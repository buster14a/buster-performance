#!/usr/bin/env bash
set -euo pipefail
workdir="$HOME/buster-fast-bench/1453-codex-20261106-perf"
sqlite="$HOME/buster-fast-bench/1296-codex-20261105/corpus/sqlite"
export EXCLUSIVE_OWNER=codex-1453 EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1453 LC_ALL=C
for policy in no-warnings no-return; do
  if [[ "$policy" == no-warnings ]]; then option=-w; else option=-Wno-return-type; fi
  for round in 1 2; do
    if [[ "$round" == 2 ]]; then order=(candidate9 base); else order=(base candidate9); fi
    for version in "${order[@]}"; do
      export EXCLUSIVE_TITLE="PR 1453 $version $policy sample $round"
      "$HOME/buster-fast-bench/exclusive.sh" bash -c '
        set -euo pipefail
        version="$1"; policy="$2"; round="$3"; option="$4"; workdir="$5"; sqlite="$6"
        test "${BUSTER_9700X_HELD:-}" = 1
        cp "$workdir/$version/build/compiler" "$workdir/compiler"
        prefix="$workdir/$version-$policy-c9-$round"
        { printf "held=%s\n" "$BUSTER_9700X_HELD"; cat /var/lib/buster-9700x/owner; sha256sum "$workdir/compiler"; } > "$prefix.receipt"
        taskset -c 2 perf stat -x, -e instructions:u,cycles:u -o "$prefix.perf" -- "$workdir/compiler" "$option" -fsyntax-only -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$sqlite" "$sqlite/sqlite3.c" > "$prefix.out" 2> "$prefix.err"
        { printf "status=0\n"; cat /var/lib/buster-9700x/owner; sha256sum "$prefix.out" "$prefix.err"; } >> "$prefix.receipt"
      ' -- "$version" "$policy" "$round" "$option" "$workdir" "$sqlite"
    done
  done
done
