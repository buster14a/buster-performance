unsigned tested(int x){unsigned y=(unsigned)x;
{__int128 r;unsigned __int128 a=(unsigned __int128)(unsigned)x<<96;if(__builtin_mul_overflow(a,(__int128)1,&r))y+=1;else y+=(unsigned)r;}
return y;}
