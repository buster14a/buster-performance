unsigned tested(int x){unsigned y=(unsigned)x;
{int r;if(__builtin_sub_overflow(x,1,&r))y+=1;else y+=(unsigned)r;}
return y;}
