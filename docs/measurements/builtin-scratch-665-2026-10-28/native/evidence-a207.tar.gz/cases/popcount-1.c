unsigned tested(int x){unsigned y=(unsigned)x;
y+=(unsigned)__builtin_popcount((unsigned)x+0);
return y;}
