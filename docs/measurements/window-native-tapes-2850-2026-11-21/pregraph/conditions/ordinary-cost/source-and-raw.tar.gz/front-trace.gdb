set pagination off
set confirm off
set print thread-events off
set debuginfod enabled off
break *node_front_chunk_windowed
commands
silent
printf "CHUNK acting=%u\n",$r8d
x/12uw $rdx
x/12ub $rcx
continue
end
break *node_window_probe
commands
silent
set $front=(NodeFront*)$rdi
printf "RECORDS %u first %u\n",$front->count,$front->made
set $k=0
while $k<$front->count && $k<64
 printf "RECORD %u tok %u op %u root %u dist %u size %u\n",$k,$front->tokens[$k],$front->ops[$k],$front->roots[$k],$front->window_left[$k],$front->sizes[$k]
 set $k=$k+1
end
continue
end
run
