#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../native-source-cost
export PATH="/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH"
python3 - <<'PY'
from pathlib import Path
p=Path('src/buster/compiler/c_check_expression_input.c');s=p.read_text()
a='node_front_chunk_windowed(front, reader, kept_tokens, kept_classes, kept, &kept_identifiers, &kept_literals);\n        node_window_probe(front);'
assert s.count(a)==1
p.write_text(s.replace(a,a[:a.index(';')+1]))
PY
git diff --binary >"$d/once.patch"
./build.sh --config Release >"$d/once.build" 2>&1;cp build/compiler "$d/once.compiler"
cd "$d";export d
sed -n '/^cd ..\/switch-inputs/,$p' condition-budget.sh | sed 's/filtered/once/g;s/k=\$d\/f-/k=\$d\/o-/g' >time-once.sh
bash time-once.sh
bash gdb-count.sh once
sed "s/'filtered','front'/'filtered','once'/;s/fresh-process-wall.tsv/fresh-process-wall-once.tsv/" standalone-wall.py >once-wall.py
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";python3 "$d/once-wall.py" "${args[@]}"
