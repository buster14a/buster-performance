#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../native-source-cost
export PATH="/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH"
python3 "$d/configure.py" take;python3 "$d/condition-budget.py"
git diff --binary >"$d/filtered.patch"
./build.sh --config Release >"$d/filtered.build" 2>&1
cp build/compiler "$d/filtered.compiler"
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
for mode in filtered;do
 r=$d/pre-$mode
 NODE_SOURCE_NATIVE_ORACLE="$r.native" NODE_SOURCE_GRAPH_ORACLE="$r.graph" "$d/$mode.compiler" --lanes 1 -c "${args[@]}" -o "$r.o" >"$r.stdout" 2>"$r.stderr"
 for f in o native graph stdout stderr;do cmp "$d/pre-off.$f" "$r.$f";done
done
for i in {1..5};do
 m=(off take filtered filtered take off);if [[ $i == 2 || $i == 4 ]];then m=(filtered off take take off filtered);fi
 j=0;for mode in "${m[@]}";do
  k=$d/f-$i-$j-$mode;j=$((j+1))
  perf stat -x, -o "$k.stat" -e duration_time,instructions:u,cycles:u,cycles:k,page-faults -- "$d/$mode.compiler" --lanes 1 -c "${args[@]}" -o "$d/timed.o" >"$k.stdout" 2>"$k.stderr"
  cmp "$d/timed.o" "$d/pre-off.o"
 done
done
