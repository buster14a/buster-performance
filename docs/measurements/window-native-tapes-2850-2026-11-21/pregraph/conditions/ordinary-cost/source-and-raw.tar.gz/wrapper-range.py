from pathlib import Path
p=Path('src/buster/compiler/c_check_expression_input.c')
s=p.read_text()
a=s.index('            const uint32_t previous=tokens[end-1];')
b=s.index('                starts[runs]',a)
s=s[:a]+'''            // The close-condition token owns both its value and the parser's forwarding list actions.
            // Collect every action of that closed parser subtree; the existing front decides their roles.
            const uint32_t last=reader->postorder_positions[token];
            const uint32_t size=reader->subtree_sizes[last];
            if (!size || size>last+1) continue;
            const uint32_t first=last+1-size;
            if ((chunk_first>first) || (through && first<=reader->postorder_positions[tokens[through-1]])) continue;
            uint32_t start=end;
            while(start>through && reader->postorder_positions[tokens[start-1]]>=first)
                --start;
            if(start<end)
            {
'''+s[b:]
a=s.index('static void check_source_condition_chunk')
b=s.index('static __attribute__((noinline)) uint64_t node_front_prepared',a)
s=s[:a]+s[a:b].replace('uint32_t acting, const CheckInputIdentifiers','uint32_t acting, uint32_t chunk_first, const CheckInputIdentifiers')+s[b:]
s=s.replace('check_source_condition_chunk(front,reader,tokens,classes,acting,identifiers,literals);','check_source_condition_chunk(front,reader,tokens,classes,acting,chunk_first,identifiers,literals);')
a=s.index('static __attribute__((noinline)) uint64_t node_front_prepared(')
b=s.index('    const uint64_t compacted',a)
s=s[:a]+s[a:b].replace('uint64_t start)','uint64_t start, uint32_t chunk_first)')+s[b:]
s=s.replace('fronting = node_front_prepared(front, fronted, reader, tokens, classes, acting, &identifiers, &literals, start);','fronting = node_front_prepared(front, fronted, reader, tokens, classes, acting, &identifiers, &literals, start, first);')
p.write_text(s)
