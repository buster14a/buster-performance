#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;out=$d/profiles;mkdir -p "$out";cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
for m in off filtered once;do
 for j in 1 2 3;do
  perf record -q -o "$out/$m-$j.data" -e cycles:u -c 300001 -- "$d/$m.compiler" --lanes 1 -c "${args[@]}" -o "$out/out.o" 2>"$out/$m-$j.stderr"
  cmp "$out/out.o" "$d/pre-off.o"
  perf report -i "$out/$m-$j.data" --stdio --no-children --sort comm,dso,symbol --percent-limit 0 --no-demangle --stdio-color never >"$out/$m-$j.txt"
 done
done
