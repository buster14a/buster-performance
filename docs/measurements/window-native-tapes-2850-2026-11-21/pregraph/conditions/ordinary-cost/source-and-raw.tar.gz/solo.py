from pathlib import Path
p=Path('src/buster/compiler/c_check_node_machine_facts.c')
s=p.read_text();a=s.index('        NodeFront* plain = arena_push_array',s.index('static void node_facts_window_begin(NodeFront* front, CheckInputReader* reader)\n{'));b=s.index('            front->plain = plain;',a)
end=s.index('        }',b)+9
p.write_text(s[:a]+'        front->plain = NULL;\n'+s[end:])
