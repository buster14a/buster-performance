#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;cd ../native-source-cost
export PATH="/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH"
python3 "$d/configure.py" take;python3 "$d/condition-budget.py";python3 "$d/condition-front.py"
git diff --binary >"$d/front.patch"
./build.sh --config Release >"$d/front.build" 2>&1
cp build/compiler "$d/front.compiler"
cd "$d"
sed -n '/^cd ..\/switch-inputs/,$p' condition-budget.sh | sed 's/filtered/front/g;s/k=\$d\/f-/k=\$d\/p-/g' >time-front.sh
export d;bash time-front.sh
