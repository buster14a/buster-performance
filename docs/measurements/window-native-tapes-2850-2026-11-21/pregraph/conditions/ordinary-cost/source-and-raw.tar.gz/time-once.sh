cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
for mode in once;do
 r=$d/pre-$mode
 NODE_SOURCE_NATIVE_ORACLE="$r.native" NODE_SOURCE_GRAPH_ORACLE="$r.graph" "$d/$mode.compiler" --lanes 1 -c "${args[@]}" -o "$r.o" >"$r.stdout" 2>"$r.stderr"
 for f in o native graph stdout stderr;do cmp "$d/pre-off.$f" "$r.$f";done
done
for i in {1..5};do
 m=(off take once once take off);if [[ $i == 2 || $i == 4 ]];then m=(once off take take off once);fi
 j=0;for mode in "${m[@]}";do
  k=$d/o-$i-$j-$mode;j=$((j+1))
  perf stat -x, -o "$k.stat" -e duration_time,instructions:u,cycles:u,cycles:k,page-faults -- "$d/$mode.compiler" --lanes 1 -c "${args[@]}" -o "$d/timed.o" >"$k.stdout" 2>"$k.stderr"
  cmp "$d/timed.o" "$d/pre-off.o"
 done
done
