#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD
for mode in take once;do
 gdb -nx -q --batch -x front-trace.gdb --args "$d/$mode.compiler" --lanes 1 -c ../cross-chunk-study/condition-runtime/conditional.c -o "$d/trace-$mode.o" >"trace-$mode.txt" 2>&1 || true
done
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
gdb -nx -q --batch -x "$d/native-calls.gdb" --args "$d/once.compiler" --lanes 1 -c "${args[@]}" -o "$d/debugger-sqlite-once.o" >"$d/debugger-sqlite-once.log" 2>&1
cmp "$d/debugger-sqlite-once.o" "$d/pre-off.o"
