"""Restrict source typing and emission to the supported condition family in a standalone ordinary -c image."""
from pathlib import Path
root=Path('src/buster/compiler')
def repl(p,a,b):
 s=p.read_text();assert s.count(a)==1,(p,a);p.write_text(s.replace(a,b))
p=root/'c_check_node_machine_facts.c';s=p.read_text()
a=s.index('    CheckInput* in = st->reader->output;',s.index('static void node_cross_type_end('))
b=s.index('    if (',s.index('NODE_DISABLED_REPORT(stderr,"cross-view',a))
# The recorded provisional-pointee keys and canonical row witnesses were consumed only in the optional late reference join.
s=s[:a]+s[b:];s=s.replace('    else if (root_private && !view->saved_rows) abort();','')
a='    struct NodeFactsReader* state = front->typer->facts;\n    const bool temporary_types ='
assert s.count(a)==1
s=s.replace(a,'''    struct NodeFactsReader* state = front->typer->facts;
    uint8_t selected[BUSTER_NODE_FRONT_RECORDS + 64]={0};
    uint32_t candidates=0;
    memset(state->proof_source_tapes,0,sizeof(state->proof_source_tapes));
    for(uint32_t r=front->made;r<front->count;++r)
    {
        const uint32_t left=front->window_left[r];
        if(!front->roots[r] || front->ops[r]!=CHECK_OP_CONDITION || !left || left>r) continue;
        const uint32_t top=r-left, size=front->sizes[top];
        if(!size || size>top+1 || size>=BUSTER_NODE_MACHINE_MOST) continue;
        memset(selected+top+1-size,1,size);
        selected[r]=1;
        candidates++;
    }
    if (candidates==0) return;
    const bool temporary_types =''')
a='        const uint8_t kind = front->window_kinds[x];\n        const uint32_t entry = front->window_entries[x];\n        bool chosen = false;';assert s.count(a)==1
s=s.replace(a,'''        if (!selected[x]) continue;
'''+a);p.write_text(s)
p=root/'c_check_node_census.c'
repl(p,'            if (front->roots[root] == 0 || !state->proof_made[root] || distance == 0 || distance > root ||','            if (op!=CHECK_OP_CONDITION || front->roots[root] == 0 || !state->proof_made[root] || distance == 0 || distance > root ||')
# Disable only the after-walk comparison and census for the unconditional source image. Preserve the ordinary batch flush and window carry.
p=root/'c_check_expression_input.c';s=p.read_text()
a=s.index('    for (uint32_t k = 0; k < acting;',s.index('static __attribute__((noinline)) uint64_t node_front_acted'))
s=s[:a]+'''    if (front->window && (fronted & BUSTER_NODE_FRONT_ORDER)==BUSTER_NODE_FRONT_BEFORE)
    {
        const uint64_t start=__rdtsc();
        check_input_expression_flush(reader,batch);
        front->pending=front->count;
        return __rdtsc()-start;
    }
'''+s[a:];p.write_text(s)
