#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../switch-inputs;source ../switch-local-args.sh
eval "args=($sqlite_arguments)";python3 "$d/standalone-wall.py" "${args[@]}"
