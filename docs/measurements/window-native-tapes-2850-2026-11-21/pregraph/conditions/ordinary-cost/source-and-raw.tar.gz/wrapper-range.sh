#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../native-source-cost
export PATH="/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH"
python3 "$d/wrapper-range.py";git diff --binary >"$d/wrapper.patch"
./build.sh --config Release >"$d/wrapper.build" 2>&1;cp build/compiler "$d/wrapper.compiler"
cd "$d"; export d
gdb -nx -q --batch -x front-trace.gdb --args "$d/wrapper.compiler" --lanes 1 -c ../cross-chunk-study/condition-runtime/conditional.c -o "$d/trace-wrapper.o" >trace-wrapper.txt 2>&1 || true
sed -n '/^cd ..\/switch-inputs/,$p' condition-budget.sh | sed 's/filtered/wrapper/g;s/k=\$d\/f-/k=\$d\/wr-/g' >time-wrapper.sh
bash time-wrapper.sh
bash gdb-count.sh wrapper
sed "s/'filtered','front'/'filtered','wrapper'/;s/fresh-process-wall.tsv/fresh-process-wall-wrapper.tsv/" standalone-wall.py >wrapper-wall.py
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";python3 "$d/wrapper-wall.py" "${args[@]}"
