#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
for mode in "$@";do
 for g in fixture sqlite;do
  if [[ $g == fixture ]];then f=("$d/../cross-chunk-study/condition-runtime/conditional.c");else f=("${args[@]}");fi
  out=$d/debugger-$g-$mode
  gdb -nx -q --batch -x "$d/native-calls.gdb" --args "$d/$mode.compiler" --lanes 1 -c "${f[@]}" -o "$out.o" >"$out.log" 2>&1
  rg '^EXECUTED_NATIVE_ENTRIES [1-9]' "$out.log";if [[ $g == sqlite ]];then cmp "$out.o" "$d/pre-off.o";fi
 done
done
