from pathlib import Path
import re,csv,sys,tarfile,hashlib,shutil,statistics as st,collections,subprocess
d=Path(__file__).resolve().parent;g=Path(sys.argv[1]).resolve();g.mkdir(parents=True,exist_ok=True)
def tsv(name,rows):
 with (g/name).open('w') as f:csv.writer(f,delimiter='\t',lineterminator='\n').writerows(rows)
def sha(p):
 with p.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
stages=[('',4,['off','capture','take']),('f-',5,['off','take','filtered']),('o-',5,['off','take','once']),('wr-',5,['off','take','wrapper'])]
if (d/'debugger-sqlite-solo.log').exists() and (d/'fresh-process-wall-solo.tsv').exists():stages.append(('so-',5,['off','wrapper','solo']))
rows=[['series','round','mode','instructions_user','cycles_user','cycles_kernel','faults']]
pairs=[['series','trial','baseline','user_instructions','user_cycles','kernel_cycles','faults','min_total_cycles_per_token','median_total_cycles_per_token','max_total_cycles_per_token']]
sources=[]
for prefix,n,modes in stages:
 series=prefix.rstrip('-') or 'baked'
 values={}
 for rd in range(1,n+1):
  for mode in modes:
   paths=sorted(d.glob(f'{prefix}{rd}-[0-9]-{mode}.stat'));assert len(paths)==2,paths
   rates=[]
   for p in paths:
    metrics={l.split(',')[2]:int(l.split(',')[0]) for l in p.read_text().splitlines() if ',' in l}
    rates.append([metrics[k] for k in ['instructions:u','cycles:u','cycles:k','page-faults']]);sources.append(p)
   values[rd,mode]=[st.mean(col) for col in zip(*rates)]
   rows.append([series,rd,mode,*values[rd,mode]])
 for trial,base in [(modes[1],modes[0]),(modes[2],modes[0]),(modes[2],modes[1])]:
  diffs=[[x-y for x,y in zip(values[rd,trial],values[rd,base])] for rd in range(1,n+1)]
  normalized=[(x[1]+x[2])/716136 for x in diffs]
  pairs.append([series,trial,base,*[st.median(col) for col in zip(*diffs)],min(normalized),st.median(normalized),max(normalized)])
tsv('rounds.tsv',rows);tsv('paired.tsv',pairs)
wr=[['series','trial','baseline','median_elapsed_ms','minimum','maximum','faster_rounds','round_count']]
for name in ['fresh-process-wall.tsv','fresh-process-wall-wrapper.tsv','fresh-process-wall-solo.tsv']:
 p=d/name
 if not p.exists():continue
 r=list(csv.DictReader(p.open(),delimiter='\t'));groups=collections.defaultdict(list)
 for x in r:groups[int(x['round']),x['mode']].append(int(x['ns']))
 modes=list(dict.fromkeys(x['mode'] for x in r))
 if len(r)!=10*len(modes): continue
 sources.append(p)
 for trial in modes[1:]:
  if trial=='front':continue
  for base in (['off'] if trial in ('capture','wrapper') else ['off',modes[1]]):
   if trial==base:continue
   dd=[(st.mean(groups[k,trial])-st.mean(groups[k,base]))/1e6 for k in range(1,6)]
   wr.append([name,trial,base,st.median(dd),min(dd),max(dd),sum(x<0 for x in dd),5])
tsv('fresh-wall.tsv',wr)
receipt=[['mode','ordinary_release_elf','front_fixture_native_entries','sqlite_native_entries','ordinary_object','graph','native_abi_rows']]
for mode in dict.fromkeys(mode for _,_,modes in stages for mode in modes):
 counts=[]
 for kind in ['fixture','sqlite']:
  file=d/f'debugger-{kind}-{mode}.log'
  if file.exists():
   cnt=re.findall(r'EXECUTED_NATIVE_ENTRIES (\d+)',file.read_text());counts.append(cnt[-1] if cnt else '-');sources.append(file)
  else:counts.append('-')
 records=[]
 for ext in ['o','graph','native']:
  file=d/f'pre-{mode}.{ext}';records.append(sha(file));assert records[-1]==sha(d/f'pre-off.{ext}')
 receipt.append([mode,sha(d/f'{mode}.compiler'),*counts,*records])
 sources.append(d/f'{mode}.patch')
tsv('coverage.tsv',receipt)
profile=[['variant','symbol','median_fresh_pct','minimum','maximum']]
for mode in ('off','filtered','once'):
 observed=[]
 for p in sorted((d/'profiles').glob(mode+'-*.txt')):
  raw=p.read_text();values=collections.defaultdict(float)
  for l in raw.splitlines():
   m=re.match(r'\s*(\d+\.\d+)%\s+.*?\s+\[(?:\.|k)\]\s+(\S+)',l)
   if m:values[m[2]]+=float(m[1])
  observed.append(values)
 assert len(observed)==3
 for symbol in set().union(*(dict(i) for i in observed)):
  xs=[v.get(symbol,0) for v in observed];median=st.median(xs)
  if median>=0.5:profile.append([mode,symbol,median,min(xs),max(xs)])
tsv('samples.tsv',[profile[0],*sorted(profile[1:],key=lambda r:(r[0],-r[2],r[1]))])
sources.extend([p for p in d.iterdir() if p.suffix in ['.sh','.py','.gdb']])
sources.extend(d.glob('trace-*.txt'));sources.extend((d/'profiles').glob('*.txt'))
with tarfile.open(g/'source-and-raw.tar.gz','w:gz',compresslevel=2) as tar:
 for path in sorted(set(sources)):tar.add(path,arcname=str(path.relative_to(d)))
print('pairs',pairs[-3:]);print('coverage',[r[:4] for r in receipt])
