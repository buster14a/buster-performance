#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../native-source-cost
export PATH="/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH"
python3 "$d/solo.py";git diff --binary >"$d/solo.patch"
./build.sh --config Release >"$d/solo.build" 2>&1;cp build/compiler "$d/solo.compiler"
cd "$d";export d
sed -n '/^cd ..\/switch-inputs/,$p' condition-budget.sh | sed 's/filtered/solo/g;s/take/wrapper/g;s/k=\$d\/f-/k=\$d\/so-/g' >time-solo.sh
bash time-solo.sh
bash gdb-count.sh solo
sed "s/'capture','take','filtered','front'/'wrapper','solo'/;s/fresh-process-wall.tsv/fresh-process-wall-solo.tsv/" standalone-wall.py >solo-wall.py
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)";python3 "$d/solo-wall.py" "${args[@]}"
