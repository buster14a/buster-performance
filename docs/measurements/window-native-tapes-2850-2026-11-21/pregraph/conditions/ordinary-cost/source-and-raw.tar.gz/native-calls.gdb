set pagination off
set confirm off
set print thread-events off
set debuginfod enabled off
python
class SourceNativeRows(gdb.Breakpoint):
    def __init__(self):
        super().__init__('*check_lower_source_entry', internal=True)
        self.silent=True
        self.entries=0
    def stop(self):
        self.entries += 1
        return False
bp=SourceNativeRows()
end
run
python print("EXECUTED_NATIVE_ENTRIES %d" % bp.entries)
