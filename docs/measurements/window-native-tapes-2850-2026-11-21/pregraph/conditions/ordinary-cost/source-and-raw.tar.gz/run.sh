#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")";d=$PWD;cd ../native-source-cost
export PATH="/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH"
for mode in off capture take;do
 python3 "$d/configure.py" "$mode"
 git diff --binary >"$d/$mode.patch"
 ./build.sh --config Release >"$d/$mode.build" 2>&1
 cp build/compiler "$d/$mode.compiler"
done
cd ../switch-inputs;source ../switch-local-args.sh
eval "args=($sqlite_arguments)"
for mode in off capture take;do
 r=$d/pre-$mode
 NODE_SOURCE_NATIVE_ORACLE="$r.native" NODE_SOURCE_GRAPH_ORACLE="$r.graph" "$d/$mode.compiler" --lanes 1 -c "${args[@]}" -o "$r.o" >"$r.stdout" 2>"$r.stderr"
 for f in o native graph stdout stderr;do cmp "$d/pre-off.$f" "$r.$f";done
done
for round in {1..4};do
 case $round in 1|4) modes=(off capture take take capture off);;2) modes=(capture take off off take capture);;3) modes=(take off capture capture off take);;esac
 idx=0
 for mode in "${modes[@]}";do
  p=$d/$round-$idx-$mode;idx=$((idx+1))
  perf stat -x, -o "$p.stat" -e instructions:u,cycles:u,cycles:k,page-faults -- "$d/$mode.compiler" --lanes 1 -c "${args[@]}" -o "$d/timed.o" >"$p.stdout" 2>"$p.stderr"
  cmp "$d/timed.o" "$d/pre-off.o"
 done
done
