from pathlib import Path
p=Path('src/buster/compiler/c_check_expression_input.c')
s=p.read_text()
ref=Path('../bench-local/sourcebb8.patch').read_text()
a=ref.index('+static void check_source_front_chunk(')
b=ref.index('\n+#endif',a)
helper='\n'.join(l[1:] for l in ref[a:b].splitlines())
helper=helper.replace('check_source_front_chunk','check_source_condition_chunk')
helper=helper.replace('const __m512i returned = _mm512_set1_epi32(CHECK_INPUT_CODE_RETURN','const __m512i condition = _mm512_set1_epi32(CHECK_INPUT_CODE_CONDITION')
helper=helper.replace('const uint32_t returns = _mm512_cmpeq_epi32_mask(codes, returned);','const uint32_t direct = _mm512_cmpeq_epi32_mask(codes, condition);').replace('(returns | _mm512_cmpeq_epi32_mask','(direct | _mm512_cmpeq_epi32_mask')
a=helper.index('            const bool is_return =');b=helper.index('                starts[runs]',a)
helper=helper[:a]+'''            const uint32_t token=tokens[end];
            const uint8_t role=reader->parser->tree.roles[token];
            if (!end || !(role==PARSE_ROLE_CLOSE_CONDITION ||
                (role==PARSE_ROLE_TERMINATOR && reader->conditions[token]))) continue;
            const uint32_t previous=tokens[end-1];
            const uint32_t last=reader->postorder_positions[previous];
            const uint32_t size=reader->subtree_sizes[last];
            if (!size || size>last+1) continue;
            const uint32_t first=last+1-size;
            if (first<reader->postorder_positions[tokens[0]] || (through && first<=reader->postorder_positions[tokens[through-1]])) continue;
            uint32_t start=end;
            bool leaves=false;
            while(start!=through && reader->postorder_positions[tokens[start-1]]>=first)
            {
                const uint32_t at=start-1;
                const uint32_t action=(classes[at]&BUSTER_CHECK_EXPRESSION_CODE_MASK)>>BUSTER_CHECK_EXPRESSION_CODE_SHIFT;
                leaves|=action==CHECK_INPUT_CODE_IDENTIFIER || action==CHECK_INPUT_CODE_LITERAL;
                if (!(action==CHECK_INPUT_CODE_IDENTIFIER || action==CHECK_INPUT_CODE_LITERAL || action==CHECK_INPUT_CODE_PREFIX ||
                    action==CHECK_INPUT_CODE_BINARY || action==CHECK_INPUT_CODE_SUBSCRIPT || action==CHECK_INPUT_CODE_MEMBER ||
                    action==CHECK_INPUT_CODE_GROUP || action==CHECK_INPUT_CODE_CAST || action==CHECK_INPUT_CODE_LIST || action==CHECK_INPUT_CODE_SEPARATOR)) break;
                start=at;
            }
            if(leaves && start<end && (start==0 || reader->postorder_positions[tokens[start-1]]<first))
            {
'''+helper[b:]
a=s.index('static __attribute__((noinline)) uint64_t node_front_prepared(')
s=s[:a]+'#if BUSTER_IN_UNIT(BUSTER_UNIT_CHECKER)\n'+helper+'\n#endif\n'+s[a:]
a=s.index('static __attribute__((noinline)) uint64_t node_front_prepared(')
before=s[:a];s=s[a:].replace('node_front_chunk_windowed(front, reader, tokens, classes, acting, identifiers, literals);','check_source_condition_chunk(front,reader,tokens,classes,acting,identifiers,literals);',1)
# A chunk with no supported source subtree didn't populate any front data. Let the ordinary reader process it in full.
a='            node_cross_chunk_prepare(front, reader);';s=s.replace(a,'            if (front->count==0) return __rdtsc()-ready;\n'+a,1)
p.write_text(before+s)
