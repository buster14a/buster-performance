#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
export NODE_SOURCE_COMPACT_FAMILIES=scalar NODE_FIXED_TYPE_ORDER=replay NODE_SOURCE_COMPACT_FIXED_CALL=1 NODE_SOURCE_CONSUME_FIXED_CALL=1 NODE_SOURCE_COMPACT_READ_CONDITION=1 NODE_SOURCE_COMPACT_LOGICAL=1
bash mixed-runtime.sh
bash fixed-call-check.sh "$d/families.compiler" "$d/mixed-fixed-runtime"
python3 fixed-call-grid.py "$d/families.compiler" "$d/mixed-fixed-grid"
python3 mixed-grid.py
python3 mixed-memory-grid.py
