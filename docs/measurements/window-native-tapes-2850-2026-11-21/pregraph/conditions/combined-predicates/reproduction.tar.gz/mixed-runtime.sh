#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD
out=$d/mixed-logical-runtime;mkdir -p "$out";cd "$out"
cp "$d/logical-guard.c" probe.c;cp "$d/logical-driver.c" driver.c
ref=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$ref" probe.c driver.c -O2 -o reference;./reference >ref.answer
source <(sed -n '/^switches=(/p' "$d/compact-conditions.sh")
for p in ordinary debug warnings;do
 f=();[[ $p != debug ]] || f=(-g);[[ $p != warnings ]] || f=(-Wall -Wextra)
 for mode in plain source compact disabled fault label;do
  opts=(env);[[ $mode == plain ]] || opts+=("${switches[@]}")
  if [[ $mode == compact || $mode == disabled || $mode == fault || $mode == label ]];then opts+=(NODE_SOURCE_COMPACT=1 NODE_SOURCE_COMPACT_REPORT=1 NODE_SOURCE_COMPACT_CONDITION=1 NODE_SOURCE_COMPACT_READ_CONDITION=1 NODE_SOURCE_COMPACT_LOGICAL=1);fi
  [[ $mode != disabled ]] || opts+=(env -u NODE_SOURCE_CONSUME_CONDITION)
  [[ $mode != fault ]] || opts+=(NODE_SOURCE_FLIP_SENSE=1)
  [[ $mode != label ]] || opts+=(NODE_SOURCE_LABEL_FAULT=1)
  k=$p-$mode
  "${opts[@]}" "$d/families.compiler" --lanes 1 -c "${f[@]}" probe.c -o "$k.o" >"$k.out" 2>"$k.err" && s=0 || s=$?
  echo "$s" >"$k.status"
  if [[ $s == 0 ]];then "$ref" driver.c "$k.o" -o "$k.run";(ulimit -c 0;"./$k.run") >"$k.answer" 2>"$k.runerr" && z=0 || z=$?; echo "$z" >"$k.runtime";fi
  if [[ $mode == plain || $mode == source || $mode == compact ]];then cmp ref.answer "$k.answer";fi
 done
done
