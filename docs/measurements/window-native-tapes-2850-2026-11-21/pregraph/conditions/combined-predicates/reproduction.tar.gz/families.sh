#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../conditional-families
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
git diff --binary >"$d/families.patch"
./build.sh >"$d/families.build" 2>&1;cp build/compiler "$d/families.compiler"
export cc=$d/families.compiler d NODE_FIXED_TYPE_ORDER=replay NODE_SOURCE_COMPACT_FIXED_CALL=1 NODE_SOURCE_CONSUME_FIXED_CALL=1 NODE_SOURCE_COMPACT_READ_CONDITION=1 NODE_SOURCE_COMPACT_LOGICAL=1 
cd "$d";for family in union scalar;do
 export NODE_SOURCE_COMPACT_FAMILIES=$family
 sed "s@fixed-type-replay@family-$family@g" check-type-replay.sh >"check-family-$family.sh"
 bash "check-family-$family.sh"
done
