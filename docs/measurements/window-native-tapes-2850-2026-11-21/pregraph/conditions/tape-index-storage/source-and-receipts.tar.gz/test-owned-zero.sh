#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../paid-zero
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
git diff --binary >"$d/owned-zero.patch"
./build.sh --config Release >"$d/owned-zero.build" 2>&1;cp build/compiler "$d/owned-zero.compiler"
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
m=owned-zero;f=$d/$m
NODE_SOURCE_GRAPH_ORACLE="$f.graph" NODE_SOURCE_NATIVE_ORACLE="$f.native" "$f.compiler" --lanes 1 -c "${args[@]}" -o "$f.o" >"$f.out" 2>"$f.err"
for ext in graph native o out err;do cmp "$d/screen.$ext" "$f.$ext";done
for r in {1..5};do
 modes=(screen owned-zero owned-zero screen); if [[ $r == 2 || $r == 4 ]];then modes=(owned-zero screen screen owned-zero);fi
 j=0;for mode in "${modes[@]}";do f=$d/oz-$r-$j-$mode;j=$((j+1));perf stat -x, -o "$f.stat" -e instructions:u,cycles:u,cycles:k,minor-faults -- "$d/$mode.compiler" --lanes 1 -c "${args[@]}" -o "$d/oz-timed.o" >"$f.out" 2>"$f.err";cmp "$d/off.o" "$d/oz-timed.o";done
done
