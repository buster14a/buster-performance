from pathlib import Path
import csv,statistics,hashlib,tarfile,collections
d=Path(__file__).resolve().parent
out=d.parent/'perf/docs/measurements/window-native-tapes-2850-2026-11-21/pregraph/conditions/tape-index-storage';out.mkdir(parents=True,exist_ok=True)
def write(f,head,rows):
 with (out/f).open('w') as b:
  w=csv.writer(b,delimiter='\t',lineterminator='\n');w.writerow(head);w.writerows(rows)
def sha(p):
 with p.open('rb') as b:return hashlib.file_digest(b,'sha256').hexdigest()
qualified=[];raw=[];pairs=[]
for mode in ('screen','paged','owned-zero'):
 qualified.append([mode,*[sha(d/(mode+'.'+ext)) for ext in ('graph','native','o','out','err','patch','compiler')]])
assert all(r[1:6]==qualified[0][1:6] for r in qualified)
write('checks.tsv',['mode','graph','native','ELF','stdout','diagnostics','patch','compiler'],qualified)
for prefix,treatment in [('pg','paged'),('oz','owned-zero')]:
 val=collections.defaultdict(list)
 for f in sorted(d.glob(prefix+'-*.stat')):
  _,rd,pos,mode=f.stem.split('-',3)
  v={r[2]:int(r[0]) for r in csv.reader(f.open()) if len(r)>=5 and r[4]=='100.00'}
  assert len(v)==4
  m=[v['instructions:u'],v['cycles:u'],v['cycles:k'],v['cycles:u']+v['cycles:k'],v['minor-faults']]
  for k,x in zip(['user instructions','user cycles','kernel cycles','total cycles','minor faults'],m):val[mode,rd,k].append(x)
  raw.append([prefix,rd,pos,mode,*m])
 for key in ['user instructions','user cycles','kernel cycles','total cycles','minor faults']:
  outcomes=[]
  for i in range(1,6):
   a,b=val[treatment,str(i),key],val['screen',str(i),key];assert len(a)==len(b)==2
   outcomes.append(statistics.mean(a)-statistics.mean(b))
  pairs.append([treatment,key,statistics.median(outcomes),min(outcomes),max(outcomes),sum(v<0 for v in outcomes)])
write('pmu.tsv',['experiment','round','position','mode','user instructions','user cycles','kernel cycles','total cycles','minor faults'],raw)
write('paired.tsv',['candidate','metric','median paired delta','minimum','maximum','lower rounds'],pairs)
with tarfile.open(out/'source-and-receipts.tar.gz','w:gz') as t:
 for name in ['screen.patch','paged.patch','owned-zero.patch','screen.build','paged.build','owned-zero.build','test-page-index.sh','test-owned-zero.sh','record-index.py']:
  t.add(d/name,arcname=name)
 for prefix in ['oz','pg']:
  for f in d.glob(prefix+'-*.stat'):t.add(f,arcname=f.name)
print(pairs)
