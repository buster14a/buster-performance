from pathlib import Path
import csv,statistics,re,collections,tarfile,hashlib
d=Path(__file__).resolve().parent;root=d/'raw/results';out=d.parent/'perf/docs/measurements/window-native-tapes-2850-2026-11-21/pregraph/conditions/combined-producer-cost/zen5'
out.mkdir(parents=True,exist_ok=True)
def write(name,head,rows):
 with (out/name).open('w') as f:
  w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(head);w.writerows(rows)
samples=[];pairs=[];proof=[]
with tarfile.open(out/'native-receipts.tar.gz','w:gz') as t:
 for name in ['sqlite','main']:
  p=root/('matrix-paidfam-'+name);v=collections.defaultdict(list)
  rows=list(csv.DictReader((p/'oracles.tsv').open(),delimiter='\t'));assert rows[0]['graph sha256']==rows[1]['graph sha256'] and int(rows[2]['nodes'])<int(rows[0]['nodes']) and len({x['native sha256'] for x in rows})==1
  elf=(p/'stage-off.sha256').read_text().strip()
  for x in rows:
   m=x['mode']
   assert (p/('oracle-'+m+'.sha256')).read_text().strip()==elf and (p/('warnings-'+m+'.sha256')).read_text().strip()==elf and (p/('stage-'+m+'.sha256')).read_text().strip()==elf
   assert (p/('warnings-'+m+'.stderr')).read_bytes()==(p/'warnings-off.stderr').read_bytes()
   proof.append([name,*x.values(),elf])
  order=list(csv.DictReader((p/'order.tsv').open(),delimiter='\t'));assert len(order)==60
  for series in ('pmu','wall'):
   for rd in range(1,6):
    modes=[r['mode'] for r in order if r['series']==series and r['round']==str(rd)];assert modes==modes[::-1] and sorted(modes)==sorted(['off','keep','replace']*2)
  for row in order:
   series,rd,pos,m=row.values();stem=p/f'{series}-{rd}-{pos}';assert stem.with_suffix('.sha256').read_text().strip()==elf
   if series=='pmu':
    e={x[2]:float(x[0]) for x in csv.reader(stem.with_suffix('.perf').open()) if len(x)>=5 and x[4]=='100.00'};assert len(e)==8
    obs={'total cycles/token':(e['cycles:u']+e['cycles:k'])/({'sqlite':716136,'main':2433922}[name]),'user instructions':e['instructions:u'],'faults':e['page-faults']}
   else:
    s=stem.with_suffix('.wall').read_text();assert 'time-runs: done, 0 failed processes' in s
    obs={'wall ms':float(re.search(r'^run 1 list 1.*?: ([\d.]+) ms wall',s,re.M)[1])}
   for metric,x in obs.items():
    samples.append([name,series,rd,pos,m,metric,x]);v[m,int(rd),metric].append(x)
  for a,b in [('keep','off'),('replace','keep'),('replace','off')]:
   for metric in ['total cycles/token','user instructions','faults','wall ms']:
    av=[statistics.mean(v[a,i,metric]) for i in range(1,6)];bv=[statistics.mean(v[b,i,metric]) for i in range(1,6)];dd=[x-y for x,y in zip(av,bv)]
    pairs.append([name,a,b,metric,statistics.median(av),statistics.median(bv),statistics.median(dd),min(dd),max(dd),sum(x<0 for x in dd)])
  for f in sorted(p.iterdir()):
   if f.is_file():t.add(f,arcname=name+'/'+f.name)
 for m in ('off','keep','replace'):
  rev=(root/('paidfam-'+m)/'revision.txt').read_text().splitlines();assert rev[0]=='84a7d3d76891d6c393497e62e6aff38f2b162fc2' and rev[1].split()[0]==hashlib.sha256((d/('paidfam-'+m+'.patch')).read_bytes()).hexdigest()
  for f in ('revision.txt','compiler.sha256'):t.add(root/('paidfam-'+m)/f,arcname='builds/'+m+'/'+f)
 for f in ('paidfam-config.sh','paidfam-one.sh','paidfam.sh','paidfam-manifest.py','paidfam-record.py'):t.add(d/f,arcname=f)
write('oracles.tsv',['input','mode','nodes','arguments','graph sha256','native sha256','native bytes','ELF sha256'],proof)
write('paired.tsv',['input','candidate','reference','metric','candidate median','reference median','median paired delta','min','max','lower rounds'],pairs)
write('samples.tsv',['input','series','round','position','mode','metric','value'],samples)
for x in pairs:
 if x[3] in ('total cycles/token','wall ms','user instructions'):print(x[0:4],round(x[6],3),x[-1])
