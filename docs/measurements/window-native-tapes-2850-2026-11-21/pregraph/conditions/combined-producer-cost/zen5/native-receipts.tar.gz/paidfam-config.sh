declare -a modes=(off keep replace) metrics=(pmu wall)
declare -A binary=([off]=paidfam-off [keep]=paidfam-keep [replace]=paidfam-replace)
round_count=5
