declare -a modes=(baseline off active) metrics=(pmu wall)
declare -A binary=([baseline]=maincurrentd335 [off]=paidsinglectx [active]=paidsinglectx)
round_count=3
