from pathlib import Path
import hashlib,struct,csv,sys
root=Path('results')
for g in (sys.argv[1:] or ['sqlite','main']):
 d=root/('matrix-paidsinglectx-'+g)
 with (d/'oracles.tsv').open('w') as f:
  w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['mode','nodes','arguments','graph sha256','native sha256','native bytes'])
  for mode in ['off','active']:
   p=d/('oracle-'+mode+'.graph');native=d/('oracle-'+mode+'.native')
   with p.open('rb') as b:n,a,_,_=struct.unpack('<4I',b.read(16));b.seek(0);graph_hash=hashlib.file_digest(b,'sha256').hexdigest()
   with native.open('rb') as b:h=hashlib.file_digest(b,'sha256').hexdigest()
   w.writerow([mode,n,a,graph_hash,h,native.stat().st_size])
