declare -a modes=(off owned profile) metrics=(pmu wall)
declare -A binary=([off]=paidfam-off [owned]=paidowned [profile]=paidprofile)
round_count=3
