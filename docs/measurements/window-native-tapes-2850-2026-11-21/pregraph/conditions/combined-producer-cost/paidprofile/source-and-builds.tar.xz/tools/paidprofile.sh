#!/bin/bash
set -euo pipefail
cd ~/buster-fast-bench/2850-codex-step2
experiment=$1
source ./paidprofile-config.sh
out=$PWD/results/matrix-$experiment
test ! -e "$out/order.tsv"
mkdir -p "$out"
printf 'series\tround\tposition\tmode\n' >"$out/order.tsv"
scratch=$(mktemp -d /dev/shm/buster2850-matrix.XXXXXXXX)
trap 'rm -f "$scratch/sqlite3.o"; rmdir "$scratch"' EXIT
run_mode() {
   local kind=$1 which=$2 stem=$3
   ./lock.sh taskset -c 2 bash paidprofile-one.sh "$experiment" "$kind" "$which" "$stem" "$scratch/sqlite3.o" >"$stem.lock" 2>&1 || { echo "failed $kind $which at $stem"; return 1; }
}
for kind in stage warnings; do
 for which in "${modes[@]}"; do run_mode "$kind" "$which" "$out/$kind-$which"; done
done
for m in owned profile; do
 for suf in sha256 bytes source-sha256 source-bytes; do cmp "$out/stage-off.$suf" "$out/stage-$m.$suf"; done
 for suf in sha256 bytes stdout stderr; do cmp "$out/warnings-off.$suf" "$out/warnings-$m.$suf"; done
done
for m in "${modes[@]}";do
 run_mode oracle "$m" "$out/oracle-$m"
 for suf in sha256 bytes;do cmp "$out/stage-off.$suf" "$out/oracle-$m.$suf";done
 for suf in native stdout stderr;do cmp "$out/oracle-off.$suf" "$out/oracle-$m.$suf";done
done

cmp "$out/oracle-owned.graph" "$out/oracle-profile.graph"
python3 - "$out" <<'CHECK'
import pathlib,struct,sys
d=pathlib.Path(sys.argv[1])
def nodes(m):
 with (d/('oracle-'+m+'.graph')).open('rb') as f: return struct.unpack('<I',f.read(4))[0]
assert nodes('profile')<nodes('off')
CHECK
exec 8>our-timing.lock
count=${#modes[@]}
for kind in "${metrics[@]}"; do
 for round in $(seq 1 "$round_count"); do
   half=(); order=()
   for ((i=0;i<count;i++)); do
      if ((round%2)); then j=$(((round-1+i)%count)); else j=$(((round-1+count-i)%count)); fi
      half+=("${modes[j]}")
   done
   order=("${half[@]}")
   for ((i=count-1;i>=0;i--)); do order+=("${half[i]}"); done
   flock -x 8
   pos=0
   for which in "${order[@]}"; do
      pos=$((pos+1))
      run_mode "$kind" "$which" "$out/$kind-$round-$pos"
      cmp "$out/stage-off.sha256" "$out/$kind-$round-$pos.sha256"
      printf '%s\t%s\t%s\t%s\n' "$kind" "$round" "$pos" "$which" >>"$out/order.tsv"
   done
   flock -u 8
 done
done
echo COMPLETE
