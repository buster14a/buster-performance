declare -a modes=(off replace prune parser owned) metrics=(pmu wall)
declare -A binary=([off]=paidfam-off [replace]=paidfam-replace [prune]=paidprune [parser]=paidparse [owned]=paidowned)
round_count=5
