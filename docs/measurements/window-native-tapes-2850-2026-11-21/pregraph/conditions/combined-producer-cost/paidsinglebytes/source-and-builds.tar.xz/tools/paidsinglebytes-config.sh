declare -a modes=(baseline off active) metrics=(pmu wall)
declare -A binary=([baseline]=maincurrentd335 [off]=paidsinglebytes [active]=paidsinglebytes)
round_count=3
