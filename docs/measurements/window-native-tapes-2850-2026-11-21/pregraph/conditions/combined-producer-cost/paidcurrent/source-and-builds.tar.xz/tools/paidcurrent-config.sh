declare -a modes=(baseline off active) metrics=(pmu wall)
declare -A binary=([baseline]=maincurrentd335 [off]=paidcurrent [active]=paidcurrent)
round_count=3
