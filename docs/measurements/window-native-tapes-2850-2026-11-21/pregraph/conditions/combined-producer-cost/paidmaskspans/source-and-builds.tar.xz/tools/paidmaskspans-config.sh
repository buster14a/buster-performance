declare -a modes=(baseline off active) metrics=(pmu wall)
declare -A binary=([baseline]=maincurrentd335 [off]=paidmaskspans [active]=paidmaskspans)
round_count=3
