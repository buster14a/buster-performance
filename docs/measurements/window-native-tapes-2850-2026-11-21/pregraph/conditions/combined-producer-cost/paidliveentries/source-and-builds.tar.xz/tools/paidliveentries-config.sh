declare -a modes=(baseline off active) metrics=(pmu wall)
declare -A binary=([baseline]=maincurrentd335 [off]=paidliveentries [active]=paidliveentries)
round_count=3
