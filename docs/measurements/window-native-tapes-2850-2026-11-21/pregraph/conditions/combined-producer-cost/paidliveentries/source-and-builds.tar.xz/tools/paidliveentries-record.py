"""Aggregate the paid reader-time graph replacement experiments on the frozen source inputs."""
from pathlib import Path
from collections import defaultdict
import csv, statistics as st, tarfile, hashlib, re, sys, shutil

d=Path(__file__).resolve().parent
series=sys.argv[1]
builds={'off':('paidfam-off','paidfam-off.patch'),'replace':('paidfam-replace','paidfam-replace.patch'),'prune':('paidprune','pruned.patch'),'parser':('paidparse','parser.patch'),'owned':('paidowned','owned.patch'),'profile':('paidprofile','profiled.patch')}
if series=='paidprune':
    modes=['off','replace','prune','parser','owned']; rounds=5; pairs=[('replace','off'),('prune','replace'),('parser','prune'),('owned','parser'),('owned','off')]
elif series=='paidprofile':
    modes=['off','owned','profile']; rounds=3; pairs=[('owned','off'),('profile','owned'),('profile','off')]
elif series=='paidliveentries':
    modes=['baseline','off','active']; rounds=3; pairs=[('off','baseline'),('active','off'),('active','baseline')]
else: raise ValueError(series)
targets=sys.argv[2:] or ['sqlite','main']
base=(d.parent/'source-current-study/parent.txt').read_text().strip()
out=d.parent/'perf/docs/measurements/window-native-tapes-2850-2026-11-21/pregraph/conditions/combined-producer-cost'/series
out.mkdir(parents=True,exist_ok=True)
raw=d/'raw/results'
def write(file,head,rows):
    with file.open('w') as f:
        w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(head);w.writerows(rows)
def rows(f):
    with f.open() as stream: return list(csv.DictReader(stream,delimiter='\t'))
for g in targets:
    p=raw/f'matrix-{series}-{g}'; dst=out/g; dst.mkdir(exist_ok=True)
    oracles=rows(p/'oracles.tsv')
    assert [r['mode'] for r in oracles]==['off','active'] and len({r['native sha256'] for r in oracles})==1
    graphs={r['mode']:r['graph sha256'] for r in oracles}
    assert int(oracles[1]['nodes'])<int(oracles[0]['nodes'])
    order=rows(p/'order.tsv');assert len(order)==4*rounds*len(modes)
    for k in ['wall','pmu']:
        for i in range(1,rounds+1):
            observed=[r['mode'] for r in order if r['series']==k and int(r['round'])==i]
            assert observed==observed[::-1] and sorted(observed)==sorted(modes*2)
    elf=(p/'stage-off.sha256').read_bytes()
    for mode in modes:
        for k in (('warnings','stage') if mode=='baseline' else ('oracle','warnings','stage')):
            assert (p/f'{k}-{mode}.sha256').read_bytes()==elf
        for ext in ('stdout','stderr'):
            assert (p/f'warnings-{mode}.{ext}').read_bytes()==(p/f'warnings-off.{ext}').read_bytes()
    rr=[];sm=[];values=defaultdict(list)
    for row in order:
        k,rd,pos,mode=row.values();stem=p/f'{k}-{rd}-{pos}'
        assert stem.with_suffix('.sha256').read_bytes()==elf
        if k=='pmu':
            stats={r[2]:float(r[0]) for r in csv.reader(stem.with_suffix('.perf').open()) if len(r)>=5 and r[4]=='100.00'}
            assert len(stats)==8
            data={'total cycles/token':(stats['cycles:u']+stats['cycles:k'])/dict(sqlite=716136,main=2433922)[g], 'user instructions':stats['instructions:u'],'minor page faults and other page faults':stats['page-faults']}
        else:
            text=stem.with_suffix('.wall').read_text();assert 'time-runs: done, 0 failed processes' in text
            data={'elapsed ms':float(re.search(r'^run 1 list 1.*?: ([\d.]+) ms wall',text,re.M)[1])}
        for key,val in data.items():
            values[mode,int(rd),key].append(val);rr.append([k,rd,pos,mode,key,val])
    for a,b in pairs:
        for key in dict.fromkeys(r[4] for r in rr):
            x=[st.mean(values[a,i,key]) for i in range(1,rounds+1)]
            y=[st.mean(values[b,i,key]) for i in range(1,rounds+1)]
            diff=[n-m for n,m in zip(x,y)]
            sm.append([a,b,key,st.median(x),st.median(y),st.median(diff),min(diff),max(diff),sum(n<0 for n in diff)])
            if key in ('elapsed ms','user instructions'): print(g,a,b,key,round(st.median(diff),4),sum(n<0 for n in diff))
    write(dst/'samples.tsv',['series','round','position','mode','metric','value'],rr)
    write(dst/'paired.tsv',['candidate','reference','metric','median candidate','median reference','median difference','minimum difference','maximum difference','lower rounds'],sm)
    shutil.copy(p/'oracles.tsv',dst)
    with tarfile.open(dst/'native-receipts.tar.xz','w:xz') as t:
        for f in sorted(p.iterdir()):
            if f.is_file() and f.suffix not in ('.lock','.graph','.native'):t.add(f,arcname=f.name)
with tarfile.open(out/'source-and-builds.tar.xz','w:xz') as t:
    for label in ['maincurrentd335','paidliveentries']:
        r=raw/label
        rev=(r/'revision.txt').read_text().splitlines()
        assert rev[0]==base
        if label=='paidliveentries':
            patch=d/'paidliveentries.patch'
            assert rev[1].split()[0]==hashlib.sha256(patch.read_bytes()).hexdigest()
            t.add(patch,arcname='paidliveentries.patch')
        else: assert len(rev)==1
        for name in ['revision.txt','compiler.sha256']:t.add(r/name,arcname='builds/'+label+'/'+name)
    for name in ['paidliveentries-one.sh','paidliveentries-config.sh','paidliveentries.sh','paidliveentries-record.py','paidliveentries-manifest.py']:
        t.add(d/name,arcname='tools/'+name)
