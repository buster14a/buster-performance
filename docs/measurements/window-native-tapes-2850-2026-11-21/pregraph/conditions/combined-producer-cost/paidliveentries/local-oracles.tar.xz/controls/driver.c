#include <stdio.h>
extern int run(int);extern unsigned trace;int main(void){for(int i=0;i<4096;i++){int value=run(i);printf("%d %u\n",value,trace);}return 0;}
