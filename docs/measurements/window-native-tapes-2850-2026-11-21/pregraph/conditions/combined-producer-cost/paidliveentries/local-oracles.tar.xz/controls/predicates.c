struct Pair {int x; int y;};
unsigned trace;
static int call(int a,int b){trace=trace*33u+(unsigned)a+5u;return a<b;}
int run(int n){struct Pair z={n%19,n%13};struct Pair *p=(n&4)?0:&z;int a=n%7-3,b=n%13-6,c=n%5-2;unsigned acc=0;trace=(unsigned)n;
if (a < b) {
#ifdef TEST_INVERT
acc ^= 13u;
#endif
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
for (int j=0;j<3;j++){if(j!=a && b<12) acc+=(unsigned)j;else break;}
switch(a & 3){case 0: acc+=2u;break;case 1: if(a<c)acc^=1u;break;default:acc*=3u;break;}
if (a == b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (a != b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (a + 2 < b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a & 7) == (b & 7)) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a < b && b < c) || c == a) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
switch(a & 3){case 0: acc+=2u;break;case 1: if(a<c)acc^=1u;break;default:acc*=3u;break;}
if (p && p->x == a) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (p && (*p).y < b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a < b && call(a, c)) || (b != 0 && call(b, a))) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a += 1) < b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
for (int j=0;j<3;j++){if(j!=a && b<12) acc+=(unsigned)j;else break;}
if ((a++ < b) && (p == 0 || p->x != c)) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
switch(a & 3){case 0: acc+=2u;break;case 1: if(a<c)acc^=1u;break;default:acc*=3u;break;}
if (p ? p->x < c : b < c) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (((void)call(a, b), a < c)) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((unsigned)a < (unsigned)b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (((a & 3) != 0) && (b < c || a == c)) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (a < b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
switch(a & 3){case 0: acc+=2u;break;case 1: if(a<c)acc^=1u;break;default:acc*=3u;break;}
if (a == b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (a != b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (a + 2 < b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
for (int j=0;j<3;j++){if(j!=a && b<12) acc+=(unsigned)j;else break;}
if ((a & 7) == (b & 7)) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a < b && b < c) || c == a) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
switch(a & 3){case 0: acc+=2u;break;case 1: if(a<c)acc^=1u;break;default:acc*=3u;break;}
if (p && p->x == a) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (p && (*p).y < b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a < b && call(a, c)) || (b != 0 && call(b, a))) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a += 1) < b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a++ < b) && (p == 0 || p->x != c)) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
switch(a & 3){case 0: acc+=2u;break;case 1: if(a<c)acc^=1u;break;default:acc*=3u;break;}
if (p ? p->x < c : b < c) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (((void)call(a, b), a < c)) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
for (int j=0;j<3;j++){if(j!=a && b<12) acc+=(unsigned)j;else break;}
if ((unsigned)a < (unsigned)b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (((a & 3) != 0) && (b < c || a == c)) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (a < b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
switch(a & 3){case 0: acc+=2u;break;case 1: if(a<c)acc^=1u;break;default:acc*=3u;break;}
if (a == b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (a != b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (a + 2 < b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a & 7) == (b & 7)) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a < b && b < c) || c == a) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
switch(a & 3){case 0: acc+=2u;break;case 1: if(a<c)acc^=1u;break;default:acc*=3u;break;}
if (p && p->x == a) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
for (int j=0;j<3;j++){if(j!=a && b<12) acc+=(unsigned)j;else break;}
if (p && (*p).y < b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a < b && call(a, c)) || (b != 0 && call(b, a))) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a += 1) < b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((a++ < b) && (p == 0 || p->x != c)) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
switch(a & 3){case 0: acc+=2u;break;case 1: if(a<c)acc^=1u;break;default:acc*=3u;break;}
if (p ? p->x < c : b < c) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (((void)call(a, b), a < c)) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if ((unsigned)a < (unsigned)b) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
if (((a & 3) != 0) && (b < c || a == c)) {
if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }
acc=acc*17u+(unsigned)call(c,a);
} else { a=b; acc^=(unsigned)b; }
if (a>b && a!=c) acc ^= (unsigned)(b+3);
return (int)((acc ^ trace) & 0x7fffffffu);
}
