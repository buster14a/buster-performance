"""Exercise sliced predicates next to selected bodies, side effects and chunk boundaries."""
import csv,hashlib,os,struct,subprocess
from pathlib import Path

d=Path(__file__).resolve().parent;out=d/'controls';out.mkdir(exist_ok=True)
w=d.parent;parent=w/'main-d335-clean/build/compiler';patch=d/'current.compiler'
clang='/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang'
source=out/'predicates.c';harness=out/'driver.c'
conditions=['a < b','a == b','a != b','a + 2 < b','(a & 7) == (b & 7)','(a < b && b < c) || c == a','p && p->x == a','p && (*p).y < b','(a < b && call(a, c)) || (b != 0 && call(b, a))','(a += 1) < b','(a++ < b) && (p == 0 || p->x != c)','p ? p->x < c : b < c','((void)call(a, b), a < c)','(unsigned)a < (unsigned)b','((a & 3) != 0) && (b < c || a == c)']
body=['struct Pair {int x; int y;};','unsigned trace;', 'static int call(int a,int b){trace=trace*33u+(unsigned)a+5u;return a<b;}', 'int run(int n){struct Pair z={n%19,n%13};struct Pair *p=(n&4)?0:&z;int a=n%7-3,b=n%13-6,c=n%5-2;unsigned acc=0;trace=(unsigned)n;']
for i,cond in enumerate(conditions*3):
 body+=['if ('+cond+') {']
 if i==0:body+=['#ifdef TEST_INVERT','acc ^= 13u;','#endif']
 body+=['if (b != c) { acc+=3u; if(a<c) b+=1; } else { acc^=7u; }','acc=acc*17u+(unsigned)call(c,a);','} else { a=b; acc^=(unsigned)b; }', 'if (a>b && a!=c) acc ^= (unsigned)(b+3);']
 if i%9==0:body+=['for (int j=0;j<3;j++){if(j!=a && b<12) acc+=(unsigned)j;else break;}']
 if i%5==0:body+=['switch(a & 3){case 0: acc+=2u;break;case 1: if(a<c)acc^=1u;break;default:acc*=3u;break;}']
body+=['return (int)((acc ^ trace) & 0x7fffffffu);','}'];source.write_text('\n'.join(body)+'\n')
harness.write_text('#include <stdio.h>\nextern int run(int);extern unsigned trace;int main(void){for(int i=0;i<4096;i++)printf("%d %u\\n",run(i),trace);return 0;}\n')
# Sequence the call and the read of trace, whose order of evaluation would otherwise be unspecified.
harness.write_text(harness.read_text().replace('printf("%d %u\\n",run(i),trace);','{int value=run(i);printf("%d %u\\n",value,trace);}'))
def h(x):return hashlib.sha256(x).hexdigest()
def execute(args,env):return subprocess.run(args,env=env,capture_output=True,timeout=90)
def sample(mode,flags,name,oracle):
 env=dict(os.environ);env.pop('BUSTER_SOURCE_CONDITION_PRODUCER',None)
 if mode=='active':env['BUSTER_SOURCE_CONDITION_PRODUCER']='1'
 for k in ('NODE_SOURCE_NATIVE_ORACLE','NODE_SOURCE_GRAPH_ORACLE'): env.pop(k,None)
 if oracle and mode in ('off','active'):
  env['NODE_SOURCE_NATIVE_ORACLE']=str(out/(name+'-'+mode+'.native'));env['NODE_SOURCE_GRAPH_ORACLE']=str(out/(name+'-'+mode+'.graph'))
 executable={'parent':parent,'off':patch,'active':patch,'clang':clang}[mode]
 obj=out/(name+'-'+mode+'.o')
 proc=execute([executable,'-std=c17',*flags,'-c',source,'-o',obj],env)
 assert proc.returncode==0,(mode,flags,proc.stderr[-2000:])
 link=out/(name+'-'+mode);subprocess.run([clang,harness,obj,'-o',link],check=True,capture_output=True)
 run=execute([link],env);assert run.returncode==0 and len(run.stdout.splitlines())==4096
 return proc.stdout,proc.stderr,obj.read_bytes(),run.stdout
with (out/'checks.tsv').open('w',buffering=1) as f:
 rows=csv.writer(f,delimiter='\t',lineterminator='\n');rows.writerow(['policy','mode','object sha256','stdout sha256','diagnostic sha256','4096-result sha256','nodes','arguments','native sha256'])
 for name,flags in {'default':[],'warnings':['-Wall','-Wextra'],'debug':['-g'],'changed':['-DTEST_INVERT']}.items():
  samples={m:sample(m,flags,name,True) for m in ('parent','off','active','clang')}
  assert samples['parent']==samples['active']==samples['off'],name
  assert samples['active'][3]==samples['clang'][3],name
  for m,record in samples.items():
   stem=out/(name+'-'+m);graph=stem.with_suffix('.graph');native=stem.with_suffix('.native')
   counts=struct.unpack('<4I',graph.read_bytes()[:16])[:2] if graph.exists() else ['','']
   rows.writerow([name,m,h(record[2]),h(record[0]),h(record[1]),h(record[3]),*counts,h(native.read_bytes()) if native.exists() else ''])
  assert (out/(name+'-active.native')).read_bytes()==(out/(name+'-off.native')).read_bytes()
  if name=='default':
   original=samples['active'][3]
   get=lambda m:struct.unpack('<I',(out/(name+'-'+m+'.graph')).read_bytes()[:4])[0]
   assert get('active')<get('off'),(get('active'),get('off'))
  if name=='changed':assert original!=samples['active'][3]
