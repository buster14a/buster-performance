from pathlib import Path
import csv,statistics,hashlib,struct,tarfile,collections,shutil
d=Path(__file__).resolve().parent
out=d.parent/'perf/docs/measurements/window-native-tapes-2850-2026-11-21/pregraph/conditions/combined-producer-cost'
out.mkdir(exist_ok=True,parents=True)
def write(name,head,rows):
 with (out/name).open('w') as f:
  w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(head);w.writerows(rows)
def sha(p):
 with p.open('rb') as b:return hashlib.file_digest(b,'sha256').hexdigest()
q=[]
for mode in ('off','keep','replace'):
 p=d/f'{mode}.graph'
 with p.open('rb') as f:n,a,_,_=struct.unpack('<4I',f.read(16))
 q.append([mode,n,a,*[sha(d/f'{mode}.{ext}') for ext in ['graph','native','o','out','err','patch','compiler']]])
assert q[0][3]==q[1][3] and q[1][1]-q[2][1]==12466 and all(x[4:8]==q[0][4:8] for x in q)
write('checks.tsv',['mode','nodes','arguments','graph','native','object','stdout','diagnostics','patch','binary'],q)
v=collections.defaultdict(list);samples=[];paired=[]
for f in sorted(d.glob('[1-5]-[0-5]-*.stat')):
 r,pos,mode=f.stem.split('-');e={x[2]:int(x[0]) for x in csv.reader(f.open()) if len(x)>=5 and x[4]=='100.00'};assert len(e)==4
 m=[e['instructions:u'],e['cycles:u'],e['cycles:k'],e['cycles:u']+e['cycles:k'],e['minor-faults']]
 for k,x in zip(['user instructions','user cycles','kernel cycles','total cycles','minor faults'],m):v[mode,r,k].append(x)
 samples.append([r,pos,mode,*m])
write('pmu.tsv',['round','position','mode','user instructions','user cycles','kernel cycles','total cycles','faults'],samples)
for row in csv.DictReader((d/'fresh-process-wall.tsv').open(),delimiter='\t'):
 assert row['checked_elf']=='1';v[row['mode'],row['round'],'wall ms'].append(int(row['ns'])/1e6)
shutil.copy(d/'fresh-process-wall.tsv',out)
for a,b in [('keep','off'),('replace','keep'),('replace','off')]:
 for k in ['user instructions','user cycles','kernel cycles','total cycles','minor faults','wall ms']:
  pairs=[]
  for i in range(1,6):
   av,bv=v[a,str(i),k],v[b,str(i),k];assert len(av)==len(bv)==2
   pairs.append(statistics.mean(av)-statistics.mean(bv))
  paired.append([a,b,k,statistics.median(pairs),min(pairs),max(pairs),sum(x<0 for x in pairs)])
write('paired.tsv',['candidate','reference','metric','median paired delta','minimum','maximum','lower rounds'],paired)
with tarfile.open(out/'source-and-receipts.tar.gz','w:gz') as t:
 for glob in ['*.patch','*.build','*.stat','*.py','*.sh']:
  for p in d.glob(glob):t.add(p,arcname=p.name)
 for n in ['condition-budget.py','condition-front.py','wrapper-range.py','solo.py']:
  t.add(d.parent/'source-condition-cost'/n,arcname='setup/'+n)
print([r for r in paired if r[2] in ('wall ms','total cycles','user instructions')])
