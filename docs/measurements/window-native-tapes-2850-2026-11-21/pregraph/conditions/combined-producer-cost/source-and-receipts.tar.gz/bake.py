from pathlib import Path
import sys,subprocess
d=Path(__file__).resolve().parent
src=d.parent/'source-condition-cost';tree=d.parent/'paid-families'
s=(src/'configure.py').read_text().replace('native-source-cost/src','paid-families/src').replace("['off','capture','take','bare']","['off','keep','replace']")
a="if mode=='take':flags.update(['NODE_SOURCE_CONSUME_CONDITION','NODE_SPLICE_ENABLE'])"
assert s.count(a)==1;s=s.replace(a,"""if mode!='off': flags.update(['NODE_SOURCE_CONSUME_CONDITION','NODE_SPLICE_ENABLE','NODE_SOURCE_CONSUME_BRANCH','NODE_SOURCE_LABELS','NODE_SOURCE_CONSUME_LABELS','NODE_SOURCE_CONSUME_POINTER','NODE_CROSS_UNINDEXED','NODE_SOURCE_CONSUME_FIXED_CALL','NODE_SOURCE_COMPACT_FAMILIES','NODE_SOURCE_COMPACT_LOGICAL','NODE_SOURCE_COMPACT_FIXED_CALL','NODE_FIXED_TYPE_ORDER'])
if mode=='replace': flags.update(['NODE_SOURCE_COMPACT','NODE_SOURCE_COMPACT_CONDITION','NODE_SOURCE_COMPACT_READ_CONDITION'])""")
a="  if key in flags:return";s=s.replace(a,"  if key in flags and key=='NODE_FIXED_TYPE_ORDER':return '((const char*)\"replay\")'\n  if key in flags and key=='NODE_SOURCE_COMPACT_FAMILIES':return '((const char*)\"scalar\")'\n"+a)
(d/'configure.py').write_text(s);mode=sys.argv[1];subprocess.run([sys.executable,str(d/'configure.py'),mode],cwd=tree,check=True)
if mode!='off':
 for name in ['condition-budget.py','condition-front.py']:
  subprocess.run([sys.executable,str(src/name)],cwd=tree,check=True)
 p=tree/'src/buster/compiler/c_check_expression_input.c';s=p.read_text();a='node_front_chunk_windowed(front, reader, kept_tokens, kept_classes, kept, &kept_identifiers, &kept_literals);\n        node_window_probe(front);'
 assert s.count(a)==1;p.write_text(s.replace(a,a.split(';')[0]+';'))
 for name in ['wrapper-range.py','solo.py']:subprocess.run([sys.executable,str(src/name)],cwd=tree,check=True)
