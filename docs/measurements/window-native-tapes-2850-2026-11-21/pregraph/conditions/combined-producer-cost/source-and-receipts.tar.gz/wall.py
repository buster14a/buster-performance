from pathlib import Path
import sys,time,subprocess,csv,hashlib,tempfile
d=Path(__file__).resolve().parent
expected=hashlib.sha256((d/'off.o').read_bytes()).digest()
with (d/'fresh-process-wall.tsv').open('w',buffering=1) as f,tempfile.TemporaryDirectory(dir=d) as p:
 w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['round','serial','mode','ns','checked_elf'])
 modes=['off','keep','replace']
 for rnd in range(5):
  seq=modes[rnd%3:]+modes[:rnd%3]
  for serial,mode in enumerate(seq+seq[::-1]):
   o=Path(p)/'result.o';o.unlink(missing_ok=True)
   start=time.perf_counter_ns()
   r=subprocess.run([str(d/(mode+'.compiler')),'--lanes','1','-c',*sys.argv[1:],'-o',str(o)],capture_output=True)
   end=time.perf_counter_ns()
   assert r.returncode==0 and not r.stderr and not r.stdout and hashlib.sha256(o.read_bytes()).digest()==expected,mode
   w.writerow([rnd+1,serial,mode,end-start,1])
