from pathlib import Path
import sys,re,shutil
here=Path(__file__).resolve().parent
root=here.parent/'paid-families/src/buster/compiler'
mode=sys.argv[1]; assert mode in ['off','keep','replace']
# Restore only files saved from our own pinned experiment.
saved=here/'original'; saved.mkdir(exist_ok=True)
names=['c_check_expression_input.c','c_check_input.c','c_check_node_census.c','c_check_node_machine_facts.c','c_check_node_machine_front.c','c_check_node_machine_reader.c','c_check_node_machine_rows.c','c_check_program.c','c_check_program_lower.c','c_checker_driver.c','c_types.c']
for name in names:
 p=root/name
 if not (saved/name).exists():shutil.copy(p,saved/name)
flags={'NODE_SPLICE_FRONT','NODE_SOURCE_CONDITION_ONLY','NODE_PROOF_NO_FP','NODE_PROOF_POINTERS','NODE_PROOF_CALLS','NODE_SOURCE_ROWS','NODE_PROOF_NATIVE','NODE_CROSS_TYPE_VIEW','NODE_CROSS_INCREMENTAL','NODE_CROSS_ARG_EPOCH','NODE_CROSS_FAST_REQUEST','NODE_SOURCE_STRINGS','NODE_SOURCE_CONDITION','NODE_SOURCE_CONDITION_ORIGINS','NODE_SOURCE_ORIGIN_PUBLISHERS'}
if mode!='off': flags.update(['NODE_SOURCE_CONSUME_CONDITION','NODE_SPLICE_ENABLE','NODE_SOURCE_CONSUME_BRANCH','NODE_SOURCE_LABELS','NODE_SOURCE_CONSUME_LABELS','NODE_SOURCE_CONSUME_POINTER','NODE_CROSS_UNINDEXED','NODE_SOURCE_CONSUME_FIXED_CALL','NODE_SOURCE_COMPACT_FAMILIES','NODE_SOURCE_COMPACT_LOGICAL','NODE_SOURCE_COMPACT_FIXED_CALL','NODE_FIXED_TYPE_ORDER'])
if mode=='replace': flags.update(['NODE_SOURCE_COMPACT','NODE_SOURCE_COMPACT_CONDITION','NODE_SOURCE_COMPACT_READ_CONDITION'])
if mode=='bare':flags={'NODE_SPLICE_FRONT'}
if mode=='off':flags=set()
for name in names:
 p=root/name;s=(saved/name).read_text()
 def switch(m):
  key=m[1]
  if key in ['NODE_SOURCE_NATIVE_ORACLE','NODE_SOURCE_GRAPH_ORACLE']:return m[0]
  if key=='NODE_CROSS_CHUNK' and mode!='off':return '((const char*)"n")'
  if key in flags and key=='NODE_FIXED_TYPE_ORDER':return '((const char*)"replay")'
  if key in flags and key=='NODE_SOURCE_COMPACT_FAMILIES':return '((const char*)"scalar")'
  if key in flags:return '((const char*)"1")'
  return '((const char*)0)'
 s=re.sub(r'getenv\("(NODE_[A-Z0-9_]+)"\)',switch,s)
 s=re.sub(r'fprintf\(stderr,\s*"(?=(?:cross-|source-(?:intern|rows|conditions)|node-proof |probe-(?:trace|full)|condition-(?:native|origin|fields|taken)|splice-(?:taken|local-class)))','if (0) fprintf(stderr,"',s)
 # Make the unused printf call a void expression. This retains the original nesting of if/else statements.
 if 'if (0) fprintf(stderr,' in s:
  s='#ifndef NODE_DISABLED_REPORT\n#define NODE_DISABLED_REPORT(...) ((void)(0 && fprintf(__VA_ARGS__)))\n#endif\n'+s.replace('if (0) fprintf(stderr,','NODE_DISABLED_REPORT(stderr,')
 p.write_text(s)
