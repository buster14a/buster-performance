from pathlib import Path
p=Path('src/buster/compiler/c_check_expression_input.c')
s=p.read_text()
a='''            while(start>through && reader->postorder_positions[tokens[start-1]]>=first)
                --start;
            if(start<end)'''
b='''            bool logical = false;
            while(start>through && reader->postorder_positions[tokens[start-1]]>=first)
            {
                const uint32_t action = tokens[--start];
                const uint8_t role = reader->parser->tree.roles[action];
                logical |= role == PARSE_ROLE_LOGICAL_AND || role == PARSE_ROLE_LOGICAL_OR;
            }
            if(start<end && logical)'''
assert s.count(a)==1
p.write_text(s.replace(a,b))
