from pathlib import Path
import csv,statistics,hashlib,struct,tarfile,collections,shutil
d=Path(__file__).resolve().parent
p=d.parent/'perf/docs/measurements/window-native-tapes-2850-2026-11-21/pregraph/conditions/paid-graph-removal'
p.mkdir(exist_ok=True,parents=True)
modes=('off','keep','replace','screen')
def read(p):return list(csv.DictReader(p.open(),delimiter='\t'))
def wr(name,headers,rows):
 with (p/name).open('w') as f:
  w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(headers);w.writerows(rows)
def sha(f):
 with f.open('rb') as b:return hashlib.file_digest(b,'sha256').hexdigest()
qual=[]
for m in modes:
 graph=d/(m+'.graph')
 with graph.open('rb') as f:n,a,v,c=struct.unpack('<4I',f.read(16))
 qual.append([m,n,a,*[sha(d/(m+'.'+ext)) for ext in ['graph','native','o','out','err','patch','compiler']]])
assert all(x[4:8]==qual[0][4:8] for x in qual) and qual[0][3]==qual[1][3]
wr('objects.tsv',['mode','nodes','arguments','graph','native','ELF','stdout','diagnostics','source patch','compiler'],qual)
stats=[]
values=collections.defaultdict(list)
for f in sorted(d.glob('[1-5]-[0-7]-*.stat')):
 r,s,m=f.stem.split('-');e={x[2]:int(x[0]) for x in csv.reader(f.read_text().splitlines()) if len(x)>4 and x[4]=='100.00'}
 assert len(e)==4
 v=[e['instructions:u'],e['cycles:u'],e['cycles:k'],e['cycles:u']+e['cycles:k'],e['minor-faults']]
 for k,t in zip(['instructions','user cycles','kernel cycles','total cycles','minor faults'],v):values[m,int(r),k].append(t)
 stats.append([r,s,m,*v])
wr('pmu.tsv',['round','position','mode','user instructions','user cycles','kernel cycles','total cycles','minor faults'],stats)
for row in read(d/'fresh-process-wall.tsv'):
 assert row['checked_elf']=='1'
 values[row['mode'],int(row['round']),'wall ms'].append(int(row['ns'])/1e6)
shutil.copy(d/'fresh-process-wall.tsv',p)
pairs=[]
for a,b in [('keep','off'),('replace','keep'),('screen','off'),('screen','replace')]:
 for metric in ['instructions','user cycles','kernel cycles','total cycles','minor faults','wall ms']:
  assert all(len(values[m,r,metric])==2 for m in (a,b) for r in range(1,6))
  ds=[statistics.mean(values[a,r,metric])-statistics.mean(values[b,r,metric]) for r in range(1,6)]
  pairs.append([a,b,metric,statistics.median(ds),min(ds),max(ds),sum(t<0 for t in ds)])
wr('paired.tsv',['candidate','reference','metric','median paired delta','minimum','maximum','lower rounds'],pairs)
profiles=[]
for m in modes:
 for ev in ['faults','instructions']:
  f=d/f'{m}-{ev}.samples';s=collections.Counter()
  for row in f.read_text().splitlines():
   col=row.split()
   if len(col)>=3 and col[0].isdigit():s[col[2]]+=int(col[0])
  profiles.extend([m,ev,k,t] for k,t in s.most_common())
wr('samples.tsv',['mode','event','sampled symbol','sum of periods'],profiles)
for m in ['off','screen']:shutil.copy(d/(m+'-clears.tsv'),p)
with tarfile.open(p/'source-and-receipts.tar.gz','w:gz') as t:
 for m in modes:
  for ext in ['patch','build']:
   t.add(d/(m+'.'+ext),arcname=m+'.'+ext)
 for name in ['run.sh','wall.py','configure.py','screen.py','sample.sh','count-clears.sh','count-clears.gdb','clear-sites.py','record-paid.py','off-clears.raw','screen-clears.raw']:
  t.add(d/name,arcname=name)
 for f in d.glob('[1-5]-[0-7]-*.stat'):t.add(f,arcname='pmu/'+f.name)
def delta(a,b,k):return next(row[3] for row in pairs if row[:3]==[a,b,k])
readme=f"""# What the source producer and graph replacement cost

Four separately compiled Release executables from Buster `84a7d3d76` produced the same SQLite ELF, native witness, stdout and diagnostics. Enabling the producer while keeping the graph added {delta('keep','off','instructions')/1e6:.2f} million user instructions and {delta('keep','off','total cycles')/1e6:.2f} million total cycles. Replacing the graph operands on that producer removed 2,750 nodes. It added {delta('replace','keep','instructions')/1e6:.2f} million instructions and {delta('replace','keep','total cycles')/1e6:.2f} million cycles. Screening logical operators at the parser narrowed the work and changed which chunks fit: 3,406 nodes disappeared, and compilation still took {delta('screen','off','total cycles')/1e6:.2f} million more cycles than the disabled build. [Matched objects and graph sizes](objects.tsv) · [Paired costs](paired.tsv)

A separate fresh-process clock measured median paired wall changes of {delta('keep','off','wall ms'):+.2f} ms for keeping the graph, {delta('replace','keep','wall ms'):+.2f} ms for replacing its operands, and {delta('screen','off','wall ms'):+.2f} ms for the lexical screen against the disabled build. All four images were run twice in each of five rounds for each measurement. The Ryzen 9 7940HS used the real frozen SQLite input and a single compilation lane. These are local costs of this implementation. The step 2 hardware gate uses the locked 9700X. [Fresh wall observations](fresh-process-wall.tsv) · [Raw PMU observations](pmu.tsv)

The screened build caused {delta('screen','off','minor faults'):,.1f} additional minor faults. A separate debugger run recorded the caller and byte count of each large clear in libc’s AVX-512 memset, with a 64 KiB threshold. The screened source path added 26,885,208 bytes of such writes in reader initialization and 5,729,096 bytes in the warning-selection pass. The largest two individual clears initialize a pointer slot per potential graph node (6,241,280 bytes) and per source token (5,729,096 bytes). These counts measure bytes written, including pages which were already resident. [Disabled clear sites](off-clears.tsv) · [Screened clear sites](screen-clears.tsv) · [Sampled instructions and faults](samples.tsv)

Each mode’s full patch applies independently at the source pin. The archive includes all four patches, build logs, individual PMU receipts and the debugger script. [Source and receipts](source-and-receipts.tar.gz)
"""
(p/'README.md').write_text(readme)
