#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
for m in off screen;do
 objdump -d --disassemble=__memset_avx512_unaligned_erms "$d/$m.compiler" | grep -Fq '<__memset_avx512_unaligned_erms+0xc5>' 
 gdb -q -batch -x "$d/count-clears.gdb" --args "$d/$m.compiler" --lanes 1 -c "${args[@]}" -o "$d/$m-clears.o" >"$d/$m-clears.raw" 2>&1
 cmp "$d/off.o" "$d/$m-clears.o"
done
