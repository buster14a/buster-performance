from pathlib import Path
import sys,subprocess
d=Path(__file__).resolve().parent;prev=d.parent/'source-condition-cost';mode=sys.argv[1]
# Reset only this diagnostic checkout's tracked edits to its source pin and reapply its published complete patch.
root=d.parent/'paid-conditions';args=['git','-C',str(root)]
subprocess.run(args+['restore','--worktree','.'],check=True)
subprocess.run(args+['apply',str(d.parent/'cross-chunk-study/logical-condition.patch')],check=True)
s=(prev/'configure.py').read_text().replace('native-source-cost/src/buster/compiler','paid-conditions/src/buster/compiler').replace("['off','capture','take','bare']","['off','keep','replace','screen']")
s=s.replace("if mode=='take':flags.update(['NODE_SOURCE_CONSUME_CONDITION','NODE_SPLICE_ENABLE'])","""if mode!='off':flags.update(['NODE_SOURCE_CONSUME_CONDITION','NODE_SPLICE_ENABLE','NODE_SOURCE_CONSUME_BRANCH','NODE_SOURCE_LABELS','NODE_SOURCE_CONSUME_LABELS','NODE_SOURCE_CONSUME_POINTER','NODE_CROSS_UNINDEXED'])
if mode in ('replace','screen'): flags.update(['NODE_SOURCE_COMPACT','NODE_SOURCE_COMPACT_CONDITION','NODE_SOURCE_COMPACT_READ_CONDITION','NODE_SOURCE_COMPACT_LOGICAL'])""")
(d/'bake.py').write_text(s);subprocess.run([sys.executable,str(d/'bake.py'),mode],cwd=root,check=True)
if mode!='off':
 for name in ['condition-budget.py','condition-front.py']:
  subprocess.run([sys.executable,str(prev/name)],cwd=root,check=True)
 p=root/'src/buster/compiler/c_check_expression_input.c';s=p.read_text()
 a='node_front_chunk_windowed(front, reader, kept_tokens, kept_classes, kept, &kept_identifiers, &kept_literals);\n        node_window_probe(front);'
 assert s.count(a)==1;p.write_text(s.replace(a,a.split(';')[0]+';'))
 for name in ['wrapper-range.py','solo.py']:subprocess.run([sys.executable,str(prev/name)],cwd=root,check=True)

if mode=="screen": subprocess.run([sys.executable,str(d/"screen.py")],cwd=root,check=True)
