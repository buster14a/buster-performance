#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../paid-conditions
export PATH="/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH"
for mode in off keep replace screen;do
 python3 "$d/configure.py" "$mode";git diff --binary >"$d/$mode.patch"
 ./build.sh --config Release >"$d/$mode.build" 2>&1;cp build/compiler "$d/$mode.compiler"
done
cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
for mode in off keep replace screen;do
 f=$d/$mode
 NODE_SOURCE_GRAPH_ORACLE="$f.graph" NODE_SOURCE_NATIVE_ORACLE="$f.native" "$d/$mode.compiler" --lanes 1 -c "${args[@]}" -o "$f.o" >"$f.out" 2>"$f.err"
 for ext in native o out err;do cmp "$d/off.$ext" "$f.$ext";done
done
cmp "$d/off.graph" "$d/keep.graph"
python3 - "$d" <<'PY'
from pathlib import Path
import struct,sys
d=Path(sys.argv[1]);v={}
for m in ['off','keep','replace','screen']:
 with (d/(m+'.graph')).open('rb') as f:v[m]=struct.unpack('<4I',f.read(16))
print(v);assert min(v['keep'][0]-v[m][0] for m in ['replace','screen'])>0
PY
for r in {1..5};do
 m=(off keep replace screen screen replace keep off);if [[ $r == 2 || $r == 4 ]];then m=(replace screen off keep keep off screen replace);fi
 j=0
 for mode in "${m[@]}";do
  f=$d/$r-$j-$mode;j=$((j+1))
  perf stat -x, -o "$f.stat" -e instructions:u,cycles:u,cycles:k,minor-faults -- "$d/$mode.compiler" --lanes 1 -c "${args[@]}" -o "$d/timed.o" >"$f.out" 2>"$f.err"
  cmp "$d/off.o" "$d/timed.o"
 done
done
sed "s/'off','capture','take','filtered','front'/'off','keep','replace','screen'/;s/pre-off.o/off.o/" "$d/../source-condition-cost/standalone-wall.py" >"$d/wall.py"
python3 "$d/wall.py" "${args[@]}"
