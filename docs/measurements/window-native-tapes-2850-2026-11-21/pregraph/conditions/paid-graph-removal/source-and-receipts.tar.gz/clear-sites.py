from pathlib import Path
import csv,subprocess,collections
d=Path(__file__).resolve().parent
allm={}
for mode in ['off','screen']:
 entries=[]
 for row in (d/(mode+'-clears.raw')).read_text().splitlines():
  if not row.startswith('CLEAR\t'):continue
  _,pc,v,n,size=row.split('\t')
  loc=subprocess.check_output(['addr2line','-e',str(d/(mode+'.compiler')),'-f','-i',pc],text=True).splitlines()
  stack=' < '.join(f'{func} ({Path(path).name.split(" ")[0]})' for func,path in zip(loc[::2],loc[1::2]))
  entries.append((stack,int(v),int(n),int(size)))
 with (d/(mode+'-clears.tsv')).open('w') as f:
  w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(['source stack','fill byte','calls','bytes']);w.writerows(entries)
 allm[mode]=collections.Counter()
 for stack,v,n,size in entries:allm[mode][stack.split(' (')[0]]+=size
print('screen minus off, bytes written in individual memset calls >=64 KiB')
for k,v in (allm['screen']-allm['off']).most_common(20):print(k,v)
