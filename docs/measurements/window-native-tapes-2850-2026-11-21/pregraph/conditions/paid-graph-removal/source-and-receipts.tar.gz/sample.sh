#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../switch-inputs;source ../switch-local-args.sh;eval "args=($sqlite_arguments)"
for mode in off screen keep replace;do
 for measure in instructions faults;do
  event=instructions:u;period=179993;[[ $measure != faults ]] || { event=minor-faults;period=19; }
  file=$d/$mode-$measure
  perf record -q -o "$file.data" -e "$event" -c "$period" -- "$d/$mode.compiler" --lanes 1 -c "${args[@]}" -o "$d/sample.o" >"$file.out" 2>"$file.err"
  cmp "$d/off.o" "$d/sample.o"
  perf script -i "$file.data" -F period,ip,sym,dso >"$file.samples" 2>"$file.decode"
 done
done
