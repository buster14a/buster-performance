set pagination off
set confirm off
set debuginfod enabled off
set print thread-events off
python
import collections,gdb
clears=collections.Counter()
calls=collections.Counter()
class ClearSite(gdb.Breakpoint):
 def stop(self):
  size=int(gdb.parse_and_eval('$rdx'))
  if size>=65536:
   pc=int(gdb.parse_and_eval('*(unsigned long *)$rsp'))-1
   value=int(gdb.parse_and_eval('$rsi')) & 255
   key=(pc,value)
   clears[key]+=size
   calls[key]+=1
  return False
ClearSite('*__memset_avx512_unaligned_erms+0x7a',internal=True)
ClearSite('*__memset_avx512_unaligned_erms+0xc5',internal=True)
end
run
python
for key,total in clears.most_common():
 pc,value=key
 print("CLEAR\t%x\t%d\t%d\t%d"%(pc,value,calls[key],total))
end
