declare -a modes=(baseline off mark route on) metrics=(pmu wall)
declare -A binary=([baseline]=expr74f [off]=visitcmp [mark]=visitcmp [route]=visitcmp [on]=visitcmp)
round_count=5
