declare -a modes=(baseline off on) metrics=(pmu wall)
declare -A binary=([baseline]=expr74f [off]=cmpdriver [on]=cmpdriver)
round_count=5
