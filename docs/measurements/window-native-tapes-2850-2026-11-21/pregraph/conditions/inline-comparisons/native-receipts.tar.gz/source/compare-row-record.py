from pathlib import Path
import csv,re,statistics as s,collections,tarfile,hashlib
d=Path(__file__).resolve().parent;w=d.parent;base=d/'raw/results';out=w/'perf/docs/measurements/window-native-tapes-2850-2026-11-21/pregraph/conditions/inline-comparisons';out.mkdir(exist_ok=True,parents=True)
observed=[];pairs=[];proof=[]
for exe in ['cmpdriver','visitcmp']:
 for group,tokens in [('sqlite',716136),('main',2433922)]:
  p=base/f'matrix-{exe}-{group}';dct=collections.defaultdict(list);order=list(csv.DictReader((p/'order.tsv').open(),delimiter='\t'))
  modes=['baseline','off','on'] if exe=='cmpdriver' else ['baseline','off','mark','route','on']
  assert len(order)==5*len(modes)*2*2
  witness=(p/'oracle-on.stderr').read_text().strip();m=re.fullmatch(r'compare-positions proposed=(\d+) published=(\d+) graph=(\d+) rows=(\d+)',witness);assert m;proof.append([exe,group,*m.groups()])
  elf=(p/'stage-baseline.sha256').read_text()
  for kind in ['stage','warnings']:
   for m in modes:assert (p/(kind+'-'+m+'.sha256')).read_text()==elf
  for x in order:
   kind,rd,pos,m=x.values();f=p/f'{kind}-{rd}-{pos}'
   assert f.with_suffix('.sha256').read_text()==elf
   if kind=='wall': vals={'wall ms':float(re.search(r'median ([\d.]+) ms wall',f.with_suffix('.wall').read_text())[1])}
   else:
    rows=[c for c in csv.reader(f.with_suffix('.perf').read_text().splitlines()) if len(c)>=5];assert all(c[4]=='100.00' for c in rows);e={c[2]:float(c[0]) for c in rows}
    vals={'cycles/token':(e['cycles:u']+e['cycles:k'])/tokens,'user instructions':int(e['instructions:u']),'minor faults':int(e['page-faults'])}
   for k,t in vals.items():dct[int(rd),m,k].append(t);observed.append([exe,group,kind,rd,pos,m,k,t])
  for m,b in ([('on','baseline'),('on','off'),('off','baseline')] if exe=='cmpdriver' else [('mark','off'),('route','mark'),('on','route'),('on','off'),('on','baseline')]):
   for metric in ['cycles/token','user instructions','wall ms','minor faults']:
    delta=[s.mean(dct[i,m,metric])-s.mean(dct[i,b,metric]) for i in range(1,6)];pairs.append([exe,group,m,b,metric,s.median(delta),min(delta),max(delta),sum(v<0 for v in delta)])
for file,h,ls in [('observations.tsv',['representation','input','series','round','position','mode','metric','value'],observed),('paired.tsv',['representation','input','candidate','reference','metric','median','min','max','lower rounds'],pairs),('native-coverage.tsv',['representation','input','candidate positions','predicates emitted','remaining graph','native rows emitted'],proof)]:
 with (out/file).open('w') as f:a=csv.writer(f,delimiter='\t',lineterminator='\n');a.writerow(h);a.writerows(ls)
for row in pairs:
 if row[2:5] in [['on','baseline','cycles/token'],['on','off','wall ms'],['on','off','cycles/token'],['mark','off','cycles/token'],['route','mark','cycles/token'],['on','route','cycles/token']]:print(*row[:5],round(row[5],3),row[8])
with tarfile.open(out/'native-receipts.tar.gz','w:gz') as t:
 for ex in ['cmpdriver','visitcmp']:
  for group in ['sqlite','main']:
   f=base/f'matrix-{ex}-{group}'
   for r in sorted(f.glob('*')):
    if r.is_file():t.add(r,arcname=ex+'/'+group+'/'+r.name)
 for ex in ['expr74f','visitcmp','cmpdriver']:
  for f in ['revision.txt','compiler.sha256']:t.add(base/ex/f,arcname='builds/'+ex+'/'+f)
 for name in ['visitcmp.patch','cmpdriver.patch','expr74f.patch','visitcmp-one.sh','visitcmp.sh','visitcmp-config.sh','cmpdriver-one.sh','cmpdriver.sh','cmpdriver-config.sh','compare-row-record.py']:t.add(d/name,arcname='source/'+name)
