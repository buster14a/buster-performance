#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../visit-comparisons
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
git diff --binary >"$d/driver.patch"
./build.sh >"$d/driver.build" 2>&1
cp ../buster/build/predefines.h build/predefines.h
NODE_COMPARE_ROWS=take NODE_COMPARE_REPORT=1 build/compiler --lanes 1 -c "$d/fixture.c" -o "$d/driver.o" >"$d/driver.out" 2>"$d/driver.err"
rg -q 'published=[1-9]' "$d/driver.err"
"$PWD/../expression-profile/build/compiler" --lanes 1 -c "$d/fixture.c" -o "$d/direct-parent.o"
cmp "$d/direct-parent.o" "$d/driver.o"
bash "$d/finish.sh"
