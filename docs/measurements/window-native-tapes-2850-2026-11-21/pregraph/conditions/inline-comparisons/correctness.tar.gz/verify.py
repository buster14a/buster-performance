from pathlib import Path
import re,csv,tarfile,subprocess
d=Path(__file__).resolve().parent;w=d.parent
out=w/'perf/docs/measurements/window-native-tapes-2850-2026-11-21/pregraph/conditions/inline-comparisons'
with tarfile.open(out/'correctness.tar.gz','w:gz') as tar:
 for study in ['fused-comparison-study','visit-comparison-study']:
  src=w/study
  checks=[]
  for i in range(1,9):
   p=src/f'checker-{i}.log';m=re.search(r'test-checker: (\d+) checks, 0 failures\s*$',p.read_text());assert m,(study,i)
   checks.append(int(m[1]));tar.add(p,arcname=study+'/'+p.name)
  count=0
  for group,n in [('sqlite',1),('main',1),('lua',34),('musl',1336)]:
   p=src/(group+'.tsv');a=list(csv.DictReader(p.open(),delimiter='\t'));assert len(a)==3*n and all(x['same']=='1' and x['code']=='0' for x in a);count+=len(a)
   tar.add(p,arcname=study+'/'+p.name)
  print(study,sum(checks),count)
  for name in ['driver.patch','driver.build','fixture.c','driver.err','finish.sh',('driver-qualification.sh' if study=='fused-comparison-study' else 'run.sh')]:
   tar.add(src/name,arcname=study+'/'+name)
 tar.add(d/'compare-row-qual.py',arcname='verify.py')
