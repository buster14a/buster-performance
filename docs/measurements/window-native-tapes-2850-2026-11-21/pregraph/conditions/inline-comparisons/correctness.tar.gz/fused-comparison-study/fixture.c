int condition_a(int x, int y) {
    if (x < y) return y-3;
    if (x >= 7) return x-2;
    while (8 == y) y--;
    if (x != y) return x+6;
    if ((x >= y)) return x-9;
    return y+13;
}
