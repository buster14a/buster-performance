#!/bin/bash
set -eu
cd "$(dirname "$0")"; d=$PWD; cd ../fused-comparisons
export PATH="/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH"
test -x build/compiler
cp ../buster/build/predefines.h build/predefines.h
new=$PWD/build/compiler;base=$PWD/../expression-profile/build/compiler
unset NODE_COMPARE_ROWS NODE_COMPARE_REPORT
cd ../switch-inputs; source ../switch-local-args.sh
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
cd "$d/../fused-comparisons"
export NODE_COMPARE_ROWS=take
for shard in {1..8};do "$new" test-checker --seed 2850 --part "$shard/8" >"$d/checker-$shard.log" 2>&1;done
cd "$d/../switch-inputs"
for g in sqlite main lua musl;do v=${g}_arguments;eval "args=(${!v})";python3 "$d/../default-object-qa/pair.py" "$d" "$g" "$base" "$new" "${args[@]}";done
