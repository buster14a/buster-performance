struct R { int n; unsigned bit:3; }; extern int global;
int f(int *p,int x){do {--x;}while(p[x]!=0);return x;}
