struct R { int n; unsigned bit:3; }; extern int global;
#pragma GCC diagnostic warning "-Wuninitialized"
int f(int *p,int x){if(_Generic(x,int:*p==x,default:0))return 1;return 0;}
