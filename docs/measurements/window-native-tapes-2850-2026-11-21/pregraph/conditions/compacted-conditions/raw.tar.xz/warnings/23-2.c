struct R { int n; unsigned bit:3; }; extern int global;
#pragma GCC diagnostic error "-Wunused-parameter"
int f(int *restrict p,const int x){if(*p==x)return x;return 0;}
