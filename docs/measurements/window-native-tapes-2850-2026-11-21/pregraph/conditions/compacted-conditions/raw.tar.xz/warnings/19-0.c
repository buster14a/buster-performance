struct R { int n; unsigned bit:3; }; extern int global;
int f(int *p,int x){if(x){}else if(p[x]==0)return x;return 0;}
