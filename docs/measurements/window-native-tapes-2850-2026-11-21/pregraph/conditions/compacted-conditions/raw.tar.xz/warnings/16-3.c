struct R { int n; unsigned bit:3; }; extern int global;
#pragma GCC diagnostic ignored "-Wuninitialized"
int f(int *p,int x){do {--x;}while(p[x]!=0);return x;}
