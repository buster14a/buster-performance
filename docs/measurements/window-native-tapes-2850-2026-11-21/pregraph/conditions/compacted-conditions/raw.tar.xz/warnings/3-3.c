struct R { int n; unsigned bit:3; }; extern int global;
#pragma GCC diagnostic ignored "-Wuninitialized"
int f(struct R *p,int x){if(p->bit==x) return 1;return 0;}
