struct R { int n; unsigned bit:3; }; extern int global;
int f(_Atomic(int) *p,int x){if(*p==x) return 1;return 0;}
