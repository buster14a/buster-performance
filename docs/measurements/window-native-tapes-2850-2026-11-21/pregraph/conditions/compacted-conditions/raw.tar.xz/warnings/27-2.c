struct R { int n; unsigned bit:3; }; extern int global;
#pragma GCC diagnostic error "-Wunused-parameter"
int f(int *p,int x){if(*p==x) return zzz;return 0;}
