struct R { int n; unsigned bit:3; }; extern int global;
#pragma GCC diagnostic warning "-Wuninitialized"
int f(int *p,int x){int *q=p+1; if(*q==x) return 1; return 0;}
