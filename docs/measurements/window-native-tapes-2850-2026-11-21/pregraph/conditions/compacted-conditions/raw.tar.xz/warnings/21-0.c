struct R { int n; unsigned bit:3; }; extern int global;
int f(int *p,int x){if(sizeof(*p==x))return 1;return 0;}
