struct R { int n; unsigned bit:3; }; extern int global;
int f(int *p,int x){if(0){if(*p==x)return 1;}return 0;}
