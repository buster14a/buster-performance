struct R { int n; unsigned bit:3; }; extern int global;
int f(int *p,int x){int *q=p+1; if(*q==x) return 1; return 0;}
