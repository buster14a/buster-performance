struct R { int n; unsigned bit:3; }; extern int global;
#pragma GCC diagnostic error "-Wunused-parameter"
int f(int x){int *p;if(*p==x) return 1;return 0;}
