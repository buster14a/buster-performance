struct R { int n; unsigned bit:3; }; extern int global;
int f(int *p,int x){ if (p[x]==x) return 1; return 0;}
