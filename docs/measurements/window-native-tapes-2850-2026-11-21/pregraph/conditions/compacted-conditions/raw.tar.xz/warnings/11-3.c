struct R { int n; unsigned bit:3; }; extern int global;
#pragma GCC diagnostic ignored "-Wuninitialized"
static int z; int f(int *p,int x){if(*p==z)return 1;return 0;}
