struct R { int n; unsigned bit:3; }; extern int global;
#pragma GCC diagnostic ignored "-Wuninitialized"
int f(int *p,int x){if(*p==(1u<<32))return x;return 0;}
