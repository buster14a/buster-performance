struct R { int n; unsigned bit:3; }; extern int global;
int f(int *p,int x){if(*p==x) return zzz;return 0;}
