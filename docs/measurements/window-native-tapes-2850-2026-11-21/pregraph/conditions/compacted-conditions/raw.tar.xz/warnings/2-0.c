struct R { int n; unsigned bit:3; }; extern int global;
int f(struct R *p,int x){if(p->n==x) return 1;return 0;}
