struct R { int n; unsigned bit:3; }; extern int global;
int f(int *p,int x){int y;if(x)y=3;if(*p==y)return 1;return 0;}
