struct R { int n; unsigned bit:3; }; extern int global;
int f(int *p,int x){for(;*p!=x;++p){}return x;}
