struct R { int n; unsigned bit:3; }; extern int global;
#pragma GCC diagnostic warning "-Wuninitialized"
int f(int x){struct R *p;if(p->n==x) return 1;return 0;}
