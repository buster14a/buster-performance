struct R { int n; unsigned bit:3; }; extern int global;
int f(int **p,int *q){if(*p==q)return 1;return 0;}
