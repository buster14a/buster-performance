#include <stdio.h>
struct Pair { int skip; int field; int end; };
extern int branches(const struct Pair*,const int*,int,int,int);
int main(void) {
    struct Pair p={3,1,2};
    const int a[32]={2,1,0,1,2,0,1,2};
    unsigned long long value=0;
    for(int x=0;x<4;++x)for(int y=0;y<3;++y)for(int z=0;z<3;++z)
        value=value*65599u+(unsigned)branches(&p,a,x,y,z);
    printf("%llu\n",value);
    return 0;
}
