struct Pair { int skip; int field; int end; };
int branches(const struct Pair *p, const int *a, int x, int y, int z) {
    int r=0;
    if ((x || y) && z) r+=1;
    if ((x && y) || z) r+=2;
    if (a[x] == y) r+=4;
    if (p->field == z) r+=8;
    if (a[x] != z && (x || y)) r+=16;
    return r;
}
