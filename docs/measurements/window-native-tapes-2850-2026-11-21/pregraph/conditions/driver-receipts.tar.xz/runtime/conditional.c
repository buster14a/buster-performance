struct fields { signed char tag; unsigned bits; int distance; };
int global;
int evaluate(struct fields *p, int *a, int x, int y) {
    int score = 0;
    if (x != y) score += 1;
    if ((unsigned)x < p->bits) score += 2;
    if (p->tag >= 0) score += 4;
    if ((long)p->distance == (long)x) score += 8;
    if (a[(unsigned)x & 1] == y) score += 16;
    if (global && (p->distance < y || !p->tag)) score += 32;
    while (x < y) { ++x; score += 64; }
    do { ++score; } while (y-- > 1 && global);
    return score;
}
