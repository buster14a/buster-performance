#include <stdio.h>
struct fields { signed char tag; unsigned bits; int distance; };
extern int global;
extern int evaluate(struct fields *, int *, int, int);
int main(void) {
    int a[] = { 3, -2 };
    unsigned long long digest = 0;
    for(int tag=-1;tag<2;tag++)
      for(int distance=-2;distance<5;distance++)
        for(unsigned bits=0;bits<5;bits++)
          for(global=0;global<2;global++)
            for(int x=-2;x<=4;x++)
              for(int y=-3;y<=4;y++) {
                struct fields p={(signed char)tag,bits,distance};
                digest = digest * 65599u + (unsigned)evaluate(&p,a,x,y);
              }
    printf("%llu\n",digest);
}
