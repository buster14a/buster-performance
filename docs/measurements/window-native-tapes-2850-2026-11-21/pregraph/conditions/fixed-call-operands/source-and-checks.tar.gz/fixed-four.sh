#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD
cd ../switch-inputs;source ../switch-local-args.sh
tree=$PWD/../pregraph-warning-study/compiler-source
main_arguments="-march=native -I$tree/src -fwrapv -funsigned-char --predefines $PWD/../proof-predefines.h $tree/src/buster/compiler/main.c"
export NODE_SOURCE_COMPACT_FIXED_CALL=1 NODE_SOURCE_CONSUME_FIXED_CALL=1 NODE_FIXED_TYPE_ORDER=replay
for g in fixture lua sqlite main musl;do
 if [[ $g == fixture ]];then args=("$d/single-calls.c" "$d/independent-runtime/probe.c" "$d/condition-runtime/conditional.c");else v=${g}_arguments;eval "args=(${!v})";fi
 python3 "$d/fixed-corpus.py" "$d/fixed-corpus" "$d/fixed-type-order.compiler" "$g" "${args[@]}"
done
