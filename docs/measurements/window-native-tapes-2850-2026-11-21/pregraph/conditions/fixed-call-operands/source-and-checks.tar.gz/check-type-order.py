from pathlib import Path
import re,sys,subprocess,os,json
p=Path(__file__).resolve().parent
cc=Path(sys.argv[1]).resolve()
e={**os.environ,'NODE_SOURCE_COMPACT_FIXED_CALL':'1','NODE_SOURCE_CONSUME_FIXED_CALL':'1','NODE_SOURCE_COMPACT_READ_CONDITION':'1','cc':str(cc),'d':str(p)}
s=(p/'check-source-calls.sh').read_text()
for i in ['known','replay']:
 here=p/('fixed-type-'+i)
 f=p/('check-type-'+i+'.sh');f.write_text(s.replace('source-fixed-reads',here.name))
 subprocess.run(['bash',f],env={**e,'NODE_FIXED_TYPE_ORDER':i},cwd=p,check=True)
 for case in sorted(here.glob('*')):
  if not (case/'graph.json').exists():print('FAILED',case,[x.read_text() for x in case.glob('*.status')]);continue
  x=json.loads((case/'graph.json').read_text())
  print(case.name,x['operands'],x['removed'],x['mismatches'],flush=True)
 if i=='replay':
  env={**os.environ,'NODE_FIXED_TYPE_ORDER':i}
  subprocess.run(['bash','fixed-call-check.sh',cc,p/'fixed-replay-runtime'],env=env,cwd=p,check=True)
  subprocess.run([sys.executable,'fixed-call-grid.py',cc,p/'fixed-replay-policies'],env=env,cwd=p,check=True)
