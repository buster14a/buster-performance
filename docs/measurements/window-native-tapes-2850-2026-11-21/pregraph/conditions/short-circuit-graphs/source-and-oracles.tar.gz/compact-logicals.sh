#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../type-links
export PATH="/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH"
python3 "$d/compact-logicals.py" "$PWD"
git diff --binary 84a7d3d76 >"$d/logical-condition.patch"
./build.sh >"$d/logical-condition.build" 2>&1;cp build/compiler "$d/logical-condition.compiler"
cd "$d"
sed -n '/^cd ..\/switch-inputs/,$p' compact-conditions.sh | sed 's/physically-compact/logical-reads/g' >check-logical-reads.sh
cc=$d/logical-condition.compiler;export d cc NODE_SOURCE_COMPACT_READ_CONDITION=1 NODE_SOURCE_COMPACT_LOGICAL=1
bash check-logical-reads.sh
