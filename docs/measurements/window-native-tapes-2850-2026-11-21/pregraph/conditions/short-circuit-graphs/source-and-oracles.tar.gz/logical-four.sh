#!/bin/bash
set -eu
cd "$(dirname "$0")";export NODE_SOURCE_COMPACT_LOGICAL=1
sed 's/compact-corpus"/logical-corpus"/;s/read-condition.compiler/logical-condition.compiler/' compact-four.sh >logical-command.sh
bash logical-command.sh
