from pathlib import Path
import sys
d=Path(sys.argv[1])/'src/buster/compiler'
def rep(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)
p=d/'c_check_node_census.c';s=p.read_text()
s=rep(s,'    if (!(front->ops[top]>=CHECK_OP_LESS && front->ops[top]<=CHECK_OP_NOT_EQUAL)) return false;', '''    const bool branch_mode=getenv("NODE_SOURCE_COMPACT_LOGICAL")!=NULL;
    const bool branched=branch_mode && (front->ops[top]==CHECK_OP_LOGICAL_AND || front->ops[top]==CHECK_OP_LOGICAL_OR);
    if (branch_mode ? !branched : !(front->ops[top]>=CHECK_OP_LESS && front->ops[top]<=CHECK_OP_NOT_EQUAL)) return false;''')
s=rep(s,'        memory|=load;', '''        const bool compare=op>=CHECK_OP_LESS && op<=CHECK_OP_NOT_EQUAL;
        const bool logical=op==CHECK_OP_LOGICAL_AND || op==CHECK_OP_LOGICAL_OR;
        if(branched && logical)
        {
            const uint32_t dl=front->window_left[x],dr=front->window_right[x];
            if(!dl || !dr || dl>x || dr>x || ((rec->standing>>2)&7)!=CHECK_CONSTANT_NONE ||
               rec->type!=BUSTER_TYPE_INT) return false;
            const NodeFactsRecord* first=state->proof_records+(x-dl);
            const NodeFactsRecord* next=state->proof_records+(x-dr);
            if(((first->standing>>2)&7)!=CHECK_CONSTANT_NONE || ((next->standing>>2)&7)!=CHECK_CONSTANT_NONE ||
               ((first->flags|next->flags)&(BUSTER_CHECK_NONNULL_ADDRESS|BUSTER_CHECK_SIDE_EFFECT))!=0 ||
               (first->object && (first->standing&3u)==CHECK_RVALUE) || (next->object && (next->standing&3u)==CHECK_RVALUE)) return false;
        }
        memory|=load;''')
s=rep(s,'x==top || load || literal_or_name || simple','x==top || load || literal_or_name || simple || (branched && (logical || compare))')
s=rep(s,'    return memory;\n}', '    return memory || branched;\n}')
s=rep(s,'const bool memory=condition && (kind==BUSTER_TYPED_CONVERT', '''const bool branch=condition && getenv("NODE_SOURCE_COMPACT_LOGICAL") &&
            (kind==BUSTER_TYPED_BRANCH_TRUE || kind==BUSTER_TYPED_BRANCH_FALSE);
        const bool memory=branch || (condition && (kind==BUSTER_TYPED_CONVERT''')
s=rep(s,'(kind==BUSTER_TYPED_PTR_ADD && row->value));','(kind==BUSTER_TYPED_PTR_ADD && row->value)));')
s=rep(s,'op==CHECK_OP_SUBSCRIPT || op==CHECK_OP_DEREFERENCE || op==CHECK_OP_ARROW);','op==CHECK_OP_SUBSCRIPT || op==CHECK_OP_DEREFERENCE || op==CHECK_OP_ARROW ||\n            (getenv("NODE_SOURCE_COMPACT_LOGICAL") && (op==CHECK_OP_LOGICAL_AND || op==CHECK_OP_LOGICAL_OR)));')
p.write_text(s)
p=d/'c_check_program_lower.c';s=p.read_text()
s=rep(s,'    const bool short_circuit = condition && check_lower_branch_condition(program,node);','''    bool captured_branch=false;
    if(condition && tape->compact_node && getenv("NODE_SOURCE_COMPACT_LOGICAL"))
        for(uint32_t i=0;i<tape->count;++i)
            captured_branch|=tape->entries[i].kind==BUSTER_TYPED_BRANCH_FALSE || tape->entries[i].kind==BUSTER_TYPED_BRANCH_TRUE;
    const bool short_circuit = condition && (captured_branch || check_lower_branch_condition(program,node));''')
p.write_text(s)
