struct R { unsigned bit:2; }; extern int foo(int);
int f(int x,int y,int z){while(x<y && y!=z)++x;return x;}
