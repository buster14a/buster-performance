struct R { unsigned bit:2; }; extern int foo(int);
int f(int x,int y,int z,int *p,volatile int *v,_Atomic(int) *a,struct R *r){int q;if(p && ++*p) return 1; return 0;}
