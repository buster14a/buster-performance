struct R { unsigned bit:2; }; extern int foo(int);
#pragma GCC diagnostic error "-Wunused-parameter"
int f(int x,int y,int z){for(;x<y && y!=z;++x){}return x;}
