struct R { unsigned bit:2; }; extern int foo(int);
#pragma GCC diagnostic warning "-Wuninitialized"
int f(int x,int y,int z,int *p,volatile int *v,_Atomic(int) *a,struct R *r){int q;if(x && *p) return 1; return 0;}
