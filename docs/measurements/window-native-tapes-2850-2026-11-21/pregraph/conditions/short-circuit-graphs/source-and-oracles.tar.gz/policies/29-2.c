struct R { unsigned bit:2; }; extern int foo(int);
#pragma GCC diagnostic error "-Wunused-parameter"
int f(int x,int y,int z){do{++x;}while(x<y || y==z);return x;}
