struct R { unsigned bit:2; }; extern int foo(int);
#pragma GCC diagnostic ignored "-Wuninitialized"
int f(int x,int y,int z,int *p,volatile int *v,_Atomic(int) *a,struct R *r){int q;if(x && (1u<<32)) return 1; return 0;}
