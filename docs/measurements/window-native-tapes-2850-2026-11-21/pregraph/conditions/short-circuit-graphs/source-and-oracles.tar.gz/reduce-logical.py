from pathlib import Path
import csv,re,json,shutil,sys,tarfile
d=Path(__file__).resolve().parent;g=Path(sys.argv[1])/'short-circuit-graphs';g.mkdir(exist_ok=True,parents=True)
paths=[]
def read(p):return list(csv.DictReader(p.open(),delimiter='\t'))
def tsv(name,r):
 with (g/name).open('w') as f:csv.writer(f,delimiter='\t',lineterminator='\n').writerows(r)
rows=[['corpus','policy','translation_units','identical_native_abi_objects_diagnostics','graph_operands_replaced','graph_nodes_removed','native_uses','not_reached','surviving_nodes_in_changed_units','surviving_edges_in_changed_units']]
for group,n in [('sqlite',3),('lua',102),('musl',4008),('main',3),('fixture',6)]:
 p=d/'logical-corpus'/(group+'.tsv');r=read(p)
 assert len(r)==n and all(i['same']=='1' and i['status']=='0' for i in r);paths.append((p,'units/'+p.name))
 for pol in ['ordinary','debug','wall']:
  part=[x for x in r if x['policy']==pol]
  rows.append([group,pol,len(part),len(part),*[sum(int(x[k] or 0) for x in part) for k in ['taken','removed','consumed','outside_source_only','surviving','edges']]])
tsv('corpus.tsv',rows)
rows=[['corpus','policy','compacted','entered','retained_source_rows','external_target_uses','internal_labels_emitted','unchanged_surviving_nodes','unchanged_surviving_edges']]
for group in ['fixture','sqlite','main']:
 for pol in ['default','debug','wall']:
  p=d/'logical-reads'/(group+'-'+pol);q=p/'graph.json';j=json.loads(q.read_text());assert not j['mismatches'] and j['extra_native']=='no';paths.append((q,'focus/'+p.name+'.json'))
  t=(p/'compact.err').read_text();entered=set(map(int,re.findall(r'^compact-consumed: token=(\d+)',t,re.M)))
  def total(pattern):return sum(int(v) for token,v in re.findall(pattern,t,re.M) if int(token) in entered)
  rows.append([group,pol,j['operands'],len(entered),j['selected_native_rows'],total(r'^branch-taken token=(\d+) body=\d+ branches=(\d+)'),total(r'^label-taken token=(\d+) body=\d+ labels=(\d+)'),j['retained'],j['fallback_edges']])
tsv('reach.tsv',rows)
ir=d/'logical-runtime';ref=(ir/'ref.answer').read_text().strip();rows=[['policy','variant','compile_status','execution_status','checksum','required_emitter_calls']]
for pol in ['ordinary','debug','warnings']:
 for m in ['plain','source','compact','disabled','fault','label']:
  p=ir/(pol+'-'+m)
  def val(ext):
   q=p.with_suffix(ext);return q.read_text().strip() if q.exists() else '-'
  cs=val('.status');rt=val('.runtime');an=val('.answer');needed=val('.err').count('compact-consumed:')
  if m in ('plain','source','compact'):assert cs==rt=='0' and an==ref
  if pol in ('ordinary','debug'):
   if m=='disabled' or m=='label':assert cs!='0'
   if m=='fault':assert cs==rt=='0' and an!=ref
   if m=='compact':assert needed==7
  rows.append([pol,m,cs,rt,an,needed])
tsv('execution.tsv',rows)
for p in ir.iterdir():
 if p.suffix in ('.out','.err','.status','.answer','.runtime','.runerr','.c'):paths.append((p,'execution/'+p.name))
cases=d/'logical-warning-grid/results.tsv';r=read(cases);assert len(r)==620 and all(x['same']=='1' for x in r),len(r)
rows=[['comparisons','equal','rejected','accepted','compiled_operands','reached_native']]
rows.append([len(r),len(r),sum(i['status']!='0' for i in r),sum(i['status']=='0' for i in r),sum(int(i['takes']) for i in r),sum(int(i['consumed']) for i in r)])
tsv('warning-policy.tsv',rows)
for p in cases.parent.iterdir():
 if p.suffix in ['.tsv','.c']:paths.append((p,'policies/'+p.name))
for name in ['compact-logicals.py','compact-logicals.sh','compact-conditions.sh','check-logical-reads.sh','logical-four.sh','logical-command.sh','logical-runtime.sh','logical-guard.c','logical-driver.c','logical-warning-grid.py','compact-corpus.py','reduce-logical.py','logical-condition.patch']:
 paths.append((d/name,name))
paths.append((d.parent/'source-graph-study/graph_check.py','graph_check.py'))
with tarfile.open(g/'source-and-oracles.tar.gz','w:gz',compresslevel=3) as f:
 for p,arc in paths:f.add(p,arcname=arc)
print('published',g)
