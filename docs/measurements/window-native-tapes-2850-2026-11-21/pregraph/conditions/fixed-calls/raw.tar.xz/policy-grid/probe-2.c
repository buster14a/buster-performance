extern int regular(int);
extern int selected(int,...);
int exercise(int x) { int v=0; if (selected(x,2)) v+=4; if (regular(x) && (selected(x,2))) v+=2; if ((selected(x,2)) || regular(x)) v++; return v; }
