extern int regular(int);
extern void selected(int) __attribute__((noreturn));
int exercise(int x) { int v=0; if ((selected(x),0)) v+=4; if (regular(x) && ((selected(x),0))) v+=2; if (((selected(x),0)) || regular(x)) v++; return v; }
