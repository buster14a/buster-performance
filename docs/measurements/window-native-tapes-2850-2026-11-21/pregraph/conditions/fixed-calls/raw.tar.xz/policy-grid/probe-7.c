extern int regular(int);
typedef int A __attribute__((aligned(16))); extern int selected(A);
int exercise(int x) { int v=0; if (selected(x)) v+=4; if (regular(x) && (selected(x))) v+=2; if ((selected(x)) || regular(x)) v++; return v; }
