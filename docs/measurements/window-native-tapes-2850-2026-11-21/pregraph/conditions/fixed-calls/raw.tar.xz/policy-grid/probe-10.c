extern int regular(int);
extern double selected(double);
int exercise(int x) { int v=0; if (selected((double)x)!=0.0) v+=4; if (regular(x) && (selected((double)x)!=0.0)) v+=2; if ((selected((double)x)!=0.0) || regular(x)) v++; return v; }
