extern int regular(int);
extern int selected(__int128);
int exercise(int x) { int v=0; if (selected((__int128)x+1)) v+=4; if (regular(x) && (selected((__int128)x+1))) v+=2; if ((selected((__int128)x+1)) || regular(x)) v++; return v; }
