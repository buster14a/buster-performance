extern int regular(int);
extern int selected(int) __attribute__((overloadable));extern int selected(long) __attribute__((overloadable));
int exercise(int x) { int v=0; if (selected(x)) v+=4; if (regular(x) && (selected(x))) v+=2; if ((selected(x)) || regular(x)) v++; return v; }
