extern int regular(int);
extern int a(int),b(int);
int exercise(int x) { int v=0; if ((x>1?a:b)(x)) v+=4; if (regular(x) && ((x>1?a:b)(x))) v+=2; if (((x>1?a:b)(x)) || regular(x)) v++; return v; }
