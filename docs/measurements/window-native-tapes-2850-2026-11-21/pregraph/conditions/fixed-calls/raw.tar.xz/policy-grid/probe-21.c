extern int regular(int);

int exercise(int x) { int v=0; if (__builtin_popcount((unsigned)x)) v+=4; if (regular(x) && (__builtin_popcount((unsigned)x))) v+=2; if ((__builtin_popcount((unsigned)x)) || regular(x)) v++; return v; }
