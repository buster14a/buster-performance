extern int regular(int);
extern int abs(int);
int exercise(int x) { int v=0; if (abs(x)) v+=4; if (regular(x) && (abs(x))) v+=2; if ((abs(x)) || regular(x)) v++; return v; }
