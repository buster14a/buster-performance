extern int regular(int);
struct z{int x;}; extern int selected(struct z);
int exercise(int x) { int v=0; if (selected((struct z){x})) v+=4; if (regular(x) && (selected((struct z){x}))) v+=2; if ((selected((struct z){x})) || regular(x)) v++; return v; }
