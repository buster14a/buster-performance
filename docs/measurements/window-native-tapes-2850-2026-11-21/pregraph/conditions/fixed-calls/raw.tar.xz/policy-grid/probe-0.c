extern int regular(int);
extern int selected(int);
int exercise(int x) { int v=0; if (selected(x)) v+=4; if (regular(x) && (selected(x))) v+=2; if ((selected(x)) || regular(x)) v++; return v; }
