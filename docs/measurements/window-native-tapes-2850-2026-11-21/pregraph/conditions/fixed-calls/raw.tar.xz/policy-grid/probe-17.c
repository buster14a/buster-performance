extern int regular(int);
static inline int selected(int z){return z*2;}
int exercise(int x) { int v=0; if (selected(x)) v+=4; if (regular(x) && (selected(x))) v+=2; if ((selected(x)) || regular(x)) v++; return v; }
