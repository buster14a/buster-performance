extern int add3(int), twice(int);
extern long mix(short, unsigned int, const int *);
extern int inspect(const int *);
extern int multi(const char *, ...);
int calls(const int *p, int x, unsigned int y, short s) {
    int answer = 0;
    if (twice(add3(x)) == (int)y) answer += 1;
    if (add3(twice(x)) > s) answer += 2;
    if (mix(s, y, p) < (long)x) answer += 4;
    if (inspect(p) && add3(x) != twice(s)) answer += 8;
    if (twice(x) || add3(s)) answer += 16;
    if (multi("%d", x)) answer += 32;
    if ((*p ? add3 : twice)(s)) answer += 64;
    return answer;
}
