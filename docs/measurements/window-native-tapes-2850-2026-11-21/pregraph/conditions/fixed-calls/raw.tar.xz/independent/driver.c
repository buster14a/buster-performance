#include <stdio.h>
#include <stdarg.h>
static unsigned calls_add, calls_twice, calls_mix, calls_inspect, calls_multi;
int add3(int x){++calls_add;return x+3;}
int twice(int x){++calls_twice;return x*2;}
long mix(short x,unsigned int y,const int *p){++calls_mix;return (long)x+(long)y+(long)*p;}
int inspect(const int *p){++calls_inspect;return *p;}
int multi(const char *fmt,...){++calls_multi;va_list ap;va_start(ap,fmt);int v=va_arg(ap,int);va_end(ap);return v%2;}
extern int calls(const int *, int, unsigned int, short);
int main(void){
    unsigned long long hash=0;
    for(int p=-2;p<=2;++p)for(int x=-4;x<=5;++x)
        for(unsigned y=0;y<=18;++y)for(short s=-3;s<=5;++s)
            hash=hash*65599u+(unsigned)calls(&p,x,y,s);
    printf("%llu %u %u %u %u %u\n",hash,calls_add,calls_twice,calls_mix,calls_inspect,calls_multi);
    return 0;
}
