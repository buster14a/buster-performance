#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$(cd .. && pwd)
ref=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin/clang
"$ref" probe.c driver.c -o ref.run;./ref.run >ref.answer
cc=${CALL_IMAGE:-$d/call-condition-compiler}
source <(sed -n '/^switches=(/p' "$d/compact-conditions.sh")
for p in ordinary debug wall;do
 f=();[[ $p != debug ]] || f=(-g);[[ $p != wall ]] || f=(-Wall -Wextra)
 for m in base source fault;do
  opts=(env)
  if [[ $m != base ]];then opts+=("${switches[@]}" NODE_SOURCE_CONSUME_FIXED_CALL=1);fi
  if [[ $m == fault ]];then opts+=(NODE_SOURCE_CALL_ORDER_FAULT=1);fi
  k=${CALL_PREFIX-}$p-$m
  "${opts[@]}" "$cc" --lanes 1 -c "${f[@]}" probe.c -o "$k.o" >"$k.out" 2>"$k.err" && st=0 || st=$?
  if [[ $st == 0 ]];then "$ref" driver.c "$k.o" -o "$k.run"; "./$k.run" >"$k.answer" && st=0 || st=$?;fi
  echo "$st" >"$k.status"
  if [[ $m != fault ]];then cmp ref.answer "$k.answer";fi
 done
done
