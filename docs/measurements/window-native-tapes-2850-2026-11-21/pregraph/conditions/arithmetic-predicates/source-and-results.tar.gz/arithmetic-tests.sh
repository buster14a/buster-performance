#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
export NODE_SOURCE_COMPACT_FAMILIES=arithmetic NODE_FIXED_TYPE_ORDER=replay NODE_SOURCE_COMPACT_FIXED_CALL=1 NODE_SOURCE_CONSUME_FIXED_CALL=1 NODE_SOURCE_COMPACT_READ_CONDITION=1 NODE_SOURCE_COMPACT_LOGICAL=1
bash arithmetic-runtime.sh
bash fixed-call-check.sh "$d/arithmetic-predicates.compiler" "$d/arithmetic-fixed-runtime"
python3 fixed-call-grid.py "$d/arithmetic-predicates.compiler" "$d/arithmetic-fixed-grid"
python3 arithmetic-grid.py
python3 arithmetic-memory-grid.py
bash arithmetic-only.sh
