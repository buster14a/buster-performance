int branch_arithmetic(unsigned x, unsigned y, unsigned z, signed char c, unsigned short h, volatile unsigned *cell, unsigned *hits)
{
    unsigned sum = 0;
    if (x + y) sum += 1;
    if (x * (y ^ z)) sum += 2;
    if (~(x | y)) sum += 4;
    if ((c + (int)h) < (int)(z & 65535u)) sum += 8;
    if ((x & y) ^ (z | x)) sum += 16;
    if (!(x - y)) sum += 32;
    if (x < y && *cell + z) { sum += 64; ++*hits; }
    if ((x * 7u - y) == z) sum += 128;
    if ((unsigned char)(x ^ y)) sum += 256;
    if ((x | y) && ((unsigned)c + h)) sum += 512;
    return (int)sum;
}
