from pathlib import Path
import csv,tarfile,hashlib,json
d=Path(__file__).resolve().parent
out=d.parent/'perf/docs/measurements/window-native-tapes-2850-2026-11-21/pregraph/conditions/arithmetic-predicates'
out.mkdir(exist_ok=True,parents=True)
def read(p):
 return list(csv.DictReader(p.open(),delimiter='\t'))
def write(name,labels,rows):
 with (out/name).open('w') as f:
  w=csv.writer(f,delimiter='\t',lineterminator='\n');w.writerow(labels);w.writerows(rows)
coverage=[];policies=[];execs=[]
for g,n in [('sqlite',1),('main',1),('lua',34),('musl',1336),('fixture',3)]:
 a=read(d/'family-corpus-arithmetic'/(g+'.tsv'))
 for pol in ['ordinary','debug','wall']:
  rows=[r for r in a if r['policy']==pol]
  assert len(rows)==n and all(r['same']=='1' and r['status']=='0' for r in rows)
  coverage.append([g,pol,n,*[sum(int(r[k]) for r in rows) for k in ('taken','removed','consumed','outside_source_only')]])
for section in ('fixed-grid','memory-grid','logical-grid'):
 path=d/('arithmetic-'+section);rows=read(next(path.glob('*.tsv')))
 assert all(r['same']=='1' for r in rows);policies.append([section,len(rows)])
for group in ['only','logical']:
 p=d/('arithmetic-'+group+'-runtime');ref=(p/'ref.answer').read_text().strip()
 for policy in ['ordinary','warnings','debug']:
  for mode in ['plain','source','compact','disabled','fault','label']:
   k=policy+'-'+mode;status=int((p/(k+'.status')).read_text())
   ans=(p/(k+'.answer')).read_text().strip() if (p/(k+'.answer')).exists() else ''
   taken=(p/(k+'.err')).read_bytes().count(b'compact-taken:')
   if mode in ['plain','source','compact']:assert ans==ref and status==0
   if mode=='fault' and policy=='ordinary':assert ans!=ref
   if mode=='compact' and policy=='ordinary':assert taken>0
   execs.append([group,policy,mode,status,taken,ans])
p=d/'arithmetic-fixed-runtime';ref=(p/'expected').read_bytes();assert all((p/(k+'.value')).read_bytes()==ref for k in ('graph','kept','removed'))
write('coverage.tsv',['input','policy','units','predicates','nodes removed','emitted','outside ordinary lowering'],coverage)
write('diagnostics.tsv',['matrix','matched cases'],policies)
write('executions.tsv',['fixture','policy','mode','compile status','removed predicates','checksum and counters'],execs)
with tarfile.open(out/'source-and-results.tar.gz','w:gz') as t:
 for f in ['arithmetic-predicates.patch','arithmetic-predicates.build','arithmetic-predicates.sh','arithmetic-four.sh','family-four.sh','check-type-replay.sh','compact-conditions.sh','fixed-corpus.py','fixed-call-check.sh','fixed-call-grid.py','fixed-call-driver.c','single-calls.c','logical-guard.c','logical-driver.c','arithmetic-guard.c','arithmetic-driver.c','arithmetic-only.sh','arithmetic-tests.sh','arithmetic-runtime.sh','arithmetic-grid.py','arithmetic-memory-grid.py','record-arithmetic.py']:
  t.add(d/f,arcname=f)
 for folder in ('family-corpus-arithmetic','arithmetic-fixed-grid','arithmetic-memory-grid','arithmetic-logical-grid','arithmetic-only-runtime','arithmetic-logical-runtime','arithmetic-fixed-runtime'):
  for f in (d/folder).iterdir():
   if f.suffix in {'.tsv','.status','.value','.answer','.runtime'} or f.name=='expected':t.add(f,arcname=folder+'/'+f.name)
 for f in (d/'arithmetic-predicates-focus').glob('*/graph.json'):t.add(f,arcname='graph/'+f.parent.name+'.json')
 t.add(d.parent/'source-graph-study/graph_check.py',arcname='graph_check.py')
x=[r for r in coverage if r[1]=='ordinary' and r[0]!='fixture']
print(coverage[0],list(map(sum,zip(*[r[3:] for r in x]))),policies)
