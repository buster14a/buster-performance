#include <stdint.h>
#include <stdio.h>
extern int branch_arithmetic(unsigned,unsigned,unsigned,signed char,unsigned short,volatile unsigned *,unsigned *);
int main(void)
{
    static const unsigned values[] = { 0, 1, 7, 8, 255, 256, 32767, 65535, 0x80000000u, 0xffffffffu };
    static const signed char chars[] = { -128, -1, 0, 127 };
    uint64_t hash = 0;
    unsigned hits = 0;
    volatile unsigned cell;
    for (unsigned i=0; i<10; ++i)
        for (unsigned j=0; j<10; ++j)
            for (unsigned k=0; k<10; ++k)
                for (unsigned m=0; m<4; ++m) {
                    cell = 0u - values[(k+m)%10];
                    unsigned result = (unsigned)branch_arithmetic(values[i],values[j],values[k],chars[m],(unsigned short)values[(i+j)%10],&cell,&hits);
                    hash = hash*65599 + result;
                }
    printf("%llu %u\n", (unsigned long long)hash,hits);
}
