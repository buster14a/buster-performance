#include <stdio.h>
extern int one_status(int), zero_status(void), compared(int), two(int,int);
static int hits[3];
static unsigned state;
int one(int v) { ++hits[0]; state = state * 17 + (unsigned)v; return v % 5; }
int zero(void) { ++hits[1]; state = state * 19 + 1; return (int)(state & 1); }
int pair(int a,int b) { ++hits[2]; state = state * 23 + (unsigned)a + (unsigned)b; return a - b; }
int main(void)
{
    unsigned sum = 11;
    for (int a = -12; a <= 12; ++a)
    {
        for (int b = -10; b <= 10; ++b)
        {
            sum = sum * 31 + (unsigned)one_status(a);
            sum = sum * 31 + (unsigned)zero_status();
            sum = sum * 31 + (unsigned)compared(b);
            sum = sum * 31 + (unsigned)two(a,b);
        }
    }
    printf("%u %u %d %d %d\n",sum,state,hits[0],hits[1],hits[2]);
    return 0;
}
