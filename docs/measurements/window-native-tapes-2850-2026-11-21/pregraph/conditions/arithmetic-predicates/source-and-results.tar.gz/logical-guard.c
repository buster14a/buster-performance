struct Bounds { int low, high; };
int select_value(const struct Bounds *p, const int *a, int index, int low, int high, int enabled)
{
    int mask=0;
    if (enabled == 1 && a[index] < high) mask += 1;
    if (enabled != 1 || p->low > low) mask += 2;
    if ((low < high && low > index) || (high == low && low != index)) mask += 4;
    if ((enabled == 1 && p->low < high) && (index < low || p->high > high)) mask += 8;
    if (((low < high && high != index) || low == index) && enabled == 1) mask += 16;
    if (enabled == 1 && (a[index] == low || a[index] == high)) mask += 32;
    if ((low == high || low == index) && (index != high || enabled == 1)) mask += 64;
    return mask;
}
