#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cd ../arithmetic-predicates
export PATH=/home/david/.cache/buster/toolchain/4444af0bee44de2d/llvm-23.1.4/bin:$PATH
git diff --binary >"$d/arithmetic-predicates.patch";./build.sh >"$d/arithmetic-predicates.build" 2>&1;cp build/compiler "$d/arithmetic-predicates.compiler"
export cc=$d/arithmetic-predicates.compiler d NODE_FIXED_TYPE_ORDER=replay NODE_SOURCE_COMPACT_FIXED_CALL=1 NODE_SOURCE_CONSUME_FIXED_CALL=1 NODE_SOURCE_COMPACT_READ_CONDITION=1 NODE_SOURCE_COMPACT_LOGICAL=1 NODE_SOURCE_COMPACT_FAMILIES=arithmetic
cd "$d";sed 's@fixed-type-replay@arithmetic-predicates-focus@g' check-type-replay.sh >check-arithmetic-predicates.sh;bash check-arithmetic-predicates.sh
sed 's/families.compiler/arithmetic-predicates.compiler/g' family-four.sh >arithmetic-four.sh;bash arithmetic-four.sh
