#include <stdio.h>
struct Bounds { int low, high; };
extern int select_value(const struct Bounds *,const int *,int,int,int,int);
int main(void)
{
    unsigned long long h=0;
    int table[4]={-2,0,2,9};struct Bounds bounds={2,6};
    for(int i=0;i<4;i++)for(int a=-3;a<=9;a++)for(int b=-2;b<=12;b++)for(int use=-1;use<=2;use++)
        h=65599*h+select_value(use==1?&bounds:0,use==1?table:0,i,a,b,use);
    printf("%llu\n",h);
}
