#!/bin/bash
set -eu
cd "$(dirname "$0")";d=$PWD;cc=$1;out=$2;mkdir -p "$out"
source <(sed -n '/^switches=(/p' compact-conditions.sh)
opts=("${switches[@]}" NODE_SOURCE_COMPACT_FIXED_CALL=1 NODE_SOURCE_CONSUME_FIXED_CALL=1 NODE_SOURCE_COMPACT=1 NODE_SOURCE_COMPACT_CONDITION=1 NODE_SOURCE_COMPACT_READ_CONDITION=1 NODE_SOURCE_COMPACT_REPORT=1)
clang -c single-calls.c -o "$out/clang.o"
clang fixed-call-driver.c "$out/clang.o" -o "$out/clang"
"$out/clang" >"$out/expected"
for mode in graph kept removed;do
 envs=()
 [[ $mode != kept ]] || envs=("${switches[@]}" NODE_SOURCE_CONSUME_FIXED_CALL=1)
 [[ $mode != removed ]] || envs=("${opts[@]}")
 env "${envs[@]}" NODE_SOURCE_NATIVE_ORACLE="$out/$mode.native" "$cc" --lanes 1 -nostdinc -c single-calls.c -o "$out/$mode.o" >"$out/$mode.out" 2>"$out/$mode.err"
 cmp "$out/graph.o" "$out/$mode.o"
 cmp "$out/graph.native" "$out/$mode.native"
 clang fixed-call-driver.c "$out/$mode.o" -o "$out/$mode.exe";"$out/$mode.exe" >"$out/$mode.value"
 cmp "$out/expected" "$out/$mode.value"
 nm -u "$out/$mode.o" >"$out/$mode.extern";cmp "$out/graph.extern" "$out/$mode.extern"
done
rg -c '^compact-(consumed|taken): ' "$out/removed.err"
