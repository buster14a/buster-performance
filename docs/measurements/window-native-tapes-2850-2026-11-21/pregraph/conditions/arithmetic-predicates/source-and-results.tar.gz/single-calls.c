extern int one(int), zero(void), pair(int, int);
int one_status(int x){if (one(x)) return 3;return 4;}
int zero_status(void){if (zero()) return 4;return 9;}
int compared(int x){if (one(x)==0) return 2;return 5;}
int two(int x,int y){if (pair(x,y)<x) return y;return 0;}
