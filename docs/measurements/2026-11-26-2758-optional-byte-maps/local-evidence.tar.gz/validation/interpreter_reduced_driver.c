// Temporary reduced test driver for #2758. This includes the unchanged production backend source at ba5b06dd.
// It is not the whole compiler product: only directly invoked interpreter tests are retained for local sanitizers.
#define BUSTER_UNIT BUSTER_UNIT_BACKEND
#define main_unit_backend static __attribute__((unused)) unused_backend_entry
#include "buster/compiler/main.c"
#undef main_unit_backend

int main(void)
{
    InterpreterTestTally tally = { 0 };
    Arena scratch = arena_reserve(16ull << 20);
    interpreter_test_expect(&tally, scratch.base != 0, "reduced-driver scratch allocation");
    if (scratch.base != 0)
    {
        interpreter_test_optional_maps(&tally, &scratch);
        interpreter_test_optional_map_capacity(&tally);
    }
    arena_release(&scratch);
    printf("reduced-driver typed map tests: %" PRIu64 " checks, %" PRIu64 " failed\n", tally.checks, tally.failures);
    int result = tally.failures != 0;
    result |= run_ir_interpreter_tests(0, 0);
    return result;
}
