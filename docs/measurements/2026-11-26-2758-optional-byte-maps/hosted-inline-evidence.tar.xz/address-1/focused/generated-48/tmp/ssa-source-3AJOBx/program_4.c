// test-ssa-source's program of seed 134000406 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x3fe8ae20u, g1 = 0x6bc7ae75u;
static unsigned garr[8] = { 0xc70990f1u, 0x6e886656u, 0xaf167d9au, 0x52a99211u, 0x91424b37u, 0xc7498d26u, 0x159ec123u, 0x2ea936b6u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    e0 = e0 * 0.5L + (long double)((unsigned)(i2 < (0x7d72a789u ^ 0xffffffffu)) & 1023u);
    { unsigned t0; double z0; if ((0u) & 1u) { t0 = (unsigned)(short)((garr[u2 & 7u] | 0xcf34adefu) & p1); z0 = (double)(((unsigned)((short)1u > (signed char)(unsigned)(short)((unsigned)e0 / ((unsigned)c1 | 1u)))) & 255u); } if ((0u) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        u0 += (unsigned)(x0 >> 70);
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                switch ((unsigned)s0 & 7u) {
                    c0 = (unsigned char)(i0 + (unsigned)((unsigned)(w0 >> 29) && fuel));
                    if (~(5u - (unsigned)((unsigned)(x0 >> 70) || *mp))) continue;
                    h1 = (unsigned short)(h1 + -(m0 * 0xf601765bu));
                }
                L0: if (--fuel == 0u) goto done;
            } while (i1++ < 3u && (unsigned)(unsigned char)(unsigned)((int)0x4a6701a8u < (int)garr[i1 & 7u]));
            w0 = w0 * 6364136223846793005ull + (unsigned)(i2 == (unsigned)(((unsigned)(i0 || (unsigned)h0) << (2u & 31u)) == (unsigned)f0));
            r0.y ^= fuel;
            if ((unsigned)(short)(u2 >> (0x10000u & 31u))) goto L4;
        } while (i0++ < 2u && (((unsigned)h0 / (p1 | 1u)) % (garr[i1 & 7u] | 1u)));
        L1: if (--fuel == 0u) goto done;
        L2: if (--fuel == 0u) goto done;
    }
    L3: if (--fuel == 0u) goto done;
    s0 = (int)garr[u2 & 7u];
    L4: if (--fuel == 0u) goto done;
    *q0 += (unsigned)!(0xffffffffu / ((a0[u1 & 3u] / (((unsigned)h0 & (unsigned)(w0 >> 29)) | 1u)) | 1u));
    if ((unsigned)b0) goto L3;
    u0 ^= (unsigned)((p0 / ((unsigned)e0 | 1u)) && (unsigned)(short)(0x80000000u - (unsigned)((int)i0 < (int)(unsigned)(x0 >> 70))));
    goto L4;
    goto L2;
    if (u3) {
        h1 = (unsigned short)(h1 + (p0 + (unsigned)((short)p0 > (signed char)(unsigned)(short)(unsigned)((int)p0 < (int)0xffffffffu))));
        goto L2;
        goto L2;
        if ((u1 & ((unsigned)d0 << (0xb54a5efcu & 31u)))) goto L0;
    } else {
        garr[(unsigned)((int)(unsigned)w0 >= (int)0x6ead11f6u) & 7u] = ((unsigned)x0 >> ((unsigned)c0 & 31u));
    }
    h1 = (unsigned short)(h1 + (unsigned)!(0x80000000u / (fuel | 1u)));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            u1 += ((unsigned)l0 * 8u);
            goto done;
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                b0 = (unsigned)(g1 && ((0x6fb7a248u + *q0) / ((unsigned)((unsigned)e0 < u0) | 1u))) != 0u;
                c0 = (unsigned char)(unsigned)(unsigned char)(unsigned)((unsigned)((unsigned)l0 && v0) < p0);
                if (v0) break;
            }
        }
    }
    goto L0;
    if ((unsigned)(signed char)((unsigned)(2u && 4u) & g1)) goto L1;
    if ((unsigned)(w0 >> 29)) goto L2;
    h1 = (unsigned short)(h1 + (0x7fffffffu << (((unsigned)l0 ? u2 : 5u) & 31u)));
    u3 += u1;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)(short)((unsigned)x0 / (p2 | 1u));
        u1 += (garr[i1 & 7u] * (unsigned)((int)(m0 >> (i2 & 31u)) >= (int)(u1 + (unsigned)c1)));
        switch (((unsigned)((int)p1 < (int)u2) | 0x10000u) & 7u) {
            w0 ^= (unsigned long long)a0[u1 & 3u] << ((unsigned)(*q0 && r0.x) & 63u);
            { unsigned t1; double z1; if (((unsigned)((short)(unsigned)((int)(unsigned)s1 >= (int)0x80000000u) > (signed char)0x80000000u)) & 1u) { t1 = r0.x; z1 = (double)(((unsigned)(unsigned char)(unsigned)((int)4u >= (int)(unsigned)(r0.y == (unsigned)s0))) & 255u); } if (((unsigned)((short)(unsigned)((int)(unsigned)s1 >= (int)0x80000000u) > (signed char)0x80000000u)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                case 4u: ;
            }
            q0 = &garr[0x7272008au & 7u];
        }
        g0 = (unsigned)(((u2 | 0xffffffffu) ^ (0x10000u & p0)) < (unsigned)e0);
    }
    d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(((0x7fffffffu | r0.x) << ((unsigned)l0 & 31u)) >> (u3 & 31u)) & 1023u);
    c0 = (unsigned char)(unsigned)(((unsigned)(x0 >> 70) << (7u & 31u)) || g0);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (4u) {
        u2 = u2 * 0x9e3779b1u + 0xffffffffu;
        if ((unsigned)e0) {
            if ((unsigned)((short)0x7c7b1a92u > (signed char)u1)) goto L2;
            if ((u2 - *q0)) goto L4;
            i2 = ((unsigned)((short)(7u * g0) > (signed char)0x80000000u) | ((unsigned)h0 / ((unsigned)h1 | 1u))) & 15u;
            if ((unsigned)(0xc3241572u == 0x79a14968u)) goto L3;
            if (((u0 >> (0x65f6b9f0u & 31u)) + 0xffffffffu)) goto L2;
            if ((unsigned)(0x10000u == (g1 / (garr[u2 & 7u] | 1u)))) goto L4;
        } else {
            g0 = ((unsigned)e0 ? (a0[u1 & 3u] % (0x7fffffffu | 1u)) : (unsigned)l0);
            L0: if (--fuel == 0u) goto done;
            while (i0++ < 2u && 0xffffffffu) { if (--fuel == 0u) goto done;
                if ((u0 | p1)) break;
                w0 ^= (unsigned long long)(unsigned)(0x2de9db72u == 9u) << (~(((unsigned)d0 << (g1 & 31u)) >> (0x80000000u & 31u)) & 63u);
            }
            u0 = u0 * 0x9e3779b1u + (garr[i1 & 7u] | (unsigned)h1);
        }
    }
    g1 += ((unsigned)(3u || r0.x) & (g1 % (garr[u2 & 7u] | 1u)));
    s1 = (int)((unsigned)s1 + (unsigned)((int)(((unsigned)h1 - 7u) * r0.y) >= (int)a0[i0 & 3u]));
    while (i0++ < 5u && (unsigned)((int)((unsigned)w0 ^ (unsigned)h1) >= (int)u2)) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch (7u & 7u) {
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)!((unsigned)(x0 >> 70) | 0x4f5006dfu)) {
                        do { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u2 = fn0((2u * i2), (0x7fffffffu / (((unsigned)(x0 >> 70) * p0) | 1u)), (i2 & u3)); }
                            a0[(unsigned)(m0 == u3) & 3u] = (unsigned)((unsigned)(x0 >> 70) < 0xe80d85a0u);
                            L1: if (--fuel == 0u) goto done;
                            continue; (void)((unsigned)(0x347e4d5u || *q0));
                        } while (i0++ < 4u && (unsigned)((int)(unsigned)h1 >= (int)(unsigned)(0x80000000u || 3u)));
                        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                            w0 ^= (unsigned long long)(0x870c71c2u - garr[i1 & 7u]) << (((7u ? (unsigned)b0 : (unsigned)((int)(unsigned)w0 >= (int)garr[u2 & 7u])) * g0) & 63u);
                            s0 = (int)(unsigned)((unsigned)((int)0x10000u < (int)(unsigned)b0) && u0);
                            *q0 += v0;
                            x0 = x0 * 0x100000001b3ull + (unsigned)((short)(p2 + (unsigned)h1) > (signed char)(unsigned)(x0 >> 70));
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(u0 < (unsigned)((short)u2 > (signed char)3u)), 3u, 8u); }
                        }
                        if (u3 == 7u) return (((unsigned)((int)garr[u2 & 7u] >= (int)i0) >> (*mp & 31u)) % ((unsigned)s0 | 1u));
                        if (((unsigned)b0 + (3u * garr[u2 & 7u]))) break;
                        L2: if (--fuel == 0u) goto done;
                    } else {
                        { unsigned t0; double z0; if ((((unsigned)x0 + r0.y)) & 1u) { t0 = 2u; z0 = (double)((-((unsigned)s0 + 0x2065115eu)) & 255u); } if ((((unsigned)x0 + r0.y)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                            L3: if (--fuel == 0u) goto done;
                            if ((unsigned)s0) goto L2;
                            w0 = w0 * 6364136223846793005ull + (garr[i1 & 7u] * 0x80000000u);
                            f0 = f0 * 0.5f + (float)((unsigned)(u2 && (i1 + (unsigned)((int)i0 >= (int)(unsigned)h1))) & 255u);
                            g0 = 6u;
                        }
                        d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)s1 > (signed char)((unsigned)c0 ? (0xb963a40au >> ((unsigned)(w0 >> 29) & 31u)) : (unsigned)h1)) & 1023u);
                        v0 = (unsigned)(0xffffffffu && u0);
                    }
                    if ((unsigned)c1) {
                        case 1u: ;
                        c1 = (signed char)(unsigned)((unsigned)l0 && r0.y);
                        if (fuel < 8u) return ((unsigned)h0 >> (((unsigned)d0 ^ fuel) & 31u));
                        if ((unsigned)(unsigned char)(0x4634e972u / ((unsigned)((int)g0 < (int)0x5748a1dbu) | 1u))) continue;
                        case 5u: ;
                    }
                }
                w0 ^= (unsigned long long)0x7fffffffu << ((unsigned)h0 & 63u);
                u0 = u0 * 0x9e3779b1u + ((unsigned)(x0 >> 70) / ((unsigned)c0 | 1u));
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)h0, u1, 0xffffffffu); }
                v0 = i0;
            }
            L4: if (--fuel == 0u) goto done;
            break; (void)(v0);
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)c1 >= (int)(unsigned)c0)) {
                    b0 = garr[i1 & 7u] != 0u;
                    r0.y ^= (unsigned)s1;
                    break; (void)(1u);
                }
                w0 = w0 * 6364136223846793005ull + (0x7fffffffu | (p2 + 0x80000000u));
                s0 = (int)(unsigned)((int)(unsigned)d0 < (int)1u);
                g1 += (unsigned)((int)(unsigned)(unsigned char)(r0.y + g1) >= (int)(unsigned)((short)0x10000u > (signed char)i1));
                while (i0++ < 4u && (unsigned)((short)u3 > (signed char)m0)) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)(((unsigned)(x0 >> 70) ^ (a0[i0 & 3u] >> (0x80000000u & 31u))) & 1023u);
                    if (0x80000000u) break;
                    break; (void)((unsigned)(unsigned char)(unsigned)(0x80000000u || (unsigned)((int)0u >= (int)4u)));
                    while (i1++ < 3u && (u1 & g0)) { if (--fuel == 0u) goto done;
                        if (3u) break;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(r0.y == *q0) - p1), garr[i1 & 7u], (unsigned)(u3 && (r0.y | p2))); }
                        u3 += (u0 | ((((unsigned)s1 | 4u) & 5u) * r0.x));
                        if (i1) break;
                        q0 = &garr[(unsigned)w0 & 7u];
                        if ((((unsigned)h1 - p2) % ((unsigned)c0 | 1u))) break;
                    }
                }
            } while (i2++ < 2u && (unsigned)(short)(unsigned)((int)(p0 * a0[i0 & 3u]) >= (int)*mp));
            q0 = &garr[((unsigned)((short)r0.x > (signed char)~((unsigned)c1 << (0xfdc4c288u & 31u))) ^ (unsigned)l0) & 7u];
        }
        if ((unsigned)!(*q0 >> ((unsigned)l0 & 31u))) {
            while (i1++ < 6u && (i2 ^ v0)) { if (--fuel == 0u) goto done;
                goto L1;
                e0 = e0 * 0.5L + (long double)((((unsigned)d0 - (unsigned)(short)(u0 - g0)) / ((unsigned)((unsigned)x0 < 0x7fffffffu) | 1u)) & 1023u);
                m0 ^= ((a0[u1 & 3u] % ((unsigned)w0 | 1u)) >> (i0 & 31u));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)*mp > (signed char)(unsigned)(r0.y && a0[i0 & 3u])), g0, ((i2 / (0xffffffffu | 1u)) ^ g0)); }
                s0 = (int)m0;
                goto L0;
            }
            r0.y ^= (unsigned)(unsigned char)(0x80000000u >> ((unsigned)(short)(unsigned)((int)(unsigned)w0 < (int)u1) & 31u));
            s1 = (int)((unsigned)s1 + (garr[u2 & 7u] ? (unsigned)(w0 >> 29) : ((unsigned)c1 * (unsigned)s0)));
            if (0xff725deu) {
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)w0) break;
                } while (i1++ < 6u && (r0.y * a0[i0 & 3u]));
                c0 = (unsigned char)(unsigned)(a0[i0 & 3u] == ((a0[u1 & 3u] ^ (unsigned)h1) & garr[u2 & 7u]));
                if ((0xed077cf7u | (unsigned)((int)0x759633f0u >= (int)g0))) {
                    if (0x7fffffffu) break;
                    m0 ^= (unsigned)!((p1 % (4u | 1u)) >> ((unsigned)(u0 < (*mp >> (9u & 31u))) & 31u));
                }
                if (a0[u1 & 3u]) {
                    { unsigned t1; double z1; if (((i0 / ((unsigned)(0x7fffffffu < (unsigned)h1) | 1u))) & 1u) { t1 = a0[u1 & 3u]; z1 = (double)((3u) & 255u); } if (((i0 / ((unsigned)(0x7fffffffu < (unsigned)h1) | 1u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                        if (fuel < 8u) return (unsigned)((0xffffffffu & (unsigned)((unsigned)h0 || 0x80000000u)) < 0x80000000u);
                        goto L1;
                        continue; (void)((unsigned)((int)(unsigned)(w0 >> 29) < (int)p0));
                    }
                    d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)(0x10000u < 7u) >= (int)0x7fffffffu) & 1023u);
                    h1 = (unsigned short)(h1 + ((unsigned)w0 & ((unsigned)h0 * g1)));
                } else {
                    if ((5u % ((unsigned)c0 | 1u))) continue;
                    a0[0x76ca9471u & 3u] = ((unsigned)(unsigned char)(unsigned)((unsigned)(*q0 < (unsigned)x0) < (i0 & (unsigned)f0)) % (g0 | 1u));
                    break; (void)(u3);
                }
                { unsigned t2; double z2; if (((unsigned)((garr[u2 & 7u] & 0x80000000u) || g1)) & 1u) { t2 = (unsigned)x0; z2 = (double)((((unsigned)(9u == r0.y) >> ((unsigned)s0 & 31u))) & 255u); } if (((unsigned)((garr[u2 & 7u] & 0x80000000u) || g1)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    u2 = u2 * 0x9e3779b1u + ((0x80c8bdd8u << ((unsigned)(unsigned char)((unsigned)h1 ^ a0[u1 & 3u]) & 31u)) - 1u);
                    while (i1++ < 6u && (unsigned)((short)p0 > (signed char)(unsigned)w0)) { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + ((0xd4ce24f6u + r0.x) % (-(unsigned)(0x16ae3175u == u0) | 1u)));
                        if (budget != 0u) { budget -= 1u; u2 = fn0(-(p2 / (u1 | 1u)), ((unsigned)b0 + (unsigned)(0x21a27032u == 0xffffffffu)), (unsigned)!(unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)((short)(unsigned)h1 > (signed char)(unsigned)b0))); }
                    }
                    if ((unsigned)((int)(unsigned)h0 < (int)0x1b89e4bau)) break;
                    if (~(u0 * (unsigned)s1)) continue;
                }
                *mp = (a0[u1 & 3u] << ((unsigned)l0 & 31u));
            }
            if ((unsigned)(v0 || (unsigned)((int)i0 < (int)(unsigned)h0))) break;
            break; (void)((unsigned)(unsigned char)(unsigned)(i1 && (unsigned)d0));
        } else {
            switch (-(0x42b97ecfu & (unsigned)((int)i0 < (int)garr[u2 & 7u])) & 7u) {
                q0 = &garr[(unsigned)(p1 < (unsigned)(2u || 5u)) & 7u];
                if (i2) break;
                { unsigned t3; double z3; if ((0x7fffffffu) & 1u) { t3 = ((unsigned)w0 - garr[i1 & 7u]); z3 = (double)((0xffffffffu) & 255u); } if ((0x7fffffffu) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                    r0.y ^= (unsigned)((unsigned)((short)(unsigned)(0xffffffffu < 0xa1655d8du) > (signed char)(unsigned)b0) || (r0.y - (unsigned)(x0 >> 70)));
                    x0 = x0 * 0x100000001b3ull + (unsigned)((int)i0 >= (int)((0x50bb103fu - (unsigned)h1) - (unsigned)h0));
                    q0 = &garr[*mp & 7u];
                    h0 = (short)(unsigned)((int)~(unsigned)((int)0x701fc163u >= (int)(unsigned)h0) < (int)4u);
                    garr[(garr[i1 & 7u] / ((unsigned)(w0 >> 29) | 1u)) & 7u] = ((unsigned)l0 ^ (unsigned)x0);
                    g0 = (unsigned)((unsigned)((a0[i0 & 3u] % ((unsigned)h1 | 1u)) == i2) && (unsigned)((short)9u > (signed char)fuel));
                }
                if ((unsigned)((short)g1 > (signed char)u1)) break;
                x0 = x0 * 0x100000001b3ull + (unsigned)(u0 == (i0 ? (unsigned)(short)(u1 >> (7u & 31u)) : (unsigned)h1));
                if (((unsigned)((int)(unsigned)h0 < (int)(unsigned)h1) ^ p2)) continue;
            }
            q0 = &garr[(p0 - (unsigned)((unsigned)((int)0x21f8f1b9u >= (int)1u) && r0.y)) & 7u];
            break; (void)((unsigned)s1);
        }
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(~(unsigned)((unsigned)(1u || u1) == (unsigned)(w0 >> 29)));
        while (i1++ < 5u && (unsigned)((unsigned)h0 == i2)) { if (--fuel == 0u) goto done;
            m0 ^= (u1 / (((unsigned)f0 - 0x24bf3f74u) | 1u));
            if (u3) break;
            *q0 += (unsigned)(w0 >> 29);
            g0 = (unsigned)((int)u3 < (int)(unsigned)h1);
        }
    }
    if ((unsigned)e0) goto done;
    r0.y ^= (unsigned)((int)(0x80000000u / (4u | 1u)) >= (int)((unsigned)(1u < p1) & (unsigned)l0));
    goto done;
    if ((unsigned)(0x10000u || (0xeffa01e9u >> (5u & 31u)))) {
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)(u1 & (0x7fffffffu / (0x3f9f29ffu | 1u)));
            if (budget != 0u) { budget -= 1u; u1 = fn0(i0, (unsigned)f0, (g1 % ((unsigned)(w0 >> 29) | 1u))); }
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)(~((unsigned)(w0 >> 29) >> ((unsigned)(i1 && i2) & 31u)));
                if ((a0[u1 & 3u] >> (u0 & 31u))) break;
                if ((unsigned)(4u < (unsigned)s1)) break;
                u2 ^= (unsigned)((int)i1 < (int)(unsigned)((short)0x7fffffffu > (signed char)a0[i0 & 3u]));
                { unsigned t4; double z4; if (((unsigned)!(a0[u1 & 3u] ? p2 : g1)) & 1u) { t4 = (unsigned)(0xffffffffu || 6u); z4 = (double)((((unsigned)b0 << (p1 & 31u))) & 255u); } if (((unsigned)!(a0[u1 & 3u] ? p2 : g1)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    f0 = f0 * 0.5f + (float)((((unsigned)(unsigned char)(unsigned)(p1 || 0u) - (unsigned)w0) % (((unsigned)c0 >> (0x7e05c563u & 31u)) | 1u)) & 255u);
                    s1 = (int)((unsigned)s1 + (unsigned)(((unsigned)s1 * (unsigned)s1) && ((unsigned)x0 / (0x6c6275du | 1u))));
                    u1 ^= (unsigned)((int)(unsigned)!((unsigned)(0u == (unsigned)(x0 >> 70)) % (7u | 1u)) >= (int)(unsigned)((short)fuel > (signed char)7u));
                    q0 = &garr[(unsigned)((short)(r0.y | (unsigned)s1) > (signed char)(unsigned)(garr[u2 & 7u] || r0.x)) & 7u];
                    g1 += ((unsigned)b0 << (0u & 31u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)e0 << (0x80000000u & 31u)), (unsigned)(i1 < (i0 ^ garr[u2 & 7u])), (0x7fffffffu & u0)); }
                }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(0x34f0111cu, i0, (p2 & (u2 >> (u0 & 31u)))); }
            if ((unsigned)((p0 ^ m0) && (unsigned)w0)) continue;
        }
        if ((unsigned)((int)(unsigned)l0 < (int)(u0 << (0x7fffffffu & 31u)))) goto L3;
        if ((unsigned)((unsigned)s0 == ((unsigned)h1 << (0x7fffffffu & 31u)))) {
            u2 = ((a0[i0 & 3u] & r0.y) / ((a0[u1 & 3u] / (fuel | 1u)) | 1u));
        } else {
            goto L4;
            if (i1) {
                g0 = 0xfe6a8414u;
                if ((6u ^ i0)) goto L4;
                i0 = (unsigned)((short)(unsigned)x0 > (signed char)(*q0 | (unsigned)(m0 == (unsigned)(x0 >> 70)))) & 15u;
                if (p0) goto L3;
            }
            e0 = e0 * 0.5L + (long double)(a0[u1 & 3u] & 1023u);
            h1 = (unsigned short)(h1 + (unsigned)s1);
        }
        switch (r0.y & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)x0 < u1), (unsigned)((short)m0 > (signed char)(g0 << (6u & 31u))), (unsigned)w0); }
            if ((unsigned)f0) goto L4;
            *q0 += (unsigned)((short)(unsigned)(p2 < a0[u1 & 3u]) > (signed char)0x80000000u);
        }
        if (i2) goto L2;
        while (i0++ < 7u && ((unsigned)((short)a0[u1 & 3u] > (signed char)u0) ^ (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((unsigned)e0 & (unsigned)(0x765d9f3bu < garr[i1 & 7u])) & 1023u);
            w0 = w0 * 6364136223846793005ull + 0xeef6d1bcu;
            do { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + a0[u1 & 3u];
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)h1 < (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)((short)(unsigned)x0 > (signed char)g1))) & 255u);
                if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, (unsigned)((unsigned)s1 == (unsigned)c1), 0x80000000u); }
                s0 = (int)(unsigned)(unsigned char)(unsigned)((short)(0x20c613e5u / (0x2586f273u | 1u)) > (signed char)r0.y);
            } while (i1++ < 5u && ((unsigned)e0 ? garr[u2 & 7u] : (unsigned)f0));
        }
    }
    h1 = (unsigned short)(h1 + (unsigned)(a0[u1 & 3u] == (1u % (a0[u1 & 3u] | 1u))));
    u0 = ~(g0 + (unsigned)(w0 >> 29));
    d0 = d0 * 0.5 + (double)(((unsigned)w0 << (r0.y & 31u)) & 1023u);
    e0 = e0 * 0.5L + (long double)(g1 & 1023u);
    goto L1;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)h0 % ((unsigned)(u2 == (unsigned)f0) | 1u))) continue;
        if (budget != 0u) { budget -= 1u; u3 = fn0(-(unsigned)((unsigned)w0 || ((unsigned)d0 + (unsigned)x0)), (unsigned)(short)(p0 / ((unsigned)f0 | 1u)), ((0x67f114fcu - p2) + 2u)); }
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s0, (m0 >> (p1 & 31u)), (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)l0)); }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((unsigned)((unsigned)f0 || garr[i1 & 7u]) * (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)((int)(unsigned)h0 >= (int)(unsigned)c1)));
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)h0 ^ 0x7c5aa02fu), -(unsigned)(0x10000u == 0x7fffffffu), ((*q0 & u2) << (2u & 31u))); }
            if ((0x80000000u + (unsigned)(w0 >> 29))) break;
            i0 = r0.y & 15u;
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)h1, (unsigned)(garr[i1 & 7u] < (0xffffffffu << (1u & 31u))), ((unsigned)(garr[u2 & 7u] == fuel) | (unsigned)s1)); }
                c0 = (unsigned char)(unsigned)((unsigned)(signed char)((unsigned)f0 / ((unsigned)e0 | 1u)) || g0);
                if ((u1 - (unsigned)(short)((unsigned)h0 & u1))) {
                    if (((0xb069f29cu / (0x80000000u | 1u)) - (unsigned)(x0 >> 70))) goto L0;
                } else {
                    if (((unsigned)x0 ^ r0.x)) continue;
                    if ((unsigned)((int)0xa8b79128u < (int)(0x6f4782c9u | a0[i0 & 3u]))) continue;
                    g1 += (unsigned)(~(u0 >> (u2 & 31u)) < (unsigned)((int)(unsigned)((short)0xf0f66badu > (signed char)0xe669812au) >= (int)p1));
                }
                do { if (--fuel == 0u) goto done;
                    g1 += ((unsigned)(x0 >> 70) ? 0x9ada8639u : (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)d0));
                    goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((u0 >> ((unsigned)!(u2 & (unsigned)h0) & 31u)), (8u | 0xb118ae93u), ((unsigned)((int)(unsigned)l0 < (int)0xffffffffu) / (*mp | 1u))); }
                    i0 = (unsigned)!((unsigned)c0 >> (p2 & 31u)) & 15u;
                } while (i0++ < 6u && u3);
                *q0 += (((unsigned)f0 | *q0) + garr[u2 & 7u]);
            }
            u0 += ((unsigned)((int)(unsigned)c1 < (int)r0.y) << ((unsigned)(m0 == (unsigned)(m0 || a0[u1 & 3u])) & 31u));
        }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((a0[i0 & 3u] & (unsigned)(0x4047ba5eu < (unsigned)l0))) break;
            *q0 += (unsigned)((short)(unsigned)((int)*q0 >= (int)g1) > (signed char)(unsigned)(x0 >> 70));
        }
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)w0 || (unsigned)(signed char)((unsigned)x0 >> ((unsigned)(signed char)((unsigned)c1 | 0u) & 31u))));
    }
    { unsigned t5; double z5; if ((u1) & 1u) { t5 = r0.y; z5 = (double)(((unsigned)((unsigned)b0 == fuel)) & 255u); } if ((u1) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        if (0x893a5f9cu) goto L0;
    }
    u1 = (unsigned)e0;
    if (((unsigned)e0 * g1)) goto done;
    goto L0;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)g1 > (signed char)(i2 % (a0[u1 & 3u] | 1u))), (unsigned)(short)((v0 << (p1 & 31u)) - 0x80000000u), (unsigned)(signed char)(unsigned)(0x1b14d962u || p2)); }
    { unsigned t6; double z6; if (((unsigned)w0) & 1u) { t6 = (unsigned)((unsigned)(x0 >> 70) && (unsigned)h1); z6 = (double)((6u) & 255u); } if (((unsigned)w0) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        while (i0++ < 2u && (unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
            continue; (void)(i2);
            m0 ^= (unsigned)h1;
        }
        *q0 += (unsigned)((int)0x1a7d4b3bu < (int)g0);
        if (u3 == 7u) return (0x80000000u >> (((g1 % (0x7fffffffu | 1u)) + 2u) & 31u));
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((fuel / ((unsigned)h0 | 1u))) {
                    if ((unsigned)((int)fuel >= (int)(unsigned)c0)) continue;
                }
                h1 = (unsigned short)(h1 + 0x80000000u);
                l0 = (long)((unsigned long)l0 + (unsigned)!((u1 - (0xffffffffu | 9u)) & r0.x));
                m0 ^= (g1 ? (unsigned)e0 : 9u);
                a0[0x80000000u & 3u] = (unsigned)w0;
                *mp = (unsigned)((short)(unsigned)((p0 | (unsigned)s0) == (unsigned)d0) > (signed char)(4u ^ u1));
            }
            if ((unsigned)(short)(unsigned)((short)(unsigned)(garr[u2 & 7u] || (unsigned)h0) > (signed char)m0)) {
                if ((((unsigned)d0 - u1) - 0x7fffffffu)) break;
                for (;;) { if (--fuel == 0u) goto done;
                    u0 += (~(u1 / (p0 | 1u)) ? v0 : (unsigned)c0);
                }
            }
            { unsigned t7; double z7; if ((~(0x937b4488u - (a0[i0 & 3u] ^ r0.x))) & 1u) { t7 = (garr[i1 & 7u] << ((0xa6591a68u >> (p1 & 31u)) & 31u)); z7 = (double)((8u) & 255u); } if ((~(0x937b4488u - (a0[i0 & 3u] ^ r0.x))) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                s0 = (int)(a0[u1 & 3u] | (i1 - (unsigned)(w0 >> 29)));
                if ((unsigned)((unsigned)!(unsigned)((int)g0 < (int)garr[i1 & 7u]) || 0xffffffffu)) break;
                u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)w0) < (unsigned)(2u == (unsigned)(garr[u2 & 7u] && (unsigned)d0)));
            }
            if ((0x80000000u * (0u ^ u1))) break;
            i1 = (4u * 0x10000u) & 15u;
            for (;;) { if (--fuel == 0u) goto done;
                *mp = m0;
                if ((unsigned)h0) {
                    switch ((unsigned)(r0.x == (unsigned)h0) & 7u) {
                        *q0 = (unsigned)((int)1u >= (int)0x80000000u);
                    }
                } else {
                    s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)((unsigned)((unsigned)h0 < m0) | (unsigned)((int)i0 < (int)(unsigned)s1)));
                    while (i2++ < 2u && 0x80000000u) { if (--fuel == 0u) goto done;
                        switch ((unsigned)(g0 && (unsigned)l0) & 7u) {
                            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)l0, (unsigned)(7u && 0x10000u), u1); }
                            if (u3 == 7u) return (unsigned)!((0x8d41abfau & (unsigned)c0) << ((unsigned)(2u || g1) & 31u));
                            case 1u: ;
                            l0 = (long)((unsigned long)l0 + *q0);
                        }
                        *q0 = ((u3 >> (p1 & 31u)) * (*mp & (unsigned)d0));
                        if (((unsigned)(u2 && (unsigned)s1) % (garr[u2 & 7u] | 1u))) break;
                        if (fuel < 8u) return (fuel << ((fuel - 6u) & 31u));
                        f0 = f0 * 0.5f + (float)((garr[i1 & 7u] - (u3 % (*q0 | 1u))) & 255u);
                        if (((p0 - 0x6361dec3u) + (unsigned)l0)) break;
                    }
                }
                if ((unsigned)h0) goto L0;
                if (budget != 0u) { budget -= 1u; u0 = fn0(fuel, *mp, ((unsigned)d0 << ((unsigned)(0x9a3375c7u == (unsigned)d0) & 31u))); }
            }
        }
        if (((*q0 << (u3 & 31u)) / (u3 | 1u))) {
            i2 = (u3 % (0x10000u | 1u)) & 15u;
            w0 = w0 * 6364136223846793005ull + -(unsigned)((int)p0 >= (int)(unsigned)c0);
            if (((unsigned)s0 << ((unsigned)((unsigned)c1 || *q0) & 31u))) {
                while (i0++ < 2u && (i2 << (a0[i0 & 3u] & 31u))) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((garr[u2 & 7u] % (r0.y | 1u)) & 255u);
                    if ((unsigned)((short)(unsigned)((unsigned)s0 < (unsigned)(w0 >> 29)) > (signed char)u1)) goto L0;
                    i1 = ((unsigned)s1 - (unsigned)f0) & 15u;
                    if ((u3 ^ (unsigned)c1)) break;
                    f0 = f0 * 0.5f + (float)((i1 ^ (unsigned)((int)(unsigned)((int)7u >= (int)0x593ceb26u) >= (int)2u)) & 255u);
                    d0 = d0 * 0.5 + (double)(((g1 - (unsigned)s0) ? (unsigned)x0 : 0x80000000u) & 1023u);
                }
                l0 = (long)((unsigned long)l0 + ((unsigned)(signed char)((unsigned)h1 | v0) + (g0 * g0)));
                if (1u) goto L0;
                goto L1;
                if (u3 == 7u) return (v0 / ((unsigned)((unsigned)(((unsigned)l0 * *q0) < r0.y) == *q0) | 1u));
                c1 = (signed char)(unsigned)f0;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)x0 | (i2 | u2)), (unsigned)((unsigned)e0 < (unsigned)(0xfc0a18e0u || 0xffffffffu)), a0[i0 & 3u]); }
        } else {
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(short)(unsigned)(m0 && r0.x) | (unsigned)h1), (0x17440007u - v0), ((p0 % (v0 | 1u)) % (m0 | 1u))); }
            g0 = (unsigned)(i0 || r0.y);
            i0 = ((unsigned)(unsigned char)((i2 / (a0[u1 & 3u] | 1u)) - 0x8fa8584fu) - 0x10000u) & 15u;
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                i0 = (unsigned)(-(p1 / ((unsigned)h0 | 1u)) == (unsigned)l0) & 15u;
                b0 = (unsigned)!(unsigned)((int)(0xe846ee95u ^ r0.x) < (int)((unsigned)x0 << (0x10000u & 31u))) != 0u;
                if (fuel < 8u) return (garr[u2 & 7u] << (0xffffffffu & 31u));
                break; (void)((p1 - m0));
                q0 = &garr[(unsigned)(0u == 3u) & 7u];
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(i2, 0x7fffffffu, i1); }
    if (((unsigned)((int)(unsigned)s1 >= (int)0xb35efa6bu) + 0x7fffffffu)) {
        goto L4;
        q0 = &garr[(i2 + ((unsigned)(unsigned char)(r0.y / ((unsigned)b0 | 1u)) << ((unsigned)((int)u0 >= (int)garr[u2 & 7u]) & 31u))) & 7u];
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)d0 % (p2 | 1u)), (unsigned)((int)i1 < (int)(unsigned)h1), ((unsigned)(w0 >> 29) ^ v0)); }
            continue; (void)((i0 >> ((unsigned)((short)v0 > (signed char)r0.x) & 31u)));
        } while (i0++ < 3u && ((0x5943330fu - v0) ^ (unsigned)f0));
    }
    b0 = ((*q0 << (p0 & 31u)) * (unsigned)(unsigned char)((unsigned)h1 | (0x10000u | u3))) != 0u;
    { unsigned t8; double z8; if ((garr[u2 & 7u]) & 1u) { t8 = ((unsigned)c0 * (i1 + (unsigned)e0)); z8 = (double)((u3) & 255u); } if ((garr[u2 & 7u]) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
        if ((unsigned)d0) goto L4;
    }
    if ((0x80000000u << ((unsigned)(fuel || i2) & 31u))) goto L4;
    h0 = (short)((unsigned)s1 & (0x58c1742au << (p0 & 31u)));
    if (budget != 0u) { budget -= 1u; u2 = fn0((g1 - garr[i1 & 7u]), 0x80000000u, 0xa2ab0207u); }
    w0 ^= (unsigned long long)(unsigned)l0 << ((unsigned)((int)a0[u1 & 3u] >= (int)(0x80000000u ? (unsigned)(0x3aabf416u < (unsigned)f0) : 0xd36aebe0u)) & 63u);
    h1 = (unsigned short)(h1 + ((unsigned)h1 + 0x2de85e0du));
    { unsigned t9; double z9; if (((0x10000u << (i0 & 31u))) & 1u) { t9 = a0[i0 & 3u]; z9 = (double)((9u) & 255u); } if (((0x10000u << (i0 & 31u))) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
        goto L2;
        h0 = (short)p0;
        *mp = ((u3 % ((unsigned)(0x7fffffffu && (unsigned)(0x91b25505u == (unsigned)s1)) | 1u)) << (7u & 31u));
        g0 = (unsigned)((int)((unsigned)f0 - a0[u1 & 3u]) >= (int)v0);
        if (0x10000u) goto L1;
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(unsigned char)(0x22bb47e6u * 0x80000000u)) break;
        if (*q0) {
            { unsigned t10; double z10; if (((i2 | p2)) & 1u) { t10 = r0.y; z10 = (double)((((0xf26584eau | p1) >> ((unsigned)c1 & 31u))) & 255u); } if (((i2 | p2)) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                if (6u) break;
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)0x5187629au < (int)((unsigned)((unsigned)s1 < (unsigned)b0) + (unsigned)(signed char)(r0.x - 0x80000000u)));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)d0 < (unsigned)e0), (unsigned)(x0 >> 70), (unsigned)s1); }
                v0 = ~((unsigned)(w0 >> 29) ? (unsigned)s0 : g0);
            }
            if (((r0.x ^ 0xffffffffu) << (3u & 31u))) {
                if ((unsigned)((int)p2 < (int)(unsigned)h0)) break;
            }
            while (i1++ < 4u && (unsigned)((int)u1 < (int)-(unsigned)((short)p2 > (signed char)0xe93a5a4eu))) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)(unsigned)x0 > (signed char)garr[u2 & 7u])) break;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)(0x10000u);
                }
                u0 = u0 * 0x9e3779b1u + u0;
                if (0x10000u) goto L0;
            }
        } else {
            a0[(unsigned)l0 & 3u] = ~((p1 << (~(unsigned)((short)1u > (signed char)(unsigned)l0) & 31u)) * a0[i0 & 3u]);
            h1 = (unsigned short)(h1 + (unsigned)!(m0 | (unsigned)(u1 == (unsigned)b0)));
        }
        garr[1u & 7u] = r0.y;
        s0 = (int)((unsigned)c1 / (((unsigned)l0 * 2u) | 1u));
        *mp = *mp;
        break; (void)(((unsigned)f0 ^ (u0 >> (u3 & 31u))));
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)(u1 && (unsigned)(a0[u1 & 3u] == (r0.y / (garr[i1 & 7u] | 1u))));
    goto L1;
    if ((unsigned)((int)1u < (int)0x10000u)) {
        q0 = &garr[((unsigned)b0 & 0x94eb373cu) & 7u];
        if (budget != 0u) { budget -= 1u; u2 = fn0(fuel, (u0 + u0), 0xf5610820u); }
    } else {
        if ((unsigned)!((unsigned)f0 << (~(i2 - (unsigned)c1) & 31u))) {
            u0 += (0x18e458bbu / ((unsigned)s0 | 1u));
            u0 += (unsigned)((short)(unsigned)c1 > (signed char)((unsigned)s0 | (unsigned)h0));
            g0 = (unsigned)(((unsigned)d0 % ((unsigned)(*mp < r0.x) | 1u)) || (unsigned)(short)(r0.x / (garr[u2 & 7u] | 1u)));
            if ((0xffffffffu / (u2 | 1u))) goto L3;
        }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0(fuel, (unsigned)((int)(unsigned)((int)0x87a4bc00u < (int)0xc6b18890u) >= (int)i1), (*q0 * (i1 / (0x30f0c137u | 1u)))); }
    while (i0++ < 2u && (unsigned)(unsigned char)((unsigned)c0 ^ m0)) { if (--fuel == 0u) goto done;
        break; (void)(i1);
        v0 = (unsigned)(0x10000u == 0xffffffffu);
        while (i1++ < 4u && (unsigned)((int)(unsigned)s1 < (int)u2)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)((unsigned)c1 ? p2 : fuel), (unsigned)(a0[u1 & 3u] < (unsigned)(signed char)(0x73808ceau / (u2 | 1u))), 0x6bf74448u); }
            break; (void)(((unsigned)(w0 >> 29) / (u3 | 1u)));
            if ((unsigned)c1) break;
        }
        if (((unsigned)b0 >> ((a0[u1 & 3u] % (0xf7edb1cu | 1u)) & 31u))) {
            switch ((unsigned)((unsigned)l0 == (unsigned)!(0x8ab267a4u << ((unsigned)d0 & 31u))) & 7u) {
                u0 = u0 * 0x9e3779b1u + (unsigned)(signed char)((unsigned)(0x9e8657deu || (unsigned)e0) ^ i2);
                *q0 += (unsigned)s1;
                do { if (--fuel == 0u) goto done;
                    c1 = (signed char)(v0 & 0xffffffffu);
                    case 0u: ;
                    if ((u0 + 0xa155f6b2u)) goto L0;
                    *q0 += (unsigned)(short)(0xf86ee441u / (v0 | 1u));
                    h0 = (short)(unsigned)((int)u1 >= (int)0x56eb24d3u);
                } while (i1++ < 2u && (0x10000u * 0x606c2e51u));
            }
            r0.x = (0x561e593au | -(unsigned)((int)(unsigned)((unsigned)x0 || i1) >= (int)(unsigned)((short)*mp > (signed char)(unsigned)f0)));
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s0 ? r0.x : garr[u2 & 7u]), (unsigned)(signed char)(unsigned)((int)g0 < (int)8u), (0xe067cdf0u >> (p1 & 31u))); }
        }
        e0 = e0 * 0.5L + (long double)((unsigned)(short)((garr[u2 & 7u] | (unsigned)(i1 == (unsigned)s1)) * i2) & 1023u);
        if (i2) {
            if ((unsigned)s1) goto L4;
            { unsigned t11; double z11; if ((((unsigned)c1 / (p0 | 1u))) & 1u) { t11 = (0xe4e5701cu % ((g0 % (u3 | 1u)) | 1u)); z11 = (double)((u3) & 255u); } if ((((unsigned)c1 / (p0 | 1u))) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
                s1 = (int)((unsigned)s1 + 0x51817525u);
                *q0 = ((~((unsigned)h1 | (unsigned)(0x8d833697u && u1)) & (unsigned)c1) << ((unsigned)s1 & 31u));
            }
        } else {
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)0xe4deb017u >= (int)0x13ef2b30u)) break;
                *q0 += (unsigned)((0xf6eb1184u << (0xffffffffu & 31u)) < (unsigned)(garr[i1 & 7u] == (unsigned)(short)(g0 * a0[u1 & 3u])));
                if (budget != 0u) { budget -= 1u; u1 = fn0(0xffffffffu, (unsigned)(0xffffffffu || 0x80000000u), 0x6276565bu); }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((*q0 ^ (unsigned)c0) < (unsigned)f0), r0.x, (unsigned)((int)v0 < (int)0xb8c35b5fu)); }
            if (budget != 0u) { budget -= 1u; u0 = fn0((i1 + (unsigned)h0), (((unsigned)c0 | u3) / (0u | 1u)), ((0x7fffffffu >> (a0[i0 & 3u] & 31u)) / (*q0 | 1u))); }
            i1 = (0xd7136469u << ((unsigned)s0 & 31u)) & 15u;
        }
    }
    a0[*mp & 3u] = (0xa20423adu ^ 0xb4b1c897u);
    if (~((r0.y >> (*mp & 31u)) >> (m0 & 31u))) goto L0;
    switch ((*mp / (u3 | 1u)) & 7u) {
        case 5u: ;
        if ((garr[i1 & 7u] * 1u)) {
            { unsigned t12; double z12; if (((unsigned)((unsigned)(unsigned char)(0xa44111eau * (unsigned)l0) == (unsigned)c0)) & 1u) { t12 = u3; z12 = (double)((0xd6ac1e6du) & 255u); } if (((unsigned)((unsigned)(unsigned char)(0xa44111eau * (unsigned)l0) == (unsigned)c0)) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
                i1 = (unsigned)((int)(5u << (i1 & 31u)) < (int)(unsigned)((short)(unsigned)s0 > (signed char)p1)) & 15u;
                if (*q0) {
                    r0.x = ((unsigned)((int)(unsigned)h1 < (int)0x10000u) * i1);
                    switch (8u & 7u) {
                        f0 = f0 * 0.5f + (float)(((unsigned)d0 >> ((1u * (unsigned)((int)0x33b5201fu >= (int)0x10000u)) & 31u)) & 255u);
                    }
                    goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)p2 >= (int)(unsigned)((int)(unsigned)d0 >= (int)7u)), (unsigned)c1, r0.y); }
                }
                if (u2) break;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)s1, ((0xb0570ca0u * (unsigned)l0) << ((unsigned)s0 & 31u)), (unsigned)c0); }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(w0 >> 29) || (unsigned)l0), (unsigned)((int)m0 < (int)0x10000u), 0xb7e8bd86u); }
            }
        }
        u1 ^= (unsigned)s1;
        if (u3 == 7u) return (unsigned)(short)((unsigned)((int)6u >= (int)0x6be01211u) >> ((unsigned)((unsigned)s1 < (unsigned)((unsigned)c0 || *q0)) & 31u));
        if ((0x3332a504u >> (garr[i1 & 7u] & 31u))) goto L2;
        g1 += ((0x80000000u ^ v0) + (0x80000000u * (unsigned)((unsigned)(x0 >> 70) && i0)));
    }
    if ((g1 + i2)) goto L1;
    d0 = d0 * 0.5 + (double)((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)((int)garr[i1 & 7u] < (int)(unsigned)d0)) & 1023u);
    goto L1;
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)p2 >= (int)(unsigned)d0);
    w0 = w0 * 6364136223846793005ull + ((0x48ef3dd3u - 0x31664cd0u) | (6u & 0u));
    s1 = (int)((unsigned)s1 + fuel);
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        continue; (void)(((unsigned)(w0 >> 29) % (((unsigned)(x0 >> 70) ^ i1) | 1u)));
        if ((0x38089249u & (unsigned)((int)(unsigned)b0 < (int)(unsigned)(w0 >> 29)))) break;
        u3 = u3 * 0x9e3779b1u + (unsigned)((int)(unsigned)e0 < (int)(4u << (0x10000u & 31u)));
        f0 = f0 * 0.5f + (float)(((~(unsigned)((unsigned)(signed char)(unsigned)((int)(unsigned)d0 >= (int)(unsigned)b0) || garr[i1 & 7u]) % ((unsigned)b0 | 1u)) % (p1 | 1u)) & 255u);
        if ((unsigned)d0) break;
    }
    while (i0++ < 4u && (garr[i1 & 7u] >> ((unsigned)((int)(unsigned)s0 < (int)m0) & 31u))) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)f0 & 7u) {
                switch ((unsigned)((unsigned)d0 && 0xc6f35258u) & 7u) {
                    garr[(*mp & (unsigned)h1) & 7u] = m0;
                    while ((unsigned)((int)(unsigned)f0 >= (int)i2)) { if (--fuel == 0u) goto done;
                        r0.x = ((0x521f9a2cu ? 0x7fffffffu : 7u) / (a0[i0 & 3u] | 1u));
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(r0.y << (v0 & 31u)), (unsigned)((unsigned)((int)2u >= (int)1u) && a0[u1 & 3u]), (fuel + i1)); }
                        w0 ^= (unsigned long long)garr[u2 & 7u] << ((unsigned)(0x80000000u == m0) & 63u);
                        g1 += (unsigned)((unsigned)((p1 >> (g0 & 31u)) == ((unsigned)c0 | i0)) == g0);
                    }
                }
                l0 = (long)((unsigned long)l0 + (unsigned)(a0[i0 & 3u] < 0x10000u));
                r0.x = p1;
                w0 = w0 * 6364136223846793005ull + (0x10000u * m0);
                d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(unsigned)((short)(unsigned)e0 > (signed char)0x7f9e5f0u) & 1023u);
                c0 = (unsigned char)7u;
            }
            g1 += (unsigned)((a0[u1 & 3u] >> (i2 & 31u)) == (0x10000u << (m0 & 31u)));
            r0.x = -(unsigned)((int)(unsigned)(0x80000000u < (i1 % ((unsigned)(w0 >> 29) | 1u))) < (int)(unsigned)(i0 < (unsigned)(w0 >> 29)));
            if ((p2 * (unsigned)s1)) break;
            if (p0) {
                w0 = w0 * 6364136223846793005ull + ((unsigned)h0 % ((unsigned)((int)(unsigned)((int)r0.x >= (int)0u) < (int)9u) | 1u));
                if (fuel < 8u) return (((unsigned)x0 | (unsigned)((short)a0[u1 & 3u] > (signed char)0x7fffffffu)) % ((fuel - *q0) | 1u));
                *q0 = (unsigned)x0;
                if (p0) {
                    switch (((unsigned)s1 ^ (unsigned)((int)(unsigned)(x0 >> 70) >= (int)r0.x)) & 7u) {
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)0x80000000u >= (int)0xffffffffu), (unsigned)((short)i1 > (signed char)m0), 9u); }
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)s1 || u0), (unsigned)(unsigned char)(((unsigned)c1 + p1) << ((unsigned)s0 & 31u)), (unsigned)l0); }
                        case 2u: ;
                    }
                }
                m0 ^= ~(p1 >> ((unsigned)f0 & 31u));
            } else {
                if (u3 == 7u) return (unsigned)(r0.y || (0x80000000u << (7u & 31u)));
            }
        }
    }
    r0.x = (unsigned)(0xffffffffu == v0);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch ((unsigned)(unsigned char)(0x69786eb1u | (unsigned)f0) & 7u) {
        f0 = f0 * 0.5f + (float)((unsigned)(8u == (unsigned)(0x4826fb0cu < (unsigned)(signed char)(0xffffffffu / (3u | 1u)))) & 255u);
        if ((0x10000u >> ((0x7fffffffu * p2) & 31u))) {
            L0: if (--fuel == 0u) goto done;
            *q0 = 0x6ef16d52u;
            L1: if (--fuel == 0u) goto done;
            s0 = (int)(i0 >> ((-(unsigned)((unsigned)(p2 && 0xe80d8e63u) == 0x10000u) & (unsigned)d0) & 31u));
        }
        l0 = (long)((unsigned long)l0 + ((unsigned)(1u && fuel) * (0x7fffffffu ? m0 : (unsigned)d0)));
        { unsigned t0; double z0; if ((((u0 % (g0 | 1u)) + (unsigned)s0)) & 1u) { t0 = g0; z0 = (double)((i0) & 255u); } if ((((u0 % (g0 | 1u)) + (unsigned)s0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                u3 ^= (u3 >> (((p1 >> (r0.x & 31u)) & (unsigned)((unsigned)s1 && 3u)) & 31u));
                do { if (--fuel == 0u) goto done;
                    L2: if (--fuel == 0u) goto done;
                } while (i1++ < 3u && ((unsigned)e0 / (0x67c8fe0eu | 1u)));
            }
        }
        do { if (--fuel == 0u) goto done;
            break; (void)(((unsigned)((int)0x7fffffffu >= (int)p1) - r0.y));
        } while (i0++ < 6u && (u0 - (unsigned)l0));
        if ((unsigned)x0) goto done;
    }
    goto L1;
    e0 = e0 * 0.5L + (long double)((0x68aac750u - (unsigned)(signed char)((0x7fffffffu >> ((0x10000u | 8u) & 31u)) - u2)) & 1023u);
    switch ((fuel + (unsigned)(0u < i1)) & 7u) {
        L3: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(g1 && fuel), (u3 / (0xffffffffu | 1u)), ((unsigned)((short)3u > (signed char)a0[u1 & 3u]) - 0xffffffffu)); }
    }
    if ((p2 ^ (unsigned)h0)) goto L1;
    L4: if (--fuel == 0u) goto done;
    if ((i2 % (garr[i1 & 7u] | 1u))) goto L1;
    h0 = (short)(((unsigned)((short)0x7fffffffu > (signed char)0x80000000u) ? 0x5eb22ffbu : r0.y) / ((unsigned)c1 | 1u));
    if (~(unsigned)(fuel < p1)) {
        garr[0x7fffffffu & 7u] = (unsigned)(u3 == g1);
    } else {
        i1 = ((p1 / ((unsigned)(fuel == 6u) | 1u)) / ((unsigned)s0 | 1u)) & 15u;
        do { if (--fuel == 0u) goto done;
            if ((0xcab49f28u + i1)) {
                s1 = (int)((unsigned)s1 + (((unsigned)((unsigned)e0 || *mp) | 0x10000u) >> ((0xd406cd05u + 0xef550131u) & 31u)));
            } else {
                if ((unsigned)l0) goto L1;
                *mp = (unsigned)!((unsigned)s0 / ((unsigned)((int)0x6d6e7dbbu >= (int)(unsigned)d0) | 1u));
            }
            switch ((unsigned)(short)(0x80000000u % ((m0 >> (*q0 & 31u)) | 1u)) & 7u) {
                u0 ^= r0.x;
            }
        } while (i0++ < 3u && (unsigned)((int)0x10000u >= (int)i1));
    }
    if (((unsigned)((unsigned)x0 < (unsigned)h1) >> (r0.x & 31u))) {
        u2 = u2 * 0x9e3779b1u + ((unsigned)((int)garr[i1 & 7u] < (int)1u) / (((unsigned)h1 * *q0) | 1u));
        switch (0xc96d9b53u & 7u) {
            if ((unsigned)(short)(0x9bab6367u & i0)) {
                w0 ^= (unsigned long long)((unsigned)s1 + (unsigned)l0) << ((unsigned)(unsigned char)((unsigned)s1 ? (unsigned)b0 : (unsigned)x0) & 63u);
            } else {
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(a0[u1 & 3u] < (unsigned)(fuel < p1)), ((unsigned)l0 & 0x8cbbcc82u), ((unsigned)x0 % ((unsigned)s1 | 1u))); }
                for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t1; double z1; if ((*q0) & 1u) { t1 = garr[u2 & 7u]; z1 = (double)((m0) & 255u); } if ((*q0) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                        s1 = (int)((unsigned)s1 + (garr[u2 & 7u] * 0x2d85cc3du));
                        case 3u: ;
                        u2 ^= (unsigned)((int)3u >= (int)0x10000u);
                        case 1u: ;
                    }
                    if (((unsigned)x0 * 0x80000000u)) {
                        default: ;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)h1 == (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x7096a08u)), 0xa6544aa1u, ((unsigned)((short)*mp > (signed char)g0) >> (p2 & 31u))); }
                        if (g0) continue;
                        x0 = x0 * 0x100000001b3ull + (unsigned)(short)((unsigned)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x7fffffffu) && (u1 * (unsigned)x0)) >> (v0 & 31u));
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)(unsigned)((short)g1 > (signed char)4u) < (int)0x10000u), (unsigned)((int)(m0 | 7u) >= (int)0xa2f787au), (unsigned)h1); }
                    } else {
                        l0 = (long)((unsigned long)l0 + -(a0[u1 & 3u] ? g1 : u3));
                        break; (void)((unsigned)(5u || (unsigned)l0));
                    }
                }
                while (i0++ < 2u && (unsigned)((int)(unsigned)!(unsigned)(0x7fffffffu || u3) < (int)8u)) { if (--fuel == 0u) goto done;
                    if ((unsigned)(short)(m0 - 0u)) goto L1;
                    case 7u: ;
                    break;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(x0 >> 70), (0x10000u ^ r0.x), (unsigned)!((unsigned)!((unsigned)s0 >> (0x3a2fe182u & 31u)) % (0x7fffffffu | 1u))); }
                }
            }
        }
        s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)((unsigned)(g0 == (unsigned)((short)3u > (signed char)(unsigned)f0)) | (unsigned)((int)0x7fffffffu < (int)0x1324cc53u)));
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        s0 = (int)(unsigned)((short)g1 > (signed char)((unsigned)w0 % (garr[i1 & 7u] | 1u)));
        if (((3u / ((unsigned)c0 | 1u)) - v0)) continue;
        goto L4;
        { unsigned t2; double z2; if (((unsigned)h1) & 1u) { t2 = ((0xffffffffu >> (u2 & 31u)) ^ (unsigned)c1); z2 = (double)((3u) & 255u); } if (((unsigned)h1) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            q0 = &garr[(9u ? (garr[i1 & 7u] - u3) : (unsigned)((unsigned)f0 == 2u)) & 7u];
            *q0 = (0x10000u % (g1 | 1u));
            while (i1++ < 3u && p0) { if (--fuel == 0u) goto done;
                break; (void)(0x246a9fdcu);
                if (budget != 0u) { budget -= 1u; u0 = fn1((a0[u1 & 3u] * fuel), ~(unsigned)((short)(unsigned)c1 > (signed char)5u), ((unsigned)((int)p0 >= (int)7u) >> (u2 & 31u))); }
                if (((unsigned)d0 << ((unsigned)((short)p2 > (signed char)g1) & 31u))) break;
                if ((unsigned)(*q0 || u2)) continue;
            }
            s1 = (int)((unsigned)s1 + (unsigned)((0x10000u * (unsigned)w0) < (unsigned)((int)8u < (int)i0)));
            v0 = u3;
            break; (void)((0x3cbb59afu + (unsigned)((int)v0 < (int)u0)));
        }
        if ((unsigned)w0) {
            w0 ^= (unsigned long long)(unsigned)l0 << ((unsigned)c0 & 63u);
            g1 += ((unsigned)c0 & ((*mp % (r0.x | 1u)) ? 0x1265b311u : u1));
            switch (-(i2 ^ 0xffffffffu) & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn0(i0, (0xffffffffu & *mp), ((unsigned)w0 / ((unsigned)l0 | 1u))); }
            }
            switch ((m0 ^ (unsigned)w0) & 7u) {
                i2 = (((unsigned)f0 - (unsigned)f0) / ((unsigned)f0 | 1u)) & 15u;
            }
        }
        b0 = (v0 / ((m0 + (((unsigned)s1 * 0xffffffffu) & 0x17019eb1u)) | 1u)) != 0u;
    }
    c0 = (unsigned char)(garr[u2 & 7u] + ((unsigned)b0 ? p2 : (6u << (garr[i1 & 7u] & 31u))));
    b0 = (garr[u2 & 7u] % (u2 | 1u)) != 0u;
    *q0 = (((unsigned)s0 - u3) % ((unsigned)((int)p0 < (int)0x10000u) | 1u));
    if (((unsigned)c0 | (unsigned)f0)) {
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.x = ((unsigned)((int)(unsigned)x0 < (int)0xd0356005u) >> (i2 & 31u));
            i2 = (unsigned)(((unsigned)c0 * 0x8072a9e8u) || ((v0 * 1u) | g0)) & 15u;
            if ((r0.y | (g1 % (4u | 1u)))) break;
            if ((unsigned)l0) break;
        }
        { unsigned t3; double z3; if ((*q0) & 1u) { t3 = (unsigned)((unsigned)b0 == *mp); z3 = (double)((*q0) & 255u); } if ((*q0) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            goto L2;
            switch ((unsigned)(a0[i0 & 3u] && a0[i0 & 3u]) & 7u) {
                if ((0x7fffffffu / (((unsigned)b0 >> ((unsigned)(w0 >> 29) & 31u)) | 1u))) break;
                case 7u: ;
                { unsigned t4; double z4; if (((0xffffffffu % (garr[i1 & 7u] | 1u))) & 1u) { t4 = (unsigned)l0; z4 = (double)(((unsigned)(p0 < u3)) & 255u); } if (((0xffffffffu % (garr[i1 & 7u] | 1u))) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                    switch (garr[i1 & 7u] & 7u) {
                        if (0x1cd95e14u) {
                            case 3u: ;
                            if (u3) goto done;
                            case 2u: ;
                            case 1u: ;
                            if ((unsigned)(g1 < 0x80000000u)) goto L4;
                            g0 = ~(*mp % ((unsigned)s1 | 1u));
                        } else {
                            case 7u: ;
                        }
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(a0[i0 & 3u] && g1), (unsigned)(r0.y == a0[u1 & 3u]), (unsigned)(0x96398036u && 0xb6df5749u)); }
                    case 1u: ;
                }
                case 0u: ;
                garr[(1u << (0xb213b079u & 31u)) & 7u] = (garr[i1 & 7u] ? m0 : *mp);
                if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)s1 << (p2 & 31u)), (6u & 0x30d0e498u), 0x80000000u); }
            }
            h1 = (unsigned short)(h1 + (unsigned)((unsigned)l0 || a0[u1 & 3u]));
            *q0 = (unsigned)(short)((unsigned)(signed char)(unsigned)((int)(p2 ^ garr[i1 & 7u]) < (int)(0xffffffffu / ((unsigned)c0 | 1u))) + i0);
        }
        *q0 += a0[u1 & 3u];
        if (((0xf6f17838u >> (0x10000u & 31u)) - (unsigned)(w0 >> 29))) goto L4;
        if ((garr[i1 & 7u] * ((unsigned)l0 << (0x10000u & 31u)))) goto L3;
    } else {
        h0 = (short)((unsigned)((int)v0 >= (int)0x35f5dd5eu) << ((unsigned)e0 & 31u));
    }
    u3 = (0x6f9fa824u & (unsigned)(garr[i1 & 7u] && 0x73590f18u));
    goto L0;
    if (1u) {
        while (i0++ < 3u && ((0x10000u % (g0 | 1u)) % (m0 | 1u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1((1u - 0x7fffffffu), r0.y, 3u); }
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)(unsigned)h0 > (signed char)((unsigned)(x0 >> 70) << ((unsigned)x0 & 31u))), ((unsigned)l0 & g0), (u0 >> (i1 & 31u))); }
                l0 = (long)((unsigned long)l0 + ((p1 | (unsigned)b0) ^ (unsigned)f0));
                if ((8u | 0xb32f5f18u)) {
                    if ((unsigned)(p1 && 0x64f2074fu)) break;
                    m0 ^= (unsigned)w0;
                    h1 = (unsigned short)(h1 + (unsigned)(((unsigned)s1 ^ (unsigned)(u0 == (unsigned)f0)) || (unsigned)((int)0x7fffffffu >= (int)0xad4492f6u)));
                    while (i2++ < 6u && 0xffffffffu) { if (--fuel == 0u) goto done;
                        u1 = fuel;
                        do { if (--fuel == 0u) goto done;
                            garr[(unsigned)(v0 && garr[u2 & 7u]) & 7u] = (unsigned)(~(unsigned)((unsigned)h0 == u0) || ((g0 & 2u) & 1u));
                            b0 = (unsigned)((unsigned)(((unsigned)c1 * 0xc95dc23au) == (unsigned)s0) || (unsigned)((int)*mp >= (int)(unsigned)c0)) != 0u;
                            if (a0[i0 & 3u]) break;
                            if (fuel < 8u) return (g0 ? ((unsigned)h0 % (u1 | 1u)) : (unsigned)!(m0 * a0[i0 & 3u]));
                            r0.y ^= ((unsigned)(0xa28938du < 0x80000000u) - r0.x);
                            continue; (void)(0x80000000u);
                        } while (i0++ < 3u && v0);
                        break; (void)((unsigned)(short)(unsigned)(0x10000u < u2));
                        if ((0x7fffffffu ^ (unsigned)(unsigned char)(unsigned)(u3 || fuel))) break;
                        w0 = w0 * 6364136223846793005ull + ((unsigned)((short)p1 > (signed char)u1) * (0x5fe72968u % (0x80000000u | 1u)));
                    }
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1((0xf9cb08cdu >> ((unsigned)((unsigned)c0 && 0x185e9c40u) & 31u)), -(p2 >> (0u & 31u)), garr[i1 & 7u]); }
                l0 = (long)((unsigned long)l0 + (i1 ? m0 : (garr[u2 & 7u] ^ *mp)));
                s0 = (int)i0;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1((0x984259c8u >> ((unsigned)(signed char)(unsigned)(0x80000000u == garr[u2 & 7u]) & 31u)), r0.y, (unsigned)(x0 >> 70)); }
            *q0 = (g1 + (unsigned)(*mp && (unsigned)w0));
        }
        if (((unsigned)l0 << ((u3 - 0xffffffffu) & 31u))) goto L0;
        *q0 += 0x7fffffffu;
        if ((unsigned)(u0 && (unsigned)d0)) goto L3;
        if (v0) goto L4;
        if (a0[u1 & 3u]) goto L4;
    } else {
        { unsigned t5; double z5; if ((((unsigned)c0 ^ 0x7fffffffu)) & 1u) { t5 = a0[i0 & 3u]; z5 = (double)((0x7fffffffu) & 255u); } if ((((unsigned)c0 ^ 0x7fffffffu)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            if (((*q0 % (9u | 1u)) ^ u3)) goto L2;
        }
        e0 = e0 * 0.5L + (long double)(((unsigned)e0 + (unsigned)((int)i0 < (int)(unsigned)(u3 && 6u))) & 1023u);
    }
    while ((0xffffffffu * (u2 * m0))) { if (--fuel == 0u) goto done;
        g1 += (unsigned)(0x93f7b5du < 0x7fffffffu);
        c1 = (signed char)(0x7fffffffu ? (0xf68d1119u * (unsigned)((int)(unsigned)x0 < (int)(unsigned)h1)) : (unsigned)h1);
        f0 = f0 * 0.5f + (float)((unsigned)(0x7fffffffu || (unsigned)s1) & 255u);
        if (fuel < 8u) return (*q0 - (unsigned)(short)(u1 << (-(unsigned)((unsigned)d0 || 1u) & 31u)));
        if (garr[u2 & 7u]) goto L4;
    }
    g1 += (unsigned)s0;
    if (0xa0c3d2e3u) goto L3;
    switch ((i2 * ~(0xeef5e8a6u >> (r0.x & 31u))) & 7u) {
        if (u3 == 7u) return ((-(u2 ^ (unsigned)c1) - (unsigned)x0) ^ (u3 + 3u));
        r0.x = (0x10000u | (a0[i0 & 3u] ? g0 : (unsigned)x0));
        d0 = d0 * 0.5 + (double)((unsigned)((int)0x7fffffffu >= (int)fuel) & 1023u);
        goto L0;
    }
    *q0 = (unsigned)(unsigned char)(unsigned)(0x3d33388bu == 0x7fffffffu);
    switch (0x10000u & 7u) {
        case 7u: ;
        while (i0++ < 5u && ((unsigned)h1 & 0x80000000u)) { if (--fuel == 0u) goto done;
            { unsigned t6; double z6; if ((0x9ffac2ffu) & 1u) { t6 = garr[u2 & 7u]; z6 = (double)(((0x4eec49au * ((unsigned)h1 % (p1 | 1u)))) & 255u); } if ((0x9ffac2ffu) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                case 0u: ;
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 2u: ;
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)(unsigned)(0x10000u < 4u);
                        *q0 = (i1 | (unsigned)((int)0x33302185u >= (int)(unsigned)d0));
                        goto L2;
                        g1 += (unsigned)!(unsigned)((int)(unsigned)d0 >= (int)(unsigned)c1);
                        b0 = (unsigned)(0x5d883691u < (u1 - r0.y)) != 0u;
                        case 1u: ;
                    }
                    if ((0xc732876fu % ((unsigned)b0 | 1u))) {
                        if (u3 == 7u) return ((v0 * 0x166d368bu) % (i1 | 1u));
                        if (garr[u2 & 7u]) goto L4;
                        default: ;
                    } else {
                        a0[0x10000u & 3u] = ~(unsigned)((short)g0 > (signed char)i0);
                        while ((*mp & 6u)) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((u0 - r0.y) < (unsigned)e0), (unsigned)!(6u & 6u), (unsigned)((short)0x80000000u > (signed char)((unsigned)(w0 >> 29) | g0))); }
                            l0 = (long)((unsigned long)l0 + fuel);
                            case 5u: ;
                            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(x0 >> 70) ? (unsigned)f0 : p1), (unsigned)h0, (unsigned)(((unsigned)(x0 >> 70) & 4u) < (unsigned)c0)); }
                            break;
                            u1 ^= (0x10000u | r0.x);
                        }
                        i0 = 0xffffffffu & 15u;
                        *q0 += ((0xce311a4du ? r0.x : 0x73cbca25u) | u1);
                    }
                    switch (0x7fffffffu & 7u) {
                        if ((i0 & p2)) break;
                        case 3u: ;
                        case 2u: ;
                        default: ;
                    }
                    if ((unsigned)!(unsigned)(0x6137fbcau < (unsigned)l0)) break;
                }
            }
            if (((r0.x - (unsigned)f0) << (u2 & 31u))) continue;
            h0 = (short)(unsigned)(unsigned char)(unsigned)((unsigned)((int)0x2400ede7u < (int)(unsigned)(x0 >> 70)) || (unsigned)c1);
        }
        w0 = w0 * 6364136223846793005ull + ((unsigned)c0 % (-(unsigned)((unsigned)b0 && -(unsigned)((int)u2 >= (int)(*mp / ((unsigned)w0 | 1u)))) | 1u));
    }
    b0 = ((unsigned)c0 ^ i0) != 0u;
    if (budget != 0u) { budget -= 1u; u2 = fn0((9u / ((fuel % ((unsigned)w0 | 1u)) | 1u)), (unsigned)(r0.x == u0), -(unsigned)(0x9a70665du == (unsigned)c0)); }
    do { if (--fuel == 0u) goto done;
        if (u3 == 7u) return ((unsigned)c0 << ((a0[u1 & 3u] - r0.x) & 31u));
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= ((unsigned)((int)r0.y < (int)0xe8f9e074u) << (((unsigned)h0 >> ((unsigned)(0xffffffffu && (unsigned)c1) & 31u)) & 31u));
            u2 += (unsigned)((unsigned)x0 || (9u | 0x59df4e62u));
            e0 = e0 * 0.5L + (long double)(g1 & 1023u);
            i2 = (unsigned)(signed char)(unsigned)((int)u1 < (int)fuel) & 15u;
        }
    } while (i0++ < 7u && 9u);
    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)d0 >> (m0 & 31u)), 0xffffffffu, (0u + 0x80000000u)); }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)l0 == (p1 ^ v0))) goto L2;
        x0 = x0 * 0x100000001b3ull + ((unsigned)((int)(g0 >> (0x10000u & 31u)) < (int)(unsigned)(3u < i1)) ^ (unsigned)b0);
        if ((unsigned)((short)((unsigned)w0 * (unsigned)e0) > (signed char)r0.x)) {
            w0 = w0 * 6364136223846793005ull + ((((unsigned)b0 ^ p1) / (0xffffffffu | 1u)) ^ (r0.x + (unsigned)b0));
            r0.x = (unsigned)((short)0x1e67daefu > (signed char)(unsigned)(p1 < i0));
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(0xffffffffu < 8u), (unsigned)((unsigned)h1 && v0), (0x7fffffffu ? (unsigned)b0 : (unsigned)c0)); }
            { unsigned t7; double z7; if (((unsigned)(g0 && *mp)) & 1u) { t7 = (garr[i1 & 7u] ? i2 : 0x80000000u); z7 = (double)((((unsigned)s1 ? v0 : (unsigned)f0)) & 255u); } if (((unsigned)(g0 && *mp)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                if (-((unsigned)l0 * v0)) goto done;
            }
            u2 += 8u;
        }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            u0 ^= (unsigned)(x0 >> 70);
            if ((unsigned)l0) break;
            e0 = e0 * 0.5L + (long double)((unsigned)!((unsigned)(signed char)((unsigned)w0 << (0xffffffffu & 31u)) * (a0[u1 & 3u] | i0)) & 1023u);
        }
        u3 += *mp;
        if (0x5b726fddu) break;
    }
    w0 = w0 * 6364136223846793005ull + (0x10000u | (unsigned)((int)(unsigned)((short)(u2 & garr[i1 & 7u]) > (signed char)(unsigned)b0) >= (int)garr[u2 & 7u]));
    if (budget != 0u) { budget -= 1u; u3 = fn1(garr[u2 & 7u], 0xa9811833u, -(0xffffffffu >> (r0.y & 31u))); }
    if (3u) goto done;
    c1 = (signed char)(unsigned)((int)(unsigned)(0x7fffffffu && i2) < (int)u2);
    if ((fuel >> ((unsigned)((int)5u < (int)g1) & 31u))) goto L3;
    if ((unsigned)((int)0xffffffffu >= (int)(unsigned)(x0 >> 70))) {
        if ((unsigned)!(0x80000000u % (*mp | 1u))) {
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(~(g1 * (unsigned)c0), (unsigned)((unsigned)f0 && 1u), (unsigned)((int)0x10000u >= (int)((unsigned)(w0 >> 29) - 4u))); }
            }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn1(8u, ((0x10000u >> ((unsigned)(w0 >> 29) & 31u)) | *q0), 0x10000u); }
                a0[*q0 & 3u] = (unsigned)((unsigned)((int)(unsigned)(w0 >> 29) >= (int)g1) && ((unsigned)(w0 >> 29) | g1));
            } while (i0++ < 2u && (unsigned)(unsigned char)(unsigned)(~(fuel | u2) < p1));
            goto L4;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(garr[u2 & 7u] || -(0xb683a826u ^ p2)), (unsigned)!(unsigned)((unsigned)s1 || ~(unsigned)(0x80000000u < p0)), (garr[i1 & 7u] & (unsigned)((int)0xe7fd379fu >= (int)(unsigned)f0))); }
        u0 += (unsigned)((int)0u >= (int)((unsigned)((unsigned)h0 && g1) / ((unsigned)l0 | 1u)));
    } else {
        goto L0;
        if (((unsigned)c1 & garr[u2 & 7u])) goto L0;
    }
    f0 = f0 * 0.5f + (float)((unsigned)((int)((unsigned)((short)a0[u1 & 3u] > (signed char)9u) + 0xffffffffu) < (int)(unsigned)((int)a0[u1 & 3u] < (int)0x26cdb109u)) & 255u);
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)(short)(((unsigned)e0 ^ (a0[i0 & 3u] % (i0 | 1u))) * p2));
        while (0x7fffffffu) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(v0 || *mp) * 8u), ((unsigned)h1 & (u0 * g0)), ((0x10000u + (unsigned)w0) % ((unsigned)d0 | 1u))); }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)fuel > (signed char)(unsigned)h0), 0x7dacad39u, i2); }
        if ((unsigned)((short)(unsigned)((int)g0 < (int)*mp) > (signed char)0xdf3f1c1du)) break;
        if ((unsigned)((short)(unsigned)((int)v0 < (int)m0) > (signed char)0x80000000u)) break;
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)i0;
        switch ((unsigned)((short)i2 > (signed char)(i1 >> ((unsigned)x0 & 31u))) & 7u) {
            *q0 = 0x1ae4e268u;
            u1 ^= (0xdcd54b44u & (unsigned)((short)(unsigned)h1 > (signed char)8u));
            if ((unsigned)(w0 >> 29)) break;
            u3 += (unsigned)((short)0x45bdcebcu > (signed char)0x2264aa8au);
            s0 = (int)(unsigned)(signed char)(unsigned)(-(i2 ? (unsigned)(a0[u1 & 3u] == 0x10000u) : g0) && u1);
            if ((unsigned)((1u - (unsigned)h1) && (unsigned)b0)) {
                if ((unsigned)((unsigned)d0 == (unsigned)s0)) goto L4;
                if ((unsigned)((int)a0[i0 & 3u] >= (int)0xa95346bu)) continue;
            } else {
                case 7u: ;
                if (((unsigned)(signed char)(unsigned)((int)0u < (int)i2) << (0xde31f6b0u & 31u))) break;
                break; (void)((*q0 & (fuel & (unsigned)f0)));
                case 4u: ;
            }
        }
        *mp = ((unsigned)(unsigned char)(2u ? (unsigned)((int)0x30a85ad1u < (int)0x7fffffffu) : 2u) | 0x10000u);
    }
    x0 = x0 * 0x100000001b3ull + ((unsigned)d0 ? (g1 % (i2 | 1u)) : 1u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u3 = fn0((0x10000u << (0xd0fcabb0u & 31u)), (a0[u1 & 3u] + 1u), (a0[i0 & 3u] * u0)); }
    do { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (u1 & (i1 / ((unsigned)((unsigned)b0 || 4u) | 1u)));
    } while (i0++ < 4u && (u0 / ((p0 << ((unsigned)e0 & 31u)) | 1u)));
    if ((unsigned)l0) goto L2;
    if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0x80000000u) << ((unsigned)d0 & 31u))) goto L0;
    if ((6u ? 0xcc836a31u : u1)) {
        L0: if (--fuel == 0u) goto done;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 6u && (unsigned)((unsigned)w0 == i0)) { if (--fuel == 0u) goto done;
            g0 = (unsigned)((int)(unsigned)h1 >= (int)p2);
            { unsigned t0; double z0; if (((unsigned)(g0 && 0x89d44957u)) & 1u) { t0 = 0x289c79f0u; z0 = (double)(((unsigned)((unsigned)c0 && (unsigned)f0)) & 255u); } if (((unsigned)(g0 && 0x89d44957u)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                b0 = ((i2 - 2u) ? 0x7fffffffu : p1) != 0u;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)x0, u0, i1); }
                    switch (((u2 << (0xbbecbb6bu & 31u)) / (u2 | 1u)) & 7u) {
                        if ((unsigned)((int)*mp >= (int)3u)) continue;
                        if (budget != 0u) { budget -= 1u; u3 = fn2(7u, (unsigned)h1, ~(i2 + 0x8dd87fc2u)); }
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn1(garr[u2 & 7u], garr[u2 & 7u], ((unsigned)((unsigned)(w0 >> 29) || p1) - garr[u2 & 7u])); }
                    if ((v0 ^ (unsigned)((int)u2 < (int)0x10000u))) goto L1;
                    w0 = w0 * 6364136223846793005ull + (unsigned)c0;
                }
            }
            L1: if (--fuel == 0u) goto done;
        }
        L2: if (--fuel == 0u) goto done;
    }
    if (0xffffffffu) goto L3;
    if ((0xb5a320d7u / (4u | 1u))) {
        while (p0) { if (--fuel == 0u) goto done;
            switch ((unsigned)d0 & 7u) {
                while (i1++ < 4u && -(unsigned)(*q0 && (unsigned)f0)) { if (--fuel == 0u) goto done;
                    a0[fuel & 3u] = (3u % ((((unsigned)((int)m0 >= (int)(unsigned)d0) + (unsigned)h0) | 0x59fbc1cfu) | 1u));
                    garr[((unsigned)l0 + 0x10000u) & 7u] = (0x515dd3d7u - r0.x);
                }
            }
            switch ((*q0 / (0x10000u | 1u)) & 7u) {
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    u3 += (((unsigned)s0 - g1) / ((unsigned)h1 | 1u));
                    if (budget != 0u) { budget -= 1u; u1 = fn0(0x39025fccu, garr[u2 & 7u], (0x538e7c70u >> (0xe786b0ccu & 31u))); }
                }
            }
        }
    }
    f0 = f0 * 0.5f + (float)((unsigned)((int)-(unsigned)((int)r0.x >= (int)v0) < (int)m0) & 255u);
    if (budget != 0u) { budget -= 1u; u0 = fn1(((g0 / (*mp | 1u)) / ((unsigned)(x0 >> 70) | 1u)), (~(i1 * (unsigned)(x0 >> 70)) >> (1u & 31u)), (a0[i0 & 3u] * (0x10000u << (u1 & 31u)))); }
    a0[(i2 | *mp) & 3u] = (unsigned)(u3 == (unsigned)(w0 >> 29));
    L3: if (--fuel == 0u) goto done;
    do { if (--fuel == 0u) goto done;
        if (((unsigned)s1 - ((unsigned)w0 ^ (unsigned)b0))) continue;
        u2 = (garr[u2 & 7u] ? u2 : 0x61fca3a5u);
        g0 = -(((unsigned)((short)i2 > (signed char)3u) + (unsigned)b0) & 8u);
        if (budget != 0u) { budget -= 1u; u2 = fn1((0x7fffffffu * i2), 2u, (unsigned)((int)fuel >= (int)p1)); }
    } while (i0++ < 3u && (unsigned)(short)(unsigned)((int)0x14aa750fu < (int)(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)w0)));
    goto L4;
    c0 = (unsigned char)(unsigned)((unsigned)(p1 || (unsigned)f0) && (unsigned)((int)(unsigned)(0x80000000u == 6u) >= (int)0x7fffffffu));
    { unsigned t1; double z1; if (((m0 | (u3 | 4u))) & 1u) { t1 = (unsigned)(((unsigned)d0 / (0x80000000u | 1u)) || (unsigned)l0); z1 = (double)(((a0[i0 & 3u] << (g0 & 31u))) & 255u); } if (((m0 | (u3 | 4u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(r0.y == (p0 ^ 0x7125abf9u)), (g0 % (((unsigned)e0 + (unsigned)d0) | 1u)), (unsigned)(unsigned char)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)*q0)); }
        w0 ^= (unsigned long long)p1 << ((((unsigned)e0 % (r0.y | 1u)) ^ 0x80000000u) & 63u);
    }
    do { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (unsigned)(unsigned char)(unsigned)(((unsigned)f0 >> (*q0 & 31u)) < m0);
        l0 = (long)((unsigned long)l0 + (unsigned)(0x4af1395cu == (unsigned)(signed char)(u0 + (5u ^ 0x80000000u))));
        do { if (--fuel == 0u) goto done;
            u3 += u1;
            h1 = (unsigned short)(h1 + ((unsigned)f0 ? (garr[i1 & 7u] % (2u | 1u)) : (unsigned)(0x6452f2d8u < (unsigned)d0)));
        } while (i1++ < 4u && (*mp / (p0 | 1u)));
    } while (i0++ < 6u && (i1 << ((unsigned)((short)r0.x > (signed char)(unsigned)f0) & 31u)));
    if (budget != 0u) { budget -= 1u; u1 = fn0((a0[u1 & 3u] << (((unsigned)h1 & r0.x) & 31u)), (unsigned)((int)(unsigned)((unsigned)d0 == (unsigned)s0) >= (int)3u), (unsigned)(short)(unsigned)((unsigned)h1 < (unsigned)(0xf78985f0u < 0x7fffffffu))); }
    do { if (--fuel == 0u) goto done;
        L4: if (--fuel == 0u) goto done;
    } while (i0++ < 3u && (unsigned)(w0 >> 29));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (0x3f73407fu ? (unsigned)((int)(unsigned)l0 < (int)(m0 << (1u & 31u))) : 7u);
        l0 = (long)((unsigned long)l0 + (0u & (unsigned)(short)(((unsigned)(x0 >> 70) / ((unsigned)(signed char)((unsigned)s1 + 6u) | 1u)) & 0x80000000u)));
        q0 = &garr[((unsigned)(unsigned char)(8u >> ((unsigned)((int)u1 < (int)(unsigned)(w0 >> 29)) & 31u)) % (garr[i1 & 7u] | 1u)) & 7u];
        { unsigned t2; double z2; if (((-((unsigned)l0 * (unsigned)d0) >> (g0 & 31u))) & 1u) { t2 = (unsigned)(g0 || (unsigned)(w0 >> 29)); z2 = (double)(((*mp | (unsigned)!(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)s0))) & 255u); } if (((-((unsigned)l0 * (unsigned)d0) >> (g0 & 31u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            if (0xffffffffu) break;
            break; (void)(i0);
            break; (void)((unsigned)((short)(unsigned)l0 > (signed char)i1));
            q0 = &garr[((unsigned)s0 + ((unsigned)h0 / ((u0 << ((0xffffffffu ^ (unsigned)b0) & 31u)) | 1u))) & 7u];
        }
    }
    if (((0x10000u + (unsigned)h0) ^ (unsigned)l0)) {
        c0 = (unsigned char)((0x10000u & (unsigned)f0) + ((unsigned)f0 << (0x7fffffffu & 31u)));
    }
    x0 = x0 * 0x100000001b3ull + 0x7534df61u;
    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)((int)p1 >= (int)a0[u1 & 3u]) / (i1 | 1u)), (unsigned)((short)u0 > (signed char)p1), 0u); }
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)h1 - (unsigned)s1), (unsigned)(unsigned char)(0x656fb64u << (0x80000000u & 31u)), (0x1c58e59cu ^ i0)); }
    if ((*mp << ((unsigned)c1 & 31u))) goto L2;
    if (budget != 0u) { budget -= 1u; u1 = fn2((garr[i1 & 7u] & (unsigned)s1), (unsigned)(*mp == (unsigned)s0), (0x7fffffffu % (6u | 1u))); }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= ((((unsigned)f0 % (0x80000000u | 1u)) ? (unsigned)w0 : (unsigned)f0) & 3u);
        r0.y ^= 0u;
        break; (void)((unsigned)(m0 || garr[i1 & 7u]));
        { unsigned t3; double z3; if ((i0) & 1u) { t3 = (garr[u2 & 7u] / (7u | 1u)); z3 = (double)((((unsigned)b0 << ((0xffffffffu / (*mp | 1u)) & 31u))) & 255u); } if ((i0) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            while (i1++ < 7u && (*mp * p1)) { if (--fuel == 0u) goto done;
                b0 = (unsigned)((int)1u < (int)(unsigned)(unsigned char)(unsigned)((unsigned)(x0 >> 70) == p0)) != 0u;
                h1 = (unsigned short)(h1 + (r0.x + (unsigned)((short)r0.y > (signed char)(unsigned)h0)));
                x0 = x0 * 0x100000001b3ull + (unsigned)(r0.x < a0[i0 & 3u]);
                do { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)((int)v0 >= (int)0x16251ea4u));
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((*mp + 0x7fffffffu) == u0), 0x80000000u, (unsigned)(3u || p0)); }
                    h0 = (short)garr[u2 & 7u];
                    { unsigned t4; double z4; if (((unsigned)f0) & 1u) { t4 = (unsigned)!((unsigned)w0 ^ u3); z4 = (double)((((unsigned)c0 & 0xffffffffu)) & 255u); } if (((unsigned)f0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                        u0 = (unsigned)((int)(unsigned)w0 < (int)p2);
                        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)w0, ((unsigned)h1 - 0x80000000u), (1u - 0xffffffffu)); }
                        s0 = (int)(((unsigned)((int)3u >= (int)~(i1 + (unsigned)c1)) - 0xffffffffu) + (unsigned)s1);
                    }
                    if (v0) break;
                    u0 = ~(unsigned)((int)u2 < (int)(unsigned)c1);
                } while (i2++ < 3u && (unsigned)f0);
            }
            switch ((0xbe0596b8u - garr[u2 & 7u]) & 7u) {
                break; (void)(garr[i1 & 7u]);
                case 3u: ;
                h0 = (short)(unsigned)(signed char)((unsigned)(i2 || 0x10000u) | 0x7fffffffu);
                do { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)(unsigned)((int)(unsigned)((0xffffffffu >> (0x2a78046fu & 31u)) == 0x7fffffffu) >= (int)(unsigned)(short)(unsigned)((int)(unsigned)c0 < (int)i1));
                        if (budget != 0u) { budget -= 1u; u3 = fn2(6u, (unsigned)(unsigned char)(0x790cfb04u * (unsigned)l0), 3u); }
                        b0 = (unsigned)(short)((unsigned)(a0[i0 & 3u] || (unsigned)c0) ? 6u : (unsigned)s1) != 0u;
                        while (i0++ < 2u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn2(((0x7fffffffu * (unsigned)f0) | v0), garr[i1 & 7u], (unsigned)((int)0xffffffffu >= (int)7u)); }
                            case 6u: ;
                            h0 = (short)2u;
                            q0 = &garr[r0.y & 7u];
                        }
                        u3 ^= ((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)(0x8bc391beu || u1)) | (unsigned)(short)(2u ^ 0x7fffffffu));
                    }
                    if (fuel < 8u) return (unsigned)(((r0.y % (garr[u2 & 7u] | 1u)) + fuel) < p1);
                } while (i1++ < 3u && (0x7fffffffu & (unsigned)b0));
                s0 = (int)(0u - (unsigned)(short)(1u + u3));
            }
            break; (void)(((unsigned)(9u || (unsigned)x0) & (unsigned)e0));
        }
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(5u && 0x164d0398u), (unsigned)c0, (unsigned)(x0 >> 70)); }
    }
    while (((7u | 0x3b1461e7u) - u2)) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(0xfb998970u && i0), (unsigned)(0xd94c2df2u == (i2 << (2u & 31u))), (unsigned)(garr[u2 & 7u] < (unsigned)w0)); }
    }
    while ((unsigned)(u0 && (unsigned)w0)) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if ((i2 << ((unsigned)e0 & 31u))) {
                u1 = u1 * 0x9e3779b1u + (unsigned)(((unsigned)(w0 >> 29) << (u2 & 31u)) == ((unsigned)(w0 >> 29) / (a0[i0 & 3u] | 1u)));
                goto L1;
                switch ((unsigned)h0 & 7u) {
                    if (budget != 0u) { budget -= 1u; u3 = fn0((a0[u1 & 3u] << ((unsigned)c1 & 31u)), -((unsigned)e0 - u0), (0x7fffffffu * ((unsigned)c0 + (unsigned)(w0 >> 29)))); }
                    h1 = (unsigned short)(h1 + (unsigned)((int)u3 >= (int)7u));
                    if (budget != 0u) { budget -= 1u; u0 = fn2(a0[i0 & 3u], i0, (unsigned)(signed char)((unsigned)h0 % (*mp | 1u))); }
                    case 2u: ;
                }
            } else {
                w0 = w0 * 6364136223846793005ull + (((unsigned)l0 << (p0 & 31u)) + ((0xffffffffu & i0) >> (fuel & 31u)));
            }
            r0.y ^= (unsigned)(unsigned char)(u2 ? a0[u1 & 3u] : ((0x80000000u + p0) * (unsigned)b0));
            if (((g1 | g1) << (garr[i1 & 7u] & 31u))) break;
        } while (i1++ < 2u && (unsigned)(signed char)(0x3c44a14fu * 3u));
        u3 ^= (a0[i0 & 3u] * ((unsigned)((int)3u < (int)-(fuel | 0xb8416701u)) & garr[u2 & 7u]));
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            while (i2++ < 5u && (unsigned)l0) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn1((garr[u2 & 7u] & ((unsigned)h1 << (p2 & 31u))), 0xffffffffu, (r0.x >> ((unsigned)((short)0x7fffffffu > (signed char)i1) & 31u))); }
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(g0 || (0x2b8676beu - (unsigned)l0)), i0, (unsigned)(short)(0x80000000u - u0)); }
                if ((unsigned)(w0 >> 29)) break;
                if (-(unsigned)(6u == 5u)) goto L0;
                while ((unsigned)(signed char)(0xffffffffu << (((unsigned)h0 ^ i2) & 31u))) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((0u / ((unsigned)w0 | 1u)), ((unsigned)(a0[u1 & 3u] == (unsigned)f0) >> (p1 & 31u)), g0); }
                }
            }
            b0 = ((unsigned)d0 << (garr[u2 & 7u] & 31u)) != 0u;
            if (r0.x) break;
        }
        garr[(unsigned)(w0 >> 29) & 7u] = (unsigned)((0x80000000u ? (unsigned)(x0 >> 70) : (unsigned)(2u && (unsigned)l0)) && (unsigned)c1);
        if (budget != 0u) { budget -= 1u; u2 = fn2(p1, *mp, ((*q0 + 0x80000000u) | (unsigned)w0)); }
        if ((unsigned)(unsigned char)(unsigned)(0xffffffffu && (i0 & (unsigned)l0))) goto L2;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)h1, (unsigned)((short)((unsigned)x0 >> (u3 & 31u)) > (signed char)u1), (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)d0)); }
    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)x0 * r0.y), (u1 | (unsigned)l0), (unsigned)(signed char)(unsigned)((int)i0 < (int)(unsigned)s1)); }
    if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)h1 + p1), (0x7fffffffu << (((unsigned)d0 / (i1 | 1u)) & 31u)), g0); }
    w0 ^= (unsigned long long)(unsigned)h1 << (-(unsigned)((((unsigned)s1 << (0u & 31u)) ^ (unsigned)h1) && (unsigned)((int)0xb7e2f4afu >= (int)0x89ddf8b2u)) & 63u);
    switch ((unsigned)(x0 >> 70) & 7u) {
        m0 ^= 0x7fffffffu;
        h1 = (unsigned short)(h1 + ((unsigned)c0 << ((unsigned)x0 & 31u)));
        case 6u: ;
    }
    g1 += (unsigned)((int)(unsigned)((int)0x67c3b430u >= (int)(unsigned)b0) < (int)9u);
    u1 = u1 * 0x9e3779b1u + 0x10000u;
    if ((unsigned)((short)(unsigned)l0 > (signed char)m0)) {
        *q0 += (unsigned)!(garr[i1 & 7u] ^ 0xa42744fu);
        switch ((unsigned)l0 & 7u) {
            if ((0x7fffffffu + -(7u ^ (unsigned)(w0 >> 29)))) {
                case 4u: ;
                x0 = x0 * 0x100000001b3ull + (unsigned)(short)(g1 * m0);
                if ((unsigned)((unsigned)s0 || (unsigned)s1)) goto L2;
            }
        }
        v0 = ((unsigned)((short)0u > (signed char)-(u3 / (p0 | 1u))) >> (3u & 31u));
        w0 = w0 * 6364136223846793005ull + i0;
        d0 = d0 * 0.5 + (double)((unsigned)s1 & 1023u);
    }
    r0.y ^= (unsigned)s1;
    while (i0++ < 3u && (unsigned)((unsigned)f0 && (unsigned)s1)) { if (--fuel == 0u) goto done;
        b0 = (unsigned)((unsigned)c1 || 0x80000000u) != 0u;
        do { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((int)(u2 >> (m0 & 31u)) >= (int)(unsigned)h0));
            { unsigned t5; double z5; if (((v0 & (unsigned)(unsigned char)(3u + a0[i0 & 3u]))) & 1u) { t5 = (unsigned)(unsigned char)((unsigned)x0 + r0.y); z5 = (double)((0x10000u) & 255u); } if (((v0 & (unsigned)(unsigned char)(3u + a0[i0 & 3u]))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                while (i2++ < 2u && i2) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((0x11924205u & (v0 ^ p2)), r0.x, g0); }
                    w0 ^= (unsigned long long)fuel << (((unsigned)(short)(unsigned)((unsigned)l0 && (unsigned)(x0 >> 70)) ^ (unsigned)w0) & 63u);
                    *q0 += 0x145e618u;
                }
                c1 = (signed char)((m0 & *mp) << ((unsigned)b0 & 31u));
            }
            x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)x0 == *mp) / (v0 | 1u));
            a0[(unsigned)(0x10000u == (unsigned)h1) & 3u] = (6u ^ (0x80000000u / (a0[u1 & 3u] | 1u)));
        } while (i1++ < 6u && (unsigned)((int)(p0 | 0xdf4ded8fu) < (int)0x7fffffffu));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)(signed char)(unsigned)((unsigned)(x0 >> 70) == garr[u2 & 7u]), (unsigned)(*mp == 0x25ec76a5u), (r0.y / ((p0 | r0.x) | 1u))); }
    c1 = (signed char)((unsigned)x0 + 0xffffffffu);
    *mp = ((unsigned)(short)(p2 * r0.x) & (unsigned)h0);
    for (;;) { if (--fuel == 0u) goto done;
        { unsigned t0; double z0; if (((i0 % (-(unsigned)((unsigned)c0 && i0) | 1u))) & 1u) { t0 = ~(i0 << (u3 & 31u)); z0 = (double)(((unsigned)(signed char)(g0 - (unsigned)b0)) & 255u); } if (((i0 % (-(unsigned)((unsigned)c0 && i0) | 1u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            while (i1++ < 2u && (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)((int)0xda18d324u < (int)8u))) { if (--fuel == 0u) goto done;
                goto L2;
                if (u3 == 7u) return (unsigned)(0x80000000u == 0x323d3f29u);
            }
        }
        if ((unsigned)(unsigned char)(0x10000u / ((unsigned)f0 | 1u))) continue;
        while (i1++ < 6u && (unsigned)(signed char)(a0[u1 & 3u] % (u2 | 1u))) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    for (;;) { if (--fuel == 0u) goto done;
                        *mp = (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)d0);
                        if (budget != 0u) { budget -= 1u; u2 = fn0(p2, (unsigned)b0, 0x10000u); }
                        if ((g0 << (0x4bb09492u & 31u))) {
                            s1 = (int)((unsigned)s1 + ((unsigned)e0 / (i2 | 1u)));
                        }
                    }
                    u3 += (unsigned)(0x4872365cu == ((unsigned)(w0 >> 29) * p2));
                    r0.y ^= ((unsigned)((short)(unsigned)w0 > (signed char)u0) % (m0 | 1u));
                    do { if (--fuel == 0u) goto done;
                        while (i2++ < 3u && (unsigned)h0) { if (--fuel == 0u) goto done;
                            i1 = *mp & 15u;
                            x0 = x0 * 0x100000001b3ull + garr[u2 & 7u];
                            r0.x = (unsigned)(*mp == (unsigned)((unsigned)(0x80000000u && 0xffffffffu) == ((unsigned)e0 & (unsigned)w0)));
                            if ((unsigned)l0) break;
                            if (u3 == 7u) return i1;
                        }
                        if (garr[i1 & 7u]) break;
                        u1 ^= a0[u1 & 3u];
                        L0: if (--fuel == 0u) goto done;
                        s0 = (int)(unsigned)((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)w0) == (unsigned)(w0 >> 29));
                        v0 = (unsigned)(signed char)(unsigned)((int)((unsigned)((int)p2 >= (int)g1) | a0[u1 & 3u]) < (int)r0.x);
                    } while (i1++ < 4u && (r0.x & (r0.x >> (u0 & 31u))));
                    L1: if (--fuel == 0u) goto done;
                } while (i0++ < 4u && ((unsigned)c1 % ((unsigned)(i2 || garr[i1 & 7u]) | 1u)));
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn1(((g1 & a0[u1 & 3u]) / (p2 | 1u)), -(unsigned)((unsigned)((int)r0.x >= (int)u0) && g0), 0x9223efafu); }
                    if (budget != 0u) { budget -= 1u; u0 = fn2(u3, a0[i0 & 3u], ((*mp % ((unsigned)b0 | 1u)) % (0xa9cc8798u | 1u))); }
                    goto L4;
                    c0 = (unsigned char)(((unsigned)e0 % ((0x3388885bu << ((p2 - (unsigned)e0) & 31u)) | 1u)) & p2);
                    L2: if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)((unsigned)d0 < (unsigned)s1) || (unsigned)s0), i1, garr[i1 & 7u]); }
                }
                { unsigned t1; double z1; if (((unsigned)(1u && (unsigned)e0)) & 1u) { t1 = (unsigned)(3u && (unsigned)(g0 && (unsigned)l0)); z1 = (double)(((unsigned)((int)(unsigned)(unsigned char)(unsigned)((short)(unsigned)b0 > (signed char)p1) >= (int)(unsigned)c1)) & 255u); } if (((unsigned)(1u && (unsigned)e0)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    w0 = w0 * 6364136223846793005ull + ~(unsigned)(i2 < (unsigned)b0);
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0xffffffffu * m0), ((unsigned)(g0 == i1) % (0x6a3ca51u | 1u)), (unsigned)e0); }
                    i2 = (unsigned)((unsigned)x0 || (unsigned)!(garr[u2 & 7u] + (unsigned)((short)0xf70270a5u > (signed char)*mp))) & 15u;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0xd9828fbau << (0xca42139u & 31u)), (unsigned)((unsigned)(6u == (unsigned)s0) < g0), p0); }
                }
            } while (i2++ < 2u && (unsigned)(p2 < r0.x));
            L3: if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)c1;
            do { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)((p2 << (0xffffffffu & 31u)) & (unsigned)((short)0xffffffffu > (signed char)0x80900d04u)) >= (int)garr[u2 & 7u]);
                v0 = ((*mp | (unsigned)(0xffffffffu && (unsigned)b0)) % ((unsigned)((int)p0 >= (int)p1) | 1u));
                if (budget != 0u) { budget -= 1u; u3 = fn0((*q0 << (garr[i1 & 7u] & 31u)), 0x7fffffffu, (p2 | (g0 % ((unsigned)d0 | 1u)))); }
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)(garr[u2 & 7u] || (unsigned)w0) == i1), ((unsigned)b0 + (unsigned)(short)(6u * garr[u2 & 7u])), fuel); }
                    if (i0) continue;
                }
            } while (i2++ < 6u && (unsigned)((int)g1 < (int)a0[u1 & 3u]));
        }
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(-(unsigned)((i2 & 0x7fffffffu) || garr[u2 & 7u]) ^ 0xd2c9162u);
            u3 = (((unsigned)f0 ? 0x2b9060c1u : (unsigned)((unsigned)f0 == 0x10000u)) | (unsigned)b0);
            i1 = r0.x & 15u;
            do { if (--fuel == 0u) goto done;
                u0 = u0 * 0x9e3779b1u + 6u;
                break; (void)(u3);
                s1 = (int)((unsigned)s1 + (g0 + (unsigned)((unsigned)c1 && p0)));
                h1 = (unsigned short)(h1 + (unsigned)((int)p1 >= (int)u2));
            } while (i2++ < 5u && ((unsigned)s1 & r0.y));
            d0 = d0 * 0.5 + (double)((unsigned)(signed char)(0x10000u | (unsigned)w0) & 1023u);
            if ((unsigned)(short)((unsigned)x0 & (unsigned)((short)u2 > (signed char)(unsigned)h1))) break;
        }
        if ((u0 ? (unsigned)f0 : p1)) break;
        while (i1++ < 6u && m0) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)(p2 & 255u);
            h0 = (short)(unsigned)(r0.y || (unsigned)((short)0x7fffffffu > (signed char)(unsigned)(w0 >> 29)));
        }
    }
    l0 = (long)((unsigned long)l0 + ((unsigned)f0 / (0x3beaea42u | 1u)));
    f0 = f0 * 0.5f + (float)((unsigned)((int)i1 < (int)((unsigned)h1 << (u1 & 31u))) & 255u);
    goto L2;
    u1 = u1 * 0x9e3779b1u + (unsigned)(x0 >> 70);
    w0 ^= (unsigned long long)(unsigned)!((unsigned)c1 * (unsigned)w0) << ((r0.x / (p0 | 1u)) & 63u);
    if (((p2 * (unsigned)w0) >> (0x7fffffffu & 31u))) goto L2;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (0xffffffffu & (unsigned)c0);
        *q0 = (unsigned)(u0 == ((unsigned)c0 ? 8u : (p0 * r0.x)));
        if (3u) break;
        u2 += ((unsigned)(unsigned char)(unsigned)((0x73107f64u % (i2 | 1u)) || 5u) / ((unsigned)s1 | 1u));
    }
    goto L3;
    if ((unsigned)((int)(fuel | 0x80000000u) < (int)u3)) goto L1;
    for (;;) { if (--fuel == 0u) goto done;
        if (1u) goto L3;
        if (0x10000u) goto L0;
        v0 = (p1 << ((u1 + (unsigned)(v0 || *mp)) & 31u));
    }
    f0 = f0 * 0.5f + (float)((p1 + 0x80000000u) & 255u);
    r0.x = ((i0 ? u3 : (unsigned)c0) & (unsigned)((unsigned)s1 < garr[u2 & 7u]));
    r0.x = (0xa66224du ^ m0);
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t2; double z2; if (((6u / (((unsigned)l0 ^ 0xdb4c0e22u) | 1u))) & 1u) { t2 = ((unsigned)c0 + r0.y); z2 = (double)((v0) & 255u); } if (((6u / (((unsigned)l0 ^ 0xdb4c0e22u) | 1u))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(g0 == ((unsigned)b0 * (unsigned)f0))) {
                    { unsigned t3; double z3; if ((g1) & 1u) { t3 = (unsigned)((unsigned)c1 < (i1 >> (r0.y & 31u))); z3 = (double)(((unsigned)(garr[u2 & 7u] == 0x77cc0efdu)) & 255u); } if ((g1) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                        w0 = w0 * 6364136223846793005ull + (unsigned)(short)(i0 ^ (unsigned)(signed char)(unsigned)((short)r0.x > (signed char)0x7fffffffu));
                        if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)w0, (unsigned)(1u == (unsigned)s0), (unsigned)(w0 >> 29)); }
                        if (budget != 0u) { budget -= 1u; u2 = fn2(fuel, (6u | ((unsigned)s0 * p0)), 3u); }
                    }
                    break; (void)((unsigned)((int)(unsigned)c1 >= (int)(unsigned)(short)(unsigned)(6u || (unsigned)l0)));
                    g0 = ((unsigned)(signed char)((unsigned)l0 ^ u0) ? 3u : (unsigned)d0);
                    if ((unsigned)f0) break;
                    if ((unsigned)d0) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((6u * 0xffffffffu) == u0), 0x7fffffffu, (1u >> (0x80000000u & 31u))); }
                }
                s0 = (int)(unsigned)x0;
                v0 = ~(fuel * p0);
            }
            { unsigned t4; double z4; if ((~(unsigned)(0x10000u || (g1 / (r0.y | 1u)))) & 1u) { t4 = 0x61225747u; z4 = (double)(((unsigned)(short)((unsigned)((int)g1 < (int)p1) + 0x7fffffffu)) & 255u); } if ((~(unsigned)(0x10000u || (g1 / (r0.y | 1u)))) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                break; (void)((i0 ^ (unsigned)l0));
            }
        }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)s1) {
                if (g0) goto L4;
            }
            w0 = w0 * 6364136223846793005ull + garr[u2 & 7u];
            break; (void)((unsigned)(g0 && 0xffffffffu));
        }
        f0 = f0 * 0.5f + (float)(((unsigned)d0 ? 0x10000u : *mp) & 255u);
        do { if (--fuel == 0u) goto done;
            break; (void)(u3);
            a0[0x7fffffffu & 3u] = (unsigned)((6u ^ g1) && (0x372e0c5du >> ((p1 >> (0x2210e898u & 31u)) & 31u)));
        } while (i1++ < 2u && (unsigned)((unsigned)b0 || (unsigned)(short)(unsigned)((short)r0.x > (signed char)0x7fffffffu)));
    }
    { unsigned t5; double z5; if ((0xfb7ab184u) & 1u) { t5 = (unsigned)((int)*mp >= (int)(unsigned)c0); z5 = (double)(((unsigned)h1) & 255u); } if ((0xfb7ab184u) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        d0 = d0 * 0.5 + (double)(garr[u2 & 7u] & 1023u);
        *mp = (unsigned)((short)(unsigned)c0 > (signed char)fuel);
        if (((p2 ^ *mp) | 0x7b58971fu)) goto done;
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            q0 = &garr[(unsigned)(i0 == ~(unsigned)(7u < (unsigned)((short)0x9151b35cu > (signed char)((unsigned)(x0 >> 70) % (i0 | 1u))))) & 7u];
            r0.x = fuel;
            if ((unsigned)c0) {
                c1 = (signed char)((unsigned)!(unsigned)((int)(unsigned)((int)(unsigned)f0 < (int)i0) < (int)(unsigned)l0) ? u2 : (unsigned)(w0 >> 29));
                if (~(unsigned)(u2 && v0)) continue;
                v0 = (unsigned)!((unsigned)(w0 >> 29) & (i2 / ((garr[i1 & 7u] >> (8u & 31u)) | 1u)));
                if ((p0 * a0[i0 & 3u])) break;
            }
            if ((unsigned)((int)0x10000u < (int)*q0)) goto L0;
            *mp = (u3 | r0.x);
        }
    }
    i1 = (unsigned)((unsigned)l0 < garr[u2 & 7u]) & 15u;
    i0 = (unsigned)(short)(garr[u2 & 7u] << ((~(unsigned)((unsigned)((int)0xffffffffu >= (int)(unsigned)f0) || (unsigned)d0) ^ u3) & 31u)) & 15u;
    f0 = f0 * 0.5f + (float)((unsigned)((short)fuel > (signed char)u0) & 255u);
    l0 = (long)((unsigned long)l0 + (unsigned)(short)(unsigned)((short)0x80000000u > (signed char)0xffffffffu));
    for (;;) { if (--fuel == 0u) goto done;
        s0 = (int)~(7u ^ (0xe095dc9u / (0xe1eab40bu | 1u)));
        do { if (--fuel == 0u) goto done;
            h0 = (short)((unsigned)(6u || (unsigned)h1) ? (unsigned)s1 : r0.x);
            a0[(p2 >> (g1 & 31u)) & 3u] = 0x7fffffffu;
            a0[(unsigned)s1 & 3u] = (a0[u1 & 3u] << (((0xea3a54au << (a0[u1 & 3u] & 31u)) + (unsigned)(signed char)(0x737bc586u >> (i0 & 31u))) & 31u));
        } while (i1++ < 6u && r0.y);
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1((((unsigned)x0 ^ (unsigned)c1) + 0x80000000u), (unsigned)s1, garr[i1 & 7u]); }
    } while (i0++ < 2u && g1);
    if (fuel < 8u) return u2;
    if ((unsigned)(p2 == (unsigned)s1)) {
        u0 ^= (~(unsigned)(u0 == (unsigned)h1) & (p1 % (garr[u2 & 7u] | 1u)));
        s0 = (int)(unsigned)(r0.x < (unsigned)((short)1u > (signed char)(unsigned)((int)i1 >= (int)(unsigned)c1)));
        if ((u1 | p1)) goto done;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)e0, u1, (unsigned)x0); }
    if ((unsigned)((int)(unsigned)(r0.y == 7u) < (int)(unsigned)c1)) {
        switch (-(unsigned)((short)i0 > (signed char)(0x80000000u ^ (unsigned)w0)) & 7u) {
            case 6u: ;
            garr[(unsigned)c0 & 7u] = (((unsigned)b0 % (g0 | 1u)) | ((unsigned)((int)0x4ee8920au >= (int)(unsigned)s1) & 0x80000000u));
            u0 ^= (r0.x ? u0 : garr[u2 & 7u]);
            if ((unsigned)!(m0 ? g1 : u3)) break;
            while (i0++ < 5u && (0xc978a38du >> (((unsigned)w0 >> ((unsigned)(x0 >> 70) & 31u)) & 31u))) { if (--fuel == 0u) goto done;
                b0 = (unsigned)((int)g0 >= (int)m0) != 0u;
            }
        }
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + (unsigned)(r0.y && (unsigned)((int)v0 >= (int)7u)));
            if ((unsigned)((unsigned)h0 && 0x6f3abd2u)) break;
        }
        if (fuel < 8u) return ((unsigned)(p2 == (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)d0)) + ((unsigned)s1 / (0x80000000u | 1u)));
        if (budget != 0u) { budget -= 1u; u2 = fn1(0x9ce66d4cu, ((unsigned)(u3 && (unsigned)w0) / (0x7fffffffu | 1u)), (0x42335cb7u / (u1 | 1u))); }
    } else {
        goto L1;
        r0.x = (((unsigned)(x0 >> 70) ? 0xa41d095eu : (unsigned)c0) + a0[i0 & 3u]);
        c1 = (signed char)((unsigned)c1 / (((*mp - 0x31fa316au) * g0) | 1u));
    }
    goto done;
    switch ((p0 ^ ((unsigned)h1 / (3u | 1u))) & 7u) {
        l0 = (long)((unsigned long)l0 + (4u >> ((unsigned)d0 & 31u)));
        r0.x = (u2 - (unsigned)(unsigned char)(unsigned)(garr[i1 & 7u] || (unsigned)(short)(unsigned)((int)v0 < (int)((unsigned)l0 >> (a0[i0 & 3u] & 31u)))));
        case 7u: ;
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((p0 - 0x7fffffffu) & 7u) {
            case 3u: ;
            *q0 += ((*mp * (unsigned)s0) % ((unsigned)w0 | 1u));
        }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t6; double z6; if ((-(unsigned)((0u & garr[u2 & 7u]) || (unsigned)(x0 >> 70))) & 1u) { t6 = ((unsigned)(w0 >> 29) / ((0x4d3a9a30u >> ((unsigned)x0 & 31u)) | 1u)); z6 = (double)((0x7fffffffu) & 255u); } if ((-(unsigned)((0u & garr[u2 & 7u]) || (unsigned)(x0 >> 70))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                if (u3 == 7u) return (0xffffffffu * *mp);
                if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)(3u < (unsigned)((int)(unsigned)d0 < (int)0x85c99366u)), (0x72466b3du & p2), (unsigned)w0); }
                if ((unsigned)(short)(unsigned)((int)(unsigned)(short)(unsigned)((int)0x9d6f5c75u < (int)0x10000u) >= (int)u1)) break;
            }
            v0 = v0;
        }
    }
    if ((unsigned)(i2 && i0)) goto L0;
    g0 = ((unsigned)(x0 >> 70) * (unsigned)(short)((p1 ^ (p2 | r0.x)) - v0));
    switch ((unsigned)((int)4u >= (int)u0) & 7u) {
        l0 = (long)((unsigned long)l0 + (g0 & ((unsigned)d0 + (unsigned)((short)0x1452e304u > (signed char)m0))));
        { unsigned t7; double z7; if ((i0) & 1u) { t7 = 0xffffffffu; z7 = (double)(((unsigned)l0) & 255u); } if ((i0) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
            u3 ^= (unsigned)((unsigned)(u0 || i0) && (1u / (0xe452700eu | 1u)));
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)w0, (unsigned)((unsigned)(short)(7u | (unsigned)s0) || (unsigned)c0), garr[i1 & 7u]); }
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                while (i1++ < 7u && (0x10000u * (0x10000u / (garr[u2 & 7u] | 1u)))) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)(g0 && a0[i0 & 3u]) & 1023u);
                }
            }
            l0 = (long)((unsigned long)l0 + (0xffffffffu % ((unsigned)(0x10000u && (u0 | 2u)) | 1u)));
        }
        goto L4;
        if (budget != 0u) { budget -= 1u; u1 = fn3(u1, (unsigned)((unsigned)c0 || 3u), a0[u1 & 3u]); }
    }
    { unsigned t8; double z8; if ((u1) & 1u) { t8 = ~((unsigned)h1 * (unsigned)c1); z8 = (double)(((unsigned)(0xffffffffu < (unsigned)((int)0xd0ea58bu >= (int)(unsigned)s0))) & 255u); } if ((u1) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
        if ((unsigned)(i2 == (unsigned)s1)) goto L2;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 12u, 0xf3362431u, 0x3e0cb2f6u },
        { 10u, 0xb5776f6bu, 0xe31385c4u },
        { 11u, 0x134f2b26u, 0x1781841fu },
        { 0u, 0x9067d6c5u, 0x7c7cfe4cu },
        { 9u, 0x9ebdbda6u, 0xdb6b8702u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
