// test-ssa-source's program of seed 134000441 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x6637f0ffu, g1 = 0xd74d7d51u;
static unsigned garr[8] = { 0x329de430u, 0x9adf1e0u, 0x9994fb6bu, 0x551de209u, 0xe77a0a8fu, 0xa0eacf97u, 0xb4996d48u, 0x1c7b75c8u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if (((unsigned)((int)(unsigned)f0 >= (int)(unsigned)e0)) & 1u) { t0 = (unsigned)(0xffffffffu == 0x7fffffffu); z0 = (double)(((unsigned)((short)((unsigned)c1 % (v0 | 1u)) > (signed char)9u)) & 255u); } if (((unsigned)((int)(unsigned)f0 >= (int)(unsigned)e0)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        goto L3;
        L0: if (--fuel == 0u) goto done;
        if ((((unsigned)f0 & 0x7fffffffu) & (unsigned)s1)) {
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((a0[u1 & 3u] & (unsigned)d0)) break;
                L1: if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (u2 | (unsigned)(i0 == u0)));
                    { unsigned t1; double z1; if ((((unsigned)((unsigned)x0 == 0x7fffffffu) - 4u)) & 1u) { t1 = 0xbccdac09u; z1 = (double)(((i0 * (unsigned)((unsigned)(w0 >> 29) == 0x7fffffffu))) & 255u); } if ((((unsigned)((unsigned)x0 == 0x7fffffffu) - 4u)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                        L2: if (--fuel == 0u) goto done;
                    }
                    L3: if (--fuel == 0u) goto done;
                    if ((r0.x / (0x80000000u | 1u))) break;
                }
                L4: if (--fuel == 0u) goto done;
                h0 = (short)(unsigned)((short)(unsigned)((unsigned)(x0 >> 70) == (unsigned)(w0 >> 29)) > (signed char)((unsigned)c0 << ((unsigned)((int)p1 < (int)fuel) & 31u)));
            }
            if (((unsigned)c1 ^ p2)) goto L3;
            s1 = (int)((unsigned)s1 + (0x823cb534u ^ (unsigned)(0x853f093eu < (unsigned)(5u < (unsigned)(short)(0x10000u & i0)))));
            if ((unsigned)(0x3dbf1f59u < (0x80000000u | a0[i0 & 3u]))) goto L3;
            switch ((0x80000000u * (unsigned)x0) & 7u) {
                if ((unsigned)(x0 >> 70)) {
                    case 0u: ;
                    if ((unsigned)(w0 >> 29)) break;
                } else {
                    goto L3;
                }
                case 7u: ;
                break; (void)((unsigned)((unsigned)((int)u0 < (int)0x85e6c8f5u) || (unsigned)f0));
                if ((unsigned)(p0 || *q0)) break;
                if ((unsigned)!(*q0 + (unsigned)(w0 >> 29))) goto L3;
                goto done;
            }
            if (0xffffffffu) {
                s1 = (int)((unsigned)s1 + ((unsigned)c1 % ((unsigned)((int)(unsigned)s0 < (int)(0x80000000u * a0[i0 & 3u])) | 1u)));
                l0 = (long)((unsigned long)l0 + a0[i0 & 3u]);
                if ((m0 % ((unsigned)(0xa2aa1723u < (unsigned)h0) | 1u))) goto L1;
                r0.x = ((unsigned)(short)(unsigned)((short)0x80000000u > (signed char)(unsigned)l0) >> (u3 & 31u));
                goto L4;
            }
        }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((0xffffffffu | 0xb7ebab36u)) break;
            q0 = &garr[(unsigned)(((unsigned)c1 / ((unsigned)(a0[u1 & 3u] == 0xe9037c63u) | 1u)) && -(unsigned)(p2 || 6u)) & 7u];
        }
    }
    if ((a0[i0 & 3u] + (unsigned)((int)0x46461e98u >= (int)(unsigned)(w0 >> 29)))) goto L3;
    { unsigned t2; double z2; if ((0x80000000u) & 1u) { t2 = (i0 << ((0x7fffffffu + a0[i0 & 3u]) & 31u)); z2 = (double)(((unsigned)((0xffffffffu << (g1 & 31u)) < 0x7fffffffu)) & 255u); } if ((0x80000000u) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        if (0x80000000u) goto L4;
        g0 = *q0;
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((i0 >> ((unsigned)d0 & 31u))) {
                if ((p1 - *mp)) break;
                if (m0) break;
                if ((unsigned)(x0 >> 70)) goto L4;
                *q0 = (unsigned)((0x10000u & (unsigned)((int)p2 < (int)0x227ed3bfu)) || 0x7fffffffu);
            } else {
                l0 = (long)((unsigned long)l0 + ((u2 - (0x1cd596d2u ? 3u : (unsigned)s1)) - (unsigned)d0));
            }
        }
        x0 = x0 * 0x100000001b3ull + fuel;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(((unsigned)((int)i2 >= (int)0xc2d2f5f2u) + (unsigned)(a0[u1 & 3u] < i1)) >> ((unsigned)x0 & 31u));
            do { if (--fuel == 0u) goto done;
                if ((unsigned)x0) break;
                if ((unsigned)!(unsigned)((unsigned)s1 == (unsigned)e0)) break;
                if (((unsigned)h0 >> (i0 & 31u))) break;
                if (fuel < 8u) return ((unsigned)h0 ? ((unsigned)b0 % ((unsigned)(w0 >> 29) | 1u)) : (u2 % (u2 | 1u)));
                if (6u) {
                    while (i2++ < 7u && (unsigned)((int)((unsigned)h1 / (garr[u2 & 7u] | 1u)) >= (int)0x10000u)) { if (--fuel == 0u) goto done;
                        h0 = (short)(u3 - 0x4dd96796u);
                        if (0x7fffffffu) break;
                        u3 += (unsigned)(unsigned char)((unsigned)w0 - (0xffffffffu % ((unsigned)c1 | 1u)));
                        while (i0++ < 7u && 1u) { if (--fuel == 0u) goto done;
                            if (5u) break;
                            if ((unsigned)(unsigned char)(0xa78ee8au & 9u)) break;
                            *mp = ((unsigned)!((unsigned)((unsigned)h1 == garr[u2 & 7u]) % (0x80000000u | 1u)) ^ (0x101f7569u / ((unsigned)h1 | 1u)));
                        }
                    }
                    *mp = (((0x10000u << (i1 & 31u)) / ((0x10000u / (fuel | 1u)) | 1u)) - u1);
                    m0 ^= r0.x;
                    r0.x = (0x183fb3fcu >> (garr[i1 & 7u] & 31u));
                    while (1u) { if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)((unsigned)(w0 >> 29) || (unsigned)(x0 >> 70)) ? i2 : p2) < 0xad7fd7e4u) & 1023u);
                        u3 = (unsigned)((short)(unsigned)((int)(unsigned)s1 < (int)(g0 << ((unsigned)d0 & 31u))) > (signed char)(0x6b8e6928u % (2u | 1u)));
                        i0 = (unsigned)((u2 - (*q0 / (i2 | 1u))) < 0u) & 15u;
                        *q0 += (((unsigned)(w0 >> 29) + p2) ? 1u : 0x41f9b71u);
                        break; (void)(u3);
                        if (((m0 ^ r0.y) * (unsigned)c0)) goto L0;
                    }
                    goto L4;
                }
            } while (i1++ < 5u && ((unsigned)!((unsigned)b0 + (unsigned)w0) + u2));
            if (((unsigned)h1 / (u0 | 1u))) {
                break; (void)((unsigned)((int)0u < (int)(unsigned)f0));
                if ((unsigned)(0xffffffffu == r0.x)) break;
                w0 = w0 * 6364136223846793005ull + (unsigned)e0;
            } else {
                if (v0) break;
                if (((unsigned)(i1 == 0x7fffffffu) << (u3 & 31u))) {
                    if (a0[i0 & 3u]) break;
                    g1 += (unsigned)(signed char)(garr[u2 & 7u] | ((r0.y ^ (unsigned)b0) - 0x80000000u));
                    garr[6u & 7u] = (unsigned)((short)p0 > (signed char)(0x7fffffffu & ((unsigned)f0 % (0x80000000u | 1u))));
                } else {
                    if (garr[u2 & 7u]) break;
                    if ((unsigned)(r0.y && 0u)) continue;
                    break; (void)(((unsigned)s1 / (u3 | 1u)));
                }
            }
            f0 = f0 * 0.5f + (float)((9u / (0xffffffffu | 1u)) & 255u);
            if (((*mp * (unsigned)d0) - (unsigned)s1)) goto done;
            break; (void)((v0 ^ u0));
        }
    }
    if ((unsigned)(i1 && garr[u2 & 7u])) goto L4;
    garr[(unsigned)(signed char)(a0[u1 & 3u] % (0x80000000u | 1u)) & 7u] = (unsigned)h0;
    if ((unsigned)((unsigned)((int)7u < (int)0x10000u) < a0[i0 & 3u])) goto L4;
    *q0 = (unsigned)(short)(unsigned)((*mp - ((unsigned)d0 ? 5u : u0)) < 0x88c4d2c9u);
    do { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)d0 + (0x7fffffffu % ((unsigned)(w0 >> 29) | 1u))));
    } while (i0++ < 2u && (unsigned)((unsigned)c1 == (g1 ^ (unsigned)e0)));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (unsigned)(short)(-(unsigned)(p0 && 0xd0dbde3du) >> ((unsigned)(0x6e4800cfu == u3) & 31u));
        u3 += (unsigned)(i2 || ((unsigned)e0 + (unsigned)((unsigned)(signed char)(unsigned)(u2 || 0x611d030cu) < (unsigned)h1)));
        goto L0;
        do { if (--fuel == 0u) goto done;
            continue; (void)(((unsigned)((int)a0[u1 & 3u] >= (int)g1) << ((unsigned)d0 & 31u)));
            while ((u0 << ((unsigned)x0 & 31u))) { if (--fuel == 0u) goto done;
                if ((unsigned)(0x80000000u == 0x4174066bu)) break;
                if ((unsigned)((short)7u > (signed char)((unsigned)c1 + (unsigned)s1))) {
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)x0) && (0xffffffffu + ((unsigned)l0 & (unsigned)l0))));
                }
            }
            { unsigned t3; double z3; if (((0x994d2ad2u ? (unsigned)e0 : garr[u2 & 7u])) & 1u) { t3 = -(unsigned)((int)(unsigned)((unsigned)h0 && 9u) >= (int)garr[i1 & 7u]); z3 = (double)((r0.y) & 255u); } if (((0x994d2ad2u ? (unsigned)e0 : garr[u2 & 7u])) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                while (0x1266c061u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        *q0 += (unsigned)(0x80000000u < (((unsigned)l0 % (g1 | 1u)) * (*q0 & u3)));
                    } while (i0++ < 7u && (unsigned)((int)(fuel + m0) < (int)0x80000000u));
                    if ((unsigned)(short)(unsigned)((int)0x4c474c58u < (int)(unsigned)(r0.y == (unsigned)(w0 >> 29)))) goto L2;
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(u3 && i0) || (unsigned)((int)garr[u2 & 7u] < (int)0x4c23fd6cu)) & 255u);
                }
                if ((unsigned)(signed char)(unsigned)((unsigned)w0 < (unsigned)s1)) {
                    g1 += (unsigned)(u3 && (unsigned)((short)(0x80000000u ^ 0x80000000u) > (signed char)((unsigned)w0 & 8u)));
                    if (~(unsigned)((unsigned)l0 || g1)) break;
                    d0 = d0 * 0.5 + (double)(((unsigned)((int)i1 >= (int)*mp) << ((u1 << (a0[u1 & 3u] & 31u)) & 31u)) & 1023u);
                    break; (void)((0xffffffffu + (0x41a396b8u | (unsigned)(x0 >> 70))));
                    *q0 = (unsigned)((int)(p1 >> ((unsigned)(x0 >> 70) & 31u)) < (int)(*q0 | (unsigned)x0));
                    switch (garr[u2 & 7u] & 7u) {
                        s0 = (int)(((g1 | 0x45846c99u) >> ((unsigned)c0 & 31u)) << (((unsigned)l0 % ((unsigned)l0 | 1u)) & 31u));
                        case 3u: ;
                        switch (~(v0 * 0xffffffffu) & 7u) {
                            r0.x = p2;
                        }
                        s1 = (int)((unsigned)s1 + *mp);
                        case 1u: ;
                    }
                }
                do { if (--fuel == 0u) goto done;
                    if (((unsigned)x0 * (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)e0))) break;
                    u0 = u0 * 0x9e3779b1u + ((p2 << (0xffffffffu & 31u)) - (unsigned)(unsigned char)(unsigned)(0xe7b409b9u && (unsigned)l0));
                    u2 += (unsigned)((int)((unsigned)c1 & 0x80000000u) < (int)(unsigned)e0);
                    *q0 = ((unsigned)(0x10000u || (i0 * u0)) + (unsigned)(w0 >> 29));
                    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((g0 / (*q0 | 1u))) break;
                        g1 += (0x7fffffffu | (unsigned)h0);
                        c0 = (unsigned char)(unsigned)((short)(u2 & (unsigned)s1) > (signed char)i1);
                    }
                    c0 = (unsigned char)(unsigned)!(garr[i1 & 7u] & (7u * (unsigned)(g0 < 0x80000000u)));
                } while (i2++ < 2u && *mp);
                e0 = e0 * 0.5L + (long double)(((unsigned)h1 - (unsigned)w0) & 1023u);
                for (;;) { if (--fuel == 0u) goto done;
                    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        switch (((unsigned)(x0 >> 70) * p2) & 7u) {
                            e0 = e0 * 0.5L + (long double)((unsigned)!(unsigned)((int)i0 >= (int)m0) & 1023u);
                            u2 ^= (unsigned)((unsigned)(unsigned char)((r0.x >> (u1 & 31u)) | (unsigned)x0) && p1);
                            w0 = w0 * 6364136223846793005ull + g0;
                        }
                        if ((((unsigned)c1 & p1) + 0x8c842174u)) goto done;
                        break; (void)((unsigned)(unsigned char)(5u >> (((unsigned)c1 | i1) & 31u)));
                        r0.y ^= (unsigned)((short)(unsigned)(p2 == (unsigned)x0) > (signed char)(unsigned)((int)(unsigned)l0 < (int)(unsigned)(unsigned char)((unsigned)s1 | fuel)));
                        break; (void)((unsigned)(g1 < (unsigned)(short)(garr[i1 & 7u] ^ (unsigned)e0)));
                    }
                    b0 = (unsigned)(signed char)((8u << (r0.x & 31u)) << (0x4f1c06fbu & 31u)) != 0u;
                    continue; (void)(((unsigned)d0 / ((0x80000000u - (unsigned)(x0 >> 70)) | 1u)));
                }
            }
            e0 = e0 * 0.5L + (long double)((0x209ae3dau & (unsigned)x0) & 1023u);
            d0 = d0 * 0.5 + (double)((i1 + (0xffffffffu / ((5u % (0u | 1u)) | 1u))) & 1023u);
            switch (6u & 7u) {
                case 4u: ;
                b0 = *mp != 0u;
                *q0 = i0;
                if (u2) continue;
                c1 = (signed char)((unsigned)h1 * 7u);
                s0 = (int)(garr[i1 & 7u] ? (u3 << ((unsigned)(5u == u1) & 31u)) : 0xf3b1a07du);
            }
        } while (i1++ < 5u && g0);
        u1 ^= (unsigned)(g1 && (p0 - (unsigned)l0));
        if ((unsigned)d0) {
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)(0x10000u && (4u * 2u));
                if ((a0[i0 & 3u] / (0xa6cef36eu | 1u))) {
                    if (0x7fffffffu) {
                        m0 ^= (g1 * i0);
                        if (((unsigned)(w0 >> 29) ^ 8u)) {
                            *q0 += (unsigned)((int)u0 < (int)((0u << (a0[i0 & 3u] & 31u)) - r0.x));
                            if ((unsigned)(signed char)(p2 - (u3 ^ 8u))) break;
                            d0 = d0 * 0.5 + (double)((unsigned)((int)3u >= (int)u2) & 1023u);
                            s0 = (int)(unsigned)d0;
                            w0 = w0 * 6364136223846793005ull + ((a0[i0 & 3u] ^ p0) ^ (unsigned)w0);
                        }
                        if (-(unsigned)((int)0x19beb072u >= (int)(unsigned)s0)) break;
                        l0 = (long)((unsigned long)l0 + ((unsigned)(r0.y == 7u) / ((unsigned)(x0 >> 70) | 1u)));
                        c0 = (unsigned char)((unsigned)((unsigned)(0x75f6b547u < (unsigned)s1) || v0) << (p2 & 31u));
                    } else {
                        if (0u) break;
                    }
                    if (-(3u * (unsigned)b0)) break;
                    e0 = e0 * 0.5L + (long double)(((unsigned)(x0 >> 70) >> ((unsigned)(r0.x || (unsigned)d0) & 31u)) & 1023u);
                    if ((unsigned)(4u < i1)) break;
                    c1 = (signed char)(0u ? i2 : 8u);
                }
                u2 += (unsigned)(unsigned char)(unsigned)(((unsigned)((int)0x7fffffffu >= (int)((unsigned)c1 % (p2 | 1u))) << (0xec470a3bu & 31u)) < *q0);
                x0 = x0 * 0x100000001b3ull + p1;
            }
            x0 = x0 * 0x100000001b3ull + (unsigned)(a0[u1 & 3u] && (unsigned)((4u ? (unsigned)f0 : 0xffffffffu) < r0.y));
            x0 = x0 * 0x100000001b3ull + ((u2 >> ((i1 | i1) & 31u)) | (u0 ^ 0x80000000u));
            switch (p0 & 7u) {
                if ((unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)h0)) break;
                case 4u: ;
                case 0u: ;
                x0 = x0 * 0x100000001b3ull + 0xdc528a06u;
                case 7u: ;
            }
        }
    }
    { unsigned t4; double z4; if ((m0) & 1u) { t4 = (u3 * fuel); z4 = (double)((((unsigned)e0 * (unsigned)(6u < 0xd1ec8a1eu))) & 255u); } if ((m0) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        r0.x = ((unsigned)(unsigned char)(0x41a87be9u >> (((unsigned)(w0 >> 29) & garr[u2 & 7u]) & 31u)) ? garr[i1 & 7u] : (unsigned)d0);
    }
    if ((((unsigned)h1 << (v0 & 31u)) ^ fuel)) goto L3;
    { unsigned t5; double z5; if (((unsigned)(unsigned char)((unsigned)(short)(unsigned)((short)v0 > (signed char)a0[u1 & 3u]) / (i1 | 1u))) & 1u) { t5 = (unsigned)x0; z5 = (double)(((unsigned)!(unsigned)(0x10000u == 7u)) & 255u); } if (((unsigned)(unsigned char)((unsigned)(short)(unsigned)((short)v0 > (signed char)a0[u1 & 3u]) / (i1 | 1u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
        if (((unsigned)w0 | ((unsigned)h1 % (0x10000u | 1u)))) goto L4;
        { unsigned t6; double z6; if (((unsigned)((int)0x82be1885u < (int)(3u - r0.y))) & 1u) { t6 = (4u * *mp); z6 = (double)(((unsigned)!(unsigned)(i0 && 0x7fffffffu)) & 255u); } if (((unsigned)((int)0x82be1885u < (int)(3u - r0.y))) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            goto L3;
            q0 = &garr[(unsigned)(signed char)((fuel / ((a0[u1 & 3u] & 0xffffffffu) | 1u)) - i0) & 7u];
            if (((unsigned)h0 ? (unsigned)f0 : (unsigned)l0)) {
                goto L2;
                if (fuel < 8u) return i0;
                w0 = w0 * 6364136223846793005ull + (unsigned)(short)(unsigned)(r0.x || 1u);
                e0 = e0 * 0.5L + (long double)((unsigned)(2u && (unsigned)(p2 == (unsigned)(((unsigned)c0 / ((unsigned)l0 | 1u)) < 0x25e5f7bfu))) & 1023u);
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)((short)1u > (signed char)(unsigned)c1) || m0)) break;
                    break; (void)(((i1 | 0xfda83555u) + 0xffffffffu));
                }
                *q0 += (unsigned)(u2 && (unsigned)((int)(unsigned)(unsigned char)((unsigned)x0 ^ 0x80000000u) >= (int)garr[i1 & 7u]));
            }
            if ((*q0 % (0x5f25e061u | 1u))) goto L3;
            if ((unsigned)((short)0x88a9dadfu > (signed char)(unsigned)(r0.y == 6u))) goto done;
            if ((unsigned)((int)(unsigned)h0 >= (int)(unsigned)(u3 && a0[u1 & 3u]))) {
                e0 = e0 * 0.5L + (long double)((unsigned)c0 & 1023u);
                goto L2;
                s0 = (int)(unsigned)((int)((p2 * (unsigned)s1) % (garr[i1 & 7u] | 1u)) < (int)0x10000u);
                do { if (--fuel == 0u) goto done;
                    if ((*q0 - (unsigned)s0)) break;
                } while (i0++ < 6u && (p1 ^ (unsigned)h0));
                { unsigned t7; double z7; if (((1u + (unsigned)h0)) & 1u) { t7 = -(1u << (fuel & 31u)); z7 = (double)(((-(unsigned)((int)(unsigned)e0 < (int)u2) & p1)) & 255u); } if (((1u + (unsigned)h0)) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                    { unsigned t8; double z8; if ((2u) & 1u) { t8 = r0.y; z8 = (double)(((unsigned)(unsigned char)(u2 & ((unsigned)l0 % (0x49316c09u | 1u)))) & 255u); } if ((2u) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                        *mp = ~(unsigned)((int)(unsigned)!(unsigned)((short)(u0 | (unsigned)((int)*q0 < (int)u3)) > (signed char)2u) < (int)u2);
                        d0 = d0 * 0.5 + (double)((0x80000000u + 0xce53e745u) & 1023u);
                        if ((unsigned)((int)(unsigned)((int)g1 < (int)(unsigned)s0) >= (int)0x5a0b089bu)) goto L1;
                        if (((unsigned)x0 & (unsigned)(i0 == *mp))) goto L1;
                        w0 ^= (unsigned long long)(unsigned)((int)0u < (int)m0) << ((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)((unsigned)(signed char)(0u | (unsigned)e0) || v0)) & 63u);
                    }
                    if (-(p2 ^ (unsigned)((int)0x10000u >= (int)(unsigned)l0))) goto L2;
                    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        m0 ^= ((p1 / (*q0 | 1u)) << (((unsigned)(short)(unsigned)((int)(unsigned)l0 >= (int)v0) << (m0 & 31u)) & 31u));
                        h0 = (short)((p2 * (unsigned)((short)g1 > (signed char)0x270eb37fu)) ^ -(unsigned)(p2 || 2u));
                    }
                    e0 = e0 * 0.5L + (long double)((u0 | (unsigned)(unsigned char)((unsigned)((short)(unsigned)c0 > (signed char)u1) % ((u3 >> (*mp & 31u)) | 1u))) & 1023u);
                    if (((unsigned)h1 >> (0x8b9f8b67u & 31u))) goto L3;
                }
                b0 = (unsigned)(0x10000u || (unsigned)((int)(unsigned)h1 < (int)0u)) != 0u;
            } else {
                while (i0++ < 2u && u0) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)((short)(unsigned)(i0 < 0x10000u) > (signed char)p2);
                    u3 += (unsigned)((unsigned)h0 || ((unsigned)f0 & (unsigned)((int)(unsigned)(u0 == 3u) >= (int)g1)));
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)(unsigned char)(0x10000u / (((unsigned)w0 ^ 0x94ea2a66u) | 1u))) break;
                        { unsigned t9; double z9; if (((0u ^ r0.y)) & 1u) { t9 = (g1 - (unsigned)h1); z9 = (double)((((unsigned)(signed char)(unsigned)(0x10000u && 4u) & fuel)) & 255u); } if (((0u ^ r0.y)) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                            if (((unsigned)((int)*q0 < (int)(unsigned)s1) * (unsigned)d0)) break;
                        }
                        d0 = d0 * 0.5 + (double)((((unsigned)((int)p2 < (int)u1) ^ g0) - (u2 % ((unsigned)w0 | 1u))) & 1023u);
                        u3 ^= (unsigned)((unsigned)((int)(unsigned)h0 >= (int)r0.y) == 0xd18b7628u);
                        if (r0.y) break;
                        if (u3 == 7u) return (1u * r0.x);
                    }
                    for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        r0.x = (unsigned)(unsigned char)(((unsigned)f0 % (g0 | 1u)) & 0xffffffffu);
                        if ((3u ^ u3)) break;
                    }
                }
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    goto L4;
                    if (*mp) break;
                    u2 ^= (unsigned)((short)0x3efa5fe6u > (signed char)(unsigned)((unsigned)h1 < (unsigned)(short)((unsigned)c0 >> (0x10000u & 31u))));
                    break; (void)(((unsigned)((short)a0[u1 & 3u] > (signed char)a0[i0 & 3u]) | 3u));
                    *q0 += (unsigned)((int)(unsigned)(6u == 0xac3a8063u) < (int)(unsigned)b0);
                    if ((unsigned)(x0 >> 70)) continue;
                }
                if ((unsigned)((unsigned)((short)(unsigned)c0 > (signed char)9u) == 6u)) goto L3;
            }
        }
        goto L2;
        u2 = u2 * 0x9e3779b1u + -((a0[i0 & 3u] >> ((unsigned)b0 & 31u)) * ((unsigned)c1 / ((unsigned)h1 | 1u)));
        v0 = (unsigned)(short)((unsigned)(w0 >> 29) | (unsigned)(i1 || (unsigned)((int)(unsigned)w0 >= (int)0xffffffffu)));
        { unsigned t10; double z10; if (((r0.y | g1)) & 1u) { t10 = (i1 << ((unsigned)x0 & 31u)); z10 = (double)(((p0 >> (0xa754eed4u & 31u))) & 255u); } if (((r0.y | g1)) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
            goto L3;
        }
    }
    goto done;
    u0 += ((unsigned)(unsigned char)((unsigned)s0 / (9u | 1u)) | 6u);
    w0 = w0 * 6364136223846793005ull + (~(unsigned)((unsigned)d0 == 0x97b062bdu) / (((unsigned)(i2 == garr[i1 & 7u]) + (unsigned)b0) | 1u));
    if ((unsigned)((int)(unsigned)c0 < (int)i2)) goto L2;
    { unsigned t11; double z11; if ((((*q0 >> (a0[u1 & 3u] & 31u)) * p1)) & 1u) { t11 = (unsigned)(7u && (0x7fffffffu % (0xf613f993u | 1u))); z11 = (double)(((unsigned)(v0 && 9u)) & 255u); } if ((((*q0 >> (a0[u1 & 3u] & 31u)) * p1)) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
        if ((((unsigned)h0 & 0xe15bb59bu) << (fuel & 31u))) {
            *q0 += g0;
            d0 = d0 * 0.5 + (double)((unsigned)((int)p2 < (int)(unsigned)((int)r0.y >= (int)(unsigned)s1)) & 1023u);
            e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)(p1 || (g1 << ((0xcf6eeb41u ? r0.y : (unsigned)c0) & 31u))) & 1023u);
        }
    }
    s0 = (int)(unsigned)((0xffffffffu % ((unsigned)h1 | 1u)) || (unsigned)((short)(unsigned)h1 > (signed char)m0));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t12; double z12; if ((p0) & 1u) { t12 = (*mp * (unsigned)l0); z12 = (double)(((u1 >> ((unsigned)l0 & 31u))) & 255u); } if ((p0) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
            while (i1++ < 7u && (unsigned)((unsigned)(0x10000u == p0) || (unsigned)l0)) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(signed char)(unsigned)(g1 == (garr[i1 & 7u] + garr[i1 & 7u])));
            }
            a0[(a0[u1 & 3u] << (m0 & 31u)) & 3u] = (unsigned)((short)p0 > (signed char)p2);
            if ((0x32d51277u & (i1 + 0x10000u))) break;
        }
        if ((unsigned)((unsigned)(x0 >> 70) && garr[i1 & 7u])) continue;
        { unsigned t13; double z13; if (((unsigned)!(unsigned)((unsigned)b0 == garr[u2 & 7u])) & 1u) { t13 = (unsigned)(unsigned char)(g0 ^ -(0x2a60ac6au / ((unsigned)b0 | 1u))); z13 = (double)(((u0 | (unsigned)f0)) & 255u); } if (((unsigned)!(unsigned)((unsigned)b0 == garr[u2 & 7u])) & 1u) { u0 += t13; d0 = d0 * 0.5 + z13; }
            if ((0xae803f66u / (m0 | 1u))) break;
        }
        u1 += (*q0 ^ (0x90d3bbd4u ? 8u : 0xf579a1ddu));
    }
    g0 = (unsigned)((short)(unsigned)(u2 < (unsigned)h1) > (signed char)(unsigned)c1);
    b0 = (unsigned)((unsigned)x0 == (unsigned)((int)(unsigned)w0 >= (int)(i2 * p1))) != 0u;
    u3 = u3 * 0x9e3779b1u + (r0.y / (g1 | 1u));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((0x7fffffffu | ((unsigned)h1 >> (u3 & 31u))));
        r0.y ^= -(unsigned)((int)(unsigned)e0 >= (int)(0x7fffffffu & ((unsigned)c1 * ((unsigned)b0 ^ 0x80000000u))));
        if (g1) {
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    *q0 = (0x80000000u >> (0xbc8a75c6u & 31u));
                    c1 = (signed char)(0x645abd59u >> (((u2 * (unsigned)w0) & garr[u2 & 7u]) & 31u));
                    do { if (--fuel == 0u) goto done;
                        h0 = (short)i1;
                        r0.x = (((u1 & (unsigned)(w0 >> 29)) - i0) | (unsigned)((int)(unsigned)h0 >= (int)p2));
                    } while (i0++ < 5u && ((unsigned)l0 * *mp));
                    if (garr[i1 & 7u]) break;
                    if ((unsigned)((unsigned)c1 < 0x10000u)) break;
                } while (i2++ < 7u && a0[u1 & 3u]);
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((0x10000u % ((unsigned)c1 | 1u))) break;
                    if (u1) {
                        if (6u) break;
                        goto L2;
                        u2 += ((unsigned)(w0 >> 29) * (garr[u2 & 7u] - (unsigned)c0));
                        if ((unsigned)((int)(unsigned)!((unsigned)x0 % ((unsigned)l0 | 1u)) >= (int)(unsigned)c0)) break;
                        break; (void)((0x80000000u >> ((unsigned)h0 & 31u)));
                    } else {
                        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                            if ((unsigned)(short)(unsigned)(u1 || (unsigned)h0)) goto L2;
                        }
                        if ((unsigned)((short)p2 > (signed char)(unsigned)(p2 == p0))) break;
                        r0.x = (unsigned)((int)(unsigned)(short)((unsigned)(signed char)(0xe35803dau >> (0xca1fa9bcu & 31u)) << (u3 & 31u)) < (int)a0[u1 & 3u]);
                    }
                    if ((~(0x7fffffffu % (0xd17179f2u | 1u)) ^ (unsigned)h0)) break;
                    if (((m0 + 6u) % ((unsigned)c1 | 1u))) {
                        g0 = (unsigned)(((g1 << (garr[i1 & 7u] & 31u)) * ((unsigned)c1 * p1)) < p2);
                        if (0x7fffffffu) break;
                        break; (void)((unsigned)(unsigned char)(unsigned)(*mp < ((unsigned)(x0 >> 70) % (7u | 1u))));
                        g0 = 7u;
                        u0 += ((unsigned)((int)a0[i0 & 3u] >= (int)p2) | (garr[u2 & 7u] / (u2 | 1u)));
                    }
                }
            }
            if ((1u / (u1 | 1u))) break;
            l0 = (long)((unsigned long)l0 + ((garr[i1 & 7u] / ((unsigned)l0 | 1u)) >> ((*mp * (unsigned)(0xba63e3acu == m0)) & 31u)));
        } else {
            b0 = (u3 >> ((unsigned)w0 & 31u)) != 0u;
            f0 = f0 * 0.5f + (float)(((unsigned)s0 ^ (unsigned)((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)(0xfabb6c6cu < u3)) && 0x80000000u)) & 255u);
            continue; (void)((unsigned)((unsigned)(fuel == (unsigned)x0) && 0x5c4a755cu));
        }
        continue; (void)((unsigned)((int)(u1 % ((unsigned)l0 | 1u)) < (int)(unsigned)d0));
    }
    goto L4;
    garr[(i2 - p0) & 7u] = ((unsigned)(p1 == garr[u2 & 7u]) | (unsigned)h1);
    do { if (--fuel == 0u) goto done;
        switch ((unsigned)(u2 == (unsigned)((unsigned)w0 < (unsigned)l0)) & 7u) {
            d0 = d0 * 0.5 + (double)((unsigned)(1u || v0) & 1023u);
        }
        a0[(0xffffffffu + (unsigned)x0) & 3u] = 0x7fffffffu;
        a0[(0x135c6528u % (m0 | 1u)) & 3u] = (unsigned)((i1 - p2) < (unsigned)((int)0xffffffffu >= (int)(unsigned)e0));
        if ((unsigned)((unsigned)e0 == garr[i1 & 7u])) break;
        d0 = d0 * 0.5 + (double)((unsigned)c0 & 1023u);
    } while (i0++ < 4u && (unsigned)(short)(unsigned)((int)5u < (int)(unsigned)s1));
    if ((a0[u1 & 3u] ^ 0x10000u)) goto done;
    v0 = ((unsigned)(r0.x && (unsigned)h0) | (unsigned)s1);
    v0 = ((unsigned)(x0 >> 70) + (unsigned)((unsigned)d0 && ~(0x8ed86c77u * g1)));
    if (fuel) {
        m0 ^= ((unsigned)(x0 >> 70) % (a0[i0 & 3u] | 1u));
        switch (m0 & 7u) {
            if (((garr[u2 & 7u] << (garr[i1 & 7u] & 31u)) / (0xb8838c37u | 1u))) {
                for (;;) { if (--fuel == 0u) goto done;
                    case 0u: ;
                }
                r0.x = (unsigned)!((unsigned)!((unsigned)(signed char)(unsigned)(garr[u2 & 7u] < (unsigned)((unsigned)e0 < (unsigned)c1)) / (0x257c44f3u | 1u)) % ((unsigned)d0 | 1u));
                x0 = x0 * 0x100000001b3ull + ~(unsigned)((short)p0 > (signed char)r0.y);
                case 2u: ;
                u1 += (0xffffffffu ^ 0u);
            }
            if (u3 == 7u) return (unsigned)((int)u3 >= (int)(unsigned)(x0 >> 70));
            if (fuel) {
                { unsigned t14; double z14; if (((unsigned)(v0 && 0x8758a1e2u)) & 1u) { t14 = ((unsigned)((short)(unsigned)h1 > (signed char)0x80000000u) << (9u & 31u)); z14 = (double)(((unsigned)((unsigned)x0 < p2)) & 255u); } if (((unsigned)(v0 && 0x8758a1e2u)) & 1u) { u0 += t14; d0 = d0 * 0.5 + z14; }
                    w0 ^= (unsigned long long)((unsigned)(w0 >> 29) - (unsigned)(w0 >> 29)) << ((((unsigned)b0 + (unsigned)f0) | 0x10000u) & 63u);
                }
                if ((i1 & 0xb38aecb3u)) goto L0;
                if (u0) goto L4;
                l0 = (long)((unsigned long)l0 + ((unsigned)l0 & (garr[i1 & 7u] >> ((unsigned)((int)u3 < (int)(unsigned)(*mp && i0)) & 31u))));
                if ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)p2)) goto L0;
                for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((unsigned)(0x10000u && r0.x) & 1023u);
                }
            } else {
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(signed char)(unsigned)((int)u0 >= (int)*q0)) break;
                    case 4u: ;
                }
                h1 = (unsigned short)(h1 + ((unsigned)(w0 >> 29) + (0x10000u * (unsigned)e0)));
                for (;;) { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)((short)(unsigned)(0xc750c6dau < m0) > (signed char)(unsigned)((int)(unsigned)c1 >= (int)0x65445638u));
                    v0 = ((unsigned)(signed char)(unsigned)((int)(unsigned)((int)fuel >= (int)0xffffffffu) >= (int)(unsigned)(signed char)(0xffffffffu - (unsigned)(x0 >> 70))) - 0x35d06afau);
                    if ((unsigned)(short)((unsigned)x0 & (unsigned)s1)) break;
                    case 3u: ;
                }
            }
        }
        e0 = e0 * 0.5L + (long double)((a0[u1 & 3u] + (unsigned)((*mp / (0x5326d6a9u | 1u)) < (unsigned)((int)i0 < (int)r0.y))) & 1023u);
        if ((0x7fffffffu | (6u | a0[i0 & 3u]))) {
            do { if (--fuel == 0u) goto done;
                if ((a0[i0 & 3u] & i1)) break;
                i0 = r0.x & 15u;
                b0 = g1 != 0u;
            } while (i0++ < 3u && (unsigned)w0);
            if (u3 == 7u) return (unsigned)(unsigned char)(unsigned)((int)6u < (int)(i1 - (0x80000000u & 0x89914224u)));
            if ((u1 - i0)) goto L2;
            if ((unsigned)!(garr[u2 & 7u] * (unsigned)(signed char)(*q0 % ((unsigned)(w0 >> 29) | 1u)))) goto L1;
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                goto L4;
            }
        }
    } else {
        if ((unsigned)((short)0xffffffffu > (signed char)5u)) {
            if ((unsigned)(((unsigned)d0 ^ 2u) < garr[i1 & 7u])) goto L0;
        } else {
            q0 = &garr[(unsigned)((int)(fuel - 0xd23c9a0au) >= (int)(unsigned)(a0[i0 & 3u] == 9u)) & 7u];
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)((g0 | r0.x) && (unsigned)((int)2u >= (int)((unsigned)d0 & 0xe899d09u)));
                { unsigned t15; double z15; if (((unsigned)((int)(unsigned)((unsigned)l0 < (unsigned)d0) >= (int)(unsigned)(x0 >> 70))) & 1u) { t15 = (unsigned)(short)(*mp | garr[u2 & 7u]); z15 = (double)(((unsigned)(x0 >> 70)) & 255u); } if (((unsigned)((int)(unsigned)((unsigned)l0 < (unsigned)d0) >= (int)(unsigned)(x0 >> 70))) & 1u) { u0 += t15; d0 = d0 * 0.5 + z15; }
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)(0x5cad5814u && (0xa558a368u - 7u)));
                        w0 ^= (unsigned long long)(unsigned)(p0 == (unsigned)d0) << (((5u | 0u) + (unsigned)((short)v0 > (signed char)u0)) & 63u);
                    }
                }
                if ((unsigned)(signed char)((unsigned)(unsigned char)((unsigned)(x0 >> 70) * 0u) - 3u)) {
                    h0 = (short)((unsigned)s0 / (i0 | 1u));
                    if ((unsigned)((unsigned)((int)(unsigned)l0 >= (int)0xb296be32u) && g1)) break;
                    g0 = (unsigned)((int)u0 >= (int)p1);
                    do { if (--fuel == 0u) goto done;
                        if (((unsigned)h0 & -(a0[i0 & 3u] & (unsigned)w0))) break;
                        if ((unsigned)(garr[i1 & 7u] || 0x9d400fd2u)) break;
                        d0 = d0 * 0.5 + (double)(((unsigned)(a0[i0 & 3u] == u2) << ((unsigned)((int)i0 >= (int)p2) & 31u)) & 1023u);
                    } while (i1++ < 7u && (i0 << (0x1524eff6u & 31u)));
                    u0 += (8u - a0[u1 & 3u]);
                } else {
                    if ((unsigned)((int)-(unsigned)(0x32e199bbu || *q0) < (int)(unsigned)s0)) break;
                    if ((garr[i1 & 7u] >> (i2 & 31u))) break;
                    m0 ^= ((m0 - ((unsigned)x0 / (0x10000u | 1u))) >> ((unsigned)(p0 && fuel) & 31u));
                }
                break; (void)((unsigned)((unsigned)((int)p1 < (int)0x7fffffffu) && u2));
            }
            g1 += (unsigned)!(unsigned)((g0 ^ (unsigned)c1) == (unsigned)(8u && 0x3c346544u));
            switch ((unsigned)((unsigned)(garr[u2 & 7u] < r0.y) || (unsigned)(w0 >> 29)) & 7u) {
                *q0 = (unsigned)((short)1u > (signed char)(unsigned)(1u && (m0 / ((garr[u2 & 7u] << (2u & 31u)) | 1u))));
                r0.x = (unsigned)(unsigned char)(unsigned)(0xdfa3e802u == (5u / ((0xae2578e0u << (m0 & 31u)) | 1u)));
                i2 = (unsigned)(unsigned char)(unsigned)(0x7fffffffu && (fuel * r0.x)) & 15u;
                case 1u: ;
                i2 = (unsigned)((0x76a70593u & a0[u1 & 3u]) || (unsigned)l0) & 15u;
            }
        }
        switch ((unsigned)s1 & 7u) {
            while (i0++ < 5u && (unsigned)(u2 || (unsigned)h1)) { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)(*mp & 1023u);
                    if (0x59b860c6u) goto L2;
                    c1 = (signed char)(unsigned)((int)(4u | (r0.y % (*mp | 1u))) < (int)9u);
                    l0 = (long)((unsigned long)l0 + r0.x);
                    w0 ^= (unsigned long long)((unsigned)w0 / (0x80000000u | 1u)) << ((unsigned)((unsigned)((short)(unsigned)c0 > (signed char)p2) && (u2 * 0x5bb14706u)) & 63u);
                }
                case 4u: ;
            }
            goto L4;
            case 3u: ;
            case 1u: ;
            if ((unsigned)((short)m0 > (signed char)(fuel ^ (unsigned)c0))) goto L1;
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t16; double z16; if ((((unsigned)(x0 >> 70) << (u2 & 31u))) & 1u) { t16 = 0x80000000u; z16 = (double)(((unsigned)(short)(i1 + (unsigned)w0)) & 255u); } if ((((unsigned)(x0 >> 70) << (u2 & 31u))) & 1u) { u2 += t16; d0 = d0 * 0.5 + z16; }
                h0 = (short)(unsigned)((int)(unsigned)f0 >= (int)(unsigned)((unsigned)h1 == 0xc84d56d0u));
                *q0 = (unsigned)((short)(unsigned)f0 > (signed char)((0xffffffffu ^ p1) * fuel));
                m0 ^= a0[u1 & 3u];
                if (fuel < 8u) return ((u0 / ((*mp % (i0 | 1u)) | 1u)) * 0x7fffffffu);
                break; (void)((0x10000u ? g0 : 0xffffffffu));
            }
            if (garr[u2 & 7u]) {
                m0 ^= -(unsigned)((int)r0.x >= (int)(unsigned)s0);
                q0 = &garr[(0x80000000u * (6u / (1u | 1u))) & 7u];
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)!(unsigned)((short)6u > (signed char)garr[i1 & 7u]) - 0x7fffffffu)) break;
                    h1 = (unsigned short)(h1 + ~(0x8fa24df8u / ((0x80000000u >> (5u & 31u)) | 1u)));
                    if (i1) break;
                    a0[(unsigned)(fuel < r0.x) & 3u] = 0x80000000u;
                    break; (void)((unsigned)f0);
                }
                garr[7u & 7u] = (unsigned)s0;
                break; (void)((i2 | (unsigned)s0));
            } else {
                do { if (--fuel == 0u) goto done;
                    if (g0) break;
                } while (i1++ < 4u && (*mp ^ ((unsigned)d0 * i0)));
                *q0 += ((unsigned)(signed char)(i1 >> (((unsigned)(0x7fffffffu || (unsigned)c1) | u1) & 31u)) - m0);
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((0x80000000u - 6u)) break;
                    w0 ^= (unsigned long long)1u << ((g1 & (unsigned)(garr[u2 & 7u] && (unsigned)(0x92f522eeu == 0x44327e29u))) & 63u);
                    if ((unsigned)(g0 == i2)) break;
                    *q0 += ((unsigned)((int)(unsigned)(0x80000000u && *q0) < (int)r0.y) % ((v0 / (8u | 1u)) | 1u));
                    if (r0.y) {
                        switch ((unsigned)!((unsigned)h0 / ((unsigned)((int)(unsigned)w0 < (int)0x105b6b25u) | 1u)) & 7u) {
                            case 2u: ;
                            if ((unsigned)((unsigned)c1 && u0)) break;
                            break; (void)((1u + p0));
                        }
                        *q0 = (unsigned)(short)(unsigned)((short)u1 > (signed char)(unsigned)((unsigned)w0 == (unsigned)(m0 == (unsigned)(w0 >> 29))));
                        e0 = e0 * 0.5L + (long double)((p0 + 0xf475d767u) & 1023u);
                        if ((unsigned)l0) break;
                    } else {
                        if ((unsigned)((int)(unsigned)(unsigned char)(unsigned)((int)0u < (int)r0.x) < (int)u0)) goto done;
                        garr[(i0 >> (v0 & 31u)) & 7u] = (unsigned)!(unsigned)((int)0x7fffffffu < (int)garr[u2 & 7u]);
                    }
                    if ((unsigned)((unsigned)c1 == 0x8e7414d0u)) break;
                }
            }
            break; (void)((unsigned)c0);
        }
    }
    goto L0;
    switch ((*mp ^ (unsigned)f0) & 7u) {
        case 1u: ;
        q0 = &garr[((unsigned)((short)u3 > (signed char)(unsigned)b0) / ((g0 / ((unsigned)(signed char)(unsigned)(*q0 < (unsigned)(x0 >> 70)) | 1u)) | 1u)) & 7u];
        u0 ^= ((unsigned)d0 + garr[u2 & 7u]);
        x0 = x0 * 0x100000001b3ull + (unsigned)(4u == (unsigned)(x0 >> 70));
        case 0u: ;
        c0 = (unsigned char)(unsigned)(unsigned char)(unsigned)(6u == i1);
    }
    if ((unsigned)((unsigned)f0 && -(g1 * 0u))) goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(0xd4e09fd5u && (3u ^ 0x80000000u))) goto done;
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(0x8f7eb7ddu < (0x3eb574cu >> (p1 & 31u))), r0.x, 2u); }
    if ((((unsigned)d0 & (unsigned)b0) << (p1 & 31u))) goto L3;
    b0 = (unsigned)((int)((unsigned)w0 % (v0 | 1u)) < (int)(~(unsigned)((int)(unsigned)x0 < (int)9u) % ((unsigned)c0 | 1u))) != 0u;
    while (i0++ < 4u && (unsigned)(r0.x == v0)) { if (--fuel == 0u) goto done;
        while (i1++ < 7u && ((g1 % (g0 | 1u)) | (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(0x80000000u, ((unsigned)((unsigned)c0 || garr[i1 & 7u]) >> (u1 & 31u)), (unsigned)(u0 < 0xd3734bf8u)); }
            q0 = &garr[(unsigned)((0x2a242669u >> ((unsigned)l0 & 31u)) || ((fuel % (a0[i0 & 3u] | 1u)) ^ u2)) & 7u];
            q0 = &garr[(*mp % ((unsigned)c0 | 1u)) & 7u];
            i0 = (((unsigned)(w0 >> 29) - 0xfd952b4cu) % ((g0 % ((unsigned)(short)((unsigned)h1 ^ *mp) | 1u)) | 1u)) & 15u;
        }
        u3 = (0x968de362u >> (0xe5fe2e83u & 31u));
        if (0xfbf08112u) break;
        { unsigned t0; double z0; if (((0u ^ (p1 ^ garr[u2 & 7u]))) & 1u) { t0 = (unsigned)((short)(unsigned)((unsigned)c0 == v0) > (signed char)i2); z0 = (double)(((2u * (unsigned)((int)0x10000u < (int)v0))) & 255u); } if (((0u ^ (p1 ^ garr[u2 & 7u]))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            if (((unsigned)(0x80000000u == u2) - u0)) {
                if ((unsigned)(m0 < 0x7fffffffu)) break;
                s0 = (int)(unsigned)((int)g1 >= (int)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)6u));
                if ((unsigned)x0) goto done;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    m0 ^= (unsigned)(signed char)((unsigned)((int)((unsigned)(0xffffffffu || 0xd68e018u) + a0[i0 & 3u]) >= (int)g0) - (unsigned)l0);
                    d0 = d0 * 0.5 + (double)((unsigned)(signed char)((unsigned)e0 & (4u * (unsigned)s0)) & 1023u);
                    e0 = e0 * 0.5L + (long double)(u3 & 1023u);
                    *q0 = *mp;
                    m0 ^= 3u;
                    break; (void)(p1);
                }
                if ((((unsigned)e0 + p1) - 9u)) {
                    g1 += (unsigned)c1;
                    g1 += fuel;
                } else {
                    L1: if (--fuel == 0u) goto done;
                    *mp = 9u;
                    break; (void)(~((unsigned)(w0 >> 29) % ((garr[i1 & 7u] % (8u | 1u)) | 1u)));
                }
                while ((unsigned)((int)*mp >= (int)(unsigned)h1)) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)x0;
                    for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)c0 && r0.x), fuel, (unsigned)((short)(unsigned)(unsigned char)(unsigned)(p2 < u0) > (signed char)a0[u1 & 3u])); }
                        x0 = x0 * 0x100000001b3ull + (unsigned)!(unsigned)((0xbb04a05u | 0x9c5d65e5u) || (unsigned)(unsigned char)(unsigned)((unsigned)(x0 >> 70) || 0xe958714u));
                        l0 = (long)((unsigned long)l0 + ((0x80000000u * v0) & 2u));
                    }
                }
            } else {
                if ((p0 / (0x9bb5fb91u | 1u))) break;
                if (0x2b215c7du) {
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)(0xffffffffu && (unsigned)h1));
                        if (((p2 % (u2 | 1u)) << (r0.x & 31u))) break;
                        break; (void)(0x5f0a64bau);
                        q0 = &garr[((unsigned)s0 - (unsigned)(u3 == g0)) & 7u];
                        if ((unsigned)(signed char)(unsigned)(((unsigned)d0 << ((unsigned)x0 & 31u)) == 0x80000000u)) {
                            L2: if (--fuel == 0u) goto done;
                            L3: if (--fuel == 0u) goto done;
                        }
                    }
                    i2 = p1 & 15u;
                }
                u2 += (u0 | ((unsigned)f0 >> (0x10000u & 31u)));
            }
            w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(unsigned)(u2 || (unsigned)s1);
            L4: if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if (((unsigned)(a0[u1 & 3u] || 0x2c60db10u)) & 1u) { t1 = (unsigned)s0; z1 = (double)((-(unsigned)(((unsigned)s1 - (unsigned)s0) == *q0)) & 255u); } if (((unsigned)(a0[u1 & 3u] || 0x2c60db10u)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                c0 = (unsigned char)i2;
                s0 = (int)(unsigned)((int)r0.y < (int)0x10000u);
                if (((unsigned)l0 & 0xffffffffu)) continue;
                if (v0) {
                    u2 = ((unsigned)(a0[u1 & 3u] == (unsigned)(u2 == i0)) & i0);
                } else {
                    *q0 = (unsigned)((short)((unsigned)c1 + (unsigned)l0) > (signed char)((g1 % (fuel | 1u)) >> (p2 & 31u)));
                    h0 = (short)(9u - 0xdb0be5a3u);
                    break; (void)((i1 + 3u));
                    *q0 = ~((r0.x | i2) << (8u & 31u));
                }
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((((unsigned)b0 >> (*mp & 31u)) << (0x597c2321u & 31u)), (((unsigned)f0 % ((unsigned)(x0 >> 70) | 1u)) / ((unsigned)(x0 >> 70) | 1u)), (p1 + (unsigned)d0)); }
                    i2 = ((unsigned)((unsigned)(w0 >> 29) || (unsigned)(w0 >> 29)) | i2) & 15u;
                    u1 ^= ~(m0 ^ 0x80000000u);
                }
            }
        }
        b0 = (unsigned)(0x1d45f73bu == (unsigned)s0) != 0u;
        d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)((short)(unsigned)e0 > (signed char)0x48451962u) | g1) && (unsigned)(2u < garr[i1 & 7u])) & 1023u);
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0(*mp, (p0 / (*q0 | 1u)), (unsigned)(signed char)(r0.x | 9u)); }
    if (u2) goto L2;
    w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(unsigned)(0x914de6fu && (unsigned)c1);
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (0x430bc9bcu) {
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((0x10000u % ((unsigned)x0 | 1u)));
                    if (i0) goto L0;
                    u0 = u0 * 0x9e3779b1u + ((unsigned)h0 + 0u);
                    if ((unsigned)((fuel ^ u2) < u3)) {
                        { unsigned t2; double z2; if (((unsigned)c0) & 1u) { t2 = (0x80000000u << (g0 & 31u)); z2 = (double)((i1) & 255u); } if (((unsigned)c0) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                            m0 ^= ((unsigned)(5u && (unsigned)(g1 == u1)) << ((unsigned)x0 & 31u));
                            if (budget != 0u) { budget -= 1u; u3 = fn0(p2, (unsigned)c1, (unsigned)(p0 < u2)); }
                            w0 = w0 * 6364136223846793005ull + (unsigned)h1;
                            x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)(i0 || (unsigned)!(unsigned)((0xf2b13d63u | (unsigned)d0) == 0x80000000u)) < (int)r0.y);
                        }
                        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                            r0.y ^= -((0x80000000u % (i1 | 1u)) % (a0[i0 & 3u] | 1u));
                            *q0 = ((unsigned)((int)0x80000000u < (int)0x92a3aeddu) ^ (unsigned)(w0 >> 29));
                        }
                        s1 = (int)((unsigned)s1 + (unsigned)h1);
                        if (0xcc615429u) {
                            h0 = (short)(unsigned)((short)(0xf3fcae31u % (*q0 | 1u)) > (signed char)(unsigned)w0);
                            if ((unsigned)((unsigned)s1 == (unsigned)x0)) break;
                            r0.y ^= 0x10000u;
                            break; (void)((0x80000000u % (r0.y | 1u)));
                            u0 = u0 * 0x9e3779b1u + ((unsigned)f0 ? a0[u1 & 3u] : (unsigned)x0);
                        }
                    }
                }
                h0 = (short)(unsigned)x0;
            }
            if (((unsigned)(w0 >> 29) >> (g1 & 31u))) continue;
            v0 = (p1 / ((0u * (0xa3b2d73au ? 9u : 3u)) | 1u));
            if (budget != 0u) { budget -= 1u; u3 = fn0(0x80000000u, (*q0 + garr[i1 & 7u]), (unsigned)((short)i2 > (signed char)0xa167c1ebu)); }
            r0.y ^= ((unsigned)c1 >> (0x10000u & 31u));
            if ((u3 + (unsigned)((unsigned)c0 == 0u))) break;
        } while (i1++ < 7u && (u0 | 0xbad61499u));
        { unsigned t3; double z3; if ((0x80000000u) & 1u) { t3 = (unsigned)(unsigned char)(0x375c43d0u ^ (unsigned)h0); z3 = (double)(((unsigned)(short)(*mp << (*q0 & 31u))) & 255u); } if ((0x80000000u) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            switch (0x71a8cf97u & 7u) {
                if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)l0 * m0), (fuel | 0x10000u), garr[i1 & 7u]); }
                *mp = (unsigned)h0;
                if (0x80000000u) {
                    i2 = (unsigned)((int)(unsigned)((int)(i1 + (unsigned)b0) < (int)*q0) >= (int)0x80000000u) & 15u;
                    c0 = (unsigned char)(unsigned)((int)(unsigned)((int)(unsigned)e0 < (int)(unsigned)s0) >= (int)p0);
                    case 0u: ;
                    if (fuel) {
                        case 7u: ;
                        if ((unsigned)((m0 >> (u2 & 31u)) || 0x7fffffffu)) continue;
                        if ((fuel & 0xffffffffu)) {
                            f0 = f0 * 0.5f + (float)((unsigned)(u3 == (garr[i1 & 7u] % (*mp | 1u))) & 255u);
                        }
                        u1 += ~(0x80000000u | (unsigned)(0xcbb8346bu == 0x80000000u));
                    } else {
                        m0 ^= (unsigned)((int)v0 < (int)(unsigned)((int)g0 < (int)(unsigned)b0));
                        break; (void)((unsigned)(0xa80b317du == v0));
                        *mp = ~(0xffffffffu | (garr[i1 & 7u] ? m0 : (g1 / (*mp | 1u))));
                        g1 += (unsigned)((int)6u >= (int)v0);
                    }
                    garr[0xffffffffu & 7u] = (unsigned)((short)(unsigned)(0xdda0f313u == r0.y) > (signed char)(unsigned)(unsigned char)((unsigned)((short)(unsigned)b0 > (signed char)p0) >> (a0[u1 & 3u] & 31u)));
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)s0 < (int)(v0 & 0x10000u)), 3u, 0x7fffffffu); }
            }
            u2 ^= (unsigned)((unsigned)e0 && -(p0 * -(unsigned)(i2 == u0)));
        }
    }
    if ((unsigned)((int)(fuel / (p0 | 1u)) >= (int)1u)) goto L0;
    *q0 = (unsigned)((g0 - 0x10000u) == 0x4a13ec9cu);
    garr[(unsigned)(0x7ac45bb5u && *q0) & 7u] = (unsigned)((unsigned)!(r0.x + g0) && (unsigned)(0xffffffffu < u2));
    for (;;) { if (--fuel == 0u) goto done;
        if (0xd75d160bu) {
            if (r0.y) break;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(unsigned char)(unsigned)((unsigned)e0 == (unsigned)l0)) break;
                while (~((unsigned)s1 | (unsigned)((short)(unsigned)l0 > (signed char)u2))) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)w0 * (unsigned)((int)u2 >= (int)(unsigned)(x0 >> 70))), (g0 ? (unsigned)f0 : i0), (i1 & (unsigned)((short)(unsigned)x0 > (signed char)(unsigned)c0))); }
                    d0 = d0 * 0.5 + (double)((unsigned)((int)8u < (int)0xab659a68u) & 1023u);
                    if ((a0[i0 & 3u] >> ((u3 + (unsigned)b0) & 31u))) {
                        h1 = (unsigned short)(h1 + (unsigned)((int)r0.y < (int)(u1 / (r0.y | 1u))));
                        if ((unsigned)!(r0.x & (unsigned)(signed char)(u1 / ((unsigned)h0 | 1u)))) break;
                    } else {
                        break; (void)(((unsigned)c1 * (unsigned)b0));
                        m0 ^= (g1 % (0u | 1u));
                        s0 = (int)(((garr[i1 & 7u] >> (i1 & 31u)) << ((3u * 0x6d906eccu) & 31u)) & 0xffffffffu);
                        if (((unsigned)f0 / ((i1 & i0) | 1u))) continue;
                    }
                }
            } while (i1++ < 2u && (unsigned)(x0 >> 70));
            if ((u2 + (8u - u1))) goto L0;
            if ((0x7fffffffu - 0x3a352ca7u)) break;
            u2 = u2 * 0x9e3779b1u + (unsigned)(signed char)(unsigned)((short)0x80000000u > (signed char)0x2fcce2feu);
        }
        break; (void)((unsigned)d0);
        r0.x = (unsigned)!(unsigned)(((unsigned)(signed char)(unsigned)(i2 < 0xffffffffu) + 1u) < i1);
        while (a0[u1 & 3u]) { if (--fuel == 0u) goto done;
            if (((unsigned)l0 >> (r0.x & 31u))) {
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (m0) break;
                    for (;;) { if (--fuel == 0u) goto done;
                        a0[(unsigned)l0 & 3u] = ((g1 + (g1 * (unsigned)s1)) * (9u / (p2 | 1u)));
                        if ((unsigned)(7u || (unsigned)((int)(unsigned)l0 >= (int)0x80000000u))) goto done;
                        d0 = d0 * 0.5 + (double)((i0 ? (5u - (unsigned)(garr[u2 & 7u] && (unsigned)s0)) : 0x249fd64du) & 1023u);
                        goto L0;
                    }
                }
                i2 = (((unsigned)h0 >> (6u & 31u)) ^ 0x10000u) & 15u;
                u2 = u2 * 0x9e3779b1u + (0xec617f19u * (unsigned)(x0 >> 70));
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)g0 >= (int)0u);
            } else {
                s0 = (int)(unsigned)((((unsigned)h0 + g1) | (unsigned)(v0 < garr[u2 & 7u])) == 1u);
                if (budget != 0u) { budget -= 1u; u1 = fn0((u1 << (u2 & 31u)), (unsigned)((short)(unsigned)s0 > (signed char)g1), (unsigned)((unsigned)(u1 < *q0) || 1u)); }
            }
            g0 = (unsigned)((short)6u > (signed char)(((unsigned)d0 >> (*mp & 31u)) % (garr[i1 & 7u] | 1u)));
            v0 = (((unsigned)h1 / (garr[i1 & 7u] | 1u)) * (unsigned)(g0 || (unsigned)((short)(unsigned)f0 > (signed char)0xffffffffu)));
        }
        c1 = (signed char)(unsigned)(u1 < (unsigned)((int)0x40575795u < (int)*q0));
        if ((unsigned)((int)(unsigned)((int)m0 >= (int)0xffffffffu) >= (int)a0[u1 & 3u])) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)g0 > (signed char)fuel), (unsigned)f0, (unsigned)((unsigned)d0 < 0xe1a8356bu)); }
            if ((unsigned)((unsigned)(1u < 0x1f7534e7u) || p1)) {
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + ((unsigned)w0 / (r0.y | 1u));
                }
                if (garr[i1 & 7u]) break;
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)((int)8u < (int)((unsigned)c0 << (0x7fffffffu & 31u))));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)c1, (unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)((unsigned)l0 && g1)), ((unsigned)(x0 >> 70) / ((unsigned)!(p2 & 0xe995b79fu) | 1u))); }
                    if ((unsigned)((int)garr[u2 & 7u] < (int)(0x80000000u ^ g0))) break;
                    h1 = (unsigned short)(h1 + ((unsigned)c0 * 0x80000000u));
                    u0 = u0 * 0x9e3779b1u + -(((unsigned)(0xe00c917cu || (unsigned)(0xffffffffu < fuel)) << (garr[u2 & 7u] & 31u)) & (unsigned)w0);
                }
                e0 = e0 * 0.5L + (long double)((0x2f279d10u << (0x10000u & 31u)) & 1023u);
            }
            f0 = f0 * 0.5f + (float)(((unsigned)((short)(unsigned)((unsigned)s0 < p2) > (signed char)(unsigned)(w0 >> 29)) * g0) & 255u);
            goto L2;
            switch ((unsigned)(-(unsigned)((int)p2 < (int)0x7fffffffu) == m0) & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(*mp == *mp), ((unsigned)w0 >> ((u0 * p0) & 31u)), (unsigned)((unsigned)s0 || 0xdf974789u)); }
            }
        } else {
            if (((unsigned)e0 & (unsigned)s1)) goto L4;
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(0x7fffffffu && (unsigned)(unsigned char)(0x10000u & 5u)), a0[i0 & 3u], -(unsigned)((short)1u > (signed char)i0)); }
    { unsigned t4; double z4; if ((((unsigned)f0 ? u2 : 0x10000u)) & 1u) { t4 = (u0 % (i0 | 1u)); z4 = (double)((((unsigned)e0 ^ *mp)) & 255u); } if ((((unsigned)f0 ? u2 : 0x10000u)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
        *mp = ((unsigned)l0 ? ((unsigned)s0 & 0xa7e29707u) : 0x5a0f5981u);
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)-((unsigned)(x0 >> 70) << (0x9990d827u & 31u));
            if (0x7b247cafu) break;
            if (r0.y) {
                { unsigned t5; double z5; if (((unsigned)(short)(*q0 - (unsigned)l0)) & 1u) { t5 = ~((unsigned)(i1 || u2) << (i2 & 31u)); z5 = (double)(((unsigned)((unsigned)(p0 < 0x80000000u) < 1u)) & 255u); } if (((unsigned)(short)(*q0 - (unsigned)l0)) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                    h1 = (unsigned short)(h1 + 0x2d8a84a6u);
                    if (budget != 0u) { budget -= 1u; u0 = fn0(garr[i1 & 7u], 9u, (unsigned)(short)(0x2e2b802bu & 0x10000u)); }
                    if (0x10000u) break;
                    for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(p2, -(unsigned)((unsigned)c1 < (unsigned)((unsigned)h0 && (unsigned)x0)), (u1 + p2)); }
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn0(7u, 0x7fffffffu, 0xba86728bu); }
                }
                u0 += ((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)(w0 >> 29)) * (unsigned)(signed char)(0x8efba698u * v0));
                if ((0x391639e8u | ~(unsigned)(*mp && i1))) goto done;
            }
        }
        if (0x96f74d45u) goto L4;
    }
    if (p1) goto L0;
    garr[5u & 7u] = (unsigned)(short)(unsigned)((unsigned)!(u1 & (unsigned)s1) && p1);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        u2 = (unsigned)!((unsigned)x0 / ((g1 + (unsigned)s0) | 1u));
        if ((unsigned)x0) continue;
    }
    v0 = g1;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (i1) break;
        if ((0x7fffffffu - (unsigned)(x0 >> 70))) break;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)d0 || u0)) {
                if ((garr[i1 & 7u] * 0x80000000u)) break;
                if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)((unsigned)(w0 >> 29) || fuel) >= (int)m0)) break;
            } else {
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!((unsigned)x0 - r0.x), (unsigned)((int)0x24508cadu >= (int)i0), 8u); }
            }
            s1 = (int)((unsigned)s1 + *mp);
            c0 = (unsigned char)(unsigned)((int)(unsigned)((int)(unsigned)c0 >= (int)(u0 * p1)) >= (int)(unsigned)!(unsigned)((int)0x7fffffffu >= (int)0x639fb9e0u));
            c0 = (unsigned char)(v0 + 3u);
            if (p1) break;
            if (0x935ba289u) break;
        } while (i1++ < 2u && ((unsigned)f0 * 0x80000000u));
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(7u, 6u, (0xbe8d823cu % ((unsigned)(u2 || (unsigned)l0) | 1u))); }
    v0 = (unsigned)!(((unsigned)(r0.y && (unsigned)h1) - p2) << (((unsigned)w0 >> (g0 & 31u)) & 31u));
    d0 = d0 * 0.5 + (double)((unsigned)((short)(u2 ? 6u : -((unsigned)b0 - 0x10000u)) > (signed char)0xffffffffu) & 1023u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    q0 = &garr[(unsigned)((int)p2 >= (int)(v0 & (unsigned)c1)) & 7u];
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (((unsigned)h0 * (unsigned)s0) << (((unsigned)(w0 >> 29) | g1) & 31u));
            if ((0xffffffffu << (r0.y & 31u))) {
                w0 ^= (unsigned long long)g0 << ((unsigned)((unsigned)((int)(a0[i0 & 3u] * (unsigned)(w0 >> 29)) < (int)fuel) && (i0 * u2)) & 63u);
                e0 = e0 * 0.5L + (long double)((unsigned)(x0 >> 70) & 1023u);
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(unsigned)((short)3u > (signed char)(unsigned)(signed char)(r0.x / ((unsigned)x0 | 1u))), (unsigned)(w0 >> 29), ((unsigned)h1 % (g0 | 1u))); }
            } else {
                L1: if (--fuel == 0u) goto done;
                if (fuel < 8u) return (8u << (g1 & 31u));
                u0 = (((unsigned)c0 * u2) % (1u | 1u));
                if (budget != 0u) { budget -= 1u; u0 = fn0((0x10000u / ((unsigned)(6u < (unsigned)(w0 >> 29)) | 1u)), (unsigned)((short)(unsigned)h0 > (signed char)0x428f1242u), (m0 & ((unsigned)h0 << (*mp & 31u)))); }
            }
            L2: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1((((unsigned)e0 >> (garr[i1 & 7u] & 31u)) - 8u), *mp, (unsigned)h1); }
            h1 = (unsigned short)(h1 + ((unsigned)c0 % ((u1 | (unsigned)s0) | 1u)));
            { unsigned t0; double z0; if (((unsigned)(0x4d159489u == (6u & 0x10000u))) & 1u) { t0 = ((unsigned)c1 & (unsigned)(unsigned char)(i2 ^ m0)); z0 = (double)((u3) & 255u); } if (((unsigned)(0x4d159489u == (6u & 0x10000u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                a0[(unsigned)(r0.y || *mp) & 3u] = (((unsigned)d0 >> ((unsigned)((unsigned)s0 < (unsigned)(garr[i1 & 7u] || (unsigned)h1)) & 31u)) + (unsigned)b0);
                if ((((unsigned)c1 << (0x17023f4fu & 31u)) & (unsigned)x0)) goto L1;
            }
        } while (i1++ < 7u && ((unsigned)s0 / (0xaffb966u | 1u)));
        while (i1++ < 5u && (p2 & (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
            q0 = &garr[(unsigned)((int)(unsigned)(signed char)((unsigned)(x0 >> 70) >> ((unsigned)x0 & 31u)) < (int)0u) & 7u];
            v0 = (unsigned)(short)(((p0 * a0[i0 & 3u]) + 0x10000u) ^ (unsigned)((int)0x78f09ffeu >= (int)(unsigned)w0));
            if (budget != 0u) { budget -= 1u; u1 = fn1((0x7fffffffu / (a0[i0 & 3u] | 1u)), (i1 ^ (5u | v0)), (unsigned)(u1 < (unsigned)!(u3 * (unsigned)d0))); }
            if ((unsigned)((short)p2 > (signed char)*mp)) break;
            if ((unsigned)!(unsigned)((short)i2 > (signed char)(unsigned)l0)) {
                r0.y ^= (fuel * p2);
            } else {
                w0 = w0 * 6364136223846793005ull + (-(3u - (unsigned)(w0 >> 29)) - (p1 ^ 7u));
                g0 = ((unsigned)((unsigned)((int)u1 >= (int)-(unsigned)(a0[u1 & 3u] == g0)) && 0u) + (unsigned)b0);
            }
        }
        if (((u2 - 0x80000000u) >> (r0.y & 31u))) {
            break; (void)(r0.x);
            if (budget != 0u) { budget -= 1u; u3 = fn1(0x8e05a89fu, (unsigned)((unsigned)!(fuel + (unsigned)l0) < i2), a0[i0 & 3u]); }
            if (fuel) {
                L3: if (--fuel == 0u) goto done;
            } else {
                if (budget != 0u) { budget -= 1u; u1 = fn0(0x7fffffffu, (unsigned)((short)u0 > (signed char)(unsigned)s1), (unsigned)(short)(9u / ((unsigned)h0 | 1u))); }
                if (0xffffffffu) break;
                L4: if (--fuel == 0u) goto done;
                b0 = (unsigned)(g1 < 0x10000u) != 0u;
            }
        } else {
            f0 = f0 * 0.5f + (float)((*mp + (unsigned)c1) & 255u);
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if ((((u0 & (unsigned)l0) << (p1 & 31u))) & 1u) { t1 = (unsigned)(u2 == (i2 - g0)); z1 = (double)((((i1 - garr[i1 & 7u]) / (a0[u1 & 3u] | 1u))) & 255u); } if ((((u0 & (unsigned)l0) << (p1 & 31u))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    f0 = f0 * 0.5f + (float)((-(unsigned)((short)0x25d4f0e9u > (signed char)((unsigned)h0 ? 0xb841c1ceu : 7u)) - 0x6c164b76u) & 255u);
                    a0[(unsigned)((int)3u >= (int)(unsigned)s1) & 3u] = (unsigned)((unsigned)(0x92603834u || (unsigned)((short)(unsigned)d0 > (signed char)g0)) < (unsigned)s0);
                }
                if (((unsigned)x0 | i0)) {
                    b0 = (unsigned)((unsigned)h1 && ((unsigned)s0 / (i2 | 1u))) != 0u;
                    break; (void)((r0.x << (0xffffffffu & 31u)));
                    while (i2++ < 3u && (unsigned)((int)r0.x < (int)0x7fffffffu)) { if (--fuel == 0u) goto done;
                        switch (p2 & 7u) {
                            if (budget != 0u) { budget -= 1u; u3 = fn1(-(i1 ? 7u : p2), u2, u0); }
                            h0 = (short)0x7fffffffu;
                            case 0u: ;
                            l0 = (long)((unsigned long)l0 + (unsigned)((int)(m0 * 9u) < (int)(m0 | u1)));
                            s0 = (int)(unsigned)((int)u3 >= (int)(((unsigned)w0 * (unsigned)((int)6u >= (int)3u)) % (a0[i0 & 3u] | 1u)));
                        }
                        break; (void)(~((0x8e3643fcu * u2) / (5u | 1u)));
                        u1 = (unsigned)((int)(unsigned)((short)6u > (signed char)0x80000000u) < (int)(unsigned)c0);
                    }
                    break; (void)(((unsigned)x0 >> (~(unsigned)((unsigned)d0 == (unsigned)(x0 >> 70)) & 31u)));
                    g1 += ((unsigned)d0 ? 0x79b15f79u : a0[u1 & 3u]);
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        m0 ^= -(unsigned)(((unsigned)(0x33283d99u && 9u) << ((7u ^ i1) & 31u)) || u3);
                        d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)((short)p0 > (signed char)0x10000u) > (signed char)(unsigned)c0) & 1023u);
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)((int)a0[i0 & 3u] >= (int)0u) && u1), (unsigned)(u3 < (unsigned)(0x7fffffffu < g1)), ((unsigned)(unsigned char)(g1 ^ m0) & fuel)); }
                        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                            if ((p1 % ((unsigned)x0 | 1u))) break;
                            m0 ^= ((unsigned)((short)*mp > (signed char)g0) + ((i1 + r0.y) / ((unsigned)c0 | 1u)));
                            w0 ^= (unsigned long long)(unsigned)((unsigned)c0 && 0xd89bbe8du) << ((unsigned)((unsigned)((short)0xffffffffu > (signed char)(unsigned)(short)(*mp - 9u)) && (garr[i1 & 7u] | (unsigned)l0)) & 63u);
                            if ((unsigned)(0x7fffffffu == (unsigned)(short)(0x7fffffffu / (r0.x | 1u)))) break;
                            if ((unsigned)h1) break;
                        }
                        if (((unsigned)c1 + 2u)) goto L4;
                    }
                } else {
                    q0 = &garr[m0 & 7u];
                    if ((unsigned)((int)(unsigned)w0 < (int)8u)) break;
                    if (i0) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((fuel >> (g1 & 31u)), *mp, (((unsigned)h0 & 0x80000000u) / (6u | 1u))); }
                }
                v0 = 0xffffffffu;
                if (a0[i0 & 3u]) break;
            }
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)garr[i1 & 7u] >= (int)r0.y), (unsigned)(0x7fffffffu == v0), -(garr[u2 & 7u] * (unsigned)(0xffffffffu < (unsigned)h0))); }
    }
    if (((unsigned)(i2 || *mp) | a0[i0 & 3u])) goto L4;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)x0 >= (int)(unsigned)(0x80000000u == (unsigned)x0)), (unsigned)((int)(g1 - 0x3567ba71u) < (int)r0.y), (unsigned)(i1 || 0x6e8535du)); }
    while (i0++ < 6u && ((unsigned)!(unsigned)((int)8u < (int)(unsigned)h1) >> (u1 & 31u))) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && (unsigned)(a0[i0 & 3u] < i1)) { if (--fuel == 0u) goto done;
            switch (0x7fffffffu & 7u) {
                if ((unsigned)(0x80000000u < fuel)) {
                    b0 = (unsigned)(w0 >> 29) != 0u;
                }
                if (u3 == 7u) return u2;
            }
            a0[((unsigned)c0 % (p2 | 1u)) & 3u] = (unsigned)(short)(*mp << (((0xf6f6ae1bu % (p2 | 1u)) % (0x7fffffffu | 1u)) & 31u));
            break; (void)((unsigned)!(unsigned)(a0[u1 & 3u] == (unsigned)f0));
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (0x10000u) {
                    if (0x3d79ebbdu) goto L0;
                    if ((0xffffffffu + garr[i1 & 7u])) break;
                    *mp = ((unsigned)c0 << ((0x741a6876u >> (((unsigned)((int)7u < (int)fuel) * (unsigned)h0) & 31u)) & 31u));
                } else {
                    goto L1;
                    q0 = &garr[(unsigned)((p0 >> ((unsigned)c0 & 31u)) == (i1 ^ g1)) & 7u];
                    c1 = (signed char)~(unsigned)(i0 == (0xe7889080u ? 0x91402a50u : i0));
                }
                if ((unsigned)c0) break;
                g0 = 1u;
                goto L2;
            }
            if (9u) continue;
        }
        if ((unsigned)d0) {
            if (7u) {
                goto L0;
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)i0 < (int)(unsigned)(short)(0x977cee4du - (unsigned)f0))) continue;
                    g0 = ((a0[i0 & 3u] + 0xd61a9105u) << ((unsigned)(p2 && 0xffffffffu) & 31u));
                    *q0 += (0x10000u & (unsigned)!((unsigned)h0 % ((unsigned)c1 | 1u)));
                    switch (a0[i0 & 3u] & 7u) {
                        case 4u: ;
                        d0 = d0 * 0.5 + (double)((r0.y | (unsigned)(unsigned char)((7u & 0x80000000u) / (fuel | 1u))) & 1023u);
                        case 7u: ;
                        s0 = (int)(0xb43ea93au % ((i0 | i1) | 1u));
                        l0 = (long)((unsigned long)l0 + a0[u1 & 3u]);
                        u2 ^= (unsigned)((int)(fuel ? u2 : 8u) >= (int)((unsigned)h1 + 0x79686c41u));
                    }
                    if ((unsigned)(8u && (unsigned)h0)) break;
                    e0 = e0 * 0.5L + (long double)((unsigned)((short)5u > (signed char)(0x432f8c6bu ? r0.x : 2u)) & 1023u);
                }
                g0 = 0xdec5ced6u;
            } else {
                i0 = ((m0 & fuel) * (0xffffffffu | (unsigned)(signed char)(unsigned)((int)2u < (int)(unsigned)(x0 >> 70)))) & 15u;
            }
        } else {
            if ((unsigned)((int)(unsigned)((unsigned)c0 == (unsigned)(x0 >> 70)) < (int)(unsigned)b0)) {
                g0 = (unsigned)(signed char)(0xfae4884cu + (0x80000000u << (u1 & 31u)));
                continue; (void)((a0[u1 & 3u] & (unsigned)(short)(0x931c586au % (*q0 | 1u))));
                { unsigned t2; double z2; if ((0xffffffffu) & 1u) { t2 = (unsigned)((int)(1u * a0[i0 & 3u]) >= (int)(unsigned)d0); z2 = (double)((((unsigned)((unsigned)(x0 >> 70) < fuel) % (3u | 1u))) & 255u); } if ((0xffffffffu) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    garr[(0x7fffffffu - g0) & 7u] = (unsigned)((int)i1 >= (int)v0);
                    if (((unsigned)x0 / (0x7acb5debu | 1u))) break;
                    break; (void)(0xb4ae189bu);
                    if (-(p2 / ((unsigned)e0 | 1u))) goto L0;
                }
                if ((unsigned)(5u < (unsigned)(0x5eb18c7eu < (unsigned)(w0 >> 29)))) continue;
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((v0 * (unsigned)d0)) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn1(garr[u2 & 7u], 2u, (a0[i0 & 3u] | r0.y)); }
                    c1 = (signed char)((unsigned)((int)(unsigned)c1 < (int)0x7fffffffu) | 8u);
                }
            } else {
                if ((unsigned)((int)0xb0df18b4u < (int)6u)) goto done;
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)(8u == g1) >= (int)(a0[i0 & 3u] ? u3 : v0));
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)b0 / (i0 | 1u)), ((unsigned)((int)0x9a1ac8d8u >= (int)2u) & (unsigned)s0), 0u); }
                s0 = (int)(unsigned)(short)(unsigned)((int)p0 >= (int)((unsigned)c1 % ((p1 & ((unsigned)s0 << (i0 & 31u))) | 1u)));
            }
            switch (((v0 - m0) << ((unsigned)s0 & 31u)) & 7u) {
                c0 = (unsigned char)5u;
                switch (0x10000u & 7u) {
                    i1 = (7u * i0) & 15u;
                    case 2u: ;
                    if ((unsigned)h0) {
                        if ((9u | *q0)) {
                            u3 = u3 * 0x9e3779b1u + ((-((unsigned)h0 - (unsigned)((int)1u >= (int)*q0)) | (unsigned)e0) | 0x10000u);
                            case 3u: ;
                            i0 = (unsigned)((0x80000000u >> (0x80000000u & 31u)) == (unsigned)(signed char)((unsigned)w0 >> ((unsigned)((int)u2 < (int)fuel) & 31u))) & 15u;
                        }
                        case 0u: ;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(p0 < (unsigned)(p0 == 0x7fffffffu)), ((unsigned)(unsigned char)(6u + 1u) + (unsigned)e0), ((unsigned)c1 / (0xf4980b13u | 1u))); }
                    }
                    if ((unsigned)c0) continue;
                    default: ;
                    b0 = (unsigned)((unsigned)w0 && (unsigned)(0u < p2)) != 0u;
                }
                case 1u: ;
                r0.y ^= -(9u % (r0.x | 1u));
            }
        }
        g1 += (g0 ? (unsigned)((unsigned)s0 < (0xffffffffu * 0x55aa8dfdu)) : 0x80000000u);
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(p1 < 0xcb5da596u), -(u3 * (unsigned)s1), (i0 | -(r0.x + p0))); }
        b0 = ((unsigned)((int)(unsigned)h0 < (int)0xac39db43u) / (0x7fffffffu | 1u)) != 0u;
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0(((0xffffffffu & (unsigned)w0) ^ 0x1ba74f09u), ((0x7fffffffu - p2) + (unsigned)s1), p2); }
        if (budget != 0u) { budget -= 1u; u0 = fn0(m0, (unsigned)h1, u2); }
    }
    a0[(0x29d78e76u & 7u) & 3u] = (~(u0 >> (4u & 31u)) - (unsigned)(short)(unsigned)((unsigned)e0 == a0[u1 & 3u]));
    { unsigned t3; double z3; if (((8u | fuel)) & 1u) { t3 = (unsigned)(short)(unsigned)((short)*mp > (signed char)((unsigned)s0 ^ g1)); z3 = (double)(((7u / ((unsigned)(r0.x < 0u) | 1u))) & 255u); } if (((8u | fuel)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)h1, 0xfe91de0cu, ((unsigned)x0 + i0)); }
    }
    goto done;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1(0u, ((unsigned)(i2 || i0) + (unsigned)x0), (garr[u2 & 7u] / ((0x2c413f0fu / (0x85bc15b8u | 1u)) | 1u))); }
        b0 = (unsigned)(short)(fuel / (1u | 1u)) != 0u;
        q0 = &garr[((unsigned)b0 >> (0xe2c87450u & 31u)) & 7u];
        if ((unsigned)!((u2 * (unsigned)s1) | *mp)) {
            if ((0x4145de37u / (a0[u1 & 3u] | 1u))) continue;
            while ((unsigned)(u3 == (a0[i0 & 3u] / (a0[i0 & 3u] | 1u)))) { if (--fuel == 0u) goto done;
                if (0x10000u) {
                    if ((r0.x >> ((unsigned)(x0 >> 70) & 31u))) {
                        garr[((unsigned)c0 + 0xffffffffu) & 7u] = (unsigned)((int)i1 < (int)(unsigned)((int)(unsigned)((short)u2 > (signed char)(unsigned)(w0 >> 29)) < (int)*q0));
                        l0 = (long)((unsigned long)l0 + 0x80000000u);
                        l0 = (long)((unsigned long)l0 + (unsigned)((short)i1 > (signed char)3u));
                    } else {
                        r0.x = ((0x80000000u ? 0x2cbfb9ffu : (unsigned)w0) << (u3 & 31u));
                    }
                    continue; (void)((unsigned)((int)0xf82a8308u < (int)((unsigned)(x0 >> 70) << (a0[i0 & 3u] & 31u))));
                    if ((unsigned)(u3 && ((unsigned)f0 ^ (unsigned)l0))) {
                        if ((6u % (0xffffffffu | 1u))) break;
                    } else {
                        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)s1 | ((unsigned)d0 * p2)), ~((unsigned)h1 * 4u), (0x80000000u | (unsigned)(signed char)((unsigned)l0 / ((unsigned)s0 | 1u)))); }
                        d0 = d0 * 0.5 + (double)((0xc763f1eeu & 0x10000u) & 1023u);
                        v0 = garr[i1 & 7u];
                    }
                    if (5u) goto L4;
                } else {
                    while (i2++ < 6u && (unsigned)s1) { if (--fuel == 0u) goto done;
                        q0 = &garr[(0u >> (0xa9193ce1u & 31u)) & 7u];
                        s0 = (int)u1;
                    }
                    for (;;) { if (--fuel == 0u) goto done;
                        if (((unsigned)((short)6u > (signed char)7u) & (unsigned)d0)) continue;
                    }
                    g0 = ((((unsigned)b0 * 4u) | p1) % ((unsigned)((unsigned)l0 && p0) | 1u));
                    continue; (void)((0x2870fd92u ^ (0x7fffffffu - 0x11f31fd2u)));
                }
            }
            c0 = (unsigned char)6u;
            e0 = e0 * 0.5L + (long double)(0xce47fd30u & 1023u);
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = (unsigned)((unsigned)(0x7fffffffu < ((unsigned)((int)p2 < (int)v0) << ((unsigned)d0 & 31u))) < (unsigned)h0);
                    if ((((unsigned)h0 % ((unsigned)(w0 >> 29) | 1u)) + (unsigned)c0)) {
                        h1 = (unsigned short)(h1 + (p1 | (unsigned)c0));
                    } else {
                        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                            u2 = u2 * 0x9e3779b1u + 0x80000000u;
                            e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)d0 == (unsigned)((unsigned)((int)(unsigned)s1 >= (int)p2) || (*q0 % (*mp | 1u)))) & 1023u);
                            if (budget != 0u) { budget -= 1u; u0 = fn1(6u, (unsigned)f0, (unsigned)c0); }
                            if (7u) goto L3;
                            v0 = ((unsigned)((unsigned)c1 && p0) | (garr[u2 & 7u] & garr[i1 & 7u]));
                        }
                    }
                    if ((unsigned)(signed char)((g0 + g1) % (v0 | 1u))) break;
                    a0[0x56e068b4u & 3u] = 1u;
                    do { if (--fuel == 0u) goto done;
                        if (a0[u1 & 3u]) continue;
                        if (0xffffffffu) break;
                        q0 = &garr[r0.y & 7u];
                    } while (i0++ < 5u && (unsigned)((unsigned)c1 == (unsigned)((unsigned)f0 == (unsigned)c0)));
                    h1 = (unsigned short)(h1 + (u0 % ((unsigned)w0 | 1u)));
                }
                v0 = (unsigned)((int)(6u - (unsigned)f0) >= (int)(unsigned)d0);
                d0 = d0 * 0.5 + (double)((*q0 + (unsigned)s1) & 1023u);
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    c1 = (signed char)(unsigned)c1;
                    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (r0.x) continue;
                        i2 = (unsigned)(u2 < 0x6fd88b54u) & 15u;
                        if (fuel) break;
                        if ((1u / (i0 | 1u))) break;
                        f0 = f0 * 0.5f + (float)((unsigned)((short)0xa749b726u > (signed char)r0.x) & 255u);
                        *mp = 0x47176e8au;
                    }
                    if (4u) continue;
                    *mp = g1;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1(u2, (unsigned)(signed char)(unsigned)((int)(unsigned)e0 < (int)(unsigned)((unsigned)c0 || 3u)), (unsigned)(short)(unsigned)((unsigned)s0 && 0x80000000u)); }
            }
            *q0 += garr[u2 & 7u];
        }
        f0 = f0 * 0.5f + (float)(0x27b164bau & 255u);
        break; (void)(3u);
    } while (i0++ < 3u && (unsigned)(unsigned char)(unsigned)(i2 == (unsigned)b0));
    if ((g1 | 0x10000u)) goto done;
    *q0 += (unsigned)((g1 + fuel) == g1);
    if (budget != 0u) { budget -= 1u; u0 = fn0(u2, (unsigned)((short)(unsigned)(signed char)(unsigned)((unsigned)b0 || 0xde094c5cu) > (signed char)r0.x), (1u << ((0x10000u / (0x63618b2u | 1u)) & 31u))); }
    if ((unsigned)((int)p1 < (int)(unsigned)(g0 == g0))) goto L2;
    s1 = (int)((unsigned)s1 + (fuel % ((*q0 / (m0 | 1u)) | 1u)));
    goto L2;
    e0 = e0 * 0.5L + (long double)(a0[u1 & 3u] & 1023u);
    while (i0++ < 3u && (unsigned)(unsigned char)(unsigned)((int)v0 >= (int)~(r0.x + (unsigned)s0))) { if (--fuel == 0u) goto done;
        break; (void)(0xffffffffu);
        if ((unsigned)h0) {
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 += u0;
                h0 = (short)(unsigned)(signed char)((unsigned)(a0[i0 & 3u] && 6u) >> ((unsigned)s1 & 31u));
                u0 ^= (unsigned)((short)(unsigned)c0 > (signed char)v0);
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)h1 >> ((unsigned)c0 & 31u)), (unsigned)s0, 8u); }
                switch (0xc51d5c7eu & 7u) {
                    *q0 = (unsigned)((int)(unsigned)(garr[i1 & 7u] < (unsigned)x0) < (int)(unsigned)((short)u1 > (signed char)p1));
                    if (budget != 0u) { budget -= 1u; u3 = fn1((i1 << (u2 & 31u)), (g1 >> ((p0 - (unsigned)e0) & 31u)), m0); }
                }
                if (u3 == 7u) return ((unsigned)l0 * 0x7fffffffu);
            }
            u2 = ((unsigned)((short)0x10000u > (signed char)(unsigned)b0) ^ p0);
            x0 = x0 * 0x100000001b3ull + ((unsigned)(signed char)((unsigned)(x0 >> 70) * (p2 + (unsigned)l0)) + (unsigned)c0);
            if ((unsigned)(0x10000u == ((unsigned)l0 + (unsigned)s0))) goto done;
        }
    }
    *q0 = garr[u2 & 7u];
    c0 = (unsigned char)((unsigned)(w0 >> 29) ? p0 : garr[i1 & 7u]);
    if (0xb3846a62u) goto L2;
    g0 = (unsigned)(short)((unsigned)(signed char)(unsigned)(i1 && r0.x) / ((unsigned)(u1 == 0x86cd1b70u) | 1u));
    if ((r0.x ? (unsigned)d0 : p1)) goto L4;
    r0.y ^= (p1 ^ (0x16af82feu % (p2 | 1u)));
    if ((i0 >> ((unsigned)f0 & 31u))) goto L0;
    switch ((unsigned)(((unsigned)s1 * p2) == (unsigned)h0) & 7u) {
        case 4u: ;
        if (4u) goto L2;
        { unsigned t4; double z4; if (((unsigned)((unsigned)(w0 >> 29) < i0)) & 1u) { t4 = 1u; z4 = (double)(((unsigned)((unsigned)c1 && g0)) & 255u); } if (((unsigned)((unsigned)(w0 >> 29) < i0)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
            case 2u: ;
        }
        *q0 += 0x7fffffffu;
        r0.y ^= (unsigned)w0;
    }
    while (i0++ < 7u && ((unsigned)((short)a0[i0 & 3u] > (signed char)u1) << ((unsigned)b0 & 31u))) { if (--fuel == 0u) goto done;
        switch (0x10000u & 7u) {
            *mp = ((unsigned)!(unsigned)(g1 < (unsigned)l0) - 0xa9f76ccdu);
            m0 ^= (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)((int)r0.x < (int)i2));
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)v0 >= (int)(unsigned)(g1 || u0)), (unsigned)(signed char)(0xffffffffu % ((unsigned)f0 | 1u)), (((unsigned)d0 - 4u) >> ((unsigned)(w0 >> 29) & 31u))); }
        }
        break; (void)(0x10000u);
        v0 = ((unsigned)((int)0x9d8c7bc0u >= (int)5u) % ((unsigned)h0 | 1u));
        goto L2;
    }
    goto L2;
    if ((unsigned)((unsigned)x0 || ((unsigned)b0 ^ i2))) goto done;
    { unsigned t5; double z5; if (((unsigned)(0x2374df7bu && i1)) & 1u) { t5 = (unsigned)((int)i0 < (int)g0); z5 = (double)((((u0 ^ (unsigned)w0) | g0)) & 255u); } if (((unsigned)(0x2374df7bu && i1)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
        if (((unsigned)((int)(unsigned)x0 >= (int)0x8e72a126u) | 7u)) goto done;
    }
    switch (v0 & 7u) {
        d0 = d0 * 0.5 + (double)((unsigned)((int)((0xffffffffu * m0) / (a0[i0 & 3u] | 1u)) >= (int)garr[u2 & 7u]) & 1023u);
    }
    d0 = d0 * 0.5 + (double)((~(garr[u2 & 7u] ? garr[u2 & 7u] : (unsigned)d0) / (u2 | 1u)) & 1023u);
    do { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)(((unsigned)w0 / (*q0 | 1u)) & 1023u);
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(w0 >> 29) + fuel), ((unsigned)s1 / (garr[u2 & 7u] | 1u)), ((unsigned)s0 / (((unsigned)e0 * (unsigned)x0) | 1u))); }
        if ((*q0 - *mp)) break;
        if ((unsigned)h0) break;
    } while (i0++ < 7u && 0xffffffffu);
    r0.x = (unsigned)(unsigned char)(unsigned)(((unsigned)(x0 >> 70) ^ (unsigned)h1) < (0x10000u ? 0x10000u : 2u));
    h0 = (short)(0x7fa2f888u ^ p2);
    r0.x = (garr[i1 & 7u] / ((unsigned)x0 | 1u));
    goto done;
    if ((p2 << ((u1 - 0x5a666ea1u) & 31u))) goto L3;
    if (((a0[u1 & 3u] - i2) - (unsigned)e0)) goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((((unsigned)s0 % ((unsigned)s1 | 1u)) & 0xffffffffu)) goto L2;
    L0: if (--fuel == 0u) goto done;
    q0 = &garr[((unsigned)c0 ^ (0xe5426510u ^ ~(u1 / ((unsigned)(unsigned char)(unsigned)(g0 < p0) | 1u)))) & 7u];
    *q0 = (fuel ? (p1 ^ *q0) : (unsigned)f0);
    h1 = (unsigned short)(h1 + -(u2 * (unsigned)s0));
    c0 = (unsigned char)(unsigned)(signed char)(unsigned)((int)g1 >= (int)0x4d499d5du);
    if (((unsigned)(x0 >> 70) << ((unsigned)f0 & 31u))) goto done;
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)b0, (unsigned)f0, 4u); }
    do { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + r0.y);
        g0 = (0x10000u - -(p2 | 3u));
        while (i1++ < 5u && g0) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((garr[i1 & 7u] << (0x7fffffffu & 31u)), (unsigned)(p1 && g1), (i1 >> ((unsigned)((unsigned)h1 || u1) & 31u))); }
            i0 = (unsigned)((short)((unsigned)s1 - (unsigned)d0) > (signed char)((0xe66bdf51u + 8u) ^ 2u)) & 15u;
            c1 = (signed char)g0;
        }
    } while (i0++ < 7u && ~(a0[u1 & 3u] << ((unsigned)(signed char)(unsigned)((short)0x7fffffffu > (signed char)g0) & 31u)));
    l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(unsigned)(0xac44e0cdu < 0xffffffffu));
    s1 = (int)((unsigned)s1 + ((unsigned)(1u && (unsigned)w0) >> ((unsigned)((int)i0 >= (int)p0) & 31u)));
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)!(unsigned)((int)r0.x < (int)fuel), (9u & *q0), (unsigned)((unsigned)((int)p2 < (int)v0) < 0u)); }
    f0 = f0 * 0.5f + (float)((unsigned)(signed char)(unsigned)((int)(unsigned)h1 >= (int)0x80000000u) & 255u);
    b0 = (unsigned)((unsigned)(signed char)(unsigned)((short)(u2 / (u1 | 1u)) > (signed char)garr[u2 & 7u]) == (unsigned)(x0 >> 70)) != 0u;
    goto L0;
    if ((unsigned)(i1 == (unsigned)((int)0x80000000u < (int)p1))) {
        s0 = (int)(((unsigned)e0 / ((unsigned)(signed char)((unsigned)(w0 >> 29) % (g0 | 1u)) | 1u)) << (8u & 31u));
        h0 = (short)(unsigned)((unsigned)s0 == *q0);
        if (budget != 0u) { budget -= 1u; u1 = fn2(-(p0 - (unsigned)((unsigned)(w0 >> 29) < 2u)), 0u, ~(r0.y - 2u)); }
        { unsigned t0; double z0; if ((p1) & 1u) { t0 = (unsigned)((unsigned)((int)i2 < (int)u1) || (unsigned)h0); z0 = (double)(((unsigned)!(6u & 0x6705e0fu)) & 255u); } if ((p1) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            u0 = u0 * 0x9e3779b1u + (unsigned)(0xf2d1f43fu || (unsigned)(unsigned char)(0xffffffffu / (p2 | 1u)));
            if ((r0.y << ((unsigned)(i1 == p1) & 31u))) {
                if (9u) goto L0;
                if (6u) {
                    if (~((unsigned)w0 | i1)) goto L3;
                } else {
                    a0[((unsigned)s1 % (g0 | 1u)) & 3u] = ((0xc44a45cdu % (a0[i0 & 3u] | 1u)) - (r0.x ? 0x923b33cau : (unsigned)w0));
                }
                h0 = (short)(0x87f40196u / ((unsigned)(a0[u1 & 3u] < garr[i1 & 7u]) | 1u));
                if ((0x7fffffffu >> (a0[u1 & 3u] & 31u))) goto L4;
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(w0 >> 29), (unsigned)d0, (~(0xffffffffu ^ p2) & i0)); }
            } else {
                if (0x10000u) goto L0;
                if (-(i0 + r0.x)) goto done;
                if ((fuel + 0x372fd9a5u)) goto L4;
                for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)((p0 * (unsigned)(p2 < u3)) == 0x582eb29au);
                    i0 = (unsigned)(unsigned char)(u3 >> (i0 & 31u)) & 15u;
                }
            }
            while (i0++ < 3u && (*q0 ^ garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                if ((unsigned)c1) break;
                L1: if (--fuel == 0u) goto done;
            }
            if (0x10000u) goto L2;
            q0 = &garr[(unsigned)((int)((unsigned)w0 * (unsigned)(fuel == 0x283eda90u)) >= (int)(0x80000000u >> (r0.x & 31u))) & 7u];
            if (((u3 & *mp) - (unsigned)l0)) goto L0;
        }
        if (((u1 | 0x493cb425u) + (unsigned)c0)) {
            l0 = (long)((unsigned long)l0 + u3);
            goto L1;
            l0 = (long)((unsigned long)l0 + (unsigned)s1);
            if (i2) goto L3;
        }
    } else {
        h0 = (short)*mp;
        L2: if (--fuel == 0u) goto done;
        while (i0++ < 6u && ((g0 ^ (unsigned)h0) / (0x10000u | 1u))) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)x0 << (g1 & 31u)) || ((unsigned)(m0 == i2) + (unsigned)h0)));
            m0 ^= ((unsigned)((int)(unsigned)(w0 >> 29) < (int)g1) % ((unsigned)((int)0xffffffffu >= (int)0x363751e7u) | 1u));
        }
    }
    if (0x10000u) goto L4;
    d0 = d0 * 0.5 + (double)(~(u1 % ((8u ^ u3) | 1u)) & 1023u);
    h0 = (short)(unsigned)((int)garr[u2 & 7u] < (int)((unsigned)b0 ? 2u : i1));
    if ((unsigned)((int)(unsigned)((short)i0 > (signed char)0u) >= (int)p2)) {
        a0[~(unsigned)((int)r0.x >= (int)r0.x) & 3u] = garr[u2 & 7u];
    } else {
        if ((~(unsigned)(1u < 0xb72a54afu) + (unsigned)c1)) goto done;
        u3 = (unsigned)(signed char)(i0 | garr[i1 & 7u]);
    }
    w0 = w0 * 6364136223846793005ull + (a0[i0 & 3u] << (((unsigned)s0 / ((unsigned)h1 | 1u)) & 31u));
    if (0xcfb96153u) {
        goto L0;
        do { if (--fuel == 0u) goto done;
            u2 += (unsigned)((short)((*mp + 0xa3f7b085u) + fuel) > (signed char)(unsigned)(short)(p0 << ((unsigned)e0 & 31u)));
            if (budget != 0u) { budget -= 1u; u0 = fn1(m0, (unsigned)s0, (r0.x * p1)); }
            L3: if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + 0u);
            L4: if (--fuel == 0u) goto done;
            g0 = (unsigned)((int)0x54e88ca3u >= (int)(unsigned)(unsigned char)(unsigned)((int)(unsigned)d0 < (int)i2));
        } while (i0++ < 4u && (unsigned)(signed char)(unsigned)((short)(i0 << (1u & 31u)) > (signed char)0x9781ab61u));
        x0 = x0 * 0x100000001b3ull + (unsigned)(u3 == (((unsigned)s0 << (0x10000u & 31u)) / ((unsigned)((unsigned)w0 && 5u) | 1u)));
        goto L0;
        if (u2) {
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2(0x7fffffffu, (unsigned)(short)((unsigned)s0 & ((unsigned)(x0 >> 70) & *mp)), 0x80000000u); }
            } while (i0++ < 2u && (unsigned)b0);
            b0 = ((8u | 0xffffffffu) % ((unsigned)!(unsigned)((short)(unsigned)f0 > (signed char)(unsigned)!((unsigned)l0 - 0x9254f4a2u)) | 1u)) != 0u;
            while ((a0[u1 & 3u] & 0x80000000u)) { if (--fuel == 0u) goto done;
                m0 ^= ((unsigned)((int)(unsigned)c1 >= (int)(u2 & (unsigned)b0)) & 0x8f2d004du);
            }
            if ((unsigned)(a0[i0 & 3u] < (unsigned)l0)) goto L1;
            while ((unsigned)s1) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(signed char)(0xccd9792eu ^ (unsigned)f0));
            }
        } else {
            goto L2;
        }
    } else {
        if ((unsigned)((short)(unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)e0) > (signed char)garr[u2 & 7u])) goto L0;
        if ((unsigned)((int)0xffffffffu < (int)i0)) {
            h0 = (short)~(*q0 ^ ((unsigned)(w0 >> 29) ^ ((unsigned)(unsigned char)((unsigned)s0 + 0xffffffffu) + a0[u1 & 3u])));
            goto L3;
            *mp = (3u ^ (i0 & (unsigned)(short)(unsigned)(u3 || (unsigned)((unsigned)d0 && 4u))));
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)p0 < (int)0x7fffffffu)) break;
        }
    }
    while ((unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
        if (i2) break;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= ((((unsigned)s1 % (((unsigned)b0 * garr[i1 & 7u]) | 1u)) ^ 0xbffbcbacu) / (0x10000u | 1u));
        do { if (--fuel == 0u) goto done;
            u1 += (((unsigned)s1 / ((2u + 9u) | 1u)) | 0x20507258u);
            if ((a0[u1 & 3u] >> ((fuel & (unsigned)l0) & 31u))) {
                b0 = ((unsigned)((int)(5u % ((unsigned)((unsigned)d0 || (unsigned)x0) | 1u)) < (int)a0[i0 & 3u]) << (r0.x & 31u)) != 0u;
                if (budget != 0u) { budget -= 1u; u0 = fn2(m0, -(unsigned)((short)0xa9fd513du > (signed char)(unsigned)b0), ((unsigned)s0 ^ 0x54cba56eu)); }
                while (i2++ < 5u && m0) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)(fuel || (unsigned)h1)) break;
                        x0 = x0 * 0x100000001b3ull + a0[i0 & 3u];
                        e0 = e0 * 0.5L + (long double)(((unsigned)b0 % ((fuel ^ (unsigned)(p0 || 3u)) | 1u)) & 1023u);
                    } while (i0++ < 6u && 1u);
                }
                h1 = (unsigned short)(h1 + (unsigned)x0);
            } else {
                if ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)w0)) break;
                for (;;) { if (--fuel == 0u) goto done;
                    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        h0 = (short)(unsigned)((int)(unsigned)((int)((unsigned)d0 & (unsigned)(w0 >> 29)) >= (int)m0) < (int)*q0);
                    }
                }
                if (((garr[i1 & 7u] + u1) + (unsigned)h0)) break;
                if ((unsigned)(signed char)(2u ? u2 : (unsigned)h1)) goto L3;
            }
        } while (i1++ < 6u && garr[i1 & 7u]);
        v0 = -((unsigned)(a0[i0 & 3u] < 2u) ^ (unsigned)((int)u3 >= (int)a0[i0 & 3u]));
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                m0 ^= a0[u1 & 3u];
                for (;;) { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + ((unsigned)(i1 || (unsigned)f0) | 0x871ab222u));
                    if ((unsigned)((unsigned)c1 == (unsigned)s1)) goto L1;
                    garr[g0 & 7u] = (0xf2c6b114u % (((unsigned)!(unsigned)(g1 && 0xffffffffu) << (garr[u2 & 7u] & 31u)) | 1u));
                    x0 = x0 * 0x100000001b3ull + (6u * 0x7fffffffu);
                }
                do { if (--fuel == 0u) goto done;
                    v0 = (2u | 0x10000u);
                    for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((2u & (unsigned)((int)r0.x < (int)p1))) break;
                        m0 ^= (unsigned)((unsigned)(unsigned char)((unsigned)(a0[i0 & 3u] && (unsigned)d0) & (unsigned)x0) < 0x36bfca9cu);
                        g0 = (unsigned)((short)(unsigned)f0 > (signed char)(unsigned)(signed char)(0x2d711e79u - u3));
                    }
                    *mp = (unsigned)((unsigned)(w0 >> 29) == (*mp << ((unsigned)l0 & 31u)));
                    if ((unsigned)(signed char)((unsigned)(7u || (unsigned)f0) << (i0 & 31u))) {
                        if (budget != 0u) { budget -= 1u; u1 = fn0((((unsigned)h0 / (0x6b079625u | 1u)) << ((unsigned)x0 & 31u)), (unsigned)(g1 && (unsigned)(short)(p0 + u2)), (unsigned)s1); }
                        if (~((unsigned)s1 * g1)) break;
                    } else {
                        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                            *q0 += (a0[i0 & 3u] % ((unsigned)d0 | 1u));
                            u1 = (unsigned)((unsigned)(short)(7u * 4u) == (u2 >> (2u & 31u)));
                            b0 = (unsigned)((unsigned)w0 || (-(unsigned)((unsigned)e0 == u3) / (5u | 1u))) != 0u;
                        }
                        i2 = (((unsigned)((int)0x7fffffffu < (int)(0xc3f69fdeu << (*mp & 31u))) << ((unsigned)x0 & 31u)) / ((unsigned)f0 | 1u)) & 15u;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((garr[u2 & 7u] / (u0 | 1u)), (garr[u2 & 7u] ^ u3), (unsigned)f0); }
                        v0 = (unsigned)((short)(unsigned)!(i0 << (0x8b5a85f3u & 31u)) > (signed char)(unsigned)(i2 && 2u));
                    }
                    s0 = (int)((unsigned)!(0x10000u * (garr[u2 & 7u] >> ((unsigned)l0 & 31u))) / (m0 | 1u));
                } while (i0++ < 2u && ((unsigned)((int)u0 < (int)3u) | (unsigned)c1));
            } while (i2++ < 3u && (*q0 % ((unsigned)(short)(i1 << (p2 & 31u)) | 1u)));
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                *q0 = ((unsigned)e0 << ((unsigned)((int)(unsigned)d0 < (int)8u) & 31u));
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)h0, g0, ~(1u % ((unsigned)e0 | 1u))); }
                if ((u2 % (5u | 1u))) goto L3;
                if (p0) break;
                s1 = (int)((unsigned)s1 + (a0[u1 & 3u] % (0xffffffffu | 1u)));
                switch (garr[i1 & 7u] & 7u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)s0, (unsigned)c0, (a0[i0 & 3u] ^ (r0.y >> (garr[i1 & 7u] & 31u)))); }
                    goto L4;
                    f0 = f0 * 0.5f + (float)((unsigned)(short)((unsigned)(short)(unsigned)((unsigned)b0 == ((unsigned)c1 + (unsigned)x0)) | (u1 - 0x80000000u)) & 255u);
                    goto L2;
                    case 0u: ;
                }
            }
            u0 ^= (unsigned)(i2 || ((9u % (0u | 1u)) / (a0[i0 & 3u] | 1u)));
            if (((0x10000u / (0x7fffffffu | 1u)) & (unsigned)w0)) goto L0;
            break; (void)(i0);
        }
        v0 = (unsigned)((garr[u2 & 7u] ? (unsigned)d0 : g0) < (unsigned)w0);
    }
    if ((unsigned)(signed char)(unsigned)(0x73013e77u == 0xe1990698u)) goto L2;
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)7u < (int)(unsigned)((int)p2 >= (int)r0.x)), (*q0 & 7u), (u1 * 9u)); }
    if (0x6d3627c2u) goto L3;
    *q0 += ((unsigned)c0 - (6u - p1));
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(fuel < (unsigned)!(unsigned)((int)g0 < (int)g1)), 4u, (unsigned)((int)u1 < (int)(unsigned)h1)); }
    goto L4;
    if ((unsigned)(0x15f22c80u || (0x80000000u & g1))) goto L3;
    u3 = ((unsigned)(x0 >> 70) + (r0.x / ((unsigned)((int)u2 < (int)p1) | 1u)));
    if ((unsigned)((int)(unsigned)f0 < (int)(unsigned)((int)r0.y < (int)0xffffffffu))) goto L0;
    while (i0++ < 6u && (unsigned)(unsigned char)(unsigned)((int)0x10000u >= (int)(unsigned)c1)) { if (--fuel == 0u) goto done;
        q0 = &garr[a0[u1 & 3u] & 7u];
        w0 = w0 * 6364136223846793005ull + 0x623068eau;
        b0 = (unsigned)(signed char)(unsigned)((int)(unsigned)(x0 >> 70) < (int)a0[u1 & 3u]) != 0u;
    }
    if ((u3 & (0x7fffffffu >> (0xffffffffu & 31u)))) {
        *q0 = (p1 | (p0 >> (p2 & 31u)));
        if ((0x7fffffffu & v0)) goto L4;
    } else {
        d0 = d0 * 0.5 + (double)((0x85935a9cu & ((unsigned)w0 ? i2 : i1)) & 1023u);
    }
    if ((unsigned)(short)(unsigned)((short)((unsigned)(x0 >> 70) >> (a0[i0 & 3u] & 31u)) > (signed char)(unsigned)b0)) goto done;
    if ((unsigned)(short)((unsigned)(w0 >> 29) ^ (unsigned)h0)) goto L1;
    goto L1;
    if (budget != 0u) { budget -= 1u; u2 = fn2(((r0.y / ((unsigned)b0 | 1u)) / (0xe7b47f8eu | 1u)), ((unsigned)(x0 >> 70) % (0x124e7da5u | 1u)), (unsigned)!(6u / ((unsigned)(x0 >> 70) | 1u))); }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t1; double z1; if ((u0) & 1u) { t1 = (u3 + ((unsigned)w0 & (unsigned)h1)); z1 = (double)((garr[u2 & 7u]) & 255u); } if ((u0) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            r0.y ^= (unsigned)(signed char)((0x7fffffffu << (u3 & 31u)) & i0);
            *q0 = (unsigned)((unsigned)((int)u3 >= (int)p1) == (p1 ? 6u : 0x3bfaa14du));
            { unsigned t2; double z2; if (((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)(v0 && (unsigned)s1))) & 1u) { t2 = u1; z2 = (double)(((unsigned)(x0 >> 70)) & 255u); } if (((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)(v0 && (unsigned)s1))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                r0.y ^= (unsigned)(signed char)((0x7fffffffu >> (i1 & 31u)) % (0xffffffffu | 1u));
                if ((unsigned)(0x1356f706u && (unsigned)s1)) goto L1;
                u1 += (unsigned)((int)v0 >= (int)(0xe9623ffau / (u2 | 1u)));
            }
            do { if (--fuel == 0u) goto done;
                break; (void)(((fuel | (unsigned)(w0 >> 29)) >> (v0 & 31u)));
                u1 ^= ((unsigned)((unsigned)c1 == p2) - (0x706de74bu / (0x8c7c1226u | 1u)));
            } while (i1++ < 7u && (unsigned)e0);
        }
        while ((r0.y << (0xffffffffu & 31u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((6u & (unsigned)(w0 >> 29)), (unsigned)h0, (unsigned)(u2 || (2u >> ((unsigned)b0 & 31u)))); }
            break; (void)((unsigned)c0);
            while (i0) { if (--fuel == 0u) goto done;
                h0 = (short)((unsigned)(i2 && (unsigned)(signed char)(unsigned)((short)8u > (signed char)0xffffffffu)) | fuel);
                { unsigned t3; double z3; if (((unsigned)((unsigned)(unsigned char)(0x6c4a0e46u >> (0x1d86b9e3u & 31u)) || 4u)) & 1u) { t3 = ((unsigned)e0 * i2); z3 = (double)(((unsigned)((short)(unsigned)(0xbf24f801u || u3) > (signed char)a0[u1 & 3u])) & 255u); } if (((unsigned)((unsigned)(unsigned char)(0x6c4a0e46u >> (0x1d86b9e3u & 31u)) || 4u)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                    continue; (void)((unsigned)f0);
                    *mp = (0x10000u | (i2 >> (1u & 31u)));
                    if (p1) goto done;
                    break; (void)((unsigned)((unsigned)c1 == v0));
                    u2 = u2 * 0x9e3779b1u + ((unsigned)((short)(unsigned)c1 > (signed char)r0.x) * (unsigned)c0);
                }
                { unsigned t4; double z4; if ((a0[i0 & 3u]) & 1u) { t4 = r0.y; z4 = (double)(((unsigned)((unsigned)(x0 >> 70) && (unsigned)d0)) & 255u); } if ((a0[i0 & 3u]) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    s1 = (int)((unsigned)s1 + ((unsigned)((int)(0x80000000u | r0.y) >= (int)0x320949ceu) >> ((p1 >> (1u & 31u)) & 31u)));
                    m0 ^= (unsigned)(p2 || (0x9c2d974fu ^ 0xe8141e42u));
                }
                if (fuel < 8u) return (unsigned)((unsigned)c1 < u3);
                h1 = (unsigned short)(h1 + (unsigned)(fuel && (unsigned)e0));
            }
            a0[(0x7fffffffu - 0x64cbf366u) & 3u] = fuel;
            switch (((unsigned)h1 & -(unsigned)((short)4u > (signed char)6u)) & 7u) {
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    g1 += (unsigned)((unsigned)(w0 >> 29) || ((unsigned)e0 / (0xa07f0e83u | 1u)));
                }
                *mp = (p2 - *mp);
                if (u3 == 7u) return a0[i0 & 3u];
                x0 = x0 * 0x100000001b3ull + (unsigned)(((r0.x / (i0 | 1u)) << (((unsigned)e0 - p1) & 31u)) && p2);
                m0 ^= (unsigned)(p1 || 0x10000u);
            }
        }
        m0 ^= (unsigned)d0;
        if (budget != 0u) { budget -= 1u; u1 = fn2(((0x90258279u + u2) * u1), ((unsigned)s1 % (u2 | 1u)), (unsigned)(fuel || a0[u1 & 3u])); }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((0xc71488b5u >> (0xffffffffu & 31u))) {
                if ((unsigned)((int)(unsigned)h0 < (int)0xda554e4fu)) {
                    *mp = (0xc6c6b4eau + (unsigned)(((unsigned)s1 - a0[i0 & 3u]) || p0));
                }
                do { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)r0.x << ((unsigned)c0 & 63u);
                    if (budget != 0u) { budget -= 1u; u2 = fn1(i2, m0, (unsigned)((unsigned)(g1 < r0.y) < 0xffffffffu)); }
                    if ((m0 >> (g1 & 31u))) goto L0;
                    if (~(unsigned)(6u && (unsigned)e0)) {
                        f0 = f0 * 0.5f + (float)((unsigned)(p1 < 7u) & 255u);
                        v0 = (unsigned)(0xe515d161u && fuel);
                        switch (garr[i1 & 7u] & 7u) {
                            if (r0.y) break;
                            case 0u: ;
                            if (budget != 0u) { budget -= 1u; u2 = fn1(0u, (p1 | (unsigned)s1), (unsigned)s0); }
                            case 4u: ;
                            h1 = (unsigned short)(h1 + ((unsigned)c0 & (0x80000000u / ((unsigned)c0 | 1u))));
                            case 5u: ;
                        }
                        c0 = (unsigned char)((unsigned)((unsigned)((unsigned)(x0 >> 70) < i2) && u2) / ((unsigned)((int)garr[u2 & 7u] >= (int)0x80000000u) | 1u));
                        if ((i1 ^ (unsigned)(w0 >> 29))) continue;
                        if ((7u ? i1 : p2)) continue;
                    }
                    do { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(unsigned)(0x7fffffffu && (unsigned)(r0.y == 0x7fffffffu));
                            if (budget != 0u) { budget -= 1u; u0 = fn0((a0[i0 & 3u] % (fuel | 1u)), (unsigned)(signed char)(unsigned)((short)-(unsigned)((int)m0 >= (int)a0[u1 & 3u]) > (signed char)p2), (unsigned)(w0 >> 29)); }
                            break; (void)((unsigned)(0xffffffffu || (i2 + p2)));
                            r0.y ^= (((unsigned)b0 & g0) ? (unsigned)((unsigned)l0 < v0) : r0.y);
                            c0 = (unsigned char)(-((i1 - ((unsigned)s1 ^ *mp)) / (i2 | 1u)) ^ u1);
                            if ((0xe8cff7b2u ^ i1)) break;
                        } while (i1++ < 7u && u3);
                        u0 += ((unsigned)((int)fuel >= (int)garr[u2 & 7u]) % (0x7fffffffu | 1u));
                        if (budget != 0u) { budget -= 1u; u0 = fn2(fuel, (unsigned)((int)(u3 * (unsigned)f0) >= (int)8u), (0xb7c9f0b8u & (unsigned)((int)(unsigned)f0 < (int)u2))); }
                    } while (i0++ < 7u && ((unsigned)((short)garr[i1 & 7u] > (signed char)fuel) >> (u3 & 31u)));
                } while (i2++ < 3u && ((0x7fffffffu >> ((unsigned)w0 & 31u)) ^ a0[u1 & 3u]));
                u3 += (unsigned)((short)(garr[i1 & 7u] + 5u) > (signed char)(unsigned)((int)(unsigned)h1 < (int)5u));
            } else {
                f0 = f0 * 0.5f + (float)(~((p1 * (unsigned)(a0[i0 & 3u] || garr[u2 & 7u])) % ((unsigned)b0 | 1u)) & 255u);
                continue; (void)((unsigned)(x0 >> 70));
                s0 = (int)(unsigned)(unsigned char)(unsigned)((unsigned)(a0[i0 & 3u] && 0x80000000u) && (unsigned)(w0 >> 29));
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    a0[(fuel & (unsigned)f0) & 3u] = ((unsigned)(i0 && 1u) % (((unsigned)(garr[i1 & 7u] < a0[i0 & 3u]) - *q0) | 1u));
                }
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn1(fuel, (unsigned)((short)(i0 + u2) > (signed char)0xffffffffu), 0x164995e7u); }
    }
    v0 = (0x8a803a0au >> ((unsigned)(signed char)(0x80000000u % (0x10000u | 1u)) & 31u));
    while ((0xffffffffu ^ 6u)) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (m0) break;
            if ((((unsigned)h1 % (r0.x | 1u)) << (u3 & 31u))) break;
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((p1 ? 0x80000000u : p2)) goto L4;
                do { if (--fuel == 0u) goto done;
                    r0.x = (*q0 << (0x10000u & 31u));
                    break; (void)((0x1f2883dcu ^ (unsigned)(w0 >> 29)));
                    if (a0[u1 & 3u]) {
                        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)((0x7fffffffu ^ garr[i1 & 7u]) - i2) & 1023u);
                    } else {
                        if (budget != 0u) { budget -= 1u; u0 = fn0(0x8a1c592eu, g0, ~((unsigned)s1 | 0u)); }
                    }
                } while (i0++ < 6u && (unsigned)((short)(unsigned)((int)4u >= (int)a0[u1 & 3u]) > (signed char)u2));
                *q0 += (u2 ^ 8u);
                u0 = u0 * 0x9e3779b1u + ((unsigned)((unsigned)((int)(unsigned)f0 >= (int)(unsigned)c0) == garr[u2 & 7u]) | (u1 + (unsigned)h0));
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)l0 - (unsigned)c0), p2, (u2 % (0xced204cbu | 1u))); }
                    if (budget != 0u) { budget -= 1u; u1 = fn1(u1, (unsigned)((unsigned)w0 || ((unsigned)b0 >> (*mp & 31u))), (unsigned)((unsigned)f0 || 0xc36c024fu)); }
                    u3 = u3 * 0x9e3779b1u + (g1 & (unsigned)((unsigned)h0 < u0));
                    if (p0) continue;
                    for (;;) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (p2 << ((unsigned)(short)(unsigned)(i1 < 0x80000000u) & 31u)));
                        do { if (--fuel == 0u) goto done;
                            x0 = x0 * 0x100000001b3ull + p0;
                            if (p2) break;
                            break; (void)((unsigned)s0);
                            h0 = (short)(0x26501c0u | ((0x7fffffffu - u3) & (unsigned)(w0 >> 29)));
                            if ((a0[i0 & 3u] ^ 0x80000000u)) break;
                            w0 ^= (unsigned long long)(0xffffffffu ^ (unsigned)h0) << ((unsigned)(unsigned char)(unsigned)((unsigned)((unsigned)b0 && (unsigned)((short)(unsigned)s1 > (signed char)2u)) < 5u) & 63u);
                        } while (i2++ < 4u && (0xa4e3afe5u % (((unsigned)x0 & fuel) | 1u)));
                        u3 += (unsigned)(w0 >> 29);
                    }
                }
                v0 = (0xb65d4ec1u % ((unsigned)(0x10000u < (unsigned)(0x19026acu == 0x7fffffffu)) | 1u));
            }
        }
    }
    *mp = (unsigned)((short)(unsigned)b0 > (signed char)(0xffffffffu >> ((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)(0u && (unsigned)d0)) & 31u)));
    if ((unsigned)l0) goto L4;
    goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L3;
    s1 = (int)((unsigned)s1 + 5u);
    if (((unsigned)((int)garr[u2 & 7u] >= (int)0u) + 0x80000000u)) {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.x = (unsigned)f0;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn3((0xffffffffu + ((unsigned)s0 + (unsigned)l0)), (unsigned)e0, ((garr[u2 & 7u] / (0x1d271806u | 1u)) & (unsigned)x0)); }
        L0: if (--fuel == 0u) goto done;
        u2 = u2 * 0x9e3779b1u + (unsigned)(u2 == ((unsigned)((unsigned)(w0 >> 29) && i2) >> ((unsigned)((int)0x80000000u < (int)(unsigned)s1) & 31u)));
    } else {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 = *q0;
        }
    }
    goto L4;
    if (((unsigned)w0 & (m0 << (0x39114ce2u & 31u)))) {
        goto done;
        if ((unsigned)((int)p2 >= (int)(unsigned)l0)) goto L2;
        switch ((unsigned)f0 & 7u) {
            e0 = e0 * 0.5L + (long double)((unsigned)((int)(p2 / ((unsigned)h1 | 1u)) >= (int)(unsigned)(3u && (unsigned)w0)) & 1023u);
            case 5u: ;
            while (i0++ < 4u && *mp) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)h0 * (unsigned)f0), (unsigned)(g0 < g1), 0xffffffffu); }
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (0xf76d06d0u) {
                        switch (0x7fffffffu & 7u) {
                            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(unsigned char)((0u * 0xffffffffu) / (a0[i0 & 3u] | 1u)), (unsigned)(unsigned char)(unsigned)(7u == i2), ((unsigned)f0 ? *mp : (unsigned)s0)); }
                            s0 = (int)(unsigned)((unsigned)((int)0x80000000u < (int)g0) < (0x7674f79au << (i2 & 31u)));
                            g0 = (unsigned)((int)(r0.y * (unsigned)((short)a0[i0 & 3u] > (signed char)0xffffffffu)) >= (int)u1);
                            continue; (void)(0x7fffffffu);
                        }
                        s0 = (int)(unsigned)!(0x93dff955u ^ i1);
                        e0 = e0 * 0.5L + (long double)((*mp - p0) & 1023u);
                    }
                    r0.y ^= ((0u | g1) ^ *q0);
                    h0 = (short)~(((r0.y >> (1u & 31u)) << (a0[u1 & 3u] & 31u)) ^ 0x80000000u);
                    w0 = w0 * 6364136223846793005ull + (0xffffffffu / (p0 | 1u));
                    if (budget != 0u) { budget -= 1u; u2 = fn3((0x62e1692bu * (unsigned)f0), (unsigned)((int)fuel >= (int)r0.x), ((r0.x + (unsigned)c0) - a0[i0 & 3u])); }
                    r0.x = (unsigned)(signed char)(5u << (a0[i0 & 3u] & 31u));
                }
                case 3u: ;
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = ((-(unsigned)((unsigned)x0 < u0) - garr[i1 & 7u]) * (unsigned)c0);
                }
                *mp = (-((unsigned)h0 + (0x80000000u & 0xffffffffu)) >> (((unsigned)s0 * 0xa09d6ce7u) & 31u));
                s0 = (int)(m0 >> ((unsigned)!(unsigned)(v0 && (unsigned)w0) & 31u));
            }
            { unsigned t0; double z0; if (((garr[i1 & 7u] & 5u)) & 1u) { t0 = ~(-(v0 << (*q0 & 31u)) << (p0 & 31u)); z0 = (double)(((9u & a0[i0 & 3u])) & 255u); } if (((garr[i1 & 7u] & 5u)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                if (0x848bfau) {
                    if (6u) {
                        e0 = e0 * 0.5L + (long double)((0x80000000u & *q0) & 1023u);
                        u3 = u3 * 0x9e3779b1u + (unsigned)((int)v0 >= (int)garr[u2 & 7u]);
                        *q0 += ((unsigned)e0 - ((6u << ((unsigned)h1 & 31u)) % (m0 | 1u)));
                        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)0xffffffffu < (int)(0x7fffffffu / ((unsigned)c0 | 1u))), (m0 + (u3 * *q0)), 0xfc7fdfa5u); }
                    } else {
                        goto L1;
                        if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(short)(garr[i1 & 7u] - (unsigned)(0x7fffffffu || p0)), (unsigned)((short)5u > (signed char)(unsigned)l0), u3); }
                        case 1u: ;
                    }
                    if ((1u / (p2 | 1u))) goto L4;
                } else {
                    x0 = x0 * 0x100000001b3ull + 0x61605eabu;
                    L1: if (--fuel == 0u) goto done;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)h0, (unsigned)((u3 / (g0 | 1u)) || 1u), (unsigned)d0); }
                r0.y ^= (m0 ^ (unsigned)(4u && (unsigned)c0));
            }
        }
    } else {
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(r0.y && 6u), ((unsigned)((unsigned)(x0 >> 70) < 6u) ^ 0x2a4a850fu), (unsigned)h1); }
        if (0xb42a27bu) {
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)((unsigned)h0 || 5u) >> (garr[u2 & 7u] & 31u)));
                i2 = ((0x8bdafc79u ? u1 : r0.x) << (i0 & 31u)) & 15u;
                while (p1) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + -(unsigned)((short)m0 > (signed char)(unsigned)((short)7u > (signed char)(unsigned)((unsigned)!(0xa4f263aeu / (p2 | 1u)) || (unsigned)b0)));
                    break; (void)((8u ^ 7u));
                    for (;;) { if (--fuel == 0u) goto done;
                        v0 = i0;
                        v0 = (unsigned)((short)(unsigned)((unsigned)((unsigned)l0 && 0x10000u) || 0x10000u) > (signed char)(unsigned)d0);
                        { unsigned t1; double z1; if (((unsigned)((short)i0 > (signed char)a0[i0 & 3u])) & 1u) { t1 = (unsigned)(signed char)(unsigned)((int)((unsigned)h1 + *mp) < (int)*q0); z1 = (double)(((((unsigned)h1 << (1u & 31u)) >> (0x557ed16au & 31u))) & 255u); } if (((unsigned)((short)i0 > (signed char)a0[i0 & 3u])) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                            if ((4u + u0)) continue;
                            u2 = ((unsigned)((int)4u < (int)0x848f1c86u) ^ 5u);
                            u0 = u0 * 0x9e3779b1u + (unsigned)((int)((unsigned)x0 + ((unsigned)f0 & garr[i1 & 7u])) >= (int)(unsigned)((int)0x10000u < (int)r0.y));
                            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)((int)0x80000000u < (int)0xfd17743fu) | u2), ((7u ^ (unsigned)s1) << ((unsigned)e0 & 31u)), (unsigned)w0); }
                            L2: if (--fuel == 0u) goto done;
                        }
                        if ((1u | 6u)) goto L4;
                        if (g0) continue;
                    }
                    if (g1) {
                        if ((unsigned)(short)((unsigned)s0 + (unsigned)h0)) goto done;
                        for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                            if ((3u + (unsigned)(unsigned char)(unsigned)(p0 && 0xbe35b0fdu))) break;
                            h0 = (short)(unsigned)h0;
                        }
                        u0 = u0 * 0x9e3779b1u + (((g1 << (i1 & 31u)) & (i0 % (8u | 1u))) % (a0[i0 & 3u] | 1u));
                    } else {
                        if ((unsigned)l0) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn1(p0, (unsigned)!(0xffffffffu * 0x10000u), u0); }
                    }
                    r0.x = ((unsigned)((int)*mp < (int)(unsigned)c1) - (unsigned)x0);
                }
                if (fuel < 8u) return i2;
                i2 = (unsigned)((int)(unsigned)w0 < (int)(0xbb9d179cu >> (g0 & 31u))) & 15u;
            }
            while (i0++ < 7u && 0xe83dc542u) { if (--fuel == 0u) goto done;
                u2 += (0x10000u | g1);
                if (0x39bc554du) goto done;
            }
            d0 = d0 * 0.5 + (double)(((unsigned)d0 & (unsigned)(i1 && i1)) & 1023u);
            if (garr[u2 & 7u]) goto L0;
        } else {
            u0 ^= (unsigned)((short)p1 > (signed char)(unsigned)((int)(6u | (u1 % (4u | 1u))) < (int)9u));
        }
        L3: if (--fuel == 0u) goto done;
    }
    L4: if (--fuel == 0u) goto done;
    do { if (--fuel == 0u) goto done;
        switch ((unsigned)(unsigned char)((unsigned)(x0 >> 70) * p0) & 7u) {
            switch ((unsigned)b0 & 7u) {
                goto L1;
                switch ((p2 ^ (unsigned)(0xbd459961u || r0.x)) & 7u) {
                    d0 = d0 * 0.5 + (double)(-(unsigned)(((unsigned)e0 + p0) && (g0 | g0)) & 1023u);
                    switch (i0 & 7u) {
                        if (budget != 0u) { budget -= 1u; u1 = fn2(8u, (unsigned)((2u + (unsigned)w0) && 0x2abed927u), (unsigned)((short)1u > (signed char)(u3 ^ 0xa3d97677u))); }
                        s1 = (int)((unsigned)s1 + (unsigned)(short)(((unsigned)d0 ? u2 : (unsigned)l0) % ((unsigned)h0 | 1u)));
                        while (i1++ < 6u && (p0 << (i2 & 31u))) { if (--fuel == 0u) goto done;
                            case 3u: ;
                            s0 = (int)(unsigned)(short)(unsigned)(((unsigned)h0 - (unsigned)w0) && (6u * (unsigned)(x0 >> 70)));
                        }
                        c0 = (unsigned char)(unsigned)((short)((unsigned)c0 + 0x80000000u) > (signed char)u2);
                        r0.x = ((unsigned)(0x80000000u || (unsigned)!(unsigned)(garr[u2 & 7u] && (unsigned)c0)) ^ p2);
                    }
                    e0 = e0 * 0.5L + (long double)((unsigned)(m0 && (unsigned)((unsigned)b0 && (unsigned)w0)) & 1023u);
                    i0 = 0x9d4ab61eu & 15u;
                    h0 = (short)((unsigned)(g1 || (unsigned)!(unsigned)((int)p2 < (int)(unsigned)!(0x7fffffffu - u1))) * 0x7fffffffu);
                    w0 = w0 * 6364136223846793005ull + (garr[u2 & 7u] % ((a0[i0 & 3u] << (((unsigned)w0 >> ((unsigned)s0 & 31u)) & 31u)) | 1u));
                }
                v0 = ((0x80000000u & (unsigned)c0) * (unsigned)((int)(unsigned)c1 < (int)((unsigned)d0 >> (p0 & 31u))));
                v0 = (unsigned)e0;
                i0 = (i1 ? (unsigned)(w0 >> 29) : (unsigned)l0) & 15u;
            }
        }
        for (;;) { if (--fuel == 0u) goto done;
            if (~(((unsigned)d0 / (0x54688e52u | 1u)) - (unsigned)d0)) break;
            if ((3u % ((unsigned)!((unsigned)w0 & *mp) | 1u))) goto L4;
            garr[(unsigned)e0 & 7u] = (unsigned)(0x20021ba0u < (unsigned)c1);
        }
        { unsigned t2; double z2; if ((~(unsigned)((unsigned)h0 && a0[i0 & 3u])) & 1u) { t2 = ((unsigned)(x0 >> 70) ^ 0x7fffffffu); z2 = (double)((a0[i0 & 3u]) & 255u); } if ((~(unsigned)((unsigned)h0 && a0[i0 & 3u])) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            do { if (--fuel == 0u) goto done;
                i1 = (unsigned)((int)(unsigned)(r0.x && (unsigned)e0) < (int)(unsigned)e0) & 15u;
                if ((0u + g0)) break;
                v0 = (unsigned)((0u & (unsigned)!(unsigned)(garr[u2 & 7u] < p0)) == 7u);
                *q0 = (i2 % ((unsigned)(3u || (unsigned)(4u && (a0[u1 & 3u] << (g0 & 31u)))) | 1u));
                if ((0x10000u | (0x7fffffffu * 0x80000000u))) {
                    f0 = f0 * 0.5f + (float)((garr[i1 & 7u] << ((unsigned)(short)((u1 % ((unsigned)e0 | 1u)) & ((unsigned)c0 + r0.x)) & 31u)) & 255u);
                    if ((unsigned)((0x52613138u - (unsigned)w0) == 6u)) break;
                    if (fuel < 8u) return (unsigned)((a0[i0 & 3u] * (unsigned)e0) == 0x10000u);
                    m0 ^= (unsigned)h1;
                }
            } while (i1++ < 3u && (garr[i1 & 7u] << (i0 & 31u)));
            if (fuel < 8u) return (unsigned)((int)(0x1beb3f92u + ~((unsigned)e0 / (6u | 1u))) < (int)(unsigned)e0);
            q0 = &garr[(unsigned)(((unsigned)x0 & 0x7fffffffu) < ((unsigned)s1 % ((3u % (2u | 1u)) | 1u))) & 7u];
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)b0);
                *mp = 0x10000u;
                if (fuel) {
                    if ((0xa1a9a637u & a0[u1 & 3u])) break;
                    { unsigned t3; double z3; if ((((unsigned)c0 & (0x25d0efc8u << (u2 & 31u)))) & 1u) { t3 = (unsigned)!(unsigned)((int)(unsigned)!(unsigned)(u1 || 6u) >= (int)u2); z3 = (double)(((unsigned)e0) & 255u); } if ((((unsigned)c0 & (0x25d0efc8u << (u2 & 31u)))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                        goto done;
                        for (;;) { if (--fuel == 0u) goto done;
                            s0 = (int)((unsigned)c0 ? (7u ? (unsigned)(x0 >> 70) : (unsigned)w0) : 0xffffffffu);
                            if ((unsigned)((int)((unsigned)l0 & 0x80000000u) >= (int)i2)) goto L4;
                            if ((unsigned)(p1 < 0x10000u)) goto L3;
                        }
                        i2 = (unsigned)((u1 + a0[u1 & 3u]) && r0.y) & 15u;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((p2 + 0x1b8bc722u), (unsigned)!(0x5b9152c6u / ((0x10000u / (0x52ea4e49u | 1u)) | 1u)), r0.y); }
                        if ((unsigned)(unsigned char)(unsigned)((int)(g1 >> ((unsigned)h0 & 31u)) >= (int)0x7fffffffu)) break;
                    }
                    if (u3 == 7u) return 3u;
                    if (a0[i0 & 3u]) break;
                } else {
                    u0 += 0x7fffffffu;
                    while (i2++ < 4u && -(unsigned)((int)(garr[i1 & 7u] ^ u0) < (int)v0)) { if (--fuel == 0u) goto done;
                        if ((unsigned)!(u3 & (r0.x ^ 0xfd6bc566u))) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn3(((2u - 0xffffffffu) << (0x7fffffffu & 31u)), m0, ((unsigned)h0 / (p2 | 1u))); }
                        if (p2) break;
                    }
                }
            }
            break; (void)((unsigned)(signed char)((0xb5015a5cu * (unsigned)h1) ^ 0x41926954u));
        }
        while (i1++ < 7u && (u3 + (unsigned)((short)p0 > (signed char)(unsigned)s1))) { if (--fuel == 0u) goto done;
            if ((unsigned)(short)(0x80000000u | (unsigned)((int)p2 < (int)g1))) {
                if (budget != 0u) { budget -= 1u; u3 = fn0(0xffffffffu, (unsigned)((int)u1 >= (int)*mp), ((unsigned)b0 / (0xffffffffu | 1u))); }
            } else {
                g1 += (unsigned)!((0x80000000u * 0x9c2741f8u) ^ (unsigned)h0);
                l0 = (long)((unsigned long)l0 + (unsigned)((int)fuel >= (int)((unsigned)b0 / (a0[i0 & 3u] | 1u))));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(r0.y && 0xffffffffu), ((a0[i0 & 3u] - p0) - (unsigned)h0), (*q0 - 0x68cb8680u)); }
                w0 = w0 * 6364136223846793005ull + i2;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)h1, (unsigned)(unsigned char)(i2 / ((unsigned)((short)r0.x > (signed char)(unsigned)x0) | 1u)), (0xffffffffu - (unsigned)h1)); }
        }
    } while (i0++ < 5u && (unsigned)(0xffffffffu || (unsigned)c0));
    if (~(((unsigned)h1 | (unsigned)b0) * 0x7fffffffu)) goto L2;
    switch (((6u % (9u | 1u)) / (0x11b5a578u | 1u)) & 7u) {
        case 5u: ;
        if ((i2 << ((3u - a0[i0 & 3u]) & 31u))) goto L1;
        if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)c0 * (unsigned)((unsigned)w0 < u3)), ((9u << (1u & 31u)) / (6u | 1u)), (0xaf61c04u % (u1 | 1u))); }
        w0 ^= (unsigned long long)~(unsigned)((short)garr[i1 & 7u] > (signed char)u3) << ((0xa7e8a2eu * u2) & 63u);
    }
    a0[(0xc9200418u - (unsigned)d0) & 3u] = (unsigned)s0;
    if ((unsigned)((unsigned)(0xffffffffu || (unsigned)s1) || r0.y)) {
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)s0 << (((unsigned)h1 ^ (2u * (unsigned)(garr[i1 & 7u] == 9u))) & 63u);
            *mp = ((unsigned)c0 % (0x10000u | 1u));
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(unsigned char)((unsigned)s0 >> (m0 & 31u)), 0xb7fea3e0u, 0xcb0192c0u); }
            *q0 += (0xbfc42919u ? p0 : 2u);
        }
    }
    x0 = x0 * 0x100000001b3ull + ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)l0) * (unsigned)x0);
    goto L3;
    *q0 = (unsigned)(*mp && g1);
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)((int)(0xde8d3347u / (0xe26d9dc8u | 1u)) < (int)0xffffffffu) >= (int)(unsigned)(x0 >> 70));
    c1 = (signed char)(0xffffffffu / ((i1 / ((unsigned)w0 | 1u)) | 1u));
    s0 = (int)((unsigned)(0x7fffffffu == 7u) * (unsigned)(short)(unsigned)(*q0 && 0u));
    s1 = (int)((unsigned)s1 + ((unsigned)h0 - (unsigned)(u2 < a0[u1 & 3u])));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (u0) {
            s0 = (int)((*q0 ? (unsigned)h0 : i2) - g0);
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                b0 = (0xc4d312u << (((6u - u3) * 0xa0121462u) & 31u)) != 0u;
                garr[(i0 ^ 6u) & 7u] = (u3 & (unsigned)((int)0x80000000u >= (int)(u2 - (unsigned)w0)));
                if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)e0 & i0), (u1 + u1), ((unsigned)h0 - (unsigned)d0)); }
            }
            goto L2;
        } else {
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(unsigned char)((u2 & u1) & i0)) goto L1;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)c0, ~(unsigned)((short)(unsigned)c1 > (signed char)(unsigned)h0), 9u); }
            }
            if ((0x4c38cc98u % (g1 | 1u))) goto L3;
            break; (void)((unsigned)c1);
        }
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            b0 = (i0 ^ (unsigned)s1) != 0u;
            if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((int)((unsigned)s0 % (0xd10fe4ffu | 1u)) < (int)v0), (unsigned)((unsigned)h0 == 0xec9efbbcu), (unsigned)((short)(unsigned)w0 > (signed char)*mp)); }
        }
        *mp = (unsigned)!((unsigned)((short)0x80000000u > (signed char)garr[i1 & 7u]) * (fuel / (4u | 1u)));
        s0 = (int)(unsigned)((int)(unsigned)c0 >= (int)~(garr[i1 & 7u] & p0));
        if ((unsigned)e0) goto L0;
    }
    if ((unsigned)(r0.x || (unsigned)h1)) goto L4;
    c1 = (signed char)(a0[u1 & 3u] - (unsigned)s1);
    garr[u0 & 7u] = (unsigned)(short)(unsigned)((int)i2 >= (int)(fuel & (unsigned)l0));
    if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)((int)0xe2030093u >= (int)(unsigned)c0), 9u, (unsigned)((int)0x80000000u < (int)p0)); }
    goto L1;
    do { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((~(unsigned)((a0[i0 & 3u] ? (unsigned)s0 : i2) || p1) | p1) & 255u);
        if (g1) break;
    } while (i0++ < 4u && (p0 % ((unsigned)d0 | 1u)));
    s0 = (int)2u;
    b0 = 0x6e8422ceu != 0u;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)b0 & 7u) {
            c1 = (signed char)(unsigned)(short)((unsigned)c1 << (~(unsigned)((int)i1 < (int)u2) & 31u));
            case 5u: ;
            u1 = u1 * 0x9e3779b1u + u1;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)((unsigned)(p2 && 7u));
                while (g1) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)(unsigned)(signed char)(r0.y & *mp) < (int)(unsigned)b0)) {
                        default: ;
                        if (budget != 0u) { budget -= 1u; u2 = fn2(u0, (0xffffffffu % (-(garr[i1 & 7u] << (u1 & 31u)) | 1u)), (0x80000000u & (unsigned)!(unsigned)((int)0x380981f1u < (int)u1))); }
                        if (budget != 0u) { budget -= 1u; u2 = fn0((garr[i1 & 7u] | ((unsigned)s1 / (i2 | 1u))), (unsigned)(unsigned char)(0x7fffffffu ^ (0xffffffffu & (unsigned)w0)), *mp); }
                        case 1u: ;
                        case 4u: ;
                        f0 = f0 * 0.5f + (float)(((~(unsigned)(p1 < u1) << ((unsigned)b0 & 31u)) | (unsigned)((unsigned)c0 || 2u)) & 255u);
                    } else {
                        w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(p1 || a0[i0 & 3u]) == (unsigned)d0);
                        u1 = (unsigned)((0x7fffffffu + 0x45d163c0u) && (unsigned)((int)((unsigned)l0 << (0u & 31u)) >= (int)0xc8828742u));
                    }
                    h1 = (unsigned short)(h1 + (unsigned)((int)0u >= (int)(unsigned)(x0 >> 70)));
                    g0 = ((*q0 * *q0) * (unsigned)(0x4181380au && (*q0 + 4u)));
                    do { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)(3u / (r0.x | 1u)) << (i0 & 63u);
                        s0 = (int)(a0[u1 & 3u] * 0x80000000u);
                        l0 = (long)((unsigned long)l0 + (unsigned)(garr[i1 & 7u] || (0x10000u << (r0.x & 31u))));
                        break; (void)((0x86369261u ^ (unsigned)b0));
                    } while (i0++ < 2u && (unsigned)(unsigned char)(unsigned)((short)0x80000000u > (signed char)fuel));
                    *q0 += (unsigned)(unsigned char)(unsigned)((int)0xc40d8255u >= (int)(unsigned)(0x7fffffffu && 0x10000u));
                }
                u1 = u1 * 0x9e3779b1u + (unsigned)((int)p1 >= (int)(1u ^ (0x29df18a3u ^ (unsigned)b0)));
            }
            case 7u: ;
        }
        w0 ^= (unsigned long long)3u << ((unsigned)(unsigned char)(p1 % ((unsigned)(((unsigned)w0 | 0x9988b783u) || v0) | 1u)) & 63u);
        do { if (--fuel == 0u) goto done;
            if ((a0[i0 & 3u] ? 0x951b7eacu : (unsigned)(x0 >> 70))) break;
            *q0 = (unsigned)x0;
            if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((short)(0xffffffffu * garr[u2 & 7u]) > (signed char)(unsigned)l0), 4u, (p1 * 0u)); }
            u2 = (garr[u2 & 7u] & (0x71b5a1b6u + a0[u1 & 3u]));
        } while (i1++ < 7u && (unsigned)x0);
        r0.x = (unsigned)((a0[u1 & 3u] % ((unsigned)h0 | 1u)) && v0);
        if (((*q0 & 1u) % (0x10000u | 1u))) break;
        l0 = (long)((unsigned long)l0 + p0);
    }
    if (((unsigned)((unsigned)w0 && g0) - u2)) goto L4;
    e0 = e0 * 0.5L + (long double)(((unsigned)((unsigned)(9u && (unsigned)s1) && (unsigned)d0) + p1) & 1023u);
    r0.x = ((unsigned)!(*mp & (unsigned)((int)(unsigned)f0 >= (int)g0)) * u0);
    if (budget != 0u) { budget -= 1u; u0 = fn1((r0.x << ((unsigned)c1 & 31u)), (unsigned)f0, 0x2f930a57u); }
    g0 = (unsigned)((unsigned)l0 && (unsigned)(short)(0x80000000u + *mp));
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)s0 > (signed char)(u1 / (0xf36e23ddu | 1u))), (((unsigned)c1 + 2u) & 0x8969bbaeu), (0x80000000u + garr[u2 & 7u])); }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)h0, p0, (unsigned)((0xcb7f679eu << (0x3f6c032fu & 31u)) && a0[i0 & 3u])); }
    do { if (--fuel == 0u) goto done;
        u0 = (((garr[u2 & 7u] >> (*q0 & 31u)) ^ ((unsigned)h1 % (i0 | 1u))) % ((unsigned)h0 | 1u));
        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((int)0xffffffffu < (int)9u) && (unsigned)((short)g1 > (signed char)g0)));
        while (i1++ < 7u && (unsigned)((int)(unsigned)c0 < (int)8u)) { if (--fuel == 0u) goto done;
            if (((unsigned)c0 ^ (unsigned)(0x36d66e57u == i2))) break;
            g0 = (unsigned)!(5u - (u2 >> (i2 & 31u)));
        }
        { unsigned t4; double z4; if (((0xb18be1d2u & (unsigned)(u3 == (unsigned)e0))) & 1u) { t4 = (unsigned)((int)p0 < (int)-(p2 % ((unsigned)c0 | 1u))); z4 = (double)(((unsigned)(signed char)(0x10000u << ((unsigned)(1u == *q0) & 31u))) & 255u); } if (((0xb18be1d2u & (unsigned)(u3 == (unsigned)e0))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(x0 >> 70), (unsigned)b0, (m0 + 8u)); }
            while ((0xffffffffu >> (garr[u2 & 7u] & 31u))) { if (--fuel == 0u) goto done;
                c1 = (signed char)((u3 * (unsigned)(x0 >> 70)) + (unsigned)((short)0x10000u > (signed char)2u));
            }
            s1 = (int)((unsigned)s1 + ((v0 * (unsigned)((unsigned)((int)2u >= (int)p0) == u2)) % ((unsigned)e0 | 1u)));
            if ((((unsigned)h0 & u3) & u2)) break;
        }
        u2 = u2 * 0x9e3779b1u + (unsigned)((1u >> (garr[u2 & 7u] & 31u)) || (unsigned)s0);
        if ((unsigned)h1) continue;
    } while (i0++ < 6u && (unsigned)(p0 && i2));
    garr[(garr[i1 & 7u] | p1) & 7u] = (fuel ^ p0);
    c1 = (signed char)((1u & i0) % ((unsigned)((int)p2 >= (int)g1) | 1u));
    u0 = u0 * 0x9e3779b1u + (m0 & 0x80000000u);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn3(~(i1 + r0.y), (0x80000000u << (0x10000u & 31u)), (unsigned)((unsigned)x0 == a0[u1 & 3u])); }
        i0 = ((unsigned)e0 | v0) & 15u;
        *q0 = ((r0.y ^ 0x9a4adaacu) >> ((unsigned)h1 & 31u));
        if ((unsigned)(a0[u1 & 3u] || (unsigned)(i2 < 0x46bbedb4u))) break;
    }
    if (((0x27974c6eu + (unsigned)f0) + p2)) goto L4;
    while (i0++ < 7u && (*mp + 2u)) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)(((0x10000u << (0x2a55f823u & 31u)) + (unsigned)(a0[u1 & 3u] == a0[i0 & 3u])) & 255u);
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = ((unsigned)s1 * (unsigned)(unsigned char)((unsigned)(garr[u2 & 7u] == (6u * (unsigned)c1)) + (unsigned)(w0 >> 29)));
    }
    if ((unsigned)((int)(unsigned)x0 >= (int)((unsigned)l0 ^ a0[i0 & 3u]))) goto L2;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = garr[i1 & 7u];
        if ((0x76e55ea2u & (unsigned)h0)) continue;
        f0 = f0 * 0.5f + (float)(((0x312da0bau >> (u3 & 31u)) | ((unsigned)l0 ? garr[i1 & 7u] : *mp)) & 255u);
        if ((unsigned)!(6u / ((unsigned)(5u < 0u) | 1u))) {
            { unsigned t5; double z5; if (((unsigned)s0) & 1u) { t5 = ((unsigned)(*mp < g1) * m0); z5 = (double)((-(unsigned)((int)9u >= (int)((unsigned)h1 / (0x2a9ea100u | 1u)))) & 255u); } if (((unsigned)s0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                r0.y ^= ~(unsigned)(((unsigned)f0 ^ (unsigned)((unsigned)b0 && (unsigned)h0)) == fuel);
                u3 += (~((unsigned)s1 >> (0x10000u & 31u)) ^ (unsigned)(p2 && g1));
                a0[g0 & 3u] = (p2 | garr[u2 & 7u]);
                break; (void)(((unsigned)((unsigned)h0 || garr[i1 & 7u]) - *q0));
                u1 += (unsigned)(i0 < (9u + u3));
            }
            l0 = (long)((unsigned long)l0 + ((unsigned)s0 / (g0 | 1u)));
            if ((m0 + (unsigned)h0)) continue;
            if (budget != 0u) { budget -= 1u; u2 = fn1(m0, ((unsigned)e0 % ((unsigned)h1 | 1u)), ((unsigned)s0 % (((unsigned)d0 >> (i2 & 31u)) | 1u))); }
        } else {
            break; (void)((unsigned)((int)(unsigned)w0 < (int)*q0));
            h1 = (unsigned short)(h1 + ~((p1 | 9u) - (2u >> ((unsigned)x0 & 31u))));
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)!((unsigned)c0 / ((0x1d0731c5u - 0x80000000u) | 1u)), (unsigned)((short)u2 > (signed char)3u), (1u ^ 4u)); }
        }
        v0 = *mp;
    }
    if ((unsigned)((int)(unsigned)c1 < (int)-((unsigned)f0 | (unsigned)b0))) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 1u, 0xdd5fcbfeu, 0xc88ffc1au },
        { 5u, 0xfffe4592u, 0xeb796f60u },
        { 0u, 0xe559b964u, 0xbaa9e87bu },
        { 5u, 0x508f7ee5u, 0x316a4930u },
        { 5u, 0x8ee03994u, 0x943cf3bdu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
