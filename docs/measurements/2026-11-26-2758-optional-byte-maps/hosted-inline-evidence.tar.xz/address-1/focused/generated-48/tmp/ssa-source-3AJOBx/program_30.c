// test-ssa-source's program of seed 134000432 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x2546fad9u, g1 = 0x9aff2d98u;
static unsigned garr[8] = { 0x5fd69646u, 0xaa0c2327u, 0x7263b3f5u, 0x56e0e18u, 0x9ed4644du, 0x9f22f80eu, 0xb70daf9eu, 0xa5c474dfu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    g1 += (0xadd27b5du % (0x8afee984u | 1u));
    u3 += 0u;
    if ((unsigned)w0) {
        L0: if (--fuel == 0u) goto done;
        if (((unsigned)w0 & ((unsigned)c0 + garr[u2 & 7u]))) {
            u3 = ((p1 & (unsigned)(6u == *q0)) - 0x567b4f00u);
            { unsigned t0; double z0; if (((unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)(garr[i1 & 7u] && 7u))) & 1u) { t0 = (unsigned)e0; z0 = (double)(((unsigned)(g1 || u2)) & 255u); } if (((unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)(garr[i1 & 7u] && 7u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                w0 = w0 * 6364136223846793005ull + (unsigned)h0;
            }
            q0 = &garr[(unsigned)((int)8u >= (int)(g1 ? (unsigned)e0 : u1)) & 7u];
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)s0) break;
                m0 ^= (garr[u2 & 7u] + (unsigned)d0);
                if ((unsigned)((int)4u < (int)-(unsigned)((int)0xffffffffu < (int)2u))) break;
                break; (void)((8u ^ (unsigned)(w0 >> 29)));
            }
            h1 = (unsigned short)(h1 + (i2 / ((unsigned)f0 | 1u)));
        } else {
            L1: if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)(x0 >> 70) || (v0 << (0x4a314518u & 31u)))) goto L4;
        }
        if (r0.x) goto L3;
        r0.x = (unsigned)(x0 >> 70);
        c0 = (unsigned char)(unsigned)((int)(0x7fffffffu * (unsigned)((unsigned)(w0 >> 29) < (unsigned)l0)) < (int)fuel);
    } else {
        garr[(unsigned)w0 & 7u] = 0x80000000u;
        *q0 = (garr[u2 & 7u] & ((unsigned)x0 / ((*mp >> (*mp & 31u)) | 1u)));
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)s1;
        L2: if (--fuel == 0u) goto done;
        if (-(i1 << ((unsigned)((int)a0[u1 & 3u] < (int)*mp) & 31u))) {
            break; (void)((unsigned)((int)(unsigned)x0 < (int)g1));
            L3: if (--fuel == 0u) goto done;
        }
    }
    if (fuel < 8u) return (unsigned)!((unsigned)(unsigned char)((unsigned)c1 / (0x18a5361au | 1u)) & (unsigned)(signed char)(6u & (v0 | *q0)));
    g0 = (unsigned)(p0 || ((i0 ? 9u : (unsigned)s0) - *q0));
    l0 = (long)((unsigned long)l0 + 0x5ca1aa6fu);
    do { if (--fuel == 0u) goto done;
        switch ((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)(0xe4656208u < (unsigned)f0)) & 7u) {
            switch (~(unsigned)((int)4u < (int)m0) & 7u) {
                continue; (void)((unsigned)((int)(unsigned)b0 >= (int)(unsigned)c1));
            }
        }
        while ((unsigned)(unsigned char)(unsigned)((unsigned)s1 == garr[u2 & 7u])) { if (--fuel == 0u) goto done;
            if ((0x10000u ? 1u : 3u)) goto L4;
        }
        do { if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
            switch (m0 & 7u) {
                case 4u: ;
                s1 = (int)((unsigned)s1 + (unsigned)(9u || i2));
                while (i2++ < 3u && (u3 * v0)) { if (--fuel == 0u) goto done;
                    if ((1u ^ p1)) goto L4;
                    s0 = (int)(unsigned)((unsigned)f0 || (unsigned)((int)(unsigned)(0xcbb49facu == r0.x) >= (int)(unsigned)(0x98d36518u && (unsigned)c0)));
                    r0.x = ((unsigned)h1 % ((unsigned)c0 | 1u));
                    c1 = (signed char)((r0.y - (unsigned)((int)u3 >= (int)u3)) << (p0 & 31u));
                }
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    case 7u: ;
                    w0 ^= (unsigned long long)(unsigned)h1 << (3u & 63u);
                    case 6u: ;
                    s0 = (int)(unsigned)((int)(3u / ((unsigned)h0 | 1u)) < (int)0x82ca563du);
                    g1 += ((unsigned)l0 ? 5u : a0[u1 & 3u]);
                    w0 ^= (unsigned long long)0x10000u << ((unsigned)((int)(unsigned)f0 >= (int)-(unsigned)((unsigned)x0 < (unsigned)c0)) & 63u);
                }
            }
            if ((unsigned)h0) break;
        } while (i1++ < 6u && ((unsigned)(p2 < 3u) ^ 0x432a8ba4u));
        a0[i0 & 3u] = 0x5e1af231u;
        s1 = (int)((unsigned)s1 + (unsigned)((garr[i1 & 7u] * 0xf0293d48u) < i2));
    } while (i0++ < 2u && (unsigned)((0x80000000u % (0x10000u | 1u)) || (unsigned)s0));
    if (i1) goto done;
    if (fuel) goto L2;
    if ((unsigned)(unsigned char)((unsigned)f0 / (g0 | 1u))) {
        h1 = (unsigned short)(h1 + (unsigned)((int)((5u - v0) % ((u1 - *q0) | 1u)) >= (int)0x10000u));
        if (((unsigned)s1 >> (r0.y & 31u))) goto done;
        while (i0++ < 5u && ((unsigned)e0 - u1)) { if (--fuel == 0u) goto done;
            if ((i0 % ((unsigned)((unsigned)h0 == m0) | 1u))) break;
        }
        goto L3;
    }
    if (0x10000u) goto L2;
    r0.x = ((0x76ac848cu / (g0 | 1u)) ^ (unsigned)!((unsigned)h1 - *q0));
    if ((unsigned)((int)0x288475c2u >= (int)*q0)) goto L1;
    if (5u) goto L4;
    e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)((p1 * (unsigned)(w0 >> 29)) || *mp) && ~((unsigned)s1 >> ((unsigned)s0 & 31u))) & 1023u);
    a0[0xaa2fa401u & 3u] = 0x6d20973eu;
    switch ((unsigned)(short)((unsigned)(0x1d9dd92du || 0u) ^ g1) & 7u) {
        c0 = (unsigned char)((unsigned)((0x8b9c2d6eu << (v0 & 31u)) || garr[u2 & 7u]) + garr[u2 & 7u]);
        case 1u: ;
        w0 = w0 * 6364136223846793005ull + (unsigned)s0;
        if ((0x7fffffffu + *q0)) goto L4;
    }
    l0 = (long)((unsigned long)l0 + (unsigned)s0);
    if (4u) {
        if ((unsigned)c0) goto L3;
        for (;;) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)u3;
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch (((unsigned)!(unsigned)((int)(unsigned)d0 < (int)garr[i1 & 7u]) / (0x80000000u | 1u)) & 7u) {
                    u1 ^= (unsigned)((short)p0 > (signed char)(unsigned)h1);
                    h1 = (unsigned short)(h1 + (p0 + *q0));
                    u3 ^= ((unsigned)(0x80000000u && u1) + 0xb5a73cecu);
                    s0 = (int)((unsigned)!(p2 % (g0 | 1u)) + -(unsigned)(0x10000u < p0));
                    if ((0x2a5b4e1eu ? 0xffffffffu : i1)) goto L1;
                }
            }
            c1 = (signed char)(((unsigned)c1 & (r0.y * ((unsigned)h1 ^ (unsigned)l0))) << ((unsigned)s1 & 31u));
            f0 = f0 * 0.5f + (float)(garr[u2 & 7u] & 255u);
        }
        *q0 = (*q0 / ((unsigned)((int)(unsigned)(fuel < a0[i0 & 3u]) < (int)0x10000u) | 1u));
    } else {
        if (((unsigned)w0 % ((unsigned)s1 | 1u))) goto L3;
        b0 = (unsigned)((int)(unsigned)d0 < (int)(unsigned)((int)p2 >= (int)(u0 ? 0x7e5c1bc0u : (unsigned)s0))) != 0u;
        while ((unsigned)((int)i2 >= (int)5u)) { if (--fuel == 0u) goto done;
            if ((0x10000u & (unsigned)((int)(unsigned)d0 < (int)g0))) break;
            if ((unsigned)(signed char)(unsigned)((unsigned)c0 || (unsigned)s0)) continue;
            a0[(0x7fffffffu * 5u) & 3u] = (((unsigned)(signed char)(unsigned)(0x8e8dd4cau || (unsigned)(signed char)(u2 & 0xd45e4c74u)) / (*q0 | 1u)) << (0x7fffffffu & 31u));
        }
    }
    goto L3;
    *mp = (unsigned)(((2u & 0x10000u) / (m0 | 1u)) && (unsigned)w0);
    if ((1u % ((unsigned)(garr[u2 & 7u] || (unsigned)(x0 >> 70)) | 1u))) goto L4;
    *q0 += (unsigned)(garr[u2 & 7u] < garr[u2 & 7u]);
    l0 = (long)((unsigned long)l0 + (unsigned)((short)((unsigned)(w0 >> 29) ^ (unsigned)(x0 >> 70)) > (signed char)((unsigned)b0 << ((0x7ef4d9fau / ((unsigned)h1 | 1u)) & 31u))));
    if (((i0 << (a0[u1 & 3u] & 31u)) * u3)) goto L0;
    c0 = (unsigned char)((unsigned)f0 / ((unsigned)h0 | 1u));
    if (0xcedec338u) goto done;
    e0 = e0 * 0.5L + (long double)(p2 & 1023u);
    *q0 += (unsigned)((unsigned)((short)(unsigned)h0 > (signed char)i0) < (0x10000u >> (u1 & 31u)));
    if (((unsigned)(w0 >> 29) % ((7u & 0x10000u) | 1u))) {
        *q0 = 6u;
        do { if (--fuel == 0u) goto done;
            if (*q0) break;
            c1 = (signed char)u0;
            if ((unsigned)(short)(i0 >> (((unsigned)(w0 >> 29) - 0x91a80b3du) & 31u))) break;
        } while (i0++ < 3u && (0xb8083aau << (0xdfe04498u & 31u)));
        while ((0x5e55951au | ((unsigned)(x0 >> 70) / (0x80000000u | 1u)))) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((g0 + (unsigned)(w0 >> 29))) continue;
                { unsigned t1; double z1; if ((~(4u << (0xd5cb5d03u & 31u))) & 1u) { t1 = ((unsigned)(x0 >> 70) >> (0x80000000u & 31u)); z1 = (double)(((unsigned)(signed char)(p2 % (0x6a84219bu | 1u))) & 255u); } if ((~(4u << (0xd5cb5d03u & 31u))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    break; (void)(g0);
                    do { if (--fuel == 0u) goto done;
                        if ((0x7fffffffu >> ((unsigned)x0 & 31u))) break;
                    } while (i2++ < 7u && (unsigned)((int)garr[i1 & 7u] >= (int)2u));
                    { unsigned t2; double z2; if (((r0.y - 0x80000000u)) & 1u) { t2 = (unsigned)((int)(unsigned)(g0 || i0) >= (int)a0[i0 & 3u]); z2 = (double)(((u3 + 0x8320ef17u)) & 255u); } if (((r0.y - 0x80000000u)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                        if (g0) goto L1;
                        if ((unsigned)((unsigned)(0xa3d711f8u && 0x40a4c6b9u) && (unsigned)b0)) break;
                        garr[(unsigned)x0 & 7u] = ((fuel << ((unsigned)d0 & 31u)) ^ ((a0[u1 & 3u] ^ 9u) ^ (unsigned)x0));
                        if (u1) goto L3;
                        l0 = (long)((unsigned long)l0 + ((unsigned)h1 << ((((unsigned)((int)(unsigned)e0 < (int)(unsigned)f0) << (a0[u1 & 3u] & 31u)) * (unsigned)f0) & 31u)));
                    }
                    e0 = e0 * 0.5L + (long double)((unsigned)(short)(0x43b9f766u * (g0 & 0xffffffffu)) & 1023u);
                    if ((garr[i1 & 7u] / (0xbf7984f4u | 1u))) break;
                    h1 = (unsigned short)(h1 + (unsigned)(((unsigned)((short)(unsigned)h0 > (signed char)3u) / (0x7fffffffu | 1u)) < (unsigned)e0));
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((unsigned)(short)(unsigned)(fuel < r0.y) < (0xffffffffu ^ 8u)) < 0x2059f906u);
                c0 = (unsigned char)(unsigned)((i0 / (((unsigned)(w0 >> 29) + (unsigned)((unsigned)c0 && garr[u2 & 7u])) | 1u)) == p1);
                break; (void)((unsigned)!(unsigned)((short)(unsigned)(short)(u0 | *mp) > (signed char)(unsigned)c0));
                u0 = u0 * 0x9e3779b1u + (unsigned)((0xffffffffu * 3u) || (g0 + 8u));
            } while (i1++ < 5u && (garr[i1 & 7u] | 0x70e41aa7u));
        }
        u0 ^= i2;
        l0 = (long)((unsigned long)l0 + ((unsigned)h1 % (0xeb3bdfdcu | 1u)));
    }
    if ((unsigned)((int)0x28d6c4a5u >= (int)(unsigned)h1)) {
        goto done;
        if (((unsigned)s1 << (a0[u1 & 3u] & 31u))) goto L1;
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)-(unsigned)((0x10000u ? 0xffffffffu : (u3 >> (g1 & 31u))) < (unsigned)h0);
        }
    }
    if ((unsigned)(a0[u1 & 3u] && *q0)) goto L0;
    if (~(r0.y & (unsigned)((unsigned)(x0 >> 70) < (unsigned)c0))) goto done;
    garr[-(0x54e0eeebu | (unsigned)(x0 >> 70)) & 7u] = (unsigned)(0x8596fc09u == (unsigned)((unsigned)h0 < (unsigned)((int)0x10000u >= (int)p1)));
    if ((unsigned)((unsigned)(fuel < p2) && 0x2bc0d5fcu)) goto L0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    v0 = ((unsigned)f0 + (-(0x2744b425u % (0x497a68e9u | 1u)) ^ (unsigned)l0));
    if ((a0[i0 & 3u] | 0xffffffffu)) goto L2;
    u2 = u2 * 0x9e3779b1u + 8u;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)s1 ^ 5u), u1, (unsigned)b0); }
    } while (i0++ < 2u && u3);
    if ((a0[i0 & 3u] % ((unsigned)(2u || (unsigned)c0) | 1u))) goto L0;
    g0 = 0xf0069915u;
    e0 = e0 * 0.5L + (long double)(0x80000000u & 1023u);
    if (p2) goto L0;
    { unsigned t0; double z0; if (((unsigned)((unsigned)(x0 >> 70) || (p0 + (unsigned)(x0 >> 70)))) & 1u) { t0 = (0x3e0e4989u >> (garr[u2 & 7u] & 31u)); z0 = (double)(((unsigned)((int)(unsigned)l0 < (int)p1)) & 255u); } if (((unsigned)((unsigned)(x0 >> 70) || (p0 + (unsigned)(x0 >> 70)))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        switch (u2 & 7u) {
            v0 = (unsigned)x0;
            while (i0++ < 6u && (0x7fffffffu - r0.x)) { if (--fuel == 0u) goto done;
                q0 = &garr[((unsigned)b0 + (0xb81578u + *mp)) & 7u];
                if ((0u << ((unsigned)c1 & 31u))) goto done;
            }
        }
        do { if (--fuel == 0u) goto done;
            r0.x = (unsigned)h0;
            u1 = u1 * 0x9e3779b1u + ((5u * (unsigned)((unsigned)l0 && (unsigned)(unsigned char)(unsigned)(g0 < i2))) / ((unsigned)b0 | 1u));
            while (r0.y) { if (--fuel == 0u) goto done;
                r0.x = (unsigned)(signed char)(unsigned)((int)g0 < (int)(unsigned)((int)(unsigned)((unsigned)d0 && (unsigned)x0) < (int)(garr[u2 & 7u] >> (0x37b43215u & 31u))));
                if ((0xe82e7b72u >> (~(0x3b1f3663u ^ fuel) & 31u))) continue;
            }
            break; (void)(r0.x);
            { unsigned t1; double z1; if ((7u) & 1u) { t1 = (unsigned)((short)(unsigned)(unsigned char)((unsigned)s0 + 0x2383857du) > (signed char)0xffffffffu); z1 = (double)((0u) & 255u); } if ((7u) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                w0 ^= (unsigned long long)(0x7fffffffu * (unsigned)c1) << ((unsigned)((unsigned)s0 && (unsigned)d0) & 63u);
                L0: if (--fuel == 0u) goto done;
                g1 += ((unsigned)(i0 < (unsigned)e0) | fuel);
                h1 = (unsigned short)(h1 + (unsigned)(short)((unsigned)(x0 >> 70) ^ (unsigned)(short)(~((unsigned)c1 - u3) >> (garr[u2 & 7u] & 31u))));
                if ((0xf0e4e1eeu | p2)) break;
                if (u3 == 7u) return (0x80000000u & (i0 / (a0[u1 & 3u] | 1u)));
            }
            *q0 = (unsigned)((int)(unsigned)(signed char)(u2 | u0) >= (int)((unsigned)b0 | fuel));
        } while (i0++ < 7u && (i1 >> (g0 & 31u)));
    }
    if (~(unsigned)((int)(unsigned)s0 >= (int)(unsigned)(i0 && g0))) {
        if (u3 == 7u) return (unsigned)((int)(u1 * (unsigned)(w0 >> 29)) >= (int)((unsigned)c1 * (unsigned)((int)(unsigned)e0 >= (int)(unsigned)s0)));
        i1 = ((unsigned)(w0 >> 29) + (*q0 | i0)) & 15u;
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            continue; (void)(0x10000u);
            u3 = 6u;
        }
        goto done;
        h1 = (unsigned short)(h1 + (unsigned)((unsigned)((int)0xb4beddfu >= (int)r0.x) == r0.x));
        if (((unsigned)b0 & 0x10000u)) goto L2;
    }
    b0 = (0x80000000u << ((unsigned)f0 & 31u)) != 0u;
    if ((0xafcf363fu - 0x80000000u)) goto L0;
    d0 = d0 * 0.5 + (double)(((5u * 0x2adb12beu) * ((unsigned)h1 << ((unsigned)(x0 >> 70) & 31u))) & 1023u);
    if ((0x7fffffffu << ((unsigned)(short)(u1 | p1) & 31u))) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((i2 - v0), (((unsigned)(w0 >> 29) | 0x7fffffffu) - g1), (unsigned)s0); }
        if ((unsigned)(i2 && (unsigned)(r0.x < 1u))) {
            l0 = (long)((unsigned long)l0 + *q0);
            c1 = (signed char)0x80000000u;
            m0 ^= (unsigned)(unsigned char)(unsigned)(((unsigned)c1 ^ (unsigned)s0) < (unsigned)(x0 >> 70));
        } else {
            L1: if (--fuel == 0u) goto done;
            if ((unsigned)(unsigned char)((unsigned)((int)(unsigned)x0 >= (int)0x10000u) >> (p2 & 31u))) {
                if ((v0 / ((p0 % (garr[u2 & 7u] | 1u)) | 1u))) goto L0;
                if (((unsigned)(x0 >> 70) + (unsigned)(garr[u2 & 7u] == (unsigned)b0))) goto L0;
                x0 = x0 * 0x100000001b3ull + (0x29e32967u % (u2 | 1u));
                f0 = f0 * 0.5f + (float)((unsigned)((short)0x7fffffffu > (signed char)(unsigned)((g1 / (7u | 1u)) < 0xffffffffu)) & 255u);
                w0 ^= (unsigned long long)(unsigned)l0 << (u2 & 63u);
            }
            while (i0++ < 6u && v0) { if (--fuel == 0u) goto done;
                if ((i0 ? (unsigned)c1 : 0x7fffffffu)) break;
                h1 = (unsigned short)(h1 + 0x80000000u);
                c1 = (signed char)(9u & (unsigned)(signed char)((unsigned)(u1 < *q0) - (unsigned)((short)(unsigned)w0 > (signed char)0x10000u)));
                c0 = (unsigned char)(unsigned)((int)0xffffffffu >= (int)(unsigned)(short)(0x782e9753u & (unsigned)d0));
                v0 = (((unsigned)((int)u1 < (int)(a0[u1 & 3u] * r0.x)) ^ 0xffffffffu) - (unsigned)f0);
            }
        }
        L2: if (--fuel == 0u) goto done;
    }
    u1 += ~(*mp & ((garr[u2 & 7u] & 0xed04f736u) ^ (unsigned)((int)0x10000u < (int)i1)));
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(8u && 0x80000000u), -((unsigned)s0 ^ (unsigned)((unsigned)w0 || v0)), 0u); }
    f0 = f0 * 0.5f + (float)(0xaf05c9f6u & 255u);
    garr[((unsigned)x0 / (0xf6ddf5b5u | 1u)) & 7u] = (u0 ? (0xe70db03au | 0u) : (unsigned)l0);
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[~(unsigned)(a0[u1 & 3u] && garr[i1 & 7u]) & 3u] = ((unsigned)(p1 && (unsigned)((unsigned)((int)0xbe965f09u < (int)i1) || r0.y)) | a0[u1 & 3u]);
        if (0xedeff2efu) break;
        r0.x = (unsigned)((unsigned)(unsigned char)(u0 * (7u ? (unsigned)f0 : 0x85f772c2u)) < garr[u2 & 7u]);
        if (u1) break;
        if (v0) break;
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0((g1 % (a0[i0 & 3u] | 1u)), (unsigned)((int)0xb8d18100u >= (int)0x33f97b70u), (unsigned)((short)(unsigned)b0 > (signed char)u3)); }
    }
    i2 = (0xef3ddeb8u ^ (0x501d94dcu * -(unsigned)((unsigned)c1 < 7u))) & 15u;
    b0 = ((*mp << (0xbd217b93u & 31u)) / ((unsigned)(u3 || (g0 ^ (unsigned)x0)) | 1u)) != 0u;
    if (budget != 0u) { budget -= 1u; u0 = fn0(p1, (u1 * (unsigned)(short)(m0 ^ 0x35b0ba22u)), (unsigned)((int)0x80000000u < (int)(0xfc645393u - p1))); }
    if ((unsigned)(i1 && (p1 ^ i1))) {
        c1 = (signed char)(unsigned)((short)(unsigned)c1 > (signed char)(*mp * 0xffffffffu));
        s0 = (int)(-(a0[u1 & 3u] / (2u | 1u)) + (5u * (unsigned)(x0 >> 70)));
        r0.y ^= (8u / (((unsigned)x0 & u1) | 1u));
    } else {
        if ((unsigned)s0) goto L1;
        switch (0xd964c46du & 7u) {
            w0 ^= (unsigned long long)p2 << ((unsigned)((short)i1 > (signed char)((0x7fffffffu % (0xcd54aa63u | 1u)) ^ (unsigned)h0)) & 63u);
            if (budget != 0u) { budget -= 1u; u2 = fn0((0xf99ee0f9u + 0x10000u), (unsigned)(u0 || p0), (u1 + u1)); }
        }
    }
    switch ((unsigned)b0 & 7u) {
        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)s1 ^ r0.x), (*mp % ((unsigned)b0 | 1u)), (unsigned)(0x13a27dc2u && m0)); }
        case 0u: ;
        if ((unsigned)((unsigned)c0 == (unsigned)w0)) {
            *q0 += i0;
            e0 = e0 * 0.5L + (long double)((unsigned)(0xed5506a4u || (unsigned)h1) & 1023u);
        } else {
            if (((v0 + 0xffffffffu) >> (m0 & 31u))) {
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(*mp && u3), p1, ((unsigned)(a0[i0 & 3u] || i0) & 9u)); }
                do { if (--fuel == 0u) goto done;
                    if (((unsigned)c0 * r0.y)) break;
                    h0 = (short)((unsigned)l0 & 0x5a23fb76u);
                } while (i0++ < 5u && ((0xffffffffu >> (4u & 31u)) / (i0 | 1u)));
                h1 = (unsigned short)(h1 + (unsigned)(((unsigned)h0 ? p1 : p2) || 0x10000u));
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)((unsigned)((int)-(0x7fffffffu / (0x10000u | 1u)) < (int)(unsigned)(x0 >> 70)) >> ((unsigned)(r0.y && garr[i1 & 7u]) & 31u));
                    default: ;
                    q0 = &garr[(r0.y ? (unsigned)l0 : (unsigned)s0) & 7u];
                    if (u0) continue;
                    if ((unsigned)((unsigned)c1 || u3)) break;
                    v0 = (g0 >> ((unsigned)h0 & 31u));
                }
                q0 = &garr[(unsigned)(x0 >> 70) & 7u];
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!(garr[i1 & 7u] * (unsigned)(u0 || p1)), (i1 * (unsigned)(x0 >> 70)), (unsigned)((unsigned)(w0 >> 29) == i0)); }
            } else {
                goto L4;
                while (i0++ < 6u && (u2 * p2)) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((r0.x >> ((unsigned)h0 & 31u)) && 0x80000000u), (4u | (unsigned)(0xf278b3e9u < (unsigned)h0)), (1u << (((unsigned)s0 % (p0 | 1u)) & 31u))); }
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        case 7u: ;
                        u3 += (unsigned)c0;
                        case 1u: ;
                        g0 = (((unsigned)(((unsigned)(x0 >> 70) << ((unsigned)f0 & 31u)) || 0x7fffffffu) + (unsigned)s0) << (a0[u1 & 3u] & 31u));
                    }
                    if ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)*q0)) goto L0;
                    s0 = (int)-(unsigned)(0x10000u || u3);
                    switch ((unsigned)s0 & 7u) {
                        continue; (void)((unsigned)s1);
                        u1 += ((unsigned)((int)r0.x < (int)r0.x) ? i1 : (unsigned)h0);
                        case 1u: ;
                    }
                    a0[(unsigned)(a0[u1 & 3u] || *mp) & 3u] = ((unsigned)f0 << (((u3 / (r0.x | 1u)) - 0x7fffffffu) & 31u));
                }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)c0, (unsigned)((int)(unsigned)d0 >= (int)(unsigned)(signed char)(i0 - 7u)), (5u + (0xffffffffu - a0[i0 & 3u]))); }
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0((g0 % (i2 | 1u)), (unsigned)(fuel || 6u), (a0[u1 & 3u] * v0)); }
    }
    q0 = &garr[(unsigned)(signed char)(g0 + (unsigned)b0) & 7u];
    goto L0;
    if ((0x27ff6cd5u + (unsigned)((int)garr[i1 & 7u] < (int)i0))) goto L1;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)h0 ? u3 : 7u));
    }
    i1 = ((unsigned)s1 ? ((unsigned)((short)v0 > (signed char)(unsigned)f0) | (unsigned)e0) : fuel) & 15u;
    c1 = (signed char)((unsigned)(4u || (unsigned)s0) ^ fuel);
    if (0xdeff99dcu) {
        L3: if (--fuel == 0u) goto done;
        garr[(unsigned)((unsigned)b0 < 3u) & 7u] = (5u + (unsigned)((int)(unsigned)(0xf53b7d8au < 0xdaf807fu) < (int)(unsigned)s1));
        u3 ^= 0x10000u;
        if (budget != 0u) { budget -= 1u; u1 = fn0((p0 - (unsigned)h0), (unsigned)((int)garr[i1 & 7u] >= (int)((unsigned)e0 * 0x99b6d99bu)), r0.y); }
        s1 = (int)((unsigned)s1 + ~(p0 / ((unsigned)b0 | 1u)));
        if (((unsigned)s1 | (m0 / ((unsigned)h0 | 1u)))) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((p0 ^ ((unsigned)d0 << (garr[u2 & 7u] & 31u))), (4u >> (g1 & 31u)), (unsigned)(a0[u1 & 3u] || (unsigned)(x0 >> 70))); }
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                u1 += p0;
                u3 = (unsigned)(0x80000000u && (unsigned)h0);
                if (budget != 0u) { budget -= 1u; u3 = fn0(-(unsigned)((0x701e05b8u * (unsigned)x0) || r0.y), ((unsigned)h1 | (r0.x - 0x68375f87u)), (unsigned)s1); }
                *mp = ((u0 << (0x5b1f6871u & 31u)) & ((unsigned)(w0 >> 29) >> (4u & 31u)));
            }
            l0 = (long)((unsigned long)l0 + ((5u ? p2 : (unsigned)(w0 >> 29)) + 4u));
            if (0x10000u) {
                if (budget != 0u) { budget -= 1u; u3 = fn0(garr[i1 & 7u], ((g0 + g0) | (unsigned)f0), m0); }
            }
        } else {
            L4: if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)(i1 == u1) < (int)3u) & 1023u);
            w0 = w0 * 6364136223846793005ull + g1;
        }
    } else {
        while (i0++ < 5u && a0[u1 & 3u]) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)((~(0x80000000u % ((0x889adf2cu / (0xdb36bc84u | 1u)) | 1u)) % (g1 | 1u)) < (unsigned)h0);
            x0 = x0 * 0x100000001b3ull + ((*q0 % (0x7fffffffu | 1u)) & (g1 ^ 0x454cf6c5u));
            g1 += v0;
            { unsigned t2; double z2; if (((unsigned)(signed char)((unsigned)((unsigned)d0 && (unsigned)f0) >> (v0 & 31u))) & 1u) { t2 = (unsigned)(*mp == (unsigned)(unsigned char)(unsigned)((short)6u > (signed char)0u)); z2 = (double)((((unsigned)d0 & g0)) & 255u); } if (((unsigned)(signed char)((unsigned)((unsigned)d0 && (unsigned)f0) >> (v0 & 31u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                if (((unsigned)(x0 >> 70) / ((m0 - 0u) | 1u))) break;
                if ((unsigned)(u0 || (unsigned)!((unsigned)h1 - garr[u2 & 7u]))) break;
                v0 = (unsigned)((0xe652620au * p0) < ((unsigned)((unsigned)f0 && 2u) & 7u));
                l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)((int)(unsigned)e0 < (int)p2) >= (int)(unsigned)(i2 && (unsigned)s1)));
                *q0 += (unsigned)((p1 << ((p2 << ((unsigned)((int)p2 < (int)(unsigned)e0) & 31u)) & 31u)) || 0x7fffffffu);
                continue; (void)((unsigned)(signed char)(((unsigned)(x0 >> 70) >> (g1 & 31u)) & a0[u1 & 3u]));
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(g1, (unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)d0), ((unsigned)b0 + 0x80000000u)); }
        }
        goto L0;
        x0 = x0 * 0x100000001b3ull + ~(unsigned)((int)(unsigned)((short)(unsigned)s0 > (signed char)r0.y) < (int)5u);
        r0.x = (unsigned)(((9u ^ (unsigned)h0) / ((unsigned)x0 | 1u)) < (u0 >> ((unsigned)h1 & 31u)));
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)b0 / ((unsigned)(unsigned char)(0x10000u >> (0xcbf410eau & 31u)) | 1u)), (unsigned)(8u || (0x10000u >> (0xea683852u & 31u))), ((g1 % (i1 | 1u)) >> (a0[u1 & 3u] & 31u))); }
    *mp = 8u;
    w0 ^= (unsigned long long)0x10000u << ((unsigned)((int)(i0 | (unsigned)(x0 >> 70)) < (int)u3) & 63u);
    h1 = (unsigned short)(h1 + -((unsigned)(0x5171be0au < u0) * r0.y));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        *q0 = ((r0.x ^ (r0.y * u3)) ^ (unsigned)(m0 == u2));
    } while (i0++ < 6u && (unsigned)((unsigned)h1 == r0.x));
    if ((unsigned)((unsigned)c1 || (u0 / (u3 | 1u)))) goto L4;
    garr[(unsigned)((int)*mp < (int)9u) & 7u] = (unsigned)((unsigned)((g0 >> ((unsigned)(x0 >> 70) & 31u)) < (unsigned)((short)9u > (signed char)(unsigned)x0)) < garr[u2 & 7u]);
    if (i1) goto L0;
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)(0xdb1b7953u - 0x10000u) >= (int)garr[u2 & 7u]), (unsigned)((unsigned)((short)(unsigned)e0 > (signed char)0x6f99acb6u) < 0xf963fb66u), i1); }
    for (;;) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((unsigned)((int)u2 >= (int)r0.x) == (unsigned)e0));
        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)l0 + (unsigned)e0), (unsigned)((int)(unsigned)(short)(unsigned)((int)0x94d32481u < (int)(unsigned)c1) >= (int)fuel), u0); }
        if ((i0 & 0x72074003u)) break;
        g1 += (m0 ^ (0x7fffffffu % (u3 | 1u)));
        if ((unsigned)((unsigned)h0 < p2)) goto L3;
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)(garr[u2 & 7u] || 0xc7b5a698u);
        switch ((unsigned)((m0 >> (m0 & 31u)) == i0) & 7u) {
            *mp = (unsigned)!(unsigned)((short)(unsigned)((int)r0.x >= (int)((unsigned)h1 >> (a0[i0 & 3u] & 31u))) > (signed char)(unsigned)b0);
            if ((unsigned)((unsigned)w0 == (unsigned)((int)3u < (int)u0))) continue;
        }
        while (i1++ < 3u && (0x53b591feu ^ (unsigned)x0)) { if (--fuel == 0u) goto done;
            *q0 = ((0x51ddb0feu % (0xba831f8fu | 1u)) >> ((~((unsigned)c0 % (m0 | 1u)) / (p0 | 1u)) & 31u));
            do { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (7u % ((unsigned)((r0.x ? 8u : 1u) == garr[u2 & 7u]) | 1u));
                { unsigned t0; double z0; if ((((unsigned)f0 / ((unsigned)(w0 >> 29) | 1u))) & 1u) { t0 = (p1 | 0x10000u); z0 = (double)(((u0 * 0x6a8357feu)) & 255u); } if ((((unsigned)f0 / ((unsigned)(w0 >> 29) | 1u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                    w0 ^= (unsigned long long)(unsigned)((int)*q0 < (int)u1) << ((((unsigned)s1 / (u0 | 1u)) - (unsigned)e0) & 63u);
                    L0: if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (g1 * p2));
                    if (budget != 0u) { budget -= 1u; u2 = fn0(u1, 0xffffffffu, g1); }
                    while (i0++ < 5u && (u0 ^ 3u)) { if (--fuel == 0u) goto done;
                        if (((unsigned)s1 % (4u | 1u))) {
                            x0 = x0 * 0x100000001b3ull + (unsigned)((int)0xffffffffu < (int)(unsigned)s1);
                            if (0x2017906bu) break;
                            s1 = (int)((unsigned)s1 + (r0.y & (unsigned)((int)a0[i0 & 3u] < (int)garr[u2 & 7u])));
                            *q0 += (unsigned)((int)((unsigned)((unsigned)s1 || p0) * (p2 ^ 0x10000u)) < (int)i2);
                            a0[(unsigned)d0 & 3u] = (v0 >> (garr[u2 & 7u] & 31u));
                            if ((unsigned)!(0x10000u ^ (unsigned)(x0 >> 70))) break;
                        }
                        e0 = e0 * 0.5L + (long double)((unsigned)(r0.x < (unsigned)h0) & 1023u);
                        v0 = (unsigned)((short)u2 > (signed char)i0);
                        do { if (--fuel == 0u) goto done;
                            g0 = (unsigned)((unsigned)(short)(unsigned)((int)m0 < (int)(u1 & 0x10000u)) < ((unsigned)(w0 >> 29) & 0x10000u));
                        } while (i1++ < 7u && 0x7fffffffu);
                        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u2 = fn1((u1 << ((unsigned)w0 & 31u)), (unsigned)c1, u1); }
                            r0.x = 0x7fffffffu;
                            break; (void)((4u * ((unsigned)x0 | p0)));
                            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)w0 | (unsigned)s0), m0, p1); }
                        }
                        u1 = u1 * 0x9e3779b1u + (unsigned)(signed char)(unsigned)((int)(unsigned)e0 >= (int)garr[u2 & 7u]);
                    }
                    if ((0x23cf84c6u / ((unsigned)d0 | 1u))) goto L1;
                }
                w0 = w0 * 6364136223846793005ull + ((unsigned)((int)(unsigned)s1 >= (int)(0xb2ce70b7u | 0xf19775cu)) + (unsigned)h0);
            } while (i2++ < 7u && (unsigned)l0);
            x0 = x0 * 0x100000001b3ull + (u3 ? u0 : i0);
            if ((unsigned)(v0 && (unsigned)h0)) {
                w0 = w0 * 6364136223846793005ull + (((unsigned)e0 | ((unsigned)b0 % ((unsigned)h1 | 1u))) % ((unsigned)x0 | 1u));
                if ((v0 / (*q0 | 1u))) {
                    L1: if (--fuel == 0u) goto done;
                    while (i2++ < 3u && (unsigned)((int)u1 >= (int)((unsigned)x0 / (i2 | 1u)))) { if (--fuel == 0u) goto done;
                        if (((unsigned)(short)((unsigned)h1 ^ i2) % (g0 | 1u))) break;
                        c0 = (unsigned char)4u;
                        if (i2) {
                            break; (void)(0xffffffffu);
                            h1 = (unsigned short)(h1 + ((unsigned)((unsigned)e0 < (0x10000u - u2)) % (0x4663304fu | 1u)));
                            *q0 = (unsigned)(((unsigned)d0 ? (unsigned)l0 : 0x10000u) < r0.y);
                            h0 = (short)(unsigned)(short)(0xbe95ae71u * ((0x10000u - (unsigned)c1) | (u0 / (0x80000000u | 1u))));
                            if (budget != 0u) { budget -= 1u; u0 = fn0(~((unsigned)f0 * 0x5aed43d8u), ((unsigned)(signed char)(0x10000u / (p1 | 1u)) | *mp), (p0 | (unsigned)s0)); }
                            L2: if (--fuel == 0u) goto done;
                        } else {
                            s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)w0 < (int)(unsigned)((unsigned)c0 && u3)));
                            q0 = &garr[i2 & 7u];
                        }
                    }
                    *q0 = (unsigned)((int)-(unsigned)((unsigned)(2u < u3) || p1) >= (int)(i2 >> (p2 & 31u)));
                }
                if (((unsigned)h0 * (unsigned)c0)) {
                    f0 = f0 * 0.5f + (float)((unsigned)((short)m0 > (signed char)(unsigned)(r0.x == (unsigned)(signed char)(unsigned)((int)3u >= (int)(unsigned)(*mp < 0x7fffffffu)))) & 255u);
                } else {
                    if ((garr[i1 & 7u] << (0x80000000u & 31u))) break;
                    L3: if (--fuel == 0u) goto done;
                    goto L1;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)0x80000000u < (int)(unsigned)!(unsigned)((unsigned)c0 == 3u)), 0x7fffffffu, (unsigned)((unsigned)c1 == (i0 | (unsigned)(w0 >> 29)))); }
                }
                h0 = (short)(unsigned)((int)*mp < (int)(unsigned)((int)(unsigned)(r0.x == i0) < (int)(8u % (5u | 1u))));
            } else {
                u2 = u2 * 0x9e3779b1u + (unsigned)(0xffffffffu && 0x80000000u);
                if (g0) break;
                u0 ^= (r0.y - fuel);
            }
            q0 = &garr[(unsigned)((u1 | g1) == (unsigned)c0) & 7u];
        }
        if (fuel < 8u) return ((unsigned)c0 * (a0[u1 & 3u] | (unsigned)((unsigned)((int)8u < (int)4u) && g0)));
        v0 = (unsigned)!(u2 & ((unsigned)c0 % ((unsigned)w0 | 1u)));
    }
    if ((r0.y >> ((p0 | u3) & 31u))) goto L3;
    v0 = i0;
    L4: if (--fuel == 0u) goto done;
    switch ((0x86531147u | (unsigned)b0) & 7u) {
        if (7u) goto L4;
        l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)(w0 >> 29) * 0x54faaa50u) == (unsigned)((unsigned)(short)((unsigned)h0 % ((unsigned)(x0 >> 70) | 1u)) < (unsigned)x0)));
        g0 = (unsigned)w0;
    }
    while (i0++ < 7u && a0[u1 & 3u]) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)r0.y >= (int)6u)) {
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + ((u2 | (unsigned)d0) / ((2u / (v0 | 1u)) | 1u));
                d0 = d0 * 0.5 + (double)((0x49fd3a41u >> ((unsigned)((int)(unsigned)((unsigned)l0 == m0) < (int)0x2087248fu) & 31u)) & 1023u);
                if ((unsigned)((int)((unsigned)d0 % (i1 | 1u)) < (int)5u)) {
                    if (i2) break;
                    s0 = (int)-(r0.y * 0x8adffc6du);
                    if ((0x7fffffffu >> (i0 & 31u))) break;
                    w0 ^= (unsigned long long)(u0 | (unsigned)h1) << ((unsigned)((int)*mp < (int)(0xbd835f88u >> (fuel & 31u))) & 63u);
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(unsigned char)(i1 ^ 1u), ((garr[u2 & 7u] >> (*mp & 31u)) >> (8u & 31u)), (unsigned)w0); }
                if ((p1 >> ((unsigned)((unsigned)b0 || 0x10000u) & 31u))) goto L4;
            }
            if ((unsigned)!(unsigned)((short)u1 > (signed char)garr[u2 & 7u])) continue;
            c0 = (unsigned char)(unsigned)(a0[u1 & 3u] && (unsigned)h1);
            r0.x = (unsigned)(unsigned char)((((r0.y >> (0x80000000u & 31u)) % (u0 | 1u)) >> (i1 & 31u)) + p1);
            b0 = (v0 + p0) != 0u;
            if (budget != 0u) { budget -= 1u; u3 = fn0(-(unsigned)((short)i0 > (signed char)m0), (unsigned)h0, (i2 ^ 2u)); }
        } else {
            if (u3 == 7u) return (3u / (~((unsigned)((unsigned)(x0 >> 70) < 0x7fffffffu) + (unsigned)(garr[u2 & 7u] || (unsigned)h0)) | 1u));
            { unsigned t1; double z1; if (((a0[i0 & 3u] ^ (unsigned)!(0x7fffffffu & (unsigned)e0))) & 1u) { t1 = (1u << (*mp & 31u)); z1 = (double)((((unsigned)s0 * ~(0xf9ccde81u >> (p2 & 31u)))) & 255u); } if (((a0[i0 & 3u] ^ (unsigned)!(0x7fffffffu & (unsigned)e0))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                a0[i0 & 3u] = ((unsigned)(g1 && (unsigned)(*mp < (unsigned)(x0 >> 70))) | (unsigned)(x0 >> 70));
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1(1u, (unsigned)((int)(unsigned)(8u || garr[u2 & 7u]) >= (int)(unsigned)c1), u3); }
                    if (((unsigned)(signed char)(v0 ^ 0x80000000u) | (unsigned)b0)) continue;
                    e0 = e0 * 0.5L + (long double)(*q0 & 1023u);
                }
                v0 = (0x7fffffffu | 0x80000000u);
            }
            if (u3) break;
        }
        w0 ^= (unsigned long long)0x7fffffffu << (((unsigned)b0 | (i1 | p1)) & 63u);
        q0 = &garr[(unsigned)d0 & 7u];
        w0 = w0 * 6364136223846793005ull + (unsigned)((fuel * 0x3ce3b7d4u) == ((unsigned)s0 - (unsigned)(short)(unsigned)(0xfdcbd3e7u || u2)));
        do { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((int)(a0[i0 & 3u] + (unsigned)s1) >= (int)0xe7c0c53u));
            l0 = (long)((unsigned long)l0 + 0x8a28cacu);
            if ((unsigned)(g1 || (unsigned)(a0[i0 & 3u] && 0x9aacc567u))) break;
            if (budget != 0u) { budget -= 1u; u0 = fn0(~(~((unsigned)h1 & r0.y) + u3), (unsigned)((unsigned)e0 < (0x7fffffffu / (8u | 1u))), (unsigned)(p1 && ((unsigned)h0 * 3u))); }
            if (r0.x) {
                if (9u) {
                    do { if (--fuel == 0u) goto done;
                        if (v0) {
                            v0 = (unsigned)f0;
                            h1 = (unsigned short)(h1 + (unsigned)((garr[u2 & 7u] >> (a0[u1 & 3u] & 31u)) < (unsigned)((int)(unsigned)s0 < (int)9u)));
                            if ((unsigned)((int)(unsigned)(w0 >> 29) < (int)(r0.y * (unsigned)(w0 >> 29)))) continue;
                        } else {
                            break; (void)((unsigned)s0);
                            break; (void)(((unsigned)f0 - (3u | p2)));
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)a0[i0 & 3u] >= (int)-(unsigned)((unsigned)(x0 >> 70) < 0xf20004a4u)), (unsigned)(i0 == (p1 | 0x87758d4fu)), (unsigned)(i2 < i2)); }
                    } while (i2++ < 7u && p2);
                    r0.x = (unsigned)(signed char)(-(r0.x - u1) % ((unsigned)(u2 < (unsigned)((int)(unsigned)b0 < (int)v0)) | 1u));
                    break; (void)(0xe6880211u);
                    m0 ^= (unsigned)((unsigned)(w0 >> 29) == (((unsigned)((unsigned)d0 || (unsigned)c1) + (unsigned)f0) / ((unsigned)e0 | 1u)));
                }
                if ((unsigned)c0) goto L0;
            }
        } while (i1++ < 2u && (unsigned)((short)garr[i1 & 7u] > (signed char)((unsigned)s0 - (unsigned)h0)));
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1(0xe2eafd4au, 5u, (g0 % (r0.y | 1u))); }
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)h0 ? *mp : (unsigned)w0), (((unsigned)w0 * g1) % (m0 | 1u)), (9u << (i0 & 31u))); }
        } while (i1++ < 4u && (i0 ^ 0x80000000u));
    }
    d0 = d0 * 0.5 + (double)((unsigned)w0 & 1023u);
    goto L3;
    h1 = (unsigned short)(h1 + (unsigned)x0);
    if (i0) goto done;
    if ((unsigned)(w0 >> 29)) goto L2;
    if (fuel < 8u) return (i1 * (-((unsigned)!(garr[u2 & 7u] << (0x8d6f7f6au & 31u)) + 0xb7f7251au) | i1));
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)(((0xa54335dcu ^ (unsigned)((short)4u > (signed char)(unsigned)c1)) * fuel) & 1023u);
        *mp = (unsigned)(((i2 % (g1 | 1u)) << (5u & 31u)) || (unsigned)l0);
        if ((u2 & (unsigned)x0)) {
            if ((unsigned)((short)i0 > (signed char)(0x24e28702u | (unsigned)w0))) {
                if (((unsigned)s0 >> (u3 & 31u))) {
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        c1 = (signed char)(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(unsigned char)(i1 - ~(unsigned)((short)4u > (signed char)garr[u2 & 7u])));
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0xffffffffu && (unsigned)(v0 < (unsigned)f0)), (unsigned)((int)(i0 << (8u & 31u)) < (int)0x10000u), g0); }
                        *mp = (unsigned)(0x417b5879u || u3);
                    }
                    a0[(u0 | u1) & 3u] = ((unsigned)((int)(unsigned)h0 >= (int)0x80000000u) & (0x80000000u / ((unsigned)c0 | 1u)));
                    if ((unsigned)((a0[i0 & 3u] ^ 0x80000000u) < (unsigned)s0)) break;
                } else {
                    while (i1++ < 5u && (0x5c0e565cu | (i1 % (0x7fffffffu | 1u)))) { if (--fuel == 0u) goto done;
                        break; (void)((0x6e4e3287u * a0[i0 & 3u]));
                        g0 = (unsigned)((unsigned)f0 == u1);
                        while (0x2c608b14u) { if (--fuel == 0u) goto done;
                            break; (void)((((unsigned)h0 << (0x7fffffffu & 31u)) / (0xffffffffu | 1u)));
                            if (((unsigned)((short)i1 > (signed char)u0) % ((unsigned)f0 | 1u))) break;
                        }
                    }
                    if ((unsigned)(u2 || (g0 & 2u))) break;
                    goto L2;
                    if ((unsigned)(x0 >> 70)) {
                        if ((unsigned)h0) break;
                        if ((unsigned)f0) goto L0;
                    } else {
                        u2 += (unsigned)((unsigned)b0 || (unsigned)c0);
                    }
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(unsigned)((unsigned)h1 && (unsigned)(garr[i1 & 7u] == 0u));
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)(((unsigned)(w0 >> 29) - (unsigned)s0));
                }
                if (~(v0 % (8u | 1u))) goto L0;
            } else {
                if (fuel) break;
                q0 = &garr[(unsigned)(0x7113a0f0u || ((unsigned)(a0[i0 & 3u] < ((unsigned)c1 % ((unsigned)w0 | 1u))) ^ (unsigned)l0)) & 7u];
                *mp = (*mp ^ (unsigned)h0);
            }
            u3 ^= ((unsigned)(0x1fc0196u < (unsigned)(r0.x && ((unsigned)h0 * u3))) + 0x52f5fabeu);
            if (budget != 0u) { budget -= 1u; u1 = fn1((i1 / ((unsigned)((int)i0 < (int)(unsigned)d0) | 1u)), ((unsigned)e0 - 0x10000u), (unsigned)(unsigned char)((unsigned)b0 | (unsigned)(garr[i1 & 7u] && (unsigned)x0))); }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (r0.y - -(unsigned)((int)(unsigned)x0 >= (int)0x80000000u));
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    while ((0xb5cbbd46u >> ((unsigned)(x0 >> 70) & 31u))) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((int)m0 < (int)*mp));
                        if ((unsigned)((int)i1 >= (int)(unsigned)x0)) continue;
                        u2 = (garr[i1 & 7u] ? garr[i1 & 7u] : p1);
                    }
                    h1 = (unsigned short)(h1 + (unsigned)((int)(2u >> (r0.x & 31u)) >= (int)i2));
                    w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)(signed char)(garr[i1 & 7u] + (u0 & 0x80000000u)) > (signed char)(unsigned)!(unsigned)((int)0xbc73e727u < (int)p0));
                }
                w0 ^= (unsigned long long)*q0 << ((unsigned)((short)0x3ab801e5u > (signed char)(u1 << ((unsigned)!(unsigned)(u3 < (unsigned)h0) & 31u))) & 63u);
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    g1 += (unsigned)(0u && (unsigned)w0);
                    if ((unsigned)((9u | v0) && 6u)) break;
                    if (0x72868656u) goto L2;
                    if ((unsigned)f0) break;
                }
                w0 ^= (unsigned long long)0x7fffffffu << ((unsigned)w0 & 63u);
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)c0 / (p2 | 1u)), (unsigned)c1, ((unsigned)b0 * 0x7fffffffu)); }
        }
        if ((unsigned)((int)~(unsigned)((int)(unsigned)c0 >= (int)garr[u2 & 7u]) < (int)u1)) continue;
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)x0 << ((unsigned)d0 & 31u)), (p2 * 0xcead8033u), ((unsigned)b0 % (0x80000000u | 1u))); }
    }
    if (((unsigned)(w0 >> 29) % (g0 | 1u))) goto done;
    r0.y ^= ((unsigned)((unsigned)h0 == i1) % (u2 | 1u));
    u2 ^= (unsigned)((0x80000000u + (unsigned)s0) && 0x80000000u);
    *q0 = (p0 ^ ~(u1 - 0xba33b1a5u));
    f0 = f0 * 0.5f + (float)((unsigned)((int)0x48eb03dbu < (int)(unsigned)!(unsigned)((unsigned)((int)v0 < (int)(unsigned)b0) == u0)) & 255u);
    w0 ^= (unsigned long long)0x80000000u << ((unsigned)((unsigned)w0 == 0xffffffffu) & 63u);
    if ((unsigned)((unsigned)e0 < (unsigned)((int)u0 >= (int)u0))) goto done;
    if (((unsigned)(0x8a9a9ef8u && 0x7fffffffu) & 5u)) {
        { unsigned t2; double z2; if ((((unsigned)f0 ^ (unsigned)(r0.y < 0x10000u))) & 1u) { t2 = -(unsigned)((unsigned)s0 || i0); z2 = (double)((((unsigned)b0 + ((unsigned)w0 - i2))) & 255u); } if ((((unsigned)f0 ^ (unsigned)(r0.y < 0x10000u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            if (i2) {
                c1 = (signed char)((unsigned)((unsigned)(0xffffffffu == r0.y) && (unsigned)c1) / ((6u * i2) | 1u));
            } else {
                if (((unsigned)((int)(unsigned)h1 < (int)r0.x) ^ (unsigned)b0)) goto L3;
                h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)w0 < (int)(((unsigned)f0 + 0x273a90d2u) + u3)));
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(signed char)(g1 << ((u3 - 0xd69a16b8u) & 31u)), 6u, (((unsigned)h0 | u2) - fuel)); }
            }
            goto L4;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!(unsigned)((int)0x778fdau >= (int)u0), (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)f0), (0xb3d0d30fu - 7u)); }
        }
        for (;;) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)s0 || (0x31a2b1ebu - u2))) break;
            } while (i1++ < 3u && ((unsigned)((int)(unsigned)c0 < (int)u1) ^ fuel));
        }
        a0[(m0 | garr[u2 & 7u]) & 3u] = ((garr[u2 & 7u] >> ((unsigned)e0 & 31u)) - ((unsigned)(i1 && (unsigned)x0) + r0.y));
        { unsigned t3; double z3; if (((unsigned)((int)(u2 << ((unsigned)c1 & 31u)) >= (int)p1)) & 1u) { t3 = (u0 - (unsigned)((int)(unsigned)e0 >= (int)m0)); z3 = (double)((u2) & 255u); } if (((unsigned)((int)(u2 << ((unsigned)c1 & 31u)) >= (int)p1)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            m0 ^= (unsigned)((unsigned)d0 == ((unsigned)!((unsigned)e0 >> ((0x80000000u | *q0) & 31u)) >> (*mp & 31u)));
            switch ((unsigned)(short)(unsigned)(g0 < (unsigned)w0) & 7u) {
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(unsigned char)((0x311094e0u ^ 7u) << (i0 & 31u)), p0, (unsigned)s1); }
                l0 = (long)((unsigned long)l0 + (unsigned)((short)0xfd06ff4bu > (signed char)(unsigned)(0x6591f9c0u || (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)((short)(unsigned)h1 > (signed char)(unsigned)(w0 >> 29))))));
                if ((0x166b980fu % (u3 | 1u))) goto L1;
            }
            w0 ^= (unsigned long long)((unsigned)e0 * (unsigned)h0) << ((0x80000000u >> ((unsigned)d0 & 31u)) & 63u);
        }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(0x15628f84u && r0.x)) {
                if ((1u / ((unsigned)(x0 >> 70) | 1u))) break;
                if ((unsigned)(short)(0xa0088799u >> ((unsigned)((int)m0 < (int)g1) & 31u))) break;
                if ((unsigned)((int)(unsigned)s1 >= (int)(unsigned)s0)) break;
                w0 ^= (unsigned long long)(unsigned)s1 << ((*mp >> (u2 & 31u)) & 63u);
                w0 ^= (unsigned long long)1u << (((unsigned)x0 | (unsigned)(r0.y == u0)) & 63u);
                c0 = (unsigned char)(unsigned)((int)-((unsigned)s1 ? 8u : p2) < (int)u1);
            }
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch ((unsigned)w0 & 7u) {
                    g1 += ~(0u * (unsigned)((unsigned)f0 == 0xffffffffu));
                    q0 = &garr[(a0[i0 & 3u] % ((unsigned)!(unsigned)((short)0x7a652549u > (signed char)g1) | 1u)) & 7u];
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1((r0.y ? r0.y : 0xf03f062bu), ((unsigned)l0 ? 0x6a5e6822u : 0xdac55cd6u), *q0); }
            }
        } while (i0++ < 4u && (unsigned)(((unsigned)c1 << (1u & 31u)) && p2));
    }
    goto done;
    q0 = &garr[fuel & 7u];
    if ((unsigned)((int)0x95cf72aau < (int)(unsigned)(x0 >> 70))) {
        if (a0[u1 & 3u]) {
            if (0x10000u) goto L3;
            if (i1) goto L0;
            goto L3;
            w0 ^= (unsigned long long)0x80000000u << ((unsigned)x0 & 63u);
            if (0xffffffffu) goto L0;
            h0 = (short)((unsigned)h1 % (r0.x | 1u));
        }
        goto L4;
    } else {
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)h1 < (unsigned)(unsigned char)(unsigned)(garr[i1 & 7u] == p2)), 0xf218d81fu, g1); }
        r0.x = (unsigned)((int)0x10000u >= (int)(unsigned)((int)m0 < (int)fuel));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (((unsigned)d0 >> (g0 & 31u))) {
        u2 = u2 * 0x9e3779b1u + ((unsigned)h1 * u1);
    }
    if (u3 == 7u) return ((unsigned)s1 ? ((unsigned)l0 ^ (unsigned)c1) : *mp);
    while (i0++ < 3u && i2) { if (--fuel == 0u) goto done;
        goto L1;
        if (budget != 0u) { budget -= 1u; u3 = fn0((0x7fffffffu + 0xc6cc1cf4u), (0x8347b9d1u >> (u2 & 31u)), (0x80000000u / ((unsigned)(0x10834d4au == fuel) | 1u))); }
    }
    switch ((0xa3db4a3u + (unsigned)s0) & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) || ~(u0 - a0[i0 & 3u])), -(unsigned)((int)((unsigned)w0 ^ (unsigned)h1) >= (int)0xb97673e5u), (p0 - p1)); }
        case 3u: ;
        if ((unsigned)((int)(unsigned)((int)garr[i1 & 7u] >= (int)fuel) >= (int)(unsigned)s1)) break;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)d0 >= (int)(unsigned)(signed char)(unsigned)((unsigned)h0 < 0xb83f1078u)), (unsigned)c1, (unsigned)(short)(0xffffffffu << (6u & 31u))); }
    }
    r0.x = (u0 * (unsigned)c0);
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)(a0[i0 & 3u] == (p0 % (0x87b32cbbu | 1u)))) continue;
        q0 = &garr[(unsigned)(unsigned char)(p0 / (garr[u2 & 7u] | 1u)) & 7u];
        s1 = (int)((unsigned)s1 + ((unsigned)e0 & (unsigned)(p2 == -(((unsigned)f0 ^ (unsigned)c0) - m0))));
        L0: if (--fuel == 0u) goto done;
        c0 = (unsigned char)(unsigned)((unsigned)!(((unsigned)h1 + (unsigned)(w0 >> 29)) / (0x7fffffffu | 1u)) == (unsigned)((int)(unsigned)s1 < (int)0xf0d9d598u));
    }
    if (u3) {
        if (budget != 0u) { budget -= 1u; u0 = fn1(0x3afbe461u, (fuel >> ((unsigned)((int)4u < (int)(unsigned)w0) & 31u)), ((i1 % (0x10000u | 1u)) / (r0.x | 1u))); }
        f0 = f0 * 0.5f + (float)((unsigned)((int)0xa4cce90fu >= (int)(unsigned)(short)(unsigned)(0x9ae1239bu == *q0)) & 255u);
    } else {
        if ((unsigned)((short)p2 > (signed char)0x10000u)) goto L1;
        do { if (--fuel == 0u) goto done;
            u2 ^= (unsigned)((short)g1 > (signed char)p0);
            b0 = ((unsigned)f0 & ((unsigned)(short)(unsigned)(6u && 0u) ^ (unsigned)h1)) != 0u;
            r0.x = (*mp / (4u | 1u));
            while (((unsigned)(0x10000u == 0xffffffffu) + 0x80000000u)) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (((u3 ? p0 : *mp) * (unsigned)s1) << (0xffffffffu & 31u));
                l0 = (long)((unsigned long)l0 + (unsigned)(u3 < (*q0 & (unsigned)c0)));
                while (i2++ < 2u && 2u) { if (--fuel == 0u) goto done;
                    if ((5u / ((unsigned)(short)(0x7fffffffu / ((unsigned)l0 | 1u)) | 1u))) {
                        if ((1u - g1)) break;
                        if ((unsigned)f0) break;
                        u1 ^= (unsigned)(i0 && ((unsigned)h1 - *q0));
                    } else {
                        if (~(unsigned)(7u == u3)) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(p2, r0.x, 0xfe42f57u); }
                        u2 = (unsigned)(((unsigned)(short)(unsigned)(r0.x || 0xffffffffu) >> (p0 & 31u)) == u2);
                        L1: if (--fuel == 0u) goto done;
                    }
                    u0 = (unsigned)((int)0x80000000u < (int)(unsigned)(unsigned char)(unsigned)((int)u1 >= (int)(unsigned)((short)0xffffffffu > (signed char)(unsigned)h0)));
                }
            }
            if ((((unsigned)h1 & (unsigned)c1) - (unsigned)(w0 >> 29))) {
                e0 = e0 * 0.5L + (long double)((unsigned)((int)0x10000u >= (int)p1) & 1023u);
                garr[((unsigned)e0 + (unsigned)f0) & 7u] = r0.x;
            } else {
                continue; (void)(~((unsigned)((short)r0.x > (signed char)(unsigned)h0) & 1u));
            }
        } while (i0++ < 5u && -(0x81423f44u - (unsigned)(0x75b9fc8bu == *q0)));
        L2: if (--fuel == 0u) goto done;
    }
    L3: if (--fuel == 0u) goto done;
    if (0xffffffffu) goto done;
    s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)f0 == p0) || (unsigned)s0));
    u3 += (unsigned)(signed char)(p1 << (0xffffffffu & 31u));
    switch (p2 & 7u) {
        if ((p2 << (((unsigned)c1 | 6u) & 31u))) {
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= ((unsigned)((int)3u < (int)i0) ^ (garr[u2 & 7u] ? u1 : a0[i0 & 3u]));
                if ((unsigned)((int)*q0 >= (int)0xc0bdd383u)) goto L4;
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((unsigned)c1 && r0.y) & (unsigned)s0), ((unsigned)(9u == (unsigned)b0) + 0x80000000u), (unsigned)((int)(unsigned)s1 < (int)g1)); }
            }
            if (((unsigned)s0 >> (a0[i0 & 3u] & 31u))) break;
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    case 5u: ;
                    if ((unsigned)(m0 == 0xffffffffu)) break;
                    l0 = (long)((unsigned long)l0 + garr[u2 & 7u]);
                    if (r0.x) {
                        L4: if (--fuel == 0u) goto done;
                        case 2u: ;
                    } else {
                        r0.x = (g0 + ((unsigned)(w0 >> 29) ^ p1));
                        e0 = e0 * 0.5L + (long double)((unsigned)c1 & 1023u);
                        *q0 = (u2 % ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x3e8ddeadu) | 1u));
                    }
                    g0 = (unsigned)((int)(unsigned)((short)0x10000u > (signed char)i1) < (int)(r0.y / (garr[i1 & 7u] | 1u)));
                } while (i1++ < 7u && (unsigned)((int)(0x7fffffffu & (unsigned)f0) < (int)garr[u2 & 7u]));
                r0.y ^= ((unsigned)((short)m0 > (signed char)0x96344b63u) >> ((p0 / ((unsigned)e0 | 1u)) & 31u));
                if (budget != 0u) { budget -= 1u; u0 = fn1((g0 | 0x7fffffffu), (unsigned)((short)m0 > (signed char)p0), (unsigned)((int)(unsigned)b0 >= (int)(unsigned)((int)0x80000000u >= (int)0u))); }
                s0 = (int)a0[i0 & 3u];
                default: ;
                r0.x = (unsigned)(((2u / (a0[u1 & 3u] | 1u)) | 0x5826657eu) < (unsigned)s0);
            }
        } else {
            case 0u: ;
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(signed char)(unsigned)(3u == i0), ((unsigned)(w0 >> 29) * (unsigned)s0), v0); }
        }
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)(g0 || 6u) * 0u), (unsigned)((int)5u < (int)p0), 0x7fffffffu); }
        if (g1) break;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((((unsigned)s1 - m0) % (*q0 | 1u)), (unsigned)f0, (unsigned)((int)0x7fffffffu < (int)(unsigned)(a0[i0 & 3u] == 0x93133161u))); }
            do { if (--fuel == 0u) goto done;
                u0 = ((unsigned)(x0 >> 70) & i2);
                { unsigned t0; double z0; if ((a0[i0 & 3u]) & 1u) { t0 = (garr[i1 & 7u] & i2); z0 = (double)(((v0 << ((unsigned)(u0 == (unsigned)x0) & 31u))) & 255u); } if ((a0[i0 & 3u]) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                    break; (void)((unsigned)((short)0xb4e52e98u > (signed char)0x80000000u));
                    u1 ^= u3;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn2(0x80000000u, (unsigned)((p1 >> (4u & 31u)) == *mp), (unsigned)(unsigned char)((unsigned)((int)(unsigned)h0 < (int)a0[i0 & 3u]) ^ v0)); }
                { unsigned t1; double z1; if (((unsigned)(u2 || p0)) & 1u) { t1 = (unsigned)((int)(unsigned)b0 < (int)0xef1dbf0au); z1 = (double)(((7u * ((unsigned)h1 + (unsigned)h1))) & 255u); } if (((unsigned)(u2 || p0)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    s1 = (int)((unsigned)s1 + (unsigned)((int)((unsigned)(w0 >> 29) - (unsigned)h1) < (int)(unsigned)((int)0xc9c38f6au >= (int)i2)));
                    r0.x = (unsigned)h0;
                    break; (void)((unsigned)((int)g1 < (int)(unsigned)b0));
                    for (;;) { if (--fuel == 0u) goto done;
                        *q0 += ((0x10000u * u2) ^ p2);
                        e0 = e0 * 0.5L + (long double)(((unsigned)(x0 >> 70) % (0x242f1a53u | 1u)) & 1023u);
                        if ((6u * (unsigned)h1)) break;
                    }
                }
            } while (i2++ < 4u && ((unsigned)((int)fuel >= (int)(unsigned)s1) << ((unsigned)s1 & 31u)));
            if ((unsigned)(0xffffffffu || p1)) break;
            break; (void)((unsigned)((garr[u2 & 7u] ^ (unsigned)h1) && a0[i0 & 3u]));
            u0 = u0 * 0x9e3779b1u + 0xffffffffu;
        } while (i1++ < 2u && *mp);
        c1 = (signed char)((unsigned)(signed char)(unsigned)((unsigned)c0 == i2) & 8u);
    }
    while ((0u ^ ~(unsigned)((unsigned)h0 < 0xffffffffu))) { if (--fuel == 0u) goto done;
        q0 = &garr[(0xffffffffu ^ -(unsigned)((int)(unsigned)x0 < (int)i2)) & 7u];
        e0 = e0 * 0.5L + (long double)((u2 | (unsigned)((((unsigned)h0 + 7u) << (fuel & 31u)) && (unsigned)h1)) & 1023u);
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(0x51f9dfa4u && garr[u2 & 7u])) break;
        u2 ^= (unsigned)!((unsigned)((unsigned)((int)u2 < (int)(unsigned)x0) < g1) % (((unsigned)h1 >> (u0 & 31u)) | 1u));
        if (((unsigned)!(7u << (p0 & 31u)) >> (p2 & 31u))) break;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)f0 & 7u) {
                while (i2++ < 5u && (0x40b192c3u & i2)) { if (--fuel == 0u) goto done;
                    break; (void)(p0);
                    if ((garr[i1 & 7u] * (unsigned)((int)(unsigned)w0 >= (int)7u))) continue;
                    case 2u: ;
                    u0 ^= ((unsigned)w0 ^ ((unsigned)(w0 >> 29) ? (unsigned)w0 : 0xffffffffu));
                    u0 ^= ((0xf1b9d331u % (0x10000u | 1u)) * m0);
                    d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)((unsigned)(unsigned char)(unsigned)((int)(a0[u1 & 3u] | 5u) < (int)0x13b21858u) ? 0x27c0fb60u : (unsigned)w0) & 1023u);
                }
                continue; (void)(u3);
                break; (void)((unsigned)(signed char)((unsigned)(0xbc646c84u && 1u) & a0[i0 & 3u]));
            }
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)e0 < (int)(unsigned)((short)fuel > (signed char)*q0))) break;
                if ((i2 - 0x6835ff11u)) {
                    f0 = f0 * 0.5f + (float)((~(a0[u1 & 3u] ? (unsigned)l0 : garr[i1 & 7u]) >> (*q0 & 31u)) & 255u);
                    if ((unsigned)(unsigned char)(5u & i2)) continue;
                    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        continue; (void)((p2 | (unsigned)c0));
                        d0 = d0 * 0.5 + (double)(-(0x10000u * (unsigned)((unsigned)(0x10000u || 5u) == v0)) & 1023u);
                    }
                    a0[(m0 + (unsigned)h1) & 3u] = v0;
                }
                u3 += (unsigned)((int)(a0[u1 & 3u] & i0) >= (int)(p1 | (p0 % (5u | 1u))));
                for (;;) { if (--fuel == 0u) goto done;
                    if (i2) break;
                    d0 = d0 * 0.5 + (double)((unsigned)((int)(u3 ? garr[i1 & 7u] : 0x7fffffffu) < (int)-((unsigned)h1 | p2)) & 1023u);
                    if (((unsigned)w0 ? (unsigned)x0 : (unsigned)x0)) goto L0;
                    w0 ^= (unsigned long long)g1 << ((((unsigned)((int)0xdf231436u >= (int)(unsigned)(x0 >> 70)) / (0x6463019fu | 1u)) % ((unsigned)s0 | 1u)) & 63u);
                    if (((unsigned)l0 - u1)) {
                        if (budget != 0u) { budget -= 1u; u3 = fn2((i1 ? *q0 : 0x152a8790u), ((garr[u2 & 7u] & *mp) | (unsigned)c1), (unsigned)e0); }
                        if ((unsigned)(fuel == 0x554d1188u)) continue;
                        r0.x = (unsigned)h0;
                    }
                }
                c0 = (unsigned char)(unsigned)(signed char)((garr[u2 & 7u] / ((unsigned)x0 | 1u)) / ((unsigned)((int)(unsigned)((int)u3 < (int)*q0) >= (int)v0) | 1u));
                c1 = (signed char)((unsigned)(unsigned char)(p1 % ((unsigned)d0 | 1u)) % (7u | 1u));
            }
            b0 = (unsigned)(short)(unsigned)((unsigned)((short)g0 > (signed char)0xffffffffu) || (unsigned)((int)(unsigned)(w0 >> 29) < (int)0x10000u)) != 0u;
            h1 = (unsigned short)(h1 + (((unsigned)(unsigned char)((unsigned)!(fuel * (unsigned)(x0 >> 70)) % ((unsigned)f0 | 1u)) * 0x59185018u) >> ((unsigned)e0 & 31u)));
            *mp = (unsigned)((int)g0 < (int)(unsigned)e0);
        }
        l0 = (long)((unsigned long)l0 + (unsigned)h1);
        switch ((unsigned)(unsigned char)(garr[u2 & 7u] + 0x7fffffffu) & 7u) {
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (0xdc5651u) goto L0;
                a0[fuel & 3u] = ((unsigned)s0 << (((unsigned)c1 ? (unsigned)(unsigned char)(unsigned)((unsigned)h0 < (unsigned)c0) : garr[i1 & 7u]) & 31u));
                w0 = w0 * 6364136223846793005ull + 0x80000000u;
                case 6u: ;
            }
        }
    }
    switch (~(fuel & ((unsigned)b0 * a0[u1 & 3u])) & 7u) {
        goto L2;
        if (m0) {
            goto done;
            f0 = f0 * 0.5f + (float)((unsigned)(short)(unsigned)((unsigned)((short)0xffffffffu > (signed char)7u) && g1) & 255u);
        }
    }
    while (i0++ < 6u && (unsigned)((unsigned)f0 && u0)) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)d0 ^ (0xee9d17c6u - 0xef985250u)));
        if (((unsigned)w0 / ((unsigned)s0 | 1u))) goto L1;
        if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)((int)v0 < (int)fuel) + (unsigned)(w0 >> 29)), ((unsigned)s1 | u2), p0); }
    }
    if (((unsigned)d0 + (unsigned)(x0 >> 70))) goto L2;
    r0.x = (p1 / ((unsigned)!(unsigned)((short)*q0 > (signed char)(unsigned)((short)(unsigned)l0 > (signed char)garr[i1 & 7u])) | 1u));
    if (((unsigned)s0 >> ((*mp - a0[u1 & 3u]) & 31u))) {
        { unsigned t2; double z2; if ((0x10000u) & 1u) { t2 = (0xb4e0e31cu * (p0 ^ (unsigned)w0)); z2 = (double)(((i2 - g1)) & 255u); } if ((0x10000u) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            h1 = (unsigned short)(h1 + (unsigned)(u2 || (unsigned)s0));
        }
        u0 = (unsigned)(0xf00bf280u && 1u);
        v0 = (0xee98b2b4u * (unsigned)(fuel == i2));
        if ((unsigned)((int)(unsigned)((int)3u < (int)0x50cadeebu) < (int)u0)) {
            if ((unsigned)(signed char)(0x12233a72u & (unsigned)(short)((unsigned)h1 + i1))) goto L0;
            r0.y ^= ((unsigned)((unsigned)((int)v0 < (int)a0[i0 & 3u]) && (unsigned)(u2 < 0x93ec270u)) / ((unsigned)h0 | 1u));
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    break; (void)(i0);
                } while (i1++ < 2u && (*mp | (unsigned)e0));
                switch ((unsigned)((unsigned)(g1 && 0x10000u) && 0x7b512e86u) & 7u) {
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)((unsigned)((short)((unsigned)f0 & p1) > (signed char)(0x865f24f4u | (unsigned)h1)) & 1023u);
                        c1 = (signed char)((unsigned)((int)i1 < (int)0x6a6c217eu) ^ 8u);
                        g0 = ((unsigned)h1 - r0.x);
                    }
                    while (i1++ < 5u && 0x80000000u) { if (--fuel == 0u) goto done;
                        if (0x8fb9587fu) continue;
                    }
                }
            }
            l0 = (long)((unsigned long)l0 + (unsigned)((int)((r0.x / (a0[u1 & 3u] | 1u)) % (v0 | 1u)) < (int)(unsigned)!(6u % (0x75a9261u | 1u))));
            if ((unsigned)((int)(unsigned)c0 >= (int)(unsigned)(0xffffffffu && u2))) goto L0;
        } else {
            switch (v0 & 7u) {
                case 5u: ;
            }
            goto L1;
            if ((unsigned)s1) goto L3;
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)0x80000000u >= (int)r0.y)) break;
            w0 = w0 * 6364136223846793005ull + (a0[i0 & 3u] | (unsigned)(p2 || ~(i2 ^ (r0.y << (0x7fffffffu & 31u)))));
            c1 = (signed char)(((unsigned)(u1 == i0) * 0x7fffffffu) >> (((unsigned)b0 & (unsigned)s0) & 31u));
            break; (void)((unsigned)((unsigned)c0 && (unsigned)x0));
        }
    } else {
        *q0 += (g1 >> ((unsigned)h1 & 31u));
        c0 = (unsigned char)u2;
    }
    goto L3;
    g1 += (*mp ^ 0x7fffffffu);
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)((int)0xffffffffu >= (int)(unsigned)s0)), (0x80000000u + (unsigned)h1), (u3 ? 0xacf73265u : garr[i1 & 7u])); }
    if (a0[u1 & 3u]) goto done;
    { unsigned t3; double z3; if ((0x5f84d62cu) & 1u) { t3 = ((unsigned)c1 << (v0 & 31u)); z3 = (double)(((unsigned)((unsigned)s0 && *q0)) & 255u); } if ((0x5f84d62cu) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        while (i0++ < 2u && ((unsigned)(0xc015a7ecu || (unsigned)f0) >> (r0.x & 31u))) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)(signed char)((unsigned)w0 - (unsigned)(w0 >> 29)));
            if ((unsigned)((short)m0 > (signed char)9u)) {
                continue; (void)((u3 << ((unsigned)(0x80000000u == i0) & 31u)));
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(a0[i0 & 3u] < r0.x) >> (9u & 31u)), (9u ^ ((unsigned)c0 * (unsigned)l0)), m0); }
                if ((p2 << ((unsigned)(short)(u3 - u3) & 31u))) continue;
                if ((unsigned)((int)(unsigned)d0 < (int)9u)) break;
                goto L1;
                if ((unsigned)((unsigned)c0 || (unsigned)((int)garr[i1 & 7u] >= (int)fuel))) break;
            }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                garr[1u & 7u] = (unsigned)((int)0x82c25997u < (int)8u);
            }
        }
        goto L2;
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(unsigned char)(unsigned)((int)(unsigned)(u1 || *mp) < (int)(unsigned)(x0 >> 70)));
                *q0 += ((unsigned)d0 * ((unsigned)((int)v0 < (int)1u) - 0x80000000u));
                while (i2++ < 2u && r0.y) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)((unsigned)b0 == (unsigned)(0x80000000u || a0[u1 & 3u])));
                }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(short)(g1 * (u1 << ((unsigned)(x0 >> 70) & 31u))), (unsigned)((int)fuel < (int)*q0), (0xffffffffu - (0x82fd94feu << (r0.x & 31u)))); }
                v0 = ((fuel % ((u0 * (unsigned)c0) | 1u)) | m0);
            } while (i1++ < 7u && (unsigned)((int)0xdfcfedf6u >= (int)a0[i0 & 3u]));
            garr[(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)s1) & 7u] = (unsigned)((short)(unsigned)((unsigned)((short)(unsigned)x0 > (signed char)((unsigned)c1 - 8u)) < (unsigned)e0) > (signed char)v0);
            u0 += (unsigned)(((unsigned)c1 + 0x80000000u) && ((unsigned)c0 >> ((unsigned)l0 & 31u)));
            w0 = w0 * 6364136223846793005ull + -(0xffffffffu >> ((unsigned)((int)*q0 >= (int)(unsigned)((int)0x8d78d701u >= (int)0xe70cad65u)) & 31u));
            u2 = ((unsigned)(short)(unsigned)(0x77fd015cu && -(unsigned)((int)0x80000000u >= (int)(fuel ^ garr[i1 & 7u]))) ^ (unsigned)h0);
        } while (i0++ < 2u && 0x81b54e8cu);
        if ((unsigned)(r0.x == (unsigned)x0)) goto done;
    }
    *q0 += ((0x10000u / (1u | 1u)) & (unsigned)h0);
    if ((unsigned)!((p0 >> (garr[i1 & 7u] & 31u)) - 0x114be98u)) goto L4;
    if (((unsigned)((unsigned)b0 < (unsigned)h1) ^ r0.y)) goto L3;
    g1 += ((unsigned)((int)g1 < (int)(unsigned)((int)(unsigned)!(a0[u1 & 3u] ^ 0xc06985f6u) >= (int)i0)) % ((unsigned)w0 | 1u));
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0((r0.y & a0[u1 & 3u]), 0x80000000u, ((unsigned)f0 + ((unsigned)c1 - u3))); }
        a0[(unsigned)(0x355452dfu && 7u) & 3u] = (~(((unsigned)s1 - u2) % (((unsigned)x0 | r0.y) | 1u)) | p1);
        if ((unsigned)((unsigned)d0 && i1)) {
            m0 ^= m0;
            if (~(unsigned)(0x47bd6485u && (unsigned)h0)) {
                w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(u3 << ((unsigned)(((r0.y >> ((unsigned)c1 & 31u)) * 0x7fffffffu) || g1) & 31u));
                s1 = (int)((unsigned)s1 + (unsigned)((short)*q0 > (signed char)(unsigned)((int)(unsigned)(0x7b91d20du < v0) < (int)(unsigned)s1)));
                switch ((9u >> ((unsigned)s1 & 31u)) & 7u) {
                    case 4u: ;
                    for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        case 6u: ;
                        i1 = (unsigned)(g0 < (unsigned)(unsigned char)(g0 << ((unsigned)(signed char)(4u * (unsigned)w0) & 31u))) & 15u;
                        l0 = (long)((unsigned long)l0 + p2);
                        { unsigned t4; double z4; if ((-(unsigned)((int)u2 < (int)r0.y)) & 1u) { t4 = ((unsigned)s0 ? p0 : i0); z4 = (double)(((unsigned)((int)(unsigned)(w0 >> 29) < (int)i2)) & 255u); } if ((-(unsigned)((int)u2 < (int)r0.y)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                            c1 = (signed char)a0[i0 & 3u];
                        }
                    }
                    case 2u: ;
                    g1 += (unsigned)(signed char)(-((unsigned)x0 * (unsigned)(fuel < 3u)) & (unsigned)((int)*mp >= (int)garr[i1 & 7u]));
                    if (((unsigned)(*q0 < (unsigned)f0) << (a0[u1 & 3u] & 31u))) {
                        if ((unsigned)((int)v0 >= (int)-((unsigned)b0 << (u0 & 31u)))) continue;
                        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)s0 * (unsigned)l0), (unsigned)((unsigned)x0 && (unsigned)(w0 >> 29)), (unsigned)(unsigned char)((unsigned)((int)(unsigned)s1 < (int)p2) * g1)); }
                        if (budget != 0u) { budget -= 1u; u3 = fn2(((a0[i0 & 3u] + 0xf2df83feu) / (p0 | 1u)), (unsigned)((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)f0) || u0), (i2 % (0xd8fa0370u | 1u))); }
                        case 1u: ;
                        *q0 = ((garr[i1 & 7u] / (*q0 | 1u)) >> ((u2 & *q0) & 31u));
                        if (budget != 0u) { budget -= 1u; u0 = fn1((a0[u1 & 3u] & 0xda00170au), ((unsigned)w0 & 0x40e4229du), (g0 % ((unsigned)(0u || 0xa07e1dceu) | 1u))); }
                    } else {
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((u1 << (g0 & 31u)) || garr[u2 & 7u]), -(unsigned)((int)(unsigned)e0 >= (int)0x10000u), (unsigned)((unsigned)c0 || garr[u2 & 7u])); }
                        if (budget != 0u) { budget -= 1u; u1 = fn2(0xb770fcd0u, g0, (unsigned)((int)(unsigned)c0 < (int)(unsigned)d0)); }
                    }
                }
                if (g0) break;
                break; (void)((unsigned)!(0xffffffffu | (unsigned)(0xffffffffu == (unsigned)h0)));
                if (((unsigned)(8u || (unsigned)s1) | 0x306f0fd4u)) break;
            } else {
                if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)e0 ? 0x7fffffffu : 2u), 0x80000000u, (unsigned)x0); }
                s1 = (int)((unsigned)s1 + (((m0 / (0x80000000u | 1u)) & (unsigned)(u1 || fuel)) * r0.x));
            }
            if (v0) break;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(*mp || a0[i0 & 3u])) break;
            } while (i1++ < 5u && (unsigned)((unsigned)c0 < 1u));
        } else {
            h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)((short)r0.y > (signed char)(unsigned)e0) >= (int)((unsigned)w0 << (0u & 31u))));
            c1 = (signed char)(unsigned)(1u && 0x35d7cccdu);
            f0 = f0 * 0.5f + (float)((~(unsigned)((int)*mp < (int)(unsigned)b0) ? 4u : (u3 & 0x80000000u)) & 255u);
            if ((unsigned)((int)(u3 * *q0) >= (int)0x55468e43u)) break;
        }
        do { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)((unsigned)e0 < v0);
        } while (i1++ < 7u && ~(unsigned)((0x80000000u ^ (unsigned)d0) || a0[i0 & 3u]));
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)r0.y > (signed char)fuel), (unsigned)x0, ((unsigned)((short)i2 > (signed char)m0) ^ garr[i1 & 7u])); }
    } while (i0++ < 7u && (8u % (p2 | 1u)));
    w0 = w0 * 6364136223846793005ull + (p1 % ((unsigned)(0x763da7c9u && -((unsigned)x0 * 0x7fffffffu)) | 1u));
    if (((unsigned)h0 % (-(unsigned)((int)0x1e4c6ca1u < (int)fuel) | 1u))) goto done;
    switch ((unsigned)((unsigned)b0 == ((unsigned)c0 ^ i0)) & 7u) {
        c1 = (signed char)(unsigned)((int)u1 >= (int)(unsigned)((int)0x327c558au < (int)(p1 * (unsigned)b0)));
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        q0 = &garr[~((unsigned)d0 | ((unsigned)(p0 || 6u) | (unsigned)h1)) & 7u];
    }
    s1 = (int)((unsigned)s1 + (u3 % ((unsigned)h0 | 1u)));
    if ((u3 + *q0)) goto L4;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)(0x7fffffffu - (unsigned)b0) << ((p2 >> (0x7fffffffu & 31u)) & 63u);
        L0: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(a0[i0 & 3u] || (unsigned)(a0[i0 & 3u] < (unsigned)h0)), (((unsigned)s0 >> (v0 & 31u)) | u2), 0x8c3bf353u); }
        if ((unsigned)(0xffffffffu && 0xa260caecu)) {
            switch ((unsigned)((int)0x80000000u >= (int)(unsigned)x0) & 7u) {
                m0 ^= (unsigned)!(unsigned)((short)u0 > (signed char)v0);
                q0 = &garr[((unsigned)(*q0 < (g1 | u3)) * ((unsigned)(x0 >> 70) ^ a0[u1 & 3u])) & 7u];
            }
            if (budget != 0u) { budget -= 1u; u3 = fn2(i2, ((unsigned)h0 ^ (unsigned)((int)(unsigned)l0 >= (int)(unsigned)d0)), (unsigned)(u2 < *q0)); }
        } else {
            b0 = ((g0 & (unsigned)l0) / ((unsigned)(signed char)(unsigned)((short)*mp > (signed char)u0) | 1u)) != 0u;
            switch ((unsigned)(short)(unsigned)(0x53089e28u == (0x7fffffffu & (unsigned)w0)) & 7u) {
                u0 = ((g0 ^ (unsigned)e0) % (((fuel & i0) >> (u2 & 31u)) | 1u));
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)b0 || (unsigned)x0), u2, (unsigned)((unsigned)f0 || 0xffffffffu)); }
                w0 = w0 * 6364136223846793005ull + (0x51f7d442u / (0xeb8f0745u | 1u));
                if (((0x5bca6c47u & 5u) % ((unsigned)b0 | 1u))) continue;
                { unsigned t0; double z0; if (((5u & *mp)) & 1u) { t0 = ((unsigned)s0 ? u3 : (unsigned)s1); z0 = (double)((g1) & 255u); } if (((5u & *mp)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                    r0.y ^= (unsigned)(short)((unsigned)(unsigned char)(unsigned)((unsigned)h1 && *mp) + g1);
                    u1 = u1 * 0x9e3779b1u + (unsigned)(signed char)(unsigned)((unsigned)f0 || (unsigned)(short)(m0 * (unsigned)w0));
                    if (9u) break;
                }
            }
        }
    }
    if (-(unsigned)((unsigned)c1 && (unsigned)c0)) {
        if (budget != 0u) { budget -= 1u; u1 = fn2(-(unsigned)((unsigned)s1 < u2), (unsigned)((int)(unsigned)d0 >= (int)(unsigned)(x0 >> 70)), (unsigned)e0); }
        while (i0++ < 7u && (unsigned)((int)0xffffffffu < (int)(unsigned)c0)) { if (--fuel == 0u) goto done;
            garr[(unsigned)(g1 && garr[i1 & 7u]) & 7u] = ((unsigned)((int)(0x80000000u - (r0.y / ((unsigned)h1 | 1u))) >= (int)0xffffffffu) & 1u);
            w0 ^= (unsigned long long)0x101a727fu << (u0 & 63u);
            if (budget != 0u) { budget -= 1u; u2 = fn2((0xa6863965u & a0[u1 & 3u]), a0[u1 & 3u], ((unsigned)e0 - (0x60251d3du ^ (unsigned)b0))); }
            if (fuel < 8u) return (unsigned)((unsigned)(signed char)((unsigned)(unsigned char)(unsigned)((int)1u < (int)garr[u2 & 7u]) * (i1 / (4u | 1u))) == 8u);
        }
        goto L4;
        goto L0;
        g0 = (0x5337477eu / (~(5u ? (u0 * 4u) : v0) | 1u));
    } else {
        g0 = (unsigned)(g1 < (unsigned)((int)g0 >= (int)(unsigned)x0));
        u1 ^= (unsigned)(0xeface622u && (unsigned)(garr[i1 & 7u] && 5u));
        if (u1) goto L0;
    }
    d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(((unsigned)e0 ? m0 : a0[u1 & 3u]) || m0) && (unsigned)(w0 >> 29)) & 1023u);
    r0.x = ((unsigned)((int)(unsigned)((int)0xe182bc22u >= (int)v0) < (int)(unsigned)(w0 >> 29)) + ((unsigned)s1 * i0));
    L1: if (--fuel == 0u) goto done;
    { unsigned t1; double z1; if (((unsigned)((short)9u > (signed char)6u)) & 1u) { t1 = ((unsigned)w0 ^ v0); z1 = (double)(((*q0 >> (r0.x & 31u))) & 255u); } if (((unsigned)((short)9u > (signed char)6u)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        while (i0++ < 2u && ~(unsigned)((*q0 << ((unsigned)s0 & 31u)) && g1)) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(fuel >> (a0[u1 & 3u] & 31u));
        }
        u0 ^= (unsigned)((short)0x10000u > (signed char)fuel);
        if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)f0 % (i2 | 1u)), (unsigned)(short)(0x10000u / (v0 | 1u)), ~((unsigned)f0 << ((p1 >> (a0[i0 & 3u] & 31u)) & 31u))); }
        if ((unsigned)(x0 >> 70)) {
            while (i0++ < 3u && i0) { if (--fuel == 0u) goto done;
                garr[(unsigned)((int)9u >= (int)garr[i1 & 7u]) & 7u] = 6u;
                { unsigned t2; double z2; if ((9u) & 1u) { t2 = (unsigned)e0; z2 = (double)(((0xe302d160u >> ((8u * i1) & 31u))) & 255u); } if ((9u) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    if (budget != 0u) { budget -= 1u; u2 = fn1(i0, g0, u0); }
                    if (u1) continue;
                }
                c0 = (unsigned char)u2;
                L2: if (--fuel == 0u) goto done;
            }
            h1 = (unsigned short)(h1 + (unsigned)((int)8u >= (int)((garr[u2 & 7u] ^ (unsigned)l0) / (m0 | 1u))));
            { unsigned t3; double z3; if (((unsigned)((short)0xffffffffu > (signed char)0xdd9c96ceu)) & 1u) { t3 = ~(unsigned)(0x80000000u && 0x14b80016u); z3 = (double)(((unsigned)((unsigned)x0 < 0xffffffffu)) & 255u); } if (((unsigned)((short)0xffffffffu > (signed char)0xdd9c96ceu)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                d0 = d0 * 0.5 + (double)((unsigned)!(((a0[u1 & 3u] - (unsigned)c0) + p0) & (unsigned)s1) & 1023u);
            }
            w0 ^= (unsigned long long)-((unsigned)f0 / (u1 | 1u)) << ((unsigned)(i0 && (unsigned)l0) & 63u);
        }
        i1 = (unsigned)(i0 || (0xd628194au - (unsigned)((unsigned)c0 == 5u))) & 15u;
    }
    g1 += (unsigned)((short)((unsigned)x0 << (3u & 31u)) > (signed char)((unsigned)c1 % ((unsigned)(unsigned char)(unsigned)(r0.x && 2u) | 1u)));
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (g1 & 7u) {
            do { if (--fuel == 0u) goto done;
                *q0 = ((unsigned)x0 - (unsigned)(3u == (r0.y ^ 0x80000000u)));
            } while (i1++ < 2u && ((unsigned)(unsigned char)(7u & 0x7fffffffu) | (unsigned)h0));
            { unsigned t4; double z4; if (((p1 % (0x7fffffffu | 1u))) & 1u) { t4 = (r0.x % (9u | 1u)); z4 = (double)(((unsigned)h0) & 255u); } if (((p1 % (0x7fffffffu | 1u))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                if (0x9827287bu) {
                    u3 = (unsigned)!((unsigned)e0 * 4u);
                } else {
                    v0 = ((unsigned)b0 << ((unsigned)((short)u1 > (signed char)(unsigned)(w0 >> 29)) & 31u));
                    L3: if (--fuel == 0u) goto done;
                    while (i1++ < 5u && ~(unsigned)((unsigned)!((unsigned)b0 - 0x80000000u) == i0)) { if (--fuel == 0u) goto done;
                        garr[-(unsigned)(m0 == 0x10000u) & 7u] = ((unsigned)(0x7fffffffu < (unsigned)b0) / (((unsigned)x0 / ((unsigned)h1 | 1u)) | 1u));
                        h1 = (unsigned short)(h1 + garr[u2 & 7u]);
                        b0 = 0x10000u != 0u;
                        garr[((unsigned)s0 * 0xf1ac38acu) & 7u] = (1u | ((unsigned)(w0 >> 29) % (0x77de58b8u | 1u)));
                        g1 += ~(((unsigned)(0x7fffffffu && 0xffffffffu) % (0xb4e24201u | 1u)) >> (0xf451e0a1u & 31u));
                    }
                    if (~(unsigned)(6u && 0x8ba555a4u)) break;
                }
                u3 = ((unsigned)(w0 >> 29) * ~(*mp + (unsigned)((short)m0 > (signed char)(unsigned)d0)));
                f0 = f0 * 0.5f + (float)((unsigned)!(unsigned)((unsigned)x0 < r0.y) & 255u);
                break; (void)(((unsigned)((unsigned)(w0 >> 29) && 0x7ff41aceu) >> (a0[u1 & 3u] & 31u)));
            }
            while (i1++ < 7u && (m0 << (0x7fffffffu & 31u))) { if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
            }
        }
        break; (void)((unsigned)(u2 == (*mp << (u1 & 31u))));
        if (budget != 0u) { budget -= 1u; u0 = fn3((7u ? p1 : (unsigned)x0), (unsigned)(p2 < r0.x), (9u ^ (u2 / ((unsigned)c1 | 1u)))); }
        goto L3;
    }
    x0 = x0 * 0x100000001b3ull + (((unsigned)c0 ? fuel : 4u) & p1);
    if ((garr[i1 & 7u] ? (unsigned)w0 : a0[i0 & 3u])) goto L4;
    goto L3;
    if (i0) goto L4;
    while (i0++ < 3u && (0x80000000u << ((0x10000u ^ 1u) & 31u))) { if (--fuel == 0u) goto done;
        if (0x10000u) break;
        while (((unsigned)x0 << ((unsigned)d0 & 31u))) { if (--fuel == 0u) goto done;
            while (i2++ < 4u && ((unsigned)(a0[u1 & 3u] || p1) ^ 7u)) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(r0.x & 1023u);
                break; (void)((unsigned)h0);
                if (fuel < 8u) return (unsigned)(w0 >> 29);
            }
            if ((unsigned)(signed char)(unsigned)(7u || 0x80000000u)) {
                { unsigned t5; double z5; if (((unsigned)(unsigned char)(u0 | 0xa462f480u)) & 1u) { t5 = (unsigned)s1; z5 = (double)(((unsigned)l0) & 255u); } if (((unsigned)(unsigned char)(u0 | 0xa462f480u)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    d0 = d0 * 0.5 + (double)((unsigned)e0 & 1023u);
                    { unsigned t6; double z6; if ((((unsigned)h0 + (unsigned)(g1 || r0.y))) & 1u) { t6 = (unsigned)((unsigned)s0 < 7u); z6 = (double)((g0) & 255u); } if ((((unsigned)h0 + (unsigned)(g1 || r0.y))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                        for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                            if ((((unsigned)h0 * 0x80000000u) + u1)) break;
                        }
                        c1 = (signed char)(a0[u1 & 3u] / (((unsigned)(w0 >> 29) & ((unsigned)c0 + 0x10000u)) | 1u));
                        if (fuel < 8u) return (0xffffffffu + (unsigned)c0);
                    }
                    garr[(unsigned)x0 & 7u] = (unsigned)(((v0 + i1) * (unsigned)(unsigned char)(unsigned)((unsigned)s1 && *mp)) || (unsigned)d0);
                    { unsigned t7; double z7; if (((0xb1710e14u + (unsigned)(w0 >> 29))) & 1u) { t7 = (unsigned)(signed char)(-(v0 % (i0 | 1u)) * (unsigned)(x0 >> 70)); z7 = (double)((((unsigned)s0 * 0x7fffffffu)) & 255u); } if (((0xb1710e14u + (unsigned)(w0 >> 29))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                        if ((unsigned)(((unsigned)l0 * i2) < u1)) goto done;
                    }
                    if ((unsigned)((unsigned)(w0 >> 29) < (unsigned)(x0 >> 70))) break;
                }
            } else {
                q0 = &garr[(unsigned)(unsigned char)((u0 ^ 0xfb9edd9fu) << ((unsigned)(i2 || a0[i0 & 3u]) & 31u)) & 7u];
                r0.y ^= ((unsigned)w0 << (-(0x10000u / (0xffffffffu | 1u)) & 31u));
            }
            v0 = (unsigned)(unsigned char)(unsigned)(r0.y < (unsigned)f0);
        }
        b0 = u1 != 0u;
        if ((unsigned)((int)(0x4fa04f41u << (0xffffffffu & 31u)) < (int)2u)) {
            switch ((unsigned)((short)6u > (signed char)(0x10000u * 0x6a335a82u)) & 7u) {
                if (u3 == 7u) return (unsigned)((int)(0x80000000u >> (0xffffffffu & 31u)) >= (int)0xddb6e3efu);
                u2 = (r0.x ^ (unsigned)b0);
                q0 = &garr[(0x10000u * (unsigned)d0) & 7u];
                switch ((unsigned)(0x80000000u && v0) & 7u) {
                    r0.x = (((unsigned)b0 ? (unsigned)(w0 >> 29) : p2) | (unsigned)b0);
                    goto L3;
                }
            }
            u2 = ((m0 * (unsigned)b0) | (v0 + 0x80000000u));
            g1 += (unsigned)((int)r0.x >= (int)(unsigned)(u1 || (unsigned)f0));
            if ((0x7fffffffu - a0[u1 & 3u])) break;
        }
        break; (void)((unsigned)x0);
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)-(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x14ede6d0u) << ((u0 << (p2 & 31u)) & 63u);
        { unsigned t8; double z8; if (((unsigned)((unsigned)h0 && u3)) & 1u) { t8 = ~(unsigned)((int)(unsigned)(w0 >> 29) < (int)(0x2dbec544u ^ 0xb305d805u)); z8 = (double)(((4u * u2)) & 255u); } if (((unsigned)((unsigned)h0 && u3)) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
            b0 = *q0 != 0u;
            w0 ^= (unsigned long long)(unsigned)((short)g0 > (signed char)u1) << (-(fuel * 8u) & 63u);
            if (u3 == 7u) return ~(a0[u1 & 3u] % (u3 | 1u));
            if (budget != 0u) { budget -= 1u; u3 = fn2(4u, *q0, (unsigned)((unsigned)c1 == (unsigned)((int)0x7fffffffu < (int)p2))); }
        }
        c1 = (signed char)(unsigned)((short)(g1 * (unsigned)x0) > (signed char)(*mp * (unsigned)(i1 || 8u)));
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        continue; (void)((unsigned)(signed char)((r0.x & p0) % (a0[i0 & 3u] | 1u)));
        break; (void)((unsigned)(2u == 3u));
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)!(unsigned)((0xffffffffu + p1) && 4u), (unsigned)!(unsigned)((unsigned)(w0 >> 29) || ((unsigned)w0 >> (u0 & 31u))), (u0 - (unsigned)e0)); }
            if ((unsigned)s1) continue;
            switch ((p0 ^ ((unsigned)x0 >> (a0[i0 & 3u] & 31u))) & 7u) {
                if ((unsigned)(i2 < g0)) goto done;
                *q0 += m0;
                for (;;) { if (--fuel == 0u) goto done;
                    u0 = u0 * 0x9e3779b1u + ((unsigned)(signed char)(unsigned)((7u - 0x7fffffffu) < v0) ^ 0xffffffffu);
                }
            }
        }
    }
    *q0 = (unsigned)f0;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 2u && i1) { if (--fuel == 0u) goto done;
            if (p1) goto L2;
            g0 = ((unsigned)!(unsigned)((unsigned)((int)i2 < (int)r0.y) == v0) & (unsigned)e0);
            if (budget != 0u) { budget -= 1u; u1 = fn1(((6u - (unsigned)f0) * (unsigned)b0), (unsigned)(garr[i1 & 7u] || *q0), (unsigned)(g1 || i2)); }
            { unsigned t9; double z9; if (((unsigned)((unsigned)b0 || (g1 * g0))) & 1u) { t9 = (garr[i1 & 7u] - (unsigned)(p1 || (unsigned)(x0 >> 70))); z9 = (double)((((unsigned)(unsigned char)(v0 & r0.y) / (1u | 1u))) & 255u); } if (((unsigned)((unsigned)b0 || (g1 * g0))) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                if ((unsigned)h1) continue;
            }
            if (2u) break;
            c1 = (signed char)(p2 / ((unsigned)(w0 >> 29) | 1u));
        }
    }
    goto L4;
    if ((unsigned)((unsigned)(x0 >> 70) == 0x80000000u)) goto L0;
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s0, (p2 % ((unsigned)e0 | 1u)), (3u >> ((0xffffffffu / (p1 | 1u)) & 31u))); }
    if ((0xffffffffu ^ 0x28f72e9cu)) goto L0;
    garr[0x30e1159au & 7u] = (0x7fffffffu * (u1 << ((unsigned)b0 & 31u)));
    u1 ^= ((u3 ^ (unsigned)x0) % ((unsigned)((int)(0x2e2ee3cbu * 0x718f333au) >= (int)fuel) | 1u));
    if ((unsigned)(0x7cabc7e7u || (unsigned)c1)) {
        l0 = (long)((unsigned long)l0 + -(((unsigned)((short)u1 > (signed char)(unsigned)(x0 >> 70)) << (garr[u2 & 7u] & 31u)) >> (1u & 31u)));
        switch (~(0xba5379c1u & g0) & 7u) {
            if ((p2 - (unsigned)(w0 >> 29))) break;
            if (0x91120693u) break;
            l0 = (long)((unsigned long)l0 + (i1 & (garr[i1 & 7u] / (p2 | 1u))));
            s1 = (int)((unsigned)s1 + fuel);
            switch (((a0[i0 & 3u] % (p1 | 1u)) / (g0 | 1u)) & 7u) {
                i1 = ((unsigned)l0 % ((unsigned)l0 | 1u)) & 15u;
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)!(p0 % (a0[u1 & 3u] | 1u)) ^ (unsigned)b0), (unsigned)d0, (unsigned)((short)i2 > (signed char)(unsigned)((int)3u < (int)p1))); }
                if ((unsigned)((int)7u >= (int)(unsigned)((short)6u > (signed char)0x65ff501eu))) goto L4;
                s0 = (int)((*mp * ((unsigned)f0 - (unsigned)l0)) + (u1 * i1));
                s0 = (int)(unsigned)((int)(unsigned)((unsigned)((short)garr[i1 & 7u] > (signed char)r0.y) == 0xffffffffu) < (int)a0[i0 & 3u]);
                q0 = &garr[(((u1 * *mp) / ((a0[i0 & 3u] | (unsigned)c1) | 1u)) * *q0) & 7u];
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(~((unsigned)d0 * (unsigned)s1), r0.x, (unsigned)((unsigned)((unsigned)e0 && (unsigned)h1) < 0x4ef1d24u)); }
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn3(9u, (unsigned)(signed char)((unsigned)e0 ^ (0x7fffffffu * u0)), ((unsigned)l0 * (unsigned)e0)); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 14u, 0xd486aa0eu, 0x1de288f7u },
        { 11u, 0x8a8d7be7u, 0xad2b578eu },
        { 9u, 0xd4d52d68u, 0x76a1eaedu },
        { 0u, 0x6584503u, 0x14627c2cu },
        { 15u, 0x6dc2ebcu, 0x93962ef1u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
