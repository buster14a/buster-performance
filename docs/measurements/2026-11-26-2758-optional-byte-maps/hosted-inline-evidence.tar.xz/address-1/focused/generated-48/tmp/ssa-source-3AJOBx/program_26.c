// test-ssa-source's program of seed 134000428 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x93fa4d1bu, g1 = 0x3269bcd4u;
static unsigned garr[8] = { 0x5d6e5bf6u, 0x4b04b802u, 0x14ac70e1u, 0x278cde9du, 0xf421169cu, 0xa6c79dd2u, 0x7a31379eu, 0x2d317eb7u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        break; (void)(5u);
        s0 = (int)(*q0 - (unsigned)((unsigned)h0 && ((fuel << (0xffffffffu & 31u)) & p1)));
        switch ((unsigned)((int)(unsigned)e0 >= (int)(u3 * u0)) & 7u) {
            if (((unsigned)(signed char)(unsigned)((int)8u < (int)(unsigned)l0) * (unsigned)(x0 >> 70))) continue;
        }
        if ((unsigned)f0) {
            do { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)((int)(unsigned)(w0 >> 29) < (int)u1) > (signed char)-(garr[i1 & 7u] >> ((unsigned)(short)(unsigned)((int)v0 < (int)*mp) & 31u))) & 1023u);
                L0: if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                while (i2++ < 4u && 0x10000u) { if (--fuel == 0u) goto done;
                    c1 = (signed char)(unsigned)(0u == u0);
                    s1 = (int)((unsigned)s1 + *q0);
                }
                u1 = u1 * 0x9e3779b1u + (0x10000u - ~((unsigned)((int)(unsigned)d0 < (int)p0) >> ((unsigned)((short)i2 > (signed char)u1) & 31u)));
            } while (i1++ < 2u && (unsigned)((p2 & 0x10000u) == (unsigned)h0));
            if (6u) {
                h1 = (unsigned short)(h1 + (i1 - ((unsigned)((p2 ^ *q0) && 0x5b3ba0c7u) << (1u & 31u))));
                L2: if (--fuel == 0u) goto done;
            }
            if (fuel) {
                w0 ^= (unsigned long long)0x37f8e932u << (p2 & 63u);
            }
            if ((unsigned)(w0 >> 29)) {
                w0 = w0 * 6364136223846793005ull + (unsigned)(*mp < 0x80000000u);
                if (((unsigned)c1 | garr[i1 & 7u])) {
                    if ((unsigned)!(unsigned)(a0[u1 & 3u] && (unsigned)((int)fuel >= (int)(unsigned)b0))) continue;
                    { unsigned t0; double z0; if ((((unsigned)x0 * g1)) & 1u) { t0 = (unsigned)c1; z0 = (double)(((0x10000u / (a0[i0 & 3u] | 1u))) & 255u); } if ((((unsigned)x0 * g1)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                        break; (void)(p1);
                    }
                    if ((unsigned)(0x7fffffffu || (0xf5b8db50u * m0))) {
                        c0 = (unsigned char)(unsigned)(signed char)((u1 ? v0 : (unsigned)w0) ^ (unsigned)((short)(unsigned)d0 > (signed char)(unsigned)c1));
                        *q0 += ((g0 % (u1 | 1u)) / (garr[i1 & 7u] | 1u));
                        c1 = (signed char)((unsigned)((int)4u >= (int)i1) ^ (unsigned)((short)(unsigned)c1 > (signed char)garr[u2 & 7u]));
                        if ((unsigned)(u0 == (0x7fffffffu * (unsigned)b0))) break;
                        { unsigned t1; double z1; if ((-((unsigned)w0 - (unsigned)((int)(unsigned)b0 >= (int)(unsigned)l0))) & 1u) { t1 = 0xaf348516u; z1 = (double)(((unsigned)(0x10000u == 0x305dadbeu)) & 255u); } if ((-((unsigned)w0 - (unsigned)((int)(unsigned)b0 >= (int)(unsigned)l0))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                            L3: if (--fuel == 0u) goto done;
                            break; (void)((unsigned)(m0 && u2));
                            i1 = (0x2fe61f02u + (unsigned)f0) & 15u;
                        }
                        break; (void)(-(unsigned)((int)0x80000000u < (int)(unsigned)(p2 || garr[i1 & 7u])));
                    } else {
                        a0[(0x70235c9bu * (unsigned)s0) & 3u] = (garr[u2 & 7u] & (unsigned)l0);
                        break; (void)((unsigned)f0);
                        if ((unsigned)((unsigned)!(8u >> ((unsigned)(w0 >> 29) & 31u)) == garr[i1 & 7u])) break;
                        if ((unsigned)((short)0xda07aa87u > (signed char)a0[i0 & 3u])) break;
                    }
                    L4: if (--fuel == 0u) goto done;
                } else {
                    garr[(u2 & *q0) & 7u] = (unsigned)((a0[u1 & 3u] + (unsigned)c0) && (i1 * 6u));
                    if ((unsigned)!((unsigned)d0 >> ((unsigned)!(p2 & garr[i1 & 7u]) & 31u))) break;
                    if (garr[u2 & 7u]) break;
                    d0 = d0 * 0.5 + (double)((unsigned)h1 & 1023u);
                }
                u1 ^= (unsigned)((unsigned)((unsigned)c1 == 0x133e50e5u) && u1);
                if (((unsigned)f0 % (m0 | 1u))) {
                    for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        v0 = (unsigned)(signed char)(unsigned)((unsigned)f0 == p2);
                        break; (void)(((p1 % (0u | 1u)) >> (a0[i0 & 3u] & 31u)));
                        c0 = (unsigned char)(unsigned)((0x68d5b6fdu - (unsigned)s1) < 7u);
                        g1 += (unsigned)((g0 ^ m0) == u1);
                    }
                    continue; (void)((unsigned)(signed char)((unsigned)((int)(unsigned)b0 < (int)*mp) / ((unsigned)h1 | 1u)));
                    if ((unsigned)!((unsigned)x0 % (3u | 1u))) goto L3;
                }
            } else {
                break; (void)((g1 + (unsigned)h1));
                if ((5u - 0xffffffffu)) break;
                continue; (void)(((unsigned)((int)a0[u1 & 3u] >= (int)g0) ^ (unsigned)f0));
            }
            if (garr[i1 & 7u]) break;
        } else {
            b0 = (unsigned)((short)(m0 | (a0[u1 & 3u] + (unsigned)(w0 >> 29))) > (signed char)(garr[i1 & 7u] + (unsigned)s0)) != 0u;
            g0 = (unsigned)((unsigned)(signed char)(0x80000000u ? p1 : (unsigned)(signed char)((unsigned)h1 + i0)) < (unsigned)h1);
            if ((0x7fffffffu ? u2 : a0[i0 & 3u])) {
                u2 += ((a0[i0 & 3u] | 0xffffffffu) * (unsigned)x0);
                f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)((unsigned)h0 ^ u2) & 255u);
                break; (void)((unsigned)((int)0x3bb7b98du >= (int)9u));
                if ((unsigned)((unsigned)((short)(unsigned)c0 > (signed char)u3) && *mp)) break;
            } else {
                i0 = (r0.y - (0x7fffffffu & (unsigned)x0)) & 15u;
                goto L0;
                u0 += (unsigned)(i1 || ((unsigned)s1 / (i1 | 1u)));
            }
        }
        a0[(unsigned)((short)(unsigned)e0 > (signed char)8u) & 3u] = (unsigned)((int)u2 < (int)0xa48f96d3u);
        l0 = (long)((unsigned long)l0 + (unsigned)((int)i1 < (int)0xffffffffu));
    } while (i0++ < 5u && (unsigned)d0);
    u0 = u0 * 0x9e3779b1u + (unsigned)((int)((unsigned)s1 / ((u0 >> (i1 & 31u)) | 1u)) < (int)(0x6aecb8e2u * (unsigned)s0));
    if ((unsigned)c0) goto L3;
    r0.y ^= (unsigned)x0;
    switch ((unsigned)e0 & 7u) {
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (0x8c19dd9eu) break;
            if ((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)s0)) continue;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 6u: ;
                switch ((unsigned)h1 & 7u) {
                    do { if (--fuel == 0u) goto done;
                        *q0 += ((i2 & u3) + g0);
                        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((short)v0 > (signed char)(unsigned)b0) < 1u) & 255u);
                    } while (i2++ < 4u && (garr[u2 & 7u] * (unsigned)f0));
                }
                if (v0) {
                    *q0 = (unsigned)!(((2u * 7u) >> (*mp & 31u)) >> ((unsigned)s0 & 31u));
                }
                if ((unsigned)((short)0x7fffffffu > (signed char)p0)) continue;
                h0 = (short)(unsigned)((int)i1 >= (int)0xffffffffu);
            }
        }
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)!((unsigned)h0 << (g0 & 31u))) break;
        u1 ^= ((unsigned)(x0 >> 70) - ((garr[i1 & 7u] % (0x7fffffffu | 1u)) * (unsigned)f0));
        e0 = e0 * 0.5L + (long double)(5u & 1023u);
        if (((i2 / (0xffffffffu | 1u)) << (i1 & 31u))) break;
        if ((u3 & (unsigned)(w0 >> 29))) break;
    } while (i0++ < 5u && 0x80000000u);
    f0 = f0 * 0.5f + (float)((unsigned)(0xffffffffu == (unsigned)((short)0x7fffffffu > (signed char)a0[i0 & 3u])) & 255u);
    switch ((unsigned)!(unsigned)((short)(u1 - u2) > (signed char)p0) & 7u) {
        d0 = d0 * 0.5 + (double)((~((unsigned)h0 * 0x7fffffffu) - (unsigned)f0) & 1023u);
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            a0[(unsigned)(r0.x && a0[u1 & 3u]) & 3u] = (unsigned)((g1 << (a0[i0 & 3u] & 31u)) == (0xb6f7bce6u ? u3 : i1));
            g1 += ((unsigned)c1 * ((u2 ? 0xeadfbfeau : r0.x) << (garr[i1 & 7u] & 31u)));
            case 2u: ;
            while (i1++ < 6u && (p0 ^ 0x3790194fu)) { if (--fuel == 0u) goto done;
                case 0u: ;
                case 5u: ;
                default: ;
                s0 = (int)(unsigned)((unsigned)(6u == 0x10000u) || 9u);
                case 3u: ;
            }
            if ((unsigned)((int)(0xc2a939a7u - u3) >= (int)(unsigned)c0)) continue;
            r0.y ^= ((a0[u1 & 3u] % ((unsigned)s1 | 1u)) & (garr[i1 & 7u] << ((9u + u1) & 31u)));
        }
        break;
    }
    goto done;
    if ((unsigned)((unsigned)h0 == 0x36c43efcu)) goto L3;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)f0) break;
            *mp = (unsigned)((int)((unsigned)(*mp < u3) | 0x7fffffffu) < (int)((unsigned)x0 - 0x80000000u));
            l0 = (long)((unsigned long)l0 + -(*mp - (unsigned)c0));
            l0 = (long)((unsigned long)l0 + ((4u + p2) | ((unsigned)(unsigned char)(r0.x | (unsigned)(x0 >> 70)) + v0)));
            if (garr[u2 & 7u]) break;
            if ((unsigned)((int)(unsigned)c1 < (int)r0.y)) break;
        } while (i1++ < 2u && a0[u1 & 3u]);
        h1 = (unsigned short)(h1 + 9u);
        if ((0x10000u - u1)) break;
        if ((unsigned)h1) {
            x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)((short)1u > (signed char)(unsigned)h1) < (int)(unsigned)(garr[i1 & 7u] && (unsigned)l0));
            if ((g1 * (0xc03f0d5u % (0xf233184fu | 1u)))) break;
        } else {
            e0 = e0 * 0.5L + (long double)((unsigned)((2u - (unsigned)s0) < p1) & 1023u);
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)(unsigned)h0;
            u0 = ((unsigned)(0x80000000u < (i1 >> ((unsigned)(garr[i1 & 7u] || i2) & 31u))) & (unsigned)s1);
            v0 = (unsigned)(short)(v0 / ((unsigned)(unsigned char)(garr[u2 & 7u] + (unsigned)(unsigned char)(0xa650505au >> ((unsigned)((int)0x80000000u < (int)v0) & 31u))) | 1u));
            h0 = (short)(unsigned)(unsigned char)(i0 ^ (((unsigned)x0 & m0) + 1u));
            switch ((unsigned)((int)(0x3244bcf4u << ((unsigned)l0 & 31u)) < (int)4u) & 7u) {
                u0 += ((unsigned)h1 % (((unsigned)w0 % (0x7fffffffu | 1u)) | 1u));
                h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(unsigned)((r0.y >> (8u & 31u)) < garr[i1 & 7u]));
                w0 ^= (unsigned long long)0xd87f63a1u << ((unsigned)((g0 ^ 0x80000000u) && (unsigned)(signed char)(m0 << ((unsigned)s0 & 31u))) & 63u);
            }
            r0.y ^= (i2 & fuel);
        }
    }
    if (u3 == 7u) return (unsigned)(((unsigned)f0 * 0x7fffffffu) == (unsigned)(0x5d1d6d31u && (unsigned)d0));
    goto L0;
    for (;;) { if (--fuel == 0u) goto done;
        { unsigned t2; double z2; if (((m0 ^ ~((unsigned)s0 ^ (unsigned)e0))) & 1u) { t2 = (unsigned)((0x7fffffffu >> (1u & 31u)) < u2); z2 = (double)(((0xa9e26b39u ^ (unsigned)((int)p2 < (int)g1))) & 255u); } if (((m0 ^ ~((unsigned)s0 ^ (unsigned)e0))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            if ((unsigned)!(0x10000u / (((unsigned)h0 | v0) | 1u))) {
                w0 = w0 * 6364136223846793005ull + ((unsigned)((short)p0 > (signed char)9u) << (p0 & 31u));
            } else {
                *q0 = 0u;
                if (i2) break;
                if (0xffffffffu) break;
            }
            break; (void)(g1);
            break; (void)((unsigned)(short)(unsigned)((short)((unsigned)(x0 >> 70) - 0xcd344d3au) > (signed char)*q0));
        }
        u2 += ((0xd29bdec7u >> (u0 & 31u)) << (0x10000u & 31u));
        goto L2;
        if (g1) break;
    }
    if ((unsigned)!(unsigned)((u3 << (p2 & 31u)) < u2)) {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)(9u && garr[u2 & 7u]);
            l0 = (long)((unsigned long)l0 + (0x6a9bb06bu >> ((0xffffffffu ^ p1) & 31u)));
            if ((unsigned)b0) break;
            if ((unsigned)(r0.x && 0u)) {
                if (((unsigned)c0 & (garr[i1 & 7u] ^ garr[i1 & 7u]))) continue;
                continue; (void)((r0.y % (i2 | 1u)));
                break; (void)((unsigned)!((unsigned)(signed char)(0x945c787cu + u0) << (i0 & 31u)));
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)((unsigned)c1 == (unsigned)b0) * garr[u2 & 7u])) break;
                    u2 += ((unsigned)e0 << (i1 & 31u));
                    if ((u2 * 1u)) break;
                    r0.x = ((unsigned)(((unsigned)e0 ^ (unsigned)e0) < (unsigned)h0) >> (v0 & 31u));
                }
                w0 ^= (unsigned long long)(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)(x0 >> 70)) << (((r0.x & u0) | p1) & 63u);
                if ((a0[u1 & 3u] * ((unsigned)c1 ^ p2))) {
                    if ((unsigned)(w0 >> 29)) break;
                    m0 ^= (unsigned)(unsigned char)(unsigned)((short)-(unsigned)((int)((r0.y << (u0 & 31u)) ^ garr[i1 & 7u]) < (int)(unsigned)h1) > (signed char)0xff6f6265u);
                    *q0 += ((unsigned)f0 | (unsigned)((int)2u < (int)4u));
                    if (-(unsigned)(r0.x < 0xffffffffu)) break;
                    for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        u0 ^= a0[u1 & 3u];
                        u3 = u3 * 0x9e3779b1u + ~(0x7fffffffu % ((unsigned)(unsigned char)(unsigned)(i0 == (unsigned)c0) | 1u));
                        r0.x = (unsigned)((unsigned)c0 && 0xffffffffu);
                    }
                    r0.x = (unsigned)!(unsigned)(garr[u2 & 7u] == 0u);
                } else {
                    do { if (--fuel == 0u) goto done;
                        { unsigned t3; double z3; if ((5u) & 1u) { t3 = (0xac99df2eu ^ ((unsigned)l0 * v0)); z3 = (double)((fuel) & 255u); } if ((5u) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                            if ((unsigned)((int)(unsigned)s1 < (int)(9u & 0x7fffffffu))) continue;
                            c0 = (unsigned char)(unsigned)((unsigned)((int)(unsigned)h1 < (int)0x10000u) == (unsigned)h1);
                            if (*mp) continue;
                            w0 = w0 * 6364136223846793005ull + (u3 << (i1 & 31u));
                        }
                        x0 = x0 * 0x100000001b3ull + -(u1 & g1);
                        { unsigned t4; double z4; if (((unsigned)((unsigned)e0 || (unsigned)((int)i1 < (int)a0[u1 & 3u]))) & 1u) { t4 = (unsigned)((int)(unsigned)l0 >= (int)(unsigned)(x0 >> 70)); z4 = (double)(((unsigned)h1) & 255u); } if (((unsigned)((unsigned)e0 || (unsigned)((int)i1 < (int)a0[u1 & 3u]))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                            goto L4;
                            if ((a0[u1 & 3u] + (r0.y >> (a0[i0 & 3u] & 31u)))) goto done;
                        }
                    } while (i1++ < 4u && (unsigned)((int)i1 >= (int)2u));
                    while (i1++ < 3u && ((unsigned)w0 / ((unsigned)f0 | 1u))) { if (--fuel == 0u) goto done;
                        *q0 += ((unsigned)b0 / ((i0 & (unsigned)d0) | 1u));
                        if ((a0[u1 & 3u] ? *q0 : g0)) continue;
                        m0 ^= (2u ? 0x98dcfa71u : (unsigned)b0);
                        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(0x7fffffffu | (unsigned)((int)u3 < (int)((unsigned)b0 ^ 5u))) & 1023u);
                    }
                    if ((u2 >> ((unsigned)h0 & 31u))) break;
                }
            } else {
                break; (void)(9u);
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (unsigned)((int)(0x80000000u + 0xffffffffu) < (int)(unsigned)(signed char)(g0 << (fuel & 31u))));
                    break; (void)((unsigned)((short)i2 > (signed char)(0x12ad9d2du * u3)));
                    break; (void)((unsigned)((unsigned)(w0 >> 29) && (0x80000000u - (unsigned)b0)));
                    if ((unsigned)((int)i0 >= (int)0x80000000u)) goto L2;
                }
                if ((unsigned)(short)(0x10000u % (r0.y | 1u))) break;
                switch ((unsigned)(garr[u2 & 7u] < garr[u2 & 7u]) & 7u) {
                    g1 += (r0.y << (0x10000u & 31u));
                    g1 += ((unsigned)e0 & (unsigned)((garr[i1 & 7u] & r0.y) == m0));
                    g0 = (7u << (u3 & 31u));
                }
            }
            if (u3 == 7u) return (unsigned)(u1 || (u0 << (garr[u2 & 7u] & 31u)));
            if (((unsigned)(w0 >> 29) & 0xffffffffu)) {
                continue; (void)((unsigned)((int)0x452a437au >= (int)u1));
                a0[u2 & 3u] = (8u ? (u2 & (unsigned)c0) : 0x855fd45u);
                if (((unsigned)(0xcb6e02cbu || (unsigned)d0) >> ((unsigned)s1 & 31u))) break;
            } else {
                { unsigned t5; double z5; if ((((unsigned)l0 >> ((unsigned)((int)*mp < (int)(unsigned)c0) & 31u))) & 1u) { t5 = (r0.y - 0xffffffffu); z5 = (double)(((unsigned)(((unsigned)b0 - garr[u2 & 7u]) == 1u)) & 255u); } if ((((unsigned)l0 >> ((unsigned)((int)*mp < (int)(unsigned)c0) & 31u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                    garr[(unsigned)((unsigned)w0 == (unsigned)(x0 >> 70)) & 7u] = (0xffffffffu & g1);
                    if (0x80000000u) break;
                }
            }
        }
        do { if (--fuel == 0u) goto done;
            if (((unsigned)h1 << ((unsigned)e0 & 31u))) {
                u3 = (u3 % (((0x10000u >> ((unsigned)s0 & 31u)) + (unsigned)d0) | 1u));
            } else {
                i1 = ((unsigned)(short)(unsigned)((int)0x80000000u >= (int)(unsigned)((int)(unsigned)l0 >= (int)0x8b088c18u)) << (0x7fffffffu & 31u)) & 15u;
                switch ((unsigned)!(unsigned)(u3 || i2) & 7u) {
                    case 0u: ;
                    if (u3 == 7u) return (((unsigned)s1 << (a0[u1 & 3u] & 31u)) << ((0xffffffffu >> ((p1 * 0x4ca7783du) & 31u)) & 31u));
                    case 1u: ;
                    i1 = (unsigned)((int)(unsigned)s0 >= (int)(unsigned)e0) & 15u;
                }
                if ((unsigned)((int)6u >= (int)garr[u2 & 7u])) break;
            }
            if ((i0 + (unsigned)(u3 || (unsigned)w0))) continue;
            a0[(unsigned)(short)((unsigned)f0 * a0[i0 & 3u]) & 3u] = (unsigned)((unsigned)(signed char)(unsigned)((0x704cab6u | (unsigned)(w0 >> 29)) == (unsigned)s0) == garr[i1 & 7u]);
        } while (i0++ < 4u && (unsigned)!(*q0 / ((unsigned)(0u < 0x32b3eb51u) | 1u)));
        goto L3;
        goto done;
    }
    if (((unsigned)((int)0x3c7fed95u >= (int)garr[u2 & 7u]) << (1u & 31u))) {
        if (garr[i1 & 7u]) {
            if ((unsigned)(0x10000u == p0)) goto L3;
            if (((unsigned)x0 | (a0[u1 & 3u] >> (u2 & 31u)))) goto L4;
            r0.y ^= (unsigned)(((unsigned)(0x6a6935a3u == u2) & p0) && 0x10000u);
            goto L2;
            goto L4;
        } else {
            *q0 += 7u;
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= (unsigned)(signed char)(unsigned)(((unsigned)h1 % ((unsigned)e0 | 1u)) == ((unsigned)(v0 == u1) * r0.x));
                u1 ^= (unsigned)(((unsigned)d0 & g0) && (unsigned)((short)(unsigned)(garr[i1 & 7u] && (unsigned)x0) > (signed char)(unsigned)f0));
                if (~((unsigned)(i1 < 3u) & *mp)) break;
                r0.y ^= (unsigned)(unsigned char)(2u << ((8u - p2) & 31u));
                if (u3 == 7u) return fuel;
                while (i1++ < 5u && p1) { if (--fuel == 0u) goto done;
                    { unsigned t6; double z6; if ((fuel) & 1u) { t6 = m0; z6 = (double)((i0) & 255u); } if ((fuel) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                        w0 = w0 * 6364136223846793005ull + (((unsigned)w0 & (unsigned)((short)0x80000000u > (signed char)p2)) + 0xffffffffu);
                        f0 = f0 * 0.5f + (float)(p0 & 255u);
                        if ((unsigned)(u0 < 5u)) break;
                        if ((unsigned)(p2 || 0x10000u)) continue;
                        break; (void)(r0.y);
                    }
                    break; (void)((unsigned)((int)i0 < (int)0x7fffffffu));
                    break; (void)(((unsigned)(w0 >> 29) << (g0 & 31u)));
                    l0 = (long)((unsigned long)l0 + i2);
                    l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)((int)(unsigned)d0 >= (int)u1) < (int)*mp));
                }
            }
            switch (v0 & 7u) {
                case 5u: ;
                u0 += (p2 << (p0 & 31u));
                g1 += -(unsigned)(a0[i0 & 3u] || (0x31d77725u >> ((unsigned)c1 & 31u)));
                if (0x7fffffffu) goto L2;
            }
        }
        if (garr[i1 & 7u]) goto L4;
        if (u3) {
            x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)c1 || 0x5d6b50ebu) ^ (9u ? u2 : p0));
            g0 = (r0.y | garr[u2 & 7u]);
            u1 += (unsigned)((int)(unsigned)((int)0xffffffffu >= (int)*q0) >= (int)0xffffffffu);
            w0 = w0 * 6364136223846793005ull + ((garr[u2 & 7u] + 0x80000000u) & (u3 ^ g0));
            if (((unsigned)((int)(unsigned)f0 >= (int)(unsigned)s0) ^ u1)) goto L4;
        }
        if ((unsigned)((int)m0 < (int)(unsigned)b0)) goto L2;
    }
    switch (-(m0 + (unsigned)((int)0xd3a86394u >= (int)(unsigned)w0)) & 7u) {
        r0.x = (unsigned)(0xffffffffu == (unsigned)c0);
        u3 = u0;
        garr[u1 & 7u] = ((unsigned)((unsigned)w0 < (unsigned)((int)(unsigned)b0 < (int)(unsigned)f0)) + p2);
    }
    { unsigned t7; double z7; if (((unsigned)((short)((unsigned)(x0 >> 70) + (unsigned)b0) > (signed char)u1)) & 1u) { t7 = (unsigned)(0x3716edcau == *q0); z7 = (double)((0x10000u) & 255u); } if (((unsigned)((short)((unsigned)(x0 >> 70) + (unsigned)b0) > (signed char)u1)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
        if (((g0 >> (0xffffffffu & 31u)) - fuel)) goto L1;
        *q0 = (5u >> (0xa5eae936u & 31u));
        goto L4;
    }
    if ((3u % (u0 | 1u))) {
        if ((unsigned)(fuel || *mp)) goto L2;
        goto L4;
        { unsigned t8; double z8; if ((a0[u1 & 3u]) & 1u) { t8 = (unsigned)((int)(unsigned)c1 < (int)(unsigned)w0); z8 = (double)((0x10000u) & 255u); } if ((a0[u1 & 3u]) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
            if (0x7fffffffu) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)(r0.x < (unsigned)((int)(unsigned)l0 >= (int)0x10000u)) * (unsigned)d0) == r0.y);
            if ((unsigned)!(i1 % ((unsigned)(x0 >> 70) | 1u))) {
                s0 = (int)((unsigned)(unsigned char)(garr[i1 & 7u] / (p0 | 1u)) % (g0 | 1u));
                garr[g1 & 7u] = (p0 | (0x2be888b2u ? (unsigned)x0 : garr[u2 & 7u]));
                s1 = (int)((unsigned)s1 + (((0x3a32e575u ^ (unsigned)f0) - (u3 + 0x10000u)) >> ((unsigned)d0 & 31u)));
            } else {
                if (9u) goto L4;
                g0 = ((0x7fffffffu ^ i1) << ((unsigned)(w0 >> 29) & 31u));
            }
            switch ((unsigned)((unsigned)f0 == 0x31a4a019u) & 7u) {
                a0[(u0 % (1u | 1u)) & 3u] = (unsigned)(signed char)((0xffffffffu + (unsigned)s1) >> (0x7fffffffu & 31u));
                { unsigned t9; double z9; if (((unsigned)((short)0x10000u > (signed char)r0.x)) & 1u) { t9 = 9u; z9 = (double)(((unsigned)h1) & 255u); } if (((unsigned)((short)0x10000u > (signed char)r0.x)) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
                    r0.y ^= (((unsigned)b0 ^ (unsigned)d0) << (3u & 31u));
                    case 3u: ;
                    if ((unsigned)(signed char)(unsigned)((unsigned)((int)u3 >= (int)(unsigned)h0) && (unsigned)s0)) goto done;
                    w0 ^= (unsigned long long)u3 << ((garr[u2 & 7u] / (m0 | 1u)) & 63u);
                    case 6u: ;
                    u2 ^= (((unsigned)!(0x6afe3de3u ^ (unsigned)h0) - (0xb28a428fu / (r0.x | 1u))) - p1);
                }
                break; (void)(((unsigned)c1 % (((unsigned)d0 / ((unsigned)s1 | 1u)) | 1u)));
            }
        }
        g0 = (unsigned)f0;
        u2 ^= (a0[u1 & 3u] << (((unsigned)((short)0xe0aaefb4u > (signed char)u2) >> ((unsigned)l0 & 31u)) & 31u));
    } else {
        h0 = (short)-(unsigned)((int)(unsigned)((unsigned)c1 == garr[i1 & 7u]) < (int)(unsigned)h0);
    }
    x0 = x0 * 0x100000001b3ull + a0[u1 & 3u];
    if ((0x10000u << (garr[u2 & 7u] & 31u))) goto L0;
    goto L3;
    goto L1;
    do { if (--fuel == 0u) goto done;
        b0 = 0x10000u != 0u;
        do { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((0x80000000u - 4u) + (unsigned)x0);
            g0 = (unsigned)((0x80000000u << (g0 & 31u)) && fuel);
            if (a0[i0 & 3u]) break;
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (((m0 % (0x7ad08824u | 1u)) ^ (unsigned)(w0 >> 29))) break;
                if ((unsigned)((unsigned)(p1 || a0[i0 & 3u]) == 0x2e6f9f83u)) break;
                u2 = ~(((unsigned)(x0 >> 70) << (0xf9a39e6du & 31u)) + (g1 << (r0.x & 31u)));
                d0 = d0 * 0.5 + (double)(i0 & 1023u);
            }
            break; (void)(((unsigned)(g0 || 3u) & garr[i1 & 7u]));
            c0 = (unsigned char)(g1 * u1);
        } while (i1++ < 3u && (unsigned)(signed char)(unsigned)(~((unsigned)c1 % ((unsigned)d0 | 1u)) && 0x33f439b0u));
    } while (i0++ < 5u && (unsigned)!(~(garr[u2 & 7u] >> (u3 & 31u)) >> ((unsigned)c0 & 31u)));
    if (p1) goto done;
    switch ((unsigned)((unsigned)s0 < g1) & 7u) {
        s0 = (int)(unsigned)h0;
    }
    u0 = (0x10000u * garr[u2 & 7u]);
    r0.x = (r0.x & (((0xb3c5c3dfu << ((unsigned)d0 & 31u)) & u3) >> (0x7fffffffu & 31u)));
    w0 = w0 * 6364136223846793005ull + 0x2de093f3u;
    *mp = (unsigned)((short)(0x7072136cu ^ a0[i0 & 3u]) > (signed char)(unsigned)(8u < (i0 * a0[u1 & 3u])));
    if (*q0) goto L1;
    if (((unsigned)b0 + (unsigned)(short)(unsigned)((short)0x75742cf7u > (signed char)p2))) goto L2;
    if (u0) goto L1;
    f0 = f0 * 0.5f + (float)((unsigned)h0 & 255u);
    switch ((unsigned)((int)(unsigned)w0 >= (int)0x80000000u) & 7u) {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 2u: ;
                case 0u: ;
            }
            case 5u: ;
            default: ;
            r0.y ^= ((0xffffffffu ? (unsigned)(x0 >> 70) : i2) + (unsigned)l0);
        }
    }
    if ((-(0xba3be7bbu % (u1 | 1u)) + 0xb7b2d03au)) goto L3;
    switch ((u1 + (unsigned)((int)0x38dd002bu >= (int)m0)) & 7u) {
        e0 = e0 * 0.5L + (long double)(0x80000000u & 1023u);
    }
    goto L3;
    while ((unsigned)h1) { if (--fuel == 0u) goto done;
        if ((unsigned)c1) goto done;
        v0 = (unsigned)c0;
        break; (void)((unsigned)(signed char)(5u + p0));
        if (0x9b73df07u) goto L0;
    }
    s1 = (int)((unsigned)s1 + ((unsigned)l0 + (u0 ? (unsigned)(p2 == garr[u2 & 7u]) : (unsigned)l0)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(fuel & r0.x) >= (int)(unsigned)x0);
    do { if (--fuel == 0u) goto done;
        u2 = u2 * 0x9e3779b1u + a0[i0 & 3u];
        q0 = &garr[(unsigned)s0 & 7u];
        goto L0;
        e0 = e0 * 0.5L + (long double)((i2 * (unsigned)(((unsigned)s0 % (garr[u2 & 7u] | 1u)) < 0xffffffffu)) & 1023u);
        q0 = &garr[(unsigned)(((unsigned)h0 / (*mp | 1u)) && 8u) & 7u];
    } while (i0++ < 4u && i1);
    if ((unsigned)((int)a0[u1 & 3u] < (int)p0)) {
        if ((unsigned)((0x10000u / ((unsigned)f0 | 1u)) == r0.x)) goto L2;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)((unsigned)s0 + 0x10000u) < (int)*mp), (unsigned)((int)p0 < (int)(i1 * 0x2fcd4bcau)), 0x7ad20381u); }
        if ((i1 / ((0x10000u ^ 0u) | 1u))) {
            goto L3;
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)h1 - (unsigned)l0), p1, (u2 + 0x7d3c38e5u)); }
            garr[8u & 7u] = (p0 ^ 7u);
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((unsigned)s0 || p0) || p1);
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((p1 + (unsigned)(x0 >> 70)) && (unsigned)s1), ((a0[i0 & 3u] ^ (unsigned)d0) & *q0), 0x80000000u); }
        }
    }
    { unsigned t0; double z0; if ((*mp) & 1u) { t0 = (i2 << (((unsigned)d0 ^ 0x80000000u) & 31u)); z0 = (double)(((unsigned)((unsigned)(signed char)(3u / (g1 | 1u)) && r0.x)) & 255u); } if ((*mp) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if ((unsigned)((short)4u > (signed char)(unsigned)b0)) goto L1;
        switch (((unsigned)c0 & ~(g0 - (unsigned)b0)) & 7u) {
            l0 = (long)((unsigned long)l0 + ((unsigned)h1 ? g0 : (i1 << ((unsigned)f0 & 31u))));
            r0.x = 2u;
            L0: if (--fuel == 0u) goto done;
            u2 ^= (unsigned)((int)(unsigned)(unsigned char)(unsigned)(u3 == (p0 * (unsigned)h0)) < (int)(unsigned)(v0 || (unsigned)(x0 >> 70)));
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)d0, i2, ((unsigned)h0 & 4u)); }
        }
        f0 = f0 * 0.5f + (float)(i2 & 255u);
        if (((unsigned)!((unsigned)(w0 >> 29) * a0[u1 & 3u]) - 0x46ad0489u)) goto L4;
        v0 = (0x85bb425bu / ((unsigned)w0 | 1u));
        u1 += (unsigned)((u0 << (a0[i0 & 3u] & 31u)) && (unsigned)s1);
    }
    L1: if (--fuel == 0u) goto done;
    x0 = x0 * 0x100000001b3ull + ((unsigned)(r0.x || p1) ? (unsigned)h0 : (r0.y / (u2 | 1u)));
    goto L3;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 ^= 0x10000u;
        if ((unsigned)!(unsigned)((unsigned)h0 && (unsigned)s0)) continue;
    }
    switch ((unsigned)h0 & 7u) {
        g0 = ((unsigned)((int)u1 < (int)v0) ^ (p2 / (0x5b6ef9b0u | 1u)));
    }
    if (8u) goto L4;
    goto done;
    w0 = w0 * 6364136223846793005ull + (unsigned)((r0.x - (unsigned)c0) < 0xa11bc7fbu);
    if (((6u | r0.x) >> (i2 & 31u))) goto done;
    if (budget != 0u) { budget -= 1u; u0 = fn0((0xf5d9172cu ^ 0x80000000u), ((p2 | i2) % ((unsigned)f0 | 1u)), (9u % (0xffffffffu | 1u))); }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((2u - fuel) < 0u)) {
            x0 = x0 * 0x100000001b3ull + a0[i0 & 3u];
            if (~((3u << (0x80000000u & 31u)) % (fuel | 1u))) break;
            L2: if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
        } else {
            h0 = (short)(0xffffffffu - (u1 ? 5u : (unsigned)f0));
            h0 = (short)(unsigned)((unsigned)s1 || ((unsigned)(unsigned char)(0x58486214u - g1) % (0x10000u | 1u)));
            g0 = (unsigned)(w0 >> 29);
        }
        if ((i2 ^ g0)) break;
        if ((unsigned)s1) continue;
        m0 ^= ((unsigned)s0 * ~(0x184f176au % (u1 | 1u)));
        break; (void)((g0 | (0xa4c8136bu ^ u3)));
    }
    if ((9u << (0x2f003e28u & 31u))) {
        if (fuel < 8u) return (unsigned)((int)(unsigned)!(m0 ^ ((unsigned)f0 ^ u0)) < (int)(unsigned)e0);
    } else {
        L4: if (--fuel == 0u) goto done;
    }
    d0 = d0 * 0.5 + (double)((((fuel * (fuel + (unsigned)c0)) * p2) >> (*mp & 31u)) & 1023u);
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!(unsigned)(u1 == p0), 2u, 1u); }
    if ((unsigned)l0) goto L3;
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)f0, 0x7fffffffu, i1); }
    if (((unsigned)(w0 >> 29) ? (unsigned)s1 : (unsigned)(w0 >> 29))) goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn0((i1 << (0x10000u & 31u)), (unsigned)f0, (unsigned)e0); }
    switch ((unsigned)!(unsigned)((short)(unsigned)((short)0x10000u > (signed char)0xab1310bau) > (signed char)garr[i1 & 7u]) & 7u) {
        switch ((4u & (unsigned)e0) & 7u) {
            { unsigned t1; double z1; if (((unsigned)((int)*q0 < (int)0x9b0e51f2u)) & 1u) { t1 = (*mp | (unsigned)c0); z1 = (double)(((unsigned)s1) & 255u); } if (((unsigned)((int)*q0 < (int)0x9b0e51f2u)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                b0 = (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)((unsigned)f0 < m0)) != 0u;
                f0 = f0 * 0.5f + (float)((unsigned)(short)(unsigned)((unsigned)l0 && ((0x7fffffffu << (u2 & 31u)) / (u0 | 1u))) & 255u);
                if (~(a0[i0 & 3u] << (p0 & 31u))) goto L0;
                if ((u3 ? 0xb4ba92b0u : (unsigned)s0)) goto done;
                if (0x68dba73u) goto L3;
                if (budget != 0u) { budget -= 1u; u3 = fn0((u1 - 5u), (*mp / ((unsigned)h1 | 1u)), (r0.x >> (u0 & 31u))); }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(i0, (*q0 << (a0[u1 & 3u] & 31u)), (unsigned)((unsigned)h0 == 6u)); }
            do { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)((int)0x715fb268u < (int)0x23408d8bu) & 1023u);
                case 6u: ;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    goto L3;
                    u3 ^= (0xffffffffu & p2);
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(p0, (unsigned)(0xaac4da73u < (unsigned)d0), (unsigned)(unsigned char)(p1 ^ (unsigned)b0)); }
                        while ((unsigned)((unsigned)d0 == v0)) { if (--fuel == 0u) goto done;
                            s0 = (int)(unsigned)((int)(unsigned)((short)p2 > (signed char)(0x7fffffffu << (0x7fffffffu & 31u))) >= (int)(r0.y >> ((unsigned)d0 & 31u)));
                        }
                        goto L2;
                    }
                    case 3u: ;
                    u3 = (unsigned)((unsigned)((int)u1 >= (int)a0[u1 & 3u]) || (unsigned)(x0 >> 70));
                }
            } while (i0++ < 4u && (0xffffffffu >> (0x7fffffffu & 31u)));
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                b0 = (unsigned)l0 != 0u;
                { unsigned t2; double z2; if ((fuel) & 1u) { t2 = 9u; z2 = (double)(((unsigned)(short)(unsigned)((unsigned)w0 == (unsigned)s0)) & 255u); } if ((fuel) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    case 2u: ;
                    case 5u: ;
                    c1 = (signed char)(unsigned)(0x10000u && (a0[u1 & 3u] ^ a0[i0 & 3u]));
                    do { if (--fuel == 0u) goto done;
                        default: ;
                        break;
                        if (((unsigned)(w0 >> 29) + 0x88f94c1cu)) break;
                    } while (i1++ < 6u && (unsigned)h0);
                    { unsigned t3; double z3; if (((p1 % ((unsigned)(w0 >> 29) | 1u))) & 1u) { t3 = -(a0[i0 & 3u] - (unsigned)h1); z3 = (double)(((unsigned)((int)(unsigned)b0 >= (int)(unsigned)h1)) & 255u); } if (((p1 % ((unsigned)(w0 >> 29) | 1u))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                        d0 = d0 * 0.5 + (double)((unsigned)((i1 ^ ((unsigned)(5u == 0x7fffffffu) + garr[i1 & 7u])) && 0xffffffffu) & 1023u);
                        c0 = (unsigned char)(unsigned)((int)p0 < (int)(unsigned)x0);
                        if ((unsigned)(garr[i1 & 7u] && 0xa1f479e2u)) {
                            case 0u: ;
                            m0 ^= (unsigned)(6u && (unsigned)f0);
                            u0 = p0;
                            *mp = (unsigned)(i1 || (0x80ff317fu + 4u));
                        } else {
                            if (budget != 0u) { budget -= 1u; u3 = fn0((3u | g0), 3u, (((unsigned)s0 / ((unsigned)s1 | 1u)) - garr[u2 & 7u])); }
                            case 1u: ;
                            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)b0 / ((0x7fffffffu | 0xb7c4127eu) | 1u)), ((unsigned)(signed char)((unsigned)(x0 >> 70) * (unsigned)c1) & p1), (unsigned)((unsigned)(*q0 || u3) == fuel)); }
                            continue; (void)(g1);
                        }
                        garr[fuel & 7u] = (unsigned)((((unsigned)s1 + (unsigned)b0) % ((unsigned)(r0.y && (unsigned)h1) | 1u)) == (unsigned)d0);
                        if (0x6522f7e4u) continue;
                        case 7u: ;
                    }
                    for (;;) { if (--fuel == 0u) goto done;
                        switch ((unsigned)b0 & 7u) {
                            case 6u: ;
                            w0 = w0 * 6364136223846793005ull + (7u & 0xe3ac5d8cu);
                        }
                    }
                }
                s0 = (int)((garr[i1 & 7u] ^ (unsigned)((unsigned)f0 == u2)) >> (0x10000u & 31u));
            }
            m0 ^= *mp;
        }
        g0 = ((r0.x | r0.y) << ((0xa834ff7fu & m0) & 31u));
        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)s1 % ((p0 ^ (unsigned)b0) | 1u)), (unsigned)!(unsigned)((unsigned)s1 < 0x10000u), garr[i1 & 7u]); }
        *q0 = (unsigned)((int)(unsigned)((int)(unsigned)(unsigned char)(unsigned)(i0 && (unsigned)((short)i1 > (signed char)(unsigned)b0)) < (int)(unsigned)(w0 >> 29)) < (int)fuel);
        if ((0x64dbcf43u * *q0)) {
            case 5u: ;
            s1 = (int)((unsigned)s1 + (unsigned)(g1 && u2));
            do { if (--fuel == 0u) goto done;
                if ((~((unsigned)d0 / ((unsigned)h1 | 1u)) * 0x915dda84u)) {
                    if ((((unsigned)w0 + (unsigned)l0) % (i1 | 1u))) goto L2;
                    *mp = (unsigned)((unsigned)l0 || (u3 - ((unsigned)w0 << (0xaa61784cu & 31u))));
                    f0 = f0 * 0.5f + (float)(i0 & 255u);
                    case 6u: ;
                }
                if (7u) goto L0;
            } while (i0++ < 4u && (unsigned)(short)(unsigned)(3u == (u2 * a0[i0 & 3u])));
            case 4u: ;
        } else {
            a0[(unsigned)e0 & 3u] = (unsigned)d0;
            if ((unsigned)h1) goto L4;
            a0[0x6b7d70dbu & 3u] = (unsigned)(w0 >> 29);
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + 0x3a82a36du);
            b0 = 0xebf081dfu != 0u;
            if (budget != 0u) { budget -= 1u; u0 = fn0(0u, (((unsigned)x0 / (0xffffffffu | 1u)) & garr[u2 & 7u]), (unsigned)s1); }
            if (0x10000u) goto L4;
            b0 = (unsigned)l0 != 0u;
            g0 = (unsigned)f0;
        }
    }
    switch (((unsigned)l0 & 0x8ae4040cu) & 7u) {
        case 1u: ;
        for (;;) { if (--fuel == 0u) goto done;
            { unsigned t4; double z4; if ((((unsigned)(w0 >> 29) % (0xebeddc0eu | 1u))) & 1u) { t4 = (unsigned)(signed char)(i2 % ((unsigned)d0 | 1u)); z4 = (double)((g0) & 255u); } if ((((unsigned)(w0 >> 29) % (0xebeddc0eu | 1u))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                case 2u: ;
                case 6u: ;
                d0 = d0 * 0.5 + (double)((((unsigned)e0 ? 1u : 0x6dd10375u) + ((unsigned)f0 & (unsigned)(x0 >> 70))) & 1023u);
            }
            if (~(u1 * (unsigned)!(unsigned)(a0[i0 & 3u] < *mp))) goto L2;
        }
        goto L0;
        for (;;) { if (--fuel == 0u) goto done;
            u3 += ((unsigned)l0 - 0xffffffffu);
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                default: ;
            }
            l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)(garr[i1 & 7u] || (unsigned)(unsigned char)(unsigned)(1u == garr[i1 & 7u])) % (i1 | 1u)) < (int)i0));
            if (0u) {
                if (~(unsigned)((int)(a0[i0 & 3u] - (unsigned)(x0 >> 70)) < (int)*q0)) goto L3;
                x0 = x0 * 0x100000001b3ull + (unsigned)(x0 >> 70);
                case 0u: ;
                a0[garr[u2 & 7u] & 3u] = (unsigned)(0x20dec466u < u3);
                do { if (--fuel == 0u) goto done;
                    garr[a0[u1 & 3u] & 7u] = u0;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)((int)r0.y < (int)r0.y) < (int)u3), (unsigned)(unsigned char)(unsigned)(r0.y < (unsigned)d0), (0xfb9eac42u & (unsigned)((short)(unsigned)f0 > (signed char)0x80000000u))); }
                    break; (void)((unsigned)((u3 - 0x7fffffffu) == (unsigned)h0));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(i1 == (unsigned)b0), (unsigned)(0x9de7c485u || ((unsigned)c0 | 0xaefae632u)), ((unsigned)(x0 >> 70) >> ((unsigned)!(unsigned)(0u && garr[i1 & 7u]) & 31u))); }
                    *mp = g1;
                    b0 = -(unsigned)((unsigned)((short)(unsigned)((short)(unsigned)x0 > (signed char)garr[i1 & 7u]) > (signed char)(unsigned)f0) || a0[i0 & 3u]) != 0u;
                } while (i1++ < 7u && (unsigned)((short)(unsigned)l0 > (signed char)i1));
                c0 = (unsigned char)((i2 + (unsigned)s0) * (unsigned)((int)i1 < (int)4u));
            } else {
                case 3u: ;
                if ((unsigned)((int)g1 < (int)0x7fffffffu)) goto L1;
                s1 = (int)((unsigned)s1 + (u3 << ((unsigned)(x0 >> 70) & 31u)));
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)(unsigned)((u1 - (unsigned)c0) < 9u), (unsigned)(fuel || r0.x), (unsigned)((unsigned)d0 == i2)); }
        }
        case 4u: ;
    }
    do { if (--fuel == 0u) goto done;
        *q0 += (unsigned)((garr[u2 & 7u] | (unsigned)((unsigned)((unsigned)f0 == 5u) && g1)) == u1);
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)d0 < 0x344f5f69u), ((unsigned)(w0 >> 29) * (unsigned)h1), a0[u1 & 3u]); }
    } while (i0++ < 5u && (unsigned)((short)(0x80000000u + 0x80000000u) > (signed char)(unsigned)d0));
    c0 = (unsigned char)(unsigned)((unsigned)((unsigned)(w0 >> 29) < 0xf8b01c07u) && v0);
    { unsigned t5; double z5; if ((((unsigned)x0 & (unsigned)((int)g1 >= (int)fuel))) & 1u) { t5 = (unsigned)(signed char)(unsigned)((int)*mp < (int)m0); z5 = (double)(((unsigned)(short)((unsigned)h1 + (unsigned)((short)0x8b647e2au > (signed char)5u))) & 255u); } if ((((unsigned)x0 & (unsigned)((int)g1 >= (int)fuel))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        if ((unsigned)x0) goto L3;
    }
    { unsigned t6; double z6; if ((((unsigned)x0 - u0)) & 1u) { t6 = *q0; z6 = (double)((fuel) & 255u); } if ((((unsigned)x0 - u0)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
        if ((6u & (unsigned)l0)) {
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                goto L4;
                { unsigned t7; double z7; if (((unsigned)s0) & 1u) { t7 = (unsigned)((short)(unsigned)x0 > (signed char)(unsigned)b0); z7 = (double)(((g0 ^ a0[u1 & 3u])) & 255u); } if (((unsigned)s0) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                    if (8u) {
                        u1 += (unsigned)(u0 || (a0[u1 & 3u] + (unsigned)((unsigned)c1 && (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)3u))));
                        if ((unsigned)(r0.x == 0x7f6e8473u)) break;
                        if ((0u | 4u)) goto L3;
                        if ((2u - (r0.x * 7u))) break;
                    } else {
                        if (budget != 0u) { budget -= 1u; u0 = fn0(a0[i0 & 3u], (unsigned)c1, (unsigned)((unsigned)((int)v0 < (int)(unsigned)(w0 >> 29)) < m0)); }
                    }
                    if ((unsigned)(unsigned char)(p2 / ((g1 << (*mp & 31u)) | 1u))) break;
                }
                if (6u) goto L0;
                a0[garr[i1 & 7u] & 3u] = (unsigned)(unsigned char)(garr[u2 & 7u] ^ (unsigned)(r0.y == u1));
            }
            if ((r0.y | (unsigned)((unsigned)(x0 >> 70) && (unsigned)s1))) goto L0;
            goto L1;
            if ((((unsigned)w0 / ((unsigned)c1 | 1u)) / (g1 | 1u))) goto L0;
            if ((0x526eb66fu >> (((unsigned)(w0 >> 29) | p2) & 31u))) goto done;
        }
        if (0x10000u) goto L3;
    }
    while (i0++ < 4u && (u1 - 0x10000u)) { if (--fuel == 0u) goto done;
        if (3u) continue;
        v0 = a0[i0 & 3u];
        h0 = (short)(unsigned)s0;
        while ((((unsigned)x0 - (unsigned)s0) & p1)) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)(0x5d1430f4u && (unsigned)w0)), (unsigned)((short)9u > (signed char)0x36b2b28bu), ((unsigned)x0 + g0)); }
                if ((unsigned)(-((unsigned)l0 & 0x7fffffffu) == (unsigned)f0)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(short)(unsigned)(0x5d14cc49u || (unsigned)f0), (unsigned)(g0 || *mp), (unsigned)((int)8u >= (int)a0[u1 & 3u])); }
                u2 ^= ((unsigned)c1 | 0xf8b8ba6eu);
                do { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)(signed char)((unsigned)((unsigned)c0 == p0) + i0));
                    for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)(((unsigned)c0 >> ((unsigned)x0 & 31u)));
                        s1 = (int)((unsigned)s1 + (unsigned)((short)0x7fffffffu > (signed char)i0));
                        *mp = (garr[u2 & 7u] / (~((unsigned)w0 + *q0) | 1u));
                        break; (void)((unsigned)!(0x941da079u % (0x80000000u | 1u)));
                        { unsigned t8; double z8; if (((unsigned)((int)5u < (int)garr[u2 & 7u])) & 1u) { t8 = (g0 >> (0xfb8afde9u & 31u)); z8 = (double)(((-(unsigned)((int)(unsigned)d0 >= (int)0xe396507eu) - 0x7fffffffu)) & 255u); } if (((unsigned)((int)5u < (int)garr[u2 & 7u])) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                            if ((unsigned)((int)(unsigned)h0 >= (int)(p2 << ((unsigned)h0 & 31u)))) break;
                            w0 ^= (unsigned long long)r0.x << ((unsigned)((int)0x4dd165eau < (int)0x80000000u) & 63u);
                        }
                    }
                    while (i1++ < 7u && (a0[u1 & 3u] >> (p2 & 31u))) { if (--fuel == 0u) goto done;
                        a0[(unsigned)((int)0x56bc2670u >= (int)(unsigned)h1) & 3u] = (unsigned)((short)0x75e45f0fu > (signed char)(u0 * i0));
                        break; (void)((p0 + (unsigned)d0));
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)r0.y < (int)((unsigned)h1 & garr[u2 & 7u])));
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)-(0x80000000u & u2) < (int)(unsigned)e0), (unsigned)((int)3u < (int)9u), ((unsigned)e0 | u2)); }
                        if ((i0 + u3)) break;
                        c1 = (signed char)(unsigned)((int)u2 < (int)(0x7fffffffu ? 0x10000u : (unsigned)((int)*mp < (int)(unsigned)(w0 >> 29))));
                    }
                    *q0 = (0x3f39b655u % ((unsigned)(short)(*q0 / ((unsigned)s0 | 1u)) | 1u));
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((short)i1 > (signed char)((unsigned)c1 % (*mp | 1u)))) goto L1;
                        if ((unsigned)((int)9u >= (int)a0[i0 & 3u])) continue;
                        break; (void)((unsigned)d0);
                        break; (void)((unsigned)((unsigned)(short)(unsigned)((short)(unsigned)c0 > (signed char)2u) || i1));
                        u3 = (0x20363733u & a0[i0 & 3u]);
                    } while (i1++ < 7u && p1);
                } while (i0++ < 6u && (unsigned)((int)fuel >= (int)(unsigned)(g0 && u3)));
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)l0 / (v0 | 1u)), ((unsigned)x0 ^ a0[u1 & 3u]), -(0x32ca7a0u & (unsigned)(unsigned char)(unsigned)((int)0x390ac6f2u >= (int)0x7fffffffu))); }
            if (((p2 ^ p1) * garr[i1 & 7u])) goto done;
            m0 ^= 3u;
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                *q0 += ((0x385079c0u % (p2 | 1u)) / ((unsigned)b0 | 1u));
                r0.x = i2;
                if ((unsigned)(0x80000000u || 1u)) break;
                if ((unsigned)b0) {
                    if (u3) break;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((garr[i1 & 7u] / (0x3d2bbc3au | 1u)), i2, ((fuel - g1) ^ (unsigned)(w0 >> 29))); }
                    *mp = ((unsigned)(0u == 0x7fffffffu) ^ r0.x);
                    b0 = (g1 * (0x80000000u & (unsigned)w0)) != 0u;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(m0 == u0) >> ((unsigned)h0 & 31u)), 0x9f74a3b8u, (unsigned)((unsigned)s0 || (a0[i0 & 3u] ^ 0x9c44ca40u))); }
                    if (2u) break;
                } else {
                    if ((unsigned)(signed char)(-(unsigned)(a0[u1 & 3u] || (unsigned)b0) | 4u)) break;
                    c0 = (unsigned char)0x31426c37u;
                    *mp = (unsigned)(~(unsigned)(0xffffffffu && 0x49d0f6bbu) || (unsigned)(0xffffffffu && (unsigned)((int)g1 < (int)0x28cc66e9u)));
                    u2 = u2 * 0x9e3779b1u + (unsigned)((int)g1 >= (int)(unsigned)((short)8u > (signed char)a0[i0 & 3u]));
                }
                if ((unsigned)c0) break;
            }
            garr[0x100bddffu & 7u] = 5u;
        }
        if (~(0x43fcd89fu & i2)) break;
    }
    if (u3 == 7u) return (u1 ^ (unsigned)((unsigned)w0 == (unsigned)s1));
    b0 = (-(0xa9c5779cu << ((garr[u2 & 7u] / (u1 | 1u)) & 31u)) | (unsigned)((short)0xb8c98525u > (signed char)u3)) != 0u;
    c0 = (unsigned char)(unsigned)((short)(((unsigned)e0 - (unsigned)l0) / ((unsigned)((int)0xe9f57ce2u >= (int)0x7fffffffu) | 1u)) > (signed char)3u);
    while (i0++ < 3u && (unsigned)(signed char)(unsigned)(u3 || (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
        i2 = (v0 - (unsigned)((p0 & r0.y) == ((unsigned)w0 * 0x80000000u))) & 15u;
        *mp = (unsigned)((int)g1 < (int)((unsigned)h0 & (*q0 + (0x33c4f75au % (r0.x | 1u)))));
        u0 += (unsigned)(p1 && (unsigned)(0x4d6a57a2u && 0x5dca90a9u));
        while (i1++ < 3u && 0x7fffffffu) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)1u << (p2 & 63u);
            u1 += ((unsigned)d0 ? i1 : ((unsigned)s0 << (((unsigned)l0 + (unsigned)d0) & 31u)));
            break; (void)(~(unsigned)(v0 < garr[i1 & 7u]));
            while (i2++ < 2u && (unsigned)((short)r0.y > (signed char)i0)) { if (--fuel == 0u) goto done;
                h0 = (short)(unsigned)(p0 == (unsigned)((int)(unsigned)c0 < (int)(unsigned)(p1 || 0x685950e3u)));
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)h0 >> ((unsigned)(0x73e0992u || (unsigned)e0) & 31u)), ((m0 >> (p1 & 31u)) / (garr[i1 & 7u] | 1u)), (unsigned)s1); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)w0, (unsigned)((unsigned)((short)garr[i1 & 7u] > (signed char)a0[u1 & 3u]) < fuel), (r0.x >> (0x6c12824au & 31u))); }
                } while (i0++ < 3u && (0x80000000u & (0xffffffffu * r0.y)));
                switch ((unsigned)!(unsigned)((int)0x7fffffffu < (int)i1) & 7u) {
                    { unsigned t9; double z9; if ((((unsigned)h1 << (0xd21f39ebu & 31u))) & 1u) { t9 = (unsigned)(unsigned char)(3u / (p1 | 1u)); z9 = (double)((((a0[i0 & 3u] & 0x209e6d5bu) / (0xffffffffu | 1u))) & 255u); } if ((((unsigned)h1 << (0xd21f39ebu & 31u))) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                        w0 = w0 * 6364136223846793005ull + ((unsigned)(w0 >> 29) ^ (((0xcd397f26u >> ((unsigned)b0 & 31u)) & i1) / (fuel | 1u)));
                        v0 = ((unsigned)d0 ? ((unsigned)((int)i0 >= (int)1u) | (unsigned)h1) : u2);
                        garr[0xe95219feu & 7u] = ((unsigned)(unsigned char)((unsigned)h1 ^ 0x7fffffffu) >> (((v0 >> (7u & 31u)) & 7u) & 31u));
                    }
                    w0 = w0 * 6364136223846793005ull + (((unsigned)(signed char)(unsigned)((unsigned)x0 && (unsigned)h1) - g0) - v0);
                    f0 = f0 * 0.5f + (float)((v0 & (unsigned)(w0 >> 29)) & 255u);
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(x0 >> 70), (unsigned)c1, 0x10000u); }
                if ((unsigned)l0) break;
                { unsigned t10; double z10; if ((u0) & 1u) { t10 = ((unsigned)(signed char)(unsigned)((unsigned)s1 && g0) | (unsigned)h1); z10 = (double)((((unsigned)f0 & i0)) & 255u); } if ((u0) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
                    if ((g1 - u0)) break;
                    *mp = (unsigned)((int)(unsigned)b0 < (int)(unsigned)x0);
                    c1 = (signed char)(unsigned)((int)m0 < (int)(unsigned)(u0 && p2));
                }
            }
            do { if (--fuel == 0u) goto done;
                u2 += (2u - r0.y);
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)8u < (int)((unsigned)x0 ^ (unsigned)h0));
                switch (0x67edb50cu & 7u) {
                    if ((unsigned)(signed char)(unsigned)(0x7fffffffu || ~(unsigned)((int)garr[u2 & 7u] < (int)0x7fffffffu))) goto L1;
                    switch ((((unsigned)l0 >> (0xae9c735u & 31u)) >> (r0.x & 31u)) & 7u) {
                        continue; (void)((unsigned)(0x80000000u < (unsigned)((unsigned)s0 < (unsigned)(w0 >> 29))));
                        v0 = ((unsigned)((int)(m0 >> (a0[i0 & 3u] & 31u)) < (int)(unsigned)x0) | fuel);
                        s0 = (int)(((unsigned)c0 * (unsigned)((int)0x7fffffffu < (int)v0)) << ((unsigned)(unsigned char)(*mp % (v0 | 1u)) & 31u));
                        break; (void)(a0[u1 & 3u]);
                        s0 = (int)((u1 * ~((unsigned)s0 & 0x7fffffffu)) / ((unsigned)c0 | 1u));
                    }
                }
                u2 = (unsigned)(signed char)((unsigned)(u0 || p2) + (unsigned)((unsigned)((unsigned)d0 && (unsigned)b0) == 7u));
            } while (i2++ < 2u && (0x244378aau * i0));
        }
        f0 = f0 * 0.5f + (float)((~(unsigned)((int)2u < (int)(unsigned)f0) | (unsigned)((int)0xffffffffu >= (int)(unsigned)h1)) & 255u);
    }
    while ((unsigned)(short)((u0 + (unsigned)h1) * (unsigned)w0)) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)l0 ^ (unsigned)((unsigned)b0 < 8u)));
        break; (void)((unsigned)(x0 >> 70));
        if (((unsigned)e0 & (unsigned)d0)) {
            u3 ^= (unsigned)!(unsigned)((short)(unsigned)h0 > (signed char)(unsigned)((0xb823a567u + (unsigned)s1) < r0.x));
            h0 = (short)u1;
            w0 ^= (unsigned long long)(unsigned)((short)0x7fffffffu > (signed char)fuel) << (((unsigned)b0 & i2) & 63u);
            while (i1++ < 6u && (unsigned)((short)0x74887b32u > (signed char)u0)) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((0x664ae12au ^ g1) & 1023u);
            }
        } else {
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)d0, (unsigned)((int)p0 >= (int)(unsigned)((int)0xfae1933fu < (int)r0.x)), (p2 | (unsigned)(short)(u1 + 0xd52fcd45u))); }
                l0 = (long)((unsigned long)l0 + (u0 % (0xffffffffu | 1u)));
            }
            s1 = (int)((unsigned)s1 + ((unsigned)h0 ? (unsigned)(*q0 && 0x80000000u) : (*mp ^ p0)));
            while (i1++ < 2u && (p0 ^ (garr[u2 & 7u] ^ i1))) { if (--fuel == 0u) goto done;
                if ((unsigned)h0) goto L4;
                if (budget != 0u) { budget -= 1u; u1 = fn0(((4u >> (0x80000000u & 31u)) * (unsigned)(w0 >> 29)), (unsigned)((unsigned)((int)(unsigned)h0 < (int)5u) == (unsigned)e0), (unsigned)f0); }
                a0[(u2 ^ (unsigned)c1) & 3u] = ((r0.y / (i2 | 1u)) % (-(unsigned)((short)((unsigned)w0 << ((unsigned)b0 & 31u)) > (signed char)(unsigned)(x0 >> 70)) | 1u));
                if (fuel < 8u) return (unsigned)(~((unsigned)(signed char)(g0 + r0.y) / (0x6435e75bu | 1u)) < (8u >> (r0.y & 31u)));
            }
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)f0 < (((unsigned)(w0 >> 29) ^ 5u) + 0xf2759166u));
        do { if (--fuel == 0u) goto done;
            if (0x80000000u) break;
            break; (void)(v0);
            b0 = ((unsigned)(*mp == (unsigned)(3u && (*q0 | (unsigned)s0))) >> (u0 & 31u)) != 0u;
            u1 = u1 * 0x9e3779b1u + (unsigned)(((g1 >> (2u & 31u)) ^ p1) == u1);
            if ((r0.y + i1)) break;
        } while (i1++ < 7u && (unsigned)((unsigned)(x0 >> 70) < g1));
        r0.x = (unsigned)(u0 && ((unsigned)(g0 || p1) << ((unsigned)s0 & 31u)));
    }
    e0 = e0 * 0.5L + (long double)((unsigned)(0x80000000u < (unsigned)((int)0xb25b7c2au < (int)u3)) & 1023u);
    if ((unsigned)(w0 >> 29)) goto L0;
    d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)((int)r0.y < (int)0x10000u) > (signed char)(9u - 0x4cd9c519u)) & 1023u);
    r0.x = ((unsigned)s0 * ~(unsigned)(i2 == (unsigned)(x0 >> 70)));
    if (budget != 0u) { budget -= 1u; u2 = fn0(i0, (0x27c6256eu >> ((0x4db07458u ^ 0xe4e178fdu) & 31u)), (((unsigned)d0 | (unsigned)d0) % (a0[i0 & 3u] | 1u))); }
    i0 = (unsigned)((int)m0 < (int)*q0) & 15u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    e0 = e0 * 0.5L + (long double)((p1 / (((unsigned)((short)0x80000000u > (signed char)g0) << (0x10000u & 31u)) | 1u)) & 1023u);
    g0 = (unsigned)((unsigned)(x0 >> 70) && (i0 >> (((unsigned)((int)(unsigned)s0 < (int)a0[u1 & 3u]) >> ((unsigned)w0 & 31u)) & 31u)));
    switch ((unsigned)d0 & 7u) {
        u3 ^= (unsigned)((short)u0 > (signed char)((unsigned)h1 ? v0 : 0x56de2544u));
    }
    h0 = (short)3u;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)garr[u2 & 7u])) break;
        c0 = (unsigned char)(a0[i0 & 3u] ? (unsigned)(r0.y || 0x98002811u) : (unsigned)((int)p2 < (int)a0[u1 & 3u]));
        while (((unsigned)(w0 >> 29) ^ 2u)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1(0x10000u, ((unsigned)s0 ? 3u : *q0), ((unsigned)x0 % (0xe6147c32u | 1u))); }
            m0 ^= (unsigned)((0x7fffffffu / (0x5ba3b428u | 1u)) && (0x7fffffffu << ((unsigned)((int)u0 < (int)0x7fffffffu) & 31u)));
            w0 ^= (unsigned long long)(unsigned)(0x10000u == 0xde7f185eu) << ((1u - 0x7fffffffu) & 63u);
            if (u1) break;
            b0 = ((5u - (i1 ^ 3u)) << (4u & 31u)) != 0u;
            for (;;) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + 0x10000u);
                L0: if (--fuel == 0u) goto done;
                garr[g0 & 7u] = 0x3a347e6au;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(w0 >> 29) || (unsigned)(0x80000000u || m0)), 0x7969b5f6u, (unsigned)(i1 == (unsigned)((unsigned)c1 < (unsigned)e0))); }
                v0 = a0[i0 & 3u];
                u1 = u1 * 0x9e3779b1u + (unsigned)(((unsigned)(x0 >> 70) - (unsigned)s0) < (unsigned)((short)(unsigned)f0 > (signed char)(0x80000000u ^ 0x7fffffffu)));
            }
        }
    }
    if (p0) goto L0;
    w0 ^= (unsigned long long)(unsigned)((int)(unsigned)w0 >= (int)(unsigned)s0) << ((((5u / (r0.x | 1u)) | (unsigned)(m0 || (unsigned)(w0 >> 29))) & a0[u1 & 3u]) & 63u);
    if (budget != 0u) { budget -= 1u; u0 = fn1(p1, (i2 & (unsigned)l0), ((unsigned)s1 / ((p0 << (r0.x & 31u)) | 1u))); }
    w0 ^= (unsigned long long)(unsigned)((unsigned)(w0 >> 29) && 8u) << ((u1 & (unsigned)((int)(p0 << ((0x80000000u << ((unsigned)h0 & 31u)) & 31u)) >= (int)p2)) & 63u);
    if (fuel) goto L0;
    goto done;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (p0 & 7u) {
            m0 ^= 7u;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(u0 ? 0xffffffffu : ((unsigned)s0 + p0));
            }
        }
        do { if (--fuel == 0u) goto done;
            *q0 += (9u & ((p1 * 0xba063770u) ^ (unsigned)d0));
            if ((unsigned)l0) {
                g0 = ((unsigned)((int)m0 >= (int)a0[u1 & 3u]) & -(~(unsigned)(u1 < garr[u2 & 7u]) - 0x5900d478u));
                if ((0x10000u % (i0 | 1u))) break;
            } else {
                goto L3;
                if (i1) goto done;
                L1: if (--fuel == 0u) goto done;
            }
            w0 = w0 * 6364136223846793005ull + (u3 + 0x623e997u);
        } while (i1++ < 2u && (unsigned)((unsigned)(w0 >> 29) && (unsigned)(0xabbaffb9u && (unsigned)s1)));
        s0 = (int)u3;
        if (2u) break;
        *mp = (unsigned)(signed char)(unsigned)(1u < (unsigned)(g1 < 5u));
    }
    { unsigned t0; double z0; if (((0xffffffffu >> ((unsigned)w0 & 31u))) & 1u) { t0 = (unsigned)(signed char)((unsigned)f0 ^ i2); z0 = (double)(((unsigned)(x0 >> 70)) & 255u); } if (((0xffffffffu >> ((unsigned)w0 & 31u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(-(((unsigned)e0 >> (i2 & 31u)) / (0u | 1u)));
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(-(unsigned)((int)(unsigned)c1 < (int)v0), *mp, (v0 >> (0x10000u & 31u))); }
                if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)((short)r0.x > (signed char)(unsigned)c1) ^ 6u), (unsigned)((unsigned)!((unsigned)h1 * u2) || 0x10000u), v0); }
                while (i2++ < 2u && i1) { if (--fuel == 0u) goto done;
                    while (i0++ < 6u && (unsigned)(9u && (unsigned)((int)p1 >= (int)p1))) { if (--fuel == 0u) goto done;
                        L2: if (--fuel == 0u) goto done;
                        u3 = u3 * 0x9e3779b1u + (unsigned)((2u * garr[i1 & 7u]) || r0.x);
                        if ((0xa5127abau % (a0[i0 & 3u] | 1u))) continue;
                        break; (void)((unsigned)((int)(unsigned)s0 >= (int)0x10000u));
                        u0 += ((unsigned)h0 ^ ((unsigned)c1 << ((v0 ? (unsigned)s0 : p2) & 31u)));
                    }
                    w0 ^= (unsigned long long)(unsigned)f0 << (((unsigned)(a0[i0 & 3u] < g0) / (v0 | 1u)) & 63u);
                }
                switch ((2u ? i0 : 0xffffffffu) & 7u) {
                    if ((0u & *q0)) continue;
                    if (0xffffffffu) break;
                    case 4u: ;
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)s0, 0xc001d72au, a0[i0 & 3u]); }
                        if (budget != 0u) { budget -= 1u; u0 = fn1((0xc04e28c4u >> (m0 & 31u)), (unsigned)((short)(unsigned)(signed char)(0x91de5a2au | u3) > (signed char)u3), ((5u * (unsigned)h0) - (unsigned)e0)); }
                        *q0 += (unsigned)((unsigned)b0 && (garr[u2 & 7u] ^ u0));
                    } while (i2++ < 5u && (((unsigned)d0 - (unsigned)f0) & 0x80000000u));
                    c0 = (unsigned char)((unsigned)((unsigned)(signed char)(i0 / (fuel | 1u)) || 0xffffffffu) - i1);
                    continue; (void)((unsigned)(x0 >> 70));
                }
                a0[((unsigned)c1 * (unsigned)(x0 >> 70)) & 3u] = ((g1 << (fuel & 31u)) >> ((unsigned)((short)(i0 >> ((unsigned)w0 & 31u)) > (signed char)(unsigned)s0) & 31u));
            }
            c0 = (unsigned char)(unsigned)(short)(unsigned)((1u >> (g0 & 31u)) || (unsigned)b0);
            u0 += u2;
            r0.x = (unsigned)((unsigned)w0 == (unsigned)((int)(0x10000u ? 0x574753c4u : 0x2b19f25du) < (int)(unsigned)b0));
            if ((0x7fffffffu + (unsigned)d0)) goto L2;
        }
        if ((unsigned)f0) goto L0;
        while (i0) { if (--fuel == 0u) goto done;
            switch ((unsigned)!(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)((unsigned)(x0 >> 70) < garr[i1 & 7u])) & 7u) {
                a0[((unsigned)b0 & garr[i1 & 7u]) & 3u] = 6u;
                u1 = (unsigned)((int)a0[u1 & 3u] < (int)(0x943a64ecu | (0xb9fba50au & 0xaa7ac2e7u)));
            }
            c1 = (signed char)((unsigned)c1 ^ garr[u2 & 7u]);
            f0 = f0 * 0.5f + (float)(((~(0u % ((unsigned)b0 | 1u)) % ((unsigned)h0 | 1u)) - 3u) & 255u);
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((1u - 0x353462e6u) % (i1 | 1u))) break;
                if (u3 == 7u) return (unsigned)((short)0x74a15117u > (signed char)(p1 ^ g1));
                switch (v0 & 7u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn1(g0, 0x905ec2a3u, garr[u2 & 7u]); }
                }
                break; (void)((unsigned)((unsigned)h1 < (unsigned)(u0 < garr[i1 & 7u])));
            }
            x0 = x0 * 0x100000001b3ull + 0x165ff5f4u;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0(garr[u2 & 7u], (unsigned)((short)*mp > (signed char)g1), 0xddabc3dfu); }
        h0 = (short)i0;
    }
    s0 = (int)((unsigned)(unsigned char)(0x10000u >> ((unsigned)((int)m0 >= (int)(0x80000000u ^ (unsigned)f0)) & 31u)) + 0x49fc8238u);
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        L3: if (--fuel == 0u) goto done;
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)l0 < (int)0xf255acb5u);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)(unsigned)b0;
        if ((unsigned)(short)((unsigned)((int)(unsigned)h0 >= (int)0x310151adu) % ((unsigned)e0 | 1u))) break;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1(r0.y, g1, (unsigned)((r0.y % (p2 | 1u)) && (unsigned)s1)); }
    g1 += (*mp | fuel);
    if ((fuel * 0x10000u)) {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (u2) {
                v0 = (unsigned)(m0 < (unsigned)w0);
            }
        }
        i2 = (unsigned)((p2 + (unsigned)s1) && ((unsigned)(g1 < 0xffffffffu) >> (u3 & 31u))) & 15u;
    }
    v0 = 0x80000000u;
    goto L2;
    if ((0xaaee52bcu | (a0[i0 & 3u] % (u1 | 1u)))) {
        if ((i1 >> (u1 & 31u))) goto L1;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + ((unsigned)f0 & (unsigned)((short)*q0 > (signed char)(unsigned)(short)((unsigned)((int)(unsigned)d0 >= (int)fuel) - 0x330d1584u)));
            s0 = (int)9u;
            u3 += ((m0 * *mp) ^ i2);
            u0 ^= (*mp >> (4u & 31u));
        }
        if (5u) {
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)b0, (0x80000000u * 0x6386cfc4u), 0xffffffffu); }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)w0 >> ((g1 % (p1 | 1u)) & 31u)), g1, 0x90e7783u); }
    } else {
        u0 += ((g0 << (*mp & 31u)) + (unsigned)(r0.y || ((unsigned)s1 + (unsigned)s0)));
        s1 = (int)((unsigned)s1 + p0);
    }
    do { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)c1 & 1023u);
        L4: if (--fuel == 0u) goto done;
    } while (i0++ < 2u && (garr[i1 & 7u] << ((unsigned)(0x6dc9a69u || (unsigned)f0) & 31u)));
    if ((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)((int)p0 >= (int)(unsigned)w0))) goto L3;
    if ((unsigned)((int)a0[i0 & 3u] < (int)0x584d5162u)) {
        if ((unsigned)(unsigned char)(p1 & (9u * v0))) {
            goto L0;
            garr[((unsigned)s1 - *mp) & 7u] = ((0x17d2bea7u << ((0xffffffffu % (garr[u2 & 7u] | 1u)) & 31u)) | (unsigned)s0);
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)c0 ^ u1), (0xffffffffu ^ (unsigned)s0), (0xffffffffu * 0xd684b293u)); }
        } else {
            if (u3 == 7u) return (i2 << (p2 & 31u));
        }
        goto L0;
        goto done;
        r0.y ^= (unsigned)!(0x1d7317bau * (unsigned)c0);
        if (((unsigned)!(0x10000u | (unsigned)h1) & 0xd9451864u)) goto L2;
        if ((9u / (*mp | 1u))) {
            if ((unsigned)(short)(0x1157f933u * g0)) goto L4;
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)((unsigned)f0 || (0x7fffffffu * ((0x7fffffffu % (u1 | 1u)) >> (fuel & 31u))));
                if (*q0) continue;
                r0.y ^= (unsigned)((int)u0 >= (int)~(unsigned)((unsigned)h0 == 0x7fffffffu));
                i1 = (unsigned)((unsigned)h1 < u1) & 15u;
                if (((unsigned)c1 << (0x80000000u & 31u))) break;
            }
            c1 = (signed char)(0xfc4684c0u & (u2 - (unsigned)s0));
            if (p2) goto L4;
            w0 ^= (unsigned long long)u2 << ((r0.x + (unsigned)(signed char)(((unsigned)x0 & (unsigned)b0) >> (r0.x & 31u))) & 63u);
            if (u3 == 7u) return (unsigned)(((unsigned)e0 * i0) || (unsigned)(garr[u2 & 7u] || (unsigned)f0));
        } else {
            while (i0++ < 5u && (unsigned)((short)(0x10000u & (unsigned)h1) > (signed char)(unsigned)x0)) { if (--fuel == 0u) goto done;
                if ((i1 << (5u & 31u))) break;
                u1 = (unsigned)s1;
                s1 = (int)((unsigned)s1 + (unsigned)b0);
                if ((m0 | p0)) continue;
                r0.y ^= (unsigned)((short)(((unsigned)l0 ^ 0x10000u) >> (*q0 & 31u)) > (signed char)*mp);
            }
        }
    } else {
        s0 = (int)6u;
        do { if (--fuel == 0u) goto done;
            i1 = (unsigned)(w0 >> 29) & 15u;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)e0, (0xd440b428u >> (p2 & 31u)), ((fuel + 0xa03afe7au) * 4u)); }
            r0.x = fuel;
            w0 = w0 * 6364136223846793005ull + u2;
        } while (i0++ < 6u && (unsigned)((int)6u < (int)i1));
        q0 = &garr[((unsigned)(w0 >> 29) >> ((unsigned)l0 & 31u)) & 7u];
        if (((unsigned)d0 * (unsigned)(u0 < (unsigned)c1))) {
            if ((garr[i1 & 7u] | garr[i1 & 7u])) goto L1;
            if (a0[u1 & 3u]) goto L2;
            if ((unsigned)((garr[u2 & 7u] | 8u) < *mp)) goto done;
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((a0[u1 & 3u] % ((unsigned)f0 | 1u))) goto L3;
                continue; (void)((unsigned)x0);
                if ((0x7fffffffu * r0.x)) break;
            }
            if (g1) goto L4;
        } else {
            u1 += (~(0xe69ea895u ^ (*mp + 1u)) ^ (u3 | (unsigned)d0));
        }
    }
    switch ((unsigned)(x0 >> 70) & 7u) {
        h1 = (unsigned short)(h1 + (0xffffffffu ^ -(0x7fffffffu | 0xffffffffu)));
        c0 = (unsigned char)((unsigned)(w0 >> 29) ? ~(g0 << (garr[u2 & 7u] & 31u)) : 0x7fffffffu);
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)((short)6u > (signed char)(unsigned)e0);
            m0 ^= (u0 * (unsigned)b0);
            case 2u: ;
            do { if (--fuel == 0u) goto done;
                case 1u: ;
                q0 = &garr[(g0 * (0x7fffffffu << (((unsigned)s0 | garr[i1 & 7u]) & 31u))) & 7u];
                u2 ^= (unsigned)(g0 || ((unsigned)((unsigned)w0 == 0x8f25e108u) * (unsigned)((int)r0.x >= (int)(unsigned)c1)));
                if (budget != 0u) { budget -= 1u; u1 = fn0((g0 / (*mp | 1u)), (unsigned)((unsigned)(u2 < (unsigned)d0) == i0), (unsigned)(short)(1u ^ r0.y)); }
                { unsigned t1; double z1; if (((0x73141abeu << ((0x7fffffffu | garr[i1 & 7u]) & 31u))) & 1u) { t1 = (unsigned)(unsigned char)(unsigned)(a0[u1 & 3u] == 0xffffffffu); z1 = (double)(((0x10000u / (u0 | 1u))) & 255u); } if (((0x73141abeu << ((0x7fffffffu | garr[i1 & 7u]) & 31u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    if ((garr[i1 & 7u] >> (0x7fffffffu & 31u))) goto L0;
                }
            } while (i1++ < 6u && ((unsigned)l0 % (u3 | 1u)));
        }
    }
    { unsigned t2; double z2; if ((((unsigned)h0 / ((unsigned)((int)(unsigned)c1 >= (int)fuel) | 1u))) & 1u) { t2 = (unsigned)s0; z2 = (double)((0x7fffffffu) & 255u); } if ((((unsigned)h0 / ((unsigned)((int)(unsigned)c1 >= (int)fuel) | 1u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        for (;;) { if (--fuel == 0u) goto done;
            h0 = (short)(((unsigned)(unsigned char)(unsigned)((unsigned)h0 || g0) + a0[u1 & 3u]) ^ (unsigned)(w0 >> 29));
            if (budget != 0u) { budget -= 1u; u1 = fn0(((garr[i1 & 7u] + 0x38696990u) & (unsigned)s1), (v0 | 0x7fffffffu), 6u); }
            w0 ^= (unsigned long long)(6u << (0xffffffffu & 31u)) << ((unsigned)(unsigned char)((0x7fffffffu | 0x80000000u) << ((unsigned)(unsigned char)((unsigned)e0 << (i0 & 31u)) & 31u)) & 63u);
            if (((unsigned)c0 - (unsigned)s0)) break;
            if (budget != 0u) { budget -= 1u; u3 = fn1((0xd7381c30u - u1), garr[i1 & 7u], ((unsigned)s0 & 6u)); }
            if ((u2 ^ (unsigned)f0)) continue;
        }
        if ((unsigned)((unsigned)(u2 == 0x7fffffffu) < m0)) goto L0;
        goto L1;
    }
    goto L4;
    c0 = (unsigned char)(a0[u1 & 3u] | (g1 + (unsigned)h1));
    *q0 = (unsigned)(-((unsigned)(x0 >> 70) ? 6u : g0) < (a0[i0 & 3u] + a0[i0 & 3u]));
    if ((unsigned)h1) goto L1;
    switch ((i2 / (((unsigned)h0 & 0xe0a0c594u) | 1u)) & 7u) {
        a0[5u & 3u] = r0.y;
        do { if (--fuel == 0u) goto done;
            if (((unsigned)e0 >> (fuel & 31u))) goto L2;
            if ((unsigned)(short)(unsigned)((unsigned)e0 == (p1 << (v0 & 31u)))) goto L4;
            if ((unsigned)((int)(g0 | (unsigned)h0) < (int)g1)) break;
        } while (i0++ < 7u && ((unsigned)((int)(unsigned)w0 >= (int)(unsigned)b0) ^ fuel));
        case 7u: ;
        if (((unsigned)((unsigned)h1 && u0) / (0xe19a395bu | 1u))) break;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1(3u, (i1 & fuel), 0xf221ad6fu); }
    s0 = (int)(unsigned)(i2 < ~(~(0xc919c3f5u - (p2 & garr[u2 & 7u])) << ((unsigned)l0 & 31u)));
    if ((unsigned)((unsigned)l0 == (v0 >> (4u & 31u)))) goto L0;
    if (u1) goto L4;
    w0 ^= (unsigned long long)garr[u2 & 7u] << ((unsigned)((p2 ? u1 : r0.x) < 5u) & 63u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    garr[u2 & 7u] = ((unsigned)((short)(unsigned)((unsigned)w0 < i2) > (signed char)*q0) % (0x7fffffffu | 1u));
    if (u3 == 7u) return (unsigned)((int)7u >= (int)(7u % (p1 | 1u)));
    while ((unsigned)(v0 == (unsigned)h0)) { if (--fuel == 0u) goto done;
        if ((unsigned)(0x7fffffffu == (0x83be9e6cu - (unsigned)x0))) {
            if ((unsigned)(unsigned char)(unsigned)((unsigned)((int)*q0 < (int)(unsigned)l0) || garr[u2 & 7u])) continue;
        } else {
            if (u1) continue;
            f0 = f0 * 0.5f + (float)((g1 << ((unsigned)x0 & 31u)) & 255u);
            b0 = (unsigned)((unsigned)((m0 % ((unsigned)w0 | 1u)) == *q0) || p2) != 0u;
            { unsigned t0; double z0; if (((unsigned)l0) & 1u) { t0 = (0xffffffffu / (u1 | 1u)); z0 = (double)(((0xffffffffu | -(0x7fffffffu << (3u & 31u)))) & 255u); } if (((unsigned)l0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                if (budget != 0u) { budget -= 1u; u1 = fn2(~((unsigned)((short)0xcdf85eedu > (signed char)u3) | (unsigned)h0), (unsigned)((int)(0xc6746ac8u / ((unsigned)b0 | 1u)) >= (int)(unsigned)b0), (unsigned)((unsigned)f0 || 0x7fffffffu)); }
            }
        }
        d0 = d0 * 0.5 + (double)((unsigned)(signed char)(unsigned)((short)m0 > (signed char)a0[i0 & 3u]) & 1023u);
        switch ((unsigned)((int)0x10000u < (int)((unsigned)f0 * 7u)) & 7u) {
            do { if (--fuel == 0u) goto done;
                if ((p2 * (unsigned)!(v0 * 0u))) continue;
                *q0 += (unsigned)((int)(unsigned)c0 >= (int)(unsigned)!((unsigned)(short)(i0 / (5u | 1u)) + 8u));
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(x0 >> 70), (u0 - garr[u2 & 7u]), garr[i1 & 7u]); }
                do { if (--fuel == 0u) goto done;
                    c1 = (signed char)(unsigned)((short)u0 > (signed char)(unsigned)(signed char)(unsigned)((short)(p2 << (r0.x & 31u)) > (signed char)-(unsigned)(r0.x || m0)));
                } while (i2++ < 5u && *q0);
                f0 = f0 * 0.5f + (float)((unsigned)(0x31ddf95cu || (((unsigned)x0 & 5u) | m0)) & 255u);
            } while (i1++ < 7u && (unsigned)((unsigned)c0 < 0x80000000u));
        }
        break; (void)(g1);
        if ((unsigned)(i2 < (unsigned)(short)(unsigned)((short)*q0 > (signed char)0x80000000u))) {
            l0 = (long)((unsigned long)l0 + i2);
            while (i1++ < 4u && 0xffffffffu) { if (--fuel == 0u) goto done;
                i1 = (unsigned)((unsigned)((int)r0.x >= (int)g0) || (unsigned)((int)(unsigned)w0 >= (int)(m0 ^ i2))) & 15u;
                w0 = w0 * 6364136223846793005ull + 3u;
            }
            s0 = (int)(unsigned)(fuel < (0x80000000u ^ garr[u2 & 7u]));
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= *mp;
                { unsigned t1; double z1; if ((m0) & 1u) { t1 = ((unsigned)e0 * r0.x); z1 = (double)(((unsigned)(w0 >> 29)) & 255u); } if ((m0) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    h0 = (short)(a0[u1 & 3u] | ((unsigned)(w0 >> 29) ^ g0));
                    for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        *mp = ((unsigned)(u0 == (unsigned)((int)0xccf119a4u >= (int)(unsigned)x0)) + (unsigned)(w0 >> 29));
                        x0 = x0 * 0x100000001b3ull + (unsigned)(0x70353b59u == (0xc662f1cu / (0x80000000u | 1u)));
                        s0 = (int)(unsigned)((int)u0 >= (int)0x10000u);
                        m0 ^= ((unsigned)((int)(unsigned)(signed char)((unsigned)(short)((unsigned)b0 * 0x80000000u) - p2) < (int)(unsigned)e0) / (0xf95e399au | 1u));
                        u3 = u3 * 0x9e3779b1u + (unsigned)((g1 | ((0xffffffffu - 0x10000u) ^ 9u)) < 0x7fffffffu);
                    }
                    h0 = (short)g0;
                    u2 = 0x50022e82u;
                }
            }
            m0 ^= (0x6b6f85e6u | 0x80000000u);
            L0: if (--fuel == 0u) goto done;
        }
    }
    if (p0) {
        while (i0++ < 3u && 3u) { if (--fuel == 0u) goto done;
            u1 ^= (r0.x | (0xffffffffu * (unsigned)((*q0 << (m0 & 31u)) && *mp)));
            if (budget != 0u) { budget -= 1u; u0 = fn2(garr[i1 & 7u], ~((unsigned)(0x10000u && p2) % (9u | 1u)), (unsigned)(unsigned char)((unsigned)(a0[i0 & 3u] || 0x6f76f208u) >> (u2 & 31u))); }
        }
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)(garr[u2 & 7u] < (unsigned)h0)) {
                i2 = ((unsigned)s1 >> (r0.x & 31u)) & 15u;
                if (u3 == 7u) return (unsigned)(signed char)((unsigned)(x0 >> 70) - (unsigned)(unsigned char)(unsigned)(u1 < u3));
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(short)((unsigned)f0 & (unsigned)(fuel == 0x7f4b9636u)), (unsigned)d0, (unsigned)((unsigned)((int)(unsigned)(x0 >> 70) < (int)0x7fffffffu) < i2)); }
            }
            c0 = (unsigned char)0x80000000u;
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((r0.x >> (((unsigned)!((r0.x / (0xe05bd197u | 1u)) >> (3u & 31u)) << (3u & 31u)) & 31u)) & 1023u);
                L1: if (--fuel == 0u) goto done;
            }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(m0 || 0xf2b39d79u), *mp, (unsigned)((int)p1 >= (int)p0)); }
                if (((unsigned)(garr[u2 & 7u] == p2) >> (i0 & 31u))) break;
                L2: if (--fuel == 0u) goto done;
            } while (i1++ < 2u && (unsigned)((i1 & 0x37c59969u) && p0));
            if ((unsigned)s0) {
                if (3u) break;
                s0 = (int)r0.y;
            }
            break; (void)((unsigned)f0);
        }
    } else {
        if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)(p0 < p1) + u2), p1, (unsigned)(x0 >> 70)); }
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)c1, ((unsigned)x0 * (unsigned)((int)0xffffffffu < (int)(unsigned)l0)), ((0x10000u & (unsigned)f0) * i2)); }
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)h1, ((unsigned)(u0 < (unsigned)d0) * 7u), *q0); }
            v0 = (unsigned)((short)*q0 > (signed char)(unsigned)((m0 ? 0x80000000u : 0x6afb08eu) && p0));
            L3: if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                { unsigned t2; double z2; if (((unsigned)(p2 == ~(unsigned)((short)(unsigned)l0 > (signed char)*q0))) & 1u) { t2 = (unsigned)(r0.x < garr[u2 & 7u]); z2 = (double)(((unsigned)((int)u2 < (int)(unsigned)(3u < 0x7fffffffu))) & 255u); } if (((unsigned)(p2 == ~(unsigned)((short)(unsigned)l0 > (signed char)*q0))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    L4: if (--fuel == 0u) goto done;
                    if (fuel) break;
                    if (fuel < 8u) return (((unsigned)l0 / ((3u | i2) | 1u)) ^ 0u);
                    h1 = (unsigned short)(h1 + (0xcd18409fu / ((unsigned)d0 | 1u)));
                    if ((unsigned)w0) break;
                    l0 = (long)((unsigned long)l0 + r0.x);
                }
            } while (i1++ < 4u && ~((unsigned)((short)0u > (signed char)i1) + g1));
        } while (i0++ < 4u && (unsigned)h1);
        if (budget != 0u) { budget -= 1u; u2 = fn0((0xd81a6b6au / (0x70daca10u | 1u)), (u0 ? 0x3aaa27c3u : 0x6a34e81u), (unsigned)(short)((v0 / (6u | 1u)) & (unsigned)c1)); }
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[(0x80000000u | i0) & 3u] = (unsigned)(0x80000000u || fuel);
        if ((unsigned)(i1 && *mp)) break;
        h0 = (short)(unsigned)((unsigned)l0 || v0);
        h1 = (unsigned short)(h1 + (unsigned)(signed char)(unsigned)((int)garr[i1 & 7u] < (int)0xa10e0f59u));
        break; (void)((u3 + (unsigned)s1));
    }
    if ((unsigned)!(unsigned)((fuel / (p1 | 1u)) || 0xafeb30cu)) goto L2;
    h1 = (unsigned short)(h1 + ((unsigned)((int)(unsigned)w0 >= (int)0x479c26d4u) % ((unsigned)((short)u2 > (signed char)0x10000u) | 1u)));
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)(0x80000000u << (i2 & 31u)) >= (int)a0[u1 & 3u]), garr[u2 & 7u], 0x600ce6c2u); }
        s0 = (int)(unsigned)w0;
        g1 += p0;
    }
    if ((4u >> ((unsigned)(i0 && garr[i1 & 7u]) & 31u))) goto L0;
    h0 = (short)(0xd68f8929u + (unsigned)((unsigned)s0 == ~(unsigned)((unsigned)d0 == (unsigned)(short)(0x10000u / (0xe4a52c78u | 1u)))));
    q0 = &garr[(unsigned)((unsigned)((unsigned)(short)(unsigned)(1u && (unsigned)(x0 >> 70)) || (unsigned)h0) || (unsigned)d0) & 7u];
    switch (g1 & 7u) {
        r0.x = (unsigned)(((unsigned)f0 + (unsigned)h1) < (unsigned)((int)*q0 >= (int)0x4c70ca03u));
        goto L1;
        case 7u: ;
        d0 = d0 * 0.5 + (double)(((unsigned)h0 * (unsigned)((int)u2 < (int)(unsigned)h0)) & 1023u);
    }
    switch ((i1 % ((unsigned)(v0 && 6u) | 1u)) & 7u) {
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 5u: ;
            if (v0) {
                default: ;
                if (((unsigned)(fuel || (unsigned)s1) + (unsigned)w0)) {
                    d0 = d0 * 0.5 + (double)((unsigned)h1 & 1023u);
                    g1 += (unsigned)(3u || (unsigned)((short)g1 > (signed char)(unsigned)l0));
                }
            } else {
                if (budget != 0u) { budget -= 1u; u2 = fn2(u1, (unsigned)(v0 == 0x204a105eu), (1u | (3u % (p0 | 1u)))); }
                case 3u: ;
            }
        }
        *q0 += 0x80000000u;
    }
    goto L0;
    if (g0) goto L4;
    goto L3;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((g0 * (unsigned)f0)) {
            l0 = (long)((unsigned long)l0 + (m0 / ((unsigned)x0 | 1u)));
            goto L2;
            q0 = &garr[garr[u2 & 7u] & 7u];
            do { if (--fuel == 0u) goto done;
                continue; (void)(0x10000u);
                b0 = (unsigned)!(unsigned)((int)((unsigned)x0 + garr[u2 & 7u]) < (int)r0.y) != 0u;
                if (budget != 0u) { budget -= 1u; u1 = fn2((garr[u2 & 7u] + (unsigned)((unsigned)s1 < *q0)), (((unsigned)w0 << (garr[i1 & 7u] & 31u)) * i1), (unsigned)(unsigned char)((unsigned)f0 / (0xafd0668eu | 1u))); }
                if ((3u / ((6u & 0xde51155au) | 1u))) break;
                continue; (void)(((unsigned)(0x7fffffffu || (unsigned)s1) % (0x7fffffffu | 1u)));
            } while (i1++ < 4u && (unsigned)((short)(i2 << (i2 & 31u)) > (signed char)(unsigned)w0));
            if ((g0 - ((unsigned)w0 >> ((unsigned)h1 & 31u)))) {
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)((unsigned)h1 << (r0.y & 31u)) << ((4u + (u3 ^ *q0)) & 63u);
                    continue; (void)(u1);
                }
                do { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((((unsigned)s1 >> ((unsigned)(w0 >> 29) & 31u)) | ((unsigned)(u3 == 5u) | (unsigned)c1)) & 255u);
                } while (i1++ < 4u && ((unsigned)h0 >> (p1 & 31u)));
                if ((unsigned)(g1 || r0.y)) goto done;
                { unsigned t3; double z3; if (((unsigned)((int)u1 >= (int)(unsigned)f0)) & 1u) { t3 = (unsigned)(short)(0x7fffffffu ^ v0); z3 = (double)((((unsigned)d0 | (i2 << ((unsigned)h1 & 31u)))) & 255u); } if (((unsigned)((int)u1 >= (int)(unsigned)f0)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                    if ((4u * ((unsigned)w0 & 4u))) break;
                    q0 = &garr[0xffffffffu & 7u];
                    s0 = (int)((garr[u2 & 7u] ? p2 : 0xffffffffu) ^ (unsigned)(garr[i1 & 7u] < (unsigned)w0));
                    u3 += ((unsigned)x0 - r0.y);
                    if ((unsigned)(unsigned char)(unsigned)(6u == g0)) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)(unsigned)e0 > (signed char)-(0xffffffffu % (g1 | 1u))), u3, (unsigned)(signed char)(unsigned)(8u && 0x3d387774u)); }
                }
                while (i1++ < 4u && 4u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)d0);
                    e0 = e0 * 0.5L + (long double)(((unsigned)(0x42f4597u == garr[i1 & 7u]) * (unsigned)s0) & 1023u);
                    l0 = (long)((unsigned long)l0 + ((9u * 0x7fffffffu) | ((unsigned)(r0.x && i1) % (*q0 | 1u))));
                }
            }
            u3 = u3 * 0x9e3779b1u + (0x7346ccb8u >> (((unsigned)h0 ? i1 : 0x85ee409fu) & 31u));
        }
        if (i0) break;
        u0 = u0 * 0x9e3779b1u + ((unsigned)w0 - (unsigned)s1);
        while (i1++ < 5u && ((1u / (u0 | 1u)) >> ((unsigned)w0 & 31u))) { if (--fuel == 0u) goto done;
            { unsigned t4; double z4; if ((((unsigned)f0 >> ((unsigned)(x0 >> 70) & 31u))) & 1u) { t4 = (unsigned)((unsigned)f0 || u3); z4 = (double)(((-(0x10000u & 0x80000000u) >> ((unsigned)x0 & 31u))) & 255u); } if ((((unsigned)f0 >> ((unsigned)(x0 >> 70) & 31u))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                if ((unsigned)(unsigned char)(unsigned)(((unsigned)s0 * (unsigned)e0) && (unsigned)s1)) {
                    b0 = ((unsigned)c0 ? garr[i1 & 7u] : p1) != 0u;
                    if (budget != 0u) { budget -= 1u; u3 = fn2(p0, (unsigned)(garr[u2 & 7u] && u0), ((unsigned)s1 * (unsigned)(w0 >> 29))); }
                    b0 = (unsigned)((unsigned)h0 == (0xffffffffu ? fuel : 0x2f4ce76eu)) != 0u;
                }
                u3 ^= (8u & (unsigned)((r0.x - (unsigned)s1) < (unsigned)h1));
                l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(unsigned)((short)fuel > (signed char)(unsigned)(0x3f4aaec4u < (garr[u2 & 7u] - p2))));
                if ((unsigned)((unsigned)e0 < (unsigned)(p1 == 9u))) continue;
            }
            b0 = (unsigned)(((0x7fffffffu << (0x80000000u & 31u)) / ((unsigned)(2u == g1) | 1u)) == (unsigned)b0) != 0u;
        }
    }
    if ((unsigned)b0) {
        do { if (--fuel == 0u) goto done;
            g1 += ((unsigned)c1 | (unsigned)(signed char)(((unsigned)(short)(*mp - (unsigned)h1) + 6u) >> (0x7fffffffu & 31u)));
            break; (void)(((unsigned)h1 >> (p2 & 31u)));
            continue; (void)(-(unsigned)((int)(0x7fffffffu - (unsigned)s0) < (int)0x80000000u));
            u0 = (unsigned)(garr[u2 & 7u] && ((fuel % (4u | 1u)) * 0xe7e220bcu));
            break; (void)(~(p0 ^ 0x207de318u));
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                *mp = (unsigned)(u3 < (*mp - (unsigned)(unsigned char)(p0 << ((unsigned)((int)a0[i0 & 3u] < (int)v0) & 31u))));
                if (0x80000000u) break;
                a0[0xffffffffu & 3u] = (unsigned)(signed char)((unsigned)h1 & (unsigned)(short)(unsigned)(0x10000u == p1));
                if (((unsigned)s0 + (unsigned)(0xbb8470e5u || (unsigned)c1))) break;
                do { if (--fuel == 0u) goto done;
                    garr[(unsigned)(signed char)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)p2) & 7u] = ((unsigned)(g0 && i1) & (unsigned)b0);
                    break; (void)((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)(unsigned char)(unsigned)(0x80000000u && m0)));
                    w0 ^= (unsigned long long)(unsigned)(r0.x || 2u) << (p1 & 63u);
                    u3 = u3 * 0x9e3779b1u + (unsigned)h1;
                    c1 = (signed char)((7u * (unsigned)c0) | fuel);
                } while (i2++ < 5u && ~(r0.x | (a0[u1 & 3u] ^ v0)));
                if (budget != 0u) { budget -= 1u; u1 = fn0((u0 & (unsigned)(7u == 0xd3ad0797u)), (unsigned)((int)i0 >= (int)(unsigned)((int)r0.x < (int)r0.x)), (*q0 * (0x9d8c21b9u >> (5u & 31u)))); }
            }
        } while (i0++ < 3u && (unsigned)(m0 || 0xffffffffu));
        if ((a0[u1 & 3u] ? m0 : r0.x)) goto L4;
        if (budget != 0u) { budget -= 1u; u2 = fn0(0x7fffffffu, (unsigned)(4u == g0), r0.y); }
        h0 = (short)(unsigned)!(unsigned)((~(0x7fffffffu & 0xffffffffu) ? 0x10000u : (unsigned)d0) && g1);
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)((unsigned)l0 / (0x31478b9du | 1u)), ((unsigned)(signed char)(unsigned)(u0 && i1) ^ i0), (unsigned)(i2 && (0xffffffffu * u0))); }
        v0 = 0xa7514529u;
        goto L1;
        if ((unsigned)(unsigned char)(unsigned)((int)fuel >= (int)(unsigned)((int)a0[u1 & 3u] >= (int)*mp))) break;
        if ((p0 ^ (unsigned)x0)) break;
        q0 = &garr[(unsigned)((int)p2 >= (int)(unsigned)c0) & 7u];
    }
    garr[a0[u1 & 3u] & 7u] = g1;
    if ((unsigned)((garr[u2 & 7u] * p1) == m0)) goto L3;
    if ((unsigned)(u0 || r0.x)) {
        v0 = i2;
        if ((0xffffffffu * (unsigned)b0)) goto L1;
        while ((g0 | garr[u2 & 7u])) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)8u << (i2 & 63u);
            break; (void)((((unsigned)c1 << (0x7fffffffu & 31u)) % (u3 | 1u)));
        }
    }
    s1 = (int)((unsigned)s1 + ((unsigned)(garr[i1 & 7u] || (unsigned)c1) / (u0 | 1u)));
    while (i0++ < 4u && 9u) { if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)((p0 >> (~(unsigned)(9u == 0x2d91abb2u) & 31u)) && (unsigned)x0);
        x0 = x0 * 0x100000001b3ull + (unsigned)((int)2u >= (int)(g1 >> (0xffffffffu & 31u)));
        l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(0x80000000u < p1) >= (int)0x7fffffffu));
        if ((0x10000u >> (m0 & 31u))) continue;
        if ((unsigned)((unsigned)(w0 >> 29) || (unsigned)s0)) break;
    }
    garr[(unsigned)(0x7fffffffu && 4u) & 7u] = (unsigned)(r0.x < ((unsigned)(unsigned char)(unsigned)(0xfc0756e2u < (unsigned)d0) + (unsigned)c1));
    switch (r0.y & 7u) {
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)b0, (unsigned)((short)(v0 * i0) > (signed char)m0), ((unsigned)((short)r0.x > (signed char)(unsigned)c0) / (g1 | 1u))); }
        case 1u: ;
        s1 = (int)((unsigned)s1 + (~(fuel + (unsigned)w0) | i0));
        if ((unsigned)((short)(0xffffffffu * r0.y) > (signed char)p2)) {
            { unsigned t5; double z5; if ((0x7fffffffu) & 1u) { t5 = (u3 - (unsigned)(x0 >> 70)); z5 = (double)(((unsigned)(signed char)(garr[i1 & 7u] % (a0[u1 & 3u] | 1u))) & 255u); } if ((0x7fffffffu) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                if (((unsigned)d0 * (m0 * 0x71c756eau))) break;
                case 2u: ;
                case 6u: ;
                if ((0x80000000u + ((unsigned)c1 % (garr[u2 & 7u] | 1u)))) goto L3;
            }
            if (g0) {
                u2 = (unsigned)((0x24d856c4u << (*q0 & 31u)) || (unsigned)(w0 >> 29));
                case 5u: ;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)(0x7fffffffu << (m0 & 31u)) < (int)0x80000000u), ((unsigned)b0 >> ((garr[i1 & 7u] << (1u & 31u)) & 31u)), (p1 * (unsigned)l0)); }
                *q0 = 0xffffffffu;
            } else {
                if ((unsigned)s0) break;
                if ((unsigned)w0) {
                    default: ;
                    *q0 += *q0;
                    if (u1) goto L3;
                    q0 = &garr[((unsigned)l0 + (unsigned)h1) & 7u];
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((short)0xffffffffu > (signed char)g0) == i0));
                }
            }
            if ((unsigned)((0x598628d8u * 0xffffffffu) == (unsigned)h0)) {
                case 3u: ;
                w0 = w0 * 6364136223846793005ull + ((unsigned)h0 * (unsigned)((unsigned)(0x80000000u < ((unsigned)(w0 >> 29) | p2)) < (unsigned)(w0 >> 29)));
                x0 = x0 * 0x100000001b3ull + 0xffffffffu;
                if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)c0 | (unsigned)(unsigned char)(unsigned)((short)r0.y > (signed char)2u)), (unsigned)((int)2u >= (int)g0), -(i0 + garr[u2 & 7u])); }
                *mp = (0x338f2cbeu | p0);
                goto L4;
            } else {
                if (budget != 0u) { budget -= 1u; u0 = fn0((0x7fffffffu * i1), (g1 % (0x33aeb82du | 1u)), (unsigned)(signed char)(fuel | (unsigned)(x0 >> 70))); }
                w0 = w0 * 6364136223846793005ull + ((v0 ? i1 : (p2 % ((unsigned)h0 | 1u))) - 0x77f14415u);
            }
        }
    }
    if ((u2 / (((unsigned)f0 ^ g0) | 1u))) {
        h1 = (unsigned short)(h1 + ((unsigned)((int)u0 >= (int)(unsigned)((short)6u > (signed char)~(unsigned)((int)0x80000000u < (int)(unsigned)c0))) & 0x7fffffffu));
        u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)(signed char)((unsigned)((short)u2 > (signed char)(unsigned)w0) | u2) && 4u);
        switch (0xffffffffu & 7u) {
            if (0xcdcb5cdeu) break;
            u1 ^= (unsigned)((short)((unsigned)w0 ? v0 : 0x297c1ceau) > (signed char)((unsigned)s0 >> (0x10000u & 31u)));
            if (fuel < 8u) return ((unsigned)h1 * ((unsigned)e0 + *mp));
            c0 = (unsigned char)-(((unsigned)((*q0 * p0) < garr[u2 & 7u]) ^ (unsigned)b0) + i2);
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)x0 && (6u + r0.y)), (unsigned)(v0 && g0), a0[i0 & 3u]); }
        }
        c1 = (signed char)((unsigned)(garr[i1 & 7u] && i2) >> ((0x7c8e55aeu * 1u) & 31u));
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                u1 = (unsigned)(short)((unsigned)e0 << (((unsigned)w0 & (unsigned)((int)(0x80000000u + (unsigned)l0) >= (int)(unsigned)c0)) & 31u));
                w0 = w0 * 6364136223846793005ull + ((0x7fffffffu ^ (unsigned)((int)u1 < (int)(unsigned)w0)) - (unsigned)h0);
                if (m0) {
                    continue; (void)((unsigned)(p0 < garr[u2 & 7u]));
                }
                if ((unsigned)((unsigned)(unsigned char)(p1 * (unsigned)f0) == 0xffffffffu)) break;
            }
        }
        r0.y ^= (u1 / (0xa3ea1b1eu | 1u));
    }
    if ((unsigned)h1) {
        if ((((unsigned)l0 / (2u | 1u)) - a0[i0 & 3u])) goto L2;
    } else {
        s1 = (int)((unsigned)s1 + ((i0 * a0[u1 & 3u]) ^ ((unsigned)s0 + (i2 >> (a0[u1 & 3u] & 31u)))));
        u2 ^= (unsigned)(unsigned char)((unsigned)e0 + (0x80000000u + (unsigned)((short)2u > (signed char)g0)));
    }
    if ((unsigned)((unsigned)((int)i1 < (int)(unsigned)(x0 >> 70)) && 1u)) goto L3;
    garr[p2 & 7u] = fuel;
    b0 = (unsigned)(unsigned char)(fuel >> ((0xb751f944u << (*q0 & 31u)) & 31u)) != 0u;
    q0 = &garr[(u2 % ((i2 % ((unsigned)l0 | 1u)) | 1u)) & 7u];
    for (;;) { if (--fuel == 0u) goto done;
        r0.y ^= (((unsigned)s1 ? fuel : (unsigned)c1) ^ (unsigned)d0);
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn2((0x10000u >> (((unsigned)s0 | u1) & 31u)), (unsigned)((int)*mp < (int)fuel), (unsigned)(unsigned char)((unsigned)!(unsigned)(0x648cafb3u < p1) | (unsigned)(x0 >> 70))); }
            q0 = &garr[((unsigned)(i2 || (0xc0168631u >> ((unsigned)e0 & 31u))) << ((unsigned)((unsigned)l0 && (unsigned)c1) & 31u)) & 7u];
            if ((0xe901368fu << (3u & 31u))) goto L0;
            if ((garr[i1 & 7u] << (fuel & 31u))) break;
            if (budget != 0u) { budget -= 1u; u3 = fn2((0xf9bb354u << ((unsigned)((unsigned)x0 || a0[i0 & 3u]) & 31u)), ~(0x51f52f28u ^ *q0), 0x9977c3e2u); }
        }
        if ((unsigned)((unsigned)(x0 >> 70) || g0)) break;
        if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)h0 + r0.x), (unsigned)(*q0 == (unsigned)l0), r0.x); }
        e0 = e0 * 0.5L + (long double)((unsigned)((int)((unsigned)((int)(unsigned)(w0 >> 29) < (int)0x10000u) + (fuel << (fuel & 31u))) < (int)p0) & 1023u);
        for (;;) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + ((u3 % ((unsigned)c0 | 1u)) % (((unsigned)c1 | garr[u2 & 7u]) | 1u));
            if ((unsigned)(unsigned char)((u0 + p0) + (unsigned)c1)) {
                g0 = ((unsigned)(w0 >> 29) ^ (unsigned)((int)9u < (int)g1));
                a0[(9u << (0x3d6665cu & 31u)) & 3u] = (unsigned)((unsigned)f0 == (unsigned)(short)((unsigned)s1 % ((unsigned)(0x7fffffffu || 0x80000000u) | 1u)));
                do { if (--fuel == 0u) goto done;
                    v0 = ((unsigned)!(p0 + *mp) + (unsigned)(0x80000000u && (unsigned)((short)u2 > (signed char)0xffffffffu)));
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)((unsigned)c1 >> (*mp & 31u)), (g1 * g1), m0); }
                    a0[(unsigned)!(g1 + 0u) & 3u] = (unsigned)(signed char)(unsigned)((unsigned)((unsigned)s0 == *q0) < (garr[i1 & 7u] - a0[i0 & 3u]));
                } while (i2++ < 3u && (a0[u1 & 3u] / ((u1 / ((unsigned)e0 | 1u)) | 1u)));
            }
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + ((unsigned)((int)g0 < (int)(unsigned)(w0 >> 29)) | (unsigned)((unsigned)(u3 && 3u) || 0x80000000u)));
                if ((g1 | 0xffffffffu)) break;
            }
            u2 ^= (((p2 >> (0x7fffffffu & 31u)) / (0x10000u | 1u)) * r0.x);
            if (((unsigned)f0 ^ i1)) {
                break; (void)((unsigned)(signed char)((unsigned)c1 >> ((unsigned)(u0 < i1) & 31u)));
            } else {
                if ((3u / (p2 | 1u))) goto L4;
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)(x0 >> 70) == 0x80000000u), ((u1 + 0x10000u) | 0xa4301e26u), 3u); }
    do { if (--fuel == 0u) goto done;
        goto L1;
    } while (i0++ < 5u && ((unsigned)d0 & (unsigned)f0));
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(i1 < 0xe7c9eaafu), (r0.y ? 0xffffffffu : 2u), (7u ^ (2u << (6u & 31u)))); }
    switch ((g0 & (unsigned)w0) & 7u) {
        if ((unsigned)(0u && (unsigned)e0)) goto L1;
    }
    do { if (--fuel == 0u) goto done;
        while (i1++ < 3u && i0) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                if (i2) {
                    u0 += (unsigned)((short)v0 > (signed char)i0);
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)((i1 * p0) & (unsigned)c0) >= (int)0x7fffffffu);
                    i2 = ((unsigned)((int)(unsigned)l0 < (int)(0x7fffffffu | 0x10000u)) ^ 0xa4a58f44u) & 15u;
                }
                goto L2;
                break; (void)((3u - (fuel / (i0 | 1u))));
                w0 = w0 * 6364136223846793005ull + u2;
            }
            if ((unsigned)(garr[u2 & 7u] && (unsigned)((short)(unsigned)c0 > (signed char)r0.x))) break;
            if (u3 == 7u) return (garr[i1 & 7u] << (0xffffffffu & 31u));
            { unsigned t6; double z6; if (((unsigned)((int)(unsigned)(signed char)(unsigned)((unsigned)(x0 >> 70) < garr[u2 & 7u]) < (int)(unsigned)l0)) & 1u) { t6 = (unsigned)((short)(unsigned)h0 > (signed char)-((unsigned)x0 + i0)); z6 = (double)(((unsigned)((int)p0 < (int)5u)) & 255u); } if (((unsigned)((int)(unsigned)(signed char)(unsigned)((unsigned)(x0 >> 70) < garr[u2 & 7u]) < (int)(unsigned)l0)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                if ((unsigned)((int)0x6a802c3bu >= (int)3u)) break;
                c1 = (signed char)(unsigned)((8u - 5u) || (0x3d4bbcd1u / ((unsigned)s0 | 1u)));
                u3 += 0xffffffffu;
                if ((unsigned)!((unsigned)d0 ^ 0xd2874753u)) goto L4;
                h1 = (unsigned short)(h1 + (unsigned)!((unsigned)(unsigned char)((unsigned)(w0 >> 29) ^ (unsigned)(unsigned char)((unsigned)(w0 >> 29) | (unsigned)(0xcf9563abu || a0[u1 & 3u]))) % (0x7fffffffu | 1u)));
            }
        }
    } while (i0++ < 3u && (i1 << (*q0 & 31u)));
    switch (*q0 & 7u) {
        w0 ^= (unsigned long long)(unsigned)x0 << ((unsigned)(-(0xeaa581c1u ? (unsigned)x0 : (unsigned)((int)0x80000000u < (int)(unsigned)s1)) && g0) & 63u);
        s0 = (int)-(unsigned)(((unsigned)s1 ^ (unsigned)d0) && r0.x);
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 6u: ;
            v0 = (unsigned)((short)i2 > (signed char)(unsigned)c0);
            u0 += (i1 << (i2 & 31u));
            g1 += (unsigned)((r0.x + u2) < i0);
        }
        if ((r0.y - 0u)) {
            i2 = ((0xffffffffu | (unsigned)!(0u / (5u | 1u))) | 0x7fffffffu) & 15u;
        } else {
            while (((unsigned)((unsigned)c1 || 0x9df8db0bu) | 5u)) { if (--fuel == 0u) goto done;
                *q0 += (unsigned)(unsigned char)(unsigned)((int)(unsigned)((short)p1 > (signed char)(unsigned)(signed char)(p2 ^ (unsigned)f0)) >= (int)(0x10000u - 0x50280a2fu));
                if ((0x80000000u % ((m0 | a0[i0 & 3u]) | 1u))) {
                    f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)((unsigned)s1 || i0) >= (int)((unsigned)(p2 && garr[u2 & 7u]) << (0x6a658a38u & 31u))) & 255u);
                    if (i0) goto L3;
                    r0.x = (unsigned)((unsigned)(signed char)(garr[i1 & 7u] + (unsigned)s1) == (unsigned)((int)(0x10000u | p2) < (int)0x8ec30e31u));
                    if (((unsigned)(unsigned char)((unsigned)e0 / (g0 | 1u)) | (unsigned)b0)) break;
                }
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((unsigned)w0 < (unsigned)((unsigned)d0 || (unsigned)h1)), (g1 & (unsigned)((unsigned)(x0 >> 70) == (unsigned)b0)), 1u); }
    }
    switch ((unsigned)(w0 >> 29) & 7u) {
        if (~((p2 / (u3 | 1u)) % (p2 | 1u))) goto L2;
        for (;;) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)l0 << ((unsigned)c0 & 63u);
            e0 = e0 * 0.5L + (long double)(5u & 1023u);
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)f0, v0, ((unsigned)x0 & (unsigned)(w0 >> 29))); }
            do { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    u1 += (p0 & ~(unsigned)((unsigned)b0 || 0x24a6cc76u));
                    l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(unsigned)((short)*mp > (signed char)(unsigned)!(unsigned)(0x7fffffffu == ((unsigned)h0 >> ((u3 ^ 0x513463ffu) & 31u)))));
                    if ((unsigned)(signed char)(unsigned)((int)((unsigned)f0 << (p2 & 31u)) >= (int)0xab7d64f1u)) {
                        if ((*q0 / ((unsigned)c1 | 1u))) continue;
                        { unsigned t7; double z7; if (((unsigned)(*q0 && *mp)) & 1u) { t7 = (unsigned)!(i1 & (a0[u1 & 3u] * (unsigned)e0)); z7 = (double)((i1) & 255u); } if (((unsigned)(*q0 && *mp)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                            r0.x = (unsigned)((unsigned)(garr[i1 & 7u] || (unsigned)(u0 || 0x7fffffffu)) == p1);
                            case 4u: ;
                        }
                        *mp = (unsigned)(0xffffffffu || (fuel | 6u));
                        if ((0x79fdc212u ? garr[u2 & 7u] : g0)) goto L1;
                        case 5u: ;
                        h1 = (unsigned short)(h1 + ((unsigned)((int)0u < (int)((unsigned)e0 >> (garr[i1 & 7u] & 31u))) | *q0));
                    } else {
                        g1 += (unsigned)((0x7fffffffu * a0[u1 & 3u]) == ((unsigned)w0 << ((r0.x * (unsigned)d0) & 31u)));
                        b0 = 2u != 0u;
                    }
                    e0 = e0 * 0.5L + (long double)(((r0.y ^ (i0 - (0xffffffffu * u3))) | r0.x) & 1023u);
                } while (i2++ < 5u && (unsigned)((*q0 / (3u | 1u)) || u0));
                g0 = ((v0 / (0xf0efa2a9u | 1u)) | (unsigned)((int)r0.y >= (int)r0.x));
                r0.x = (unsigned)((int)u1 >= (int)garr[i1 & 7u]);
                e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)((unsigned)(short)(unsigned)(((unsigned)b0 << (*mp & 31u)) && (0x117aee1du * 0x80000000u)) + *mp) & 1023u);
                break; (void)((unsigned)f0);
            } while (i1++ < 2u && ((unsigned)((int)0x80000000u >= (int)g0) & garr[u2 & 7u]));
            case 6u: ;
        }
        default: ;
        if (fuel < 8u) return 0xffffffffu;
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 ^= (*q0 | ((unsigned)(x0 >> 70) + g1));
    }
    m0 ^= (0xffffffffu ^ (unsigned)h0);
    x0 = x0 * 0x100000001b3ull + (unsigned)!(unsigned)((short)((unsigned)w0 & (garr[i1 & 7u] / (p1 | 1u))) > (signed char)(unsigned)(garr[u2 & 7u] && 0x77ff5fe7u));
    { unsigned t8; double z8; if (((unsigned)s0) & 1u) { t8 = (unsigned)((unsigned)c0 || ((unsigned)w0 / (5u | 1u))); z8 = (double)(((unsigned)((unsigned)((int)0x7fffffffu < (int)u3) || (unsigned)c0)) & 255u); } if (((unsigned)s0) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
        m0 ^= 0x1b25119du;
    }
    while (i0++ < 7u && (i1 >> ((unsigned)((short)(unsigned)h1 > (signed char)r0.y) & 31u))) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)c1 > (signed char)(unsigned)(r0.y && u0)), 0xffffffffu, garr[u2 & 7u]); }
        while (i1++ < 7u && (unsigned)x0) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)((short)(garr[u2 & 7u] >> ((unsigned)(x0 >> 70) & 31u)) > (signed char)(0x4c6c99bu % (1u | 1u)));
            do { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    *mp = (0x10000u / (i2 | 1u));
                    goto L3;
                    if ((unsigned)((short)7u > (signed char)0x10000u)) goto L2;
                    if ((unsigned)(signed char)(p2 + 0x3ba6a5b1u)) break;
                    s1 = (int)((unsigned)s1 + (i2 | (unsigned)(unsigned char)(unsigned)(g0 == (unsigned)((unsigned)h1 == (unsigned)f0))));
                }
                s0 = (int)(unsigned)(((unsigned)b0 % (0x7fffffffu | 1u)) < (7u / ((0xe4a8eda9u + u1) | 1u)));
                { unsigned t9; double z9; if ((r0.x) & 1u) { t9 = (0u + *mp); z9 = (double)(((4u ^ -(unsigned)((int)0x80000000u < (int)(unsigned)e0))) & 255u); } if ((r0.x) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                    g1 += ((unsigned)(0x765298e0u == 0x35cef818u) + (0x10000u * (p2 << ((unsigned)(w0 >> 29) & 31u))));
                }
                break; (void)((unsigned)h1);
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((0x10000u << (0x80000000u & 31u)));
                    if ((unsigned)!((unsigned)((int)a0[u1 & 3u] >= (int)a0[u1 & 3u]) / ((unsigned)f0 | 1u))) break;
                    x0 = x0 * 0x100000001b3ull + u1;
                }
                if (0x82641272u) continue;
            } while (i2++ < 7u && (p0 - ((unsigned)f0 % (6u | 1u))));
            c1 = (signed char)(unsigned)((unsigned)((int)(unsigned)h1 < (int)u0) && 1u);
        }
        if ((0x526e1ab4u & 0x5189badeu)) {
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((r0.y & (u3 >> ((unsigned)l0 & 31u)))) goto L2;
            }
            if ((unsigned)(fuel == ((unsigned)l0 | (unsigned)h0))) break;
            if ((((unsigned)s0 % (g0 | 1u)) - garr[u2 & 7u])) {
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(x0 >> 70)) break;
                    { unsigned t10; double z10; if ((3u) & 1u) { t10 = (unsigned)(0x35e876fdu < (unsigned)e0); z10 = (double)(((p0 >> (g0 & 31u))) & 255u); } if ((3u) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
                        g1 += r0.x;
                    }
                }
                if (m0) goto done;
                if ((0xa2d5a65au * ((unsigned)c1 - 0xaf04a75du))) {
                    if (((0x4c807fb5u ^ (unsigned)l0) + (unsigned)s1)) break;
                    x0 = x0 * 0x100000001b3ull + (unsigned)(0x57f550e8u || a0[i0 & 3u]);
                    b0 = (v0 ? u0 : a0[u1 & 3u]) != 0u;
                } else {
                    if ((unsigned)((short)(unsigned)d0 > (signed char)g0)) continue;
                }
            } else {
                d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(((i0 ? p1 : (unsigned)c1) << (u3 & 31u)) | 0xffffffffu) & 1023u);
                w0 ^= (unsigned long long)(0x6da014f5u & a0[i0 & 3u]) << ((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)((unsigned)c0 == (0xffffffffu << (0x274cac39u & 31u)))) & 63u);
            }
        } else {
            v0 = p0;
            if ((0x10000u % ((0xae588220u / ((unsigned)(w0 >> 29) | 1u)) | 1u))) break;
            break; (void)(((unsigned)(x0 >> 70) + g0));
            h1 = (unsigned short)(h1 + 1u);
        }
        a0[(unsigned)(unsigned char)(u1 << (0x7fffffffu & 31u)) & 3u] = (u2 ? 0x10000u : (unsigned)d0);
        if ((unsigned)(signed char)(unsigned)((int)0x10000u < (int)(0x7fffffffu & (unsigned)l0))) continue;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    u0 += (0x7a9fc77bu | 0xf6f9722du);
    if (u3 == 7u) return (unsigned)((int)(garr[u2 & 7u] >> (4u & 31u)) >= (int)(unsigned)((short)(unsigned)h1 > (signed char)8u));
    if (budget != 0u) { budget -= 1u; u0 = fn1(p1, (unsigned)w0, (unsigned)c0); }
    u3 = (r0.x / ((unsigned)((int)0x10000u >= (int)(unsigned)l0) | 1u));
    a0[-(p1 * a0[i0 & 3u]) & 3u] = ((i2 ? (unsigned)c1 : (*q0 % (0xf2b9bfa2u | 1u))) * 0u);
    switch ((unsigned)b0 & 7u) {
        L0: if (--fuel == 0u) goto done;
        case 2u: ;
        if ((unsigned)((int)0x80000000u >= (int)(unsigned)((short)u1 > (signed char)0x48eb184bu))) goto L1;
    }
    while ((unsigned)((short)p2 > (signed char)p0)) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            b0 = g1 != 0u;
        } while (i1++ < 6u && (unsigned)h1);
        q0 = &garr[(unsigned)((int)((unsigned)b0 >> (0x8e13bdfau & 31u)) >= (int)u0) & 7u];
        w0 ^= (unsigned long long)(unsigned)e0 << ((unsigned)((*mp >> ((unsigned)d0 & 31u)) && (garr[u2 & 7u] ^ (unsigned)c1)) & 63u);
    }
    if (budget != 0u) { budget -= 1u; u3 = fn3((8u + (unsigned)c0), (~(unsigned)((unsigned)x0 == 0x7fffffffu) + (unsigned)f0), (6u ? 5u : (unsigned)b0)); }
    u3 += (unsigned)((int)*q0 < (int)(unsigned)h1);
    { unsigned t0; double z0; if (((unsigned)l0) & 1u) { t0 = (unsigned)((int)(unsigned)e0 >= (int)(unsigned)b0); z0 = (double)((-(unsigned)((short)(unsigned)((int)u1 >= (int)4u) > (signed char)(unsigned)d0)) & 255u); } if (((unsigned)l0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        if ((unsigned)((int)i0 < (int)u1)) {
            L1: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(0x10000u < (unsigned)!((unsigned)(w0 >> 29) << (p1 & 31u))), (unsigned)((unsigned)s1 == p0), p2); }
            goto done;
        } else {
            goto L0;
            while (i0++ < 2u && i2) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (unsigned)((short)5u > (signed char)p2);
                if ((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)((int)0x554bb4e8u >= (int)u2))) goto L2;
                if ((r0.y - i0)) continue;
                L2: if (--fuel == 0u) goto done;
                b0 = (u1 & 6u) != 0u;
            }
            u2 ^= (unsigned)(x0 >> 70);
        }
        goto L2;
        h0 = (short)(unsigned)(u3 < (0x80000000u >> (~(unsigned)((unsigned)s1 < m0) & 31u)));
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            u2 ^= (((unsigned)w0 % ((unsigned)h1 | 1u)) << (((unsigned)(p2 && garr[i1 & 7u]) % (0xffffffffu | 1u)) & 31u));
            break; (void)(p2);
            h1 = (unsigned short)(h1 + (unsigned)((int)0x8fb9121du < (int)0u));
            if (0xfb870f92u) break;
            if ((unsigned)(u2 || (unsigned)((int)(unsigned)w0 >= (int)a0[i0 & 3u]))) {
                { unsigned t1; double z1; if (((7u >> (r0.x & 31u))) & 1u) { t1 = g0; z1 = (double)(((unsigned)!((unsigned)(0xa3415cccu || (unsigned)l0) | (unsigned)x0)) & 255u); } if (((7u >> (r0.x & 31u))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    e0 = e0 * 0.5L + (long double)((9u * ((unsigned)!(0xac6b3282u / ((unsigned)(unsigned char)(unsigned)((unsigned)f0 || garr[i1 & 7u]) | 1u)) & u2)) & 1023u);
                }
                for (;;) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((0x399e4c59u ? i0 : (unsigned)b0) & 1023u);
                    *q0 = (unsigned)((int)u2 < (int)(unsigned)((p1 << ((0x7fffffffu - (unsigned)s0) & 31u)) && u2));
                    c0 = (unsigned char)(unsigned)(((p1 / ((unsigned)(w0 >> 29) | 1u)) - 1u) && 0x10000u);
                }
                r0.x = (((unsigned)c0 % ((unsigned)d0 | 1u)) - a0[i0 & 3u]);
                g0 = (unsigned)(unsigned char)((r0.y + (p1 + (unsigned)f0)) * (u1 | g1));
                g1 += ((unsigned)(w0 >> 29) % (0x290f6823u | 1u));
            } else {
                if ((unsigned)(signed char)(unsigned)((a0[u1 & 3u] | 1u) < 3u)) goto L2;
                e0 = e0 * 0.5L + (long double)((unsigned)(7u && a0[i0 & 3u]) & 1023u);
            }
        }
    }
    goto L1;
    d0 = d0 * 0.5 + (double)(((unsigned)(0xcd2f2c05u == 7u) << ((0x5f9275cbu | (8u & 4u)) & 31u)) & 1023u);
    if (((unsigned)((int)a0[u1 & 3u] < (int)0x7fffffffu) % (0x7fffffffu | 1u))) goto L3;
    if ((1u << ((unsigned)(0xffffffffu < p2) & 31u))) {
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((i2 >> (6u & 31u)), (unsigned)(i2 && 3u), (u3 / (((unsigned)c0 + a0[i0 & 3u]) | 1u))); }
            m0 ^= (garr[i1 & 7u] & (a0[u1 & 3u] ? *q0 : 0xec326aaau));
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)(unsigned)((unsigned)d0 || 0xe836e2eu) > (signed char)u2), 0xe8be2379u, (unsigned)((int)p0 >= (int)a0[u1 & 3u])); }
            if (fuel) continue;
            u0 = (0x80000000u ? 0x10000u : i2);
        } while (i0++ < 6u && ((unsigned)c1 * (unsigned)(u2 < (unsigned)x0)));
        if ((unsigned)((int)garr[i1 & 7u] >= (int)5u)) goto L3;
    }
    switch ((unsigned)(0x8c024f7u || (unsigned)(signed char)(r0.y % ((unsigned)e0 | 1u))) & 7u) {
        do { if (--fuel == 0u) goto done;
            c1 = (signed char)-(0xffffffffu % (0xffffffffu | 1u));
        } while (i0++ < 5u && (unsigned)((int)g1 >= (int)u2));
        L3: if (--fuel == 0u) goto done;
        q0 = &garr[(unsigned)((unsigned)((int)(unsigned)((int)(unsigned)b0 < (int)i0) >= (int)0xfc74c66eu) == -(5u % (0x1e958db5u | 1u))) & 7u];
        v0 = (unsigned)((int)(unsigned)((short)(unsigned)c1 > (signed char)(unsigned)s1) < (int)(u3 / ((0xb79f7d81u + *q0) | 1u)));
        while (u2) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                garr[((unsigned)f0 - u0) & 7u] = -(5u % (m0 | 1u));
                { unsigned t2; double z2; if (((8u * 0x1ce9716u)) & 1u) { t2 = (unsigned)((short)a0[i0 & 3u] > (signed char)*q0); z2 = (double)(((g1 ^ (2u >> (*mp & 31u)))) & 255u); } if (((8u * 0x1ce9716u)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    if (u0) {
                        l0 = (long)((unsigned long)l0 + ((unsigned)x0 | ((p2 / (g0 | 1u)) & 0x7fffffffu)));
                        e0 = e0 * 0.5L + (long double)(((unsigned)f0 >> (0u & 31u)) & 1023u);
                        case 7u: ;
                    }
                    if ((unsigned)(w0 >> 29)) {
                        case 4u: ;
                        r0.x = (a0[u1 & 3u] ^ p0);
                    } else {
                        d0 = d0 * 0.5 + (double)(((0x20bea056u * (unsigned)f0) - (p1 >> (p0 & 31u))) & 1023u);
                        r0.x = 0x46ac39c6u;
                    }
                    case 3u: ;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((short)(unsigned)s0 > (signed char)u0)) {
                            d0 = d0 * 0.5 + (double)(((unsigned)s0 + (unsigned)(signed char)(unsigned)((short)(unsigned)!(a0[i0 & 3u] * 0x10000u) > (signed char)(unsigned)f0)) & 1023u);
                            e0 = e0 * 0.5L + (long double)((6u | ((0u ^ (unsigned)s0) / (0x6701455u | 1u))) & 1023u);
                        } else {
                            case 6u: ;
                            l0 = (long)((unsigned long)l0 + ((unsigned)((int)(0x80000000u ? g1 : (unsigned)(x0 >> 70)) < (int)u1) & (unsigned)(w0 >> 29)));
                            if ((unsigned)((int)(unsigned)e0 >= (int)(unsigned)((int)(unsigned)l0 < (int)0x4f63c6d3u))) goto L2;
                        }
                        if (budget != 0u) { budget -= 1u; u2 = fn2(((5u >> (0xb65249ddu & 31u)) / (0x83e58392u | 1u)), ((unsigned)s0 * u2), ((unsigned)c0 * 0x80000000u)); }
                        default: ;
                        s0 = (int)((unsigned)(short)(((unsigned)(0x7fffffffu || i2) & 0x7fffffffu) | r0.y) / (u2 | 1u));
                        break;
                    } while (i2++ < 2u && (unsigned)(r0.y && (unsigned)((int)0x506a1542u < (int)(unsigned)h0)));
                    f0 = f0 * 0.5f + (float)(0xdf0de3aau & 255u);
                }
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    case 0u: ;
                }
            } while (i1++ < 3u && *q0);
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(g1 == 0x7fffffffu), ((9u & *q0) ^ *mp), 8u); }
                { unsigned t3; double z3; if (((unsigned)e0) & 1u) { t3 = -(unsigned)(3u == 0u); z3 = (double)((((unsigned)d0 + (unsigned)s0)) & 255u); } if (((unsigned)e0) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                    break;
                    if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)b0, (fuel | (unsigned)c1), (unsigned)((unsigned)s1 < 0x80000000u)); }
                }
                g1 += 0x27ce7386u;
                m0 ^= (unsigned)((short)(0xcca72f6au ^ (unsigned)(p0 || r0.y)) > (signed char)(unsigned)d0);
                *q0 += (unsigned)((int)(((unsigned)e0 >> ((unsigned)l0 & 31u)) & ((unsigned)w0 % ((unsigned)c0 | 1u))) >= (int)garr[i1 & 7u]);
            } while (i1++ < 6u && (unsigned)(p2 && (u1 * (unsigned)l0)));
            if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)c1 & (fuel / (2u | 1u))), -(unsigned)((unsigned)b0 < r0.y), (unsigned)(6u || garr[i1 & 7u])); }
            w0 = w0 * 6364136223846793005ull + (unsigned)h0;
            s1 = (int)((unsigned)s1 + (g0 % (7u | 1u)));
        }
    }
    s0 = (int)(0x10000u + (((unsigned)e0 / (0x80000000u | 1u)) ^ (u2 % ((unsigned)c1 | 1u))));
    if (budget != 0u) { budget -= 1u; u3 = fn2(0xb71d49c7u, ((0x10000u & p2) ^ (unsigned)c1), 0xdff32991u); }
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)(unsigned)c0 >= (int)(unsigned)w0), (fuel - 1u), u2); }
    if ((unsigned)(0x29bea7b1u || i1)) goto L0;
    garr[fuel & 7u] = ((unsigned)x0 % (0x73d8729u | 1u));
    { unsigned t4; double z4; if (((unsigned)h0) & 1u) { t4 = (unsigned)((int)(unsigned)b0 >= (int)(unsigned)(u1 && a0[i0 & 3u])); z4 = (double)((((unsigned)(i0 == 0x82c6eadeu) / (3u | 1u))) & 255u); } if (((unsigned)h0) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        r0.x = (p0 - (unsigned)((int)i2 >= (int)p2));
    }
    if (((*q0 ^ u1) / ((unsigned)e0 | 1u))) {
        f0 = f0 * 0.5f + (float)((unsigned)((int)p1 >= (int)(unsigned)s0) & 255u);
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= a0[u1 & 3u];
            *q0 = (unsigned)(9u == (unsigned)((int)0x10000u >= (int)p0));
            if ((unsigned)((unsigned)h1 == (0x80000000u + 0u))) break;
            if (budget != 0u) { budget -= 1u; u1 = fn2((u3 / (u3 | 1u)), (unsigned)(g0 == (0u ^ 0x7fffffffu)), (unsigned)((short)0xffffffffu > (signed char)(m0 & (unsigned)b0))); }
            r0.y ^= (((unsigned)((short)0x4abe3636u > (signed char)8u) + 2u) + 0x91ab5e4bu);
            g0 = ((unsigned)(short)((unsigned)(*mp == garr[u2 & 7u]) | garr[u2 & 7u]) << ((unsigned)c1 & 31u));
        }
        do { if (--fuel == 0u) goto done;
            h0 = (short)((6u >> ((0x80000000u >> (((unsigned)w0 >> (garr[i1 & 7u] & 31u)) & 31u)) & 31u)) & r0.y);
            for (;;) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(((unsigned)d0 & (unsigned)s1) & 255u);
                break; (void)((((unsigned)d0 + (unsigned)e0) + (unsigned)l0));
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)((int)5u < (int)(unsigned)w0) < (unsigned)((unsigned)((short)r0.y > (signed char)(unsigned)h0) || (unsigned)(x0 >> 70))));
                if ((unsigned)(0xbc93cdd6u == *mp)) break;
            }
            if (((unsigned)x0 & 6u)) continue;
            m0 ^= (unsigned)(3u || (unsigned)(w0 >> 29));
            if ((unsigned)((unsigned)(1u < (unsigned)d0) || (unsigned)c0)) break;
        } while (i0++ < 2u && (5u << (8u & 31u)));
        if ((i2 << (u0 & 31u))) goto L3;
        do { if (--fuel == 0u) goto done;
            switch ((*mp << ((g1 + (unsigned)h0) & 31u)) & 7u) {
                v0 = (-((a0[u1 & 3u] | 0x1f9a1b72u) << (i2 & 31u)) / ((unsigned)l0 | 1u));
                if (fuel < 8u) return ((unsigned)s1 & v0);
                l0 = (long)((unsigned long)l0 + ~(unsigned)((int)fuel >= (int)(unsigned)x0));
            }
        } while (i0++ < 7u && (unsigned)(w0 >> 29));
    }
    do { if (--fuel == 0u) goto done;
        if (0x80000000u) continue;
        if (~(unsigned)((int)0x2e75e5b9u >= (int)(unsigned)x0)) break;
        do { if (--fuel == 0u) goto done;
            i1 = (unsigned)(8u || (unsigned)(0x592035d3u < i2)) & 15u;
        } while (i1++ < 3u && (unsigned)(m0 || 0x7f2658ccu));
    } while (i0++ < 6u && p0);
    h0 = (short)(0x10000u / ((i0 | ((unsigned)w0 & m0)) | 1u));
    if ((unsigned)(unsigned char)(unsigned)(i1 < 0x24a4ef64u)) {
        if (u1) {
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)e0 && (a0[i0 & 3u] >> ((0u >> (i2 & 31u)) & 31u))));
                switch ((unsigned)(short)(unsigned)((int)fuel < (int)(unsigned)(x0 >> 70)) & 7u) {
                    if ((unsigned)c0) {
                        if ((0x53682cf9u + a0[u1 & 3u])) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(0x7fffffffu || (unsigned)s1), (unsigned)(0x2f477d43u && (unsigned)((int)u3 < (int)p0)), (unsigned)(short)((unsigned)s0 & (unsigned)(0x10000u && 0u))); }
                        s0 = (int)(unsigned)((u3 & u1) < (unsigned)(a0[u1 & 3u] || (g0 % ((unsigned)(w0 >> 29) | 1u))));
                    } else {
                        h1 = (unsigned short)(h1 + (unsigned)((unsigned)(p2 && (g0 / (0x99acea52u | 1u))) == ((unsigned)x0 & 2u)));
                        u2 += (p1 ^ a0[i0 & 3u]);
                        case 7u: ;
                        r0.x = (unsigned)((int)p2 < (int)(((unsigned)(x0 >> 70) ^ fuel) + ((unsigned)h1 - (unsigned)w0)));
                    }
                    g1 += (unsigned)(u1 && (unsigned)x0);
                    if (u3) {
                        case 4u: ;
                        e0 = e0 * 0.5L + (long double)((0x31aed2a9u / (*mp | 1u)) & 1023u);
                        w0 = w0 * 6364136223846793005ull + (unsigned)((int)((unsigned)((short)0x10000u > (signed char)(unsigned)c1) >> ((i0 & (unsigned)f0) & 31u)) < (int)(unsigned)s0);
                    } else {
                        e0 = e0 * 0.5L + (long double)((unsigned)(0xd9f8dfebu < p2) & 1023u);
                        r0.x = (unsigned)((short)*q0 > (signed char)p2);
                    }
                    m0 ^= ((unsigned)(((unsigned)d0 + i1) == (unsigned)f0) ^ 5u);
                }
                e0 = e0 * 0.5L + (long double)((unsigned)(short)((unsigned)((int)((0x10000u % (u1 | 1u)) % (u0 | 1u)) < (int)p1) | 0x7fbb2a70u) & 1023u);
                if ((unsigned)((int)(unsigned)s0 >= (int)u0)) break;
                d0 = d0 * 0.5 + (double)((unsigned)s0 & 1023u);
                c1 = (signed char)((unsigned)(w0 >> 29) + (r0.y ? (unsigned)(w0 >> 29) : (unsigned)s1));
            }
            if (((unsigned)x0 * (unsigned)!(unsigned)((int)p0 >= (int)garr[u2 & 7u]))) goto L0;
            if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)d0 % (0x10000u | 1u)), 0x7fffffffu, (unsigned)((unsigned)l0 && 0x42a30ddfu)); }
            goto L0;
            if (*mp) {
                { unsigned t5; double z5; if (((unsigned)((short)r0.x > (signed char)garr[i1 & 7u])) & 1u) { t5 = (unsigned)(unsigned char)((unsigned)e0 ? i2 : u3); z5 = (double)((i0) & 255u); } if (((unsigned)((short)r0.x > (signed char)garr[i1 & 7u])) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(i2 && (unsigned)h1), 5u, (unsigned)s0); }
                    u1 = (unsigned)((int)(unsigned)((unsigned)x0 == 0x80eb306u) >= (int)4u);
                    goto L2;
                    u3 ^= (unsigned)(short)(unsigned)((short)(0x80000000u << (p2 & 31u)) > (signed char)-(unsigned)((short)*mp > (signed char)(unsigned)e0));
                }
                c1 = (signed char)(unsigned)!(unsigned)((short)-((u1 * (unsigned)h1) ^ 0xb99fe754u) > (signed char)(unsigned)((unsigned)h1 < 0x80000000u));
                b0 = ((unsigned)l0 ? i2 : (unsigned)((int)(unsigned)f0 >= (int)(unsigned)s1)) != 0u;
                if (u3 == 7u) return (unsigned)((unsigned)(w0 >> 29) || (unsigned)(signed char)(garr[u2 & 7u] >> (i0 & 31u)));
            }
            if (-(unsigned)((int)0x539bd86bu < (int)(unsigned)h0)) {
                goto L0;
            }
        } else {
            if (5u) goto L0;
        }
    }
    if (((unsigned)!(p1 * p1) & u0)) goto L3;
    if (budget != 0u) { budget -= 1u; u2 = fn2((0x7fffffffu ? 0x10000u : garr[i1 & 7u]), (m0 - (unsigned)s0), ((1u * i2) ^ (unsigned)h0)); }
    u2 += (unsigned)((unsigned)(0x1e905fc5u || 0x7fffffffu) && p1);
    w0 = w0 * 6364136223846793005ull + (0x80000000u / (p2 | 1u));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)e0 & (unsigned)(u0 && (unsigned)h0))) {
            if (fuel < 8u) return ((unsigned)((int)i0 >= (int)i0) - g0);
            u0 = ((unsigned)e0 | (0x80000000u * i0));
            if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)b0) / ((unsigned)c1 | 1u))) break;
        }
        if (3u) continue;
        while (i1++ < 3u && 0x9e9499efu) { if (--fuel == 0u) goto done;
            b0 = (unsigned)((int)((unsigned)s1 << (p0 & 31u)) >= (int)(unsigned)(0xc3039486u && (unsigned)s0)) != 0u;
            if (budget != 0u) { budget -= 1u; u0 = fn1((0xffffffffu | u3), ((unsigned)(w0 >> 29) - a0[u1 & 3u]), (unsigned)(garr[i1 & 7u] || 0x5f11eca5u)); }
            if ((unsigned)(a0[u1 & 3u] || 0xa145a8b3u)) break;
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((unsigned)s0 || v0) == (unsigned)((0xd6741583u % ((unsigned)c0 | 1u)) && a0[u1 & 3u]));
        }
        if ((u0 ^ i1)) goto L1;
    }
    w0 ^= (unsigned long long)(unsigned)h0 << ((p1 >> (a0[u1 & 3u] & 31u)) & 63u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 11u, 0xb72e216eu, 0x15cb5a49u },
        { 11u, 0xeb33ef6bu, 0xbfa3bb72u },
        { 4u, 0xb9873295u, 0x5756ce20u },
        { 2u, 0x290efda1u, 0xa3fc98ccu },
        { 8u, 0x1f3a65afu, 0xca065ff6u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
