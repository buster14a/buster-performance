// test-ssa-source's program of seed 134000426 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x7d75a3f2u, g1 = 0xcdda821bu;
static unsigned garr[8] = { 0x51bcd36au, 0x7228ed54u, 0xfe0e4180u, 0x627dd915u, 0x6b82c7aeu, 0xd1ed0529u, 0x21a44003u, 0xd8cdea95u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    s0 = (int)(unsigned)((int)(r0.x >> (((unsigned)s1 | a0[i0 & 3u]) & 31u)) < (int)(unsigned)d0);
    do { if (--fuel == 0u) goto done;
        i0 = (unsigned)c1 & 15u;
        r0.x = (0x76f1cac9u ^ (unsigned)s1);
        *q0 = (unsigned)(0x7fffffffu && (p1 >> ((unsigned)(i0 == (unsigned)b0) & 31u)));
        b0 = ((garr[u2 & 7u] % ((unsigned)c0 | 1u)) >> (a0[u1 & 3u] & 31u)) != 0u;
        do { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
            g0 = *mp;
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                a0[(0xedb18e67u ^ *q0) & 3u] = fuel;
                if ((unsigned)((short)(0x426f4c89u / ((unsigned)e0 | 1u)) > (signed char)u3)) break;
            }
            if (-(unsigned)(u3 || ((unsigned)(w0 >> 29) / (p1 | 1u)))) continue;
        } while (i1++ < 3u && (u3 / (g0 | 1u)));
    } while (i0++ < 5u && ((unsigned)l0 | (unsigned)(unsigned char)(i2 | (unsigned)c0)));
    s0 = (int)((unsigned)c1 % ((unsigned)(0x80000000u && ~(0x80000000u * garr[i1 & 7u])) | 1u));
    if ((0x80000000u ^ (unsigned)(signed char)(unsigned)(0xffffffffu == 0x10000u))) {
        do { if (--fuel == 0u) goto done;
            if (((unsigned)l0 & (unsigned)d0)) {
                switch (u2 & 7u) {
                    case 1u: ;
                    L1: if (--fuel == 0u) goto done;
                    if ((0xffffffffu << ((0x4fc64ef3u >> ((unsigned)c1 & 31u)) & 31u))) goto L0;
                    r0.y ^= (unsigned)s1;
                    L2: if (--fuel == 0u) goto done;
                    if (fuel < 8u) return ((0x81a8e331u ^ (unsigned)(a0[i0 & 3u] || 6u)) | u0);
                }
                w0 = w0 * 6364136223846793005ull + (unsigned)((short)fuel > (signed char)~(unsigned)((0x4b450821u * ((unsigned)c1 / (garr[i1 & 7u] | 1u))) == garr[u2 & 7u]));
                g1 += (unsigned)(signed char)(unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)f0 || u1) == (unsigned)(0xb8a669d9u == a0[i0 & 3u]));
            }
        } while (i0++ < 5u && 0xc5bbe036u);
        do { if (--fuel == 0u) goto done;
            i0 = -((unsigned)(short)(unsigned)(a0[i0 & 3u] && (a0[i0 & 3u] / ((unsigned)s1 | 1u))) ^ r0.y) & 15u;
            for (;;) { if (--fuel == 0u) goto done;
                goto L1;
                while (i2++ < 5u && ((unsigned)l0 << ((unsigned)((int)(unsigned)w0 < (int)4u) & 31u))) { if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                    L4: if (--fuel == 0u) goto done;
                    break; (void)((unsigned)(x0 >> 70));
                    garr[((unsigned)d0 >> (u3 & 31u)) & 7u] = (unsigned)(short)(4u ? (unsigned)h1 : ~(unsigned)((short)i0 > (signed char)0x7fffffffu));
                    h0 = (short)((unsigned)((int)6u >= (int)(unsigned)(unsigned char)((unsigned)h1 % (p2 | 1u))) % ((unsigned)!(g1 + i0) | 1u));
                    h1 = (unsigned short)(h1 + ~(((unsigned)(m0 || (unsigned)f0) ^ (unsigned)((int)a0[i0 & 3u] >= (int)0x3d229c0fu)) & u3));
                }
                d0 = d0 * 0.5 + (double)((0xfaf05910u ? a0[u1 & 3u] : 4u) & 1023u);
                r0.y ^= (unsigned)e0;
                if (((unsigned)((int)0xffffffffu >= (int)p2) << ((unsigned)b0 & 31u))) {
                    if ((unsigned)((unsigned)((int)0x10000u >= (int)0x10000u) || (unsigned)x0)) break;
                }
                if ((unsigned)((short)(unsigned)(i2 == 0x80000000u) > (signed char)r0.y)) break;
            }
            break; (void)((unsigned)((int)((unsigned)s1 & i0) >= (int)(unsigned)h0));
            if ((unsigned)(signed char)(6u << (0xf54fbc37u & 31u))) continue;
            if ((unsigned)(short)(0xffffffffu + (unsigned)w0)) break;
        } while (i0++ < 6u && (unsigned)s1);
        if ((unsigned)((int)(unsigned)h0 < (int)r0.y)) goto L1;
        if ((unsigned)(i1 || (*mp ^ (unsigned)c1))) {
            g0 = (0x10000u >> ((unsigned)(garr[i1 & 7u] == u0) & 31u));
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if (((unsigned)h1 + 0x8613dc6bu)) goto L3;
                    r0.y ^= ((unsigned)(i1 && a0[u1 & 3u]) / ((p1 >> (0x10000u & 31u)) | 1u));
                    if ((unsigned)(i2 == 0xffffffffu)) goto done;
                    if (((unsigned)!(*mp + g0) / (4u | 1u))) {
                        if (((unsigned)d0 * r0.x)) {
                            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)(short)(unsigned)((int)(unsigned)((unsigned)s1 == g0) < (int)1u) && 0x80000000u);
                            v0 = (unsigned)(x0 >> 70);
                            s0 = (int)garr[i1 & 7u];
                            break; (void)(u2);
                            *q0 += (unsigned)((short)((unsigned)(u3 || 4u) ^ (unsigned)c0) > (signed char)0x9f9c0e54u);
                        } else {
                            u2 += (unsigned)(((unsigned)d0 | (unsigned)(0x7fffffffu || fuel)) || p0);
                            garr[((unsigned)b0 + 0x81052f55u) & 7u] = ((0xcf1cee04u >> (((unsigned)c1 - 7u) & 31u)) >> ((unsigned)d0 & 31u));
                            g0 = (unsigned)((unsigned)((int)*q0 >= (int)(unsigned)s0) == garr[i1 & 7u]);
                            b0 = 0x1915879cu != 0u;
                        }
                        if ((unsigned)((0xff5d88deu * i1) && 0x7fffffffu)) {
                            if ((unsigned)(u3 && p0)) break;
                            d0 = d0 * 0.5 + (double)(((unsigned)x0 / (p0 | 1u)) & 1023u);
                            if ((fuel | (m0 * 0xffffffffu))) continue;
                            if (~((unsigned)d0 ^ (unsigned)((int)0x1ca3bc8du < (int)fuel))) break;
                        } else {
                            a0[(unsigned)((int)0xd9f7d8aau >= (int)8u) & 3u] = (unsigned)((short)0x93478746u > (signed char)(unsigned)(short)((unsigned)s1 * fuel));
                            l0 = (long)((unsigned long)l0 + u1);
                        }
                    } else {
                        if ((unsigned)(0x70b8067bu == 0x7fffffffu)) break;
                    }
                    *q0 = (unsigned)!(unsigned)(0x7cbb7bf8u && (unsigned)!(unsigned)((unsigned)h1 == 0xffffffffu));
                    if (((unsigned)b0 ^ (unsigned)(4u && (unsigned)c1))) break;
                } while (i1++ < 7u && 0xdc378faeu);
            }
        }
        u0 += (unsigned)(i1 && a0[u1 & 3u]);
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + ((unsigned)(w0 >> 29) - 0x26ddf827u));
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((0xde04e2a3u * (unsigned)h0)) break;
        }
        while ((unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)(short)(*q0 + (unsigned)d0);
            a0[~((unsigned)c1 ^ *q0) & 3u] = (unsigned)((unsigned)(((unsigned)h0 % (i1 | 1u)) == (unsigned)(u3 < i1)) && 0x27fdbf57u);
            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)c1 == (0x80000000u / (g1 | 1u))) & 1023u);
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return -((r0.y ? (unsigned)e0 : ((unsigned)c1 | 0x730d53c4u)) >> (u1 & 31u));
            }
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)f0 < (unsigned)(w0 >> 29)) & 255u);
            if ((unsigned)(p0 == i0)) break;
        }
    }
    l0 = (long)((unsigned long)l0 + ((unsigned)(x0 >> 70) >> ((unsigned)h1 & 31u)));
    m0 ^= a0[i0 & 3u];
    *mp = ((unsigned)(0xffffffffu && *q0) & (unsigned)c1);
    if ((0xe5e8bdadu / ((unsigned)(*mp && (unsigned)b0) | 1u))) {
        if ((unsigned)!((unsigned)f0 | 0x1c8c775au)) goto L4;
        garr[(unsigned)(x0 >> 70) & 7u] = (unsigned)((int)(unsigned)((short)0x7fffffffu > (signed char)a0[u1 & 3u]) < (int)(a0[u1 & 3u] << ((unsigned)(signed char)((unsigned)l0 ^ i0) & 31u)));
        if (fuel < 8u) return (unsigned)((unsigned)x0 < 0x10000u);
        u2 += 4u;
        do { if (--fuel == 0u) goto done;
            break; (void)(fuel);
            g0 = (unsigned)(u0 == garr[u2 & 7u]);
            c1 = (signed char)(0xc1c03412u & a0[u1 & 3u]);
            break; (void)((*q0 & g1));
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(unsigned char)((unsigned)((int)*mp < (int)p0) - 0xd43cf738u)) break;
                if (3u) break;
                switch ((u3 >> (7u & 31u)) & 7u) {
                    goto L2;
                    r0.x = (unsigned)((int)(unsigned)(w0 >> 29) >= (int)8u);
                }
                do { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + fuel);
                } while (i2++ < 2u && *mp);
            }
        } while (i0++ < 2u && (g1 & p0));
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (0x80000000u & 7u) {
            u3 = (unsigned)(short)((unsigned)x0 + (unsigned)((7u << (1u & 31u)) && (unsigned)l0));
            v0 = -(fuel << (p1 & 31u));
            c1 = (signed char)(0x10000u & fuel);
            for (;;) { if (--fuel == 0u) goto done;
                *mp = 0xbeaeda8eu;
                case 2u: ;
                case 1u: ;
                *mp = (unsigned)h0;
            }
        }
        if ((-(0x577017bdu + 4u) - i2)) break;
    }
    *q0 += ((unsigned)(0x5939269bu < (unsigned)((unsigned)l0 || (unsigned)w0)) * g0);
    switch (u2 & 7u) {
        case 0u: ;
        if ((unsigned)(a0[i0 & 3u] && (unsigned)((unsigned)s0 < u1))) {
            default: ;
            h0 = (short)(unsigned)((int)(~(unsigned)(0x3f103bd2u || r0.y) * garr[i1 & 7u]) >= (int)u3);
            *mp = (0x7fffffffu ? p1 : 3u);
            { unsigned t0; double z0; if ((((0x7fffffffu >> ((unsigned)x0 & 31u)) % (0xffffffffu | 1u))) & 1u) { t0 = 0xddfa310eu; z0 = (double)((((unsigned)s0 * r0.x)) & 255u); } if ((((0x7fffffffu >> ((unsigned)x0 & 31u)) % (0xffffffffu | 1u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                *mp = (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)e0);
                case 3u: ;
            }
            break; (void)((unsigned)(g1 == (unsigned)h0));
            u0 = (((garr[i1 & 7u] + garr[u2 & 7u]) & *q0) ^ r0.y);
        }
    }
    while (i0++ < 5u && (r0.x % (p2 | 1u))) { if (--fuel == 0u) goto done;
        h0 = (short)((unsigned)c1 + (unsigned)s0);
        r0.x = garr[u2 & 7u];
        if ((unsigned)((short)u1 > (signed char)i2)) {
            if (garr[u2 & 7u]) goto L4;
            u3 += (i1 ? (unsigned)d0 : 0x10000u);
            break; (void)((*q0 + v0));
            a0[v0 & 3u] = (unsigned)((short)(unsigned)(((unsigned)h0 | r0.x) == (*mp + (unsigned)b0)) > (signed char)0xffffffffu);
        }
        if ((0x80000000u ^ r0.y)) break;
    }
    if ((unsigned)((unsigned)(unsigned char)(m0 - (unsigned)c0) < i1)) goto L2;
    if ((unsigned)(*mp == 0x7fffffffu)) goto L1;
    while (i0++ < 6u && (unsigned)((unsigned)w0 && ((unsigned)(w0 >> 29) / ((unsigned)x0 | 1u)))) { if (--fuel == 0u) goto done;
        v0 = (3u | (unsigned)s1);
        if (0x89d70845u) {
            while (i1++ < 4u && (8u / ((9u | *mp) | 1u))) { if (--fuel == 0u) goto done;
                r0.y ^= (i1 & garr[u2 & 7u]);
                h0 = (short)((r0.x >> (u3 & 31u)) >> (v0 & 31u));
                *q0 += (unsigned)(0x268d40fau == (unsigned)(signed char)((i0 | (unsigned)b0) ^ 2u));
                w0 = w0 * 6364136223846793005ull + ((unsigned)s0 / (*q0 | 1u));
                *q0 += (unsigned)(r0.y && u2);
            }
        }
        for (;;) { if (--fuel == 0u) goto done;
            v0 = i1;
            if ((v0 ? g1 : 0xf2351b5bu)) {
                if ((5u * (0xffffffffu / (7u | 1u)))) continue;
                if (((unsigned)((int)(unsigned)h0 < (int)(unsigned)w0) & u3)) break;
                do { if (--fuel == 0u) goto done;
                    { unsigned t1; double z1; if ((p1) & 1u) { t1 = (unsigned)(0x66f85a26u && 8u); z1 = (double)(((u2 ^ (8u / (a0[i0 & 3u] | 1u)))) & 255u); } if ((p1) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                        c0 = (unsigned char)(unsigned)((4u ^ *q0) || (unsigned)(0xba27be21u < (unsigned)h1));
                        break; (void)(((unsigned)s1 << (1u & 31u)));
                        if (((unsigned)c1 % ((u0 | *q0) | 1u))) break;
                        a0[(unsigned)(r0.x < m0) & 3u] = p1;
                        break; (void)(~((unsigned)h1 | (0xde6ca7d6u / (0x910d5be4u | 1u))));
                        if (u3 == 7u) return (((unsigned)c1 << ((unsigned)c0 & 31u)) + (4u / (*q0 | 1u)));
                    }
                    garr[-(i0 % (i1 | 1u)) & 7u] = (p0 ? (unsigned)x0 : (unsigned)!(i2 | 0x80000000u));
                    while ((unsigned)((int)u0 >= (int)(unsigned)(0xe7b138dfu < garr[u2 & 7u]))) { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + (unsigned)((*mp / (i1 | 1u)) == (0x541b2ee4u + (unsigned)((short)i1 > (signed char)u0)));
                        *mp = (p2 * (unsigned)s1);
                    }
                    if (((unsigned)(x0 >> 70) + *q0)) break;
                } while (i2++ < 6u && (unsigned)((int)i2 < (int)(u2 / (0xffffffffu | 1u))));
                if ((unsigned)(a0[i0 & 3u] || (unsigned)h0)) break;
            } else {
                h1 = (unsigned short)(h1 + (unsigned)(u3 == (8u << ((unsigned)d0 & 31u))));
                break; (void)(a0[i0 & 3u]);
                u3 ^= g1;
                i2 = (unsigned)(unsigned char)(unsigned)((fuel << ((unsigned)(g1 < 0xcbcb6c4du) & 31u)) < (p2 / (9u | 1u))) & 15u;
            }
            x0 = x0 * 0x100000001b3ull + (*q0 + fuel);
            if ((unsigned)(1u && 7u)) {
                v0 = (unsigned)((g1 % (a0[i0 & 3u] | 1u)) || 9u);
                h1 = (unsigned short)(h1 + 0xb17b0ff4u);
            } else {
                if ((unsigned)b0) break;
                w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(unsigned)(garr[i1 & 7u] < 0x2b676ed9u);
                x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)!(*mp & fuel) && *mp) / ((unsigned)l0 | 1u));
            }
            continue; (void)(((unsigned)b0 ^ ((unsigned)s1 * garr[u2 & 7u])));
            if ((unsigned)((a0[i0 & 3u] / (0x54354ba3u | 1u)) || (unsigned)(w0 >> 29))) continue;
        }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            u1 = u1 * 0x9e3779b1u + (p1 + (fuel << ((a0[u1 & 3u] + m0) & 31u)));
            g0 = (((unsigned)b0 ^ (unsigned)(x0 >> 70)) + 0x80000000u);
            w0 = w0 * 6364136223846793005ull + ((unsigned)e0 & (unsigned)(0x80000000u || (fuel / ((unsigned)h1 | 1u))));
            for (;;) { if (--fuel == 0u) goto done;
                g0 = (u0 >> (g1 & 31u));
            }
            u1 = u1 * 0x9e3779b1u + (unsigned)(m0 == ((p1 / (0x80000000u | 1u)) << (u0 & 31u)));
            if ((i0 * 0xae433831u)) break;
        }
        if ((unsigned)(a0[u1 & 3u] == 0x7fffffffu)) break;
        if ((0x80000000u ? r0.x : 3u)) break;
    }
    if ((unsigned)(m0 || (unsigned)h1)) {
        f0 = f0 * 0.5f + (float)((((unsigned)((unsigned)s1 < (unsigned)(short)(unsigned)(r0.x == (unsigned)l0)) - u0) + 0xc3d0262cu) & 255u);
    } else {
        switch (4u & 7u) {
            case 6u: ;
            switch ((unsigned)(signed char)(unsigned)(0x80000000u && (i2 - 0x80000000u)) & 7u) {
                case 3u: ;
                x0 = x0 * 0x100000001b3ull + 6u;
            }
            if (((unsigned)((int)(unsigned)d0 >= (int)0x30edfb51u) << ((unsigned)(w0 >> 29) & 31u))) goto L2;
            u2 = u2 * 0x9e3779b1u + (0x4b87bb29u << ((unsigned)((short)p1 > (signed char)0x80000000u) & 31u));
            while ((unsigned)((short)u2 > (signed char)(unsigned)h1)) { if (--fuel == 0u) goto done;
                continue; (void)((unsigned)(signed char)(0x7fffffffu ^ 5u));
                *q0 = (unsigned)(unsigned char)(0xffffffffu << (i1 & 31u));
            }
        }
    }
    c0 = (unsigned char)((unsigned)d0 / ((unsigned)e0 | 1u));
    { unsigned t2; double z2; if ((((unsigned)((unsigned)(x0 >> 70) == garr[u2 & 7u]) | (unsigned)f0)) & 1u) { t2 = (unsigned)(unsigned char)(p0 << (0u & 31u)); z2 = (double)((g0) & 255u); } if ((((unsigned)((unsigned)(x0 >> 70) == garr[u2 & 7u]) | (unsigned)f0)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        if (0x10000u) {
            if ((unsigned)e0) goto done;
        } else {
            *q0 = i0;
        }
        switch ((unsigned)((int)(unsigned)s0 < (int)6u) & 7u) {
            *mp = (unsigned)((int)0x7fffffffu < (int)(unsigned)f0);
            s1 = (int)((unsigned)s1 + (unsigned)(short)(unsigned)(0x95cb339fu < (unsigned)(unsigned char)((unsigned)((int)(unsigned)h1 >= (int)0xc26352d8u) << (i1 & 31u))));
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    g0 = ((*q0 * a0[u1 & 3u]) * ((unsigned)x0 / ((g0 & 0x80000000u) | 1u)));
                    case 7u: ;
                    d0 = d0 * 0.5 + (double)((0x80000000u - (unsigned)x0) & 1023u);
                }
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 5u: ;
                    break; (void)((unsigned)(w0 >> 29));
                }
                { unsigned t3; double z3; if ((p0) & 1u) { t3 = (m0 * p0); z3 = (double)((p2) & 255u); } if ((p0) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    case 1u: ;
                    { unsigned t4; double z4; if (((unsigned)((unsigned)d0 && (unsigned)(x0 >> 70))) & 1u) { t4 = ((unsigned)c1 - (unsigned)!(unsigned)((short)u1 > (signed char)a0[i0 & 3u])); z4 = (double)(((unsigned)(r0.y < (unsigned)d0)) & 255u); } if (((unsigned)((unsigned)d0 && (unsigned)(x0 >> 70))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                        case 6u: ;
                    }
                    if (fuel < 8u) return (unsigned)((5u * ((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)d0) - (unsigned)d0)) || i1);
                    { unsigned t5; double z5; if ((p1) & 1u) { t5 = ((unsigned)b0 ^ *mp); z5 = (double)((m0) & 255u); } if ((p1) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                        default: ;
                        r0.y ^= ((i0 / ((unsigned)h0 | 1u)) ? (unsigned)s1 : (unsigned)s1);
                    }
                    if ((0x907dc8d2u + g1)) {
                        g0 = (unsigned)(short)(u0 & (((unsigned)h0 % (p0 | 1u)) * ((unsigned)l0 >> (u0 & 31u))));
                        break;
                        break;
                        case 0u: ;
                        continue; (void)((unsigned)h1);
                        break;
                    } else {
                        r0.y ^= ((0xacc9781eu + u1) >> ((unsigned)((int)0u < (int)(garr[i1 & 7u] & r0.y)) & 31u));
                        break;
                        break;
                        *q0 = (unsigned)w0;
                    }
                    if (a0[u1 & 3u]) break;
                }
                case 4u: ;
            }
            w0 ^= (unsigned long long)v0 << ((*q0 ? p0 : (unsigned)b0) & 63u);
        }
    }
    w0 = w0 * 6364136223846793005ull + ((unsigned)!(u1 - p1) & (i1 << (7u & 31u)));
    if (v0) goto L0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    m0 ^= (unsigned)((int)(unsigned)(p1 || u0) < (int)(unsigned)((short)((unsigned)b0 * g0) > (signed char)i0));
    for (;;) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)(((unsigned)w0 ^ (unsigned)(x0 >> 70)) & 1023u);
        garr[(unsigned)h0 & 7u] = (i0 & *q0);
    }
    { unsigned t0; double z0; if (((unsigned)e0) & 1u) { t0 = 8u; z0 = (double)(((unsigned)((int)(0x10000u + g1) < (int)p1)) & 255u); } if (((unsigned)e0) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        h0 = (short)(unsigned)((short)0x7fffffffu > (signed char)(unsigned)(garr[i1 & 7u] < 5u));
        if ((unsigned)x0) goto L4;
        x0 = x0 * 0x100000001b3ull + 0x10000u;
        if (((unsigned)w0 & a0[u1 & 3u])) goto L3;
    }
    u0 += (8u - (unsigned)((short)(0x54379c47u / ((unsigned)((unsigned)l0 || (unsigned)h0) | 1u)) > (signed char)8u));
    switch ((unsigned)((int)(unsigned)d0 >= (int)(unsigned)(signed char)(unsigned)((int)(unsigned)b0 >= (int)(unsigned)(w0 >> 29))) & 7u) {
        if ((unsigned)!(unsigned)((int)(unsigned)d0 >= (int)(unsigned)f0)) {
            L0: if (--fuel == 0u) goto done;
            switch ((unsigned)s0 & 7u) {
                if (i0) break;
                L1: if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(x0 >> 70) < 9u);
                c0 = (unsigned char)-(unsigned)(garr[u2 & 7u] || u1);
                l0 = (long)((unsigned long)l0 + (((unsigned)((int)r0.y >= (int)i0) ^ 0xffffffffu) & 0x10000u));
            }
        }
        if (0xe749cbc9u) break;
        if ((unsigned)!(0xc6d2e32fu >> ((0xffffffffu - (unsigned)x0) & 31u))) goto L4;
        *q0 += ((unsigned)x0 % ((unsigned)l0 | 1u));
    }
    *q0 += ((unsigned)l0 ? (unsigned)d0 : (unsigned)e0);
    h1 = (unsigned short)(h1 + (unsigned)((unsigned)!((i1 ^ (unsigned)((int)a0[i0 & 3u] < (int)0x7fffffffu)) << (0x10000u & 31u)) == r0.y));
    s0 = (int)0x21ffcb07u;
    *q0 = (unsigned)((int)(((unsigned)c1 | (unsigned)s1) * (0xffffffffu / ((unsigned)d0 | 1u))) >= (int)0x10000u);
    do { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + -(m0 ^ (unsigned)(a0[i0 & 3u] || 0x538e6cb4u)));
        break; (void)(0u);
        if (0x7fffffffu) goto L4;
        u0 = i0;
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(2u % (a0[u1 & 3u] | 1u)), a0[i0 & 3u], (unsigned)(*q0 == m0)); }
    } while (i0++ < 4u && (unsigned)(p1 == (unsigned)s0));
    if (budget != 0u) { budget -= 1u; u2 = fn0(0u, (0xffffffffu - (unsigned)(p0 == (unsigned)d0)), ((unsigned)(unsigned char)(unsigned)(m0 == u2) ^ 0xf644239fu)); }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((short)0x80000000u > (signed char)i2)) {
            L2: if (--fuel == 0u) goto done;
            goto L3;
            L3: if (--fuel == 0u) goto done;
            u0 = (unsigned)w0;
        }
        if (0x10000u) goto L1;
        w0 ^= (unsigned long long)(unsigned)c1 << (a0[i0 & 3u] & 63u);
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((i0 / (u2 | 1u))) goto L2;
            *q0 += (0xffffffffu / ((unsigned)((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)l0) < (unsigned)(x0 >> 70)) | 1u));
            *q0 += (unsigned)((r0.x | garr[u2 & 7u]) == i2);
            d0 = d0 * 0.5 + (double)((unsigned)(m0 && (0xe794bfd5u << ((unsigned)(x0 >> 70) & 31u))) & 1023u);
        }
        if ((r0.y | (unsigned)e0)) {
            d0 = d0 * 0.5 + (double)(u1 & 1023u);
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((0x80000000u * (unsigned)d0) || 8u)) break;
            } while (i1++ < 3u && 0xffffffffu);
        }
        if ((r0.x >> (m0 & 31u))) break;
    } while (i0++ < 4u && (unsigned)((int)0x8e33222u >= (int)(u1 << (0xc107703du & 31u))));
    { unsigned t1; double z1; if (((unsigned)((short)(m0 << (0xf43cf7e2u & 31u)) > (signed char)0u)) & 1u) { t1 = ((5u / (a0[u1 & 3u] | 1u)) >> (v0 & 31u)); z1 = (double)(((unsigned)((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)h0) == *q0)) & 255u); } if (((unsigned)((short)(m0 << (0xf43cf7e2u & 31u)) > (signed char)0u)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            goto done;
        }
        a0[0x10000u & 3u] = (unsigned)(((unsigned)c1 % (a0[i0 & 3u] | 1u)) == (unsigned)(5u == u0));
        do { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)u1 << ((i1 % ((0xae7277e2u * (unsigned)((int)5u >= (int)(unsigned)c0)) | 1u)) & 63u);
            do { if (--fuel == 0u) goto done;
                goto L0;
                if (budget != 0u) { budget -= 1u; u1 = fn0((v0 & (unsigned)((int)a0[i0 & 3u] < (int)0x80000000u)), (unsigned)((unsigned)c0 < (p2 % (p2 | 1u))), (unsigned)((int)(unsigned)f0 < (int)*mp)); }
            } while (i1++ < 3u && fuel);
        } while (i0++ < 6u && (unsigned)s0);
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!(unsigned)(g1 == 0x10000u), 7u, ((i1 * (unsigned)f0) / (v0 | 1u))); }
        if ((unsigned)c1) goto L1;
    }
    c0 = (unsigned char)(unsigned)(u0 && (unsigned)!(unsigned)((unsigned)s1 || (unsigned)!(p2 * u0)));
    c0 = (unsigned char)(*mp >> ((unsigned)w0 & 31u));
    if (0x97939687u) goto L3;
    if (u3 == 7u) return (unsigned)((unsigned)l0 < (unsigned)!(unsigned)(((0x7e32be04u % (0xef98beabu | 1u)) % (0xffffffffu | 1u)) && i2));
    switch ((0xba0480cdu + (unsigned)(0x6697f624u && (unsigned)f0)) & 7u) {
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)((short)0x6f408282u > (signed char)0x10000u);
            g0 = (((unsigned)f0 + 0x44526c57u) * 2u);
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(unsigned char)((unsigned)c1 * 0x10000u), (unsigned)(r0.x && 0xffffffffu), (*q0 - ((unsigned)l0 >> (4u & 31u)))); }
            L4: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((p2 ^ 0x10000u), (unsigned)((int)0xa00a1a8au >= (int)0x10000u), i1); }
            u2 = (unsigned)(0x10000u || (unsigned)((int)(unsigned)(0x80000000u == 0xffffffffu) >= (int)0x7fffffffu));
        }
        if ((unsigned)(8u || (unsigned)(8u && (unsigned)s0))) {
            u3 += (0x7fffffffu % (i1 | 1u));
            switch ((0x8c8138e2u << ((unsigned)(x0 >> 70) & 31u)) & 7u) {
                garr[g1 & 7u] = ((unsigned)(g0 || m0) >> (u0 & 31u));
                g0 = ((1u ? 8u : (unsigned)c0) + v0);
                case 2u: ;
            }
        } else {
            if (((unsigned)b0 / (i0 | 1u))) goto L0;
            switch ((a0[u1 & 3u] << ((unsigned)x0 & 31u)) & 7u) {
                while (i0++ < 2u && (unsigned)(i2 == 4u)) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + 0xffffffffu;
                    d0 = d0 * 0.5 + (double)((p1 + i0) & 1023u);
                    q0 = &garr[((unsigned)c1 + (unsigned)((unsigned)(short)(p2 ? (unsigned)(w0 >> 29) : fuel) && 9u)) & 7u];
                    case 2u: ;
                    u0 = (unsigned)((int)(unsigned)((int)(unsigned)e0 < (int)((unsigned)s0 - (unsigned)((int)g0 < (int)a0[i0 & 3u]))) >= (int)(unsigned)b0);
                }
                { unsigned t2; double z2; if (((unsigned)c0) & 1u) { t2 = (v0 * (unsigned)f0); z2 = (double)(((*q0 / (u0 | 1u))) & 255u); } if (((unsigned)c0) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    default: ;
                    garr[a0[u1 & 3u] & 7u] = (unsigned)((int)((unsigned)c0 ? 3u : *q0) >= (int)(unsigned)(short)(unsigned)((unsigned)s1 || (unsigned)x0));
                    w0 ^= (unsigned long long)(garr[i1 & 7u] - 4u) << (((garr[u2 & 7u] % (0xffffffffu | 1u)) & (unsigned)x0) & 63u);
                    garr[0xdc837ab3u & 7u] = (unsigned)(signed char)(0x19662d16u * 0x6562a5a6u);
                }
                b0 = (unsigned)(signed char)(unsigned)(garr[i1 & 7u] || u3) != 0u;
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    u0 += 0x7fffffffu;
                    case 5u: ;
                    v0 = (u3 | (u2 & (g0 << ((unsigned)(w0 >> 29) & 31u))));
                    g0 = ((unsigned)((int)*q0 >= (int)(unsigned)c1) - (unsigned)(0x80000000u || (unsigned)(5u < (unsigned)c0)));
                    *q0 += 0xb257f6eau;
                    if ((g0 / ((unsigned)l0 | 1u))) continue;
                }
                u3 += (g0 >> ((unsigned)(signed char)(unsigned)(1u || 0x10000u) & 31u));
            }
            f0 = f0 * 0.5f + (float)(((unsigned)f0 / (0x10000u | 1u)) & 255u);
        }
        case 5u: ;
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 5u && ((unsigned)((int)(unsigned)f0 < (int)(unsigned)l0) >> (0x10000u & 31u))) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)((v0 << (((unsigned)b0 + (unsigned)e0) & 31u)) << (u1 & 31u));
                { unsigned t3; double z3; if ((u3) & 1u) { t3 = 1u; z3 = (double)(((i2 ? r0.x : (unsigned)h1)) & 255u); } if ((u3) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                    switch (0x10000u & 7u) {
                        if ((unsigned)d0) break;
                        break; (void)((p1 | a0[u1 & 3u]));
                    }
                    s1 = (int)((unsigned)s1 + ((unsigned)l0 - (unsigned)((int)(unsigned)(short)(r0.x / (((unsigned)c1 << ((unsigned)f0 & 31u)) | 1u)) < (int)(unsigned)e0)));
                }
            }
            g0 = (unsigned)(((unsigned)h0 + (u3 + p1)) < 3u);
            s0 = (int)(((unsigned)c0 << ((unsigned)((unsigned)f0 < 0x10000u) & 31u)) / (0x10000u | 1u));
            case 3u: ;
        }
        i2 = (r0.y % (g1 | 1u)) & 15u;
    }
    while (i0++ < 4u && 0x10000u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (r0.y + (unsigned)((g1 & 0u) == r0.y)));
        w0 = w0 * 6364136223846793005ull + ((unsigned)h1 / ((unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)b0) | 1u));
        u0 = u0 * 0x9e3779b1u + -(((unsigned)l0 << (p0 & 31u)) + ((i2 & *mp) % (0x10000u | 1u)));
        w0 = w0 * 6364136223846793005ull + (unsigned)((short)a0[i0 & 3u] > (signed char)0x7fffffffu);
        do { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (a0[i0 & 3u] & v0);
                    *q0 = (unsigned)((int)(unsigned)b0 >= (int)((g1 + 2u) % (0xffffffffu | 1u)));
                }
                if (g0) continue;
                s1 = (int)((unsigned)s1 + ((unsigned)(x0 >> 70) >> ((unsigned)((unsigned)h0 || 0x14693f92u) & 31u)));
                s1 = (int)((unsigned)s1 + ((unsigned)(g0 < p1) ^ (unsigned)(unsigned char)(unsigned)(g0 || 0xd234884fu)));
                f0 = f0 * 0.5f + (float)((unsigned)(((0xffffffffu - garr[i1 & 7u]) - (unsigned)b0) < (unsigned)c1) & 255u);
            }
            w0 ^= (unsigned long long)(unsigned)(x0 >> 70) << ((unsigned)(signed char)(unsigned)(((unsigned)(w0 >> 29) >> (0x80000000u & 31u)) < (unsigned)((short)*mp > (signed char)u3)) & 63u);
            if ((p0 + -(r0.y << (0u & 31u)))) goto L0;
            { unsigned t4; double z4; if ((((i0 ^ (unsigned)l0) >> (0u & 31u))) & 1u) { t4 = (unsigned)f0; z4 = (double)(((g1 - (unsigned)(w0 >> 29))) & 255u); } if ((((i0 ^ (unsigned)l0) >> (0u & 31u))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                if ((unsigned)((short)(unsigned)l0 > (signed char)(0xd3c697b0u - 5u))) goto done;
                break; (void)(a0[i0 & 3u]);
                if (((unsigned)(0x7fffffffu < (unsigned)x0) / (0x5a643fa8u | 1u))) break;
                { unsigned t5; double z5; if ((((unsigned)d0 << ((r0.x | r0.x) & 31u))) & 1u) { t5 = a0[u1 & 3u]; z5 = (double)(((unsigned)e0) & 255u); } if ((((unsigned)d0 << ((r0.x | r0.x) & 31u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    if (~((0xffffffffu & 0xa8616c63u) / (0x86d0f8b3u | 1u))) break;
                    if ((r0.x * 7u)) break;
                }
            }
            while (i2++ < 7u && ((0x80000000u >> (*q0 & 31u)) & fuel)) { if (--fuel == 0u) goto done;
                c1 = (signed char)(unsigned)((int)p2 >= (int)(unsigned)c1);
            }
            l0 = (long)((unsigned long)l0 + 0x3a4e3ffu);
        } while (i1++ < 6u && a0[i0 & 3u]);
        break; (void)((0x88a3d481u * 0xffffffffu));
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(short)(i0 / (0x609c402du | 1u))) break;
        u3 ^= (v0 | (0x8a735940u * (unsigned)f0));
        f0 = f0 * 0.5f + (float)(((unsigned)((unsigned)(garr[i1 & 7u] == *mp) || r0.y) | (0x76267238u - u3)) & 255u);
        r0.x = a0[i0 & 3u];
    }
    do { if (--fuel == 0u) goto done;
        if (((unsigned)(signed char)(unsigned)(u0 || (unsigned)e0) | fuel)) {
            *mp = (unsigned)d0;
            if ((1u | u2)) goto L0;
        } else {
            continue; (void)(((unsigned)(w0 >> 29) * p2));
            if (u3 == 7u) return m0;
            w0 ^= (unsigned long long)(m0 << (4u & 31u)) << (0x44bac34bu & 63u);
            a0[fuel & 3u] = 0xb79a031du;
        }
        switch ((unsigned)((short)4u > (signed char)(i2 ^ 0xffffffffu)) & 7u) {
            s1 = (int)((unsigned)s1 + (3u ^ (m0 * g1)));
            goto L1;
            if (8u) goto done;
            { unsigned t6; double z6; if (((i0 & (unsigned)d0)) & 1u) { t6 = (a0[u1 & 3u] % (((unsigned)h0 / (fuel | 1u)) | 1u)); z6 = (double)((0x7fffffffu) & 255u); } if (((i0 & (unsigned)d0)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                m0 ^= (r0.y - (unsigned)(short)(*q0 << ((unsigned)h1 & 31u)));
                switch ((unsigned)(unsigned char)(unsigned)((unsigned)s0 || g1) & 7u) {
                    s0 = (int)(unsigned)(u3 == (0u * i0));
                    g0 = (unsigned)((unsigned)((int)*mp < (int)r0.y) < (i2 ^ (unsigned)x0));
                    g1 += (unsigned)((unsigned)c1 == i1);
                    case 0u: ;
                    x0 = x0 * 0x100000001b3ull + 0xfa90029eu;
                    { unsigned t7; double z7; if ((((unsigned)c1 & u2)) & 1u) { t7 = *mp; z7 = (double)(((unsigned)s0) & 255u); } if ((((unsigned)c1 & u2)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                        q0 = &garr[(unsigned)((int)r0.y < (int)((unsigned)e0 & (unsigned)f0)) & 7u];
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(u0 && r0.x) | (unsigned)l0), (((unsigned)x0 & a0[u1 & 3u]) * a0[i0 & 3u]), (unsigned)(i0 && v0)); }
                        i0 = (unsigned)!((unsigned)((unsigned)f0 == (unsigned)s1) + 0xb89869c4u) & 15u;
                        b0 = (unsigned)(short)(unsigned)((unsigned)f0 && (unsigned)(short)(unsigned)(i0 && (unsigned)!(3u ? p1 : u1))) != 0u;
                    }
                }
                if ((unsigned)((v0 | a0[i0 & 3u]) || (unsigned)(w0 >> 29))) goto done;
                u1 = (*mp >> (-(unsigned)((u2 & (unsigned)(w0 >> 29)) == 0x7fffffffu) & 31u));
                case 7u: ;
                { unsigned t8; double z8; if (((0x7fffffffu ^ p0)) & 1u) { t8 = (m0 ? g1 : garr[i1 & 7u]); z8 = (double)((-(r0.y ? (unsigned)l0 : (unsigned)(w0 >> 29))) & 255u); } if (((0x7fffffffu ^ p0)) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                    case 1u: ;
                    if (((unsigned)(signed char)(v0 >> (garr[i1 & 7u] & 31u)) >> (9u & 31u))) break;
                    a0[r0.y & 3u] = (unsigned)((int)0x80000000u >= (int)u0);
                }
            }
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 += (0x10000u ^ r0.x);
                garr[g1 & 7u] = ((p1 * r0.x) | (unsigned)((int)r0.x < (int)0x3a3bb738u));
                default: ;
                s0 = (int)(u1 / (~((unsigned)h0 ^ *q0) | 1u));
            }
        }
    } while (i0++ < 6u && a0[u1 & 3u]);
    if (u3 == 7u) return ((unsigned)((int)(unsigned)s1 < (int)i0) + ((unsigned)x0 ? (unsigned)b0 : 0x5e7d1066u));
    u0 += (i0 ^ (unsigned)(fuel < (unsigned)s1));
    switch ((unsigned)e0 & 7u) {
        while (i0++ < 3u && (u1 >> (u0 & 31u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((u3 ^ (unsigned)h0), (unsigned)((unsigned)h0 == (a0[i0 & 3u] | u2)), 0xd0dd2fe4u); }
            h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)((int)(unsigned)h1 < (int)(unsigned)s1) >= (int)(unsigned)((short)u1 > (signed char)r0.y)));
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            continue; (void)(((unsigned)s0 ^ r0.y));
            case 7u: ;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)fuel < (int)(unsigned)(signed char)(unsigned)((int)9u >= (int)p0)), *mp, (0x10000u * *q0)); }
            s0 = (int)(unsigned)((unsigned)b0 && (unsigned)!((unsigned)(0x10000u < (unsigned)x0) | (unsigned)(x0 >> 70)));
            u1 ^= 9u;
            u0 = u0 * 0x9e3779b1u + 0x80000000u;
        }
    }
    e0 = e0 * 0.5L + (long double)(((u1 * ((0xf1ecebdcu << ((unsigned)f0 & 31u)) ^ 0x80000000u)) >> (fuel & 31u)) & 1023u);
    do { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)((short)i0 > (signed char)(unsigned)(a0[i0 & 3u] < (unsigned)((int)(unsigned)(0xf0a5c30fu < a0[u1 & 3u]) >= (int)(unsigned)c0))));
    } while (i0++ < 2u && (unsigned)!((i1 & garr[u2 & 7u]) - 9u));
    *mp = (((unsigned)s1 | (unsigned)((unsigned)(x0 >> 70) && (unsigned)b0)) ^ 0x6e8f5232u);
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        garr[g0 & 7u] = (g0 % (~(unsigned)((unsigned)c1 < (r0.x | 0x3e30d7c5u)) | 1u));
    }
    if ((((unsigned)l0 + 7u) << (0xffffffffu & 31u))) goto L1;
    if ((unsigned)((int)(unsigned)b0 < (int)(unsigned)(short)(unsigned)((unsigned)s0 && (unsigned)f0))) {
        if ((unsigned)s1) goto done;
    }
    x0 = x0 * 0x100000001b3ull + (g0 >> ((unsigned)(m0 && (unsigned)s0) & 31u));
    if (3u) goto L4;
    *mp = (9u + u3);
    if (budget != 0u) { budget -= 1u; u0 = fn0((0xfd302c59u | 0u), (unsigned)b0, (unsigned)h0); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)((int)((unsigned)s1 & 6u) < (int)0x7fffffffu)) {
        u3 ^= (unsigned)s0;
        b0 = (unsigned)((int)r0.x >= (int)(unsigned)s0) != 0u;
        L0: if (--fuel == 0u) goto done;
    }
    L1: if (--fuel == 0u) goto done;
    while (i0++ < 7u && (unsigned)(unsigned char)(fuel & ((unsigned)c0 / (a0[i0 & 3u] | 1u)))) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            switch ((unsigned)(signed char)(unsigned)(m0 == garr[i1 & 7u]) & 7u) {
                do { if (--fuel == 0u) goto done;
                    a0[(unsigned)c1 & 3u] = (r0.x ? (unsigned)c1 : (0x80000000u | 0x10000u));
                    if (((unsigned)h0 & ((unsigned)x0 | u0))) continue;
                    c0 = (unsigned char)(unsigned)((short)(unsigned)((int)g0 >= (int)r0.y) > (signed char)(unsigned)h1);
                    { unsigned t0; double z0; if ((0x2e834564u) & 1u) { t0 = (unsigned)(a0[u1 & 3u] || (unsigned)(i2 && fuel)); z0 = (double)(((p2 - (unsigned)(signed char)(unsigned)((int)(unsigned)(x0 >> 70) < (int)*mp))) & 255u); } if ((0x2e834564u) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                        if ((unsigned)(signed char)((unsigned)c1 ^ 0x10000u)) {
                            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(x0 >> 70), (0x88ee5336u / ((fuel - 0x1b642f5u) | 1u)), (unsigned)(fuel == fuel)); }
                            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(2u || (unsigned)c1), ((unsigned)((short)(unsigned)b0 > (signed char)r0.x) | i2), ((unsigned)b0 - 3u)); }
                            L2: if (--fuel == 0u) goto done;
                            g0 = (v0 - ((unsigned)(unsigned char)(unsigned)((unsigned)s0 == u3) | (unsigned)h1));
                            w0 ^= (unsigned long long)0x51ac5603u << ((unsigned)s0 & 63u);
                        } else {
                            if (budget != 0u) { budget -= 1u; u1 = fn1(((0x8035d51du / ((unsigned)s1 | 1u)) | (unsigned)(w0 >> 29)), (unsigned)((int)(unsigned)l0 >= (int)u0), (v0 - ((unsigned)d0 & a0[i0 & 3u]))); }
                            h0 = (short)u1;
                            case 2u: ;
                            if ((0x10000u % ((unsigned)e0 | 1u))) goto L4;
                        }
                        if (u3) break;
                        *q0 = (unsigned)(signed char)((unsigned)(r0.x && 0x10000u) ^ (unsigned)((0x10000u | 0x9ea7025au) && 0u));
                    }
                } while (i2++ < 2u && (unsigned)h1);
                goto L0;
                i1 = (unsigned)((int)(unsigned)(w0 >> 29) >= (int)(a0[u1 & 3u] / (a0[i0 & 3u] | 1u))) & 15u;
                switch ((r0.y & 8u) & 7u) {
                    r0.y ^= (1u ? (unsigned)(0x10000u == a0[i0 & 3u]) : (unsigned)(signed char)((unsigned)b0 >> (i2 & 31u)));
                    c0 = (unsigned char)0x2cc7512fu;
                }
                garr[(unsigned)d0 & 7u] = ~((unsigned)((short)p2 > (signed char)u3) & 0x80000000u);
            }
            s1 = (int)((unsigned)s1 + (unsigned)(g0 == (unsigned)((short)(0xf6218b7cu | u0) > (signed char)m0)));
            if (0x10000u) {
                if (p2) {
                    u1 = u1 * 0x9e3779b1u + (i2 * r0.x);
                    if (u1) break;
                    if (i1) {
                        b0 = (unsigned)(*mp < (*q0 % (i2 | 1u))) != 0u;
                    } else {
                        r0.y ^= (v0 ^ (unsigned)d0);
                    }
                    f0 = f0 * 0.5f + (float)((garr[u2 & 7u] - ((0xf41957e3u << ((unsigned)b0 & 31u)) * ((unsigned)c0 % ((unsigned)w0 | 1u)))) & 255u);
                    s0 = (int)0x7fffffffu;
                }
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    h0 = (short)((unsigned)(garr[u2 & 7u] && 0xf04a1434u) << (*q0 & 31u));
                    i2 = (unsigned)((short)u2 > (signed char)(unsigned)(short)(0x10000u % (0x51e9cb0cu | 1u))) & 15u;
                    m0 ^= (0xbb16690au ^ 3u);
                }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)(g1 << (0x7fffffffu & 31u)), 2u, 0xe8d240f3u); }
                c0 = (unsigned char)((unsigned)s1 / (fuel | 1u));
                if (((unsigned)((int)0xffffffffu < (int)(unsigned)f0) & (unsigned)(x0 >> 70))) break;
                if ((unsigned)((p0 >> (0xffffffffu & 31u)) || 1u)) goto L1;
            } else {
                L3: if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + ((u3 * a0[i0 & 3u]) ^ (unsigned)h1);
                s1 = (int)((unsigned)s1 + ((r0.y / (((unsigned)((short)i0 > (signed char)8u) / (6u | 1u)) | 1u)) ^ 0x8b73d4cu));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)(w0 >> 29) == garr[u2 & 7u]), (fuel / ((unsigned)((int)8u < (int)p0) | 1u)), m0); }
            h1 = (unsigned short)(h1 + (unsigned)(unsigned char)((-(garr[u2 & 7u] ? (unsigned)(w0 >> 29) : 0xe59e83e3u) % (0xffffffffu | 1u)) - i0));
        } while (i1++ < 4u && *mp);
        h1 = (unsigned short)(h1 + v0);
        do { if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if (((0x6fc29a29u >> ((a0[u1 & 3u] & *mp) & 31u))) & 1u) { t1 = i0; z1 = (double)(((unsigned)x0) & 255u); } if (((0x6fc29a29u >> ((a0[u1 & 3u] & *mp) & 31u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                L4: if (--fuel == 0u) goto done;
                if ((unsigned)l0) continue;
                if (((unsigned)((int)(unsigned)l0 < (int)0x10000u) << (0xc167ddc0u & 31u))) continue;
                s0 = (int)(((unsigned)d0 & 6u) ^ (unsigned)l0);
            }
            do { if (--fuel == 0u) goto done;
                *q0 = (unsigned)(0xffffffffu < g1);
                i2 = a0[i0 & 3u] & 15u;
                { unsigned t2; double z2; if ((v0) & 1u) { t2 = u3; z2 = (double)((i2) & 255u); } if ((v0) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    continue; (void)(p2);
                }
                if (((unsigned)l0 % (m0 | 1u))) break;
                if (budget != 0u) { budget -= 1u; u3 = fn1(p1, (*mp & (unsigned)((short)(unsigned)b0 > (signed char)*mp)), m0); }
                { unsigned t3; double z3; if (((unsigned)(1u && 0x7fffffffu)) & 1u) { t3 = ((a0[u1 & 3u] >> (0x6b3ca43du & 31u)) % (g0 | 1u)); z3 = (double)((r0.y) & 255u); } if (((unsigned)(1u && 0x7fffffffu)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    if (budget != 0u) { budget -= 1u; u2 = fn0(u0, 0u, (unsigned)(unsigned char)(unsigned)(0xf4a6a400u && (unsigned)!(0xde60484au / ((unsigned)l0 | 1u)))); }
                    if ((fuel / ((unsigned)((unsigned)(x0 >> 70) && 0x10000u) | 1u))) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn1((u0 | (0x80000000u & p2)), m0, (unsigned)(0xe391bc72u || 0xaf929826u)); }
                    if ((p1 | (unsigned)!((unsigned)w0 >> (u2 & 31u)))) {
                        break; (void)((unsigned)(short)(*mp | i0));
                        e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)((unsigned)x0 < garr[i1 & 7u]) & 1023u);
                        u1 ^= (unsigned)f0;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(0xc7712e07u && fuel), 0xc772bc60u, (p2 ? 0u : (unsigned)h0)); }
                    } else {
                        h0 = (short)(0x82d1ae30u * ((unsigned)c1 / (r0.x | 1u)));
                    }
                }
            } while (i2++ < 2u && 0x10000u);
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)d0 == (unsigned)(r0.x < 0xdcd2dec3u)), (unsigned)((short)(unsigned)(0xde0fb7u && 0x10000u) > (signed char)9u), -((g0 % ((unsigned)w0 | 1u)) & 0x81c95fa0u)); }
        } while (i1++ < 6u && (unsigned)c0);
        switch ((unsigned)((int)(unsigned)w0 < (int)(0xffffffffu >> ((unsigned)h1 & 31u))) & 7u) {
            g0 = ((0x2d78e66u - m0) * 0xb8d2a943u);
            { unsigned t4; double z4; if (((unsigned)((short)3u > (signed char)fuel)) & 1u) { t4 = m0; z4 = (double)(((p1 ^ 0xffffffffu)) & 255u); } if (((unsigned)((short)3u > (signed char)fuel)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                case 3u: ;
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    switch ((unsigned)((u1 - p0) || (unsigned)l0) & 7u) {
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)0x21d8b53u >= (int)(unsigned)((unsigned)(x0 >> 70) || 4u)), (a0[u1 & 3u] / (*mp | 1u)), (u2 - ((unsigned)h0 + 0x60f91u))); }
                    }
                    a0[*q0 & 3u] = ((unsigned)((unsigned)e0 == (a0[i0 & 3u] / (u0 | 1u))) + 7u);
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((short)a0[i0 & 3u] > (signed char)(0xfbf77219u >> (g1 & 31u))), 0xbf235c09u, (unsigned)d0); }
                }
                h1 = (unsigned short)(h1 + 0x90f4e2e3u);
                *q0 = ~(u0 ^ (((unsigned)((int)garr[u2 & 7u] < (int)0x7fffffffu) & 0x3108729du) % ((unsigned)w0 | 1u)));
                m0 ^= (unsigned)((unsigned)w0 && ((unsigned)(x0 >> 70) % ((unsigned)e0 | 1u)));
                do { if (--fuel == 0u) goto done;
                    case 5u: ;
                    case 6u: ;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(-((unsigned)(m0 && u0) >> ((unsigned)b0 & 31u)), (unsigned)(u2 < p1), ((garr[u2 & 7u] ^ u0) - a0[u1 & 3u])); }
                    garr[8u & 7u] = (6u % ((unsigned)(w0 >> 29) | 1u));
                    g0 = (unsigned)(unsigned char)(unsigned)((int)(unsigned)(short)(g1 * 0xffffffffu) >= (int)~((a0[u1 & 3u] / (0xece95dau | 1u)) - (unsigned)h0));
                } while (i1++ < 7u && (i0 >> ((unsigned)((short)0xc4c0fbe9u > (signed char)(unsigned)x0) & 31u)));
            }
            default: ;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(a0[i0 & 3u] || 0xffffffffu), (unsigned)b0, i2); }
            r0.y ^= i2;
        }
        if ((unsigned)(p0 < 0xf8ac5814u)) break;
    }
    goto L4;
    garr[garr[i1 & 7u] & 7u] = (unsigned)((int)(0x80000000u ? fuel : (unsigned)c1) >= (int)(0x10000u - (unsigned)w0));
    *q0 = ((u2 * 0x3e1a1026u) / (v0 | 1u));
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)c0 && 5u), (unsigned)c0, p1); }
    goto L1;
    { unsigned t5; double z5; if (((0xffffffffu << (9u & 31u))) & 1u) { t5 = (unsigned)(x0 >> 70); z5 = (double)(((unsigned)((unsigned)x0 == 7u)) & 255u); } if (((0xffffffffu << (9u & 31u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
        while (i0++ < 4u && (unsigned)(0x7fffffffu == (unsigned)((int)(unsigned)h1 < (int)1u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1(g1, i0, (u0 | (unsigned)e0)); }
        }
        c1 = (signed char)(unsigned)((short)g0 > (signed char)(unsigned)!((unsigned)b0 % (a0[i0 & 3u] | 1u)));
        garr[(unsigned)f0 & 7u] = (((unsigned)h1 << (v0 & 31u)) << (*mp & 31u));
        l0 = (long)((unsigned long)l0 + ((unsigned)!(unsigned)((int)a0[i0 & 3u] >= (int)g0) * -(unsigned)(0x836536c5u || 0x54e724d4u)));
        if (budget != 0u) { budget -= 1u; u2 = fn0((4u & (unsigned)(short)(0xffffffffu >> (m0 & 31u))), p0, (unsigned)(*q0 && (0u * p2))); }
    }
    g1 += (unsigned)(m0 || (unsigned)((0x5678734u & (unsigned)c0) < (unsigned)c1));
    goto L0;
    switch (((unsigned)(garr[u2 & 7u] || (unsigned)b0) << (p0 & 31u)) & 7u) {
        do { if (--fuel == 0u) goto done;
            r0.x = (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)((unsigned)d0 && (unsigned)(u3 && (3u - (unsigned)h0))));
            u3 += ~(unsigned)((int)(unsigned)c0 >= (int)(unsigned)s0);
            case 4u: ;
            default: ;
        } while (i0++ < 6u && u1);
        { unsigned t6; double z6; if ((((unsigned)e0 % ((unsigned)h0 | 1u))) & 1u) { t6 = 8u; z6 = (double)((((unsigned)(x0 >> 70) - (unsigned)(p1 < g1))) & 255u); } if ((((unsigned)e0 % ((unsigned)h0 | 1u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            h0 = (short)0xffa13c85u;
            switch ((g1 >> (0x5c6c1951u & 31u)) & 7u) {
                case 4u: ;
                d0 = d0 * 0.5 + (double)(((unsigned)((int)0xffffffffu >= (int)5u) >> (r0.y & 31u)) & 1023u);
                do { if (--fuel == 0u) goto done;
                    u1 ^= (unsigned)l0;
                } while (i0++ < 3u && (4u << (0x74b269c1u & 31u)));
                case 1u: ;
                e0 = e0 * 0.5L + (long double)((-(0x7fffffffu ^ m0) + (p2 + (unsigned)w0)) & 1023u);
                switch ((u1 & (unsigned)c0) & 7u) {
                    s1 = (int)((unsigned)s1 + (0x36219678u - (unsigned)((int)garr[i1 & 7u] < (int)0x10000u)));
                }
            }
        }
        case 0u: ;
    }
    if ((unsigned)s1) goto L4;
    if ((unsigned)(short)(unsigned)((short)u3 > (signed char)(0xffffffffu % (*mp | 1u)))) goto done;
    if (budget != 0u) { budget -= 1u; u3 = fn1(0x10000u, (m0 * (unsigned)(0x80000000u && 2u)), (unsigned)d0); }
    do { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)(-((unsigned)l0 & 0x51213cc3u) && 0u));
                m0 ^= (unsigned)(u1 || r0.y);
                f0 = f0 * 0.5f + (float)(((unsigned)((short)(0xffffffffu % (r0.x | 1u)) > (signed char)(unsigned)s0) ^ (unsigned)((short)i1 > (signed char)i0)) & 255u);
            } while (i2++ < 4u && (unsigned)((int)fuel >= (int)0x7fffffffu));
        }
    } while (i0++ < 2u && ~(0x80000000u | (a0[u1 & 3u] % (0x80000000u | 1u))));
    g1 += ((((unsigned)b0 / (0xffffffffu | 1u)) + (unsigned)(w0 >> 29)) * 3u);
    if ((unsigned)(p2 == (unsigned)((int)i1 < (int)(unsigned)(x0 >> 70)))) goto L2;
    u2 = ((9u >> (7u & 31u)) & ((unsigned)(x0 >> 70) & (unsigned)h0));
    d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(unsigned)((unsigned)(unsigned char)((unsigned)((int)9u < (int)(unsigned)(0x2654318fu == *q0)) ^ (unsigned)l0) && 0x74e6b095u) & 1023u);
    a0[i1 & 3u] = (unsigned)((unsigned)(w0 >> 29) || (unsigned)(signed char)(i2 >> ((unsigned)f0 & 31u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        b0 = ~(i0 / ((unsigned)l0 | 1u)) != 0u;
        w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)((short)(a0[i0 & 3u] * 9u) > (signed char)m0) && (unsigned)((short)r0.x > (signed char)0xbb5a4bc4u));
        h0 = (short)(unsigned)((unsigned)(0xc65c02e6u < r0.x) || 0x4216d3f7u);
        if ((unsigned)((p0 ^ a0[i0 & 3u]) || 0x18c2365eu)) break;
        if ((a0[u1 & 3u] ^ g0)) break;
    }
    c0 = (unsigned char)((unsigned)((int)p1 >= (int)a0[u1 & 3u]) | 0x10000u);
    while (v0) { if (--fuel == 0u) goto done;
        while (i1++ < 3u && (0xefa81f2u & (unsigned)d0)) { if (--fuel == 0u) goto done;
            garr[(unsigned)(short)((unsigned)h0 ^ g0) & 7u] = (unsigned)((unsigned)((unsigned)x0 || (unsigned)(x0 >> 70)) < ((unsigned)w0 ^ (unsigned)!(u3 >> (0xcac272e2u & 31u))));
            *q0 += (unsigned)(w0 >> 29);
            do { if (--fuel == 0u) goto done;
                c1 = (signed char)(((unsigned)w0 & v0) + 0xdbf533f2u);
                w0 = w0 * 6364136223846793005ull + (2u / ((unsigned)((unsigned)(short)(i0 & (unsigned)s0) && i1) | 1u));
                if ((unsigned)((int)0xb8bdfa8cu >= (int)m0)) break;
                h1 = (unsigned short)(h1 + ((u0 / ((p2 << ((unsigned)(short)(unsigned)(i2 && 9u) & 31u)) | 1u)) / (g0 | 1u)));
            } while (i2++ < 4u && (unsigned)d0);
            u1 = (((a0[i0 & 3u] | (unsigned)b0) * (unsigned)c1) << (((unsigned)s0 | *q0) & 31u));
        }
        { unsigned t0; double z0; if ((((unsigned)c0 & i1)) & 1u) { t0 = (unsigned)((short)p0 > (signed char)0xffffffffu); z0 = (double)(((fuel | r0.y)) & 255u); } if ((((unsigned)c0 & i1)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            while (0x10000u) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((~(unsigned)(0xdb58251du || (unsigned)h1) ^ (unsigned)b0), (0x3081af59u * 9u), ((unsigned)c1 ^ (unsigned)((int)p0 < (int)(unsigned)d0))); }
                    if ((unsigned)((short)(unsigned)!(*q0 | 6u) > (signed char)a0[u1 & 3u])) continue;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((u0 ^ i2), (u0 / ((unsigned)(w0 >> 29) | 1u)), (unsigned)(*q0 || (unsigned)s1)); }
                    for (;;) { if (--fuel == 0u) goto done;
                        c1 = (signed char)(unsigned)(unsigned char)((unsigned)(w0 >> 29) ^ ((unsigned)((int)(unsigned)s0 >= (int)r0.y) + (unsigned)(m0 || a0[u1 & 3u])));
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((0x10000u % ((unsigned)(x0 >> 70) | 1u)), (unsigned)(unsigned char)(p0 + (0x10000u | r0.x)), (((unsigned)c0 * (unsigned)h1) * u3)); }
                    if ((unsigned)(garr[i1 & 7u] == ((unsigned)s1 - 0xffffffffu))) break;
                }
            }
            s0 = (int)(p0 - (unsigned)(g0 < (unsigned)s0));
        }
        if (0x10000u) {
            a0[(0x80000000u | i2) & 3u] = (unsigned)((((unsigned)w0 / (g0 | 1u)) | (unsigned)l0) || p1);
            while (i1++ < 3u && (unsigned)((int)(unsigned)((short)0xa72dd005u > (signed char)(unsigned)s0) >= (int)0x924ed93fu)) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)(0xd29d7792u == (unsigned)f0);
                e0 = e0 * 0.5L + (long double)((unsigned)!((unsigned)b0 * (0x4cb5c43bu << ((unsigned)s0 & 31u))) & 1023u);
                s0 = (int)(unsigned)((short)~(0x10000u ? (v0 | 0x10000u) : 3u) > (signed char)(unsigned)f0);
                a0[garr[u2 & 7u] & 3u] = (unsigned)((short)((unsigned)!(unsigned)((int)a0[i0 & 3u] < (int)u0) | 5u) > (signed char)0x7fffffffu);
            }
            if (fuel < 8u) return (unsigned)!(unsigned)((int)(unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)e0) < (int)(unsigned)((int)(unsigned)s0 < (int)(unsigned)((int)r0.y < (int)(unsigned)w0)));
        }
        r0.x = (unsigned)d0;
        v0 = (0u * i2);
        s0 = (int)(unsigned)((int)((unsigned)(signed char)(unsigned)(1u || fuel) % ((i1 / (u2 | 1u)) | 1u)) >= (int)8u);
    }
    goto L0;
    if (((g0 / (u3 | 1u)) << (v0 & 31u))) goto done;
    if ((*mp / (5u | 1u))) goto L4;
    if (budget != 0u) { budget -= 1u; u2 = fn1((p1 >> ((unsigned)((unsigned)x0 == garr[i1 & 7u]) & 31u)), (unsigned)((unsigned)((unsigned)s0 && 4u) && 0xd5754d24u), (unsigned)((int)(unsigned)l0 >= (int)(unsigned)f0)); }
    if ((0xd2de7c78u / (1u | 1u))) goto L0;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
    }
    g1 += ((unsigned)h1 - (unsigned)s1);
    m0 ^= (unsigned)(w0 >> 29);
    if ((unsigned)((short)(unsigned)f0 > (signed char)u0)) {
        if (((unsigned)s0 + (*mp + (unsigned)(x0 >> 70)))) goto done;
        if ((unsigned)((int)(unsigned)x0 >= (int)0x9bab1008u)) goto done;
        s1 = (int)((unsigned)s1 + 0x12910e04u);
        if (budget != 0u) { budget -= 1u; u3 = fn0((i1 / (garr[i1 & 7u] | 1u)), ((unsigned)b0 / (0x97db9e2cu | 1u)), (unsigned)((short)*q0 > (signed char)(unsigned)!(unsigned)(a0[u1 & 3u] == (unsigned)h1))); }
    }
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            *q0 += 0x10000u;
        } while (i1++ < 6u && -((unsigned)(unsigned char)(unsigned)(8u && u2) & garr[u2 & 7u]));
    } while (i0++ < 3u && ((unsigned)(0x8f2d0fedu && 0xf7bb48f0u) / (4u | 1u)));
    if (budget != 0u) { budget -= 1u; u3 = fn2((p0 / (p0 | 1u)), m0, (unsigned)b0); }
    l0 = (long)((unsigned long)l0 + ((unsigned)(v0 < (unsigned)((int)(unsigned)((int)(unsigned)c1 >= (int)0xea0fc0c9u) >= (int)garr[i1 & 7u])) | v0));
    do { if (--fuel == 0u) goto done;
        if ((unsigned)w0) {
            *mp = (unsigned)s1;
            f0 = f0 * 0.5f + (float)((unsigned)s0 & 255u);
            { unsigned t1; double z1; if (((9u / (~((unsigned)c1 ^ (unsigned)e0) | 1u))) & 1u) { t1 = garr[i1 & 7u]; z1 = (double)(((g0 | (unsigned)(x0 >> 70))) & 255u); } if (((9u / (~((unsigned)c1 ^ (unsigned)e0) | 1u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                L1: if (--fuel == 0u) goto done;
                break; (void)(p0);
                L2: if (--fuel == 0u) goto done;
                g0 = (unsigned)(0xae0526d2u || (unsigned)f0);
                a0[(unsigned)h0 & 3u] = (unsigned)(*mp || (5u * u0));
                u0 += ((unsigned)l0 << (0x6044aa53u & 31u));
            }
        }
    } while (i0++ < 5u && (3u % (r0.x | 1u)));
    if ((unsigned)((unsigned)(v0 == u0) < 0x2d642ca8u)) goto L0;
    h0 = (short)(unsigned)((unsigned)((0x10000u - 0u) && (u2 + a0[i0 & 3u])) < (unsigned)b0);
    v0 = (unsigned)h0;
    if ((unsigned)(p2 && 0x10000u)) goto L1;
    switch (u0 & 7u) {
        L3: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)f0, (garr[i1 & 7u] | v0), ((unsigned)s0 ^ a0[u1 & 3u])); }
        if (((unsigned)s0 >> (((unsigned)(x0 >> 70) ^ (unsigned)c1) & 31u))) goto L3;
        i0 = (unsigned)s0 & 15u;
    }
    while (i0++ < 7u && (unsigned)(0x2ee915a6u || 3u)) { if (--fuel == 0u) goto done;
        if (p2) goto L1;
        s0 = (int)((unsigned)((short)(unsigned)((int)(unsigned)d0 < (int)p1) > (signed char)(unsigned)c1) - (unsigned)((unsigned)c1 < 0xe4d9516bu));
        c1 = (signed char)(unsigned)!(unsigned)((unsigned)(short)(unsigned)((int)(unsigned)s0 < (int)(unsigned)e0) || (3u ^ g0));
    }
    L4: if (--fuel == 0u) goto done;
    h0 = (short)garr[u2 & 7u];
    f0 = f0 * 0.5f + (float)(u3 & 255u);
    c0 = (unsigned char)2u;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(signed char)((unsigned)w0 + 8u), (unsigned)((unsigned)(w0 >> 29) == (unsigned)(w0 >> 29)), ((a0[u1 & 3u] / (*q0 | 1u)) / (3u | 1u))); }
        if ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)x0)) {
            { unsigned t2; double z2; if (((garr[u2 & 7u] << ((unsigned)c1 & 31u))) & 1u) { t2 = (unsigned)((short)(0x91d2ad2eu | 1u) > (signed char)(unsigned)x0); z2 = (double)(((unsigned)e0) & 255u); } if (((garr[u2 & 7u] << ((unsigned)c1 & 31u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)s0 < (int)((unsigned)((short)*mp > (signed char)(unsigned)(w0 >> 29)) - (unsigned)(x0 >> 70)));
                if ((unsigned)f0) continue;
                if ((unsigned)((short)a0[i0 & 3u] > (signed char)0x80000000u)) goto L0;
                v0 = (unsigned)(signed char)((unsigned)((int)p2 >= (int)p1) | (unsigned)(short)(5u * (unsigned)c0));
                *q0 = (6u & (unsigned)((short)p2 > (signed char)r0.y));
                if ((0x10000u << (0x1d6cadau & 31u))) break;
            }
            *mp = ((unsigned)((unsigned)h1 && ((a0[u1 & 3u] / (p0 | 1u)) >> (0x4d9298e1u & 31u))) << ((unsigned)h0 & 31u));
            s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((i2 << (0x10000u & 31u)) == a0[u1 & 3u]) || 0x10000u));
            break; (void)((0x10000u / ((unsigned)x0 | 1u)));
        }
        { unsigned t3; double z3; if (((unsigned)(0u < ((unsigned)h0 >> (7u & 31u)))) & 1u) { t3 = 0x80000000u; z3 = (double)(((unsigned)(p1 < 0x10000u)) & 255u); } if (((unsigned)(0u < ((unsigned)h0 >> (7u & 31u)))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            break; (void)(v0);
            h0 = (short)(unsigned)f0;
            switch ((g0 + (unsigned)l0) & 7u) {
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)((short)(unsigned)c0 > (signed char)i1) && (unsigned)((short)1u > (signed char)((unsigned)b0 + v0)));
                x0 = x0 * 0x100000001b3ull + (p0 / (a0[i0 & 3u] | 1u));
                i0 = (u3 % ((0x4b670d1fu << ((unsigned)d0 & 31u)) | 1u)) & 15u;
            }
            w0 ^= (unsigned long long)(r0.x ^ 0x7fffffffu) << (((unsigned)h1 | i2) & 63u);
            h0 = (short)((fuel / ((unsigned)(short)(unsigned)(0x80000000u < p0) | 1u)) ^ i2);
        }
    } while (i0++ < 7u && ((unsigned)x0 ^ 1u));
    a0[(unsigned)((short)(unsigned)d0 > (signed char)r0.x) & 3u] = ((unsigned)((int)(unsigned)(fuel < i0) < (int)(unsigned)(1u || g0)) & (unsigned)f0);
    if (budget != 0u) { budget -= 1u; u2 = fn1(g1, (unsigned)((int)0xb8623ef4u < (int)u0), (unsigned)((unsigned)f0 == (unsigned)((unsigned)w0 == *q0))); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    x0 = x0 * 0x100000001b3ull + ((0x80000000u << ((unsigned)c1 & 31u)) + (unsigned)((int)((unsigned)e0 | i1) < (int)r0.x));
    s0 = (int)((5u >> (0x196a0221u & 31u)) >> ((unsigned)(x0 >> 70) & 31u));
    do { if (--fuel == 0u) goto done;
        if ((((unsigned)d0 % ((unsigned)f0 | 1u)) << (fuel & 31u))) break;
    } while (i0++ < 3u && ((0xa0fb1aceu - (unsigned)(x0 >> 70)) ^ 0x7fffffffu));
    *mp = ((unsigned)!(i1 >> (garr[i1 & 7u] & 31u)) * (unsigned)((int)2u >= (int)(unsigned)((int)(unsigned)x0 >= (int)v0)));
    if ((unsigned)((int)i1 < (int)(unsigned)c0)) goto L3;
    if (u3 == 7u) return ((unsigned)(0x77cbad19u || i1) + (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)s1));
    if ((0x10000u >> ((unsigned)(fuel || 0x7fffffffu) & 31u))) goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((int)u2 < (int)g1), ((unsigned)e0 / ((unsigned)(short)((unsigned)h1 << (i2 & 31u)) | 1u)), ((unsigned)(u2 < (unsigned)w0) << (0x7fffffffu & 31u))); }
    if (((unsigned)l0 | (unsigned)h1)) goto L2;
    switch ((unsigned)(signed char)(((unsigned)b0 + u0) + (unsigned)h0) & 7u) {
        switch ((5u % (m0 | 1u)) & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn2(g1, p0, r0.y); }
            r0.y ^= 0x62dae7bu;
            f0 = f0 * 0.5f + (float)((unsigned)(v0 < a0[u1 & 3u]) & 255u);
        }
        g1 += 0x7c077814u;
        if (budget != 0u) { budget -= 1u; u3 = fn0((fuel << (a0[u1 & 3u] & 31u)), (unsigned)c0, 7u); }
    }
    x0 = x0 * 0x100000001b3ull + ((unsigned)((int)(unsigned)d0 < (int)r0.x) & ((unsigned)(x0 >> 70) / (*mp | 1u)));
    if (fuel < 8u) return -(unsigned)((unsigned)((i1 + (unsigned)d0) || (unsigned)(short)((unsigned)c1 + fuel)) && g0);
    *q0 = (g0 << (u1 & 31u));
    d0 = d0 * 0.5 + (double)((garr[i1 & 7u] << ((i2 ? (0x6124acdu - (unsigned)s1) : (unsigned)c1) & 31u)) & 1023u);
    { unsigned t0; double z0; if (((r0.x * *q0)) & 1u) { t0 = (unsigned)((int)(unsigned)f0 < (int)(unsigned)h0); z0 = (double)((((unsigned)e0 % (m0 | 1u))) & 255u); } if (((r0.x * *q0)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        switch (((unsigned)d0 + (unsigned)(w0 >> 29)) & 7u) {
            do { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
                if (0x1b33592du) {
                    if (~(unsigned)((int)6u < (int)((unsigned)s1 | p2))) break;
                    w0 ^= (unsigned long long)(unsigned)((unsigned)w0 == 0xf90ebbcau) << ((unsigned)((int)((unsigned)(x0 >> 70) | (r0.x ^ 3u)) < (int)(*q0 / (p1 | 1u))) & 63u);
                    L1: if (--fuel == 0u) goto done;
                    if (4u) continue;
                } else {
                    *q0 += (unsigned)((short)(unsigned)(0u || 0xffffffffu) > (signed char)(unsigned)w0);
                    if (((unsigned)((int)fuel >= (int)(unsigned)l0) & (unsigned)d0)) goto L0;
                    b0 = ((1u | (unsigned)c0) >> ((unsigned)(i1 || (unsigned)h1) & 31u)) != 0u;
                }
                if ((g1 ^ p0)) break;
                if (-((unsigned)d0 % (r0.x | 1u))) {
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)((int)0xbe60caf0u >= (int)(unsigned)w0) && (unsigned)!(unsigned)(i1 == i0)));
                    if ((u1 % ((unsigned)(short)(unsigned)(u2 && fuel) | 1u))) continue;
                    f0 = f0 * 0.5f + (float)(((unsigned)(w0 >> 29) / ((~(unsigned)(g0 == 1u) / (p2 | 1u)) | 1u)) & 255u);
                } else {
                    for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        u0 = u0 * 0x9e3779b1u + (unsigned)(unsigned char)(unsigned)(m0 == fuel);
                        break; (void)((unsigned)((int)u2 < (int)(g0 | (unsigned)(x0 >> 70))));
                        w0 = w0 * 6364136223846793005ull + u1;
                        x0 = x0 * 0x100000001b3ull + ((unsigned)w0 + (unsigned)c1);
                    }
                }
                case 7u: ;
            } while (i0++ < 5u && (i2 + g1));
            q0 = &garr[(unsigned)(fuel == (unsigned)((~(fuel * (unsigned)b0) % (2u | 1u)) == 0x41fbfbedu)) & 7u];
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if ((p1) & 1u) { t1 = u1; z1 = (double)((g1) & 255u); } if ((p1) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    L2: if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + ((unsigned)((short)m0 > (signed char)0xcd50d529u) + (unsigned)(w0 >> 29)));
                    b0 = ((unsigned)l0 / (-(unsigned)((int)(2u % ((unsigned)(w0 >> 29) | 1u)) >= (int)(unsigned)(x0 >> 70)) | 1u)) != 0u;
                }
                b0 = (i1 / ((*mp + (unsigned)((int)(unsigned)c1 < (int)0xffffffffu)) | 1u)) != 0u;
                while (i1++ < 3u && (unsigned)!((unsigned)(w0 >> 29) + i2)) { if (--fuel == 0u) goto done;
                    case 1u: ;
                    if ((unsigned)(x0 >> 70)) break;
                    garr[(1u * 0xffffffffu) & 7u] = ((unsigned)(u3 == (unsigned)((unsigned)x0 && (unsigned)c0)) | (i2 / ((unsigned)x0 | 1u)));
                    garr[(*mp | 2u) & 7u] = (unsigned)((unsigned)(x0 >> 70) || (unsigned)((int)0x7fffffffu >= (int)0xffffffffu));
                    w0 ^= (unsigned long long)(6u >> ((unsigned)f0 & 31u)) << (~(((unsigned)s0 % ((unsigned)((int)4u < (int)0x780a143fu) | 1u)) * (unsigned)f0) & 63u);
                    if ((0x80000000u % ((i2 - g0) | 1u))) break;
                }
            }
            garr[(8u & (unsigned)h1) & 7u] = (unsigned)c1;
            u2 += (0x10000u >> ((unsigned)c1 & 31u));
        }
        s1 = (int)((unsigned)s1 + (unsigned)(w0 >> 29));
        if ((((unsigned)c0 | *mp) / ((unsigned)h0 | 1u))) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn2(-(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)(signed char)(p1 << (0x80000000u & 31u))), (garr[i1 & 7u] >> ((0x8bbc7f41u >> (garr[u2 & 7u] & 31u)) & 31u)), (0x86820u & (unsigned)(short)(unsigned)((unsigned)h1 && (unsigned)w0))); }
        goto L3;
    }
    if ((unsigned)(-(unsigned)(0x6d8098bu == (unsigned)w0) || (unsigned)c0)) {
        if (u1) goto L0;
        if (g1) goto L0;
        s0 = (int)(unsigned)((p0 ? (unsigned)(x0 >> 70) : u0) && (unsigned)w0);
        l0 = (long)((unsigned long)l0 + -(r0.y * (0x80000000u >> (a0[i0 & 3u] & 31u))));
        L3: if (--fuel == 0u) goto done;
        if ((unsigned)((short)u1 > (signed char)2u)) goto done;
    }
    while (a0[i0 & 3u]) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)!((unsigned)s0 ^ *mp), r0.y, 0x7fffffffu); }
        s1 = (int)((unsigned)s1 + 0x10000u);
        v0 = (unsigned)((int)(unsigned)((short)a0[i0 & 3u] > (signed char)m0) >= (int)(unsigned)((short)u0 > (signed char)0x10000u));
        L4: if (--fuel == 0u) goto done;
        { unsigned t2; double z2; if ((p1) & 1u) { t2 = (((unsigned)c1 + 0x10000u) % (*q0 | 1u)); z2 = (double)((((unsigned)c1 ^ u3)) & 255u); } if ((p1) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            if ((unsigned)(u3 && u1)) {
                if (garr[i1 & 7u]) break;
                break; (void)((unsigned)(0x640e3413u || (r0.x << ((unsigned)e0 & 31u))));
            } else {
                u2 = ((p0 | i0) / ((unsigned)(u2 < a0[u1 & 3u]) | 1u));
                if ((unsigned)((int)(unsigned)((int)p0 >= (int)0x7fffffffu) >= (int)1u)) {
                    if (budget != 0u) { budget -= 1u; u3 = fn1(0xec97a641u, (0x10000u / ((unsigned)!(unsigned)((int)garr[i1 & 7u] >= (int)m0) | 1u)), garr[u2 & 7u]); }
                    break; (void)(-((unsigned)d0 * (0x80000000u ^ r0.y)));
                    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(unsigned char)(unsigned)((short)(unsigned)h1 > (signed char)(5u ^ r0.x)), i0, 0x80000000u); }
                } else {
                    if (budget != 0u) { budget -= 1u; u0 = fn0((0u + (m0 << (garr[u2 & 7u] & 31u))), (unsigned)(((unsigned)h0 % (u0 | 1u)) && u2), p1); }
                    for (;;) { if (--fuel == 0u) goto done;
                        g0 = (unsigned)(unsigned char)(g1 >> (((unsigned)b0 << (u2 & 31u)) & 31u));
                        if (((unsigned)c1 & (unsigned)((int)a0[u1 & 3u] >= (int)g0))) {
                            *q0 += (i1 * (unsigned)x0);
                        }
                        if ((-(0x6834a2a5u % (0x3b6a435u | 1u)) - (unsigned)d0)) {
                            a0[p2 & 3u] = u0;
                        } else {
                            if ((unsigned)s1) continue;
                            if (0x10000u) break;
                            m0 ^= ((0x3525fbeeu % (*mp | 1u)) & u0);
                        }
                        if (budget != 0u) { budget -= 1u; u1 = fn0((m0 | u3), (unsigned)c1, (unsigned)d0); }
                        break; (void)((0x10000u - 0xb7b01a06u));
                    }
                }
                if ((0xa807dfc4u & 0xc455238bu)) break;
                if ((unsigned)(m0 < (unsigned)(x0 >> 70))) break;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn2(u2, 0x4ec17fc9u, garr[i1 & 7u]); }
        }
    }
    do { if (--fuel == 0u) goto done;
        if ((r0.x / ((unsigned)f0 | 1u))) break;
        if ((unsigned)(0xffffffffu || v0)) {
            i2 = (unsigned)(a0[u1 & 3u] == (unsigned)((short)0xffffffffu > (signed char)(g1 % (((unsigned)s0 - u2) | 1u)))) & 15u;
            f0 = f0 * 0.5f + (float)((((unsigned)w0 - 0x9544f236u) * (unsigned)c0) & 255u);
        }
    } while (i0++ < 7u && ~((unsigned)b0 / (0x10000u | 1u)));
    if ((8u >> ((unsigned)f0 & 31u))) {
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (0xb7471a86u / (0x99adf40eu | 1u));
            if (((unsigned)h1 ^ (unsigned)((int)(unsigned)l0 >= (int)(unsigned)b0))) break;
        }
        *q0 = (5u ? 0xfff91c28u : (unsigned)(x0 >> 70));
        do { if (--fuel == 0u) goto done;
            if (u3 == 7u) return (unsigned)c0;
            switch (0x9b355830u & 7u) {
                if ((unsigned)((short)r0.y > (signed char)(unsigned)b0)) {
                    x0 = x0 * 0x100000001b3ull + (unsigned)((int)0x80000000u >= (int)(unsigned)((g0 >> (r0.y & 31u)) || 0x744f9c2cu));
                    l0 = (long)((unsigned long)l0 + v0);
                    case 7u: ;
                    if (budget != 0u) { budget -= 1u; u2 = fn3(((0x7634b6d9u ^ 8u) << (u0 & 31u)), (unsigned)((a0[i0 & 3u] + a0[u1 & 3u]) == r0.x), (unsigned)(garr[u2 & 7u] || 7u)); }
                    case 6u: ;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn3(i2, (unsigned)s1, 0xffffffffu); }
            }
            if ((7u ^ (unsigned)(0x8b67db01u || p1))) {
                if (-(unsigned)(8u == (unsigned)((int)i1 >= (int)r0.x))) break;
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn3(0x7fffffffu, garr[u2 & 7u], ((unsigned)(w0 >> 29) + ((unsigned)w0 & garr[i1 & 7u]))); }
                    goto L4;
                    if ((-(unsigned)((short)i2 > (signed char)m0) | 0x1e9e4771u)) break;
                    for (;;) { if (--fuel == 0u) goto done;
                        u0 += (unsigned)((int)-(v0 - (unsigned)c0) >= (int)-(u0 ? 7u : garr[i1 & 7u]));
                        r0.y ^= ((unsigned)(x0 >> 70) << ((m0 / ((unsigned)!(0x80000000u ^ (unsigned)((int)0x80000000u < (int)garr[u2 & 7u])) | 1u)) & 31u));
                    }
                    goto L2;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(0x80000000u, p0, (u1 - (unsigned)f0)); }
                }
                q0 = &garr[-((unsigned)(garr[i1 & 7u] || u0) - (1u + fuel)) & 7u];
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        r0.y ^= ((unsigned)(*mp < (unsigned)h0) % ((unsigned)((g1 << (g0 & 31u)) && (unsigned)s0) | 1u));
                        if (budget != 0u) { budget -= 1u; u2 = fn1(0xcf8a7afu, (unsigned)((short)0xffffffffu > (signed char)u1), (0xa235e90eu / (a0[i0 & 3u] | 1u))); }
                        break; (void)(0xf68ef43bu);
                        e0 = e0 * 0.5L + (long double)((unsigned)(signed char)((unsigned)d0 + p2) & 1023u);
                    } while (i2++ < 4u && 0x5dcab25fu);
                    r0.y ^= (((unsigned)c0 - (i0 * (unsigned)c1)) / ((unsigned)(x0 >> 70) | 1u));
                    f0 = f0 * 0.5f + (float)((-((unsigned)e0 * (unsigned)!((unsigned)b0 ? p0 : *q0)) & garr[u2 & 7u]) & 255u);
                    w0 = w0 * 6364136223846793005ull + ((a0[i0 & 3u] - (unsigned)l0) % (((unsigned)((int)0xe83d4f2eu < (int)garr[u2 & 7u]) + (unsigned)s1) | 1u));
                    if (g0) goto done;
                    if ((unsigned)((short)(0x80000000u - (unsigned)b0) > (signed char)fuel)) {
                        if ((a0[u1 & 3u] ^ (0u << (p0 & 31u)))) goto L4;
                        break; (void)((u3 & 0xffffffffu));
                        r0.x = (unsigned)!(i0 + (p1 / (p0 | 1u)));
                        break; (void)(((unsigned)l0 - u0));
                        do { if (--fuel == 0u) goto done;
                            if ((unsigned)(short)(p1 / (5u | 1u))) goto L0;
                            c0 = (unsigned char)((unsigned)f0 % ((unsigned)(m0 && 8u) | 1u));
                            break; (void)((*q0 ^ (6u | 0x80000000u)));
                            if ((unsigned)l0) break;
                            if (fuel < 8u) return *q0;
                        } while (i2++ < 3u && -(unsigned)(0x2ac64634u && -((unsigned)d0 - 0xffffffffu)));
                        *q0 = (unsigned)((p1 & 0x10000u) || (unsigned)(i0 || 0x80679f88u));
                    } else {
                        break; (void)(i2);
                        w0 ^= (unsigned long long)u1 << ((unsigned)((unsigned)(signed char)(unsigned)((short)m0 > (signed char)p2) || (unsigned)((0xf0bdc931u & g1) || (unsigned)h0)) & 63u);
                        if ((unsigned)((int)(garr[u2 & 7u] ^ (unsigned)h1) >= (int)p2)) break;
                    }
                }
            } else {
                *q0 = ((i1 | r0.x) - (unsigned)(signed char)(0xffffffffu >> (((unsigned)s1 / (g0 | 1u)) & 31u)));
                e0 = e0 * 0.5L + (long double)(((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)((unsigned)((int)0x10000u < (int)(unsigned)h1) == u3)) ^ (unsigned)w0) & 1023u);
                switch (((unsigned)(0x19818613u < (unsigned)(w0 >> 29)) | u2) & 7u) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((a0[u1 & 3u] + r0.x), ((unsigned)((short)0xa52f3ce4u > (signed char)m0) << (a0[i0 & 3u] & 31u)), (unsigned)((int)~((unsigned)w0 & u3) < (int)(unsigned)c0)); }
                    case 7u: ;
                }
                if ((2u >> (r0.x & 31u))) continue;
            }
        } while (i0++ < 7u && (g0 | 1u));
    }
    { unsigned t3; double z3; if (((unsigned)s0) & 1u) { t3 = 0xe79804e3u; z3 = (double)(((unsigned)(x0 >> 70)) & 255u); } if (((unsigned)s0) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        if ((8u ? a0[u1 & 3u] : u2)) {
            goto L4;
            if (7u) goto done;
        } else {
            garr[p1 & 7u] = ((unsigned)(0xdb1f2d0du == (unsigned)d0) % (g0 | 1u));
            if ((unsigned)(p2 || 0x28a98e5du)) goto L2;
            if ((unsigned)(unsigned char)((unsigned)c1 << (((unsigned)e0 - 0x78cbb63fu) & 31u))) goto L1;
        }
        do { if (--fuel == 0u) goto done;
            i0 = (u1 | (unsigned)((int)(unsigned)w0 >= (int)g0)) & 15u;
            if (fuel < 8u) return fuel;
            u0 = u0 * 0x9e3779b1u + (unsigned)((u0 % ((unsigned)(short)(unsigned)(u1 && (unsigned)e0) | 1u)) || (unsigned)((int)(unsigned)c1 < (int)m0));
            if (g0) {
                d0 = d0 * 0.5 + (double)((unsigned)((short)u3 > (signed char)(unsigned)c1) & 1023u);
                u0 = (unsigned)((g1 / (garr[u2 & 7u] | 1u)) && ((unsigned)f0 ^ (unsigned)((unsigned)e0 < 0x10000u)));
                *q0 += (unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)((unsigned)e0 == (unsigned)e0));
                while (i1++ < 7u && u0) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)b0 / ((unsigned)(u2 || 0x80000000u) | 1u)), ((unsigned)c1 * i1), (g0 | garr[u2 & 7u])); }
                }
                garr[(unsigned)b0 & 7u] = g0;
            }
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch (((unsigned)((int)0x80000000u >= (int)r0.y) * m0) & 7u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)e0 ^ p2), r0.x, (unsigned)(g0 && i2)); }
                    goto L3;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(((u2 << (garr[i1 & 7u] & 31u)) * (unsigned)c0), a0[i0 & 3u], ((a0[u1 & 3u] * 4u) - 0x7fffffffu)); }
            }
            while (i1++ < 3u && u0) { if (--fuel == 0u) goto done;
                continue; (void)((unsigned)(0xffffffffu < a0[u1 & 3u]));
                if ((unsigned)(short)(a0[u1 & 3u] >> ((unsigned)c1 & 31u))) break;
                continue; (void)((unsigned)((a0[i0 & 3u] / (r0.y | 1u)) && (unsigned)l0));
                if ((unsigned)((int)i0 < (int)0x2346b1d4u)) goto L0;
                l0 = (long)((unsigned long)l0 + 0xffffffffu);
                { unsigned t4; double z4; if ((((unsigned)c1 << (i0 & 31u))) & 1u) { t4 = (unsigned)f0; z4 = (double)(((unsigned)l0) & 255u); } if ((((unsigned)c1 << (i0 & 31u))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                    e0 = e0 * 0.5L + (long double)((unsigned)(short)(p2 - (unsigned)(short)((unsigned)f0 + ((unsigned)s0 & p1))) & 1023u);
                    for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        u2 += (unsigned)((unsigned)((int)0u >= (int)(unsigned)c0) == garr[u2 & 7u]);
                        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)l0 / ((g0 & p0) | 1u)), (i0 & 0x7fffffffu), (unsigned)!(unsigned)((short)(unsigned)c0 > (signed char)(unsigned)h0)); }
                        if ((unsigned)(0xffffffffu < (i1 >> ((unsigned)(x0 >> 70) & 31u)))) break;
                    }
                    continue; (void)((u3 ? m0 : (unsigned)x0));
                    if (((unsigned)((short)i0 > (signed char)(unsigned)x0) & a0[u1 & 3u])) {
                        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)2u >= (int)(u3 * g1)), ((unsigned)f0 & (unsigned)(x0 >> 70)), (unsigned)(short)(unsigned)((int)(unsigned)((short)(unsigned)b0 > (signed char)(unsigned)x0) >= (int)u2)); }
                        goto L2;
                    } else {
                        *q0 = (unsigned)((int)(g1 >> (g0 & 31u)) >= (int)0x10000u);
                        if ((unsigned)(w0 >> 29)) {
                            v0 = (0xffffffffu ? ((unsigned)s1 ^ ~(unsigned)((int)(unsigned)l0 < (int)(unsigned)l0)) : i0);
                            if (budget != 0u) { budget -= 1u; u3 = fn1(g0, (unsigned)c1, (unsigned)((unsigned)((int)(unsigned)w0 >= (int)(unsigned)w0) && 0x80000000u)); }
                            if (0xe828065eu) break;
                        } else {
                            break; (void)((((unsigned)s1 / (v0 | 1u)) - a0[i0 & 3u]));
                            *q0 = (unsigned)((p0 % (p0 | 1u)) < (unsigned)((i2 << (5u & 31u)) || i1));
                            s0 = (int)v0;
                        }
                    }
                    { unsigned t5; double z5; if (((unsigned)(0x10000u || 0x80000000u)) & 1u) { t5 = (unsigned)((unsigned)c0 || r0.x); z5 = (double)((0x10000u) & 255u); } if (((unsigned)(0x10000u || 0x80000000u)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                        garr[(unsigned)(m0 && 0x7464a3cdu) & 7u] = ((unsigned)h0 | (p0 << ((unsigned)h1 & 31u)));
                        s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((unsigned)(3u < (unsigned)(x0 >> 70)) < 8u) >= (int)u1));
                        c1 = (signed char)((unsigned)!((unsigned)h0 + u3) + (unsigned)s0);
                        s0 = (int)(unsigned)(short)((m0 + i0) | (u1 * (unsigned)l0));
                        if (budget != 0u) { budget -= 1u; u1 = fn1((0xffffffffu / (r0.y | 1u)), (p1 / ((0x10000u & 0x10000u) | 1u)), 1u); }
                    }
                }
            }
        } while (i0++ < 3u && (unsigned)((int)(unsigned)x0 >= (int)(u1 / (0xffffffffu | 1u))));
    }
    if (0x80000000u) goto L0;
    if (*mp) {
        if ((unsigned)c1) {
            h1 = (unsigned short)(h1 + (unsigned)((int)u1 >= (int)(unsigned)(unsigned char)(unsigned)((int)(p0 | *q0) < (int)(unsigned)(7u < u3))));
            if ((unsigned)s1) {
                r0.x = ((unsigned)(u2 == (unsigned)x0) & garr[u2 & 7u]);
                if (budget != 0u) { budget -= 1u; u3 = fn2((g1 << ((unsigned)s0 & 31u)), (unsigned)((g1 % ((unsigned)e0 | 1u)) && 0x80000000u), 0x10000u); }
                if (((unsigned)h1 << (m0 & 31u))) goto L3;
                s1 = (int)((unsigned)s1 + (((u3 + a0[u1 & 3u]) - u3) << (0x7fffffffu & 31u)));
                goto L0;
            }
            if (((unsigned)x0 + (0x6c7f6bb0u % ((unsigned)x0 | 1u)))) goto L1;
            c0 = (unsigned char)(unsigned)(0xffffffffu || garr[u2 & 7u]);
        }
    }
    if (((unsigned)d0 | 0xabbdd3d6u)) {
        if (budget != 0u) { budget -= 1u; u2 = fn2(((g1 & 0x7fffffffu) << (0xffffffffu & 31u)), garr[u2 & 7u], 2u); }
        *q0 = (unsigned)((short)g0 > (signed char)*mp);
        h0 = (short)(4u ^ 3u);
        goto L0;
    } else {
        { unsigned t6; double z6; if (((unsigned)(i2 || u3)) & 1u) { t6 = u3; z6 = (double)(((unsigned)(0x10000u == 0x7fffffffu)) & 255u); } if (((unsigned)(i2 || u3)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            while (i0++ < 6u && (u2 - (0x2e04df5du / ((unsigned)f0 | 1u)))) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return (unsigned)((short)(g0 | g1) > (signed char)((1u + u2) * a0[u1 & 3u]));
                if ((unsigned)(signed char)((i2 / ((unsigned)e0 | 1u)) / (0x947837dbu | 1u))) break;
                if ((unsigned)w0) {
                    if (budget != 0u) { budget -= 1u; u0 = fn1((0xbb78025cu - (unsigned)x0), (unsigned)b0, (u2 >> ((unsigned)h1 & 31u))); }
                    if (u0) {
                        break; (void)((unsigned)(unsigned char)((m0 / (*mp | 1u)) / ((unsigned)c0 | 1u)));
                    } else {
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s0 - 5u), (unsigned)((int)(unsigned)((unsigned)d0 || fuel) < (int)0xffffffffu), (7u * p2)); }
                        u2 = u2 * 0x9e3779b1u + ((unsigned)((int)0xffffffffu >= (int)(unsigned)c1) - r0.x);
                    }
                    r0.y ^= (-(unsigned)((int)(0x30b7f3e8u - 2u) >= (int)0u) & (unsigned)f0);
                    u2 += ((garr[i1 & 7u] >> (*q0 & 31u)) * ((*q0 - 0x80000000u) % (u3 | 1u)));
                    if ((unsigned)(v0 < (unsigned)((unsigned)x0 && fuel))) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)e0 && (unsigned)c0), (unsigned)(i2 == (unsigned)l0), (unsigned)w0); }
                }
                goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)(w0 >> 29) - (unsigned)(0x9c25552bu || 0xffffffffu)), (unsigned)e0, (unsigned)((short)0xddef6b89u > (signed char)(unsigned)x0)); }
            }
            q0 = &garr[(unsigned)((int)*mp < (int)((u0 | ((unsigned)d0 % (a0[i0 & 3u] | 1u))) ^ p1)) & 7u];
            do { if (--fuel == 0u) goto done;
                if (8u) {
                    if ((unsigned)(signed char)(0x5d5c0a32u % ((unsigned)l0 | 1u))) goto L1;
                    do { if (--fuel == 0u) goto done;
                        u2 = (u2 | (unsigned)(i1 || (unsigned)((unsigned)d0 && a0[i0 & 3u])));
                        switch ((unsigned)s0 & 7u) {
                            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((int)m0 >= (int)v0) || (unsigned)f0) & 255u);
                            x0 = x0 * 0x100000001b3ull + (6u ^ (p1 - i1));
                            h1 = (unsigned short)(h1 + (unsigned)(a0[i0 & 3u] == (unsigned)h1));
                            v0 = m0;
                            if ((unsigned)((unsigned)((int)v0 >= (int)r0.y) < a0[u1 & 3u])) continue;
                            if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)(p1 < 0x6eb31936u) % (0x7f107814u | 1u)), -(6u & ((unsigned)l0 - i1)), (a0[i0 & 3u] + (0xffffffffu * 0xffffffffu))); }
                        }
                    } while (i1++ < 3u && (unsigned)((short)(u1 & 4u) > (signed char)r0.y));
                    if (budget != 0u) { budget -= 1u; u2 = fn1(fuel, u3, (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x8f60d328u)); }
                    continue; (void)(a0[i0 & 3u]);
                    g1 += (unsigned)((r0.x * (i0 + u3)) || u1);
                } else {
                    s1 = (int)((unsigned)s1 + 0x2b58b445u);
                    if (budget != 0u) { budget -= 1u; u2 = fn1((0x7fffffffu ? g0 : 1u), r0.y, (unsigned)f0); }
                    a0[i1 & 3u] = (unsigned)!(unsigned)(((unsigned)x0 >> ((0xffffffffu % ((unsigned)h0 | 1u)) & 31u)) == (0x27bf9752u | u3));
                    break; (void)(((7u ^ 0xf4cde8d0u) & (unsigned)c0));
                }
                u0 ^= (unsigned)(fuel && (unsigned)s1);
            } while (i0++ < 3u && (unsigned)((p0 ^ u2) < p0));
            if ((p0 - (u3 - (unsigned)e0))) goto L0;
            if ((unsigned)((*mp ^ 0x86038346u) && 5u)) {
                switch ((unsigned)(3u < (unsigned)d0) & 7u) {
                    g1 += fuel;
                    if (budget != 0u) { budget -= 1u; u3 = fn2(((*q0 * (unsigned)f0) << (3u & 31u)), (unsigned)((int)(unsigned)s1 >= (int)(unsigned)(0x7fffffffu < garr[u2 & 7u])), ((unsigned)((short)garr[u2 & 7u] > (signed char)5u) % (0x13654194u | 1u))); }
                    if (fuel < 8u) return ((unsigned)((int)(unsigned)c0 < (int)(2u ^ 0x7fffffffu)) / (9u | 1u));
                    case 6u: ;
                }
                goto L1;
                if (-(-(unsigned)((int)(unsigned)(w0 >> 29) >= (int)0xffffffffu) | (unsigned)h1)) goto L2;
                q0 = &garr[(g0 & 0x1f5d98abu) & 7u];
                u3 += (a0[u1 & 3u] ^ (unsigned)(garr[u2 & 7u] < ~(u0 * r0.y)));
            } else {
                r0.y ^= (((unsigned)c0 + r0.x) & (unsigned)(short)(g0 ? g1 : 0x7fffffffu));
                i0 = (fuel % (r0.y | 1u)) & 15u;
                switch ((unsigned)!((unsigned)((int)r0.x < (int)0x39d775e8u) & a0[i0 & 3u]) & 7u) {
                    if (budget != 0u) { budget -= 1u; u3 = fn2(0xdc40aeaau, (unsigned)!(unsigned)((int)i0 < (int)(unsigned)((int)(unsigned)s1 < (int)*q0)), -(0xf0676f1du + (0xffffffffu >> (2u & 31u)))); }
                    b0 = (unsigned)((p0 >> (u3 & 31u)) && g0) != 0u;
                    r0.y ^= u3;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)w0, ((9u - v0) << (p2 & 31u)), (unsigned)!(0xef756e5fu << (*mp & 31u))); }
            }
        }
    }
    garr[(unsigned)c1 & 7u] = (unsigned)((-(0x80000000u | (unsigned)e0) | (unsigned)((unsigned)s1 || u2)) == u1);
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)h0, (unsigned)(v0 < ((unsigned)c1 - 0x81a43c2eu)), (unsigned)((short)a0[i0 & 3u] > (signed char)(g0 % ((unsigned)c0 | 1u)))); }
        goto L3;
        r0.y ^= ((unsigned)(a0[u1 & 3u] == (5u & 0x90220599u)) >> ((unsigned)w0 & 31u));
    } while (i0++ < 6u && garr[i1 & 7u]);
    if (fuel < 8u) return p2;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)(w0 >> 29) << (9u & 31u)));
        if (budget != 0u) { budget -= 1u; u1 = fn3(0x4c2ac929u, ((garr[i1 & 7u] >> (0xbb53b740u & 31u)) | 3u), (g1 + (i2 * (unsigned)s0))); }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch (p2 & 7u) {
                case 5u: ;
                g1 += 3u;
                case 7u: ;
                g1 += ((unsigned)(m0 || (unsigned)((7u | p1) == (unsigned)d0)) % ((unsigned)c0 | 1u));
                r0.x = (u0 & 0xe1e1b3fau);
                g1 += u2;
            }
            q0 = &garr[((unsigned)s0 + (0x1bdd5f15u >> ((unsigned)((unsigned)l0 && (unsigned)(x0 >> 70)) & 31u))) & 7u];
            if ((~((unsigned)h0 % (0x80000000u | 1u)) * *q0)) break;
        }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            while (i2++ < 7u && (p2 / ((unsigned)(signed char)(unsigned)(u1 == 0x7fffffffu) | 1u))) { if (--fuel == 0u) goto done;
                if ((unsigned)(5u && i2)) break;
                g0 = (r0.y ^ ((unsigned)((int)0xffffffffu >= (int)(unsigned)(w0 >> 29)) - (i1 ^ 0xffffffffu)));
                b0 = (unsigned)(0xffffffffu || (unsigned)((int)7u < (int)g1)) != 0u;
            }
            if (-(unsigned)(0xffffffffu == (r0.y | (unsigned)c0))) {
                g0 = (unsigned)(i0 || (unsigned)s0);
                f0 = f0 * 0.5f + (float)((8u >> (v0 & 31u)) & 255u);
            } else {
                e0 = e0 * 0.5L + (long double)(((unsigned)x0 >> ((unsigned)w0 & 31u)) & 1023u);
            }
            break; (void)(u2);
        }
    }
    if (((unsigned)b0 << ((unsigned)d0 & 31u))) goto L2;
    if ((p0 & (0x21007a9cu % (v0 | 1u)))) {
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (0xffffffffu) break;
            while (i1++ < 7u && ~(unsigned)((int)((unsigned)l0 - 0xa21f69dfu) < (int)u3)) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + ((unsigned)d0 * ((u2 / (v0 | 1u)) / (p0 | 1u))));
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)u1 > (signed char)p1), (unsigned)((unsigned)l0 == (unsigned)e0), (unsigned)(p1 == (u0 ^ v0))); }
                    if (0x10000u) break;
                    continue; (void)((unsigned)h0);
                }
                if ((unsigned)((unsigned)(unsigned char)(a0[u1 & 3u] | i1) == 0x9aa83269u)) goto L3;
                { unsigned t7; double z7; if (((unsigned)(7u == (0x1d553d52u / (u3 | 1u)))) & 1u) { t7 = (*q0 % (8u | 1u)); z7 = (double)(((unsigned)((unsigned)l0 < 0x80000000u)) & 255u); } if (((unsigned)(7u == (0x1d553d52u / (u3 | 1u)))) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                    if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)(x0 >> 70) % ((unsigned)c1 | 1u)), (u0 % (i1 | 1u)), (unsigned)((int)0x10000u >= (int)p0)); }
                    c0 = (unsigned char)((unsigned)((int)0x10000u >= (int)0x10000u) / (i2 | 1u));
                    i2 = u2 & 15u;
                }
                if (~(0x10000u / (0u | 1u))) break;
                if (budget != 0u) { budget -= 1u; u2 = fn3(9u, (p1 - (unsigned)w0), (garr[i1 & 7u] / ((p0 >> (0x491ab1dbu & 31u)) | 1u))); }
                if (((unsigned)(x0 >> 70) >> ((r0.x - i1) & 31u))) goto L4;
            }
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(v0 / ((unsigned)(w0 >> 29) | 1u)) >= (int)0x7fffffffu));
            g1 += ((*q0 + g0) % (a0[u1 & 3u] | 1u));
            r0.x = (unsigned)(0xbd134df2u && (garr[i1 & 7u] << (0x10000u & 31u)));
        }
        if ((unsigned)(unsigned char)(0x80000000u >> (garr[i1 & 7u] & 31u))) {
            if (((unsigned)l0 ^ (unsigned)c0)) goto L3;
            i2 = (0x30aae453u - (0x80000000u + (unsigned)h0)) & 15u;
            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(((unsigned)(w0 >> 29) >> (garr[i1 & 7u] & 31u)) || g0) == v0));
            if ((unsigned)(signed char)(*mp & (unsigned)((int)p0 >= (int)*mp))) goto L0;
        } else {
            f0 = f0 * 0.5f + (float)(p0 & 255u);
            *mp = (unsigned)w0;
        }
        garr[(r0.y << ((unsigned)(x0 >> 70) & 31u)) & 7u] = (0xdde90653u + ((unsigned)(x0 >> 70) | *mp));
        if ((unsigned)((unsigned)f0 < g0)) goto done;
    }
    u3 ^= (unsigned)((short)fuel > (signed char)(unsigned)((u2 ^ 3u) && (unsigned)((int)v0 >= (int)0xffffffffu)));
    switch ((unsigned)((unsigned)b0 == 0xb5830ffau) & 7u) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn2((u2 % (g0 | 1u)), (unsigned)((int)0x80000000u >= (int)(unsigned)l0), a0[u1 & 3u]); }
            while (i1++ < 4u && 6u) { if (--fuel == 0u) goto done;
                if (4u) break;
                if ((unsigned)((int)p0 >= (int)(unsigned)(a0[u1 & 3u] == 3u))) continue;
                s0 = (int)0x7fffffffu;
                u1 ^= (p0 << ((unsigned)(r0.y || u3) & 31u));
                case 7u: ;
                if (budget != 0u) { budget -= 1u; u0 = fn2(i1, (garr[u2 & 7u] | fuel), (unsigned)(i0 && (unsigned)(short)((unsigned)c1 & 0x7fffffffu))); }
            }
            u0 = u0 * 0x9e3779b1u + (((unsigned)l0 | (unsigned)(a0[i0 & 3u] == i0)) | (unsigned)((int)0xa94b9412u < (int)(unsigned)(w0 >> 29)));
            if (u3 == 7u) return (((unsigned)((int)m0 >= (int)4u) | a0[i0 & 3u]) % (g1 | 1u));
            r0.y ^= (u2 + fuel);
            w0 = w0 * 6364136223846793005ull + ~(p0 >> ((unsigned)((short)(a0[u1 & 3u] | r0.x) > (signed char)i2) & 31u));
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(*q0 < 0x2a286de5u), (*q0 & 0xcb5ae0f7u), ((0x10000u | 0x710c118cu) - u2)); }
    b0 = (unsigned)((unsigned)(x0 >> 70) == (u3 / (g0 | 1u))) != 0u;
    if (budget != 0u) { budget -= 1u; u0 = fn0(((m0 ^ (unsigned)x0) + a0[u1 & 3u]), (unsigned)((unsigned)s0 < 1u), (u1 >> (-(m0 + u3) & 31u))); }
    h1 = (unsigned short)(h1 + (unsigned)((unsigned)x0 == 0x10000u));
    u1 = u1 * 0x9e3779b1u + 0x7fffffffu;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 2u, 0x227b7537u, 0x26f09700u },
        { 15u, 0x9a0b812bu, 0xc6ea4e89u },
        { 2u, 0x2a7d9d5au, 0xd1d3f111u },
        { 0u, 0x4e25a28du, 0x9ca492b8u },
        { 7u, 0xccc6e6f0u, 0x62ae5bdeu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
