// test-ssa-source's program of seed 134000421 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x33da6f7au, g1 = 0x3ccf1b33u;
static unsigned garr[8] = { 0xffdde053u, 0x46ab3d5fu, 0x479ee8c9u, 0x3f3b6083u, 0xf06c7974u, 0x8b50b3du, 0xc74c8047u, 0xac810584u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    while (i0++ < 6u && (unsigned)s1) { if (--fuel == 0u) goto done;
        a0[p2 & 3u] = 5u;
        do { if (--fuel == 0u) goto done;
            if ((0x4fba4eu & g1)) break;
        } while (i1++ < 3u && (unsigned)((int)garr[u2 & 7u] < (int)*mp));
        q0 = &garr[(6u >> ((2u % (u3 | 1u)) & 31u)) & 7u];
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
            } while (i2++ < 7u && (unsigned)((int)a0[i0 & 3u] < (int)(i0 & i0)));
            m0 ^= (0xffffffffu & 0xffffffffu);
            s0 = (int)u0;
            if ((unsigned)x0) continue;
        } while (i1++ < 2u && (unsigned)(signed char)((unsigned)w0 << ((unsigned)h0 & 31u)));
    }
    s1 = (int)((unsigned)s1 + 0x80000000u);
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (r0.y / (0xafb271e6u | 1u)));
        if ((*mp | g0)) goto L3;
        c0 = (unsigned char)garr[u2 & 7u];
        switch ((unsigned)((int)((unsigned)(x0 >> 70) & (unsigned)x0) >= (int)(unsigned)l0) & 7u) {
            if (fuel < 8u) return (unsigned)((short)(4u << ((unsigned)((int)(unsigned)d0 >= (int)(unsigned)(0x7fffffffu < u0)) & 31u)) > (signed char)u0);
            switch ((unsigned)(r0.x || g1) & 7u) {
                h1 = (unsigned short)(h1 + (unsigned)((-(0x78e17c17u ^ a0[i0 & 3u]) << (p0 & 31u)) || (unsigned)(unsigned char)(unsigned)(i0 && u1)));
            }
            if ((unsigned)((u0 + 0x7fffffffu) == u2)) {
                do { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (unsigned)b0;
                    *mp = (*q0 / ((-(u0 & 0x80000000u) * (unsigned)((int)(unsigned)s0 >= (int)(unsigned)s0)) | 1u));
                    L2: if (--fuel == 0u) goto done;
                } while (i1++ < 5u && -(unsigned)((short)r0.x > (signed char)3u));
            }
            while (0xdc01512u) { if (--fuel == 0u) goto done;
                if ((unsigned)e0) {
                    break; (void)(g0);
                    w0 ^= (unsigned long long)0x10000u << (((unsigned)((unsigned)h0 && (unsigned)w0) + (-(g1 + a0[u1 & 3u]) & 2u)) & 63u);
                    L3: if (--fuel == 0u) goto done;
                } else {
                    u0 = (unsigned)(((unsigned)w0 | 8u) && (unsigned)(unsigned char)(unsigned)((unsigned)((int)p2 < (int)0xa2677125u) == 8u));
                    b0 = (((unsigned)h0 | 0x80000000u) & a0[u1 & 3u]) != 0u;
                }
                do { if (--fuel == 0u) goto done;
                    b0 = ((unsigned)(1u < g1) - (unsigned)((short)8u > (signed char)i2)) != 0u;
                    while (i0++ < 2u && (u1 | i1)) { if (--fuel == 0u) goto done;
                        g0 = (unsigned)(signed char)(-(unsigned)((unsigned)f0 || *mp) / ((unsigned)(2u < (6u ^ i0)) | 1u));
                        e0 = e0 * 0.5L + (long double)(3u & 1023u);
                        w0 = w0 * 6364136223846793005ull + (0x10000u + g0);
                    }
                    L4: if (--fuel == 0u) goto done;
                    case 3u: ;
                } while (i2++ < 6u && r0.x);
                q0 = &garr[((unsigned)f0 / (u3 | 1u)) & 7u];
                u3 = u3 * 0x9e3779b1u + (unsigned)b0;
                while (i2++ < 2u && (0xaca57b58u & a0[i0 & 3u])) { if (--fuel == 0u) goto done;
                    garr[garr[u2 & 7u] & 7u] = (unsigned)c1;
                    case 7u: ;
                    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (unsigned)((int)u3 < (int)a0[u1 & 3u]));
                        g1 += 0x7fffffffu;
                        *mp = (0xffffffffu ^ 0x5010c705u);
                    }
                    h0 = (short)(unsigned)(0x10000u < (unsigned)f0);
                }
                if (a0[u1 & 3u]) break;
            }
            s1 = (int)((unsigned)s1 + (~((unsigned)(*q0 < 8u) * 1u) & (0x6f08ba90u | u1)));
            for (;;) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(((unsigned)(*mp || u1) ^ (unsigned)h0) & 1023u);
                *mp = (a0[u1 & 3u] + 0xffffffffu);
                case 4u: ;
                l0 = (long)((unsigned long)l0 + (unsigned)(signed char)((unsigned)(g0 < g0) ? garr[i1 & 7u] : (8u ^ 0x80000000u)));
                g0 = ((unsigned)((int)((unsigned)x0 + i0) < (int)u1) % ((unsigned)(x0 >> 70) | 1u));
            }
        }
        h1 = (unsigned short)(h1 + p1);
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(w0 >> 29) == (unsigned)c1));
    }
    if (u3 == 7u) return (((unsigned)l0 ? 0x79f08a6u : p2) - g0);
    if (-(i2 ^ (unsigned)(short)(0xffffffffu + (unsigned)h1))) {
        w0 ^= (unsigned long long)(unsigned)(short)(*mp << (0x10000u & 31u)) << ((unsigned)((int)(unsigned)(u1 == garr[u2 & 7u]) < (int)(unsigned)(g0 || (unsigned)(garr[i1 & 7u] && (unsigned)s0))) & 63u);
        if ((unsigned)(signed char)(unsigned)((int)fuel >= (int)(unsigned)s1)) {
            if ((0x631f826bu ^ (unsigned)e0)) {
                goto done;
                if ((unsigned)((int)(i0 + u0) >= (int)0x80000000u)) {
                    u1 = ((unsigned)c0 * 8u);
                    *mp = (0x7a8c4d5du >> (a0[i0 & 3u] & 31u));
                    g1 += (((u0 + a0[u1 & 3u]) << (0u & 31u)) / (g0 | 1u));
                }
                r0.y ^= a0[u1 & 3u];
                goto L2;
                w0 ^= (unsigned long long)((unsigned)c0 + (unsigned)f0) << (((unsigned)((int)0u < (int)-(unsigned)((short)a0[i0 & 3u] > (signed char)garr[i1 & 7u])) | (unsigned)(m0 == 0xe1de8fdbu)) & 63u);
            }
            *mp = fuel;
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                v0 = (unsigned)(signed char)((unsigned)(unsigned char)(unsigned)(((unsigned)b0 << (p2 & 31u)) && (*mp >> (0xd4508aa5u & 31u))) >> (i0 & 31u));
                w0 ^= (unsigned long long)u3 << (~((unsigned)(9u || (i2 + (unsigned)w0)) | (unsigned)(fuel && 0xffffffffu)) & 63u);
                if (((unsigned)(w0 >> 29) | 2u)) break;
                if (((unsigned)l0 / (u1 | 1u))) break;
                h0 = (short)((unsigned)c0 * 0x7fffffffu);
                u2 ^= (unsigned)((~(unsigned)(p0 == 0x80000000u) / ((unsigned)d0 | 1u)) || 0x5ce4cd2u);
            }
            if ((unsigned)(x0 >> 70)) goto done;
            u2 ^= (unsigned)((int)v0 < (int)0x5887d64du);
            { unsigned t0; double z0; if ((9u) & 1u) { t0 = 0xc83225ddu; z0 = (double)((0xffffffffu) & 255u); } if ((9u) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                if (0x3d40715au) goto L1;
                if (1u) {
                    v0 = v0;
                }
                goto L4;
                switch ((8u ^ 9u) & 7u) {
                    i1 = ((unsigned)(garr[u2 & 7u] || m0) * 0xffffffffu) & 15u;
                    case 6u: ;
                }
            }
        } else {
            goto L2;
            w0 ^= (unsigned long long)(unsigned)((unsigned)h0 == p1) << ((unsigned)(short)(unsigned)((int)0x10000u >= (int)0x80000000u) & 63u);
            u1 += (unsigned)((unsigned)((int)1u >= (int)6u) < (unsigned)(unsigned char)(*mp >> ((unsigned)(x0 >> 70) & 31u)));
        }
        if (u1) goto L2;
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)(unsigned char)(p2 | r0.x) | (unsigned)f0)) {
                c1 = (signed char)(unsigned)((unsigned)c1 == (*mp - garr[i1 & 7u]));
                if (garr[i1 & 7u]) break;
                m0 ^= (0xafecebb9u / ((unsigned)((unsigned)(8u && i2) < (unsigned)x0) | 1u));
                v0 = 0x396fd8f9u;
                if ((p0 ? (unsigned)x0 : i0)) goto done;
                break; (void)((unsigned)((int)(unsigned)x0 >= (int)garr[i1 & 7u]));
            } else {
                h1 = (unsigned short)(h1 + -(unsigned)((int)(p0 & u1) >= (int)9u));
                f0 = f0 * 0.5f + (float)(-(unsigned)(u0 == 0x80000000u) & 255u);
            }
            w0 = w0 * 6364136223846793005ull + (0xffffffffu ^ (unsigned)(0u == (unsigned)d0));
            s1 = (int)((unsigned)s1 + ((unsigned)h0 << ((unsigned)(w0 >> 29) & 31u)));
            if ((unsigned)((int)(unsigned)w0 < (int)0xffffffffu)) break;
        }
        if ((unsigned)(5u < (unsigned)((int)(unsigned)x0 >= (int)(unsigned)s0))) goto L3;
        if (((unsigned)x0 * (unsigned)((short)(unsigned)e0 > (signed char)p1))) goto done;
    } else {
        while (i0++ < 2u && (unsigned)((short)(unsigned)c1 > (signed char)r0.y)) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(i0);
            }
            switch ((unsigned)(short)(unsigned)(0xffffffffu || (unsigned)((unsigned)s0 < 0x7fffffffu)) & 7u) {
                goto L2;
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    g0 = (unsigned)((int)((unsigned)(w0 >> 29) * p2) >= (int)1u);
                    break; (void)((i0 & (unsigned)(w0 >> 29)));
                }
                h1 = (unsigned short)(h1 + (unsigned)(w0 >> 29));
                c1 = (signed char)(unsigned)(fuel < (unsigned)(signed char)(unsigned)((int)(unsigned)w0 >= (int)((unsigned)b0 - (unsigned)(x0 >> 70))));
                for (;;) { if (--fuel == 0u) goto done;
                    while ((unsigned)(signed char)(unsigned)(garr[u2 & 7u] || 0x7fffffffu)) { if (--fuel == 0u) goto done;
                        if (((unsigned)h0 | 0x39bf5f17u)) continue;
                    }
                    if (8u) {
                        c0 = (unsigned char)(unsigned)((short)(unsigned)((unsigned)!(unsigned)((int)g0 >= (int)6u) || 6u) > (signed char)(unsigned)((int)0x80000000u >= (int)(unsigned)e0));
                        case 6u: ;
                    } else {
                        case 2u: ;
                    }
                    default: ;
                    case 3u: ;
                    while ((unsigned)c1) { if (--fuel == 0u) goto done;
                        if (~(unsigned)((int)(3u / ((unsigned)(x0 >> 70) | 1u)) < (int)(unsigned)b0)) goto L0;
                        v0 = ~((unsigned)(*mp < 7u) % ((unsigned)((int)(unsigned)!((unsigned)(x0 >> 70) << (g0 & 31u)) >= (int)v0) | 1u));
                        b0 = (garr[i1 & 7u] ^ (i2 * -(0xffffffffu >> ((unsigned)(short)(unsigned)((int)(unsigned)h0 < (int)m0) & 31u)))) != 0u;
                        a0[a0[i0 & 3u] & 3u] = (4u + r0.x);
                        case 0u: ;
                        { unsigned t1; double z1; if (((i0 << ((8u / ((unsigned)(w0 >> 29) | 1u)) & 31u))) & 1u) { t1 = u1; z1 = (double)(((u0 * (m0 << ((unsigned)h1 & 31u)))) & 255u); } if (((i0 << ((8u / ((unsigned)(w0 >> 29) | 1u)) & 31u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                            r0.y ^= (unsigned)(a0[i0 & 3u] < (i1 | (unsigned)(w0 >> 29)));
                            l0 = (long)((unsigned long)l0 + i0);
                            if ((unsigned)s0) goto done;
                            case 7u: ;
                        }
                    }
                    break;
                }
                { unsigned t2; double z2; if (((unsigned)(x0 >> 70)) & 1u) { t2 = (unsigned)(((unsigned)b0 / (0xffffffffu | 1u)) < 0x8b98db5fu); z2 = (double)(((unsigned)((unsigned)c0 || 2u)) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    f0 = f0 * 0.5f + (float)((*q0 ? 0x10000u : 6u) & 255u);
                }
            }
            f0 = f0 * 0.5f + (float)(((p2 / (0xffffffffu | 1u)) % ((unsigned)f0 | 1u)) & 255u);
            if ((unsigned)((unsigned)c1 < (u3 / ((unsigned)d0 | 1u)))) goto L0;
            { unsigned t3; double z3; if (((unsigned)((short)(unsigned)h0 > (signed char)0xcb860a59u)) & 1u) { t3 = 0xdb0b95e4u; z3 = (double)(((u1 & *mp)) & 255u); } if (((unsigned)((short)(unsigned)h0 > (signed char)0xcb860a59u)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                c1 = (signed char)(unsigned)(1u < (unsigned)s1);
                if ((2u & 1u)) break;
                break; (void)((unsigned)(m0 && *q0));
                continue; (void)((0xdc632d6bu << ((unsigned)((int)r0.x < (int)(unsigned)s1) & 31u)));
                if ((7u | (unsigned)(w0 >> 29))) break;
            }
            r0.x = 0x6c267d9du;
        }
    }
    while (i0++ < 5u && (unsigned)((short)p1 > (signed char)((unsigned)x0 % ((unsigned)s0 | 1u)))) { if (--fuel == 0u) goto done;
        if ((unsigned)(0x10000u || (unsigned)(0x7a0810fcu || (unsigned)b0))) continue;
    }
    w0 ^= (unsigned long long)(unsigned)((short)(unsigned)e0 > (signed char)p1) << (0x6b515939u & 63u);
    if (*mp) goto L4;
    r0.y ^= 2u;
    goto L0;
    e0 = e0 * 0.5L + (long double)(((unsigned)s1 | m0) & 1023u);
    *q0 = ((unsigned)((unsigned)x0 < 0x5bad2ed1u) + 0xeff65ec4u);
    if ((unsigned)(signed char)(0x5536acc9u & a0[u1 & 3u])) goto done;
    goto L3;
    if ((r0.y | r0.y)) goto L0;
    if (fuel < 8u) return (a0[i0 & 3u] - (unsigned)(short)(m0 % (i2 | 1u)));
    v0 = (unsigned)(unsigned char)(unsigned)((unsigned)b0 < (u3 ? ((unsigned)h0 | a0[i0 & 3u]) : i0));
    if (i1) goto L4;
    goto L2;
    b0 = -(((g0 - 3u) << (0x53903d8bu & 31u)) >> ((unsigned)s1 & 31u)) != 0u;
    if (((unsigned)w0 / ((unsigned)h0 | 1u))) {
        do { if (--fuel == 0u) goto done;
            r0.y ^= ((unsigned)((int)(unsigned)x0 < (int)p2) + ((unsigned)l0 % ((u3 << (a0[i0 & 3u] & 31u)) | 1u)));
            { unsigned t4; double z4; if (((-(unsigned)((int)9u < (int)u3) | 7u)) & 1u) { t4 = ((unsigned)c1 ^ (0x7fffffffu & 0x80000000u)); z4 = (double)(((unsigned)(3u == (garr[u2 & 7u] | (unsigned)w0))) & 255u); } if (((-(unsigned)((int)9u < (int)u3) | 7u)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                w0 = w0 * 6364136223846793005ull + (7u & a0[u1 & 3u]);
                if (i2) break;
            }
            { unsigned t5; double z5; if (((u1 * fuel)) & 1u) { t5 = p2; z5 = (double)((*q0) & 255u); } if (((u1 * fuel)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                goto L3;
                u2 ^= (unsigned)(unsigned char)(unsigned)(r0.y || (i1 / (garr[i1 & 7u] | 1u)));
            }
            garr[0x2fea3dc9u & 7u] = (unsigned)c0;
            w0 ^= (unsigned long long)(r0.y / (0x10000u | 1u)) << ((unsigned)((v0 / (*q0 | 1u)) < (0xffffffffu >> ((unsigned)f0 & 31u))) & 63u);
        } while (i0++ < 6u && (unsigned)(unsigned char)(garr[i1 & 7u] + *q0));
        if (0x10000u) goto L0;
        goto done;
        *q0 = (0xffffffffu & 0x80000000u);
    } else {
        goto done;
        if ((unsigned)((unsigned)h0 < i0)) goto L1;
        w0 = w0 * 6364136223846793005ull + (6u / ((0x8c429184u ^ (unsigned)!(unsigned)(i0 && ((unsigned)c0 / (i1 | 1u)))) | 1u));
        switch ((unsigned)((unsigned)(r0.x && (unsigned)b0) == (unsigned)b0) & 7u) {
            case 7u: ;
            goto done;
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)((int)0x7300866bu >= (int)(unsigned)f0) << (7u & 63u);
                u3 += (6u & (unsigned)(9u || 0xffffffffu));
                if (((unsigned)((int)p0 < (int)garr[u2 & 7u]) & 6u)) goto L3;
                case 0u: ;
                g0 = (unsigned)(u2 || (unsigned)(short)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)g0));
                i1 = a0[i0 & 3u] & 15u;
            }
            garr[u3 & 7u] = (unsigned)((unsigned)s0 == (0x80000000u * (unsigned)((a0[u1 & 3u] & 0x4369df2u) && fuel)));
            *q0 = (unsigned)h1;
        }
    }
    do { if (--fuel == 0u) goto done;
        if ((a0[u1 & 3u] & (unsigned)s1)) break;
        do { if (--fuel == 0u) goto done;
            q0 = &garr[((unsigned)(short)(p2 ? (p0 >> (m0 & 31u)) : 0x84281ae9u) - a0[u1 & 3u]) & 7u];
            switch ((((unsigned)s0 ^ 6u) * *q0) & 7u) {
                u2 ^= (unsigned)(a0[i0 & 3u] == (0x10000u - (0x10000u << ((unsigned)d0 & 31u))));
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    garr[(unsigned)l0 & 7u] = (unsigned)((0xd1727c75u | v0) && 0xffffffffu);
                    while (i0++ < 7u && (unsigned)s0) { if (--fuel == 0u) goto done;
                        *q0 += (unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)((int)((unsigned)h0 ? (unsigned)h1 : *q0) < (int)2u));
                        d0 = d0 * 0.5 + (double)(m0 & 1023u);
                        case 6u: ;
                        case 1u: ;
                    }
                    v0 = (r0.x ? g0 : (unsigned)b0);
                    { unsigned t6; double z6; if (((0x8dfcb363u & (unsigned)((short)(unsigned)s1 > (signed char)i0))) & 1u) { t6 = (unsigned)h0; z6 = (double)(((unsigned)l0) & 255u); } if (((0x8dfcb363u & (unsigned)((short)(unsigned)s1 > (signed char)i0))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                        case 3u: ;
                        g0 = (unsigned)((int)0x10000u < (int)((unsigned)((unsigned)c0 || *q0) & g1));
                        i0 = ((v0 & (unsigned)d0) ^ r0.x) & 15u;
                        default: ;
                        r0.y ^= (unsigned)((unsigned)s0 && 0x80000000u);
                    }
                }
                *mp = (((unsigned)(x0 >> 70) % (0x4f13de81u | 1u)) / ((0x7fffffffu & (unsigned)((short)0xdbfdbfb9u > (signed char)1u)) | 1u));
                case 2u: ;
            }
            u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)((short)(unsigned)((int)(unsigned)d0 >= (int)(unsigned)(0x80000000u < (unsigned)l0)) > (signed char)r0.y) == (unsigned)e0);
        } while (i1++ < 5u && (unsigned)!(unsigned)(0xe3d2532bu && *q0));
        w0 ^= (unsigned long long)(unsigned)((unsigned)b0 && u3) << ((garr[u2 & 7u] * 9u) & 63u);
        { unsigned t7; double z7; if ((((unsigned)((int)p2 < (int)4u) - 0x10000u)) & 1u) { t7 = (unsigned)((int)u3 < (int)(unsigned)s1); z7 = (double)((((unsigned)b0 & (0xffffffffu * (unsigned)d0))) & 255u); } if ((((unsigned)((int)p2 < (int)4u) - 0x10000u)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
            if ((unsigned)((unsigned)((int)(unsigned)h1 >= (int)0u) < m0)) break;
            u2 = (unsigned)(((unsigned)s1 & a0[u1 & 3u]) < (g1 % (((unsigned)(x0 >> 70) * u0) | 1u)));
            if ((unsigned)x0) {
                switch (u0 & 7u) {
                    d0 = d0 * 0.5 + (double)(((unsigned)x0 % ((unsigned)((unsigned)b0 && (0x2a6ca4d4u >> (0x2bd1e694u & 31u))) | 1u)) & 1023u);
                }
                do { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)(((unsigned)((unsigned)c1 == 0xf080f727u) ? v0 : 0x81f83291u) & 255u);
                } while (i1++ < 4u && (unsigned)s0);
            }
            { unsigned t8; double z8; if (((0x10000u ^ (unsigned)(short)((unsigned)f0 * 8u))) & 1u) { t8 = ((unsigned)s0 + 8u); z8 = (double)(((unsigned)((int)g0 < (int)(unsigned)d0)) & 255u); } if (((0x10000u ^ (unsigned)(short)((unsigned)f0 * 8u))) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                if ((unsigned)((unsigned)b0 || 0x10000u)) break;
                switch ((unsigned)(short)((unsigned)l0 & (unsigned)c0) & 7u) {
                    h0 = (short)(unsigned)(p2 < 0xffffffffu);
                    do { if (--fuel == 0u) goto done;
                        case 0u: ;
                        if ((unsigned)(unsigned char)(7u * (unsigned)w0)) continue;
                        f0 = f0 * 0.5f + (float)((unsigned)((short)a0[i0 & 3u] > (signed char)*mp) & 255u);
                        case 2u: ;
                    } while (i1++ < 4u && (unsigned)c1);
                    if (((unsigned)b0 ^ 8u)) break;
                }
                if ((unsigned)(unsigned char)(unsigned)((unsigned)l0 && v0)) goto L1;
                u1 = (6u + (unsigned)((int)5u >= (int)0xe2050bf8u));
                switch ((u2 - g0) & 7u) {
                    f0 = f0 * 0.5f + (float)(0x7fffffffu & 255u);
                    case 4u: ;
                }
            }
            h0 = (short)(0x10000u << ((unsigned)!(3u ? i1 : u2) & 31u));
            h1 = (unsigned short)(h1 + fuel);
        }
        if ((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)c1)) break;
        if ((p2 + i0)) goto L3;
    } while (i0++ < 6u && 0u);
    goto L4;
    f0 = f0 * 0.5f + (float)(0xcb9644d2u & 255u);
    g0 = ((0xdcb18214u / ((unsigned)(w0 >> 29) | 1u)) % (2u | 1u));
    if ((2u ^ (i0 % (0x7fffffffu | 1u)))) goto L3;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((0xffffffffu - p1)) {
            e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)!(u3 + garr[u2 & 7u]) >= (int)(unsigned)((int)(u0 << ((unsigned)c1 & 31u)) >= (int)a0[i0 & 3u])) & 1023u);
            if (0x5d928489u) continue;
            f0 = f0 * 0.5f + (float)((unsigned)((int)(garr[i1 & 7u] ^ (unsigned)((int)*q0 >= (int)0xc1dcb4d6u)) < (int)*q0) & 255u);
        }
    }
    { unsigned t9; double z9; if (((unsigned)((unsigned)(0x80000000u < 0x59dcf6d8u) < i2)) & 1u) { t9 = (garr[u2 & 7u] ^ *q0); z9 = (double)((m0) & 255u); } if (((unsigned)((unsigned)(0x80000000u < 0x59dcf6d8u) < i2)) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
        if ((unsigned)((unsigned)((unsigned)(x0 >> 70) && 2u) == u2)) {
            if ((unsigned)(0x7fffffffu && a0[i0 & 3u])) goto L1;
            if ((r0.x * (g0 % ((unsigned)f0 | 1u)))) goto L2;
            if (2u) goto L3;
            switch (~((unsigned)c1 ^ (unsigned)((int)(unsigned)f0 < (int)0x3d446e56u)) & 7u) {
                if (-(unsigned)((short)r0.x > (signed char)*mp)) goto L1;
                if (r0.y) {
                    { unsigned t10; double z10; if (((unsigned)(x0 >> 70)) & 1u) { t10 = (0u << ((unsigned)c1 & 31u)); z10 = (double)(((6u % (~(unsigned)((short)a0[i0 & 3u] > (signed char)p1) | 1u))) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                        f0 = f0 * 0.5f + (float)((1u / ((unsigned)(0u || v0) | 1u)) & 255u);
                        if ((a0[i0 & 3u] % (7u | 1u))) goto L4;
                        d0 = d0 * 0.5 + (double)((v0 - (i2 ? 0x80000000u : a0[u1 & 3u])) & 1023u);
                        g1 += (unsigned)((short)(unsigned)h1 > (signed char)((u2 + u3) * (unsigned)(g0 == a0[u1 & 3u])));
                        l0 = (long)((unsigned long)l0 + ~((unsigned)(*mp && *q0) / (0x7fffffffu | 1u)));
                        case 4u: ;
                    }
                    u1 ^= ((0x5bc1cf67u * i2) / (5u | 1u));
                    u3 = u3 * 0x9e3779b1u + (unsigned)(signed char)(unsigned)((int)(unsigned)!(m0 - 9u) >= (int)((unsigned)s0 & *q0));
                    u0 += (unsigned)!(unsigned)(0xaeb530c9u < -((unsigned)c1 ^ (unsigned)c0));
                    a0[6u & 3u] = (unsigned)((short)(unsigned)c0 > (signed char)(unsigned)x0);
                    h0 = (short)(((unsigned)e0 % (0xc3cbf5e9u | 1u)) ^ (*mp | 4u));
                }
                if (g1) {
                    case 0u: ;
                    case 5u: ;
                    u2 = u2 * 0x9e3779b1u + (unsigned)((int)(unsigned)(0x80000000u || (unsigned)d0) >= (int)(unsigned)x0);
                }
                while ((unsigned)((int)0xffffffffu >= (int)(*q0 % (4u | 1u)))) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((unsigned)(signed char)(unsigned)(i2 && (0x10000u + 0x1d44df15u)) & 1023u);
                    e0 = e0 * 0.5L + (long double)((p2 | a0[i0 & 3u]) & 1023u);
                    break; (void)((fuel << (0x10000u & 31u)));
                    *mp = (unsigned)((int)v0 >= (int)((unsigned)(i2 || g0) - r0.x));
                    if ((unsigned)h0) goto L2;
                    m0 ^= (unsigned)((int)(unsigned)(0x447a7cb2u || (6u + (unsigned)d0)) >= (int)0xffffffffu);
                }
                g0 = (((unsigned)h0 ^ (unsigned)l0) * i2);
                default: ;
            }
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                r0.x = ((u0 & 2u) ? fuel : (*q0 / ((unsigned)s0 | 1u)));
                if ((unsigned)((int)m0 < (int)garr[i1 & 7u])) break;
                if (3u) break;
                if ((unsigned)(((unsigned)d0 % (*q0 | 1u)) < *mp)) goto L4;
            } while (i1++ < 2u && (0x80000000u << ((garr[i1 & 7u] ^ a0[u1 & 3u]) & 31u)));
            *q0 += 0xf399662bu;
            break; (void)(2u);
            w0 = w0 * 6364136223846793005ull + -((unsigned)((int)(unsigned)((short)u3 > (signed char)garr[i1 & 7u]) >= (int)(unsigned)d0) & (m0 - (unsigned)(x0 >> 70)));
            v0 = (u3 & (unsigned)((int)(unsigned)h0 >= (int)0x80000000u));
        }
        goto L4;
        h1 = (unsigned short)(h1 + (unsigned)(p2 < (unsigned)(0xeb4074f3u < 9u)));
        h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)h0 < (int)(unsigned)((unsigned)(u1 == g0) == 4u)));
    }
    do { if (--fuel == 0u) goto done;
        if (fuel) {
            garr[((unsigned)(x0 >> 70) | i1) & 7u] = -(9u - (unsigned)(signed char)(unsigned)((int)a0[u1 & 3u] < (int)0x10000u));
        }
        switch (0x80000000u & 7u) {
            *mp = ((6u + 0x364b01b7u) - (unsigned)((short)0x3367bb59u > (signed char)*mp));
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 0u: ;
                case 4u: ;
            }
            default: ;
        }
    } while (i0++ < 4u && g0);
    h0 = (short)(unsigned)((i1 - a0[u1 & 3u]) && (unsigned)s1);
    if (u2) goto done;
    *mp = u2;
    u1 = (unsigned)((int)(unsigned)((int)g1 >= (int)*q0) >= (int)(g0 >> (4u & 31u)));
    if ((6u * 0x10000u)) goto L2;
    if ((unsigned)(short)((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)d0) << (i0 & 31u))) goto L0;
    a0[0xb4e5d8dfu & 3u] = ((unsigned)h0 >> ((unsigned)((unsigned)w0 && garr[u2 & 7u]) & 31u));
    x0 = x0 * 0x100000001b3ull + (0x10000u - *mp);
    a0[((unsigned)e0 + 0xd542b70u) & 3u] = (unsigned)b0;
    if (u2) {
        *mp = (6u & (unsigned)(r0.x || 2u));
        if (-(unsigned)((int)garr[i1 & 7u] < (int)(unsigned)(x0 >> 70))) goto L1;
    } else {
        goto L4;
        e0 = e0 * 0.5L + (long double)((unsigned)((int)(r0.y << (u3 & 31u)) < (int)(0xe09c581au >> ((unsigned)s1 & 31u))) & 1023u);
        w0 ^= (unsigned long long)(unsigned)(5u == 0x80000000u) << ((unsigned)(0x64e7a353u && (garr[u2 & 7u] << ((unsigned)b0 & 31u))) & 63u);
    }
    u3 += 3u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if (((unsigned)(6u || (unsigned)(r0.x && v0))) & 1u) { t0 = (unsigned)(short)(unsigned)((int)(unsigned)(0x9f4e8b9cu < (unsigned)w0) >= (int)(unsigned)w0); z0 = (double)(((unsigned)((int)0u < (int)(g1 | i1))) & 255u); } if (((unsigned)(6u || (unsigned)(r0.x && v0))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if ((0x85cb0958u ^ (unsigned)b0)) {
            if ((unsigned)((unsigned)f0 < (unsigned)f0)) goto L1;
        }
    }
    d0 = d0 * 0.5 + (double)((unsigned)((short)2u > (signed char)((unsigned)(signed char)(u1 + *mp) ^ (unsigned)s1)) & 1023u);
    goto L4;
    if (0xada55a7du) goto L1;
    x0 = x0 * 0x100000001b3ull + (unsigned)(0xdd6ef1acu || 0xfab48c77u);
    if ((r0.y / (fuel | 1u))) goto L1;
    if ((unsigned)(0xefd26c0eu || 7u)) goto L0;
    if ((u2 >> (u1 & 31u))) goto L1;
    if (budget != 0u) { budget -= 1u; u2 = fn0(0x5853a268u, (m0 << ((unsigned)(2u || u1) & 31u)), (unsigned)s0); }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)(x0 >> 70) << (0xd5f47f25u & 31u))) {
            switch (((0x7fffffffu | u0) % (v0 | 1u)) & 7u) {
                d0 = d0 * 0.5 + (double)(((unsigned)b0 ^ p2) & 1023u);
                L0: if (--fuel == 0u) goto done;
                *q0 = 0x80000000u;
                L1: if (--fuel == 0u) goto done;
                c0 = (unsigned char)(3u % (((unsigned)((unsigned)(w0 >> 29) && (a0[i0 & 3u] % (i1 | 1u))) - g1) | 1u));
            }
            g0 = (unsigned)((unsigned)(x0 >> 70) == (unsigned)((int)u0 < (int)r0.y));
            b0 = (0x10000u << (0x47021250u & 31u)) != 0u;
        }
        { unsigned t1; double z1; if ((r0.y) & 1u) { t1 = ((unsigned)l0 ^ (a0[i0 & 3u] | a0[u1 & 3u])); z1 = (double)((~(i2 * (unsigned)!(0x80000000u / ((unsigned)c0 | 1u)))) & 255u); } if ((r0.y) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            if ((unsigned)(signed char)(unsigned)(m0 || i0)) break;
            break; (void)((3u - garr[u2 & 7u]));
            if ((u2 ^ (a0[u1 & 3u] >> (g0 & 31u)))) break;
            if ((unsigned)(0x93389c1cu || (unsigned)w0)) break;
        }
        l0 = (long)((unsigned long)l0 + ((unsigned)(signed char)(*q0 << (2u & 31u)) & 0x1bf18f27u));
        continue; (void)((unsigned)((short)m0 > (signed char)(unsigned)(unsigned char)(unsigned)(u2 && 7u)));
    }
    while ((unsigned)((unsigned)(signed char)(unsigned)(g1 == p0) == u3)) { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)(short)(unsigned)((int)(unsigned)s0 < (int)(unsigned)c0);
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)((unsigned)((unsigned)((int)r0.y >= (int)*mp) && (unsigned)h1) - g1);
            if ((p1 % (g1 | 1u))) break;
        }
    }
    if ((0x7fffffffu ^ (unsigned)(x0 >> 70))) goto L3;
    h0 = (short)(unsigned)((g0 >> (*q0 & 31u)) || ((unsigned)x0 % ((unsigned)(w0 >> 29) | 1u)));
    s1 = (int)((unsigned)s1 + p2);
    if ((unsigned)!(a0[u1 & 3u] - 6u)) {
        if ((((unsigned)c0 & (unsigned)x0) - p1)) {
            q0 = &garr[(unsigned)((unsigned)h0 && (unsigned)s0) & 7u];
            h0 = (short)(unsigned)((0x7fffffffu >> (0xffffffffu & 31u)) == ((unsigned)(0u < (unsigned)e0) ^ p0));
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                u2 = (unsigned)(r0.x || (u2 ? g1 : (p2 * (unsigned)c1)));
                h0 = (short)garr[u2 & 7u];
                q0 = &garr[(((unsigned)(0xf38b44fu && 9u) ? *q0 : 0xd3dd6157u) * p0) & 7u];
                if (0xffffffffu) goto L2;
                v0 = (p1 ? i2 : 1u);
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    L2: if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (unsigned)c1);
                    h1 = (unsigned short)(h1 + ((unsigned)(garr[u2 & 7u] || (unsigned)c0) % (0x80000000u | 1u)));
                    c1 = (signed char)(unsigned)(short)(unsigned)((unsigned)l0 < (unsigned)(0xf8151c9au || (unsigned)c0));
                    m0 ^= (garr[u2 & 7u] - 0x64e50c6fu);
                    do { if (--fuel == 0u) goto done;
                        { unsigned t2; double z2; if (((unsigned)(signed char)((unsigned)s0 ? p1 : 8u)) & 1u) { t2 = (u1 % (1u | 1u)); z2 = (double)((0x80000000u) & 255u); } if (((unsigned)(signed char)((unsigned)s0 ? p1 : 8u)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                            w0 ^= (unsigned long long)0x3faf273u << ((unsigned)(0xf53ad881u < (unsigned)(fuel == p2)) & 63u);
                            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)c0), ~(0x29f382c8u ^ (unsigned)(signed char)(0xf7003ccbu << (0u & 31u))), i0); }
                            g1 += -((unsigned)f0 ? (unsigned)c0 : garr[u2 & 7u]);
                            u1 += ((v0 & (unsigned)c0) % ((unsigned)((unsigned)h1 && (unsigned)(0xce21d489u || u3)) | 1u));
                            continue; (void)((unsigned)((short)(u0 | 0xf1f66eeeu) > (signed char)(unsigned)f0));
                            q0 = &garr[-(unsigned)((u0 + ((unsigned)h0 - 0xd4d71e2cu)) && 0xffffffffu) & 7u];
                        }
                        if (~(unsigned)((short)0xba8f4f1bu > (signed char)(g1 * garr[i1 & 7u]))) break;
                        s0 = (int)(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)d0);
                    } while (i2++ < 6u && ((unsigned)b0 + (unsigned)((short)i2 > (signed char)g0)));
                }
            }
        } else {
            if ((unsigned)(u0 == u2)) goto L2;
            if ((unsigned)(w0 >> 29)) {
                L3: if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                goto L1;
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(u3 == (unsigned)b0) || (unsigned)x0), ((unsigned)(u3 == 0x80000000u) | a0[u1 & 3u]), ((unsigned)f0 * (g1 % (r0.y | 1u)))); }
                }
                h0 = (short)7u;
            }
            if (((unsigned)f0 << (u0 & 31u))) goto L4;
            *q0 += ((unsigned)((unsigned)b0 < (~((unsigned)h1 & r0.x) >> (u2 & 31u))) * a0[i0 & 3u]);
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((r0.x | (unsigned)c0) || a0[u1 & 3u]), (unsigned)(short)((unsigned)d0 ^ a0[i0 & 3u]), (u3 * (unsigned)(i2 < (unsigned)x0))); }
        r0.x = (g1 & g0);
    } else {
        if ((garr[i1 & 7u] - (unsigned)d0)) {
            goto L4;
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                s0 = (int)(unsigned)((unsigned)(x0 >> 70) || (unsigned)((int)p0 < (int)g1));
            }
            if (0x76201c86u) goto done;
        }
        while (i0++ < 4u && (*q0 | g0)) { if (--fuel == 0u) goto done;
            while (i1++ < 2u && (unsigned)d0) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)((int)p1 >= (int)(unsigned)x0) < 0x8edafc70u)) break;
                if (fuel < 8u) return (u0 << (u1 & 31u));
                d0 = d0 * 0.5 + (double)(((unsigned)(p2 == ((unsigned)x0 % (0u | 1u))) * i0) & 1023u);
                *q0 = (unsigned)(i1 || ((unsigned)((int)(0xffffffffu ^ (unsigned)e0) >= (int)r0.y) % (i1 | 1u)));
                if ((unsigned)l0) break;
            }
            if (~(unsigned)((unsigned)(short)((unsigned)d0 * (unsigned)h0) && u2)) break;
            while (i1++ < 6u && (garr[u2 & 7u] - u1)) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)5u < (int)a0[u1 & 3u])) {
                    if (budget != 0u) { budget -= 1u; u3 = fn0(i1, 8u, (unsigned)((g1 + 0xffffffffu) && 8u)); }
                }
            }
        }
        { unsigned t3; double z3; if ((-(4u - a0[u1 & 3u])) & 1u) { t3 = (unsigned)((int)(unsigned)e0 >= (int)i1); z3 = (double)(((unsigned)s1) & 255u); } if ((-(4u - a0[u1 & 3u])) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            if (budget != 0u) { budget -= 1u; u2 = fn0(i0, (unsigned)(w0 >> 29), ((unsigned)f0 | (unsigned)(u2 == (unsigned)x0))); }
            { unsigned t4; double z4; if ((~(unsigned)(0xda2a034u && i1)) & 1u) { t4 = fuel; z4 = (double)((~(unsigned)((int)(unsigned)((unsigned)l0 < i0) >= (int)(unsigned)f0)) & 255u); } if ((~(unsigned)(0xda2a034u && i1)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                if (v0) goto L4;
                if (a0[i0 & 3u]) goto L2;
                if (budget != 0u) { budget -= 1u; u2 = fn0(0x7fffffffu, fuel, (((unsigned)e0 ^ 0x39733856u) & 0x7fffffffu)); }
                h1 = (unsigned short)(h1 + (unsigned)((a0[u1 & 3u] + i0) && g1));
                if (budget != 0u) { budget -= 1u; u3 = fn0((7u & u3), (unsigned)!((unsigned)c0 & (unsigned)s0), (unsigned)f0); }
            }
            u3 += fuel;
            switch ((unsigned)l0 & 7u) {
                if (budget != 0u) { budget -= 1u; u1 = fn0(9u, (unsigned)((int)0x7fffffffu < (int)(unsigned)b0), (unsigned)b0); }
                for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    g0 = (0x5ef4f5du * (r0.x + (u3 * (unsigned)h0)));
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)c1 ? (unsigned)x0 : garr[i1 & 7u]), (unsigned)((short)(unsigned)((unsigned)l0 || u3) > (signed char)(unsigned)h0), (unsigned)((unsigned)((int)4u < (int)u2) == i1)); }
                    c1 = (signed char)(unsigned)w0;
                    r0.y ^= 0x6fa90077u;
                    f0 = f0 * 0.5f + (float)((0xffffffffu & (unsigned)(0x7fffffffu < garr[i1 & 7u])) & 255u);
                    while (i1++ < 5u && v0) { if (--fuel == 0u) goto done;
                        case 2u: ;
                        case 6u: ;
                        switch ((unsigned)((int)fuel >= (int)p0) & 7u) {
                            if ((6u / (((unsigned)c0 * (unsigned)s1) | 1u))) continue;
                            w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)(unsigned)((int)(unsigned)s0 >= (int)((unsigned)s1 - (unsigned)e0));
                        }
                        case 5u: ;
                        if ((unsigned)(w0 >> 29)) goto L2;
                        if ((p1 >> (((unsigned)h1 ^ (unsigned)(w0 >> 29)) & 31u))) continue;
                    }
                }
                if ((0x80000000u << ((unsigned)(p0 || (unsigned)s0) & 31u))) goto L1;
                h0 = (short)(unsigned)(unsigned char)(unsigned)(*q0 == (unsigned)!(unsigned)((6u * p1) == (p0 ^ garr[i1 & 7u])));
                if (0x7fffffffu) {
                    w0 ^= (unsigned long long)u2 << (2u & 63u);
                    c0 = (unsigned char)(p1 + 0xb72bec34u);
                    if ((2u | fuel)) {
                        q0 = &garr[((unsigned)((v0 << (m0 & 31u)) && u0) * (unsigned)(x0 >> 70)) & 7u];
                        *q0 = ((4u / ((unsigned)s0 | 1u)) - (unsigned)(v0 < (r0.y - u3)));
                        x0 = x0 * 0x100000001b3ull + (unsigned)(m0 || ((unsigned)(u3 || r0.x) / (0x10000u | 1u)));
                        if ((g0 | (unsigned)((unsigned)e0 == p0))) {
                            if ((i0 | r0.x)) break;
                        } else {
                            case 7u: ;
                            *q0 = (unsigned)(u3 == (unsigned)((0x10000u + 3u) || (unsigned)((short)m0 > (signed char)v0)));
                            case 3u: ;
                            case 1u: ;
                        }
                        goto L4;
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0x10000u & (unsigned)(signed char)(unsigned)((int)(unsigned)c0 < (int)6u)), (unsigned)((int)(unsigned)h0 >= (int)g1), (unsigned)((unsigned)h0 < (unsigned)((short)(unsigned)w0 > (signed char)0x489df4feu))); }
                    if (fuel < 8u) return (unsigned)((short)(unsigned)x0 > (signed char)((unsigned)((unsigned)x0 || (unsigned)d0) * 5u));
                    while (i0++ < 2u && (unsigned)((short)9u > (signed char)(unsigned)(v0 || 0xebe43d18u))) { if (--fuel == 0u) goto done;
                        u0 += (unsigned)w0;
                        if ((unsigned)h0) break;
                        if ((u1 % (fuel | 1u))) break;
                        if ((unsigned)d0) continue;
                        w0 ^= (unsigned long long)garr[u2 & 7u] << ((u2 - garr[i1 & 7u]) & 63u);
                        default: ;
                    }
                } else {
                    d0 = d0 * 0.5 + (double)(((0x7fffffffu ^ (unsigned)s1) * ((unsigned)b0 * u3)) & 1023u);
                }
                if ((unsigned)(w0 >> 29)) goto L3;
            }
            if ((unsigned)(signed char)((unsigned)c0 ^ *mp)) {
                goto L2;
                goto done;
            }
            { unsigned t5; double z5; if ((garr[u2 & 7u]) & 1u) { t5 = (a0[i0 & 3u] ^ (i2 - 0xc1b28775u)); z5 = (double)((0x80000000u) & 255u); } if ((garr[u2 & 7u]) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                if (((unsigned)f0 - a0[u1 & 3u])) goto L4;
                goto L1;
                if ((unsigned)((short)(unsigned)((short)p0 > (signed char)0xffffffffu) > (signed char)(unsigned)h0)) goto L0;
                u2 = u2 * 0x9e3779b1u + ((unsigned)((int)(unsigned)(0xffffffffu < fuel) < (int)g0) << (3u & 31u));
                m0 ^= (unsigned)b0;
                switch ((unsigned)h0 & 7u) {
                    if (4u) goto L2;
                }
            }
        }
    }
    goto done;
    do { if (--fuel == 0u) goto done;
        u3 += (unsigned)((unsigned)((unsigned)w0 < u2) < (fuel << (a0[i0 & 3u] & 31u)));
        if ((garr[u2 & 7u] * 2u)) break;
    } while (i0++ < 3u && (unsigned)(0u < (unsigned)((short)0xb5b903a4u > (signed char)0x7fffffffu)));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)u3 << ((unsigned)(signed char)(i1 + (unsigned)(garr[i1 & 7u] < (unsigned)e0)) & 63u);
            g0 = (unsigned)((short)(0x10000u << (i2 & 31u)) > (signed char)0x4809943bu);
            *q0 += (unsigned)((unsigned)l0 || (unsigned)((short)m0 > (signed char)(unsigned)(p1 < 0x7fffffffu)));
            if (((unsigned)s0 + (unsigned)f0)) break;
        } while (i1++ < 2u && (0xffffffffu ^ fuel));
        if (((1u >> (0x7fffffffu & 31u)) - garr[u2 & 7u])) goto L2;
        break; (void)(g0);
        if (fuel < 8u) return (unsigned)((unsigned)((unsigned)c1 == garr[i1 & 7u]) || ((unsigned)h0 / (0x169df1beu | 1u)));
    }
    u1 ^= (((unsigned)h1 ^ (unsigned)c0) ^ 5u);
    goto L4;
    goto L2;
    if ((0x8f941f1bu ^ p0)) {
        e0 = e0 * 0.5L + (long double)(((unsigned)b0 << (((unsigned)d0 + (0u % (((unsigned)b0 * *mp) | 1u))) & 31u)) & 1023u);
        while (i0++ < 2u && i0) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)(unsigned char)(unsigned)(0xffffffffu == (unsigned)(x0 >> 70)) >= (int)p0) & 1023u);
        }
        if (-(unsigned)((int)(unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)c1) < (int)garr[u2 & 7u])) {
            if ((unsigned)(0x716788c2u || (unsigned)((short)0x10000u > (signed char)0x7fffffffu))) goto done;
        } else {
            goto L2;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)u1 < (int)p2), (unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x80000000u), (unsigned)((unsigned)x0 && 3u)); }
            u1 = u1 * 0x9e3779b1u + (unsigned)(p1 == garr[i1 & 7u]);
        }
        e0 = e0 * 0.5L + (long double)(a0[i0 & 3u] & 1023u);
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)garr[u2 & 7u] >= (int)(0x7fffffffu >> (r0.x & 31u))), (unsigned)(w0 >> 29), (unsigned)((int)0xcc01ea66u >= (int)(unsigned)s1)); }
    } else {
        g1 += (0xffffffffu << ((0x8630764du - (unsigned)((unsigned)l0 < 4u)) & 31u));
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (i1 ? (unsigned)(x0 >> 70) : 0x7203c333u);
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (0x6339494u << ((unsigned)c1 & 31u));
                q0 = &garr[(a0[i0 & 3u] ^ (((unsigned)!(unsigned)((short)i0 > (signed char)(unsigned)w0) / ((unsigned)s1 | 1u)) / ((unsigned)(w0 >> 29) | 1u))) & 7u];
            }
        }
        if ((unsigned)((short)(a0[i0 & 3u] + (unsigned)x0) > (signed char)0xffffffffu)) {
            if (u3 == 7u) return ((unsigned)((short)*q0 > (signed char)(unsigned)d0) & (r0.x ? fuel : 2u));
            a0[a0[u1 & 3u] & 3u] = (unsigned)(short)(unsigned)((unsigned)(signed char)((unsigned)h0 - fuel) && ((unsigned)((unsigned)(w0 >> 29) && u0) - (unsigned)(w0 >> 29)));
            while (i0++ < 4u && 8u) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    switch (((unsigned)f0 * (unsigned)(x0 >> 70)) & 7u) {
                        switch (((g1 << (m0 & 31u)) - 5u) & 7u) {
                            u2 = u2 * 0x9e3779b1u + ~(((unsigned)(signed char)(unsigned)(p0 || (unsigned)e0) << ((unsigned)w0 & 31u)) - ~(unsigned)((unsigned)f0 < 0x7274113au));
                        }
                        switch (((i1 & 0x68dec797u) + 0xdbab5f5cu) & 7u) {
                            l0 = (long)((unsigned long)l0 + ((unsigned)d0 | ((0xcfef49a5u << ((p2 + fuel) & 31u)) >> ((unsigned)w0 & 31u))));
                            case 6u: ;
                        }
                    }
                    if ((((unsigned)h1 >> (0x10000u & 31u)) - p2)) continue;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)w0, u2, (0x80000000u << (((unsigned)b0 % ((unsigned)d0 | 1u)) & 31u))); }
                }
                goto done;
                break; (void)((i1 & v0));
            }
            s0 = (int)(0x80000000u & p1);
        }
        if ((g0 << (u2 & 31u))) goto L4;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0(p2, (unsigned)((short)9u > (signed char)(8u + (unsigned)(w0 >> 29))), (unsigned)w0); }
    goto L4;
    { unsigned t6; double z6; if (((4u - (unsigned)c0)) & 1u) { t6 = (unsigned)e0; z6 = (double)(((unsigned)f0) & 255u); } if (((4u - (unsigned)c0)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        if (u3 == 7u) return ((unsigned)f0 << ((unsigned)d0 & 31u));
        if (0x967774c1u) goto L2;
        if (0x4a97dc0au) goto L4;
        h0 = (short)((unsigned)c0 % (0x10000u | 1u));
    }
    switch ((unsigned)((short)((unsigned)(w0 >> 29) - (unsigned)s0) > (signed char)0x7fffffffu) & 7u) {
        u1 = 0x7ae3281fu;
    }
    if ((6u * 0x80000000u)) {
        a0[(unsigned)!(0x10000u << (0x80000000u & 31u)) & 3u] = (unsigned)(0x10000u && 0x857f4a34u);
        switch (4u & 7u) {
            case 5u: ;
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                *q0 += a0[i0 & 3u];
                do { if (--fuel == 0u) goto done;
                    case 4u: ;
                    if ((0x96209dabu % (p2 | 1u))) goto L2;
                } while (i1++ < 4u && 0xffffffffu);
                u1 = (unsigned)(unsigned char)((unsigned)((int)r0.x >= (int)(unsigned)(x0 >> 70)) + 0xffffffffu);
                c1 = (signed char)(unsigned)((int)(unsigned)((int)a0[i0 & 3u] >= (int)a0[i0 & 3u]) < (int)(unsigned)((int)0x7fffffffu >= (int)7u));
                break; (void)(((unsigned)h0 ^ u2));
                e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)h1 >= (int)(unsigned)((short)2u > (signed char)(unsigned)(unsigned char)((unsigned)e0 / (v0 | 1u)))) & 1023u);
            }
            { unsigned t7; double z7; if (((g1 / (0x10000u | 1u))) & 1u) { t7 = (g0 * a0[u1 & 3u]); z7 = (double)(((unsigned)(i1 && (unsigned)s1)) & 255u); } if (((g1 / (0x10000u | 1u))) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                if (budget != 0u) { budget -= 1u; u3 = fn0(a0[i0 & 3u], (unsigned)((int)(unsigned)(signed char)(unsigned)(0x10000u && 0x7fffffffu) >= (int)r0.y), (unsigned)s1); }
                if (budget != 0u) { budget -= 1u; u1 = fn0(u0, g0, (unsigned)w0); }
                case 0u: ;
            }
            m0 ^= (unsigned)(1u || *q0);
            u2 = u2 * 0x9e3779b1u + ((unsigned)d0 / ((unsigned)((int)(a0[u1 & 3u] % ((0x7b432f4au & (unsigned)s0) | 1u)) < (int)p0) | 1u));
        }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(fuel || u1), garr[i1 & 7u], (0x937560feu % ((unsigned)h1 | 1u))); }
    h0 = (short)(unsigned)(6u && (unsigned)(p0 || 0x10000u));
    if ((0x10000u << (~(g0 << (0xffffffffu & 31u)) & 31u))) goto L4;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        goto L2;
    }
    g1 += (unsigned)c1;
    if ((unsigned)((int)((unsigned)(w0 >> 29) ^ 0xffffffffu) < (int)5u)) goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto done;
    if (p0) goto L2;
    h1 = (unsigned short)(h1 + (unsigned)!(unsigned)(0xada423efu && r0.y));
    h1 = (unsigned short)(h1 + (*mp + ((0x10000u / ((unsigned)x0 | 1u)) - (unsigned)h0)));
    b0 = (unsigned)h1 != 0u;
    { unsigned t0; double z0; if (((0x80000000u | (unsigned)(x0 >> 70))) & 1u) { t0 = (unsigned)((unsigned)b0 == 1u); z0 = (double)((((unsigned)(unsigned char)(0xffffffffu / (r0.y | 1u)) % (a0[u1 & 3u] | 1u))) & 255u); } if (((0x80000000u | (unsigned)(x0 >> 70))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        { unsigned t1; double z1; if ((r0.y) & 1u) { t1 = (~(garr[i1 & 7u] / (0x7fffffffu | 1u)) | g1); z1 = (double)((-(0x7fffffffu / (i0 | 1u))) & 255u); } if ((r0.y) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            h0 = (short)(unsigned)((int)(unsigned)x0 >= (int)*mp);
            u2 += ((unsigned)s0 % (garr[i1 & 7u] | 1u));
            u3 = u3 * 0x9e3779b1u + (3u * ((unsigned)x0 & (g1 + (unsigned)w0)));
            x0 = x0 * 0x100000001b3ull + -(unsigned)((unsigned)!(unsigned)((unsigned)f0 && (unsigned)x0) < (0xd3dfe6f6u ^ 1u));
            f0 = f0 * 0.5f + (float)(((0x7fffffffu + ((unsigned)f0 | (unsigned)((int)(unsigned)c1 >= (int)*mp))) << (i1 & 31u)) & 255u);
        }
        if ((*q0 + (u0 >> ((unsigned)h0 & 31u)))) goto L0;
        x0 = x0 * 0x100000001b3ull + p0;
        goto L4;
        u3 = u3 * 0x9e3779b1u + -(unsigned)((int)(unsigned)((short)0x2497768cu > (signed char)0x731832d9u) < (int)(unsigned)(p1 == u2));
    }
    switch ((unsigned)!(0xf838ca34u % ((0x9b4303a5u - (unsigned)f0) | 1u)) & 7u) {
        while (-(0x27ea0607u % (a0[u1 & 3u] | 1u))) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (unsigned)((short)garr[i1 & 7u] > (signed char)garr[u2 & 7u]);
                w0 ^= (unsigned long long)a0[u1 & 3u] << (((((unsigned)((int)(unsigned)s0 < (int)3u) + u2) + (unsigned)l0) << (m0 & 31u)) & 63u);
                x0 = x0 * 0x100000001b3ull + ((unsigned)(u0 || a0[u1 & 3u]) << (p1 & 31u));
                if ((a0[i0 & 3u] + ((unsigned)s1 & (unsigned)s0))) goto L1;
                r0.x = (unsigned)((int)garr[i1 & 7u] >= (int)(0u ^ *mp));
            }
            if ((unsigned)s0) {
                if ((*mp ? 0xffffffffu : r0.y)) goto L1;
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)b0, (6u * r0.x), (unsigned)((unsigned)s0 < 0x7fffffffu)); }
                w0 = w0 * 6364136223846793005ull + (unsigned)!(((unsigned)x0 >> (fuel & 31u)) | ((unsigned)l0 * (garr[u2 & 7u] << (0x80000000u & 31u))));
            }
            d0 = d0 * 0.5 + (double)(g1 & 1023u);
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)((short)a0[i0 & 3u] > (signed char)g0);
        if (((unsigned)((int)u2 < (int)*q0) | (unsigned)(w0 >> 29))) {
            d0 = d0 * 0.5 + (double)(m0 & 1023u);
            b0 = ((unsigned)e0 ^ (unsigned)((unsigned)c0 || (unsigned)s1)) != 0u;
            case 1u: ;
        }
        L0: if (--fuel == 0u) goto done;
        b0 = (unsigned)!(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(u0 ^ 0xffffffffu)) != 0u;
        { unsigned t2; double z2; if ((((unsigned)h1 + 0x9d9b9629u)) & 1u) { t2 = (unsigned)c1; z2 = (double)(((unsigned)((unsigned)((unsigned)x0 || g0) == (unsigned)c0)) & 255u); } if ((((unsigned)h1 + 0x9d9b9629u)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            while (i0++ < 3u && p0) { if (--fuel == 0u) goto done;
                h0 = (short)(unsigned)((int)(0x7fffffffu - *mp) >= (int)((unsigned)c1 | (unsigned)s1));
                c0 = (unsigned char)(unsigned)((int)((unsigned)x0 & -(unsigned)(0xa8735da1u && garr[u2 & 7u])) >= (int)(unsigned)(i2 == 0x269f5577u));
                *q0 = (unsigned)b0;
            }
            u1 += (garr[u2 & 7u] / (~(*mp ^ (0xd30cac7u | garr[u2 & 7u])) | 1u));
            case 7u: ;
            while (i0++ < 2u && ((unsigned)d0 * (unsigned)c1)) { if (--fuel == 0u) goto done;
                a0[u0 & 3u] = g0;
                case 6u: ;
                if ((unsigned)(unsigned char)(g1 | 0x80000000u)) {
                    x0 = x0 * 0x100000001b3ull + ((a0[u1 & 3u] >> (6u & 31u)) - p0);
                    u3 ^= (unsigned)((unsigned)((int)u2 >= (int)r0.x) && (unsigned)(u0 < i1));
                    case 4u: ;
                    r0.y ^= (unsigned)((u2 ^ (4u >> ((unsigned)x0 & 31u))) < (unsigned)(p0 && p1));
                } else {
                    if (fuel < 8u) return ((unsigned)e0 << (r0.y & 31u));
                    switch ((unsigned)(fuel == (unsigned)h1) & 7u) {
                        if ((garr[u2 & 7u] | (0x10000u << (0x7fffffffu & 31u)))) continue;
                        u1 ^= (((unsigned)l0 >> (g0 & 31u)) % ((unsigned)((short)(a0[i0 & 3u] * 0x852e18fau) > (signed char)i1) | 1u));
                        { unsigned t3; double z3; if (((unsigned)(2u && a0[i0 & 3u])) & 1u) { t3 = (unsigned)((int)(unsigned)h0 >= (int)a0[i0 & 3u]); z3 = (double)(((unsigned)f0) & 255u); } if (((unsigned)(2u && a0[i0 & 3u])) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                            u1 = ((unsigned)h1 - ((unsigned)(w0 >> 29) + -(0xfe0e312u + (unsigned)(x0 >> 70))));
                            q0 = &garr[a0[u1 & 3u] & 7u];
                            if ((unsigned)((short)(unsigned)c0 > (signed char)((unsigned)h0 << ((unsigned)x0 & 31u)))) goto L0;
                            L1: if (--fuel == 0u) goto done;
                        }
                        L2: if (--fuel == 0u) goto done;
                        m0 ^= ((u2 << ((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)(0x47f001f3u && a0[u1 & 3u])) & 31u)) | (unsigned)h0);
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((int)(unsigned)h0 >= (int)a0[i0 & 3u]) & (unsigned)b0), (6u & *mp), 4u); }
                    }
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        m0 ^= ((unsigned)d0 >> ((garr[u2 & 7u] - v0) & 31u));
                    }
                    if ((6u | (unsigned)(u1 < p2))) {
                        u3 = (4u - p1);
                        if (budget != 0u) { budget -= 1u; u2 = fn0((5u ^ (unsigned)c0), (unsigned)c0, u0); }
                    }
                }
            }
        }
    }
    l0 = (long)((unsigned long)l0 + (unsigned)((int)a0[u1 & 3u] >= (int)((unsigned)((int)0x2ed2e1f8u >= (int)(5u - 0x456f1d9cu)) >> ((unsigned)h1 & 31u))));
    do { if (--fuel == 0u) goto done;
        a0[v0 & 3u] = 0x80000000u;
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (m0) goto L4;
            if (u3 == 7u) return ~(unsigned)((unsigned)w0 == *q0);
            L3: if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
            if (u2) goto L1;
        }
        if (0x10000u) continue;
        do { if (--fuel == 0u) goto done;
            a0[((unsigned)(x0 >> 70) >> ((unsigned)b0 & 31u)) & 3u] = (unsigned)((0x7c18cecau ^ m0) && ((unsigned)(i2 && p0) >> (0xffffffffu & 31u)));
            if (budget != 0u) { budget -= 1u; u2 = fn1((a0[i0 & 3u] / (g1 | 1u)), (unsigned)((unsigned)((unsigned)h0 && *q0) == 0xdbc933f5u), (a0[u1 & 3u] ^ 0u)); }
            m0 ^= (unsigned)((int)((unsigned)((short)5u > (signed char)g0) / ((unsigned)s0 | 1u)) < (int)0x8a25c2b1u);
            if ((r0.y / ((unsigned)e0 | 1u))) break;
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)r0.x >= (int)(unsigned)f0), i1, (unsigned)((int)(8u + garr[u2 & 7u]) < (int)g0)); }
                b0 = (unsigned)((int)(unsigned)((int)i0 < (int)0x92219d76u) >= (int)garr[i1 & 7u]) != 0u;
                if ((unsigned)s1) goto L2;
                break; (void)(r0.y);
                h0 = (short)(unsigned)((short)(unsigned)(p2 || i1) > (signed char)(unsigned)(0xffffffffu && garr[i1 & 7u]));
                do { if (--fuel == 0u) goto done;
                    { unsigned t4; double z4; if ((((unsigned)((int)u0 < (int)0x9fcdfbddu) | (unsigned)b0)) & 1u) { t4 = garr[u2 & 7u]; z4 = (double)(((unsigned)f0) & 255u); } if ((((unsigned)((int)u0 < (int)0x9fcdfbddu) | (unsigned)b0)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((int)(garr[u2 & 7u] & i2) >= (int)u2) == (unsigned)!(i0 | g1)) & 1023u);
                    }
                    g0 = (unsigned)((int)u2 >= (int)((0x82487d17u << ((0xa5e22818u ^ v0) & 31u)) ^ 0xffffffffu));
                    if (budget != 0u) { budget -= 1u; u1 = fn1(0xee1c9ffeu, (unsigned)(0x80000000u < 0x7fffffffu), a0[i0 & 3u]); }
                } while (i0++ < 2u && (unsigned)!(0x25048cdau << ((unsigned)(0xe14c23dcu || 0x80000000u) & 31u)));
            }
            if ((unsigned)e0) break;
        } while (i1++ < 6u && 3u);
    } while (i0++ < 3u && 0xbc19b845u);
    { unsigned t5; double z5; if ((((0xdb632922u % (0x80000000u | 1u)) >> ((unsigned)x0 & 31u))) & 1u) { t5 = (9u + (unsigned)d0); z5 = (double)(((unsigned)((int)(unsigned)b0 < (int)((unsigned)f0 - (unsigned)c0))) & 255u); } if ((((0xdb632922u % (0x80000000u | 1u)) >> ((unsigned)x0 & 31u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
        if ((unsigned)f0) goto L2;
        b0 = ((0x97660eeu + i0) >> ((unsigned)((int)(unsigned)w0 >= (int)0x50cd63beu) & 31u)) != 0u;
        while (i0++ < 2u && (unsigned)((int)(unsigned)w0 >= (int)a0[u1 & 3u])) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(0xe4c4d470u < r0.y) / ((unsigned)s1 | 1u)), (unsigned)(g1 < fuel), (unsigned)((short)(unsigned)c0 > (signed char)((unsigned)w0 & 6u))); }
            q0 = &garr[((3u - i1) ? 6u : m0) & 7u];
            s1 = (int)((unsigned)s1 + ((unsigned)l0 + ((unsigned)(x0 >> 70) + -(unsigned)((int)(unsigned)(w0 >> 29) >= (int)garr[i1 & 7u]))));
            while (i1++ < 4u && (p1 % (a0[u1 & 3u] | 1u))) { if (--fuel == 0u) goto done;
                if (g1) {
                    w0 = w0 * 6364136223846793005ull + *mp;
                    r0.y ^= ((p2 | g1) / (((unsigned)s1 * (unsigned)(short)(unsigned)(0x7fffffffu == (unsigned)h1)) | 1u));
                    break; (void)((unsigned)(0x65d0ff94u || 0x9377d093u));
                    if ((unsigned)(w0 >> 29)) break;
                    *q0 = (unsigned)((int)p0 >= (int)5u);
                } else {
                    m0 ^= (((unsigned)l0 ? (unsigned)(0xffffffffu && (unsigned)x0) : 0x80000000u) >> (garr[i1 & 7u] & 31u));
                }
                v0 = ((unsigned)((int)(unsigned)d0 >= (int)i2) ? 6u : (unsigned)f0);
                if ((unsigned)(signed char)(unsigned)((int)0x7258bc9au >= (int)(unsigned)(unsigned char)(0x10000u * (unsigned)d0))) {
                    if (p1) break;
                    continue; (void)((0xffffffffu / ((unsigned)(unsigned char)((unsigned)b0 << (a0[i0 & 3u] & 31u)) | 1u)));
                    g1 += (unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)(signed char)(a0[u1 & 3u] << (i1 & 31u)));
                    c0 = (unsigned char)(unsigned)((int)(unsigned)c1 >= (int)((unsigned)s0 * -(0x7fffffffu ? fuel : i2)));
                    if (*q0) continue;
                    r0.y ^= (r0.y / (u1 | 1u));
                } else {
                    u3 += *q0;
                    u2 += (unsigned)(((unsigned)s0 << (4u & 31u)) == i2);
                    w0 ^= (unsigned long long)*q0 << ((((unsigned)(short)(0x949ab44du / (u0 | 1u)) | (unsigned)((int)fuel >= (int)9u)) - (unsigned)d0) & 63u);
                    r0.y ^= u2;
                }
                goto L2;
            }
            g0 = (unsigned)((short)m0 > (signed char)(unsigned)d0);
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)c0);
                    if ((unsigned)((short)(*mp - (unsigned)d0) > (signed char)p0)) break;
                } while (i2++ < 7u && 0x6b2a8aeeu);
                if ((1u ^ (unsigned)d0)) break;
            }
        }
    }
    if ((a0[i0 & 3u] - 0x7fffffffu)) goto L0;
    h0 = (short)(unsigned)(1u < -((unsigned)x0 ? i0 : (unsigned)c1));
    if ((4u ^ 0x80000000u)) {
        if (((unsigned)h0 * (unsigned)((short)i1 > (signed char)(unsigned)c1))) {
            e0 = e0 * 0.5L + (long double)((unsigned)(u1 < (0x80000000u >> (garr[u2 & 7u] & 31u))) & 1023u);
            r0.x = (unsigned)(unsigned char)(unsigned)((unsigned)((short)(a0[u1 & 3u] ^ v0) > (signed char)(u2 | m0)) && r0.x);
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                q0 = &garr[((6u & 0x459b2937u) << (0x80000000u & 31u)) & 7u];
                r0.y ^= (unsigned)(g0 || (unsigned)e0);
                m0 ^= ((unsigned)((int)0x7fffffffu < (int)(unsigned)e0) % ((u0 >> ((unsigned)((unsigned)(x0 >> 70) && (unsigned)(w0 >> 29)) & 31u)) | 1u));
                *mp = (unsigned)((int)0xffffffffu < (int)p1);
                { unsigned t6; double z6; if ((0x80000000u) & 1u) { t6 = (unsigned)(signed char)(p0 >> (u2 & 31u)); z6 = (double)(((unsigned)((int)3u >= (int)(unsigned)(signed char)(i2 ^ 3u))) & 255u); } if ((0x80000000u) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                    if ((unsigned)e0) goto L3;
                    if ((4u ^ (unsigned)(7u < (unsigned)h1))) break;
                    if (u3 == 7u) return (unsigned)w0;
                    e0 = e0 * 0.5L + (long double)((unsigned)(*mp < r0.x) & 1023u);
                    for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (fuel < 8u) return (unsigned)(((unsigned)(u1 && 0xcc46f5cbu) / (i1 | 1u)) && a0[i0 & 3u]);
                        continue; (void)((v0 % ((unsigned)c1 | 1u)));
                        m0 ^= ((unsigned)(w0 >> 29) % ((unsigned)b0 | 1u));
                    }
                }
            }
        } else {
            if (((unsigned)((int)(unsigned)e0 < (int)u1) - u3)) goto L3;
            { unsigned t7; double z7; if (((2u ^ (u0 ^ (unsigned)e0))) & 1u) { t7 = (unsigned)((int)0x7fffffffu < (int)(v0 ^ (unsigned)l0)); z7 = (double)(((unsigned)(signed char)(u3 | i1)) & 255u); } if (((2u ^ (u0 ^ (unsigned)e0))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                u3 = (unsigned)((unsigned)h1 < (((p1 >> ((unsigned)f0 & 31u)) ^ 0x7fffffffu) & garr[i1 & 7u]));
                a0[(unsigned)c1 & 3u] = (unsigned)((unsigned)(unsigned char)((unsigned)((int)a0[u1 & 3u] >= (int)*mp) | (unsigned)d0) || (unsigned)(2u && 0x80000000u));
                w0 = w0 * 6364136223846793005ull + (p1 * (unsigned)f0);
            }
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)(0x7fffffffu == *q0) % ((unsigned)e0 | 1u))) break;
                *q0 = 1u;
            }
            if ((unsigned)((unsigned)b0 == (unsigned)((unsigned)s0 && r0.y))) goto L4;
        }
        if ((unsigned)(short)(unsigned)(garr[u2 & 7u] || v0)) {
            b0 = u1 != 0u;
            r0.x = (u0 + (unsigned)(0xf8b1d6a1u < 0x7fffffffu));
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (m0) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)7u > (signed char)(fuel << (a0[u1 & 3u] & 31u))), (r0.x % ((unsigned)e0 | 1u)), (unsigned)(unsigned char)(unsigned)(0x752a6fefu && 0xcc9406e7u)); }
                    break; (void)((unsigned)c0);
                    b0 = ((unsigned)!(((unsigned)(w0 >> 29) + 0x7fffffffu) >> (m0 & 31u)) + (unsigned)d0) != 0u;
                }
                g1 += (unsigned)(r0.y == (unsigned)(x0 >> 70));
                *q0 += (unsigned)x0;
                if ((unsigned)!(garr[u2 & 7u] * u1)) break;
                r0.x = (unsigned)((u2 / ((unsigned)!(fuel ? garr[u2 & 7u] : g1) | 1u)) || 0x8d5ee66eu);
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((8u - garr[u2 & 7u]), (g0 & *q0), ~(unsigned)((int)(unsigned)b0 >= (int)(r0.x + 0xffffffffu))); }
            if (u3 == 7u) return ((0u - i0) & (unsigned)((int)0x1b966e5du >= (int)0x6bc8e663u));
        }
        *mp = (((unsigned)(m0 == 8u) << (v0 & 31u)) * -(unsigned)((int)(unsigned)d0 >= (int)r0.y));
        if ((unsigned)!(unsigned)((int)(unsigned)(u1 == (unsigned)(x0 >> 70)) < (int)a0[u1 & 3u])) goto L0;
        { unsigned t8; double z8; if (((unsigned)((short)6u > (signed char)(unsigned)w0)) & 1u) { t8 = ~(unsigned)(fuel && (unsigned)l0); z8 = (double)(((garr[i1 & 7u] ^ (unsigned)(4u || g0))) & 255u); } if (((unsigned)((short)6u > (signed char)(unsigned)w0)) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
            goto done;
            { unsigned t9; double z9; if ((p1) & 1u) { t9 = ((unsigned)c1 * garr[i1 & 7u]); z9 = (double)((0x80000000u) & 255u); } if ((p1) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                switch ((unsigned)(unsigned char)((unsigned)(w0 >> 29) & 0xb55b20eu) & 7u) {
                    d0 = d0 * 0.5 + (double)((((unsigned)s0 ^ 0xeddbf575u) & ((unsigned)s1 << (((unsigned)x0 % (2u | 1u)) & 31u))) & 1023u);
                }
                goto L0;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)p0 < (int)(unsigned)((short)i0 > (signed char)v0)), (1u % ((unsigned)s1 | 1u)), (unsigned)b0); }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)f0, (unsigned)s0, (unsigned)(4u < (6u / (2u | 1u)))); }
        }
        c1 = (signed char)(unsigned)!(unsigned)((0x10000u - r0.y) < (0x10000u / (p1 | 1u)));
    }
    if (((unsigned)c1 - (unsigned)x0)) goto L0;
    if (budget != 0u) { budget -= 1u; u2 = fn1(u1, ((unsigned)e0 ? (unsigned)e0 : i1), (unsigned)(x0 >> 70)); }
    u2 = (unsigned)(short)(0xe418d745u * v0);
    w0 = w0 * 6364136223846793005ull + (((unsigned)s1 % ((unsigned)h1 | 1u)) % (garr[i1 & 7u] | 1u));
    switch ((unsigned)(p1 == r0.y) & 7u) {
        g1 += (a0[i0 & 3u] - (unsigned)(p1 < (*q0 & (unsigned)((int)r0.y < (int)0x779d0b7au))));
        case 5u: ;
        c0 = (unsigned char)0xffffffffu;
    }
    if ((a0[u1 & 3u] / (g0 | 1u))) goto L4;
    if (((unsigned)h0 << ((0x10000u | garr[u2 & 7u]) & 31u))) goto L0;
    if (fuel < 8u) return ((unsigned)s0 << ((u3 - ((unsigned)s1 + m0)) & 31u));
    if ((unsigned)(short)(9u / (((unsigned)s0 >> (a0[i0 & 3u] & 31u)) | 1u))) {
        g1 += (unsigned)(signed char)(unsigned)((unsigned)(r0.x == r0.x) < (unsigned)(p0 || 0x32f97a11u));
        if ((unsigned)((unsigned)c0 == a0[u1 & 3u])) goto done;
        goto L3;
        goto L3;
    } else {
        if ((unsigned)((short)0x80000000u > (signed char)(unsigned)((short)g1 > (signed char)(unsigned)s0))) goto L3;
    }
    if (p1) goto L4;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn1(((garr[u2 & 7u] | (unsigned)w0) >> ((unsigned)f0 & 31u)), 0u, ((unsigned)c1 << (6u & 31u))); }
        if ((unsigned)e0) {
            if (*q0) {
                a0[(g0 - i1) & 3u] = (unsigned)((short)(unsigned)(short)(unsigned)((unsigned)c1 < 1u) > (signed char)fuel);
                i1 = (unsigned)(0x8b31936cu < (a0[i0 & 3u] + u2)) & 15u;
                c0 = (unsigned char)(0u | ((unsigned)l0 >> (i0 & 31u)));
                *q0 = (unsigned)(unsigned char)(0xeb733u - ((unsigned)s1 & g0));
            }
            break; (void)(((m0 ^ (unsigned)e0) >> (8u & 31u)));
        } else {
            if (budget != 0u) { budget -= 1u; u2 = fn0(garr[u2 & 7u], (0x7fffffffu % ((unsigned)s0 | 1u)), (~(unsigned)(a0[u1 & 3u] == *mp) / (0x4349e317u | 1u))); }
            if ((unsigned)x0) {
                l0 = (long)((unsigned long)l0 + p1);
                { unsigned t10; double z10; if ((((unsigned)c1 ^ (unsigned)h1)) & 1u) { t10 = (unsigned)((unsigned)(w0 >> 29) || 0xb946180du); z10 = (double)((((unsigned)l0 - (unsigned)((short)*q0 > (signed char)1u))) & 255u); } if ((((unsigned)c1 ^ (unsigned)h1)) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
                    if (budget != 0u) { budget -= 1u; u2 = fn1((u1 ^ 2u), (5u * p0), (((unsigned)(w0 >> 29) / (2u | 1u)) - 4u)); }
                    continue; (void)((0x80000000u / ((unsigned)s0 | 1u)));
                    f0 = f0 * 0.5f + (float)((unsigned)((short)0x4895ab4eu > (signed char)(unsigned)((g1 / (garr[u2 & 7u] | 1u)) && (unsigned)((short)(unsigned)s0 > (signed char)0x9c1058f1u))) & 255u);
                    v0 = 0x80000000u;
                }
                goto L0;
                u3 += ((unsigned)((int)4u < (int)4u) | u0);
            } else {
                w0 ^= (unsigned long long)0x10000u << ((unsigned)(unsigned char)(unsigned)((g1 << ((0x7f25ac9bu ? (unsigned)(x0 >> 70) : u2) & 31u)) || r0.y) & 63u);
                if (budget != 0u) { budget -= 1u; u0 = fn0(u2, (unsigned)e0, (unsigned)(unsigned char)((unsigned)f0 % ((unsigned)(0x8d9667bbu || (unsigned)f0) | 1u))); }
                if (((unsigned)h1 << ((*q0 >> (p1 & 31u)) & 31u))) break;
            }
            do { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if (g0) continue;
                } while (i2++ < 5u && (unsigned)((fuel << (g1 & 31u)) && u0));
                break; (void)(u0);
                do { if (--fuel == 0u) goto done;
                    for (;;) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)e0, (unsigned)f0, (0xebd377b2u | 0x80000000u)); }
                        if (0xc4c82ac3u) {
                            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)0xffffffffu >= (int)garr[i1 & 7u]), 0x945d2244u, ((p2 >> (u0 & 31u)) ^ *mp)); }
                            if (budget != 0u) { budget -= 1u; u0 = fn0(~(unsigned)((short)0x7fffffffu > (signed char)-(0xc7929964u | u0)), r0.x, *mp); }
                            goto L0;
                            if (((unsigned)c0 + (unsigned)(garr[u2 & 7u] == m0))) break;
                        } else {
                            m0 ^= (unsigned)(unsigned char)(u1 | p2);
                            if ((unsigned)(unsigned char)((unsigned)h0 >> (p1 & 31u))) break;
                        }
                        h1 = (unsigned short)(h1 + (unsigned)l0);
                        if (fuel < 8u) return ((unsigned)s0 * (*q0 << ((i1 | m0) & 31u)));
                        w0 ^= (unsigned long long)(unsigned)(short)(fuel << ((unsigned)d0 & 31u)) << ((unsigned)(unsigned char)((unsigned)c1 & (unsigned)e0) & 63u);
                    }
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(signed char)((unsigned)h0 ? u1 : r0.y) || ((unsigned)h0 / (0x91da5f04u | 1u))));
                    b0 = (unsigned)e0 != 0u;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)c0, (unsigned)s0, (((unsigned)l0 - 8u) + 0xe161ae75u)); }
                    if (budget != 0u) { budget -= 1u; u0 = fn1((((unsigned)h0 << ((unsigned)x0 & 31u)) & u3), (~(u3 + (unsigned)w0) >> ((unsigned)f0 & 31u)), (unsigned)((short)(unsigned)x0 > (signed char)0x80000000u)); }
                    if (a0[u1 & 3u]) continue;
                } while (i2++ < 5u && ((unsigned)h1 << (0xde793b17u & 31u)));
                break; (void)(((unsigned)h0 >> (0x7fffffffu & 31u)));
                break; (void)((unsigned)((unsigned)(g1 == 0xffffffffu) < a0[i0 & 3u]));
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)h1 == (unsigned)((short)p2 > (signed char)(unsigned)(u2 < v0)));
            } while (i1++ < 3u && (unsigned)((unsigned)l0 == (unsigned)w0));
            c1 = (signed char)(0x5923f7a1u / (0x25a01e00u | 1u));
        }
        switch ((unsigned)(0x662fdeefu && (unsigned)(0x3e828cd7u || p2)) & 7u) {
            case 3u: ;
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)f0 == (unsigned)(unsigned char)(unsigned)((int)0xffffffffu < (int)fuel)), (((unsigned)c1 % (0x7fffffffu | 1u)) * i1), ((unsigned)(0xf6f5cf8du == a0[i0 & 3u]) & 0x3ac1b3e6u)); }
    if ((unsigned)((unsigned)!(unsigned)(g0 == 0xffffffffu) || i1)) goto L1;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (u3 == 7u) return 0x80000000u;
    }
    goto L2;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (8u) continue;
        switch ((unsigned)(a0[u1 & 3u] == ((unsigned)s0 + 0xffffffffu)) & 7u) {
            g0 = g1;
            a0[((unsigned)f0 >> (u1 & 31u)) & 3u] = (((unsigned)(short)((unsigned)s1 ? r0.y : r0.x) * 8u) ^ *q0);
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + 5u);
                v0 = (unsigned)((int)0x80000000u < (int)0x80000000u);
            }
        }
        if (((unsigned)f0 % ((unsigned)(u0 && (unsigned)s0) | 1u))) goto L0;
    }
    h1 = (unsigned short)(h1 + -(((4u >> (7u & 31u)) & (i1 - a0[u1 & 3u])) << (*q0 & 31u)));
    if ((unsigned)(short)((u0 / (g1 | 1u)) - 0xffffffffu)) {
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)c1 ^ (unsigned)x0), ((unsigned)(*q0 < (unsigned)d0) % ((unsigned)(x0 >> 70) | 1u)), 0x7fffffffu); }
        r0.y ^= (unsigned)(signed char)((unsigned)((short)(unsigned)h0 > (signed char)0x80000000u) & (unsigned)(short)((unsigned)b0 * r0.x));
        do { if (--fuel == 0u) goto done;
            goto L3;
            if ((unsigned)(signed char)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)i0)) continue;
            if (((0xff4efd3au * garr[u2 & 7u]) / (0x7fffffffu | 1u))) {
                while (i1++ < 3u && a0[i0 & 3u]) { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + 0x913775edu);
                    if ((v0 % (r0.y | 1u))) break;
                    if (i2) break;
                    u0 += p2;
                    switch ((unsigned)((int)0x10000u < (int)0x80000000u) & 7u) {
                        u0 += (unsigned)l0;
                        s0 = (int)(unsigned)(g0 == ((unsigned)!((unsigned)w0 + garr[i1 & 7u]) << (p0 & 31u)));
                        case 3u: ;
                    }
                    goto L4;
                }
                if ((p0 ? i1 : (unsigned)(x0 >> 70))) break;
            } else {
                x0 = x0 * 0x100000001b3ull + (3u % ((unsigned)((short)((unsigned)b0 ^ (unsigned)c0) > (signed char)0x7fffffffu) | 1u));
                c0 = (unsigned char)(i0 & (r0.y << (garr[i1 & 7u] & 31u)));
            }
            e0 = e0 * 0.5L + (long double)(((p2 << ((a0[u1 & 3u] >> (a0[u1 & 3u] & 31u)) & 31u)) << ((unsigned)(g1 == garr[u2 & 7u]) & 31u)) & 1023u);
        } while (i0++ < 5u && ((unsigned)((int)(unsigned)f0 < (int)(unsigned)h1) & 0xffffffffu));
        a0[a0[u1 & 3u] & 3u] = (((unsigned)w0 * 0u) ^ (unsigned)((short)(3u << (r0.y & 31u)) > (signed char)0x3a39e43du));
        if ((p2 >> ((unsigned)s0 & 31u))) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((a0[u1 & 3u] ^ ((unsigned)e0 % ((unsigned)w0 | 1u))), (unsigned)((i2 >> (7u & 31u)) && 6u), (unsigned)(signed char)((unsigned)e0 >> (~(u2 * r0.x) & 31u))); }
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (0x1e7af70bu & -((unsigned)s0 & garr[i1 & 7u])));
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (p2 % (0x10000u | 1u)));
                    if ((unsigned)b0) break;
                }
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)(unsigned char)((u2 | 6u) << (p0 & 31u))) goto L0;
                    break; (void)((unsigned)((unsigned)(*mp == (unsigned)(w0 >> 29)) < (unsigned)(x0 >> 70)));
                }
                do { if (--fuel == 0u) goto done;
                    if ((0xa186bc92u - (unsigned)d0)) goto L3;
                } while (i1++ < 4u && (unsigned)((int)(unsigned)f0 < (int)p2));
                c0 = (unsigned char)-((unsigned)f0 % ((unsigned)(i1 || 8u) | 1u));
                garr[(p2 & (unsigned)l0) & 7u] = (unsigned)((short)(unsigned)(1u || 8u) > (signed char)(m0 << (a0[u1 & 3u] & 31u)));
            }
        }
        q0 = &garr[((unsigned)((unsigned)b0 || (unsigned)e0) * i2) & 7u];
    }
    *q0 += -((unsigned)h0 % ((0xffffffffu + garr[i1 & 7u]) | 1u));
    if (*mp) {
        goto done;
        g0 = ((unsigned)(short)((0xfeec3ac0u | r0.y) << (garr[u2 & 7u] & 31u)) * (2u & v0));
        { unsigned t11; double z11; if (((5u % ((unsigned)h0 | 1u))) & 1u) { t11 = (unsigned)(unsigned char)((unsigned)(i1 && m0) + (unsigned)(x0 >> 70)); z11 = (double)(((unsigned)(unsigned char)(unsigned)(0x7fffffffu && 0x80000000u)) & 255u); } if (((5u % ((unsigned)h0 | 1u))) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
            goto L2;
            goto done;
            while (i0++ < 5u && (unsigned)((int)(unsigned)l0 < (int)0xc784ed30u)) { if (--fuel == 0u) goto done;
                if ((garr[u2 & 7u] >> (0x7fffffffu & 31u))) break;
                s1 = (int)((unsigned)s1 + (0xffffffffu + ((unsigned)((int)p2 < (int)(unsigned)c0) >> (a0[u1 & 3u] & 31u))));
                u0 = r0.x;
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    h0 = (short)(unsigned)((int)u0 < (int)(unsigned)!(unsigned)((unsigned)(signed char)(unsigned)(fuel < (unsigned)((unsigned)h1 == 0x10000u)) && 0xc6ec54aeu));
                    r0.x = ((unsigned)((unsigned)f0 || (unsigned)h0) / (*mp | 1u));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0xffb9945u | i0), (unsigned)!(u1 << ((unsigned)b0 & 31u)), (unsigned)l0); }
                    if ((unsigned)(x0 >> 70)) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)garr[i1 & 7u] < (int)u2), (unsigned)(0xa13b5427u && (unsigned)x0), (0xb08b8c48u / (m0 | 1u))); }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(p0, ((unsigned)s1 >> ((unsigned)w0 & 31u)), (unsigned)(0x80000000u && 0x519a2765u)); }
                }
                if (((unsigned)w0 - (0x10000u % ((unsigned)(w0 >> 29) | 1u)))) {
                    c0 = (unsigned char)(-((*mp ^ 0x64e233b5u) & i0) << (i2 & 31u));
                    u0 ^= i0;
                    g1 += (r0.x * ((unsigned)((int)(unsigned)b0 < (int)*q0) / ((unsigned)h0 | 1u)));
                }
                h1 = (unsigned short)(h1 + u1);
            }
        }
        u1 ^= ~(unsigned)((unsigned)((int)0x35f389c5u >= (int)0xb9b7d05bu) == g0);
        *q0 = ((unsigned)c1 >> ((unsigned)x0 & 31u));
    } else {
        b0 = (unsigned)(u1 && (6u % ((0x9f33f78u | -(0x7fffffffu % (garr[i1 & 7u] | 1u))) | 1u))) != 0u;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(i1 < (unsigned)(u0 == g1)), (unsigned)((short)0xffffffffu > (signed char)6u), (((unsigned)(w0 >> 29) | p1) * 0xa767b244u)); }
    }
    if ((unsigned)(0x23d09970u == (unsigned)((unsigned)(w0 >> 29) == 0xfacc2126u))) goto L3;
    u2 ^= (unsigned)(i2 < (unsigned)(signed char)(9u >> (0x10000u & 31u)));
    if (~(i0 >> ((unsigned)c1 & 31u))) {
        if (budget != 0u) { budget -= 1u; u0 = fn1((garr[i1 & 7u] - (unsigned)((unsigned)s1 == (unsigned)h0)), (g0 ^ (unsigned)(x0 >> 70)), (((unsigned)s1 - (unsigned)l0) | 0x80000000u)); }
        do { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)(*mp || r0.y);
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + ((((unsigned)s1 / (a0[i0 & 3u] | 1u)) ^ garr[i1 & 7u]) * u3);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(u2, 4u, (a0[u1 & 3u] + (unsigned)(3u || (unsigned)b0))); }
                }
                q0 = &garr[(unsigned)(unsigned char)(~((1u & 0x3436fb9u) + (unsigned)((short)0x7fffffffu > (signed char)u1)) | u3) & 7u];
                c0 = (unsigned char)(unsigned)((short)(unsigned)(0xcc5e8416u && (unsigned)x0) > (signed char)(g1 | 0x10000u));
            }
            u2 ^= (0x561945b9u ? m0 : (*q0 * 0x45e46f4au));
        } while (i0++ < 6u && ((unsigned)x0 | (unsigned)b0));
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(signed char)(unsigned)(p2 || g0), ~(~(u2 % (g1 | 1u)) ^ (unsigned)x0), (unsigned)(signed char)(0x7fffffffu / ((unsigned)f0 | 1u))); }
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)(x0 >> 70) || 0x10000u), ((unsigned)l0 << (0x42d12d99u & 31u)), (unsigned)!((unsigned)(x0 >> 70) / ((unsigned)(g1 && 4u) | 1u))); }
        *q0 += (unsigned)(unsigned char)(i0 | (unsigned)(m0 && (unsigned)h1));
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            g0 = (unsigned)!(unsigned)((unsigned)((unsigned)(x0 >> 70) < r0.x) < (unsigned)d0);
            if (((unsigned)f0 ^ (unsigned)((short)garr[i1 & 7u] > (signed char)0xffffffffu))) goto L4;
            if ((unsigned)h0) {
                if ((r0.x * r0.x)) {
                    if (0x2995ca6cu) break;
                    x0 = x0 * 0x100000001b3ull + (unsigned)!((unsigned)((int)(unsigned)c0 >= (int)0xc0e76ecbu) - 0x4d396df2u);
                    if (u3 == 7u) return (unsigned)(~(unsigned)(a0[u1 & 3u] == (3u & 0x80000000u)) < (unsigned)b0);
                    x0 = x0 * 0x100000001b3ull + (unsigned)h0;
                }
                goto L3;
                q0 = &garr[~((unsigned)((unsigned)((int)u1 < (int)g1) || g1) - (0x80000000u | g1)) & 7u];
                if ((unsigned)(short)(0x80000000u - *q0)) continue;
                s0 = (int)(unsigned)(unsigned char)(((unsigned)w0 + 0xffffffffu) / (0x3a057e08u | 1u));
                if (fuel) goto L0;
            } else {
                break; (void)((g1 << (0u & 31u)));
                if (i0) break;
            }
        }
    }
    if (fuel < 8u) return ((unsigned)(w0 >> 29) | a0[i0 & 3u]);
    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)d0 >> ((unsigned)(x0 >> 70) & 31u)), (((unsigned)s1 % ((unsigned)f0 | 1u)) ^ 0x7fffffffu), ((unsigned)h1 >> ((unsigned)(unsigned char)(2u ^ a0[u1 & 3u]) & 31u))); }
    b0 = ~(unsigned)((unsigned)((int)fuel < (int)(unsigned)h1) == *mp) != 0u;
    r0.x = (unsigned)(signed char)(u0 << ((unsigned)(unsigned char)(unsigned)((int)(unsigned)(short)(unsigned)(1u && (unsigned)c1) >= (int)(unsigned)((int)(unsigned)l0 < (int)v0)) & 31u));
    u2 = (~(i0 % ((unsigned)!(1u % ((unsigned)x0 | 1u)) | 1u)) + (unsigned)s0);
    goto L2;
    a0[(unsigned)s0 & 3u] = garr[u2 & 7u];
    if ((((unsigned)e0 ^ a0[u1 & 3u]) << ((unsigned)f0 & 31u))) {
        g0 = (unsigned)((short)(unsigned)s1 > (signed char)8u);
        if ((((unsigned)s1 * (unsigned)b0) ^ a0[i0 & 3u])) goto L0;
        if ((unsigned)(v0 < (fuel ^ (unsigned)c0))) goto L2;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)0x3732627cu >= (int)7u), (unsigned)!(unsigned)((unsigned)(unsigned char)(a0[i0 & 3u] + p0) && a0[i0 & 3u]), (5u - (unsigned)s1)); }
            goto L4;
            { unsigned t12; double z12; if (((unsigned)e0) & 1u) { t12 = (unsigned)((unsigned)(x0 >> 70) || (unsigned)l0); z12 = (double)(((unsigned)((int)(unsigned)(0x10000u || 5u) < (int)6u)) & 255u); } if (((unsigned)e0) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
                g1 += (unsigned)w0;
                g1 += (0x80000000u & ((unsigned)f0 << ((unsigned)s0 & 31u)));
            }
            break; (void)((3u ^ 6u));
            l0 = (long)((unsigned long)l0 + ((unsigned)s1 - v0));
            if ((0xffffffffu - (unsigned)h1)) break;
        } while (i0++ < 7u && (9u + p0));
        u1 ^= (((unsigned)b0 ? (unsigned)(0xffffffffu == i2) : 0x5dde3354u) / ((unsigned)w0 | 1u));
        m0 ^= (unsigned)(((v0 % (u2 | 1u)) + 0x7fffffffu) && (unsigned)((unsigned)e0 || (unsigned)x0));
    } else {
        if (budget != 0u) { budget -= 1u; u2 = fn0((((unsigned)s1 & g0) & v0), garr[u2 & 7u], (unsigned)((int)(unsigned)f0 < (int)a0[u1 & 3u])); }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1(fuel, 0x7080385fu, ~(unsigned)((int)(unsigned)d0 < (int)a0[i0 & 3u])); }
    switch ((unsigned)(0x2f051fb4u < v0) & 7u) {
        case 7u: ;
    }
    if ((unsigned)f0) {
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)s0, (unsigned)((int)p1 >= (int)a0[i0 & 3u]), (unsigned)((0xffffffffu - fuel) < (unsigned)h0)); }
        w0 ^= (unsigned long long)m0 << (((unsigned)((int)p2 >= (int)2u) << (0u & 31u)) & 63u);
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1(i2, (unsigned)w0, (v0 / (i2 | 1u))); }
            continue; (void)(r0.y);
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)r0.y > (signed char)(unsigned)d0), (unsigned)s1, ((unsigned)f0 ^ (unsigned)(2u < (unsigned)d0))); }
            while ((unsigned)l0) { if (--fuel == 0u) goto done;
                *q0 += (unsigned)((unsigned)s0 == ((unsigned)(m0 && 0x7fffffffu) | a0[u1 & 3u]));
            }
            switch (0x10000u & 7u) {
                switch ((m0 | (unsigned)w0) & 7u) {
                    if ((unsigned)((*mp & *mp) && (unsigned)c1)) goto L0;
                    r0.y ^= 1u;
                    g1 += (garr[u2 & 7u] / ((((unsigned)(w0 >> 29) / ((unsigned)h1 | 1u)) ^ ((unsigned)e0 - 0xffffffffu)) | 1u));
                    continue; (void)((unsigned)d0);
                    case 7u: ;
                    g0 = (unsigned)((int)p1 < (int)(unsigned)(a0[u1 & 3u] == (unsigned)h0));
                }
                x0 = x0 * 0x100000001b3ull + (8u ^ ((unsigned)(0xb7bc2df2u < 0u) << ((unsigned)w0 & 31u)));
                c0 = (unsigned char)(unsigned)((unsigned)((short)(0xffffffffu - p1) > (signed char)i1) < 0xffffffffu);
            }
        }
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)((int)6u < (int)(unsigned)(unsigned char)(9u - v0)) & 7u) {
                h0 = (short)(unsigned)((int)-(u2 & (unsigned)(unsigned char)((unsigned)((short)3u > (signed char)0x7fffffffu) ^ p1)) >= (int)0xe76040f8u);
                if (u3) {
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(fuel && (u2 | *q0)), (unsigned)(2u < 6u), (p0 << ((unsigned)h0 & 31u))); }
                    a0[u1 & 3u] = (1u + u1);
                    if (budget != 0u) { budget -= 1u; u1 = fn1(((u2 << (r0.y & 31u)) + (unsigned)s1), (unsigned)((unsigned)!((unsigned)(x0 >> 70) & a0[i0 & 3u]) < 3u), (unsigned)((int)0xcf7d5b45u >= (int)9u)); }
                }
                switch (p0 & 7u) {
                    m0 ^= ((unsigned)(x0 >> 70) - (unsigned)(x0 >> 70));
                }
                goto L3;
                case 4u: ;
            }
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)(w0 >> 29) >> ((unsigned)b0 & 31u)), ((unsigned)(signed char)(unsigned)((unsigned)s0 || r0.x) >> ((unsigned)h0 & 31u)), (0xbcb57956u - 0x7fffffffu)); }
    if (u2) {
        if ((unsigned)c0) {
            u1 ^= (unsigned)((int)(unsigned)((*mp / (p0 | 1u)) && (u0 / (i0 | 1u))) < (int)*q0);
            garr[u2 & 7u] = (garr[u2 & 7u] | ((unsigned)s0 ^ ((unsigned)h1 + r0.x)));
            if ((unsigned)((short)7u > (signed char)(unsigned)l0)) goto done;
        } else {
            while (i1) { if (--fuel == 0u) goto done;
                switch ((unsigned)(unsigned char)(0x92c87139u * (unsigned)l0) & 7u) {
                    L0: if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)u3 >= (int)(unsigned)(fuel < (unsigned)e0)), (unsigned)((short)(unsigned)w0 > (signed char)i2), (unsigned)f0); }
                }
                u0 = u0 * 0x9e3779b1u + ((unsigned)!(unsigned)(0x10000u < 9u) - ((u0 >> ((unsigned)s0 & 31u)) & 0x10000u));
                b0 = (*mp + 0x60d19955u) != 0u;
                if ((unsigned)(garr[u2 & 7u] || (7u >> (u0 & 31u)))) break;
                r0.y ^= (unsigned)((short)(unsigned)h0 > (signed char)(unsigned)((int)8u < (int)(g0 + 6u)));
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(5u == (unsigned)(7u < (unsigned)w0)), u1, (unsigned)(unsigned char)(unsigned)((int)(unsigned)e0 >= (int)(unsigned)((int)r0.x < (int)i2))); }
            }
            goto L1;
            g1 += ((unsigned)(u3 && 0xd9694117u) << (p1 & 31u));
        }
        if ((unsigned)((int)0x7fffffffu >= (int)u3)) {
            do { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + ((unsigned)((short)0xd9f2ff80u > (signed char)(unsigned)h1) / ((unsigned)h1 | 1u));
            } while (i0++ < 5u && (unsigned)d0);
        } else {
            if ((unsigned)((int)a0[i0 & 3u] < (int)0x80000000u)) {
                x0 = x0 * 0x100000001b3ull + (unsigned)(0xa52673f1u && (unsigned)(v0 == (g0 + p0)));
                u0 = u0 * 0x9e3779b1u + ((unsigned)(garr[u2 & 7u] == (unsigned)d0) ? ((unsigned)w0 * 0xffffffffu) : 0xc0e9e671u);
                w0 ^= (unsigned long long)0x2020d397u << ((unsigned)(unsigned char)((unsigned)d0 << ((unsigned)((int)r0.x < (int)p2) & 31u)) & 63u);
                x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((unsigned)((short)p0 > (signed char)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)u0)) | (*mp - (unsigned)e0));
                b0 = (unsigned)w0 != 0u;
                w0 = w0 * 6364136223846793005ull + ((unsigned)s0 >> ((unsigned)(signed char)(0u % ((unsigned)(w0 >> 29) | 1u)) & 31u));
            } else {
                do { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)((short)*q0 > (signed char)(unsigned)b0);
                    if (budget != 0u) { budget -= 1u; u2 = fn2(0x9c1c3619u, i0, (unsigned)c1); }
                    if ((unsigned)h0) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)w0, *mp, (g0 * (p0 & a0[i0 & 3u]))); }
                } while (i0++ < 6u && ((unsigned)((unsigned)s0 && (unsigned)d0) >> (i1 & 31u)));
                for (;;) { if (--fuel == 0u) goto done;
                    if (0x10000u) break;
                    if (m0) break;
                    if (0x10000u) goto L3;
                }
                if ((unsigned)(v0 == (unsigned)w0)) {
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((4u - 0x10000u) - 1u), (unsigned)e0, (0x80000000u << (0x44bed032u & 31u))); }
                    while (i0++ < 2u && (unsigned)(r0.x == p2)) { if (--fuel == 0u) goto done;
                        if ((unsigned)!((unsigned)(g0 < a0[u1 & 3u]) | u0)) break;
                    }
                    if ((m0 | 0x10000u)) goto L1;
                }
                e0 = e0 * 0.5L + (long double)(p1 & 1023u);
            }
            if (fuel < 8u) return ((unsigned)((unsigned)(0x7fffffffu && u3) < (unsigned)h1) >> ((a0[u1 & 3u] >> ((unsigned)e0 & 31u)) & 31u));
            { unsigned t0; double z0; if (((0x9f4c4c23u % (a0[i0 & 3u] | 1u))) & 1u) { t0 = g1; z0 = (double)((r0.y) & 255u); } if (((0x9f4c4c23u % (a0[i0 & 3u] | 1u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                if ((unsigned)(g0 < 0xffffffffu)) {
                    if ((unsigned)h0) goto L0;
                    L2: if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)f0, (unsigned)((int)-((unsigned)(w0 >> 29) ^ a0[i0 & 3u]) >= (int)garr[u2 & 7u]), (0x10000u % ((unsigned)((unsigned)c1 == *q0) | 1u))); }
                    goto L2;
                    L3: if (--fuel == 0u) goto done;
                    goto done;
                } else {
                    { unsigned t1; double z1; if (((unsigned)((int)p2 >= (int)(unsigned)s0)) & 1u) { t1 = p2; z1 = (double)(((unsigned)(unsigned char)(3u ^ 0x80000000u)) & 255u); } if (((unsigned)((int)p2 >= (int)(unsigned)s0)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                        goto done;
                        if ((unsigned)(short)(unsigned)((unsigned)(short)(unsigned)((int)a0[u1 & 3u] < (int)(unsigned)e0) == (unsigned)(x0 >> 70))) goto L0;
                    }
                    if (*mp) goto L4;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((unsigned)(w0 >> 29) < m0) >> (a0[i0 & 3u] & 31u)), ((unsigned)s1 & (unsigned)x0), (unsigned)!(unsigned)((7u >> (1u & 31u)) && a0[i0 & 3u])); }
                }
                if (~((u0 | 0x7fffffffu) - i0)) {
                    if ((unsigned)((unsigned)b0 || 0x80000000u)) goto L2;
                    f0 = f0 * 0.5f + (float)((unsigned)c0 & 255u);
                }
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)((m0 / (0x99c948b4u | 1u)) * (unsigned)h1);
                    L4: if (--fuel == 0u) goto done;
                    switch (((unsigned)!(3u & (unsigned)d0) / (m0 | 1u)) & 7u) {
                        case 0u: ;
                        case 3u: ;
                        case 2u: ;
                        { unsigned t2; double z2; if (((unsigned)(g0 && (unsigned)h1)) & 1u) { t2 = 0x80000000u; z2 = (double)((((*q0 * garr[u2 & 7u]) ^ 0x10000u)) & 255u); } if (((unsigned)(g0 && (unsigned)h1)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                            s0 = (int)(unsigned)(0x10000u || (unsigned)d0);
                            a0[a0[u1 & 3u] & 3u] = (unsigned)((int)(unsigned)d0 < (int)(unsigned)(0xffffffffu || ((unsigned)s1 ? 0xffffffffu : (unsigned)e0)));
                            s0 = (int)(unsigned)!(*mp >> ((0x7fffffffu & a0[i0 & 3u]) & 31u));
                            case 4u: ;
                            *q0 = u1;
                            *q0 = (unsigned)((int)u1 >= (int)(((0x969194aeu & a0[u1 & 3u]) - g0) | 0x7fffffffu));
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn0(u2, (((unsigned)(w0 >> 29) & v0) | v0), u2); }
                    }
                    w0 = w0 * 6364136223846793005ull + garr[i1 & 7u];
                }
                *mp = (unsigned)(unsigned char)(unsigned)(u0 == 0x225a3b64u);
            }
            goto L0;
        }
        goto L2;
    }
    h1 = (unsigned short)(h1 + (unsigned)((unsigned)w0 < 8u));
    if (r0.x) {
        r0.x = i1;
        u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)c0 && (unsigned)((int)p2 >= (int)0x80000000u));
        if (budget != 0u) { budget -= 1u; u0 = fn2(p0, m0, (unsigned)(garr[i1 & 7u] < v0)); }
        { unsigned t3; double z3; if ((((unsigned)f0 * 0x78676288u)) & 1u) { t3 = (unsigned)((int)u0 < (int)(unsigned)h0); z3 = (double)(((garr[i1 & 7u] & u2)) & 255u); } if ((((unsigned)f0 * 0x78676288u)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            if ((unsigned)((short)p0 > (signed char)0x85bc87f4u)) goto L3;
            u0 += -(((unsigned)(w0 >> 29) / ((unsigned)s1 | 1u)) ^ (u0 | (unsigned)((unsigned)s0 == 0x3d92b345u)));
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                u0 = u0 * 0x9e3779b1u + (unsigned)((int)(unsigned)(unsigned char)((unsigned)(m0 == 0x1683cf5eu) ? (unsigned)x0 : g1) >= (int)(unsigned)c0);
                if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)(v0 == (unsigned)s1) * (unsigned)x0), (unsigned)((int)(unsigned)c0 >= (int)(unsigned)s1), (0x7fffffffu / (fuel | 1u))); }
                v0 = ((0x7fffffffu << ((unsigned)h0 & 31u)) * (a0[u1 & 3u] ? fuel : (unsigned)h1));
                goto L1;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)!(unsigned)((unsigned)c1 && p0), (unsigned)(0x84944bc7u == (unsigned)b0), m0); }
                { unsigned t4; double z4; if (((unsigned)((unsigned)d0 || i2)) & 1u) { t4 = (0x80000000u % (0u | 1u)); z4 = (double)((((unsigned)h1 / ((unsigned)w0 | 1u))) & 255u); } if (((unsigned)((unsigned)d0 || i2)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    if ((*q0 | (6u - (unsigned)(x0 >> 70)))) break;
                }
            }
            if (0xe6a7741du) goto L4;
            q0 = &garr[(unsigned)((short)0x625601abu > (signed char)(unsigned)(short)(u0 * (unsigned)x0)) & 7u];
            garr[(unsigned)(short)(unsigned)(0x89cf9ea6u && 0xc335cfdu) & 7u] = (unsigned)((int)(garr[i1 & 7u] + ((unsigned)l0 >> ((unsigned)((unsigned)b0 && 2u) & 31u))) >= (int)(unsigned)(x0 >> 70));
        }
        if (((*mp % (m0 | 1u)) * (unsigned)c0)) goto L1;
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (-((unsigned)(unsigned char)(unsigned)(i0 || (unsigned)h0) | u2)) goto L4;
    }
    i1 = ((0xeb018a11u + (unsigned)(unsigned char)(0x880a497au & 0x655ae5d1u)) ^ i0) & 15u;
    u2 = (0xffffffffu | ~(unsigned)(r0.y || 0xe2247db7u));
    goto L0;
    c1 = (signed char)(unsigned)b0;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0x80000000u) goto L3;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)(9u & 255u);
            { unsigned t5; double z5; if ((-(unsigned)((short)8u > (signed char)(unsigned)(i2 || 0xe90c19a1u))) & 1u) { t5 = r0.x; z5 = (double)((((unsigned)((unsigned)h1 && p0) | (unsigned)c0)) & 255u); } if ((-(unsigned)((short)8u > (signed char)(unsigned)(i2 || 0xe90c19a1u))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                if ((0x8a9371efu >> (r0.x & 31u))) break;
                u2 = u2 * 0x9e3779b1u + (unsigned)(0xc71fd9a9u && (unsigned)h0);
            }
            if ((unsigned)(x0 >> 70)) break;
            if ((unsigned)e0) break;
            c1 = (signed char)((unsigned)l0 + (unsigned)h1);
        }
        if ((unsigned)x0) continue;
        { unsigned t6; double z6; if (((unsigned)(0xf58ce439u || (p2 - 0xcf05f6ffu))) & 1u) { t6 = (unsigned)((short)p0 > (signed char)g0); z6 = (double)(((unsigned)((int)(0x80000000u | (unsigned)b0) >= (int)(unsigned)l0)) & 255u); } if (((unsigned)(0xf58ce439u || (p2 - 0xcf05f6ffu))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
            c0 = (unsigned char)m0;
        }
        w0 ^= (unsigned long long)1u << ((unsigned)c0 & 63u);
    }
    if ((unsigned)((int)(*mp & i2) >= (int)v0)) {
        u2 ^= (unsigned)((unsigned)x0 || (-(*mp / (m0 | 1u)) - i2));
        do { if (--fuel == 0u) goto done;
            c1 = (signed char)-((unsigned)((unsigned)h1 && (i2 * u2)) + v0);
        } while (i0++ < 7u && garr[u2 & 7u]);
        m0 ^= (unsigned)((int)(unsigned)h0 >= (int)(unsigned)((int)((unsigned)((unsigned)d0 < (unsigned)h1) & p2) >= (int)u0));
        *q0 += 0xffffffffu;
    } else {
        r0.x = a0[i0 & 3u];
        s1 = (int)((unsigned)s1 + -(p0 % (((unsigned)c0 / (p0 | 1u)) | 1u)));
        switch (((unsigned)b0 * p2) & 7u) {
            w0 = w0 * 6364136223846793005ull + fuel;
            case 4u: ;
            case 5u: ;
            a0[(0x7fffffffu | 0xbf25a747u) & 3u] = u1;
            case 6u: ;
        }
    }
    g1 += (unsigned)(p2 && (unsigned)((int)*mp >= (int)(unsigned)(i1 && (unsigned)w0)));
    if ((unsigned)(unsigned char)(0x10000u - (i2 - a0[u1 & 3u]))) {
        if ((unsigned)b0) goto L4;
        w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(a0[u1 & 3u] ^ 3u);
        if (((p1 & u0) << (0x876fca4bu & 31u))) {
            if (budget != 0u) { budget -= 1u; u0 = fn1(p0, (unsigned)((unsigned)s1 || (unsigned)f0), ((unsigned)h0 - (unsigned)(a0[u1 & 3u] || r0.y))); }
            m0 ^= ((unsigned)w0 * u1);
        }
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(unsigned char)(0xc3e1cd6du + g1), ((unsigned)(x0 >> 70) - (unsigned)h0), (unsigned)(signed char)(unsigned)(0x80000000u < (unsigned)h0)); }
        *q0 += ((0x10000u ^ (unsigned)((int)(unsigned)h0 >= (int)6u)) | (unsigned)!(unsigned)(0x7fffffffu || a0[u1 & 3u]));
        g0 = (0x69921c3fu + (0x83aebec0u % (((unsigned)((short)r0.y > (signed char)1u) & fuel) | 1u)));
    } else {
        s1 = (int)((unsigned)s1 + i2);
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1((0xa39e279bu / ((unsigned)((int)*q0 < (int)(unsigned)(w0 >> 29)) | 1u)), (g0 | (unsigned)e0), a0[u1 & 3u]); }
    switch ((unsigned)((int)(2u / (0x1d40dc2bu | 1u)) >= (int)i2) & 7u) {
        b0 = (unsigned)(unsigned char)(unsigned)(7u && ((p0 & r0.x) << ((0x79a6ce9bu << (r0.y & 31u)) & 31u))) != 0u;
        w0 ^= (unsigned long long)(0xca0d5342u ^ u2) << ((unsigned)!(0x10000u ^ (unsigned)!(unsigned)((int)(unsigned)((garr[u2 & 7u] - (unsigned)d0) || 0xab598b80u) >= (int)u1)) & 63u);
    }
    if (((i0 * r0.y) / ((unsigned)d0 | 1u))) {
        do { if (--fuel == 0u) goto done;
            if ((u3 + (unsigned)s0)) break;
            if (~(unsigned)((int)1u < (int)(unsigned)(short)(a0[u1 & 3u] | v0))) {
                s0 = (int)8u;
                r0.x = (a0[i0 & 3u] ^ v0);
                x0 = x0 * 0x100000001b3ull + (0x6bbdf138u - ~((unsigned)w0 + (unsigned)(2u && (unsigned)s1)));
                do { if (--fuel == 0u) goto done;
                    *mp = (unsigned)((unsigned)h0 < 0x10000u);
                } while (i1++ < 5u && (unsigned)h1);
                if (r0.x) break;
                do { if (--fuel == 0u) goto done;
                    *mp = ((unsigned)d0 * (unsigned)((int)p2 >= (int)(unsigned)(w0 >> 29)));
                    if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)(w0 >> 29) % ((garr[i1 & 7u] & 0x7ebab3b6u) | 1u)), ((unsigned)h0 ^ (0u >> ((unsigned)x0 & 31u))), (unsigned)(short)(unsigned)((int)r0.y < (int)p1)); }
                    if (budget != 0u) { budget -= 1u; u0 = fn1(v0, (unsigned)((int)(unsigned)e0 < (int)*mp), (p0 ? v0 : (unsigned)f0)); }
                    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(i1 && i2) | 9u), ((unsigned)c0 >> ((unsigned)((short)(unsigned)x0 > (signed char)garr[u2 & 7u]) & 31u)), 0xd3d80fdbu); }
                    h1 = (unsigned short)(h1 + ((unsigned)((short)*mp > (signed char)(unsigned)x0) - 1u));
                    break; (void)(g1);
                } while (i1++ < 7u && ((unsigned)l0 & 0x80000000u));
            }
            a0[(unsigned)e0 & 3u] = ((unsigned)((int)v0 < (int)r0.y) + (unsigned)f0);
        } while (i0++ < 7u && -((unsigned)c1 - (unsigned)((unsigned)c1 || i0)));
        if (budget != 0u) { budget -= 1u; u1 = fn2((u3 >> (g1 & 31u)), (6u * (unsigned)s1), 0x45b8c446u); }
        if ((a0[i0 & 3u] | (unsigned)l0)) goto L0;
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(unsigned char)(unsigned)(0x1c3cbcfbu || r0.y), (unsigned)d0, (0x49ba786cu ? p2 : 0x7fffffffu)); }
    } else {
        c0 = (unsigned char)((unsigned)c0 % (r0.x | 1u));
        if ((*mp << (r0.x & 31u))) {
            goto L4;
            if (0x9495c3f3u) goto L2;
            a0[*mp & 3u] = (unsigned)(garr[i1 & 7u] == g0);
            goto done;
            goto L1;
            while (i0++ < 6u && (unsigned)((int)garr[i1 & 7u] >= (int)p1)) { if (--fuel == 0u) goto done;
                if ((unsigned)((m0 - 3u) < i1)) break;
            }
        } else {
            if ((unsigned)h1) goto L1;
            r0.y ^= ((unsigned)((int)(unsigned)((short)4u > (signed char)0xcc7a5a5au) < (int)(unsigned)!(unsigned)((unsigned)h0 == 4u)) + (unsigned)c1);
        }
        while (i0++ < 7u && (unsigned)(a0[i0 & 3u] || 0x7348eeeau)) { if (--fuel == 0u) goto done;
            if (((unsigned)e0 ? (unsigned)d0 : (unsigned)f0)) break;
            break; (void)(9u);
            if ((unsigned)((int)0x20bac85u < (int)(unsigned)!((unsigned)c1 >> (1u & 31u)))) goto L3;
            switch ((((unsigned)h1 % (1u | 1u)) ^ (unsigned)e0) & 7u) {
                r0.y ^= (unsigned)(7u == (0xcccf90ddu % ((unsigned)(0xf971066fu || garr[u2 & 7u]) | 1u)));
                if ((unsigned)(short)(garr[i1 & 7u] + (m0 * 0x10000u))) goto L3;
                do { if (--fuel == 0u) goto done;
                    if ((v0 | g1)) continue;
                    if ((unsigned)h0) continue;
                    garr[0x7fffffffu & 7u] = ((unsigned)(u0 == (unsigned)h0) & (unsigned)(w0 >> 29));
                    case 3u: ;
                    *q0 += (unsigned)((unsigned)s1 && i1);
                } while (i1++ < 7u && (unsigned)l0);
                garr[0x9b38d51bu & 7u] = (unsigned)((int)p0 < (int)0x80000000u);
                if (i2) break;
                s1 = (int)((unsigned)s1 + ((unsigned)((short)0x7fffffffu > (signed char)0u) >> ((0x10000u - 0xbd144a85u) & 31u)));
            }
            if (0xffffffffu) break;
        }
        b0 = ((unsigned)(signed char)(unsigned)((unsigned)((int)((unsigned)d0 / (0x80000000u | 1u)) < (int)(unsigned)s1) == g0) << (a0[u1 & 3u] & 31u)) != 0u;
    }
    while ((unsigned)h0) { if (--fuel == 0u) goto done;
        if ((0xce773e62u | i1)) {
            *q0 += g0;
            switch ((*mp >> (-(0xffffffffu | (unsigned)e0) & 31u)) & 7u) {
                switch (((unsigned)(w0 >> 29) | 0xffffffffu) & 7u) {
                    s0 = (int)garr[u2 & 7u];
                    if (((unsigned)h0 + fuel)) goto L3;
                }
            }
        } else {
            l0 = (long)((unsigned long)l0 + (unsigned)(0xffffffffu < (p0 - garr[u2 & 7u])));
        }
        if ((unsigned)x0) break;
        a0[(unsigned)(0x10000u < v0) & 3u] = (unsigned)((int)(0x6e68498u << (0x10000u & 31u)) >= (int)(1u & (6u % ((unsigned)l0 | 1u))));
    }
    g1 += (unsigned)(3u && (m0 * (v0 | 0x80000000u)));
    *mp = (unsigned)((int)(unsigned)d0 >= (int)(unsigned)(i2 && 4u));
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        c1 = (signed char)((9u % (i1 | 1u)) % (0xb554ec1cu | 1u));
        u0 = u0 * 0x9e3779b1u + (((*mp / (*q0 | 1u)) / (2u | 1u)) ? (unsigned)e0 : g1);
        if ((unsigned)f0) break;
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(unsigned char)(0xada175acu / ((unsigned)c0 | 1u))) {
            continue; (void)((unsigned)((unsigned)w0 < ((unsigned)(x0 >> 70) | 0x10000u)));
            c0 = (unsigned char)-(unsigned)((int)p2 >= (int)0x870d672bu);
            *mp = ((unsigned)(signed char)(unsigned)((short)0x10000u > (signed char)g1) + (unsigned)e0);
            d0 = d0 * 0.5 + (double)((0x681cc292u / (((unsigned)b0 << (r0.x & 31u)) | 1u)) & 1023u);
            goto L0;
            q0 = &garr[((0x80000000u ? g1 : 0x5c2b3516u) ^ 0x7fffffffu) & 7u];
        } else {
            { unsigned t7; double z7; if (((unsigned)((int)1u >= (int)0x7fffffffu)) & 1u) { t7 = (unsigned)((int)(unsigned)d0 >= (int)((unsigned)e0 >> ((unsigned)c0 & 31u))); z7 = (double)(((unsigned)(w0 >> 29)) & 255u); } if (((unsigned)((int)1u >= (int)0x7fffffffu)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                { unsigned t8; double z8; if ((((unsigned)s1 * (unsigned)w0)) & 1u) { t8 = (unsigned)(short)((unsigned)((short)garr[u2 & 7u] > (signed char)0x10000u) >> (r0.y & 31u)); z8 = (double)(((9u - (unsigned)(signed char)(r0.y / (p2 | 1u)))) & 255u); } if ((((unsigned)s1 * (unsigned)w0)) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                    if ((unsigned)w0) break;
                    if ((unsigned)(i2 || ((unsigned)d0 & r0.x))) break;
                    if ((a0[u1 & 3u] ^ (unsigned)(2u && p1))) continue;
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        switch (r0.x & 7u) {
                            if (budget != 0u) { budget -= 1u; u0 = fn1(0x3f59c301u, (u3 ? (unsigned)x0 : (unsigned)l0), 0xa0d9ae5fu); }
                            if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(x0 >> 70) & v0), (unsigned)h0, (a0[u1 & 3u] << (((unsigned)f0 | (unsigned)(w0 >> 29)) & 31u))); }
                            case 7u: ;
                        }
                        if (a0[u1 & 3u]) break;
                        h1 = (unsigned short)(h1 + (0x630ec35fu & r0.y));
                        *mp = g0;
                        *q0 += (unsigned)(v0 && 0xe0522596u);
                        *q0 += 3u;
                    }
                    c0 = (unsigned char)(((r0.x * 0xffffffffu) - ((unsigned)f0 & 0x97416aadu)) << (p2 & 31u));
                    if ((*mp ^ 0x8c6eef69u)) continue;
                }
                d0 = d0 * 0.5 + (double)((unsigned)((short)((unsigned)w0 % (0x6d686d28u | 1u)) > (signed char)(unsigned)((int)((unsigned)(w0 >> 29) | 6u) < (int)r0.x)) & 1023u);
                while (i1++ < 2u && (unsigned)(r0.y || (unsigned)d0)) { if (--fuel == 0u) goto done;
                    u2 = (unsigned)((short)i2 > (signed char)0x9c123bcdu);
                    if (u2) {
                        continue; (void)(i1);
                        if ((unsigned)(short)((unsigned)x0 ^ u1)) goto L0;
                        break; (void)((2u * i1));
                    } else {
                        if (i1) break;
                        w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)(((r0.x >> ((unsigned)c1 & 31u)) >> ((unsigned)h1 & 31u)) - 0xc5a97fecu);
                        *mp = garr[i1 & 7u];
                        e0 = e0 * 0.5L + (long double)((v0 >> (a0[u1 & 3u] & 31u)) & 1023u);
                    }
                    e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)c0) & 1023u);
                    if ((unsigned)(signed char)(unsigned)((int)a0[i0 & 3u] < (int)((unsigned)x0 - 0xa9fe1775u))) {
                        h0 = (short)(unsigned)(0x10000u && (unsigned)((int)(unsigned)c0 < (int)a0[u1 & 3u]));
                        if ((unsigned)(u0 < 0x7fffffffu)) break;
                        break; (void)((unsigned)(u0 == 4u));
                    }
                    if ((0x766b4f57u >> ((r0.x | r0.x) & 31u))) break;
                }
            }
            if ((unsigned)(short)(3u + -((unsigned)e0 & 0x7fffffffu))) {
                m0 ^= ((unsigned)(x0 >> 70) << ((unsigned)h0 & 31u));
                *q0 = ((3u * g0) * (unsigned)((int)(unsigned)f0 >= (int)*mp));
                if (budget != 0u) { budget -= 1u; u1 = fn2((((unsigned)c1 + 0x7fffffffu) & (unsigned)(x0 >> 70)), p1, 0xa9093f7du); }
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)c1, ((unsigned)w0 ? u3 : (unsigned)(x0 >> 70)), (unsigned)!(u2 << (p0 & 31u))); }
                if (u1) break;
            } else {
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)h1, (unsigned)((int)(unsigned)c0 >= (int)-(unsigned)((int)a0[u1 & 3u] >= (int)fuel)), (unsigned)!((unsigned)!((unsigned)c0 % (0x10000u | 1u)) * 9u)); }
                r0.y ^= ((unsigned)l0 ^ ((unsigned)h0 ? (unsigned)((short)(unsigned)d0 > (signed char)p2) : (unsigned)h0));
                do { if (--fuel == 0u) goto done;
                    if ((i2 | garr[u2 & 7u])) break;
                } while (i1++ < 7u && (unsigned)((int)p0 >= (int)v0));
                if ((unsigned)(unsigned char)(2u & (m0 << (0x41c6d0dbu & 31u)))) continue;
            }
            while (i1++ < 3u && (unsigned)((short)u3 > (signed char)i1)) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)(0x10000u || (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)((unsigned)!(g0 >> (p2 & 31u)) && m0))));
                h1 = (unsigned short)(h1 + ((fuel >> ((unsigned)((short)0u > (signed char)a0[i0 & 3u]) & 31u)) % ((unsigned)c0 | 1u)));
                h1 = (unsigned short)(h1 + (unsigned)((4u << (0xf9087a1u & 31u)) < (unsigned)(unsigned char)((unsigned)(5u == u3) << (0xd6bcd934u & 31u))));
            }
            if ((unsigned)((int)0xffffffffu >= (int)p2)) {
                switch ((unsigned)((int)fuel < (int)(unsigned)x0) & 7u) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)c1 && (unsigned)s0), u1, (unsigned)((short)p1 > (signed char)(unsigned)h0)); }
                    l0 = (long)((unsigned long)l0 + (unsigned)((int)(p0 ? 0x10000u : a0[u1 & 3u]) >= (int)(unsigned)(unsigned char)(unsigned)((int)9u < (int)i0)));
                    if ((unsigned)(unsigned char)(0x7fffffffu & (unsigned)f0)) goto L4;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn2(*q0, (v0 | r0.y), 0x5f6f6b5u); }
            } else {
                if ((unsigned)((int)(unsigned)(garr[i1 & 7u] && 0xffffffffu) >= (int)0x67e7e8dfu)) break;
                if ((unsigned)(0x7fffffffu && a0[u1 & 3u])) {
                    *mp = (0x1363488u - garr[i1 & 7u]);
                    do { if (--fuel == 0u) goto done;
                        garr[(p0 >> ((unsigned)e0 & 31u)) & 7u] = (unsigned)(short)(r0.y << (i2 & 31u));
                        if (p2) break;
                        continue; (void)(((unsigned)x0 | *q0));
                    } while (i1++ < 7u && (unsigned)(x0 >> 70));
                } else {
                    if (a0[i0 & 3u]) break;
                }
                if (4u) break;
            }
        }
        if ((garr[u2 & 7u] | ((unsigned)s0 ^ p2))) break;
        break; (void)(((unsigned)b0 * (unsigned)((short)0x4807660eu > (signed char)p1)));
        u1 += (unsigned)((int)(unsigned)(x0 >> 70) < (int)(0x589f3c1bu >> (a0[i0 & 3u] & 31u)));
        x0 = x0 * 0x100000001b3ull + u0;
        { unsigned t9; double z9; if (((unsigned)(short)(unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)s0)) & 1u) { t9 = 0xffffffffu; z9 = (double)(((4u & (unsigned)h1)) & 255u); } if (((unsigned)(short)(unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)s0)) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
            if (((unsigned)s0 >> (p1 & 31u))) break;
            w0 ^= (unsigned long long)p1 << (r0.y & 63u);
            if ((unsigned)x0) continue;
            if (((unsigned)c1 ? 0xffffffffu : (unsigned)f0)) break;
            m0 ^= (unsigned)(unsigned char)(((unsigned)l0 + 0x2de771b6u) ^ (unsigned)c0);
            if (budget != 0u) { budget -= 1u; u0 = fn2(5u, (0x894da175u % (0x10000u | 1u)), (fuel % (4u | 1u))); }
        }
    }
    *q0 = (unsigned)((unsigned)((short)(unsigned)h1 > (signed char)0x10000u) && (unsigned)((unsigned)c0 && (unsigned)(0x24f7402bu == (unsigned)b0)));
    if (fuel < 8u) return (unsigned)((int)(unsigned)((unsigned)b0 < garr[u2 & 7u]) < (int)0x7fffffffu);
    if ((v0 % ((garr[i1 & 7u] ^ v0) | 1u))) goto L0;
    garr[u0 & 7u] = (unsigned)((unsigned)((short)(unsigned)((short)(unsigned)h1 > (signed char)7u) > (signed char)0x80000000u) < (g0 | (unsigned)c0));
    *q0 += (unsigned)((short)8u > (signed char)-(unsigned)((short)i2 > (signed char)(3u * g1)));
    if (budget != 0u) { budget -= 1u; u0 = fn0((0xc83cdc43u * 7u), u3, ((unsigned)s0 ^ ((unsigned)s0 | g0))); }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)x0 > (signed char)0xedf19acu), 0xffffffffu, (unsigned)c0); }
    h1 = (unsigned short)(h1 + ~((unsigned)((short)garr[u2 & 7u] > (signed char)g1) | 0xffffffffu));
    c0 = (unsigned char)((unsigned)x0 * (i2 - i2));
    if ((unsigned)(*q0 || (m0 % (garr[u2 & 7u] | 1u)))) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *q0 += (unsigned)(0x384c5d82u == 0x10000u);
    if ((unsigned)(0x24b03ecu == 4u)) {
        { unsigned t0; double z0; if ((((unsigned)s0 & (unsigned)(unsigned char)((unsigned)c1 & (unsigned)s0))) & 1u) { t0 = (unsigned)((int)6u < (int)(garr[i1 & 7u] * 3u)); z0 = (double)(((unsigned)(short)((unsigned)c1 / (7u | 1u))) & 255u); } if ((((unsigned)s0 & (unsigned)(unsigned char)((unsigned)c1 & (unsigned)s0))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            if ((unsigned)((0x10000u - (unsigned)s1) < r0.y)) goto L2;
            garr[(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)l0) & 7u] = (unsigned)((unsigned)s0 < (garr[u2 & 7u] - 5u));
            if (budget != 0u) { budget -= 1u; u3 = fn1(0xd501d44u, (unsigned)w0, (2u % (u1 | 1u))); }
            L0: if (--fuel == 0u) goto done;
            switch ((0x7fffffffu / (u1 | 1u)) & 7u) {
                u3 = (unsigned)((unsigned)(i2 < p2) < (unsigned)(short)(0xa965d788u * 0x80000000u));
                if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)s0 + (0x204cffe5u - 3u)), (unsigned)(signed char)(garr[i1 & 7u] >> ((unsigned)h1 & 31u)), (unsigned)(short)(unsigned)((unsigned)((unsigned)s1 && (unsigned)h1) || (unsigned)h1)); }
                do { if (--fuel == 0u) goto done;
                    q0 = &garr[(u1 ? (unsigned)s0 : (unsigned)f0) & 7u];
                    q0 = &garr[((0x7fffffffu & g1) + (unsigned)s1) & 7u];
                } while (i0++ < 4u && (0x512b5ed1u - p0));
                if (2u) goto L4;
                h1 = (unsigned short)(h1 + (p2 + (unsigned)(x0 >> 70)));
                while (i0++ < 4u && (unsigned)!(u3 | *q0)) { if (--fuel == 0u) goto done;
                    garr[(unsigned)(r0.x == 0x7fffffffu) & 7u] = (6u << (i1 & 31u));
                }
            }
            L1: if (--fuel == 0u) goto done;
        }
        e0 = e0 * 0.5L + (long double)((((unsigned)((unsigned)(w0 >> 29) < (unsigned)(x0 >> 70)) % (0xe32a252au | 1u)) ^ 0xffffffffu) & 1023u);
        if ((unsigned)((int)0x6757c1c7u < (int)a0[i0 & 3u])) {
            goto L1;
        } else {
            if (((unsigned)e0 - (unsigned)(signed char)(unsigned)(i1 == (unsigned)l0))) goto L4;
            if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((int)i2 >= (int)m0), (0xffffffffu >> ((u1 + 0x4bc8ef35u) & 31u)), (unsigned)s0); }
            h0 = (short)(unsigned)(0x80000000u || r0.y);
            m0 ^= (unsigned)(unsigned char)(fuel - (unsigned)!(unsigned)((unsigned)l0 && 0x10000u));
        }
    } else {
        if (~(i0 % ((5u >> ((unsigned)h1 & 31u)) | 1u))) goto L3;
        g0 = (unsigned)(((0xffffffffu / (r0.x | 1u)) & m0) || (unsigned)(r0.x < 0x10000u));
        if (((unsigned)c0 & 0xe1470a70u)) goto L4;
        if ((unsigned)((int)u1 >= (int)(unsigned)(short)(0x5409d4d8u | 0xffffffffu))) goto L4;
    }
    if ((unsigned)((short)(unsigned)(u2 && 0u) > (signed char)u3)) goto done;
    g0 = (unsigned)(8u || (unsigned)b0);
    switch ((unsigned)(short)(a0[i0 & 3u] << ((unsigned)(unsigned char)(u2 * (unsigned)h1) & 31u)) & 7u) {
        switch ((unsigned)(4u && i0) & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)!(unsigned)(u1 == (0x80000000u * (unsigned)h0)), (unsigned)s1, r0.x); }
            case 3u: ;
            if (r0.y) goto L3;
            case 2u: ;
        }
    }
    if (a0[u1 & 3u]) {
        goto L1;
        if (r0.x) goto L1;
        if ((unsigned)(signed char)(unsigned)((unsigned)e0 == 0x80000000u)) {
            { unsigned t1; double z1; if (((unsigned)c0) & 1u) { t1 = r0.x; z1 = (double)((0xfc2e1562u) & 255u); } if (((unsigned)c0) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                if (budget != 0u) { budget -= 1u; u3 = fn2((a0[i0 & 3u] | ((unsigned)f0 << (garr[u2 & 7u] & 31u))), ~(p0 & u1), (unsigned)x0); }
                r0.x = (fuel ? garr[u2 & 7u] : 3u);
            }
            if ((i1 >> (0x8743fcbdu & 31u))) {
                c0 = (unsigned char)(unsigned)(0xcc051ae0u == (unsigned)(((unsigned)(w0 >> 29) | (unsigned)c0) && (unsigned)w0));
                { unsigned t2; double z2; if ((-(unsigned)(r0.y && g0)) & 1u) { t2 = (u2 / (r0.x | 1u)); z2 = (double)(((unsigned)(0xfc762721u < (u1 ^ 9u))) & 255u); } if ((-(unsigned)(r0.y && g0)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    if (budget != 0u) { budget -= 1u; u2 = fn0((0x7fffffffu ? 3u : (unsigned)(w0 >> 29)), garr[i1 & 7u], (unsigned)(x0 >> 70)); }
                    if (fuel < 8u) return (((unsigned)(w0 >> 29) * m0) % (u1 | 1u));
                    if ((unsigned)((unsigned)d0 || (unsigned)(signed char)(unsigned)((short)0x8326d037u > (signed char)r0.x))) goto L1;
                    if ((unsigned)(short)((unsigned)(x0 >> 70) * p0)) {
                        { unsigned t3; double z3; if (((p1 & ((unsigned)(w0 >> 29) ^ p1))) & 1u) { t3 = ~(unsigned)((int)7u < (int)(0u << ((unsigned)c1 & 31u))); z3 = (double)((((unsigned)((short)(unsigned)s0 > (signed char)r0.y) % (u3 | 1u))) & 255u); } if (((p1 & ((unsigned)(w0 >> 29) ^ p1))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                            q0 = &garr[((unsigned)h1 ^ ((i2 >> (6u & 31u)) | g1)) & 7u];
                            if ((unsigned)s0) goto L3;
                            d0 = d0 * 0.5 + (double)((unsigned)(short)(unsigned)((int)(unsigned)((short)((unsigned)e0 * u1) > (signed char)8u) >= (int)(unsigned)b0) & 1023u);
                            goto L1;
                            u1 ^= (unsigned)(unsigned char)(6u ^ (unsigned)c1);
                        }
                    } else {
                        h1 = (unsigned short)(h1 + ((0x80000000u << ((unsigned)b0 & 31u)) ^ (garr[i1 & 7u] % (0x10000u | 1u))));
                    }
                    *q0 += ((unsigned)e0 | u3);
                    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(0x10000u == (8u << (0x10000u & 31u))), g0, (i1 << ((unsigned)x0 & 31u))); }
                }
                s1 = (int)((unsigned)s1 + (unsigned)(u3 || (r0.y % ((0x7fffffffu & r0.x) | 1u))));
                goto L4;
                u3 = u3 * 0x9e3779b1u + (unsigned)((2u & (unsigned)(u1 && (unsigned)c0)) == ((unsigned)e0 * (unsigned)s1));
                if ((0xffffffffu % ((unsigned)x0 | 1u))) goto done;
            } else {
                goto L4;
                q0 = &garr[((0u + (r0.x >> (((unsigned)l0 | 0xd484d7u) & 31u))) + 0x7fffffffu) & 7u];
                m0 ^= (u0 << ((unsigned)(8u && (p2 ^ garr[u2 & 7u])) & 31u));
                if ((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)w0)) {
                    r0.y ^= 0xb006671u;
                    if (u3 == 7u) return (unsigned)(garr[u2 & 7u] && (((unsigned)c0 & 9u) ? p0 : 8u));
                    do { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)((unsigned)(short)(unsigned)((int)u3 >= (int)*q0) & 1023u);
                        break; (void)(((unsigned)h1 / (0x6722a137u | 1u)));
                        if (budget != 0u) { budget -= 1u; u2 = fn2(0x7fffffffu, (unsigned)(unsigned char)((0x7fffffffu ^ *mp) / (0xe0a14beu | 1u)), 0x151bbefeu); }
                        m0 ^= a0[i0 & 3u];
                        L2: if (--fuel == 0u) goto done;
                    } while (i0++ < 2u && (unsigned)s0);
                } else {
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)h1 % (((unsigned)c0 % (p0 | 1u)) | 1u)), (unsigned)(*mp && ((unsigned)(x0 >> 70) * *mp)), (0x80000000u / (((unsigned)b0 / (p2 | 1u)) | 1u))); }
                }
            }
            if ((u0 / (8u | 1u))) goto L1;
            w0 = w0 * 6364136223846793005ull + (unsigned)(r0.y && a0[u1 & 3u]);
        }
        h1 = (unsigned short)(h1 + (unsigned)((int)(0x10000u ? (unsigned)b0 : (unsigned)((unsigned)d0 || 0x10000u)) < (int)(unsigned)(x0 >> 70)));
        if ((unsigned)(unsigned char)(fuel | 0x80000000u)) goto L0;
        u2 += (unsigned)c0;
    }
    do { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (i0 * (unsigned)c1));
        { unsigned t4; double z4; if ((garr[u2 & 7u]) & 1u) { t4 = -(unsigned)((unsigned)b0 && (unsigned)((unsigned)s1 && 0xe9182a81u)); z4 = (double)(((garr[i1 & 7u] << ((i0 * 0xdc812084u) & 31u))) & 255u); } if ((garr[u2 & 7u]) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
            s0 = (int)(unsigned)(short)(unsigned)(fuel == (unsigned)(r0.x || u0));
        }
        if ((unsigned)s1) break;
        L3: if (--fuel == 0u) goto done;
    } while (i0++ < 5u && (r0.y % (((unsigned)s0 % (7u | 1u)) | 1u)));
    r0.y ^= ~((unsigned)l0 + ((((unsigned)h1 - 0x10000u) - i1) << ((unsigned)c0 & 31u)));
    if (0xd5c24787u) {
        if (budget != 0u) { budget -= 1u; u0 = fn2((r0.y / (r0.y | 1u)), (unsigned)((short)0x80000000u > (signed char)(unsigned)d0), (unsigned)(i0 || i0)); }
        h1 = (unsigned short)(h1 + -(((unsigned)h0 * 0u) / (((unsigned)h1 + (unsigned)((short)5u > (signed char)5u)) | 1u)));
        L4: if (--fuel == 0u) goto done;
        { unsigned t5; double z5; if ((((unsigned)f0 ? a0[u1 & 3u] : 9u)) & 1u) { t5 = (unsigned)((short)0xffffffffu > (signed char)(u1 ^ (unsigned)c1)); z5 = (double)(((unsigned)s1) & 255u); } if ((((unsigned)f0 ? a0[u1 & 3u] : 9u)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            if ((0x5148b896u << ((unsigned)((unsigned)w0 && 3u) & 31u))) goto L4;
            m0 ^= -(unsigned)(u3 == ((unsigned)l0 & r0.x));
            c0 = (unsigned char)~((-(u2 | 0x7fffffffu) - (unsigned)b0) & 6u);
            r0.x = r0.y;
            if ((unsigned)(signed char)(2u << (3u & 31u))) {
                if (budget != 0u) { budget -= 1u; u0 = fn0((5u / ((unsigned)((int)(unsigned)s0 >= (int)i1) | 1u)), (p0 ^ p2), ((3u + m0) >> (0x80000000u & 31u))); }
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (0xe5dd3c56u) {
                        if (((unsigned)c0 << (0x80000000u & 31u))) break;
                        c0 = (unsigned char)((unsigned)s1 ? (unsigned)c1 : 0x10000u);
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(m0 || (unsigned)(x0 >> 70)), (unsigned)(unsigned char)(unsigned)((int)*mp >= (int)(unsigned)((int)(unsigned)h0 >= (int)*mp)), (*mp << (((unsigned)c0 - p2) & 31u))); }
                        if (budget != 0u) { budget -= 1u; u2 = fn3((p1 >> ((g0 - 0x10000u) & 31u)), (0x6d752570u * a0[i0 & 3u]), ((unsigned)f0 >> ((unsigned)x0 & 31u))); }
                        if (garr[u2 & 7u]) break;
                    } else {
                        u1 = ((unsigned)!(2u << (0x9bab77d7u & 31u)) * i0);
                        if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)((unsigned)(signed char)((unsigned)h1 ^ i1) && (unsigned)h0), (unsigned)(short)(garr[u2 & 7u] << (u2 & 31u)), ((9u & m0) >> ((unsigned)h1 & 31u))); }
                        if (budget != 0u) { budget -= 1u; u1 = fn3(((unsigned)l0 / (i1 | 1u)), g1, (v0 ^ u3)); }
                    }
                    i0 = 0xffffffffu & 15u;
                }
                switch ((unsigned)((int)0x9569f926u < (int)i2) & 7u) {
                    s0 = (int)(unsigned)(short)((unsigned)h0 % (0x6ef510fcu | 1u));
                    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((int)(unsigned)(p1 && fuel) >= (int)(unsigned)h1), r0.x, (unsigned)((int)6u >= (int)(unsigned)h0)); }
                        u3 ^= (p1 ^ (unsigned)((int)(unsigned)(signed char)(unsigned)((int)0xffffffffu >= (int)(unsigned)d0) >= (int)(r0.y >> ((unsigned)x0 & 31u))));
                    }
                    if ((unsigned)((int)u2 < (int)i2)) goto L3;
                    f0 = f0 * 0.5f + (float)(0x2c98168bu & 255u);
                }
            }
        }
        f0 = f0 * 0.5f + (float)((unsigned)c0 & 255u);
    } else {
        c0 = (unsigned char)((unsigned)s0 & ((unsigned)((int)0x5ae4d847u >= (int)i2) >> (u2 & 31u)));
        switch (((unsigned)((int)fuel < (int)r0.x) | (unsigned)s0) & 7u) {
            if ((u0 << (m0 & 31u))) goto L1;
            s0 = (int)(unsigned)(garr[i1 & 7u] && 6u);
            case 1u: ;
            case 3u: ;
            do { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (unsigned)w0);
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (r0.y * (unsigned)((short)m0 > (signed char)(unsigned)e0)));
                        default: ;
                        continue; (void)(((unsigned)(w0 >> 29) * (0x10000u - v0)));
                        h0 = (short)((unsigned)(signed char)(0x10000u % (u0 | 1u)) + (unsigned)(signed char)((unsigned)h0 ^ 0x40e5944bu));
                        c1 = (signed char)((unsigned)f0 >> ((unsigned)(short)((unsigned)h0 + (unsigned)c1) & 31u));
                    }
                    if (0x7fffffffu) continue;
                }
                if (fuel < 8u) return ((0xeb911c6du >> ((unsigned)h0 & 31u)) % (0x10000u | 1u));
                l0 = (long)((unsigned long)l0 + (unsigned)(p0 == u0));
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)((short)0x10b7072bu > (signed char)a0[u1 & 3u]);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(0xcdf74566u, (unsigned)(short)((v0 / (g1 | 1u)) + 4u), (0xac2e9d44u % ((unsigned)(p0 || p2) | 1u))); }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1(0x7fffffffu, (unsigned)(i1 < m0), (unsigned)s0); }
            } while (i0++ < 5u && (unsigned)(x0 >> 70));
            if (0u) {
                i0 = (unsigned)((int)u2 >= (int)(unsigned)c1) & 15u;
                { unsigned t6; double z6; if (((a0[u1 & 3u] & (0x7fffffffu | i1))) & 1u) { t6 = (unsigned)((int)0u < (int)(garr[u2 & 7u] + 6u)); z6 = (double)((u3) & 255u); } if (((a0[u1 & 3u] & (0x7fffffffu | i1))) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                    c0 = (unsigned char)(unsigned)!((0x10000u * (unsigned)e0) << (((unsigned)s1 << ((unsigned)d0 & 31u)) & 31u));
                    if (budget != 0u) { budget -= 1u; u2 = fn1(~(0xe390608au * v0), (a0[i0 & 3u] ^ u2), (-(unsigned)(fuel && i2) | i1)); }
                    case 5u: ;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0(2u, (unsigned)(9u || 9u), (i2 ? i2 : *q0)); }
            } else {
                case 6u: ;
            }
        }
    }
    if ((unsigned)((int)0x12b7c91bu < (int)(5u ^ u1))) goto L1;
    if ((unsigned)(i0 < r0.x)) goto done;
    if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)(m0 || 3u) % (u2 | 1u)), (garr[i1 & 7u] ^ (unsigned)f0), (unsigned)f0); }
    if (fuel < 8u) return 0xffffffffu;
    while (i0++ < 7u && (i1 >> (u2 & 31u))) { if (--fuel == 0u) goto done;
        v0 = (unsigned)((int)(unsigned)h0 >= (int)(0xa7796502u * (unsigned)(signed char)((unsigned)h1 + (unsigned)(w0 >> 29))));
        while (i1++ < 7u && ((2u << (u1 & 31u)) | r0.y)) { if (--fuel == 0u) goto done;
            continue; (void)((unsigned)(i1 == (p1 + i1)));
            { unsigned t7; double z7; if (((0x10000u << ((unsigned)(m0 && u0) & 31u))) & 1u) { t7 = (unsigned)(fuel == (unsigned)(v0 || i1)); z7 = (double)(((unsigned)c0) & 255u); } if (((0x10000u << ((unsigned)(m0 && u0) & 31u))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                break; (void)(0x80000000u);
                if ((0x10000u << (((unsigned)s0 >> (6u & 31u)) & 31u))) {
                    *q0 = ((unsigned)x0 + g0);
                    m0 ^= fuel;
                    for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        b0 = (unsigned)(short)((garr[i1 & 7u] >> (a0[i0 & 3u] & 31u)) / ((unsigned)((0xffffffffu - (unsigned)f0) < (unsigned)l0) | 1u)) != 0u;
                    }
                    if ((m0 ^ (unsigned)s1)) break;
                    *q0 = ((unsigned)h1 * m0);
                } else {
                    if (0xec1d5871u) break;
                }
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn3((garr[u2 & 7u] + (a0[u1 & 3u] << (p1 & 31u))), (u2 / (~((unsigned)(w0 >> 29) ^ g0) | 1u)), (r0.x / (i2 | 1u))); }
    if (fuel) goto L4;
    { unsigned t8; double z8; if (((unsigned)(short)(i0 - *mp)) & 1u) { t8 = (a0[u1 & 3u] - 8u); z8 = (double)((0xda48885au) & 255u); } if (((unsigned)(short)(i0 - *mp)) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
        if (((garr[i1 & 7u] * u3) ^ (unsigned)c0)) goto L3;
        switch (v0 & 7u) {
            goto done;
            case 6u: ;
            { unsigned t9; double z9; if (((unsigned)f0) & 1u) { t9 = (*q0 * (garr[u2 & 7u] >> (1u & 31u))); z9 = (double)(((0u % ((unsigned)h0 | 1u))) & 255u); } if (((unsigned)f0) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                a0[(unsigned)!(v0 << (g1 & 31u)) & 3u] = 9u;
                c0 = (unsigned char)-(0x7ba4c0dfu - (unsigned)((int)p1 < (int)u0));
            }
            s1 = (int)((unsigned)s1 + -((unsigned)(unsigned char)(0xd681d581u / (2u | 1u)) + ((unsigned)((short)i1 > (signed char)v0) & r0.x)));
        }
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (u3 == 7u) return ((unsigned)s0 ^ u3);
            while (i1++ < 3u && (unsigned)((short)u2 > (signed char)((unsigned)s1 - fuel))) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)h0 && (*q0 | 1u))) goto L0;
            }
            while (i1++ < 2u && fuel) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + 0x10000u;
            }
            do { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(((unsigned)((unsigned)((short)*mp > (signed char)0x7fffffffu) < (unsigned)s1) - (unsigned)(fuel || i2)) & 1023u);
                *q0 = -(*q0 - (0xffffffffu ? 7u : -(0u << ((unsigned)b0 & 31u))));
                if (budget != 0u) { budget -= 1u; u2 = fn3(g0, (unsigned)(signed char)(u1 * i2), (unsigned)((short)(unsigned)l0 > (signed char)(u0 - *q0))); }
                if (((unsigned)((int)0x80000000u < (int)(unsigned)d0) & m0)) goto L0;
                break; (void)((garr[u2 & 7u] + 0xd5d4c9f2u));
                if (p2) continue;
            } while (i1++ < 2u && ~(unsigned)((short)(p1 + 6u) > (signed char)0x32cafffu));
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)c1 >= (int)0x6d616d73u);
            if (0xdcac576du) break;
        }
        if ((u1 * u2)) goto L4;
    }
    goto done;
    if ((p1 - (unsigned)(short)(0x861f3e61u % ((unsigned)e0 | 1u)))) {
        h1 = (unsigned short)(h1 + ((unsigned)f0 >> ((unsigned)((int)(unsigned)w0 < (int)*mp) & 31u)));
        c0 = (unsigned char)((0x261fbe84u ^ i1) & 3u);
    }
    e0 = e0 * 0.5L + (long double)(((unsigned)l0 << (6u & 31u)) & 1023u);
    do { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)(~((m0 | a0[u1 & 3u]) ^ 0x7fffffffu) & 1023u);
        if ((unsigned)(g1 && (unsigned)(p1 < (unsigned)s0))) break;
        if (budget != 0u) { budget -= 1u; u0 = fn1(p2, (garr[i1 & 7u] - (unsigned)c0), (unsigned)((int)(unsigned)(p0 < 3u) < (int)i0)); }
        for (;;) { if (--fuel == 0u) goto done;
            if (0x952f2892u) break;
            switch ((unsigned)((int)0x81122c45u < (int)((unsigned)x0 / (p2 | 1u))) & 7u) {
                u2 ^= ((i0 % ((unsigned)w0 | 1u)) << ((0x14510e1fu & (unsigned)e0) & 31u));
                break; (void)((0u << ((unsigned)(unsigned char)(0x10000u - (unsigned)(x0 >> 70)) & 31u)));
                c0 = (unsigned char)(unsigned)(0x7fffffffu || (unsigned)e0);
                while (i2++ < 7u && (garr[i1 & 7u] | (0x512bda8fu % ((unsigned)x0 | 1u)))) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)0x7fffffffu < (int)garr[u2 & 7u])) {
                        garr[0x541e4da8u & 7u] = ((unsigned)(signed char)(unsigned)((short)0x10000u > (signed char)(garr[u2 & 7u] << ((unsigned)h1 & 31u))) ^ (unsigned)((int)(unsigned)s1 >= (int)(unsigned)f0));
                    }
                }
                while ((0x80000000u | (unsigned)x0)) { if (--fuel == 0u) goto done;
                    u3 ^= ((unsigned)s1 >> (0x80000000u & 31u));
                    case 6u: ;
                }
            }
            b0 = ((unsigned)((unsigned)b0 && (unsigned)w0) << (((unsigned)l0 >> (u3 & 31u)) & 31u)) != 0u;
            do { if (--fuel == 0u) goto done;
                garr[((unsigned)f0 + (unsigned)h1) & 7u] = (a0[i0 & 3u] | (-(0x2ea16a02u ? garr[i1 & 7u] : 7u) << ((unsigned)b0 & 31u)));
                s0 = (int)((unsigned)((unsigned)h0 || fuel) >> (u0 & 31u));
            } while (i2++ < 6u && (unsigned)c1);
            garr[g0 & 7u] = u2;
        }
        break; (void)(0x98b01c22u);
    } while (i0++ < 6u && ((unsigned)(0u == 6u) ^ (unsigned)h1));
    if (budget != 0u) { budget -= 1u; u3 = fn1((p2 * (unsigned)(w0 >> 29)), (unsigned)((unsigned)x0 || (unsigned)b0), (p2 % (9u | 1u))); }
    if ((unsigned)((p0 - (unsigned)h1) && (unsigned)w0)) {
        u2 = (unsigned)((int)(unsigned)((a0[i0 & 3u] * g1) == p1) >= (int)(unsigned)e0);
        goto L2;
        q0 = &garr[(unsigned)(signed char)(unsigned)((short)(i1 + (g0 | *q0)) > (signed char)(unsigned)(r0.y && u0)) & 7u];
        r0.x = (unsigned)(0xffffffffu && ((unsigned)s1 >> (p0 & 31u)));
        b0 = (~(unsigned)(5u == p1) & (g0 ? (unsigned)(x0 >> 70) : (unsigned)e0)) != 0u;
        if (0x4ffebf21u) goto L4;
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1((i0 ^ (u3 - i2)), ((unsigned)(signed char)(unsigned)(6u == p0) ^ v0), 0x80000000u); }
        g1 += (i0 & (unsigned)(signed char)(unsigned)((a0[i0 & 3u] * *mp) && ((unsigned)w0 & (unsigned)(x0 >> 70))));
        i1 = ((unsigned)((m0 & 6u) < (unsigned)s1) / (r0.x | 1u)) & 15u;
        u3 = u3 * 0x9e3779b1u + a0[i0 & 3u];
        if ((unsigned)(0x7fffffffu == a0[u1 & 3u])) break;
    }
    if ((unsigned)l0) goto L0;
    m0 ^= ((unsigned)x0 + (unsigned)((short)i0 > (signed char)(unsigned)c0));
    goto done;
    goto done;
    switch (0x148b8537u & 7u) {
        u1 += (unsigned)(0x7fffffffu == garr[i1 & 7u]);
        u2 += (unsigned)((int)(unsigned)s1 >= (int)p2);
        if ((unsigned)c0) {
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 1u: ;
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (2u) goto L3;
                    while (i2++ < 7u && ((unsigned)s0 | 0xffffffffu)) { if (--fuel == 0u) goto done;
                        if ((unsigned)x0) {
                            if ((unsigned)(a0[i0 & 3u] && (unsigned)(short)((unsigned)c1 + 0x10000u))) continue;
                            c0 = (unsigned char)(unsigned)((unsigned)(short)(((unsigned)(w0 >> 29) - u3) ^ u1) || ((unsigned)c1 & 0x80000000u));
                            case 5u: ;
                        } else {
                            if (budget != 0u) { budget -= 1u; u3 = fn1((*mp * (a0[u1 & 3u] >> (*mp & 31u))), (unsigned)((int)u1 < (int)(unsigned)((int)(unsigned)b0 >= (int)g0)), (unsigned)((unsigned)d0 || (0xfd96b1fu / (fuel | 1u)))); }
                            h1 = (unsigned short)(h1 + (0x80000000u / (1u | 1u)));
                        }
                    }
                    s0 = (int)(unsigned)s1;
                }
                { unsigned t10; double z10; if ((-(unsigned)(r0.x || 0xffffffffu)) & 1u) { t10 = (u0 % (6u | 1u)); z10 = (double)((p0) & 255u); } if ((-(unsigned)(r0.x || 0xffffffffu)) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                    case 7u: ;
                    { unsigned t11; double z11; if (((u0 * (8u << ((unsigned)f0 & 31u)))) & 1u) { t11 = (unsigned)((int)0x7fffffffu >= (int)*mp); z11 = (double)(((4u % (((unsigned)h0 * 0x80000000u) | 1u))) & 255u); } if (((u0 * (8u << ((unsigned)f0 & 31u)))) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
                        g0 = (u0 + (7u >> ((unsigned)((i0 | i1) && 0x235693c0u) & 31u)));
                        if ((unsigned)(p0 && (unsigned)c0)) goto L4;
                    }
                    while (i1++ < 4u && (p1 ^ 0x7fffffffu)) { if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)((((unsigned)(a0[u1 & 3u] < (unsigned)h0) << (i1 & 31u)) & (unsigned)w0) & 1023u);
                        if ((unsigned)((short)9u > (signed char)u1)) goto L4;
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)d0, (unsigned)(~(unsigned)((unsigned)c0 == 7u) < (unsigned)s0), (unsigned)(unsigned char)(unsigned)(7u && (unsigned)h0)); }
                        while (i2++ < 6u && 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)(unsigned)(x0 >> 70) < (int)a0[i0 & 3u]), p1, (unsigned)s1); }
                            default: ;
                            u1 += ((unsigned)((int)(u2 - (unsigned)c1) >= (int)u1) + ((unsigned)d0 << ((unsigned)c0 & 31u)));
                        }
                    }
                    c0 = (unsigned char)(unsigned)(unsigned char)((unsigned)(x0 >> 70) / ((u2 | fuel) | 1u));
                }
                if ((*mp * (0x88df5b11u ^ u0))) break;
                g1 += ((5u & m0) + m0);
            }
            if ((p0 & u2)) {
                if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)((short)(unsigned)h1 > (signed char)(unsigned)((unsigned)d0 && 8u)), i2, p0); }
                r0.x = ((unsigned)((int)(unsigned)h0 < (int)(unsigned)x0) % ((unsigned)(7u && (unsigned)((unsigned)e0 && u2)) | 1u));
            }
            break;
        } else {
            goto L3;
            c0 = (unsigned char)(unsigned)(signed char)(unsigned)((short)(garr[u2 & 7u] / (0xffffffffu | 1u)) > (signed char)(unsigned)(unsigned char)((unsigned)c1 ^ 0xe4c55d42u));
            if (budget != 0u) { budget -= 1u; u2 = fn3((garr[i1 & 7u] ^ 2u), (unsigned)(signed char)((unsigned)(w0 >> 29) | *q0), 0x8144e1d4u); }
        }
    }
    a0[g1 & 3u] = a0[i0 & 3u];
    if (p0) {
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)d0 << (i0 & 31u))) break;
            if (budget != 0u) { budget -= 1u; u0 = fn0((m0 / ((unsigned)s1 | 1u)), u1, p0); }
            do { if (--fuel == 0u) goto done;
                g0 = ~(u0 >> ((p1 >> (fuel & 31u)) & 31u));
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    m0 ^= (unsigned)((int)8u < (int)(unsigned)(signed char)(0x10000u - 0x10000u));
                    c0 = (unsigned char)(i1 | (unsigned)c0);
                }
                u3 += (unsigned)((int)(unsigned)c1 >= (int)5u);
                d0 = d0 * 0.5 + (double)((unsigned)(signed char)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x80000000u) & 1023u);
            } while (i1++ < 3u && (garr[u2 & 7u] * (unsigned)c0));
            u0 = (unsigned)(short)(unsigned)((int)v0 < (int)v0);
        }
        u3 = garr[i1 & 7u];
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            b0 = (-((unsigned)d0 ? i0 : *mp) - 0xeb368c96u) != 0u;
            u3 ^= (unsigned)!((u3 % (((unsigned)h1 << ((unsigned)d0 & 31u)) | 1u)) >> ((0xc42c75c0u >> (r0.y & 31u)) & 31u));
        }
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            g1 += u2;
            u0 ^= (unsigned)f0;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (0x28f1e1f7u) {
                    if (budget != 0u) { budget -= 1u; u2 = fn1(r0.y, (unsigned)((short)0x80000000u > (signed char)(unsigned)d0), ((unsigned)(w0 >> 29) << ((u3 * i2) & 31u))); }
                    w0 = w0 * 6364136223846793005ull + ((unsigned)(short)(unsigned)(0xb97851b5u && a0[u1 & 3u]) | (unsigned)h1);
                    if (((unsigned)e0 + (unsigned)((int)(unsigned)c0 >= (int)(unsigned)x0))) break;
                } else {
                    q0 = &garr[(unsigned)((i0 + 0x7fffffffu) && (0x10000u ? u1 : (unsigned)s1)) & 7u];
                    break; (void)((unsigned)((int)u0 >= (int)(unsigned)w0));
                }
                break; (void)((unsigned)h0);
                *mp = ((unsigned)h0 + p2);
            }
        }
    } else {
        e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)s0 >= (int)(unsigned)((short)p1 > (signed char)0xf29bbfd0u)) & 1023u);
        l0 = (long)((unsigned long)l0 + ((unsigned)s0 & (unsigned)c0));
        d0 = d0 * 0.5 + (double)(-(unsigned)((unsigned)(signed char)((unsigned)c0 | (unsigned)(x0 >> 70)) && ((unsigned)((int)(unsigned)h1 < (int)0x10000u) + r0.y)) & 1023u);
        if ((2u - -(fuel ^ 0x9c511609u))) goto done;
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        u1 = u1 * 0x9e3779b1u + (-(p1 | (*mp / ((unsigned)(x0 >> 70) | 1u))) - 0x47783bu);
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)*q0 >= (int)(unsigned)((unsigned)h0 < r0.x)), (unsigned)h1, (unsigned)w0); }
    }
    h0 = (short)-(unsigned)((0xda4e9b73u ^ u2) && (p2 & (unsigned)(signed char)(unsigned)((int)u3 >= (int)g0)));
    u0 = u0 * 0x9e3779b1u + (fuel ^ (unsigned)(0x10000u || i2));
    { unsigned t12; double z12; if ((garr[i1 & 7u]) & 1u) { t12 = r0.y; z12 = (double)((0x3672668fu) & 255u); } if ((garr[i1 & 7u]) & 1u) { u1 += t12; d0 = d0 * 0.5 + z12; }
        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)!(unsigned)((int)0u >= (int)g1) < 0x80000000u));
        u3 = 0x10000u;
        { unsigned t13; double z13; if ((0x1b422333u) & 1u) { t13 = (unsigned)((unsigned)c1 < ((unsigned)s1 << (v0 & 31u))); z13 = (double)(((0x7888668fu / (garr[i1 & 7u] | 1u))) & 255u); } if ((0x1b422333u) & 1u) { u3 += t13; d0 = d0 * 0.5 + z13; }
            if ((0x80000000u & 5u)) {
                if (((unsigned)(x0 >> 70) - p0)) goto L3;
            } else {
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    g0 = (0x1b8aed7cu - (unsigned)s0);
                    i1 = (0x10000u + (unsigned)(x0 >> 70)) & 15u;
                }
            }
            goto L2;
        }
        for (;;) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                m0 ^= ((unsigned)c1 ? 9u : (m0 << ((unsigned)d0 & 31u)));
                if (((unsigned)(w0 >> 29) | u0)) continue;
                l0 = (long)((unsigned long)l0 + *mp);
                continue; (void)((unsigned)(signed char)((r0.y - 0xffffffffu) * r0.y));
            } while (i1++ < 5u && 7u);
            if ((unsigned)(7u < (unsigned)s0)) break;
            goto done;
            if ((unsigned)((int)0x5dcb765u < (int)(unsigned)b0)) continue;
        }
    }
    d0 = d0 * 0.5 + (double)(v0 & 1023u);
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t14; double z14; if (((unsigned)((int)u1 >= (int)~(unsigned)((unsigned)s0 == 0xc93c7acu))) & 1u) { t14 = (unsigned)(unsigned char)(i0 & u3); z14 = (double)(((p1 % ((unsigned)(short)((unsigned)e0 & p1) | 1u))) & 255u); } if (((unsigned)((int)u1 >= (int)~(unsigned)((unsigned)s0 == 0xc93c7acu))) & 1u) { u1 += t14; d0 = d0 * 0.5 + z14; }
            if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)s1 - i1), (0xffffffffu ? (unsigned)e0 : g1), (unsigned)((short)p2 > (signed char)(unsigned)d0)); }
            *mp = *q0;
            if ((unsigned)(p0 || garr[u2 & 7u])) break;
            if (fuel) break;
            if (4u) break;
        }
        { unsigned t15; double z15; if (((unsigned)(w0 >> 29)) & 1u) { t15 = (unsigned)(4u || v0); z15 = (double)((i0) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u0 += t15; d0 = d0 * 0.5 + z15; }
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)((i1 | p2));
                if (budget != 0u) { budget -= 1u; u3 = fn0(a0[i0 & 3u], ((unsigned)((int)0x50be33d1u >= (int)u2) - v0), (0xe5f60b2au >> (u0 & 31u))); }
                if ((u2 - *q0)) break;
                if (budget != 0u) { budget -= 1u; u1 = fn1(0x80000000u, r0.y, (unsigned)((int)(unsigned)((short)(unsigned)d0 > (signed char)i2) >= (int)0xef69791bu)); }
                if ((unsigned)((int)0xaa2d88cau >= (int)(unsigned)(0x7fffffffu || m0))) break;
            }
            break; (void)(v0);
            if ((unsigned)!(unsigned)((int)0xffffffffu >= (int)(unsigned)w0)) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn3((2u | (unsigned)!((unsigned)w0 | p2)), (unsigned)s0, (unsigned)((unsigned)x0 || (unsigned)((short)0xffffffffu > (signed char)(unsigned)s1))); }
        }
        if ((r0.x | 0x80000000u)) {
            break; (void)((unsigned)((int)(unsigned)w0 >= (int)(0xf6a48ddu - a0[u1 & 3u])));
            if ((unsigned)(unsigned char)(2u * r0.x)) break;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((0xffffffffu >> (garr[u2 & 7u] & 31u)) || (unsigned)l0), (unsigned)!(unsigned)((int)garr[u2 & 7u] < (int)(unsigned)((int)0xffffffffu < (int)i1)), (u3 & (unsigned)(r0.x == 0x80000000u))); }
            if ((unsigned)c0) break;
        }
        if ((unsigned)((short)m0 > (signed char)0x7fffffffu)) continue;
        f0 = f0 * 0.5f + (float)((unsigned)(g0 || *q0) & 255u);
        if (0x70e3a74du) {
            u2 += ((r0.x | (unsigned)((unsigned)((short)(unsigned)s1 > (signed char)r0.x) < (unsigned)(x0 >> 70))) - 4u);
            if ((unsigned)((short)(unsigned)((int)*mp < (int)0x7420c761u) > (signed char)1u)) {
                switch ((unsigned)(((unsigned)s1 << (0xa41fb19cu & 31u)) && (unsigned)(x0 >> 70)) & 7u) {
                    s1 = (int)((unsigned)s1 + i0);
                    s1 = (int)((unsigned)s1 + ((*q0 / ((unsigned)f0 | 1u)) ? garr[u2 & 7u] : (unsigned)(fuel < 0x1c8d8973u)));
                    s1 = (int)((unsigned)s1 + (0xffffffffu / ((unsigned)w0 | 1u)));
                    for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            a0[*mp & 3u] = (unsigned)(short)(unsigned)(-((unsigned)(m0 < (unsigned)c0) | (unsigned)((unsigned)d0 == 2u)) || v0);
                            case 6u: ;
                        } while (i2++ < 2u && (unsigned)(5u && 5u));
                        u0 = u0 * 0x9e3779b1u + (unsigned)((short)~(g0 >> ((unsigned)(u3 == u1) & 31u)) > (signed char)(g1 - 0xc91bf91cu));
                        if (budget != 0u) { budget -= 1u; u0 = fn0((8u ? v0 : (unsigned)c0), (0x7bd19886u % ((unsigned)d0 | 1u)), (unsigned)x0); }
                        if (i2) goto L3;
                        if (((unsigned)f0 ^ (unsigned)f0)) continue;
                    }
                    if ((0x97ab795fu * p0)) continue;
                }
            }
            v0 = (unsigned)!(((unsigned)((unsigned)c1 == (unsigned)c1) >> (*mp & 31u)) + garr[i1 & 7u]);
            if ((unsigned)((int)0x10000u >= (int)(0xd84faed3u | u1))) break;
            i0 = (unsigned)(0xd1200c36u || (p1 >> (0x10000u & 31u))) & 15u;
        } else {
            do { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((g1 | m0) & 255u);
            } while (i1++ < 7u && (unsigned)((unsigned)c0 < 0x10000u));
            f0 = f0 * 0.5f + (float)(7u & 255u);
        }
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)(x0 >> 70);
            if ((unsigned)(unsigned char)((0x10000u % (0x7fffffffu | 1u)) + 0xb3b8d561u)) break;
            switch (i2 & 7u) {
                c1 = (signed char)(0xca11ee0bu >> ((unsigned)!(0x81760f09u >> (6u & 31u)) & 31u));
                case 3u: ;
                a0[(unsigned)(signed char)(unsigned)((int)(unsigned)l0 < (int)u1) & 3u] = 0x8befabfeu;
                case 2u: ;
                d0 = d0 * 0.5 + (double)((unsigned)((unsigned)c0 == p1) & 1023u);
            }
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((short)0x501503bdu > (signed char)garr[u2 & 7u]), (unsigned)((unsigned)x0 == 0xffffffffu), (unsigned)((int)0x10000u < (int)5u)); }
            v0 = (unsigned)((unsigned)s1 && u2);
            if ((unsigned)!(unsigned)((int)0x9776e282u < (int)garr[u2 & 7u])) goto L1;
        } while (i1++ < 3u && (unsigned)w0);
        while ((unsigned)(0x81306a10u || (fuel - 0xba52c3aeu))) { if (--fuel == 0u) goto done;
            v0 = (unsigned)((0xd481bf2eu >> ((unsigned)c0 & 31u)) || (unsigned)((int)i1 < (int)u2));
            if ((u2 >> (((unsigned)e0 / (u3 | 1u)) & 31u))) break;
            if (-(unsigned)(p2 == (unsigned)f0)) break;
            u3 = u3 * 0x9e3779b1u + (unsigned)((int)u1 >= (int)((unsigned)((int)1u < (int)u0) * (unsigned)((short)0x7fffffffu > (signed char)(unsigned)(w0 >> 29))));
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(0x25f63042u == (unsigned)e0), (unsigned)l0, p2); }
            if (p1) {
                if (fuel < 8u) return -(-(unsigned)(0xffffffffu && (unsigned)l0) * *q0);
                *mp = (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)h0);
                if (m0) break;
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    u3 = (unsigned)(short)(unsigned)((int)i1 < (int)(unsigned)s1);
                    garr[(u2 | i0) & 7u] = (unsigned)(-((unsigned)(0x10000u == (unsigned)c1) + fuel) == (unsigned)l0);
                    if (u3 == 7u) return a0[i0 & 3u];
                }
                s1 = (int)((unsigned)s1 + garr[u2 & 7u]);
                u0 = g1;
            }
        }
        w0 ^= (unsigned long long)garr[u2 & 7u] << (((unsigned)h1 % ((unsigned)((0x10000u | 6u) < (unsigned)l0) | 1u)) & 63u);
        if ((0x3e23bc88u + (unsigned)(0xffffffffu || (unsigned)x0))) {
            a0[p0 & 3u] = (unsigned)((unsigned)(short)(unsigned)((unsigned)(0x7fffffffu && v0) < (unsigned)x0) && u2);
            h1 = (unsigned short)(h1 + (fuel & (unsigned)((unsigned)(x0 >> 70) < u3)));
            if (u3 == 7u) return ((m0 * (unsigned)e0) / ((unsigned)(w0 >> 29) | 1u));
            s0 = (int)(0xeb32d19cu * (unsigned)((unsigned)x0 == 0x10000u));
        } else {
            i0 = (r0.x | (unsigned)(0x4bc5a4bdu && 0u)) & 15u;
            if ((p1 >> (g1 & 31u))) {
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(0x80000000u < garr[i1 & 7u]), (unsigned)x0, 0x19c47f47u); }
                { unsigned t16; double z16; if (((a0[u1 & 3u] << ((i1 % (a0[i0 & 3u] | 1u)) & 31u))) & 1u) { t16 = ((garr[u2 & 7u] ^ (unsigned)(x0 >> 70)) ^ (unsigned)c0); z16 = (double)(((unsigned)(0x74ef218u || (unsigned)((short)(unsigned)c1 > (signed char)(unsigned)s0))) & 255u); } if (((a0[u1 & 3u] << ((i1 % (a0[i0 & 3u] | 1u)) & 31u))) & 1u) { u3 += t16; d0 = d0 * 0.5 + z16; }
                    if ((unsigned)((int)(unsigned)s0 >= (int)(garr[i1 & 7u] - garr[u2 & 7u]))) goto L0;
                    l0 = (long)((unsigned long)l0 + (4u % ((unsigned)l0 | 1u)));
                    b0 = (unsigned)((unsigned)x0 && (i2 >> ((unsigned)(p1 < (unsigned)f0) & 31u))) != 0u;
                }
                if ((unsigned)l0) continue;
                g1 += (unsigned)((unsigned)(w0 >> 29) < (unsigned)w0);
                h0 = (short)((unsigned)(u1 && (unsigned)((unsigned)(signed char)(r0.y / (0xe8e254ccu | 1u)) || *q0)) + garr[u2 & 7u]);
                { unsigned t17; double z17; if ((8u) & 1u) { t17 = 0xffffffffu; z17 = (double)(((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(i1 + (unsigned)c1))) & 255u); } if ((8u) & 1u) { u0 += t17; d0 = d0 * 0.5 + z17; }
                    if (budget != 0u) { budget -= 1u; u0 = fn3((r0.y - (6u & 0x7fffffffu)), (*q0 * a0[i0 & 3u]), *mp); }
                    if ((unsigned)h0) break;
                    for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn2(4u, (unsigned)((int)(unsigned)s0 >= (int)(u3 | g1)), (p1 / (i2 | 1u))); }
                        r0.x = ((unsigned)s0 ? (0x7fffffffu % (5u | 1u)) : i0);
                        w0 ^= (unsigned long long)(a0[u1 & 3u] | p1) << ((unsigned)!((unsigned)((int)r0.y >= (int)(garr[i1 & 7u] + (unsigned)b0)) ^ garr[u2 & 7u]) & 63u);
                        { unsigned t18; double z18; if ((a0[i0 & 3u]) & 1u) { t18 = u0; z18 = (double)(((unsigned)((int)0x7fffffffu >= (int)a0[i0 & 3u])) & 255u); } if ((a0[i0 & 3u]) & 1u) { u2 += t18; d0 = d0 * 0.5 + z18; }
                            w0 ^= (unsigned long long)(a0[u1 & 3u] - (unsigned)l0) << ((unsigned)((0x7fffffffu + 0x3980fa4du) && p2) & 63u);
                            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)b0 == a0[i0 & 3u]));
                        }
                        break; (void)((unsigned)(unsigned char)((unsigned)d0 % (p2 | 1u)));
                    }
                    if (i1) goto L4;
                }
            }
        }
        for (;;) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)((int)~(unsigned)((unsigned)s0 && r0.x) >= (int)(unsigned)(signed char)(unsigned)((unsigned)l0 || u0)) & 1023u);
                switch (garr[u2 & 7u] & 7u) {
                    if ((unsigned)(x0 >> 70)) {
                        x0 = x0 * 0x100000001b3ull + (u3 << ((unsigned)(((unsigned)s1 % ((u3 | 0x10000u) | 1u)) < *mp) & 31u));
                        if (budget != 0u) { budget -= 1u; u1 = fn0(7u, p2, (unsigned)((p0 / (0x52eee011u | 1u)) == a0[u1 & 3u])); }
                        h0 = (short)((unsigned)e0 / (((unsigned)(w0 >> 29) >> (garr[u2 & 7u] & 31u)) | 1u));
                    }
                    if (((v0 >> (8u & 31u)) & 0x53a53591u)) {
                        case 0u: ;
                        w0 ^= (unsigned long long)1u << ((p2 ? garr[u2 & 7u] : ((unsigned)s1 ^ 0x54aefcaeu)) & 63u);
                    }
                }
                s1 = (int)((unsigned)s1 + 0x371e6e34u);
            }
            break; (void)((((unsigned)f0 | (unsigned)d0) + r0.y));
            if (budget != 0u) { budget -= 1u; u1 = fn1((0x9692ebb2u | 0x7fffffffu), (r0.x << (*q0 & 31u)), (unsigned)((int)(g1 & (unsigned)(x0 >> 70)) >= (int)(unsigned)c0)); }
        }
        if ((0x80000000u + r0.y)) continue;
    }
    if ((unsigned)(w0 >> 29)) {
        if ((0x10000u | (0x10000u / (u2 | 1u)))) goto L1;
        goto L2;
        if ((unsigned)((int)(unsigned)h1 < (int)(unsigned)(8u == p0))) goto L2;
    } else {
        if (g1) goto L3;
        switch ((((unsigned)d0 | (unsigned)w0) / (r0.x | 1u)) & 7u) {
            goto L3;
            break; (void)((unsigned)((unsigned)(x0 >> 70) || (unsigned)((int)i2 < (int)0x1ba20950u)));
            b0 = (unsigned)(x0 >> 70) != 0u;
            if (budget != 0u) { budget -= 1u; u2 = fn3(-(unsigned)((int)i2 >= (int)0x80000000u), (unsigned)(4u || (unsigned)((int)0x10000u >= (int)(unsigned)h0)), ~(unsigned)((int)((unsigned)w0 ^ 0x10000u) >= (int)g1)); }
        }
    }
    c0 = (unsigned char)i1;
    i1 = (p0 | (unsigned)f0) & 15u;
    if (r0.y) goto done;
    w0 ^= (unsigned long long)(unsigned)f0 << ((unsigned)((unsigned)s1 || (0xc6d56d50u ? *q0 : u0)) & 63u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 3u, 0xb2a05a87u, 0x4f61ddafu },
        { 1u, 0xd37a6918u, 0x12587894u },
        { 12u, 0x65bde556u, 0x111c0665u },
        { 11u, 0x2c75843fu, 0xf9ba5a1u },
        { 10u, 0x62055d42u, 0x2d2cecedu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
