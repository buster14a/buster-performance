// test-ssa-source's program of seed 134000433 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x3ae1a46bu, g1 = 0x64ae23e3u;
static unsigned garr[8] = { 0x5ffc8f4du, 0x26604b1fu, 0x8c871127u, 0x55e4a989u, 0xdc229798u, 0xc96f489bu, 0xd77ae88eu, 0x1dc11a51u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    c0 = (unsigned char)((unsigned)e0 + ((0x10000u ^ a0[u1 & 3u]) & (0x76ce501u - 2u)));
    L0: if (--fuel == 0u) goto done;
    *q0 = (i1 | 7u);
    l0 = (long)((unsigned long)l0 + (unsigned)((0x5ce26a4eu ^ p1) == (u0 ? 0xd0405413u : a0[u1 & 3u])));
    L1: if (--fuel == 0u) goto done;
    s0 = (int)(unsigned)(-(unsigned)((g0 ^ (unsigned)(w0 >> 29)) < p2) && (0x4fb0c305u - 0x10000u));
    L2: if (--fuel == 0u) goto done;
    L3: if (--fuel == 0u) goto done;
    while (i0++ < 5u && (unsigned)((int)p2 < (int)((unsigned)f0 + 6u))) { if (--fuel == 0u) goto done;
        L4: if (--fuel == 0u) goto done;
    }
    if ((6u / ((unsigned)((int)6u < (int)u3) | 1u))) goto done;
    a0[(garr[i1 & 7u] & 0x7609fed5u) & 3u] = (0x5c20b2d6u + 0xffffffffu);
    { unsigned t0; double z0; if (((unsigned)((unsigned)c1 || ((unsigned)d0 & 0x80000000u))) & 1u) { t0 = (3u ? g0 : 3u); z0 = (double)(((g0 * (unsigned)h0)) & 255u); } if (((unsigned)((unsigned)c1 || ((unsigned)d0 & 0x80000000u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        if (((unsigned)h0 * (0x7fffffffu + p1))) goto L0;
        switch ((i1 >> ((g1 >> (g0 & 31u)) & 31u)) & 7u) {
            switch ((unsigned)((int)*q0 < (int)(unsigned)f0) & 7u) {
                garr[(*mp | 0x6fc5476u) & 7u] = (unsigned)c1;
                h0 = (short)((unsigned)((unsigned)!(garr[i1 & 7u] ^ 0x445de3adu) == (unsigned)d0) % ((a0[i0 & 3u] | g0) | 1u));
                case 5u: ;
            }
            do { if (--fuel == 0u) goto done;
                if (r0.x) {
                    goto L1;
                    case 2u: ;
                    switch (0xc54553a4u & 7u) {
                        *q0 += garr[i1 & 7u];
                        case 5u: ;
                        case 2u: ;
                    }
                    case 3u: ;
                } else {
                    u1 = (unsigned)h1;
                }
                switch (((unsigned)((int)r0.y >= (int)6u) * (unsigned)h0) & 7u) {
                    g1 += (0xffffffffu * (unsigned)f0);
                    while (i1++ < 3u && (unsigned)(5u < (unsigned)((unsigned)s0 && i2))) { if (--fuel == 0u) goto done;
                        goto L3;
                        w0 ^= (unsigned long long)m0 << (r0.y & 63u);
                        case 7u: ;
                    }
                    if ((unsigned)((int)6u >= (int)~(unsigned)(m0 || 3u))) break;
                    if (fuel < 8u) return (unsigned)(5u < garr[u2 & 7u]);
                    do { if (--fuel == 0u) goto done;
                        case 1u: ;
                        case 0u: ;
                        case 5u: ;
                        while (i2++ < 7u && *q0) { if (--fuel == 0u) goto done;
                            *q0 = (unsigned)(short)((unsigned)c0 * ((unsigned)f0 ^ (unsigned)((int)(unsigned)((short)i0 > (signed char)(unsigned)h0) >= (int)(unsigned)x0)));
                            *q0 += (unsigned)(4u || (unsigned)(unsigned char)(unsigned)(r0.y == (p0 % (0x10000u | 1u))));
                            if ((unsigned)((int)(unsigned)(short)(unsigned)(0x613c8280u < u2) < (int)0x49e6f76bu)) break;
                            default: ;
                            case 2u: ;
                        }
                        if ((unsigned)c1) continue;
                    } while (i1++ < 4u && v0);
                    g1 += (*mp % ((0xfd667dfdu ? p2 : 0xe8fc6994u) | 1u));
                }
                case 0u: ;
            } while (i0++ < 2u && (unsigned)(u0 < (6u / (0x80000000u | 1u))));
            default: ;
            if (u1) break;
            g0 = (a0[u1 & 3u] & (unsigned)e0);
        }
        l0 = (long)((unsigned long)l0 + u0);
        switch ((unsigned)s1 & 7u) {
            if ((u2 * (0xffffffffu ^ 0x80000000u))) goto L2;
            case 5u: ;
            case 7u: ;
        }
        if ((m0 ? (unsigned)(x0 >> 70) : 8u)) goto L0;
    }
    if (0x9fdb9108u) goto L4;
    if ((unsigned)(unsigned char)(unsigned)(u2 || p1)) goto L1;
    if ((garr[i1 & 7u] ^ 0x20d2f43bu)) goto L0;
    h0 = (short)(unsigned)((unsigned)e0 < (unsigned)(3u == m0));
    if ((p1 - (unsigned)(w0 >> 29))) goto L0;
    h1 = (unsigned short)(h1 + ((u2 / (0x10000u | 1u)) / (~((unsigned)e0 | g1) | 1u)));
    if (~(unsigned)((int)(unsigned)b0 < (int)garr[i1 & 7u])) {
        goto L0;
        e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)((int)(p0 / (0x7fffffffu | 1u)) < (int)0x10000u)) & 1023u);
        v0 = (unsigned)(signed char)(unsigned)((unsigned)(garr[u2 & 7u] < fuel) == (unsigned)l0);
        if ((unsigned)((unsigned)s1 || (unsigned)(short)(u1 & 1u))) goto L0;
    } else {
        b0 = 0xffffffffu != 0u;
        if (((unsigned)d0 | (unsigned)l0)) goto L1;
        goto L1;
        while (i0++ < 4u && (a0[u1 & 3u] & (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)a0[u1 & 3u]))) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)d0 >= (int)(0xbf4543deu * p2))) break;
            { unsigned t1; double z1; if (((unsigned)((unsigned)(0x920c246au || v0) && 0x80000000u)) & 1u) { t1 = p2; z1 = (double)((*q0) & 255u); } if (((unsigned)((unsigned)(0x920c246au || v0) && 0x80000000u)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                c1 = (signed char)(((unsigned)e0 & 0x98c659f6u) * (unsigned)(3u == 0xa7b45dc0u));
                c0 = (unsigned char)((garr[i1 & 7u] ^ r0.x) << ((unsigned)b0 & 31u));
                break; (void)((g0 - (unsigned)(p0 < u2)));
            }
        }
    }
    goto L3;
    s1 = (int)((unsigned)s1 + (g0 + (unsigned)f0));
    do { if (--fuel == 0u) goto done;
        if (0xc4a1807fu) goto done;
    } while (i0++ < 5u && 3u);
    s0 = (int)((*q0 + 8u) >> ((0xffffffffu >> (0x80000000u & 31u)) & 31u));
    if ((unsigned)(short)(u1 & (unsigned)c0)) {
        if ((unsigned)(short)((unsigned)l0 & (unsigned)(w0 >> 29))) {
            if ((unsigned)(a0[i0 & 3u] || ((unsigned)l0 % (fuel | 1u)))) {
                q0 = &garr[(unsigned)(w0 >> 29) & 7u];
                *mp = (unsigned)((unsigned)(garr[u2 & 7u] < (unsigned)c0) && (unsigned)b0);
                v0 = ((*mp % ((unsigned)((m0 % (g0 | 1u)) < 0x10000u) | 1u)) * i1);
                goto L1;
                if (((unsigned)(0x7fffffffu || (unsigned)s0) * *q0)) goto L1;
                if ((unsigned)(p1 || i2)) goto L0;
            }
            v0 = (r0.x % (((unsigned)c0 - (0xffffffffu - (unsigned)(x0 >> 70))) | 1u));
        }
        if (((unsigned)d0 * garr[i1 & 7u])) goto L3;
    } else {
        b0 = ((unsigned)(signed char)(0x10000u ? 0x80000000u : (unsigned)c0) / (5u | 1u)) != 0u;
        *mp = u2;
    }
    r0.y ^= ((0xb35f2037u ^ (unsigned)(x0 >> 70)) << (0xffffffffu & 31u));
    b0 = r0.x != 0u;
    if (v0) goto L4;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        s0 = (int)((unsigned)((unsigned)c1 == (unsigned)f0) >> (r0.x & 31u));
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            while (i2++ < 6u && ((unsigned)e0 ^ p1)) { if (--fuel == 0u) goto done;
                if ((u0 % (0x80000000u | 1u))) break;
                if (fuel < 8u) return (unsigned)((int)(m0 | fuel) < (int)i0);
                l0 = (long)((unsigned long)l0 + (unsigned)((int)i2 < (int)6u));
            }
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (0x10000u) continue;
                c1 = (signed char)0x275149dau;
                if (fuel) break;
                if ((unsigned)(m0 || 0xffffffffu)) break;
            }
            *mp = (unsigned)h0;
            if ((unsigned)(unsigned char)(unsigned)((short)(unsigned)s0 > (signed char)0xc270f953u)) {
                switch (((unsigned)e0 - ((unsigned)(x0 >> 70) % (9u | 1u))) & 7u) {
                    s1 = (int)((unsigned)s1 + (unsigned)((int)(0x763be5a8u % (u2 | 1u)) >= (int)(fuel ? p2 : (unsigned)c0)));
                    g0 = (unsigned)(unsigned char)(u1 % (((unsigned)((short)0u > (signed char)u2) >> (i1 & 31u)) | 1u));
                    c0 = (unsigned char)r0.y;
                    v0 = ((unsigned)h0 % ((unsigned)(w0 >> 29) | 1u));
                }
                r0.y ^= ~(p0 / ((unsigned)s1 | 1u));
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)f0) break;
                    w0 = w0 * 6364136223846793005ull + ((u0 * a0[i0 & 3u]) % (9u | 1u));
                    h1 = (unsigned short)(h1 + (unsigned)(0x80000000u && (unsigned)x0));
                    break; (void)((0x80000000u / ((unsigned)s0 | 1u)));
                } while (i2++ < 4u && (unsigned)(i0 == u0));
                if ((unsigned)(p1 && (i1 & 3u))) break;
            } else {
                if (~(g0 << (v0 & 31u))) {
                    b0 = (unsigned)(x0 >> 70) != 0u;
                    goto L2;
                    if (0x80000000u) {
                        break; (void)((unsigned)((short)(unsigned)(0x80000000u && u3) > (signed char)(unsigned)l0));
                        s1 = (int)((unsigned)s1 + a0[u1 & 3u]);
                        h0 = (short)(p2 >> (0x52f0a8a6u & 31u));
                        l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)h1 + garr[u2 & 7u]) == (unsigned)(0x7dd73972u == (unsigned)c1)));
                        if (g0) break;
                        m0 ^= ~(unsigned)((unsigned)h0 == (unsigned)(w0 >> 29));
                    } else {
                        if (((unsigned)(garr[u2 & 7u] < 0xff4af6ffu) ^ u2)) break;
                        i2 = (g0 % (m0 | 1u)) & 15u;
                        w0 ^= (unsigned long long)(unsigned)(i0 == p1) << ((((unsigned)b0 / (u1 | 1u)) - r0.x) & 63u);
                        break; (void)((unsigned)((short)7u > (signed char)u0));
                    }
                    if (a0[i0 & 3u]) break;
                }
                h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)((int)(unsigned)s1 < (int)0x11f2217u)));
                if ((a0[i0 & 3u] | 6u)) break;
            }
        }
        if (a0[u1 & 3u]) break;
        if (u2) {
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)b0 < (int)g0));
        } else {
            do { if (--fuel == 0u) goto done;
                u1 = (r0.y >> (v0 & 31u));
                if ((3u % ((unsigned)(0x3d8b60dbu || 0x7fffffffu) | 1u))) continue;
            } while (i1++ < 7u && r0.x);
            w0 = w0 * 6364136223846793005ull + (u3 + (unsigned)(u2 || 0xffffffffu));
            if ((a0[i0 & 3u] / (i2 | 1u))) continue;
            q0 = &garr[(*q0 ? g0 : (((unsigned)(x0 >> 70) / (*mp | 1u)) * 1u)) & 7u];
        }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)d0) break;
            f0 = f0 * 0.5f + (float)((unsigned)f0 & 255u);
        }
    }
    q0 = &garr[(6u >> ((unsigned)c0 & 31u)) & 7u];
    switch ((unsigned)(r0.x < (unsigned)(w0 >> 29)) & 7u) {
        case 6u: ;
        goto done;
        u1 += p2;
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)((short)((unsigned)f0 * fuel) > (signed char)4u));
            }
            continue; (void)((u0 & (unsigned)f0));
            do { if (--fuel == 0u) goto done;
                while (i0++ < 7u && 0x5c0a548u) { if (--fuel == 0u) goto done;
                    if ((*q0 + 0x10000u)) break;
                    garr[(unsigned)((short)9u > (signed char)p0) & 7u] = (g1 ? *mp : 0x80000000u);
                    if ((unsigned)((unsigned)b0 || (i1 / ((unsigned)e0 | 1u)))) break;
                    d0 = d0 * 0.5 + (double)((unsigned)((unsigned)s0 && (unsigned)(signed char)(((unsigned)d0 ^ 5u) | (unsigned)b0)) & 1023u);
                    e0 = e0 * 0.5L + (long double)(-(unsigned)(0xa3c47235u || 0x6acc7d69u) & 1023u);
                }
            } while (i2++ < 7u && (0x5fd3effau + u3));
            h1 = (unsigned short)(h1 + ((unsigned)((unsigned)w0 && (unsigned)(v0 && 0xda878ca0u)) % ((m0 << (i0 & 31u)) | 1u)));
            v0 = ((unsigned)(signed char)(unsigned)((int)(unsigned)c1 < (int)(unsigned)((int)0xfd3a55f3u < (int)1u)) << (((unsigned)h1 & garr[i1 & 7u]) & 31u));
        } while (i1++ < 7u && u0);
        switch ((unsigned)((short)9u > (signed char)(g0 / (p2 | 1u))) & 7u) {
            s0 = (int)(unsigned)c0;
            goto done;
            case 5u: ;
            r0.x = ((unsigned)(w0 >> 29) & i2);
            q0 = &garr[~((unsigned)((r0.y >> ((unsigned)s1 & 31u)) == garr[i1 & 7u]) | 0x10000u) & 7u];
        }
        while (i1++ < 4u && 0xb3eb0a5du) { if (--fuel == 0u) goto done;
            break; (void)(~((unsigned)(w0 >> 29) ^ (v0 ^ 0xffffffffu)));
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)f0 && 0xd1de3c86u)) goto L1;
                if ((unsigned)(g0 == p0)) break;
            }
            u1 += (unsigned)!(unsigned)((unsigned)x0 || (0xd77778aeu & r0.x));
            a0[((unsigned)l0 + *q0) & 3u] = (unsigned)!((unsigned)e0 ? 0x10000u : p2);
            g0 = ((unsigned)(w0 >> 29) ^ 0x7d471147u);
            if ((~(i1 >> ((unsigned)h0 & 31u)) + p0)) goto L1;
        }
        if ((unsigned)((int)0x10000u >= (int)*mp)) break;
        if ((unsigned)((unsigned)((short)0x80000000u > (signed char)0x69cd99a4u) == 0x710ebcd9u)) break;
        if ((0x18175e2u >> ((unsigned)(0x80000000u && 0x7fffffffu) & 31u))) break;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((fuel >> (fuel & 31u))) break;
        if ((unsigned)((int)garr[i1 & 7u] < (int)i1)) {
            L0: if (--fuel == 0u) goto done;
            r0.x = (unsigned)((int)((unsigned)((unsigned)f0 == garr[i1 & 7u]) | 2u) < (int)7u);
            c0 = (unsigned char)((unsigned)((int)6u < (int)(unsigned)f0) >> ((unsigned)b0 & 31u));
        } else {
            switch ((unsigned)b0 & 7u) {
                L1: if (--fuel == 0u) goto done;
                case 0u: ;
                u0 += (unsigned)((int)i0 >= (int)a0[i0 & 3u]);
            }
            if ((unsigned)((int)~(u2 & (unsigned)h1) >= (int)0x2744db12u)) {
                if (budget != 0u) { budget -= 1u; u0 = fn0(2u, (v0 % ((unsigned)!(unsigned)(2u || 0u) | 1u)), 0x7fffffffu); }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)5u >= (int)3u), (unsigned)((int)u0 >= (int)(unsigned)((int)5u >= (int)(unsigned)w0)), (unsigned)(short)(((unsigned)s0 / (0xda27a732u | 1u)) * (unsigned)f0)); }
                i0 = u2 & 15u;
                L2: if (--fuel == 0u) goto done;
                if ((a0[i0 & 3u] >> (garr[i1 & 7u] & 31u))) goto L3;
            }
            if (((*mp - (unsigned)s1) << (r0.y & 31u))) {
                w0 ^= (unsigned long long)(unsigned)s1 << ((unsigned)((short)i0 > (signed char)u3) & 63u);
                *mp = (unsigned)((unsigned)((int)(unsigned)d0 >= (int)(unsigned)f0) || ((unsigned)f0 & (m0 >> ((unsigned)e0 & 31u))));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)m0 > (signed char)-(unsigned)(1u && 6u)), ((unsigned)(r0.x < (unsigned)b0) - g1), (unsigned)(v0 && (unsigned)c1)); }
                c1 = (signed char)(unsigned)((unsigned)(u3 < (unsigned)((unsigned)((unsigned)s0 == 0x14fae70du) || *q0)) == p0);
                i0 = 0x7fffffffu & 15u;
            } else {
                c1 = (signed char)i2;
            }
        }
        if ((0xfeaa0253u + (unsigned)(x0 >> 70))) {
            s1 = (int)((unsigned)s1 + (unsigned)!((unsigned)(p0 < (unsigned)((int)i1 < (int)(unsigned)d0)) / ((unsigned)(x0 >> 70) | 1u)));
            if (0xbc68780eu) break;
            if (budget != 0u) { budget -= 1u; u0 = fn0((r0.y ^ (unsigned)((int)p0 >= (int)(unsigned)w0)), (unsigned)((int)u2 >= (int)(unsigned)s1), ((unsigned)((unsigned)(w0 >> 29) == garr[i1 & 7u]) % ((unsigned)s0 | 1u))); }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((short)fuel > (signed char)(unsigned)e0)) break;
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = p1;
                    c1 = (signed char)(u0 / ((0x10000u ? (unsigned)((short)(unsigned)c0 > (signed char)p2) : u0) | 1u));
                    *q0 += ((unsigned)((unsigned)(2u || 0x10000u) == (unsigned)((int)(unsigned)e0 >= (int)(unsigned)s1)) >> (a0[u1 & 3u] & 31u));
                    if ((i1 << (0xffffffffu & 31u))) {
                        break; (void)((unsigned)(0u < -(a0[i0 & 3u] >> (u1 & 31u))));
                    } else {
                        q0 = &garr[r0.y & 7u];
                    }
                    m0 ^= (unsigned)(*q0 < garr[i1 & 7u]);
                }
                u2 += (0xba1a00b3u & (i2 << (u1 & 31u)));
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)x0 << (a0[u1 & 3u] & 31u)), ((unsigned)((int)0x80000000u >= (int)m0) - *mp), -(0x32042231u % (0xb558486bu | 1u))); }
                L3: if (--fuel == 0u) goto done;
            } while (i1++ < 4u && (unsigned)((int)(unsigned)h0 >= (int)(unsigned)(w0 >> 29)));
            i1 = 0x80000000u & 15u;
            u2 = u2 * 0x9e3779b1u + ((unsigned)s1 & (m0 / (4u | 1u)));
        }
        b0 = (unsigned)(v0 < ((unsigned)((short)9u > (signed char)6u) << (u3 & 31u))) != 0u;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            u2 = u2 * 0x9e3779b1u + (unsigned)(((unsigned)d0 | i1) == (unsigned)s1);
            u3 = u3 * 0x9e3779b1u + (1u / ((unsigned)((int)(unsigned)((int)a0[u1 & 3u] < (int)u1) < (int)p1) | 1u));
            { unsigned t0; double z0; if ((((unsigned)c0 | (r0.y - u3))) & 1u) { t0 = (unsigned)(p0 || g1); z0 = (double)(((unsigned)(2u && (0x80000000u / (g1 | 1u)))) & 255u); } if ((((unsigned)c0 | (r0.y - u3))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                if (((unsigned)(1u || g0) ^ (unsigned)w0)) break;
                break; (void)((unsigned)(signed char)(0x80000000u << (0xf2f27b2eu & 31u)));
            }
            L4: if (--fuel == 0u) goto done;
        }
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch ((garr[u2 & 7u] + p0) & 7u) {
                case 3u: ;
                goto L0;
                case 2u: ;
            }
            if ((unsigned)(g0 < ((unsigned)(x0 >> 70) << (r0.y & 31u)))) break;
            s1 = (int)((unsigned)s1 + (0x31fc20b5u & (unsigned)(0u && 0x80000000u)));
            if (i0) {
                if (budget != 0u) { budget -= 1u; u2 = fn0((0x9d2ddde6u | (unsigned)((int)u2 >= (int)(unsigned)(x0 >> 70))), g1, (u0 | (unsigned)((int)*mp < (int)(unsigned)c0))); }
                while (i2++ < 7u && ((unsigned)(i1 < p2) / (i0 | 1u))) { if (--fuel == 0u) goto done;
                    while ((unsigned)(g0 || p0)) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn0((u0 * 0xd453bbe0u), (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)g1), ((unsigned)!(unsigned)(0x7a7857adu || 3u) / (0u | 1u))); }
                        if ((((unsigned)c1 - p2) << (0x209b3abbu & 31u))) break;
                        if (((p2 ^ *q0) & (unsigned)x0)) {
                            w0 = w0 * 6364136223846793005ull + -(unsigned)((short)-(unsigned)(0x80000000u && u2) > (signed char)(i0 | (unsigned)(w0 >> 29)));
                            if (budget != 0u) { budget -= 1u; u1 = fn0(*q0, ((unsigned)(w0 >> 29) / (i0 | 1u)), (unsigned)(0xf89e6b2fu || garr[u2 & 7u])); }
                        } else {
                            c0 = (unsigned char)((unsigned)(x0 >> 70) ^ (unsigned)(((unsigned)l0 & i0) || *q0));
                        }
                        if (p2) break;
                        *mp = ((m0 * (unsigned)((short)u3 > (signed char)0u)) / (u2 | 1u));
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((9u % ((unsigned)(u0 && (unsigned)h0) | 1u)), ((unsigned)c1 - 7u), (unsigned)(i1 < (p1 << (fuel & 31u)))); }
                    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        b0 = ~(unsigned)((short)(unsigned)!(a0[u1 & 3u] << (i0 & 31u)) > (signed char)0x13365b88u) != 0u;
                        q0 = &garr[((unsigned)(short)((unsigned)l0 / (*q0 | 1u)) & (unsigned)(6u == 0x10000u)) & 7u];
                    }
                }
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)(unsigned)((int)a0[u1 & 3u] < (int)0x8e4fee3cu) > (signed char)m0), ((unsigned)!(unsigned)((unsigned)s1 || (unsigned)c1) - 0x80000000u), (fuel / (0xffffffffu | 1u))); }
                }
                if ((unsigned)((unsigned)s0 == (unsigned)((short)fuel > (signed char)(unsigned)w0))) continue;
            }
            if ((a0[u1 & 3u] + (unsigned)(7u && 0xddea8cdbu))) continue;
            if ((unsigned)!(1u / (*q0 | 1u))) break;
        }
    }
    goto L0;
    goto L2;
    l0 = (long)((unsigned long)l0 + u0);
    while (garr[i1 & 7u]) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((unsigned)l0 && r0.x));
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (2u * (unsigned)((5u ? 0xffffffffu : a0[u1 & 3u]) && m0));
        if ((((unsigned)b0 << (*q0 & 31u)) + (unsigned)(w0 >> 29))) continue;
        *q0 += (unsigned)(p1 && (unsigned)((int)(unsigned)h0 >= (int)(unsigned)((short)v0 > (signed char)(unsigned)d0)));
        while (i1++ < 5u && (unsigned)((short)0x5f7b6b76u > (signed char)(unsigned)d0)) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + -((unsigned)((int)(i1 << (0x80000000u & 31u)) < (int)(unsigned)(m0 < 0xd4ed00a3u)) ^ i1));
            u0 ^= ((u3 >> (i2 & 31u)) + (unsigned)(unsigned char)(garr[i1 & 7u] - (4u << (u0 & 31u))));
            if ((unsigned)(a0[u1 & 3u] || 0x81d9a78u)) break;
            continue; (void)((unsigned)c1);
            l0 = (long)((unsigned long)l0 + g0);
        }
        do { if (--fuel == 0u) goto done;
            break; (void)(g0);
        } while (i1++ < 4u && (unsigned)((int)0xb25db24eu < (int)i0));
        do { if (--fuel == 0u) goto done;
            r0.x = 0x17d41c3eu;
        } while (i1++ < 5u && (unsigned)((unsigned)h0 || a0[i0 & 3u]));
    }
    if ((unsigned)(g1 && (0xffffffffu & g0))) goto L2;
    if (((0x80000000u - u1) & i0)) {
        if ((1u ^ (unsigned)b0)) {
            if ((r0.y << ((unsigned)h1 & 31u))) goto L0;
        } else {
            u3 = ((unsigned)((unsigned)(w0 >> 29) && (unsigned)(w0 >> 29)) ? (unsigned)x0 : 0x8b2c35cbu);
            goto L0;
        }
        if ((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)((int)r0.y >= (int)p1))) goto L1;
        for (;;) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((unsigned)c1 & 1023u);
            break; (void)(((fuel % (m0 | 1u)) << (a0[u1 & 3u] & 31u)));
            x0 = x0 * 0x100000001b3ull + (unsigned)((int)(((unsigned)f0 + 0xebddd3f6u) % (0xa55e947fu | 1u)) >= (int)(unsigned)s1);
            goto L1;
        }
        *mp = (((unsigned)s0 & m0) % ((unsigned)d0 | 1u));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((0xc2b6acd5u / (0x5477cf84u | 1u)), u0, (g1 | g1)); }
    u0 = u0 * 0x9e3779b1u + (*mp & 0xffffffffu);
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)i0 > (signed char)9u), (p0 * a0[i0 & 3u]), v0); }
    goto L3;
    if (u3 == 7u) return ((unsigned)((unsigned)h0 && (unsigned)l0) + u0);
    switch ((8u + 0x7fffffffu) & 7u) {
        h0 = (short)(0x537404c2u & (unsigned)(short)(unsigned)(fuel == 0x7fffffffu));
    }
    if (u3 == 7u) return (((unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)c0) + i0) - i2);
    u2 = (unsigned)((short)(unsigned)(short)(p2 / ((p0 << (p0 & 31u)) | 1u)) > (signed char)u3);
    goto L0;
    h0 = (short)(i2 ^ g1);
    if ((unsigned)((int)4u >= (int)(unsigned)h1)) goto L3;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (9u) continue;
        if (((unsigned)(w0 >> 29) % ((fuel | 0xffffffffu) | 1u))) {
            s0 = (int)((0x7fffffffu << (0xffffffffu & 31u)) >> ((unsigned)((int)i1 >= (int)r0.x) & 31u));
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((0xffffffffu % ((unsigned)(signed char)(unsigned)(r0.y || 0xffffffffu) | 1u)), (p1 >> ((unsigned)e0 & 31u)), (unsigned)((int)v0 >= (int)0xffffffffu)); }
            }
            v0 = (unsigned)(w0 >> 29);
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)0x80000000u >= (int)0x6ef9dcc5u), (unsigned)(short)((unsigned)w0 & 0x1321f24u), (unsigned)(short)(unsigned)((int)(unsigned)(0xb157d9dcu == u0) >= (int)garr[i1 & 7u])); }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)l0, 0xffffffffu, (unsigned)((int)garr[u2 & 7u] >= (int)(p2 - (unsigned)s1))); }
        } else {
            break; (void)(0x29af164cu);
            w0 = w0 * 6364136223846793005ull + r0.y;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)0x7fffffffu > (signed char)(u3 * i2)), ((unsigned)((short)0xe08e8b1du > (signed char)(unsigned)s0) & 0x10000u), 0xe6613fa1u); }
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)((int)((unsigned)s1 - (unsigned)(0x27f8dbfbu && 0x10000u)) < (int)(p0 * 0x80000000u));
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                goto L0;
                m0 ^= g0;
                *mp = (unsigned)x0;
                if ((u2 ^ (unsigned)d0)) goto L0;
                continue; (void)(a0[u1 & 3u]);
                garr[(unsigned)(0x10000u && (unsigned)d0) & 7u] = (((unsigned)(0x9e6158f2u || (unsigned)x0) / ((u2 * (unsigned)e0) | 1u)) | r0.x);
            }
        }
    }
    goto L2;
    *q0 = (0x10000u - (4u ? u0 : garr[i1 & 7u]));
    s1 = (int)((unsigned)s1 + (0x80000000u ^ (unsigned)((short)(g0 + r0.y) > (signed char)((unsigned)e0 % (*mp | 1u)))));
    if ((g0 % (i1 | 1u))) goto L2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    h0 = (short)(unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)((short)m0 > (signed char)(unsigned)(u0 && (unsigned)(signed char)((unsigned)e0 | garr[u2 & 7u]))));
    if (((i1 * 0x10000u) >> (i1 & 31u))) {
        if (~((unsigned)b0 ^ 0x7fffffffu)) goto L4;
        g1 += (unsigned)(((unsigned)x0 << (i0 & 31u)) < (unsigned)w0);
    }
    if (u3 == 7u) return 0xeb9bae80u;
    a0[(u2 >> (r0.x & 31u)) & 3u] = (unsigned)(((unsigned)h1 ? r0.x : m0) && 1u);
    u3 ^= (((unsigned)((short)-(i0 << (a0[u1 & 3u] & 31u)) > (signed char)*q0) >> (0x7fffffffu & 31u)) & *mp);
    goto L2;
    r0.x = (v0 << ((g0 / (u0 | 1u)) & 31u));
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
            *q0 = ((unsigned)c1 ^ (3u + a0[i0 & 3u]));
            { unsigned t0; double z0; if (((unsigned)((int)0x3e79e184u < (int)a0[u1 & 3u])) & 1u) { t0 = (v0 | i2); z0 = (double)((((unsigned)(w0 >> 29) << (0u & 31u))) & 255u); } if (((unsigned)((int)0x3e79e184u < (int)a0[u1 & 3u])) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)x0, 3u, (i0 | 0x10000u)); }
                break; (void)((g0 - (p1 << (5u & 31u))));
                m0 ^= (unsigned)((unsigned)(unsigned char)((unsigned)((short)fuel > (signed char)(unsigned)c0) / (a0[u1 & 3u] | 1u)) == p0);
                if ((0x10000u ^ garr[i1 & 7u])) break;
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t1; double z1; if (((-(r0.x * (unsigned)f0) >> (r0.y & 31u))) & 1u) { t1 = 0xc5b69cb1u; z1 = (double)((0x80000000u) & 255u); } if (((-(r0.x * (unsigned)f0) >> (r0.y & 31u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                        b0 = (0u & (unsigned)((unsigned)w0 == (unsigned)b0)) != 0u;
                        L1: if (--fuel == 0u) goto done;
                        c1 = (signed char)(unsigned)(((6u << (a0[u1 & 3u] & 31u)) - fuel) && *q0);
                    }
                    l0 = (long)((unsigned long)l0 + (((unsigned)(u1 == i2) - *q0) - p1));
                    m0 ^= (unsigned)h0;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((p1 * i2) >> (2u & 31u)), u1, (u1 ? *q0 : a0[i0 & 3u])); }
                }
            }
        }
        while (i1++ < 7u && (unsigned)((int)(unsigned)d0 < (int)0x80000000u)) { if (--fuel == 0u) goto done;
            if (((unsigned)e0 << ((a0[u1 & 3u] + 0x7fffffffu) & 31u))) break;
            if ((unsigned)!(0xffffffffu + (unsigned)c1)) break;
            if (((unsigned)h0 / (fuel | 1u))) {
                { unsigned t2; double z2; if (((unsigned)(unsigned char)(p0 & i2)) & 1u) { t2 = (unsigned)!(unsigned)((short)(unsigned)(u1 && (unsigned)h0) > (signed char)(unsigned)h0); z2 = (double)((0xd0350dc6u) & 255u); } if (((unsigned)(unsigned char)(p0 & i2)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    if ((u3 + i2)) break;
                }
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((short)i1 > (signed char)g0) << ((unsigned)w0 & 31u)), (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)(w0 >> 29)), (unsigned)h0); }
    e0 = e0 * 0.5L + (long double)((unsigned)e0 & 1023u);
    if (u1) goto L1;
    v0 = (m0 % (~(unsigned)((unsigned)(short)(p2 & (unsigned)f0) && (0x1f353b5eu >> (0x6d80ff78u & 31u))) | 1u));
    if (*mp) goto L0;
    if (p1) goto done;
    do { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((unsigned)f0 & 1023u);
        w0 = w0 * 6364136223846793005ull + (fuel ^ u1);
        v0 = ((unsigned)c0 & (unsigned)h0);
        if (budget != 0u) { budget -= 1u; u0 = fn1(a0[u1 & 3u], 6u, (unsigned)d0); }
        while ((p0 - (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)a0[u1 & 3u]))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)p2 < (int)(unsigned)f0), (0x7fffffffu / (p2 | 1u)), ((unsigned)(p2 == p1) << (*mp & 31u))); }
            L2: if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(short)(unsigned)((short)*q0 > (signed char)garr[i1 & 7u])) goto L4;
                g1 += ((unsigned)!(0x80000000u | *mp) >> (((a0[u1 & 3u] - (unsigned)(x0 >> 70)) << (u1 & 31u)) & 31u));
            }
            switch ((unsigned)((int)0xf2ecd14au >= (int)(unsigned)!(g1 & (unsigned)e0)) & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)(unsigned)((int)0x10000u < (int)i0), ((unsigned)(u1 || 0x1be5e7bu) & (unsigned)c0), (unsigned)(r0.y == (unsigned)((short)i0 > (signed char)g1))); }
                r0.y ^= (u1 & (unsigned)(u3 == (g1 + (unsigned)((int)0x7fffffffu >= (int)(unsigned)e0))));
                v0 = (m0 ^ (unsigned)((short)(unsigned)((int)p2 >= (int)(unsigned)x0) > (signed char)garr[u2 & 7u]));
            }
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)0x2e116d34u < (int)0x3b4cee75u)) continue;
                s1 = (int)((unsigned)s1 + (0x10000u ^ (m0 | 0xf532cb72u)));
                u0 ^= (0xb559ae67u * (unsigned)(u1 < i0));
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)e0, (*q0 << ((unsigned)w0 & 31u)), u1); }
                do { if (--fuel == 0u) goto done;
                    for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)l0 == p2));
                        if (((unsigned)h1 % ((unsigned)c0 | 1u))) goto L3;
                    }
                    g1 += u0;
                    m0 ^= (r0.x << (m0 & 31u));
                    if (budget != 0u) { budget -= 1u; u1 = fn0(*q0, ((unsigned)h1 + 0x7fffffffu), (unsigned)l0); }
                    L3: if (--fuel == 0u) goto done;
                } while (i0++ < 3u && (0xffffffffu << (((unsigned)b0 ^ a0[i0 & 3u]) & 31u)));
                h1 = (unsigned short)(h1 + (unsigned)((int)7u < (int)(unsigned)l0));
            }
            d0 = d0 * 0.5 + (double)(u2 & 1023u);
        }
        do { if (--fuel == 0u) goto done;
            i1 = ((0xff63520eu ^ (unsigned)e0) >> ((0x8f41b881u | ((unsigned)l0 % (p1 | 1u))) & 31u)) & 15u;
        } while (i1++ < 6u && (unsigned)s0);
    } while (i0++ < 7u && (unsigned)(signed char)(unsigned)((short)(unsigned)e0 > (signed char)(u0 & 3u)));
    h0 = (short)((unsigned)((int)0x13d04b5au >= (int)0x7fffffffu) % ((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)((short)p0 > (signed char)(unsigned)h1)) | 1u));
    if ((unsigned)!(0x10000u % ((unsigned)(p1 && 0xd2db95a9u) | 1u))) {
        if ((g0 | (unsigned)(0x9505a425u < (unsigned)(w0 >> 29)))) goto L0;
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            g0 = (unsigned)(((unsigned)b0 ^ u0) || (unsigned)(i0 == (0xffffffffu & (unsigned)l0)));
        }
        while ((5u & u1)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1(5u, (unsigned)(p1 == (unsigned)l0), (unsigned)x0); }
            l0 = (long)((unsigned long)l0 + ((unsigned)(4u && (unsigned)s0) / ((unsigned)((int)0xea366286u >= (int)i0) | 1u)));
            c0 = (unsigned char)(((unsigned)s1 % ((i2 / (v0 | 1u)) | 1u)) >> (0x10000u & 31u));
        }
        *q0 = -(unsigned)((8u & a0[u1 & 3u]) == ((unsigned)e0 % ((unsigned)c0 | 1u)));
    }
    c1 = (signed char)(0x80000000u | (unsigned)(v0 && (7u + fuel)));
    m0 ^= (i0 & 0xadfcac5au);
    do { if (--fuel == 0u) goto done;
        s0 = (int)((unsigned)s1 + 2u);
        h0 = (short)(0xee710d50u << ((unsigned)((int)((unsigned)((short)2u > (signed char)*q0) * *mp) < (int)0xffffffffu) & 31u));
        x0 = x0 * 0x100000001b3ull + ~((*q0 >> ((unsigned)l0 & 31u)) << ((unsigned)l0 & 31u));
        { unsigned t3; double z3; if (((unsigned)((int)(unsigned)!(unsigned)((int)0u >= (int)i2) < (int)r0.x)) & 1u) { t3 = ((unsigned)(unsigned char)(unsigned)(r0.y == i1) * g0); z3 = (double)((p1) & 255u); } if (((unsigned)((int)(unsigned)!(unsigned)((int)0u >= (int)i2) < (int)r0.x)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            if (budget != 0u) { budget -= 1u; u3 = fn0(u1, (m0 | u2), (unsigned)e0); }
            do { if (--fuel == 0u) goto done;
                if ((8u + (unsigned)c1)) {
                    if (u1) break;
                    switch ((unsigned)((int)4u >= (int)0x7fffffffu) & 7u) {
                        s0 = (int)(((unsigned)(w0 >> 29) % (i0 | 1u)) + g0);
                        if (budget != 0u) { budget -= 1u; u3 = fn0(4u, a0[i0 & 3u], (unsigned)l0); }
                        *q0 += ((unsigned)w0 << ((3u * (unsigned)e0) & 31u));
                        if (budget != 0u) { budget -= 1u; u3 = fn0((r0.x >> (i2 & 31u)), ((unsigned)s0 << (0x7e48ab5fu & 31u)), (unsigned)((int)9u < (int)(unsigned)(0x7fffffffu < 8u))); }
                        m0 ^= (unsigned)(((unsigned)e0 % (p2 | 1u)) && (unsigned)!(unsigned)((short)(unsigned)(garr[i1 & 7u] && (unsigned)l0) > (signed char)(unsigned)f0));
                        c0 = (unsigned char)(g0 >> (((unsigned)f0 >> ((unsigned)h1 & 31u)) & 31u));
                    }
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        r0.x = 0x9d6d8a3au;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((0xd253e2a0u | v0), (unsigned)c1, 0xe67fe012u); }
                        q0 = &garr[(unsigned)(i2 == 0xffffffffu) & 7u];
                        *mp = (unsigned)(p0 == ((m0 / (i1 | 1u)) | 6u));
                        c1 = (signed char)((unsigned)(((unsigned)(x0 >> 70) / ((v0 | (unsigned)d0) | 1u)) == (unsigned)c0) & garr[u2 & 7u]);
                    }
                }
                u1 = u1 * 0x9e3779b1u + ((unsigned)((unsigned)(w0 >> 29) && g0) * (6u % (*mp | 1u)));
                L4: if (--fuel == 0u) goto done;
                u2 ^= g0;
                e0 = e0 * 0.5L + (long double)((unsigned)s1 & 1023u);
                u1 += ((unsigned)((int)i2 < (int)p2) ? (unsigned)s0 : (unsigned)w0);
            } while (i1++ < 4u && (u2 * (unsigned)e0));
            c0 = (unsigned char)(unsigned)((short)m0 > (signed char)(((unsigned)w0 % (6u | 1u)) << (garr[i1 & 7u] & 31u)));
            if (g1) {
                break; (void)(0xffffffffu);
                if (budget != 0u) { budget -= 1u; u0 = fn0((a0[i0 & 3u] ^ (unsigned)e0), (unsigned)(x0 >> 70), (unsigned)(0xee74b0f0u < (unsigned)f0)); }
                u0 = (unsigned)((int)(unsigned)s1 < (int)(unsigned)(unsigned char)(unsigned)((short)i2 > (signed char)(3u + 0xffffffffu)));
            }
            if (budget != 0u) { budget -= 1u; u1 = fn1(-((unsigned)c0 & a0[i0 & 3u]), *mp, (unsigned)((unsigned)f0 < (unsigned)c1)); }
        }
        m0 ^= ((unsigned)((unsigned)(short)(~(0xa31e03feu / (g0 | 1u)) + u3) == 0x7d6003fbu) + g0);
        if ((unsigned)((short)*q0 > (signed char)-(0x10000u >> ((unsigned)s1 & 31u)))) continue;
    } while (i0++ < 6u && u2);
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)l0 % (r0.y | 1u))) {
            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(unsigned)((short)2u > (signed char)(unsigned)x0);
        }
        break; (void)((unsigned)d0);
    }
    if ((u0 ? i0 : (unsigned)f0)) goto done;
    c0 = (unsigned char)(unsigned)(8u || (unsigned)(g0 == ((unsigned)(0x5dd22c07u && p1) >> ((unsigned)f0 & 31u))));
    if (0x10000u) goto L0;
    *mp = (unsigned)c0;
    goto L3;
    if ((unsigned)((unsigned)h1 == *q0)) goto L4;
    u3 = (0x80000000u ? p2 : (unsigned)((short)*q0 > (signed char)(unsigned)d0));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)f0;
        u2 = u2 * 0x9e3779b1u + (0xccdab646u - (unsigned)(*q0 || (unsigned)!(unsigned)((unsigned)e0 && (unsigned)h0)));
        if (4u) goto L2;
    }
    L0: if (--fuel == 0u) goto done;
    a0[m0 & 3u] = (unsigned)((int)(unsigned)!(unsigned)((unsigned)((short)p0 > (signed char)garr[i1 & 7u]) || (garr[u2 & 7u] | u1)) >= (int)0x4f604c0fu);
    goto done;
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)h1 % (r0.x | 1u))) continue;
            if (budget != 0u) { budget -= 1u; u2 = fn1((i1 << (i1 & 31u)), (u2 * u1), 0xa510eb97u); }
        }
    } while (i0++ < 5u && a0[i0 & 3u]);
    { unsigned t0; double z0; if (((unsigned)(0xc328a774u < 7u)) & 1u) { t0 = (unsigned)h0; z0 = (double)((i0) & 255u); } if (((unsigned)(0xc328a774u < 7u)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        if (9u) goto L2;
        switch ((unsigned)w0 & 7u) {
            L1: if (--fuel == 0u) goto done;
            case 5u: ;
            if ((unsigned)!(8u * 7u)) goto L3;
        }
    }
    c0 = (unsigned char)(i2 % (g1 | 1u));
    while ((*q0 & (v0 | 5u))) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (((unsigned)x0 ? 0x10000u : m0) | 0x80000000u);
        h0 = (short)(unsigned)(unsigned char)(unsigned)((int)((unsigned)h0 % (garr[i1 & 7u] | 1u)) >= (int)garr[i1 & 7u]);
        while (i1++ < 3u && (unsigned)(unsigned char)(unsigned)((short)0x80000000u > (signed char)(unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
            if (((unsigned)f0 >> (((unsigned)x0 << (v0 & 31u)) & 31u))) break;
            b0 = ((unsigned)c1 / ((unsigned)(0x6bf438c1u == 0xaf48764u) | 1u)) != 0u;
        }
    }
    goto L2;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = *q0;
        { unsigned t1; double z1; if (((unsigned)(unsigned char)(7u & 0xae370d09u)) & 1u) { t1 = (unsigned)((short)m0 > (signed char)(unsigned)s1); z1 = (double)(((unsigned)((int)(unsigned)(short)(u2 - 0x10000u) < (int)0xbce179d9u)) & 255u); } if (((unsigned)(unsigned char)(7u & 0xae370d09u)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            { unsigned t2; double z2; if (((unsigned)((int)(unsigned)(0x314c408fu || 9u) >= (int)g1)) & 1u) { t2 = (u0 % (garr[u2 & 7u] | 1u)); z2 = (double)(((unsigned)((short)4u > (signed char)a0[u1 & 3u])) & 255u); } if (((unsigned)((int)(unsigned)(0x314c408fu || 9u) >= (int)g1)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)b0 < (unsigned)(x0 >> 70)), ((0x80000000u ^ (unsigned)h1) & 0xb284e9feu), (unsigned)l0); }
                *q0 += ((unsigned)(2u < m0) * (u3 + (unsigned)b0));
                switch ((unsigned)(short)((unsigned)(0xffffffffu < 0u) ^ p2) & 7u) {
                    case 4u: ;
                    break; (void)(((unsigned)x0 - (unsigned)s1));
                    b0 = (unsigned)c0 != 0u;
                    break; (void)(((unsigned)h0 * (unsigned)e0));
                    c1 = (signed char)(unsigned)(signed char)((u0 / ((unsigned)((int)0x10000u >= (int)0u) | 1u)) & p0);
                    f0 = f0 * 0.5f + (float)(~((unsigned)((short)u1 > (signed char)a0[i0 & 3u]) | (unsigned)b0) & 255u);
                }
                c0 = (unsigned char)(unsigned)((short)(unsigned)s0 > (signed char)(1u / ((unsigned)s1 | 1u)));
                while (8u) { if (--fuel == 0u) goto done;
                    if (0x7fffffffu) continue;
                }
                break; (void)((unsigned)(w0 >> 29));
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)s0 + 3u), r0.x, (unsigned)((short)u0 > (signed char)0xa2aa871eu)); }
            if ((u1 / (g1 | 1u))) continue;
            if ((v0 & r0.x)) {
                m0 ^= (unsigned)c0;
                if (0x5202573du) goto done;
            }
            if (a0[i0 & 3u]) {
                if ((unsigned)d0) break;
            } else {
                break; (void)(0u);
                L2: if (--fuel == 0u) goto done;
                break; (void)((*q0 >> ((unsigned)(0x7fffffffu < 8u) & 31u)));
                if (3u) break;
            }
            while ((unsigned)(short)(unsigned)((short)0x80000000u > (signed char)4u)) { if (--fuel == 0u) goto done;
                i0 = (unsigned)(u0 && (unsigned)((short)0x10000u > (signed char)0x10000u)) & 15u;
                l0 = (long)((unsigned long)l0 + (u3 >> (0x234620d6u & 31u)));
                if (r0.x) break;
            }
        }
        g0 = ((unsigned)b0 & (6u & (8u % (p1 | 1u))));
        while ((0x5177c44au & m0)) { if (--fuel == 0u) goto done;
            b0 = 0x853b8652u != 0u;
            if (budget != 0u) { budget -= 1u; u2 = fn0(0x8bd06350u, 0x80000000u, (unsigned)(i0 == ((unsigned)e0 << (0x80000000u & 31u)))); }
            while (i2++ < 3u && (unsigned)((unsigned)e0 || (unsigned)b0)) { if (--fuel == 0u) goto done;
                *q0 += (unsigned)((int)(unsigned)h1 >= (int)((unsigned)b0 * (unsigned)(0u && 0xffffffffu)));
                do { if (--fuel == 0u) goto done;
                    while (i1++ < 3u && -((unsigned)h0 >> (0x10000u & 31u))) { if (--fuel == 0u) goto done;
                        b0 = (unsigned)((unsigned)c1 == 0u) != 0u;
                        c0 = (unsigned char)(unsigned)(garr[i1 & 7u] && (unsigned)(i0 || (unsigned)s0));
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((g0 & (unsigned)(x0 >> 70)) << ((unsigned)(w0 >> 29) & 31u)), (p0 << ((unsigned)b0 & 31u)), (unsigned)(unsigned char)((unsigned)f0 >> (0xef0dcec8u & 31u))); }
                    }
                    break; (void)(((unsigned)h0 ^ 0xffffffffu));
                    w0 = w0 * 6364136223846793005ull + ((unsigned)((short)(unsigned)s1 > (signed char)p2) & (unsigned)b0);
                } while (i0++ < 6u && (unsigned)((int)1u < (int)8u));
                if ((unsigned)c1) break;
            }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn2(0x80000000u, (unsigned)f0, (u2 & r0.y)); }
        L3: if (--fuel == 0u) goto done;
    }
    v0 = ((unsigned)((int)garr[u2 & 7u] >= (int)p1) ^ (unsigned)!(unsigned)(g1 == fuel));
    if ((unsigned)s1) goto L1;
    if (garr[i1 & 7u]) {
        if (fuel < 8u) return (~(0x7fffffffu % (*mp | 1u)) + i0);
    } else {
        while ((unsigned)((int)r0.x >= (int)(unsigned)((unsigned)e0 < *q0))) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                s0 = (int)(unsigned)((int)((unsigned)(unsigned char)(unsigned)((unsigned)b0 < r0.x) * garr[u2 & 7u]) < (int)(5u % (0x6ce00cceu | 1u)));
            }
        }
    }
    { unsigned t3; double z3; if ((a0[i0 & 3u]) & 1u) { t3 = (unsigned)((unsigned)((int)(unsigned)c0 >= (int)(unsigned)b0) || (unsigned)(w0 >> 29)); z3 = (double)((((unsigned)c1 ? *mp : (unsigned)w0)) & 255u); } if ((a0[i0 & 3u]) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
        if (budget != 0u) { budget -= 1u; u0 = fn1(((0x45c09906u | garr[i1 & 7u]) & r0.y), ((unsigned)d0 / ((unsigned)(unsigned char)(unsigned)(0xe7595a08u == m0) | 1u)), (unsigned)((int)(unsigned)c0 < (int)u1)); }
        x0 = x0 * 0x100000001b3ull + ((unsigned)(unsigned char)(7u / (0x10000u | 1u)) - 0x7fffffffu);
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            i0 = (unsigned)b0 & 15u;
            if (i1) {
                if (budget != 0u) { budget -= 1u; u2 = fn2((0x10000u - 7u), (unsigned)(unsigned char)(unsigned)(0x10000u < (g1 / (m0 | 1u))), ((unsigned)c1 << (i0 & 31u))); }
                v0 = (unsigned)((int)(unsigned)h0 >= (int)(unsigned)l0);
                if ((p1 - p0)) break;
                if (-((unsigned)(signed char)(1u >> ((unsigned)s1 & 31u)) + i0)) goto L3;
                if (budget != 0u) { budget -= 1u; u2 = fn1(p2, (0xd8d16247u + (u3 / ((unsigned)h1 | 1u))), (unsigned)(signed char)(unsigned)(u3 || ((unsigned)b0 * a0[u1 & 3u]))); }
            }
            switch (((unsigned)(g0 < i1) << (i1 & 31u)) & 7u) {
                if ((unsigned)(unsigned char)(unsigned)(3u == p0)) break;
                { unsigned t4; double z4; if (((unsigned)!(0x34bde4ddu | i0)) & 1u) { t4 = (unsigned)((short)0x5185c1ecu > (signed char)p0); z4 = (double)(((unsigned)(w0 >> 29)) & 255u); } if (((unsigned)!(0x34bde4ddu | i0)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    if ((0xffffffffu / (u2 | 1u))) continue;
                    a0[0xcdfe71fdu & 3u] = (unsigned)((short)0x7e460a98u > (signed char)(unsigned)(signed char)(p0 ^ u1));
                    if ((m0 ? (unsigned)h1 : (unsigned)(x0 >> 70))) goto L3;
                }
                case 4u: ;
                if (~(g1 + (unsigned)l0)) {
                    *mp = (((unsigned)c0 >> (((unsigned)f0 * (unsigned)h0) & 31u)) + (0x53e748f0u | fuel));
                    b0 = (i2 >> ((unsigned)((short)(unsigned)(unsigned char)(unsigned)((short)(unsigned)s0 > (signed char)(unsigned)c0) > (signed char)0xffffffffu) & 31u)) != 0u;
                }
            }
            u3 += (unsigned)((unsigned)(0xffffffffu == (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)h0)) == r0.y);
            L4: if (--fuel == 0u) goto done;
        }
        goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2(garr[u2 & 7u], (unsigned)d0, (unsigned)((int)0x45cc5ddau >= (int)0xd9f5edaau)); }
    }
    goto L0;
    goto L3;
    u2 = u2 * 0x9e3779b1u + m0;
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)h1) goto L4;
            switch ((u1 * u0) & 7u) {
                c0 = (unsigned char)0xea544f51u;
                switch (-(i0 << ((unsigned)w0 & 31u)) & 7u) {
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)(0x51d176eau == (unsigned)(w0 >> 29))), (i0 / ((3u / (fuel | 1u)) | 1u)), *q0); }
                    for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)g0 < (int)(unsigned)((int)(unsigned)s1 >= (int)i2))) break;
                        case 6u: ;
                        a0[0x6b505e21u & 3u] = (i0 / (7u | 1u));
                        r0.x = (unsigned)!((unsigned)((int)(unsigned)(signed char)(g0 << (u1 & 31u)) < (int)(unsigned)((int)0x80000000u < (int)g0)) - 0x6f0f9bdbu);
                        break; (void)(0u);
                        if (~(3u & (unsigned)d0)) continue;
                    }
                    m0 ^= (((unsigned)b0 << ((unsigned)c0 & 31u)) & a0[u1 & 3u]);
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(u2 && 9u), (unsigned)((int)0xffffffffu >= (int)0xa16a3ceu), (3u << ((unsigned)((int)g1 < (int)(unsigned)(w0 >> 29)) & 31u))); }
                    d0 = d0 * 0.5 + (double)((u2 >> ((unsigned)((unsigned)f0 || (unsigned)((int)7u >= (int)-(u3 ^ 4u))) & 31u)) & 1023u);
                }
                l0 = (long)((unsigned long)l0 + u0);
                case 6u: ;
                do { if (--fuel == 0u) goto done;
                    switch (i1 & 7u) {
                        { unsigned t5; double z5; if (((unsigned)((int)(unsigned)c0 >= (int)0xffffffffu)) & 1u) { t5 = 0x80000000u; z5 = (double)((m0) & 255u); } if (((unsigned)((int)(unsigned)c0 >= (int)0xffffffffu)) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                            goto L1;
                            s1 = (int)((unsigned)s1 + ((unsigned)s0 ^ (2u << (v0 & 31u))));
                            g0 = (unsigned)((0xadfcc085u ^ 0x80000000u) == (unsigned)((int)g1 < (int)(unsigned)((unsigned)x0 && garr[u2 & 7u])));
                            continue; (void)((unsigned)(w0 >> 29));
                        }
                        r0.x = (unsigned)((unsigned)((short)(unsigned)h1 > (signed char)u3) < p0);
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(0u || 0x80000000u), ((unsigned)e0 - (unsigned)f0), ((unsigned)c1 / (((unsigned)s1 - (unsigned)(w0 >> 29)) | 1u))); }
                    }
                } while (i2++ < 7u && p1);
                default: ;
            }
        }
        if ((unsigned)(u3 < (p2 / (i1 | 1u)))) {
            do { if (--fuel == 0u) goto done;
                r0.x = ((unsigned)(x0 >> 70) ? i2 : 4u);
                if (0xc85385e3u) break;
                continue; (void)((unsigned)(g0 || 0u));
            } while (i1++ < 6u && (i1 / ((p1 ^ 1u) | 1u)));
        } else {
            break; (void)((0xa98b52b3u >> ((unsigned)((int)0xacd6d32cu < (int)(unsigned)d0) & 31u)));
            c1 = (signed char)(unsigned)(0xb127abe6u || 0xd270e008u);
        }
    } while (i0++ < 3u && (unsigned)!(unsigned)(p0 < (unsigned)((int)5u < (int)p1)));
    if ((u3 - p0)) {
        switch ((unsigned)((unsigned)w0 == (unsigned)((int)0x80000000u >= (int)(unsigned)d0)) & 7u) {
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                s0 = (int)-(unsigned)(0xdee2f30bu || (g1 | ~(0x80000000u << (a0[u1 & 3u] & 31u))));
            }
            do { if (--fuel == 0u) goto done;
                if (u3 == 7u) return ((unsigned)((int)i0 < (int)(unsigned)(w0 >> 29)) * (unsigned)(u1 < 0x26789cb3u));
                do { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((i0 ^ (unsigned)c0)) {
                            v0 = fuel;
                            u1 = u1 * 0x9e3779b1u + (unsigned)(unsigned char)(9u - *mp);
                            if (budget != 0u) { budget -= 1u; u1 = fn1((7u % ((unsigned)((int)1u >= (int)(unsigned)b0) | 1u)), (unsigned)(0x579fd6bdu < (unsigned)((short)u1 > (signed char)8u)), ((unsigned)((unsigned)d0 < (unsigned)x0) + 0x10000u)); }
                            b0 = (unsigned)(unsigned char)(unsigned)((int)~((unsigned)(w0 >> 29) - (0x10000u / ((garr[u2 & 7u] & 0xf63f88bcu) | 1u))) < (int)u1) != 0u;
                        }
                        if (u0) break;
                        l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)c0 == a0[i0 & 3u]) % ((i2 / ((garr[u2 & 7u] << (p1 & 31u)) | 1u)) | 1u)));
                        { unsigned t6; double z6; if (((9u ? u0 : (unsigned)(x0 >> 70))) & 1u) { t6 = (5u | (unsigned)((int)g1 < (int)(unsigned)d0)); z6 = (double)(((unsigned)(unsigned char)(6u ? 0x80000000u : (unsigned)e0)) & 255u); } if (((9u ? u0 : (unsigned)(x0 >> 70))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                            if (budget != 0u) { budget -= 1u; u3 = fn2((0xf71a67au | i2), (unsigned)((int)r0.y < (int)(unsigned)(u2 || 0xb7b8c6bcu)), ((unsigned)l0 * (unsigned)s0)); }
                            case 0u: ;
                            e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(i0 % (a0[i0 & 3u] | 1u)) & 1023u);
                            w0 ^= (unsigned long long)0xffffffffu << ((p1 << ((unsigned)(p2 == u2) & 31u)) & 63u);
                            f0 = f0 * 0.5f + (float)((((unsigned)l0 << ((unsigned)c1 & 31u)) << ((unsigned)((int)9u < (int)u0) & 31u)) & 255u);
                        }
                        r0.x = (unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)e0);
                    }
                    s0 = (int)(unsigned)(9u < (((unsigned)(x0 >> 70) + 0x17274661u) % (p0 | 1u)));
                    case 1u: ;
                    do { if (--fuel == 0u) goto done;
                        default: ;
                    } while (i2++ < 5u && (0x80000000u & (unsigned)d0));
                } while (i1++ < 6u && (0x56b1126u * garr[i1 & 7u]));
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)h1, -((unsigned)((int)(unsigned)h1 >= (int)0x4d47bf53u) % (i1 | 1u)), r0.x); }
                do { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)((0x80000000u >> ((unsigned)(w0 >> 29) & 31u)) || ((unsigned)(signed char)(0xffffffffu * (unsigned)(x0 >> 70)) ^ (unsigned)b0));
                    if ((a0[u1 & 3u] * r0.x)) {
                        x0 = x0 * 0x100000001b3ull + ((unsigned)((short)(unsigned)s0 > (signed char)0xafc896d3u) + (unsigned)s0);
                        break;
                        s0 = (int)9u;
                        if ((unsigned)h0) goto L0;
                        h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)h0 < (int)m0));
                    }
                    *mp = a0[i0 & 3u];
                } while (i1++ < 7u && ((unsigned)(w0 >> 29) % (i2 | 1u)));
                switch ((0xb7fcac76u >> (0xa8cda2bau & 31u)) & 7u) {
                    e0 = e0 * 0.5L + (long double)((0xde6f7f4cu ^ 3u) & 1023u);
                    d0 = d0 * 0.5 + (double)((((unsigned)((short)(unsigned)w0 > (signed char)5u) & (garr[u2 & 7u] ^ 0x10000u)) % ((unsigned)(w0 >> 29) | 1u)) & 1023u);
                    if ((m0 ? 0xffffffffu : r0.y)) {
                        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)u1 > (signed char)u3), (unsigned)((short)(unsigned)c1 > (signed char)0x680e8bfbu), (*q0 / ((unsigned)s1 | 1u))); }
                        { unsigned t7; double z7; if ((0xade10bd4u) & 1u) { t7 = (unsigned)((unsigned)(p0 && 2u) && 0xffffffffu); z7 = (double)(((0x10000u % (i1 | 1u))) & 255u); } if ((0xade10bd4u) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                            case 1u: ;
                            *q0 = fuel;
                            c1 = (signed char)((((unsigned)s0 >> ((unsigned)s0 & 31u)) & i2) - (unsigned)!(unsigned)((short)0x32491c9fu > (signed char)0xd80df51fu));
                            if (budget != 0u) { budget -= 1u; u2 = fn0((0x2971f500u + (p2 >> (0x80000000u & 31u))), (8u | (unsigned)(x0 >> 70)), (unsigned)((unsigned)d0 == (unsigned)s0)); }
                            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((unsigned)h1 < (unsigned)(u1 && p0)), (m0 & fuel), (unsigned)(8u == (unsigned)(*mp == u0))); }
                        }
                        if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)s1 / (0xffffffffu | 1u)), ((unsigned)b0 * i2), (unsigned)(short)((unsigned)w0 & (unsigned)(short)(unsigned)(i0 == 0x7929ab69u))); }
                    } else {
                        if (budget != 0u) { budget -= 1u; u3 = fn2(i2, 8u, (unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)(p0 || i0))); }
                        case 3u: ;
                        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)*mp > (signed char)*mp), ((unsigned)((int)0xf7b13fe3u >= (int)garr[u2 & 7u]) / (6u | 1u)), 2u); }
                        u3 ^= ((unsigned)l0 | (0u | (unsigned)(signed char)((unsigned)l0 << ((unsigned)d0 & 31u))));
                    }
                    if (0x7fffffffu) {
                        a0[0x10000u & 3u] = u2;
                        continue; (void)(v0);
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((short)(unsigned)w0 > (signed char)g0) / (0xc65664c8u | 1u)), r0.y, (unsigned)(i0 == (i0 >> ((unsigned)l0 & 31u)))); }
                    } else {
                        do { if (--fuel == 0u) goto done;
                            *q0 += ((unsigned)(8u < 0x2ce8da27u) ^ (unsigned)!(unsigned)(p2 && (unsigned)w0));
                            s0 = (int)garr[u2 & 7u];
                            goto L4;
                            c0 = (unsigned char)(((unsigned)c1 + a0[u1 & 3u]) + (unsigned)h1);
                            if ((unsigned)((int)(unsigned)s1 >= (int)r0.x)) break;
                            v0 = ((fuel % (0x30483449u | 1u)) >> ((unsigned)(x0 >> 70) & 31u));
                        } while (i1++ < 7u && (unsigned)((*q0 - a0[u1 & 3u]) < 8u));
                    }
                }
            } while (i0++ < 2u && ((r0.y & (unsigned)s1) >> (0x80000000u & 31u)));
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 5u: ;
                if (fuel < 8u) return (unsigned)((int)(0x10000u ^ (2u ^ 0x7fffffffu)) < (int)(unsigned)x0);
                w0 = w0 * 6364136223846793005ull + (((unsigned)(w0 >> 29) * ((unsigned)w0 / (v0 | 1u))) + (unsigned)s0);
                d0 = d0 * 0.5 + (double)(-(4u * (unsigned)(p1 < (unsigned)f0)) & 1023u);
            }
            r0.y ^= (fuel | (3u * m0));
            do { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(((unsigned)(short)(unsigned)(i2 < u2) ? (unsigned)x0 : -((unsigned)h1 | 2u)) & 1023u);
                break; (void)((((unsigned)w0 + (unsigned)x0) & u2));
                if ((unsigned)x0) {
                    w0 = w0 * 6364136223846793005ull + (0x7fffffffu & *mp);
                    { unsigned t8; double z8; if (((unsigned)(unsigned char)(unsigned)((unsigned)h0 || (unsigned)!((unsigned)b0 * 0xffffffffu))) & 1u) { t8 = (i0 << ((unsigned)s1 & 31u)); z8 = (double)(((unsigned)!(unsigned)((int)(unsigned)l0 < (int)i2)) & 255u); } if (((unsigned)(unsigned char)(unsigned)((unsigned)h0 || (unsigned)!((unsigned)b0 * 0xffffffffu))) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                        r0.y ^= -(unsigned)((int)(a0[i0 & 3u] >> (9u & 31u)) >= (int)-((unsigned)w0 << ((unsigned)(0xa9911f82u == r0.x) & 31u)));
                        h1 = (unsigned short)(h1 + (unsigned)((int)6u >= (int)1u));
                        if (u3 == 7u) return (unsigned)x0;
                        break; (void)((g1 | fuel));
                    }
                    r0.x = (unsigned)((unsigned)(((unsigned)b0 & (unsigned)s1) && u3) && (unsigned)b0);
                }
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)(signed char)(unsigned)((int)u0 >= (int)(unsigned)((unsigned)d0 == (unsigned)f0)) >= (int)(unsigned)c1));
                    *q0 += (((unsigned)d0 & (unsigned)(a0[i0 & 3u] && (unsigned)f0)) % (p2 | 1u));
                    *q0 = (unsigned)(u0 < v0);
                    if ((unsigned)(m0 == garr[u2 & 7u])) continue;
                    u2 = u2 * 0x9e3779b1u + (unsigned)(u1 || (0x10000u | (0x7d1285eeu - ((unsigned)c1 + (unsigned)h1))));
                }
                if (3u) {
                    x0 = x0 * 0x100000001b3ull + (unsigned)!(p0 & (g1 ^ garr[u2 & 7u]));
                }
                continue; (void)((g0 % ((7u << ((unsigned)h1 & 31u)) | 1u)));
            } while (i0++ < 6u && (*q0 >> (0xffffffffu & 31u)));
        }
        while (i0++ < 3u && (unsigned)(signed char)((unsigned)h1 + 0x2e20b6cdu)) { if (--fuel == 0u) goto done;
            u3 = u3 * 0x9e3779b1u + (9u ? i2 : garr[i1 & 7u]);
            m0 ^= ((unsigned)(w0 >> 29) & g1);
            f0 = f0 * 0.5f + (float)((unsigned)(-((unsigned)s1 % ((unsigned)b0 | 1u)) && ((unsigned)c1 + u0)) & 255u);
            break; (void)(0xffffffffu);
        }
        if (i2) {
            if ((unsigned)(signed char)((unsigned)s0 - (unsigned)((unsigned)s0 == (unsigned)f0))) goto L0;
            if ((u3 / ((unsigned)h1 | 1u))) {
                if (budget != 0u) { budget -= 1u; u2 = fn2(i0, (unsigned)(garr[i1 & 7u] == u3), ((unsigned)x0 ^ i0)); }
                h0 = (short)(unsigned)((unsigned)h0 == (0x7fffffffu << ((unsigned)h0 & 31u)));
                if (i1) {
                    goto L4;
                    goto done;
                    if ((unsigned)((int)garr[u2 & 7u] < (int)u0)) goto L3;
                    if (0x7fffffffu) goto L4;
                }
            }
            if ((unsigned)((short)a0[i0 & 3u] > (signed char)a0[u1 & 3u])) goto L1;
        }
        g1 += ((unsigned)((short)0xffffffffu > (signed char)m0) << ((unsigned)(0x10000u || (unsigned)s0) & 31u));
    } else {
        do { if (--fuel == 0u) goto done;
            if ((p0 << (u0 & 31u))) break;
            if (((unsigned)l0 ? 9u : (unsigned)h0)) break;
        } while (i0++ < 3u && (u1 / ((unsigned)l0 | 1u)));
    }
    u1 = ((unsigned)((int)7u >= (int)(unsigned)c1) | (fuel & u2));
    if (0x10000u) goto L3;
    q0 = &garr[((unsigned)(0xffffffffu == (unsigned)(x0 >> 70)) ^ (garr[u2 & 7u] + (0x80000000u ^ 0u))) & 7u];
    goto L4;
    goto L4;
    r0.x = u3;
    s0 = (int)(unsigned)(5u == m0);
    *q0 = (unsigned)((unsigned)w0 < (unsigned)e0);
    if ((unsigned)e0) {
        if ((unsigned)(6u == (unsigned)d0)) goto L4;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    d0 = d0 * 0.5 + (double)(u3 & 1023u);
    if ((unsigned)(a0[i0 & 3u] == ((unsigned)x0 & 0xb9f458f6u))) {
        u3 = ((unsigned)((int)(0xa59cb7f5u ^ (unsigned)h0) >= (int)(unsigned)c1) << (2u & 31u));
    }
    if (budget != 0u) { budget -= 1u; u3 = fn3(garr[i1 & 7u], (unsigned)((int)0xa0578ce0u < (int)0x59ed4b21u), (unsigned)((int)r0.x < (int)4u)); }
    g1 += (garr[i1 & 7u] / ((unsigned)(0x513cf18u < g1) | 1u));
    if (p2) {
        garr[(unsigned)(short)(unsigned)(garr[i1 & 7u] < 9u) & 7u] = (unsigned)((unsigned)((unsigned)h1 || 0x7fffffffu) || 0x10000u);
        if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)d0 + (u0 >> (u3 & 31u))), (unsigned)d0, ((unsigned)s1 >> ((unsigned)h1 & 31u))); }
        if (-(unsigned)((unsigned)h0 || i1)) {
            if ((u2 & (unsigned)c1)) goto L2;
            f0 = f0 * 0.5f + (float)(0xbb57d62u & 255u);
            if (budget != 0u) { budget -= 1u; u1 = fn0((8u << (i1 & 31u)), 2u, (u2 - (unsigned)((short)3u > (signed char)0u))); }
        } else {
            q0 = &garr[(unsigned)w0 & 7u];
            h1 = (unsigned short)(h1 + -(m0 / ((unsigned)w0 | 1u)));
        }
        do { if (--fuel == 0u) goto done;
            continue; (void)((unsigned)(0x8069f07au && -(i0 | (unsigned)b0)));
            while (i1++ < 7u && (unsigned)((unsigned)c1 < u2)) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)e0) & 255u);
                break; (void)(u2);
                if ((unsigned)((unsigned)h0 || (r0.x % (5u | 1u)))) break;
            }
            if ((unsigned)((short)(unsigned)b0 > (signed char)r0.x)) break;
            if (u3 == 7u) return (unsigned)(-(unsigned)((short)(r0.y << (0x1b8768c6u & 31u)) > (signed char)(unsigned)(p2 && u1)) && i1);
            *mp = 2u;
        } while (i0++ < 5u && ((0x80000000u >> (r0.y & 31u)) | u0));
        do { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + (unsigned)(short)(unsigned)(i2 && 8u));
        } while (i0++ < 4u && g1);
        g1 += ((garr[i1 & 7u] - ((unsigned)x0 << ((unsigned)w0 & 31u))) << ((v0 >> (0x9d2eeb89u & 31u)) & 31u));
    }
    goto L4;
    if ((unsigned)((unsigned)(0x928ad219u || i0) || 0x10000u)) goto L4;
    if ((unsigned)((int)r0.x >= (int)p1)) goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn1(u3, ((4u - (unsigned)s1) << (p1 & 31u)), 0xffffffffu); }
    w0 ^= (unsigned long long)(fuel + (unsigned)d0) << (((unsigned)((int)(unsigned)e0 < (int)(unsigned)h0) + 0xffffffffu) & 63u);
    if (u3) goto L2;
    switch (5u & 7u) {
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)c1, (unsigned)(w0 >> 29), garr[i1 & 7u]); }
            s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((int)0x7fffffffu >= (int)(unsigned)(7u && (unsigned)(p2 == (unsigned)h1))) < (int)(unsigned)x0));
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)(signed char)((unsigned)c0 * garr[u2 & 7u]);
            }
        } while (i0++ < 3u && (unsigned)w0);
        while (i0++ < 5u && (unsigned)(unsigned char)((unsigned)c1 * 0x4de9c5dau)) { if (--fuel == 0u) goto done;
            continue; (void)((unsigned)(r0.x < (unsigned)!((unsigned)s1 - 0x10000u)));
            case 0u: ;
            w0 ^= (unsigned long long)(unsigned)(7u == (unsigned)(w0 >> 29)) << (0x364c91abu & 63u);
            case 2u: ;
            if ((unsigned)b0) goto L2;
            if ((unsigned)((int)(unsigned)l0 < (int)0x83da4330u)) goto L1;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(signed char)(p0 + 0xffffffffu), (unsigned)c0, (0xffffffffu & (unsigned)((int)0x10000u < (int)garr[u2 & 7u]))); }
    }
    { unsigned t0; double z0; if ((u0) & 1u) { t0 = (7u * 8u); z0 = (double)(((0x7fffffffu + ((unsigned)x0 * u2))) & 255u); } if ((u0) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        goto L3;
        { unsigned t1; double z1; if (((unsigned)(short)(unsigned)((short)(3u | 6u) > (signed char)(unsigned)h1)) & 1u) { t1 = ((unsigned)e0 % (0xe75ce359u | 1u)); z1 = (double)(((m0 / ((unsigned)(i2 < 0x7fffffffu) | 1u))) & 255u); } if (((unsigned)(short)(unsigned)((short)(3u | 6u) > (signed char)(unsigned)h1)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            w0 = w0 * 6364136223846793005ull + (unsigned)(((9u ? 1u : (unsigned)x0) + (unsigned)c0) || (unsigned)w0);
            w0 = w0 * 6364136223846793005ull + (unsigned)(0x80000000u && 0x925522cdu);
            switch ((unsigned)((unsigned)((int)i1 >= (int)(unsigned)s0) || i1) & 7u) {
                if ((unsigned)c1) break;
                if ((unsigned)(short)(r0.x % ((unsigned)(unsigned char)(unsigned)(g0 < (unsigned)h1) | 1u))) {
                    case 0u: ;
                    if (0x9976083eu) break;
                    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        i0 = (0x10000u + u2) & 15u;
                    }
                }
                if ((unsigned)(short)(v0 << (i2 & 31u))) goto L4;
                if (1u) {
                    L0: if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (g1 ^ ((unsigned)(unsigned char)((unsigned)b0 ^ g1) ^ (v0 & (unsigned)l0)));
                    L1: if (--fuel == 0u) goto done;
                } else {
                    if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)((short)0xc5027328u > (signed char)(unsigned)w0) - (unsigned)f0), (unsigned)((int)0xffffffffu < (int)((unsigned)s1 | 0x10000u)), u1); }
                }
                c1 = (signed char)((unsigned)(fuel && (unsigned)b0) / ((0x8748f15fu - (unsigned)(w0 >> 29)) | 1u));
                break; (void)(((unsigned)(r0.x < u2) + (unsigned)h0));
            }
            L2: if (--fuel == 0u) goto done;
            *q0 = -(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)a0[u1 & 3u]);
            do { if (--fuel == 0u) goto done;
                v0 = 0xffffffffu;
                if ((v0 & u3)) break;
                e0 = e0 * 0.5L + (long double)(0x10000u & 1023u);
            } while (i0++ < 6u && 0xc8c1c2e2u);
        }
        if ((unsigned)(3u == 0x80000000u)) goto L0;
        L3: if (--fuel == 0u) goto done;
        if (-(u3 / (u1 | 1u))) goto L0;
    }
    while (~((unsigned)s0 << ((0x551cc9e9u >> ((unsigned)s0 & 31u)) & 31u))) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch ((8u / (garr[u2 & 7u] | 1u)) & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)(x0 >> 70) - ((unsigned)c1 << ((unsigned)e0 & 31u))), (unsigned)((short)(unsigned)((unsigned)x0 < u2) > (signed char)v0), (0x6c618808u / (((unsigned)s1 ^ r0.y) | 1u))); }
            }
            if ((0x10000u * 0xf8b0ff32u)) break;
            switch ((unsigned)((int)(0x90c8408du - (unsigned)f0) < (int)p0) & 7u) {
                case 6u: ;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (i2) break;
                    x0 = x0 * 0x100000001b3ull + ((unsigned)(signed char)(fuel | m0) + (unsigned)w0);
                    if (((unsigned)b0 / ((unsigned)d0 | 1u))) goto L0;
                    garr[(unsigned)((unsigned)d0 < (unsigned)(x0 >> 70)) & 7u] = ~(~(u1 + p1) << ((unsigned)b0 & 31u));
                    if ((unsigned)((int)(unsigned)(0xffffffffu < i0) < (int)(unsigned)f0)) goto L2;
                    do { if (--fuel == 0u) goto done;
                        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                            if ((unsigned)l0) break;
                            goto L2;
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn3(~(unsigned)((int)a0[i0 & 3u] < (int)(unsigned)((int)r0.x < (int)r0.x)), ((unsigned)d0 - (unsigned)((int)i1 >= (int)(unsigned)h0)), (*q0 ? (unsigned)x0 : (unsigned)h0)); }
                        L4: if (--fuel == 0u) goto done;
                    } while (i0++ < 3u && (unsigned)(unsigned char)(unsigned)(0xb60d9aa6u == i0));
                }
                do { if (--fuel == 0u) goto done;
                    b0 = (unsigned)((int)(unsigned)(m0 == 0x10000u) < (int)0x80000000u) != 0u;
                    case 4u: ;
                    if ((i2 << (0x27c61658u & 31u))) goto L2;
                    h0 = (short)((unsigned)b0 % ((0x7fffffffu | u1) | 1u));
                    if ((unsigned)h1) {
                        w0 = w0 * 6364136223846793005ull + (unsigned)(i0 < (unsigned)((unsigned)(w0 >> 29) || (*q0 * (unsigned)!(unsigned)((short)8u > (signed char)1u))));
                        case 0u: ;
                        case 2u: ;
                        if ((m0 + (unsigned)((short)7u > (signed char)m0))) goto done;
                    }
                    case 5u: ;
                } while (i2++ < 7u && (unsigned)((unsigned)w0 || 0x4b962760u));
                switch ((unsigned)h0 & 7u) {
                    c0 = (unsigned char)fuel;
                    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)c0, ((*q0 % (v0 | 1u)) - a0[u1 & 3u]), (unsigned)((int)(unsigned)(0x10000u || (unsigned)x0) >= (int)(unsigned)(x0 >> 70))); }
                }
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)b0 < (unsigned)c1) & 255u);
                u0 ^= (g1 % ((unsigned)((int)(unsigned)s0 >= (int)6u) | 1u));
            }
            q0 = &garr[-(0x51d618d8u + (unsigned)h1) & 7u];
            if ((*mp * (unsigned)s0)) {
                if ((unsigned)(x0 >> 70)) break;
            }
            s1 = (int)((unsigned)s1 + (-(unsigned)((int)(unsigned)f0 >= (int)0xd55d780fu) % ((p2 ? u1 : r0.x) | 1u)));
        }
        if ((0x80000000u | (unsigned)h0)) break;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((r0.x | (u0 % (p0 | 1u))), (unsigned)(unsigned char)(garr[i1 & 7u] & (unsigned)(g1 < a0[u1 & 3u])), (unsigned)(w0 >> 29)); }
    do { if (--fuel == 0u) goto done;
        switch ((unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)(u3 == fuel)) & 7u) {
            b0 = (unsigned)((int)r0.x < (int)(g1 & (unsigned)((int)~(unsigned)((int)(unsigned)c1 < (int)0x80000000u) >= (int)u3))) != 0u;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)0x9c06d9e1u;
                    }
                    w0 = w0 * 6364136223846793005ull + garr[i1 & 7u];
                    r0.x = (garr[u2 & 7u] / ((p1 % (0x80000000u | 1u)) | 1u));
                    b0 = ((unsigned)c0 % ((i2 % (0x7fffffffu | 1u)) | 1u)) != 0u;
                    w0 ^= (unsigned long long)(0x7fffffffu % (6u | 1u)) << (i0 & 63u);
                    case 2u: ;
                }
                i0 = 7u & 15u;
                r0.y ^= (unsigned)((short)(unsigned)((int)(unsigned)(i1 == p0) < (int)(unsigned)c1) > (signed char)u2);
            }
            s1 = (int)((unsigned)s1 + (5u | (0x39171116u ? 0xffffffffu : (unsigned)s1)));
            x0 = x0 * 0x100000001b3ull + (unsigned)d0;
            case 0u: ;
        }
        if ((unsigned)(0x572c10ffu < u1)) {
            if ((0x10000u / (i0 | 1u))) goto done;
            if ((unsigned)((0u / (r0.x | 1u)) || r0.y)) {
                do { if (--fuel == 0u) goto done;
                    *mp = p0;
                } while (i1++ < 2u && (9u ? p0 : 0x80000000u));
                s1 = (int)((unsigned)s1 + ((((unsigned)w0 % ((unsigned)e0 | 1u)) << (0x80000000u & 31u)) - (unsigned)(r0.y < i1)));
                *q0 += ((p2 - 0x7fffffffu) % (i2 | 1u));
            } else {
                if (budget != 0u) { budget -= 1u; u0 = fn3((u1 * garr[i1 & 7u]), v0, (unsigned)(((unsigned)b0 & p2) == (unsigned)s0)); }
                if ((unsigned)(short)((g0 - (unsigned)d0) / ((unsigned)c0 | 1u))) break;
                g0 = (unsigned)((short)m0 > (signed char)(r0.x | (unsigned)w0));
                d0 = d0 * 0.5 + (double)(((unsigned)b0 ^ 0xf81b3fd3u) & 1023u);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(0x7fffffffu == 0x58c39deu), garr[u2 & 7u], (6u | (unsigned)(p2 || (unsigned)s1))); }
            q0 = &garr[((unsigned)((unsigned)c1 < 0xffffffffu) >> ((unsigned)((unsigned)c1 || (unsigned)((int)(unsigned)h0 >= (int)*q0)) & 31u)) & 7u];
        } else {
            { unsigned t2; double z2; if (((unsigned)!((i1 / (p0 | 1u)) | g1)) & 1u) { t2 = (unsigned)(unsigned char)(unsigned)((unsigned)c0 == (unsigned)((int)(unsigned)d0 < (int)garr[i1 & 7u])); z2 = (double)(((9u & (unsigned)(signed char)(unsigned)(a0[i0 & 3u] == (unsigned)(w0 >> 29)))) & 255u); } if (((unsigned)!((i1 / (p0 | 1u)) | g1)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                if (m0) goto L2;
                if (budget != 0u) { budget -= 1u; u1 = fn2(g0, (unsigned)(0x7fffffffu == (unsigned)f0), i0); }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(w0 >> 29), (unsigned)((8u % (0x7fffffffu | 1u)) < u1), g0); }
                break; (void)((unsigned)((int)~(u1 & (unsigned)b0) >= (int)(unsigned)e0));
                s0 = (int)(unsigned)((u1 % ((unsigned)c0 | 1u)) || (unsigned)b0);
            }
            u3 ^= ((unsigned)e0 ? 0x10000u : 9u);
        }
        w0 = w0 * 6364136223846793005ull + (unsigned)(short)((unsigned)b0 & *q0);
    } while (i0++ < 2u && i2);
    if ((unsigned)((unsigned)!(g1 * i1) || (unsigned)w0)) goto L2;
    { unsigned t3; double z3; if (((unsigned)((short)0x80000000u > (signed char)u3)) & 1u) { t3 = ((unsigned)(w0 >> 29) - (0xffffffffu | r0.x)); z3 = (double)(((unsigned)f0) & 255u); } if (((unsigned)((short)0x80000000u > (signed char)u3)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((unsigned)l0 && fuel) == (4u - (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)h0))) & 1023u);
    }
    if ((unsigned)d0) {
        if (1u) goto L2;
        goto done;
        g1 += (*mp ? (unsigned)l0 : m0);
    }
    switch ((0x16292dcdu << (0x80000000u & 31u)) & 7u) {
        if ((unsigned)(*mp < 0x10000u)) goto done;
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (m0 & 0x80000000u);
            if (r0.y) continue;
            if ((unsigned)((unsigned)f0 == (unsigned)c0)) {
                if ((unsigned)c0) {
                    case 2u: ;
                } else {
                    h0 = (short)((unsigned)(signed char)(unsigned)((int)(unsigned)c0 < (int)g1) | garr[u2 & 7u]);
                }
            }
        }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)((unsigned)(x0 >> 70) && (unsigned)((short)(unsigned)d0 > (signed char)(unsigned)h1));
            switch ((m0 * (unsigned)l0) & 7u) {
                if ((unsigned)((short)(unsigned)!((unsigned)e0 + p1) > (signed char)r0.x)) goto done;
                case 3u: ;
                if (budget != 0u) { budget -= 1u; u3 = fn1((0x80000000u % (0xffffffffu | 1u)), (a0[i0 & 3u] % ((unsigned)w0 | 1u)), m0); }
            }
            h1 = (unsigned short)(h1 + (0x7fffffffu * (garr[u2 & 7u] - (unsigned)x0)));
            break; (void)(0xb74d9769u);
        }
        b0 = (~(unsigned)(v0 == (unsigned)((unsigned)h1 && 0xad30e394u)) | 1u) != 0u;
        if ((unsigned)((int)*mp >= (int)((unsigned)c1 | garr[i1 & 7u]))) {
            switch (a0[i0 & 3u] & 7u) {
                case 3u: ;
                if (0x80000000u) goto L2;
                u0 = u0 * 0x9e3779b1u + ((unsigned)(u3 < r0.y) + (unsigned)s0);
            }
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 6u: ;
                while (i1++ < 4u && (unsigned)e0) { if (--fuel == 0u) goto done;
                    g1 += ((unsigned)c1 - a0[i0 & 3u]);
                    case 3u: ;
                }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn3((4u ? 0xffffffffu : r0.y), ~(unsigned)((int)(unsigned)b0 >= (int)p2), (unsigned)(g0 && a0[i0 & 3u])); }
            default: ;
            s0 = (int)(unsigned)c0;
        }
        goto L4;
    }
    u2 = u2 * 0x9e3779b1u + (unsigned)((unsigned)s1 && r0.y);
    if (((unsigned)f0 / (v0 | 1u))) {
        { unsigned t4; double z4; if (((unsigned)(signed char)(((unsigned)l0 % ((unsigned)w0 | 1u)) + 0xe561c59au)) & 1u) { t4 = 5u; z4 = (double)(((unsigned)f0) & 255u); } if (((unsigned)(signed char)(((unsigned)l0 % ((unsigned)w0 | 1u)) + 0xe561c59au)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            switch ((unsigned)f0 & 7u) {
                *q0 += u2;
                switch (((3u * (unsigned)d0) * 0x64f224e2u) & 7u) {
                    q0 = &garr[(unsigned)((short)0x7fffffffu > (signed char)(unsigned)((u2 - i2) || 5u)) & 7u];
                    do { if (--fuel == 0u) goto done;
                        case 4u: ;
                    } while (i0++ < 5u && (unsigned)h1);
                    { unsigned t5; double z5; if (((0x80000000u ? fuel : *mp)) & 1u) { t5 = (unsigned)(short)((r0.x - (unsigned)w0) | (unsigned)c0); z5 = (double)(((unsigned)!(0x308313eau % (((unsigned)e0 / (u3 | 1u)) | 1u))) & 255u); } if (((0x80000000u ? fuel : *mp)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                        if (budget != 0u) { budget -= 1u; u2 = fn0((u2 & m0), (9u & (5u ^ 0x10000u)), (~(7u << (fuel & 31u)) ^ (unsigned)e0)); }
                        if (budget != 0u) { budget -= 1u; u1 = fn3(3u, r0.x, (unsigned)((unsigned)f0 || u3)); }
                        *q0 = (unsigned)((int)(unsigned)(fuel || (unsigned)c1) < (int)((r0.y | (unsigned)s1) / (u2 | 1u)));
                        case 0u: ;
                        case 5u: ;
                        while ((unsigned)s0) { if (--fuel == 0u) goto done;
                            f0 = f0 * 0.5f + (float)(u0 & 255u);
                        }
                    }
                    while (i0++ < 3u && (unsigned)(-(unsigned)(g1 && p1) && (unsigned)h0)) { if (--fuel == 0u) goto done;
                        break; (void)((*mp << (r0.y & 31u)));
                        case 1u: ;
                    }
                }
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)((unsigned)(p0 || ((unsigned)(0x80000000u < (unsigned)c1) + u0)) < 1u);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0(0xffffffffu, g0, (unsigned)((unsigned)(0x80000000u == (unsigned)x0) && 0x7fffffffu)); }
                *mp = (unsigned)((unsigned)h1 < (0x7fffffffu * (i0 / ((unsigned)s1 | 1u))));
                case 3u: ;
            }
            g1 += ((a0[u1 & 3u] >> (a0[i0 & 3u] & 31u)) ^ (unsigned)((short)9u > (signed char)u2));
        }
        f0 = f0 * 0.5f + (float)((4u ? 0x86cde790u : i1) & 255u);
        if ((unsigned)!(unsigned)(0xeaf06b4fu && (a0[u1 & 3u] + 2u))) goto L4;
        m0 ^= (unsigned)((int)((0x208c310bu - (unsigned)(u2 < 0u)) % (8u | 1u)) < (int)g1);
    }
    if (u0) goto L4;
    if (i1) {
        do { if (--fuel == 0u) goto done;
            if ((unsigned)h1) break;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (i1) break;
                if (budget != 0u) { budget -= 1u; u0 = fn3(p1, (((unsigned)f0 ^ 0x8772b794u) | 5u), ((unsigned)l0 >> (8u & 31u))); }
                u3 = u3 * 0x9e3779b1u + ((unsigned)(signed char)(unsigned)(u2 && (unsigned)l0) | garr[u2 & 7u]);
            }
            if (4u) {
                if (budget != 0u) { budget -= 1u; u2 = fn3(garr[u2 & 7u], (unsigned)((unsigned)c1 == p2), v0); }
            } else {
                if (((unsigned)(signed char)(garr[u2 & 7u] + *mp) >> (p1 & 31u))) break;
            }
            garr[((unsigned)f0 - u1) & 7u] = (0x10000u | (g0 * (unsigned)(((unsigned)f0 * (unsigned)c0) && (unsigned)(w0 >> 29))));
            u2 += ((0xbc08ad9cu % (garr[u2 & 7u] | 1u)) - (unsigned)(short)(0x7fffffffu ^ 7u));
            while (i1++ < 6u && ((unsigned)s1 & (unsigned)!(fuel * 0x503963a0u))) { if (--fuel == 0u) goto done;
                b0 = (unsigned)((int)(unsigned)(u3 < a0[i0 & 3u]) >= (int)((r0.y % ((unsigned)c1 | 1u)) % ((unsigned)(x0 >> 70) | 1u))) != 0u;
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)f0 ^ (unsigned)c1), (u2 - (unsigned)((unsigned)b0 < 3u)), (0x476ca304u * (unsigned)h0)); }
                if ((unsigned)((int)(unsigned)e0 < (int)(u0 + i0))) break;
                do { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((r0.x ^ 0x7fffffffu) % (garr[u2 & 7u] | 1u));
                    c0 = (unsigned char)(unsigned)((unsigned)(unsigned char)(i0 * (unsigned)f0) && (unsigned)s0);
                } while (i2++ < 6u && 0xffffffffu);
                f0 = f0 * 0.5f + (float)(8u & 255u);
                if ((0x80000000u / ((unsigned)(0x8bb80855u && (unsigned)d0) | 1u))) break;
            }
        } while (i0++ < 7u && (unsigned)(*mp && (unsigned)s1));
        if (0xffffffffu) goto L4;
        c0 = (unsigned char)(unsigned)(short)((unsigned)(0xcc013e23u == *mp) & ((unsigned)h1 >> (((unsigned)x0 / (0x8b4fc96u | 1u)) & 31u)));
    }
    if (((unsigned)h1 << (r0.y & 31u))) goto L2;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        q0 = &garr[((unsigned)(0x7fffffffu < (a0[i0 & 3u] | 0x7182f727u)) + 4u) & 7u];
    }
    if ((unsigned)s1) goto L2;
    if (fuel) goto L2;
    l0 = (long)((unsigned long)l0 + ((unsigned)b0 / (((unsigned)h0 % ((unsigned)h1 | 1u)) | 1u)));
    l0 = (long)((unsigned long)l0 + ((unsigned)(r0.y < a0[u1 & 3u]) & (unsigned)(short)(-(unsigned)(m0 < fuel) - *q0)));
    if (((unsigned)s1 ^ r0.y)) {
        if (r0.y) goto done;
    }
    goto L0;
    c1 = (signed char)(unsigned)((0xd08a728bu ? u2 : 0x54424d5au) || (unsigned)s0);
    if (u2) goto done;
    if ((((unsigned)h0 / (0x10000u | 1u)) % (0x80000000u | 1u))) {
        if (g1) goto L2;
        switch (0x8e461761u & 7u) {
            case 4u: ;
            if (budget != 0u) { budget -= 1u; u1 = fn3((g0 ^ (0x7246f217u >> (i2 & 31u))), (unsigned)((unsigned)c0 || i2), (unsigned)(0x10000u == (unsigned)e0)); }
            i1 = ((unsigned)(signed char)(i1 / (u0 | 1u)) + ((0u + (unsigned)b0) % (i2 | 1u))) & 15u;
            if ((unsigned)((int)a0[u1 & 3u] >= (int)0xffffffffu)) {
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(u2 || 0xc815ad9u), (9u + (unsigned)(w0 >> 29)), (0x80000000u - (r0.x * 3u))); }
                if ((3u << ((0x10000u % (u3 | 1u)) & 31u))) break;
                c0 = (unsigned char)(g1 + 6u);
            }
            u2 += r0.y;
        }
        while (((unsigned)l0 * r0.y)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn2(a0[u1 & 3u], (0x3ac213b9u % (u2 | 1u)), v0); }
            if ((-((unsigned)(x0 >> 70) | 0xb766ca78u) - m0)) {
                c0 = (unsigned char)(unsigned)(unsigned char)(v0 % (p1 | 1u));
                if (0xb2629a36u) goto L1;
                if ((p2 % (0x7fffffffu | 1u))) continue;
                if (a0[i0 & 3u]) goto L4;
                m0 ^= (unsigned)((int)*mp >= (int)((unsigned)(0x10000u || (unsigned)c0) % ((unsigned)((unsigned)e0 < 9u) | 1u)));
                if (a0[u1 & 3u]) goto L2;
            }
            i0 = 0x7fffffffu & 15u;
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 5u, 0x1d67627cu, 0xcfd29558u },
        { 12u, 0xce00426eu, 0x9206e89fu },
        { 9u, 0xd5ab095fu, 0xc0efe3dfu },
        { 6u, 0x1ff3744bu, 0xa5825f1eu },
        { 7u, 0x3131ac6eu, 0x13a8c456u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
