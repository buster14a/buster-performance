// test-ssa-source's program of seed 134000413 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xa851e1ebu, g1 = 0x574d2aa6u;
static unsigned garr[8] = { 0xc6267f10u, 0xf94389e5u, 0x1c210e34u, 0x8f96741cu, 0xa527573au, 0xecaaa0f0u, 0x9017f455u, 0xc27d9dd4u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    x0 = x0 * 0x100000001b3ull + (unsigned)(p0 && (unsigned)(unsigned char)(unsigned)((int)-(unsigned)((unsigned)f0 < 0x703e9b20u) < (int)(i2 & i0)));
    L0: if (--fuel == 0u) goto done;
    if ((unsigned)(unsigned char)((unsigned)(x0 >> 70) * g0)) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 += (unsigned)((unsigned)((unsigned)l0 < (unsigned)(w0 >> 29)) < p1);
            x0 = x0 * 0x100000001b3ull + i0;
        }
        L1: if (--fuel == 0u) goto done;
        if ((unsigned)h1) goto L1;
    }
    while (i0++ < 3u && (unsigned)(0x10000u == (unsigned)((int)4u >= (int)(unsigned)h0))) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t0; double z0; if ((0x7fffffffu) & 1u) { t0 = (0x5ea8e5e6u % (u3 | 1u)); z0 = (double)(((unsigned)c1) & 255u); } if ((0x7fffffffu) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                    L2: if (--fuel == 0u) goto done;
                    if (u3 == 7u) return ((unsigned)((unsigned)d0 || (unsigned)(unsigned char)(unsigned)(3u < (unsigned)h0)) / (3u | 1u));
                    f0 = f0 * 0.5f + (float)((unsigned)!(unsigned)(i0 || a0[i0 & 3u]) & 255u);
                    if ((garr[u2 & 7u] * u2)) break;
                    l0 = (long)((unsigned long)l0 + (9u ? (1u + *q0) : 4u));
                    c1 = (signed char)(-(unsigned)(i2 || (unsigned)((int)(unsigned)w0 < (int)0x10000u)) | p0);
                }
                L3: if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                switch (~((unsigned)(w0 >> 29) / ((unsigned)l0 | 1u)) & 7u) {
                    case 1u: ;
                    s1 = (int)((unsigned)s1 + (unsigned)!(*mp - (unsigned)x0));
                    if ((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)h1)) {
                        x0 = x0 * 0x100000001b3ull + ((unsigned)(0x80000000u == -(p1 | (unsigned)s1)) + (unsigned)(*mp == v0));
                        do { if (--fuel == 0u) goto done;
                            i2 = ((p0 + (unsigned)(w0 >> 29)) / ((unsigned)!(8u ? (unsigned)w0 : (unsigned)w0) | 1u)) & 15u;
                            case 2u: ;
                        } while (i0++ < 3u && 0x10000u);
                        { unsigned t1; double z1; if (((unsigned)((int)r0.y < (int)0x7fffffffu)) & 1u) { t1 = (unsigned)s1; z1 = (double)(((unsigned)((int)p0 < (int)r0.y)) & 255u); } if (((unsigned)((int)r0.y < (int)0x7fffffffu)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                            w0 ^= (unsigned long long)(unsigned)c0 << ((unsigned)l0 & 63u);
                            default: ;
                            case 6u: ;
                            if (0x80000000u) continue;
                        }
                    } else {
                        if (g1) goto done;
                    }
                    if ((unsigned)!(unsigned)(a0[u1 & 3u] || (p1 * g1))) {
                        if ((unsigned)(0xaffb7de8u || 0xd3b1484eu)) break;
                    } else {
                        do { if (--fuel == 0u) goto done;
                            case 0u: ;
                        } while (i0++ < 6u && (unsigned)((int)*mp >= (int)0x80000000u));
                        l0 = (long)((unsigned long)l0 + (unsigned)d0);
                        garr[(unsigned)((short)(unsigned)h1 > (signed char)0x10000u) & 7u] = ((0x584fbf75u ^ ((unsigned)x0 | 0u)) / ((unsigned)((int)5u >= (int)7u) | 1u));
                        x0 = x0 * 0x100000001b3ull + (unsigned)!(unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)((int)p2 < (int)r0.x) && r0.x) || (unsigned)(i2 && p0));
                    }
                    { unsigned t2; double z2; if ((((unsigned)s0 + (unsigned)s0)) & 1u) { t2 = (unsigned)(short)(0x532d16ffu * (unsigned)(short)(unsigned)(0xffffffffu || g1)); z2 = (double)((4u) & 255u); } if ((((unsigned)s0 + (unsigned)s0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                        *q0 += ((fuel ? 0xca5696fau : a0[i0 & 3u]) << ((unsigned)((int)(unsigned)l0 >= (int)4u) & 31u));
                        if ((0xb1d51569u & (unsigned)(x0 >> 70))) {
                            case 5u: ;
                        }
                        case 4u: ;
                        break;
                    }
                }
            }
            i2 = ((unsigned)((int)(a0[u1 & 3u] ^ 9u) < (int)u2) * g1) & 15u;
        }
        g1 += 2u;
        q0 = &garr[(unsigned)f0 & 7u];
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            a0[0u & 3u] = (unsigned)((short)(0xffffffffu % (u3 | 1u)) > (signed char)(unsigned)(0xffffffffu < 0x56aa16a2u));
            if (((unsigned)h1 | 0xba0041d7u)) goto L4;
            switch (g0 & 7u) {
                b0 = (v0 - (0xffffffffu << ((unsigned)c0 & 31u))) != 0u;
                if ((unsigned)((unsigned)((unsigned)x0 == r0.x) < g1)) break;
                u3 ^= (((unsigned)((int)(unsigned)w0 >= (int)a0[i0 & 3u]) % (m0 | 1u)) >> ((unsigned)(unsigned char)((unsigned)s0 << (u0 & 31u)) & 31u));
                if ((unsigned)((short)r0.y > (signed char)u1)) continue;
            }
            if ((unsigned)e0) break;
        }
    }
    if (8u) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)(x0 >> 70));
            r0.y ^= (*q0 >> (((unsigned)(unsigned char)(g1 / ((unsigned)w0 | 1u)) ^ 0x53f525d9u) & 31u));
            if (((unsigned)(fuel == u2) / ((unsigned)s0 | 1u))) {
                *mp = (unsigned)((int)0x7fffffffu < (int)fuel);
                do { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)d0);
                    break; (void)((0x82d2c26bu + (unsigned)c1));
                } while (i1++ < 6u && (unsigned)(garr[u2 & 7u] == 6u));
                u2 ^= ((unsigned)d0 / (0xffffffffu | 1u));
                w0 = w0 * 6364136223846793005ull + i2;
            }
            *q0 += ((fuel << (u0 & 31u)) - (unsigned)(short)(0xffffffffu ^ v0));
            if (fuel < 8u) return (unsigned)((int)(unsigned)(signed char)(5u >> ((0x10000u ? u1 : 0x4137dd43u) & 31u)) < (int)6u);
        }
        goto done;
        r0.y ^= (unsigned)(short)(p1 ^ garr[u2 & 7u]);
        do { if (--fuel == 0u) goto done;
            if (((unsigned)d0 | (unsigned)(w0 >> 29))) break;
        } while (i0++ < 6u && ((u1 >> (fuel & 31u)) - 7u));
    }
    u1 += ((unsigned)(unsigned char)(unsigned)(0xffffffffu == (unsigned)(9u == 1u)) * (unsigned)((int)g1 >= (int)g1));
    *mp = (unsigned)((short)0x10000u > (signed char)((unsigned)c0 << ((fuel ? (unsigned)h1 : r0.y) & 31u)));
    if ((7u % ((unsigned)c1 | 1u))) goto L3;
    w0 ^= (unsigned long long)0xffffffffu << ((unsigned)w0 & 63u);
    d0 = d0 * 0.5 + (double)((unsigned)((short)0x10000u > (signed char)(unsigned)((short)u1 > (signed char)(unsigned)((int)(unsigned)h0 < (int)i2))) & 1023u);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[(0x25077d79u ^ (unsigned)w0) & 3u] = (u3 | (unsigned)!(0x1d34a232u ^ 1u));
        l0 = (long)((unsigned long)l0 + (unsigned)(g1 && ((unsigned)((int)u1 >= (int)(0x8e9e5cc2u << ((unsigned)f0 & 31u))) | 0xe3229f12u)));
        continue; (void)(~((unsigned)w0 + (0u + 0x38c68af2u)));
    }
    m0 ^= ((unsigned)w0 * (unsigned)((unsigned)h0 < 2u));
    if (u3 == 7u) return (unsigned)(signed char)((unsigned)c0 / (0x80000000u | 1u));
    if (a0[i0 & 3u]) {
        if (r0.y) goto L4;
        { unsigned t3; double z3; if (((unsigned)(unsigned char)(unsigned)((int)((unsigned)d0 >> (i2 & 31u)) >= (int)(unsigned)s1)) & 1u) { t3 = (0x7fffffffu >> (3u & 31u)); z3 = (double)((r0.y) & 255u); } if (((unsigned)(unsigned char)(unsigned)((int)((unsigned)d0 >> (i2 & 31u)) >= (int)(unsigned)s1)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)s1 & (unsigned)d0) == ((unsigned)(x0 >> 70) / (0xa625a5dfu | 1u))) & 255u);
            if (g0) {
                b0 = (unsigned)((int)i2 < (int)p2) != 0u;
                if (u3 == 7u) return ((unsigned)(w0 >> 29) + u2);
            } else {
                x0 = x0 * 0x100000001b3ull + (unsigned)((((unsigned)h0 >> (garr[i1 & 7u] & 31u)) ^ 0x80000000u) && garr[u2 & 7u]);
                if (0x10000u) goto L1;
                w0 = w0 * 6364136223846793005ull + ((unsigned)(w0 >> 29) ^ p1);
                if (0x7fffffffu) goto L2;
            }
            u2 += (unsigned)(fuel == (i0 / (g0 | 1u)));
            u3 ^= ((unsigned)(x0 >> 70) + a0[u1 & 3u]);
        }
        if ((unsigned)e0) goto L2;
        if (0xf9bf6c25u) goto L4;
    }
    if (m0) goto L1;
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)0x7fffffffu < (int)((unsigned)d0 * 0x23e4018eu))) break;
    }
    if (~(unsigned)((int)i0 >= (int)(garr[i1 & 7u] + u0))) {
        u0 = ~((unsigned)d0 - (unsigned)((int)(unsigned)x0 < (int)(((unsigned)s1 % (5u | 1u)) - v0)));
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            *mp = 8u;
            if ((u3 + 0x8c2fbf41u)) break;
            r0.x = (unsigned)((short)fuel > (signed char)(0xbe2d8edfu >> ((i1 % (g1 | 1u)) & 31u)));
            r0.x = (7u << (p0 & 31u));
            if ((unsigned)((unsigned)(x0 >> 70) == i0)) break;
            s1 = (int)((unsigned)s1 + (unsigned)((short)u3 > (signed char)(unsigned)!(fuel ? (unsigned)f0 : *q0)));
        }
        goto L0;
    }
    c0 = (unsigned char)v0;
    *q0 += (0x598a842au & (p0 + ((u2 << (0x7fffffffu & 31u)) - (unsigned)e0)));
    if (i0) goto L3;
    if ((((unsigned)f0 | garr[i1 & 7u]) + 0x581c9e31u)) {
        if ((unsigned)x0) goto L3;
    } else {
        if ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)0x80000000u)) goto L4;
        g0 = (r0.y >> ((m0 ? (unsigned)s1 : (0x80000000u ^ 0x55fd04b2u)) & 31u));
        i0 = ~(fuel * (unsigned)!(unsigned)(r0.x == (unsigned)c1)) & 15u;
    }
    { unsigned t4; double z4; if (((unsigned)((int)p0 < (int)(unsigned)h1)) & 1u) { t4 = (0xcbdc2adau + i0); z4 = (double)(((unsigned)(r0.y || (unsigned)(unsigned char)(0x9d181ec2u ^ m0))) & 255u); } if (((unsigned)((int)p0 < (int)(unsigned)h1)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
        r0.x = ((unsigned)(short)(0x10000u / (g0 | 1u)) ^ (unsigned)c0);
        i2 = p2 & 15u;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch ((0x7fffffffu | (unsigned)c1) & 7u) {
        u2 = (r0.x >> (p1 & 31u));
        goto L0;
        goto L1;
        { unsigned t0; double z0; if ((0x98e94ba1u) & 1u) { t0 = (unsigned)((unsigned)b0 < p0); z0 = (double)((0x408c84f7u) & 255u); } if ((0x98e94ba1u) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            h0 = (short)((unsigned)s1 - g0);
            d0 = d0 * 0.5 + (double)(((2u ? v0 : ~(a0[u1 & 3u] | (unsigned)l0)) % (i2 | 1u)) & 1023u);
            w0 ^= (unsigned long long)(unsigned)h0 << ((a0[u1 & 3u] * (unsigned)((int)0x9538f82bu < (int)(unsigned)s1)) & 63u);
            { unsigned t1; double z1; if (((unsigned)((short)~(unsigned)(0xa2536ad7u && (unsigned)w0) > (signed char)u0)) & 1u) { t1 = (unsigned)c0; z1 = (double)(((unsigned)s0) & 255u); } if (((unsigned)((short)~(unsigned)(0xa2536ad7u && (unsigned)w0) > (signed char)u0)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                s0 = (int)(unsigned)(unsigned char)(unsigned)((u1 * r0.y) || (0x10000u | (unsigned)((short)1u > (signed char)0x7fffffffu)));
            }
            case 1u: ;
            do { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
                case 6u: ;
            } while (i0++ < 3u && (unsigned)l0);
        }
    }
    w0 = w0 * 6364136223846793005ull + ((i2 - i2) & 0xffffffffu);
    d0 = d0 * 0.5 + (double)(((unsigned)c1 % (fuel | 1u)) & 1023u);
    while (i0++ < 4u && (unsigned)(fuel == a0[u1 & 3u])) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            *mp = (4u ? 7u : (unsigned)s0);
            while (1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + ((unsigned)(((unsigned)f0 % (0xffffffffu | 1u)) || (unsigned)(unsigned char)(unsigned)((short)(unsigned)c1 > (signed char)0x80000000u)) - 4u));
                if ((0x52633725u - 6u)) {
                    if (budget != 0u) { budget -= 1u; u0 = fn0(a0[u1 & 3u], (unsigned)(signed char)(u3 | a0[i0 & 3u]), ((unsigned)s0 % ((p2 - *mp) | 1u))); }
                    b0 = (unsigned)(a0[i0 & 3u] < fuel) != 0u;
                    v0 = (unsigned)(short)((unsigned)h0 * (i2 / (0x7fffffffu | 1u)));
                    garr[(unsigned)(unsigned char)(unsigned)((int)3u < (int)0x10000u) & 7u] = (((0x80000000u << ((unsigned)h1 & 31u)) - (unsigned)((int)4u < (int)0x10000u)) + 0xa9b4e78eu);
                    h1 = (unsigned short)(h1 + (unsigned)(garr[u2 & 7u] == (1u ^ ((v0 / (0xffffffffu | 1u)) | g1))));
                }
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + ((unsigned)(w0 >> 29) ? u1 : (unsigned)((short)~((unsigned)s0 ^ r0.y) > (signed char)0x76389048u)));
                    for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)((m0 >> (((unsigned)w0 ^ 9u) & 31u)));
                        r0.y ^= (unsigned)((0xf9a73491u & g1) == m0);
                        if ((a0[i0 & 3u] - 0x80000000u)) break;
                        break; (void)((unsigned)(u1 < 0x3922961eu));
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(signed char)(unsigned)((1u ^ garr[u2 & 7u]) || (unsigned)h0), (g0 % ((unsigned)s1 | 1u)), ((unsigned)h0 << ((i0 >> (i2 & 31u)) & 31u))); }
                        for (;;) { if (--fuel == 0u) goto done;
                            *q0 = (5u ? (a0[i0 & 3u] / (garr[i1 & 7u] | 1u)) : (g0 ^ garr[u2 & 7u]));
                            r0.y ^= fuel;
                        }
                    }
                    if (((7u + u1) / ((unsigned)(w0 >> 29) | 1u))) break;
                    q0 = &garr[(unsigned)((int)(garr[u2 & 7u] / ((0x2e820797u ? (unsigned)s1 : 0x8124d91cu) | 1u)) >= (int)(unsigned)b0) & 7u];
                    if (budget != 0u) { budget -= 1u; u2 = fn0(8u, (unsigned)((unsigned)d0 == 0x7fffffffu), garr[i1 & 7u]); }
                    if (i0) {
                        L1: if (--fuel == 0u) goto done;
                    }
                }
                if (*q0) continue;
                goto L2;
            }
            while (i2++ < 5u && ((unsigned)((int)(unsigned)s1 >= (int)(unsigned)(w0 >> 29)) / (p1 | 1u))) { if (--fuel == 0u) goto done;
                { unsigned t2; double z2; if ((p0) & 1u) { t2 = (0x7fffffffu << ((unsigned)((unsigned)w0 || (unsigned)(x0 >> 70)) & 31u)); z2 = (double)(((unsigned)(w0 >> 29)) & 255u); } if ((p0) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    if ((unsigned)d0) break;
                    b0 = ((unsigned)c1 >> (p0 & 31u)) != 0u;
                    goto L2;
                    L2: if (--fuel == 0u) goto done;
                }
                do { if (--fuel == 0u) goto done;
                    continue; (void)((unsigned)(((unsigned)(w0 >> 29) << (0xd30b8f50u & 31u)) == a0[u1 & 3u]));
                    do { if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + (unsigned)((int)3u < (int)(u2 * (i2 - (unsigned)x0)));
                        goto L2;
                        e0 = e0 * 0.5L + (long double)((unsigned)((int)((unsigned)(x0 >> 70) % ((unsigned)l0 | 1u)) >= (int)(unsigned)b0) & 1023u);
                        h1 = (unsigned short)(h1 + (unsigned)(signed char)((unsigned)b0 / (-(unsigned)((unsigned)f0 || (unsigned)c1) | 1u)));
                    } while (i1++ < 7u && ((unsigned)h1 + (0x10000u << ((unsigned)s1 & 31u))));
                    g0 = (unsigned)((int)(unsigned)((short)0u > (signed char)(unsigned)e0) >= (int)i1);
                    c1 = (signed char)p0;
                    s0 = (int)((unsigned)((int)(4u - u2) < (int)r0.y) ? (unsigned)b0 : u1);
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)(0x6f7c5749u < (unsigned)(x0 >> 70))) break;
                    }
                } while (i0++ < 5u && (unsigned)(p1 || (unsigned)b0));
                d0 = d0 * 0.5 + (double)(0x10000u & 1023u);
                m0 ^= (unsigned)(short)(((unsigned)s1 ? (unsigned)b0 : 0x10000u) & (unsigned)(unsigned char)(unsigned)((short)(unsigned)s0 > (signed char)*mp));
                if ((0x6ffb8a08u + 8u)) break;
                L3: if (--fuel == 0u) goto done;
            }
        }
        i0 = (unsigned)((short)(v0 ? 0u : 0xffffffffu) > (signed char)u3) & 15u;
        { unsigned t3; double z3; if (((unsigned)(short)(0xa36e9690u >> (a0[u1 & 3u] & 31u))) & 1u) { t3 = ((unsigned)!(p0 ^ *q0) >> (r0.y & 31u)); z3 = (double)(((unsigned)((unsigned)h1 == (unsigned)f0)) & 255u); } if (((unsigned)(short)(0xa36e9690u >> (a0[u1 & 3u] & 31u))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            q0 = &garr[u0 & 7u];
            u1 = (unsigned)(signed char)(p1 ^ (unsigned)((int)u1 >= (int)0x10000u));
            l0 = (long)((unsigned long)l0 + 0xa6f079b8u);
        }
    }
    switch ((unsigned)((int)u2 < (int)(unsigned)h1) & 7u) {
        if (budget != 0u) { budget -= 1u; u3 = fn0((0x688b8c1du / (0x80000000u | 1u)), (unsigned)(u1 == (unsigned)(x0 >> 70)), (unsigned)((int)((unsigned)l0 - (unsigned)f0) < (int)8u)); }
        if (((unsigned)l0 | (unsigned)((int)(unsigned)c0 < (int)p1))) goto L1;
        u2 = u2 * 0x9e3779b1u + ((unsigned)((int)(1u ^ a0[i0 & 3u]) >= (int)u2) ? r0.x : (unsigned)h1);
        d0 = d0 * 0.5 + (double)(0xdfb21de8u & 1023u);
    }
    *q0 += (unsigned)((int)i1 < (int)(unsigned)f0);
    *q0 += -((u0 % (5u | 1u)) % (0x10000u | 1u));
    b0 = (unsigned)(unsigned char)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(fuel ? 0x10000u : p0)) != 0u;
    c1 = (signed char)(unsigned)!((unsigned)(x0 >> 70) % ((unsigned)(signed char)(6u >> (((unsigned)l0 % ((unsigned)(g0 == 0u) | 1u)) & 31u)) | 1u));
    x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)x0 && 0x7fffffffu);
    L4: if (--fuel == 0u) goto done;
    switch ((unsigned)(unsigned char)(0x32c57571u * a0[u1 & 3u]) & 7u) {
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)(0x7f38d215u || fuel)) {
                c0 = (unsigned char)(8u & (r0.x ^ ((unsigned)s0 | (unsigned)(u3 || p0))));
                case 7u: ;
                c0 = (unsigned char)(unsigned)e0;
                case 0u: ;
            } else {
                if ((i1 + (unsigned)(0x269ea6f8u < 0x7fffffffu))) break;
            }
        }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)(0x10000u - i1), (unsigned)((short)(unsigned)c1 > (signed char)0x7fffffffu), (unsigned)(7u || fuel)); }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)((unsigned)l0 || p1)), (unsigned)c0, (0x1fdaae7u << (9u & 31u))); }
        }
        case 4u: ;
        case 1u: ;
    }
    if ((i2 ^ (unsigned)(0u == a0[u1 & 3u]))) goto L2;
    if ((6u % ((unsigned)(x0 >> 70) | 1u))) goto L4;
    for (;;) { if (--fuel == 0u) goto done;
        *q0 = (0x4d72b356u % ((unsigned)((unsigned)d0 || (unsigned)((int)(unsigned)(a0[i0 & 3u] < 0u) < (int)0xffffffffu)) | 1u));
    }
    *q0 += (m0 >> (((unsigned)(x0 >> 70) * ((unsigned)w0 | g1)) & 31u));
    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(x0 >> 70) >> ((8u - (unsigned)c0) & 31u)), (unsigned)!(unsigned)(0x270d12c1u && p1), (unsigned)(0x10000u && 0xd46aac43u)); }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= (0xffffffffu | r0.x);
        { unsigned t4; double z4; if (((unsigned)(((unsigned)x0 * 0xffffffffu) == (unsigned)c1)) & 1u) { t4 = 3u; z4 = (double)(((0x7af159c1u >> (((unsigned)l0 | a0[u1 & 3u]) & 31u))) & 255u); } if (((unsigned)(((unsigned)x0 * 0xffffffffu) == (unsigned)c1)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            if ((unsigned)((int)(unsigned)l0 < (int)0x7589cf8cu)) {
                if ((unsigned)(4u < u0)) break;
                w0 ^= (unsigned long long)(unsigned)(u3 || 9u) << ((unsigned)((unsigned)e0 < 9u) & 63u);
                b0 = (unsigned)h0 != 0u;
                do { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (unsigned)((unsigned)((int)0x8c25e263u < (int)0x77550f7cu) && garr[i1 & 7u]);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((u2 * 2u) << ((unsigned)h0 & 31u)), g0, 4u); }
                    d0 = d0 * 0.5 + (double)(0x80000000u & 1023u);
                    if ((unsigned)(garr[i1 & 7u] || 9u)) goto done;
                } while (i1++ < 4u && 0x2e739fcdu);
                c1 = (signed char)(unsigned)s1;
            }
            if ((0xd35ad90fu / ((unsigned)h0 | 1u))) break;
            if (u3) break;
            if ((1u % (0x2d76f240u | 1u))) break;
            *mp = (r0.y >> ((unsigned)l0 & 31u));
            i1 = (unsigned)(short)(*mp - (unsigned)((int)0x37f8685bu < (int)i1)) & 15u;
        }
    }
    goto L1;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)h0, (unsigned)(p1 < 0xffffffffu), (unsigned)((short)0x80000000u > (signed char)(unsigned)(x0 >> 70))); }
    if ((((unsigned)e0 | a0[u1 & 3u]) % (v0 | 1u))) goto L2;
    while (i0++ < 5u && -(~(0x7fffffffu << ((unsigned)b0 & 31u)) | g0)) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + r0.y);
        *q0 = -(unsigned)(fuel || ((0xf40f19d1u * a0[i0 & 3u]) | (0x80000000u ^ (unsigned)(w0 >> 29))));
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)h0 + u3), ((unsigned)c0 - p1), p0); }
        if (budget != 0u) { budget -= 1u; u2 = fn0(i0, (unsigned)(m0 == 0x7fffffffu), (*q0 >> ((unsigned)((int)(unsigned)x0 >= (int)0x10000u) & 31u))); }
        while (i1++ < 3u && (garr[u2 & 7u] | i2)) { if (--fuel == 0u) goto done;
            switch ((((unsigned)c0 ^ r0.y) * (unsigned)(x0 >> 70)) & 7u) {
                q0 = &garr[(unsigned)c1 & 7u];
                b0 = (unsigned)!((unsigned)(signed char)(unsigned)((int)garr[u2 & 7u] < (int)(i0 - 0x7fffffffu)) % ((unsigned)(v0 < 0xffffffffu) | 1u)) != 0u;
                continue; (void)((a0[u1 & 3u] % (v0 | 1u)));
            }
            i2 = ((unsigned)(short)(unsigned)(garr[i1 & 7u] < (unsigned)((int)0xe52b44c3u >= (int)3u)) + (g1 + p0)) & 15u;
            e0 = e0 * 0.5L + (long double)((((unsigned)h1 >> ((unsigned)x0 & 31u)) / (a0[i0 & 3u] | 1u)) & 1023u);
        }
        if (4u) break;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *q0 += ((unsigned)((short)(unsigned)x0 > (signed char)(*mp - m0)) / (u1 | 1u));
    if (fuel < 8u) return ((unsigned)(unsigned char)(unsigned)((int)(unsigned)l0 >= (int)(unsigned)x0) / ((unsigned)h1 | 1u));
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(short)((unsigned)(x0 >> 70) ? (unsigned)f0 : 3u), (7u | v0), (0x862677beu & u0)); }
    while (i0++ < 2u && ~((unsigned)f0 / (7u | 1u))) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((6u - r0.x) & 1023u);
        s1 = (int)((unsigned)s1 + (unsigned)(short)(unsigned)(8u < (unsigned)f0));
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(((0x10000u & 0xeffdf7bu) << ((unsigned)b0 & 31u)));
            if ((unsigned)((unsigned)c1 < (unsigned)(v0 || (unsigned)(w0 >> 29)))) break;
            { unsigned t0; double z0; if (((unsigned)(w0 >> 29)) & 1u) { t0 = p2; z0 = (double)(((unsigned)((short)v0 > (signed char)(garr[u2 & 7u] & 0u))) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    L0: if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((0x10000u << (i0 & 31u)), (unsigned)!((unsigned)(0xa98619dbu < (unsigned)w0) ^ *q0), (3u / (u1 | 1u))); }
                }
                if ((0xffffffffu ? p0 : m0)) continue;
                if ((unsigned)(x0 >> 70)) break;
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(5u, r0.x, u2); }
                    L1: if (--fuel == 0u) goto done;
                }
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((fuel ^ p1), u1, (unsigned)(signed char)((unsigned)b0 * (unsigned)w0)); }
        }
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)m0 >= (int)garr[u2 & 7u]);
        if ((unsigned)(i2 == (unsigned)(x0 >> 70))) {
            { unsigned t1; double z1; if (((unsigned)d0) & 1u) { t1 = 0xa22b79a9u; z1 = (double)((((i1 >> (0x7fffffffu & 31u)) << (v0 & 31u))) & 255u); } if (((unsigned)d0) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn1(garr[u2 & 7u], (i0 * 0x80000000u), a0[u1 & 3u]); }
                    *q0 += -((9u & p2) % ((unsigned)b0 | 1u));
                    s0 = (int)(0x4f4acda6u - *mp);
                } while (i1++ < 5u && (unsigned)((unsigned)x0 || (unsigned)h0));
                while (v0) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((-(m0 | a0[u1 & 3u]) / (i1 | 1u)), garr[u2 & 7u], 2u); }
                        L2: if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)c1, 0x774035d4u, (u0 - i0)); }
                        r0.x = (unsigned)(0xe998f782u < (unsigned)c1);
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)0x7fffffffu < (int)(2u * 3u)), (0x7d99bf7eu * (unsigned)!(unsigned)(0x80000000u < *mp)), ((unsigned)(w0 >> 29) >> ((unsigned)f0 & 31u))); }
                    } while (i2++ < 4u && (i1 | (0x7fffffffu | (unsigned)c0)));
                }
                c0 = (unsigned char)(unsigned)((unsigned)((unsigned)h1 < 0xdca362a1u) || ((unsigned)f0 >> (5u & 31u)));
                c1 = (signed char)(unsigned)((unsigned)(m0 || (unsigned)((short)(unsigned)(short)(p2 + p1) > (signed char)(unsigned)c1)) && r0.x);
                u2 += (9u << ((unsigned)((int)(unsigned)d0 < (int)(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)b0)) & 31u));
                h0 = (short)(unsigned)w0;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0xc23e7e26u && 0x31719785u), garr[i1 & 7u], (2u | i2)); }
            h1 = (unsigned short)(h1 + p1);
            s1 = (int)((unsigned)s1 + (unsigned)x0);
        } else {
            if ((u2 ^ p1)) break;
            if (((unsigned)c0 | u1)) break;
            if (budget != 0u) { budget -= 1u; u1 = fn0((a0[i0 & 3u] << (0x10000u & 31u)), (unsigned)((short)g0 > (signed char)i0), (unsigned)(short)(g0 * (unsigned)((short)(unsigned)c1 > (signed char)p1))); }
            q0 = &garr[((unsigned)((int)m0 >= (int)(unsigned)e0) / (p0 | 1u)) & 7u];
        }
    }
    c1 = (signed char)((0xffffffffu & (unsigned)(x0 >> 70)) & (unsigned)((unsigned)((int)fuel < (int)p1) < (unsigned)s1));
    i1 = (8u ^ m0) & 15u;
    if ((unsigned)(short)(unsigned)((int)2u >= (int)1u)) {
        if (i0) goto L2;
        *q0 = (unsigned)c0;
        h1 = (unsigned short)(h1 + (unsigned)(((unsigned)s0 / (0xfa2f052u | 1u)) == g1));
        if (budget != 0u) { budget -= 1u; u0 = fn0(~(unsigned)((int)0x80000000u >= (int)(unsigned)(unsigned char)(unsigned)(garr[u2 & 7u] || u3)), (unsigned)((unsigned)(*q0 || (unsigned)s1) < (unsigned)h1), (p1 % (0xc3862465u | 1u))); }
    } else {
        q0 = &garr[0x5da8b602u & 7u];
        s0 = (int)(unsigned)(0x7fffffffu == (unsigned)((short)fuel > (signed char)(unsigned)(signed char)(v0 << (g1 & 31u))));
        if ((unsigned)(9u || (unsigned)((int)0x7fffffffu < (int)0xb6e2207bu))) goto L3;
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)a0[i0 & 3u] < (int)((unsigned)w0 | (unsigned)c0)), (unsigned)(signed char)(unsigned)(g0 == garr[i1 & 7u]), 8u); }
    }
    s1 = (int)((unsigned)s1 + -((unsigned)(v0 == r0.x) ^ -(garr[i1 & 7u] ^ (unsigned)c1)));
    c0 = (unsigned char)(unsigned)((short)(unsigned)(signed char)(unsigned)((unsigned)x0 == i1) > (signed char)((0xb609f8e5u + (unsigned)(w0 >> 29)) / ((unsigned)s1 | 1u)));
    *q0 += r0.y;
    m0 ^= (~(unsigned)(r0.y == (0u - (unsigned)((unsigned)c0 == u1))) * garr[i1 & 7u]);
    l0 = (long)((unsigned long)l0 + ((unsigned)(u3 < 0xd790fafeu) | (7u * ((unsigned)s1 - (unsigned)d0))));
    if ((0x10000u ^ (r0.x % (r0.y | 1u)))) {
        u1 = u1 * 0x9e3779b1u + (unsigned)(signed char)((unsigned)((int)(unsigned)(v0 || (unsigned)(x0 >> 70)) >= (int)(fuel & a0[i0 & 3u])) % (0x10000u | 1u));
    } else {
        garr[(unsigned)(u3 == 0x44ff398u) & 7u] = (((unsigned)h1 % ((unsigned)d0 | 1u)) / ((unsigned)((short)p0 > (signed char)(unsigned)x0) | 1u));
        if ((0x7fffffffu % ((unsigned)e0 | 1u))) goto L3;
        if (u3) goto L3;
        if (budget != 0u) { budget -= 1u; u2 = fn0((g0 / (u3 | 1u)), ((unsigned)(0xffffffffu && i1) >> ((unsigned)h0 & 31u)), (u2 + (unsigned)((unsigned)h1 == (unsigned)d0))); }
    }
    c1 = (signed char)(unsigned)((unsigned)(u3 || 0x7fffffffu) < (unsigned)((unsigned)s1 && (unsigned)(x0 >> 70)));
    u1 = (v0 >> ((unsigned)l0 & 31u));
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)h0, (5u ^ 3u), garr[i1 & 7u]); }
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(p0 || (unsigned)x0), (unsigned)((2u & (unsigned)(x0 >> 70)) && g0), (unsigned)((int)(unsigned)x0 < (int)((unsigned)f0 - 0x80000000u))); }
    if ((5u + 0x10000u)) goto L0;
    if (u3) goto L1;
    if ((unsigned)(a0[u1 & 3u] && (unsigned)s1)) {
        L3: if (--fuel == 0u) goto done;
        while (i0++ < 5u && ~((unsigned)f0 ^ *mp)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(a0[i0 & 3u] || i1), (unsigned)e0, (unsigned)((int)(a0[u1 & 3u] / (*mp | 1u)) < (int)p0)); }
            s0 = (int)(g1 % (0xdc1c2e06u | 1u));
            w0 ^= (unsigned long long)0xffffffffu << ((unsigned)((unsigned)e0 && ((unsigned)(i2 == 0u) | 2u)) & 63u);
        }
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)(0x244f4f86u || (unsigned)((int)(unsigned)h1 < (int)(unsigned)(w0 >> 29))) < (int)(unsigned)(garr[u2 & 7u] < (unsigned)h1));
        q0 = &garr[(unsigned)(signed char)(((unsigned)(unsigned char)(p2 % (-((unsigned)d0 + i0) | 1u)) + 0x9ea6c8a8u) | p0) & 7u];
    }
    if ((unsigned)f0) {
        if ((p1 - 0x10000u)) {
            L4: if (--fuel == 0u) goto done;
            u3 = (unsigned)(p2 || (unsigned)(((unsigned)(x0 >> 70) * (unsigned)(w0 >> 29)) && 0xbf57e6fcu));
            if (((unsigned)b0 << ((2u * 0xe93308d9u) & 31u))) goto L1;
            switch (p0 & 7u) {
                case 1u: ;
                do { if (--fuel == 0u) goto done;
                    r0.y ^= ((unsigned)(short)((unsigned)(w0 >> 29) & 0x10000u) >> ((4u % ((g1 - (unsigned)e0) | 1u)) & 31u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0(0x80000000u, (g0 | (unsigned)s0), (unsigned)((short)(unsigned)w0 > (signed char)(fuel / (r0.x | 1u)))); }
                    if ((unsigned)(0x10000u < (u3 >> (m0 & 31u)))) goto done;
                    case 4u: ;
                } while (i0++ < 4u && garr[i1 & 7u]);
                w0 ^= (unsigned long long)(unsigned)(w0 >> 29) << ((0x7fffffffu | (unsigned)((int)r0.y >= (int)~(unsigned)((short)(unsigned)h0 > (signed char)0x1ebcdfb9u))) & 63u);
                if (budget != 0u) { budget -= 1u; u1 = fn1(garr[i1 & 7u], (unsigned)(v0 && a0[u1 & 3u]), (unsigned)(0x97bfb85au < 4u)); }
            }
            if (((unsigned)(unsigned char)(unsigned)(r0.y || 8u) << (u1 & 31u))) goto L2;
        } else {
            h1 = (unsigned short)(h1 + (-(0x7fffffffu & u1) * (-((unsigned)d0 % ((unsigned)x0 | 1u)) / (r0.x | 1u))));
            s0 = (int)((unsigned)((unsigned)w0 < (unsigned)s0) | (unsigned)((int)i0 < (int)(unsigned)((int)(unsigned)d0 >= (int)9u)));
            a0[(6u + *mp) & 3u] = (p0 | (unsigned)(g0 < (unsigned)h1));
        }
        if (p2) {
            do { if (--fuel == 0u) goto done;
                *q0 += ((unsigned)(i1 < ((unsigned)s0 * p0)) / (u2 | 1u));
            } while (i0++ < 2u && (unsigned)l0);
            if (0xffffffffu) goto L1;
            if ((unsigned)((short)0x7e0a5dd6u > (signed char)p2)) goto L1;
        }
        c1 = (signed char)(unsigned)(p0 || 0x10000u);
        while (i0++ < 2u && *mp) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)(i1 & 255u);
            { unsigned t2; double z2; if (((unsigned)(4u || u0)) & 1u) { t2 = (u0 * (m0 - 0x80000000u)); z2 = (double)(((unsigned)(short)((unsigned)s1 - ((unsigned)f0 << ((unsigned)f0 & 31u)))) & 255u); } if (((unsigned)(4u || u0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                u1 = 0x1674e1eeu;
                if ((0x8dcf6389u & (unsigned)!(p2 >> (g0 & 31u)))) break;
            }
            if (garr[u2 & 7u]) break;
            if ((unsigned)l0) {
                u0 = (unsigned)((int)p0 < (int)r0.x);
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn1(*q0, (unsigned)(w0 >> 29), (unsigned)!((unsigned)c1 + (unsigned)((unsigned)f0 || 1u))); }
    } else {
        a0[0x7fffffffu & 3u] = (((unsigned)x0 ^ *q0) - (unsigned)((int)i2 >= (int)(unsigned)((int)0xffffffffu < (int)u3)));
        s1 = (int)((unsigned)s1 + (u2 * (unsigned)d0));
        *mp = (p2 / ((unsigned)(signed char)(unsigned)(p1 && a0[i0 & 3u]) | 1u));
    }
    goto L0;
    if (((unsigned)b0 % (0x10000u | 1u))) goto L1;
    while (i0++ < 3u && (unsigned)s1) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1((0x80000000u * (unsigned)(unsigned char)(1u * 0x932fb142u)), (unsigned)(0x10000u && *q0), (0xcc927280u ^ 0x1290bda7u)); }
        if (g1) break;
        s1 = (int)((unsigned)s1 + (unsigned)((0xd1868fa9u >> (u2 & 31u)) && ((g0 | 3u) % ((unsigned)h0 | 1u))));
        g0 = ((unsigned)h0 ? (unsigned)s0 : i2);
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        u2 += (unsigned)(p0 || -(unsigned)((unsigned)h0 < 5u));
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)c0 || 6u), (unsigned)(unsigned char)((unsigned)s0 ^ i2), (unsigned)((int)m0 < (int)fuel)); }
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (garr[u2 & 7u]) break;
            w0 = w0 * 6364136223846793005ull + (-(unsigned)((unsigned)f0 == u3) * a0[u1 & 3u]);
            *mp = (unsigned)((unsigned)h0 || p0);
            if (a0[i0 & 3u]) {
                continue; (void)((unsigned)(p2 || (unsigned)d0));
                if ((unsigned)((short)0x7fffffffu > (signed char)(0x80000000u ^ 0x80000000u))) break;
                if (((unsigned)(unsigned char)(unsigned)(p0 < (unsigned)c1) - i0)) continue;
                { unsigned t3; double z3; if (((i1 + 0xe84e00bu)) & 1u) { t3 = ((unsigned)(x0 >> 70) + (garr[i1 & 7u] | a0[u1 & 3u])); z3 = (double)(((unsigned)x0) & 255u); } if (((i1 + 0xe84e00bu)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                    if ((unsigned)(unsigned char)(*q0 << (9u & 31u))) break;
                    l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(-(0xe0e756e0u & (u2 % (g0 | 1u))) - a0[i0 & 3u])));
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)l0, ((unsigned)e0 & *mp), (unsigned)(signed char)(*q0 % (0xa6cf6656u | 1u))); }
                    for (;;) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)s1);
                        s0 = (int)((unsigned)((unsigned)(unsigned char)(0xffffffffu | 0xffffffffu) && 0xffffffffu) / (((unsigned)f0 + 0xffffffffu) | 1u));
                        switch (~(unsigned)((int)0xffffffffu >= (int)g0) & 7u) {
                            h1 = (unsigned short)(h1 + (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)s1));
                            w0 = w0 * 6364136223846793005ull + (i0 ^ ((unsigned)d0 % (-(unsigned)(0xce6ad5f4u && a0[u1 & 3u]) | 1u)));
                            u3 += (unsigned)(g1 || (unsigned)((unsigned)x0 || *q0));
                            case 2u: ;
                            f0 = f0 * 0.5f + (float)((p1 / (0x7e4229c4u | 1u)) & 255u);
                        }
                        break; (void)((unsigned)((short)0xffffffffu > (signed char)u0));
                        r0.x = ((g1 + 0x87a92f0bu) % (0x421b8ba1u | 1u));
                    }
                    break; (void)((unsigned)h0);
                    r0.y ^= ((unsigned)b0 - (garr[u2 & 7u] % (u3 | 1u)));
                }
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)s0);
                    f0 = f0 * 0.5f + (float)(((unsigned)(fuel && (unsigned)((int)i1 >= (int)(unsigned)s0)) ? (unsigned)f0 : u3) & 255u);
                    if ((unsigned)(u0 || p2)) goto L0;
                }
                x0 = x0 * 0x100000001b3ull + 7u;
            }
            v0 = ((u0 >> ((unsigned)(u3 || u1) & 31u)) - ~(unsigned)(0xffffffffu || 8u));
        }
        if ((unsigned)((int)m0 < (int)u3)) break;
    }
    if ((unsigned)c1) {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(u3 == (unsigned)((unsigned)w0 < (unsigned)h1))) break;
            q0 = &garr[((unsigned)c0 + (v0 * (unsigned)w0)) & 7u];
            if (0x10000u) break;
        }
        r0.y ^= ((unsigned)!(unsigned)((i1 | 0x37923c50u) || (unsigned)h0) | (g1 << (garr[i1 & 7u] & 31u)));
        while (i0++ < 6u && (((unsigned)(x0 >> 70) * *q0) * (unsigned)c1)) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)!(0x80000000u * fuel) || (unsigned)h1)) break;
            switch (u2 & 7u) {
                case 6u: ;
                if (budget != 0u) { budget -= 1u; u3 = fn1(0x7fffffffu, ((unsigned)((int)9u < (int)(unsigned)c1) / (i0 | 1u)), 0xffffffffu); }
                g1 += (unsigned)(g1 || ((unsigned)(w0 >> 29) / (*q0 | 1u)));
                u1 ^= (unsigned)((short)(unsigned)(u1 == (unsigned)(unsigned char)(unsigned)((unsigned)((unsigned)s1 < (unsigned)d0) && i0)) > (signed char)0xe18d1506u);
                g1 += ~(unsigned)((int)(unsigned)d0 >= (int)(unsigned)w0);
                w0 = w0 * 6364136223846793005ull + 2u;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1((*q0 ^ (unsigned)((int)u0 < (int)0xbab8c0b7u)), ((unsigned)c0 / (p2 | 1u)), ((unsigned)!(unsigned)(i1 && i2) | 0x80000000u)); }
            x0 = x0 * 0x100000001b3ull + (unsigned)((int)*mp < (int)u3);
            if (u2) break;
            if (u3 == 7u) return (unsigned)((unsigned)((int)*q0 < (int)(garr[i1 & 7u] >> ((0xce52202fu * (unsigned)s0) & 31u))) < p1);
        }
        goto L1;
        for (;;) { if (--fuel == 0u) goto done;
            if (7u) goto L4;
            f0 = f0 * 0.5f + (float)((1u | (unsigned)((int)(unsigned)s0 >= (int)(unsigned)((short)u2 > (signed char)0xffffffffu))) & 255u);
        }
    }
    if ((unsigned)(short)((unsigned)c0 % ((unsigned)(4u || 0x10000u) | 1u))) goto L3;
    while (i0++ < 3u && (unsigned)d0) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)c1 < (int)0x10000u)) break;
        if ((unsigned)(fuel && 2u)) break;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (garr[i1 & 7u] / (0x48458202u | 1u));
                s0 = (int)((unsigned)d0 + 0x29799ac4u);
            }
        }
        if ((unsigned)((short)0x713346f3u > (signed char)(i1 & i2))) {
            goto done;
            switch ((unsigned)(0x80000000u == (p0 << (v0 & 31u))) & 7u) {
                r0.x = (0x10000u / (((unsigned)d0 - (unsigned)c1) | 1u));
                h0 = (short)(unsigned)((unsigned)((int)u0 >= (int)m0) == (0x1223700u >> (r0.y & 31u)));
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)w0 > (signed char)u0);
                a0[(unsigned)((short)p0 > (signed char)0xd55d65dcu) & 3u] = ((unsigned)f0 - 4u);
                case 5u: ;
            }
            h0 = (short)(unsigned)((unsigned)c0 == (unsigned)c1);
        }
        if (0x7fffffffu) {
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                v0 = (unsigned)(6u && (unsigned)(u3 && (0x48dec7au ? 3u : i0)));
                garr[p2 & 7u] = ((unsigned)l0 << ((unsigned)(x0 >> 70) & 31u));
                while (i2++ < 6u && (unsigned)((int)7u < (int)(unsigned)(signed char)((unsigned)l0 / (i1 | 1u)))) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)(w0 >> 29));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(u3 == (unsigned)((int)i0 >= (int)(unsigned)h0)), (unsigned)(unsigned char)(u2 % (m0 | 1u)), a0[i0 & 3u]); }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((garr[u2 & 7u] / ((unsigned)h1 | 1u)) < (unsigned)h1), (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)u0), (unsigned)((0xce947214u % ((unsigned)(w0 >> 29) | 1u)) == (unsigned)c0)); }
                    if ((unsigned)d0) break;
                    s1 = (int)((unsigned)s1 + (unsigned)!(unsigned)((short)(unsigned)(garr[u2 & 7u] < (unsigned)s1) > (signed char)i0));
                    s0 = (int)(unsigned)(0x7fffffffu && ~((unsigned)c1 >> (i0 & 31u)));
                }
                r0.y ^= (unsigned)(unsigned char)(p1 % (~(0xfe6d42edu - (unsigned)(w0 >> 29)) | 1u));
                do { if (--fuel == 0u) goto done;
                    v0 = g0;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(g0 == (p0 & u3)), (unsigned)e0, (unsigned)w0); }
                    b0 = (((unsigned)w0 ? 0x27f549d5u : (unsigned)c1) / ((0x7b8c231au + garr[u2 & 7u]) | 1u)) != 0u;
                    if ((unsigned)((int)0x7fffffffu >= (int)(unsigned)c1)) goto L2;
                } while (i2++ < 4u && (unsigned)((unsigned)(w0 >> 29) && (unsigned)f0));
            }
            *mp = i0;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)((int)0x35ae7072u < (int)0x97b4c997u) << (u0 & 31u)), (0x2bec4dd0u % ((unsigned)e0 | 1u)), (unsigned)((short)(unsigned)((short)(unsigned)b0 > (signed char)0x80000000u) > (signed char)(unsigned)h0)); }
                g1 += (unsigned)h0;
                a0[i1 & 3u] = (unsigned)(p0 == u1);
            }
        }
    }
    r0.y ^= 0x10000u;
    if (budget != 0u) { budget -= 1u; u1 = fn0(p0, (0xffffffffu >> ((unsigned)s0 & 31u)), (0x80000000u << ((unsigned)e0 & 31u))); }
    { unsigned t4; double z4; if (((unsigned)(garr[u2 & 7u] == 0x469afe3cu)) & 1u) { t4 = (i0 % ((p2 * 6u) | 1u)); z4 = (double)((p1) & 255u); } if (((unsigned)(garr[u2 & 7u] == 0x469afe3cu)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
        if ((unsigned)((int)(unsigned)(0xa8ac05f0u == 0x80000000u) >= (int)a0[u1 & 3u])) {
            b0 = (unsigned)((int)r0.y < (int)(garr[u2 & 7u] % (g1 | 1u))) != 0u;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((0x80000000u - u1) | 2u), (unsigned)(i0 && 0xfe83b42du), (unsigned)((unsigned)(x0 >> 70) && 0xffffffffu)); }
            { unsigned t5; double z5; if (((u2 << ((unsigned)s1 & 31u))) & 1u) { t5 = ((unsigned)f0 * (unsigned)x0); z5 = (double)(((6u & 8u)) & 255u); } if (((u2 << ((unsigned)s1 & 31u))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                w0 ^= (unsigned long long)u0 << ((u1 ? (unsigned)(x0 >> 70) : 0x80000000u) & 63u);
                switch ((unsigned)x0 & 7u) {
                    case 1u: ;
                    case 0u: ;
                }
                if ((unsigned)((int)r0.x >= (int)*q0)) goto L1;
            }
            r0.x = (unsigned)!(((unsigned)h0 - (unsigned)l0) - 0xe9fdde7bu);
        }
        do { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)(0x7fffffffu == (unsigned)(signed char)((unsigned)s0 ^ p1));
            { unsigned t6; double z6; if (((unsigned)b0) & 1u) { t6 = ((unsigned)h1 / ((unsigned)(0xffffffffu < u2) | 1u)); z6 = (double)(((g0 + ~(0x5eae3151u ^ (unsigned)l0))) & 255u); } if (((unsigned)b0) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                g1 += (m0 << (0xffffffffu & 31u));
                if (r0.y) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0(0x7fffffffu, *mp, (unsigned)(0x49f128ddu || (fuel & *q0))); }
                    if (~((unsigned)((short)fuel > (signed char)u0) * a0[i0 & 3u])) break;
                    h1 = (unsigned short)(h1 + (unsigned)((r0.y + 0x80000000u) || r0.x));
                } else {
                    c0 = (unsigned char)(unsigned)((short)(unsigned)d0 > (signed char)(unsigned)(0xb963dc8eu && a0[u1 & 3u]));
                    m0 ^= (unsigned)(unsigned char)(a0[u1 & 3u] & (unsigned)((int)u0 < (int)(((unsigned)s0 * garr[u2 & 7u]) - (unsigned)l0)));
                    if (((unsigned)((unsigned)e0 == (unsigned)d0) << (0xea50e741u & 31u))) continue;
                    switch ((unsigned)(0x10000u < 0u) & 7u) {
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)s1, g0, (unsigned)(unsigned char)(p1 >> ((unsigned)((unsigned)s0 || i1) & 31u))); }
                        q0 = &garr[(unsigned)((0x10000u ^ (unsigned)(w0 >> 29)) || r0.y) & 7u];
                        c1 = (signed char)(unsigned)((short)i0 > (signed char)(unsigned)((unsigned)w0 && (unsigned)(w0 >> 29)));
                        g0 = (unsigned)(((unsigned)s1 * 0x10000u) < 0u);
                    }
                }
                *mp = (unsigned)(~((g0 * 0u) | v0) || (unsigned)(w0 >> 29));
                do { if (--fuel == 0u) goto done;
                    switch ((0xffffffffu >> (r0.y & 31u)) & 7u) {
                        if (budget != 0u) { budget -= 1u; u1 = fn0((0x7fffffffu / (0x80000000u | 1u)), (unsigned)(signed char)(unsigned)((int)0x4afb8e1u < (int)(0xffffffffu >> (*mp & 31u))), (unsigned)(u2 == fuel)); }
                        r0.x = (v0 ^ (unsigned)f0);
                        c0 = (unsigned char)((unsigned)(signed char)(unsigned)((int)(garr[i1 & 7u] ^ (unsigned)d0) >= (int)i2) ? 0xa3370e06u : *q0);
                    }
                    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)(p2 && 0xffffffffu) & 1023u);
                } while (i1++ < 5u && (unsigned)((short)4u > (signed char)(unsigned)w0));
            }
            e0 = e0 * 0.5L + (long double)(((unsigned)((int)(unsigned)(u2 == 0u) < (int)(5u << (9u & 31u))) << ((unsigned)c0 & 31u)) & 1023u);
        } while (i0++ < 7u && 0x7fffffffu);
        v0 = (unsigned)((int)(m0 ^ r0.x) < (int)0x776c367bu);
    }
    if (~(2u | 0u)) {
        *q0 += ((unsigned)((int)9u >= (int)garr[i1 & 7u]) + (unsigned)((unsigned)h0 && 7u));
        switch ((unsigned)((i1 & i2) < g1) & 7u) {
            if ((unsigned)((unsigned)h0 && (unsigned)(p0 || (unsigned)f0))) {
                u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)((int)*q0 >= (int)4u) && (unsigned)(signed char)((i0 * m0) << (i1 & 31u)));
                *q0 = (unsigned)(garr[i1 & 7u] == (0x4b49a1a2u << (*mp & 31u)));
                v0 = 0x4663b53du;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn1((0x80000000u >> ((unsigned)l0 & 31u)), (unsigned)w0, (unsigned)(0x9cf19343u == 9u)); }
            *mp = ((3u | (unsigned)d0) >> ((0xffffffffu & 7u) & 31u));
            if ((unsigned)((0x7256cb1cu - 5u) == fuel)) goto done;
        }
        x0 = x0 * 0x100000001b3ull + (garr[u2 & 7u] >> ((unsigned)(x0 >> 70) & 31u));
        if ((unsigned)(a0[u1 & 3u] == (unsigned)((short)(unsigned)e0 > (signed char)*q0))) goto done;
        if (fuel < 8u) return (0x10000u * (unsigned)((int)(unsigned)((short)(unsigned)s0 > (signed char)(unsigned)f0) < (int)6u));
    } else {
        w0 ^= (unsigned long long)*q0 << ((unsigned)(garr[i1 & 7u] < (u2 - (u0 - (unsigned)(0x44b8df30u && v0)))) & 63u);
    }
    x0 = x0 * 0x100000001b3ull + ((r0.x >> ((unsigned)(x0 >> 70) & 31u)) | (unsigned)e0);
    if (budget != 0u) { budget -= 1u; u0 = fn0(((0xffffffffu * *q0) >> (0xe370dd91u & 31u)), (0xe815d551u | (unsigned)(short)(unsigned)((short)0x42457ab0u > (signed char)9u)), (unsigned)((garr[u2 & 7u] % ((unsigned)(w0 >> 29) | 1u)) || 7u)); }
    do { if (--fuel == 0u) goto done;
        s0 = (int)(unsigned)((short)6u > (signed char)0u);
        u0 = u0 * 0x9e3779b1u + (~((unsigned)w0 / (0x1bdd06a1u | 1u)) ? m0 : -(0xffffffffu & 0x10000u));
        while (0x51c61b4fu) { if (--fuel == 0u) goto done;
            break; (void)((m0 % (garr[u2 & 7u] | 1u)));
            u3 = (g1 ? 0x80000000u : (2u - p0));
            u1 = u1 * 0x9e3779b1u + (((unsigned)w0 ^ (unsigned)h0) >> (0x10000u & 31u));
            x0 = x0 * 0x100000001b3ull + (unsigned)((0xd2e6b2f1u & 0xffffffffu) || 1u);
            u3 ^= ((unsigned)c1 - (g1 >> ((unsigned)(w0 >> 29) & 31u)));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1(*q0, (0u | g0), 2u); }
    } while (i0++ < 4u && (unsigned)!(unsigned)((int)(unsigned)x0 >= (int)u1));
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)(u1 << ((unsigned)((int)(unsigned)((int)0x80000000u >= (int)0x36cd8e1bu) >= (int)r0.x) & 31u));
        if (budget != 0u) { budget -= 1u; u3 = fn1(m0, ((unsigned)s0 - r0.x), 0x89964af9u); }
        { unsigned t7; double z7; if (((unsigned)(w0 >> 29)) & 1u) { t7 = a0[i0 & 3u]; z7 = (double)(((0x7fffffffu | (unsigned)h1)) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
            { unsigned t8; double z8; if (((unsigned)(i0 && 4u)) & 1u) { t8 = 0u; z8 = (double)(((r0.y % (garr[u2 & 7u] | 1u))) & 255u); } if (((unsigned)(i0 && 4u)) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)u2 < (int)(unsigned)((short)(unsigned)h1 > (signed char)(unsigned)l0))) break;
                    w0 = w0 * 6364136223846793005ull + fuel;
                    e0 = e0 * 0.5L + (long double)(((unsigned)h0 + 3u) & 1023u);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(signed char)(unsigned)((int)(unsigned)(m0 == 0x7fffffffu) >= (int)r0.x), (((unsigned)s0 % (m0 | 1u)) & (unsigned)d0), 0xffffffffu); }
                u3 += g1;
                *mp = (unsigned)((unsigned)((int)i1 < (int)v0) < ((unsigned)f0 | (0x4293b188u - (unsigned)w0)));
                r0.y ^= *mp;
            }
            s1 = (int)((unsigned)s1 + (v0 / (g0 | 1u)));
        }
        i0 = (0u / (((unsigned)c1 * i0) | 1u)) & 15u;
        if ((unsigned)((int)g0 >= (int)(unsigned)s1)) break;
    }
    do { if (--fuel == 0u) goto done;
        c1 = (signed char)((p0 - 0x10000u) | ((unsigned)c0 ? u1 : (unsigned)c1));
        if ((unsigned)((unsigned)(x0 >> 70) < i1)) {
            s1 = (int)((unsigned)s1 + (~(a0[i0 & 3u] ^ (i2 + (unsigned)(signed char)((unsigned)f0 % (i1 | 1u)))) % (0xabccc501u | 1u)));
            while (i1++ < 2u && (unsigned)(signed char)(unsigned)((short)(a0[i0 & 3u] | (unsigned)c1) > (signed char)p1)) { if (--fuel == 0u) goto done;
                u0 = u0 * 0x9e3779b1u + (6u ? v0 : (u3 * (unsigned)((unsigned)e0 < *mp)));
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)r0.y > (signed char)0x80000000u), (unsigned)(unsigned char)(unsigned)(fuel && 0x6a2ba2c7u), (unsigned)(0x6c70fb70u || garr[i1 & 7u])); }
            }
            garr[i1 & 7u] = (unsigned)(unsigned char)(fuel - 0x7fffffffu);
            goto L1;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)((int)4u >= (int)(unsigned)((int)1u >= (int)(v0 & 0x3ab5fa6eu)));
            }
        } else {
            break; (void)((unsigned)(short)(u0 * (unsigned)b0));
            while (i1++ < 2u && (unsigned)((unsigned)(x0 >> 70) < (unsigned)(0x80000000u == 3u))) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)b0, g1, (unsigned)((i2 + (unsigned)w0) || (unsigned)b0)); }
                    break; (void)((unsigned)((unsigned)e0 || 0x7fffffffu));
                } while (i2++ < 5u && (unsigned)((9u ^ 0x7fffffffu) && i2));
                { unsigned t9; double z9; if ((garr[i1 & 7u]) & 1u) { t9 = (unsigned)((unsigned)(0x637338d3u || garr[u2 & 7u]) && (unsigned)h0); z9 = (double)((0xffffffffu) & 255u); } if ((garr[i1 & 7u]) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
                    u1 += (unsigned)(u0 || (unsigned)c1);
                    *q0 = 0x274d9654u;
                    if ((u2 / (garr[i1 & 7u] | 1u))) continue;
                    u2 += ((unsigned)c0 >> ((g1 + (*mp ? p2 : (unsigned)c0)) & 31u));
                    break; (void)(((unsigned)x0 << ((unsigned)(unsigned char)((unsigned)x0 & (unsigned)x0) & 31u)));
                    b0 = ~(unsigned)(p1 || (unsigned)((short)(unsigned)d0 > (signed char)0xa52fb753u)) != 0u;
                }
            }
        }
        if ((unsigned)((short)m0 > (signed char)(i0 >> (i1 & 31u)))) goto L1;
        *q0 = (0xffffffffu * (unsigned)((int)garr[i1 & 7u] >= (int)3u));
    } while (i0++ < 5u && ((unsigned)h1 / ((unsigned)f0 | 1u)));
    while (i0++ < 5u && (unsigned)(0x199c9aadu == (unsigned)b0)) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                g1 += g0;
                h1 = (unsigned short)(h1 + (*q0 ^ (unsigned)(m0 < 0x99eb6185u)));
            }
            if (*q0) {
                h1 = (unsigned short)(h1 + (unsigned)((int)(0x82312353u >> (garr[u2 & 7u] & 31u)) < (int)(((unsigned)c1 >> ((unsigned)h0 & 31u)) ^ (unsigned)s0)));
                if (garr[i1 & 7u]) break;
                break; (void)((0x10000u % (0xffffffffu | 1u)));
                s0 = (int)(unsigned)((unsigned)(x0 >> 70) == 0x63e0cff5u);
                if (r0.y) break;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)(unsigned)(0x80000000u && (unsigned)c1), p0, (unsigned)h1); }
            if ((unsigned)(p2 == u2)) goto L4;
            if ((unsigned)h1) continue;
            g1 += (0u - garr[i1 & 7u]);
        }
        u0 = u0 * 0x9e3779b1u + ((*q0 + 0x80000000u) + (r0.x % ((6u << (0xd12c9145u & 31u)) | 1u)));
        e0 = e0 * 0.5L + (long double)((0x7fffffffu ^ (unsigned)((int)garr[i1 & 7u] < (int)p2)) & 1023u);
        switch ((unsigned)(7u == i1) & 7u) {
            d0 = d0 * 0.5 + (double)(8u & 1023u);
            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(i0 < g0) && (0x7fffffffu >> (p1 & 31u))));
            case 4u: ;
            r0.y ^= (unsigned)(v0 < (unsigned)h0);
        }
        u3 += (0x1b7a0c72u >> ((unsigned)(unsigned char)((i1 / ((unsigned)e0 | 1u)) << (0xffffffffu & 31u)) & 31u));
    }
    u0 = u0 * 0x9e3779b1u + (unsigned)h0;
    for (;;) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(*q0);
        }
    }
    if ((unsigned)((int)0xc8567792u < (int)u2)) goto L4;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(m0 < ((unsigned)(w0 >> 29) | (unsigned)(x0 >> 70)))) break;
        break; (void)(-(((unsigned)c0 << (u1 & 31u)) % (i2 | 1u)));
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)(0x9c63cd4cu ^ (unsigned)(p1 || (r0.y | 0xffffffffu)));
        }
        d0 = d0 * 0.5 + (double)((unsigned)(w0 >> 29) & 1023u);
        goto L4;
        if ((unsigned)l0) break;
    }
    if ((unsigned)(1u < (u3 + g1))) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((r0.y / ((unsigned)(0x7fffffffu < 9u) | 1u))) {
            c0 = (unsigned char)((0x80000000u ^ a0[u1 & 3u]) * (unsigned)!(garr[u2 & 7u] << ((r0.y >> (u3 & 31u)) & 31u)));
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)!((8u ^ a0[u1 & 3u]) / (v0 | 1u)), ((unsigned)f0 + *mp), ~(u2 | (unsigned)h1)); }
            d0 = d0 * 0.5 + (double)(((unsigned)b0 + (unsigned)((int)(unsigned)((int)(unsigned)l0 < (int)0x5b44844fu) >= (int)(unsigned)(unsigned char)(unsigned)(i1 && (unsigned)c0))) & 1023u);
            b0 = (unsigned)((int)0x7fffffffu >= (int)i2) != 0u;
        }
    }
    if ((unsigned)((int)(unsigned)(g1 || u2) >= (int)0xefa8acfdu)) goto L0;
    r0.x = ((*mp >> (u1 & 31u)) >> ((unsigned)!(0x41529ed9u ^ 7u) & 31u));
    f0 = f0 * 0.5f + (float)((unsigned)l0 & 255u);
    if ((unsigned)((int)a0[i0 & 3u] < (int)0xc96ed2u)) goto L2;
    if ((unsigned)(unsigned char)(unsigned)((unsigned)h1 == (unsigned)(7u && *q0))) goto L2;
    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)s0 - a0[i0 & 3u]), (unsigned)(unsigned char)(unsigned)(a0[i0 & 3u] && 4u), (unsigned)(signed char)(unsigned)((unsigned)((unsigned)f0 && 0x10000u) && 0xe462eaecu)); }
    if ((0x392034e5u * -(garr[u2 & 7u] - (unsigned)w0))) {
        L0: if (--fuel == 0u) goto done;
        q0 = &garr[(unsigned)!((unsigned)c0 | 0x77feda2au) & 7u];
        goto L4;
        if ((unsigned)f0) {
            if (budget != 0u) { budget -= 1u; u1 = fn2((8u & 6u), (fuel & (unsigned)s0), (unsigned)h0); }
            for (;;) { if (--fuel == 0u) goto done;
                c1 = (signed char)(unsigned)((int)((0x80000000u ^ 8u) - (unsigned)(unsigned char)(0x7fffffffu * 0xf1e33fe0u)) >= (int)(unsigned)h0);
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)d0, (unsigned)(0x7fffffffu && (unsigned)b0), u1); }
                if ((unsigned)(short)(unsigned)(i2 || (i2 >> (fuel & 31u)))) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)d0 && 5u), (6u & 0xa1a9e1efu), (unsigned)((int)0x78770a42u >= (int)g1)); }
                    if ((r0.x * p1)) continue;
                    if ((unsigned)c1) break;
                    d0 = d0 * 0.5 + (double)((0xffffffffu & (0x991d5b1au >> (8u & 31u))) & 1023u);
                    w0 ^= (unsigned long long)(p2 ^ 0x6f163ab3u) << (((unsigned)(w0 >> 29) + 0u) & 63u);
                    if ((unsigned)!(unsigned)(0x10000u < (unsigned)b0)) break;
                } else {
                    if ((unsigned)s0) break;
                    if ((*q0 % ((unsigned)b0 | 1u))) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)d0 << (g1 & 31u)), ((unsigned)f0 << ((unsigned)w0 & 31u)), (unsigned)!(((unsigned)h1 / (p1 | 1u)) + g0)); }
                }
            }
        } else {
            if (i2) {
                if (a0[i0 & 3u]) goto L4;
                if (u1) goto L1;
                u1 = u1 * 0x9e3779b1u + a0[u1 & 3u];
                if ((unsigned)(unsigned char)(unsigned)((unsigned)(0xbaed168cu < (unsigned)w0) == (unsigned)s1)) goto L3;
            }
        }
    } else {
        if (budget != 0u) { budget -= 1u; u0 = fn2((p2 | 0xffffffffu), ((p0 & (unsigned)s1) % (r0.x | 1u)), (p2 ? (unsigned)w0 : *q0)); }
        u2 = ((unsigned)((int)((unsigned)w0 << (m0 & 31u)) < (int)(unsigned)(w0 >> 29)) & (unsigned)(x0 >> 70));
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)h1, (0xffffffffu << (u1 & 31u)), (p0 & (p0 % (0x80000000u | 1u)))); }
        h1 = (unsigned short)(h1 + (unsigned)((short)0x80000000u > (signed char)fuel));
    }
    if (fuel < 8u) return (unsigned)((unsigned)((int)1u < (int)0xad4daa24u) || 9u);
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((short)r0.x > (signed char)(unsigned)((unsigned)b0 < (unsigned)l0)), r0.y, a0[i0 & 3u]); }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        q0 = &garr[((2u - (0x10000u & (unsigned)s0)) >> (p1 & 31u)) & 7u];
        g0 = (unsigned)l0;
        switch ((unsigned)(garr[u2 & 7u] < u3) & 7u) {
            L1: if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(a0[u1 & 3u] & 1023u);
            { unsigned t0; double z0; if (((p0 << (g0 & 31u))) & 1u) { t0 = (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)(a0[i0 & 3u] || 4u)); z0 = (double)(((0u & (u3 - i2))) & 255u); } if (((p0 << (g0 & 31u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)((short)(unsigned)f0 > (signed char)3u) && r0.x), (unsigned)l0, (unsigned)(i1 || (unsigned)(x0 >> 70))); }
                    if (u1) goto L3;
                    s0 = (int)(3u / (0x7fffffffu | 1u));
                }
                w0 = w0 * 6364136223846793005ull + (unsigned)!((m0 ^ p0) | 0x80000000u);
                do { if (--fuel == 0u) goto done;
                    if ((r0.y ? p0 : 0x1dc9f9e8u)) break;
                } while (i1++ < 7u && (unsigned)(g1 == 0xe41c799cu));
                switch ((u1 & ((unsigned)s1 >> (r0.x & 31u))) & 7u) {
                    g1 += (0x80000000u & (unsigned)h0);
                    case 5u: ;
                    break; (void)((unsigned)(i2 && i0));
                    *q0 = r0.y;
                }
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((p0 * u1));
                    if ((unsigned)b0) goto L2;
                    case 7u: ;
                }
                if (0x10000u) continue;
            }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((0x10000u % (((unsigned)d0 << ((unsigned)l0 & 31u)) | 1u))) {
                    while ((garr[u2 & 7u] * 0xa9d7b74u)) { if (--fuel == 0u) goto done;
                        switch (((unsigned)((int)0x7df56e77u < (int)a0[u1 & 3u]) ^ u0) & 7u) {
                            u3 ^= (unsigned)(signed char)(0x2b273389u + 4u);
                            c0 = (unsigned char)((unsigned)s0 & u2);
                            *q0 += (0x80000000u % ((unsigned)((unsigned)((int)i2 < (int)6u) == (*q0 ^ 0x10000u)) | 1u));
                            c1 = (signed char)(unsigned)(((unsigned)x0 - (unsigned)((unsigned)s0 == g0)) < (unsigned)e0);
                        }
                        u1 += (unsigned)((unsigned)s1 && i2);
                        w0 ^= (unsigned long long)(*q0 - (unsigned)s0) << ((unsigned)e0 & 63u);
                        if ((4u & a0[i0 & 3u])) continue;
                        if (v0) goto L1;
                    }
                    v0 = (0x179c83bcu + (0x20bcbaacu & 0x10000u));
                    x0 = x0 * 0x100000001b3ull + ((unsigned)s0 ^ ((unsigned)h0 ? 5u : (unsigned)(w0 >> 29)));
                    q0 = &garr[((unsigned)w0 / (3u | 1u)) & 7u];
                    for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(1u == (unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)l0)), ((unsigned)((unsigned)e0 && (unsigned)h1) | 4u), a0[i0 & 3u]); }
                        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(u1 / ((0x80000000u | r0.x) | 1u)) & 1023u);
                        r0.x = v0;
                    }
                } else {
                    x0 = x0 * 0x100000001b3ull + ((unsigned)f0 & ((unsigned)h0 >> ((unsigned)((int)(unsigned)c1 >= (int)((unsigned)(w0 >> 29) | 6u)) & 31u)));
                }
                continue; (void)(0u);
            }
            do { if (--fuel == 0u) goto done;
                goto L0;
                L2: if (--fuel == 0u) goto done;
                break; (void)((unsigned)((int)0x32a2672eu < (int)5u));
            } while (i1++ < 7u && (*q0 / (0xa68d61acu | 1u)));
        }
        *q0 = (unsigned)(0xc2d6b9cbu && u1);
        if (((0x7fffffffu % (0x52da6df2u | 1u)) | i2)) {
            g0 = (0x1f9ff379u ^ ((0x80000000u >> ((unsigned)w0 & 31u)) * v0));
        }
        L3: if (--fuel == 0u) goto done;
    }
    goto L2;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        q0 = &garr[(unsigned)h0 & 7u];
        goto L3;
        s1 = (int)((unsigned)s1 + garr[i1 & 7u]);
        if (0xffffffffu) break;
        u3 = (unsigned)c0;
        if (2u) break;
    }
    L4: if (--fuel == 0u) goto done;
    if (0x7a389f55u) {
        goto done;
        h1 = (unsigned short)(h1 + ((unsigned)((int)((unsigned)l0 / ((unsigned)w0 | 1u)) < (int)(unsigned)h1) << (0x80000000u & 31u)));
        if (0x80000000u) {
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((0x62552748u * garr[u2 & 7u]) && fuel)) break;
                s0 = (int)((unsigned)((int)(unsigned)d0 >= (int)(unsigned)c1) << ((u0 / ((unsigned)s1 | 1u)) & 31u));
                w0 = w0 * 6364136223846793005ull + (0x80000000u * (unsigned)(((unsigned)h1 | r0.y) < -(unsigned)(u1 < 0x80000000u)));
            }
            u1 ^= ((unsigned)((int)r0.x < (int)(unsigned)((short)(unsigned)h0 > (signed char)fuel)) >> ((unsigned)((int)g0 < (int)v0) & 31u));
        } else {
            if ((~(3u ^ 0x72904af2u) ^ a0[i0 & 3u])) goto L1;
            h1 = (unsigned short)(h1 + (garr[i1 & 7u] % ((unsigned)!(unsigned)(7u < 0x2cb0d826u) | 1u)));
        }
        do { if (--fuel == 0u) goto done;
            *q0 += (unsigned)(fuel && r0.x);
            d0 = d0 * 0.5 + (double)((0x961ec7fcu - (fuel << (u0 & 31u))) & 1023u);
            if (budget != 0u) { budget -= 1u; u0 = fn0((m0 | (unsigned)(signed char)(u3 << (*mp & 31u))), (g0 >> ((0xc8f0b4du ^ a0[i0 & 3u]) & 31u)), 0x9f849441u); }
            i1 = (unsigned)!(u1 % (((1u ? (unsigned)d0 : 0x80000000u) << (u0 & 31u)) | 1u)) & 15u;
            if ((unsigned)b0) break;
            if (i2) break;
        } while (i0++ < 2u && (i1 >> ((unsigned)h1 & 31u)));
    }
    *q0 = (unsigned)((unsigned)(w0 >> 29) && g1);
    if (0x109639d5u) {
        if ((unsigned)d0) goto L3;
        goto L3;
        if (i2) goto done;
        if ((unsigned)((unsigned)l0 || i0)) goto L1;
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)e0 & (unsigned)c1), (unsigned)(*mp && (g0 & p1)), (unsigned)((int)(unsigned)f0 < (int)u2)); }
    } else {
        a0[(unsigned)((unsigned)s1 || r0.x) & 3u] = (unsigned)((int)(unsigned)(*q0 && r0.x) < (int)(unsigned)(short)(unsigned)(((unsigned)h1 << (0x10000u & 31u)) || g1));
    }
    if (u0) {
        *q0 += (0x506dd66au << (0u & 31u));
        if ((unsigned)h0) {
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (-(unsigned)((int)(unsigned)s1 >= (int)a0[i0 & 3u]) - (m0 ^ (garr[i1 & 7u] << (i1 & 31u))));
                c0 = (unsigned char)(((unsigned)h0 - 6u) - (unsigned)((int)(u3 & u2) >= (int)m0));
                h0 = (short)u1;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((garr[i1 & 7u] - (*q0 % ((unsigned)s0 | 1u)))) goto L2;
                    if (fuel < 8u) return (unsigned)((int)(unsigned)((unsigned)l0 == (i0 + (unsigned)l0)) < (int)(unsigned)((unsigned)c0 && r0.x));
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)(unsigned)((int)a0[u1 & 3u] < (int)fuel) >= (int)r0.x), 0x1f7b6fc4u, 0x2b86bb72u); }
                }
                h1 = (unsigned short)(h1 + (((unsigned)l0 + g1) + 9u));
                if (0xd6752165u) {
                    for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((0x10000u << (-(unsigned)((int)(unsigned)l0 >= (int)0xffffffffu) & 31u))) goto L1;
                        u2 = ((m0 ^ (0x9ca5c2c0u & p2)) + (unsigned)((short)i0 > (signed char)p1));
                    }
                    w0 ^= (unsigned long long)(2u % (m0 | 1u)) << ((((0x10000u & (unsigned)h0) & 7u) * p1) & 63u);
                    if ((unsigned)((unsigned)e0 && r0.y)) break;
                    for (;;) { if (--fuel == 0u) goto done;
                        s0 = (int)(unsigned)((int)(unsigned)c1 < (int)(unsigned)(unsigned char)((unsigned)(unsigned char)((unsigned)d0 + 1u) * (unsigned)(7u && p2)));
                        c0 = (unsigned char)g1;
                        r0.y ^= ((unsigned)s1 - i0);
                    }
                }
            }
            m0 ^= (unsigned)((int)(unsigned)c1 < (int)(*mp << ((p0 | i2) & 31u)));
            goto L1;
            for (;;) { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)((unsigned)((int)p1 < (int)r0.y) || (0u + 6u));
            }
        } else {
            if ((unsigned)e0) goto L2;
            u1 += (unsigned)!((unsigned)b0 % ((0x63eec1c2u + ((unsigned)c0 | (unsigned)w0)) | 1u));
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)h0 < ((unsigned)(w0 >> 29) & (unsigned)(0x58523fd7u || 0x80000000u))) & 255u);
            a0[(0x41f6489au + 0xffffffffu) & 3u] = (unsigned)(signed char)(~(((5u - 0x10000u) - p2) << (m0 & 31u)) - p0);
        }
        s1 = (int)((unsigned)s1 + *mp);
        u3 = (unsigned)((int)(unsigned)((int)0xd9dd9f4u >= (int)(unsigned)c1) < (int)p0);
    }
    while ((r0.x & (unsigned)c1)) { if (--fuel == 0u) goto done;
        break; (void)((0x193c319bu / (m0 | 1u)));
        if (garr[u2 & 7u]) {
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn2((4u ^ (unsigned)c0), (unsigned)((int)i1 >= (int)u2), ((unsigned)!(unsigned)(g0 == 0xffffffffu) / (7u | 1u))); }
                garr[(unsigned)(5u < *mp) & 7u] = (unsigned)((int)8u >= (int)(unsigned)(unsigned char)(p0 - p2));
                if ((unsigned)s1) break;
                g0 = (0x6fc15a41u & (unsigned)((short)(unsigned)((int)(unsigned)s1 < (int)3u) > (signed char)(unsigned)(short)(i2 >> (1u & 31u))));
                do { if (--fuel == 0u) goto done;
                    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((0x2e9f28fbu << (p2 & 31u)), (0xffffffffu | (unsigned)(signed char)(unsigned)((short)5u > (signed char)g1)), u2); }
                        c0 = (unsigned char)(unsigned)(((unsigned)w0 << ((unsigned)b0 & 31u)) && 6u);
                        if (0x10000u) break;
                        l0 = (long)((unsigned long)l0 + (unsigned)(short)((unsigned)s1 / (((unsigned)h1 ? 0x80000000u : p0) | 1u)));
                        if (((unsigned)s1 ? p2 : r0.y)) goto L3;
                    }
                    if ((unsigned)((short)r0.x > (signed char)((unsigned)h1 / (i2 | 1u)))) break;
                } while (i2++ < 4u && (unsigned)c1);
            } while (i1++ < 4u && ((unsigned)l0 >> (0xffffffffu & 31u)));
            c1 = (signed char)u1;
        }
        r0.y ^= (unsigned)l0;
        u2 = u2 * 0x9e3779b1u + (unsigned)(~(i1 & g1) || (unsigned)((int)(unsigned)w0 < (int)i0));
        if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)((int)0xffffffffu < (int)g0) * (unsigned)f0), ((9u / (3u | 1u)) * 1u), ~(unsigned)((short)garr[i1 & 7u] > (signed char)i1)); }
        q0 = &garr[((unsigned)s1 ^ (fuel - 0x10000u)) & 7u];
    }
    u3 = u3 * 0x9e3779b1u + (unsigned)((*q0 + 5u) || ((unsigned)(w0 >> 29) | (unsigned)(unsigned char)(unsigned)(p2 && *q0)));
    l0 = (long)((unsigned long)l0 + (i2 ^ p1));
    if (garr[u2 & 7u]) goto L4;
    l0 = (long)((unsigned long)l0 + (unsigned)((int)7u >= (int)(unsigned)s0));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    switch (3u & 7u) {
        case 7u: ;
        if ((unsigned)((short)i0 > (signed char)i0)) {
            for (;;) { if (--fuel == 0u) goto done;
                while (i1++ < 5u && (8u >> ((u0 + u1) & 31u))) { if (--fuel == 0u) goto done;
                    case 1u: ;
                    for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        continue; (void)((0x2e88c71fu * (unsigned)(4u == 0xead223b6u)));
                        c1 = (signed char)(unsigned)((short)(unsigned)w0 > (signed char)(unsigned)((int)0xffffffffu >= (int)0x80000000u));
                    }
                    for (;;) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (unsigned)((unsigned)(short)((unsigned)(*mp && 0x10000u) | (7u << (i2 & 31u))) && u0));
                        if (fuel < 8u) return (unsigned)(unsigned char)(((unsigned)h0 * (unsigned)((int)u2 >= (int)(unsigned)((int)(unsigned)(w0 >> 29) < (int)0xdc0d1a00u))) >> (r0.y & 31u));
                        if (budget != 0u) { budget -= 1u; u3 = fn1((8u ^ ((unsigned)w0 % ((unsigned)h0 | 1u))), (unsigned)(0xffffffffu == 0x80000000u), (unsigned)(0xd0b68567u || (unsigned)(x0 >> 70))); }
                        w0 ^= (unsigned long long)(0x153d098fu - 0x80000000u) << ((unsigned)((int)0xffffffffu >= (int)0x10000u) & 63u);
                        goto L4;
                        m0 ^= (((0x7fffffffu * (unsigned)s1) - 0xef4f4ec6u) | 0x5b3f8ca1u);
                    }
                    g0 = fuel;
                }
                if (u3 == 7u) return ((unsigned)(p0 == g1) * 0x7fffffffu);
            }
            if ((unsigned)((int)(unsigned)(signed char)(unsigned)((int)u1 >= (int)i2) >= (int)r0.x)) {
                L1: if (--fuel == 0u) goto done;
            } else {
                x0 = x0 * 0x100000001b3ull + ((unsigned)(w0 >> 29) + (unsigned)d0);
                i0 = ((unsigned)s1 % (((0xffffffffu * 0x10000u) - 2u) | 1u)) & 15u;
            }
        } else {
            case 6u: ;
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                default: ;
                g0 = ((unsigned)(x0 >> 70) | (unsigned)c1);
                continue; (void)((r0.x + *mp));
                if (0x10000u) break;
                r0.y ^= (unsigned)c0;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(unsigned char)(8u * (unsigned)c1), (u2 - p2), p0); }
            }
            case 3u: ;
            { unsigned t0; double z0; if ((((unsigned)e0 - (unsigned)(g1 < 6u))) & 1u) { t0 = (0xa0498dd8u * p1); z0 = (double)((0x80000000u) & 255u); } if ((((unsigned)e0 - (unsigned)(g1 < 6u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                L2: if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    g1 += ((unsigned)((unsigned)(0xffffffffu < 0xe65cc0b8u) < (unsigned)((unsigned)(w0 >> 29) && 0xeec34e70u)) >> (r0.y & 31u));
                    L3: if (--fuel == 0u) goto done;
                    case 0u: ;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)e0, (0x7fffffffu | r0.x), p2); }
                    L4: if (--fuel == 0u) goto done;
                    break;
                }
                if (0x6e1039f3u) goto L2;
                break;
            }
        }
        w0 = w0 * 6364136223846793005ull + (garr[u2 & 7u] >> ((unsigned)(short)((unsigned)c1 * (7u ^ (unsigned)s1)) & 31u));
        w0 = w0 * 6364136223846793005ull + ~(unsigned)((int)p1 >= (int)(unsigned)e0);
    }
    switch (0x7c6c7729u & 7u) {
        if (((unsigned)(8u || v0) + 3u)) {
            do { if (--fuel == 0u) goto done;
                b0 = (unsigned)!(unsigned)(p2 || g0) != 0u;
            } while (i0++ < 7u && 0xffffffffu);
            if (budget != 0u) { budget -= 1u; u3 = fn2(u2, (unsigned)(g0 < (fuel >> (v0 & 31u))), (unsigned)((unsigned)f0 || (unsigned)d0)); }
        } else {
            switch ((0x80000000u | (unsigned)(0u && 0x10000u)) & 7u) {
                s0 = (int)(6u / ((unsigned)f0 | 1u));
            }
            c0 = (unsigned char)((unsigned)c1 % ((unsigned)((int)(unsigned)(signed char)(unsigned)((9u * 1u) == i2) < (int)garr[u2 & 7u]) | 1u));
        }
        switch ((0x9f212916u << (p0 & 31u)) & 7u) {
            i0 = ((unsigned)((unsigned)!(unsigned)((short)fuel > (signed char)0x10000u) && (fuel * i1)) + (unsigned)s1) & 15u;
            case 5u: ;
            if (budget != 0u) { budget -= 1u; u0 = fn1(m0, i0, (unsigned)w0); }
        }
        case 5u: ;
        goto done;
        c0 = (unsigned char)(unsigned)((short)(unsigned)((unsigned)f0 && v0) > (signed char)fuel);
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((0x7fffffffu ? (unsigned)(fuel && i0) : (g0 % (1u | 1u))) & 1023u);
        }
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        s0 = (int)(0x80000000u ? r0.x : 8u);
    }
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)0xf850c329u > (signed char)(unsigned)(short)(0x10000u / (p2 | 1u))), p2, ((0xea656119u | p2) & (unsigned)d0)); }
    if ((v0 % ((unsigned)((short)v0 > (signed char)garr[i1 & 7u]) | 1u))) goto L2;
    { unsigned t1; double z1; if (((unsigned)((short)9u > (signed char)0x7fffffffu)) & 1u) { t1 = (9u | u0); z1 = (double)(((unsigned)(3u && 0x80000000u)) & 255u); } if (((unsigned)((short)9u > (signed char)0x7fffffffu)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        if (u3) {
            *q0 = (unsigned)((((unsigned)f0 + p1) * (unsigned)h0) || m0);
            if ((0xfd1b2cf3u >> (u2 & 31u))) goto L0;
            u3 = u3 * 0x9e3779b1u + (u1 >> ((u3 ^ (unsigned)h1) & 31u));
        } else {
            v0 = ((0xffffffffu + 0x1c473a4fu) * (unsigned)d0);
        }
        if (6u) {
            if (a0[u1 & 3u]) {
                *mp = u0;
                if (a0[i0 & 3u]) goto L1;
                if ((unsigned)s1) {
                    goto L4;
                    i1 = (unsigned)((short)(i1 / (u1 | 1u)) > (signed char)(garr[u2 & 7u] & (*mp - v0))) & 15u;
                    r0.y ^= (unsigned)((short)(i1 >> ((unsigned)f0 & 31u)) > (signed char)a0[u1 & 3u]);
                    d0 = d0 * 0.5 + (double)(0x7fffffffu & 1023u);
                    u2 ^= (unsigned)!(i2 ^ (r0.x % ((unsigned)(fuel == 0xffffffffu) | 1u)));
                }
            } else {
                b0 = u3 != 0u;
                if (budget != 0u) { budget -= 1u; u0 = fn3(0x10000u, (v0 ? p1 : *mp), p1); }
                u1 += u3;
                goto L3;
            }
            { unsigned t2; double z2; if ((6u) & 1u) { t2 = ((unsigned)((int)(unsigned)s0 >= (int)i1) & 0x10000u); z2 = (double)(((unsigned)(unsigned char)(8u & u0)) & 255u); } if ((6u) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)(unsigned char)(garr[i1 & 7u] / ((unsigned)h1 | 1u)) >= (int)u1);
                u3 += ((unsigned)(g1 || (unsigned)(x0 >> 70)) + (unsigned)(g1 && r0.x));
                if ((unsigned)(signed char)(unsigned)((short)0x9a49e039u > (signed char)(garr[u2 & 7u] & p2))) goto done;
                while ((*mp ^ (garr[i1 & 7u] - (unsigned)(w0 >> 29)))) { if (--fuel == 0u) goto done;
                    *q0 += (g1 & i0);
                    if (budget != 0u) { budget -= 1u; u0 = fn1(~(8u ^ 0xd5fff05eu), (unsigned)(unsigned char)((unsigned)c1 * p2), (i2 ^ *mp)); }
                    r0.x = (0x7fffffffu ^ ((unsigned)((int)(unsigned)w0 >= (int)(unsigned)l0) >> ((0u >> (0xf023d1dbu & 31u)) & 31u)));
                    *q0 = (unsigned)c1;
                }
            }
            goto L4;
            w0 ^= (unsigned long long)0xd1f6ea70u << ((unsigned)(unsigned char)(unsigned)((short)a0[u1 & 3u] > (signed char)(0xffffffffu - 0xf4df3c4bu)) & 63u);
            if ((unsigned)(m0 < ((unsigned)x0 % (5u | 1u)))) goto done;
        }
        switch (((unsigned)x0 >> ((unsigned)s1 & 31u)) & 7u) {
            *q0 = ~((0x67334373u ^ 5u) & ((unsigned)((unsigned)c0 == 0x92e88091u) % ((unsigned)c1 | 1u)));
            switch ((unsigned)((unsigned)(u1 == fuel) < r0.y) & 7u) {
                if ((unsigned)((int)0x99709360u < (int)i2)) {
                    if (fuel < 8u) return ((unsigned)w0 ? ((unsigned)(unsigned char)(u2 & 0xb208a588u) / (u2 | 1u)) : 0xc3314851u);
                    while (i0++ < 2u && (unsigned)(unsigned char)((0x88ab485u << (1u & 31u)) / (0xc1ef4749u | 1u))) { if (--fuel == 0u) goto done;
                        case 4u: ;
                        q0 = &garr[(unsigned)(signed char)(unsigned)(0x24ba125au == (unsigned)d0) & 7u];
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn3((a0[u1 & 3u] - v0), (a0[i0 & 3u] << ((unsigned)((short)p0 > (signed char)(unsigned)s1) & 31u)), (unsigned)h1); }
                    a0[u3 & 3u] = ((0x80000000u * (unsigned)s0) + (unsigned)f0);
                    case 5u: ;
                }
                l0 = (long)((unsigned long)l0 + (unsigned)(0x80000000u == (unsigned)(*q0 < *q0)));
            }
        }
        g0 = (unsigned)(short)((unsigned)s1 >> (a0[i0 & 3u] & 31u));
        u3 = u3 * 0x9e3779b1u + (unsigned)!(garr[i1 & 7u] ^ 0x2917d711u);
        if (u3) {
            x0 = x0 * 0x100000001b3ull + (unsigned)((int)(r0.y % (a0[i0 & 3u] | 1u)) < (int)(0x80000000u ? 0x10000u : 0x9b0e0809u));
        } else {
            g0 = ((unsigned)((unsigned)x0 == (unsigned)((short)m0 > (signed char)(unsigned)s1)) + -((unsigned)h0 | (unsigned)b0));
            *mp = (unsigned)!(unsigned)((int)(unsigned)s1 >= (int)a0[i0 & 3u]);
            a0[-(7u | (unsigned)h1) & 3u] = ((unsigned)b0 << (0x10000u & 31u));
        }
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((i0 * 0x7fffffffu)) break;
    }
    if ((unsigned)(((unsigned)d0 | (unsigned)w0) && *q0)) goto L2;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(short)(g1 * i0)) {
            b0 = ((unsigned)s1 % (((a0[u1 & 3u] | u0) >> (0u & 31u)) | 1u)) != 0u;
            if (u3 == 7u) return (0xcee10841u * (a0[u1 & 3u] * (unsigned)(*mp && r0.y)));
            break; (void)((unsigned)!(unsigned)(0x7fffffffu || (unsigned)(unsigned char)((unsigned)h1 - 0x80000000u)));
        } else {
            { unsigned t3; double z3; if (((unsigned)(0x829fee2au || 0xffffffffu)) & 1u) { t3 = ((unsigned)s1 ^ u2); z3 = (double)(((unsigned)((int)(unsigned)e0 < (int)a0[u1 & 3u])) & 255u); } if (((unsigned)(0x829fee2au || 0xffffffffu)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                if (budget != 0u) { budget -= 1u; u3 = fn1((a0[u1 & 3u] & v0), 0u, *q0); }
                u2 = (3u | 4u);
            }
            { unsigned t4; double z4; if (((unsigned)l0) & 1u) { t4 = (unsigned)(u3 || (r0.y & garr[i1 & 7u])); z4 = (double)((*q0) & 255u); } if (((unsigned)l0) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                if (budget != 0u) { budget -= 1u; u2 = fn1((r0.y ^ (unsigned)(signed char)(g0 & 0x38323abeu)), i0, (unsigned)(0xffffffffu == *q0)); }
            }
        }
    }
    if ((-(unsigned)((int)i0 < (int)(unsigned)c1) % (m0 | 1u))) goto L0;
    if (((u2 / (i1 | 1u)) | *q0)) goto L3;
    c1 = (signed char)(a0[u1 & 3u] | r0.x);
    u0 = u0 * 0x9e3779b1u + (4u ^ ((0xb530fbbdu | u0) ^ u3));
    f0 = f0 * 0.5f + (float)(((unsigned)((int)((unsigned)b0 * u2) < (int)0xd3cf0f87u) >> (6u & 31u)) & 255u);
    if ((unsigned)((i1 % ((unsigned)h0 | 1u)) && a0[u1 & 3u])) goto L4;
    while (i0++ < 3u && (unsigned)(short)(unsigned)((int)i1 < (int)fuel)) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)(u0 % (0x664f4b02u | 1u)) << ((unsigned)((short)0xa15dcedau > (signed char)(unsigned)((short)u3 > (signed char)(unsigned)e0)) & 63u);
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn3((r0.y ^ (unsigned)(w0 >> 29)), ((unsigned)e0 - 0x80000000u), (unsigned)((unsigned)((int)r0.y >= (int)(unsigned)f0) && p1)); }
                if ((unsigned)h0) goto done;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)(unsigned)(u3 || p2) > (signed char)(unsigned)s0), (unsigned)f0, (unsigned)((int)r0.y < (int)0x3ef21701u)); }
            w0 ^= (unsigned long long)(unsigned)h0 << (((unsigned)s1 ? 0xf8391b1u : fuel) & 63u);
            if (0x5bb318dfu) goto L4;
        }
        v0 = ~(unsigned)(6u && (0x80000000u * i2));
    }
    if (((unsigned)((unsigned)c1 == p2) / (i2 | 1u))) {
        goto L0;
        if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)(0xd153c978u && g0) >> (0xffffffffu & 31u)), (unsigned)e0, (unsigned)(p1 < (unsigned)(x0 >> 70))); }
        u1 ^= (unsigned)(short)((unsigned)s1 | u1);
        if (garr[i1 & 7u]) goto L2;
        c0 = (unsigned char)(unsigned)(m0 && i0);
    } else {
        while ((unsigned)((int)u2 < (int)(unsigned)h0)) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                break; (void)(fuel);
            } while (i1++ < 7u && ((g0 * 0x3c7543bfu) * 0xb830f24cu));
            v0 = (unsigned)(((unsigned)(u3 && (unsigned)f0) >> (i2 & 31u)) == (unsigned)(g1 || garr[u2 & 7u]));
        }
        garr[(unsigned)((unsigned)b0 && g0) & 7u] = ((unsigned)((unsigned)s1 && 0x10000u) ^ ((unsigned)x0 / (0x562f5abeu | 1u)));
    }
    *q0 = 0x80000000u;
    if (((unsigned)d0 * (unsigned)c1)) goto L0;
    if ((garr[u2 & 7u] % ((unsigned)s0 | 1u))) {
        d0 = d0 * 0.5 + (double)(~(m0 >> ((unsigned)x0 & 31u)) & 1023u);
        *mp = (unsigned)s1;
        *mp = 5u;
        l0 = (long)((unsigned long)l0 + (unsigned)x0);
        switch (u1 & 7u) {
            while ((r0.y % (0x7fffffffu | 1u))) { if (--fuel == 0u) goto done;
                *mp = ((g1 | *q0) * p0);
                case 1u: ;
                c0 = (unsigned char)((0xa2b6e67bu << (0x693ca553u & 31u)) - (g0 * (0xffffffffu - u3)));
                if (garr[i1 & 7u]) break;
            }
            case 2u: ;
            while (i0++ < 3u && (unsigned)((unsigned)!(0xffffffffu - 0x33805f22u) && 8u)) { if (--fuel == 0u) goto done;
                *mp = m0;
                case 4u: ;
                w0 = w0 * 6364136223846793005ull + (unsigned)((((unsigned)l0 * 0xffffffffu) << ((unsigned)((int)(unsigned)d0 < (int)(unsigned)c0) & 31u)) && i0);
            }
            if (i0) break;
            default: ;
            *q0 += ((unsigned)(short)((unsigned)f0 / (garr[i1 & 7u] | 1u)) ^ (((unsigned)l0 ^ p2) * i0));
        }
    } else {
        u3 += (unsigned)(x0 >> 70);
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                *q0 = (unsigned)((short)i0 > (signed char)(unsigned)((short)(unsigned)h1 > (signed char)0x7fffffffu));
                b0 = 0x60d28c0u != 0u;
                { unsigned t5; double z5; if (((9u + 0x80000000u)) & 1u) { t5 = r0.y; z5 = (double)(((unsigned)((int)(unsigned)c1 >= (int)u0)) & 255u); } if (((9u + 0x80000000u)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                    if (u3 == 7u) return (((*mp * i0) + (unsigned)x0) * garr[u2 & 7u]);
                    if (m0) {
                        b0 = (unsigned)!(unsigned)(a0[i0 & 3u] || ((unsigned)f0 - m0)) != 0u;
                    }
                    r0.y ^= (unsigned)b0;
                    f0 = f0 * 0.5f + (float)((unsigned)((int)1u < (int)(unsigned)((int)r0.x >= (int)(*q0 * i0))) & 255u);
                    if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)(unsigned char)(unsigned)(u1 && 0xffffffffu), ((unsigned)((unsigned)h0 || (unsigned)c1) & (unsigned)f0), (unsigned)((int)fuel < (int)0x10000u)); }
                    u1 = 0x5282b103u;
                }
            } while (i1++ < 2u && (g0 << ((unsigned)l0 & 31u)));
            if (((unsigned)c1 | ((unsigned)f0 % (9u | 1u)))) goto L3;
            b0 = 0x93cd0d9cu != 0u;
            break; (void)((unsigned)(unsigned char)(0u & i1));
        }
        do { if (--fuel == 0u) goto done;
            if ((i0 / (p1 | 1u))) break;
        } while (i0++ < 5u && ((unsigned)h1 << ((6u ^ (unsigned)c0) & 31u)));
        h0 = (short)i0;
    }
    if (a0[u1 & 3u]) goto L3;
    v0 = (unsigned)((int)(unsigned)c0 >= (int)m0);
    a0[(unsigned)((int)u3 < (int)9u) & 3u] = (unsigned)(signed char)(0x17e1ec5fu % (0x10000u | 1u));
    if (budget != 0u) { budget -= 1u; u3 = fn0(0x80000000u, (unsigned)c1, ~(0x10000u | 0x10000u)); }
    if ((0xffffffffu ^ p1)) {
        switch (u0 & 7u) {
            if ((unsigned)b0) {
                while (i0++ < 3u && p2) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        a0[((unsigned)c1 * (unsigned)e0) & 3u] = (4u % ((unsigned)((short)(*q0 * (8u | *mp)) > (signed char)(unsigned)e0) | 1u));
                        r0.x = (0x80000000u * (((unsigned)h0 & 0x10000u) + (unsigned)(v0 && g0)));
                        w0 = w0 * 6364136223846793005ull + r0.x;
                        s1 = (int)((unsigned)s1 + (unsigned)(short)(p2 ^ (unsigned)(w0 >> 29)));
                        h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)((unsigned)b0 || g0) >= (int)(unsigned)(0xffffffffu < g1)));
                    } while (i1++ < 6u && (v0 >> ((unsigned)((short)(unsigned)w0 > (signed char)(unsigned)e0) & 31u)));
                    u3 = (unsigned)!(g1 ^ (unsigned)c1);
                    v0 = p1;
                    s0 = (int)((p0 + (unsigned)(x0 >> 70)) ^ (unsigned)d0);
                    *q0 += (((unsigned)(r0.x && a0[u1 & 3u]) >> ((m0 / ((unsigned)h0 | 1u)) & 31u)) / (a0[i0 & 3u] | 1u));
                    garr[~(a0[i0 & 3u] ^ i2) & 7u] = ((p1 - (unsigned)c1) - ((unsigned)d0 - (fuel & 0x10000u)));
                }
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)((unsigned)h0 || (u1 - a0[i0 & 3u])) < (unsigned)((int)r0.y < (int)(unsigned)h0)));
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((short)u1 > (signed char)0xb7a178a9u), (unsigned)f0, (unsigned)e0); }
                }
            }
        }
    }
    *mp = ((unsigned)!(r0.x | (unsigned)!(0x10000u * g1)) - (unsigned)(9u < *q0));
    if ((unsigned)l0) goto L0;
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)5u >= (int)0xffffffffu), (unsigned)(0xd5570a15u == (garr[u2 & 7u] / (fuel | 1u))), (unsigned)(short)(unsigned)((unsigned)(x0 >> 70) || (unsigned)w0)); }
    if ((unsigned)d0) goto L1;
    if ((unsigned)((int)(unsigned)h1 >= (int)0x2e3a3e65u)) {
        *mp = (unsigned)c0;
        if (((unsigned)s0 | (unsigned)(short)(unsigned)(u1 == (unsigned)d0))) goto L4;
        s1 = (int)((unsigned)s1 + (unsigned)(short)(unsigned)((unsigned)(short)(0x10000u & (unsigned)e0) == (unsigned)(u1 || u2)));
        u2 = u2 * 0x9e3779b1u + (unsigned)(signed char)((u1 % ((unsigned)(r0.x == 4u) | 1u)) % ((unsigned)((unsigned)x0 < *q0) | 1u));
        f0 = f0 * 0.5f + (float)((unsigned)(short)((0x10000u | 0x10000u) + (unsigned)e0) & 255u);
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            i1 = ((unsigned)(6u == (unsigned)(u3 < 3u)) - 0x32d48917u) & 15u;
        }
    }
    g1 += (unsigned)(unsigned char)(u3 >> ((unsigned)s0 & 31u));
    if ((unsigned)(signed char)((unsigned)(w0 >> 29) * (0xffffffffu << (i2 & 31u)))) goto L1;
    switch (*mp & 7u) {
        w0 ^= (unsigned long long)(unsigned)w0 << ((unsigned)(short)(unsigned)((((unsigned)(i0 || v0) & 1u) % ((unsigned)h1 | 1u)) && 0x381453c5u) & 63u);
    }
    if ((unsigned)h1) goto L1;
    a0[p2 & 3u] = ((4u % ((unsigned)s0 | 1u)) << (0xcdbc6926u & 31u));
    if ((unsigned)d0) goto done;
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)(0x10000u + m0), (0xbd37f65du * (unsigned)h1), -(unsigned)((r0.y ^ i2) < (unsigned)(w0 >> 29))); }
    r0.y ^= 0xdb81eb2eu;
    *q0 += (unsigned)((int)(fuel ? (unsigned)x0 : garr[i1 & 7u]) >= (int)a0[i0 & 3u]);
    u0 ^= ((unsigned)((unsigned)((int)(unsigned)(x0 >> 70) < (int)p0) < (unsigned)((unsigned)l0 && 1u)) & u0);
    m0 ^= (8u % (0xb1be568du | 1u));
    garr[(0x88c97243u | 2u) & 7u] = ((8u - (unsigned)c0) + 0x80000000u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 0u, 0xc87fd949u, 0xa60a867cu },
        { 15u, 0xb27972cu, 0x713d3au },
        { 13u, 0x9cb1afdbu, 0xb4fab014u },
        { 9u, 0x7deb3c73u, 0x260ddcc3u },
        { 1u, 0x1f0883ddu, 0xd01b0eb4u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
