// test-ssa-source's program of seed 134000439 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xbaab0fe6u, g1 = 0xba9968c2u;
static unsigned garr[8] = { 0xf6b07f9cu, 0x497633d3u, 0x45289d0u, 0x323ca0au, 0x1f2312c9u, 0x1c65942bu, 0x919a4435u, 0x44cd1a4bu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    r0.y ^= (unsigned)(signed char)((p0 & (unsigned)h1) << ((unsigned)(*q0 < (u3 ^ *mp)) & 31u));
    L0: if (--fuel == 0u) goto done;
    if (((0x10000u * u0) | 0x10000u)) goto L0;
    L1: if (--fuel == 0u) goto done;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (0xc9f9dd7cu << ((unsigned)((unsigned)(x0 >> 70) < m0) & 31u));
        q0 = &garr[(unsigned)(w0 >> 29) & 7u];
    }
    g0 = (unsigned)((int)(u1 / (0xf7cd3baeu | 1u)) < (int)((u3 / (0x28a2babau | 1u)) >> (*mp & 31u)));
    if ((unsigned)((short)(unsigned)s0 > (signed char)(0xac88df24u ^ i1))) goto L4;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        L2: if (--fuel == 0u) goto done;
        garr[((unsigned)x0 | 0x10000u) & 7u] = (*mp ^ (unsigned)x0);
        a0[p0 & 3u] = ((unsigned)e0 & (unsigned)(m0 < 5u));
        *q0 += (garr[i1 & 7u] % ((unsigned)l0 | 1u));
    }
    x0 = x0 * 0x100000001b3ull + (a0[u1 & 3u] << (p2 & 31u));
    c1 = (signed char)(unsigned)((unsigned)((unsigned)e0 && g0) < (unsigned)(0xd06bcbacu == (u2 >> (6u & 31u))));
    while (i0++ < 2u && (g0 | 0x80000000u)) { if (--fuel == 0u) goto done;
        L3: if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + 0x10000u;
        switch ((u2 ^ (unsigned)(g1 && (unsigned)w0)) & 7u) {
            L4: if (--fuel == 0u) goto done;
        }
        if (m0) continue;
        f0 = f0 * 0.5f + (float)((*mp ? 7u : (1u * (unsigned)(x0 >> 70))) & 255u);
        r0.y ^= (i0 << ((unsigned)x0 & 31u));
    }
    r0.y ^= (7u + ~(p0 >> ((unsigned)(0u || 0x267d6adu) & 31u)));
    if (((unsigned)c0 >> ((unsigned)(*q0 < 0xe288dfd2u) & 31u))) {
        if ((unsigned)((int)(unsigned)(unsigned char)((unsigned)s0 + 2u) >= (int)u1)) {
            { unsigned t0; double z0; if (((unsigned)(w0 >> 29)) & 1u) { t0 = i1; z0 = (double)(((unsigned)((int)0x7fffffffu < (int)(unsigned)s0)) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                goto L3;
                if ((unsigned)(unsigned char)(unsigned)((int)u1 >= (int)(unsigned)((short)0x97fac767u > (signed char)0x7fffffffu))) goto L2;
                c0 = (unsigned char)((unsigned)(garr[i1 & 7u] < garr[i1 & 7u]) / (a0[u1 & 3u] | 1u));
                if ((unsigned)(w0 >> 29)) goto L4;
                w0 ^= (unsigned long long)(unsigned)(i1 < 0xca5991c5u) << ((unsigned)((unsigned)((int)(unsigned)d0 < (int)1u) && (unsigned)(g0 < r0.y)) & 63u);
                if (u0) {
                    h1 = (unsigned short)(h1 + (i0 * (garr[i1 & 7u] & v0)));
                    c0 = (unsigned char)u0;
                    if ((unsigned)w0) goto L0;
                    w0 = w0 * 6364136223846793005ull + ((unsigned)((short)0x8b152ac4u > (signed char)(unsigned)h0) * (unsigned)s1);
                    garr[r0.x & 7u] = ((unsigned)h0 % ((p0 + ((unsigned)b0 | (p0 - g0))) | 1u));
                    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)((unsigned)((r0.y - (unsigned)l0) && (unsigned)((int)(unsigned)h0 < (int)i0)) & 255u);
                        break; (void)((unsigned)((unsigned)(9u < r0.y) || u0));
                        break; (void)((i2 + (unsigned)(short)(0x10000u - (unsigned)w0)));
                        f0 = f0 * 0.5f + (float)(((unsigned)((short)u1 > (signed char)(unsigned)(short)(unsigned)(a0[i0 & 3u] && u3)) + -(*q0 - (unsigned)f0)) & 255u);
                    }
                } else {
                    c0 = (unsigned char)(unsigned)((4u | (unsigned)h1) || (r0.y + p0));
                    i0 = ((unsigned)w0 | (m0 >> ((2u - (unsigned)(signed char)((unsigned)s1 - u3)) & 31u))) & 15u;
                }
            }
            goto L2;
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                *q0 = (0x7fffffffu | ((unsigned)l0 + 3u));
                g1 += (i1 >> ((unsigned)(short)(unsigned)((unsigned)s0 || 4u) & 31u));
                break; (void)(2u);
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)s1 > (signed char)(8u | ((unsigned)x0 - u2)));
                g0 = ~(unsigned)(g0 || g1);
            }
            if (g0) goto done;
            if (u1) goto done;
        } else {
            while (i0++ < 2u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t1; double z1; if (((7u ^ (unsigned)((short)garr[i1 & 7u] > (signed char)fuel))) & 1u) { t1 = (unsigned)(x0 >> 70); z1 = (double)(((unsigned)d0) & 255u); } if (((7u ^ (unsigned)((short)garr[i1 & 7u] > (signed char)fuel))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                        if (p1) break;
                        if ((unsigned)((short)(unsigned)h1 > (signed char)(unsigned)(w0 >> 29))) {
                            q0 = &garr[0xf0b88987u & 7u];
                            b0 = (4u * (unsigned)(unsigned char)((unsigned)((unsigned)s0 || (unsigned)w0) & (u3 ^ u1))) != 0u;
                        }
                        r0.y ^= (unsigned)((unsigned)(signed char)(unsigned)(0u < (unsigned)(x0 >> 70)) == (unsigned)d0);
                        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(g1 || (unsigned)w0) < (unsigned)x0) & 255u);
                        if ((unsigned)(i1 && (unsigned)(short)(unsigned)((int)m0 >= (int)(unsigned)w0))) break;
                        s1 = (int)((unsigned)s1 + ((unsigned)((int)i2 >= (int)u1) * (unsigned)((unsigned)w0 && ((unsigned)f0 ^ u2))));
                    }
                    break; (void)(i0);
                    while (u3) { if (--fuel == 0u) goto done;
                        while (i0++ < 7u && (u0 ? u2 : 5u)) { if (--fuel == 0u) goto done;
                            if (u3 == 7u) return (unsigned)(signed char)((unsigned)((int)(unsigned)h1 < (int)0xffffffffu) & (unsigned)((short)((unsigned)d0 / (i1 | 1u)) > (signed char)garr[u2 & 7u]));
                        }
                        goto L4;
                        g1 += (unsigned)((int)(unsigned)(w0 >> 29) < (int)*mp);
                    }
                    u0 += (*q0 + (unsigned)(x0 >> 70));
                }
                x0 = x0 * 0x100000001b3ull + (i1 + g1);
            }
            w0 = w0 * 6364136223846793005ull + g0;
            goto L4;
        }
        if ((unsigned)((int)0x7fffffffu >= (int)p1)) goto L3;
    } else {
        d0 = d0 * 0.5 + (double)(((0x7fffffffu ? *q0 : 0x44d5ff0au) | (4u | 1u)) & 1023u);
        u2 ^= (unsigned)((int)((unsigned)(unsigned char)((unsigned)l0 ? 0x80000000u : 0x10000u) * r0.y) < (int)(unsigned)w0);
        while (i0++ < 4u && (unsigned)!(0x7fffffffu % ((unsigned)h0 | 1u))) { if (--fuel == 0u) goto done;
            if (p2) {
                if ((unsigned)(0x1346408du == (unsigned)c1)) break;
            } else {
                switch ((unsigned)(short)((unsigned)(unsigned char)(unsigned)((int)i2 >= (int)8u) << (r0.x & 31u)) & 7u) {
                    do { if (--fuel == 0u) goto done;
                        if (r0.x) goto L2;
                    } while (i1++ < 7u && (unsigned)c0);
                    if ((unsigned)(0x10000u == (unsigned)s1)) {
                        x0 = x0 * 0x100000001b3ull + (unsigned)((short)(*mp << ((unsigned)s1 & 31u)) > (signed char)(unsigned)w0);
                        u1 ^= (unsigned)(~(a0[i0 & 3u] << ((unsigned)(signed char)(unsigned)(i0 && garr[i1 & 7u]) & 31u)) < (unsigned)h0);
                        case 5u: ;
                    } else {
                        { unsigned t2; double z2; if (((unsigned)d0) & 1u) { t2 = m0; z2 = (double)((fuel) & 255u); } if (((unsigned)d0) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                            case 0u: ;
                            u0 += p0;
                            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(unsigned char)((unsigned)c0 ? (unsigned)d0 : r0.x) && (unsigned)(w0 >> 29)) & 1023u);
                            s0 = (int)(unsigned)s1;
                            case 1u: ;
                        }
                        while (i1++ < 7u && -(r0.x * (unsigned)e0)) { if (--fuel == 0u) goto done;
                            e0 = e0 * 0.5L + (long double)((unsigned)((int)(3u % ((unsigned)l0 | 1u)) >= (int)(unsigned)(p2 == u0)) & 1023u);
                            case 2u: ;
                            *q0 = ~((unsigned)(x0 >> 70) / ((((unsigned)c1 & (unsigned)s0) - ((unsigned)h1 & (unsigned)h1)) | 1u));
                        }
                        r0.x = (p2 << ((unsigned)(signed char)((unsigned)((short)(unsigned)(u3 == 9u) > (signed char)a0[i0 & 3u]) - u0) & 31u));
                        garr[(unsigned)c1 & 7u] = ((unsigned)h1 ? (unsigned)(x0 >> 70) : u2);
                    }
                }
                h1 = (unsigned short)(h1 + ((unsigned)l0 | (g0 * u1)));
            }
            if (u0) {
                g1 += (unsigned)((unsigned)(((unsigned)x0 ^ 0xffffffffu) && (unsigned)l0) == (g0 | (unsigned)c1));
                u3 ^= (unsigned)((int)u3 >= (int)(unsigned)(unsigned char)(r0.x | (unsigned)(a0[i0 & 3u] == (unsigned)((int)(unsigned)s0 >= (int)g0))));
                u1 = u1;
                { unsigned t3; double z3; if (((unsigned)(short)(r0.x ^ r0.y)) & 1u) { t3 = (unsigned)((int)(g0 | 0xffffffffu) < (int)(unsigned)h1); z3 = (double)((g0) & 255u); } if (((unsigned)(short)(r0.x ^ r0.y)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    break; (void)((0x72197718u / ((r0.x & (unsigned)s0) | 1u)));
                    if ((unsigned)((int)(unsigned)s0 < (int)1u)) goto L2;
                    { unsigned t4; double z4; if (((unsigned)(0xffffffffu == (unsigned)s0)) & 1u) { t4 = (unsigned)(short)(unsigned)((unsigned)s1 && (unsigned)c0); z4 = (double)(((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)((int)(unsigned)h1 < (int)(unsigned)w0))) & 255u); } if (((unsigned)(0xffffffffu == (unsigned)s0)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                        { unsigned t5; double z5; if (((unsigned)!(u1 ^ 0x10000u)) & 1u) { t5 = (unsigned)s0; z5 = (double)(((unsigned)(g0 < p2)) & 255u); } if (((unsigned)!(u1 ^ 0x10000u)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                            x0 = x0 * 0x100000001b3ull + g1;
                            f0 = f0 * 0.5f + (float)((((unsigned)(w0 >> 29) >> ((unsigned)(unsigned char)(unsigned)((int)1u >= (int)a0[u1 & 3u]) & 31u)) % ((unsigned)c0 | 1u)) & 255u);
                            if (((unsigned)h1 % (0x80000000u | 1u))) break;
                        }
                    }
                    d0 = d0 * 0.5 + (double)((a0[u1 & 3u] & (unsigned)(signed char)(0x83979538u ^ 0x6b13870au)) & 1023u);
                    continue; (void)(((unsigned)s1 - 0x7fffffffu));
                }
            }
            goto L2;
            do { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + 0x10000u;
                if (((unsigned)((unsigned)(x0 >> 70) == r0.x) * m0)) break;
            } while (i1++ < 6u && 0x10000u);
            do { if (--fuel == 0u) goto done;
                if ((garr[i1 & 7u] | -(0xffffffffu % (u2 | 1u)))) break;
            } while (i1++ < 5u && ((unsigned)w0 ? u0 : r0.x));
            do { if (--fuel == 0u) goto done;
                if ((p1 << (p0 & 31u))) goto L0;
            } while (i1++ < 3u && ((unsigned)b0 + (unsigned)h0));
        }
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)s0) {
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                g0 = (unsigned)(0xf1de6c9eu < (unsigned)x0);
                e0 = e0 * 0.5L + (long double)((0xddd5b9a9u << ((a0[i0 & 3u] / (0x7fffffffu | 1u)) & 31u)) & 1023u);
                switch ((-(unsigned)(7u < (unsigned)w0) % ((unsigned)x0 | 1u)) & 7u) {
                    continue; (void)(r0.y);
                    w0 = w0 * 6364136223846793005ull + ((unsigned)c0 * (unsigned)((int)fuel < (int)(unsigned)s1));
                    { unsigned t6; double z6; if (((0x54e77341u % ((0xee793b81u | u1) | 1u))) & 1u) { t6 = (0x684645fu / ((unsigned)h1 | 1u)); z6 = (double)(((0x7fffffffu + 0xffffffffu)) & 255u); } if (((0x54e77341u % ((0xee793b81u | u1) | 1u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                        r0.y ^= (r0.x >> (3u & 31u));
                        garr[g0 & 7u] = (unsigned)((unsigned)e0 == ((unsigned)x0 ? (unsigned)l0 : 0x82669f31u));
                        if ((*mp & 0x7fffffffu)) goto L3;
                    }
                    a0[(unsigned)(p0 || i0) & 3u] = (unsigned)((unsigned)!((g0 >> (g0 & 31u)) << (g0 & 31u)) && (unsigned)h0);
                    { unsigned t7; double z7; if ((((unsigned)(x0 >> 70) * (unsigned)w0)) & 1u) { t7 = (g0 | ((unsigned)h1 / (0xb64bb658u | 1u))); z7 = (double)(((unsigned)(unsigned char)((unsigned)!(0x80000000u * *mp) >> ((unsigned)f0 & 31u))) & 255u); } if ((((unsigned)(x0 >> 70) * (unsigned)w0)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                        case 4u: ;
                    }
                    if ((unsigned)(x0 >> 70)) {
                        default: ;
                        w0 = w0 * 6364136223846793005ull + (unsigned)!((unsigned)((unsigned)d0 < i1) >> ((8u - (garr[u2 & 7u] + u3)) & 31u));
                        m0 ^= (unsigned)((unsigned)((int)(unsigned)l0 < (int)0x10000u) || garr[i1 & 7u]);
                        *mp = (unsigned)(short)(unsigned)((int)8u >= (int)u3);
                        l0 = (long)((unsigned long)l0 + (r0.y & (unsigned)s1));
                    }
                }
                if ((unsigned)((int)(unsigned)s0 >= (int)(unsigned)((int)7u < (int)p2))) {
                    if (i2) break;
                    if (garr[i1 & 7u]) continue;
                    if (((unsigned)x0 - (unsigned)d0)) break;
                    h0 = (short)a0[u1 & 3u];
                    break; (void)((g1 * (0xecf4618eu + (unsigned)s0)));
                    if (u3 == 7u) return u3;
                }
                m0 ^= (unsigned)((unsigned)s0 || i2);
                if ((v0 & (unsigned)(u3 || (unsigned)(x0 >> 70)))) break;
            }
        }
        break; (void)((garr[u2 & 7u] << ((i2 << (0x3a885de7u & 31u)) & 31u)));
        break; (void)(1u);
    } while (i0++ < 6u && ((unsigned)e0 + (unsigned)(w0 >> 29)));
    if ((unsigned)(signed char)(i1 & (unsigned)(unsigned char)(g0 % ((unsigned)x0 | 1u)))) goto L1;
    u2 ^= (unsigned)e0;
    garr[4u & 7u] = (unsigned)(3u == 0xbceddb13u);
    u0 = u0 * 0x9e3779b1u + ((unsigned)l0 << ((unsigned)c0 & 31u));
    if (0xffffffffu) goto L3;
    if ((unsigned)(short)(unsigned)((unsigned)s0 < m0)) goto L4;
    goto L1;
    c1 = (signed char)(unsigned)((int)(unsigned)(unsigned char)(0x7c2edf68u + (unsigned)c0) < (int)(unsigned)((fuel - 0x80000000u) || 7u));
    c1 = (signed char)(1u & (unsigned)((unsigned)f0 || ((unsigned)w0 >> ((unsigned)s1 & 31u))));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        q0 = &garr[((unsigned)!(0x721d77beu * (unsigned)e0) << (((unsigned)s0 / ((unsigned)h0 | 1u)) & 31u)) & 7u];
        q0 = &garr[(i2 / ((unsigned)((short)u3 > (signed char)i0) | 1u)) & 7u];
        do { if (--fuel == 0u) goto done;
            u1 = u1 * 0x9e3779b1u + i1;
        } while (i1++ < 2u && (unsigned)((short)(unsigned)x0 > (signed char)-((unsigned)(w0 >> 29) ^ u0)));
        u3 = ((unsigned)w0 + 0x7fffffffu);
    }
    u1 += a0[u1 & 3u];
    q0 = &garr[u3 & 7u];
    if (fuel < 8u) return (garr[u2 & 7u] << (p0 & 31u));
    if (g1) {
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)m0 < (int)(3u ^ 0x819e5f4fu)), i1, (unsigned)((short)(unsigned)(*mp < u1) > (signed char)i2)); }
        if (budget != 0u) { budget -= 1u; u2 = fn0(u0, p2, (unsigned)((int)((unsigned)f0 - u1) < (int)p2)); }
        r0.x = ((unsigned)((0x10000u - 0x48ed4198u) || 0x10000u) | *mp);
        if (budget != 0u) { budget -= 1u; u2 = fn0((1u + (unsigned)((int)0xffffffffu < (int)u0)), ((unsigned)((short)(unsigned)d0 > (signed char)8u) + p1), (unsigned)((0xffffffffu ^ (unsigned)s0) && 0x80000000u)); }
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (-(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)(4u < 0x80000000u))) continue;
        }
    } else {
        *q0 = (unsigned)(short)(((unsigned)(w0 >> 29) | (unsigned)b0) ? 0x89d63583u : u3);
        if (0xcdba7ed3u) goto done;
        L0: if (--fuel == 0u) goto done;
        *q0 = (unsigned)(((unsigned)c1 >> ((unsigned)l0 & 31u)) == ((unsigned)w0 % ((unsigned)l0 | 1u)));
    }
    c1 = (signed char)(unsigned)(0xede04122u < (unsigned)c1);
    *mp = ((unsigned)(p1 < (unsigned)l0) ? g0 : *mp);
    if (i1) goto L2;
    if ((unsigned)(unsigned char)(unsigned)((short)m0 > (signed char)0x7fffffffu)) {
        l0 = (long)((unsigned long)l0 + ((unsigned)f0 << (((unsigned)c0 ? (unsigned)((short)0u > (signed char)u3) : u1) & 31u)));
    }
    if ((unsigned)((short)0x10000u > (signed char)u0)) goto L2;
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((unsigned)(u0 == (unsigned)((unsigned)b0 < 0x80000000u)) % (g1 | 1u));
            { unsigned t0; double z0; if (((((unsigned)(x0 >> 70) - 0x80000000u) * 0xb05b2e96u)) & 1u) { t0 = ((v0 ^ 0xffffffffu) & 0x7fffffffu); z0 = (double)((((unsigned)s0 & (unsigned)(u3 < u0))) & 255u); } if (((((unsigned)(x0 >> 70) - 0x80000000u) * 0xb05b2e96u)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                if (0x80000000u) break;
                do { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)((int)(unsigned)w0 >= (int)((0x5674b616u * (unsigned)d0) / ((unsigned)b0 | 1u)));
                    s0 = (int)(p0 / (((unsigned)f0 - 0x599391d2u) | 1u));
                    if (3u) continue;
                    if ((unsigned)(signed char)((unsigned)((int)(unsigned)h1 >= (int)7u) << (0x7fa3f530u & 31u))) break;
                    w0 = w0 * 6364136223846793005ull + (unsigned)(0x10000u && (unsigned)h0);
                } while (i2++ < 5u && (unsigned)(0x2f4b7398u && (unsigned)h1));
                *mp = (unsigned)(short)(i1 ? (unsigned)l0 : *q0);
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)(i2 ? (unsigned)h0 : (unsigned)s0), 0u, (unsigned)((short)0x7fffffffu > (signed char)(7u % (p1 | 1u)))); }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((2u ^ p2) < (unsigned)c0), 0x2a75cab2u, 6u); }
            w0 = w0 * 6364136223846793005ull + (unsigned)!(0x88c2d328u - (fuel ? 0x7fffffffu : (unsigned)w0));
        } while (i1++ < 7u && 0xffffffffu);
        do { if (--fuel == 0u) goto done;
            c1 = (signed char)(g0 << ((((v0 | (unsigned)s0) + i2) + u0) & 31u));
            L1: if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + ((unsigned)c1 + (*mp % (u0 | 1u))));
            if ((unsigned)(short)(((unsigned)b0 ^ u2) + 0xe4b41287u)) break;
        } while (i1++ < 4u && (unsigned)(1u == 0xb870065u));
    } while (i0++ < 3u && ~(6u / ((unsigned)s1 | 1u)));
    b0 = (unsigned)(0x7fffffffu == (unsigned)(0x985807d8u && g0)) != 0u;
    if ((p0 * v0)) {
        s1 = (int)((unsigned)s1 + u2);
    }
    r0.x = (unsigned)((short)(garr[u2 & 7u] | ((unsigned)h1 & (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)e0))) > (signed char)i2);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 = (unsigned)((int)(unsigned)((short)5u > (signed char)0x7fffffffu) < (int)(unsigned)c0);
    }
    L2: if (--fuel == 0u) goto done;
    s1 = (int)((unsigned)s1 + 0x10000u);
    goto L2;
    { unsigned t1; double z1; if ((*mp) & 1u) { t1 = (unsigned)((int)p0 >= (int)(p0 % (i1 | 1u))); z1 = (double)(((unsigned)(0xf7aba761u && (v0 << (*q0 & 31u)))) & 255u); } if ((*mp) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        c0 = (unsigned char)m0;
        if ((unsigned)w0) {
            if ((0x290fc159u / ((unsigned)b0 | 1u))) goto L4;
        } else {
            r0.y ^= (unsigned)((int)p2 < (int)(unsigned)w0);
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0((r0.y & (unsigned)c1), (3u | (unsigned)h1), u0); }
        v0 = (g1 / ((unsigned)(4u < v0) | 1u));
        m0 ^= 6u;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)s0 < (int)*q0), g0, (unsigned)((0x691e03a5u - (unsigned)f0) && *q0)); }
    if ((unsigned)(signed char)(unsigned)((int)0xffffffffu < (int)(fuel << (0x80000000u & 31u)))) goto L0;
    while (i0++ < 5u && (i2 << ((*mp ^ 0x80000000u) & 31u))) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)0x10000u << (0x10000u & 63u);
        goto L1;
        u0 ^= ((0x8402ac76u - v0) | (unsigned)((short)0x7fffffffu > (signed char)(unsigned)((int)g1 >= (int)u2)));
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            while (i2++ < 6u && 4u) { if (--fuel == 0u) goto done;
                if ((r0.y + (unsigned)(i2 == p0))) goto L1;
                m0 ^= (unsigned)(m0 && (0xe2798b7cu & ((unsigned)w0 << ((unsigned)e0 & 31u))));
                switch (a0[u1 & 3u] & 7u) {
                    do { if (--fuel == 0u) goto done;
                        s0 = (int)(unsigned)(signed char)((i1 % (r0.x | 1u)) * ((unsigned)((unsigned)w0 < v0) | (unsigned)d0));
                    } while (i0++ < 3u && (5u ? 0x321ba0adu : p2));
                }
            }
            c1 = (signed char)0xffffffffu;
        }
        switch (((unsigned)(x0 >> 70) ? r0.y : (unsigned)x0) & 7u) {
            L3: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0(r0.y, (unsigned)w0, (unsigned)(short)(unsigned)((short)0x12770d77u > (signed char)(unsigned)(signed char)(unsigned)(6u && *q0))); }
        }
    }
    m0 ^= g0;
    g1 += (unsigned)((int)0xa778a43du >= (int)(~(*mp & u1) ^ (p2 ^ 0x7fffffffu)));
    goto L2;
    if ((unsigned)((int)(unsigned)b0 >= (int)(unsigned)b0)) goto done;
    if ((p1 / (((unsigned)e0 * *mp) | 1u))) goto L2;
    if ((a0[u1 & 3u] ^ g0)) goto done;
    c0 = (unsigned char)((unsigned)(garr[i1 & 7u] && (g1 ^ 6u)) / ((unsigned)h1 | 1u));
    if (0x80000000u) {
        while (i0++ < 7u && ((unsigned)s1 - (unsigned)((short)0x260b950cu > (signed char)0xffffffffu))) { if (--fuel == 0u) goto done;
            b0 = (unsigned)((unsigned)((short)(0x7fffffffu & (unsigned)h1) > (signed char)(unsigned)x0) || u0) != 0u;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)h1 ^ i2), p1, (unsigned)h0); }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 += ((r0.y ? 0x80000000u : 0xbad2015cu) | (unsigned)(short)((unsigned)l0 & *mp));
            }
        }
        w0 ^= (unsigned long long)m0 << ((*q0 ^ 0xfef49ac9u) & 63u);
        if ((unsigned)((unsigned)(unsigned char)(unsigned)((int)(unsigned)x0 >= (int)0xbbd5bae3u) || u3)) {
            L4: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(((0x67884322u >> (0x8d3dc0d0u & 31u)) * r0.y), (fuel & u3), (0xffffffffu << (0x7fffffffu & 31u))); }
            while (g0) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (*mp) continue;
                    switch ((0x7fffffffu << ((unsigned)(signed char)(p0 - (unsigned)x0) & 31u)) & 7u) {
                        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(x0 >> 70) < ((unsigned)c0 >> ((unsigned)d0 & 31u))) & 255u);
                        if (budget != 0u) { budget -= 1u; u3 = fn0(fuel, (i2 ^ (unsigned)s0), (unsigned)((int)r0.x < (int)((unsigned)h1 / (p2 | 1u)))); }
                        if (r0.x) {
                            q0 = &garr[((unsigned)!(v0 ? (unsigned)(short)(r0.x - (unsigned)(x0 >> 70)) : *q0) >> (0x54cc6cb7u & 31u)) & 7u];
                            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x852a4c18u && (unsigned)(w0 >> 29)), 0xffffffffu, u0); }
                            case 3u: ;
                            *q0 += (unsigned)((unsigned)(0x7fffffffu && (unsigned)s1) < garr[i1 & 7u]);
                            default: ;
                            w0 ^= (unsigned long long)(i1 % (garr[u2 & 7u] | 1u)) << (r0.x & 63u);
                        } else {
                            w0 ^= (unsigned long long)0xffffffffu << ((unsigned)((unsigned)e0 == a0[u1 & 3u]) & 63u);
                            case 1u: ;
                        }
                        case 0u: ;
                    }
                    f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)l0 >> (0x3cbe093cu & 31u)) || -((unsigned)h0 / ((unsigned)s0 | 1u))) & 255u);
                    q0 = &garr[(unsigned)(unsigned char)(p1 + (unsigned)((int)(unsigned)f0 >= (int)3u)) & 7u];
                }
                r0.x = ((8u ? (unsigned)((unsigned)h0 < fuel) : 0x10000u) * *q0);
                if (r0.x) break;
            }
            g1 += ((unsigned)x0 & (unsigned)!((unsigned)c1 | ((unsigned)(w0 >> 29) >> ((unsigned)w0 & 31u))));
            u3 ^= (unsigned)((r0.y + 8u) == i2);
            *q0 = ((unsigned)(w0 >> 29) - (0x10000u ? 0x10000u : g1));
        }
        { unsigned t2; double z2; if (((0xcd515476u - 1u)) & 1u) { t2 = 0x3779ac06u; z2 = (double)(((p2 / (garr[u2 & 7u] | 1u))) & 255u); } if (((0xcd515476u - 1u)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            e0 = e0 * 0.5L + (long double)(g1 & 1023u);
            *q0 += (unsigned)(6u || (unsigned)((int)0x80000000u < (int)(unsigned)b0));
            if ((garr[i1 & 7u] / (((unsigned)w0 | (unsigned)w0) | 1u))) goto L2;
            if ((*q0 % (i2 | 1u))) goto L4;
            if ((unsigned)((int)garr[i1 & 7u] < (int)5u)) {
                for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    h0 = (short)~(7u + (0u ^ u0));
                    if ((v0 & 0u)) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(~(*q0 ^ garr[i1 & 7u]), (0x10000u & 0xffffffffu), (unsigned)((short)(unsigned)x0 > (signed char)(*mp % ((unsigned)s0 | 1u)))); }
                    garr[u1 & 7u] = (unsigned)(g1 == ((unsigned)w0 | (a0[i0 & 3u] ^ p0)));
                    f0 = f0 * 0.5f + (float)((m0 * 0xffffffffu) & 255u);
                    c1 = (signed char)(unsigned)(p2 || (unsigned)((unsigned)w0 && (unsigned)(w0 >> 29)));
                }
                b0 = (unsigned)(u3 && (unsigned)(signed char)((0x5aac36d8u & m0) / ((p2 & i1) | 1u))) != 0u;
            }
        }
    }
    if (m0) goto L3;
    m0 ^= ((v0 - (unsigned)b0) | 9u);
    goto L1;
    if (5u) goto done;
    if ((unsigned)l0) goto L0;
    if ((0x6622c0c8u << (i1 & 31u))) goto done;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((short)*mp > (signed char)g1) & *q0), ~((unsigned)d0 << (0x10000u & 31u)), (*mp | m0)); }
        if ((unsigned)((int)(unsigned)f0 >= (int)(m0 / (0x9d451c3du | 1u)))) break;
        if (u2) {
            do { if (--fuel == 0u) goto done;
                continue; (void)(((unsigned)l0 ^ (unsigned)(x0 >> 70)));
                c0 = (unsigned char)(2u - 6u);
                garr[(garr[i1 & 7u] % ((unsigned)w0 | 1u)) & 7u] = (unsigned)(signed char)(unsigned)((unsigned)((short)(i0 << (u1 & 31u)) > (signed char)0x298efb7bu) || *q0);
                if ((unsigned)((short)(unsigned)e0 > (signed char)(p1 * 0x63d82682u))) {
                    u3 = u3 * 0x9e3779b1u + (((unsigned)w0 ^ (m0 ^ 0x80000000u)) & (r0.x / (*mp | 1u)));
                    w0 = w0 * 6364136223846793005ull + (unsigned)h0;
                    u0 += (0xf33285b6u & (u1 * (unsigned)d0));
                    while (i2++ < 7u && (unsigned)!((3u & i2) - garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)(unsigned)((int)u1 < (int)(unsigned)s0) << ((unsigned)((int)0x7fffffffu >= (int)(((unsigned)(0x3a8aa727u == garr[u2 & 7u]) * (unsigned)f0) - 0xe36c63abu)) & 63u);
                        x0 = x0 * 0x100000001b3ull + (unsigned)(m0 == p1);
                    }
                } else {
                    *mp = u2;
                    for (;;) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)w0, (unsigned)((short)7u > (signed char)((unsigned)c1 ^ (unsigned)h0)), -((unsigned)f0 >> ((6u ^ g0) & 31u))); }
                        if (budget != 0u) { budget -= 1u; u1 = fn0(0x59afea68u, (r0.y ? u2 : (unsigned)e0), (unsigned)s1); }
                        break; (void)((unsigned)x0);
                    }
                    d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)e0 / (u2 | 1u)) && garr[i1 & 7u]) & 1023u);
                    w0 = w0 * 6364136223846793005ull + (unsigned)(((unsigned)((int)i1 < (int)p0) | a0[i0 & 3u]) || (unsigned)(i0 < 4u));
                }
                s1 = (int)((unsigned)s1 + 4u);
            } while (i1++ < 4u && (unsigned)x0);
            w0 ^= (unsigned long long)(unsigned)s0 << ((r0.x >> (0u & 31u)) & 63u);
            u3 += (i2 * g0);
        } else {
            x0 = x0 * 0x100000001b3ull + (unsigned)(a0[i0 & 3u] && 0x1a27843u);
            if ((i2 | (unsigned)w0)) {
                x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((int)r0.x < (int)u1) < (unsigned)(i0 || g0));
            }
            h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)(unsigned char)(unsigned)((short)(unsigned)((unsigned)s1 < 9u) > (signed char)(unsigned)e0) < (int)(unsigned)(x0 >> 70)));
            do { if (--fuel == 0u) goto done;
                if ((unsigned)s1) {
                    if (5u) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)l0 < (int)7u), (unsigned)d0, (0x9376bdcfu - ((unsigned)w0 * p2))); }
                    *mp = (((unsigned)(unsigned char)((unsigned)e0 ^ u3) + fuel) << (-(unsigned)(0x7fffffffu == (unsigned)c0) & 31u));
                }
                garr[(unsigned)(unsigned char)((unsigned)(x0 >> 70) * i0) & 7u] = (unsigned)(short)((r0.x | (unsigned)h0) * m0);
            } while (i1++ < 5u && (unsigned)(w0 >> 29));
        }
    }
    if ((unsigned)((unsigned)s1 || (p1 + r0.y))) {
        garr[(0x7fffffffu ^ g1) & 7u] = ~(i0 << (*mp & 31u));
        w0 ^= (unsigned long long)0x10000u << (((unsigned)((unsigned)b0 || p1) >> ((i2 << ((unsigned)d0 & 31u)) & 31u)) & 63u);
    }
    u0 = (unsigned)((unsigned)c1 == ((unsigned)c1 / ((unsigned)((u3 * 6u) < 5u) | 1u)));
    s1 = (int)((unsigned)s1 + ((unsigned)(g0 && u0) ^ 1u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    v0 = (i2 ? (p0 / (0xffffffffu | 1u)) : u2);
    r0.y ^= ((unsigned)d0 ^ (0x7fffffffu % (p2 | 1u)));
    g0 = ((garr[u2 & 7u] | (unsigned)c0) / ((unsigned)b0 | 1u));
    switch (g0 & 7u) {
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(m0 < u1), a0[u1 & 3u], (r0.x % (*mp | 1u))); }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((*mp % (2u | 1u)) + (unsigned)((int)u3 < (int)g0)) & 1023u);
            q0 = &garr[(unsigned)(signed char)(*q0 >> (2u & 31u)) & 7u];
            g1 += (((unsigned)((short)p2 > (signed char)i0) & r0.y) + 0xffffffffu);
            if ((unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)((unsigned)s0 == (unsigned)f0))) break;
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                g0 = (unsigned)(u0 == (unsigned)c0);
                case 4u: ;
            }
            switch ((unsigned)(0x80000000u < garr[i1 & 7u]) & 7u) {
                while (i1++ < 6u && (0x80000000u ^ 0u)) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((a0[i0 & 3u] >> (i2 & 31u)), ((unsigned)l0 << (i1 & 31u)), (unsigned)c1); }
                        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                            u3 += (unsigned)((int)(unsigned)h1 >= (int)m0);
                            v0 = (unsigned)(g1 || g1);
                        }
                    } while (i2++ < 5u && m0);
                    c1 = (signed char)(unsigned)((unsigned)(unsigned char)(unsigned)((int)0xdb503025u >= (int)(unsigned)(x0 >> 70)) || m0);
                    a0[(unsigned)((int)a0[i0 & 3u] >= (int)u3) & 3u] = (unsigned)((short)7u > (signed char)(fuel + r0.x));
                    u3 ^= (u0 + ((0x10000u - 2u) % (u3 | 1u)));
                    f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(1u - u0)) & 255u);
                    garr[(unsigned)d0 & 7u] = (0x7fffffffu ? (unsigned)l0 : garr[u2 & 7u]);
                }
                garr[(unsigned)s0 & 7u] = (unsigned)((short)(unsigned)(short)((unsigned)(0x1b20b389u < g0) + i0) > (signed char)(unsigned)l0);
            }
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(unsigned char)((unsigned)(w0 >> 29) + u2), (unsigned)(g0 && (0x80000000u | 0u)), g0); }
        g1 += (0x80000000u | 0x40d678ffu);
        goto L3;
        x0 = x0 * 0x100000001b3ull + ((unsigned)((int)(unsigned)(x0 >> 70) < (int)p1) ^ 0x422ac4e3u);
    }
    L0: if (--fuel == 0u) goto done;
    f0 = f0 * 0.5f + (float)((((unsigned)(x0 >> 70) >> ((unsigned)(5u < 0x3f54596au) & 31u)) << (9u & 31u)) & 255u);
    u3 = u3 * 0x9e3779b1u + (unsigned)(u2 || garr[u2 & 7u]);
    goto L3;
    if ((unsigned)(0x7fffffffu < 0xc6b86496u)) goto L0;
    h1 = (unsigned short)(h1 + (unsigned)(1u == (unsigned)((r0.x / ((unsigned)((int)(unsigned)c1 < (int)0xef0eeec9u) | 1u)) && p0)));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= (unsigned)(unsigned char)(unsigned)((short)(unsigned)((int)(unsigned)((short)g1 > (signed char)g0) < (int)i0) > (signed char)0x10000u);
        if (*q0) break;
        if ((5u | 0u)) continue;
        s1 = (int)((unsigned)s1 + (0x52d3ffa9u ^ (g0 + u1)));
        break; (void)((unsigned)(6u || p0));
        if (budget != 0u) { budget -= 1u; u0 = fn1((garr[i1 & 7u] + (unsigned)b0), (p1 * (i0 / (0x20a92c27u | 1u))), (i0 + (unsigned)((short)5u > (signed char)u2))); }
    }
    goto L4;
    while (i0++ < 6u && (garr[u2 & 7u] << (0x5788ca58u & 31u))) { if (--fuel == 0u) goto done;
        h0 = (short)u2;
        if (budget != 0u) { budget -= 1u; u1 = fn1((*q0 | 9u), m0, (unsigned)(p2 || (u2 << (0x7ee49d9du & 31u)))); }
        if ((a0[u1 & 3u] & -(0x7fffffffu * garr[i1 & 7u]))) break;
    }
    b0 = (unsigned)((int)(fuel ^ ((unsigned)l0 % (*q0 | 1u))) < (int)(0xffffffffu * 3u)) != 0u;
    w0 = w0 * 6364136223846793005ull + a0[i0 & 3u];
    i0 = 7u & 15u;
    garr[0xffffffffu & 7u] = (0x331da620u * u1);
    e0 = e0 * 0.5L + (long double)((unsigned)(short)(((unsigned)x0 ? (unsigned)f0 : ~(2u | 1u)) >> (7u & 31u)) & 1023u);
    goto done;
    v0 = -(unsigned)((int)(unsigned)(0x10000u < r0.y) >= (int)garr[u2 & 7u]);
    if (u2) goto L0;
    if (r0.x) goto L0;
    { unsigned t0; double z0; if ((((unsigned)((int)0xffffffffu >= (int)*mp) << (9u & 31u))) & 1u) { t0 = (unsigned)(*mp && 6u); z0 = (double)((((p0 % (*q0 | 1u)) | 0x60aec1aeu)) & 255u); } if ((((unsigned)((int)0xffffffffu >= (int)*mp) << (9u & 31u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        if ((unsigned)x0) goto L3;
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)(6u >> (garr[u2 & 7u] & 31u)), (unsigned)((int)(unsigned)x0 < (int)(unsigned)((unsigned)x0 == 3u)), (5u ^ (p2 - v0))); }
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)(unsigned)((int)((unsigned)c0 >> (garr[i1 & 7u] & 31u)) < (int)v0), (unsigned)((short)a0[u1 & 3u] > (signed char)m0), 0x7fffffffu); }
            garr[u0 & 7u] = (((unsigned)x0 % ((unsigned)((int)5u < (int)(unsigned)h0) | 1u)) & a0[u1 & 3u]);
            v0 = *q0;
            i1 = i0 & 15u;
            w0 ^= (unsigned long long)(unsigned)((int)u2 >= (int)0xaeddfd01u) << (((unsigned)(0x80000000u < 9u) ^ (unsigned)((unsigned)(p2 && (unsigned)s1) && garr[i1 & 7u])) & 63u);
        }
        if (-(0xffffffffu % ((0x5e5d205bu - (unsigned)(w0 >> 29)) | 1u))) goto L1;
        if (5u) {
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.x = (unsigned)l0;
                switch (g1 & 7u) {
                    if (budget != 0u) { budget -= 1u; u0 = fn0(0x1328dc29u, (fuel << ((r0.y >> (v0 & 31u)) & 31u)), p1); }
                    q0 = &garr[(unsigned)((short)r0.x > (signed char)v0) & 7u];
                    if (budget != 0u) { budget -= 1u; u1 = fn0((((unsigned)b0 % ((unsigned)e0 | 1u)) ^ p0), a0[i0 & 3u], (p0 & u2)); }
                    u0 += (unsigned)(r0.x < (unsigned)(unsigned char)(unsigned)((short)r0.y > (signed char)(g0 + 0x4549fef7u)));
                    case 1u: ;
                    g0 = (unsigned)(signed char)(((unsigned)h1 * 0xa0d7033eu) % (7u | 1u));
                }
                g0 = ((unsigned)h0 ? 0x93de4963u : (unsigned)(fuel || 6u));
                break; (void)(((unsigned)s0 * (unsigned)s1));
                if (4u) goto done;
                if ((m0 * (unsigned)(0xffffffffu || r0.y))) {
                    if ((unsigned)(unsigned char)((unsigned)c0 << (m0 & 31u))) break;
                    u2 = u2 * 0x9e3779b1u + fuel;
                    u0 = (unsigned)(((unsigned)b0 ^ p1) < (unsigned)((int)u1 < (int)0x3e280095u));
                } else {
                    l0 = (long)((unsigned long)l0 + (0x80000000u + garr[i1 & 7u]));
                    if (u2) break;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(~(0x80000000u & (*q0 % (g0 | 1u))), i2, 0xffffffffu); }
                    i0 = (unsigned)(u2 || (unsigned)c0) & 15u;
                }
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0u < i1), (unsigned)x0, (unsigned)c0); }
    u2 += ((unsigned)(short)((unsigned)s1 ^ u3) ^ (0xffffffffu / (0x80000000u | 1u)));
    goto L4;
    switch (i0 & 7u) {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((unsigned)!((unsigned)l0 * v0) & 1023u);
            c0 = (unsigned char)0xffffffffu;
            b0 = -(unsigned)((unsigned)((short)0x10000u > (signed char)(unsigned)e0) < (r0.y / (r0.x | 1u))) != 0u;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0x321cdcfau || u1), (unsigned)(v0 < p1), ((unsigned)(x0 >> 70) + g1)); }
            w0 ^= (unsigned long long)0x80000000u << ((unsigned)((short)(g0 % ((unsigned)((unsigned)(signed char)(unsigned)(a0[i0 & 3u] == 0x7fffffffu) == garr[u2 & 7u]) | 1u)) > (signed char)0x7f40319u) & 63u);
        }
        L2: if (--fuel == 0u) goto done;
        r0.y ^= ((0xe517409cu & a0[u1 & 3u]) - ~(0xb24797f2u | (unsigned)d0));
    }
    r0.y ^= (i2 + ((unsigned)(((unsigned)s0 + 0x3fc18062u) < (unsigned)h0) & p1));
    if ((unsigned)l0) goto L1;
    l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)c1 * (unsigned)f0) < (int)(unsigned)(p0 < (unsigned)((short)a0[i0 & 3u] > (signed char)0x227a376bu))));
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)d0, (unsigned)(signed char)(unsigned)((int)g0 >= (int)g0), (0xfe42fefau ? (unsigned)x0 : p1)); }
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)p2 >= (int)(unsigned)(signed char)((unsigned)(w0 >> 29) << (0xffffffffu & 31u))), (2u << ((5u - (unsigned)c1) & 31u)), (garr[i1 & 7u] & (unsigned)h0)); }
    if (budget != 0u) { budget -= 1u; u0 = fn0((v0 / (g0 | 1u)), (unsigned)(short)(unsigned)((int)0xffffffffu < (int)garr[u2 & 7u]), (unsigned)c0); }
    if ((unsigned)((int)(v0 / (r0.y | 1u)) >= (int)0x7fffffffu)) goto L2;
    l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)((short)i0 > (signed char)((unsigned)c1 >> (((unsigned)h0 ^ p1) & 31u))));
L3: if (--fuel == 0u) goto done;
L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    g1 += (unsigned)(0x7ca5e828u == (unsigned)((int)4u >= (int)(0xac9520d7u / ((4u % (a0[i0 & 3u] | 1u)) | 1u))));
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = ~(unsigned)((int)p0 < (int)(0x3ea7248du & (unsigned)(x0 >> 70)));
        c1 = (signed char)(((unsigned)(w0 >> 29) | (0x7fffffffu % ((unsigned)s0 | 1u))) << ((unsigned)!((unsigned)x0 | 0x10000u) & 31u));
        switch ((~(unsigned)(u3 == (unsigned)f0) * p2) & 7u) {
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((u0 - (u1 ? 0x4f242a49u : 0x7fffffffu)) & 1023u);
            }
            if ((unsigned)!(unsigned)(0x10000u < 0x9000992cu)) {
                if (budget != 0u) { budget -= 1u; u0 = fn0((p1 | (0x10000u + 0x1eff457bu)), (unsigned)((unsigned)((int)0xb8d54364u < (int)u2) == a0[i0 & 3u]), (r0.x | (unsigned)((unsigned)x0 || 6u))); }
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return 0x10000u;
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(r0.x && ((unsigned)c1 + 0x35396db0u)), (unsigned)(unsigned char)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)((unsigned)d0 < 0xffffffffu)), 8u); }
                    *q0 += i2;
                }
                while ((unsigned)e0) { if (--fuel == 0u) goto done;
                    if ((fuel + (m0 >> (0xc22432adu & 31u)))) break;
                    if (m0) {
                        L0: if (--fuel == 0u) goto done;
                        h0 = (short)(((unsigned)(w0 >> 29) / ((m0 << (fuel & 31u)) | 1u)) / (0x80000000u | 1u));
                        if (budget != 0u) { budget -= 1u; u3 = fn2(r0.y, garr[i1 & 7u], 8u); }
                        if (budget != 0u) { budget -= 1u; u3 = fn2((0u >> ((r0.y >> (0x80000000u & 31u)) & 31u)), (unsigned)((int)(unsigned)c0 < (int)(u1 - 6u)), g0); }
                        q0 = &garr[~(unsigned)((short)i2 > (signed char)(unsigned)c1) & 7u];
                        v0 = (0x4b32bb71u | 1u);
                    }
                    if ((unsigned)s1) {
                        if ((unsigned)e0) continue;
                        continue; (void)((u3 | (unsigned)(g0 < 0x796c6919u)));
                        if (~(unsigned)((int)fuel >= (int)0x76278ab7u)) continue;
                        if (budget != 0u) { budget -= 1u; u1 = fn2((i2 + 0x3cbdabbeu), (unsigned)((int)(unsigned)l0 < (int)0x80000000u), fuel); }
                        for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                            f0 = f0 * 0.5f + (float)((0xe27ff8adu ? 6u : 2u) & 255u);
                            f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)(g0 && (unsigned)!(0x7fffffffu ? *mp : *q0)) < (int)a0[i0 & 3u]) & 255u);
                        }
                    }
                    g1 += (u2 | (7u << ((unsigned)(g1 < p0) & 31u)));
                    if (0xa6ebff39u) continue;
                    do { if (--fuel == 0u) goto done;
                        b0 = (7u + p0) != 0u;
                        continue; (void)(~(unsigned)(0xdd07b6a5u || (unsigned)c0));
                        case 1u: ;
                        u3 += (unsigned)s0;
                        d0 = d0 * 0.5 + (double)(((unsigned)((unsigned)x0 && 0x3c53209cu) << (0x10000u & 31u)) & 1023u);
                        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(w0 >> 29) / (u1 | 1u)), (r0.y + garr[i1 & 7u]), (0x10000u << ((unsigned)w0 & 31u))); }
                    } while (i2++ < 6u && (unsigned)((unsigned)((short)a0[u1 & 3u] > (signed char)u0) || 0x36ba06f5u));
                }
                garr[(unsigned)(w0 >> 29) & 7u] = (i0 % (u3 | 1u));
                c0 = (unsigned char)((unsigned)x0 + 3u);
                c0 = (unsigned char)(4u << (i2 & 31u));
            }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                goto L1;
                L2: if (--fuel == 0u) goto done;
                if (0x80000000u) goto L4;
                w0 ^= (unsigned long long)0xbc87f437u << (r0.y & 63u);
            }
            if (0x10000u) continue;
            goto L2;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
                continue; (void)(5u);
                case 0u: ;
                u2 = ((unsigned)x0 + (unsigned)!((0x10000u & 0xb235a62u) ^ (g0 << ((unsigned)c1 & 31u))));
                r0.x = (unsigned)(((unsigned)(x0 >> 70) & ((unsigned)w0 ^ (unsigned)l0)) < p1);
            }
        }
        { unsigned t0; double z0; if ((3u) & 1u) { t0 = (unsigned)((i1 * g0) || 0x7fffffffu); z0 = (double)(((unsigned)((unsigned)(p0 == 2u) || 0x7fffffffu)) & 255u); } if ((3u) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            d0 = d0 * 0.5 + (double)(((unsigned)(x0 >> 70) & (0x80000000u / ((unsigned)c1 | 1u))) & 1023u);
        }
    }
    u2 ^= u2;
    if (budget != 0u) { budget -= 1u; u1 = fn1(6u, 0x4a7329c5u, u1); }
    if ((2u & -(unsigned)((unsigned)(x0 >> 70) < (unsigned)(x0 >> 70)))) goto L2;
    h0 = (short)*q0;
    if (g1) {
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(0x721d5b32u && (unsigned)!((unsigned)c1 - 0x10000u)), (unsigned)(v0 && (fuel + 0u)), (v0 - 0x7fffffffu)); }
        if ((unsigned)e0) goto L3;
        switch ((0xffffffffu * 0xd420543bu) & 7u) {
            case 2u: ;
        }
        s1 = (int)((unsigned)s1 + ~(1u ? i1 : (unsigned)((unsigned)(w0 >> 29) && m0)));
        if ((8u & (unsigned)f0)) goto L2;
        goto L4;
    } else {
        f0 = f0 * 0.5f + (float)(((unsigned)(a0[i0 & 3u] && (p2 / (r0.x | 1u))) ^ (unsigned)(w0 >> 29)) & 255u);
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)(0x75833bfu < (*mp ^ r0.y));
            garr[(unsigned)(w0 >> 29) & 7u] = (unsigned)(a0[i0 & 3u] < 0x10000u);
            if (i0) {
                if ((unsigned)(0x7fffffffu == u1)) break;
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn2((i2 | 0x80000000u), (garr[i1 & 7u] & (unsigned)e0), (unsigned)(signed char)(p1 >> ((unsigned)h0 & 31u))); }
    }
    l0 = (long)((unsigned long)l0 + 0u);
    if (0xefc741d0u) {
        x0 = x0 * 0x100000001b3ull + ((unsigned)e0 & (unsigned)d0);
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 += ((i2 ^ 0x2aec780bu) ^ 0x10000u);
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)(short)((((unsigned)s1 + u0) % (r0.x | 1u)) >> ((unsigned)s0 & 31u));
                break; (void)((unsigned)f0);
            }
            h1 = (unsigned short)(h1 + (0xaa0b4599u | 0xbb6be8d4u));
            u0 = u0 * 0x9e3779b1u + (unsigned)d0;
            q0 = &garr[(unsigned)(short)(unsigned)((unsigned)((unsigned)w0 && 0x6ee1a694u) || i2) & 7u];
        }
        if ((unsigned)((unsigned)((int)i1 < (int)fuel) < u3)) {
            if (u3) {
                u1 = u1 * 0x9e3779b1u + (*mp ? (unsigned)(signed char)(unsigned)((int)garr[u2 & 7u] < (int)0u) : 0x80000000u);
                if ((3u << (i2 & 31u))) goto done;
                i2 = (((unsigned)l0 & (unsigned)x0) - (unsigned)f0) & 15u;
                if (((unsigned)d0 - g1)) goto L2;
            }
            if ((0xffffffffu | (r0.y - p0))) goto L4;
            if ((unsigned)((unsigned)h0 || (unsigned)s1)) goto L3;
            c0 = (unsigned char)(unsigned)((int)u1 < (int)(unsigned)((short)a0[u1 & 3u] > (signed char)(1u + 0x6f1cbba5u)));
            u2 = (unsigned)((short)garr[i1 & 7u] > (signed char)(0x4469f189u | (unsigned)(x0 >> 70)));
            l0 = (long)((unsigned long)l0 + 0x10000u);
        } else {
            g0 = 0x66d361d9u;
            if (u1) goto done;
        }
    } else {
        { unsigned t1; double z1; if ((-(0x29e6147fu << (p1 & 31u))) & 1u) { t1 = r0.x; z1 = (double)(((i2 % ((fuel << ((unsigned)d0 & 31u)) | 1u))) & 255u); } if ((-(0x29e6147fu << (p1 & 31u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            goto L3;
        }
        s0 = (int)-(garr[u2 & 7u] * r0.y);
        *mp = (unsigned)(signed char)(p0 & (unsigned)(p1 == (unsigned)((unsigned)d0 && 7u)));
        u0 = u0 * 0x9e3779b1u + ((u0 - (unsigned)!((unsigned)l0 & 0x10000u)) % (garr[u2 & 7u] | 1u));
    }
    if ((unsigned)((int)p0 < (int)(unsigned)s0)) goto done;
    u3 = u3 * 0x9e3779b1u + (fuel % ((3u % (((unsigned)(short)(0x7fffffffu + a0[i0 & 3u]) >> (a0[u1 & 3u] & 31u)) | 1u)) | 1u));
    if ((unsigned)(p1 || r0.x)) goto L2;
    *q0 += u1;
    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)h0 - i1), (r0.x << (0xe1439b17u & 31u)), (unsigned)s0); }
    if (0u) {
        if (budget != 0u) { budget -= 1u; u1 = fn0((0xe1c7cd56u ? 0u : (unsigned)l0), (i0 % (6u | 1u)), (i2 + 0x734ebee8u)); }
        if ((a0[u1 & 3u] >> ((r0.y | fuel) & 31u))) {
            while (i0++ < 4u && ((unsigned)((short)(unsigned)c1 > (signed char)0x40251584u) & (unsigned)c1)) { if (--fuel == 0u) goto done;
                while (i1++ < 4u && (unsigned)((short)0x3fb7cfd6u > (signed char)(0x367bd8a2u | (unsigned)c0))) { if (--fuel == 0u) goto done;
                    if (p0) break;
                    do { if (--fuel == 0u) goto done;
                        c1 = (signed char)(i2 | (unsigned)(signed char)((r0.x / ((0x822a982eu << (0xaac8668eu & 31u)) | 1u)) | 0x10000u));
                        u1 ^= (0x80000000u | (unsigned)((unsigned)s0 || u2));
                        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)x0 && (unsigned)(7u == (p0 & (unsigned)(short)(p2 | g1)))) & 255u);
                        u1 = u1 * 0x9e3779b1u + (u1 % ((0x2e2cc03fu % (p1 | 1u)) | 1u));
                        q0 = &garr[(u0 - g1) & 7u];
                    } while (i2++ < 4u && (unsigned)((short)(unsigned)s1 > (signed char)m0));
                    if (((unsigned)c0 | (unsigned)((unsigned)c0 && 0x80000000u))) goto L2;
                }
            }
            u3 = (((unsigned)c0 << ((unsigned)h0 & 31u)) - 0x80000000u);
            if ((i0 ? g0 : i1)) {
                s0 = (int)u1;
                goto L2;
                h1 = (unsigned short)(h1 + p0);
                if (-(unsigned)((int)(unsigned)f0 >= (int)*mp)) goto done;
            } else {
                c0 = (unsigned char)(unsigned)!((unsigned)(x0 >> 70) % ((unsigned)d0 | 1u));
                m0 ^= (1u - (u2 % (v0 | 1u)));
            }
            if (((unsigned)s1 * (unsigned)h1)) {
                goto L4;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)(unsigned)((int)u2 >= (int)0x80000000u), (unsigned)c0, (0x10000u - (unsigned)(u0 || (unsigned)w0))); }
            } else {
                L4: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2(((5u / (*mp | 1u)) * (unsigned)f0), ((unsigned)(v0 || (unsigned)h0) / (u2 | 1u)), r0.x); }
                do { if (--fuel == 0u) goto done;
                    v0 = (unsigned)((short)0xb16a2615u > (signed char)-(((unsigned)w0 >> ((unsigned)c1 & 31u)) * (unsigned)(x0 >> 70)));
                } while (i0++ < 5u && r0.y);
            }
            switch (0xffffffffu & 7u) {
                case 2u: ;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)!(unsigned)((int)(unsigned)(i2 || garr[u2 & 7u]) >= (int)(unsigned)h1), ((unsigned)(unsigned char)(unsigned)(1u < m0) + 6u), (garr[i1 & 7u] * (0x10000u & u3))); }
                a0[u3 & 3u] = ((unsigned)(u1 == (unsigned)((unsigned)s1 == *q0)) - (unsigned)(8u < 0x7fffffffu));
                if ((unsigned)((unsigned)(u1 == i1) < p2)) break;
                if (3u) break;
            }
        }
        goto L3;
        w0 = w0 * 6364136223846793005ull + 0x86bda0dfu;
    } else {
        h0 = (short)(unsigned)((int)((unsigned)(fuel < (unsigned)s1) - 6u) >= (int)(0xdb7b5e9eu % (0x3f79122au | 1u)));
        u0 += ((unsigned)((short)u3 > (signed char)g1) * (5u + (m0 % (*q0 | 1u))));
        *q0 = ((9u % (m0 | 1u)) % (((garr[u2 & 7u] / (0x901510d3u | 1u)) / ((unsigned)c1 | 1u)) | 1u));
        switch ((p0 >> ((unsigned)(0x9464a4a2u || 0x80000000u) & 31u)) & 7u) {
            u2 = u2 * 0x9e3779b1u + (unsigned)(unsigned char)(unsigned)((int)((unsigned)s0 ^ a0[u1 & 3u]) < (int)((garr[u2 & 7u] / (p1 | 1u)) | 0x2a2f36a4u));
            if ((i2 ^ p2)) goto L2;
            c0 = (unsigned char)((unsigned)h1 % (0x723d583fu | 1u));
            g0 = ((unsigned)((int)(unsigned)c0 < (int)(unsigned)((int)garr[i1 & 7u] >= (int)0x80000000u)) / ((unsigned)b0 | 1u));
            u1 += p2;
        }
    }
    do { if (--fuel == 0u) goto done;
        *mp = ((unsigned)((int)(9u & (unsigned)c1) < (int)garr[u2 & 7u]) % (1u | 1u));
        *mp = (((0x7fffffffu + garr[u2 & 7u]) ^ v0) % ((unsigned)s1 | 1u));
        a0[(i1 / (7u | 1u)) & 3u] = ((a0[u1 & 3u] << (g1 & 31u)) | i1);
        if (fuel < 8u) return (u3 >> (0x81a50bd4u & 31u));
        l0 = (long)((unsigned long)l0 + (unsigned)((int)0x7fffffffu < (int)(unsigned)(r0.y == u1)));
        if ((unsigned)x0) break;
    } while (i0++ < 7u && 0xffffffffu);
    x0 = x0 * 0x100000001b3ull + (unsigned)s1;
    *q0 = a0[u1 & 3u];
    l0 = (long)((unsigned long)l0 + i2);
    q0 = &garr[((unsigned)((unsigned)f0 && (r0.y - (unsigned)h0)) | ((unsigned)c0 << (0x80000000u & 31u))) & 7u];
    { unsigned t2; double z2; if ((v0) & 1u) { t2 = 0xffffffffu; z2 = (double)(((0xd62b2670u << ((garr[u2 & 7u] << (u3 & 31u)) & 31u))) & 255u); } if ((v0) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        l0 = (long)((unsigned long)l0 + (0x1d52c9ccu / ((unsigned)(short)(unsigned)((short)(unsigned)w0 > (signed char)(0x81184c92u % (0x3934319bu | 1u))) | 1u)));
        { unsigned t3; double z3; if (((*q0 ^ (unsigned)f0)) & 1u) { t3 = ((unsigned)(w0 >> 29) & (unsigned)d0); z3 = (double)((garr[u2 & 7u]) & 255u); } if (((*q0 ^ (unsigned)f0)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            l0 = (long)((unsigned long)l0 + ((unsigned)((*q0 * u2) == 0x4e430425u) << (v0 & 31u)));
            r0.y ^= (unsigned)(signed char)(0x7fffffffu ^ (unsigned)s1);
            goto L3;
        }
        do { if (--fuel == 0u) goto done;
            { unsigned t4; double z4; if ((((unsigned)s0 & i0)) & 1u) { t4 = (9u - 0x7fffffffu); z4 = (double)((0xc4ded56bu) & 255u); } if ((((unsigned)s0 & i0)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                e0 = e0 * 0.5L + (long double)(0x1f4efa42u & 1023u);
                if ((unsigned)(v0 < (unsigned)(u1 && (unsigned)b0))) break;
                q0 = &garr[(unsigned)x0 & 7u];
                if (u1) goto done;
            }
        } while (i0++ < 6u && p2);
        if ((*mp + 3u)) goto L3;
    }
    goto L4;
    if (fuel) {
        if (0x10000u) goto L3;
    }
    goto L4;
    do { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (unsigned)!(4u | u2);
    } while (i0++ < 7u && 0x7fffffffu);
    switch (r0.x & 7u) {
        case 5u: ;
        b0 = (((unsigned)((unsigned)f0 < (unsigned)(x0 >> 70)) ^ u0) % (3u | 1u)) != 0u;
    }
    while (i0++ < 5u && (unsigned)(short)(unsigned)(garr[u2 & 7u] == ((unsigned)b0 * (unsigned)x0))) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(a0[i0 & 3u] < 9u)) break;
            switch ((unsigned)x0 & 7u) {
                s0 = (int)(unsigned)(7u && ((unsigned)s0 % ((m0 ^ garr[u2 & 7u]) | 1u)));
                case 0u: ;
                i1 = (i0 ? fuel : 0x9e9c6d5bu) & 15u;
                goto L4;
                case 4u: ;
                if (budget != 0u) { budget -= 1u; u1 = fn1((v0 << (garr[i1 & 7u] & 31u)), (unsigned)(signed char)((unsigned)(0x498d003eu < u1) & u2), garr[i1 & 7u]); }
            }
        } while (i1++ < 2u && 0x34cc6ab7u);
    }
    c1 = (signed char)(6u | (unsigned)(u3 || ((unsigned)(a0[u1 & 3u] || u0) & p0)));
    r0.y ^= (4u / (((unsigned)h1 | (unsigned)e0) | 1u));
    if (u3) {
        if (u3 == 7u) return (unsigned)((unsigned)(w0 >> 29) || ((unsigned)(w0 >> 29) ? a0[u1 & 3u] : i2));
        { unsigned t5; double z5; if ((((1u % (u1 | 1u)) + (unsigned)(w0 >> 29))) & 1u) { t5 = (unsigned)((i2 >> (v0 & 31u)) && (unsigned)x0); z5 = (double)((~(unsigned)(garr[i1 & 7u] || u0)) & 255u); } if ((((1u % (u1 | 1u)) + (unsigned)(w0 >> 29))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            *mp = 8u;
            if ((unsigned)((int)fuel >= (int)(unsigned)b0)) goto L1;
        }
        h1 = (unsigned short)(h1 + ((unsigned)(x0 >> 70) % (a0[u1 & 3u] | 1u)));
        for (;;) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((unsigned)(short)((1u | u3) % (m0 | 1u)) | (0x80000000u ^ (unsigned)(w0 >> 29)));
            if (fuel < 8u) return (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(a0[i0 & 3u] / (7u | 1u)));
            switch (((unsigned)s1 | ((unsigned)b0 & 4u)) & 7u) {
                if (~(unsigned)((int)m0 >= (int)0xffffffffu)) {
                    case 0u: ;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)7u >= (int)a0[u1 & 3u]), i0, (unsigned)((int)4u >= (int)(unsigned)s0)); }
                    case 1u: ;
                    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)*mp >= (int)r0.y), (p2 ^ u3), garr[i1 & 7u]); }
                    q0 = &garr[(unsigned)((short)3u > (signed char)(unsigned)s1) & 7u];
                } else {
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)w0) || garr[i1 & 7u]), (unsigned)(short)((unsigned)h0 / ((unsigned)((int)0x6973f6d2u < (int)8u) | 1u)), (0xb4661008u / ((unsigned)((int)i1 >= (int)r0.y) | 1u))); }
                        a0[((unsigned)(w0 >> 29) % (u2 | 1u)) & 3u] = (unsigned)(0x7fffffffu || ((unsigned)h1 << (((unsigned)(4u || 6u) * 0x10000u) & 31u)));
                        u0 ^= ((8u >> ((unsigned)(u3 == i0) & 31u)) | 6u);
                    }
                    s1 = (int)((unsigned)s1 + ((unsigned)!(0x216e0938u & r0.x) + i2));
                    u2 = (unsigned)(short)(0xffffffffu % ((((unsigned)c1 & *mp) * v0) | 1u));
                    while (((unsigned)(short)(0xffffffffu + 0x10000u) ^ 0x80000000u)) { if (--fuel == 0u) goto done;
                        g1 += (unsigned)((u1 + ((unsigned)s0 - (unsigned)w0)) == i1);
                    }
                }
                if ((unsigned)d0) goto done;
                case 3u: ;
                g0 = (~((unsigned)(x0 >> 70) & p1) ^ (unsigned)s0);
                if (budget != 0u) { budget -= 1u; u0 = fn0((garr[i1 & 7u] - (0x80000000u % ((unsigned)h0 | 1u))), ((unsigned)b0 & (g0 / (0x10000u | 1u))), (unsigned)((unsigned)x0 && ((unsigned)s1 * m0))); }
            }
            garr[p1 & 7u] = ((unsigned)(i2 && 0x7a44d55eu) >> (0x7fffffffu & 31u));
        }
        if (0x44e3b4a6u) goto L3;
        do { if (--fuel == 0u) goto done;
            q0 = &garr[~((unsigned)((short)u0 > (signed char)a0[i0 & 3u]) ^ 0xffffffffu) & 7u];
            f0 = f0 * 0.5f + (float)((i0 ^ ((unsigned)e0 << ((unsigned)b0 & 31u))) & 255u);
            if (budget != 0u) { budget -= 1u; u0 = fn0(a0[u1 & 3u], (unsigned)((int)0u >= (int)(unsigned)c1), (unsigned)((unsigned)s1 == (unsigned)((unsigned)(w0 >> 29) == u0))); }
            *q0 += -((unsigned)(short)(unsigned)(fuel == r0.y) << (v0 & 31u));
            break; (void)((unsigned)h0);
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)s1 - (unsigned)((unsigned)(x0 >> 70) == 7u)), (unsigned)((int)(unsigned)w0 < (int)garr[u2 & 7u]), a0[u1 & 3u]); }
        } while (i0++ < 4u && (unsigned)((short)(unsigned)((int)0x4d716288u >= (int)(unsigned)b0) > (signed char)(unsigned)w0));
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(w0 >> 29)) goto L4;
        }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)b0) break;
            garr[(unsigned)e0 & 7u] = ((0x80000000u ? (unsigned)d0 : u0) & ~(unsigned)((int)(unsigned)f0 < (int)p1));
        } while (i1++ < 6u && (unsigned)(unsigned char)(((unsigned)f0 - 0x22c4e587u) & *mp));
        if ((unsigned)w0) {
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t6; double z6; if (((unsigned)(unsigned char)((unsigned)b0 % ((unsigned)e0 | 1u))) & 1u) { t6 = (unsigned)s1; z6 = (double)(((m0 << (-(unsigned)(0x72e60f97u || u1) & 31u))) & 255u); } if (((unsigned)(unsigned char)((unsigned)b0 % ((unsigned)e0 | 1u))) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                    if ((unsigned)((0x59a37fc7u % (g0 | 1u)) || (unsigned)l0)) continue;
                    *mp = m0;
                    m0 ^= (unsigned)((short)v0 > (signed char)4u);
                }
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(0x7fffffffu == a0[u1 & 3u]), (unsigned)s0, (unsigned)!(0xffffffffu - u1)); }
                do { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)!(2u & (unsigned)c1) & 1023u);
                } while (i2++ < 2u && ((unsigned)(x0 >> 70) % (r0.y | 1u)));
                if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)c0 ^ a0[i0 & 3u]), u3, ~(unsigned)(8u < u2)); }
                if (r0.y) break;
            }
            x0 = x0 * 0x100000001b3ull + (r0.y >> (((unsigned)(unsigned char)(*mp << (a0[i0 & 3u] & 31u)) / ((u1 << (2u & 31u)) | 1u)) & 31u));
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)d0, (i2 / ((unsigned)h1 | 1u)), (unsigned)(r0.y || g1)); }
            if (budget != 0u) { budget -= 1u; u0 = fn2((0xeb7342fbu ^ 6u), ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)x0) ^ *q0), (2u | (unsigned)c1)); }
            if ((unsigned)c0) break;
            h1 = (unsigned short)(h1 + p2);
        } else {
            b0 = (unsigned)((int)p0 < (int)0x10000u) != 0u;
            if (0xffffffffu) break;
        }
        break; (void)((0x10000u * (u3 | 0u)));
        if ((unsigned)((int)g1 < (int)(unsigned)b0)) continue;
    }
    do { if (--fuel == 0u) goto done;
        h0 = (short)(unsigned)(unsigned char)(u1 / (((unsigned)h0 | u2) | 1u));
        garr[(unsigned)((short)0x8bc01bd1u > (signed char)a0[u1 & 3u]) & 7u] = ((unsigned)(short)(2u ^ (unsigned)s0) >> ((0xe1c48a4au << (i0 & 31u)) & 31u));
        goto L1;
        if (0x45026675u) {
            x0 = x0 * 0x100000001b3ull + (unsigned)!(((unsigned)(w0 >> 29) & (unsigned)s1) & ~((unsigned)w0 / ((unsigned)((int)garr[u2 & 7u] >= (int)0xdecd0908u) | 1u)));
            if (((unsigned)w0 % ((unsigned)((int)0xf84d9841u >= (int)(unsigned)s1) | 1u))) {
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    switch (garr[u2 & 7u] & 7u) {
                        case 4u: ;
                        case 1u: ;
                        w0 ^= (unsigned long long)(unsigned)(0xf4b7331eu < p0) << ((unsigned)((unsigned)(w0 >> 29) || 2u) & 63u);
                    }
                    if ((unsigned)((int)(unsigned)h0 >= (int)(*mp * 0x36ba6e96u))) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((short)p2 > (signed char)*q0) || 0x5f67b3d5u));
                    if ((unsigned)((unsigned)e0 == 0x80000000u)) goto L2;
                    break; (void)((unsigned)(*mp || *q0));
                    s1 = (int)((unsigned)s1 + (0x80000000u % (a0[u1 & 3u] | 1u)));
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0((0x5d6cfc48u + (unsigned)((unsigned)c0 < 9u)), m0, 0x10000u); }
                { unsigned t7; double z7; if (((unsigned)((int)(unsigned)f0 < (int)(unsigned)((unsigned)d0 == garr[i1 & 7u]))) & 1u) { t7 = (unsigned)(p0 < 3u); z7 = (double)(((unsigned)((int)i2 < (int)0x3d7d6460u)) & 255u); } if (((unsigned)((int)(unsigned)f0 < (int)(unsigned)((unsigned)d0 == garr[i1 & 7u]))) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                    v0 = 0x7fffffffu;
                    if ((u3 / (p0 | 1u))) break;
                    h0 = (short)(unsigned)((int)(7u % (i0 | 1u)) < (int)(((unsigned)w0 | 0x80000000u) * 0x5568a449u));
                    if (u2) break;
                }
                e0 = e0 * 0.5L + (long double)(((unsigned)(9u < *mp) | (unsigned)w0) & 1023u);
                if (((garr[u2 & 7u] >> ((unsigned)s1 & 31u)) + a0[i0 & 3u])) break;
                if ((garr[u2 & 7u] ^ (unsigned)(x0 >> 70))) break;
            } else {
                q0 = &garr[(unsigned)((unsigned)!(0x80000000u / (i2 | 1u)) < (unsigned)(((unsigned)x0 << (9u & 31u)) && m0)) & 7u];
                h0 = (short)((7u * 0x10000u) >> ((unsigned)w0 & 31u));
            }
        }
        c1 = (signed char)(unsigned)(short)(unsigned)(i2 < -(unsigned)((short)i1 > (signed char)0xe9335c2fu));
    } while (i0++ < 3u && (unsigned)s1);
    garr[garr[u2 & 7u] & 7u] = (unsigned)(g0 == (p2 - 3u));
    if ((unsigned)((3u | 0x9138d3d4u) < 0x7fffffffu)) goto L1;
    if ((unsigned)((short)0x80000000u > (signed char)(unsigned)(signed char)(unsigned)(0x10000u < 0x7fffffffu))) goto L1;
    q0 = &garr[(v0 << ((r0.y * (i1 + u0)) & 31u)) & 7u];
    goto done;
    switch (((unsigned)(i0 == r0.y) - v0) & 7u) {
        if ((((unsigned)e0 % (0x5ed7bd19u | 1u)) << (0x80000000u & 31u))) goto L1;
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)(m0 || (0x10000u / ((unsigned)e0 | 1u)));
            if (0x660c65ffu) {
                if (0xef65453cu) {
                    case 1u: ;
                }
                case 4u: ;
                do { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)(((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)x0) % (*mp | 1u)) || ~(unsigned)((unsigned)(x0 >> 70) == (unsigned)(x0 >> 70)));
                    if (u3 == 7u) return (unsigned)(((unsigned)s0 & (unsigned)((short)(unsigned)b0 > (signed char)(1u % (garr[u2 & 7u] | 1u)))) || 0x80000000u);
                    if (3u) continue;
                    d0 = d0 * 0.5 + (double)(((unsigned)((int)u0 >= (int)4u) % ((unsigned)(7u || (unsigned)d0) | 1u)) & 1023u);
                    b0 = (a0[i0 & 3u] / ((unsigned)h0 | 1u)) != 0u;
                } while (i1++ < 3u && (unsigned)(0u || -(unsigned)((int)0x83327fefu < (int)a0[u1 & 3u])));
                c1 = (signed char)((garr[u2 & 7u] ? (unsigned)c1 : 0x421accc5u) % ((unsigned)c1 | 1u));
                case 2u: ;
            } else {
                if ((unsigned)(w0 >> 29)) goto L1;
                e0 = e0 * 0.5L + (long double)((unsigned)!(unsigned)((short)u3 > (signed char)r0.y) & 1023u);
                case 0u: ;
                if (budget != 0u) { budget -= 1u; u1 = fn2((p2 ? p1 : u1), (unsigned)((int)(unsigned)s1 >= (int)4u), (unsigned)e0); }
            }
        }
    }
    if (fuel < 8u) return ((unsigned)b0 / (0xb460d6c2u | 1u));
    if ((0xa3676b94u ? 0x80000000u : (unsigned)f0)) goto L1;
    for (;;) { if (--fuel == 0u) goto done;
        s0 = (int)(unsigned)!(unsigned)(0u < ((*mp % (9u | 1u)) + a0[u1 & 3u]));
    }
    a0[(garr[u2 & 7u] / (fuel | 1u)) & 3u] = ((unsigned)(unsigned char)((u2 << (g1 & 31u)) ? (unsigned)f0 : (unsigned)s1) * u0);
    if ((unsigned)(signed char)(garr[u2 & 7u] - (unsigned)c1)) {
        m0 ^= (r0.y | u1);
        u3 ^= ((0x28b2618cu * garr[u2 & 7u]) | (unsigned)((unsigned)w0 == (unsigned)((short)u3 > (signed char)(unsigned)h0)));
        goto L4;
        i1 = (0x80000000u << ((unsigned)((int)0x52aad95au < (int)i2) & 31u)) & 15u;
    } else {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch (((unsigned)(x0 >> 70) / ((unsigned)((int)6u >= (int)(unsigned)b0) | 1u)) & 7u) {
                *mp = (unsigned)(unsigned char)(unsigned)((r0.y - u3) == (unsigned)w0);
                u3 = u3 * 0x9e3779b1u + (unsigned)((short)0x80000000u > (signed char)0x10000u);
                if (budget != 0u) { budget -= 1u; u1 = fn1(~((unsigned)(0x8bd6da66u == u0) & (unsigned)f0), (0xe459a271u & (unsigned)((int)(unsigned)w0 >= (int)i0)), (unsigned)w0); }
                w0 ^= (unsigned long long)*mp << ((2u << ((unsigned)((int)u3 >= (int)(unsigned)((unsigned)(short)((unsigned)(w0 >> 29) % ((unsigned)h1 | 1u)) || u3)) & 31u)) & 63u);
                if ((((unsigned)e0 | *mp) | 0xf3f14cb9u)) continue;
                c1 = (signed char)((unsigned)(x0 >> 70) ? (u1 / (0x52541fa9u | 1u)) : (unsigned)(p2 < (unsigned)c0));
            }
            u3 = u3 * 0x9e3779b1u + 6u;
        }
        g0 = (unsigned)l0;
        if (((p2 << ((unsigned)c1 & 31u)) + p0)) goto done;
    }
    if (((unsigned)(signed char)(i2 + u1) ^ 0x80000000u)) {
        i0 = (unsigned)(p2 || 0x10000u) & 15u;
        g1 += (((i2 << ((unsigned)h1 & 31u)) | (unsigned)c0) / ((unsigned)(u0 && garr[i1 & 7u]) | 1u));
        if ((r0.x * (unsigned)h0)) goto L0;
    }
    goto done;
    if ((unsigned)c0) goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    r0.x = (unsigned)(5u && (unsigned)(signed char)((*mp ? 0xd1cf5998u : (unsigned)l0) % ((unsigned)s0 | 1u)));
    if (u3 == 7u) return *mp;
    { unsigned t0; double z0; if (((unsigned)((short)(unsigned)w0 > (signed char)fuel)) & 1u) { t0 = 0x6b552f8u; z0 = (double)(((unsigned)!(unsigned)(0x80000000u && i0)) & 255u); } if (((unsigned)((short)(unsigned)w0 > (signed char)fuel)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        a0[(u1 * 0xdbfed0b2u) & 3u] = (unsigned)d0;
        w0 ^= (unsigned long long)(garr[u2 & 7u] + v0) << ((p2 ? (6u + (unsigned)((unsigned)c0 && i1)) : 0u) & 63u);
        while (i0++ < 6u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
            q0 = &garr[(unsigned)(signed char)(unsigned)((short)0x80000000u > (signed char)(unsigned)b0) & 7u];
            u2 ^= (0xa9de51a8u / ((8u - *q0) | 1u));
        }
    }
    if (0x80000000u) {
        if (budget != 0u) { budget -= 1u; u1 = fn0((i0 - i1), (r0.x & (unsigned)b0), ((r0.x ^ u3) / (garr[i1 & 7u] | 1u))); }
        L0: if (--fuel == 0u) goto done;
    }
    v0 = (unsigned)(short)(unsigned)(g0 < (unsigned)(i0 == 2u));
    if ((u2 * 1u)) {
        h1 = (unsigned short)(h1 + garr[i1 & 7u]);
        if (-(0u * a0[u1 & 3u])) goto L2;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((0xc59e1ca1u >> (garr[i1 & 7u] & 31u)), 0xed299673u, m0); }
    switch (((unsigned)x0 % (a0[i0 & 3u] | 1u)) & 7u) {
        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((int)9u < (int)*mp) % ((unsigned)x0 | 1u)), ((v0 + i0) | a0[u1 & 3u]), (unsigned)(garr[i1 & 7u] == -(unsigned)((unsigned)x0 == (unsigned)d0))); }
    }
    if (u3 == 7u) return (unsigned)((int)2u >= (int)(unsigned)s0);
    *mp = ((unsigned)((short)*mp > (signed char)i1) * (0x7fffffffu & (unsigned)l0));
    L1: if (--fuel == 0u) goto done;
    v0 = ~((unsigned)(~(garr[u2 & 7u] ? (unsigned)(x0 >> 70) : g1) || 0x7fffffffu) / (u3 | 1u));
    goto L1;
    { unsigned t1; double z1; if ((6u) & 1u) { t1 = *mp; z1 = (double)(((0x7cef5580u ? (unsigned)s1 : p0)) & 255u); } if ((6u) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            continue; (void)((((unsigned)h0 % ((unsigned)c1 | 1u)) & 0x3dc3c252u));
            L2: if (--fuel == 0u) goto done;
            { unsigned t2; double z2; if ((((unsigned)c1 << (u0 & 31u))) & 1u) { t2 = u1; z2 = (double)(((unsigned)((short)(unsigned)(0x51e339e6u || *q0) > (signed char)0x10000u)) & 255u); } if ((((unsigned)c1 << (u0 & 31u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                garr[*mp & 7u] = p0;
                i0 = (unsigned)!((unsigned)((int)(unsigned)f0 >= (int)0x10000u) >> (0x7fffffffu & 31u)) & 15u;
                if ((unsigned)(garr[i1 & 7u] == ((unsigned)s0 % (p1 | 1u)))) break;
                if (u3 == 7u) return ((unsigned)(signed char)((unsigned)c0 ? i0 : i1) & p1);
            }
        }
        w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)(~(i0 * (unsigned)f0) ? *q0 : u0);
    }
    r0.y ^= (unsigned)((int)garr[i1 & 7u] < (int)0x80000000u);
    r0.x = g1;
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(unsigned char)(unsigned)(8u || 0x80000000u));
    } while (i0++ < 5u && (unsigned)((short)(unsigned)h1 > (signed char)0xf49d49efu));
    { unsigned t3; double z3; if (((unsigned)((int)4u < (int)(unsigned)c0)) & 1u) { t3 = ((u3 ^ 1u) + (unsigned)b0); z3 = (double)(((unsigned)c1) & 255u); } if (((unsigned)((int)4u < (int)(unsigned)c0)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
        a0[i1 & 3u] = (0xffffffffu + (u0 ^ (i0 - r0.y)));
        L3: if (--fuel == 0u) goto done;
        if ((g0 >> (~(unsigned)((short)(unsigned)c1 > (signed char)4u) & 31u))) {
            r0.y ^= (0x10000u | p0);
            do { if (--fuel == 0u) goto done;
                c1 = (signed char)i0;
                L4: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(w0 >> 29), ((unsigned)h1 >> (0xbae57b40u & 31u)), (unsigned)((short)0x80000000u > (signed char)(unsigned)h0)); }
                *q0 = 6u;
                if ((unsigned)((short)0x80000000u > (signed char)~(a0[i0 & 3u] << (i0 & 31u)))) break;
                g1 += (a0[i0 & 3u] >> ((unsigned)((garr[i1 & 7u] / (0x10000u | 1u)) || (unsigned)c1) & 31u));
            } while (i0++ < 2u && ~(0x1d81f01du * *mp));
            x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)(0x7e8a326au || (unsigned)(w0 >> 29)) > (signed char)a0[u1 & 3u]);
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)fuel > (signed char)i2), (unsigned)(0x10000u || garr[u2 & 7u]), (unsigned)((int)(0xea980682u / ((unsigned)e0 | 1u)) < (int)(unsigned)(x0 >> 70))); }
        } else {
            w0 = w0 * 6364136223846793005ull + (unsigned)h0;
            if ((unsigned)((unsigned)h0 || (unsigned)l0)) goto L4;
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)((short)(p0 / (0xaab51562u | 1u)) > (signed char)~(r0.x % ((0x80000000u ^ 0x7cf5cceau) | 1u)));
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            b0 = (8u / ((unsigned)(9u < (unsigned)(short)(0xd69dc33eu % (0x80000000u | 1u))) | 1u)) != 0u;
        }
    }
    g0 = ((unsigned)f0 * 0xffffffffu);
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((0x10000u + 0x682ba6afu) & 1023u);
        switch (((unsigned)!(i0 % (0xffffffffu | 1u)) & (unsigned)c1) & 7u) {
            l0 = (long)((unsigned long)l0 + (unsigned)(0xffffffffu == 0u));
            switch (0xffffffffu & 7u) {
                d0 = d0 * 0.5 + (double)((unsigned)d0 & 1023u);
            }
            c1 = (signed char)((unsigned)(i1 < i0) ^ (0x3946a752u / (i0 | 1u)));
            case 4u: ;
        }
        break; (void)(((unsigned)(0u && m0) << (0x7fffffffu & 31u)));
        s0 = (int)((unsigned)(x0 >> 70) ^ (unsigned)((unsigned)w0 < 2u));
        x0 = x0 * 0x100000001b3ull + ((unsigned)w0 & (a0[i0 & 3u] << ((unsigned)b0 & 31u)));
    }
    w0 ^= (unsigned long long)garr[u2 & 7u] << ((unsigned)((unsigned)((int)((unsigned)w0 ? (unsigned)b0 : a0[u1 & 3u]) >= (int)g0) == 5u) & 63u);
    v0 = 0x29023673u;
    w0 = w0 * 6364136223846793005ull + (unsigned)(0x7fffffffu < fuel);
    l0 = (long)((unsigned long)l0 + ((unsigned)(garr[u2 & 7u] < (unsigned)c0) - u2));
    h0 = (short)(unsigned)(u3 && (unsigned)b0);
    switch (((unsigned)d0 / ((unsigned)s1 | 1u)) & 7u) {
        if ((unsigned)((int)(5u << (0x10000u & 31u)) < (int)g0)) break;
        do { if (--fuel == 0u) goto done;
            case 1u: ;
            *q0 += *mp;
            case 5u: ;
        } while (i0++ < 7u && (unsigned)((int)(unsigned)l0 < (int)(unsigned)(signed char)(a0[i0 & 3u] * 0x80000000u)));
        c1 = (signed char)1u;
        a0[(i0 | i0) & 3u] = ((unsigned)((int)i1 >= (int)(unsigned)c0) - (i2 ? (unsigned)d0 : (unsigned)e0));
        if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(w0 >> 29), r0.y, -((1u >> (p0 & 31u)) | 0x80000000u)); }
    }
    goto L1;
    do { if (--fuel == 0u) goto done;
        continue; (void)((unsigned)((short)fuel > (signed char)(unsigned)s1));
        do { if (--fuel == 0u) goto done;
            if (((unsigned)h0 * (unsigned)((unsigned)c1 && 0x22db6ee3u))) goto L0;
            l0 = (long)((unsigned long)l0 + (unsigned)s1);
            if (g0) continue;
            do { if (--fuel == 0u) goto done;
                s0 = (int)(0x10000u << ((fuel & (unsigned)e0) & 31u));
                c0 = (unsigned char)(0x50d787b0u ? (unsigned)d0 : (v0 ^ u1));
                w0 ^= (unsigned long long)(unsigned)(signed char)((unsigned)h1 | (unsigned)x0) << ((unsigned)(u0 || fuel) & 63u);
                *q0 = r0.x;
                break; (void)(0x7fffffffu);
            } while (i2++ < 7u && 7u);
            f0 = f0 * 0.5f + (float)(((unsigned)((short)i2 > (signed char)a0[i0 & 3u]) << ((i2 >> (g0 & 31u)) & 31u)) & 255u);
        } while (i1++ < 2u && (g1 - (unsigned)(a0[i0 & 3u] == (unsigned)h0)));
        while (i1++ < 6u && 5u) { if (--fuel == 0u) goto done;
            if (u2) {
                g1 += (9u & (unsigned)f0);
                c1 = (signed char)(unsigned)(signed char)((9u ? u0 : 0x80000000u) << (*mp & 31u));
                m0 ^= (*q0 ^ ((m0 | p0) / ((unsigned)(u3 || (unsigned)d0) | 1u)));
                if ((unsigned)((int)garr[u2 & 7u] >= (int)0x10000u)) break;
            } else {
                switch (((unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x20f6fca1u) - u2) & 7u) {
                    if (p0) goto L4;
                    u0 = (unsigned)!(unsigned)(p2 == (6u - v0));
                    if (budget != 0u) { budget -= 1u; u1 = fn2(7u, 7u, (0x80000000u % ((g1 - u3) | 1u))); }
                }
                if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)((unsigned)s0 == 2u) / ((unsigned)f0 | 1u)), (fuel >> ((unsigned)l0 & 31u)), (unsigned)d0); }
                *q0 += (0u | (unsigned)e0);
            }
            d0 = d0 * 0.5 + (double)((4u << (((unsigned)x0 ^ v0) & 31u)) & 1023u);
            if (~(0xa8af6a51u * (8u << (1u & 31u)))) break;
        }
        u2 ^= (unsigned)(signed char)(unsigned)(a0[i0 & 3u] && p2);
    } while (i0++ < 6u && 8u);
    for (;;) { if (--fuel == 0u) goto done;
        q0 = &garr[(r0.y / ((u2 ^ (unsigned)e0) | 1u)) & 7u];
    }
    w0 ^= (unsigned long long)7u << ((-(8u / ((unsigned)c0 | 1u)) / (a0[i0 & 3u] | 1u)) & 63u);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)(g1 && ((unsigned)(*mp < a0[u1 & 3u]) - i2));
            { unsigned t4; double z4; if ((((unsigned)((short)(unsigned)s1 > (signed char)0xd2e3b2d6u) << ((unsigned)l0 & 31u))) & 1u) { t4 = (unsigned)(signed char)(unsigned)((short)(unsigned)c0 > (signed char)g1); z4 = (double)(((0xd790b288u >> (5u & 31u))) & 255u); } if ((((unsigned)((short)(unsigned)s1 > (signed char)0xd2e3b2d6u) << ((unsigned)l0 & 31u))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)(w0 >> 29));
                    w0 ^= (unsigned long long)(unsigned)s0 << (5u & 63u);
                    break; (void)((unsigned)((short)0x5862554fu > (signed char)0x4683be99u));
                    break; (void)((unsigned)(v0 || (u1 % (0x10000u | 1u))));
                    switch (r0.x & 7u) {
                        if (budget != 0u) { budget -= 1u; u1 = fn2((u2 ^ u0), ((unsigned)h1 ^ u3), ~(1u % ((unsigned)l0 | 1u))); }
                        case 3u: ;
                        default: ;
                        while (1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u3 = fn0((0x3d75e1b8u / ((unsigned)(signed char)(unsigned)((int)(unsigned)h1 >= (int)i1) | 1u)), (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)(*mp || 9u)), garr[i1 & 7u]); }
                            s0 = (int)(unsigned)s0;
                            c1 = (signed char)(((unsigned)h1 >> (p1 & 31u)) & (m0 + (8u - (unsigned)b0)));
                            b0 = (unsigned)((int)0x7fffffffu >= (int)(((unsigned)s1 % (garr[u2 & 7u] | 1u)) >> (a0[i0 & 3u] & 31u))) != 0u;
                        }
                        garr[p0 & 7u] = (unsigned)(g1 < (unsigned)d0);
                    }
                    h0 = (short)g1;
                }
                if (((unsigned)(w0 >> 29) % ((unsigned)b0 | 1u))) break;
            }
        }
        if ((unsigned)((short)(a0[u1 & 3u] << (i1 & 31u)) > (signed char)u2)) {
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(short)(unsigned)((r0.y ^ u3) == u0), ((unsigned)l0 ^ (unsigned)w0), m0); }
        } else {
            f0 = f0 * 0.5f + (float)((r0.x % ((unsigned)(signed char)((unsigned)(u2 == *mp) >> (p0 & 31u)) | 1u)) & 255u);
        }
        if (7u) break;
    }
    do { if (--fuel == 0u) goto done;
        switch (*mp & 7u) {
            if ((0x6adddc7u + 3u)) goto L3;
        }
        if (-((garr[u2 & 7u] >> (g1 & 31u)) - garr[u2 & 7u])) continue;
        f0 = f0 * 0.5f + (float)(((unsigned)(w0 >> 29) ? (unsigned)b0 : r0.x) & 255u);
        goto L1;
    } while (i0++ < 2u && ((unsigned)((int)6u < (int)u3) | 0x10000u));
    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)(w0 >> 29) / ((fuel / (0x10000u | 1u)) | 1u)), p2, (g0 << (((unsigned)l0 - 3u) & 31u))); }
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)d0 + (unsigned)((unsigned)(x0 >> 70) < p0)), (fuel << ((unsigned)(0x80000000u < 0xffffffffu) & 31u)), *mp); }
    if ((unsigned)x0) {
        h1 = (unsigned short)(h1 + 0x8d71de8au);
        if ((0x80000000u + ((unsigned)s1 - fuel))) goto L1;
        if ((unsigned)h0) goto L4;
        e0 = e0 * 0.5L + (long double)((p1 << ((9u & ((unsigned)s1 + garr[u2 & 7u])) & 31u)) & 1023u);
    } else {
        g1 += 1u;
    }
    goto L4;
    if (budget != 0u) { budget -= 1u; u3 = fn3((0x16e13ecu >> (((unsigned)c0 & (unsigned)h0) & 31u)), ((u1 % (*mp | 1u)) << (m0 & 31u)), 0xec623536u); }
    e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)c0 < (int)0xcfb52b8u) & 1023u);
    if (budget != 0u) { budget -= 1u; u1 = fn3(5u, (unsigned)((unsigned)((short)(unsigned)l0 > (signed char)0x292eea76u) && u2), (unsigned)c0); }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((i2 + (unsigned)c0)) break;
        if (((unsigned)c1 / ((unsigned)d0 | 1u))) break;
        do { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)((p1 >> (((unsigned)s1 - (unsigned)(x0 >> 70)) & 31u)));
                w0 ^= (unsigned long long)(unsigned)(p1 < 0x56d690dfu) << ((unsigned)h1 & 63u);
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(0xffffffffu * *q0) < (int)-(unsigned)((r0.x & a0[u1 & 3u]) == a0[u1 & 3u]));
                if ((((unsigned)l0 | (unsigned)c0) >> (garr[i1 & 7u] & 31u))) break;
                u3 ^= (unsigned)(u3 < (unsigned)(garr[i1 & 7u] && (unsigned)((unsigned)e0 == (unsigned)!(unsigned)(garr[u2 & 7u] || 0xfa17f465u))));
                v0 = (unsigned)(((unsigned)s0 * 2u) < ((unsigned)h1 >> (m0 & 31u)));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(unsigned char)(9u - 0x10000u), (unsigned)s1, (p1 + p0)); }
            if ((unsigned)(unsigned char)(p0 ? u0 : a0[i0 & 3u])) break;
            if ((r0.y % (p1 | 1u))) break;
            r0.y ^= ((unsigned)h0 ? (unsigned)c0 : (unsigned)h1);
        } while (i1++ < 5u && ((unsigned)w0 + (unsigned)(u2 < fuel)));
        h0 = (short)~(fuel - 0xffffffffu);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 12u, 0x8f2e8dc7u, 0xa7d42fefu },
        { 11u, 0xd8318d74u, 0xaa5da3ceu },
        { 15u, 0xa5f0177fu, 0x2ffcbd34u },
        { 8u, 0x7089c523u, 0xf3181112u },
        { 1u, 0x69079b83u, 0xd693003au },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
