// test-ssa-source's program of seed 134000431 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x64297ee7u, g1 = 0x77f81679u;
static unsigned garr[8] = { 0x3d5a9a41u, 0x58a791aau, 0xb56a4257u, 0x36c10760u, 0xe58c21ebu, 0x71c8b84du, 0x162ef946u, 0xcd7b067fu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    u3 += (unsigned)((int)p0 < (int)0x2990de9du);
    if ((unsigned)((int)3u < (int)a0[u1 & 3u])) goto L3;
    { unsigned t0; double z0; if ((~(unsigned)((unsigned)s0 < ((unsigned)e0 / (m0 | 1u)))) & 1u) { t0 = u3; z0 = (double)(((unsigned)h0) & 255u); } if ((~(unsigned)((unsigned)s0 < ((unsigned)e0 / (m0 | 1u)))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        goto L4;
        *mp = ((u3 & (unsigned)c0) % ((unsigned)h0 | 1u));
        h1 = (unsigned short)(h1 + (unsigned)((int)((unsigned)(4u || r0.y) << (0x51d0d574u & 31u)) < (int)((unsigned)l0 / (v0 | 1u))));
    }
    { unsigned t1; double z1; if (((unsigned)((int)4u < (int)*q0)) & 1u) { t1 = ((unsigned)l0 / (i2 | 1u)); z1 = (double)(((u3 ? (unsigned)h1 : 7u)) & 255u); } if (((unsigned)((int)4u < (int)*q0)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        L0: if (--fuel == 0u) goto done;
        c1 = (signed char)(((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)(w0 >> 29)) ? r0.x : u1) >> ((unsigned)s0 & 31u));
        L1: if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            b0 = (5u / (*q0 | 1u)) != 0u;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)b0) goto done;
                break; (void)((unsigned)(unsigned char)(u1 + (6u / (5u | 1u))));
                L2: if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                    if ((unsigned)((short)(4u + (unsigned)s1) > (signed char)u3)) break;
                }
            } while (i1++ < 4u && 0x80000000u);
            g1 += m0;
            u3 = u3 * 0x9e3779b1u + ((unsigned)x0 ^ (garr[i1 & 7u] << (((unsigned)((short)a0[i0 & 3u] > (signed char)i2) | 9u) & 31u)));
            break; (void)((unsigned)((int)g1 < (int)(unsigned)(signed char)((unsigned)(w0 >> 29) << (u0 & 31u))));
            while (i1++ < 4u && (unsigned)((8u ^ 6u) && garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                if (i2) break;
                *q0 += (r0.y >> (0x80000000u & 31u));
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        L4: if (--fuel == 0u) goto done;
                    } while (i0++ < 6u && -(r0.y % (4u | 1u)));
                    if (0xffffffffu) break;
                    if (((unsigned)(unsigned char)(0x7fffffffu ^ u3) ^ 0x7fffffffu)) break;
                }
            }
        } while (i0++ < 6u && (unsigned)l0);
        if (9u) goto L1;
        u1 = (0xc89caba7u ^ (unsigned)(i0 < (unsigned)(garr[u2 & 7u] && (unsigned)x0)));
    }
    do { if (--fuel == 0u) goto done;
        *mp = (unsigned)((unsigned)c0 < (unsigned)s1);
        v0 = v0;
        if (garr[u2 & 7u]) break;
    } while (i0++ < 7u && (unsigned)(0x836ea260u || 0xd4007b89u));
    if ((unsigned)((int)p0 >= (int)(fuel ^ 2u))) goto L3;
    u3 = (unsigned)(signed char)((0xebeb15c6u & (0xbafd64b2u << ((unsigned)((int)(unsigned)b0 >= (int)(unsigned)s1) & 31u))) / (i2 | 1u));
    w0 = w0 * 6364136223846793005ull + 0x901cdd6fu;
    b0 = (p1 >> (0x80000000u & 31u)) != 0u;
    w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)((unsigned)(6u < 0x518e3ad8u) + i2);
    u3 ^= ((0xb33f7d5du / (m0 | 1u)) << (0x7fffffffu & 31u));
    b0 = (~(unsigned)(i2 && (unsigned)d0) | (unsigned)s0) != 0u;
    switch ((garr[u2 & 7u] / (fuel | 1u)) & 7u) {
        a0[(unsigned)(garr[i1 & 7u] && r0.y) & 3u] = (unsigned)(signed char)((unsigned)(w0 >> 29) << ((unsigned)(fuel || fuel) & 31u));
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(unsigned char)((unsigned)s1 + (unsigned)l0)) {
            g0 = (garr[i1 & 7u] << ((unsigned)((0x248fc367u / (0u | 1u)) || (unsigned)(r0.y || (unsigned)x0)) & 31u));
            if ((i1 & (unsigned)((unsigned)b0 || 0x80000000u))) break;
            u3 = u3 * 0x9e3779b1u + ((unsigned)(9u < v0) % (*mp | 1u));
            break; (void)(r0.y);
            w0 ^= (unsigned long long)(i0 - u1) << (0xffffffffu & 63u);
        }
        d0 = d0 * 0.5 + (double)((unsigned)(short)(p2 & (unsigned)h1) & 1023u);
    }
    d0 = d0 * 0.5 + (double)(*mp & 1023u);
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((fuel - r0.x)) continue;
        do { if (--fuel == 0u) goto done;
            if ((2u + i1)) break;
            switch ((0x80000000u << ((unsigned)f0 & 31u)) & 7u) {
                case 1u: ;
                do { if (--fuel == 0u) goto done;
                    case 4u: ;
                } while (i2++ < 4u && 6u);
                e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(((unsigned)h0 ^ 4u) ? (unsigned)b0 : u3) & 1023u);
                *q0 = (unsigned)(0x10000u && (unsigned)c1);
            }
            a0[(unsigned)(unsigned char)(0x10000u - g1) & 3u] = (unsigned)((int)((unsigned)d0 % ((r0.y / (0xffffffffu | 1u)) | 1u)) >= (int)4u);
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (~(8u ? m0 : (unsigned)s0) & (0xf58cca4bu - 0x9d9c61b1u));
                    h1 = (unsigned short)(h1 + (u2 & u2));
                    u0 += (unsigned)((short)(unsigned)(signed char)(0x80000000u % ((unsigned)e0 | 1u)) > (signed char)(0xc043a29du % (0xffffffffu | 1u)));
                    if (u3 == 7u) return (((unsigned)(unsigned char)(0x10000u / (r0.x | 1u)) / (((unsigned)e0 << ((unsigned)h1 & 31u)) | 1u)) - (unsigned)(x0 >> 70));
                    c0 = (unsigned char)((unsigned)(garr[u2 & 7u] || g0) / (((unsigned)f0 + *q0) | 1u));
                    if (((unsigned)x0 ^ (*mp | u0))) continue;
                }
                if ((unsigned)s1) {
                    l0 = (long)((unsigned long)l0 + *mp);
                    *mp = (unsigned)((unsigned)(((unsigned)l0 + (unsigned)s0) == (unsigned)w0) || u1);
                    e0 = e0 * 0.5L + (long double)(((unsigned)h0 | g0) & 1023u);
                    h0 = (short)-((unsigned)(short)(unsigned)((int)(unsigned)((int)fuel >= (int)0x90b822dbu) >= (int)garr[i1 & 7u]) - (unsigned)x0);
                    continue; (void)((unsigned)(m0 || fuel));
                    e0 = e0 * 0.5L + (long double)(6u & 1023u);
                }
                h0 = (short)(unsigned)(unsigned char)(7u / (a0[u1 & 3u] | 1u));
                r0.y ^= ((unsigned)((unsigned)e0 || i0) | 1u);
                *q0 += ((i2 / (4u | 1u)) ? (unsigned)(r0.x < 0x80000000u) : (unsigned)e0);
                if (0x3d51266bu) goto L3;
            }
            if ((p0 / (2u | 1u))) {
                *mp = (unsigned)(unsigned char)(unsigned)(u2 < 0xffffffffu);
                { unsigned t2; double z2; if (((unsigned)((int)7u >= (int)(unsigned)(unsigned char)(unsigned)((int)6u < (int)0xefc8aa2bu))) & 1u) { t2 = (unsigned)f0; z2 = (double)(((unsigned)(u3 && 0x7fffffffu)) & 255u); } if (((unsigned)((int)7u >= (int)(unsigned)(unsigned char)(unsigned)((int)6u < (int)0xefc8aa2bu))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    u0 += ((unsigned)!(unsigned)(u2 == 8u) - 0x10000u);
                    g0 = 0xffffffffu;
                }
            }
        } while (i1++ < 4u && (unsigned)(signed char)(((unsigned)b0 & (unsigned)e0) % (r0.y | 1u)));
        { unsigned t3; double z3; if (((unsigned)(w0 >> 29)) & 1u) { t3 = (0x3817a70eu - *q0); z3 = (double)(((unsigned)f0) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            switch (i2 & 7u) {
                u0 = u0 * 0x9e3779b1u + ((unsigned)c1 + v0);
                for (;;) { if (--fuel == 0u) goto done;
                    u0 = (4u >> (p2 & 31u));
                    c0 = (unsigned char)((unsigned)(0xc686f3abu == u2) ^ (unsigned)(*mp == (unsigned)s1));
                    f0 = f0 * 0.5f + (float)((*q0 / ((unsigned)(unsigned char)(unsigned)((int)0xa29aa614u < (int)(unsigned)(2u && (0xb6e1fa9u << ((unsigned)e0 & 31u)))) | 1u)) & 255u);
                    if ((unsigned)((short)(unsigned)((int)(unsigned)b0 >= (int)0x7707a30du) > (signed char)*q0)) break;
                    case 6u: ;
                    default: ;
                }
                { unsigned t4; double z4; if (((unsigned)((short)fuel > (signed char)0x10000u)) & 1u) { t4 = ((unsigned)(fuel && (unsigned)c0) | (unsigned)d0); z4 = (double)(((a0[u1 & 3u] * (unsigned)((int)i0 >= (int)0xffffffffu))) & 255u); } if (((unsigned)((short)fuel > (signed char)0x10000u)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    if (p0) break;
                    u1 ^= (m0 >> ((unsigned)(((unsigned)c0 * (unsigned)c0) && g1) & 31u));
                    case 5u: ;
                    r0.y ^= (unsigned)s0;
                    g1 += (unsigned)((short)(unsigned)((int)0x7fffffffu >= (int)(unsigned)((u3 % (9u | 1u)) == a0[u1 & 3u])) > (signed char)a0[i0 & 3u]);
                }
            }
            if ((u0 ^ (unsigned)(w0 >> 29))) break;
            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(signed char)((unsigned)x0 * u3) < ((unsigned)(signed char)((unsigned)l0 / ((unsigned)l0 | 1u)) ^ (unsigned)h0)) & 1023u);
            if (r0.y) break;
        }
    }
    do { if (--fuel == 0u) goto done;
        u2 = u2 * 0x9e3779b1u + ((((unsigned)(w0 >> 29) ^ (unsigned)x0) - g1) / (r0.x | 1u));
    } while (i0++ < 7u && 0x80000000u);
    r0.y ^= 0x7d068ad2u;
    h1 = (unsigned short)(h1 + (unsigned)(a0[i0 & 3u] == i1));
    if (*q0) {
        r0.y ^= 0x7fffffffu;
        s1 = (int)((unsigned)s1 + (unsigned)s0);
        f0 = f0 * 0.5f + (float)((((unsigned)c1 * v0) * (p1 / ((unsigned)(2u == (unsigned)s1) | 1u))) & 255u);
    } else {
        if (fuel < 8u) return (0xb13dacafu + (unsigned)l0);
        if ((u2 ? i1 : (unsigned)c1)) {
            c1 = (signed char)((unsigned)s0 ? *q0 : 0xffffffffu);
            g1 += (unsigned)(((unsigned)e0 ^ 8u) == ((3u / (garr[i1 & 7u] | 1u)) + 0x10000u));
            d0 = d0 * 0.5 + (double)((unsigned)((int)(m0 * 0u) < (int)g0) & 1023u);
            if ((0x80000000u / (0xc1f00c02u | 1u))) goto L0;
        }
    }
    if ((((unsigned)b0 - v0) << (7u & 31u))) goto L0;
    if (i0) {
        a0[(unsigned)((short)u0 > (signed char)(unsigned)s0) & 3u] = (fuel - (unsigned)((unsigned)(x0 >> 70) || (unsigned)(0x7fffffffu < 0xddec1a90u)));
    }
    u2 ^= (unsigned)((unsigned)l0 == garr[u2 & 7u]);
    if ((g0 >> ((unsigned)((int)u1 >= (int)0x903e9a3cu) & 31u))) goto L3;
    *q0 = (unsigned)(short)(r0.y / ((unsigned)(garr[u2 & 7u] == p0) | 1u));
    { unsigned t5; double z5; if (((garr[u2 & 7u] ^ (unsigned)(garr[u2 & 7u] == (unsigned)(x0 >> 70)))) & 1u) { t5 = ((unsigned)(0xcd882787u == 0x7fffffffu) + 6u); z5 = (double)(((i1 & 2u)) & 255u); } if (((garr[u2 & 7u] ^ (unsigned)(garr[u2 & 7u] == (unsigned)(x0 >> 70)))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
        while ((unsigned)(u0 && (unsigned)h1)) { if (--fuel == 0u) goto done;
            if ((unsigned)s0) goto L3;
            for (;;) { if (--fuel == 0u) goto done;
                if ((i1 << (u2 & 31u))) {
                    continue; (void)((unsigned)((short)a0[u1 & 3u] > (signed char)a0[i0 & 3u]));
                    f0 = f0 * 0.5f + (float)(*mp & 255u);
                    if (((unsigned)h1 + i1)) break;
                    u2 = u3;
                } else {
                    if (u3 == 7u) return (u0 | (unsigned)s0);
                }
                goto L3;
                if (((unsigned)(9u && 4u) ^ i0)) break;
            }
            break; (void)(0x49bddf32u);
            if (a0[i0 & 3u]) break;
            *q0 += ~((g0 << ((unsigned)s0 & 31u)) * 0u);
            do { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (0x7fffffffu % ((unsigned)(0x68085e60u < i0) | 1u)));
            } while (i1++ < 2u && (a0[u1 & 3u] | v0));
        }
        *q0 = ((i1 + (unsigned)h0) % ((unsigned)((unsigned)w0 == (unsigned)(u0 && (unsigned)c1)) | 1u));
    }
    u3 += (0xffffffffu | (g0 / (m0 | 1u)));
    u3 ^= 1u;
    l0 = (long)((unsigned long)l0 + (unsigned)(short)(8u << ((unsigned)(m0 == (1u / (0x25b4f3bau | 1u))) & 31u)));
    do { if (--fuel == 0u) goto done;
        { unsigned t6; double z6; if (((0x10000u ^ (unsigned)h1)) & 1u) { t6 = (unsigned)((short)r0.y > (signed char)(unsigned)s1); z6 = (double)((((unsigned)d0 ^ i1)) & 255u); } if (((0x10000u ^ (unsigned)h1)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            if ((p2 - (unsigned)(0xafcb3177u || m0))) {
                if ((u0 & ((unsigned)c1 * 0xcb8c585u))) break;
                break; (void)(u1);
                l0 = (long)((unsigned long)l0 + (unsigned)(x0 >> 70));
                if (0x819b4342u) break;
            }
            { unsigned t7; double z7; if (((unsigned)((g0 + garr[u2 & 7u]) < r0.y)) & 1u) { t7 = ((unsigned)c1 ^ 4u); z7 = (double)((((unsigned)f0 << ((unsigned)f0 & 31u))) & 255u); } if (((unsigned)((g0 + garr[u2 & 7u]) < r0.y)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                { unsigned t8; double z8; if (((unsigned)(unsigned char)(g1 << ((unsigned)h1 & 31u))) & 1u) { t8 = (u1 ^ u1); z8 = (double)((-(unsigned)(0x10000u || a0[i0 & 3u])) & 255u); } if (((unsigned)(unsigned char)(g1 << ((unsigned)h1 & 31u))) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                    if ((unsigned)((int)u0 >= (int)(u1 >> (a0[u1 & 3u] & 31u)))) break;
                    do { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)d0);
                        r0.y ^= (unsigned)((int)3u >= (int)(unsigned)!(unsigned)((unsigned)f0 && (unsigned)(~((unsigned)h0 ^ (unsigned)h0) == 4u)));
                        do { if (--fuel == 0u) goto done;
                            break; (void)((*mp >> (-(unsigned)((int)(unsigned)w0 >= (int)a0[i0 & 3u]) & 31u)));
                            h0 = (short)(unsigned)(p1 < i1);
                            *mp = 0x80000000u;
                            if ((unsigned)(u0 < (0x41ba17b4u / (0xe8849838u | 1u)))) break;
                            if (u3 == 7u) return ((unsigned)x0 / (a0[i0 & 3u] | 1u));
                            if ((g1 / ((0x10000u << (r0.y & 31u)) | 1u))) break;
                        } while (i2++ < 7u && (unsigned)((unsigned)(w0 >> 29) && p0));
                        c1 = (signed char)(unsigned)(7u == p2);
                        if ((unsigned)(x0 >> 70)) break;
                    } while (i1++ < 2u && ((unsigned)x0 - (unsigned)((short)(unsigned)s0 > (signed char)0x758780b1u)));
                    for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                            if (((unsigned)!(unsigned)(v0 || fuel) * m0)) goto L4;
                            c1 = (signed char)((((unsigned)s1 & 0x10000u) % ((unsigned)(i0 < a0[i0 & 3u]) | 1u)) % (i0 | 1u));
                            if (((unsigned)s0 + (unsigned)x0)) break;
                            if (5u) break;
                            break; (void)(r0.y);
                            v0 = ~(g0 * i0);
                        }
                    }
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)(*q0 == (unsigned)c1) && ~(r0.x ^ 7u)));
                }
                if ((unsigned)((int)8u >= (int)5u)) break;
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)(w0 >> 29)) break;
                    x0 = x0 * 0x100000001b3ull + ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(signed char)((0xffffffffu ^ 0xffffffffu) * 0x7fffffffu)) % (0xc1f680edu | 1u));
                    d0 = d0 * 0.5 + (double)(0x7fffffffu & 1023u);
                    if ((unsigned)((int)(0x2e983fbau << (0x209899eau & 31u)) >= (int)r0.y)) break;
                }
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (0x80000000u) break;
                    if (r0.y) continue;
                }
                if (p2) break;
            }
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                goto L2;
                u3 ^= ((unsigned)l0 | (0x5d1228fcu | (unsigned)(unsigned char)((unsigned)b0 - (unsigned)e0)));
            }
            w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(unsigned)((int)(unsigned)s1 < (int)v0);
            if (p2) break;
            if ((unsigned)((int)6u >= (int)(u1 % (0x80000000u | 1u)))) break;
        }
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return ((unsigned)((unsigned)e0 < (unsigned)((int)g1 >= (int)(unsigned)(signed char)(m0 << (i0 & 31u)))) << (a0[i0 & 3u] & 31u));
                *q0 = garr[u2 & 7u];
                if ((g1 ^ (unsigned)(garr[u2 & 7u] || 9u))) continue;
            }
            *q0 = ((unsigned)((int)(unsigned)w0 >= (int)v0) << ((unsigned)(x0 >> 70) & 31u));
            if (u1) goto L1;
            if (0x10000u) break;
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)s0;
    } while (i0++ < 6u && (unsigned)(signed char)(v0 << (4u & 31u)));
    q0 = &garr[((0x80000000u / ((unsigned)c0 | 1u)) | 2u) & 7u];
    if ((unsigned)(a0[u1 & 3u] < 0xffffffffu)) goto L3;
    if (u3 == 7u) return *mp;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto done;
    l0 = (long)((unsigned long)l0 + (u1 * ((unsigned)s1 >> ((unsigned)c0 & 31u))));
    while (i0++ < 6u && (unsigned)(i2 || 0x42b82ccau)) { if (--fuel == 0u) goto done;
        s0 = (int)(unsigned)((unsigned)((int)(unsigned)b0 < (int)(0x47a4673au | (unsigned)h1)) && (*mp / (*q0 | 1u)));
        garr[((unsigned)x0 | 3u) & 7u] = ((unsigned)!(unsigned)(0x80000000u || (unsigned)((short)7u > (signed char)(unsigned)c1)) ^ (u0 & *q0));
        if (budget != 0u) { budget -= 1u; u2 = fn0(u3, (unsigned)f0, ~((unsigned)s1 | u0)); }
    }
    l0 = (long)((unsigned long)l0 + (unsigned)((short)(unsigned)(short)(a0[i0 & 3u] / (((unsigned)s0 >> (7u & 31u)) | 1u)) > (signed char)*mp));
    s0 = (int)(3u - 0xcb86894fu);
    if (budget != 0u) { budget -= 1u; u1 = fn0(0xeaec2480u, (unsigned)((unsigned)e0 == g0), 0x80000000u); }
    u0 = u0 * 0x9e3779b1u + (unsigned)(u0 || (unsigned)s1);
    x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((int)(unsigned)e0 < (int)m0) < ((unsigned)(short)(g0 >> (g1 & 31u)) - (unsigned)h0));
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(fuel == (0x7fffffffu / (fuel | 1u))), (u0 >> ((unsigned)(g0 < 0x4d47df52u) & 31u)), (unsigned)(0x42290702u == (a0[i0 & 3u] ^ a0[u1 & 3u]))); }
    c1 = (signed char)(unsigned)(signed char)((1u / ((unsigned)h1 | 1u)) + u0);
    while (i0++ < 6u && ~((unsigned)s0 % ((unsigned)w0 | 1u))) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                continue; (void)((unsigned)((unsigned)!(unsigned)((int)0xd0627c40u < (int)5u) && 0x80000000u));
                garr[(u3 - (unsigned)s0) & 7u] = (unsigned)((short)(unsigned)s1 > (signed char)(unsigned)!(unsigned)(fuel && (unsigned)h0));
                a0[((unsigned)h1 % ((unsigned)s0 | 1u)) & 3u] = ((unsigned)(short)((unsigned)c1 | ((unsigned)((unsigned)b0 || p1) + 9u)) | m0);
                switch ((unsigned)(signed char)(unsigned)(u2 == g1) & 7u) {
                    m0 ^= (*mp | (unsigned)d0);
                }
                if ((unsigned)((int)4u < (int)-(unsigned)((short)garr[i1 & 7u] > (signed char)*mp))) {
                    u1 += (unsigned)b0;
                    s1 = (int)((unsigned)s1 + (unsigned)(short)(unsigned)((unsigned)(signed char)((unsigned)c1 >> (3u & 31u)) == g0));
                    if (p0) goto L0;
                    v0 = (unsigned)h1;
                    L0: if (--fuel == 0u) goto done;
                    if (0xca9915a6u) break;
                }
                i0 = ((garr[i1 & 7u] % ((6u ^ u1) | 1u)) << (i2 & 31u)) & 15u;
            } while (i2++ < 5u && u0);
            if ((unsigned)((unsigned)f0 < p0)) break;
            if (((0x9ee481d3u % (0x97dfdb31u | 1u)) / (0x86082b96u | 1u))) break;
        }
        if ((1u - (unsigned)(unsigned char)(unsigned)(p1 || (unsigned)x0))) {
            if (garr[i1 & 7u]) {
                if (v0) break;
                x0 = x0 * 0x100000001b3ull + ((p0 ? fuel : 0x3d29126eu) | 0x10000u);
                while (m0) { if (--fuel == 0u) goto done;
                    if (((a0[u1 & 3u] & (unsigned)(w0 >> 29)) & 0x80000000u)) goto done;
                    u1 = (garr[i1 & 7u] - (unsigned)w0);
                    c1 = (signed char)(0xa883741du ^ (unsigned)((unsigned)((unsigned)l0 || (6u << (0x984482f2u & 31u))) == garr[i1 & 7u]));
                    if (i0) break;
                }
                do { if (--fuel == 0u) goto done;
                    if (a0[i0 & 3u]) break;
                    if ((unsigned)(8u == (unsigned)((unsigned)(w0 >> 29) || garr[i1 & 7u]))) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)c0 < (int)0xade4c9d8u), (unsigned)(*mp < (unsigned)(signed char)(p2 << (0xc7ab0b5cu & 31u))), ((unsigned)f0 ^ 0x28130c55u)); }
                    u1 += (unsigned)(w0 >> 29);
                    if (((unsigned)(short)(p0 - (unsigned)x0) % (r0.x | 1u))) break;
                } while (i1++ < 5u && a0[u1 & 3u]);
            }
        } else {
            u2 += (unsigned)((unsigned)l0 || a0[u1 & 3u]);
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)d0 == -(0x7fffffffu / (0x96698967u | 1u))), (unsigned)h0, (unsigned)(a0[u1 & 3u] < (unsigned)(x0 >> 70))); }
        }
        garr[fuel & 7u] = (i2 ^ u1);
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(a0[u1 & 3u] / ((unsigned)w0 | 1u)) < (int)a0[u1 & 3u]), (u1 << ((unsigned)b0 & 31u)), ((i1 * 9u) + g1)); }
    }
    s0 = (int)(unsigned)h0;
    *q0 += ((r0.y ^ 9u) - 3u);
    if (r0.x) {
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((unsigned)s1 < u3) + p2), -((unsigned)(i1 < *q0) | i0), *q0); }
        e0 = e0 * 0.5L + (long double)((((unsigned)((unsigned)w0 && (unsigned)s1) + (unsigned)h0) & p1) & 1023u);
        switch ((unsigned)((short)(unsigned)d0 > (signed char)6u) & 7u) {
            case 5u: ;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0(*q0, (4u & 0xffffffffu), r0.x); }
    } else {
        b0 = (unsigned)(unsigned char)((unsigned)x0 << (u3 & 31u)) != 0u;
        u3 = u3 * 0x9e3779b1u + garr[i1 & 7u];
        L1: if (--fuel == 0u) goto done;
        if ((0x8d990b7bu * r0.x)) {
            w0 ^= (unsigned long long)(0x4d8ff3aeu << (g1 & 31u)) << (((*q0 << (garr[i1 & 7u] & 31u)) * m0) & 63u);
            do { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)w0 + u1));
                L2: if (--fuel == 0u) goto done;
                garr[(unsigned)((unsigned)c0 < 0u) & 7u] = (0x33c36ee7u | (unsigned)((v0 & p0) || p0));
                L3: if (--fuel == 0u) goto done;
            } while (i0++ < 3u && i2);
            b0 = (*mp + 0x80000000u) != 0u;
            h1 = (unsigned short)(h1 + ((i1 ? 2u : 5u) % (1u | 1u)));
            c1 = (signed char)(g0 ? i1 : 0u);
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((short)(unsigned)h0 > (signed char)9u) * p2), (7u | 0xffffffffu), 9u); }
        }
    }
    s1 = (int)((unsigned)s1 + (unsigned)c1);
    if ((unsigned)((unsigned)((unsigned)w0 || p2) || (unsigned)s0)) {
        u3 = u3 * 0x9e3779b1u + ((unsigned)(v0 < p1) | (0xf350c16eu / (u2 | 1u)));
        if ((unsigned)(0xd2c93f72u || (u0 - (unsigned)l0))) goto L4;
        w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(short)((unsigned)x0 & (unsigned)s0) == (unsigned)(((unsigned)e0 - 0x2dea942bu) || *mp));
        if (((unsigned)(x0 >> 70) - (unsigned)((short)(unsigned)h1 > (signed char)5u))) goto L2;
        m0 ^= (r0.x ^ (v0 * p2));
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)h1 && 3u), ((unsigned)w0 << ((unsigned)b0 & 31u)), 0x10000u); }
    c0 = (unsigned char)(unsigned)d0;
    L4: if (--fuel == 0u) goto done;
    if ((g0 >> (0x10000u & 31u))) goto L4;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(r0.y || 0x6ee9dc5bu)) break;
        q0 = &garr[(unsigned)((int)((unsigned)(signed char)(unsigned)((unsigned)l0 && r0.y) | (0x7fffffffu >> ((unsigned)c1 & 31u))) >= (int)(unsigned)c0) & 7u];
        if (fuel < 8u) return ((p1 % (garr[i1 & 7u] | 1u)) * a0[i0 & 3u]);
        if (0u) goto L4;
        r0.x = (unsigned)(-(unsigned)(0xffffffffu && i1) < 7u);
    }
    while (i0++ < 5u && (unsigned)(0xd83dfc87u || garr[u2 & 7u])) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)(unsigned)((int)1u < (int)(unsigned)s1) << ((unsigned)((unsigned)c0 == (unsigned)((unsigned)s0 == i0)) & 63u);
        do { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)(0x11157323u < (0xc74e95ffu % ((5u << ((unsigned)s1 & 31u)) | 1u)));
            e0 = e0 * 0.5L + (long double)(((unsigned)s1 * (9u ? (unsigned)b0 : m0)) & 1023u);
        } while (i1++ < 2u && 0x338afbe6u);
    }
    goto L2;
    { unsigned t0; double z0; if ((1u) & 1u) { t0 = ((unsigned)h0 >> (-(p2 << ((unsigned)(x0 >> 70) & 31u)) & 31u)); z0 = (double)(((unsigned)s0) & 255u); } if ((1u) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        goto L4;
    }
    { unsigned t1; double z1; if ((v0) & 1u) { t1 = m0; z1 = (double)((garr[i1 & 7u]) & 255u); } if ((v0) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        l0 = (long)((unsigned long)l0 + (unsigned)(short)(unsigned)((int)5u >= (int)0x5871bf7bu));
        if (*q0) goto L1;
        if (0x80000000u) goto L3;
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)d0);
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(garr[i1 & 7u] == (unsigned)h0), (unsigned)((unsigned)b0 == (v0 * *mp)), (a0[i0 & 3u] >> (9u & 31u))); }
        if ((unsigned)((int)7u >= (int)(unsigned)(1u < p0))) goto L2;
        if ((unsigned)((unsigned)c1 == (unsigned)c0)) {
            break; (void)((unsigned)((unsigned)(x0 >> 70) || 8u));
            if ((unsigned)(w0 >> 29)) break;
            c1 = (signed char)p2;
        }
    }
    do { if (--fuel == 0u) goto done;
        if (7u) break;
        if (0x8ae26379u) break;
        if (0x10000u) break;
        break; (void)((0x7fffffffu - (unsigned)e0));
        if ((unsigned)(g1 == m0)) {
            r0.x = 0x7fffffffu;
            while (i1++ < 5u && a0[i0 & 3u]) { if (--fuel == 0u) goto done;
                if ((i1 + fuel)) break;
                if ((r0.y | (unsigned)(signed char)(unsigned)(u1 || (unsigned)f0))) {
                    if (u3) break;
                    break; (void)(0xffffffffu);
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((0xadf2b915u / (0xea35a189u | 1u)) ^ (unsigned)d0), (unsigned)((short)(8u & (unsigned)f0) > (signed char)3u), (unsigned)(0x1f8dff74u || (unsigned)((int)0xb970ba42u >= (int)7u))); }
                    r0.y ^= (unsigned)(short)(unsigned)((unsigned)h0 || (unsigned)((int)m0 < (int)(g0 + 0xd30a240bu)));
                    if (garr[u2 & 7u]) {
                        u2 ^= fuel;
                    } else {
                        if (r0.x) break;
                        r0.y ^= (unsigned)((int)(unsigned)((unsigned)e0 == (unsigned)(x0 >> 70)) >= (int)p1);
                        q0 = &garr[(unsigned)(short)(a0[i0 & 3u] + 2u) & 7u];
                    }
                }
                h0 = (short)(0x329fc541u % (i0 | 1u));
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((g1 << ((unsigned)(w0 >> 29) & 31u)), (unsigned)((short)3u > (signed char)(unsigned)l0), g1); }
            b0 = ((unsigned)s1 >> (2u & 31u)) != 0u;
            if ((unsigned)(unsigned char)(*q0 * u3)) break;
        }
        goto L0;
    } while (i0++ < 3u && (v0 / ((unsigned)c1 | 1u)));
    *q0 += ((a0[i0 & 3u] - ((unsigned)b0 ^ 6u)) & *mp);
    { unsigned t2; double z2; if ((0xf4a13656u) & 1u) { t2 = (unsigned)(u1 && fuel); z2 = (double)((garr[u2 & 7u]) & 255u); } if ((0xf4a13656u) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        do { if (--fuel == 0u) goto done;
            switch (((*q0 * u3) / (2u | 1u)) & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(short)(unsigned)((unsigned)(signed char)(unsigned)((short)0x80000000u > (signed char)garr[i1 & 7u]) || (unsigned)(x0 >> 70)), (unsigned)((short)(unsigned)((int)(unsigned)x0 < (int)0x10000u) > (signed char)i0), p2); }
                case 6u: ;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)((short)i1 > (signed char)(unsigned)(x0 >> 70)) < (int)p1), -(r0.y * 0xc4c2999bu), (p2 + ((unsigned)h1 - (unsigned)e0))); }
            garr[(fuel / (i0 | 1u)) & 7u] = (unsigned)((unsigned)h0 < (unsigned)(signed char)(unsigned)((int)(unsigned)f0 >= (int)(unsigned)(a0[u1 & 3u] == (0x146a5f32u & garr[i1 & 7u]))));
            while (i1++ < 3u && (unsigned)d0) { if (--fuel == 0u) goto done;
                if (((unsigned)(w0 >> 29) | (unsigned)d0)) goto L1;
                if ((((unsigned)(w0 >> 29) | 0u) << ((unsigned)f0 & 31u))) goto L0;
            }
            while (i1++ < 6u && (m0 / ((unsigned)s1 | 1u))) { if (--fuel == 0u) goto done;
                if (p0) break;
                x0 = x0 * 0x100000001b3ull + ~(0x6e7be124u | ((unsigned)(signed char)(unsigned)((short)m0 > (signed char)(unsigned)(x0 >> 70)) - fuel));
                if ((unsigned)(unsigned char)(unsigned)((unsigned)h0 == 4u)) break;
                v0 = ((unsigned)((short)a0[i0 & 3u] > (signed char)0xb54c2720u) | r0.y);
            }
        } while (i0++ < 6u && (unsigned)((int)-(unsigned)((unsigned)d0 < 8u) >= (int)a0[i0 & 3u]));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)(u1 == (unsigned)w0));
    }
    if ((unsigned)((short)(unsigned)(a0[i0 & 3u] || garr[i1 & 7u]) > (signed char)(unsigned)e0)) goto L1;
    if (budget != 0u) { budget -= 1u; u0 = fn1((0xffffffffu >> (p1 & 31u)), a0[i0 & 3u], ((unsigned)(2u == 0x86722d7fu) << (v0 & 31u))); }
    a0[(0u % (m0 | 1u)) & 3u] = ((8u ? garr[u2 & 7u] : (unsigned)(w0 >> 29)) / ((unsigned)c0 | 1u));
    if (0xffffffffu) {
        if (g0) goto L1;
    } else {
        do { if (--fuel == 0u) goto done;
            v0 = (unsigned)(short)((unsigned)(signed char)(unsigned)(a0[i0 & 3u] && u3) / ((unsigned)(0x7ed90d2du && (unsigned)f0) | 1u));
        } while (i0++ < 2u && (m0 + ((unsigned)f0 - 0u)));
        if ((m0 ^ i1)) goto L3;
        c0 = (unsigned char)(unsigned)s0;
        if ((0xffffffffu / (garr[u2 & 7u] | 1u))) goto L4;
    }
    if (((unsigned)(m0 < g0) | p1)) goto L3;
    goto L4;
    x0 = x0 * 0x100000001b3ull + (unsigned)(0xffffffffu || fuel);
    if (p2) goto done;
    if (-(unsigned)((i0 | r0.y) < (unsigned)f0)) goto L3;
    v0 = 0xf631c893u;
    if (((unsigned)(x0 >> 70) % (((unsigned)c1 % (p2 | 1u)) | 1u))) {
        if (garr[i1 & 7u]) goto L3;
        u2 = u2 * 0x9e3779b1u + (m0 - (unsigned)l0);
    } else {
        w0 = w0 * 6364136223846793005ull + (((unsigned)f0 - (unsigned)((int)(p1 / ((unsigned)s1 | 1u)) >= (int)r0.y)) & 4u);
        l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(i2 ^ (u0 << (0xc01808d5u & 31u))));
        L0: if (--fuel == 0u) goto done;
        if ((0xdcb6ba0eu & 0x2cde1868u)) goto L2;
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        u1 ^= (unsigned)(unsigned char)(unsigned)((short)p2 > (signed char)u3);
        if ((i2 % (a0[i0 & 3u] | 1u))) {
            if ((u0 >> (p1 & 31u))) break;
            u0 += (unsigned)!(2u ^ (i1 << ((unsigned)x0 & 31u)));
            i0 = (unsigned)((unsigned)c1 && *q0) & 15u;
            for (;;) { if (--fuel == 0u) goto done;
                *mp = (unsigned)(signed char)(unsigned)((u2 + ((unsigned)x0 + (u1 | *q0))) && i2);
                if ((v0 * 0x9dea93b1u)) break;
                h1 = (unsigned short)(h1 + 0xffffffffu);
                break; (void)(-(unsigned)(i2 < (unsigned)((short)g0 > (signed char)0xd97d9358u)));
                if (fuel < 8u) return (g1 * u3);
                if (budget != 0u) { budget -= 1u; u1 = fn0((0xffffffffu ^ garr[u2 & 7u]), (unsigned)(v0 && i1), (6u & p1)); }
            }
            { unsigned t0; double z0; if (((unsigned)((int)g1 >= (int)*mp)) & 1u) { t0 = (((unsigned)f0 / ((unsigned)h1 | 1u)) >> (u0 & 31u)); z0 = (double)(((unsigned)!(unsigned)((int)p0 >= (int)(unsigned)b0)) & 255u); } if (((unsigned)((int)g1 >= (int)*mp)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                u3 += garr[u2 & 7u];
                g0 = (unsigned)((short)(unsigned)h0 > (signed char)(0x2b5d1481u << ((unsigned)f0 & 31u)));
            }
            garr[(unsigned)(signed char)(0x7fffffffu + v0) & 7u] = (unsigned)(0x80000000u < ((unsigned)w0 * (unsigned)((short)(unsigned)c0 > (signed char)(unsigned)(a0[i0 & 3u] == 0x7fffffffu))));
        } else {
            r0.y ^= ((unsigned)f0 & 0x3486f60u);
            break; (void)((unsigned)(i1 == (unsigned)b0));
            h0 = (short)((m0 / ((unsigned)((unsigned)d0 == *q0) | 1u)) - (unsigned)((int)0x10000u < (int)v0));
            switch (0x1fcf0a9bu & 7u) {
                g1 += ((unsigned)(v0 == (unsigned)(signed char)(unsigned)((unsigned)l0 || 0x80000000u)) & 6u);
                *q0 = (unsigned)((unsigned)(garr[u2 & 7u] < 5u) || i0);
                if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)b0 | ((unsigned)x0 - g0)), u0, fuel); }
                for (;;) { if (--fuel == 0u) goto done;
                    switch ((unsigned)(((unsigned)(w0 >> 29) * 0xdbb23b9eu) < (unsigned)x0) & 7u) {
                        if (fuel < 8u) return ~(((unsigned)(w0 >> 29) ? v0 : u0) - 0x80000000u);
                        m0 ^= 0xdebc90d3u;
                        L1: if (--fuel == 0u) goto done;
                    }
                }
                u1 += (u3 + (unsigned)l0);
            }
        }
        u1 = 0x7fffffffu;
    }
    u2 ^= (unsigned)(((unsigned)e0 | garr[u2 & 7u]) && (unsigned)((int)*mp < (int)(unsigned)(w0 >> 29)));
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)((int)0xcb5a7708u < (int)0u) < (int)(unsigned)h0), ((unsigned)b0 ^ ((unsigned)w0 ^ 0xf41feac3u)), (u3 - (unsigned)d0)); }
    if ((unsigned)((short)(unsigned)s0 > (signed char)~(4u - 0x10000u))) goto done;
    switch ((unsigned)((unsigned)f0 && r0.x) & 7u) {
        while (i0++ < 7u && 1u) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if (((unsigned)(0x80000000u == (unsigned)(w0 >> 29))) & 1u) { t1 = 0x10000u; z1 = (double)(((unsigned)h0) & 255u); } if (((unsigned)(0x80000000u == (unsigned)(w0 >> 29))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    if ((unsigned)(short)(unsigned)((int)fuel < (int)(unsigned)((unsigned)f0 == 0xffffffffu))) goto done;
                    switch ((unsigned)((u3 ^ (unsigned)b0) && 0x7fffffffu) & 7u) {
                        if ((0xfcba388au >> ((unsigned)d0 & 31u))) continue;
                        h1 = (unsigned short)(h1 + (unsigned)(x0 >> 70));
                        if (0x118e2e27u) break;
                        for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                            case 4u: ;
                            w0 ^= (unsigned long long)p2 << (((unsigned)d0 + (unsigned)w0) & 63u);
                            case 5u: ;
                            if (fuel < 8u) return (unsigned)(signed char)(u3 - (unsigned)(signed char)((unsigned)(x0 >> 70) & r0.y));
                            if ((p2 * -(5u % (*mp | 1u)))) continue;
                            h1 = (unsigned short)(h1 + (unsigned)((((unsigned)b0 - (unsigned)x0) ^ (4u - 0x324a2968u)) && 0u));
                        }
                        d0 = d0 * 0.5 + (double)((((unsigned)d0 >> ((unsigned)(w0 >> 29) & 31u)) | ((p1 % (0xeef278d6u | 1u)) % (a0[i0 & 3u] | 1u))) & 1023u);
                        if (i1) goto L1;
                    }
                    switch ((0x10000u * 0xffffffffu) & 7u) {
                        w0 ^= (unsigned long long)(unsigned)s1 << (0xf4efad0eu & 63u);
                        f0 = f0 * 0.5f + (float)((g0 - (unsigned)((unsigned)((0x675c5a54u & i0) == 0x6d872a7au) && 0xffffffffu)) & 255u);
                        *q0 += r0.y;
                        c0 = (unsigned char)(unsigned)((int)((unsigned)l0 ^ fuel) < (int)0xffffffffu);
                        if ((unsigned)(short)(i2 * (unsigned)((int)(unsigned)w0 >= (int)4u))) goto L0;
                        c0 = (unsigned char)(unsigned)(x0 >> 70);
                    }
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)r0.y < (int)(unsigned)((unsigned)s0 < 0x5aceb537u)), (unsigned)(unsigned char)(u2 * (unsigned)h0), (unsigned)e0); }
                if ((unsigned)w0) break;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)(unsigned)!((unsigned)b0 & 6u) >= (int)(unsigned)e0), ((unsigned)b0 >> (9u & 31u)), (unsigned)((int)r0.y < (int)(unsigned)h0)); }
            }
            if ((unsigned)(unsigned char)(unsigned)(i2 < (unsigned)((int)(unsigned)b0 >= (int)u0))) continue;
            w0 ^= (unsigned long long)i0 << (((unsigned)(w0 >> 29) >> ((unsigned)((short)(unsigned)b0 > (signed char)g1) & 31u)) & 63u);
        }
        i0 = (((unsigned)w0 | (unsigned)w0) / ((a0[u1 & 3u] % ((unsigned)c0 | 1u)) | 1u)) & 15u;
        case 5u: ;
        h1 = (unsigned short)(h1 + ((unsigned)l0 >> (0x29e34107u & 31u)));
        do { if (--fuel == 0u) goto done;
            u0 = u0 * 0x9e3779b1u + (0u + (unsigned)((unsigned)(0x61f44569u || *mp) && 0xffffffffu));
            case 7u: ;
            b0 = 0x170c08e4u != 0u;
            u3 = u3 * 0x9e3779b1u + (((unsigned)((int)9u < (int)0x7fffffffu) << (0x80000000u & 31u)) % (i1 | 1u));
            if (budget != 0u) { budget -= 1u; u0 = fn1((0x10000u * i0), (unsigned)((int)(m0 & (unsigned)h1) < (int)2u), (0xa04aca37u - (unsigned)s1)); }
        } while (i0++ < 4u && 4u);
    }
    do { if (--fuel == 0u) goto done;
        r0.y ^= (r0.x & -(*mp / ((unsigned)s1 | 1u)));
        if ((7u + 0x80000000u)) break;
        *q0 += (unsigned)(2u == (a0[u1 & 3u] - (unsigned)s1));
        a0[r0.x & 3u] = -(((6u | 0x10000u) >> (garr[u2 & 7u] & 31u)) | 5u);
    } while (i0++ < 5u && (garr[i1 & 7u] >> ((unsigned)x0 & 31u)));
    if (fuel < 8u) return (unsigned)((int)(unsigned)x0 >= (int)0x247a6691u);
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((garr[i1 & 7u] & i0) & 7u) {
            c1 = (signed char)-(2u / (garr[u2 & 7u] | 1u));
            *mp = (i0 & (unsigned)s0);
            w0 = w0 * 6364136223846793005ull + p1;
            case 6u: ;
        }
        if ((unsigned)d0) break;
        a0[-(0x7fffffffu * *q0) & 3u] = (unsigned)(g0 < (unsigned)(((unsigned)x0 - *q0) < a0[i0 & 3u]));
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)f0, ~(unsigned)(u1 == 5u), (unsigned)((short)(unsigned)l0 > (signed char)g1)); }
        do { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + ~(g0 % ((g1 << (((unsigned)b0 | 6u) & 31u)) | 1u)));
            if ((unsigned)(short)(unsigned)((short)0xffffffffu > (signed char)(9u / ((unsigned)s0 | 1u)))) break;
            switch (((unsigned)f0 ? (unsigned)c1 : 7u) & 7u) {
                m0 ^= (((unsigned)(unsigned char)(unsigned)((unsigned)b0 < (unsigned)w0) << ((unsigned)h1 & 31u)) - (unsigned)w0);
                if ((*q0 / ((g1 | m0) | 1u))) {
                    u1 = u1 * 0x9e3779b1u + (unsigned)((int)((unsigned)(i1 || (unsigned)x0) / (u2 | 1u)) >= (int)(unsigned)(w0 >> 29));
                } else {
                    x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)(unsigned char)(unsigned)(p2 < i1) == (8u - 0u)) | 0x292d2c69u);
                    if (fuel < 8u) return 0xeade2374u;
                    goto done;
                    case 6u: ;
                }
                v0 = (unsigned)b0;
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((u2 * 0x7fffffffu));
                    if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)h1 << ((unsigned)x0 & 31u)), 6u, (0x10000u | (i1 / (*q0 | 1u)))); }
                    h0 = (short)g1;
                    if ((unsigned)((short)m0 > (signed char)*q0)) continue;
                    if ((unsigned)!(unsigned)((int)(unsigned)h1 < (int)(unsigned)b0)) break;
                    default: ;
                }
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)(0xbdbc037fu == 0xffffffffu));
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)c0, (unsigned)s0, u1); }
                    L2: if (--fuel == 0u) goto done;
                    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (r0.y) goto L2;
                        r0.y ^= (unsigned)(0x10000u < (unsigned)w0);
                        h0 = (short)(unsigned)((int)a0[u1 & 3u] >= (int)(a0[i0 & 3u] ^ (unsigned)b0));
                        if (p2) continue;
                        continue; (void)((unsigned)(unsigned char)((unsigned)x0 & garr[i1 & 7u]));
                    }
                    if ((unsigned)((short)fuel > (signed char)(unsigned)(x0 >> 70))) continue;
                }
            }
        } while (i1++ < 2u && 3u);
        goto L4;
    }
    L3: if (--fuel == 0u) goto done;
    m0 ^= (unsigned)((int)0xfdd73796u >= (int)g1);
    e0 = e0 * 0.5L + (long double)((unsigned)w0 & 1023u);
    while (i0++ < 4u && *q0) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)(fuel && (unsigned)((short)0xda9bc636u > (signed char)((unsigned)((unsigned)c0 && v0) & p2)));
        i0 = (unsigned)((short)(unsigned)f0 > (signed char)(unsigned)((int)i1 >= (int)(unsigned)((int)a0[i0 & 3u] < (int)0x7fffffffu))) & 15u;
        break; (void)((0u - (unsigned)d0));
        e0 = e0 * 0.5L + (long double)((a0[u1 & 3u] | (unsigned)(fuel && 0x10000u)) & 1023u);
        garr[(0xffffffffu - (unsigned)s1) & 7u] = (unsigned)x0;
    }
    l0 = (long)((unsigned long)l0 + (unsigned)c0);
L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)((int)r0.y < (int)u0)) {
        if ((unsigned)((int)0x80000000u < (int)(unsigned)((int)i0 >= (int)(unsigned)c0))) {
            w0 = w0 * 6364136223846793005ull + (*mp + (unsigned)s0);
            e0 = e0 * 0.5L + (long double)(u3 & 1023u);
            i2 = (unsigned)(signed char)(a0[i0 & 3u] * (unsigned)l0) & 15u;
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                while (i1++ < 6u && r0.y) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)l0 - i0), (unsigned)((int)(0xffffffffu | (unsigned)b0) < (int)i1), (unsigned)!(unsigned)(*q0 == (unsigned)!(*mp - 0x80000000u))); }
                    L0: if (--fuel == 0u) goto done;
                }
                break; (void)((((unsigned)s1 / ((unsigned)d0 | 1u)) + 0x80000000u));
                i1 = 9u & 15u;
                e0 = e0 * 0.5L + (long double)((u3 % ((unsigned)((unsigned)(w0 >> 29) || ((unsigned)l0 << (r0.y & 31u))) | 1u)) & 1023u);
            }
            v0 = (unsigned)(short)(unsigned)((unsigned)((int)(unsigned)(((unsigned)(x0 >> 70) >> (i0 & 31u)) || g0) >= (int)u0) == p2);
        }
        g0 = (*mp * (unsigned)((unsigned)(w0 >> 29) || 0x6a3f7ec0u));
    } else {
        if ((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)c1)) {
            q0 = &garr[(unsigned)(signed char)(unsigned)(0x6ef65abfu && (g1 ? (unsigned)s1 : 8u)) & 7u];
            { unsigned t0; double z0; if (((unsigned)(r0.y && (unsigned)((short)u0 > (signed char)(unsigned)b0))) & 1u) { t0 = ((unsigned)s0 ^ (unsigned)c0); z0 = (double)((1u) & 255u); } if (((unsigned)(r0.y && (unsigned)((short)u0 > (signed char)(unsigned)b0))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                r0.y ^= (i2 * 0x10000u);
                if (budget != 0u) { budget -= 1u; u0 = fn0(a0[i0 & 3u], ((unsigned)f0 | i1), (unsigned)((0xffffffffu & (unsigned)s1) || (unsigned)c1)); }
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)s1 > (signed char)(unsigned)((int)(unsigned)(unsigned char)(3u % ((unsigned)l0 | 1u)) < (int)i0));
                for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (v0 / (*q0 | 1u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn2(-(unsigned)(garr[i1 & 7u] < (unsigned)((short)0x30b07206u > (signed char)0x10000u)), 7u, g1); }
                    u2 += (((unsigned)((int)(unsigned)l0 < (int)-(unsigned)(0x80000000u == (unsigned)l0)) >> (fuel & 31u)) + a0[u1 & 3u]);
                }
                goto L3;
            }
        } else {
            b0 = (p2 % (((0x156a84a5u - u3) ^ 0x64d99eccu) | 1u)) != 0u;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0(r0.y, 3u, (unsigned)(signed char)(g0 ^ (r0.x + r0.x))); }
    }
    if (((unsigned)h0 ^ *q0)) goto L2;
    goto L3;
    goto L3;
    *mp = (unsigned)((0u ^ 0x7121a951u) && (i2 + 3u));
    do { if (--fuel == 0u) goto done;
        *q0 = (unsigned)(i0 && u3);
        if ((0x515e0555u << (a0[u1 & 3u] & 31u))) goto L0;
        if (~(9u + (unsigned)c1)) {
            switch ((unsigned)((unsigned)(unsigned char)(r0.y - i1) < 8u) & 7u) {
                switch ((garr[i1 & 7u] ^ (unsigned)(a0[i0 & 3u] || 0x80000000u)) & 7u) {
                    h0 = (short)(unsigned)((int)(unsigned)(signed char)(u0 % ((unsigned)s0 | 1u)) >= (int)(r0.y - (unsigned)b0));
                    r0.y ^= (unsigned)l0;
                    while ((unsigned)(short)(unsigned)((unsigned)c1 || 7u)) { if (--fuel == 0u) goto done;
                        if (-((unsigned)f0 - i0)) break;
                        for (;;) { if (--fuel == 0u) goto done;
                            *q0 += (unsigned)((unsigned)((unsigned)s0 < ((unsigned)c1 * p0)) < (unsigned)(short)(unsigned)(u0 && (unsigned)(x0 >> 70)));
                            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(0x80000000u ? ((unsigned)l0 % (garr[i1 & 7u] | 1u)) : 0x5883658u);
                            g0 = ((unsigned)f0 & (u2 >> ((unsigned)((short)garr[u2 & 7u] > (signed char)0x10000u) & 31u)));
                            c0 = (unsigned char)((unsigned)((unsigned)x0 < g1) >> (0x10000u & 31u));
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn0(0x80000000u, -((unsigned)s0 << ((r0.y % ((unsigned)s0 | 1u)) & 31u)), (0xe01dfc04u ^ r0.y)); }
                    }
                    u3 += u2;
                    e0 = e0 * 0.5L + (long double)(0x7fffffffu & 1023u);
                    L1: if (--fuel == 0u) goto done;
                }
                if ((g1 ^ (unsigned)((short)(unsigned)c0 > (signed char)0x60b2d3d3u))) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(x0 >> 70), (unsigned)(unsigned char)((3u << ((unsigned)h1 & 31u)) + fuel), (r0.y - a0[u1 & 3u])); }
                    switch ((((unsigned)l0 & 0x54848c1fu) | 0x27355bdbu) & 7u) {
                        do { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(x0 >> 70), (0x7fffffffu >> (0xffffffffu & 31u)), garr[i1 & 7u]); }
                            case 6u: ;
                            if (budget != 0u) { budget -= 1u; u2 = fn1((p2 >> ((unsigned)s1 & 31u)), (unsigned)x0, r0.x); }
                            w0 = w0 * 6364136223846793005ull + (unsigned)h0;
                            if (budget != 0u) { budget -= 1u; u3 = fn2((((unsigned)s1 * p2) ^ 0x27f8a68u), -(garr[i1 & 7u] >> ((i1 >> (v0 & 31u)) & 31u)), (*mp & (unsigned)((int)p0 >= (int)0x7fffffffu))); }
                        } while (i1++ < 3u && (garr[u2 & 7u] * ((unsigned)h1 + (unsigned)f0)));
                    }
                    L2: if (--fuel == 0u) goto done;
                } else {
                    if (i0) break;
                }
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    c1 = (signed char)(((unsigned)(u2 || r0.x) * m0) - (8u >> (0x80000000u & 31u)));
                }
                case 6u: ;
                *q0 += (4u & (unsigned)(short)(unsigned)((short)(unsigned)((unsigned)s1 == (unsigned)h1) > (signed char)0xc1290072u));
                *q0 += (unsigned)((fuel - v0) || ((unsigned)x0 >> (0x10000u & 31u)));
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0(0xffffffffu, (unsigned)(u2 == ((unsigned)d0 >> (u3 & 31u))), (v0 & u2)); }
        }
        r0.x = 8u;
        w0 = w0 * 6364136223846793005ull + (unsigned)e0;
    } while (i0++ < 7u && (~(u0 ^ 0x6a8ae3c2u) >> (0x10000u & 31u)));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 = (u1 & (unsigned)(-(unsigned)(v0 || (unsigned)(r0.x && (unsigned)e0)) && (unsigned)e0));
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (i1) {
                r0.y ^= i0;
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (9u << ((unsigned)(x0 >> 70) & 31u)) != 0u;
                    f0 = f0 * 0.5f + (float)(((~(unsigned)((int)u1 >= (int)(unsigned)c1) / ((unsigned)s1 | 1u)) * 2u) & 255u);
                    if ((unsigned)h1) break;
                    { unsigned t1; double z1; if (((m0 - (unsigned)s1)) & 1u) { t1 = (unsigned)b0; z1 = (double)((*mp) & 255u); } if (((m0 - (unsigned)s1)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                        if (budget != 0u) { budget -= 1u; u0 = fn1(v0, ((u2 ^ (unsigned)e0) - 0x70f6e492u), p0); }
                        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((int)r0.x < (int)(unsigned)((int)1u < (int)u3)), (g0 ^ ((unsigned)f0 + p2)), (0x8bdd7972u ^ 0x7b1af49bu)); }
                    }
                    *q0 = (fuel >> ((unsigned)((short)(unsigned)((int)(unsigned)((int)*q0 < (int)a0[i0 & 3u]) >= (int)g1) > (signed char)p2) & 31u));
                    if (budget != 0u) { budget -= 1u; u1 = fn2((3u * (p2 * (unsigned)h0)), ((unsigned)b0 / (((unsigned)c1 + g1) | 1u)), r0.x); }
                }
                if (7u) break;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    h0 = (short)(unsigned)c1;
                    u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)c0 && (unsigned)!(unsigned)(g0 == 0x38c2d96du));
                    continue; (void)(r0.y);
                    b0 = (unsigned)(unsigned char)((unsigned)((unsigned)(signed char)(0xcf8f61a0u % (i1 | 1u)) == a0[i0 & 3u]) ^ (unsigned)x0) != 0u;
                }
                if ((a0[i0 & 3u] / (8u | 1u))) {
                    u1 ^= (unsigned)(signed char)(7u | (unsigned)(0x80000000u < (p2 * (unsigned)h1)));
                    q0 = &garr[(i2 << ((0x4cea711bu + i2) & 31u)) & 7u];
                    continue; (void)(((u2 + (unsigned)h1) << (i0 & 31u)));
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(signed char)(unsigned)((unsigned)!(v0 % (i0 | 1u)) < 0xb894be97u), u3, fuel); }
                    h1 = (unsigned short)(h1 + (unsigned)(u3 < 0xccfa7bb2u));
                } else {
                    if ((i2 % (fuel | 1u))) break;
                    g1 += 7u;
                }
            }
            r0.y ^= (unsigned)((short)g1 > (signed char)0xffffffffu);
            if (budget != 0u) { budget -= 1u; u3 = fn0((0x10000u + fuel), (unsigned)((short)0xa2ec6571u > (signed char)((unsigned)s0 | fuel)), (*q0 + ((unsigned)b0 + 0x10000u))); }
            if (0x80000000u) {
                m0 ^= (a0[u1 & 3u] ? 0x7fffffffu : fuel);
                if ((unsigned)((unsigned)w0 == (8u ^ 8u))) {
                    if (fuel < 8u) return (unsigned)((unsigned)(w0 >> 29) || 0x80000000u);
                    switch ((unsigned)(i0 == (unsigned)((unsigned)e0 || 6u)) & 7u) {
                        h1 = (unsigned short)(h1 + (unsigned)((int)(0x7fffffffu ^ 0x7fffffffu) < (int)u3));
                        { unsigned t2; double z2; if ((((unsigned)(8u || i1) >> (*q0 & 31u))) & 1u) { t2 = (unsigned)(signed char)(unsigned)(0xffffffffu < (unsigned)s0); z2 = (double)((((unsigned)s0 ? u2 : (unsigned)x0)) & 255u); } if ((((unsigned)(8u || i1) >> (*q0 & 31u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                            g0 = (unsigned)((int)(unsigned)h1 < (int)(unsigned)w0);
                        }
                        *q0 += (unsigned)(0xd1b0f4ddu || 2u);
                    }
                    h1 = (unsigned short)(h1 + (g1 & 5u));
                    u1 = ((u3 * (unsigned)(x0 >> 70)) >> ((unsigned)d0 & 31u));
                } else {
                    c0 = (unsigned char)((unsigned)(p1 < 6u) - -((unsigned)w0 << ((unsigned)w0 & 31u)));
                    do { if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + (((unsigned)(short)(u1 ^ 0x7fffffffu) % (i2 | 1u)) >> ((6u - r0.y) & 31u));
                    } while (i2++ < 2u && (0x8b99fe6bu % (8u | 1u)));
                    break; (void)(i1);
                }
            } else {
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)u3 > (signed char)u3), 0xf8e90d8du, ((unsigned)(x0 >> 70) ^ (m0 << (g1 & 31u)))); }
                    h0 = (short)((unsigned)c1 & ((unsigned)(x0 >> 70) % (*mp | 1u)));
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((u3 << (g1 & 31u)) || (unsigned)l0), (unsigned)((int)(unsigned)c0 < (int)0x10000u), ((7u + u0) % (*q0 | 1u))); }
            }
        }
        g0 = (unsigned)((unsigned)(4u < (unsigned)e0) || (p0 / (((unsigned)(x0 >> 70) << (garr[i1 & 7u] & 31u)) | 1u)));
        s0 = (int)(unsigned)((int)(unsigned)(x0 >> 70) < (int)u3);
    }
    s0 = (int)((i2 - (unsigned)s1) + ((unsigned)w0 / ((u0 ^ u1) | 1u)));
    *mp = (unsigned)((short)7u > (signed char)p1);
    if ((unsigned)(0x10000u == u0)) goto L0;
    do { if (--fuel == 0u) goto done;
        { unsigned t3; double z3; if (((unsigned)((unsigned)(r0.y || p0) == (unsigned)(x0 >> 70))) & 1u) { t3 = ((i2 + 5u) + r0.x); z3 = (double)(((unsigned)((int)*mp >= (int)((unsigned)l0 % (u2 | 1u)))) & 255u); } if (((unsigned)((unsigned)(r0.y || p0) == (unsigned)(x0 >> 70))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            u0 += (0u + (unsigned)((int)(unsigned)((unsigned)((short)0x7cf72e97u > (signed char)(unsigned)d0) && 0xffffffffu) >= (int)(unsigned)w0));
            a0[r0.x & 3u] = 0x10000u;
        }
        break; (void)((unsigned)((short)a0[i0 & 3u] > (signed char)(v0 / (g1 | 1u))));
        e0 = e0 * 0.5L + (long double)(i1 & 1023u);
        for (;;) { if (--fuel == 0u) goto done;
            if (g0) break;
            if (((unsigned)c0 & (a0[i0 & 3u] >> (0xa852b771u & 31u)))) break;
            u1 ^= (m0 << ((unsigned)((int)0x974116a6u < (int)0xffffffffu) & 31u));
            if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)f0 % (0x4f9f4c22u | 1u)), (unsigned)(u3 < ~(unsigned)(garr[u2 & 7u] < a0[u1 & 3u])), ((unsigned)h0 * (unsigned)b0)); }
        }
        if ((i1 & 0x10000u)) break;
    } while (i0++ < 2u && (unsigned)(g0 && 0x80000000u));
    c1 = (signed char)(unsigned)c1;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)c0, (unsigned)(x0 >> 70), -(unsigned)((int)i0 < (int)0x7fffffffu)); }
        *q0 = (unsigned)!(unsigned)((unsigned)!(unsigned)((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)garr[i1 & 7u]) < 0xfd8ec4d6u) || 0xe9f4bbb6u);
        h1 = (unsigned short)(h1 + (unsigned)(((unsigned)c1 ? p1 : (p2 ^ 0x39d7ae65u)) && (unsigned)w0));
        do { if (--fuel == 0u) goto done;
            { unsigned t4; double z4; if ((p2) & 1u) { t4 = m0; z4 = (double)(((unsigned)h0) & 255u); } if ((p2) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                w0 ^= (unsigned long long)(unsigned)l0 << (v0 & 63u);
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(*mp == ((unsigned)c1 ^ p0)), (unsigned)(short)((0x10000u << (m0 & 31u)) + *q0), (unsigned)h0); }
            }
        } while (i1++ < 4u && (unsigned)s1);
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)(unsigned)f0 < (int)(unsigned)((short)r0.x > (signed char)(unsigned)d0)), ((unsigned)c0 << (v0 & 31u)), (0x7fffffffu + (unsigned)((short)*mp > (signed char)(unsigned)h1))); }
    }
    for (;;) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)((short)9u > (signed char)(unsigned)((int)r0.x < (int)(unsigned)e0)));
        L3: if (--fuel == 0u) goto done;
        u3 = ~((unsigned)(0xee75e840u < 5u) | (i0 >> ((0x6a3ea599u % (*q0 | 1u)) & 31u)));
        r0.x = (unsigned)((unsigned)l0 < (6u >> ((unsigned)(p1 && *mp) & 31u)));
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(0u || v0)) {
                if (fuel < 8u) return (-((g0 % (9u | 1u)) * *q0) / (3u | 1u));
                if ((0x6cb09969u << (0x80000000u & 31u))) {
                    h1 = (unsigned short)(h1 + ((2u ? (unsigned)h1 : u2) ? g1 : 0x8f440054u));
                } else {
                    break; (void)((fuel | (unsigned)l0));
                    *q0 = ((unsigned)l0 / ((i1 ^ (u2 ^ (garr[i1 & 7u] | (unsigned)s0))) | 1u));
                }
                g1 += (unsigned)(m0 && (2u >> (0xb141a4fau & 31u)));
                L4: if (--fuel == 0u) goto done;
                { unsigned t5; double z5; if ((-((unsigned)c0 & (unsigned)(signed char)(*mp << (0xf78576f3u & 31u)))) & 1u) { t5 = (fuel / (p1 | 1u)); z5 = (double)((m0) & 255u); } if ((-((unsigned)c0 & (unsigned)(signed char)(*mp << (0xf78576f3u & 31u)))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                    if ((0x4d1947fbu + 0x588cbd1eu)) break;
                }
            } else {
                m0 ^= ((unsigned)(u0 < (unsigned)h0) << (4u & 31u));
            }
            if (0x9f3dbe48u) break;
        } while (i1++ < 4u && ((i0 ^ *mp) >> (0xffffffffu & 31u)));
    }
    { unsigned t6; double z6; if ((8u) & 1u) { t6 = (u2 ^ 0x80000000u); z6 = (double)((0x80000000u) & 255u); } if ((8u) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
        m0 ^= (0x80000000u * (unsigned)((0x8a584d82u | v0) < (unsigned)(r0.x && 0xd255fc7eu)));
        b0 = (unsigned)((int)(unsigned)c1 >= (int)(unsigned)!(0xc6a680adu % ((unsigned)h1 | 1u))) != 0u;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn2((v0 ? 0xd459ad33u : 0xffffffffu), a0[u1 & 3u], garr[i1 & 7u]); }
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)f0 ^ v0), (unsigned)((int)(unsigned)((int)(unsigned)h1 >= (int)fuel) < (int)4u), (unsigned)(3u || (unsigned)(short)(*mp & u2))); }
    if (budget != 0u) { budget -= 1u; u0 = fn2((0x80000000u * p2), (a0[i0 & 3u] - -(unsigned)((unsigned)h0 == p2)), ~((r0.y | p2) % ((unsigned)(x0 >> 70) | 1u))); }
    u2 += (unsigned)(signed char)(unsigned)(*q0 || p2);
    if (r0.y) goto done;
    { unsigned t7; double z7; if (((unsigned)(0xffffffffu < i2)) & 1u) { t7 = (0x97298916u / ((unsigned)(short)(*mp / (r0.x | 1u)) | 1u)); z7 = (double)((i2) & 255u); } if (((unsigned)(0xffffffffu < i2)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
        g1 += (unsigned)(signed char)(((unsigned)(w0 >> 29) ^ u2) | (unsigned)(x0 >> 70));
        h0 = (short)(unsigned)((short)(unsigned)(signed char)(a0[i0 & 3u] + 8u) > (signed char)((unsigned)(w0 >> 29) | 0xffffffffu));
    }
    if (((unsigned)((unsigned)e0 || *q0) & (unsigned)c1)) {
        switch ((0x5e15566bu | 0x6f5a8888u) & 7u) {
            if (u3 == 7u) return (unsigned)((short)(unsigned)(a0[u1 & 3u] && (unsigned)c1) > (signed char)0x7fffffffu);
            i0 = ((1u + (unsigned)d0) / ((unsigned)((unsigned)c0 && (unsigned)s1) | 1u)) & 15u;
            if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)(x0 >> 70) << (((unsigned)(w0 >> 29) % (*q0 | 1u)) & 31u)), (0u ? i0 : garr[u2 & 7u]), ((0x14d1a515u >> (u2 & 31u)) % (0x10000u | 1u))); }
            *mp = (unsigned)(-(0x10e66152u | (unsigned)(unsigned char)(unsigned)(1u && v0)) && (unsigned)!(0x39e24887u - a0[i0 & 3u]));
        }
        for (;;) { if (--fuel == 0u) goto done;
            if ((0xda9092c3u | 5u)) {
                if ((unsigned)!(unsigned)((int)(unsigned)(u3 && i0) >= (int)u1)) continue;
            } else {
                u2 = (unsigned)(x0 >> 70);
                while (i1++ < 3u && p0) { if (--fuel == 0u) goto done;
                    if (0x80000000u) break;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn2(9u, 0xdd9a2964u, ((unsigned)w0 / ((unsigned)e0 | 1u))); }
                if ((unsigned)(signed char)(p0 + (unsigned)((short)0x10000u > (signed char)3u))) continue;
            }
        }
        i0 = (unsigned)((short)p1 > (signed char)((g0 ^ *mp) ^ fuel)) & 15u;
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)0x7fffffffu < (int)i2), (3u & 0x7fffffffu), i1); }
    } else {
        u2 = u2 * 0x9e3779b1u + (unsigned)((int)garr[i1 & 7u] < (int)0x7fffffffu);
        switch (0x7fffffffu & 7u) {
            while (i0++ < 5u && (unsigned)!(unsigned)((short)p2 > (signed char)a0[i0 & 3u])) { if (--fuel == 0u) goto done;
                c1 = (signed char)0x80000000u;
                while (i1++ < 4u && i2) { if (--fuel == 0u) goto done;
                    g1 += (unsigned)((int)((unsigned)b0 / (i2 | 1u)) < (int)(unsigned)!(unsigned)((unsigned)d0 < i1));
                    c0 = (unsigned char)i2;
                    case 2u: ;
                    case 6u: ;
                }
                l0 = (long)((unsigned long)l0 + ((unsigned)(w0 >> 29) >> (((unsigned)c0 & (unsigned)e0) & 31u)));
            }
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                h0 = (short)0x10000u;
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)h0 == (unsigned)((unsigned)d0 || (unsigned)d0))) continue;
                    if (u2) {
                        h1 = (unsigned short)(h1 + (0u << ((unsigned)((unsigned)(w0 >> 29) == (unsigned)l0) & 31u)));
                        continue; (void)((unsigned)((short)0x297d5686u > (signed char)garr[u2 & 7u]));
                        case 1u: ;
                    } else {
                        v0 = (unsigned)((short)(unsigned)((int)(unsigned)x0 >= (int)(unsigned)c0) > (signed char)((unsigned)l0 % (i1 | 1u)));
                        default: ;
                        g0 = ((unsigned)(0xce9c5e15u || 4u) % ((unsigned)((int)(unsigned)c1 < (int)garr[u2 & 7u]) | 1u));
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)e0 % ((i1 - 9u) | 1u)), (unsigned)(short)(unsigned)(g1 == (unsigned)((unsigned)l0 && v0)), ((unsigned)s1 / (u0 | 1u))); }
                    }
                    if (fuel) continue;
                    if ((unsigned)(-(7u << ((unsigned)e0 & 31u)) == (unsigned)h1)) break;
                }
            }
            { unsigned t8; double z8; if (((*q0 & (unsigned)((int)(unsigned)f0 >= (int)u1))) & 1u) { t8 = (unsigned)((unsigned)((int)2u >= (int)garr[i1 & 7u]) || (unsigned)(x0 >> 70)); z8 = (double)(((v0 + u3)) & 255u); } if (((*q0 & (unsigned)((int)(unsigned)f0 >= (int)u1))) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                c0 = (unsigned char)(unsigned)((int)i0 < (int)0x1abdedf1u);
                if (((unsigned)(0x7fffffffu || (unsigned)l0) << (r0.x & 31u))) break;
            }
            garr[garr[i1 & 7u] & 7u] = (5u + 1u);
            a0[(2u * 0x30d4b568u) & 3u] = (unsigned)(unsigned char)(((unsigned)s0 % ((unsigned)h1 | 1u)) + (u0 ^ a0[u1 & 3u]));
        }
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)s0 || u2) & 255u);
        }
        if (u1) {
            if (budget != 0u) { budget -= 1u; u2 = fn0(g1, (unsigned)(signed char)(unsigned)(u1 || (0xffffffffu % (*q0 | 1u))), (((unsigned)e0 << ((unsigned)(w0 >> 29) & 31u)) >> (i1 & 31u))); }
            g1 += (unsigned)((g1 & a0[i0 & 3u]) && v0);
        } else {
            goto done;
            if ((*q0 >> ((unsigned)c1 & 31u))) {
                if (((unsigned)(p0 == (unsigned)s0) >> ((unsigned)e0 & 31u))) {
                    if (1u) goto done;
                    u3 += (unsigned)(unsigned char)(4u ^ (unsigned)l0);
                    g1 += (unsigned)s1;
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn2((i1 & (i0 + (unsigned)c1)), (0x80000000u | (unsigned)((unsigned)s0 < 0xcb1ad20bu)), ((unsigned)x0 >> (6u & 31u))); }
                    g0 = ((unsigned)(i1 == ~(unsigned)(garr[u2 & 7u] == 0x7fffffffu)) >> (a0[i0 & 3u] & 31u));
                }
            } else {
                if ((unsigned)(fuel || (u3 << ((unsigned)x0 & 31u)))) goto L4;
                if ((unsigned)l0) goto done;
                { unsigned t9; double z9; if (((unsigned)(r0.x == 0x80000000u)) & 1u) { t9 = g1; z9 = (double)(((unsigned)d0) & 255u); } if (((unsigned)(r0.x == 0x80000000u)) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                    goto done;
                    if ((u1 ? garr[i1 & 7u] : (unsigned)h1)) goto L1;
                    r0.x = (-((unsigned)((short)(unsigned)c1 > (signed char)6u) % ((unsigned)d0 | 1u)) << ((unsigned)(unsigned char)((unsigned)(x0 >> 70) * i1) & 31u));
                    goto L3;
                    if (((unsigned)((int)garr[u2 & 7u] < (int)garr[i1 & 7u]) - 0x69626450u)) goto done;
                    w0 = w0 * 6364136223846793005ull + (unsigned)c0;
                }
            }
        }
    }
    *q0 = (5u ? (unsigned)(unsigned char)(*q0 >> (1u & 31u)) : (unsigned)!((unsigned)s1 * p2));
    c1 = (signed char)(unsigned)(0xf977d01bu && (unsigned)((short)u0 > (signed char)0x10000u));
    goto L4;
    if (budget != 0u) { budget -= 1u; u0 = fn2(9u, (unsigned)(i2 < 9u), ((unsigned)e0 & (unsigned)(signed char)(0x10000u + i2))); }
    switch (((unsigned)b0 ^ 0x438dc3d9u) & 7u) {
        case 7u: ;
        x0 = x0 * 0x100000001b3ull + (*mp % (((unsigned)((int)u0 >= (int)u1) * 0x7264ca17u) | 1u));
        garr[a0[i0 & 3u] & 7u] = (garr[u2 & 7u] << (((m0 << (u3 & 31u)) / ((unsigned)(unsigned char)(unsigned)(fuel < 0xffffffffu) | 1u)) & 31u));
        if ((unsigned)h1) break;
        goto done;
    }
    goto L4;
    *mp = p1;
    goto L4;
    *mp = (unsigned)c1;
    l0 = (long)((unsigned long)l0 + (unsigned)(u2 < ((unsigned)((0x9c1d5017u + 0x8935b2ccu) && (unsigned)h1) << ((unsigned)s1 & 31u))));
    { unsigned t10; double z10; if ((m0) & 1u) { t10 = (unsigned)((int)6u >= (int)u2); z10 = (double)(((unsigned)x0) & 255u); } if ((m0) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
        if (((unsigned)e0 + (unsigned)l0)) goto L4;
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)w0, (3u >> ((a0[i0 & 3u] * u0) & 31u)), i2); }
        if ((unsigned)((int)(unsigned)(w0 >> 29) < (int)r0.y)) {
            s1 = (int)((unsigned)s1 + 0x7fffffffu);
        }
        l0 = (long)((unsigned long)l0 + (unsigned)(-(unsigned)(6u || 0x47ac348bu) && ((unsigned)d0 % (0x80000000u | 1u))));
        while (i0++ < 4u && (r0.x * p0)) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)((r0.x | u3) / ((i1 | (unsigned)c0) | 1u))) & 255u);
        }
        switch (0x30c4479du & 7u) {
            if ((unsigned)(x0 >> 70)) goto L4;
            switch ((unsigned)((unsigned)(0x7fffffffu || (unsigned)x0) == (unsigned)f0) & 7u) {
                w0 ^= (unsigned long long)0x77158238u << ((unsigned)((unsigned)w0 == (unsigned)((unsigned)((int)(unsigned)(unsigned char)(unsigned)((int)(unsigned)(x0 >> 70) < (int)*mp) >= (int)i2) == 0x3bb240e9u)) & 63u);
                *q0 += (unsigned)((int)(unsigned)((unsigned)e0 == ~(unsigned)((int)g1 < (int)3u)) < (int)(unsigned)h0);
                a0[(r0.x * (unsigned)h0) & 3u] = (i1 / ((unsigned)((unsigned)(0xffffffffu == (unsigned)((unsigned)s0 || fuel)) || i1) | 1u));
                if ((unsigned)(signed char)(unsigned)((short)p2 > (signed char)*q0)) {
                    case 4u: ;
                    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (((unsigned)((unsigned)h0 || 8u) / (1u | 1u))) goto L0;
                    }
                    while (i0++ < 5u && (p0 ? u3 : (unsigned)e0)) { if (--fuel == 0u) goto done;
                        if ((unsigned)d0) break;
                        { unsigned t11; double z11; if (((unsigned)((unsigned)e0 || (unsigned)((int)i2 >= (int)*mp))) & 1u) { t11 = 0x132cea86u; z11 = (double)((0x59ba613eu) & 255u); } if (((unsigned)((unsigned)e0 || (unsigned)((int)i2 >= (int)*mp))) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
                            l0 = (long)((unsigned long)l0 + 0x439a737u);
                        }
                    }
                } else {
                    if (budget != 0u) { budget -= 1u; u3 = fn0(*mp, *mp, 6u); }
                }
            }
        }
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(0u == ((unsigned)d0 | 5u))) goto L2;
        break; (void)((unsigned)w0);
        x0 = x0 * 0x100000001b3ull + ((unsigned)!(unsigned)((int)m0 < (int)u3) ^ ((unsigned)(9u || (unsigned)h1) | (unsigned)l0));
        x0 = x0 * 0x100000001b3ull + (u2 ^ (2u ? 2u : (garr[i1 & 7u] % ((unsigned)c0 | 1u))));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn1(((5u / (fuel | 1u)) >> (0x7fffffffu & 31u)), (u0 / (0x80000000u | 1u)), (unsigned)(short)(unsigned)((int)0u >= (int)0x7fffffffu)); }
    r0.y ^= (u1 * 9u);
    w0 ^= (unsigned long long)(0x1f33c8e5u * r0.y) << ((unsigned)(short)(unsigned)((unsigned)d0 && (unsigned)c0) & 63u);
    switch (r0.x & 7u) {
        if ((6u ^ (u0 >> ((unsigned)b0 & 31u)))) {
            if ((unsigned)(w0 >> 29)) goto L3;
            goto done;
        }
    }
    goto L0;
    h1 = (unsigned short)(h1 + (g0 ^ 0x8a210ef4u));
    if (m0) {
        m0 ^= (~(unsigned)(4u < (unsigned)((int)(unsigned)h1 >= (int)(unsigned)f0)) >> ((unsigned)(short)(0x80000000u * (unsigned)f0) & 31u));
        w0 ^= (unsigned long long)(unsigned)x0 << (1u & 63u);
        h0 = (short)(unsigned)(unsigned char)(0xc7cacb06u ^ 0xa7e0c8a2u);
    } else {
        switch (((unsigned)e0 / ((*mp + (unsigned)h0) | 1u)) & 7u) {
            case 7u: ;
            goto done;
            if (((unsigned)s0 & 0xffffffffu)) goto L3;
        }
    }
    h0 = (short)(u0 | u3);
    goto L2;
    goto done;
    q0 = &garr[*mp & 7u];
    if ((unsigned)(1u == u2)) goto L2;
    if (0x10000u) goto L4;
    u1 = (unsigned)((unsigned)h0 < (a0[i0 & 3u] ^ m0));
    g1 += (*mp & g1);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        b0 = garr[i1 & 7u] != 0u;
        if (fuel < 8u) return (unsigned)((unsigned)((int)(unsigned)c0 >= (int)0xd2df7a15u) || ((unsigned)((int)g0 >= (int)v0) - garr[i1 & 7u]));
        if (garr[u2 & 7u]) break;
        r0.y ^= (unsigned)((unsigned)((unsigned)b0 || 0xe9ce43f4u) || (unsigned)(-(unsigned)((short)0x80000000u > (signed char)(unsigned)f0) && (unsigned)h1));
        g1 += (unsigned)((int)((unsigned)(unsigned char)(0x10000u % ((unsigned)h1 | 1u)) + v0) < (int)0xd6bcdea9u);
    } while (i0++ < 5u && 0u);
    while (i0++ < 6u && (unsigned)((int)p0 < (int)(m0 & i2))) { if (--fuel == 0u) goto done;
        h0 = (short)(unsigned)(p1 < 0x80000000u);
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            *mp = 0xbfb724cu;
            goto done;
        }
    }
    m0 ^= 1u;
    goto L1;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(0xd55ccb69u < (unsigned)(0x10000u && u1)), ((unsigned)x0 % (0xd551f815u | 1u)), (unsigned)h0); }
        q0 = &garr[(unsigned)e0 & 7u];
        d0 = d0 * 0.5 + (double)((0x3979fe5fu % (-(p0 + fuel) | 1u)) & 1023u);
        if ((unsigned)(short)(unsigned)((short)0x8386c2e2u > (signed char)(m0 / ((unsigned)d0 | 1u)))) continue;
        while (i1++ < 5u && (*mp / ((unsigned)(short)(8u % (*mp | 1u)) | 1u))) { if (--fuel == 0u) goto done;
            if (*q0) {
                L0: if (--fuel == 0u) goto done;
                u1 += 0x10000u;
                continue; (void)(u3);
            } else {
                f0 = f0 * 0.5f + (float)((0x7fffffffu / ((unsigned)(unsigned char)(0x10000u + ((fuel * g0) + 0x7fffffffu)) | 1u)) & 255u);
            }
            if ((a0[i0 & 3u] >> ((unsigned)l0 & 31u))) {
                b0 = ((unsigned)((int)0xffffffffu >= (int)i0) * ((2u >> ((unsigned)b0 & 31u)) / (p2 | 1u))) != 0u;
                if (u3 == 7u) return (((unsigned)(x0 >> 70) / ((unsigned)h0 | 1u)) - (unsigned)((int)0xe107c343u >= (int)0x80000000u));
                if (budget != 0u) { budget -= 1u; u2 = fn2(u1, ((unsigned)f0 >> ((unsigned)((int)(unsigned)(x0 >> 70) < (int)garr[i1 & 7u]) & 31u)), *mp); }
            } else {
                f0 = f0 * 0.5f + (float)((unsigned)((((unsigned)c1 | 2u) | r0.y) == (*q0 >> ((unsigned)b0 & 31u))) & 255u);
                L1: if (--fuel == 0u) goto done;
            }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)(0x61c44ba9u & 0x77f74bbfu) > (signed char)0xffffffffu), ((unsigned)s0 >> (0x10000u & 31u)), r0.y); }
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(g0 && (unsigned)h1), (unsigned)((int)garr[i1 & 7u] < (int)0x56d9469eu), 0xffffffffu); }
                *mp = (unsigned)((short)(unsigned)(p0 == u1) > (signed char)0x7fffffffu);
                for (;;) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)garr[i1 & 7u];
                    u1 = (unsigned)((int)(r0.y ? p2 : (unsigned)c1) >= (int)7u);
                    while (i1++ < 5u && (*q0 + (unsigned)!((unsigned)s0 | 7u))) { if (--fuel == 0u) goto done;
                        *mp = ((unsigned)(v0 && (unsigned)f0) * garr[i1 & 7u]);
                        continue; (void)((0x7fffffffu << (a0[i0 & 3u] & 31u)));
                        L2: if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)((2u % ((unsigned)c0 | 1u)) & 1023u);
                        if (budget != 0u) { budget -= 1u; u3 = fn1((((unsigned)d0 - 0u) | 0x10000u), 0xc4a9fe44u, (unsigned)(unsigned char)(9u * (unsigned)(signed char)(unsigned)((int)0x9fec3070u < (int)0x80000000u))); }
                    }
                }
            } while (i2++ < 6u && (i0 | (unsigned)(signed char)(g1 >> ((unsigned)l0 & 31u))));
        }
        if ((unsigned)b0) break;
    } while (i0++ < 5u && -(v0 & (unsigned)(2u && (unsigned)h0)));
    s0 = (int)(i0 ? (unsigned)(x0 >> 70) : i1);
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)(*mp & (unsigned)w0) > (signed char)u2), ((unsigned)b0 + (unsigned)l0), 1u); }
    c0 = (unsigned char)((6u << ((unsigned)s0 & 31u)) - (unsigned)(unsigned char)((unsigned)l0 ^ (unsigned)c1));
    c0 = (unsigned char)1u;
    if (u3 == 7u) return (((unsigned)(g1 < (unsigned)(w0 >> 29)) % (0x80000000u | 1u)) + i2);
    r0.x = ((unsigned)s0 / ((((unsigned)l0 * 6u) + 0x10000u) | 1u));
    l0 = (long)((unsigned long)l0 + (unsigned)(p2 && (unsigned)b0));
    g1 += (unsigned)(i2 == m0);
    if (p1) {
        h1 = (unsigned short)(h1 + (unsigned)((unsigned)s1 == ((unsigned)(x0 >> 70) << ((unsigned)h1 & 31u))));
        v0 = (((0x80000000u ^ 7u) >> (0x15fbe9dau & 31u)) * (unsigned)((short)(unsigned)c1 > (signed char)0x10000u));
        if ((unsigned)((unsigned)h0 < ((unsigned)w0 + r0.x))) goto L1;
        u2 = u2 * 0x9e3779b1u + -(0x1210e689u >> ((0xffffffffu << (0xba375efau & 31u)) & 31u));
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + u2);
            if (garr[u2 & 7u]) break;
            g0 = (a0[u1 & 3u] | (unsigned)(0x80000000u < (unsigned)e0));
            L3: if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                while (((unsigned)(w0 >> 29) & 0x10000u)) { if (--fuel == 0u) goto done;
                    L4: if (--fuel == 0u) goto done;
                    for (;;) { if (--fuel == 0u) goto done;
                        { unsigned t0; double z0; if (((g0 % (u2 | 1u))) & 1u) { t0 = (unsigned)((int)(unsigned)!(0u & 0xb46b1755u) >= (int)0xe5b24c49u); z0 = (double)((garr[u2 & 7u]) & 255u); } if (((g0 % (u2 | 1u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                            break; (void)(0x6b4be4b5u);
                            if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)(a0[i0 & 3u] < 6u), (unsigned)((unsigned)d0 || *q0), (0x3604d1cu * 1u)); }
                            if (budget != 0u) { budget -= 1u; u3 = fn2(u1, (0xffffffffu % (0xa0c90e66u | 1u)), (unsigned)(v0 < 0x33285e9eu)); }
                            break; (void)((unsigned)((int)u2 >= (int)0xa4e8dbd1u));
                            if ((unsigned)h0) continue;
                            i0 = 4u & 15u;
                        }
                        if (budget != 0u) { budget -= 1u; u1 = fn0(p1, 0x4c7406fcu, (unsigned)((int)((unsigned)f0 >> (r0.x & 31u)) >= (int)0x6d417753u)); }
                        if ((r0.x + (0x7fffffffu >> ((unsigned)h0 & 31u)))) break;
                        if (a0[i0 & 3u]) break;
                        break; (void)((i0 % (u0 | 1u)));
                        l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)((short)g0 > (signed char)0x10000u) % (i1 | 1u)) < 0x7569a862u));
                    }
                }
                if (budget != 0u) { budget -= 1u; u2 = fn3((0xf01c2b9u % ((unsigned)e0 | 1u)), (unsigned)x0, ((0x10000u ^ (unsigned)s0) << ((unsigned)x0 & 31u))); }
                if (((garr[i1 & 7u] + 8u) * a0[i0 & 3u])) {
                    b0 = (unsigned)((0x10000u - fuel) < 0x269e3a02u) != 0u;
                } else {
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)s1) break;
                    }
                }
                switch (((unsigned)((unsigned)h1 || (unsigned)(x0 >> 70)) - fuel) & 7u) {
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(*q0 == *q0), (unsigned)s1, (unsigned)(u3 || 0xffffffffu)); }
                    continue; (void)((unsigned)(short)((unsigned)((int)r0.y < (int)(unsigned)c0) - *q0));
                    h1 = (unsigned short)(h1 + ((unsigned)(short)((unsigned)b0 & 2u) & (0x10000u * (unsigned)(garr[i1 & 7u] && *q0))));
                    case 5u: ;
                }
                *mp = (unsigned)((unsigned)(5u || 0u) == (unsigned)(short)(unsigned)((int)(2u | *mp) < (int)3u));
            }
            while (((u0 & 0x3ff1c717u) | (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                *mp = (0x7fffffffu & (i2 + (unsigned)(u1 || ((unsigned)h0 + (unsigned)c1))));
                h0 = (short)g0;
            }
        }
        f0 = f0 * 0.5f + (float)(((unsigned)h1 + (unsigned)(((unsigned)(x0 >> 70) % (m0 | 1u)) || (unsigned)e0)) & 255u);
    } else {
        e0 = e0 * 0.5L + (long double)((unsigned)(0xd14bdd2eu < u1) & 1023u);
    }
    switch (u3 & 7u) {
        r0.y ^= (unsigned)(((v0 / ((unsigned)c0 | 1u)) & *mp) < 0x80000000u);
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)!(((unsigned)((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)c0) == (unsigned)c0) >> (0x98e63a55u & 31u)) >> (i1 & 31u));
            if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)(0x7c30b28cu < a0[u1 & 3u]), ~(unsigned)((short)(unsigned)c1 > (signed char)0x80000000u), (unsigned)l0); }
        }
    }
    s1 = (int)((unsigned)s1 + ~(unsigned)((unsigned)(x0 >> 70) || (unsigned)w0));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)l0)) break;
    }
    u2 = ((unsigned)f0 * ((g1 + (unsigned)d0) ? i2 : p2));
    if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)(unsigned char)(7u - (unsigned)x0), 0xffffffffu, (0x7d74c764u ^ 0x80000000u)); }
    if ((unsigned)(0x80000000u && i0)) {
        i2 = 6u & 15u;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(0xeacecdb6u == u3) | v0), (unsigned)l0, (*mp << (5u & 31u))); }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)((unsigned)c1 && (unsigned)(short)(fuel ^ (unsigned)w0)) & 7u) {
            if ((unsigned)(x0 >> 70)) continue;
            f0 = f0 * 0.5f + (float)((a0[u1 & 3u] + m0) & 255u);
        }
        goto L3;
    }
    w0 = w0 * 6364136223846793005ull + 0x28f9149au;
    do { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (unsigned)((int)(unsigned)w0 >= (int)(0x392e8a1fu + (unsigned)h1));
        do { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (i1 / ((*q0 ? 0x4fdf4918u : (0x10000u % ((unsigned)(w0 >> 29) | 1u))) | 1u));
            if ((unsigned)(signed char)((unsigned)((unsigned)(x0 >> 70) && 2u) - 0x7fffffffu)) break;
            if (r0.x) break;
            if (budget != 0u) { budget -= 1u; u3 = fn1(~(i0 | 8u), (i2 * 0x7fffffffu), ((unsigned)(x0 >> 70) ? g1 : i0)); }
            for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)s1 + (p1 - 0u))) break;
                if (7u) break;
            }
            if ((~(*mp << (r0.y & 31u)) / (v0 | 1u))) goto L4;
        } while (i1++ < 4u && v0);
        h1 = (unsigned short)(h1 + (unsigned)d0);
        for (;;) { if (--fuel == 0u) goto done;
            v0 = (unsigned)((int)(unsigned)(unsigned char)((unsigned)(w0 >> 29) >> ((p1 >> ((unsigned)x0 & 31u)) & 31u)) < (int)(unsigned)h0);
        }
        if ((p1 * (g1 ^ 0x80000000u))) continue;
    } while (i0++ < 5u && (unsigned)(unsigned char)((*q0 / (0x7d3f9b1u | 1u)) - (unsigned)c1));
    *q0 = ((0x78efd434u << ((u2 + i0) & 31u)) + m0);
    do { if (--fuel == 0u) goto done;
        switch (((unsigned)((int)5u >= (int)a0[u1 & 3u]) | (unsigned)e0) & 7u) {
            continue; (void)(((p0 * 1u) / (i2 | 1u)));
            garr[~(unsigned)((short)*q0 > (signed char)8u) & 7u] = (unsigned)((int)u2 >= (int)(unsigned)(short)(i1 - 3u));
            if (((a0[i0 & 3u] + p1) - i2)) goto done;
            if ((unsigned)((unsigned)w0 || 0xb571e5a9u)) continue;
            if ((unsigned)((unsigned)((short)0x40e454b2u > (signed char)4u) && (unsigned)h1)) goto L2;
        }
    } while (i0++ < 2u && u1);
    if (0x715bbcb9u) goto L0;
    while (i0++ < 5u && (unsigned)((short)(unsigned)(r0.x && u1) > (signed char)garr[i1 & 7u])) { if (--fuel == 0u) goto done;
        g0 = u0;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)(garr[i1 & 7u] - ((unsigned)(u1 == 7u) + (unsigned)s0));
            if (3u) goto L0;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)2u >= (int)((unsigned)b0 % ((unsigned)(w0 >> 29) | 1u))), (unsigned)(fuel == *q0), (unsigned)(i1 || (unsigned)(garr[i1 & 7u] < 0x68f66b5au))); }
            while (i2++ < 4u && 0x22532e38u) { if (--fuel == 0u) goto done;
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    u2 += 0xaa108d6du;
                    i2 = garr[i1 & 7u] & 15u;
                    switch ((((unsigned)(x0 >> 70) % ((unsigned)s0 | 1u)) + 7u) & 7u) {
                        case 7u: ;
                        if ((unsigned)(u1 && u1)) continue;
                        if (fuel < 8u) return (i1 | a0[i0 & 3u]);
                        u1 += ((0xffffffffu << (((unsigned)(w0 >> 29) + garr[u2 & 7u]) & 31u)) + (unsigned)((int)a0[i0 & 3u] >= (int)garr[i1 & 7u]));
                    }
                    g1 += (0x7fffffffu ? (p0 ^ r0.y) : (unsigned)(w0 >> 29));
                    r0.y ^= (unsigned)(r0.x == (unsigned)e0);
                    r0.x = (unsigned)((int)(0x80000000u & 0x80000000u) < (int)a0[u1 & 3u]);
                }
                break; (void)((0x85c2b86cu >> (p1 & 31u)));
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)(i1 && 0x7ddafaa6u));
                    while (i1++ < 7u && (unsigned)s0) { if (--fuel == 0u) goto done;
                        switch ((unsigned)(r0.y && (unsigned)(r0.y < (unsigned)b0)) & 7u) {
                            if (budget != 0u) { budget -= 1u; u2 = fn2(p0, ((unsigned)x0 & r0.x), (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)w0)); }
                            if ((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)(u3 < u0))) goto L2;
                            f0 = f0 * 0.5f + (float)(((unsigned)c0 / ((garr[i1 & 7u] % ((fuel - (unsigned)b0) | 1u)) | 1u)) & 255u);
                        }
                        break; (void)(u3);
                        *q0 += (unsigned)!(a0[i0 & 3u] + 0u);
                        if (*q0) break;
                        s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(a0[u1 & 3u] - (unsigned)(short)((0x235e6bc8u * i1) << ((unsigned)h1 & 31u))));
                    }
                    r0.y ^= m0;
                    break; (void)((unsigned)(x0 >> 70));
                }
                switch ((unsigned)((unsigned)((unsigned)b0 || (unsigned)b0) || p2) & 7u) {
                    case 5u: ;
                    case 3u: ;
                    u1 += i0;
                    s0 = (int)p0;
                    while (i0++ < 3u && (garr[u2 & 7u] / ((*mp >> (p1 & 31u)) | 1u))) { if (--fuel == 0u) goto done;
                        case 2u: ;
                        e0 = e0 * 0.5L + (long double)(g1 & 1023u);
                    }
                    s1 = (int)((unsigned)s1 + (unsigned)(short)(p2 | (unsigned)w0));
                }
                { unsigned t1; double z1; if ((0xffffffffu) & 1u) { t1 = a0[i0 & 3u]; z1 = (double)((((unsigned)(x0 >> 70) & u1)) & 255u); } if ((0xffffffffu) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    x0 = x0 * 0x100000001b3ull + (unsigned)(short)(garr[u2 & 7u] % (a0[u1 & 3u] | 1u));
                }
            }
        }
        switch ((v0 * (unsigned)(*mp || *q0)) & 7u) {
            while (i1++ < 4u && 9u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)0x702bb11fu < (int)(4u & p0))) {
                    u1 = u1 * 0x9e3779b1u + (unsigned)b0;
                    if (((unsigned)f0 % ((g1 << ((unsigned)c1 & 31u)) | 1u))) break;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((unsigned)b0 || (unsigned)x0), (unsigned)b0, (0x10000u | (g0 & g1))); }
                if (budget != 0u) { budget -= 1u; u0 = fn2(~(r0.x / ((0x80000000u << (g0 & 31u)) | 1u)), (0x10000u + (unsigned)((int)fuel >= (int)i0)), (0x7fffffffu >> (garr[u2 & 7u] & 31u))); }
                h1 = (unsigned short)(h1 + (unsigned)((short)0x10000u > (signed char)0x10000u));
                c0 = (unsigned char)(unsigned)((unsigned)(short)(unsigned)(9u || (unsigned)s0) < ((unsigned)f0 & (0x42fbed3u * garr[i1 & 7u])));
            }
            u2 += ((unsigned)((short)((unsigned)s0 >> ((unsigned)d0 & 31u)) > (signed char)*q0) + ((unsigned)d0 % (r0.y | 1u)));
            if ((unsigned)((short)(unsigned)(0x580143ccu && i2) > (signed char)(unsigned)s0)) continue;
        }
        if ((unsigned)(signed char)(unsigned)(1u == u2)) continue;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)h0 * (unsigned)!(unsigned)((unsigned)(w0 >> 29) || fuel)), (i2 ^ a0[u1 & 3u]), (unsigned)((unsigned)(0xb2c4b406u && 0x80000000u) == g0)); }
    if (4u) {
        u3 += (unsigned)((int)(1u >> (p0 & 31u)) < (int)(garr[i1 & 7u] ^ r0.x));
        r0.x = u0;
        do { if (--fuel == 0u) goto done;
            *q0 = (4u * (~(i1 << ((unsigned)e0 & 31u)) & (unsigned)!(unsigned)(0x710b8ceu < i1)));
        } while (i0++ < 4u && 3u);
        q0 = &garr[(*q0 | (unsigned)((p2 | (unsigned)c0) == 0xa83b5117u)) & 7u];
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        c1 = (signed char)~(g1 ? (unsigned)((int)m0 < (int)(unsigned)s1) : (unsigned)s0);
        if (budget != 0u) { budget -= 1u; u0 = fn2(0x2e60f443u, (0xffffffffu & (a0[i0 & 3u] << (g0 & 31u))), (unsigned)((short)0xa73823e2u > (signed char)(garr[i1 & 7u] & 0x77e8d467u))); }
        if (0x30ee5f5u) break;
        i0 = ((unsigned)(short)(unsigned)(0x10000u == 0x10000u) + (a0[i0 & 3u] % (garr[i1 & 7u] | 1u))) & 15u;
        break; (void)(i1);
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            i2 = p2 & 15u;
            goto L3;
            if (budget != 0u) { budget -= 1u; u1 = fn3(((unsigned)s1 ? (unsigned)l0 : (unsigned)w0), (unsigned)(0x7fffffffu && (u2 | a0[u1 & 3u])), p0); }
            if ((garr[u2 & 7u] * i0)) {
                garr[8u & 7u] = ((unsigned)b0 * u2);
                if (0xc8b83038u) {
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)c0, (unsigned)(x0 >> 70), (unsigned)((unsigned)x0 < p1)); }
                }
            } else {
                q0 = &garr[(0x64d05d20u % (9u | 1u)) & 7u];
                l0 = (long)((unsigned long)l0 + 0xffffffffu);
            }
            { unsigned t2; double z2; if (((unsigned)(signed char)((unsigned)(garr[i1 & 7u] || p2) & r0.x)) & 1u) { t2 = ((unsigned)s1 * i0); z2 = (double)(((u3 << (i2 & 31u))) & 255u); } if (((unsigned)(signed char)((unsigned)(garr[i1 & 7u] || p2) & r0.x)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                break; (void)(7u);
                while (i2++ < 2u && (unsigned)((short)(unsigned)(signed char)((unsigned)d0 >> ((unsigned)w0 & 31u)) > (signed char)(unsigned)w0)) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)(((unsigned)b0 & p2) & 1023u);
                    if (3u) {
                        break; (void)((unsigned)((unsigned)!(unsigned)((int)i2 >= (int)i1) < 0x8290ccfcu));
                    } else {
                        if ((unsigned)c0) goto L2;
                        if (fuel < 8u) return (a0[i0 & 3u] * 0xffffffffu);
                        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(0xffffffffu == *q0) == (*q0 & (unsigned)c0)));
                        if ((unsigned)(0x12b949eu && (unsigned)(1u && (unsigned)c0))) goto L3;
                    }
                }
                { unsigned t3; double z3; if ((1u) & 1u) { t3 = (unsigned)((unsigned)((int)0x7fffffffu >= (int)r0.y) == (unsigned)l0); z3 = (double)((((unsigned)((unsigned)c1 || (unsigned)(w0 >> 29)) - i1)) & 255u); } if ((1u) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    c1 = (signed char)(unsigned)((int)m0 < (int)a0[i0 & 3u]);
                    if ((u2 & (unsigned)(7u || 4u))) {
                        if ((unsigned)x0) goto L1;
                    }
                    if ((0xffffffffu * u3)) {
                        h1 = (unsigned short)(h1 + (unsigned)((short)g0 > (signed char)(unsigned)d0));
                        v0 = ((6u - garr[u2 & 7u]) / ((unsigned)((int)g0 < (int)(unsigned)((unsigned)b0 < i1)) | 1u));
                        *mp = (unsigned)(0x80000000u && *q0);
                    } else {
                        if (u3 == 7u) return (unsigned)(((unsigned)((unsigned)d0 < (unsigned)w0) - (p0 ^ 0xffffffffu)) < 0xffffffffu);
                        if (a0[u1 & 3u]) break;
                        s0 = (int)((0u >> (u2 & 31u)) + (0x10000u << ((unsigned)(x0 >> 70) & 31u)));
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)(i2 && (unsigned)f0) & p1), ((p1 ^ 0x5bcbe927u) << (0x80000000u & 31u)), ((unsigned)f0 * (unsigned)(2u || garr[u2 & 7u]))); }
                    if ((unsigned)!(0u / (*q0 | 1u))) {
                        if ((unsigned)(((unsigned)s0 % (p1 | 1u)) && (unsigned)b0)) break;
                        while (i2++ < 4u && p2) { if (--fuel == 0u) goto done;
                            if (~(unsigned)((unsigned)w0 || (p2 + *mp))) break;
                            break; (void)((0x3d8204dau + (unsigned)(m0 && (unsigned)b0)));
                            u0 ^= (unsigned)((int)g0 >= (int)(unsigned)(unsigned char)((unsigned)((short)v0 > (signed char)g0) & 0x520f74bu));
                            if ((r0.y * (unsigned)e0)) break;
                            *mp = ((i2 % (0x3830c732u | 1u)) / ((unsigned)s0 | 1u));
                            if ((unsigned)(unsigned char)(unsigned)((unsigned)((int)m0 >= (int)(unsigned)e0) == (unsigned)b0)) break;
                        }
                        continue; (void)((unsigned)((short)(*mp - 0x4645fe32u) > (signed char)v0));
                    }
                }
                if (*mp) {
                    if (budget != 0u) { budget -= 1u; u0 = fn2(p1, ((unsigned)x0 / ((u2 ^ i2) | 1u)), (p0 + (unsigned)((unsigned)(w0 >> 29) && u2))); }
                    while (((unsigned)d0 * (unsigned)b0)) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + 0x80000000u);
                        r0.x = (i1 % (*mp | 1u));
                        garr[(unsigned)(0xf5bc4933u < *q0) & 7u] = (unsigned)(a0[u1 & 3u] && (p1 ^ 0x24a95b25u));
                        q0 = &garr[(0x7fcd4dacu / ((((unsigned)f0 + u1) % ((0x10000u * (unsigned)e0) | 1u)) | 1u)) & 7u];
                    }
                }
                break; (void)(((unsigned)e0 / (r0.x | 1u)));
                if (budget != 0u) { budget -= 1u; u2 = fn0((i0 ^ 0x8f7ec9b1u), 8u, (unsigned)(p2 || (unsigned)x0)); }
            }
            if (((unsigned)s0 / (fuel | 1u))) break;
        }
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        goto L0;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)(short)(((unsigned)s1 % ((r0.y ^ 0x10000u) | 1u)) % (0xff5e2086u | 1u));
            { unsigned t4; double z4; if (((unsigned)(u2 < (unsigned)(p0 || g0))) & 1u) { t4 = u3; z4 = (double)(((unsigned)((unsigned)h0 || (unsigned)x0)) & 255u); } if (((unsigned)(u2 < (unsigned)(p0 || g0))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                s0 = (int)i2;
                r0.x = (r0.y * (*mp % (-((unsigned)s1 << ((unsigned)s1 & 31u)) | 1u)));
                h0 = (short)(unsigned)!(unsigned)(((unsigned)((int)(unsigned)(x0 >> 70) >= (int)fuel) << ((unsigned)e0 & 31u)) < 0xac870ad0u);
                s0 = (int)0x7fffffffu;
                i0 = ((unsigned)((int)0x65523042u < (int)0x10000u) ^ g0) & 15u;
            }
            l0 = (long)((unsigned long)l0 + (unsigned)(short)((9u ^ ((unsigned)(x0 >> 70) | p2)) ^ (unsigned)((short)r0.y > (signed char)(unsigned)b0)));
        }
        if ((unsigned)((p0 * 0u) && u1)) {
            break; (void)(-((g0 / (u3 | 1u)) - 0x45e96cbfu));
            h1 = (unsigned short)(h1 + (*q0 + i0));
            if (~(unsigned)((unsigned)c0 && 0xcb0eb3c5u)) break;
            u1 = u1 * 0x9e3779b1u + (unsigned)(signed char)(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)((int)(unsigned)s1 < (int)(0xd8f5c167u - (unsigned)c0)));
            if ((unsigned)((int)((unsigned)f0 * (unsigned)b0) >= (int)(unsigned)x0)) break;
            if (-((unsigned)f0 | 0xad9b16e6u)) break;
        }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(*q0 || 0x10000u)) break;
        } while (i1++ < 3u && (unsigned)(((unsigned)h1 * 5u) == 0x3f5ecad7u));
    }
    if (((unsigned)((short)0x7fffffffu > (signed char)a0[i0 & 3u]) / (m0 | 1u))) goto L1;
    f0 = f0 * 0.5f + (float)((0x10000u - a0[u1 & 3u]) & 255u);
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)d0, u3, (0x4b65ca54u + (unsigned)d0)); }
    { unsigned t5; double z5; if (((0xffffffffu / (i1 | 1u))) & 1u) { t5 = (unsigned)c0; z5 = (double)((5u) & 255u); } if (((0xffffffffu / (i1 | 1u))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
        if ((unsigned)((short)8u > (signed char)u2)) {
            s1 = (int)((unsigned)s1 + (unsigned)(0u && garr[i1 & 7u]));
            u1 += 0x80000000u;
            if ((i0 >> ((u3 + 0xb5859131u) & 31u))) goto done;
            s0 = (int)(unsigned)((int)((unsigned)c1 | v0) < (int)(0x7a4f2577u << ((unsigned)c0 & 31u)));
            goto L0;
            if (budget != 0u) { budget -= 1u; u3 = fn3(~(unsigned)((int)1u >= (int)(unsigned)e0), (unsigned)(p1 == garr[i1 & 7u]), (p2 + a0[i0 & 3u])); }
        } else {
            f0 = f0 * 0.5f + (float)((((unsigned)h1 & 0x7fffffffu) & (unsigned)!(unsigned)((short)(unsigned)(fuel || a0[i0 & 3u]) > (signed char)p1)) & 255u);
            switch ((unsigned)((unsigned)w0 && u2) & 7u) {
                x0 = x0 * 0x100000001b3ull + (unsigned)((u0 ^ i1) < u3);
                *mp = (p0 + garr[u2 & 7u]);
                case 1u: ;
                goto L4;
            }
        }
    }
    goto L1;
    if ((unsigned)((short)0xaa172967u > (signed char)(unsigned)(unsigned char)(0x7fffffffu % (i0 | 1u)))) goto done;
    if ((unsigned)(signed char)(0x9b542f2u * p2)) goto L0;
    a0[(unsigned)c0 & 3u] = (((unsigned)(i0 == m0) ? p1 : (unsigned)h1) ^ 8u);
    if ((m0 >> ((unsigned)(v0 && g1) & 31u))) goto L1;
    f0 = f0 * 0.5f + (float)((unsigned)(g1 < v0) & 255u);
    while (i0++ < 5u && 0x10000u) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)c1 || ((unsigned)x0 * (g1 % (0xa7db70d9u | 1u)))) & 1023u);
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(unsigned char)((unsigned)s1 ^ (unsigned)s1), ((0xa3893cbau + (unsigned)l0) - 8u), (unsigned)e0); }
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)p2 > (signed char)(unsigned)h1), u1, ((unsigned)s0 * 9u)); }
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(garr[u2 & 7u] == 0x55c56946u)) break;
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)e0 < garr[u2 & 7u]) & 255u);
        garr[(u2 - 0x81133909u) & 7u] = (((unsigned)(0x80000000u && 0x7fffffffu) & p1) & ((unsigned)c0 - v0));
        if (u3 == 7u) return ((unsigned)(unsigned char)(g0 ^ 5u) + i2);
    }
    d0 = d0 * 0.5 + (double)(((unsigned)(x0 >> 70) | (*mp << (u1 & 31u))) & 1023u);
    switch (p2 & 7u) {
        e0 = e0 * 0.5L + (long double)(((unsigned)(a0[u1 & 3u] || (unsigned)h1) - 9u) & 1023u);
    }
    if (budget != 0u) { budget -= 1u; u3 = fn2((0u * 0xffffffffu), (unsigned)d0, (a0[i0 & 3u] + (unsigned)(w0 >> 29))); }
    w0 ^= (unsigned long long)(unsigned)((short)8u > (signed char)(unsigned)(w0 >> 29)) << ((unsigned)((int)(unsigned)(((unsigned)c0 | (unsigned)(x0 >> 70)) == *mp) < (int)0x7fffffffu) & 63u);
    h0 = (short)(unsigned)((unsigned)(i0 || u3) == (((unsigned)b0 | g1) / (v0 | 1u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 15u, 0x62687ec5u, 0x729c1acfu },
        { 12u, 0x390016fu, 0x82550c61u },
        { 0u, 0x7d973ceeu, 0xefbef278u },
        { 11u, 0x917ec2b1u, 0x7c506245u },
        { 8u, 0x4843d14u, 0x52da7cf8u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
