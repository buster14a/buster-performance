// test-ssa-source's program of seed 134000447 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x6b134ee4u, g1 = 0x2f95c9au;
static unsigned garr[8] = { 0xb0e546ffu, 0xae3ddce0u, 0x1fa59f6bu, 0x2ec007d6u, 0x3572bbf9u, 0x82a7ff67u, 0x175f5f99u, 0x118ba3a0u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch ((3u + r0.x) & 7u) {
        if (fuel < 8u) return (unsigned)((int)i0 < (int)0xc2bc63f4u);
        if (*mp) {
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 2u: ;
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)(u3 & (unsigned)(w0 >> 29)) < (int)(unsigned)e0)) break;
                    if ((6u | (unsigned)d0)) goto L1;
                    for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        default: ;
                        L0: if (--fuel == 0u) goto done;
                        for (;;) { if (--fuel == 0u) goto done;
                            continue; (void)(((unsigned)(unsigned char)(u0 * (unsigned)b0) >> ((unsigned)d0 & 31u)));
                            g0 = -(u2 ? 9u : 8u);
                            e0 = e0 * 0.5L + (long double)((-(((unsigned)e0 << ((unsigned)c0 & 31u)) * (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)d0)) >> (p2 & 31u)) & 1023u);
                        }
                    }
                    r0.y ^= (unsigned)((g0 << ((unsigned)b0 & 31u)) < (unsigned)(p0 < (unsigned)(x0 >> 70)));
                } while (i1++ < 2u && *mp);
                L1: if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)s1 == (unsigned)w0)) goto L3;
                    u3 = u3 * 0x9e3779b1u + (unsigned)((int)(unsigned)(unsigned char)(unsigned)((unsigned)x0 && ((unsigned)(p0 < u1) & g1)) < (int)3u);
                    L2: if (--fuel == 0u) goto done;
                    { unsigned t0; double z0; if (((unsigned)(unsigned char)(((unsigned)w0 | i1) * (unsigned)s0)) & 1u) { t0 = (0xffffffffu ? 0x5da63cddu : i0); z0 = (double)(((0x7fffffffu & garr[i1 & 7u])) & 255u); } if (((unsigned)(unsigned char)(((unsigned)w0 | i1) * (unsigned)s0)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                        while (-((0x8a88f098u << (5u & 31u)) % (p2 | 1u))) { if (--fuel == 0u) goto done;
                            if ((unsigned)w0) goto L1;
                        }
                        while (garr[u2 & 7u]) { if (--fuel == 0u) goto done;
                            if (v0) goto L3;
                            case 7u: ;
                            u0 = ((u1 << (4u & 31u)) ^ (unsigned)c0);
                            continue; (void)((unsigned)(0xf0bb8724u == 5u));
                            garr[*mp & 7u] = -((unsigned)f0 ? (unsigned)((int)(unsigned)w0 >= (int)0x80000000u) : 9u);
                            break; (void)(i2);
                        }
                        L3: if (--fuel == 0u) goto done;
                    }
                } while (i1++ < 6u && (r0.y / (((unsigned)c1 * (unsigned)x0) | 1u)));
                a0[(0x10000u >> (4u & 31u)) & 3u] = ((unsigned)(w0 >> 29) & (unsigned)(u2 == (unsigned)!(unsigned)((unsigned)d0 < (unsigned)(0x206fa00fu && (unsigned)f0))));
                while (i1++ < 4u && (r0.x & ((unsigned)d0 & 4u))) { if (--fuel == 0u) goto done;
                    u1 += (unsigned)((int)v0 < (int)p2);
                    h0 = (short)(unsigned)(w0 >> 29);
                }
            }
            case 5u: ;
            v0 = (unsigned)((unsigned)c0 < (garr[u2 & 7u] & ((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)d0) ^ (unsigned)b0)));
            while (i0++ < 2u && (unsigned)(signed char)(u0 * 0x2e0c0044u)) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return ((i1 * u2) << ((u2 & (i0 << (0x226053feu & 31u))) & 31u));
                break; (void)(9u);
                break; (void)((0x6f09a91bu - ((unsigned)w0 << (0xa4da4804u & 31u))));
                h1 = (unsigned short)(h1 + ((unsigned)((short)(unsigned)((unsigned)d0 < r0.x) > (signed char)(unsigned)(fuel == m0)) & (unsigned)d0));
                { unsigned t1; double z1; if ((p2) & 1u) { t1 = p1; z1 = (double)(((unsigned)((int)(unsigned)h1 < (int)p2)) & 255u); } if ((p2) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    L4: if (--fuel == 0u) goto done;
                    break;
                    s1 = (int)((unsigned)s1 + ((unsigned)l0 ^ ((unsigned)(x0 >> 70) | 0x1f527d98u)));
                    s1 = (int)((unsigned)s1 + u0);
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        goto L4;
                        w0 = w0 * 6364136223846793005ull + (garr[i1 & 7u] >> (3u & 31u));
                        break;
                        case 3u: ;
                        if ((unsigned)(p1 || 0x10000u)) continue;
                    }
                }
            }
        } else {
            d0 = d0 * 0.5 + (double)((((unsigned)h0 >> ((unsigned)e0 & 31u)) >> (7u & 31u)) & 1023u);
            do { if (--fuel == 0u) goto done;
                if (((unsigned)(x0 >> 70) >> (garr[u2 & 7u] & 31u))) {
                    case 6u: ;
                    break;
                    break; (void)((u3 ? u2 : 0xf67cf935u));
                    if (fuel < 8u) return 5u;
                }
                break;
                u3 ^= (r0.x / (0x5bdccfedu | 1u));
            } while (i0++ < 5u && (unsigned)!((unsigned)(0x27f87e64u < r0.x) % (g1 | 1u)));
            r0.y ^= (unsigned)((int)0xffffffffu >= (int)((unsigned)h0 >> ((unsigned)s0 & 31u)));
            switch (p2 & 7u) {
                w0 = w0 * 6364136223846793005ull + (m0 - ((unsigned)(0x92602569u == 0xdfdcf666u) ^ (unsigned)h1));
                for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    case 4u: ;
                    switch ((a0[u1 & 3u] * fuel) & 7u) {
                        u1 = u1 * 0x9e3779b1u + ((r0.y ^ a0[u1 & 3u]) ^ (0x7fffffffu ^ (unsigned)h0));
                        garr[(0x4a0a3f9fu << (u2 & 31u)) & 7u] = (0x10000u << (i2 & 31u));
                        case 0u: ;
                        m0 ^= (unsigned)h0;
                        h0 = (short)(unsigned)(0xc31bfa80u && (unsigned)h1);
                    }
                }
            }
        }
        switch (((unsigned)l0 / ((g1 << ((unsigned)c0 & 31u)) | 1u)) & 7u) {
            d0 = d0 * 0.5 + (double)((unsigned)d0 & 1023u);
            s0 = (int)(*mp * (unsigned)((int)0xffffffffu < (int)(*mp ? i2 : i0)));
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 2u: ;
                if ((unsigned)(w0 >> 29)) goto L3;
                r0.x = (unsigned)((int)(unsigned)d0 < (int)u2);
                case 0u: ;
            }
        }
        case 0u: ;
        l0 = (long)((unsigned long)l0 + (p0 >> (garr[u2 & 7u] & 31u)));
        break;
    }
    if ((unsigned)(unsigned char)(a0[i0 & 3u] + r0.y)) goto L4;
    { unsigned t2; double z2; if (((unsigned)(signed char)(unsigned)(0xf2c82a3u && (3u & (unsigned)l0))) & 1u) { t2 = ((garr[u2 & 7u] + (unsigned)s1) - u3); z2 = (double)((((unsigned)(w0 >> 29) | (unsigned)((int)0x58248a70u >= (int)0x80000000u))) & 255u); } if (((unsigned)(signed char)(unsigned)(0xf2c82a3u && (3u & (unsigned)l0))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        for (;;) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(0x10000u & 1023u);
            r0.x = (unsigned)((unsigned)((unsigned)h1 == (unsigned)((short)v0 > (signed char)(0xffffffffu ^ v0))) || 0x7fffffffu);
        }
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((u0 - (unsigned)h0) ^ (unsigned)s1)) {
            break; (void)((unsigned)(unsigned char)((unsigned)c0 + (unsigned)h1));
        }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            g0 = (unsigned)(w0 >> 29);
            if ((unsigned)((short)(unsigned)h1 > (signed char)(unsigned)c0)) {
                s1 = (int)((unsigned)s1 + (r0.y & 0x80000000u));
                s0 = (int)(((unsigned)c1 / ((unsigned)d0 | 1u)) / (a0[u1 & 3u] | 1u));
                m0 ^= (unsigned)(short)(unsigned)((0xffffffffu | u2) && ((unsigned)(v0 && (unsigned)h1) / (fuel | 1u)));
            } else {
                if ((0x10000u >> ((unsigned)s0 & 31u))) break;
                if ((0x10000u & (unsigned)h0)) break;
                if ((unsigned)((int)0x80000000u < (int)garr[u2 & 7u])) continue;
            }
            r0.x = (unsigned)s0;
        }
    }
    garr[(unsigned)(r0.y == 8u) & 7u] = (unsigned)(garr[u2 & 7u] || fuel);
    switch (2u & 7u) {
        { unsigned t3; double z3; if ((i2) & 1u) { t3 = (unsigned)((0xffffffffu >> (9u & 31u)) && 0x2f2863d8u); z3 = (double)(((unsigned)(i0 || (unsigned)((int)garr[i1 & 7u] < (int)0x7fffffffu))) & 255u); } if ((i2) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            if ((garr[u2 & 7u] + u3)) {
                u2 = u2 * 0x9e3779b1u + (unsigned)c0;
            } else {
                r0.x = ((unsigned)(0xb7d5fbdeu && *mp) - (unsigned)(((unsigned)s0 - (unsigned)s0) < (unsigned)e0));
                f0 = f0 * 0.5f + (float)(0x26452417u & 255u);
                goto L2;
                if ((unsigned)(w0 >> 29)) break;
            }
            if (m0) goto done;
            case 7u: ;
            case 2u: ;
        }
        case 1u: ;
        case 4u: ;
        if ((u1 + (unsigned)c0)) goto done;
        d0 = d0 * 0.5 + (double)(((unsigned)((i1 ? 0x7fffffffu : i2) < garr[i1 & 7u]) * (unsigned)h0) & 1023u);
    }
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)f0) break;
    }
    while (i0++ < 2u && (0x60c23a45u & ((unsigned)s0 >> ((unsigned)w0 & 31u)))) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(i2 % ((unsigned)(short)(unsigned)((r0.y ? 0x10000u : a0[i0 & 3u]) < (unsigned)w0) | 1u));
    }
    h0 = (short)-((unsigned)x0 * (unsigned)((int)u1 >= (int)garr[u2 & 7u]));
    if (g1) {
        if (u3 == 7u) return ((i0 >> (u2 & 31u)) * (unsigned)!((*mp + (unsigned)s1) >> (m0 & 31u)));
        if (~(u3 - (unsigned)h1)) goto L1;
        if (0xffffffffu) {
            u2 ^= ((unsigned)((unsigned)s1 && i1) / ((unsigned)(unsigned char)(p0 + (unsigned)s1) | 1u));
            i1 = ((unsigned)h1 & 0x98ba5c50u) & 15u;
        } else {
            *mp = (unsigned)(r0.y < ((unsigned)f0 - (unsigned)(5u && v0)));
            if (fuel < 8u) return u3;
            g1 += (u2 + (u0 << (0x10000u & 31u)));
        }
        c0 = (unsigned char)(unsigned)((unsigned)((unsigned)s0 || g0) && (unsigned)((0x7fffffffu >> (0xb7780792u & 31u)) < r0.y));
    } else {
        if ((unsigned)((int)g0 < (int)(0x23b4293bu << (g1 & 31u)))) goto L2;
        *mp = (unsigned)(fuel < 0x10000u);
    }
    if ((unsigned)f0) {
        c0 = (unsigned char)(unsigned)(a0[u1 & 3u] || (unsigned)((int)(unsigned)(w0 >> 29) < (int)i0));
    }
    if ((unsigned)b0) goto L4;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        s0 = (int)((unsigned)h0 << ((0x7fffffffu / (i2 | 1u)) & 31u));
    }
    d0 = d0 * 0.5 + (double)((8u | (unsigned)b0) & 1023u);
    w0 ^= (unsigned long long)(unsigned)e0 << ((unsigned)s0 & 63u);
    if ((unsigned)((u1 - 0x10000u) == (unsigned)f0)) goto L1;
    if (g0) {
        c1 = (signed char)(unsigned)(signed char)((unsigned)(u0 == 0xae001336u) | (unsigned)(signed char)((unsigned)(1u == 0xbbb3970u) >> (0u & 31u)));
        goto L4;
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)(m0 | 6u) > (signed char)i0)) continue;
            *q0 += (((unsigned)(x0 >> 70) >> (0xb1ea6e14u & 31u)) ? 8u : ~(v0 * p0));
            if ((unsigned)((short)i1 > (signed char)(0x1a0db371u / (u3 | 1u)))) {
                switch ((i0 << ((r0.y >> (0x393466b4u & 31u)) & 31u)) & 7u) {
                    case 4u: ;
                    w0 ^= (unsigned long long)4u << ((unsigned)((int)(unsigned)(0x7fffffffu < (unsigned)b0) < (int)u3) & 63u);
                    h0 = (short)(a0[u1 & 3u] << (i0 & 31u));
                    continue; (void)(p1);
                    f0 = f0 * 0.5f + (float)((m0 | (unsigned)(signed char)(fuel ? (unsigned)(w0 >> 29) : p2)) & 255u);
                    if (g1) break;
                }
                *q0 = (unsigned)!(unsigned)((int)(unsigned)!(unsigned)(0xffffffffu == m0) >= (int)(unsigned)((unsigned)((unsigned)h0 == *mp) || (unsigned)(w0 >> 29)));
            } else {
                if ((unsigned)((int)0x209980c6u >= (int)(unsigned)((int)0x82f95cc8u >= (int)garr[u2 & 7u]))) break;
                if (((unsigned)(short)(unsigned)((unsigned)(w0 >> 29) == 0xffffffffu) | 4u)) break;
                break; (void)((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)((short)garr[i1 & 7u] > (signed char)garr[i1 & 7u])));
                if ((unsigned)(unsigned char)(unsigned)(0x7fc7c9e7u || 0x9c3fbb1u)) break;
            }
            while (i1++ < 2u && ((p1 ^ (unsigned)s1) ^ p0)) { if (--fuel == 0u) goto done;
                q0 = &garr[7u & 7u];
            }
        }
        if (g0) goto L0;
        if (u3 == 7u) return (unsigned)((unsigned)(7u < 3u) == (unsigned)b0);
    } else {
        while (((unsigned)h0 & (unsigned)s1)) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (r0.x) break;
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    a0[p0 & 3u] = (unsigned)((short)p2 > (signed char)4u);
                    g0 = (unsigned)(short)((unsigned)((u3 & (unsigned)b0) || (unsigned)x0) << (v0 & 31u));
                    { unsigned t4; double z4; if ((p2) & 1u) { t4 = (0x7fffffffu >> (i0 & 31u)); z4 = (double)((i1) & 255u); } if ((p2) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                        a0[(unsigned)c1 & 3u] = (unsigned)((short)u3 > (signed char)0xffffffffu);
                        u0 += (unsigned)!((unsigned)(short)(unsigned)((unsigned)l0 || 6u) / (p0 | 1u));
                        break; (void)((5u << (7u & 31u)));
                        *q0 = (unsigned)(x0 >> 70);
                        if (((unsigned)((unsigned)b0 == (unsigned)(w0 >> 29)) / (r0.y | 1u))) continue;
                    }
                    if ((garr[u2 & 7u] + 0x6bbdc2ddu)) break;
                }
                if ((0x10000u << (0x80000000u & 31u))) {
                    { unsigned t5; double z5; if (((garr[i1 & 7u] % (0x10000u | 1u))) & 1u) { t5 = (unsigned)(signed char)(i0 & (unsigned)x0); z5 = (double)((*q0) & 255u); } if (((garr[i1 & 7u] % (0x10000u | 1u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                        x0 = x0 * 0x100000001b3ull + ((unsigned)(short)(g1 % (1u | 1u)) | m0);
                        l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)((g1 << (((unsigned)w0 | g1) & 31u)) == (unsigned)(0x80000000u || i2)));
                        if (((unsigned)((int)1u < (int)(unsigned)(x0 >> 70)) << (0xd1f49296u & 31u))) break;
                        u0 ^= (unsigned)((int)((7u & (unsigned)d0) << ((unsigned)!(unsigned)((int)v0 < (int)p2) & 31u)) < (int)(unsigned)w0);
                        if (-(2u & r0.x)) break;
                    }
                }
                f0 = f0 * 0.5f + (float)((unsigned)((int)garr[i1 & 7u] < (int)m0) & 255u);
            }
            if (((unsigned)e0 - (unsigned)s0)) break;
        }
        switch (g0 & 7u) {
            f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)(0x80000000u < 0xa6b8bec3u) >= (int)((unsigned)f0 | u0)) & 255u);
            f0 = f0 * 0.5f + (float)((unsigned)(0x7fffffffu == 9u) & 255u);
        }
    }
    if (((unsigned)h1 * i1)) goto L1;
    switch ((unsigned)f0 & 7u) {
        if (0xd2410ab0u) {
            do { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (unsigned)x0;
                switch ((unsigned)(p2 || ((unsigned)l0 * 5u)) & 7u) {
                    g0 = ((unsigned)((short)garr[i1 & 7u] > (signed char)p1) >> ((a0[u1 & 3u] + fuel) & 31u));
                    l0 = (long)((unsigned long)l0 + ((unsigned)h0 % ((i1 + 8u) | 1u)));
                }
                case 2u: ;
            } while (i0++ < 2u && (unsigned)b0);
            v0 = (unsigned)((unsigned)w0 < (unsigned)((unsigned)c0 || (unsigned)(short)(unsigned)(0xe9167633u && p0)));
        } else {
            while ((unsigned)((int)u1 < (int)(9u << (0xb1d08298u & 31u)))) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (unsigned)(x0 >> 70);
                case 7u: ;
                case 1u: ;
                *q0 += u1;
            }
            s0 = (int)(unsigned)((int)8u >= (int)((unsigned)e0 >> (u2 & 31u)));
            while (i0++ < 4u && (unsigned)(fuel < (unsigned)((unsigned)f0 || (unsigned)s1))) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)b0 == r0.x)) goto L3;
                case 5u: ;
                case 4u: ;
                default: ;
                goto L4;
            }
        }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(garr[i1 & 7u] < r0.x) < (unsigned)((unsigned)(signed char)(unsigned)(0x232f4474u || (unsigned)e0) == garr[u2 & 7u])) & 255u);
        }
        case 6u: ;
    }
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                *q0 = (unsigned)(u1 < (unsigned)(0u && (-(unsigned)(i1 && garr[i1 & 7u]) / ((unsigned)d0 | 1u))));
                while (i0++ < 7u && fuel) { if (--fuel == 0u) goto done;
                    v0 = ((1u / ((unsigned)h0 | 1u)) << ((garr[i1 & 7u] >> ((garr[i1 & 7u] & (unsigned)d0) & 31u)) & 31u));
                }
                f0 = f0 * 0.5f + (float)((unsigned)c1 & 255u);
                *q0 = (unsigned)((0x80000000u + garr[u2 & 7u]) || (0xaa6af9fdu ? *q0 : 0x10000u));
                if ((unsigned)(signed char)(unsigned)((int)6u >= (int)(unsigned)(0x4acd9072u && 0xffffffffu))) break;
                *mp = (unsigned)((unsigned)c1 == (0x48b2e1f8u / (0xffffffffu | 1u)));
            } while (i2++ < 6u && (unsigned)((unsigned)(p2 < (unsigned)f0) == 0xa0910b87u));
            if ((unsigned)((unsigned)(x0 >> 70) && 0xffffffffu)) {
                f0 = f0 * 0.5f + (float)((unsigned)(short)((unsigned)b0 ? 0x119ff1bfu : (unsigned)w0) & 255u);
            } else {
                m0 ^= (unsigned)!(0x4814e0c6u - (garr[u2 & 7u] << (*mp & 31u)));
                switch (((unsigned)(unsigned char)(g1 * p2) | (unsigned)e0) & 7u) {
                    h0 = (short)p0;
                    i1 = 0xf3296288u & 15u;
                    case 4u: ;
                    goto L1;
                }
                if (m0) {
                    q0 = &garr[(unsigned)((unsigned)(x0 >> 70) || (unsigned)((unsigned)s0 || u0)) & 7u];
                    s0 = (int)0x7fffffffu;
                    b0 = ((unsigned)c0 / (i1 | 1u)) != 0u;
                    if (fuel < 8u) return (r0.x / (g0 | 1u));
                    u0 = u0 * 0x9e3779b1u + ((unsigned)h0 ^ ((unsigned)((0x10000u + (unsigned)c1) || (unsigned)w0) - (unsigned)e0));
                    if ((unsigned)((int)0x7fffffffu < (int)0x10000u)) break;
                } else {
                    { unsigned t6; double z6; if (((unsigned)((0x1da667fbu << (fuel & 31u)) || garr[u2 & 7u])) & 1u) { t6 = (a0[i0 & 3u] ? 0xa673d710u : *mp); z6 = (double)((i1) & 255u); } if (((unsigned)((0x1da667fbu << (fuel & 31u)) || garr[u2 & 7u])) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                        if ((unsigned)(w0 >> 29)) goto L4;
                        break; (void)(u1);
                        c0 = (unsigned char)((unsigned)(x0 >> 70) | (unsigned)((unsigned)x0 && (u2 >> (g1 & 31u))));
                        u3 = u3 * 0x9e3779b1u + (u2 << (((unsigned)c1 / (p2 | 1u)) & 31u));
                    }
                    if ((0x10000u % ((i2 / (0x10000u | 1u)) | 1u))) break;
                }
            }
        }
        if (u3 == 7u) return (((unsigned)c0 % (a0[i0 & 3u] | 1u)) ? i0 : v0);
        if ((unsigned)(-(0xf3e203abu & garr[u2 & 7u]) || r0.y)) goto done;
        c1 = (signed char)(unsigned)((unsigned)((r0.x & (unsigned)h0) == 0x10000u) == ((unsigned)b0 | *q0));
    } while (i0++ < 7u && *mp);
    if (0x709400u) goto L0;
    g0 = (unsigned)(i1 < (unsigned)e0);
    goto done;
    if (fuel < 8u) return (unsigned)(signed char)(unsigned)((unsigned)x0 == 0xf8e214bau);
    if (((unsigned)f0 % ((unsigned)((int)i2 >= (int)garr[u2 & 7u]) | 1u))) goto done;
    if ((4u / ((unsigned)c1 | 1u))) {
        b0 = (unsigned)((int)(0x9988bfa1u % (i1 | 1u)) < (int)-(unsigned)((short)4u > (signed char)p0)) != 0u;
        if ((unsigned)((short)0xffffffffu > (signed char)p0)) goto L2;
        switch (0x7fffffffu & 7u) {
            { unsigned t7; double z7; if (((unsigned)!((unsigned)c0 * 0x2ff0ae6eu)) & 1u) { t7 = (0xffffffffu & i0); z7 = (double)((((unsigned)(signed char)(unsigned)(0xd719e9d2u < p2) - (unsigned)h0)) & 255u); } if (((unsigned)!((unsigned)c0 * 0x2ff0ae6eu)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                u2 += (garr[u2 & 7u] - (g0 & (*mp % (0xa6ebfa1bu | 1u))));
                if ((r0.x | (unsigned)(i0 < 8u))) goto L1;
            }
            if (u3 == 7u) return (unsigned)((int)r0.y >= (int)(unsigned)!(unsigned)((unsigned)f0 < u3));
            case 7u: ;
            do { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (3u - u0));
                u3 = (unsigned)((int)-(0xb67d2071u * (unsigned)c1) < (int)(unsigned)s1);
                case 2u: ;
                if (fuel < 8u) return ((unsigned)c0 / ((unsigned)l0 | 1u));
            } while (i0++ < 6u && 0u);
            goto L2;
        }
    }
    switch ((unsigned)((unsigned)(x0 >> 70) || garr[u2 & 7u]) & 7u) {
        u3 += ((unsigned)(signed char)((unsigned)s1 >> ((unsigned)c0 & 31u)) ^ *mp);
        case 1u: ;
        case 3u: ;
        e0 = e0 * 0.5L + (long double)(~(unsigned)((short)9u > (signed char)m0) & 1023u);
        g1 += (unsigned)((unsigned)l0 && (unsigned)s0);
        u2 += ((unsigned)c0 / ((unsigned)((int)(r0.x ^ garr[i1 & 7u]) >= (int)(unsigned)(garr[i1 & 7u] || *q0)) | 1u));
    }
    h1 = (unsigned short)(h1 + (unsigned)(((unsigned)((int)(unsigned)x0 >= (int)u2) & (garr[i1 & 7u] / (p2 | 1u))) == 0xffffffffu));
    goto L1;
    if ((unsigned)!(((unsigned)c0 >> ((unsigned)h0 & 31u)) ^ 0xdd7bb79fu)) goto done;
    if ((a0[u1 & 3u] << (1u & 31u))) {
        if ((unsigned)((int)i2 >= (int)((unsigned)l0 + p0))) {
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)f0 || (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)l0))) {
                    garr[(a0[i0 & 3u] * (unsigned)l0) & 7u] = a0[u1 & 3u];
                    if ((garr[u2 & 7u] >> ((unsigned)(0x10000u || 0x7072c02du) & 31u))) break;
                    b0 = (unsigned)s0 != 0u;
                } else {
                    if ((0xffffffffu << ((0x1a2ea5dcu % ((unsigned)b0 | 1u)) & 31u))) break;
                }
                a0[9u & 3u] = (3u - g0);
            }
            i0 = ((0x9ce9f61bu * a0[u1 & 3u]) ^ (unsigned)s1) & 15u;
            f0 = f0 * 0.5f + (float)(0x80000000u & 255u);
            do { if (--fuel == 0u) goto done;
                a0[(unsigned)(2u < garr[u2 & 7u]) & 3u] = (unsigned)((int)(unsigned)(unsigned char)((unsigned)(signed char)(unsigned)(a0[i0 & 3u] < u1) + 0xf7fc5f80u) >= (int)0x76f985aau);
            } while (i0++ < 3u && ((unsigned)l0 % (9u | 1u)));
            switch ((i0 << (p1 & 31u)) & 7u) {
                b0 = ((unsigned)(0x3fdae9cu < 0x1b241af5u) * (unsigned)!((unsigned)(unsigned char)(unsigned)((int)0x544b56ceu < (int)p2) - garr[u2 & 7u])) != 0u;
                while (i0++ < 2u && (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)(0xe8d52261u < (unsigned)w0))) { if (--fuel == 0u) goto done;
                    case 6u: ;
                    goto L3;
                    u3 = ((unsigned)!(a0[u1 & 3u] * 1u) << ((unsigned)!(unsigned)(g1 == m0) & 31u));
                    case 7u: ;
                }
                case 1u: ;
                e0 = e0 * 0.5L + (long double)((r0.x << ((unsigned)((((unsigned)x0 & u3) - 0x7fffffffu) == 5u) & 31u)) & 1023u);
            }
        }
        q0 = &garr[p1 & 7u];
        d0 = d0 * 0.5 + (double)((2u / (((unsigned)!(u1 | 0u) % (5u | 1u)) | 1u)) & 1023u);
        l0 = (long)((unsigned long)l0 + u0);
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(5u < garr[u2 & 7u])) continue;
            v0 = (unsigned)(signed char)(unsigned)(2u < 4u);
            if (fuel) break;
            if ((unsigned)(g0 && g0)) goto L1;
            b0 = ~((unsigned)w0 - p0) != 0u;
        } while (i0++ < 6u && (unsigned)(garr[u2 & 7u] || p1));
        if (g1) goto L4;
    }
    if (((7u - (unsigned)c1) % ((unsigned)f0 | 1u))) {
        if ((u3 + *mp)) goto done;
        h0 = (short)(((unsigned)f0 | p0) ? 8u : (0x40364a69u & i1));
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 7u && ~(0x5d190568u ? i2 : 0x741c68a0u)) { if (--fuel == 0u) goto done;
                if ((g0 & (unsigned)h1)) break;
                if (((unsigned)(x0 >> 70) + (unsigned)(w0 >> 29))) break;
            }
        }
        if (((fuel + 0u) + (unsigned)f0)) goto L3;
    }
    if ((unsigned)((unsigned)s1 && garr[u2 & 7u])) goto L2;
    if (i1) goto L1;
    l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)(2u < (unsigned)((unsigned)l0 == (unsigned)((short)fuel > (signed char)(unsigned)w0))));
    u2 = u2 * 0x9e3779b1u + (unsigned)x0;
    goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)((unsigned)w0 % (a0[u1 & 3u] | 1u)) < (int)r0.y), (0x367cb007u % ((unsigned)c1 | 1u)), ((r0.x & i2) * 0x10000u)); }
            for (;;) { if (--fuel == 0u) goto done;
                u3 += (unsigned)(0x10000u || a0[u1 & 3u]);
                L0: if (--fuel == 0u) goto done;
            }
        } while (i1++ < 2u && (unsigned)(r0.y == 0xffffffffu));
        e0 = e0 * 0.5L + (long double)((0x80000000u | ((unsigned)s1 ^ r0.x)) & 1023u);
    }
    if ((a0[u1 & 3u] / (r0.y | 1u))) goto done;
    c0 = (unsigned char)~(unsigned)(g0 == 0u);
    b0 = ((unsigned)(g1 == i2) ? 0xffffffffu : (a0[u1 & 3u] >> (a0[u1 & 3u] & 31u))) != 0u;
    if ((unsigned)w0) goto L0;
    goto L1;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(a0[u1 & 3u] == 0x142d85b2u), (unsigned)((int)(i1 / (r0.x | 1u)) < (int)fuel), (unsigned)((int)(unsigned)(x0 >> 70) >= (int)v0)); }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((r0.x | (unsigned)((int)0xac87cb73u < (int)8u)), (unsigned)x0, (unsigned)((int)*mp < (int)(unsigned)c0)); }
    if (budget != 0u) { budget -= 1u; u3 = fn0(0x10000u, 0xcbdfa2e8u, (unsigned)w0); }
    l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)l0 >= (int)((unsigned)(unsigned char)(1u % ((unsigned)c1 | 1u)) / (0xc6614c8bu | 1u))));
    if (budget != 0u) { budget -= 1u; u0 = fn0((i0 / (0xffffffffu | 1u)), (unsigned)(a0[u1 & 3u] && (4u * u2)), (u0 * (unsigned)(w0 >> 29))); }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)(w0 >> 29) << ((unsigned)s0 & 31u))) break;
        if ((unsigned)(short)(unsigned)((int)(i0 | (unsigned)c1) < (int)4u)) break;
    }
    { unsigned t0; double z0; if ((m0) & 1u) { t0 = garr[i1 & 7u]; z0 = (double)(((((unsigned)s1 | 0x7fffffffu) << ((unsigned)f0 & 31u))) & 255u); } if ((m0) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            garr[(unsigned)((int)u3 < (int)(unsigned)s0) & 7u] = r0.x;
            switch (0xd0323dd7u & 7u) {
                h0 = (short)0xcbbc9149u;
                if (budget != 0u) { budget -= 1u; u1 = fn0((fuel ^ r0.y), ((unsigned)d0 ^ (4u << ((unsigned)s0 & 31u))), (unsigned)b0); }
                { unsigned t1; double z1; if (((garr[i1 & 7u] << ((unsigned)c0 & 31u))) & 1u) { t1 = i2; z1 = (double)(((a0[i0 & 3u] % ((unsigned)((int)0x10000u < (int)0xd386933du) | 1u))) & 255u); } if (((garr[i1 & 7u] << ((unsigned)c0 & 31u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    case 0u: ;
                    *mp = (unsigned)((int)(unsigned)(w0 >> 29) >= (int)((u1 >> (0xa649fd54u & 31u)) / ((unsigned)(short)(i2 | (unsigned)s1) | 1u)));
                }
                w0 ^= (unsigned long long)(unsigned)((short)3u > (signed char)0x7fffffffu) << ((i1 | (unsigned)(p0 < (unsigned)(short)((unsigned)s1 % (p1 | 1u)))) & 63u);
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)h1, (unsigned)((garr[u2 & 7u] / (0xf0d219eau | 1u)) || 0x80000000u), (i0 ^ (unsigned)!(unsigned)(0x2c17f966u && 0x455c8b46u))); }
            }
            h1 = (unsigned short)(h1 + ((unsigned)b0 ^ (unsigned)h0));
            u3 += (unsigned)(garr[u2 & 7u] || (unsigned)((int)p2 < (int)(*mp % ((unsigned)c0 | 1u))));
            if ((unsigned)(p1 < 0xd5903b1bu)) {
                s0 = (int)r0.x;
                if ((unsigned)(-(unsigned)(0x84d55cbfu && (unsigned)(w0 >> 29)) < r0.y)) goto L1;
                q0 = &garr[(unsigned)!((u1 + i2) % (i0 | 1u)) & 7u];
                switch (0x7fffffffu & 7u) {
                    if (-((unsigned)!(i1 - *q0) >> ((unsigned)s0 & 31u))) continue;
                }
                while (i1++ < 7u && (unsigned)(((unsigned)w0 + (unsigned)c1) && 0u)) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + p0);
                    if (p1) break;
                    L1: if (--fuel == 0u) goto done;
                }
                m0 ^= (unsigned)((int)((unsigned)h1 % ((unsigned)(x0 >> 70) | 1u)) >= (int)u2);
            } else {
                if ((0x80000000u + (unsigned)s0)) break;
                break; (void)((*q0 & 0x7fffffffu));
                if ((0x10000u + ((unsigned)c0 ^ (unsigned)(x0 >> 70)))) break;
            }
            if ((unsigned)((int)(unsigned)f0 < (int)(fuel ^ 8u))) {
                L2: if (--fuel == 0u) goto done;
                u2 = (((unsigned)e0 ^ (unsigned)((short)(garr[u2 & 7u] - i1) > (signed char)(unsigned)e0)) << (p2 & 31u));
                L3: if (--fuel == 0u) goto done;
                if ((unsigned)(*q0 < 8u)) break;
            } else {
                l0 = (long)((unsigned long)l0 + ((garr[i1 & 7u] / ((unsigned)l0 | 1u)) & i2));
                e0 = e0 * 0.5L + (long double)((((u2 << (p1 & 31u)) | 3u) + (unsigned)(u1 < 0x7fffffffu)) & 1023u);
            }
        }
        if (u0) {
            if ((m0 / (~(unsigned)((int)m0 >= (int)0x80000000u) | 1u))) goto L4;
            s1 = (int)((unsigned)s1 + (p0 - (i2 ? p1 : u0)));
        }
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (unsigned)((0x80000000u * ((unsigned)c0 % ((0x78a9d8acu | 0x80000000u) | 1u))) && garr[i1 & 7u]);
        s1 = (int)((unsigned)s1 + (unsigned)c1);
        r0.x = (unsigned)((unsigned)((short)m0 > (signed char)garr[u2 & 7u]) == (unsigned)((int)(unsigned)(u2 && a0[u1 & 3u]) >= (int)(unsigned)h0));
        if ((2u | p1)) {
            do { if (--fuel == 0u) goto done;
                if ((u0 * (unsigned)!(0xb63da5f0u << (9u & 31u)))) break;
                u2 += (unsigned)(0x7fffffffu && (unsigned)(g0 == ((unsigned)(signed char)(unsigned)((int)(unsigned)f0 >= (int)g0) ^ (unsigned)s1)));
                if (r0.x) break;
                while (i2++ < 5u && 4u) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(unsigned)c0;
                    do { if (--fuel == 0u) goto done;
                        break; (void)((*mp | 0x80000000u));
                        *q0 += (unsigned)((2u % ((unsigned)((short)(p2 & 0xdd23f370u) > (signed char)r0.x) | 1u)) || p2);
                        while (i1++ < 3u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                            s0 = (int)((0u ? 6u : (unsigned)x0) * 0x10000u);
                            if (budget != 0u) { budget -= 1u; u2 = fn0(i2, ((unsigned)b0 ? (unsigned)(w0 >> 29) : (unsigned)s0), (g1 / (0x756f9062u | 1u))); }
                            L4: if (--fuel == 0u) goto done;
                            *mp = (unsigned)((int)(unsigned)(2u || ((unsigned)b0 >> (m0 & 31u))) < (int)(unsigned)((int)(unsigned)h0 >= (int)u1));
                            h0 = (short)*q0;
                            break; (void)(v0);
                        }
                        u2 = (unsigned)(((unsigned)(signed char)(u0 & p1) << (v0 & 31u)) || (unsigned)x0);
                        r0.x = -(0xffffffffu + p0);
                        l0 = (long)((unsigned long)l0 + ((unsigned)((int)(unsigned)((int)(unsigned)h0 < (int)p2) < (int)u1) >> (a0[i0 & 3u] & 31u)));
                    } while (i0++ < 6u && 0xfe934ac8u);
                }
            } while (i1++ < 2u && (unsigned)!(u1 + (unsigned)((int)(unsigned)c1 >= (int)(unsigned)w0)));
            h1 = (unsigned short)(h1 + (unsigned)((int)((unsigned)((unsigned)e0 && v0) >> ((unsigned)s0 & 31u)) < (int)a0[i0 & 3u]));
        }
        while (i1++ < 6u && a0[i0 & 3u]) { if (--fuel == 0u) goto done;
            *mp = (((unsigned)x0 / (r0.y | 1u)) - (unsigned)h1);
            continue; (void)((unsigned)(8u && 0xf1910d14u));
        }
        *q0 += ((unsigned)!((unsigned)(w0 >> 29) % (garr[u2 & 7u] | 1u)) + *q0);
    }
    c0 = (unsigned char)((p0 + 0xeeb4ef64u) * (unsigned)h1);
    f0 = f0 * 0.5f + (float)(0x7fffffffu & 255u);
    if ((unsigned)((short)0x10000u > (signed char)0x2e6b9eddu)) {
        if ((unsigned)e0) goto L0;
    }
    *q0 = ((*q0 | p0) & 0xffffffffu);
    while ((unsigned)f0) { if (--fuel == 0u) goto done;
        u1 += 0xec9a1de1u;
        if (((unsigned)(w0 >> 29) * fuel)) {
            if ((unsigned)((int)(unsigned)h0 >= (int)(unsigned)((int)i0 < (int)u3))) break;
        } else {
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((0x7fffffffu | i1)) break;
            }
            switch (0x80000000u & 7u) {
                if (8u) {
                    if (budget != 0u) { budget -= 1u; u3 = fn0(0x346bb108u, m0, (0x7fffffffu - p1)); }
                    { unsigned t2; double z2; if (((unsigned)(a0[i0 & 3u] && (unsigned)c0)) & 1u) { t2 = ((unsigned)(w0 >> 29) & *mp); z2 = (double)((u1) & 255u); } if (((unsigned)(a0[i0 & 3u] && (unsigned)c0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                        case 3u: ;
                        r0.y ^= (unsigned)(signed char)(unsigned)((int)(unsigned)((int)0x10000u >= (int)0xefe8b7cbu) < (int)p1);
                        case 4u: ;
                        garr[(unsigned)((unsigned)e0 && garr[i1 & 7u]) & 7u] = g1;
                        v0 = (unsigned)(garr[i1 & 7u] == 5u);
                        i1 = (unsigned)(unsigned char)(unsigned)(garr[i1 & 7u] < (g0 >> ((m0 ^ (unsigned)((unsigned)h1 || (unsigned)b0)) & 31u))) & 15u;
                    }
                }
                x0 = x0 * 0x100000001b3ull + *mp;
            }
        }
        while (i1++ < 6u && (unsigned)((int)((unsigned)h0 + u3) >= (int)8u)) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)(((unsigned)(short)(0xd32ef595u ^ (unsigned)(v0 && 8u)) ? 0xbd931bb6u : (unsigned)d0) & 1023u);
                    continue; (void)((unsigned)!((0x29ccde59u % (0xffffffffu | 1u)) & u0));
                    if (fuel < 8u) return g1;
                    r0.y ^= (unsigned)((unsigned)w0 < m0);
                    if ((i0 | i1)) goto L4;
                    if ((unsigned)e0) break;
                }
                b0 = (unsigned)b0 != 0u;
                if (((unsigned)l0 / ((unsigned)e0 | 1u))) break;
                a0[(0x7fffffffu + i0) & 3u] = ((unsigned)((unsigned)(a0[i0 & 3u] && 0xf21a15b7u) == (unsigned)(w0 >> 29)) << (0xcf6324c2u & 31u));
            }
            if (garr[i1 & 7u]) break;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)(0x10000u - a0[u1 & 3u]), (((unsigned)h0 - (unsigned)(w0 >> 29)) + u1), (unsigned)c1); }
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                r0.x = (g1 ^ (unsigned)h0);
                if ((0x4c7f8be4u % (p0 | 1u))) break;
                break; (void)((unsigned)(unsigned char)((unsigned)f0 & *q0));
            }
        }
        g1 += (r0.x ^ ((unsigned)w0 & 0xffffffffu));
        u2 = ((i0 % (0x83bad624u | 1u)) & u1);
        r0.y ^= ((unsigned)x0 - r0.y);
    }
    { unsigned t3; double z3; if (((0u + (unsigned)(0x64af25a8u == i0))) & 1u) { t3 = p0; z3 = (double)(((unsigned)((unsigned)((short)g0 > (signed char)(unsigned)d0) || (unsigned)e0)) & 255u); } if (((0u + (unsigned)(0x64af25a8u == i0))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        if ((unsigned)((short)0x3918fefeu > (signed char)(unsigned)((int)*q0 < (int)*mp))) goto L0;
    }
    h1 = (unsigned short)(h1 + (~(unsigned)((unsigned)(x0 >> 70) == ~(p2 % ((unsigned)d0 | 1u))) | i0));
    if ((a0[u1 & 3u] + (unsigned)d0)) {
        if (((unsigned)(w0 >> 29) * (unsigned)f0)) {
            { unsigned t4; double z4; if (((unsigned)((unsigned)((short)0x7fffffffu > (signed char)p0) || u2)) & 1u) { t4 = 8u; z4 = (double)((0x10000u) & 255u); } if (((unsigned)((unsigned)((short)0x7fffffffu > (signed char)p0) || u2)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                d0 = d0 * 0.5 + (double)(((i2 << (v0 & 31u)) + (unsigned)h0) & 1023u);
                goto L0;
                *mp = *q0;
                h1 = (unsigned short)(h1 + (0x5eb7439fu >> ((g1 >> (0x80000000u & 31u)) & 31u)));
                garr[(0x4bed8e3du << ((unsigned)w0 & 31u)) & 7u] = (unsigned)((unsigned)h0 && g1);
                if (budget != 0u) { budget -= 1u; u0 = fn0(i0, (0x1ea1df6cu - (unsigned)(w0 >> 29)), m0); }
            }
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.x = ((unsigned)b0 | (unsigned)l0);
                e0 = e0 * 0.5L + (long double)(((unsigned)((unsigned)(w0 >> 29) && (unsigned)h0) * (unsigned)((int)(unsigned)f0 >= (int)u2)) & 1023u);
                q0 = &garr[(unsigned)(p1 && 0x7fffffffu) & 7u];
                if (((unsigned)b0 | (unsigned)h1)) break;
            }
        } else {
            goto L3;
        }
        goto L4;
        while (i0++ < 5u && 7u) { if (--fuel == 0u) goto done;
            a0[(unsigned)!(0x80000000u | (unsigned)w0) & 3u] = (unsigned)((int)v0 < (int)(unsigned)f0);
            u0 += *q0;
        }
        r0.y ^= ((unsigned)w0 ^ (unsigned)(a0[i0 & 3u] < i0));
        if ((0xccc010e6u | g0)) {
            if ((*mp >> (8u & 31u))) goto L3;
        }
    }
    while ((unsigned)(g0 < fuel)) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (g0 ^ ((unsigned)s1 - 0x7233eafeu));
    }
    g0 = (unsigned)((int)((unsigned)b0 * (unsigned)(w0 >> 29)) < (int)(unsigned)(r0.x || 7u));
    u2 = u2 * 0x9e3779b1u + (unsigned)x0;
    if (0xffffffffu) {
        v0 = (0x7fffffffu - i1);
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)!(a0[u1 & 3u] % (9u | 1u)) + (unsigned)l0), (unsigned)(2u && (unsigned)((int)i0 >= (int)p0)), (unsigned)((int)0xcbb86099u < (int)garr[i1 & 7u])); }
        goto done;
    }
    a0[u2 & 3u] = ((unsigned)(short)(0x80000000u & p0) + (8u % (g0 | 1u)));
    if (0u) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)w0 + 0xe2392ab0u) == g0));
            if (0xd4956623u) {
                if ((unsigned)(r0.y == 4u)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)x0, (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)x0), u3); }
                *q0 = (5u >> ((unsigned)(signed char)(unsigned)((int)fuel < (int)(unsigned)(p0 || (unsigned)((int)*mp >= (int)3u))) & 31u));
            } else {
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((5u / ((unsigned)(2u < 8u) | 1u)));
                    garr[(unsigned)f0 & 7u] = (unsigned)(garr[u2 & 7u] == a0[i0 & 3u]);
                }
            }
            *q0 += (unsigned)!(0xb0f87a86u ? p1 : u2);
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                b0 = 0x10000u != 0u;
                f0 = f0 * 0.5f + (float)(garr[u2 & 7u] & 255u);
                switch ((unsigned)((unsigned)(u0 < 0xe777fbb3u) && (unsigned)h1) & 7u) {
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(w0 >> 29), ~(unsigned)((short)9u > (signed char)-(0xb2989dfau | m0)), (0xb9d1ffb3u + (unsigned)(7u || (unsigned)h1))); }
                }
                if ((unsigned)(u2 == (0x7fffffffu * (unsigned)h0))) goto L0;
            }
            { unsigned t5; double z5; if (((unsigned)(signed char)(0xeabc48e9u << (0x1991e386u & 31u))) & 1u) { t5 = i0; z5 = (double)((-(unsigned)(garr[i1 & 7u] || i2)) & 255u); } if (((unsigned)(signed char)(0xeabc48e9u << (0x1991e386u & 31u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                b0 = 6u != 0u;
                break; (void)(((unsigned)c0 - 8u));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(v0 < ~((unsigned)l0 % (0x80000000u | 1u))), (*q0 & i2), ((unsigned)(w0 >> 29) / ((unsigned)b0 | 1u))); }
                h1 = (unsigned short)(h1 + (unsigned)(a0[u1 & 3u] < (u2 % ((0x6986dcd2u << (0xffffffffu & 31u)) | 1u))));
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (r0.x + (unsigned)!(unsigned)(i1 || 2u)));
                    e0 = e0 * 0.5L + (long double)((0xffffffffu & (0x7fffffffu << ((unsigned)(fuel == i0) & 31u))) & 1023u);
                    do { if (--fuel == 0u) goto done;
                        continue; (void)((unsigned)!(r0.x << ((unsigned)l0 & 31u)));
                        if ((0x7fffffffu * (unsigned)((unsigned)w0 || i2))) continue;
                        switch (((unsigned)((unsigned)s1 < 4u) - i0) & 7u) {
                            b0 = ((unsigned)(short)(0xffffffffu >> ((i0 / ((0x7a189188u / (0xd8b3af9cu | 1u)) | 1u)) & 31u)) << (0x10000u & 31u)) != 0u;
                            case 1u: ;
                            continue; (void)(~(unsigned)(((unsigned)s0 % (0xffffffffu | 1u)) && (unsigned)l0));
                            case 7u: ;
                        }
                        if ((unsigned)((int)u1 < (int)(unsigned)((int)v0 >= (int)(unsigned)b0))) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(((unsigned)h1 - (unsigned)f0) == (unsigned)e0), ((u3 + 0x10000u) ^ g0), 0xa1211b51u); }
                    } while (i2++ < 5u && fuel);
                    if ((unsigned)(signed char)(unsigned)((int)0xe186913cu < (int)0x5d1add2eu)) goto L1;
                }
            }
            if (u0) continue;
        }
        if (i1) {
            if (((0x10000u & 0x5de89637u) + (unsigned)c0)) goto L2;
            if ((unsigned)((unsigned)x0 || u1)) goto L4;
        }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((i0 | 0xb6385656u) || (unsigned)(x0 >> 70))) break;
        }
    } else {
        if (g0) {
            e0 = e0 * 0.5L + (long double)((-(unsigned)((int)g0 < (int)0xdf1d5582u) / ((unsigned)(short)(3u | (unsigned)w0) | 1u)) & 1023u);
            { unsigned t6; double z6; if (((unsigned)(u0 == g1)) & 1u) { t6 = -(unsigned)((short)r0.x > (signed char)0xc29bf54au); z6 = (double)(((unsigned)(signed char)(unsigned)((unsigned)x0 == garr[i1 & 7u])) & 255u); } if (((unsigned)(u0 == g1)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(short)(p0 * u1) && (unsigned)(x0 >> 70)), u2, (unsigned)((unsigned)b0 < 7u)); }
                a0[7u & 3u] = ((unsigned)(g0 == 0x79b31e07u) ^ (fuel << ((r0.y ^ 0x8934d83u) & 31u)));
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(p1 / ((unsigned)s1 | 1u)) << ((unsigned)((unsigned)c1 < i0) & 63u);
                    if ((unsigned)(unsigned char)(unsigned)(3u < i1)) goto done;
                    garr[0xf2c20fe3u & 7u] = 5u;
                    if (0x80000000u) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)s1, (unsigned)((short)0x10000u > (signed char)a0[i0 & 3u]), (unsigned)(x0 >> 70)); }
                    if (g1) goto L0;
                }
                if ((unsigned)(u1 == (r0.x | u2))) goto L3;
                if (i2) goto done;
            }
            goto L3;
            *q0 += (unsigned)(w0 >> 29);
            u3 = (5u ^ 2u);
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (0xffffffffu) break;
                { unsigned t7; double z7; if ((((unsigned)d0 * 0xffffffffu)) & 1u) { t7 = r0.x; z7 = (double)(((unsigned)(((unsigned)f0 & 0xffffffffu) == u0)) & 255u); } if ((((unsigned)d0 * 0xffffffffu)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                    break; (void)(((unsigned)f0 ? g0 : 0x2d56d47bu));
                }
                if ((fuel >> (0x5aa10c90u & 31u))) break;
                r0.y ^= ((0x7fffffffu - 2u) << ((unsigned)s1 & 31u));
                m0 ^= (unsigned)((short)(0xffffffffu - 0x529ecdbdu) > (signed char)((unsigned)e0 ^ (unsigned)(fuel || 0xc182bf08u)));
                if (((unsigned)((unsigned)c0 && p1) * (unsigned)x0)) {
                    switch (((unsigned)((int)i2 >= (int)fuel) & (unsigned)(w0 >> 29)) & 7u) {
                        if (-(unsigned)(~(i0 / (0xffffffffu | 1u)) < *mp)) goto L2;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(1u, (unsigned)h0, (0xa293bdbau / (3u | 1u))); }
                        m0 ^= (unsigned)!(0x80000000u & ((unsigned)((p0 >> (g0 & 31u)) && p1) & (unsigned)s1));
                        if (budget != 0u) { budget -= 1u; u2 = fn0(u3, (unsigned)((unsigned)(p1 == 0x80000000u) || 0xa3938961u), (3u | u0)); }
                    }
                    a0[(unsigned)((unsigned)(w0 >> 29) < *mp) & 3u] = 0x7fffffffu;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)h1, (unsigned)c1, (unsigned)((int)u1 >= (int)u0)); }
                    b0 = (unsigned)(p1 || a0[i0 & 3u]) != 0u;
                    r0.y ^= 0x10000u;
                } else {
                    break; (void)((p2 + (unsigned)(x0 >> 70)));
                    e0 = e0 * 0.5L + (long double)((unsigned)(garr[u2 & 7u] == garr[i1 & 7u]) & 1023u);
                }
            }
        } else {
            goto L3;
            m0 ^= ((unsigned)(unsigned char)((unsigned)h0 + u3) * (unsigned)!(unsigned)((unsigned)(w0 >> 29) == u0));
        }
        c0 = (unsigned char)(unsigned)((int)r0.y < (int)*mp);
    }
    goto L2;
    if (r0.y) {
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)(0xb122e23u ? 0x5d1b586eu : fuel), (unsigned)((short)(unsigned)!(0xdfb6122bu / ((unsigned)(x0 >> 70) | 1u)) > (signed char)0x80000000u), (unsigned)c1); }
            goto L4;
            x0 = x0 * 0x100000001b3ull + (*mp * garr[i1 & 7u]);
            if ((unsigned)((int)0xdc629d9au < (int)(unsigned)x0)) break;
            c0 = (unsigned char)~(g0 * (unsigned)(0x1b3f480cu == (unsigned)l0));
        } while (i0++ < 3u && (u2 / ((unsigned)(signed char)(0xefce7b16u & *q0) | 1u)));
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (u3 == 7u) return ((((unsigned)x0 - 1u) + 0xe4a01c8du) + p1);
            if ((*mp << ((unsigned)((short)u0 > (signed char)1u) & 31u))) goto L0;
            break; (void)((unsigned)(0x5fdc576u && 0x1c469226u));
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(i0 && 0x7fffffffu) || 0xee481f4au), (unsigned)((short)u2 > (signed char)(unsigned)l0), (unsigned)((int)(unsigned)h1 < (int)0x10000u)); }
            goto L3;
            if ((7u - (unsigned)((unsigned)w0 < r0.x))) break;
        }
        g0 = ((9u & p0) >> (garr[u2 & 7u] & 31u));
    } else {
        do { if (--fuel == 0u) goto done;
            continue; (void)(0x80000000u);
            a0[(unsigned)((int)0x751934bbu >= (int)0x10000u) & 3u] = (unsigned)l0;
        } while (i0++ < 6u && *q0);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    h1 = (unsigned short)(h1 + (unsigned)(u2 == (unsigned)(0xffffffffu || 0xda90fd0eu)));
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)!(unsigned)((i1 + (unsigned)l0) == (unsigned)(x0 >> 70)), (unsigned)(x0 >> 70), ((unsigned)(x0 >> 70) / ((i1 & 0x80000000u) | 1u))); }
    *q0 += (garr[i1 & 7u] + 0xf822a493u);
    { unsigned t0; double z0; if (((p2 << (i1 & 31u))) & 1u) { t0 = 0x80000000u; z0 = (double)(((unsigned)(short)(unsigned)(garr[u2 & 7u] || i2)) & 255u); } if (((p2 << (i1 & 31u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        goto L0;
        s1 = (int)((unsigned)s1 + ((u0 / (3u | 1u)) + 0x80000000u));
        if (6u) goto L1;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + 2u);
            a0[9u & 3u] = -(((unsigned)(signed char)(r0.y >> (u3 & 31u)) / ((unsigned)h1 | 1u)) & i0);
            if ((a0[i0 & 3u] * a0[i0 & 3u])) {
                if ((unsigned)s0) goto L4;
                e0 = e0 * 0.5L + (long double)((0x7fffffffu * ((unsigned)((int)4u >= (int)(unsigned)d0) * (unsigned)((int)0x998702a2u >= (int)(unsigned)c1))) & 1023u);
                c1 = (signed char)(a0[i0 & 3u] >> ((i1 ? (unsigned)s0 : 0xf6e6be40u) & 31u));
                break; (void)((unsigned)((int)garr[u2 & 7u] >= (int)4u));
                q0 = &garr[(0x5b367cadu >> (5u & 31u)) & 7u];
            } else {
                while (0xeed8d6ecu) { if (--fuel == 0u) goto done;
                    L1: if (--fuel == 0u) goto done;
                    g0 = (u0 % (0u | 1u));
                    break; (void)(((unsigned)f0 >> (v0 & 31u)));
                    if ((unsigned)((int)(unsigned)f0 >= (int)(unsigned)f0)) continue;
                    if ((unsigned)!(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(unsigned char)(g1 << (garr[u2 & 7u] & 31u)))) continue;
                }
            }
            if ((unsigned)l0) continue;
            { unsigned t1; double z1; if ((3u) & 1u) { t1 = p2; z1 = (double)(((g0 | 0u)) & 255u); } if ((3u) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                r0.y ^= (unsigned)((unsigned)((unsigned)l0 < (unsigned)c1) == (unsigned)d0);
                if (u3 == 7u) return (unsigned)(unsigned char)(unsigned)((int)p1 >= (int)(unsigned)(u1 || (unsigned)(r0.y < a0[u1 & 3u])));
                if (0x7fffffffu) break;
            }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(garr[i1 & 7u], 0x7fffffffu, (a0[i0 & 3u] << ((unsigned)(6u && u1) & 31u))); }
        s1 = (int)((unsigned)s1 + ((unsigned)s1 | ((unsigned)(i2 && i1) >> ((9u % (0x71d45df4u | 1u)) & 31u))));
        if (((unsigned)b0 | g1)) goto L2;
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)e0, (0u | (unsigned)l0), (g0 ? 1u : r0.y)); }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)((int)g1 < (int)(unsigned)(short)(unsigned)((int)r0.x < (int)fuel));
            w0 = w0 * 6364136223846793005ull + (unsigned)(short)((0x80000000u | r0.y) >> ((unsigned)(0x10000u && 4u) & 31u));
            e0 = e0 * 0.5L + (long double)((u1 >> ((unsigned)d0 & 31u)) & 1023u);
        }
    }
    if (5u) {
        h1 = (unsigned short)(h1 + ((unsigned)(short)(unsigned)((short)(unsigned)!(unsigned)((short)*q0 > (signed char)8u) > (signed char)m0) >> (5u & 31u)));
        u1 = u1 * 0x9e3779b1u + r0.x;
    }
    g1 += (i2 / (0x80000000u | 1u));
    if ((unsigned)c0) {
        if (budget != 0u) { budget -= 1u; u2 = fn0(u1, (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)!(6u >> (v0 & 31u))), 0xa15aee1u); }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 += (unsigned)((short)*mp > (signed char)(0u & 0xffffffffu));
            if ((unsigned)((short)i1 > (signed char)(unsigned)c0)) break;
            if ((unsigned)x0) {
                L2: if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(unsigned)(0xd236fb35u || (unsigned)(x0 >> 70)) > (signed char)u3), (unsigned)((int)(unsigned)w0 >= (int)(unsigned)(short)(*mp * 0x7fffffffu)), ((unsigned)(g0 < i1) + (unsigned)(w0 >> 29))); }
                }
            }
            *q0 = ((unsigned)((short)(unsigned)(short)(unsigned)(r0.y && (unsigned)(w0 >> 29)) > (signed char)(unsigned)(0u == m0)) - i1);
            while (i1++ < 4u && ((unsigned)(p0 < (unsigned)s0) % (*q0 | 1u))) { if (--fuel == 0u) goto done;
                g0 = u0;
                u3 ^= g1;
                if (((unsigned)(p1 || 0xffffffffu) * 0x10000u)) {
                    *mp = (0xaecfddeau % ((unsigned)(unsigned char)(unsigned)(m0 && ((0xf6a9d1feu * (unsigned)f0) | 0xffffffffu)) | 1u));
                    q0 = &garr[(unsigned)h1 & 7u];
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(0x10000u == 9u), u2, (unsigned)((unsigned)e0 && *mp)); }
                    *q0 += (garr[u2 & 7u] ? (unsigned)x0 : u2);
                } else {
                    c0 = (unsigned char)((unsigned)(x0 >> 70) << (9u & 31u));
                    while (i2++ < 3u && u2) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((unsigned)f0 < u2) & 0x8c38bc44u), ((0xe8569e60u * 0x84bf5afbu) ^ 0x64a74930u), ((unsigned)(w0 >> 29) % (0xffffffffu | 1u))); }
                    }
                    s1 = (int)((unsigned)s1 + (garr[u2 & 7u] / ((unsigned)(v0 || (unsigned)c1) | 1u)));
                    b0 = ~(unsigned)((unsigned)s1 && (6u % (p2 | 1u))) != 0u;
                }
                g1 += (unsigned)(signed char)((unsigned)d0 * v0);
                *mp = ((unsigned)((unsigned)w0 < a0[i0 & 3u]) >> (0xffffffffu & 31u));
                *q0 += 0xffffffffu;
            }
        }
        r0.y ^= ~(0xfe997363u / ((a0[i0 & 3u] / (i0 | 1u)) | 1u));
    }
    d0 = d0 * 0.5 + (double)((i1 ? (a0[u1 & 3u] - *mp) : (unsigned)((int)(unsigned)h0 >= (int)r0.x)) & 1023u);
    h1 = (unsigned short)(h1 + (unsigned)((unsigned)(((unsigned)c1 ^ 2u) || r0.x) && ((unsigned)x0 << (*mp & 31u))));
    if (u3 == 7u) return (unsigned)(short)((unsigned)h1 ^ *mp);
    if (p2) {
        if (budget != 0u) { budget -= 1u; u0 = fn1(~(unsigned)(1u == r0.x), i0, -(0x6c7bb36u - (unsigned)((int)0xf67f4c82u < (int)0x10000u))); }
        do { if (--fuel == 0u) goto done;
            if ((0xbe1e69c7u ^ (4u / (fuel | 1u)))) continue;
            i1 = ((unsigned)b0 ^ g0) & 15u;
            if (3u) continue;
            if (~(i1 | 0x7e172f45u)) continue;
        } while (i0++ < 4u && (u1 >> (((unsigned)(x0 >> 70) * p1) & 31u)));
        do { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)((unsigned)d0 - (unsigned)e0) << (((i0 - -(unsigned)((int)0x80000000u < (int)p1)) ? p2 : 0x80000000u) & 63u);
            if (((unsigned)((short)(unsigned)h1 > (signed char)2u) % ((unsigned)(x0 >> 70) | 1u))) break;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)!((unsigned)((int)(unsigned)w0 < (int)(unsigned)h1) + a0[u1 & 3u]) & 1023u);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)l0 || p2), (unsigned)(garr[i1 & 7u] && -(u2 | (unsigned)d0)), (0x84785059u >> (r0.y & 31u))); }
            }
            switch (*q0 & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)l0 * (unsigned)s0), (unsigned)b0, (0x1bfcf1b2u + (unsigned)h0)); }
                f0 = f0 * 0.5f + (float)((unsigned)(0xffffffffu == garr[u2 & 7u]) & 255u);
                q0 = &garr[(((unsigned)(w0 >> 29) & v0) << (g1 & 31u)) & 7u];
                d0 = d0 * 0.5 + (double)(((unsigned)(((unsigned)c1 + (unsigned)s1) && p2) << ((unsigned)s1 & 31u)) & 1023u);
                L3: if (--fuel == 0u) goto done;
                h0 = (short)(unsigned)((int)(u1 | (unsigned)(x0 >> 70)) >= (int)((unsigned)(x0 >> 70) % ((unsigned)(unsigned char)(unsigned)((unsigned)s0 == (unsigned)l0) | 1u)));
            }
        } while (i0++ < 3u && a0[u1 & 3u]);
        m0 ^= ((unsigned)!(u1 | 0xc6d38273u) >> ((unsigned)s1 & 31u));
        do { if (--fuel == 0u) goto done;
            r0.y ^= (*q0 & ((p1 - ~(unsigned)((int)0x745102f4u >= (int)u0)) | 0x31abaaa0u));
            while (i1++ < 4u && (unsigned)((short)(unsigned)(p1 < r0.x) > (signed char)7u)) { if (--fuel == 0u) goto done;
                s0 = (int)((0x1215b2acu + 0x87e94f16u) % ((unsigned)(0x80000000u || ((unsigned)(w0 >> 29) ^ 0u)) | 1u));
            }
            if ((i0 | a0[i0 & 3u])) break;
            if (0x84251d93u) {
                m0 ^= a0[i0 & 3u];
                v0 = (unsigned)h1;
            }
        } while (i0++ < 2u && (unsigned)((int)(unsigned)d0 >= (int)((unsigned)h1 ^ p1)));
    } else {
        if (budget != 0u) { budget -= 1u; u3 = fn1(i2, (0x176c1e8fu - 0xffffffffu), 3u); }
        { unsigned t2; double z2; if (((unsigned)l0) & 1u) { t2 = (8u ^ (unsigned)((unsigned)x0 == (unsigned)s0)); z2 = (double)(((unsigned)(signed char)((8u / (0x80000000u | 1u)) ^ g1)) & 255u); } if (((unsigned)l0) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            if ((a0[i0 & 3u] / (0x80000000u | 1u))) goto L0;
            d0 = d0 * 0.5 + (double)((garr[i1 & 7u] / ((a0[u1 & 3u] ^ 0x10000u) | 1u)) & 1023u);
            if ((unsigned)((unsigned)b0 < (unsigned)s1)) goto L2;
        }
    }
    { unsigned t3; double z3; if (((unsigned)((int)(unsigned)(signed char)((unsigned)e0 - 0xbce60fbdu) >= (int)m0)) & 1u) { t3 = ((unsigned)x0 / (i1 | 1u)); z3 = (double)((u2) & 255u); } if (((unsigned)((int)(unsigned)(signed char)((unsigned)e0 - 0xbce60fbdu) >= (int)m0)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        if ((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)s0)) goto L2;
        if (budget != 0u) { budget -= 1u; u3 = fn0((0x80000000u ? r0.x : a0[u1 & 3u]), *mp, u0); }
        garr[-(unsigned)(p2 < 0xfa67a60u) & 7u] = ((unsigned)l0 / ((0x49e6f77u ? 0xffffffffu : (unsigned)e0) | 1u));
    }
    if ((unsigned)(unsigned char)(unsigned)(p1 == (a0[i0 & 3u] ^ (unsigned)w0))) goto L4;
    if ((unsigned)((short)((unsigned)f0 * garr[i1 & 7u]) > (signed char)0x9128e7d8u)) {
        if (g0) goto L2;
        L4: if (--fuel == 0u) goto done;
        c1 = (signed char)-(unsigned)((unsigned)((unsigned)c1 && (0x17852ce0u << ((unsigned)s1 & 31u))) == u0);
        i2 = 0x62264e7u & 15u;
    }
    *q0 += (((unsigned)(x0 >> 70) ? (unsigned)s0 : 0x93df4606u) | (unsigned)((int)m0 >= (int)4u));
    goto L3;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (~((unsigned)(i0 || *mp) / (5u | 1u)) & 7u) {
            case 4u: ;
            case 3u: ;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)r0.x;
                g1 += ((unsigned)(p2 && (unsigned)(0xffffffffu == p2)) | (unsigned)((int)i0 >= (int)i1));
                if ((unsigned)((unsigned)b0 && a0[i0 & 3u])) goto L1;
                do { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (unsigned)(x0 >> 70));
                    break; (void)(0x1bbba17cu);
                    e0 = e0 * 0.5L + (long double)((i0 << ((unsigned)f0 & 31u)) & 1023u);
                    h0 = (short)(r0.x + (garr[i1 & 7u] + m0));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)(unsigned)((short)0xffffffffu > (signed char)((unsigned)c1 / (0xffffffffu | 1u))), (unsigned)(0x3a832966u < (a0[i0 & 3u] + i0)), (unsigned)(r0.x == 0xa1d5eb8cu)); }
                } while (i2++ < 3u && v0);
                c1 = (signed char)(a0[u1 & 3u] >> ((0x7fffffffu ^ ((unsigned)c0 / ((unsigned)l0 | 1u))) & 31u));
                default: ;
            }
            while (i1++ < 3u && (p2 << (*mp & 31u))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)((unsigned)s0 ^ p2)), (unsigned)(fuel && 0x80000000u), ((unsigned)h1 & (unsigned)h1)); }
                if (*q0) goto L0;
            }
        }
        if ((unsigned)((g0 << (u1 & 31u)) < u2)) break;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)(unsigned)((short)u0 > (signed char)p2) >= (int)a0[u1 & 3u]), (unsigned)((int)a0[u1 & 3u] < (int)(m0 / ((unsigned)s1 | 1u))), (u2 ^ 0x10000u)); }
        }
        if ((0x80000000u | (unsigned)(w0 >> 29))) break;
        { unsigned t4; double z4; if ((0x7fffffffu) & 1u) { t4 = (0x1633140du * (unsigned)w0); z4 = (double)(((((unsigned)l0 - 0xe0927b04u) & v0)) & 255u); } if ((0x7fffffffu) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (0x7fffffffu) goto L0;
                if (u3 == 7u) return (unsigned)!(unsigned)(0x80000000u < (unsigned)s1);
            }
            if (((unsigned)((short)(unsigned)w0 > (signed char)*q0) + r0.x)) continue;
            s0 = (int)(((garr[u2 & 7u] * garr[i1 & 7u]) * v0) << (u2 & 31u));
            break; (void)(0xa32fd94fu);
            u2 += (0u << ((unsigned)((int)2u < (int)(unsigned)s1) & 31u));
            u0 ^= (unsigned)((short)((unsigned)f0 | (unsigned)(u3 == 3u)) > (signed char)v0);
        }
        s0 = (int)~(unsigned)(((0x2e8db255u + *mp) - (unsigned)l0) && a0[i0 & 3u]);
    }
    if (((unsigned)b0 % (*q0 | 1u))) goto L0;
    g1 += (unsigned)(garr[i1 & 7u] == (unsigned)(0x179b8eccu || (unsigned)d0));
    if (fuel) goto L1;
    if (4u) goto L2;
    if (i2) {
        h1 = (unsigned short)(h1 + (unsigned)((short)(0xffffffffu / (i1 | 1u)) > (signed char)(unsigned)((short)garr[i1 & 7u] > (signed char)(0xc4a3043du | garr[i1 & 7u]))));
    } else {
        if ((8u & 0x7d3e0839u)) {
            h0 = (short)(unsigned)(short)(a0[u1 & 3u] % ((p0 / (0x7fffffffu | 1u)) | 1u));
            g0 = (unsigned)((short)5u > (signed char)m0);
            if ((unsigned)e0) {
                if ((0xca543b02u << ((unsigned)(unsigned char)(p0 << (i0 & 31u)) & 31u))) goto L1;
                r0.y ^= -((unsigned)b0 + (unsigned)((m0 % ((unsigned)c1 | 1u)) && p2));
                s1 = (int)((unsigned)s1 + ((i0 * (unsigned)((int)(unsigned)s1 >= (int)0x7fffffffu)) / ((p2 & (unsigned)e0) | 1u)));
                m0 ^= ((unsigned)((int)p2 < (int)7u) << ((unsigned)(x0 >> 70) & 31u));
                if ((unsigned)s0) goto L3;
            } else {
                q0 = &garr[(a0[u1 & 3u] >> (u0 & 31u)) & 7u];
                m0 ^= ((2u ^ (unsigned)e0) - ((unsigned)h0 + (unsigned)l0));
                s0 = (int)((unsigned)(u3 == fuel) - (p2 * (i1 * v0)));
                goto L0;
            }
            c0 = (unsigned char)u0;
            if (budget != 0u) { budget -= 1u; u0 = fn1((p2 >> ((unsigned)(4u == 7u) & 31u)), (unsigned)!(unsigned)(0x7fffffffu || (unsigned)(0xffffffffu && 0x7fffffffu)), ((unsigned)(9u && 0x2b8fafb1u) << ((unsigned)d0 & 31u))); }
        } else {
            switch ((m0 / ((unsigned)((unsigned)x0 || (unsigned)l0) | 1u)) & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn1(((a0[u1 & 3u] - m0) / (0x7fa0eef9u | 1u)), (unsigned)((unsigned)((short)2u > (signed char)garr[i1 & 7u]) && 0xffffffffu), 6u); }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)garr[u2 & 7u] >= (int)(fuel << (u3 & 31u))), (unsigned)s0, (unsigned)(p0 == (unsigned)(x0 >> 70))); }
                if ((r0.y ^ (unsigned)((int)0x7fffffffu < (int)(unsigned)h1))) {
                    case 4u: ;
                    goto L0;
                    case 1u: ;
                    v0 = 2u;
                    default: ;
                    c1 = (signed char)(unsigned)(0x7fffffffu < m0);
                } else {
                    u2 ^= (unsigned)((unsigned)(x0 >> 70) == a0[i0 & 3u]);
                    garr[(5u - i1) & 7u] = (6u % (0x4ce488a8u | 1u));
                }
                *q0 += ((p0 % (v0 | 1u)) & 2u);
                w0 ^= (unsigned long long)(unsigned)d0 << ((unsigned)b0 & 63u);
            }
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                g1 += ((unsigned)((int)g1 >= (int)6u) / ((p2 * fuel) | 1u));
            }
            goto L1;
        }
    }
    do { if (--fuel == 0u) goto done;
        garr[(unsigned)e0 & 7u] = (garr[i1 & 7u] + 0x97a90516u);
        { unsigned t5; double z5; if ((u0) & 1u) { t5 = a0[i0 & 3u]; z5 = (double)((((unsigned)((int)0x10000u < (int)u3) & r0.y)) & 255u); } if ((u0) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            switch ((unsigned)((unsigned)e0 && fuel) & 7u) {
                case 1u: ;
                c1 = (signed char)(p2 + *mp);
                if ((unsigned)(w0 >> 29)) break;
                u3 += *q0;
                case 5u: ;
                { unsigned t6; double z6; if ((*q0) & 1u) { t6 = (u1 & 0x4f9dc608u); z6 = (double)(((i0 - (unsigned)((short)(unsigned)b0 > (signed char)p0))) & 255u); } if ((*q0) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                    if (((0x3f5c402cu % ((unsigned)d0 | 1u)) - 0x85d63c52u)) break;
                    if ((unsigned)(u3 || (*mp ^ 0x19a7bc96u))) break;
                    case 6u: ;
                    if (i2) goto L0;
                    v0 = u2;
                    c0 = (unsigned char)(((unsigned)((int)((unsigned)s0 / (p2 | 1u)) < (int)0x7fffffffu) >> (0xffffffffu & 31u)) * 9u);
                }
            }
        }
        u0 += (unsigned)(short)((unsigned)x0 >> ((unsigned)d0 & 31u));
        { unsigned t7; double z7; if (((i1 - (unsigned)((unsigned)e0 == p1))) & 1u) { t7 = 0x10000u; z7 = (double)(((unsigned)(a0[i0 & 3u] == (unsigned)s1)) & 255u); } if (((i1 - (unsigned)((unsigned)e0 == p1))) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(*q0 == 8u), (unsigned)((int)(unsigned)w0 < (int)(unsigned)!(unsigned)(*mp || g0)), (0xffffffffu ^ 0xffffffffu)); }
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(r0.y || (unsigned)h1), ((unsigned)s0 % ((unsigned)c1 | 1u)), (i0 >> ((unsigned)x0 & 31u))); }
        }
    } while (i0++ < 7u && (unsigned)((unsigned)((unsigned)x0 == 0x693be2adu) == 7u));
    goto L3;
    q0 = &garr[(unsigned)(a0[u1 & 3u] < 0xffffffffu) & 7u];
    do { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)((unsigned)h0 * a0[i0 & 3u]) << ((unsigned)((short)(2u + p2) > (signed char)(0x10000u + (unsigned)(3u && garr[i1 & 7u]))) & 63u);
    } while (i0++ < 3u && p0);
    if ((p0 & a0[u1 & 3u])) goto L2;
    if ((unsigned)!(unsigned)((short)(unsigned)(0x4800d4f6u && 5u) > (signed char)u2)) {
        i0 = (unsigned)((unsigned)((0x10000u & i2) < v0) || ~(p2 / ((unsigned)c0 | 1u))) & 15u;
        e0 = e0 * 0.5L + (long double)((unsigned)(0x7b907ed3u == garr[u2 & 7u]) & 1023u);
        { unsigned t8; double z8; if (((unsigned)(*q0 == 7u)) & 1u) { t8 = (9u % ((unsigned)h1 | 1u)); z8 = (double)((0x10000u) & 255u); } if (((unsigned)(*q0 == 7u)) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
            if ((unsigned)(unsigned char)(unsigned)((int)*mp >= (int)2u)) goto L1;
        }
    } else {
        if (p0) goto L4;
        switch (-(2u | (unsigned)((int)p1 >= (int)m0)) & 7u) {
            m0 ^= ~(unsigned)((unsigned)w0 && ~(unsigned)((int)(unsigned)s1 >= (int)(unsigned)l0));
            if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((unsigned)w0 < v0) | 0x80000000u), (unsigned)((unsigned)(i0 || (unsigned)e0) == i2), i1); }
            { unsigned t9; double z9; if (((g0 & (unsigned)((unsigned)c0 == (unsigned)l0))) & 1u) { t9 = (r0.y >> (0x7fffffffu & 31u)); z9 = (double)(((u2 | (unsigned)(0x80000000u == 9u))) & 255u); } if (((g0 & (unsigned)((unsigned)c0 == (unsigned)l0))) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                case 6u: ;
                *mp = ((unsigned)((short)8u > (signed char)(0x4a738102u % (u1 | 1u))) * (u0 % ((unsigned)e0 | 1u)));
                garr[i2 & 7u] = (0xffffffffu ? garr[u2 & 7u] : p2);
            }
            m0 ^= ((0x23686fe5u + (unsigned)h0) | -(unsigned)((int)0xa8856129u >= (int)(unsigned)(x0 >> 70)));
        }
        q0 = &garr[(unsigned)((int)(unsigned)(p0 || v0) >= (int)((unsigned)h1 ^ (unsigned)h0)) & 7u];
    }
    h0 = (short)((m0 % ((unsigned)(*q0 || (unsigned)l0) | 1u)) - (0x80000000u & 0x4d0ead02u));
    { unsigned t10; double z10; if ((0x80000000u) & 1u) { t10 = (i1 - a0[i0 & 3u]); z10 = (double)(((unsigned)f0) & 255u); } if ((0x80000000u) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
        g1 += (unsigned)((unsigned)h0 || m0);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while (i0++ < 4u && (unsigned)(p2 < 0x7fffffffu)) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            b0 = (p0 & ((unsigned)h0 ? (unsigned)((int)p0 >= (int)fuel) : (unsigned)c1)) != 0u;
            while (i2++ < 2u && (unsigned)l0) { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
            }
            while (i2++ < 6u && (unsigned)!(garr[i1 & 7u] | r0.x)) { if (--fuel == 0u) goto done;
                { unsigned t0; double z0; if (((g0 % ((unsigned)!(unsigned)((int)g1 < (int)0x4d8937aau) | 1u))) & 1u) { t0 = (7u << (m0 & 31u)); z0 = (double)(((unsigned)((int)u0 >= (int)((unsigned)x0 ^ 0u))) & 255u); } if (((g0 % ((unsigned)!(unsigned)((int)g1 < (int)0x4d8937aau) | 1u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    r0.x = (unsigned)(((unsigned)d0 ? 0x80000000u : 0xeea5ae0au) || p0);
                    *mp = (i0 ? (unsigned)c0 : ((0xcdbaeb60u >> ((unsigned)(w0 >> 29) & 31u)) >> (8u & 31u)));
                    s1 = (int)((unsigned)s1 + r0.y);
                    q0 = &garr[(unsigned)b0 & 7u];
                    if (fuel < 8u) return (u2 / ((unsigned)(p2 && ((unsigned)s0 >> ((unsigned)(unsigned char)((unsigned)b0 ^ g1) & 31u))) | 1u));
                }
                do { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(unsigned)c1 << (((unsigned)(x0 >> 70) ? v0 : (unsigned)(u1 == 0x80000000u)) & 63u);
                    if (budget != 0u) { budget -= 1u; u2 = fn2((((unsigned)c0 | g1) / (0x7d9cf39du | 1u)), i2, ((unsigned)x0 - (unsigned)!((unsigned)f0 - p1))); }
                } while (i0++ < 2u && (unsigned)(garr[u2 & 7u] || g0));
                L1: if (--fuel == 0u) goto done;
                L2: if (--fuel == 0u) goto done;
            }
            if (((unsigned)h0 << (0x4047da4au & 31u))) {
                l0 = (long)((unsigned long)l0 + 0x79e0a665u);
                if (0x10000u) break;
                u1 += (unsigned)((unsigned)s1 < (u2 | garr[i1 & 7u]));
                { unsigned t1; double z1; if ((((r0.x >> (0x33934f0fu & 31u)) ^ (unsigned)(w0 >> 29))) & 1u) { t1 = (r0.x % (0xffffffffu | 1u)); z1 = (double)(((unsigned)((unsigned)e0 && (unsigned)h0)) & 255u); } if ((((r0.x >> (0x33934f0fu & 31u)) ^ (unsigned)(w0 >> 29))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    i2 = ((unsigned)!(unsigned)((int)g1 < (int)(unsigned)c0) >> ((unsigned)d0 & 31u)) & 15u;
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                            if ((-((unsigned)l0 ^ p0) - p2)) break;
                            L3: if (--fuel == 0u) goto done;
                            m0 ^= (unsigned)h1;
                            break; (void)(i1);
                        }
                        if (3u) break;
                    }
                }
                if ((unsigned)x0) continue;
            }
        } while (i1++ < 5u && (unsigned)(short)(unsigned)((int)((unsigned)s1 | *q0) >= (int)(unsigned)b0));
    }
    if ((0x80000000u + v0)) {
        if (budget != 0u) { budget -= 1u; u3 = fn0((fuel & m0), *q0, (p1 - u2)); }
        b0 = 0xb0f591a5u != 0u;
        r0.x = (unsigned)((short)u2 > (signed char)(((unsigned)s0 | 0xffffffffu) + u0));
        if ((unsigned)(short)((a0[i0 & 3u] << ((unsigned)c0 & 31u)) % (0x10000u | 1u))) {
            *q0 += u3;
            L4: if (--fuel == 0u) goto done;
            v0 = (unsigned)(r0.y || ((unsigned)(i0 && 9u) * (unsigned)(w0 >> 29)));
        } else {
            { unsigned t2; double z2; if (((unsigned)(w0 >> 29)) & 1u) { t2 = (3u | (unsigned)b0); z2 = (double)((0x80000000u) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                f0 = f0 * 0.5f + (float)(-(g1 | ((unsigned)c1 * (unsigned)(u0 || (unsigned)(w0 >> 29)))) & 255u);
                if (a0[i0 & 3u]) goto L1;
                *q0 += p1;
                if ((unsigned)!(unsigned)(0x3abce7c3u == 0x10000u)) goto L2;
            }
        }
        if (0xffffffffu) goto L4;
    } else {
        if (9u) goto done;
    }
    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)h0 < (u1 - p2)));
    if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)((short)a0[u1 & 3u] > (signed char)a0[u1 & 3u]) < (int)p1)) goto L1;
    if (a0[i0 & 3u]) goto L0;
    goto L2;
    if (budget != 0u) { budget -= 1u; u0 = fn2((((unsigned)c1 - 0xd7e0f985u) | u0), (unsigned)!((unsigned)h0 + i2), (unsigned)((short)i2 > (signed char)(unsigned)(w0 >> 29))); }
    goto done;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)(0x80000000u || (unsigned)s1) < (int)(unsigned)s1), ((unsigned)b0 - 0xffffffffu), ((unsigned)d0 - (*mp & (unsigned)(w0 >> 29)))); }
    if ((unsigned)((short)g0 > (signed char)(unsigned)(x0 >> 70))) goto L1;
    if (g0) goto L4;
    r0.x = ((0xa648ae1cu | 0xe0e83c32u) >> ((u2 / ((1u % (p2 | 1u)) | 1u)) & 31u));
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(g0 || (unsigned)e0), (*q0 & (unsigned)s0), (unsigned)b0); }
    if ((unsigned)(signed char)(unsigned)((int)4u >= (int)(v0 | (unsigned)h1))) goto done;
    l0 = (long)((unsigned long)l0 + ((unsigned)h0 - (unsigned)c1));
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            garr[(unsigned)e0 & 7u] = (0xe2e6a52fu << (-((unsigned)x0 ^ i1) & 31u));
            l0 = (long)((unsigned long)l0 + ((unsigned)b0 >> ((0x24745d8fu * g0) & 31u)));
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s1, i0, (unsigned)((short)*mp > (signed char)(unsigned)((int)(unsigned)w0 < (int)i2))); }
            c0 = (unsigned char)((unsigned)((g0 >> (u0 & 31u)) || a0[i0 & 3u]) + 0x87a88f9cu);
            s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(short)(i1 / ((unsigned)(*mp < 0xcb752583u) | 1u)) == 0x7fffffffu));
        } while (i1++ < 2u && *mp);
        if (fuel < 8u) return (unsigned)((*q0 | (0x8a3f71b0u + 0xe03ac040u)) && (unsigned)((unsigned)h1 && 4u));
        switch ((0xe4ef0768u << ((unsigned)((short)(unsigned)b0 > (signed char)u3) & 31u)) & 7u) {
            w0 ^= (unsigned long long)g0 << ((unsigned)((0x7fffffffu % (u0 | 1u)) && 5u) & 63u);
            while (i1++ < 6u && p0) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((0xffffffffu - u0), (unsigned)((int)0x10000u >= (int)a0[u1 & 3u]), 0x2588272cu); }
            }
            b0 = (unsigned)e0 != 0u;
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)b0 << ((unsigned)(5u < ((unsigned)c0 ^ 6u)) & 63u);
                if (budget != 0u) { budget -= 1u; u2 = fn0(*q0, (unsigned)((unsigned)d0 && ((unsigned)e0 >> ((unsigned)w0 & 31u))), (unsigned)(short)((unsigned)(0x7fffffffu == (unsigned)f0) | r0.y)); }
                { unsigned t3; double z3; if (((u1 - 0x10c1cd7cu)) & 1u) { t3 = (unsigned)(unsigned char)(unsigned)((short)4u > (signed char)0x7a5d0e51u); z3 = (double)(((unsigned)((int)(unsigned)b0 < (int)(unsigned)((unsigned)w0 < (unsigned)l0))) & 255u); } if (((u1 - 0x10c1cd7cu)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                    c0 = (unsigned char)((r0.x | (unsigned)b0) / ((unsigned)((short)(unsigned)((unsigned)h0 == 0xffffffffu) > (signed char)(unsigned)s1) | 1u));
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            *mp = (unsigned)((int)(unsigned)(short)(r0.x * (unsigned)(signed char)(unsigned)((short)7u > (signed char)9u)) < (int)(unsigned)c0);
                            c0 = (unsigned char)(i2 * (p2 | (unsigned)((v0 & (unsigned)s0) || (unsigned)s0)));
                            case 6u: ;
                            u3 += (unsigned)(signed char)((unsigned)(g1 && fuel) % ((unsigned)(p0 < (unsigned)((int)0x2c943070u >= (int)(unsigned)x0)) | 1u));
                            r0.y ^= (g1 / (((unsigned)c1 % ((m0 + 0x26c1d4e7u) | 1u)) | 1u));
                        } while (i0++ < 7u && (unsigned)!(garr[u2 & 7u] >> (0x7fffffffu & 31u)));
                        c0 = (unsigned char)r0.y;
                        c0 = (unsigned char)(unsigned)(g0 == 6u);
                        case 3u: ;
                    }
                    q0 = &garr[((unsigned)l0 << ((0x7521b629u / ((unsigned)(0xffffffffu == ((unsigned)f0 + 3u)) | 1u)) & 31u)) & 7u];
                    case 2u: ;
                    if (((unsigned)s0 | u1)) goto L0;
                }
                w0 = w0 * 6364136223846793005ull + 0x80000000u;
            } while (i1++ < 3u && i0);
            default: ;
        }
    } while (i0++ < 4u && (unsigned)(0x7fffffffu == (unsigned)h1));
    if (budget != 0u) { budget -= 1u; u2 = fn1(r0.y, ((v0 & a0[u1 & 3u]) - 0x319e584eu), garr[u2 & 7u]); }
    if (garr[i1 & 7u]) goto L0;
    if ((unsigned)l0) goto L0;
    if (-(unsigned)((int)(unsigned)f0 >= (int)((unsigned)c0 / (g1 | 1u)))) {
        x0 = x0 * 0x100000001b3ull + (((unsigned)(i2 && 9u) >> ((unsigned)(w0 >> 29) & 31u)) * 8u);
        r0.y ^= p2;
        goto done;
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((unsigned)s0 || ((unsigned)c0 | 6u)));
            b0 = 0x80000000u != 0u;
            s0 = (int)(7u >> ((unsigned)(x0 >> 70) & 31u));
            if (((unsigned)(x0 >> 70) % ((*q0 | 0xffffffffu) | 1u))) break;
            continue; (void)(0xe9b2376au);
        }
    }
    if (0xd1c0c120u) {
        if ((unsigned)(unsigned char)(0x80000000u ? 0xed7baca6u : (unsigned)l0)) goto L4;
        if ((unsigned)((unsigned)b0 < 3u)) {
            *q0 = (unsigned)((int)(unsigned)((int)((unsigned)(w0 >> 29) & 0x80000000u) >= (int)i1) >= (int)u0);
        }
        *q0 += ((0x80000000u ? u2 : g0) * u1);
        if (budget != 0u) { budget -= 1u; u3 = fn2((0x10000u | (unsigned)((unsigned)w0 || garr[i1 & 7u])), fuel, 7u); }
    } else {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            a0[u1 & 3u] = ((unsigned)((unsigned)c0 && i1) - 5u);
            v0 = (unsigned)((garr[i1 & 7u] % (p0 | 1u)) || (unsigned)w0);
        }
        goto L0;
        w0 ^= (unsigned long long)(3u << (g0 & 31u)) << ((unsigned)((unsigned)d0 || (0xffffffffu ^ (unsigned)(unsigned char)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)garr[i1 & 7u]) * u0))) & 63u);
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1((r0.y << ((unsigned)((int)g1 < (int)0x9e5480afu) & 31u)), (unsigned)(0xf63156eu < (unsigned)x0), (unsigned)(signed char)((unsigned)((short)v0 > (signed char)1u) & 0xf5147fbu)); }
    if ((7u % (0xffffffffu | 1u))) {
        if (budget != 0u) { budget -= 1u; u0 = fn0(0xe68dc383u, (-(0x451b0c42u >> ((unsigned)d0 & 31u)) + (unsigned)(w0 >> 29)), (unsigned)((int)i2 >= (int)6u)); }
        { unsigned t4; double z4; if ((((unsigned)((unsigned)h0 || 0xbeb8c629u) | fuel)) & 1u) { t4 = (0xa10c4dceu & (unsigned)d0); z4 = (double)((i0) & 255u); } if ((((unsigned)((unsigned)h0 || 0xbeb8c629u) | fuel)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
            w0 ^= (unsigned long long)(unsigned)(unsigned char)(i1 | 2u) << (fuel & 63u);
        }
        x0 = x0 * 0x100000001b3ull + i0;
        c0 = (unsigned char)((unsigned)((int)0xffffffffu < (int)(u2 ^ g0)) - (5u & a0[u1 & 3u]));
    } else {
        if (a0[i0 & 3u]) {
            q0 = &garr[(unsigned)((int)(unsigned)e0 >= (int)(9u << (u2 & 31u))) & 7u];
        } else {
            q0 = &garr[((unsigned)l0 << (0xffffffffu & 31u)) & 7u];
            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)h0 && (unsigned)((int)r0.x < (int)fuel)) & 1023u);
            b0 = (unsigned)((int)0x7fffffffu >= (int)(unsigned)(garr[i1 & 7u] || 0x10000u)) != 0u;
        }
        if (0xe8a36173u) goto done;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(u2 && 0x7fffffffu), (unsigned)d0, 3u); }
    if ((g0 & garr[u2 & 7u])) goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    garr[(unsigned)((short)0x7fffffffu > (signed char)6u) & 7u] = (u3 & (unsigned)b0);
    if ((unsigned)(0xffffffffu < (0u >> (garr[u2 & 7u] & 31u)))) {
        v0 = (fuel % ((unsigned)((short)(unsigned)((unsigned)((unsigned)s1 == u1) < (unsigned)h1) > (signed char)(unsigned)(w0 >> 29)) | 1u));
        d0 = d0 * 0.5 + (double)((u1 ? 0x10000u : (unsigned)w0) & 1023u);
        if (~(unsigned)(garr[i1 & 7u] == m0)) goto L3;
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)x0, ((unsigned)h0 - p1), (0x7fffffffu ^ (a0[i0 & 3u] / (g0 | 1u)))); }
        if (i0) {
            L0: if (--fuel == 0u) goto done;
            switch (((unsigned)b0 & (unsigned)((short)g1 > (signed char)0xb6a4926cu)) & 7u) {
                case 6u: ;
            }
            i0 = (unsigned)(short)(i1 / (((g1 & (unsigned)h0) & 0u) | 1u)) & 15u;
            if (u3 == 7u) return 0xf5aac211u;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)!(a0[u1 & 3u] + *q0), (unsigned)(signed char)(0xfac3e1a7u << ((unsigned)(w0 >> 29) & 31u)), (unsigned)f0); }
            goto done;
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)d0, 0xcf1ed3e1u, (0x88a36fb2u - 0xe51142fdu)); }
    b0 = a0[i0 & 3u] != 0u;
    u0 = (unsigned)((short)(unsigned)(unsigned char)(unsigned)((int)(unsigned)((unsigned)(w0 >> 29) || 0x10000u) >= (int)(unsigned)w0) > (signed char)(i1 ^ g1));
    switch ((unsigned)(0xffffffffu == u2) & 7u) {
        case 3u: ;
        while (i0++ < 6u && (8u % ((unsigned)(unsigned char)((unsigned)c0 ^ a0[u1 & 3u]) | 1u))) { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)(unsigned char)(unsigned)((u1 | u0) || (unsigned)((u2 % (r0.y | 1u)) < 0x80c3498cu));
            d0 = d0 * 0.5 + (double)(((unsigned)(unsigned char)((unsigned)x0 * 0x10000u) / ((unsigned)((int)0x57903b6cu < (int)u2) | 1u)) & 1023u);
            i1 = (((unsigned)((unsigned)((short)i1 > (signed char)5u) || (unsigned)d0) << (8u & 31u)) + 0xb2eedae0u) & 15u;
            *q0 += (unsigned)(~(unsigned)(*mp == (unsigned)s1) || (unsigned)s1);
            L1: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)(0x1f664733u == garr[i1 & 7u]), ((1u % (2u | 1u)) << (*mp & 31u)), ((unsigned)(u2 < (unsigned)l0) * i0)); }
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if (((unsigned)((unsigned)l0 < (unsigned)(9u && (unsigned)e0))) & 1u) { t0 = (unsigned)(0x10000u || u0); z0 = (double)(((unsigned)(garr[u2 & 7u] < *mp)) & 255u); } if (((unsigned)((unsigned)l0 < (unsigned)(9u && (unsigned)e0))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                f0 = f0 * 0.5f + (float)(((0x2d446383u >> (0u & 31u)) * (garr[i1 & 7u] | (unsigned)(0x10000u && a0[u1 & 3u]))) & 255u);
            }
            u2 ^= ((unsigned)w0 / ((u3 | (unsigned)l0) | 1u));
            c0 = (unsigned char)(unsigned)(u2 || 0xffffffffu);
            do { if (--fuel == 0u) goto done;
                b0 = -(unsigned)((unsigned)((short)g1 > (signed char)0x88e280dau) < (unsigned)(short)(unsigned)((int)g0 >= (int)(unsigned)l0)) != 0u;
                w0 ^= (unsigned long long)m0 << (((unsigned)(i2 && (unsigned)w0) | (0x83f7c20bu ^ (unsigned)s0)) & 63u);
                case 4u: ;
                c0 = (unsigned char)((unsigned)w0 ? ((0u >> ((unsigned)s0 & 31u)) + 0x10000u) : p2);
                switch ((p0 - (unsigned)((short)(unsigned)l0 > (signed char)u2)) & 7u) {
                    if (fuel < 8u) return ((i2 * 0xfff2285bu) >> ((unsigned)((unsigned)((int)g1 < (int)0xffffffffu) < 9u) & 31u));
                    if (((unsigned)(w0 >> 29) % ((unsigned)b0 | 1u))) {
                        garr[p1 & 7u] = (unsigned)!(u2 | g1);
                        c1 = (signed char)(unsigned)(garr[i1 & 7u] == (unsigned)(x0 >> 70));
                        for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                            *mp = (unsigned)(((unsigned)l0 >> (r0.y & 31u)) && u3);
                        }
                        u1 ^= (((unsigned)((int)i1 >= (int)garr[u2 & 7u]) * (unsigned)s0) / (v0 | 1u));
                        goto L2;
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn3(g0, (unsigned)((unsigned)((int)0xffffffffu < (int)p2) == garr[u2 & 7u]), ((unsigned)((short)u2 > (signed char)a0[u1 & 3u]) << ((unsigned)l0 & 31u))); }
                    L2: if (--fuel == 0u) goto done;
                    i0 = (unsigned)(((p0 * *mp) ^ g1) && (unsigned)(signed char)(unsigned)((int)a0[i0 & 3u] < (int)(unsigned)l0)) & 15u;
                }
            } while (i1++ < 5u && (i0 + p0));
            if (budget != 0u) { budget -= 1u; u0 = fn1(0x43833a9bu, ((m0 & (unsigned)c1) << ((unsigned)b0 & 31u)), (0x80000000u & (unsigned)(w0 >> 29))); }
        }
    }
    *q0 = (unsigned)(((unsigned)h0 - (0x10000u >> ((unsigned)(x0 >> 70) & 31u))) < 0xffffffffu);
    u1 ^= ((unsigned)((short)~(unsigned)((short)(unsigned)l0 > (signed char)0x7fffffffu) > (signed char)garr[i1 & 7u]) + (p0 & 0x67a77b18u));
    h0 = (short)(unsigned)(unsigned char)(0x58fa6354u * (unsigned)(short)(((unsigned)((int)(unsigned)l0 >= (int)(unsigned)e0) - (unsigned)s1) / (v0 | 1u)));
    m0 ^= u0;
    goto L0;
    L3: if (--fuel == 0u) goto done;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((r0.x | (unsigned)e0) & 7u) {
            u3 ^= (unsigned)((short)(unsigned)((int)(unsigned)d0 >= (int)3u) > (signed char)(((unsigned)f0 | (unsigned)c0) & 0x10000u));
        }
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)(unsigned)((int)0x80000000u < (int)(unsigned)l0) > (signed char)0x10000u)) break;
    }
    L4: if (--fuel == 0u) goto done;
    b0 = (unsigned)(u3 || i0) != 0u;
    if (0x3201cbf9u) goto L1;
    h0 = (short)(unsigned)(v0 && 0u);
    if (((i1 ^ (unsigned)b0) << ((unsigned)e0 & 31u))) goto L1;
    while (a0[u1 & 3u]) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if (((0xab03987u - v0)) & 1u) { t1 = (0x7fffffffu / ((unsigned)x0 | 1u)); z1 = (double)((6u) & 255u); } if (((0xab03987u - v0)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                garr[a0[i0 & 3u] & 7u] = (((unsigned)((unsigned)c0 || 7u) / ((unsigned)(short)(unsigned)(i2 == a0[i0 & 3u]) | 1u)) - 0x10000u);
                b0 = (i2 | (r0.x ? u2 : (unsigned)((short)i1 > (signed char)0x6502d0adu))) != 0u;
                u2 = (unsigned)(short)(unsigned)((short)(unsigned)c0 > (signed char)(unsigned)((int)(unsigned)((unsigned)b0 || (unsigned)(signed char)(garr[u2 & 7u] >> (garr[i1 & 7u] & 31u))) < (int)(unsigned)h1));
                if (budget != 0u) { budget -= 1u; u1 = fn2((i2 & (unsigned)b0), r0.y, *q0); }
                if ((0x36185e7u * i2)) break;
                r0.x = ((unsigned)(short)(unsigned)((short)0x8417cca5u > (signed char)(unsigned)(garr[i1 & 7u] && garr[u2 & 7u])) & u1);
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(((r0.y * (unsigned)x0) ^ i0), (0x7fffffffu + a0[i0 & 3u]), (unsigned)b0); }
            goto L1;
            r0.y ^= (0x10000u >> ((unsigned)((int)0x7fffffffu >= (int)u1) & 31u));
            do { if (--fuel == 0u) goto done;
                c0 = (unsigned char)((7u ^ (unsigned)e0) ^ (0xe1fcce95u >> ((unsigned)(x0 >> 70) & 31u)));
                s0 = (int)(i0 / (((unsigned)c0 ? (unsigned)d0 : p1) | 1u));
                r0.x = (unsigned)(unsigned char)(((2u << ((unsigned)e0 & 31u)) >> ((a0[i0 & 3u] & m0) & 31u)) ^ a0[i0 & 3u]);
                r0.y ^= (((unsigned)h1 << (0xa3d97fu & 31u)) * garr[u2 & 7u]);
            } while (i2++ < 4u && (0x9f992cdeu + u0));
        } while (i1++ < 7u && fuel);
        { unsigned t2; double z2; if (((unsigned)((short)m0 > (signed char)(unsigned)w0)) & 1u) { t2 = 0xffffffffu; z2 = (double)(((unsigned)((int)(unsigned)((int)garr[u2 & 7u] < (int)(unsigned)c1) < (int)6u)) & 255u); } if (((unsigned)((short)m0 > (signed char)(unsigned)w0)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            if ((unsigned)(0xffffffffu == 0u)) {
                break; (void)((0x7fffffffu % (~(u2 << ((unsigned)(w0 >> 29) & 31u)) | 1u)));
            } else {
                break; (void)(p1);
                if (((unsigned)(w0 >> 29) >> (i0 & 31u))) break;
                v0 = (unsigned)(r0.y || (unsigned)((int)0x3b917d09u < (int)(unsigned)s0));
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)p2 < (int)garr[u2 & 7u]), (unsigned)h1, (garr[i1 & 7u] - (unsigned)h1)); }
            }
            if (i1) break;
        }
        if ((unsigned)!(unsigned)((short)(unsigned)((unsigned)s0 < 8u) > (signed char)0x1e3898cdu)) break;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 11u, 0xdc7db673u, 0xc420a84cu },
        { 8u, 0x5f10007du, 0x69ef9b73u },
        { 11u, 0xdc822d41u, 0x10678253u },
        { 4u, 0xb1739c29u, 0x64b36828u },
        { 12u, 0xa9226b30u, 0x63803fb5u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
