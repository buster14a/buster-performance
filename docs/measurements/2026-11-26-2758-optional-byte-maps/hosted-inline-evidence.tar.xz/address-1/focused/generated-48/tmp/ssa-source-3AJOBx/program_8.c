// test-ssa-source's program of seed 134000410 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xb106da43u, g1 = 0x1875a929u;
static unsigned garr[8] = { 0x233fad9eu, 0x98345d69u, 0xfb332ce9u, 0x383e2c71u, 0x6d0b9452u, 0xac46e799u, 0xa2afc6aau, 0x8f4eea93u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((r0.y % (u0 | 1u))) goto L2;
    goto L2;
    L0: if (--fuel == 0u) goto done;
    goto L2;
    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(m0 - (unsigned)(p0 == p1)) & 1023u);
    if ((unsigned)s0) goto L1;
    if ((unsigned)(i0 == (unsigned)(short)((unsigned)w0 >> ((unsigned)(x0 >> 70) & 31u)))) goto L1;
    r0.y ^= (garr[i1 & 7u] >> ((unsigned)(unsigned char)(unsigned)((int)g0 >= (int)(unsigned)l0) & 31u));
    while (i0++ < 6u && (p2 ? i0 : garr[u2 & 7u])) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)((short)0xee21f9eau > (signed char)(unsigned)(w0 >> 29));
        L1: if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)((int)((unsigned)(unsigned char)(unsigned)((short)0x249cff26u > (signed char)3u) | 0x80000000u) >= (int)(i0 % (r0.y | 1u))) & 1023u);
    }
    s1 = (int)((unsigned)s1 + ~(8u + fuel));
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        q0 = &garr[(unsigned)x0 & 7u];
        g1 += ((unsigned)f0 % ((unsigned)((unsigned)x0 && a0[u1 & 3u]) | 1u));
        break; (void)((unsigned)(*mp < ((unsigned)f0 << (m0 & 31u))));
        break; (void)((0x7f630899u - (unsigned)(unsigned char)(p0 & v0)));
        while (i1++ < 4u && (unsigned)h0) { if (--fuel == 0u) goto done;
            u1 ^= (unsigned)((unsigned)l0 < (unsigned)l0);
            do { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    goto done;
                    h0 = (short)(unsigned)(signed char)(p1 << ((4u ^ (~(unsigned)((int)g0 < (int)(unsigned)c1) & 0x2bd14b7du)) & 31u));
                    if ((unsigned)(x0 >> 70)) break;
                    L2: if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                }
                e0 = e0 * 0.5L + (long double)(a0[u1 & 3u] & 1023u);
            } while (i2++ < 6u && (m0 + 9u));
            L4: if (--fuel == 0u) goto done;
        }
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((u1 & *q0)) continue;
            w0 = w0 * 6364136223846793005ull + (unsigned)(short)((0x10000u ^ v0) << ((0x80000000u / (4u | 1u)) & 31u));
            w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)((g0 ? p2 : p1) << ((unsigned)(signed char)(unsigned)(0x7fffffffu == r0.y) & 31u));
            c0 = (unsigned char)(((unsigned)c0 ? (unsigned)c1 : i1) << ((unsigned)((int)p0 < (int)(unsigned)s0) & 31u));
            q0 = &garr[(unsigned)w0 & 7u];
            switch (((r0.x / (*mp | 1u)) | i0) & 7u) {
                *mp = (unsigned)(u1 || u0);
                g0 = (i0 | (0x10000u | u3));
                case 2u: ;
                l0 = (long)((unsigned long)l0 + (unsigned)((short)(unsigned)(0x7fffffffu == (unsigned)h0) > (signed char)(unsigned)(5u && 6u)));
            }
        }
    }
    if ((unsigned)((short)a0[i0 & 3u] > (signed char)*mp)) goto L1;
    if ((unsigned)!(p0 / (a0[i0 & 3u] | 1u))) goto L4;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)((unsigned)((unsigned)((int)0x7fffffffu < (int)0u) < (unsigned)!(7u >> (0x5f5fd4b7u & 31u))) - (unsigned)b0);
        if ((unsigned)(p1 || r0.y)) break;
        if ((*q0 & g1)) {
            break; (void)(0x274b9b2bu);
            if ((unsigned)!((unsigned)b0 + (unsigned)h1)) break;
            *q0 = ((unsigned)((int)0x8de7d51cu < (int)m0) - ((unsigned)b0 % ((unsigned)((unsigned)h1 && (unsigned)c1) | 1u)));
            g0 = (unsigned)((int)m0 < (int)(unsigned)(signed char)(0xffffffffu / (5u | 1u)));
            if (u3 == 7u) return ((unsigned)(x0 >> 70) % (a0[u1 & 3u] | 1u));
            u2 += 6u;
        }
        if ((unsigned)((short)(0xffffffffu | 0x80000000u) > (signed char)0x80000000u)) break;
        x0 = x0 * 0x100000001b3ull + (unsigned)!((unsigned)(*mp || (unsigned)x0) - 0xffffffffu);
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if ((r0.y ^ (unsigned)c1)) break;
            break; (void)(6u);
            w0 ^= (unsigned long long)(unsigned)(u0 && (unsigned)c1) << ((unsigned)!((unsigned)((int)(unsigned)c0 >= (int)(0x80000000u << ((unsigned)w0 & 31u))) - ~(i0 | 0x7fffffffu)) & 63u);
            switch ((v0 - (a0[u1 & 3u] % ((unsigned)f0 | 1u))) & 7u) {
                q0 = &garr[0x386cf57fu & 7u];
                case 2u: ;
                s0 = (int)(unsigned)x0;
                switch (((unsigned)s0 ^ (unsigned)(g1 < (unsigned)c1)) & 7u) {
                    goto L2;
                    case 0u: ;
                    l0 = (long)((unsigned long)l0 + ((unsigned)c1 / (i0 | 1u)));
                    if ((unsigned)((int)(unsigned)e0 < (int)*q0)) {
                        v0 = (unsigned)(w0 >> 29);
                        case 5u: ;
                    }
                    case 6u: ;
                }
                case 5u: ;
            }
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)((short)(unsigned)((unsigned)(i2 || i0) < (unsigned)(u3 < (unsigned)s1)) > (signed char)*mp) & 7u];
                c1 = (signed char)(unsigned)!(unsigned)((int)(unsigned)((unsigned)e0 || u1) < (int)0u);
                if (i2) continue;
                c0 = (unsigned char)(unsigned)((int)u3 < (int)0xb2264d59u);
                q0 = &garr[(u2 ^ (unsigned)((unsigned)l0 < (unsigned)(0xddf97f5cu < u3))) & 7u];
            }
        } while (i1++ < 7u && ((unsigned)c1 ? a0[i0 & 3u] : 0x8424ce18u));
        i0 = (unsigned)h1 & 15u;
        switch ((unsigned)((int)(*q0 | p1) < (int)1u) & 7u) {
            case 1u: ;
            c1 = (signed char)((unsigned)(signed char)((unsigned)(x0 >> 70) % ((unsigned)(x0 >> 70) | 1u)) << (4u & 31u));
            if ((0x91680551u / (*q0 | 1u))) {
                case 4u: ;
            } else {
                if (u0) break;
                do { if (--fuel == 0u) goto done;
                    goto L2;
                    case 2u: ;
                } while (i1++ < 6u && (unsigned)!(unsigned)((unsigned)(signed char)(unsigned)(u3 && 7u) == (unsigned)h1));
            }
        }
        *q0 = (unsigned)((0x10000u - *mp) < (unsigned)((short)0x10000u > (signed char)g1));
        s0 = (int)((0x80000000u + (unsigned)c1) >> ((unsigned)!(unsigned)(6u || (unsigned)s0) & 31u));
        break; (void)((0xffffffffu * a0[i0 & 3u]));
    }
    x0 = x0 * 0x100000001b3ull + -(0x80000000u * 0x10000u);
    m0 ^= (u1 >> ((unsigned)h1 & 31u));
    q0 = &garr[(unsigned)((int)(unsigned)(i2 < (unsigned)s0) < (int)*q0) & 7u];
    if (fuel) goto L1;
    *q0 = (unsigned)((int)garr[u2 & 7u] < (int)0xa84a410fu);
    goto L4;
    for (;;) { if (--fuel == 0u) goto done;
        if ((r0.x - (unsigned)(0u < fuel))) break;
        a0[(a0[i0 & 3u] % (r0.y | 1u)) & 3u] = (unsigned)!(unsigned)((int)(*mp % (p2 | 1u)) >= (int)*mp);
    }
    { unsigned t0; double z0; if (((unsigned)((0xccfac1d7u << (*q0 & 31u)) < 0x97fadbfbu)) & 1u) { t0 = (unsigned)(a0[u1 & 3u] && fuel); z0 = (double)((0xffffffffu) & 255u); } if (((unsigned)((0xccfac1d7u << (*q0 & 31u)) < 0x97fadbfbu)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        goto done;
        if ((unsigned)((unsigned)f0 == *mp)) goto L3;
        if (0x23d264c4u) {
            r0.x = ((unsigned)c0 | (unsigned)((unsigned)s1 || (p2 & 9u)));
            if ((7u ? v0 : 0x10000u)) goto L2;
        }
        m0 ^= g0;
    }
    f0 = f0 * 0.5f + (float)((((unsigned)c1 % ((unsigned)s1 | 1u)) & (unsigned)c0) & 255u);
    g1 += ((unsigned)c0 / ((unsigned)(0xffffffffu < u3) | 1u));
    u1 = ((unsigned)e0 + (i2 >> ((unsigned)(x0 >> 70) & 31u)));
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        u1 ^= (4u ? (unsigned)((unsigned)b0 == (0xffffffffu % (*q0 | 1u))) : 0xfc50b42eu);
        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(signed char)(r0.y ? 0x376c11fdu : fuel) == (unsigned)c1) & 1023u);
        if (((unsigned)c0 << ((unsigned)e0 & 31u))) break;
    }
    q0 = &garr[((0x31f7a435u ? (r0.y % (0x7fffffffu | 1u)) : p1) * (unsigned)s0) & 7u];
    l0 = (long)((unsigned long)l0 + ((fuel / (a0[u1 & 3u] | 1u)) << (-(unsigned)((int)(p0 % ((unsigned)s1 | 1u)) >= (int)u0) & 31u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(v0 == 0xae64c4b7u)) {
        L0: if (--fuel == 0u) goto done;
    } else {
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)(unsigned char)(unsigned)((unsigned)((short)fuel > (signed char)(unsigned)e0) && (unsigned)w0));
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)s0, (unsigned)((int)(unsigned)h1 >= (int)(0xaaabb63eu ^ i2)), ((0x72eea793u & 0x937074a7u) - *q0)); }
            switch (i0 & 7u) {
                continue; (void)((i2 % ((unsigned)(w0 >> 29) | 1u)));
                do { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + 0x7861e6c3u);
                    c1 = (signed char)((0x3bfca7f2u | 0xffffffffu) >> ((unsigned)(short)((unsigned)s0 + (fuel >> (a0[i0 & 3u] & 31u))) & 31u));
                } while (i1++ < 3u && ((unsigned)x0 >> ((unsigned)(x0 >> 70) & 31u)));
                if (u0) break;
            }
            if (fuel < 8u) return ((unsigned)(p1 || 0x80000000u) << (0x323b9227u & 31u));
            e0 = e0 * 0.5L + (long double)(((unsigned)!(u1 + (unsigned)(x0 >> 70)) / (u2 | 1u)) & 1023u);
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)((unsigned)s1 >> (1u & 31u)) << ((0x7fffffffu + (unsigned)((int)(unsigned)l0 < (int)4u)) & 63u);
            } while (i1++ < 7u && (unsigned)x0);
        }
        c1 = (signed char)(u0 - a0[u1 & 3u]);
        c0 = (unsigned char)(((unsigned)(unsigned char)(unsigned)((int)(unsigned)w0 >= (int)g0) + r0.x) + i0);
    }
    v0 = ((unsigned)(((unsigned)f0 * (unsigned)(unsigned char)((unsigned)s1 - i2)) == 0xffffffffu) - i0);
    u3 ^= (a0[u1 & 3u] & 0x80000000u);
    if ((g1 % ((unsigned)l0 | 1u))) goto L1;
    h0 = (short)~(0x10000u * *mp);
    u1 += (unsigned)((int)(unsigned)((int)r0.x >= (int)(unsigned)(x0 >> 70)) < (int)(unsigned)(x0 >> 70));
    garr[(v0 << (garr[u2 & 7u] & 31u)) & 7u] = (i0 & (3u ? (9u & p2) : 3u));
    L1: if (--fuel == 0u) goto done;
    goto L2;
    while (i0++ < 3u && u0) { if (--fuel == 0u) goto done;
        *q0 += u1;
        if (fuel < 8u) return (unsigned)((5u & (unsigned)c1) < (*mp >> (*q0 & 31u)));
        while (i1++ < 7u && (unsigned)h1) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)c0, (unsigned)!(unsigned)((unsigned)d0 == (0u * i2)), 0xdee0fbf7u); }
            if ((unsigned)(9u == (unsigned)((int)*mp < (int)garr[i1 & 7u]))) break;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0(0x7fffffffu, (unsigned)(x0 >> 70), (unsigned)(signed char)(unsigned)((int)(unsigned)((unsigned)(x0 >> 70) < u2) < (int)m0)); }
        *mp = 0u;
        f0 = f0 * 0.5f + (float)((((unsigned)h1 ? r0.x : g1) | g1) & 255u);
    }
    goto L4;
    L2: if (--fuel == 0u) goto done;
    m0 ^= ((unsigned)(short)(p0 * 9u) * 0x8e26944du);
    { unsigned t0; double z0; if (((7u ^ (unsigned)(x0 >> 70))) & 1u) { t0 = (3u + ~((unsigned)s0 + a0[u1 & 3u])); z0 = (double)(((0u ^ 0x99d88ac4u)) & 255u); } if (((7u ^ (unsigned)(x0 >> 70))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)(i0 && 0xffffffffu) % (7u | 1u))) {
                L3: if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
            }
            if ((~(unsigned)(1u || u3) - (unsigned)(w0 >> 29))) break;
            g0 = (unsigned)((unsigned)((unsigned)((int)0x10000u >= (int)0x8351ce76u) == (unsigned)x0) < (unsigned)c1);
            u3 = (3u ^ i2);
        }
        w0 = w0 * 6364136223846793005ull + ((unsigned)((int)0x8b385314u < (int)0x63d2eedfu) << ((unsigned)(unsigned char)(unsigned)(0x80000000u || a0[i0 & 3u]) & 31u));
        switch (2u & 7u) {
            while (i0++ < 7u && 0xf48b25d6u) { if (--fuel == 0u) goto done;
                r0.y ^= (*mp & u1);
                i0 = ((unsigned)(9u && (unsigned)d0) + garr[u2 & 7u]) & 15u;
                l0 = (long)((unsigned long)l0 + (unsigned)((int)(0x10000u % ((g0 >> (u1 & 31u)) | 1u)) < (int)4u));
                break; (void)((unsigned)(w0 >> 29));
                if ((0xa79914f6u / ((unsigned)h0 | 1u))) break;
            }
            l0 = (long)((unsigned long)l0 + *mp);
            for (;;) { if (--fuel == 0u) goto done;
                b0 = 0x9dd17b4cu != 0u;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    switch (((unsigned)x0 + 5u) & 7u) {
                        *q0 += r0.x;
                        goto L0;
                        case 5u: ;
                        continue; (void)((unsigned)(p1 < (u3 / (5u | 1u))));
                    }
                    case 5u: ;
                    s0 = (int)(unsigned)((int)(unsigned)((int)(unsigned)c1 < (int)p0) >= (int)(i2 / (0x10000u | 1u)));
                    b0 = (0x750c964du - 0x80000000u) != 0u;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((short)0x80000000u > (signed char)(unsigned)(w0 >> 29)) - 0x80000000u), ((unsigned)c1 << (g1 & 31u)), ((unsigned)(w0 >> 29) % (((unsigned)s1 / (0xffffffffu | 1u)) | 1u))); }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0(6u, (g1 & u1), -(unsigned)((unsigned)c0 && u3)); }
                case 4u: ;
            }
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(p1, ~(4u << (fuel & 31u)), (unsigned)(signed char)(r0.x >> (u0 & 31u))); }
                        *mp = ((p1 * ((unsigned)x0 + u0)) ^ r0.x);
                        w0 ^= (unsigned long long)(unsigned)((int)garr[i1 & 7u] >= (int)u2) << (((unsigned)(((unsigned)h1 ^ p2) < (unsigned)h0) / (p2 | 1u)) & 63u);
                        if (4u) continue;
                        c0 = (unsigned char)(unsigned)((short)((unsigned)((int)0x7fffffffu < (int)garr[i1 & 7u]) | p0) > (signed char)(unsigned)((unsigned)(x0 >> 70) < r0.y));
                    } while (i2++ < 6u && (*q0 * 0x7fffffffu));
                    h1 = (unsigned short)(h1 + (unsigned)(a0[i0 & 3u] || (unsigned)(r0.y && (unsigned)d0)));
                    if ((unsigned)s0) continue;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)b0 & (r0.y / ((unsigned)b0 | 1u))), (unsigned)(1u == (0x52b51075u & 6u)), (unsigned)(short)((unsigned)f0 / (p1 | 1u))); }
                    case 3u: ;
                } while (i1++ < 4u && 0x5172792u);
                while (0xffffffffu) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)d0 >= (int)(unsigned)((short)2u > (signed char)0xffffffffu)), ((unsigned)(signed char)(0xd8098114u | u1) + (unsigned)s0), (unsigned)(unsigned char)(unsigned)(r0.y && i2)); }
                    c1 = (signed char)(unsigned)((short)(unsigned)s1 > (signed char)(v0 ? m0 : (unsigned)e0));
                    c1 = (signed char)(unsigned)((int)(unsigned)((int)((unsigned)s1 << (0xf88f26e5u & 31u)) < (int)(unsigned)(x0 >> 70)) < (int)(unsigned)((unsigned)f0 && 0x77e8cc88u));
                    u2 += (unsigned)(u2 && ((unsigned)d0 / (0x12d06b76u | 1u)));
                    if (budget != 0u) { budget -= 1u; u2 = fn0(7u, garr[u2 & 7u], *mp); }
                    do { if (--fuel == 0u) goto done;
                        if ((*mp % (m0 | 1u))) continue;
                        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                            if (m0) break;
                            s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)s0 >= (int)i2));
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(unsigned char)((unsigned)d0 + (unsigned)(0xc04f73abu && 4u)), (unsigned)!(0x10000u / (g0 | 1u)), (unsigned)!(unsigned)((int)((unsigned)b0 | 0xc590614bu) < (int)0u)); }
                        }
                        b0 = (unsigned)((int)(unsigned)e0 >= (int)(i2 ? ~(unsigned)((int)u2 < (int)r0.y) : g1)) != 0u;
                        while (i0++ < 3u && ((unsigned)(9u && (unsigned)x0) | (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x7fffffffu == 0x80000000u), (unsigned)(garr[u2 & 7u] < -(unsigned)((int)(unsigned)b0 >= (int)a0[u1 & 3u])), (unsigned)(signed char)(((unsigned)b0 ^ v0) % (garr[i1 & 7u] | 1u))); }
                            a0[(unsigned)((int)(unsigned)x0 >= (int)a0[u1 & 3u]) & 3u] = (unsigned)(signed char)(unsigned)(0xb3a4a2beu && 0x10000u);
                        }
                        switch (((unsigned)(7u < (unsigned)s0) | fuel) & 7u) {
                            if ((unsigned)(0x7fffffffu < (u0 - u0))) break;
                            g0 = (unsigned)(garr[i1 & 7u] || (unsigned)h1);
                            *q0 += (unsigned)(0x7fffffffu < *q0);
                            if ((unsigned)((int)0x5f7f9ee5u >= (int)(unsigned)h0)) continue;
                            if (budget != 0u) { budget -= 1u; u1 = fn0(u3, v0, (8u | r0.y)); }
                            case 1u: ;
                        }
                    } while (i2++ < 3u && (unsigned)(0x48edccccu || m0));
                }
            }
        }
        goto done;
        goto L0;
        l0 = (long)((unsigned long)l0 + a0[u1 & 3u]);
    }
    { unsigned t1; double z1; if (((unsigned)f0) & 1u) { t1 = (unsigned)((int)(unsigned)d0 >= (int)0x80000000u); z1 = (double)(((unsigned)((unsigned)d0 || fuel)) & 255u); } if (((unsigned)f0) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        garr[a0[u1 & 3u] & 7u] = (unsigned)((int)(unsigned)(signed char)(unsigned)(~(a0[u1 & 3u] % (g0 | 1u)) == (unsigned)(0xffffffffu || u3)) < (int)0xffffffffu);
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(unsigned)(garr[u2 & 7u] < (p1 << (r0.x & 31u))), (garr[i1 & 7u] % ((unsigned)(unsigned char)(unsigned)((short)0x3b038835u > (signed char)p1) | 1u)), (unsigned)(signed char)(unsigned)((int)u1 < (int)(unsigned)l0)); }
        u3 = u0;
        i1 = ((unsigned)(short)(i1 << (p2 & 31u)) ^ ((unsigned)h1 * ~(unsigned)((int)0x3169eebfu < (int)(unsigned)s1))) & 15u;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(~(u0 % ((unsigned)(i0 || garr[u2 & 7u]) | 1u)), (0x96df9f5u - 4u), u1); }
            do { if (--fuel == 0u) goto done;
                if (((unsigned)(w0 >> 29) - g1)) break;
                if ((0x7fffffffu ^ (0x7fffffffu + i0))) break;
                if ((7u ^ (unsigned)((unsigned)l0 && r0.x))) break;
                if (budget != 0u) { budget -= 1u; u2 = fn0(0x4dd9a375u, (unsigned)(unsigned char)((unsigned)d0 / (0xd0f7bc72u | 1u)), ~((unsigned)h0 - (unsigned)((int)p2 < (int)(unsigned)(x0 >> 70)))); }
            } while (i1++ < 4u && (unsigned)!(r0.x << (0xfadb6577u & 31u)));
            if ((unsigned)c0) {
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((g1 - m0) == (unsigned)d0), 8u, (fuel << (((unsigned)s0 & 0x4e8f7132u) & 31u))); }
                switch ((unsigned)(signed char)(unsigned)(p0 || 9u) & 7u) {
                    if (0xa7b09072u) break;
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(p0 < (unsigned)(w0 >> 29)) || 0x80000000u));
                    w0 ^= (unsigned long long)(u1 << (a0[i0 & 3u] & 31u)) << ((unsigned)((unsigned)((int)(unsigned)s1 < (int)0x80000000u) < a0[u1 & 3u]) & 63u);
                    if (budget != 0u) { budget -= 1u; u0 = fn0(*mp, (2u * (i0 ^ garr[i1 & 7u])), ((unsigned)l0 - (*q0 * 0xc7854a0eu))); }
                }
            }
            a0[i1 & 3u] = (unsigned)((short)(r0.y % (0xb7f16801u | 1u)) > (signed char)9u);
        } while (i0++ < 7u && (u3 << (u1 & 31u)));
        { unsigned t2; double z2; if (((unsigned)((unsigned)e0 && a0[i0 & 3u])) & 1u) { t2 = 0xec79c7d0u; z2 = (double)(((unsigned)l0) & 255u); } if (((unsigned)((unsigned)e0 && a0[i0 & 3u])) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            if (budget != 0u) { budget -= 1u; u3 = fn0((a0[i0 & 3u] << ((unsigned)(i1 < 0x10000u) & 31u)), -(unsigned)((short)(unsigned)f0 > (signed char)(unsigned)c0), (unsigned)w0); }
            u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)((unsigned)h0 || i0) || ~(unsigned)(g0 < (unsigned)(signed char)(unsigned)(a0[i0 & 3u] && (unsigned)w0)));
            goto L1;
        }
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (4u ? p0 : 8u));
        g0 = ((unsigned)(0xaf2b4e4bu == p0) ^ (5u & 0x83c025d4u));
        *q0 = (unsigned)(((unsigned)x0 ^ r0.y) && 0x9e02562u);
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)e0 << (i1 & 31u)), (unsigned)(i0 || (0x184c6e5u << ((unsigned)b0 & 31u))), (unsigned)((unsigned)e0 || r0.x)); }
        u2 += (unsigned)((unsigned)((short)(unsigned)(short)((unsigned)c1 / ((unsigned)e0 | 1u)) > (signed char)(unsigned)h1) || (i0 + 0x44adb0d4u));
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)c1 == p1), (unsigned)(x0 >> 70), ((unsigned)(1u < 4u) | a0[i0 & 3u])); }
        w0 ^= (unsigned long long)(g0 | r0.x) << ((unsigned)((int)(unsigned)((unsigned)e0 || (r0.x + (unsigned)(0x7fffffffu && fuel))) >= (int)5u) & 63u);
        a0[(unsigned)x0 & 3u] = 0xddafdd18u;
        break; (void)(0x7fdbbc19u);
    } while (i0++ < 3u && (unsigned)((int)(unsigned)(1u == p1) < (int)(unsigned)b0));
    switch ((unsigned)(m0 && g0) & 7u) {
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t3; double z3; if ((fuel) & 1u) { t3 = (u1 >> (u0 & 31u)); z3 = (double)(((unsigned)(signed char)((unsigned)l0 ^ 6u)) & 255u); } if ((fuel) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                if (budget != 0u) { budget -= 1u; u3 = fn0(0x80000000u, (unsigned)!(((unsigned)c0 >> (p0 & 31u)) * 0x80000000u), (unsigned)((int)g1 < (int)(unsigned)f0)); }
                u0 = ((unsigned)((unsigned)x0 < r0.y) >> (((0x3c4960eau << (4u & 31u)) % (r0.x | 1u)) & 31u));
                m0 ^= (-(unsigned)((short)0x7fffffffu > (signed char)5u) * (unsigned)d0);
                if (budget != 0u) { budget -= 1u; u3 = fn0((*q0 / (p1 | 1u)), (unsigned)(p2 < (unsigned)s0), (u3 + (unsigned)(unsigned char)((unsigned)c0 / (fuel | 1u)))); }
                if (((unsigned)((unsigned)x0 == (unsigned)(x0 >> 70)) >> (garr[u2 & 7u] & 31u))) goto L2;
                m0 ^= (unsigned)((int)0x10000u >= (int)(0x1d384a32u >> ((unsigned)(unsigned char)(unsigned)((unsigned)f0 && (unsigned)c0) & 31u)));
            }
            e0 = e0 * 0.5L + (long double)(((unsigned)s1 * 0x80000000u) & 1023u);
            if ((unsigned)(unsigned char)((i0 ^ p1) * 3u)) goto L3;
            if ((unsigned)((unsigned)d0 < (unsigned)(0x80000000u == p1))) goto done;
        }
        if ((unsigned)f0) goto L3;
    }
    do { if (--fuel == 0u) goto done;
        c0 = (unsigned char)((a0[u1 & 3u] + 6u) / (0xabcb207cu | 1u));
        c0 = (unsigned char)((unsigned)(signed char)((unsigned)((unsigned)(x0 >> 70) < 0x69ba6f2au) / ((unsigned)w0 | 1u)) << ((unsigned)((short)u3 > (signed char)(unsigned)c0) & 31u));
        f0 = f0 * 0.5f + (float)(p0 & 255u);
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            *mp = (unsigned)!(unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)((int)(r0.y / (p2 | 1u)) < (int)u2));
            if (budget != 0u) { budget -= 1u; u1 = fn0((a0[u1 & 3u] + (unsigned)((unsigned)f0 || u3)), a0[i0 & 3u], (unsigned)d0); }
        }
        if ((unsigned)s1) goto L3;
    } while (i0++ < 6u && -(unsigned)((unsigned)(w0 >> 29) || ((unsigned)h1 | p0)));
    if (((unsigned)l0 * (unsigned)b0)) goto L3;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        continue; (void)(((0x7fffffffu | 0x7b4c2132u) % (i1 | 1u)));
        *q0 = u0;
        r0.y ^= ((garr[i1 & 7u] & 6u) ^ 0x362bcbb9u);
        *q0 += ((unsigned)f0 << ((unsigned)((short)0x250b7b44u > (signed char)(unsigned)d0) & 31u));
        if ((unsigned)((unsigned)!(unsigned)(u2 || i1) == fuel)) break;
    }
    *mp = ((0xc2ae7257u & (unsigned)x0) ? 0xffffffffu : 0x5951c924u);
    if ((unsigned)((int)*mp >= (int)(unsigned)(w0 >> 29))) goto L0;
    d0 = d0 * 0.5 + (double)(((p2 & 1u) + (unsigned)c0) & 1023u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L1;
    L0: if (--fuel == 0u) goto done;
    switch (((unsigned)((int)garr[u2 & 7u] >= (int)0x6ad16391u) % ((unsigned)x0 | 1u)) & 7u) {
        do { if (--fuel == 0u) goto done;
            goto L3;
            if (p1) {
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)c0 >= (int)0x5d51e98u), r0.y, (unsigned)((unsigned)s0 || (unsigned)s0)); }
                break; (void)((unsigned)d0);
                case 3u: ;
            } else {
                u1 = u1 * 0x9e3779b1u + (8u - 0x77384da4u);
                if ((0x7fffffffu >> ((unsigned)(short)(unsigned)((short)(unsigned)x0 > (signed char)(unsigned)h1) & 31u))) {
                    default: ;
                    s0 = (int)(u2 * 3u);
                }
            }
        } while (i0++ < 6u && (r0.x << ((unsigned)(x0 >> 70) & 31u)));
        if (garr[u2 & 7u]) break;
        while (i0++ < 4u && (unsigned)((unsigned)e0 == (unsigned)(garr[u2 & 7u] == m0))) { if (--fuel == 0u) goto done;
            case 4u: ;
            L1: if (--fuel == 0u) goto done;
        }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)((int)0u >= (int)p1) < (int)0x2c113417u)) continue;
            if ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)i2)) break;
        } while (i0++ < 2u && (unsigned)((int)(v0 << (7u & 31u)) >= (int)garr[i1 & 7u]));
        if (((unsigned)h1 | 0x10000u)) {
            if (budget != 0u) { budget -= 1u; u3 = fn0(0xcf939d5du, 0x7fffffffu, p1); }
            c1 = (signed char)(((unsigned)x0 * (*q0 - (unsigned)(w0 >> 29))) - (u3 >> (g1 & 31u)));
            u1 = ((unsigned)f0 | (unsigned)b0);
            q0 = &garr[(((unsigned)(*mp < i1) - a0[i0 & 3u]) << ((unsigned)s1 & 31u)) & 7u];
        }
        if ((unsigned)!(unsigned)(a0[u1 & 3u] < u3)) {
            if ((r0.x - (unsigned)(4u < g0))) {
                break;
            } else {
                r0.x = (unsigned)(unsigned char)(a0[u1 & 3u] / (a0[u1 & 3u] | 1u));
                do { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)!((unsigned)!((unsigned)l0 / ((unsigned)d0 | 1u)) << (g1 & 31u)) > (signed char)((unsigned)e0 % (p2 | 1u)));
                    L2: if (--fuel == 0u) goto done;
                    r0.x = (unsigned)((int)0xedbf2d43u < (int)p0);
                } while (i0++ < 6u && (unsigned)(u0 && garr[u2 & 7u]));
                s0 = (int)(unsigned)((unsigned)((int)5u >= (int)3u) && (garr[u2 & 7u] & 7u));
            }
            u1 += (7u >> ((unsigned)((int)g0 < (int)(unsigned)((unsigned)x0 < (4u & (unsigned)(x0 >> 70)))) & 31u));
            c1 = (signed char)(g1 - (unsigned)(x0 >> 70));
            do { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)((int)fuel >= (int)(unsigned)(unsigned char)(unsigned)((unsigned)c0 || (0x879a6e59u >> ((unsigned)(a0[i0 & 3u] || (unsigned)c1) & 31u)))) & 1023u);
                L3: if (--fuel == 0u) goto done;
                a0[~(unsigned)(0x10000u == (unsigned)(x0 >> 70)) & 3u] = (0xffffffffu - (unsigned)((a0[i0 & 3u] | r0.x) == (0x102f349bu ^ i0)));
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)w0, (u0 >> (~(0x834b92acu / (u0 | 1u)) & 31u)), ((unsigned)((int)p1 >= (int)0u) / (p0 | 1u))); }
            } while (i0++ < 6u && 0xdc142413u);
        }
    }
    *mp = (unsigned)((int)(u3 ? fuel : 0x7fffffffu) >= (int)(0x7fffffffu >> (p1 & 31u)));
    v0 = (2u / (p1 | 1u));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)d0 % (((unsigned)e0 << (0xd8b86100u & 31u)) | 1u))) {
            L4: if (--fuel == 0u) goto done;
            switch (((unsigned)((unsigned)f0 && (unsigned)c0) - g1) & 7u) {
                r0.y ^= (unsigned)(unsigned char)(*q0 % ((unsigned)((int)(unsigned)c0 < (int)g0) | 1u));
                case 5u: ;
                goto L0;
                u0 += (unsigned)!(garr[i1 & 7u] * i0);
            }
            do { if (--fuel == 0u) goto done;
                u2 ^= (unsigned)((int)(0x3c844366u * (0x7fffffffu << ((unsigned)c0 & 31u))) >= (int)(unsigned)((int)6u < (int)m0));
                d0 = d0 * 0.5 + (double)(((unsigned)s0 % (((unsigned)c1 * 0x7fffffffu) | 1u)) & 1023u);
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (fuel) continue;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)d0, ~(unsigned)((unsigned)c1 && (unsigned)f0), fuel); }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(0x63c15e04u, (unsigned)s1, ~(r0.x << (0x21397ad6u & 31u))); }
                    if (2u) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn1(p1, (unsigned)(unsigned char)(unsigned)(m0 == (6u / ((unsigned)h0 | 1u))), 0x10000u); }
                }
            } while (i1++ < 2u && *mp);
            do { if (--fuel == 0u) goto done;
                b0 = (unsigned)((short)~(unsigned)((unsigned)c0 || p0) > (signed char)u3) != 0u;
                r0.x = ((unsigned)!(unsigned)(a0[u1 & 3u] || 0xfb9be805u) << (r0.x & 31u));
                g1 += (*q0 | 4u);
            } while (i1++ < 6u && (unsigned)c0);
        } else {
            if ((unsigned)s1) break;
            w0 = w0 * 6364136223846793005ull + ((unsigned)(g1 || 0u) - p1);
            if (budget != 0u) { budget -= 1u; u1 = fn1(-(unsigned)((garr[u2 & 7u] - (unsigned)b0) == r0.x), ~(g1 * 0x75078f17u), *mp); }
        }
        *q0 = -(unsigned)(((unsigned)(w0 >> 29) - ((unsigned)x0 + r0.x)) == v0);
        if ((unsigned)(short)((unsigned)(w0 >> 29) * (*q0 + 1u))) {
            if ((g0 & i1)) continue;
            a0[(unsigned)s0 & 3u] = (0u | (unsigned)((int)v0 >= (int)0xffffffffu));
            for (;;) { if (--fuel == 0u) goto done;
                u2 ^= ((unsigned)!(0xea667670u ? r0.x : (unsigned)w0) / ((unsigned)e0 | 1u));
                { unsigned t0; double z0; if (((unsigned)((int)p1 >= (int)(unsigned)s0)) & 1u) { t0 = p0; z0 = (double)(((unsigned)(a0[i0 & 3u] && (8u + fuel))) & 255u); } if (((unsigned)((int)p1 >= (int)(unsigned)s0)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                    if (7u) break;
                    if ((unsigned)((short)(u1 << ((unsigned)f0 & 31u)) > (signed char)i1)) goto L4;
                    if ((g1 | (unsigned)h0)) {
                        goto L1;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(0x10000u < (unsigned)w0), (unsigned)((int)r0.x >= (int)0xf17356dcu), 0x8dab6bdfu); }
                        if (budget != 0u) { budget -= 1u; u1 = fn1((p2 | (unsigned)(w0 >> 29)), (unsigned)(0x10000u && 0x80000000u), (unsigned)(short)(g0 * (unsigned)(5u == (unsigned)s1))); }
                    } else {
                        garr[4u & 7u] = (unsigned)(unsigned char)(unsigned)((int)(unsigned)w0 >= (int)0u);
                        g0 = (((unsigned)(x0 >> 70) << (0u & 31u)) ^ 0x10000u);
                        u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)(x0 >> 70) && a0[i0 & 3u]);
                    }
                    if ((-(0x7d82ffc8u + 0x870e04a1u) % (p2 | 1u))) break;
                    if ((fuel * 1u)) break;
                    garr[(0x5b14e5f6u % (0x61db1c77u | 1u)) & 7u] = (((r0.x & (unsigned)s0) ^ *mp) & (0x16270659u ^ garr[i1 & 7u]));
                }
                garr[*q0 & 7u] = (unsigned)(short)(unsigned)((unsigned)(signed char)((unsigned)(x0 >> 70) + p2) == ((unsigned)((short)0xff471b42u > (signed char)(unsigned)l0) / (0x7fffffffu | 1u)));
            }
            if ((3u & 0x10000u)) break;
            if ((unsigned)b0) continue;
        }
        if (0x9718a325u) goto L4;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1(0x7fffffffu, (unsigned)e0, 0x80000000u); }
            s1 = (int)((unsigned)s1 + (((unsigned)((unsigned)(w0 >> 29) == (unsigned)c1) % (p2 | 1u)) / ((*q0 & (unsigned)h0) | 1u)));
        }
        q0 = &garr[(unsigned)((short)(((unsigned)s1 + (r0.x >> ((unsigned)s1 & 31u))) - 0xd4858c01u) > (signed char)0x7fffffffu) & 7u];
    }
    goto done;
    if (budget != 0u) { budget -= 1u; u3 = fn1(garr[u2 & 7u], (a0[u1 & 3u] % (*mp | 1u)), 3u); }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (a0[u1 & 3u]) {
            s1 = (int)((unsigned)s1 + (garr[u2 & 7u] | (unsigned)((unsigned)x0 || u2)));
            do { if (--fuel == 0u) goto done;
                v0 = (unsigned)((int)0x5071f4f6u >= (int)(unsigned)(unsigned char)(fuel << (i1 & 31u)));
                h0 = (short)(unsigned)((unsigned)!((unsigned)((short)(unsigned)(p1 || a0[i0 & 3u]) > (signed char)u0) ^ p1) < p0);
                goto L4;
                q0 = &garr[(unsigned)(signed char)(~(unsigned)((int)u3 >= (int)9u) + ((unsigned)h0 | *mp)) & 7u];
            } while (i1++ < 4u && u2);
            if ((0xe337da46u - garr[i1 & 7u])) continue;
            if (p0) continue;
            if (((unsigned)w0 / ((unsigned)(short)(unsigned)(r0.y || u2) | 1u))) {
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(signed char)(unsigned)((int)0xce9749abu >= (int)((unsigned)(w0 >> 29) << (m0 & 31u))), (unsigned)((short)(unsigned)b0 > (signed char)0x80000000u), (unsigned)((short)0x62ffbbb1u > (signed char)(unsigned)(0xd6abeb67u || 0x10000u))); }
                if ((1u + fuel)) {
                    e0 = e0 * 0.5L + (long double)((unsigned)(8u || (unsigned)f0) & 1023u);
                } else {
                    *q0 += 0x33323627u;
                }
            } else {
                if ((0x475001a0u >> (0x64aa2a77u & 31u))) {
                    if ((p1 * (unsigned)((int)v0 < (int)p1))) break;
                    switch ((unsigned)b0 & 7u) {
                        case 6u: ;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((i1 ^ 0xac06f6f3u), (unsigned)(signed char)(unsigned)(8u && v0), (0x10000u % (((unsigned)w0 / ((unsigned)w0 | 1u)) | 1u))); }
                        q0 = &garr[-(unsigned)((short)((unsigned)h0 << (g0 & 31u)) > (signed char)(fuel & (garr[i1 & 7u] >> (*q0 & 31u)))) & 7u];
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((0x80000000u % (i2 | 1u)) || r0.y), p0, (unsigned)(short)(i2 * (unsigned)s0)); }
                        while (i1++ < 4u && (unsigned)(r0.y < p0)) { if (--fuel == 0u) goto done;
                            case 0u: ;
                            h0 = (short)(((unsigned)h0 * (unsigned)((unsigned)(w0 >> 29) || 0xffffffffu)) / ((a0[u1 & 3u] << ((unsigned)l0 & 31u)) | 1u));
                            case 4u: ;
                            s0 = (int)0x9f5f6e34u;
                            default: ;
                            u0 ^= ((unsigned)((short)(unsigned)(p1 == v0) > (signed char)i0) >> ((unsigned)x0 & 31u));
                        }
                    }
                    if (((unsigned)h1 & garr[i1 & 7u])) break;
                    *q0 += fuel;
                }
                u3 += (unsigned)((short)(unsigned)d0 > (signed char)(unsigned)((unsigned)d0 || g1));
                if ((r0.x - i0)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn1((garr[u2 & 7u] % (i1 | 1u)), (unsigned)(g0 || ((unsigned)e0 / (0x10000u | 1u))), ((unsigned)w0 / (p0 | 1u))); }
            }
            *mp = (unsigned)d0;
        }
        break; (void)(((unsigned)h0 ^ (2u & 0x54e4756au)));
        while (i1++ < 5u && 0x80000000u) { if (--fuel == 0u) goto done;
            if ((0xcfcf3b77u ^ garr[i1 & 7u])) break;
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(0x10000u, (unsigned)((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)w0) == 0u), garr[u2 & 7u]); }
                c1 = (signed char)(unsigned)((int)0xc630e4e8u >= (int)(unsigned)((unsigned)l0 < (unsigned)((int)0x7fffffffu >= (int)(m0 << (u2 & 31u)))));
                break; (void)(fuel);
            }
            u0 += ((v0 | garr[i1 & 7u]) & a0[i0 & 3u]);
            u2 = -(2u % ((unsigned)(4u < m0) | 1u));
            a0[(unsigned)f0 & 3u] = ((unsigned)c1 << ((unsigned)((int)(unsigned)(p1 || p1) < (int)(unsigned)x0) & 31u));
        }
        if (0x10000u) {
            r0.x = ((unsigned)(0x33da3d61u < p0) ^ (unsigned)(((unsigned)s1 - a0[u1 & 3u]) || i1));
            do { if (--fuel == 0u) goto done;
                break; (void)(*q0);
                w0 ^= (unsigned long long)(unsigned)s1 << ((unsigned)(7u || (unsigned)((short)(m0 ? 6u : v0) > (signed char)a0[u1 & 3u])) & 63u);
                if (((u3 / (r0.x | 1u)) - 0x950205abu)) break;
                *mp = -((unsigned)((unsigned)h0 || 0x12c425b1u) | i0);
                r0.y ^= (unsigned)((p2 / (g0 | 1u)) < (unsigned)((r0.y / (i0 | 1u)) == garr[u2 & 7u]));
                if ((0x80000000u & 9u)) break;
            } while (i1++ < 6u && (unsigned)(0x7f2c810bu && garr[u2 & 7u]));
            e0 = e0 * 0.5L + (long double)(((u1 & 0x10000u) + (i2 * m0)) & 1023u);
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)((unsigned)c1 ? 1u : p1), (unsigned)!((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)(x0 >> 70)) | 0x7ae1a3a4u), i2); }
            break; (void)((((unsigned)b0 + u2) ^ (unsigned)s1));
            *q0 += (unsigned)((int)((unsigned)(w0 >> 29) >> ((unsigned)((unsigned)c1 || (unsigned)!(0x7fffffffu ^ 0x7fffffffu)) & 31u)) >= (int)i1);
        }
        x0 = x0 * 0x100000001b3ull + 0xffffffffu;
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = (0x7fffffffu ^ 0x194add6du);
        if (i0) {
            break; (void)((unsigned)!(unsigned)(0x10000u == (unsigned)((int)v0 >= (int)m0)));
        }
        if ((unsigned)((int)*mp < (int)(unsigned)s0)) goto L4;
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)(unsigned)((short)0xffffffffu > (signed char)(unsigned)d0), (unsigned)((unsigned)(unsigned char)(unsigned)((int)(unsigned)s0 >= (int)0xbbc3e79au) || (unsigned)f0), (u1 >> (i0 & 31u))); }
        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)w0 ^ (unsigned)c1), (unsigned)l0, m0); }
    }
    garr[(p1 >> (*q0 & 31u)) & 7u] = 0xffffffffu;
    g0 = (unsigned)(short)(unsigned)(((unsigned)f0 % (3u | 1u)) || (p1 + 9u));
    if (u3 == 7u) return (8u + 0x10000u);
    while (i0++ < 5u && (unsigned)((int)*mp >= (int)garr[u2 & 7u])) { if (--fuel == 0u) goto done;
        if (((unsigned)h0 | (unsigned)s1)) break;
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (-(unsigned)(0x80000000u || 0xffffffffu)) {
            *q0 += 0x543a91beu;
            h1 = (unsigned short)(h1 + (0x80000000u | (-(unsigned)((unsigned)h0 || i2) + 0x80000000u)));
            g1 += (unsigned)((short)((unsigned)c1 + (i0 & i1)) > (signed char)(unsigned)(i0 == 0x7fffffffu));
            if ((garr[i1 & 7u] + fuel)) {
                while (i1++ < 6u && (unsigned)((int)garr[i1 & 7u] >= (int)0u)) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)0xffffffffu < (int)fuel), -(unsigned)((0x7fffffffu - p0) < 0x55e8a897u), i2); }
                    i2 = (unsigned)(((unsigned)(x0 >> 70) * (unsigned)b0) && (unsigned)((int)(unsigned)h1 < (int)(unsigned)c0)) & 15u;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((0x7fffffffu << (6u & 31u)), (unsigned)((unsigned)(i2 || (unsigned)l0) == *mp), (unsigned)(short)((unsigned)w0 % (u2 | 1u))); }
                    if ((garr[i1 & 7u] / (((unsigned)c0 | p0) | 1u))) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((0x31c35e45u / (((unsigned)s0 % (1u | 1u)) | 1u)), ((unsigned)c0 & p0), 0x10000u); }
                    x0 = x0 * 0x100000001b3ull + (((unsigned)s1 << (v0 & 31u)) ^ (unsigned)((int)0x10000u >= (int)i2));
                }
            }
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)(a0[i0 & 3u] == 0xf7026eddu) % (0x7fffffffu | 1u)));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)f0, (unsigned)(0x6e8c0014u || (unsigned)((unsigned)h1 || 3u)), fuel); }
                u2 = u2 * 0x9e3779b1u + (unsigned)((int)i0 >= (int)(unsigned)((unsigned)x0 == ((unsigned)((short)v0 > (signed char)(unsigned)s0) << (*mp & 31u))));
                u3 = 0xe89f95f8u;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)0x90d384d2u << (0u & 63u);
                    if ((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)(x0 >> 70))) break;
                    if (u3 == 7u) return ((3u & ((unsigned)x0 - a0[u1 & 3u])) >> (m0 & 31u));
                    if ((unsigned)(0x444c83beu == i1)) break;
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        goto L1;
                        h1 = (unsigned short)(h1 + (unsigned)!(unsigned)(((a0[i0 & 3u] % (m0 | 1u)) - (unsigned)l0) == 0xf05ae91au));
                        *q0 = ((unsigned)(u3 || 0x59cf2ad4u) << ((0x5932093du - -(unsigned)((unsigned)c1 == 8u)) & 31u));
                    }
                }
                c1 = (signed char)9u;
            }
        }
    }
    h1 = (unsigned short)(h1 + 2u);
    s0 = (int)(unsigned)(p2 || (unsigned)l0);
    if ((5u / (g0 | 1u))) goto L1;
    if ((g0 - p0)) {
        g1 += (unsigned)(short)(unsigned)((short)(unsigned)((unsigned)((unsigned)c1 && 0x80000000u) < (unsigned)s1) > (signed char)v0);
        u0 ^= -(unsigned)((int)0x80000000u >= (int)*mp);
        if (budget != 0u) { budget -= 1u; u1 = fn1(a0[i0 & 3u], (i1 >> (2u & 31u)), ((unsigned)s1 | (unsigned)l0)); }
        if (budget != 0u) { budget -= 1u; u3 = fn1(r0.y, ((unsigned)(w0 >> 29) << (((unsigned)w0 >> (u0 & 31u)) & 31u)), (0xd27da56fu | (unsigned)((int)(unsigned)c0 < (int)(unsigned)h1))); }
    } else {
        if ((fuel / (4u | 1u))) {
            if (~(p2 << (fuel & 31u))) {
                w0 ^= (unsigned long long)(unsigned)c0 << ((unsigned)(short)(unsigned)((int)(unsigned)d0 >= (int)(unsigned)(short)(unsigned)((0xff5f965cu ^ 0xffffffffu) < (unsigned)c0)) & 63u);
            }
            q0 = &garr[((3u * i1) ^ (9u / (fuel | 1u))) & 7u];
            r0.x = (0x7fffffffu ? p2 : garr[u2 & 7u]);
            { unsigned t1; double z1; if (((0x10000u | (a0[i0 & 3u] - (unsigned)f0))) & 1u) { t1 = 1u; z1 = (double)(((unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x7fffffffu)) & 255u); } if (((0x10000u | (a0[i0 & 3u] - (unsigned)f0))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                g1 += (unsigned)(r0.x || ((unsigned)(3u == (unsigned)(w0 >> 29)) * (r0.y * 0xffffffffu)));
                if (budget != 0u) { budget -= 1u; u2 = fn1(p0, (unsigned)l0, p2); }
                u3 = u3 * 0x9e3779b1u + (r0.x * (unsigned)f0);
                goto done;
            }
            while (i0++ < 3u && (unsigned)(0x24d8bcc7u < (unsigned)(u2 || g0))) { if (--fuel == 0u) goto done;
                i1 = (unsigned)((int)((unsigned)(a0[i0 & 3u] < 1u) - (unsigned)((int)i2 >= (int)1u)) < (int)u0) & 15u;
                e0 = e0 * 0.5L + (long double)(v0 & 1023u);
                if ((unsigned)((short)(unsigned)f0 > (signed char)p1)) continue;
            }
            { unsigned t2; double z2; if ((~((0xadb6cfe3u % (0xcdcf7933u | 1u)) / (i2 | 1u))) & 1u) { t2 = (unsigned)((p1 + (unsigned)x0) || (unsigned)c0); z2 = (double)((0x80000000u) & 255u); } if ((~((0xadb6cfe3u % (0xcdcf7933u | 1u)) / (i2 | 1u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                m0 ^= *q0;
                if ((*mp >> (3u & 31u))) goto L4;
                while (i0++ < 4u && ((unsigned)f0 % ((unsigned)(x0 >> 70) | 1u))) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)(short)((unsigned)e0 & (unsigned)((int)(unsigned)h1 < (int)p0));
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)(unsigned)((int)p2 < (int)v0) < (int)u2), ((unsigned)(x0 >> 70) & (unsigned)d0), (0xb4872d11u & (unsigned)w0)); }
                }
                x0 = x0 * 0x100000001b3ull + 0x10000u;
                if ((i0 ? 6u : i0)) goto L0;
                if (u1) goto L4;
            }
        }
        while (i0++ < 7u && (unsigned)(3u < (unsigned)((short)(unsigned)h1 > (signed char)a0[u1 & 3u]))) { if (--fuel == 0u) goto done;
            c1 = (signed char)(0u * (unsigned)d0);
            l0 = (long)((unsigned long)l0 + (unsigned)f0);
            w0 = w0 * 6364136223846793005ull + (unsigned)(r0.x && (unsigned)((0xb1a58e87u & 0x80000000u) && (u3 & 0x7fffffffu)));
            a0[(i2 / (p0 | 1u)) & 3u] = (unsigned)((unsigned)h0 || p0);
            if (p2) break;
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch (fuel & 7u) {
                    switch (((unsigned)h1 & (unsigned)x0) & 7u) {
                        case 7u: ;
                        case 1u: ;
                        *q0 = (p2 * ((unsigned)((unsigned)w0 == u2) + (unsigned)w0));
                        a0[g0 & 3u] = (unsigned)((0xe80f4e6du ^ (unsigned)((int)(unsigned)(w0 >> 29) >= (int)g0)) || 0x7fffffffu);
                    }
                    if (fuel < 8u) return (((unsigned)s1 >> (0x7fffffffu & 31u)) + (unsigned)((unsigned)h0 || (unsigned)((unsigned)h0 && v0)));
                    h0 = (short)((unsigned)s1 << (i1 & 31u));
                }
                h1 = (unsigned short)(h1 + -((unsigned)(((unsigned)h0 ^ u2) < (unsigned)h0) << (p0 & 31u)));
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)!(0x59dd23a4u ^ *mp), 0xdbfdf45fu, ((0xffffffffu + 3u) % (u1 | 1u))); }
                m0 ^= (unsigned)((int)(unsigned)(garr[u2 & 7u] || (unsigned)((int)u3 < (int)a0[u1 & 3u])) < (int)0x2a293377u);
            }
        }
        h1 = (unsigned short)(h1 + 0u);
        goto L0;
    }
    switch (v0 & 7u) {
        c0 = (unsigned char)(unsigned)(short)(unsigned)((short)u1 > (signed char)(unsigned)((unsigned)s0 == (0x10da2d27u - (g0 / (0x8b620f09u | 1u)))));
    }
    if (g1) goto done;
    goto L0;
    if ((unsigned)s0) goto L0;
    s1 = (int)((unsigned)s1 + (p2 >> ((u2 << (*mp & 31u)) & 31u)));
    if (0xffffffffu) {
        switch ((unsigned)!((0xdd04ebbau % (u1 | 1u)) ^ 0x3a54ebb2u) & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn0((0x79a30fbcu / (0xdb760653u | 1u)), ((unsigned)w0 ^ 2u), (unsigned)((unsigned)(u0 == 2u) || 8u)); }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(garr[u2 & 7u], (unsigned)((int)(unsigned)d0 >= (int)(unsigned)c0), (p0 >> ((unsigned)f0 & 31u))); }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((garr[u2 & 7u] + 0xf2e3b171u), (unsigned)f0, ((unsigned)w0 & v0)); }
    if (((unsigned)((int)(unsigned)(w0 >> 29) >= (int)p2) & v0)) goto done;
    if ((p0 / (p0 | 1u))) {
        h1 = (unsigned short)(h1 + 0u);
        b0 = (unsigned)((short)v0 > (signed char)((unsigned)(signed char)(0xfe31e6e3u ? garr[u2 & 7u] : 0x7802c8abu) + 1u)) != 0u;
    }
    if (((unsigned)l0 & 0xc92a7440u)) goto L2;
    *q0 += (unsigned)(unsigned char)((garr[i1 & 7u] ? (unsigned)c0 : g1) >> (u0 & 31u));
    a0[(garr[u2 & 7u] + (unsigned)(w0 >> 29)) & 3u] = (unsigned)c1;
    if ((((unsigned)x0 - (unsigned)s0) << ((unsigned)l0 & 31u))) {
        switch ((unsigned)s0 & 7u) {
            while (i0++ < 2u && i0) { if (--fuel == 0u) goto done;
                case 0u: ;
            }
        }
        q0 = &garr[(unsigned)(short)(((i2 ? fuel : 0u) ^ (unsigned)w0) - p2) & 7u];
        w0 = w0 * 6364136223846793005ull + (0x7fffffffu << (5u & 31u));
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0(((u1 * r0.x) + garr[u2 & 7u]), (fuel >> ((unsigned)((int)g1 >= (int)0xffffffffu) & 31u)), a0[u1 & 3u]); }
        l0 = (long)((unsigned long)l0 + (unsigned)c0);
        break; (void)((unsigned)(p0 < (garr[i1 & 7u] | i1)));
        u2 = u2 * 0x9e3779b1u + (unsigned)s1;
    } while (i0++ < 2u && (a0[u1 & 3u] - 0x962ecf8du));
    do { if (--fuel == 0u) goto done;
        if (0x76c22e6eu) {
            u0 ^= ((unsigned)s0 + (garr[u2 & 7u] ^ (unsigned)c1));
            if (budget != 0u) { budget -= 1u; u0 = fn1(-(unsigned)((6u >> (0xffffffffu & 31u)) || (unsigned)h1), (0x5849a563u / ((unsigned)h1 | 1u)), (unsigned)(*q0 < ((unsigned)(w0 >> 29) + p1))); }
            break; (void)((0x65cae55bu % ((unsigned)(x0 >> 70) | 1u)));
            if (3u) continue;
            if ((unsigned)((short)0x80000000u > (signed char)(unsigned)((unsigned)s1 && m0))) break;
        } else {
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)(i0 >> (a0[u1 & 3u] & 31u)) < (int)((unsigned)h0 ^ 0x69ceb9bbu));
            r0.x = (((unsigned)s1 ^ (unsigned)l0) * m0);
        }
        *q0 = ((unsigned)x0 - r0.x);
        a0[((unsigned)x0 - 1u) & 3u] = ((unsigned)c0 & (unsigned)!((unsigned)h1 * m0));
        i2 = (unsigned)c0 & 15u;
    } while (i0++ < 7u && (unsigned)(p2 == 0x47f1ee76u));
    if (r0.y) {
        if ((unsigned)(g1 && u1)) goto L4;
        while (i0++ < 2u && ((unsigned)((int)a0[i0 & 3u] < (int)u1) / (0x40945017u | 1u))) { if (--fuel == 0u) goto done;
            u0 = u0 * 0x9e3779b1u + (((unsigned)((unsigned)e0 && 0x10000u) * (unsigned)(u3 == (unsigned)e0)) % (u1 | 1u));
            if (g1) break;
            if (0x984c52f6u) {
                if (budget != 0u) { budget -= 1u; u2 = fn1(~(4u * (unsigned)s0), (unsigned)c1, (unsigned)c0); }
                if ((unsigned)(signed char)(unsigned)((0x10000u | (unsigned)c0) || *q0)) {
                    if (budget != 0u) { budget -= 1u; u3 = fn1((i1 ^ (unsigned)x0), (unsigned)!(unsigned)((unsigned)f0 < 0x10000u), (unsigned)(0xb319b99au && (r0.x ^ 0x914c2561u))); }
                    if ((unsigned)s1) break;
                    break; (void)((0xd9baf5a7u % ((2u >> ((unsigned)d0 & 31u)) | 1u)));
                } else {
                    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((int)g1 >= (int)i0) & 5u), ((unsigned)c0 & 0x7fffffffu), (m0 ? u1 : 6u)); }
                    if ((unsigned)((int)a0[u1 & 3u] >= (int)0xa14dd3b2u)) break;
                }
                l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(w0 >> 29) == (v0 ^ 7u)));
            } else {
                u0 += ((unsigned)(g0 || (unsigned)f0) * ((unsigned)(w0 >> 29) % (g0 | 1u)));
                l0 = (long)((unsigned long)l0 + (unsigned)(w0 >> 29));
                m0 ^= g0;
                if ((unsigned)(x0 >> 70)) break;
            }
            *q0 = (unsigned)(((unsigned)h0 << (0xd96740f2u & 31u)) < u3);
            if ((0x9076ba8eu + g0)) goto L2;
        }
        if (garr[u2 & 7u]) {
            if (fuel < 8u) return (unsigned)!(unsigned)(((r0.y - g1) ? (unsigned)b0 : m0) || g1);
            if (budget != 0u) { budget -= 1u; u0 = fn1((7u / (g1 | 1u)), (i1 % ((*q0 + garr[u2 & 7u]) | 1u)), ~(p2 * g0)); }
            if (fuel < 8u) return 3u;
            u3 ^= (unsigned)((short)garr[i1 & 7u] > (signed char)(p1 % ((unsigned)w0 | 1u)));
        } else {
            if ((unsigned)c1) goto L2;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1(((*mp - 0x134408c6u) ^ 0xd7c6cbd0u), (unsigned)s0, (unsigned)((unsigned)h1 || (unsigned)(signed char)(0x10000u | (unsigned)c1))); }
    }
    g0 = (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(0xffffffffu * (unsigned)b0));
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (-(unsigned)((int)1u < (int)((unsigned)f0 - r0.x))) goto L4;
        g0 = (unsigned)((int)((p0 & *q0) << (i0 & 31u)) < (int)m0);
        c1 = (signed char)6u;
        if (budget != 0u) { budget -= 1u; u2 = fn0((0x6856452fu - ((unsigned)w0 | (unsigned)x0)), (unsigned)(0xb6965797u == (garr[u2 & 7u] + i2)), (unsigned)((int)0x2d5c05c3u >= (int)(unsigned)h0)); }
        goto L2;
    }
    if (((unsigned)(g1 == (unsigned)h1) * u1)) goto L1;
    c0 = (unsigned char)(unsigned)((int)((u2 >> (p1 & 31u)) << (0x9e9c5a33u & 31u)) < (int)(p1 & 0xebc0b553u));
    h1 = (unsigned short)(h1 + a0[i0 & 3u]);
    if ((unsigned)(w0 >> 29)) goto L1;
    goto done;
    d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((int)(unsigned)w0 < (int)0xffffffffu) == 0x37f58641u) & 1023u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)f0 || i2), (((unsigned)s1 >> (*q0 & 31u)) | 0xe097808bu), (unsigned)((unsigned)(p2 && (unsigned)e0) && 0x3fc4dbb5u)); }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(u3 | (unsigned)(0x5398aae1u == 0u));
        L0: if (--fuel == 0u) goto done;
    }
    L1: if (--fuel == 0u) goto done;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)c0, (i1 >> (0x3300e5beu & 31u)), (unsigned)(6u == (unsigned)w0)); }
        while ((garr[u2 & 7u] | 0x58a217bdu)) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)l0);
            break; (void)((unsigned)(short)(unsigned)((int)(unsigned)x0 >= (int)fuel));
            L2: if (--fuel == 0u) goto done;
        }
        *mp = ~(g0 * (unsigned)c1);
        *q0 = (unsigned)!(unsigned)(((unsigned)w0 << (i0 & 31u)) == (unsigned)(a0[u1 & 3u] || (unsigned)s0));
        x0 = x0 * 0x100000001b3ull + (0x216e7491u & (*mp - (unsigned)h1));
    } while (i0++ < 2u && (1u + (unsigned)!(unsigned)(0xa86dc4fu < 8u)));
    if (v0) goto L0;
    do { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((0x10000u ? 0x7fffffffu : 0x189f24b1u) & 255u);
        if ((unsigned)((unsigned)h0 || ((unsigned)w0 & 0x159be775u))) continue;
        switch ((m0 & r0.y) & 7u) {
            v0 = ~((*q0 * (u0 << ((unsigned)s1 & 31u))) ^ u3);
            garr[0x7fffffffu & 7u] = (unsigned)((int)(i0 << ((6u ^ ((unsigned)w0 ^ (unsigned)c1)) & 31u)) < (int)garr[i1 & 7u]);
            { unsigned t0; double z0; if ((u1) & 1u) { t0 = (unsigned)(signed char)(unsigned)((short)v0 > (signed char)(unsigned)((short)i1 > (signed char)0x80000000u)); z0 = (double)(((unsigned)(signed char)((unsigned)e0 << ((unsigned)c0 & 31u))) & 255u); } if ((u1) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                if (u3 == 7u) return (((unsigned)w0 % ((unsigned)c1 | 1u)) ? (unsigned)f0 : fuel);
            }
            *q0 += (-(unsigned)(0xe79753f9u || p1) - 0x10000u);
            case 1u: ;
        }
        if ((9u % (0xcd9e12a4u | 1u))) {
            { unsigned t1; double z1; if (((u1 ^ a0[u1 & 3u])) & 1u) { t1 = (unsigned)(~(unsigned)((short)m0 > (signed char)(unsigned)(x0 >> 70)) == u2); z1 = (double)((7u) & 255u); } if (((u1 ^ a0[u1 & 3u])) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                l0 = (long)((unsigned long)l0 + (unsigned)((g1 ^ a0[i0 & 3u]) && (*mp >> ((unsigned)!(a0[i0 & 3u] / (0x4a71938cu | 1u)) & 31u))));
                *q0 += ((unsigned)(m0 && (unsigned)x0) / (((unsigned)e0 * g0) | 1u));
                break; (void)((unsigned)h0);
                L3: if (--fuel == 0u) goto done;
                s0 = (int)(fuel - (unsigned)(3u == -((u2 ^ 0xd81dd848u) >> (0x7fffffffu & 31u))));
            }
            L4: if (--fuel == 0u) goto done;
            u3 = u3 * 0x9e3779b1u + (unsigned)((garr[u2 & 7u] | 0xbad04bddu) < (unsigned)((short)u3 > (signed char)*q0));
            h1 = (unsigned short)(h1 + (unsigned)d0);
            if ((unsigned)(x0 >> 70)) break;
        }
        if (((unsigned)f0 & a0[u1 & 3u])) goto L2;
        goto L1;
    } while (i0++ < 2u && (unsigned)(u1 == (unsigned)c1));
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 6u && ((unsigned)(*q0 && (unsigned)e0) % (r0.x | 1u))) { if (--fuel == 0u) goto done;
            if (((unsigned)(x0 >> 70) ^ (unsigned)f0)) break;
            do { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)((int)fuel >= (int)(unsigned)w0) < (int)(unsigned)(x0 >> 70)) & 1023u);
                break; (void)((unsigned)(0x1c454129u == 2u));
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((unsigned)s0 || 2u) < (0u >> (6u & 31u))) & 255u);
                if ((unsigned)(r0.y == 9u)) break;
                if ((u0 & v0)) break;
            } while (i2++ < 6u && u3);
        }
        if (((unsigned)((short)(unsigned)c1 > (signed char)p1) ^ i2)) {
            if (1u) break;
            if (budget != 0u) { budget -= 1u; u0 = fn0(i2, (0xe39f79a3u >> ((unsigned)w0 & 31u)), (unsigned)((unsigned)((int)(unsigned)w0 >= (int)(unsigned)f0) && 0x80000000u)); }
            c0 = (unsigned char)r0.y;
        } else {
            e0 = e0 * 0.5L + (long double)(g1 & 1023u);
            if ((*mp + (unsigned)((unsigned)b0 || a0[i0 & 3u]))) break;
            h1 = (unsigned short)(h1 + 0x10000u);
            if ((unsigned)(signed char)(*mp * garr[u2 & 7u])) break;
        }
        garr[fuel & 7u] = ((4u / (0x72b61e45u | 1u)) / ((-((unsigned)(x0 >> 70) | 2u) | i0) | 1u));
        break; (void)(0x80000000u);
        s0 = (int)(unsigned)(short)(unsigned)((int)v0 >= (int)g0);
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)((short)g0 > (signed char)(unsigned)c1) < 0xd569d891u)) goto L4;
            continue; (void)((unsigned)(u3 < p1));
            if ((unsigned)((int)4u >= (int)0x9dd6009eu)) break;
            garr[(unsigned)d0 & 7u] = 0xe6c153acu;
            i2 = ((unsigned)((unsigned)l0 && 0x7d937fa4u) * ((unsigned)b0 ? 0x64da5744u : 0x8453a3afu)) & 15u;
        }
    }
    goto L0;
    if ((unsigned)(v0 || 8u)) {
        if ((unsigned)w0) goto L0;
        goto L2;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn2((a0[u1 & 3u] / (u1 | 1u)), ((unsigned)!(fuel << (0xc8f7d2bcu & 31u)) & 0x10000u), (unsigned)c1); }
    if ((unsigned)((int)*mp >= (int)r0.x)) goto L2;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (~(u3 & (fuel >> ((unsigned)x0 & 31u))) << ((unsigned)((unsigned)x0 && (unsigned)x0) & 31u)));
        r0.y ^= (fuel ? v0 : (unsigned)((int)0xffffffffu < (int)0x3ca9f971u));
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = (g0 | u2);
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)!(m0 ^ a0[i0 & 3u]), (unsigned)s1, ((p1 + i1) | p0)); }
        u2 = (((0x896f2967u << ((unsigned)c0 & 31u)) + 0x7fffffffu) << ((unsigned)e0 & 31u));
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.x = (unsigned)(unsigned char)((0xb9acf4c7u ? 0xb4d5d8dbu : (unsigned)(w0 >> 29)) + (*mp + g1));
        }
        if (fuel) break;
    }
    a0[(unsigned)w0 & 3u] = p1;
    f0 = f0 * 0.5f + (float)(u1 & 255u);
    if ((u3 << (v0 & 31u))) {
        if ((u0 ? (unsigned)w0 : 0x536c619du)) goto L3;
    }
    switch ((unsigned)(x0 >> 70) & 7u) {
        if (fuel < 8u) return (unsigned)((unsigned)h0 < ((unsigned)h0 - ((unsigned)s0 * u0)));
        h1 = (unsigned short)(h1 + (unsigned)((unsigned)c0 || 0x80000000u));
        f0 = f0 * 0.5f + (float)((0xffffffffu + ((unsigned)e0 ? garr[i1 & 7u] : (unsigned)((int)(unsigned)b0 < (int)(unsigned)s1))) & 255u);
        break; (void)(fuel);
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 3u && (unsigned)(0x80000000u || g1)) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)l0 & (unsigned)e0), (a0[i0 & 3u] * garr[i1 & 7u]), p2); }
                    case 2u: ;
                    s1 = (int)((unsigned)s1 + ((unsigned)(u2 || 0x6b670d28u) ^ (unsigned)(0u < (unsigned)(0xc684b9b1u || 0x19d99fd3u))));
                    if ((unsigned)h0) goto L2;
                    *q0 = (unsigned)(unsigned char)(unsigned)(0x190e2ed7u || (unsigned)(g0 < (unsigned)((short)(m0 % (0xffffffffu | 1u)) > (signed char)i1)));
                    g0 = ((unsigned)(*q0 == (i1 / (fuel | 1u))) & 0x2fa3a19bu);
                }
                case 7u: ;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    a0[5u & 3u] = ~(a0[i0 & 3u] >> (*mp & 31u));
                    break; (void)((*mp | p0));
                    g0 = (unsigned)(signed char)((unsigned)((int)r0.y < (int)(unsigned)(short)(unsigned)((int)u2 < (int)0xffffffffu)) / (u1 | 1u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)s1 | (unsigned)c0), 0x7fffffffu, (p1 - (unsigned)x0)); }
                    case 4u: ;
                    do { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)((unsigned)s1 * u2);
                        g0 = (unsigned)((short)(5u << ((unsigned)f0 & 31u)) > (signed char)garr[u2 & 7u]);
                        b0 = (p2 ^ (unsigned)b0) != 0u;
                        i2 = ((unsigned)(x0 >> 70) / (0x7fffffffu | 1u)) & 15u;
                        d0 = d0 * 0.5 + (double)((a0[u1 & 3u] >> ((unsigned)x0 & 31u)) & 1023u);
                        c1 = (signed char)(((unsigned)w0 ^ i1) >> (0x10000u & 31u));
                    } while (i0++ < 3u && 0x727440a7u);
                }
            }
            a0[a0[u1 & 3u] & 3u] = u1;
            l0 = (long)((unsigned long)l0 + ((a0[i0 & 3u] / (((unsigned)s1 + g1) | 1u)) & ((unsigned)x0 ^ p2)));
            q0 = &garr[((p1 & ((unsigned)c1 + (unsigned)h1)) - ((unsigned)x0 | 0xfe2c8e1au)) & 7u];
            if ((0x80000000u * (unsigned)e0)) break;
        }
    }
    i0 = (((unsigned)((int)(unsigned)h1 < (int)(g0 + r0.y)) | (unsigned)d0) >> ((unsigned)h0 & 31u)) & 15u;
    if (budget != 0u) { budget -= 1u; u3 = fn0(u2, 6u, r0.y); }
    if ((unsigned)(short)((unsigned)(7u || 0x80000000u) * 3u)) goto L0;
    u1 = u1 * 0x9e3779b1u + r0.y;
    if (0x10000u) goto done;
    goto done;
    if (*mp) {
        switch (0x80000000u & 7u) {
            u3 ^= (g0 << ((unsigned)((int)2u >= (int)u3) & 31u));
        }
        c0 = (unsigned char)(unsigned)(0x81990bb6u && (((unsigned)f0 % (g0 | 1u)) + (unsigned)((int)(unsigned)s1 >= (int)a0[u1 & 3u])));
        w0 = w0 * 6364136223846793005ull + ~(unsigned)((unsigned)(a0[u1 & 3u] && (unsigned)(w0 >> 29)) && 0x9f02dcbdu);
        garr[0x7fffffffu & 7u] = (unsigned)((int)(a0[i0 & 3u] - *q0) < (int)(unsigned)(signed char)(i0 - (unsigned)((int)(unsigned)(x0 >> 70) < (int)0xd21c80d5u)));
    }
    garr[(unsigned)(w0 >> 29) & 7u] = (u2 * ((i2 + 0xb54f4244u) + 0x46334546u));
    f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)(v0 && 0u) < (int)((unsigned)b0 | *q0)) & 255u);
    goto L4;
    switch (((unsigned)d0 ? (unsigned)d0 : 5u) & 7u) {
        case 7u: ;
        while ((unsigned)((unsigned)h0 == (unsigned)s1)) { if (--fuel == 0u) goto done;
            u2 = u2 * 0x9e3779b1u + (unsigned)s1;
            default: ;
        }
        i0 = ((0u - p0) * (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)s0)) & 15u;
        break; (void)(3u);
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)*mp > (signed char)0x10000u), (unsigned)(*q0 || v0), (unsigned)!(unsigned)((unsigned)x0 == (0x10000u - garr[i1 & 7u]))); }
    if (fuel < 8u) return (v0 & (unsigned)((int)(unsigned)x0 < (int)0xffffffffu));
    h0 = (short)(unsigned)((int)(unsigned)c1 >= (int)(unsigned)(0x8d935046u == (p0 | 0xf99f4d14u)));
    w0 ^= (unsigned long long)~(unsigned)((short)3u > (signed char)4u) << ((g0 / ((g0 / ((unsigned)s1 | 1u)) | 1u)) & 63u);
    if (v0) goto done;
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (0x7fffffffu) break;
        }
    } while (i0++ < 4u && 6u);
    if ((unsigned)(unsigned char)(unsigned)(0xff3126feu && (unsigned)((int)(unsigned)h1 < (int)(unsigned)d0))) {
        if ((unsigned)((int)0x80000000u < (int)u0)) goto L3;
        if ((unsigned)((unsigned)s0 == g1)) goto L4;
        if (p1) goto L0;
    }
    if (((p1 << (0xe4e8487cu & 31u)) % (r0.y | 1u))) goto done;
    q0 = &garr[~(unsigned)(a0[u1 & 3u] == (((unsigned)d0 % ((unsigned)(unsigned char)(unsigned)((int)u0 < (int)i2) | 1u)) * *q0)) & 7u];
    if (a0[i0 & 3u]) goto L3;
    if ((u2 - (unsigned)(g0 < (unsigned)b0))) goto done;
    u3 = u3 * 0x9e3779b1u + ((unsigned)h1 << ((unsigned)d0 & 31u));
    if (((unsigned)x0 << (i1 & 31u))) goto L4;
    c1 = (signed char)(unsigned)(p1 || (0u << (0xc66e5851u & 31u)));
    if (p1) {
        a0[0xb7b440b1u & 3u] = ~(garr[i1 & 7u] + (unsigned)c1);
        r0.y ^= (unsigned)(0x2cf933d4u < p2);
        m0 ^= (unsigned)((unsigned)((int)p2 < (int)0x10000u) || (unsigned)(signed char)(0xe9908ab6u << ((unsigned)f0 & 31u)));
        if (p1) goto L2;
        if ((unsigned)((int)0x80000000u < (int)(unsigned)h1)) {
            goto L2;
            u2 = garr[i1 & 7u];
            h1 = (unsigned short)(h1 + (unsigned)c1);
        }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((g0 & (g1 + (unsigned)(w0 >> 29))), (unsigned)(w0 >> 29), (unsigned)((unsigned)h1 || garr[i1 & 7u])); }
    e0 = e0 * 0.5L + (long double)((unsigned)((int)r0.y >= (int)(unsigned)(short)(0x7fffffffu | 2u)) & 1023u);
    goto L3;
    *q0 += (unsigned)(0xfdc833d6u < (0x9348e336u / (garr[u2 & 7u] | 1u)));
    goto L1;
    h1 = (unsigned short)(h1 + ((unsigned)c0 & i0));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (((3u & g0) >> (u3 & 31u))) goto L4;
    while (i0++ < 2u && 0x5e69626fu) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)fuel << ((i0 & (garr[i1 & 7u] | 0xffffffffu)) & 63u);
        b0 = (*mp * (i1 | (unsigned)l0)) != 0u;
        d0 = d0 * 0.5 + (double)(*q0 & 1023u);
    }
    q0 = &garr[(*q0 << (0x7fffffffu & 31u)) & 7u];
    if ((m0 - u3)) goto L0;
    s1 = (int)((unsigned)s1 + fuel);
    do { if (--fuel == 0u) goto done;
        switch (garr[u2 & 7u] & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)(0x10000u < (unsigned)x0), 0x7fffffffu, a0[u1 & 3u]); }
            v0 = i1;
            if ((unsigned)h0) {
                case 4u: ;
                break; (void)((u1 * i1));
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)((unsigned)(x0 >> 70) ^ (unsigned)b0) > (signed char)i0), (unsigned)c0, (unsigned)(0xffffffffu < (unsigned)h1)); }
                if (budget != 0u) { budget -= 1u; u3 = fn2((3u - (0x9fa80d4bu << ((unsigned)l0 & 31u))), 0x10000u, (a0[u1 & 3u] << (4u & 31u))); }
            }
            if ((unsigned)((short)((unsigned)c0 | 2u) > (signed char)0x7fffffffu)) goto L4;
            *q0 = (unsigned)(unsigned char)(unsigned)(u3 && ~((unsigned)s1 ^ (unsigned)s1));
            if (((*mp * 0xb2a831f4u) ^ 0xffffffffu)) goto done;
        }
        *q0 += (unsigned)((int)(((unsigned)h1 / (u2 | 1u)) * (unsigned)(0x4319ef45u && 5u)) >= (int)(unsigned)h1);
        while (i1++ < 4u && (0xec48a1a3u ? fuel : g1)) { if (--fuel == 0u) goto done;
            if (0xed546692u) {
                a0[(unsigned)f0 & 3u] = (~((unsigned)f0 | ~(unsigned)(u2 && 0xffffffffu)) % ((unsigned)c1 | 1u));
                if (fuel < 8u) return (0x3ddceb6fu * r0.y);
                e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)h0 >= (int)0xeb95d3e4u) & 1023u);
                if ((unsigned)b0) continue;
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(short)(3u << ((unsigned)l0 & 31u)) < (unsigned)((short)0xa32e11e8u > (signed char)u3)) & 255u);
                d0 = d0 * 0.5 + (double)((v0 ^ (unsigned)((unsigned)d0 == 0xf200470fu)) & 1023u);
            } else {
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((unsigned)h1 == (unsigned)c0), r0.y, (unsigned)((int)(u1 * 0xff467a99u) < (int)(unsigned)c1)); }
                if (budget != 0u) { budget -= 1u; u3 = fn1((0x80000000u % (((unsigned)f0 | p0) | 1u)), ((unsigned)(u0 && u2) | (unsigned)s1), (unsigned)s1); }
                if (budget != 0u) { budget -= 1u; u0 = fn3(-(unsigned)((int)0x10000u >= (int)(unsigned)((int)a0[u1 & 3u] >= (int)0u)), (unsigned)((int)(unsigned)h1 < (int)(unsigned)l0), (unsigned)f0); }
                r0.x = ((unsigned)((unsigned)e0 || p1) << (u1 & 31u));
            }
            L0: if (--fuel == 0u) goto done;
            break; (void)((unsigned)(r0.y == (unsigned)((short)i0 > (signed char)9u)));
            v0 = ((unsigned)((unsigned)(w0 >> 29) == 0x10000u) ^ v0);
            { unsigned t0; double z0; if (((unsigned)!((p1 << ((unsigned)e0 & 31u)) - v0)) & 1u) { t0 = a0[i0 & 3u]; z0 = (double)((r0.x) & 255u); } if (((unsigned)!((p1 << ((unsigned)e0 & 31u)) - v0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                continue; (void)(((0x10000u << (u3 & 31u)) & a0[u1 & 3u]));
            }
        }
        if (0x62ea38f1u) break;
    } while (i0++ < 2u && (garr[i1 & 7u] << ((unsigned)((int)i1 < (int)i2) & 31u)));
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)((short)((unsigned)b0 - (garr[i1 & 7u] * (unsigned)f0)) > (signed char)(unsigned)((int)i0 >= (int)u1));
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)f0, ((unsigned)e0 ^ (unsigned)h1), v0); }
            *mp = ((unsigned)((int)(unsigned)l0 < (int)9u) + (unsigned)((unsigned)e0 && p1));
        }
        if (((g0 % (0u | 1u)) % (0x7fffffffu | 1u))) break;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(-(0x80000000u | ((unsigned)s0 | 4u)));
            break; (void)((0x80000000u << (u3 & 31u)));
            if ((unsigned)(signed char)((unsigned)(r0.y == g0) + 8u)) continue;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(u1 || 0x4b3771c2u), (unsigned)((int)(unsigned)e0 < (int)((unsigned)d0 >> (i1 & 31u))), (unsigned)((unsigned)h0 && ((unsigned)x0 + u0))); }
        }
        if ((unsigned)((short)(unsigned)h1 > (signed char)(0xffffffffu % (r0.y | 1u)))) continue;
    }
    if ((unsigned)!((v0 + 0x80000000u) / (0xfa4fd24fu | 1u))) {
        if ((unsigned)((int)0xbbe2e319u >= (int)p2)) goto L2;
        g0 = u1;
        switch ((unsigned)((int)(unsigned)x0 >= (int)i0) & 7u) {
            if ((garr[u2 & 7u] >> (r0.x & 31u))) {
                if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)(((unsigned)h1 % (0x7fffffffu | 1u)) < (unsigned)s1), (unsigned)((short)0x94a63348u > (signed char)(unsigned)l0), (*q0 >> (p2 & 31u))); }
                case 7u: ;
            } else {
                L1: if (--fuel == 0u) goto done;
            }
            if (8u) goto L1;
            a0[((unsigned)f0 / (0x31dcfdb1u | 1u)) & 3u] = (5u ^ 0x375bfa87u);
            case 1u: ;
        }
        *q0 += (((g1 | (unsigned)x0) * 2u) ^ (unsigned)((int)0xa14cec10u >= (int)0x80000000u));
    }
    if ((p1 + (1u - 0xffffffffu))) goto L2;
    L2: if (--fuel == 0u) goto done;
    if (((unsigned)(signed char)(unsigned)(i0 == 0xffffffffu) | 0x18013f5au)) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 = r0.y;
            L3: if (--fuel == 0u) goto done;
            *q0 += (unsigned)(9u && 0x1b91067fu);
            f0 = f0 * 0.5f + (float)(~((m0 & 0xffffffffu) ^ (v0 + (unsigned)((int)m0 < (int)0x5dffe794u))) & 255u);
            c0 = (unsigned char)(unsigned)((short)1u > (signed char)~(9u / ((unsigned)((unsigned)(unsigned char)(unsigned)((int)9u >= (int)i1) == 0xffffffffu) | 1u)));
            if ((unsigned)((int)0x80000000u < (int)(unsigned)f0)) continue;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn2((g0 * (unsigned)h0), (unsigned)((unsigned)(short)(unsigned)(fuel < 0xf01e0605u) && (unsigned)x0), 0x80000000u); }
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 += (u1 * (unsigned)((short)(unsigned)s0 > (signed char)(unsigned)x0));
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)l0 < (unsigned)(g1 || p0)), (unsigned)(x0 >> 70), (unsigned)(unsigned char)(unsigned)((unsigned)((short)(unsigned)l0 > (signed char)0xee73644au) && 2u)); }
        L4: if (--fuel == 0u) goto done;
        g0 = (unsigned)(signed char)(unsigned)((unsigned)(short)((unsigned)w0 + (unsigned)((int)(unsigned)x0 < (int)5u)) == (unsigned)!(unsigned)((unsigned)d0 == 4u));
    }
    v0 = u2;
    d0 = d0 * 0.5 + (double)(((unsigned)((int)(unsigned)(short)(i0 >> (0x80000000u & 31u)) >= (int)0x80000000u) | (unsigned)(0x7fffffffu || (unsigned)s0)) & 1023u);
    v0 = ((unsigned)((u0 % (((unsigned)(w0 >> 29) | 0xffffffffu) | 1u)) < (unsigned)s0) << ((unsigned)l0 & 31u));
    *mp = (unsigned)((unsigned)((p0 & i1) && (unsigned)((int)0x63638779u < (int)0x80000000u)) || 0xa86529cdu);
    if ((g0 % (i0 | 1u))) {
        c1 = (signed char)(unsigned)c1;
        c0 = (unsigned char)((u2 & u3) % ((8u ? 0x2c1dfc79u : (unsigned)e0) | 1u));
        if ((unsigned)!(a0[i0 & 3u] >> (0x7961dc2du & 31u))) goto L1;
        if ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)((unsigned)l0 < (unsigned)s0))) goto L3;
        for (;;) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (-(unsigned)(m0 && *q0)) goto L0;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!((unsigned)((unsigned)c0 == u3) << (fuel & 31u)), (garr[u2 & 7u] / ((unsigned)(x0 >> 70) | 1u)), (unsigned)((int)g0 >= (int)(unsigned)f0)); }
                while (i2++ < 4u && ((unsigned)(x0 >> 70) - 0xcef522e9u)) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)((unsigned)(x0 >> 70) & 1023u);
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(u0 < 8u), (unsigned)l0, (unsigned)(unsigned char)((unsigned)((unsigned)e0 || u3) % ((unsigned)b0 | 1u))); }
                        switch ((unsigned)x0 & 7u) {
                            if ((unsigned)l0) continue;
                            if (0x10000u) break;
                            g1 += (unsigned)((int)0x10000u < (int)((unsigned)((short)(unsigned)h0 > (signed char)6u) ? i2 : (unsigned)c1));
                            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(signed char)(r0.y ^ (5u % (v0 | 1u))), ((unsigned)(0xa7f703b8u == 0x7fffffffu) * m0), 0x10000u); }
                            if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)c0 * (*mp ^ (unsigned)s1)), (unsigned)((unsigned)c1 == (unsigned)((short)p2 > (signed char)u0)), 0x530d672eu); }
                        }
                    } while (i0++ < 4u && (p1 * ((unsigned)(w0 >> 29) >> (g0 & 31u))));
                    d0 = d0 * 0.5 + (double)((unsigned)(((0x74d0076bu ^ 2u) + a0[i0 & 3u]) || (0xc577ff24u >> ((unsigned)s0 & 31u))) & 1023u);
                    u1 = (unsigned)(p2 && (unsigned)x0);
                }
                do { if (--fuel == 0u) goto done;
                    if ((0x80000000u << ((unsigned)d0 & 31u))) continue;
                    h1 = (unsigned short)(h1 + 0xae720851u);
                    *q0 = ((unsigned)w0 * u1);
                } while (i2++ < 5u && (p2 ^ v0));
                if ((unsigned)((short)0x7d992868u > (signed char)garr[u2 & 7u])) break;
                switch ((unsigned)((unsigned)((int)0x80000000u < (int)(unsigned)w0) && (unsigned)w0) & 7u) {
                    g1 += (unsigned)w0;
                    if ((((unsigned)l0 & a0[i0 & 3u]) + p2)) goto L1;
                    h0 = (short)(unsigned)((int)((unsigned)f0 & (unsigned)f0) < (int)(unsigned)(0x5c49d2dbu == g1));
                    s0 = (int)((g1 ^ (unsigned)(6u || 0xf172bc91u)) << (~(unsigned)(0x80000000u < i0) & 31u));
                }
            }
            break; (void)((unsigned)(short)(unsigned)(u1 || u3));
            if ((unsigned)(signed char)((unsigned)f0 + p0)) continue;
            for (;;) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)!(unsigned)(g0 || ((unsigned)c1 % ((unsigned)((int)0xffffffffu < (int)(unsigned)e0) | 1u)));
                m0 ^= (u2 >> ((unsigned)w0 & 31u));
                if (0u) continue;
                s0 = (int)(unsigned)(unsigned char)(unsigned)((g1 >> ((unsigned)b0 & 31u)) || ((0x8b215b12u ^ (unsigned)s1) + u1));
            }
        }
    } else {
        if (((unsigned)(signed char)(*mp & u3) / (0xffffffffu | 1u))) {
            c0 = (unsigned char)(unsigned)!(unsigned)((v0 % ((unsigned)l0 | 1u)) == (unsigned)((unsigned)(short)((unsigned)s1 & *q0) || garr[i1 & 7u]));
            if (garr[i1 & 7u]) goto L1;
            *q0 += (((0x10000u >> ((3u ^ v0) & 31u)) << (i1 & 31u)) / (1u | 1u));
            u3 = u3 * 0x9e3779b1u + ((unsigned)s1 >> (-(unsigned)((unsigned)((unsigned)f0 == (unsigned)b0) || 0xcaad9086u) & 31u));
        }
        if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)s1, (unsigned)h1, ((unsigned)e0 ^ (unsigned)(9u < 1u))); }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((m0 ? 3u : (unsigned)e0), (unsigned)((short)i1 > (signed char)~(unsigned)(i2 < 0x7fffffffu)), ((0x80000000u | u1) * (unsigned)c1)); }
        }
    }
    c1 = (signed char)(unsigned)((int)0x80000000u >= (int)v0);
    if (((unsigned)c1 + *mp)) goto done;
    while (i0++ < 7u && (unsigned)((short)((unsigned)h1 ^ (unsigned)h1) > (signed char)0x7fffffffu)) { if (--fuel == 0u) goto done;
        i2 = (2u - (unsigned)((int)i2 >= (int)(unsigned)s1)) & 15u;
    }
    if ((unsigned)s1) goto L2;
    if (((0x79f45af7u * *mp) >> (0x80000000u & 31u))) {
        if ((unsigned)((short)-(unsigned)((int)9u < (int)0x711c2eeu) > (signed char)0x10000u)) goto L4;
        if (budget != 0u) { budget -= 1u; u1 = fn1(0x7fffffffu, (unsigned)s0, -(g0 | u0)); }
        h0 = (short)(*mp - ((unsigned)((unsigned)h1 || a0[i0 & 3u]) & (unsigned)h1));
        { unsigned t1; double z1; if ((-(0xd9dc3e3du / ((fuel | a0[i0 & 3u]) | 1u))) & 1u) { t1 = (i2 % (((unsigned)c1 & g0) | 1u)); z1 = (double)((-(0x890807u >> ((unsigned)h1 & 31u))) & 255u); } if ((-(0xd9dc3e3du / ((fuel | a0[i0 & 3u]) | 1u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)(0xffffffffu && (unsigned)h1) / (u3 | 1u)), a0[i0 & 3u], (unsigned)((unsigned)b0 == garr[u2 & 7u])); }
            if ((0x8993b5b5u & ((unsigned)(x0 >> 70) / ((unsigned)c0 | 1u)))) goto L2;
            if ((unsigned)(0x376aa2a4u && 4u)) goto L1;
            goto L3;
        }
    }
    w0 = w0 * 6364136223846793005ull + ((((unsigned)(w0 >> 29) + (unsigned)l0) % (u1 | 1u)) ^ (0x34e48044u % (garr[i1 & 7u] | 1u)));
    if ((garr[i1 & 7u] % ((i0 - (unsigned)w0) | 1u))) goto L0;
    if (0x10000u) goto L2;
    goto done;
    { unsigned t2; double z2; if ((((unsigned)w0 ^ (1u | 1u))) & 1u) { t2 = (unsigned)c0; z2 = (double)((0xbde80428u) & 255u); } if ((((unsigned)w0 ^ (1u | 1u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        g0 = (unsigned)(~(unsigned)((short)7u > (signed char)((unsigned)h1 + 0xffffffffu)) || garr[u2 & 7u]);
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1(~(unsigned)((int)~(0xe2c9d983u & 0x7ecf3108u) >= (int)(unsigned)(x0 >> 70)), ((garr[u2 & 7u] % ((unsigned)w0 | 1u)) % (a0[i0 & 3u] | 1u)), (unsigned)((int)(unsigned)(p2 < 0xffffffffu) < (int)(unsigned)(w0 >> 29))); }
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                u1 ^= ((unsigned)((short)p1 > (signed char)g1) - (unsigned)x0);
                do { if (--fuel == 0u) goto done;
                    for (;;) { if (--fuel == 0u) goto done;
                        if ((unsigned)!(unsigned)((0x80000000u << ((unsigned)s0 & 31u)) == (unsigned)l0)) break;
                        if (r0.y) goto L3;
                        i1 = (unsigned)(short)(0x10000u >> ((unsigned)e0 & 31u)) & 15u;
                    }
                } while (i2++ < 4u && (g0 & (u3 | (unsigned)h1)));
                if ((unsigned)s0) continue;
                if (budget != 0u) { budget -= 1u; u3 = fn2(0x3b825ce4u, 3u, (unsigned)s1); }
            }
            if ((0xffffffffu << (u3 & 31u))) break;
            if (budget != 0u) { budget -= 1u; u3 = fn1((i2 ^ (unsigned)((int)0x207b45deu < (int)0x930b1493u)), ((unsigned)(unsigned char)(3u - (unsigned)h1) ^ 0xa6835135u), (garr[i1 & 7u] << (*mp & 31u))); }
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn3((0xf8d116c5u + (0xb686ca1bu & (unsigned)d0)), (~(i2 | 6u) / (p1 | 1u)), (unsigned)((int)r0.x >= (int)0xffffffffu)); }
    q0 = &garr[((garr[u2 & 7u] - (unsigned)(5u || 0x10000u)) + (unsigned)(w0 >> 29)) & 7u];
    if (-(0xd5c75453u & garr[i1 & 7u])) goto L1;
    w0 ^= (unsigned long long)~(garr[u2 & 7u] >> ((unsigned)(x0 >> 70) & 31u)) << ((unsigned)(signed char)(unsigned)((1u | m0) && (unsigned)(fuel || (unsigned)d0)) & 63u);
    if (((0xd6ab809bu * p1) - fuel)) {
        e0 = e0 * 0.5L + (long double)((5u % ((unsigned)s1 | 1u)) & 1023u);
        goto done;
        if ((g0 + (0x7fffffffu * 6u))) {
            if (budget != 0u) { budget -= 1u; u1 = fn1((0x76e70170u % (g0 | 1u)), ((unsigned)c0 | (i2 + (unsigned)c0)), ((unsigned)l0 >> (i1 & 31u))); }
            *mp = 0u;
            q0 = &garr[u2 & 7u];
            l0 = (long)((unsigned long)l0 + (unsigned)(*mp < g1));
            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(unsigned)((m0 + 1u) && ((unsigned)(m0 < i0) - a0[i0 & 3u]));
        } else {
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                a0[(garr[i1 & 7u] / (i2 | 1u)) & 3u] = (unsigned)((0x10000u * (unsigned)c0) == 1u);
                if (u3) continue;
                if (u3 == 7u) return (((unsigned)s1 & ((unsigned)w0 ^ (unsigned)c1)) * (unsigned)w0);
                garr[(unsigned)(short)(0xffffffffu >> (m0 & 31u)) & 7u] = ((garr[i1 & 7u] / (0xcd301069u | 1u)) ? (unsigned)c1 : (v0 * (unsigned)s0));
                if (((unsigned)((unsigned)c0 < 6u) / (*mp | 1u))) {
                    if ((unsigned)(g1 < (unsigned)(v0 < 0x264eaff0u))) break;
                    s0 = (int)(unsigned)((short)*mp > (signed char)v0);
                    if (u3 == 7u) return (unsigned)((int)r0.x >= (int)((unsigned)(garr[u2 & 7u] < ~(unsigned)(i2 && a0[u1 & 3u])) & u0));
                } else {
                    if ((unsigned)((int)garr[i1 & 7u] < (int)g1)) break;
                    d0 = d0 * 0.5 + (double)(((u3 << (0xd3ad6b48u & 31u)) ^ (unsigned)((unsigned)((int)r0.y < (int)0xee60e4a1u) < 9u)) & 1023u);
                }
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)w0) + 2u)) {
                        if ((unsigned)(0xff5e39a0u < (i1 >> (garr[i1 & 7u] & 31u)))) break;
                    } else {
                        if (0x7fffffffu) goto L2;
                        garr[(i0 / (8u | 1u)) & 7u] = ((unsigned)(i1 && 6u) - (unsigned)d0);
                        break; (void)(a0[i0 & 3u]);
                    }
                    g1 += g1;
                    x0 = x0 * 0x100000001b3ull + 0x80000000u;
                    if (((unsigned)c0 ^ ((unsigned)e0 & 7u))) continue;
                    break; (void)((v0 | *mp));
                }
            }
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (-(a0[i0 & 3u] % (0xffffffffu | 1u))) goto L3;
                *q0 = 0xffffffffu;
                if ((unsigned)c0) {
                    s1 = (int)((unsigned)s1 + ((unsigned)h1 % ((unsigned)(signed char)(unsigned)((short)0x7fffffffu > (signed char)u1) | 1u)));
                    break; (void)((r0.y << ((unsigned)((short)p0 > (signed char)r0.y) & 31u)));
                } else {
                    if ((unsigned)b0) break;
                    q0 = &garr[(unsigned)((int)(unsigned)(m0 && (unsigned)(unsigned char)(i2 * *q0)) < (int)a0[i0 & 3u]) & 7u];
                    a0[i2 & 3u] = ((garr[u2 & 7u] + 0x23fb86fcu) - (unsigned)(g1 < (unsigned)(x0 >> 70)));
                    q0 = &garr[((unsigned)h1 % (((unsigned)h0 | (unsigned)x0) | 1u)) & 7u];
                }
                { unsigned t3; double z3; if (((0x80000000u / ((unsigned)((short)p2 > (signed char)u1) | 1u))) & 1u) { t3 = garr[u2 & 7u]; z3 = (double)(((garr[u2 & 7u] & 0x5c4deed0u)) & 255u); } if (((0x80000000u / ((unsigned)((short)p2 > (signed char)u1) | 1u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    if (budget != 0u) { budget -= 1u; u2 = fn3((*q0 ? 0x99a40334u : 0xc1978d45u), 0x471b1ba8u, p2); }
                    if ((unsigned)((short)(unsigned)b0 > (signed char)0x80000000u)) break;
                    if (((unsigned)d0 ? (unsigned)h1 : 0x9621fd85u)) break;
                }
                r0.y ^= ((g1 | u3) % ((p1 << ((unsigned)((int)3u >= (int)(unsigned)x0) & 31u)) | 1u));
            }
            if ((g0 % (0xdc08451cu | 1u))) goto L1;
            if ((r0.y / (0x4aa828b4u | 1u))) goto L2;
        }
        while (i0++ < 5u && (unsigned)(signed char)(8u * (*mp ^ a0[u1 & 3u]))) { if (--fuel == 0u) goto done;
            if ((unsigned)(3u || -(unsigned)((int)r0.x < (int)0xe39c971u))) break;
            switch ((unsigned)((int)2u >= (int)0x80000000u) & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)f0 == 5u), *mp, (a0[u1 & 3u] * u0)); }
                if (budget != 0u) { budget -= 1u; u1 = fn2((*q0 & (unsigned)((int)(unsigned)s0 >= (int)(unsigned)x0)), ((unsigned)d0 | 0x80000000u), (unsigned)((short)(unsigned)h0 > (signed char)g1)); }
                goto L0;
                case 2u: ;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(0u == 0u) + 0xbeb7f290u), ((unsigned)c1 / (0x7fffffffu | 1u)), (unsigned)(p2 == 0x80000000u)); }
            x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)(short)(6u >> (0xdd16b5ceu & 31u)) >= (int)(0x10000u / (1u | 1u)));
            h0 = (short)(unsigned)x0;
            g1 += (unsigned)(8u == g0);
        }
        v0 = (v0 % ((unsigned)(short)(unsigned)(a0[i0 & 3u] || v0) | 1u));
        switch ((unsigned)d0 & 7u) {
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(0x10000u < (unsigned)(p1 < 0xe1309f2du)) >= (int)i0));
        }
    }
    i0 = 6u & 15u;
    switch ((unsigned)((unsigned)(x0 >> 70) == r0.x) & 7u) {
        case 4u: ;
        if ((unsigned)((unsigned)w0 < *mp)) {
            default: ;
            case 3u: ;
            r0.y ^= (unsigned)((unsigned)((int)r0.x < (int)0x2e84fdc1u) && 0x7fffffffu);
            if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)e0 - (unsigned)(signed char)(unsigned)((short)a0[i0 & 3u] > (signed char)0x10000u)), ((unsigned)!(u2 >> ((unsigned)s1 & 31u)) << ((unsigned)(w0 >> 29) & 31u)), 0xcb3ba594u); }
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)c0 < (int)(unsigned)!(unsigned)(2u && u0)));
        }
        case 7u: ;
        s0 = (int)(unsigned)((int)(unsigned)!((unsigned)h0 + (unsigned)(short)((unsigned)h1 ? (unsigned)x0 : u0)) < (int)m0);
        if ((unsigned)((unsigned)f0 == (unsigned)s1)) {
            { unsigned t4; double z4; if (((1u | (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)e0))) & 1u) { t4 = ((unsigned)x0 * (unsigned)d0); z4 = (double)(((unsigned)h1) & 255u); } if (((1u | (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)e0))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                for (;;) { if (--fuel == 0u) goto done;
                    case 0u: ;
                    e0 = e0 * 0.5L + (long double)(2u & 1023u);
                }
                break;
                w0 ^= (unsigned long long)(unsigned)(i0 || 9u) << ((((unsigned)f0 & (unsigned)!(unsigned)((int)u3 >= (int)0xffffffffu)) * (u1 % (garr[u2 & 7u] | 1u))) & 63u);
                v0 = 0x10000u;
                u2 ^= 0xffffffffu;
            }
            h1 = (unsigned short)(h1 + (unsigned)(p1 < 0xb4db6e5du));
            switch ((unsigned)(signed char)(u1 << ((unsigned)b0 & 31u)) & 7u) {
                e0 = e0 * 0.5L + (long double)((r0.x % (((unsigned)((int)0xffffffffu >= (int)(0x10000u + p0)) | (unsigned)d0) | 1u)) & 1023u);
                q0 = &garr[(unsigned)((short)(unsigned)s0 > (signed char)(unsigned)((unsigned)((int)a0[i0 & 3u] < (int)(p2 << (i0 & 31u))) < (unsigned)d0)) & 7u];
            }
            if ((a0[i0 & 3u] >> ((unsigned)h0 & 31u))) goto L4;
        }
        if ((v0 - (v0 % ((unsigned)h1 | 1u)))) {
            if (budget != 0u) { budget -= 1u; u2 = fn1((5u % (a0[u1 & 3u] | 1u)), 1u, garr[u2 & 7u]); }
            s1 = (int)((unsigned)s1 + ((p1 ^ (unsigned)h0) ^ (unsigned)(x0 >> 70)));
        } else {
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 6u: ;
            }
            do { if (--fuel == 0u) goto done;
                { unsigned t5; double z5; if ((0x7fffffffu) & 1u) { t5 = (unsigned)((i2 ^ 0x6c075541u) && (unsigned)b0); z5 = (double)((((unsigned)(w0 >> 29) << (r0.y & 31u))) & 255u); } if ((0x7fffffffu) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                    continue; (void)(i0);
                    case 1u: ;
                }
                continue; (void)((unsigned)(x0 >> 70));
            } while (i0++ < 2u && 0x76cd758cu);
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(8u || m0), ((unsigned)l0 ^ (i0 & 7u)), ((unsigned)(w0 >> 29) ^ p1)); }
        }
    }
    i0 = (-(u3 & 0xf6d3f025u) ^ (g0 / (5u | 1u))) & 15u;
    goto L3;
    for (;;) { if (--fuel == 0u) goto done;
        if (u1) break;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)s1) {
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)(0x80000000u || (unsigned)h1) - garr[i1 & 7u]), (unsigned)b0, 9u); }
                    v0 = 0x7fffffffu;
                } while (i2++ < 5u && (unsigned)((unsigned)(w0 >> 29) < (unsigned)c0));
                d0 = d0 * 0.5 + (double)(0xffffffffu & 1023u);
                goto L0;
            }
            if (((unsigned)e0 | ((unsigned)b0 - (unsigned)x0))) break;
            if ((unsigned)(signed char)((p2 & u0) / (0x82aaef7fu | 1u))) {
                s1 = (int)((unsigned)s1 + ((unsigned)h0 / (garr[i1 & 7u] | 1u)));
                if ((0x834534f1u / (fuel | 1u))) break;
                if (budget != 0u) { budget -= 1u; u2 = fn2((9u - (unsigned)(i2 < fuel)), ((unsigned)d0 | (unsigned)(x0 >> 70)), (unsigned)(signed char)(0x411d891eu / (0xe61d210u | 1u))); }
                w0 ^= (unsigned long long)i1 << (((unsigned)(0u || (unsigned)h0) % ((unsigned)(signed char)(unsigned)(0x29612df6u == 1u) | 1u)) & 63u);
                s1 = (int)((unsigned)s1 + (unsigned)(signed char)(0xd14aaaf1u ^ (unsigned)x0));
            }
            while (i2++ < 4u && ((unsigned)c1 ? 8u : m0)) { if (--fuel == 0u) goto done;
                u2 = u2 * 0x9e3779b1u + ((unsigned)((unsigned)(w0 >> 29) && 0xbec3710cu) | 3u);
                if ((*mp >> (((unsigned)c1 | 7u) & 31u))) continue;
                if ((unsigned)((short)u2 > (signed char)i1)) break;
            }
            u2 = (unsigned)((unsigned)((unsigned)(w0 >> 29) == (0xffffffffu ? a0[u1 & 3u] : (unsigned)c0)) || 3u);
            if ((0u % ((unsigned)l0 | 1u))) break;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn3(((i2 << ((unsigned)f0 & 31u)) >> (i2 & 31u)), (((unsigned)d0 * *mp) & 7u), u3); }
        switch ((unsigned)((int)(unsigned)(w0 >> 29) < (int)0xd807ee2au) & 7u) {
            s0 = (int)(0x908b4751u | g1);
        }
        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(unsigned)(u2 < (unsigned)((fuel % (0x123610dbu | 1u)) < (unsigned)(w0 >> 29))) & 1023u);
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn3(i2, r0.x, (a0[i0 & 3u] - *mp)); }
            if (0x80000000u) break;
            x0 = x0 * 0x100000001b3ull + ((unsigned)l0 - (unsigned)((g0 - u3) || (unsigned)(p0 < (unsigned)s1)));
        } while (i1++ < 3u && a0[u1 & 3u]);
    }
    { unsigned t6; double z6; if (((unsigned)((int)u0 >= (int)0x8f6b0866u)) & 1u) { t6 = ((unsigned)((int)i2 >= (int)garr[u2 & 7u]) + (unsigned)(w0 >> 29)); z6 = (double)(((g1 | u0)) & 255u); } if (((unsigned)((int)u0 >= (int)0x8f6b0866u)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        { unsigned t7; double z7; if (((unsigned)(signed char)(unsigned)(((unsigned)b0 & (unsigned)x0) || 0x23126499u)) & 1u) { t7 = -((6u * a0[u1 & 3u]) >> (0xf539a5c7u & 31u)); z7 = (double)(((unsigned)((int)(unsigned)(0x80000000u && (unsigned)(x0 >> 70)) >= (int)u0)) & 255u); } if (((unsigned)(signed char)(unsigned)(((unsigned)b0 & (unsigned)x0) || 0x23126499u)) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
            if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)!(unsigned)((int)p2 < (int)(unsigned)e0), i0, (unsigned)x0); }
        }
        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)((int)(unsigned)b0 < (int)(unsigned)(u2 < 6u)) < (unsigned)l0) & 1023u);
    }
    goto L1;
    goto done;
    do { if (--fuel == 0u) goto done;
        u2 += (unsigned)w0;
    } while (i0++ < 5u && (unsigned)(u1 && 0x10000u));
    q0 = &garr[((unsigned)h1 - (unsigned)((short)(unsigned)(0x7fffffffu && 5u) > (signed char)(0x7fffffffu * (unsigned)h0))) & 7u];
    if (fuel < 8u) return (unsigned)((int)(a0[u1 & 3u] + (unsigned)h0) < (int)((unsigned)((short)0x42beb5e8u > (signed char)u3) + 0xffffffffu));
    goto L3;
    u2 = ((unsigned)(0x80000000u && (u3 ^ 0xffffffffu)) * (unsigned)(unsigned char)(unsigned)((unsigned)e0 == g1));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 1u, 0x47307460u, 0x7ab97737u },
        { 0u, 0x37b0f7d8u, 0x4e07c0dcu },
        { 0u, 0x83c29efau, 0xd63429b5u },
        { 11u, 0xc915e12cu, 0x1b69af63u },
        { 13u, 0x319b8854u, 0x73dafb44u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
