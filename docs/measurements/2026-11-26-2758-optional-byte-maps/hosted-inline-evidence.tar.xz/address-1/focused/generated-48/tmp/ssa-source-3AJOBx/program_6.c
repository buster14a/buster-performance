// test-ssa-source's program of seed 134000408 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xe6e9fd10u, g1 = 0x99813b98u;
static unsigned garr[8] = { 0x282a6b78u, 0xb1403330u, 0x371be5d3u, 0xe67aff2eu, 0x7c8e9e44u, 0xf919f804u, 0xdb33dd9cu, 0x891038f5u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    v0 = (unsigned)(short)(u1 + ((unsigned)((short)u3 > (signed char)0x80000000u) / ((unsigned)((int)0x2812ffbfu >= (int)m0) | 1u)));
    g0 = (unsigned)((unsigned)((short)0u > (signed char)(unsigned)s1) < 7u);
    if ((3u | (unsigned)((int)a0[i0 & 3u] < (int)2u))) goto L2;
    u0 ^= 0x7fffffffu;
    L0: if (--fuel == 0u) goto done;
    { unsigned t0; double z0; if ((g1) & 1u) { t0 = ((unsigned)w0 * u3); z0 = (double)(((unsigned)(u3 || (unsigned)w0)) & 255u); } if ((g1) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        if (6u) goto done;
        a0[(unsigned)((short)(unsigned)f0 > (signed char)(unsigned)l0) & 3u] = (unsigned)(m0 || (u0 >> ((unsigned)l0 & 31u)));
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && 1u) { if (--fuel == 0u) goto done;
            a0[0xce75f427u & 3u] = (unsigned)(0x184bc667u || a0[u1 & 3u]);
            if ((unsigned)((unsigned)((unsigned)(w0 >> 29) || u1) || 0x7fffffffu)) break;
            L1: if (--fuel == 0u) goto done;
        }
        if ((unsigned)(i0 || 0x80000000u)) goto L0;
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[((unsigned)h0 * u1) & 3u] = fuel;
        switch ((0xffffffffu - g0) & 7u) {
            if ((unsigned)((unsigned)d0 == (v0 << (g1 & 31u)))) break;
            L2: if (--fuel == 0u) goto done;
        }
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            g0 = ((0x7fffffffu >> ((unsigned)((int)(unsigned)b0 < (int)r0.y) & 31u)) + (unsigned)((unsigned)l0 && fuel));
            if ((unsigned)((short)i1 > (signed char)v0)) {
                r0.y ^= (unsigned)((int)(i1 + g1) >= (int)(unsigned)((int)(unsigned)c0 >= (int)a0[i0 & 3u]));
                do { if (--fuel == 0u) goto done;
                    u1 = u1 * 0x9e3779b1u + (unsigned)w0;
                    u2 ^= (unsigned)(short)(0xdbb49f4eu % (((unsigned)f0 >> (0x265ec97u & 31u)) | 1u));
                    d0 = d0 * 0.5 + (double)((unsigned)(0x781167ccu && u0) & 1023u);
                    b0 = ((unsigned)((unsigned)(i0 || 7u) || (unsigned)f0) >> ((unsigned)c1 & 31u)) != 0u;
                } while (i2++ < 4u && (0x80000000u << (-(unsigned)(0x10000u < r0.x) & 31u)));
                e0 = e0 * 0.5L + (long double)((unsigned)w0 & 1023u);
            } else {
                u1 += u3;
                *mp = (unsigned)((unsigned)((short)(fuel << (i2 & 31u)) > (signed char)(unsigned)((int)(unsigned)h0 < (int)p0)) < 8u);
                L3: if (--fuel == 0u) goto done;
            }
        }
    }
    *q0 += 0x10000u;
    d0 = d0 * 0.5 + (double)(((unsigned)(0xae68a0b3u < 0xd27dfa4bu) & (unsigned)x0) & 1023u);
    if (((0xa8c7131fu * 0x80000000u) + r0.x)) goto L1;
    i2 = (unsigned)((int)(unsigned)(8u && g1) < (int)(unsigned)(unsigned char)((unsigned)c0 & 0x80000000u)) & 15u;
    if (u1) {
        if ((unsigned)w0) {
            if ((unsigned)(short)(r0.x & 0xffffffffu)) goto done;
            L4: if (--fuel == 0u) goto done;
            if (((unsigned)(7u || r0.y) * 0x10000u)) goto L3;
        } else {
            if ((8u ^ *mp)) goto done;
        }
        g0 = (((unsigned)s0 % ((0x80000000u << ((unsigned)d0 & 31u)) | 1u)) - (unsigned)c0);
        goto L0;
        while ((i2 - -(unsigned)(fuel == 1u))) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)l0 << (((unsigned)c0 + 0x9f88304du) & 63u);
            if (-((unsigned)x0 % (a0[u1 & 3u] | 1u))) break;
            u1 = p1;
        }
        b0 = (unsigned)((unsigned)((int)(unsigned)s0 >= (int)(unsigned)b0) || (unsigned)!(unsigned)((unsigned)s0 == p0)) != 0u;
    }
    while (-((unsigned)d0 ^ (unsigned)w0)) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)c0);
        l0 = (long)((unsigned long)l0 + (((unsigned)c0 % (u0 | 1u)) ^ 9u));
    }
    if ((unsigned)((int)0xc48dbc33u >= (int)(unsigned)(*q0 < u2))) goto L3;
    w0 ^= (unsigned long long)(*q0 + 5u) << (((unsigned)x0 ? 0x80000000u : (unsigned)(p0 && (unsigned)s0)) & 63u);
    b0 = 0x7fffffffu != 0u;
    goto L1;
    u3 = u3 * 0x9e3779b1u + (0x2f208b4du | 0x3883d22bu);
    e0 = e0 * 0.5L + (long double)((((unsigned)l0 ^ 1u) | (unsigned)b0) & 1023u);
    { unsigned t1; double z1; if (((unsigned)!(unsigned)(u3 < r0.x)) & 1u) { t1 = (v0 * (0x3d97974cu ^ 0xc1f47335u)); z1 = (double)(((unsigned)(unsigned char)((unsigned)h0 + u0)) & 255u); } if (((unsigned)!(unsigned)(u3 < r0.x)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t2; double z2; if (((unsigned)((int)(unsigned)((int)*q0 < (int)a0[u1 & 3u]) >= (int)1u)) & 1u) { t2 = ((0x10000u % ((unsigned)s1 | 1u)) / (0x802be52bu | 1u)); z2 = (double)(((a0[i0 & 3u] * i2)) & 255u); } if (((unsigned)((int)(unsigned)((int)*q0 < (int)a0[u1 & 3u]) >= (int)1u)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                v0 = ((unsigned)!(unsigned)((int)u0 >= (int)(i1 / (a0[u1 & 3u] | 1u))) ? 0xffffffffu : (unsigned)x0);
            }
            *q0 += ((unsigned)d0 | (unsigned)s0);
            if ((unsigned)((int)*mp >= (int)(a0[i0 & 3u] / (*q0 | 1u)))) {
                *mp = (-(unsigned)(fuel < (unsigned)(x0 >> 70)) + ((i1 ^ (unsigned)(w0 >> 29)) * i1));
                goto L1;
                *mp = (unsigned)(signed char)(u2 * i0);
            }
            if (u2) continue;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                while (i2++ < 4u && (unsigned)((unsigned)l0 < m0)) { if (--fuel == 0u) goto done;
                    break; (void)((0x7bc43c49u & (unsigned)(w0 >> 29)));
                    r0.x = ((unsigned)(p0 < (unsigned)(0x80000000u || a0[u1 & 3u])) & u1);
                    u1 = ((unsigned)(a0[i0 & 3u] || *mp) << (g0 & 31u));
                    h1 = (unsigned short)(h1 + (i1 ^ (unsigned)((short)(8u << (((unsigned)e0 * (unsigned)s0) & 31u)) > (signed char)(unsigned)e0)));
                    if (fuel) break;
                    a0[(unsigned)((int)2u >= (int)(unsigned)s1) & 3u] = (i1 / (p2 | 1u));
                }
                r0.y ^= (unsigned)((int)(unsigned)(a0[i0 & 3u] && 0x3db1ec1u) < (int)(p2 - (unsigned)(garr[i1 & 7u] == u1)));
                if (garr[i1 & 7u]) break;
                break; (void)(*mp);
                q0 = &garr[(unsigned)(signed char)((unsigned)(0x80000000u && garr[i1 & 7u]) - (unsigned)(garr[i1 & 7u] < (unsigned)c1)) & 7u];
                w0 = w0 * 6364136223846793005ull + (r0.x | (unsigned)(r0.x < (unsigned)h0));
            }
        }
        goto L2;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (4u) break;
            r0.y ^= (((unsigned)(u2 && i1) % (r0.y | 1u)) - (unsigned)s1);
        }
        { unsigned t3; double z3; if ((((unsigned)(0xe0e4e4bfu && (unsigned)x0) | 0x7bfb425cu)) & 1u) { t3 = u1; z3 = (double)((i2) & 255u); } if ((((unsigned)(0xe0e4e4bfu && (unsigned)x0) | 0x7bfb425cu)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            goto done;
            c0 = (unsigned char)((unsigned)(unsigned char)((u2 + 6u) | garr[u2 & 7u]) - g1);
            f0 = f0 * 0.5f + (float)((unsigned)l0 & 255u);
            *mp = ((0xffffffffu - 6u) - (unsigned)(0xa60d07c0u == (unsigned)h0));
        }
    }
    if ((unsigned)(((unsigned)c1 >> (0x10000u & 31u)) && 0x18cc7d24u)) goto L0;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[((unsigned)(w0 >> 29) - g0) & 3u] = ((unsigned)l0 % ((unsigned)((short)(r0.x % ((unsigned)w0 | 1u)) > (signed char)0x8702c58cu) | 1u));
        if ((unsigned)(signed char)(((unsigned)x0 >> (i2 & 31u)) - a0[u1 & 3u])) goto done;
        garr[(unsigned)!((unsigned)d0 - *mp) & 7u] = (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)(signed char)(garr[i1 & 7u] - (unsigned)(unsigned char)(unsigned)((fuel % ((unsigned)c1 | 1u)) < 6u)));
        v0 = (unsigned)((unsigned)((int)(unsigned)d0 < (int)a0[i0 & 3u]) == a0[i0 & 3u]);
    }
    while (i0++ < 5u && (unsigned)((int)g0 >= (int)8u)) { if (--fuel == 0u) goto done;
        if ((unsigned)(0x7fffffffu && 0xffffffffu)) {
            if (0xffffffffu) break;
            f0 = f0 * 0.5f + (float)(((unsigned)d0 >> ((unsigned)(unsigned char)(unsigned)(u2 && (r0.y & (unsigned)s1)) & 31u)) & 255u);
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                garr[(unsigned)(u1 && 0x7fffffffu) & 7u] = ((unsigned)(g1 == i2) + ~(r0.x >> ((unsigned)s0 & 31u)));
                r0.x = (unsigned)((int)(unsigned)(*mp && p1) >= (int)(unsigned)((short)*q0 > (signed char)a0[i0 & 3u]));
                break; (void)((garr[u2 & 7u] / ((p1 ^ (unsigned)(w0 >> 29)) | 1u)));
                e0 = e0 * 0.5L + (long double)((unsigned)(a0[i0 & 3u] || (i1 % ((unsigned)((short)m0 > (signed char)(0x80000000u / ((unsigned)l0 | 1u))) | 1u))) & 1023u);
                if ((unsigned)(*q0 || m0)) break;
            }
        } else {
            l0 = (long)((unsigned long)l0 + -(((unsigned)d0 - (a0[u1 & 3u] << ((*mp % ((unsigned)x0 | 1u)) & 31u))) & (unsigned)l0));
            s1 = (int)((unsigned)s1 + ((unsigned)((int)0xffffffffu < (int)(unsigned)c0) ^ (unsigned)(signed char)((unsigned)d0 % ((unsigned)(0xffffffffu == 0xffffffffu) | 1u))));
            if ((unsigned)!(unsigned)((unsigned)c1 && (unsigned)c1)) continue;
            r0.x = (unsigned)((int)m0 < (int)((unsigned)(fuel == (0x7fffffffu & (unsigned)(x0 >> 70))) / (p1 | 1u)));
        }
        l0 = (long)((unsigned long)l0 + (unsigned)w0);
    }
    while (i0++ < 5u && (unsigned)((short)(unsigned)f0 > (signed char)(0x10000u & r0.y))) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                u3 = ((0xb2eaca0eu * (unsigned)(u0 == (unsigned)l0)) | (unsigned)h0);
                if ((unsigned)(unsigned char)(i1 % (0u | 1u))) {
                    g0 = (unsigned)s0;
                    if (u0) break;
                    continue; (void)((((unsigned)x0 << (0x7fffffffu & 31u)) & 0x7fffffffu));
                    if ((unsigned)((int)fuel < (int)m0)) continue;
                }
                if (((unsigned)w0 - *mp)) {
                    do { if (--fuel == 0u) goto done;
                        if ((a0[u1 & 3u] | r0.x)) goto L0;
                    } while (i0++ < 3u && (unsigned)((int)2u < (int)(g0 | g0)));
                    u1 ^= (unsigned)x0;
                    *q0 += (0xf5779a69u * g1);
                    h1 = (unsigned short)(h1 + (unsigned)((short)(u3 >> (u0 & 31u)) > (signed char)u2));
                    l0 = (long)((unsigned long)l0 + -(*q0 / (garr[i1 & 7u] | 1u)));
                    g1 += ((unsigned)(-((unsigned)d0 - garr[u2 & 7u]) || ((unsigned)(x0 >> 70) << (p2 & 31u))) % (u2 | 1u));
                }
                if (8u) break;
                q0 = &garr[(unsigned)(4u && (0x10000u ^ (g0 | (unsigned)c0))) & 7u];
            }
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (0x7fffffffu) break;
                if (7u) break;
                v0 = 0xf91629f9u;
                if (((unsigned)(0x67c449a9u && 0xe341ebcau) % (p0 | 1u))) break;
                if ((0xffffffffu / ((unsigned)h1 | 1u))) break;
                if ((r0.y & m0)) break;
            }
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)((int)(unsigned)x0 >= (int)0xffffffffu) << ((((unsigned)w0 + (r0.x ^ (*mp + (unsigned)b0))) >> (3u & 31u)) & 63u);
            }
            if ((unsigned)(g0 || r0.x)) break;
            l0 = (long)((unsigned long)l0 + (unsigned)(g1 && (unsigned)(u2 || u3)));
        } while (i1++ < 2u && r0.x);
        *mp = (unsigned)(short)(0x80000000u ^ (unsigned)(0xf9973eb2u || (unsigned)h1));
        d0 = d0 * 0.5 + (double)((r0.x | p0) & 1023u);
        if (g1) break;
        if ((0xffffffffu ^ p2)) break;
        *q0 += (u2 % ((unsigned)((int)0xffffffffu >= (int)*q0) | 1u));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    w0 = w0 * 6364136223846793005ull + (((a0[i0 & 3u] ^ (unsigned)(w0 >> 29)) >> (garr[u2 & 7u] & 31u)) & (unsigned)((int)u1 < (int)0x78fc7094u));
    { unsigned t0; double z0; if ((0u) & 1u) { t0 = (4u % (((unsigned)x0 ^ (unsigned)c1) | 1u)); z0 = (double)(((unsigned)(short)((i2 + fuel) << (8u & 31u))) & 255u); } if ((0u) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)(unsigned)(m0 == 8u), ((unsigned)(g0 == a0[u1 & 3u]) | 0xffffffffu), (m0 - 0xffffffffu)); }
        goto L2;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            while ((unsigned)((g0 * a0[i0 & 3u]) && r0.x)) { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
                i1 = ((a0[u1 & 3u] & fuel) & (p0 & *q0)) & 15u;
                u0 = u0 * 0x9e3779b1u + (unsigned)(g1 && (unsigned)s0);
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + ((u2 / (0x83d48bffu | 1u)) << ((unsigned)(signed char)(unsigned)((int)(unsigned)(unsigned char)(p1 / ((unsigned)e0 | 1u)) >= (int)0xffffffffu) & 31u));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!(0xf7f222a3u * garr[u2 & 7u]), ((unsigned)((unsigned)h0 || (unsigned)f0) ^ (unsigned)s1), ((unsigned)(x0 >> 70) & (unsigned)(signed char)(0xffffffffu + (unsigned)h1))); }
                    L1: if (--fuel == 0u) goto done;
                    while (i0++ < 7u && (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
                        L2: if (--fuel == 0u) goto done;
                        if (fuel < 8u) return (i0 << (u3 & 31u));
                        if ((unsigned)(signed char)((unsigned)(0x96db1692u && (unsigned)e0) >> (i2 & 31u))) break;
                        c1 = (signed char)((0x10000u >> (((unsigned)(x0 >> 70) / (m0 | 1u)) & 31u)) / (0x25ef6a62u | 1u));
                    }
                    i0 = p0 & 15u;
                    q0 = &garr[(unsigned)(-(2u % (0x43d75b17u | 1u)) || (v0 << (p1 & 31u))) & 7u];
                }
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (m0) {
                        L3: if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + (unsigned)(garr[u2 & 7u] < u2);
                        if ((i0 & 0xc185c830u)) goto L1;
                        goto L3;
                    }
                    if (((0x10000u ^ 0x215b9b82u) - 7u)) {
                        w0 ^= (unsigned long long)(unsigned)(signed char)(unsigned)((int)(unsigned)f0 < (int)p0) << ((unsigned)(signed char)((unsigned)(signed char)(~(0xffffffffu ? 0x80000000u : (unsigned)c1) & 0x10000u) - 0u) & 63u);
                        r0.x = (unsigned)((int)(*q0 / (0x10000u | 1u)) < (int)(p0 >> (0x94e03209u & 31u)));
                    } else {
                        if (budget != 0u) { budget -= 1u; u1 = fn0((u3 & 0xc057f288u), (unsigned)(w0 >> 29), (unsigned)s1); }
                        a0[(unsigned)(u1 && (unsigned)h0) & 3u] = (unsigned)(a0[u1 & 3u] < (1u ? m0 : (unsigned)s0));
                        d0 = d0 * 0.5 + (double)((unsigned)(*q0 == (unsigned)h0) & 1023u);
                    }
                    x0 = x0 * 0x100000001b3ull + ((0xcea08b3fu % ((unsigned)l0 | 1u)) | (unsigned)(x0 >> 70));
                    c0 = (unsigned char)0x7f123c07u;
                    if (i1) break;
                }
                if ((unsigned)((unsigned)s1 || (p1 & r0.x))) continue;
            }
            L4: if (--fuel == 0u) goto done;
            h0 = (short)u1;
            if ((0x8064c092u - (unsigned)(a0[i0 & 3u] && p1))) break;
            while (i1++ < 6u && (unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + 0x23a1a82bu);
                b0 = (unsigned)((0x49975f8bu & (unsigned)((unsigned)s0 && (unsigned)w0)) || *q0) != 0u;
                if ((unsigned)((unsigned)((int)i0 >= (int)0x80000000u) < garr[u2 & 7u])) continue;
                x0 = x0 * 0x100000001b3ull + (unsigned)!(unsigned)(0xffffffffu && 0xb90fd611u);
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)((unsigned)c0 < (unsigned)s0) || u0), (unsigned)(signed char)((unsigned)((short)(unsigned)s1 > (signed char)8u) / (r0.x | 1u)), (unsigned)((int)(unsigned)((int)0xb262f6fu >= (int)u3) >= (int)2u)); }
                u0 ^= 0x8c59d669u;
            }
        }
        u1 ^= (unsigned)((unsigned)((unsigned)(u1 || -(unsigned)(i1 && (unsigned)s1)) == 0x10000u) || u3);
        if (u3 == 7u) return 5u;
        m0 ^= ((unsigned)x0 | i2);
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!(unsigned)((unsigned)(w0 >> 29) < 9u), (0x7fffffffu >> (0xe0d15593u & 31u)), 0x176dfd9au); }
    if (i1) {
        w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)(unsigned)((short)0xf734ca29u > (signed char)(unsigned)l0);
        if ((unsigned)h0) {
            if (0x2d328825u) {
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(p0 == 0x80000000u), (u3 + (p0 | p2)), (*mp + (unsigned)s0)); }
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)b0 ? 0x82d4bda4u : (unsigned)l0), (unsigned)((unsigned)f0 && (unsigned)x0), (unsigned)(a0[u1 & 3u] < i1)); }
                q0 = &garr[(unsigned)(short)(unsigned)((unsigned)l0 || (unsigned)((int)(0x80000000u | (unsigned)x0) < (int)(unsigned)s0)) & 7u];
                if (3u) goto L4;
                v0 = ((0x10000u - (unsigned)(w0 >> 29)) & ((unsigned)((int)p0 >= (int)0x33045affu) / (0x6f9b7d59u | 1u)));
            } else {
                c0 = (unsigned char)(unsigned)!(p1 << ((2u ? 0x24d9c0a9u : 0x7fffffffu) & 31u));
                r0.x = i2;
                u1 ^= (unsigned)((int)6u >= (int)(r0.y + 0x7fffffffu));
                *mp = (unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)((unsigned)((unsigned)b0 && (0xe6f8005eu % (m0 | 1u))) < r0.y));
            }
            h1 = (unsigned short)(h1 + (g0 >> (7u & 31u)));
            if ((unsigned)b0) goto done;
            if (p0) goto L0;
            while ((unsigned)c1) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)0xd5a63a65u << ((unsigned)l0 & 63u);
                { unsigned t1; double z1; if ((0x7fffffffu) & 1u) { t1 = (v0 - (unsigned)(signed char)(unsigned)(r0.x == v0)); z1 = (double)(((unsigned)((int)a0[u1 & 3u] < (int)0xffffffffu)) & 255u); } if ((0x7fffffffu) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    r0.x = (unsigned)(unsigned char)((unsigned)((short)g0 > (signed char)(garr[u2 & 7u] << ((unsigned)x0 & 31u))) * (unsigned)b0);
                    { unsigned t2; double z2; if (((unsigned)((unsigned)x0 && ((unsigned)w0 * garr[i1 & 7u]))) & 1u) { t2 = 0x401c9bb5u; z2 = (double)((0x45c47e8fu) & 255u); } if (((unsigned)((unsigned)x0 && ((unsigned)w0 * garr[i1 & 7u]))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                        if (fuel < 8u) return (6u ^ g0);
                        if ((unsigned)(short)(v0 % ((unsigned)s0 | 1u))) continue;
                    }
                    h1 = (unsigned short)(h1 + p2);
                    if (u3 == 7u) return (0x9a29d3b5u | -((unsigned)c0 * (unsigned)f0));
                    u3 += (-(unsigned)(u0 || (unsigned)h0) | ((unsigned)h1 ^ 0x80000000u));
                }
                r0.y ^= (0x863cc6c6u - (unsigned)(short)(i2 + (unsigned)s0));
                { unsigned t3; double z3; if (((p0 * r0.x)) & 1u) { t3 = ((4u * p2) / (*mp | 1u)); z3 = (double)(((unsigned)((int)(unsigned)c0 < (int)garr[i1 & 7u])) & 255u); } if (((p0 * r0.x)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    if ((((unsigned)b0 + *q0) << (i1 & 31u))) break;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)(garr[u2 & 7u] == i0)) break;
                        *mp = garr[i1 & 7u];
                    } while (i1++ < 4u && (v0 ^ (unsigned)s1));
                    if ((unsigned)((int)a0[u1 & 3u] >= (int)(p2 * 0x7fffffffu))) break;
                }
            }
            if ((unsigned)!(7u + (unsigned)(x0 >> 70))) goto L0;
        }
        if ((((unsigned)s1 + (unsigned)l0) >> (garr[i1 & 7u] & 31u))) goto L1;
        if (6u) goto L0;
    }
    s1 = (int)((unsigned)s1 + (unsigned)(signed char)(a0[i0 & 3u] - (unsigned)((unsigned)(*mp && i0) && g1)));
    a0[(unsigned)((unsigned)(x0 >> 70) || 4u) & 3u] = (unsigned)(5u < 0x9961b3a3u);
    g1 += ~(~(unsigned)(i0 || (unsigned)e0) & (r0.x | v0));
    x0 = x0 * 0x100000001b3ull + (((unsigned)((unsigned)e0 < 0xa165e5bfu) - (unsigned)e0) ? v0 : u0);
    if (r0.x) {
        while (i0++ < 5u && (r0.x * (unsigned)b0)) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + ((r0.x + (unsigned)(r0.x == m0)) + 0x512d27e8u);
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 2u && (unsigned)((unsigned)d0 == 4u)) { if (--fuel == 0u) goto done;
                u3 ^= 0x7fffffffu;
                if ((7u & u3)) break;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0xffffffffu == 1u), (unsigned)(0x7fffffffu && (g0 & garr[u2 & 7u])), 0x80000000u); }
                if ((unsigned)((unsigned)b0 && r0.x)) break;
                if ((unsigned)h1) goto done;
                if ((0x10000u << (*mp & 31u))) break;
            }
            { unsigned t4; double z4; if (((0x10000u - 0xcbfd8222u)) & 1u) { t4 = (unsigned)(short)(*mp ? i1 : (unsigned)c0); z4 = (double)(((a0[i0 & 3u] % (((unsigned)l0 + (unsigned)e0) | 1u))) & 255u); } if (((0x10000u - 0xcbfd8222u)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                { unsigned t5; double z5; if (((0x40725bf0u & ~(unsigned)((short)0xffffffffu > (signed char)0xf666fcfdu))) & 1u) { t5 = (unsigned)(unsigned char)((unsigned)(unsigned char)(unsigned)((short)p2 > (signed char)4u) << (fuel & 31u)); z5 = (double)(((unsigned)((unsigned)(r0.x || 0x17a310a1u) || a0[i0 & 3u])) & 255u); } if (((0x40725bf0u & ~(unsigned)((short)0xffffffffu > (signed char)0xf666fcfdu))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    c0 = (unsigned char)(v0 | (unsigned)(3u && fuel));
                    if ((unsigned)d0) break;
                    if (((unsigned)(*mp && p2) | r0.x)) break;
                    *mp = (unsigned)((short)(0x26a64ed7u ^ 0xd4c35426u) > (signed char)((unsigned)((int)v0 < (int)garr[u2 & 7u]) * (unsigned)h0));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((u0 * 0xffffffffu), (unsigned)(r0.y || (unsigned)((int)p2 < (int)(unsigned)e0)), (unsigned)(short)((unsigned)b0 / ((unsigned)c0 | 1u))); }
                }
                *mp = (unsigned)(u0 && (unsigned)c1);
                do { if (--fuel == 0u) goto done;
                    switch (7u & 7u) {
                        if (u3 == 7u) return ((((unsigned)c1 >> ((unsigned)s1 & 31u)) + (3u % (r0.x | 1u))) - 7u);
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((0x80000000u & 8u) % ((unsigned)h1 | 1u)), *q0, (unsigned)c0); }
                        if (garr[i1 & 7u]) goto done;
                        u0 ^= 0xc2f37ec7u;
                    }
                    if ((g0 - (unsigned)s1)) break;
                    h0 = (short)(unsigned)((int)p2 < (int)3u);
                } while (i1++ < 4u && ((8u / (5u | 1u)) ^ garr[u2 & 7u]));
                break; (void)(garr[u2 & 7u]);
                c1 = (signed char)(unsigned)!(((unsigned)c0 / ((unsigned)((int)fuel >= (int)((unsigned)h0 * 0x10000u)) | 1u)) | i2);
            }
            u0 ^= ((unsigned)w0 | ((a0[u1 & 3u] / (a0[u1 & 3u] | 1u)) << ((0xffffffffu * v0) & 31u)));
            garr[(unsigned)(unsigned char)(unsigned)((int)*mp >= (int)a0[i0 & 3u]) & 7u] = (r0.y << (((unsigned)w0 | ~(unsigned)((int)(unsigned)x0 >= (int)0x7fffffffu)) & 31u));
        }
        { unsigned t6; double z6; if (((unsigned)(u2 && i0)) & 1u) { t6 = -(((unsigned)(w0 >> 29) - garr[u2 & 7u]) * 0xc21834bu); z6 = (double)(((unsigned)((int)(unsigned)w0 >= (int)m0)) & 255u); } if (((unsigned)(u2 && i0)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            switch ((unsigned)((unsigned)d0 || u0) & 7u) {
                if ((0x80000000u << (0x80000000u & 31u))) {
                    case 7u: ;
                    f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)(signed char)(0x834b8531u + ~(unsigned)(0xaebb34a7u && i1)) < (int)5u) & 255u);
                    if ((unsigned)(u2 < (unsigned)x0)) goto L2;
                    while ((unsigned)((int)p0 < (int)~((unsigned)(x0 >> 70) - (unsigned)w0))) { if (--fuel == 0u) goto done;
                        case 0u: ;
                        if (u0) break;
                        { unsigned t7; double z7; if (((u2 ? a0[u1 & 3u] : (unsigned)(w0 >> 29))) & 1u) { t7 = (0x80000000u % (((unsigned)c0 & 0xd8b1108bu) | 1u)); z7 = (double)((((unsigned)h1 * 0x7fffffffu)) & 255u); } if (((u2 ? a0[u1 & 3u] : (unsigned)(w0 >> 29))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                            if ((unsigned)h1) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn0(((p1 & 0xd3b1aef2u) * (unsigned)c1), (unsigned)(x0 >> 70), (i0 + 5u)); }
                            goto L2;
                        }
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(short)(unsigned)(*q0 || (unsigned)((unsigned)h0 < a0[i0 & 3u])), ~(u1 | 0x10000u), (unsigned)(*mp < (unsigned)(0x80000000u && (unsigned)s0))); }
                } else {
                    c0 = (unsigned char)(i1 << ((unsigned)e0 & 31u));
                    u0 = i0;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(u1 == 0x1d3e28d7u), (unsigned)(fuel < 4u), ((garr[i1 & 7u] * (unsigned)c1) | 0x7fffffffu)); }
            }
            g1 += ((unsigned)f0 / ((3u ^ p2) | 1u));
            garr[i1 & 7u] = (unsigned)(g1 || (unsigned)(4u < (unsigned)d0));
            u3 = (unsigned)(a0[u1 & 3u] == garr[u2 & 7u]);
            if (*q0) goto L2;
        }
        s0 = (int)(unsigned)((unsigned)(0xb80c83d6u == 0x838541d3u) || (unsigned)((int)(unsigned)e0 >= (int)(unsigned)s0));
        h0 = (short)(3u << ((unsigned)s0 & 31u));
        u0 += (unsigned)(unsigned char)((unsigned)h1 >> (((unsigned)((int)p0 >= (int)a0[i0 & 3u]) + (unsigned)d0) & 31u));
    } else {
        if ((unsigned)((int)(g1 % (0x7fffffffu | 1u)) < (int)(unsigned)(x0 >> 70))) {
            if ((unsigned)((short)(0x2302cd8au & garr[i1 & 7u]) > (signed char)0x7fffffffu)) goto L3;
            if ((unsigned)((0x5b6b515cu & 7u) == i1)) {
                if ((unsigned)((short)(unsigned)((short)p0 > (signed char)(unsigned)c1) > (signed char)r0.x)) goto done;
                goto done;
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (p0) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((8u / (p2 | 1u)), (garr[i1 & 7u] | (5u % ((unsigned)x0 | 1u))), (i0 / ((*q0 >> (i2 & 31u)) | 1u))); }
                    u0 ^= (unsigned)s0;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((4u - 0x80000000u), (unsigned)(0x680cc381u || (unsigned)b0), (unsigned)((short)0x63fdbf70u > (signed char)p1)); }
                    switch (-(unsigned)((i2 ^ (unsigned)s1) < v0) & 7u) {
                        e0 = e0 * 0.5L + (long double)(-(unsigned)(a0[i0 & 3u] && p1) & 1023u);
                        m0 ^= (garr[i1 & 7u] % ((unsigned)((int)0x10000u < (int)0u) | 1u));
                    }
                    if ((u3 ^ g1)) {
                        continue; (void)((unsigned)(w0 >> 29));
                    } else {
                        if ((unsigned)c0) continue;
                        break; (void)((unsigned)(unsigned char)(unsigned)((unsigned)l0 && (0xffffffffu >> (7u & 31u))));
                    }
                }
                if (budget != 0u) { budget -= 1u; u3 = fn0(~(i0 & ((unsigned)x0 % ((unsigned)(x0 >> 70) | 1u))), (unsigned)(r0.y < 0xd48ea369u), (unsigned)(p2 && 0xcd3fcf39u)); }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)(unsigned)(u0 || (unsigned)(x0 >> 70)), ((unsigned)((unsigned)w0 == 0x1715063au) - 0x7fffffffu), (unsigned)e0); }
            } else {
                r0.y ^= (1u ^ (unsigned)((unsigned)(7u == -(fuel ^ u1)) || r0.x));
            }
            if ((unsigned)((short)(0x3c808e0u % ((unsigned)f0 | 1u)) > (signed char)0x80000000u)) goto done;
            { unsigned t8; double z8; if ((((unsigned)c1 + (3u & 0xa0b0ee5u))) & 1u) { t8 = ((unsigned)w0 - (unsigned)(w0 >> 29)); z8 = (double)(((unsigned)s0) & 255u); } if ((((unsigned)c1 + (3u & 0xa0b0ee5u))) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                if ((p1 >> (((unsigned)f0 + (unsigned)(w0 >> 29)) & 31u))) goto L3;
                a0[(unsigned)(0x10000u || i1) & 3u] = ((unsigned)(*mp || p0) << (((1u * i0) % (0x49e06f40u | 1u)) & 31u));
                if (budget != 0u) { budget -= 1u; u1 = fn0(p1, i2, ((unsigned)b0 - 0x99dfc54cu)); }
            }
        }
        if (0xeafdfb90u) {
            *mp = p1;
            switch (((p0 | garr[u2 & 7u]) / (0x10000u | 1u)) & 7u) {
                u2 = ((unsigned)b0 >> (((6u | r0.x) >> ((0xffffffffu / ((unsigned)h0 | 1u)) & 31u)) & 31u));
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    case 6u: ;
                    goto done;
                }
                w0 = w0 * 6364136223846793005ull + (-(u3 ^ 8u) | (unsigned)((short)5u > (signed char)p2));
            }
            r0.y ^= (unsigned)((short)(unsigned)w0 > (signed char)((m0 << (a0[i0 & 3u] & 31u)) ? v0 : (unsigned)l0));
            s1 = (int)((unsigned)s1 + (unsigned)x0);
            do { if (--fuel == 0u) goto done;
                v0 = ((unsigned)s0 << (2u & 31u));
                q0 = &garr[(unsigned)c1 & 7u];
                c1 = (signed char)(unsigned)(0xc235834eu == *mp);
            } while (i0++ < 6u && (unsigned)(w0 >> 29));
            if ((unsigned)(((unsigned)e0 - v0) && 0x5d0a05b4u)) goto L0;
        }
        q0 = &garr[(unsigned)e0 & 7u];
        do { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                while (i2++ < 5u && (unsigned)e0) { if (--fuel == 0u) goto done;
                    if (u2) goto L2;
                }
                for (;;) { if (--fuel == 0u) goto done;
                    { unsigned t9; double z9; if (((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)(0x2b9219c6u == 0x10000u))) & 1u) { t9 = i1; z9 = (double)((i1) & 255u); } if (((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)(0x2b9219c6u == 0x10000u))) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                        if ((unsigned)(signed char)(unsigned)((int)(unsigned)(signed char)(unsigned)((unsigned)(x0 >> 70) && *mp) < (int)0xffffffffu)) break;
                        goto L4;
                        break; (void)(7u);
                        b0 = (p0 ? *q0 : (unsigned)c0) != 0u;
                        garr[((unsigned)h0 - (unsigned)f0) & 7u] = u1;
                    }
                    if (((unsigned)w0 | r0.y)) break;
                    if (i1) break;
                    s0 = (int)(unsigned)(signed char)(0xa70a6be4u | ((unsigned)h0 ? 3u : (unsigned)((unsigned)c1 || 0xcd9fad8bu)));
                }
                while (i2++ < 2u && 6u) { if (--fuel == 0u) goto done;
                    if (m0) {
                        s0 = (int)g1;
                        f0 = f0 * 0.5f + (float)(((4u ^ u3) - ((unsigned)((int)(unsigned)c0 < (int)u2) ^ 0x57c33f75u)) & 255u);
                        break; (void)((7u >> ((unsigned)(short)((unsigned)h0 << (v0 & 31u)) & 31u)));
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0x7fffffffu >> ((unsigned)((unsigned)h0 && (unsigned)l0) & 31u)), a0[u1 & 3u], (0x80000000u - (unsigned)f0)); }
                }
                c1 = (signed char)0xff26f2b5u;
                if ((unsigned)((int)0x185e0b69u < (int)(0xe6692e84u + a0[u1 & 3u]))) {
                    c0 = (unsigned char)garr[u2 & 7u];
                } else {
                    continue; (void)(~(2u ^ i0));
                    c1 = (signed char)~(unsigned)((int)~((unsigned)(short)(i1 ^ 0x7fffffffu) + p1) >= (int)((unsigned)s1 >> (0x10000u & 31u)));
                    switch ((4u / (*mp | 1u)) & 7u) {
                        h1 = (unsigned short)(h1 + ((unsigned)(x0 >> 70) / ((unsigned)(signed char)(-((unsigned)d0 >> (2u & 31u)) << (p0 & 31u)) | 1u)));
                        { unsigned t10; double z10; if (((unsigned)(short)(1u >> (0x7fffffffu & 31u))) & 1u) { t10 = (6u / (garr[i1 & 7u] | 1u)); z10 = (double)((((unsigned)c0 | garr[u2 & 7u])) & 255u); } if (((unsigned)(short)(1u >> (0x7fffffffu & 31u))) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
                            if (budget != 0u) { budget -= 1u; u3 = fn0((p0 & 5u), (unsigned)h1, (unsigned)b0); }
                            case 6u: ;
                            if ((unsigned)c1) break;
                        }
                        case 7u: ;
                    }
                }
            }
            s1 = (int)((unsigned)s1 + (fuel >> ((unsigned)((unsigned)((short)(unsigned)h1 > (signed char)garr[i1 & 7u]) == 0xccbfe04du) & 31u)));
            x0 = x0 * 0x100000001b3ull + 0u;
            if ((unsigned)(short)(unsigned)((int)(unsigned)e0 < (int)(unsigned)s0)) break;
        } while (i0++ < 6u && (unsigned)h0);
    }
    if ((garr[u2 & 7u] * (unsigned)e0)) goto L1;
    v0 = (unsigned)((int)0x10000u < (int)-(p0 * (unsigned)d0));
    d0 = d0 * 0.5 + (double)(((unsigned)(0x80000000u || (g0 + p2)) | -(m0 % ((unsigned)s0 | 1u))) & 1023u);
    v0 = a0[u1 & 3u];
    goto L3;
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(signed char)(unsigned)(-(unsigned)((unsigned)l0 == g0) == g1), ((unsigned)((int)(unsigned)l0 >= (int)0x10000u) << (9u & 31u)), 0x80000000u); }
    if (0xffffffffu) {
        w0 ^= (unsigned long long)a0[i0 & 3u] << ((unsigned)((p1 | a0[u1 & 3u]) || 0x6fd73381u) & 63u);
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)!(unsigned)((unsigned)s1 == (unsigned)w0) < p1), -(unsigned)((int)(unsigned)(0x80000000u && g0) < (int)0x7b5d0f65u), (unsigned)((int)((unsigned)b0 & 0xf75a7187u) < (int)(unsigned)c0)); }
            break; (void)((unsigned)(w0 >> 29));
        }
        if ((0x80000000u & 0x6c574a8bu)) goto done;
    }
    do { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((~(fuel + (unsigned)((int)(unsigned)((int)0x10000u < (int)9u) >= (int)v0)) ^ a0[i0 & 3u]) & 255u);
    } while (i0++ < 5u && (unsigned)((unsigned)s1 < (garr[u2 & 7u] / ((unsigned)l0 | 1u))));
    if (g0) goto L4;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && (unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)c1, (unsigned)c0, (unsigned)((int)(unsigned)w0 >= (int)(unsigned)(r0.x || (unsigned)h1))); }
            h1 = (unsigned short)(h1 + 0x326f7af8u);
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0x613a319u && *mp), 0xffffffffu, (((unsigned)e0 - (unsigned)l0) / ((unsigned)c0 | 1u))); }
        }
        if (fuel < 8u) return (unsigned)((short)(unsigned)(signed char)(r0.y + 0x66903055u) > (signed char)u1);
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(0x9e5048a5u < 0x80000000u) | 0xcfd08614u), 0xd6d97e98u, (unsigned)((int)0xfdc30e5bu < (int)~((unsigned)s1 >> ((unsigned)c0 & 31u)))); }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(short)(fuel - 0xf35bedf7u), ((unsigned)e0 ? 0x2b4b5351u : (unsigned)s0), (unsigned)h0); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (u3 == 7u) return ((0x80000000u / (((fuel / (a0[i0 & 3u] | 1u)) / (0x80000000u | 1u)) | 1u)) | u3);
    if (budget != 0u) { budget -= 1u; u1 = fn1((i0 - (0xffffffffu ^ g1)), (unsigned)(i1 < v0), (unsigned)s1); }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[(unsigned)(*mp || (unsigned)b0) & 3u] = 0x10000u;
        u2 = u2 * 0x9e3779b1u + (unsigned)((short)m0 > (signed char)0x470c2887u);
        if (((7u << (0x78c057f2u & 31u)) << (i1 & 31u))) break;
        u0 ^= 0x7fffffffu;
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = ((unsigned)(0xba667592u == v0) ? 6u : (unsigned)s0);
        *mp = (0x8d6adfd8u * u0);
        s0 = (int)(((unsigned)s0 ^ u1) >> (0x7fffffffu & 31u));
        for (;;) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(0xa6c0e7d7u & 1023u);
            if (budget != 0u) { budget -= 1u; u0 = fn1(0xffffffffu, u0, (unsigned)(signed char)(garr[u2 & 7u] >> ((unsigned)(0x10000u && (unsigned)e0) & 31u))); }
        }
        if ((unsigned)(g1 < (u1 + *mp))) {
            if ((g1 * p0)) {
                q0 = &garr[(0x7fffffffu - p2) & 7u];
            } else {
                *q0 = (((g0 / (p1 | 1u)) ^ (unsigned)(w0 >> 29)) | (unsigned)((short)(unsigned)d0 > (signed char)r0.y));
                if (budget != 0u) { budget -= 1u; u1 = fn0(g0, ((unsigned)(0xffffffffu < 0xfe2fc8b9u) | i1), (unsigned)((unsigned)(x0 >> 70) || g0)); }
                q0 = &garr[0x9fe0153u & 7u];
            }
            if ((0x7fffffffu % ((a0[u1 & 3u] | v0) | 1u))) break;
            d0 = d0 * 0.5 + (double)((unsigned)c1 & 1023u);
            r0.y ^= (unsigned)h0;
            { unsigned t0; double z0; if ((3u) & 1u) { t0 = (0x7fffffffu / (0x227f2482u | 1u)); z0 = (double)((((0xffffffffu | u2) - 0x3918556u)) & 255u); } if ((3u) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                x0 = x0 * 0x100000001b3ull + ((6u ? (unsigned)w0 : 0x601027d2u) | (unsigned)((int)m0 >= (int)u0));
                g0 = ((unsigned)h1 ^ ((unsigned)b0 >> (0x80000000u & 31u)));
                L0: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(x0 >> 70), ((unsigned)s0 | 0x80000000u), (u2 / (((unsigned)s1 - a0[i0 & 3u]) | 1u))); }
            }
            *q0 += ((0xf264a29du >> (0x10000u & 31u)) % (((i2 - i1) << ((unsigned)w0 & 31u)) | 1u));
        }
    }
    while (i0++ < 4u && (5u & 0x45667f12u)) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && ((unsigned)l0 * (unsigned)(i1 || 0x7fffffffu))) { if (--fuel == 0u) goto done;
            if (-(unsigned)((int)(g0 / ((unsigned)l0 | 1u)) < (int)(unsigned)l0)) {
                if ((unsigned)((unsigned)(w0 >> 29) < (unsigned)c0)) continue;
                if ((0x9f0e215au & (i0 / ((unsigned)l0 | 1u)))) {
                    r0.x = (unsigned)(short)((unsigned)((short)0xab595aefu > (signed char)i1) & (p0 | *mp));
                    l0 = (long)((unsigned long)l0 + v0);
                    v0 = (unsigned)((unsigned)c1 || (unsigned)(8u || (unsigned)h1));
                    switch ((unsigned)((i1 + (unsigned)(w0 >> 29)) < u2) & 7u) {
                        s1 = (int)((unsigned)s1 + (unsigned)((g0 - (unsigned)b0) || (unsigned)c0));
                        c0 = (unsigned char)((unsigned)w0 >> ((unsigned)!(unsigned)((int)(unsigned)((int)(unsigned)((int)(unsigned)h1 >= (int)2u) >= (int)p2) < (int)(unsigned)d0) & 31u));
                    }
                    if (-(unsigned)((int)(u2 * 0x7fffffffu) < (int)2u)) break;
                    f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)((short)(unsigned)!(unsigned)((short)0x10000u > (signed char)(unsigned)w0) > (signed char)(unsigned)d0) < (int)~(unsigned)(0x3b123d37u || (unsigned)(w0 >> 29))) & 255u);
                } else {
                    break; (void)((unsigned)w0);
                    L1: if (--fuel == 0u) goto done;
                    r0.y ^= ((unsigned)h0 & (i2 >> ((unsigned)((int)(unsigned)c1 < (int)(unsigned)(signed char)(unsigned)(a0[u1 & 3u] < u0)) & 31u)));
                }
                f0 = f0 * 0.5f + (float)(~(u3 & ~(i2 * (unsigned)l0)) & 255u);
                if ((unsigned)(w0 >> 29)) continue;
                g1 += ((unsigned)f0 ^ (0x8f9646d5u - (r0.y % (0xc81ab2b1u | 1u))));
            }
            { unsigned t1; double z1; if (((3u + a0[i0 & 3u])) & 1u) { t1 = (r0.x % (u1 | 1u)); z1 = (double)(((unsigned)((int)(unsigned)(0x80000000u || i2) >= (int)a0[i0 & 3u])) & 255u); } if (((3u + a0[i0 & 3u])) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)v0 << (0x80000000u & 63u);
                }
                break; (void)(r0.x);
                h0 = (short)(*q0 & 0x80000000u);
                if (u3) {
                    s1 = (int)((unsigned)s1 + (unsigned)(((unsigned)(0xa02620e3u || 8u) - 0x7fffffffu) && (unsigned)(signed char)((unsigned)w0 % (5u | 1u))));
                    garr[(fuel << ((unsigned)d0 & 31u)) & 7u] = ((7u & (unsigned)f0) | (unsigned)e0);
                    h0 = (short)(unsigned)((int)0x258b2150u >= (int)i2);
                    a0[0xa84e3b9eu & 3u] = i0;
                    d0 = d0 * 0.5 + (double)(r0.y & 1023u);
                }
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    v0 = r0.x;
                    b0 = (unsigned)((int)u2 < (int)(unsigned)((unsigned)(*q0 || *mp) == 8u)) != 0u;
                    w0 ^= (unsigned long long)(unsigned)((unsigned)h0 || g0) << ((((unsigned)s1 | u1) * (g0 / ((unsigned)d0 | 1u))) & 63u);
                }
            }
            if ((unsigned)x0) {
                switch (u3 & 7u) {
                    break; (void)((u1 & (unsigned)(short)(i2 | v0)));
                    L2: if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                    garr[u0 & 7u] = ((p0 ^ p2) & (unsigned)((unsigned)(u1 || garr[i1 & 7u]) < u1));
                    u2 += ((unsigned)(garr[u2 & 7u] == 0xffffffffu) | (unsigned)x0);
                }
                *q0 = (unsigned)s1;
                L4: if (--fuel == 0u) goto done;
                if (p0) {
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)h0 || (unsigned)((int)6u < (int)v0)), (unsigned)c0, (unsigned)((int)((unsigned)x0 & 0x80000000u) < (int)0x5e7bbc6bu)); }
                } else {
                    r0.x = (unsigned)!(((p0 << (g1 & 31u)) ^ v0) % ((unsigned)b0 | 1u));
                }
            }
        }
        u2 = u2 * 0x9e3779b1u + (6u * g0);
        do { if (--fuel == 0u) goto done;
            q0 = &garr[(0xffffffffu - (u1 << (0xffffffffu & 31u))) & 7u];
            r0.x = (((unsigned)(signed char)(unsigned)(p1 == u3) << (u0 & 31u)) / (0x4099812au | 1u));
            if ((0xffffffffu << (i2 & 31u))) {
                d0 = d0 * 0.5 + (double)(((i2 * 0xaa3bc8cau) % ((unsigned)x0 | 1u)) & 1023u);
            } else {
                do { if (--fuel == 0u) goto done;
                    if (*mp) break;
                    while (0x7fffffffu) { if (--fuel == 0u) goto done;
                        r0.x = g0;
                        if (((unsigned)((int)r0.x >= (int)0xfe78b37cu) / (*q0 | 1u))) break;
                    }
                    break; (void)((unsigned)(0x7fffffffu || a0[i0 & 3u]));
                    if (v0) break;
                } while (i2++ < 4u && ((unsigned)s0 % ((1u - v0) | 1u)));
            }
            w0 = w0 * 6364136223846793005ull + (1u & g1);
            goto L1;
            e0 = e0 * 0.5L + (long double)((0x78b1bff4u / (0x10000u | 1u)) & 1023u);
        } while (i1++ < 4u && (0x556d4760u ^ p1));
        s1 = (int)((unsigned)s1 + ((-(0x183316c7u ^ 0xbbfd19c0u) - p1) / ((garr[i1 & 7u] * 0x80000000u) | 1u)));
        x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)b0 < (int)garr[i1 & 7u]);
    }
    if ((unsigned)(i1 < g0)) {
        u2 += ((unsigned)h1 & (unsigned)c0);
        while ((unsigned)s0) { if (--fuel == 0u) goto done;
            if ((*q0 % (0xffffffffu | 1u))) break;
        }
    } else {
        *q0 += (u2 / ((unsigned)((unsigned)(fuel && (unsigned)l0) && (unsigned)((unsigned)(x0 >> 70) == (unsigned)d0)) | 1u));
        e0 = e0 * 0.5L + (long double)(~(unsigned)((int)i2 < (int)(unsigned)((unsigned)b0 < p2)) & 1023u);
        c0 = (unsigned char)(u0 & 4u);
        { unsigned t2; double z2; if ((((unsigned)e0 + (unsigned)c1)) & 1u) { t2 = (u3 ^ u2); z2 = (double)(((unsigned)((short)(unsigned)((int)0x337ab92cu >= (int)6u) > (signed char)*q0)) & 255u); } if ((((unsigned)e0 + (unsigned)c1)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            if (0xf47a5702u) goto done;
            *mp = 0x10000u;
            u2 = (unsigned)((3u << (*q0 & 31u)) < 0x10000u);
            goto L0;
            if (a0[u1 & 3u]) goto L3;
            for (;;) { if (--fuel == 0u) goto done;
                garr[(unsigned)((unsigned)s1 < 0x80000000u) & 7u] = (((unsigned)h1 ? 0u : r0.y) + (unsigned)((unsigned)s1 < g0));
                f0 = f0 * 0.5f + (float)(((v0 - 0x80000000u) / (((unsigned)c1 ^ (unsigned)h0) | 1u)) & 255u);
                a0[u3 & 3u] = (0xffffffffu << ((unsigned)(p0 || (unsigned)((int)r0.x < (int)p2)) & 31u));
                l0 = (long)((unsigned long)l0 + (*q0 % (u2 | 1u)));
                e0 = e0 * 0.5L + (long double)(((unsigned)(unsigned char)(unsigned)((unsigned)((int)u2 < (int)((unsigned)(w0 >> 29) + 0x480b8e4eu)) == r0.y) % (i0 | 1u)) & 1023u);
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn1((u0 & (unsigned)h0), g0, 0xffffffffu); }
    if ((unsigned)c1) {
        { unsigned t3; double z3; if (((p1 << ((unsigned)((short)0u > (signed char)u1) & 31u))) & 1u) { t3 = (unsigned)c0; z3 = (double)((fuel) & 255u); } if (((p1 << ((unsigned)((short)0u > (signed char)u1) & 31u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            w0 = w0 * 6364136223846793005ull + ((unsigned)e0 << (((unsigned)w0 % ((unsigned)e0 | 1u)) & 31u));
            goto done;
            h0 = (short)((unsigned)(signed char)((unsigned)(3u && (unsigned)h1) | (unsigned)e0) >> (p1 & 31u));
        }
        if (6u) goto L4;
        if (budget != 0u) { budget -= 1u; u1 = fn1((*mp >> ((unsigned)x0 & 31u)), (unsigned)((short)u0 > (signed char)garr[i1 & 7u]), (unsigned)!(8u / (g0 | 1u))); }
        goto L0;
        if ((unsigned)(signed char)((unsigned)((int)3u >= (int)*mp) ^ (unsigned)b0)) goto L1;
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)(a0[u1 & 3u] & 1023u);
        if (0x3d962203u) break;
        l0 = (long)((unsigned long)l0 + ((unsigned)(x0 >> 70) + 0x10000u));
        if (0x8e0cc1a5u) break;
    }
    if (u2) goto L1;
    if (0x7fffffffu) goto L2;
    q0 = &garr[(unsigned)(7u < *q0) & 7u];
    if ((((unsigned)s0 | 0x10000u) / (i2 | 1u))) goto L0;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)-((p1 | 0x80000000u) % (0xd34ead21u | 1u));
        break; (void)((unsigned)((short)a0[u1 & 3u] > (signed char)0x5f3f68b7u));
        *mp = (unsigned)((int)((unsigned)x0 ? (unsigned)s0 : (unsigned)x0) >= (int)(0xe45f7b69u ^ 4u));
        v0 = 0x10000u;
        if ((unsigned)((int)g1 < (int)a0[i0 & 3u])) break;
    }
    goto done;
    u1 = ((unsigned)((unsigned)!((unsigned)w0 & u2) < 0x80000000u) * 0xffffffffu);
    l0 = (long)((unsigned long)l0 + (unsigned)((int)m0 < (int)(unsigned)c0));
    { unsigned t4; double z4; if (((p2 - 1u)) & 1u) { t4 = (unsigned)((short)(unsigned)s0 > (signed char)0x10000u); z4 = (double)((garr[i1 & 7u]) & 255u); } if (((p2 - 1u)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
        a0[(4u - a0[i0 & 3u]) & 3u] = (unsigned)(unsigned char)(((unsigned)f0 ? i1 : (unsigned)e0) + (unsigned)e0);
        u2 += (unsigned)c1;
        w0 = w0 * 6364136223846793005ull + ((7u << (garr[i1 & 7u] & 31u)) >> ((unsigned)((0x10000u & i2) && (unsigned)c1) & 31u));
    }
    c1 = (signed char)~((0x889d24eeu + 0xcc08667au) ^ (unsigned)(unsigned char)((unsigned)(7u || (unsigned)s0) - 0x7fffffffu));
    c0 = (unsigned char)((unsigned)((short)(unsigned)c0 > (signed char)0x277807d9u) | (unsigned)(unsigned char)(0xffffffffu - 0x7fffffffu));
    { unsigned t5; double z5; if (((unsigned)h0) & 1u) { t5 = (((unsigned)x0 | 0x8c447a22u) ^ 0x11b2d02au); z5 = (double)(((2u / ((0x5b2f771au & 0x80000000u) | 1u))) & 255u); } if (((unsigned)h0) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        switch ((unsigned)(w0 >> 29) & 7u) {
            break; (void)((*mp - (unsigned)(fuel && (unsigned)x0)));
            g1 += (unsigned)((unsigned)(x0 >> 70) || (unsigned)((int)u3 < (int)(unsigned)(w0 >> 29)));
            h1 = (unsigned short)(h1 + (u1 % (i1 | 1u)));
        }
        if ((unsigned)(unsigned char)(unsigned)(0x10000u < a0[i0 & 3u])) {
            if (budget != 0u) { budget -= 1u; u0 = fn0(i1, (0u - p0), (6u * (unsigned)!(unsigned)((int)(unsigned)h1 >= (int)0x80000000u))); }
            if (((6u << (i2 & 31u)) + (unsigned)e0)) goto L3;
            do { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)c1 & 255u);
                while (i1++ < 5u && (unsigned)((int)u1 < (int)u1)) { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)((short)1u > (signed char)((unsigned)e0 % ((unsigned)b0 | 1u)));
                    if ((unsigned)d0) {
                        if (fuel < 8u) return (0x7fffffffu / ((unsigned)h1 | 1u));
                        if ((unsigned)(r0.y < p1)) break;
                        if ((unsigned)(unsigned char)(unsigned)((int)(p0 | u3) < (int)(unsigned)e0)) {
                            f0 = f0 * 0.5f + (float)(0xc662c60cu & 255u);
                        } else {
                            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)x0 || (unsigned)c0), -(unsigned)((g0 + (unsigned)e0) || 0x4155e02fu), (unsigned)((unsigned)b0 || (unsigned)(w0 >> 29))); }
                        }
                    } else {
                        c1 = (signed char)((unsigned)((int)(unsigned)s1 < (int)0xa611f41fu) % (((unsigned)b0 - fuel) | 1u));
                        v0 = 9u;
                    }
                    e0 = e0 * 0.5L + (long double)((unsigned)(g0 || i2) & 1023u);
                    *q0 = (unsigned)((unsigned)(0xff85affeu && p1) == p1);
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(9u + (unsigned)(w0 >> 29)) >= (int)8u), (p1 | (unsigned)((unsigned)(x0 >> 70) == p2)), (r0.x & 0x80000000u)); }
                    if ((unsigned)s0) {
                        if ((0x132567acu >> (a0[u1 & 3u] & 31u))) break;
                    }
                }
                r0.x = (unsigned)(p2 && (0x826ea2f3u - 4u));
                while (i1++ < 4u && (*q0 >> ((unsigned)((short)0x2d5e7987u > (signed char)garr[u2 & 7u]) & 31u))) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)(m0 % (6u | 1u)) > (signed char)r0.x), (unsigned)l0, (unsigned)w0); }
                }
            } while (i0++ < 2u && ~(unsigned)(7u == p0));
            i1 = u1 & 15u;
            a0[0x80000000u & 3u] = (unsigned)((unsigned)((unsigned)f0 < p2) || (unsigned)((short)*q0 > (signed char)(unsigned)!(unsigned)((unsigned)e0 < 0xfd0a7674u)));
            do { if (--fuel == 0u) goto done;
                break; (void)((0u ? r0.y : a0[i0 & 3u]));
                u0 ^= 7u;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)f0, p1, (unsigned)l0); }
                if ((unsigned)((int)(u0 & 0xf88c8b92u) < (int)garr[u2 & 7u])) {
                    u0 ^= (u3 + (unsigned)(g0 || (unsigned)(garr[i1 & 7u] == garr[i1 & 7u])));
                } else {
                    u2 += (unsigned)e0;
                    x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(unsigned)((unsigned)f0 == (*q0 * 4u));
                }
            } while (i0++ < 5u && (0xffffffffu + p0));
        }
        do { if (--fuel == 0u) goto done;
            i1 = i2 & 15u;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(unsigned char)(8u - p0) << (g1 & 31u)), (unsigned)s1, -(unsigned)((0x10000u / ((unsigned)b0 | 1u)) || (unsigned)c1)); }
            if (((unsigned)s0 ? a0[u1 & 3u] : p1)) continue;
            if (budget != 0u) { budget -= 1u; u3 = fn1((a0[i0 & 3u] >> ((unsigned)(0x935f1c7u == p2) & 31u)), (unsigned)l0, (unsigned)((short)(p1 / (0xfca8e3b7u | 1u)) > (signed char)a0[i0 & 3u])); }
            u2 = a0[i0 & 3u];
            w0 ^= (unsigned long long)m0 << (0x10000u & 63u);
        } while (i0++ < 7u && (p2 & (unsigned)(0u == (unsigned)(x0 >> 70))));
        if (i1) goto L3;
        if ((unsigned)(signed char)((unsigned)(garr[i1 & 7u] || *mp) >> (*mp & 31u))) {
            h1 = (unsigned short)(h1 + (unsigned)((short)(0x882add27u + (unsigned)h0) > (signed char)(unsigned)(signed char)(0xca449ec4u * 0x7fffffffu)));
        } else {
            if (u3) {
                g1 += (9u - (unsigned)b0);
                i0 = ~(g0 ? (unsigned)!((0x80000000u + 8u) | 3u) : g0) & 15u;
                garr[(unsigned)d0 & 7u] = (unsigned)((unsigned)(short)(p1 >> (0x32848e9u & 31u)) == a0[i0 & 3u]);
                if ((unsigned)d0) goto L4;
                goto L3;
                e0 = e0 * 0.5L + (long double)((0x7fffffffu ? (0x580d525fu / ((unsigned)f0 | 1u)) : 0x10000u) & 1023u);
            } else {
                if ((unsigned)(w0 >> 29)) goto done;
                h0 = (short)((unsigned)(short)(unsigned)(0x80000000u && 0xd4418d15u) ^ r0.x);
                if (budget != 0u) { budget -= 1u; u2 = fn0((0u ^ *q0), (unsigned)(short)(unsigned)((unsigned)s0 && (unsigned)(unsigned char)(p1 % (0xa6abfb10u | 1u))), 0xe1b791b1u); }
                w0 ^= (unsigned long long)0xffffffffu << ((unsigned)(((i2 & 0x7fffffffu) ^ (unsigned)(0x46281f9du && 0x80000000u)) && 0xffffffffu) & 63u);
            }
            *mp = ((unsigned)(w0 >> 29) / (p0 | 1u));
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)l0 >> ((unsigned)e0 & 31u)), (unsigned)s0, (i2 << (m0 & 31u))); }
        }
        g0 = 0xb27b4734u;
    }
    a0[0xffffffffu & 3u] = u3;
    s0 = (int)(unsigned)((int)(*mp - 0xe0a176fbu) < (int)u2);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(-(unsigned)(u1 < 0xdc69ed7fu));
        if (fuel < 8u) return (unsigned)((int)0xffffffffu < (int)(0xffffffffu * p1));
        if ((unsigned)s0) break;
        if (budget != 0u) { budget -= 1u; u3 = fn1((p1 ^ p0), (unsigned)c0, (a0[i0 & 3u] ^ (unsigned)x0)); }
    }
    u3 ^= (((unsigned)x0 | (unsigned)l0) + (unsigned)(0xad9e7899u < (unsigned)((unsigned)l0 == g0)));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((*q0 & 0x19233067u)) break;
        if ((unsigned)l0) break;
        if ((5u * u3)) break;
        r0.x = ((g1 % (fuel | 1u)) | (unsigned)h0);
        do { if (--fuel == 0u) goto done;
            if (a0[u1 & 3u]) goto L4;
            g0 = (unsigned)((unsigned)b0 == (v0 >> (((unsigned)c1 + u3) & 31u)));
        } while (i1++ < 3u && ((unsigned)f0 + (unsigned)c1));
    }
    u0 += (i1 & (unsigned)(r0.y || (unsigned)((int)0x10000u >= (int)0x82049089u)));
    v0 = (unsigned)s1;
    b0 = 0x80000000u != 0u;
    if (0x10000u) goto L2;
    { unsigned t6; double z6; if ((~(0x7fffffffu + (unsigned)(garr[u2 & 7u] == a0[i0 & 3u]))) & 1u) { t6 = (*q0 - (unsigned)s0); z6 = (double)((((unsigned)c0 / (i2 | 1u))) & 255u); } if ((~(0x7fffffffu + (unsigned)(garr[u2 & 7u] == a0[i0 & 3u]))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
        { unsigned t7; double z7; if (((unsigned)(~(unsigned)(0xffffffffu == u3) || (unsigned)x0)) & 1u) { t7 = (unsigned)((int)(unsigned)d0 >= (int)(0x7c30b185u * *q0)); z7 = (double)(((i0 ? 2u : fuel)) & 255u); } if (((unsigned)(~(unsigned)(0xffffffffu == u3) || (unsigned)x0)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
            if ((a0[i0 & 3u] ^ (unsigned)(garr[i1 & 7u] || r0.y))) {
                if ((unsigned)h0) goto L2;
            } else {
                goto L2;
                if ((unsigned)d0) goto L3;
                *mp = 0x97db7777u;
                g1 += (unsigned)((short)0u > (signed char)((unsigned)c1 | v0));
            }
            goto L4;
            if (4u) goto done;
            if ((~(unsigned)((unsigned)b0 < u3) | 0xffffffffu)) goto done;
        }
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(u2, ((unsigned)((short)(unsigned)c1 > (signed char)u3) * 0x1f481375u), (unsigned)((short)r0.y > (signed char)*q0)); }
                if ((g0 - a0[u1 & 3u])) break;
                if (u0) continue;
                do { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        i1 = 0x3ac743d1u & 15u;
                        i2 = r0.x & 15u;
                        if ((unsigned)(unsigned char)((unsigned)f0 & (unsigned)((unsigned)s0 == 0xe0bcc05cu))) break;
                        if (i2) goto L0;
                        if (((unsigned)w0 ^ 0x10000u)) break;
                        c1 = (signed char)((p0 / (*mp | 1u)) ^ garr[u2 & 7u]);
                    } while (i0++ < 7u && (u3 % (i1 | 1u)));
                    if (p0) break;
                    u3 = (((unsigned)((int)6u >= (int)(unsigned)e0) * ((unsigned)d0 >> (0x96378d1fu & 31u))) & (unsigned)h0);
                } while (i2++ < 2u && v0);
                g0 = 0xa0fb635cu;
            }
            u1 += p1;
            do { if (--fuel == 0u) goto done;
                if (((unsigned)c1 / (i1 | 1u))) {
                    *q0 = ((unsigned)((int)p1 >= (int)(unsigned)c1) % (g1 | 1u));
                    switch (((unsigned)w0 & (unsigned)b0) & 7u) {
                        *mp = (unsigned)((unsigned)((unsigned)e0 < (i0 + 0x10000u)) < (r0.y ^ garr[u2 & 7u]));
                        g1 += ((unsigned)(w0 >> 29) ^ (unsigned)d0);
                        case 1u: ;
                        f0 = f0 * 0.5f + (float)((g1 | ((unsigned)((short)i2 > (signed char)(unsigned)s1) | (unsigned)(i1 == fuel))) & 255u);
                        s0 = (int)(unsigned)(x0 >> 70);
                        default: ;
                    }
                    if ((unsigned)(0x5de2c413u && i0)) break;
                } else {
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        s0 = (int)(unsigned)((unsigned)s1 || (unsigned)(i0 && i0));
                    }
                    x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)(((unsigned)f0 % (p0 | 1u)) >> ((0xffffffffu * 0xe27dd6e7u) & 31u));
                    if ((unsigned)((unsigned)((unsigned)s1 || (unsigned)e0) < 0xffffffffu)) break;
                    break; (void)(((r0.y % ((unsigned)d0 | 1u)) << ((unsigned)s0 & 31u)));
                }
                f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)((unsigned)(1u == v0) | (unsigned)((int)i0 >= (int)0x10000u)) & 255u);
                r0.y ^= 0x7fffffffu;
                *mp = i1;
            } while (i1++ < 7u && (unsigned)f0);
        }
        if ((unsigned)(g0 < (unsigned)f0)) {
            if ((unsigned)s1) {
                if ((v0 + g0)) goto L1;
                a0[(unsigned)(u3 && a0[i0 & 3u]) & 3u] = ((0x7fffffffu | (unsigned)w0) & (unsigned)e0);
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)x0 && i0), 0x7fffffffu, ((unsigned)h1 >> (a0[u1 & 3u] & 31u))); }
                goto L1;
                { unsigned t8; double z8; if ((((unsigned)l0 | (m0 * 0x73a4ac5cu))) & 1u) { t8 = p0; z8 = (double)((9u) & 255u); } if ((((unsigned)l0 | (m0 * 0x73a4ac5cu))) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                    w0 = w0 * 6364136223846793005ull + garr[u2 & 7u];
                }
            }
            switch ((0xf3b82ccu >> (((unsigned)w0 & 0x7fffffffu) & 31u)) & 7u) {
                switch (0xaa685eb0u & 7u) {
                    case 3u: ;
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (0x7fffffffu) goto L1;
                        do { if (--fuel == 0u) goto done;
                            h0 = (short)(unsigned)((int)(unsigned)((int)u2 >= (int)u3) < (int)v0);
                            if (budget != 0u) { budget -= 1u; u2 = fn1(garr[u2 & 7u], ((unsigned)(x0 >> 70) + (unsigned)(0x7fffffffu < u3)), (unsigned)d0); }
                            if (0x80000000u) continue;
                            *q0 += (*q0 / ((unsigned)(((unsigned)x0 * fuel) < 1u) | 1u));
                        } while (i1++ < 5u && ((unsigned)d0 & (unsigned)((int)fuel >= (int)u1)));
                        if (g0) {
                            *mp = (0xdfe40e82u - ((unsigned)w0 << (i0 & 31u)));
                            g1 += (i0 - 7u);
                            goto L4;
                            l0 = (long)((unsigned long)l0 + 0x767ea0b2u);
                            break; (void)(((unsigned)f0 % ((unsigned)h0 | 1u)));
                            garr[(unsigned)b0 & 7u] = (unsigned)!(unsigned)((int)(unsigned)h1 >= (int)u3);
                        } else {
                            u2 = (unsigned)((unsigned)f0 == ((unsigned)(x0 >> 70) >> ((unsigned)f0 & 31u)));
                            c1 = (signed char)(i0 >> ((unsigned)(u3 == (unsigned)(0x51a885eeu && 0u)) & 31u));
                            u2 += (unsigned)s0;
                            if (budget != 0u) { budget -= 1u; u0 = fn0((0x80000000u >> ((unsigned)w0 & 31u)), (unsigned)s1, 0x39d3ca08u); }
                        }
                        break; (void)((m0 | 0xaf468559u));
                        i1 = fuel & 15u;
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(r0.x == u3) < (unsigned)h0), ((garr[u2 & 7u] / ((unsigned)w0 | 1u)) * (unsigned)l0), (unsigned)((int)(unsigned)((int)g0 >= (int)a0[u1 & 3u]) < (int)garr[i1 & 7u])); }
                    if (budget != 0u) { budget -= 1u; u3 = fn1((0u ^ 0x841808a0u), (unsigned)c0, (unsigned)((0x7a09f727u << (u3 & 31u)) == g1)); }
                    if (u3 == 7u) return ((unsigned)(w0 >> 29) * (unsigned)(2u == ((unsigned)c1 / (0xb3c0b6f7u | 1u))));
                }
            }
            { unsigned t9; double z9; if ((0x10000u) & 1u) { t9 = (unsigned)((short)(unsigned)h1 > (signed char)0x80000000u); z9 = (double)((u2) & 255u); } if ((0x10000u) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                i2 = p2 & 15u;
                l0 = (long)((unsigned long)l0 + u0);
            }
            w0 ^= (unsigned long long)0x7fffffffu << ((unsigned)(i0 == (unsigned)b0) & 63u);
            b0 = (((unsigned)c0 / ((unsigned)e0 | 1u)) % (-(a0[u1 & 3u] & 0x68eee100u) | 1u)) != 0u;
            goto L0;
        }
    }
    e0 = e0 * 0.5L + (long double)((0x10000u | ((unsigned)((unsigned)(w0 >> 29) == p1) & (unsigned)s0)) & 1023u);
    w0 ^= (unsigned long long)(u0 % (g0 | 1u)) << ((unsigned)((short)(unsigned)((unsigned)(0xbae112b1u < *mp) && g1) > (signed char)(unsigned)(w0 >> 29)) & 63u);
    m0 ^= ((unsigned)x0 << ((unsigned)(a0[u1 & 3u] || 0x36ccaec2u) & 31u));
    while (i0++ < 3u && (~(unsigned)(0x7fffffffu && 0xffffffffu) | 9u)) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)(unsigned)(unsigned char)(*q0 ^ u1) << ((unsigned)((0x4ead48fcu % (0x4fe40553u | 1u)) && 7u) & 63u);
        do { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((unsigned)((int)4u >= (int)(unsigned)c0) & 1023u);
            v0 = ((unsigned)(signed char)(((unsigned)w0 >> (1u & 31u)) << ((r0.x / (u0 | 1u)) & 31u)) * a0[i0 & 3u]);
            g1 += (unsigned)(signed char)(i2 ? (unsigned)((int)0u < (int)0x1bcf5f46u) : (fuel + u2));
            if ((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)s0)) break;
        } while (i1++ < 3u && (unsigned)(i2 == (r0.x << (0xffffffffu & 31u))));
    }
    if ((unsigned)(x0 >> 70)) {
        s1 = (int)((unsigned)s1 + (unsigned)(0u || (unsigned)((int)*mp >= (int)4u)));
        goto L2;
        q0 = &garr[((unsigned)(short)(unsigned)((int)(unsigned)b0 < (int)(unsigned)d0) / ((unsigned)((a0[u1 & 3u] ^ p1) == garr[u2 & 7u]) | 1u)) & 7u];
        while ((unsigned)((unsigned)(0xffffffffu == r0.y) == 0x7fffffffu)) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((unsigned)c0 && v0));
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(fuel && 4u)) break;
                u0 = (((unsigned)(x0 >> 70) ^ (unsigned)s0) + (unsigned)(short)(u3 * (unsigned)d0));
            } while (i1++ < 2u && (i2 | r0.x));
            e0 = e0 * 0.5L + (long double)((unsigned)(i1 == (unsigned)f0) & 1023u);
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)0x1ffcf64du < (int)3u), (a0[i0 & 3u] + r0.x), (unsigned)((unsigned)w0 < (unsigned)l0)); }
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (fuel < 8u) return 0x7fffffffu;
    a0[(a0[i0 & 3u] << ((unsigned)w0 & 31u)) & 3u] = ((unsigned)((unsigned)s0 || garr[u2 & 7u]) >> (((0x7fffffffu - 3u) >> (a0[i0 & 3u] & 31u)) & 31u));
    *q0 += (fuel >> ((7u ? *mp : fuel) & 31u));
    { unsigned t0; double z0; if (((unsigned)(short)(garr[i1 & 7u] % (garr[i1 & 7u] | 1u))) & 1u) { t0 = fuel; z0 = (double)(((unsigned)((unsigned)c1 < i0)) & 255u); } if (((unsigned)(short)(garr[i1 & 7u] % (garr[i1 & 7u] | 1u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        if (r0.y) goto done;
        if (0xcd82e043u) goto L4;
        switch ((7u & (unsigned)b0) & 7u) {
            b0 = (unsigned)(fuel && (unsigned)d0) != 0u;
            w0 ^= (unsigned long long)(unsigned)h1 << ((unsigned)(unsigned char)((*mp - 0x2c921989u) * ((unsigned)c1 & (unsigned)(w0 >> 29))) & 63u);
        }
        if ((unsigned)(short)(r0.y ^ u1)) goto L3;
        c1 = (signed char)~(unsigned)((int)(5u ^ 0x7fffffffu) >= (int)(0x30e43537u - 8u));
    }
    if ((unsigned)(p1 && (unsigned)s0)) goto L2;
    x0 = x0 * 0x100000001b3ull + -(garr[u2 & 7u] * (unsigned)((short)u1 > (signed char)(unsigned)((unsigned)s0 && fuel)));
    if ((unsigned)((unsigned)(3u || 0x10000u) == 3u)) {
        r0.y ^= 0x10000u;
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(((unsigned)(w0 >> 29) + g0) && garr[u2 & 7u]), ~(unsigned)((short)*mp > (signed char)(unsigned)x0), a0[u1 & 3u]); }
        a0[((unsigned)(x0 >> 70) + 0x10000u) & 3u] = (unsigned)h0;
    } else {
        l0 = (long)((unsigned long)l0 + 0xe5c4020u);
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)d0 & (unsigned)f0), (unsigned)((unsigned)w0 == (unsigned)(short)(garr[i1 & 7u] >> (garr[u2 & 7u] & 31u))), (unsigned)((short)(unsigned)(8u == (unsigned)f0) > (signed char)0x10000u)); }
        if ((garr[u2 & 7u] << (((unsigned)w0 / (g0 | 1u)) & 31u))) goto L4;
        L0: if (--fuel == 0u) goto done;
    }
    if (*mp) goto L0;
    q0 = &garr[(unsigned)((int)0x10000u >= (int)(v0 << (r0.x & 31u))) & 7u];
    c0 = (unsigned char)(unsigned)(i0 < ((3u / (r0.y | 1u)) + (u2 % (garr[u2 & 7u] | 1u))));
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1((0x80000000u / ((unsigned)c0 | 1u)), r0.y, (unsigned)(r0.x || (unsigned)((unsigned)h1 == 0x81ebd79eu))); }
        break; (void)((0x80000000u % (0xffffffffu | 1u)));
        if (budget != 0u) { budget -= 1u; u0 = fn2(g1, (unsigned)c0, (unsigned)(signed char)(unsigned)((int)*mp < (int)m0)); }
    } while (i0++ < 4u && ((unsigned)e0 * p1));
    *q0 += (unsigned)c0;
    garr[(unsigned)(8u && u0) & 7u] = (unsigned)((unsigned)((unsigned)h1 || (u3 % (0x932b26fcu | 1u))) == (0xffffffffu & u1));
    b0 = (unsigned)((short)8u > (signed char)(6u - (garr[u2 & 7u] - (unsigned)((short)v0 > (signed char)0xffffffffu)))) != 0u;
    garr[0x10000u & 7u] = (unsigned)((u3 ? 0x10000u : 0x13e275acu) || u2);
    if (budget != 0u) { budget -= 1u; u1 = fn1((u1 ^ g0), (0x80000000u * (r0.y % (i1 | 1u))), (unsigned)(signed char)(0x7fffffffu + (r0.y ^ (unsigned)s0))); }
    if ((((unsigned)e0 & 3u) % (g0 | 1u))) goto L0;
    l0 = (long)((unsigned long)l0 + (u1 ^ u1));
    do { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + 0x8a14c656u);
        { unsigned t1; double z1; if (((0x7fffffffu ^ (0x6b03f896u << (m0 & 31u)))) & 1u) { t1 = (unsigned)(garr[i1 & 7u] || -(unsigned)((int)(unsigned)e0 < (int)(unsigned)c1)); z1 = (double)(((unsigned)((unsigned)x0 == (unsigned)(w0 >> 29))) & 255u); } if (((0x7fffffffu ^ (0x6b03f896u << (m0 & 31u)))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)(unsigned)h1 > (signed char)(g1 + (unsigned)f0)), (r0.x & *mp), 0xffffffffu); }
        }
        L1: if (--fuel == 0u) goto done;
    } while (i0++ < 3u && 0xffffffffu);
    f0 = f0 * 0.5f + (float)(1u & 255u);
    { unsigned t2; double z2; if (((unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)e0)) & 1u) { t2 = i2; z2 = (double)(((unsigned)((int)0x7fffffffu < (int)fuel)) & 255u); } if (((unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)e0)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        do { if (--fuel == 0u) goto done;
            L2: if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
        } while (i0++ < 7u && (4u >> (0xa1314294u & 31u)));
        if (budget != 0u) { budget -= 1u; u1 = fn0(0xa39a80e6u, (8u >> ((unsigned)l0 & 31u)), (0x80000000u & (9u + garr[u2 & 7u]))); }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            i2 = 0xffffffffu & 15u;
        }
        *mp = 0xffffffffu;
        goto L2;
        u3 ^= (unsigned)((0xffffffffu ? p0 : 7u) || 0x80000000u);
    }
    switch ((unsigned)(unsigned char)(unsigned)((short)(0x732fecceu + (unsigned)s0) > (signed char)(unsigned)w0) & 7u) {
        if ((unsigned)l0) {
            if (budget != 0u) { budget -= 1u; u0 = fn2(~(unsigned)((u3 & r0.y) < (unsigned)(w0 >> 29)), (unsigned)(p0 && p2), 0xa975ee0cu); }
            case 7u: ;
            while (i0++ < 2u && 0x10000u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)l0, g1, (unsigned)(signed char)(unsigned)((short)(unsigned)c1 > (signed char)(unsigned)w0)); }
                case 4u: ;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s0, (((unsigned)s1 + (unsigned)d0) >> (g0 & 31u)), (unsigned)d0); }
                f0 = f0 * 0.5f + (float)(5u & 255u);
            }
        } else {
            w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)((i0 ^ 0x10000u) >> (0x80000000u & 31u));
            if ((g1 * (unsigned)h0)) break;
        }
        while (i0++ < 7u && r0.x) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn2(0xdc04787du, ((2u + 0x10000u) % (0x10000u | 1u)), (u1 & (unsigned)((unsigned)c1 < u1))); }
            c0 = (unsigned char)garr[i1 & 7u];
            m0 ^= ~(unsigned)((int)u3 < (int)~(unsigned)((unsigned)(p2 && fuel) && 0x39f65758u));
        }
        a0[(unsigned)c1 & 3u] = (0x381135c0u / (0u | 1u));
        x0 = x0 * 0x100000001b3ull + ((unsigned)(unsigned char)((unsigned)(i1 < p2) | (unsigned)!(unsigned)((int)a0[u1 & 3u] >= (int)0x7fffffffu)) & 7u);
    }
    if ((unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)x0)) goto done;
    if ((unsigned)(signed char)(0u << (0xffffffffu & 31u))) goto L3;
    if ((7u * i1)) {
        *q0 = (unsigned)s1;
        s0 = (int)((unsigned)((int)*q0 >= (int)p1) % (6u | 1u));
    } else {
        garr[(unsigned)((unsigned)w0 && a0[i0 & 3u]) & 7u] = (unsigned)((unsigned)((unsigned)(x0 >> 70) && 0x925fcf7cu) < (unsigned)f0);
        v0 = (unsigned)(short)(unsigned)((short)p0 > (signed char)(((unsigned)b0 / (5u | 1u)) + (unsigned)((unsigned)c0 || 0x7fffffffu)));
        goto L3;
    }
    if ((unsigned)(0xed2fca66u == (*q0 | (unsigned)l0))) {
        switch (0xc40f462cu & 7u) {
            break; (void)((unsigned)h0);
            if ((u1 | (unsigned)((unsigned)s0 || 0x80000000u))) {
                g0 = (unsigned)(signed char)(i0 & (u3 - (unsigned)(x0 >> 70)));
                r0.x = -((0x98842b6fu % (0x10000u | 1u)) / ((unsigned)(garr[u2 & 7u] && (v0 - (unsigned)(w0 >> 29))) | 1u));
                if (((unsigned)(m0 == (unsigned)x0) >> (g1 & 31u))) goto done;
                c0 = (unsigned char)(g1 + -((5u ^ u1) << ((unsigned)x0 & 31u)));
            }
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (0x7fffffffu << ((unsigned)c0 & 31u));
            while (0xfdc83c9bu) { if (--fuel == 0u) goto done;
                break; (void)((~(unsigned)((unsigned)b0 && (unsigned)(w0 >> 29)) / (garr[u2 & 7u] | 1u)));
                u0 ^= ((unsigned)(((unsigned)(x0 >> 70) >> ((unsigned)((short)(unsigned)s1 > (signed char)p2) & 31u)) < (unsigned)c0) * 6u);
                g0 = u2;
            }
            if ((0x7fffffffu % (~(0x80000000u ^ 9u) | 1u))) goto L1;
            s0 = (int)(unsigned)(((unsigned)(signed char)(0x7fffffffu * 4u) >> ((unsigned)((int)r0.y < (int)0xffffffffu) & 31u)) == u2);
        }
        if ((unsigned)l0) goto L2;
        switch ((unsigned)((unsigned)((short)(unsigned)h0 > (signed char)u2) || u2) & 7u) {
            i1 = ((0x80000000u + ((3u / ((unsigned)x0 | 1u)) & garr[u2 & 7u])) * r0.y) & 15u;
            case 5u: ;
            d0 = d0 * 0.5 + (double)((0xd4c6a718u + (unsigned)h0) & 1023u);
            default: ;
        }
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            a0[0xcf956c8au & 3u] = 9u;
        }
        s0 = (int)(unsigned)((unsigned)((unsigned)(i0 == *mp) && ((unsigned)s1 ^ 0xfced5060u)) == 0x700b12a2u);
    } else {
        u3 = 0x7fffffffu;
    }
    w0 = w0 * 6364136223846793005ull + (p1 & (unsigned)(0x8a9fe94u < (unsigned)e0));
    if (fuel < 8u) return (((unsigned)((short)1u > (signed char)(unsigned)b0) + (unsigned)(x0 >> 70)) - ~(unsigned)((unsigned)(x0 >> 70) && a0[i0 & 3u]));
    if (budget != 0u) { budget -= 1u; u1 = fn1((p1 + (unsigned)((int)(unsigned)c1 >= (int)(unsigned)h1)), (0xfe1fa92bu / ((unsigned)b0 | 1u)), (unsigned)l0); }
    l0 = (long)((unsigned long)l0 + (unsigned)f0);
    x0 = x0 * 0x100000001b3ull + (8u ^ i2);
    u0 += (unsigned)((int)0x10000u < (int)0x10000u);
    q0 = &garr[(fuel >> ((unsigned)((unsigned)(0xffffffffu || (unsigned)e0) && (0x80000000u % (0x80000000u | 1u))) & 31u)) & 7u];
    x0 = x0 * 0x100000001b3ull + ((i0 ? a0[i0 & 3u] : 0x80000000u) & i0);
    switch ((unsigned)((unsigned)e0 || 0x10000u) & 7u) {
        s1 = (int)((unsigned)s1 + (unsigned)((int)i2 < (int)(6u >> ((unsigned)(signed char)(unsigned)((unsigned)c1 || (unsigned)e0) & 31u))));
        w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)(unsigned char)(*q0 & 4u) > (signed char)(unsigned)(signed char)(5u - (1u + (unsigned)c0)));
    }
    c1 = (signed char)(unsigned)((short)(u0 - 5u) > (signed char)*mp);
    do { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)(unsigned)s0 << ((unsigned)((int)0x7fffffffu < (int)(unsigned)h1) & 63u);
        i2 = (p2 + (unsigned)((int)(unsigned)(garr[u2 & 7u] && p2) >= (int)0x80000000u)) & 15u;
    } while (i0++ < 2u && (garr[u2 & 7u] << ((unsigned)h1 & 31u)));
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)0x10000u > (signed char)*q0), ((unsigned)e0 % (9u | 1u)), (fuel + r0.y)); }
L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    s0 = (int)(unsigned)(short)(0x7fffffffu & (unsigned)(a0[u1 & 3u] < 6u));
    if (*mp) goto L4;
    *mp = (unsigned)d0;
    if (budget != 0u) { budget -= 1u; u3 = fn3((garr[u2 & 7u] << ((unsigned)l0 & 31u)), (garr[i1 & 7u] >> ((unsigned)((int)0xb90f42a3u < (int)0xdcb6beb8u) & 31u)), (garr[u2 & 7u] + (unsigned)(v0 == garr[i1 & 7u]))); }
    goto L1;
    u2 += ((unsigned)(w0 >> 29) + (unsigned)((unsigned)((unsigned)c1 && 0xffffffffu) || (unsigned)f0));
    u3 = (garr[i1 & 7u] % ((unsigned)((int)(unsigned)s1 >= (int)v0) | 1u));
    if (~(u1 & fuel)) {
        if (((unsigned)(0xb2123f1cu < 0x8e664f4au) * a0[u1 & 3u])) goto L1;
        if ((unsigned)e0) {
            c1 = (signed char)((unsigned)(0xa8ecbc96u < 0x8ef9ec8cu) % (((unsigned)d0 >> ((unsigned)s0 & 31u)) | 1u));
            do { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)((unsigned)(x0 >> 70) && u2);
                h1 = (unsigned short)(h1 + ((unsigned)b0 * a0[i0 & 3u]));
            } while (i0++ < 6u && 0xc4c84235u);
            *mp = (((unsigned)((int)(0x3d770d9du >> (0x10000u & 31u)) < (int)r0.y) >> (0xffffffffu & 31u)) ^ (unsigned)(w0 >> 29));
            L0: if (--fuel == 0u) goto done;
        }
        switch ((*q0 - p0) & 7u) {
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 2u: ;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)(((unsigned)w0 >> ((p2 ^ 0xffffffffu) & 31u)));
                }
                if ((unsigned)(u3 || a0[i0 & 3u])) {
                    if (budget != 0u) { budget -= 1u; u1 = fn2(fuel, m0, (r0.y >> ((unsigned)h1 & 31u))); }
                    *q0 = ((a0[u1 & 3u] % ((unsigned)s1 | 1u)) | m0);
                    b0 = ((unsigned)!((0xffffffffu & (unsigned)w0) / (0xf73e8738u | 1u)) | 9u) != 0u;
                    switch ((unsigned)(unsigned char)((unsigned)((unsigned)h0 == i0) * u3) & 7u) {
                        *q0 = (0x7fffffffu >> (u3 & 31u));
                        i0 = (0x5f815e75u ? *q0 : *mp) & 15u;
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(((unsigned)(x0 >> 70) | m0) < (unsigned)s1), g0, (unsigned)(r0.y && 0x2207b2dcu)); }
                }
            }
            if ((0x80000000u >> ((unsigned)(garr[i1 & 7u] || a0[u1 & 3u]) & 31u))) goto L1;
            break; (void)((unsigned)((int)u1 >= (int)p0));
            f0 = f0 * 0.5f + (float)((0xffffffffu * 0x9bc25db8u) & 255u);
        }
        *q0 = (unsigned)s1;
    } else {
        if ((g1 / ((unsigned)l0 | 1u))) {
            u0 ^= (unsigned)(*q0 < 9u);
            if (0x7fffffffu) goto L4;
            *q0 += (unsigned)(unsigned char)(r0.y ? fuel : (unsigned)((unsigned)h0 < v0));
            if (0xbfed6e85u) goto L0;
        } else {
            if ((8u % (1u | 1u))) goto L3;
            c1 = (signed char)((unsigned)h0 ^ a0[i0 & 3u]);
            d0 = d0 * 0.5 + (double)(garr[u2 & 7u] & 1023u);
        }
        w0 = w0 * 6364136223846793005ull + 0x1d43184bu;
        u3 += (garr[u2 & 7u] - (r0.y - (unsigned)f0));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn3(m0, ((unsigned)f0 - 0x7fffffffu), (unsigned)(p0 == garr[i1 & 7u])); }
    { unsigned t0; double z0; if ((u2) & 1u) { t0 = (unsigned)e0; z0 = (double)((garr[i1 & 7u]) & 255u); } if ((u2) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        if (((unsigned)(signed char)(i1 >> ((unsigned)w0 & 31u)) / (fuel | 1u))) {
            switch ((v0 >> (0x7aa129e2u & 31u)) & 7u) {
                v0 = ~(unsigned)((int)(unsigned)h0 >= (int)g1);
            }
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0(i1, (unsigned)c1, (p0 - (unsigned)(g0 < (unsigned)f0))); }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)c1, ((unsigned)(u2 == g0) << (a0[u1 & 3u] & 31u)), (0xbf643b63u | (unsigned)f0)); }
            }
            if (p2) {
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)h1, 0x7fffffffu, (u1 >> ((u0 ^ m0) & 31u))); }
                c1 = (signed char)(unsigned)((unsigned)(w0 >> 29) || (unsigned)(3u == (unsigned)(0x10000u < (unsigned)((unsigned)(w0 >> 29) && u2))));
                goto L4;
                for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    u2 += (u1 << ((unsigned)!(v0 % ((unsigned)(*mp || (unsigned)h1) | 1u)) & 31u));
                    l0 = (long)((unsigned long)l0 + (unsigned)(0x45dbc7efu || 0x2773a393u));
                    goto L2;
                    L1: if (--fuel == 0u) goto done;
                    while (i1++ < 7u && (unsigned)((unsigned)h0 == (g1 - garr[u2 & 7u]))) { if (--fuel == 0u) goto done;
                        c1 = (signed char)((unsigned)(g1 && (unsigned)l0) ? (unsigned)d0 : 0x80000000u);
                        if (budget != 0u) { budget -= 1u; u2 = fn0(fuel, (0x778bf82au & (unsigned)!((unsigned)c1 * 0x6cbd2d0fu)), 5u); }
                        i2 = ((unsigned)((unsigned)((int)0x80000000u < (int)u0) || *mp) / ((unsigned)(g0 == u1) | 1u)) & 15u;
                        L2: if (--fuel == 0u) goto done;
                        c0 = (unsigned char)((unsigned)h0 - (unsigned)!(unsigned)((int)(unsigned)s0 < (int)(unsigned)(x0 >> 70)));
                        L3: if (--fuel == 0u) goto done;
                    }
                    if (u3 == 7u) return (unsigned)((int)((garr[i1 & 7u] + g0) - ((unsigned)f0 / ((unsigned)e0 | 1u))) >= (int)i1);
                }
                a0[(unsigned)((short)m0 > (signed char)(unsigned)c1) & 3u] = ((unsigned)(unsigned char)(unsigned)(i1 < *mp) % ((garr[u2 & 7u] + (0x10000u & (unsigned)h1)) | 1u));
                f0 = f0 * 0.5f + (float)(((unsigned)(signed char)(unsigned)((int)(unsigned)s1 < (int)0xdd28a2b9u) << ((unsigned)((unsigned)d0 == *mp) & 31u)) & 255u);
            } else {
                g1 += (unsigned)((int)u2 >= (int)*q0);
                if ((a0[u1 & 3u] + (unsigned)!(unsigned)(0x15d15319u || 0x34ee1f98u))) goto L4;
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)w0, (unsigned)((int)0x10000u >= (int)0xffffffffu), (2u * garr[u2 & 7u])); }
            }
            { unsigned t1; double z1; if (((unsigned)c1) & 1u) { t1 = (unsigned)(x0 >> 70); z1 = (double)(((0x80000000u ^ 6u)) & 255u); } if (((unsigned)c1) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                *mp = (i1 & (unsigned)s1);
                r0.x = ((unsigned)((int)2u < (int)m0) * u3);
                s1 = (int)((unsigned)s1 + (unsigned)((p0 | (unsigned)(p1 && (0x80000000u % (r0.y | 1u)))) == 0x65123658u));
            }
            if (0xb9e6ff5bu) goto L1;
        }
        if ((7u & (unsigned)h0)) {
            if ((unsigned)(signed char)(unsigned)(0x8fdaa076u || (unsigned)(0x7fffffffu || (unsigned)f0))) {
                { unsigned t2; double z2; if ((((*mp & a0[u1 & 3u]) * p1)) & 1u) { t2 = garr[i1 & 7u]; z2 = (double)(((unsigned)f0) & 255u); } if ((((*mp & a0[u1 & 3u]) * p1)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)s0, (0x4b9324bfu * u2), (unsigned)(short)((unsigned)((int)(unsigned)x0 >= (int)p2) + (unsigned)c1)); }
                    if ((unsigned)(fuel < 3u)) goto L0;
                    if ((unsigned)((fuel >> (r0.x & 31u)) || p2)) goto L2;
                    if ((a0[u1 & 3u] / ((u2 << (u2 & 31u)) | 1u))) goto L0;
                    L4: if (--fuel == 0u) goto done;
                }
                c0 = (unsigned char)0x10000u;
                if ((unsigned)(a0[u1 & 3u] && (unsigned)w0)) goto done;
                if ((unsigned)!(a0[i0 & 3u] / ((unsigned)f0 | 1u))) {
                    if ((0x933f6a34u << ((unsigned)f0 & 31u))) goto L1;
                    if ((unsigned)((unsigned)b0 == (unsigned)b0)) goto L4;
                    g1 += ((unsigned)d0 ^ (unsigned)c0);
                    { unsigned t3; double z3; if (((fuel % ((unsigned)b0 | 1u))) & 1u) { t3 = r0.y; z3 = (double)(((unsigned)((0x10000u + 7u) && g1)) & 255u); } if (((fuel % ((unsigned)b0 | 1u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        u3 ^= (unsigned)((g1 >> (-(unsigned)((int)(unsigned)(w0 >> 29) < (int)a0[u1 & 3u]) & 31u)) < (unsigned)x0);
                    }
                }
                if ((unsigned)((int)(unsigned)f0 < (int)(unsigned)s0)) {
                    l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(unsigned)((int)((6u - r0.x) & (unsigned)h1) >= (int)(9u ^ (unsigned)l0)));
                    if (0xa0bf8c0fu) goto L1;
                    garr[(unsigned)f0 & 7u] = p2;
                    v0 = (0u / ((unsigned)((unsigned)e0 == (0x7fffffffu >> (6u & 31u))) | 1u));
                } else {
                    q0 = &garr[(unsigned)(signed char)(unsigned)((int)a0[i0 & 3u] < (int)p2) & 7u];
                    goto L1;
                    if (0x10000u) goto L0;
                    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)b0 / (((unsigned)h0 | (unsigned)d0) | 1u)), ((u1 / ((unsigned)w0 | 1u)) / (0x10000u | 1u)), (unsigned)(1u && 8u)); }
                }
                l0 = (long)((unsigned long)l0 + (unsigned)c0);
            } else {
                { unsigned t4; double z4; if ((0x4b54bc0eu) & 1u) { t4 = (0x7fffffffu | 0x80000000u); z4 = (double)((9u) & 255u); } if ((0x4b54bc0eu) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    if (budget != 0u) { budget -= 1u; u0 = fn3(((unsigned)c0 | 0xffffffffu), u1, (unsigned)(v0 == 0x80000000u)); }
                    if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(6u == ~(unsigned)((int)(unsigned)l0 < (int)(unsigned)(x0 >> 70))), (i0 ? (unsigned)h0 : i2), (8u % (g0 | 1u))); }
                }
                c1 = (signed char)(unsigned)b0;
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)((short)0xffffffffu > (signed char)8u));
                    goto L3;
                    for (;;) { if (--fuel == 0u) goto done;
                        if (((unsigned)w0 % (0xea15a58fu | 1u))) goto L0;
                        if (budget != 0u) { budget -= 1u; u2 = fn3((fuel << (-(a0[i0 & 3u] & (unsigned)(w0 >> 29)) & 31u)), ((unsigned)h0 ^ (u0 / ((unsigned)d0 | 1u))), (garr[u2 & 7u] | 9u)); }
                        if ((unsigned)(unsigned char)(unsigned)((unsigned)(i2 && (unsigned)s1) == 0x8860f988u)) break;
                    }
                }
                u0 += (unsigned)s1;
            }
            garr[(unsigned)s0 & 7u] = (0xffffffffu ^ ((unsigned)s1 * 3u));
            q0 = &garr[(unsigned)(i0 && (unsigned)s0) & 7u];
            if ((unsigned)((int)p0 < (int)(i1 + m0))) {
                switch ((unsigned)(0x7ecce59cu && (1u * 8u)) & 7u) {
                    if (u3 == 7u) return (unsigned)((garr[u2 & 7u] + (unsigned)(garr[i1 & 7u] && g1)) && 0xffffffffu);
                    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (9u) {
                            if ((r0.x * garr[i1 & 7u])) continue;
                            case 5u: ;
                            *q0 += (unsigned)f0;
                            if (budget != 0u) { budget -= 1u; u0 = fn0(-((unsigned)x0 | (0xffffffffu - v0)), (unsigned)(unsigned char)((unsigned)b0 / (0xffffffffu | 1u)), (unsigned)((5u << (p0 & 31u)) == (unsigned)(x0 >> 70))); }
                            continue; (void)((1u ^ *q0));
                        }
                        case 6u: ;
                        garr[(u3 & p1) & 7u] = (unsigned)((unsigned)((unsigned)e0 || 2u) || 0x7fffffffu);
                        if (budget != 0u) { budget -= 1u; u2 = fn3(g1, 0u, (unsigned)s0); }
                        if (u1) goto L2;
                        m0 ^= (g1 % (0x7fffffffu | 1u));
                    }
                }
                switch (((2u << ((unsigned)b0 & 31u)) / ((unsigned)d0 | 1u)) & 7u) {
                    h1 = (unsigned short)(h1 + ((unsigned)s1 - (unsigned)w0));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((0u + v0) && (unsigned)h1), ((0x80000000u * 7u) + 0x10000u), (unsigned)(signed char)((unsigned)b0 % ((unsigned)(0xffffffffu && 0x3f0d2a47u) | 1u))); }
                goto L2;
                a0[(unsigned)l0 & 3u] = (((unsigned)(short)(unsigned)(a0[i0 & 3u] == ((unsigned)(w0 >> 29) + 9u)) + (unsigned)w0) >> (a0[u1 & 3u] & 31u));
                if (budget != 0u) { budget -= 1u; u2 = fn3((3u | (unsigned)(0x10000u < 0x140017edu)), (unsigned)((int)(unsigned)h1 < (int)(1u * p2)), (*mp << (u3 & 31u))); }
            }
            if ((unsigned)x0) goto L2;
        } else {
            g0 = ((u0 & g0) * (unsigned)(unsigned char)(((unsigned)w0 * (unsigned)b0) & i1));
        }
    }
    do { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((u2 ^ a0[i0 & 3u]) & 1023u);
        q0 = &garr[((unsigned)s1 * (unsigned)x0) & 7u];
        if ((unsigned)w0) break;
    } while (i0++ < 6u && ((unsigned)s1 - (r0.x ^ (unsigned)(x0 >> 70))));
    if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)x0, (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)x0), (unsigned)((int)p2 >= (int)i0)); }
    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(0xbe8ecadau || ((unsigned)b0 + 0xffffffffu)), 0x80000000u, 3u); }
    g1 += (unsigned)d0;
    do { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(unsigned)h1;
        if ((u3 + m0)) continue;
        m0 ^= ((unsigned)((short)0x80000000u > (signed char)fuel) << ((p1 % (*q0 | 1u)) & 31u));
        break; (void)((unsigned)(0x4830df7bu || (unsigned)((int)a0[u1 & 3u] < (int)fuel)));
    } while (i0++ < 5u && ((unsigned)((unsigned)(w0 >> 29) && r0.y) ^ 0x7fffffffu));
    switch (u0 & 7u) {
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(x0 >> 70), (unsigned)h0, i2); }
        g1 += (unsigned)((7u & (unsigned)c1) && garr[i1 & 7u]);
        *q0 += i1;
        case 7u: ;
        d0 = d0 * 0.5 + (double)(((unsigned)(0x80000000u || 5u) | 1u) & 1023u);
        if ((unsigned)(signed char)(unsigned)(0x199a5b33u || 0x8c84ef56u)) {
            d0 = d0 * 0.5 + (double)(((9u >> (0u & 31u)) % (9u | 1u)) & 1023u);
        } else {
            { unsigned t5; double z5; if ((v0) & 1u) { t5 = (unsigned)s1; z5 = (double)((0xa3c36612u) & 255u); } if ((v0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                case 6u: ;
                c0 = (unsigned char)(unsigned)(0xc5d89453u && (m0 ? fuel : v0));
                case 3u: ;
                u2 ^= (unsigned)(short)(g1 << (0x78b7eddbu & 31u));
                { unsigned t6; double z6; if ((0xeac3961bu) & 1u) { t6 = ((unsigned)e0 % ((0xdc896c7au % ((unsigned)c0 | 1u)) | 1u)); z6 = (double)(((a0[u1 & 3u] << (0xffffffffu & 31u))) & 255u); } if ((0xeac3961bu) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                    if (budget != 0u) { budget -= 1u; u1 = fn1((((unsigned)h1 ^ 0x10000u) << ((unsigned)d0 & 31u)), (g0 * 0x10000u), (unsigned)(0x17b6d8a1u && garr[i1 & 7u])); }
                    { unsigned t7; double z7; if (((unsigned)((short)fuel > (signed char)i0)) & 1u) { t7 = 0x7fffffffu; z7 = (double)(((r0.x / ((unsigned)((int)i2 < (int)p2) | 1u))) & 255u); } if (((unsigned)((short)fuel > (signed char)i0)) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                        *q0 += (u0 * (unsigned)(signed char)(unsigned)((int)(unsigned)h1 >= (int)g0));
                        if (a0[u1 & 3u]) goto done;
                    }
                }
            }
        }
    }
    goto L1;
    m0 ^= (a0[i0 & 3u] >> (p1 & 31u));
    if (~(i2 & 0xe9ad2919u)) {
        u2 = ((p0 | i1) % ((unsigned)((unsigned)((int)0x7fffffffu < (int)fuel) || 0x27980b55u) | 1u));
        if (((unsigned)((short)garr[i1 & 7u] > (signed char)p1) - (unsigned)s0)) goto L2;
        r0.y ^= (((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)c0) % ((3u / (r0.x | 1u)) | 1u)) >> (0x212160fu & 31u));
    } else {
        u2 += ((p1 ^ 0xe4010863u) | m0);
        s1 = (int)((unsigned)s1 + (u1 ? (unsigned)(fuel && (unsigned)c1) : i0));
        if ((unsigned)f0) goto L2;
        if ((unsigned)(*q0 == 0x5e3fd3eeu)) goto L0;
    }
    a0[(unsigned)(signed char)(0x80000000u + (unsigned)f0) & 3u] = (unsigned)(short)(r0.y & 0x5186adbcu);
    u1 = ((i1 ? p2 : p2) ? p2 : 0x2a7bde1au);
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2((0x10000u ? v0 : 0x10000u), (9u - r0.x), 0x797e1734u); }
        w0 = w0 * 6364136223846793005ull + (i0 | 0xefde6741u);
        switch ((unsigned)((unsigned)h0 && (m0 % ((unsigned)w0 | 1u))) & 7u) {
            case 5u: ;
            if (((unsigned)w0 << (0x9069ad1fu & 31u))) continue;
            r0.y ^= (0x7c3f9b98u ^ (m0 ? 6u : (garr[u2 & 7u] + u0)));
        }
        u1 = u1 * 0x9e3779b1u + (0x80000000u * (unsigned)l0);
        if ((g1 << (0xffffffffu & 31u))) break;
        while (i1++ < 3u && (unsigned)((int)-(3u + *q0) < (int)(unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
            u0 += u2;
            if (((unsigned)(i2 || 0x10000u) * (unsigned)h1)) break;
        }
    } while (i0++ < 6u && (unsigned)h0);
    if ((unsigned)f0) {
        if ((garr[u2 & 7u] - u1)) {
            a0[6u & 3u] = (unsigned)b0;
            g1 += (unsigned)(g1 && (unsigned)c0);
            if (0x80000000u) goto L3;
        } else {
            if (u2) goto L1;
            do { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(((unsigned)(0xbe65e4d4u || (6u + (unsigned)s0)) << ((unsigned)d0 & 31u)) & 1023u);
                if ((unsigned)((unsigned)(x0 >> 70) < g0)) break;
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)0x80000000u >= (int)(unsigned)(unsigned char)((unsigned)s1 << (u3 & 31u)))) break;
                    u0 += v0;
                    do { if (--fuel == 0u) goto done;
                        break; (void)(g1);
                        if (budget != 0u) { budget -= 1u; u3 = fn2(m0, (5u << (0u & 31u)), u2); }
                        if ((unsigned)((int)0x7fffffffu < (int)(unsigned)((short)5u > (signed char)g0))) break;
                    } while (i2++ < 3u && (unsigned)(9u || u1));
                    while ((unsigned)((0x606bd552u * 0xd5f698u) < (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
                        if (garr[i1 & 7u]) break;
                        e0 = e0 * 0.5L + (long double)(((unsigned)(short)(0x7fffffffu & 0x4802768du) + (unsigned)f0) & 1023u);
                    }
                }
                c1 = (signed char)((0x80000000u % (u0 | 1u)) ? (unsigned)(u0 && 0x80000000u) : 0xffffffffu);
                v0 = 0xffffffffu;
            } while (i0++ < 3u && (r0.x * 8u));
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)((int)(0x68a5fa5u & 0xd3c69c2fu) < (int)(a0[u1 & 3u] / (garr[u2 & 7u] | 1u))) & 1023u);
                if (v0) {
                    q0 = &garr[(((unsigned)s0 >> (m0 & 31u)) ^ (unsigned)(((unsigned)l0 & (unsigned)c1) == (unsigned)c0)) & 7u];
                    *mp = 0x7fffffffu;
                    goto L0;
                    { unsigned t8; double z8; if (((unsigned)l0) & 1u) { t8 = ((9u & garr[i1 & 7u]) * a0[i0 & 3u]); z8 = (double)(((i1 - p1)) & 255u); } if (((unsigned)l0) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                        g0 = u1;
                    }
                } else {
                    if ((u3 * r0.y)) goto L2;
                    for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (p1) break;
                        b0 = (fuel - (unsigned)f0) != 0u;
                        h1 = (unsigned short)(h1 + (8u ? garr[u2 & 7u] : 4u));
                    }
                    d0 = d0 * 0.5 + (double)((unsigned)((7u << ((0xc2f877ebu | 6u) & 31u)) && (unsigned)c1) & 1023u);
                    do { if (--fuel == 0u) goto done;
                        r0.y ^= (unsigned)((0u % (g1 | 1u)) || i2);
                        a0[i1 & 3u] = ((unsigned)((unsigned)((int)9u < (int)g0) && g1) << (((unsigned)l0 & p2) & 31u));
                        if ((v0 ^ fuel)) break;
                        h0 = (short)r0.x;
                    } while (i1++ < 7u && (u0 % ((unsigned)((int)0x4c607d54u < (int)(unsigned)s0) | 1u)));
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0(((0xa64d96deu ^ (unsigned)h0) >> (3u & 31u)), (unsigned)d0, ((unsigned)s1 % (0x10000u | 1u))); }
                if ((0x7fffffffu % ((unsigned)((int)(unsigned)b0 < (int)0xa928a03bu) | 1u))) break;
            }
        }
        s0 = (int)((0x7fffffffu ? v0 : g0) | (unsigned)s1);
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                if (*q0) goto L4;
                i0 = i1 & 15u;
            }
            u3 = 8u;
            u2 ^= (unsigned)((int)0x51bd9056u < (int)((unsigned)(5u == 0x3fdb1448u) * fuel));
            if (0x41aa408u) break;
        }
        if ((~(r0.y + 0xffffffffu) / ((unsigned)f0 | 1u))) {
            c1 = (signed char)(unsigned)((int)((unsigned)((int)g1 < (int)i2) ^ (unsigned)w0) >= (int)p0);
            *mp = (((unsigned)w0 - (0x2d1e860cu | i0)) << (5u & 31u));
        }
        *q0 = -((7u & ((unsigned)b0 | (unsigned)w0)) + (0x69c376e2u * i1));
        if ((garr[u2 & 7u] - (unsigned)c0)) {
            v0 = (unsigned)(0x99fde83du && (unsigned)(~(unsigned)((short)u1 > (signed char)7u) || u1));
            goto L2;
            if (budget != 0u) { budget -= 1u; u0 = fn1((a0[i0 & 3u] * 0x7fffffffu), i1, (fuel + (unsigned)(i0 == 0x7fffffffu))); }
        }
    } else {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.x = (((unsigned)((int)r0.x < (int)6u) | 6u) / ((unsigned)!(p2 ^ v0) | 1u));
            for (;;) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(((unsigned)(~(p0 + u1) || 1u) - 0x879c4c2eu) & 255u);
                break; (void)(9u);
                u2 += (unsigned)(signed char)(p0 ^ (unsigned)x0);
                *q0 += (unsigned)(v0 == (unsigned)(garr[i1 & 7u] || ((unsigned)s0 - a0[u1 & 3u])));
            }
            goto L0;
        }
        l0 = (long)((unsigned long)l0 + ((3u ? 3u : u1) * 0x80000000u));
    }
    if ((8u ^ p0)) {
        if (r0.y) goto L0;
    } else {
        while (p1) { if (--fuel == 0u) goto done;
            while (i1++ < 6u && (v0 * (unsigned)((int)(unsigned)h1 < (int)6u))) { if (--fuel == 0u) goto done;
                r0.y ^= (g0 | 0x2c703a79u);
                u0 = u0 * 0x9e3779b1u + (((unsigned)f0 | 0x47fc783bu) << (r0.x & 31u));
                if ((fuel ? (unsigned)x0 : i0)) break;
                c0 = (unsigned char)(((0x25a42065u << (p0 & 31u)) / (0x8178dbdbu | 1u)) + a0[i0 & 3u]);
                garr[*mp & 7u] = ~((unsigned)((unsigned)h0 < garr[i1 & 7u]) / (((unsigned)h1 ^ (4u << ((unsigned)s0 & 31u))) | 1u));
            }
            continue; (void)((unsigned)((unsigned)f0 && p1));
        }
        if ((0x10000u + *mp)) goto L4;
        m0 ^= (unsigned)((int)(7u % ((unsigned)x0 | 1u)) < (int)(unsigned)l0);
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((7u >> ((unsigned)d0 & 31u)), ((unsigned)w0 << ((unsigned)l0 & 31u)), (5u | (unsigned)((short)(unsigned)s1 > (signed char)(unsigned)(x0 >> 70)))); }
    if ((unsigned)b0) goto L4;
    h0 = (short)-(0xca0756d7u ? i0 : (unsigned)!((unsigned)c1 | r0.y));
    h0 = (short)(unsigned)(0xe54aba59u == (unsigned)((short)7u > (signed char)(unsigned)((int)m0 >= (int)(unsigned)((short)u1 > (signed char)0xaa3839ddu))));
    goto L0;
    *q0 += (unsigned)!(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(((unsigned)x0 - r0.y) - (6u | (unsigned)e0)));
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = (unsigned)(r0.y < garr[u2 & 7u]);
    }
    if (9u) {
        *mp = (unsigned)((int)(g0 << ((unsigned)l0 & 31u)) >= (int)((unsigned)l0 - (unsigned)s1));
        do { if (--fuel == 0u) goto done;
            u0 ^= ((unsigned)((int)0x7fffffffu >= (int)(unsigned)(a0[i0 & 3u] && (unsigned)h1)) + 0xbb2d23adu);
            r0.y ^= (unsigned)w0;
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(u3 || (8u & r0.x)), 4u, ((unsigned)l0 + (unsigned)((int)r0.x < (int)a0[i0 & 3u]))); }
            while ((2u % (0x80000000u | 1u))) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)(i2 || i2));
                } while (i2++ < 6u && 1u);
                if (fuel < 8u) return (unsigned)(short)(((unsigned)s0 * *mp) * 4u);
                if (((unsigned)s1 * 3u)) break;
                if (budget != 0u) { budget -= 1u; u0 = fn3(a0[i0 & 3u], 0x80000000u, (((unsigned)s0 << (0x10000u & 31u)) | (unsigned)(w0 >> 29))); }
                if (((unsigned)c0 ? r0.x : *mp)) goto L1;
                if (0xffffffffu) break;
            }
            h0 = (short)((unsigned)((unsigned)h0 && 0x7fffffffu) + 4u);
        } while (i0++ < 2u && (unsigned)(0x4e563bf4u && 0xcbff9f5cu));
        garr[(2u - p0) & 7u] = (unsigned)(0x23164190u == (unsigned)(4u < ((unsigned)((int)6u < (int)(unsigned)c0) ^ m0)));
        if ((unsigned)((int)0xffffffffu >= (int)(*mp >> (u2 & 31u)))) goto L2;
    } else {
        if ((0x80000000u >> (i1 & 31u))) goto L3;
        goto L4;
    }
    goto L4;
    while (i0++ < 7u && (unsigned)(short)(i1 | (unsigned)x0)) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn3((0x7fffffffu % (g0 | 1u)), ((unsigned)((short)r0.x > (signed char)(unsigned)e0) / (r0.x | 1u)), (unsigned)s0); }
        if ((p1 | p0)) break;
    }
    r0.x = (unsigned)((int)*mp < (int)0x10000u);
    if (budget != 0u) { budget -= 1u; u2 = fn3((g1 ^ p0), (unsigned)((unsigned)c1 && i2), fuel); }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(signed char)(0x275ed196u - 4u)) break;
        break; (void)((unsigned)((short)garr[u2 & 7u] > (signed char)(0x80000000u + 0x7fffffffu)));
        if ((unsigned)(short)((unsigned)b0 + (i0 % (6u | 1u)))) goto L2;
        goto L4;
        do { if (--fuel == 0u) goto done;
            *mp = (unsigned)(signed char)(unsigned)((unsigned)c1 < 0x7fffffffu);
            if (p0) break;
        } while (i1++ < 5u && (((unsigned)b0 | (unsigned)(w0 >> 29)) | u1));
        break; (void)((unsigned)((unsigned)f0 || garr[i1 & 7u]));
    } while (i0++ < 5u && 0x10000u);
    if ((unsigned)((unsigned)d0 || garr[u2 & 7u])) goto L0;
    do { if (--fuel == 0u) goto done;
        a0[(0x27b19075u << ((unsigned)f0 & 31u)) & 3u] = (-(i2 >> (0u & 31u)) ^ ((unsigned)((int)(unsigned)x0 < (int)i0) % ((unsigned)s1 | 1u)));
        if (((5u - 3u) | (unsigned)w0)) goto L0;
        while (i1++ < 5u && ((0x14344289u << (v0 & 31u)) << (i2 & 31u))) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)u3 << ((garr[u2 & 7u] % ((unsigned)h0 | 1u)) & 63u);
            h1 = (unsigned short)(h1 + (0x7fffffffu % ((((p0 << ((unsigned)h0 & 31u)) - (unsigned)w0) + (unsigned)h1) | 1u)));
            switch ((unsigned)(0xffffffffu || *mp) & 7u) {
                continue; (void)(~((unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)d0) >> (p1 & 31u)));
            }
        }
        if (((unsigned)((int)(unsigned)l0 < (int)0x7fffffffu) & (unsigned)c1)) {
            *q0 = ((unsigned)(a0[u1 & 3u] == i1) / (a0[i0 & 3u] | 1u));
            h0 = (short)(i1 << ((9u ^ 0x7fffffffu) & 31u));
            if (0xe56a4542u) break;
            { unsigned t9; double z9; if (((unsigned)f0) & 1u) { t9 = 3u; z9 = (double)(((unsigned)((a0[i0 & 3u] << ((unsigned)s0 & 31u)) && (unsigned)x0)) & 255u); } if (((unsigned)f0) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                b0 = (fuel + (i2 + 0x80000000u)) != 0u;
            }
            if ((unsigned)((int)(0xae7bd14eu & 8u) >= (int)u3)) continue;
        }
        do { if (--fuel == 0u) goto done;
            r0.x = (unsigned)((int)((unsigned)d0 >> (0xffffffffu & 31u)) < (int)(((unsigned)s0 - 0x24da267bu) & *mp));
        } while (i1++ < 3u && 6u);
    } while (i0++ < 3u && g1);
    if ((0x10000u ^ 0x110d969fu)) goto L3;
    if ((unsigned)(((unsigned)s0 / ((unsigned)l0 | 1u)) && 4u)) goto L2;
    goto L0;
    *q0 = (unsigned)((unsigned)((short)u3 > (signed char)(0xe7051958u & (unsigned)h1)) && i1);
    h1 = (unsigned short)(h1 + (unsigned)!(unsigned)((short)(i2 / (0x80000000u | 1u)) > (signed char)(u1 >> ((a0[u1 & 3u] & 8u) & 31u))));
    switch ((i1 ^ *mp) & 7u) {
        while (((unsigned)h0 % ((unsigned)(0x63cd9269u && p1) | 1u))) { if (--fuel == 0u) goto done;
            if ((unsigned)s1) {
                if (budget != 0u) { budget -= 1u; u3 = fn1(p0, (garr[u2 & 7u] ^ (unsigned)(u3 || 1u)), (r0.x >> ((unsigned)((int)0x80000000u >= (int)u1) & 31u))); }
                *q0 = (u3 + ((0x5211ba56u << ((unsigned)((unsigned)h1 == (unsigned)b0) & 31u)) + i1));
                do { if (--fuel == 0u) goto done;
                    r0.x = u0;
                    w0 = w0 * 6364136223846793005ull + (((unsigned)l0 * (unsigned)e0) << ((unsigned)((a0[u1 & 3u] - (unsigned)h0) == p2) & 31u));
                    case 6u: ;
                    default: ;
                } while (i1++ < 5u && ((unsigned)s1 % (*q0 | 1u)));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)x0 == (0u ^ u0)), (a0[i0 & 3u] >> (2u & 31u)), 0x7fffffffu); }
            if ((~(0x6a4049e1u | (unsigned)c1) | (unsigned)(w0 >> 29))) {
                case 1u: ;
            }
            r0.y ^= 5u;
            f0 = f0 * 0.5f + (float)(((unsigned)((unsigned)(w0 >> 29) && ((0x3ce2a98fu * a0[u1 & 3u]) << ((unsigned)s0 & 31u))) >> ((unsigned)c0 & 31u)) & 255u);
        }
        s1 = (int)((unsigned)s1 + ((unsigned)((short)0xbd48ad0fu > (signed char)(unsigned)f0) >> (0x7fffffffu & 31u)));
        w0 = w0 * 6364136223846793005ull + (unsigned)(*q0 < (i2 % ((0xffffffffu | (m0 - p0)) | 1u)));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 12u, 0x81d832d6u, 0x4d5659b4u },
        { 11u, 0x44dcbc38u, 0x3c6057b5u },
        { 12u, 0xc19eccabu, 0x173d97ebu },
        { 6u, 0xc3c4a09du, 0xc8d02d71u },
        { 1u, 0xb0e953acu, 0xe85d9070u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
