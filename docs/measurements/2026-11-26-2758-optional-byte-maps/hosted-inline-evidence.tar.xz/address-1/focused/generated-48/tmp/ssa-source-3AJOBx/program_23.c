// test-ssa-source's program of seed 134000425 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x9e9565feu, g1 = 0xf10baaacu;
static unsigned garr[8] = { 0x96ac1558u, 0xff886853u, 0x42be20b0u, 0xef2e9642u, 0x9fa0e652u, 0x97f976eau, 0xa05f1870u, 0x1697d98u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L3;
    if ((u3 ? 0xffffffffu : v0)) goto L4;
    h0 = (short)(unsigned)(short)(i1 / (g1 | 1u));
    do { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        break; (void)((unsigned)((short)((unsigned)l0 - m0) > (signed char)0x9ab6b761u));
    } while (i0++ < 4u && (unsigned)((unsigned)h1 && 0xffffffffu));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(0x6316f45fu >> ((unsigned)((unsigned)((short)0x10000u > (signed char)(4u - 0x80000000u)) && 0xffffffffu) & 31u));
        *q0 = (0x10000u * (garr[u2 & 7u] / (9u | 1u)));
        if ((unsigned)((unsigned)e0 < (unsigned)e0)) {
            r0.x = (unsigned)((short)m0 > (signed char)((a0[i0 & 3u] ? 0x7fffffffu : (unsigned)e0) * (unsigned)(x0 >> 70)));
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t0; double z0; if (((0xd36ce112u ? m0 : 0x10000u)) & 1u) { t0 = (unsigned)f0; z0 = (double)(((unsigned)((unsigned)e0 == 0xffffffffu)) & 255u); } if (((0xd36ce112u ? m0 : 0x10000u)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                    i1 = (unsigned)((unsigned)e0 && *mp) & 15u;
                    L1: if (--fuel == 0u) goto done;
                }
                while (i2++ < 5u && i0) { if (--fuel == 0u) goto done;
                    u2 += (unsigned)(short)(unsigned)((int)(unsigned)f0 < (int)*mp);
                    r0.y ^= ((unsigned)w0 - (p1 >> ((unsigned)s0 & 31u)));
                    L2: if (--fuel == 0u) goto done;
                    *mp = (unsigned)(2u && g1);
                    w0 ^= (unsigned long long)0x10000u << ((unsigned)h1 & 63u);
                }
                break; (void)(6u);
            }
            do { if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
            } while (i1++ < 7u && 0x4cd14475u);
            if ((0xffffffffu - r0.y)) goto L1;
            v0 = i2;
        } else {
            do { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    while (i0++ < 4u && (unsigned)((unsigned)x0 == (unsigned)c1)) { if (--fuel == 0u) goto done;
                        m0 ^= (unsigned)h1;
                        switch (u3 & 7u) {
                            a0[(unsigned)((short)u2 > (signed char)fuel) & 3u] = (unsigned)((int)(unsigned)((int)u1 < (int)(unsigned)x0) >= (int)(0xffffffffu - ((unsigned)h1 - garr[u2 & 7u])));
                        }
                    }
                } while (i2++ < 6u && ((unsigned)(unsigned char)(p1 & (unsigned)h0) & 5u));
                *q0 = (unsigned)((unsigned)e0 || (garr[u2 & 7u] - (unsigned)e0));
                u2 = u2 * 0x9e3779b1u + (unsigned)((int)garr[u2 & 7u] < (int)(u2 >> (*q0 & 31u)));
            } while (i1++ < 7u && (*mp / ((unsigned)(i2 && (unsigned)x0) | 1u)));
            if ((i0 | (unsigned)x0)) {
                if ((fuel ^ u0)) goto done;
            }
        }
    }
    s0 = (int)-((unsigned)c1 + ~(p0 | (0xb94b6268u + 0xf6b7cba3u)));
    f0 = f0 * 0.5f + (float)(r0.y & 255u);
    L4: if (--fuel == 0u) goto done;
    if (r0.x) {
        goto L0;
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (0x407326u) break;
        }
        x0 = x0 * 0x100000001b3ull + ((unsigned)(unsigned char)(fuel % (i1 | 1u)) / ((unsigned)(p0 && 0x60a2ae58u) | 1u));
        e0 = e0 * 0.5L + (long double)((unsigned)((short)((unsigned)h1 | 0x80000000u) > (signed char)(unsigned)((int)(unsigned)(*q0 && p1) < (int)p1)) & 1023u);
        while (i0++ < 3u && i1) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((0x8446d716u ^ 0x80000000u) & 1023u);
            *mp = (unsigned)(short)(6u * 0x7fffffffu);
            h0 = (short)-(a0[i0 & 3u] << (p1 & 31u));
            if (*mp) break;
            if (i1) break;
            if (u2) {
                r0.y ^= ((unsigned)(a0[u1 & 3u] && (unsigned)d0) + garr[i1 & 7u]);
                break; (void)((*q0 & (unsigned)h0));
                do { if (--fuel == 0u) goto done;
                    if (9u) continue;
                    a0[g0 & 3u] = (unsigned)(short)(*q0 ? (unsigned)(x0 >> 70) : u3);
                } while (i1++ < 4u && (unsigned)((int)u3 < (int)((unsigned)d0 % (7u | 1u))));
            } else {
                l0 = (long)((unsigned long)l0 + (unsigned)((int)r0.y < (int)m0));
            }
        }
        goto L0;
    }
    if ((i2 * (unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) && (unsigned)s1))) goto L1;
    goto L3;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(x0 >> 70)) break;
    } while (i0++ < 3u && (unsigned)e0);
    if (garr[i1 & 7u]) goto L4;
    while (i0++ < 7u && (unsigned)(0x10000u < 0x80000000u)) { if (--fuel == 0u) goto done;
        if (((unsigned)((int)u3 < (int)8u) >> ((unsigned)w0 & 31u))) break;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)c0) goto L3;
            l0 = (long)((unsigned long)l0 + (unsigned)(short)(unsigned)(~(unsigned)((unsigned)(r0.y && (8u & 5u)) < 0x10000u) || i0));
            break; (void)((unsigned)(unsigned char)((unsigned)(w0 >> 29) << ((unsigned)h1 & 31u)));
            switch ((unsigned)((0x10000u ^ (unsigned)s0) == (unsigned)s0) & 7u) {
                continue; (void)((unsigned)(((unsigned)w0 << (u1 & 31u)) && *q0));
                { unsigned t1; double z1; if (((0x7fffffffu ? a0[u1 & 3u] : v0)) & 1u) { t1 = (0x80000000u / ((u2 % (g1 | 1u)) | 1u)); z1 = (double)(((unsigned)((unsigned)(r0.y || (unsigned)e0) == (unsigned)s1)) & 255u); } if (((0x7fffffffu ? a0[u1 & 3u] : v0)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    case 6u: ;
                }
                d0 = d0 * 0.5 + (double)(0xf9189801u & 1023u);
            }
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)d0 < (int)(5u ^ 0x10000u))) break;
                h1 = (unsigned short)(h1 + 7u);
                g0 = (unsigned)((short)m0 > (signed char)(unsigned)(w0 >> 29));
                if (u3 == 7u) return *q0;
            }
            w0 ^= (unsigned long long)(0x10000u ^ i0) << ((unsigned)((8u + 0x9609c475u) < (unsigned)(signed char)(unsigned)((int)u1 < (int)i0)) & 63u);
        }
        switch (~(u2 & (u1 & p1)) & 7u) {
            case 5u: ;
            case 2u: ;
            i1 = (unsigned)((unsigned)h1 && (unsigned)(p0 && 0x80000000u)) & 15u;
            while (((unsigned)s1 >> ((p2 >> (0xf6955f87u & 31u)) & 31u))) { if (--fuel == 0u) goto done;
                g0 = (((r0.x | -(v0 ^ m0)) << (u3 & 31u)) % (i2 | 1u));
                default: ;
                case 7u: ;
                if ((unsigned)h1) continue;
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)((m0 | 0x80000000u) || 0u) & 1023u);
                    s1 = (int)((unsigned)s1 + (-(unsigned)((int)p0 >= (int)(unsigned)(((unsigned)f0 + 0x401b8c88u) < m0)) ^ (unsigned)b0));
                    break;
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        break;
                        if (((unsigned)(i0 && p1) % (0x80000000u | 1u))) continue;
                        w0 = w0 * 6364136223846793005ull + (4u ^ (garr[i1 & 7u] | ((0xde0ad3d2u * i2) | (unsigned)b0)));
                        switch ((unsigned)((int)u1 < (int)r0.y) & 7u) {
                            a0[(unsigned)l0 & 3u] = -(0xa6450b54u * (unsigned)d0);
                            e0 = e0 * 0.5L + (long double)((unsigned)(w0 >> 29) & 1023u);
                            u1 += (unsigned)((int)0u < (int)(unsigned)(unsigned char)(unsigned)((short)(unsigned)w0 > (signed char)0x57eaf405u));
                            x0 = x0 * 0x100000001b3ull + (0x10000u * 0xfb7ddf15u);
                            a0[6u & 3u] = (6u + (unsigned)(short)(unsigned)(0x78d0715bu || ((unsigned)f0 & (unsigned)s0)));
                            case 4u: ;
                        }
                        *mp = (unsigned)((int)(unsigned)((int)(unsigned)w0 < (int)(unsigned)((int)a0[u1 & 3u] >= (int)0x80000000u)) >= (int)(0x80000000u ^ u0));
                    }
                    goto L3;
                }
            }
            break;
            case 1u: ;
        }
        u0 = u0 * 0x9e3779b1u + (unsigned)(x0 >> 70);
        l0 = (long)((unsigned long)l0 + (m0 ^ (unsigned)((unsigned)h1 == 0x979f75fdu)));
        if (r0.y) {
            if (g1) continue;
            if ((unsigned)l0) break;
            if (a0[u1 & 3u]) break;
            do { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (2u) break;
                    if ((u2 ^ ((unsigned)s0 << ((unsigned)(w0 >> 29) & 31u)))) break;
                }
                if ((3u & (unsigned)(w0 >> 29))) break;
                { unsigned t2; double z2; if ((v0) & 1u) { t2 = (unsigned)((int)g1 < (int)((unsigned)h0 >> (*q0 & 31u))); z2 = (double)(((unsigned)(a0[u1 & 3u] < (a0[u1 & 3u] & 9u))) & 255u); } if ((v0) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    if ((unsigned)((0xffffffffu % (garr[u2 & 7u] | 1u)) == 0x7c4a4d1du)) break;
                    if ((unsigned)(3u < ((unsigned)s0 << (a0[u1 & 3u] & 31u)))) break;
                    if ((unsigned)(signed char)(1u / (2u | 1u))) break;
                }
                if ((unsigned)((int)(1u - u3) < (int)(unsigned)f0)) {
                    g1 += ((unsigned)c1 ^ p1);
                    q0 = &garr[(m0 % ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)b0) | 1u)) & 7u];
                } else {
                    while (i2++ < 5u && (unsigned)(1u == (unsigned)(i1 == (unsigned)d0))) { if (--fuel == 0u) goto done;
                        goto L2;
                    }
                    *mp = 0xb152b5edu;
                    break; (void)((unsigned)b0);
                }
                h1 = (unsigned short)(h1 + (m0 >> ((unsigned)l0 & 31u)));
            } while (i1++ < 6u && (u3 + i2));
            if (((unsigned)((int)(unsigned)(w0 >> 29) < (int)fuel) & g0)) break;
        } else {
            if ((m0 | ((unsigned)s0 | 8u))) goto L3;
            i0 = i2 & 15u;
            if ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)s0)) break;
            if (g0) break;
        }
    }
    if (garr[i1 & 7u]) {
        u3 += (unsigned)((unsigned)(u0 && (a0[u1 & 3u] << (i2 & 31u))) && (unsigned)(0xffffffffu && garr[u2 & 7u]));
        while (i0++ < 7u && (0u & (unsigned)c1)) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return (fuel >> (p1 & 31u));
                continue; (void)((p0 - (unsigned)(2u && g0)));
                x0 = x0 * 0x100000001b3ull + 0xc6460872u;
            }
            g0 = 0x80000000u;
            if ((1u ^ (7u - 0x80000000u))) {
                if (-(unsigned)(0x3c135f86u == 8u)) break;
            } else {
                q0 = &garr[(u1 - (v0 << ((unsigned)c1 & 31u))) & 7u];
            }
            switch ((unsigned)s0 & 7u) {
                c1 = (signed char)(unsigned)((unsigned)((int)4u >= (int)(unsigned)(i0 < 3u)) == -(unsigned)((short)garr[u2 & 7u] > (signed char)u1));
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)c0 || (u0 << (garr[u2 & 7u] & 31u))) & 255u);
                h0 = (short)(unsigned)((int)(unsigned)((unsigned)((unsigned)d0 || i0) || *mp) >= (int)r0.x);
                case 1u: ;
                a0[garr[i1 & 7u] & 3u] = (unsigned)(8u < (unsigned)(*mp || 0x10000u));
                h0 = (short)(unsigned)((int)(0xffffffffu & (unsigned)e0) >= (int)a0[u1 & 3u]);
            }
            break; (void)(u0);
            m0 ^= ((i0 | (unsigned)l0) & *mp);
        }
    }
    if ((unsigned)((unsigned)s0 == 4u)) goto L3;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)r0.y < (int)0xa2fe9cfdu)) break;
        while ((a0[i0 & 3u] & i2)) { if (--fuel == 0u) goto done;
            switch ((unsigned)(p2 && 0x2870befu) & 7u) {
                case 0u: ;
            }
            m0 ^= ((unsigned)(garr[u2 & 7u] && fuel) * (unsigned)(unsigned char)((unsigned)(g0 && 4u) - (unsigned)f0));
            g0 = ((unsigned)(short)(unsigned)((unsigned)s1 && (0x84a7f203u * garr[i1 & 7u])) + 0x80000000u);
            do { if (--fuel == 0u) goto done;
                i0 = (unsigned)c1 & 15u;
                switch (r0.y & 7u) {
                    u2 ^= (unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)w0));
                    switch ((unsigned)f0 & 7u) {
                        h1 = (unsigned short)(h1 + 5u);
                        if ((0x10000u | 0x7d03f4e9u)) goto L4;
                        s0 = (int)(g1 - ((m0 ^ m0) ^ g0));
                        r0.y ^= (1u ? (unsigned)((int)0xd2e0b693u >= (int)m0) : (v0 | a0[i0 & 3u]));
                    }
                    case 4u: ;
                }
                if (u1) break;
            } while (i2++ < 6u && m0);
            if (0x80000000u) continue;
            if ((unsigned)((short)(0u * 0x10000u) > (signed char)u3)) {
                if ((a0[u1 & 3u] | u3)) break;
                if ((unsigned)(*mp < m0)) break;
                i1 = 0x1706be9du & 15u;
                g0 = ((*q0 ? 0x7fffffffu : 3u) - *mp);
                d0 = d0 * 0.5 + (double)((unsigned)!((unsigned)!((unsigned)h0 ? p1 : (unsigned)c1) ? u3 : u0) & 1023u);
            }
        }
        *mp = (a0[u1 & 3u] / (0x136dd41u | 1u));
    }
    if (-((p0 << (0xf2713680u & 31u)) / (0xb15f9dacu | 1u))) {
        c0 = (unsigned char)garr[i1 & 7u];
        g0 = (unsigned)((int)(unsigned)((int)((unsigned)h1 + 0xffffffffu) >= (int)(3u - i0)) >= (int)a0[u1 & 3u]);
        for (;;) { if (--fuel == 0u) goto done;
            m0 ^= ((unsigned)e0 ? a0[i0 & 3u] : 0x7fffffffu);
        }
        if ((p0 - (unsigned)((int)(unsigned)w0 < (int)(unsigned)s0))) goto L1;
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (u2) break;
            if (7u) {
                q0 = &garr[i2 & 7u];
                h1 = (unsigned short)(h1 + (unsigned)w0);
                garr[(0x10000u % ((unsigned)e0 | 1u)) & 7u] = (unsigned)(p0 && r0.y);
            }
            if ((((unsigned)b0 >> (7u & 31u)) | 1u)) {
                if (((unsigned)c1 + (unsigned)(v0 || r0.y))) {
                    if ((unsigned)x0) {
                        do { if (--fuel == 0u) goto done;
                            w0 = w0 * 6364136223846793005ull + ((0x10000u & p1) - 6u);
                            c1 = (signed char)(p2 * (unsigned)((short)0x7fffffffu > (signed char)((unsigned)w0 >> (g0 & 31u))));
                        } while (i1++ < 6u && u3);
                        l0 = (long)((unsigned long)l0 + ((unsigned)(0xe7b17f0u < (unsigned)h1) | *mp));
                        break; (void)((0xffffffffu / ((unsigned)s0 | 1u)));
                    }
                    if (((unsigned)c0 & 0xcd2dd0e9u)) break;
                }
                break; (void)((unsigned)h1);
                r0.y ^= r0.x;
                if (~((unsigned)(i0 < 0xe2ff7f42u) << ((unsigned)f0 & 31u))) continue;
                if (((0x366c3bc6u - (unsigned)h1) % ((unsigned)c0 | 1u))) {
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)w0 || (g1 / ((unsigned)!(0x86a0691bu << (0xb607305bu & 31u)) | 1u))));
                    c0 = (unsigned char)a0[u1 & 3u];
                    b0 = (unsigned)(-(unsigned)(0x10000u && fuel) || ((unsigned)(w0 >> 29) * m0)) != 0u;
                }
            } else {
                while (i1++ < 3u && (u0 / ((p1 + u3) | 1u))) { if (--fuel == 0u) goto done;
                    *q0 = r0.y;
                    r0.y ^= (unsigned)x0;
                    h1 = (unsigned short)(h1 + ((unsigned)c0 | (unsigned)x0));
                }
                while (i1++ < 7u && (u3 | (unsigned)(0u == (unsigned)w0))) { if (--fuel == 0u) goto done;
                    *q0 += -(8u << ((unsigned)!(*mp + 4u) & 31u));
                    w0 ^= (unsigned long long)(unsigned)(w0 >> 29) << ((unsigned)(0x3a5f7f0bu && (a0[u1 & 3u] * m0)) & 63u);
                }
                { unsigned t3; double z3; if ((*q0) & 1u) { t3 = u1; z3 = (double)((((0xffffffffu + 0x80000000u) * 0x80000000u)) & 255u); } if ((*q0) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)((v0 / (0x9308e5b8u | 1u)) & 1023u);
                        c0 = (unsigned char)(unsigned)h0;
                    }
                    w0 = w0 * 6364136223846793005ull + (g0 / (0x31be7fdbu | 1u));
                }
                if (((unsigned)f0 / (((unsigned)s1 % (0x7fffffffu | 1u)) | 1u))) {
                    m0 ^= -(0xffffffffu | i1);
                    u1 ^= ((unsigned)(garr[i1 & 7u] && ((unsigned)((unsigned)d0 < (unsigned)e0) - (unsigned)s0)) % (u1 | 1u));
                    s1 = (int)((unsigned)s1 + (unsigned)h0);
                } else {
                    b0 = (unsigned)(signed char)(unsigned)((short)garr[u2 & 7u] > (signed char)r0.y) != 0u;
                }
            }
            g0 = (unsigned)(short)(1u ? i1 : fuel);
            break; (void)((0x80000000u ? *mp : garr[u2 & 7u]));
        }
    } else {
        h1 = (unsigned short)(h1 + (m0 ? -(5u & (unsigned)(i2 && 4u)) : 0x80000000u));
        if ((unsigned)((short)*q0 > (signed char)i2)) goto done;
        do { if (--fuel == 0u) goto done;
            switch (((a0[u1 & 3u] / (i0 | 1u)) - *q0) & 7u) {
                e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)c1 < (int)(unsigned)((short)p0 > (signed char)(unsigned)c1)) & 1023u);
                if (0x7fffffffu) break;
                for (;;) { if (--fuel == 0u) goto done;
                    case 2u: ;
                    r0.y ^= 4u;
                    c1 = (signed char)(unsigned)((unsigned)(garr[i1 & 7u] < (unsigned)c1) == u2);
                    case 3u: ;
                }
                if ((unsigned)((short)v0 > (signed char)m0)) goto L4;
            }
            u1 = ((unsigned)w0 | (unsigned)((int)u1 >= (int)i2));
            if ((m0 & (unsigned)(4u == u0))) break;
        } while (i0++ < 6u && (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)((unsigned)(w0 >> 29) || u3)));
    }
    *q0 += (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)((int)*mp < (int)0x7fffffffu));
    while (i0++ < 5u && (unsigned)((short)i0 > (signed char)(unsigned)((unsigned)d0 == 5u))) { if (--fuel == 0u) goto done;
        r0.y ^= a0[u1 & 3u];
        if ((r0.x + a0[i0 & 3u])) break;
        if ((p0 * (unsigned)((short)v0 > (signed char)(unsigned)e0))) break;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)c1) {
                w0 ^= (unsigned long long)0xadb98d36u << ((unsigned)(unsigned char)((unsigned)e0 >> ((~(unsigned)((unsigned)x0 == (unsigned)((int)(unsigned)f0 < (int)0x10000u)) | fuel) & 31u)) & 63u);
                u3 = u3 * 0x9e3779b1u + ((unsigned)l0 ^ (unsigned)c0);
                h0 = (short)(((unsigned)(7u || (unsigned)((unsigned)b0 < i2)) & (unsigned)c0) & (unsigned)b0);
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (r0.x / (*q0 | 1u)));
                }
            }
        } while (i1++ < 2u && (5u * m0));
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((0xfb741cf1u & (unsigned)s0)) break;
            if (((unsigned)f0 - -((unsigned)h0 << (v0 & 31u)))) continue;
            if (8u) continue;
        }
        if ((a0[i0 & 3u] ? fuel : (unsigned)s0)) goto done;
    }
    if ((unsigned)(short)(1u << ((r0.y << ((unsigned)f0 & 31u)) & 31u))) goto L4;
    switch (0xffffffffu & 7u) {
        case 1u: ;
        case 0u: ;
    }
    *q0 += (unsigned)((p1 * (unsigned)x0) || (unsigned)(u0 < 0x7fffffffu));
    if ((unsigned)b0) goto L1;
    r0.y ^= *mp;
    if (-((unsigned)((short)0x684a1b6au > (signed char)0x10000u) ^ 0x167a62bcu)) goto done;
    while (i0++ < 6u && 8u) { if (--fuel == 0u) goto done;
        { unsigned t4; double z4; if ((i1) & 1u) { t4 = 0x10000u; z4 = (double)(((unsigned)(0x6ebb244bu || 9u)) & 255u); } if ((i1) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            break; (void)((m0 | 0xffffffffu));
            if ((u0 | (unsigned)(5u && (unsigned)(x0 >> 70)))) break;
        }
        if ((unsigned)((int)(unsigned)s1 >= (int)v0)) break;
        c0 = (unsigned char)p2;
        { unsigned t5; double z5; if (((r0.x + (unsigned)h1)) & 1u) { t5 = r0.x; z5 = (double)(((0xb4078f2u ^ (unsigned)!((unsigned)c0 << (0xcf1aa6a0u & 31u)))) & 255u); } if (((r0.x + (unsigned)h1)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            u0 = (unsigned)((unsigned)e0 < (unsigned)((int)(unsigned)(i0 || (unsigned)(x0 >> 70)) >= (int)0xf30afb1au));
            if (0xf497d176u) break;
        }
        if ((g1 * (unsigned)((short)r0.x > (signed char)a0[u1 & 3u]))) {
            u0 = g1;
            c1 = (signed char)(unsigned)x0;
            q0 = &garr[(fuel ? 0xffffffffu : (unsigned)((unsigned)l0 || 0x3bc2db29u)) & 7u];
            g1 += (unsigned)(garr[u2 & 7u] || *q0);
            m0 ^= -(unsigned)((0xffffffffu % ((unsigned)d0 | 1u)) || (unsigned)(short)((0x6272302eu + (unsigned)h1) >> (garr[u2 & 7u] & 31u)));
        } else {
            if ((unsigned)(a0[i0 & 3u] == p2)) break;
            if ((unsigned)(g1 < (0x8b2c319eu % ((unsigned)l0 | 1u)))) break;
        }
    }
    *mp = (unsigned)(short)(unsigned)(3u < (0x10000u - (unsigned)(0x7fffffffu < 0x7fffffffu)));
    if (0x5f358f88u) {
        if (((unsigned)h0 ^ (u2 * *mp))) goto L4;
        do { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)x0 == p1);
        } while (i0++ < 3u && ((unsigned)(unsigned char)(9u | 0xcc936733u) >> ((unsigned)h1 & 31u)));
        if (((unsigned)l0 & i1)) goto L4;
        u2 = (unsigned)((unsigned)(7u < p1) < (unsigned)h0);
        if ((unsigned)((short)~(unsigned)((int)(unsigned)w0 >= (int)(unsigned)x0) > (signed char)0xd1d49de7u)) {
            while (i0++ < 5u && (unsigned)b0) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)u1 < (int)(unsigned)((int)0x4e682f0au >= (int)(unsigned)e0))) break;
                { unsigned t6; double z6; if ((((r0.y ^ a0[i0 & 3u]) ^ 6u)) & 1u) { t6 = ((unsigned)x0 * (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)b0)); z6 = (double)(((unsigned)(short)(u3 | p1)) & 255u); } if ((((r0.y ^ a0[i0 & 3u]) ^ 6u)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                    b0 = (unsigned)b0 != 0u;
                    x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)(signed char)(garr[i1 & 7u] - -(v0 + 9u)) > (signed char)m0);
                    g1 += -(unsigned)((int)r0.y < (int)((unsigned)((unsigned)((short)0x80000000u > (signed char)0x10000u) == u1) - 0x7fffffffu));
                }
                if (5u) break;
            }
            *q0 += ((unsigned)e0 & 0x10000u);
            { unsigned t7; double z7; if (((i2 * (unsigned)h0)) & 1u) { t7 = (4u * (u3 << (v0 & 31u))); z7 = (double)((0x48b70712u) & 255u); } if (((i2 * (unsigned)h0)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                if ((unsigned)((short)(unsigned)c0 > (signed char)-(p1 + (unsigned)(x0 >> 70)))) {
                    if ((unsigned)(u2 || g0)) goto L0;
                    if (u0) goto L0;
                    goto L2;
                    m0 ^= 9u;
                }
                q0 = &garr[(unsigned)((g0 | (unsigned)x0) || g1) & 7u];
                w0 = w0 * 6364136223846793005ull + garr[i1 & 7u];
                w0 ^= (unsigned long long)(unsigned)s0 << ((unsigned)((int)(unsigned)(short)(unsigned)(0x7fffffffu == 0x7fffffffu) < (int)(unsigned)(u0 || (unsigned)(x0 >> 70))) & 63u);
            }
        } else {
            e0 = e0 * 0.5L + (long double)((unsigned)((int)((0u & 1u) + (*q0 << (1u & 31u))) >= (int)garr[i1 & 7u]) & 1023u);
            if ((0xf7d12380u >> (((unsigned)c0 ^ a0[u1 & 3u]) & 31u))) goto L1;
            i0 = (unsigned)((unsigned)c0 && (m0 ^ (unsigned)((int)0x5718bea4u >= (int)a0[i0 & 3u]))) & 15u;
        }
        r0.y ^= (unsigned)((unsigned)b0 || (unsigned)b0);
    } else {
        *q0 += ((unsigned)(i1 || (unsigned)(unsigned char)(unsigned)((int)0x80000000u >= (int)0u)) >> ((unsigned)(0x93c0d658u == u3) & 31u));
        { unsigned t8; double z8; if ((0x80000000u) & 1u) { t8 = (unsigned)d0; z8 = (double)((i1) & 255u); } if ((0x80000000u) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)c1 >= (int)0u);
            if (i1) goto L2;
            if ((0xeff4d0dfu % (0u | 1u))) goto L1;
            c0 = (unsigned char)(*q0 % (0xffffffffu | 1u));
        }
        goto L1;
        if (((unsigned)c0 << ((unsigned)((int)0xf11f4284u < (int)garr[i1 & 7u]) & 31u))) {
            goto L2;
            s1 = (int)((unsigned)s1 + (unsigned)((int)((unsigned)s1 % (*q0 | 1u)) < (int)p1));
            if (u3 == 7u) return *q0;
            if (u3 == 7u) return ((unsigned)((int)m0 < (int)0xec36dc5du) ? (g1 >> (u2 & 31u)) : *mp);
        } else {
            if ((p0 >> (((unsigned)b0 << ((unsigned)s0 & 31u)) & 31u))) goto L2;
        }
    }
    r0.y ^= (unsigned)((unsigned)l0 && ((unsigned)(x0 >> 70) % ((unsigned)(((unsigned)(w0 >> 29) / (0x8d2e2ca2u | 1u)) == (unsigned)(w0 >> 29)) | 1u)));
    if ((unsigned)(i2 || r0.x)) {
        r0.y ^= ((*q0 + i0) ^ 0xffffffffu);
        goto L4;
        goto L3;
        g0 = (unsigned)(unsigned char)(unsigned)((short)(unsigned)b0 > (signed char)(m0 / ((unsigned)h0 | 1u)));
        do { if (--fuel == 0u) goto done;
            g1 += ((u1 >> (((unsigned)e0 ? u0 : 1u) & 31u)) / (u1 | 1u));
            a0[(0x80000000u * i0) & 3u] = (unsigned)c0;
            l0 = (long)((unsigned long)l0 + (unsigned)(1u < 0x8ab6c967u));
            goto L4;
            { unsigned t9; double z9; if ((((0x80000000u ^ (unsigned)c0) / (*q0 | 1u))) & 1u) { t9 = (unsigned)h1; z9 = (double)(((*mp << (((unsigned)b0 | 0xffffffffu) & 31u))) & 255u); } if ((((0x80000000u ^ (unsigned)c0) / (*q0 | 1u))) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                continue; (void)((0xffffffffu | (unsigned)f0));
                if ((unsigned)((unsigned)w0 && (unsigned)((int)(unsigned)s1 >= (int)(unsigned)c0))) continue;
                break; (void)(p1);
                if ((unsigned)(short)(0x83463e8eu ^ i2)) break;
            }
        } while (i0++ < 7u && (unsigned)(0u && *mp));
    } else {
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.x = (unsigned)((short)v0 > (signed char)((unsigned)(v0 || a0[u1 & 3u]) * 0xeef918c9u));
            l0 = (long)((unsigned long)l0 + (unsigned)((int)0xffffffffu < (int)1u));
            c1 = (signed char)(((g1 ^ g1) - (unsigned)x0) - (unsigned)(r0.x && (unsigned)h1));
            if ((unsigned)((short)~(unsigned)(g1 == 0xc23f9c4cu) > (signed char)0x7fffffffu)) break;
            do { if (--fuel == 0u) goto done;
                switch (garr[i1 & 7u] & 7u) {
                    d0 = d0 * 0.5 + (double)((v0 / (((0x943ac172u + 0x86dcd703u) / (0x80000000u | 1u)) | 1u)) & 1023u);
                    switch ((~(g1 * (unsigned)f0) | (unsigned)w0) & 7u) {
                        v0 = (unsigned)(short)(unsigned)((int)(unsigned)(i2 < ((unsigned)x0 - r0.y)) >= (int)(0xb74f751au ^ g1));
                        case 5u: ;
                        if (p2) goto L3;
                        case 4u: ;
                        u3 += (unsigned)(short)((unsigned)(0x80000000u == u2) + (u3 / (0x10000u | 1u)));
                    }
                    b0 = (unsigned)(signed char)(unsigned)((short)(unsigned)d0 > (signed char)(0u ^ u0)) != 0u;
                    continue; (void)((unsigned)(w0 >> 29));
                }
                if (0x5326a31du) break;
                g1 += (i1 - -((unsigned)((short)0x10000u > (signed char)(unsigned)(p1 && a0[u1 & 3u])) + *q0));
            } while (i1++ < 4u && 0xff126c1eu);
            if ((((unsigned)s1 << (garr[u2 & 7u] & 31u)) & 0xffffffffu)) break;
        }
        if ((unsigned)((int)((unsigned)x0 * (unsigned)b0) >= (int)*q0)) goto L3;
    }
    if (~((unsigned)d0 ^ ((unsigned)(w0 >> 29) >> (i1 & 31u)))) {
        if ((unsigned)s0) goto L4;
        if ((unsigned)h0) goto L4;
    }
    if (i1) goto L0;
    while (i1) { if (--fuel == 0u) goto done;
        if ((unsigned)c1) goto L2;
        h1 = (unsigned short)(h1 + (unsigned)(garr[i1 & 7u] || (unsigned)s0));
        if ((0x7fffffffu - 9u)) {
            *q0 += (unsigned)(signed char)(unsigned)((int)(unsigned)d0 < (int)(unsigned)d0);
            break; (void)((unsigned)(0x7fffffffu || (unsigned)(x0 >> 70)));
        }
    }
    goto L1;
    while (((unsigned)e0 ? garr[u2 & 7u] : p1)) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)c0 & *mp) || (unsigned)!(unsigned)((int)(unsigned)((unsigned)c0 == p2) >= (int)(unsigned)(x0 >> 70))) & 1023u);
        h1 = (unsigned short)(h1 + ((p0 % (g0 | 1u)) << (((unsigned)c1 >> ((unsigned)c0 & 31u)) & 31u)));
    }
    c1 = (signed char)u0;
    if (((unsigned)s1 & 0x7fffffffu)) {
        do { if (--fuel == 0u) goto done;
            r0.x = (unsigned)((short)(a0[u1 & 3u] + (unsigned)x0) > (signed char)fuel);
        } while (i0++ < 7u && ((unsigned)(0xda76defeu < 0xffffffffu) + 5u));
        u3 = u3 * 0x9e3779b1u + ((unsigned)(x0 >> 70) & ~(*mp ? (unsigned)(w0 >> 29) : 4u));
    } else {
        if ((unsigned)(4u == ((unsigned)f0 | u3))) goto L1;
        v0 = v0;
        if (~(unsigned)((unsigned)(garr[u2 & 7u] || 9u) == 0x7fffffffu)) goto done;
    }
    for (;;) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)(u1 < ((0x80000000u ^ 0x7fffffffu) & 0x1825f310u));
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                u2 ^= ((r0.x | 0xffffffffu) & 0x857f1a86u);
                *mp = (unsigned)!(garr[i1 & 7u] * (unsigned)(p1 && (fuel | (unsigned)(w0 >> 29))));
                do { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        { unsigned t10; double z10; if ((1u) & 1u) { t10 = (unsigned)!(unsigned)((unsigned)((int)r0.x >= (int)(unsigned)f0) == 0xed8d6f41u); z10 = (double)((-(p0 << (u2 & 31u))) & 255u); } if ((1u) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
                            if (((unsigned)(x0 >> 70) % ((unsigned)l0 | 1u))) break;
                            if ((unsigned)((int)0x10000u < (int)garr[u2 & 7u])) break;
                            s1 = (int)((unsigned)s1 + (m0 << ((unsigned)(signed char)(unsigned)(((unsigned)(x0 >> 70) >> (p2 & 31u)) || (unsigned)(*mp || (unsigned)e0)) & 31u)));
                            if (a0[i0 & 3u]) goto done;
                        }
                        r0.y ^= ((unsigned)b0 ^ 0x10000u);
                    } while (i1++ < 3u && (unsigned)(unsigned char)(i2 ^ a0[i0 & 3u]));
                    switch ((a0[i0 & 3u] - ((unsigned)h0 - (unsigned)d0)) & 7u) {
                        break; (void)((unsigned)b0);
                        case 5u: ;
                        m0 ^= (0xbb15f564u << (fuel & 31u));
                    }
                } while (i0++ < 6u && (u2 * (0xffffffffu % (*mp | 1u))));
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)r0.x << (u3 & 63u);
                }
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)(x0 >> 70) && ((unsigned)c1 + 0x99ce4520u))) {
                        u3 ^= (unsigned)!((unsigned)c0 / (0xffffffffu | 1u));
                        if ((garr[i1 & 7u] / (g0 | 1u))) break;
                        if (((unsigned)((unsigned)c0 < 0xffffffffu) << (0xffffffffu & 31u))) break;
                        if (i1) goto L0;
                        w0 ^= (unsigned long long)a0[u1 & 3u] << ((unsigned)!((a0[i0 & 3u] * (unsigned)l0) * (unsigned)h0) & 63u);
                    }
                    break; (void)((unsigned)(unsigned char)(unsigned)((short)p1 > (signed char)a0[i0 & 3u]));
                    if ((unsigned)((unsigned)(0xffffffffu == 0xef14a279u) || v0)) break;
                    break; (void)((unsigned)b0);
                    if (i2) break;
                }
                if (u3 == 7u) return (unsigned)(((unsigned)e0 / ((unsigned)c1 | 1u)) == (unsigned)((short)*q0 > (signed char)(unsigned)s0));
            }
            q0 = &garr[0x34bc9374u & 7u];
            if ((unsigned)(a0[i0 & 3u] || i0)) {
                g0 = p1;
                for (;;) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)~(i2 + 6u) << (((unsigned)b0 * ((unsigned)(garr[i1 & 7u] || garr[i1 & 7u]) << ((unsigned)d0 & 31u))) & 63u);
                    b0 = (g1 + (p1 >> ((unsigned)((0xde150962u | a0[u1 & 3u]) < a0[i0 & 3u]) & 31u))) != 0u;
                    if ((unsigned)e0) break;
                    if ((unsigned)c0) goto L1;
                    do { if (--fuel == 0u) goto done;
                        m0 ^= ((unsigned)f0 + 0xe351d849u);
                        { unsigned t11; double z11; if (((5u + (p0 & i0))) & 1u) { t11 = ((unsigned)f0 | 7u); z11 = (double)((u2) & 255u); } if (((5u + (p0 & i0))) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
                            g1 += (unsigned)!(unsigned)((int)(unsigned)(((unsigned)((int)0x10000u < (int)p1) << ((unsigned)s1 & 31u)) < (unsigned)b0) >= (int)(unsigned)x0);
                            *q0 = u2;
                            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)d0 < ((p2 / (0x7fffffffu | 1u)) / ((unsigned)c1 | 1u)));
                            h0 = (short)-(0x2443d48bu - p0);
                            break; (void)((unsigned)(v0 && (unsigned)h1));
                        }
                    } while (i0++ < 5u && (unsigned)(((unsigned)c1 | 0x1a8508b4u) == u1));
                    v0 = (0xffffffffu ? (u3 | garr[u2 & 7u]) : (0x7fffffffu ^ *q0));
                }
                continue; (void)((unsigned)s1);
                while (i2++ < 6u && (unsigned)h1) { if (--fuel == 0u) goto done;
                    if ((unsigned)h0) goto L3;
                }
                break; (void)(((unsigned)s0 ^ ((unsigned)c1 - 0x2e7443eu)));
                u2 = u2 * 0x9e3779b1u + u0;
            }
            s0 = (int)(0xf0791576u | (unsigned)h1);
            switch ((0xac1429dbu | (u0 | m0)) & 7u) {
                u1 += (p0 - 0x453a1c21u);
                u2 += ((unsigned)(w0 >> 29) << ((unsigned)(short)(*q0 ^ i1) & 31u));
                *q0 = ~(((unsigned)((unsigned)((int)p1 >= (int)g1) < i0) / ((unsigned)s0 | 1u)) / ((unsigned)x0 | 1u));
                u2 += (unsigned)(signed char)((unsigned)c0 << (u1 & 31u));
            }
        } while (i1++ < 3u && (unsigned)((int)m0 < (int)(unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)x0)));
        while (i1++ < 4u && ((*q0 * (unsigned)f0) / ((unsigned)c1 | 1u))) { if (--fuel == 0u) goto done;
            if (u3 == 7u) return ((unsigned)((short)(p1 * (unsigned)(w0 >> 29)) > (signed char)g1) / ((unsigned)d0 | 1u));
        }
        if (fuel < 8u) return (unsigned)((int)u0 < (int)(1u / (r0.y | 1u)));
        if (((unsigned)w0 * p2)) break;
        switch ((unsigned)!((unsigned)e0 + p0) & 7u) {
            if ((0x80000000u << (r0.x & 31u))) {
                v0 = (unsigned)(0xb7d95bbbu == (0x80000000u * (unsigned)b0));
                r0.x = i2;
                if (~(unsigned)(4u || (unsigned)((int)8u >= (int)i1))) {
                    b0 = ((unsigned)((int)(3u - r0.y) >= (int)(unsigned)s0) % ((unsigned)((short)(unsigned)d0 > (signed char)a0[i0 & 3u]) | 1u)) != 0u;
                    w0 = w0 * 6364136223846793005ull + (unsigned)(r0.x < (i1 << ((~((unsigned)h0 % ((unsigned)h1 | 1u)) >> (a0[i0 & 3u] & 31u)) & 31u)));
                    s1 = (int)((unsigned)s1 + g0);
                    d0 = d0 * 0.5 + (double)((unsigned)(m0 || u2) & 1023u);
                    if ((unsigned)(unsigned char)(0x17d5e002u / (r0.y | 1u))) continue;
                }
                r0.y ^= (unsigned)(u2 || ~(m0 + (unsigned)l0));
                break; (void)((0x967d6d1u * 0x10000u));
            }
        }
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)c1 | u2)) break;
            *q0 += ~(unsigned)((unsigned)(w0 >> 29) == (unsigned)!(*q0 ^ (unsigned)l0));
            garr[(unsigned)e0 & 7u] = ((unsigned)b0 & ((unsigned)((int)(a0[u1 & 3u] * p1) < (int)(unsigned)x0) | 4u));
        }
    }
    w0 ^= (unsigned long long)0x80000000u << ((unsigned)((unsigned)s0 == (unsigned)h1) & 63u);
    v0 = ((unsigned)((short)0x5ced78dfu > (signed char)m0) >> ((unsigned)((int)(unsigned)x0 < (int)i0) & 31u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if ((a0[u1 & 3u]) & 1u) { t0 = (unsigned)((int)(m0 + 0xe7e002ebu) >= (int)g0); z0 = (double)(((0x5582cabdu / (0xe01d9a15u | 1u))) & 255u); } if ((a0[u1 & 3u]) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        if ((unsigned)((short)*q0 > (signed char)p2)) goto L3;
        u0 += 0x739980a1u;
        u0 ^= -(((unsigned)((short)9u > (signed char)0xffffffffu) | (unsigned)(unsigned char)(unsigned)((int)fuel >= (int)(unsigned)f0)) % ((unsigned)c0 | 1u));
        w0 ^= (unsigned long long)i1 << ((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)f0) & 63u);
        goto L2;
    }
    u1 += (unsigned)(*q0 && (unsigned)((unsigned)(a0[i0 & 3u] && garr[u2 & 7u]) < garr[u2 & 7u]));
    m0 ^= (unsigned)(v0 || garr[i1 & 7u]);
    goto L3;
    L0: if (--fuel == 0u) goto done;
    goto done;
    d0 = d0 * 0.5 + (double)(~(unsigned)(*q0 || (unsigned)(short)(r0.x * 0xb68d497cu)) & 1023u);
    { unsigned t1; double z1; if (((unsigned)d0) & 1u) { t1 = (unsigned)(p0 == m0); z1 = (double)(((p0 << (((unsigned)(x0 >> 70) >> (u3 & 31u)) & 31u))) & 255u); } if (((unsigned)d0) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        L1: if (--fuel == 0u) goto done;
    }
    while ((unsigned)((unsigned)((int)u1 < (int)8u) < p2)) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0(0x764a7bc5u, *q0, (unsigned)(short)(((unsigned)b0 | i1) << ((unsigned)b0 & 31u))); }
    }
    d0 = d0 * 0.5 + (double)((unsigned)((int)0x99d349fcu >= (int)(unsigned)((unsigned)l0 || 0x74201d65u)) & 1023u);
    if (budget != 0u) { budget -= 1u; u0 = fn0((0x7fffffffu + *mp), ((fuel % (0x7fffffffu | 1u)) ^ 4u), (unsigned)!(unsigned)(p2 || (unsigned)(p2 == (unsigned)s1))); }
    d0 = d0 * 0.5 + (double)(((unsigned)((int)(unsigned)(5u == 0xc9434e8u) < (int)*q0) % (((unsigned)c0 ^ (unsigned)e0) | 1u)) & 1023u);
    while (i0++ < 3u && ((*mp / (3u | 1u)) & (unsigned)c1)) { if (--fuel == 0u) goto done;
        goto L3;
        e0 = e0 * 0.5L + (long double)(((4u ? garr[i1 & 7u] : g0) ^ 0x10000u) & 1023u);
        if (g0) {
            a0[(0xffffffffu << (0xd5873d9au & 31u)) & 3u] = (unsigned)!((unsigned)w0 >> (0x593e0d76u & 31u));
            f0 = f0 * 0.5f + (float)((unsigned)((short)(i1 ? (unsigned)((short)r0.x > (signed char)3u) : (unsigned)(w0 >> 29)) > (signed char)(unsigned)w0) & 255u);
            if (budget != 0u) { budget -= 1u; u1 = fn0((((unsigned)c0 + u1) ^ p0), (unsigned)((unsigned)s0 == 8u), (unsigned)((short)2u > (signed char)0x10000u)); }
        }
    }
    goto L3;
    u3 += g1;
    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(0x18782ec5u && ((unsigned)c0 + 0x89fcb345u)) && (0x1f66bfbdu >> (*q0 & 31u)));
    if ((r0.y / (u3 | 1u))) goto L4;
    h1 = (unsigned short)(h1 + (unsigned)(~(u3 >> (u2 & 31u)) && (unsigned)(signed char)((unsigned)((unsigned)s1 && (unsigned)c1) ^ 0x3de7a143u)));
    if (budget != 0u) { budget -= 1u; u3 = fn0(0u, (unsigned)(short)(unsigned)((int)(unsigned)s0 >= (int)(unsigned)(unsigned char)(0x69916209u >> (r0.y & 31u))), (0x11d6866cu ^ (unsigned)h1)); }
    goto done;
    { unsigned t2; double z2; if ((((unsigned)w0 ^ 9u)) & 1u) { t2 = (0xffffffffu - (unsigned)(x0 >> 70)); z2 = (double)((((fuel >> (r0.y & 31u)) & (unsigned)(x0 >> 70))) & 255u); } if ((((unsigned)w0 ^ 9u)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        if ((i2 >> (5u & 31u))) {
            c0 = (unsigned char)(unsigned)((short)*mp > (signed char)(0xffffffffu ? (unsigned)((int)m0 >= (int)5u) : 0xa11a692bu));
            c1 = (signed char)(unsigned)(((unsigned)c0 << ((unsigned)d0 & 31u)) || u2);
        }
        s0 = (int)(garr[u2 & 7u] >> ((u3 | (u2 >> ((unsigned)f0 & 31u))) & 31u));
        g1 += ~(((unsigned)((short)0x93256741u > (signed char)a0[u1 & 3u]) ^ garr[u2 & 7u]) - ((unsigned)s1 + 0x1a800ec8u));
        { unsigned t3; double z3; if (((unsigned)!((unsigned)((unsigned)c0 == (unsigned)w0) >> (u2 & 31u))) & 1u) { t3 = (unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)(short)(u1 << ((unsigned)d0 & 31u))); z3 = (double)((3u) & 255u); } if (((unsigned)!((unsigned)((unsigned)c0 == (unsigned)w0) >> (u2 & 31u))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            for (;;) { if (--fuel == 0u) goto done;
                { unsigned t4; double z4; if (((unsigned)w0) & 1u) { t4 = i1; z4 = (double)((0x32255a5cu) & 255u); } if (((unsigned)w0) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    u1 += ((((unsigned)(i1 < u1) + fuel) / ((unsigned)s0 | 1u)) | a0[u1 & 3u]);
                }
            }
            L2: if (--fuel == 0u) goto done;
        }
        { unsigned t5; double z5; if ((((unsigned)h1 >> ((unsigned)c1 & 31u))) & 1u) { t5 = ((unsigned)d0 - 6u); z5 = (double)((a0[i0 & 3u]) & 255u); } if ((((unsigned)h1 >> ((unsigned)c1 & 31u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            while (i0++ < 6u && 8u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((0x80000000u % ((6u - m0) | 1u)), (unsigned)d0, ((unsigned)(r0.y || u1) & garr[i1 & 7u])); }
                L3: if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
            }
            if ((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)((int)(unsigned)w0 >= (int)0x80000000u))) {
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (garr[i1 & 7u]) break;
                }
                l0 = (long)((unsigned long)l0 + ~(0x7fffffffu | (*mp | (0x2b56513du * (unsigned)w0))));
                garr[8u & 7u] = (~(unsigned)(*q0 < u0) & (unsigned)((int)(unsigned)e0 >= (int)(unsigned)(x0 >> 70)));
                q0 = &garr[((unsigned)s0 ^ (unsigned)b0) & 7u];
            } else {
                b0 = (i0 * (unsigned)c0) != 0u;
                while (i0++ < 5u && (unsigned)(r0.y || (unsigned)s1)) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(~(unsigned)((0x80000000u ^ 0xc54ed8e3u) || (unsigned)h0), (unsigned)(signed char)((unsigned)f0 - 0x7fffffffu), (0x6d310016u % (0xffffffffu | 1u))); }
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)l0 < (u3 + r0.y)));
                    if ((unsigned)(u2 < (unsigned)h1)) {
                        x0 = x0 * 0x100000001b3ull + (unsigned)((int)0u >= (int)(unsigned)((int)g1 < (int)v0));
                    }
                    if (((unsigned)s1 + (unsigned)f0)) break;
                    if ((0x80000000u << (m0 & 31u))) break;
                }
            }
            if (((unsigned)((short)m0 > (signed char)p0) ^ a0[u1 & 3u])) {
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)d0, ((unsigned)((unsigned)h1 < p2) * (unsigned)w0), (a0[i0 & 3u] | 7u)); }
                d0 = d0 * 0.5 + (double)(-(unsigned)((int)garr[u2 & 7u] >= (int)0xe2d1396fu) & 1023u);
                if ((unsigned)w0) {
                    w0 = w0 * 6364136223846793005ull + (unsigned)!(0x80000000u & ((unsigned)(x0 >> 70) ? (unsigned)s1 : (unsigned)(0x7fffffffu || u3)));
                    c1 = (signed char)v0;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(p1, g0, (unsigned)(0xffffffffu == (unsigned)(w0 >> 29))); }
                }
            } else {
                goto L3;
                *mp = p0;
            }
            r0.x = (unsigned)c0;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(9u == (0xc835dd9eu - garr[i1 & 7u])), ((unsigned)((short)i2 > (signed char)(unsigned)f0) * i2), (unsigned)((int)(unsigned)!(unsigned)((short)u0 > (signed char)0x2eaafc6au) >= (int)(unsigned)w0)); }
    }
    c1 = (signed char)7u;
    m0 ^= ((i1 ? (unsigned)h0 : m0) % ((unsigned)w0 | 1u));
    if (budget != 0u) { budget -= 1u; u0 = fn0(0x10000u, u2, (unsigned)s1); }
    switch (((unsigned)(w0 >> 29) >> ((i2 % ((unsigned)(w0 >> 29) | 1u)) & 31u)) & 7u) {
        if ((unsigned)!(unsigned)(u1 < (unsigned)((int)i1 < (int)(unsigned)(w0 >> 29)))) goto L4;
        case 6u: ;
        c1 = (signed char)-(unsigned)((unsigned)h1 < *mp);
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 3u && ~(p2 ? garr[u2 & 7u] : a0[i0 & 3u])) { if (--fuel == 0u) goto done;
            { unsigned t6; double z6; if (((p0 | (unsigned)c1)) & 1u) { t6 = 0x80000000u; z6 = (double)((((unsigned)l0 >> ((u0 << (0xa0346815u & 31u)) & 31u))) & 255u); } if (((p0 | (unsigned)c1)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                w0 = w0 * 6364136223846793005ull + ((unsigned)((int)p2 >= (int)(unsigned)b0) - (unsigned)((short)u1 > (signed char)(unsigned)s0));
                if (0x58aeef96u) break;
                if ((unsigned)((int)((unsigned)c0 >> (8u & 31u)) >= (int)*mp)) break;
            }
            v0 = 8u;
            if (((unsigned)l0 << (7u & 31u))) break;
            g1 += *q0;
            u3 = u3 * 0x9e3779b1u + ((unsigned)(x0 >> 70) & (unsigned)c0);
        }
        while (a0[u1 & 3u]) { if (--fuel == 0u) goto done;
            if (((unsigned)h0 & 4u)) break;
            *q0 = (unsigned)(((unsigned)((int)(unsigned)c1 >= (int)(unsigned)c0) % (i2 | 1u)) < (unsigned)((int)(unsigned)s1 < (int)0x10000u));
            while (i2++ < 5u && (unsigned)((int)(0x1fb3f26du >> ((unsigned)h1 & 31u)) < (int)4u)) { if (--fuel == 0u) goto done;
                if ((unsigned)(unsigned char)(g1 * *q0)) break;
                *mp = ((unsigned)((unsigned)c0 < ((unsigned)d0 ? garr[u2 & 7u] : garr[i1 & 7u])) >> (m0 & 31u));
                v0 = 0xe1f6cd2fu;
                if ((unsigned)l0) break;
                d0 = d0 * 0.5 + (double)((5u - m0) & 1023u);
                u0 = u0 * 0x9e3779b1u + (g0 >> (*q0 & 31u));
            }
            if ((unsigned)((short)p2 > (signed char)p0)) break;
        }
        w0 ^= (unsigned long long)((unsigned)s1 - garr[i1 & 7u]) << ((unsigned)(g0 && 0x3d0c282cu) & 63u);
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(r0.x < a0[u1 & 3u]) | (unsigned)h0), (garr[i1 & 7u] >> (0xdfe4074bu & 31u)), (unsigned)l0); }
    if (budget != 0u) { budget -= 1u; u1 = fn0(u1, (unsigned)f0, p0); }
    if ((unsigned)(5u == ((unsigned)f0 << (0xdfdfd55au & 31u)))) goto L4;
    if ((unsigned)((short)0x80000000u > (signed char)(unsigned)(u2 == (unsigned)c1))) goto L3;
    while (i0++ < 7u && (unsigned)((short)i2 > (signed char)0x8a426575u)) { if (--fuel == 0u) goto done;
        i0 = r0.y & 15u;
        switch ((unsigned)((int)(unsigned)s1 >= (int)(0xbe005f3du - g0)) & 7u) {
            switch ((unsigned)f0 & 7u) {
                if (u1) continue;
                b0 = (unsigned)((unsigned)f0 < 0xb1345b66u) != 0u;
                *q0 += i0;
                r0.x = (unsigned)(0xffffffffu || (i1 - (v0 - u3)));
                u0 ^= (unsigned)(short)(unsigned)((unsigned)f0 || ((unsigned)d0 | i1));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((6u << (0xffffffffu & 31u)), (unsigned)((short)0u > (signed char)(unsigned)(w0 >> 29)), ~(unsigned)(8u || 0x7fffffffu)); }
        }
        break; (void)((0xeb0f716bu | (0x5fd76128u * i1)));
        w0 = w0 * 6364136223846793005ull + ((unsigned)h0 | r0.y);
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            g1 += (unsigned)(signed char)((unsigned)c0 >> (((unsigned)(~(4u >> (0x7fffffffu & 31u)) < g0) << (4u & 31u)) & 31u));
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)f0 < (g1 * (unsigned)!(*mp / ((unsigned)((unsigned)(x0 >> 70) || 0x3464675fu) | 1u)))) & 255u);
            g0 = (r0.x << (((unsigned)(x0 >> 70) * ((unsigned)l0 * 0x80da4a35u)) & 31u));
            if (((unsigned)(fuel && (unsigned)f0) % (m0 | 1u))) goto L4;
            { unsigned t7; double z7; if (((unsigned)((int)(unsigned)(u0 || a0[i0 & 3u]) < (int)p0)) & 1u) { t7 = (i1 - p0); z7 = (double)(((unsigned)((short)r0.y > (signed char)(unsigned)h1)) & 255u); } if (((unsigned)((int)(unsigned)(u0 || a0[i0 & 3u]) < (int)p0)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(((unsigned)(x0 >> 70) << (u2 & 31u)) < (unsigned)d0), (unsigned)((int)g0 < (int)u3), 2u); }
                switch ((unsigned)!(unsigned)(r0.x && (r0.y + p0)) & 7u) {
                    if ((unsigned)(g0 || (unsigned)h0)) goto L0;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(x0 >> 70), (unsigned)((int)(u3 - 0x1114090fu) >= (int)(unsigned)e0), (unsigned)((short)(0x10000u << (u3 & 31u)) > (signed char)a0[i0 & 3u])); }
                    w0 ^= (unsigned long long)(unsigned)(0x182efd82u == 0x7fffffffu) << ((unsigned)((unsigned)w0 && (unsigned)((int)m0 < (int)-(unsigned)((int)(unsigned)f0 >= (int)r0.x))) & 63u);
                    f0 = f0 * 0.5f + (float)((0x10000u * (unsigned)(4u || (i2 / ((unsigned)w0 | 1u)))) & 255u);
                    if (0x2871c6bdu) {
                        u2 = u2 * 0x9e3779b1u + ((g1 - ~(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)l0)) / ((unsigned)(1u == (unsigned)c1) | 1u));
                        w0 = w0 * 6364136223846793005ull + (unsigned)(w0 >> 29);
                        q0 = &garr[((8u % ((unsigned)(x0 >> 70) | 1u)) / ((unsigned)((unsigned)b0 == *q0) | 1u)) & 7u];
                        v0 = ~(unsigned)((int)(unsigned)e0 >= (int)r0.y);
                        m0 ^= (unsigned)(a0[u1 & 3u] && (unsigned)b0);
                    }
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((0x80000000u | (0u - m0)), (unsigned)(0xef2bdcd8u && 0x10000u), 0x95dd6f2bu); }
                        g0 = (unsigned)((short)((unsigned)s0 >> (p1 & 31u)) > (signed char)0xf00ca084u);
                    }
                }
                if ((unsigned)((int)i2 < (int)p0)) break;
                r0.y ^= (unsigned)((int)0x10000u < (int)-(g1 % ((v0 ? 0xd085303u : 0x7fffffffu) | 1u)));
                if (budget != 0u) { budget -= 1u; u0 = fn0((fuel | (i1 - (unsigned)s0)), (unsigned)(0xd962038au == ((unsigned)c0 ^ a0[u1 & 3u])), ((unsigned)((int)6u >= (int)(unsigned)w0) | i1)); }
            }
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(v0 & 0x10000u) << (((unsigned)h0 / ((unsigned)((unsigned)d0 && (unsigned)((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)h1) || v0)) | 1u)) & 63u);
            }
        }
        g1 += m0;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)c1 || 8u), garr[u2 & 7u], 0x7fffffffu); }
    q0 = &garr[((unsigned)h1 ? p2 : u2) & 7u];
    if ((unsigned)e0) goto done;
    if ((unsigned)((int)0x8c49559cu >= (int)(unsigned)c0)) goto L2;
    w0 = w0 * 6364136223846793005ull + 0xf9553f8au;
    w0 ^= (unsigned long long)(unsigned)!(0xb9482aabu * i2) << (((unsigned)b0 << (fuel & 31u)) & 63u);
    if (budget != 0u) { budget -= 1u; u3 = fn0((garr[i1 & 7u] / (0xffffffffu | 1u)), (((unsigned)l0 % (*mp | 1u)) << ((unsigned)c0 & 31u)), (0x321ad5ddu % ((0xe98105f0u >> (0x10000u & 31u)) | 1u))); }
    if ((u0 + (i1 % ((unsigned)s1 | 1u)))) {
        { unsigned t8; double z8; if ((((unsigned)((int)0u < (int)m0) | a0[i0 & 3u])) & 1u) { t8 = p0; z8 = (double)(((unsigned)(x0 >> 70)) & 255u); } if ((((unsigned)((int)0u < (int)m0) | a0[i0 & 3u])) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
            do { if (--fuel == 0u) goto done;
                *q0 = ((unsigned)((unsigned)(u1 || 0x5a4a5f42u) == v0) | (unsigned)((unsigned)w0 && 0x10000u));
                if (budget != 0u) { budget -= 1u; u3 = fn0(a0[i0 & 3u], 0xa46eb142u, (unsigned)((int)((unsigned)h1 / (0x64cc3b6eu | 1u)) < (int)v0)); }
                break; (void)(((unsigned)(x0 >> 70) >> (0x7a6fb39fu & 31u)));
            } while (i0++ < 3u && u0);
        }
        { unsigned t9; double z9; if (((unsigned)(x0 >> 70)) & 1u) { t9 = (0x706a13a8u - g0); z9 = (double)(((unsigned)s1) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
            switch (((unsigned)d0 ^ 0x11a3cc54u) & 7u) {
                if ((unsigned)s0) goto L4;
                i1 = (0u | ((unsigned)d0 >> ((unsigned)h0 & 31u))) & 15u;
                l0 = (long)((unsigned long)l0 + (i0 + (unsigned)(((unsigned)(i2 && (unsigned)h0) % (u3 | 1u)) == a0[u1 & 3u])));
                h0 = (short)((unsigned)(signed char)(p2 ^ 4u) | 0x10000u);
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(1u, (unsigned)((int)*mp < (int)p0), (unsigned)(x0 >> 70)); }
            if ((i0 << (r0.x & 31u))) goto L2;
        }
    } else {
        r0.y ^= u3;
    }
    w0 = w0 * 6364136223846793005ull + a0[u1 & 3u];
    if ((unsigned)!(unsigned)((short)(unsigned)((int)(unsigned)x0 >= (int)7u) > (signed char)(unsigned)(x0 >> 70))) {
        if (u3) goto done;
        d0 = d0 * 0.5 + (double)((6u * (unsigned)!(unsigned)(u0 < (unsigned)(x0 >> 70))) & 1023u);
        x0 = x0 * 0x100000001b3ull + 9u;
        if ((unsigned)h0) goto L4;
        switch ((a0[i0 & 3u] % ((unsigned)(w0 >> 29) | 1u)) & 7u) {
            h1 = (unsigned short)(h1 + (0xffffffffu / (0x585b9cc9u | 1u)));
            f0 = f0 * 0.5f + (float)(((((unsigned)x0 | 0x8ddca8ddu) ^ (unsigned)(*q0 || (unsigned)s1)) >> (v0 & 31u)) & 255u);
            v0 = (unsigned)(unsigned char)(unsigned)((unsigned)l0 == (unsigned)((int)0x7fffffffu >= (int)((0xffffffffu - 0u) << (i0 & 31u))));
            u2 = u2 * 0x9e3779b1u + (fuel << (5u & 31u));
            case 0u: ;
        }
    } else {
        if ((unsigned)((int)u1 >= (int)0x10000u)) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)garr[i1 & 7u] > (signed char)u1), 4u, (unsigned)((int)1u >= (int)u3)); }
    }
    e0 = e0 * 0.5L + (long double)(0x23e14ce4u & 1023u);
    if ((0u * (garr[i1 & 7u] - 3u))) {
        while (i0++ < 2u && (unsigned)w0) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((0xc44271f9u >> (0xf10988b8u & 31u)), (unsigned)(signed char)((unsigned)(w0 >> 29) & 9u), (unsigned)((unsigned)c0 == (unsigned)(short)((unsigned)b0 % (v0 | 1u)))); }
        }
        *q0 = u2;
        m0 ^= ((unsigned)(((unsigned)x0 ^ (unsigned)h1) && a0[u1 & 3u]) << ((unsigned)(u3 && 0xc781a47bu) & 31u));
    }
    h0 = (short)(((unsigned)h0 >> ((unsigned)((unsigned)x0 || 0x3ae046beu) & 31u)) >> (0x7a81077au & 31u));
    if (budget != 0u) { budget -= 1u; u3 = fn0((*q0 * garr[u2 & 7u]), (unsigned)((int)(u1 ^ (unsigned)(w0 >> 29)) < (int)0xc4e531f3u), (unsigned)e0); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (u0) goto L4;
    do { if (--fuel == 0u) goto done;
        a0[i0 & 3u] = ((unsigned)x0 * (unsigned)(short)((unsigned)e0 >> (*q0 & 31u)));
        if (0xb06fc3beu) goto L4;
        switch (2u & 7u) {
            b0 = 0x7fffffffu != 0u;
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)f0 / ((unsigned)h1 | 1u)), (g0 % ((3u + (unsigned)x0) | 1u)), garr[i1 & 7u]); }
        }
        if ((unsigned)((int)0x80000000u >= (int)(unsigned)((unsigned)d0 && (unsigned)h0))) {
            h1 = (unsigned short)(h1 + u3);
            if (0x65248e5du) break;
            while (i1++ < 6u && (unsigned)h1) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)c0, (unsigned)((short)i1 > (signed char)u3), p2); }
                u3 ^= (unsigned)((unsigned)((unsigned)e0 == 0xffffffffu) < (unsigned)((unsigned)(0x986605f5u || 0xffffffffu) && u0));
                { unsigned t0; double z0; if ((u3) & 1u) { t0 = (unsigned)((unsigned)x0 == r0.x); z0 = (double)(((g1 ^ (unsigned)f0)) & 255u); } if ((u3) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    L0: if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + r0.x);
                }
                c0 = (unsigned char)((a0[i0 & 3u] | 0xf3cd4b3au) - (0x5ba08326u ? (unsigned)f0 : 0x7345a79du));
                if (((unsigned)(a0[i0 & 3u] == 0x7936e660u) % ((unsigned)w0 | 1u))) {
                    { unsigned t1; double z1; if (((unsigned)((int)garr[i1 & 7u] >= (int)(0xf55131e8u * (unsigned)s0))) & 1u) { t1 = (unsigned)((int)(*q0 ^ u1) >= (int)i0); z1 = (double)(((unsigned)!(-(unsigned)((unsigned)x0 && *mp) / (g1 | 1u))) & 255u); } if (((unsigned)((int)garr[i1 & 7u] >= (int)(0xf55131e8u * (unsigned)s0))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                        i0 = (unsigned)((int)0xa2d5d003u >= (int)u0) & 15u;
                        L1: if (--fuel == 0u) goto done;
                        b0 = ((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)((short)a0[i0 & 3u] > (signed char)p1)) % ((unsigned)s1 | 1u)) != 0u;
                        break; (void)((u1 % ((unsigned)e0 | 1u)));
                        if ((unsigned)(r0.y == (0x7fffffffu | 0xffffffffu))) break;
                        h0 = (short)((unsigned)w0 | (unsigned)(u2 && (unsigned)c0));
                    }
                    u0 += (unsigned)((int)(unsigned)w0 < (int)-(fuel | g0));
                } else {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(x0 >> 70), (g0 | 5u), (unsigned)(short)(garr[u2 & 7u] ? 0x80000000u : (unsigned)h0)); }
                }
            }
        }
    } while (i0++ < 6u && (g0 * garr[u2 & 7u]));
    u2 ^= (unsigned)(short)(unsigned)((int)0xffffffffu >= (int)a0[i0 & 3u]);
    a0[(unsigned)((int)0x10000u < (int)a0[i0 & 3u]) & 3u] = (unsigned)(short)((i0 ^ (unsigned)w0) << (i0 & 31u));
    r0.x = ((unsigned)h1 >> (0x80000000u & 31u));
    s0 = (int)fuel;
    *mp = g0;
    while (i0++ < 5u && (fuel << (a0[u1 & 3u] & 31u))) { if (--fuel == 0u) goto done;
        if (((i1 ^ 0x10000u) + g1)) break;
        L2: if (--fuel == 0u) goto done;
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)(garr[u2 & 7u] < 0u);
    if ((unsigned)((unsigned)w0 == (unsigned)e0)) {
        f0 = f0 * 0.5f + (float)((0x7fffffffu / (0x8940fa5u | 1u)) & 255u);
        switch ((unsigned)((int)0x7fffffffu < (int)(p2 >> (*q0 & 31u))) & 7u) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)l0, (g0 ^ garr[u2 & 7u]), 8u); }
            u1 ^= (r0.x << (0xffffffffu & 31u));
            L3: if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((g1 & (unsigned)(x0 >> 70)) & 1023u);
            case 7u: ;
            { unsigned t2; double z2; if (((unsigned)w0) & 1u) { t2 = (garr[u2 & 7u] % ((unsigned)(w0 >> 29) | 1u)); z2 = (double)((i0) & 255u); } if (((unsigned)w0) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                g1 += (unsigned)((short)(unsigned)(((unsigned)s0 % (g0 | 1u)) && u0) > (signed char)(unsigned)f0);
                *q0 = (unsigned)s0;
                g1 += (0xcf7b9681u + (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)h1));
            }
        }
        for (;;) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                a0[0xfa264f18u & 3u] = ((unsigned)((int)(unsigned)h1 >= (int)u3) & (garr[u2 & 7u] % ((unsigned)w0 | 1u)));
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)(unsigned)e0 >= (int)0x2641d521u), (unsigned)((int)r0.y >= (int)garr[u2 & 7u]), (unsigned)((unsigned)s1 || (0x7a216194u << ((unsigned)(x0 >> 70) & 31u)))); }
                if (garr[u2 & 7u]) goto L4;
            }
        }
        if ((unsigned)((int)7u < (int)p0)) {
            if ((unsigned)((unsigned)s1 && 1u)) {
                h0 = (short)((r0.x & (unsigned)w0) << (0x10000u & 31u));
                if (budget != 0u) { budget -= 1u; u1 = fn0((m0 % (5u | 1u)), 3u, ((unsigned)l0 % ((3u - 3u) | 1u))); }
                if (((unsigned)h1 - 0xffffffffu)) goto done;
                switch (g0 & 7u) {
                    L4: if (--fuel == 0u) goto done;
                    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        *q0 = (unsigned)s0;
                        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                            c0 = (unsigned char)(unsigned)(0x31a64f64u == (unsigned)!(unsigned)(5u && r0.x));
                        }
                        if (a0[u1 & 3u]) continue;
                        continue; (void)(((unsigned)c0 ^ i2));
                        if ((unsigned)((short)(unsigned)w0 > (signed char)p1)) continue;
                        s0 = (int)0u;
                    }
                    u3 += (g0 ? (unsigned)l0 : (r0.y & (unsigned)l0));
                    do { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + (unsigned)((short)((unsigned)(w0 >> 29) ^ v0) > (signed char)0x10000u));
                        w0 ^= (unsigned long long)(unsigned)((unsigned)f0 && 9u) << ((unsigned)(signed char)((6u ^ garr[i1 & 7u]) % (0x387ff7dcu | 1u)) & 63u);
                        w0 ^= (unsigned long long)r0.y << ((unsigned)(short)(unsigned)((short)(unsigned)((short)0xffffffffu > (signed char)r0.x) > (signed char)(unsigned)((int)v0 < (int)*mp)) & 63u);
                    } while (i0++ < 5u && (unsigned)((int)(unsigned)e0 >= (int)(0x65baa7a6u % (u0 | 1u))));
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)(0xffffffffu < (i1 << (0x4b4e304au & 31u)));
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)((int)(unsigned)w0 < (int)(unsigned)(signed char)(unsigned)((int)i2 < (int)(unsigned)s1)) == *q0);
            }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1(v0, (fuel % ((unsigned)(v0 < (unsigned)(w0 >> 29)) | 1u)), u2); }
                s0 = (int)(unsigned)((int)2u < (int)(unsigned)e0);
                if ((7u | u0)) goto L4;
                s0 = (int)((unsigned)c1 + (unsigned)s1);
                r0.x = (unsigned)(unsigned char)(p1 / ((unsigned)((int)(unsigned)e0 >= (int)(unsigned)c0) | 1u));
            } while (i0++ < 7u && 0xd414ed69u);
            if (((unsigned)l0 ^ (unsigned)(*mp && 0x10000u))) goto L3;
            s1 = (int)((unsigned)s1 + ((((unsigned)w0 ? a0[i0 & 3u] : i1) & (unsigned)e0) / (i1 | 1u)));
        } else {
            f0 = f0 * 0.5f + (float)((0u + (unsigned)c1) & 255u);
            if ((unsigned)((int)(unsigned)w0 >= (int)(unsigned)(i2 && 0x10000u))) goto L3;
            u1 = u1 * 0x9e3779b1u + ((unsigned)((int)(unsigned)s1 >= (int)a0[i0 & 3u]) % (p1 | 1u));
            if ((unsigned)((int)a0[i0 & 3u] >= (int)((unsigned)d0 | p1))) goto L0;
        }
    } else {
        l0 = (long)((unsigned long)l0 + (u0 + (unsigned)((int)(unsigned)w0 >= (int)(unsigned)s0)));
    }
    w0 ^= (unsigned long long)(unsigned)(8u == 4u) << ((unsigned)((int)(unsigned)((u3 + a0[i0 & 3u]) < (unsigned)e0) >= (int)(unsigned)(u1 || 0u)) & 63u);
    do { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((u1 & (unsigned)(((p2 - (unsigned)(x0 >> 70)) * g0) == 0xb7fd0392u)) & 1023u);
        c1 = (signed char)((unsigned)e0 & garr[u2 & 7u]);
        e0 = e0 * 0.5L + (long double)(5u & 1023u);
        break; (void)(g1);
    } while (i0++ < 5u && (unsigned)(signed char)((unsigned)h0 * (unsigned)b0));
    if ((unsigned)!((unsigned)s0 + (unsigned)d0)) goto L3;
    w0 ^= (unsigned long long)0xd152fc64u << ((unsigned)((int)(unsigned)((unsigned)(0xe9b78fe6u == (unsigned)c1) < 0x75030606u) < (int)g0) & 63u);
    if (~(unsigned)((int)*q0 < (int)(unsigned)!((unsigned)b0 >> (0x63b215b0u & 31u)))) goto L2;
    *mp = (0xffffffffu & 0x7fffffffu);
    if ((r0.y ^ 0xffffffffu)) goto L0;
    x0 = x0 * 0x100000001b3ull + -(unsigned)((int)(unsigned)(w0 >> 29) < (int)(((unsigned)(x0 >> 70) << ((unsigned)s1 & 31u)) ? (unsigned)(w0 >> 29) : 0x61833691u));
    if (fuel < 8u) return (unsigned)((unsigned)f0 < (unsigned)w0);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)!((unsigned)(w0 >> 29) + u0)) break;
        v0 = (unsigned)((3u ? (unsigned)d0 : (unsigned)(w0 >> 29)) < (unsigned)c0);
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(a0[u1 & 3u] == 0x7fffffffu), -(p2 >> (1u & 31u)), (unsigned)w0); }
    }
    if (~(unsigned)((short)*mp > (signed char)g1)) {
        if (((unsigned)h1 - 0x80000000u)) {
            d0 = d0 * 0.5 + (double)((r0.y ? (unsigned)(signed char)(7u / ((unsigned)(short)((unsigned)(w0 >> 29) - 0x80000000u) | 1u)) : u0) & 1023u);
            goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)p0 < (int)*q0), 8u, (unsigned)(2u < a0[i0 & 3u])); }
            x0 = x0 * 0x100000001b3ull + (unsigned)(short)(p2 * (unsigned)!(unsigned)((int)p0 >= (int)((u2 | u3) << (m0 & 31u))));
            u1 += (unsigned)s0;
        } else {
            if ((unsigned)(6u < (1u / (a0[u1 & 3u] | 1u)))) goto L2;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)r0.y > (signed char)2u), (r0.x << (p2 & 31u)), (unsigned)(7u < ((unsigned)f0 << (9u & 31u)))); }
            if ((unsigned)f0) goto L3;
            goto L3;
        }
        r0.x = (r0.y << ((unsigned)(fuel && (unsigned)((garr[i1 & 7u] * 0xbd99dfddu) == 0xfd215aacu)) & 31u));
        if ((8u ? r0.x : (unsigned)(x0 >> 70))) goto L2;
        { unsigned t3; double z3; if (((u2 / (g1 | 1u))) & 1u) { t3 = (unsigned)(((unsigned)x0 % ((unsigned)f0 | 1u)) && a0[i0 & 3u]); z3 = (double)((((unsigned)((short)garr[i1 & 7u] > (signed char)0x69598bfu) - r0.y)) & 255u); } if (((u2 / (g1 | 1u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            g0 = (unsigned)((short)i1 > (signed char)((unsigned)d0 / (v0 | 1u)));
            if ((fuel | (*q0 / (i0 | 1u)))) goto done;
            if ((p0 % (0u | 1u))) goto L1;
        }
        b0 = (unsigned)((unsigned)(signed char)(unsigned)((unsigned)c1 < m0) == (unsigned)((short)i0 > (signed char)(unsigned)c1)) != 0u;
    } else {
        *q0 += (unsigned)(signed char)(unsigned)((u3 << (u2 & 31u)) && m0);
        while ((unsigned)((short)0xe60f01beu > (signed char)0x7fffffffu)) { if (--fuel == 0u) goto done;
            { unsigned t4; double z4; if (((r0.x << (2u & 31u))) & 1u) { t4 = (unsigned)(signed char)(unsigned)((short)0x5cb8e898u > (signed char)r0.x); z4 = (double)(((unsigned)(garr[i1 & 7u] < (unsigned)e0)) & 255u); } if (((r0.x << (2u & 31u))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                if (r0.x) break;
                if (fuel < 8u) return (unsigned)(u3 == 0x80000000u);
            }
            c1 = (signed char)(-(g1 ? 0xd27747d3u : (unsigned)(i0 || garr[u2 & 7u])) | (unsigned)(x0 >> 70));
        }
    }
    if ((unsigned)((int)(unsigned)d0 < (int)0xc364f254u)) goto done;
    goto done;
    e0 = e0 * 0.5L + (long double)(4u & 1023u);
    if ((unsigned)((0x10000u & *q0) == 1u)) goto done;
    f0 = f0 * 0.5f + (float)(1u & 255u);
    if ((unsigned)(unsigned char)((0x21109972u % (i2 | 1u)) + (unsigned)d0)) goto L2;
    if ((unsigned)s0) goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn1(~(garr[i1 & 7u] | 0x80000000u), (unsigned)((int)r0.y < (int)3u), (*mp % (g1 | 1u))); }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)e0) break;
        g1 += (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)((unsigned)(v0 && 0x2ffc5c70u) < (a0[u1 & 3u] << (a0[u1 & 3u] & 31u))));
        while (0x80000000u) { if (--fuel == 0u) goto done;
            m0 ^= (u3 - (garr[i1 & 7u] | a0[u1 & 3u]));
            if ((unsigned)w0) break;
            if (((unsigned)w0 >> ((unsigned)(garr[i1 & 7u] || 0xf3d19416u) & 31u))) break;
        }
        h0 = (short)(v0 - 8u);
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)c0, (*q0 & a0[i0 & 3u]), (unsigned)((short)0x7fffffffu > (signed char)p2)); }
        h1 = (unsigned short)(h1 + ((i2 >> (v0 & 31u)) / ((unsigned)(0x10000u || 0xff24664bu) | 1u)));
    }
    if ((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)x0)) {
        m0 ^= ((unsigned)h1 % ((i0 % ((unsigned)((short)5u > (signed char)(unsigned)x0) | 1u)) | 1u));
        r0.x = g1;
    }
    if ((0x10000u | (unsigned)(u3 && 0xf79b9f0au))) goto L3;
    if (((unsigned)f0 / (0x10000u | 1u))) goto L1;
    do { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((short)(unsigned)s1 > (signed char)(u2 | (unsigned)s0)) < 0x10000u));
        switch (~(unsigned)((unsigned)e0 || i1) & 7u) {
            for (;;) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)((unsigned)((unsigned)(v0 && i2) < *mp) - (*mp >> (0x971118d2u & 31u)));
            }
            { unsigned t5; double z5; if ((u3) & 1u) { t5 = (unsigned)(((unsigned)h0 + 0x7fffffffu) < 1u); z5 = (double)(((unsigned)(p2 == 0xf5587ba9u)) & 255u); } if ((u3) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                case 5u: ;
                if (((unsigned)h1 << ((g0 - i2) & 31u))) continue;
                w0 = w0 * 6364136223846793005ull + (0x26414ca9u * 0x10000u);
            }
            c1 = (signed char)(unsigned)(signed char)((p2 & (unsigned)(x0 >> 70)) | ((unsigned)((unsigned)h0 && 9u) + (unsigned)s1));
        }
        { unsigned t6; double z6; if (((unsigned)((unsigned)(0xd8f70cefu || u1) == (unsigned)b0)) & 1u) { t6 = (0x7ef2e886u >> ((unsigned)((int)6u >= (int)*mp) & 31u)); z6 = (double)(((unsigned)((int)0xd51c3559u < (int)0xd34a40a5u)) & 255u); } if (((unsigned)((unsigned)(0xd8f70cefu || u1) == (unsigned)b0)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
            if ((unsigned)s0) break;
            if (0x3c41e5adu) {
                m0 ^= (unsigned)((unsigned)((int)u1 < (int)i2) == (unsigned)(0x35dfa27du < 5u));
                if ((unsigned)((int)a0[i0 & 3u] >= (int)(0xd6ce76bfu - a0[i0 & 3u]))) {
                    b0 = (r0.y - (unsigned)(1u || -(fuel + (unsigned)f0))) != 0u;
                    if ((u2 - (unsigned)d0)) break;
                    if (fuel < 8u) return 0xc128402cu;
                    goto L1;
                }
                if (u0) break;
                if (budget != 0u) { budget -= 1u; u2 = fn0(-(unsigned)(m0 == ((unsigned)x0 & u2)), (unsigned)f0, (unsigned)(i1 || p0)); }
                c1 = (signed char)(0x10000u + (5u << ((unsigned)((int)g1 >= (int)8u) & 31u)));
            }
            h0 = (short)garr[i1 & 7u];
            if (((unsigned)((unsigned)(x0 >> 70) == (unsigned)x0) >> ((unsigned)h1 & 31u))) break;
            break; (void)((unsigned)((0x2bbd3612u & 1u) && (unsigned)h1));
        }
        switch ((0xb048d955u / (0x7fffffffu | 1u)) & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(unsigned char)(unsigned)(~((unsigned)c0 ^ (unsigned)d0) || i2), -(i2 * (unsigned)!(unsigned)((short)0x7fffffffu > (signed char)(unsigned)c0)), (unsigned)x0); }
            if (((1u + 0x80000000u) * u2)) goto done;
        }
        r0.y ^= (unsigned)!(-(unsigned)((int)(unsigned)s1 >= (int)u1) + (unsigned)((int)0x80000000u < (int)0xb66d4ebdu));
        if (1u) {
            h0 = (short)~(*mp ^ g0);
            if (budget != 0u) { budget -= 1u; u3 = fn1(u1, ((unsigned)((int)0xfbe728bau < (int)(unsigned)(w0 >> 29)) | garr[u2 & 7u]), 4u); }
        } else {
            h0 = (short)(unsigned)s1;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (1u) break;
                v0 = p0;
            }
        }
    } while (i0++ < 3u && (unsigned)((int)u3 < (int)(unsigned)h0));
    if (budget != 0u) { budget -= 1u; u3 = fn1(u3, ((unsigned)s1 * 0x7fffffffu), (1u * ((unsigned)h0 % ((unsigned)s0 | 1u)))); }
    u1 = (unsigned)(((6u & (unsigned)(fuel && p0)) | g0) < r0.x);
    if ((-(unsigned)(garr[i1 & 7u] < 2u) | 0xe8970842u)) goto L0;
    { unsigned t7; double z7; if (((unsigned)(p1 || 4u)) & 1u) { t7 = ((unsigned)(short)(0x225abf87u % (p1 | 1u)) >> (9u & 31u)); z7 = (double)(((((unsigned)l0 % (r0.x | 1u)) >> ((unsigned)(w0 >> 29) & 31u))) & 255u); } if (((unsigned)(p1 || 4u)) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
        d0 = d0 * 0.5 + (double)((unsigned)((short)0xe6a76b6eu > (signed char)(unsigned)!(unsigned)(i1 || (unsigned)b0)) & 1023u);
        if (budget != 0u) { budget -= 1u; u1 = fn0((9u << ((unsigned)(7u && garr[u2 & 7u]) & 31u)), g1, ((unsigned)s1 ? i1 : u0)); }
        if (budget != 0u) { budget -= 1u; u0 = fn1((6u >> (((unsigned)(w0 >> 29) / (fuel | 1u)) & 31u)), (unsigned)((unsigned)f0 && 0x80000000u), 0x9a1e7388u); }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(-(unsigned)(garr[u2 & 7u] == (unsigned)((short)g1 > (signed char)a0[u1 & 3u])), (u1 + 0xffffffffu), ((unsigned)b0 >> (0x1a299429u & 31u))); }
    r0.y ^= ((garr[i1 & 7u] % (0x10000u | 1u)) % ((3u << ((unsigned)h0 & 31u)) | 1u));
    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)c0 == (u2 % ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)v0) | 1u))));
    u3 += ((unsigned)((int)0x7fffffffu >= (int)0xb352ed41u) << ((0x80000000u / ((unsigned)c0 | 1u)) & 31u));
    u3 = u3 * 0x9e3779b1u + (unsigned)(signed char)((unsigned)(short)((p0 + i1) >> (((unsigned)l0 & 0xffffffffu) & 31u)) / (m0 | 1u));
    i2 = (unsigned)((int)4u >= (int)(unsigned)(0x3c72ee08u == 0xffffffffu)) & 15u;
    if (((unsigned)(garr[i1 & 7u] && (unsigned)h1) << (u1 & 31u))) goto done;
    b0 = ((unsigned)((unsigned)(0x97e23b08u || (0u % ((unsigned)s0 | 1u))) || v0) << (0x10000u & 31u)) != 0u;
    if ((unsigned)((short)(unsigned)w0 > (signed char)(unsigned)x0)) goto L2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(signed char)((0x80000000u >> (u1 & 31u)) % (9u | 1u))) {
        x0 = x0 * 0x100000001b3ull + (unsigned)((p1 / (u3 | 1u)) || (8u & v0));
        c0 = (unsigned char)(unsigned)(((unsigned)(x0 >> 70) ^ (unsigned)(w0 >> 29)) == ((unsigned)((int)0xf4009bdeu >= (int)(unsigned)s1) >> (0x80000000u & 31u)));
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)((unsigned)c0 || p1) & 7u) {
            u1 = u1 * 0x9e3779b1u + ((((unsigned)d0 / ((unsigned)(x0 >> 70) | 1u)) - (unsigned)h1) >> ((unsigned)(unsigned char)(u0 << (p2 & 31u)) & 31u));
            c1 = (signed char)(unsigned)((int)0xffffffffu >= (int)0x385d7635u);
            switch ((unsigned)((unsigned)(unsigned char)(0x27ba9a7au & p2) && (unsigned)w0) & 7u) {
                *q0 = (unsigned)s1;
                v0 = (0xe48677deu >> ((unsigned)(signed char)(unsigned)(6u == p2) & 31u));
                s1 = (int)((unsigned)s1 + u3);
                if (budget != 0u) { budget -= 1u; u2 = fn1(0x10000u, (unsigned)s1, (unsigned)(short)(u1 ^ garr[u2 & 7u])); }
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *mp = ((unsigned)h0 + (unsigned)(short)((unsigned)c0 ? (unsigned)(garr[i1 & 7u] || (unsigned)f0) : a0[u1 & 3u]));
                    if (g1) goto done;
                    *q0 = ((unsigned)w0 * ((unsigned)s0 / ((unsigned)(x0 >> 70) | 1u)));
                    for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                            a0[((unsigned)c1 % (0x80000000u | 1u)) & 3u] = (unsigned)((short)i0 > (signed char)(unsigned)((short)*mp > (signed char)((unsigned)f0 & (0x7fffffffu >> (v0 & 31u)))));
                            r0.y ^= (unsigned)(i0 < 2u);
                            if ((unsigned)(v0 < (unsigned)l0)) continue;
                            u3 = u3 * 0x9e3779b1u + -(0x10000u - (unsigned)(i1 < (unsigned)s0));
                            d0 = d0 * 0.5 + (double)((unsigned)e0 & 1023u);
                            s1 = (int)((unsigned)s1 + (i2 ^ u3));
                        }
                        g1 += ((unsigned)((int)(unsigned)(unsigned char)((unsigned)x0 - 0x7fffffffu) < (int)(unsigned)s0) >> (((unsigned)s1 - r0.x) & 31u));
                        switch ((i0 & g0) & 7u) {
                            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)((int)u2 >= (int)m0) + i2), ((unsigned)((int)0x325b22e9u < (int)*q0) % (u2 | 1u)), 0xba873785u); }
                            v0 = ((unsigned)s1 - (i1 | g1));
                            x0 = x0 * 0x100000001b3ull + (unsigned)(9u < (unsigned)(w0 >> 29));
                            *q0 = (0xcd84952cu / ((unsigned)s1 | 1u));
                            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(5u == (unsigned)h1), ((unsigned)d0 & 0xcce68189u), (((unsigned)x0 + 1u) ^ (unsigned)l0)); }
                        }
                        h1 = (unsigned short)(h1 + (0xa19d1159u / ((unsigned)b0 | 1u)));
                    }
                    u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)(x0 >> 70) == 3u);
                    garr[4u & 7u] = (unsigned)(signed char)(unsigned)((unsigned)s1 < (unsigned)(p1 || u0));
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0(7u, 0x7fffffffu, (unsigned)((int)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0x80000000u) >= (int)a0[i0 & 3u])); }
            }
            switch ((unsigned)((int)0x80000000u < (int)garr[u2 & 7u]) & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn1((0x10000u | (unsigned)((int)0xffffffffu >= (int)0xffffffffu)), ((unsigned)((int)0x70ab9ffcu < (int)r0.y) ^ 0x4b7a22ffu), ((unsigned)e0 % (0x7147a687u | 1u))); }
            }
            case 0u: ;
        }
    }
    { unsigned t0; double z0; if ((((unsigned)((int)r0.x >= (int)r0.y) / (u0 | 1u))) & 1u) { t0 = (v0 ? 4u : (unsigned)x0); z0 = (double)((0xffffffffu) & 255u); } if ((((unsigned)((int)r0.x >= (int)r0.y) / (u0 | 1u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        r0.x = (unsigned)((int)~(unsigned)((int)0xffffffffu >= (int)garr[i1 & 7u]) >= (int)(unsigned)s0);
        g0 = ((unsigned)h0 << ((i1 / ((unsigned)c0 | 1u)) & 31u));
        do { if (--fuel == 0u) goto done;
            u1 ^= (0x7fffffffu % ((0x80000000u ^ (unsigned)((int)0x10000u < (int)(unsigned)(x0 >> 70))) | 1u));
        } while (i0++ < 2u && p2);
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (m0 >> ((unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)((short)(unsigned)d0 > (signed char)0u)) & 31u)));
            if (budget != 0u) { budget -= 1u; u2 = fn0(p1, (unsigned)d0, ((unsigned)(w0 >> 29) - (unsigned)(x0 >> 70))); }
            L0: if (--fuel == 0u) goto done;
            while (i1++ < 3u && ((unsigned)w0 * g1)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2((3u ? u3 : 0xffffffffu), (unsigned)((r0.x << (i0 & 31u)) && 0xef48a402u), (fuel - (7u + r0.x))); }
                if ((unsigned)(0x37ac7897u || i0)) goto L2;
            }
        }
        u0 = u0 * 0x9e3779b1u + (unsigned)(0x59b7b3cfu < ((unsigned)((int)1u < (int)fuel) ? (unsigned)(w0 >> 29) : 0u));
    }
    *q0 += 0x80000000u;
    u2 = u2 * 0x9e3779b1u + (unsigned)((int)(unsigned)w0 < (int)0x5ec53513u);
    h1 = (unsigned short)(h1 + (unsigned)(w0 >> 29));
    if ((4u - i2)) goto L2;
    w0 ^= (unsigned long long)0xffffffffu << ((unsigned)!(unsigned)(a0[i0 & 3u] && 2u) & 63u);
    f0 = f0 * 0.5f + (float)((unsigned)((short)(unsigned)w0 > (signed char)((unsigned)h1 ^ (unsigned)l0)) & 255u);
    *mp = (unsigned)c0;
    goto L0;
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((unsigned)(unsigned char)(p1 * 0xffffffffu) == g0), (u2 | fuel), 0x7fffffffu); }
    u3 = -(unsigned)(((unsigned)h1 ? (unsigned)s0 : (unsigned)c0) && ((unsigned)f0 % (4u | 1u)));
    switch ((unsigned)((int)(unsigned)h0 >= (int)(unsigned)(v0 == a0[i0 & 3u])) & 7u) {
        v0 = (((unsigned)e0 / ((unsigned)h1 | 1u)) / ((unsigned)s0 | 1u));
        if ((unsigned)(0x10000u && 0xa47ac225u)) {
            if ((2u + 0x7fffffffu)) goto L3;
            do { if (--fuel == 0u) goto done;
                v0 = 9u;
                u1 ^= (unsigned)c0;
            } while (i0++ < 7u && (v0 / (3u | 1u)));
            case 2u: ;
            garr[(unsigned)((unsigned)(x0 >> 70) == 4u) & 7u] = (unsigned)((unsigned)l0 < (unsigned)(unsigned char)(u1 ^ (unsigned)(0xc37209e1u < 7u)));
            s1 = (int)((unsigned)s1 + (unsigned)((int)((unsigned)b0 % (r0.y | 1u)) < (int)(unsigned)!((unsigned)(x0 >> 70) | (i1 * 0x7fffffffu))));
            L1: if (--fuel == 0u) goto done;
        } else {
            s1 = (int)((unsigned)s1 + ((unsigned)((unsigned)e0 && 0x4962ace7u) + ((unsigned)d0 + *mp)));
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0xb08d52e0u && (unsigned)((int)garr[u2 & 7u] < (int)7u)), u1, ((unsigned)((int)(unsigned)h1 < (int)5u) | i2)); }
        if ((unsigned)c1) {
            L2: if (--fuel == 0u) goto done;
            if ((unsigned)((r0.y | (unsigned)c0) == u0)) goto done;
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)garr[u2 & 7u] << ((*q0 / (7u | 1u)) & 63u);
                do { if (--fuel == 0u) goto done;
                    b0 = (unsigned)((unsigned)h1 && (unsigned)c1) != 0u;
                    u2 += r0.x;
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)d0, (0x579cacb5u & (unsigned)(w0 >> 29)), (2u * (v0 ^ *q0))); }
                    *q0 += (unsigned)(unsigned char)(unsigned)((int)fuel >= (int)((unsigned)((int)(unsigned)f0 >= (int)(unsigned)((unsigned)e0 && (unsigned)h0)) - (unsigned)c1));
                    case 0u: ;
                } while (i1++ < 5u && (6u * u2));
                switch ((0x10000u * p1) & 7u) {
                    if ((unsigned)b0) continue;
                    if (0x317181ffu) continue;
                }
            }
            switch ((unsigned)(fuel || r0.y) & 7u) {
                garr[garr[u2 & 7u] & 7u] = 0x7fffffffu;
                if (((unsigned)!(0xf2b0db88u >> (7u & 31u)) >> ((unsigned)e0 & 31u))) goto L2;
                *mp = r0.x;
                if (0xffffffffu) break;
                g0 = ((unsigned)(0xffffffffu && (unsigned)w0) + 0x74da03a0u);
            }
            if ((unsigned)l0) {
                m0 ^= ((unsigned)((int)(unsigned)w0 >= (int)(a0[u1 & 3u] & u2)) * (unsigned)((short)i2 > (signed char)0x138a34e0u));
                if ((a0[i0 & 3u] & (unsigned)(signed char)(unsigned)((short)u2 > (signed char)4u))) goto L3;
                if ((*q0 - (unsigned)c0)) {
                    if ((unsigned)(unsigned char)(unsigned)(m0 == (unsigned)s1)) {
                        while ((unsigned)(short)((unsigned)b0 & ((unsigned)d0 & g1))) { if (--fuel == 0u) goto done;
                            f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)((int)0x80000000u < (int)(unsigned)c1) >= (int)u2) & 255u);
                            c1 = (signed char)(i2 * (unsigned)((unsigned)(garr[u2 & 7u] == p1) && (unsigned)(short)(unsigned)((unsigned)b0 == garr[i1 & 7u])));
                        }
                        if ((unsigned)!(((unsigned)h1 - 6u) & 1u)) goto L2;
                        case 6u: ;
                        g0 = ((r0.x | p2) << ((unsigned)((int)0xffffffffu >= (int)6u) & 31u));
                    } else {
                        e0 = e0 * 0.5L + (long double)(u1 & 1023u);
                        s0 = (int)0u;
                        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)(unsigned)l0 >= (int)r0.y), (unsigned)(short)(unsigned)(a0[i0 & 3u] == (unsigned)(short)(r0.y << (*mp & 31u))), ~(0x1fc08433u % ((unsigned)h1 | 1u))); }
                    }
                    x0 = x0 * 0x100000001b3ull + (unsigned)(0x7fffffffu || 0xc7521e67u);
                }
            }
        }
        default: ;
        switch ((unsigned)(0x7fffffffu == (0x1053ec67u % (5u | 1u))) & 7u) {
            goto L4;
            x0 = x0 * 0x100000001b3ull + (fuel * ((unsigned)c0 - (0xd8cfb943u * (unsigned)l0)));
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.x = fuel;
                u1 ^= (garr[u2 & 7u] % ((unsigned)h0 | 1u));
            }
            if ((unsigned)((short)(unsigned)c0 > (signed char)0x7fffffffu)) goto L2;
            if (((unsigned)x0 & (i2 * *mp))) goto L4;
        }
    }
    g1 += u0;
    while (i0++ < 6u && (p1 ^ 9u)) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(unsigned)f0;
        if (budget != 0u) { budget -= 1u; u0 = fn0((m0 - ((unsigned)c1 | *mp)), ((unsigned)l0 * 0x80000000u), r0.x); }
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(x0 >> 70) == (unsigned)((short)8u > (signed char)p0)) & 255u);
        if ((unsigned)w0) break;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            while ((unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)((unsigned)(short)(0x354444f6u / (u0 | 1u)) || (unsigned)h1));
                L3: if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    L4: if (--fuel == 0u) goto done;
                    i0 = (*mp + 0x7fffffffu) & 15u;
                    break; (void)((i2 % (0x10000u | 1u)));
                } while (i0++ < 2u && (unsigned)(signed char)(unsigned)(i1 < ((unsigned)s0 - (unsigned)c0)));
                break; (void)((unsigned)((short)0u > (signed char)(unsigned)(x0 >> 70)));
                for (;;) { if (--fuel == 0u) goto done;
                    u3 += ((unsigned)s0 >> (((unsigned)((int)(unsigned)s0 >= (int)0xd38e6a55u) - (unsigned)((int)0xd945c73cu >= (int)(unsigned)x0)) & 31u));
                    f0 = f0 * 0.5f + (float)(((7u % ((unsigned)(v0 == a0[i0 & 3u]) | 1u)) ? (unsigned)c1 : (unsigned)l0) & 255u);
                    if (p1) break;
                    { unsigned t1; double z1; if ((~(*q0 + *q0)) & 1u) { t1 = ((unsigned)(*q0 || (unsigned)c0) >> ((unsigned)c1 & 31u)); z1 = (double)((((unsigned)f0 & 0xbb2d06b5u)) & 255u); } if ((~(*q0 + *q0)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                        continue; (void)(p0);
                    }
                }
                a0[(unsigned)((unsigned)b0 < 0x6a032dbcu) & 3u] = (unsigned)h0;
            }
            c0 = (unsigned char)(unsigned)((short)i1 > (signed char)(unsigned)(x0 >> 70));
            continue; (void)((unsigned)(short)(0x7fffffffu >> ((unsigned)((short)1u > (signed char)i1) & 31u)));
            if (budget != 0u) { budget -= 1u; u2 = fn2(~(unsigned)(garr[i1 & 7u] < (0xffffffffu ^ (unsigned)h0)), (0x4160a327u % ((unsigned)c0 | 1u)), fuel); }
        }
        if (2u) {
            if (budget != 0u) { budget -= 1u; u2 = fn0((r0.y / (((unsigned)s1 >> (*q0 & 31u)) | 1u)), (unsigned)(9u || m0), (unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)l0))); }
            continue; (void)(u0);
            if ((v0 ^ ((unsigned)h1 & 0x10000u))) goto L0;
            u1 ^= (unsigned)(((unsigned)(short)(unsigned)(0xffffffffu && (unsigned)f0) % (garr[u2 & 7u] | 1u)) && (a0[u1 & 3u] % (r0.x | 1u)));
        } else {
            i0 = m0 & 15u;
            if ((unsigned)x0) {
                if ((*q0 % (p2 | 1u))) {
                    w0 = w0 * 6364136223846793005ull + ((unsigned)(w0 >> 29) / (((unsigned)((unsigned)(g0 < 0xe3ff32a4u) < 1u) - 0x7fffffffu) | 1u));
                    s0 = (int)(unsigned)((unsigned)x0 == r0.x);
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)x0 && g1), p2, *mp); }
                    u0 += (0x7f89210fu + (unsigned)l0);
                    { unsigned t2; double z2; if (((i0 + (0x7fffffffu >> ((unsigned)s0 & 31u)))) & 1u) { t2 = (unsigned)((int)(unsigned)((short)i2 > (signed char)(unsigned)e0) < (int)p0); z2 = (double)(((unsigned)((short)0x26ab1937u > (signed char)i0)) & 255u); } if (((i0 + (0x7fffffffu >> ((unsigned)s0 & 31u)))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                        w0 = w0 * 6364136223846793005ull + m0;
                        garr[(unsigned)(0x7fffffffu && 0x80000000u) & 7u] = (unsigned)((short)(r0.x ? 0x5793edb3u : (unsigned)h1) > (signed char)~(0x384ce682u + *mp));
                        if (v0) break;
                        u3 = (((unsigned)e0 | (fuel % ((unsigned)e0 | 1u))) % ((g0 / (m0 | 1u)) | 1u));
                    }
                    if ((unsigned)((int)6u < (int)(unsigned)(short)(unsigned)((int)(unsigned)x0 < (int)*mp))) goto L3;
                } else {
                    if ((unsigned)(w0 >> 29)) goto done;
                    do { if (--fuel == 0u) goto done;
                        break; (void)(p0);
                        h1 = (unsigned short)(h1 + (unsigned)d0);
                        g0 = (unsigned)((int)(unsigned)((short)(unsigned)l0 > (signed char)*mp) < (int)0xe3f4a628u);
                    } while (i1++ < 2u && (unsigned)((g1 % (0x10000u | 1u)) < u0));
                    s1 = (int)((unsigned)s1 + ((unsigned)((short)0xffffffffu > (signed char)v0) + *mp));
                }
                switch (7u & 7u) {
                    continue; (void)(((unsigned)(w0 >> 29) % ((unsigned)h1 | 1u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((unsigned)h0 || ((unsigned)x0 & 5u)), (unsigned)l0, u1); }
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(unsigned char)(r0.x + (7u / (5u | 1u))), (a0[u1 & 3u] % (a0[u1 & 3u] | 1u)), (unsigned)l0); }
                    for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)e0 && 0x2ddc3cfcu) % ((0x2e2d60dau + 0x10000u) | 1u)));
                        case 5u: ;
                        q0 = &garr[((7u | (unsigned)(unsigned char)(a0[u1 & 3u] << ((v0 * p2) & 31u))) % ((unsigned)(w0 >> 29) | 1u)) & 7u];
                        b0 = (unsigned)((int)(unsigned)c1 < (int)(fuel / ((unsigned)((i2 + 5u) && 0x80000000u) | 1u))) != 0u;
                    }
                }
            }
            d0 = d0 * 0.5 + (double)((unsigned)(signed char)((unsigned)((int)(unsigned)d0 >= (int)p2) & (unsigned)l0) & 1023u);
        }
    }
    { unsigned t3; double z3; if (((i1 * (unsigned)((unsigned)s1 || 0x10000u))) & 1u) { t3 = (a0[i0 & 3u] >> ((unsigned)s1 & 31u)); z3 = (double)(((unsigned)((int)u2 < (int)0xbef64d2u)) & 255u); } if (((i1 * (unsigned)((unsigned)s1 || 0x10000u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        c1 = (signed char)((p2 & (unsigned)((int)0x80000000u >= (int)(unsigned)s0)) % ((unsigned)((int)a0[u1 & 3u] >= (int)0x7fffffffu) | 1u));
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            continue; (void)(0xffffffffu);
            if ((3u << (u3 & 31u))) break;
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                u3 ^= ((unsigned)x0 % ((unsigned)((unsigned)(w0 >> 29) || p0) | 1u));
                u2 += ((garr[i1 & 7u] * *q0) ? u0 : (fuel % (0xd95c91b9u | 1u)));
                *mp = (unsigned)((g0 + (unsigned)c1) || u0);
                w0 ^= (unsigned long long)3u << ((unsigned)(x0 >> 70) & 63u);
                if (((0x7fffffffu % (4u | 1u)) & 0x1371ca12u)) goto done;
                switch ((a0[i0 & 3u] >> (v0 & 31u)) & 7u) {
                    i0 = ((unsigned)((unsigned)x0 < p1) % ((unsigned)l0 | 1u)) & 15u;
                    w0 = w0 * 6364136223846793005ull + ((unsigned)s1 ? (unsigned)d0 : 0x53df68a3u);
                    s0 = (int)3u;
                    d0 = d0 * 0.5 + (double)(((unsigned)(u2 < p0) << ((unsigned)((unsigned)w0 < (unsigned)h0) & 31u)) & 1023u);
                    case 2u: ;
                    if (budget != 0u) { budget -= 1u; u1 = fn2((u0 + 0x16e7606u), (p2 << (0xfb36e543u & 31u)), (u2 - i1)); }
                }
            }
            do { if (--fuel == 0u) goto done;
                continue; (void)(8u);
                if (budget != 0u) { budget -= 1u; u1 = fn1(r0.y, (unsigned)(signed char)(unsigned)((unsigned)l0 && (unsigned)(short)(unsigned)((unsigned)d0 == p2)), (unsigned)!(u0 - (0x10000u << (0x95d46049u & 31u)))); }
                if ((unsigned)((short)p2 > (signed char)(0x75165b6cu | u0))) continue;
                if (((unsigned)(u1 == (unsigned)h1) + i0)) goto L4;
            } while (i2++ < 6u && a0[i0 & 3u]);
            w0 ^= (unsigned long long)i2 << ((unsigned)((int)u3 < (int)(r0.y / (9u | 1u))) & 63u);
        } while (i1++ < 5u && ((unsigned)c0 << ((unsigned)h0 & 31u)));
        { unsigned t4; double z4; if (((-(unsigned)((int)garr[i1 & 7u] >= (int)9u) % (0x80000000u | 1u))) & 1u) { t4 = i1; z4 = (double)((garr[u2 & 7u]) & 255u); } if (((-(unsigned)((int)garr[i1 & 7u] >= (int)9u) % (0x80000000u | 1u))) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            q0 = &garr[g0 & 7u];
            garr[(a0[i0 & 3u] / ((unsigned)(x0 >> 70) | 1u)) & 7u] = ((unsigned)(*q0 < (unsigned)((short)1u > (signed char)(unsigned)x0)) << (5u & 31u));
        }
        if (*q0) continue;
    }
    c1 = (signed char)(unsigned)b0;
    do { if (--fuel == 0u) goto done;
        g1 += (m0 ^ fuel);
        break; (void)(6u);
        c0 = (unsigned char)(unsigned)((9u & (unsigned)h1) == ((unsigned)h0 ^ 0x9c7df874u));
    } while (i0++ < 7u && (0x7fffffffu + 0x2e698659u));
    goto L2;
    if (((unsigned)((short)u2 > (signed char)u0) | r0.y)) goto L2;
    e0 = e0 * 0.5L + (long double)((unsigned)(~((unsigned)(x0 >> 70) >> (6u & 31u)) < ((unsigned)(3u && 0x10000u) - (unsigned)e0)) & 1023u);
    do { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)((unsigned)(unsigned char)(unsigned)((short)0xffffffffu > (signed char)(unsigned)e0) || (unsigned)d0);
        if (budget != 0u) { budget -= 1u; u2 = fn2(i2, (unsigned)((unsigned)h0 || (unsigned)((short)0u > (signed char)1u)), (unsigned)(signed char)((i0 & (unsigned)d0) + (unsigned)c0)); }
        { unsigned t5; double z5; if (((unsigned)d0) & 1u) { t5 = fuel; z5 = (double)(((unsigned)((int)0xc4e6665bu >= (int)0x10000u)) & 255u); } if (((unsigned)d0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            e0 = e0 * 0.5L + (long double)((unsigned)(((unsigned)s0 - (unsigned)h0) && (unsigned)e0) & 1023u);
            if ((unsigned)(fuel < (unsigned)c0)) break;
            break; (void)((unsigned)((int)u0 < (int)p2));
        }
        garr[(unsigned)(0x7fffffffu < (unsigned)w0) & 7u] = 0xffffffffu;
    } while (i0++ < 2u && (unsigned)c0);
    c1 = (signed char)((unsigned)d0 ? g0 : (unsigned)((unsigned)w0 == (g1 + 0xcac4192bu)));
    garr[(unsigned)e0 & 7u] = (unsigned)((unsigned)x0 == m0);
    h0 = (short)(unsigned)((int)(unsigned)((int)a0[u1 & 3u] >= (int)i0) >= (int)3u);
    if (a0[i0 & 3u]) {
        if ((garr[u2 & 7u] % ((3u - 0x10000u) | 1u))) goto done;
        a0[(unsigned)s0 & 3u] = (unsigned)((unsigned)(signed char)(unsigned)((unsigned)((short)i2 > (signed char)m0) < (unsigned)((short)3u > (signed char)(unsigned)b0)) == *mp);
    }
    if (4u) goto L0;
    x0 = x0 * 0x100000001b3ull + garr[i1 & 7u];
    *mp = ((unsigned)((short)0xeb25a2cau > (signed char)u1) * (unsigned)e0);
    switch (((unsigned)h0 & r0.y) & 7u) {
        i2 = -(unsigned)(9u || (unsigned)(w0 >> 29)) & 15u;
        q0 = &garr[(0x10000u >> ((unsigned)((short)(0xffffffffu % (p1 | 1u)) > (signed char)0xffffffffu) & 31u)) & 7u];
        case 1u: ;
        case 0u: ;
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        u1 ^= -(unsigned)((unsigned)((int)a0[i0 & 3u] >= (int)0x7fffffffu) || (0x7fffffffu & (unsigned)x0));
    }
    if (0xffffffffu) goto L1;
    if (3u) goto L0;
    { unsigned t6; double z6; if ((r0.x) & 1u) { t6 = (unsigned)!((i2 << (u2 & 31u)) % (0x10000u | 1u)); z6 = (double)(((unsigned)(short)(unsigned)((unsigned)d0 && (unsigned)x0)) & 255u); } if ((r0.x) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
        while (i0++ < 4u && (unsigned)((short)0xe098a672u > (signed char)(unsigned)h0)) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)(*q0 < (unsigned)w0));
            w0 = w0 * 6364136223846793005ull + (0x10000u | (m0 & 0x10000u));
        }
        *q0 += *q0;
        if ((unsigned)(signed char)(u1 % (p1 | 1u))) goto L1;
    }
    if (fuel < 8u) return ((unsigned)(r0.y == (unsigned)d0) + g1);
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(0x7fffffffu << (0x10000u & 31u)) > (signed char)p1), ((unsigned)d0 << ((unsigned)(w0 >> 29) & 31u)), ((unsigned)b0 ^ (m0 << (fuel & 31u)))); }
    b0 = g1 != 0u;
    s0 = (int)6u;
    if (((unsigned)d0 ? 0x80000000u : (unsigned)w0)) goto done;
    if ((unsigned)h0) goto done;
    if (r0.y) {
        if (u3) goto L2;
        if (i1) goto L2;
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)((2u | 0x1dbe35ceu) || (2u / (i0 | 1u))) & 1023u);
                if ((unsigned)(i2 == 0x7fffffffu)) break;
                h1 = (unsigned short)(h1 + 0x7fffffffu);
                i0 = ((unsigned)((unsigned)c0 == (u0 - m0)) + (unsigned)((unsigned)c1 && (unsigned)l0)) & 15u;
                q0 = &garr[(u0 ^ (unsigned)((unsigned)(unsigned char)((i1 % ((unsigned)(w0 >> 29) | 1u)) / (m0 | 1u)) || 0x7fffffffu)) & 7u];
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = (unsigned)((int)*mp < (int)(unsigned)h0);
                    if (((unsigned)c0 % ((unsigned)l0 | 1u))) break;
                    break; (void)((unsigned)e0);
                }
            } while (i1++ < 3u && (unsigned)((int)(unsigned)s0 < (int)(garr[u2 & 7u] + 6u)));
            c0 = (unsigned char)(unsigned)(i2 == (unsigned)((unsigned)s1 == 1u));
        }
        x0 = x0 * 0x100000001b3ull + (garr[i1 & 7u] >> ((unsigned)((short)0xf6575882u > (signed char)(g1 | g1)) & 31u));
        { unsigned t7; double z7; if ((9u) & 1u) { t7 = (unsigned)b0; z7 = (double)(((unsigned)(0x73771e8du || *mp)) & 255u); } if ((9u) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
            d0 = d0 * 0.5 + (double)(((unsigned)f0 + ((unsigned)(p1 < 0xffffffffu) >> (~(5u * p0) & 31u))) & 1023u);
            r0.x = (unsigned)h1;
            if ((unsigned)(short)(unsigned)((int)(unsigned)s1 >= (int)(unsigned)d0)) goto L3;
            if ((((unsigned)h1 / (p2 | 1u)) - u2)) goto L2;
        }
    } else {
        goto L3;
        do { if (--fuel == 0u) goto done;
            if ((garr[u2 & 7u] >> (u1 & 31u))) continue;
            m0 ^= (r0.y & ((i1 + i0) << (u0 & 31u)));
            if (garr[i1 & 7u]) break;
        } while (i0++ < 3u && g0);
        if (((*mp ^ 0x8ee97292u) / (0x7fffffffu | 1u))) {
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)x0, -(unsigned)((short)1u > (signed char)(unsigned)d0), (*mp << ((unsigned)d0 & 31u))); }
            u1 = u1 * 0x9e3779b1u + -(0x80000000u & (unsigned)h0);
            x0 = x0 * 0x100000001b3ull + (((unsigned)((unsigned)c0 < 0x7fffffffu) + (unsigned)(0x10000u == p2)) << (7u & 31u));
            if ((u3 ^ (unsigned)!(a0[i0 & 3u] / (fuel | 1u)))) goto L4;
        }
    }
    f0 = f0 * 0.5f + (float)(((unsigned)(((unsigned)w0 - 0xae95975fu) || 0x10000u) ^ 4u) & 255u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    a0[2u & 3u] = fuel;
    *q0 = (unsigned)(i2 < 0xa3e0fc0bu);
    { unsigned t0; double z0; if ((((unsigned)h0 - (i2 | 0x6190dde2u))) & 1u) { t0 = ((unsigned)f0 | (unsigned)f0); z0 = (double)(((unsigned)w0) & 255u); } if ((((unsigned)h0 - (i2 | 0x6190dde2u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        L0: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn2((i0 | g0), (i2 ? garr[i1 & 7u] : 3u), (unsigned)f0); }
        if (budget != 0u) { budget -= 1u; u1 = fn1((p0 << ((u2 ^ 0x7fffffffu) & 31u)), (0x10000u >> (0x7fffffffu & 31u)), (unsigned)!((r0.x & u2) >> (r0.x & 31u))); }
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(u2 == (unsigned)f0), (p2 - p0), (unsigned)(x0 >> 70)); }
        u1 ^= (unsigned)(0xffffffffu && 0xc5c67c6u);
        if (budget != 0u) { budget -= 1u; u2 = fn3((-(unsigned)(garr[u2 & 7u] || 0x80000000u) ^ p0), (unsigned)((int)g1 < (int)(unsigned)f0), (a0[u1 & 3u] ^ ((unsigned)f0 / (p2 | 1u)))); }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn2((g1 >> (8u & 31u)), (unsigned)x0, ((unsigned)((short)8u > (signed char)5u) + 0x7fffffffu)); }
    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(x0 >> 70), ((unsigned)w0 ? p0 : 0x80000000u), (unsigned)(signed char)(unsigned)(((unsigned)(w0 >> 29) / (*mp | 1u)) && 0x7fffffffu)); }
    b0 = (unsigned)(short)(unsigned)((short)(unsigned)((unsigned)((unsigned)l0 < 1u) || 6u) > (signed char)u3) != 0u;
    if (budget != 0u) { budget -= 1u; u0 = fn1(0u, (g0 & -(0x80000000u ^ (unsigned)c1)), m0); }
    if (1u) goto done;
    do { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (p2 ? 2u : (unsigned)(x0 >> 70)));
        w0 ^= (unsigned long long)((unsigned)h1 << ((unsigned)c0 & 31u)) << ((unsigned)((int)g1 >= (int)(unsigned)(unsigned char)(i1 - u1)) & 63u);
        while (i1++ < 2u && (unsigned)(5u == (unsigned)x0)) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((unsigned)(short)(unsigned)((short)(unsigned)(u0 || (unsigned)b0) > (signed char)p2) & 1023u);
            break; (void)((unsigned)(0xffffffffu < *q0));
            v0 = (*mp | (unsigned)c0);
        }
        q0 = &garr[((p1 ^ *mp) >> ((unsigned)(signed char)(unsigned)((unsigned)(0xdb47678u < 0x161bcd57u) == 0x80000000u) & 31u)) & 7u];
        do { if (--fuel == 0u) goto done;
            switch (0x89d8db0fu & 7u) {
                u1 += (p1 + (unsigned)h0);
                break; (void)((unsigned)d0);
                L1: if (--fuel == 0u) goto done;
                c0 = (unsigned char)~((unsigned)c1 >> (u2 & 31u));
            }
            break; (void)((g0 & 0xbe7af326u));
        } while (i1++ < 4u && fuel);
        *q0 += r0.x;
    } while (i0++ < 2u && (unsigned)(unsigned char)(unsigned)(4u || (unsigned)s0));
    q0 = &garr[(unsigned)((unsigned)s1 == ((unsigned)c1 + 0x10000u)) & 7u];
    if ((unsigned)(v0 == 0x7fffffffu)) {
        switch ((unsigned)(w0 >> 29) & 7u) {
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(u2 & 1023u);
                e0 = e0 * 0.5L + (long double)(((unsigned)(x0 >> 70) * g1) & 1023u);
                if (budget != 0u) { budget -= 1u; u2 = fn3(*q0, (unsigned)((r0.x * *q0) == *q0), (i1 | (unsigned)b0)); }
            }
            w0 ^= (unsigned long long)(unsigned)(a0[u1 & 3u] == (unsigned)d0) << (((v0 * 0xffffffffu) * (unsigned)((int)garr[u2 & 7u] >= (int)p1)) & 63u);
        }
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && (unsigned)l0) { if (--fuel == 0u) goto done;
            *q0 += (0x7fffffffu & (u2 | (unsigned)x0));
            for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)(unsigned)((int)(fuel / (a0[i0 & 3u] | 1u)) < (int)5u);
                m0 ^= (unsigned)((unsigned)h0 && ~(((unsigned)(w0 >> 29) & (7u & u2)) >> (garr[i1 & 7u] & 31u)));
                c0 = (unsigned char)(unsigned)(-(unsigned)((short)r0.x > (signed char)(unsigned)s0) < (p0 | garr[i1 & 7u]));
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((0x2625ca01u ? 0x4e25194u : (unsigned)c0)) break;
                    a0[(3u / ((unsigned)f0 | 1u)) & 3u] = g0;
                    break; (void)((unsigned)!((unsigned)l0 | (unsigned)(signed char)(unsigned)((unsigned)f0 == 0xb9fabc6eu)));
                    if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((0x289174dcu + u1) < g0), *mp, (g1 << ((unsigned)((unsigned)(w0 >> 29) || p0) & 31u))); }
                }
                u1 += 0x80000000u;
                q0 = &garr[((unsigned)e0 - (unsigned)(unsigned char)(unsigned)((short)i1 > (signed char)(unsigned)s1)) & 7u];
            }
        }
    }
    { unsigned t1; double z1; if (((-(unsigned)(0xe2bd0d85u == (unsigned)e0) << (0x10000u & 31u))) & 1u) { t1 = ((r0.x ^ 3u) >> (0xc0073f4au & 31u)); z1 = (double)(((unsigned)((unsigned)f0 && (0x2a2f7410u % (*q0 | 1u)))) & 255u); } if (((-(unsigned)(0xe2bd0d85u == (unsigned)e0) << (0x10000u & 31u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        goto L1;
        if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)c1 << (0x80000000u & 31u)), 0x80000000u, garr[u2 & 7u]); }
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((i2 - garr[u2 & 7u])) {
            do { if (--fuel == 0u) goto done;
                if (((unsigned)d0 + (i1 << (p0 & 31u)))) break;
                L2: if (--fuel == 0u) goto done;
            } while (i1++ < 4u && garr[u2 & 7u]);
            goto L4;
            *q0 += (unsigned)((int)0xcc6a5dd9u < (int)garr[u2 & 7u]);
            { unsigned t2; double z2; if (((unsigned)(short)(unsigned)((short)i0 > (signed char)(unsigned)((int)garr[u2 & 7u] >= (int)u2))) & 1u) { t2 = a0[i0 & 3u]; z2 = (double)((-(unsigned)((unsigned)b0 || fuel)) & 255u); } if (((unsigned)(short)(unsigned)((short)i0 > (signed char)(unsigned)((int)garr[u2 & 7u] >= (int)u2))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                break; (void)(0u);
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(unsigned)((int)(m0 << (0xffffffffu & 31u)) < (int)(unsigned)(w0 >> 29));
                    *q0 = (unsigned)(short)(unsigned)(((unsigned)f0 - (unsigned)e0) < (unsigned)((unsigned)x0 == (unsigned)f0));
                    while (i2++ < 4u && 5u) { if (--fuel == 0u) goto done;
                        q0 = &garr[((m0 >> (p1 & 31u)) | (unsigned)((int)(unsigned)l0 < (int)fuel)) & 7u];
                        if (budget != 0u) { budget -= 1u; u2 = fn0(-(5u >> (garr[i1 & 7u] & 31u)), i2, i0); }
                    }
                }
                if (0xde735b19u) {
                    break; (void)((unsigned)(signed char)(unsigned)((int)(unsigned)d0 < (int)0x48515b23u));
                    *q0 = g0;
                    if ((unsigned)((int)0x7fffffffu >= (int)(r0.y | 0x3ef0ad0du))) break;
                    h1 = (unsigned short)(h1 + ((unsigned)((int)(unsigned)l0 < (int)(*q0 ^ i2)) + i2));
                    if ((4u ^ (unsigned)(x0 >> 70))) goto L3;
                    u0 = u0 * 0x9e3779b1u + (unsigned)(8u == 0xa1e90176u);
                } else {
                    d0 = d0 * 0.5 + (double)((g0 >> ((fuel << ((unsigned)((unsigned)b0 < a0[u1 & 3u]) & 31u)) & 31u)) & 1023u);
                    if (fuel < 8u) return (unsigned)((int)garr[u2 & 7u] >= (int)u1);
                }
                break; (void)((unsigned)(u3 && (unsigned)c1));
                for (;;) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + ((unsigned)((short)m0 > (signed char)*mp) << ((unsigned)((int)u1 < (int)5u) & 31u));
                    L3: if (--fuel == 0u) goto done;
                    if (u3) break;
                }
            }
            for (;;) { if (--fuel == 0u) goto done;
                r0.y ^= ((unsigned)(0x7fffffffu || v0) / (0xa66de04bu | 1u));
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((short)*mp > (signed char)i1) < v0) & 255u);
                g0 = garr[u2 & 7u];
                if (8u) break;
            }
            w0 ^= (unsigned long long)(unsigned)d0 << (((0x80000000u >> (~(unsigned)((int)((unsigned)(w0 >> 29) & u0) >= (int)u2) & 31u)) << ((unsigned)h1 & 31u)) & 63u);
        }
        e0 = e0 * 0.5L + (long double)((unsigned)(short)(p0 ^ 0x10000u) & 1023u);
        switch ((unsigned)((short)0xf57bb1dbu > (signed char)(unsigned)s0) & 7u) {
            u2 = u2 * 0x9e3779b1u + ~(i0 >> (r0.y & 31u));
        }
    }
    if ((unsigned)x0) goto L1;
    if ((unsigned)((int)*q0 >= (int)(0xb5ce358cu | *q0))) goto L3;
    h1 = (unsigned short)(h1 + (u0 * ((unsigned)c0 + i2)));
    L4: if (--fuel == 0u) goto done;
    for (;;) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)((int)0x3b4f2742u < (int)fuel) % ((unsigned)d0 | 1u)));
    }
    *q0 = ((unsigned)b0 | (unsigned)c1);
    f0 = f0 * 0.5f + (float)((((unsigned)l0 - 0x3bbbaf4cu) & g1) & 255u);
    garr[(unsigned)((unsigned)x0 && p1) & 7u] = (unsigned)((unsigned)h1 || ((0x76c49e98u % ((unsigned)(garr[i1 & 7u] == v0) | 1u)) / (0x80000000u | 1u)));
    r0.x = (unsigned)((*q0 * (unsigned)s1) < *mp);
    u2 ^= (unsigned)!(m0 >> ((1u >> (0xffffffffu & 31u)) & 31u));
    f0 = f0 * 0.5f + (float)(((unsigned)((int)r0.y < (int)1u) ^ (unsigned)((short)fuel > (signed char)(u0 + fuel))) & 255u);
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                s0 = (int)a0[u1 & 3u];
                if ((1u + 0xffffffffu)) break;
                if (g1) break;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(short)(unsigned)(fuel == (u1 + a0[u1 & 3u])), r0.x, (unsigned)((int)(*q0 * 0xffffffffu) >= (int)i0)); }
                v0 = (i2 * (r0.x >> (0x7fffffffu & 31u)));
            }
            while (i2++ < 4u && (unsigned)l0) { if (--fuel == 0u) goto done;
                a0[0xe683f319u & 3u] = ((unsigned)((short)p0 > (signed char)0x7b83ba54u) ^ ((unsigned)e0 - (0xb29efee7u >> (garr[u2 & 7u] & 31u))));
                { unsigned t3; double z3; if (((unsigned)w0) & 1u) { t3 = u0; z3 = (double)(((unsigned)c0) & 255u); } if (((unsigned)w0) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    if (-(unsigned)((int)r0.y < (int)u3)) break;
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)f0 < u1));
                    h0 = (short)(~(0x10000u << (g0 & 31u)) - (unsigned)((int)7u < (int)0x6d37a936u));
                }
                m0 ^= ((unsigned)((unsigned)(w0 >> 29) < g1) + (unsigned)!(2u - ((unsigned)s0 % ((unsigned)(w0 >> 29) | 1u))));
                break; (void)((unsigned)((int)7u < (int)(unsigned)f0));
                c0 = (unsigned char)(unsigned)((unsigned)s1 || (unsigned)h0);
                if ((r0.y % (0x37e86a07u | 1u))) goto L2;
            }
            goto L0;
            { unsigned t4; double z4; if ((m0) & 1u) { t4 = (0x10000u % (0x784d26dfu | 1u)); z4 = (double)(((unsigned)((int)(unsigned)((int)i1 >= (int)(unsigned)h0) < (int)(unsigned)(x0 >> 70))) & 255u); } if ((m0) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                d0 = d0 * 0.5 + (double)((unsigned)(short)(unsigned)(((unsigned)w0 >> ((unsigned)(0xffffffffu || (unsigned)h1) & 31u)) < 4u) & 1023u);
                s1 = (int)((unsigned)s1 + (u0 ? ((unsigned)b0 * r0.x) : r0.x));
            }
            if ((unsigned)!(((unsigned)w0 % (0x7f7de023u | 1u)) + garr[u2 & 7u])) break;
            continue; (void)((*mp * (unsigned)((int)(unsigned)x0 >= (int)(unsigned)h0)));
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0(r0.y, 5u, (unsigned)(garr[u2 & 7u] && (unsigned)s0)); }
        if (budget != 0u) { budget -= 1u; u3 = fn0((*mp << (0x10000u & 31u)), (unsigned)w0, 0x45fdd4fbu); }
        switch (((i1 | u0) + 0xdcdf9b26u) & 7u) {
            s0 = (int)(unsigned)(0x7fffffffu && -(unsigned)((unsigned)c1 && garr[i1 & 7u]));
            case 7u: ;
        }
        if (g1) continue;
    }
    goto L3;
    u3 = ((unsigned)((int)(0x8486ee22u & (m0 / (0x7fffffffu | 1u))) >= (int)r0.x) + (unsigned)s0);
    if (((unsigned)(u3 < garr[u2 & 7u]) >> ((unsigned)h1 & 31u))) {
        if (budget != 0u) { budget -= 1u; u0 = fn2(-((unsigned)x0 * 0xffffffffu), (unsigned)!(g1 & (6u << ((unsigned)d0 & 31u))), ((unsigned)w0 + (unsigned)x0)); }
    } else {
        goto L4;
        e0 = e0 * 0.5L + (long double)((unsigned)((short)0xffffffffu > (signed char)0x1886db53u) & 1023u);
        if ((5u + (unsigned)(signed char)(a0[u1 & 3u] * 0xaceedb61u))) goto done;
    }
    *mp = *q0;
    d0 = d0 * 0.5 + (double)(((unsigned)l0 / ((unsigned)(x0 >> 70) | 1u)) & 1023u);
    if ((unsigned)b0) goto L1;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((1u ^ m0)) break;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1(i2, ((unsigned)h0 ? garr[i1 & 7u] : 3u), ((unsigned)h0 >> ((p1 ^ (unsigned)x0) & 31u))); }
    u3 = u3 * 0x9e3779b1u + (unsigned)s1;
    q0 = &garr[(unsigned)(signed char)(7u ^ ((unsigned)l0 >> ((unsigned)!(u3 / ((g1 ^ 0xffffffffu) | 1u)) & 31u))) & 7u];
    do { if (--fuel == 0u) goto done;
        if (0x9a7bb59du) break;
        u0 = 0u;
    } while (i0++ < 2u && (0x7fffffffu & u3));
    while (i0++ < 4u && (i2 << (*q0 & 31u))) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(signed char)(0xb613727fu >> ((unsigned)(unsigned char)(unsigned)(p1 < (unsigned)c0) & 31u)));
        if (r0.y) {
            u0 ^= ((unsigned)e0 << (((unsigned)c1 ^ *mp) & 31u));
            c0 = (unsigned char)((unsigned)(signed char)((unsigned)((int)*mp < (int)v0) % ((unsigned)h0 | 1u)) % ((unsigned)h0 | 1u));
            break; (void)(a0[u1 & 3u]);
            x0 = x0 * 0x100000001b3ull + ((unsigned)d0 & (unsigned)((unsigned)(a0[u1 & 3u] && 0xbf308f78u) < 8u));
        }
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (i1) {
                    if (budget != 0u) { budget -= 1u; u1 = fn1(m0, (unsigned)((int)(g1 + m0) < (int)p2), (unsigned)e0); }
                    if (budget != 0u) { budget -= 1u; u0 = fn0(0xffffffffu, (u2 * (unsigned)((int)(unsigned)w0 >= (int)(unsigned)b0)), (unsigned)f0); }
                    b0 = ((unsigned)(0xd4feb0f1u < (unsigned)h0) ? u1 : ((unsigned)d0 & 0x7fffffffu)) != 0u;
                    u1 ^= (unsigned)((int)(g0 * (unsigned)w0) >= (int)(unsigned)!(unsigned)((unsigned)((int)0x4c6785d4u >= (int)(unsigned)s0) == 0u));
                    e0 = e0 * 0.5L + (long double)((0x7fffffffu - (unsigned)((int)u1 >= (int)(unsigned)(((unsigned)x0 - (unsigned)b0) < (unsigned)(x0 >> 70)))) & 1023u);
                }
                if (((unsigned)e0 * (unsigned)c1)) break;
                w0 ^= (unsigned long long)(unsigned)f0 << ((unsigned)e0 & 63u);
                r0.x = m0;
                switch (g0 & 7u) {
                    case 2u: ;
                    l0 = (long)((unsigned long)l0 + fuel);
                }
            }
        } while (i1++ < 5u && (unsigned)(p0 || *mp));
        if (((unsigned)h1 | (unsigned)(w0 >> 29))) {
            if ((unsigned)(u3 && (g0 / (0xef55d429u | 1u)))) {
                r0.y ^= (unsigned)(unsigned char)(garr[i1 & 7u] >> ((unsigned)w0 & 31u));
            } else {
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((short)*mp > (signed char)(unsigned)b0) % (0x7df35094u | 1u)), i0, i0); }
                i0 = (0x10000u ^ (unsigned)(r0.y < garr[u2 & 7u])) & 15u;
                h1 = (unsigned short)(h1 + a0[i0 & 3u]);
                continue; (void)(((unsigned)((short)v0 > (signed char)(unsigned)(x0 >> 70)) & 1u));
            }
        } else {
            u0 = (unsigned)w0;
            while (i1++ < 5u && ((unsigned)((short)7u > (signed char)8u) << (p1 & 31u))) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (p1 - (unsigned)((int)(unsigned)((short)(unsigned)d0 > (signed char)garr[i1 & 7u]) >= (int)i2));
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)-(p0 ? m0 : m0) >= (int)u2);
                if ((unsigned)(u1 && p0)) {
                    u0 += (unsigned)b0;
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        u1 += (unsigned)((unsigned)(p2 == v0) < (0x3f73157au & r0.y));
                        continue; (void)((unsigned)(a0[u1 & 3u] < (unsigned)((short)(unsigned)c0 > (signed char)u2)));
                        continue; (void)(((p1 - (unsigned)s1) + r0.x));
                        if ((garr[i1 & 7u] * (unsigned)x0)) break;
                    }
                    if ((a0[i0 & 3u] | m0)) break;
                    do { if (--fuel == 0u) goto done;
                        if (*mp) break;
                        if ((fuel * (unsigned)(x0 >> 70))) break;
                        if ((unsigned)((unsigned)h1 || 0x873d1f15u)) break;
                        if (fuel < 8u) return (unsigned)((int)g1 < (int)((unsigned)c1 - m0));
                    } while (i2++ < 2u && fuel);
                    b0 = (unsigned)b0 != 0u;
                    if (0x80245a11u) break;
                }
                if (((unsigned)c0 % ((u1 << (2u & 31u)) | 1u))) {
                    g1 += (unsigned)((int)0x5eaceaf9u < (int)(0x631431dbu - ((unsigned)b0 & (i0 / ((unsigned)s1 | 1u)))));
                    x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)e0 == (unsigned)(0xa6015579u < (unsigned)((int)0x42da9712u < (int)(unsigned)((short)(unsigned)s1 > (signed char)1u))));
                    if ((unsigned)x0) break;
                    w0 ^= (unsigned long long)m0 << ((unsigned)((int)(1u - 0xcf7aa790u) >= (int)0x7fffffffu) & 63u);
                    if ((unsigned)(signed char)((unsigned)l0 - 5u)) break;
                    if ((unsigned)((int)(unsigned)((int)0xd84980feu >= (int)p2) >= (int)0x80000000u)) break;
                } else {
                    { unsigned t5; double z5; if ((((unsigned)f0 << ((unsigned)s1 & 31u))) & 1u) { t5 = (unsigned)(unsigned char)(8u & 7u); z5 = (double)((0x97c2d01au) & 255u); } if ((((unsigned)f0 << ((unsigned)s1 & 31u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                        u0 = (unsigned)h0;
                        break; (void)(((unsigned)(short)(9u + 0x80000000u) + (unsigned)d0));
                        d0 = d0 * 0.5 + (double)((unsigned)e0 & 1023u);
                        break; (void)(0x5e896165u);
                        break; (void)((unsigned)((int)0x7fffffffu >= (int)(unsigned)l0));
                        w0 ^= (unsigned long long)(unsigned)((int)0xae1d5f4au < (int)(unsigned)(x0 >> 70)) << (((unsigned)((short)(unsigned)((short)(unsigned)e0 > (signed char)0xf2e45bau) > (signed char)(unsigned)h0) * (unsigned)((short)(unsigned)w0 > (signed char)m0)) & 63u);
                    }
                }
            }
            switch ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(4u + (unsigned)c0)) & 7u) {
                while (i1++ < 6u && (unsigned)((short)(unsigned)x0 > (signed char)0xab743c27u)) { if (--fuel == 0u) goto done;
                    if (v0) goto L1;
                    if ((unsigned)l0) continue;
                    m0 ^= 8u;
                    *q0 += 0x7ec91acau;
                }
                if ((unsigned)b0) goto L4;
                s0 = (int)(unsigned)(short)(6u << (0xa9a0e7f3u & 31u));
                if (budget != 0u) { budget -= 1u; u1 = fn1(0x10000u, ((unsigned)(w0 >> 29) - (u0 | p0)), i0); }
                w0 ^= (unsigned long long)7u << ((unsigned)(0x48d472cbu < (a0[i0 & 3u] << ((unsigned)((int)*q0 < (int)0xef9ccff5u) & 31u))) & 63u);
                while (r0.x) { if (--fuel == 0u) goto done;
                    *mp = (unsigned)((short)u3 > (signed char)(unsigned)((int)8u >= (int)9u));
                    g0 = (unsigned)((0x7fffffffu >> (p1 & 31u)) && (unsigned)((short)u3 > (signed char)8u));
                }
            }
            do { if (--fuel == 0u) goto done;
                while (i2++ < 5u && *q0) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(signed char)(unsigned)((int)u2 >= (int)(unsigned)(3u < i0)), ((unsigned)x0 ^ a0[i0 & 3u]), (unsigned)(unsigned char)((unsigned)w0 << ((unsigned)h1 & 31u))); }
                }
                *mp = (unsigned)((g0 & 0xffffffffu) && (0x80000000u ? (unsigned)l0 : r0.y));
                s0 = (int)6u;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(unsigned char)(0xd57714a3u >> (p1 & 31u))) break;
                    x0 = x0 * 0x100000001b3ull + i0;
                    u0 = u0 * 0x9e3779b1u + (a0[u1 & 3u] + *q0);
                }
                break; (void)((unsigned)((int)(unsigned)(0x5670d7bu < a0[u1 & 3u]) >= (int)m0));
                garr[(unsigned)(unsigned char)(u3 | u0) & 7u] = (unsigned)(w0 >> 29);
            } while (i1++ < 6u && (r0.y + p2));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(g0 == u0), 0x80000000u, 0xffc4a409u); }
        if (v0) {
            if (((unsigned)l0 % ((unsigned)c0 | 1u))) continue;
            if (u0) goto L3;
            *q0 += (*mp & (unsigned)((int)*q0 >= (int)i1));
            s0 = (int)(unsigned)(fuel && garr[u2 & 7u]);
            r0.y ^= (unsigned)((int)((unsigned)((int)6u < (int)(unsigned)x0) << (0x817ac14cu & 31u)) < (int)0x10000u);
            *q0 = (0x7fffffffu & (unsigned)((int)0xa2dcc592u >= (int)9u));
        } else {
            u0 += (unsigned)((short)(((unsigned)h1 * (unsigned)l0) / (0x5a309731u | 1u)) > (signed char)(unsigned)h0);
        }
        x0 = x0 * 0x100000001b3ull + 0xf6fd3a8cu;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 6u, 0x4e28e6a1u, 0x59a14c20u },
        { 9u, 0xfe08a5cfu, 0x43b9cfd3u },
        { 11u, 0xedbd06dfu, 0x3206d947u },
        { 9u, 0xa48cb82au, 0x6fd35e41u },
        { 5u, 0xa1e239fbu, 0xf42a0580u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
