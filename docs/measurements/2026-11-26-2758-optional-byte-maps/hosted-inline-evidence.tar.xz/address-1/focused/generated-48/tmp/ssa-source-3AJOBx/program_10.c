// test-ssa-source's program of seed 134000412 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x376f9859u, g1 = 0x8880b8bdu;
static unsigned garr[8] = { 0x4a12013eu, 0x96ce1b2cu, 0x1066024u, 0xfc146de9u, 0xc74a863du, 0x5c7b8717u, 0xd2df3602u, 0x348609d1u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L1;
    L0: if (--fuel == 0u) goto done;
    q0 = &garr[(unsigned)((unsigned)(unsigned char)(a0[i0 & 3u] ? (unsigned)e0 : 0x5af3948du) < (unsigned)(m0 && 0x8b246493u)) & 7u];
    do { if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
        *mp = (unsigned)(short)(unsigned)((unsigned)((short)r0.x > (signed char)(unsigned)((unsigned)((int)5u < (int)(unsigned)(w0 >> 29)) < (unsigned)c1)) && 0xdb0946c2u);
        x0 = x0 * 0x100000001b3ull + (p1 | (*mp * v0));
    } while (i0++ < 5u && 0x10000u);
    if ((unsigned)(0x7fffffffu < (unsigned)b0)) {
        if ((r0.x ^ 4u)) goto L1;
        if (((unsigned)((int)i1 >= (int)8u) / (0u | 1u))) {
            s0 = (int)(unsigned)(signed char)(unsigned)((unsigned)(x0 >> 70) == (unsigned)(p1 && 0x7fffffffu));
            while (i0++ < 5u && i0) { if (--fuel == 0u) goto done;
                L2: if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
                r0.x = (u3 << ((unsigned)((int)(unsigned)((unsigned)((short)m0 > (signed char)v0) && *mp) >= (int)7u) & 31u));
            }
        }
        if (r0.y) goto L2;
        x0 = x0 * 0x100000001b3ull + -(1u & (unsigned)(unsigned char)(unsigned)((int)i1 >= (int)(fuel << ((unsigned)x0 & 31u))));
        L4: if (--fuel == 0u) goto done;
        if ((garr[u2 & 7u] * (unsigned)(w0 >> 29))) {
            { unsigned t0; double z0; if ((garr[i1 & 7u]) & 1u) { t0 = (unsigned)((int)0x54deb4abu >= (int)6u); z0 = (double)((a0[i0 & 3u]) & 255u); } if ((garr[i1 & 7u]) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                s0 = (int)((unsigned)((int)(unsigned)e0 >= (int)(unsigned)((short)*q0 > (signed char)(unsigned)(x0 >> 70))) << (fuel & 31u));
                if (fuel < 8u) return a0[i0 & 3u];
            }
            r0.x = ~((unsigned)(w0 >> 29) / ((unsigned)((unsigned)((unsigned)(unsigned char)(r0.x + 0u) || u1) || 0xffffffffu) | 1u));
            if (0xf842d038u) {
                f0 = f0 * 0.5f + (float)((unsigned)((short)0xffffffffu > (signed char)(unsigned)s1) & 255u);
            } else {
                if (((0xffffffffu & (unsigned)w0) / (*q0 | 1u))) goto L3;
                f0 = f0 * 0.5f + (float)(-(0xffffffffu / (garr[i1 & 7u] | 1u)) & 255u);
                b0 = (unsigned)(7u || (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)s1)) != 0u;
            }
        }
    } else {
        *mp = *mp;
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)1u >= (int)((unsigned)s1 + 0x7fffffffu))) break;
        }
        do { if (--fuel == 0u) goto done;
            break; (void)(((unsigned)(short)(0x25d706cfu / ((unsigned)c0 | 1u)) * (unsigned)x0));
            l0 = (long)((unsigned long)l0 + (unsigned)(w0 >> 29));
            h1 = (unsigned short)(h1 + (unsigned)((unsigned)((int)0x80000000u >= (int)g1) || (0xaf018066u / (p2 | 1u))));
            a0[fuel & 3u] = ((0x84f5ffbau >> ((garr[u2 & 7u] << ((unsigned)c1 & 31u)) & 31u)) + (unsigned)c0);
            break; (void)((i2 | i2));
        } while (i0++ < 7u && (unsigned)((short)(i1 ^ 0x332a719cu) > (signed char)(unsigned)h0));
        g1 += (u3 | (unsigned)d0);
    }
    d0 = d0 * 0.5 + (double)(u1 & 1023u);
    f0 = f0 * 0.5f + (float)(((unsigned)(signed char)(u3 - i0) - (unsigned)(signed char)(*mp - (unsigned)l0)) & 255u);
    u2 = u2 * 0x9e3779b1u + (unsigned)((short)i2 > (signed char)(unsigned)!(unsigned)((unsigned)((short)0u > (signed char)*q0) || 5u));
    if (((unsigned)!(unsigned)(6u || *q0) + 0x7fffffffu)) {
        if ((unsigned)(unsigned char)((unsigned)(0xffffffffu == (unsigned)h0) << (r0.y & 31u))) goto L4;
        h1 = (unsigned short)(h1 + (unsigned)((unsigned)((int)(6u & p0) < (int)(unsigned)c1) && (u3 / ((unsigned)b0 | 1u))));
        goto L4;
        if ((0xffffffffu | (unsigned)b0)) {
            i0 = ((unsigned)s0 >> ((unsigned)c0 & 31u)) & 15u;
            garr[0xa56679bau & 7u] = (unsigned)x0;
            if (((unsigned)s0 % (a0[u1 & 3u] | 1u))) goto L0;
            garr[(unsigned)s0 & 7u] = (0x7fffffffu / ((fuel | *mp) | 1u));
            if ((unsigned)(~(unsigned)((unsigned)c1 && (unsigned)e0) || 0xceac0296u)) goto done;
        }
        v0 = (unsigned)(*mp && 0xffffffffu);
    } else {
        if ((i2 + (unsigned)(0x10000u == (unsigned)s0))) goto L3;
        if ((unsigned)(0x10000u && ((unsigned)w0 * (unsigned)e0))) {
            goto L2;
            c0 = (unsigned char)((unsigned)(signed char)(5u / ((unsigned)h0 | 1u)) % ((unsigned)l0 | 1u));
            *q0 += (6u * (i1 ? ((unsigned)(x0 >> 70) | (unsigned)f0) : p0));
            e0 = e0 * 0.5L + (long double)(((r0.x / (0xd63024d6u | 1u)) >> ((unsigned)(garr[i1 & 7u] < (5u >> ((unsigned)(w0 >> 29) & 31u))) & 31u)) & 1023u);
            goto L0;
        } else {
            if (v0) {
                if (6u) goto L4;
                u3 += ((unsigned)c1 ^ (unsigned)(short)(unsigned)((int)g1 >= (int)2u));
                e0 = e0 * 0.5L + (long double)((unsigned)((int)u3 < (int)(p2 & 0x21a652d3u)) & 1023u);
                do { if (--fuel == 0u) goto done;
                    if (0xa09b7c20u) break;
                    if ((unsigned)(5u || (*mp - garr[i1 & 7u]))) continue;
                    break; (void)((m0 << (2u & 31u)));
                } while (i0++ < 6u && (0xffffffffu & 0xaff81d3du));
                d0 = d0 * 0.5 + (double)((0x39b6435cu >> ((0xffffffffu >> (-(u1 | (unsigned)d0) & 31u)) & 31u)) & 1023u);
            }
        }
        e0 = e0 * 0.5L + (long double)((((unsigned)((int)garr[u2 & 7u] < (int)g1) % ((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)h1) | 1u)) << ((unsigned)s0 & 31u)) & 1023u);
    }
    if ((1u >> (p1 & 31u))) {
        h0 = (short)*mp;
    } else {
        goto L1;
        if (p0) goto done;
        if ((i1 ^ u2)) goto L0;
        goto L3;
    }
    if ((0x7fffffffu ? 4u : 0x7fffffffu)) goto L3;
    s1 = (int)((unsigned)s1 + (0x80000000u << ((unsigned)((short)r0.x > (signed char)i0) & 31u)));
    b0 = (unsigned)(signed char)((unsigned)e0 | garr[i1 & 7u]) != 0u;
    if (p2) goto L4;
    switch ((r0.y - (6u & 0x57c0db42u)) & 7u) {
        q0 = &garr[(unsigned)!(unsigned)((unsigned)s0 < *q0) & 7u];
    }
    goto done;
    switch (*mp & 7u) {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 3u: ;
            if ((unsigned)(signed char)((unsigned)(w0 >> 29) + u1)) continue;
            { unsigned t1; double z1; if ((((unsigned)(x0 >> 70) >> ((unsigned)h0 & 31u))) & 1u) { t1 = (unsigned)(p1 == ((unsigned)h0 + (unsigned)c0)); z1 = (double)((fuel) & 255u); } if ((((unsigned)(x0 >> 70) >> ((unsigned)h0 & 31u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                *mp = -((u2 >> ((0x7fffffffu ? r0.y : a0[i0 & 3u]) & 31u)) | (unsigned)x0);
                s1 = (int)((unsigned)s1 + (((unsigned)s0 * (unsigned)(unsigned char)(unsigned)((int)(unsigned)b0 >= (int)u1)) % ((unsigned)w0 | 1u)));
                g1 += ((unsigned)((int)i1 >= (int)a0[i0 & 3u]) >> ((g1 & (unsigned)w0) & 31u));
                w0 = w0 * 6364136223846793005ull + ((unsigned)d0 ^ 0xc46dd107u);
            }
            if (fuel < 8u) return ((unsigned)(short)((*mp - i2) ? 0x5ed89be8u : g0) / ((unsigned)l0 | 1u));
        }
    }
    switch (g0 & 7u) {
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 2u: ;
                i0 = (unsigned)((int)(unsigned)(5u < (unsigned)(x0 >> 70)) >= (int)v0) & 15u;
                u2 = u2 * 0x9e3779b1u + (unsigned)((int)a0[u1 & 3u] >= (int)(3u % (i1 | 1u)));
                f0 = f0 * 0.5f + (float)(r0.y & 255u);
            }
            a0[(unsigned)((int)(unsigned)x0 < (int)0x74425e78u) & 3u] = *mp;
            *q0 += -(unsigned)(a0[i0 & 3u] || ((unsigned)f0 ^ (p0 / (i1 | 1u))));
            case 4u: ;
            e0 = e0 * 0.5L + (long double)((0x4a73718au ^ 0xd8e9a0a7u) & 1023u);
        }
        if ((unsigned)(0x10000u && 6u)) goto L1;
        v0 = a0[u1 & 3u];
    }
    g1 += (unsigned)(signed char)(0x10000u << ((unsigned)(u3 || u0) & 31u));
    if ((unsigned)(w0 >> 29)) {
        do { if (--fuel == 0u) goto done;
            break; (void)(0xab9387a8u);
            switch ((unsigned)((int)0x993466b4u >= (int)v0) & 7u) {
                c1 = (signed char)(0x93557e62u + (0xcc2c3368u % (*q0 | 1u)));
                case 6u: ;
            }
            if ((0x10000u - (unsigned)(w0 >> 29))) break;
            l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)(((u1 << (0xffffffffu & 31u)) ^ u2) == 0x7fffffffu));
        } while (i0++ < 4u && (unsigned)((unsigned)((int)r0.y >= (int)0x5f089104u) < 0x256e7901u));
        if ((0u / ((unsigned)(2u && (unsigned)l0) | 1u))) goto L1;
        u1 = u1 * 0x9e3779b1u + (unsigned)(short)(unsigned)(*q0 || (fuel * (unsigned)x0));
        if ((unsigned)(0x7dddb7d1u || (unsigned)s0)) goto done;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)((0x7fffffffu * 5u) == (unsigned)(*q0 == i1));
            do { if (--fuel == 0u) goto done;
                break; (void)((unsigned)e0);
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)(4u || p0) << ((unsigned)(x0 >> 70) & 31u))) break;
                    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        u0 = u0 * 0x9e3779b1u + (unsigned)(w0 >> 29);
                        e0 = e0 * 0.5L + (long double)(((unsigned)((int)(unsigned)b0 < (int)(unsigned)s1) | 0xf97c1da6u) & 1023u);
                    }
                    b0 = (0x80000000u + 0x16407288u) != 0u;
                    for (;;) { if (--fuel == 0u) goto done;
                        r0.y ^= ((unsigned)s0 >> ((unsigned)(2u || ((unsigned)b0 / (u0 | 1u))) & 31u));
                    }
                    if ((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)(0x5d06cb8fu && p0))) break;
                }
                { unsigned t2; double z2; if (((unsigned)(u3 || u2)) & 1u) { t2 = r0.y; z2 = (double)(((u0 + (unsigned)((int)2u < (int)(unsigned)f0))) & 255u); } if (((unsigned)(u3 || u2)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    v0 = (unsigned)w0;
                    if ((9u << (0xf47e69e5u & 31u))) continue;
                    if ((unsigned)((int)u3 >= (int)u1)) break;
                    while (i2++ < 3u && (unsigned)(signed char)((unsigned)l0 % ((unsigned)(x0 >> 70) | 1u))) { if (--fuel == 0u) goto done;
                        if ((unsigned)((short)0x8db5e7a5u > (signed char)(unsigned)((short)*q0 > (signed char)garr[i1 & 7u]))) break;
                        if ((unsigned)((int)(3u | (unsigned)x0) >= (int)fuel)) break;
                        c0 = (unsigned char)(unsigned)((short)0x80000000u > (signed char)(u2 * (p0 << ((unsigned)d0 & 31u))));
                        if ((unsigned)s1) break;
                    }
                }
            } while (i1++ < 7u && (unsigned)(0x67390abcu < (u1 ^ i0)));
            if ((a0[u1 & 3u] ^ (unsigned)l0)) {
                break; (void)(i1);
                d0 = d0 * 0.5 + (double)((r0.y << ((i2 / ((unsigned)b0 | 1u)) & 31u)) & 1023u);
                m0 ^= (unsigned)((m0 * 0x43a96729u) || (unsigned)(p1 && 0xf3f5be1du));
                switch (p2 & 7u) {
                    case 4u: ;
                    if (((unsigned)(w0 >> 29) | 5u)) goto L3;
                    case 7u: ;
                }
            }
        }
        *q0 = (6u | (unsigned)l0);
    }
    { unsigned t3; double z3; if ((u3) & 1u) { t3 = (9u + (i1 ^ (unsigned)(x0 >> 70))); z3 = (double)(((i2 % ((unsigned)(w0 >> 29) | 1u))) & 255u); } if ((u3) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        for (;;) { if (--fuel == 0u) goto done;
            h0 = (short)((unsigned)h0 | (unsigned)(unsigned char)((unsigned)(garr[i1 & 7u] == (unsigned)s0) & (unsigned)((int)p1 >= (int)v0)));
            if (~(((unsigned)(w0 >> 29) - fuel) | (unsigned)c0)) continue;
            { unsigned t4; double z4; if ((((unsigned)c1 << (m0 & 31u))) & 1u) { t4 = (a0[u1 & 3u] + p1); z4 = (double)(((unsigned)((int)(unsigned)((int)v0 < (int)i1) >= (int)0xffffffffu)) & 255u); } if ((((unsigned)c1 << (m0 & 31u))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                m0 ^= -(unsigned)((unsigned)(x0 >> 70) || (*q0 - (unsigned)x0));
                if (-(unsigned)(((unsigned)e0 * g1) == (unsigned)s0)) {
                    break; (void)((0u + i2));
                    if (((unsigned)x0 ^ ((unsigned)d0 & (unsigned)w0))) break;
                    break; (void)((0x10000u << (p1 & 31u)));
                    i0 = (unsigned)((int)garr[i1 & 7u] >= (int)m0) & 15u;
                    l0 = (long)((unsigned long)l0 + (unsigned)((garr[i1 & 7u] >> (fuel & 31u)) && (unsigned)(a0[u1 & 3u] == (unsigned)e0)));
                    m0 ^= (unsigned)h0;
                }
                if ((unsigned)(unsigned char)(unsigned)((unsigned)(fuel == r0.x) < 0xc4aaaa9bu)) {
                    s0 = (int)(-(unsigned)((unsigned)f0 && 0x80000000u) * (u1 % (fuel | 1u)));
                    h0 = (short)m0;
                }
                h1 = (unsigned short)(h1 + (1u ? 9u : g0));
            }
            b0 = (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(g0 && (u3 & (unsigned)(w0 >> 29)))) != 0u;
            { unsigned t5; double z5; if (((unsigned)(0xffffffffu && p2)) & 1u) { t5 = ((unsigned)s1 & ((unsigned)(x0 >> 70) >> (0x7fffffffu & 31u))); z5 = (double)((((unsigned)((int)garr[i1 & 7u] >= (int)5u) << (u1 & 31u))) & 255u); } if (((unsigned)(0xffffffffu && p2)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                if ((unsigned)(short)((unsigned)b0 & i2)) continue;
                break; (void)((unsigned)((int)(unsigned)(0xffffffffu == 0xd623b75bu) < (int)5u));
                *q0 += (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)((short)~(unsigned)((int)g1 >= (int)p1) > (signed char)(unsigned)w0));
                u2 = ((unsigned)(i1 || (unsigned)c0) - (unsigned)b0);
                break; (void)(0x80000000u);
                if ((u0 + p0)) break;
            }
            u2 ^= (((0x74041d54u % (i2 | 1u)) ^ 7u) ? (unsigned)f0 : 8u);
        }
        goto L2;
        if ((unsigned)!((unsigned)(0x80000000u < i0) / (1u | 1u))) goto done;
        { unsigned t6; double z6; if ((((unsigned)e0 * g1)) & 1u) { t6 = u1; z6 = (double)(((i0 - (unsigned)h1)) & 255u); } if ((((unsigned)e0 * g1)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(*q0 & 1023u);
                if (fuel) break;
                if (u3 == 7u) return (unsigned)((int)(unsigned)((unsigned)l0 == u3) >= (int)3u);
                { unsigned t7; double z7; if ((5u) & 1u) { t7 = (u2 << ((unsigned)s1 & 31u)); z7 = (double)((((unsigned)((int)*mp >= (int)(unsigned)l0) << (4u & 31u))) & 255u); } if ((5u) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                    if ((unsigned)((unsigned)((unsigned)(w0 >> 29) || m0) || 0x54429b59u)) break;
                    if ((unsigned)!(unsigned)((7u * 0x1b01233au) == u3)) break;
                    h1 = (unsigned short)(h1 + (unsigned)((~(garr[u2 & 7u] + i2) ^ garr[u2 & 7u]) && (unsigned)b0));
                    w0 = w0 * 6364136223846793005ull + (unsigned)((g1 + (unsigned)b0) && ((*q0 >> (7u & 31u)) % (i2 | 1u)));
                }
                m0 ^= ((unsigned)(signed char)((unsigned)x0 * (unsigned)(x0 >> 70)) << ((*mp ? fuel : u2) & 31u));
            }
        }
    }
    goto L3;
    do { if (--fuel == 0u) goto done;
        i0 = (unsigned)((unsigned)w0 == u1) & 15u;
    } while (i0++ < 2u && -((unsigned)((int)i0 < (int)0x1471628du) - 0xffffffffu));
    do { if (--fuel == 0u) goto done;
        if (a0[i0 & 3u]) break;
        if (2u) break;
    } while (i0++ < 3u && ((0x72377450u & 6u) - (unsigned)e0));
    h0 = (short)(unsigned)h1;
    switch (0x7fffffffu & 7u) {
        case 5u: ;
    }
    if (u3 == 7u) return -(g1 ? 5u : a0[u1 & 3u]);
    if ((unsigned)((short)(unsigned)(*q0 && i1) > (signed char)0x4f5f5b34u)) goto L4;
    x0 = x0 * 0x100000001b3ull + ((unsigned)h0 | (unsigned)((int)garr[u2 & 7u] >= (int)0x64608c01u));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t8; double z8; if ((0x643fceb3u) & 1u) { t8 = ((unsigned)((int)(unsigned)d0 < (int)u0) & 0xcb7d0511u); z8 = (double)((0x7fffffffu) & 255u); } if ((0x643fceb3u) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
            a0[-(unsigned)(garr[u2 & 7u] && r0.x) & 3u] = ((unsigned)h1 * (unsigned)((short)r0.x > (signed char)a0[u1 & 3u]));
            garr[~(unsigned)((int)fuel < (int)g0) & 7u] = (a0[i0 & 3u] ? (unsigned)x0 : 0xb3a67863u);
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                a0[(unsigned)((unsigned)h1 < 4u) & 3u] = (unsigned)((short)(u2 - (unsigned)(w0 >> 29)) > (signed char)(unsigned)(0xe839bfe4u < (unsigned)s0));
                if (5u) break;
            }
            switch ((unsigned)(3u && p1) & 7u) {
                case 7u: ;
                do { if (--fuel == 0u) goto done;
                    case 5u: ;
                    c0 = (unsigned char)((unsigned)b0 >> (0x80000000u & 31u));
                    m0 ^= (unsigned)d0;
                    do { if (--fuel == 0u) goto done;
                        case 1u: ;
                        if ((unsigned)((int)0xf3060a9cu >= (int)0x294f6ee6u)) {
                            g0 = a0[u1 & 3u];
                            if ((unsigned)(w0 >> 29)) goto L3;
                            if ((unsigned)(p2 || 0x4223d27cu)) goto L1;
                            default: ;
                        } else {
                            i2 = (unsigned)(short)(u2 ^ 0xdd6197c9u) & 15u;
                            if ((0xc7de035bu % (((unsigned)w0 % (p0 | 1u)) | 1u))) goto done;
                        }
                        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)x0 || (unsigned)(u0 || -(unsigned)((int)0u >= (int)(unsigned)x0))) & 255u);
                        if (0x7fffffffu) {
                            if (0xffffffffu) goto L0;
                        }
                        case 4u: ;
                    } while (i2++ < 6u && ((unsigned)f0 % ((unsigned)(4u == (unsigned)h1) | 1u)));
                    case 6u: ;
                    do { if (--fuel == 0u) goto done;
                        if (u3 == 7u) return ((unsigned)f0 >> ((0x7fffffffu ? 5u : (unsigned)s0) & 31u));
                    } while (i2++ < 7u && ((a0[i0 & 3u] >> (0x555ccb97u & 31u)) >> ((unsigned)(w0 >> 29) & 31u)));
                } while (i1++ < 6u && (g1 | (unsigned)b0));
                g0 = ((unsigned)(u1 && a0[u1 & 3u]) >> (i0 & 31u));
                if (garr[i1 & 7u]) continue;
                break;
            }
        }
        if ((-(0x7fffffffu ^ u1) | 0x10000u)) goto done;
        u0 += (r0.y ? g1 : (unsigned)((int)(unsigned)e0 < (int)0x7c0e909u));
    }
    s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((short)(unsigned)(i2 == (unsigned)x0) > (signed char)7u) < (int)(unsigned)(signed char)(unsigned)((short)g1 > (signed char)u2)));
    r0.x = (unsigned)!(unsigned)((short)(unsigned)l0 > (signed char)7u);
    goto L0;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                break; (void)(p2);
                if ((unsigned)c1) {
                    c1 = (signed char)((unsigned)((int)(unsigned)x0 < (int)(unsigned)l0) & (u1 * ((unsigned)l0 + (unsigned)s1)));
                    break; (void)((p0 >> (r0.y & 31u)));
                    if ((g1 | (unsigned)(signed char)(0xe01efb02u * (unsigned)c0))) break;
                }
                break; (void)(((unsigned)f0 % (p1 | 1u)));
                if ((unsigned)(x0 >> 70)) goto done;
                { unsigned t9; double z9; if (((unsigned)!(unsigned)((short)u2 > (signed char)0xb1f43019u)) & 1u) { t9 = (unsigned)((int)(0xbf5d53d4u * 3u) < (int)garr[u2 & 7u]); z9 = (double)(((4u - (unsigned)f0)) & 255u); } if (((unsigned)!(unsigned)((short)u2 > (signed char)0xb1f43019u)) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                    if ((unsigned)((unsigned)(garr[i1 & 7u] < a0[u1 & 3u]) < 0xffffffffu)) break;
                    switch (((unsigned)((unsigned)e0 == p1) * 0xff3e9274u) & 7u) {
                        break; (void)((unsigned)x0);
                        *q0 += (((u3 >> ((unsigned)f0 & 31u)) - (unsigned)l0) >> (g1 & 31u));
                        while (i0++ < 4u && 4u) { if (--fuel == 0u) goto done;
                            q0 = &garr[((unsigned)((unsigned)h0 && (unsigned)e0) >> (*mp & 31u)) & 7u];
                            i1 = (unsigned)f0 & 15u;
                            case 7u: ;
                            l0 = (long)((unsigned long)l0 + ((0x80000000u >> (m0 & 31u)) - ((unsigned)((unsigned)(w0 >> 29) < garr[u2 & 7u]) / (u1 | 1u))));
                        }
                        continue; (void)((unsigned)(((unsigned)(w0 >> 29) / ((unsigned)h1 | 1u)) || 0x10000u));
                    }
                    if ((0xffffffffu >> ((9u * u2) & 31u))) break;
                    h0 = (short)((unsigned)s0 * (7u << ((unsigned)(w0 >> 29) & 31u)));
                    l0 = (long)((unsigned long)l0 + (unsigned)(3u && (unsigned)(0x7fffffffu < p1)));
                }
                if (g1) break;
            } while (i2++ < 4u && (0xd3f9ce0u | (i1 >> (garr[i1 & 7u] & 31u))));
            f0 = f0 * 0.5f + (float)(((unsigned)(short)(g1 % ((unsigned)h1 | 1u)) + garr[i1 & 7u]) & 255u);
            if ((unsigned)(0x80000000u == (i2 - i2))) break;
            do { if (--fuel == 0u) goto done;
                *q0 = m0;
                if (~(0x7fffffffu & u1)) continue;
                if ((unsigned)((int)0x50677e4au >= (int)0xa557b17bu)) continue;
            } while (i2++ < 6u && r0.y);
            u0 ^= (unsigned)((int)u1 < (int)p1);
        }
        c0 = (unsigned char)(unsigned)(unsigned char)((0x19785d33u ^ (0xffffffffu ^ g1)) % (v0 | 1u));
        w0 ^= (unsigned long long)g0 << ((unsigned)(unsigned char)(unsigned)(0x7fffffffu && (unsigned)h1) & 63u);
        do { if (--fuel == 0u) goto done;
            g1 += (unsigned)((unsigned)(unsigned char)(unsigned)(0x9ff904beu < 0x544824adu) == ~((i0 ^ 5u) >> ((unsigned)e0 & 31u)));
        } while (i1++ < 6u && 0x95b83907u);
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (g0) break;
        if ((unsigned)l0) break;
        a0[0x10000u & 3u] = (unsigned)((int)g1 >= (int)((unsigned)d0 ^ (unsigned)((short)p1 > (signed char)(unsigned)s0)));
        c0 = (unsigned char)(unsigned)((int)(i0 >> ((unsigned)x0 & 31u)) >= (int)((unsigned)f0 + (unsigned)((int)*mp < (int)i2)));
        break; (void)(((unsigned)((short)g0 > (signed char)*mp) << ((unsigned)h0 & 31u)));
        if ((m0 | p1)) break;
    }
    while (i0++ < 5u && u3) { if (--fuel == 0u) goto done;
        if (((*mp - 0xd8f57c3fu) << (u3 & 31u))) continue;
        w0 = w0 * 6364136223846793005ull + (unsigned)(garr[u2 & 7u] == (1u + (unsigned)((0xcb5793d0u + r0.y) || (unsigned)d0)));
        u1 = (0xffffffffu ^ (unsigned)w0);
        while (i1++ < 7u && (0x7fffffffu << ((unsigned)(unsigned char)(garr[u2 & 7u] - p1) & 31u))) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)l0);
            u2 = u2 * 0x9e3779b1u + ((unsigned)((short)*mp > (signed char)u0) ^ p2);
            break; (void)((unsigned)f0);
            if ((r0.x ? (unsigned)h0 : u3)) {
                c0 = (unsigned char)g0;
                if ((unsigned)((8u & 0u) || r0.y)) goto L4;
            } else {
                { unsigned t10; double z10; if (((i1 * *q0)) & 1u) { t10 = (u1 << (g0 & 31u)); z10 = (double)((4u) & 255u); } if (((i1 * *q0)) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                    c1 = (signed char)~(0xb88c1edcu & garr[i1 & 7u]);
                    break; (void)((unsigned)((unsigned)s1 == *q0));
                }
            }
        }
        if ((unsigned)((int)(unsigned)(p0 < (unsigned)w0) >= (int)1u)) continue;
    }
    a0[4u & 3u] = (unsigned)((int)(0xffffffffu + 0x3d9e70f7u) < (int)0xccc896ddu);
    { unsigned t11; double z11; if (((garr[i1 & 7u] * i0)) & 1u) { t11 = (*mp & (unsigned)((int)p2 < (int)0x10000u)); z11 = (double)((((0xef54eae0u >> (u1 & 31u)) | (unsigned)s1)) & 255u); } if (((garr[i1 & 7u] * i0)) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
        g1 += (unsigned)(u0 && 3u);
        x0 = x0 * 0x100000001b3ull + (0x1fbe3185u / (4u | 1u));
    }
    if (u3 == 7u) return ((unsigned)(v0 < (unsigned)((unsigned)(short)(unsigned)((unsigned)x0 || (unsigned)b0) < u3)) / (0xffffffffu | 1u));
    garr[a0[i0 & 3u] & 7u] = (unsigned)(short)(unsigned)((unsigned)x0 == (unsigned)((int)2u < (int)(fuel * p0)));
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)m0 << ((unsigned)(short)(p2 ^ (unsigned)(short)((0xffffffffu >> (m0 & 31u)) | i0)) & 63u);
        }
        if (0x7fffffffu) break;
        do { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)(unsigned char)((unsigned)(0u || 0x4d8a26b4u) / (((unsigned)(unsigned char)((unsigned)s0 * (unsigned)(w0 >> 29)) % (9u | 1u)) | 1u));
        } while (i1++ < 5u && (garr[i1 & 7u] << ((unsigned)x0 & 31u)));
        if ((unsigned)(0xffffffffu < *q0)) break;
        goto L0;
        if ((0xda99b077u + (unsigned)(unsigned char)(unsigned)((short)g0 > (signed char)0u))) break;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while ((unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
        g1 += (-((unsigned)(1u && u3) >> ((unsigned)h0 & 31u)) + r0.y);
        h0 = (short)(a0[u1 & 3u] / ((((unsigned)x0 ^ -(unsigned)((unsigned)h0 && r0.y)) ^ 5u) | 1u));
        if ((0x878ef4ccu & (unsigned)(0xfcd08f1fu == (unsigned)d0))) {
            if (~(((unsigned)s0 * (unsigned)e0) % ((unsigned)e0 | 1u))) {
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)h0 >= (int)i0), 0x10000u, ((unsigned)(r0.x && 4u) ^ 0x1176a2dfu)); }
                v0 = ((unsigned)w0 / (0xb8582773u | 1u));
                do { if (--fuel == 0u) goto done;
                    L0: if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)p2 << ((unsigned)l0 & 63u);
                    r0.x = (unsigned)!(unsigned)(-(unsigned)(u2 == r0.y) < (unsigned)s1);
                } while (i1++ < 4u && (unsigned)((int)(unsigned)f0 >= (int)((unsigned)s0 >> (3u & 31u))));
            } else {
                e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)((unsigned)f0 == (unsigned)f0) > (signed char)(unsigned)(u1 && 0x8caecc89u)) & 1023u);
            }
            w0 ^= (unsigned long long)(unsigned)((int)0x7fffffffu < (int)g0) << ((unsigned)((int)-(u3 - 0x7fffffffu) < (int)(unsigned)((int)(unsigned)s0 >= (int)(unsigned)!(r0.y % (r0.y | 1u)))) & 63u);
            if (-((*mp / (a0[u1 & 3u] | 1u)) & *q0)) {
                b0 = ~((unsigned)b0 | (unsigned)((unsigned)c0 == (unsigned)h0)) != 0u;
                if ((unsigned)((int)(g0 ^ 5u) < (int)garr[u2 & 7u])) goto done;
                r0.y ^= ((unsigned)h1 ? garr[i1 & 7u] : u3);
                h0 = (short)(unsigned)(0x1124e323u || (u1 << ((unsigned)b0 & 31u)));
                while (u2) { if (--fuel == 0u) goto done;
                    L1: if (--fuel == 0u) goto done;
                }
            } else {
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)0u > (signed char)garr[i1 & 7u]), (unsigned)h1, ((0xffffffffu | *mp) / (0x5c82e393u | 1u))); }
                    if ((unsigned)(0x74471944u == ((unsigned)h1 >> (0x7fffffffu & 31u)))) break;
                    continue; (void)((unsigned)((int)(m0 % (0x10000u | 1u)) >= (int)r0.y));
                    break; (void)((0x7fffffffu << ((8u - (unsigned)b0) & 31u)));
                }
                r0.y ^= (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)((int)(unsigned)l0 >= (int)(unsigned)c1));
                garr[(0u & *q0) & 7u] = g0;
            }
            switch (((unsigned)d0 >> ((unsigned)((unsigned)(x0 >> 70) < 4u) & 31u)) & 7u) {
                switch (((unsigned)f0 | 0xd30fa668u) & 7u) {
                    w0 = w0 * 6364136223846793005ull + (0u - (0x7fffffffu & ((unsigned)(0x14ae5316u == (unsigned)s1) >> (0x20cb9edfu & 31u))));
                    q0 = &garr[i1 & 7u];
                    if (fuel < 8u) return (unsigned)(u3 && ((unsigned)(0x683f3400u < (0xda7de97fu << (garr[u2 & 7u] & 31u))) >> (0u & 31u)));
                    s0 = (int)*mp;
                    q0 = &garr[(0x80000000u / (i2 | 1u)) & 7u];
                    v0 = ((unsigned)((int)(unsigned)h0 < (int)0xe1f82577u) % ((0xc02764d7u * (unsigned)((unsigned)h0 && 0x96b71da8u)) | 1u));
                }
            }
        }
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)e0 || (unsigned)((short)i2 > (signed char)garr[i1 & 7u])));
        if ((unsigned)(v0 < (unsigned)(unsigned char)(unsigned)((int)0xffffffffu >= (int)u2))) break;
    }
    *q0 = (4u ^ (fuel + 0xffffffffu));
    if ((unsigned)((unsigned)h0 || ~(0x5487c700u - fuel))) goto L0;
    if ((unsigned)((unsigned)(short)(*mp * a0[i0 & 3u]) && (unsigned)s0)) {
        if (0x7fffffffu) goto L0;
        if ((unsigned)(g0 && *mp)) {
            if (-(p0 ^ 0x1784ffc2u)) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!(unsigned)((int)*mp >= (int)0u), (p0 | (unsigned)b0), (unsigned)((short)a0[i0 & 3u] > (signed char)0x7fffffffu)); }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(i2 >> ((unsigned)l0 & 31u)) > (signed char)garr[u2 & 7u]), (unsigned)(unsigned char)(a0[u1 & 3u] - (i2 >> (0xdaffeab8u & 31u))), i0); }
            { unsigned t0; double z0; if (((0xffffffffu / ((unsigned)((unsigned)l0 < m0) | 1u))) & 1u) { t0 = i0; z0 = (double)(((unsigned)((int)3u < (int)(unsigned)(fuel == 3u))) & 255u); } if (((0xffffffffu / ((unsigned)((unsigned)l0 < m0) | 1u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                u0 = u0 * 0x9e3779b1u + ((unsigned)(short)(((u1 | m0) - 0xe7e9478fu) - u3) + 0x9a9b2681u);
            }
            c1 = (signed char)((unsigned)x0 * (unsigned)((int)(unsigned)(signed char)((unsigned)(x0 >> 70) % ((unsigned)c0 | 1u)) >= (int)(0xc74cece3u - u0)));
        } else {
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    u2 += (unsigned)((i1 / ((unsigned)h1 | 1u)) || u2);
                    u3 += (unsigned)(signed char)((unsigned)!(((unsigned)h0 + (unsigned)b0) / (u2 | 1u)) % (((unsigned)s1 >> (0xd2de5d4cu & 31u)) | 1u));
                    while ((unsigned)l0) { if (--fuel == 0u) goto done;
                        g1 += (unsigned)((unsigned)f0 == (unsigned)w0);
                        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)h0 - u0), (2u & (unsigned)((int)u2 >= (int)u1)), 0x80000000u); }
                        *q0 += (unsigned)(signed char)(unsigned)((int)u2 < (int)((unsigned)s1 % (((unsigned)((int)i2 >= (int)0xfa43fe82u) >> ((unsigned)h0 & 31u)) | 1u)));
                        garr[(unsigned)e0 & 7u] = (unsigned)(i1 || fuel);
                    }
                    u3 ^= ((unsigned)((short)p0 > (signed char)(unsigned)(m0 && p0)) << ((unsigned)(m0 < 0x85d8d5cdu) & 31u));
                    break; (void)((*q0 - a0[u1 & 3u]));
                    h0 = (short)(unsigned)l0;
                }
                L2: if (--fuel == 0u) goto done;
                if ((0x80000000u / ((m0 % (0x10000u | 1u)) | 1u))) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)(w0 >> 29) < (int)0u), (unsigned)(m0 || (unsigned)(signed char)(unsigned)((short)garr[u2 & 7u] > (signed char)0xffffffffu)), 5u); }
            }
        }
    } else {
        goto L0;
        i1 = fuel & 15u;
        b0 = (v0 - (0xffffffffu & r0.x)) != 0u;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((v0 - garr[u2 & 7u]), ((unsigned)(signed char)((unsigned)w0 >> (*mp & 31u)) >> ((unsigned)s1 & 31u)), (unsigned)((int)(p1 * (unsigned)e0) >= (int)p0)); }
    if (budget != 0u) { budget -= 1u; u0 = fn0((p1 << ((0x50b9f0edu / ((unsigned)d0 | 1u)) & 31u)), ((unsigned)b0 ? garr[i1 & 7u] : v0), 0xbaa4c7e5u); }
    if ((unsigned)e0) goto L0;
    if ((g1 - a0[i0 & 3u])) goto L1;
    s0 = (int)~((unsigned)((int)4u < (int)p2) ? r0.y : (unsigned)h1);
    { unsigned t1; double z1; if (((unsigned)s0) & 1u) { t1 = (unsigned)(unsigned char)(unsigned)((int)(a0[u1 & 3u] ^ (unsigned)w0) < (int)0xccb31e13u); z1 = (double)((0x10000u) & 255u); } if (((unsigned)s0) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        v0 = *q0;
        if (budget != 0u) { budget -= 1u; u1 = fn0((i2 * 0xbfa9fa2bu), (unsigned)!(unsigned)((short)g0 > (signed char)(unsigned)f0), ~(unsigned)(0x9e861411u || 0x80000000u)); }
        d0 = d0 * 0.5 + (double)((i1 | p0) & 1023u);
        { unsigned t2; double z2; if (((unsigned)((int)0xa6eacf6au < (int)(unsigned)(x0 >> 70))) & 1u) { t2 = (unsigned)(a0[i0 & 3u] < 0x7fffffffu); z2 = (double)(((unsigned)(0xffffffffu < (fuel + u1))) & 255u); } if (((unsigned)((int)0xa6eacf6au < (int)(unsigned)(x0 >> 70))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            goto L2;
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)(((*mp & v0) - m0));
                if ((*mp ? 0x9986e079u : 0x4cf97af0u)) {
                    L3: if (--fuel == 0u) goto done;
                    *q0 = (unsigned)!(unsigned)(fuel && i1);
                    L4: if (--fuel == 0u) goto done;
                }
                continue; (void)(0x3504ed77u);
            }
            { unsigned t3; double z3; if ((p1) & 1u) { t3 = (unsigned)(9u < u0); z3 = (double)(((unsigned)((unsigned)w0 && (u0 | (unsigned)s1))) & 255u); } if ((p1) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                w0 ^= (unsigned long long)(1u / (p1 | 1u)) << ((unsigned)((int)5u >= (int)a0[u1 & 3u]) & 63u);
            }
            u1 = (u3 % ((unsigned)f0 | 1u));
        }
    }
    for (;;) { if (--fuel == 0u) goto done;
        break; (void)(u1);
        *q0 = ((7u | fuel) % ((unsigned)(signed char)(*mp >> ((unsigned)(p2 && v0) & 31u)) | 1u));
        if ((0x7fffffffu + 0x364f1160u)) break;
    }
    if ((garr[u2 & 7u] | 0x6e86f117u)) goto done;
    switch ((unsigned)((short)u1 > (signed char)0xcf3f02c8u) & 7u) {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (u0 * (i1 | (g1 + (0x10000u / (r0.y | 1u)))));
            if ((0x80000000u & (unsigned)h0)) {
                r0.x = (unsigned)((unsigned)f0 == (unsigned)l0);
                case 2u: ;
                if ((fuel % ((r0.y % ((unsigned)b0 | 1u)) | 1u))) goto L1;
                c1 = (signed char)((unsigned)((garr[i1 & 7u] & i2) < p1) * (unsigned)f0);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(i1 || (unsigned)(0x95613b9du && 0x7fffffffu)), (unsigned)!(unsigned)(*q0 || 7u), 0u); }
            } else {
                i2 = (g1 | (((unsigned)w0 % ((unsigned)s1 | 1u)) ? i2 : u3)) & 15u;
                goto L0;
                h1 = (unsigned short)(h1 + u2);
            }
            w0 = w0 * 6364136223846793005ull + (a0[i0 & 3u] + (unsigned)(signed char)((unsigned)((int)(unsigned)((int)u2 >= (int)0x7e11c1fcu) >= (int)p2) ^ 7u));
        }
        u0 = u0 * 0x9e3779b1u + (unsigned)(signed char)(unsigned)((int)(a0[u1 & 3u] ? 2u : (unsigned)e0) < (int)-(unsigned)((unsigned)c1 || 0x80000000u));
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)b0 % (0x80000000u | 1u)), (garr[u2 & 7u] >> ((r0.y * fuel) & 31u)), 0x80000000u); }
        c1 = (signed char)(unsigned)((unsigned)e0 < (unsigned)(short)(g1 | garr[u2 & 7u]));
        { unsigned t4; double z4; if (((unsigned)(signed char)(5u & m0)) & 1u) { t4 = (unsigned)(unsigned char)(garr[u2 & 7u] + u2); z4 = (double)(((unsigned)(signed char)(0x50a30a0eu + (9u / (0x96674235u | 1u)))) & 255u); } if (((unsigned)(signed char)(5u & m0)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            case 0u: ;
            if ((0xf77c5bd6u * 6u)) break;
            if (budget != 0u) { budget -= 1u; u3 = fn0(8u, ((unsigned)s1 ? p1 : a0[u1 & 3u]), m0); }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)c1, (unsigned)(*q0 == (unsigned)b0), (g0 << ((*q0 - a0[i0 & 3u]) & 31u))); }
    }
    e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)((unsigned)d0 & i2) & 1023u);
    if (0x4dcd4ffcu) {
        i1 = (0xcca8b4edu / ((unsigned)(((unsigned)(x0 >> 70) * p2) || ((unsigned)c1 % (v0 | 1u))) | 1u)) & 15u;
        if ((unsigned)(0xa593c6deu == 0x7fffffffu)) goto L3;
        if (u3 == 7u) return (unsigned)((int)(unsigned)b0 < (int)(unsigned)((unsigned)(signed char)(unsigned)(0xffffffffu < a0[u1 & 3u]) < (unsigned)s1));
        u3 += (r0.y * (unsigned)(i0 || (u1 % (p0 | 1u))));
        *mp = (unsigned)(short)(unsigned)((int)garr[i1 & 7u] < (int)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)((unsigned)c1 && 7u)));
    } else {
        i2 = ((r0.y % (i1 | 1u)) & (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(0xf0e8e67du & 2u))) & 15u;
    }
    if (g1) {
        r0.x = (unsigned)((*q0 + (unsigned)f0) == (unsigned)e0);
        garr[(0x2e7a55beu * *mp) & 7u] = (0xffffffffu & ((unsigned)b0 - ((unsigned)h1 % (-(unsigned)(5u == 8u) | 1u))));
    } else {
        if (u3 == 7u) return (unsigned)(u3 || 0x41a83ae3u);
        i0 = (unsigned)((int)(unsigned)b0 >= (int)(unsigned)d0) & 15u;
        if ((unsigned)((int)(unsigned)c1 >= (int)(unsigned)c1)) goto L2;
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(a0[i0 & 3u], 0x378119f3u, -(6u * r0.x)); }
            break; (void)(((unsigned)(a0[i0 & 3u] || m0) ^ 6u));
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)((unsigned)((int)garr[i1 & 7u] < (int)9u) << (0x7fffffffu & 31u)), (unsigned)((int)(unsigned)d0 < (int)u1), (unsigned)((int)fuel >= (int)*mp)); }
                if (0x7fffffffu) break;
                if ((unsigned)!((unsigned)w0 ^ g0)) continue;
                u3 += (((1u % (i0 | 1u)) & v0) | *mp);
                break; (void)((unsigned)(short)(unsigned)((unsigned)w0 < (unsigned)(i1 == (unsigned)h1)));
                if ((unsigned)(v0 < (unsigned)(w0 >> 29))) goto L2;
            }
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((g0 >> (2u & 31u)));
                if ((5u + 9u)) {
                    *q0 = (unsigned)(short)(unsigned)((unsigned)((int)0x10000u < (int)0x4952550u) == (unsigned)(0x7fffffffu < (unsigned)w0));
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((0xde2307aeu + (garr[u2 & 7u] * 7u)), 6u, i1); }
                    if ((unsigned)((short)(unsigned)c1 > (signed char)p0)) break;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(a0[i0 & 3u], (unsigned)((int)(unsigned)s0 < (int)0xa17363cfu), (unsigned)s1); }
                break; (void)((unsigned)((unsigned)(p1 < (unsigned)w0) < u0));
                u1 = u1 * 0x9e3779b1u + (unsigned)e0;
                g1 += (unsigned)(garr[u2 & 7u] == -(unsigned)((short)0xdd6443e9u > (signed char)0xffffffffu));
            }
            a0[0xf95ef1ccu & 3u] = ((i2 * (unsigned)c0) + ((unsigned)e0 - 0xbe9a1489u));
        }
    }
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            while (r0.y) { if (--fuel == 0u) goto done;
                if ((p0 / ((p0 + (unsigned)c0) | 1u))) break;
                *q0 = (unsigned)((int)u2 < (int)5u);
                if ((unsigned)b0) goto L0;
                h0 = (short)(2u >> (0x80000000u & 31u));
            }
        }
        c0 = (unsigned char)(unsigned)(unsigned char)(unsigned)((2u * (u2 % (*mp | 1u))) && (r0.y >> (r0.x & 31u)));
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)0xffffffffu < (int)0x7fffffffu), 0x7fffffffu, u1); }
        if ((unsigned)((short)i0 > (signed char)0x1a76d810u)) {
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u2) break;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((unsigned)((int)~((0xda643334u * (unsigned)(x0 >> 70)) >> ((unsigned)s1 & 31u)) < (int)(unsigned)x0) & 255u);
                    x0 = x0 * 0x100000001b3ull + (9u % (u2 | 1u));
                    *q0 += (unsigned)((unsigned)((unsigned)x0 || 0x802c999cu) < (unsigned)e0);
                    if (i0) continue;
                    if (4u) goto L4;
                    if (((unsigned)d0 - (v0 & m0))) break;
                }
                if (((unsigned)((int)0x10000u < (int)*q0) & r0.y)) {
                    do { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + (0x42423c66u >> (u1 & 31u)));
                        h0 = (short)i1;
                    } while (i2++ < 2u && (unsigned)((int)(unsigned)e0 < (int)(unsigned)(x0 >> 70)));
                    garr[((unsigned)c1 >> ((unsigned)s0 & 31u)) & 7u] = (0x42290c45u << (a0[i0 & 3u] & 31u));
                    switch (((unsigned)!((unsigned)x0 | 7u) << (0xffffffffu & 31u)) & 7u) {
                        case 0u: ;
                        if ((unsigned)(signed char)((unsigned)(unsigned char)(unsigned)((unsigned)s0 == u1) | p0)) continue;
                        v0 = garr[i1 & 7u];
                        if ((9u >> (0x9469e8e7u & 31u))) {
                            if (budget != 0u) { budget -= 1u; u0 = fn0(0xffffffffu, (unsigned)((unsigned)h0 == 0xffffffffu), (p0 ^ (u2 << (9u & 31u)))); }
                            w0 ^= (unsigned long long)(unsigned)(w0 >> 29) << (((unsigned)((m0 - *mp) && ((unsigned)c1 - (unsigned)b0)) % (0xf82ec716u | 1u)) & 63u);
                            *q0 = (g1 + ((fuel ? r0.x : 0x80000000u) >> ((unsigned)b0 & 31u)));
                            l0 = (long)((unsigned long)l0 + (unsigned)((int)(((unsigned)h1 >> (0xef3d729au & 31u)) / ((0xf6c38d92u / (v0 | 1u)) | 1u)) >= (int)p0));
                            w0 ^= (unsigned long long)(u3 << ((unsigned)w0 & 31u)) << ((unsigned)(((unsigned)(0x36ca993fu && 5u) & g1) || 9u) & 63u);
                        } else {
                            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)(unsigned)((short)4u > (signed char)-(unsigned)(g0 < 0x10000u)), ((i2 << (p2 & 31u)) ^ (unsigned)b0), ((unsigned)((int)7u < (int)u2) - 9u)); }
                            if (budget != 0u) { budget -= 1u; u2 = fn0((0x763435ecu * a0[i0 & 3u]), g1, r0.y); }
                            if (((unsigned)(g1 && i2) ^ (unsigned)c0)) break;
                        }
                    }
                    do { if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + u2;
                        x0 = x0 * 0x100000001b3ull + (unsigned)((int)(0u ? (0x473f8c07u << (0x2027c6f9u & 31u)) : garr[i1 & 7u]) >= (int)*q0);
                        if ((g1 / ((unsigned)s1 | 1u))) continue;
                        if (p1) break;
                        break; (void)((unsigned)((int)i2 >= (int)p2));
                    } while (i2++ < 2u && (unsigned)!(p2 % (u2 | 1u)));
                    for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, (8u / ((1u & 0xd56b747cu) | 1u)), (unsigned)((int)(0x4a92592au % ((unsigned)s1 | 1u)) < (int)0xa2aed156u)); }
                    }
                    s0 = (int)((unsigned)(w0 >> 29) + u0);
                } else {
                    if ((unsigned)f0) goto L2;
                    q0 = &garr[((unsigned)e0 / (((unsigned)b0 / ((unsigned)f0 | 1u)) | 1u)) & 7u];
                    g0 = (*q0 * (unsigned)d0);
                }
                if ((0x3194c976u ? (unsigned)s0 : (unsigned)h0)) break;
                if (fuel < 8u) return ((u2 ? (unsigned)c0 : 0u) / (((unsigned)b0 & 0x80000000u) | 1u));
                *mp = ((0x6b416107u * u0) * (0xf447917cu + i2));
            }
            if ((8u << ((unsigned)h0 & 31u))) goto L4;
            if (*q0) break;
            break; (void)((unsigned)((short)(unsigned)f0 > (signed char)u2));
        } else {
            while (i1++ < 4u && (0x80000000u << (0xd8fdc751u & 31u))) { if (--fuel == 0u) goto done;
                { unsigned t5; double z5; if (((unsigned)d0) & 1u) { t5 = g1; z5 = (double)(((a0[u1 & 3u] - (unsigned)(0x80000000u && (unsigned)(x0 >> 70)))) & 255u); } if (((unsigned)d0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    r0.x = 0xbed827cu;
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)*q0 >= (int)(unsigned)((int)m0 < (int)*q0));
                    if (garr[i1 & 7u]) goto L4;
                    if ((unsigned)f0) {
                        x0 = x0 * 0x100000001b3ull + (7u ^ u0);
                        if ((unsigned)h0) break;
                    } else {
                        goto L3;
                        if ((unsigned)((unsigned)h0 < (unsigned)w0)) continue;
                        break; (void)((i1 / ((unsigned)!(unsigned)((unsigned)l0 && p1) | 1u)));
                        if ((unsigned)((int)(unsigned)w0 >= (int)0x10000u)) break;
                    }
                    for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            m0 ^= u3;
                            b0 = (unsigned)((int)0x80000000u < (int)r0.x) != 0u;
                            q0 = &garr[u2 & 7u];
                            if (a0[u1 & 3u]) continue;
                            u0 += (unsigned)h0;
                            v0 = 1u;
                        } while (i0++ < 4u && 0xc1593a9bu);
                        if (0x7fffffffu) goto L3;
                        goto L1;
                        if ((unsigned)(0x10000u && (unsigned)!(unsigned)((short)0x80000000u > (signed char)m0))) break;
                    }
                    if (((unsigned)x0 & u2)) break;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, a0[i0 & 3u], (unsigned)(signed char)((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)e0) << ((unsigned)b0 & 31u))); }
                x0 = x0 * 0x100000001b3ull + (unsigned)!(unsigned)((short)(unsigned)l0 > (signed char)(p0 | u1));
            }
            do { if (--fuel == 0u) goto done;
                if ((5u >> (g0 & 31u))) break;
                l0 = (long)((unsigned long)l0 + -(unsigned)((unsigned)(short)(unsigned)(((unsigned)h0 << ((unsigned)c1 & 31u)) || i2) && (unsigned)((int)0xd5403aa9u >= (int)0xa698c18fu)));
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    u1 ^= 0xc455376du;
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)((unsigned)!(0x10000u >> (u1 & 31u)) || garr[u2 & 7u]) < (unsigned)((unsigned)(w0 >> 29) && (unsigned)b0)));
                    l0 = (long)((unsigned long)l0 + (unsigned)(p0 < fuel));
                    break; (void)((7u >> ((unsigned)(signed char)(0x9a6a3c3fu % (u1 | 1u)) & 31u)));
                }
            } while (i1++ < 7u && ((garr[i1 & 7u] / (6u | 1u)) | (unsigned)s1));
            if ((i0 & g1)) {
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(unsigned)(u1 || (unsigned)s0) << ((0x517a1cd9u / (fuel | 1u)) & 63u);
                }
                *q0 = (unsigned)((short)(unsigned)e0 > (signed char)*q0);
                u3 += (a0[i0 & 3u] + -(r0.x >> (garr[i1 & 7u] & 31u)));
            } else {
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (5u - 0x10000u));
                    if ((0x24d7ca5bu ? g0 : g0)) {
                        break; (void)(((2u ^ v0) % (g1 | 1u)));
                        if ((unsigned)(w0 >> 29)) break;
                        c1 = (signed char)(unsigned)((int)u2 < (int)0x10000u);
                        d0 = d0 * 0.5 + (double)((u3 >> (((unsigned)(short)(0xc13296e1u | (unsigned)s1) * (unsigned)h0) & 31u)) & 1023u);
                        if (((unsigned)(8u == garr[i1 & 7u]) ^ garr[i1 & 7u])) break;
                    } else {
                        garr[(unsigned)(i1 == 0u) & 7u] = ((unsigned)h1 * ((unsigned)((unsigned)d0 && *mp) * (unsigned)x0));
                        a0[(unsigned)x0 & 3u] = ((p1 >> ((6u >> (r0.y & 31u)) & 31u)) << (p2 & 31u));
                        goto L0;
                        if (((unsigned)w0 % ((m0 * 0xc383ee79u) | 1u))) break;
                    }
                    if (((unsigned)l0 - garr[u2 & 7u])) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)h0 / ((unsigned)((short)m0 > (signed char)(unsigned)s1) | 1u)), (unsigned)((int)(unsigned)(x0 >> 70) < (int)g1), (*q0 << (fuel & 31u))); }
                }
                w0 ^= (unsigned long long)fuel << ((0x6e2f7262u & m0) & 63u);
            }
        }
    } while (i0++ < 7u && 0xf83726d7u);
    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(unsigned char)(r0.y / ((unsigned)w0 | 1u)) - p0), (unsigned)s0, ((unsigned)x0 | 6u)); }
    if ((unsigned)(short)(1u << ((unsigned)((short)a0[i0 & 3u] > (signed char)0xcfddcecdu) & 31u))) {
        goto L3;
        u2 = u2 * 0x9e3779b1u + ((2u / (0x80000000u | 1u)) & (unsigned)c1);
    }
    if (((unsigned)w0 >> ((unsigned)(signed char)((unsigned)s0 % (0xe64b620u | 1u)) & 31u))) goto L0;
    while ((unsigned)h1) { if (--fuel == 0u) goto done;
        a0[i2 & 3u] = -((unsigned)((short)(unsigned)(i2 == (unsigned)s1) > (signed char)(unsigned)c1) & 0x71970f6du);
        if ((~(unsigned)((unsigned)s0 < u2) * p2)) {
            if ((unsigned)(((unsigned)w0 - r0.x) && (unsigned)x0)) continue;
            q0 = &garr[((unsigned)(signed char)(unsigned)(u3 || garr[u2 & 7u]) >> ((unsigned)s0 & 31u)) & 7u];
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s0 & (unsigned)l0), (unsigned)((unsigned)s1 < (unsigned)s1), (unsigned)c0); }
            if ((unsigned)(0x7fffffffu < (unsigned)(garr[i1 & 7u] < (unsigned)c0))) goto done;
            if ((unsigned)(0x10000u == p2)) break;
        }
        if ((unsigned)((short)0xe1d7dc90u > (signed char)(unsigned)((int)0xffffffffu < (int)0x80000000u))) {
            if ((unsigned)(short)(0xfe980dd6u % (g0 | 1u))) break;
            *mp = ((0x10000u * 0x80000000u) << ((u1 - u1) & 31u));
            h0 = (short)(u3 << ((fuel << (u3 & 31u)) & 31u));
            continue; (void)(0x9fad46c8u);
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((6u << (g0 & 31u)) % (0xc2e083cbu | 1u))) break;
                if (((unsigned)c1 ^ 5u)) break;
                f0 = f0 * 0.5f + (float)((((unsigned)(a0[i0 & 3u] && garr[u2 & 7u]) + (a0[i0 & 3u] / (6u | 1u))) * (unsigned)b0) & 255u);
                if (0x45e5d4b1u) {
                    if ((unsigned)h0) goto done;
                    if ((unsigned)d0) goto L0;
                    u1 = u1 * 0x9e3779b1u + (r0.x / (((-(unsigned)((int)garr[i1 & 7u] < (int)8u) - (unsigned)h0) % (0x937c22acu | 1u)) | 1u));
                    w0 ^= (unsigned long long)0x6e2dffa8u << (u0 & 63u);
                    u3 += (g1 >> (((unsigned)((unsigned)w0 && u1) + r0.x) & 31u));
                } else {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(7u || i0), (unsigned)((int)0u < (int)(p0 - r0.x)), i1); }
                    g1 += (garr[i1 & 7u] * 3u);
                    s0 = (int)~(9u - (*mp ^ g0));
                    c1 = (signed char)(~(0x39dfffd5u & *mp) >> ((unsigned)((int)u3 < (int)(7u ^ p2)) & 31u));
                }
            }
        } else {
            if (0xb90ab15du) break;
        }
        if ((g0 ^ a0[i0 & 3u])) continue;
        g1 += ((4u >> ((unsigned)b0 & 31u)) & ~(unsigned)((int)(unsigned)w0 >= (int)*q0));
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)i2 > (signed char)p0), i2, (unsigned)b0); }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)c0 == v0), 0x226632bcu, (u0 ^ 0x140da126u)); }
    goto L2;
    b0 = (((0xc07bc7ddu ^ (unsigned)x0) % ((unsigned)h1 | 1u)) % (-(0xab27d4adu | g0) | 1u)) != 0u;
    l0 = (long)((unsigned long)l0 + ((unsigned)((int)i1 >= (int)(0x80000000u ? r0.y : i0)) ^ (unsigned)(x0 >> 70)));
    if ((unsigned)((int)u0 < (int)(unsigned)e0)) {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            v0 = ((unsigned)x0 >> ((unsigned)(x0 >> 70) & 31u));
            { unsigned t6; double z6; if (((unsigned)(signed char)(0x7fffffffu - (unsigned)((unsigned)c0 && p1))) & 1u) { t6 = ((unsigned)b0 ^ (unsigned)(0xd64aa2du || 0u)); z6 = (double)((((unsigned)s1 * ((unsigned)c0 << (garr[i1 & 7u] & 31u)))) & 255u); } if (((unsigned)(signed char)(0x7fffffffu - (unsigned)((unsigned)c0 && p1))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                if ((unsigned)((int)0x10000u < (int)(unsigned)c0)) break;
                if ((p2 * (unsigned)w0)) {
                    if (u0) break;
                    g0 = ((0xca2fda8eu | r0.y) - (0x6e05f564u / (*mp | 1u)));
                    e0 = e0 * 0.5L + (long double)((unsigned)c0 & 1023u);
                    r0.x = (unsigned)((unsigned)((int)r0.x >= (int)((unsigned)s0 * 0xffffffffu)) || (*q0 + 2u));
                    x0 = x0 * 0x100000001b3ull + (1u | (unsigned)((unsigned)(5u == (unsigned)d0) == (unsigned)e0));
                } else {
                    f0 = f0 * 0.5f + (float)(((unsigned)h0 ? -((unsigned)f0 - (unsigned)h0) : (unsigned)d0) & 255u);
                    d0 = d0 * 0.5 + (double)((unsigned)(r0.y < (unsigned)(p1 < (unsigned)(unsigned char)((8u << ((unsigned)(w0 >> 29) & 31u)) * 8u))) & 1023u);
                }
                if (fuel < 8u) return v0;
                if ((unsigned)((int)0xd1bc1b40u >= (int)(0x2ecdecfbu - 4u))) break;
                c1 = (signed char)(unsigned)(signed char)((8u | (unsigned)w0) + (unsigned)h1);
            }
            u2 ^= (unsigned)((int)(unsigned)((fuel & 0x9b9ab095u) < (unsigned)l0) >= (int)(unsigned)(0xffffffffu < g1));
        }
        switch (0x10000u & 7u) {
            while ((unsigned)((unsigned)l0 < 0xc48ae9b5u)) { if (--fuel == 0u) goto done;
                if (0x77fe0603u) {
                    *q0 += (unsigned)l0;
                }
                if ((unsigned)((short)r0.x > (signed char)(unsigned)((int)(unsigned)c1 < (int)(unsigned)h1))) {
                    b0 = (unsigned)((p2 & p0) < (unsigned)(p1 < (unsigned)s1)) != 0u;
                    v0 = (unsigned)((int)(r0.x * r0.y) < (int)0x80000000u);
                } else {
                    if ((0xffffffffu >> (v0 & 31u))) break;
                    m0 ^= ((u3 + garr[u2 & 7u]) << (a0[i0 & 3u] & 31u));
                }
                while ((a0[u1 & 3u] | 0x6798bc4u)) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)u1 < (int)0xffffffffu)) {
                        case 6u: ;
                        v0 = (unsigned)(short)((unsigned)((int)(unsigned)!(unsigned)(r0.y < i2) >= (int)u2) + i0);
                        g1 += ((2u / ((unsigned)(0xffffffffu == u1) | 1u)) ^ ((unsigned)(w0 >> 29) * 0x7fffffffu));
                        c0 = (unsigned char)(unsigned)((short)(unsigned)f0 > (signed char)(unsigned)((short)0x2c4f94b6u > (signed char)0x10000u));
                        d0 = d0 * 0.5 + (double)(i0 & 1023u);
                    } else {
                        l0 = (long)((unsigned long)l0 + ((unsigned)(short)(*mp & p0) << (6u & 31u)));
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(p2 < (unsigned)d0), (p1 ^ p1), (unsigned)((short)v0 > (signed char)a0[i0 & 3u])); }
                    }
                }
                if ((fuel | fuel)) goto L3;
            }
            f0 = f0 * 0.5f + (float)(-((unsigned)b0 << ((unsigned)((short)*q0 > (signed char)(unsigned)(w0 >> 29)) & 31u)) & 255u);
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(u3 == -(unsigned)((unsigned)x0 || (unsigned)c0))) {
                while (i1++ < 7u && (unsigned)((int)0xcc8300f3u < (int)0xffffffffu)) { if (--fuel == 0u) goto done;
                    *q0 = ~(a0[i0 & 3u] << (garr[i1 & 7u] & 31u));
                    w0 ^= (unsigned long long)(unsigned)((int)(unsigned)b0 >= (int)(unsigned)(x0 >> 70)) << ((unsigned)!(unsigned)((a0[u1 & 3u] & 8u) < (0u % (0xffffffffu | 1u))) & 63u);
                    switch (u0 & 7u) {
                        case 2u: ;
                        do { if (--fuel == 0u) goto done;
                            if ((unsigned)l0) break;
                            m0 ^= (unsigned)((unsigned)((short)0xf7bc50bdu > (signed char)4u) && u0);
                            if (v0) continue;
                            if (budget != 0u) { budget -= 1u; u1 = fn0(9u, (0xf7dc45d6u << (4u & 31u)), (unsigned)s0); }
                            v0 = (unsigned)h1;
                        } while (i2++ < 2u && (unsigned)((short)m0 > (signed char)3u));
                        s0 = (int)(u2 ? u2 : (unsigned)x0);
                        g0 = (unsigned)(unsigned char)(unsigned)((unsigned)w0 && (unsigned)((int)6u >= (int)(unsigned)(((unsigned)s1 | u3) || p2)));
                        if (((0xf24fb97cu / (*mp | 1u)) | 0xffffffffu)) break;
                    }
                    { unsigned t7; double z7; if ((5u) & 1u) { t7 = (unsigned)((unsigned)!(g1 >> (i1 & 31u)) && 0x1cfab0f1u); z7 = (double)(((0xc4b1bebcu - (unsigned)(short)(unsigned)(0x80000000u < 9u))) & 255u); } if ((5u) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                        if ((((unsigned)d0 << (0x7fffffffu & 31u)) << (garr[u2 & 7u] & 31u))) break;
                        l0 = (long)((unsigned long)l0 + 0x80000000u);
                        break; (void)(0xffffffffu);
                        l0 = (long)((unsigned long)l0 + ~((unsigned)((int)(unsigned)w0 >= (int)0x2d8c7293u) * a0[u1 & 3u]));
                    }
                }
                { unsigned t8; double z8; if ((0x4002a72bu) & 1u) { t8 = (3u ^ (unsigned)w0); z8 = (double)(((r0.x >> (((unsigned)l0 + 0x80000000u) & 31u))) & 255u); } if ((0x4002a72bu) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                    garr[p0 & 7u] = 6u;
                    if (m0) {
                        if ((u2 | 0x85071354u)) break;
                        u3 ^= 6u;
                        v0 = ((6u - (unsigned)x0) / (r0.y | 1u));
                        if ((*q0 ^ (unsigned)((short)0xee1315dbu > (signed char)(unsigned)x0))) goto L3;
                        u3 ^= (unsigned)(signed char)((unsigned)((int)(unsigned)s0 >= (int)(r0.x | i1)) * (unsigned)x0);
                        q0 = &garr[0xffffffffu & 7u];
                    } else {
                        if ((unsigned)((int)0xc35ca35cu < (int)(unsigned)w0)) break;
                        if (p0) goto done;
                    }
                    if ((unsigned)((int)p0 < (int)(unsigned)(m0 && (unsigned)f0))) continue;
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)c0) break;
                        break; (void)((unsigned)((unsigned)(i1 && i0) < (unsigned)c1));
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((i0 ? (unsigned)x0 : garr[i1 & 7u]), (p1 >> ((unsigned)(short)(4u ^ r0.x) & 31u)), (unsigned)(0x7fffffffu < (unsigned)s0)); }
                    if (i0) break;
                }
                if (0x10000u) continue;
                *q0 += (unsigned)((unsigned)((unsigned)(x0 >> 70) || 0x7fffffffu) || (unsigned)((int)(a0[u1 & 3u] ^ (unsigned)w0) < (int)a0[i0 & 3u]));
            } else {
                g0 = ((unsigned)(short)(garr[i1 & 7u] * 0x57ceb18du) ? (a0[i0 & 3u] % (*mp | 1u)) : 0xc0be92edu);
                if (p0) break;
            }
            if ((unsigned)e0) break;
            r0.y ^= a0[i0 & 3u];
            if ((unsigned)b0) continue;
        }
        b0 = (a0[u1 & 3u] & *mp) != 0u;
        if (((unsigned)(0xd81f0b0fu == garr[u2 & 7u]) % (0x10000u | 1u))) goto L0;
    }
    if ((garr[i1 & 7u] + ~(i2 + fuel))) goto L3;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (5u & (r0.x + 0x10000u));
        v0 = 3u;
        f0 = f0 * 0.5f + (float)((unsigned)w0 & 255u);
        break; (void)(r0.y);
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)s0 < 0x3dece551u)) break;
        }
        { unsigned t9; double z9; if ((a0[u1 & 3u]) & 1u) { t9 = ((unsigned)b0 / ((0x1d2c3327u >> (9u & 31u)) | 1u)); z9 = (double)((p0) & 255u); } if ((a0[u1 & 3u]) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
            do { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)((short)0xa0a0f74cu > (signed char)(unsigned)(0xffffffffu < m0)) & 255u);
                if ((p2 * 0xcd712051u)) break;
            } while (i1++ < 2u && a0[i0 & 3u]);
        }
    }
    d0 = d0 * 0.5 + (double)(((unsigned)(w0 >> 29) / (u1 | 1u)) & 1023u);
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        s0 = (int)8u;
        switch ((u3 * 0x80000000u) & 7u) {
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(((u1 * p0) & 0x793f9a92u) & 255u);
                m0 ^= (unsigned)((int)u3 >= (int)p0);
            }
        }
        while (i1++ < 3u && ((unsigned)(*q0 || 2u) >> ((unsigned)h1 & 31u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(u2 && (unsigned)((int)9u >= (int)(unsigned)c1)), p1, ((unsigned)!((unsigned)d0 ^ i2) % (g1 | 1u))); }
        }
        c1 = (signed char)(u0 / (((unsigned)((unsigned)e0 == a0[i0 & 3u]) ^ (2u | u0)) | 1u));
    }
    x0 = x0 * 0x100000001b3ull + (0x7fffffffu % (*mp | 1u));
    a0[(unsigned)(7u < u2) & 3u] = p1;
    if (u3 == 7u) return (((garr[u2 & 7u] % (3u | 1u)) + (unsigned)(x0 >> 70)) >> ((unsigned)h0 & 31u));
    if ((unsigned)(8u < i1)) goto L1;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t10; double z10; if (((unsigned)!(p1 & p2)) & 1u) { t10 = (unsigned)(v0 || (unsigned)e0); z10 = (double)((((unsigned)e0 ^ i1)) & 255u); } if (((unsigned)!(p1 & p2)) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
            if ((u1 << ((unsigned)(0xffffffffu && *mp) & 31u))) break;
            break; (void)((3u % ((4u | 0x80000000u) | 1u)));
            if (((unsigned)(i2 || (unsigned)x0) ^ 0x2eaf27d8u)) {
                if ((unsigned)(unsigned char)((unsigned)s1 - r0.y)) break;
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (fuel) goto L0;
                }
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = ((unsigned)h0 ^ (unsigned)((short)i2 > (signed char)((unsigned)l0 * 0x80000000u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(unsigned)((u1 * m0) == i0), (((unsigned)c1 % (5u | 1u)) ^ garr[u2 & 7u]), 0x80000000u); }
                }
                if ((fuel >> ((unsigned)c1 & 31u))) break;
            } else {
                u3 = u3 * 0x9e3779b1u + ((unsigned)s1 ? (unsigned)(0x80000000u || 0u) : 8u);
                if ((0x28a8cf5du ^ i1)) break;
            }
        }
        x0 = x0 * 0x100000001b3ull + ((unsigned)e0 ^ i0);
    }
    if ((0xbeeab034u & (u2 + g0))) goto L2;
    if (a0[u1 & 3u]) goto L3;
    if ((unsigned)!((unsigned)c0 * 0x7825aa4au)) goto L3;
    if (budget != 0u) { budget -= 1u; u2 = fn0(0xffffffffu, ((unsigned)h0 * (unsigned)(short)(0x80000000u % (g1 | 1u))), ((unsigned)h0 | i2)); }
    e0 = e0 * 0.5L + (long double)((unsigned)(x0 >> 70) & 1023u);
    g1 += (unsigned)!(unsigned)((short)0x2fc36c98u > (signed char)(unsigned)(x0 >> 70));
    s0 = (int)(0x1f326f62u >> ((p0 ^ (unsigned)s1) & 31u));
    f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(u2 % ((0x8b2c0a0fu ^ 0x7fffffffu) | 1u)) & 255u);
    if (((3u % ((unsigned)(x0 >> 70) | 1u)) & garr[u2 & 7u])) {
        if ((unsigned)(signed char)((unsigned)s0 % (i1 | 1u))) goto L0;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    if (7u) goto L3;
    switch ((0xffffffffu | g0) & 7u) {
        s0 = (int)(0xb70194d8u * 6u);
        L1: if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)(i1 & 255u);
        *mp = (unsigned)(unsigned char)(unsigned)(((unsigned)b0 % ((garr[i1 & 7u] - (unsigned)w0) | 1u)) || (g1 / ((unsigned)d0 | 1u)));
        while (i0++ < 5u && i2) { if (--fuel == 0u) goto done;
            case 3u: ;
        }
        d0 = d0 * 0.5 + (double)((unsigned)(signed char)(unsigned)((short)((unsigned)b0 ? (9u << (9u & 31u)) : u3) > (signed char)(unsigned)e0) & 1023u);
    }
    goto L3;
    while (i0++ < 3u && (unsigned)(unsigned char)((unsigned)d0 << ((unsigned)e0 & 31u))) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)d0 < (unsigned)h0), 0xffffffffu, r0.y); }
            if ((unsigned)d0) break;
            if (m0) break;
        }
        w0 = w0 * 6364136223846793005ull + (0xffffffffu + a0[u1 & 3u]);
        *q0 += 5u;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((fuel << (g1 & 31u)), (0x7fffffffu | fuel), (u0 / (i0 | 1u))); }
    u2 += (unsigned)((int)0x7fffffffu < (int)(fuel & (*mp >> (a0[u1 & 3u] & 31u))));
    goto L4;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((0xffffffffu ? (unsigned)c0 : 4u) & 7u) {
            for (;;) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)!(~(unsigned)((unsigned)((int)(unsigned)((short)0x10000u > (signed char)0xffffffffu) < (int)0x80000000u) || p1) + r0.y) & 1023u);
                do { if (--fuel == 0u) goto done;
                    goto L4;
                } while (i2++ < 7u && ~(r0.x * 1u));
            }
            if (((unsigned)d0 >> (*q0 & 31u))) {
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(0x4ee01c3u ^ garr[i1 & 7u]) >= (int)m0), (r0.y & (unsigned)(x0 >> 70)), (((unsigned)f0 / (*q0 | 1u)) - 0x7fffffffu)); }
                m0 ^= ((unsigned)s1 - (0x5c973ce3u / (garr[i1 & 7u] | 1u)));
                l0 = (long)((unsigned long)l0 + (unsigned)d0);
                if (budget != 0u) { budget -= 1u; u0 = fn0((~(a0[u1 & 3u] / (i2 | 1u)) | a0[i0 & 3u]), a0[i0 & 3u], (0x7fffffffu >> ((unsigned)((int)(unsigned)c0 < (int)(unsigned)f0) & 31u))); }
            } else {
                if ((unsigned)w0) break;
            }
            i0 = (unsigned)((short)(unsigned)c1 > (signed char)0x57434bc5u) & 15u;
            if ((unsigned)(x0 >> 70)) {
                if (budget != 0u) { budget -= 1u; u3 = fn0(0xd567c90au, (p0 & ((unsigned)l0 >> (a0[u1 & 3u] & 31u))), 0xabdd113du); }
            }
        }
        if (i0) break;
        L2: if (--fuel == 0u) goto done;
        u2 = u2 * 0x9e3779b1u + (unsigned)(signed char)((unsigned)(short)((unsigned)(x0 >> 70) - 0u) % ((8u | (0u & 0x33f2bccbu)) | 1u));
        s1 = (int)((unsigned)s1 + (m0 + ((unsigned)((7u % (0x59178d87u | 1u)) || *q0) * 0x9438d892u)));
        if ((unsigned)!(0xffffffffu % (((unsigned)(w0 >> 29) | (unsigned)f0) | 1u))) {
            if ((unsigned)((int)(unsigned)l0 >= (int)(unsigned)((int)0xc75d985bu >= (int)fuel))) break;
            r0.x = (unsigned)((unsigned)l0 || (unsigned)((unsigned)f0 || (unsigned)((unsigned)l0 || (garr[u2 & 7u] + 0x10000u))));
        } else {
            if ((unsigned)((short)8u > (signed char)0x93dfa5f6u)) goto L2;
            *q0 = (unsigned)f0;
            if ((unsigned)((p0 * 0xffffffffu) == u3)) continue;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)((int)(unsigned)c0 < (int)garr[u2 & 7u]) || 0x74d9174eu), ((unsigned)l0 * i1), (unsigned)(i0 < g1)); }
        }
    }
    goto L3;
    x0 = x0 * 0x100000001b3ull + (unsigned)((short)(0x10000u << ((unsigned)x0 & 31u)) > (signed char)(unsigned)(signed char)(unsigned)((unsigned)s1 < v0));
    goto L3;
    e0 = e0 * 0.5L + (long double)(((unsigned)(w0 >> 29) + (unsigned)f0) & 1023u);
    { unsigned t0; double z0; if ((((p2 << (*mp & 31u)) >> ((unsigned)e0 & 31u))) & 1u) { t0 = 0x7fffffffu; z0 = (double)((-(unsigned)((int)(0x10000u | (unsigned)(x0 >> 70)) < (int)(unsigned)(x0 >> 70))) & 255u); } if ((((p2 << (*mp & 31u)) >> ((unsigned)e0 & 31u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        if (fuel < 8u) return (0x75156260u / ((unsigned)((int)(unsigned)h0 < (int)(unsigned)w0) | 1u));
        if ((1u + (*q0 + 9u))) goto L0;
        { unsigned t1; double z1; if (((unsigned)(0xffffffffu || *q0)) & 1u) { t1 = (0x7fffffffu - (unsigned)l0); z1 = (double)(((unsigned)(m0 && (unsigned)(p2 < p0))) & 255u); } if (((unsigned)(0xffffffffu || *q0)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            if ((unsigned)(i2 < 0x10000u)) goto L1;
            while (3u) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    while (i2++ < 7u && (u2 | (unsigned)!(unsigned)(0xcff6aa48u && (unsigned)x0))) { if (--fuel == 0u) goto done;
                        if ((unsigned)h1) break;
                    }
                    if (g1) goto L1;
                    if ((unsigned)((short)g1 > (signed char)r0.y)) break;
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)(unsigned)!(a0[u1 & 3u] ? -(u1 / ((unsigned)h1 | 1u)) : (unsigned)d0);
                        if ((unsigned)((int)(unsigned)h0 < (int)(4u ^ 0xb0a262f1u))) continue;
                        c1 = (signed char)u1;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(0xcd7561a6u, 0x56886c6eu, (unsigned)((unsigned)s0 && i2)); }
                    }
                    if ((unsigned)((int)p0 >= (int)(unsigned)!(unsigned)((int)m0 >= (int)9u))) break;
                }
                d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)(short)((unsigned)s1 - 0x64a42b95u) > (signed char)~(4u >> (0x80000000u & 31u))) & 1023u);
                { unsigned t2; double z2; if ((((unsigned)((unsigned)c1 && (unsigned)c0) ^ u0)) & 1u) { t2 = v0; z2 = (double)((((unsigned)x0 ? i0 : 0u)) & 255u); } if ((((unsigned)((unsigned)c1 && (unsigned)c0) ^ u0)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    L3: if (--fuel == 0u) goto done;
                    break; (void)((unsigned)(fuel == (unsigned)c0));
                    break; (void)((unsigned)((unsigned)((short)u3 > (signed char)garr[u2 & 7u]) || i2));
                    for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                            h1 = (unsigned short)(h1 + (unsigned)(0x10000u || (0u % ((garr[u2 & 7u] ? 0u : p1) | 1u))));
                            w0 ^= (unsigned long long)r0.x << (p0 & 63u);
                        }
                        u1 = u1 * 0x9e3779b1u + 8u;
                        if (((u1 ^ p0) | (unsigned)h1)) break;
                        i2 = (~((0x10000u << (i0 & 31u)) - (unsigned)d0) * 0xbba279d1u) & 15u;
                        q0 = &garr[(unsigned)(((unsigned)((int)m0 >= (int)0x5fb46a8cu) >> (3u & 31u)) == ~(p0 * (unsigned)s1)) & 7u];
                        h1 = (unsigned short)(h1 + (unsigned)((0x7fffffffu | 0x4d53d26du) || u1));
                    }
                    m0 ^= -(unsigned)((garr[u2 & 7u] ? ((unsigned)b0 / ((unsigned)e0 | 1u)) : 0xffffffffu) == (unsigned)s0);
                }
                if (((5u << (p1 & 31u)) - g0)) goto L0;
            }
            if ((r0.x & (unsigned)(*mp == 3u))) goto L0;
            i2 = (unsigned)(signed char)((unsigned)(x0 >> 70) ^ (r0.y / ((unsigned)x0 | 1u))) & 15u;
            L4: if (--fuel == 0u) goto done;
        }
        if ((unsigned)(signed char)((unsigned)((unsigned)c0 || 2u) * (unsigned)c0)) {
            a0[u3 & 3u] = ((unsigned)s0 & (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)g0));
        } else {
            goto L1;
        }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            u1 = u1 * 0x9e3779b1u + (0x80000000u >> ((unsigned)!(unsigned)((short)(0x7fffffffu + (unsigned)(short)(u2 % ((unsigned)w0 | 1u))) > (signed char)garr[i1 & 7u]) & 31u));
            if (((unsigned)e0 % (0xffffffffu | 1u))) {
                while (i1++ < 3u && u0) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + ((0x9b808cc3u - 0xc49b6ba4u) ^ ((unsigned)((int)(unsigned)c1 < (int)*mp) << (garr[i1 & 7u] & 31u)));
                    w0 = w0 * 6364136223846793005ull + -(unsigned)(((unsigned)(0x80000000u == g1) & u0) && (unsigned)s0);
                    a0[(unsigned)s0 & 3u] = ((4u << (0x10000u & 31u)) / ((unsigned)(5u || v0) | 1u));
                }
                if (a0[i0 & 3u]) goto L4;
                if (-((unsigned)(0x6fbcabd8u == (unsigned)(x0 >> 70)) / ((unsigned)c0 | 1u))) break;
                s1 = (int)((unsigned)s1 + ((u3 - (unsigned)w0) ^ (u0 ? g0 : 6u)));
            } else {
                while (i1++ < 3u && 0x10000u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(unsigned char)((0x58c4351u | u2) << (0xa35b0447u & 31u))) continue;
                }
            }
            while (i1++ < 3u && p2) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    u1 = u1 * 0x9e3779b1u + (fuel / (r0.y | 1u));
                    if ((unsigned)h0) break;
                    u3 += (((unsigned)h1 ? g1 : 0x80000000u) >> ((g1 - (unsigned)d0) & 31u));
                } while (i2++ < 6u && -(unsigned)((unsigned)c1 < (unsigned)(w0 >> 29)));
                if ((unsigned)s0) break;
                if ((-((unsigned)b0 | u0) | 1u)) break;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)(unsigned)((int)(unsigned)b0 < (int)0xca1d397cu) >= (int)(unsigned)w0), 0x10000u, (unsigned)(w0 >> 29)); }
            if (budget != 0u) { budget -= 1u; u2 = fn1((-(a0[i0 & 3u] >> (0xb9601f9cu & 31u)) % (5u | 1u)), *q0, m0); }
            if ((u2 ^ garr[u2 & 7u])) break;
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!((unsigned)((short)u2 > (signed char)(unsigned)x0) % (6u | 1u)), ((fuel & 1u) / ((unsigned)(w0 >> 29) | 1u)), (a0[u1 & 3u] << (garr[u2 & 7u] & 31u))); }
    { unsigned t3; double z3; if (((garr[u2 & 7u] | 0xfb2e9508u)) & 1u) { t3 = ((unsigned)w0 ^ (unsigned)((int)p2 >= (int)(unsigned)h0)); z3 = (double)(((a0[u1 & 3u] << (1u & 31u))) & 255u); } if (((garr[u2 & 7u] | 0xfb2e9508u)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        goto L2;
    }
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            continue; (void)((p0 / (u1 | 1u)));
        } while (i1++ < 4u && u0);
        if (i1) {
            if (i0) break;
            q0 = &garr[(unsigned)((1u ^ (unsigned)(9u < 0xffffffffu)) && (p0 % (4u | 1u))) & 7u];
            if ((unsigned)((unsigned)c0 || i2)) break;
        } else {
            w0 ^= (unsigned long long)~(unsigned)((unsigned)h1 && m0) << (p1 & 63u);
        }
        if ((p2 & (unsigned)l0)) continue;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(8u < u3), (p1 >> ((unsigned)w0 & 31u)), (unsigned)e0); }
            switch (g0 & 7u) {
                s1 = (int)((unsigned)s1 + ((0x10000u & 3u) * 0xb3101616u));
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    h0 = (short)i1;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)s0, (3u << (((unsigned)c0 >> ((unsigned)c0 & 31u)) & 31u)), (unsigned)(*q0 || 0x7cc21acau)); }
                    if (budget != 0u) { budget -= 1u; u0 = fn1(fuel, ((unsigned)e0 & (unsigned)((short)(unsigned)h1 > (signed char)*mp)), (0x7fffffffu | 7u)); }
                    case 6u: ;
                }
                h1 = (unsigned short)(h1 + ((unsigned)((unsigned)d0 < (unsigned)((short)0x9d9fc904u > (signed char)0x80000000u)) | (unsigned)b0));
                d0 = d0 * 0.5 + (double)(((unsigned)s1 | -(unsigned)((int)(0x96ccd608u | (unsigned)h0) < (int)0x10000u)) & 1023u);
            }
            { unsigned t4; double z4; if (((((unsigned)d0 >> (*mp & 31u)) << (*q0 & 31u))) & 1u) { t4 = (unsigned)((int)g1 >= (int)(unsigned)h1); z4 = (double)(((unsigned)(short)(unsigned)(v0 == *mp)) & 255u); } if (((((unsigned)d0 >> (*mp & 31u)) << (*q0 & 31u))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                e0 = e0 * 0.5L + (long double)((u0 >> (-(unsigned)((int)g0 < (int)u1) & 31u)) & 1023u);
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((g1 * (unsigned)f0) || (unsigned)b0)) break;
                    if ((unsigned)((int)0x82fb4641u < (int)(g0 >> ((unsigned)b0 & 31u)))) {
                        if ((0xffffffffu / (0xffffffffu | 1u))) break;
                        if ((unsigned)(0x4409dc82u == 0x9dbb085du)) goto L2;
                        *mp = ((0x5a565d28u - u0) + (garr[i1 & 7u] - (unsigned)((int)(unsigned)b0 >= (int)8u)));
                    } else {
                        *mp = (((unsigned)s1 * garr[u2 & 7u]) % (((unsigned)(x0 >> 70) / ((unsigned)s0 | 1u)) | 1u));
                        if (4u) continue;
                    }
                    c0 = (unsigned char)((unsigned)l0 + (unsigned)(w0 >> 29));
                } while (i2++ < 6u && (p0 / ((unsigned)(g0 < 0u) | 1u)));
                d0 = d0 * 0.5 + (double)(3u & 1023u);
            }
            *mp = (0x1320c92cu & ((unsigned)x0 / (0x7fffffffu | 1u)));
            m0 ^= (v0 >> (((unsigned)((unsigned)(x0 >> 70) && (unsigned)((int)1u >= (int)r0.y)) | 0xf1c28e65u) & 31u));
            if (budget != 0u) { budget -= 1u; u1 = fn1((i2 + r0.y), 0x10000u, (((unsigned)l0 + (unsigned)(w0 >> 29)) << ((unsigned)s1 & 31u))); }
        }
    } while (i0++ < 5u && 0x10000u);
    w0 = w0 * 6364136223846793005ull + 0x80000000u;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((garr[u2 & 7u] % ((m0 % (p2 | 1u)) | 1u)));
    }
    if (p0) goto L0;
    w0 ^= (unsigned long long)(0x557e3124u & i2) << (5u & 63u);
    switch ((unsigned)((0xaa725c2eu + (unsigned)(x0 >> 70)) && *q0) & 7u) {
        for (;;) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                garr[(unsigned)(unsigned char)(garr[i1 & 7u] * v0) & 7u] = (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)((unsigned)(signed char)(0xffffffffu % ((unsigned)f0 | 1u)) == v0));
                switch (((unsigned)f0 << (((unsigned)(w0 >> 29) << ((unsigned)c0 & 31u)) & 31u)) & 7u) {
                    q0 = &garr[(unsigned)(0u == (a0[i0 & 3u] ? (unsigned)(w0 >> 29) : 0x94e7af60u)) & 7u];
                    while (i2++ < 5u && (unsigned)((short)(unsigned)((short)0x7fffffffu > (signed char)v0) > (signed char)p0)) { if (--fuel == 0u) goto done;
                        h0 = (short)(unsigned)(u0 == (unsigned)!(0x690b1eedu ^ (unsigned)(p0 || 0xb05a1088u)));
                        case 2u: ;
                        s1 = (int)((unsigned)s1 + (garr[i1 & 7u] >> ((unsigned)(i1 || 0x10000u) & 31u)));
                    }
                    q0 = &garr[(unsigned)(signed char)(((unsigned)w0 | (unsigned)e0) ? (unsigned)s0 : (unsigned)w0) & 7u];
                    case 7u: ;
                    x0 = x0 * 0x100000001b3ull + (-(unsigned)((short)r0.y > (signed char)(unsigned)e0) ? ((unsigned)s0 ^ i2) : v0);
                    default: ;
                }
                r0.x = (unsigned)((int)0xffffffffu < (int)*mp);
            } while (i1++ < 3u && (a0[i0 & 3u] + (unsigned)((unsigned)f0 < *q0)));
            { unsigned t5; double z5; if (((garr[u2 & 7u] / ((unsigned)x0 | 1u))) & 1u) { t5 = (v0 + ((unsigned)d0 + (unsigned)(w0 >> 29))); z5 = (double)(((p2 & p1)) & 255u); } if (((garr[u2 & 7u] / ((unsigned)x0 | 1u))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 7u: ;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)l0), (unsigned)w0, (garr[i1 & 7u] - p1)); }
                    case 4u: ;
                    if ((unsigned)((int)(unsigned)d0 >= (int)v0)) goto L0;
                    if (((unsigned)e0 | ((unsigned)(x0 >> 70) ^ (unsigned)c1))) break;
                }
                default: ;
                s0 = (int)0x7fffffffu;
            }
            if (fuel < 8u) return i0;
            switch (((a0[i0 & 3u] & g0) & 0x807b2d7cu) & 7u) {
                if (((unsigned)d0 & r0.x)) continue;
                garr[(7u * u3) & 7u] = ((unsigned)c0 * 4u);
            }
        }
        break;
        case 3u: ;
        u0 += (unsigned)((unsigned)(x0 >> 70) == (unsigned)c1);
        while (*q0) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)e0 & 1023u);
            continue; (void)((unsigned)(unsigned char)((fuel >> (0x80000000u & 31u)) + (unsigned)f0));
            h0 = (short)((-(unsigned)(((unsigned)l0 / (7u | 1u)) && (unsigned)(w0 >> 29)) & (unsigned)(x0 >> 70)) >> ((unsigned)h1 & 31u));
            break; (void)((0xffffffffu / (i1 | 1u)));
        }
    }
    i0 = (unsigned)(p2 < (unsigned)(0x2d402efeu && u2)) & 15u;
    h0 = (short)(u2 >> ((unsigned)((int)(unsigned)(unsigned char)(i1 & g0) >= (int)(fuel >> ((unsigned)c0 & 31u))) & 31u));
    if ((7u << ((unsigned)(w0 >> 29) & 31u))) {
        if (~(unsigned)(fuel && ~(unsigned)(0xffffffffu || (unsigned)d0))) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0((p2 - g0), v0, (unsigned)((int)r0.x < (int)(unsigned)(r0.y && 0x80000000u))); }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!(unsigned)((unsigned)s1 == 0u), (0xe916bcd7u - r0.y), ~(unsigned)((int)(unsigned)(u3 || 0x1771e10eu) < (int)garr[i1 & 7u])); }
        goto L0;
        b0 = (p0 % (0x46067e03u | 1u)) != 0u;
        switch ((unsigned)((int)(unsigned)((short)p0 > (signed char)a0[u1 & 3u]) >= (int)(unsigned)e0) & 7u) {
            if (((unsigned)h1 << (*mp & 31u))) {
                if ((unsigned)(m0 && 0x38896bf1u)) break;
                goto L2;
                g0 = (unsigned)((unsigned)b0 == fuel);
                { unsigned t6; double z6; if (((unsigned)x0) & 1u) { t6 = (a0[i0 & 3u] ^ (unsigned)((unsigned)x0 < (unsigned)h1)); z6 = (double)((0x10000u) & 255u); } if (((unsigned)x0) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        h0 = (short)(fuel * (unsigned)((int)((unsigned)d0 ^ (unsigned)((short)(unsigned)h0 > (signed char)0x10000u)) >= (int)i1));
                        case 7u: ;
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(((unsigned)d0 % (u1 | 1u)) == u1), (m0 - 0xffffffffu), (unsigned)((short)0xffffffffu > (signed char)0xd892d0e1u)); }
                    }
                    m0 ^= (unsigned)(p0 == m0);
                    if ((unsigned)((int)(unsigned)b0 < (int)(unsigned)((short)0xffffffffu > (signed char)(unsigned)s1))) {
                        a0[(fuel * 0xb1faa302u) & 3u] = (p2 | (0x68fab3f9u ^ (u2 ^ a0[u1 & 3u])));
                        if ((4u - (unsigned)c1)) break;
                    } else {
                        case 3u: ;
                        s0 = (int)0x10000u;
                        v0 = ((unsigned)((int)(0xffffffffu | i0) >= (int)u1) << ((g1 & 0xffffffffu) & 31u));
                    }
                    m0 ^= (unsigned)!(unsigned)((int)(6u ? 5u : (unsigned)e0) >= (int)(r0.x * r0.y));
                    goto L0;
                    r0.y ^= p1;
                }
            } else {
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)s0 < (unsigned)x0), ((unsigned)(4u == 0x13951e35u) << ((unsigned)c1 & 31u)), ((unsigned)((unsigned)b0 < r0.y) ^ u2)); }
            }
            i0 = p0 & 15u;
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                u3 = u3 * 0x9e3779b1u + g0;
                *q0 += (((unsigned)w0 & a0[i0 & 3u]) - ((unsigned)c1 / (-(unsigned)((int)(unsigned)s1 >= (int)3u) | 1u)));
                h1 = (unsigned short)(h1 + (unsigned)(signed char)((9u - (unsigned)f0) - (unsigned)((int)3u < (int)0x7fffffffu)));
                w0 ^= (unsigned long long)(unsigned)(a0[i0 & 3u] < (unsigned)h1) << ((garr[u2 & 7u] * (unsigned)h0) & 63u);
                if (0x90ad429du) continue;
            }
            m0 ^= (unsigned)((0x3bc258f5u ? u1 : u1) && (v0 * i2));
            u3 = ((unsigned)s0 - (unsigned)((int)(unsigned)s1 >= (int)fuel));
        }
    } else {
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)c0, (unsigned)((unsigned)((int)i0 < (int)i0) == (unsigned)x0), (unsigned)(signed char)(p0 << ((garr[i1 & 7u] + (unsigned)s1) & 31u))); }
            x0 = x0 * 0x100000001b3ull + u0;
            f0 = f0 * 0.5f + (float)(((unsigned)(signed char)(0x2973db8au + 0x1c78e6cfu) ^ 7u) & 255u);
        } while (i0++ < 3u && (unsigned)(g1 == 0x7fffffffu));
        if ((unsigned)(unsigned char)(unsigned)((int)(7u ^ 0xdb1452c6u) < (int)(unsigned)e0)) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)w0, 0xefc86f57u, (unsigned)(short)(unsigned)((int)(unsigned)((unsigned)x0 < u0) >= (int)u0)); }
            c0 = (unsigned char)(unsigned)(0x10000u == (unsigned)((int)0x80000000u >= (int)2u));
            if ((unsigned)((int)(*mp + i2) >= (int)(unsigned)x0)) {
                if (((v0 & 1u) - (unsigned)f0)) goto L2;
            }
        }
    }
    *mp = u0;
    if (((unsigned)d0 | 0x2c5cf42du)) goto L1;
    s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((int)-(unsigned)(garr[u2 & 7u] < i2) < (int)i0) >= (int)*mp));
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!(v0 * g1), g1, (unsigned)s1); }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)e0, (unsigned)d0, r0.x); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (;;) { if (--fuel == 0u) goto done;
        u0 = u0 * 0x9e3779b1u + ((unsigned)s0 & (unsigned)((int)i2 >= (int)(unsigned)s0));
    }
    while (i0++ < 2u && (unsigned)((short)a0[u1 & 3u] > (signed char)r0.y)) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        if ((unsigned)(m0 == g0)) goto L3;
    }
    if (i2) {
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)l0 && a0[u1 & 3u]), (garr[i1 & 7u] % ((unsigned)b0 | 1u)), ((u2 / (0xa8465681u | 1u)) & *q0)); }
            L1: if (--fuel == 0u) goto done;
            while (i1++ < 4u && (unsigned)(r0.x < (unsigned)!(unsigned)(garr[u2 & 7u] == 5u))) { if (--fuel == 0u) goto done;
                g1 += ((u0 % (0xb4e9b5bfu | 1u)) & (unsigned)((unsigned)(w0 >> 29) || 0x80000000u));
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)~(unsigned)(p1 || (unsigned)x0) >= (int)garr[i1 & 7u]), (i2 % ((i2 * fuel) | 1u)), 0x7fffffffu); }
            }
            L2: if (--fuel == 0u) goto done;
            v0 = ((unsigned)(0u || 0x80000000u) ^ (unsigned)b0);
            if (budget != 0u) { budget -= 1u; u2 = fn2(u3, (unsigned)(signed char)(unsigned)(p0 == (unsigned)(short)(0x7fffffffu & 4u)), (unsigned)((int)((unsigned)(w0 >> 29) >> ((unsigned)b0 & 31u)) < (int)0x5f8267fau)); }
        } while (i0++ < 6u && (unsigned)(i2 && 0x10000u));
        e0 = e0 * 0.5L + (long double)((fuel - 9u) & 1023u);
    }
    if (budget != 0u) { budget -= 1u; u3 = fn2(g1, ((unsigned)w0 ? (unsigned)c0 : v0), ~(unsigned)(0x10000u && (unsigned)(w0 >> 29))); }
    w0 ^= (unsigned long long)(unsigned)((unsigned)(w0 >> 29) == u1) << ((unsigned)((0xffffffffu / ((u2 / (r0.x | 1u)) | 1u)) < 0x7fffffffu) & 63u);
    if (fuel < 8u) return (unsigned)c0;
    L3: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u2 = fn1((p1 ^ (unsigned)h0), (unsigned)(signed char)(((unsigned)c0 << (0xd7f27e70u & 31u)) / (p2 | 1u)), (unsigned)(garr[u2 & 7u] == (unsigned)w0)); }
    c1 = (signed char)(unsigned)((int)0x3bf47f6au < (int)2u);
    if ((unsigned)((unsigned)(unsigned char)(0xd9ce7ebu % ((unsigned)e0 | 1u)) == i2)) {
        q0 = &garr[(unsigned)((r0.x / ((unsigned)(0x98db0ee2u && 0x10000u) | 1u)) < (unsigned)((unsigned)c0 < (unsigned)h0)) & 7u];
        v0 = (unsigned)(u3 && g1);
        L4: if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)!(garr[i1 & 7u] ^ u2);
        s0 = (int)(((unsigned)(signed char)(unsigned)((unsigned)(signed char)((unsigned)b0 ^ i2) || p2) >> ((unsigned)c0 & 31u)) & u2);
    } else {
        while (i0++ < 4u && u1) { if (--fuel == 0u) goto done;
            s0 = (int)((unsigned)((unsigned)(signed char)(0xffffffffu + 0x49b38b9bu) == (unsigned)f0) >> ((0x7fffffffu - p1) & 31u));
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(*mp < 0x10000u), m0, (unsigned)x0); }
            e0 = e0 * 0.5L + (long double)(((unsigned)(x0 >> 70) + (unsigned)((int)(unsigned)h0 >= (int)((unsigned)((int)0x80000000u >= (int)u2) | (unsigned)c0))) & 1023u);
            *q0 += (v0 & (unsigned)(short)(unsigned)(3u && 0x481c4f03u));
        }
        { unsigned t0; double z0; if (((unsigned)((short)i0 > (signed char)m0)) & 1u) { t0 = ((unsigned)((int)(unsigned)h1 < (int)r0.y) - *q0); z0 = (double)(((unsigned)((short)(unsigned)l0 > (signed char)7u)) & 255u); } if (((unsigned)((short)i0 > (signed char)m0)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            do { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t1; double z1; if (((unsigned)((int)(unsigned)(r0.x && g1) >= (int)r0.x)) & 1u) { t1 = 0x80000000u; z1 = (double)(((unsigned)((int)0xb7090318u < (int)(unsigned)((int)(unsigned)c0 < (int)u3))) & 255u); } if (((unsigned)((int)(unsigned)(r0.x && g1) >= (int)r0.x)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                        u2 += 0u;
                        e0 = e0 * 0.5L + (long double)(((v0 ? (unsigned)(x0 >> 70) : 0xbcfdb43au) | (unsigned)(8u == (unsigned)h0)) & 1023u);
                        goto L2;
                        r0.x = (unsigned)(signed char)(unsigned)((short)u0 > (signed char)(unsigned)(v0 < 5u));
                        if ((unsigned)((int)u0 >= (int)(unsigned)(0x80000000u == (unsigned)f0))) goto L1;
                        b0 = ((8u & i1) * (unsigned)(0xd2540dbeu && (unsigned)(p1 == r0.y))) != 0u;
                    }
                }
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)p0 > (signed char)(unsigned)((unsigned)c1 || 0x7fffffffu)), (0x553d3a82u | (unsigned)(signed char)(unsigned)(0x1960eb29u && 0x10000u)), (unsigned)(r0.x < garr[i1 & 7u])); }
                }
                c0 = (unsigned char)(unsigned)(*q0 && a0[u1 & 3u]);
                if ((unsigned)(short)(-(*q0 + 0x225c3fbdu) ^ p2)) break;
            } while (i0++ < 2u && (unsigned)(((unsigned)c1 & (unsigned)c1) == p0));
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)d0, (unsigned)(*q0 == (unsigned)w0), 0x80000000u); }
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                b0 = (unsigned)!((0x33e5ad26u % ((unsigned)w0 | 1u)) / (m0 | 1u)) != 0u;
                i1 = -(((unsigned)x0 - (unsigned)l0) ? garr[u2 & 7u] : *mp) & 15u;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        { unsigned t2; double z2; if ((0x10000u) & 1u) { t2 = ((3u - garr[i1 & 7u]) >> (7u & 31u)); z2 = (double)((u0) & 255u); } if ((0x10000u) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                            if ((0x7fffffffu % (0x7184bbd9u | 1u))) break;
                            m0 ^= (u3 | 0x70723090u);
                            break; (void)((unsigned)(signed char)(((unsigned)h1 >> ((unsigned)b0 & 31u)) << (u0 & 31u)));
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)e0 < ((unsigned)l0 << (0x7fffffffu & 31u))), (unsigned)!((unsigned)(x0 >> 70) % (0x7fffffffu | 1u)), (unsigned)(signed char)((unsigned)(garr[i1 & 7u] && garr[i1 & 7u]) - *q0)); }
                        r0.x = ((-((unsigned)c1 ^ u1) << ((unsigned)((int)(unsigned)s1 >= (int)0xdbca4d54u) & 31u)) | 2u);
                    } while (i2++ < 4u && *q0);
                    q0 = &garr[(unsigned)(3u == (v0 >> (1u & 31u))) & 7u];
                    *q0 = (unsigned)w0;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)s0, (unsigned)h1, (unsigned)((unsigned)f0 || 4u)); }
                }
                a0[g0 & 3u] = (unsigned)(2u || (unsigned)(unsigned char)(0x10000u - (unsigned)((int)0x53d3371bu < (int)1u)));
            }
            if ((unsigned)(garr[i1 & 7u] == 2u)) goto L0;
        }
        w0 ^= (unsigned long long)(unsigned)(w0 >> 29) << ((a0[i0 & 3u] ^ m0) & 63u);
    }
    while (i0++ < 5u && (6u / (p0 | 1u))) { if (--fuel == 0u) goto done;
        { unsigned t3; double z3; if (((unsigned)((unsigned)s0 && (unsigned)((int)i0 >= (int)g1))) & 1u) { t3 = (unsigned)((short)u0 > (signed char)garr[i1 & 7u]); z3 = (double)((p1) & 255u); } if (((unsigned)((unsigned)s0 && (unsigned)((int)i0 >= (int)g1))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            h0 = (short)((unsigned)(9u < 0x60208691u) * ((unsigned)d0 - (unsigned)(signed char)(0x2f5fd221u % ((unsigned)h1 | 1u))));
            if (budget != 0u) { budget -= 1u; u1 = fn2(u3, (9u ^ 3u), fuel); }
            r0.y ^= (unsigned)((unsigned)l0 || ((u3 + p2) % ((u2 >> (0x7fffffffu & 31u)) | 1u)));
            u2 += (unsigned)(x0 >> 70);
            d0 = d0 * 0.5 + (double)(((p1 * (unsigned)f0) % (r0.x | 1u)) & 1023u);
        }
        g0 = (r0.x % ((~((unsigned)e0 * i2) - p1) | 1u));
        q0 = &garr[-(v0 - ((unsigned)h0 - (((unsigned)(x0 >> 70) << (0x2d1ce529u & 31u)) - 0x10000u))) & 7u];
    }
    { unsigned t4; double z4; if (((unsigned)e0) & 1u) { t4 = i1; z4 = (double)((v0) & 255u); } if (((unsigned)e0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        { unsigned t5; double z5; if (((0x72420bdcu + (unsigned)w0)) & 1u) { t5 = *q0; z5 = (double)((g0) & 255u); } if (((0x72420bdcu + (unsigned)w0)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            switch (((a0[i0 & 3u] / (a0[u1 & 3u] | 1u)) >> ((unsigned)s0 & 31u)) & 7u) {
                if ((unsigned)((unsigned)b0 < (unsigned)c0)) break;
                do { if (--fuel == 0u) goto done;
                    switch (((unsigned)h0 & (unsigned)h1) & 7u) {
                        h1 = (unsigned short)(h1 + (((unsigned)d0 >> ((unsigned)(0xa53e3cbeu == fuel) & 31u)) << (garr[u2 & 7u] & 31u)));
                    }
                    if (u0) break;
                    case 7u: ;
                } while (i0++ < 6u && (8u / (r0.x | 1u)));
                if (budget != 0u) { budget -= 1u; u1 = fn0(-((unsigned)((unsigned)x0 || (unsigned)w0) & p1), (0xf8963a97u ^ p1), (unsigned)l0); }
                c1 = (signed char)(unsigned)((int)(unsigned)((unsigned)c1 < (unsigned)c0) < (int)((unsigned)l0 << ((garr[u2 & 7u] ^ r0.x) & 31u)));
                case 5u: ;
                case 4u: ;
            }
            x0 = x0 * 0x100000001b3ull + (unsigned)((short)0x10000u > (signed char)(unsigned)s1);
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.x = (unsigned)((short)i2 > (signed char)0x7fffffffu);
            }
            g1 += (a0[u1 & 3u] << (((unsigned)c1 << ((unsigned)x0 & 31u)) & 31u));
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(unsigned char)((unsigned)s0 / (u2 | 1u)), 0xffffffffu, (p2 + ~(unsigned)((int)(unsigned)c0 >= (int)0x6d563125u))); }
            if ((2u % (u3 | 1u))) goto L2;
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((((unsigned)(x0 >> 70) * (unsigned)d0) + 0xc5987852u));
            s0 = (int)((unsigned)(short)(unsigned)((unsigned)b0 || r0.x) % (-(unsigned)((int)4u >= (int)(garr[u2 & 7u] & (unsigned)e0)) | 1u));
            if ((unsigned)!(r0.y ? (unsigned)w0 : a0[i0 & 3u])) break;
            g1 += ((unsigned)((int)(unsigned)s1 >= (int)(0xffffffffu * u3)) % (u2 | 1u));
        }
        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(short)(unsigned)(4u < (unsigned)((unsigned)((short)fuel > (signed char)(unsigned)b0) < a0[u1 & 3u])) && 0x80000000u) & 1023u);
        if ((unsigned)((unsigned)h0 == garr[u2 & 7u])) goto done;
        goto L4;
    }
    u2 = u2 * 0x9e3779b1u + -((0x4569e536u - (unsigned)(w0 >> 29)) << (((0x4c860f5fu ^ (unsigned)l0) + 0x593849b9u) & 31u));
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)h1, (unsigned)f0, i2); }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(garr[u2 & 7u] || 0x7fffffffu)) break;
    }
    u3 = u3 * 0x9e3779b1u + ((i0 >> (9u & 31u)) / ((9u / ((unsigned)l0 | 1u)) | 1u));
    { unsigned t6; double z6; if ((((garr[u2 & 7u] / (garr[u2 & 7u] | 1u)) - (unsigned)c0)) & 1u) { t6 = garr[u2 & 7u]; z6 = (double)((9u) & 255u); } if ((((garr[u2 & 7u] / (garr[u2 & 7u] | 1u)) - (unsigned)c0)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        { unsigned t7; double z7; if (((unsigned)((int)(unsigned)((int)0x7fffffffu >= (int)u2) >= (int)(unsigned)s0)) & 1u) { t7 = *mp; z7 = (double)(((unsigned)s0) & 255u); } if (((unsigned)((int)(unsigned)((int)0x7fffffffu >= (int)u2) >= (int)(unsigned)s0)) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
            { unsigned t8; double z8; if (((p1 / (0x786fa46u | 1u))) & 1u) { t8 = 0x7fffffffu; z8 = (double)(((unsigned)(signed char)((unsigned)h1 << (0xd28949dcu & 31u))) & 255u); } if (((p1 / (0x786fa46u | 1u))) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((int)garr[u2 & 7u] < (int)((unsigned)f0 << (-(unsigned)(r0.x < 0x7fffffffu) & 31u))) || 0x3be52bd0u);
                goto L3;
                goto L2;
                if ((0xc6b5504au / ((i1 / ((unsigned)h0 | 1u)) | 1u))) goto L3;
            }
            *mp = ((unsigned)((int)p1 < (int)(unsigned)l0) >> ((unsigned)(0x7fffffffu && ~(a0[i0 & 3u] & (unsigned)(x0 >> 70))) & 31u));
        }
        { unsigned t9; double z9; if (((unsigned)(w0 >> 29)) & 1u) { t9 = (unsigned)s1; z9 = (double)(((g0 * 1u)) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
            goto L4;
        }
        d0 = d0 * 0.5 + (double)(9u & 1023u);
        if ((0x7fffffffu ^ 8u)) {
            if (m0) goto L1;
            if ((unsigned)((garr[i1 & 7u] << (0x7fffffffu & 31u)) < 0xc9288c7cu)) goto L3;
            m0 ^= 0x8f394105u;
            *mp = (unsigned)((short)i2 > (signed char)(unsigned)((short)(fuel - i2) > (signed char)(unsigned)f0));
            a0[0u & 3u] = u2;
        } else {
            g0 = i2;
            goto L1;
            s1 = (int)((unsigned)s1 + 4u);
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1(v0, garr[u2 & 7u], (unsigned)(w0 >> 29)); }
    goto L4;
    *mp = ~(unsigned)((0x80000000u & (unsigned)((int)fuel < (int)(unsigned)b0)) || i1);
    do { if (--fuel == 0u) goto done;
        *q0 = (((unsigned)l0 ^ (unsigned)x0) ^ (0x418f283eu % (a0[u1 & 3u] | 1u)));
        if ((unsigned)((int)(unsigned)(0x7fffffffu || (unsigned)l0) >= (int)u0)) break;
        if (((unsigned)s1 ? (unsigned)(x0 >> 70) : (unsigned)f0)) break;
    } while (i0++ < 7u && (unsigned)!((unsigned)b0 | (unsigned)!(m0 & 0x10000u)));
    goto done;
    if ((unsigned)((int)0x7fffffffu < (int)(unsigned)(w0 >> 29))) goto L2;
    u2 = (*q0 | (a0[i0 & 3u] % ((0x80000000u / ((u1 | (unsigned)(x0 >> 70)) | 1u)) | 1u)));
    { unsigned t10; double z10; if ((((unsigned)(signed char)(0x3a4c663u | 0x6f26afd5u) >> (p0 & 31u))) & 1u) { t10 = (unsigned)c0; z10 = (double)((((unsigned)e0 & (unsigned)((unsigned)l0 == 2u))) & 255u); } if ((((unsigned)(signed char)(0x3a4c663u | 0x6f26afd5u) >> (p0 & 31u))) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(fuel == (unsigned)d0), (2u >> (0xa7bed588u & 31u)), u3); }
        if ((unsigned)((int)u1 < (int)fuel)) goto L4;
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)!(unsigned)(3u < a0[i0 & 3u]), (u0 - (unsigned)x0), (~(unsigned)((short)r0.x > (signed char)g1) + r0.x)); }
        *q0 += (0x8579b8ceu - (a0[u1 & 3u] ^ p0));
        e0 = e0 * 0.5L + (long double)((unsigned)((int)p1 < (int)fuel) & 1023u);
        c0 = (unsigned char)(unsigned)((int)0x80000000u >= (int)(unsigned)((int)(unsigned)(r0.y == (unsigned)b0) >= (int)u1));
    }
    while (i0++ < 6u && ((unsigned)((int)p0 >= (int)u0) * 0x418b11c2u)) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (garr[i1 & 7u]) continue;
            if ((unsigned)(short)(a0[i0 & 3u] | 0x10000u)) break;
            c0 = (unsigned char)((unsigned)((unsigned)c1 || (unsigned)l0) * (unsigned)(x0 >> 70));
        }
        if (-(unsigned)((int)(unsigned)s0 >= (int)(g0 * 0x7078f600u))) break;
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, (unsigned)(0x10000u == p2), -(unsigned)((short)(unsigned)c0 > (signed char)0x80000000u)); }
    }
    if ((u1 ? garr[u2 & 7u] : 0xcb628119u)) goto L0;
    if ((r0.y / (((unsigned)(x0 >> 70) - (unsigned)d0) | 1u))) {
        if ((unsigned)((int)(unsigned)!(unsigned)((short)0xfbc3bf7cu > (signed char)0x7fffffffu) < (int)garr[u2 & 7u])) goto L0;
    }
    if (((unsigned)e0 ^ (unsigned)s0)) goto L0;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)c0 < (int)(unsigned)(0x51e99125u || 0xd259c2c1u))) break;
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (v0) {
                *mp = v0;
                if (budget != 0u) { budget -= 1u; u1 = fn1((0xa9d7a044u >> (((unsigned)e0 + 0u) & 31u)), (0xe921d1b1u + (unsigned)s0), (unsigned)((a0[i0 & 3u] / (m0 | 1u)) && *q0)); }
                d0 = d0 * 0.5 + (double)((unsigned)((int)((unsigned)(r0.y || 0xffffffffu) + r0.x) < (int)(unsigned)(signed char)(fuel & (unsigned)s1)) & 1023u);
            }
            break; (void)(garr[i1 & 7u]);
            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((0x41b0da84u * r0.x) % (1u | 1u));
        }
        if (i0) {
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((((unsigned)x0 / ((unsigned)c0 | 1u)) + *mp)) {
                    m0 ^= ((unsigned)((int)(p2 % (p0 | 1u)) >= (int)0x6a358a13u) | 6u);
                    s0 = (int)(~(u0 & garr[u2 & 7u]) >> ((unsigned)e0 & 31u));
                    garr[*mp & 7u] = (unsigned)((int)m0 < (int)0x7fffffffu);
                }
            }
            h1 = (unsigned short)(h1 + (unsigned)(((unsigned)h0 | 0xffffffffu) && (unsigned)(x0 >> 70)));
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                u2 += (unsigned)(short)(~(unsigned)(i2 < (unsigned)e0) + u0);
                h1 = (unsigned short)(h1 + (m0 - i0));
            }
            u1 = u0;
        }
        a0[(unsigned)(w0 >> 29) & 3u] = (unsigned)((int)m0 >= (int)g1);
        g0 = fuel;
    } while (i0++ < 6u && (unsigned)(0x32bfb10du < garr[i1 & 7u]));
    *q0 = fuel;
    m0 ^= p2;
    g0 = (unsigned)((int)(unsigned)((int)(unsigned)e0 >= (int)4u) < (int)(unsigned)x0);
    if (budget != 0u) { budget -= 1u; u3 = fn2(u2, (unsigned)((int)(unsigned)((unsigned)s1 == 3u) < (int)1u), (0x80000000u + u2)); }
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            { unsigned t11; double z11; if (((unsigned)(0u || (unsigned)c1)) & 1u) { t11 = *mp; z11 = (double)((*q0) & 255u); } if (((unsigned)(0u || (unsigned)c1)) & 1u) { u3 += t11; d0 = d0 * 0.5 + z11; }
                if (budget != 0u) { budget -= 1u; u3 = fn2((r0.y + (unsigned)(p0 < g1)), (p0 + (g1 * garr[i1 & 7u])), (p2 / (-(unsigned)((int)(unsigned)(x0 >> 70) >= (int)0xffffffffu) | 1u))); }
                if (budget != 0u) { budget -= 1u; u1 = fn0(9u, u3, (unsigned)((short)0x10000u > (signed char)0xeca69ad7u)); }
                d0 = d0 * 0.5 + (double)((unsigned)(0x80000000u || (unsigned)(unsigned char)((unsigned)h1 * 5u)) & 1023u);
            }
            if ((i1 + ((unsigned)e0 - u2))) goto L1;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)h0 < (unsigned)b0), (u3 & (unsigned)s1), m0); }
            q0 = &garr[(unsigned)!(((unsigned)(short)(unsigned)(a0[i0 & 3u] == i2) & v0) ? a0[i0 & 3u] : (unsigned)(w0 >> 29)) & 7u];
            f0 = f0 * 0.5f + (float)((u2 / ((unsigned)c1 | 1u)) & 255u);
            s1 = (int)((unsigned)s1 + (unsigned)s0);
        } while (i1++ < 3u && (unsigned)((unsigned)((int)*mp >= (int)0x10000u) || 0xd93309c5u));
        if (((unsigned)(r0.x && r0.x) / (r0.x | 1u))) continue;
        if ((unsigned)((int)0xe72e20abu >= (int)(unsigned)h1)) {
            u1 ^= (((unsigned)h1 ^ (u3 / (0x526115c2u | 1u))) << ((r0.x % (a0[i0 & 3u] | 1u)) & 31u));
            r0.x = m0;
            h0 = (short)(unsigned)!((unsigned)c0 ? (unsigned)(0x7fffffffu < (unsigned)d0) : (unsigned)b0);
            break; (void)(0x80000000u);
        } else {
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((garr[u2 & 7u] * (unsigned)(w0 >> 29))) continue;
                u0 += (unsigned)(unsigned char)(unsigned)((short)6u > (signed char)(unsigned)(0xffffffffu && (unsigned)((unsigned)h0 || 0xffffffffu)));
                if (((u1 | g1) % (g1 | 1u))) continue;
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)s1) {
                        if (((g0 ^ p0) ^ 7u)) break;
                        c1 = (signed char)(unsigned)f0;
                    }
                    if (0u) {
                        if (p1) break;
                        u0 += (unsigned)(signed char)(g1 ^ -(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x10000u));
                    } else {
                        d0 = d0 * 0.5 + (double)(((unsigned)c1 ^ (unsigned)s1) & 1023u);
                        l0 = (long)((unsigned long)l0 + ((unsigned)h1 % ((unsigned)(((unsigned)((int)0x391b0797u < (int)fuel) & r0.y) || 0x80000000u) | 1u)));
                    }
                    v0 = (unsigned)(((unsigned)w0 & (unsigned)((short)i1 > (signed char)(unsigned)c0)) && (unsigned)(u3 == (unsigned)h0));
                } while (i2++ < 7u && (5u * 2u));
                if ((unsigned)e0) {
                    s1 = (int)((unsigned)s1 + (unsigned)((int)(u1 / (((unsigned)(0x79a33bffu && 8u) / (a0[i0 & 3u] | 1u)) | 1u)) >= (int)g1));
                    if ((unsigned)(u0 || (unsigned)(x0 >> 70))) continue;
                    u2 = u2 * 0x9e3779b1u + (garr[i1 & 7u] + (unsigned)(i0 && p1));
                    if (u0) break;
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)r0.x > (signed char)9u), (2u | (unsigned)(signed char)(a0[u1 & 3u] - 0x78221d25u)), (unsigned)(x0 >> 70)); }
                    { unsigned t12; double z12; if ((~((unsigned)((int)m0 >= (int)*q0) >> (p1 & 31u))) & 1u) { t12 = p2; z12 = (double)((0x10000u) & 255u); } if ((~((unsigned)((int)m0 >= (int)*q0) >> (p1 & 31u))) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
                        if ((unsigned)((int)(unsigned)((int)g1 >= (int)(unsigned)s0) >= (int)0x4faba373u)) break;
                    }
                }
            }
            h1 = (unsigned short)(h1 + (unsigned)((unsigned)(signed char)(u0 & i2) && u1));
            d0 = d0 * 0.5 + (double)(garr[i1 & 7u] & 1023u);
        }
        while (i1++ < 4u && (unsigned)h1) { if (--fuel == 0u) goto done;
            if (((unsigned)s1 * 0x7fffffffu)) break;
        }
    } while (i0++ < 6u && (unsigned)(1u < (0xffffffffu - i1)));
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        v0 = (unsigned)((int)((fuel >> (3u & 31u)) % (2u | 1u)) < (int)(0xffffffffu % (0x10000u | 1u)));
        r0.y ^= ((unsigned)b0 + (p0 << (g0 & 31u)));
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)(unsigned)(3u == u1);
            w0 = w0 * 6364136223846793005ull + ((unsigned)c0 & ((unsigned)x0 ^ (garr[u2 & 7u] + 0xfbb19369u)));
            garr[(unsigned)((int)(unsigned)d0 >= (int)garr[i1 & 7u]) & 7u] = (unsigned)(unsigned char)((unsigned)(u2 < 0xffffffffu) >> ((unsigned)b0 & 31u));
            e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)((unsigned)x0 == 0x15c7387au)) & 1023u);
            c1 = (signed char)((unsigned)(v0 || garr[i1 & 7u]) ^ (unsigned)(unsigned char)(r0.y + ((unsigned)d0 >> (i0 & 31u))));
            if ((unsigned)(signed char)((unsigned)c0 >> (r0.x & 31u))) break;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)l0 % (5u | 1u)), (unsigned)(a0[i0 & 3u] < (unsigned)((int)u2 >= (int)u0)), (unsigned)(r0.x < ~(p1 | (unsigned)l0))); }
        while (-(p0 >> (m0 & 31u))) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + i0;
            u2 = (*q0 & u1);
            h1 = (unsigned short)(h1 + ((unsigned)(w0 >> 29) % ((unsigned)((short)(unsigned)((short)i2 > (signed char)m0) > (signed char)(u0 / (6u | 1u))) | 1u)));
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)c0, (unsigned)c0, (unsigned)(short)(7u ^ u3)); }
                garr[i0 & 7u] = (unsigned)((int)g0 < (int)0x442a96fau);
                s1 = (int)((unsigned)s1 + i0);
                if ((((unsigned)l0 & g0) & (unsigned)e0)) break;
                h1 = (unsigned short)(h1 + (unsigned)(unsigned char)((unsigned)((int)((unsigned)s1 + 0x140b22f9u) >= (int)(unsigned)c0) - u3));
            } while (i2++ < 6u && u3);
            c0 = (unsigned char)((garr[i1 & 7u] - 4u) + (unsigned)(short)(r0.y << (((unsigned)c0 * u2) & 31u)));
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(v0 == (a0[u1 & 3u] % (0x7f9685e5u | 1u))), ((unsigned)f0 / ((a0[u1 & 3u] | (unsigned)s0) | 1u)), (0xffffffffu ^ (unsigned)c0)); }
        }
    }
    if ((p2 % ((unsigned)b0 | 1u))) goto L4;
    if ((unsigned)((int)(unsigned)(x0 >> 70) < (int)(3u ^ p2))) {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1(i0, (0xffffffffu * 0u), (r0.x & r0.x)); }
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((a0[u1 & 3u] | (unsigned)((int)r0.y >= (int)a0[i0 & 3u]))) {
                    c1 = (signed char)((0xffffffffu ^ r0.x) ? (unsigned)((int)(unsigned)d0 < (int)7u) : (unsigned)w0);
                }
                if (fuel < 8u) return ((*q0 << ((unsigned)l0 & 31u)) & garr[u2 & 7u]);
                break; (void)(r0.x);
                garr[(0x7fffffffu >> (i1 & 31u)) & 7u] = ((*q0 & ((unsigned)b0 / (r0.y | 1u))) % (i2 | 1u));
                if (u3 == 7u) return 0xb389f52cu;
                break; (void)((unsigned)(garr[u2 & 7u] || m0));
            }
            if (-(((unsigned)(w0 >> 29) - 0x10000u) / (4u | 1u))) break;
        }
        if ((0x7fffffffu % ((0x10000u << ((unsigned)s0 & 31u)) | 1u))) goto L4;
        if ((unsigned)s1) goto L4;
        if ((u3 | (unsigned)b0)) goto L2;
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + ((unsigned)((short)0x80000000u > (signed char)p0) & 0xf49972c4u);
                for (;;) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (unsigned)((int)g0 >= (int)(0x7fffffffu ? (unsigned)(x0 >> 70) : (0x1c4baf3cu % (7u | 1u))));
                    if ((0xffffffffu ? 0x62b53ebfu : p0)) continue;
                    w0 = w0 * 6364136223846793005ull + ((0xd9e9312u & (unsigned)((short)0x41e4b29du > (signed char)r0.x)) - (unsigned)(unsigned char)(unsigned)((short)u2 > (signed char)(unsigned)b0));
                    garr[4u & 7u] = (0x7fffffffu * g0);
                    goto L2;
                }
                b0 = (0x10000u - -(fuel >> ((unsigned)h0 & 31u))) != 0u;
            }
            continue; (void)((unsigned)(short)(unsigned)((short)m0 > (signed char)r0.x));
            *q0 += (unsigned)((short)(garr[i1 & 7u] - 0xa9cfa021u) > (signed char)(r0.x | 0x80000000u));
        }
        switch (garr[u2 & 7u] & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)s1, (unsigned)b0, 0xaae4ca61u); }
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)c1) continue;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(v0, ((unsigned)w0 >> (u3 & 31u)), (unsigned)((int)0xffffffffu >= (int)(0x10000u << (0x87a37f21u & 31u)))); }
        }
    } else {
        if ((unsigned)((int)m0 < (int)~(unsigned)((unsigned)b0 && (unsigned)l0))) {
            r0.x = (((unsigned)f0 ^ g1) - (unsigned)((unsigned)(garr[u2 & 7u] || 0xffffffffu) == 6u));
            x0 = x0 * 0x100000001b3ull + (unsigned)((int)(7u / ((0xdf0ce8a2u >> ((unsigned)s0 & 31u)) | 1u)) < (int)(unsigned)(x0 >> 70));
            *q0 += u0;
            a0[((unsigned)(w0 >> 29) << (6u & 31u)) & 3u] = 5u;
        } else {
            s1 = (int)((unsigned)s1 + ((unsigned)h1 * (p1 ? i2 : ((unsigned)(x0 >> 70) | u1))));
            w0 = w0 * 6364136223846793005ull + ~((unsigned)((unsigned)h1 == 7u) - r0.x);
            e0 = e0 * 0.5L + (long double)((unsigned)((int)p2 >= (int)((r0.y ^ r0.x) / (a0[i0 & 3u] | 1u))) & 1023u);
        }
        if (*mp) goto L1;
    }
    if ((unsigned)((int)3u < (int)((unsigned)c0 % (fuel | 1u)))) goto L1;
    if ((unsigned)(short)(unsigned)(0xffffffffu == 5u)) goto L0;
    r0.x = (unsigned)((int)((unsigned)s1 * 0xb496a730u) >= (int)((unsigned)s0 + (unsigned)b0));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    q0 = &garr[(unsigned)w0 & 7u];
    v0 = (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)7u);
    g0 = (u2 - 1u);
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)u0;
            L0: if (--fuel == 0u) goto done;
            if (((unsigned)(m0 && 0x10000u) << (garr[u2 & 7u] & 31u))) {
                if (budget != 0u) { budget -= 1u; u0 = fn0(((m0 * (unsigned)x0) | a0[u1 & 3u]), ((r0.y + p1) << (0x80000000u & 31u)), (unsigned)((short)(unsigned)(u1 && i1) > (signed char)3u)); }
                s0 = (int)fuel;
                d0 = d0 * 0.5 + (double)(((unsigned)(signed char)(unsigned)((int)m0 < (int)(unsigned)f0) / (p2 | 1u)) & 1023u);
            } else {
                garr[3u & 7u] = (~(unsigned)((int)(unsigned)w0 < (int)0xffffffffu) - (unsigned)(1u < v0));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn2(g1, ((fuel % (a0[i0 & 3u] | 1u)) | 0x10000u), (unsigned)(signed char)(unsigned)((int)(unsigned)s0 >= (int)g1)); }
            w0 ^= (unsigned long long)3u << ((unsigned)((int)r0.y < (int)((unsigned)((int)(unsigned)e0 >= (int)p1) - ((unsigned)l0 >> (u0 & 31u)))) & 63u);
            if (((unsigned)c1 | (unsigned)s1)) {
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)(p1 || (unsigned)((unsigned)d0 == fuel)));
                        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                            s0 = (int)(((unsigned)b0 % (p2 | 1u)) + m0);
                            d0 = d0 * 0.5 + (double)(((unsigned)(unsigned char)(0x80000000u & (unsigned)c1) ? garr[i1 & 7u] : u2) & 1023u);
                            w0 ^= (unsigned long long)0x749dc62u << (((0xb4829568u & (unsigned)c1) * (unsigned)(x0 >> 70)) & 63u);
                            u2 += (unsigned)((int)0x6220c190u < (int)a0[u1 & 3u]);
                        }
                    }
                    u1 ^= (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)h0);
                }
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)f0 >= (int)(unsigned)(0xffffffffu < (p1 % (((unsigned)d0 & (unsigned)c0) | 1u))));
                r0.y ^= (unsigned)s1;
                b0 = (unsigned)((int)0xa6298ad6u >= (int)(unsigned)(unsigned char)((unsigned)s0 * 0xd65d2622u)) != 0u;
            }
        }
        if (0xee5750b1u) break;
        if ((unsigned)f0) break;
        u3 = u3 * 0x9e3779b1u + (unsigned)((short)((garr[i1 & 7u] ? (unsigned)e0 : m0) + 0x422b5b44u) > (signed char)a0[i0 & 3u]);
    } while (i0++ < 3u && (unsigned)((int)(u2 ^ 9u) < (int)4u));
    if ((unsigned)!((0x94e2400du % (fuel | 1u)) * 0xd3044e0du)) {
        if (1u) goto done;
        if ((garr[u2 & 7u] << (garr[i1 & 7u] & 31u))) {
            do { if (--fuel == 0u) goto done;
                if ((garr[i1 & 7u] / (i0 | 1u))) {
                    if (budget != 0u) { budget -= 1u; u3 = fn3(0x153d396fu, u3, a0[i0 & 3u]); }
                    if (a0[i0 & 3u]) continue;
                    if (budget != 0u) { budget -= 1u; u2 = fn1(a0[u1 & 3u], (unsigned)(2u < g1), ((unsigned)d0 * (unsigned)w0)); }
                    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)(9u == -(unsigned)(*q0 == r0.x)), (unsigned)((unsigned)((int)p1 >= (int)garr[u2 & 7u]) && i0), (*q0 ^ u1)); }
                }
                q0 = &garr[0xffffffffu & 7u];
                while (i1++ < 4u && (unsigned)s1) { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)((unsigned)(r0.y && (garr[i1 & 7u] % ((unsigned)(w0 >> 29) | 1u))) & 255u);
                        if ((u0 - (0x80000000u - 9u))) break;
                    }
                    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)c0 == (unsigned)b0);
                    f0 = f0 * 0.5f + (float)((unsigned)(signed char)((unsigned)w0 + 0xffffffffu) & 255u);
                }
                *q0 = ((unsigned)((int)0u >= (int)fuel) & *mp);
                if ((unsigned)((short)u1 > (signed char)(unsigned)c0)) break;
            } while (i0++ < 4u && (0x1cd5ca2fu + (unsigned)f0));
        }
        c1 = (signed char)(unsigned)(((*q0 + a0[i0 & 3u]) % ((unsigned)s1 | 1u)) || (unsigned)l0);
        switch ((g0 + (unsigned)!(g0 % ((unsigned)s1 | 1u))) & 7u) {
            x0 = x0 * 0x100000001b3ull + (p1 * (0x10000u | (0x2d90b530u >> ((unsigned)s1 & 31u))));
            i0 = ((unsigned)((short)(g0 ? i2 : g0) > (signed char)a0[u1 & 3u]) * r0.y) & 15u;
            d0 = d0 * 0.5 + (double)(((unsigned)(x0 >> 70) << (0x80000000u & 31u)) & 1023u);
            if ((unsigned)(signed char)(garr[i1 & 7u] << (g1 & 31u))) {
                c1 = (signed char)(((unsigned)b0 + 0u) % ((unsigned)(unsigned char)(unsigned)((0xffffffffu & (unsigned)l0) == g1) | 1u));
                if ((unsigned)f0) {
                    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)*q0 >= (int)0xc5e42632u)) break;
                        s1 = (int)((unsigned)s1 + ((unsigned)(signed char)((m0 << (4u & 31u)) ^ ((unsigned)w0 | g0)) + (unsigned)c1));
                        c0 = (unsigned char)(unsigned)!(unsigned)((int)0xd3d9f2a7u >= (int)((unsigned)((int)(unsigned)h1 < (int)0x93330101u) + a0[i0 & 3u]));
                    }
                    L1: if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (unsigned)((short)(i1 / (*mp | 1u)) > (signed char)(0xecbfd8b8u | (unsigned)h1)));
                } else {
                    L2: if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                    case 6u: ;
                    c1 = (signed char)((8u * *q0) & (unsigned)((g0 << (a0[u1 & 3u] & 31u)) == fuel));
                }
                b0 = (unsigned)((unsigned)(((unsigned)c1 - u3) < (unsigned)x0) || m0) != 0u;
                switch (0xa635e3beu & 7u) {
                    if (budget != 0u) { budget -= 1u; u3 = fn1(fuel, (unsigned)(p1 == (unsigned)s0), i0); }
                    garr[u2 & 7u] = i0;
                    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        while ((unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
                            f0 = f0 * 0.5f + (float)((p1 % ((unsigned)(u1 == (u3 | 0x10000u)) | 1u)) & 255u);
                            *q0 = (unsigned)((short)r0.y > (signed char)(unsigned)((short)(unsigned)(u2 < (unsigned)c0) > (signed char)0xa0df3c14u));
                        }
                        if (fuel < 8u) return ((unsigned)x0 & (unsigned)((int)(unsigned)((short)u0 > (signed char)(unsigned)b0) >= (int)(0x48a3a0c8u | 0xada71feeu)));
                        *mp = (unsigned)((unsigned)((int)(i0 ^ m0) >= (int)u2) && (unsigned)d0);
                        *q0 = u2;
                        if (budget != 0u) { budget -= 1u; u2 = fn2(p1, (unsigned)((int)(g0 % (0x155f977au | 1u)) >= (int)3u), (unsigned)((int)p1 >= (int)a0[u1 & 3u])); }
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)d0, (unsigned)(garr[i1 & 7u] == garr[i1 & 7u]), (0x7fffffffu >> (g0 & 31u))); }
                }
            } else {
                x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)d0 << (p2 & 31u)) < (unsigned)((int)(unsigned)(*mp < u2) < (int)(unsigned)x0));
                case 4u: ;
                g1 += ((unsigned)w0 / (6u | 1u));
            }
            L4: if (--fuel == 0u) goto done;
        }
        if (fuel) goto L3;
        q0 = &garr[(unsigned)(x0 >> 70) & 7u];
    } else {
        w0 = w0 * 6364136223846793005ull + i1;
        if (((unsigned)((int)(unsigned)h1 >= (int)(unsigned)f0) >> (0x5fc7a8eau & 31u))) goto L1;
        if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)l0, (unsigned)((int)(p2 * (unsigned)s1) < (int)(unsigned)x0), (unsigned)d0); }
        if (((unsigned)h0 - (unsigned)((unsigned)f0 == (unsigned)s0))) {
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)x0) break;
            }
            if (((unsigned)(signed char)(u0 - p2) + 0xffffffffu)) goto L0;
            if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((int)p2 >= (int)(unsigned)s0), 0x389e4076u, (unsigned)((int)~((unsigned)s0 % (a0[i0 & 3u] | 1u)) >= (int)u2)); }
            u2 ^= (unsigned)((short)(unsigned)f0 > (signed char)((unsigned)((unsigned)s0 || 9u) & 0xc03d8096u));
            switch ((unsigned)(p1 && 7u) & 7u) {
                case 7u: ;
                { unsigned t0; double z0; if ((((unsigned)(unsigned char)(unsigned)(5u == (unsigned)e0) / (0xd5fed7ccu | 1u))) & 1u) { t0 = (unsigned)h0; z0 = (double)((p2) & 255u); } if ((((unsigned)(unsigned char)(unsigned)(5u == (unsigned)e0) / (0xd5fed7ccu | 1u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                    if ((u0 + (r0.y + *mp))) {
                        case 6u: ;
                        c1 = (signed char)((unsigned)(short)((unsigned)b0 % ((unsigned)x0 | 1u)) & (unsigned)x0);
                        if ((unsigned)((int)(unsigned)((int)0xde1c1604u < (int)a0[i0 & 3u]) >= (int)v0)) goto L1;
                        h0 = (short)(unsigned)(unsigned char)(r0.x + garr[i1 & 7u]);
                        case 5u: ;
                    }
                }
                if (u3) break;
                w0 = w0 * 6364136223846793005ull + (~(0x7fffffffu ^ (((unsigned)x0 << (p0 & 31u)) % ((unsigned)x0 | 1u))) + (unsigned)l0);
                c0 = (unsigned char)(unsigned)(~(unsigned)((unsigned)h0 && ((unsigned)d0 ? (unsigned)w0 : 0x80000000u)) && (unsigned)e0);
                b0 = (0x78cd4e6eu ? (m0 * garr[i1 & 7u]) : v0) != 0u;
            }
            a0[(p2 ^ (unsigned)s0) & 3u] = 7u;
        }
    }
    { unsigned t1; double z1; if ((0x89e316f8u) & 1u) { t1 = ((u3 * *mp) & (unsigned)b0); z1 = (double)((r0.y) & 255u); } if ((0x89e316f8u) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        if (budget != 0u) { budget -= 1u; u3 = fn2((g1 & v0), ((unsigned)s0 | (unsigned)(garr[u2 & 7u] < garr[i1 & 7u])), (v0 | 0u)); }
        r0.y ^= (unsigned)((short)(unsigned)e0 > (signed char)0xffffffffu);
        if ((unsigned)((0x7fffffffu - 0xffffffffu) < u2)) {
            h0 = (short)((unsigned)h0 % ((p0 << (a0[i0 & 3u] & 31u)) | 1u));
            if (((unsigned)e0 * u0)) goto L0;
            if ((1u | r0.y)) goto L3;
        }
        if ((unsigned)(3u == 0x89bf6d07u)) {
            goto L4;
        }
        *q0 = ((unsigned)(short)(u3 << (~(u1 - *q0) & 31u)) % ((unsigned)(p2 == (unsigned)e0) | 1u));
    }
    if ((g1 - 0x7fffffffu)) {
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((short)0x52202802u > (signed char)(unsigned)!(p2 | u0))) break;
            break; (void)((unsigned)(0x12c67dc4u && u3));
            if (u1) continue;
            if (budget != 0u) { budget -= 1u; u0 = fn2((r0.y / ((unsigned)s0 | 1u)), (unsigned)((unsigned)(x0 >> 70) < r0.y), 6u); }
            if (budget != 0u) { budget -= 1u; u2 = fn0(0x10000u, *q0, (0xf1389101u ^ r0.x)); }
        } while (i0++ < 6u && (unsigned)(v0 < i0));
    } else {
        if (5u) goto L0;
        s0 = (int)(unsigned)h1;
    }
    if (0xffffffffu) {
        if ((unsigned)((g0 >> (0x24865e7u & 31u)) < 0x10000u)) {
            if (budget != 0u) { budget -= 1u; u2 = fn2(i2, (8u ? (unsigned)x0 : garr[u2 & 7u]), ((unsigned)s1 + (unsigned)b0)); }
            while (i0++ < 6u && (unsigned)!(((unsigned)c0 - a0[i0 & 3u]) % (r0.y | 1u))) { if (--fuel == 0u) goto done;
                i0 = (unsigned)(0x80000000u == ((fuel ^ g0) & (unsigned)l0)) & 15u;
                if ((unsigned)((short)u1 > (signed char)m0)) break;
            }
            q0 = &garr[(unsigned)(p1 && 0xffffffffu) & 7u];
        } else {
            r0.y ^= (a0[u1 & 3u] ? (unsigned)s0 : 0xffffffffu);
            if (garr[i1 & 7u]) goto L3;
            if ((v0 | (i0 + (unsigned)(w0 >> 29)))) goto L3;
            u3 += (fuel + r0.y);
        }
        m0 ^= i2;
    } else {
        while (i0++ < 4u && -(unsigned)((short)u2 > (signed char)(unsigned)x0)) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)c1);
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(0xe905a1a9u < 0x7fffffffu)) continue;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    u2 ^= (r0.x << ((unsigned)(signed char)(0x80281394u ^ (unsigned)f0) & 31u));
                    c1 = (signed char)((unsigned)x0 & (unsigned)!((unsigned)x0 << (((unsigned)d0 * p1) & 31u)));
                    m0 ^= ((unsigned)((int)garr[i1 & 7u] >= (int)i2) - m0);
                    v0 = (unsigned)(a0[u1 & 3u] || (unsigned)f0);
                    *q0 = (unsigned)((unsigned)d0 == garr[u2 & 7u]);
                }
                w0 = w0 * 6364136223846793005ull + ((unsigned)(x0 >> 70) + (i0 ^ (unsigned)s1));
                c0 = (unsigned char)((unsigned)(w0 >> 29) * (0xe491eb11u % (*mp | 1u)));
                if (budget != 0u) { budget -= 1u; u0 = fn0((6u << ((unsigned)s0 & 31u)), 0x7fffffffu, (garr[i1 & 7u] % ((unsigned)(garr[i1 & 7u] && (unsigned)s0) | 1u))); }
                u2 += ((unsigned)((int)7u >= (int)(unsigned)h0) >> (p0 & 31u));
            } while (i1++ < 6u && (r0.y | ((unsigned)x0 - u0)));
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)s0) break;
                u3 = u3 * 0x9e3779b1u + ((unsigned)((unsigned)e0 || i1) ^ (unsigned)((int)0x10000u >= (int)(unsigned)((int)fuel < (int)(unsigned)d0)));
                c1 = (signed char)(fuel / (((*mp ^ u3) % (fuel | 1u)) | 1u));
            }
            b0 = (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)c1) != 0u;
            if ((0x70c0d077u >> ((*q0 * (unsigned)b0) & 31u))) {
                for (;;) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((((unsigned)((int)1u >= (int)7u) - i1) >> ((unsigned)c0 & 31u)) & 1023u);
                    c1 = (signed char)(0x10000u ^ (unsigned)d0);
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)((short)p0 > (signed char)(unsigned)h0) < (unsigned)e0), ~(unsigned)((0xc862e024u * 0xf3c8c8c8u) == (unsigned)x0), *mp); }
                }
                if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)s1 % (0x5d9cf05u | 1u)), (m0 / (0x1c3c2575u | 1u)), ~(8u ? g0 : 0xeb86708u)); }
            }
        }
        if (6u) {
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)b0 % (a0[u1 & 3u] | 1u)));
            }
            if (g1) goto L3;
            if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)x0 * i2), ~((unsigned)w0 << ((p0 ^ p1) & 31u)), 0x6c11a27u); }
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                *mp = ((unsigned)(0x80000000u < (unsigned)!(p0 | (unsigned)s1)) | p1);
                garr[(unsigned)((int)*q0 < (int)2u) & 7u] = (unsigned)(p2 || 0x10000u);
                if ((unsigned)(u0 && *q0)) break;
            }
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                g0 = (((unsigned)c1 - 0xacc9d672u) + ((unsigned)b0 - (unsigned)(signed char)(unsigned)((short)*mp > (signed char)0xd88c0969u)));
                break; (void)((unsigned)((unsigned)e0 || (unsigned)(3u && i1)));
                a0[g0 & 3u] = (g1 + i0);
            }
        } else {
            if (u3) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0(~(u2 & (unsigned)c0), v0, (((unsigned)e0 ^ fuel) - (unsigned)(w0 >> 29))); }
        }
        u3 = u3 * 0x9e3779b1u + g0;
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(0x7fffffffu);
            w0 ^= (unsigned long long)(unsigned)((short)u2 > (signed char)2u) << (((unsigned)((int)0xa1c33e5fu < (int)a0[u1 & 3u]) ^ (unsigned)((u3 * v0) < garr[u2 & 7u])) & 63u);
            if ((((unsigned)e0 >> (0x5bf2dc3bu & 31u)) | 0x80000000u)) break;
            r0.y ^= (0x7fffffffu / ((unsigned)((int)0x10000u < (int)(unsigned)(short)(a0[i0 & 3u] % (g1 | 1u))) | 1u));
            while (i1++ < 4u && (unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        a0[v0 & 3u] = ((unsigned)(0x4b6c41f1u && (unsigned)s0) >> (0x10000u & 31u));
                        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)0xe9d088dfu > (signed char)m0), (unsigned)d0, garr[u2 & 7u]); }
                        break; (void)((unsigned)(m0 < p2));
                        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                            if (((unsigned)((int)0x10000u < (int)(unsigned)h0) % (a0[i0 & 3u] | 1u))) break;
                            garr[(unsigned)h1 & 7u] = (unsigned)((int)(unsigned)h1 < (int)(unsigned)((int)(unsigned)h1 >= (int)0xffffffffu));
                            continue; (void)(((unsigned)c1 | (unsigned)w0));
                        }
                        h0 = (short)i0;
                        w0 = w0 * 6364136223846793005ull + -((u2 & 4u) ? g0 : a0[i0 & 3u]);
                    } while (i0++ < 3u && (unsigned)(garr[u2 & 7u] == (unsigned)d0));
                    r0.x = (a0[i0 & 3u] << ((unsigned)c1 & 31u));
                    r0.y ^= ((unsigned)(u1 < u1) ^ (unsigned)(r0.x == (unsigned)(short)(0x80000000u & (unsigned)s1)));
                    if (budget != 0u) { budget -= 1u; u1 = fn3((a0[i0 & 3u] & i2), r0.y, fuel); }
                }
                do { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(unsigned)(signed char)(((0x7fffffffu ^ (unsigned)s1) + ((unsigned)c0 - i0)) << (0x10000u & 31u));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((p2 + p1), 0x79cc8f87u, ((unsigned)(w0 >> 29) >> ((unsigned)((int)*mp >= (int)u2) & 31u))); }
                    if (0x80000000u) continue;
                    if ((i2 >> (garr[i1 & 7u] & 31u))) break;
                    u2 = u2 * 0x9e3779b1u + (unsigned)((short)(unsigned)((int)(unsigned)c1 >= (int)i1) > (signed char)(unsigned)x0);
                    if ((unsigned)((short)0x977ddf05u > (signed char)((unsigned)w0 % ((unsigned)f0 | 1u)))) break;
                } while (i2++ < 6u && p2);
            }
        }
    }
    s0 = (int)(unsigned)((u3 - a0[u1 & 3u]) < (unsigned)((int)0x80000000u < (int)(unsigned)s0));
    u0 += (0x7fffffffu ^ (unsigned)(unsigned char)(unsigned)(0x78195c5bu && 0xfc197181u));
    u0 += (p2 * (unsigned)b0);
    q0 = &garr[(((unsigned)(w0 >> 29) ? 0xf37ea8c9u : 0xf389fb51u) * (unsigned)s1) & 7u];
    c1 = (signed char)(unsigned)((unsigned)e0 && (unsigned)!((g1 % ((unsigned)e0 | 1u)) & (unsigned)(v0 && (unsigned)c0)));
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(short)(unsigned)((int)0xe20446fau < (int)r0.y), a0[i0 & 3u], (a0[i0 & 3u] | 2u)); }
    h1 = (unsigned short)(h1 + ((g1 ? *mp : i0) << (((unsigned)(w0 >> 29) ^ a0[i0 & 3u]) & 31u)));
    if (budget != 0u) { budget -= 1u; u2 = fn1((u1 * (unsigned)c0), (unsigned)((int)*mp < (int)-(u2 % ((unsigned)f0 | 1u))), (unsigned)w0); }
    goto L4;
    if (budget != 0u) { budget -= 1u; u1 = fn2((a0[u1 & 3u] / (i1 | 1u)), (0xf4b7d6c8u - i0), (unsigned)((int)(unsigned)c0 < (int)v0)); }
    *q0 = *mp;
    if (p2) goto L4;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 12u, 0x9a0d9b6au, 0xe8b412a7u },
        { 10u, 0x38594a32u, 0xf9e09ccau },
        { 6u, 0x65802fabu, 0x1e1e4f87u },
        { 9u, 0xe043ec84u, 0x253dc34du },
        { 4u, 0x80998a8cu, 0x62d2c546u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
