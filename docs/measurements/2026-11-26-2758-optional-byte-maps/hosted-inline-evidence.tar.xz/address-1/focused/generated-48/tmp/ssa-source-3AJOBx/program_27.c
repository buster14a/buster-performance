// test-ssa-source's program of seed 134000429 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x4c64eb8eu, g1 = 0x49a99518u;
static unsigned garr[8] = { 0xc42815cfu, 0x4fa94995u, 0x467038b6u, 0x94ed2e6bu, 0x7dc01b51u, 0x79b3b2a6u, 0xd2f52ee1u, 0xb29dcc4bu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    x0 = x0 * 0x100000001b3ull + (fuel + (unsigned)!(0xacb6b0du ? p0 : u1));
    { unsigned t0; double z0; if (((unsigned)s1) & 1u) { t0 = (garr[i1 & 7u] & garr[i1 & 7u]); z0 = (double)(((unsigned)f0) & 255u); } if (((unsigned)s1) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if (-(u0 << ((unsigned)b0 & 31u))) {
            if (g1) goto L1;
            L0: if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if ((((unsigned)(r0.x && *mp) & g1)) & 1u) { t1 = (*mp / ((unsigned)h1 | 1u)); z1 = (double)((0x5f95d21du) & 255u); } if ((((unsigned)(r0.x && *mp) & g1)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                u1 ^= ((unsigned)(3u && u2) / (p0 | 1u));
            }
            g1 += (unsigned)((int)((p2 / (*q0 | 1u)) / ((unsigned)h0 | 1u)) < (int)(unsigned)((int)(unsigned)x0 >= (int)u0));
            g0 = (u0 ? (unsigned)c1 : i1);
        }
        h0 = (short)((unsigned)((int)i1 >= (int)v0) | i0);
    }
    if ((unsigned)((int)garr[u2 & 7u] < (int)((unsigned)c0 - 7u))) goto done;
    goto done;
    goto L1;
    m0 ^= i1;
    if ((garr[i1 & 7u] ^ m0)) goto L1;
    h0 = (short)(((unsigned)(x0 >> 70) ? (unsigned)((int)(unsigned)s0 < (int)1u) : (unsigned)c1) % (0u | 1u));
    L2: if (--fuel == 0u) goto done;
    c0 = (unsigned char)((0x80000000u & *mp) & p1);
    if ((unsigned)w0) goto done;
    u3 = (((unsigned)((int)0x10000u >= (int)(unsigned)h1) >> ((unsigned)((int)0x617680e5u < (int)7u) & 31u)) & 0x80000000u);
    L3: if (--fuel == 0u) goto done;
    if ((unsigned)(short)(u0 - (p0 * r0.y))) {
        if ((i1 ^ garr[u2 & 7u])) goto L1;
        b0 = 0xa328e9beu != 0u;
        goto L2;
        if ((unsigned)s0) {
            if ((unsigned)((unsigned)!(unsigned)((unsigned)h1 == 0x9f2088ceu) || u3)) {
                { unsigned t2; double z2; if ((((unsigned)e0 & (*mp & p2))) & 1u) { t2 = ((v0 ^ 2u) >> ((unsigned)c1 & 31u)); z2 = (double)((~(u1 % (0xe945ef47u | 1u))) & 255u); } if ((((unsigned)e0 & (*mp & p2))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    g1 += ((0xcc727cb9u >> (p0 & 31u)) / (p0 | 1u));
                    w0 = w0 * 6364136223846793005ull + (g1 + (unsigned)s0);
                    g0 = (unsigned)(signed char)(unsigned)((0xde11e76u * (unsigned)((int)(unsigned)c0 >= (int)0x1860a03fu)) || (i1 & a0[u1 & 3u]));
                    if (garr[u2 & 7u]) goto L2;
                }
                if (~(0xffffffffu >> ((i0 / ((unsigned)x0 | 1u)) & 31u))) goto L1;
                for (;;) { if (--fuel == 0u) goto done;
                    if (0x10000u) break;
                    break; (void)(((i2 / (i2 | 1u)) + r0.y));
                }
            } else {
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)(0xffffffffu & 255u);
                    do { if (--fuel == 0u) goto done;
                        h0 = (short)0x32b6c7aeu;
                    } while (i1++ < 6u && (unsigned)(4u && (unsigned)(x0 >> 70)));
                }
            }
            m0 ^= ((0x10000u | i1) % ((unsigned)h0 | 1u));
            g1 += (fuel >> (g0 & 31u));
            if ((unsigned)(signed char)(u1 + (unsigned)(x0 >> 70))) goto done;
            if ((r0.x ^ ((unsigned)f0 ^ 9u))) {
                if ((v0 - ((unsigned)w0 % (0xb5ab231eu | 1u)))) goto done;
            } else {
                w0 ^= (unsigned long long)(0x10000u + p1) << ((unsigned)w0 & 63u);
                goto L0;
            }
        } else {
            u1 = u1 * 0x9e3779b1u + (unsigned)(((i2 * 0x9998e656u) - ((unsigned)h0 - v0)) && (unsigned)c1);
            if ((unsigned)((int)(unsigned)w0 < (int)0xffffffffu)) goto L0;
        }
    } else {
        f0 = f0 * 0.5f + (float)((unsigned)((short)a0[i0 & 3u] > (signed char)fuel) & 255u);
    }
    a0[(unsigned)h0 & 3u] = (unsigned)(r0.x == (i2 / ((unsigned)((short)(unsigned)((unsigned)(x0 >> 70) || 9u) > (signed char)0xcab9f8eau) | 1u)));
    u0 = u0 * 0x9e3779b1u + (unsigned)((short)0u > (signed char)u2);
    c0 = (unsigned char)0u;
    L4: if (--fuel == 0u) goto done;
    if ((unsigned)(short)(unsigned)((unsigned)c0 < 0x80000000u)) goto done;
    goto L4;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((garr[i1 & 7u] + *mp) & 7u) {
            q0 = &garr[((unsigned)(0x10000u || 0x10000u) % ((a0[i0 & 3u] - ((unsigned)b0 * u0)) | 1u)) & 7u];
            u1 ^= garr[i1 & 7u];
            r0.y ^= ((4u - 0x80000000u) % (m0 | 1u));
            { unsigned t3; double z3; if ((*mp) & 1u) { t3 = p0; z3 = (double)(((unsigned)((int)u1 < (int)a0[i0 & 3u])) & 255u); } if ((*mp) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                if ((unsigned)(u3 == m0)) {
                    g0 = ((unsigned)h0 % ((unsigned)h1 | 1u));
                    case 6u: ;
                    v0 = (unsigned)((unsigned)(unsigned char)(unsigned)((int)r0.y >= (int)p0) < ((unsigned)c0 / ((u0 - u0) | 1u)));
                    default: ;
                    e0 = e0 * 0.5L + (long double)(u1 & 1023u);
                }
                g1 += ((unsigned)((int)i0 < (int)p2) ? 0x92771171u : (unsigned)(0xdb960a10u == u3));
                w0 ^= (unsigned long long)(unsigned)((int)3u >= (int)4u) << (((unsigned)c1 + (0xffffffffu & i1)) & 63u);
            }
            g0 = (unsigned)(0x80000000u || ((unsigned)f0 / (r0.y | 1u)));
        }
    }
    if ((0xffffffffu << ((unsigned)e0 & 31u))) {
        while (i0++ < 5u && (i0 << ((i1 + *mp) & 31u))) { if (--fuel == 0u) goto done;
            if ((unsigned)w0) break;
            if ((unsigned)e0) continue;
            if (2u) break;
            while (m0) { if (--fuel == 0u) goto done;
                if (((unsigned)(garr[i1 & 7u] < p2) / ((unsigned)s0 | 1u))) break;
                if ((((unsigned)e0 & 0x87350727u) ^ u1)) break;
                w0 ^= (unsigned long long)(r0.x << (u3 & 31u)) << ((0x63379e47u % ((unsigned)(signed char)(unsigned)((v0 << (0x10000u & 31u)) || (0x7fffffffu + (unsigned)c1)) | 1u)) & 63u);
                break; (void)(*q0);
                e0 = e0 * 0.5L + (long double)((unsigned)l0 & 1023u);
                g0 = (((u3 ^ fuel) ? 0u : (unsigned)s0) - i1);
            }
            switch ((unsigned)(u1 == (unsigned)s1) & 7u) {
                { unsigned t4; double z4; if (((unsigned)((int)(unsigned)(0x10000u == 0x7fffffffu) < (int)(unsigned)s0)) & 1u) { t4 = (9u ^ 0xffffffffu); z4 = (double)(((unsigned)(w0 >> 29)) & 255u); } if (((unsigned)((int)(unsigned)(0x10000u == 0x7fffffffu) < (int)(unsigned)s0)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    l0 = (long)((unsigned long)l0 + (unsigned)h1);
                    goto L2;
                    case 0u: ;
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        case 6u: ;
                        if ((unsigned)((short)u1 > (signed char)0xa355f913u)) break;
                        if (r0.y) break;
                        r0.x = (unsigned)((unsigned)d0 && (unsigned)(0x80000000u && (unsigned)e0));
                        g0 = (((unsigned)s1 / (0x10000u | 1u)) % (((0x80000000u | 0x397b1c05u) - garr[u2 & 7u]) | 1u));
                        case 3u: ;
                    }
                    case 1u: ;
                    if ((unsigned)((int)0x8b0723efu < (int)v0)) break;
                }
                { unsigned t5; double z5; if (((unsigned)((unsigned)(short)(p2 * fuel) || 2u)) & 1u) { t5 = r0.y; z5 = (double)(((r0.x | u1)) & 255u); } if (((unsigned)((unsigned)(short)(p2 * fuel) || 2u)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    do { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(g0 / ((0x7fffffffu >> ((unsigned)(w0 >> 29) & 31u)) | 1u)));
                        l0 = (long)((unsigned long)l0 + 0x80000000u);
                        case 4u: ;
                        continue; (void)(0x7fffffffu);
                    } while (i1++ < 4u && (unsigned)(short)(unsigned)((u0 & i0) == 0xcbdaa2d8u));
                    if ((unsigned)w0) goto L1;
                    u3 ^= (unsigned)(0x7fffffffu < (0x10000u | ((unsigned)c1 + (unsigned)f0)));
                    g1 += ((unsigned)s1 << ((unsigned)(0x34af2647u && 0x80000000u) & 31u));
                }
                default: ;
            }
            if ((i0 & *q0)) {
                if ((*q0 / (((unsigned)f0 << (*mp & 31u)) | 1u))) break;
                u1 += (0u / ((unsigned)(signed char)(~(unsigned)(0x16a8549fu && u1) | 3u) | 1u));
                if (((unsigned)e0 & r0.x)) break;
                if ((unsigned)((short)p2 > (signed char)(unsigned)b0)) break;
            }
        }
        if ((unsigned)(a0[u1 & 3u] < (0x4af9e484u * (unsigned)(x0 >> 70)))) {
            if ((unsigned)(g0 && i2)) goto L3;
        } else {
            switch ((unsigned)(signed char)((unsigned)h0 * (unsigned)h1) & 7u) {
                break; (void)((unsigned)(0xfa590bd6u && r0.y));
                *q0 = (unsigned)((short)(unsigned)(u2 < (unsigned)w0) > (signed char)g1);
                *mp = (unsigned)(garr[u2 & 7u] == 0x7fffffffu);
                case 6u: ;
            }
            if ((unsigned)((short)0xc982f886u > (signed char)u2)) goto L3;
            if ((unsigned)((unsigned)c1 == p2)) goto L2;
        }
        *q0 = (unsigned)(signed char)(unsigned)((int)(unsigned)h1 >= (int)(r0.y >> ((unsigned)((int)0x676eb6b2u >= (int)0x7fffffffu) & 31u)));
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((0x10000u + (unsigned)(0x7fffffffu == 0xbfc4b8a9u))) {
                c1 = (signed char)0x96de0493u;
                s0 = (int)(r0.x - (4u * 2u));
                l0 = (long)((unsigned long)l0 + (unsigned)!(0x80000000u - (unsigned)x0));
                if ((unsigned)(i0 == (7u ^ (unsigned)(w0 >> 29)))) {
                    break; (void)(~(g1 / (a0[u1 & 3u] | 1u)));
                } else {
                    break; (void)((0x2e81fde7u & 0x10000u));
                    q0 = &garr[(unsigned)(unsigned char)((0x7fffffffu % (p2 | 1u)) * (g0 ^ 0xf44b1c3cu)) & 7u];
                    if ((0u | (unsigned)x0)) break;
                    garr[i1 & 7u] = a0[u1 & 3u];
                }
                { unsigned t6; double z6; if (((g0 >> ((unsigned)w0 & 31u))) & 1u) { t6 = ~((0x548b1a60u ^ i2) - p0); z6 = (double)(((unsigned)((int)i1 < (int)(unsigned)((unsigned)h1 && i0))) & 255u); } if (((g0 >> ((unsigned)w0 & 31u))) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                    f0 = f0 * 0.5f + (float)((unsigned)((int)4u < (int)(unsigned)(u0 || (unsigned)(*q0 && u0))) & 255u);
                    break; (void)((unsigned)(0x7fffffffu || 0x4b96833du));
                }
            } else {
                break; (void)((0x644a15bau + 9u));
            }
            if (u2) break;
            if (fuel) break;
            if (((unsigned)((unsigned)h1 == u0) & p2)) break;
            if (0xd9d59231u) break;
        }
    }
    if (((i0 ^ (unsigned)c1) ^ 0xeb6a6e0eu)) goto L4;
    if (~(i2 / ((unsigned)f0 | 1u))) {
        if ((i1 ? (unsigned)e0 : p0)) goto done;
    }
    if ((unsigned)((short)((unsigned)c0 | g1) > (signed char)(unsigned)b0)) goto done;
    u3 ^= (unsigned)(0xffffffffu == (unsigned)(short)(unsigned)(*q0 || (unsigned)s1));
    if ((i1 % (~(unsigned)((int)i1 >= (int)a0[i0 & 3u]) | 1u))) goto L3;
    h0 = (short)((unsigned)(0xb7861843u == i1) % (*q0 | 1u));
    if (0x10000u) goto L3;
    g1 += ((p1 | (unsigned)(w0 >> 29)) + (0xffffffffu >> (0u & 31u)));
    if ((unsigned)s1) goto L1;
    { unsigned t7; double z7; if (((unsigned)((int)(unsigned)(0xffffffffu || 0x250cdb92u) < (int)0x10000u)) & 1u) { t7 = (unsigned)((unsigned)l0 < (unsigned)e0); z7 = (double)(((unsigned)(0xffffffffu && 7u)) & 255u); } if (((unsigned)((int)(unsigned)(0xffffffffu || 0x250cdb92u) < (int)0x10000u)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
        if (u3 == 7u) return (0x7fffffffu >> ((u0 % ((unsigned)h1 | 1u)) & 31u));
        goto done;
        switch ((0x80000000u - ((unsigned)c0 << (0x80000000u & 31u))) & 7u) {
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 4u: ;
            }
            do { if (--fuel == 0u) goto done;
                q0 = &garr[(garr[i1 & 7u] - (unsigned)((unsigned)(p1 || r0.y) && 0x80000000u)) & 7u];
                continue; (void)(garr[u2 & 7u]);
                g1 += (p1 ^ 9u);
                d0 = d0 * 0.5 + (double)((0x80000000u % ((unsigned)(x0 >> 70) | 1u)) & 1023u);
            } while (i0++ < 2u && ((6u / (i2 | 1u)) & garr[u2 & 7u]));
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(~((0x10000u >> ((unsigned)s0 & 31u)) << (~(0xb5bb13e9u + (unsigned)(w0 >> 29)) & 31u)) & 255u);
                case 6u: ;
                default: ;
                u1 = (unsigned)s0;
                if (6u) {
                    if (0xdd564496u) {
                        d0 = d0 * 0.5 + (double)((unsigned)(signed char)(unsigned)(garr[i1 & 7u] < 8u) & 1023u);
                        h0 = (short)(u0 * (p2 | 6u));
                    }
                    c0 = (unsigned char)~((unsigned)(garr[i1 & 7u] < (unsigned)h1) / (((m0 / (r0.y | 1u)) * i2) | 1u));
                } else {
                    case 2u: ;
                }
            }
            s1 = (int)((unsigned)s1 + 0xffffffffu);
        }
    }
    if ((0x80000000u ^ g1)) goto L2;
    if ((unsigned)(x0 >> 70)) {
        u0 = (i1 << ((p1 | (v0 / (*q0 | 1u))) & 31u));
        i1 = ((unsigned)((int)(unsigned)h1 < (int)(unsigned)((unsigned)(w0 >> 29) && 5u)) + p1) & 15u;
        a0[i1 & 3u] = ((unsigned)s1 >> (~(0x7fffffffu + (unsigned)!(unsigned)(*q0 < (unsigned)b0)) & 31u));
    } else {
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((int)0x80000000u < (int)(r0.y | fuel)) || 5u);
        }
        if (fuel < 8u) return (unsigned)(0x7a17c7fcu == (2u | (0x8c788b31u + *q0)));
        e0 = e0 * 0.5L + (long double)((0x970df55cu * garr[i1 & 7u]) & 1023u);
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)((short)i2 > (signed char)g1) & 7u) {
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 1u: ;
                    case 4u: ;
                    switch ((unsigned)(5u == *q0) & 7u) {
                        u2 = u2 * 0x9e3779b1u + (~(unsigned)((int)(u3 + (unsigned)e0) >= (int)*mp) / (u2 | 1u));
                        case 3u: ;
                        s1 = (int)((unsigned)s1 + (((unsigned)((int)u0 >= (int)g0) - g1) / (v0 | 1u)));
                    }
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        u1 = u1 * 0x9e3779b1u + (((i1 % ((unsigned)d0 | 1u)) ? v0 : (unsigned)c1) & 0x10000u);
                        i2 = -(unsigned)(((unsigned)w0 ? 0xffffffffu : 1u) < ((unsigned)x0 | p2)) & 15u;
                        a0[((unsigned)(w0 >> 29) >> (i1 & 31u)) & 3u] = (unsigned)(fuel || ((unsigned)(0x1d38aa9au == 0x7fffffffu) & -(unsigned)(0xaf62fda2u || r0.x)));
                        u2 += (0xc119be71u & garr[u2 & 7u]);
                        r0.y ^= (0x7fffffffu >> (garr[u2 & 7u] & 31u));
                        default: ;
                    }
                    goto done;
                    break;
                }
                e0 = e0 * 0.5L + (long double)(((unsigned)s0 / (7u | 1u)) & 1023u);
                switch (((unsigned)c0 + (0x7fffffffu >> ((unsigned)s0 & 31u))) & 7u) {
                    *q0 += (unsigned)(unsigned char)(unsigned)((unsigned)!(unsigned)((unsigned)c1 && u2) == ~(unsigned)((int)-(0x7fffffffu * (unsigned)h0) >= (int)0x80000000u));
                }
            }
            f0 = f0 * 0.5f + (float)((0x8884da8bu & 0xf80e5025u) & 255u);
            e0 = e0 * 0.5L + (long double)((0x7fffffffu / (0xe2d67ba4u | 1u)) & 1023u);
            g1 += ((unsigned)c1 ^ r0.x);
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= (0xa7b2408eu % ((unsigned)(w0 >> 29) | 1u));
        if ((0x442877acu & (unsigned)((int)(unsigned)c0 >= (int)p0))) break;
        m0 ^= (unsigned)(unsigned char)(((unsigned)h0 & -(unsigned)(p1 < (unsigned)b0)) >> ((u2 - r0.y) & 31u));
        if (u3) break;
    }
    c1 = (signed char)(0xffffffffu ? g0 : r0.x);
    { unsigned t0; double z0; if (((unsigned)(4u || (unsigned)b0)) & 1u) { t0 = (0u - (unsigned)!((unsigned)s1 << ((unsigned)s1 & 31u))); z0 = (double)((((unsigned)(x0 >> 70) << (((unsigned)(w0 >> 29) ^ (unsigned)x0) & 31u))) & 255u); } if (((unsigned)(4u || (unsigned)b0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        do { if (--fuel == 0u) goto done;
            continue; (void)(((unsigned)((short)(unsigned)d0 > (signed char)i1) / ((unsigned)l0 | 1u)));
            e0 = e0 * 0.5L + (long double)((unsigned)(short)(a0[i0 & 3u] * (unsigned)((int)5u < (int)2u)) & 1023u);
            { unsigned t1; double z1; if (((unsigned)((unsigned)(p2 == a0[i0 & 3u]) < p0)) & 1u) { t1 = 0x10000u; z1 = (double)((((unsigned)(x0 >> 70) | (v0 * (unsigned)h1))) & 255u); } if (((unsigned)((unsigned)(p2 == a0[i0 & 3u]) < p0)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                if (budget != 0u) { budget -= 1u; u2 = fn0(p0, ((9u << (0x7fffffffu & 31u)) + r0.x), i1); }
                h1 = (unsigned short)(h1 + (unsigned)((short)~(a0[i0 & 3u] << (u0 & 31u)) > (signed char)(unsigned)((int)0x7fffffffu < (int)(unsigned)(w0 >> 29))));
                u2 += *mp;
                while (i1++ < 7u && -(unsigned)((short)v0 > (signed char)(u1 << ((unsigned)h0 & 31u)))) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        b0 = ((unsigned)((short)a0[i0 & 3u] > (signed char)u0) / (-(g1 * (unsigned)((int)(unsigned)e0 >= (int)(unsigned)f0)) | 1u)) != 0u;
                        g0 = (unsigned)(signed char)(unsigned)((unsigned)(m0 < (unsigned)h0) && ((unsigned)c1 << (((unsigned)(w0 >> 29) & 0x68a4d8ddu) & 31u)));
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)u0 >= (int)i1), garr[i1 & 7u], (0x57002d86u % (m0 | 1u))); }
                        if (((g1 << (r0.y & 31u)) >> ((unsigned)c0 & 31u))) break;
                        w0 ^= (unsigned long long)garr[i1 & 7u] << ((garr[u2 & 7u] ^ 0x80000000u) & 63u);
                        r0.x = ((unsigned)!(v0 | (unsigned)b0) >> (0x7fffffffu & 31u));
                    } while (i2++ < 3u && (unsigned)(garr[u2 & 7u] && p2));
                }
                l0 = (long)((unsigned long)l0 + (unsigned)(u3 == ((8u / (~(g0 - (unsigned)s1) | 1u)) ^ a0[u1 & 3u])));
            }
            if ((u0 | (unsigned)!(unsigned)((int)i0 >= (int)0xabf5b2adu))) break;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(0x371a65du & 255u);
                r0.x = (unsigned)l0;
            }
        } while (i0++ < 6u && (unsigned)((unsigned)l0 || g0));
        L0: if (--fuel == 0u) goto done;
        u2 = u2 * 0x9e3779b1u + (unsigned)(v0 < (unsigned)w0);
        x0 = x0 * 0x100000001b3ull + ((r0.x * u2) | r0.x);
        garr[1u & 7u] = (0x42a6d7feu - u1);
        if ((unsigned)(p2 == -(unsigned)((int)0x80000000u < (int)a0[i0 & 3u]))) {
            switch ((unsigned)(a0[i0 & 3u] || v0) & 7u) {
                if (6u) goto L2;
                *q0 = ((unsigned)s1 & ((0xffffffffu - (unsigned)d0) + u2));
                while ((unsigned)((int)r0.y < (int)0x10000u)) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)((unsigned)x0 % ((unsigned)s1 | 1u)) << (((unsigned)(0x3d0c5a27u == 0x1de1a29au) << ((unsigned)s1 & 31u)) & 63u);
                    if ((garr[u2 & 7u] << (i2 & 31u))) break;
                    e0 = e0 * 0.5L + (long double)((unsigned)(a0[i0 & 3u] && garr[i1 & 7u]) & 1023u);
                    if ((2u << (0x7fffffffu & 31u))) continue;
                    case 3u: ;
                    case 5u: ;
                }
                u2 = (unsigned)e0;
                m0 ^= ((0x9e460334u & (unsigned)l0) * *q0);
            }
        }
    }
    do { if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)(short)(u2 ^ g1);
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)d0 && (unsigned)w0)) break;
            if (budget != 0u) { budget -= 1u; u3 = fn0((7u % ((unsigned)d0 | 1u)), 0x2cd9cdecu, ((garr[i1 & 7u] ^ 0x80000000u) << (0x7fffffffu & 31u))); }
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                u3 += (0x7fffffffu % (i0 | 1u));
                break; (void)((u2 | 0xe87750ecu));
                switch (p0 & 7u) {
                    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        case 0u: ;
                        if ((p0 * ~(unsigned)((int)u1 >= (int)p1))) goto done;
                    }
                    g1 += (((unsigned)l0 ? (unsigned)s0 : (unsigned)(unsigned char)((unsigned)s1 - (unsigned)(x0 >> 70))) / ((unsigned)(w0 >> 29) | 1u));
                    q0 = &garr[(m0 & (unsigned)((int)(unsigned)d0 < (int)g0)) & 7u];
                }
            }
            g1 += ((0x47d4288u - (5u % (v0 | 1u))) + (unsigned)s0);
            g0 = (a0[i0 & 3u] * 0x10000u);
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)u3 > (signed char)p2), 9u, ((unsigned)f0 << ((0xc3db1fddu - 0x18b35d72u) & 31u))); }
        }
        L1: if (--fuel == 0u) goto done;
        break; (void)((unsigned)x0);
        e0 = e0 * 0.5L + (long double)(((unsigned)((int)0x3cdf5b0u >= (int)0x80000000u) - u1) & 1023u);
        s1 = (int)((unsigned)s1 + ((r0.x + (i0 ^ (unsigned)c0)) + (unsigned)l0));
    } while (i0++ < 2u && g1);
    g0 = ((unsigned)((unsigned)s1 < g0) % (p1 | 1u));
    if ((u3 & (unsigned)f0)) goto done;
    *mp = ((unsigned)((unsigned)s1 < (unsigned)(0x80000000u < a0[i0 & 3u])) | ~(unsigned)((int)u0 < (int)0u));
    u2 ^= ((r0.y << (r0.y & 31u)) + (unsigned)!(unsigned)((unsigned)(short)(3u << (u1 & 31u)) || (unsigned)e0));
    h1 = (unsigned short)(h1 + (unsigned)((short)(i2 + (unsigned)(signed char)(i0 - (unsigned)c0)) > (signed char)(unsigned)c0));
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            switch (~(unsigned)((unsigned)(w0 >> 29) && (unsigned)s0) & 7u) {
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)(unsigned)((unsigned)l0 || 6u) >= (int)0x80000000u)) {
                        c0 = (unsigned char)~((unsigned)s0 | (u3 >> (fuel & 31u)));
                        if ((garr[i1 & 7u] % (((unsigned)h0 % (0xffffffffu | 1u)) | 1u))) goto L3;
                        switch ((((unsigned)l0 * 0xaac09e9fu) * g1) & 7u) {
                            *q0 = (((unsigned)s1 / ((unsigned)(x0 >> 70) | 1u)) + v0);
                        }
                        if ((2u - (unsigned)(x0 >> 70))) continue;
                    }
                    u1 = ((u3 + (unsigned)(x0 >> 70)) * 0x10000u);
                } while (i2++ < 3u && (unsigned)(7u && *q0));
                for (;;) { if (--fuel == 0u) goto done;
                    v0 = u0;
                    if ((unsigned)w0) continue;
                    u1 += g1;
                    L2: if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (u3 % ((unsigned)(fuel < i1) | 1u));
                }
                b0 = *q0 != 0u;
            }
            break; (void)((a0[u1 & 3u] << (i1 & 31u)));
            if (((0x80000000u / (0xffffffffu | 1u)) & (unsigned)l0)) {
                if ((unsigned)s1) break;
            }
        }
        L3: if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)(((unsigned)w0 - 0x10000u) & 1023u);
        if (*q0) goto L3;
        if (budget != 0u) { budget -= 1u; u2 = fn0((3u >> (u2 & 31u)), (0x10000u + (u2 ^ g1)), ((unsigned)f0 >> ((unsigned)x0 & 31u))); }
        if (budget != 0u) { budget -= 1u; u2 = fn0((fuel << ((i1 << (garr[u2 & 7u] & 31u)) & 31u)), (unsigned)!(u1 & a0[u1 & 3u]), (unsigned)h1); }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0(0xe3f65f94u, (unsigned)c0, 0x7fffffffu); }
    x0 = x0 * 0x100000001b3ull + ((0x8ddfb764u & u1) & p1);
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0(*mp, u1, (unsigned)((short)(unsigned)c0 > (signed char)m0)); }
        if (8u) break;
    }
    if ((unsigned)f0) goto L0;
    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(signed char)(*mp ^ *q0) >> (1u & 31u)), -(unsigned)((short)*mp > (signed char)u0), (6u & u3)); }
    c1 = (signed char)(unsigned)d0;
    u2 ^= (unsigned)h0;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)(((unsigned)(short)((unsigned)s1 / (garr[u2 & 7u] | 1u)) / (*q0 | 1u)) || (unsigned)f0));
        h1 = (unsigned short)(h1 + p1);
        while (i1++ < 5u && ~(0x850b9deu * fuel)) { if (--fuel == 0u) goto done;
            if (v0) goto L0;
            s0 = (int)((a0[i0 & 3u] % (1u | 1u)) << (((unsigned)c0 & fuel) & 31u));
            if (((unsigned)((int)(unsigned)(w0 >> 29) >= (int)r0.x) % (i0 | 1u))) continue;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)s1, (*q0 & 0x7fffffffu), garr[u2 & 7u]); }
        s1 = (int)((unsigned)s1 + ((unsigned)((unsigned)(u0 && p2) == (unsigned)((int)(unsigned)x0 >= (int)0x10000u)) ^ i0));
    }
    while (i0++ < 3u && (p2 / (u3 | 1u))) { if (--fuel == 0u) goto done;
        { unsigned t2; double z2; if (((unsigned)((int)0x2b765bc7u >= (int)0u)) & 1u) { t2 = 8u; z2 = (double)((garr[i1 & 7u]) & 255u); } if (((unsigned)((int)0x2b765bc7u >= (int)0u)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            break; (void)((unsigned)((unsigned)h1 && i2));
            s0 = (int)(0xffffffffu ? (unsigned)((unsigned)(0x4916a0c2u < u1) == 5u) : (unsigned)h0);
            if ((0x60e1f1ccu >> ((unsigned)l0 & 31u))) {
                L4: if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    garr[0x10000u & 7u] = (unsigned)(8u < (garr[u2 & 7u] - (0x10000u ? i0 : 0x115655a4u)));
                }
                garr[(unsigned)((int)(unsigned)(x0 >> 70) < (int)u2) & 7u] = ((unsigned)(signed char)(unsigned)(0x10000u < g0) % ((garr[u2 & 7u] | garr[i1 & 7u]) | 1u));
            } else {
                if ((unsigned)c1) break;
                if ((u1 + (unsigned)(unsigned char)(u3 >> (*q0 & 31u)))) break;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)m0 >= (int)(unsigned)(signed char)(g1 ^ 0x2ca260a8u)), (u2 & *mp), (unsigned)((int)9u < (int)0xf40c3ce5u)); }
                if (((unsigned)((int)0x1b8289eeu < (int)(unsigned)l0) >> (p0 & 31u))) break;
            }
        }
        switch ((unsigned)((6u ^ (unsigned)l0) && (unsigned)c0) & 7u) {
            switch (((unsigned)(a0[i0 & 3u] < 2u) >> (p2 & 31u)) & 7u) {
                switch (0xffffffffu & 7u) {
                    garr[(unsigned)x0 & 7u] = (unsigned)((int)(*q0 % ((unsigned)e0 | 1u)) >= (int)p1);
                    case 3u: ;
                }
            }
            g1 += (unsigned)((unsigned)e0 == (((unsigned)(signed char)(unsigned)((int)a0[i0 & 3u] < (int)0xfbc36b0cu) << (0x31bdbdbdu & 31u)) | u0));
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                g1 += -(7u ^ (0xffffffffu ^ (unsigned)(*q0 || 0u)));
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!((unsigned)x0 & (2u | (unsigned)b0)), (9u / (p1 | 1u)), (unsigned)((unsigned)d0 < p1)); }
                b0 = (unsigned)(short)(1u / (0x7fffffffu | 1u)) != 0u;
                *q0 = -(unsigned)(i0 && (unsigned)(a0[i0 & 3u] && ((unsigned)c1 ? (unsigned)s1 : 0xe5076dc2u)));
                *q0 += -(unsigned)(i1 < (unsigned)(short)(unsigned)((int)(u2 >> (p1 & 31u)) >= (int)(unsigned)((unsigned)e0 < u2)));
            }
            l0 = (long)((unsigned long)l0 + (unsigned)c0);
            h0 = (short)(8u >> ((unsigned)(short)(p0 ^ *q0) & 31u));
        }
        i0 = (unsigned)((unsigned)s0 == (unsigned)h1) & 15u;
    }
    *mp = (unsigned)(0x7fffffffu == 1u);
    if (-((4u * i1) % ((unsigned)(x0 >> 70) | 1u))) {
        if (((unsigned)c1 / ((unsigned)((int)a0[u1 & 3u] < (int)0xbd07ede6u) | 1u))) goto L1;
        v0 = -(p1 ? (r0.x * (unsigned)h0) : (0x5470dc4bu + 0xd20c790eu));
        goto L3;
        if (budget != 0u) { budget -= 1u; u3 = fn0((u0 % (0x53342990u | 1u)), 5u, ~(unsigned)(m0 || *mp)); }
        *q0 = ((unsigned)((unsigned)((int)(unsigned)x0 < (int)(unsigned)(x0 >> 70)) && (unsigned)!(0xfa5fdc05u & r0.x)) + (unsigned)l0);
    } else {
        r0.y ^= (unsigned)c1;
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0(2u, ((unsigned)(u1 || (unsigned)c0) / (0xce418810u | 1u)), ((0x953e9fdau / ((unsigned)f0 | 1u)) / (0x7fffffffu | 1u))); }
        do { if (--fuel == 0u) goto done;
            if (((unsigned)((int)7u >= (int)0xb831e882u) >> (0x93b417fau & 31u))) break;
            w0 = w0 * 6364136223846793005ull + p0;
            h1 = (unsigned short)(h1 + 0x3353a915u);
            g0 = garr[u2 & 7u];
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(short)((unsigned)((int)(unsigned)e0 >= (int)0x61651078u) ^ p2)) {
                    if ((7u >> (0xfd09a99u & 31u))) break;
                } else {
                    if ((p2 - 4u)) break;
                    b0 = ((unsigned)(w0 >> 29) * (unsigned)((unsigned)w0 || (unsigned)h1)) != 0u;
                }
                l0 = (long)((unsigned long)l0 + 0x80000000u);
                if (((unsigned)(signed char)(unsigned)(6u || 0x7fffffffu) & a0[i0 & 3u])) {
                    *mp = (unsigned)(signed char)((0xde303159u | ((unsigned)(w0 >> 29) / ((0xe3c7d9a3u % ((unsigned)l0 | 1u)) | 1u))) + 0xffffffffu);
                    while (i0++ < 4u && (unsigned)(unsigned char)(6u - (unsigned)l0)) { if (--fuel == 0u) goto done;
                        break; (void)(((unsigned)e0 >> (garr[i1 & 7u] & 31u)));
                        *mp = (unsigned)!(i1 + (u1 & (0xffffffffu | 0x62003275u)));
                        if (budget != 0u) { budget -= 1u; u3 = fn0(p2, 0xffffffffu, fuel); }
                        break; (void)((unsigned)(4u || (unsigned)((short)0x7fffffffu > (signed char)0x80000000u)));
                        garr[0x8e515750u & 7u] = (unsigned)(short)(i0 + garr[u2 & 7u]);
                    }
                    while (i0++ < 2u && p0) { if (--fuel == 0u) goto done;
                        g0 = (p0 ^ ((unsigned)h0 / ((((unsigned)b0 << (u1 & 31u)) >> (*mp & 31u)) | 1u)));
                        c0 = (unsigned char)0x7fffffffu;
                        if ((u0 * ((unsigned)d0 | 9u))) goto L3;
                        if ((0xffffffffu + r0.y)) break;
                        continue; (void)(0xc9ba0718u);
                    }
                }
                do { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + ((((unsigned)(x0 >> 70) % (r0.y | 1u)) / (1u | 1u)) % ((unsigned)h1 | 1u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((*mp | 0xa8dccf5bu), (r0.x >> (0xf0179ddbu & 31u)), (unsigned)(unsigned char)((unsigned)(unsigned char)(a0[i0 & 3u] / ((unsigned)x0 | 1u)) ^ u3)); }
                } while (i0++ < 2u && (p2 >> (6u & 31u)));
                e0 = e0 * 0.5L + (long double)((((unsigned)s1 * (unsigned)s1) * *q0) & 1023u);
            }
            if (((garr[i1 & 7u] + u2) - p1)) break;
        } while (i1++ < 6u && (unsigned)(unsigned char)(unsigned)((int)garr[u2 & 7u] >= (int)0xffffffffu));
    } while (i0++ < 6u && ((unsigned)((unsigned)(x0 >> 70) || (unsigned)d0) >> (garr[u2 & 7u] & 31u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while ((unsigned)((int)0xffffffffu >= (int)((unsigned)x0 | a0[i0 & 3u]))) { if (--fuel == 0u) goto done;
        *mp = ((garr[u2 & 7u] - 0x3bc8fe2au) ^ (0x378c32ceu | (unsigned)(garr[i1 & 7u] && i2)));
        if (budget != 0u) { budget -= 1u; u3 = fn0((0xffffffffu - ~((unsigned)h1 - 0u)), (r0.x >> (m0 & 31u)), (1u - 0xa7b95345u)); }
        m0 ^= (unsigned)(unsigned char)(unsigned)(((m0 + (unsigned)(0x7fffffffu < 7u)) * garr[u2 & 7u]) == (unsigned)s1);
        q0 = &garr[(0x80000000u ? r0.x : 0x80e00868u) & 7u];
    }
    while (i0++ < 2u && (0x7fffffffu + v0)) { if (--fuel == 0u) goto done;
        break; (void)(m0);
        if ((unsigned)(p2 < 0x7fffffffu)) {
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn1((7u & (unsigned)(p2 && *mp)), (0xf29e08dfu ^ (unsigned)((int)(unsigned)(w0 >> 29) < (int)0x10000u)), (*mp - (unsigned)((short)a0[u1 & 3u] > (signed char)g1))); }
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    q0 = &garr[(unsigned)((unsigned)((int)9u >= (int)g1) || ((unsigned)x0 ? u1 : v0)) & 7u];
                    r0.y ^= (unsigned)c1;
                    a0[(5u & 0xffffffffu) & 3u] = (unsigned)d0;
                }
                u0 += (a0[u1 & 3u] ^ 0x7fffffffu);
                if (i1) {
                    if (fuel < 8u) return (6u / (((unsigned)(u3 == i2) + p0) | 1u));
                    if (u3 == 7u) return (unsigned)(0xa416960fu == (0x8eaeb360u / (0x531a0804u | 1u)));
                }
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((u0 % ((unsigned)c1 | 1u)));
                }
            }
            if ((0x7fffffffu * a0[i0 & 3u])) {
                if (budget != 0u) { budget -= 1u; u1 = fn0((0xe2ac48d0u + (garr[i1 & 7u] + (unsigned)f0)), (r0.y % ((unsigned)s0 | 1u)), (unsigned)((unsigned)w0 < (unsigned)((short)(unsigned)c0 > (signed char)*q0))); }
                if ((unsigned)(short)(unsigned)((short)(unsigned)w0 > (signed char)(unsigned)h0)) break;
                g1 += ((0xc2066d69u + (p1 ^ (unsigned)h0)) - u0);
                L0: if (--fuel == 0u) goto done;
            } else {
                u1 = u2;
                u2 ^= (0x20f3d748u | i1);
                f0 = f0 * 0.5f + (float)((((unsigned)f0 - (unsigned)h0) | garr[u2 & 7u]) & 255u);
            }
            g0 = (unsigned)(x0 >> 70);
        } else {
            L1: if (--fuel == 0u) goto done;
        }
        if ((unsigned)((unsigned)h1 || (p2 + r0.y))) {
            c1 = (signed char)((unsigned)h0 | (unsigned)((int)(a0[u1 & 3u] | fuel) >= (int)a0[u1 & 3u]));
            h0 = (short)((unsigned)(unsigned char)(unsigned)((unsigned)s1 == (unsigned)f0) % (0x80000000u | 1u));
        }
        if ((unsigned)(0x4af9e244u && (unsigned)(short)(p1 ^ (unsigned)s0))) goto L2;
        q0 = &garr[(unsigned)(unsigned char)(unsigned)((int)(unsigned)((unsigned)w0 < 2u) < (int)(unsigned)((p2 - (unsigned)e0) && 2u)) & 7u];
    }
    while (i0++ < 6u && (~(unsigned)(3u == (unsigned)c0) & 0x49d01706u)) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(0xffffffffu && g0));
        break; (void)((a0[i0 & 3u] | (unsigned)s1));
    }
    if (((fuel & (unsigned)x0) & i0)) goto L0;
    if ((unsigned)!(unsigned)((short)2u > (signed char)u1)) {
        if (budget != 0u) { budget -= 1u; u2 = fn0(i0, (0x8cc40302u % (u1 | 1u)), (unsigned)h1); }
        x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)(r0.x && p1) > (signed char)((unsigned)x0 ^ (0x80000000u & g0)));
        L2: if (--fuel == 0u) goto done;
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            garr[((unsigned)c0 | r0.y) & 7u] = (unsigned)(*mp || -((unsigned)b0 | 0x7fffffffu));
            f0 = f0 * 0.5f + (float)((((0x80000000u | g1) % ((unsigned)h1 | 1u)) - (*q0 << (fuel & 31u))) & 255u);
        }
    }
    s1 = (int)((unsigned)s1 + (p1 % ((unsigned)((short)8u > (signed char)(*mp / ((unsigned)s0 | 1u))) | 1u)));
    f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)(m0 || *mp) - (unsigned)(x0 >> 70)) < (u2 | a0[u1 & 3u])) & 255u);
    r0.y ^= (unsigned)((int)(unsigned)(0xffffffffu || 3u) >= (int)(unsigned)((short)(a0[i0 & 3u] % (u0 | 1u)) > (signed char)r0.y));
    L3: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)p2 >= (int)((unsigned)(w0 >> 29) & 0x85777581u)), (unsigned)(0x6de05f75u == (unsigned)((unsigned)f0 == (unsigned)h0)), (unsigned)((short)u1 > (signed char)(*mp | 0xd0021cfau))); }
    x0 = x0 * 0x100000001b3ull + (unsigned)(short)(v0 + (unsigned)f0);
    goto L3;
    { unsigned t0; double z0; if (((unsigned)!(u3 + (unsigned)((int)(unsigned)(w0 >> 29) < (int)garr[i1 & 7u]))) & 1u) { t0 = (0x80000000u - (unsigned)c0); z0 = (double)(((unsigned)((short)(unsigned)(i0 && 0x7fffffffu) > (signed char)0x1b54b4f5u)) & 255u); } if (((unsigned)!(u3 + (unsigned)((int)(unsigned)(w0 >> 29) < (int)garr[i1 & 7u]))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        if (u3 == 7u) return (unsigned)(a0[u1 & 3u] && 0x80000000u);
        if (0x80000000u) {
            L4: if (--fuel == 0u) goto done;
        } else {
            if ((fuel & (unsigned)(signed char)(unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)f0))) goto L1;
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(short)(*mp & (9u % ((unsigned)s0 | 1u)))) break;
                u3 ^= (unsigned)(unsigned char)(unsigned)((short)u0 > (signed char)5u);
            }
            r0.y ^= (unsigned)((short)-(((unsigned)(w0 >> 29) + u2) % (garr[u2 & 7u] | 1u)) > (signed char)fuel);
        }
    }
    goto L1;
    if ((unsigned)e0) goto L1;
    g0 = 0xffffffffu;
    if (r0.x) {
        r0.x = (0x78c4c5au / ((unsigned)(short)(p2 ^ 1u) | 1u));
        w0 = w0 * 6364136223846793005ull + (unsigned)!(unsigned)(8u || a0[u1 & 3u]);
        do { if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if ((0xc471f2cau) & 1u) { t1 = ((unsigned)((short)0x8434a820u > (signed char)(unsigned)b0) ^ 0u); z1 = (double)((u2) & 255u); } if ((0xc471f2cau) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                if ((3u - (unsigned)d0)) break;
                continue; (void)((unsigned)(unsigned char)(unsigned)(7u == (0x4f8301f7u | (unsigned)e0)));
                if (((unsigned)e0 + (*q0 << ((unsigned)s1 & 31u)))) break;
                c0 = (unsigned char)(unsigned)(signed char)((r0.y & m0) * (unsigned)(0xffffffffu < (unsigned)l0));
                break; (void)(((unsigned)s0 ^ 0u));
                if (budget != 0u) { budget -= 1u; u1 = fn0((0x7fffffffu & (unsigned)((unsigned)d0 && u0)), (unsigned)((short)(unsigned)c0 > (signed char)0x5bcce5bbu), ((unsigned)s1 - 0xffffffffu)); }
            }
            if (4u) break;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)f0, (unsigned)(signed char)(0xb550bdb2u + 7u), (unsigned)((unsigned)e0 && 0x10000u)); }
            g0 = ((unsigned)d0 ? garr[u2 & 7u] : ((unsigned)b0 >> ((unsigned)(x0 >> 70) & 31u)));
            *q0 = (i1 & garr[u2 & 7u]);
            u2 = u2 * 0x9e3779b1u + ((unsigned)(x0 >> 70) | p1);
        } while (i0++ < 5u && ((unsigned)h0 << ((unsigned)x0 & 31u)));
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)((unsigned)h1 * *mp) > (signed char)0xffffffffu)) {
                x0 = x0 * 0x100000001b3ull + *q0;
                l0 = (long)((unsigned long)l0 + (p2 * m0));
                if ((unsigned)(g0 < ((unsigned)b0 ^ (unsigned)h0))) goto L3;
                break; (void)(p2);
                f0 = f0 * 0.5f + (float)(((unsigned)l0 ? (i1 | p1) : 0xffffffffu) & 255u);
                if (0x4aa858a7u) break;
            } else {
                v0 = 0x7fffffffu;
                r0.y ^= (unsigned)s0;
            }
            w0 = w0 * 6364136223846793005ull + (8u / (((r0.y * fuel) + (i2 / (u1 | 1u))) | 1u));
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (unsigned)((p0 - (unsigned)s1) == garr[i1 & 7u]));
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    v0 = (unsigned)((short)(i1 & 5u) > (signed char)(unsigned)((unsigned)h0 < 0x70913b3bu));
                    if (-(u2 << (p1 & 31u))) break;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((r0.x + (unsigned)(*q0 == p1)), (0x7fffffffu - (unsigned)(a0[i0 & 3u] || 0xe8eda078u)), g0); }
                    g0 = (((unsigned)s0 ^ (unsigned)d0) << ((unsigned)((int)(unsigned)l0 >= (int)*q0) & 31u));
                    m0 ^= (unsigned)(m0 && p2);
                    if (~(a0[i0 & 3u] - r0.y)) break;
                }
                if (garr[i1 & 7u]) break;
                if ((0xffffffffu ? 0x10000u : u1)) goto L3;
                goto L0;
                if ((unsigned)(unsigned char)((unsigned)s1 ? u1 : (unsigned)f0)) continue;
            }
            w0 ^= (unsigned long long)(unsigned)h1 << ((u2 % ((unsigned)((unsigned)l0 == ~(~(1u * (unsigned)s1) % ((unsigned)(x0 >> 70) | 1u))) | 1u)) & 63u);
        }
    }
    x0 = x0 * 0x100000001b3ull + (*q0 * (unsigned)(p1 || 0x80000000u));
    d0 = d0 * 0.5 + (double)((unsigned)(p0 < ((5u ^ garr[i1 & 7u]) / ((unsigned)(0xefd7f88cu < (unsigned)s0) | 1u))) & 1023u);
    w0 ^= (unsigned long long)(0x346eeb8du % (p1 | 1u)) << (((unsigned)l0 ^ 1u) & 63u);
    switch ((unsigned)d0 & 7u) {
        switch ((unsigned)(g0 == u3) & 7u) {
            c0 = (unsigned char)(unsigned)((6u ? ((unsigned)w0 / (0x4a83a52u | 1u)) : *q0) == u0);
            if (budget != 0u) { budget -= 1u; u2 = fn1(((m0 * (unsigned)c1) & r0.x), (unsigned)((int)(unsigned)w0 < (int)*q0), (garr[i1 & 7u] / (r0.x | 1u))); }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1(u1, (0x6a286e75u | (unsigned)s0), (unsigned)((int)(*q0 * 0x7fffffffu) >= (int)0x41dc8aa3u)); }
        if ((unsigned)(w0 >> 29)) {
            l0 = (long)((unsigned long)l0 + ((unsigned)(garr[i1 & 7u] < 0x10000u) + (3u ^ (unsigned)b0)));
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 3u: ;
                s0 = (int)(unsigned)((int)garr[i1 & 7u] < (int)(g0 >> (p0 & 31u)));
                f0 = f0 * 0.5f + (float)((((unsigned)((int)a0[i0 & 3u] < (int)0x1102b78u) % ((unsigned)((int)p1 >= (int)5u) | 1u)) * r0.y) & 255u);
                *mp = (unsigned)((unsigned)(signed char)(0xcb015854u + (unsigned)l0) < r0.y);
                case 4u: ;
            }
            case 1u: ;
        }
        default: ;
        if (garr[u2 & 7u]) goto L3;
    }
    if ((unsigned)(i0 && ((unsigned)l0 >> (garr[i1 & 7u] & 31u)))) {
        s0 = (int)((unsigned)((int)(unsigned)l0 < (int)u1) << ((3u | (unsigned)s0) & 31u));
        switch (u1 & 7u) {
            h1 = (unsigned short)(h1 + (unsigned)((0x80000000u * p1) < ((p1 & i0) >> ((unsigned)w0 & 31u))));
            u1 = u1 * 0x9e3779b1u + ((unsigned)((unsigned)d0 == (u1 | (unsigned)((unsigned)(w0 >> 29) || 0x7fffffffu))) >> ((unsigned)b0 & 31u));
            i0 = (unsigned)((int)((unsigned)(p0 < (r0.y / ((unsigned)d0 | 1u))) >> (r0.y & 31u)) >= (int)i2) & 15u;
            h1 = (unsigned short)(h1 + (unsigned)s0);
            case 2u: ;
            if ((unsigned)((unsigned)w0 < u0)) {
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) == 5u) || 0x35b0d6c5u), ((i2 << (2u & 31u)) + 0x78309339u), 9u); }
                break; (void)(7u);
                u2 = u2 * 0x9e3779b1u + (unsigned)(w0 >> 29);
                i0 = (unsigned)s0 & 15u;
                u0 += (unsigned)((int)i2 < (int)(unsigned)s0);
            } else {
                h1 = (unsigned short)(h1 + (g0 + 0xbf2e5fb3u));
                if ((unsigned)s1) {
                    while (i0++ < 3u && garr[u2 & 7u]) { if (--fuel == 0u) goto done;
                        default: ;
                    }
                    a0[(unsigned)e0 & 3u] = (0xf63bc873u / (~((unsigned)d0 & (unsigned)l0) | 1u));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((i1 << (p2 & 31u)), (unsigned)e0, ((unsigned)(signed char)(fuel & (unsigned)w0) * r0.x)); }
                    w0 ^= (unsigned long long)7u << (((unsigned)h1 >> ((unsigned)b0 & 31u)) & 63u);
                    e0 = e0 * 0.5L + (long double)((unsigned)((short)6u > (signed char)(a0[i0 & 3u] % (m0 | 1u))) & 1023u);
                    case 6u: ;
                } else {
                    case 3u: ;
                    garr[((unsigned)b0 / (g1 | 1u)) & 7u] = (unsigned)(unsigned char)((unsigned)w0 & u0);
                    r0.x = (((u0 << (a0[i0 & 3u] & 31u)) * r0.x) ^ a0[u1 & 3u]);
                    case 4u: ;
                }
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    break;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(v0 && garr[u2 & 7u]), ((unsigned)d0 ^ p2), (unsigned)(0xd2c21cceu || ((unsigned)(w0 >> 29) << (0x10000u & 31u)))); }
            }
        }
    } else {
        if ((0x4c495a2bu & *q0)) goto done;
    }
    d0 = d0 * 0.5 + (double)((unsigned)((int)(i2 >> (*mp & 31u)) >= (int)(unsigned)!(unsigned)(((unsigned)w0 + (unsigned)w0) || 2u)) & 1023u);
    g1 += (unsigned)((unsigned)(signed char)(u1 << ((unsigned)((unsigned)s1 || (unsigned)s1) & 31u)) || (1u ^ (unsigned)x0));
    do { if (--fuel == 0u) goto done;
        break; (void)(u0);
    } while (i0++ < 2u && (unsigned)((short)0xffffffffu > (signed char)(g0 & *mp)));
    if (~(unsigned)((unsigned)((int)0x4db8d6e9u < (int)0x10000u) == i1)) goto done;
    if (i0) goto L2;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)0x80000000u < (int)(unsigned)((int)g1 < (int)(unsigned)x0));
        garr[(unsigned)e0 & 7u] = (unsigned)((unsigned)(x0 >> 70) == (0x80000000u << (garr[u2 & 7u] & 31u)));
        break; (void)((i1 ? 0x4829707au : (unsigned)h0));
        do { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + fuel);
            l0 = (long)((unsigned long)l0 + (0x297911a9u * (unsigned)((int)(unsigned)w0 < (int)0x1b68f78eu)));
            s0 = (int)(unsigned)((int)(unsigned)((short)p0 > (signed char)fuel) >= (int)((unsigned)h0 & (unsigned)d0));
        } while (i1++ < 5u && (unsigned)((2u | r0.y) && 0xffffffffu));
        q0 = &garr[~((unsigned)(fuel && (unsigned)x0) & (0xb346b57du >> ((unsigned)h1 & 31u))) & 7u];
    }
    v0 = (0x21898d2eu + (m0 | g1));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)(short)(p1 - (unsigned)(*mp == 0x765cdc87u)));
        { unsigned t2; double z2; if ((((unsigned)(a0[i0 & 3u] == 2u) << (r0.x & 31u))) & 1u) { t2 = 0xc87369d0u; z2 = (double)(((7u << ((unsigned)(*q0 && m0) & 31u))) & 255u); } if ((((unsigned)(a0[i0 & 3u] == 2u) << (r0.x & 31u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            c1 = (signed char)((unsigned)(((unsigned)w0 & u0) && u2) & (unsigned)c0);
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)s1 >> (((unsigned)(w0 >> 29) / ((unsigned)f0 | 1u)) & 31u))) break;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(unsigned)l0 > (signed char)((unsigned)(x0 >> 70) / (p2 | 1u))), (unsigned)((short)(unsigned)!(u3 / ((unsigned)s0 | 1u)) > (signed char)u1), ((0x2f989bau + 0xffffffffu) % ((unsigned)c1 | 1u))); }
                if (budget != 0u) { budget -= 1u; u0 = fn0(0xdfaa2589u, 0x6590a54du, (unsigned)((int)(a0[i0 & 3u] * garr[i1 & 7u]) < (int)8u)); }
            }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 += (u2 - a0[u1 & 3u]);
                if (budget != 0u) { budget -= 1u; u0 = fn0(garr[i1 & 7u], ((unsigned)((short)v0 > (signed char)a0[i0 & 3u]) | (unsigned)c0), (unsigned)((unsigned)e0 && garr[i1 & 7u])); }
                l0 = (long)((unsigned long)l0 + (p1 / ((garr[u2 & 7u] ^ (unsigned)h1) | 1u)));
                s0 = (int)(unsigned)((int)p2 < (int)(3u * 0x65b9805u));
            }
            if (fuel < 8u) return (unsigned)x0;
        }
    }
    if ((unsigned)((i1 | v0) < garr[i1 & 7u])) {
        while (i0++ < 2u && ((unsigned)b0 << ((unsigned)d0 & 31u))) { if (--fuel == 0u) goto done;
            if (0u) break;
        }
    } else {
        *q0 += -((unsigned)((short)(unsigned)d0 > (signed char)((unsigned)d0 << ((unsigned)(garr[i1 & 7u] < u0) & 31u))) & 0x162c1819u);
    }
    if ((unsigned)s0) goto L3;
    do { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)!(i2 * ((unsigned)x0 & u3)) & 1023u);
        if ((unsigned)((short)g0 > (signed char)(a0[u1 & 3u] | (unsigned)l0))) {
            while (i1++ < 2u && (unsigned)((unsigned)x0 || ((unsigned)d0 + fuel))) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + ((0u + (a0[i0 & 3u] | p0)) | (unsigned)(signed char)(unsigned)(0xc0f8fa08u < 4u));
                f0 = f0 * 0.5f + (float)(-(unsigned)(~(unsigned)((unsigned)c0 < g1) || ((unsigned)(fuel && (unsigned)f0) >> (p1 & 31u))) & 255u);
                *q0 = ((unsigned)d0 * (unsigned)(v0 && (unsigned)w0));
                u2 ^= (unsigned)((int)(unsigned)!((unsigned)((unsigned)h0 == 0x10000u) ? 0x7fffffffu : (unsigned)(x0 >> 70)) >= (int)*q0);
                w0 = w0 * 6364136223846793005ull + (unsigned)(short)(unsigned)((int)p0 < (int)(unsigned)((int)*q0 < (int)(unsigned)(x0 >> 70)));
                switch ((unsigned)!(unsigned)(r0.y < (unsigned)(garr[u2 & 7u] && 0x80000000u)) & 7u) {
                    s0 = (int)(unsigned)s1;
                    x0 = x0 * 0x100000001b3ull + ((unsigned)c0 >> (garr[i1 & 7u] & 31u));
                }
            }
            switch (((unsigned)(1u && fuel) << ((unsigned)w0 & 31u)) & 7u) {
                i0 = (unsigned)((int)p2 < (int)g0) & 15u;
            }
        }
        goto L2;
        do { if (--fuel == 0u) goto done;
            if (p2) break;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)w0, (unsigned)((int)u1 >= (int)u0), (garr[i1 & 7u] * p0)); }
            if ((1u & (unsigned)f0)) {
                if (2u) {
                    a0[(unsigned)!(i0 % (u1 | 1u)) & 3u] = (p2 / ((unsigned)c1 | 1u));
                }
                switch ((unsigned)(0x319fc95u || (unsigned)s1) & 7u) {
                    i2 = 0x80000000u & 15u;
                    if (0xe40e7836u) goto L4;
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        case 0u: ;
                        c1 = (signed char)(0x3aa82f0u - (unsigned)(u1 == p0));
                        if ((garr[i1 & 7u] - (unsigned)w0)) goto L2;
                    }
                    case 6u: ;
                }
                s0 = (int)(((unsigned)(m0 < 0xefce3577u) * i0) + (unsigned)((int)p2 < (int)0x2a5537d3u));
            }
            i1 = (unsigned)(short)((unsigned)((unsigned)h1 && (unsigned)((unsigned)s1 < 0x463e12afu)) ^ (unsigned)(0x45a3c791u < g0)) & 15u;
            if ((unsigned)((int)a0[u1 & 3u] >= (int)(r0.x - 0x80000000u))) goto L1;
            q0 = &garr[g1 & 7u];
        } while (i1++ < 6u && (unsigned)((garr[u2 & 7u] | 8u) || g0));
    } while (i0++ < 2u && 0x10000u);
    if ((0x8829d488u ^ 0x7fffffffu)) {
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((3u ^ ((unsigned)h1 << (garr[i1 & 7u] & 31u))) < u0) && r0.y);
            while (i1++ < 4u && (unsigned)(signed char)((unsigned)(w0 >> 29) << ((unsigned)((short)0x10000u > (signed char)(unsigned)c1) & 31u))) { if (--fuel == 0u) goto done;
                if (6u) break;
                r0.y ^= v0;
            }
            *q0 += 0xe183f9b0u;
            for (;;) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return u1;
                c1 = (signed char)(((unsigned)d0 << ((2u * i2) & 31u)) >> ((g1 >> ((unsigned)h0 & 31u)) & 31u));
                g0 = (r0.y / (((unsigned)((short)u2 > (signed char)(unsigned)f0) ^ g1) | 1u));
                e0 = e0 * 0.5L + (long double)(4u & 1023u);
            }
        }
        r0.x = (unsigned)(u1 == (g0 | 0xc1aa22c8u));
        if (0x10000u) goto L0;
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)u1 < (int)5u), (unsigned)(i0 || 0x80000000u), (unsigned)((short)i2 > (signed char)(unsigned)!(unsigned)((int)g1 < (int)0x62baa774u))); }
        garr[(1u / (g0 | 1u)) & 7u] = r0.x;
        v0 = ((unsigned)h0 - r0.y);
    }
    a0[((unsigned)c0 ^ (unsigned)c1) & 3u] = (*q0 ? (0x10000u >> (i0 & 31u)) : a0[i0 & 3u]);
    g1 += (g1 - (unsigned)!((a0[i0 & 3u] % (0x80000000u | 1u)) | (unsigned)e0));
    goto L0;
    x0 = x0 * 0x100000001b3ull + ~(unsigned)((0xa063b4f2u - p2) == (unsigned)((int)(unsigned)l0 >= (int)(a0[i0 & 3u] << (a0[u1 & 3u] & 31u))));
    { unsigned t3; double z3; if ((((unsigned)c0 | garr[u2 & 7u])) & 1u) { t3 = (unsigned)((int)p2 >= (int)(unsigned)d0); z3 = (double)(((unsigned)((int)0xffffffffu < (int)0x7fffffffu)) & 255u); } if ((((unsigned)c0 | garr[u2 & 7u])) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        x0 = x0 * 0x100000001b3ull + (unsigned)((short)0x643e6f85u > (signed char)-(unsigned)((short)(unsigned)s0 > (signed char)(unsigned)((unsigned)b0 == (unsigned)c0)));
        l0 = (long)((unsigned long)l0 + (u0 << ((unsigned)((unsigned)w0 == -((unsigned)c1 % (2u | 1u))) & 31u)));
        g0 = ((unsigned)c1 >> ((unsigned)h1 & 31u));
    }
    if ((unsigned)((short)0x7fffffffu > (signed char)a0[u1 & 3u])) goto L0;
    goto L1;
    while (i0++ < 7u && u2) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)p2;
        *q0 = (unsigned)(unsigned char)(((unsigned)(0u && 0x7fffffffu) & (unsigned)((unsigned)b0 == u0)) % (*mp | 1u));
        u2 += p1;
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(u3 == (unsigned)((int)0xffffffffu < (int)(unsigned)d0)), (unsigned)(short)(u2 >> (((unsigned)h0 - (unsigned)(x0 >> 70)) & 31u)), 0u); }
        b0 = (unsigned)(short)(0xd5857cd6u % ((~(i0 ? (unsigned)h1 : *q0) + (unsigned)e0) | 1u)) != 0u;
        i2 = (((unsigned)h0 + 2u) - (unsigned)((short)0xd457fff7u > (signed char)(unsigned)(i2 < *mp))) & 15u;
    }
    if ((unsigned)(i0 == 0x6864b7au)) goto L4;
    if ((unsigned)((unsigned)((int)(unsigned)f0 < (int)(unsigned)h1) && i1)) goto L3;
    do { if (--fuel == 0u) goto done;
        while (i1++ < 6u && ((unsigned)(0x80000000u || u3) % (0x10000u | 1u))) { if (--fuel == 0u) goto done;
            if ((unsigned)s0) continue;
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(g0 || 0xffffffffu), (unsigned)(short)((unsigned)(w0 >> 29) * 0x80000000u), 0x63b89398u); }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)0x7fffffffu > (signed char)(unsigned)c1), -(unsigned)(i1 || v0), (unsigned)(unsigned char)(unsigned)((int)((unsigned)h1 >> ((unsigned)e0 & 31u)) < (int)u1)); }
                break; (void)((unsigned)(0x80000000u == (unsigned)d0));
            }
        }
        h1 = (unsigned short)(h1 + (unsigned)((int)9u < (int)p1));
    } while (i0++ < 2u && (~((unsigned)s0 ^ (unsigned)h1) + (unsigned)h0));
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)(*q0 & 1023u);
        v0 = (p2 ^ fuel);
        switch (u0 & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn1(0x15480f78u, 0x7fffffffu, (unsigned)s0); }
            if (budget != 0u) { budget -= 1u; u3 = fn1(a0[u1 & 3u], (unsigned)x0, (0x4b8315c1u % ((unsigned)f0 | 1u))); }
        }
        switch ((4u - (unsigned)d0) & 7u) {
            u1 += (unsigned)(0x10000u && (unsigned)(signed char)(0xffffffffu * a0[i0 & 3u]));
        }
        if ((unsigned)(unsigned char)(unsigned)((short)(unsigned)c1 > (signed char)(unsigned)f0)) break;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    a0[0x7fffffffu & 3u] = (unsigned)((short)(garr[i1 & 7u] % (i1 | 1u)) > (signed char)(unsigned)c0);
    switch (u0 & 7u) {
        { unsigned t0; double z0; if ((i0) & 1u) { t0 = (unsigned)x0; z0 = (double)(((*q0 - p2)) & 255u); } if ((i0) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            break; (void)((unsigned)((unsigned)b0 < (unsigned)((int)garr[u2 & 7u] >= (int)r0.x)));
            if ((unsigned)((short)(unsigned)((int)garr[u2 & 7u] < (int)r0.x) > (signed char)(unsigned)(w0 >> 29))) {
                u0 ^= (g1 + 0xe0a24d9fu);
                g0 = ((unsigned)h0 % ((*mp >> ((garr[i1 & 7u] ^ 8u) & 31u)) | 1u));
                if (fuel < 8u) return (unsigned)((int)0x49d9cd63u >= (int)0x80000000u);
            } else {
                if (((m0 & i2) ^ i0)) goto L4;
                if ((unsigned)(0xc73bd73eu == (unsigned)f0)) {
                    u0 = (unsigned)f0;
                    s1 = (int)((unsigned)s1 + (unsigned)(i2 || 0xa3625b91u));
                    break; (void)((7u / (u0 | 1u)));
                }
                { unsigned t1; double z1; if ((garr[u2 & 7u]) & 1u) { t1 = ((unsigned)s1 - 0x10000u); z1 = (double)((0x10000u) & 255u); } if ((garr[u2 & 7u]) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    while ((unsigned)(signed char)(unsigned)(m0 && 1u)) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (unsigned)((unsigned)((short)0xffffffffu > (signed char)((unsigned)(w0 >> 29) ? 0x7fffffffu : 8u)) == garr[u2 & 7u]));
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(unsigned char)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x10000u) >> ((unsigned)h0 & 31u)), (unsigned)(garr[i1 & 7u] || r0.x), (u0 >> (0x1389626fu & 31u))); }
                        L1: if (--fuel == 0u) goto done;
                        if (p1) continue;
                        break; (void)(~((unsigned)(w0 >> 29) % (u1 | 1u)));
                        if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)h0 | (unsigned)h0), u3, (unsigned)(r0.y == (unsigned)(i1 && i0))); }
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)(unsigned)h1 >= (int)(0x80000000u | 0x7fffffffu)), (unsigned)s1, 0x48c388c4u); }
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(i2 == *q0), ((unsigned)(0x10000u && (unsigned)c0) | 1u), (0x7fffffffu + (unsigned)(w0 >> 29))); }
                    if ((unsigned)!((unsigned)d0 | 3u)) goto L3;
                    goto L3;
                }
            }
        }
        L2: if (--fuel == 0u) goto done;
        L3: if (--fuel == 0u) goto done;
        if ((unsigned)(short)(0xc240fa85u ^ 0u)) {
            while (i0++ < 5u && 0x10000u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)h0 && (r0.x * 0xffffffffu)), (r0.y / ((5u & *q0) | 1u)), ~(unsigned)((int)*q0 >= (int)v0)); }
            }
            L4: if (--fuel == 0u) goto done;
        } else {
            while (i0++ < 4u && (0x9161c5b1u / (u2 | 1u))) { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        while (~(unsigned)((unsigned)(w0 >> 29) && (r0.y * (unsigned)l0))) { if (--fuel == 0u) goto done;
                            w0 ^= (unsigned long long)-((unsigned)c0 | 0x80000000u) << (((unsigned)((int)(unsigned)x0 < (int)(unsigned)w0) & (unsigned)(((unsigned)d0 + fuel) == (unsigned)b0)) & 63u);
                        }
                        s1 = (int)((unsigned)s1 + (fuel ^ 0x7fffffffu));
                        b0 = (unsigned)((unsigned)h1 < (unsigned)c0) != 0u;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)f0, (((unsigned)h1 | fuel) + 0x80000000u), (garr[i1 & 7u] % ((unsigned)((int)0x7fffffffu >= (int)6u) | 1u))); }
                        case 0u: ;
                    } while (i2++ < 2u && 0x80000000u);
                }
                i0 = (*q0 ? p0 : ((unsigned)x0 | 0x80000000u)) & 15u;
                case 5u: ;
            }
        }
        *q0 = ((u1 - 0x99a04f47u) | g0);
        if (budget != 0u) { budget -= 1u; u3 = fn0(~(unsigned)((int)a0[i0 & 3u] < (int)garr[i1 & 7u]), (0x69bebe70u ^ (unsigned)f0), (p1 ^ u0)); }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn2((a0[u1 & 3u] - (0x80000000u << (a0[u1 & 3u] & 31u))), (unsigned)((int)0x75884619u < (int)(unsigned)c0), (0xebe4e411u ^ g0)); }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (0x6801b7c6u ? ((unsigned)(signed char)(unsigned)(g0 || m0) & a0[u1 & 3u]) : i2);
        continue; (void)(((unsigned)d0 >> ((unsigned)(0x10000u || 6u) & 31u)));
        continue; (void)(((unsigned)h0 ^ p2));
        goto L1;
        do { if (--fuel == 0u) goto done;
            break; (void)(~(garr[u2 & 7u] ? i2 : (unsigned)e0));
            x0 = x0 * 0x100000001b3ull + ((unsigned)!(0xffffffffu & 3u) % ((unsigned)x0 | 1u));
            if ((unsigned)e0) break;
        } while (i1++ < 4u && (unsigned)(garr[u2 & 7u] < (unsigned)(short)(u3 / ((unsigned)f0 | 1u))));
        h0 = (short)((*mp * 0u) % ((unsigned)((unsigned)s1 || 5u) | 1u));
    }
    if (budget != 0u) { budget -= 1u; u2 = fn2((v0 << ((unsigned)x0 & 31u)), p1, ((unsigned)(x0 >> 70) / (9u | 1u))); }
    if (((0xfc368f96u >> (a0[u1 & 3u] & 31u)) >> ((unsigned)w0 & 31u))) goto L1;
    if (i0) {
        if (*mp) goto L1;
    } else {
        if ((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)(w0 >> 29))) goto L4;
    }
    u0 += (unsigned)(short)(0x80000000u - (unsigned)(w0 >> 29));
    { unsigned t2; double z2; if (((0xffffffffu | 0x10000u)) & 1u) { t2 = (0xffffffffu / (p0 | 1u)); z2 = (double)((a0[u1 & 3u]) & 255u); } if (((0xffffffffu | 0x10000u)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        x0 = x0 * 0x100000001b3ull + ((((g1 >> (0x17b43d23u & 31u)) - v0) & r0.x) * m0);
        if (fuel < 8u) return ((unsigned)((unsigned)(i2 || (unsigned)(0x10000u < 0x8a07500fu)) == (unsigned)w0) - (unsigned)h1);
    }
    do { if (--fuel == 0u) goto done;
        c0 = (unsigned char)((unsigned)(5u == 3u) / ((unsigned)l0 | 1u));
        l0 = (long)((unsigned long)l0 + (a0[u1 & 3u] | p1));
        if ((unsigned)((unsigned)w0 < (unsigned)(short)(u0 & (unsigned)(x0 >> 70)))) {
            if (budget != 0u) { budget -= 1u; u2 = fn2(0xfa6a99c4u, r0.x, (unsigned)((u3 << (u3 & 31u)) && (unsigned)l0)); }
            if ((unsigned)f0) break;
            m0 ^= ((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)((unsigned)c1 || 0x10000u)) * (unsigned)(w0 >> 29));
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (u3 == 7u) return 0x215e825du;
        }
        r0.y ^= ((0xffffffffu >> ((unsigned)(i0 && *q0) & 31u)) ? 0x10000u : (unsigned)(x0 >> 70));
    } while (i0++ < 2u && (u1 * 0x80000000u));
    *q0 += u2;
    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((int)(unsigned)c1 >= (int)(unsigned)(signed char)(0x7fffffffu + 0xffffffffu)), r0.y, i0); }
    { unsigned t3; double z3; if ((garr[u2 & 7u]) & 1u) { t3 = (unsigned)(u2 && (unsigned)((int)0x8d020342u >= (int)p1)); z3 = (double)(((u0 << (3u & 31u))) & 255u); } if ((garr[u2 & 7u]) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
        while (~(unsigned)((int)0x80000000u >= (int)0x7fffffffu)) { if (--fuel == 0u) goto done;
            while ((unsigned)(signed char)((unsigned)h1 ^ u3)) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((p2 | (unsigned)c0) & 255u);
                garr[(unsigned)(signed char)(0xffffffffu + fuel) & 7u] = (7u / ((unsigned)((int)0x61aa35e0u < (int)(unsigned)h1) | 1u));
                u0 += (unsigned)(signed char)((p0 * (unsigned)s1) - (unsigned)(short)(unsigned)((unsigned)((int)garr[u2 & 7u] < (int)i1) == 0x44084d46u));
                break; (void)((unsigned)e0);
                break; (void)((unsigned)f0);
            }
            if (fuel < 8u) return (fuel & 0x10000u);
            break; (void)((unsigned)((int)a0[u1 & 3u] >= (int)u0));
            while (i1++ < 7u && (unsigned)((unsigned)((int)0x4557ef7du < (int)(unsigned)(x0 >> 70)) == 0xfe3320e3u)) { if (--fuel == 0u) goto done;
                if (((*mp % ((unsigned)h1 | 1u)) << (m0 & 31u))) continue;
                if (u3 == 7u) return r0.y;
                for (;;) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(unsigned)((short)g1 > (signed char)(unsigned)s1) << (u2 & 63u);
                    if (i0) break;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0(0xffffffffu, 2u, 8u); }
                { unsigned t4; double z4; if (((unsigned)(signed char)(garr[i1 & 7u] / ((u0 ^ fuel) | 1u))) & 1u) { t4 = (unsigned)(a0[i0 & 3u] || (unsigned)(u2 || a0[u1 & 3u])); z4 = (double)((((unsigned)h1 - (i2 + *q0))) & 255u); } if (((unsigned)(signed char)(garr[i1 & 7u] / ((u0 ^ fuel) | 1u))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                    u3 = (((0x80000000u << (p2 & 31u)) % ((g1 / (garr[u2 & 7u] | 1u)) | 1u)) << (0x80000000u & 31u));
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        u2 = (u3 & (unsigned)(short)(0x6897d301u >> ((unsigned)((short)0x10000u > (signed char)(unsigned)s0) & 31u)));
                        if ((unsigned)(v0 < (unsigned)((int)9u >= (int)(unsigned)c1))) break;
                    }
                    if ((unsigned)w0) break;
                    while (i2++ < 5u && (unsigned)s0) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn1(0x80000000u, (unsigned)((short)g0 > (signed char)v0), ((0xffffffffu & 0x10000u) + (unsigned)d0)); }
                        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)((int)(unsigned)e0 >= (int)(unsigned)h1) / (m0 | 1u)), (unsigned)((unsigned)h0 && 0xffffffffu), (0x10000u - 0xa79d39d3u)); }
                        f0 = f0 * 0.5f + (float)((unsigned)((short)(unsigned)c1 > (signed char)garr[u2 & 7u]) & 255u);
                    }
                }
                while (i2++ < 4u && u3) { if (--fuel == 0u) goto done;
                    u0 = u0 * 0x9e3779b1u + (unsigned)((short)((unsigned)h0 - (unsigned)b0) > (signed char)(unsigned)x0);
                    u2 += (unsigned)((int)(unsigned)(short)(g1 / (p0 | 1u)) < (int)(unsigned)!(((unsigned)s0 * 0xb609feceu) + (unsigned)x0));
                    r0.y ^= ((unsigned)((int)i0 < (int)a0[i0 & 3u]) ? (unsigned)(signed char)(0xaa046925u >> (0x10000u & 31u)) : 0xffffffffu);
                    v0 = (unsigned)(0x10731b56u && ((*q0 & u3) >> (p0 & 31u)));
                }
            }
            q0 = &garr[(unsigned)(unsigned char)(unsigned)(((unsigned)x0 / ((unsigned)h0 | 1u)) || (unsigned)((short)p2 > (signed char)(unsigned)((unsigned)e0 && (unsigned)w0))) & 7u];
        }
        { unsigned t5; double z5; if ((i2) & 1u) { t5 = (unsigned)((unsigned)f0 == m0); z5 = (double)((a0[i0 & 3u]) & 255u); } if ((i2) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            if ((fuel - u0)) goto L4;
            if ((a0[i0 & 3u] ? garr[i1 & 7u] : (unsigned)f0)) {
                c1 = (signed char)u3;
                if ((unsigned)(unsigned char)(((unsigned)(x0 >> 70) | *mp) | (unsigned)h0)) goto L1;
            } else {
                s1 = (int)((unsigned)s1 + (-(u3 - garr[i1 & 7u]) % (p2 | 1u)));
                h1 = (unsigned short)(h1 + (unsigned)(u2 && (~(unsigned)(u1 < 6u) ? (unsigned)f0 : 0xe0ffb3c7u)));
                goto done;
                h0 = (short)(unsigned)(short)(unsigned)(r0.y || ((unsigned)!(g0 ^ garr[u2 & 7u]) ? 9u : (unsigned)h1));
            }
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(i0 & 1023u);
                i0 = (unsigned)((int)(unsigned)((unsigned)(unsigned char)(0x48c406efu / ((unsigned)((int)u3 >= (int)g1) | 1u)) && i1) < (int)0x7fffffffu) & 15u;
                break; (void)(((unsigned)c0 + (unsigned)((unsigned)(x0 >> 70) && 0x10000u)));
            }
            u3 = ((((unsigned)c1 ^ 8u) / (u2 | 1u)) | p0);
            if (budget != 0u) { budget -= 1u; u0 = fn1((garr[u2 & 7u] ? 0xffffffffu : fuel), ((3u & garr[u2 & 7u]) % (p2 | 1u)), (unsigned)b0); }
        }
        w0 = w0 * 6364136223846793005ull + ((unsigned)((v0 | a0[i0 & 3u]) < (unsigned)w0) | garr[i1 & 7u]);
        for (;;) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (garr[u2 & 7u] | 1u);
            h1 = (unsigned short)(h1 + ((unsigned)((int)*mp < (int)0x7fffffffu) / (((unsigned)h1 - (unsigned)b0) | 1u)));
            m0 ^= i0;
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((short)(unsigned)(short)(unsigned)(v0 < (unsigned)(x0 >> 70)) > (signed char)(unsigned)f0) < ((unsigned)s0 >> (0xffffffffu & 31u)));
            if ((unsigned)(unsigned char)(unsigned)((9u >> (u2 & 31u)) || 0x10000u)) {
                r0.y ^= (unsigned)(x0 >> 70);
                x0 = x0 * 0x100000001b3ull + (((unsigned)l0 / ((unsigned)f0 | 1u)) << ((unsigned)((unsigned)l0 || (a0[u1 & 3u] & (unsigned)e0)) & 31u));
                if ((unsigned)((int)((unsigned)h1 | fuel) < (int)0xb73090b2u)) break;
                if ((unsigned)(w0 >> 29)) goto L1;
                b0 = (((unsigned)(unsigned char)(unsigned)(u2 && a0[u1 & 3u]) - garr[u2 & 7u]) ^ (unsigned)((int)p0 < (int)0xffffffffu)) != 0u;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn2(3u, g0, (unsigned)s1); }
                    if (budget != 0u) { budget -= 1u; u3 = fn1((m0 / (i1 | 1u)), (unsigned)((r0.x | 2u) == 6u), garr[i1 & 7u]); }
                    if (0x8a922255u) break;
                    i0 = -(unsigned)((fuel | ((unsigned)(w0 >> 29) - 0xa12b3643u)) || -(unsigned)((unsigned)d0 < u3)) & 15u;
                } while (i1++ < 2u && (unsigned)((int)(0x95c1cb3cu % (0xb40c70e3u | 1u)) < (int)(unsigned)s1));
            } else {
                if ((u3 & 0x10000u)) break;
            }
        }
        garr[(0x59abf640u & 0x314ebf50u) & 7u] = (unsigned)(0xffffffffu == (unsigned)(x0 >> 70));
    }
    if ((p0 / ((0x7fffffffu % ((unsigned)s1 | 1u)) | 1u))) goto done;
    goto L4;
    { unsigned t6; double z6; if (((unsigned)d0) & 1u) { t6 = 0x80000000u; z6 = (double)(((garr[u2 & 7u] % ((unsigned)(8u || i2) | 1u))) & 255u); } if (((unsigned)d0) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            while ((((unsigned)d0 * (unsigned)d0) - 6u)) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return (unsigned)(0x80000000u < (unsigned)s1);
                if ((unsigned)(x0 >> 70)) continue;
                if ((unsigned)s1) break;
            }
            if (0xb94168ceu) break;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)(i0 < r0.y) == (unsigned)h1), r0.x, (unsigned)((int)0x10000u < (int)2u)); }
        v0 = (unsigned)((short)(unsigned)(short)(unsigned)((int)((unsigned)(0u && 0x4f496bceu) + *mp) < (int)(unsigned)h1) > (signed char)u2);
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            q0 = &garr[(unsigned)(short)(((unsigned)l0 >> ((unsigned)((int)((unsigned)c1 ^ v0) < (int)(unsigned)l0) & 31u)) ^ (unsigned)e0) & 7u];
            m0 ^= (0xb6bc0119u + (garr[u2 & 7u] ^ fuel));
            *q0 += (0xffffffffu & v0);
            m0 ^= (unsigned)((u1 ? (unsigned)h0 : (unsigned)s0) == (i2 / (p1 | 1u)));
            if ((unsigned)b0) break;
            if (0u) continue;
        }
    }
    while (i0++ < 6u && (v0 / (0xffffffffu | 1u))) { if (--fuel == 0u) goto done;
        u1 ^= ((unsigned)((short)(unsigned)((unsigned)e0 && (unsigned)s0) > (signed char)i1) / (((unsigned)f0 ^ p1) | 1u));
        if (budget != 0u) { budget -= 1u; u1 = fn1(6u, (unsigned)!((unsigned)x0 << (i0 & 31u)), (r0.x - 0xd9f9417fu)); }
        g1 += 5u;
        *q0 += (3u % (((0x7fffffffu | (unsigned)(r0.y < p0)) >> (g1 & 31u)) | 1u));
    }
    if (~(0x7fffffffu * (unsigned)((short)u0 > (signed char)(unsigned)s0))) {
        { unsigned t7; double z7; if (((unsigned)((int)(unsigned)s1 < (int)9u)) & 1u) { t7 = a0[u1 & 3u]; z7 = (double)(((unsigned)((0x80000000u * v0) || 5u)) & 255u); } if (((unsigned)((int)(unsigned)s1 < (int)9u)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
            if (fuel < 8u) return (unsigned)(signed char)(unsigned)(((p2 ^ 0x80000000u) * fuel) && (i2 + 0xffffffffu));
            if ((unsigned)((unsigned)d0 && u0)) goto L1;
            if (budget != 0u) { budget -= 1u; u2 = fn1(u0, (unsigned)((int)(0x7fffffffu >> (a0[u1 & 3u] & 31u)) < (int)6u), (unsigned)c1); }
            if (budget != 0u) { budget -= 1u; u2 = fn2(p2, (unsigned)(0x6021d9e0u == g0), 7u); }
            *mp = 0x10000u;
            f0 = f0 * 0.5f + (float)(((unsigned)(fuel && i2) / (garr[u2 & 7u] | 1u)) & 255u);
        }
        if (budget != 0u) { budget -= 1u; u1 = fn2((0x55438559u & (u2 << ((unsigned)c0 & 31u))), -((unsigned)h0 & 0xe295680au), (m0 | u1)); }
        if (((unsigned)d0 / (u1 | 1u))) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)d0 << ((unsigned)c0 & 31u)) >= (int)fuel));
        if (budget != 0u) { budget -= 1u; u1 = fn0(0x7fffffffu, (((unsigned)b0 * i1) | g0), (unsigned)((unsigned)h1 == p1)); }
    } else {
        if (budget != 0u) { budget -= 1u; u1 = fn1((a0[i0 & 3u] * (unsigned)(p1 || 0x2197c841u)), (unsigned)(1u == u3), (unsigned)b0); }
        while ((unsigned)((int)a0[i0 & 3u] < (int)(r0.y - v0))) { if (--fuel == 0u) goto done;
            s0 = (int)(p1 ? v0 : 0xc2e2cfb4u);
            if ((unsigned)(signed char)(unsigned)((unsigned)(x0 >> 70) < (unsigned)c0)) break;
            if (i1) break;
            e0 = e0 * 0.5L + (long double)(7u & 1023u);
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)i2 < (int)garr[u2 & 7u]), (-(0x80000000u ^ (unsigned)f0) ^ 0u), (0x80000000u | 0x56db0a9au)); }
        }
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)(0x6479bae8u || (unsigned)(9u || ((a0[u1 & 3u] ^ g1) << (0xa19d4ee8u & 31u))));
    if (u3 == 7u) return (m0 << (p0 & 31u));
    *q0 = (unsigned)(signed char)(unsigned)(4u || (unsigned)f0);
    if ((unsigned)x0) goto L1;
    { unsigned t8; double z8; if ((0xffffffffu) & 1u) { t8 = (unsigned)!((unsigned)((short)(unsigned)w0 > (signed char)4u) & p1); z8 = (double)(((unsigned)(0xc503b2a9u < (unsigned)(p0 && (unsigned)l0))) & 255u); } if ((0xffffffffu) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
        if ((unsigned)f0) goto done;
        w0 = w0 * 6364136223846793005ull + (0xffffffffu / ((((unsigned)d0 << ((unsigned)h1 & 31u)) ? (unsigned)s0 : m0) | 1u));
        *mp = (unsigned)((unsigned)(signed char)(unsigned)((int)i0 < (int)((unsigned)x0 % (0xffffffffu | 1u))) < 0xffffffffu);
        i1 = ((unsigned)(signed char)(0xbfffaaeeu << ((unsigned)h1 & 31u)) ^ (unsigned)(0x18f27b3au && i2)) & 15u;
        m0 ^= 0x10000u;
    }
    if (0x10000u) goto L3;
    if ((unsigned)(unsigned char)(unsigned)((unsigned)h0 || (unsigned)h0)) goto L0;
    if (i2) goto L3;
    do { if (--fuel == 0u) goto done;
        if (-(unsigned)((int)0x10000u >= (int)(unsigned)(g1 && g0))) break;
        while ((unsigned)(a0[u1 & 3u] == *mp)) { if (--fuel == 0u) goto done;
            if ((6u ^ (0xac35b671u + u0))) break;
            u1 += ~((unsigned)l0 >> ((0x4f2bbd48u + a0[i0 & 3u]) & 31u));
        }
        v0 = (r0.x << (u0 & 31u));
        if ((unsigned)((short)(unsigned)((unsigned)(x0 >> 70) && (unsigned)s0) > (signed char)(unsigned)s1)) break;
    } while (i0++ < 2u && garr[i1 & 7u]);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)((p2 ? 0xffffffffu : 0xa3d56917u) & fuel) & 1023u);
    if (fuel < 8u) return 0x80000000u;
    *q0 = r0.y;
    do { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + u1;
    } while (i0++ < 2u && (i2 * (0x5d7cabf0u / (u3 | 1u))));
    while (i0++ < 2u && (unsigned)(0x7fffffffu == g0)) { if (--fuel == 0u) goto done;
        if ((unsigned)!((unsigned)c1 >> (0x7fffffffu & 31u))) {
            { unsigned t0; double z0; if (((unsigned)((int)p2 < (int)0x7fffffffu)) & 1u) { t0 = i0; z0 = (double)(((u1 % ((unsigned)(unsigned char)((unsigned)s1 + p1) | 1u))) & 255u); } if (((unsigned)((int)p2 < (int)0x7fffffffu)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                if (((g0 * u1) * *mp)) {
                    if (((unsigned)x0 % (*mp | 1u))) continue;
                    u3 += (unsigned)((int)(((unsigned)f0 & (unsigned)!(i0 % ((unsigned)c1 | 1u))) % (5u | 1u)) < (int)(unsigned)e0);
                    d0 = d0 * 0.5 + (double)((((unsigned)!(3u | 0x60c794e7u) - u3) & (unsigned)e0) & 1023u);
                    h1 = (unsigned short)(h1 + (unsigned)(v0 < (7u % ((unsigned)((int)(*mp - r0.x) >= (int)(unsigned)x0) | 1u))));
                    d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)l0 < (int)(unsigned)(w0 >> 29)) & 1023u);
                    f0 = f0 * 0.5f + (float)(v0 & 255u);
                } else {
                    if (((unsigned)s1 + 1u)) {
                        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((1u % (1u | 1u)) || a0[u1 & 3u]), (1u + (0x6a18d75bu ^ (unsigned)b0)), (3u / (0x7fffffffu | 1u))); }
                        break; (void)((0x442bea13u ? a0[i0 & 3u] : u0));
                        if (budget != 0u) { budget -= 1u; u2 = fn2(((0xffffffffu << (i1 & 31u)) - p0), (((unsigned)l0 % ((unsigned)s0 | 1u)) * m0), (8u << (8u & 31u))); }
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)s1, ((unsigned)(fuel && (unsigned)(w0 >> 29)) | i2), (u2 % (i0 | 1u))); }
                        if ((0xdc77ee89u % ((unsigned)s0 | 1u))) break;
                    }
                    for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        goto L0;
                        *q0 = p2;
                        break; (void)((u2 ^ u0));
                        *q0 = ~(unsigned)((short)0xba8b95d0u > (signed char)((unsigned)c1 / ((g0 | 1u) | 1u)));
                        r0.y ^= v0;
                        *q0 = u3;
                    }
                    f0 = f0 * 0.5f + (float)(((unsigned)((u2 * 5u) < (unsigned)h0) - ~(a0[u1 & 3u] | (unsigned)c1)) & 255u);
                    continue; (void)(garr[u2 & 7u]);
                }
                garr[(unsigned)(5u == 8u) & 7u] = (unsigned)(((unsigned)b0 + ((unsigned)s0 << (0x807d992u & 31u))) && (a0[u1 & 3u] / (5u | 1u)));
                c0 = (unsigned char)-(unsigned)((short)r0.x > (signed char)garr[i1 & 7u]);
                if (*mp) goto L3;
            }
            r0.x = (unsigned)(((unsigned)s1 / ((unsigned)l0 | 1u)) < ((unsigned)s1 & i1));
        } else {
            c0 = (unsigned char)(unsigned)((u0 / ((unsigned)h0 | 1u)) < (unsigned)w0);
            L0: if (--fuel == 0u) goto done;
        }
    }
    for (;;) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn3(garr[i1 & 7u], (unsigned)((unsigned)c1 == (unsigned)s1), r0.y); }
        u0 ^= ((unsigned)((unsigned)((int)v0 >= (int)0x7fffffffu) && (unsigned)x0) - 6u);
        if ((4u / ((a0[i0 & 3u] ^ (unsigned)(x0 >> 70)) | 1u))) break;
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(6u == (unsigned)(w0 >> 29))) {
            i2 = (unsigned)(((*mp ^ p2) & (unsigned)s1) < (garr[u2 & 7u] % ((unsigned)(x0 >> 70) | 1u))) & 15u;
            break; (void)((unsigned)((int)0x78df5817u < (int)a0[i0 & 3u]));
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 = (v0 + 1u);
                q0 = &garr[(unsigned)((unsigned)(w0 >> 29) < (unsigned)((0x2967a751u ^ 0x76776ed0u) || (unsigned)(unsigned char)((unsigned)w0 % (1u | 1u)))) & 7u];
                l0 = (long)((unsigned long)l0 + (unsigned)!((unsigned)((short)(i1 % ((unsigned)e0 | 1u)) > (signed char)4u) * (u3 % ((unsigned)b0 | 1u))));
                if (budget != 0u) { budget -= 1u; u1 = fn3(7u, (unsigned)s1, 0xdbcc8365u); }
                r0.x = (v0 ? *q0 : (unsigned)x0);
                if (9u) goto L4;
            }
            g0 = 0xbbe4b30eu;
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn3(u3, (unsigned)e0, ((a0[u1 & 3u] * u2) % ((unsigned)c1 | 1u))); }
            u0 = u0 * 0x9e3779b1u + r0.x;
        }
        if ((unsigned)c0) {
            r0.y ^= ((unsigned)((int)p1 < (int)0xce9b78bu) ? 0xffffffffu : (unsigned)(u3 < r0.x));
            { unsigned t1; double z1; if ((((u1 & 0xf6a1dcc3u) ^ 4u)) & 1u) { t1 = ((unsigned)w0 << ((fuel & (unsigned)(w0 >> 29)) & 31u)); z1 = (double)(((unsigned)(g1 == (unsigned)s0)) & 255u); } if ((((u1 & 0xf6a1dcc3u) ^ 4u)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                q0 = &garr[(unsigned)((short)(u3 << ((unsigned)d0 & 31u)) > (signed char)0xffffffffu) & 7u];
            }
            s0 = (int)((0xa5daa52eu | (unsigned)c1) + (unsigned)((p0 % ((unsigned)f0 | 1u)) == 0x10000u));
            r0.x = (((unsigned)h0 << (*mp & 31u)) / ((unsigned)c0 | 1u));
            g0 = (unsigned)h0;
        } else {
            while (i1++ < 6u && (unsigned)w0) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (unsigned)b0;
                g0 = (unsigned)(unsigned char)(0xafa91060u % (((unsigned)c1 ? 8u : -((unsigned)(w0 >> 29) + 0xffffffffu)) | 1u));
            }
            i2 = (0xe765fe52u * 0xdb6f0e85u) & 15u;
            if ((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)(m0 || u0))) goto L0;
            while (i1++ < 6u && (1u + 5u)) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + i0);
                if ((p2 % (((unsigned)h1 & p1) | 1u))) goto L1;
            }
        }
        garr[u3 & 7u] = (unsigned)(g1 && (unsigned)(u1 || 0x7fb5af1du));
    }
    if (g0) goto L0;
    c1 = (signed char)0x5ecf610bu;
    s0 = (int)(unsigned)!(0x10000u >> ((unsigned)w0 & 31u));
    f0 = f0 * 0.5f + (float)((unsigned)e0 & 255u);
    b0 = (unsigned)((int)((unsigned)h0 << (g1 & 31u)) >= (int)(unsigned)(x0 >> 70)) != 0u;
    if (fuel < 8u) return (unsigned)!(unsigned)((unsigned)((int)((unsigned)((short)u3 > (signed char)0x171c86c5u) * (unsigned)s1) < (int)r0.x) < (unsigned)c0);
    *mp = ((unsigned)s1 | (g0 * 0x98e165b7u));
    g1 += p2;
    if (budget != 0u) { budget -= 1u; u2 = fn0((r0.x >> (m0 & 31u)), (unsigned)!(unsigned)((short)(unsigned)h0 > (signed char)4u), *q0); }
    if ((3u ? p0 : g0)) {
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((5u ^ u3) & 7u) {
                c0 = (unsigned char)((0x4c9fbc2fu ? g0 : 0x10000u) - a0[i0 & 3u]);
                g0 = ((unsigned)((short)7u > (signed char)i0) ^ garr[u2 & 7u]);
            }
            break; (void)((unsigned)b0);
            if ((unsigned)(((unsigned)x0 & (unsigned)f0) < p2)) continue;
            l0 = (long)((unsigned long)l0 + fuel);
        }
        if ((u2 >> (u3 & 31u))) {
            i0 = (unsigned)((*mp << (5u & 31u)) || (0x7fffffffu | 0xffffffffu)) & 15u;
            if (0x80000000u) {
                if ((unsigned)!((unsigned)b0 - (unsigned)h0)) {
                    L1: if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (v0 & (unsigned)((((unsigned)w0 - 6u) * (unsigned)s1) && u0)));
                    g0 = (-(unsigned)((int)5u < (int)(unsigned)c1) - (unsigned)(p1 == u3));
                    m0 ^= (unsigned)(p1 < r0.y);
                    m0 ^= 0x80000000u;
                    L2: if (--fuel == 0u) goto done;
                } else {
                    w0 = w0 * 6364136223846793005ull + 5u;
                }
                u2 = 9u;
                L3: if (--fuel == 0u) goto done;
                { unsigned t2; double z2; if ((r0.x) & 1u) { t2 = (unsigned)(1u && u1); z2 = (double)(((v0 % (0xee9f0445u | 1u))) & 255u); } if ((r0.x) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    if ((unsigned)(r0.x < 0x163b041cu)) goto L0;
                    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)(unsigned char)(unsigned)((4u + u2) || 0xaaba80a8u)) continue;
                        a0[2u & 3u] = (unsigned)((short)(unsigned)(-((unsigned)(x0 >> 70) * 0x5f834a1fu) && (unsigned)((short)r0.y > (signed char)p1)) > (signed char)u1);
                        { unsigned t3; double z3; if (((v0 | 7u)) & 1u) { t3 = (unsigned)((unsigned)(x0 >> 70) && (unsigned)((unsigned)h1 < (unsigned)(w0 >> 29))); z3 = (double)(((m0 - (i1 & i0))) & 255u); } if (((v0 | 7u)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(u2 < (p1 & u3)), ~(unsigned)((unsigned)h1 < (a0[u1 & 3u] / (0x8c76c0b6u | 1u))), (unsigned)((p0 + (unsigned)x0) < 0x80000000u)); }
                            f0 = f0 * 0.5f + (float)((r0.y - (0x10000u & (unsigned)((short)r0.x > (signed char)0x10000u))) & 255u);
                            w0 ^= (unsigned long long)((unsigned)s1 - u2) << ((unsigned)!((unsigned)!((unsigned)f0 + (unsigned)w0) & u2) & 63u);
                            v0 = *mp;
                            if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)x0 & (unsigned)(x0 >> 70)), (unsigned)(p2 == 0x50caaa82u), (p0 ^ a0[u1 & 3u])); }
                            u3 = 0x7fffffffu;
                        }
                    }
                    x0 = x0 * 0x100000001b3ull + ((unsigned)(unsigned char)(unsigned)((unsigned)w0 == g0) * ((unsigned)l0 * (unsigned)w0));
                    L4: if (--fuel == 0u) goto done;
                    if ((p2 + (unsigned)c1)) goto L2;
                }
                while (i0++ < 4u && ((8u & garr[u2 & 7u]) >> (p2 & 31u))) { if (--fuel == 0u) goto done;
                    b0 = ((unsigned)(0x10000u || (unsigned)l0) + u0) != 0u;
                    if (u1) {
                        if (budget != 0u) { budget -= 1u; u1 = fn3(garr[u2 & 7u], ((unsigned)(v0 || i1) ^ (unsigned)h1), (unsigned)e0); }
                        if (budget != 0u) { budget -= 1u; u2 = fn2(0x7fffffffu, 0x7fffffffu, (garr[u2 & 7u] ^ 0xffffffffu)); }
                        break; (void)((0xffffffffu & (unsigned)(x0 >> 70)));
                        if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)(signed char)(unsigned)((int)0u >= (int)u0), (0x8146ec39u + p0), (unsigned)((short)p1 > (signed char)(unsigned)w0)); }
                        if ((0x721d7988u ^ (unsigned)(signed char)(0x80000000u - garr[i1 & 7u]))) break;
                    }
                    u0 = (g1 - (unsigned)e0);
                }
                if ((unsigned)e0) goto done;
            } else {
                a0[(unsigned)s0 & 3u] = (0x10000u / ((unsigned)(unsigned char)(4u - (u0 << ((3u - *q0) & 31u))) | 1u));
                v0 = ((unsigned)b0 | a0[i0 & 3u]);
                a0[(0x10000u ^ 0x7fffffffu) & 3u] = (((unsigned)c1 ? u3 : u1) + g1);
                if (g0) goto L3;
            }
            e0 = e0 * 0.5L + (long double)((unsigned)(u3 && (unsigned)((~((unsigned)c0 % (0x80000000u | 1u)) * g1) && u2)) & 1023u);
            if (((unsigned)h0 << (0x7fffffffu & 31u))) goto L4;
            l0 = (long)((unsigned long)l0 + u1);
            *mp = g1;
        }
        *mp = m0;
        c0 = (unsigned char)(unsigned)(short)((0xf96ebc93u ^ (unsigned)(x0 >> 70)) + 0xffffffffu);
        m0 ^= ((0xffffffffu | i0) % ((9u ? g0 : (unsigned)h1) | 1u));
    } else {
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(0x80000000u < (0x10000u % (u2 | 1u))), ((5u * 0xd0f3223eu) * (unsigned)s0), ((unsigned)w0 % (8u | 1u))); }
        switch (((i2 * p2) + 0xce70c282u) & 7u) {
            u0 = u0 * 0x9e3779b1u + (unsigned)((fuel % (u0 | 1u)) == (unsigned)((int)0x10000u < (int)p1));
            case 6u: ;
            if (budget != 0u) { budget -= 1u; u0 = fn2((a0[u1 & 3u] * p0), (unsigned)(unsigned char)(0xffffffffu ^ 0xffffffffu), *q0); }
            { unsigned t4; double z4; if ((i2) & 1u) { t4 = 0x324829abu; z4 = (double)((((unsigned)f0 & (unsigned)(u0 == a0[i0 & 3u]))) & 255u); } if ((i2) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                q0 = &garr[(unsigned)((unsigned)(u0 < (unsigned)(short)((unsigned)h0 & (unsigned)h1)) == (unsigned)!(unsigned)((short)g1 > (signed char)(unsigned)l0)) & 7u];
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)i0 < (int)9u);
                u1 ^= (g1 << (fuel & 31u));
            }
            goto L2;
            { unsigned t5; double z5; if ((0xffffffffu) & 1u) { t5 = v0; z5 = (double)((u2) & 255u); } if ((0xffffffffu) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                i0 = (*mp | (fuel + 0x7fffffffu)) & 15u;
                if ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)e0)) {
                    if (budget != 0u) { budget -= 1u; u2 = fn2((u3 ^ (unsigned)((unsigned)s1 || i2)), (unsigned)((int)u1 < (int)(unsigned)(w0 >> 29)), u0); }
                    do { if (--fuel == 0u) goto done;
                        q0 = &garr[(unsigned)((int)r0.x < (int)8u) & 7u];
                        c1 = (signed char)(0xffffffffu >> (-(0xffffffffu | (unsigned)l0) & 31u));
                        case 3u: ;
                        if (0xe7490b90u) goto done;
                        i0 = ((((unsigned)c1 * (i0 | (unsigned)x0)) & 5u) >> (0x75626b83u & 31u)) & 15u;
                        case 4u: ;
                    } while (i0++ < 5u && (unsigned)((v0 % (garr[i1 & 7u] | 1u)) < g0));
                    l0 = (long)((unsigned long)l0 + (unsigned)((short)0xdc43bc4cu > (signed char)(p0 | p0)));
                } else {
                    c1 = (signed char)(unsigned)((unsigned)h1 < ~(garr[i1 & 7u] ^ ((unsigned)d0 * g0)));
                    if (garr[i1 & 7u]) break;
                    for (;;) { if (--fuel == 0u) goto done;
                        case 0u: ;
                        u0 = u0 * 0x9e3779b1u + (i1 ? (unsigned)s0 : (0x43e9e0e7u - 3u));
                        if ((unsigned)((unsigned)(v0 < (unsigned)c1) || (unsigned)h0)) continue;
                        if ((unsigned)!(*mp ^ *mp)) break;
                    }
                    s0 = (int)i0;
                }
                while (i0++ < 6u && (2u % ((unsigned)((int)(unsigned)h1 >= (int)0xffffffffu) | 1u))) { if (--fuel == 0u) goto done;
                    default: ;
                    g0 = (unsigned)f0;
                    r0.y ^= fuel;
                    f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)s0 * ~(unsigned)((int)i2 >= (int)1u)) < u2) & 255u);
                    if (g0) goto L2;
                }
            }
        }
        e0 = e0 * 0.5L + (long double)((((((unsigned)e0 << (0x15533b27u & 31u)) >> (u0 & 31u)) ^ g1) >> ((unsigned)h0 & 31u)) & 1023u);
        goto L0;
    }
    i2 = (u2 + (unsigned)w0) & 15u;
    a0[(unsigned)!(unsigned)(u1 || (unsigned)c0) & 3u] = 2u;
    *mp = p0;
    switch ((g0 / ((unsigned)(short)((unsigned)(x0 >> 70) & u2) | 1u)) & 7u) {
        break; (void)(0x80000000u);
        if ((unsigned)d0) {
            h0 = (short)(unsigned)e0;
            m0 ^= (v0 << (((unsigned)(x0 >> 70) / ((unsigned)d0 | 1u)) & 31u));
            *mp = (u3 & u2);
            s1 = (int)((unsigned)s1 + (*mp / ((g1 & 8u) | 1u)));
        }
        { unsigned t6; double z6; if ((i2) & 1u) { t6 = (unsigned)f0; z6 = (double)(((0x7fffffffu ^ (unsigned)(garr[i1 & 7u] == (unsigned)(w0 >> 29)))) & 255u); } if ((i2) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
            if ((unsigned)((short)r0.x > (signed char)((unsigned)(w0 >> 29) * garr[u2 & 7u]))) break;
        }
        goto L1;
    }
    goto L2;
    if ((i1 << (3u & 31u))) {
        s0 = (int)(unsigned)((unsigned)h0 < r0.y);
        g0 = (unsigned)((short)3u > (signed char)0xbeae8fb0u);
        if (i0) goto L4;
        *mp = (garr[u2 & 7u] % (((unsigned)s0 * 0x10000u) | 1u));
        if (0x7fffffffu) {
            *q0 = *q0;
            switch ((a0[u1 & 3u] & (unsigned)(x0 >> 70)) & 7u) {
                c1 = (signed char)(garr[u2 & 7u] ^ (unsigned)((short)(unsigned)((int)0xdf5802f8u >= (int)garr[i1 & 7u]) > (signed char)2u));
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((unsigned)h1 && 8u), g0, (i0 / (garr[i1 & 7u] | 1u))); }
                u1 ^= (unsigned)((int)(unsigned)(*q0 || a0[u1 & 3u]) >= (int)(0xd05b42d4u - r0.x));
                break; (void)((unsigned)(0xfa5dd43au == a0[u1 & 3u]));
                if ((unsigned)(x0 >> 70)) break;
                i1 = ((unsigned)l0 >> ((unsigned)((int)(unsigned)l0 >= (int)(unsigned)((int)m0 < (int)m0)) & 31u)) & 15u;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn3((((unsigned)s0 & (unsigned)(w0 >> 29)) & (unsigned)s0), 0x80000000u, ((unsigned)d0 ? 0xffffffffu : 8u)); }
            *q0 = (unsigned)(garr[i1 & 7u] || (unsigned)(v0 < (i1 % ((unsigned)((int)i1 >= (int)u3) | 1u))));
            a0[(unsigned)(short)(unsigned)((unsigned)c1 || (unsigned)b0) & 3u] = ((u0 | p1) / ((u2 & g0) | 1u));
        } else {
            if (~(unsigned)(7u && g1)) goto L3;
        }
        goto L1;
    }
    u0 += (unsigned)(short)(unsigned)((int)(7u ? 0xb53897dfu : (unsigned)b0) < (int)(p2 & a0[u1 & 3u]));
    if ((p0 + (p0 % ((unsigned)e0 | 1u)))) goto L0;
    goto L1;
    if (((unsigned)((int)0x80000000u < (int)v0) | (unsigned)s0)) {
        if ((unsigned)!(unsigned)(fuel < 6u)) goto L4;
    } else {
        if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(unsigned char)(unsigned)(((unsigned)s1 % (0x37b18b18u | 1u)) || 0u), (unsigned)((int)0xa82ac9ccu >= (int)0xd0cc5037u), ((unsigned)((int)fuel >= (int)(unsigned)b0) & m0)); }
        for (;;) { if (--fuel == 0u) goto done;
            if (p2) break;
            if ((unsigned)(signed char)(unsigned)((int)(unsigned)c0 < (int)i0)) break;
            e0 = e0 * 0.5L + (long double)((fuel << (0x25614577u & 31u)) & 1023u);
            w0 ^= (unsigned long long)5u << ((((unsigned)s1 / (0x80000000u | 1u)) - 0xa542205u) & 63u);
            i0 = (5u + ((0x8960d569u ^ 5u) | v0)) & 15u;
            u2 ^= (unsigned)b0;
        }
    }
    if (0x10000u) goto L3;
    switch (0x80000000u & 7u) {
        x0 = x0 * 0x100000001b3ull + (unsigned)(short)(unsigned)((unsigned)((int)i0 >= (int)(unsigned)(x0 >> 70)) < r0.x);
        goto done;
        case 7u: ;
        do { if (--fuel == 0u) goto done;
            break; (void)(g0);
            u3 += ((0x99b9f8b5u >> (((unsigned)b0 * (unsigned)d0) & 31u)) + g1);
            case 4u: ;
        } while (i0++ < 4u && 6u);
    }
    s1 = (int)((unsigned)s1 + (unsigned)!(((unsigned)c0 + u2) % ((unsigned)(signed char)(u1 % ((unsigned)(*mp < (unsigned)x0) | 1u)) | 1u)));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)((short)p1 > (signed char)(unsigned)(w0 >> 29)))) break;
    }
    if ((unsigned)h1) goto L4;
    if (((unsigned)b0 + (unsigned)(w0 >> 29))) {
        if ((0xffffffffu & (unsigned)c1)) {
            f0 = f0 * 0.5f + (float)(((unsigned)((int)g1 < (int)0x3f823a1du) - ((unsigned)l0 ^ 1u)) & 255u);
            switch ((unsigned)(unsigned char)(a0[i0 & 3u] >> (a0[i0 & 3u] & 31u)) & 7u) {
                u2 = u2 * 0x9e3779b1u + (unsigned)((int)0x7fffffffu < (int)garr[u2 & 7u]);
                case 6u: ;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn3(((8u | g1) << ((unsigned)d0 & 31u)), 0xffffffffu, a0[u1 & 3u]); }
                } while (i0++ < 5u && -(unsigned)((unsigned)(unsigned char)(unsigned)(0x7fffffffu && 0x80000000u) && (unsigned)b0));
                goto L3;
                g0 = v0;
            }
            w0 ^= (unsigned long long)r0.x << (((unsigned)(unsigned char)(0x7fffffffu >> (0xffffffffu & 31u)) % (u0 | 1u)) & 63u);
            if ((unsigned)(u1 && (unsigned)((unsigned)x0 == i0))) {
                if (0xef7c1e58u) goto L2;
                if (((unsigned)e0 - 0x80000000u)) goto done;
                if ((1u + 7u)) goto L2;
                if (budget != 0u) { budget -= 1u; u3 = fn3((i1 - (unsigned)(signed char)((unsigned)s1 / (0x10000u | 1u))), 0x7fffffffu, (fuel + (p0 % ((unsigned)s1 | 1u)))); }
                if (budget != 0u) { budget -= 1u; u0 = fn2(i0, 0xe864a3bu, (unsigned)(i0 || (unsigned)b0)); }
                u2 = (unsigned)!((unsigned)(short)(0x10000u | (unsigned)((int)(unsigned)b0 < (int)0xa15d3222u)) << ((unsigned)s0 & 31u));
            } else {
                h0 = (short)(unsigned)(signed char)((unsigned)(x0 >> 70) - (unsigned)(signed char)(unsigned)((short)(a0[u1 & 3u] * garr[u2 & 7u]) > (signed char)(unsigned)((int)(unsigned)h1 >= (int)*q0)));
                d0 = d0 * 0.5 + (double)((0x6b89628eu * ((unsigned)c0 & fuel)) & 1023u);
            }
        }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)x0;
            i1 = (unsigned)(unsigned char)(unsigned)((int)0x70b888e1u >= (int)(unsigned)x0) & 15u;
        }
        u2 += (unsigned)((short)0x68f7f44eu > (signed char)((0x10000u % (0xcdd8c276u | 1u)) + (unsigned)((int)(unsigned)c0 >= (int)(unsigned)s1)));
    } else {
        if (budget != 0u) { budget -= 1u; u3 = fn2(0x80000000u, (unsigned)d0, (unsigned)((short)(unsigned)c1 > (signed char)(unsigned)((unsigned)h1 == g0))); }
    }
    q0 = &garr[(unsigned)((unsigned)(unsigned char)(unsigned)((short)0x7fffffffu > (signed char)(unsigned)(garr[u2 & 7u] || (unsigned)f0)) < (p2 >> ((unsigned)h0 & 31u))) & 7u];
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)s0 * (unsigned)h1));
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((p0 | r0.x)) continue;
            g0 = (u2 & i0);
            r0.x = (unsigned)(short)((unsigned)(x0 >> 70) & (unsigned)(a0[u1 & 3u] && 0xada14301u));
            g0 = u1;
            if (((unsigned)w0 | (unsigned)((unsigned)x0 == 0x549db806u))) {
                s1 = (int)((unsigned)s1 + (unsigned)(short)(unsigned)((int)(unsigned)(r0.y || (unsigned)c0) >= (int)p1));
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(((unsigned)(w0 >> 29) ^ (unsigned)l0) && 0x8397d488u), fuel, ((unsigned)(p0 < (unsigned)s1) << (i1 & 31u))); }
            } else {
                goto done;
            }
            goto done;
        }
    }
    v0 = ((unsigned)(p1 || (u1 % ((unsigned)(w0 >> 29) | 1u))) / (g0 | 1u));
    for (;;) { if (--fuel == 0u) goto done;
        r0.x = (unsigned)((4u / (0xeb84ba90u | 1u)) < (unsigned)(unsigned char)(unsigned)((int)g1 < (int)1u));
        g0 = (unsigned)((int)(unsigned)c0 < (int)(unsigned)x0);
    }
    if ((unsigned)((int)((unsigned)(w0 >> 29) ^ r0.x) < (int)(unsigned)w0)) goto done;
    if ((garr[u2 & 7u] ? (unsigned)s0 : 0u)) goto L4;
    if (7u) goto L2;
    if (*q0) {
        garr[((unsigned)x0 + *q0) & 7u] = (v0 | m0);
    } else {
        do { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                goto L0;
                if ((0xffffffffu & (unsigned)(8u < i2))) goto L2;
                while ((unsigned)((int)p2 < (int)(unsigned)d0)) { if (--fuel == 0u) goto done;
                    if (5u) break;
                    u3 = ((unsigned)h0 / ((p1 | 0x80000000u) | 1u));
                    if ((unsigned)((unsigned)d0 == 0x895c552au)) break;
                    c1 = (signed char)(*q0 ? (unsigned)c0 : (0x7375157fu + garr[i1 & 7u]));
                }
                if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)((unsigned)c1 && g0), -(((unsigned)e0 / ((unsigned)l0 | 1u)) + v0), 0x80000000u); }
                h0 = (short)(unsigned)((i1 >> (u0 & 31u)) && (unsigned)c0);
                if (fuel < 8u) return (unsigned)(u1 && (unsigned)l0);
            }
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((fuel | u3)) continue;
                if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)c0 / (((unsigned)h1 | u2) | 1u)), 0x7fffffffu, (4u - fuel)); }
                if ((unsigned)(0xcf3f0892u || (unsigned)d0)) break;
                h0 = (short)(unsigned)((int)u2 >= (int)g0);
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)((int)*mp >= (int)r0.y))) break;
                    if (((0u & 0xbdf74274u) + 4u)) break;
                    r0.x = (unsigned)(i1 < ((0xdcb3b986u * g1) - (unsigned)b0));
                    if (((unsigned)c1 - (unsigned)((int)u3 < (int)i1))) {
                        if ((unsigned)((int)*mp >= (int)u2)) break;
                        switch ((unsigned)(unsigned char)((p1 - 2u) * i0) & 7u) {
                            if ((unsigned)(short)((unsigned)(signed char)(fuel ^ a0[i0 & 3u]) % (6u | 1u))) break;
                            c0 = (unsigned char)(unsigned)(p1 == (unsigned)((a0[i0 & 3u] - 0x6235fcdu) && (unsigned)w0));
                            case 6u: ;
                            case 7u: ;
                            if (budget != 0u) { budget -= 1u; u1 = fn2(0x62ca7951u, (p1 % (*mp | 1u)), g0); }
                            *q0 += garr[i1 & 7u];
                        }
                        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(m0 || 5u), (unsigned)e0, -(unsigned)(i0 || 0x80000000u)); }
                        }
                    } else {
                        if (garr[u2 & 7u]) {
                            l0 = (long)((unsigned long)l0 + ~(unsigned)(((0xffffffffu + (unsigned)l0) / (g0 | 1u)) || u3));
                            if ((r0.x * (unsigned)b0)) goto L4;
                            if (budget != 0u) { budget -= 1u; u2 = fn0(r0.y, ((unsigned)w0 | (unsigned)s0), (unsigned)(u1 && (0x10000u % ((unsigned)h1 | 1u)))); }
                            garr[i1 & 7u] = (unsigned)(p0 || (unsigned)(signed char)(0u * garr[i1 & 7u]));
                            g0 = (g0 >> (u0 & 31u));
                            if (budget != 0u) { budget -= 1u; u2 = fn2(0u, u2, ((unsigned)h1 & (unsigned)h0)); }
                        }
                        for (;;) { if (--fuel == 0u) goto done;
                            *mp = i2;
                            if (budget != 0u) { budget -= 1u; u3 = fn0(2u, ((4u * *q0) % (1u | 1u)), (unsigned)(((unsigned)(x0 >> 70) >> ((unsigned)l0 & 31u)) < m0)); }
                            s0 = (int)((unsigned)b0 * fuel);
                            if ((unsigned)(i0 < ~((unsigned)c1 & g0))) goto done;
                            g0 = (unsigned)((short)p2 > (signed char)((unsigned)(w0 >> 29) % ((a0[u1 & 3u] * u3) | 1u)));
                        }
                    }
                    l0 = (long)((unsigned long)l0 + 8u);
                }
                e0 = e0 * 0.5L + (long double)(u0 & 1023u);
            }
            if (u3 == 7u) return ~(unsigned)((unsigned)(0x990d753fu == 4u) && r0.x);
            break; (void)((unsigned)(0xffffffffu && (4u + m0)));
            if (0x14b10101u) break;
            if ((unsigned)((short)(unsigned)x0 > (signed char)0xffffffffu)) continue;
        } while (i0++ < 3u && 0x10000u);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 6u, 0x4a2d6193u, 0x9d75d124u },
        { 8u, 0xe29d6ee9u, 0x2214091au },
        { 8u, 0x1e4a3006u, 0xcc990eaeu },
        { 9u, 0x7e27132fu, 0x9c28b8dau },
        { 5u, 0xd307f0b0u, 0xa7a1595du },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
