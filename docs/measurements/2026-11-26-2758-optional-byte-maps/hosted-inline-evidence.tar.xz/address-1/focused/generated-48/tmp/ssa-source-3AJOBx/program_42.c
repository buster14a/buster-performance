// test-ssa-source's program of seed 134000444 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x66a43d05u, g1 = 0x25ab2960u;
static unsigned garr[8] = { 0xdf34f4acu, 0x98a96481u, 0x85455f06u, 0x5843c9d2u, 0xd96cadbau, 0xe89426c7u, 0x2861340du, 0xa8cc8519u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (8u) goto L3;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0x80000000u) break;
        if (((unsigned)(g1 == u3) / ((unsigned)(w0 >> 29) | 1u))) {
            i0 = (r0.x >> ((unsigned)((unsigned)w0 && (unsigned)l0) & 31u)) & 15u;
            b0 = (unsigned)((int)(r0.x + 0xf390d931u) >= (int)(p0 << (0xd02f88b8u & 31u))) != 0u;
            switch (0x80000000u & 7u) {
                L0: if (--fuel == 0u) goto done;
                goto L3;
            }
            do { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                L2: if (--fuel == 0u) goto done;
                break; (void)((unsigned)!((4u % ((unsigned)x0 | 1u)) & (unsigned)l0));
                if (((unsigned)c1 << ((unsigned)w0 & 31u))) goto L4;
            } while (i1++ < 7u && (unsigned)!(0x10000u | m0));
            while (i1++ < 4u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                if (p0) {
                    break; (void)(((unsigned)w0 ^ (unsigned)(unsigned char)(p0 - (unsigned)(w0 >> 29))));
                } else {
                    if ((0xffffffffu ^ (p1 & (unsigned)(x0 >> 70)))) continue;
                    if ((unsigned)((unsigned)c1 == (unsigned)(w0 >> 29))) break;
                    s1 = (int)((unsigned)s1 + (unsigned)((int)u2 < (int)(unsigned)(0x7fffffffu || 0xbd39334bu)));
                }
                r0.y ^= (unsigned)(unsigned char)(a0[i0 & 3u] - i2);
                s0 = (int)((unsigned)(0x7fffffffu && *mp) | 0xffffffffu);
            }
        } else {
            { unsigned t0; double z0; if ((m0) & 1u) { t0 = (unsigned)c1; z0 = (double)(((unsigned)s0) & 255u); } if ((m0) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                i0 = ((g0 / ((unsigned)w0 | 1u)) / ((unsigned)(unsigned char)(v0 % (5u | 1u)) | 1u)) & 15u;
                w0 ^= (unsigned long long)*mp << ((unsigned)(short)(8u << (((unsigned)(0x7365530u < 0xffffffffu) + g1) & 31u)) & 63u);
                if (6u) break;
            }
            { unsigned t1; double z1; if ((((unsigned)(0x4155736cu || 0x80000000u) / (u2 | 1u))) & 1u) { t1 = 0x80000000u; z1 = (double)(((unsigned)((int)r0.y < (int)0x10000u)) & 255u); } if ((((unsigned)(0x4155736cu || 0x80000000u) / (u2 | 1u))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                if ((unsigned)((int)(unsigned)!(0x3708ddd6u + 0x31675b32u) >= (int)g0)) break;
                if ((unsigned)((short)0xffffffffu > (signed char)0xf4effb8fu)) break;
                q0 = &garr[(unsigned)((int)g0 >= (int)((unsigned)l0 | (unsigned)(unsigned char)((unsigned)h0 & i2))) & 7u];
                b0 = (unsigned)c0 != 0u;
                for (;;) { if (--fuel == 0u) goto done;
                    if (v0) goto done;
                    if (u0) goto L2;
                    L3: if (--fuel == 0u) goto done;
                    u2 = ((unsigned)((0x10000u / ((unsigned)h0 | 1u)) || (unsigned)((short)0xae30d60du > (signed char)(unsigned)c0)) << (u1 & 31u));
                    u1 ^= (unsigned)((short)i0 > (signed char)(g1 * (*mp - m0)));
                }
                e0 = e0 * 0.5L + (long double)(8u & 1023u);
            }
            g1 += (0x10000u << ((a0[i0 & 3u] >> (4u & 31u)) & 31u));
            if (0xe88d0f62u) goto done;
        }
    }
    s0 = (int)((unsigned)(short)(0x5be14f7fu % (g1 | 1u)) % ((unsigned)c1 | 1u));
    L4: if (--fuel == 0u) goto done;
    h0 = (short)((unsigned)((int)i0 >= (int)*q0) % ((unsigned)(((unsigned)b0 | (unsigned)c0) < u1) | 1u));
    if ((unsigned)((int)(unsigned)h1 < (int)fuel)) goto L1;
    if (r0.y) goto L2;
    s1 = (int)((unsigned)s1 + ((0x10000u & a0[i0 & 3u]) + u2));
    switch ((g0 * (unsigned)b0) & 7u) {
        { unsigned t2; double z2; if ((u2) & 1u) { t2 = (unsigned)((short)(unsigned)f0 > (signed char)(a0[i0 & 3u] & (unsigned)h0)); z2 = (double)((4u) & 255u); } if ((u2) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            w0 = w0 * 6364136223846793005ull + (unsigned)(short)((unsigned)((int)garr[i1 & 7u] < (int)i1) | ((unsigned)(signed char)(0x9e27cf41u * (unsigned)s0) - (unsigned)c1));
            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(-(0x78a6b843u ? (unsigned)c0 : 0xb36f7947u) || a0[u1 & 3u]) || (unsigned)x0));
            switch (0x80000000u & 7u) {
                a0[p0 & 3u] = 0x80000000u;
            }
            case 7u: ;
        }
        h1 = (unsigned short)(h1 + 3u);
        c0 = (unsigned char)((v0 << (i2 & 31u)) ? i0 : (unsigned)(short)(unsigned)(v0 < i1));
        s0 = (int)((unsigned)((0x561d5ca7u - 9u) == 0x630b3148u) * (unsigned)((unsigned)c0 == 0x3b830d17u));
        m0 ^= (unsigned)(i1 < (garr[i1 & 7u] | (unsigned)(signed char)((unsigned)b0 | (unsigned)c0)));
    }
    m0 ^= 9u;
    { unsigned t3; double z3; if ((u1) & 1u) { t3 = (5u % (u3 | 1u)); z3 = (double)(((unsigned)((i0 & p2) || 0xeedec350u)) & 255u); } if ((u1) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        if ((unsigned)(short)(0xe8242e75u + (unsigned)h1)) goto done;
        m0 ^= ((-(unsigned)((int)i0 >= (int)v0) - i1) | (unsigned)((int)garr[i1 & 7u] < (int)g0));
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)s1 < (int)(unsigned)(6u && a0[i0 & 3u]))) break;
            u3 = (unsigned)(short)(unsigned)((int)4u >= (int)(unsigned)((short)2u > (signed char)(unsigned)s1));
            break; (void)((4u / (0xffffffffu | 1u)));
            if (0x80000000u) break;
            for (;;) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    break; (void)((*q0 * (unsigned)((short)v0 > (signed char)(unsigned)s1)));
                    if ((unsigned)((short)5u > (signed char)(p0 << (0x80000000u & 31u)))) {
                        *q0 = (unsigned)((p0 % (g1 | 1u)) < (unsigned)((unsigned)l0 == g1));
                        if ((garr[i1 & 7u] ? (unsigned)f0 : g1)) break;
                        if ((unsigned)s0) break;
                        if ((p2 & ((unsigned)b0 ^ (unsigned)h1))) break;
                        g1 += ((unsigned)e0 & 3u);
                        if ((0x14c6f9a5u >> (u2 & 31u))) break;
                    } else {
                        if (((unsigned)((short)(unsigned)b0 > (signed char)r0.x) >> (garr[u2 & 7u] & 31u))) continue;
                    }
                    do { if (--fuel == 0u) goto done;
                        *mp = ((*mp / ((unsigned)(short)(unsigned)((m0 << ((unsigned)x0 & 31u)) || 0x207e5e89u) | 1u)) << (2u & 31u));
                        u0 = (unsigned)(v0 && (unsigned)(m0 < (unsigned)c0));
                        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                            *mp = -(0x7337ad07u >> ((0x10000u % (((p2 | v0) ^ (unsigned)b0) | 1u)) & 31u));
                            if (4u) break;
                            if (u3 == 7u) return (unsigned)((unsigned)((int)(unsigned)((unsigned)l0 || m0) < (int)(i2 & (unsigned)l0)) == i2);
                        }
                        g1 += (0u + u3);
                    } while (i0++ < 6u && (8u << (9u & 31u)));
                } while (i2++ < 3u && (0x10000u ^ 0xffffffffu));
                u3 = (unsigned)((int)(((unsigned)s0 + a0[u1 & 3u]) / (a0[u1 & 3u] | 1u)) >= (int)(unsigned)c1);
                l0 = (long)((unsigned long)l0 + (unsigned)(short)(r0.y / (0xffffffffu | 1u)));
                r0.y ^= (((unsigned)s0 % (0x33e58f97u | 1u)) - i0);
                switch (u0 & 7u) {
                    *q0 = ((unsigned)((unsigned)d0 < (unsigned)c0) + (unsigned)((u2 | 0x10000u) == 0x10000u));
                    case 7u: ;
                }
                u0 ^= m0;
            }
            switch ((unsigned)(unsigned char)(unsigned)(0x5ddb74d5u == a0[u1 & 3u]) & 7u) {
                b0 = (unsigned)((short)0x10000u > (signed char)((unsigned)(w0 >> 29) | (unsigned)s0)) != 0u;
                h0 = (short)(-((unsigned)(x0 >> 70) / ((unsigned)((short)(unsigned)f0 > (signed char)garr[u2 & 7u]) | 1u)) + ((unsigned)s0 % (garr[i1 & 7u] | 1u)));
                while ((unsigned)((int)0x3b373b69u < (int)p1)) { if (--fuel == 0u) goto done;
                    { unsigned t4; double z4; if ((u1) & 1u) { t4 = (unsigned)s1; z4 = (double)(((unsigned)c0) & 255u); } if ((u1) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                        { unsigned t5; double z5; if (((0xfd4125a8u >> (v0 & 31u))) & 1u) { t5 = ((unsigned)e0 + (unsigned)s1); z5 = (double)((a0[u1 & 3u]) & 255u); } if (((0xfd4125a8u >> (v0 & 31u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                            case 2u: ;
                            g0 = (garr[u2 & 7u] << ((((unsigned)((short)(unsigned)l0 > (signed char)p0) & v0) & (unsigned)x0) & 31u));
                            case 4u: ;
                        }
                        *q0 = 0x10000u;
                    }
                    case 1u: ;
                    *q0 += (g1 * (unsigned)h0);
                    default: ;
                }
                s0 = (int)((unsigned)((int)p1 >= (int)2u) % (8u | 1u));
            }
        }
        goto L0;
        goto L0;
        { unsigned t6; double z6; if (((unsigned)(u0 && p2)) & 1u) { t6 = 0x10000u; z6 = (double)((~((unsigned)s1 >> ((v0 << (0x80000000u & 31u)) & 31u))) & 255u); } if (((unsigned)(u0 && p2)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
            u0 = u0 * 0x9e3779b1u + (unsigned)((a0[i0 & 3u] + (m0 % (u3 | 1u))) || (unsigned)((unsigned)(x0 >> 70) < (unsigned)d0));
            g1 += ((0xa6c8b7a3u ? r0.y : i0) << (0x80000000u & 31u));
            if (((unsigned)h1 & 0xcc13f5d6u)) goto L4;
            if (0x80000000u) goto L0;
            if ((unsigned)(0u == (i1 / (7u | 1u)))) goto L3;
        }
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)((unsigned)w0 ^ (garr[i1 & 7u] | ((u3 - (unsigned)l0) | (unsigned)h1)));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        g1 += i0;
        while ((0x80000000u | *mp)) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)(w0 >> 29);
        }
        continue; (void)((unsigned)(unsigned char)(unsigned)((int)i2 < (int)v0));
        w0 ^= (unsigned long long)((unsigned)f0 ^ 4u) << ((unsigned)!(g0 << ((p2 ? i2 : (unsigned)(x0 >> 70)) & 31u)) & 63u);
    }
    *mp = ((unsigned)(signed char)(p2 - i0) * (unsigned)((unsigned)(x0 >> 70) || i0));
    v0 = ~(a0[i0 & 3u] >> ((unsigned)((int)1u < (int)(0x80000000u % (0xffffffffu | 1u))) & 31u));
    if (u0) goto done;
    for (;;) { if (--fuel == 0u) goto done;
        break; (void)((u3 / (i2 | 1u)));
        do { if (--fuel == 0u) goto done;
            g0 = p0;
            if (0xcfbc7d3u) goto L1;
            if (u2) goto L4;
            s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(unsigned)((short)((unsigned)b0 ^ 0x10000u) > (signed char)*q0));
            if ((unsigned)(u2 || (unsigned)((int)a0[u1 & 3u] < (int)0x53a134beu))) {
                g0 = u0;
                { unsigned t7; double z7; if ((v0) & 1u) { t7 = (0xffffffffu * fuel); z7 = (double)(((unsigned)d0) & 255u); } if ((v0) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                    if ((unsigned)(short)(0xfd5fd0c1u << (g1 & 31u))) continue;
                    if (0x2d7eb945u) continue;
                    h1 = (unsigned short)(h1 + (unsigned)((int)m0 >= (int)((i1 ? (unsigned)c0 : 0x80000000u) >> (5u & 31u))));
                    if ((unsigned)((m0 << ((unsigned)h1 & 31u)) == garr[i1 & 7u])) break;
                }
            } else {
                *mp = u3;
                if ((0xffffffffu + 0xffffffffu)) break;
                if ((unsigned)((unsigned)(w0 >> 29) && (unsigned)w0)) {
                    if (((unsigned)((short)3u > (signed char)*q0) << (8u & 31u))) break;
                    break; (void)((i1 & (unsigned)(p2 && 1u)));
                    continue; (void)((unsigned)x0);
                }
            }
            for (;;) { if (--fuel == 0u) goto done;
                if (p0) break;
                g1 += ((2u & garr[i1 & 7u]) >> (p2 & 31u));
                *mp = (unsigned)(garr[u2 & 7u] == ((unsigned)h0 * 0xffffffffu));
            }
        } while (i1++ < 7u && (unsigned)((unsigned)h1 < 7u));
        { unsigned t8; double z8; if (((unsigned)(unsigned char)(i2 >> ((unsigned)l0 & 31u))) & 1u) { t8 = a0[u1 & 3u]; z8 = (double)((p2) & 255u); } if (((unsigned)(unsigned char)(i2 >> ((unsigned)l0 & 31u))) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
            if (((unsigned)x0 / (m0 | 1u))) break;
            if ((unsigned)h0) continue;
            while (i1++ < 2u && (unsigned)(short)(*mp ? 0xc4f9516eu : (unsigned)h1)) { if (--fuel == 0u) goto done;
                if ((unsigned)s1) goto L2;
                u1 ^= (unsigned)((u1 ? 0x261464e3u : (unsigned)s0) == u1);
            }
            s1 = (int)((unsigned)s1 + -((unsigned)((int)u0 >= (int)a0[i0 & 3u]) / ((garr[i1 & 7u] + u1) | 1u)));
            { unsigned t9; double z9; if (((unsigned)(0x5fcea7d6u == ((unsigned)c0 + a0[i0 & 3u]))) & 1u) { t9 = 0x10000u; z9 = (double)(((((unsigned)x0 ^ p1) - (unsigned)x0)) & 255u); } if (((unsigned)(0x5fcea7d6u == ((unsigned)c0 + a0[i0 & 3u]))) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                break; (void)((unsigned)((unsigned)l0 == p0));
                c1 = (signed char)(unsigned)((unsigned)(r0.x && a0[u1 & 3u]) || ((unsigned)e0 ^ g0));
                c1 = (signed char)(unsigned)(signed char)(unsigned)(0x3dd7b3bu && ((unsigned)(signed char)(u3 / ((unsigned)((int)8u < (int)0x10000u) | 1u)) >> (m0 & 31u)));
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (p2) break;
                }
                if ((0u * (0xa58c278au | (unsigned)s1))) break;
            }
        }
        { unsigned t10; double z10; if (((unsigned)((unsigned)b0 == ((unsigned)d0 >> (r0.x & 31u)))) & 1u) { t10 = (9u | 1u); z10 = (double)(((unsigned)h1) & 255u); } if (((unsigned)((unsigned)b0 == ((unsigned)d0 >> (r0.x & 31u)))) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
            if (v0) {
                break; (void)((unsigned)(short)(*mp ? garr[u2 & 7u] : 0x2ab0e22fu));
                break; (void)(((unsigned)((unsigned)b0 && 0x80000000u) % (8u | 1u)));
                l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)x0 >= (int)8u));
            }
            if ((unsigned)!(0x10000u | garr[u2 & 7u])) {
                goto L3;
                break; (void)(0x10000u);
            } else {
                do { if (--fuel == 0u) goto done;
                    v0 = g0;
                } while (i1++ < 6u && v0);
                if ((unsigned)w0) continue;
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)((a0[u1 & 3u] + (unsigned)c0));
                        *q0 += ((garr[u2 & 7u] << (i0 & 31u)) * 0x80000000u);
                        if (a0[i0 & 3u]) break;
                        w0 ^= (unsigned long long)(unsigned)!(r0.x >> (fuel & 31u)) << ((0x80000000u >> ((unsigned)(x0 >> 70) & 31u)) & 63u);
                        w0 ^= (unsigned long long)p0 << ((unsigned)(short)(0x10000u * (unsigned)((int)(unsigned)c1 >= (int)p2)) & 63u);
                    }
                    if (-(unsigned)(0x76659230u == 0x7fffffffu)) break;
                }
                s0 = (int)(unsigned)((int)(g0 - (unsigned)(0x3b147ac6u < (unsigned)s1)) < (int)0xd36dbab5u);
            }
            while (i1++ < 6u && (unsigned)(g1 == 3u)) { if (--fuel == 0u) goto done;
                if (((unsigned)((short)0x12158292u > (signed char)i2) << (0xb5d97b1eu & 31u))) break;
                if (i1) break;
            }
            r0.x = (unsigned)(signed char)((unsigned)((int)i1 >= (int)(unsigned)c1) & (unsigned)(fuel == (garr[i1 & 7u] | 0u)));
            if ((unsigned)(short)(3u ^ (unsigned)b0)) goto done;
        }
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            goto L0;
            q0 = &garr[u2 & 7u];
            if ((unsigned)(0x90467563u < g1)) goto L1;
            if ((unsigned)(0xc4b7cacu || (unsigned)(signed char)(unsigned)((short)0x8db5496bu > (signed char)3u))) break;
        }
        if ((u0 + (unsigned)(short)((unsigned)h1 * (unsigned)c0))) break;
    }
    while (i0++ < 4u && (unsigned)(g1 || -(g0 + 0x80000000u))) { if (--fuel == 0u) goto done;
        q0 = &garr[((unsigned)((short)(r0.y & 0xffffffffu) > (signed char)u0) % ((unsigned)d0 | 1u)) & 7u];
        if ((unsigned)((unsigned)(short)(unsigned)(a0[i0 & 3u] < 0x76e84f05u) < garr[i1 & 7u])) {
            *q0 = (unsigned)((int)0x4a50b397u < (int)p1);
            if ((unsigned)((0xffffffffu << (9u & 31u)) < (unsigned)(w0 >> 29))) break;
            if (garr[u2 & 7u]) {
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    q0 = &garr[((((unsigned)b0 << (4u & 31u)) % ((unsigned)(x0 >> 70) | 1u)) >> (0xffffffffu & 31u)) & 7u];
                    *q0 = ((unsigned)f0 | (unsigned)(((0x53827a48u | g0) * g1) == 0x1ae5032cu));
                }
            } else {
                e0 = e0 * 0.5L + (long double)(((p0 ^ r0.x) / (0x5c6acfffu | 1u)) & 1023u);
            }
        }
        l0 = (long)((unsigned long)l0 + 0x7e87e685u);
        { unsigned t11; double z11; if (((unsigned)((int)0x7fffffffu < (int)(unsigned)(w0 >> 29))) & 1u) { t11 = (unsigned)s0; z11 = (double)(((v0 >> (u2 & 31u))) & 255u); } if (((unsigned)((int)0x7fffffffu < (int)(unsigned)(w0 >> 29))) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
            break; (void)(((unsigned)w0 ^ (*mp * g0)));
            if (*mp) break;
            if (((unsigned)h1 ? i0 : 4u)) break;
            if ((2u >> (0x6c74f78eu & 31u))) {
                while (i1++ < 3u && (u1 / ((v0 | (unsigned)s1) | 1u))) { if (--fuel == 0u) goto done;
                    { unsigned t12; double z12; if ((-(unsigned)((unsigned)(a0[i0 & 3u] < 0xee785ad4u) < 4u)) & 1u) { t12 = (r0.y << ((unsigned)(w0 >> 29) & 31u)); z12 = (double)(((p0 ^ garr[u2 & 7u])) & 255u); } if ((-(unsigned)((unsigned)(a0[i0 & 3u] < 0xee785ad4u) < 4u)) & 1u) { u1 += t12; d0 = d0 * 0.5 + z12; }
                        if ((g0 | (unsigned)(r0.x < r0.y))) goto done;
                        h1 = (unsigned short)(h1 + ((unsigned)(x0 >> 70) * (unsigned)((int)(unsigned)(signed char)(unsigned)((int)i2 >= (int)u0) < (int)r0.x)));
                        if ((unsigned)(r0.x || (0x10000u ^ *q0))) {
                            if ((unsigned)((r0.x / ((unsigned)b0 | 1u)) || r0.y)) break;
                            if (0u) break;
                            *q0 += (g1 - (unsigned)(signed char)(5u | *q0));
                            u3 = ((unsigned)s0 % ((unsigned)((int)0x7fffffffu >= (int)fuel) | 1u));
                            w0 ^= (unsigned long long)0x10000u << (r0.y & 63u);
                            if (((unsigned)w0 * r0.x)) break;
                        } else {
                            if (0x10000u) break;
                            c0 = (unsigned char)(unsigned)!(p1 / ((0x80000000u | 0xffffffffu) | 1u));
                        }
                        if (0xffffffffu) break;
                        m0 ^= (unsigned)((short)(0u + (p0 | r0.x)) > (signed char)(unsigned)(0xc1d6eeb6u && garr[u2 & 7u]));
                    }
                }
            }
        }
    }
    d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)(0x10000u && (unsigned)l0) ? (unsigned)c1 : *mp) && (unsigned)c0) & 1023u);
    switch (~((i1 * garr[u2 & 7u]) % (m0 | 1u)) & 7u) {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 5u: ;
        }
    }
    { unsigned t13; double z13; if ((((unsigned)(4u < u0) >> (0xbc2c275fu & 31u))) & 1u) { t13 = (unsigned)(signed char)(i2 / ((unsigned)f0 | 1u)); z13 = (double)(((unsigned)(unsigned char)(unsigned)((int)g1 < (int)(unsigned)((int)0xffffffffu < (int)0x3c580319u))) & 255u); } if ((((unsigned)(4u < u0) >> (0xbc2c275fu & 31u))) & 1u) { u0 += t13; d0 = d0 * 0.5 + z13; }
        if ((p0 / ((unsigned)l0 | 1u))) goto L0;
        { unsigned t14; double z14; if ((u0) & 1u) { t14 = (unsigned)((g1 / ((unsigned)e0 | 1u)) && (unsigned)h0); z14 = (double)(((((unsigned)(x0 >> 70) + u3) - r0.y)) & 255u); } if ((u0) & 1u) { u2 += t14; d0 = d0 * 0.5 + z14; }
            if (-(g1 * p1)) goto L2;
        }
        r0.x = (3u | (unsigned)((int)u1 < (int)(unsigned)((short)0x7fffffffu > (signed char)2u)));
        do { if (--fuel == 0u) goto done;
            if (-((g1 ^ 0xfe08d2abu) * garr[u2 & 7u])) goto L2;
        } while (i0++ < 4u && (unsigned)(4u < (unsigned)h1));
        do { if (--fuel == 0u) goto done;
            b0 = r0.x != 0u;
            if (fuel < 8u) return ((unsigned)(m0 || 0x80000000u) << ((unsigned)h0 & 31u));
        } while (i0++ < 6u && r0.y);
        if ((unsigned)(u0 == (v0 | 0xffffffffu))) goto L3;
    }
    l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)x0));
    { unsigned t15; double z15; if ((((unsigned)(signed char)(unsigned)(0xffffffffu == 0x10000u) | 0x10000u)) & 1u) { t15 = (unsigned)(unsigned char)(u0 % ((unsigned)l0 | 1u)); z15 = (double)((((unsigned)d0 & i0)) & 255u); } if ((((unsigned)(signed char)(unsigned)(0xffffffffu == 0x10000u) | 0x10000u)) & 1u) { u2 += t15; d0 = d0 * 0.5 + z15; }
        if ((unsigned)(signed char)((unsigned)h0 * 0x7fffffffu)) {
            if ((unsigned)((unsigned)(9u == u1) < 0xffffffffu)) goto done;
            u3 ^= (unsigned)(signed char)(((0xffffffffu % ((unsigned)(w0 >> 29) | 1u)) | (unsigned)c0) << (0xffffffffu & 31u));
            if ((unsigned)!((unsigned)(p2 && (unsigned)s1) | u0)) goto done;
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= (m0 >> (-((unsigned)h1 * ((fuel ^ 0x948197eu) % (5u | 1u))) & 31u));
                v0 = ((unsigned)(x0 >> 70) << (((unsigned)e0 % (g0 | 1u)) & 31u));
            }
            b0 = (unsigned)((int)u3 < (int)((a0[i0 & 3u] ^ (unsigned)(w0 >> 29)) / (0x10000u | 1u))) != 0u;
            for (;;) { if (--fuel == 0u) goto done;
                r0.x = (unsigned)((short)(0xffffffffu << ((0x80000000u * fuel) & 31u)) > (signed char)v0);
                if ((unsigned)c1) goto L4;
                break; (void)((unsigned)b0);
                u1 = u1 * 0x9e3779b1u + ((0xf33476b2u / ((unsigned)h0 | 1u)) ^ 1u);
            }
        } else {
            do { if (--fuel == 0u) goto done;
                if ((p0 & p1)) break;
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (p2) goto done;
                    h0 = (short)(unsigned)((int)0xffffffffu >= (int)(unsigned)((short)(unsigned)x0 > (signed char)(unsigned)((int)i0 >= (int)0x7fffffffu)));
                    if ((0x80000000u | p2)) break;
                    g0 = (unsigned)((int)r0.y < (int)(unsigned)h1);
                    continue; (void)(((unsigned)s1 & 0x5c6779c4u));
                    if (((unsigned)((int)i1 < (int)g1) << (garr[i1 & 7u] & 31u))) break;
                }
                a0[(garr[i1 & 7u] % ((unsigned)b0 | 1u)) & 3u] = ((unsigned)f0 ^ (0x10000u ? (unsigned)f0 : 6u));
            } while (i0++ < 6u && 7u);
        }
        goto L2;
        s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)b0 > (signed char)u3));
        w0 = w0 * 6364136223846793005ull + ((*q0 ^ (unsigned)((unsigned)(x0 >> 70) == (i0 << ((unsigned)b0 & 31u)))) / (r0.y | 1u));
        v0 = (u0 | ((garr[u2 & 7u] | i0) % (((unsigned)d0 + (unsigned)e0) | 1u)));
    }
    e0 = e0 * 0.5L + (long double)((unsigned)s1 & 1023u);
    if ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)u3)) goto done;
    u2 += (0xd681ae0eu ? (unsigned)c1 : (unsigned)(p2 || (unsigned)d0));
    if (fuel < 8u) return (unsigned)(-(garr[i1 & 7u] * 0xffffffffu) || i1);
    r0.x = *mp;
    if ((unsigned)h1) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u0 = fn0((-(*mp * 0x45b88184u) ^ (unsigned)s1), (unsigned)!(r0.y << ((unsigned)(0x7fffffffu || m0) & 31u)), 3u); }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        u2 = u2 * 0x9e3779b1u + (unsigned)(p0 || g0);
        w0 = w0 * 6364136223846793005ull + 0x7fffffffu;
        L0: if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
        }
        a0[6u & 3u] = (unsigned)((short)(unsigned)((int)(unsigned)f0 < (int)(r0.x ^ (unsigned)c1)) > (signed char)(unsigned)b0);
        continue; (void)((r0.x * g0));
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)(u3 % ((unsigned)s1 | 1u)) << (((0x3eb967b3u | 5u) + (unsigned)((unsigned)((int)5u < (int)8u) || 0x827fcc71u)) & 63u);
        u1 = u1 * 0x9e3779b1u + (unsigned)(3u || (unsigned)(0x2a0fd1c0u == ((unsigned)(signed char)(p0 >> (p2 & 31u)) - (unsigned)x0)));
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)c0 && (unsigned)f0)) goto L1;
    } while (i0++ < 4u && (unsigned)(-(m0 - u1) < garr[i1 & 7u]));
    if ((0xffffffffu ^ r0.x)) {
        if ((u1 * u1)) {
            if (2u) goto L1;
            u2 += p1;
            u2 = u2 * 0x9e3779b1u + (unsigned)(short)(4u ? 0x5b4c94e3u : (0x7aa7cca2u ? p2 : 3u));
        } else {
            goto L4;
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)s1) break;
                u0 = 0x7fffffffu;
                break; (void)(0x10000u);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(x0 >> 70) < 0x10000u), u3, (*mp << (a0[u1 & 3u] & 31u))); }
        }
        { unsigned t0; double z0; if (((unsigned)((short)i2 > (signed char)0x10000u)) & 1u) { t0 = (i0 & (unsigned)e0); z0 = (double)(((*mp | 2u)) & 255u); } if (((unsigned)((short)i2 > (signed char)0x10000u)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            switch ((unsigned)((int)(unsigned)((short)0xffffffffu > (signed char)a0[i0 & 3u]) < (int)i0) & 7u) {
                g1 += (garr[u2 & 7u] >> ((r0.y | 6u) & 31u));
                L2: if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
            }
            goto L0;
            c1 = (signed char)(9u >> ((unsigned)((int)0x8fb32e2u < (int)(r0.x ? (unsigned)h0 : garr[i1 & 7u])) & 31u));
            if (budget != 0u) { budget -= 1u; u0 = fn0((a0[i0 & 3u] / (a0[i0 & 3u] | 1u)), (unsigned)(r0.y || (9u ^ r0.x)), (unsigned)((int)p2 < (int)(unsigned)x0)); }
            c0 = (unsigned char)((unsigned)(short)((unsigned)h1 / (*q0 | 1u)) * (p2 * garr[i1 & 7u]));
            if (budget != 0u) { budget -= 1u; u3 = fn0((garr[u2 & 7u] | p0), 0x10000u, 0x492ac9a4u); }
        }
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(g1);
            u0 += (unsigned)(unsigned char)(r0.y ^ 4u);
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                r0.x = r0.y;
                if ((garr[i1 & 7u] / (((unsigned)e0 & (unsigned)(x0 >> 70)) | 1u))) {
                    r0.x = (p0 ^ u0);
                    r0.x = (((unsigned)(g1 && (unsigned)s1) | 0x3f73a96bu) | *q0);
                    if (budget != 0u) { budget -= 1u; u2 = fn0(garr[u2 & 7u], (0xffffffffu | (0u | (unsigned)f0)), (unsigned)d0); }
                }
                w0 ^= (unsigned long long)(unsigned)c0 << ((unsigned)(unsigned char)(unsigned)((int)u1 >= (int)garr[i1 & 7u]) & 63u);
                h1 = (unsigned short)(h1 + (unsigned)(short)((p1 % (p1 | 1u)) ^ (unsigned)(g0 < p2)));
                h0 = (short)(0xffffffffu / (g1 | 1u));
                if (0x7fffffffu) break;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((u0 % (p0 | 1u)), g0, (unsigned)(signed char)(unsigned)((r0.x & 0x4034627du) == 3u)); }
            d0 = d0 * 0.5 + (double)((a0[u1 & 3u] - (unsigned)b0) & 1023u);
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                g0 = r0.y;
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((r0.x * g0), (unsigned)(0xda368b48u || (unsigned)(u3 < *q0)), (4u / (-(a0[i0 & 3u] / (0x84c09096u | 1u)) | 1u))); }
        g0 = ((unsigned)s1 << ((unsigned)(short)(unsigned)(0x10000u && (unsigned)((int)fuel >= (int)i0)) & 31u));
        goto L4;
    }
    if (garr[u2 & 7u]) {
        if (9u) {
            L4: if (--fuel == 0u) goto done;
        } else {
            garr[u3 & 7u] = (unsigned)((int)(unsigned)h1 < (int)((unsigned)e0 * ((unsigned)s1 >> (g0 & 31u))));
        }
        u1 = (0xe2aac831u | 0x10000u);
    } else {
        w0 ^= (unsigned long long)(unsigned)c0 << ((p0 - (~(0x80000000u / (r0.y | 1u)) ^ v0)) & 63u);
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)c1, (0x80000000u ? garr[u2 & 7u] : m0), (unsigned)c1); }
        { unsigned t1; double z1; if ((m0) & 1u) { t1 = u0; z1 = (double)((-(unsigned)(0x80000000u || *q0)) & 255u); } if ((m0) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            if (budget != 0u) { budget -= 1u; u2 = fn0((4u & 0xb906c892u), p0, (garr[i1 & 7u] ^ 0x7fffffffu)); }
            i1 = ((unsigned)((short)(unsigned)((short)(0xc3c500edu / (r0.x | 1u)) > (signed char)2u) > (signed char)0x1b6929b3u) & 0x7fffffffu) & 15u;
            do { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + 0x7fffffffu);
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)h1, (0xb5e3b7afu >> ((unsigned)b0 & 31u)), (unsigned)((int)0xdada5d58u < (int)7u)); }
                    e0 = e0 * 0.5L + (long double)(i1 & 1023u);
                    while (i2++ < 5u && (unsigned)c1) { if (--fuel == 0u) goto done;
                        break; (void)(0x80000000u);
                        b0 = g0 != 0u;
                        u1 ^= ((a0[i0 & 3u] | (unsigned)((short)u2 > (signed char)(unsigned)x0)) + a0[i0 & 3u]);
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(unsigned)((int)((unsigned)(w0 >> 29) ^ r0.x) < (int)v0), a0[i0 & 3u], (unsigned)(0x9fed4de9u < 0x3410e4dfu)); }
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)e0, 7u, (unsigned)c1); }
                        if ((u2 % (g0 | 1u))) break;
                        goto L3;
                        c1 = (signed char)((garr[u2 & 7u] | 8u) | (unsigned)d0);
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)8u >= (int)((unsigned)c0 ^ 0x7fffffffu)), (unsigned)s0, ((0xd440259eu >> (1u & 31u)) >> (u3 & 31u))); }
                    } while (i2++ < 5u && fuel);
                }
                *mp = ((unsigned)f0 >> ((unsigned)x0 & 31u));
            } while (i0++ < 7u && (unsigned)((*mp * 0x9c81e9fu) == i0));
            r0.x = m0;
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)f0 == (unsigned)(a0[u1 & 3u] == (unsigned)s0)), fuel, (0xffffffffu >> (garr[u2 & 7u] & 31u))); }
    garr[(*mp ^ (unsigned)h1) & 7u] = (unsigned)((int)-(*mp ^ (unsigned)((int)i2 < (int)0x80000000u)) < (int)(unsigned)(0x41965aa8u || i2));
    w0 = w0 * 6364136223846793005ull + (((unsigned)(signed char)(garr[i1 & 7u] / (0x3e69a724u | 1u)) & u2) | *mp);
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(u1 && 3u), (unsigned)s1, ~(unsigned)((short)(unsigned)c1 > (signed char)*q0)); }
    u2 += (((unsigned)d0 + u3) | 0x83cfc944u);
    if ((unsigned)c0) {
        x0 = x0 * 0x100000001b3ull + (unsigned)((0xd01d2806u % (0x37bee59fu | 1u)) == a0[i0 & 3u]);
        if ((unsigned)((unsigned)f0 && (unsigned)(5u < 0xa582e9bbu))) {
            h0 = (short)((unsigned)(signed char)(0x10000u + (unsigned)c0) % (a0[u1 & 3u] | 1u));
            while (i0++ < 3u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                s0 = (int)~(*mp % (garr[u2 & 7u] | 1u));
                m0 ^= (unsigned)((unsigned)((int)(a0[u1 & 3u] - (u1 / (0xffffffffu | 1u))) < (int)u3) && 0xec4a40d1u);
                if (-(unsigned)((int)(unsigned)((short)u0 > (signed char)g1) >= (int)fuel)) break;
                if ((unsigned)((short)v0 > (signed char)*mp)) break;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(unsigned char)(r0.y * v0), ((3u ^ (unsigned)l0) + 0u), (p1 >> (u1 & 31u))); }
            }
            u2 += (unsigned)(unsigned char)(((unsigned)s0 << (garr[u2 & 7u] & 31u)) | (unsigned)((i1 % (3u | 1u)) && 9u));
        }
        u2 += (unsigned)(m0 && (unsigned)((short)(unsigned)(signed char)(unsigned)(0x7fffffffu && u1) > (signed char)i0));
        if (((unsigned)l0 * fuel)) goto L3;
        a0[((unsigned)h1 + (unsigned)b0) & 3u] = 0x2d51bc7eu;
        do { if (--fuel == 0u) goto done;
            a0[(unsigned)((short)p1 > (signed char)u1) & 3u] = m0;
            if (budget != 0u) { budget -= 1u; u1 = fn0((0x38935b41u >> ((unsigned)x0 & 31u)), (unsigned)(signed char)(unsigned)((g0 % (u1 | 1u)) == 0xd44be0c2u), a0[i0 & 3u]); }
            c1 = (signed char)(unsigned)h1;
            if (0x42226706u) break;
        } while (i0++ < 4u && ((unsigned)(signed char)(unsigned)((int)0x7f16663bu < (int)(unsigned)w0) | 0x10000u));
    } else {
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)s0) break;
            l0 = (long)((unsigned long)l0 + (unsigned)(g1 == 0x10000u));
        }
    }
    r0.y ^= a0[u1 & 3u];
    u1 = u1 * 0x9e3779b1u + (unsigned)!(unsigned)((int)(unsigned)((3u << ((p2 + u2) & 31u)) < i2) >= (int)7u);
    h1 = (unsigned short)(h1 + 0x10000u);
    r0.x = (unsigned)((unsigned)(w0 >> 29) == (unsigned)(0xffffffffu || u2));
    *mp = (unsigned)(unsigned char)(u3 * (u2 | (i1 << (u3 & 31u))));
    g0 = 0xffffffffu;
    if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)0xffffffffu)) goto L3;
    h1 = (unsigned short)(h1 + (unsigned)(w0 >> 29));
    w0 = w0 * 6364136223846793005ull + (unsigned)((short)a0[i0 & 3u] > (signed char)v0);
    while (i0++ < 5u && (unsigned)x0) { if (--fuel == 0u) goto done;
        *mp = ((0u + ((unsigned)h1 * r0.x)) ? a0[u1 & 3u] : u3);
        { unsigned t2; double z2; if (((unsigned)((int)2u >= (int)5u)) & 1u) { t2 = 6u; z2 = (double)(((unsigned)((short)p0 > (signed char)r0.y)) & 255u); } if (((unsigned)((int)2u >= (int)5u)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            garr[-((unsigned)c1 & r0.y) & 7u] = ((unsigned)s1 / (*mp | 1u));
            v0 = (p2 * (unsigned)((unsigned)h1 || (a0[u1 & 3u] ^ i1)));
            { unsigned t3; double z3; if (((unsigned)(8u == u3)) & 1u) { t3 = (unsigned)((unsigned)((short)garr[u2 & 7u] > (signed char)u0) || (unsigned)s1); z3 = (double)((g0) & 255u); } if (((unsigned)(8u == u3)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                if ((0x54853691u * a0[u1 & 3u])) break;
                break; (void)(((unsigned)(0xd163bc6eu < 0x80000000u) ^ p1));
                x0 = x0 * 0x100000001b3ull + ((unsigned)e0 & (unsigned)((unsigned)c0 && 9u));
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0(2u, (unsigned)((int)0xeb0e7372u < (int)(unsigned)(w0 >> 29)), (unsigned)((int)fuel < (int)(unsigned)((short)u0 > (signed char)(unsigned)f0))); }
            *q0 += u0;
        }
        *mp = g0;
        if ((unsigned)(garr[i1 & 7u] && (unsigned)x0)) continue;
        if (*mp) break;
        break; (void)((unsigned)((unsigned)l0 || (5u | r0.x)));
    }
    *q0 = (0x10000u << ((~((unsigned)c1 & (unsigned)(w0 >> 29)) + (unsigned)(g0 && (unsigned)e0)) & 31u));
    *q0 += (unsigned)(w0 >> 29);
    if ((unsigned)(6u || 0x10000u)) goto L2;
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            *mp = (unsigned)((int)0x7fffffffu >= (int)((unsigned)c0 + fuel));
            if (budget != 0u) { budget -= 1u; u3 = fn0((((unsigned)h1 >> (0xbcd8a5e8u & 31u)) % (g1 | 1u)), (unsigned)c0, (p2 | 0x3a55a896u)); }
            l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)h0 && fuel) / ((p1 + (unsigned)f0) | 1u)));
        } while (i1++ < 6u && ((*mp + (unsigned)h1) << (7u & 31u)));
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(r0.x >> (v0 & 31u)) >= (int)4u)) break;
            if (budget != 0u) { budget -= 1u; u3 = fn0(u3, r0.y, p1); }
            w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)((unsigned)(unsigned char)(unsigned)((short)u1 > (signed char)(unsigned)h0) == g0) > (signed char)3u);
            s0 = (int)0x1a5a2a20u;
            a0[(0x10000u + u1) & 3u] = (unsigned)(fuel < g0);
            if (((unsigned)(garr[i1 & 7u] < (unsigned)s1) ^ (unsigned)c1)) {
                if ((unsigned)((unsigned)c1 == 0xb4c8765fu)) break;
                f0 = f0 * 0.5f + (float)(garr[i1 & 7u] & 255u);
                garr[(3u | 1u) & 7u] = ((unsigned)(short)(unsigned)(0x10000u && 8u) ^ ((3u ^ 0x80000000u) * 0x10000u));
                if ((unsigned)((unsigned)e0 == v0)) {
                    if ((u2 % ((0x10000u ^ (unsigned)f0) | 1u))) {
                        s0 = (int)(unsigned)((int)0x1f91a126u >= (int)(((u1 & g1) % (0x10000u | 1u)) % (u2 | 1u)));
                        w0 ^= (unsigned long long)0x7fffffffu << ((unsigned)(short)((g0 + ((unsigned)e0 ? 0xffffffffu : 0x10000u)) ^ (unsigned)s0) & 63u);
                        r0.x = p1;
                    }
                }
            }
        } while (i1++ < 6u && (unsigned)((unsigned)d0 || (unsigned)(i1 == 0x49f7129bu)));
        if (((0x422e80d1u >> ((unsigned)b0 & 31u)) - (unsigned)s1)) goto L3;
        break; (void)((i2 / (0x7fffffffu | 1u)));
        if (u3) continue;
    } while (i0++ < 5u && 0xffffffffu);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *q0 = -(unsigned)((int)8u >= (int)((unsigned)(*q0 == (unsigned)((unsigned)e0 && 1u)) % (0x39618df3u | 1u)));
    m0 ^= (unsigned)(u0 == (unsigned)(signed char)(0u ^ 0x7fffffffu));
    goto done;
    w0 = w0 * 6364136223846793005ull + (unsigned)((v0 % (u2 | 1u)) || (~(v0 - u1) % (r0.y | 1u)));
    switch (garr[i1 & 7u] & 7u) {
        r0.y ^= (unsigned)l0;
    }
    if (0x7fffffffu) {
        if (budget != 0u) { budget -= 1u; u3 = fn1(0x1dd42170u, (u1 | (unsigned)s0), (0xf5f4b5f0u | 0x7b4ec997u)); }
        switch ((u3 - (unsigned)f0) & 7u) {
            if (r0.x) goto done;
            case 7u: ;
            if (budget != 0u) { budget -= 1u; u3 = fn1((i1 ? m0 : 0x663e5e11u), (unsigned)b0, 0x7fffffffu); }
            v0 = i2;
            case 3u: ;
        }
        switch (*q0 & 7u) {
            r0.x = (0xffffffffu << (((((unsigned)s1 % ((unsigned)w0 | 1u)) / (*mp | 1u)) >> ((unsigned)h1 & 31u)) & 31u));
            w0 ^= (unsigned long long)(unsigned)(0xa3b9827cu || (unsigned)h1) << ((unsigned)(signed char)(5u >> ((unsigned)c1 & 31u)) & 63u);
            r0.y ^= (unsigned)(2u == 3u);
        }
        l0 = (long)((unsigned long)l0 + (unsigned)((short)((unsigned)w0 % (a0[i0 & 3u] | 1u)) > (signed char)((unsigned)s1 % (a0[i0 & 3u] | 1u))));
        do { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)((*mp * *q0) < (unsigned)(fuel && (unsigned)((int)2u < (int)g0))));
        } while (i0++ < 5u && (0x65ee22a3u | p2));
        L0: if (--fuel == 0u) goto done;
    } else {
        goto done;
        r0.x = (((unsigned)(w0 >> 29) << ((unsigned)w0 & 31u)) >> (i0 & 31u));
        if (((0u + p1) + (unsigned)c1)) {
            goto L0;
            r0.x = (unsigned)((int)(g1 % (0xa141f3b8u | 1u)) < (int)(fuel >> (0x7fffffffu & 31u)));
            while ((g0 + (0u / (r0.x | 1u)))) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(((unsigned)(garr[u2 & 7u] < *q0) * (unsigned)c1) & 1023u);
                l0 = (long)((unsigned long)l0 + ((unsigned)w0 + 0x76fa53beu));
            }
            L1: if (--fuel == 0u) goto done;
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)((unsigned)x0 >> (0xbcfcbc9cu & 31u));
    }
    u1 = u1 * 0x9e3779b1u + u1;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)(unsigned char)((unsigned)s0 / (6u | 1u)) == (unsigned)e0)) break;
    } while (i0++ < 7u && 0xffffffffu);
    if (0x80000000u) goto L0;
    if (((0x80000000u + 6u) % ((unsigned)h0 | 1u))) {
        u1 = u1 * 0x9e3779b1u + (unsigned)((int)v0 < (int)(unsigned)f0);
        x0 = x0 * 0x100000001b3ull + (unsigned)d0;
        if ((0x9b5736b4u * (unsigned)c0)) {
            switch (~(unsigned)(a0[u1 & 3u] == 0xc629539fu) & 7u) {
                L2: if (--fuel == 0u) goto done;
                goto L2;
                u1 ^= (a0[u1 & 3u] & (unsigned)((unsigned)(w0 >> 29) < p0));
                if (budget != 0u) { budget -= 1u; u2 = fn0(((7u * (unsigned)d0) + *mp), (p1 + ~(unsigned)((int)0x30b119b9u >= (int)9u)), (unsigned)(short)(0x7fffffffu & (u0 + (unsigned)c0))); }
                L3: if (--fuel == 0u) goto done;
            }
            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(((unsigned)x0 | 0xcbe8daf2u) == ~(unsigned)((int)a0[i0 & 3u] >= (int)m0)) < 0x80000000u));
            L4: if (--fuel == 0u) goto done;
        } else {
            while (i0++ < 6u && 0x1bbd6fefu) { if (--fuel == 0u) goto done;
                garr[(unsigned)x0 & 7u] = (unsigned)l0;
                if (fuel < 8u) return (unsigned)h0;
            }
            if ((unsigned)s1) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((unsigned)b0 || 0x1af71bf2u) * (unsigned)e0), ((unsigned)((int)0xffffffffu >= (int)(unsigned)(w0 >> 29)) % ((unsigned)l0 | 1u)), (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)h0)); }
        }
        goto L3;
    } else {
        if ((unsigned)!(unsigned)((short)(unsigned)x0 > (signed char)u0)) {
            d0 = d0 * 0.5 + (double)(((unsigned)s1 - (9u / ((unsigned)(w0 >> 29) | 1u))) & 1023u);
            goto L1;
        }
        if (a0[u1 & 3u]) {
            u0 ^= (((unsigned)x0 * i2) << ((unsigned)(0x10000u || (unsigned)(w0 >> 29)) & 31u));
            a0[(unsigned)b0 & 3u] = ((unsigned)l0 >> ((unsigned)s1 & 31u));
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (u1) continue;
                if ((garr[i1 & 7u] % (2u | 1u))) break;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)s0, (unsigned)(i0 || (p1 << (0x820b2d48u & 31u))), (unsigned)((unsigned)f0 == (unsigned)(0xffffffffu || 0x85feaffeu))); }
        } else {
            m0 ^= (*mp & u0);
            do { if (--fuel == 0u) goto done;
                break; (void)(*mp);
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)c0, (m0 >> ((unsigned)l0 & 31u)), ((unsigned)x0 - g0)); }
            } while (i0++ < 2u && (unsigned)((int)(unsigned)s1 < (int)1u));
        }
        { unsigned t0; double z0; if (((unsigned)(signed char)(unsigned)((short)(m0 ^ r0.x) > (signed char)u2)) & 1u) { t0 = (unsigned)(u3 == u1); z0 = (double)(((((unsigned)f0 - p0) - 0xe3b9ec17u)) & 255u); } if (((unsigned)(signed char)(unsigned)((short)(m0 ^ r0.x) > (signed char)u2)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= -((unsigned)!(unsigned)(u2 == (unsigned)w0) & (unsigned)((int)0xabff2c60u < (int)(unsigned)x0));
                if (((unsigned)b0 << (0x98285d54u & 31u))) break;
                if (((4u / (a0[u1 & 3u] | 1u)) % (u0 | 1u))) break;
                b0 = (fuel * (unsigned)((int)0xeb573e9au < (int)((unsigned)c0 << (7u & 31u)))) != 0u;
                break; (void)((unsigned)(signed char)(unsigned)(i1 == a0[i0 & 3u]));
            }
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)((int)(unsigned)f0 < (int)((unsigned)w0 % ((unsigned)((int)(unsigned)s1 < (int)0x34a2a17u) | 1u)));
            u1 ^= (3u << ((u0 >> (((0x6e2cb5a2u | 0u) & (unsigned)h1) & 31u)) & 31u));
            *q0 += ((unsigned)((unsigned)w0 && (unsigned)((short)9u > (signed char)*mp)) + (unsigned)(w0 >> 29));
        }
    }
    if (0xf93be9e2u) goto done;
    { unsigned t1; double z1; if (((unsigned)w0) & 1u) { t1 = u1; z1 = (double)(((0x1efd8192u - u0)) & 255u); } if (((unsigned)w0) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        if ((0x10000u / (u1 | 1u))) goto L0;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)s0 == (unsigned)c0), (unsigned)!(i2 ? *mp : 0x333a36cbu), ((unsigned)(x0 >> 70) + v0)); }
        r0.x = 0xffffffffu;
        goto L2;
    }
    { unsigned t2; double z2; if (((((unsigned)c1 - 0xc2351d3bu) << (0x16243615u & 31u))) & 1u) { t2 = 0x3a130b6u; z2 = (double)(((unsigned)(0x829a6da8u && (unsigned)d0)) & 255u); } if (((((unsigned)c1 - 0xc2351d3bu) << (0x16243615u & 31u))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(g0 == (i0 - i0)), (i1 << ((unsigned)((int)0x67610a8eu >= (int)0xe656f6cfu) & 31u)), 0x80000000u); }
    }
    switch ((unsigned)(signed char)(unsigned)(7u && (unsigned)e0) & 7u) {
        m0 ^= ((unsigned)((short)garr[i1 & 7u] > (signed char)5u) * u1);
        garr[(0xffffffffu % ((unsigned)s1 | 1u)) & 7u] = ((((unsigned)(i2 && 0x88dff235u) % (0x10000u | 1u)) + i0) / (1u | 1u));
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)e0, (i1 >> (i1 & 31u)), 1u); }
        break; (void)((0xffffffffu - 0x80000000u));
        if (budget != 0u) { budget -= 1u; u2 = fn0(~((unsigned)h0 + fuel), (1u ^ 7u), (p1 - g1)); }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            while ((unsigned)(short)(unsigned)((short)0x7fffffffu > (signed char)u0)) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (unsigned)((int)r0.y < (int)((unsigned)b0 - (unsigned)((int)0x7fffffffu >= (int)p0))));
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)((int)0x10000u >= (int)3u) << (v0 & 31u)), (u3 - (unsigned)(0x45274b49u < *mp)), (unsigned)!((0xffffffffu >> (u3 & 31u)) >> ((unsigned)f0 & 31u))); }
                if ((unsigned)(x0 >> 70)) goto L3;
                break; (void)((unsigned)((unsigned)e0 && i0));
                h1 = (unsigned short)(h1 + ((unsigned)(0x10000u < 0x10000u) / (0x2aa34087u | 1u)));
            }
            *q0 = (unsigned)d0;
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1((r0.x - (p1 - u0)), (unsigned)w0, (unsigned)s1); }
    c0 = (unsigned char)((unsigned)x0 & (0xec2dd65fu * 0x4461cbe9u));
    { unsigned t3; double z3; if ((u0) & 1u) { t3 = (unsigned)((0xdc5a0109u ^ 0xbb69d374u) || (unsigned)f0); z3 = (double)(((unsigned)(signed char)(unsigned)((unsigned)!(unsigned)((int)(unsigned)c1 >= (int)(unsigned)(x0 >> 70)) && i1)) & 255u); } if ((u0) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
        if (fuel < 8u) return ((unsigned)(a0[u1 & 3u] == v0) & (unsigned)((int)*q0 >= (int)u2));
        if (v0) goto L2;
    }
    if (fuel < 8u) return (unsigned)(w0 >> 29);
    g1 += ((0x4eb52d37u ? p0 : 5u) / ((0x10000u - 0x80000000u) | 1u));
    do { if (--fuel == 0u) goto done;
        if (((unsigned)h0 | (unsigned)c1)) {
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                b0 = ((unsigned)(a0[u1 & 3u] && 4u) << ((unsigned)h1 & 31u)) != 0u;
            }
            for (;;) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)c0 == ((unsigned)(0x7fffffffu || a0[u1 & 3u]) & u0)) & 255u);
                a0[4u & 3u] = (unsigned)(w0 >> 29);
                break; (void)(((unsigned)c0 / (0xe37ea023u | 1u)));
            }
            r0.y ^= (unsigned)((u2 & 0x7fffffffu) && (unsigned)((short)(unsigned)c1 > (signed char)(unsigned)s1));
            q0 = &garr[(0x1a528c85u + (g1 ^ (unsigned)f0)) & 7u];
            if (garr[u2 & 7u]) break;
            u0 = (u0 >> ((((i2 + (unsigned)s0) % (7u | 1u)) | p1) & 31u));
        }
        e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)(unsigned)((short)((unsigned)f0 - u2) > (signed char)(unsigned)(signed char)(i2 - 0x80000000u)) & 1023u);
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            *q0 = (unsigned)((int)(0xa9f6b953u % ((unsigned)((int)i2 >= (int)0x7e2cb849u) | 1u)) < (int)(0x10000u >> ((unsigned)(w0 >> 29) & 31u)));
            if (budget != 0u) { budget -= 1u; u2 = fn0(a0[u1 & 3u], (0x31a22a52u ? 0u : (unsigned)b0), *q0); }
            { unsigned t4; double z4; if (((unsigned)l0) & 1u) { t4 = (i0 << (8u & 31u)); z4 = (double)(((unsigned)((int)(unsigned)((unsigned)d0 == 8u) >= (int)p1)) & 255u); } if (((unsigned)l0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                if (((unsigned)x0 | (unsigned)e0)) break;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (0xffffffffu) break;
                    s1 = (int)((unsigned)s1 + 4u);
                }
                a0[(unsigned)!(v0 * 0xffffffffu) & 3u] = (unsigned)!(unsigned)(a0[u1 & 3u] < 9u);
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    m0 ^= ((unsigned)l0 & (unsigned)(7u && m0));
                    x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(p0 * (unsigned)f0);
                    if ((unsigned)(v0 < (unsigned)(i1 < (unsigned)c1))) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)(x0 >> 70) < (int)0x10000u), (unsigned)!((unsigned)((unsigned)(x0 >> 70) || 0x7fffffffu) & g1), ((unsigned)((short)r0.y > (signed char)0xffffffffu) + 0x80000000u)); }
                }
            }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((int)g1 >= (int)(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)f0))) {
                    if ((unsigned)((int)(unsigned)((short)p2 > (signed char)0xb28c9b9bu) < (int)r0.y)) goto L3;
                    switch ((m0 << ((unsigned)e0 & 31u)) & 7u) {
                        if (fuel < 8u) return (unsigned)((~(0x10000u * -((unsigned)s0 & p2)) | 0xe72d1131u) && (unsigned)(x0 >> 70));
                        x0 = x0 * 0x100000001b3ull + p1;
                        w0 = w0 * 6364136223846793005ull + ((unsigned)((int)((unsigned)e0 - 0u) < (int)*mp) * ((unsigned)w0 + 0xc76f30e3u));
                        case 1u: ;
                        if (garr[i1 & 7u]) {
                            v0 = (unsigned)((int)(0u | u0) >= (int)p2);
                            a0[garr[u2 & 7u] & 3u] = 0x7fffffffu;
                        } else {
                            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((int)p0 >= (int)(unsigned)b0) == (unsigned)d0);
                            default: ;
                            garr[*q0 & 7u] = *q0;
                        }
                        l0 = (long)((unsigned long)l0 + (unsigned)((short)u0 > (signed char)(0xe58cde09u * (unsigned)h0)));
                    }
                    c1 = (signed char)((unsigned)c0 & (unsigned)!(unsigned)((int)0x53683bau >= (int)(6u - ((unsigned)d0 % ((unsigned)b0 | 1u)))));
                    if (budget != 0u) { budget -= 1u; u2 = fn1((0x7fffffffu & (unsigned)c1), (g0 << (r0.x & 31u)), (1u + 0x80000000u)); }
                } else {
                    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)x0 & (*mp << (9u & 31u))), 0xc2973e48u, 0xffffffffu); }
                    continue; (void)(((unsigned)w0 << (0x10000u & 31u)));
                    if (((unsigned)(x0 >> 70) ^ (r0.y >> (u1 & 31u)))) break;
                }
                break; (void)((v0 * (unsigned)((short)0x10000u > (signed char)i1)));
            } while (i2++ < 5u && (unsigned)s0);
        }
        if (((unsigned)h0 << ((unsigned)((int)7u >= (int)(unsigned)s0) & 31u))) break;
        if ((unsigned)(0x61c29e69u && p1)) {
            l0 = (long)((unsigned long)l0 + a0[u1 & 3u]);
            switch (((unsigned)((int)p2 < (int)0x7fffffffu) * 0x3c32bb4u) & 7u) {
                f0 = f0 * 0.5f + (float)(((unsigned)s1 << (p0 & 31u)) & 255u);
                m0 ^= (u3 + ((unsigned)e0 / (p1 | 1u)));
                w0 = w0 * 6364136223846793005ull + (unsigned)c0;
                u0 += (((unsigned)w0 | a0[i0 & 3u]) << ((0xffffffffu | p2) & 31u));
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)s1 || a0[u1 & 3u]), (unsigned)(u0 == (unsigned)((int)(unsigned)s1 >= (int)(unsigned)(x0 >> 70))), 0xba87fbf1u); }
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0(0xffffffffu, (unsigned)(0x10000u < (unsigned)(signed char)(g0 % (i1 | 1u))), (unsigned)((short)(unsigned)((short)(unsigned)f0 > (signed char)0x515cdcffu) > (signed char)0x80000000u)); }
            s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(unsigned)((int)(garr[i1 & 7u] >> (0x7cc21fb2u & 31u)) >= (int)(unsigned)((int)p2 >= (int)(unsigned)c1)));
        } else {
            if (a0[i0 & 3u]) break;
            r0.x = -(unsigned)(6u || (unsigned)(i0 == r0.y));
            c0 = (unsigned char)(unsigned)c0;
            w0 = w0 * 6364136223846793005ull + (i2 - ((u3 / (0x7fffffffu | 1u)) >> (u3 & 31u)));
        }
        switch ((fuel ^ a0[i0 & 3u]) & 7u) {
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)!(unsigned)(4u < (unsigned)f0) << (i2 & 31u)), 0xffffffffu, 0x972952aau); }
            if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, (0x2bedd979u % ((unsigned)f0 | 1u)), (0x80000000u << (a0[u1 & 3u] & 31u))); }
            { unsigned t5; double z5; if (((unsigned)(short)((unsigned)(unsigned char)(0x49f14cbfu | 0x8f5a1a6au) % (0x538e958eu | 1u))) & 1u) { t5 = (unsigned)(short)(unsigned)((int)(unsigned)s0 < (int)0x775a1be1u); z5 = (double)(((unsigned)((int)0xf21179c3u >= (int)fuel)) & 255u); } if (((unsigned)(short)((unsigned)(unsigned char)(0x49f14cbfu | 0x8f5a1a6au) % (0x538e958eu | 1u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                if (budget != 0u) { budget -= 1u; u3 = fn1((0x7fffffffu << ((unsigned)!((unsigned)f0 % (9u | 1u)) & 31u)), r0.y, (unsigned)((unsigned)l0 && 0x10000u)); }
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (1u % ((u3 >> ((unsigned)(x0 >> 70) & 31u)) | 1u)) != 0u;
                    r0.y ^= -((unsigned)c0 ? (unsigned)c0 : 0x3d9fd7aeu);
                    case 4u: ;
                    b0 = (0x80000000u - (u1 % (0xffffffffu | 1u))) != 0u;
                }
                h1 = (unsigned short)(h1 + (unsigned)((int)(*mp ^ garr[i1 & 7u]) < (int)(unsigned)h0));
                { unsigned t6; double z6; if (((((unsigned)w0 / (a0[u1 & 3u] | 1u)) / (r0.x | 1u))) & 1u) { t6 = (0x7fffffffu >> (u1 & 31u)); z6 = (double)(((unsigned)((unsigned)c0 == (unsigned)s1)) & 255u); } if (((((unsigned)w0 / (a0[u1 & 3u] | 1u)) / (r0.x | 1u))) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(i2, (unsigned)((short)0xd0065d67u > (signed char)g1), (i2 / (6u | 1u))); }
                    u0 = u0 * 0x9e3779b1u + (p2 | (i1 ^ r0.y));
                }
                w0 ^= (unsigned long long)(g0 >> (i0 & 31u)) << ((unsigned)(*mp == (unsigned)!(unsigned)(0x7fffffffu == garr[u2 & 7u])) & 63u);
            }
            case 7u: ;
        }
    } while (i0++ < 7u && (unsigned)((int)0x8f2a1322u < (int)g1));
    while ((unsigned)(short)(0xad72b82u * u0)) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)((int)g1 < (int)r0.y) && v0), (unsigned)((short)((unsigned)s0 ^ g1) > (signed char)p0), (unsigned)((garr[u2 & 7u] >> (fuel & 31u)) || u0)); }
            f0 = f0 * 0.5f + (float)((unsigned)(6u == garr[i1 & 7u]) & 255u);
        }
        if (r0.y) break;
        { unsigned t7; double z7; if ((garr[i1 & 7u]) & 1u) { t7 = (i0 ^ (unsigned)x0); z7 = (double)(((unsigned)l0) & 255u); } if ((garr[i1 & 7u]) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
            goto L3;
        }
        if (u3 == 7u) return ~(unsigned)((int)((0x10000u << (~(unsigned)((int)p0 < (int)g0) & 31u)) - (unsigned)(w0 >> 29)) < (int)(unsigned)c1);
        { unsigned t8; double z8; if ((((unsigned)h1 % ((unsigned)d0 | 1u))) & 1u) { t8 = 0x38911883u; z8 = (double)((0x80000000u) & 255u); } if ((((unsigned)h1 % ((unsigned)d0 | 1u))) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
            g1 += (unsigned)((unsigned)w0 || (unsigned)((int)0x10000u < (int)0x7fffffffu));
        }
    }
    w0 = w0 * 6364136223846793005ull + (u2 | (unsigned)b0);
    while (i0++ < 3u && (unsigned)((unsigned)d0 || u3)) { if (--fuel == 0u) goto done;
        if (r0.y) break;
        m0 ^= (unsigned)(signed char)(garr[i1 & 7u] / ((unsigned)!((unsigned)(x0 >> 70) / ((unsigned)((unsigned)s0 && (*mp + u0)) | 1u)) | 1u));
    }
    for (;;) { if (--fuel == 0u) goto done;
        switch (((unsigned)(w0 >> 29) << ((unsigned)(signed char)(p0 | a0[u1 & 3u]) & 31u)) & 7u) {
            b0 = (unsigned)((unsigned)((int)(9u ^ 0u) < (int)(unsigned)c1) == (unsigned)(a0[i0 & 3u] || *mp)) != 0u;
        }
        if (fuel < 8u) return (unsigned)((a0[u1 & 3u] & 9u) == (unsigned)!(*q0 + g0));
    }
    c0 = (unsigned char)-((unsigned)l0 & i0);
    if (budget != 0u) { budget -= 1u; u2 = fn0((r0.y | m0), (unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)(x0 >> 70)), (unsigned)(0xf44fd7e6u == (a0[u1 & 3u] / (u0 | 1u)))); }
    if (i2) {
        m0 ^= (p0 + 0xffffffffu);
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)((int)(-(0u * u0) & *q0) < (int)(unsigned)((int)u2 >= (int)u3));
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                q0 = &garr[0u & 7u];
            }
            d0 = d0 * 0.5 + (double)(~((unsigned)((int)r0.x < (int)3u) - (a0[u1 & 3u] % ((unsigned)(unsigned char)(0x9f9929f4u * 0xffffffffu) | 1u))) & 1023u);
            i0 = (unsigned)((int)u3 >= (int)(-(unsigned)(i0 < p1) << (v0 & 31u))) & 15u;
            if (((unsigned)x0 % ((unsigned)d0 | 1u))) continue;
            f0 = f0 * 0.5f + (float)((0xe525547cu + ((p2 + garr[i1 & 7u]) >> ((0x80000000u | (unsigned)h0) & 31u))) & 255u);
        }
        c0 = (unsigned char)2u;
        u1 ^= 1u;
        if (*mp) {
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(r0.x ^ u0)), (unsigned)x0, (unsigned)c0); }
                if ((0x10000u % (3u | 1u))) goto done;
                g1 += (unsigned)((unsigned)f0 == ((unsigned)(x0 >> 70) % (0x80000000u | 1u)));
                if ((unsigned)(short)(0x5cfb9986u | (0x10000u / (g1 | 1u)))) break;
                u3 = u3 * 0x9e3779b1u + (unsigned)((int)(fuel | i2) < (int)(8u - (0xffffffffu & (unsigned)x0)));
                w0 = w0 * 6364136223846793005ull + g0;
            } while (i0++ < 2u && (unsigned)(u0 || (8u ^ r0.y)));
            if ((unsigned)((short)(unsigned)f0 > (signed char)(v0 - a0[u1 & 3u]))) goto L1;
            if ((unsigned)!(unsigned)((short)(unsigned)x0 > (signed char)a0[u1 & 3u])) goto L2;
            if (i0) goto L1;
            *q0 = (((unsigned)l0 % (((unsigned)(0x10000u || a0[i0 & 3u]) | p2) | 1u)) - u1);
            u2 = u2 * 0x9e3779b1u + u0;
        }
        while (i0++ < 2u && (unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
            if (((unsigned)(0u < (unsigned)h0) * a0[i0 & 3u])) break;
            g1 += ((unsigned)(0x10000u || fuel) << ((unsigned)((int)2u < (int)(unsigned)s1) & 31u));
            d0 = d0 * 0.5 + (double)((g0 << (u2 & 31u)) & 1023u);
            u2 = (unsigned)(short)(unsigned)((unsigned)w0 == (unsigned)(0x80000000u || (unsigned)s0));
            if (7u) {
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s0 ^ 0xd8298e96u), *mp, (unsigned)((short)u3 > (signed char)(unsigned)(unsigned char)((unsigned)s0 + p0))); }
                    if (((unsigned)c0 + (unsigned)(short)(unsigned)((int)garr[u2 & 7u] < (int)garr[u2 & 7u]))) break;
                    u3 += ((unsigned)((unsigned)(signed char)(unsigned)((int)(unsigned)(*mp || (unsigned)h0) >= (int)(unsigned)b0) || (unsigned)c0) & p0);
                }
                f0 = f0 * 0.5f + (float)((unsigned)(0x5bf79273u < i1) & 255u);
                x0 = x0 * 0x100000001b3ull + ((unsigned)!(unsigned)(g0 < (unsigned)h0) * -(u3 - g1));
                e0 = e0 * 0.5L + (long double)(((unsigned)s1 << (*q0 & 31u)) & 1023u);
                r0.y ^= (unsigned)!(unsigned)((unsigned)((int)(unsigned)f0 >= (int)v0) == 0xc43b407du);
            }
            continue; (void)(a0[u1 & 3u]);
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((2u << (g1 & 31u)), (unsigned)c1, (unsigned)c1); }
    if ((unsigned)x0) goto L0;
    if ((5u + (fuel << (p0 & 31u)))) {
        if ((((unsigned)x0 / ((unsigned)b0 | 1u)) | 6u)) goto L0;
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(0x7fffffffu && a0[i0 & 3u]) % (u2 | 1u)), (v0 - ~(i0 / ((unsigned)b0 | 1u))), (unsigned)(3u == (unsigned)(a0[i0 & 3u] && g1))); }
        if (((unsigned)(x0 >> 70) >> (garr[i1 & 7u] & 31u))) goto L3;
        s1 = (int)((unsigned)s1 + fuel);
        do { if (--fuel == 0u) goto done;
            if (*q0) {
                if ((unsigned)((int)*mp >= (int)(unsigned)((int)0x522b5e58u < (int)a0[u1 & 3u]))) goto L2;
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        *mp = (unsigned)((0x7fffffffu * (unsigned)b0) && ((unsigned)((unsigned)(w0 >> 29) == *mp) << (0x60e6402u & 31u)));
                    } while (i2++ < 7u && (0x10000u + (unsigned)(x0 >> 70)));
                    a0[4u & 3u] = (unsigned)((g1 & i2) && 7u);
                    *q0 += ((unsigned)(w0 >> 29) << ((unsigned)h0 & 31u));
                }
            } else {
                if (garr[u2 & 7u]) break;
                if ((*mp | (unsigned)(short)(u1 ^ (unsigned)h1))) break;
            }
            while ((unsigned)(9u < (unsigned)(0xeac4eeaeu && (unsigned)c1))) { if (--fuel == 0u) goto done;
                b0 = ((unsigned)b0 | 0x72d477f4u) != 0u;
                w0 ^= (unsigned long long)(unsigned)!(v0 | 0x45935560u) << ((unsigned)((unsigned)w0 || g0) & 63u);
            }
        } while (i0++ < 7u && (unsigned)(a0[i0 & 3u] && (u3 >> ((unsigned)w0 & 31u))));
        b0 = (7u & (unsigned)(short)(garr[i1 & 7u] & (0xf637cc18u >> (*q0 & 31u)))) != 0u;
    } else {
        while ((unsigned)(u1 == u1)) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((int)2u >= (int)(unsigned)s1));
            if ((0x7fffffffu | 8u)) continue;
            if ((0xffffffffu % (v0 | 1u))) break;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                u1 = u1 * 0x9e3779b1u + g1;
            }
        }
        h0 = (short)((unsigned)!(unsigned)(r0.x < (i1 - v0)) * u1);
        u0 += (u1 ^ (r0.x % ((unsigned)c0 | 1u)));
    }
    goto L1;
    h0 = (short)(unsigned)((int)*mp < (int)(unsigned)c1);
    for (;;) { if (--fuel == 0u) goto done;
        if ((0xffffffffu % ((unsigned)(unsigned char)(unsigned)((short)m0 > (signed char)(unsigned)s1) | 1u))) goto L4;
        while (i1++ < 5u && (g0 * 7u)) { if (--fuel == 0u) goto done;
            if (u1) break;
            *q0 += r0.x;
            while ((m0 ^ a0[i0 & 3u])) { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = 6u;
                    break; (void)((unsigned)e0);
                    *q0 += garr[i1 & 7u];
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        while (i2++ < 6u && (((unsigned)b0 / (p1 | 1u)) - (unsigned)h1)) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u1 = fn0((0x10000u / (0xffffffffu | 1u)), ((unsigned)f0 & garr[u2 & 7u]), 0x7fffffffu); }
                            if ((unsigned)((unsigned)s1 || p1)) break;
                            a0[(unsigned)(g0 || 2u) & 3u] = a0[i0 & 3u];
                            break; (void)((unsigned)l0);
                        }
                        if (budget != 0u) { budget -= 1u; u2 = fn0(0x8db9a9fcu, (unsigned)((int)0x5eea78edu < (int)(unsigned)(w0 >> 29)), (unsigned)((int)p0 >= (int)(unsigned)c0)); }
                        while (i2++ < 3u && (unsigned)(9u && 7u)) { if (--fuel == 0u) goto done;
                            r0.y ^= (unsigned)((int)(unsigned)c0 >= (int)p2);
                            h1 = (unsigned short)(h1 + ((u0 >> (((unsigned)((int)(unsigned)b0 >= (int)(unsigned)c0) % (fuel | 1u)) & 31u)) * garr[u2 & 7u]));
                            break; (void)(((unsigned)f0 >> (0x10000u & 31u)));
                            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)h1 && (unsigned)h1), (unsigned)((unsigned)d0 && (unsigned)((short)p1 > (signed char)i2)), (-(a0[u1 & 3u] & 6u) % (0x79232c00u | 1u))); }
                        }
                        if ((unsigned)(0xc7e883fdu || *q0)) break;
                        m0 ^= (unsigned)((short)u3 > (signed char)0x1ae68ebcu);
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn1(i2, (unsigned)c1, (a0[i0 & 3u] << (9u & 31u))); }
                }
                { unsigned t9; double z9; if ((8u) & 1u) { t9 = *mp; z9 = (double)((9u) & 255u); } if ((8u) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                    if ((unsigned)((int)0x15a05d77u >= (int)0x2759d60cu)) break;
                    break; (void)(((unsigned)f0 >> (1u & 31u)));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((0xffffffffu * 0xffffffffu), ~((unsigned)c1 + p2), 0xffffffffu); }
                    l0 = (long)((unsigned long)l0 + ((unsigned)((int)r0.x < (int)(i2 - (0x6d768032u * (unsigned)f0))) % ((unsigned)s0 | 1u)));
                    if (budget != 0u) { budget -= 1u; u2 = fn1((u1 ? (unsigned)x0 : i0), (p2 & ((unsigned)b0 >> (p2 & 31u))), v0); }
                }
            }
        }
    }
    { unsigned t10; double z10; if (((unsigned)((short)i1 > (signed char)0x7fffffffu)) & 1u) { t10 = (0x23e0a32eu | (unsigned)c1); z10 = (double)((((unsigned)h1 & (fuel + (unsigned)b0))) & 255u); } if (((unsigned)((short)i1 > (signed char)0x7fffffffu)) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
        c0 = (unsigned char)(unsigned)(3u == 0x2a1286fu);
        if ((*q0 / ((8u ^ u3) | 1u))) {
            v0 = (unsigned)(signed char)((unsigned)(0x7fffffffu || (unsigned)(x0 >> 70)) / ((unsigned)e0 | 1u));
            v0 = a0[u1 & 3u];
            if (0x7fffffffu) goto L4;
        }
    }
    { unsigned t11; double z11; if (((unsigned)(a0[u1 & 3u] || 0xffffffffu)) & 1u) { t11 = (unsigned)((unsigned)(x0 >> 70) == (unsigned)(w0 >> 29)); z11 = (double)(((0xffffffffu >> (*q0 & 31u))) & 255u); } if (((unsigned)(a0[u1 & 3u] || 0xffffffffu)) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)b0, garr[i1 & 7u], (unsigned)(0x7f30d811u == r0.x)); }
    }
    { unsigned t12; double z12; if ((((unsigned)e0 << (((unsigned)(w0 >> 29) - p0) & 31u))) & 1u) { t12 = i2; z12 = (double)(((unsigned)e0) & 255u); } if ((((unsigned)e0 << (((unsigned)(w0 >> 29) - p0) & 31u))) & 1u) { u1 += t12; d0 = d0 * 0.5 + z12; }
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)(garr[i1 & 7u] || ((g0 % (p2 | 1u)) >> ((unsigned)(unsigned char)(garr[i1 & 7u] % (*mp | 1u)) & 31u))));
                break; (void)(0x80000000u);
                x0 = x0 * 0x100000001b3ull + 5u;
                if ((unsigned)((unsigned)e0 || 0u)) break;
            } while (i1++ < 2u && ((unsigned)h0 * (u3 * 0x799f8176u)));
            l0 = (long)((unsigned long)l0 + 0x10000u);
        } while (i0++ < 4u && (unsigned)(u1 && v0));
        if (u3) goto L0;
        if (((unsigned)s0 ^ u3)) goto L0;
        b0 = (unsigned)((unsigned)w0 == (unsigned)(unsigned char)((unsigned)(0x939cbe61u && 0x80000000u) << (p2 & 31u))) != 0u;
        if (((unsigned)(9u == i0) % (i0 | 1u))) goto L4;
    }
    do { if (--fuel == 0u) goto done;
        if (g1) goto done;
        g1 += (unsigned)w0;
        w0 = w0 * 6364136223846793005ull + garr[u2 & 7u];
        i0 = (0x7566d231u ^ -((r0.y / (p0 | 1u)) ? garr[u2 & 7u] : u1)) & 15u;
        if (budget != 0u) { budget -= 1u; u1 = fn1((0xfe416543u | (unsigned)h1), i2, (unsigned)((int)p2 < (int)(unsigned)h0)); }
        g0 = (p0 | (garr[i1 & 7u] ^ ((*mp & *q0) | m0)));
    } while (i0++ < 7u && g0);
    v0 = g1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    m0 ^= (unsigned)!((u0 + (0xffffffffu | 0xc14dfcd5u)) << (p0 & 31u));
    L0: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)h0 + (unsigned)s0), garr[u2 & 7u], (unsigned)(signed char)(unsigned)(0xffffffffu || *q0)); }
    u3 = u3 * 0x9e3779b1u + (unsigned)(short)(unsigned)(0xe1080ab8u < (unsigned)(x0 >> 70));
    u3 ^= -(unsigned)(r0.y < u1);
    garr[(unsigned)(0x91ddb73eu || (unsigned)s0) & 7u] = ((unsigned)((short)((unsigned)f0 ^ ((unsigned)l0 >> (p2 & 31u))) > (signed char)p1) / (m0 | 1u));
    h0 = (short)(((unsigned)c0 << (0x10000u & 31u)) - ((unsigned)(3u < 0xd33b6598u) & *mp));
    m0 ^= ((unsigned)(p1 || 0xb2175d29u) / ((unsigned)((unsigned)(r0.x == 0x7fffffffu) || 0x80000000u) | 1u));
    { unsigned t0; double z0; if ((~(i1 - i1)) & 1u) { t0 = (r0.y ^ *q0); z0 = (double)((((unsigned)(x0 >> 70) ^ u0)) & 255u); } if ((~(i1 - i1)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        r0.x = (unsigned)((int)(unsigned)c0 >= (int)((unsigned)((int)i0 >= (int)(unsigned)e0) << ((unsigned)x0 & 31u)));
        r0.y ^= (u3 ? 0x6de8b1bau : (unsigned)w0);
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0(0x7fffffffu, ((unsigned)(a0[i0 & 3u] && 1u) | 0xffffffffu), (unsigned)((int)0xaa606352u < (int)-(unsigned)((short)0x5e2e95aeu > (signed char)a0[i0 & 3u]))); }
            if (budget != 0u) { budget -= 1u; u3 = fn0((0x10000u - a0[u1 & 3u]), 0xff1bfdd7u, *q0); }
        }
        i0 = (unsigned)!(3u / ((unsigned)((8u - (unsigned)(w0 >> 29)) || 5u) | 1u)) & 15u;
        c0 = (unsigned char)((unsigned)((short)garr[u2 & 7u] > (signed char)u3) % ((unsigned)x0 | 1u));
        s0 = (int)((unsigned)c0 ^ (unsigned)((short)(unsigned)c1 > (signed char)((unsigned)x0 ^ (unsigned)b0)));
    }
    c1 = (signed char)(unsigned)((unsigned)(i2 < 0xcf11b9c0u) || ((unsigned)w0 % (0x10000u | 1u)));
    h0 = (short)~((unsigned)x0 & (unsigned)((int)(0x80000000u << (u1 & 31u)) >= (int)(g1 - 0x96a02675u)));
    L1: if (--fuel == 0u) goto done;
    *mp = (unsigned)((int)(unsigned)(r0.x && (unsigned)c1) < (int)(a0[u1 & 3u] | (*q0 - 0xdd9cf1dfu)));
    c1 = (signed char)(unsigned)((int)((unsigned)(signed char)((unsigned)h1 ? 0xa7fec0bcu : u0) & 0x65d8e2fbu) >= (int)(unsigned)l0);
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        i2 = ((unsigned)e0 << ((unsigned)((int)(0x24df146bu / (0x6811099bu | 1u)) >= (int)(unsigned)((int)0xa3145ec3u >= (int)u0)) & 31u)) & 15u;
        if (((unsigned)!(unsigned)(i0 == *q0) ^ u1)) {
            e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)((int)(r0.y + 0x10000u) >= (int)(unsigned)(p0 && (unsigned)w0)) & 1023u);
        } else {
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((short)a0[i0 & 3u] > (signed char)~((unsigned)c1 * m0))) {
                    break; (void)((garr[u2 & 7u] % (((unsigned)f0 ^ u1) | 1u)));
                    if (budget != 0u) { budget -= 1u; u2 = fn1(a0[u1 & 3u], (unsigned)((short)(unsigned)((int)p2 < (int)g1) > (signed char)(unsigned)c0), (unsigned)(garr[u2 & 7u] || (u0 * a0[u1 & 3u]))); }
                }
                L2: if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn2(((u3 >> (9u & 31u)) | r0.y), 0x390781bau, 0x4b00d980u); }
                }
                L3: if (--fuel == 0u) goto done;
                continue; (void)((a0[u1 & 3u] - 0x2231e3bdu));
            } while (i1++ < 3u && (unsigned)(w0 >> 29));
            h1 = (unsigned short)(h1 + ~((r0.x - (unsigned)h1) >> (((unsigned)c1 << ((unsigned)d0 & 31u)) & 31u)));
            if ((unsigned)((int)8u < (int)0x7fffffffu)) break;
        }
        if ((unsigned)((int)0xe662db2u < (int)(unsigned)(short)(unsigned)((short)(unsigned)h0 > (signed char)r0.x))) {
            if (((a0[i0 & 3u] - (unsigned)(w0 >> 29)) << (0x80000000u & 31u))) {
                a0[u2 & 3u] = ((u1 - u0) << ((unsigned)s0 & 31u));
                b0 = (unsigned)((int)4u >= (int)(unsigned)(3u < (unsigned)((int)*q0 >= (int)g1))) != 0u;
                if (fuel < 8u) return ((unsigned)f0 / ((m0 / ((unsigned)(x0 >> 70) | 1u)) | 1u));
                garr[(unsigned)(0x6761b79du && u2) & 7u] = (unsigned)(u1 || 0x96448321u);
                break; (void)(fuel);
            }
            q0 = &garr[*mp & 7u];
            if ((unsigned)c1) goto L4;
        }
        m0 ^= (unsigned)(short)((v0 | r0.y) | (unsigned)(w0 >> 29));
    }
    d0 = d0 * 0.5 + (double)((unsigned)x0 & 1023u);
    u0 = (unsigned)((u0 << ((unsigned)s0 & 31u)) == (unsigned)((int)(unsigned)w0 < (int)7u));
    *q0 = (unsigned)((unsigned)(i2 == r0.x) == (0x747aaf6cu - i1));
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)0x80000000u < (int)(p2 & (unsigned)s1)), m0, (unsigned)!(unsigned)(g0 < p1)); }
    x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)c1 == (unsigned)(0x9188b34eu == *mp));
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((0xac88074au / (0xffffffffu | 1u)) < i1)) break;
        if (budget != 0u) { budget -= 1u; u3 = fn1((p1 << ((unsigned)w0 & 31u)), (unsigned)((int)(unsigned)x0 >= (int)a0[u1 & 3u]), (i1 | 0xffffffffu)); }
        if ((unsigned)(0x80000000u == (a0[i0 & 3u] | (unsigned)(x0 >> 70)))) continue;
        if ((unsigned)((unsigned)b0 < (unsigned)(4u < 8u))) {
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)garr[u2 & 7u] > (signed char)u2), v0, 0x80000000u); }
            if ((g1 * (unsigned)((unsigned)(x0 >> 70) && (unsigned)h1))) {
                break; (void)((unsigned)!((unsigned)(x0 >> 70) + (unsigned)d0));
                switch (u1 & 7u) {
                    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)c1, 3u, (unsigned)(0xffffffffu && (unsigned)(i2 && 8u))); }
                    u3 += (i1 + (i2 ^ u2));
                }
            }
            x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)(3u / (((unsigned)c1 >> (0x80000000u & 31u)) | 1u));
            r0.y ^= ((~(unsigned)((unsigned)c1 || (unsigned)h0) * r0.y) | 7u);
            while (i1++ < 5u && 6u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)i1 << ((fuel & (unsigned)f0) & 63u);
                d0 = d0 * 0.5 + (double)(((unsigned)c1 % (9u | 1u)) & 1023u);
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)((short)(unsigned)(unsigned char)(unsigned)((0x10000u + 0x10000u) && (unsigned)!(unsigned)((short)0xffffffffu > (signed char)0xd617303eu)) > (signed char)p0);
                    if ((0x7fffffffu / ((unsigned)(unsigned char)(unsigned)((unsigned)b0 && 0x2a9c4896u) | 1u))) goto L0;
                    x0 = x0 * 0x100000001b3ull + (((unsigned)f0 & 0x6080d233u) * 4u);
                }
                u1 = (((unsigned)(a0[i0 & 3u] < (unsigned)b0) - ((unsigned)d0 % (0x1c7b2362u | 1u))) % (0x989e3249u | 1u));
                g1 += ((fuel & 8u) ? (unsigned)s0 : 0xffffffffu);
            }
            do { if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if (((u1 * (unsigned)((int)(unsigned)x0 >= (int)(unsigned)e0))) & 1u) { t1 = v0; z1 = (double)(((r0.y - p0)) & 255u); } if (((u1 * (unsigned)((int)(unsigned)x0 >= (int)(unsigned)e0))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    w0 ^= (unsigned long long)(unsigned)(r0.x == (unsigned)c1) << (((unsigned)h1 % (0xe545dcc0u | 1u)) & 63u);
                    while (i2++ < 4u && v0) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (unsigned)(m0 == ((unsigned)(u1 || u2) >> (m0 & 31u))));
                    }
                    u1 ^= (0x459138e5u * (p2 ^ (unsigned)x0));
                    d0 = d0 * 0.5 + (double)((0x10000u * r0.y) & 1023u);
                    if ((a0[u1 & 3u] & *mp)) break;
                }
                if (0x7fffffffu) continue;
                switch (0xffffffffu & 7u) {
                    *mp = ((unsigned)(p1 && ((unsigned)e0 ^ g0)) / (((unsigned)b0 * 0u) | 1u));
                    break; (void)(0xb53ea716u);
                    garr[(0x7cf161f8u * i2) & 7u] = (unsigned)((unsigned)c0 || (unsigned)((short)(unsigned)(0x6bfb46bfu && (p0 >> (a0[u1 & 3u] & 31u))) > (signed char)(unsigned)x0));
                }
            } while (i1++ < 3u && (unsigned)h1);
        } else {
            h1 = (unsigned short)(h1 + (((unsigned)((int)u0 < (int)p2) - 0x7fffffffu) / (g1 | 1u)));
        }
        do { if (--fuel == 0u) goto done;
            if (7u) {
                if ((unsigned)(0xffffffffu || (unsigned)d0)) break;
                garr[(unsigned)((short)i1 > (signed char)(unsigned)(w0 >> 29)) & 7u] = (0x80000000u % (0x25c4fd61u | 1u));
                break; (void)((unsigned)(r0.x == a0[u1 & 3u]));
                do { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return ((unsigned)((unsigned)c0 == (unsigned)((int)m0 >= (int)v0)) ^ 0x80000000u);
                    if (garr[u2 & 7u]) break;
                    v0 = (unsigned)((unsigned)(0xffffffffu || (6u & (unsigned)l0)) < (unsigned)l0);
                    if (budget != 0u) { budget -= 1u; u0 = fn0(0x80000000u, 0xc14a7abu, ((unsigned)(4u && 0xffffffffu) - u2)); }
                    L4: if (--fuel == 0u) goto done;
                } while (i2++ < 4u && (unsigned)c0);
            } else {
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)l0 || ((unsigned)s0 / ((unsigned)(x0 >> 70) | 1u))), a0[i0 & 3u], u3); }
            }
        } while (i1++ < 3u && (-(unsigned)((int)(unsigned)x0 >= (int)u1) / ((unsigned)h1 | 1u)));
    }
    { unsigned t2; double z2; if (((9u * r0.y)) & 1u) { t2 = u1; z2 = (double)(((unsigned)(w0 >> 29)) & 255u); } if (((9u * r0.y)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        if (budget != 0u) { budget -= 1u; u0 = fn0(-(u0 ^ (unsigned)((int)garr[i1 & 7u] >= (int)m0)), (unsigned)(0x891492u && (unsigned)f0), ~(0x10000u << (0x7fffffffu & 31u))); }
        if ((unsigned)(unsigned char)(unsigned)((int)r0.x >= (int)0xcda0b2f5u)) {
            s1 = (int)((unsigned)s1 + (unsigned)((*mp - g1) == (unsigned)x0));
            u3 = u3 * 0x9e3779b1u + (*mp + i2);
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(0xe24a2c7au && garr[u2 & 7u]) == 0x34cd5088u) & 1023u);
                l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)(4u || 0u) - 0xb9bd6dfbu) < (int)4u));
                do { if (--fuel == 0u) goto done;
                    break; (void)(fuel);
                } while (i1++ < 3u && ((unsigned)c1 & r0.y));
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)x0 < (int)(unsigned)((short)8u > (signed char)0xffffffffu)), i0, (unsigned)(0xf2de522u == (unsigned)(0x4d7747f3u == (unsigned)l0))); }
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((-(0x10000u % ((unsigned)s1 | 1u)) + *mp)) {
                        goto L0;
                        c1 = (signed char)(unsigned)(*q0 || ((unsigned)((unsigned)(w0 >> 29) == 0x45aeac0u) & (p0 / (a0[i0 & 3u] | 1u))));
                        c0 = (unsigned char)((unsigned)(w0 >> 29) | ((unsigned)(short)(unsigned)(u3 && u0) % (fuel | 1u)));
                        continue; (void)(0x8af62d33u);
                    } else {
                        w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)(0xffffffffu & ((unsigned)f0 % ((unsigned)h0 | 1u)));
                        c1 = (signed char)(0x66499316u * 0xe506d411u);
                        break; (void)((a0[u1 & 3u] / ((unsigned)(6u || 0x94d0e1c3u) | 1u)));
                    }
                }
            }
            if (fuel < 8u) return (((unsigned)((int)m0 >= (int)(unsigned)l0) >> (0xf8277adu & 31u)) | (unsigned)e0);
            if ((0xa158cd68u >> ((0xffffffffu ^ g1) & 31u))) {
                if (0x7302c984u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn1(-(unsigned)((short)(unsigned)((short)0x7fffffffu > (signed char)m0) > (signed char)4u), (unsigned)((int)(unsigned)f0 >= (int)(unsigned)!(1u | v0)), (unsigned)((int)(unsigned)((short)i2 > (signed char)(unsigned)(x0 >> 70)) >= (int)0x10000u)); }
                if ((unsigned)(a0[u1 & 3u] && u1)) goto L3;
                if (i2) goto L1;
                w0 ^= (unsigned long long)(unsigned)(short)((unsigned)c0 >> (6u & 31u)) << ((0xfa977e17u * (unsigned)((short)g0 > (signed char)m0)) & 63u);
            } else {
                if ((g0 >> (2u & 31u))) goto L1;
                g1 += (unsigned)(~(0x8c6626a3u >> (0x80000000u & 31u)) == 0x9bcd30e6u);
                s0 = (int)((r0.x - u0) + (unsigned)(*mp == 8u));
            }
        } else {
            if (*mp) goto L1;
            q0 = &garr[(unsigned)(signed char)(unsigned)((short)((7u / ((unsigned)f0 | 1u)) * p0) > (signed char)(unsigned)(0xad0bbffbu && (unsigned)h1)) & 7u];
        }
    }
    s1 = (int)((unsigned)s1 + (a0[i0 & 3u] % ((unsigned)((short)(unsigned)x0 > (signed char)garr[i1 & 7u]) | 1u)));
    if ((unsigned)(x0 >> 70)) goto L2;
    if (fuel) goto done;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (3u) {
            if (budget != 0u) { budget -= 1u; u0 = fn0((g1 + i1), (unsigned)((unsigned)f0 || (unsigned)c0), ~(unsigned)((int)8u >= (int)0xd1a3431eu)); }
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                garr[(0x3eb3308au % (g1 | 1u)) & 7u] = (0xa0168b50u * (unsigned)h1);
                u1 = (0x730549c5u | 0x95b8fe5fu);
                u1 = u1 * 0x9e3779b1u + (unsigned)(i2 == m0);
                v0 = -((0x10000u + (unsigned)c1) >> (*mp & 31u));
            }
            goto L2;
            u3 += ((unsigned)!(unsigned)((unsigned)s0 < (unsigned)h0) ? 0x7288e06cu : g1);
            switch (((unsigned)c1 + (0x24f86df3u + (unsigned)e0)) & 7u) {
                r0.x = (4u ^ 0xffffffffu);
            }
            continue; (void)((unsigned)((unsigned)(w0 >> 29) && (unsigned)c0));
        } else {
            x0 = x0 * 0x100000001b3ull + ((unsigned)h1 * (unsigned)(short)(unsigned)((short)((unsigned)w0 - 0x80000000u) > (signed char)-(g0 + 5u)));
        }
        if ((unsigned)((int)0xa414d5a9u < (int)v0)) break;
        u0 = -((unsigned)l0 | (unsigned)(x0 >> 70));
        if (((unsigned)b0 >> (1u & 31u))) break;
    }
    goto L1;
    if ((unsigned)((unsigned)(5u < i0) < u3)) {
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((int)p1 >= (int)*mp) / (6u | 1u)), p0, ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x10000u) >> ((unsigned)b0 & 31u))); }
    } else {
        w0 ^= (unsigned long long)u3 << ((unsigned)c0 & 63u);
        if ((unsigned)(u1 && u3)) goto L4;
        do { if (--fuel == 0u) goto done;
            while (i1++ < 7u && (((unsigned)h1 & (unsigned)w0) + 0x4317dd20u)) { if (--fuel == 0u) goto done;
                *q0 = (((0x80000000u & g1) % (6u | 1u)) >> ((unsigned)(short)(unsigned)(i1 && 0x80000000u) & 31u));
                break; (void)(i2);
                for (;;) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)((short)((fuel | a0[i0 & 3u]) & 0x7fffffffu) > (signed char)(m0 ^ u0));
                }
            }
        } while (i0++ < 4u && ((unsigned)((short)0xba8139beu > (signed char)u3) / (0xe80759b7u | 1u)));
    }
    i0 = (unsigned)(signed char)(g0 ^ (r0.x & (unsigned)x0)) & 15u;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        v0 = (unsigned)c0;
        h1 = (unsigned short)(h1 + (i0 % (((0x80000000u ? a0[u1 & 3u] : (unsigned)l0) % ((unsigned)c0 | 1u)) | 1u)));
        break; (void)((unsigned)((int)(unsigned)f0 < (int)4u));
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn2(8u, 3u, (i2 >> (((unsigned)x0 << (*q0 & 31u)) & 31u))); }
            if (0xffffffffu) goto L3;
            switch (a0[i0 & 3u] & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)!(unsigned)((unsigned)f0 || u2), r0.y, -(unsigned)(u2 < (unsigned)(w0 >> 29))); }
                case 0u: ;
                garr[u3 & 7u] = (unsigned)((unsigned)(w0 >> 29) < (unsigned)d0);
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)m0 >= (int)5u)) {
                        case 5u: ;
                        { unsigned t3; double z3; if ((0x10000u) & 1u) { t3 = ((7u | *q0) + (unsigned)(w0 >> 29)); z3 = (double)((i2) & 255u); } if ((0x10000u) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                            v0 = ((unsigned)(signed char)(fuel * *q0) - (unsigned)((fuel / (a0[i0 & 3u] | 1u)) < 2u));
                        }
                        if ((unsigned)((0x10000u / ((unsigned)h0 | 1u)) == p2)) goto L0;
                    }
                    if ((unsigned)e0) break;
                    continue; (void)((unsigned)(0x10000u < (garr[u2 & 7u] ^ (unsigned)l0)));
                    if (*mp) goto L3;
                }
                s1 = (int)((unsigned)s1 + *q0);
            }
            h0 = (short)((unsigned)(g1 || 0x7fffffffu) & p1);
            if ((unsigned)(((unsigned)b0 & (unsigned)h0) < *q0)) {
                *mp = (unsigned)((short)((unsigned)w0 * (unsigned)(unsigned char)(unsigned)(i2 && fuel)) > (signed char)i0);
                if (a0[i0 & 3u]) break;
                e0 = e0 * 0.5L + (long double)(-(unsigned)((int)(unsigned)l0 < (int)0x10000u) & 1023u);
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)v0 >= (int)(unsigned)((unsigned)l0 || (unsigned)e0));
                if ((unsigned)s0) {
                    x0 = x0 * 0x100000001b3ull + (unsigned)((int)((unsigned)(signed char)((unsigned)e0 & 0xe72c3de6u) % (u3 | 1u)) < (int)(unsigned)h1);
                }
            }
        }
        if ((unsigned)((unsigned)s0 && 0xffffffffu)) break;
    }
    if ((m0 & (4u % (u1 | 1u)))) goto L4;
    if ((unsigned)(0x10000u == (*mp - (unsigned)s0))) goto L2;
    if ((unsigned)((int)0x92ed98c8u < (int)(unsigned)h1)) {
        goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn1(0xffffffffu, ((unsigned)h1 & (unsigned)e0), p1); }
    }
    r0.y ^= (unsigned)e0;
    g0 = ((unsigned)((unsigned)l0 < 0xb38c8308u) ? (unsigned)((short)p1 > (signed char)i2) : 0xf734f506u);
    while (i0++ < 2u && 3u) { if (--fuel == 0u) goto done;
        while (i1++ < 4u && (unsigned)(r0.x || ((unsigned)(w0 >> 29) / ((unsigned)l0 | 1u)))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)(unsigned)w0 >= (int)r0.y), ((unsigned)((int)i1 >= (int)p1) ^ (unsigned)e0), ((a0[u1 & 3u] * *mp) % ((unsigned)e0 | 1u))); }
            i0 = ((unsigned)(m0 || r0.x) % (g1 | 1u)) & 15u;
            if ((garr[u2 & 7u] - 0xf2d11efeu)) continue;
        }
        c0 = (unsigned char)(((unsigned)f0 % (r0.y | 1u)) & 4u);
        do { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)(w0 >> 29) << (g0 & 63u);
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(0xa2574b19u == 5u), p1, (unsigned)(v0 == a0[i0 & 3u])); }
            }
            while (u0) { if (--fuel == 0u) goto done;
                { unsigned t4; double z4; if (((0x6c9210aau % (0x10000u | 1u))) & 1u) { t4 = (a0[u1 & 3u] << ((unsigned)(m0 && 9u) & 31u)); z4 = (double)((0x10000u) & 255u); } if (((0x6c9210aau % (0x10000u | 1u))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    c1 = (signed char)(~((unsigned)((int)0xffffffffu < (int)u0) & a0[i0 & 3u]) >> ((unsigned)w0 & 31u));
                }
            }
            r0.y ^= 0x80000000u;
            if (budget != 0u) { budget -= 1u; u1 = fn0(0x13cabd35u, 9u, (unsigned)(i2 < (unsigned)h1)); }
            while (i2++ < 3u && (unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
                { unsigned t5; double z5; if (((unsigned)((0x7fffffffu << (0x60487ae9u & 31u)) || 0x1d4e160cu)) & 1u) { t5 = (unsigned)(0x59dcb864u < (unsigned)x0); z5 = (double)((3u) & 255u); } if (((unsigned)((0x7fffffffu << (0x60487ae9u & 31u)) || 0x1d4e160cu)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                    if ((unsigned)(0xe1ff8517u < (unsigned)h1)) {
                        if ((unsigned)((unsigned)w0 < p1)) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((r0.x & (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)l0)), 0xa86b9df1u, r0.x); }
                        h1 = (unsigned short)(h1 + (unsigned)(signed char)(3u - (unsigned)((unsigned)(w0 >> 29) || 0u)));
                        h1 = (unsigned short)(h1 + (unsigned)c1);
                        if ((unsigned)(signed char)(0xbcc18047u + (unsigned)(v0 || 1u))) {
                            h1 = (unsigned short)(h1 + (unsigned)((unsigned)b0 || (unsigned)e0));
                            break; (void)((r0.y % ((fuel & garr[i1 & 7u]) | 1u)));
                            garr[(unsigned)h0 & 7u] = ((unsigned)d0 & (p2 ? p2 : (p2 | 0x7fffffffu)));
                            if ((a0[i0 & 3u] ^ (unsigned)(0x80000000u || g1))) continue;
                            w0 = w0 * 6364136223846793005ull + ((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)h0) - p2);
                        }
                        u0 ^= ((0x7fffffffu >> ((unsigned)((int)g0 < (int)garr[u2 & 7u]) & 31u)) | r0.y);
                    } else {
                        if (fuel) break;
                    }
                    if (((unsigned)w0 % (0x10000u | 1u))) break;
                    h0 = (short)(unsigned)(short)(unsigned)(g0 || (unsigned)(x0 >> 70));
                    if (u3 == 7u) return (0x5e055e27u & g0);
                    m0 ^= (((unsigned)(w0 >> 29) >> ((0xffffffffu + u3) & 31u)) >> (((unsigned)h1 - garr[u2 & 7u]) & 31u));
                }
            }
        } while (i1++ < 2u && (0x562ebb13u / ((unsigned)c0 | 1u)));
        if (budget != 0u) { budget -= 1u; u1 = fn0(p2, ((unsigned)s1 - a0[u1 & 3u]), 0x986e4f35u); }
    }
    switch ((unsigned)(6u && (unsigned)(x0 >> 70)) & 7u) {
        r0.y ^= (0x49fff290u ^ ~(unsigned)(u3 == 0xaf43b137u));
        case 6u: ;
        w0 ^= (unsigned long long)0x95ad05a7u << ((unsigned)((int)*mp >= (int)p0) & 63u);
        { unsigned t6; double z6; if ((((unsigned)d0 & (unsigned)((int)(unsigned)l0 >= (int)a0[u1 & 3u]))) & 1u) { t6 = (unsigned)(short)(((unsigned)s0 >> (6u & 31u)) >> ((unsigned)e0 & 31u)); z6 = (double)((0x80000000u) & 255u); } if ((((unsigned)d0 & (unsigned)((int)(unsigned)l0 >= (int)a0[u1 & 3u]))) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            if ((unsigned)(short)((unsigned)e0 | (m0 & (unsigned)x0))) {
                a0[(unsigned)(a0[u1 & 3u] || 0x7fffffffu) & 3u] = (unsigned)((int)*mp >= (int)(unsigned)h0);
            }
            v0 = (0xc1c12301u | (m0 << ((unsigned)((int)(unsigned)h0 >= (int)(unsigned)(short)(0x10000u % (i2 | 1u))) & 31u)));
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (u3 == 7u) return (unsigned)((int)~(*q0 | *q0) >= (int)(unsigned)((int)0x15ff0cdeu < (int)(unsigned)((int)r0.x >= (int)2u)));
        }
        if (((unsigned)(unsigned char)((unsigned)s0 * g1) | 0x24e31f0bu)) goto L1;
    }
    goto done;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 += ((unsigned)x0 * (unsigned)(p2 < (unsigned)(w0 >> 29)));
        if (budget != 0u) { budget -= 1u; u2 = fn1(a0[i0 & 3u], (unsigned)(signed char)(g0 >> ((unsigned)(x0 >> 70) & 31u)), (unsigned)(9u == v0)); }
        r0.x = ((unsigned)(fuel || (r0.y << (0xcf538708u & 31u))) % (u0 | 1u));
        switch ((unsigned)(p2 && 0x40a2d525u) & 7u) {
            if (budget != 0u) { budget -= 1u; u2 = fn0(fuel, ((unsigned)((short)(unsigned)s0 > (signed char)a0[u1 & 3u]) & (unsigned)h1), fuel); }
        }
    }
    if ((unsigned)((unsigned)c0 && 6u)) goto done;
    if ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)fuel)) {
        if ((r0.y / (2u | 1u))) goto done;
        *q0 = i1;
        if (budget != 0u) { budget -= 1u; u3 = fn2(6u, (unsigned)(0xab64a905u == u2), (u1 >> (0u & 31u))); }
    } else {
        if (((i0 * 9u) + (unsigned)f0)) goto done;
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                b0 = (fuel | ((unsigned)d0 ^ (unsigned)(w0 >> 29))) != 0u;
            } while (i1++ < 6u && ((unsigned)!(unsigned)(*mp || *q0) | 0x80000000u));
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)m0;
                a0[(unsigned)((unsigned)h1 || (unsigned)e0) & 3u] = (u1 << (0x10000u & 31u));
                if (budget != 0u) { budget -= 1u; u1 = fn1((0x25e2569fu / (garr[u2 & 7u] | 1u)), (unsigned)(signed char)(i1 & 1u), (unsigned)c0); }
                e0 = e0 * 0.5L + (long double)((unsigned)!(u1 + (unsigned)(unsigned char)(4u >> (0xffffffffu & 31u))) & 1023u);
            }
            switch ((u1 / ((u2 - u0) | 1u)) & 7u) {
                case 1u: ;
                do { if (--fuel == 0u) goto done;
                    g1 += (unsigned)h0;
                    case 0u: ;
                } while (i1++ < 6u && (a0[u1 & 3u] ^ 0x7fffffffu));
            }
            u3 ^= (r0.x | (0x10000u % ((unsigned)h1 | 1u)));
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)!(r0.x % (fuel | 1u)), (unsigned)s0, ((unsigned)h1 / ((r0.y ^ fuel) | 1u))); }
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t7; double z7; if (((unsigned)((int)0x7fffffffu >= (int)((unsigned)s1 / (g1 | 1u)))) & 1u) { t7 = (unsigned)c0; z7 = (double)(((unsigned)((short)0xba0c519cu > (signed char)0x40a911c2u)) & 255u); } if (((unsigned)((int)0x7fffffffu >= (int)((unsigned)s1 / (g1 | 1u)))) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                    u1 = u1 * 0x9e3779b1u + (0x67d7dca9u + (unsigned)(0x10000u && i0));
                    if ((unsigned)(garr[u2 & 7u] < (unsigned)(0xffffffffu || (unsigned)x0))) goto done;
                    if ((5u % ((*q0 << (0x7fffffffu & 31u)) | 1u))) break;
                    *mp = (v0 * (unsigned)((int)r0.x >= (int)((unsigned)w0 / (2u | 1u))));
                }
                c0 = (unsigned char)-(unsigned)((short)u2 > (signed char)(0xf15cc54fu | 0x6c16abfau));
                if ((g1 / ((0x7fffffffu * i2) | 1u))) break;
            }
        }
        if ((unsigned)(signed char)(unsigned)((short)(unsigned)(garr[i1 & 7u] && i0) > (signed char)0xffffffffu)) {
            u1 ^= (unsigned)((short)r0.y > (signed char)(*q0 | (unsigned)((int)g1 < (int)0xfcc4dbe6u)));
            u1 = (((unsigned)s1 & r0.x) | (0x20ae558bu % ((unsigned)((short)(unsigned)s0 > (signed char)0x10000u) | 1u)));
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)((int)-(u2 + 8u) < (int)((unsigned)c0 & (unsigned)((unsigned)h1 || u1)));
                *q0 = (unsigned)(unsigned char)((-(unsigned)((short)(unsigned)(g1 && 2u) > (signed char)2u) + 0xe5d44f1u) + 0xffffffffu);
                *q0 += -(0x7fffffffu & g0);
                continue; (void)((unsigned)h0);
                do { if (--fuel == 0u) goto done;
                    if (0x7fffffffu) break;
                    switch ((5u | (unsigned)e0) & 7u) {
                        switch ((0xffffffffu >> ((a0[u1 & 3u] + r0.y) & 31u)) & 7u) {
                            garr[(unsigned)(i2 == (unsigned)(x0 >> 70)) & 7u] = (unsigned)(0xb43fc228u || 0x10000u);
                            if ((i1 - *q0)) break;
                            case 5u: ;
                            c0 = (unsigned char)(g1 * (u0 >> (m0 & 31u)));
                            if ((7u & (unsigned)c1)) break;
                            if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)h1 * (unsigned)w0), (unsigned)((unsigned)((int)(unsigned)x0 < (int)(unsigned)x0) || garr[i1 & 7u]), (unsigned)(short)((unsigned)((short)4u > (signed char)(unsigned)h0) * i1)); }
                        }
                        s1 = (int)((unsigned)s1 + 0x7fffffffu);
                        b0 = (unsigned)((short)(unsigned)h1 > (signed char)(0x7fffffffu << ((unsigned)c1 & 31u))) != 0u;
                        goto L0;
                    }
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        g0 = (unsigned)(short)(unsigned)((int)(unsigned)b0 >= (int)(unsigned)h0);
                        break; (void)(garr[i1 & 7u]);
                        v0 = a0[u1 & 3u];
                    }
                    break; (void)((unsigned)((int)p2 >= (int)u1));
                } while (i1++ < 4u && (unsigned)((int)a0[u1 & 3u] >= (int)(u0 | u1)));
            }
            if (i0) goto L0;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(short)(unsigned)((unsigned)h1 || (unsigned)(short)(p1 ^ 0xe949e7c7u)), (unsigned)((int)0xc522d6e4u < (int)(unsigned)(w0 >> 29)), ~(g0 | (unsigned)(x0 >> 70))); }
            { unsigned t8; double z8; if (((unsigned)((unsigned)b0 && *mp)) & 1u) { t8 = (6u / (((unsigned)c1 >> ((unsigned)w0 & 31u)) | 1u)); z8 = (double)(((unsigned)(0xffffffffu < p0)) & 255u); } if (((unsigned)((unsigned)b0 && *mp)) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                for (;;) { if (--fuel == 0u) goto done;
                    u2 = u2 * 0x9e3779b1u + r0.y;
                    f0 = f0 * 0.5f + (float)(a0[i0 & 3u] & 255u);
                }
                l0 = (long)((unsigned long)l0 + (r0.x ^ 0x614706dcu));
                h0 = (short)((unsigned)((int)0x10000u < (int)(unsigned)x0) ^ u1);
                goto L4;
                if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)(short)(9u << (0x7fffffffu & 31u)) / (u0 | 1u)), 4u, -((unsigned)h0 - 0xc269e805u)); }
            }
        } else {
            s0 = (int)garr[i1 & 7u];
            w0 = w0 * 6364136223846793005ull + (unsigned)x0;
            if ((unsigned)(signed char)(4u + 7u)) goto L1;
        }
    }
    if ((unsigned)((unsigned)((unsigned)c0 && 0x9baaa979u) < (unsigned)f0)) goto done;
    b0 = (unsigned)((unsigned)((short)1u > (signed char)u1) && (unsigned)((u1 + (unsigned)w0) < a0[u1 & 3u])) != 0u;
    *q0 = r0.x;
    do { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)((int)(unsigned)(i1 < 0xffffffffu) < (int)(unsigned)(0x10000u || (unsigned)(x0 >> 70))));
        if ((fuel + v0)) {
            break; (void)(((unsigned)((int)0x873f7a23u >= (int)r0.x) ^ 0xffffffffu));
            if (budget != 0u) { budget -= 1u; u2 = fn0(u1, (v0 - 0xffffffffu), (unsigned)((int)(unsigned)h0 < (int)(unsigned)(x0 >> 70))); }
            if ((unsigned)((int)a0[u1 & 3u] >= (int)0xf63e10f6u)) continue;
            s0 = (int)(unsigned)s1;
            s1 = (int)((unsigned)s1 + (a0[i0 & 3u] << (0x8c1d2b1du & 31u)));
        }
        while (i1++ < 2u && 0x80000000u) { if (--fuel == 0u) goto done;
            goto done;
            switch ((0x80000000u + 0x7fffffffu) & 7u) {
                { unsigned t9; double z9; if ((1u) & 1u) { t9 = 3u; z9 = (double)((0xc614cb4eu) & 255u); } if ((1u) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                    if (budget != 0u) { budget -= 1u; u3 = fn1(((garr[u2 & 7u] * (unsigned)c1) & i0), (9u >> (3u & 31u)), (unsigned)c0); }
                    b0 = (unsigned)((r0.y >> (g1 & 31u)) && (unsigned)!(unsigned)((g0 / (2u | 1u)) < (unsigned)c1)) != 0u;
                    *q0 += ((unsigned)((unsigned)f0 && (0x80000000u / (garr[i1 & 7u] | 1u))) & garr[i1 & 7u]);
                }
                *q0 += (unsigned)((unsigned)s1 && (unsigned)((int)*q0 < (int)3u));
                u1 += (unsigned)w0;
                case 7u: ;
                if (budget != 0u) { budget -= 1u; u3 = fn1((1u - (m0 * fuel)), (unsigned)(r0.y == 6u), g0); }
            }
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                while (i0++ < 6u && *q0) { if (--fuel == 0u) goto done;
                    *q0 += fuel;
                    do { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)((unsigned)s1 < 7u)) && *q0));
                        garr[(i1 - p1) & 7u] = (unsigned)((int)((unsigned)(w0 >> 29) | p2) < (int)(unsigned)(x0 >> 70));
                    } while (i1++ < 4u && (unsigned)(0x10000u && (unsigned)b0));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((0xffffffffu | 6u), (0xec5ca501u - 0x4158a63cu), (unsigned)((int)(unsigned)l0 >= (int)p0)); }
                    if ((0x4557786u / (u0 | 1u))) break;
                    if ((unsigned)(((unsigned)(w0 >> 29) << ((unsigned)w0 & 31u)) < 0x7fffffffu)) goto L2;
                }
                if ((unsigned)f0) {
                    q0 = &garr[((unsigned)(p1 && (i0 << (0x7fffffffu & 31u))) / (0xa2c12af0u | 1u)) & 7u];
                }
                l0 = (long)((unsigned long)l0 + ((unsigned)(short)(0u ^ 0x4d06fb37u) / (i0 | 1u)));
            }
        }
        u2 ^= (unsigned)((int)0x4724d316u >= (int)i1);
    } while (i0++ < 5u && garr[i1 & 7u]);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)s0, (garr[i1 & 7u] / (p0 | 1u)), (unsigned)((int)u0 < (int)m0)); }
        if (fuel < 8u) return (unsigned)(short)((unsigned)h0 * (unsigned)(u1 || (unsigned)((int)(unsigned)w0 >= (int)(unsigned)s0)));
        L0: if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)(((unsigned)c1 >> ((unsigned)s0 & 31u)) & 1023u);
        w0 ^= (unsigned long long)(6u & r0.y) << ((unsigned)(unsigned char)((0x10000u | 0x80000000u) - ((unsigned)x0 ? u1 : *mp)) & 63u);
    } while (i0++ < 6u && 0xffffffffu);
    w0 = w0 * 6364136223846793005ull + v0;
    { unsigned t0; double z0; if ((0xffffffffu) & 1u) { t0 = (unsigned)((short)0xffffffffu > (signed char)0x7fffffffu); z0 = (double)(((unsigned)((int)v0 >= (int)(unsigned)b0)) & 255u); } if ((0xffffffffu) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        if (5u) goto L1;
        goto L4;
        m0 ^= (unsigned)(signed char)(unsigned)(0x10000u < r0.y);
        garr[(4u >> ((unsigned)(x0 >> 70) & 31u)) & 7u] = ((unsigned)((unsigned)w0 < 0x7fffffffu) & u0);
    }
    if ((0x7fffffffu ? garr[i1 & 7u] : r0.y)) {
        if (budget != 0u) { budget -= 1u; u3 = fn1((((unsigned)x0 - 1u) >> (0x7fffffffu & 31u)), 0u, (unsigned)(*mp && (unsigned)h0)); }
        m0 ^= (unsigned)(unsigned char)(((unsigned)((short)(m0 % (0x80000000u | 1u)) > (signed char)0x10000u) * 0x54b81319u) & 0x6152a18cu);
        if (((unsigned)(p2 < 0xdcd8801u) * 0u)) {
            q0 = &garr[(unsigned)(0xbf70cd96u || g1) & 7u];
            c1 = (signed char)~(unsigned)((int)(unsigned)((unsigned)w0 && u2) < (int)(unsigned)(garr[u2 & 7u] == 0xf9308178u));
            L1: if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((((unsigned)x0 ? (unsigned)h1 : 0x8496f238u) % ((unsigned)c1 | 1u)) & 255u);
            r0.x = ((unsigned)(i2 || (unsigned)c1) + (unsigned)(signed char)(unsigned)((int)u2 < (int)garr[i1 & 7u]));
            c1 = (signed char)(unsigned)((short)u2 > (signed char)0x80000000u);
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0((0x10000u - (unsigned)((int)(unsigned)l0 < (int)0x9d77f76eu)), 0x49d0ad14u, (unsigned)((unsigned)((unsigned)s1 == i1) == r0.y)); }
        if ((unsigned)!(unsigned)((int)0x10000u >= (int)-(0x7fffffffu + (unsigned)w0))) goto L1;
        *mp = (unsigned)w0;
    } else {
        if (budget != 0u) { budget -= 1u; u3 = fn0((0x10000u & (unsigned)f0), (v0 << ((unsigned)d0 & 31u)), (u1 >> (~(garr[i1 & 7u] | garr[i1 & 7u]) & 31u))); }
        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(w0 >> 29) == g0));
        c0 = (unsigned char)(0x30004b00u ? i2 : m0);
        m0 ^= (((unsigned)((int)p0 < (int)((unsigned)h1 >> (9u & 31u))) | 0x82d55db5u) % ((unsigned)l0 | 1u));
    }
    *q0 += (unsigned)(signed char)(2u * i2);
    if (0x80000000u) {
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            v0 = u0;
        }
        switch (0x80000000u & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn3((6u * p2), (u0 | 0x27391d6du), (unsigned)w0); }
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                i0 = ((unsigned)(1u < (unsigned)c1) % ((0x10000u | (p0 >> ((unsigned)x0 & 31u))) | 1u)) & 15u;
                g0 = (unsigned)((short)i0 > (signed char)p2);
                e0 = e0 * 0.5L + (long double)(0x80000000u & 1023u);
                L2: if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (unsigned)(unsigned char)((unsigned)((int)0x9860e81fu < (int)(unsigned)s1) | ((unsigned)(x0 >> 70) + i1)));
                    if ((i2 >> (m0 & 31u))) break;
                    if (u3 == 7u) return (2u >> (g1 & 31u));
                    s1 = (int)((unsigned)s1 + (0xffffffffu << ((unsigned)d0 & 31u)));
                    break; (void)((unsigned)((unsigned)(a0[i0 & 3u] < (unsigned)c0) < r0.y));
                    if (i1) continue;
                }
            }
        }
        if (0x3042fd3fu) goto L0;
        i0 = (*q0 - (unsigned)(1u == 0xd64c681u)) & 15u;
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        continue; (void)((7u << (3u & 31u)));
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            u2 = u2;
        }
        { unsigned t1; double z1; if (((unsigned)((int)r0.y < (int)(unsigned)((int)7u >= (int)(unsigned)s0))) & 1u) { t1 = 0x34c43620u; z1 = (double)(((unsigned)((unsigned)!(unsigned)(0xffffffffu && g1) && 0xdd798b29u)) & 255u); } if (((unsigned)((int)r0.y < (int)(unsigned)((int)7u >= (int)(unsigned)s0))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            switch ((unsigned)((unsigned)l0 < (unsigned)w0) & 7u) {
                if (u1) break;
                switch ((i0 ? 0x906e0c4du : garr[u2 & 7u]) & 7u) {
                    if (v0) goto L4;
                }
                if (-((unsigned)f0 - m0)) break;
            }
        }
        w0 ^= (unsigned long long)(unsigned)x0 << (((unsigned)b0 - u1) & 63u);
    }
    { unsigned t2; double z2; if (((unsigned)!((r0.x | (unsigned)x0) | a0[u1 & 3u])) & 1u) { t2 = (unsigned)(7u == (u0 << (0x80000000u & 31u))); z2 = (double)((((unsigned)h1 * (g1 % (r0.y | 1u)))) & 255u); } if (((unsigned)!((r0.x | (unsigned)x0) | a0[u1 & 3u])) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(v0 < (unsigned)x0) < (int)(unsigned)((short)g1 > (signed char)a0[u1 & 3u])));
        { unsigned t3; double z3; if ((garr[u2 & 7u]) & 1u) { t3 = (unsigned)((short)(unsigned)((int)(unsigned)s1 < (int)g0) > (signed char)(unsigned)h1); z3 = (double)(((unsigned)c1) & 255u); } if ((garr[u2 & 7u]) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            a0[garr[u2 & 7u] & 3u] = ((unsigned)d0 + 0x16747da9u);
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2(u3, (unsigned)(5u == (2u | (unsigned)s1)), (unsigned)(unsigned char)((unsigned)l0 ^ 0xffffffffu)); }
                w0 = w0 * 6364136223846793005ull + (((unsigned)((unsigned)b0 || g0) ? 9u : 0xd2194ef3u) | u3);
            } while (i1++ < 4u && (u3 % (0x10000u | 1u)));
            break; (void)(garr[i1 & 7u]);
            if (1u) goto L2;
        }
        if (((unsigned)d0 % (u1 | 1u))) goto L0;
        switch (u1 & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn3((i2 | (unsigned)b0), ((unsigned)((int)(unsigned)h0 < (int)a0[i0 & 3u]) * p1), (unsigned)!(0x80000000u << (*q0 & 31u))); }
            c0 = (unsigned char)(unsigned)(0x7c0136b8u == (unsigned)b0);
            if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)s0 / (a0[u1 & 3u] | 1u)), (unsigned)((unsigned)w0 || (unsigned)b0), ((unsigned)(signed char)(unsigned)((short)(unsigned)e0 > (signed char)0u) & a0[u1 & 3u])); }
            d0 = d0 * 0.5 + (double)(((0x80000000u >> (~(g0 | 7u) & 31u)) << ((unsigned)((int)(unsigned)s0 >= (int)(unsigned)d0) & 31u)) & 1023u);
        }
    }
    u3 ^= ((a0[u1 & 3u] & u2) / (i0 | 1u));
    { unsigned t4; double z4; if ((u1) & 1u) { t4 = ((unsigned)d0 | *q0); z4 = (double)(((u2 % (u3 | 1u))) & 255u); } if ((u1) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        c0 = (unsigned char)u3;
        m0 ^= (unsigned)((short)m0 > (signed char)(unsigned)(0x22be0e91u && u1));
        *q0 += ((unsigned)((int)0x80000000u >= (int)a0[u1 & 3u]) - 0x9e416838u);
    }
    { unsigned t5; double z5; if ((0x10000u) & 1u) { t5 = ((unsigned)s0 - (unsigned)(x0 >> 70)); z5 = (double)((((unsigned)x0 - 0x10000u)) & 255u); } if ((0x10000u) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
        if ((0x80000000u << ((unsigned)f0 & 31u))) goto L1;
        if ((unsigned)((0x10000u - 5u) || (unsigned)l0)) goto L2;
        b0 = 0x7fffffffu != 0u;
        s0 = (int)(a0[u1 & 3u] - (unsigned)((int)((unsigned)e0 & 3u) < (int)(unsigned)l0));
    }
    s1 = (int)((unsigned)s1 + garr[u2 & 7u]);
    if (budget != 0u) { budget -= 1u; u3 = fn1((p0 ^ (unsigned)e0), ((unsigned)(u2 || g0) / (0x103871f2u | 1u)), ~((0x7fffffffu - (unsigned)s1) ^ garr[u2 & 7u])); }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((((unsigned)h1 - (unsigned)l0) >> (u3 & 31u))) break;
        u2 = (unsigned)(x0 >> 70);
        u3 ^= -(unsigned)(a0[u1 & 3u] || 0x6104c76eu);
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(4u || m0), (unsigned)((unsigned)((unsigned)h1 == garr[i1 & 7u]) < 7u), (unsigned)(w0 >> 29)); }
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)((int)(unsigned)s1 < (int)(3u ^ u0));
        if ((unsigned)(0x3e784961u == 6u)) break;
        if (budget != 0u) { budget -= 1u; u1 = fn0(garr[u2 & 7u], (unsigned)(short)(v0 ^ (unsigned)s0), i1); }
        i0 = (unsigned)((int)(unsigned)((short)0x97e76d25u > (signed char)5u) < (int)(unsigned)((g1 >> (0x80000000u & 31u)) || (unsigned)(w0 >> 29))) & 15u;
    }
    goto L0;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            a0[i0 & 3u] = (unsigned)(unsigned char)(((r0.y % (i0 | 1u)) << (r0.x & 31u)) | fuel);
            if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((short)(0x7fffffffu & 0x80000000u) > (signed char)u0), (unsigned)(short)((unsigned)e0 & ((unsigned)x0 >> (u0 & 31u))), (i1 / (u1 | 1u))); }
            i0 = ((unsigned)(signed char)(unsigned)((short)0x5afd2c3au > (signed char)(unsigned)e0) << (((unsigned)(w0 >> 29) | (unsigned)c0) & 31u)) & 15u;
        }
        u1 += (3u ^ (unsigned)s1);
        g1 += (unsigned)h1;
        { unsigned t6; double z6; if (((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)((unsigned)s1 == r0.x))) & 1u) { t6 = (0xffffffffu >> ((0x51c74ba2u - r0.x) & 31u)); z6 = (double)(((((unsigned)x0 >> (g1 & 31u)) - g0)) & 255u); } if (((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)((unsigned)s1 == r0.x))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            if (budget != 0u) { budget -= 1u; u3 = fn3(0x80000000u, (unsigned)(0x10000u && 0x7feef80u), (unsigned)(w0 >> 29)); }
            for (;;) { if (--fuel == 0u) goto done;
                g0 = 0xffffffffu;
                *q0 = ((unsigned)(short)((unsigned)((short)(unsigned)c1 > (signed char)0xb6bd19au) * (unsigned)f0) << ((unsigned)(x0 >> 70) & 31u));
                if (0x80000000u) {
                    if (~((unsigned)(0x80000000u || (unsigned)b0) << (g1 & 31u))) continue;
                    switch ((-(*mp ^ 0x492368b0u) | 3u) & 7u) {
                        h0 = (short)(unsigned)((unsigned)((unsigned)b0 == (u1 % (u0 | 1u))) == (unsigned)x0);
                    }
                    if ((u3 % (p1 | 1u))) break;
                    if ((unsigned)c1) break;
                } else {
                    if (budget != 0u) { budget -= 1u; u3 = fn0(r0.x, 7u, ~(i2 >> (((unsigned)b0 & 0u) & 31u))); }
                }
            }
            c0 = (unsigned char)(unsigned)(r0.x && 0xffffffffu);
        }
        if ((unsigned)((short)(unsigned)c0 > (signed char)6u)) break;
    }
    r0.y ^= (i2 | 0x7cc1310u);
    if ((0x55838065u & (garr[i1 & 7u] - 4u))) {
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (unsigned)e0;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(p0 && u1), (unsigned)((unsigned)f0 < 0x7fffffffu), (unsigned)!(unsigned)((int)0x37d2a185u >= (int)a0[i0 & 3u])); }
        if (((unsigned)x0 | u0)) goto L3;
    } else {
        if (u0) goto L1;
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((unsigned)e0 < 2u), (unsigned)((0x7fffffffu + 0xffffffffu) < 0x7fffffffu), 0xa8690458u); }
        do { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)r0.x > (signed char)(unsigned)(i1 == 0xffffffffu)), *mp, (1u % (0x80000000u | 1u))); }
                x0 = x0 * 0x100000001b3ull + (unsigned)e0;
                { unsigned t7; double z7; if (((unsigned)((unsigned)l0 || u2)) & 1u) { t7 = ((unsigned)(signed char)(unsigned)(u0 || 8u) & 0x7fffffffu); z7 = (double)(((unsigned)s0) & 255u); } if (((unsigned)((unsigned)l0 || u2)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                    if (m0) {
                        q0 = &garr[(unsigned)(p2 == (4u ? m0 : (unsigned)(x0 >> 70))) & 7u];
                        u2 = u2 * 0x9e3779b1u + (unsigned)((unsigned)((unsigned)!(unsigned)((int)p1 >= (int)0x40614ccfu) == (unsigned)f0) < fuel);
                        if (budget != 0u) { budget -= 1u; u3 = fn3(g1, (unsigned)(((unsigned)c1 + r0.x) < *q0), (unsigned)(r0.x == i1)); }
                        g1 += 5u;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((u1 & (i0 % ((unsigned)(x0 >> 70) | 1u))), (garr[u2 & 7u] - (unsigned)(7u || u0)), a0[i0 & 3u]); }
                        s1 = (int)((unsigned)s1 + (unsigned)(signed char)((unsigned)x0 >> ((0u | u3) & 31u)));
                    }
                    f0 = f0 * 0.5f + (float)(~(*mp / (((unsigned)e0 | (u2 ? 7u : fuel)) | 1u)) & 255u);
                    s0 = (int)(unsigned)((unsigned)h1 || (unsigned)(a0[u1 & 3u] == (garr[u2 & 7u] % (*mp | 1u))));
                    *q0 = (unsigned)!(p2 * ((unsigned)b0 - (unsigned)w0));
                }
                b0 = i1 != 0u;
            }
            continue; (void)((unsigned)h0);
            i0 = (v0 * u0) & 15u;
            q0 = &garr[(unsigned)(((unsigned)h0 ? 6u : (unsigned)w0) && (unsigned)s1) & 7u];
        } while (i0++ < 2u && a0[u1 & 3u]);
        L4: if (--fuel == 0u) goto done;
    }
    { unsigned t8; double z8; if ((((unsigned)c1 % ((unsigned)(x0 >> 70) | 1u))) & 1u) { t8 = ((i2 - 0x10000u) - 0u); z8 = (double)(((p0 & 0x9b8971e8u)) & 255u); } if ((((unsigned)c1 % ((unsigned)(x0 >> 70) | 1u))) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
        if (u3 == 7u) return (0x6c257933u & (((unsigned)s0 * (*q0 & 0x7fffffffu)) + (unsigned)c1));
        b0 = (unsigned)((unsigned)((0x30671178u + (unsigned)c0) && v0) == (0x10000u | (unsigned)(x0 >> 70))) != 0u;
    }
    c0 = (unsigned char)(0x10000u << ((0xffffffffu - g1) & 31u));
    g0 = ~(unsigned)((unsigned)d0 || (unsigned)((int)(unsigned)(g0 || 0x7fffffffu) < (int)p1));
    { unsigned t9; double z9; if ((garr[u2 & 7u]) & 1u) { t9 = p1; z9 = (double)((((0x10000u | g1) & 0x7fffffffu)) & 255u); } if ((garr[u2 & 7u]) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
        switch ((*mp * (unsigned)(short)(fuel / ((unsigned)l0 | 1u))) & 7u) {
            *q0 += ((unsigned)c0 ? (unsigned)x0 : (unsigned)w0);
            case 3u: ;
            m0 ^= (unsigned)(0xffffffffu < (((unsigned)h1 % ((m0 ^ g0) | 1u)) - u1));
        }
        if ((unsigned)((short)5u > (signed char)r0.x)) goto L3;
        if ((unsigned)(~(unsigned)(a0[i0 & 3u] < 0x7fffffffu) < i0)) goto L0;
        if (fuel) goto L2;
        *q0 += (unsigned)((unsigned)e0 == 3u);
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 += (unsigned)((int)0x7b230594u >= (int)0x10000u);
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)w0 >= (int)(0x7fffffffu % (((unsigned)(w0 >> 29) % (0x7fffffffu | 1u)) | 1u)));
        u0 += ((unsigned)c0 >> (-(fuel << ((unsigned)c1 & 31u)) & 31u));
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(w0 >> 29), (unsigned)(g1 == 0xf304d384u), (unsigned)(signed char)(unsigned)(0xfc09c65eu == ((unsigned)c1 + (unsigned)x0))); }
        x0 = x0 * 0x100000001b3ull + (fuel ? i0 : 0x80000000u);
    }
    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(0xffffffffu == (unsigned)s0) && (unsigned)w0));
    switch ((unsigned)(unsigned char)((u0 | 0xdaba6470u) / (g0 | 1u)) & 7u) {
        goto L0;
    }
    if ((fuel ^ (unsigned)b0)) goto L2;
    if ((r0.y - 0x7fffffffu)) goto done;
    f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)f0 < (int)((unsigned)x0 << ((unsigned)d0 & 31u))) & 255u);
    v0 = g0;
    { unsigned t10; double z10; if (((unsigned)((unsigned)((short)garr[i1 & 7u] > (signed char)m0) || fuel)) & 1u) { t10 = 0x10000u; z10 = (double)(((unsigned)(i0 && (unsigned)(w0 >> 29))) & 255u); } if (((unsigned)((unsigned)((short)garr[i1 & 7u] > (signed char)m0) || fuel)) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
        goto L3;
        u1 = ((r0.y >> ((unsigned)x0 & 31u)) & (i1 & u0));
    }
    if (budget != 0u) { budget -= 1u; u0 = fn3(-(r0.x | (unsigned)(garr[i1 & 7u] || i1)), u3, (unsigned)(9u && 0xffffffffu)); }
    r0.x = (p2 * ((unsigned)((unsigned)(w0 >> 29) < 0xbc2cd02du) / ((0xf0b17197u + i0) | 1u)));
    if (-(((unsigned)w0 / (0xbfb94321u | 1u)) + p0)) {
        l0 = (long)((unsigned long)l0 + (0xc0a0ce85u << ((unsigned)!((unsigned)((int)1u >= (int)i2) ^ (unsigned)s0) & 31u)));
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((short)(unsigned)c1 > (signed char)0x57e7b0f7u), (unsigned)e0, 3u); }
        garr[((unsigned)b0 % (u3 | 1u)) & 7u] = -(unsigned)((int)(unsigned)((short)8u > (signed char)(unsigned)l0) >= (int)(unsigned)d0);
        if ((unsigned)l0) {
            c1 = (signed char)(unsigned)(a0[u1 & 3u] < ((unsigned)s1 * 0x80000000u));
            e0 = e0 * 0.5L + (long double)((g1 ^ (unsigned)c0) & 1023u);
            if ((6u - 0xc30dc365u)) goto L3;
        } else {
            f0 = f0 * 0.5f + (float)((unsigned)((int)6u >= (int)0x361d881cu) & 255u);
            if ((unsigned)(u2 < (fuel / (0x7fffffffu | 1u)))) {
                if (0x7276570u) goto L3;
            } else {
                if ((unsigned)w0) {
                    c1 = (signed char)((unsigned)w0 >> (u0 & 31u));
                    h1 = (unsigned short)(h1 + (unsigned)s0);
                } else {
                    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((int)u0 >= (int)p0) < (int)~((unsigned)c0 ? (unsigned)e0 : 0x81372945u)));
                    }
                    r0.x = (unsigned)(*mp < (unsigned)((unsigned)(p2 == *q0) && 0x10000u));
                }
                w0 = w0 * 6364136223846793005ull + ((r0.y - (unsigned)(0xe04e1bbu < 0x4c68346u)) << (0xdd4397a5u & 31u));
                if (garr[u2 & 7u]) {
                    e0 = e0 * 0.5L + (long double)((unsigned)((0x672a4f0u * *q0) < (u0 >> (p0 & 31u))) & 1023u);
                    g1 += -(r0.y >> ((unsigned)(w0 >> 29) & 31u));
                    { unsigned t11; double z11; if (((unsigned)d0) & 1u) { t11 = 4u; z11 = (double)(((unsigned)((int)u0 >= (int)((unsigned)d0 + p0))) & 255u); } if (((unsigned)d0) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
                        if ((unsigned)((int)(unsigned)e0 < (int)*mp)) goto L3;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(0x10000u, ((unsigned)(signed char)(unsigned)(0x80000000u < i0) - 1u), (a0[u1 & 3u] ^ i2)); }
                    }
                    w0 = w0 * 6364136223846793005ull + (((unsigned)w0 + a0[i0 & 3u]) + (unsigned)(p0 < garr[i1 & 7u]));
                    if ((unsigned)(short)(unsigned)((int)(unsigned)x0 >= (int)0xb103bed5u)) goto L3;
                    if ((unsigned)s0) goto done;
                } else {
                    if (-((unsigned)(*mp < 8u) + a0[u1 & 3u])) goto L1;
                }
                v0 = (unsigned)e0;
            }
        }
        if (((unsigned)h0 % ((0x80000000u / (*mp | 1u)) | 1u))) goto L1;
        if ((unsigned)(2u || (unsigned)c1)) {
            goto L3;
            if ((unsigned)w0) goto L2;
            if ((((unsigned)c0 - garr[u2 & 7u]) << (0xffffffffu & 31u))) goto L0;
            if (u3 == 7u) return ((unsigned)l0 >> ((unsigned)((short)0x10000u > (signed char)~(unsigned)((unsigned)h0 < (unsigned)(w0 >> 29))) & 31u));
            e0 = e0 * 0.5L + (long double)((unsigned)(p0 && (unsigned)(u1 && p0)) & 1023u);
        }
    }
    if (((unsigned)f0 << (0x80000000u & 31u))) goto L2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 12u, 0x49f8c423u, 0xd3364bf2u },
        { 0u, 0x9e3ec1b9u, 0x1c0da759u },
        { 4u, 0x1a78c9b6u, 0x34e6f0bu },
        { 14u, 0xd91f058fu, 0x8e544f20u },
        { 10u, 0x5bc5bc93u, 0xc542888u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
