// test-ssa-source's program of seed 134000434 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xbda097b5u, g1 = 0xd030e37fu;
static unsigned garr[8] = { 0x56c68a27u, 0x4b210a9eu, 0xaf2d5e4du, 0x52187a5bu, 0x4ad954bfu, 0x819b36f2u, 0xc066affu, 0xd1e4f896u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    w0 ^= (unsigned long long)u0 << ((0x80000000u >> ((unsigned)(((unsigned)s0 ? 2u : (unsigned)b0) < p0) & 31u)) & 63u);
    if ((unsigned)((short)3u > (signed char)p1)) goto done;
    if (fuel < 8u) return (unsigned)((int)u3 >= (int)(unsigned)(2u || 0x7fffffffu));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        i0 = (unsigned)!(*mp | (unsigned)!(*q0 & (unsigned)w0)) & 15u;
        if (m0) {
            L1: if (--fuel == 0u) goto done;
            if ((unsigned)(u2 < (unsigned)((int)0xd356221du < (int)0xffffffffu))) goto L2;
            if ((unsigned)c1) goto L3;
            c0 = (unsigned char)(unsigned)(a0[u1 & 3u] == (unsigned)((short)(unsigned)(short)(unsigned)((int)(unsigned)c0 >= (int)p1) > (signed char)r0.y));
            switch (0x10000u & 7u) {
                if ((i1 & (unsigned)(short)((unsigned)h0 % ((unsigned)w0 | 1u)))) continue;
                x0 = x0 * 0x100000001b3ull + ((*mp ^ fuel) << ((unsigned)((int)v0 < (int)r0.x) & 31u));
            }
            u2 ^= (((unsigned)s1 << ((unsigned)(x0 >> 70) & 31u)) - 0u);
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            *q0 = ((unsigned)((int)(unsigned)c0 < (int)4u) / ((unsigned)((unsigned)(unsigned char)(p2 ^ i0) && v0) | 1u));
            if (u3 == 7u) return (unsigned)(0xf5aa7b21u && 1u);
            do { if (--fuel == 0u) goto done;
                if ((unsigned)c0) continue;
            } while (i2++ < 4u && u3);
            m0 ^= (unsigned)((int)(unsigned)(3u || 0x7fffffffu) < (int)m0);
            if ((0x10000u & 0x89ff64afu)) {
                if ((unsigned)(short)(unsigned)((unsigned)s1 == (garr[u2 & 7u] ^ 0x7214647au))) {
                    L2: if (--fuel == 0u) goto done;
                    if ((unsigned)(p0 && (unsigned)w0)) break;
                    L3: if (--fuel == 0u) goto done;
                    L4: if (--fuel == 0u) goto done;
                }
                g0 = (unsigned)(((unsigned)c1 >> (*mp & 31u)) == u3);
                if ((unsigned)((int)(unsigned)((int)u3 >= (int)0xffffffffu) >= (int)r0.y)) {
                    i1 = (unsigned)((p1 ^ p0) < p1) & 15u;
                    if ((unsigned)!(unsigned)((int)(unsigned)s0 < (int)fuel)) break;
                    m0 ^= ((unsigned)(r0.x && (unsigned)x0) << ((unsigned)((short)i0 > (signed char)a0[u1 & 3u]) & 31u));
                } else {
                    break; (void)(u0);
                    w0 ^= (unsigned long long)(7u / (0xc63ad09fu | 1u)) << (-(unsigned)((int)(unsigned)(p2 < (unsigned)s0) >= (int)(unsigned)(a0[u1 & 3u] < p0)) & 63u);
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (((unsigned)f0 ^ p1)) break;
                        if ((unsigned)(g1 || ((unsigned)f0 % (garr[u2 & 7u] | 1u)))) break;
                        if ((unsigned)e0) break;
                        q0 = &garr[((unsigned)s1 ^ ((unsigned)(x0 >> 70) % (3u | 1u))) & 7u];
                        if ((unsigned)((unsigned)(short)((unsigned)(w0 >> 29) % (4u | 1u)) && (unsigned)s0)) break;
                    }
                    if (r0.x) break;
                }
                if (u0) goto done;
            }
            if (p2) {
                u3 ^= i2;
                break; (void)(0x7a2c5785u);
                switch ((i0 * u0) & 7u) {
                    d0 = d0 * 0.5 + (double)((fuel | (unsigned)((~(unsigned)((short)0x10000u > (signed char)(unsigned)b0) + i2) == p0)) & 1023u);
                    v0 = (unsigned)(6u < (v0 | (unsigned)b0));
                }
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    g1 += (r0.x - 0xffffffffu);
                    if ((0xffffffffu * (p2 % ((unsigned)x0 | 1u)))) {
                        if ((unsigned)(9u && (unsigned)w0)) goto L2;
                        break; (void)(((unsigned)h1 | (unsigned)(x0 >> 70)));
                        if (((unsigned)(x0 >> 70) + (unsigned)b0)) continue;
                        u3 = u3 * 0x9e3779b1u + (unsigned)(g0 && (m0 + g0));
                        if (u3 == 7u) return (unsigned)((int)*mp < (int)(unsigned)(signed char)(p0 << (5u & 31u)));
                    } else {
                        s1 = (int)((unsigned)s1 + ((unsigned)h1 * (0xffffffffu ? 0xcc7a6c32u : p0)));
                        u1 ^= (unsigned)((unsigned)((int)0xffffffffu >= (int)0u) && 0x10000u);
                        w0 ^= (unsigned long long)((unsigned)e0 % (u3 | 1u)) << ((unsigned)(((0xcf9d2f56u % (0xecb41dccu | 1u)) ? g0 : *mp) < (unsigned)w0) & 63u);
                    }
                }
            } else {
                *mp = (unsigned)((int)(unsigned)!(0x9f015bc6u << ((unsigned)s1 & 31u)) < (int)((unsigned)l0 % (u1 | 1u)));
                continue; (void)((i0 >> (((unsigned)w0 - r0.y) & 31u)));
                r0.x = ((unsigned)(p1 && 0x111f3472u) & m0);
                v0 = ~((p0 ^ (unsigned)(w0 >> 29)) + (v0 - (unsigned)(*mp && 0x80000000u)));
            }
        }
        break; (void)(i2);
    }
    if ((unsigned)l0) {
        goto L0;
    } else {
        h0 = (short)i1;
        w0 = w0 * 6364136223846793005ull + ((unsigned)((short)fuel > (signed char)(unsigned)(x0 >> 70)) + (i2 + (unsigned)(x0 >> 70)));
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((garr[u2 & 7u] + (unsigned)(2u || (unsigned)e0))) break;
        if ((u1 * (unsigned)w0)) {
            r0.y ^= 0x80000000u;
            if (((unsigned)(w0 >> 29) ^ i2)) {
                if (u0) {
                    s0 = (int)(unsigned)((i1 * (((unsigned)l0 | (unsigned)e0) % (0xda6dc2e0u | 1u))) < v0);
                }
            }
            u1 ^= ((((unsigned)c0 * p2) >> ((unsigned)(x0 >> 70) & 31u)) | *q0);
            r0.y ^= (unsigned)(fuel || 3u);
        }
    }
    switch (u2 & 7u) {
        u1 += (unsigned)((unsigned)s1 == 0xf9525534u);
        case 4u: ;
        case 1u: ;
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 5u: ;
            if ((unsigned)((unsigned)((unsigned)w0 == (unsigned)x0) || i0)) {
                v0 = (((p2 >> ((unsigned)s0 & 31u)) ? a0[i0 & 3u] : (unsigned)e0) << (p0 & 31u));
            }
        }
        r0.y ^= (unsigned)((unsigned)(((unsigned)(x0 >> 70) << ((unsigned)h0 & 31u)) || 0xffffffffu) && (0xffffffffu * 0x5ec90adeu));
        if (u1) {
            if ((unsigned)(p2 || (unsigned)(0x7fffffffu && p2))) goto L1;
            u0 = (unsigned)((short)(unsigned)(u2 && (unsigned)d0) > (signed char)((unsigned)!(unsigned)((int)0x80000000u < (int)p1) * (unsigned)w0));
        } else {
            if ((unsigned)((*mp / (0xdd32b746u | 1u)) < i1)) break;
            u3 = (unsigned)!(unsigned)((short)u2 > (signed char)(garr[i1 & 7u] / ((unsigned)((int)(unsigned)c0 >= (int)v0) | 1u)));
            goto L3;
            break; (void)((unsigned)((*mp ^ r0.y) || (unsigned)x0));
        }
    }
    goto L4;
    if ((a0[u1 & 3u] + (a0[u1 & 3u] ^ g0))) {
        if (((r0.x | a0[u1 & 3u]) * 0x10000u)) goto done;
        if ((a0[i0 & 3u] & 0x10000u)) goto L0;
        do { if (--fuel == 0u) goto done;
            if (v0) continue;
            if (fuel) goto L4;
            { unsigned t0; double z0; if (((unsigned)(a0[u1 & 3u] < (unsigned)c1)) & 1u) { t0 = 0u; z0 = (double)(((unsigned)(i1 < r0.y)) & 255u); } if (((unsigned)(a0[u1 & 3u] < (unsigned)c1)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                if ((unsigned)((unsigned)h1 || g1)) break;
                break; (void)(((unsigned)d0 ^ (p1 % (r0.y | 1u))));
                switch ((unsigned)x0 & 7u) {
                    if (u3 == 7u) return (unsigned)((int)r0.y < (int)(0xffffffffu & i2));
                    c0 = (unsigned char)(0xffffffffu + (-(unsigned)(-((unsigned)c0 + p0) || 0xa4e0b3b5u) & p1));
                    f0 = f0 * 0.5f + (float)(((0xb9c03db0u % (0x44e36768u | 1u)) | ((unsigned)h1 >> (0x7fffffffu & 31u))) & 255u);
                    if (u3 == 7u) return (unsigned)((unsigned)((short)a0[i0 & 3u] > (signed char)0xd10d5633u) < (((unsigned)(w0 >> 29) - fuel) % (g1 | 1u)));
                    w0 = w0 * 6364136223846793005ull + (unsigned)!(unsigned)(*mp < garr[u2 & 7u]);
                }
                if ((unsigned)((unsigned)c0 < *q0)) break;
                l0 = (long)((unsigned long)l0 + *mp);
            }
        } while (i0++ < 7u && 4u);
        goto L0;
        b0 = (unsigned)((int)r0.y >= (int)u2) != 0u;
    } else {
        if (8u) goto L4;
    }
    b0 = (((unsigned)c1 % (0x7fffffffu | 1u)) >> ((unsigned)((unsigned)c0 || 0x80000000u) & 31u)) != 0u;
    garr[1u & 7u] = -(g0 ? u2 : u0);
    *q0 = (garr[i1 & 7u] + (unsigned)(short)(unsigned)(0xa13be634u && u2));
    if ((u3 / (0x8e9a6f80u | 1u))) goto L4;
    goto L0;
    w0 = w0 * 6364136223846793005ull + ((unsigned)((int)(unsigned)((short)i2 > (signed char)i2) < (int)p2) * (unsigned)(i0 && g1));
    l0 = (long)((unsigned long)l0 + (i0 | (unsigned)(signed char)((unsigned)d0 & (unsigned)e0)));
    if ((0xffffffffu / ((unsigned)!(unsigned)(0xbf620af3u == 0xa2463ff9u) | 1u))) goto L1;
    h1 = (unsigned short)(h1 + ((r0.x | i0) % ((unsigned)(signed char)(unsigned)((int)*mp < (int)(unsigned)l0) | 1u)));
    goto L3;
    switch (a0[u1 & 3u] & 7u) {
        case 0u: ;
        default: ;
        switch ((unsigned)l0 & 7u) {
            *q0 = ((unsigned)s0 / ((unsigned)(x0 >> 70) | 1u));
            l0 = (long)((unsigned long)l0 + ((unsigned)(w0 >> 29) % (u1 | 1u)));
        }
        { unsigned t1; double z1; if (((unsigned)(((unsigned)x0 ^ a0[u1 & 3u]) == fuel)) & 1u) { t1 = 2u; z1 = (double)(((unsigned)((int)2u >= (int)(unsigned)(p0 && g1))) & 255u); } if (((unsigned)(((unsigned)x0 ^ a0[u1 & 3u]) == fuel)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            break;
            case 6u: ;
            h0 = (short)(unsigned)((unsigned)((int)(unsigned)(w0 >> 29) < (int)i0) < (6u | a0[i0 & 3u]));
            break;
            case 7u: ;
        }
        { unsigned t2; double z2; if (((unsigned)((unsigned)d0 == 9u)) & 1u) { t2 = p1; z2 = (double)((garr[u2 & 7u]) & 255u); } if (((unsigned)((unsigned)d0 == 9u)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            w0 ^= (unsigned long long)-(0xb87a73d2u % (u2 | 1u)) << (0xffffffffu & 63u);
            garr[((unsigned)f0 << ((unsigned)x0 & 31u)) & 7u] = ((unsigned)w0 / (*q0 | 1u));
        }
    }
    if (((4u % (a0[i0 & 3u] | 1u)) * 0xffffffffu)) {
        { unsigned t3; double z3; if (((*q0 ^ 0x7fffffffu)) & 1u) { t3 = (unsigned)((int)(unsigned)w0 >= (int)a0[u1 & 3u]); z3 = (double)(((0x7fffffffu ^ (unsigned)x0)) & 255u); } if (((*q0 ^ 0x7fffffffu)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            if (fuel < 8u) return ((unsigned)(p2 && (unsigned)h0) >> ((unsigned)d0 & 31u));
            while (i0++ < 3u && ((0x10000u | garr[u2 & 7u]) * r0.y)) { if (--fuel == 0u) goto done;
                if (v0) break;
                if ((unsigned)((int)(0x80000000u % (a0[i0 & 3u] | 1u)) < (int)0x10000u)) break;
            }
            garr[p2 & 7u] = (unsigned)((short)((unsigned)d0 ^ (unsigned)((unsigned)((short)a0[i0 & 3u] > (signed char)a0[u1 & 3u]) && 4u)) > (signed char)0xcb31a9a0u);
            do { if (--fuel == 0u) goto done;
                if ((u2 + g1)) {
                    r0.x = ((unsigned)w0 * (unsigned)c0);
                }
                if (fuel) break;
            } while (i0++ < 2u && (unsigned)b0);
            if (0x19f0495eu) goto L3;
        }
        *mp = (unsigned)(((unsigned)d0 % ((unsigned)c1 | 1u)) && -((unsigned)f0 & 3u));
    } else {
        u1 ^= 0xf44f863bu;
        while (i0++ < 5u && (unsigned)l0) { if (--fuel == 0u) goto done;
            if (~(8u >> ((unsigned)((unsigned)l0 == 0x10000u) & 31u))) {
                u3 = u3 * 0x9e3779b1u + (unsigned)((int)(u1 % (u3 | 1u)) >= (int)2u);
                if ((unsigned)(6u < (unsigned)x0)) break;
                s1 = (int)((unsigned)s1 + (unsigned)(p2 < u3));
                if ((unsigned)(unsigned char)((unsigned)(u2 && 0x62f2daedu) >> (4u & 31u))) {
                    if (((unsigned)((unsigned)h1 || *q0) * p1)) {
                        w0 ^= (unsigned long long)(p2 * a0[u1 & 3u]) << ((unsigned)((unsigned)e0 == (unsigned)c0) & 63u);
                        if (a0[i0 & 3u]) goto L4;
                        q0 = &garr[((unsigned)d0 >> (a0[i0 & 3u] & 31u)) & 7u];
                        if ((unsigned)((short)(9u % ((unsigned)h0 | 1u)) > (signed char)i0)) break;
                        if ((unsigned)((int)g0 < (int)((unsigned)e0 << (1u & 31u)))) break;
                        w0 ^= (unsigned long long)(unsigned)f0 << ((unsigned)(7u || (((unsigned)w0 << ((unsigned)(1u || 0x80000000u) & 31u)) >> (0x10000u & 31u))) & 63u);
                    }
                    if ((unsigned)s1) {
                        goto done;
                        s0 = (int)((unsigned)f0 >> ((unsigned)e0 & 31u));
                        u0 += (0x3cdd7fadu ? (unsigned)(i0 && 0x10000u) : (*mp % (0x96e0db4cu | 1u)));
                    }
                    r0.y ^= (p1 & p0);
                    g1 += 0x275e8f9du;
                    x0 = x0 * 0x100000001b3ull + (unsigned)((short)0x369cd514u > (signed char)((unsigned)c1 & u3));
                    i1 = (unsigned)((short)(unsigned)!(unsigned)((unsigned)w0 && (unsigned)s0) > (signed char)3u) & 15u;
                } else {
                    break; (void)((unsigned)((int)p2 >= (int)u0));
                    *q0 += g0;
                    if ((*q0 >> ((unsigned)w0 & 31u))) break;
                }
                g1 += (unsigned)((short)(unsigned)w0 > (signed char)0xffffffffu);
            } else {
                if ((unsigned)s0) continue;
                g1 += (u3 ^ (unsigned)c0);
                if ((garr[u2 & 7u] * (unsigned)c0)) break;
            }
            break; (void)((unsigned)((unsigned)s0 && 0xbe99477eu));
        }
        while (i0++ < 6u && (unsigned)((int)(unsigned)e0 < (int)(unsigned)!(0xf45f6d0u | 0x3ebbbbbcu))) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)r0.y < (int)(0x7fffffffu % (9u | 1u)))) break;
            if ((unsigned)d0) break;
            r0.x = (unsigned)((unsigned)((int)4u < (int)(unsigned)s0) < (unsigned)((int)(unsigned)((int)0x35af5374u >= (int)u1) < (int)u3));
        }
    }
    if ((unsigned)b0) goto L4;
    if ((unsigned)((short)0x10000u > (signed char)(unsigned)h1)) {
        if (((unsigned)d0 & 0xffffffffu)) goto L2;
        do { if (--fuel == 0u) goto done;
            if (fuel < 8u) return ((unsigned)((int)0x80000000u < (int)i1) & (4u << (8u & 31u)));
            r0.x = (i0 >> ((unsigned)((unsigned)(g1 && (unsigned)(x0 >> 70)) == 0u) & 31u));
            break; (void)((0x46bd8b8u << ((unsigned)((short)0xffffffffu > (signed char)i2) & 31u)));
            while (i1++ < 3u && ((unsigned)c1 >> (0xe95b25f9u & 31u))) { if (--fuel == 0u) goto done;
                b0 = (((0u * 5u) >> ((unsigned)(fuel && u2) & 31u)) << ((unsigned)(x0 >> 70) & 31u)) != 0u;
                x0 = x0 * 0x100000001b3ull + (6u << ((unsigned)((int)(unsigned)(x0 >> 70) < (int)m0) & 31u));
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    goto done;
                }
                if ((unsigned)(w0 >> 29)) break;
            }
        } while (i0++ < 7u && (unsigned)(p2 && 0xa6f7c45du));
        switch ((unsigned)((int)*q0 < (int)((unsigned)(x0 >> 70) & m0)) & 7u) {
            { unsigned t4; double z4; if (((unsigned)((unsigned)w0 < u2)) & 1u) { t4 = (0x16576eb1u ^ u3); z4 = (double)((((u1 >> (*q0 & 31u)) | u3)) & 255u); } if (((unsigned)((unsigned)w0 < u2)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                d0 = d0 * 0.5 + (double)(m0 & 1023u);
            }
        }
        if ((unsigned)(m0 == (unsigned)((unsigned)h0 || p2))) goto L3;
    } else {
        b0 = (unsigned)((int)0x9b85ebd6u >= (int)5u) != 0u;
        if ((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)(x0 >> 70))) goto L3;
        while (i0++ < 7u && 0xe1369164u) { if (--fuel == 0u) goto done;
            if ((7u >> (garr[i1 & 7u] & 31u))) break;
            while (0xd3799a02u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)(signed char)(0xd3b1393eu / (0x10000u | 1u)));
                if ((unsigned)(signed char)(0x7fffffffu + p1)) break;
                u3 ^= (unsigned)(0xa59b2ba6u == (unsigned)w0);
                g1 += (unsigned)((int)(unsigned)(a0[u1 & 3u] && 0x7f3f8945u) >= (int)p2);
                if (~(i1 / (garr[u2 & 7u] | 1u))) break;
                m0 ^= (unsigned)(0x7fffffffu == (i0 & (0xffffffffu | u0)));
            }
        }
    }
    goto L2;
    if ((unsigned)(w0 >> 29)) goto L0;
    while (i0++ < 7u && (g1 - 0x4ed58dbdu)) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)((unsigned)d0 | r0.y) << (((unsigned)f0 / ((0xffffffffu * (unsigned)b0) | 1u)) & 63u);
        { unsigned t5; double z5; if (((0x4eb23f9du % (p1 | 1u))) & 1u) { t5 = garr[i1 & 7u]; z5 = (double)(((p0 << (u0 & 31u))) & 255u); } if (((0x4eb23f9du % (p1 | 1u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            a0[r0.y & 3u] = (-(unsigned)((9u >> (0x80000000u & 31u)) == (unsigned)w0) % (garr[u2 & 7u] | 1u));
            while (i1++ < 7u && (0xbcb60f7eu | 0xffffffffu)) { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)((short)(unsigned)l0 > (signed char)fuel) >> (i2 & 31u)));
                b0 = (fuel << ((unsigned)(p0 == (unsigned)(m0 && (unsigned)x0)) & 31u)) != 0u;
            }
            a0[((unsigned)e0 / (p2 | 1u)) & 3u] = (4u - u0);
            break; (void)((unsigned)((unsigned)d0 < (unsigned)c1));
            while (i1++ < 5u && (g1 ? fuel : (unsigned)c1)) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)~(unsigned)((short)(unsigned)!(unsigned)((int)(unsigned)l0 >= (int)(unsigned)s1) > (signed char)(0x7fffffffu * (unsigned)h0));
                q0 = &garr[(u1 ^ (unsigned)(a0[u1 & 3u] || (0x10000u >> (p2 & 31u)))) & 7u];
                break; (void)((p2 & 0x80000000u));
                if ((unsigned)(w0 >> 29)) break;
            }
            d0 = d0 * 0.5 + (double)(((unsigned)(unsigned char)(0x7bcda454u / (0xf84cc71eu | 1u)) & (g1 ? a0[i0 & 3u] : a0[i0 & 3u])) & 1023u);
        }
        l0 = (long)((unsigned long)l0 + ((unsigned)((int)0x7fffffffu < (int)i1) & (r0.y >> ((unsigned)((unsigned)e0 == 0xbeaf8f82u) & 31u))));
        { unsigned t6; double z6; if ((~(unsigned)((int)(0x3d90abb6u * 0xf0d98e0u) < (int)(unsigned)c1)) & 1u) { t6 = (unsigned)(1u && 6u); z6 = (double)((garr[i1 & 7u]) & 255u); } if ((~(unsigned)((int)(0x3d90abb6u * 0xf0d98e0u) < (int)(unsigned)c1)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
            if ((unsigned)((unsigned)d0 && u1)) break;
            { unsigned t7; double z7; if (((unsigned)((short)(unsigned)h1 > (signed char)g1)) & 1u) { t7 = ((unsigned)((int)p0 >= (int)p0) % (garr[i1 & 7u] | 1u)); z7 = (double)(((unsigned)(signed char)(6u + 0x80000000u)) & 255u); } if (((unsigned)((short)(unsigned)h1 > (signed char)g1)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                goto L1;
                g0 = (unsigned)((short)((0x7fffffffu ? (unsigned)(x0 >> 70) : (unsigned)d0) | (unsigned)b0) > (signed char)garr[i1 & 7u]);
                *mp = (unsigned)(((unsigned)((unsigned)l0 == g0) | (unsigned)c1) && 6u);
            }
            break; (void)(v0);
        }
    }
    switch ((unsigned)h0 & 7u) {
        v0 = (unsigned)((short)(0xffffffffu >> (~(*q0 * fuel) & 31u)) > (signed char)8u);
        g0 = (unsigned)((unsigned)(signed char)((unsigned)((int)v0 < (int)r0.y) - (g1 << (0x10000u & 31u))) == (unsigned)f0);
        if (0x7fffffffu) {
            if ((0xb65ac772u & 0x10000u)) {
                if ((unsigned)(0x7fffffffu && (unsigned)(w0 >> 29))) {
                    switch ((unsigned)(u1 < (g0 ^ (unsigned)s0)) & 7u) {
                        l0 = (long)((unsigned long)l0 + 0x7ce98484u);
                        u2 = u2 * 0x9e3779b1u + (unsigned)((int)0xcace4374u < (int)(unsigned)(unsigned char)(unsigned)(u3 || 9u));
                    }
                    q0 = &garr[(unsigned)((int)(8u - g0) >= (int)(unsigned)((short)5u > (signed char)0xffffffffu)) & 7u];
                }
            } else {
                if (-(unsigned)((short)2u > (signed char)(unsigned)((short)i1 > (signed char)p2))) goto done;
                while (i0++ < 6u && (unsigned)((int)(0x83e360d5u & (unsigned)c0) < (int)p0)) { if (--fuel == 0u) goto done;
                    continue; (void)((i0 | (unsigned)h1));
                }
                if ((unsigned)!((garr[u2 & 7u] >> (*q0 & 31u)) - *mp)) break;
            }
            for (;;) { if (--fuel == 0u) goto done;
                case 6u: ;
                case 7u: ;
                c1 = (signed char)(0u & r0.x);
            }
            r0.x = 0x13817863u;
        } else {
            if (g1) {
                if ((p2 % (fuel | 1u))) {
                    if (garr[i1 & 7u]) goto L4;
                    case 0u: ;
                    default: ;
                    *mp = ((unsigned)((unsigned)b0 || (garr[i1 & 7u] ^ (unsigned)l0)) / (0xc0496c24u | 1u));
                } else {
                    *q0 = ((unsigned)((short)(unsigned)e0 > (signed char)((unsigned)x0 * (unsigned)s0)) ^ *q0);
                    *mp = (unsigned)(unsigned char)(unsigned)((short)-(i2 * a0[u1 & 3u]) > (signed char)p2);
                    w0 = w0 * 6364136223846793005ull + (a0[u1 & 3u] % (9u | 1u));
                }
                u0 += (unsigned)(short)((unsigned)((int)(unsigned)s0 < (int)(unsigned)x0) / (i1 | 1u));
            }
        }
        break;
        break;
    }
    x0 = x0 * 0x100000001b3ull + (r0.x / (((m0 - g0) & (0x24c66c18u ^ 0x51248ef2u)) | 1u));
    if ((i2 << ((unsigned)d0 & 31u))) {
        if (0x80000000u) goto L3;
        c1 = (signed char)p2;
        r0.y ^= (unsigned)((unsigned)!((unsigned)((int)(unsigned)b0 >= (int)0x80000000u) / ((unsigned)(0x10000u < r0.x) | 1u)) && (unsigned)s0);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
        }
        a0[(unsigned)((unsigned)d0 < 3u) & 3u] = (unsigned)(w0 >> 29);
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((6u >> (i2 & 31u)), 0x10000u, 4u); }
    switch (2u & 7u) {
        for (;;) { if (--fuel == 0u) goto done;
            if (~(0xffffffffu + (0xffffffffu & u3))) {
                L1: if (--fuel == 0u) goto done;
            }
            if (fuel < 8u) return 7u;
            r0.x = ((unsigned)w0 & (unsigned)((unsigned)h1 && r0.x));
        }
        h1 = (unsigned short)(h1 + (unsigned)((0x7fffffffu - (0x10000u / ((unsigned)c1 | 1u))) && (unsigned)(fuel == (unsigned)s0)));
    }
    if (garr[u2 & 7u]) {
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(u2 || r0.y) | fuel), ((unsigned)!(v0 >> (0x10000u & 31u)) * *mp), (unsigned)(short)(p1 & 0x10000u)); }
    }
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(2u || g1) && (3u * (unsigned)h1)));
            if (garr[i1 & 7u]) {
                if (0x20f98041u) {
                    break; (void)(i0);
                    if (budget != 0u) { budget -= 1u; u1 = fn0((-((unsigned)e0 << (0u & 31u)) | (unsigned)h1), (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)w0), (p0 / ((unsigned)e0 | 1u))); }
                }
                if (((unsigned)(x0 >> 70) / ((unsigned)((int)(unsigned)h0 < (int)0x7fffffffu) | 1u))) break;
                if ((unsigned)s0) break;
                garr[(unsigned)(0x10000u || (unsigned)f0) & 7u] = *q0;
                if (((unsigned)(w0 >> 29) & 3u)) continue;
                r0.y ^= ((unsigned)b0 ^ (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)s0));
            }
        } while (i1++ < 3u && 1u);
        switch ((3u >> ((u2 % ((unsigned)x0 | 1u)) & 31u)) & 7u) {
            L2: if (--fuel == 0u) goto done;
            case 7u: ;
            L3: if (--fuel == 0u) goto done;
            if ((unsigned)(w0 >> 29)) {
                if (p2) continue;
            }
        }
        *q0 += (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)b0);
    } while (i0++ < 7u && m0);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 = u0 * 0x9e3779b1u + (unsigned)((int)(unsigned)!((unsigned)d0 * (unsigned)f0) >= (int)p0);
        m0 ^= (unsigned)e0;
    }
    goto L4;
    L4: if (--fuel == 0u) goto done;
    goto L4;
    if (g1) goto L0;
    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((unsigned)l0 < *mp) == fuel));
    if (-(g1 & (unsigned)b0)) {
        s1 = (int)((unsigned)s1 + (unsigned)h1);
        m0 ^= (((unsigned)(unsigned char)((unsigned)f0 ? u3 : i0) << (r0.y & 31u)) * *mp);
        q0 = &garr[i0 & 7u];
        r0.x = (unsigned)((unsigned)h0 == r0.y);
        if ((unsigned)((short)(unsigned)(0xa37e9514u && 7u) > (signed char)p0)) goto L3;
        s1 = (int)((unsigned)s1 + (unsigned)(r0.x || (4u ^ 0x7fffffffu)));
    }
    g1 += 0x3d1ee8fu;
    u2 ^= ((unsigned)(v0 < 0xffffffffu) - g0);
    i2 = ((unsigned)((short)(unsigned)f0 > (signed char)garr[u2 & 7u]) >> ((unsigned)(unsigned char)((unsigned)h1 % (p1 | 1u)) & 31u)) & 15u;
    if (budget != 0u) { budget -= 1u; u3 = fn0(((r0.x >> (0x3600d073u & 31u)) + i0), (unsigned)((unsigned)((int)0x93b5f4c1u < (int)g1) && 5u), 0xb173503du); }
    if ((unsigned)((short)(unsigned)(signed char)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)l0) > (signed char)0x7d67eb76u)) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)l0, (unsigned)(i1 && r0.y), (unsigned)((int)(unsigned)l0 < (int)m0)); }
        if (budget != 0u) { budget -= 1u; u0 = fn0((0xffffffffu & 4u), (unsigned)((short)4u > (signed char)0xffffffffu), (0x10000u >> ((unsigned)b0 & 31u))); }
    }
    g1 += ((unsigned)((unsigned)(i2 && r0.y) == ((unsigned)e0 & a0[i0 & 3u])) & *mp);
    b0 = (0x7fffffffu + (garr[i1 & 7u] * (unsigned)(0xffffffffu || (r0.x << ((unsigned)c0 & 31u))))) != 0u;
    do { if (--fuel == 0u) goto done;
        switch (~(0x80000000u ? a0[u1 & 3u] : i2) & 7u) {
            q0 = &garr[6u & 7u];
        }
        c0 = (unsigned char)((unsigned)((int)(unsigned)x0 < (int)((unsigned)c1 + a0[i0 & 3u])) % ((unsigned)(u3 < 0xb8b71347u) | 1u));
        switch (((0x7fffffffu >> (0x10000u & 31u)) * (unsigned)s0) & 7u) {
            do { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)((int)(unsigned)s1 < (int)((unsigned)((unsigned)b0 || g1) % (~(0x80000000u >> (0xffffffffu & 31u)) | 1u)));
                    g1 += a0[i0 & 3u];
                    a0[(unsigned)((short)r0.y > (signed char)0xf2b81aeeu) & 3u] = (unsigned)(signed char)((unsigned)(a0[i0 & 3u] == 0u) >> (0x4c53b2ffu & 31u));
                    r0.x = ((unsigned)((int)0x10000u < (int)(unsigned)(r0.x && *mp)) / (p2 | 1u));
                }
                u3 += ((0xeed58fc7u / ((unsigned)(p1 && (unsigned)c1) | 1u)) ? garr[i1 & 7u] : (unsigned)c0);
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    case 1u: ;
                    case 7u: ;
                }
                if ((unsigned)((unsigned)d0 || 3u)) continue;
            } while (i1++ < 7u && (0x10000u ? (unsigned)b0 : p1));
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)(p1 | 1u) < (int)(garr[u2 & 7u] - (unsigned)b0));
            switch (((unsigned)(w0 >> 29) % ((unsigned)(unsigned char)(9u << (0xdfb22e23u & 31u)) | 1u)) & 7u) {
                v0 = p2;
                h1 = (unsigned short)(h1 + (unsigned)(0x486ae497u == (0x2017f59au << (*q0 & 31u))));
            }
            g0 = (unsigned)(signed char)((unsigned)((int)((unsigned)e0 & 0xffffffffu) >= (int)(3u * (unsigned)c0)) << (garr[u2 & 7u] & 31u));
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0(2u, ((unsigned)(x0 >> 70) & 0x2e614ab7u), ((unsigned)e0 / ((u3 / (a0[i0 & 3u] | 1u)) | 1u))); }
        if ((0x9fe3fd59u >> (garr[u2 & 7u] & 31u))) goto L4;
    } while (i0++ < 2u && a0[i0 & 3u]);
    if (budget != 0u) { budget -= 1u; u1 = fn0(-((unsigned)((unsigned)e0 || 4u) + (unsigned)w0), (unsigned)((int)0xffffffffu >= (int)0x10000u), (unsigned)c0); }
    switch (((unsigned)d0 | (unsigned)!(unsigned)(r0.x || u3)) & 7u) {
        case 4u: ;
        while (i0++ < 3u && -(u0 ? a0[i0 & 3u] : (unsigned)b0)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)h1, (a0[u1 & 3u] >> (0x80000000u & 31u)), (0x6ff736fbu * 0x7fffffffu)); }
            l0 = (long)((unsigned long)l0 + (((unsigned)l0 + i2) & 0xffffffffu));
            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((int)(unsigned)s0 < (int)p0) | 0x3cf3132bu), ((unsigned)c0 ^ (garr[i1 & 7u] & g1)), (p0 | (u0 / (0x80000000u | 1u)))); }
            e0 = e0 * 0.5L + (long double)(((3u << (u2 & 31u)) | (unsigned)f0) & 1023u);
        }
        if (((unsigned)(w0 >> 29) * ((unsigned)s0 ^ 1u))) goto done;
        m0 ^= (2u - (unsigned)((v0 & (unsigned)h1) == 0xffffffffu));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    u0 += ((0xffffffffu ? r0.y : (unsigned)h0) + 8u);
    u2 = (i0 >> (a0[u1 & 3u] & 31u));
    w0 ^= (unsigned long long)(unsigned)e0 << (((((p2 >> ((unsigned)d0 & 31u)) & (unsigned)h0) / ((unsigned)(x0 >> 70) | 1u)) >> ((unsigned)b0 & 31u)) & 63u);
    if (budget != 0u) { budget -= 1u; u0 = fn0(a0[u1 & 3u], (i0 | (unsigned)(6u == u1)), 4u); }
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)c0 < g0)) break;
            switch ((unsigned)(unsigned char)(unsigned)((unsigned)(signed char)(g0 / (i2 | 1u)) && g0) & 7u) {
                switch (((unsigned)(w0 >> 29) ^ (v0 ^ 0xffffffffu)) & 7u) {
                    if ((i0 ? 8u : (unsigned)s1)) {
                        *q0 += (unsigned)(g1 < 0x80000000u);
                        garr[(unsigned)(0x10000u < g1) & 7u] = -((unsigned)s1 & i1);
                        if (m0) goto L4;
                    }
                }
                goto L4;
                L0: if (--fuel == 0u) goto done;
                if (0x7fffffffu) {
                    if ((unsigned)((short)p1 > (signed char)p0)) {
                        u3 += (unsigned)((int)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)((short)(unsigned)h0 > (signed char)3u)) < (int)(unsigned)w0);
                    } else {
                        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)h0 & 2u), 0x932ffda6u, ((unsigned)((unsigned)c0 && (unsigned)(w0 >> 29)) >> (0x7fffffffu & 31u))); }
                        if (budget != 0u) { budget -= 1u; u3 = fn1((u3 + (unsigned)(0xd036c42fu < (unsigned)b0)), ((unsigned)(3u && (unsigned)b0) - i2), ~((unsigned)((unsigned)e0 < r0.y) % (g0 | 1u))); }
                        s1 = (int)((unsigned)s1 + (unsigned)!(((*mp >> (u3 & 31u)) - (unsigned)s1) ? 0x7fffffffu : v0));
                        if (budget != 0u) { budget -= 1u; u1 = fn1((9u % (v0 | 1u)), (unsigned)((short)((unsigned)s0 << (u1 & 31u)) > (signed char)i0), (unsigned)l0); }
                    }
                }
                u2 ^= (unsigned)((int)*q0 < (int)(0x80000000u & (unsigned)(w0 >> 29)));
            }
            c0 = (unsigned char)a0[u1 & 3u];
            if ((unsigned)(signed char)(unsigned)(0x80000000u == 0x2e4befb4u)) {
                while (i2++ < 4u && ((unsigned)(0xf4931be2u && (unsigned)x0) + (unsigned)e0)) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1(-((unsigned)(x0 >> 70) << ((unsigned)s1 & 31u)), -(unsigned)((int)2u >= (int)(unsigned)d0), (unsigned)c1); }
                    x0 = x0 * 0x100000001b3ull + (unsigned)((short)(0x80000000u | g0) > (signed char)(unsigned)(signed char)((unsigned)c0 * (unsigned)h1));
                    while ((unsigned)s1) { if (--fuel == 0u) goto done;
                        L1: if (--fuel == 0u) goto done;
                        if (g0) {
                            g0 = (unsigned)(x0 >> 70);
                        }
                        break; (void)((1u | (garr[i1 & 7u] % ((unsigned)b0 | 1u))));
                        if ((i2 - i1)) {
                            if ((u1 >> ((a0[u1 & 3u] % (0x2e17c267u | 1u)) & 31u))) break;
                            if (garr[i1 & 7u]) break;
                            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)h1, (unsigned)b0, (unsigned)s0); }
                            q0 = &garr[0xfd197ce9u & 7u];
                            if ((unsigned)c1) goto L2;
                            b0 = (unsigned)(0x1d006cf7u || (8u / (v0 | 1u))) != 0u;
                        } else {
                            if (u3 == 7u) return -((*mp ? v0 : (0x64b1fe82u / (r0.y | 1u))) & (unsigned)x0);
                            if ((i2 ^ (unsigned)c0)) continue;
                            if ((p1 >> (((unsigned)f0 << ((unsigned)w0 & 31u)) & 31u))) goto L0;
                            if (((unsigned)((short)0x56d661b7u > (signed char)*mp) + garr[u2 & 7u])) break;
                        }
                        v0 = (((unsigned)(unsigned char)(unsigned)((int)0xeefab33u < (int)r0.x) >> ((unsigned)s0 & 31u)) | p2);
                    }
                    goto L2;
                    if ((unsigned)d0) {
                        if (((unsigned)(x0 >> 70) & (0x10000u >> (u1 & 31u)))) break;
                        goto L0;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(r0.x, 0x10000u, (unsigned)((unsigned)x0 || (0x10000u | 0x10000u))); }
                        i2 = (((u2 % (0x10000u | 1u)) ^ 0xee30e2eu) * (unsigned)(short)(unsigned)(u2 && 0x519b600au)) & 15u;
                    }
                    s1 = (int)((unsigned)s1 + (unsigned)((short)((r0.x & garr[i1 & 7u]) * (unsigned)!((unsigned)c0 & (unsigned)c0)) > (signed char)a0[i0 & 3u]));
                }
                u0 = u0 * 0x9e3779b1u + (unsigned)h1;
                h1 = (unsigned short)(h1 + (unsigned)(short)((0xffffffffu - 0x80000000u) << (((unsigned)s0 & (unsigned)(7u < (unsigned)l0)) & 31u)));
                if ((m0 + (unsigned)(w0 >> 29))) goto L3;
                u0 = u0 * 0x9e3779b1u + (unsigned)(-((unsigned)(g1 || (unsigned)h0) * (unsigned)e0) && ((unsigned)w0 ^ 0u));
            }
            { unsigned t0; double z0; if (((unsigned)e0) & 1u) { t0 = g0; z0 = (double)(((0x80000000u / ((unsigned)h0 | 1u))) & 255u); } if (((unsigned)e0) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                h0 = (short)(1u % (((unsigned)(0x80000000u || 0xec9a3b13u) + g1) | 1u));
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (((a0[u1 & 3u] & (unsigned)w0) / (0xf081a82du | 1u))) {
                        *q0 += garr[i1 & 7u];
                        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)w0 < ((unsigned)((int)i1 < (int)garr[i1 & 7u]) | 0x1b02fbdu)) & 1023u);
                    }
                    d0 = d0 * 0.5 + (double)(((unsigned)((int)fuel < (int)garr[u2 & 7u]) | u2) & 1023u);
                    for (;;) { if (--fuel == 0u) goto done;
                        L2: if (--fuel == 0u) goto done;
                        break; (void)((unsigned)h1);
                        break; (void)((u2 + a0[i0 & 3u]));
                    }
                    if (4u) break;
                }
                if (0x7fffffffu) continue;
                r0.y ^= *mp;
                if (budget != 0u) { budget -= 1u; u3 = fn1((-(0x7fffffffu >> (1u & 31u)) - (unsigned)(w0 >> 29)), (unsigned)((short)u3 > (signed char)(unsigned)(unsigned char)(i0 ^ 0x80000000u)), 0x336b3618u); }
                if (budget != 0u) { budget -= 1u; u1 = fn0(~(unsigned)((short)(unsigned)(0xffffffffu == p0) > (signed char)6u), (*q0 ^ i1), (unsigned)((short)m0 > (signed char)0xffffffffu)); }
            }
        } while (i1++ < 6u && (m0 >> ((unsigned)h1 & 31u)));
        do { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((1u << (((i2 & (unsigned)s0) >> (1u & 31u)) & 31u)) & 1023u);
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)w0 - p0), *q0, ((i0 | 1u) >> ((unsigned)d0 & 31u))); }
            u2 += (unsigned)(unsigned char)(unsigned)((int)(unsigned)((short)2u > (signed char)0x70fde1ffu) < (int)((unsigned)(x0 >> 70) / (p2 | 1u)));
            u1 += (unsigned)(short)(unsigned)(p0 == (unsigned)l0);
        } while (i1++ < 5u && (6u / (i2 | 1u)));
        while (i1++ < 6u && ((unsigned)h0 % ((unsigned)s0 | 1u))) { if (--fuel == 0u) goto done;
            if ((unsigned)(x0 >> 70)) break;
            if ((((unsigned)h0 << ((unsigned)x0 & 31u)) % ((unsigned)c1 | 1u))) {
                *q0 += (7u * (unsigned)((int)((fuel | garr[u2 & 7u]) & i2) < (int)(unsigned)e0));
            }
        }
        if (((garr[u2 & 7u] + v0) - p1)) {
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)0x10000u < (int)u3), (unsigned)((short)(unsigned)b0 > (signed char)0xabb0a57bu), (unsigned)((unsigned)f0 && ((unsigned)(w0 >> 29) - 8u))); }
                a0[(g1 % ((unsigned)(x0 >> 70) | 1u)) & 3u] = (unsigned)((short)0x7fffffffu > (signed char)(unsigned)(signed char)(unsigned)((unsigned)h1 == *mp));
                if (((0xa6896741u - a0[u1 & 3u]) << (0xffffffffu & 31u))) continue;
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(u2 < 2u) == (unsigned)(0xc3e18ce6u || 0xeb68a5a5u)) & 1023u);
                if (budget != 0u) { budget -= 1u; u0 = fn1(0x89216ba9u, (*q0 - 0x80000000u), (unsigned)((int)((unsigned)l0 & r0.x) < (int)g0)); }
                if ((unsigned)e0) break;
            }
        } else {
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (g1 ^ (i1 % (7u | 1u)));
                    u1 = (unsigned)((short)8u > (signed char)9u);
                }
                L3: if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1(0x2f80addfu, (unsigned)((short)(unsigned)s0 > (signed char)(1u + 8u)), (unsigned)(unsigned char)(m0 + (unsigned)(1u || (unsigned)c1))); }
                    *mp = (unsigned)(((unsigned)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)7u) < (unsigned)x0) | (unsigned)h0) == p2);
                    if (budget != 0u) { budget -= 1u; u1 = fn0((3u * 0x10000u), (unsigned)((short)r0.y > (signed char)3u), (u0 << (0xdbabbc3eu & 31u))); }
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)d0, (unsigned)((u2 | (unsigned)s1) || 0x80000000u), (2u ^ -(unsigned)((int)p1 >= (int)fuel))); }
                    w0 = w0 * 6364136223846793005ull + ((unsigned)s1 - 0x34a3d6a1u);
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0(garr[u2 & 7u], (p0 - (unsigned)(0x7fffffffu == r0.y)), 4u); }
                { unsigned t1; double z1; if ((((unsigned)w0 / ((unsigned)((int)(unsigned)f0 < (int)9u) | 1u))) & 1u) { t1 = (unsigned)((*mp / ((unsigned)s1 | 1u)) == u1); z1 = (double)(((unsigned)w0) & 255u); } if ((((unsigned)w0 / ((unsigned)((int)(unsigned)f0 < (int)9u) | 1u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(i0, (unsigned)((unsigned)c0 < (unsigned)b0), 0xffffffffu); }
                    g0 = (unsigned)(*mp || 0x7def07d1u);
                    if ((unsigned)((int)(unsigned)l0 < (int)(unsigned)l0)) break;
                    r0.x = garr[i1 & 7u];
                }
            }
        }
        x0 = x0 * 0x100000001b3ull + ~(0xffffffffu ^ -((0x7fffffffu | g0) << (-(unsigned)(u1 == 0x7fffffffu) & 31u)));
    } while (i0++ < 6u && (unsigned)!((m0 | p2) & 0x80000000u));
    do { if (--fuel == 0u) goto done;
        while ((unsigned)((short)(unsigned)(g0 < 0xffffffffu) > (signed char)0x80000000u)) { if (--fuel == 0u) goto done;
            if (garr[u2 & 7u]) {
                break; (void)(((unsigned)((int)u2 < (int)*q0) | 0x7fffffffu));
                if (budget != 0u) { budget -= 1u; u0 = fn0(~(unsigned)((int)0u < (int)0xffffffffu), (unsigned)(r0.x == 0xb214e038u), (unsigned)c0); }
                L4: if (--fuel == 0u) goto done;
            }
            m0 ^= ((unsigned)((int)(unsigned)(v0 && v0) < (int)0x5c87c3c0u) | (unsigned)(r0.x == v0));
            if (((unsigned)(0xffffffffu && i2) - u1)) break;
        }
    } while (i0++ < 7u && (unsigned)(w0 >> 29));
    if (((unsigned)s0 ? 0x10000u : i1)) {
        while ((unsigned)w0) { if (--fuel == 0u) goto done;
            g0 = -(0xef171e16u / (((unsigned)h1 & (unsigned)(u2 == r0.x)) | 1u));
            h1 = (unsigned short)(h1 + (a0[u1 & 3u] ^ (unsigned)((int)(unsigned)h0 < (int)u2)));
            if (g1) break;
            b0 = 0x7fffffffu != 0u;
            r0.y ^= ((unsigned)((int)(g1 - (unsigned)c1) >= (int)fuel) << ((unsigned)c0 & 31u));
            break; (void)(i1);
        }
    } else {
        u3 += ((unsigned)l0 ^ 0u);
        u2 ^= (unsigned)(((unsigned)s0 | p0) || g0);
        if ((0xffffffffu ^ p0)) {
            f0 = f0 * 0.5f + (float)((((unsigned)(signed char)(~(unsigned)(garr[i1 & 7u] && 0xffffffffu) % ((unsigned)c0 | 1u)) * 5u) >> (v0 & 31u)) & 255u);
            d0 = d0 * 0.5 + (double)(((garr[u2 & 7u] % ((u0 % (((unsigned)h0 & p2) | 1u)) | 1u)) >> (garr[i1 & 7u] & 31u)) & 1023u);
            g0 = (unsigned)!((unsigned)(signed char)(m0 ? garr[u2 & 7u] : (unsigned)(w0 >> 29)) & i1);
            s0 = (int)(unsigned)((unsigned)(short)(unsigned)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)u1) == (unsigned)((short)p0 > (signed char)(unsigned)c0)) == (unsigned)e0);
        } else {
            c0 = (unsigned char)fuel;
            do { if (--fuel == 0u) goto done;
                while (i1++ < 2u && (unsigned)!(((unsigned)c0 | i1) / (p2 | 1u))) { if (--fuel == 0u) goto done;
                    if (p1) {
                        break; (void)((unsigned)c1);
                        if ((unsigned)(signed char)(unsigned)((unsigned)(0x80000000u && i2) && i1)) break;
                        i1 = (unsigned)(((unsigned)s1 ^ g1) && (unsigned)(signed char)(unsigned)((short)0x6181c511u > (signed char)0x80000000u)) & 15u;
                        break; (void)(*q0);
                    }
                    l0 = (long)((unsigned long)l0 + (u1 / ((p0 ^ (unsigned)((int)(unsigned)b0 < (int)(unsigned)l0)) | 1u)));
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        g0 = (p2 ^ g0);
                        break; (void)(p0);
                        continue; (void)(5u);
                    }
                    l0 = (long)((unsigned long)l0 + (unsigned)(g0 == ((unsigned)h1 >> ((unsigned)l0 & 31u))));
                    *mp = (unsigned)(2u && ((unsigned)d0 << ((0u ^ (unsigned)c0) & 31u)));
                    break; (void)((i2 * 0xffffffffu));
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(0u || ((unsigned)h0 - u3)), (unsigned)(signed char)(unsigned)((short)(unsigned)(signed char)(0x10000u - 0xffffffffu) > (signed char)(unsigned)(w0 >> 29)), (u3 << ((unsigned)((int)(unsigned)h1 < (int)0x7fffffffu) & 31u))); }
                continue; (void)((unsigned)l0);
            } while (i0++ < 5u && (unsigned)(unsigned char)(g1 >> (p0 & 31u)));
            garr[(unsigned)(u3 < *q0) & 7u] = garr[i1 & 7u];
        }
    }
    h1 = (unsigned short)(h1 + (unsigned)((int)(i1 ? *q0 : 0x80000000u) < (int)0xf764f858u));
    if (budget != 0u) { budget -= 1u; u3 = fn1((0xc54541c9u / (u0 | 1u)), (unsigned)(a0[i0 & 3u] < (r0.x % (r0.y | 1u))), (unsigned)(u0 < a0[u1 & 3u])); }
    if (budget != 0u) { budget -= 1u; u0 = fn1((v0 >> ((v0 ^ i1) & 31u)), (unsigned)(p2 || (garr[i1 & 7u] + u3)), (unsigned)f0); }
    if (i2) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                g0 = ((unsigned)(*mp || u3) - a0[i0 & 3u]);
                if ((unsigned)f0) break;
                if ((unsigned)c1) break;
            }
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.x = p0;
            switch ((r0.x / ((unsigned)((int)*q0 >= (int)0xffffffffu) | 1u)) & 7u) {
                u1 = u1 * 0x9e3779b1u + ((unsigned)(u3 && p0) * ((unsigned)((short)a0[u1 & 3u] > (signed char)g1) % (p0 | 1u)));
                i0 = (unsigned)!((unsigned)x0 + (2u | (unsigned)d0)) & 15u;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)p0 < (int)u2), ((unsigned)c1 + 2u), 0x80000000u); }
                if (a0[i0 & 3u]) goto L2;
            }
            if ((unsigned)f0) {
                if (v0) {
                    for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)((unsigned)!(i1 | (unsigned)(a0[i0 & 3u] < (unsigned)c0)) & 1023u);
                        if (0x7039b0ccu) {
                            b0 = (unsigned)(m0 || i2) != 0u;
                            g0 = (unsigned)!(0xe7f8e179u | (garr[u2 & 7u] ^ (unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)c1)));
                            if (((0xa0cec3b3u ^ 5u) % ((unsigned)w0 | 1u))) break;
                            c1 = (signed char)(unsigned)((int)a0[i0 & 3u] < (int)u1);
                            c0 = (unsigned char)(unsigned)(signed char)(u3 ^ (((unsigned)e0 * (unsigned)w0) / ((unsigned)x0 | 1u)));
                            q0 = &garr[((unsigned)(0xdd2e0398u || 0x57081663u) - (unsigned)((unsigned)(x0 >> 70) || (unsigned)l0)) & 7u];
                        }
                        while ((unsigned)((unsigned)(0xffffffffu == u2) && 0x7fffffffu)) { if (--fuel == 0u) goto done;
                            if (fuel < 8u) return (unsigned)((unsigned)c0 < (unsigned)((int)0xc9dae087u < (int)(unsigned)c1));
                            x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)c1 < (int)((unsigned)((short)(unsigned)s1 > (signed char)0x6ee64f08u) >> ((unsigned)((int)u0 < (int)0x64550445u) & 31u)));
                        }
                        s0 = (int)((0x80000000u % (3u | 1u)) >> ((unsigned)((int)(unsigned)x0 >= (int)(i2 % ((unsigned)(w0 >> 29) | 1u))) & 31u));
                        if ((unsigned)((short)g1 > (signed char)(0xac58eb00u + 0xa6615fdbu))) break;
                    }
                    if (((unsigned)x0 - a0[u1 & 3u])) break;
                    if ((unsigned)(unsigned char)(g1 ? m0 : 0x7fffffffu)) break;
                    if (g1) break;
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)(unsigned)d0 < (int)garr[u2 & 7u])) goto L4;
                    }
                    garr[(unsigned)(signed char)(3u - 0x80000000u) & 7u] = -((unsigned)(short)(unsigned)((unsigned)s1 < fuel) / ((i0 % ((unsigned)h0 | 1u)) | 1u));
                } else {
                    g1 += (0xffffffffu << (garr[u2 & 7u] & 31u));
                }
            } else {
                c0 = (unsigned char)(unsigned)((short)(v0 & (unsigned)w0) > (signed char)((unsigned)s1 % ((unsigned)((int)8u >= (int)g1) | 1u)));
                if ((unsigned)((unsigned)x0 == (unsigned)c0)) break;
                u3 = (unsigned)(unsigned char)((unsigned)(signed char)(unsigned)(g1 < *q0) + (unsigned)s0);
                r0.y ^= (a0[u1 & 3u] - u2);
            }
        }
    }
    i0 = garr[i1 & 7u] & 15u;
    u1 = u1 * 0x9e3779b1u + (0x80000000u + (unsigned)((int)a0[i0 & 3u] < (int)(fuel ? 8u : garr[i1 & 7u])));
    c1 = (signed char)(i2 ^ ((unsigned)h0 ? (a0[i0 & 3u] << ((unsigned)(x0 >> 70) & 31u)) : m0));
    { unsigned t2; double z2; if (((unsigned)((a0[u1 & 3u] - v0) == (unsigned)f0)) & 1u) { t2 = (unsigned)((int)9u < (int)(unsigned)l0); z2 = (double)(((unsigned)((int)fuel >= (int)0x10000u)) & 255u); } if (((unsigned)((a0[u1 & 3u] - v0) == (unsigned)f0)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 += (unsigned)(((9u ? *q0 : r0.x) % ((unsigned)l0 | 1u)) < u0);
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch ((unsigned)((r0.x % (9u | 1u)) == 0x80000000u) & 7u) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(short)((unsigned)l0 ? 0x80000000u : g1), (1u / ((unsigned)(0xd9139aa5u && garr[i1 & 7u]) | 1u)), (7u & (unsigned)l0)); }
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(0xb6fd2500u || (unsigned)(a0[u1 & 3u] < p2)), ((g0 + (unsigned)(w0 >> 29)) - i2), (unsigned)!(0x3fbf4cc9u ? 6u : (unsigned)(x0 >> 70))); }
                    { unsigned t3; double z3; if ((m0) & 1u) { t3 = ~((unsigned)(w0 >> 29) + (unsigned)((int)(unsigned)l0 >= (int)garr[u2 & 7u])); z3 = (double)((((unsigned)x0 << (p0 & 31u))) & 255u); } if ((m0) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(0x80000000u && *mp) && ((0xffffffffu - 0x7fffffffu) * (unsigned)b0)));
                        for (;;) { if (--fuel == 0u) goto done;
                            g0 = *q0;
                            goto done;
                            case 3u: ;
                            if (budget != 0u) { budget -= 1u; u3 = fn0(0x80000000u, 0xffffffffu, 5u); }
                            c1 = (signed char)fuel;
                            case 4u: ;
                        }
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)b0 | (unsigned)f0), 2u, i2); }
                        if (((unsigned)e0 - 0xaad2dc06u)) continue;
                        for (;;) { if (--fuel == 0u) goto done;
                            g1 += (g1 - (3u | ~(unsigned)(v0 < i2)));
                            case 2u: ;
                            m0 ^= ((unsigned)(short)(i1 << ((unsigned)x0 & 31u)) - (unsigned)(signed char)(u2 << (4u & 31u)));
                            h0 = (short)r0.y;
                        }
                        if ((unsigned)s1) continue;
                    }
                    if ((p2 | (0xcd223530u / ((unsigned)c0 | 1u)))) break;
                    case 7u: ;
                    w0 = w0 * 6364136223846793005ull + ((unsigned)e0 / (a0[i0 & 3u] | 1u));
                }
                l0 = (long)((unsigned long)l0 + v0);
                if (*mp) goto L2;
                goto L1;
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        break; (void)((a0[i0 & 3u] | r0.x));
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)p1 < (int)(unsigned)f0), (unsigned)(u2 == (0x80000000u / ((unsigned)s1 | 1u))), u2); }
                        if (((unsigned)((short)(unsigned)f0 > (signed char)i1) * p1)) goto L4;
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)e0, (unsigned)((unsigned)((unsigned)d0 || 0x7fffffffu) < m0), (unsigned)((unsigned)(short)((unsigned)l0 | 0x4d315c99u) < a0[u1 & 3u])); }
                        *mp = (u1 << ((m0 / (g0 | 1u)) & 31u));
                    } while (i0++ < 4u && (unsigned)f0);
                    if (0x2a1228f3u) break;
                }
            }
            if ((u3 * (unsigned)((unsigned)(w0 >> 29) || garr[u2 & 7u]))) break;
        }
        if ((0x10000u & (unsigned)(m0 < *q0))) goto L0;
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)d0 - (unsigned)e0), (unsigned)!(unsigned)(1u == (unsigned)(w0 >> 29)), (unsigned)e0); }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)(g1 == 0x80000000u) < i2), (unsigned)((short)0x10000u > (signed char)(unsigned)!((unsigned)s1 / (garr[i1 & 7u] | 1u))), 0x80000000u); }
            u1 += (unsigned)(signed char)(unsigned)((unsigned)w0 < (unsigned)(unsigned char)(8u ^ (unsigned)c0));
            *q0 += p1;
            if ((unsigned)((int)0u < (int)a0[u1 & 3u])) break;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(r0.x == ((unsigned)d0 ^ (unsigned)w0)), 0u, (unsigned)b0); }
            if (budget != 0u) { budget -= 1u; u2 = fn0(*mp, (r0.x << ((unsigned)s1 & 31u)), ((unsigned)((int)0x80000000u >= (int)0x80000000u) / (1u | 1u))); }
        }
        while (i1++ < 2u && garr[u2 & 7u]) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)h0 && (unsigned)f0)) continue;
            s0 = (int)((unsigned)(x0 >> 70) ^ 2u);
            g0 = (((unsigned)(w0 >> 29) * (u0 * 0x6034f1ffu)) * 0x80000000u);
            switch (((unsigned)h1 / ((unsigned)(0xbdce2c89u || v0) | 1u)) & 7u) {
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    *mp = ((unsigned)((unsigned)c1 || (unsigned)c0) * (0x7fffffffu << (r0.x & 31u)));
                    if ((p0 & ((unsigned)s0 ^ (unsigned)b0))) {
                        { unsigned t4; double z4; if (((unsigned)((int)(0xa068cbb5u + (unsigned)(w0 >> 29)) >= (int)m0)) & 1u) { t4 = (unsigned)((unsigned)l0 || 0x80000000u); z4 = (double)(((unsigned)((unsigned)e0 && (unsigned)f0)) & 255u); } if (((unsigned)((int)(0xa068cbb5u + (unsigned)(w0 >> 29)) >= (int)m0)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                            if (((unsigned)s0 & v0)) break;
                            case 0u: ;
                            garr[i2 & 7u] = garr[u2 & 7u];
                            *q0 += ((unsigned)((unsigned)e0 == (unsigned)f0) - u3);
                            if (u2) break;
                            if ((unsigned)(w0 >> 29)) break;
                        }
                        if ((g0 % (fuel | 1u))) continue;
                    }
                    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        garr[0x80000000u & 7u] = (unsigned)((short)(unsigned)(p0 || ((unsigned)(w0 >> 29) % ((unsigned)(6u && (unsigned)s1) | 1u))) > (signed char)(unsigned)f0);
                        *q0 = (unsigned)((unsigned)(x0 >> 70) == *q0);
                        if (0xffffffffu) continue;
                        s1 = (int)((unsigned)s1 + (unsigned)c0);
                    }
                }
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)((int)(garr[i1 & 7u] * (unsigned)e0) >= (int)(unsigned)((int)r0.x >= (int)(unsigned)h1));
                }
                f0 = f0 * 0.5f + (float)((-(r0.x >> (7u & 31u)) ^ (unsigned)(i2 || 0x7d24b7e1u)) & 255u);
            }
            i0 = (unsigned)((int)(v0 + i2) >= (int)0xf9eba79cu) & 15u;
        }
        c0 = (unsigned char)0x1f835cb9u;
    } while (i0++ < 7u && (unsigned)e0);
    w0 ^= (unsigned long long)(unsigned)((unsigned)d0 || fuel) << (~((unsigned)h0 * (6u + 8u)) & 63u);
    *q0 = 0x6b9d72aeu;
    if (((unsigned)(x0 >> 70) << (7u & 31u))) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1(2u, ((unsigned)(1u && u3) + 1u), (unsigned)((unsigned)s1 < g0)); }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(0xffffffffu, (p2 / (0x63d69e6bu | 1u)), (unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)(unsigned char)((unsigned)h1 % (garr[u2 & 7u] | 1u)))); }
            }
            if ((unsigned)h1) goto L1;
            v0 = (unsigned)((unsigned)((5u << (garr[u2 & 7u] & 31u)) == u0) && (3u + garr[i1 & 7u]));
        }
        if (0x10000u) {
            if (a0[u1 & 3u]) goto L3;
            q0 = &garr[(0x7fffffffu - (v0 * ((1u & fuel) | p0))) & 7u];
            do { if (--fuel == 0u) goto done;
                break; (void)((0x7e0fa2d3u & (unsigned)((unsigned)s1 && 7u)));
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)(unsigned)(p2 == i1) > (signed char)0xffffffffu)) break;
                    q0 = &garr[(unsigned)((g1 * fuel) < (unsigned)w0) & 7u];
                    d0 = d0 * 0.5 + (double)((((unsigned)(unsigned char)(2u * i2) >> (g0 & 31u)) % (garr[i1 & 7u] | 1u)) & 1023u);
                    break; (void)(g0);
                    if ((unsigned)h1) {
                        if (0x698fae6bu) break;
                        break; (void)(i1);
                    }
                    if (*q0) goto L0;
                }
            } while (i0++ < 2u && (unsigned)(u3 && u1));
            if (budget != 0u) { budget -= 1u; u3 = fn0((*mp ^ *q0), (unsigned)!(unsigned)(0x4e246a2u || (u3 >> (0xa1777077u & 31u))), 0x80000000u); }
        } else {
            *mp = 0xc3d9faacu;
            if (r0.y) goto L0;
        }
        goto L4;
    } else {
        b0 = (((unsigned)(x0 >> 70) ^ (unsigned)((short)garr[i1 & 7u] > (signed char)p2)) + (6u * i2)) != 0u;
        goto L3;
        q0 = &garr[(unsigned)(0x8d466d66u && (unsigned)!((unsigned)((short)i1 > (signed char)(unsigned)(*q0 && 0x779476f8u)) & 0u)) & 7u];
        if (budget != 0u) { budget -= 1u; u2 = fn0(~((unsigned)s1 % (a0[u1 & 3u] | 1u)), (unsigned)(p0 < (unsigned)e0), (unsigned)((unsigned)f0 && (unsigned)e0)); }
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[(unsigned)(garr[u2 & 7u] == (unsigned)h0) & 3u] = (unsigned)(7u == *mp);
        do { if (--fuel == 0u) goto done;
            g0 = -(0x10000u << (i0 & 31u));
        } while (i1++ < 5u && (unsigned)((int)(r0.y << (8u & 31u)) >= (int)0x7fffffffu));
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (0x80000000u) break;
            u1 ^= (unsigned)((short)0xe09d70du > (signed char)(0x7fffffffu | (r0.y % ((unsigned)(w0 >> 29) | 1u))));
            u0 += (unsigned)((short)(unsigned)(garr[u2 & 7u] < (unsigned)e0) > (signed char)((g1 * (unsigned)h1) % ((unsigned)h0 | 1u)));
        }
        if (a0[i0 & 3u]) {
            if ((unsigned)l0) break;
            if (budget != 0u) { budget -= 1u; u0 = fn1(0xf33f7453u, (unsigned)((short)g1 > (signed char)(unsigned)(0x7fffffffu && fuel)), (((unsigned)s1 % (p1 | 1u)) ^ *mp)); }
            { unsigned t5; double z5; if ((((unsigned)(signed char)(r0.y | 0x80000000u) + i2)) & 1u) { t5 = (unsigned)(x0 >> 70); z5 = (double)(((unsigned)((int)(unsigned)b0 < (int)(unsigned)(x0 >> 70))) & 255u); } if ((((unsigned)(signed char)(r0.y | 0x80000000u) + i2)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                { unsigned t6; double z6; if ((-(unsigned)(6u < 8u)) & 1u) { t6 = (0x7fffffffu ^ (unsigned)(5u || v0)); z6 = (double)((~(unsigned)(0xffffffffu < (u3 + (unsigned)s1))) & 255u); } if ((-(unsigned)(6u < 8u)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                    if (budget != 0u) { budget -= 1u; u3 = fn1((g1 | g0), (unsigned)(i0 == (unsigned)(0x3f84dcd8u || 0x3d4f144du)), u1); }
                    r0.x = (unsigned)((unsigned)((int)(unsigned)(unsigned char)(i1 ^ (0x7fffffffu + 0xce781b46u)) >= (int)r0.y) || u3);
                    continue; (void)(((unsigned)c0 / ((unsigned)((short)(unsigned)x0 > (signed char)0x6750a6d9u) | 1u)));
                    if (garr[u2 & 7u]) {
                        if ((unsigned)((r0.x ^ (unsigned)s1) || r0.y)) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((0xea0d2319u + (unsigned)!(unsigned)((int)garr[i1 & 7u] >= (int)garr[i1 & 7u])), 0x10000u, (unsigned)b0); }
                        g1 += (unsigned)((int)m0 < (int)(unsigned)((unsigned)(fuel || (unsigned)h0) && (unsigned)d0));
                        { unsigned t7; double z7; if (((r0.x ^ r0.y)) & 1u) { t7 = (i0 << (m0 & 31u)); z7 = (double)(((0x3483c86fu + (unsigned)(w0 >> 29))) & 255u); } if (((r0.x ^ r0.y)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                            if ((unsigned)((short)(r0.y + (unsigned)b0) > (signed char)i2)) break;
                            g1 += u2;
                            b0 = (0x47c2adcfu ^ (unsigned)((int)0xe2b7be9u < (int)m0)) != 0u;
                            if (budget != 0u) { budget -= 1u; u3 = fn0((r0.y % ((unsigned)w0 | 1u)), ((u2 ^ u0) / ((unsigned)f0 | 1u)), 9u); }
                        }
                        if (budget != 0u) { budget -= 1u; u1 = fn0(~(unsigned)((unsigned)(p0 < fuel) || a0[u1 & 3u]), (i1 - v0), (unsigned)(unsigned char)(unsigned)(p0 < 0x80000000u)); }
                    } else {
                        g1 += (((unsigned)c0 + g0) >> ((unsigned)s0 & 31u));
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)h0 < (int)0xb59d0550u), (8u % (0x3c7bbc4fu | 1u)), (0x8089a0bu & v0)); }
                        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                            c1 = (signed char)(i2 ^ (unsigned)!(0x7d8f6d52u | (unsigned)(fuel && a0[i0 & 3u])));
                            q0 = &garr[(unsigned)((int)(((r0.y - 0x623b4f2du) * 0x10000u) | r0.x) >= (int)(unsigned)c0) & 7u];
                            r0.y ^= (unsigned)((int)a0[i0 & 3u] >= (int)m0);
                            if (a0[u1 & 3u]) break;
                        }
                    }
                    d0 = d0 * 0.5 + (double)(((unsigned)(((unsigned)x0 ^ r0.x) < 0xdbf08923u) % ((4u >> ((unsigned)c0 & 31u)) | 1u)) & 1023u);
                    i0 = (unsigned)(0x93751591u < (0xffffffffu * (unsigned)w0)) & 15u;
                }
                d0 = d0 * 0.5 + (double)(((unsigned)s1 * (unsigned)((unsigned)f0 == (unsigned)c0)) & 1023u);
                if (~(unsigned)((int)garr[i1 & 7u] < (int)garr[u2 & 7u])) break;
            }
        } else {
            break; (void)(a0[u1 & 3u]);
        }
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        u2 += (unsigned)((unsigned)((int)(unsigned)x0 >= (int)i2) < (unsigned)l0);
        c0 = (unsigned char)(unsigned)((short)(unsigned)s0 > (signed char)9u);
        u2 ^= (unsigned)(short)((unsigned)(r0.y < 8u) * (unsigned)((int)8u >= (int)(unsigned)(0xffffffffu && 6u)));
        b0 = (unsigned)((7u << (0x8b2a3f72u & 31u)) < (unsigned)((int)0x297bbaa0u < (int)(0xf363a7fcu - (unsigned)f0))) != 0u;
        switch (((r0.y / (*q0 | 1u)) >> ((unsigned)f0 & 31u)) & 7u) {
            do { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (u2) {
                        case 7u: ;
                        f0 = f0 * 0.5f + (float)((unsigned)((int)~(0x80000000u / ((unsigned)((unsigned)h0 || 0x22152d4du) | 1u)) >= (int)i1) & 255u);
                        u1 = u1 * 0x9e3779b1u + (unsigned)!(unsigned)((int)(unsigned)(-(unsigned)((short)0x4d208de9u > (signed char)(unsigned)(w0 >> 29)) || 0x82b432e6u) < (int)g1);
                    } else {
                        garr[(unsigned)(0x5ff60ea6u == u1) & 7u] = (unsigned)(garr[i1 & 7u] < ((unsigned)h1 >> ((unsigned)((int)0x44c42e61u >= (int)a0[u1 & 3u]) & 31u)));
                    }
                    c1 = (signed char)0x27b2cf7bu;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(p0 == (unsigned)(0x10000u < p1)), 0x10000u, ((unsigned)s0 | 0x909bf7e4u)); }
                }
            } while (i1++ < 4u && (unsigned)(((unsigned)h0 % (*q0 | 1u)) == a0[u1 & 3u]));
            switch (u3 & 7u) {
                case 1u: ;
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(unsigned)((int)(unsigned)((int)(unsigned)b0 >= (int)7u) < (int)(unsigned)w0);
                    m0 ^= (unsigned)!((4u + ((unsigned)e0 >> ((unsigned)(w0 >> 29) & 31u))) & (unsigned)w0);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1(2u, (unsigned)(signed char)((unsigned)(0u < garr[u2 & 7u]) << ((unsigned)c0 & 31u)), *q0); }
                s0 = (int)(unsigned)!((unsigned)w0 * i1);
                u1 += 9u;
            }
            case 5u: ;
        }
    }
    goto L1;
    if ((unsigned)c0) goto L1;
    if ((unsigned)((unsigned)((unsigned)h0 && garr[i1 & 7u]) || u1)) {
        if (budget != 0u) { budget -= 1u; u1 = fn0((u2 | 1u), (unsigned)((0x7fffffffu << ((unsigned)(w0 >> 29) & 31u)) == u1), (unsigned)((short)0x80000000u > (signed char)i2)); }
        c1 = (signed char)(i2 + (unsigned)(0x4d82d5eeu == -(*mp / ((garr[u2 & 7u] + (unsigned)c1) | 1u))));
        if ((unsigned)(short)(unsigned)((int)r0.x < (int)r0.x)) {
            if (budget != 0u) { budget -= 1u; u2 = fn0(p0, (unsigned)(i1 < i1), (unsigned)e0); }
            u2 = u2 * 0x9e3779b1u + ((unsigned)c1 & (unsigned)((int)(unsigned)((int)(unsigned)x0 >= (int)u0) >= (int)6u));
            b0 = ~(unsigned)(((unsigned)x0 ^ i1) && 0x36621d96u) != 0u;
            if ((unsigned)(unsigned char)(0xf200a87fu | ((unsigned)x0 ^ (unsigned)b0))) goto L4;
            if ((0x10000u << (5u & 31u))) goto L2;
        } else {
            if (fuel < 8u) return ((unsigned)w0 & (unsigned)((0x82eb261au ^ 0x10000u) < (unsigned)(x0 >> 70)));
            { unsigned t8; double z8; if (((unsigned)((unsigned)(0x7fffffffu == (unsigned)x0) && 0xb0bb162bu)) & 1u) { t8 = *mp; z8 = (double)((((unsigned)s1 << (*q0 & 31u))) & 255u); } if (((unsigned)((unsigned)(0x7fffffffu == (unsigned)x0) && 0xb0bb162bu)) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((0xd4fb14a5u ^ (unsigned)h1)) continue;
                    goto L3;
                    g0 = (unsigned)(u0 && p0);
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)f0 < (int)0xffffffffu), (unsigned)((*mp | i0) == u2), (((unsigned)s1 / (0x80000000u | 1u)) ^ 5u)); }
                }
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((((unsigned)c0 ^ 0x80000000u) * 0x6fa2a85cu)) goto L4;
                    r0.y ^= (unsigned)(-(unsigned)((short)0x184c8575u > (signed char)0x7fffffffu) < (unsigned)(signed char)(unsigned)(3u < 0u));
                    c1 = (signed char)(unsigned)(((unsigned)(0x907d94bdu == 0xa044f124u) >> (0x80000000u & 31u)) && 0x80000000u);
                    if (((unsigned)w0 << ((7u + g0) & 31u))) break;
                    if ((7u - p2)) break;
                    if (((unsigned)w0 & (unsigned)((unsigned)e0 < 0xffffffffu))) continue;
                }
                e0 = e0 * 0.5L + (long double)(a0[u1 & 3u] & 1023u);
                u1 = u1 * 0x9e3779b1u + (*q0 << ((unsigned)c0 & 31u));
                g0 = (unsigned)((unsigned)!(garr[u2 & 7u] | r0.y) == (unsigned)f0);
                l0 = (long)((unsigned long)l0 + (p2 / (i2 | 1u)));
            }
            l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)((short)0u > (signed char)((unsigned)((short)i2 > (signed char)(unsigned)s1) / ((unsigned)(0x7fffffffu == 0x7fb5f2c3u) | 1u))));
            l0 = (long)((unsigned long)l0 + (unsigned)((int)0x6f8ea66u < (int)(0x26368205u & 0xed3e7dbcu)));
        }
        if ((unsigned)((int)i2 < (int)*q0)) {
            if ((r0.x % (u3 | 1u))) goto L3;
            do { if (--fuel == 0u) goto done;
                *q0 += 0x80000000u;
                u0 = u0 * 0x9e3779b1u + (unsigned)(unsigned char)(unsigned)((unsigned)(0x1ac76f7cu == (unsigned)(x0 >> 70)) || (unsigned)(signed char)((unsigned)(5u || 0xe835dbdcu) + 0xffffffffu));
            } while (i0++ < 3u && (unsigned)((int)0x7fffffffu < (int)8u));
        } else {
            r0.y ^= ((unsigned)((int)m0 >= (int)(unsigned)s1) ^ 3u);
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)h0, (0xffffffffu | 7u), 3u); }
            s0 = (int)~(9u ^ (unsigned)(u2 || (0x37363895u / ((unsigned)(5u && (unsigned)c0) | 1u))));
            v0 = (4u % ((unsigned)((unsigned)((int)(unsigned)s1 < (int)(unsigned)h0) || 4u) | 1u));
        }
        if (g0) {
            *mp = (unsigned)((short)((u2 / (u0 | 1u)) / (4u | 1u)) > (signed char)u0);
            q0 = &garr[((unsigned)(short)(unsigned)(u1 == i0) | *mp) & 7u];
        } else {
            e0 = e0 * 0.5L + (long double)(garr[u2 & 7u] & 1023u);
            d0 = d0 * 0.5 + (double)(((unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)s1) ^ u2) & 1023u);
            goto done;
        }
        *q0 += (unsigned)(i1 && p0);
    } else {
        switch (*q0 & 7u) {
            switch ((unsigned)(u3 == (unsigned)(0xc9a55dcu && (unsigned)l0)) & 7u) {
                for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    case 6u: ;
                    *q0 = (unsigned)(0x80000000u == -(unsigned)(i2 || (unsigned)h0));
                }
                for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    while ((unsigned)b0) { if (--fuel == 0u) goto done;
                        *q0 = a0[i0 & 3u];
                    }
                    u3 = ((unsigned)c0 ? (unsigned)!((unsigned)l0 % ((unsigned)b0 | 1u)) : (unsigned)!(unsigned)((unsigned)c0 < (unsigned)l0));
                    if ((unsigned)((int)9u >= (int)(unsigned)(6u && 0x10000u))) continue;
                }
                case 3u: ;
                c0 = (unsigned char)p1;
                if (u3 == 7u) return (((unsigned)((short)0xffffffffu > (signed char)9u) >> (1u & 31u)) / (p2 | 1u));
            }
        }
        if ((unsigned)((short)r0.x > (signed char)(unsigned)e0)) {
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(x0 >> 70)) break;
                if ((unsigned)((int)(unsigned)(fuel == u0) < (int)(unsigned)l0)) {
                    c1 = (signed char)(unsigned)(((unsigned)(a0[i0 & 3u] || 0x7fffffffu) ^ (unsigned)c1) == ((unsigned)b0 ^ (unsigned)l0));
                    continue; (void)(0x7fffffffu);
                    if ((unsigned)((int)~(unsigned)(i1 || p1) >= (int)(unsigned)w0)) continue;
                    break; (void)(7u);
                    if (((p2 * 0x5bbc325eu) - 7u)) goto L4;
                    continue; (void)(r0.y);
                } else {
                    if (((a0[u1 & 3u] % (garr[i1 & 7u] | 1u)) >> ((unsigned)s1 & 31u))) {
                        if (budget != 0u) { budget -= 1u; u0 = fn1(a0[u1 & 3u], 0x47158b6au, ((unsigned)b0 % (0x917b9fecu | 1u))); }
                        if (fuel < 8u) return (7u - (i2 / ((unsigned)((int)0xffffffffu >= (int)g1) | 1u)));
                    } else {
                        break; (void)((unsigned)(8u < (unsigned)f0));
                        g0 = ~(((u2 * 0xe7b2f4a0u) % (((unsigned)x0 % (g1 | 1u)) | 1u)) % ((unsigned)h0 | 1u));
                        if (fuel < 8u) return (~((unsigned)s1 * 0xc87df651u) % (7u | 1u));
                    }
                    *q0 = (unsigned)(2u == (u3 ? i1 : (unsigned)(a0[u1 & 3u] && 0x7fffffffu)));
                    for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (((unsigned)(0xc03167c9u || (unsigned)s0) ^ 0u)) continue;
                    }
                }
                if (6u) break;
            }
            e0 = e0 * 0.5L + (long double)(i2 & 1023u);
            m0 ^= ((0xd3d9001fu & (unsigned)b0) << ((unsigned)d0 & 31u));
            if (((unsigned)(signed char)(unsigned)(u0 && 0xffffffffu) & 4u)) {
                s0 = (int)((0x7fffffffu + (unsigned)x0) - 9u);
                if ((unsigned)((0xffffffffu + (unsigned)c0) < 0x680ab16cu)) goto L0;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(unsigned char)(p0 >> ((unsigned)e0 & 31u)), 0x400d8fcbu, i2); }
                if ((unsigned)l0) {
                    if ((unsigned)f0) goto L3;
                }
                d0 = d0 * 0.5 + (double)((unsigned)b0 & 1023u);
                if ((unsigned)((unsigned)h0 && (0xffffffffu & *q0))) goto L3;
            } else {
                garr[(unsigned)f0 & 7u] = (i0 & 0x7fffffffu);
            }
            switch ((0xdf0058d7u >> ((unsigned)((unsigned)(x0 >> 70) || 0x10000u) & 31u)) & 7u) {
                if (((unsigned)(short)(unsigned)((unsigned)s0 < p0) - i2)) break;
                for (;;) { if (--fuel == 0u) goto done;
                    case 0u: ;
                    continue; (void)(a0[u1 & 3u]);
                    e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)!(unsigned)((unsigned)e0 < fuel) > (signed char)~((r0.x ^ 0xf6f1fee3u) >> (m0 & 31u))) & 1023u);
                    w0 = w0 * 6364136223846793005ull + (unsigned)((0x7299b82cu & i2) && (i1 << ((6u + g0) & 31u)));
                    if ((unsigned)(u2 && (u2 - r0.x))) goto L3;
                }
            }
        }
        switch (5u & 7u) {
            case 0u: ;
            if (((unsigned)((int)a0[i0 & 3u] < (int)garr[u2 & 7u]) - (unsigned)w0)) goto L0;
            x0 = x0 * 0x100000001b3ull + (0x10000u ? 8u : a0[u1 & 3u]);
            case 4u: ;
            break; (void)((i1 | g0));
        }
    }
    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)h1 && (9u % (u2 | 1u))) & 255u);
    s1 = (int)((unsigned)s1 + 0u);
    do { if (--fuel == 0u) goto done;
        u3 = u3 * 0x9e3779b1u + (unsigned)(0xecb88c54u == (unsigned)h0);
    } while (i0++ < 6u && *mp);
    g0 = (7u / ((unsigned)s1 | 1u));
    u3 += ((unsigned)b0 % (*mp | 1u));
    m0 ^= (unsigned)((short)(unsigned)(i1 == ((unsigned)(x0 >> 70) ^ (unsigned)c0)) > (signed char)9u);
    if ((unsigned)((int)v0 >= (int)(unsigned)l0)) {
        if (budget != 0u) { budget -= 1u; u3 = fn1((fuel * (unsigned)(0x261be588u < (unsigned)x0)), (unsigned)((unsigned)h1 && ((unsigned)b0 - a0[u1 & 3u])), ((unsigned)((int)*mp >= (int)u3) ^ 0x10000u)); }
        if ((unsigned)((int)(unsigned)l0 >= (int)garr[u2 & 7u])) goto L1;
        if (fuel < 8u) return (unsigned)(short)(0x80000000u - (unsigned)f0);
    } else {
        goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)((short)(0x7fffffffu * (unsigned)(x0 >> 70)) > (signed char)9u);
    }
    u3 ^= (unsigned)((unsigned)(short)(unsigned)(0xffffffffu < ((unsigned)d0 / ((unsigned)c1 | 1u))) && (9u - 0x774face0u));
    if (5u) goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(short)((unsigned)(r0.y || a0[u1 & 3u]) << (0xffffffffu & 31u)), (0u % ((unsigned)h0 | 1u)), i0); }
        h0 = (short)-(unsigned)((unsigned)d0 == (unsigned)((short)(unsigned)((short)7u > (signed char)i0) > (signed char)*q0));
        if (0x7fffffffu) break;
    }
    if (((unsigned)x0 & (0x10000u >> (5u & 31u)))) goto L0;
    goto done;
    v0 = a0[i0 & 3u];
    *q0 = 5u;
    if ((unsigned)(signed char)((unsigned)b0 % ((r0.x ^ 0xffffffffu) | 1u))) goto L2;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)1u < (int)u3)) {
                if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(w0 >> 29) ? (unsigned)d0 : 3u), (unsigned)c0, ((unsigned)d0 - 0x99889d25u)); }
                d0 = d0 * 0.5 + (double)(((unsigned)((int)u2 >= (int)0x7bbe9d1au) ^ ((unsigned)s0 % ((unsigned)c1 | 1u))) & 1023u);
                r0.x = (unsigned)((unsigned)b0 == 3u);
            } else {
                if (i0) break;
            }
        }
        do { if (--fuel == 0u) goto done;
            if (0xffffffffu) break;
            continue; (void)((unsigned)(x0 >> 70));
            if ((u0 & 0x80000000u)) {
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)i2 > (signed char)((0u >> ((unsigned)c0 & 31u)) % ((p0 * u3) | 1u)));
                h0 = (short)u1;
                garr[a0[i0 & 3u] & 7u] = (unsigned)s0;
                if ((unsigned)(w0 >> 29)) continue;
                if ((unsigned)s1) break;
                L0: if (--fuel == 0u) goto done;
            }
            break; (void)(m0);
        } while (i1++ < 3u && 9u);
        a0[(i1 << (garr[u2 & 7u] & 31u)) & 3u] = (unsigned)(9u && ((u0 + (unsigned)c1) / (u1 | 1u)));
        if (u2) continue;
        if (((unsigned)l0 & (unsigned)w0)) break;
        L1: if (--fuel == 0u) goto done;
    }
    while ((unsigned)(*mp == 3u)) { if (--fuel == 0u) goto done;
        if ((u1 | -(a0[i0 & 3u] + 0x6d3bae71u))) break;
        if (((2u >> (u1 & 31u)) % (0x2c056609u | 1u))) continue;
        d0 = d0 * 0.5 + (double)(((unsigned)(0x80000000u && i0) % ((unsigned)((8u | (unsigned)(x0 >> 70)) || 6u) | 1u)) & 1023u);
        if (((unsigned)((int)p0 < (int)(unsigned)h0) ^ 0x7fffffffu)) break;
        if ((unsigned)(-(0x80000000u | (unsigned)d0) < 9u)) {
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u1) break;
                w0 = w0 * 6364136223846793005ull + (unsigned)((v0 << ((unsigned)((unsigned)l0 && (unsigned)w0) & 31u)) == u2);
                *q0 = ((unsigned)h0 & 0x30d5e363u);
                if (((0u >> (0xffffffffu & 31u)) ^ (unsigned)c1)) {
                    break; (void)(4u);
                    d0 = d0 * 0.5 + (double)(((unsigned)w0 + (6u * (unsigned)f0)) & 1023u);
                    x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)(u1 || 0x19ad6bc4u) == (unsigned)l0);
                    b0 = ~((unsigned)(unsigned char)(*q0 - 3u) * 0xffffffffu) != 0u;
                    u1 += ((unsigned)(0x48282150u || 2u) * (unsigned)((unsigned)h1 && i2));
                    *q0 += (unsigned)((unsigned)h1 && 0xabd34272u);
                }
                continue; (void)((3u >> ((unsigned)s1 & 31u)));
            }
        }
    }
    while (i0++ < 5u && (unsigned)((short)(g1 >> (g0 & 31u)) > (signed char)garr[u2 & 7u])) { if (--fuel == 0u) goto done;
        L2: if (--fuel == 0u) goto done;
        g1 += (unsigned)!((unsigned)f0 << (0u & 31u));
        if (budget != 0u) { budget -= 1u; u0 = fn0(((i0 & (unsigned)s1) / (0x20fa5a54u | 1u)), (unsigned)!(unsigned)((short)(g1 << ((unsigned)c1 & 31u)) > (signed char)u3), 3u); }
        u3 += (g0 ? 0x10000u : u3);
        L3: if (--fuel == 0u) goto done;
    }
    if (((unsigned)(p0 < u3) << ((unsigned)h1 & 31u))) {
        w0 ^= (unsigned long long)(unsigned)!(unsigned)((int)u3 < (int)4u) << ((unsigned)((((unsigned)h0 << ((unsigned)((int)0x68abe529u < (int)0x679df1b0u) & 31u)) / ((unsigned)s1 | 1u)) < (unsigned)(w0 >> 29)) & 63u);
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((((unsigned)((int)8u < (int)p0) & (unsigned)((int)6u < (int)0x7fffffffu)) | 1u) & 1023u);
            h0 = (short)(unsigned)((0x7949b0b3u % (0x27356187u | 1u)) || (unsigned)!((unsigned)x0 * (unsigned)l0));
            if ((unsigned)((unsigned)h1 < a0[u1 & 3u])) {
                if (((unsigned)s0 + i1)) {
                    if ((unsigned)!(unsigned)(*q0 && ((unsigned)l0 / (g0 | 1u)))) continue;
                    s0 = (int)((unsigned)b0 / ((fuel & a0[u1 & 3u]) | 1u));
                    continue; (void)(0x10000u);
                } else {
                    while (i1++ < 7u && (i0 * ~(8u / (*mp | 1u)))) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(unsigned char)(p1 + *q0), (u2 << ((unsigned)((int)g0 < (int)a0[u1 & 3u]) & 31u)), (unsigned)(signed char)(a0[u1 & 3u] ^ (unsigned)b0)); }
                        if (p1) break;
                        if (((unsigned)!(0x7fffffffu | 0xffffffffu) | 5u)) continue;
                        if (fuel < 8u) return ((unsigned)w0 << (r0.x & 31u));
                        r0.y ^= r0.x;
                        if ((unsigned)(-(a0[i0 & 3u] * 0x3c11194eu) == (unsigned)c0)) break;
                    }
                    switch ((unsigned)((unsigned)h0 == 0x80000000u) & 7u) {
                        if (fuel < 8u) return -((unsigned)(w0 >> 29) - *mp);
                        goto L1;
                        h1 = (unsigned short)(h1 + 0x8e452b8du);
                        L4: if (--fuel == 0u) goto done;
                    }
                }
            }
            r0.y ^= ((unsigned)(((unsigned)!(garr[u2 & 7u] / (0x10000u | 1u)) & (unsigned)h1) == (unsigned)c1) | garr[u2 & 7u]);
            if (~(0x4426de9eu & (unsigned)((unsigned)c1 == 0x7caa79aau))) continue;
        }
        if (((unsigned)(unsigned char)((unsigned)s1 - (unsigned)s0) & 0x89ee7b7cu)) goto L3;
        if ((unsigned)((unsigned)b0 == 0x72f286d0u)) {
            do { if (--fuel == 0u) goto done;
                if (((unsigned)w0 * (unsigned)f0)) {
                    if ((0x10000u - (r0.x / ((unsigned)c1 | 1u)))) goto L1;
                    while (i1++ < 3u && (unsigned)(0x80000000u || 0x14951632u)) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((0x7fffffffu + a0[i0 & 3u]), a0[u1 & 3u], (g0 & (unsigned)h1)); }
                        if (fuel < 8u) return ((u1 & (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)e0)) << ((unsigned)h0 & 31u));
                        g0 = 7u;
                        u2 = ((unsigned)c1 ? a0[u1 & 3u] : (unsigned)s0);
                        switch ((unsigned)((int)u0 >= (int)(unsigned)x0) & 7u) {
                            s1 = (int)((unsigned)s1 + (r0.x | r0.y));
                            r0.x = (((p1 << (0xffffffffu & 31u)) | (unsigned)s1) + i1);
                        }
                    }
                    if ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)((int)(unsigned)h0 >= (int)(unsigned)s1))) break;
                    h0 = (short)(unsigned)(signed char)(7u + u2);
                    s1 = (int)((unsigned)s1 + (((u0 >> (r0.y & 31u)) % (6u | 1u)) ^ ((unsigned)e0 >> ((unsigned)f0 & 31u))));
                } else {
                    g0 = 4u;
                    v0 = (p2 * (unsigned)(6u == -(p2 | (unsigned)c1)));
                    if ((unsigned)w0) break;
                    if (0x77a2379fu) break;
                }
                continue; (void)((unsigned)!((unsigned)w0 * 0x80000000u));
                if (budget != 0u) { budget -= 1u; u3 = fn0((g0 + (unsigned)s1), r0.x, i1); }
            } while (i0++ < 5u && (((unsigned)f0 / (*q0 | 1u)) * u0));
            r0.x = (unsigned)((unsigned)c0 || (unsigned)c0);
            goto L1;
            w0 = w0 * 6364136223846793005ull + (unsigned)(0x9d7a00c9u && (unsigned)((short)garr[i1 & 7u] > (signed char)((0x7fffffffu << (r0.y & 31u)) * garr[i1 & 7u])));
            switch ((unsigned)s0 & 7u) {
                if (0x10000u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn1(8u, p2, (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)h1)); }
                    u3 ^= (unsigned)(i1 == ((unsigned)((int)p1 < (int)v0) + v0));
                    break; (void)(p1);
                    if ((unsigned)(short)(0x80000000u >> (5u & 31u))) goto L3;
                    case 5u: ;
                }
                do { if (--fuel == 0u) goto done;
                    while (i1++ < 7u && (unsigned)((short)u3 > (signed char)(unsigned)((int)a0[i0 & 3u] >= (int)i0))) { if (--fuel == 0u) goto done;
                        u2 = (unsigned)((int)(unsigned)(4u < (7u + i2)) < (int)0x7d171e60u);
                        case 1u: ;
                        if (garr[u2 & 7u]) break;
                        garr[(0xe3cefb92u >> (3u & 31u)) & 7u] = ((g1 % (0xee9ec6bau | 1u)) >> (((6u + (unsigned)l0) * r0.y) & 31u));
                        for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn1((0x80000000u + (unsigned)l0), (((unsigned)x0 * i2) << (0x5fe8c6du & 31u)), (unsigned)!(unsigned)((int)(unsigned)c0 >= (int)(fuel & garr[u2 & 7u]))); }
                            d0 = d0 * 0.5 + (double)((unsigned)((0u & (unsigned)s1) && (unsigned)((int)fuel >= (int)(*q0 >> (i1 & 31u)))) & 1023u);
                        }
                        for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                            *q0 += (unsigned)((0x4d350995u << (u3 & 31u)) == (unsigned)(u3 == 7u));
                        }
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)r0.x >= (int)g0), (unsigned)((p0 * 4u) && r0.x), (v0 + (unsigned)((unsigned)c1 == u2))); }
                    l0 = (long)((unsigned long)l0 + (unsigned)((short)0u > (signed char)(m0 >> (g1 & 31u))));
                    u2 = (a0[i0 & 3u] ? i0 : 0x311331c4u);
                } while (i0++ < 3u && (u2 + garr[u2 & 7u]));
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((unsigned)(0x80000000u == a0[u1 & 3u]) && a0[i0 & 3u]), ((unsigned)!(unsigned)(m0 && 0x15aad315u) << (garr[u2 & 7u] & 31u)), (unsigned)((short)0x7fffffffu > (signed char)u0)); }
                x0 = x0 * 0x100000001b3ull + (unsigned)((g0 ? a0[i0 & 3u] : *q0) == (unsigned)!(unsigned)(u3 < (unsigned)w0));
                case 3u: ;
                if (-(unsigned)(r0.y == r0.y)) {
                    case 4u: ;
                } else {
                    case 0u: ;
                    if (fuel) goto L0;
                    s1 = (int)((unsigned)s1 + (unsigned)!(unsigned)((0x7fffffffu | (i1 + r0.x)) || -(u0 - 0x4319a705u)));
                    c1 = (signed char)(unsigned)((unsigned)x0 < (((unsigned)(w0 >> 29) / (7u | 1u)) << ((unsigned)((unsigned)e0 || u1) & 31u)));
                }
            }
            for (;;) { if (--fuel == 0u) goto done;
                if (i2) break;
            }
        } else {
            w0 ^= (unsigned long long)(unsigned)f0 << ((0xc64097d0u | 8u) & 63u);
            if ((unsigned)(((unsigned)w0 >> (garr[u2 & 7u] & 31u)) && g0)) {
                if (p2) {
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)2u > (signed char)0xffffffffu), ((unsigned)((int)u0 >= (int)0x173f3036u) >> (0x10000u & 31u)), fuel); }
                    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        q0 = &garr[(g1 | (unsigned)((int)(*q0 % (0x6a3b9b4bu | 1u)) < (int)(0x654a84d4u % (p0 | 1u)))) & 7u];
                        h0 = (short)(unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) == 3u);
                    }
                } else {
                    if ((unsigned)(3u < *q0)) {
                        if (budget != 0u) { budget -= 1u; u2 = fn0(5u, 0x7fffffffu, (u1 ? 5u : r0.y)); }
                        h0 = (short)(unsigned)!((unsigned)d0 << (u3 & 31u));
                        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)l0, (unsigned)((unsigned)((unsigned)h1 < (unsigned)x0) && p2), 0x7fffffffu); }
                    }
                    if ((unsigned)((int)m0 >= (int)(unsigned)d0)) goto L1;
                    if ((unsigned)(signed char)(r0.x + a0[i0 & 3u])) goto L1;
                    goto L4;
                }
            }
        }
        if (i1) goto done;
    }
    if ((unsigned)((garr[u2 & 7u] / (0x7fffffffu | 1u)) == 0x5adeb74bu)) {
        switch ((i0 * 0x3a68bf1cu) & 7u) {
            while (i0++ < 4u && 4u) { if (--fuel == 0u) goto done;
                u1 ^= (g0 ^ (0xc48b8833u ? u3 : (unsigned)s0));
                case 6u: ;
                if (budget != 0u) { budget -= 1u; u1 = fn0(3u, (unsigned)(0u < (unsigned)l0), garr[i1 & 7u]); }
            }
            e0 = e0 * 0.5L + (long double)((unsigned)(*q0 < p0) & 1023u);
            q0 = &garr[(unsigned)(a0[i0 & 3u] && 0x8525bf0eu) & 7u];
            v0 = 6u;
            if (budget != 0u) { budget -= 1u; u1 = fn2(-(unsigned)((short)(unsigned)x0 > (signed char)(unsigned)s1), (u1 % (a0[u1 & 3u] | 1u)), ((unsigned)c1 / ((unsigned)!((unsigned)c1 & p0) | 1u))); }
        }
        if ((unsigned)((int)(2u + garr[u2 & 7u]) < (int)(unsigned)(w0 >> 29))) goto L4;
        if (-(unsigned)((int)0x80000000u >= (int)0xffffffffu)) goto done;
        do { if (--fuel == 0u) goto done;
            i2 = (unsigned)!(unsigned)((int)(unsigned)((p2 - (unsigned)c1) < (unsigned)h0) < (int)(unsigned)(x0 >> 70)) & 15u;
            if ((unsigned)(p0 && i0)) {
                if ((unsigned)(*mp && (unsigned)(w0 >> 29))) break;
            } else {
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)(0xbc272311u);
                        break; (void)(0x7fffffffu);
                        h1 = (unsigned short)(h1 + (unsigned)((int)garr[u2 & 7u] < (int)((unsigned)(unsigned char)(((unsigned)(x0 >> 70) << (0xffffffffu & 31u)) * garr[i1 & 7u]) >> (p1 & 31u))));
                        garr[i0 & 7u] = (a0[i0 & 3u] ^ (unsigned)((short)4u > (signed char)i2));
                    }
                    c1 = (signed char)(unsigned)((int)*q0 >= (int)(unsigned)((int)4u < (int)(0x5208e270u - m0)));
                    f0 = f0 * 0.5f + (float)((i2 ^ (0x1eda33a6u - v0)) & 255u);
                    if ((unsigned)s1) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(i0, (a0[i0 & 3u] >> (6u & 31u)), u3); }
                }
            }
            continue; (void)(0x10000u);
            while (i1++ < 3u && 0xffffffffu) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)l0, (unsigned)(signed char)(0x224e2bb7u % (r0.x | 1u)), 0xfa74755du); }
            }
        } while (i0++ < 4u && (unsigned)(w0 >> 29));
        f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(-((unsigned)((unsigned)h1 || g1) | (unsigned)s0) + 0x80000000u) & 255u);
        goto L3;
    }
    while (((unsigned)(x0 >> 70) / (1u | 1u))) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(0x827432d5u == g0), 0xbfcf60deu, ((u1 ^ (unsigned)h1) & (unsigned)b0)); }
        break; (void)((unsigned)(4u == g0));
        if (u0) break;
    }
    v0 = (unsigned)((int)0x10000u >= (int)(unsigned)((int)((unsigned)b0 | 0x664afe79u) < (int)(unsigned)!(4u - 0xffffffffu)));
    if (~(((unsigned)l0 / (g1 | 1u)) + 3u)) {
        if ((unsigned)(0xfadfe084u == (u0 % (*q0 | 1u)))) goto L4;
        u3 = u3 * 0x9e3779b1u + (unsigned)x0;
        if (((unsigned)s0 >> ((g0 | garr[i1 & 7u]) & 31u))) goto L4;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (-(unsigned)((short)(unsigned)s0 > (signed char)(unsigned)((int)u3 >= (int)(unsigned)l0))) continue;
            if (0x3c489ac0u) goto L0;
            if (((unsigned)d0 & (u2 / ((unsigned)b0 | 1u)))) break;
            h1 = (unsigned short)(h1 + (unsigned)(signed char)((unsigned)f0 & (unsigned)d0));
            i0 = (unsigned)(unsigned char)(p0 % ((unsigned)(x0 >> 70) | 1u)) & 15u;
            break; (void)((unsigned)(a0[u1 & 3u] < a0[u1 & 3u]));
        }
    }
    u1 = (0x8db7a79fu & g1);
    r0.x = ((unsigned)((unsigned)((unsigned)s0 < (unsigned)c0) < p1) / ((unsigned)(p1 || u2) | 1u));
    v0 = (unsigned)l0;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((*q0 * (unsigned)b0)) {
            if ((8u >> (p1 & 31u))) continue;
            g1 += ((unsigned)s1 & r0.x);
            break; (void)((0x7fffffffu ^ (5u - 1u)));
            if (budget != 0u) { budget -= 1u; u0 = fn1(0x86bec47u, (unsigned)((short)u3 > (signed char)(unsigned)((int)0x861883eeu < (int)p1)), i0); }
        }
        u1 ^= (9u + (((unsigned)s1 + 0xa2d56f6eu) % ((unsigned)l0 | 1u)));
        if (((unsigned)w0 ^ garr[u2 & 7u])) goto L4;
        *q0 += (0x9582db1eu - (9u & 0xffffffffu));
    }
    if ((unsigned)f0) {
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)(unsigned)l0 >= (int)0x7fffffffu), garr[i1 & 7u], 2u); }
        if (((unsigned)(x0 >> 70) ? (unsigned)c1 : i0)) {
            if ((unsigned)(8u && (unsigned)((short)*q0 > (signed char)3u))) goto L1;
            switch ((0xfad7e579u ? 0x80000000u : 0xffffffffu) & 7u) {
                while ((unsigned)f0) { if (--fuel == 0u) goto done;
                    u1 ^= -(a0[u1 & 3u] * p2);
                    if (p1) {
                        for (;;) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(short)(0x80000000u % (((unsigned)l0 ^ (unsigned)c0) | 1u)), 0xffffffffu, ((unsigned)h1 >> (0x10000u & 31u))); }
                            case 4u: ;
                            i2 = (unsigned)((int)~(unsigned)((unsigned)(w0 >> 29) || p2) >= (int)(((unsigned)(w0 >> 29) >> (garr[u2 & 7u] & 31u)) & (unsigned)s1)) & 15u;
                        }
                    } else {
                        i1 = (g0 & (unsigned)l0) & 15u;
                        s0 = (int)g0;
                    }
                }
                while ((unsigned)(0xffffffffu || fuel)) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)u1 << ((unsigned)((int)(u2 % (i1 | 1u)) < (int)5u) & 63u);
                    a0[(unsigned)(short)(i0 * 0xf5c6dc11u) & 3u] = -(unsigned)((int)(unsigned)((unsigned)f0 || 0x10000u) < (int)(unsigned)(0x82b4f7edu < 5u));
                    u2 = ((unsigned)((int)i1 >= (int)g1) - 7u);
                    case 3u: ;
                }
                w0 ^= (unsigned long long)(unsigned)(u3 == 0xb0970c75u) << ((unsigned)c1 & 63u);
                w0 = w0 * 6364136223846793005ull + 0x7fffffffu;
                if (budget != 0u) { budget -= 1u; u3 = fn1((p0 & (unsigned)(i1 == p0)), p1, (unsigned)(unsigned char)(unsigned)((short)a0[i0 & 3u] > (signed char)~(garr[u2 & 7u] + 0x5e1e50c5u))); }
            }
            goto L4;
            if (-((unsigned)((int)a0[i0 & 3u] >= (int)i2) % ((unsigned)(w0 >> 29) | 1u))) {
                if (u1) goto done;
            }
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                continue; (void)(i0);
                do { if (--fuel == 0u) goto done;
                    while (i0++ < 5u && (unsigned)((int)7u < (int)(unsigned)l0)) { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)(((unsigned)c0 ^ (a0[u1 & 3u] | i1)) & 255u);
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((0xffffffffu | 0x7fffffffu) || (unsigned)w0), 0x6aa3084au, (unsigned)((short)a0[i0 & 3u] > (signed char)~(unsigned)((short)u0 > (signed char)a0[i0 & 3u]))); }
                    }
                    if ((unsigned)(0xffffffffu && (unsigned)(0xffffffffu == u0))) break;
                    g0 = ((0u * 7u) << (4u & 31u));
                } while (i2++ < 6u && (u1 + i0));
                if (budget != 0u) { budget -= 1u; u2 = fn1((2u / ((unsigned)s1 | 1u)), (unsigned)s0, (*q0 << ((unsigned)w0 & 31u))); }
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    for (;;) { if (--fuel == 0u) goto done;
                        goto L0;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(5u, 0x10000u, i1); }
                        if ((unsigned)!(0x10000u * 0x6d572d3du)) break;
                    }
                    break; (void)(((unsigned)c1 * garr[u2 & 7u]));
                }
                u1 ^= (unsigned)e0;
            }
        }
        switch (u2 & 7u) {
            if (fuel < 8u) return (((unsigned)s0 ^ (unsigned)x0) << ((unsigned)c0 & 31u));
            if (0x80000000u) {
                u3 += (fuel << (garr[u2 & 7u] & 31u));
                b0 = ((unsigned)b0 << ((0x7fffffffu << (4u & 31u)) & 31u)) != 0u;
                h0 = (short)(((unsigned)(w0 >> 29) & ((unsigned)e0 & 0x62a11303u)) / ((0x56e081d0u + 1u) | 1u));
                r0.x = (unsigned)(unsigned char)(unsigned)((int)*q0 >= (int)garr[i1 & 7u]);
            } else {
                case 1u: ;
                l0 = (long)((unsigned long)l0 + (unsigned)((5u * g0) == (unsigned)s1));
            }
            { unsigned t0; double z0; if ((garr[i1 & 7u]) & 1u) { t0 = (unsigned)h1; z0 = (double)((i0) & 255u); } if ((garr[i1 & 7u]) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                if (p2) {
                    goto L4;
                    case 5u: ;
                } else {
                    case 2u: ;
                    if ((unsigned)(m0 < garr[i1 & 7u])) goto done;
                }
            }
            w0 ^= (unsigned long long)((unsigned)c1 * 0x42fe46u) << ((r0.x & 0x2c77732au) & 63u);
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)!((unsigned)((int)5u < (int)(unsigned)(w0 >> 29)) * m0), (unsigned)!(unsigned)(0xd611b211u == (unsigned)h0), (unsigned)((3u + (unsigned)e0) < (unsigned)s0)); }
        }
        switch ((0xffffffffu ? v0 : (unsigned)s0) & 7u) {
            u1 = u1 * 0x9e3779b1u + (((unsigned)h0 >> ((*mp + 0x7fffffffu) & 31u)) * (unsigned)((int)*q0 < (int)g0));
            case 0u: ;
            u0 += ((4u << ((0x80000000u | a0[i0 & 3u]) & 31u)) / (i1 | 1u));
            switch (~(unsigned)((short)3u > (signed char)0x10000u) & 7u) {
                while (i0++ < 5u && m0) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(u2, (v0 + (0x10000u / ((unsigned)x0 | 1u))), ((unsigned)x0 - (unsigned)e0)); }
                    garr[(0xffffffffu ^ a0[u1 & 3u]) & 7u] = (unsigned)!(unsigned)(((unsigned)l0 % ((p1 << (r0.x & 31u)) | 1u)) < ~(0xffffffffu - fuel));
                    if ((unsigned)(signed char)(0x8acf155u & p1)) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((*q0 + (unsigned)(x0 >> 70)), 6u, (unsigned)c1); }
                    case 3u: ;
                }
            }
            case 2u: ;
        }
        if ((unsigned)!((unsigned)c1 ^ (unsigned)w0)) goto L4;
    }
    u0 = (unsigned)(short)(garr[i1 & 7u] / ((unsigned)(i1 == (((unsigned)x0 & 0x7ddc25eeu) * 0x10000u)) | 1u));
    do { if (--fuel == 0u) goto done;
        if (a0[u1 & 3u]) goto L2;
        w0 = w0 * 6364136223846793005ull + ((unsigned)(v0 || (unsigned)w0) << ((unsigned)((unsigned)(*mp || (unsigned)f0) == *q0) & 31u));
        while (i1++ < 7u && (unsigned)(unsigned char)(v0 ^ *q0)) { if (--fuel == 0u) goto done;
            switch (2u & 7u) {
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)s1 && i2);
                case 6u: ;
                s0 = (int)((unsigned)((int)*q0 < (int)(unsigned)(x0 >> 70)) & 0xee448722u);
            }
            x0 = x0 * 0x100000001b3ull + (unsigned)s1;
        }
        l0 = (long)((unsigned long)l0 + (0xffffffffu / ((9u - u2) | 1u)));
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)(unsigned)(p2 || (unsigned)c0) >= (int)7u), (unsigned)((short)i0 > (signed char)i1), (unsigned)(w0 >> 29)); }
        garr[(unsigned)(signed char)((unsigned)x0 | a0[u1 & 3u]) & 7u] = 0x7fffffffu;
    } while (i0++ < 2u && (g0 % (fuel | 1u)));
    { unsigned t1; double z1; if (((unsigned)((int)fuel < (int)(unsigned)(unsigned char)(0x53b5a509u - p0))) & 1u) { t1 = 8u; z1 = (double)(((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0xc2bcbc15u)) & 255u); } if (((unsigned)((int)fuel < (int)(unsigned)(unsigned char)(0x53b5a509u - p0))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        s0 = (int)8u;
        if ((garr[u2 & 7u] | ((unsigned)s1 ^ 0x7fffffffu))) goto L2;
        if ((unsigned)(0x10000u == 0xd86c3865u)) goto L0;
    }
    u2 ^= i0;
    if (((unsigned)((int)(unsigned)x0 < (int)r0.y) >> (u2 & 31u))) goto L4;
    if ((unsigned)(0xedab1281u && (unsigned)h1)) goto L3;
    if (-(u3 | 0xda782cfu)) goto L1;
    u1 = (unsigned)(u1 == (0x9eeba452u >> (6u & 31u)));
    for (;;) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)!(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)((int)a0[i0 & 3u] < (int)0xca9cadafu)));
            if (0x7fffffffu) break;
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((r0.y % ((garr[u2 & 7u] ^ (unsigned)f0) | 1u))) break;
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(0u == 0x80000000u), g1, u0); }
                    if ((unsigned)h1) {
                        continue; (void)((unsigned)(0xffffffffu < (unsigned)b0));
                    } else {
                        u1 ^= (unsigned)((a0[i0 & 3u] ^ (unsigned)(w0 >> 29)) == p0);
                        if ((unsigned)((unsigned)w0 || (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)x0))) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn1(~((unsigned)w0 / ((unsigned)s0 | 1u)), (0xaaad3ac7u | (unsigned)d0), (unsigned)(w0 >> 29)); }
                    }
                    u2 = (unsigned)(w0 >> 29);
                    r0.x = (unsigned)((int)(unsigned)w0 < (int)((unsigned)d0 ? p2 : 3u));
                }
                if ((0u ^ (u2 | p1))) break;
                h1 = (unsigned short)(h1 + (0x7fffffffu / ((unsigned)w0 | 1u)));
                h1 = (unsigned short)(h1 + ((unsigned)l0 / (i2 | 1u)));
                if ((u1 % ((unsigned)l0 | 1u))) break;
            }
            garr[r0.y & 7u] = -((unsigned)h0 / (p0 | 1u));
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)c1, (unsigned)((int)0xffffffffu >= (int)(unsigned)(signed char)(4u ^ r0.x)), ((unsigned)s1 << ((unsigned)w0 & 31u))); }
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (((unsigned)h0 << ((unsigned)(w0 >> 29) & 31u)) * (garr[i1 & 7u] - p1));
        if ((unsigned)(x0 >> 70)) break;
        if (g0) {
            break; (void)((i0 ^ ((unsigned)f0 * u0)));
            if (((unsigned)!(0x6b5b65b2u % ((unsigned)x0 | 1u)) << (0xd472b5c7u & 31u))) break;
            h1 = (unsigned short)(h1 + (((unsigned)(w0 >> 29) / (0x7fffffffu | 1u)) / (fuel | 1u)));
            *q0 += ((unsigned)s1 * ((garr[u2 & 7u] & (unsigned)s0) ^ (u3 | i2)));
            do { if (--fuel == 0u) goto done;
                if (((unsigned)(3u || a0[u1 & 3u]) % ((unsigned)w0 | 1u))) {
                    i0 = (3u - 0x773591bau) & 15u;
                    u3 += (((a0[u1 & 3u] ^ (unsigned)f0) & (unsigned)(0xffffffffu == 1u)) ^ p0);
                }
                switch (i0 & 7u) {
                    case 1u: ;
                    e0 = e0 * 0.5L + (long double)(((unsigned)d0 & 0x10000u) & 1023u);
                    case 7u: ;
                    if ((unsigned)(m0 < (g0 >> (v0 & 31u)))) {
                        case 6u: ;
                        b0 = (0x49088b81u + (p1 * garr[u2 & 7u])) != 0u;
                        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((unsigned)(w0 >> 29) && p0), ((5u + (unsigned)d0) | u3), (p0 & p0)); }
                        c0 = (unsigned char)(p0 & p2);
                        case 4u: ;
                        s0 = (int)((m0 ^ 0x10000u) - (unsigned)((short)(unsigned)c0 > (signed char)v0));
                    } else {
                        q0 = &garr[(unsigned)(unsigned char)(unsigned)(i0 == (unsigned)b0) & 7u];
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn1(g0, (unsigned)l0, ((unsigned)h0 & u2)); }
                    switch ((0x4d520f3bu / (r0.y | 1u)) & 7u) {
                        u2 = (unsigned)(*mp && ((0x6bcbd126u << ((0x7fffffffu + (unsigned)h0) & 31u)) - 7u));
                        case 2u: ;
                        *q0 += (unsigned)(0x99c0bd9eu || (unsigned)(5u && 3u));
                        for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                            u1 = (unsigned)(short)(0x80000000u + (unsigned)(((unsigned)s0 + (unsigned)s1) < ((unsigned)s0 + u1)));
                            l0 = (long)((unsigned long)l0 + (((unsigned)c1 & 0x1082b66cu) & ((2u << ((unsigned)s0 & 31u)) >> ((unsigned)h0 & 31u))));
                        }
                        c1 = (signed char)(((unsigned)e0 / (0xffffffffu | 1u)) & ((unsigned)c1 >> ((i1 + (unsigned)d0) & 31u)));
                    }
                }
                u2 = (unsigned)(p1 == garr[i1 & 7u]);
                h0 = (short)((unsigned)(0x49110366u && (0x10000u / ((unsigned)e0 | 1u))) | u3);
                break; (void)((unsigned)((int)(unsigned)h1 < (int)(unsigned)((short)0x9f12fa3u > (signed char)(unsigned)d0)));
            } while (i1++ < 2u && (0x10000u >> ((unsigned)f0 & 31u)));
        }
        s1 = (int)((unsigned)s1 + (0xffffffffu * 1u));
        while (8u) { if (--fuel == 0u) goto done;
            a0[0x540d50edu & 3u] = (unsigned)((int)((garr[i1 & 7u] | i0) * (unsigned)c1) >= (int)(unsigned)(0xd3af2786u == 0x7fffffffu));
            if (0x80000000u) {
                q0 = &garr[(unsigned)((int)fuel >= (int)(u3 * (unsigned)d0)) & 7u];
            }
            u2 ^= ((unsigned)(short)((unsigned)(w0 >> 29) ? *mp : u3) >> (0xf3da8469u & 31u));
        }
    }
    if ((p1 / ((unsigned)((unsigned)l0 || garr[u2 & 7u]) | 1u))) {
        if (r0.y) goto L3;
        if ((a0[u1 & 3u] >> ((unsigned)(8u == (unsigned)c1) & 31u))) {
            w0 ^= (unsigned long long)(unsigned)((short)r0.y > (signed char)garr[u2 & 7u]) << ((v0 ? (u2 | (unsigned)b0) : i2) & 63u);
        }
        b0 = (unsigned)!(a0[u1 & 3u] >> ((((unsigned)c1 - (unsigned)e0) + (unsigned)f0) & 31u)) != 0u;
    }
    do { if (--fuel == 0u) goto done;
        if ((*mp % ((r0.y << (0u & 31u)) | 1u))) break;
        *q0 = (unsigned)(signed char)(unsigned)(0xee0da540u && (u0 >> ((unsigned)f0 & 31u)));
        if (0x80000000u) continue;
        do { if (--fuel == 0u) goto done;
            g1 += (((unsigned)(0x7fffffffu == 0xdb759cccu) | (u1 ^ 3u)) | (unsigned)(w0 >> 29));
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)g1 < (int)0x21f3df30u)) goto L3;
                if ((unsigned)((short)(unsigned)((short)0x80000000u > (signed char)0x80000000u) > (signed char)i1)) break;
                u1 = u1 * 0x9e3779b1u + ((unsigned)((int)(unsigned)((int)1u < (int)m0) < (int)(a0[u1 & 3u] >> (p2 & 31u))) >> (0xe3a5a06bu & 31u));
                if (0x55c11326u) break;
                w0 = w0 * 6364136223846793005ull + (unsigned)(short)(0xf04f60d5u * fuel);
            }
            if (r0.x) break;
            *q0 += ((unsigned)l0 ? ((unsigned)x0 & fuel) : 0xee182b47u);
            *mp = (p0 << ((unsigned)(2u < 0x10000u) & 31u));
        } while (i1++ < 5u && (unsigned)d0);
    } while (i0++ < 7u && (u1 >> (i0 & 31u)));
    if (0xfa600d7eu) {
        if (((unsigned)l0 | 4u)) goto L4;
        if ((unsigned)(x0 >> 70)) {
            if (p0) {
                if (budget != 0u) { budget -= 1u; u1 = fn0(~(0x35275912u ^ 1u), ((v0 >> ((unsigned)(x0 >> 70) & 31u)) / (garr[u2 & 7u] | 1u)), (unsigned)b0); }
                a0[9u & 3u] = (0x80000000u | (u1 & (unsigned)f0));
                if ((u3 >> ((unsigned)s1 & 31u))) goto L0;
                do { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (0xffffffffu & g1));
                    m0 ^= ((0x7fffffffu ^ 6u) - 0xaa897423u);
                    if (budget != 0u) { budget -= 1u; u2 = fn0(3u, (0x80000000u / ((7u & 0x80000000u) | 1u)), (unsigned)((unsigned)h0 && m0)); }
                } while (i0++ < 7u && p0);
                m0 ^= (0x7fffffffu / (i1 | 1u));
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)c0 >> ((unsigned)c1 & 31u)), (unsigned)(unsigned char)(v0 - u1), (unsigned)((unsigned)b0 < (unsigned)((int)4u >= (int)a0[u1 & 3u]))); }
            }
            f0 = f0 * 0.5f + (float)((unsigned)((v0 >> (((unsigned)x0 | (unsigned)e0) & 31u)) == (unsigned)((int)(unsigned)d0 >= (int)a0[i0 & 3u])) & 255u);
            s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(unsigned)((short)((unsigned)(unsigned char)(unsigned)(v0 == (unsigned)x0) + 7u) > (signed char)(unsigned)l0));
        } else {
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (a0[i0 & 3u]) break;
                if ((0xe98fe60cu >> (((unsigned)d0 >> ((unsigned)(w0 >> 29) & 31u)) & 31u))) {
                    q0 = &garr[(0x7fffffffu / (0x7fffffffu | 1u)) & 7u];
                    if (((unsigned)(x0 >> 70) | 0x9c07a75fu)) goto done;
                    break; (void)((unsigned)(unsigned char)((unsigned)f0 >> ((0x94cf7eb5u / (*mp | 1u)) & 31u)));
                    *q0 = (unsigned)((int)((0u ? 4u : 8u) ^ 0x6ddc0811u) >= (int)i0);
                    if ((6u >> (r0.x & 31u))) continue;
                    break; (void)((unsigned)((short)0x80000000u > (signed char)(unsigned)x0));
                }
                b0 = fuel != 0u;
                w0 ^= (unsigned long long)(unsigned)(2u && v0) << ((unsigned)(short)(unsigned)((a0[i0 & 3u] << ((unsigned)((int)(0xb7905678u / ((unsigned)(w0 >> 29) | 1u)) >= (int)(unsigned)(x0 >> 70)) & 31u)) == (unsigned)(w0 >> 29)) & 63u);
                if ((0x940b9b23u * (unsigned)s0)) goto L0;
            }
            h1 = (unsigned short)(h1 + (unsigned)s1);
            r0.x = -(unsigned)((int)0x8b4a52e4u >= (int)garr[u2 & 7u]);
            w0 ^= (unsigned long long)(unsigned)((int)(unsigned)d0 >= (int)0xe03105f9u) << ((u0 % ((unsigned)(unsigned char)(0x32bc1512u % ((unsigned)s0 | 1u)) | 1u)) & 63u);
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn2(9u, (unsigned)((8u << (4u & 31u)) == *q0), (p2 | 7u)); }
    if ((unsigned)w0) {
        u2 = (3u ? *mp : i2);
        if ((unsigned)s1) goto done;
        switch ((i2 % (((unsigned)c1 >> ((unsigned)f0 & 31u)) | 1u)) & 7u) {
            while (i0++ < 5u && (unsigned)f0) { if (--fuel == 0u) goto done;
                garr[m0 & 7u] = ~((unsigned)(7u == (unsigned)s1) | (unsigned)((int)(unsigned)(w0 >> 29) < (int)p0));
                b0 = (i2 - a0[i0 & 3u]) != 0u;
                { unsigned t2; double z2; if (((u0 / (m0 | 1u))) & 1u) { t2 = (m0 - (unsigned)(short)(0x84543abfu ^ i0)); z2 = (double)((((unsigned)(x0 >> 70) << (((unsigned)c1 % ((unsigned)(x0 >> 70) | 1u)) & 31u))) & 255u); } if (((u0 / (m0 | 1u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    w0 ^= (unsigned long long)(unsigned)s0 << ((unsigned)l0 & 63u);
                    u2 ^= (u3 - fuel);
                    g0 = -(0xc4645e03u << ((unsigned)(r0.x < *q0) & 31u));
                    c0 = (unsigned char)(unsigned)((short)(0u ^ 0xffffffffu) > (signed char)(unsigned)(0x97d00e31u < 6u));
                    s1 = (int)((unsigned)s1 + 0x10000u);
                    case 1u: ;
                }
                switch ((i2 | (unsigned)h1) & 7u) {
                    switch ((unsigned)((int)(unsigned)(0xe93f898du || 5u) >= (int)u2) & 7u) {
                        u1 = u1 * 0x9e3779b1u + (unsigned)b0;
                        case 0u: ;
                        if (u3 == 7u) return (g0 & *mp);
                    }
                    for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + (unsigned)(0xc6f9005au == (a0[u1 & 3u] & (unsigned)((short)(unsigned)((int)(unsigned)x0 < (int)r0.x) > (signed char)(unsigned)c1)));
                        *q0 += (6u << (((0x10000u >> (garr[u2 & 7u] & 31u)) * 0xcb5d07beu) & 31u));
                        case 6u: ;
                        b0 = (unsigned)((short)(u1 * (unsigned)s1) > (signed char)(unsigned)(short)((unsigned)(g1 < garr[u2 & 7u]) % (fuel | 1u))) != 0u;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)((i2 << (0x53d6ac71u & 31u)) ^ r0.x), (unsigned)((int)(u0 & u1) >= (int)r0.y), ((unsigned)l0 & ((unsigned)e0 - p2))); }
                        d0 = d0 * 0.5 + (double)((unsigned)x0 & 1023u);
                    }
                    case 4u: ;
                }
                g0 = (unsigned)((short)((unsigned)h0 ? (unsigned)c0 : 0x7eecbb4au) > (signed char)((unsigned)b0 >> (0x10000u & 31u)));
            }
            case 6u: ;
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    case 3u: ;
                    h0 = (short)(unsigned)((int)(g1 << (*mp & 31u)) >= (int)((unsigned)(u2 == (unsigned)f0) * (unsigned)h0));
                } while (i1++ < 2u && (unsigned)((unsigned)(short)(p0 / ((unsigned)c1 | 1u)) == fuel));
                if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)l0 + m0), (unsigned)((int)0xffffffffu < (int)(unsigned)e0), (p0 ^ i2)); }
            }
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                garr[(unsigned)(u3 || p0) & 7u] = (((unsigned)s1 - 1u) * (0xdb347daeu >> ((unsigned)(g0 || 0x43b1e574u) & 31u)));
                do { if (--fuel == 0u) goto done;
                    if (a0[i0 & 3u]) break;
                    for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (r0.y) continue;
                        case 4u: ;
                        default: ;
                        h0 = (short)(unsigned)((unsigned)(*q0 == r0.x) || 3u);
                        e0 = e0 * 0.5L + (long double)((unsigned)(fuel == u2) & 1023u);
                    }
                } while (i1++ < 2u && (unsigned)((unsigned)d0 < a0[u1 & 3u]));
                if ((0xb6162353u << (0x7fffffffu & 31u))) {
                    c0 = (unsigned char)((unsigned)((int)((unsigned)c0 << (*q0 & 31u)) < (int)(unsigned)(unsigned char)(0x6fe11bccu * 0x10000u)) / (0x347bffe0u | 1u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)e0 || (unsigned)c0), (0x80000000u ^ (unsigned)l0), ((unsigned)f0 / ((unsigned)f0 | 1u))); }
                    s1 = (int)((unsigned)s1 + v0);
                    { unsigned t3; double z3; if ((0xe46450efu) & 1u) { t3 = (u1 * (unsigned)((short)p0 > (signed char)u1)); z3 = (double)(((unsigned)((int)(unsigned)f0 >= (int)i2)) & 255u); } if ((0xe46450efu) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        q0 = &garr[(unsigned)((((unsigned)c1 / (r0.x | 1u)) % ((unsigned)(garr[i1 & 7u] && g1) | 1u)) || u2) & 7u];
                        d0 = d0 * 0.5 + (double)((unsigned)(p2 || garr[i1 & 7u]) & 1023u);
                        u3 ^= (unsigned)((int)v0 >= (int)i1);
                        u1 ^= ((unsigned)f0 + (unsigned)c1);
                        m0 ^= ((unsigned)e0 & -(u1 | (unsigned)c1));
                        continue; (void)(((unsigned)c0 & (unsigned)l0));
                    }
                    u3 ^= (unsigned)c0;
                    if (g0) goto L3;
                } else {
                    if ((unsigned)(5u == (unsigned)b0)) {
                        r0.y ^= r0.y;
                        *q0 += ((unsigned)((short)m0 > (signed char)u0) - (unsigned)f0);
                    } else {
                        if (budget != 0u) { budget -= 1u; u2 = fn0((0xffffffffu / (8u | 1u)), (unsigned)((int)0x2db3c6dau >= (int)0x80000000u), 1u); }
                        v0 = (unsigned)((unsigned)((int)g0 >= (int)p2) && (i2 * (unsigned)w0));
                        u1 = u1 * 0x9e3779b1u + ((unsigned)(x0 >> 70) % (((g1 ^ 0x3fa3188cu) & (unsigned)((int)(unsigned)d0 < (int)garr[u2 & 7u])) | 1u));
                        v0 = (((unsigned)s0 >> (0x80000000u & 31u)) % (0x20f21c36u | 1u));
                    }
                    if ((*mp & (unsigned)(0x10000u == (unsigned)c1))) goto done;
                    *q0 += (unsigned)d0;
                    if ((unsigned)((short)p2 > (signed char)0x7fffffffu)) break;
                }
                w0 ^= (unsigned long long)(unsigned)h1 << ((unsigned)((unsigned)s1 == -((m0 - 6u) - (unsigned)(u3 && 0x420a609bu))) & 63u);
                a0[(unsigned)(0x10000u == (unsigned)x0) & 3u] = r0.x;
            }
            r0.x = 0x97cd017u;
            h1 = (unsigned short)(h1 + (unsigned)!(unsigned)((int)u0 >= (int)(g1 ^ 0x80000000u)));
        }
        if ((g0 + p0)) goto L0;
        if ((0u & (unsigned)w0)) {
            g1 += (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x7fffffffu);
        } else {
            h0 = (short)(unsigned)x0;
            goto L4;
        }
        d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)((int)(3u << (0x118e843u & 31u)) >= (int)(i1 * (unsigned)h0)) >= (int)i2) & 1023u);
    } else {
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            g0 = (unsigned)(((unsigned)f0 & garr[u2 & 7u]) < 0xf33ff56du);
        }
        switch ((unsigned)(signed char)((unsigned)e0 * 2u) & 7u) {
            case 6u: ;
            case 7u: ;
            if ((unsigned)(short)(u2 % (((unsigned)(w0 >> 29) % (fuel | 1u)) | 1u))) {
                h0 = (short)(((u1 + 0x7fffffffu) >> (0x6bd6a08u & 31u)) << (((unsigned)l0 ^ (unsigned)h1) & 31u));
                s0 = (int)(unsigned)((unsigned)((int)(unsigned)h0 < (int)a0[i0 & 3u]) || 0x80000000u);
                u0 = u0 * 0x9e3779b1u + 0xecaebc31u;
                a0[(*mp * (unsigned)c0) & 3u] = (unsigned)(((u0 - g1) >> (i0 & 31u)) == *q0);
                s1 = (int)((unsigned)s1 + (unsigned)(*mp == (unsigned)x0));
                switch ((unsigned)e0 & 7u) {
                    case 0u: ;
                    case 5u: ;
                    l0 = (long)((unsigned long)l0 + (unsigned)((int)(5u - g1) < (int)((unsigned)(i1 || 0x7fffffffu) * (unsigned)d0)));
                    case 1u: ;
                    case 4u: ;
                }
            } else {
                h0 = (short)(unsigned)((int)7u < (int)0xb05b6b9cu);
                if (budget != 0u) { budget -= 1u; u1 = fn0(((fuel / (6u | 1u)) - u3), *q0, (unsigned)h0); }
                goto L2;
                if ((unsigned)((unsigned)b0 && (*q0 << (v0 & 31u)))) {
                    if ((unsigned)((int)(unsigned)e0 < (int)(unsigned)c0)) goto L4;
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(short)(9u << ((unsigned)x0 & 31u)), (unsigned)h0, u3); }
                    h0 = (short)(unsigned)(unsigned char)(((unsigned)b0 - 1u) >> ((a0[i0 & 3u] ^ v0) & 31u));
                } else {
                    s1 = (int)((unsigned)s1 + (unsigned)(0xffffffffu || -((unsigned)((unsigned)(0x10000u && 7u) && 0x9976610cu) * *mp)));
                    v0 = ((unsigned)((int)garr[i1 & 7u] >= (int)(u0 ^ (1u / (u3 | 1u)))) << (*mp & 31u));
                }
            }
            if (p1) break;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)u3 >= (int)p1), 0x1139755eu, ~(unsigned)((short)0x741fd145u > (signed char)a0[i0 & 3u])); }
        }
    }
    c0 = (unsigned char)(u0 - (~(p0 - *mp) ? (unsigned)x0 : (unsigned)s0));
    { unsigned t4; double z4; if (((v0 + a0[u1 & 3u])) & 1u) { t4 = (6u + -(6u ^ 0x80000000u)); z4 = (double)(((unsigned)w0) & 255u); } if (((v0 + a0[u1 & 3u])) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
        if (((unsigned)l0 % ((unsigned)e0 | 1u))) goto L0;
    }
    v0 = ((unsigned)(signed char)(unsigned)(p2 || (unsigned)(0x6fd0fa0fu == fuel)) | g1);
    if (budget != 0u) { budget -= 1u; u2 = fn0((u1 * (unsigned)((int)u1 < (int)garr[i1 & 7u])), *q0, 0xa906638au); }
    if (((unsigned)c1 + 4u)) goto done;
    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)h1, a0[u1 & 3u], (r0.x + (unsigned)b0)); }
    a0[(3u << (0x10000u & 31u)) & 3u] = (unsigned)((int)u3 < (int)(unsigned)f0);
    if ((a0[u1 & 3u] & (unsigned)c1)) goto L3;
    switch ((unsigned)((short)(*q0 ^ v0) > (signed char)(unsigned)d0) & 7u) {
        if ((unsigned)(9u < 3u)) break;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)((unsigned)h1 || 0x10000u) + (unsigned)d0), (unsigned)((short)0xffffffffu > (signed char)(unsigned)((unsigned)l0 && fuel)), 8u); }
    do { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)((unsigned)c1 < (0x62439210u / ((unsigned)((int)0x998995b0u < (int)(unsigned)w0) | 1u))) > (signed char)p2));
    } while (i0++ < 4u && (unsigned)((int)i2 < (int)g0));
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(p1 && r0.x), (garr[u2 & 7u] / (garr[i1 & 7u] | 1u)), (unsigned)h1); }
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)x0, (r0.y - (unsigned)l0), (unsigned)s1); }
    goto L4;
    if (*mp) {
        h0 = (short)((unsigned)x0 % ((unsigned)(short)((unsigned)(short)(unsigned)(i2 < 0xffffffffu) | u1) | 1u));
        if ((unsigned)((short)u3 > (signed char)a0[u1 & 3u])) goto L4;
    } else {
        if (((unsigned)f0 / (garr[i1 & 7u] | 1u))) goto L4;
        { unsigned t5; double z5; if (((m0 ^ (unsigned)(w0 >> 29))) & 1u) { t5 = fuel; z5 = (double)((0x4a1728c9u) & 255u); } if (((m0 ^ (unsigned)(w0 >> 29))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
            h0 = (short)(unsigned)((unsigned)(x0 >> 70) && g0);
            if ((i1 >> ((0xffffffffu * 0x10000u) & 31u))) {
                c0 = (unsigned char)0x7fffffffu;
                goto L0;
                goto L2;
            } else {
                if (((unsigned)l0 ^ (garr[u2 & 7u] >> (r0.y & 31u)))) goto done;
                { unsigned t6; double z6; if (((unsigned)l0) & 1u) { t6 = 0x3883641cu; z6 = (double)((((unsigned)b0 ^ (p1 ^ r0.x))) & 255u); } if (((unsigned)l0) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                    f0 = f0 * 0.5f + (float)((0x10000u | (r0.x % ((unsigned)s0 | 1u))) & 255u);
                }
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(signed char)(unsigned)((unsigned)((int)i0 < (int)(unsigned)f0) < i0), (u2 >> ((unsigned)c1 & 31u)), u3); }
            }
            s0 = (int)((p1 << (0x7fffffffu & 31u)) << ((m0 * garr[u2 & 7u]) & 31u));
        }
        l0 = (long)((unsigned long)l0 + fuel);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    c0 = (unsigned char)(unsigned)w0;
    if (fuel < 8u) return (unsigned)((unsigned)(short)(fuel >> (3u & 31u)) && (unsigned)w0);
    d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(short)(0x50da463du >> ((unsigned)((int)(unsigned)b0 < (int)1u) & 31u)) == (r0.x << ((unsigned)s0 & 31u))) & 1023u);
    if (garr[i1 & 7u]) goto L2;
    if (0x7fffffffu) goto L0;
    if ((0xffffffffu | v0)) {
        if (((0x5abcb35fu - u3) % ((unsigned)(w0 >> 29) | 1u))) {
            L0: if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
            g0 = 6u;
        } else {
            if ((unsigned)(signed char)(unsigned)(garr[u2 & 7u] && a0[u1 & 3u])) goto L4;
            if ((0x7fffffffu ^ ((unsigned)s0 << (0xffffffffu & 31u)))) goto L3;
        }
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((0x80000000u | 0x80000000u)) {
                e0 = e0 * 0.5L + (long double)((unsigned)(0x80000000u && ((unsigned)s1 / ((unsigned)(v0 || 0x80000000u) | 1u))) & 1023u);
                m0 ^= 3u;
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return ((unsigned)(x0 >> 70) * (8u >> ((((unsigned)s1 ^ fuel) | garr[u2 & 7u]) & 31u)));
                }
                switch ((unsigned)(p0 || 0x904194c0u) & 7u) {
                    case 7u: ;
                }
                if ((garr[i1 & 7u] + ~(unsigned)((unsigned)x0 < p2))) {
                    r0.y ^= ((unsigned)(x0 >> 70) ? 8u : 0u);
                    r0.y ^= fuel;
                }
            } else {
                m0 ^= (((unsigned)(6u && g0) | (unsigned)l0) ^ (unsigned)(a0[u1 & 3u] < u3));
                L2: if (--fuel == 0u) goto done;
                switch (7u & 7u) {
                    c1 = (signed char)((unsigned)w0 << (i1 & 31u));
                    case 6u: ;
                    if (i1) goto L3;
                }
            }
            l0 = (long)((unsigned long)l0 + (unsigned)((short)((unsigned)((int)(unsigned)(garr[u2 & 7u] < (unsigned)s0) < (int)p1) << (r0.x & 31u)) > (signed char)u3));
            e0 = e0 * 0.5L + (long double)((unsigned)(short)((unsigned)s0 ? g1 : (unsigned)h0) & 1023u);
            { unsigned t0; double z0; if (((unsigned)(unsigned char)(unsigned)(u2 && (unsigned)s1)) & 1u) { t0 = ((unsigned)((short)r0.x > (signed char)v0) & g0); z0 = (double)(((unsigned)((short)*mp > (signed char)(unsigned)((unsigned)h1 || *mp))) & 255u); } if (((unsigned)(unsigned char)(unsigned)(u2 && (unsigned)s1)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                h1 = (unsigned short)(h1 + (unsigned)((int)4u < (int)(unsigned)((int)8u < (int)i1)));
                b0 = (unsigned)((int)garr[i1 & 7u] < (int)p1) != 0u;
                w0 = w0 * 6364136223846793005ull + r0.y;
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn2(((u1 * 0xd0834538u) << (a0[u1 & 3u] & 31u)), 8u, p0); }
        c0 = (unsigned char)(unsigned)h0;
        f0 = f0 * 0.5f + (float)((unsigned)(i0 || (a0[u1 & 3u] << ((0u >> ((unsigned)c1 & 31u)) & 31u))) & 255u);
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 = ((unsigned)((short)(unsigned)d0 > (signed char)a0[u1 & 3u]) ^ u1);
            g1 += ((unsigned)l0 / ((unsigned)((int)0x10000u < (int)2u) | 1u));
            if (u2) break;
            d0 = d0 * 0.5 + (double)((i2 * r0.x) & 1023u);
            do { if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)(unsigned)h1 < (int)p0), ((unsigned)s0 % ((unsigned)d0 | 1u)), ((unsigned)h0 >> ((unsigned)h1 & 31u))); }
                g1 += (unsigned)(signed char)((unsigned)(fuel || u0) * (unsigned)b0);
            } while (i1++ < 4u && 0xffffffffu);
        }
    }
    d0 = d0 * 0.5 + (double)((unsigned)((unsigned)h1 && (unsigned)(w0 >> 29)) & 1023u);
    goto L0;
    while (i0++ < 3u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
        if (((unsigned)((int)r0.x >= (int)a0[u1 & 3u]) ^ (unsigned)b0)) continue;
        w0 ^= (unsigned long long)0x7fffffffu << (((unsigned)((unsigned)(5u || 4u) == 0xd1a9be97u) ^ 0u) & 63u);
        do { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)(u3);
            }
            for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)h0 << ((u2 << ((unsigned)(w0 >> 29) & 31u)) & 63u);
                if (((2u >> ((unsigned)d0 & 31u)) >> (v0 & 31u))) {
                    g1 += (unsigned)((short)*mp > (signed char)0xffffffffu);
                    b0 = ((unsigned)l0 ? 0x10000u : 0xae3363ddu) != 0u;
                    if (budget != 0u) { budget -= 1u; u3 = fn3((0x80000000u << ((unsigned)b0 & 31u)), 2u, g1); }
                    u2 = u2 * 0x9e3779b1u + (unsigned)w0;
                } else {
                    continue; (void)((unsigned)h1);
                    g1 += ((unsigned)(short)(a0[u1 & 3u] >> (((unsigned)s1 ? 0xaea19a94u : (unsigned)e0) & 31u)) % (0xffffffffu | 1u));
                }
                e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)((int)u3 < (int)0x1c72422du) >= (int)(unsigned)((int)0x6f69bc6au < (int)i0)) & 1023u);
            }
            continue; (void)((a0[i0 & 3u] >> (v0 & 31u)));
        } while (i1++ < 4u && r0.x);
        if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)f0 | (unsigned)s1), -(u2 + ((unsigned)c0 & 9u)), 0x10000u); }
        L4: if (--fuel == 0u) goto done;
        v0 = ((unsigned)(w0 >> 29) % ((unsigned)(fuel && 3u) | 1u));
    }
    if ((~((unsigned)x0 | v0) / (7u | 1u))) goto done;
    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((int)((unsigned)c0 * garr[i1 & 7u]) < (int)garr[u2 & 7u]), (0x80000000u << (r0.y & 31u)), (unsigned)((int)u2 >= (int)garr[i1 & 7u])); }
    if (g0) {
        r0.x = (unsigned)((short)(unsigned)w0 > (signed char)(((unsigned)c0 * 0xca71c47fu) * 2u));
        c0 = (unsigned char)(0x7fffffffu / (8u | 1u));
        if (budget != 0u) { budget -= 1u; u1 = fn1(a0[u1 & 3u], (unsigned)((int)0x30ce5e49u < (int)(unsigned)e0), (unsigned)((int)g0 >= (int)(7u & i2))); }
        u1 ^= (unsigned)(short)((unsigned)((int)((unsigned)f0 % (0x10000u | 1u)) >= (int)(unsigned)d0) + 0x61b10445u);
        if ((0x1e8425fu >> ((unsigned)b0 & 31u))) {
            q0 = &garr[((unsigned)c0 >> ((unsigned)h0 & 31u)) & 7u];
            if ((unsigned)((short)(unsigned)(short)(unsigned)((short)u2 > (signed char)(unsigned)f0) > (signed char)(unsigned)c1)) {
                i1 = 0xef54195eu & 15u;
                d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)((unsigned)w0 * (0x31883c59u ? 0x7fffffffu : u3)) & 1023u);
                d0 = d0 * 0.5 + (double)((unsigned)c0 & 1023u);
            }
            w0 = w0 * 6364136223846793005ull + (unsigned)(((unsigned)h1 | 4u) == (fuel - (*mp + i0)));
        } else {
            c0 = (unsigned char)(unsigned)((int)garr[u2 & 7u] >= (int)p2);
            e0 = e0 * 0.5L + (long double)((unsigned)(short)((unsigned)(0xe30ff54eu || a0[i0 & 3u]) & (unsigned)h0) & 1023u);
            if ((2u >> ((unsigned)(fuel == g0) & 31u))) goto L3;
        }
        while ((unsigned)((short)fuel > (signed char)9u)) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (*q0 ^ r0.x));
            break; (void)((0xa23f889cu << ((unsigned)(r0.y || (unsigned)s0) & 31u)));
            b0 = ((unsigned)((int)(unsigned)c0 < (int)(unsigned)(g1 < (unsigned)d0)) / (0xf6ed18dbu | 1u)) != 0u;
        }
    }
    *mp = (unsigned)s0;
    if (((unsigned)x0 * 3u)) {
        if (u3 == 7u) return ((unsigned)(x0 >> 70) % ((unsigned)w0 | 1u));
        s1 = (int)((unsigned)s1 + (unsigned)((short)9u > (signed char)a0[u1 & 3u]));
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(0x1120fc29u && i0) < (unsigned)((unsigned)(w0 >> 29) && (5u ^ u2))));
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)(short)((0x7fffffffu | p2) >> (garr[i1 & 7u] & 31u));
    a0[garr[u2 & 7u] & 3u] = (0x80000000u << (garr[u2 & 7u] & 31u));
    if ((unsigned)((short)r0.y > (signed char)g1)) {
        while (i0++ < 3u && (u3 / (0x4abf0d78u | 1u))) { if (--fuel == 0u) goto done;
            if ((((unsigned)h0 * (unsigned)(w0 >> 29)) | a0[u1 & 3u])) break;
            v0 = 0u;
            if ((unsigned)!(0x15055a9fu + 0x80000000u)) break;
        }
        switch ((unsigned)((int)0x7a9707eau >= (int)i0) & 7u) {
            case 1u: ;
            c1 = (signed char)(unsigned)c0;
            case 5u: ;
            s1 = (int)((unsigned)s1 + (u2 | (0x134399cau - (unsigned)((int)i1 >= (int)u2))));
        }
    }
    while (i0++ < 3u && ((unsigned)h1 + 0x10000u)) { if (--fuel == 0u) goto done;
        break; (void)((0x4581675cu / ((unsigned)w0 | 1u)));
        if ((unsigned)(unsigned char)(unsigned)((unsigned)l0 && 0u)) break;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)s1 ^ 5u)) break;
        }
    }
    switch ((unsigned)((int)(unsigned)(0x7fffffffu < fuel) >= (int)p1) & 7u) {
        switch ((unsigned)((int)g1 < (int)0x1d4bdc1bu) & 7u) {
            do { if (--fuel == 0u) goto done;
                goto L3;
                if ((unsigned)(0x10000u < 0x7fffffffu)) {
                    for (;;) { if (--fuel == 0u) goto done;
                        case 6u: ;
                        if (((unsigned)e0 ^ (unsigned)((unsigned)x0 < (unsigned)s1))) {
                            if ((unsigned)((3u / (0x10000u | 1u)) || 0x128abe99u)) break;
                            if (u3 == 7u) return (unsigned)((unsigned)h1 == (i1 ^ (unsigned)((int)(unsigned)b0 >= (int)*q0)));
                        } else {
                            break; (void)(0x8d289fd1u);
                            if (budget != 0u) { budget -= 1u; u1 = fn0(0xd997a2cdu, (2u % ((3u / (0x8ebadee7u | 1u)) | 1u)), g0); }
                            u3 ^= 0x7fffffffu;
                            if ((unsigned)s1) break;
                        }
                        if (0xdc08fc6cu) break;
                        e0 = e0 * 0.5L + (long double)((unsigned)((int)((unsigned)h0 ? i1 : u0) >= (int)0x10000u) & 1023u);
                        c1 = (signed char)(p0 >> ((0x8e3cec65u >> (a0[i0 & 3u] & 31u)) & 31u));
                    }
                    if ((unsigned)(x0 >> 70)) goto L0;
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        i2 = (garr[u2 & 7u] >> ((unsigned)(unsigned char)(unsigned)((int)i0 >= (int)(unsigned)b0) & 31u)) & 15u;
                    }
                }
            } while (i0++ < 3u && (unsigned)!((r0.y ^ i1) * v0));
        }
        l0 = (long)((unsigned long)l0 + (unsigned)(a0[u1 & 3u] || (unsigned)c0));
        r0.y ^= 0xffffffffu;
    }
    goto L0;
    if ((unsigned)((unsigned)((int)a0[i0 & 3u] >= (int)0x7fffffffu) || 0x10000u)) goto L4;
    if (budget != 0u) { budget -= 1u; u1 = fn3((0x10000u << (0x7fffffffu & 31u)), 0x10000u, m0); }
    if (2u) goto L1;
    { unsigned t1; double z1; if (((unsigned)((int)0xa25b4108u >= (int)((unsigned)(w0 >> 29) ^ 0xe9a589deu))) & 1u) { t1 = (unsigned)h1; z1 = (double)(((unsigned)(1u || 0xffffffffu)) & 255u); } if (((unsigned)((int)0xa25b4108u >= (int)((unsigned)(w0 >> 29) ^ 0xe9a589deu))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        if (~(u1 - u2)) goto L2;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(5u && v0), (unsigned)(0x15f7db62u && g1), (unsigned)((short)p1 > (signed char)r0.y)); }
        do { if (--fuel == 0u) goto done;
            switch (-((unsigned)c0 | (unsigned)(0xffffffffu == 0xfff9efb3u)) & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn2((0x80000000u % (r0.x | 1u)), v0, (unsigned)(0x10000u == p0)); }
            }
            u2 = u2 * 0x9e3779b1u + ((unsigned)f0 | (unsigned)(short)(g0 ? (unsigned)c0 : 0x10000u));
        } while (i0++ < 4u && (unsigned)(r0.y == (unsigned)((int)i1 < (int)(unsigned)s1)));
        if ((unsigned)(0x10000u == (unsigned)h0)) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((0u / ((unsigned)h0 | 1u)), (unsigned)((0x3664d765u >> (g1 & 31u)) < (unsigned)x0), ((unsigned)((short)v0 > (signed char)a0[u1 & 3u]) % ((unsigned)x0 | 1u))); }
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(0x7fffffffu < (*mp + u1)), (u2 ? r0.y : u1), (unsigned)((i0 | g1) < (unsigned)h0)); }
        } else {
            if ((0x80000000u | 0x10000u)) {
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)w0) goto L3;
                    break; (void)(4u);
                    break; (void)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x7fffffffu));
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)(9u | p2) < (int)4u), (a0[u1 & 3u] % (0x10000u | 1u)), (p2 << (0xb2ab5c79u & 31u))); }
                    if (i0) break;
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)((int)u0 >= (int)v0) && (unsigned)((short)(i0 | 2u) > (signed char)(unsigned)(x0 >> 70))));
                }
                h0 = (short)(unsigned)((int)garr[u2 & 7u] < (int)(unsigned)s1);
                a0[0x10000u & 3u] = (unsigned)e0;
                if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)w0, (0x92e3d59fu / (i0 | 1u)), v0); }
                if (budget != 0u) { budget -= 1u; u1 = fn1(((a0[u1 & 3u] >> (0x7fffffffu & 31u)) >> ((unsigned)(w0 >> 29) & 31u)), (0x10000u ^ (unsigned)s1), p1); }
            } else {
                *q0 = (unsigned)(i0 < (unsigned)((int)r0.x >= (int)(unsigned)((int)g0 >= (int)(unsigned)((int)(unsigned)x0 < (int)garr[u2 & 7u]))));
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)w0, (unsigned)((int)(unsigned)f0 < (int)(u2 | u1)), fuel); }
                r0.x = 0x47d9d9a6u;
                goto L1;
            }
            s1 = (int)((unsigned)s1 + a0[u1 & 3u]);
            goto L1;
        }
        b0 = (unsigned)(x0 >> 70) != 0u;
        switch ((unsigned)!(unsigned)((unsigned)s0 && 0xffffffffu) & 7u) {
            case 1u: ;
            b0 = ((p2 >> (*q0 & 31u)) << ((p1 << ((garr[u2 & 7u] / (0xfcde67acu | 1u)) & 31u)) & 31u)) != 0u;
        }
    }
    if (((unsigned)f0 + (unsigned)s1)) {
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)f0, m0, (unsigned)(0xffffffffu && a0[i0 & 3u])); }
        c1 = (signed char)p1;
    } else {
        if (fuel < 8u) return 0xffffffffu;
    }
    *q0 += ((((0x80000000u % (r0.y | 1u)) * a0[u1 & 3u]) / (i2 | 1u)) | 0x356f88b5u);
    if ((8u % ((unsigned)c0 | 1u))) goto done;
    switch (-(unsigned)((short)(unsigned)l0 > (signed char)i2) & 7u) {
        { unsigned t2; double z2; if (((unsigned)!((unsigned)((int)(unsigned)(w0 >> 29) >= (int)p0) & (unsigned)h0)) & 1u) { t2 = u2; z2 = (double)((0xe02efb70u) & 255u); } if (((unsigned)!((unsigned)((int)(unsigned)(w0 >> 29) >= (int)p0) & (unsigned)h0)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            x0 = x0 * 0x100000001b3ull + ((unsigned)((int)(unsigned)s0 < (int)(unsigned)e0) & u3);
        }
        case 0u: ;
        c0 = (unsigned char)((unsigned)l0 & (unsigned)b0);
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        continue; (void)(((5u + (unsigned)c1) % ((unsigned)c1 | 1u)));
        if ((unsigned)((unsigned)(x0 >> 70) < (unsigned)c0)) break;
        if ((p0 & 0x10000u)) {
            switch ((unsigned)((unsigned)w0 < (unsigned)w0) & 7u) {
                switch (p1 & 7u) {
                    if ((unsigned)((short)5u > (signed char)(unsigned)c0)) {
                        u1 += (unsigned)(signed char)(5u << ((6u - 0x7fffffffu) & 31u));
                        l0 = (long)((unsigned long)l0 + -(unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)c0));
                    } else {
                        u3 ^= ((unsigned)(0x7fffffffu == (fuel + (unsigned)h1)) / ((unsigned)h1 | 1u));
                        case 6u: ;
                        do { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)h1 ? garr[i1 & 7u] : (unsigned)(w0 >> 29)), ((unsigned)x0 | (unsigned)((int)0xffffffffu < (int)i0)), (unsigned)(unsigned char)(0xa1627614u | (unsigned)x0)); }
                            if (((p1 << (1u & 31u)) ^ u2)) goto L0;
                        } while (i1++ < 4u && 2u);
                    }
                }
                case 1u: ;
            }
            *q0 = (u3 % (p0 | 1u));
            i1 = ((unsigned)((unsigned)c1 < (unsigned)h1) - g1) & 15u;
        } else {
            if (budget != 0u) { budget -= 1u; u3 = fn3((u0 + i1), (8u + 8u), (unsigned)((unsigned)h0 < (unsigned)!((unsigned)(w0 >> 29) * (unsigned)c0))); }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u2) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(x0 >> 70), (unsigned)((unsigned)((int)(unsigned)s0 < (int)p1) == fuel), (unsigned)((unsigned)((int)(unsigned)s0 < (int)0x6033fa8du) || (unsigned)c0)); }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)0x98933faau > (signed char)(u1 % ((unsigned)c0 | 1u))), ~(0x93930a20u ^ (unsigned)h0), (i1 ^ 4u)); }
                v0 = (unsigned)((unsigned)(x0 >> 70) == 0xe60c5a42u);
                if ((unsigned)w0) continue;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((0x2b9d93adu << ((unsigned)((unsigned)w0 < (unsigned)c1) & 31u)));
                    if (-(i2 & *q0)) break;
                    break; (void)((unsigned)(0x4d2b30dfu && (unsigned)x0));
                    if (~(unsigned)((unsigned)s1 || -(a0[u1 & 3u] * (unsigned)e0))) break;
                }
            }
            break; (void)((unsigned)((unsigned)h0 && (a0[u1 & 3u] + 0x80000000u)));
        }
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((int)a0[i0 & 3u] >= (int)0x678e5412u)) {
            *q0 = (r0.x << ((0x10000u * (unsigned)(w0 >> 29)) & 31u));
            if ((unsigned)(i1 || garr[i1 & 7u])) break;
            c0 = (unsigned char)((unsigned)s0 ? (unsigned)(*mp == (*mp & 5u)) : fuel);
            if ((unsigned)h0) break;
            r0.y ^= (unsigned)((unsigned)b0 == (unsigned)(v0 == 0x80000000u));
            h0 = (short)((unsigned)(0x7fffffffu < garr[u2 & 7u]) | (*q0 + 0x80000000u));
        }
        if (i1) break;
        do { if (--fuel == 0u) goto done;
            if ((0xcc88a06bu * ((unsigned)s1 + (unsigned)(w0 >> 29)))) break;
            continue; (void)((unsigned)((int)9u < (int)(u3 % (0x8eaa4e72u | 1u))));
            g0 = ((unsigned)(0xffffffffu || u0) % ((unsigned)(short)(6u & (unsigned)!(p0 & g1)) | 1u));
            if (((unsigned)(w0 >> 29) / ((unsigned)f0 | 1u))) break;
            break; (void)((unsigned)(signed char)(((unsigned)e0 >> (0x7fffffffu & 31u)) & a0[i0 & 3u]));
        } while (i1++ < 4u && (p0 | a0[u1 & 3u]));
    } while (i0++ < 5u && 6u);
    switch (0x7fffffffu & 7u) {
        if (g0) goto L2;
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)((unsigned)x0 == (unsigned)c0) - p2)) goto done;
        u2 = u2 * 0x9e3779b1u + (unsigned)(short)(u2 >> (a0[u1 & 3u] & 31u));
        if (v0) break;
        if ((unsigned)((unsigned)c0 && u0)) break;
        if ((9u / (5u | 1u))) break;
    }
    goto L1;
    if (budget != 0u) { budget -= 1u; u2 = fn1((fuel * (unsigned)d0), ((0x4dd050acu & 3u) & 4u), ((unsigned)(1u && i2) + 0x10000u)); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 12u, 0x62a52198u, 0x21379bd4u },
        { 9u, 0x5fb25dfbu, 0xd2eab0acu },
        { 2u, 0xf78599efu, 0x845b20e6u },
        { 6u, 0x193c8703u, 0x835dc783u },
        { 4u, 0x27c16ef3u, 0xafa4b00fu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
