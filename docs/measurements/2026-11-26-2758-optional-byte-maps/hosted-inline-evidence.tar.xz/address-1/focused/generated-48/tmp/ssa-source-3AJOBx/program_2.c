// test-ssa-source's program of seed 134000404 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xcdf58cc2u, g1 = 0x573f8386u;
static unsigned garr[8] = { 0xaeaf705u, 0xb26ee587u, 0x8f441fcau, 0xc71e5a9du, 0x8ecb5028u, 0x57988193u, 0xef89b0e2u, 0x25be1ab7u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
        if ((8u * (unsigned)!(unsigned)(2u || i1))) break;
        u2 = ((unsigned)((2u >> (p1 & 31u)) && (unsigned)((unsigned)f0 < (unsigned)x0)) % ((unsigned)(x0 >> 70) | 1u));
    } while (i0++ < 3u && (i0 ^ u1));
    if ((unsigned)((int)u3 >= (int)(unsigned)(0xb8839979u == m0))) goto L2;
    if ((unsigned)b0) goto L1;
    if ((0xb5c47de5u - 0x3e9b2e8u)) goto L1;
    L2: if (--fuel == 0u) goto done;
    v0 = 9u;
    L3: if (--fuel == 0u) goto done;
    if ((unsigned)s1) goto L0;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)(unsigned)((int)7u < (int)(unsigned)l0) > (signed char)0x10000u)) break;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if ((0xffffffffu) & 1u) { t0 = (unsigned)((int)u3 < (int)r0.y); z0 = (double)((v0) & 255u); } if ((0xffffffffu) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                continue; (void)(p0);
            }
            l0 = (long)((unsigned long)l0 + (unsigned)(0x10000u < (((p1 | (unsigned)w0) + *mp) | 0xffffffffu)));
        }
        if (((4u | (unsigned)l0) + 0x7fffffffu)) {
            x0 = x0 * 0x100000001b3ull + (unsigned)(u1 == ((unsigned)d0 % ((unsigned)w0 | 1u)));
            e0 = e0 * 0.5L + (long double)((((unsigned)(unsigned char)(p2 - ((unsigned)f0 % ((unsigned)h0 | 1u))) + g1) + u3) & 1023u);
            if (~(p0 >> (g0 & 31u))) {
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)w0 & fuel)) break;
                    if (((unsigned)b0 ? p0 : (unsigned)s0)) break;
                }
                if ((unsigned)(p1 == (unsigned)l0)) {
                    *q0 = (unsigned)((short)~(u3 % (garr[i1 & 7u] | 1u)) > (signed char)(unsigned)((int)(unsigned)s1 >= (int)(0u * v0)));
                    L4: if (--fuel == 0u) goto done;
                    if ((unsigned)(w0 >> 29)) break;
                    u1 = (0xeee9eca4u | u2);
                } else {
                    g0 = (unsigned)((unsigned)(m0 == p0) < (unsigned)(p0 || 0x80000000u));
                    if ((unsigned)((int)(unsigned)((unsigned)w0 == (unsigned)w0) >= (int)*mp)) break;
                    if ((unsigned)l0) break;
                    break; (void)((unsigned)c0);
                }
                w0 = w0 * 6364136223846793005ull + (unsigned)(garr[i1 & 7u] && ~(9u ? 0x80000000u : *q0));
                if (u1) {
                    if ((0x7fffffffu % (6u | 1u))) break;
                    u2 += (3u % (((0x7fffffffu - 0x78af88cbu) << (i0 & 31u)) | 1u));
                }
                if ((0xffffffffu << (p0 & 31u))) break;
                if (0x10000u) continue;
            } else {
                q0 = &garr[(unsigned)((int)(unsigned)(*mp < (unsigned)f0) >= (int)r0.x) & 7u];
                a0[*q0 & 3u] = ((unsigned)((int)i1 >= (int)(unsigned)b0) & (unsigned)(0x67b691fu == (0xda0df27eu & p2)));
            }
            c1 = (signed char)(unsigned)(u1 == ~(unsigned)((short)garr[u2 & 7u] > (signed char)((unsigned)s0 >> (0x10000u & 31u))));
        }
        { unsigned t1; double z1; if (((unsigned)(0xfb51e4e2u || ~(0x8c79da23u ^ 0x11c758f1u))) & 1u) { t1 = (unsigned)c1; z1 = (double)(((unsigned)((int)r0.x < (int)0xf6ed69dbu)) & 255u); } if (((unsigned)(0xfb51e4e2u || ~(0x8c79da23u ^ 0x11c758f1u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            { unsigned t2; double z2; if (((4u * (g1 >> (i0 & 31u)))) & 1u) { t2 = (unsigned)((short)garr[u2 & 7u] > (signed char)*q0); z2 = (double)((fuel) & 255u); } if (((4u * (g1 >> (i0 & 31u)))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                goto L4;
                break; (void)(8u);
                u2 = (unsigned)!(unsigned)(r0.y < (unsigned)((int)(unsigned)c1 >= (int)9u));
                while (i1) { if (--fuel == 0u) goto done;
                    if (0x7fffffffu) break;
                    if (fuel < 8u) return (unsigned)((unsigned)d0 == (unsigned)((g0 % ((unsigned)h1 | 1u)) || (i1 << (r0.y & 31u))));
                    l0 = (long)((unsigned long)l0 + (unsigned)x0);
                    break; (void)((unsigned)(a0[i0 & 3u] == m0));
                }
                if ((p0 & (unsigned)f0)) break;
                i2 = i0 & 15u;
            }
            { unsigned t3; double z3; if ((v0) & 1u) { t3 = (unsigned)((int)((unsigned)e0 | i1) >= (int)0u); z3 = (double)((garr[u2 & 7u]) & 255u); } if ((v0) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)f0 == ((unsigned)c0 * (unsigned)((int)0x10000u >= (int)(i2 % (garr[u2 & 7u] | 1u))))) & 1023u);
            }
            break; (void)(a0[u1 & 3u]);
            c1 = (signed char)(unsigned)((m0 ^ 0x10000u) || ((v0 & 0xffffffffu) - a0[i0 & 3u]));
            *mp = (unsigned)((short)~((unsigned)e0 / (u0 | 1u)) > (signed char)(unsigned)((short)p0 > (signed char)a0[u1 & 3u]));
        }
        if (0x3e203e45u) {
            b0 = 0xffffffffu != 0u;
            if ((unsigned)((int)(unsigned)(3u < (unsigned)c0) >= (int)(unsigned)x0)) break;
            if ((unsigned)(0x7fffffffu && u2)) {
                g0 = r0.x;
            } else {
                s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)((unsigned)w0 & (unsigned)((short)0x80000000u > (signed char)0xffffffffu)));
                u2 = u2 * 0x9e3779b1u + (0u / ((unsigned)(0xa01e0263u && i1) | 1u));
            }
            x0 = x0 * 0x100000001b3ull + ((unsigned)((short)p1 > (signed char)(0x36a9eed6u << ((unsigned)w0 & 31u))) + (unsigned)((short)(unsigned)s1 > (signed char)8u));
        } else {
            while (((unsigned)w0 * 0x97ca3675u)) { if (--fuel == 0u) goto done;
                switch ((unsigned)((int)garr[i1 & 7u] < (int)p2) & 7u) {
                    s1 = (int)((unsigned)s1 + (((unsigned)((unsigned)b0 < 0xffffffffu) * r0.y) << ((unsigned)l0 & 31u)));
                    if (((unsigned)(p2 && (unsigned)c1) - (unsigned)e0)) break;
                    h0 = (short)((unsigned)(x0 >> 70) & (unsigned)((u3 & 0x7fffffffu) == (unsigned)s0));
                    *q0 = (unsigned)(p2 < i1);
                    switch ((unsigned)(x0 >> 70) & 7u) {
                        l0 = (long)((unsigned long)l0 + a0[u1 & 3u]);
                        s0 = (int)(((a0[u1 & 3u] % (garr[u2 & 7u] | 1u)) + (unsigned)c0) - ((unsigned)e0 >> (r0.x & 31u)));
                    }
                }
            }
            u0 ^= (i1 ^ (unsigned)(((unsigned)c1 - 0x7fffffffu) && (unsigned)d0));
            while ((unsigned)(unsigned char)((unsigned)e0 * i1)) { if (--fuel == 0u) goto done;
                if ((unsigned)(-(*mp % ((unsigned)l0 | 1u)) || 0u)) continue;
            }
        }
        q0 = &garr[(((unsigned)(short)(r0.y / ((unsigned)c0 | 1u)) - (unsigned)e0) | u3) & 7u];
    }
    if ((unsigned)(0x233a6368u || 4u)) goto L3;
    goto L0;
    e0 = e0 * 0.5L + (long double)(v0 & 1023u);
    u1 = u1 * 0x9e3779b1u + (unsigned)((int)0x7fffffffu < (int)(u1 << (5u & 31u)));
    while (i0++ < 7u && 2u) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((unsigned)h0 || (unsigned)h1));
        u1 += (unsigned)(r0.y && ((unsigned)f0 / (g0 | 1u)));
        if ((unsigned)((short)0x4b1ce5eeu > (signed char)u3)) break;
        *mp = (((unsigned)b0 - 1u) * ((unsigned)s1 >> (fuel & 31u)));
        break; (void)(u0);
    }
    d0 = d0 * 0.5 + (double)((unsigned)w0 & 1023u);
    { unsigned t4; double z4; if (((unsigned)(u0 == fuel)) & 1u) { t4 = ((0xff262a82u - (unsigned)e0) >> (0x80000000u & 31u)); z4 = (double)((~(1u + 4u)) & 255u); } if (((unsigned)(u0 == fuel)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        c0 = (unsigned char)((unsigned)(w0 >> 29) % ((unsigned)(g1 && 0x10000u) | 1u));
    }
    w0 = w0 * 6364136223846793005ull + ((unsigned)(x0 >> 70) ? (unsigned)s1 : (unsigned)(short)(unsigned)(0x6f1f079bu && 0x8bb2d075u));
    q0 = &garr[(unsigned)(x0 >> 70) & 7u];
    switch ((*mp | r0.x) & 7u) {
        switch ((9u * 0x94ed6656u) & 7u) {
            u1 = u1 * 0x9e3779b1u + (*q0 ^ r0.x);
            c1 = (signed char)(unsigned)(i2 < 0xffffffffu);
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((*q0 << (p0 & 31u))) continue;
                while ((i1 | (0u ^ 8u))) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return ((unsigned)((0xcc16cc2fu / (a0[i0 & 3u] | 1u)) && 0x10000u) - (unsigned)((int)v0 < (int)garr[i1 & 7u]));
                    case 5u: ;
                    if ((unsigned)(u1 == (unsigned)(x0 >> 70))) goto L0;
                    case 0u: ;
                }
                case 6u: ;
            }
            c0 = (unsigned char)((unsigned)l0 % ((unsigned)l0 | 1u));
            g1 += (((unsigned)(6u || (unsigned)f0) | (4u * 3u)) & 0u);
            default: ;
        }
        if (9u) goto L2;
        c0 = (unsigned char)(garr[i1 & 7u] & (0x849db40du << (g1 & 31u)));
        *mp = (unsigned)((unsigned)(a0[u1 & 3u] == i2) || (1u - (unsigned)l0));
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)((short)p1 > (signed char)0x7fffffffu) >= (int)0x10000u)) goto L2;
            v0 = ((unsigned)l0 / (a0[i0 & 3u] | 1u));
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= (unsigned)((short)(0x7fffffffu ^ i1) > (signed char)(unsigned)(u1 || (unsigned)c1));
                *q0 += (unsigned)(short)(unsigned)(*mp < (unsigned)((short)((unsigned)c1 + (unsigned)d0) > (signed char)r0.y));
                switch (((unsigned)x0 & fuel) & 7u) {
                    u0 = u0 * 0x9e3779b1u + ((unsigned)f0 + (unsigned)(signed char)(4u << ((unsigned)f0 & 31u)));
                    *mp = v0;
                    case 7u: ;
                    i1 = ((unsigned)!(garr[i1 & 7u] ^ (unsigned)s0) >> ((unsigned)(w0 >> 29) & 31u)) & 15u;
                }
                if (0x80000000u) goto done;
                w0 ^= (unsigned long long)(unsigned)c1 << ((unsigned)((int)g0 < (int)(unsigned)(a0[i0 & 3u] || i1)) & 63u);
            }
            break;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 += (unsigned)((unsigned)!(unsigned)((short)(unsigned)(short)(*mp << (0u & 31u)) > (signed char)0xffffffffu) || *q0);
                c0 = (unsigned char)(p0 / (0xa8ea0ee9u | 1u));
            }
            break;
        }
    }
    while (i0++ < 2u && (unsigned)((unsigned)((short)p0 > (signed char)1u) == a0[i0 & 3u])) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(p0 + (r0.x << ((unsigned)c0 & 31u))) >= (int)p1);
                break; (void)((4u ^ *mp));
                if ((unsigned)(0x28b39699u < (g0 * 0xf934dba2u))) break;
            } while (i2++ < 2u && 0x10000u);
            if ((unsigned)(short)(0x7fffffffu | 8u)) break;
            u1 ^= (unsigned)((int)(garr[u2 & 7u] % ((unsigned)l0 | 1u)) < (int)(unsigned)e0);
        }
        if (0x67e13625u) break;
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)(garr[u2 & 7u] || 0x10000u) >= (int)fuel)) break;
            m0 ^= i2;
        } while (i1++ < 7u && (0xec40676du + a0[i0 & 3u]));
    }
    if (5u) goto L0;
    while (i0++ < 4u && g0) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)((int)-(unsigned)(u2 || a0[u1 & 3u]) >= (int)0x3feeb692u) & 1023u);
    }
    goto L1;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)((int)(unsigned)((short)0x597bc73bu > (signed char)(unsigned)l0) < (int)9u);
    }
    if ((unsigned)((short)0xe2cabfffu > (signed char)6u)) goto L3;
    if ((unsigned)((short)u0 > (signed char)i2)) goto L1;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((0x1d9f5d1eu + 2u) * -(unsigned)((short)r0.x > (signed char)p2));
            u1 = u1 * 0x9e3779b1u + ((unsigned)((9u - a0[u1 & 3u]) && 8u) ^ (unsigned)d0);
            while (~(0xffffffffu / (0xf9afe741u | 1u))) { if (--fuel == 0u) goto done;
                if (g1) break;
                break; (void)(-(u1 << ((0x24655a48u + (unsigned)e0) & 31u)));
                c0 = (unsigned char)(unsigned)h0;
                if (-(unsigned)((unsigned)(i1 && fuel) || fuel)) continue;
                if (fuel < 8u) return p2;
            }
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                u1 += (unsigned)((unsigned)(short)(r0.x ? p0 : 9u) && (9u / (g1 | 1u)));
                if (r0.x) goto L2;
                if (0u) break;
                u1 = u1 * 0x9e3779b1u + ((unsigned)((short)(unsigned)(short)(r0.x & 0u) > (signed char)m0) * *mp);
                if ((unsigned)(0x80000000u && 0x10000u)) break;
                if ((unsigned)((int)v0 >= (int)((unsigned)f0 >> ((unsigned)c0 & 31u)))) {
                    a0[(unsigned)(r0.y < 0xffffffffu) & 3u] = (unsigned)(signed char)(unsigned)(2u && (unsigned)w0);
                }
            }
        } while (i1++ < 4u && m0);
        h1 = (unsigned short)(h1 + ~((unsigned)d0 - i0));
        if ((unsigned)!((unsigned)e0 / ((unsigned)(short)(unsigned)((int)0x766483fcu < (int)(unsigned)(x0 >> 70)) | 1u))) break;
    }
    if ((unsigned)((short)((unsigned)f0 / (m0 | 1u)) > (signed char)(unsigned)(w0 >> 29))) goto done;
    u0 = (unsigned)((int)(((unsigned)x0 << ((unsigned)x0 & 31u)) + i2) < (int)(unsigned)((int)(unsigned)x0 < (int)(unsigned)(w0 >> 29)));
    if ((r0.y - *mp)) goto L4;
    g1 += ~(((unsigned)(x0 >> 70) / ((unsigned)((int)(unsigned)c1 < (int)(unsigned)c1) | 1u)) + (unsigned)e0);
    q0 = &garr[(unsigned)((short)(unsigned)((unsigned)c1 == 0x669ea076u) > (signed char)(unsigned)(0x3c2ad419u || garr[u2 & 7u])) & 7u];
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (unsigned)((unsigned)((unsigned)b0 == 1u) == (unsigned)x0);
        if (0x10000u) break;
        if ((unsigned)(5u == g0)) {
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)(short)(u1 / ((unsigned)(w0 >> 29) | 1u)) << ((((unsigned)h0 ? r0.x : (unsigned)(fuel < 0u)) - v0) & 63u);
            } while (i1++ < 3u && (unsigned)((short)(g1 & i2) > (signed char)u1));
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)0u << ((((unsigned)w0 << (a0[u1 & 3u] & 31u)) | (0x7fffffffu & (g0 / ((unsigned)f0 | 1u)))) & 63u);
                garr[((unsigned)h1 | u0) & 7u] = (p0 | fuel);
                c0 = (unsigned char)(unsigned)((int)v0 < (int)0x8d47efd8u);
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    u3 = (unsigned)((short)(unsigned)((int)*q0 >= (int)(unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)(i1 && (unsigned)w0))) > (signed char)(unsigned)x0);
                    if (((g1 + (unsigned)c1) >> ((unsigned)l0 & 31u))) break;
                    switch (u1 & 7u) {
                        v0 = ((i1 + 0x9bd97c5au) / (~((unsigned)(w0 >> 29) + (unsigned)f0) | 1u));
                        if ((unsigned)((unsigned)f0 == (unsigned)h1)) goto L0;
                        g1 += (~((unsigned)h0 / (0x7fffffffu | 1u)) * (unsigned)((short)fuel > (signed char)g1));
                    }
                    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        m0 ^= (unsigned)((int)(unsigned)(0x80000000u || 0xbbed5763u) < (int)(unsigned)h0);
                        c1 = (signed char)(unsigned)(w0 >> 29);
                        u2 += ((0x80000000u ? a0[i0 & 3u] : (unsigned)l0) / ((unsigned)(0x27b8b4efu < a0[i0 & 3u]) | 1u));
                        h1 = (unsigned short)(h1 + ((unsigned)(unsigned char)(*mp ^ m0) & (unsigned)w0));
                        c0 = (unsigned char)((unsigned)w0 * 0x10000u);
                        do { if (--fuel == 0u) goto done;
                            h0 = (short)((unsigned)l0 + ~(a0[i0 & 3u] * ((unsigned)(w0 >> 29) | (unsigned)h0)));
                            x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)u2) | 4u);
                            break; (void)(0x7fffffffu);
                            *q0 = (unsigned)(signed char)(unsigned)((int)(unsigned)f0 < (int)((unsigned)e0 * (unsigned)((int)0x10000u < (int)*mp)));
                            a0[((unsigned)w0 ^ 8u) & 3u] = (unsigned)((short)p2 > (signed char)((unsigned)(0x33c0f91cu < 0xbf7bc32u) / (7u | 1u)));
                        } while (i1++ < 2u && garr[u2 & 7u]);
                    }
                    if (((3u / (u0 | 1u)) / ((unsigned)s0 | 1u))) break;
                }
                u0 = ((garr[i1 & 7u] & (unsigned)(0x7ff3f93u == u1)) / (((unsigned)s1 & fuel) | 1u));
                b0 = ((unsigned)f0 + (unsigned)((int)p1 >= (int)0xffffffffu)) != 0u;
            }
            continue; (void)((unsigned)d0);
            do { if (--fuel == 0u) goto done;
                continue; (void)((unsigned)!(3u & (unsigned)(short)(u0 - (unsigned)b0)));
            } while (i1++ < 4u && i1);
            if ((0x7fffffffu % ((unsigned)(i2 == (unsigned)c0) | 1u))) break;
        }
    }
    if ((unsigned)(signed char)(0x7fffffffu * (unsigned)(short)(0x5f64d027u + r0.y))) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            u3 ^= (unsigned)((unsigned)x0 == (unsigned)((unsigned)d0 && (unsigned)((unsigned)s0 && 3u)));
            switch ((unsigned)(x0 >> 70) & 7u) {
                *mp = (r0.y ? 0u : 0x6beab851u);
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    switch (i2 & 7u) {
                        r0.y ^= (unsigned)h0;
                        c0 = (unsigned char)v0;
                    }
                    m0 ^= (unsigned)(a0[u1 & 3u] || ((unsigned)(short)(unsigned)(0x66563707u == (unsigned)(w0 >> 29)) & ((unsigned)(w0 >> 29) >> (*mp & 31u))));
                }
                e0 = e0 * 0.5L + (long double)((((0x80000000u | 0x18ba7eafu) * p0) * (unsigned)(r0.y && 0x1ca00d55u)) & 1023u);
                if (u3 == 7u) return (unsigned)(signed char)(unsigned)(((g0 << ((unsigned)c0 & 31u)) % (((unsigned)c1 % (4u | 1u)) | 1u)) && (unsigned)s1);
            }
            if (0x80000000u) break;
            goto L0;
        }
        s1 = (int)((unsigned)s1 + (unsigned)c0);
        w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)((short)(0x10000u + i0) > (signed char)(unsigned)e0) == (0x80000000u & garr[u2 & 7u]));
    }
    q0 = &garr[(unsigned)((unsigned)((int)0xffffffffu < (int)5u) || 0xb381e5c4u) & 7u];
    if (u0) goto L3;
    goto L3;
    goto L0;
    r0.y ^= (unsigned)(~(unsigned)(3u || 3u) < g1);
    if ((unsigned)(0xffffffffu && 0xfd0a2695u)) goto L3;
    if (fuel < 8u) return (unsigned)(a0[u1 & 3u] < (unsigned)((9u << (0x7fffffffu & 31u)) || 0x80000000u));
    if (p2) goto L3;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = ((g1 | (unsigned)(i1 < g0)) & 1u);
        if (u3 == 7u) return ((unsigned)(x0 >> 70) | u1);
        if ((unsigned)(*mp < (v0 >> (v0 & 31u)))) {
            v0 = 0x7fffffffu;
            if ((unsigned)(x0 >> 70)) break;
            if ((unsigned)((int)1u >= (int)fuel)) goto L0;
            garr[(unsigned)((int)m0 >= (int)7u) & 7u] = (unsigned)((int)((unsigned)h1 | (*q0 ? 0x1c54f028u : (unsigned)d0)) < (int)m0);
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                h0 = (short)((g0 ? v0 : 0x10000u) ^ (unsigned)((unsigned)(w0 >> 29) && 0x80000000u));
                w0 = w0 * 6364136223846793005ull + ((unsigned)((unsigned)h1 && 0xffffffffu) >> (0x80000000u & 31u));
                if ((unsigned)(signed char)(0x7fffffffu << (7u & 31u))) break;
                r0.y ^= (*q0 % ((v0 << (0x2424d531u & 31u)) | 1u));
            }
        }
        while ((9u | (unsigned)((short)(unsigned)l0 > (signed char)g0))) { if (--fuel == 0u) goto done;
            s0 = (int)(unsigned)(a0[i0 & 3u] == (unsigned)(i0 || r0.x));
            if ((unsigned)((short)*mp > (signed char)-(0x7fffffffu / (7u | 1u)))) {
                w0 ^= (unsigned long long)-(*mp % (garr[i1 & 7u] | 1u)) << ((i0 & p0) & 63u);
                s1 = (int)((unsigned)s1 + (unsigned)((short)*q0 > (signed char)(unsigned)(v0 && (unsigned)(x0 >> 70))));
                w0 ^= (unsigned long long)(u3 << ((unsigned)b0 & 31u)) << ((unsigned)((int)(unsigned)((0x10000u - u0) || (unsigned)w0) >= (int)(unsigned)((unsigned)s0 < (unsigned)(x0 >> 70))) & 63u);
                { unsigned t5; double z5; if (((unsigned)((p2 % (0x77744dcdu | 1u)) < (unsigned)h1)) & 1u) { t5 = 7u; z5 = (double)(((unsigned)(u3 == *q0)) & 255u); } if (((unsigned)((p2 % (0x77744dcdu | 1u)) < (unsigned)h1)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    if ((unsigned)(0xd069cfc0u && (unsigned)((unsigned)s0 < (unsigned)l0))) {
                        w0 ^= (unsigned long long)(*q0 & r0.x) << ((7u % ((0x73dddaf8u - (unsigned)d0) | 1u)) & 63u);
                        v0 = (unsigned)x0;
                        if ((unsigned)((int)p2 >= (int)i0)) break;
                        u0 ^= i2;
                    } else {
                        i2 = ((unsigned)((int)(unsigned)l0 >= (int)r0.y) >> ((unsigned)e0 & 31u)) & 15u;
                    }
                    h0 = (short)(unsigned)((int)(unsigned)((short)g1 > (signed char)(0xcf73a0a7u ^ (unsigned)h1)) >= (int)u0);
                    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)d0 || (((unsigned)(4u || *q0) / (9u | 1u)) ^ 0x452a1657u));
                    i0 = (u3 / (m0 | 1u)) & 15u;
                }
                if (0x30fc736eu) {
                    w0 = w0 * 6364136223846793005ull + ((0xee4939f3u + (unsigned)b0) >> (((unsigned)(*mp < 0x8fea48bdu) - 0x78b90850u) & 31u));
                    if (((unsigned)l0 + (unsigned)(fuel == (unsigned)h0))) break;
                    if ((*q0 & (unsigned)s1)) break;
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((r0.y << (fuel & 31u))) break;
                        continue; (void)(((5u | i0) - 0xffffffffu));
                        { unsigned t6; double z6; if ((((unsigned)h0 / (p2 | 1u))) & 1u) { t6 = (p1 + 0x4686d0afu); z6 = (double)((((unsigned)w0 * 0xa3ec86a3u)) & 255u); } if ((((unsigned)h0 / (p2 | 1u))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                            if ((unsigned)(unsigned char)(unsigned)((unsigned)s0 == 0x5cce7c15u)) break;
                            break; (void)(((unsigned)h0 & (unsigned)b0));
                            if ((m0 + (unsigned)s1)) break;
                            h1 = (unsigned short)(h1 + ((u3 + (unsigned)l0) - p1));
                            i2 = ((unsigned)((((unsigned)h1 % ((unsigned)f0 | 1u)) * garr[u2 & 7u]) && u1) & (unsigned)d0) & 15u;
                        }
                        if (((unsigned)c0 + (unsigned)f0)) break;
                        v0 = (unsigned)((int)(unsigned)h1 < (int)(unsigned)((int)(unsigned)w0 < (int)a0[i0 & 3u]));
                        if ((unsigned)((int)0x10000u < (int)0x30a53510u)) goto L2;
                    }
                    e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(i2 || i1) && (unsigned)((short)m0 > (signed char)(0xffffffffu << (0xffffffffu & 31u)))) & 1023u);
                }
                *mp = (unsigned)(w0 >> 29);
            }
            switch (p1 & 7u) {
                case 5u: ;
            }
            c0 = (unsigned char)(5u * (p1 - (0x1525cb92u + (unsigned)x0)));
        }
    }
    g1 += (7u >> (0x2f268b63u & 31u));
    q0 = &garr[((unsigned)(signed char)((0x7fffffffu % ((unsigned)h1 | 1u)) & (unsigned)(w0 >> 29)) & (8u / (2u | 1u))) & 7u];
    if (((p2 / (a0[i0 & 3u] | 1u)) & 6u)) goto L2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)(fuel & 1023u);
        switch (a0[i0 & 3u] & 7u) {
            case 7u: ;
            case 6u: ;
            c0 = (unsigned char)(unsigned)l0;
            case 5u: ;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(u3, ((unsigned)(x0 >> 70) ^ 0x94ee5806u), (unsigned)((int)garr[i1 & 7u] >= (int)g1)); }
                if (budget != 0u) { budget -= 1u; u0 = fn0((g0 % (9u | 1u)), 0xffffffffu, 0x80000000u); }
                { unsigned t0; double z0; if (((unsigned)(w0 >> 29)) & 1u) { t0 = ((unsigned)w0 / (u1 | 1u)); z0 = (double)(((unsigned)((unsigned)d0 && 0x37edeab8u)) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)0x22fe07c7u > (signed char)(p0 ^ p1)), (unsigned)s0, (unsigned)((int)m0 >= (int)(0x10000u * p0))); }
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(short)(unsigned)((int)((unsigned)b0 >> ((unsigned)l0 & 31u)) < (int)*mp), u0, (unsigned)((unsigned)(x0 >> 70) && (0xd327dbf6u ^ fuel))); }
                    g0 = (unsigned)(unsigned char)((unsigned)(short)((unsigned)h1 & i1) / ((unsigned)((int)(unsigned)(a0[u1 & 3u] || (unsigned)s1) < (int)a0[i0 & 3u]) | 1u));
                    s1 = (int)((unsigned)s1 + 0x10000u);
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, (3u + (unsigned)(short)(3u << (garr[u2 & 7u] & 31u))), (unsigned)((int)a0[i0 & 3u] < (int)0x395a278cu)); }
            } while (i1++ < 5u && ((unsigned)f0 - (unsigned)(w0 >> 29)));
        }
        if ((0xf9ccc55u + (unsigned)(signed char)(8u % (m0 | 1u)))) continue;
    }
    r0.y ^= (v0 % (garr[i1 & 7u] | 1u));
    switch (2u & 7u) {
        while ((unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
            g1 += fuel;
            q0 = &garr[((u2 / (garr[i1 & 7u] | 1u)) | 2u) & 7u];
            if ((unsigned)(signed char)(0xffffffffu & (i0 / (i2 | 1u)))) break;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0(i0, (p1 / (m0 | 1u)), (unsigned)(signed char)(1u & 9u)); }
        case 1u: ;
        break; (void)(p1);
    }
    while (i0++ < 7u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (unsigned)(p1 && a0[u1 & 3u]);
        if ((unsigned)(garr[u2 & 7u] || (r0.x + *mp))) break;
        if ((unsigned)((int)(unsigned)s0 < (int)g1)) {
            if ((0x7fffffffu / ((unsigned)((int)0u >= (int)a0[u1 & 3u]) | 1u))) continue;
            if ((0xb01789ccu % ((unsigned)b0 | 1u))) goto L1;
        } else {
            if (v0) goto L2;
            a0[*q0 & 3u] = (((0x10000u % ((g1 + 3u) | 1u)) - 0x932a0600u) % (i0 | 1u));
        }
        continue; (void)(0x10000u);
    }
    if ((unsigned)((int)i0 >= (int)9u)) goto L4;
    goto L3;
    if ((unsigned)(i1 && 5u)) goto L3;
    u1 ^= (unsigned)(short)(unsigned)(i1 || 2u);
    { unsigned t1; double z1; if ((r0.y) & 1u) { t1 = (unsigned)(m0 && (unsigned)l0); z1 = (double)(((unsigned)(p1 < (unsigned)s1)) & 255u); } if ((r0.y) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            goto L3;
            { unsigned t2; double z2; if (((unsigned)((int)(unsigned)(u2 < u1) >= (int)u0)) & 1u) { t2 = (unsigned)(w0 >> 29); z2 = (double)(((unsigned)(w0 >> 29)) & 255u); } if (((unsigned)((int)(unsigned)(u2 < u1) >= (int)u0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                *mp = ~(g1 << ((unsigned)((int)(unsigned)((unsigned)s0 && (unsigned)e0) >= (int)0x10000u) & 31u));
                while (i1++ < 3u && (unsigned)!((unsigned)w0 * (i0 - p2))) { if (--fuel == 0u) goto done;
                    h0 = (short)(0u % ((unsigned)s1 | 1u));
                }
                if (fuel) goto L1;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)x0 * (unsigned)d0), i2, (unsigned)((unsigned)(x0 >> 70) || (unsigned)c1)); }
            if (((unsigned)((int)0x5fd2f24au < (int)0x43852394u) % (0x10000u | 1u))) break;
            if (((unsigned)((int)i0 < (int)0x80000000u) ^ 4u)) {
                if (((unsigned)w0 * -(unsigned)((short)garr[u2 & 7u] > (signed char)i0))) continue;
                *q0 += ((unsigned)((short)(unsigned)((int)(unsigned)l0 >= (int)m0) > (signed char)(unsigned)(x0 >> 70)) >> ((r0.y ^ g0) & 31u));
            } else {
                b0 = (unsigned)(r0.y == ((unsigned)(x0 >> 70) / ((unsigned)c1 | 1u))) != 0u;
                v0 = ((unsigned)(i0 == 0x4655f831u) * (u2 & i2));
                g0 = p1;
            }
        }
        m0 ^= (unsigned)(short)((unsigned)(v0 == 0xc282efu) * i0);
        if (((0xffffffffu * 0x10000u) - 0x3205fca9u)) goto L4;
    }
    if (u3 == 7u) return (unsigned)((int)0x80000000u >= (int)0u);
    v0 = (unsigned)((unsigned)(((unsigned)h0 << (v0 & 31u)) < (unsigned)((int)0x7fffffffu >= (int)0x80000000u)) < 0x88553b15u);
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((int)fuel >= (int)((unsigned)l0 + (unsigned)h0))) goto L0;
        do { if (--fuel == 0u) goto done;
            a0[(garr[i1 & 7u] - *mp) & 3u] = (unsigned)(unsigned char)((*mp ^ (0xa7742defu ^ u1)) >> ((0x80000000u & a0[u1 & 3u]) & 31u));
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)b0 | 0xf1a8650fu), (unsigned)x0, (7u << (v0 & 31u))); }
            break; (void)((unsigned)((i0 % (0x10000u | 1u)) || 0x6e69bac1u));
        } while (i1++ < 2u && 0x80000000u);
        if (p2) goto L4;
    } while (i0++ < 2u && (9u ? 0xd6f6bbc0u : u3));
    l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)b0 / (garr[i1 & 7u] | 1u)) && (unsigned)(x0 >> 70)));
    g1 += (unsigned)(unsigned char)(unsigned)(u1 < (unsigned)(u2 || ~((unsigned)h0 << ((unsigned)h1 & 31u))));
    c1 = (signed char)(unsigned)((unsigned)w0 < (7u % (0x21177500u | 1u)));
    i0 = ((unsigned)(short)((unsigned)(x0 >> 70) & p0) + (unsigned)((int)0x844d2df6u < (int)u0)) & 15u;
    if (u3) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)h1 << (i1 & 63u);
            *mp = ((unsigned)(*mp && u3) ^ (unsigned)((unsigned)((int)u3 >= (int)0x7fffffffu) == g0));
        }
        L0: if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + ~(m0 & ((0x511cb724u * (unsigned)h1) | 0x293f01cfu));
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(4u * 0xe16c5586u);
            d0 = d0 * 0.5 + (double)(0xef92900cu & 1023u);
            { unsigned t3; double z3; if ((a0[i0 & 3u]) & 1u) { t3 = (unsigned)e0; z3 = (double)(((unsigned)(short)(unsigned)(0x7ebd4796u == (unsigned)e0)) & 255u); } if ((a0[i0 & 3u]) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                if ((unsigned)x0) break;
            }
        }
        v0 = (unsigned)((int)fuel >= (int)(unsigned)((int)p2 < (int)i1));
    }
    do { if (--fuel == 0u) goto done;
        break; (void)(u3);
        break; (void)((unsigned)s0);
    } while (i0++ < 5u && 0xf1741eceu);
    goto L2;
    L1: if (--fuel == 0u) goto done;
    if (3u) goto done;
    *mp = (unsigned)(short)((((unsigned)e0 & (unsigned)((int)0x7fffffffu >= (int)8u)) | 0x7fffffffu) & (unsigned)f0);
    g0 = (unsigned)((u2 * (unsigned)((int)g1 >= (int)p1)) && (unsigned)((int)m0 < (int)p0));
    s0 = (int)(((unsigned)(unsigned char)(unsigned)((short)(unsigned)h0 > (signed char)m0) * *q0) + 9u);
L2: if (--fuel == 0u) goto done;
L3: if (--fuel == 0u) goto done;
L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if ((u3) & 1u) { t0 = v0; z0 = (double)(((unsigned)((int)(unsigned)b0 >= (int)i0)) & 255u); } if ((u3) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        switch (~(unsigned)((int)(unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)s0) >= (int)u0) & 7u) {
            if ((unsigned)((int)(unsigned)((unsigned)e0 == 0x4b5d8d5au) >= (int)p1)) goto L3;
            if ((unsigned)((int)u2 >= (int)fuel)) goto L1;
            f0 = f0 * 0.5f + (float)(0x80000000u & 255u);
        }
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(0xffffffffu && (unsigned)(w0 >> 29)));
                r0.x = ((unsigned)((unsigned)((short)0xffffffffu > (signed char)(unsigned)((int)*q0 >= (int)0x2d60c396u)) < (unsigned)w0) % (u1 | 1u));
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)0x7fffffffu < (int)a0[i0 & 3u]), 0x624d0e0eu, (unsigned)s1); }
                *q0 += (0x80000000u >> ((unsigned)(short)((unsigned)s1 - 8u) & 31u));
                switch (((9u | (unsigned)f0) + a0[i0 & 3u]) & 7u) {
                    q0 = &garr[(((unsigned)((int)g1 >= (int)(unsigned)s0) ? 0x8a789cfcu : p0) % (4u | 1u)) & 7u];
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)d0, ((unsigned)f0 / ((unsigned)w0 | 1u)), (0x7fffffffu | *mp)); }
                    garr[((unsigned)e0 | (unsigned)f0) & 7u] = (unsigned)(short)(fuel * (unsigned)((int)(unsigned)(p1 || (unsigned)(unsigned char)((unsigned)s0 / (p0 | 1u))) >= (int)a0[i0 & 3u]));
                }
            } while (i1++ < 5u && -(unsigned)((short)a0[i0 & 3u] > (signed char)0x80000000u));
            g0 = ((unsigned)((unsigned)(w0 >> 29) && *mp) / ((g0 >> (p1 & 31u)) | 1u));
        } while (i0++ < 6u && (unsigned)((unsigned)(p0 && (unsigned)f0) && 0x80000000u));
        L0: if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (unsigned)l0;
        } while (i0++ < 5u && 0xe599c925u);
        *mp = ((unsigned)((short)i0 > (signed char)a0[u1 & 3u]) - (7u | 0u));
        *q0 = (v0 ^ (unsigned)((0x811f3e95u / ((unsigned)f0 | 1u)) && (unsigned)(w0 >> 29)));
    }
    do { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + ((unsigned)c1 % ((0x7fffffffu >> (v0 & 31u)) | 1u)));
            for (;;) { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                if (fuel < 8u) return r0.y;
                m0 ^= (unsigned)((unsigned)l0 && (unsigned)(((unsigned)(w0 >> 29) ^ a0[i0 & 3u]) == (unsigned)h0));
                if (0xeffc678du) break;
                if (0xca4a607cu) {
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(~(unsigned)(1u || v0) < (unsigned)l0), ~((unsigned)((int)(unsigned)l0 < (int)0x7fffffffu) * p1), 0x7fffffffu); }
                    while (i0++ < 4u && (unsigned)((unsigned)(w0 >> 29) == (*mp * garr[u2 & 7u]))) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)v0 < (int)(*q0 << (0x7fffffffu & 31u))), (unsigned)!(0x80000000u & 0x80000000u), -(u0 % ((unsigned)d0 | 1u))); }
                        d0 = d0 * 0.5 + (double)(6u & 1023u);
                        c0 = (unsigned char)((unsigned)e0 ^ 2u);
                    }
                    if (p0) continue;
                    g0 = (unsigned)((short)i0 > (signed char)~((1u << ((unsigned)f0 & 31u)) ^ garr[i1 & 7u]));
                    switch ((unsigned)(unsigned char)(unsigned)((unsigned)w0 || (unsigned)s1) & 7u) {
                        s1 = (int)((unsigned)s1 + (unsigned)((5u | *q0) && (0x10000u - (unsigned)((int)(unsigned)s1 < (int)0x17619741u))));
                        v0 = ((unsigned)(v0 == (unsigned)e0) >> (((5u * p1) & 0x20362016u) & 31u));
                        if (budget != 0u) { budget -= 1u; u2 = fn1(8u, fuel, v0); }
                    }
                    continue; (void)((unsigned)((short)8u > (signed char)(unsigned)((short)a0[i0 & 3u] > (signed char)a0[i0 & 3u])));
                } else {
                    if ((r0.x ^ (0x7fffffffu << (u2 & 31u)))) {
                        d0 = d0 * 0.5 + (double)((g1 - (0x80000000u % ((unsigned)b0 | 1u))) & 1023u);
                        c0 = (unsigned char)0xffffffffu;
                        u0 ^= (unsigned)((unsigned)d0 || (unsigned)s1);
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)d0, (unsigned)((int)6u < (int)((unsigned)x0 / (*q0 | 1u))), (unsigned)(-((unsigned)s1 << ((unsigned)b0 & 31u)) || 0x80000000u)); }
                        if (((unsigned)((int)*mp < (int)5u) + (unsigned)s1)) goto done;
                        { unsigned t1; double z1; if ((((unsigned)(x0 >> 70) ^ (unsigned)(*q0 && g0))) & 1u) { t1 = (unsigned)h1; z1 = (double)(((0xffffffffu / (a0[i0 & 3u] | 1u))) & 255u); } if ((((unsigned)(x0 >> 70) ^ (unsigned)(*q0 && g0))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                            c0 = (unsigned char)((unsigned)(short)(unsigned)(0x80000000u || u2) & ~(unsigned)(a0[i0 & 3u] || u2));
                            if ((unsigned)((*mp << ((unsigned)c0 & 31u)) && 0x94d09d02u)) continue;
                        }
                    } else {
                        u1 += (unsigned)((v0 / ((unsigned)(x0 >> 70) | 1u)) < (unsigned)s1);
                    }
                    if (r0.y) break;
                }
                x0 = x0 * 0x100000001b3ull + (((*mp >> ((unsigned)e0 & 31u)) | (unsigned)s1) << ((unsigned)(0x9c7bb7d3u || 2u) & 31u));
            }
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                u2 ^= 0x80000000u;
                goto L3;
                *mp = (unsigned)((short)(*q0 % (u2 | 1u)) > (signed char)(unsigned)((unsigned)(u3 || (unsigned)l0) || (unsigned)s0));
            }
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                i0 = ((unsigned)e0 << (i2 & 31u)) & 15u;
                x0 = x0 * 0x100000001b3ull + ((unsigned)s0 ? (garr[i1 & 7u] + (unsigned)(short)((unsigned)w0 / (0xd352710bu | 1u))) : 2u);
            }
            q0 = &garr[(unsigned)((int)(unsigned)((short)(unsigned)c1 > (signed char)(unsigned)h1) >= (int)(0x7905730au - (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)(w0 >> 29)))) & 7u];
            if (m0) continue;
        }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            L2: if (--fuel == 0u) goto done;
            if ((unsigned)(0xcdfed496u || (unsigned)(w0 >> 29))) goto done;
            b0 = ((unsigned)((int)(0xbd70d52fu | 0xef63d738u) >= (int)0u) / (r0.y | 1u)) != 0u;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(w0 >> 29) < m0), (unsigned)((int)(r0.y | (unsigned)s1) < (int)(unsigned)s0), ((i1 - 0x3ad78fc4u) % ((unsigned)b0 | 1u))); }
            L3: if (--fuel == 0u) goto done;
            a0[0x77eed59eu & 3u] = (g0 % ((unsigned)(0x80000000u == (unsigned)s1) | 1u));
        }
        { unsigned t2; double z2; if ((((unsigned)e0 + (unsigned)(r0.y || 0x28309a5bu))) & 1u) { t2 = *mp; z2 = (double)(((unsigned)w0) & 255u); } if ((((unsigned)e0 + (unsigned)(r0.y || 0x28309a5bu))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0u) == m0);
            for (;;) { if (--fuel == 0u) goto done;
                switch ((unsigned)((unsigned)x0 || 2u) & 7u) {
                    u3 = u3 * 0x9e3779b1u + (unsigned)(short)(*q0 % ((unsigned)(garr[i1 & 7u] && u2) | 1u));
                    if (budget != 0u) { budget -= 1u; u2 = fn1(0x7fffffffu, (unsigned)(7u || (unsigned)(w0 >> 29)), 0u); }
                }
            }
            break; (void)(0x7781aau);
            e0 = e0 * 0.5L + (long double)(((unsigned)e0 ? p2 : a0[i0 & 3u]) & 1023u);
            L4: if (--fuel == 0u) goto done;
        }
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((u0 >> (3u & 31u)) * (u2 | 4u)) & 1023u);
        }
        v0 = ((unsigned)s1 - i0);
    } while (i0++ < 2u && (i2 * ((unsigned)h0 << (a0[i0 & 3u] & 31u))));
    do { if (--fuel == 0u) goto done;
        switch (a0[i0 & 3u] & 7u) {
            if (v0) {
                d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(x0 >> 70) || (((unsigned)(w0 >> 29) & 0xffffffffu) / ((unsigned)h1 | 1u))) & 1023u);
                if ((unsigned)((unsigned)(8u < 0xa961ffb1u) < (unsigned)c0)) break;
                continue; (void)(~(unsigned)((unsigned)x0 || ((unsigned)l0 + (unsigned)e0)));
                for (;;) { if (--fuel == 0u) goto done;
                    { unsigned t3; double z3; if (((unsigned)((p0 + p2) || (unsigned)h1)) & 1u) { t3 = (unsigned)d0; z3 = (double)((((i2 * (unsigned)f0) % (*q0 | 1u))) & 255u); } if (((unsigned)((p0 + p2) || (unsigned)h1)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                        if (u0) goto L4;
                    }
                    w0 ^= (unsigned long long)(0x99040933u | p2) << (((unsigned)(u3 < 0x60b955f7u) | 0xffffffffu) & 63u);
                    *mp = (((unsigned)h1 & (unsigned)(x0 >> 70)) << ((unsigned)((unsigned)((unsigned)s1 == 0x80000000u) || 2u) & 31u));
                }
            } else {
                *mp = (unsigned)!(unsigned)(u2 && (unsigned)((int)u3 >= (int)(r0.y ^ u0)));
                case 6u: ;
                if (0u) break;
            }
            default: ;
            *q0 += (p1 / (7u | 1u));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((0x10000u ^ 1u), ((u2 * fuel) >> (0x80000000u & 31u)), (unsigned)(short)((unsigned)e0 * (unsigned)w0)); }
        r0.y ^= (unsigned)!(unsigned)((i1 + 0x6b980098u) == v0);
    } while (i0++ < 5u && ((0x10000u >> ((unsigned)h0 & 31u)) & 1u));
    if (((unsigned)c1 / (0xa0876a4u | 1u))) {
        *mp = (((u1 & p2) | fuel) - (r0.y - (unsigned)s1));
        *q0 += (unsigned)((int)u2 < (int)(0x80000000u ^ g1));
    }
    if ((r0.x >> ((garr[u2 & 7u] >> (6u & 31u)) & 31u))) {
        if (budget != 0u) { budget -= 1u; u3 = fn1((0xec8caf50u << (u1 & 31u)), garr[u2 & 7u], i2); }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)((short)g1 > (signed char)(unsigned)(a0[i0 & 3u] < 4u));
            if ((1u | a0[u1 & 3u])) break;
            do { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((short)4u > (signed char)((unsigned)c1 - 1u)) || (unsigned)d0) & 1023u);
                c1 = (signed char)(unsigned)((int)((0x10000u & (0u - 0x80000000u)) << (g1 & 31u)) >= (int)a0[i0 & 3u]);
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    goto L4;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)(signed char)((unsigned)w0 & 0xd5e54cf9u)) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0xffffffffu || g0), (unsigned)(u0 || (*q0 << (m0 & 31u))), ((unsigned)f0 + (unsigned)h1)); }
                        if (u3 == 7u) return *mp;
                        if (8u) break;
                        if ((0x3e169a6eu % (0x7fffffffu | 1u))) goto done;
                    } while (i0++ < 6u && (unsigned)(u2 || 0x10000u));
                }
                i1 = (unsigned)!(unsigned)(0xffffffffu < (unsigned)w0) & 15u;
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)(w0 >> 29) | (i0 * p0)), (unsigned)d0, (unsigned)(0x10000u < (unsigned)(w0 >> 29))); }
            } while (i1++ < 6u && (unsigned)((int)r0.y < (int)(unsigned)(0xffffffffu < (unsigned)(x0 >> 70))));
            if ((unsigned)(garr[u2 & 7u] && garr[u2 & 7u])) break;
        }
        goto L0;
    } else {
        if (i0) goto L1;
        u3 ^= (0xa7748c8du | (0x7fffffffu / (8u | 1u)));
        if (-(unsigned)((unsigned)(w0 >> 29) && u1)) goto done;
    }
    if (~(p2 + ((unsigned)s0 / ((unsigned)w0 | 1u)))) {
        goto L0;
        b0 = ((r0.x << ((unsigned)e0 & 31u)) >> (r0.y & 31u)) != 0u;
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)2u > (signed char)~(unsigned)((unsigned)h1 && v0)), (p1 + u1), ((unsigned)(w0 >> 29) ? (unsigned)s0 : (unsigned)e0)); }
        h0 = (short)(unsigned)(0u && u3);
        switch ((3u + g0) & 7u) {
            q0 = &garr[(m0 % ((unsigned)(9u && ~((unsigned)w0 + (unsigned)d0)) | 1u)) & 7u];
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)c0 + i1), ((u2 / ((unsigned)f0 | 1u)) * 0x308558a4u), (unsigned)d0); }
    a0[(unsigned)(w0 >> 29) & 3u] = (unsigned)(u1 == (unsigned)((unsigned)((int)3u >= (int)0x10000u) < (g0 & 9u)));
    if (budget != 0u) { budget -= 1u; u2 = fn1(garr[i1 & 7u], (unsigned)b0, (0u | (m0 - v0))); }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)s0, ((unsigned)((unsigned)l0 == (unsigned)x0) + 0x93a35dc2u), i2); }
    if ((unsigned)(r0.y < 0x579bff2du)) {
        w0 = w0 * 6364136223846793005ull + u1;
        for (;;) { if (--fuel == 0u) goto done;
            c1 = (signed char)p0;
            g0 = ((unsigned)l0 ? m0 : (unsigned)(*mp == (unsigned)s0));
            r0.y ^= ((unsigned)(short)(unsigned)(i2 && 0x80000000u) / ((unsigned)(m0 == (fuel & u3)) | 1u));
            while (i1++ < 3u && ((unsigned)h1 / ((p1 / ((unsigned)f0 | 1u)) | 1u))) { if (--fuel == 0u) goto done;
                u0 = m0;
                goto L2;
                if (u3) break;
                if ((unsigned)c0) continue;
                g1 += -(unsigned)((unsigned)b0 || (0xffffffffu & p2));
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (~((i2 - 0x7fffffffu) - 0xc2e51ca3u)) break;
                    if (((unsigned)b0 / (fuel | 1u))) break;
                    if ((((unsigned)c0 | (unsigned)(w0 >> 29)) >> ((unsigned)d0 & 31u))) break;
                    u3 ^= (0x80000000u << ((0xddc6959du << (((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)(w0 >> 29)) << (fuel & 31u)) & 31u)) & 31u));
                    if (((unsigned)(a0[u1 & 3u] || 0x7fffffffu) >> ((unsigned)(w0 >> 29) & 31u))) goto L4;
                }
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((0x37c46fe5u + 0xdffa8805u), (i1 + (unsigned)f0), (i1 | i2)); }
            if ((8u >> (p0 & 31u))) break;
        }
    } else {
        goto L0;
        v0 = (unsigned)h0;
        goto L2;
    }
    h0 = (short)(unsigned)(((unsigned)e0 ? (unsigned)h1 : (unsigned)h0) < 0xffffffffu);
    if ((unsigned)b0) {
        if ((unsigned)((unsigned)(w0 >> 29) == 0xe46566a1u)) {
            g0 = (unsigned)((unsigned)((unsigned)s0 == i1) || (6u ^ (unsigned)((int)p0 >= (int)m0)));
            if (g0) {
                *q0 = (unsigned)(unsigned char)(((unsigned)x0 << (0xdc5b4ffu & 31u)) / (((unsigned)f0 % (p1 | 1u)) | 1u));
                s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)((int)9u >= (int)garr[u2 & 7u])));
                u0 = (unsigned)((unsigned)b0 < (unsigned)x0);
                w0 = w0 * 6364136223846793005ull + fuel;
                if ((unsigned)h1) goto done;
                q0 = &garr[(unsigned)(((unsigned)(x0 >> 70) + (unsigned)h0) || u1) & 7u];
            }
        }
    } else {
        if ((3u << (0x4ffa499u & 31u))) goto L4;
        if (~(unsigned)(0x80000000u && ~(unsigned)((short)0x80000000u > (signed char)(unsigned)l0))) goto L2;
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)(unsigned)!(*mp ^ (unsigned)b0);
        i1 = (unsigned)((int)v0 >= (int)(unsigned)((unsigned)s0 == r0.y)) & 15u;
        while (i1++ < 2u && (((unsigned)(w0 >> 29) + fuel) - (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
            if (fuel < 8u) return i0;
            while ((unsigned)x0) { if (--fuel == 0u) goto done;
                g1 += ((unsigned)(0x270f667au || ((unsigned)l0 ^ fuel)) | ~(unsigned)((unsigned)s0 && r0.y));
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)h0) ^ i0)) {
                        l0 = (long)((unsigned long)l0 + (5u >> ((unsigned)h0 & 31u)));
                        for (;;) { if (--fuel == 0u) goto done;
                            if (0x10000u) break;
                            s0 = (int)(unsigned)((short)(unsigned)((int)0xffffffffu >= (int)(m0 << (g1 & 31u))) > (signed char)0x80000000u);
                        }
                        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(short)(unsigned)(u0 == m0) == fuel) & 255u);
                        if ((0xd66caa3cu >> (0xffffffffu & 31u))) goto L4;
                        *q0 = (unsigned)((short)(6u >> (0x10000u & 31u)) > (signed char)(i0 % ((unsigned)(0x10000u || p0) | 1u)));
                        break; (void)(((unsigned)(0x7fffffffu && r0.y) * p2));
                    } else {
                        f0 = f0 * 0.5f + (float)((unsigned)(x0 >> 70) & 255u);
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)0x80000000u < (int)0x7fffffffu), r0.x, (unsigned)(short)(unsigned)(0x8f2c9d3au < 0x7fffffffu)); }
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)(0x10000u + (unsigned)l0), -(r0.y ^ 0xffffffffu), (unsigned)h1); }
                        if (budget != 0u) { budget -= 1u; u1 = fn1(garr[i1 & 7u], ((unsigned)((int)r0.x >= (int)p1) - (unsigned)h0), (unsigned)((int)(unsigned)(short)(unsigned)((int)p2 < (int)0x80000000u) < (int)0x80000000u)); }
                        x0 = x0 * 0x100000001b3ull + ((unsigned)c1 & (i1 - (unsigned)((int)(unsigned)x0 < (int)p1)));
                        q0 = &garr[(unsigned)((int)(unsigned)s0 < (int)((unsigned)s1 ^ 0x7fffffffu)) & 7u];
                        if (((unsigned)s1 & (0u - r0.x))) break;
                        h1 = (unsigned short)(h1 + 0x4693eb15u);
                    } while (i1++ < 7u && 0xdb8c2f21u);
                    { unsigned t4; double z4; if (((unsigned)(8u && v0)) & 1u) { t4 = (unsigned)((short)(unsigned)((int)i0 < (int)g0) > (signed char)0x10000u); z4 = (double)((i1) & 255u); } if (((unsigned)(8u && v0)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                        u3 = u3 * 0x9e3779b1u + (unsigned)!(((unsigned)(3u && i1) << (i0 & 31u)) / ((unsigned)h1 | 1u));
                        break; (void)(a0[i0 & 3u]);
                        if (*mp) break;
                        s0 = (int)((unsigned)((short)u0 > (signed char)(unsigned)w0) + (unsigned)((6u >> (0x83e7244bu & 31u)) == (unsigned)h1));
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)x0 && p0), (0xffffffffu + (0x80000000u & (unsigned)s0)), ((unsigned)s0 & (unsigned)(signed char)(v0 >> ((unsigned)(w0 >> 29) & 31u)))); }
                    for (;;) { if (--fuel == 0u) goto done;
                        if ((*q0 * (unsigned)(u3 || 1u))) break;
                        if ((unsigned)x0) goto L3;
                        if ((unsigned)((int)i0 < (int)(0x80000000u ^ 4u))) {
                            u2 ^= ((i2 << (0xffffffffu & 31u)) >> ((u3 % (m0 | 1u)) & 31u));
                            *mp = (unsigned)(short)((unsigned)(garr[i1 & 7u] || garr[u2 & 7u]) << (0x7fffffffu & 31u));
                        } else {
                            q0 = &garr[(garr[i1 & 7u] ^ (9u & a0[u1 & 3u])) & 7u];
                            break; (void)((fuel % (u2 | 1u)));
                        }
                    }
                }
            }
            while (i2++ < 3u && (8u >> ((unsigned)(p0 && p1) & 31u))) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)((unsigned)((int)0xacb75f8u >= (int)r0.x) ? (unsigned)((int)3u >= (int)*mp) : (unsigned)h0);
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(a0[i0 & 3u] || (unsigned)(unsigned char)(unsigned)((int)(unsigned)w0 >= (int)*q0)), garr[u2 & 7u], garr[u2 & 7u]); }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)garr[i1 & 7u] > (signed char)(u2 - 0x6941e43fu)), -(i2 ? (unsigned)s1 : (unsigned)d0), (unsigned)((short)(a0[i0 & 3u] * (unsigned)(w0 >> 29)) > (signed char)fuel)); }
            }
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                b0 = (((unsigned)(i1 || i0) & (unsigned)l0) - (r0.y | garr[u2 & 7u])) != 0u;
                while ((0x98ef1634u + (garr[u2 & 7u] / ((unsigned)h1 | 1u)))) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((*mp - (0xe129ca47u | (unsigned)s1)) & 1023u);
                    l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)((short)a0[u1 & 3u] > (signed char)a0[u1 & 3u]));
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)9u > (signed char)(unsigned)w0), (unsigned)(((unsigned)f0 >> (9u & 31u)) < p2), g0); }
                    d0 = d0 * 0.5 + (double)((unsigned)((int)7u < (int)(unsigned)c0) & 1023u);
                    if (((unsigned)((int)*mp < (int)(unsigned)b0) << (p2 & 31u))) continue;
                }
            }
            if (~(unsigned)((short)u2 > (signed char)(u1 + (unsigned)c0))) {
                break; (void)(0x10000u);
                u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)(w0 >> 29) < (unsigned)((unsigned)h1 || ((unsigned)w0 * (unsigned)(0x80000000u < garr[i1 & 7u]))));
                *q0 += 8u;
            } else {
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)(unsigned)(9u && (unsigned)e0), g0, (unsigned)(0x6d40b18fu < (unsigned)((unsigned)x0 && u1))); }
                goto L1;
                continue; (void)((m0 ^ (g0 % (0x80000000u | 1u))));
                u0 = u0 * 0x9e3779b1u + ((unsigned)((short)(unsigned)h1 > (signed char)0x10000u) % (r0.y | 1u));
            }
        }
        if ((unsigned)((short)p0 > (signed char)(unsigned)(x0 >> 70))) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)s0 && (unsigned)((short)garr[u2 & 7u] > (signed char)0xb4b71edcu)), (v0 | (0x10000u | g1)), g0); }
            s1 = (int)((unsigned)s1 + (unsigned)(short)((unsigned)f0 >> (g0 & 31u)));
            goto L4;
            if ((unsigned)((unsigned)e0 && (unsigned)h0)) break;
            if ((unsigned)((unsigned)s0 || m0)) break;
            for (;;) { if (--fuel == 0u) goto done;
                u1 ^= ((unsigned)b0 >> (i1 & 31u));
                v0 = (unsigned)(x0 >> 70);
                *q0 += (((unsigned)((unsigned)c0 < g1) / ((unsigned)b0 | 1u)) / ((unsigned)(short)((unsigned)h0 + r0.x) | 1u));
                u3 ^= ((unsigned)(7u < (unsigned)(x0 >> 70)) - (unsigned)h0);
            }
        } else {
            if (((unsigned)(w0 >> 29) | 0x172f3a90u)) {
                if (p1) {
                    while (i1++ < 6u && ((unsigned)(*q0 && 0u) & 0x615ef73cu)) { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            r0.y ^= (unsigned)((short)(unsigned)(signed char)(unsigned)(p1 == ~(unsigned)((unsigned)(x0 >> 70) || p1)) > (signed char)p0);
                            g0 = r0.x;
                        } while (i2++ < 4u && (unsigned)(unsigned char)((unsigned)(u1 == p2) * *q0));
                    }
                }
            } else {
                if (0xffffffffu) break;
                goto L2;
                if (((unsigned)x0 << ((unsigned)w0 & 31u))) break;
                if (a0[u1 & 3u]) break;
            }
            break; (void)((unsigned)((unsigned)x0 < (unsigned)((int)g1 >= (int)i1)));
            if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)s1 - i1), (unsigned)d0, (unsigned)(short)((unsigned)(x0 >> 70) / ((unsigned)!(0x80000000u % (g1 | 1u)) | 1u))); }
            if ((unsigned)((int)p1 < (int)(unsigned)(x0 >> 70))) goto L4;
        }
        r0.x = (((unsigned)b0 >> (*mp & 31u)) % (g0 | 1u));
    }
    if ((unsigned)((unsigned)s0 == (unsigned)f0)) goto L2;
    if (((unsigned)l0 / (((unsigned)l0 ^ 0x906eff20u) | 1u))) {
        for (;;) { if (--fuel == 0u) goto done;
            *q0 = (unsigned)(unsigned char)((unsigned)((unsigned)l0 < (unsigned)(signed char)((unsigned)(x0 >> 70) & g0)) << ((0xffffffffu << (0x26ca0361u & 31u)) & 31u));
            s1 = (int)((unsigned)s1 + 0x368bc512u);
            w0 ^= (unsigned long long)(unsigned)(9u < u1) << ((p2 & r0.x) & 63u);
            w0 ^= (unsigned long long)(unsigned)!(unsigned)(4u && garr[u2 & 7u]) << (((unsigned)((unsigned)w0 || i2) * (unsigned)(p1 == garr[u2 & 7u])) & 63u);
        }
        { unsigned t5; double z5; if ((0x3be08804u) & 1u) { t5 = 0u; z5 = (double)(((unsigned)((unsigned)b0 < (unsigned)(short)(0x7ac08501u * a0[i0 & 3u]))) & 255u); } if ((0x3be08804u) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            switch (((unsigned)(w0 >> 29) << ((g0 | 0x7fffffffu) & 31u)) & 7u) {
                h1 = (unsigned short)(h1 + (a0[u1 & 3u] ? 0x158b244eu : 3u));
                if ((unsigned)((short)i0 > (signed char)(unsigned)c0)) goto L2;
            }
            a0[r0.y & 3u] = (((6u * 0x80000000u) ^ (unsigned)(x0 >> 70)) / (p1 | 1u));
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)*mp >= (int)r0.y), i2, ((i2 << ((unsigned)(x0 >> 70) & 31u)) % ((unsigned)s0 | 1u))); }
            }
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(i0 || (i0 & p1)), ((unsigned)(w0 >> 29) % (u1 | 1u)), v0); }
                if (budget != 0u) { budget -= 1u; u0 = fn0((p0 << ((unsigned)(w0 >> 29) & 31u)), (unsigned)(((unsigned)e0 | 0u) < (unsigned)d0), ((v0 >> ((unsigned)d0 & 31u)) >> ((unsigned)w0 & 31u))); }
                if (budget != 0u) { budget -= 1u; u0 = fn1(((g1 % (i1 | 1u)) & v0), garr[u2 & 7u], (unsigned)f0); }
                goto L1;
                q0 = &garr[(unsigned)f0 & 7u];
                if ((unsigned)((int)((unsigned)c0 / (0x80000000u | 1u)) >= (int)garr[i1 & 7u])) break;
            }
        }
    }
    if (1u) {
        if (budget != 0u) { budget -= 1u; u3 = fn1(p1, (unsigned)((short)g0 > (signed char)fuel), (unsigned)(0x80000000u && (unsigned)f0)); }
    }
    switch (((unsigned)h0 ^ (unsigned)c1) & 7u) {
        garr[(6u * 0xffffffffu) & 7u] = (unsigned)(x0 >> 70);
        case 6u: ;
        if ((i0 << (u3 & 31u))) goto L2;
        i0 = r0.y & 15u;
        g1 += (0xc2da4e7fu - (p0 + 0x80000000u));
        if (g1) {
            if (fuel < 8u) return a0[i0 & 3u];
            if (((unsigned)x0 / ((4u & 0xad37ad7bu) | 1u))) {
                i0 = (unsigned)!(fuel / (4u | 1u)) & 15u;
                f0 = f0 * 0.5f + (float)(((8u & (unsigned)((unsigned)c0 == (unsigned)h0)) + (unsigned)((short)u0 > (signed char)(unsigned)(x0 >> 70))) & 255u);
                goto L0;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)(0x7fffffffu % (i1 | 1u)) >= (int)0xe71162bdu), (unsigned)((unsigned)x0 || p0), (*mp & (unsigned)(0x80000000u && 8u))); }
                if (u3 == 7u) return (unsigned)(~(0x80000000u & (unsigned)(short)((unsigned)x0 << ((unsigned)d0 & 31u))) < ((unsigned)d0 | 8u));
                r0.y ^= (((0x7cf9354eu | 0x2b3ec988u) + (unsigned)(u1 && 0x469da6f3u)) & (unsigned)d0);
            }
            default: ;
            case 3u: ;
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)((unsigned)(unsigned char)(a0[i0 & 3u] / (0x10000u | 1u)) ? (unsigned)f0 : (unsigned)e0) >= (int)5u);
            e0 = e0 * 0.5L + (long double)((unsigned)((int)i1 < (int)(unsigned)h0) & 1023u);
        }
    }
    s0 = (int)(unsigned)(0x1c721f7u && 1u);
    if (((unsigned)c0 | 0xee46bc37u)) goto L0;
    { unsigned t6; double z6; if (((0x330474e2u >> (((unsigned)h1 | (unsigned)f0) & 31u))) & 1u) { t6 = i0; z6 = (double)(((2u + ((unsigned)h0 - r0.x))) & 255u); } if (((0x330474e2u >> (((unsigned)h1 | (unsigned)f0) & 31u))) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        do { if (--fuel == 0u) goto done;
            c1 = (signed char)(6u >> ((unsigned)!(a0[u1 & 3u] ? 0x6b65e15bu : (unsigned)l0) & 31u));
        } while (i0++ < 6u && (unsigned)h1);
        m0 ^= (a0[i0 & 3u] ? ((unsigned)f0 - p0) : (garr[i1 & 7u] / (m0 | 1u)));
    }
    { unsigned t7; double z7; if ((u3) & 1u) { t7 = (unsigned)((short)0xffffffffu > (signed char)(unsigned)(unsigned char)(1u - u2)); z7 = (double)((3u) & 255u); } if ((u3) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
        while (i0++ < 5u && (0u / (fuel | 1u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1((0xb5872fd5u * (unsigned)h0), (unsigned)(short)(0x10000u << ((3u - 0x7fffffffu) & 31u)), (8u & (unsigned)(*q0 && a0[u1 & 3u]))); }
            c0 = (unsigned char)((u0 - i0) % (5u | 1u));
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)d0) break;
                l0 = (long)((unsigned long)l0 + (unsigned)((r0.y * garr[u2 & 7u]) && a0[i0 & 3u]));
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)(unsigned)(m0 == (garr[i1 & 7u] / (fuel | 1u))), ((unsigned)l0 / (i0 | 1u)), ((unsigned)((unsigned)d0 == 4u) * 4u)); }
                m0 ^= ((0x6fb8baf8u | (unsigned)l0) ^ (p0 + 0x33c005a2u));
                a0[g0 & 3u] = ((unsigned)s1 | (garr[u2 & 7u] % ((unsigned)c1 | 1u)));
            }
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((*q0 / ((unsigned)w0 | 1u)), (a0[u1 & 3u] % ((a0[i0 & 3u] % ((unsigned)(x0 >> 70) | 1u)) | 1u)), (unsigned)(short)(unsigned)((m0 - (unsigned)s0) || 0xe798b5f7u)); }
                while (i2++ < 5u && (*q0 % (garr[u2 & 7u] | 1u))) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)(*mp || (unsigned)(7u < 0u)));
                    if ((unsigned)((int)0x70faec00u < (int)4u)) break;
                }
                if ((unsigned)(2u && (unsigned)b0)) goto L3;
                f0 = f0 * 0.5f + (float)(~(unsigned)((short)(unsigned)((unsigned)(x0 >> 70) == 3u) > (signed char)0x80000000u) & 255u);
            }
            if ((0x5d3ef19au % ((unsigned)f0 | 1u))) break;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, 0xffffffffu, i2); }
        if (((unsigned)(0x35606a4cu == 0xb2b8b28fu) - (unsigned)(x0 >> 70))) goto L1;
        b0 = (unsigned)((u2 * (unsigned)c0) && (unsigned)((int)(unsigned)(0x7fffffffu || u2) >= (int)(unsigned)h0)) != 0u;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)w0 < (int)(unsigned)(signed char)((unsigned)s0 << (0x49c0d8bau & 31u)))) goto L3;
            if ((u0 * 0x48b5941cu)) {
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)((int)0x7fffffffu < (int)(unsigned)s0) || i2);
                h0 = (short)((unsigned)((int)0x80000000u < (int)0x9a64beafu) & 0x80000000u);
            } else {
                if ((0x7fffffffu + 0x7fffffffu)) break;
                if (((unsigned)l0 % ((unsigned)w0 | 1u))) {
                    f0 = f0 * 0.5f + (float)(((unsigned)(short)(garr[u2 & 7u] >> (6u & 31u)) >> (4u & 31u)) & 255u);
                    if ((unsigned)(short)((unsigned)(i0 || 0xe26bae0fu) ^ 0x9ba8d532u)) break;
                    do { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)((unsigned)((0xd1cb47e6u * p0) == 0xc2af8193u) & 1023u);
                        garr[((unsigned)(w0 >> 29) & (unsigned)s1) & 7u] = (unsigned)((unsigned)(signed char)((unsigned)l0 - p1) == (unsigned)(signed char)(i0 >> (1u & 31u)));
                        s0 = (int)(0x7fffffffu + (unsigned)f0);
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s1 >> (0x10000u & 31u)), (unsigned)(0xfc51749du < i0), 0xaadcd7afu); }
                        w0 = w0 * 6364136223846793005ull + (unsigned)((0x5d21b308u - (unsigned)((int)u1 < (int)fuel)) == 0x23333da5u);
                    } while (i1++ < 3u && (unsigned)(short)(unsigned)((int)(unsigned)w0 >= (int)p2));
                    *q0 = (0x14201bb8u ^ 0x747b46c0u);
                }
                m0 ^= (0x10000u * (unsigned)s0);
                u1 ^= (unsigned)((unsigned)s0 < (unsigned)(0x29b7a0e9u && (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)x0)));
            }
            if ((unsigned)((0x6fca5e0du << (0xffffffffu & 31u)) == (unsigned)b0)) break;
        } while (i0++ < 7u && (garr[i1 & 7u] & 0x21aec64au));
    }
    a0[(i2 - (unsigned)e0) & 3u] = (garr[u2 & 7u] + (unsigned)b0);
    switch ((u1 - 0x5f2fc5c8u) & 7u) {
        h0 = (short)(unsigned)d0;
    }
    s1 = (int)((unsigned)s1 + ((unsigned)((int)p2 >= (int)(unsigned)d0) / (((unsigned)e0 ? 0x45ca0d5au : 0x3ef3baa4u) | 1u)));
    if ((0x7fffffffu << (fuel & 31u))) goto L0;
    if ((unsigned)((int)9u >= (int)(unsigned)c0)) goto L1;
    if ((unsigned)(0xffffffffu == u2)) goto L3;
    if (budget != 0u) { budget -= 1u; u1 = fn0((u3 | 0x4377661bu), ~(unsigned)((unsigned)l0 || a0[i0 & 3u]), (u3 - 0xffffffffu)); }
    if (7u) goto L2;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(garr[u2 & 7u]);
        s1 = (int)((unsigned)s1 + (unsigned)(2u || (unsigned)(garr[i1 & 7u] < ((r0.y / (p1 | 1u)) * i2))));
        u3 += (unsigned)(r0.y == (unsigned)(9u || (unsigned)!((unsigned)h1 | i2)));
    }
    u0 ^= (unsigned)x0;
    if (-((unsigned)s0 * 0xffffffffu)) goto L2;
    while (((unsigned)b0 * u0)) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)(signed char)(unsigned)((int)(unsigned)w0 >= (int)(g1 << ((unsigned)h1 & 31u))));
        if ((unsigned)((int)3u >= (int)p2)) continue;
        while (i1++ < 3u && (0x80000000u + 0x80000000u)) { if (--fuel == 0u) goto done;
            switch (((unsigned)w0 >> (2u & 31u)) & 7u) {
                switch ((unsigned)(signed char)(g1 >> ((unsigned)(w0 >> 29) & 31u)) & 7u) {
                    while ((unsigned)((unsigned)s0 && 5u)) { if (--fuel == 0u) goto done;
                        u2 = p0;
                        if ((unsigned)((int)0xd223af44u < (int)p2)) {
                            if (garr[u2 & 7u]) goto L4;
                        }
                        case 1u: ;
                        if (g1) break;
                        v0 = (unsigned)((unsigned)((int)(unsigned)s1 < (int)(0xe8736099u % (0xf9fa8c42u | 1u))) == garr[i1 & 7u]);
                        e0 = e0 * 0.5L + (long double)((unsigned)(0xffffffffu && (unsigned)(0x80000000u == 0x8d4ad8eau)) & 1023u);
                    }
                    switch ((garr[u2 & 7u] + 0x46cfeb7u) & 7u) {
                        e0 = e0 * 0.5L + (long double)((unsigned)((6u ^ (unsigned)d0) && (*mp * (unsigned)w0)) & 1023u);
                        h0 = (short)(unsigned)((unsigned)((int)0x10000u >= (int)m0) && ~(unsigned)((int)0xffffffffu >= (int)0xa237f021u));
                        for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                            s0 = (int)(g0 & (m0 ? *mp : (unsigned)f0));
                            if ((7u % ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)garr[i1 & 7u]) | 1u))) goto L0;
                            c1 = (signed char)~((unsigned)(x0 >> 70) + (unsigned)((unsigned)f0 || i2));
                            h0 = (short)(unsigned)((unsigned)(x0 >> 70) && (1u << (garr[i1 & 7u] & 31u)));
                            u2 = u2 * 0x9e3779b1u + (unsigned)(short)(unsigned)(6u < (0x95a9e8b2u * (unsigned)e0));
                        }
                        if (budget != 0u) { budget -= 1u; u1 = fn0((0x44bf9082u * (unsigned)((short)(unsigned)h1 > (signed char)a0[i0 & 3u])), (g0 % ((6u | 1u) | 1u)), (unsigned)c1); }
                        case 5u: ;
                        f0 = f0 * 0.5f + (float)((unsigned)((int)0x7fffffffu < (int)u1) & 255u);
                    }
                    switch ((p0 & (unsigned)(x0 >> 70)) & 7u) {
                        r0.y ^= (unsigned)(g1 == (unsigned)(fuel == (unsigned)f0));
                        s0 = (int)(unsigned)((int)(unsigned)s1 < (int)((i0 / ((unsigned)c1 | 1u)) - m0));
                        if (budget != 0u) { budget -= 1u; u1 = fn0(u0, garr[i1 & 7u], (unsigned)((int)0xffffffffu >= (int)(0x7fffffffu - v0))); }
                        garr[(unsigned)(unsigned char)(unsigned)((short)3u > (signed char)p0) & 7u] = (unsigned)(~((i0 ? i2 : 0x7fffffffu) | 0x10000u) || u2);
                        m0 ^= -(((unsigned)d0 | a0[i0 & 3u]) * 0xb9425524u);
                    }
                    for (;;) { if (--fuel == 0u) goto done;
                        *q0 = (unsigned)(5u || (r0.x << (((unsigned)(unsigned char)(6u - 0x7fffffffu) >> (garr[u2 & 7u] & 31u)) & 31u)));
                        if ((unsigned)l0) continue;
                        case 6u: ;
                        w0 ^= (unsigned long long)(unsigned)(9u < 0xffffffffu) << ((unsigned)(unsigned char)(unsigned)((unsigned)((unsigned)h1 < (unsigned)(x0 >> 70)) && 0xffffffffu) & 63u);
                        w0 ^= (unsigned long long)p0 << ((((unsigned)((int)(unsigned)s1 >= (int)u0) ? 1u : (unsigned)h1) ^ 0xfbbeb86eu) & 63u);
                    }
                    while (i2++ < 2u && (m0 << (u0 & 31u))) { if (--fuel == 0u) goto done;
                        if ((0xffffffffu >> (0xd88b3001u & 31u))) goto L0;
                        c0 = (unsigned char)((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)(short)(unsigned)(0x10000u && (garr[u2 & 7u] ^ (unsigned)e0))) ^ (unsigned)d0);
                        m0 ^= (unsigned)((int)u1 >= (int)*q0);
                        if ((unsigned)(0xbc7070f6u || (unsigned)h1)) break;
                    }
                }
                if (((unsigned)((int)a0[i0 & 3u] < (int)0x2423060du) - 0x86320aa2u)) goto L1;
                if (((unsigned)c0 % ((0xadb3cc41u >> ((unsigned)w0 & 31u)) | 1u))) continue;
                q0 = &garr[((unsigned)(signed char)(unsigned)((int)garr[u2 & 7u] < (int)(unsigned)l0) % ((unsigned)d0 | 1u)) & 7u];
                case 3u: ;
            }
            v0 = ((0x7fffffffu >> (*mp & 31u)) ? (unsigned)f0 : (m0 - (unsigned)b0));
        }
        if ((unsigned)(g1 && (unsigned)f0)) {
            u3 ^= (p0 + ((u2 | 9u) - u3));
            if ((*q0 / ((unsigned)(*mp < 0x94f37e32u) | 1u))) goto done;
            if (0xffffffffu) break;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(u1 && 0x10000u), (unsigned)((g1 ^ 0x10000u) < 0x113f934u), ((p1 * u3) ^ (unsigned)(x0 >> 70))); }
        } else {
            h0 = (short)(unsigned)(i2 == (unsigned)(v0 && (unsigned)((int)m0 >= (int)u1)));
            s1 = (int)((unsigned)s1 + ((unsigned)(0x10000u && *q0) - 0x1503461cu));
            if (u3 == 7u) return (r0.x ^ (unsigned)(6u == (unsigned)(signed char)(0x5a9dd79fu * 0x3854fd87u)));
        }
        u3 += (unsigned)!((unsigned)((unsigned)(*q0 == u0) || (unsigned)f0) << ((unsigned)((int)0x6c4ad10u >= (int)0x75316590u) & 31u));
        if (0x9f8edc5eu) {
            c0 = (unsigned char)((unsigned)s0 & *q0);
            g1 += ((unsigned)((unsigned)((unsigned)s0 == u3) == 0x4b6b061eu) * (m0 - (unsigned)b0));
            switch (0x312fd1adu & 7u) {
                if ((unsigned)h1) {
                    s1 = (int)((unsigned)s1 + (0u >> ((unsigned)((int)(unsigned)s0 < (int)u1) & 31u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)g0 > (signed char)(u2 / (*mp | 1u))), (0x10000u << (u0 & 31u)), *q0); }
                    *mp = (~((unsigned)x0 | 0xf8a064b3u) * (unsigned)((int)u2 < (int)0x80000000u));
                }
            }
        }
    }
    if ((unsigned)((*mp * a0[u1 & 3u]) && (unsigned)e0)) goto L4;
    f0 = f0 * 0.5f + (float)((unsigned)w0 & 255u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u2 = fn2(i2, (((unsigned)x0 >> ((unsigned)h0 & 31u)) / ((unsigned)b0 | 1u)), ((0x80000000u << (0x75a2905au & 31u)) & 0x7fffffffu)); }
    g1 += (unsigned)(i1 && ~(~((unsigned)l0 - v0) << (0x7fffffffu & 31u)));
    goto done;
    while ((i1 | *mp)) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(u0 < m0), 0x80000000u, (unsigned)(u2 || 0xffffffffu)); }
        s0 = (int)(r0.y ? 0x80000000u : p2);
        q0 = &garr[(unsigned)!(unsigned)((int)0x50cb5001u >= (int)-(0xffffffffu * (unsigned)f0)) & 7u];
        do { if (--fuel == 0u) goto done;
            if (u3 == 7u) return (unsigned)((int)*mp < (int)m0);
            f0 = f0 * 0.5f + (float)((unsigned)((8u ^ g1) || (p1 - (unsigned)f0)) & 255u);
            d0 = d0 * 0.5 + (double)(((unsigned)((short)0x9f4c0618u > (signed char)r0.y) | v0) & 1023u);
            L0: if (--fuel == 0u) goto done;
            goto L1;
            { unsigned t0; double z0; if (((unsigned)(a0[i0 & 3u] < ~((unsigned)c1 ^ *mp))) & 1u) { t0 = 7u; z0 = (double)(((unsigned)b0) & 255u); } if (((unsigned)(a0[i0 & 3u] < ~((unsigned)c1 ^ *mp))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                L1: if (--fuel == 0u) goto done;
                L2: if (--fuel == 0u) goto done;
                if ((unsigned)(w0 >> 29)) continue;
                if (a0[i0 & 3u]) continue;
            }
        } while (i1++ < 3u && *mp);
    }
    if (budget != 0u) { budget -= 1u; u0 = fn2(((p2 + (unsigned)x0) & garr[u2 & 7u]), (unsigned)(x0 >> 70), (0xffffffffu - i2)); }
    q0 = &garr[(unsigned)d0 & 7u];
    u2 = u2 * 0x9e3779b1u + ((unsigned)(unsigned char)(0xe239cf2bu * 3u) % ((unsigned)(4u && u3) | 1u));
    if ((unsigned)((int)(unsigned)c0 >= (int)0xd1ee04ceu)) goto L4;
    while (i0++ < 4u && (unsigned)((int)0x80000000u >= (int)*q0)) { if (--fuel == 0u) goto done;
        *mp = (unsigned)(signed char)((unsigned)e0 ? u1 : g0);
        i0 = (unsigned)(7u && i0) & 15u;
    }
    do { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(0x699e0e16u & (unsigned)((int)0x10000u >= (int)garr[i1 & 7u]));
        m0 ^= (0x80000000u / ((unsigned)(7u || *mp) | 1u));
        if (fuel < 8u) return (((u2 >> ((unsigned)l0 & 31u)) << (v0 & 31u)) % ((unsigned)((int)0xffffffffu >= (int)i2) | 1u));
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)(unsigned char)(0x68b6afb7u >> (0x8334b3ceu & 31u)) << (((((unsigned)(w0 >> 29) ? 0x3d6708u : (unsigned)w0) / (u0 | 1u)) | 4u) & 63u);
        }
    } while (i0++ < 3u && i0);
    s0 = (int)(unsigned)c0;
    c0 = (unsigned char)(7u / ((7u * garr[u2 & 7u]) | 1u));
    switch ((unsigned)((int)(unsigned)c1 >= (int)(*q0 / (i0 | 1u))) & 7u) {
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)(u1 | m0)) {
                case 7u: ;
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(r0.x && g1)) break;
                }
                if ((unsigned)(signed char)((0xffffffffu | v0) >> (r0.y & 31u))) continue;
                *q0 += 0xffffffffu;
                switch ((unsigned)h1 & 7u) {
                    do { if (--fuel == 0u) goto done;
                        if (((unsigned)(x0 >> 70) << (0xfe47032au & 31u))) {
                            q0 = &garr[(unsigned)((int)((g1 ^ (unsigned)b0) - ((unsigned)(x0 >> 70) + p2)) >= (int)(unsigned)w0) & 7u];
                            case 0u: ;
                        } else {
                            if (budget != 0u) { budget -= 1u; u3 = fn2(*q0, a0[i0 & 3u], (a0[i0 & 3u] | (*q0 / ((unsigned)x0 | 1u)))); }
                        }
                        L3: if (--fuel == 0u) goto done;
                        c1 = (signed char)8u;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)d0, (unsigned)l0, garr[i1 & 7u]); }
                        L4: if (--fuel == 0u) goto done;
                    } while (i1++ < 4u && (unsigned)((short)*q0 > (signed char)3u));
                    r0.y ^= (v0 * (m0 * ((unsigned)h1 << ((6u & r0.x) & 31u))));
                    do { if (--fuel == 0u) goto done;
                        case 4u: ;
                        case 6u: ;
                        case 1u: ;
                    } while (i1++ < 4u && (unsigned)!(unsigned)((8u / (0x9f33a097u | 1u)) || u0));
                    h1 = (unsigned short)(h1 + (1u ? p2 : (u2 - 0x7fffffffu)));
                }
                break; (void)((unsigned)(8u || r0.y));
            }
            if (((unsigned)x0 + (unsigned)(0x4c89815au || (unsigned)l0))) continue;
            *q0 += (unsigned)((unsigned)((int)i1 >= (int)(((unsigned)c0 * p0) ^ 0x10000u)) || (unsigned)(x0 >> 70));
        } while (i0++ < 7u && (0x922301d6u - (unsigned)h1));
    }
    if ((unsigned)(((unsigned)b0 - (unsigned)e0) < p2)) goto L1;
    switch ((unsigned)s1 & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)h1, p2, (unsigned)(u3 && ((unsigned)e0 - u0))); }
    }
    if ((unsigned)s0) goto L1;
    goto L4;
    switch ((unsigned)((u2 | 0x7abd2b86u) && garr[u2 & 7u]) & 7u) {
        v0 = (((fuel - (unsigned)f0) * p0) / (4u | 1u));
        if (budget != 0u) { budget -= 1u; u0 = fn2((8u / (0xffffffffu | 1u)), ((unsigned)(unsigned char)(0xf0fe0bc8u & (unsigned)h0) - u2), (unsigned)((unsigned)(0x7fffffffu && a0[i0 & 3u]) && 0x10000u)); }
        if (~(1u & (unsigned)h0)) {
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)1u >= (int)(unsigned)(3u || 0xffffffffu)), (unsigned)(short)(unsigned)((short)1u > (signed char)p2), *q0); }
                break; (void)((garr[i1 & 7u] & (i2 % (u2 | 1u))));
                if (fuel < 8u) return ((unsigned)!(m0 + (unsigned)((int)(unsigned)c0 >= (int)*mp)) * garr[i1 & 7u]);
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 6u: ;
                    q0 = &garr[(unsigned)((short)(unsigned)h0 > (signed char)(unsigned)(((unsigned)(0x10000u || (unsigned)h1) << (fuel & 31u)) && (unsigned)e0)) & 7u];
                    r0.y ^= ~((unsigned)(0x78a07597u && i0) ^ garr[i1 & 7u]);
                }
                if (((unsigned)s0 ? 3u : 0xffffffffu)) goto L2;
            } while (i0++ < 2u && (fuel + *mp));
            l0 = (long)((unsigned long)l0 + (((unsigned)c0 % (u3 | 1u)) ^ p0));
            i2 = ((unsigned)((int)(unsigned)(r0.x || (unsigned)!(unsigned)((int)0xff55468au < (int)(unsigned)x0)) >= (int)(unsigned)e0) ^ p1) & 15u;
        } else {
            v0 = (unsigned)((int)(unsigned)c0 < (int)(unsigned)(p0 || (unsigned)(x0 >> 70)));
            u0 += (unsigned)((((unsigned)x0 * (unsigned)c1) >> ((unsigned)c0 & 31u)) == (unsigned)(2u && 0x7e990c98u));
            if ((garr[u2 & 7u] >> (fuel & 31u))) goto done;
        }
        case 1u: ;
        u2 += (unsigned)((int)m0 < (int)(unsigned)((unsigned)c0 < p2));
        s1 = (int)((unsigned)s1 + (0xffffffffu & (v0 & (i1 ? p2 : fuel))));
    }
    if (r0.x) goto L3;
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(i0 == 0xffffffffu));
        l0 = (long)((unsigned long)l0 + a0[u1 & 3u]);
        c0 = (unsigned char)((6u << (p0 & 31u)) & (unsigned)!(0x10000u << ((i2 / ((unsigned)b0 | 1u)) & 31u)));
        if ((unsigned)((unsigned)c0 || 0xb6e78967u)) goto L4;
    } while (i0++ < 2u && (4u ? garr[i1 & 7u] : (unsigned)b0));
    if (((unsigned)w0 >> (0x80000000u & 31u))) goto done;
    if ((p0 ^ 0xc296a227u)) goto L4;
    if (g1) goto L1;
    u1 += ~(unsigned)(a0[u1 & 3u] < ((unsigned)(p2 < (unsigned)b0) / ((i2 % (fuel | 1u)) | 1u)));
    if ((unsigned)((int)0x9c7449ecu < (int)i2)) {
        d0 = d0 * 0.5 + (double)(((unsigned)c1 / ((a0[i0 & 3u] / (*mp | 1u)) | 1u)) & 1023u);
        { unsigned t1; double z1; if ((g1) & 1u) { t1 = (0xaf24df56u >> ((unsigned)!((unsigned)h1 | 0x7fffffffu) & 31u)); z1 = (double)((fuel) & 255u); } if ((g1) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            switch (r0.x & 7u) {
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)((unsigned)s0 == (unsigned)(x0 >> 70)) < (int)(unsigned)s1);
            }
            goto L4;
            l0 = (long)((unsigned long)l0 + ((unsigned)c0 % (u2 | 1u)));
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                *mp = (u3 / (*mp | 1u));
            }
        }
        c1 = (signed char)(unsigned)((int)((g1 & u3) ? (unsigned)f0 : (unsigned)l0) >= (int)(unsigned)s1);
        s0 = (int)((unsigned)e0 * (unsigned)((unsigned)(i2 || p1) < (unsigned)f0));
    }
    if ((unsigned)(unsigned char)(unsigned)(0x322d8de5u == 0xbdec6aeau)) goto done;
    { unsigned t2; double z2; if ((0xffffffffu) & 1u) { t2 = ((unsigned)((int)a0[u1 & 3u] < (int)0xbbcf8ca0u) % (0x7fffffffu | 1u)); z2 = (double)((((0x10000u % ((unsigned)c1 | 1u)) ^ 0xffffffffu)) & 255u); } if ((0xffffffffu) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        if (g1) goto done;
        r0.y ^= (unsigned)(garr[i1 & 7u] || (-(i2 % (0x80000000u | 1u)) << ((0x80000000u << (v0 & 31u)) & 31u)));
        u1 = u1 * 0x9e3779b1u + 3u;
        e0 = e0 * 0.5L + (long double)(((0xb5990048u | i0) - (unsigned)(u2 || m0)) & 1023u);
        u2 += (unsigned)((short)(unsigned)(short)(unsigned)((unsigned)e0 < 0xffffffffu) > (signed char)0x7fffffffu);
        if (budget != 0u) { budget -= 1u; u1 = fn2(u1, (0x7b36e460u << ((unsigned)d0 & 31u)), (g1 & (unsigned)((unsigned)(x0 >> 70) || (unsigned)x0))); }
    }
    if ((unsigned)((short)(i1 + u3) > (signed char)i1)) goto L0;
    u3 += ((unsigned)(u0 || 0u) ^ (unsigned)!(7u << (((unsigned)s0 ^ p0) & 31u)));
    while (i0++ < 5u && (6u * (unsigned)f0)) { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (unsigned)((unsigned)e0 && (unsigned)l0);
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)0xffffffffu > (signed char)(unsigned)((int)0xffffffffu < (int)r0.y))) continue;
                garr[g0 & 7u] = ((p0 + a0[i0 & 3u]) % ((0x80000000u >> (0xc18faccdu & 31u)) | 1u));
                break; (void)((((unsigned)s0 - 4u) << (0x10000u & 31u)));
                h1 = (unsigned short)(h1 + (0x7f0ecee8u * 0x7562447cu));
            }
            u1 += u2;
            u0 = u0 * 0x9e3779b1u + (unsigned)((int)(0x2f928f05u & *q0) >= (int)((unsigned)((int)(unsigned)e0 < (int)m0) % (0x8d3926a9u | 1u)));
            break; (void)(u1);
            for (;;) { if (--fuel == 0u) goto done;
                u2 += ((unsigned)e0 % ((unsigned)((unsigned)l0 || g1) | 1u));
                v0 = ((*q0 ^ 0x80000000u) >> ((unsigned)((unsigned)x0 == a0[i0 & 3u]) & 31u));
                break; (void)(((unsigned)c1 ^ 3u));
                r0.y ^= (unsigned)((unsigned)f0 && v0);
            }
        }
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = (unsigned)((short)(unsigned)(signed char)(p1 >> (i2 & 31u)) > (signed char)(7u - 0x80000000u));
        do { if (--fuel == 0u) goto done;
            switch (u0 & 7u) {
                if (u3) continue;
                garr[(unsigned)(a0[u1 & 3u] && a0[i0 & 3u]) & 7u] = (unsigned)s0;
                x0 = x0 * 0x100000001b3ull + ((unsigned)(p0 == (unsigned)e0) % ((unsigned)(x0 >> 70) | 1u));
                case 5u: ;
                if (((unsigned)s0 ^ -(unsigned)(0xffffffffu < 8u))) continue;
            }
        } while (i1++ < 3u && (u0 - u1));
    }
    if ((unsigned)f0) {
        *q0 += (0xfdd3f688u / ((m0 | 0x5d783746u) | 1u));
        if ((unsigned)(signed char)(m0 ^ (unsigned)(7u < 0x27d0e48bu))) goto L1;
        if (((unsigned)c0 % ((unsigned)w0 | 1u))) goto L3;
        r0.y ^= (unsigned)((short)(7u + (3u % (g1 | 1u))) > (signed char)4u);
    } else {
        if ((0x95cbbe1u >> (r0.x & 31u))) goto done;
        do { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)(u2 & 255u);
            if ((unsigned)!(unsigned)((unsigned)c1 || 0x845afbacu)) goto L0;
            if ((unsigned)e0) {
                if (p0) {
                    d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)w0 < (int)0x7fffffffu) & 1023u);
                    while ((unsigned)((0xf1a66dfeu * (unsigned)l0) < 0x7fffffffu)) { if (--fuel == 0u) goto done;
                        h0 = (short)(unsigned)(unsigned char)(unsigned)((short)(unsigned)((int)fuel >= (int)0x28374197u) > (signed char)6u);
                        if (((unsigned)e0 & p0)) continue;
                    }
                    c1 = (signed char)-((unsigned)((short)p0 > (signed char)(unsigned)(p1 && 0x32f71efbu)) / (0x944ce1f3u | 1u));
                    *mp = (unsigned)((int)0x10000u >= (int)(unsigned)(unsigned char)(unsigned)((unsigned)((int)fuel < (int)(unsigned)e0) || (m0 + (unsigned)h1)));
                    w0 = w0 * 6364136223846793005ull + (r0.x - (unsigned)((short)(unsigned)((short)7u > (signed char)(unsigned)(x0 >> 70)) > (signed char)0x55650e4du));
                } else {
                    continue; (void)(0x7fffffffu);
                    if (0x80000000u) break;
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                            continue; (void)(((unsigned)f0 - p1));
                            if (fuel < 8u) return (unsigned)s0;
                            d0 = d0 * 0.5 + (double)((unsigned)((short)((unsigned)(g1 == 0x3fea6a32u) * u2) > (signed char)(unsigned)((int)i2 < (int)(unsigned)h0)) & 1023u);
                            v0 = 4u;
                            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(u1 << ((0xffffffffu / (fuel | 1u)) & 31u));
                            r0.x = (unsigned)f0;
                        }
                        break; (void)((unsigned)(i0 < (unsigned)!((unsigned)b0 >> (0x7fffffffu & 31u))));
                    }
                    d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)h1 < (int)g0) & 1023u);
                }
                if (g0) break;
                if (i0) break;
                if ((unsigned)(a0[i0 & 3u] < ((unsigned)s1 % (0xffffffffu | 1u)))) {
                    if (0x10000u) break;
                    if ((4u + 0x7fffffffu)) break;
                    v0 = 0xf11b2f86u;
                    if (0x10000u) break;
                    s0 = (int)(unsigned)((short)(8u - ((unsigned)h0 * (unsigned)h1)) > (signed char)7u);
                } else {
                    u0 += (unsigned)h1;
                    u0 ^= (unsigned)((int)(unsigned)x0 < (int)a0[i0 & 3u]);
                }
                h0 = (short)(g1 ? p2 : (unsigned)c0);
                if ((unsigned)(1u || (unsigned)c1)) {
                    m0 ^= (unsigned)(*q0 < (unsigned)((int)p0 >= (int)(unsigned)s0));
                    if (u3 == 7u) return (unsigned)w0;
                    f0 = f0 * 0.5f + (float)(~((((unsigned)s1 / (0x8b7902dbu | 1u)) * (*q0 ^ 5u)) % (0x10000u | 1u)) & 255u);
                    continue; (void)((unsigned)(4u && v0));
                }
            } else {
                do { if (--fuel == 0u) goto done;
                    garr[(unsigned)(short)(unsigned)((short)r0.y > (signed char)i0) & 7u] = (unsigned)(((unsigned)(short)(6u - (unsigned)e0) ^ fuel) || 4u);
                } while (i1++ < 7u && (0xffffffffu % ((unsigned)(u2 || (unsigned)c1) | 1u)));
                if ((0x936b3c90u | 0x6549902eu)) goto L0;
                while (garr[u2 & 7u]) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)((unsigned)d0 + u1) << (((unsigned)s0 - r0.y) & 63u);
                    l0 = (long)((unsigned long)l0 + (unsigned)h1);
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(((unsigned)s1 | v0) < (unsigned)f0), 0xffffffffu, (7u - (unsigned)(g0 < g1))); }
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        continue; (void)(((unsigned)b0 / (i1 | 1u)));
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)((1u >> ((unsigned)w0 & 31u)) | p2), (unsigned)((int)(g1 * 9u) < (int)(unsigned)d0), -((unsigned)(2u || (unsigned)d0) / (p0 | 1u))); }
                        if ((unsigned)!(0xffffffffu | p1)) break;
                        if (0xffffffffu) continue;
                    }
                    { unsigned t3; double z3; if (((unsigned)(short)(0x10000u * (a0[i0 & 3u] % ((unsigned)b0 | 1u)))) & 1u) { t3 = a0[u1 & 3u]; z3 = (double)(((unsigned)(fuel == p2)) & 255u); } if (((unsigned)(short)(0x10000u * (a0[i0 & 3u] % ((unsigned)b0 | 1u)))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        h0 = (short)~((unsigned)(short)(r0.x * 0x80000000u) / (0xb69badd2u | 1u));
                        if (((unsigned)((int)(unsigned)w0 < (int)0x7fffffffu) / (garr[u2 & 7u] | 1u))) break;
                        c1 = (signed char)(unsigned)((short)0xddb592a9u > (signed char)(unsigned)s1);
                        r0.x = (unsigned)(0xffffffffu < (unsigned)((int)(v0 / ((unsigned)!(0u & g1) | 1u)) < (int)0u));
                        g1 += ((unsigned)l0 >> (0x65ab979au & 31u));
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn2((i2 ^ 0x6e529573u), (unsigned)w0, (unsigned)((int)i1 >= (int)(unsigned)((int)0x1130ab64u >= (int)*q0))); }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(1u < 0xffffffffu), u1, (unsigned)((short)(unsigned)(5u && (unsigned)w0) > (signed char)(unsigned)c0)); }
            }
            i0 = (((unsigned)s1 << (garr[i1 & 7u] & 31u)) ? (unsigned)c1 : 0x6a4cc5ddu) & 15u;
            l0 = (long)((unsigned long)l0 + ((unsigned)(w0 >> 29) % ((unsigned)f0 | 1u)));
        } while (i0++ < 7u && ((0xdd59d274u - r0.x) ^ (unsigned)l0));
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            *mp = (unsigned)((int)0x10000u >= (int)(5u * 0x21558bb8u));
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)3u >= (int)0x7fffffffu), -(9u & a0[u1 & 3u]), 0x80000000u); }
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t4; double z4; if (((unsigned)((int)(unsigned)s1 >= (int)((unsigned)b0 + p1))) & 1u) { t4 = (unsigned)((unsigned)b0 && (0x80000000u << (0x2dee5ed7u & 31u))); z4 = (double)(((unsigned)l0) & 255u); } if (((unsigned)((int)(unsigned)s1 >= (int)((unsigned)b0 + p1))) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                    if (fuel) break;
                    if ((unsigned)f0) break;
                    continue; (void)((unsigned)(0xe1bde82fu < (unsigned)x0));
                    goto L2;
                }
                if ((unsigned)(v0 && (unsigned)d0)) {
                    a0[0xffffffffu & 3u] = ((*q0 ^ (0x7fffffffu & (unsigned)x0)) & 0x7fffffffu);
                    f0 = f0 * 0.5f + (float)(((unsigned)((short)g1 > (signed char)(garr[i1 & 7u] & 0x7a5f17d2u)) * ((unsigned)s0 * i2)) & 255u);
                    *mp = ((unsigned)b0 % (0xde1227abu | 1u));
                    if (((unsigned)s0 | (unsigned)(w0 >> 29))) break;
                    m0 ^= (unsigned)!((unsigned)((int)(unsigned)h1 < (int)r0.y) - ((unsigned)f0 | (unsigned)(x0 >> 70)));
                    if ((unsigned)s0) break;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0(0x83914eecu, (unsigned)(p1 && (unsigned)(w0 >> 29)), (((unsigned)x0 ^ (unsigned)f0) + 9u)); }
                break; (void)(((unsigned)(w0 >> 29) + m0));
                s1 = (int)((unsigned)s1 + (unsigned)(0x80000000u && (unsigned)d0));
                *q0 = (unsigned)((0x33e39f02u / (g0 | 1u)) < u0);
            }
        }
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((g1 << ((unsigned)(m0 == (unsigned)c1) & 31u))) break;
        do { if (--fuel == 0u) goto done;
            if (u2) break;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((3u << (0x740444a7u & 31u))) break;
            }
            if ((unsigned)!(unsigned)((unsigned)(w0 >> 29) && (unsigned)(w0 >> 29))) {
                r0.x = (p0 / ((unsigned)((int)g0 < (int)(r0.y & u2)) | 1u));
                { unsigned t5; double z5; if ((((unsigned)(signed char)(unsigned)(p0 && 0xffffffffu) >> ((unsigned)(w0 >> 29) & 31u))) & 1u) { t5 = (unsigned)(m0 || (unsigned)h0); z5 = (double)(((unsigned)x0) & 255u); } if ((((unsigned)(signed char)(unsigned)(p0 && 0xffffffffu) >> ((unsigned)(w0 >> 29) & 31u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    if (u1) break;
                }
            } else {
                if ((0xb6b26b24u % ((unsigned)c1 | 1u))) break;
                break; (void)((4u & (unsigned)((unsigned)c0 && p1)));
                break; (void)((unsigned)s0);
            }
            for (;;) { if (--fuel == 0u) goto done;
                switch ((unsigned)((short)(unsigned)c1 > (signed char)(unsigned)(w0 >> 29)) & 7u) {
                    a0[(garr[u2 & 7u] + (unsigned)s1) & 3u] = (unsigned)((short)u0 > (signed char)(unsigned)s0);
                    if (((unsigned)w0 - (p1 >> (0x7fffffffu & 31u)))) {
                        if (a0[u1 & 3u]) goto L2;
                        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                            q0 = &garr[(0x7fffffffu / (u3 | 1u)) & 7u];
                            r0.x = 1u;
                            b0 = fuel != 0u;
                        }
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)v0 > (signed char)(unsigned)f0), (unsigned)(*q0 || a0[i0 & 3u]), (unsigned)h0); }
                        r0.x = (unsigned)(short)(unsigned)(g0 || 5u);
                    }
                }
                r0.y ^= (u3 / ((unsigned)f0 | 1u));
                g1 += (0x7fffffffu | (0xced39dc8u + garr[u2 & 7u]));
            }
            break; (void)((g1 | (u2 & 0x65077307u)));
        } while (i1++ < 7u && (unsigned)c1);
        u2 += v0;
        s1 = (int)((unsigned)s1 + (8u % (a0[i0 & 3u] | 1u)));
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)c1, (unsigned)((int)i1 < (int)r0.x), ((unsigned)s1 / (a0[i0 & 3u] | 1u))); }
        while ((unsigned)((a0[u1 & 3u] / (5u | 1u)) && garr[u2 & 7u])) { if (--fuel == 0u) goto done;
            g1 += (unsigned)(p0 < 1u);
            garr[((unsigned)(x0 >> 70) * i1) & 7u] = ((unsigned)(unsigned char)(p0 ^ 0xc5add0b5u) ^ (unsigned)((int)9u >= (int)(unsigned)(9u || fuel)));
            break; (void)(i0);
            continue; (void)((unsigned)((g0 / (g0 | 1u)) && p1));
            x0 = x0 * 0x100000001b3ull + (unsigned)(short)(unsigned)(u0 || (p0 + 0x80000000u));
        }
    }
    d0 = d0 * 0.5 + (double)(((unsigned)(x0 >> 70) / (-((a0[u1 & 3u] ^ u0) / (u1 | 1u)) | 1u)) & 1023u);
    u1 ^= 8u;
    v0 = (unsigned)((int)p2 >= (int)(unsigned)((unsigned)!(r0.x % ((unsigned)!(unsigned)((unsigned)l0 == i2) | 1u)) == 0x80000000u));
    do { if (--fuel == 0u) goto done;
        u1 = u1 * 0x9e3779b1u + (unsigned)((int)(0x9dd53251u ^ 9u) >= (int)((unsigned)c0 ^ (unsigned)(x0 >> 70)));
        if ((unsigned)((int)(unsigned)(x0 >> 70) < (int)(v0 ^ (unsigned)d0))) goto L0;
        b0 = (unsigned)(0x80c9952eu < a0[i0 & 3u]) != 0u;
    } while (i0++ < 6u && (unsigned)((0x5a36bb7eu / (u0 | 1u)) && 0xcf66ccc8u));
    if ((0x7fffffffu / ((unsigned)(unsigned char)(i1 << ((unsigned)c0 & 31u)) | 1u))) goto L4;
    goto L0;
    if (6u) goto L0;
    if (((garr[u2 & 7u] ^ u3) << ((unsigned)(w0 >> 29) & 31u))) {
        if (fuel) goto L0;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((i0 << (4u & 31u)), (unsigned)((unsigned)h0 < 8u), (*mp >> (r0.y & 31u))); }
    d0 = d0 * 0.5 + (double)(((unsigned)(garr[u2 & 7u] == r0.x) * (9u % (p0 | 1u))) & 1023u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)*mp < (int)v0)) continue;
        }
        if (u3) break;
    }
    f0 = f0 * 0.5f + (float)((unsigned)!(unsigned)((v0 ^ (unsigned)(x0 >> 70)) == (2u / ((unsigned)(u2 < 0x3d7e6562u) | 1u))) & 255u);
    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(short)(r0.y & (unsigned)c1), (u3 / (u1 | 1u)), ((u3 % (0x7fffffffu | 1u)) >> (0xd9b1d955u & 31u))); }
    do { if (--fuel == 0u) goto done;
        garr[p1 & 7u] = (unsigned)((short)(3u >> (3u & 31u)) > (signed char)0xffffffffu);
        goto L1;
    } while (i0++ < 6u && (fuel % (fuel | 1u)));
    r0.x = (unsigned)(u1 < ((unsigned)x0 * (unsigned)h0));
    goto L3;
    *mp = (unsigned)(unsigned char)(i1 & 4u);
    *mp = (unsigned)(((unsigned)f0 & r0.x) == ((9u << (i0 & 31u)) * (unsigned)l0));
    { unsigned t0; double z0; if (((unsigned)((int)v0 < (int)(a0[i0 & 3u] << (0xdd77126fu & 31u)))) & 1u) { t0 = g0; z0 = (double)((0u) & 255u); } if (((unsigned)((int)v0 < (int)(a0[i0 & 3u] << (0xdd77126fu & 31u)))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        if ((unsigned)e0) goto L2;
    }
    { unsigned t1; double z1; if ((((unsigned)(signed char)(unsigned)(0x10000u == *mp) * u3)) & 1u) { t1 = -(5u >> (u2 & 31u)); z1 = (double)(((unsigned)((short)(unsigned)w0 > (signed char)(unsigned)((int)0xffffffffu >= (int)i1))) & 255u); } if ((((unsigned)(signed char)(unsigned)(0x10000u == *mp) * u3)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        if (fuel < 8u) return (2u * (unsigned)s1);
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)3u < (int)(unsigned)(g1 == (unsigned)e0)), (0x7fffffffu << ((unsigned)c0 & 31u)), (u0 % (v0 | 1u))); }
        if (budget != 0u) { budget -= 1u; u0 = fn1((g0 + (u0 & i2)), (unsigned)(signed char)(unsigned)((int)garr[u2 & 7u] < (int)(unsigned)l0), (a0[i0 & 3u] >> (g0 & 31u))); }
    }
    if ((r0.x * u0)) {
        goto L2;
        i0 = 0x80000000u & 15u;
        v0 = (unsigned)((unsigned)((unsigned)e0 && 0u) == 0x80000000u);
        if ((u2 * 0x110e1b52u)) goto L3;
        if ((unsigned)((int)0xab075e48u < (int)(*mp * 0x1012473eu))) goto L0;
        r0.x = (((unsigned)((short)(unsigned)(short)(0xc6d4994eu / (i0 | 1u)) > (signed char)*q0) & r0.x) & garr[u2 & 7u]);
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)b0, (unsigned)w0, ((unsigned)(i0 < g0) * (unsigned)c0)); }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            r0.y ^= ((unsigned)(unsigned char)(g1 - ((unsigned)h1 | 0xcdf66ad9u)) + 0xd8fc3f78u);
        } while (i1++ < 5u && (6u << (((unsigned)(x0 >> 70) * (unsigned)s1) & 31u)));
        break; (void)(p0);
    }
    L0: if (--fuel == 0u) goto done;
    x0 = x0 * 0x100000001b3ull + (*q0 % (g0 | 1u));
    L1: if (--fuel == 0u) goto done;
    d0 = d0 * 0.5 + (double)((((unsigned)((int)garr[u2 & 7u] >= (int)g0) % (0x7fffffffu | 1u)) % (-(i2 + garr[i1 & 7u]) | 1u)) & 1023u);
    h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(unsigned)((short)0x3cbd8412u > (signed char)(unsigned)((short)a0[u1 & 3u] > (signed char)(i0 | 0x77aa0fbau))));
    L2: if (--fuel == 0u) goto done;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = a0[u1 & 3u];
    }
    if ((unsigned)(0x10000u == (unsigned)s0)) goto done;
    switch ((unsigned)s1 & 7u) {
        while (i0++ < 7u && ((unsigned)(2u == 6u) - 7u)) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((0xffffffffu + (unsigned)f0) & 1023u);
                r0.y ^= (unsigned)((short)(unsigned)s1 > (signed char)0xf9d707f9u);
                switch ((u1 * (unsigned)c0) & 7u) {
                    a0[(unsigned)((int)(unsigned)e0 >= (int)0u) & 3u] = 0x6b2a7d15u;
                    L3: if (--fuel == 0u) goto done;
                }
                case 7u: ;
                u0 ^= (unsigned)(short)(unsigned)((short)(p1 ^ garr[u2 & 7u]) > (signed char)a0[u1 & 3u]);
            } while (i1++ < 7u && ((unsigned)l0 & (a0[i0 & 3u] >> (*mp & 31u))));
            if ((unsigned)(garr[i1 & 7u] < (unsigned)!(r0.x << (9u & 31u)))) continue;
            case 4u: ;
            u0 ^= (u3 / ((unsigned)(short)(unsigned)(i1 < u1) | 1u));
            if (0x7fffffffu) goto L2;
        }
        if (((unsigned)l0 / (m0 | 1u))) {
            w0 ^= (unsigned long long)(u3 + (unsigned)l0) << (2u & 63u);
            { unsigned t2; double z2; if (((u2 * 0x10000u)) & 1u) { t2 = (0x10000u >> (7u & 31u)); z2 = (double)((garr[i1 & 7u]) & 255u); } if (((u2 * 0x10000u)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)(unsigned)(*q0 && (unsigned)w0), (unsigned)(0x80000000u < (unsigned)c1), (0xffffffffu - (unsigned)((short)(unsigned)h0 > (signed char)(unsigned)h1))); }
            }
            if ((unsigned)((unsigned)!((unsigned)d0 << (r0.y & 31u)) < a0[i0 & 3u])) goto L0;
            L4: if (--fuel == 0u) goto done;
        } else {
            u1 = (unsigned)(p0 && (unsigned)e0);
            f0 = f0 * 0.5f + (float)((unsigned)(garr[u2 & 7u] < (0x80000000u + (unsigned)((unsigned)(x0 >> 70) && 8u))) & 255u);
        }
        if ((unsigned)((u3 << (i1 & 31u)) == 0xb6bddd13u)) {
            if (garr[u2 & 7u]) break;
            g1 += ((unsigned)((short)2u > (signed char)(p2 >> (0x44497e7bu & 31u))) % (fuel | 1u));
            case 1u: ;
            r0.y ^= (g1 ? (unsigned)s0 : p1);
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 5u, 0x2e5c9260u, 0x36d20da0u },
        { 11u, 0xbce70d24u, 0x380cdb89u },
        { 4u, 0xda7b9c47u, 0x207538adu },
        { 15u, 0x643230bau, 0x2ec88c01u },
        { 2u, 0x3341fdb3u, 0x6ce1f888u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
