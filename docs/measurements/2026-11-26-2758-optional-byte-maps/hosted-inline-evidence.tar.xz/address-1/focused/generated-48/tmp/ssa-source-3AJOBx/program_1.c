// test-ssa-source's program of seed 134000403 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x7ec6f9fau, g1 = 0x217ce058u;
static unsigned garr[8] = { 0xcd8e566u, 0xcdc36cbdu, 0xf9b274dau, 0x3ea533abu, 0xfaf1e578u, 0x3706d05au, 0x8ce0dc1cu, 0x7a88b649u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    f0 = f0 * 0.5f + (float)((0x28e95bb7u / ((unsigned)f0 | 1u)) & 255u);
    if (0x69e51926u) {
        r0.x = ((unsigned)((v0 * 0x1afd8270u) && g1) << ((unsigned)(p2 || r0.x) & 31u));
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + a0[u1 & 3u]);
            if (3u) break;
            if ((unsigned)c1) break;
        }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(signed char)(unsigned)((unsigned)e0 && (unsigned)(signed char)(unsigned)((unsigned)d0 && 0x7fffffffu)));
                if (-(4u ^ 0xe0eb42du)) goto L2;
                goto L3;
                break; (void)(m0);
            }
            { unsigned t0; double z0; if (((unsigned)(signed char)((unsigned)(u1 < 0x80000000u) * (unsigned)l0)) & 1u) { t0 = -(unsigned)(i2 < (unsigned)b0); z0 = (double)(((u1 ^ 0xee9b9283u)) & 255u); } if (((unsigned)(signed char)((unsigned)(u1 < 0x80000000u) * (unsigned)l0)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                L0: if (--fuel == 0u) goto done;
                continue; (void)((unsigned)((int)(unsigned)c1 >= (int)(unsigned)h1));
            }
        }
    } else {
        L1: if (--fuel == 0u) goto done;
    }
    a0[((unsigned)e0 / (*q0 | 1u)) & 3u] = (unsigned)((short)((unsigned)h1 >> ((unsigned)w0 & 31u)) > (signed char)(unsigned)c1);
    if ((unsigned)c0) {
        m0 ^= ((unsigned)((short)(0xf9fe0f3bu | 0xf9aba0a9u) > (signed char)(unsigned)(x0 >> 70)) + (unsigned)(i1 == 2u));
        if ((u1 - 3u)) goto L2;
    }
    L2: if (--fuel == 0u) goto done;
    goto L1;
    l0 = (long)((unsigned long)l0 + ((0xffffffffu & 0x6df96b1fu) ^ (1u * fuel)));
    L3: if (--fuel == 0u) goto done;
    if ((unsigned)(x0 >> 70)) {
        u3 += (unsigned)(short)(unsigned)((short)fuel > (signed char)(unsigned)((short)fuel > (signed char)(unsigned)s1));
        if (~((unsigned)h1 | (0xb26baf1cu & 0x41741542u))) goto L1;
        switch ((unsigned)((int)u0 >= (int)0x10000u) & 7u) {
            goto L0;
        }
        u0 += (unsigned)(unsigned char)(unsigned)(3u && (unsigned)s1);
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        L4: if (--fuel == 0u) goto done;
        g0 = (unsigned)(signed char)(unsigned)((unsigned)(0x7fffffffu == u3) == i1);
        g0 = (unsigned)((int)i1 < (int)(g0 & 4u));
        x0 = x0 * 0x100000001b3ull + ((unsigned)(((unsigned)b0 - (unsigned)l0) == (unsigned)((unsigned)s0 == (unsigned)c0)) * p0);
        { unsigned t1; double z1; if ((u1) & 1u) { t1 = (unsigned)(p1 || p0); z1 = (double)(((unsigned)((int)0x5b3e7416u >= (int)(unsigned)e0)) & 255u); } if ((u1) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            if ((v0 & (unsigned)s0)) {
                l0 = (long)((unsigned long)l0 + (0x80000000u | ((unsigned)h1 >> (~(u3 ? a0[i0 & 3u] : (unsigned)s1) & 31u))));
                do { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((unsigned)((int)(0x80000000u + g1) >= (int)(unsigned)(*mp == 0x4b2bb677u)) & 1023u);
                } while (i1++ < 7u && 5u);
                d0 = d0 * 0.5 + (double)(-(((unsigned)(signed char)(i2 ? 0xd04c4f2du : 4u) | 0xffffffffu) ^ (unsigned)c1) & 1023u);
                break; (void)((unsigned)(a0[i0 & 3u] || ((unsigned)h0 << (1u & 31u))));
                if ((unsigned)b0) {
                    do { if (--fuel == 0u) goto done;
                        if (((0x9caddc19u & (unsigned)h0) * p2)) continue;
                        for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                            if (r0.x) break;
                            if (m0) goto done;
                        }
                        if ((unsigned)(signed char)(unsigned)((short)(unsigned)l0 > (signed char)-(0x7bb0fe8au ^ u2))) break;
                        if ((4u * (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)(x0 >> 70)))) goto L2;
                        garr[(unsigned)(0x7fffffffu < a0[u1 & 3u]) & 7u] = (unsigned)d0;
                    } while (i1++ < 7u && (unsigned)((int)(unsigned)f0 >= (int)(unsigned)x0));
                    h1 = (unsigned short)(h1 + (0x27c5a3deu % (((u1 + 0x10000u) >> (0x80000000u & 31u)) | 1u)));
                    break; (void)(0xffffffffu);
                    if (((unsigned)((int)r0.x >= (int)(unsigned)(x0 >> 70)) ^ v0)) {
                        r0.y ^= (0x80000000u + v0);
                        if ((unsigned)(x0 >> 70)) {
                            a0[(a0[i0 & 3u] - v0) & 3u] = (p2 - ((0x80000000u >> (u3 & 31u)) << (-((unsigned)c1 / (i1 | 1u)) & 31u)));
                            v0 = (unsigned)(signed char)(a0[u1 & 3u] ? (unsigned)(p0 < r0.x) : ((unsigned)c0 - (unsigned)l0));
                            if ((p2 / (i2 | 1u))) continue;
                            i2 = (unsigned)(signed char)((unsigned)(short)((u0 ^ (0x7ff888b5u ^ *q0)) + 0x7fffffffu) & 0x10000u) & 15u;
                            g0 = (unsigned)(g1 && (unsigned)(short)(u1 * p2));
                        }
                        if ((unsigned)((int)g0 < (int)(unsigned)(unsigned char)(unsigned)((int)4u < (int)r0.x))) {
                            if ((unsigned)((unsigned)c1 && (u0 / (p2 | 1u)))) break;
                            u0 ^= (unsigned)((int)((g0 ^ (unsigned)c1) - a0[u1 & 3u]) >= (int)u1);
                        }
                        break; (void)((unsigned)((int)1u < (int)u3));
                        c1 = (signed char)(3u % (p0 | 1u));
                        b0 = (unsigned)(unsigned char)((a0[i0 & 3u] % (0x7fffffffu | 1u)) | 8u) != 0u;
                    }
                    f0 = f0 * 0.5f + (float)((unsigned)(6u && 1u) & 255u);
                }
                { unsigned t2; double z2; if (((0x10000u - (unsigned)f0)) & 1u) { t2 = 0x715f4c4eu; z2 = (double)(((5u * ((unsigned)x0 >> (p2 & 31u)))) & 255u); } if (((0x10000u - (unsigned)f0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    if ((6u % (((unsigned)x0 - (unsigned)s0) | 1u))) break;
                    if (((unsigned)s0 | u2)) break;
                    b0 = ((unsigned)(0xea6e972bu < g1) + (unsigned)(0x7fffffffu < fuel)) != 0u;
                }
            }
            break; (void)(p2);
            if (((unsigned)h1 >> (4u & 31u))) {
                if ((0x7fffffffu * garr[i1 & 7u])) {
                    m0 ^= (unsigned)(signed char)(unsigned)((int)0x7fffffffu < (int)(g0 ? m0 : u0));
                    s0 = (int)((r0.y - 0x4324dcd5u) / ((unsigned)l0 | 1u));
                } else {
                    f0 = f0 * 0.5f + (float)((unsigned)!((unsigned)c0 / ((unsigned)((int)(unsigned)((int)(unsigned)h0 < (int)0x80000000u) >= (int)p2) | 1u)) & 255u);
                    for (;;) { if (--fuel == 0u) goto done;
                        if (((r0.y << (garr[u2 & 7u] & 31u)) | (unsigned)d0)) break;
                        r0.y ^= (((unsigned)((int)p2 < (int)fuel) ^ (r0.y ^ *q0)) | m0);
                        g1 += (unsigned)((0x772b5b16u << ((u2 + *mp) & 31u)) < (unsigned)c1);
                        w0 ^= (unsigned long long)(unsigned)l0 << ((unsigned)(u3 == i2) & 63u);
                        if ((garr[i1 & 7u] | (unsigned)((short)garr[u2 & 7u] > (signed char)r0.y))) break;
                        e0 = e0 * 0.5L + (long double)(((unsigned)!((unsigned)((short)0u > (signed char)0x98e86fa1u) * a0[i0 & 3u]) | ((unsigned)w0 ^ (unsigned)w0)) & 1023u);
                    }
                    if (0xe0e0e71cu) break;
                    u1 = (unsigned)b0;
                }
                g1 += (unsigned)(3u || 0xa1e7dca9u);
                c0 = (unsigned char)(a0[u1 & 3u] * (unsigned)e0);
                c1 = (signed char)(r0.y % (garr[u2 & 7u] | 1u));
            } else {
                goto L4;
                if ((0x6b9ff156u % (7u | 1u))) continue;
                if (u3 == 7u) return ((unsigned)s1 * (8u - i0));
            }
        }
    }
    g1 += 0u;
    goto done;
    i0 = (unsigned)(signed char)(unsigned)((unsigned)((unsigned)x0 && u1) || (u2 - (unsigned)e0)) & 15u;
    if (*mp) goto L4;
    if (p1) goto L0;
    do { if (--fuel == 0u) goto done;
        u3 += (u2 / ((unsigned)((short)a0[i0 & 3u] > (signed char)garr[u2 & 7u]) | 1u));
        break; (void)(5u);
        { unsigned t3; double z3; if (((unsigned)(0x80000000u || 0x80000000u)) & 1u) { t3 = (p0 + (unsigned)s0); z3 = (double)((((unsigned)h0 ^ (unsigned)(w0 >> 29))) & 255u); } if (((unsigned)(0x80000000u || 0x80000000u)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            break; (void)((0x521c2732u + 0x2bd49b5cu));
            { unsigned t4; double z4; if (((unsigned)c0) & 1u) { t4 = (i0 >> ((unsigned)e0 & 31u)); z4 = (double)((i0) & 255u); } if (((unsigned)c0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                if (1u) {
                    g0 = ((unsigned)d0 << ((unsigned)b0 & 31u));
                    break; (void)(0xd96170eeu);
                    if (((u3 + (unsigned)(w0 >> 29)) * 0xffffffffu)) break;
                    w0 = w0 * 6364136223846793005ull + (4u ? (unsigned)(x0 >> 70) : 0x7fffffffu);
                } else {
                    e0 = e0 * 0.5L + (long double)((r0.x / ((unsigned)(r0.y || m0) | 1u)) & 1023u);
                }
                continue; (void)(u3);
                switch ((unsigned)((unsigned)l0 || m0) & 7u) {
                    a0[(unsigned)(short)(m0 >> (p2 & 31u)) & 3u] = (unsigned)((short)0xffffffffu > (signed char)a0[u1 & 3u]);
                }
                *mp = (0xffffffffu % (i0 | 1u));
                s1 = (int)((unsigned)s1 + (i0 >> (a0[i0 & 3u] & 31u)));
                if ((unsigned)(9u < 0x87d7579cu)) break;
            }
            a0[7u & 3u] = (unsigned)((short)m0 > (signed char)(0x185fc17eu >> (5u & 31u)));
            r0.y ^= (unsigned)((int)p0 < (int)(((unsigned)h0 & 5u) ? 0x10000u : garr[u2 & 7u]));
            d0 = d0 * 0.5 + (double)(1u & 1023u);
            w0 ^= (unsigned long long)(p1 & 0xffffffffu) << (((0x10000u >> (-(unsigned)(0xac2ef47au && i1) & 31u)) ^ (unsigned)!(r0.y - g0)) & 63u);
        }
    } while (i0++ < 2u && (unsigned)d0);
    c1 = (signed char)(unsigned)((unsigned)((int)i1 >= (int)0x69536b61u) < (unsigned)x0);
    garr[g1 & 7u] = 0x4be50362u;
    do { if (--fuel == 0u) goto done;
        *mp = (4u >> (((unsigned)(signed char)(0u ^ (unsigned)c0) << ((unsigned)((short)0xffffffffu > (signed char)*q0) & 31u)) & 31u));
        do { if (--fuel == 0u) goto done;
            if (m0) {
                l0 = (long)((unsigned long)l0 + 0x62c46c3au);
            }
            break; (void)((unsigned)c1);
            if ((unsigned)e0) break;
            if ((0x10000u ^ u2)) break;
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + ~((unsigned)(0x40eba723u < (*mp ? (unsigned)f0 : *q0)) - 0x7fffffffu));
                if (0x10000u) goto L4;
                break; (void)((unsigned)((unsigned)h1 || i1));
                garr[(u1 - a0[i0 & 3u]) & 7u] = 6u;
                break; (void)((0x8bebbf6au * u0));
                switch ((unsigned)((int)0xe48c7b67u >= (int)0x7fffffffu) & 7u) {
                    if ((0x7fffffffu + i1)) break;
                    if (i0) continue;
                    c0 = (unsigned char)(unsigned)((int)*mp >= (int)(unsigned)l0);
                    r0.y ^= ((0x80000000u & ((unsigned)(x0 >> 70) & (unsigned)s0)) % ((unsigned)((int)(unsigned)w0 >= (int)0x401f687eu) | 1u));
                    break; (void)((unsigned)d0);
                    case 6u: ;
                }
            }
        } while (i1++ < 5u && (p1 % ((unsigned)e0 | 1u)));
        q0 = &garr[(unsigned)((m0 & (unsigned)e0) == ((unsigned)f0 + (unsigned)s0)) & 7u];
        h0 = (short)-(m0 * (3u / (0xfdc14e39u | 1u)));
        g0 = (unsigned)((unsigned)(short)((unsigned)(garr[i1 & 7u] < a0[u1 & 3u]) / ((unsigned)d0 | 1u)) || (unsigned)(0x82d8a642u < (unsigned)c1));
        if ((*mp - (unsigned)h0)) goto L4;
    } while (i0++ < 6u && (unsigned)(i2 < (unsigned)h0));
    if ((unsigned)((short)i1 > (signed char)(unsigned)(9u && 0x80000000u))) goto L0;
    { unsigned t5; double z5; if ((-(unsigned)((unsigned)s1 || a0[i0 & 3u])) & 1u) { t5 = (unsigned)((int)~(unsigned)((short)0x80000000u > (signed char)0x10000u) < (int)p1); z5 = (double)((0xda15b404u) & 255u); } if ((-(unsigned)((unsigned)s1 || a0[i0 & 3u])) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
        if ((unsigned)((short)0xffffffffu > (signed char)(unsigned)x0)) goto L1;
        if (0x7fffffffu) goto L2;
        for (;;) { if (--fuel == 0u) goto done;
            r0.x = (unsigned)(0x10000u && g1);
            s1 = (int)((unsigned)s1 + (g0 % ((*q0 - (unsigned)((int)0x4dd0d59eu < (int)r0.x)) | 1u)));
        }
        d0 = d0 * 0.5 + (double)(0xca831630u & 1023u);
        e0 = e0 * 0.5L + (long double)((unsigned)c0 & 1023u);
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 = ((unsigned)s0 % ((unsigned)((int)(unsigned)h1 < (int)(unsigned)((a0[u1 & 3u] & i0) && 0x10000u)) | 1u));
        }
    }
    if ((unsigned)((int)(unsigned)l0 >= (int)i2)) goto L3;
    if ((unsigned)l0) {
        r0.x = (unsigned)((unsigned)(signed char)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)i2) == (unsigned)((unsigned)(x0 >> 70) == 0xcb11bb37u));
        goto done;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= 1u;
        }
        if ((unsigned)(0x80000000u == (1u >> (r0.y & 31u)))) goto done;
        s1 = (int)((unsigned)s1 + (a0[u1 & 3u] & 9u));
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)((unsigned)h0 / ((unsigned)(0x9ad43b12u < (unsigned)l0) | 1u)) < (int)(unsigned)((short)0xffffffffu > (signed char)i1));
    if (1u) goto L0;
    for (;;) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)(signed char)((unsigned)(a0[i0 & 3u] && g0) | (unsigned)(w0 >> 29)) > (signed char)~(0xee1f05a8u << (0x10000u & 31u))) & 1023u);
        while (i1++ < 5u && 0x10000u) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                g0 = garr[u2 & 7u];
                if ((unsigned)((int)r0.y < (int)*mp)) break;
                { unsigned t6; double z6; if (((unsigned)c1) & 1u) { t6 = 0x7fffffffu; z6 = (double)(((unsigned)!(unsigned)(0xa19a88c0u && (garr[i1 & 7u] ^ r0.y))) & 255u); } if (((unsigned)c1) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                    do { if (--fuel == 0u) goto done;
                        c1 = (signed char)(unsigned)((int)(unsigned)f0 < (int)(unsigned)((unsigned)(short)(unsigned)(8u || garr[u2 & 7u]) == 4u));
                        c1 = (signed char)(unsigned)((int)(unsigned)c0 >= (int)8u);
                        if ((unsigned)h0) continue;
                    } while (i0++ < 3u && 0xffffffffu);
                    while (i0++ < 7u && (unsigned)((short)v0 > (signed char)p1)) { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            if ((unsigned)(((unsigned)d0 >> (r0.x & 31u)) == (unsigned)h1)) break;
                        } while (i1++ < 3u && (unsigned)(u1 == 0x7fffffffu));
                        if ((unsigned)(short)(*q0 >> ((unsigned)b0 & 31u))) break;
                        g1 += 0x7fffffffu;
                        *q0 = 0x1e5a50c0u;
                        h0 = (short)(unsigned)((unsigned)(unsigned char)(u1 ? u0 : (unsigned)s1) < (unsigned)c1);
                        if ((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)c1)) break;
                    }
                    break; (void)(-(unsigned)((int)0xb9b3d293u < (int)u0));
                    g1 += (((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)s1) + (6u + 3u)) & 0x80000000u);
                }
                m0 ^= (unsigned)(w0 >> 29);
                w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)!(0xd1e68194u << (r0.x & 31u)) > (signed char)((unsigned)f0 / ((unsigned)(4u < m0) | 1u)));
                if (u1) {
                    s1 = (int)((unsigned)s1 + (unsigned)(signed char)((p1 ^ 0x80000000u) + (unsigned)(((unsigned)e0 | 0x7fffffffu) == 0u)));
                    break; (void)((unsigned)((int)(unsigned)h0 < (int)9u));
                    u3 ^= (unsigned)e0;
                    s0 = (int)a0[i0 & 3u];
                    do { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + (g1 >> (((unsigned)(x0 >> 70) | (unsigned)(i0 < 1u)) & 31u)));
                        s0 = (int)(0x6e30eba7u % ((g1 % (u1 | 1u)) | 1u));
                        if ((unsigned)c0) break;
                    } while (i0++ < 6u && (unsigned)(garr[i1 & 7u] == (unsigned)s1));
                }
            }
            if ((g1 >> (r0.x & 31u))) {
                a0[0xffffffffu & 3u] = u1;
                w0 ^= (unsigned long long)(0xc84a45fau & (unsigned)(w0 >> 29)) << (((unsigned)((int)(unsigned)w0 >= (int)(unsigned)((short)(unsigned)e0 > (signed char)(unsigned)f0)) | *q0) & 63u);
                break; (void)(((unsigned)f0 - (r0.x - *q0)));
                c0 = (unsigned char)(((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)h0) ? (unsigned)h0 : (unsigned)(x0 >> 70)) - p1);
            } else {
                garr[(p2 + (unsigned)b0) & 7u] = -(unsigned)(r0.x && i1);
                if ((unsigned)(i1 && v0)) break;
                m0 ^= r0.y;
            }
            f0 = f0 * 0.5f + (float)((garr[u2 & 7u] & 0xef8ad0edu) & 255u);
            while (r0.x) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)~((unsigned)x0 >> ((unsigned)s0 & 31u)) > (signed char)0x10000u)) {
                    garr[a0[u1 & 3u] & 7u] = (unsigned)s0;
                }
                *q0 = ((unsigned)(p1 || *mp) - (unsigned)e0);
                if ((unsigned)(signed char)((unsigned)l0 - (r0.y % (6u | 1u)))) goto L0;
                if (0x10000u) continue;
                if (7u) break;
                if (p0) {
                    if (fuel) continue;
                    break; (void)(0x80000000u);
                    break; (void)((((unsigned)c1 % (8u | 1u)) ^ g1));
                    if (~(unsigned)((int)0x80000000u >= (int)(unsigned)c1)) break;
                    garr[((unsigned)(w0 >> 29) - 2u) & 7u] = i0;
                }
            }
            for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)(signed char)((u1 - 0xa4f1b72cu) * (unsigned)h0) & 1023u);
                i2 = (unsigned)(i0 || (unsigned)((short)r0.x > (signed char)(unsigned)c1)) & 15u;
                b0 = 8u != 0u;
            }
            break; (void)(u1);
        }
    }
    l0 = (long)((unsigned long)l0 + ~((9u * 0x77541084u) | (unsigned)((int)(unsigned)s1 < (int)((unsigned)(w0 >> 29) << ((unsigned)l0 & 31u)))));
    q0 = &garr[(unsigned)(3u == (unsigned)l0) & 7u];
    if ((0u - (unsigned)h0)) goto L0;
    if ((unsigned)((unsigned)((unsigned)b0 == u1) == (unsigned)b0)) goto L0;
    while (i0++ < 3u && (a0[u1 & 3u] / ((unsigned)((int)3u < (int)*q0) | 1u))) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)((unsigned)((int)*q0 < (int)(0x10000u * (unsigned)e0)) ? m0 : g1);
        s1 = (int)((unsigned)s1 + ((unsigned)(u0 == 1u) - (unsigned)(signed char)((unsigned)(u2 || i2) + 0x37e3774du)));
        if (5u) break;
        r0.y ^= 0x80000000u;
        if ((~((unsigned)h1 ^ garr[u2 & 7u]) % (a0[u1 & 3u] | 1u))) {
            continue; (void)(g1);
            while (0u) { if (--fuel == 0u) goto done;
                continue; (void)(((0xdf3ed730u >> (p0 & 31u)) << (a0[i0 & 3u] & 31u)));
                if ((fuel * p2)) break;
                if (((0xaf971fb8u / (garr[i1 & 7u] | 1u)) - u0)) break;
            }
            if (((unsigned)c0 - (unsigned)((unsigned)(w0 >> 29) || (unsigned)l0))) break;
            g1 += u0;
        }
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(unsigned char)((0xcd27ad8cu ^ a0[u1 & 3u]) % (0xc61f398fu | 1u)) && fuel);
    { unsigned t7; double z7; if (((unsigned)((int)(unsigned)h1 < (int)(4u * 0xffffffffu))) & 1u) { t7 = 0x80000000u; z7 = (double)((i1) & 255u); } if (((unsigned)((int)(unsigned)h1 < (int)(4u * 0xffffffffu))) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
        if (5u) goto L2;
        do { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + u0;
            do { if (--fuel == 0u) goto done;
                g1 += (unsigned)(short)(unsigned)((int)5u >= (int)(unsigned)s1);
            } while (i1++ < 3u && (unsigned)b0);
            if (v0) break;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                i0 = (unsigned)((unsigned)!(u1 / (2u | 1u)) || 0x7f793c51u) & 15u;
                *mp = (unsigned)(0x7fffffffu < garr[u2 & 7u]);
                *q0 += (((0xe460cadfu % (0u | 1u)) | 0x601c2d79u) % ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)v0) | 1u));
                if (((unsigned)((unsigned)(w0 >> 29) || (unsigned)d0) >> (*mp & 31u))) continue;
                while (i2++ < 2u && (unsigned)(signed char)(0x10000u << (i1 & 31u))) { if (--fuel == 0u) goto done;
                    if (3u) goto L2;
                    while (i0++ < 6u && (((unsigned)(x0 >> 70) % (1u | 1u)) ^ u0)) { if (--fuel == 0u) goto done;
                        v0 = ((fuel << (((unsigned)w0 | (unsigned)d0) & 31u)) + (unsigned)h1);
                        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                            u0 += garr[i1 & 7u];
                            if ((unsigned)((unsigned)((unsigned)c1 && v0) && 1u)) continue;
                            u1 = (unsigned)(0x7fffffffu == 0x7fffffffu);
                            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(w0 >> 29) == i0) & 1023u);
                            if (0x80000000u) break;
                        }
                        u3 ^= (unsigned)((unsigned)(signed char)(unsigned)((int)0x545c38u >= (int)g1) || (unsigned)(1u || *q0));
                        if ((fuel << (0x9d5ee856u & 31u))) goto L4;
                        u1 = u1 * 0x9e3779b1u + ((garr[u2 & 7u] % ((unsigned)c1 | 1u)) | (unsigned)(short)(p0 ? garr[i1 & 7u] : 0xffffffffu));
                        r0.x = (0x10000u % ((unsigned)h0 | 1u));
                    }
                    r0.y ^= 0xffffffffu;
                    switch ((5u << ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)h0) & 31u)) & 7u) {
                        break; (void)((4u - (unsigned)((int)6u >= (int)u3)));
                        h0 = (short)(g1 | (unsigned)!((unsigned)d0 << ((((unsigned)s0 ^ 0x7ae3ab22u) | (unsigned)(w0 >> 29)) & 31u)));
                        d0 = d0 * 0.5 + (double)(r0.y & 1023u);
                        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                            garr[p0 & 7u] = 3u;
                            if (fuel < 8u) return ((unsigned)(short)(unsigned)((short)~(p0 << (p1 & 31u)) > (signed char)r0.x) % ((unsigned)((int)0x7fffffffu >= (int)(unsigned)s0) | 1u));
                            if ((unsigned)(7u && garr[u2 & 7u])) break;
                            case 6u: ;
                            case 3u: ;
                            default: ;
                        }
                        switch ((unsigned)c0 & 7u) {
                            a0[(unsigned)((int)*q0 >= (int)p2) & 3u] = (((fuel * u0) >> (~(0xffffffffu << ((unsigned)f0 & 31u)) & 31u)) ^ (unsigned)x0);
                        }
                        if ((unsigned)(0x7fffffffu && g0)) break;
                    }
                    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (u1) break;
                        if (garr[u2 & 7u]) break;
                        garr[2u & 7u] = (unsigned)((unsigned)((short)0x10000u > (signed char)m0) && r0.y);
                        if ((0x80000000u / (i2 | 1u))) break;
                        w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)(fuel < ((unsigned)s1 >> (i0 & 31u))) > (signed char)(i2 & 0x11e10a9fu));
                    }
                    if ((0x7fffffffu / ((unsigned)!(g0 - (unsigned)s0) | 1u))) break;
                }
                r0.x = ((garr[i1 & 7u] | (unsigned)c1) | 0xffffffffu);
            }
            if (((unsigned)(*mp && 0x7e0cacd3u) | garr[u2 & 7u])) break;
            while (i1++ < 3u && (unsigned)((unsigned)(w0 >> 29) && p1)) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (0x40ada421u << ((unsigned)!(unsigned)((short)(0xdaa3c5ffu << ((unsigned)s1 & 31u)) > (signed char)(unsigned)w0) & 31u));
                g0 = (unsigned)w0;
                d0 = d0 * 0.5 + (double)((((unsigned)c0 << ((unsigned)w0 & 31u)) - (unsigned)w0) & 1023u);
                goto L1;
                v0 = ((unsigned)(x0 >> 70) % ((unsigned)(short)(0xdaae3b39u ? 0x10000u : p2) | 1u));
            }
        } while (i0++ < 6u && (unsigned)((int)garr[i1 & 7u] < (int)0x1ea80beau));
        *q0 += (unsigned)(r0.x == (r0.x << ((unsigned)((int)(unsigned)(9u || 0xf247e28bu) < (int)u3) & 31u)));
        if (((unsigned)x0 / ((unsigned)(x0 >> 70) | 1u))) goto done;
        if (g1) goto L2;
    }
    c0 = (unsigned char)(((unsigned)f0 ^ (g1 - 0xffffffffu)) ^ (u1 % ((unsigned)b0 | 1u)));
    if (i0) goto L0;
    switch (((unsigned)(p1 || a0[i0 & 3u]) - u0) & 7u) {
        switch (0x7fffffffu & 7u) {
            while (i0++ < 2u && (a0[u1 & 3u] & i1)) { if (--fuel == 0u) goto done;
                case 6u: ;
                h0 = (short)(0xffffffffu - garr[i1 & 7u]);
            }
            case 1u: ;
            x0 = x0 * 0x100000001b3ull + (0x8122e31bu - (((unsigned)l0 / (a0[u1 & 3u] | 1u)) & u2));
            g1 += ((unsigned)((int)0x6df547d8u >= (int)i0) / (0xffffffffu | 1u));
            b0 = (unsigned)(short)((unsigned)(i2 && (unsigned)h0) << ((unsigned)d0 & 31u)) != 0u;
        }
        case 2u: ;
        case 4u: ;
    }
    h0 = (short)(0xabe484f3u | (7u | (unsigned)((unsigned)(w0 >> 29) || 3u)));
    goto L1;
    goto L0;
    switch ((unsigned)c0 & 7u) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 3u: ;
            if (0x6623c9f6u) {
                g0 = (g1 | (0x4ca1a482u - r0.x));
                case 6u: ;
            } else {
                case 7u: ;
                case 1u: ;
            }
            c1 = (signed char)(p1 << ((unsigned)((unsigned)d0 && 0x80000000u) & 31u));
            case 5u: ;
            x0 = x0 * 0x100000001b3ull + ((unsigned)(4u < 0x7ee71db6u) | ((unsigned)b0 % (0xdfcd348au | 1u)));
            default: ;
        }
        *mp = (unsigned)(i2 || (unsigned)((int)0xe3665e28u >= (int)(unsigned)l0));
        { unsigned t8; double z8; if (((unsigned)(g1 == 0xe356f9ceu)) & 1u) { t8 = 4u; z8 = (double)((*mp) & 255u); } if (((unsigned)(g1 == 0xe356f9ceu)) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
            do { if (--fuel == 0u) goto done;
                case 2u: ;
            } while (i0++ < 5u && (unsigned)(x0 >> 70));
        }
        if ((unsigned)(short)(0xffffffffu / ((unsigned)!(unsigned)((unsigned)l0 || i0) | 1u))) break;
        for (;;) { if (--fuel == 0u) goto done;
            goto L0;
            w0 ^= (unsigned long long)((unsigned)x0 - 0xffffffffu) << (((unsigned)w0 * p2) & 63u);
            break;
        }
    }
    if ((0x80000000u / (garr[u2 & 7u] | 1u))) {
        if ((unsigned)((unsigned)(0x5b5701c6u && fuel) == 0x80000000u)) goto L2;
    }
    goto L2;
    if (g0) goto L3;
    while (i0++ < 4u && u3) { if (--fuel == 0u) goto done;
        if ((unsigned)((u3 ^ 0xffffffffu) && 0x10000u)) break;
        switch (0x80000000u & 7u) {
            while (i1++ < 3u && (unsigned)c1) { if (--fuel == 0u) goto done;
                while ((unsigned)!(v0 | (unsigned)h0)) { if (--fuel == 0u) goto done;
                    c1 = (signed char)(unsigned)((short)((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)h1) | (unsigned)(0x9d568225u || (unsigned)l0)) > (signed char)r0.x);
                    case 4u: ;
                    e0 = e0 * 0.5L + (long double)((0x927e716bu & a0[u1 & 3u]) & 1023u);
                    s1 = (int)((unsigned)s1 + (unsigned)((short)(garr[u2 & 7u] % ((i0 ^ a0[i0 & 3u]) | 1u)) > (signed char)(unsigned)c1));
                }
                i1 = -(a0[i0 & 3u] ^ 0x641eab14u) & 15u;
                m0 ^= ~(unsigned)(g1 || (unsigned)(signed char)((unsigned)c1 ^ i0));
                case 7u: ;
                switch ((2u + a0[u1 & 3u]) & 7u) {
                    goto L1;
                }
                if ((unsigned)((int)0x10000u >= (int)(unsigned)e0)) {
                    if (r0.y) {
                        for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                            case 3u: ;
                            if (p1) continue;
                        }
                        case 2u: ;
                        if ((unsigned)(short)(unsigned)((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)l0) && (unsigned)h0)) {
                            case 1u: ;
                            v0 = (m0 % (0x80000000u | 1u));
                            *q0 = (unsigned)h1;
                            if ((p2 | 9u)) break;
                        }
                    }
                    if ((0x60ae4fb8u >> ((p0 - 0x80000000u) & 31u))) {
                        d0 = d0 * 0.5 + (double)(p1 & 1023u);
                        if ((unsigned)((short)i0 > (signed char)(unsigned)(0xd7eb227cu == (unsigned)h0))) break;
                        default: ;
                    } else {
                        if (g1) continue;
                        *mp = ((unsigned)e0 << (-(unsigned)(0x7fffffffu && 0xffffffffu) & 31u));
                        break;
                    }
                    if ((unsigned)((short)(unsigned)x0 > (signed char)(i1 - *mp))) continue;
                    *q0 = ((unsigned)c0 + (unsigned)!(0x580fa0u % (2u | 1u)));
                } else {
                    w0 ^= (unsigned long long)*mp << (((0xffffffffu + (unsigned)h1) >> (garr[i1 & 7u] & 31u)) & 63u);
                }
            }
            while (i1++ < 4u && (unsigned)x0) { if (--fuel == 0u) goto done;
                break;
                u2 += (unsigned)((int)(unsigned)s0 >= (int)(unsigned)s0);
                if (u3 == 7u) return (0xac340558u - (unsigned)x0);
            }
            case 0u: ;
            m0 ^= (((unsigned)(w0 >> 29) + (unsigned)s0) ^ 8u);
            if ((((unsigned)w0 + 0x84600883u) | 0xb18d13b1u)) goto L1;
        }
        c0 = (unsigned char)-(unsigned)((int)(garr[u2 & 7u] + r0.x) < (int)(u1 | (unsigned)((int)(unsigned)c0 >= (int)2u)));
        r0.y ^= (unsigned)(*q0 == (*q0 - (unsigned)((unsigned)(0xffffffffu || garr[u2 & 7u]) == 0x3ee61747u)));
        break; (void)((r0.x ? (unsigned)h0 : v0));
        c0 = (unsigned char)(unsigned)b0;
    }
    w0 ^= (unsigned long long)((unsigned)h0 / (p1 | 1u)) << ((unsigned)(-(u3 % (0x80000000u | 1u)) == 0x5ad30546u) & 63u);
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(w0 >> 29));
        if ((2u % ((i1 / (p0 | 1u)) | 1u))) continue;
        if ((0xffffffffu & 0x537cba91u)) {
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (r0.x + (-(unsigned)((int)(unsigned)((int)(unsigned)d0 < (int)0x80000000u) < (int)u2) + p1));
                if (fuel < 8u) return ((unsigned)(w0 >> 29) % ((unsigned)!(((unsigned)w0 ^ u0) << ((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)h1) & 31u)) | 1u));
                { unsigned t9; double z9; if ((((9u >> (1u & 31u)) * 6u)) & 1u) { t9 = (0xffffffffu | 6u); z9 = (double)((0x471c181bu) & 255u); } if ((((9u >> (1u & 31u)) * 6u)) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                    s0 = (int)(unsigned)c0;
                    *mp = (unsigned)((unsigned)((int)*q0 < (int)0x7fffffffu) || (8u & (unsigned)w0));
                    switch ((((unsigned)(x0 >> 70) / (fuel | 1u)) >> (garr[u2 & 7u] & 31u)) & 7u) {
                        h0 = (short)(u2 << ((garr[i1 & 7u] + v0) & 31u));
                        if (r0.x) continue;
                    }
                    e0 = e0 * 0.5L + (long double)(5u & 1023u);
                }
                b0 = ~(unsigned)((int)(unsigned)((short)(unsigned)c0 > (signed char)(a0[i0 & 3u] | a0[u1 & 3u])) < (int)(garr[i1 & 7u] % ((unsigned)l0 | 1u))) != 0u;
                if ((0x84424624u + (unsigned)((int)(unsigned)f0 >= (int)3u))) break;
                if ((a0[i0 & 3u] * u2)) break;
            }
        } else {
            q0 = &garr[((u1 + 1u) ^ (*q0 & (unsigned)(short)(g0 * 1u))) & 7u];
        }
    } while (i0++ < 3u && (unsigned)(unsigned char)(unsigned)((0x45baf074u - p2) == 0x87274e98u));
    while (i0++ < 6u && *mp) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t10; double z10; if (((unsigned)(3u || 0x6ea2d9c8u)) & 1u) { t10 = (0x80000000u >> ((r0.x + (unsigned)h0) & 31u)); z10 = (double)(((unsigned)(unsigned char)(unsigned)((i2 % (i2 | 1u)) && (unsigned)(w0 >> 29))) & 255u); } if (((unsigned)(3u || 0x6ea2d9c8u)) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
                u3 = (unsigned)!(garr[u2 & 7u] - u1);
                goto L0;
            }
            break; (void)((0xffffffffu + (unsigned)(x0 >> 70)));
            if ((u3 | 4u)) break;
        }
        if (-(((unsigned)c0 | *q0) % (0x248555fu | 1u))) {
            h0 = (short)(unsigned)(unsigned char)(v0 % ((unsigned)((unsigned)(0xe7747042u && r0.y) < i1) | 1u));
        } else {
            if (*q0) break;
        }
        *mp = (unsigned)(signed char)(unsigned)((unsigned)((unsigned)s1 < (unsigned)(x0 >> 70)) == ((unsigned)(5u == 5u) | 6u));
        s0 = (int)(unsigned)((int)(unsigned)f0 >= (int)((unsigned)w0 - 2u));
        if (p1) break;
        w0 = w0 * 6364136223846793005ull + (unsigned)(x0 >> 70);
    }
    if (-((unsigned)f0 + p1)) goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch ((i2 >> ((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)x0) & 31u)) & 7u) {
        goto L3;
        do { if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if (((unsigned)(short)(0x10000u >> (((unsigned)d0 ^ m0) & 31u))) & 1u) { t0 = (unsigned)(g1 && m0); z0 = (double)((5u) & 255u); } if (((unsigned)(short)(0x10000u >> (((unsigned)d0 ^ m0) & 31u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                i1 = (unsigned)(signed char)(m0 % ((unsigned)h0 | 1u)) & 15u;
                { unsigned t1; double z1; if ((~(unsigned)((int)fuel < (int)7u)) & 1u) { t1 = ((unsigned)((unsigned)c1 && 0x7fffffffu) << ((unsigned)s1 & 31u)); z1 = (double)(((u0 / (fuel | 1u))) & 255u); } if ((~(unsigned)((int)fuel < (int)7u)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    if ((unsigned)((int)0xed5c2ec3u < (int)p0)) break;
                    case 7u: ;
                    u3 += 0x88dd1523u;
                }
            }
            garr[5u & 7u] = ((unsigned)(0x63e17fc5u && (unsigned)c0) >> ((garr[u2 & 7u] ? i1 : i0) & 31u));
            { unsigned t2; double z2; if ((((unsigned)(x0 >> 70) << (0xb9f096f6u & 31u))) & 1u) { t2 = ((unsigned)((int)1u < (int)(unsigned)s1) * r0.y); z2 = (double)((0xaa48cbe2u) & 255u); } if ((((unsigned)(x0 >> 70) << (0xb9f096f6u & 31u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((i0 | (unsigned)l0), ((unsigned)d0 ? (unsigned)l0 : (unsigned)(w0 >> 29)), ((unsigned)h0 * (unsigned)((short)0xe30012a1u > (signed char)g1))); }
                    break; (void)(u0);
                    d0 = d0 * 0.5 + (double)((unsigned)((short)1u > (signed char)(0xffffffffu & p2)) & 1023u);
                    if (r0.x) break;
                    a0[(unsigned)((int)(unsigned)l0 >= (int)2u) & 3u] = ((unsigned)(((unsigned)c0 % (g0 | 1u)) < g1) / ((p1 ^ garr[u2 & 7u]) | 1u));
                    *q0 = (((i1 | 0xc327e098u) / ((unsigned)(x0 >> 70) | 1u)) << (0xffffffffu & 31u));
                }
                *mp = -(a0[i0 & 3u] + (unsigned)((int)3u >= (int)0x7fffffffu));
            }
        } while (i0++ < 5u && (unsigned)((int)a0[i0 & 3u] >= (int)*q0));
        if (i1) {
            u0 ^= (p2 << (i0 & 31u));
        } else {
            *q0 += (unsigned)(0x1542defbu == g1);
            case 3u: ;
            goto done;
        }
    }
    if ((unsigned)d0) goto done;
    u2 ^= (unsigned)((int)(unsigned)c0 < (int)p0);
    i0 = 0x74ac22d1u & 15u;
    goto L1;
    *q0 += ((unsigned)((short)0xc5c5b05u > (signed char)0u) | (unsigned)(a0[i0 & 3u] < r0.y));
    q0 = &garr[(unsigned)(signed char)((*q0 & p1) / ((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)c1) | 1u)) & 7u];
    L0: if (--fuel == 0u) goto done;
    c0 = (unsigned char)((u2 + (unsigned)(g0 && i2)) * m0);
    u3 += (unsigned)b0;
    h1 = (unsigned short)(h1 + (unsigned)(a0[u1 & 3u] < (unsigned)f0));
    *mp = (unsigned)(short)((unsigned)x0 | (unsigned)e0);
    if (u3 == 7u) return (((unsigned)c0 ? m0 : (unsigned)d0) + (unsigned)!((unsigned)l0 * g1));
    do { if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
        b0 = (unsigned)((int)p2 < (int)((unsigned)d0 | 3u)) != 0u;
    } while (i0++ < 6u && 2u);
    e0 = e0 * 0.5L + (long double)((unsigned)(((unsigned)(i0 && 0x7fffffffu) + m0) == (garr[u2 & 7u] << (u1 & 31u))) & 1023u);
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)p2 >= (int)(garr[u2 & 7u] % ((unsigned)f0 | 1u)))) {
            w0 ^= (unsigned long long)(garr[i1 & 7u] & 0x10000u) << ((unsigned)((0x16738895u | (unsigned)c1) && (unsigned)c0) & 63u);
            if (((unsigned)s1 >> (0u & 31u))) break;
            if (g0) break;
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0(0xd8d0e065u, (unsigned)h1, 4u); }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)((unsigned)!((unsigned)s0 | 0xf6f392ebu) % ((((unsigned)(x0 >> 70) + 0xf46e0f70u) | 0xc1142c7cu) | 1u));
        r0.y ^= (9u << (0x80000000u & 31u));
        L2: if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0(4u, (unsigned)(short)(unsigned)(0xffffffffu || garr[u2 & 7u]), (0xffffffffu >> ((unsigned)l0 & 31u))); }
            s0 = (int)(unsigned)((int)(*mp + 0x44836997u) >= (int)((unsigned)s1 % (g0 | 1u)));
            q0 = &garr[(unsigned)((int)(unsigned)(0x80000000u || (unsigned)(x0 >> 70)) >= (int)(unsigned)(w0 >> 29)) & 7u];
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(-(unsigned)(garr[u2 & 7u] && 5u) < g0), (u2 ? 0x9b88fed6u : g0), (unsigned)(i0 == (unsigned)!(unsigned)((unsigned)s0 < r0.x))); }
            u3 ^= (unsigned)(short)(i1 * (unsigned)(signed char)(0xcdf5e7d8u << (0x2b3771b1u & 31u)));
            { unsigned t3; double z3; if (((m0 >> ((unsigned)(garr[i1 & 7u] < i1) & 31u))) & 1u) { t3 = (u3 << (v0 & 31u)); z3 = (double)((m0) & 255u); } if (((m0 >> ((unsigned)(garr[i1 & 7u] < i1) & 31u))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                *q0 += ((g1 & ((g1 << ((unsigned)d0 & 31u)) << (u1 & 31u))) - g0);
                L3: if (--fuel == 0u) goto done;
                goto L1;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)x0, (garr[u2 & 7u] + (unsigned)l0), 0xffffffffu); }
            }
        } while (i1++ < 7u && -((unsigned)b0 / ((0x50d0b032u - 0xec366f4eu) | 1u)));
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(0x30753fb1u && (unsigned)l0)) {
                if (((unsigned)b0 >> (0xde84340fu & 31u))) break;
                switch ((g0 + (garr[i1 & 7u] & (unsigned)l0)) & 7u) {
                    h1 = (unsigned short)(h1 + (unsigned)((u2 ? u2 : garr[i1 & 7u]) < 0x5111256cu));
                    if (u3) break;
                    L4: if (--fuel == 0u) goto done;
                    v0 = (fuel % (garr[i1 & 7u] | 1u));
                    s0 = (int)g0;
                }
                if (-(a0[u1 & 3u] & 0x80000000u)) continue;
                if ((unsigned)e0) break;
            }
        }
        do { if (--fuel == 0u) goto done;
            if (((unsigned)b0 << ((unsigned)!(unsigned)((unsigned)x0 && 0xd5e52199u) & 31u))) continue;
        } while (i1++ < 2u && a0[i0 & 3u]);
    }
    garr[8u & 7u] = (unsigned)((int)u2 >= (int)(unsigned)!(unsigned)(7u < (r0.x << (a0[i0 & 3u] & 31u))));
    s0 = (int)(unsigned)((int)(u3 >> (p2 & 31u)) < (int)(unsigned)x0);
    if (i0) {
        goto L2;
    }
    r0.x = (~(p0 << (0xa401d828u & 31u)) - 0x7fffffffu);
    h1 = (unsigned short)(h1 + i0);
    q0 = &garr[((unsigned)c0 % (((unsigned)s0 % (0x5f01eb9du | 1u)) | 1u)) & 7u];
    w0 ^= (unsigned long long)(0xbbe69300u >> ((unsigned)f0 & 31u)) << ((unsigned)(0x99454f93u < g0) & 63u);
    x0 = x0 * 0x100000001b3ull + g0;
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            continue; (void)(~((unsigned)s1 | (9u % ((unsigned)l0 | 1u))));
            if ((i1 / (2u | 1u))) break;
            *mp = p2;
            if ((unsigned)h0) break;
            break; (void)((0x68244ca2u ^ ((unsigned)f0 ^ (unsigned)f0)));
        }
        if (((unsigned)c1 * u2)) break;
    } while (i0++ < 2u && i2);
    *q0 = p2;
    f0 = f0 * 0.5f + (float)((unsigned)(0x10000u == ((unsigned)f0 % ((a0[u1 & 3u] ? (unsigned)l0 : i2) | 1u))) & 255u);
    if (-(unsigned)(0xf11af012u || ((unsigned)f0 | (unsigned)s0))) {
        r0.x = g1;
    } else {
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)f0) break;
                if (u3 == 7u) return (unsigned)(signed char)(*mp ? 0xffffffffu : (((unsigned)d0 >> (0u & 31u)) / (p2 | 1u)));
                if (u3 == 7u) return ((p2 * 2u) / ((unsigned)(u0 && p0) | 1u));
                s0 = (int)((fuel / (*q0 | 1u)) / (g1 | 1u));
                v0 = (unsigned)s1;
            } while (i1++ < 6u && (unsigned)((short)r0.x > (signed char)0x7fffffffu));
            if (fuel < 8u) return 0x943de0e0u;
        } while (i0++ < 4u && (0u / (g1 | 1u)));
        goto L0;
        m0 ^= (garr[i1 & 7u] * v0);
        w0 = w0 * 6364136223846793005ull + (0x216b8394u ^ ((unsigned)s0 % (0x80000000u | 1u)));
    }
    if ((unsigned)((unsigned)((unsigned)(w0 >> 29) && (unsigned)s1) == (unsigned)s0)) goto L2;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)b0 < 9u), (u0 | 3u), 0x57ab1feu); }
        if (u3 == 7u) return (0x3bbc310u ^ ~(r0.x & (unsigned)w0));
        if (u3 == 7u) return (unsigned)((int)-(unsigned)((short)(unsigned)s1 > (signed char)i0) < (int)(0u ^ p2));
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((p0 & g1)) {
                f0 = f0 * 0.5f + (float)((unsigned)((int)a0[u1 & 3u] >= (int)((r0.x | 9u) & (unsigned)(w0 >> 29))) & 255u);
                { unsigned t4; double z4; if (((unsigned)((int)(unsigned)s0 >= (int)(u0 ^ 0x36446485u))) & 1u) { t4 = ((unsigned)((unsigned)d0 || (unsigned)l0) % (0x1acc99b0u | 1u)); z4 = (double)(((unsigned)(-((unsigned)f0 - garr[i1 & 7u]) < *mp)) & 255u); } if (((unsigned)((int)(unsigned)s0 >= (int)(u0 ^ 0x36446485u))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    m0 ^= a0[i0 & 3u];
                    switch ((unsigned)((int)(unsigned)e0 >= (int)p2) & 7u) {
                        *q0 = (unsigned)(a0[u1 & 3u] && (((unsigned)(w0 >> 29) << (0xffffffffu & 31u)) ^ a0[u1 & 3u]));
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(g1 == (3u + 0xa20760ecu)), v0, (unsigned)!(fuel << (~(garr[i1 & 7u] + fuel) & 31u))); }
                        if (((unsigned)(short)((unsigned)b0 & m0) | 7u)) {
                            case 5u: ;
                            u2 = u2 * 0x9e3779b1u + (7u & (unsigned)((short)0x4d7b7ec2u > (signed char)a0[i0 & 3u]));
                        } else {
                            case 3u: ;
                            if (budget != 0u) { budget -= 1u; u1 = fn0((0x8f1bec4fu | 1u), (0x80000000u - v0), (unsigned)(((unsigned)c1 - p2) && p0)); }
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn0(p0, fuel, (0x7d52bf46u >> ((unsigned)!(unsigned)((unsigned)f0 && 0x8dfdbe3du) & 31u))); }
                    }
                }
                garr[(unsigned)h1 & 7u] = 0x80000000u;
                break; (void)((0x96c87f17u >> ((unsigned)((int)(unsigned)l0 >= (int)0x30d45e2du) & 31u)));
                if ((unsigned)(1u && (unsigned)((int)(unsigned)c0 >= (int)garr[u2 & 7u]))) break;
                break; (void)((u0 * (9u & a0[i0 & 3u])));
            } else {
                b0 = ((0xa77597c9u * m0) + (g1 | i1)) != 0u;
                if (budget != 0u) { budget -= 1u; u2 = fn0(u2, (0xb54e3c3au & ((unsigned)h0 * (unsigned)e0)), (unsigned)(fuel || p2)); }
                *q0 += (unsigned)((unsigned)((garr[u2 & 7u] % (0x10000u | 1u)) || v0) || 0x80000000u);
            }
            switch ((unsigned)w0 & 7u) {
                if (budget != 0u) { budget -= 1u; u1 = fn0(((i0 * 5u) & u1), ((unsigned)((short)i0 > (signed char)(unsigned)c1) >> (u0 & 31u)), (unsigned)((unsigned)(x0 >> 70) || (unsigned)((short)a0[i0 & 3u] > (signed char)*mp))); }
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)((short)0x4744ccd6u > (signed char)garr[u2 & 7u]) / ((unsigned)h0 | 1u)), ((0x5b01e0cau >> (v0 & 31u)) % (0x850cd9e7u | 1u)), (unsigned)(w0 >> 29)); }
                b0 = (unsigned)(1u || (0xb6321b7bu >> (i2 & 31u))) != 0u;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(*mp, (unsigned)h0, 0x10000u); }
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)f0, ((unsigned)((short)(unsigned)l0 > (signed char)garr[i1 & 7u]) - (unsigned)x0), (p1 % (0x80000000u | 1u))); }
                { unsigned t5; double z5; if ((0xcdd68a91u) & 1u) { t5 = (0xffffffffu ? g1 : (unsigned)l0); z5 = (double)(((unsigned)((int)i0 >= (int)(garr[i1 & 7u] << (0x80000000u & 31u)))) & 255u); } if ((0xcdd68a91u) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                    e0 = e0 * 0.5L + (long double)(0x3457c55fu & 1023u);
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(short)(0x80000000u % (u1 | 1u)) << (u2 & 31u)), 0x80000000u, (0x265b06d8u * 7u)); }
                    case 4u: ;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)2u >= (int)0x7fffffffu), (unsigned)d0, (unsigned)(0xffffffffu == (unsigned)(unsigned char)((unsigned)c0 - r0.y))); }
                    if ((unsigned)((unsigned)(garr[u2 & 7u] < i0) || p1)) break;
                    s0 = (int)((9u % (0x80000000u | 1u)) / (((unsigned)f0 | garr[i1 & 7u]) | 1u));
                }
            }
        }
    }
    switch ((-(i0 / (p1 | 1u)) / (a0[i0 & 3u] | 1u)) & 7u) {
        case 2u: ;
        if ((unsigned)((int)(unsigned)f0 < (int)i0)) break;
        if ((unsigned)(3u == i2)) {
            default: ;
            m0 ^= (unsigned)c0;
            case 3u: ;
            garr[(unsigned)((unsigned)h1 && (unsigned)e0) & 7u] = (unsigned)(r0.x && ((unsigned)f0 * (unsigned)((unsigned)w0 < (unsigned)d0)));
            if ((unsigned)((short)garr[i1 & 7u] > (signed char)(6u << (*q0 & 31u)))) goto L0;
        }
        if ((a0[i0 & 3u] * (unsigned)l0)) goto L2;
    }
    switch ((unsigned)c0 & 7u) {
        switch (-((unsigned)(w0 >> 29) / ((unsigned)d0 | 1u)) & 7u) {
            if ((unsigned)((m0 << (garr[i1 & 7u] & 31u)) && 6u)) break;
            e0 = e0 * 0.5L + (long double)((unsigned)f0 & 1023u);
        }
        if ((*q0 << (0x80000000u & 31u))) goto L0;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)x0 < (int)u1), 4u, (0x7fffffffu * 0x88cc1cd1u)); }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((g1 % (((unsigned)h0 & 0x80000000u) | 1u)), 4u, (unsigned)(u1 == a0[i0 & 3u])); }
    if (budget != 0u) { budget -= 1u; u2 = fn0(i2, (unsigned)((unsigned)(7u < (unsigned)(x0 >> 70)) == (unsigned)x0), (g1 - ~(unsigned)((int)u3 >= (int)r0.y))); }
    if (budget != 0u) { budget -= 1u; u1 = fn0(0x7fffffffu, (g1 - garr[i1 & 7u]), ((unsigned)h1 * 0x5df97f04u)); }
    { unsigned t6; double z6; if (((unsigned)(short)(-(unsigned)((unsigned)c0 == (unsigned)b0) << ((unsigned)s1 & 31u))) & 1u) { t6 = (unsigned)((int)p2 >= (int)(5u + (unsigned)f0)); z6 = (double)(((r0.x / (0xa991194du | 1u))) & 255u); } if (((unsigned)(short)(-(unsigned)((unsigned)c0 == (unsigned)b0) << ((unsigned)s1 & 31u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
        while (i0++ < 3u && (unsigned)((int)(unsigned)f0 < (int)(unsigned)((int)4u < (int)g0))) { if (--fuel == 0u) goto done;
            if (i2) goto L0;
            if ((g0 / ((unsigned)b0 | 1u))) break;
            if (0x10000u) break;
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (i1) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(*q0, (2u * (unsigned)!((unsigned)b0 ^ 4u)), v0); }
                    i1 = -(unsigned)((unsigned)((int)(unsigned)h1 >= (int)(unsigned)(g0 || 0x7fffffffu)) == (unsigned)w0) & 15u;
                    c0 = (unsigned char)(unsigned)((int)u1 < (int)5u);
                    garr[(unsigned)(w0 >> 29) & 7u] = (~(unsigned)((int)0x4cb6b8u < (int)(unsigned)!((unsigned)w0 | g1)) % ((unsigned)s1 | 1u));
                    d0 = d0 * 0.5 + (double)(((unsigned)(p0 || (unsigned)h0) >> ((unsigned)c1 & 31u)) & 1023u);
                }
                do { if (--fuel == 0u) goto done;
                    goto done;
                    do { if (--fuel == 0u) goto done;
                        if (p0) goto L3;
                        if (~(unsigned)((int)((unsigned)l0 + r0.x) < (int)u0)) break;
                        do { if (--fuel == 0u) goto done;
                            *q0 = (unsigned)((unsigned)(0xffffffffu < garr[u2 & 7u]) < p2);
                            if ((a0[u1 & 3u] - (unsigned)(0x10000u < (unsigned)s0))) break;
                            x0 = x0 * 0x100000001b3ull + (u2 ? g0 : g1);
                            u2 += (0u | (0x80000000u ? g0 : v0));
                        } while (i1++ < 3u && 5u);
                        if (0xcfeb907eu) break;
                        if ((u3 | (unsigned)(0x7fffffffu && u3))) break;
                    } while (i0++ < 2u && (unsigned)((short)*mp > (signed char)((unsigned)c0 % (r0.y | 1u))));
                } while (i2++ < 5u && (unsigned)((int)(unsigned)f0 >= (int)0u));
                goto L0;
                f0 = f0 * 0.5f + (float)((u2 % (8u | 1u)) & 255u);
            }
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (9u) break;
                { unsigned t7; double z7; if ((((unsigned)h1 >> (i2 & 31u))) & 1u) { t7 = (unsigned)(u1 || (unsigned)(x0 >> 70)); z7 = (double)((-(r0.x ^ v0)) & 255u); } if ((((unsigned)h1 >> (i2 & 31u))) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                    if ((*mp | (unsigned)w0)) break;
                }
                m0 ^= (4u << (0xf572724cu & 31u));
                *q0 += (unsigned)((short)(unsigned)b0 > (signed char)i0);
                if ((unsigned)((int)(unsigned)s1 < (int)(1u & 0x3f601366u))) {
                    f0 = f0 * 0.5f + (float)(9u & 255u);
                    u1 = (unsigned)e0;
                }
            }
        }
        u1 += (unsigned)((short)((unsigned)c0 + (unsigned)w0) > (signed char)9u);
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)l0 && p0), (unsigned)((short)-(unsigned)(p1 == 0x80000000u) > (signed char)0x448ff38u), (v0 ^ (unsigned)s1)); }
        i2 = ((unsigned)(signed char)(unsigned)(0xd402b2c8u == *mp) | (unsigned)((unsigned)s0 && garr[i1 & 7u])) & 15u;
        for (;;) { if (--fuel == 0u) goto done;
            while (i1++ < 2u && (garr[i1 & 7u] + (r0.y / (i0 | 1u)))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((((unsigned)e0 ^ 0x80000000u) ^ 0x10000u), 0xb9fac3abu, ((p0 - 8u) - 2u)); }
            }
            m0 ^= ((unsigned)((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)x0) < v0) & (unsigned)h1);
            u1 ^= (unsigned)((short)*mp > (signed char)(unsigned)!(unsigned)((int)u2 < (int)p2));
            break; (void)((unsigned)(unsigned char)(0u ^ m0));
            s1 = (int)((unsigned)s1 + (unsigned)!(unsigned)((int)(unsigned)(a0[u1 & 3u] || 7u) >= (int)((unsigned)((short)fuel > (signed char)0xfec8e2e5u) ^ *mp)));
        }
    }
    if (u3 == 7u) return (unsigned)((int)((unsigned)h0 + u3) < (int)(unsigned)(i0 && (unsigned)((short)0x8e1a6d0eu > (signed char)p1)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u1 = fn1((a0[u1 & 3u] * r0.y), (unsigned)(((unsigned)(x0 >> 70) / ((unsigned)d0 | 1u)) || (unsigned)s0), (v0 / (0x1a212c4cu | 1u))); }
    garr[p2 & 7u] = (unsigned)((int)0x268f6ac7u < (int)(unsigned)(unsigned char)((unsigned)b0 ? i1 : 0xab22810fu));
    h1 = (unsigned short)(h1 + (unsigned)(signed char)(a0[u1 & 3u] % (((unsigned)h0 >> ((unsigned)(m0 || (unsigned)e0) & 31u)) | 1u)));
    c1 = (signed char)(unsigned)(0x80000000u && (unsigned)(0x10000u || fuel));
    if ((u2 % (5u | 1u))) goto done;
    if (~(7u & 2u)) {
        switch (0xffffffffu & 7u) {
            if ((unsigned)(w0 >> 29)) break;
        }
        for (;;) { if (--fuel == 0u) goto done;
            switch ((0x10000u << ((unsigned)(short)(unsigned)((short)*mp > (signed char)0xea120567u) & 31u)) & 7u) {
                do { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + ((unsigned)((short)(unsigned)(unsigned char)(0x833bad28u & 0x10000u) > (signed char)0xf0c38cc1u) % ((unsigned)h0 | 1u)));
                    L0: if (--fuel == 0u) goto done;
                    if ((unsigned)((int)(unsigned)w0 < (int)a0[i0 & 3u])) continue;
                    case 7u: ;
                } while (i1++ < 6u && 0xb26152d0u);
            }
            l0 = (long)((unsigned long)l0 + 7u);
            do { if (--fuel == 0u) goto done;
                u1 += (unsigned)c1;
                r0.x = (unsigned)(unsigned char)((unsigned)h0 ^ (unsigned)((unsigned)d0 || ((0x10000u / ((unsigned)x0 | 1u)) / ((unsigned)(w0 >> 29) | 1u))));
                g0 = 0xffffffffu;
                while (garr[u2 & 7u]) { if (--fuel == 0u) goto done;
                    break; (void)(((garr[u2 & 7u] | 0x4248d4f8u) | a0[i0 & 3u]));
                    goto L3;
                }
            } while (i1++ < 5u && a0[i0 & 3u]);
            if ((0x7fffffffu ^ 0xffffffffu)) {
                if (budget != 0u) { budget -= 1u; u2 = fn0(garr[u2 & 7u], (6u - fuel), (unsigned)(w0 >> 29)); }
            }
            w0 ^= (unsigned long long)u0 << (~(unsigned)((unsigned)b0 || (unsigned)(x0 >> 70)) & 63u);
            r0.x = 8u;
        }
        w0 = w0 * 6364136223846793005ull + ((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)((int)(unsigned)(0x80000000u < r0.x) < (int)1u)) % ((unsigned)w0 | 1u));
    } else {
        goto L0;
        while (i0++ < 2u && (unsigned)(4u || v0)) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)((unsigned)(((unsigned)s1 + r0.x) || (unsigned)h1) < i2);
                if (budget != 0u) { budget -= 1u; u1 = fn1(3u, (unsigned)w0, (unsigned)s0); }
            }
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)s0 % ((0u % ((unsigned)h0 | 1u)) | 1u))) break;
                    if ((unsigned)x0) break;
                    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        *q0 = -(7u - ((unsigned)c0 << (((unsigned)(x0 >> 70) << ((unsigned)(p1 || g0) & 31u)) & 31u)));
                        v0 = (((unsigned)(signed char)(unsigned)((unsigned)c0 && (unsigned)(w0 >> 29)) - v0) / ((unsigned)(short)(unsigned)((unsigned)(x0 >> 70) == 2u) | 1u));
                        if (budget != 0u) { budget -= 1u; u1 = fn0(0x1b10e939u, 0x83b415b7u, (unsigned)((i0 + a0[u1 & 3u]) < 0x32493c30u)); }
                        if ((unsigned)(p1 || ~(g1 << (0xffffffffu & 31u)))) {
                            d0 = d0 * 0.5 + (double)(6u & 1023u);
                            break; (void)((unsigned)(*mp && 5u));
                            break; (void)((unsigned)(*mp || p2));
                            u3 += (unsigned)(short)(unsigned)((unsigned)(short)(8u | 0xe29e983eu) && i1);
                        }
                    }
                    switch (((unsigned)(short)(fuel ^ 0x80000000u) * a0[u1 & 3u]) & 7u) {
                        v0 = (unsigned)(((unsigned)(0xeb70e420u < 0xffffffffu) % ((unsigned)((int)u3 >= (int)p0) | 1u)) == (unsigned)(w0 >> 29));
                        h1 = (unsigned short)(h1 + (unsigned)s1);
                    }
                    while (i0) { if (--fuel == 0u) goto done;
                        if ((unsigned)h0) break;
                        if (budget != 0u) { budget -= 1u; u0 = fn1(3u, i2, (*q0 - ((unsigned)b0 / (0x3914f97du | 1u)))); }
                        r0.x = (6u | (0xa9d92f54u ^ *mp));
                        w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)(unsigned)((unsigned)(short)(unsigned)((0xc7b9ea8au + (unsigned)w0) < (unsigned)l0) == (fuel >> (5u & 31u)));
                        if (((0xd4049c43u << (0x8f99d6bdu & 31u)) ^ g0)) break;
                        v0 = (unsigned)((unsigned)d0 == ((unsigned)(short)(unsigned)((unsigned)(x0 >> 70) || garr[i1 & 7u]) & (unsigned)((unsigned)w0 || u0)));
                    }
                    break; (void)((unsigned)((int)(unsigned)x0 >= (int)garr[u2 & 7u]));
                }
                d0 = d0 * 0.5 + (double)((unsigned)b0 & 1023u);
            }
        }
        f0 = f0 * 0.5f + (float)(((unsigned)b0 + p0) & 255u);
    }
    r0.x = (unsigned)(u0 == (0x10000u - 0x7ad5ee8eu));
    if (((unsigned)(i1 == 0x10000u) ^ (unsigned)h1)) goto L2;
    while (i0++ < 5u && fuel) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            r0.x = *q0;
            s0 = (int)~(unsigned)(((unsigned)w0 + 5u) && (unsigned)s0);
        } while (i1++ < 5u && u1);
        switch ((unsigned)(i2 || i0) & 7u) {
            if (((unsigned)h1 - (unsigned)c1)) {
                case 2u: ;
            }
            q0 = &garr[4u & 7u];
            switch ((unsigned)l0 & 7u) {
                f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)l0 >= (int)i2) & 255u);
                L2: if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)h0 & 7u];
            }
            e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(a0[u1 & 3u] & ((unsigned)(short)((unsigned)b0 ^ (unsigned)c1) * p2)) & 1023u);
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(6u, *q0, ((0x7fffffffu * i1) / ((unsigned)h0 | 1u))); }
        goto L3;
    }
    if (*q0) goto L1;
    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)c0 / ((0x10000u * v0) | 1u)), ((unsigned)x0 - (unsigned)c1), (unsigned)((int)0xb4ede27eu >= (int)v0)); }
    if (((unsigned)((short)g1 > (signed char)0x72d2abcdu) - (unsigned)c1)) goto L1;
    { unsigned t0; double z0; if ((((unsigned)x0 % ((9u / (7u | 1u)) | 1u))) & 1u) { t0 = 0x81c5e718u; z0 = (double)(((unsigned)(x0 >> 70)) & 255u); } if ((((unsigned)x0 % ((9u / (7u | 1u)) | 1u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        { unsigned t1; double z1; if (((0xffffffffu << (u2 & 31u))) & 1u) { t1 = u1; z1 = (double)((0x80000000u) & 255u); } if (((0xffffffffu << (u2 & 31u))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)(0x80000000u < 0u)) break;
            }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((0xffffffffu >> (i2 & 31u)) || 0x10000u)) continue;
                d0 = d0 * 0.5 + (double)(((unsigned)((int)0x70e4c70au >= (int)(unsigned)f0) ^ (unsigned)(g1 == p1)) & 1023u);
                u1 = u1 * 0x9e3779b1u + (0x80000000u * i1);
            } while (i0++ < 2u && p0);
            *q0 = (unsigned)((unsigned)h1 || 0x10000u);
            h0 = (short)(((2u / ((unsigned)(0u || (unsigned)x0) | 1u)) % (0xcc295bb5u | 1u)) + r0.x);
            do { if (--fuel == 0u) goto done;
                r0.y ^= (unsigned)((i2 - (unsigned)(w0 >> 29)) == (8u | garr[u2 & 7u]));
                if (budget != 0u) { budget -= 1u; u2 = fn1(r0.y, (g0 * (unsigned)((int)p0 < (int)(unsigned)d0)), (u3 % ((unsigned)w0 | 1u))); }
            } while (i0++ < 4u && (unsigned)d0);
            if (-(unsigned)((short)0x10000u > (signed char)(unsigned)h0)) goto L2;
        }
        if ((unsigned)(u2 == ((unsigned)l0 ^ p1))) goto done;
        if (((unsigned)((unsigned)(x0 >> 70) < 0x97192162u) % ((unsigned)b0 | 1u))) goto L1;
        if (0xc6f63e4fu) goto L3;
        if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)f0 | (unsigned)(u3 || (unsigned)b0)), (((unsigned)(x0 >> 70) | 1u) & 0x7fffffffu), (unsigned)!(unsigned)(i0 == u2)); }
    }
    switch ((g1 / ((unsigned)(w0 >> 29) | 1u)) & 7u) {
        l0 = (long)((unsigned long)l0 + ((unsigned)x0 - (0x80000000u + u1)));
        c0 = (unsigned char)(unsigned)c1;
        *q0 += (unsigned)((unsigned)((unsigned)(short)((unsigned)(8u < (unsigned)(w0 >> 29)) - g0) == *mp) && 0x6af51b5fu);
        *q0 += -(unsigned)((short)g1 > (signed char)fuel);
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((0x7fffffffu % ((v0 | garr[i1 & 7u]) | 1u)), (0x80000000u - r0.y), (unsigned)(unsigned char)(unsigned)((short)i1 > (signed char)(p0 + i1))); }
            d0 = d0 * 0.5 + (double)(((unsigned)(~((unsigned)s0 + (unsigned)w0) && u1) | (unsigned)(short)(8u << (0x7fffffffu & 31u))) & 1023u);
            x0 = x0 * 0x100000001b3ull + ((unsigned)(0x10000u || u0) << (0xbd20c66eu & 31u));
            garr[(unsigned)c0 & 7u] = (unsigned)(0xe7054068u && (*q0 >> ((unsigned)f0 & 31u)));
            switch (((0x7fffffffu ^ p2) & u2) & 7u) {
                x0 = x0 * 0x100000001b3ull + 0x2bf068b4u;
                r0.y ^= (u3 + (unsigned)((short)r0.y > (signed char)garr[u2 & 7u]));
            }
        } while (i0++ < 6u && (unsigned)x0);
        L3: if (--fuel == 0u) goto done;
    }
    while ((unsigned)((unsigned)h0 < (unsigned)h0)) { if (--fuel == 0u) goto done;
        if (v0) {
            e0 = e0 * 0.5L + (long double)(fuel & 1023u);
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(unsigned)(fuel || (unsigned)s0), -(fuel + (unsigned)s1), (unsigned)(short)(unsigned)((unsigned)f0 < (unsigned)e0)); }
                while (fuel) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (unsigned)((short)0x80000000u > (signed char)u0));
                }
                a0[(i1 + (unsigned)s0) & 3u] = a0[i0 & 3u];
                s0 = (int)(0x8fb3f0d3u ^ (0x715ae2b8u ? (unsigned)c0 : (fuel - g0)));
                if (((unsigned)((int)0x90cec7f3u >= (int)garr[u2 & 7u]) + i0)) break;
            }
        }
        u2 = u2 * 0x9e3779b1u + (0x18b63069u + (unsigned)b0);
        d0 = d0 * 0.5 + (double)(((unsigned)b0 << ((0x7fffffffu / (0u | 1u)) & 31u)) & 1023u);
        l0 = (long)((unsigned long)l0 + (*mp << ((unsigned)f0 & 31u)));
        if (-(unsigned)((unsigned)(0x7fffffffu || v0) && (unsigned)d0)) break;
    }
    L4: if (--fuel == 0u) goto done;
    if (9u) {
        goto L3;
        if ((0xffffffffu / (a0[u1 & 3u] | 1u))) goto L2;
        c0 = (unsigned char)(unsigned)(short)((unsigned)h0 << (p2 & 31u));
        if (fuel) goto L3;
        if (((unsigned)e0 << (a0[u1 & 3u] & 31u))) goto L2;
    }
    i0 = ((r0.x / ((unsigned)(short)((unsigned)l0 >> ((unsigned)c1 & 31u)) | 1u)) + r0.x) & 15u;
    h0 = (short)(p0 + ((unsigned)(7u == garr[i1 & 7u]) - (unsigned)((unsigned)w0 == 0x80000000u)));
    goto L1;
    if (-(0x10000u | ((unsigned)f0 / (5u | 1u)))) {
        if (garr[u2 & 7u]) {
            goto done;
            v0 = ((unsigned)((unsigned)x0 && -(0xda6162c8u - v0)) - 0x7fffffffu);
            switch ((garr[u2 & 7u] + (unsigned)((unsigned)h0 == (unsigned)c0)) & 7u) {
                if (a0[u1 & 3u]) goto done;
                a0[(unsigned)((int)3u < (int)0xd3343b46u) & 3u] = ((unsigned)((unsigned)w0 == (6u * r0.x)) >> ((i0 ^ 0x10000u) & 31u));
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)(x0 >> 70) < (unsigned)(0x3f3ef987u && 0x2e46bd51u)), m0, (unsigned)h1); }
                while (i0++ < 2u && 0x36e84d90u) { if (--fuel == 0u) goto done;
                    v0 = 9u;
                    case 7u: ;
                    if (budget != 0u) { budget -= 1u; u1 = fn1(a0[u1 & 3u], (unsigned)((unsigned)(*q0 < m0) || 0xc19692a7u), g1); }
                    r0.x = (unsigned)((unsigned)((int)0x7fffffffu < (int)u1) || (i2 << (0x78785686u & 31u)));
                }
                r0.x = 0x7fffffffu;
                if ((0x7fffffffu % (3u | 1u))) goto L3;
            }
            if ((8u ^ i2)) goto L1;
            { unsigned t2; double z2; if (((unsigned)h0) & 1u) { t2 = (u0 | (m0 >> (r0.y & 31u))); z2 = (double)((garr[i1 & 7u]) & 255u); } if (((unsigned)h0) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                v0 = (unsigned)((unsigned)d0 == (unsigned)x0);
                goto done;
                if (m0) goto L1;
                c1 = (signed char)-(u3 << ((0x10000u & 5u) & 31u));
                h0 = (short)(unsigned)h0;
                d0 = d0 * 0.5 + (double)(g0 & 1023u);
            }
        }
        f0 = f0 * 0.5f + (float)((unsigned)(a0[u1 & 3u] || (unsigned)((int)(i1 >> (i2 & 31u)) < (int)(unsigned)(short)(unsigned)((int)(unsigned)s1 >= (int)g1))) & 255u);
        { unsigned t3; double z3; if (((unsigned)((int)a0[i0 & 3u] < (int)garr[u2 & 7u])) & 1u) { t3 = (unsigned)((unsigned)(garr[u2 & 7u] == (unsigned)c0) < (unsigned)c1); z3 = (double)((0xe028b522u) & 255u); } if (((unsigned)((int)a0[i0 & 3u] < (int)garr[u2 & 7u])) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            *q0 += (unsigned)(p1 || (unsigned)((int)i0 < (int)garr[i1 & 7u]));
            *q0 += r0.y;
        }
        d0 = d0 * 0.5 + (double)((unsigned)((short)((unsigned)(unsigned char)(a0[u1 & 3u] ^ (unsigned)(signed char)(0xd24c57e0u >> ((unsigned)b0 & 31u))) % (fuel | 1u)) > (signed char)garr[i1 & 7u]) & 1023u);
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch (((unsigned)(w0 >> 29) % (u3 | 1u)) & 7u) {
                break; (void)(((unsigned)c1 << (g0 & 31u)));
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)c0 << ((unsigned)w0 & 31u)), p1, ((fuel << ((unsigned)l0 & 31u)) | a0[i0 & 3u])); }
                h1 = (unsigned short)(h1 + ((garr[i1 & 7u] >> ((unsigned)s1 & 31u)) + ((unsigned)(x0 >> 70) - u3)));
                if ((unsigned)l0) break;
                x0 = x0 * 0x100000001b3ull + u1;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)(0x7fffffffu == (unsigned)c0) < *q0), ((unsigned)x0 >> (6u & 31u)), (unsigned)(v0 || 6u)); }
            }
        }
        while (i0++ < 2u && 3u) { if (--fuel == 0u) goto done;
            if (fuel < 8u) return (unsigned)(unsigned char)((unsigned)f0 + ((unsigned)d0 & i0));
            break; (void)(-(unsigned)(p1 == 0x9c35db67u));
            a0[0x10000u & 3u] = (i0 / ((unsigned)l0 | 1u));
            c0 = (unsigned char)(unsigned)(unsigned char)((unsigned)e0 ? (unsigned)h1 : (6u << (p1 & 31u)));
        }
    } else {
        { unsigned t4; double z4; if (((unsigned)((int)(unsigned)(m0 < 0x9d5cd5eau) < (int)a0[u1 & 3u])) & 1u) { t4 = (unsigned)((g0 / ((unsigned)(w0 >> 29) | 1u)) || (unsigned)h0); z4 = (double)(((unsigned)((unsigned)((short)i1 > (signed char)0x25b991f0u) || 0x80000000u)) & 255u); } if (((unsigned)((int)(unsigned)(m0 < 0x9d5cd5eau) < (int)a0[u1 & 3u])) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                q0 = &garr[((9u ^ 7u) % ((unsigned)(signed char)((0x885eb4e5u * a0[i0 & 3u]) + 0x80000000u) | 1u)) & 7u];
                u0 += (0x80000000u | (unsigned)d0);
                while ((unsigned)(p0 == (unsigned)s0)) { if (--fuel == 0u) goto done;
                    if (a0[i0 & 3u]) break;
                    if (0xffffffffu) break;
                    d0 = d0 * 0.5 + (double)((unsigned)d0 & 1023u);
                    continue; (void)((a0[u1 & 3u] << ((unsigned)s1 & 31u)));
                    if ((u2 & ((unsigned)(w0 >> 29) >> (v0 & 31u)))) goto L2;
                    if ((unsigned)w0) break;
                }
            }
            if (~(i0 ^ ((unsigned)b0 | p0))) goto L3;
        }
        w0 = w0 * 6364136223846793005ull + ((unsigned)((int)(unsigned)(signed char)(unsigned)((int)6u < (int)(unsigned)h1) >= (int)*mp) - 5u);
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((m0 | u1) && (unsigned)l0), (unsigned)((unsigned)w0 || (unsigned)x0), (unsigned)(0u == (unsigned)e0)); }
        break; (void)(((unsigned)w0 - i1));
        if ((unsigned)((unsigned)b0 < u0)) break;
        if ((unsigned)d0) {
            if (budget != 0u) { budget -= 1u; u0 = fn0((a0[i0 & 3u] | p0), (i0 ^ (unsigned)(fuel || (unsigned)(w0 >> 29))), garr[i1 & 7u]); }
            b0 = (unsigned)c1 != 0u;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)(unsigned)w0 >= (int)~((unsigned)(w0 >> 29) | *q0)), (unsigned)h0, (unsigned)((int)v0 >= (int)(unsigned)h0)); }
        } else {
            while (i1++ < 6u && (unsigned)(r0.y || 0x7fffffffu)) { if (--fuel == 0u) goto done;
                { unsigned t5; double z5; if (((0x92142b4au ^ u2)) & 1u) { t5 = (unsigned)(short)(i1 << ((unsigned)s0 & 31u)); z5 = (double)((u3) & 255u); } if (((0x92142b4au ^ u2)) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                    u2 = (unsigned)(signed char)((unsigned)((unsigned)x0 || (0x8a87ff14u / (*q0 | 1u))) & (*q0 * 0x10000u));
                    e0 = e0 * 0.5L + (long double)(((unsigned)d0 * g0) & 1023u);
                    continue; (void)(((1u / ((unsigned)c1 | 1u)) - 0x10000u));
                    switch (0xbea8cedu & 7u) {
                        if (budget != 0u) { budget -= 1u; u1 = fn0(garr[i1 & 7u], (unsigned)((int)-(unsigned)(0xffffffffu < fuel) < (int)(unsigned)(w0 >> 29)), (u3 - v0)); }
                        if ((g0 - (p1 * u1))) {
                            case 3u: ;
                        }
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)0x6f296060u > (signed char)u3), (unsigned)(unsigned char)(unsigned)(u3 && ((unsigned)e0 | p2)), (v0 - (unsigned)l0)); }
                    }
                    u2 ^= (unsigned)((r0.x % (9u | 1u)) && u2);
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn1(p2, (unsigned)((short)(unsigned)c0 > (signed char)a0[u1 & 3u]), (unsigned)((int)1u < (int)(unsigned)c1)); }
                        f0 = f0 * 0.5f + (float)((unsigned)s0 & 255u);
                        if (u3 == 7u) return (i0 | (unsigned)(x0 >> 70));
                        m0 ^= (0x6e242439u | (unsigned)(0x7fffffffu == u0));
                        if (((unsigned)c1 * (0x80000000u & 0x99d27bbbu))) break;
                    } while (i2++ < 3u && ((unsigned)((unsigned)b0 == 0x80000000u) * (unsigned)s0));
                }
                *mp = (u0 - g1);
                do { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return ~((6u << (0x30aba56eu & 31u)) ^ 8u);
                    if ((r0.y | (*mp << (0x4fb71d8du & 31u)))) goto done;
                    c1 = (signed char)(unsigned)(signed char)(i1 - g0);
                } while (i2++ < 7u && 5u);
            }
            while ((i2 - r0.y)) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)!(((unsigned)!(u1 % (a0[i0 & 3u] | 1u)) | (unsigned)s0) | ((unsigned)d0 ^ p1)) & 1023u);
                if (0x6a8af1e1u) continue;
                switch ((unsigned)h0 & 7u) {
                    u1 += (unsigned)s1;
                }
                s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)(*mp || (*mp * i2)) < (int)*mp));
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(7u << ((unsigned)h0 & 31u)), (unsigned)((int)r0.x >= (int)garr[u2 & 7u]), ((unsigned)(w0 >> 29) / ((unsigned)w0 | 1u))); }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn1(0xffffffffu, ((unsigned)(0x10000u || m0) + (unsigned)b0), (2u >> ((unsigned)h1 & 31u))); }
        }
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)(short)(unsigned)(*q0 < p2) == garr[i1 & 7u])) {
                    c1 = (signed char)((unsigned)f0 & 0xd8a76541u);
                    a0[~(0x7fffffffu - u3) & 3u] = (0x68e3d568u % ((unsigned)((short)(unsigned)h1 > (signed char)1u) | 1u));
                    h0 = (short)((*mp & 0xc3bcd2dfu) ^ ((unsigned)((unsigned)x0 < 0xc4d851dau) >> (i1 & 31u)));
                    if ((3u | 0x52f378bu)) break;
                    e0 = e0 * 0.5L + (long double)((u2 >> (i2 & 31u)) & 1023u);
                    if (0x140c128fu) {
                        goto L4;
                        if ((v0 * 3u)) goto L2;
                        do { if (--fuel == 0u) goto done;
                            e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)b0 < r0.y) & 1023u);
                            break; (void)((unsigned)((int)(unsigned)d0 >= (int)(0x368a8521u * 9u)));
                            v0 = (5u << ((a0[i0 & 3u] ? (unsigned)c0 : a0[u1 & 3u]) & 31u));
                            if (budget != 0u) { budget -= 1u; u0 = fn1(1u, (((unsigned)c0 & (unsigned)b0) | (unsigned)w0), ((8u % (u1 | 1u)) | a0[i0 & 3u])); }
                        } while (i0++ < 7u && (unsigned)((int)(unsigned)((unsigned)l0 || *q0) < (int)(unsigned)l0));
                        if ((unsigned)w0) break;
                    }
                }
                m0 ^= ((unsigned)s0 - u0);
            }
            break; (void)(((unsigned)((int)garr[i1 & 7u] < (int)u3) << (u3 & 31u)));
            if (~(garr[u2 & 7u] ^ 7u)) break;
            if (fuel) break;
            while (i2++ < 5u && *q0) { if (--fuel == 0u) goto done;
                a0[(unsigned)((unsigned)c0 && p2) & 3u] = (r0.y % ((unsigned)(unsigned char)(p2 - (unsigned)c0) | 1u));
                if ((unsigned)((unsigned)l0 || i0)) break;
                g0 = (unsigned)e0;
                if (budget != 0u) { budget -= 1u; u1 = fn0((u0 - 1u), (garr[i1 & 7u] << ((unsigned)((int)u3 >= (int)i1) & 31u)), (unsigned)((int)0xc8afd78bu < (int)(0x7fffffffu - 0x7fffffffu))); }
                if ((unsigned)((int)p2 >= (int)1u)) break;
                s1 = (int)((unsigned)s1 + ~(unsigned)((int)p1 < (int)((0x7bb1a7dau / (m0 | 1u)) << (0xe15ed187u & 31u))));
            }
        }
    }
    if (8u) goto L0;
    if ((unsigned)(unsigned char)(unsigned)(r0.x || 5u)) {
        w0 ^= (unsigned long long)0xffffffffu << (m0 & 63u);
    } else {
        if (0xffffffffu) {
            s1 = (int)((unsigned)s1 + (unsigned)(signed char)(0xbdd7778eu >> (~(unsigned)(0x10000u && 0x66b4fb02u) & 31u)));
            if (budget != 0u) { budget -= 1u; u1 = fn0((r0.y + (unsigned)c0), u1, a0[i0 & 3u]); }
            m0 ^= (unsigned)((int)(unsigned)((unsigned)(x0 >> 70) && (unsigned)f0) < (int)(p2 / (0x10000u | 1u)));
        } else {
            if ((unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)(i2 || (unsigned)b0))) goto L1;
            goto L3;
            if ((unsigned)s1) goto L1;
            s0 = (int)i1;
        }
        if (u3 == 7u) return ((unsigned)(2u && 0x7fffffffu) | (unsigned)!(unsigned)((short)(unsigned)s1 > (signed char)m0));
    }
    if ((unsigned)x0) goto L4;
    if ((unsigned)d0) goto L3;
    goto done;
    if ((unsigned)(0xf574b0b4u && ((unsigned)d0 * 8u))) goto L2;
    x0 = x0 * 0x100000001b3ull + (1u + 8u);
    g1 += ((unsigned)x0 % (((unsigned)(fuel || (0x6045330cu * 1u)) / (9u | 1u)) | 1u));
    while (i0++ < 4u && ((unsigned)s1 - (unsigned)(a0[u1 & 3u] < fuel))) { if (--fuel == 0u) goto done;
        if ((unsigned)!((unsigned)(a0[u1 & 3u] < u2) << (2u & 31u))) break;
        if (((unsigned)l0 + 0x80000000u)) break;
        garr[((unsigned)c1 + (unsigned)x0) & 7u] = (((r0.y / (0xffffffffu | 1u)) ? g1 : r0.y) * a0[i0 & 3u]);
        if (0x80000000u) {
            if ((unsigned)(((unsigned)h1 | r0.y) < a0[u1 & 3u])) break;
            h0 = (short)2u;
            v0 = (fuel << ((unsigned)d0 & 31u));
            { unsigned t6; double z6; if (((unsigned)(w0 >> 29)) & 1u) { t6 = (unsigned)((int)(unsigned)h1 >= (int)(unsigned)!(0xffffffffu >> (0x80000000u & 31u))); z6 = (double)(((unsigned)e0) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                i2 = ((unsigned)l0 & fuel) & 15u;
                if ((unsigned)l0) break;
                switch (2u & 7u) {
                    case 3u: ;
                    w0 ^= (unsigned long long)0xc72a7312u << ((unsigned)(u0 == (unsigned)(fuel && 1u)) & 63u);
                    case 6u: ;
                    if ((0xd96ccbcu ? a0[i0 & 3u] : 0x2b1e42feu)) continue;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)6u < (int)u1), ((unsigned)e0 ? (unsigned)(w0 >> 29) : (unsigned)(w0 >> 29)), (unsigned)s1); }
                if (u3 == 7u) return m0;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1((v0 << (v0 & 31u)), (unsigned)((a0[i0 & 3u] | u3) || u2), fuel); }
            if ((unsigned)((0x7fffffffu % (v0 | 1u)) || 0x4ab7512au)) break;
        } else {
            if (5u) break;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)e0 && (unsigned)(short)(unsigned)((short)u2 > (signed char)8u)), ((0xffffffffu << ((unsigned)s1 & 31u)) & r0.y), a0[i0 & 3u]); }
        if (a0[i0 & 3u]) goto L4;
    }
    v0 = g0;
    i1 = ((0x7fffffffu << ((unsigned)f0 & 31u)) | 0x1fd14a5u) & 15u;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = (unsigned)(g0 || (unsigned)f0);
    }
    goto L0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((v0 >> (u1 & 31u))) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((0x4aa858f8u % (u1 | 1u)), (unsigned)((short)(unsigned)s0 > (signed char)((unsigned)x0 & 8u)), (unsigned)((int)i2 >= (int)u3)); }
    }
    { unsigned t0; double z0; if ((((unsigned)((int)(unsigned)b0 < (int)(unsigned)(x0 >> 70)) * u3)) & 1u) { t0 = r0.x; z0 = (double)(((unsigned)b0) & 255u); } if ((((unsigned)((int)(unsigned)b0 < (int)(unsigned)(x0 >> 70)) * u3)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        u3 += ((unsigned)((int)*q0 < (int)(unsigned)h1) - 0xac98d253u);
        s0 = (int)(unsigned)(0xe8822cc0u < (unsigned)((short)((unsigned)d0 << ((unsigned)s1 & 31u)) > (signed char)u3));
        u1 ^= *mp;
    }
    goto L0;
    if (*mp) {
        if (fuel < 8u) return (unsigned)((short)(unsigned)x0 > (signed char)(0x29983577u / (r0.y | 1u)));
        q0 = &garr[(unsigned)(short)((0x10000u & garr[i1 & 7u]) - ((unsigned)d0 % (r0.x | 1u))) & 7u];
        r0.x = ((unsigned)((short)*q0 > (signed char)(fuel / (fuel | 1u))) & g1);
        *q0 += (a0[i0 & 3u] | (unsigned)((9u >> (garr[u2 & 7u] & 31u)) < 2u));
    }
    while (i0++ < 3u && (unsigned)(signed char)(unsigned)((4u + p1) == m0)) { if (--fuel == 0u) goto done;
        a0[3u & 3u] = (-(unsigned)((int)9u < (int)garr[i1 & 7u]) << ((g1 & 5u) & 31u));
        { unsigned t1; double z1; if (((p0 << ((unsigned)(x0 >> 70) & 31u))) & 1u) { t1 = (unsigned)((0xffffffffu | r0.y) || 4u); z1 = (double)((((unsigned)(w0 >> 29) / (2u | 1u))) & 255u); } if (((p0 << ((unsigned)(x0 >> 70) & 31u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            u2 = u2 * 0x9e3779b1u + ((unsigned)(0xffffffffu && (unsigned)e0) & 9u);
            if (0x11f46416u) break;
            c0 = (unsigned char)((unsigned)(0x10000u == g1) % ((unsigned)((int)(unsigned)s1 >= (int)6u) | 1u));
            *q0 += ((unsigned)c1 << ((unsigned)((unsigned)((int)(unsigned)h0 >= (int)0x6c0137eau) < (unsigned)c0) & 31u));
            i0 = (unsigned)((int)i1 < (int)(unsigned)((int)garr[i1 & 7u] < (int)(unsigned)e0)) & 15u;
        }
        goto L2;
        switch (((unsigned)h1 | (unsigned)e0) & 7u) {
            if ((*mp + a0[u1 & 3u])) {
                case 4u: ;
                l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)(garr[u2 & 7u] || v0) % (i0 | 1u)) == (unsigned)(x0 >> 70)));
            }
        }
        if ((p1 << ((r0.x & p0) & 31u))) break;
        s1 = (int)((unsigned)s1 + (unsigned)((int)(r0.y / (0x7fffffffu | 1u)) < (int)(unsigned)(fuel < a0[u1 & 3u])));
    }
    r0.y ^= (unsigned)(short)(unsigned)((0x87a183au / (0xffffffffu | 1u)) && ((unsigned)x0 * 0x7fffffffu));
    { unsigned t2; double z2; if ((((unsigned)((int)0xffffffffu < (int)(unsigned)s0) | u1)) & 1u) { t2 = 0xbfc766ddu; z2 = (double)(((i2 & (unsigned)h0)) & 255u); } if ((((unsigned)((int)0xffffffffu < (int)(unsigned)s0) | u1)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        if (budget != 0u) { budget -= 1u; u3 = fn1(-((a0[i0 & 3u] | i0) << (r0.y & 31u)), (unsigned)((unsigned)s1 == r0.x), ~(i2 << ((unsigned)s1 & 31u))); }
    }
    while (i0++ < 5u && (unsigned)h0) { if (--fuel == 0u) goto done;
        if ((3u + (unsigned)c1)) continue;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0(p0, a0[u1 & 3u], (unsigned)(i2 || 0x10000u)); }
    if ((unsigned)(u0 || u1)) goto L1;
    goto L2;
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)1u < (int)(unsigned)l0);
    if ((unsigned)(signed char)((r0.y & fuel) * fuel)) {
        if (v0) {
            u0 = (unsigned)((int)i2 < (int)(unsigned)((int)(unsigned)s0 >= (int)0x4fbfe488u));
            if (fuel < 8u) return (~((unsigned)h1 >> (~((unsigned)b0 % (0xc009a56fu | 1u)) & 31u)) & (unsigned)(0xffffffffu == r0.x));
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((unsigned)(w0 >> 29) < (unsigned)f0) || *q0);
            v0 = 0x54dce6ceu;
            c1 = (signed char)(unsigned)(0x80000000u < (unsigned)h0);
            if ((unsigned)(fuel || ((unsigned)c0 | (unsigned)h0))) goto L4;
        } else {
            if ((unsigned)c0) {
                h1 = (unsigned short)(h1 + (unsigned)!((unsigned)l0 << (7u & 31u)));
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)h0 - (unsigned)(signed char)(unsigned)((unsigned)(x0 >> 70) < (unsigned)h0)), (0x10000u ? u3 : fuel), (p1 + (*q0 % (0x92e91446u | 1u)))); }
                h0 = (short)(unsigned)(unsigned char)(0xb415f799u + (garr[i1 & 7u] * m0));
            } else {
                L0: if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)((int)0xffffffffu < (int)(unsigned)f0) && a0[u1 & 3u])) goto L4;
                if ((garr[i1 & 7u] | 0x7269561cu)) goto L1;
                r0.x = 0xffffffffu;
            }
            if ((u1 ^ (unsigned)(signed char)((unsigned)(w0 >> 29) & 0u))) goto L0;
            goto done;
        }
        goto L2;
        L1: if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)w0 < (int)(unsigned)b0)) goto L0;
        d0 = d0 * 0.5 + (double)((unsigned)((0x93f47510u / (g0 | 1u)) || (unsigned)e0) & 1023u);
        w0 ^= (unsigned long long)(0u / (g1 | 1u)) << (((p2 / ((unsigned)(w0 >> 29) | 1u)) ^ a0[i0 & 3u]) & 63u);
    }
    do { if (--fuel == 0u) goto done;
        if (u3 == 7u) return ((unsigned)(i0 == (unsigned)(w0 >> 29)) / ((unsigned)f0 | 1u));
        if (~(7u | (0x87ef3a7eu + 6u))) break;
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)w0, g1, 2u); }
            do { if (--fuel == 0u) goto done;
                q0 = &garr[(0xd0d65bdau >> (~(unsigned)((int)(unsigned)l0 >= (int)r0.x) & 31u)) & 7u];
                if (u2) {
                    r0.y ^= (unsigned)((short)*q0 > (signed char)((unsigned)(0x80000000u == 0xacb2ba1eu) * (i0 & (unsigned)e0)));
                    if (a0[u1 & 3u]) break;
                    switch ((4u & 0x112444c7u) & 7u) {
                        if ((unsigned)((unsigned)(x0 >> 70) || a0[u1 & 3u])) continue;
                        if ((unsigned)(short)((unsigned)!(unsigned)((short)0x58a82f64u > (signed char)garr[i1 & 7u]) ^ (unsigned)(x0 >> 70))) continue;
                        if ((unsigned)!(r0.y - u2)) {
                            u1 ^= (unsigned)(unsigned char)((0x91bbd17cu - 0x485a5475u) >> ((unsigned)((int)a0[u1 & 3u] >= (int)((unsigned)c1 & 0x80000000u)) & 31u));
                            if (budget != 0u) { budget -= 1u; u3 = fn2((1u / (garr[i1 & 7u] | 1u)), i0, 6u); }
                            case 6u: ;
                            s0 = (int)((u1 << ((unsigned)f0 & 31u)) & (unsigned)((int)i0 < (int)v0));
                            r0.y ^= (a0[u1 & 3u] * (unsigned)((int)0x4b7e1108u < (int)(unsigned)(w0 >> 29)));
                        } else {
                            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(p0 || g1), (i1 | (g0 % (i1 | 1u))), (unsigned)((int)0x5a5db1a3u >= (int)u3)); }
                        }
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn1((7u | r0.x), (unsigned)((unsigned)c1 || (unsigned)((int)0x10000u < (int)(unsigned)w0)), (unsigned)((i2 * v0) < 0xb64f867du)); }
                }
                w0 = w0 * 6364136223846793005ull + ((unsigned)((int)r0.x >= (int)((unsigned)(x0 >> 70) + 0xfed119e3u)) & (unsigned)(0x7fffffffu && *mp));
                if ((fuel << (((unsigned)c1 ^ garr[i1 & 7u]) & 31u))) continue;
                if ((unsigned)(signed char)((unsigned)c1 << (-(a0[u1 & 3u] | (unsigned)(w0 >> 29)) & 31u))) break;
                b0 = (unsigned)f0 != 0u;
            } while (i2++ < 3u && 0x80000000u);
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(-(unsigned)((unsigned)(a0[u1 & 3u] && (unsigned)s0) || 0x6ce6076cu));
                garr[(unsigned)(0xb363cba0u == g1) & 7u] = 4u;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(unsigned char)(unsigned)(0x10000u && u3), *q0, (unsigned)(signed char)((unsigned)w0 >> (0x527e0228u & 31u))); }
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)s0, (unsigned)(unsigned char)(unsigned)((int)*mp < (int)(unsigned)c0), (unsigned)((int)(unsigned)h1 >= (int)(9u % (0xffffffffu | 1u)))); }
                for (;;) { if (--fuel == 0u) goto done;
                    r0.y ^= 8u;
                    u2 += (unsigned)!(u2 ^ (unsigned)(9u && u1));
                    if ((i2 - u2)) continue;
                }
                w0 ^= (unsigned long long)(unsigned)(r0.y < (unsigned)b0) << ((unsigned)(g0 && (unsigned)((int)g0 < (int)(unsigned)l0)) & 63u);
            }
            s1 = (int)((unsigned)s1 + (unsigned)(u3 || a0[i0 & 3u]));
            while (i2++ < 4u && ((v0 / (p1 | 1u)) & (unsigned)h1)) { if (--fuel == 0u) goto done;
                r0.x = ~(unsigned)((short)(unsigned)(short)(unsigned)((short)u2 > (signed char)i2) > (signed char)(unsigned)s0);
                if ((0xe6938d76u ^ (unsigned)d0)) break;
                switch ((unsigned)(short)(unsigned)((int)g1 < (int)*q0) & 7u) {
                    L2: if (--fuel == 0u) goto done;
                    if ((5u | 0x1f59ccbbu)) {
                        f0 = f0 * 0.5f + (float)(((unsigned)h0 << ((unsigned)x0 & 31u)) & 255u);
                        case 1u: ;
                        m0 ^= (unsigned)(*q0 == (unsigned)(((unsigned)x0 & v0) || i1));
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(short)(unsigned)(u2 || 3u), ((unsigned)c1 | a0[i0 & 3u]), (*mp & u0)); }
                        continue; (void)(((unsigned)e0 | ((unsigned)h0 & (unsigned)s0)));
                    } else {
                        if (((unsigned)((unsigned)h0 == garr[i1 & 7u]) + 0x7fffffffu)) goto L0;
                        break; (void)((unsigned)((unsigned)(g1 == (unsigned)x0) && 7u));
                        goto L3;
                        u0 = u0 * 0x9e3779b1u + (u1 ? 0x2e97df5eu : fuel);
                    }
                    h1 = (unsigned short)(h1 + g1);
                    if ((g1 ^ (unsigned)w0)) {
                        default: ;
                        v0 = u1;
                        if (budget != 0u) { budget -= 1u; u3 = fn2(p0, (unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)9u < (int)(unsigned)e0) < (int)garr[i1 & 7u]), ~(garr[i1 & 7u] ^ (0xfd189688u * *q0))); }
                        if ((unsigned)(short)(((unsigned)h1 ^ u2) | i0)) break;
                    } else {
                        L3: if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((0x9a214868u ^ u2), (v0 | i2), ((r0.x & a0[u1 & 3u]) ^ 0xb022b8a6u)); }
                        u0 += i2;
                        u1 = ((r0.y ? (unsigned)((unsigned)e0 && i0) : 8u) / ((unsigned)c1 | 1u));
                    }
                    s0 = (int)2u;
                }
                do { if (--fuel == 0u) goto done;
                    r0.x = (((unsigned)b0 | i1) + (unsigned)s1);
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)(unsigned)f0 > (signed char)*q0), (unsigned)((int)(unsigned)h1 < (int)i1), (unsigned)(signed char)(0x10000u >> ((0xffffffffu << ((unsigned)f0 & 31u)) & 31u))); }
                    l0 = (long)((unsigned long)l0 + (a0[u1 & 3u] >> (0xb5fe15c6u & 31u)));
                    c0 = (unsigned char)(unsigned)(short)((unsigned)(u3 && garr[i1 & 7u]) >> ((unsigned)f0 & 31u));
                    g1 += (p2 ? 0u : v0);
                } while (i0++ < 2u && (unsigned)(signed char)(unsigned)((unsigned)((int)0xffffffffu < (int)(unsigned)d0) && (unsigned)w0));
            }
        }
        g1 += (unsigned)(unsigned char)((0x884fae8u + u3) * (unsigned)c1);
        if (((unsigned)w0 << (p1 & 31u))) break;
    } while (i0++ < 6u && ~(i0 >> (g0 & 31u)));
    if ((unsigned)e0) {
        r0.y ^= (((0x7fffffffu - 0xbb9a70aau) >> (5u & 31u)) ^ 2u);
    }
    u1 = 9u;
    do { if (--fuel == 0u) goto done;
        u1 ^= (unsigned)!(m0 / ((unsigned)((short)u1 > (signed char)(unsigned)c0) | 1u));
        while (i1++ < 2u && (unsigned)(short)(unsigned)(0x10000u < i1)) { if (--fuel == 0u) goto done;
            { unsigned t3; double z3; if (((p0 / ((unsigned)h1 | 1u))) & 1u) { t3 = a0[i0 & 3u]; z3 = (double)((((unsigned)c1 / (((unsigned)l0 & g0) | 1u))) & 255u); } if (((p0 / ((unsigned)h1 | 1u))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)*mp >= (int)0x7fffffffu), 1u, (unsigned)(((unsigned)s0 - m0) < (unsigned)c0)); }
                { unsigned t4; double z4; if (((unsigned)(short)(1u - 0xffffffffu)) & 1u) { t4 = (((unsigned)b0 | 0x8bc0cf7bu) << (r0.y & 31u)); z4 = (double)((0x591f557eu) & 255u); } if (((unsigned)(short)(1u - 0xffffffffu)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        q0 = &garr[(unsigned)(((unsigned)e0 & 4u) && (0x9d280185u % (((unsigned)x0 ^ 2u) | 1u))) & 7u];
                        L4: if (--fuel == 0u) goto done;
                        if ((unsigned)(0xffffffffu && p2)) break;
                    }
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        garr[(unsigned)(signed char)(0x83f35fbcu | i0) & 7u] = (unsigned)(signed char)((unsigned)(w0 >> 29) + p1);
                        if (0x2b13c6eau) goto L0;
                    }
                    if ((unsigned)((int)(unsigned)((int)p1 < (int)u0) >= (int)u1)) break;
                    if (m0) break;
                    s0 = (int)*mp;
                }
                break; (void)(((unsigned)(x0 >> 70) << (6u & 31u)));
            }
            s0 = (int)(unsigned)(short)(0x9a4fdc57u + (unsigned)(p1 || (unsigned)h1));
            while (i2++ < 2u && (unsigned)((a0[i0 & 3u] ^ p1) < 0x80000000u)) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    if ((a0[u1 & 3u] - (unsigned)c0)) continue;
                    if (-((p0 - 0x529ee425u) | 0x10000u)) break;
                    if (((a0[i0 & 3u] * i0) ^ 0x7fffffffu)) continue;
                    *q0 = (unsigned)(u0 && p0);
                    if (0x5a597ca9u) break;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn0((0x5f4e9ac1u ^ (unsigned)((int)(unsigned)l0 >= (int)(unsigned)e0)), (r0.x ? 0xa84c2cbbu : u1), ((p1 | garr[u2 & 7u]) % (a0[i0 & 3u] | 1u))); }
                switch ((unsigned)!(i1 / (g0 | 1u)) & 7u) {
                    c0 = (unsigned char)(6u << (0xffffffffu & 31u));
                    case 2u: ;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(((0x2f23a2b2u | i1) ^ 0x3c93dd69u), (unsigned)(x0 >> 70), (0x58a5d08au + (unsigned)((short)(unsigned)e0 > (signed char)u3))); }
                    r0.x = (unsigned)(unsigned char)(unsigned)((int)r0.x >= (int)9u);
                    garr[(unsigned)((int)p1 >= (int)r0.y) & 7u] = garr[u2 & 7u];
                }
            }
            if ((unsigned)s1) goto done;
            if (garr[i1 & 7u]) break;
            u2 += ((unsigned)!((unsigned)w0 | p2) - (unsigned)(0xffffffffu && m0));
        }
        if ((unsigned)s0) break;
    } while (i0++ < 2u && (unsigned)((unsigned)((short)0x66d5fad8u > (signed char)fuel) < *mp));
    g1 += (unsigned)((int)(unsigned)h1 < (int)r0.y);
    i2 = ((unsigned)h1 + 7u) & 15u;
    switch ((unsigned)h1 & 7u) {
        case 7u: ;
        u1 = u1 * 0x9e3779b1u + (unsigned)(signed char)((2u | *mp) ^ (unsigned)(0x13fe8855u && *mp));
        if (fuel < 8u) return ((unsigned)e0 ^ (unsigned)(0xcc6aea10u == ((unsigned)e0 ^ (unsigned)s0)));
    }
    while (i0++ < 2u && (8u | (unsigned)((int)r0.y >= (int)0x76579320u))) { if (--fuel == 0u) goto done;
        if ((unsigned)(p1 < (unsigned)x0)) {
            if (((p0 % ((unsigned)(w0 >> 29) | 1u)) << (v0 & 31u))) break;
            break; (void)((unsigned)(((unsigned)l0 * garr[u2 & 7u]) < (unsigned)c1));
        } else {
            a0[(unsigned)(0u == r0.x) & 3u] = ((unsigned)((short)0x215f679au > (signed char)m0) >> ((unsigned)((short)(unsigned)e0 > (signed char)((unsigned)c1 + r0.y)) & 31u));
            u2 = (unsigned)((int)m0 < (int)p1);
            while (i1++ < 6u && (g1 ? garr[i1 & 7u] : (unsigned)b0)) { if (--fuel == 0u) goto done;
                a0[(0x286d260fu ^ 0xffffffffu) & 3u] = (unsigned)((unsigned)b0 && (unsigned)((short)g0 > (signed char)(unsigned)(short)(unsigned)((int)4u < (int)g1)));
                s1 = (int)((unsigned)s1 + (fuel ? (unsigned)(short)(unsigned)((short)0x11c3b3bbu > (signed char)*mp) : ((unsigned)h0 ^ garr[u2 & 7u])));
                goto L3;
                if (((unsigned)(w0 >> 29) ? i0 : r0.y)) break;
            }
            w0 ^= (unsigned long long)(8u % (i2 | 1u)) << (-((unsigned)l0 + p1) & 63u);
        }
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((0xaa9a4619u - (unsigned)((unsigned)d0 || 5u)) & 7u) {
            if ((unsigned)((unsigned)s0 || 4u)) break;
            if ((unsigned)(g0 < a0[i0 & 3u])) {
                i2 = (unsigned)e0 & 15u;
                if ((unsigned)(p1 < 0xd53bbe9eu)) goto L2;
                r0.x = (((r0.y & 0xb311f40bu) - 0xba63ad2bu) * (unsigned)(p2 == (unsigned)(w0 >> 29)));
                s1 = (int)((unsigned)s1 + (unsigned)((unsigned)c1 == ((unsigned)l0 ? (unsigned)(x0 >> 70) : 0x10000u)));
                if (*q0) continue;
                if ((unsigned)(signed char)(i2 & 0x6dcd50a7u)) {
                    s1 = (int)((unsigned)s1 + ((unsigned)(~(unsigned)((unsigned)(w0 >> 29) && (unsigned)s0) == garr[u2 & 7u]) ? p0 : (unsigned)(x0 >> 70)));
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        case 1u: ;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)((unsigned)d0 + ((unsigned)b0 >> (0xffffffffu & 31u))), (unsigned)(short)(unsigned)((int)(3u - 0xc7c6c167u) < (int)9u), (unsigned)(p2 == 0xfbfa2c83u)); }
                        r0.x = ((unsigned)((int)(unsigned)h1 >= (int)(p2 ^ (unsigned)x0)) ? 0xda254f60u : v0);
                    }
                    u3 ^= (g0 | 0x80000000u);
                    if ((unsigned)((unsigned)l0 || (unsigned)(unsigned char)(0x5d8cc72cu / (0x80000000u | 1u)))) {
                        case 3u: ;
                        v0 = 0xf9861021u;
                        h0 = (short)((a0[i0 & 3u] % ((0xffffffffu * 6u) | 1u)) << ((r0.y & 5u) & 31u));
                        *q0 += (v0 - i1);
                    } else {
                        u1 += ((unsigned)((short)0xffffffffu > (signed char)(unsigned)((int)0x28dfc0bcu >= (int)(unsigned)b0)) & p2);
                        f0 = f0 * 0.5f + (float)(u2 & 255u);
                    }
                    l0 = (long)((unsigned long)l0 + (unsigned)(0x9d130fafu == ~((unsigned)b0 + (unsigned)s0)));
                    if ((unsigned)((int)5u < (int)fuel)) break;
                } else {
                    h0 = (short)(p1 * ((unsigned)b0 - 0xffffffffu));
                    c0 = (unsigned char)(unsigned)((short)(unsigned)(unsigned char)((unsigned)h0 << ((unsigned)s0 & 31u)) > (signed char)0x96fc70bu);
                    garr[0x33068de9u & 7u] = u2;
                }
            }
            r0.x = (unsigned)((unsigned)((int)(unsigned)h1 < (int)(unsigned)s1) && ((unsigned)((unsigned)l0 < u1) & (unsigned)x0));
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)w0 ? garr[u2 & 7u] : 5u), (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)b0), ((unsigned)h1 + (i2 * fuel))); }
            case 0u: ;
        }
    }
    goto done;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        u1 ^= (unsigned)((8u << (r0.x & 31u)) && 0xba61e57du);
        b0 = (unsigned)((unsigned)e0 == -(unsigned)((short)*q0 > (signed char)6u)) != 0u;
        a0[(a0[u1 & 3u] / (u3 | 1u)) & 3u] = ((unsigned)c1 ^ (unsigned)(4u || 0x80000000u));
        if (~(unsigned)((*q0 + (unsigned)f0) || u1)) goto L0;
        if ((unsigned)((int)*mp >= (int)u3)) {
            { unsigned t5; double z5; if ((0xffffffffu) & 1u) { t5 = (6u / (0x451f4ec4u | 1u)); z5 = (double)(((v0 * 0x2607aaa7u)) & 255u); } if ((0xffffffffu) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                h0 = (short)(unsigned)(unsigned char)(u3 | (unsigned)(unsigned char)(fuel ^ 0x10000u));
                if ((unsigned)(0u == (unsigned)(short)(unsigned)((int)p0 >= (int)u2))) break;
            }
            if ((m0 + (unsigned)f0)) continue;
        }
        e0 = e0 * 0.5L + (long double)((a0[i0 & 3u] % ((unsigned)(w0 >> 29) | 1u)) & 1023u);
    }
    r0.y ^= u2;
    b0 = (unsigned)(2u == (0xf08ac9eu | (0x566235ceu / (3u | 1u)))) != 0u;
    switch ((unsigned)x0 & 7u) {
        do { if (--fuel == 0u) goto done;
            case 2u: ;
            if (p0) continue;
            switch ((unsigned)((int)(unsigned)c0 < (int)(unsigned)s0) & 7u) {
                if ((v0 | (u2 % (v0 | 1u)))) goto L4;
                case 6u: ;
                g0 = (0xffffffffu + (unsigned)e0);
            }
            w0 = w0 * 6364136223846793005ull + ((unsigned)(*mp < (unsigned)((unsigned)(0xde7d0ad7u && a0[u1 & 3u]) < g0)) * u0);
            u2 = u2 * 0x9e3779b1u + (u0 - 0x80000000u);
        } while (i0++ < 5u && (1u - p1));
        u3 ^= ~((unsigned)x0 | (unsigned)c1);
        if ((0x20e27569u << (3u & 31u))) {
            if ((unsigned)((short)0x72621d00u > (signed char)(garr[i1 & 7u] % (0x65eccb46u | 1u)))) goto L4;
            if (~(unsigned)((int)(unsigned)((short)4u > (signed char)2u) >= (int)0x38fe6ee1u)) {
                u2 += -(unsigned)((unsigned)x0 && (unsigned)e0);
                if ((unsigned)((7u + (unsigned)(x0 >> 70)) || (unsigned)(x0 >> 70))) goto L3;
                w0 ^= (unsigned long long)*q0 << ((unsigned)((unsigned)(a0[u1 & 3u] || u3) && ((unsigned)(signed char)((unsigned)d0 << (0x169ac467u & 31u)) | (unsigned)(w0 >> 29))) & 63u);
                break; (void)((0x7fffffffu << ((unsigned)s1 & 31u)));
            }
            while (i0++ < 7u && (unsigned)(unsigned char)(i0 + i1)) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)b0 & 1023u);
                g1 += (unsigned)(*mp == (0x80000000u ? 2u : 0x7fffffffu));
                case 0u: ;
            }
            u1 = u1 * 0x9e3779b1u + (unsigned)((int)(unsigned)((int)0x40d08c67u >= (int)p1) < (int)(unsigned)(x0 >> 70));
            u2 = (unsigned)(x0 >> 70);
        } else {
            w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(unsigned)(((unsigned)h0 >> (fuel & 31u)) || a0[u1 & 3u]);
            case 3u: ;
        }
    }
    if (((unsigned)d0 + u3)) {
        if ((unsigned)x0) goto L3;
        e0 = e0 * 0.5L + (long double)(((p0 % ((unsigned)d0 | 1u)) ? u0 : *mp) & 1023u);
    } else {
        l0 = (long)((unsigned long)l0 + ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)d0) >> ((((unsigned)s0 / (a0[u1 & 3u] | 1u)) * 0x23d868du) & 31u)));
    }
    switch ((6u - (unsigned)(signed char)(unsigned)(u1 && i1)) & 7u) {
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((int)r0.x < (int)m0), (unsigned)w0, ((unsigned)d0 % (a0[u1 & 3u] | 1u))); }
        u3 = u3 * 0x9e3779b1u + (unsigned)((short)fuel > (signed char)(unsigned)(1u && (u2 + 7u)));
        do { if (--fuel == 0u) goto done;
            case 7u: ;
            b0 = ~(unsigned)((int)(unsigned)l0 >= (int)(unsigned)h1) != 0u;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(signed char)(unsigned)((short)(unsigned)(short)((unsigned)c0 % ((unsigned)c0 | 1u)) > (signed char)(unsigned)b0), u0, (unsigned)(0xdf0a4f6eu && 7u)); }
            if (u3 == 7u) return u1;
            *q0 = (unsigned)h1;
            do { if (--fuel == 0u) goto done;
                if (0x1957ac27u) goto L3;
                goto done;
                r0.y ^= -(3u + 6u);
                *q0 += g1;
                { unsigned t6; double z6; if (((u2 >> (((unsigned)e0 >> ((unsigned)h1 & 31u)) & 31u))) & 1u) { t6 = 0xf4fee66au; z6 = (double)(((unsigned)((unsigned)l0 && (unsigned)b0)) & 255u); } if (((u2 >> (((unsigned)e0 >> ((unsigned)h1 & 31u)) & 31u))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                    if ((unsigned)((int)v0 < (int)7u)) {
                        v0 = (unsigned)(signed char)(unsigned)((int)(unsigned)d0 >= (int)((unsigned)e0 & -(unsigned)(u1 < 9u)));
                        default: ;
                        c1 = (signed char)(unsigned)(0x355f2bc4u && ((unsigned)((v0 - *mp) == 3u) + 3u));
                        r0.x = (unsigned)(w0 >> 29);
                        case 5u: ;
                        *q0 += ((5u << ((unsigned)f0 & 31u)) ? a0[i0 & 3u] : (unsigned)c0);
                    }
                }
            } while (i1++ < 3u && (p0 | (i0 & *q0)));
        } while (i0++ < 6u && (unsigned)((int)0xa1f1e6afu >= (int)(unsigned)l0));
        goto L4;
        if (budget != 0u) { budget -= 1u; u2 = fn0(r0.x, (0xd61e2997u >> (m0 & 31u)), (unsigned)(p0 < 0x80000000u)); }
        if (budget != 0u) { budget -= 1u; u3 = fn1(5u, (unsigned)((unsigned)d0 || (unsigned)c1), (unsigned)((unsigned)((int)u3 < (int)0x80000000u) && 7u)); }
    }
    if ((0x80000000u - ((unsigned)d0 - (unsigned)c1))) goto L3;
    goto L2;
    e0 = e0 * 0.5L + (long double)(((unsigned)((int)0x3762207u >= (int)0x130baa2cu) / ((unsigned)(v0 == u0) | 1u)) & 1023u);
    i0 = u3 & 15u;
    do { if (--fuel == 0u) goto done;
        garr[0x7fffffffu & 7u] = (unsigned)((int)i2 < (int)(a0[i0 & 3u] | (unsigned)c0));
    } while (i0++ < 5u && (u1 ^ (unsigned)!(unsigned)((int)0xcb9c524cu < (int)u2)));
    a0[u3 & 3u] = ((unsigned)x0 << (u0 & 31u));
    if ((unsigned)(0u && (unsigned)(short)(g0 << ((unsigned)w0 & 31u)))) {
        goto done;
        if (i1) {
            g0 = (unsigned)(x0 >> 70);
            if (garr[u2 & 7u]) goto L4;
            if ((unsigned)!(unsigned)(((unsigned)s1 ^ (unsigned)f0) && garr[i1 & 7u])) goto L3;
        } else {
            if (budget != 0u) { budget -= 1u; u2 = fn0(9u, g1, (p1 << (0u & 31u))); }
            goto done;
            h1 = (unsigned short)(h1 + ((m0 ^ 0x10000u) ? g0 : p0));
            i2 = (unsigned)((short)1u > (signed char)0x10000u) & 15u;
        }
        if (0xae78caa5u) {
            if (a0[i0 & 3u]) goto done;
            if ((unsigned)(unsigned char)(unsigned)(p2 == 0xdd16eeb1u)) goto L1;
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)b0 / (garr[i1 & 7u] | 1u))) goto L2;
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (unsigned)(short)((unsigned)(garr[i1 & 7u] == 0x80000000u) / ((~(3u / (*q0 | 1u)) << (a0[u1 & 3u] & 31u)) | 1u));
                    if (budget != 0u) { budget -= 1u; u2 = fn1(a0[i0 & 3u], ((unsigned)(m0 && i0) >> (0xd3413680u & 31u)), 0xa3aef757u); }
                    u2 ^= ((unsigned)e0 & (((unsigned)e0 | 0x80000000u) >> (v0 & 31u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn2(0x80000000u, *q0, (unsigned)((i1 >> (1u & 31u)) == g1)); }
                    if (u3 == 7u) return (unsigned)(signed char)((unsigned)h1 ? (unsigned)(u3 || garr[i1 & 7u]) : ~((unsigned)s1 / ((unsigned)f0 | 1u)));
                    garr[(unsigned)((unsigned)b0 < 0xadd5c0u) & 7u] = (p0 << (((unsigned)(x0 >> 70) & v0) & 31u));
                }
                i1 = (unsigned)f0 & 15u;
                if ((unsigned)!(u2 & (unsigned)d0)) break;
            }
            s1 = (int)((unsigned)s1 + (unsigned)!(a0[i0 & 3u] - *mp));
            { unsigned t7; double z7; if (((unsigned)((unsigned)s0 || (*mp * (unsigned)d0))) & 1u) { t7 = r0.x; z7 = (double)(((unsigned)((int)(unsigned)c1 >= (int)m0)) & 255u); } if (((unsigned)((unsigned)s0 || (*mp * (unsigned)d0))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                c0 = (unsigned char)(((unsigned)((int)p1 >= (int)(unsigned)s0) + a0[i0 & 3u]) - ((unsigned)s1 & 0x2894d372u));
                if ((i2 | (unsigned)!(unsigned)(0x7fffffffu == (unsigned)c0))) goto L0;
                i0 = (p1 * 7u) & 15u;
                do { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)(unsigned)((short)m0 > (signed char)(0xb188b937u << (garr[i1 & 7u] & 31u))), (0x94c3531fu / ((unsigned)(w0 >> 29) | 1u)), ((unsigned)((int)0xe8dbb9ffu >= (int)0x4717dbd2u) / (*mp | 1u))); }
                        u2 += (unsigned)((a0[i0 & 3u] << ((p2 + ((unsigned)d0 / (7u | 1u))) & 31u)) == 0xffffffffu);
                        if (((unsigned)e0 << ((unsigned)e0 & 31u))) break;
                        s1 = (int)((unsigned)s1 + (g0 / (g0 | 1u)));
                        h0 = (short)(unsigned)(0x377121f6u && ((r0.y % ((unsigned)((int)0xffffffffu < (int)(unsigned)c0) | 1u)) - (unsigned)s0));
                        if ((unsigned)(0x10000u < (unsigned)h0)) goto done;
                    } while (i1++ < 7u && ((unsigned)((unsigned)e0 < 0x7fffffffu) / (u2 | 1u)));
                    if (fuel < 8u) return (unsigned)((int)0xe555d313u < (int)((unsigned)((unsigned)c1 && 0x7fffffffu) % (((unsigned)b0 / (u1 | 1u)) | 1u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)e0, (unsigned)((int)p0 >= (int)(a0[u1 & 3u] % ((unsigned)l0 | 1u))), a0[u1 & 3u]); }
                    if (a0[u1 & 3u]) {
                        d0 = d0 * 0.5 + (double)((unsigned)((short)9u > (signed char)((unsigned)(unsigned char)(unsigned)(p2 < u1) >> ((unsigned)(x0 >> 70) & 31u))) & 1023u);
                        if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)s1 << (((unsigned)h1 % (0u | 1u)) & 31u)), *q0, (u2 * garr[u2 & 7u])); }
                        *mp = (unsigned)x0;
                    } else {
                        b0 = (unsigned)(0x10000u < (unsigned)((short)0xb097b2f8u > (signed char)(unsigned)((unsigned)(w0 >> 29) < p1))) != 0u;
                    }
                } while (i0++ < 5u && (unsigned)(g1 == a0[u1 & 3u]));
                u3 = u3 * 0x9e3779b1u + (unsigned)((unsigned)((short)(unsigned)b0 > (signed char)0x80000000u) < (*mp >> (5u & 31u)));
            }
        }
    }
    if (9u) goto L4;
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)((short)p1 > (signed char)u2);
        }
        d0 = d0 * 0.5 + (double)(((p2 ? p1 : -(p2 * 0x267829b3u)) ^ (unsigned)s0) & 1023u);
        switch ((unsigned)w0 & 7u) {
            if (-(i1 + 2u)) goto L0;
            q0 = &garr[(r0.y * (unsigned)(0x1d5d60f8u == ((unsigned)s1 & i0))) & 7u];
            { unsigned t8; double z8; if ((0xa87c01e8u) & 1u) { t8 = 0x10000u; z8 = (double)(((*mp ^ (unsigned)((unsigned)b0 && (unsigned)x0))) & 255u); } if ((0xa87c01e8u) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                u1 = u1 * 0x9e3779b1u + ((unsigned)d0 >> (garr[i1 & 7u] & 31u));
                case 3u: ;
                if (budget != 0u) { budget -= 1u; u3 = fn2(garr[u2 & 7u], ((unsigned)(0x10000u && (unsigned)b0) & u3), (unsigned)!(4u - m0)); }
                case 2u: ;
                if ((unsigned)((unsigned)e0 && (unsigned)l0)) goto done;
                case 0u: ;
            }
            u2 += (0x7fffffffu % (((unsigned)((unsigned)c1 < (0x80000000u - (unsigned)s1)) ^ (unsigned)x0) | 1u));
            { unsigned t9; double z9; if ((8u) & 1u) { t9 = u3; z9 = (double)((p2) & 255u); } if ((8u) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)(unsigned)(x0 >> 70) < (int)(v0 | 0xb4d6bc5eu)), a0[i0 & 3u], ((unsigned)h1 | (unsigned)(0x9ea03906u == (unsigned)d0))); }
                u0 ^= ((r0.x % (((unsigned)l0 * 1u) | 1u)) & *q0);
                case 7u: ;
                c1 = (signed char)r0.x;
                h1 = (unsigned short)(h1 + (unsigned)((((unsigned)c0 - 0x54b003d3u) / (0x7fffffffu | 1u)) < ((unsigned)h1 ^ garr[i1 & 7u])));
            }
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch ((unsigned)(unsigned char)(unsigned)(0xaec78530u || i2) & 7u) {
                    u1 = u1 * 0x9e3779b1u + 0x5f58aa2au;
                    case 4u: ;
                    if (*q0) break;
                    *q0 += ~((unsigned)c0 - a0[i0 & 3u]);
                    i0 = 0x80000000u & 15u;
                }
                if ((unsigned)((unsigned)w0 == i0)) goto done;
                if (0x7fffffffu) continue;
                q0 = &garr[((unsigned)d0 + 0xffffffffu) & 7u];
            }
        }
        g1 += (3u - (unsigned)((int)g1 < (int)p1));
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.x = (2u ^ a0[u1 & 3u]);
            break; (void)(u2);
        }
        d0 = d0 * 0.5 + (double)((unsigned)(short)(unsigned)((short)i0 > (signed char)(p2 & 0xfc7794afu)) & 1023u);
    } while (i0++ < 7u && (8u ^ 3u));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = ((unsigned)(w0 >> 29) + (unsigned)w0);
        if ((unsigned)!(unsigned)((unsigned)h0 == (unsigned)f0)) break;
    }
    { unsigned t10; double z10; if (((unsigned)((int)(unsigned)((unsigned)w0 < 8u) >= (int)p0)) & 1u) { t10 = (unsigned)((short)0x80000000u > (signed char)p1); z10 = (double)(((unsigned)((unsigned)s1 || (unsigned)f0)) & 255u); } if (((unsigned)((int)(unsigned)((unsigned)w0 < 8u) >= (int)p0)) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
        if (budget != 0u) { budget -= 1u; u3 = fn0((~(g0 % ((unsigned)h1 | 1u)) / ((unsigned)f0 | 1u)), garr[i1 & 7u], (-((unsigned)l0 | fuel) << (i1 & 31u))); }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((0x80000000u % (1u | 1u))) break;
            r0.y ^= ((p1 >> ((unsigned)f0 & 31u)) * ((unsigned)e0 | i1));
        }
        h0 = (short)(p0 + ((unsigned)(x0 >> 70) >> (i2 & 31u)));
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 3u && ((unsigned)c0 % (((unsigned)(w0 >> 29) << ((unsigned)s1 & 31u)) | 1u))) { if (--fuel == 0u) goto done;
                if ((unsigned)b0) break;
                c0 = (unsigned char)*q0;
                do { if (--fuel == 0u) goto done;
                    if ((((unsigned)s1 ^ i1) ^ *q0)) goto L2;
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)c1, (unsigned)((int)(u1 * 0xb03f567eu) >= (int)i0), (unsigned)((i2 * 0x4f6f7fbu) == 0x10000u)); }
                    do { if (--fuel == 0u) goto done;
                        if (0x4f938f35u) {
                            break; (void)((unsigned)(i2 || a0[u1 & 3u]));
                            if (u1) break;
                            if (0x80000000u) continue;
                            if (budget != 0u) { budget -= 1u; u0 = fn1(0xffffffffu, ((unsigned)!((unsigned)c0 * (unsigned)(x0 >> 70)) - a0[u1 & 3u]), (unsigned)(fuel < (unsigned)(w0 >> 29))); }
                            if (budget != 0u) { budget -= 1u; u2 = fn2((8u & (unsigned)w0), (0x14e3c665u << ((0x864c9d6eu & a0[i0 & 3u]) & 31u)), (unsigned)(*mp < (9u << ((unsigned)c1 & 31u)))); }
                        } else {
                            u3 = u3 * 0x9e3779b1u + ((garr[i1 & 7u] - (unsigned)s0) % ((g1 >> ((unsigned)(x0 >> 70) & 31u)) | 1u));
                            if (u3 == 7u) return (unsigned)((unsigned)(unsigned char)((unsigned)(m0 || a0[u1 & 3u]) / ((unsigned)c1 | 1u)) == (7u + i0));
                            i2 = 0xffffffffu & 15u;
                            w0 = w0 * 6364136223846793005ull + (unsigned)((int)0x1e4dcc6au < (int)(a0[u1 & 3u] << (i2 & 31u)));
                        }
                        c0 = (unsigned char)((fuel - garr[u2 & 7u]) - (unsigned)((short)r0.y > (signed char)(unsigned)c1));
                    } while (i0++ < 2u && (i2 << (a0[i0 & 3u] & 31u)));
                    v0 = i2;
                    h0 = (short)~(unsigned)((int)(2u / (i1 | 1u)) >= (int)u0);
                    if ((u0 | 0x46f12b43u)) break;
                } while (i2++ < 6u && (unsigned)h0);
                do { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(0x80000000u && (0xb3f55812u << (u0 & 31u))) >= (int)(a0[u1 & 3u] & (unsigned)c0)));
                    break; (void)(0xffffffffu);
                    g1 += (unsigned)(9u && g1);
                    if ((unsigned)((0xa64c7a11u & 0x138a61f0u) || r0.x)) break;
                    q0 = &garr[(unsigned)(r0.x || 0x65171bbeu) & 7u];
                } while (i2++ < 7u && (unsigned)(8u || p0));
                if (-(0x10000u & (unsigned)h1)) {
                    break; (void)(0xffffffffu);
                    h0 = (short)(unsigned)!((0x10000u & (unsigned)(0xffffffffu == g1)) ^ p1);
                }
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)w0 >> (m0 & 31u)), (0x10000u ^ (unsigned)h1), (((unsigned)c0 >> (r0.x & 31u)) | 0x87ffaaf5u)); }
            }
            m0 ^= (0u << ((unsigned)w0 & 31u));
            while (i1++ < 3u && ((unsigned)(unsigned char)(unsigned)((short)(unsigned)l0 > (signed char)i1) << (3u & 31u))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0((garr[i1 & 7u] % (8u | 1u)), fuel, (u1 + *q0)); }
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    h0 = (short)*mp;
                    if (((unsigned)f0 - m0)) goto done;
                    u0 = u0 * 0x9e3779b1u + (((unsigned)(w0 >> 29) / ((unsigned)b0 | 1u)) ^ *q0);
                    break; (void)((1u ^ (unsigned)c1));
                }
                u0 ^= (0x3d79960fu | ((unsigned)(x0 >> 70) & 5u));
                s1 = (int)((unsigned)s1 + 0xffffffffu);
                if ((unsigned)l0) {
                    if ((unsigned)(unsigned char)((unsigned)((unsigned)d0 < (unsigned)b0) >> (garr[i1 & 7u] & 31u))) {
                        do { if (--fuel == 0u) goto done;
                            *q0 += (unsigned)((g0 ^ 3u) < (unsigned)(a0[u1 & 3u] || (unsigned)l0));
                            s1 = (int)((unsigned)s1 + (unsigned)(signed char)(unsigned)(8u && 7u));
                            break; (void)((unsigned)e0);
                        } while (i2++ < 4u && (r0.y - i1));
                        a0[2u & 3u] = r0.y;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((0x374a45afu ^ i1), *q0, ((8u % ((unsigned)(w0 >> 29) | 1u)) << (u0 & 31u))); }
                    }
                    w0 = w0 * 6364136223846793005ull + (0x5f13ea3cu >> (i1 & 31u));
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((int)(3u << (a0[i0 & 3u] & 31u)) >= (int)(a0[i0 & 3u] | (unsigned)c1)) && 0x10000u));
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)(i0);
                    }
                    { unsigned t11; double z11; if (((p2 >> (i2 & 31u))) & 1u) { t11 = *q0; z11 = (double)(((v0 ^ (unsigned)h1)) & 255u); } if (((p2 >> (i2 & 31u))) & 1u) { u3 += t11; d0 = d0 * 0.5 + z11; }
                        g1 += (0x80000000u | u2);
                        h1 = (unsigned short)(h1 + garr[u2 & 7u]);
                    }
                }
            }
            break; (void)(((unsigned)c1 ^ fuel));
            g0 = ((0xd2404b7u ? u2 : (unsigned)f0) >> ((unsigned)h1 & 31u));
        }
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)!(unsigned)((unsigned)d0 == (0xe3b9e306u + g0))) break;
            r0.y ^= 6u;
            if (budget != 0u) { budget -= 1u; u2 = fn1(0u, (unsigned)(short)(3u | ((unsigned)e0 * *mp)), 0x80000000u); }
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(r0.y == (unsigned)s1), (unsigned)w0, (garr[i1 & 7u] - 0xe0c74502u)); }
            switch ((unsigned)x0 & 7u) {
                case 5u: ;
                g1 += ((unsigned)l0 / ((0x450ea1b5u * 0xffffffffu) | 1u));
                a0[a0[u1 & 3u] & 3u] = ((unsigned)s1 * i2);
                if (((unsigned)(w0 >> 29) % ((unsigned)(u0 && 0u) | 1u))) continue;
                c1 = (signed char)((unsigned)(v0 < 0xc157aea1u) | (r0.x & 0xa3ffd1cu));
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(short)(unsigned)((int)7u < (int)(unsigned)w0) && 0x61636bc0u) & 1023u);
            }
        }
        r0.y ^= ((-(i0 % ((unsigned)c1 | 1u)) % (0x5aa6c9a3u | 1u)) % ((unsigned)h1 | 1u));
    }
    e0 = e0 * 0.5L + (long double)(((unsigned)c0 | (unsigned)w0) & 1023u);
    switch ((unsigned)(unsigned char)((unsigned)(i1 && 0xffffffffu) & 1u) & 7u) {
        a0[-(0x10000u * 0x10000u) & 3u] = ((unsigned)((int)0x1d963501u < (int)r0.y) / ((unsigned)(0x7fffffffu || fuel) | 1u));
        c1 = (signed char)(unsigned)((int)(unsigned)e0 >= (int)0x6397030bu);
        h1 = (unsigned short)(h1 + (0x44447c8du ^ r0.y));
    }
    while (i0++ < 7u && r0.x) { if (--fuel == 0u) goto done;
        v0 = (m0 + ((unsigned)(unsigned char)(0xb244057fu % (9u | 1u)) ? i1 : 0x61ec4c4au));
        if ((i1 ^ (unsigned)((int)r0.y < (int)0x10000u))) {
            *q0 = (unsigned)(unsigned char)((i1 ? (unsigned)(w0 >> 29) : a0[u1 & 3u]) << (u2 & 31u));
            d0 = d0 * 0.5 + (double)((unsigned)((int)0x5e9b632du < (int)0xffffffffu) & 1023u);
        }
    }
    if ((i0 | u3)) goto L4;
    s0 = (int)(unsigned)d0;
    if (budget != 0u) { budget -= 1u; u2 = fn0(-(unsigned)(0x80000000u || v0), (unsigned)(i0 || (unsigned)(p0 < fuel)), ((unsigned)e0 + (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)x0))); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *mp = (unsigned)((int)(unsigned)(g1 == 0xc025df4fu) >= (int)(unsigned)c0);
    i1 = (unsigned)((unsigned)b0 && (v0 - 0x7fffffffu)) & 15u;
    while ((0x10000u % ((unsigned)d0 | 1u))) { if (--fuel == 0u) goto done;
        *q0 = ((unsigned)((int)0xc7784c1du < (int)g0) % ((unsigned)((int)((unsigned)f0 | u2) < (int)(unsigned)s0) | 1u));
        r0.x = (9u >> ((5u % (9u | 1u)) & 31u));
        g1 += (unsigned)(signed char)((unsigned)(w0 >> 29) >> ((unsigned)(unsigned char)(u2 / (9u | 1u)) & 31u));
    }
    u2 = u2 * 0x9e3779b1u + (0x7fffffffu * (unsigned)(w0 >> 29));
    f0 = f0 * 0.5f + (float)(4u & 255u);
    goto L2;
    if (0x7df034bu) {
        a0[(unsigned)(g1 && v0) & 3u] = ~((unsigned)l0 % ((unsigned)(x0 >> 70) | 1u));
        if (0xf5c95e54u) {
            L0: if (--fuel == 0u) goto done;
            if ((unsigned)(p0 || (unsigned)h0)) {
                if (0x80000000u) goto L4;
                *q0 += (0xffffffffu | (0xffffffffu / (i2 | 1u)));
                if (budget != 0u) { budget -= 1u; u0 = fn2(p2, p1, ((unsigned)((short)(unsigned)d0 > (signed char)r0.y) % (g1 | 1u))); }
                if (m0) goto L0;
                c0 = (unsigned char)((unsigned)(signed char)(unsigned)((unsigned)w0 < (g0 - g1)) + (1u + (unsigned)c0));
            } else {
                if ((unsigned)((short)0x80000000u > (signed char)p0)) goto L2;
                i0 = (unsigned)((u1 & r0.x) == (unsigned)x0) & 15u;
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)8u >= (int)((unsigned)(x0 >> 70) << ((r0.x - (unsigned)b0) & 31u)));
                c1 = (signed char)((unsigned)((unsigned)(a0[i0 & 3u] == i1) || (unsigned)(7u && r0.y)) - 0xa7df244au);
            }
            if ((0x7fffffffu / ((unsigned)x0 | 1u))) {
                garr[1u & 7u] = v0;
                for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(w0 >> 29) - 0x80000000u), (unsigned)((9u / (u3 | 1u)) && g0), (unsigned)((unsigned)((int)r0.y < (int)0xffffffffu) < *mp)); }
                    garr[((unsigned)(w0 >> 29) - *mp) & 7u] = i0;
                    if ((fuel - -(unsigned)(6u || r0.y))) {
                        s0 = (int)(unsigned)((unsigned)((short)(g0 % (p1 | 1u)) > (signed char)p1) || (unsigned)((int)i1 >= (int)i0));
                    } else {
                        if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)(x0 >> 70) << (0xffffffffu & 31u)), ((unsigned)h0 ^ ((unsigned)e0 / ((unsigned)w0 | 1u))), (unsigned)(unsigned char)(u2 % ((unsigned)((unsigned)b0 && (unsigned)w0) | 1u))); }
                        u2 += ((0xb1d32df2u << (i2 & 31u)) ? r0.x : 0xa2105d3bu);
                        if (fuel < 8u) return garr[u2 & 7u];
                        if (fuel < 8u) return ((unsigned)w0 >> ((unsigned)f0 & 31u));
                    }
                    if ((p2 % (r0.x | 1u))) break;
                    L1: if (--fuel == 0u) goto done;
                }
            } else {
                w0 = w0 * 6364136223846793005ull + -(unsigned)(((unsigned)f0 | u2) == 6u);
                s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)s1 > (signed char)(r0.y ^ ~(unsigned)(u1 || 0xa293439au))));
                goto done;
            }
            if (((unsigned)h1 ^ ((unsigned)c0 & (unsigned)x0))) goto L3;
            if (6u) goto done;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)x0, (unsigned)b0, *q0); }
        u1 ^= (((unsigned)d0 << (-(unsigned)(fuel < 0xe0f0d5c5u) & 31u)) >> ((unsigned)((unsigned)e0 && 1u) & 31u));
        L2: if (--fuel == 0u) goto done;
    } else {
        r0.y ^= a0[i0 & 3u];
    }
    w0 ^= (unsigned long long)(unsigned)(unsigned char)(9u & 0xffffffffu) << ((unsigned)((short)0x6cdec920u > (signed char)(unsigned)(x0 >> 70)) & 63u);
    m0 ^= (*q0 >> ((v0 - (unsigned)h0) & 31u));
    if ((0xaa7dc2acu / (0x7fffffffu | 1u))) goto L2;
    l0 = (long)((unsigned long)l0 + ((unsigned)(0xffffffffu || (unsigned)(x0 >> 70)) << (((unsigned)b0 << (a0[i0 & 3u] & 31u)) & 31u)));
    if ((g0 + i2)) goto done;
    *mp = ((unsigned)(w0 >> 29) << ((-(p1 >> (0x9860ea2eu & 31u)) ^ (unsigned)(w0 >> 29)) & 31u));
    if ((u0 + v0)) {
        h0 = (short)(r0.x * ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)((unsigned)e0 < r0.y)) ^ u3));
        switch ((unsigned)(unsigned char)((0x7fffffffu ^ (unsigned)s0) + 1u) & 7u) {
            if (~(a0[i0 & 3u] + (5u | (unsigned)(x0 >> 70)))) goto L2;
            c1 = (signed char)(fuel >> (((unsigned)l0 % (0xffffffffu | 1u)) & 31u));
            r0.x = (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(g1 << (p0 & 31u)));
        }
        i0 = ((unsigned)((unsigned)(short)(unsigned)(garr[i1 & 7u] == 5u) < fuel) & *q0) & 15u;
    } else {
        switch ((0x80000000u >> (7u & 31u)) & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn2((u0 % (u2 | 1u)), (g0 | (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)(w0 >> 29))), *q0); }
            b0 = *q0 != 0u;
            b0 = (unsigned)((int)v0 >= (int)(garr[u2 & 7u] ? fuel : garr[u2 & 7u])) != 0u;
        }
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)((int)0xffffffffu < (int)0u);
        if (((unsigned)c1 * u2)) break;
        if ((garr[i1 & 7u] / ((unsigned)b0 | 1u))) goto done;
    }
    goto L0;
    if (((0xffffffffu >> ((unsigned)e0 & 31u)) >> (0x10000u & 31u))) goto L4;
    if (((unsigned)s0 & r0.x)) goto done;
    if ((0xa40034d6u + 0xb8fb95f1u)) {
        switch (g1 & 7u) {
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + ((0x10000u ^ (unsigned)(0x7fffffffu < 0x10000u)) % (i0 | 1u)));
                m0 ^= (unsigned)((short)(unsigned)c0 > (signed char)((unsigned)((int)0x7fffffffu >= (int)(unsigned)(w0 >> 29)) + 0xc473a427u));
                { unsigned t0; double z0; if ((v0) & 1u) { t0 = 0xffffffffu; z0 = (double)((((unsigned)b0 + 0x10000u)) & 255u); } if ((v0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    u0 ^= -((garr[i1 & 7u] - (unsigned)h0) - 0x80000000u);
                    h1 = (unsigned short)(h1 + (*mp % (i2 | 1u)));
                    if ((unsigned)f0) continue;
                    garr[((unsigned)c0 | fuel) & 7u] = (unsigned)((int)*mp < (int)a0[u1 & 3u]);
                }
            }
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)s1) continue;
                if (budget != 0u) { budget -= 1u; u3 = fn2(6u, (unsigned)(r0.y && (unsigned)((int)0x3ceb63c9u >= (int)p0)), (unsigned)((unsigned)d0 && (garr[u2 & 7u] % (garr[u2 & 7u] | 1u)))); }
                d0 = d0 * 0.5 + (double)((unsigned)((int)u3 < (int)(m0 ^ (unsigned)(x0 >> 70))) & 1023u);
                case 6u: ;
                { unsigned t1; double z1; if ((((unsigned)c1 * (0x7fffffffu | g1))) & 1u) { t1 = ((unsigned)(unsigned char)(unsigned)((int)fuel >= (int)0x1628fc38u) >> (r0.y & 31u)); z1 = (double)((((unsigned)b0 & a0[i0 & 3u])) & 255u); } if ((((unsigned)c1 * (0x7fffffffu | g1))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    *mp = (6u * ((unsigned)(a0[i0 & 3u] && fuel) - 0x7fffffffu));
                }
            }
            garr[(unsigned)(g1 || u3) & 7u] = ((0x80000000u ^ 5u) | p0);
        }
        if (r0.x) {
            L3: if (--fuel == 0u) goto done;
        } else {
            u3 += ((unsigned)((short)fuel > (signed char)((a0[i0 & 3u] * (unsigned)c1) & g0)) + garr[i1 & 7u]);
            goto L2;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((0x80000000u & 0x7fffffffu) || (unsigned)s1), (garr[i1 & 7u] ? u1 : *q0), (unsigned)(a0[i0 & 3u] < 0x6ee9d4f5u)); }
            g0 = (unsigned)f0;
        }
        if ((unsigned)((int)i2 < (int)p0)) goto L1;
        s0 = (int)(unsigned)!(((unsigned)((short)(unsigned)l0 > (signed char)9u) - (unsigned)s0) * -(0xb61b11f9u >> (0xd6af0bceu & 31u)));
        switch ((unsigned)((int)0xb59778b3u >= (int)u1) & 7u) {
            v0 = (unsigned)((int)((unsigned)d0 + ((unsigned)c1 - g0)) >= (int)(unsigned)((short)0xffffffffu > (signed char)(unsigned)c0));
        }
        L4: if (--fuel == 0u) goto done;
    }
    if ((0xfd2c85b8u >> ((0xffffffffu % (0x10000u | 1u)) & 31u))) goto L4;
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(unsigned char)(garr[i1 & 7u] + i0)) break;
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)d0) break;
                    b0 = ((unsigned)c1 >> (0x10000u & 31u)) != 0u;
                }
                b0 = (unsigned)((unsigned)((int)(unsigned)(short)((unsigned)h0 | 0x56de334au) < (int)*q0) || (1u * (unsigned)(w0 >> 29))) != 0u;
            }
        }
        switch (0x3dd54f0eu & 7u) {
            f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(((unsigned)f0 - i1) ^ -(i0 << (0x7fffffffu & 31u))) & 255u);
            if (((unsigned)c1 >> ((unsigned)(u2 < i1) & 31u))) {
                case 4u: ;
                r0.y ^= (unsigned)(((unsigned)h0 ^ a0[i0 & 3u]) || (unsigned)h0);
            }
        }
        switch (fuel & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)c0 - 0x10000u), i0, (i1 ? 0xffffffffu : 9u)); }
            w0 ^= (unsigned long long)(unsigned)((unsigned)w0 == fuel) << (-(((unsigned)((int)u2 >= (int)2u) >> (0x80000000u & 31u)) % (*q0 | 1u)) & 63u);
            w0 = w0 * 6364136223846793005ull + (unsigned)(fuel < r0.x);
        }
        w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)((int)a0[i0 & 3u] < (int)0xf6b1b4f0u) || (unsigned)((u3 / (u2 | 1u)) && 0x93a244f3u));
        u0 ^= (unsigned)(unsigned char)(unsigned)((int)v0 >= (int)(unsigned)(p2 == g0));
        v0 = (((0xdd1ac57fu << (0xffffffffu & 31u)) << (a0[u1 & 3u] & 31u)) - 3u);
    } while (i0++ < 2u && (unsigned)((int)i2 >= (int)i1));
    c0 = (unsigned char)(unsigned)((i1 << ((unsigned)s0 & 31u)) == ((unsigned)s0 >> (garr[u2 & 7u] & 31u)));
    v0 = (0x80000000u << (2u & 31u));
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)h0, 0u, 0x80000000u); }
    u2 += -((unsigned)h0 - ((g0 & (unsigned)(x0 >> 70)) << (g1 & 31u)));
    while (i0++ < 7u && (unsigned)(a0[u1 & 3u] < (unsigned)((unsigned)h0 < 0x549b204cu))) { if (--fuel == 0u) goto done;
        u3 = (unsigned)((int)(unsigned)(1u == 0x7fffffffu) < (int)-((r0.y << (*q0 & 31u)) >> (fuel & 31u)));
        s0 = (int)(unsigned)(u1 || v0);
        if ((unsigned)!(unsigned)(4u < ((unsigned)h0 + fuel))) break;
    }
    if (-(unsigned)(0xf0ab17cdu == garr[u2 & 7u])) goto L3;
    u3 = u3 * 0x9e3779b1u + r0.x;
    do { if (--fuel == 0u) goto done;
        u2 = (unsigned)(short)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)(w0 >> 29));
        e0 = e0 * 0.5L + (long double)(2u & 1023u);
    } while (i0++ < 4u && (unsigned)((unsigned)(0x1d961390u || i0) && 0x80000000u));
    s1 = (int)((unsigned)s1 + (unsigned)((int)0x10000u < (int)(a0[u1 & 3u] >> ((unsigned)(0x6dca84f0u == m0) & 31u))));
    l0 = (long)((unsigned long)l0 + (unsigned)((int)7u < (int)0x3ce7e9acu));
    goto L0;
    if ((unsigned)(0xffffffffu && 4u)) {
        if ((0xa3b5e558u - (unsigned)((int)0x7c9c7cb2u < (int)p2))) {
            if ((unsigned)(p2 && (0xef1f4406u | 0x80000000u))) goto L0;
        } else {
            if (budget != 0u) { budget -= 1u; u2 = fn3(0x8f0a50c8u, m0, (unsigned)((int)fuel >= (int)(unsigned)b0)); }
            if ((p1 - 4u)) goto L1;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((0u | 0xd8a3b930u) < p1)) goto L4;
                g0 = (unsigned)(0x5391f656u && (unsigned)w0);
            } while (i0++ < 3u && 0x80000000u);
        }
    } else {
        l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)w0 + (unsigned)f0) == ((unsigned)w0 - (unsigned)(*q0 == (unsigned)w0))));
    }
    if ((i2 ^ (0x7fffffffu | a0[u1 & 3u]))) {
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (unsigned)(short)(unsigned)((i1 | i0) == (unsigned)(unsigned char)(unsigned)(~((unsigned)c1 & r0.x) < (unsigned)(w0 >> 29)));
            a0[(unsigned)(0u && (unsigned)c0) & 3u] = (u2 ? i2 : 0x17f818eu);
        }
        r0.y ^= ((fuel | r0.y) ? (p1 + *mp) : 0x647606u);
        v0 = (i0 >> (garr[i1 & 7u] & 31u));
        if (v0) goto L2;
        if ((unsigned)(unsigned char)((garr[u2 & 7u] + g1) * i1)) goto L4;
    } else {
        if ((unsigned)f0) goto L1;
        c0 = (unsigned char)(unsigned)((short)((unsigned)((int)r0.x < (int)0x13f7065bu) + (unsigned)w0) > (signed char)(unsigned)s1);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 6u, 0x514c0c60u, 0x8f134375u },
        { 4u, 0x900971e3u, 0x6e51f791u },
        { 15u, 0x7ca58293u, 0xd99df4e0u },
        { 10u, 0x966be9a1u, 0xfb1f5753u },
        { 9u, 0x5a47d317u, 0x88684f8au },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
