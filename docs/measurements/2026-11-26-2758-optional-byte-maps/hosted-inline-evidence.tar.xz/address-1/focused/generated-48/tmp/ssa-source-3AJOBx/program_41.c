// test-ssa-source's program of seed 134000443 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x67a41b7bu, g1 = 0xb530a99cu;
static unsigned garr[8] = { 0xd44f416du, 0xd2f428f0u, 0x973c73d4u, 0x26305b33u, 0x51ecfd98u, 0x694e37d8u, 0x89001cdcu, 0xc7f62b7fu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if ((m0) & 1u) { t0 = (unsigned)((unsigned)(*q0 || r0.x) == garr[i1 & 7u]); z0 = (double)(((5u / (r0.y | 1u))) & 255u); } if ((m0) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if (u3 == 7u) return (unsigned)((int)((unsigned)((unsigned)c1 && 0xffffffffu) + 0x6709bd6eu) < (int)p2);
        g1 += (unsigned)(signed char)((0x80000000u >> ((unsigned)(garr[u2 & 7u] && 7u) & 31u)) - i1);
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            u2 = (unsigned)((a0[i0 & 3u] % (0x15d5a2e5u | 1u)) == (unsigned)l0);
            g1 += (0x67d9aa2bu * 0x10000u);
        }
        L0: if (--fuel == 0u) goto done;
    }
    m0 ^= (unsigned)((short)((unsigned)w0 & (unsigned)((unsigned)h0 || (p2 * 0x10000u))) > (signed char)i2);
    if ((unsigned)((int)(unsigned)e0 < (int)(unsigned)(r0.x || p1))) goto done;
    goto L1;
    goto L2;
    *mp = (8u | (unsigned)!(unsigned)((g1 / (u1 | 1u)) < v0));
    L1: if (--fuel == 0u) goto done;
    garr[i1 & 7u] = (unsigned)((int)~((unsigned)(0x80000000u && 2u) << ((unsigned)x0 & 31u)) < (int)u0);
    if ((8u << ((m0 % (2u | 1u)) & 31u))) goto L0;
    e0 = e0 * 0.5L + (long double)(((unsigned)(9u || 0x3f8b2b10u) % (u1 | 1u)) & 1023u);
    switch (((unsigned)((int)2u < (int)g0) << ((unsigned)e0 & 31u)) & 7u) {
        w0 = w0 * 6364136223846793005ull + ((unsigned)h1 << (m0 & 31u));
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(unsigned char)(unsigned)((unsigned)c0 < (unsigned)((short)0xc54d891fu > (signed char)6u))) {
            *q0 += ((unsigned)((int)(p1 * (unsigned)e0) >= (int)*q0) / ((unsigned)s0 | 1u));
            break; (void)(3u);
        }
    } while (i0++ < 3u && (unsigned)e0);
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (unsigned)(short)((unsigned)(unsigned char)((unsigned)h1 - 0x10000u) * (unsigned)(signed char)((unsigned)s1 ? 4u : (unsigned)d0));
        switch (u2 & 7u) {
            L2: if (--fuel == 0u) goto done;
            if ((unsigned)(unsigned char)(u1 + (u1 + (unsigned)x0))) break;
            L3: if (--fuel == 0u) goto done;
            g0 = (unsigned)!(unsigned)(u3 < (0xf4e770cfu / ((unsigned)(short)((p1 << (i0 & 31u)) & g0) | 1u)));
            *mp = (unsigned)((unsigned)h1 == fuel);
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if (((u3 << ((unsigned)(signed char)(unsigned)((int)0x1aff9d5du < (int)(unsigned)w0) & 31u))) & 1u) { t1 = p2; z1 = (double)((((v0 + (unsigned)c1) / (0x7fffffffu | 1u))) & 255u); } if (((u3 << ((unsigned)(signed char)(unsigned)((int)0x1aff9d5du < (int)(unsigned)w0) & 31u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                g1 += -(i2 * g0);
                L4: if (--fuel == 0u) goto done;
                break; (void)((3u * 0xd0ab5819u));
                m0 ^= -((unsigned)c0 + (unsigned)(unsigned char)(*q0 & a0[i0 & 3u]));
                l0 = (long)((unsigned long)l0 + (i0 >> ((unsigned)((short)u2 > (signed char)g0) & 31u)));
                f0 = f0 * 0.5f + (float)((unsigned)(r0.y && (unsigned)((int)v0 < (int)(unsigned)c0)) & 255u);
            }
            switch (i0 & 7u) {
                if (((p1 - i1) - u3)) {
                    c1 = (signed char)(unsigned)((int)(unsigned)f0 >= (int)p1);
                } else {
                    case 2u: ;
                }
                *mp = ~(unsigned)((short)((i2 + (unsigned)(x0 >> 70)) / ((unsigned)!(0xffffffffu % ((unsigned)(w0 >> 29) | 1u)) | 1u)) > (signed char)0x80000000u);
                case 4u: ;
                d0 = d0 * 0.5 + (double)((0x7aaab839u ^ u3) & 1023u);
            }
            continue; (void)(0x7aaf603fu);
            continue; (void)(g0);
            if ((garr[i1 & 7u] % (g0 | 1u))) continue;
        }
        goto L0;
    }
    if ((9u + 0xcfd77d2cu)) {
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)x0 << (0x7fffffffu & 31u)));
                u0 += (unsigned)(0x8aeb6827u && *q0);
                if (((unsigned)d0 % ((unsigned)((unsigned)(w0 >> 29) < g0) | 1u))) break;
                r0.x = (unsigned)(signed char)(u1 ? p1 : 7u);
            } while (i1++ < 2u && ~(g0 << (7u & 31u)));
            switch ((unsigned)((int)8u < (int)0xac23fd8du) & 7u) {
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 4u: ;
                    s0 = (int)(unsigned)((unsigned)b0 && (unsigned)((unsigned)((short)(unsigned)s0 > (signed char)m0) && (unsigned)((unsigned)h1 == *q0)));
                }
                *q0 += ((unsigned)!((unsigned)b0 - g0) >> ((u2 >> ((unsigned)((int)i1 >= (int)(unsigned)h1) & 31u)) & 31u));
            }
        } while (i0++ < 3u && (unsigned)((unsigned)(r0.x < g1) && v0));
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((0xf1be2ec9u & 4u)) goto L2;
            garr[8u & 7u] = (((unsigned)(x0 >> 70) >> (0xa2d517a6u & 31u)) | (0xffffffffu >> ((unsigned)(v0 || (unsigned)(x0 >> 70)) & 31u)));
        }
        if ((i1 ? m0 : (unsigned)s1)) goto L1;
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[(unsigned)s1 & 3u] = (9u + i2);
        if (-((unsigned)w0 * i1)) break;
        if (0x10000u) break;
        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)c1 && (unsigned)((int)0xffffffffu >= (int)i2)) & 1023u);
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(x0 >> 70)) break;
        if ((0x5fb8b1d9u << (0xffffffffu & 31u))) {
            i0 = (unsigned)((int)fuel < (int)fuel) & 15u;
            r0.x = (unsigned)((short)(i0 + 0xb90bcf4cu) > (signed char)(unsigned)((int)(unsigned)((short)(unsigned)d0 > (signed char)(unsigned)e0) >= (int)(unsigned)(x0 >> 70)));
            r0.y ^= (unsigned)(garr[i1 & 7u] && (0xffffffffu | p1));
        } else {
            g0 = (fuel % (((u3 / ((unsigned)s0 | 1u)) % (~((unsigned)h0 - (unsigned)s0) | 1u)) | 1u));
            if (p0) break;
        }
        if ((8u >> ((unsigned)w0 & 31u))) break;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= 9u;
            *q0 += (unsigned)((int)p1 < (int)(unsigned)!(unsigned)((unsigned)s0 || u2));
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)!(fuel >> ((unsigned)(unsigned char)((unsigned)s1 ^ 0xffffffffu) & 31u)) >= (int)(m0 - 0xac3d7576u)));
            goto L0;
            e0 = e0 * 0.5L + (long double)((unsigned)(m0 && 0x4b107566u) & 1023u);
            c0 = (unsigned char)(m0 / ((((unsigned)(x0 >> 70) ? i2 : 0x7fffffffu) / (garr[u2 & 7u] | 1u)) | 1u));
        }
        { unsigned t2; double z2; if ((((unsigned)((unsigned)c1 == 0x7fffffffu) - 0xbfdc51d4u)) & 1u) { t2 = (unsigned)((unsigned)d0 == (i1 + *q0)); z2 = (double)(((unsigned)(unsigned char)(0x8ffdb0c1u ^ (unsigned)(short)(garr[u2 & 7u] & fuel))) & 255u); } if ((((unsigned)((unsigned)c1 == 0x7fffffffu) - 0xbfdc51d4u)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            *q0 += (unsigned)(short)(0x9af8233du | (unsigned)c1);
            do { if (--fuel == 0u) goto done;
                if ((((unsigned)h0 - v0) >> (0xffffffffu & 31u))) break;
                u3 += (unsigned)(signed char)(*q0 + (unsigned)((unsigned)b0 || 1u));
            } while (i1++ < 3u && ((unsigned)s0 | (unsigned)(x0 >> 70)));
        }
        if (a0[i0 & 3u]) break;
    }
    switch ((unsigned)((int)((unsigned)w0 >> ((unsigned)s1 & 31u)) < (int)(unsigned)f0) & 7u) {
        case 6u: ;
        break; (void)((unsigned)((int)0x43c8324cu >= (int)(0x2d63f5e8u + 0u)));
        case 1u: ;
        q0 = &garr[(u3 >> ((unsigned)w0 & 31u)) & 7u];
        case 3u: ;
        s0 = (int)(unsigned)(x0 >> 70);
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)!(fuel << ((unsigned)(short)((unsigned)s0 << (r0.y & 31u)) & 31u))) break;
        i0 = (unsigned)(0xadc7234du == (unsigned)((int)(unsigned)(short)(a0[i0 & 3u] % ((unsigned)((unsigned)(x0 >> 70) && 0x80000000u) | 1u)) < (int)(unsigned)s0)) & 15u;
        break; (void)((unsigned)h0);
        g1 += (garr[i1 & 7u] & (unsigned)f0);
        goto L0;
    }
    if (u3 == 7u) return (unsigned)(*mp && v0);
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        u1 = (unsigned)(a0[u1 & 3u] || 0x10000u);
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)m0 << (0x80000000u & 63u);
            *q0 = r0.x;
            { unsigned t3; double z3; if (((unsigned)(0x7fffffffu || p0)) & 1u) { t3 = (r0.y * u0); z3 = (double)((i0) & 255u); } if (((unsigned)(0x7fffffffu || p0)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                *mp = (unsigned)(m0 == (v0 * (unsigned)e0));
                if ((a0[u1 & 3u] << (0x1219273bu & 31u))) break;
                if ((*q0 >> (((unsigned)c1 & (unsigned)f0) & 31u))) {
                    s1 = (int)((unsigned)s1 + *mp);
                    s0 = (int)(unsigned)c1;
                }
                if ((unsigned)w0) break;
                f0 = f0 * 0.5f + (float)((unsigned)h0 & 255u);
                break; (void)((0x10000u << ((0xca9f9eb9u * (unsigned)h0) & 31u)));
            }
            if ((a0[u1 & 3u] ^ (unsigned)(i0 && (unsigned)c0))) continue;
            i0 = ((garr[i1 & 7u] % (0x441390bfu | 1u)) >> ((0x74e6fb71u << (fuel & 31u)) & 31u)) & 15u;
        }
        if ((unsigned)(signed char)(7u ^ 0x10000u)) {
            if ((unsigned)((int)*q0 < (int)0xf9d20113u)) goto L0;
            s1 = (int)((unsigned)s1 + (((p1 % (3u | 1u)) / (garr[i1 & 7u] | 1u)) * 0x80000000u));
            c0 = (unsigned char)(unsigned)(0x80000000u || ((unsigned)(0xffffffffu < (unsigned)(9u || 0xffffffffu)) >> (6u & 31u)));
            do { if (--fuel == 0u) goto done;
                if (((unsigned)((short)m0 > (signed char)(unsigned)h0) * 0x7fffffffu)) break;
                if ((unsigned)((int)u3 >= (int)(unsigned)(garr[i1 & 7u] && a0[i0 & 3u]))) break;
                q0 = &garr[(((u1 & 1u) * (unsigned)s0) << ((unsigned)((int)4u >= (int)0u) & 31u)) & 7u];
                i1 = ((unsigned)(w0 >> 29) ^ (unsigned)l0) & 15u;
                if (v0) break;
                m0 ^= ~(unsigned)((unsigned)f0 || (7u * p2));
            } while (i1++ < 7u && (g0 & 0x80000000u));
            if ((unsigned)(0x9c7e0480u < garr[u2 & 7u])) {
                break; (void)((unsigned)x0);
            } else {
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)((short)(unsigned)x0 > (signed char)(0x15402e5u - 0xffffffffu)) < (int)((unsigned)d0 << ((unsigned)x0 & 31u)));
                garr[g1 & 7u] = 0xfa05bbe7u;
                if (((r0.y - 8u) % (i2 | 1u))) {
                    u1 = ((unsigned)(w0 >> 29) | (unsigned)!((r0.y << ((unsigned)h0 & 31u)) / ((unsigned)s0 | 1u)));
                    { unsigned t4; double z4; if ((0x21593461u) & 1u) { t4 = (3u << (a0[i0 & 3u] & 31u)); z4 = (double)(((unsigned)(unsigned char)(unsigned)((int)u3 < (int)(unsigned)(unsigned char)((unsigned)c1 | (unsigned)(x0 >> 70)))) & 255u); } if ((0x21593461u) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                        if ((8u - (0xa541b6feu << (8u & 31u)))) break;
                    }
                    goto L3;
                }
            }
        } else {
            h1 = (unsigned short)(h1 + (~(unsigned)((short)*mp > (signed char)(unsigned)(0x7fffffffu == (unsigned)h1)) << (p1 & 31u)));
            w0 ^= (unsigned long long)9u << ((unsigned)((int)~(p2 >> ((unsigned)w0 & 31u)) < (int)((unsigned)(w0 >> 29) | (p2 >> ((unsigned)e0 & 31u)))) & 63u);
            if (((unsigned)s1 * 0xffffffffu)) {
                break; (void)((i1 | 0xffffffffu));
                if ((unsigned)(short)(unsigned)((unsigned)w0 < g1)) break;
                if (-(unsigned)((int)((unsigned)s1 | a0[u1 & 3u]) < (int)0xffffffffu)) {
                    c0 = (unsigned char)i0;
                    while (i1++ < 5u && (0x80000000u << ((unsigned)(2u && r0.y) & 31u))) { if (--fuel == 0u) goto done;
                        { unsigned t5; double z5; if (((g1 * u1)) & 1u) { t5 = (unsigned)((int)0x8e9dd4f5u < (int)(unsigned)b0); z5 = (double)((0x10000u) & 255u); } if (((g1 * u1)) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                            r0.x = ((unsigned)h0 & ((0xb4039943u >> ((unsigned)(x0 >> 70) & 31u)) + 7u));
                            c0 = (unsigned char)(u0 + (unsigned)(u3 || garr[i1 & 7u]));
                        }
                        u0 = u0 * 0x9e3779b1u + 9u;
                        if ((unsigned)(((unsigned)h0 ^ u0) == p2)) break;
                        if (((unsigned)((short)1u > (signed char)garr[u2 & 7u]) << (0x5c65fb37u & 31u))) break;
                    }
                    if ((unsigned)((int)(unsigned)e0 < (int)(unsigned)e0)) break;
                } else {
                    *mp = (((unsigned)c0 / ((unsigned)(p2 < i0) | 1u)) | (unsigned)(0xffffffffu < g0));
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        i2 = ((unsigned)((unsigned)d0 < r0.x) + (m0 % (0xb167cccdu | 1u))) & 15u;
                        if ((((unsigned)d0 >> (0xc503768fu & 31u)) * a0[i0 & 3u])) break;
                        break; (void)(g0);
                    }
                    if (u3 == 7u) return ((unsigned)(0xffffffffu || 0x50eb59b7u) ^ 2u);
                }
                if ((unsigned)!(unsigned)((int)(unsigned)l0 < (int)(unsigned)w0)) {
                    r0.x = (unsigned)(short)((unsigned)x0 ^ ((unsigned)l0 | (unsigned)(short)(0x10000u + v0)));
                    c0 = (unsigned char)(unsigned)(i2 == (((unsigned)e0 - 0x7fffffffu) << ((garr[i1 & 7u] << (fuel & 31u)) & 31u)));
                    v0 = (unsigned)!(unsigned)((int)(unsigned)b0 >= (int)((unsigned)((unsigned)l0 || (unsigned)x0) ^ 0xffffffffu));
                    l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)w0 == 3u) * ((unsigned)((unsigned)s0 && (unsigned)(w0 >> 29)) | u0)));
                } else {
                    if (i1) break;
                    goto done;
                    if (~(unsigned)(-(0xefd8d5b3u >> (garr[u2 & 7u] & 31u)) == g0)) continue;
                    w0 = w0 * 6364136223846793005ull + (unsigned)(((unsigned)h0 % ((unsigned)(w0 >> 29) | 1u)) < (m0 | (*mp - (unsigned)h1)));
                }
                if (((*q0 >> (a0[i0 & 3u] & 31u)) + 0xffffffffu)) break;
                garr[(g0 | 9u) & 7u] = ((9u << ((unsigned)(u3 && u3) & 31u)) & (unsigned)(0x7fffffffu == r0.y));
            }
        }
    }
    if ((unsigned)(r0.y || (unsigned)((int)(unsigned)h1 < (int)0x23b271a4u))) goto done;
    b0 = garr[i1 & 7u] != 0u;
    x0 = x0 * 0x100000001b3ull + (p1 ^ (unsigned)(short)((unsigned)(unsigned char)((unsigned)(x0 >> 70) >> (p1 & 31u)) - m0));
    u3 += i1;
    if (~(0x4768df7bu % ((u2 >> ((unsigned)s1 & 31u)) | 1u))) goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if ((~(unsigned)(0xffffffffu || fuel)) & 1u) { t0 = (unsigned)(signed char)(unsigned)((int)0xffffffffu >= (int)garr[u2 & 7u]); z0 = (double)(((a0[i0 & 3u] ^ (v0 >> (0xe3056654u & 31u)))) & 255u); } if ((~(unsigned)(0xffffffffu || fuel)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        { unsigned t1; double z1; if (((3u % ((unsigned)((unsigned)s0 < 9u) | 1u))) & 1u) { t1 = (7u << (i0 & 31u)); z1 = (double)((((u3 / (*q0 | 1u)) + g1)) & 255u); } if (((3u % ((unsigned)((unsigned)s0 < 9u) | 1u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            v0 = ((unsigned)s0 * (unsigned)((g1 | (0xe73f253du >> (0xba4791a0u & 31u))) || garr[i1 & 7u]));
            c0 = (unsigned char)(unsigned)f0;
            if (((a0[u1 & 3u] | u3) << ((unsigned)(w0 >> 29) & 31u))) goto L4;
            if ((g1 - (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)h0))) goto L4;
            { unsigned t2; double z2; if (((u1 * u1)) & 1u) { t2 = (0xe7b75778u / ((unsigned)h1 | 1u)); z2 = (double)(((unsigned)(signed char)((unsigned)s0 ^ 0x80000000u)) & 255u); } if (((u1 * u1)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                u1 = (unsigned)((short)p0 > (signed char)((8u ^ v0) & (fuel % ((unsigned)(x0 >> 70) | 1u))));
                m0 ^= 0x80000000u;
            }
            if ((unsigned)(short)(unsigned)((int)0x10000u >= (int)a0[u1 & 3u])) goto L3;
        }
    }
    { unsigned t3; double z3; if (((0xa0e85d96u ^ 5u)) & 1u) { t3 = (unsigned)d0; z3 = (double)((0xffffffffu) & 255u); } if (((0xa0e85d96u ^ 5u)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        g1 += r0.x;
        s1 = (int)((unsigned)s1 + (unsigned)((3u / ((unsigned)c1 | 1u)) == (unsigned)((int)p1 < (int)0x80000000u)));
        l0 = (long)((unsigned long)l0 + (v0 ? garr[i1 & 7u] : (unsigned)b0));
        if (budget != 0u) { budget -= 1u; u1 = fn0((0x8b978deeu + ((unsigned)s1 * (unsigned)h1)), 4u, g0); }
    }
    if (i0) {
        e0 = e0 * 0.5L + (long double)((unsigned)((short)0xa9562871u > (signed char)a0[i0 & 3u]) & 1023u);
        u2 = u2 * 0x9e3779b1u + -(unsigned)((int)a0[i0 & 3u] >= (int)((unsigned)(signed char)(i1 + m0) | (g0 | 0xa63d05feu)));
        u1 ^= (0xffffffffu << (0x30327dedu & 31u));
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0(0x7fffffffu, ((unsigned)(0x2730f6b6u == (unsigned)d0) / (0x7fffffffu | 1u)), fuel); }
            g0 = 0x83b8dbf3u;
            f0 = f0 * 0.5f + (float)((unsigned)((int)i1 >= (int)(3u - (0xdffcb9e9u + (unsigned)c0))) & 255u);
            h1 = (unsigned short)(h1 + 8u);
            break; (void)(5u);
        }
    }
    do { if (--fuel == 0u) goto done;
        if (-(unsigned)((8u | (unsigned)f0) || a0[u1 & 3u])) {
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)((unsigned)b0 ? 0x80000000u : g1);
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0(i0, (unsigned)x0, 0x80000000u); }
        continue; (void)((p2 >> (u3 & 31u)));
    } while (i0++ < 7u && -(unsigned)((int)(fuel + (unsigned)e0) < (int)(unsigned)(x0 >> 70)));
    if (0x80000000u) {
        if (((0x56a149ecu / ((unsigned)h1 | 1u)) + v0)) {
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s1 | 0x4a86d866u), (unsigned)((int)0x10000u < (int)(unsigned)(short)(3u | 1u)), (unsigned)(u0 && 9u)); }
            if ((unsigned)(x0 >> 70)) goto L1;
            u3 = u3 * 0x9e3779b1u + ((0x10000u + (unsigned)s1) & (unsigned)(garr[u2 & 7u] || 0x5fc7b313u));
            if ((unsigned)(w0 >> 29)) {
                m0 ^= (unsigned)!(unsigned)((0x7fffffffu | 2u) || (0x6cfd599du % ((unsigned)((int)2u >= (int)(unsigned)c0) | 1u)));
                if (budget != 0u) { budget -= 1u; u2 = fn0(3u, (unsigned)(x0 >> 70), (unsigned)(3u || u3)); }
            }
            q0 = &garr[u0 & 7u];
            if (u2) goto L2;
        }
        f0 = f0 * 0.5f + (float)((unsigned)((short)(u2 + (unsigned)h0) > (signed char)0u) & 255u);
        switch ((5u / (a0[u1 & 3u] | 1u)) & 7u) {
            g1 += (0x7fffffffu | (unsigned)b0);
        }
        v0 = (unsigned)((p1 >> ((unsigned)s1 & 31u)) && ((unsigned)(0x80000000u < 0xd03677du) - 6u));
        while (i0++ < 7u && 0x80000000u) { if (--fuel == 0u) goto done;
            while (-(unsigned)(r0.x == p0)) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)h0);
            }
            *q0 = ((unsigned)((int)(g1 * (unsigned)d0) < (int)r0.x) & ((unsigned)b0 << (0u & 31u)));
            for (;;) { if (--fuel == 0u) goto done;
                goto L1;
                if ((unsigned)(*q0 || 6u)) break;
                L0: if (--fuel == 0u) goto done;
            }
        }
    }
    goto L4;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)garr[u2 & 7u] >= (int)g1), fuel, 9u); }
    w0 ^= (unsigned long long)0x80000000u << (*mp & 63u);
    if (((unsigned)c0 * 0x7fffffffu)) {
        r0.x = (unsigned)(signed char)((unsigned)((int)fuel >= (int)a0[u1 & 3u]) | (unsigned)!(unsigned)((unsigned)w0 && (unsigned)(u2 || v0)));
        L1: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0(~(unsigned)((int)(unsigned)s0 < (int)(unsigned)(p2 < 0x80000000u)), ~(unsigned)((unsigned)(x0 >> 70) < i0), ((unsigned)d0 % ((unsigned)((unsigned)c1 || m0) | 1u))); }
        l0 = (long)((unsigned long)l0 + (unsigned)((short)(unsigned)d0 > (signed char)-(unsigned)((unsigned)h1 < (((unsigned)(x0 >> 70) + g0) + (unsigned)h1))));
        L2: if (--fuel == 0u) goto done;
    }
    goto L2;
    do { if (--fuel == 0u) goto done;
        if ((0xffffffffu >> (0xa3c95bd1u & 31u))) goto L0;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t4; double z4; if ((u2) & 1u) { t4 = ((unsigned)l0 / ((unsigned)((short)i1 > (signed char)6u) | 1u)); z4 = (double)((p0) & 255u); } if ((u2) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                u1 = u1 * 0x9e3779b1u + -(p2 % ((unsigned)!(unsigned)((short)garr[i1 & 7u] > (signed char)4u) | 1u));
                L3: if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
            }
            h1 = (unsigned short)(h1 + (p2 | (unsigned)(8u || (((unsigned)h0 - m0) & r0.y))));
            if (fuel < 8u) return ((unsigned)(x0 >> 70) ^ (unsigned)((unsigned)(0x74ac5bcfu || 9u) < i0));
            do { if (--fuel == 0u) goto done;
                break; (void)(garr[u2 & 7u]);
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)h0, (unsigned)((short)(unsigned)!(fuel % (i0 | 1u)) > (signed char)p1), fuel); }
            } while (i2++ < 7u && (unsigned)(unsigned char)((unsigned)x0 ? (unsigned)c0 : (unsigned)c0));
            v0 = (u1 ? (u1 / (u1 | 1u)) : (0xffffffffu | 8u));
            *mp = (((0x7fffffffu ^ (unsigned)l0) / ((unsigned)((unsigned)l0 && (unsigned)f0) | 1u)) % (u2 | 1u));
        }
        if (((0xbd75ce53u << (0x10000u & 31u)) & (unsigned)d0)) break;
        if (budget != 0u) { budget -= 1u; u3 = fn0(v0, (u2 - (unsigned)((int)0x7fffffffu < (int)i2)), (unsigned)(w0 >> 29)); }
    } while (i0++ < 7u && (p0 << (garr[i1 & 7u] & 31u)));
    d0 = d0 * 0.5 + (double)((a0[i0 & 3u] - (unsigned)((0xffffffffu & a0[u1 & 3u]) || *q0)) & 1023u);
    w0 = w0 * 6364136223846793005ull + ((unsigned)(3u && p2) & i0);
    u2 ^= ((unsigned)(((unsigned)w0 % (((unsigned)w0 - r0.x) | 1u)) || (unsigned)h0) + r0.x);
    switch (~(unsigned)((int)a0[i0 & 3u] >= (int)garr[i1 & 7u]) & 7u) {
        { unsigned t5; double z5; if ((0xffffffffu) & 1u) { t5 = (unsigned)((int)p1 >= (int)u2); z5 = (double)(((2u * -((unsigned)h1 / ((unsigned)(w0 >> 29) | 1u)))) & 255u); } if ((0xffffffffu) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            *q0 += (unsigned)(signed char)((m0 - (unsigned)(u2 || (unsigned)l0)) / (i0 | 1u));
            case 6u: ;
            case 2u: ;
        }
        case 3u: ;
    }
    if ((unsigned)s0) goto L2;
    if (u1) goto done;
    e0 = e0 * 0.5L + (long double)((unsigned)((short)garr[u2 & 7u] > (signed char)(7u ^ ((unsigned)b0 >> (8u & 31u)))) & 1023u);
    if (~(unsigned)(a0[u1 & 3u] && v0)) goto done;
    { unsigned t6; double z6; if (((unsigned)(*mp && g1)) & 1u) { t6 = ((unsigned)(p2 && p1) % ((unsigned)l0 | 1u)); z6 = (double)(((unsigned)((short)*q0 > (signed char)0x609c66cu)) & 255u); } if (((unsigned)(*mp && g1)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
        if ((unsigned)!(((unsigned)h0 * (unsigned)e0) | 0x55dac8a7u)) goto L4;
        if ((u0 ^ ~(unsigned)((int)(unsigned)h0 >= (int)0x80000000u))) goto L3;
        if ((((unsigned)(x0 >> 70) % ((unsigned)x0 | 1u)) / ((unsigned)w0 | 1u))) {
            v0 = ((garr[i1 & 7u] + 3u) ? u1 : r0.x);
            e0 = e0 * 0.5L + (long double)((unsigned)((int)(u3 | g0) >= (int)~(unsigned)((unsigned)(i1 && u1) == u3)) & 1023u);
            goto L4;
        } else {
            s0 = (int)u1;
            goto L2;
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((i1 - (unsigned)((int)0x14bda9c6u < (int)(unsigned)s1)), (unsigned)((0x80000000u * (unsigned)e0) < 3u), garr[i1 & 7u]); }
                do { if (--fuel == 0u) goto done;
                    continue; (void)(1u);
                    u1 ^= (unsigned)((int)(p1 & (v0 << (a0[i0 & 3u] & 31u))) < (int)0x42959f5au);
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)f0 / (r0.x | 1u)), (unsigned)(0x738a48f4u && g1), (unsigned)((int)0xffffffffu >= (int)-(p2 >> ((unsigned)h1 & 31u)))); }
                    { unsigned t7; double z7; if (((unsigned)w0) & 1u) { t7 = p0; z7 = (double)(((unsigned)((*q0 ^ (unsigned)(x0 >> 70)) || u3)) & 255u); } if (((unsigned)w0) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                        continue; (void)((fuel * (unsigned)e0));
                        garr[(unsigned)x0 & 7u] = (0x80000000u % ((unsigned)(*q0 == 0x2dfa83dcu) | 1u));
                        if (budget != 0u) { budget -= 1u; u2 = fn0((0x80000000u % (v0 | 1u)), 0x5a08a168u, (unsigned)(signed char)(unsigned)(i1 == (unsigned)s1)); }
                    }
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (((unsigned)h0 ? g1 : (unsigned)x0)) break;
                        h0 = (short)(unsigned)c1;
                        if (0xffffffffu) goto L3;
                        if ((unsigned)((unsigned)s0 || (unsigned)h1)) continue;
                        u3 ^= (g0 | p1);
                    }
                } while (i1++ < 2u && (unsigned)((unsigned)((int)(unsigned)w0 < (int)fuel) == (unsigned)(x0 >> 70)));
                break; (void)(((unsigned)(signed char)(unsigned)((unsigned)h0 < g1) / (r0.y | 1u)));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!((unsigned)s0 & r0.y), (0x2fa575e8u & (g0 - a0[u1 & 3u])), 0xffffffffu); }
                if (budget != 0u) { budget -= 1u; u1 = fn0(u3, (unsigned)((int)(unsigned)s1 >= (int)((unsigned)f0 + (unsigned)d0)), (unsigned)((unsigned)(0x83f40227u && u3) || 9u)); }
            }
            b0 = (unsigned)f0 != 0u;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)h1 * (garr[i1 & 7u] ^ (unsigned)w0)), ((unsigned)f0 % ((u1 | (unsigned)w0) | 1u)), ((unsigned)l0 >> (0xca756d4cu & 31u))); }
        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(x0 >> 70) ^ 0xdb982b0u), (unsigned)!((unsigned)w0 << (1u & 31u)), ((unsigned)x0 / ((unsigned)e0 | 1u))); }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0(0u, (a0[i0 & 3u] + i1), i1); }
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(i0 % ((unsigned)(w0 >> 29) | 1u)) >= (int)r0.x), (u2 - u2), (unsigned)(unsigned char)(4u + u3)); }
    if (budget != 0u) { budget -= 1u; u0 = fn0(1u, (unsigned)(short)(unsigned)((int)(unsigned)h1 >= (int)(unsigned)f0), (g0 % (a0[i0 & 3u] | 1u))); }
    u2 ^= (0x41998872u * (unsigned)(w0 >> 29));
    e0 = e0 * 0.5L + (long double)(*q0 & 1023u);
    while (i0++ < 6u && (unsigned)(8u == -(unsigned)((unsigned)s0 && 0xebcb3ce1u))) { if (--fuel == 0u) goto done;
        *q0 = ((unsigned)(short)(unsigned)(i0 == fuel) % ((unsigned)((int)-(0x35a7d412u << (a0[i0 & 3u] & 31u)) >= (int)0x8d8ec906u) | 1u));
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)l0 == (unsigned)e0), 0x10000u, 0x5e8e40b0u); }
        l0 = (long)((unsigned long)l0 + (unsigned)((short)p0 > (signed char)(unsigned)((unsigned)(4u == (garr[u2 & 7u] & 9u)) == 9u)));
        if ((garr[i1 & 7u] & (unsigned)l0)) {
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(fuel, (unsigned)(unsigned char)(1u | (i1 / (p2 | 1u))), (((unsigned)s0 - (unsigned)s0) / (r0.x | 1u))); }
                while (((unsigned)c1 >> (9u & 31u))) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(p1, (r0.y | (unsigned)((int)v0 >= (int)(unsigned)d0)), (unsigned)(garr[i1 & 7u] < (fuel ^ (unsigned)x0))); }
                    if ((v0 | garr[u2 & 7u])) {
                        if (((unsigned)l0 + p0)) goto L1;
                    }
                    *q0 += u3;
                }
                if (p0) break;
            }
            do { if (--fuel == 0u) goto done;
                if (~(u1 << ((unsigned)x0 & 31u))) goto L1;
                if (budget != 0u) { budget -= 1u; u2 = fn0(0x80000000u, 9u, 2u); }
                if (0x273fa086u) break;
                if ((unsigned)d0) break;
                goto L3;
                g1 += (unsigned)b0;
            } while (i1++ < 6u && (unsigned)b0);
        } else {
            c1 = (signed char)((0x80000000u | 0x80000000u) - -(unsigned)(p1 || i1));
            c1 = (signed char)((unsigned)c0 + (unsigned)((unsigned)(unsigned char)(unsigned)(0x10000u < p0) && a0[i0 & 3u]));
        }
        m0 ^= (unsigned)((short)u0 > (signed char)(garr[i1 & 7u] & p1));
        if ((unsigned)(short)(((unsigned)(x0 >> 70) / (*q0 | 1u)) & p2)) {
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)(short)(unsigned)((int)(unsigned)l0 < (int)0xa93023e7u) < g1);
            *q0 = (unsigned)((short)(unsigned)d0 > (signed char)(unsigned)(short)(7u >> (((unsigned)d0 | (unsigned)((int)i0 >= (int)r0.y)) & 31u)));
            do { if (--fuel == 0u) goto done;
                *q0 += (5u & 1u);
                if (((unsigned)h1 % (((unsigned)l0 / ((unsigned)c1 | 1u)) | 1u))) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)x0 & 0x80000000u), (unsigned)(u2 < i0), (p2 + (r0.y ^ (unsigned)d0))); }
            } while (i1++ < 2u && ((unsigned)l0 - (unsigned)c1));
            if ((unsigned)(short)((0xa3408c81u ^ g0) | (unsigned)(x0 >> 70))) break;
        } else {
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)b0 == -(unsigned)((int)(unsigned)d0 >= (int)(unsigned)w0)), (0x80000000u + p2), (unsigned)(w0 >> 29)); }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(0x10000u >> (0u & 31u)) >= (int)v0), ((unsigned)c1 >> (v0 & 31u)), (unsigned)((int)0x1baf5aa7u >= (int)(i2 >> (4u & 31u)))); }
            if (u3 == 7u) return ((unsigned)h0 ^ i0);
        }
    }
    if ((unsigned)f0) {
        while (i0++ < 3u && r0.x) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(r0.y < ((unsigned)d0 >> (*q0 & 31u)))) goto L4;
                if ((unsigned)(4u && (0x10000u ^ (unsigned)c1))) break;
                u1 ^= (((0x80000000u - 8u) ^ (unsigned)d0) << ((unsigned)x0 & 31u));
                r0.x = (i0 % (u1 | 1u));
            }
            w0 ^= (unsigned long long)garr[i1 & 7u] << ((unsigned)h0 & 63u);
            while (i1++ < 3u && fuel) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(r0.y, (unsigned)(short)((unsigned)((int)0x10000u >= (int)(unsigned)s1) << (i1 & 31u)), (unsigned)((int)u1 >= (int)0x71473614u)); }
                if ((((unsigned)w0 * (unsigned)l0) - (unsigned)h1)) break;
                m0 ^= v0;
                garr[(unsigned)((int)i0 >= (int)a0[u1 & 3u]) & 7u] = ((unsigned)l0 << (4u & 31u));
            }
            e0 = e0 * 0.5L + (long double)((unsigned)((short)0xb1d2a642u > (signed char)(unsigned)(unsigned char)((unsigned)(p0 && ((unsigned)f0 / (m0 | 1u))) - 0x7fffffffu)) & 1023u);
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(r0.x && 0xffffffffu), ((garr[i1 & 7u] - (unsigned)(x0 >> 70)) + i2), (u1 ? 0x10000u : (unsigned)s1)); }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)c1 >= (int)g1), ((unsigned)h1 >> (~((unsigned)e0 - 0x7fffffffu) & 31u)), (unsigned)(unsigned char)((unsigned)((unsigned)s1 == a0[i0 & 3u]) << ((unsigned)c1 & 31u))); }
        if (8u) {
            if ((unsigned)c0) goto done;
            switch ((0x9b54e3aau + *q0) & 7u) {
                u3 ^= (unsigned)(((unsigned)w0 / (0x10000u | 1u)) || (unsigned)s1);
            }
            if (r0.x) {
                goto done;
            }
            if ((v0 & ((unsigned)d0 & 0xffffffffu))) goto L3;
        } else {
            a0[p1 & 3u] = (u3 | (unsigned)(0xffffffffu && (v0 * p1)));
            if ((unsigned)(x0 >> 70)) {
                *q0 = 0x1a578b2cu;
                i0 = (((unsigned)s1 >> ((unsigned)f0 & 31u)) & (6u + (unsigned)b0)) & 15u;
                *q0 += ((0x7fffffffu >> (((0xb1335fc7u ^ 4u) % ((unsigned)w0 | 1u)) & 31u)) | (unsigned)h1);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)c1, 4u, *mp); }
                w0 ^= (unsigned long long)(unsigned)w0 << ((g0 ^ i2) & 63u);
                if (garr[u2 & 7u]) {
                    b0 = (0u ? (unsigned)x0 : garr[u2 & 7u]) != 0u;
                    s0 = (int)(u2 | (unsigned)((unsigned)(r0.y || (r0.y ^ u1)) == 0x80000000u));
                    h1 = (unsigned short)(h1 + (unsigned)(((unsigned)((short)(unsigned)x0 > (signed char)u0) * m0) || 0x80000000u));
                    *mp = (((unsigned)(i0 || v0) ^ (r0.x + (unsigned)c0)) * 7u);
                    goto L1;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)((int)garr[i1 & 7u] < (int)*q0) == (unsigned)s1), (r0.y + u0), garr[i1 & 7u]); }
                }
            } else {
                if (i0) goto done;
            }
        }
        if ((unsigned)!(unsigned)(*q0 == (unsigned)((short)0x7fffffffu > (signed char)(unsigned)c1))) {
            c1 = (signed char)(((unsigned)w0 + i0) << ((unsigned)(unsigned char)(g1 ^ 8u) & 31u));
            switch ((i0 | *q0) & 7u) {
                case 2u: ;
                if ((unsigned)(short)(unsigned)(((unsigned)s0 / ((unsigned)(w0 >> 29) | 1u)) == (unsigned)x0)) break;
                if ((m0 - fuel)) goto L3;
                if (u3 == 7u) return ((unsigned)(i1 && (unsigned)w0) & ((unsigned)(w0 >> 29) / (i1 | 1u)));
            }
            r0.x = (unsigned)(unsigned char)(((unsigned)h1 + u0) / (p2 | 1u));
            if ((unsigned)(x0 >> 70)) {
                if (((unsigned)e0 - p1)) goto L2;
                h1 = (unsigned short)(h1 + ((unsigned)s0 - 3u));
                if (fuel < 8u) return (unsigned)(u0 < (unsigned)((int)u2 < (int)i0));
                a0[0x7fffffffu & 3u] = (unsigned)(0x80000000u == (unsigned)h1);
            }
            if ((p0 % (8u | 1u))) goto done;
            q0 = &garr[(unsigned)((short)(unsigned)((short)(0x10000u + (unsigned)e0) > (signed char)(5u ^ 0u)) > (signed char)r0.y) & 7u];
        }
        if (u2) goto done;
    } else {
        switch ((unsigned)((int)((unsigned)(w0 >> 29) >> (8u & 31u)) >= (int)0xafd60ab8u) & 7u) {
            *q0 = (0xe095bb5fu ^ (unsigned)((short)fuel > (signed char)(0xeeec1f39u + (unsigned)((short)m0 > (signed char)0xffffffffu))));
            if ((unsigned)(0x8a0cb0dcu == (unsigned)s0)) break;
        }
        w0 ^= (unsigned long long)(unsigned)((int)u1 >= (int)0x8577c210u) << (-(unsigned)(g1 && ((unsigned)((short)m0 > (signed char)g1) + u2)) & 63u);
        r0.y ^= -(unsigned)((int)((unsigned)s1 / (r0.x | 1u)) < (int)0xcb3a8defu);
    }
    m0 ^= ((unsigned)f0 % (0xa1ff1915u | 1u));
    if ((unsigned)(p2 && 0x63d163aau)) goto L4;
    { unsigned t8; double z8; if ((((garr[u2 & 7u] % ((unsigned)s0 | 1u)) >> (8u & 31u))) & 1u) { t8 = (unsigned)(unsigned char)(unsigned)(0xa3827caeu < i0); z8 = (double)((u1) & 255u); } if ((((garr[u2 & 7u] % ((unsigned)s0 | 1u)) >> (8u & 31u))) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
        goto L0;
        if ((0x7fffffffu | 0x10000u)) goto L4;
        f0 = f0 * 0.5f + (float)(((unsigned)(short)(*q0 << ((unsigned)s0 & 31u)) - (0x7fffffffu % (1u | 1u))) & 255u);
        if ((unsigned)s0) goto L3;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (p0) goto L1;
    }
    if ((0x80000000u % (6u | 1u))) goto done;
    if ((unsigned)(signed char)(unsigned)((int)0x3abc4465u < (int)*mp)) goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u3 = fn0((((unsigned)c0 << (g0 & 31u)) | (unsigned)x0), r0.y, ((unsigned)c1 ? p2 : 8u)); }
    h0 = (short)p0;
    q0 = &garr[((unsigned)(unsigned char)(unsigned)(0x4126c652u || r0.y) >> (0xffffffffu & 31u)) & 7u];
    while (u3) { if (--fuel == 0u) goto done;
        a0[(unsigned)(x0 >> 70) & 3u] = (unsigned)((int)(unsigned)e0 < (int)(unsigned)(x0 >> 70));
        L0: if (--fuel == 0u) goto done;
    }
    do { if (--fuel == 0u) goto done;
        if (0x734426ecu) goto L4;
        L1: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)f0 && 0x10000u), -(unsigned)((short)i1 > (signed char)(unsigned)((unsigned)s0 && (unsigned)c1)), (unsigned)x0); }
        if ((unsigned)f0) continue;
        w0 ^= (unsigned long long)(r0.y ^ (unsigned)c1) << ((2u >> ((a0[i0 & 3u] / ((unsigned)s0 | 1u)) & 31u)) & 63u);
    } while (i0++ < 2u && (unsigned)(a0[i0 & 3u] && (unsigned)w0));
    e0 = e0 * 0.5L + (long double)(((i0 / ((0x10000u ? 0xffffffffu : 3u) | 1u)) ^ v0) & 1023u);
    if ((r0.x & 6u)) goto L3;
    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((short)g1 > (signed char)(unsigned)l0) && (2u ^ m0)) & 255u);
    *q0 += (r0.y >> ((p2 - (unsigned)(unsigned char)(unsigned)(r0.y && fuel)) & 31u));
    if (budget != 0u) { budget -= 1u; u3 = fn1(0xffffffffu, (unsigned)(i0 && (unsigned)(0x77b2f250u && (unsigned)(w0 >> 29))), ((unsigned)h0 + g1)); }
    d0 = d0 * 0.5 + (double)(((unsigned)h1 % ((unsigned)((short)(unsigned)(short)(0x10000u % (0xffffffffu | 1u)) > (signed char)(unsigned)h1) | 1u)) & 1023u);
    { unsigned t0; double z0; if ((g0) & 1u) { t0 = ((unsigned)f0 - (unsigned)s1); z0 = (double)(((unsigned)(9u == 6u)) & 255u); } if ((g0) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        g0 = (0xb492c90bu << (g1 & 31u));
    }
    g1 += (unsigned)c1;
    d0 = d0 * 0.5 + (double)((unsigned)!(u2 % (u1 | 1u)) & 1023u);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t1; double z1; if ((g1) & 1u) { t1 = (6u & (r0.x * 0x8c729c15u)); z1 = (double)(((unsigned)(0xb0cee348u && 6u)) & 255u); } if ((g1) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            if ((g1 ^ 0x22d59182u)) {
                c0 = (unsigned char)(u3 ^ (unsigned)d0);
                L2: if (--fuel == 0u) goto done;
                i0 = 0xaaf13ccu & 15u;
                continue; (void)((unsigned)(8u && (unsigned)x0));
                L3: if (--fuel == 0u) goto done;
            }
            L4: if (--fuel == 0u) goto done;
        }
        while (((unsigned)x0 % (r0.y | 1u))) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)(((unsigned)((int)i0 >= (int)(unsigned)e0) ? a0[u1 & 3u] : (unsigned)s0) < 0x7fffffffu));
            switch ((unsigned)((int)(unsigned)((int)0x8925ac2bu < (int)0xf6e1536fu) >= (int)garr[u2 & 7u]) & 7u) {
                if ((unsigned)(i2 || p0)) {
                    if ((unsigned)((unsigned)x0 || g0)) continue;
                    case 6u: ;
                    h1 = (unsigned short)(h1 + (unsigned)((6u | p1) < (p1 + (unsigned)(*q0 < 0x80000000u))));
                    { unsigned t2; double z2; if ((0x4adcc53au) & 1u) { t2 = (0x10000u | 8u); z2 = (double)(((0x74b19980u >> (0x7fffffffu & 31u))) & 255u); } if ((0x4adcc53au) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                        *q0 = 8u;
                    }
                    case 3u: ;
                    r0.x = (unsigned)(signed char)(((0x92eec399u >> (r0.y & 31u)) << ((unsigned)(w0 >> 29) & 31u)) | *mp);
                } else {
                    *mp = a0[u1 & 3u];
                    if ((2u << ((unsigned)(w0 >> 29) & 31u))) break;
                    if (((unsigned)e0 * (r0.x | garr[i1 & 7u]))) continue;
                    s0 = (int)((unsigned)!((unsigned)e0 ? u3 : 0x7fffffffu) ? 0u : 0x1b54ed07u);
                }
                v0 = 0x7fffffffu;
                { unsigned t3; double z3; if ((g1) & 1u) { t3 = g0; z3 = (double)(((unsigned)(0u < i2)) & 255u); } if ((g1) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)h0 >= (int)((unsigned)h1 * 0xffffffffu)));
                    switch ((*mp | (unsigned)s1) & 7u) {
                        e0 = e0 * 0.5L + (long double)((4u ? 1u : 0x223d45fdu) & 1023u);
                        if ((u2 + m0)) goto L4;
                        u2 = u2 * 0x9e3779b1u + (7u + (unsigned)(0xbb7e404eu < garr[i1 & 7u]));
                        *mp = (unsigned)((unsigned)s1 == u2);
                    }
                    default: ;
                }
                h1 = (unsigned short)(h1 + (unsigned)(~(unsigned)((unsigned)h0 == fuel) == 0x7fffffffu));
            }
            while (i2++ < 5u && p1) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)((unsigned)c1 ^ 0x80000000u) > (signed char)0x10000u), (unsigned)f0, (unsigned)((unsigned)b0 || r0.x)); }
                if (~(unsigned)((unsigned)(x0 >> 70) || *q0)) {
                    c0 = (unsigned char)(unsigned)((short)(unsigned)h1 > (signed char)(-(unsigned)((unsigned)(signed char)(7u & (unsigned)d0) == i1) + u1));
                    if (((0x10000u - 0x8c389bfbu) | 0x10000u)) continue;
                }
            }
            while (i2++ < 3u && ((unsigned)s0 | (unsigned)w0)) { if (--fuel == 0u) goto done;
                u1 = u1 * 0x9e3779b1u + (unsigned)h1;
                f0 = f0 * 0.5f + (float)((unsigned)!((unsigned)s1 ^ (unsigned)h0) & 255u);
                if (budget != 0u) { budget -= 1u; u1 = fn0(0x8d523107u, (m0 ? (unsigned)c0 : (unsigned)h1), r0.y); }
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    u3 += (unsigned)l0;
                    if (-(unsigned)((short)*q0 > (signed char)(unsigned)((unsigned)x0 && (unsigned)s1))) break;
                    if (0xce684017u) break;
                    if (((unsigned)c1 ? (unsigned)(w0 >> 29) : 0xf2e85b3cu)) break;
                    switch (i0 & 7u) {
                        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                            case 6u: ;
                            if (fuel < 8u) return ((unsigned)s1 | (u1 & (unsigned)((unsigned)(2u && 6u) < u3)));
                            a0[((unsigned)l0 + 0xb7053b30u) & 3u] = (unsigned)(0x80000000u && u1);
                        }
                        l0 = (long)((unsigned long)l0 + (unsigned)l0);
                        *q0 = (unsigned)w0;
                    }
                }
                w0 ^= (unsigned long long)(i0 - (unsigned)l0) << ((-(g0 & u3) - m0) & 63u);
            }
            switch (((unsigned)h0 | 0x50781f4au) & 7u) {
                r0.x = (unsigned)(g0 < (unsigned)((unsigned)(short)(p1 - garr[i1 & 7u]) == (unsigned)e0));
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)((unsigned)(x0 >> 70) ^ ~(0x7fffffffu - *mp)), (0x232e001du << ((u0 - (unsigned)d0) & 31u)), *mp); }
                e0 = e0 * 0.5L + (long double)((unsigned)((short)(*q0 + ((unsigned)h1 + (unsigned)s1)) > (signed char)(unsigned)(i1 && 7u)) & 1023u);
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x8e63a9d5u < (unsigned)((int)(unsigned)e0 < (int)(unsigned)b0)), (unsigned)(garr[u2 & 7u] < r0.y), (p1 + garr[u2 & 7u])); }
            }
            *mp = (unsigned)((int)(unsigned)f0 < (int)(unsigned)(((unsigned)x0 / (*q0 | 1u)) < (p1 << (garr[u2 & 7u] & 31u))));
        }
        if (i0) break;
        w0 = w0 * 6364136223846793005ull + 0x80000000u;
    }
    if ((unsigned)((int)(unsigned)f0 < (int)i2)) goto L3;
    if ((unsigned)(unsigned char)(unsigned)(0xf21b23d7u == fuel)) goto done;
    d0 = d0 * 0.5 + (double)((unsigned)e0 & 1023u);
    switch ((i1 | u0) & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(short)(unsigned)((int)(unsigned)e0 < (int)a0[u1 & 3u]) & r0.x), 8u, (a0[i0 & 3u] & (unsigned)(x0 >> 70))); }
        case 3u: ;
        if ((i1 | ((unsigned)x0 | u3))) {
            c1 = (signed char)fuel;
            c0 = (unsigned char)((unsigned)h1 >> (0x80000000u & 31u));
        } else {
            u0 ^= (garr[u2 & 7u] >> ((0xc378222u / (0x1722aad4u | 1u)) & 31u));
            f0 = f0 * 0.5f + (float)((((p0 >> (9u & 31u)) * garr[i1 & 7u]) & (unsigned)s1) & 255u);
            if ((unsigned)s1) {
                u0 += 7u;
                if (~((unsigned)c0 * 8u)) break;
                b0 = ((unsigned)(unsigned char)((unsigned)c1 >> (0x23c3649cu & 31u)) >> (((unsigned)h0 ? 0xf919d409u : u2) & 31u)) != 0u;
                if (((0x5df4c089u + u3) - (unsigned)c0)) goto L2;
                if (fuel < 8u) return (garr[i1 & 7u] ^ (unsigned)c0);
                if ((unsigned)(short)(0x7fffffffu >> (m0 & 31u))) {
                    r0.y ^= ((((unsigned)c0 - (unsigned)f0) | (unsigned)((int)i2 < (int)0x7fffffffu)) << ((unsigned)c1 & 31u));
                    if ((unsigned)(m0 == (*q0 << (0x4afcab0eu & 31u)))) {
                        break; (void)((0x9e6bdaau * 0xd6a14a25u));
                        x0 = x0 * 0x100000001b3ull + (unsigned)(u2 == ((unsigned)l0 * i2));
                    }
                }
            } else {
                if ((unsigned)(unsigned char)(unsigned)((short)(0x6c62bd1du >> (p0 & 31u)) > (signed char)0xffffffffu)) goto L1;
            }
            case 7u: ;
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)!((0u / ((unsigned)e0 | 1u)) + (unsigned)f0)) {
                c0 = (unsigned char)((unsigned)!(unsigned)(0x10000u || 0xffffffffu) << ((unsigned)(signed char)(0x10000u ? p2 : *q0) & 31u));
                if (budget != 0u) { budget -= 1u; u0 = fn0(0x5deb50f1u, (unsigned)c1, (i2 >> (0x10000u & 31u))); }
                u0 = (unsigned)((short)(unsigned)(r0.y && a0[u1 & 3u]) > (signed char)0xffffffffu);
                if (fuel) {
                    break; (void)(0xde2bdb82u);
                }
                *mp = (unsigned)((short)a0[i0 & 3u] > (signed char)(0x10000u ? fuel : 0x10000u));
            }
            c1 = (signed char)r0.x;
            continue; (void)((unsigned)f0);
            if (((0x73166723u % ((unsigned)f0 | 1u)) / ((unsigned)c0 | 1u))) {
                x0 = x0 * 0x100000001b3ull + (unsigned)(short)(unsigned)((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)(short)(unsigned)(0xf74a0648u && 0x10000u)) || ((unsigned)b0 * (unsigned)f0));
                if (budget != 0u) { budget -= 1u; u2 = fn1((0xc2d549d1u & u3), (unsigned)x0, (unsigned)((int)i0 < (int)a0[i0 & 3u])); }
                case 0u: ;
                do { if (--fuel == 0u) goto done;
                    u1 = ((unsigned)((short)0x80000000u > (signed char)u1) * (unsigned)(0x23d2ab40u < u3));
                } while (i1++ < 5u && u3);
                { unsigned t4; double z4; if ((~((unsigned)c0 / ((unsigned)((short)(unsigned)d0 > (signed char)i2) | 1u))) & 1u) { t4 = (unsigned)f0; z4 = (double)(((unsigned)(0x5e173cbcu || (unsigned)c0)) & 255u); } if ((~((unsigned)c0 / ((unsigned)((short)(unsigned)d0 > (signed char)i2) | 1u))) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                    e0 = e0 * 0.5L + (long double)(((unsigned)((short)*q0 > (signed char)0x7fffffffu) + (unsigned)b0) & 1023u);
                    r0.y ^= ((unsigned)(3u && (unsigned)d0) << ((unsigned)((p0 & i2) && garr[i1 & 7u]) & 31u));
                    if (r0.x) goto L0;
                    c1 = (signed char)-((unsigned)((short)((unsigned)(signed char)(unsigned)(0xffbeb161u && a0[i0 & 3u]) / ((unsigned)h1 | 1u)) > (signed char)g0) * r0.y);
                }
            }
            case 5u: ;
        }
        if ((unsigned)c0) break;
        while (i0++ < 5u && 9u) { if (--fuel == 0u) goto done;
            switch (((unsigned)(p1 < u0) >> ((unsigned)h0 & 31u)) & 7u) {
                w0 = w0 * 6364136223846793005ull + ~((unsigned)(9u == 0x274ca239u) / (0xffffffffu | 1u));
                if ((m0 - (unsigned)((int)(unsigned)w0 < (int)3u))) continue;
                case 1u: ;
                *mp = (0xefb63587u % ((unsigned)(short)(unsigned)((unsigned)s0 == i0) | 1u));
            }
            switch ((unsigned)(short)(unsigned)(u1 == (unsigned)h1) & 7u) {
                switch ((unsigned)((short)0x7fffffffu > (signed char)0u) & 7u) {
                    if ((p0 | (unsigned)(0x7f78a255u || (unsigned)e0))) {
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)(w0 >> 29) && (0xffffffffu % (9u | 1u))), (unsigned)(unsigned char)(i2 << ((unsigned)w0 & 31u)), (unsigned)((int)g1 >= (int)garr[u2 & 7u])); }
                        h0 = (short)0x10000u;
                        if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)h1 * u2), (unsigned)(signed char)(0x5ff929c2u + garr[u2 & 7u]), ((i0 % (i1 | 1u)) | (unsigned)f0)); }
                        case 0u: ;
                        goto L1;
                        case 1u: ;
                    }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(unsigned char)(unsigned)((int)8u < (int)(unsigned)s0), (a0[u1 & 3u] | a0[u1 & 3u]), ((0x9de3eaceu << (u2 & 31u)) ^ *mp)); }
                c0 = (unsigned char)((unsigned)(short)((unsigned)c1 + 0x10000u) | (unsigned)!((m0 + r0.x) << ((unsigned)w0 & 31u)));
                m0 ^= (unsigned)(0x80000000u == (unsigned)((int)4u < (int)(unsigned)(x0 >> 70)));
                for (;;) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((unsigned)((short)6u > (signed char)((garr[i1 & 7u] + (unsigned)h0) % ((r0.y | 7u) | 1u))) & 1023u);
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((0x80000000u & r0.y) < v0), u0, (0x7fffffffu << (u0 & 31u))); }
                    w0 ^= (unsigned long long)(unsigned)((unsigned)(w0 >> 29) == i1) << ((unsigned)((unsigned)(signed char)(unsigned)((short)4u > (signed char)((unsigned)(w0 >> 29) >> ((unsigned)l0 & 31u))) && 7u) & 63u);
                    if ((unsigned)(unsigned char)(~(m0 % (0xffffffffu | 1u)) * 7u)) break;
                }
                if ((unsigned)(x0 >> 70)) break;
            }
            h0 = (short)(unsigned)(i0 == u2);
            if ((unsigned)x0) {
                f0 = f0 * 0.5f + (float)((unsigned)((short)(unsigned)l0 > (signed char)u3) & 255u);
                if ((unsigned)(x0 >> 70)) break;
                do { if (--fuel == 0u) goto done;
                    default: ;
                    if ((garr[u2 & 7u] / ((unsigned)h0 | 1u))) goto L1;
                } while (i1++ < 7u && 0x5d5a60d6u);
                if (budget != 0u) { budget -= 1u; u3 = fn1(6u, (unsigned)(v0 && ((unsigned)f0 - garr[u2 & 7u])), (r0.x << ((u0 ^ i1) & 31u))); }
            }
            h0 = (short)(unsigned)((int)(unsigned)((short)(unsigned)(u0 == i1) > (signed char)9u) < (int)(unsigned)((short)a0[i0 & 3u] > (signed char)i2));
            w0 ^= (unsigned long long)v0 << ((((unsigned)d0 >> (i0 & 31u)) << (((unsigned)d0 ^ ((unsigned)s1 % (garr[u2 & 7u] | 1u))) & 31u)) & 63u);
        }
    }
    d0 = d0 * 0.5 + (double)(((unsigned)c0 % (p2 | 1u)) & 1023u);
    if ((i1 - 8u)) {
        if (i2) goto L3;
        e0 = e0 * 0.5L + (long double)(0x10000u & 1023u);
        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(0x7fffffffu ? 0x80000000u : 0x9d84621au) & 1023u);
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)0x483bb1u < (int)0x7fffffffu);
    while (4u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            { unsigned t5; double z5; if ((*q0) & 1u) { t5 = 0xe4a8d933u; z5 = (double)(((unsigned)(m0 || (unsigned)((short)(unsigned)f0 > (signed char)7u))) & 255u); } if ((*q0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)0x59d8aeb0u > (signed char)(unsigned)(9u < 0xffffffffu)), (i2 ^ r0.y), ((unsigned)l0 ^ (0xc1c62380u & 1u))); }
                    break; (void)((i0 >> (r0.y & 31u)));
                    *q0 = (unsigned)((unsigned)((int)a0[i0 & 3u] >= (int)6u) || -(unsigned)((short)g0 > (signed char)(unsigned)d0));
                    w0 ^= (unsigned long long)p0 << (-(unsigned)(((g1 ^ u2) % (r0.y | 1u)) || (unsigned)(x0 >> 70)) & 63u);
                }
                m0 ^= (unsigned)(garr[u2 & 7u] < a0[i0 & 3u]);
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)h0 && 0xffffffffu), (unsigned)x0, ((unsigned)(0xffffffffu && r0.y) - *q0)); }
            }
        } while (i1++ < 3u && -(unsigned)(g1 < (unsigned)b0));
        q0 = &garr[(u2 + (unsigned)(p1 && (*mp << (0xb8d03032u & 31u)))) & 7u];
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)(short)(unsigned)((unsigned)c1 || (unsigned)((int)(unsigned)l0 < (int)4u));
    l0 = (long)((unsigned long)l0 + ((unsigned)((int)(unsigned)(u3 && 0x80000000u) >= (int)*q0) - (unsigned)l0));
    { unsigned t6; double z6; if ((((unsigned)(x0 >> 70) - u1)) & 1u) { t6 = (unsigned)(u0 && (unsigned)((unsigned)h0 && garr[u2 & 7u])); z6 = (double)(((unsigned)b0) & 255u); } if ((((unsigned)(x0 >> 70) - u1)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
        { unsigned t7; double z7; if ((((unsigned)((int)0xf2ec34feu >= (int)u2) * v0)) & 1u) { t7 = (0x7fffffffu | (unsigned)l0); z7 = (double)(((unsigned)x0) & 255u); } if ((((unsigned)((int)0xf2ec34feu >= (int)u2) * v0)) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
            if (1u) goto L4;
            u0 += ((unsigned)f0 ? garr[u2 & 7u] : garr[i1 & 7u]);
            u2 = u2 * 0x9e3779b1u + ((unsigned)c0 / (-(3u << ((u3 | (unsigned)b0) & 31u)) | 1u));
            i2 = (*mp + ((unsigned)((int)(unsigned)(signed char)(0xbc47e938u & 5u) >= (int)0xa7ffad3cu) & (unsigned)w0)) & 15u;
            c0 = (unsigned char)p1;
            x0 = x0 * 0x100000001b3ull + (unsigned)c1;
        }
        *q0 += (unsigned)((unsigned)!(unsigned)((int)0x80000000u < (int)0x80000000u) || (unsigned)b0);
        garr[(unsigned)(signed char)(0x10000u << ((unsigned)(w0 >> 29) & 31u)) & 7u] = (unsigned)(unsigned char)(m0 << (g1 & 31u));
        do { if (--fuel == 0u) goto done;
            if ((garr[u2 & 7u] << ((unsigned)(signed char)((unsigned)b0 & 0xffffffffu) & 31u))) continue;
            s1 = (int)((unsigned)s1 + (unsigned)((short)m0 > (signed char)(g1 & garr[u2 & 7u])));
            u3 = u3 * 0x9e3779b1u + ((unsigned)((int)0x80000000u < (int)(unsigned)c1) * (unsigned)(signed char)(unsigned)((unsigned)s1 || i2));
            u2 = u2 * 0x9e3779b1u + ((unsigned)w0 & (unsigned)((short)(unsigned)l0 > (signed char)*mp));
            x0 = x0 * 0x100000001b3ull + (unsigned)(short)(p2 & m0);
            break; (void)(0x7fffffffu);
        } while (i0++ < 7u && g0);
        r0.x = (~((u1 + p2) ^ 0x89a26a68u) >> ((unsigned)(r0.y || (unsigned)h1) & 31u));
        u1 += (9u >> ((unsigned)(w0 >> 29) & 31u));
    }
    b0 = ((unsigned)(x0 >> 70) | (unsigned)d0) != 0u;
    u0 = (p0 * r0.y);
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)d0, (unsigned)((int)(unsigned)h0 >= (int)(unsigned)((unsigned)f0 && g1)), (0x10000u / (u2 | 1u))); }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        garr[garr[u2 & 7u] & 7u] = (r0.x % (p2 | 1u));
        e0 = e0 * 0.5L + (long double)(g1 & 1023u);
        if (fuel < 8u) return (9u & (*q0 >> (u1 & 31u)));
    }
    goto L2;
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)v0 >= (int)(5u % (g0 | 1u))), (((unsigned)w0 | i2) | 0x80000000u), (unsigned)(signed char)(unsigned)((unsigned)c0 == i2)); }
    if (-(unsigned)((unsigned)(m0 < 0xffffffffu) == i2)) {
        do { if (--fuel == 0u) goto done;
            if ((unsigned)b0) {
                m0 ^= (unsigned)((int)(9u - 0xffffffffu) < (int)u2);
                a0[r0.x & 3u] = (unsigned)((short)(unsigned)((int)(unsigned)!(unsigned)(6u || i2) < (int)(unsigned)h0) > (signed char)(unsigned)w0);
                if (budget != 0u) { budget -= 1u; u3 = fn1(1u, (unsigned)x0, (i1 + v0)); }
                c0 = (unsigned char)(unsigned)((0u * m0) < v0);
            } else {
                if ((unsigned)b0) goto L3;
            }
            while (i1++ < 5u && (unsigned)s1) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)w0 >= (int)((0x8366c1feu % (3u | 1u)) & (unsigned)((int)u2 >= (int)(unsigned)x0))) & 255u);
                continue; (void)(((unsigned)((short)(unsigned)s0 > (signed char)u0) ^ p1));
                if ((0x80000000u ^ i1)) break;
                u1 ^= (p0 >> (0x7fffffffu & 31u));
                x0 = x0 * 0x100000001b3ull + (unsigned)(0xd76e787bu == (((unsigned)s0 - ((unsigned)f0 >> (p0 & 31u))) >> (2u & 31u)));
                if ((unsigned)h1) break;
            }
        } while (i0++ < 7u && (unsigned)((short)0x80000000u > (signed char)-(p2 - m0)));
        goto done;
    }
    d0 = d0 * 0.5 + (double)(p0 & 1023u);
    if ((*q0 & u3)) goto L2;
    f0 = f0 * 0.5f + (float)(u0 & 255u);
    if (((unsigned)!(unsigned)(0x68f7501du < a0[u1 & 3u]) << (0xffffffffu & 31u))) {
        if (((unsigned)w0 - p2)) goto L2;
        { unsigned t8; double z8; if ((((unsigned)l0 << ((2u / ((unsigned)w0 | 1u)) & 31u))) & 1u) { t8 = fuel; z8 = (double)(((i2 % ((unsigned)(signed char)((unsigned)h0 << (fuel & 31u)) | 1u))) & 255u); } if ((((unsigned)l0 << ((2u / ((unsigned)w0 | 1u)) & 31u))) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)l0 / (u3 | 1u)));
                x0 = x0 * 0x100000001b3ull + ((unsigned)x0 ? *mp : (unsigned)s0);
            }
            { unsigned t9; double z9; if (((*q0 ? (unsigned)(x0 >> 70) : 0x11750cb7u)) & 1u) { t9 = (m0 | garr[i1 & 7u]); z9 = (double)(((0xffffffffu ^ (unsigned)s0)) & 255u); } if (((*q0 ? (unsigned)(x0 >> 70) : 0x11750cb7u)) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (((0xffffffffu << (i1 & 31u)) ^ (unsigned)h0) >> (fuel & 31u)));
                    break; (void)(((unsigned)s0 / (u1 | 1u)));
                    m0 ^= (unsigned)(unsigned char)(unsigned)((int)(unsigned)((unsigned)c1 == garr[u2 & 7u]) >= (int)((unsigned)((int)0x1ac4bbf4u < (int)(unsigned)h0) % ((unsigned)h0 | 1u)));
                    m0 ^= ((unsigned)((int)(unsigned)e0 < (int)0x415b9955u) ^ 0x80000000u);
                    if ((unsigned)(unsigned char)((unsigned)(x0 >> 70) * (unsigned)((short)(unsigned)c1 > (signed char)r0.y))) {
                        b0 = (0x7fffffffu ^ (unsigned)s1) != 0u;
                        r0.x = (u2 / (*mp | 1u));
                    }
                    garr[0xffffffffu & 7u] = (i1 | (unsigned)d0);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1(p2, (p0 * (unsigned)(r0.x < r0.y)), (unsigned)((unsigned)(signed char)(unsigned)(garr[i1 & 7u] == 0x71186a30u) < u3)); }
                goto L3;
                { unsigned t10; double z10; if (((unsigned)((int)((unsigned)d0 - u0) < (int)(unsigned)b0)) & 1u) { t10 = ((unsigned)(r0.y == i1) * (unsigned)c0); z10 = (double)((((fuel / (0xffffffffu | 1u)) % (0x10000u | 1u))) & 255u); } if (((unsigned)((int)((unsigned)d0 - u0) < (int)(unsigned)b0)) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                    if ((unsigned)(short)(p1 / ((p1 >> ((unsigned)l0 & 31u)) | 1u))) goto L1;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)f0, 6u, (unsigned)((0x10000u % (u0 | 1u)) || 8u)); }
                    if (budget != 0u) { budget -= 1u; u2 = fn0((u3 ^ (unsigned)s0), (0x146c3784u * u1), (u3 | (unsigned)l0)); }
                    if (*q0) goto done;
                    *q0 += (unsigned)(a0[i0 & 3u] && g0);
                    u0 = u0 * 0x9e3779b1u + (unsigned)(((unsigned)w0 >> (a0[i0 & 3u] & 31u)) || (0x3e327773u ? (unsigned)f0 : u1));
                }
                h0 = (short)0x10000u;
                q0 = &garr[(unsigned)d0 & 7u];
            }
            g0 = (unsigned)((int)*q0 < (int)(unsigned)h1);
            { unsigned t11; double z11; if (((r0.x + (unsigned)b0)) & 1u) { t11 = ((p0 % (v0 | 1u)) / ((unsigned)w0 | 1u)); z11 = (double)(((unsigned)((int)0x80000000u >= (int)0x7fffffffu)) & 255u); } if (((r0.x + (unsigned)b0)) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
                if ((unsigned)(signed char)(g0 >> (g1 & 31u))) goto L1;
                while (i0++ < 3u && (unsigned)((unsigned)c1 == 0x7fffffffu)) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)~(unsigned)((int)u2 < (int)a0[i0 & 3u]) >= (int)(unsigned)b0)) {
                        if ((0x27c961f0u >> (1u & 31u))) break;
                    }
                    x0 = x0 * 0x100000001b3ull + (u0 - 0x10000u);
                    q0 = &garr[((unsigned)(a0[i0 & 3u] && 1u) % (u2 | 1u)) & 7u];
                    if ((unsigned)(unsigned char)(unsigned)(v0 == 2u)) goto L3;
                }
            }
            d0 = d0 * 0.5 + (double)((*mp & (unsigned)(a0[u1 & 3u] < p0)) & 1023u);
            if (u3 == 7u) return 4u;
        }
        switch (((unsigned)((unsigned)(w0 >> 29) || (unsigned)h1) ^ g1) & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn1(0x10000u, (unsigned)w0, v0); }
            u3 = u3 * 0x9e3779b1u + (unsigned)(short)((unsigned)(w0 >> 29) - ~((unsigned)e0 + (unsigned)f0));
        }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)w0) {
                if ((unsigned)((int)p0 >= (int)((unsigned)d0 | (unsigned)e0))) break;
            } else {
                v0 = (unsigned)((short)(unsigned)((u3 & 0x2faae224u) || (fuel & a0[u1 & 3u])) > (signed char)(unsigned)s1);
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)b0 & (unsigned)((unsigned)(w0 >> 29) < (unsigned)c1)), (p1 - i1), (*q0 & i2)); }
            }
            if (i1) break;
            w0 = w0 * 6364136223846793005ull + (9u | (unsigned)((1u + 8u) || ~(unsigned)((unsigned)c1 && g1)));
            u0 += (unsigned)(garr[i1 & 7u] || (p0 * u2));
            { unsigned t12; double z12; if (((unsigned)(0x596e4bc0u == 0x80000000u)) & 1u) { t12 = p2; z12 = (double)((((i1 / (0x10000u | 1u)) & *mp)) & 255u); } if (((unsigned)(0x596e4bc0u == 0x80000000u)) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
                g0 = 0x80000000u;
                u0 = u0 * 0x9e3779b1u + (unsigned)(unsigned char)(*q0 << (-(0xa60ca323u % ((unsigned)s1 | 1u)) & 31u));
                r0.y ^= -((unsigned)h0 / ((unsigned)s0 | 1u));
            }
            { unsigned t13; double z13; if ((garr[i1 & 7u]) & 1u) { t13 = (a0[i0 & 3u] << ((unsigned)s1 & 31u)); z13 = (double)(((unsigned)c1) & 255u); } if ((garr[i1 & 7u]) & 1u) { u3 += t13; d0 = d0 * 0.5 + z13; }
                if (fuel < 8u) return (unsigned)((int)u2 < (int)(unsigned)((int)(unsigned)((unsigned)c0 == r0.y) >= (int)4u));
                g0 = 0x3715b5c5u;
                if ((unsigned)(unsigned char)((fuel / ((unsigned)h1 | 1u)) ^ 2u)) {
                    c1 = (signed char)((unsigned)(a0[i0 & 3u] < (unsigned)w0) | (unsigned)((unsigned)d0 && p0));
                }
            }
        } while (i0++ < 7u && (unsigned)((int)0x10000u >= (int)0x10000u));
    } else {
        *q0 = (unsigned)(unsigned char)((unsigned)h0 / (*mp | 1u));
        goto L1;
    }
    do { if (--fuel == 0u) goto done;
        if ((p0 >> (0x7fffffffu & 31u))) break;
        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(unsigned char)(unsigned)(garr[i1 & 7u] == 0x7fffffffu) + g1), (a0[u1 & 3u] / (7u | 1u)), 0x80000000u); }
        a0[(unsigned)c1 & 3u] = r0.y;
        break; (void)((2u ? 0x10000u : 0x3d6f18dbu));
    } while (i0++ < 3u && (unsigned)((short)0x10000u > (signed char)0x7fffffffu));
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)c0 >> ((unsigned)(i1 && (unsigned)h1) & 31u)), (u3 | a0[i0 & 3u]), (unsigned)((unsigned)(w0 >> 29) && 0x77901299u)); }
    while (i0++ < 2u && (unsigned)b0) { if (--fuel == 0u) goto done;
        if ((unsigned)(0u == u0)) break;
        switch ((p2 + (r0.y / (0xe54de6f2u | 1u))) & 7u) {
            s0 = (int)(8u + (6u / (5u | 1u)));
            { unsigned t14; double z14; if (((unsigned)e0) & 1u) { t14 = 0x10000u; z14 = (double)((u3) & 255u); } if (((unsigned)e0) & 1u) { u1 += t14; d0 = d0 * 0.5 + z14; }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)d0, (0x4664ecc9u | (unsigned)c0), (unsigned)((short)(g0 % (p1 | 1u)) > (signed char)4u)); }
                if (budget != 0u) { budget -= 1u; u0 = fn0(u0, (0x80000000u ? 0xc733cdd4u : (unsigned)s1), a0[u1 & 3u]); }
                g1 += ((unsigned)c0 ? ~(g1 / (p2 | 1u)) : i1);
                h1 = (unsigned short)(h1 + (unsigned)((7u % (0x7fffffffu | 1u)) < (0xc67fe98du << (a0[i0 & 3u] & 31u))));
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 6u: ;
                    if (0xc51de5a7u) {
                        u0 = u0 * 0x9e3779b1u + ((unsigned)(((unsigned)s1 << ((0x8585f9e2u - p2) & 31u)) || i1) / (8u | 1u));
                        while (i2++ < 2u && (unsigned)f0) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u3 = fn1((0x7fffffffu & (0x80000000u << (garr[i1 & 7u] & 31u))), 0x7fffffffu, (unsigned)(unsigned char)(unsigned)((unsigned)(g1 && 0x1f4473b3u) && 0x8fa39a5u)); }
                            a0[(u2 >> (0xebf73884u & 31u)) & 3u] = (unsigned)((short)(unsigned)((short)(unsigned)c0 > (signed char)2u) > (signed char)(unsigned)(0x3fced0acu < (unsigned)b0));
                            e0 = e0 * 0.5L + (long double)((unsigned)((int)~(*q0 / (*q0 | 1u)) >= (int)g0) & 1023u);
                            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)garr[u2 & 7u] > (signed char)((unsigned)w0 & (unsigned)(x0 >> 70))), (unsigned)(u3 && r0.x), ((unsigned)w0 >> ((unsigned)(w0 >> 29) & 31u))); }
                            case 1u: ;
                            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(a0[u1 & 3u] < r0.x), 0x7fffffffu, u2); }
                        }
                        g0 = (unsigned)((unsigned)d0 || 0x80000000u);
                        i2 = (i1 ^ (unsigned)((int)0x103a84fau < (int)u2)) & 15u;
                        v0 = (unsigned)((int)(p1 - u1) < (int)(unsigned)(short)(2u * (unsigned)e0));
                    } else {
                        { unsigned t15; double z15; if ((0u) & 1u) { t15 = (unsigned)((unsigned)h0 < 2u); z15 = (double)((((unsigned)b0 & (i2 % (u0 | 1u)))) & 255u); } if ((0u) & 1u) { u2 += t15; d0 = d0 * 0.5 + z15; }
                            *q0 = ((unsigned)(x0 >> 70) ? (unsigned)h0 : (unsigned)x0);
                            d0 = d0 * 0.5 + (double)(((unsigned)(i2 && (unsigned)(signed char)(unsigned)((short)7u > (signed char)6u)) + (unsigned)c1) & 1023u);
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn1(u1, (garr[u2 & 7u] ^ (*mp - 0x80000000u)), r0.y); }
                        if ((unsigned)((short)garr[u2 & 7u] > (signed char)3u)) continue;
                    }
                    case 7u: ;
                }
                a0[i0 & 3u] = *mp;
            }
            u0 += (((unsigned)((unsigned)s0 == 0xbb25445u) - (unsigned)x0) * 6u);
            if (~(unsigned)((unsigned)x0 == 9u)) {
                default: ;
                continue; (void)((5u >> (0x10000u & 31u)));
                case 3u: ;
            }
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + ((unsigned)l0 / ((4u | (unsigned)l0) | 1u));
                u1 ^= ((0x10000u ? (unsigned)d0 : (unsigned)((short)i1 > (signed char)0x80000000u)) / (0xb59cbf6eu | 1u));
                r0.x = (((unsigned)l0 ^ (unsigned)b0) & *mp);
                break;
            }
            v0 = (unsigned)((unsigned)((0x599d2ffu >> (u1 & 31u)) < (unsigned)c0) || (unsigned)(i2 == (unsigned)b0));
        }
        if (((unsigned)x0 + (0x7fffffffu * *q0))) goto L3;
        if (v0) break;
    }
    for (;;) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)s1) break;
            if (budget != 0u) { budget -= 1u; u0 = fn0(6u, (unsigned)(garr[u2 & 7u] && (unsigned)s1), ((unsigned)(x0 >> 70) * v0)); }
            m0 ^= ((unsigned)x0 | (p1 & ((p1 + 0xffffffffu) << ((unsigned)h1 & 31u))));
            break; (void)(((unsigned)(m0 && 0xe4782ab1u) << (u2 & 31u)));
            h1 = (unsigned short)(h1 + (0x5e6b4f55u << ((unsigned)h1 & 31u)));
        }
    }
    if ((unsigned)h0) goto done;
    g0 = (unsigned)(0x7fffffffu == (unsigned)((int)(unsigned)(signed char)((1u - 1u) % ((unsigned)e0 | 1u)) < (int)7u));
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)e0, ((unsigned)b0 + (unsigned)(garr[u2 & 7u] == 0x15e88952u)), (unsigned)(w0 >> 29)); }
    u3 += (unsigned)h1;
    s0 = (int)(unsigned)((unsigned)((int)g0 >= (int)v0) || (unsigned)((unsigned)!(unsigned)(0x80000000u && r0.x) && r0.y));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (((unsigned)l0 ^ u3)) goto L2;
    c1 = (signed char)((a0[i0 & 3u] >> (p1 & 31u)) >> ((unsigned)(u0 && 8u) & 31u));
    if (((unsigned)w0 >> ((u3 - *mp) & 31u))) goto L1;
    if ((unsigned)w0) goto L2;
    do { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        switch ((p1 - (m0 - u0)) & 7u) {
            if (-((0x10a81319u | (unsigned)f0) / (r0.x | 1u))) break;
            u3 = u3 * 0x9e3779b1u + ((0u << (0x4cfd6dc3u & 31u)) ^ u3);
        }
        g1 += (unsigned)((int)(a0[i0 & 3u] << ((unsigned)((unsigned)c0 && 0x11df4710u) & 31u)) >= (int)(unsigned)(unsigned char)(unsigned)((int)v0 >= (int)(unsigned)e0));
        if (fuel < 8u) return (garr[i1 & 7u] & 0x80000000u);
    } while (i0++ < 2u && 0x10000u);
    x0 = x0 * 0x100000001b3ull + m0;
    c0 = (unsigned char)((unsigned)((int)(unsigned)d0 >= (int)(0x715f9428u % (u0 | 1u))) & (unsigned)((short)u2 > (signed char)r0.y));
    if ((unsigned)s1) goto L4;
    d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)e0 / (u2 | 1u)) == i1) & 1023u);
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
    }
    r0.x = (0xa178c7u >> (7u & 31u));
    c1 = (signed char)((unsigned)f0 ^ ((0xc3ba0f21u % (u2 | 1u)) / (((unsigned)s0 * g0) | 1u)));
    g1 += ((unsigned)((unsigned)w0 == *mp) + 0x10000u);
    c1 = (signed char)(*mp % ((unsigned)s1 | 1u));
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (~(*mp % (0x4e460eabu | 1u)) << ((unsigned)((unsigned)b0 == (unsigned)(u1 || (unsigned)w0)) & 31u));
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(0x6945aa41u == a0[u1 & 3u])) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn2((-((unsigned)h0 - 0x10000u) + 0xa80a49d9u), 0xffffffffu, (unsigned)!(unsigned)(((unsigned)c1 / ((unsigned)c0 | 1u)) == p0)); }
                    m0 ^= (garr[i1 & 7u] / ((unsigned)!(unsigned)((int)(unsigned)f0 >= (int)v0) | 1u));
                    if ((unsigned)((unsigned)h0 && (unsigned)l0)) break;
                    switch ((*mp | (unsigned)h1) & 7u) {
                        c1 = (signed char)(((0xfc8f6ccbu * (i1 % (4u | 1u))) & (unsigned)x0) - p2);
                        *mp = (unsigned)(p0 && u3);
                        L2: if (--fuel == 0u) goto done;
                        a0[8u & 3u] = ((unsigned)f0 % (((unsigned)h1 * i1) | 1u));
                    }
                    w0 = w0 * 6364136223846793005ull + ((8u ^ a0[i0 & 3u]) * 3u);
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)*q0 > (signed char)(unsigned)((int)g1 < (int)5u)), (0x107a81eu | 0xdf39f6a5u), (unsigned)((int)0x7fffffffu < (int)u2)); }
            }
            h1 = (unsigned short)(h1 + (p1 % (((unsigned)!(0x80000000u & 0x80000000u) % ((unsigned)(w0 >> 29) | 1u)) | 1u)));
        }
    }
    q0 = &garr[(unsigned)(0x78cbbe21u && (unsigned)f0) & 7u];
    if (-(0x2c24450eu * (unsigned)((int)(unsigned)l0 < (int)0x2ce8c512u))) {
        h0 = (short)((a0[u1 & 3u] % ((unsigned)(0xf7714b82u < p0) | 1u)) << (-((unsigned)s1 >> (0x35327b8au & 31u)) & 31u));
        if ((0xf2ff8b84u | 0u)) {
            s1 = (int)((unsigned)s1 + ((u0 % (0xffffffffu | 1u)) ^ ((unsigned)(short)(i0 ^ 0x527a73fdu) - p1)));
            f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(a0[u1 & 3u] | (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0u)) & 255u);
            if ((0xffffffffu * 0x555db69eu)) goto done;
        } else {
            h1 = (unsigned short)(h1 + (unsigned)(p2 == (unsigned)s1));
        }
        while (i0++ < 2u && (g0 - (r0.x & (unsigned)h1))) { if (--fuel == 0u) goto done;
            b0 = -((unsigned)(u0 || (unsigned)((short)(unsigned)(0x7fffffffu == i1) > (signed char)r0.y)) % (0x80000000u | 1u)) != 0u;
        }
        e0 = e0 * 0.5L + (long double)((0x10000u / (0xd5a591f0u | 1u)) & 1023u);
        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((int)r0.y >= (int)g1) % (r0.x | 1u)), (*q0 & g1), (v0 ? 0x7b962749u : p2)); }
        v0 = (*mp * (r0.y ^ (unsigned)((int)0x7fffffffu >= (int)6u)));
    }
    goto L0;
    q0 = &garr[(unsigned)((unsigned)f0 && 0xbb6f1325u) & 7u];
    L3: if (--fuel == 0u) goto done;
    L4: if (--fuel == 0u) goto done;
    v0 = ((unsigned)h0 - ((unsigned)s1 ^ p0));
    if ((unsigned)s0) goto done;
    c0 = (unsigned char)(0x90af30bfu % ((unsigned)(garr[i1 & 7u] || (unsigned)((unsigned)(w0 >> 29) && 0x10000u)) | 1u));
    while (i0++ < 5u && (i2 * (unsigned)s0)) { if (--fuel == 0u) goto done;
        if ((p0 % (9u | 1u))) break;
        if (u3 == 7u) return (unsigned)(unsigned char)(u2 * (unsigned)(g1 || 0x80000000u));
        switch ((unsigned)(unsigned char)(unsigned)(v0 || (unsigned)(x0 >> 70)) & 7u) {
            g1 += a0[u1 & 3u];
            if ((unsigned)((unsigned)((short)i1 > (signed char)u3) == 0x80000000u)) break;
            case 3u: ;
            while (i1++ < 5u && (unsigned)(g1 && 0x6b79ea11u)) { if (--fuel == 0u) goto done;
                u2 += ((unsigned)((short)(i2 << ((unsigned)e0 & 31u)) > (signed char)(unsigned)(short)(fuel * a0[i0 & 3u])) << ((unsigned)b0 & 31u));
            }
            m0 ^= (unsigned)(short)((p0 / (5u | 1u)) | ((unsigned)h1 + (unsigned)h1));
            h0 = (short)a0[u1 & 3u];
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)(unsigned)((unsigned)((short)p0 > (signed char)m0) < 0x10000u), (unsigned)(signed char)(7u & 0x10000u), 0xe5f4b2d1u); }
    switch ((unsigned)!(unsigned)((int)(unsigned)d0 < (int)1u) & 7u) {
        r0.x = 0x7fffffffu;
        for (;;) { if (--fuel == 0u) goto done;
            while (i1++ < 3u && 9u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(unsigned)((unsigned)((short)u3 > (signed char)(0xffffffffu % (0x2eb6d5f9u | 1u))) || (1u + (unsigned)e0)) & 255u);
            }
            u1 = u1 * 0x9e3779b1u + (garr[i1 & 7u] << ((unsigned)(0x7fffffffu < ((unsigned)e0 + (unsigned)d0)) & 31u));
        }
        while (i0++ < 4u && 6u) { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)(unsigned char)((unsigned)b0 | (unsigned)w0) && 0u)) goto L3;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                while (i2++ < 5u && u0) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((i0 ? (unsigned)s0 : (unsigned)d0), 3u, p0); }
                    if ((unsigned)((int)(unsigned)h1 < (int)u0)) {
                        if (((0x10000u / (fuel | 1u)) >> (0x7fffffffu & 31u))) break;
                        L1: if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)(-((i2 + r0.x) ^ r0.y) & 1023u);
                        if (budget != 0u) { budget -= 1u; u3 = fn1((((unsigned)c0 - 1u) | p0), (unsigned)(signed char)(unsigned)(*mp == (unsigned)h0), (unsigned)b0); }
                        c1 = (signed char)(unsigned)((short)(p0 ^ (unsigned)((0xe0d926f3u + (unsigned)d0) && a0[u1 & 3u])) > (signed char)i1);
                        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)l0 * (unsigned)(short)(unsigned)(p2 < 0x2ec05dbeu)), (unsigned)(w0 >> 29), 0x735b2221u); }
                    } else {
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)*mp > (signed char)(unsigned)((short)0x7fffffffu > (signed char)g1)), (unsigned)c0, ((u2 / (i1 | 1u)) + *q0)); }
                        case 7u: ;
                        i0 = 0x8c2e846au & 15u;
                        L2: if (--fuel == 0u) goto done;
                    }
                    s1 = (int)((unsigned)s1 + (unsigned)e0);
                    g1 += ((unsigned)(signed char)(unsigned)((int)p2 >= (int)(unsigned)((short)a0[u1 & 3u] > (signed char)0x80000000u)) - (g1 >> (g0 & 31u)));
                    u1 = ((unsigned)(signed char)(u1 ^ u1) >> (garr[i1 & 7u] & 31u));
                    if ((0x555c8575u / (((unsigned)l0 << (r0.y & 31u)) | 1u))) goto L2;
                }
                if ((unsigned)((0x10000u | p1) == (unsigned)w0)) goto L3;
                if (budget != 0u) { budget -= 1u; u3 = fn2((-(unsigned)(0x80000000u && 8u) & 0x246237a8u), ~(unsigned)((int)0x4f04c457u < (int)0u), (garr[u2 & 7u] | (unsigned)((unsigned)c0 == fuel))); }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)s1, 0x885794ebu, (0x7fffffffu | u2)); }
            }
        }
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        L3: if (--fuel == 0u) goto done;
        if ((unsigned)(u1 == (i1 << ((unsigned)e0 & 31u)))) {
            if (m0) continue;
            if ((unsigned)c0) continue;
            u3 ^= ((unsigned)(unsigned char)(unsigned)((short)r0.x > (signed char)0x10000u) - (p0 % (p2 | 1u)));
            if (3u) break;
            c1 = (signed char)((v0 << (i2 & 31u)) + i0);
        } else {
            l0 = (long)((unsigned long)l0 + (unsigned)((0x7fffffffu * (unsigned)((unsigned)b0 || (i0 - 0x8112332bu))) < u0));
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (0x7fffffffu / (v0 | 1u)));
            x0 = x0 * 0x100000001b3ull + ((unsigned)h1 / ((unsigned)((int)(unsigned)s1 >= (int)5u) | 1u));
            g0 = 0xdc0dae33u;
            if (g0) goto L2;
        }
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            u2 ^= (0x10000u << ((unsigned)((int)((unsigned)c0 & (unsigned)(x0 >> 70)) < (int)(unsigned)l0) & 31u));
            if (p2) break;
            if ((0x56eac6c5u ^ g0)) break;
            e0 = e0 * 0.5L + (long double)((unsigned)((garr[u2 & 7u] ? 0x8e457faeu : (unsigned)b0) && u3) & 1023u);
            if ((u0 >> (0x7fffffffu & 31u))) goto L0;
        }
        if ((unsigned)e0) break;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (((i2 ^ (unsigned)l0) | (unsigned)h0) & 7u) {
            while (i1++ < 6u && (unsigned)((u2 % (*q0 | 1u)) || (unsigned)e0)) { if (--fuel == 0u) goto done;
                h0 = (short)(g0 | u1);
                case 6u: ;
                i2 = (unsigned)((short)garr[u2 & 7u] > (signed char)i2) & 15u;
                case 3u: ;
                if ((5u & (unsigned)h1)) break;
            }
            if (fuel < 8u) return (unsigned)((int)(unsigned)(x0 >> 70) >= (int)((unsigned)b0 + v0));
            if (fuel < 8u) return garr[i1 & 7u];
            g1 += (u0 & (*mp >> ((unsigned)c0 & 31u)));
            while (i1++ < 2u && (unsigned)((int)g0 >= (int)g0)) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    c1 = (signed char)(unsigned)((short)p0 > (signed char)u0);
                    case 4u: ;
                    do { if (--fuel == 0u) goto done;
                        { unsigned t0; double z0; if ((-(garr[u2 & 7u] * (unsigned)s0)) & 1u) { t0 = (g0 ^ (unsigned)d0); z0 = (double)(((unsigned)((int)u1 >= (int)a0[i0 & 3u])) & 255u); } if ((-(garr[u2 & 7u] * (unsigned)s0)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                            i2 = (unsigned)((short)0x7fffffffu > (signed char)u2) & 15u;
                            c0 = (unsigned char)i1;
                        }
                        if ((unsigned)(unsigned char)(unsigned)(u2 || 9u)) {
                            d0 = d0 * 0.5 + (double)((i2 % ((fuel / ((unsigned)f0 | 1u)) | 1u)) & 1023u);
                            garr[p1 & 7u] = (unsigned)h0;
                            default: ;
                        } else {
                            break;
                            L4: if (--fuel == 0u) goto done;
                        }
                        l0 = (long)((unsigned long)l0 + 0xf7d51896u);
                    } while (i0++ < 5u && (unsigned)(i0 < (unsigned)d0));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)u3 >= (int)p1), (unsigned)h0, (unsigned)((int)1u < (int)(unsigned)((int)i2 >= (int)(unsigned)c0))); }
                } while (i2++ < 3u && (9u / (i1 | 1u)));
            }
            if (budget != 0u) { budget -= 1u; u1 = fn3(((unsigned)s0 | (garr[u2 & 7u] ^ u3)), ((unsigned)h1 >> ((0x6e03a98u - p1) & 31u)), (unsigned)((short)1u > (signed char)(m0 | 0xd4429782u))); }
        }
        r0.y ^= u2;
        if (0x7fffffffu) continue;
        c1 = (signed char)(0x10000u >> ((u0 >> ((unsigned)s0 & 31u)) & 31u));
    }
    if (0xffffffffu) goto L2;
    if ((unsigned)l0) goto L1;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)l0 < (int)(unsigned)e0), ((r0.x + (unsigned)b0) % (a0[u1 & 3u] | 1u)), (unsigned)((int)u3 < (int)(unsigned)h0)); }
    s0 = (int)(unsigned)!((unsigned)s0 * (unsigned)(unsigned char)(unsigned)((int)((unsigned)c0 + (unsigned)(short)(v0 ^ (unsigned)h0)) >= (int)0x80000000u));
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 2u && (*q0 ^ a0[i0 & 3u])) { if (--fuel == 0u) goto done;
            while (i2++ < 2u && 0xffffffffu) { if (--fuel == 0u) goto done;
                *q0 += (unsigned)(((unsigned)x0 / (u1 | 1u)) == 0x7fffffffu);
                break; (void)((0x10a9b353u - (unsigned)b0));
                { unsigned t1; double z1; if (((unsigned)l0) & 1u) { t1 = (unsigned)((unsigned)(x0 >> 70) == m0); z1 = (double)((9u) & 255u); } if (((unsigned)l0) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(v0 == a0[u1 & 3u]), (unsigned)(0x862cda34u || (unsigned)f0), ((unsigned)((unsigned)e0 || (unsigned)h0) * 0x3f17c705u)); }
                    if ((unsigned)f0) break;
                    if (0xffffffffu) {
                        if ((unsigned)f0) break;
                        if ((a0[u1 & 3u] * (unsigned)f0)) goto L0;
                        c0 = (unsigned char)0u;
                        g0 = (fuel << ((unsigned)s0 & 31u));
                        *q0 += (unsigned)((short)0x10000u > (signed char)(unsigned)(w0 >> 29));
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn1(m0, (1u - fuel), (unsigned)(m0 || (unsigned)d0)); }
                    w0 ^= (unsigned long long)(unsigned)((int)garr[i1 & 7u] >= (int)garr[u2 & 7u]) << ((unsigned)b0 & 63u);
                    break; (void)(((unsigned)c0 + (unsigned)(w0 >> 29)));
                }
                if (budget != 0u) { budget -= 1u; u0 = fn2(((r0.x - (unsigned)(x0 >> 70)) & (unsigned)b0), ~(0x7fffffffu ^ (m0 << (u1 & 31u))), (0x7fffffffu >> (u0 & 31u))); }
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)w0, (unsigned)((int)(unsigned)b0 < (int)(unsigned)(unsigned char)(unsigned)((unsigned)(w0 >> 29) == a0[i0 & 3u])), m0); }
            }
            for (;;) { if (--fuel == 0u) goto done;
                continue; (void)(((unsigned)d0 << ((unsigned)b0 & 31u)));
                if (budget != 0u) { budget -= 1u; u1 = fn1(7u, (p2 ^ u2), (a0[u1 & 3u] + 0xffffffffu)); }
                for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(x0 >> 70), ((0x7fffffffu / (*mp | 1u)) % (0x7fffffffu | 1u)), (m0 << ((unsigned)(unsigned char)(unsigned)((unsigned)x0 && v0) & 31u))); }
                    switch ((p1 ? 8u : 0x10000u) & 7u) {
                        b0 = 0xbc0c81b7u != 0u;
                        d0 = d0 * 0.5 + (double)(u3 & 1023u);
                        u1 = u1 * 0x9e3779b1u + (unsigned)((int)(unsigned)h0 < (int)0xffffffffu);
                        if ((unsigned)(u1 < (unsigned)f0)) {
                            x0 = x0 * 0x100000001b3ull + ((unsigned)((int)(unsigned)l0 < (int)p2) & ((unsigned)(w0 >> 29) - (unsigned)(g1 && v0)));
                            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)(x0 >> 70)), (u1 ^ p1), (unsigned)((short)i2 > (signed char)0x7fffffffu)); }
                            garr[p2 & 7u] = 7u;
                            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)w0, garr[i1 & 7u], (unsigned)!((unsigned)s1 * 7u)); }
                        } else {
                            if ((unsigned)d0) continue;
                            break; (void)((unsigned)!((unsigned)c1 << ((unsigned)c1 & 31u)));
                            if (budget != 0u) { budget -= 1u; u2 = fn2((*q0 % ((unsigned)l0 | 1u)), ~(unsigned)((short)(u3 & a0[i0 & 3u]) > (signed char)0x7974ea8du), (unsigned)(x0 >> 70)); }
                        }
                        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(((unsigned)h1 - i0) && u0), (unsigned)((unsigned)(4u || (unsigned)b0) || *q0), garr[u2 & 7u]); }
                        case 3u: ;
                    }
                    if (((unsigned)d0 ^ p1)) continue;
                    c0 = (unsigned char)(~(unsigned)((int)i1 >= (int)fuel) / (u3 | 1u));
                    if (fuel) break;
                    w0 = w0 * 6364136223846793005ull + (unsigned)(g1 == (unsigned)c0);
                }
                if ((p0 & 0xdadeb349u)) break;
                break; (void)((unsigned)((0x80000000u & 0x7fffffffu) == u0));
                if ((unsigned)(x0 >> 70)) break;
            }
        }
        h0 = (short)(i1 - fuel);
    }
    h0 = (short)(*mp - p2);
    if ((unsigned)(-(v0 - g1) == (unsigned)x0)) {
        u2 = u2 * 0x9e3779b1u + (unsigned)(((unsigned)l0 * g0) == (u0 ^ p0));
    }
    if ((unsigned)((g1 ^ (unsigned)c1) || a0[i0 & 3u])) goto L2;
    if ((p2 ? u1 : (unsigned)c1)) {
        if (a0[i0 & 3u]) {
            if (*q0) goto L2;
            if (r0.y) {
                if (*mp) goto L3;
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)(u1 == ((unsigned)h0 & (unsigned)x0));
                    if (fuel < 8u) return u1;
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)!((unsigned)f0 / ((unsigned)(garr[i1 & 7u] && 0xaa9b5bb8u) | 1u))) break;
                        *q0 += (unsigned)((unsigned)(garr[i1 & 7u] == (unsigned)(signed char)(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)x0)) || ((unsigned)(w0 >> 29) - a0[u1 & 3u]));
                        if ((unsigned)(v0 && i2)) break;
                        *q0 += 0xe6c46e39u;
                        while (i2++ < 7u && ((unsigned)(garr[u2 & 7u] && 0u) - 0x80000000u)) { if (--fuel == 0u) goto done;
                            if (fuel < 8u) return (unsigned)(((unsigned)(0x82e405c7u || i2) >> ((4u % (2u | 1u)) & 31u)) == (unsigned)e0);
                            if ((unsigned)(u1 == (unsigned)(signed char)(unsigned)((int)m0 >= (int)u2))) break;
                            g0 = (u1 >> ((unsigned)((unsigned)((short)0xb34a41bcu > (signed char)u3) && r0.x) & 31u));
                            if (budget != 0u) { budget -= 1u; u0 = fn1((garr[u2 & 7u] * r0.y), (r0.x << ((unsigned)e0 & 31u)), ((0u | u1) | 0x85ef7efu)); }
                            g0 = r0.y;
                            if ((3u * (unsigned)(signed char)(unsigned)(0x7fffffffu || 0x7fffffffu))) continue;
                        }
                    }
                    d0 = d0 * 0.5 + (double)(~(garr[i1 & 7u] ^ -(u3 << (0x10000u & 31u))) & 1023u);
                    if ((unsigned)c1) break;
                    switch (garr[i1 & 7u] & 7u) {
                        if ((unsigned)!(unsigned)((unsigned)c0 == ((unsigned)(x0 >> 70) | (unsigned)x0))) break;
                    }
                }
                if ((unsigned)((int)(unsigned)((int)r0.x < (int)(unsigned)c0) >= (int)(unsigned)w0)) goto done;
            } else {
                if ((unsigned)(*q0 || (unsigned)(signed char)(*mp & r0.x))) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((int)3u < (int)(unsigned)b0), (0x5dd0d62u | garr[u2 & 7u]), ~(0x127014b7u % (0x21fa8b58u | 1u))); }
            }
            if (((r0.x / (p0 | 1u)) + (unsigned)h0)) goto L3;
            switch ((m0 % ((unsigned)((short)garr[u2 & 7u] > (signed char)v0) | 1u)) & 7u) {
                case 1u: ;
                if (((unsigned)((int)(unsigned)c1 < (int)(unsigned)h0) - garr[u2 & 7u])) {
                    u1 = u1 * 0x9e3779b1u + (unsigned)x0;
                    if (~(unsigned)(u1 || u0)) {
                        if ((unsigned)(0x7fffffffu < 0x7fffffffu)) break;
                        w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(unsigned)(3u && 0xffffffffu);
                        u3 += (*mp ? 0x80000000u : (garr[i1 & 7u] >> (g1 & 31u)));
                        goto L3;
                    }
                }
                { unsigned t2; double z2; if ((((unsigned)e0 << (0xe67a8a91u & 31u))) & 1u) { t2 = (unsigned)((int)(unsigned)(a0[i0 & 3u] || (unsigned)(w0 >> 29)) < (int)p1); z2 = (double)((((0x80000000u - 8u) + (unsigned)s1)) & 255u); } if ((((unsigned)e0 << (0xe67a8a91u & 31u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    { unsigned t3; double z3; if (((unsigned)(3u == (unsigned)((short)(unsigned)f0 > (signed char)(unsigned)e0))) & 1u) { t3 = 7u; z3 = (double)((0x336e1d3fu) & 255u); } if (((unsigned)(3u == (unsigned)((short)(unsigned)f0 > (signed char)(unsigned)e0))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                        c1 = (signed char)3u;
                        if ((garr[i1 & 7u] >> (~(unsigned)((unsigned)c1 < 0xed94af72u) & 31u))) {
                            i1 = (unsigned)((int)(unsigned)(garr[i1 & 7u] == (unsigned)((unsigned)w0 == (unsigned)s0)) < (int)(unsigned)((short)(unsigned)c0 > (signed char)5u)) & 15u;
                            if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)c1 ^ (unsigned)(unsigned char)(u1 + 0x96d02471u)), ~((unsigned)((int)i0 < (int)7u) * *q0), (unsigned)((short)0u > (signed char)(unsigned)((int)0x634ae283u < (int)4u))); }
                            h0 = (short)0x7fffffffu;
                            h0 = (short)(unsigned)(((unsigned)f0 + (unsigned)c0) == ((unsigned)((int)(unsigned)s1 >= (int)0x7fffffffu) << (v0 & 31u)));
                            case 4u: ;
                            x0 = x0 * 0x100000001b3ull + (u0 + (unsigned)s1);
                        } else {
                            if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((short)(unsigned)(0x1ff283eeu < (unsigned)w0) > (signed char)m0), 0x80000000u, (9u + i2)); }
                        }
                        case 0u: ;
                        default: ;
                        if (0x7fffffffu) {
                            *q0 = (u1 / (7u | 1u));
                        }
                        l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)((unsigned)l0 == (unsigned)((int)(unsigned)(short)((unsigned)w0 % (u2 | 1u)) >= (int)i0)));
                    }
                    g0 = (i0 * ((unsigned)h0 >> (p0 & 31u)));
                    case 6u: ;
                }
            }
        } else {
            v0 = ((0x5f5f4c18u >> (garr[i1 & 7u] & 31u)) + (u3 - (unsigned)h0));
            switch (((unsigned)(x0 >> 70) ? (unsigned)(w0 >> 29) : (unsigned)d0) & 7u) {
                i0 = g0 & 15u;
                if (((v0 / ((unsigned)c0 | 1u)) - 0x80000000u)) {
                    if (fuel < 8u) return 0xcf978d8bu;
                    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (((unsigned)c0 * i2)) goto L1;
                        if ((unsigned)(*mp || (u0 / (0xffffffffu | 1u)))) continue;
                        b0 = i2 != 0u;
                        r0.y ^= (unsigned)(g1 && 7u);
                        e0 = e0 * 0.5L + (long double)((0x80000000u % (a0[u1 & 3u] | 1u)) & 1023u);
                        h0 = (short)(7u ? a0[u1 & 3u] : 0x10000u);
                    }
                    if ((unsigned)(0xf741f5b0u == (unsigned)((int)*q0 >= (int)(unsigned)x0))) {
                        r0.y ^= (unsigned)(unsigned char)(4u % ((g1 & (p1 & (i0 | (unsigned)w0))) | 1u));
                        e0 = e0 * 0.5L + (long double)((unsigned)((int)((unsigned)b0 + 6u) >= (int)0xd0e254b6u) & 1023u);
                    }
                    break; (void)((unsigned)(i0 && p1));
                    if (((i1 >> (i2 & 31u)) & (unsigned)(x0 >> 70))) {
                        u1 ^= -(unsigned)((int)(unsigned)((int)(m0 % (*q0 | 1u)) < (int)p0) < (int)v0);
                        g1 += (unsigned)(0x80000000u < ((p1 << (0x80000000u & 31u)) ^ 0u));
                        if (budget != 0u) { budget -= 1u; u1 = fn1(~(unsigned)(g0 == 0x80000000u), (unsigned)s0, 9u); }
                        g1 += (unsigned)(short)((unsigned)h0 - (unsigned)!(unsigned)(u0 < 6u));
                        do { if (--fuel == 0u) goto done;
                            case 4u: ;
                        } while (i0++ < 5u && (unsigned)((int)i0 < (int)(unsigned)s1));
                        case 3u: ;
                    } else {
                        if (budget != 0u) { budget -= 1u; u3 = fn1((i0 + u1), (a0[i0 & 3u] << ((unsigned)(r0.x < (unsigned)w0) & 31u)), (unsigned)(u2 == (unsigned)((int)(unsigned)c1 >= (int)i1))); }
                        q0 = &garr[((g1 & 0x7fffffffu) >> (((unsigned)d0 / (0xffffffffu | 1u)) & 31u)) & 7u];
                        u2 += ((unsigned)x0 / (0xb04a0d49u | 1u));
                        goto L1;
                    }
                } else {
                    *q0 += (((unsigned)(0x10000u || g0) & (unsigned)h1) + (0x7fffffffu / (0xffffffffu | 1u)));
                    case 7u: ;
                    u3 ^= (unsigned)(0x10000u == ((unsigned)(x0 >> 70) + a0[i0 & 3u]));
                    s0 = (int)0x80000000u;
                }
            }
            while (i0++ < 2u && u0) { if (--fuel == 0u) goto done;
                if ((i1 << (0xffffffffu & 31u))) break;
                if (fuel < 8u) return (unsigned)((short)(0x5e5c8b50u & 0x2ff62810u) > (signed char)(2u + r0.y));
                if ((unsigned)((unsigned)(short)(i0 + (unsigned)c0) || a0[i0 & 3u])) break;
                while (i1++ < 7u && (unsigned)((unsigned)c0 < 0x7f56ba20u)) { if (--fuel == 0u) goto done;
                    v0 = ((unsigned)((unsigned)h0 < garr[u2 & 7u]) << ((unsigned)e0 & 31u));
                    if (((unsigned)((short)a0[i0 & 3u] > (signed char)0xb279bf40u) ^ 2u)) continue;
                    if ((unsigned)((short)garr[u2 & 7u] > (signed char)0x1a1ad1d6u)) break;
                    *q0 = (unsigned)((int)(unsigned)(w0 >> 29) < (int)p0);
                    u1 += (unsigned)h1;
                }
                if (fuel < 8u) return (unsigned)b0;
            }
        }
        goto L4;
        { unsigned t4; double z4; if (((unsigned)((int)i0 >= (int)i0)) & 1u) { t4 = ((unsigned)b0 | (unsigned)d0); z4 = (double)(((unsigned)(4u || i0)) & 255u); } if (((unsigned)((int)i0 >= (int)i0)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            for (;;) { if (--fuel == 0u) goto done;
                *mp = ((unsigned)(unsigned char)((unsigned)c0 + fuel) + (unsigned)!(8u + (a0[u1 & 3u] - (unsigned)w0)));
                u2 ^= ((unsigned)((unsigned)(x0 >> 70) && (unsigned)c1) & (unsigned)d0);
                r0.x = ((unsigned)f0 * 0x80000000u);
                i0 = (unsigned)(0x80000000u == ((unsigned)f0 + (fuel % ((unsigned)(x0 >> 70) | 1u)))) & 15u;
                break; (void)(((unsigned)(garr[i1 & 7u] == *mp) + 0x80000000u));
            }
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)!((unsigned)(m0 || (unsigned)l0) / (*q0 | 1u))) break;
            c1 = (signed char)0xffffffffu;
            while ((a0[i0 & 3u] << ((unsigned)(*mp || (unsigned)w0) & 31u))) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    while (i0++ < 6u && (i1 / (r0.y | 1u))) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn2((i0 / (u2 | 1u)), (unsigned)((short)0x9ff9a9eeu > (signed char)fuel), (unsigned)(unsigned char)(a0[i0 & 3u] ^ (unsigned)e0)); }
                        if (((r0.y * (unsigned)(x0 >> 70)) | i1)) break;
                        s1 = (int)((unsigned)s1 + (unsigned)((((unsigned)(w0 >> 29) / (3u | 1u)) << ((r0.x + (unsigned)c0) & 31u)) && 0x10000u));
                        if (((unsigned)c0 % ((unsigned)s1 | 1u))) break;
                        l0 = (long)((unsigned long)l0 + (((unsigned)x0 << (p1 & 31u)) << (2u & 31u)));
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)(short)(2u << (0x423e2a26u & 31u)), (unsigned)(0x10000u && (unsigned)f0), ((unsigned)(0u && (unsigned)h0) ^ (unsigned)f0)); }
                    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (u3 == 7u) return p2;
                        w0 ^= (unsigned long long)u0 << ((unsigned)(8u == i1) & 63u);
                        w0 = w0 * 6364136223846793005ull + (((unsigned)h0 * 0xffffffffu) ^ i2);
                    }
                    d0 = d0 * 0.5 + (double)((unsigned)(x0 >> 70) & 1023u);
                    h1 = (unsigned short)(h1 + ((unsigned)s0 << ((unsigned)d0 & 31u)));
                }
                if ((unsigned)c0) break;
                if (fuel < 8u) return (r0.y % ((u3 - fuel) | 1u));
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(unsigned char)(unsigned)(5u == (0x10000u - 0xb2306bcfu)), ((unsigned)!(unsigned)((int)0u >= (int)(unsigned)e0) % (1u | 1u)), i1); }
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((int)(m0 + 0xffffffffu) >= (int)(unsigned)s1), ((garr[i1 & 7u] >> ((unsigned)d0 & 31u)) % (u0 | 1u)), (unsigned)((short)0x7fffffffu > (signed char)((unsigned)c1 >> (p0 & 31u)))); }
                d0 = d0 * 0.5 + (double)(((unsigned)c0 ^ (unsigned)c0) & 1023u);
            }
        }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((i1 - (unsigned)!((unsigned)c0 | (unsigned)e0))) continue;
            if ((unsigned)((int)(0u | 8u) >= (int)(unsigned)h1)) {
                while ((unsigned)e0) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (9u | 0x7fffffffu);
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (u3 == 7u) return 2u;
                        f0 = f0 * 0.5f + (float)(((unsigned)((int)i1 < (int)m0) / (*mp | 1u)) & 255u);
                        if (3u) goto L2;
                        break; (void)((unsigned)((int)p2 >= (int)(unsigned)((int)(unsigned)f0 < (int)0x5a98505cu)));
                        if (u3 == 7u) return ((i0 % (p2 | 1u)) % ((unsigned)((short)a0[u1 & 3u] > (signed char)(u3 % (7u | 1u))) | 1u));
                        f0 = f0 * 0.5f + (float)(((unsigned)(signed char)(0xffffffffu & a0[u1 & 3u]) + 0xd7b3d20eu) & 255u);
                    }
                    if (garr[u2 & 7u]) break;
                    if ((unsigned)!(unsigned)(0x80000000u < u1)) goto L2;
                }
                g0 = (unsigned)(fuel == g1);
                if ((0xffffffffu & (unsigned)((int)0x2761cd27u < (int)0x262dbb40u))) break;
                r0.y ^= ((unsigned)x0 - (unsigned)(x0 >> 70));
                { unsigned t5; double z5; if (((unsigned)((0x7fffffffu * v0) < (unsigned)e0)) & 1u) { t5 = (unsigned)((short)(unsigned)s1 > (signed char)(unsigned)f0); z5 = (double)((((unsigned)((unsigned)l0 == 0xfb061240u) >> (i1 & 31u))) & 255u); } if (((unsigned)((0x7fffffffu * v0) < (unsigned)e0)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    q0 = &garr[(unsigned)((int)(u3 << (0xd6eed0bcu & 31u)) >= (int)u0) & 7u];
                    s1 = (int)((unsigned)s1 + ((unsigned)(i1 == (unsigned)(0x6ca7b730u < (unsigned)e0)) / (p1 | 1u)));
                    if (budget != 0u) { budget -= 1u; u2 = fn3(0x10000u, ((g0 & a0[i0 & 3u]) - 6u), 2u); }
                    h0 = (short)((unsigned)(0u && (0x7fffffffu ^ (unsigned)(w0 >> 29))) - (r0.y ^ v0));
                    w0 ^= (unsigned long long)(unsigned)b0 << (((unsigned)((int)u3 < (int)a0[i0 & 3u]) ? a0[u1 & 3u] : (unsigned)c0) & 63u);
                    c0 = (unsigned char)-(0xffffffffu % ((unsigned)h0 | 1u));
                }
            }
            f0 = f0 * 0.5f + (float)((unsigned)((u3 + v0) == p1) & 255u);
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    *mp = (0u >> (0x10000u & 31u));
                    m0 ^= a0[i0 & 3u];
                }
                c0 = (unsigned char)((unsigned)((int)(unsigned)d0 >= (int)(unsigned)(signed char)((unsigned)s0 % ((unsigned)(x0 >> 70) | 1u))) % (a0[u1 & 3u] | 1u));
                { unsigned t6; double z6; if (((unsigned)((int)0x7fffffffu >= (int)(unsigned)(0x10000u && 0xffffffffu))) & 1u) { t6 = (unsigned)(signed char)(-((unsigned)d0 + u2) << (u0 & 31u)); z6 = (double)(((unsigned)((unsigned)s0 < u1)) & 255u); } if (((unsigned)((int)0x7fffffffu >= (int)(unsigned)(0x10000u && 0xffffffffu))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                    if ((unsigned)((int)(unsigned)(x0 >> 70) < (int)p2)) break;
                }
            }
            f0 = f0 * 0.5f + (float)((unsigned)(short)((unsigned)((int)2u < (int)(unsigned)h1) | (unsigned)e0) & 255u);
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)~((unsigned)w0 >> ((unsigned)((unsigned)(v0 && (unsigned)s1) < ((unsigned)h1 << (u1 & 31u))) & 31u));
            { unsigned t7; double z7; if (((unsigned)((int)(unsigned)(w0 >> 29) < (int)0xffffffffu)) & 1u) { t7 = u1; z7 = (double)((((unsigned)l0 * (unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)f0))) & 255u); } if (((unsigned)((int)(unsigned)(w0 >> 29) < (int)0xffffffffu)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                q0 = &garr[(unsigned)w0 & 7u];
                if ((unsigned)(r0.y == garr[i1 & 7u])) break;
                h0 = (short)(unsigned)f0;
            }
            if ((0xae3308dcu << ((r0.x << ((unsigned)w0 & 31u)) & 31u))) break;
            if (((unsigned)h1 * ~(unsigned)(6u < p1))) goto L1;
            if (budget != 0u) { budget -= 1u; u3 = fn0((0x10000u ^ a0[u1 & 3u]), (a0[u1 & 3u] ^ *mp), (*mp << (0x80000000u & 31u))); }
            switch (((unsigned)((int)0xffffffffu >= (int)1u) << ((unsigned)l0 & 31u)) & 7u) {
                case 7u: ;
                u3 ^= (unsigned)((0x957531fu - p1) && 0x77aaae9eu);
            }
        }
    } else {
        h1 = (unsigned short)(h1 + (fuel % ((0x80000000u - (unsigned)h0) | 1u)));
    }
    switch ((0x80000000u % (i2 | 1u)) & 7u) {
        h0 = (short)((unsigned)h0 * (unsigned)(r0.x < g1));
    }
    if (i1) goto L0;
    r0.x = (unsigned)(signed char)(i0 % (2u | 1u));
    if (0x7fffffffu) goto L2;
    if (budget != 0u) { budget -= 1u; u0 = fn1((g1 ^ (unsigned)((unsigned)e0 == i1)), (unsigned)(x0 >> 70), ((unsigned)c1 ^ (unsigned)((unsigned)l0 || (unsigned)s1))); }
    goto L0;
    while (i0++ < 3u && (unsigned)((0x10000u | (unsigned)e0) < (unsigned)w0)) { if (--fuel == 0u) goto done;
        c1 = (signed char)(u0 << (-(0x1ee41364u - r0.x) & 31u));
        break; (void)((unsigned)((int)(*q0 * u1) >= (int)(unsigned)c1));
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((2u % (0xffffffffu | 1u)) ^ (unsigned)c0) & 1023u);
            g1 += (unsigned)((int)(unsigned)(short)((unsigned)(unsigned char)(0x7eb8a441u & (unsigned)l0) << ((unsigned)s0 & 31u)) >= (int)(unsigned)(x0 >> 70));
            if ((unsigned)((short)r0.x > (signed char)(unsigned)h0)) goto L0;
            if ((unsigned)((int)0x7a021f2cu < (int)0x10000u)) {
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    c1 = (signed char)a0[u1 & 3u];
                    do { if (--fuel == 0u) goto done;
                        c1 = (signed char)(unsigned)((short)((unsigned)b0 / ((unsigned)e0 | 1u)) > (signed char)(unsigned)l0);
                        a0[0xffffffffu & 3u] = (((unsigned)(unsigned char)(unsigned)((unsigned)b0 || g1) << (0x10000u & 31u)) % (i2 | 1u));
                        s1 = (int)((unsigned)s1 + (((unsigned)h0 ^ 0xe8e8d007u) & (unsigned)(w0 >> 29)));
                        if ((3u | (unsigned)h1)) continue;
                        l0 = (long)((unsigned long)l0 + (unsigned)(short)(unsigned)(-(0x7fffffffu + 3u) < ((unsigned)((unsigned)b0 && (unsigned)d0) & 0xbf551c73u)));
                        break; (void)(0x38ff4684u);
                    } while (i0++ < 6u && r0.y);
                    f0 = f0 * 0.5f + (float)(((a0[u1 & 3u] % (u3 | 1u)) * ((unsigned)(0x29770b72u && v0) << (r0.y & 31u))) & 255u);
                }
                if ((unsigned)(x0 >> 70)) {
                    while (i2++ < 3u && 6u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((short)*mp > (signed char)(unsigned)((unsigned)h0 == i0))) break;
                    }
                    if ((unsigned)((short)a0[i0 & 3u] > (signed char)(0x38963d69u - *q0))) break;
                }
                switch ((unsigned)((unsigned)f0 || 4u) & 7u) {
                    if ((m0 ^ 0x7fffffffu)) {
                        c1 = (signed char)((0x80000000u - (r0.x / (0x7fffffffu | 1u))) + (unsigned)!((unsigned)c1 >> (9u & 31u)));
                        if (0xd4f45d9au) {
                            case 1u: ;
                            a0[4u & 3u] = ((unsigned)!(p1 ^ i0) + ((unsigned)s1 & p0));
                            if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(0x5920b739u && 0x10000u), (unsigned)((short)(unsigned)((short)p0 > (signed char)(unsigned)c1) > (signed char)0x80000000u), m0); }
                            v0 = (garr[i1 & 7u] ? (unsigned)(0xb00656fu == (unsigned)(i2 < i0)) : (unsigned)c0);
                            garr[(unsigned)((int)0xffffffffu < (int)(unsigned)w0) & 7u] = (((unsigned)s0 >> ((unsigned)l0 & 31u)) / (p1 | 1u));
                        } else {
                            garr[p0 & 7u] = (unsigned)((int)(unsigned)s1 >= (int)(0x166f660au / ((unsigned)(0x80000000u && 1u) | 1u)));
                            g0 = ((unsigned)!((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)v0) / (p2 | 1u)) * (0x80000000u - (unsigned)d0));
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)0xacabb9f8u < (int)p1), i1, ((unsigned)h1 << (~((unsigned)s1 | i2) & 31u))); }
                        }
                        if (i2) break;
                        if (u3 == 7u) return (fuel + (unsigned)d0);
                    } else {
                        default: ;
                    }
                    break;
                    while ((unsigned)(0x10000u == i2)) { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            c0 = (unsigned char)(unsigned)((0x52252fe9u ? r0.y : 0xc9c7c251u) || i1);
                            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(short)(unsigned)((int)0xd9cef156u < (int)i1), (unsigned)c0, 0x7c3eea6du); }
                            h0 = (short)((0x80000000u & v0) - ((unsigned)s0 >> ((unsigned)(6u == 0xffffffffu) & 31u)));
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)p1 >= (int)0xe89ca2a3u), (unsigned)((int)(unsigned)x0 >= (int)(unsigned)c1), u2); }
                        } while (i0++ < 3u && ((unsigned)((unsigned)(x0 >> 70) || a0[i0 & 3u]) / (6u | 1u)));
                        continue; (void)(((unsigned)(u1 < u2) ^ a0[u1 & 3u]));
                        l0 = (long)((unsigned long)l0 + (i2 >> ((unsigned)w0 & 31u)));
                        h0 = (short)(unsigned)((int)0x10000u >= (int)(unsigned)(unsigned char)(unsigned)(0x735b9495u == (unsigned)f0));
                        case 3u: ;
                        q0 = &garr[(garr[u2 & 7u] + (unsigned)w0) & 7u];
                    }
                    e0 = e0 * 0.5L + (long double)((1u >> ((9u / ((unsigned)d0 | 1u)) & 31u)) & 1023u);
                    h0 = (short)(u1 & (unsigned)(short)(3u + u1));
                    u2 = u2;
                }
                w0 ^= (unsigned long long)r0.y << ((unsigned)(short)(unsigned)(3u && fuel) & 63u);
                e0 = e0 * 0.5L + (long double)((((p1 % ((unsigned)c1 | 1u)) / (i1 | 1u)) ^ (unsigned)s1) & 1023u);
            }
            if ((0xcde602cdu & 5u)) break;
        }
        if ((unsigned)(unsigned char)(unsigned)(m0 < i2)) break;
        g1 += ((unsigned)((unsigned)((int)(unsigned)f0 < (int)u0) || a0[u1 & 3u]) % (a0[u1 & 3u] | 1u));
    }
    if ((p0 / (0xf8a9241cu | 1u))) {
        r0.y ^= (unsigned)((((unsigned)s1 >> (a0[i0 & 3u] & 31u)) / (0xffffffffu | 1u)) && ((unsigned)(x0 >> 70) | r0.x));
        if ((unsigned)((short)8u > (signed char)0x10000u)) {
            while (i0++ < 5u && (unsigned)(signed char)(*q0 ^ (unsigned)c0)) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(u3 < 0x23033fe8u));
                s1 = (int)((unsigned)s1 + p0);
                if (((unsigned)((int)p2 >= (int)0x7fffffffu) & 0x89b2368u)) break;
                b0 = (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)h0) != 0u;
                d0 = d0 * 0.5 + (double)(((unsigned)x0 % (((unsigned)w0 ^ (unsigned)c0) | 1u)) & 1023u);
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)(0xd6aca81cu + (unsigned)((unsigned)h0 && (unsigned)d0));
                    if (*q0) break;
                    *q0 = ((unsigned)(6u == i2) << (0x8a333735u & 31u));
                }
            }
            goto L3;
        }
        do { if (--fuel == 0u) goto done;
            if (fuel < 8u) return (unsigned)((((unsigned)(x0 >> 70) & (unsigned)x0) + i1) < v0);
            if (((unsigned)s0 + u3)) break;
        } while (i0++ < 7u && (unsigned)(unsigned char)(p2 - 0u));
        q0 = &garr[r0.y & 7u];
        if (1u) goto L0;
        garr[(i0 % ((unsigned)e0 | 1u)) & 7u] = ((unsigned)(unsigned char)(1u ^ 0xa57d7147u) % (0x158c5efdu | 1u));
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)(x0 >> 70) && i2)) break;
        if ((unsigned)s0) {
            break; (void)((g1 << ((unsigned)c1 & 31u)));
            f0 = f0 * 0.5f + (float)(((unsigned)(signed char)(unsigned)((int)(0x80000000u - 0u) < (int)(unsigned)(w0 >> 29)) * (unsigned)!((unsigned)f0 * (unsigned)(w0 >> 29))) & 255u);
            if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)w0, ((0x8a129988u >> ((unsigned)b0 & 31u)) / (i2 | 1u)), garr[i1 & 7u]); }
            if (0x79768388u) break;
        }
        switch (((unsigned)w0 - 1u) & 7u) {
            while (i1++ < 2u && (4u >> ((unsigned)h1 & 31u))) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + ~(unsigned)((int)(unsigned)((short)i2 > (signed char)(unsigned)!(2u + (unsigned)d0)) >= (int)i2);
                case 1u: ;
            }
            if ((unsigned)(0x1daab140u == i0)) goto L4;
        }
        if (4u) {
            c0 = (unsigned char)0x7fffffffu;
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(r0.x == ((unsigned)f0 / ((unsigned)h1 | 1u))), (p1 ^ i1), *mp); }
            if (((0x43f201aeu & (unsigned)c1) - u3)) goto L3;
            h0 = (short)(unsigned)((0xfe7632b9u >> (m0 & 31u)) || i2);
            h1 = (unsigned short)(h1 + (((4u - 0u) + (unsigned)x0) - r0.x));
            if (budget != 0u) { budget -= 1u; u3 = fn2((r0.x | 0x420cc50eu), (unsigned)(garr[u2 & 7u] == 0xffffffffu), (unsigned)((short)-(unsigned)((unsigned)(w0 >> 29) && i1) > (signed char)a0[i0 & 3u])); }
        }
        switch (m0 & 7u) {
            s1 = (int)((unsigned)s1 + (unsigned)!(((p0 | r0.x) % (u2 | 1u)) >> (-(unsigned)((short)(unsigned)l0 > (signed char)0x59bbb0b9u) & 31u)));
            *q0 += (unsigned)((int)(unsigned)((int)p2 >= (int)0x7fffffffu) < (int)(unsigned)((int)r0.y >= (int)(unsigned)(x0 >> 70)));
            switch ((6u ? 0xffffffffu : u1) & 7u) {
                u2 += ((p0 >> ((unsigned)s0 & 31u)) & a0[u1 & 3u]);
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)h1, (unsigned)(x0 >> 70), 0xffffffffu); }
                case 1u: ;
                a0[(unsigned)(fuel == m0) & 3u] = 6u;
            }
        }
    }
    if ((unsigned)((int)u3 < (int)(unsigned)f0)) goto L4;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        i1 = u3 & 15u;
        switch ((unsigned)((unsigned)h1 < (unsigned)d0) & 7u) {
            continue; (void)((unsigned)((int)0x80000000u < (int)*q0));
        }
    }
    m0 ^= ((unsigned)l0 | (unsigned)l0);
    if (budget != 0u) { budget -= 1u; u2 = fn2(((0x10000u / (p0 | 1u)) + v0), ~(2u * u0), (unsigned)h0); }
    goto L0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 13u, 0x3d53202au, 0x295cff04u },
        { 8u, 0x8f6d8ebbu, 0xc79da3a2u },
        { 8u, 0xb7cf6807u, 0xc8b26d41u },
        { 1u, 0xa1ae6cebu, 0xe88ffc96u },
        { 0u, 0x27ab8681u, 0xf84720ccu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
