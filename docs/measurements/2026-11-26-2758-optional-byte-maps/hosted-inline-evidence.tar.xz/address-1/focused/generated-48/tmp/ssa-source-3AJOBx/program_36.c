// test-ssa-source's program of seed 134000438 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xb1eabb09u, g1 = 0x11616f15u;
static unsigned garr[8] = { 0xe9ea14ecu, 0x1d7453beu, 0x24fe685u, 0xda2a7246u, 0xe76cb1c5u, 0xdb7b687u, 0x743b9890u, 0x3d2ddbeeu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    garr[(unsigned)w0 & 7u] = (unsigned)(u2 < p2);
    goto L4;
    c0 = (unsigned char)u0;
    L1: if (--fuel == 0u) goto done;
    if ((unsigned)(u2 == r0.x)) goto L4;
    h0 = (short)(unsigned)c0;
    if (~(unsigned)(garr[i1 & 7u] == 0x63363310u)) goto L3;
    if (m0) goto L0;
    *q0 = (~(unsigned)((int)0xd7f3cdu < (int)(unsigned)((short)(unsigned)b0 > (signed char)i0)) ? p1 : garr[u2 & 7u]);
    r0.y ^= i1;
    while (garr[u2 & 7u]) { if (--fuel == 0u) goto done;
        L2: if (--fuel == 0u) goto done;
        u2 += ((r0.x ^ -(3u + (unsigned)h0)) * ((unsigned)s1 % (0x10000u | 1u)));
        L3: if (--fuel == 0u) goto done;
        switch (0xebafb8c0u & 7u) {
            d0 = d0 * 0.5 + (double)((unsigned)(~((unsigned)(*mp < 0x17fcb7e1u) / ((unsigned)e0 | 1u)) < (0x10000u % (6u | 1u))) & 1023u);
            L4: if (--fuel == 0u) goto done;
        }
        if ((unsigned)!((unsigned)c0 & (unsigned)l0)) break;
        m0 ^= (unsigned)((int)g1 < (int)*mp);
    }
    if (fuel < 8u) return (unsigned)(g0 || i1);
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 6u && (0x6cced0fdu * p0)) { if (--fuel == 0u) goto done;
            s0 = (int)((unsigned)(short)(i2 % (~((unsigned)h1 + 0xffffffffu) | 1u)) * ((unsigned)h0 - u3));
            switch ((5u & 0x1de2a788u) & 7u) {
                x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((a0[i0 & 3u] & (unsigned)w0) ^ (unsigned)((int)p0 < (int)3u));
                case 4u: ;
                f0 = f0 * 0.5f + (float)(i0 & 255u);
            }
            goto L2;
            if (0x10000u) {
                switch ((unsigned)(w0 >> 29) & 7u) {
                    case 7u: ;
                }
                break; (void)((unsigned)(0xffffffffu < 0xffffffffu));
                switch (0xbbeea34u & 7u) {
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        v0 = (unsigned)((unsigned)d0 < 0x7fffffffu);
                    }
                    garr[(v0 - p1) & 7u] = (unsigned)(signed char)(v0 % (i2 | 1u));
                    case 6u: ;
                    x0 = x0 * 0x100000001b3ull + ((unsigned)c1 >> (0x8210b2acu & 31u));
                    case 7u: ;
                }
            }
        }
        while (i1++ < 4u && 0x3e687f68u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)(short)(g0 | (unsigned)h0) << ((u3 / (~(unsigned)((int)(unsigned)d0 < (int)0xf73f17u) | 1u)) & 63u);
            m0 ^= (unsigned)((int)(r0.y | (unsigned)((int)(0x80000000u - 2u) >= (int)0xdc00f351u)) < (int)*q0);
            c1 = (signed char)(((unsigned)s1 + 1u) >> ((unsigned)((int)p0 >= (int)*mp) & 31u));
        }
        if ((unsigned)d0) break;
        r0.y ^= ((unsigned)(((a0[i0 & 3u] >> ((unsigned)x0 & 31u)) % (0xffffffffu | 1u)) < (unsigned)c1) | p2);
        if ((unsigned)x0) {
            continue; (void)((unsigned)((int)(unsigned)((short)0x7fffffffu > (signed char)(unsigned)s1) < (int)u0));
            garr[g0 & 7u] = *mp;
            do { if (--fuel == 0u) goto done;
                break; (void)((unsigned)e0);
            } while (i1++ < 7u && u0);
            do { if (--fuel == 0u) goto done;
                if (((unsigned)h0 * (i0 - 0x7fffffffu))) break;
                r0.x = (unsigned)!(unsigned)((int)(unsigned)f0 >= (int)((unsigned)(x0 >> 70) ^ 2u));
                if ((-(unsigned)(0x10000u || (unsigned)c1) << (u3 & 31u))) break;
                c0 = (unsigned char)(i0 ? (unsigned)c1 : ((unsigned)c0 & (unsigned)((int)0x7ee62a3u < (int)garr[u2 & 7u])));
                u3 ^= ((0u & *mp) * (unsigned)(signed char)((0x66552f09u & (unsigned)b0) / (0xf33c94d6u | 1u)));
            } while (i1++ < 3u && (0x10000u & (unsigned)(u1 < a0[i0 & 3u])));
            if ((unsigned)(garr[u2 & 7u] || (unsigned)((short)a0[i0 & 3u] > (signed char)0x4541b6dau))) {
                if (g0) {
                    if (p2) break;
                    x0 = x0 * 0x100000001b3ull + (p2 | p0);
                    if ((5u | 8u)) break;
                    switch ((unsigned)((short)(garr[u2 & 7u] & 0x7fffffffu) > (signed char)8u) & 7u) {
                        case 5u: ;
                        d0 = d0 * 0.5 + (double)((unsigned)(0x80000000u < ((unsigned)(0x10b02fd2u < p1) % (i2 | 1u))) & 1023u);
                        case 1u: ;
                        case 6u: ;
                    }
                    h1 = (unsigned short)(h1 + (a0[u1 & 3u] % ((unsigned)d0 | 1u)));
                    garr[(unsigned)(short)(0x80000000u ^ 6u) & 7u] = (p2 - 0x7fffffffu);
                } else {
                    h0 = (short)(~(fuel + m0) + ((unsigned)c0 | (unsigned)l0));
                    s1 = (int)((unsigned)s1 + (unsigned)(((unsigned)(0x80000000u || (unsigned)c1) >> ((unsigned)l0 & 31u)) || (unsigned)s1));
                    while (i1++ < 7u && (unsigned)((int)0xe8023af7u >= (int)0xb8efe414u)) { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)(unsigned)(unsigned char)((unsigned)d0 % (u1 | 1u)) < (int)(unsigned)s1)) goto L4;
                        if (~((0x8e9c1d27u * fuel) - 0xffffffffu)) break;
                        *q0 = 0x7fffffffu;
                        if ((unsigned)c0) break;
                        r0.y ^= ((unsigned)((int)0xffffffffu >= (int)0x82349258u) % ((unsigned)(p2 || g1) | 1u));
                    }
                }
            } else {
                if ((*q0 / (0x10000u | 1u))) break;
                h0 = (short)(unsigned)s0;
                if (9u) goto L2;
                q0 = &garr[((unsigned)((unsigned)(short)(p2 >> (0x96fd0fddu & 31u)) && g1) / (0xc603d504u | 1u)) & 7u];
            }
        }
        break; (void)((p2 + (unsigned)d0));
    }
    if (((unsigned)f0 & 0u)) goto L2;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(~(unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)(m0 || (unsigned)s0)));
        continue; (void)((unsigned)h1);
    }
    r0.x = (u1 - ((unsigned)x0 ? v0 : m0));
    if ((unsigned)((unsigned)(x0 >> 70) == a0[i0 & 3u])) {
        c0 = (unsigned char)((((unsigned)f0 ? p2 : 5u) / ((unsigned)e0 | 1u)) & 0x449f9c0eu);
        if ((unsigned)((short)(unsigned)h0 > (signed char)*q0)) goto L0;
        m0 ^= (unsigned)((int)r0.y >= (int)((unsigned)c1 | 4u));
        f0 = f0 * 0.5f + (float)((unsigned)((short)6u > (signed char)(unsigned)((int)(unsigned)h1 < (int)(p1 * garr[u2 & 7u]))) & 255u);
        if ((unsigned)e0) goto L2;
        if ((*mp ^ (i1 << (r0.y & 31u)))) {
            if ((unsigned)(*mp || garr[u2 & 7u])) goto L0;
        }
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)(((*mp & v0) - (unsigned)(unsigned char)(i1 - (unsigned)(w0 >> 29))) & 1023u);
        if ((unsigned)h0) break;
        x0 = x0 * 0x100000001b3ull + 0xf0f8e2eu;
        break; (void)(((unsigned)(unsigned char)(unsigned)((unsigned)c1 && p2) + (unsigned)h0));
    }
    c1 = (signed char)(0x10000u * r0.x);
    if ((p2 ^ (unsigned)d0)) {
        *q0 = ((unsigned)!(unsigned)((unsigned)d0 == (unsigned)x0) >> (r0.y & 31u));
        s0 = (int)(unsigned)(0x80000000u || (unsigned)h1);
        u3 ^= (unsigned)((unsigned)((unsigned)c0 && (unsigned)!((unsigned)w0 >> (p1 & 31u))) == -(unsigned)(1u == 0x10000u));
        e0 = e0 * 0.5L + (long double)((-(r0.x % (v0 | 1u)) - (unsigned)((int)(p1 - (unsigned)c0) < (int)(unsigned)l0)) & 1023u);
        if ((unsigned)((int)p2 < (int)(8u % (3u | 1u)))) goto L3;
    } else {
        if (((unsigned)l0 / (u0 | 1u))) goto L1;
        goto L0;
        g0 = (unsigned)(short)(p1 >> ((unsigned)(i0 < (0x5aafe17eu | 7u)) & 31u));
    }
    i0 = (v0 - (unsigned)((int)0xffffffffu < (int)g1)) & 15u;
    u0 = u0 * 0x9e3779b1u + ((unsigned)((v0 - a0[i0 & 3u]) == (unsigned)(x0 >> 70)) & (i2 >> ((unsigned)f0 & 31u)));
    w0 = w0 * 6364136223846793005ull + (1u >> ((unsigned)(r0.x && (unsigned)l0) & 31u));
    *q0 += ~(unsigned)((short)(unsigned)(p1 || (unsigned)(9u < 0x9a02484cu)) > (signed char)(unsigned)(w0 >> 29));
    *q0 = a0[i0 & 3u];
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)0xd07db909u < (int)9u)) break;
        if ((0x7fffffffu ^ -(unsigned)(0x3b28edacu == (unsigned)b0))) break;
        while (i1++ < 2u && (a0[i0 & 3u] * m0)) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)0x7fffffffu;
            { unsigned t0; double z0; if ((0x80000000u) & 1u) { t0 = (unsigned)w0; z0 = (double)((p1) & 255u); } if ((0x80000000u) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                if ((unsigned)((int)7u < (int)-(unsigned)(garr[u2 & 7u] < fuel))) break;
            }
            d0 = d0 * 0.5 + (double)(((unsigned)s0 % (((unsigned)w0 - (unsigned)w0) | 1u)) & 1023u);
            if (((a0[u1 & 3u] / (p0 | 1u)) % (p0 | 1u))) goto L0;
            l0 = (long)((unsigned long)l0 + (garr[u2 & 7u] + (unsigned)(garr[i1 & 7u] || g1)));
        }
        { unsigned t1; double z1; if ((((u1 % (0xd7601721u | 1u)) + fuel)) & 1u) { t1 = (unsigned)((short)3u > (signed char)(unsigned)(0x80000000u < (unsigned)e0)); z1 = (double)(((fuel / (((unsigned)h1 * (unsigned)s0) | 1u))) & 255u); } if ((((u1 % (0xd7601721u | 1u)) + fuel)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            if ((unsigned)f0) break;
            if (((unsigned)(w0 >> 29) / (0xb3d61156u | 1u))) break;
            s0 = (int)(unsigned)((0x10000u >> (i1 & 31u)) < 0x80000000u);
            s0 = (int)(0x7fffffffu ^ i2);
            break; (void)((0xffffffffu * (4u + p1)));
        }
        if ((unsigned)((unsigned)c0 || 0xffffffffu)) break;
        { unsigned t2; double z2; if (((unsigned)((int)0x3ba62d37u >= (int)8u)) & 1u) { t2 = (unsigned)((int)u0 < (int)p2); z2 = (double)((1u) & 255u); } if (((unsigned)((int)0x3ba62d37u >= (int)8u)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            r0.y ^= 0x10000u;
            while ((a0[i0 & 3u] / (0x7fffffffu | 1u))) { if (--fuel == 0u) goto done;
                s0 = (int)(unsigned)s0;
                if ((unsigned)((int)6u >= (int)(unsigned)((short)0x7fffffffu > (signed char)garr[i1 & 7u]))) break;
                v0 = r0.y;
                if ((0x96d10442u | (unsigned)c1)) break;
            }
            if ((unsigned)l0) break;
            if ((unsigned)((unsigned)c0 || u1)) break;
        }
    }
    r0.y ^= ((2u >> (r0.x & 31u)) - (unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)(u0 == (unsigned)c1)));
    r0.y ^= (unsigned)(9u == ~(unsigned)((short)(unsigned)(p0 || (unsigned)x0) > (signed char)*mp));
    b0 = (unsigned)((int)((7u & 0x51129d96u) ^ i2) >= (int)(unsigned)s0) != 0u;
    if (r0.x) goto done;
    if ((unsigned)((short)0xf6880cd4u > (signed char)(unsigned)(5u < i1))) goto L4;
    goto L2;
    f0 = f0 * 0.5f + (float)((unsigned)!(unsigned)(~(unsigned)((int)(unsigned)f0 >= (int)garr[i1 & 7u]) == a0[u1 & 3u]) & 255u);
    if ((unsigned)(g0 == (0x10000u >> (*q0 & 31u)))) goto L2;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((0x10000u % ((unsigned)e0 | 1u))) {
            l0 = (long)((unsigned long)l0 + u2);
        } else {
            if (a0[u1 & 3u]) {
                garr[0x10000u & 7u] = ((unsigned)(0xedad5962u == 0xffffffffu) >> ((unsigned)s0 & 31u));
                break; (void)(-(unsigned)((int)i0 >= (int)(unsigned)h0));
            } else {
                i0 = (unsigned)w0 & 15u;
                i0 = 0u & 15u;
                if ((a0[i0 & 3u] + 0xfcc7e0b6u)) break;
                if (((unsigned)h0 ^ (unsigned)(p0 < m0))) break;
            }
            if (((i2 >> ((unsigned)w0 & 31u)) / (u3 | 1u))) break;
            if ((unsigned)(signed char)(unsigned)((int)4u >= (int)p1)) goto L2;
        }
        l0 = (long)((unsigned long)l0 + v0);
        if (p0) break;
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((*q0 % (p2 | 1u))) break;
        { unsigned t3; double z3; if ((0u) & 1u) { t3 = (unsigned)(r0.y == 4u); z3 = (double)((u0) & 255u); } if ((0u) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            if ((unsigned)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)v0) < m0)) break;
            if (0x4e4203a6u) break;
        }
    }
    goto done;
    w0 = w0 * 6364136223846793005ull + (unsigned)(((unsigned)((int)*mp >= (int)0x10000u) + (unsigned)((unsigned)x0 == u3)) == *q0);
    switch ((i2 - (unsigned)s1) & 7u) {
        if (garr[i1 & 7u]) goto L1;
        q0 = &garr[((unsigned)(m0 == (unsigned)(x0 >> 70)) | ((u2 + (unsigned)e0) + fuel)) & 7u];
        if ((unsigned)f0) {
            h0 = (short)(unsigned)s0;
            d0 = d0 * 0.5 + (double)((unsigned)(short)(unsigned)((unsigned)w0 < ((unsigned)w0 + fuel)) & 1023u);
        }
        r0.x = (unsigned)(*q0 && (unsigned)!(garr[u2 & 7u] - (0u ^ u3)));
    }
    d0 = d0 * 0.5 + (double)(((r0.x ? (unsigned)(x0 >> 70) : p2) * (unsigned)h0) & 1023u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (u3 == 7u) return (9u ^ i2);
    w0 ^= (unsigned long long)(unsigned)(a0[u1 & 3u] < 0xd44bc0cau) << (0x20cbdd57u & 63u);
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)e0 == u3), 0u, (u1 + ((unsigned)h1 + 0xffffffffu))); }
    while (i0++ < 5u && (0xbb88b033u ? 1u : 0x2401b24fu)) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)h1 / (0x7fffffffu | 1u)));
        *mp = (u0 % (u0 | 1u));
        do { if (--fuel == 0u) goto done;
            a0[i1 & 3u] = (unsigned)(signed char)((unsigned)((short)u2 > (signed char)0x98bd3bb8u) / ((0xffffffffu - p2) | 1u));
            if ((unsigned)(g1 || (a0[i0 & 3u] ^ (unsigned)s0))) goto L4;
        } while (i1++ < 7u && (r0.y ^ (unsigned)w0));
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if (((unsigned)(a0[i0 & 3u] == a0[i0 & 3u])) & 1u) { t0 = garr[i1 & 7u]; z0 = (double)((((unsigned)((int)*q0 >= (int)u1) * r0.x)) & 255u); } if (((unsigned)(a0[i0 & 3u] == a0[i0 & 3u])) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                h0 = (short)(u1 * p2);
                c0 = (unsigned char)(unsigned)((((unsigned)(w0 >> 29) % (p0 | 1u)) | fuel) < 0xff0d9adeu);
                if (budget != 0u) { budget -= 1u; u0 = fn0((((unsigned)b0 + 1u) >> (fuel & 31u)), (unsigned)s0, (4u + 2u)); }
            }
            c1 = (signed char)((unsigned)(0x8aeca221u < (unsigned)h0) + fuel);
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)x0 >= (int)v0), (unsigned)(0x74c2ba04u < a0[i0 & 3u]), i2); }
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
                u3 = u3 * 0x9e3779b1u + (unsigned)((unsigned)((short)u2 > (signed char)g0) && (0x28d960dfu & (unsigned)s1));
                if ((5u >> ((0xfe108e76u * 0x80000000u) & 31u))) continue;
                if ((unsigned)(unsigned char)((unsigned)((unsigned)d0 || u2) % (fuel | 1u))) {
                    garr[(unsigned)f0 & 7u] = (unsigned)(short)((unsigned)f0 * 0xc5b16775u);
                    r0.y ^= (0x8613568fu + 0xffffffffu);
                    continue; (void)(((unsigned)h0 + p0));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s1, (unsigned)((int)(unsigned)(w0 >> 29) < (int)((unsigned)(x0 >> 70) ^ r0.y)), 0u); }
                    *q0 += (-(unsigned)((unsigned)(0xdb746a41u < (unsigned)d0) || 0x8fc015f8u) + fuel);
                } else {
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)f0 < (int)p2);
                    a0[(unsigned)(4u < *q0) & 3u] = (unsigned)(((unsigned)(signed char)(2u * (unsigned)d0) | u3) == u0);
                }
                do { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)e0 < ((unsigned)e0 * p1)));
                } while (i0++ < 3u && (unsigned)((short)g0 > (signed char)(unsigned)(w0 >> 29)));
                L1: if (--fuel == 0u) goto done;
            }
            u2 = (((4u * (unsigned)x0) >> (p2 & 31u)) & 0x650efe30u);
            w0 ^= (unsigned long long)0x7fffffffu << ((unsigned)(short)(6u << ((unsigned)((unsigned)(a0[i0 & 3u] && 0x31f82b52u) < (unsigned)c0) & 31u)) & 63u);
        }
        if (((unsigned)l0 / (((unsigned)b0 >> ((unsigned)(w0 >> 29) & 31u)) | 1u))) {
            if ((unsigned)((short)(unsigned)b0 > (signed char)~(unsigned)((int)p0 < (int)i0))) {
                w0 ^= (unsigned long long)(8u / ((unsigned)s1 | 1u)) << ((0xc086d9cau - fuel) & 63u);
                w0 ^= (unsigned long long)1u << (((unsigned)d0 << (0xff1f447bu & 31u)) & 63u);
                goto L3;
                if ((unsigned)h0) break;
                continue; (void)(((unsigned)((short)(unsigned)c0 > (signed char)7u) << (garr[u2 & 7u] & 31u)));
                s0 = (int)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)a0[i0 & 3u]) << ((unsigned)(0x942f607fu || (4u & (unsigned)c0)) & 31u));
            }
            h1 = (unsigned short)(h1 + (((v0 | (unsigned)l0) ^ (unsigned)l0) ^ *q0));
            if ((unsigned)!(7u & (unsigned)((short)p1 > (signed char)g1))) break;
            if (0x10000u) break;
            if (budget != 0u) { budget -= 1u; u1 = fn0(0xffffffffu, (unsigned)((unsigned)(p0 && (unsigned)w0) == (unsigned)h1), (p0 % (((unsigned)c0 >> ((unsigned)e0 & 31u)) | 1u))); }
        } else {
            while ((unsigned)(0x7fffffffu < ((unsigned)c1 ^ (unsigned)x0))) { if (--fuel == 0u) goto done;
                while (u3) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + ((p1 - (unsigned)c0) / ((unsigned)((unsigned)s1 < *q0) | 1u));
                }
                u1 += 5u;
                do { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)(x0 >> 70) < (int)u3), (u2 >> ((unsigned)(r0.x && r0.y) & 31u)), (unsigned)(0xa4839315u || 0u)); }
                        b0 = (unsigned)s0 != 0u;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)(unsigned)(u1 < (p1 % ((unsigned)l0 | 1u))), (unsigned)((unsigned)s1 || (unsigned)h1), (0x80000000u | (unsigned)h1)); }
                        if (fuel < 8u) return fuel;
                        w0 ^= (unsigned long long)u2 << ((unsigned)((unsigned)((unsigned)f0 < ((unsigned)((unsigned)c1 && u0) >> (1u & 31u))) == a0[u1 & 3u]) & 63u);
                        if (budget != 0u) { budget -= 1u; u2 = fn0(0xfb014e29u, (unsigned)(signed char)((unsigned)x0 - 0x1ea5c68au), (unsigned)((unsigned)((short)p2 > (signed char)0x80000000u) || (unsigned)d0)); }
                    } while (i0++ < 3u && (unsigned)c0);
                } while (i2++ < 6u && ((r0.x % (fuel | 1u)) << (u0 & 31u)));
                if ((unsigned)(unsigned char)(u0 - (0x10000u ^ g1))) goto L3;
                L2: if (--fuel == 0u) goto done;
                a0[4u & 3u] = (unsigned)!(u3 + (unsigned)((int)4u < (int)r0.y));
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)f0 / (*q0 | 1u)), ((unsigned)(x0 >> 70) << ((0x7fffffffu / ((unsigned)h0 | 1u)) & 31u)), 0x576f42d0u); }
        }
        garr[(unsigned)((int)m0 < (int)*q0) & 7u] = (unsigned)(short)(6u / ((unsigned)((int)(unsigned)((short)0x3194cf96u > (signed char)(unsigned)(0x80000000u || 0x80000000u)) >= (int)0xb78155dfu) | 1u));
    }
    if ((unsigned)((short)-(unsigned)((unsigned)c0 && (unsigned)x0) > (signed char)(unsigned)x0)) goto L0;
    if ((0x9241e11au * 0x814db55eu)) {
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)c0 & 0x10000u), (unsigned)((int)(u0 & i0) < (int)p1), r0.y); }
        if ((unsigned)b0) goto L3;
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            i0 = (unsigned)(p2 && (i1 - (unsigned)s1)) & 15u;
            g0 = ~(unsigned)(u3 || 9u);
            w0 ^= (unsigned long long)~(0x5ee89b3au + u0) << ((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)s0) & 63u);
        }
    }
    if ((unsigned)((short)((unsigned)b0 >> (0x80000000u & 31u)) > (signed char)(unsigned)(x0 >> 70))) {
        r0.x = (unsigned)((short)(unsigned)((unsigned)(x0 >> 70) && (unsigned)d0) > (signed char)r0.x);
        l0 = (long)((unsigned long)l0 + (0x9510587du + 0x8e16d810u));
        r0.x = p2;
        r0.x = (unsigned)((unsigned)!(5u >> (6u & 31u)) || ((1u - (unsigned)(w0 >> 29)) * (unsigned)f0));
        r0.y ^= ((unsigned)(u2 || ((unsigned)s0 ? u0 : (unsigned)s0)) >> ((unsigned)c0 & 31u));
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(x0 >> 70) >> ((unsigned)((short)0xffffffffu > (signed char)i1) & 31u)), ((unsigned)h0 ? 0u : g0), (unsigned)(g1 && v0)); }
    *mp = (unsigned)(x0 >> 70);
    if ((unsigned)!((unsigned)f0 ? i1 : p2)) goto L2;
    if ((2u * (u1 % (r0.y | 1u)))) {
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)f0, (unsigned)d0, (unsigned)!(0xd725f60u | (2u ^ garr[u2 & 7u]))); }
        q0 = &garr[u0 & 7u];
        goto L0;
        goto L0;
        if ((unsigned)w0) goto done;
    }
    goto L3;
    d0 = d0 * 0.5 + (double)((0xffffffffu >> ((6u | (0xffffffffu | a0[u1 & 3u])) & 31u)) & 1023u);
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0x80000000u) {
            if ((0x621188f8u * (unsigned)h1)) continue;
            b0 = ((unsigned)(r0.x == p0) | (unsigned)h0) != 0u;
            garr[-(unsigned)((short)a0[u1 & 3u] > (signed char)garr[u2 & 7u]) & 7u] = (((unsigned)(w0 >> 29) ? a0[i0 & 3u] : *q0) ^ (unsigned)f0);
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)l0, (unsigned)((unsigned)h1 == (unsigned)d0), ((unsigned)l0 ^ (m0 * (unsigned)e0))); }
            } while (i1++ < 7u && 0u);
            if ((unsigned)((short)2u > (signed char)a0[i0 & 3u])) break;
            g0 = ~((unsigned)((int)5u < (int)(g0 ? 0u : r0.x)) % (u1 | 1u));
        }
        L3: if (--fuel == 0u) goto done;
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)((-(unsigned)((int)(unsigned)f0 < (int)u3) * u1) && (unsigned)(0x6a8fbc19u || 0x91469980u));
    e0 = e0 * 0.5L + (long double)((0x8e6555d4u / ((p2 ^ fuel) | 1u)) & 1023u);
    if (budget != 0u) { budget -= 1u; u3 = fn0((0x92dba1fu & (unsigned)h0), -(v0 / (2u | 1u)), 2u); }
    if ((unsigned)w0) goto L2;
    f0 = f0 * 0.5f + (float)(0x80000000u & 255u);
    L4: if (--fuel == 0u) goto done;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0x7fffffffu) {
            if ((unsigned)x0) break;
            if (fuel) break;
            i0 = (unsigned)f0 & 15u;
            continue; (void)(p2);
            break; (void)(u3);
        }
        *q0 = (unsigned)((int)7u < (int)(unsigned)((unsigned)s0 < (unsigned)(x0 >> 70)));
    }
    if (~((unsigned)e0 * (unsigned)((unsigned)h1 < r0.y))) goto L4;
    if ((((unsigned)(w0 >> 29) - p2) / ((unsigned)(w0 >> 29) | 1u))) {
        v0 = (unsigned)((unsigned)!((unsigned)((int)0xf8019f3fu < (int)fuel) / (garr[u2 & 7u] | 1u)) && 0x7fffffffu);
        garr[(unsigned)(u1 == (unsigned)(x0 >> 70)) & 7u] = ((unsigned)(unsigned char)((unsigned)h1 + (garr[i1 & 7u] - 1u)) >> (garr[u2 & 7u] & 31u));
        if ((0x7fffffffu + a0[u1 & 3u])) goto L2;
        if ((g1 << (0xbbc86725u & 31u))) goto L2;
        if (budget != 0u) { budget -= 1u; u2 = fn0(i0, a0[i0 & 3u], (unsigned)((short)0x80000000u > (signed char)0x84c6d308u)); }
    }
    for (;;) { if (--fuel == 0u) goto done;
        { unsigned t1; double z1; if ((((unsigned)(unsigned char)(0xd8ef1decu * *mp) & 0xffffffffu)) & 1u) { t1 = (unsigned)(0x216d0a65u == (p2 + u1)); z1 = (double)((0x80000000u) & 255u); } if ((((unsigned)(unsigned char)(0xd8ef1decu * *mp) & 0xffffffffu)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            if (0x7fffffffu) break;
            h0 = (short)(unsigned)((v0 + (unsigned)s1) || (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)(x0 >> 70)));
            break; (void)((unsigned)((int)(2u ^ *q0) < (int)0xd0425b19u));
        }
        if ((unsigned)((int)0xc0336cabu < (int)(5u % (3u | 1u)))) {
            u1 = (unsigned)(((unsigned)(w0 >> 29) | (unsigned)d0) == (unsigned)((unsigned)e0 || r0.x));
            break; (void)(0x7fffffffu);
            if (~((unsigned)(w0 >> 29) + (unsigned)(garr[u2 & 7u] || 0xffffffffu))) break;
            d0 = d0 * 0.5 + (double)((garr[u2 & 7u] - p0) & 1023u);
        }
    }
    if (0x10000u) goto L2;
    { unsigned t2; double z2; if (((garr[u2 & 7u] * (unsigned)!(unsigned)((short)a0[i0 & 3u] > (signed char)0u))) & 1u) { t2 = i1; z2 = (double)((((unsigned)e0 & (0x7fffffffu * (unsigned)w0))) & 255u); } if (((garr[u2 & 7u] * (unsigned)!(unsigned)((short)a0[i0 & 3u] > (signed char)0u))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        u2 ^= (unsigned)((int)(unsigned)((int)v0 < (int)(unsigned)f0) >= (int)(unsigned)!(0x7fffffffu * ((unsigned)w0 & garr[i1 & 7u])));
        if (~(unsigned)((int)(fuel % (2u | 1u)) >= (int)(unsigned)x0)) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(w0 >> 29) == ((unsigned)b0 - (unsigned)d0)), (5u + p2), ~(unsigned)(i1 == (unsigned)(g0 && a0[u1 & 3u]))); }
            if ((unsigned)((unsigned)d0 || p2)) goto L4;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)c1 < p1), (a0[i0 & 3u] + u1), m0); }
            if ((unsigned)s1) goto L3;
            s0 = (int)((unsigned)c0 + (garr[i1 & 7u] ? *mp : (unsigned)(x0 >> 70)));
            v0 = ((r0.y ? p2 : (unsigned)s0) * (8u - 0u));
        } else {
            u3 = 0x803105fau;
            i0 = ((unsigned)(short)(unsigned)((int)*mp >= (int)(0xffffffffu * (unsigned)c0)) / (garr[u2 & 7u] | 1u)) & 15u;
            if ((unsigned)(8u == (unsigned)s1)) goto L3;
        }
        *mp = (unsigned)((short)(unsigned)((int)(unsigned)e0 < (int)(unsigned)(6u == p2)) > (signed char)0x52900b4u);
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)u2 >= (int)0xffffffffu), (unsigned)(signed char)(unsigned)(p0 < *mp), (i0 + p1)); }
        if ((unsigned)c0) {
            c1 = (signed char)((unsigned)((int)0u >= (int)(unsigned)d0) % ((unsigned)c0 | 1u));
            m0 ^= ((unsigned)((unsigned)(v0 < i1) && 0x3f87bcb4u) - (unsigned)h0);
        } else {
            if (budget != 0u) { budget -= 1u; u2 = fn0((g1 / ((1u / ((unsigned)w0 | 1u)) | 1u)), (unsigned)((int)g1 < (int)(unsigned)l0), 0x80000000u); }
            r0.y ^= (((unsigned)s0 - (unsigned)x0) * u2);
            s1 = (int)((unsigned)s1 + ((unsigned)h0 | (unsigned)(short)(unsigned)((int)(u3 + 0x8c84ebd0u) < (int)*mp)));
        }
    }
    if (3u) {
        while (i0++ < 3u && (unsigned)h1) { if (--fuel == 0u) goto done;
            break; (void)((a0[u1 & 3u] ^ 0xffffffffu));
            if ((unsigned)(m0 == 0x39f58208u)) break;
        }
        if (((unsigned)c1 << ((u0 ^ (unsigned)(x0 >> 70)) & 31u))) goto L2;
    } else {
        do { if (--fuel == 0u) goto done;
            if (u3 == 7u) return ((unsigned)(x0 >> 70) + (p1 | (u2 ^ (unsigned)(x0 >> 70))));
        } while (i0++ < 4u && (unsigned)(signed char)((unsigned)((short)g1 > (signed char)7u) >> (m0 & 31u)));
        m0 ^= (0xffffffffu % ((unsigned)e0 | 1u));
        r0.y ^= p0;
    }
    if ((unsigned)((int)garr[i1 & 7u] >= (int)*q0)) goto L4;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)(w0 >> 29));
        while (i1++ < 5u && (r0.y & (a0[u1 & 3u] >> (0xf5b33bcu & 31u)))) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + (v0 - (unsigned)(short)(unsigned)(0xd82c451au || ((unsigned)d0 - 0xffffffffu))));
            { unsigned t3; double z3; if (((garr[i1 & 7u] / (0xff092b99u | 1u))) & 1u) { t3 = (unsigned)((p2 * (unsigned)e0) || (unsigned)e0); z3 = (double)((v0) & 255u); } if (((garr[i1 & 7u] / (0xff092b99u | 1u))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                if (u3 == 7u) return (unsigned)(a0[i0 & 3u] == 0x7fffffffu);
                h0 = (short)(unsigned)((unsigned)((unsigned)s0 == (unsigned)c0) || (a0[u1 & 3u] | i2));
            }
            r0.x = ((unsigned)(unsigned char)(0xec00c058u / (((unsigned)(0x57cf121u && a0[u1 & 3u]) & *mp) | 1u)) ^ (unsigned)e0);
            if (fuel < 8u) return (unsigned)((unsigned)(unsigned char)(unsigned)(0xffffffffu || u0) && (unsigned)((int)v0 >= (int)r0.y));
            if (u3 == 7u) return 0x10000u;
            if (~((unsigned)(short)(unsigned)((short)a0[i0 & 3u] > (signed char)p1) & (unsigned)(w0 >> 29))) goto L4;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(0xffffffffu, 7u, (unsigned)((int)((unsigned)h0 >> (garr[i1 & 7u] & 31u)) < (int)6u)); }
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0(0x2354c0a9u, (*mp ? garr[i1 & 7u] : 5u), (unsigned)((short)a0[u1 & 3u] > (signed char)*mp)); }
        if (p1) {
            if ((0xffffffffu * (unsigned)c0)) break;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(a0[u1 & 3u] || (garr[u2 & 7u] * 0xfc1de69u)), (unsigned)(-(unsigned)((int)(unsigned)s0 >= (int)*q0) || i0), (unsigned)(unsigned char)(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)s0)); }
            switch ((fuel ^ (unsigned)e0) & 7u) {
                garr[u0 & 7u] = (unsigned)((unsigned)l0 == (unsigned)(0xffffffffu || (0x7fffffffu * (p2 << (0xcdc97692u & 31u)))));
                { unsigned t4; double z4; if (((a0[i0 & 3u] + fuel)) & 1u) { t4 = ((unsigned)((short)0x1f2dd4cdu > (signed char)v0) ^ 0x6ee30634u); z4 = (double)(((p1 * 0x7bd3f5a1u)) & 255u); } if (((a0[i0 & 3u] + fuel)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    s1 = (int)((unsigned)s1 + (u2 / (0xffffffffu | 1u)));
                    if (g1) break;
                    case 0u: ;
                    if ((unsigned)b0) continue;
                    if (0xb5bdb843u) break;
                    *q0 += (0x80000000u | ~((unsigned)f0 ? (fuel | 0u) : (unsigned)s0));
                }
                if ((unsigned)((int)0x9ae7bb84u < (int)(garr[u2 & 7u] >> (garr[u2 & 7u] & 31u)))) goto L4;
                break; (void)((unsigned)l0);
                case 6u: ;
                while ((unsigned)((short)0x89a6b3a9u > (signed char)p2)) { if (--fuel == 0u) goto done;
                    m0 ^= ((unsigned)(0xce1b3710u || 0x276fdde0u) | (unsigned)(unsigned char)(9u / ((garr[i1 & 7u] + (unsigned)h1) | 1u)));
                    b0 = (7u ^ (unsigned)d0) != 0u;
                    if (((unsigned)c1 & fuel)) continue;
                    e0 = e0 * 0.5L + (long double)((u2 | (unsigned)(short)(unsigned)((int)(unsigned)(0xc34fc14fu || *mp) >= (int)g1)) & 1023u);
                }
            }
            w0 ^= (unsigned long long)(u1 & (unsigned)h0) << ((unsigned)((int)(p0 & 0x613aeef7u) >= (int)(0x80000000u | 0x10000u)) & 63u);
        } else {
            if ((0xece60468u << ((unsigned)c0 & 31u))) goto L3;
            r0.y ^= u2;
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 = (unsigned)((short)p0 > (signed char)0xffffffffu);
                m0 ^= (i0 - (unsigned)f0);
                { unsigned t5; double z5; if (((unsigned)c1) & 1u) { t5 = 0x6db62b75u; z5 = (double)((-((unsigned)w0 / (a0[u1 & 3u] | 1u))) & 255u); } if (((unsigned)c1) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    c0 = (unsigned char)(((unsigned)l0 & (unsigned)s1) >> ((unsigned)l0 & 31u));
                    while (i2++ < 4u && (unsigned)((*mp ^ r0.x) || 0x10000u)) { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            w0 = w0 * 6364136223846793005ull + (unsigned)(0x10000u == (unsigned)(w0 >> 29));
                        } while (i0++ < 6u && (((unsigned)c1 << ((unsigned)(x0 >> 70) & 31u)) + (unsigned)s0));
                        r0.y ^= (unsigned)((short)((unsigned)(0x9c4414beu < 0x7fffffffu) ? (unsigned)d0 : p1) > (signed char)0x86537e1bu);
                        if (0x7fffffffu) break;
                        u2 = u2 * 0x9e3779b1u + ((unsigned)(x0 >> 70) % ((unsigned)((unsigned)((int)*mp < (int)(unsigned)h0) || (unsigned)(x0 >> 70)) | 1u));
                    }
                    c1 = (signed char)g1;
                    u2 = (unsigned)(a0[i0 & 3u] < (unsigned)((short)((unsigned)s0 ? 9u : u2) > (signed char)r0.x));
                    if ((v0 * r0.y)) break;
                    switch ((unsigned)(signed char)((unsigned)(unsigned char)(unsigned)((int)*mp >= (int)(unsigned)d0) & (unsigned)d0) & 7u) {
                        if (budget != 0u) { budget -= 1u; u2 = fn0((u1 ? (unsigned)b0 : 0x80000000u), (garr[i1 & 7u] * u1), ((unsigned)(x0 >> 70) | r0.x)); }
                        u1 = ((0x42766ad1u ? (unsigned)x0 : (unsigned)c0) >> ((unsigned)(0xa09d1b61u && 9u) & 31u));
                    }
                }
                if ((0x4bca531cu | (unsigned)(a0[u1 & 3u] && (unsigned)c1))) break;
            }
            { unsigned t6; double z6; if (((unsigned)e0) & 1u) { t6 = 2u; z6 = (double)((((a0[i0 & 3u] % (u2 | 1u)) >> (a0[u1 & 3u] & 31u))) & 255u); } if (((unsigned)e0) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                c0 = (unsigned char)(unsigned)(v0 == (unsigned)c0);
                break; (void)((0xffffffffu / ((unsigned)e0 | 1u)));
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)(unsigned)((short)r0.y > (signed char)3u), m0, (0xffffffffu + u2)); }
        u3 ^= 0x80000000u;
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(u3 || 9u), ((unsigned)e0 % ((unsigned)w0 | 1u)), (unsigned)f0); }
        i0 = ((unsigned)(1u || ((unsigned)w0 | i1)) << (r0.y & 31u)) & 15u;
    }
    { unsigned t7; double z7; if ((fuel) & 1u) { t7 = ((unsigned)s0 ^ (unsigned)(x0 >> 70)); z7 = (double)((0x10000u) & 255u); } if ((fuel) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
        if ((g1 % ((g0 / ((unsigned)w0 | 1u)) | 1u))) goto L1;
        r0.y ^= (unsigned)((unsigned)((int)(a0[u1 & 3u] - u0) >= (int)(unsigned)c1) && (unsigned)(p1 < (unsigned)c0));
        u1 += a0[i0 & 3u];
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    u1 = ((unsigned)l0 - v0);
    *q0 += (unsigned)((unsigned)(0xaec78762u && 2u) && ((unsigned)x0 & garr[u2 & 7u]));
    *q0 = ~(unsigned)((unsigned)((short)(i1 * 0x16360c5au) > (signed char)(unsigned)s1) < (r0.y - u2));
    while (i0++ < 2u && 5u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)g1 < (int)(unsigned)(short)(unsigned)(garr[i1 & 7u] && fuel))) {
            i1 = (unsigned)(short)(m0 / (((2u & *q0) * -(unsigned)((int)0u < (int)v0)) | 1u)) & 15u;
            u3 ^= (((unsigned)c0 << (g0 & 31u)) << (p2 & 31u));
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(w0 >> 29), a0[i0 & 3u], (unsigned)(short)(unsigned)((int)p0 < (int)0u)); }
            c0 = (unsigned char)(unsigned)(unsigned char)(9u | (r0.y ^ ((r0.y | u3) | (unsigned)(w0 >> 29))));
        } else {
            *mp = 0x80000000u;
            if ((unsigned)(unsigned char)((unsigned)(w0 >> 29) + u1)) continue;
        }
        s1 = (int)((unsigned)s1 + ((unsigned)(signed char)(unsigned)(m0 == 0x8bfb6ce4u) * garr[u2 & 7u]));
        b0 = ((6u / (p1 | 1u)) * (unsigned)s0) != 0u;
        if ((5u >> ((unsigned)(x0 >> 70) & 31u))) {
            u2 = u2 * 0x9e3779b1u + ((unsigned)h0 | (unsigned)((unsigned)((int)0x80000000u >= (int)0x35495c9bu) < p2));
        } else {
            l0 = (long)((unsigned long)l0 + ((unsigned)h1 - ((unsigned)((unsigned)h0 == (unsigned)h1) ^ (unsigned)d0)));
            switch ((unsigned)l0 & 7u) {
                L0: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1((0xe8b139fdu ^ 0x293d813eu), (0x20555418u * r0.y), (unsigned)((short)v0 > (signed char)(unsigned)((int)i1 < (int)(unsigned)h0))); }
                goto L1;
            }
            *q0 += (unsigned)((unsigned)((short)(garr[u2 & 7u] - garr[i1 & 7u]) > (signed char)(0x80000000u - 0x856d05f8u)) && v0);
            goto L2;
        }
        l0 = (long)((unsigned long)l0 + (u1 ^ (7u + (unsigned)(0xffffffffu == (unsigned)f0))));
        if ((unsigned)b0) break;
    }
    if ((unsigned)((a0[u1 & 3u] * 0x9dae63f0u) && 0x10000u)) goto L2;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(garr[i1 & 7u] == (0x80000000u / (i2 | 1u))), ((unsigned)s0 % ((u3 | g1) | 1u)), (unsigned)((unsigned)((unsigned)b0 < 3u) < u1)); }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0xffffffffu) continue;
        s0 = (int)0x80000000u;
    }
    v0 = (unsigned)(short)((unsigned)s1 / (-(unsigned)(0x4fbd251du == (u0 << (p1 & 31u))) | 1u));
    while ((0u & p2)) { if (--fuel == 0u) goto done;
        switch (0x75e652a7u & 7u) {
            case 2u: ;
            L1: if (--fuel == 0u) goto done;
            default: ;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                i0 = ((unsigned)w0 - (~((unsigned)(x0 >> 70) & -(p1 - (unsigned)(w0 >> 29))) - 0x80000000u)) & 15u;
                if ((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)c1)) {
                    break; (void)(((unsigned)((int)(unsigned)c0 >= (int)8u) << (g1 & 31u)));
                    q0 = &garr[((unsigned)((int)(unsigned)w0 < (int)((unsigned)s0 - 0x10000u)) | 5u) & 7u];
                } else {
                    u0 = u0 * 0x9e3779b1u + ((unsigned)s1 & (unsigned)(x0 >> 70));
                    if (0x838004fbu) continue;
                    v0 = (4u - (unsigned)((short)(unsigned)(9u && fuel) > (signed char)*mp));
                    if ((unsigned)f0) continue;
                }
            }
        }
        L2: if (--fuel == 0u) goto done;
        if ((fuel & (u3 % (p1 | 1u)))) break;
    }
    u1 += ((unsigned)c1 - a0[u1 & 3u]);
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)a0[u1 & 3u] < (int)u0), (unsigned)(w0 >> 29), (unsigned)h1); }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0xd65120f0u) break;
        u0 = (unsigned)x0;
        if (p2) {
            if (a0[u1 & 3u]) {
                if (0xb0d53320u) break;
                w0 ^= (unsigned long long)u0 << (((unsigned)b0 / (((0x533e4d87u << (a0[i0 & 3u] & 31u)) & u3) | 1u)) & 63u);
                while (i1++ < 5u && 0x7bf81543u) { if (--fuel == 0u) goto done;
                    if ((5u | (unsigned)c0)) {
                        if ((unsigned)!((unsigned)h0 * m0)) break;
                        if (i0) break;
                        L3: if (--fuel == 0u) goto done;
                    }
                    l0 = (long)((unsigned long)l0 + (unsigned)(((u0 & (unsigned)l0) + r0.y) < u2));
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(w0 >> 29), (unsigned)((int)fuel >= (int)((unsigned)h0 / ((unsigned)d0 | 1u))), ((unsigned)c0 ? v0 : *q0)); }
                }
                d0 = d0 * 0.5 + (double)((unsigned)(short)(0x10000u ^ u1) & 1023u);
            } else {
                break; (void)((unsigned)(fuel || (unsigned)(0x7fffffffu < (unsigned)f0)));
                if ((4u ^ (fuel - (unsigned)(w0 >> 29)))) goto L4;
                do { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        continue; (void)((((unsigned)c1 >> (g0 & 31u)) + 6u));
                        if (-(0xffffffffu ? 0x31d9d82fu : a0[i0 & 3u])) {
                            break; (void)((-(0x552cd7cau / (r0.y | 1u)) >> (1u & 31u)));
                            w0 ^= (unsigned long long)(7u & *q0) << ((u1 << (0xffffffffu & 31u)) & 63u);
                        } else {
                            goto L4;
                            r0.x = 0x68c2ab37u;
                            goto done;
                            if (((unsigned)f0 | ((unsigned)h1 ^ 7u))) goto L3;
                        }
                        f0 = f0 * 0.5f + (float)((0u << (0x881f0e4bu & 31u)) & 255u);
                        m0 ^= (unsigned)!(unsigned)(0x7fffffffu == *q0);
                    } while (i2++ < 2u && (unsigned)d0);
                    r0.y ^= ((i0 * garr[u2 & 7u]) % (((unsigned)h0 * (a0[u1 & 3u] ^ 0x249a5298u)) | 1u));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((3u & (i1 + (unsigned)w0)), u2, m0); }
                    h0 = (short)((unsigned)h0 / (a0[u1 & 3u] | 1u));
                } while (i1++ < 6u && (8u / (p0 | 1u)));
                if ((unsigned)((int)(2u * (unsigned)b0) < (int)(unsigned)l0)) {
                    continue; (void)(~(u0 << ((unsigned)(x0 >> 70) & 31u)));
                    if ((unsigned)(garr[u2 & 7u] || 0x10000u)) goto L2;
                    c1 = (signed char)((unsigned)((int)((unsigned)h1 + u1) < (int)0xd59eb241u) + (unsigned)s1);
                    if ((u2 | ((unsigned)d0 & 0x1df4443cu))) {
                        L4: if (--fuel == 0u) goto done;
                        u3 += (unsigned)x0;
                        *q0 = ((unsigned)c0 >> (g0 & 31u));
                        if ((0x7fffffffu << ((u3 - i1) & 31u))) break;
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(r0.x, (9u & u2), (unsigned)(0xc791d522u || (a0[i0 & 3u] | (unsigned)f0))); }
                }
            }
            *q0 = (unsigned)((int)0x9873d2e6u >= (int)0x8334d782u);
            a0[(unsigned)h0 & 3u] = ((unsigned)h1 | (unsigned)l0);
            h0 = (short)(unsigned)(w0 >> 29);
            d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)b0 << (0xc5a9d29eu & 31u)) < p2) & 1023u);
            break; (void)(((unsigned)h0 + u3));
        }
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)x0 / (r0.y | 1u)), (u0 - *q0), 0x4c923a59u); }
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(x0 >> 70), 7u, (unsigned)(u2 || 0xffffffffu)); }
            if (fuel < 8u) return (unsigned)((short)(unsigned)h1 > (signed char)u0);
            c0 = (unsigned char)((unsigned)!(p2 % ((i2 % (2u | 1u)) | 1u)) >> (p1 & 31u));
            c0 = (unsigned char)-(unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)c1);
            w0 ^= (unsigned long long)(unsigned)c1 << ((unsigned)((int)(unsigned)l0 < (int)0x10000u) & 63u);
        } while (i1++ < 3u && ((6u & m0) & (unsigned)s1));
        v0 = (unsigned)((unsigned)(0x80000000u && u0) && (u2 - 2u));
    }
    while (i0++ < 7u && (unsigned)(u0 < u2)) { if (--fuel == 0u) goto done;
        *mp = (unsigned)f0;
        garr[(i0 | i1) & 7u] = (unsigned)(0xffffffffu == (unsigned)(x0 >> 70));
        break; (void)((unsigned)((unsigned)((int)u0 < (int)(unsigned)f0) || 0x80000000u));
        u0 = u0 * 0x9e3779b1u + (fuel + (unsigned)s0);
        if ((unsigned)(*mp && 8u)) break;
        r0.y ^= ((unsigned)((int)(unsigned)w0 >= (int)r0.y) >> ((unsigned)((int)(unsigned)f0 < (int)(unsigned)(0x10000u == a0[u1 & 3u])) & 31u));
    }
    if ((unsigned)x0) goto L0;
    u1 += ~(0u >> (u3 & 31u));
    a0[(unsigned)((int)g0 < (int)(unsigned)b0) & 3u] = ~(((i0 << (0xffffffffu & 31u)) ? *mp : fuel) % ((unsigned)s1 | 1u));
    m0 ^= 2u;
    if ((unsigned)((unsigned)h1 == (*q0 * u1))) goto done;
    l0 = (long)((unsigned long)l0 + (unsigned)((short)(unsigned)((a0[u1 & 3u] << (0x2b77d04fu & 31u)) == (unsigned)f0) > (signed char)i1));
    goto done;
    if (((unsigned)c0 ^ fuel)) goto L4;
    if ((unsigned)(unsigned char)(unsigned)((int)fuel >= (int)(unsigned)((int)4u < (int)v0))) goto L1;
    garr[(unsigned)(0xffffffffu < (unsigned)h0) & 7u] = (0xf14b5b34u ? (unsigned)((unsigned)((short)r0.x > (signed char)(unsigned)b0) && (unsigned)c0) : g1);
    if (((unsigned)c0 << (m0 & 31u))) goto done;
    if (u3 == 7u) return (i0 - (5u >> ((unsigned)c0 & 31u)));
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 = (garr[i1 & 7u] >> ((unsigned)!(i2 >> (u3 & 31u)) & 31u));
        u2 ^= i1;
        d0 = d0 * 0.5 + (double)((unsigned)(2u || (unsigned)((unsigned)s0 && (p1 / ((unsigned)(p2 || 6u) | 1u)))) & 1023u);
        if (((0xffffffffu / ((unsigned)s1 | 1u)) - (unsigned)b0)) goto L0;
        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)b0 || ~((unsigned)((int)fuel >= (int)(0x10000u % (1u | 1u))) ^ p0)) & 1023u);
    }
    *q0 += (unsigned)((int)(garr[u2 & 7u] >> ((unsigned)h0 & 31u)) < (int)(0xcdce67cfu % ((unsigned)(8u == 5u) | 1u)));
    i1 = (p0 + ((unsigned)((unsigned)b0 < 4u) - (unsigned)((unsigned)s0 || 0xb56d35f7u))) & 15u;
    do { if (--fuel == 0u) goto done;
        if ((4u % (a0[i0 & 3u] | 1u))) goto L1;
        if ((unsigned)h0) {
            goto L3;
            switch ((unsigned)f0 & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn1(((0x80896986u * 0x10000u) | p0), fuel, r0.x); }
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (0x9d140c0u % ((unsigned)f0 | 1u));
                    switch (i2 & 7u) {
                        case 3u: ;
                        u2 = (unsigned)((short)(unsigned)c0 > (signed char)(v0 & u1));
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(garr[i1 & 7u] || u3) << (0x7fffffffu & 31u)), fuel, (unsigned)(signed char)(unsigned)((int)(unsigned)h0 < (int)r0.y)); }
                    }
                    c0 = (unsigned char)(a0[i0 & 3u] / ((r0.x << ((0u >> (fuel & 31u)) & 31u)) | 1u));
                    u2 = u2 * 0x9e3779b1u + ((unsigned)((unsigned)((int)p0 >= (int)*mp) < (unsigned)c1) >> ((unsigned)(x0 >> 70) & 31u));
                    if (u3 == 7u) return ((i1 ^ r0.y) << ((unsigned)(signed char)(~(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)e0) >> (g1 & 31u)) & 31u));
                }
                h1 = (unsigned short)(h1 + (unsigned)!((g1 % ((unsigned)x0 | 1u)) >> (0xffffffffu & 31u)));
                while (i1++ < 2u && (unsigned)!(unsigned)((unsigned)l0 || ((unsigned)s1 + p1))) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)(0x5b5ed9f0u || (unsigned)((int)p2 >= (int)(0x6d57ee07u | u2))) & 1023u);
                    if ((7u & (unsigned)(a0[i0 & 3u] || (unsigned)(w0 >> 29)))) {
                        i0 = (a0[u1 & 3u] | (unsigned)((int)0xf6e5fd0cu >= (int)8u)) & 15u;
                        if (-(unsigned)((int)(g0 >> (0xffffffffu & 31u)) >= (int)0xffffffffu)) goto L4;
                        do { if (--fuel == 0u) goto done;
                            u3 ^= ((unsigned)((short)m0 > (signed char)garr[i1 & 7u]) & (garr[i1 & 7u] % ((*q0 * u2) | 1u)));
                            u0 += (unsigned)(0x5f91d896u == (unsigned)((short)0u > (signed char)(unsigned)h1));
                            h0 = (short)(0x2f3b0882u | (unsigned)l0);
                            if ((m0 | (unsigned)l0)) break;
                        } while (i2++ < 4u && garr[i1 & 7u]);
                        case 2u: ;
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn1(-(((unsigned)e0 & p1) << ((unsigned)h1 & 31u)), (unsigned)((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)(w0 >> 29)) == i1), i1); }
                    u1 += ((unsigned)b0 * (unsigned)(i2 || 0xb20a0eb2u));
                }
            }
            { unsigned t0; double z0; if ((((garr[u2 & 7u] % (0x10000u | 1u)) - u2)) & 1u) { t0 = (unsigned)f0; z0 = (double)(((0xea974e29u | a0[u1 & 3u])) & 255u); } if ((((garr[u2 & 7u] % (0x10000u | 1u)) - u2)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                w0 ^= (unsigned long long)(unsigned)(w0 >> 29) << ((unsigned)(unsigned char)(unsigned)((a0[u1 & 3u] ? u1 : 0x6ebd6becu) == (unsigned)x0) & 63u);
            }
            c0 = (unsigned char)(((unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)h1) - (unsigned)f0) + (unsigned)(0xe2e8fbbau == 6u));
            u2 ^= (unsigned)((int)(i0 ^ 6u) < (int)0x80000000u);
            if (budget != 0u) { budget -= 1u; u1 = fn1(i2, (a0[u1 & 3u] * (unsigned)f0), (unsigned)((unsigned)(a0[i0 & 3u] && 0x10000u) || (unsigned)s1)); }
        } else {
            if (budget != 0u) { budget -= 1u; u3 = fn0(0xaa333bc8u, (4u + (i1 ^ 4u)), ((unsigned)d0 >> (p2 & 31u))); }
        }
    } while (i0++ < 4u && (r0.y - (unsigned)((unsigned)s0 == garr[u2 & 7u])));
    if (fuel < 8u) return (unsigned)((int)fuel >= (int)((unsigned)s0 * 0x80000000u));
    u1 = ((unsigned)(unsigned char)((unsigned)(w0 >> 29) ^ m0) - a0[i0 & 3u]);
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((v0 ^ garr[u2 & 7u])) goto L4;
            if (fuel < 8u) return ((unsigned)((short)p1 > (signed char)(unsigned)(garr[i1 & 7u] || (unsigned)s1)) + 7u);
        }
        garr[(unsigned)((int)0x64441b31u >= (int)garr[i1 & 7u]) & 7u] = 0xffffffffu;
        a0[i1 & 3u] = ((unsigned)(u1 == 0x722c7a44u) ^ 5u);
        if ((unsigned)x0) break;
        if (-(((unsigned)h1 - 0x80000000u) << (i2 & 31u))) {
            *q0 += (g1 + (u0 ^ garr[u2 & 7u]));
            switch (p2 & 7u) {
                w0 ^= (unsigned long long)0x13fb1dfeu << (0xffffffffu & 63u);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(x0 >> 70), (u0 | (unsigned)(0x80000000u < 0xffffffffu)), a0[i0 & 3u]); }
                do { if (--fuel == 0u) goto done;
                    switch (garr[u2 & 7u] & 7u) {
                        if ((unsigned)!(unsigned)((int)2u >= (int)(unsigned)(signed char)(unsigned)(g1 && g0))) continue;
                        { unsigned t1; double z1; if ((garr[u2 & 7u]) & 1u) { t1 = ((unsigned)e0 % (1u | 1u)); z1 = (double)((u0) & 255u); } if ((garr[u2 & 7u]) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((short)(unsigned)h1 > (signed char)g1), m0, (unsigned)b0); }
                            if (((unsigned)!((unsigned)c0 + 7u) - r0.x)) break;
                            c1 = (signed char)~(unsigned)((short)(unsigned)(u3 == 0xbce8f5bu) > (signed char)(0xffffffffu % (p0 | 1u)));
                            case 5u: ;
                            q0 = &garr[6u & 7u];
                        }
                        for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                            g1 += (0x2f6eeb81u ? ((unsigned)c0 * (unsigned)h0) : (2u | 3u));
                            case 6u: ;
                            h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)((short)0x10000u > (signed char)(unsigned)(v0 && 0x3a1aca8eu)) > (signed char)garr[u2 & 7u]));
                            r0.y ^= ((unsigned)c1 << (0x7fffffffu & 31u));
                            s1 = (int)((unsigned)s1 + (0x10000u | 0x7fffffffu));
                        }
                        do { if (--fuel == 0u) goto done;
                            if ((unsigned)f0) goto L2;
                            if ((unsigned)((m0 / (0x4c85027au | 1u)) && (unsigned)b0)) break;
                            r0.x = ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(short)((unsigned)c1 - 0x7fffffffu)) * *mp);
                        } while (i2++ < 5u && (unsigned)s1);
                        garr[(9u ^ g1) & 7u] = (unsigned)((int)(unsigned)h0 >= (int)(unsigned)((short)0xffffffffu > (signed char)((unsigned)(x0 >> 70) & (unsigned)s0)));
                        u1 = u1 * 0x9e3779b1u + *mp;
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)((unsigned)(w0 >> 29) == (unsigned)l0) == garr[i1 & 7u]), r0.y, (unsigned)h1); }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0x7854f372u < 0x8312a686u), (unsigned)w0, (unsigned)(u0 && ((unsigned)b0 << ((unsigned)c1 & 31u)))); }
                } while (i1++ < 5u && -((unsigned)(g0 < g1) & (unsigned)(w0 >> 29)));
                for (;;) { if (--fuel == 0u) goto done;
                    if (~(unsigned)((int)r0.y < (int)(unsigned)((unsigned)c0 == garr[i1 & 7u]))) break;
                }
                u1 += (6u - (unsigned)s0);
            }
        } else {
            if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)h1 & (unsigned)s1), (u1 % (0xc018586cu | 1u)), (*mp * (unsigned)(5u == (unsigned)c1))); }
            break; (void)(~(unsigned)((int)0x812f9c7u < (int)0x8081a071u));
            if (budget != 0u) { budget -= 1u; u1 = fn0(u3, (unsigned)((int)r0.y >= (int)0x4aed89a4u), v0); }
        }
        u0 += (unsigned)((unsigned)s1 == r0.x);
    }
    { unsigned t2; double z2; if (((unsigned)(signed char)(unsigned)(garr[u2 & 7u] == (unsigned)(0x44bf8a7fu == (unsigned)b0))) & 1u) { t2 = g1; z2 = (double)((u3) & 255u); } if (((unsigned)(signed char)(unsigned)(garr[u2 & 7u] == (unsigned)(0x44bf8a7fu == (unsigned)b0))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        a0[(unsigned)(0xffffffffu == 0x80000000u) & 3u] = (0x9a337128u + (unsigned)(fuel == (unsigned)((int)(unsigned)b0 < (int)0xffffffffu)));
    }
    h1 = (unsigned short)(h1 + (unsigned)!(v0 & *q0));
    if (fuel < 8u) return (((m0 | v0) / ((unsigned)(x0 >> 70) | 1u)) >> ((unsigned)f0 & 31u));
    if (((unsigned)((unsigned)c1 || u2) ^ u0)) goto L2;
    x0 = x0 * 0x100000001b3ull + p2;
    goto L1;
    if (p1) {
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1(a0[i0 & 3u], 0xb0efe542u, (g0 * 6u)); }
            if (((unsigned)(fuel < p1) % (0u | 1u))) {
                break; (void)((0x4e6babcu << (m0 & 31u)));
                d0 = d0 * 0.5 + (double)(((r0.x | garr[u2 & 7u]) << ((0x72bb8b1du / (0xffffffffu | 1u)) & 31u)) & 1023u);
                continue; (void)((unsigned)c1);
                v0 = u3;
                goto L4;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)(short)(p0 / (garr[u2 & 7u] | 1u)) == u1), (unsigned)((unsigned)(short)(u2 << ((unsigned)s0 & 31u)) && (unsigned)c1), 1u); }
            }
            garr[((unsigned)s0 | (unsigned)d0) & 7u] = ((1u - 0x15518c8au) | (g0 & 0x80000000u));
            r0.x = -(p2 / (a0[i0 & 3u] | 1u));
            if (budget != 0u) { budget -= 1u; u3 = fn1(4u, p0, (9u * u3)); }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t3; double z3; if ((((unsigned)c1 ^ (unsigned)(a0[u1 & 3u] && 0xffffffffu))) & 1u) { t3 = i2; z3 = (double)(((unsigned)((int)(unsigned)w0 >= (int)a0[i0 & 3u])) & 255u); } if ((((unsigned)c1 ^ (unsigned)(a0[u1 & 3u] && 0xffffffffu))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                        while (i0++ < 4u && ((unsigned)l0 & 0x100e04e5u)) { if (--fuel == 0u) goto done;
                            goto L1;
                            if ((garr[i1 & 7u] | (a0[i0 & 3u] * garr[i1 & 7u]))) goto done;
                            s0 = (int)(unsigned)c0;
                        }
                        u2 ^= 0x10000u;
                        switch ((*mp << (a0[u1 & 3u] & 31u)) & 7u) {
                            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)i0 >= (int)(g0 & fuel)), 0x26275596u, fuel); }
                            case 4u: ;
                            w0 = w0 * 6364136223846793005ull + (unsigned)(i1 && (5u - garr[u2 & 7u]));
                            case 5u: ;
                            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(0xff435c46u && (2u >> (0u & 31u))), v0, (unsigned)(short)((unsigned)l0 | 0x10000u)); }
                        }
                        break; (void)(0xffffffffu);
                    }
                    q0 = &garr[(-(p0 ^ 0x10000u) + m0) & 7u];
                }
                f0 = f0 * 0.5f + (float)(((unsigned)(x0 >> 70) / ((unsigned)!((unsigned)d0 ? (unsigned)f0 : 0xffffffffu) | 1u)) & 255u);
                if (0x80000000u) continue;
                i2 = ((unsigned)((int)*mp >= (int)(unsigned)f0) + 0x10000u) & 15u;
                if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)(short)(unsigned)(m0 == 0xad2fa109u) << (u2 & 31u)), (unsigned)c0, m0); }
            }
        } while (i0++ < 3u && (unsigned)((short)(unsigned)h1 > (signed char)(a0[u1 & 3u] & (unsigned)b0)));
        if ((unsigned)((int)0xd55e10ecu < (int)garr[i1 & 7u])) {
            c1 = (signed char)(unsigned)d0;
            goto L3;
            d0 = d0 * 0.5 + (double)(2u & 1023u);
        }
        switch (0x80000000u & 7u) {
            c0 = (unsigned char)((unsigned)((int)i1 < (int)(unsigned)((int)(unsigned)x0 >= (int)3u)) << ((unsigned)!((unsigned)(x0 >> 70) >> (0x7fffffffu & 31u)) & 31u));
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(p2 == 6u)) break;
                { unsigned t4; double z4; if ((0u) & 1u) { t4 = *q0; z4 = (double)((0x80000000u) & 255u); } if ((0u) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                    q0 = &garr[((i2 + 0x34620fc4u) << (0xa8f99831u & 31u)) & 7u];
                    v0 = (unsigned)((int)(u2 + (unsigned)c1) < (int)0xffffffffu);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1(~(unsigned)(i2 < 0xffffffffu), (i2 + (unsigned)s0), a0[u1 & 3u]); }
                if ((r0.y | a0[u1 & 3u])) {
                    case 0u: ;
                    case 4u: ;
                    a0[(g0 % ((unsigned)l0 | 1u)) & 3u] = (((unsigned)s0 + 0x80000000u) ^ r0.y);
                } else {
                    default: ;
                    g1 += (unsigned)((unsigned)(0x10000u == (unsigned)e0) == (unsigned)((unsigned)h0 < 0x7fffffffu));
                    a0[p2 & 3u] = (unsigned)((short)0x34ec6c26u > (signed char)(i1 << (0xa427bfd2u & 31u)));
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(g1 && 5u), (r0.x - 5u), 0x10000u); }
            }
            if (((unsigned)h1 ^ (garr[i1 & 7u] & r0.y))) goto L3;
        }
        g1 += (p2 - ((unsigned)c1 % (0x6a3f709cu | 1u)));
        while (garr[i1 & 7u]) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)0x63979d57u > (signed char)((unsigned)(x0 >> 70) * (unsigned)f0)), (unsigned)(unsigned char)((unsigned)(0x47703ad1u < (unsigned)(x0 >> 70)) % ((unsigned)x0 | 1u)), 0x45d30d6au); }
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)e0 - 0xffffffffu)) {
                    if ((unsigned)(w0 >> 29)) break;
                    if (((i2 - p0) & (unsigned)c1)) {
                        break; (void)((i2 + 0x7fffffffu));
                        if (budget != 0u) { budget -= 1u; u1 = fn1(((6u & p2) + i2), ((unsigned)l0 | a0[u1 & 3u]), 0x80000000u); }
                        *q0 = ((unsigned)(((unsigned)c0 << (u1 & 31u)) == 0x5d021d67u) + (unsigned)(x0 >> 70));
                    }
                    if ((6u ^ 0x10000u)) break;
                    r0.y ^= (unsigned)((unsigned)((unsigned)!((unsigned)c1 ? g0 : i0) || 0x28abb32fu) < *q0);
                }
                break; (void)((*q0 + (u2 * (unsigned)s0)));
                g1 += (u0 ? 8u : (unsigned)(0x80000000u || (unsigned)c0));
            }
        }
    }
    switch ((unsigned)((short)0x8b77a8e0u > (signed char)garr[u2 & 7u]) & 7u) {
        case 7u: ;
        a0[(unsigned)l0 & 3u] = (unsigned)(-(unsigned)((unsigned)b0 < 0x7fffffffu) && 6u);
        case 4u: ;
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(w0 >> 29), (3u + 4u), (0x80000000u / (9u | 1u))); }
        case 5u: ;
    }
    r0.y ^= (unsigned)((unsigned)h1 < (unsigned)c0);
    goto L2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while (i0++ < 5u && 0x6f59fdbdu) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)(garr[u2 & 7u] && ~((unsigned)s1 ? 0x10000u : 0x30aa78aeu)) & 1023u);
        goto L3;
    }
    if (((unsigned)s1 / (8u | 1u))) goto done;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)((int)0x80000000u < (int)(unsigned)((int)p1 >= (int)0x41540d0u));
        h1 = (unsigned short)(h1 + (unsigned)(*mp || (p1 - (2u * 0x80000000u))));
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            continue; (void)(0u);
            switch ((unsigned)(w0 >> 29) & 7u) {
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn2((0x6a09015eu >> (p1 & 31u)), (r0.x + *q0), 7u); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((u1 ^ a0[i0 & 3u]), (unsigned)(signed char)((unsigned)(i2 || 0xb52e8222u) / (v0 | 1u)), u2); }
                } while (i2++ < 4u && 0x80000000u);
            }
        }
        if ((0x8a1579adu - *mp)) {
            break; (void)(u1);
            if (u2) {
                L0: if (--fuel == 0u) goto done;
                if (((unsigned)s0 * u1)) break;
                c0 = (unsigned char)((unsigned)h0 >> (a0[i0 & 3u] & 31u));
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(0x80b163f9u || ((unsigned)d0 + u3)), (unsigned)((short)(unsigned)c0 > (signed char)7u), (unsigned)((unsigned)w0 || g1)); }
                if (u3 == 7u) return (unsigned)(u0 && (unsigned)s0);
                c1 = (signed char)(u0 * garr[i1 & 7u]);
            } else {
                *mp = ((unsigned)s0 % ((unsigned)((unsigned)h0 || (unsigned)(0x5f7d5d70u && (unsigned)(x0 >> 70))) | 1u));
                s0 = (int)(unsigned)((a0[i0 & 3u] - (-((unsigned)(x0 >> 70) - 0xa3a25da6u) >> ((unsigned)l0 & 31u))) < a0[u1 & 3u]);
                if (0x96e8d249u) break;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((short)-(unsigned)((int)p0 >= (int)v0) > (signed char)0x10000u), g0, i2); }
        } else {
            switch ((unsigned)(signed char)((0x10000u << (0x10000u & 31u)) >> (0x80000000u & 31u)) & 7u) {
                if ((unsigned)((int)0xffffffffu >= (int)(0x8df8d87au | g1))) goto L0;
            }
            if ((unsigned)h0) break;
        }
    }
    { unsigned t0; double z0; if (((0xffffffffu - (unsigned)(v0 < 2u))) & 1u) { t0 = u1; z0 = (double)((((unsigned)(signed char)(unsigned)((short)0x10000u > (signed char)(unsigned)l0) | *q0)) & 255u); } if (((0xffffffffu - (unsigned)(v0 < 2u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        x0 = x0 * 0x100000001b3ull + (v0 * 9u);
    }
    *mp = (*mp >> (((unsigned)((short)p2 > (signed char)0xb9d12224u) + 0xffffffffu) & 31u));
    switch ((unsigned)((short)8u > (signed char)(unsigned)h0) & 7u) {
        switch ((g1 + 5u) & 7u) {
            if ((p0 ? (unsigned)s1 : (unsigned)c0)) break;
        }
    }
    for (;;) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((*mp >> (p0 & 31u)) & 1023u);
            goto L3;
        } while (i1++ < 4u && (unsigned)(unsigned char)((unsigned)(signed char)(unsigned)((int)garr[i1 & 7u] < (int)*mp) / (r0.y | 1u)));
        continue; (void)(i2);
    }
    if (u3) {
        if (p0) goto L3;
        if ((unsigned)(u2 == (unsigned)(w0 >> 29))) goto L0;
        if (-(unsigned)((short)(unsigned)(0x80000000u == (unsigned)x0) > (signed char)0x3e285ffbu)) {
            if (fuel < 8u) return (unsigned)(signed char)(((p0 >> (0xcdf88f52u & 31u)) - (garr[i1 & 7u] >> (0x7fffffffu & 31u))) + 0x4766fe53u);
            goto done;
            L1: if (--fuel == 0u) goto done;
        }
    }
    goto L0;
    while (i0++ < 3u && (unsigned)(*q0 < ((unsigned)s0 / (r0.y | 1u)))) { if (--fuel == 0u) goto done;
        h0 = (short)(unsigned)((short)(0x26bf58cbu - 1u) > (signed char)0x76d24a2fu);
        h1 = (unsigned short)(h1 + ((unsigned)s0 * (unsigned)h0));
    }
    goto L4;
    if ((unsigned)!(garr[i1 & 7u] % ((unsigned)!(0x10000u & g1) | 1u))) {
        g0 = (unsigned)(signed char)((unsigned)((unsigned)h0 == 3u) % ((unsigned)((short)(unsigned)s1 > (signed char)0x7fffffffu) | 1u));
        v0 = 0x3138a6a2u;
        u3 += (unsigned)f0;
    } else {
        if ((unsigned)h1) goto L4;
    }
    if (r0.x) {
        if (((0x10000u / (*q0 | 1u)) / ((unsigned)h0 | 1u))) {
            m0 ^= i2;
            *q0 = u1;
            if ((unsigned)(w0 >> 29)) goto L1;
            l0 = (long)((unsigned long)l0 + ((fuel << (u1 & 31u)) | 0x915d7476u));
            g0 = (unsigned)((int)(0x4005c652u - (unsigned)(unsigned char)(g0 & 0x2ae2503eu)) >= (int)(3u & (unsigned)l0));
        } else {
            while (i0++ < 6u && (unsigned)((short)i2 > (signed char)(unsigned)((short)r0.y > (signed char)*mp))) { if (--fuel == 0u) goto done;
                L2: if (--fuel == 0u) goto done;
                s0 = (int)i2;
                e0 = e0 * 0.5L + (long double)(((unsigned)(x0 >> 70) >> ((0x7fffffffu & (unsigned)b0) & 31u)) & 1023u);
            }
            w0 = w0 * 6364136223846793005ull + (fuel & (unsigned)((r0.y & 2u) < (u3 & fuel)));
            if (((unsigned)c1 ? (unsigned)x0 : 2u)) {
                if (budget != 0u) { budget -= 1u; u0 = fn2(g1, (0x80000000u >> ((p0 + 0xb8d97568u) & 31u)), (unsigned)(unsigned char)(0xb998e8a0u / (0x34cc86au | 1u))); }
                c1 = (signed char)((unsigned)e0 / ((unsigned)s1 | 1u));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)0xb807d4f3u < (int)((unsigned)w0 >> ((unsigned)l0 & 31u))), u3, p2); }
        }
        l0 = (long)((unsigned long)l0 + ((unsigned)l0 & (m0 / ((i0 % ((unsigned)((int)p0 < (int)1u) | 1u)) | 1u))));
        { unsigned t1; double z1; if (((unsigned)(a0[i0 & 3u] && (unsigned)d0)) & 1u) { t1 = ((9u | *q0) * (unsigned)c0); z1 = (double)(((unsigned)!(unsigned)((0xffffffffu >> (i0 & 31u)) == (unsigned)e0)) & 255u); } if (((unsigned)(a0[i0 & 3u] && (unsigned)d0)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            if (-(p1 ^ (unsigned)(x0 >> 70))) {
                *q0 += (u0 - (0xb4afca49u - m0));
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((r0.y | r0.y), (garr[i1 & 7u] & (unsigned)((unsigned)c0 == u1)), (unsigned)(short)(unsigned)((unsigned)h0 == (p2 ^ v0))); }
                    u3 += 9u;
                    w0 ^= (unsigned long long)((unsigned)b0 + p1) << ((unsigned)(unsigned char)((unsigned)d0 * (unsigned)(short)((unsigned)((unsigned)h0 && u2) >> (3u & 31u))) & 63u);
                    g0 = (unsigned)((int)p2 >= (int)(unsigned)(signed char)(v0 | (unsigned)x0));
                    if ((g0 * (unsigned)b0)) goto L1;
                    do { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (unsigned)((g1 | (g0 >> (v0 & 31u))) < ((unsigned)c1 & 0x80000000u)));
                    } while (i1++ < 4u && (unsigned)h1);
                } while (i0++ < 2u && 0x7442c712u);
            }
            if (~(6u + a0[i0 & 3u])) goto done;
            r0.y ^= ((g0 ^ 0x71322362u) / ((unsigned)(garr[i1 & 7u] && (p2 / (0x7fffffffu | 1u))) | 1u));
            if (budget != 0u) { budget -= 1u; u2 = fn2((v0 ^ (0x7fffffffu | a0[u1 & 3u])), (unsigned)((unsigned)w0 < (i2 % ((unsigned)w0 | 1u))), (unsigned)(unsigned char)((u1 % ((unsigned)(w0 >> 29) | 1u)) >> (p0 & 31u))); }
        }
        v0 = (((unsigned)c1 % ((unsigned)((unsigned)x0 || 0x6f881c19u) | 1u)) * (v0 >> (*mp & 31u)));
        switch ((unsigned)(0u == a0[u1 & 3u]) & 7u) {
            u3 = u3 * 0x9e3779b1u + (u0 ? 0x80000000u : (0xffffffffu * 0x10000u));
            L3: if (--fuel == 0u) goto done;
            case 3u: ;
        }
        if (0x7fffffffu) {
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                switch ((unsigned)((int)0x8fed472u < (int)garr[u2 & 7u]) & 7u) {
                    r0.y ^= 0x10000u;
                    i1 = 0xffffffffu & 15u;
                    m0 ^= garr[u2 & 7u];
                    if (budget != 0u) { budget -= 1u; u1 = fn1(0xdf5ab1e4u, (0x3d9882dbu ^ (unsigned)d0), p2); }
                }
                switch (0xdc61ba5au & 7u) {
                    if (fuel < 8u) return (unsigned)((int)i0 < (int)((unsigned)(g0 || 0x10000u) % (*mp | 1u)));
                }
                break; (void)((unsigned)((int)(unsigned)h0 < (int)p2));
            }
        } else {
            switch (i1 & 7u) {
                L4: if (--fuel == 0u) goto done;
            }
            goto L4;
            if (((unsigned)d0 >> ((unsigned)e0 & 31u))) goto L2;
            if ((unsigned)(0xd5dfae8au && 9u)) {
                a0[i2 & 3u] = (unsigned)((unsigned)(unsigned char)(unsigned)(7u < 0xc3fa51d7u) < ((unsigned)((int)(unsigned)c1 < (int)a0[u1 & 3u]) - i1));
                h0 = (short)(unsigned)(signed char)((unsigned)((int)p1 < (int)p0) + (unsigned)(6u < (unsigned)(w0 >> 29)));
                if (((unsigned)d0 + 0x7fffffffu)) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0(a0[u1 & 3u], (p0 / ((unsigned)f0 | 1u)), 5u); }
                }
            } else {
                if (~((unsigned)((unsigned)h1 || (unsigned)s0) + *mp)) goto L0;
            }
        }
    } else {
        while (i0++ < 6u && 5u) { if (--fuel == 0u) goto done;
            if ((p2 * (unsigned)x0)) goto done;
            c1 = (signed char)r0.y;
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)b0 - g1), 0x8e2da502u, (unsigned)((short)0x5ed052afu > (signed char)(unsigned)h1)); }
            g1 += (r0.x / ((p0 * i2) | 1u));
            if ((8u ^ 8u)) continue;
            a0[(unsigned)(short)(unsigned)((short)m0 > (signed char)g0) & 3u] = (((unsigned)((int)0x9b54776fu >= (int)u0) + 7u) + ~(p1 ^ (unsigned)s1));
        }
        { unsigned t2; double z2; if ((fuel) & 1u) { t2 = ((unsigned)s0 / (0x3c397bc2u | 1u)); z2 = (double)(((unsigned)!((g1 - r0.x) / (p0 | 1u))) & 255u); } if ((fuel) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            if (u1) goto L3;
            if ((((unsigned)d0 - 0xffffffffu) - 6u)) goto L2;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)b0, (u1 << ((0x7fffffffu / ((unsigned)c1 | 1u)) & 31u)), ((unsigned)x0 / ((unsigned)((short)i2 > (signed char)i2) | 1u))); }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn2(((9u | g1) * 0xc0cb985eu), (unsigned)(short)(a0[i0 & 3u] ^ u2), (unsigned)b0); }
                m0 ^= 0x10000u;
                if ((*q0 * (unsigned)b0)) break;
                i0 = 0x5d6ef65u & 15u;
            } while (i0++ < 4u && (0x6bad70fau * 0x10000u));
            u3 += (unsigned)((short)p1 > (signed char)((unsigned)c0 - 0u));
        }
        h1 = (unsigned short)(h1 + 0xffffffffu);
    }
    d0 = d0 * 0.5 + (double)(((unsigned)s0 ? 7u : r0.y) & 1023u);
    switch (((unsigned)h1 | p2) & 7u) {
        u0 += (i2 / (((unsigned)((unsigned)w0 || 0x10000u) + (unsigned)e0) | 1u));
        goto L4;
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((u0 >> ((unsigned)(p2 < i1) & 31u))) {
                garr[(unsigned)(r0.y && 8u) & 7u] = ((unsigned)((int)((unsigned)(x0 >> 70) >> (~(garr[u2 & 7u] % (0x10000u | 1u)) & 31u)) >= (int)0x2cc15c26u) * (unsigned)h1);
                c0 = (unsigned char)(unsigned)!((unsigned)s1 ? (unsigned)(short)(a0[i0 & 3u] << ((unsigned)f0 & 31u)) : (unsigned)h0);
                u1 = (((unsigned)((short)(unsigned)c1 > (signed char)0x7fffffffu) % (*q0 | 1u)) | r0.x);
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (i1 ? 0xcd90b197u : 0u) != 0u;
                    if ((unsigned)((int)(unsigned)(*mp && 0u) >= (int)(unsigned)b0)) break;
                }
            }
            q0 = &garr[i2 & 7u];
        }
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((p2 - (unsigned)(x0 >> 70))) break;
        if (budget != 0u) { budget -= 1u; u0 = fn1((v0 ^ *q0), (unsigned)(i2 && (unsigned)(g1 == (unsigned)h1)), ((unsigned)h1 / (0x3789e32eu | 1u))); }
        d0 = d0 * 0.5 + (double)((g1 << ((unsigned)h1 & 31u)) & 1023u);
        r0.y ^= -(9u * (unsigned)(a0[u1 & 3u] < 0u));
        q0 = &garr[(((unsigned)(0x9722477bu == garr[u2 & 7u]) - (unsigned)c1) ^ (unsigned)((short)r0.x > (signed char)(unsigned)h1)) & 7u];
        if (((u2 + (unsigned)f0) & fuel)) break;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        while ((unsigned)((unsigned)c0 || (5u >> (i1 & 31u)))) { if (--fuel == 0u) goto done;
            u1 ^= ~(unsigned)(*q0 < 0xa626170au);
            *q0 = (unsigned)((unsigned)((int)u1 >= (int)(0x9816a80au * 0xb90b16dau)) && (garr[i1 & 7u] + 0xb2d491fbu));
            b0 = (unsigned)(short)(unsigned)((p2 - (unsigned)c0) < 0xad372372u) != 0u;
            while ((unsigned)!(unsigned)(0x10000u < ((unsigned)b0 / (0x25405753u | 1u)))) { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)(p2 == (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)(0x10000u || garr[i1 & 7u])));
                }
                if ((0xffffffffu | garr[u2 & 7u])) break;
                h0 = (short)(0x2a2eadecu ? (unsigned)c1 : a0[i0 & 3u]);
                if (budget != 0u) { budget -= 1u; u0 = fn1(*mp, (unsigned)w0, (i0 ^ 0xca766bc5u)); }
                for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn2((p2 / ((unsigned)(6u < (unsigned)f0) | 1u)), 0x33447379u, (unsigned)((int)u3 >= (int)(unsigned)(short)(0xffffffffu - (unsigned)c0))); }
                }
                *q0 += (unsigned)((int)(unsigned)s1 < (int)(g0 >> ((unsigned)((short)2u > (signed char)0x7c607d78u) & 31u)));
            }
            if (-((unsigned)s1 ? 0x80000000u : (unsigned)h1)) goto L0;
        }
        if ((unsigned)f0) {
            if (budget != 0u) { budget -= 1u; u2 = fn1((fuel ? (unsigned)w0 : p1), r0.y, (unsigned)!(v0 << (p2 & 31u))); }
            { unsigned t3; double z3; if ((((0xd87ce7cbu & (unsigned)e0) / (0xffffffffu | 1u))) & 1u) { t3 = ((unsigned)((short)(unsigned)l0 > (signed char)0x7fffffffu) | i2); z3 = (double)((0x8d0a07afu) & 255u); } if ((((0xd87ce7cbu & (unsigned)e0) / (0xffffffffu | 1u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                garr[*mp & 7u] = (0x7fffffffu * a0[i0 & 3u]);
                v0 = (unsigned)((int)(unsigned)((unsigned)(0xfc81b9abu < p1) == (unsigned)d0) >= (int)i0);
            }
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)((short)a0[u1 & 3u] > (signed char)0x10000u) == (unsigned)d0), (unsigned)(w0 >> 29), (unsigned)(unsigned char)(i2 / (fuel | 1u))); }
            h0 = (short)((((unsigned)l0 | (unsigned)d0) & (unsigned)c1) | garr[u2 & 7u]);
            if (budget != 0u) { budget -= 1u; u0 = fn2((0xffffffffu - (m0 / (3u | 1u))), (r0.x ^ (unsigned)d0), (*mp + 1u)); }
            goto L2;
        }
        *mp = (unsigned)((unsigned)d0 < (unsigned)d0);
        m0 ^= a0[i0 & 3u];
        if ((unsigned)e0) break;
    }
    w0 ^= (unsigned long long)(u3 * (unsigned)h0) << (((unsigned)(short)((8u * p1) / (0xf1aa9896u | 1u)) & 1u) & 63u);
    switch (p2 & 7u) {
        h0 = (short)((i0 & (unsigned)c0) * 4u);
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1(-(unsigned)((int)0x612add5fu < (int)4u), (r0.x / ((i2 << (2u & 31u)) | 1u)), u3); }
    a0[(unsigned)s1 & 3u] = (unsigned)(((0xae570fe9u * (unsigned)h0) + (0xbbe0dbc2u + g0)) == i2);
    if ((0xffffffffu ^ 0x80000000u)) goto L4;
    if ((0x40ac3703u % ((unsigned)s0 | 1u))) goto L0;
    if ((unsigned)(unsigned char)(g0 >> (0u & 31u))) goto L1;
    if (((*mp * a0[u1 & 3u]) & p0)) goto L4;
    if ((unsigned)(i0 && a0[u1 & 3u])) goto L1;
    while (i0++ < 7u && (unsigned)((int)(unsigned)c0 < (int)garr[i1 & 7u])) { if (--fuel == 0u) goto done;
        if (0xcde20749u) {
            f0 = f0 * 0.5f + (float)((unsigned)(0x80000000u == (unsigned)(i0 < (unsigned)(a0[i0 & 3u] || 0x2f565b2au))) & 255u);
            e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)((short)(0x10000u ? m0 : 0xde9c32a9u) > (signed char)a0[i0 & 3u]) < (int)(unsigned)w0) & 1023u);
            h0 = (short)(unsigned)((short)(unsigned)d0 > (signed char)(0x9f1c956eu * *q0));
        }
    }
    if ((0xd6a3ffd0u % (i1 | 1u))) {
        h0 = (short)((unsigned)l0 | (garr[u2 & 7u] >> ((unsigned)((short)a0[i0 & 3u] > (signed char)*mp) & 31u)));
        if ((unsigned)(((unsigned)h0 >> ((unsigned)(w0 >> 29) & 31u)) || 2u)) {
            r0.x = (0xffffffffu - ~((unsigned)(unsigned char)((unsigned)d0 >> (u0 & 31u)) >> (5u & 31u)));
            if ((unsigned)b0) goto L2;
            i0 = (((unsigned)c0 ? *mp : garr[i1 & 7u]) >> (i0 & 31u)) & 15u;
            if (m0) {
                if (0xf6958eacu) goto L1;
                u0 += (*q0 / ((unsigned)(unsigned char)(unsigned)((int)((unsigned)w0 >> (p1 & 31u)) >= (int)(unsigned)c1) | 1u));
                goto L3;
                g1 += ((g1 / ((unsigned)f0 | 1u)) + (unsigned)d0);
                if ((unsigned)d0) goto L3;
                *q0 += 0xa66c656fu;
            }
            c0 = (unsigned char)(((unsigned)((unsigned)c0 == g1) / ((unsigned)(0x6629ff4cu < u1) | 1u)) << ((unsigned)(x0 >> 70) & 31u));
        }
        while (i0++ < 4u && ((unsigned)s1 + 0x80000000u)) { if (--fuel == 0u) goto done;
            *q0 += (unsigned)((int)v0 >= (int)(unsigned)d0);
        }
        if (8u) {
            { unsigned t4; double z4; if ((((unsigned)l0 / (u3 | 1u))) & 1u) { t4 = (u0 - p0); z4 = (double)(((unsigned)b0) & 255u); } if ((((unsigned)l0 / (u3 | 1u))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                if (((unsigned)s1 | *q0)) goto done;
                if (((unsigned)((int)p1 >= (int)0x97f3b489u) % (0x175cee47u | 1u))) goto L4;
            }
            if (((g1 & 0x794ae4feu) / ((unsigned)f0 | 1u))) {
                if ((unsigned)((unsigned)(2u == (unsigned)s0) && (unsigned)s1)) {
                    m0 ^= i2;
                    if (((g1 & *q0) ^ 0x10000u)) goto L3;
                    if ((garr[i1 & 7u] * (g0 / ((unsigned)h0 | 1u)))) goto L2;
                } else {
                    if ((unsigned)((unsigned)b0 == 0xffffffffu)) goto L2;
                }
                garr[i0 & 7u] = ((0x9d125c36u / (p1 | 1u)) / ((unsigned)((unsigned)x0 && 0x10000u) | 1u));
                for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)((int)(u0 << ((unsigned)d0 & 31u)) < (int)((0x7fffffffu % (i0 | 1u)) % (garr[u2 & 7u] | 1u)));
                }
                if ((unsigned)(short)(unsigned)((unsigned)(0xffffffffu || (unsigned)b0) && u2)) goto L4;
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    m0 ^= ((unsigned)((unsigned)(w0 >> 29) < (unsigned)(signed char)(p0 - a0[u1 & 3u])) & u1);
                    do { if (--fuel == 0u) goto done;
                        if (((0xffffffffu + u1) >> (g0 & 31u))) break;
                        if (((unsigned)f0 * fuel)) {
                            if ((0xc0b3da11u - 0x1f8f3d1du)) break;
                            if (budget != 0u) { budget -= 1u; u0 = fn0(i1, (0xffffffffu >> ((unsigned)s0 & 31u)), (unsigned)(signed char)((unsigned)((short)1u > (signed char)8u) >> (u2 & 31u))); }
                        } else {
                            *mp = ((unsigned)((int)(unsigned)d0 >= (int)(unsigned)(0x10000u || *q0)) ? garr[u2 & 7u] : 0x80000000u);
                        }
                        c1 = (signed char)(unsigned)(r0.y || 0x16124329u);
                        if ((unsigned)(signed char)((unsigned)c0 - (unsigned)h0)) goto L0;
                        if ((u3 + (garr[i1 & 7u] ^ garr[u2 & 7u]))) break;
                        u2 ^= (unsigned)((*mp % (fuel | 1u)) == (unsigned)(0x80000000u || i2));
                    } while (i1++ < 6u && (5u - (unsigned)(w0 >> 29)));
                    break; (void)((unsigned)!(0xb1090d6u & (unsigned)h0));
                    x0 = x0 * 0x100000001b3ull + ((unsigned)f0 + p2);
                    break; (void)((unsigned)((int)((unsigned)(w0 >> 29) | garr[u2 & 7u]) < (int)garr[u2 & 7u]));
                    b0 = 0xffffffffu != 0u;
                }
            }
            if ((unsigned)c0) {
                if ((i2 - (p2 | a0[i0 & 3u]))) goto L2;
                w0 = w0 * 6364136223846793005ull + (unsigned)(r0.x == (0x10000u * *mp));
                if (((unsigned)h0 << (0xffffffffu & 31u))) goto L3;
                c0 = (unsigned char)((unsigned)(signed char)(unsigned)((short)*mp > (signed char)(unsigned)h1) & (unsigned)!((unsigned)e0 & garr[u2 & 7u]));
            }
            if ((unsigned)((int)p0 >= (int)(unsigned)(g1 && 0x10000u))) goto L4;
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)((int)*mp >= (int)(unsigned)e0) / ((unsigned)w0 | 1u)));
                continue; (void)((unsigned)(fuel == m0));
                if (fuel < 8u) return (unsigned)(signed char)(u2 >> (((unsigned)(w0 >> 29) % (3u | 1u)) & 31u));
                b0 = ((unsigned)s0 & ((unsigned)(p2 == (unsigned)d0) % (g0 | 1u))) != 0u;
            }
        }
        switch ((i1 << ((unsigned)(r0.y == *mp) & 31u)) & 7u) {
            case 2u: ;
            if (((unsigned)x0 * 0xdb06d76eu)) goto L1;
            switch ((unsigned)(signed char)(unsigned)((int)*mp < (int)4u) & 7u) {
                case 4u: ;
            }
            s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)s0));
        }
    }
    if ((unsigned)x0) {
        d0 = d0 * 0.5 + (double)((unsigned)((i2 | 0xffffffffu) < (p1 + 4u)) & 1023u);
        r0.x = (unsigned)((int)i1 >= (int)p2);
        *mp = (6u << ((unsigned)b0 & 31u));
    } else {
        goto done;
        goto L4;
        if ((unsigned)(signed char)((unsigned)((short)r0.x > (signed char)garr[i1 & 7u]) / (a0[u1 & 3u] | 1u))) goto L1;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)b0 || ((unsigned)e0 + u0)), 0x512923e9u, (unsigned)((int)((unsigned)x0 + i2) < (int)(unsigned)e0)); }
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(p0 == (unsigned)c1)) goto L1;
        s1 = (int)((unsigned)s1 + (unsigned)((int)(a0[i0 & 3u] ? (4u % (u2 | 1u)) : r0.y) >= (int)(unsigned)h1));
        b0 = (unsigned)((int)0x10000u >= (int)r0.y) != 0u;
    }
    v0 = ((0xffffffffu / (v0 | 1u)) - (a0[i0 & 3u] % ((unsigned)((unsigned)l0 == v0) | 1u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(0x880f58d5u || fuel)) goto L4;
    goto L2;
    { unsigned t0; double z0; if ((0x80000000u) & 1u) { t0 = ((unsigned)h1 >> (6u & 31u)); z0 = (double)(((unsigned)(w0 >> 29)) & 255u); } if ((0x80000000u) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        r0.y ^= (unsigned)(r0.x || (unsigned)s0);
        c1 = (signed char)(unsigned)(0x7fffffffu && (1u & (unsigned)e0));
        d0 = d0 * 0.5 + (double)(((unsigned)s1 / (((unsigned)(x0 >> 70) ^ (unsigned)h0) | 1u)) & 1023u);
    }
    if (u0) goto L2;
    if (v0) goto L2;
    do { if (--fuel == 0u) goto done;
        switch ((unsigned)((int)(p2 / (p2 | 1u)) >= (int)u0) & 7u) {
            h1 = (unsigned short)(h1 + ((4u % ((unsigned)((int)5u < (int)0x2443f0c5u) | 1u)) + (unsigned)x0));
        }
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)f0 == u0) & 255u);
    } while (i0++ < 7u && 0xffffffffu);
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(0x8ab62989u == u0)) goto L1;
    } while (i0++ < 6u && m0);
    l0 = (long)((unsigned long)l0 + u0);
    { unsigned t1; double z1; if (((unsigned)((short)0x10000u > (signed char)u0)) & 1u) { t1 = (unsigned)(fuel < i0); z1 = (double)(((u1 << (a0[u1 & 3u] & 31u))) & 255u); } if (((unsigned)((short)0x10000u > (signed char)u0)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        L0: if (--fuel == 0u) goto done;
        goto L3;
    }
    { unsigned t2; double z2; if (((unsigned)(*mp < r0.x)) & 1u) { t2 = -(u3 % ((unsigned)s0 | 1u)); z2 = (double)(((unsigned)(u1 || (unsigned)l0)) & 255u); } if (((unsigned)(*mp < r0.x)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        i2 = (unsigned)(short)(unsigned)(u2 && a0[u1 & 3u]) & 15u;
        while (((unsigned)c1 - (u3 ^ 0x10000u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1(u3, (p1 | (unsigned)((short)0x13cd82e5u > (signed char)0x7429e3d3u)), (0xa5ebeb2du % ((unsigned)(u1 < (unsigned)w0) | 1u))); }
            L1: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((p1 ^ 0x7fffffffu), (0xe406f69bu / (garr[u2 & 7u] | 1u)), (unsigned)(6u == (unsigned)(w0 >> 29))); }
            c0 = (unsigned char)(unsigned)(unsigned char)(3u & (unsigned)(0x80000000u == 6u));
            u2 ^= ((unsigned)c0 ? 0x10000u : (unsigned)c0);
        }
        { unsigned t3; double z3; if (((unsigned)((unsigned)((short)i0 > (signed char)(unsigned)h0) || 0xeb404ef4u)) & 1u) { t3 = *q0; z3 = (double)((~(unsigned)((unsigned)e0 && ((unsigned)x0 >> ((unsigned)h1 & 31u)))) & 255u); } if (((unsigned)((unsigned)((short)i0 > (signed char)(unsigned)h0) || 0xeb404ef4u)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            *mp = ((unsigned)x0 + (unsigned)(u0 == 0x1301ffebu));
            if (budget != 0u) { budget -= 1u; u0 = fn3((0xffffffffu + u0), ((unsigned)x0 - 0x60a2aee9u), (unsigned)((0x18bdb693u - (unsigned)l0) && 0x1ef7c09du)); }
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(0x80000000u && *mp), (unsigned)!((unsigned)(a0[u1 & 3u] == (unsigned)x0) | (unsigned)c0), (unsigned)x0); }
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)x0 || (unsigned)((short)(unsigned)(unsigned char)(p1 ^ ((unsigned)h0 % ((unsigned)(x0 >> 70) | 1u))) > (signed char)(unsigned)(w0 >> 29)));
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                L2: if (--fuel == 0u) goto done;
            }
        }
        goto L1;
        { unsigned t4; double z4; if (((unsigned)b0) & 1u) { t4 = (unsigned)((unsigned)((unsigned)(x0 >> 70) || g0) && u3); z4 = (double)(((v0 ? 0x993b3b9u : 5u)) & 255u); } if (((unsigned)b0) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
            h0 = (short)(unsigned)((int)(unsigned)h0 >= (int)(m0 % ((unsigned)d0 | 1u)));
            while (i0++ < 2u && (unsigned)!(unsigned)((short)0xc9a20433u > (signed char)-(unsigned)((int)g0 >= (int)g0))) { if (--fuel == 0u) goto done;
                if ((g1 * (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)c1))) {
                    if (budget != 0u) { budget -= 1u; u1 = fn3(0xd1d9e2bdu, (0x10000u / ((unsigned)f0 | 1u)), ((unsigned)(w0 >> 29) % ((unsigned)!(unsigned)((int)(unsigned)(w0 >> 29) >= (int)0x80000000u) | 1u))); }
                }
                if ((unsigned)(signed char)((1u / (0x49f99464u | 1u)) | u0)) {
                    c0 = (unsigned char)(u2 & (unsigned)((unsigned)l0 || (unsigned)(short)((unsigned)x0 / (r0.x | 1u))));
                    u1 ^= 0xd2b07f83u;
                    do { if (--fuel == 0u) goto done;
                        while (((unsigned)(1u == m0) & (unsigned)h1)) { if (--fuel == 0u) goto done;
                            if (fuel < 8u) return (unsigned)(unsigned char)(unsigned)(8u && g1);
                            v0 = (unsigned)((unsigned)l0 < ((unsigned)f0 & u3));
                            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(u3 == 0x10000u), (8u + fuel), 0xb22ab973u); }
                            r0.y ^= (unsigned)(short)((~(unsigned)((short)m0 > (signed char)m0) | (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)l0)) ^ 0x80000000u);
                        }
                        L3: if (--fuel == 0u) goto done;
                    } while (i1++ < 2u && (unsigned)c1);
                    s0 = (int)0u;
                }
                switch ((unsigned)(r0.y || (unsigned)((unsigned)d0 < i0)) & 7u) {
                    c1 = (signed char)(unsigned)((int)(*q0 >> (0x80000000u & 31u)) < (int)(r0.x << (p1 & 31u)));
                    case 7u: ;
                    { unsigned t5; double z5; if ((((unsigned)((int)0x4993d956u < (int)(unsigned)s0) / (a0[i0 & 3u] | 1u))) & 1u) { t5 = u3; z5 = (double)((fuel) & 255u); } if ((((unsigned)((int)0x4993d956u < (int)(unsigned)s0) / (a0[i0 & 3u] | 1u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                        a0[~(unsigned)(u0 || r0.y) & 3u] = (0x7fffffffu << (g1 & 31u));
                        u3 ^= 0xadd8175u;
                        case 0u: ;
                        s1 = (int)((unsigned)s1 + (unsigned)((int)0xffffffffu < (int)(unsigned)s1));
                        r0.y ^= (unsigned)(signed char)(unsigned)((short)(unsigned)((p1 + i1) == u1) > (signed char)(unsigned)((int)0u < (int)i2));
                    }
                    if (fuel < 8u) return ((unsigned)h1 | *q0);
                }
                i1 = ((unsigned)(signed char)(unsigned)((int)(unsigned)((int)1u < (int)u3) < (int)u2) >> (((unsigned)c1 << ((unsigned)x0 & 31u)) & 31u)) & 15u;
                h1 = (unsigned short)(h1 + (i0 + u2));
                g0 = (unsigned)(unsigned char)(unsigned)((int)((unsigned)s0 >> ((unsigned)(w0 >> 29) & 31u)) < (int)5u);
            }
            if (fuel < 8u) return *q0;
            if (budget != 0u) { budget -= 1u; u3 = fn3((0xbc973b49u | -((unsigned)h1 >> ((unsigned)s1 & 31u))), a0[i0 & 3u], 5u); }
            w0 = w0 * 6364136223846793005ull + (unsigned)s1;
        }
        do { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)!(unsigned)((unsigned)l0 < (p1 / ((unsigned)(unsigned char)((unsigned)(unsigned char)(unsigned)(r0.y || g0) >> (p1 & 31u)) | 1u)));
            if (fuel < 8u) return (*mp / (((5u + (unsigned)s1) >> (u0 & 31u)) | 1u));
            if (v0) break;
        } while (i0++ < 5u && -(unsigned)(*q0 < (i2 - i1)));
    }
    if ((unsigned)!(unsigned)((short)i1 > (signed char)((unsigned)c0 - m0))) goto L1;
    if ((v0 / ((unsigned)f0 | 1u))) goto L2;
    if ((fuel | (unsigned)(garr[u2 & 7u] == p2))) goto L2;
    r0.y ^= (unsigned)(p0 < (*mp - ((u3 / (m0 | 1u)) - r0.y)));
    switch ((unsigned)((int)0xeca678b7u < (int)a0[u1 & 3u]) & 7u) {
        case 6u: ;
        g1 += (unsigned)(a0[u1 & 3u] || (unsigned)(unsigned char)(unsigned)((int)2u < (int)(unsigned)x0));
    }
    u0 += (unsigned)(short)((unsigned)h1 / (0xfd35f192u | 1u));
    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)((int)u3 < (int)r0.x) < (0x10000u | (unsigned)e0));
    L4: if (--fuel == 0u) goto done;
    b0 = (-(unsigned)((int)(unsigned)l0 < (int)4u) ^ (unsigned)x0) != 0u;
    if ((7u ^ (unsigned)(w0 >> 29))) goto L0;
    if (((g1 + a0[i0 & 3u]) & g1)) goto L1;
    if ((unsigned)(m0 && (unsigned)(w0 >> 29))) goto L0;
    for (;;) { if (--fuel == 0u) goto done;
        *mp = (unsigned)(short)((6u ^ u1) - (unsigned)(a0[i0 & 3u] < u1));
        if (~(unsigned)((short)p0 > (signed char)(unsigned)f0)) goto L1;
        m0 ^= ~((unsigned)(0xaad125fu && fuel) << ((p2 * (unsigned)(short)(unsigned)((short)v0 > (signed char)g0)) & 31u));
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            u0 ^= ((unsigned)c1 | (unsigned)(w0 >> 29));
            h1 = (unsigned short)(h1 + 0x10000u);
            if (((unsigned)c0 ^ (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)u0))) break;
        }
        *q0 = (v0 | 0x7fffffffu);
        g1 += ((unsigned)((int)p0 < (int)(0x2fed12dbu + v0)) & (unsigned)((int)(unsigned)b0 < (int)0x7fffffffu));
    }
    goto L1;
    if (a0[u1 & 3u]) {
        if (budget != 0u) { budget -= 1u; u2 = fn2(v0, 4u, (unsigned)((int)(unsigned)h1 >= (int)r0.x)); }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 11u, 0x22f93b9fu, 0x2b632ceu },
        { 3u, 0xec1d9eccu, 0x837d9ea1u },
        { 8u, 0x11daf34du, 0x806caf61u },
        { 4u, 0x43ce0addu, 0x68d58f1au },
        { 2u, 0x960196eu, 0x55f60deu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
