// test-ssa-source's program of seed 134000424 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xcaa50b2du, g1 = 0x28d2af33u;
static unsigned garr[8] = { 0x7fc08b56u, 0x9795f0e9u, 0xd7541042u, 0xf109bfe0u, 0xff49680cu, 0xac0bau, 0xf6e38006u, 0xd93353dfu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L3;
    if ((unsigned)((short)0xbb84cb0fu > (signed char)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)i2))) goto L2;
    f0 = f0 * 0.5f + (float)(((unsigned)d0 >> ((p2 ^ (unsigned)s1) & 31u)) & 255u);
    s1 = (int)((unsigned)s1 + (unsigned)((int)7u < (int)0x80000000u));
    f0 = f0 * 0.5f + (float)(((unsigned)!(unsigned)((unsigned)((short)v0 > (signed char)(unsigned)c0) == g0) / ((0xffffffffu >> (fuel & 31u)) | 1u)) & 255u);
    e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)e0 > (signed char)-((unsigned)((int)(unsigned)w0 >= (int)(unsigned)(w0 >> 29)) << (*q0 & 31u))) & 1023u);
    switch (~(unsigned)((short)u1 > (signed char)((unsigned)b0 & 2u)) & 7u) {
        L0: if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)(((unsigned)e0 | 0x7f0e120bu) & 255u);
        L2: if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + ((unsigned)((int)0xaaf70466u >= (int)g1) | ((unsigned)h0 / (0xffffffffu | 1u))));
    }
    if (((unsigned)h0 % ((unsigned)(0x73b1d006u < (unsigned)c0) | 1u))) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (6u) break;
            break; (void)((unsigned)(7u || (unsigned)x0));
            L3: if (--fuel == 0u) goto done;
        }
        do { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)c0;
            switch ((unsigned)(*q0 < -(unsigned)((int)0x489fdd8eu >= (int)4u)) & 7u) {
                do { if (--fuel == 0u) goto done;
                    L4: if (--fuel == 0u) goto done;
                } while (i1++ < 3u && (unsigned)b0);
                if ((unsigned)c1) break;
            }
            garr[(unsigned)(signed char)(unsigned)(r0.y == 0x10000u) & 7u] = ((unsigned)((short)0x7f5b5c4du > (signed char)p2) & ((unsigned)(w0 >> 29) << (5u & 31u)));
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)((unsigned)h0 == 0x80000000u) && (unsigned)s1)) break;
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((unsigned)((0xfe7e3780u / (a0[i0 & 3u] | 1u)) < garr[i1 & 7u]) & 1023u);
                    do { if (--fuel == 0u) goto done;
                        r0.x = (0x54ac9f3u + 3u);
                        a0[r0.y & 3u] = (g1 - (unsigned)w0);
                        while (i1++ < 7u && (0xa7721f4cu | p2)) { if (--fuel == 0u) goto done;
                            if ((unsigned)(*q0 == u1)) break;
                            if (((unsigned)d0 - i1)) continue;
                            l0 = (long)((unsigned long)l0 + ((0x36cc0fddu << (0x80000000u & 31u)) - (unsigned)((int)fuel >= (int)(unsigned)(x0 >> 70))));
                            if (2u) break;
                            break; (void)(u1);
                        }
                        d0 = d0 * 0.5 + (double)((g0 / ((unsigned)(((v0 % (g1 | 1u)) << (a0[i0 & 3u] & 31u)) < 8u) | 1u)) & 1023u);
                        g0 = p2;
                        *q0 += (m0 / ((unsigned)(5u && 0x7fffffffu) | 1u));
                    } while (i0++ < 6u && (g1 / ((unsigned)w0 | 1u)));
                    if ((u1 + 0xf5c69eu)) break;
                }
                if (((unsigned)c0 & i1)) break;
                if ((0x80000000u / (g0 | 1u))) break;
                u3 = u3 * 0x9e3779b1u + ((unsigned)c0 | 0xd67a5c61u);
            } while (i1++ < 7u && (u2 & i1));
        } while (i0++ < 6u && (unsigned)c0);
    }
    if ((unsigned)((*mp >> ((unsigned)x0 & 31u)) < garr[i1 & 7u])) {
        if (*q0) {
            *q0 += (unsigned)((int)(unsigned)((int)0x80000000u >= (int)u3) < (int)(unsigned)e0);
            m0 ^= (i2 | 0x7fffffffu);
            if (~(((unsigned)f0 & i1) - (unsigned)(w0 >> 29))) goto L1;
            s1 = (int)((unsigned)s1 + garr[u2 & 7u]);
        } else {
            a0[(unsigned)e0 & 3u] = (*q0 - (unsigned)(short)(u2 ^ (unsigned)(unsigned char)((unsigned)h1 | 0x640a0576u)));
            i1 = (unsigned)((int)u3 >= (int)(unsigned)b0) & 15u;
        }
        goto L1;
    }
    while (i0++ < 6u && *q0) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)(((unsigned)f0 + (unsigned)((int)u1 >= (int)u0)) & 1023u);
        h0 = (short)i0;
        w0 ^= (unsigned long long)(unsigned)l0 << ((unsigned)(garr[i1 & 7u] < (unsigned)d0) & 63u);
        if (0u) goto L2;
        break; (void)((u2 % ((unsigned)d0 | 1u)));
    }
    if ((unsigned)((unsigned)(x0 >> 70) < ((unsigned)l0 | v0))) goto L2;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            if (i1) {
                switch ((unsigned)e0 & 7u) {
                    u1 = u1 * 0x9e3779b1u + (*mp | (unsigned)((short)u0 > (signed char)((v0 | g1) % (i2 | 1u))));
                    r0.y ^= -((i0 % (m0 | 1u)) * ((unsigned)h0 << ((1u ^ (unsigned)s1) & 31u)));
                    b0 = (unsigned)((int)m0 >= (int)(v0 << (((unsigned)b0 | (unsigned)((int)p1 < (int)8u)) & 31u))) != 0u;
                    if (9u) goto L0;
                }
                if (fuel) break;
                u2 += (unsigned)(0x80000000u < ~(unsigned)((int)i0 < (int)r0.x));
            }
        }
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            a0[0x7fffffffu & 3u] = 6u;
            switch (u2 & 7u) {
                goto L0;
                w0 ^= (unsigned long long)0x8e1feea3u << ((unsigned)(0x80000000u && (u3 ? garr[u2 & 7u] : g1)) & 63u);
                w0 = w0 * 6364136223846793005ull + (g1 / ((unsigned)(short)(unsigned)((unsigned)(r0.x || (unsigned)(w0 >> 29)) < 0u) | 1u));
                if (r0.x) {
                    while (i2++ < 5u && ((unsigned)w0 % (0x93bc1aedu | 1u))) { if (--fuel == 0u) goto done;
                        case 2u: ;
                    }
                    case 6u: ;
                    r0.x = ((unsigned)(0x1ba2b550u || 2u) & ((unsigned)c1 ? (unsigned)e0 : 0x7cd9ce0du));
                }
                continue; (void)((unsigned)((int)i1 < (int)garr[i1 & 7u]));
            }
        }
        u1 = ((unsigned)f0 & (p1 % ((unsigned)(w0 >> 29) | 1u)));
        break; (void)((unsigned)((int)a0[u1 & 3u] >= (int)(0xc4445be5u % (0x7fffffffu | 1u))));
        if ((((unsigned)(x0 >> 70) & u3) % (p1 | 1u))) {
            if (fuel < 8u) return 0x10000u;
            break; (void)((u1 - a0[u1 & 3u]));
            if ((8u + (unsigned)s0)) {
                c1 = (signed char)((unsigned)x0 ^ (unsigned)(0x7fffffffu || ((unsigned)c1 >> ((*mp & *mp) & 31u))));
                c1 = (signed char)(unsigned)(short)(0xe99e5462u >> (a0[u1 & 3u] & 31u));
                if (u3) break;
                while (i1++ < 3u && (i0 | 0x30c64d6cu)) { if (--fuel == 0u) goto done;
                    u2 ^= (-(*mp | (unsigned)x0) >> ((a0[u1 & 3u] / (a0[i0 & 3u] | 1u)) & 31u));
                    b0 = ~(unsigned)((int)(unsigned)f0 < (int)(unsigned)d0) != 0u;
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((unsigned)b0 == 4u) < (unsigned)((int)(i1 >> ((unsigned)h1 & 31u)) < (int)2u)));
                    break; (void)((unsigned)(unsigned char)(unsigned)(*mp < u1));
                    break; (void)((unsigned)h0);
                    if (((unsigned)h1 + (unsigned)d0)) break;
                }
            } else {
                if ((unsigned)((int)(unsigned)!(0xffffffffu / (4u | 1u)) >= (int)0xffffffffu)) break;
            }
        }
    }
    if (-(unsigned)((int)(unsigned)((unsigned)e0 && 3u) < (int)(unsigned)(x0 >> 70))) goto L4;
    w0 ^= (unsigned long long)(unsigned)c1 << (a0[i0 & 3u] & 63u);
    goto L4;
    do { if (--fuel == 0u) goto done;
        { unsigned t0; double z0; if ((0xb9ffbu) & 1u) { t0 = (unsigned)(signed char)(unsigned)(0x10000u || i0); z0 = (double)((((u3 | *mp) ^ (unsigned)x0)) & 255u); } if ((0xb9ffbu) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            if ((unsigned)((int)3u >= (int)r0.x)) break;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                g0 = (~(unsigned)((int)0xffffffffu >= (int)(unsigned)(unsigned char)(unsigned)((short)p1 > (signed char)8u)) + *mp);
                r0.y ^= ((unsigned)((unsigned)(short)(unsigned)(garr[i1 & 7u] == i0) || (unsigned)c0) | ~(0x6e2a46fbu >> ((unsigned)c1 & 31u)));
                if ((0x5d81ce0eu + (unsigned)((unsigned)b0 < 0xa968f777u))) break;
                r0.y ^= (unsigned)d0;
            }
            if ((unsigned)c1) continue;
            if ((unsigned)(i1 == u2)) break;
        }
        d0 = d0 * 0.5 + (double)(((u1 + (unsigned)s1) - fuel) & 1023u);
        *q0 = (unsigned)(unsigned char)((unsigned)(g1 < 0xc694bb46u) + -((unsigned)e0 % ((g1 * 0u) | 1u)));
        *mp = ((unsigned)s0 & ((0x918cf842u - u3) ^ ((unsigned)f0 & 0xb4374082u)));
        do { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(m0 || 4u)) goto L0;
            }
            b0 = (unsigned)((int)(p2 % ((unsigned)f0 | 1u)) >= (int)(((unsigned)h1 & g1) / ((unsigned)s0 | 1u))) != 0u;
            u3 += (unsigned)(w0 >> 29);
            if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)((short)u1 > (signed char)(unsigned)f0) < (int)g0)) break;
            break; (void)((0x10000u + p0));
            if (g1) {
                *q0 = (unsigned)(signed char)((((unsigned)c1 % (0x75af351cu | 1u)) * ((unsigned)(x0 >> 70) >> (9u & 31u))) % (0xffffffffu | 1u));
                if (0xac07c96bu) {
                    e0 = e0 * 0.5L + (long double)((unsigned)(((unsigned)e0 ^ i1) && g1) & 1023u);
                    if ((0x1a4cf889u / (0xffffffffu | 1u))) continue;
                    g0 = (0xa08b96cfu | u1);
                    e0 = e0 * 0.5L + (long double)((unsigned)((int)8u >= (int)(unsigned)(3u && (unsigned)e0)) & 1023u);
                }
                q0 = &garr[p0 & 7u];
                d0 = d0 * 0.5 + (double)((unsigned)((*q0 % (7u | 1u)) && (unsigned)((unsigned)h0 < g0)) & 1023u);
            } else {
                c1 = (signed char)(unsigned)((unsigned)!(0xa247d6a0u ^ (unsigned)(0x1a9b808u < garr[i1 & 7u])) < (v0 - (unsigned)w0));
                q0 = &garr[(unsigned)(x0 >> 70) & 7u];
            }
        } while (i1++ < 6u && (p0 - (unsigned)((int)(unsigned)s1 < (int)0x528f7104u)));
    } while (i0++ < 7u && ~(unsigned)((short)(unsigned)h0 > (signed char)(unsigned)(x0 >> 70)));
    *q0 += ((unsigned)((short)r0.y > (signed char)4u) ^ (unsigned)((int)0u < (int)1u));
    goto L3;
    u1 += (unsigned)(0u && (u2 / (p1 | 1u)));
    goto L0;
    if ((0x7fffffffu >> ((unsigned)((short)0x80000000u > (signed char)0x89c60995u) & 31u))) {
        d0 = d0 * 0.5 + (double)(3u & 1023u);
        if ((unsigned)((short)(unsigned)h0 > (signed char)(0x7fffffffu + 0xe3d6598bu))) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)(garr[i1 & 7u] && (unsigned)((int)i2 >= (int)fuel)) & 1023u);
        switch ((unsigned)((unsigned)((int)(unsigned)b0 >= (int)(unsigned)h0) < v0) & 7u) {
            u0 = (unsigned)h1;
            if (((unsigned)e0 & (p1 | 8u))) {
                c0 = (unsigned char)garr[u2 & 7u];
                garr[i2 & 7u] = p2;
            }
        }
        if ((unsigned)(signed char)((unsigned)d0 << ((unsigned)(x0 >> 70) & 31u))) {
            if (i2) {
                c1 = (signed char)(unsigned)(signed char)(unsigned)((short)((unsigned)(0x80000000u == 0xd25dc0fbu) - i2) > (signed char)(unsigned)(a0[i0 & 3u] == 9u));
                if (~(unsigned)((int)i2 >= (int)r0.x)) {
                    if ((unsigned)((short)0u > (signed char)(unsigned)(0xda997213u == g1))) goto L0;
                    *q0 = ((8u + p1) ^ 3u);
                    goto done;
                }
                goto L0;
                d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)s0 > (signed char)1u) & 1023u);
                if (~(unsigned)((short)garr[i1 & 7u] > (signed char)((unsigned)c1 & a0[u1 & 3u]))) goto L3;
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((0x80000000u % (0xe0846682u | 1u)) == g0)) break;
                        f0 = f0 * 0.5f + (float)((unsigned)e0 & 255u);
                        d0 = d0 * 0.5 + (double)(-(unsigned)((int)((2u >> ((unsigned)e0 & 31u)) * 0x67576e40u) < (int)~(6u - 0xc43cf4au)) & 1023u);
                        if ((unsigned)(short)(unsigned)(a0[u1 & 3u] == u0)) goto L0;
                        if ((~(0xffffffffu | g1) * 4u)) break;
                        s1 = (int)((unsigned)s1 + (0xffffffffu * (p2 % (((unsigned)b0 - (unsigned)s0) | 1u))));
                    } while (i1++ < 4u && g0);
                    s0 = (int)(unsigned)(unsigned char)(unsigned)(((unsigned)s1 % (a0[i0 & 3u] | 1u)) == (unsigned)b0);
                    for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        u2 = (unsigned)((unsigned)l0 || (unsigned)((unsigned)f0 && (unsigned)(unsigned char)(unsigned)(r0.y < i0)));
                        if ((4u + garr[i1 & 7u])) break;
                        q0 = &garr[~((a0[u1 & 3u] >> ((unsigned)w0 & 31u)) & (unsigned)((int)(unsigned)(g0 && 0x7fffffffu) < (int)i2)) & 7u];
                        u0 = u0 * 0x9e3779b1u + ((5u % (r0.y | 1u)) * (unsigned)((int)i1 < (int)((unsigned)(w0 >> 29) ^ (unsigned)f0)));
                        for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                            g0 = (unsigned)h1;
                            break; (void)((0x80000000u ^ 0xffffffffu));
                            break; (void)((unsigned)((unsigned)((int)fuel < (int)(unsigned)l0) || i0));
                        }
                    }
                    break; (void)((0xffffffffu % ((unsigned)w0 | 1u)));
                    if (p1) break;
                    for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((0x80000000u << (a0[u1 & 3u] & 31u))) goto L3;
                        c0 = (unsigned char)~(unsigned)((int)0x7fffffffu < (int)garr[i1 & 7u]);
                        c1 = (signed char)((unsigned)s0 * ((unsigned)(w0 >> 29) - (unsigned)h1));
                    }
                }
            }
            if (((unsigned)w0 - (unsigned)((short)fuel > (signed char)garr[u2 & 7u]))) goto L0;
        }
    } else {
        u1 ^= v0;
        u2 += (-((unsigned)((short)fuel > (signed char)5u) + garr[i1 & 7u]) >> ((unsigned)(short)(garr[u2 & 7u] | 0x2b79910eu) & 31u));
        if (v0) goto L0;
        if (0xabc1fafdu) goto L0;
    }
    f0 = f0 * 0.5f + (float)(u3 & 255u);
    if (0x18044ea3u) goto L0;
    if ((unsigned)(w0 >> 29)) {
        if ((unsigned)((int)*q0 < (int)(garr[i1 & 7u] - (unsigned)h0))) {
            do { if (--fuel == 0u) goto done;
                c1 = (signed char)(unsigned)((unsigned)((short)r0.y > (signed char)a0[u1 & 3u]) == (unsigned)(x0 >> 70));
                if (u1) break;
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)i1 < (int)fuel);
                if ((unsigned)((unsigned)(p2 == *q0) || (unsigned)c1)) goto L3;
                x0 = x0 * 0x100000001b3ull + (unsigned)!(unsigned)(i1 && (unsigned)((unsigned)c0 || (unsigned)(unsigned char)(u2 * fuel)));
            } while (i0++ < 7u && u1);
            f0 = f0 * 0.5f + (float)((6u & (unsigned)((short)(unsigned)(a0[i0 & 3u] < 0x10000u) > (signed char)9u)) & 255u);
        }
        { unsigned t1; double z1; if ((a0[u1 & 3u]) & 1u) { t1 = (unsigned)((unsigned)s1 || (unsigned)(0xb0b99029u || garr[i1 & 7u])); z1 = (double)((garr[i1 & 7u]) & 255u); } if ((a0[u1 & 3u]) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            if (0x78d27058u) goto done;
            if (-(unsigned)((short)~(unsigned)((int)i1 >= (int)0x46bd7459u) > (signed char)(unsigned)l0)) goto done;
            e0 = e0 * 0.5L + (long double)(r0.y & 1023u);
            switch ((0x4cfc9fe8u >> ((unsigned)(short)(unsigned)(i2 && (unsigned)f0) & 31u)) & 7u) {
                d0 = d0 * 0.5 + (double)((0x80000000u & 0xc858eaadu) & 1023u);
            }
        }
        if ((unsigned)d0) goto L0;
        { unsigned t2; double z2; if (((unsigned)d0) & 1u) { t2 = ((unsigned)(w0 >> 29) - 0x906c49c4u); z2 = (double)(((unsigned)((int)9u < (int)(unsigned)e0)) & 255u); } if (((unsigned)d0) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            if (p0) goto done;
            goto L0;
            { unsigned t3; double z3; if (((unsigned)((int)*q0 < (int)(unsigned)!(5u >> ((unsigned)x0 & 31u)))) & 1u) { t3 = (unsigned)l0; z3 = (double)((-(unsigned)((unsigned)(w0 >> 29) && 0x4f7ea7bcu)) & 255u); } if (((unsigned)((int)*q0 < (int)(unsigned)!(5u >> ((unsigned)x0 & 31u)))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                s1 = (int)((unsigned)s1 + (unsigned)((int)8u < (int)~((unsigned)d0 | 0x195766b4u)));
                if (u3 == 7u) return (((unsigned)l0 + (unsigned)c1) * (unsigned)h1);
                a0[g0 & 3u] = ((*q0 << (0x10000u & 31u)) >> (7u & 31u));
                while ((*q0 << (i2 & 31u))) { if (--fuel == 0u) goto done;
                    q0 = &garr[(u0 * ((unsigned)((int)(unsigned)s1 >= (int)1u) ? (unsigned)e0 : 0x10000u)) & 7u];
                    break; (void)((unsigned)((short)((unsigned)h1 ^ r0.y) > (signed char)0x10000u));
                    switch (0xffffffffu & 7u) {
                        continue; (void)((unsigned)(7u && (unsigned)w0));
                        s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)w0 > (signed char)((unsigned)(signed char)(p2 >> ((u3 / (0x31709aau | 1u)) & 31u)) % (garr[i1 & 7u] | 1u))));
                    }
                    s0 = (int)(unsigned)(r0.x && (a0[u1 & 3u] | (unsigned)l0));
                }
            }
            w0 = w0 * 6364136223846793005ull + ((unsigned)(unsigned char)(r0.y - p1) - (9u ^ (unsigned)c1));
            e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)(*mp < (unsigned)(unsigned char)((unsigned)b0 - a0[u1 & 3u])) < (int)((unsigned)b0 + (unsigned)c1)) & 1023u);
            i0 = (garr[i1 & 7u] - ((unsigned)s1 >> ((0x7fffffffu >> (v0 & 31u)) & 31u))) & 15u;
        }
        u0 ^= (unsigned)(w0 >> 29);
    }
    switch ((unsigned)((unsigned)(4u == i0) < 0xa1e66fabu) & 7u) {
        case 2u: ;
        case 1u: ;
        case 0u: ;
        break; (void)(v0);
    }
    { unsigned t4; double z4; if ((((unsigned)c0 * ((unsigned)d0 / ((unsigned)s0 | 1u)))) & 1u) { t4 = 8u; z4 = (double)((0x247293deu) & 255u); } if ((((unsigned)c0 * ((unsigned)d0 / ((unsigned)s0 | 1u)))) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)4u < (int)6u)) break;
            r0.x = ((unsigned)(0x4a6056d9u == (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)s0)) ^ (unsigned)(x0 >> 70));
        }
    }
    if (((unsigned)d0 / ((unsigned)h1 | 1u))) goto L2;
    if (((r0.x & *q0) + p2)) goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((((unsigned)c0 + g1) + (unsigned)(x0 >> 70))) {
        if (((unsigned)h1 << ((unsigned)(x0 >> 70) & 31u))) goto L2;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(0x4c1b3d82u, (m0 * (0xffffffffu % (*q0 | 1u))), *mp); }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)x0, ((unsigned)e0 / (*mp | 1u)), (unsigned)(i2 == 0x10000u)); }
    L0: if (--fuel == 0u) goto done;
    w0 = w0 * 6364136223846793005ull + (i1 & (unsigned)s0);
    if ((unsigned)(short)(a0[i0 & 3u] ^ (unsigned)h1)) {
        c1 = (signed char)(unsigned)((unsigned)(a0[u1 & 3u] && garr[i1 & 7u]) || (unsigned)(a0[u1 & 3u] == a0[i0 & 3u]));
        do { if (--fuel == 0u) goto done;
            u2 = u2 * 0x9e3779b1u + 3u;
            if ((unsigned)((int)(p1 % ((unsigned)c0 | 1u)) < (int)0xfa441f6bu)) break;
            if (budget != 0u) { budget -= 1u; u2 = fn0(i2, ((v0 - 0x7fffffffu) >> (a0[u1 & 3u] & 31u)), (unsigned)(m0 == garr[u2 & 7u])); }
            if ((unsigned)((unsigned)((unsigned)b0 || garr[u2 & 7u]) || i1)) break;
            L1: if (--fuel == 0u) goto done;
        } while (i0++ < 5u && (1u ? *mp : (unsigned)w0));
        u0 += (garr[i1 & 7u] / (m0 | 1u));
        if ((unsigned)!((2u + 0xa292e702u) % (m0 | 1u))) {
            if (fuel < 8u) return (unsigned)(short)((unsigned)x0 << (a0[u1 & 3u] & 31u));
            if ((unsigned)(2u || (p1 ^ (unsigned)d0))) goto L3;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)((int)6u < (int)0x7fffffffu) && a0[u1 & 3u]), (i2 | (unsigned)((int)(unsigned)h1 >= (int)*mp)), 0u); }
            if ((0xa783f2d8u * p2)) goto L4;
        } else {
            if ((unsigned)((0x80000000u - 0x7fffffffu) < 9u)) goto L4;
            m0 ^= (a0[u1 & 3u] << (m0 & 31u));
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                while (i1++ < 3u && (unsigned)!((unsigned)d0 | 7u)) { if (--fuel == 0u) goto done;
                    L2: if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + 8u);
                    f0 = f0 * 0.5f + (float)((unsigned)s0 & 255u);
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)garr[u2 & 7u] > (signed char)garr[u2 & 7u]), (u1 / (i0 | 1u)), (0x9b7c21e3u & 0x173fb3deu)); }
                    *q0 += 0x3cdf314fu;
                    *mp = (unsigned)((int)4u < (int)garr[u2 & 7u]);
                }
                if ((unsigned)(x0 >> 70)) continue;
                if (((unsigned)s0 / (p2 | 1u))) {
                    switch ((unsigned)s1 & 7u) {
                        case 1u: ;
                        *q0 = (0x3c45b85au * u3);
                        case 6u: ;
                    }
                    L3: if (--fuel == 0u) goto done;
                    m0 ^= (unsigned)(((unsigned)(p2 < 0u) / ((unsigned)s0 | 1u)) == (u1 * (unsigned)b0));
                    u1 += 0x80000000u;
                    if (u3) goto L4;
                    d0 = d0 * 0.5 + (double)(((unsigned)(signed char)(g1 ^ (unsigned)l0) ? (unsigned)w0 : u2) & 1023u);
                } else {
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (unsigned)((unsigned)(8u && (unsigned)d0) == (0xe53bf797u / (0x80000000u | 1u))));
                    }
                    break; (void)((unsigned)(w0 >> 29));
                }
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)((short)0x3ca1dff9u > (signed char)a0[i0 & 3u]) >> (v0 & 31u))) break;
                    garr[0x80000000u & 7u] = (unsigned)((int)(unsigned)(x0 >> 70) < (int)(i2 + i1));
                    while (i2++ < 7u && (unsigned)!((unsigned)(u0 < (unsigned)f0) ^ v0)) { if (--fuel == 0u) goto done;
                        if ((-(0x10000u & 0x4cff588bu) ^ fuel)) break;
                        L4: if (--fuel == 0u) goto done;
                        if ((unsigned)(((unsigned)f0 ^ 0xffffffffu) < u3)) break;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((g1 << (g1 & 31u)), 0xbe69c883u, ~(0x10000u ^ (unsigned)(0x10000u < 0xb1abcc85u))); }
                    }
                }
                x0 = x0 * 0x100000001b3ull + ((unsigned)c1 >> ((unsigned)((int)(unsigned)c0 >= (int)((unsigned)((int)u0 < (int)*q0) << (g1 & 31u))) & 31u));
            }
        }
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (0xffffffffu & (a0[i0 & 3u] % (p0 | 1u))));
        if ((unsigned)((unsigned)(p1 && g0) == (unsigned)d0)) break;
        e0 = e0 * 0.5L + (long double)((p1 & *mp) & 1023u);
        if (budget != 0u) { budget -= 1u; u1 = fn0(((g0 + u0) | 0x14f8ac1bu), (4u / (0x7fffffffu | 1u)), (((unsigned)x0 / (6u | 1u)) ^ g0)); }
        q0 = &garr[r0.x & 7u];
    }
    r0.y ^= u3;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && (unsigned)((unsigned)(w0 >> 29) < (0x5036738fu * i1))) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(w0 >> 29) == (9u % ((unsigned)f0 | 1u))) & 1023u);
            b0 = ((unsigned)(0u && (unsigned)((short)~(unsigned)((unsigned)x0 < (unsigned)e0) > (signed char)6u)) | i2) != 0u;
            if (0x10000u) {
                *q0 += (unsigned)(short)(unsigned)(u2 && (unsigned)((int)garr[u2 & 7u] < (int)0x7fffffffu));
                x0 = x0 * 0x100000001b3ull + (((unsigned)w0 + (unsigned)h1) / ((a0[i0 & 3u] << ((unsigned)c1 & 31u)) | 1u));
                c0 = (unsigned char)(unsigned)((int)(9u ^ (unsigned)((int)0x768cc944u >= (int)(unsigned)h1)) < (int)(unsigned)((unsigned)w0 == fuel));
                x0 = x0 * 0x100000001b3ull + a0[u1 & 3u];
                do { if (--fuel == 0u) goto done;
                    if (~(u0 % (fuel | 1u))) break;
                } while (i2++ < 2u && (0xc75dc391u + 0x10000u));
            } else {
                w0 ^= (unsigned long long)~(9u * 0x5bc11822u) << ((unsigned)(0xe2fe0d3bu && (unsigned)(i1 || (unsigned)s0)) & 63u);
                if ((unsigned)(p2 < u0)) continue;
                if (*mp) break;
                if (i0) continue;
            }
            switch (((unsigned)!(unsigned)((short)0x7fffffffu > (signed char)(unsigned)s0) - *q0) & 7u) {
                s1 = (int)((unsigned)s1 + (a0[u1 & 3u] % (((unsigned)(8u && (unsigned)s1) & (unsigned)((short)p1 > (signed char)(unsigned)e0)) | 1u)));
                i0 = (unsigned)((int)(unsigned)c0 >= (int)((unsigned)(garr[i1 & 7u] || u2) % ((unsigned)s1 | 1u))) & 15u;
                switch (u0 & 7u) {
                    do { if (--fuel == 0u) goto done;
                        case 4u: ;
                    } while (i2++ < 5u && (unsigned)(*q0 < (unsigned)e0));
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        case 7u: ;
                        case 0u: ;
                        s1 = (int)((unsigned)s1 + v0);
                        r0.x = a0[i0 & 3u];
                    }
                    case 1u: ;
                    garr[(unsigned)d0 & 7u] = (unsigned)((int)u1 < (int)0x112e368u);
                    q0 = &garr[(unsigned)((short)0x80000000u > (signed char)*mp) & 7u];
                    if (u3 == 7u) return (unsigned)(u1 && ((*q0 % (u1 | 1u)) | (unsigned)(fuel < (unsigned)h0)));
                }
                if ((i0 | 0x7fffffffu)) break;
                if ((unsigned)(a0[u1 & 3u] == garr[u2 & 7u])) break;
                case 5u: ;
            }
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)f0 == u1), u1, (r0.y ^ garr[i1 & 7u])); }
        if ((unsigned)((int)(unsigned)w0 < (int)(i2 << (fuel & 31u)))) break;
    }
    while (i0++ < 2u && -(unsigned)(garr[i1 & 7u] < 0x80000000u)) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)s0 || (unsigned)s0)) goto L4;
        do { if (--fuel == 0u) goto done;
            if (u3 == 7u) return (unsigned)((unsigned)(*mp || (((unsigned)h1 / (fuel | 1u)) ^ 2u)) || *q0);
            g0 = (unsigned)(*q0 == 0x7fffffffu);
            l0 = (long)((unsigned long)l0 + (unsigned)(((a0[i0 & 3u] * (unsigned)c0) / ((unsigned)c0 | 1u)) < ((unsigned)e0 - (unsigned)b0)));
        } while (i1++ < 4u && (g0 << ((unsigned)((unsigned)c0 && 0x7fffffffu) & 31u)));
        goto done;
        u2 = p0;
        for (;;) { if (--fuel == 0u) goto done;
            break; (void)((g0 << (0xdf809064u & 31u)));
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((p1 / (u1 | 1u)), g0, 0x7fffffffu); }
                if ((unsigned)w0) break;
                if ((unsigned)h0) break;
                if (((unsigned)l0 * ((unsigned)b0 >> (u3 & 31u)))) {
                    if ((0xced55c4bu & p1)) break;
                    u2 = u2 * 0x9e3779b1u + 6u;
                    *q0 += ((unsigned)h1 >> ((unsigned)!(unsigned)((short)(unsigned)h0 > (signed char)i1) & 31u));
                } else {
                    f0 = f0 * 0.5f + (float)((g0 ? garr[i1 & 7u] : ((unsigned)b0 >> ((unsigned)l0 & 31u))) & 255u);
                    break; (void)(*q0);
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(i0 + i1), i2, i0); }
            }
            goto L4;
        }
    }
    v0 = ((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)w0) & fuel);
    if ((unsigned)((unsigned)((int)p0 < (int)fuel) && (unsigned)w0)) goto L4;
    if ((((unsigned)s1 / ((unsigned)s1 | 1u)) / ((unsigned)h0 | 1u))) goto L4;
    d0 = d0 * 0.5 + (double)(((m0 / (3u | 1u)) ? (u2 + 0xffffffffu) : (unsigned)w0) & 1023u);
    r0.x = (unsigned)((unsigned)s1 || (unsigned)(0x80000000u && (g1 ? (unsigned)c1 : 0xe04e8075u)));
    m0 ^= (unsigned)((unsigned)(x0 >> 70) < (unsigned)!(unsigned)(0x10000u || (u1 - v0)));
    for (;;) { if (--fuel == 0u) goto done;
        while (i1++ < 7u && (unsigned)d0) { if (--fuel == 0u) goto done;
            v0 = (unsigned)((unsigned)(*mp < 9u) || (unsigned)((int)(fuel % (7u | 1u)) < (int)u3));
            s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((short)(unsigned)x0 > (signed char)r0.y) < u0));
            { unsigned t0; double z0; if (((unsigned)(0x7fffffffu && g0)) & 1u) { t0 = ((unsigned)b0 | (u2 >> (v0 & 31u))); z0 = (double)(((r0.y - (unsigned)(garr[u2 & 7u] < 5u))) & 255u); } if (((unsigned)(0x7fffffffu && g0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                if (budget != 0u) { budget -= 1u; u1 = fn0(-((u2 & 0u) & (unsigned)s1), ((unsigned)x0 | (unsigned)s1), (g1 + (unsigned)((int)(unsigned)x0 >= (int)1u))); }
                if (budget != 0u) { budget -= 1u; u1 = fn0((0x7fffffffu << (0xb48ff54fu & 31u)), ((unsigned)(r0.x == u1) - fuel), ((unsigned)(0xc28e15dbu < u3) & i2)); }
                if ((unsigned)((int)u1 < (int)v0)) break;
                if ((garr[u2 & 7u] & 3u)) break;
            }
            c0 = (unsigned char)(unsigned)(garr[u2 & 7u] < (unsigned)((int)(garr[i1 & 7u] | (unsigned)s0) >= (int)(unsigned)((int)a0[u1 & 3u] < (int)a0[i0 & 3u])));
        }
        while ((unsigned)!(i2 | 0xffffffffu)) { if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if ((g0) & 1u) { t1 = ((0xb6512a15u - (unsigned)x0) / (0x80000000u | 1u)); z1 = (double)((p1) & 255u); } if ((g0) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                if ((unsigned)((short)p1 > (signed char)(garr[i1 & 7u] >> ((unsigned)s0 & 31u)))) goto done;
                if (((unsigned)h0 * i1)) goto L2;
                f0 = f0 * 0.5f + (float)(((7u | v0) + g1) & 255u);
                if ((unsigned)((int)0x575f6659u >= (int)fuel)) {
                    *q0 += (unsigned)((int)((unsigned)(w0 >> 29) - r0.y) >= (int)((unsigned)f0 << (a0[u1 & 3u] & 31u)));
                    if (budget != 0u) { budget -= 1u; u3 = fn0(1u, i2, (unsigned)((unsigned)e0 < (unsigned)(x0 >> 70))); }
                    q0 = &garr[(((unsigned)d0 << ((unsigned)l0 & 31u)) >> ((unsigned)(p0 || 0x6ea24e36u) & 31u)) & 7u];
                    if ((unsigned)((int)0x278af1d8u >= (int)garr[u2 & 7u])) break;
                    garr[((unsigned)w0 - (unsigned)s1) & 7u] = 0x10000u;
                    h1 = (unsigned short)(h1 + (unsigned)((int)u1 < (int)(p2 - (0x7344e3d4u << ((unsigned)l0 & 31u)))));
                } else {
                    break; (void)(0x8928255au);
                    w0 ^= (unsigned long long)0x8676cc99u << ((unsigned)((unsigned)h1 == 0x7fffffffu) & 63u);
                    if ((unsigned)((int)(unsigned)h0 < (int)0x7fffffffu)) break;
                }
                u1 += (unsigned)((unsigned)e0 == ((unsigned)h1 % (((unsigned)h1 / ((unsigned)d0 | 1u)) | 1u)));
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(0x7fffffffu, i1, (i2 << ((0x80000000u & 0x7fffffffu) & 31u))); }
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(v0 < (unsigned)e0), m0, (0xffffffffu / ((unsigned)(fuel && 2u) | 1u))); }
                    if ((unsigned)x0) goto L1;
                } while (i2++ < 6u && u2);
            }
            break; (void)(a0[u1 & 3u]);
            for (;;) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (garr[i1 & 7u] & a0[i0 & 3u]);
                *q0 += (0xe8c5b203u & ((0x7fffffffu & (unsigned)f0) + (u2 ^ p1)));
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((u3 | i0), 0xf7b51bb5u, (unsigned)(u3 || (r0.y + garr[u2 & 7u]))); }
            if ((unsigned)(i1 && 0xffffffffu)) break;
            e0 = e0 * 0.5L + (long double)((unsigned)e0 & 1023u);
        }
        l0 = (long)((unsigned long)l0 + (i0 / ((unsigned)(unsigned char)(unsigned)(((unsigned)w0 % ((unsigned)w0 | 1u)) || (unsigned)((short)6u > (signed char)(unsigned)c0)) | 1u)));
        b0 = (unsigned)((int)(unsigned)((unsigned)e0 == u3) < (int)(unsigned)(i2 || garr[i1 & 7u])) != 0u;
    }
    c0 = (unsigned char)(unsigned)s0;
    if ((unsigned)(g0 < 0xd72eff78u)) {
        if ((unsigned)((int)m0 < (int)fuel)) goto L0;
        s1 = (int)((unsigned)s1 + (unsigned)e0);
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(signed char)(unsigned)(g1 && (unsigned)((int)(unsigned)b0 < (int)*q0)), (unsigned)(short)(u1 | *q0), (unsigned)(short)(u1 % (v0 | 1u))); }
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((0x594687c9u - 0x80000000u) & 7u) {
                s0 = (int)(unsigned)(u1 || garr[i1 & 7u]);
                case 4u: ;
                { unsigned t2; double z2; if (((unsigned)l0) & 1u) { t2 = ((2u - 0u) - 0x9271d414u); z2 = (double)(((unsigned)c1) & 255u); } if (((unsigned)l0) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    if (((unsigned)x0 ^ (p0 - 0x80000000u))) break;
                    v0 = (unsigned)(i0 < 0xa41ff225u);
                }
                *q0 += (unsigned)((short)4u > (signed char)(0x7fffffffu / ((0x80000000u + *q0) | 1u)));
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    switch (m0 & 7u) {
                        d0 = d0 * 0.5 + (double)(garr[u2 & 7u] & 1023u);
                        e0 = e0 * 0.5L + (long double)(((garr[u2 & 7u] + garr[u2 & 7u]) / ((unsigned)((short)7u > (signed char)(unsigned)c0) | 1u)) & 1023u);
                        g1 += ((r0.x * (m0 ? (unsigned)s0 : p2)) * (unsigned)(w0 >> 29));
                        if (5u) goto L2;
                        u2 = u2 * 0x9e3779b1u + (*mp % ((unsigned)(signed char)(unsigned)(0x10000u == (unsigned)e0) | 1u));
                    }
                    q0 = &garr[(unsigned)((int)u1 >= (int)m0) & 7u];
                    case 6u: ;
                    if ((unsigned)(signed char)(r0.x & i0)) break;
                    r0.y ^= ((unsigned)(short)(unsigned)(i1 && (unsigned)((int)a0[i0 & 3u] < (int)a0[u1 & 3u])) % (u3 | 1u));
                }
                q0 = &garr[-(unsigned)((int)0x10000u >= (int)(i2 - 0u)) & 7u];
            }
            do { if (--fuel == 0u) goto done;
                break; (void)(fuel);
                l0 = (long)((unsigned long)l0 + ((unsigned)e0 % ((unsigned)((int)(unsigned)s0 >= (int)(unsigned)l0) | 1u)));
                c0 = (unsigned char)((unsigned)d0 * 0xffffffffu);
                switch ((unsigned)(7u || (unsigned)x0) & 7u) {
                    case 4u: ;
                    if ((unsigned)(signed char)(unsigned)((short)(unsigned)((short)0x668d8882u > (signed char)8u) > (signed char)3u)) goto L4;
                    break; (void)(u2);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0(((a0[i0 & 3u] ^ 5u) + 0xffffffffu), (unsigned)((int)i2 >= (int)u2), (unsigned)h1); }
            } while (i1++ < 3u && (*mp / ((unsigned)w0 | 1u)));
            w0 = w0 * 6364136223846793005ull + *q0;
            *q0 = (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)(0x2d26beb1u || (unsigned)b0));
            v0 = (unsigned)((short)g0 > (signed char)(unsigned)((int)2u >= (int)r0.y));
        }
    } else {
        if ((unsigned)((garr[u2 & 7u] ^ 0xffffffffu) || (unsigned)d0)) {
            m0 ^= (unsigned)s1;
        }
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((2u * ((unsigned)c1 * m0))) goto L1;
        }
        { unsigned t3; double z3; if (((0x7fffffffu >> ((unsigned)s1 & 31u))) & 1u) { t3 = (unsigned)(unsigned char)(unsigned)(*q0 || (unsigned)((unsigned)h0 || 0xffffffffu)); z3 = (double)(((unsigned)(w0 >> 29)) & 255u); } if (((0x7fffffffu >> ((unsigned)s1 & 31u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            goto L1;
        }
        g0 = (unsigned)(3u < ((unsigned)w0 * 0xffffffffu));
    }
    if (p2) goto L0;
    m0 ^= (unsigned)f0;
    q0 = &garr[(unsigned)(signed char)(unsigned)((int)((unsigned)w0 | 7u) < (int)((unsigned)f0 >> ((unsigned)((int)0x99069909u < (int)m0) & 31u))) & 7u];
    while (i0++ < 6u && ((r0.y / (i0 | 1u)) * *mp)) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((unsigned)d0 || i0));
        { unsigned t4; double z4; if ((((unsigned)l0 - garr[i1 & 7u])) & 1u) { t4 = ((unsigned)s1 % ((unsigned)((short)p1 > (signed char)7u) | 1u)); z4 = (double)(((g1 % ((unsigned)c1 | 1u))) & 255u); } if ((((unsigned)l0 - garr[i1 & 7u])) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            while (m0) { if (--fuel == 0u) goto done;
                switch (((a0[i0 & 3u] >> (i2 & 31u)) | 1u) & 7u) {
                    u2 = u2 * 0x9e3779b1u + ((((0xa4e6f826u + i0) >> (p1 & 31u)) - 0x80000000u) + a0[i0 & 3u]);
                    m0 ^= (0x4da5a1c6u % (((unsigned)x0 / ((unsigned)((int)garr[u2 & 7u] >= (int)0u) | 1u)) | 1u));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((g1 % ((unsigned)!(unsigned)((int)0x6a2b8cb3u < (int)4u) | 1u)), (unsigned)d0, (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)s1)); }
                    do { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            break; (void)((g0 >> ((0x701c43e2u >> (9u & 31u)) & 31u)));
                            *q0 += ((unsigned)s0 & (u1 & u0));
                        } while (i0++ < 2u && ((unsigned)w0 ^ *q0));
                    } while (i2++ < 4u && g0);
                }
                if ((unsigned)(short)((unsigned)(signed char)(unsigned)(i0 && i0) << (0x80000000u & 31u))) {
                    { unsigned t5; double z5; if ((((0x959ab09bu & i2) % ((unsigned)c1 | 1u))) & 1u) { t5 = (v0 >> (7u & 31u)); z5 = (double)((r0.y) & 255u); } if ((((0x959ab09bu & i2) % ((unsigned)c1 | 1u))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                        garr[(unsigned)(a0[u1 & 3u] || (unsigned)f0) & 7u] = p0;
                        f0 = f0 * 0.5f + (float)((7u + *mp) & 255u);
                        e0 = e0 * 0.5L + (long double)(i2 & 1023u);
                        u3 = u3 * 0x9e3779b1u + (3u & p1);
                        if ((0x7fa1c704u + ((unsigned)h1 * v0))) goto L0;
                        switch (m0 & 7u) {
                            w0 ^= (unsigned long long)(unsigned)f0 << ((unsigned)((short)(unsigned)((unsigned)l0 || g0) > (signed char)(unsigned)((unsigned)((short)0xffffffffu > (signed char)(unsigned)w0) < g1)) & 63u);
                        }
                    }
                    for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        h0 = (short)((unsigned)e0 / ((unsigned)(w0 >> 29) | 1u));
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)i0 < (int)(unsigned)((unsigned)f0 && 0x616f8e07u)));
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0(u3, 0xdf73180eu, (0xefcae9cfu ^ 0xb566360fu)); }
                    c0 = (unsigned char)(0x4df09e3u / (0xffffffffu | 1u));
                    if ((u0 ^ (unsigned)((int)r0.y >= (int)r0.x))) break;
                }
                break; (void)((unsigned)(short)(a0[u1 & 3u] / ((unsigned)(0x10000u && 0xffffffffu) | 1u)));
                u3 += (unsigned)(u2 && (unsigned)!(a0[i0 & 3u] & garr[i1 & 7u]));
            }
            if (u3 == 7u) return (garr[u2 & 7u] << ((unsigned)(short)(p0 | m0) & 31u));
            switch ((unsigned)((0xee807aa9u / (p0 | 1u)) == g0) & 7u) {
                s1 = (int)((unsigned)s1 + (unsigned)s0);
                l0 = (long)((unsigned long)l0 + -(unsigned)(((unsigned)!((unsigned)x0 >> ((unsigned)s0 & 31u)) ? g1 : 0xffffffffu) && (unsigned)d0));
                if (garr[u2 & 7u]) continue;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(6u == (unsigned)((int)(unsigned)l0 < (int)0x10000u)), (0xab1294b8u % (0x7fffffffu | 1u)), (unsigned)!(unsigned)(g1 < 0x80000000u)); }
            }
            if (i1) break;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)m0 < (int)(unsigned)c1), ((0xd726a994u & garr[i1 & 7u]) + i1), (g1 + 0x8b7e4fd6u)); }
        }
        if (fuel < 8u) return (unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)(unsigned char)(unsigned)((unsigned)s0 < u0));
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)(x0 >> 70) || 5u), 0x80000000u, i1); }
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)d0) break;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)c1 - (unsigned)((short)g1 > (signed char)g0))) break;
            if ((unsigned)(short)(unsigned)(r0.x || u1)) break;
            if (m0) break;
        }
        break; (void)((unsigned)((int)a0[i0 & 3u] >= (int)m0));
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)((unsigned)(short)((unsigned)e0 | g1) * (0xdc53019cu * 1u));
            c1 = (signed char)((unsigned)((int)u3 >= (int)(unsigned)h1) << ((0x4b4b2497u % ((unsigned)d0 | 1u)) & 31u));
            if (6u) goto L3;
            garr[u2 & 7u] = ((a0[i0 & 3u] + (unsigned)c1) / ((unsigned)((short)6u > (signed char)(unsigned)((short)0x80000000u > (signed char)(unsigned)d0)) | 1u));
            b0 = (unsigned)((unsigned)(x0 >> 70) == u2) != 0u;
            if (budget != 0u) { budget -= 1u; u1 = fn0((0xe8ab591du % (0x7fffffffu | 1u)), (unsigned)((int)(unsigned)s0 >= (int)(unsigned)(unsigned char)(unsigned)((int)r0.x >= (int)3u)), (unsigned)(w0 >> 29)); }
        }
    } while (i0++ < 2u && ((unsigned)c1 * (unsigned)d0));
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)e0);
        if (r0.x) break;
        break; (void)(p0);
    }
    f0 = f0 * 0.5f + (float)(a0[i0 & 3u] & 255u);
    if (budget != 0u) { budget -= 1u; u3 = fn0((0x80000000u >> (a0[u1 & 3u] & 31u)), 0xd8c29a35u, (unsigned)((unsigned)w0 || 0x10000u)); }
    r0.y ^= (0xa57db998u | 0xffffffffu);
    goto L4;
    do { if (--fuel == 0u) goto done;
        { unsigned t6; double z6; if (((p1 >> ((1u >> ((unsigned)c1 & 31u)) & 31u))) & 1u) { t6 = ((unsigned)((unsigned)c1 < (unsigned)b0) / (*q0 | 1u)); z6 = (double)(((unsigned)(0x111ae43bu < 0xffffffffu)) & 255u); } if (((p1 >> ((1u >> ((unsigned)c1 & 31u)) & 31u))) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            v0 = ((u3 & u1) >> (g1 & 31u));
            break; (void)(((unsigned)x0 | p2));
            h0 = (short)(unsigned)((r0.x | a0[i0 & 3u]) == 5u);
            u0 += ((unsigned)(0xf0463392u == v0) / ((unsigned)((short)p1 > (signed char)(unsigned)((int)p2 < (int)i2)) | 1u));
        }
    } while (i0++ < 2u && (unsigned)s0);
    if (((a0[i0 & 3u] & (unsigned)h0) & g1)) {
        c0 = (unsigned char)(unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)s1 < u1) && (unsigned)(r0.y < 7u));
        c0 = (unsigned char)(unsigned)((int)0xf0e0f10bu < (int)(0xe21dbabfu & (unsigned)((unsigned)h1 < (unsigned)h0)));
        b0 = r0.x != 0u;
        goto L2;
    }
    if ((unsigned)!((unsigned)d0 + ~((unsigned)c1 & (unsigned)s1))) goto L1;
    switch (u3 & 7u) {
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)c1), 5u, (0x48e2d11au << (g1 & 31u))); }
        case 2u: ;
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((int)r0.y >= (int)0xffffffffu) % (i1 | 1u)), (unsigned)(*q0 == i0), (v0 % ((unsigned)e0 | 1u))); }
        *mp = u0;
        switch (0xe455d1f3u & 7u) {
            { unsigned t7; double z7; if (((4u % ((unsigned)((int)0x8bd32f6eu >= (int)i1) | 1u))) & 1u) { t7 = ((unsigned)f0 << (p0 & 31u)); z7 = (double)(((unsigned)(p1 && (4u >> (0x80000000u & 31u)))) & 255u); } if (((4u % ((unsigned)((int)0x8bd32f6eu >= (int)i1) | 1u))) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                x0 = x0 * 0x100000001b3ull + ((unsigned)(unsigned char)(unsigned)((unsigned)(x0 >> 70) == (unsigned)x0) % (u0 | 1u));
            }
            if ((unsigned)((int)fuel < (int)(unsigned)(w0 >> 29))) {
                case 6u: ;
                *q0 = (unsigned)((unsigned)f0 && garr[u2 & 7u]);
                *mp = (a0[i0 & 3u] / (((unsigned)(7u < 0x80000000u) << ((unsigned)l0 & 31u)) | 1u));
                if ((unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)x0)) break;
                { unsigned t8; double z8; if ((((unsigned)e0 >> (g0 & 31u))) & 1u) { t8 = (p1 + (unsigned)(0x10000u == (unsigned)s1)); z8 = (double)((r0.y) & 255u); } if ((((unsigned)e0 >> (g0 & 31u))) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                    h0 = (short)v0;
                    a0[(2u >> (r0.x & 31u)) & 3u] = (unsigned)(g1 == (unsigned)((int)(unsigned)(u0 || 5u) >= (int)v0));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)*mp > (signed char)g1), 0x1e45126du, (unsigned)((unsigned)h0 || r0.y)); }
                    default: ;
                    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((int)(unsigned)((int)(unsigned)h1 >= (int)(unsigned)h0) >= (int)0x2d87d657u) || 9u));
                }
                if ((unsigned)(r0.y || g1)) {
                    if ((unsigned)f0) {
                        case 1u: ;
                    } else {
                        w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)!(r0.x | 4u) > (signed char)r0.y);
                        r0.x = ((0xffffffffu << (((unsigned)w0 ^ m0) & 31u)) & 0xcda8193au);
                        break;
                    }
                } else {
                    case 0u: ;
                    goto L1;
                }
            } else {
                if (u3 == 7u) return (unsigned)(signed char)(u0 / ((unsigned)l0 | 1u));
                if (0xffffffffu) goto done;
                case 3u: ;
                r0.y ^= 0xbd6aa7bdu;
            }
            a0[garr[u2 & 7u] & 3u] = (unsigned)!(unsigned)((int)~(unsigned)((unsigned)((unsigned)((int)9u < (int)r0.x) == g1) && 8u) >= (int)0xf95a63f4u);
            if ((unsigned)e0) {
                m0 ^= ((unsigned)(i2 == u2) & ((*q0 - i2) | v0));
                break;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(u0 && i2), ((unsigned)((int)u3 >= (int)0x80000000u) + (unsigned)f0), (r0.x | 0xa9c13ed7u)); }
                if (budget != 0u) { budget -= 1u; u2 = fn0((6u + (0x8475c975u + a0[i0 & 3u])), (unsigned)((int)0x7fffffffu < (int)(unsigned)h0), i1); }
                u0 += (u0 / ((unsigned)((int)(unsigned)f0 < (int)i2) | 1u));
                r0.x = (i1 * (unsigned)(0x65f37859u < (unsigned)x0));
            } else {
                garr[0x80000000u & 7u] = ((unsigned)((int)(unsigned)h0 >= (int)9u) % ((unsigned)((short)(unsigned)(short)(4u & (unsigned)c1) > (signed char)(unsigned)s0) | 1u));
            }
            break;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)d0, (unsigned)(unsigned char)(unsigned)((unsigned)!(*q0 / ((unsigned)h0 | 1u)) || (unsigned)f0), (0x943e0abbu | p2)); }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)(0u < (unsigned)e0) < (int)u0), (fuel - u2), (unsigned)x0); }
    b0 = (((0x35eff170u | garr[u2 & 7u]) >> (0xfdfd6c1fu & 31u)) >> ((0x90922735u + 0x7fffffffu) & 31u)) != 0u;
    g1 += (((unsigned)!(unsigned)(p1 < 0x10000u) * ((unsigned)s1 | 0x7fffffffu)) + r0.x);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((u1 * r0.x)) break;
        garr[0x80000000u & 7u] = (unsigned)h0;
        if (budget != 0u) { budget -= 1u; u1 = fn0((u2 / (u0 | 1u)), 1u, ((unsigned)s1 & (unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)c0))); }
        if ((unsigned)!((unsigned)d0 % (g0 | 1u))) goto L2;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0(u1, ((unsigned)(v0 && a0[i0 & 3u]) % (garr[i1 & 7u] | 1u)), (unsigned)(0x7fffffffu || p2)); }
    { unsigned t9; double z9; if ((((unsigned)(signed char)(0xbce2d875u >> (g0 & 31u)) | g0)) & 1u) { t9 = ~(u2 / (*q0 | 1u)); z9 = (double)((p0) & 255u); } if ((((unsigned)(signed char)(0xbce2d875u >> (g0 & 31u)) | g0)) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
        if (budget != 0u) { budget -= 1u; u2 = fn0(0x3eb38a3du, 7u, (-(unsigned)((unsigned)c1 && (unsigned)s1) ^ fuel)); }
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(garr[u2 & 7u], ((0xffffffffu << ((unsigned)b0 & 31u)) - (unsigned)(w0 >> 29)), (unsigned)((int)0x7fffffffu < (int)g0)); }
            e0 = e0 * 0.5L + (long double)((r0.x ? r0.y : (unsigned)((int)p0 >= (int)(unsigned)h0)) & 1023u);
            if (9u) {
                b0 = (unsigned)(w0 >> 29) != 0u;
                s1 = (int)((unsigned)s1 + ~(unsigned)(p1 && ((unsigned)e0 + r0.x)));
                goto L3;
                break; (void)(0x10000u);
            } else {
                break; (void)((fuel >> ((unsigned)h0 & 31u)));
                m0 ^= (unsigned)b0;
                if (((unsigned)((int)p0 < (int)u2) << (0xdb81e091u & 31u))) break;
            }
            switch ((unsigned)((int)v0 >= (int)~(0x10000u >> (p2 & 31u))) & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(signed char)((0xecc7f512u << (g1 & 31u)) - 5u), (((unsigned)b0 * 0x10000u) + 9u), (6u / (0x98350b45u | 1u))); }
                r0.y ^= (unsigned)(unsigned char)(unsigned)(i0 == (u2 ? (unsigned)e0 : (unsigned)((unsigned)s1 == 0x10000u)));
                d0 = d0 * 0.5 + (double)((0xe5948ed9u % (i2 | 1u)) & 1023u);
            }
            l0 = (long)((unsigned long)l0 + (unsigned)(short)(i1 ^ 0x90648f88u));
            { unsigned t10; double z10; if ((5u) & 1u) { t10 = (unsigned)h0; z10 = (double)(((garr[i1 & 7u] - p2)) & 255u); } if ((5u) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
                q0 = &garr[~((m0 * (unsigned)(x0 >> 70)) % ((unsigned)((int)p2 >= (int)7u) | 1u)) & 7u];
                if (p0) break;
                w0 ^= (unsigned long long)(unsigned)(short)((unsigned)h0 ^ u1) << ((a0[u1 & 3u] << ((u1 - u3) & 31u)) & 63u);
                if ((4u / (i2 | 1u))) goto L0;
                q0 = &garr[(unsigned)((short)((unsigned)((unsigned)l0 && 0x10000u) ^ 0xffffffffu) > (signed char)0x4bf77a97u) & 7u];
            }
        } while (i0++ < 6u && (unsigned)(x0 >> 70));
        l0 = (long)((unsigned long)l0 + ~(unsigned)((int)u3 >= (int)((unsigned)((unsigned)l0 < g0) & 0x373d502fu)));
        while (i0++ < 5u && (unsigned)((int)garr[i1 & 7u] < (int)4u)) { if (--fuel == 0u) goto done;
            if (u3 == 7u) return (0x12cba4fdu * 1u);
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    g1 += ((u2 >> (*q0 & 31u)) % ((unsigned)(short)(unsigned)((short)0xcc4125fau > (signed char)0x6ea494bcu) | 1u));
    a0[0xffffffffu & 3u] = ((unsigned)f0 | (a0[u1 & 3u] % (r0.x | 1u)));
    switch (((unsigned)d0 - 0x80000000u) & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn0(1u, a0[i0 & 3u], (unsigned)h1); }
        c0 = (unsigned char)((r0.y / (u1 | 1u)) << ((0x10000u << (fuel & 31u)) & 31u));
        g1 += ((unsigned)s1 * *mp);
        c1 = (signed char)(unsigned)(((unsigned)s0 >> (a0[i0 & 3u] & 31u)) && p1);
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)(r0.x < i0);
    if (u3 == 7u) return (unsigned)((unsigned)f0 < (unsigned)!(m0 % ((unsigned)(0x96a442bfu || g0) | 1u)));
    *q0 = (0x7fffffffu - (unsigned)(garr[i1 & 7u] == 0xffffffffu));
    c0 = (unsigned char)(((8u >> ((unsigned)c1 & 31u)) & (unsigned)f0) << ((r0.x & *q0) & 31u));
    if (((0x7fffffffu ^ (unsigned)l0) >> ((unsigned)f0 & 31u))) {
        v0 = (g1 + 0u);
    } else {
        do { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)(a0[i0 & 3u] && v0) > (signed char)(unsigned)((int)((unsigned)w0 >> (a0[i0 & 3u] & 31u)) >= (int)3u)) & 1023u);
            if (budget != 0u) { budget -= 1u; u1 = fn1(m0, ((0x262b2a3fu * (unsigned)h0) / (v0 | 1u)), (unsigned)(v0 == (u1 & u2))); }
            if ((unsigned)h0) break;
            i0 = ((unsigned)(short)(0xdd2e84c4u | garr[i1 & 7u]) | (unsigned)d0) & 15u;
            for (;;) { if (--fuel == 0u) goto done;
                r0.x = (unsigned)(0x794041a8u < 7u);
                L0: if (--fuel == 0u) goto done;
                break; (void)(((unsigned)(x0 >> 70) / ((unsigned)((short)0x80000000u > (signed char)0u) | 1u)));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(signed char)(p1 ^ 0x80000000u), p2, ((unsigned)e0 >> ((u3 / (5u | 1u)) & 31u))); }
            }
            b0 = (unsigned)(unsigned char)(unsigned)((unsigned)l0 || r0.y) != 0u;
        } while (i0++ < 6u && (m0 | 0x7fffffffu));
        *q0 += (v0 + (unsigned)(0xc1b6a4fdu && (i0 << ((0xcddbb838u ^ r0.y) & 31u))));
    }
    { unsigned t0; double z0; if ((0x15f487au) & 1u) { t0 = (*q0 + (unsigned)h1); z0 = (double)(((unsigned)((int)(unsigned)w0 < (int)9u)) & 255u); } if ((0x15f487au) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        if (budget != 0u) { budget -= 1u; u2 = fn0(u3, ((unsigned)h1 + 0xffffffffu), ((unsigned)!(unsigned)((short)i0 > (signed char)u1) + (unsigned)e0)); }
        s1 = (int)((unsigned)s1 + (m0 - ((0x80000000u ? 4u : (unsigned)(w0 >> 29)) * (unsigned)w0)));
    }
    c0 = (unsigned char)(unsigned)((int)u2 >= (int)(5u ^ (unsigned)(p0 || u0)));
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)c1, ((i2 << (0x7fffffffu & 31u)) % ((unsigned)b0 | 1u)), (unsigned)((int)1u >= (int)a0[i0 & 3u])); }
    if (u3 == 7u) return (0x7fffffffu ? (unsigned)w0 : 6u);
    if ((unsigned)(a0[i0 & 3u] == (unsigned)x0)) goto L3;
    l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)((short)0x8714e09bu > (signed char)g1) / (0x45e8cc13u | 1u)) || (1u & (unsigned)e0)));
    while (i0++ < 4u && (unsigned)(short)(((unsigned)s0 + 0x80000000u) * u0)) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)(short)(unsigned)((short)i1 > (signed char)(unsigned)((unsigned)(x0 >> 70) && 0xb7d7ee4fu)) > (signed char)(unsigned)h1);
        L1: if (--fuel == 0u) goto done;
        if (-(unsigned)((int)(0x949881eau + (unsigned)s0) >= (int)0xafa0d69du)) break;
        l0 = (long)((unsigned long)l0 + ((unsigned)x0 ^ 0x5e328adeu));
        if ((1u ^ r0.y)) {
            garr[*mp & 7u] = ((unsigned)(w0 >> 29) ^ i2);
            continue; (void)((0u - r0.y));
        } else {
            if (budget != 0u) { budget -= 1u; u0 = fn0(m0, (garr[u2 & 7u] | 0x10000u), (unsigned)(0xca8dabdu < (*mp & (unsigned)l0))); }
            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)c1 < (unsigned)(w0 >> 29)) & 1023u);
            if (budget != 0u) { budget -= 1u; u3 = fn0(0xc3e5016bu, (unsigned)((unsigned)((short)p1 > (signed char)v0) == 0xffffffffu), (unsigned)((p0 + 3u) && (unsigned)x0)); }
        }
        m0 ^= (unsigned)(1u || (unsigned)(0x55b0a22u && (*mp % ((p1 | 0x80000000u) | 1u))));
    }
    e0 = e0 * 0.5L + (long double)((p0 - (unsigned)((unsigned)x0 == 0x7fffffffu)) & 1023u);
    u0 = 0xadaee6b1u;
    if ((unsigned)(signed char)((unsigned)c0 ? 0x5209f1d0u : 0xb3feaf98u)) goto done;
    switch (((unsigned)l0 % ((unsigned)((int)*mp < (int)garr[i1 & 7u]) | 1u)) & 7u) {
        w0 ^= (unsigned long long)0u << ((((unsigned)(short)(unsigned)((int)*q0 < (int)6u) << (garr[i1 & 7u] & 31u)) - 0x8c7a8275u) & 63u);
    }
    r0.x = ((unsigned)((u3 << (p0 & 31u)) == p1) >> ((unsigned)b0 & 31u));
    s1 = (int)((unsigned)s1 + u3);
    if (p0) goto L0;
    L2: if (--fuel == 0u) goto done;
    goto L2;
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)g0 >= (int)5u);
    L3: if (--fuel == 0u) goto done;
    *mp = (unsigned)((int)(unsigned)c0 < (int)(unsigned)s1);
    L4: if (--fuel == 0u) goto done;
    *q0 += a0[u1 & 3u];
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(u1 && 4u)) {
            u2 = u2 * 0x9e3779b1u + g0;
        } else {
            a0[((unsigned)h1 & 2u) & 3u] = (u2 - (unsigned)h0);
            continue; (void)((unsigned)(signed char)(unsigned)((int)0xffffffffu >= (int)u3));
        }
        continue; (void)(0x80000000u);
        if ((unsigned)(short)(unsigned)((unsigned)w0 || -(0x237afec4u * g1))) break;
        if (((unsigned)s0 + u1)) continue;
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (8u | ((0x8459d308u << ((unsigned)l0 & 31u)) % (0x7fffffffu | 1u)));
        if (0x3305c188u) break;
        u2 = ((unsigned)(5u < (0u / (p0 | 1u))) / ((unsigned)((short)0x7fffffffu > (signed char)0x1981c255u) | 1u));
        if (budget != 0u) { budget -= 1u; u2 = fn1((2u >> (g1 & 31u)), 0x7fffffffu, (0x55ff8d9cu + (unsigned)f0)); }
        c1 = (signed char)u2;
    }
    r0.y ^= ((unsigned)(w0 >> 29) % (((unsigned)e0 - (v0 + 0x7fffffffu)) | 1u));
    *q0 = ~((r0.y & (unsigned)((unsigned)(x0 >> 70) && i2)) ^ (unsigned)d0);
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((0u % (u1 | 1u))) goto L1;
        s0 = (int)(unsigned)s0;
        if ((unsigned)((int)0x7fffffffu >= (int)(p2 >> (u0 & 31u)))) {
            s0 = (int)(i0 + 0xfe2441a4u);
            c1 = (signed char)(unsigned)((int)0x7fffffffu >= (int)(2u ? a0[u1 & 3u] : (unsigned)h1));
            h0 = (short)0x10000u;
        }
        if (*q0) continue;
        continue; (void)((0u << ((unsigned)(fuel == 0x7fffffffu) & 31u)));
        if (u1) break;
    }
    i1 = (1u & p0) & 15u;
    s0 = (int)(((unsigned)((int)1u < (int)0u) << ((unsigned)((int)r0.y < (int)0x2f572bf5u) & 31u)) / (a0[u1 & 3u] | 1u));
    l0 = (long)((unsigned long)l0 + (unsigned)((8u * u0) || 6u));
    if (g1) goto L2;
    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)d0 | 0xfc68409du), (unsigned)(unsigned char)(unsigned)((int)(unsigned)s1 >= (int)2u), (unsigned)(0xdf60a7e0u < (unsigned)(v0 == (unsigned)(w0 >> 29)))); }
    if (fuel < 8u) return (unsigned)(1u && (r0.y % ((((unsigned)s0 & (unsigned)(x0 >> 70)) / (u2 | 1u)) | 1u)));
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)0x28a21a8bu < (int)a0[i0 & 3u]), (unsigned)(i1 || ~(unsigned)(garr[u2 & 7u] || (unsigned)e0)), (0xffffffffu >> (u2 & 31u))); }
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)e0, ((unsigned)w0 + ~((unsigned)l0 - p2)), ((unsigned)s0 >> (i0 & 31u))); }
    d0 = d0 * 0.5 + (double)((unsigned)(u1 == ((0x7fffffffu ? (unsigned)s1 : r0.y) + 9u)) & 1023u);
    while ((unsigned)(p2 && (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)(6u == (unsigned)(garr[u2 & 7u] && (unsigned)((int)i1 >= (int)garr[u2 & 7u])));
            u1 = u1 * 0x9e3779b1u + ((unsigned)((int)9u >= (int)(unsigned)b0) << ((unsigned)(3u == (unsigned)((unsigned)(w0 >> 29) || g0)) & 31u));
            switch ((unsigned)h1 & 7u) {
                w0 = w0 * 6364136223846793005ull + (0xffffffffu * (unsigned)((unsigned)b0 < ((unsigned)l0 ? (unsigned)x0 : (unsigned)s0)));
                switch (r0.y & 7u) {
                    if ((unsigned)c0) {
                        w0 = w0 * 6364136223846793005ull + (unsigned)(short)((unsigned)(r0.x < (unsigned)e0) - (unsigned)((unsigned)(8u == a0[i0 & 3u]) < 5u));
                        if (i1) break;
                        c1 = (signed char)~((((unsigned)d0 ^ u2) - 5u) & (unsigned)(short)(*mp / ((unsigned)(x0 >> 70) | 1u)));
                    } else {
                        u1 = u1 * 0x9e3779b1u + ((unsigned)((unsigned)(u0 || (unsigned)l0) || 0xb28a0c94u) << (u3 & 31u));
                        if (u1) goto L3;
                        if ((unsigned)(1u && 4u)) break;
                    }
                    switch ((unsigned)(0xa5139f5du < (unsigned)s0) & 7u) {
                        case 7u: ;
                        switch (6u & 7u) {
                            case 7u: ;
                            b0 = g1 != 0u;
                            default: ;
                        }
                        if ((unsigned)((short)g0 > (signed char)0xe25648c2u)) break;
                        continue; (void)(i2);
                        case 2u: ;
                        h0 = (short)(unsigned)((int)(unsigned)b0 < (int)(unsigned)x0);
                    }
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)x0 << (p1 & 31u)), (unsigned)!((unsigned)c1 * 3u), (unsigned)(((unsigned)d0 | i0) == g0)); }
                u0 = (p0 << (0x7fffffffu & 31u));
                while (i2++ < 6u && (9u << (0x548e94b9u & 31u))) { if (--fuel == 0u) goto done;
                    goto L4;
                    if (((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)(w0 >> 29)) * (unsigned)e0)) goto L0;
                    u3 = u3 * 0x9e3779b1u + (unsigned)(w0 >> 29);
                }
                case 4u: ;
            }
            h1 = (unsigned short)(h1 + (v0 * p2));
        }
        { unsigned t1; double z1; if ((0x7fffffffu) & 1u) { t1 = g0; z1 = (double)((0xbd0068aeu) & 255u); } if ((0x7fffffffu) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            e0 = e0 * 0.5L + (long double)(((unsigned)(u1 && (unsigned)l0) + (*mp % (r0.y | 1u))) & 1023u);
        }
        continue; (void)((unsigned)(1u || 0xb29f7d01u));
    }
    switch ((unsigned)((unsigned)(signed char)((unsigned)x0 | 0xffffffffu) || *mp) & 7u) {
        q0 = &garr[((5u - (unsigned)s1) - i1) & 7u];
        case 2u: ;
        i1 = ((unsigned)h0 ? (unsigned)l0 : 9u) & 15u;
        w0 = w0 * 6364136223846793005ull + v0;
        if ((u1 ^ (garr[i1 & 7u] ^ 0x96877aeu))) {
            *q0 = (unsigned)((unsigned)c0 == ~(unsigned)((int)(unsigned)e0 < (int)(unsigned)s1));
            case 0u: ;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)u1 > (signed char)(unsigned)((short)0x80000000u > (signed char)a0[i0 & 3u])), (unsigned)w0, (g1 % ((unsigned)s1 | 1u))); }
            { unsigned t2; double z2; if ((7u) & 1u) { t2 = (unsigned)(unsigned char)(*q0 ^ 4u); z2 = (double)(((0u & ((unsigned)c1 << (u2 & 31u)))) & 255u); } if ((7u) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                *mp = (unsigned)((int)(unsigned)((int)5u >= (int)(unsigned)h0) < (int)2u);
                if ((unsigned)((unsigned)(x0 >> 70) == r0.y)) goto L4;
                g0 = garr[i1 & 7u];
            }
            default: ;
            f0 = f0 * 0.5f + (float)(u2 & 255u);
        } else {
            g1 += (unsigned)(signed char)(((0xffffffffu * (unsigned)(w0 >> 29)) ^ (unsigned)e0) - (m0 / (g0 | 1u)));
            while (i0++ < 7u && u0) { if (--fuel == 0u) goto done;
                continue; (void)((unsigned)(short)(unsigned)(fuel || (unsigned)f0));
                if (budget != 0u) { budget -= 1u; u3 = fn1(a0[u1 & 3u], (0x80000000u + i2), (unsigned)(v0 || u0)); }
                s1 = (int)((unsigned)s1 + (unsigned)(-(0x454abfcfu / (garr[u2 & 7u] | 1u)) == 0x80000000u));
            }
            c1 = (signed char)((unsigned)(3u && (unsigned)c0) >> (*mp & 31u));
        }
        e0 = e0 * 0.5L + (long double)(-(i0 | u2) & 1023u);
    }
    d0 = d0 * 0.5 + (double)(-(((unsigned)c0 * r0.x) + m0) & 1023u);
    goto L2;
    if (budget != 0u) { budget -= 1u; u3 = fn1(u2, (unsigned)((unsigned)((unsigned)e0 || 0x80000000u) < (unsigned)e0), (6u << (0x7fffffffu & 31u))); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    m0 ^= (unsigned)(signed char)(unsigned)((int)(unsigned)c1 >= (int)(unsigned)(fuel && (unsigned)(0x80000000u || 0x80000000u)));
    c0 = (unsigned char)(unsigned)s0;
    while (i0++ < 3u && fuel) { if (--fuel == 0u) goto done;
        if (~(unsigned)((int)0x10000u < (int)(unsigned)(a0[u1 & 3u] || 1u))) break;
        if (8u) break;
        if (budget != 0u) { budget -= 1u; u0 = fn2((0x10000u / ((unsigned)(signed char)(unsigned)((unsigned)s0 < m0) | 1u)), -((unsigned)c1 + ((unsigned)s1 >> (fuel & 31u))), (unsigned)((p1 & 0xe7522aecu) || p1)); }
        { unsigned t0; double z0; if (((unsigned)f0) & 1u) { t0 = (a0[u1 & 3u] << ((0x37c6fc8fu * g1) & 31u)); z0 = (double)(((m0 | (unsigned)e0)) & 255u); } if (((unsigned)f0) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            switch (p1 & 7u) {
                l0 = (long)((unsigned long)l0 + 0x1a5c8fafu);
            }
            q0 = &garr[((unsigned)((unsigned)(g1 || 8u) < 0x10000u) - (unsigned)c0) & 7u];
        }
        if (garr[u2 & 7u]) {
            u1 += (7u << ((unsigned)((6u & 0x7fe93893u) && u0) & 31u));
        } else {
            if ((unsigned)(unsigned char)(u3 % (((unsigned)(w0 >> 29) & garr[u2 & 7u]) | 1u))) goto L4;
        }
        for (;;) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)3u;
            u3 = u3 * 0x9e3779b1u + (unsigned)((unsigned)((unsigned)s0 || 0u) && -(g0 | (unsigned)l0));
            if (((unsigned)e0 ? (unsigned)h1 : 0x7fffffffu)) {
                u1 = u1 * 0x9e3779b1u + (u0 << ((0x323d6ef8u * (unsigned)(4u && (unsigned)c0)) & 31u));
                while ((unsigned)h0) { if (--fuel == 0u) goto done;
                    if (u0) break;
                    m0 ^= (unsigned)((unsigned)(9u && (unsigned)(i2 || r0.y)) || u2);
                    u3 = (0x2ba46ab3u & ((unsigned)d0 ? g0 : 0x8feb76b1u));
                    if ((g1 & *q0)) continue;
                    s0 = (int)((unsigned)(a0[u1 & 3u] && (a0[u1 & 3u] + *q0)) + *q0);
                }
                if (((unsigned)c1 / (fuel | 1u))) break;
                s0 = (int)6u;
                if ((unsigned)((unsigned)c0 == 5u)) {
                    switch (*q0 & 7u) {
                        if (fuel < 8u) return (unsigned)(short)((*q0 << (garr[i1 & 7u] & 31u)) & 0xfcdd5dadu);
                    }
                    if ((unsigned)((unsigned)((int)a0[i0 & 3u] < (int)0x7fffffffu) || (unsigned)s1)) goto L3;
                    *q0 = 0x10000u;
                    u2 = ((unsigned)e0 % (garr[i1 & 7u] | 1u));
                    L0: if (--fuel == 0u) goto done;
                } else {
                    if (((unsigned)((int)p2 < (int)*mp) / (0x51dc0184u | 1u))) break;
                    L1: if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if (~(unsigned)((int)(unsigned)((int)fuel >= (int)(unsigned)c1) < (int)i2)) break;
                        e0 = e0 * 0.5L + (long double)(7u & 1023u);
                    } while (i2++ < 3u && (unsigned)e0);
                }
            } else {
                if ((unsigned)(0xb8a647ebu == 8u)) continue;
                L2: if (--fuel == 0u) goto done;
                i2 = ~(u1 ? 0x24b9df0bu : m0) & 15u;
            }
            c0 = (unsigned char)(unsigned)((int)(r0.y ? (unsigned)h1 : p0) < (int)i1);
            if (v0) {
                if ((0x10000u ? u0 : a0[i0 & 3u])) goto L4;
                v0 = (unsigned)(signed char)(unsigned)(((unsigned)h0 - (unsigned)x0) && 0x273bd9bu);
                g1 += (0x10000u + (g0 ? u2 : r0.y));
                switch ((p1 & i2) & 7u) {
                    q0 = &garr[(0xffffffffu * r0.x) & 7u];
                    if ((~((unsigned)c1 << ((unsigned)d0 & 31u)) << (*mp & 31u))) continue;
                    case 4u: ;
                    w0 ^= (unsigned long long)(unsigned)!(garr[i1 & 7u] + (unsigned)e0) << ((unsigned)(i0 && (unsigned)((int)(g0 / (0x10000u | 1u)) >= (int)(unsigned)!(unsigned)(0x41ff56d8u && u2))) & 63u);
                }
                if ((unsigned)(signed char)(unsigned)((int)v0 < (int)(unsigned)c1)) break;
            }
        }
    }
    if ((unsigned)((short)p1 > (signed char)u0)) {
        f0 = f0 * 0.5f + (float)((((unsigned)((short)p0 > (signed char)~(unsigned)((unsigned)s1 < g1)) + (unsigned)h0) >> (u0 & 31u)) & 255u);
        for (;;) { if (--fuel == 0u) goto done;
            if (u3) goto L4;
            if (*q0) {
                L3: if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + 0xffffffffu;
                if (budget != 0u) { budget -= 1u; u1 = fn0((~(unsigned)(6u || 0x7fffffffu) % (u3 | 1u)), (unsigned)(0xffffffffu == (unsigned)e0), (i0 | (unsigned)(signed char)(unsigned)(*q0 && (unsigned)h1))); }
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)(unsigned)(0xffffffffu == (unsigned)s0) >= (int)(unsigned)s1), *mp, (unsigned)((0x10000u % ((unsigned)(w0 >> 29) | 1u)) || (unsigned)s1)); }
            } else {
                switch ((unsigned)w0 & 7u) {
                    h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(*mp << (r0.y & 31u)));
                    if (0x80000000u) {
                        L4: if (--fuel == 0u) goto done;
                    }
                    case 4u: ;
                    g1 += (r0.y << ((*q0 * g0) & 31u));
                }
                if (budget != 0u) { budget -= 1u; u0 = fn2((*q0 ^ garr[i1 & 7u]), (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)c1), (0xd70a39feu % ((unsigned)(0xffffffffu < 0x7fffffffu) | 1u))); }
            }
            switch ((garr[i1 & 7u] - (unsigned)c1) & 7u) {
                garr[(unsigned)b0 & 7u] = (((unsigned)l0 + r0.x) ^ 8u);
                l0 = (long)((unsigned long)l0 + (*q0 >> ((unsigned)(u2 || 4u) & 31u)));
                *mp = (unsigned)(garr[i1 & 7u] && ((unsigned)!(g1 * u1) & (unsigned)(0x80000000u == (unsigned)w0)));
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)((p1 + m0) + r0.x), (unsigned)(0x10000u < 6u), (*mp << ((unsigned)c0 & 31u))); }
            }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                r0.x = g1;
            }
            break; (void)(p2);
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                s0 = (int)(unsigned)(((unsigned)s1 ^ i0) == u3);
            }
        }
        if (((unsigned)c0 - 0xffffffffu)) goto done;
    }
    if ((unsigned)((int)p0 >= (int)0xffffffffu)) goto L0;
    r0.x = (i0 + (unsigned)(unsigned char)(unsigned)((short)(unsigned)w0 > (signed char)(unsigned)s0));
    goto L1;
    f0 = f0 * 0.5f + (float)(((g0 % ((unsigned)l0 | 1u)) + (v0 ? (unsigned)d0 : *mp)) & 255u);
    x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)s1 < (unsigned)c0);
    u2 ^= (((unsigned)f0 % ((g1 ? (unsigned)c0 : 0xa2daffc5u) | 1u)) ^ p2);
    { unsigned t1; double z1; if ((i2) & 1u) { t1 = p0; z1 = (double)(((unsigned)(g0 == (0x7fffffffu ^ 0x5c302c3du))) & 255u); } if ((i2) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        g1 += (unsigned)((short)(0x7fffffffu + (unsigned)(x0 >> 70)) > (signed char)r0.x);
        if (v0) goto L3;
        u0 = (g1 ^ (unsigned)h1);
        { unsigned t2; double z2; if ((-(unsigned)((m0 + (unsigned)f0) < garr[i1 & 7u])) & 1u) { t2 = (unsigned)f0; z2 = (double)(((i2 | (unsigned)f0)) & 255u); } if ((-(unsigned)((m0 + (unsigned)f0) < garr[i1 & 7u])) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            switch ((0xfd928af7u % (0xffffffffu | 1u)) & 7u) {
                g1 += (unsigned)((int)i2 < (int)(unsigned)(signed char)(unsigned)(0xc5515522u < ((unsigned)b0 % (3u | 1u))));
                if ((unsigned)((u3 - garr[i1 & 7u]) || 3u)) goto L0;
                s1 = (int)((unsigned)s1 + r0.y);
                g1 += u1;
            }
            u3 += (i2 / (*q0 | 1u));
        }
    }
    if ((unsigned)(x0 >> 70)) goto L4;
    if ((r0.y + 0xffffffffu)) {
        { unsigned t3; double z3; if ((((0x7fffffffu ^ 9u) * 0xffffffffu)) & 1u) { t3 = -((unsigned)c1 + garr[u2 & 7u]); z3 = (double)((p1) & 255u); } if ((((0x7fffffffu ^ 9u) * 0xffffffffu)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            w0 = w0 * 6364136223846793005ull + ((unsigned)l0 % ((~(unsigned)((unsigned)s0 == ((unsigned)x0 / ((unsigned)(x0 >> 70) | 1u))) | (unsigned)h0) | 1u));
            c1 = (signed char)~(unsigned)(~(p2 ? garr[u2 & 7u] : (unsigned)f0) == 0x4d26fb90u);
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)c1 >= (int)0xe7ebe4c6u)) {
                    u1 = u1 * 0x9e3779b1u + (a0[i0 & 3u] ^ ((unsigned)s1 & (unsigned)(w0 >> 29)));
                    d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(w0 >> 29) && 0xffffffffu) & 1023u);
                    r0.x = 0x7fffffffu;
                    f0 = f0 * 0.5f + (float)(p2 & 255u);
                } else {
                    w0 = w0 * 6364136223846793005ull + (unsigned)d0;
                }
                u2 += ~(0xb61f40b3u / (u3 | 1u));
                s0 = (int)(0x7fffffffu - (u1 ? (unsigned)c0 : (unsigned)f0));
            }
            b0 = (unsigned)b0 != 0u;
            i2 = (unsigned)((unsigned)(1u || (unsigned)s1) < (u2 % ((unsigned)s0 | 1u))) & 15u;
            if (budget != 0u) { budget -= 1u; u2 = fn2((fuel % (a0[i0 & 3u] | 1u)), u1, (a0[u1 & 3u] * (0xffffffffu % (0x1cf767cau | 1u)))); }
        }
    }
    if ((unsigned)(g1 == v0)) {
        d0 = d0 * 0.5 + (double)(i0 & 1023u);
        r0.y ^= (i1 / (v0 | 1u));
        w0 ^= (unsigned long long)garr[i1 & 7u] << (~(unsigned)((short)((a0[i0 & 3u] % ((unsigned)d0 | 1u)) ^ 1u) > (signed char)~(unsigned)((int)g1 >= (int)0xf018ff30u)) & 63u);
        if ((0u >> (p0 & 31u))) goto L0;
        e0 = e0 * 0.5L + (long double)((0x7fffffffu + ((unsigned)(short)((g1 ^ (unsigned)c1) >> ((unsigned)w0 & 31u)) / ((unsigned)d0 | 1u))) & 1023u);
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(p2 < (g1 ^ 0x80000000u))) {
            l0 = (long)((unsigned long)l0 + i1);
            u0 ^= 0x10000u;
            { unsigned t4; double z4; if ((0xed0550c8u) & 1u) { t4 = ((unsigned)((int)0u >= (int)(unsigned)e0) >> (v0 & 31u)); z4 = (double)(((unsigned)(u2 < g1)) & 255u); } if ((0xed0550c8u) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                { unsigned t5; double z5; if ((g1) & 1u) { t5 = (unsigned)f0; z5 = (double)(((unsigned)((3u ^ 0xec5af80cu) == u0)) & 255u); } if ((g1) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                    r0.y ^= garr[i1 & 7u];
                }
                d0 = d0 * 0.5 + (double)(-((8u & (unsigned)b0) - ((unsigned)((short)*mp > (signed char)(unsigned)c0) / ((unsigned)c0 | 1u))) & 1023u);
                e0 = e0 * 0.5L + (long double)(((unsigned)(w0 >> 29) | ((unsigned)f0 << (0x80000000u & 31u))) & 1023u);
            }
            i0 = 0x80000000u & 15u;
            w0 ^= (unsigned long long)(unsigned)((unsigned)l0 || (unsigned)b0) << (garr[u2 & 7u] & 63u);
        }
        e0 = e0 * 0.5L + (long double)(v0 & 1023u);
        if (*q0) break;
    }
    if ((unsigned)h1) goto L1;
    { unsigned t6; double z6; if (((unsigned)((unsigned)((unsigned)h1 == (unsigned)c1) == i2)) & 1u) { t6 = r0.x; z6 = (double)((((g0 << ((unsigned)d0 & 31u)) * (unsigned)(w0 >> 29))) & 255u); } if (((unsigned)((unsigned)((unsigned)h1 == (unsigned)c1) == i2)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
        *mp = ((a0[u1 & 3u] | *mp) >> ((unsigned)(u1 < (unsigned)h0) & 31u));
        if ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)((unsigned)w0 == 0x7fffffffu))) goto L3;
        while ((0x7fffffffu % ((unsigned)f0 | 1u))) { if (--fuel == 0u) goto done;
            *mp = (-(p0 & 0x10000u) + 0xb1347226u);
            if ((unsigned)b0) goto L2;
            { unsigned t7; double z7; if (((0xd76749b3u >> (-(unsigned)(p2 < i2) & 31u))) & 1u) { t7 = (unsigned)d0; z7 = (double)((((unsigned)c1 | 0x12a89518u)) & 255u); } if (((0xd76749b3u >> (-(unsigned)(p2 < i2) & 31u))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                if ((0x471d417du / ((r0.x & (unsigned)x0) | 1u))) break;
                x0 = x0 * 0x100000001b3ull + (unsigned)(short)((garr[i1 & 7u] | p1) & ~(unsigned)((unsigned)e0 < -(unsigned)((unsigned)c0 == 0x4418eb4du)));
            }
            if ((garr[u2 & 7u] + (unsigned)(0xcce422a1u == 0x966a54b3u))) break;
        }
        u0 += ((unsigned)w0 / (garr[i1 & 7u] | 1u));
        if (garr[i1 & 7u]) goto L2;
        if ((a0[u1 & 3u] & (a0[i0 & 3u] << (v0 & 31u)))) goto L4;
    }
    if ((unsigned)((int)(unsigned)l0 < (int)(unsigned)((short)*q0 > (signed char)0xffffffffu))) {
        if (0x7fffffffu) goto L4;
        switch ((0x10000u * 0x7fffffffu) & 7u) {
            do { if (--fuel == 0u) goto done;
                if (u0) {
                    r0.y ^= (unsigned)(i1 == (unsigned)(signed char)((unsigned)(unsigned char)(unsigned)(3u && (unsigned)b0) + 0u));
                    if (((unsigned)f0 % (g0 | 1u))) continue;
                    case 7u: ;
                } else {
                    d0 = d0 * 0.5 + (double)((unsigned)((*q0 & p1) == ((unsigned)(w0 >> 29) ^ (unsigned)(short)(garr[u2 & 7u] << ((unsigned)l0 & 31u)))) & 1023u);
                    { unsigned t8; double z8; if ((g0) & 1u) { t8 = 4u; z8 = (double)((0x10000u) & 255u); } if ((g0) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                        case 3u: ;
                        i2 = u1 & 15u;
                        case 0u: ;
                    }
                    u2 = (*mp & 0xffffffffu);
                    switch ((unsigned)((short)i1 > (signed char)(unsigned)e0) & 7u) {
                        i2 = ((7u - (m0 % (7u | 1u))) * (unsigned)!(m0 * g1)) & 15u;
                        r0.x = (unsigned)((int)(unsigned)(8u && (0x3f195a5au ? (unsigned)h0 : 0x23b30397u)) < (int)(unsigned)w0);
                    }
                }
                goto L1;
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)!(unsigned)((int)(unsigned)((unsigned)l0 < (unsigned)w0) >= (int)u3), (unsigned)((0xffffffffu << (a0[u1 & 3u] & 31u)) == 0x483f3eefu), p2); }
                continue; (void)((unsigned)s0);
                continue; (void)(v0);
            } while (i0++ < 6u && a0[i0 & 3u]);
        }
        *q0 += (unsigned)(short)(unsigned)(*q0 < (unsigned)e0);
        u3 = u3 * 0x9e3779b1u + (unsigned)((unsigned)c0 == (0xffffffffu * 0u));
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)c0 % ((unsigned)c0 | 1u)), (unsigned)((short)(unsigned)c1 > (signed char)(0x48e6808du + 2u)), m0); }
        if ((unsigned)((unsigned)((int)(unsigned)h0 >= (int)0x7fffffffu) || (unsigned)w0)) goto L3;
    } else {
        *q0 += garr[i1 & 7u];
        if (0x10000u) {
            h0 = (short)(unsigned)(signed char)((0xfadb8706u | i1) >> (r0.x & 31u));
            goto L3;
            switch ((((unsigned)h0 << (v0 & 31u)) | garr[i1 & 7u]) & 7u) {
                v0 = (4u & 0x3170eebbu);
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)((unsigned)(0u && r0.y) < 0x10000u) >= (int)(a0[u1 & 3u] << ((unsigned)e0 & 31u)));
                if ((unsigned)(signed char)(unsigned)((unsigned)h1 < (unsigned)(p1 || p1))) break;
                goto L0;
            }
            if ((unsigned)b0) {
                if ((unsigned)c1) goto L1;
                for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = ((unsigned)((unsigned)(x0 >> 70) || garr[u2 & 7u]) / ((unsigned)((i0 - p0) == (unsigned)(w0 >> 29)) | 1u));
                    continue; (void)(((unsigned)s0 >> ((4u | a0[u1 & 3u]) & 31u)));
                }
            } else {
                u3 = (unsigned)((unsigned)(garr[u2 & 7u] || 0x80000000u) && (p1 >> (garr[i1 & 7u] & 31u)));
                if (0x7fffffffu) goto L2;
                w0 = w0 * 6364136223846793005ull + ((unsigned)h0 & (garr[u2 & 7u] & (u0 << ((unsigned)f0 & 31u))));
            }
        } else {
            x0 = x0 * 0x100000001b3ull + (2u + (6u | ((unsigned)(0xffffffffu && i1) + g0)));
        }
        do { if (--fuel == 0u) goto done;
            *q0 = ((*q0 & 0x80000000u) + i2);
            *mp = (0x3f493fedu / (u3 | 1u));
            garr[(unsigned)(p0 || (unsigned)s0) & 7u] = (r0.x | (unsigned)d0);
            break; (void)(0x10000u);
        } while (i0++ < 5u && (unsigned)((unsigned)((int)r0.y < (int)7u) < *mp));
    }
    if (garr[i1 & 7u]) goto L4;
    if ((unsigned)((short)(unsigned)((int)0xa23e6f2bu >= (int)*q0) > (signed char)0x10000u)) goto L0;
    garr[(unsigned)(w0 >> 29) & 7u] = ((unsigned)((short)i0 > (signed char)(unsigned)s0) ? (unsigned)(x0 >> 70) : p1);
    goto L4;
    u1 = (((0xda885d96u & 1u) << ((unsigned)(signed char)(unsigned)((unsigned)c1 == (unsigned)c0) & 31u)) + 3u);
    i1 = ~(unsigned)((int)*q0 < (int)(unsigned)b0) & 15u;
    goto L4;
    while (i0++ < 2u && (g0 * u0)) { if (--fuel == 0u) goto done;
        if ((unsigned)c1) {
            if ((unsigned)((int)p0 < (int)0x80000000u)) continue;
            h0 = (short)(u0 ? (unsigned)s0 : u1);
            *q0 += ((unsigned)w0 * (unsigned)(signed char)(unsigned)((short)0u > (signed char)(unsigned)h1));
        } else {
            do { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(0u << (0x3af5b2c0u & 31u)) << (((unsigned)h0 ^ (unsigned)((short)0x7fffffffu > (signed char)(unsigned)l0)) & 63u);
                }
            } while (i1++ < 3u && (unsigned)((short)(unsigned)c0 > (signed char)(0x10000u / (0xbc9df496u | 1u))));
            u3 ^= (u2 >> (m0 & 31u));
            if (9u) break;
            c0 = (unsigned char)(((unsigned)s1 ^ (0x2262f932u / (0x890e667eu | 1u))) | ((unsigned)h1 + garr[u2 & 7u]));
        }
        if ((0xffffffffu << (p1 & 31u))) break;
        if (budget != 0u) { budget -= 1u; u0 = fn0((u1 - (unsigned)(x0 >> 70)), (unsigned)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)w0) || p2), (unsigned)(g1 || 0xafb538c9u)); }
        if ((m0 % (0x3b4acc31u | 1u))) break;
        c0 = (unsigned char)((unsigned)h1 * 4u);
    }
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)w0, (unsigned)(0x172f9816u && (unsigned)(short)(5u << ((unsigned)(w0 >> 29) & 31u))), (g0 * (0x81fc0ec8u % (p0 | 1u)))); }
    if ((u0 - (unsigned)((int)v0 >= (int)a0[i0 & 3u]))) goto done;
    goto L0;
    if (budget != 0u) { budget -= 1u; u3 = fn1(3u, garr[u2 & 7u], m0); }
    if (((unsigned)s0 << ((unsigned)d0 & 31u))) goto L0;
    h0 = (short)(r0.y ^ (unsigned)s0);
    u1 += (unsigned)((int)(unsigned)(p2 || (unsigned)(garr[u2 & 7u] || v0)) < (int)(unsigned)c1);
    switch ((unsigned)w0 & 7u) {
        s1 = (int)((unsigned)s1 + 0u);
        c0 = (unsigned char)(garr[u2 & 7u] >> ((fuel | 0x80000000u) & 31u));
        break; (void)(p0);
        case 4u: ;
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)i2 > (signed char)(g0 >> (0x80000000u & 31u))), ((unsigned)e0 ^ (unsigned)(m0 < (unsigned)e0)), ((0x38cf30ebu * r0.x) & 0x80000000u)); }
    }
    if (p1) goto L4;
    b0 = (unsigned)((short)v0 > (signed char)0xc95a987fu) != 0u;
    g0 = ~(fuel - 0xf1208143u);
    f0 = f0 * 0.5f + (float)((unsigned)((int)0xffffffffu >= (int)(unsigned)!(a0[i0 & 3u] / ((g1 | i2) | 1u))) & 255u);
    if ((u1 / (0x4d24dc1eu | 1u))) {
        while (i0++ < 3u && ~((r0.y % (2u | 1u)) % (garr[i1 & 7u] | 1u))) { if (--fuel == 0u) goto done;
            if ((unsigned)l0) goto L3;
            if (budget != 0u) { budget -= 1u; u3 = fn1((0xfd0b69b6u << (2u & 31u)), ((unsigned)(x0 >> 70) - 8u), 0x4254f51fu); }
        }
        switch (v0 & 7u) {
            r0.y ^= (unsigned)((int)(unsigned)(w0 >> 29) >= (int)((unsigned)d0 - (unsigned)e0));
            u0 = (unsigned)((unsigned)((int)0x8c5281ddu < (int)((unsigned)b0 ? i2 : p0)) == u3);
            do { if (--fuel == 0u) goto done;
                u0 = garr[u2 & 7u];
                case 3u: ;
                f0 = f0 * 0.5f + (float)((unsigned)(9u < ~(unsigned)((int)g0 >= (int)(unsigned)!((unsigned)(w0 >> 29) | 0x80000000u))) & 255u);
                if (((unsigned)(x0 >> 70) * g1)) goto L3;
            } while (i0++ < 7u && (unsigned)(*q0 == ((unsigned)f0 & a0[u1 & 3u])));
            while (i0++ < 2u && (u2 + a0[i0 & 3u])) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)*q0 >= (int)2u)) {
                    if (garr[u2 & 7u]) continue;
                    h0 = (short)((unsigned)s1 << (((unsigned)c1 + (r0.y - 0x80000000u)) & 31u));
                }
                a0[(unsigned)(w0 >> 29) & 3u] = (unsigned)b0;
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)e0 | (v0 + (unsigned)(w0 >> 29))), garr[u2 & 7u], (0x7fffffffu >> ((unsigned)(*mp == r0.x) & 31u))); }
                u2 = u2 * 0x9e3779b1u + (unsigned)s0;
                u1 ^= ((unsigned)w0 - (unsigned)!(unsigned)((short)(unsigned)h0 > (signed char)0x7fffffffu));
            }
            r0.y ^= (unsigned)x0;
        }
    }
    while (i0++ < 7u && (unsigned)((unsigned)((int)(unsigned)d0 >= (int)u0) && r0.y)) { if (--fuel == 0u) goto done;
        while ((unsigned)(a0[i0 & 3u] < (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
            { unsigned t9; double z9; if (((unsigned)((int)0x10000u >= (int)(4u * p1))) & 1u) { t9 = (unsigned)((unsigned)(x0 >> 70) && (unsigned)e0); z9 = (double)(((unsigned)(x0 >> 70)) & 255u); } if (((unsigned)((int)0x10000u >= (int)(4u * p1))) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                v0 = garr[u2 & 7u];
                e0 = e0 * 0.5L + (long double)((unsigned)((int)(9u & i0) < (int)(unsigned)((g1 % (0xe82a8ee9u | 1u)) < (unsigned)h1)) & 1023u);
                while ((0x10000u ? (unsigned)d0 : (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                    if ((0x80000000u * garr[u2 & 7u])) break;
                    c1 = (signed char)((fuel ? 0x80000000u : 0x88f1a8d1u) / ((unsigned)!(unsigned)((unsigned)b0 && *mp) | 1u));
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(signed char)(unsigned)((unsigned)(g1 || (unsigned)h1) || r0.y) < (unsigned)(0x7fffffffu == (unsigned)s0)) & 255u);
                }
                c0 = (unsigned char)(g1 << ((unsigned)(signed char)(m0 ? (unsigned)c0 : 0x6706009cu) & 31u));
                l0 = (long)((unsigned long)l0 + (0x58734cb4u ? ((unsigned)h1 << ((unsigned)c0 & 31u)) : (unsigned)w0));
                w0 = w0 * 6364136223846793005ull + (fuel * (unsigned)(0x90c95061u && 7u));
            }
            while (0xffffffffu) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)((short)(unsigned)(short)(*mp & 0x60e18952u) > (signed char)r0.x);
                if ((u1 << (u3 & 31u))) break;
            }
        }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)e0) & 1023u);
        }
        c0 = (unsigned char)(unsigned)((unsigned)((short)2u > (signed char)~(unsigned)(7u || i1)) < 8u);
    }
    if ((unsigned)((unsigned)c0 == u1)) goto L4;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    r0.y ^= (unsigned)((unsigned)!(p0 * *mp) < (0x80000000u + u3));
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1((0xca5a5e4u / ((unsigned)((short)(unsigned)f0 > (signed char)0x4dbb2fb3u) | 1u)), (9u * fuel), (unsigned)(signed char)(unsigned)(fuel == 0x7e731834u)); }
        h0 = (short)((unsigned)c1 + (i2 ? 0x83d05088u : (unsigned)((short)p1 > (signed char)u0)));
    } while (i0++ < 7u && (unsigned)d0);
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn3((0x10000u >> ((unsigned)((unsigned)b0 == i2) & 31u)), (unsigned)((int)i2 < (int)(0x7f4e0ac8u + (unsigned)w0)), (unsigned)((unsigned)s0 == (unsigned)(*q0 && g1))); }
        if ((unsigned)h1) {
            if ((8u ? (unsigned)f0 : r0.y)) continue;
        }
        *q0 += (unsigned)((unsigned)(0xffffffffu < 1u) && 0x12efe28fu);
    }
    s0 = (int)(6u << ((unsigned)((int)(unsigned)h0 >= (int)0xffffffffu) & 31u));
    s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((unsigned)((int)(unsigned)s0 >= (int)(unsigned)(x0 >> 70)) < (i0 % (r0.y | 1u))) < (int)(unsigned)s0));
    u1 += (6u / (g1 | 1u));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    i0 = ((unsigned)h0 >> ((unsigned)((unsigned)b0 < (r0.x & (unsigned)c0)) & 31u)) & 15u;
                }
                if ((a0[i0 & 3u] | *mp)) continue;
                *q0 += ((unsigned)((unsigned)(1u < (unsigned)(w0 >> 29)) || fuel) ? *mp : 0x7fffffffu);
                u0 += (garr[u2 & 7u] ^ (unsigned)s0);
                i0 = (unsigned)e0 & 15u;
                b0 = (unsigned)((int)u1 >= (int)0xd11a4f21u) != 0u;
            }
        } while (i1++ < 6u && (unsigned)(0x4fec2187u || i1));
        w0 ^= (unsigned long long)(unsigned)d0 << ((unsigned)((unsigned)f0 && (unsigned)((unsigned)d0 < (unsigned)(w0 >> 29))) & 63u);
        switch (0x80000000u & 7u) {
            if ((((unsigned)s1 << (g1 & 31u)) + (unsigned)c0)) goto L3;
            if (u1) break;
            goto L0;
            if (((0x12792182u / ((unsigned)s0 | 1u)) << (5u & 31u))) {
                g1 += ((unsigned)!(unsigned)((unsigned)s0 || (unsigned)((int)*mp < (int)(unsigned)!(r0.y * 5u))) * r0.y);
                L0: if (--fuel == 0u) goto done;
                { unsigned t0; double z0; if ((i0) & 1u) { t0 = (unsigned)((unsigned)(x0 >> 70) == ((unsigned)c1 >> (p2 & 31u))); z0 = (double)(((unsigned)h0) & 255u); } if ((i0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    h0 = (short)0xffffffffu;
                    for (;;) { if (--fuel == 0u) goto done;
                        b0 = ((0x9dc33762u << (i0 & 31u)) - (unsigned)((unsigned)h1 || 4u)) != 0u;
                        for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                            r0.x = ((garr[i1 & 7u] * (unsigned)(0x6c54002eu || (unsigned)(x0 >> 70))) * (unsigned)(i0 || r0.x));
                            L1: if (--fuel == 0u) goto done;
                            case 3u: ;
                            if (((0xffffffffu / ((unsigned)d0 | 1u)) % (r0.y | 1u))) continue;
                            v0 = 0u;
                        }
                        w0 = w0 * 6364136223846793005ull + (-((unsigned)(p0 < (unsigned)l0) << ((unsigned)s0 & 31u)) << ((unsigned)d0 & 31u));
                        *q0 += (0xd643e5d6u >> (u1 & 31u));
                        switch ((unsigned)(short)((unsigned)((int)(unsigned)w0 < (int)(unsigned)e0) ^ 0x7fffffffu) & 7u) {
                            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((short)p1 > (signed char)0xeba5b9c4u), (unsigned)((unsigned)(x0 >> 70) < ~((unsigned)l0 << ((unsigned)s1 & 31u))), ((unsigned)e0 >> ((unsigned)c1 & 31u))); }
                            continue; (void)((0xaec05ae1u ? p2 : g1));
                            w0 = w0 * 6364136223846793005ull + ((unsigned)(p0 && a0[i0 & 3u]) | i0);
                            b0 = (unsigned)f0 != 0u;
                            case 1u: ;
                            u3 = u3 * 0x9e3779b1u + ((unsigned)((int)*mp >= (int)u0) ? (u3 | (unsigned)l0) : *mp);
                        }
                        case 1u: ;
                    }
                    default: ;
                }
            } else {
                { unsigned t1; double z1; if ((3u) & 1u) { t1 = (unsigned)((unsigned)x0 && (unsigned)((int)i0 >= (int)0x7fffffffu)); z1 = (double)(((unsigned)((int)(unsigned)w0 < (int)(unsigned)l0)) & 255u); } if ((3u) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    if (((unsigned)h1 * (g0 & fuel))) break;
                    while (i1++ < 5u && 7u) { if (--fuel == 0u) goto done;
                        L2: if (--fuel == 0u) goto done;
                        if ((unsigned)(0x10000u < u3)) break;
                        c0 = (unsigned char)((unsigned)h1 % ((unsigned)l0 | 1u));
                    }
                    break;
                    if ((unsigned)(((unsigned)c0 >> (9u & 31u)) < (unsigned)(x0 >> 70))) break;
                    if ((unsigned)((unsigned)f0 < 0x7fffffffu)) goto done;
                }
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 5u: ;
                    if ((unsigned)((int)((unsigned)e0 * 9u) >= (int)6u)) {
                        if (budget != 0u) { budget -= 1u; u0 = fn3(((unsigned)c0 - *mp), 0x554241c6u, (unsigned)(garr[u2 & 7u] == 0xffffffffu)); }
                    } else {
                        if ((unsigned)((unsigned)e0 || (unsigned)((unsigned)c0 && i0))) {
                            c1 = (signed char)0x80000000u;
                            goto done;
                            g0 = (unsigned)((int)(unsigned)((unsigned)f0 < -(i0 ^ 0x7fffffffu)) < (int)(unsigned)(*mp || 0x10000u));
                            L3: if (--fuel == 0u) goto done;
                            m0 ^= (unsigned)(u3 < *q0);
                        }
                        L4: if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((unsigned)c0 || 0xf8bc73f2u));
                        if ((0x80000000u ? i2 : v0)) break;
                    }
                    if ((g0 - (unsigned)(signed char)(unsigned)((short)m0 > (signed char)0x10000u))) goto done;
                    case 2u: ;
                }
                do { if (--fuel == 0u) goto done;
                    if (0x80000000u) goto L1;
                    case 6u: ;
                    h1 = (unsigned short)(h1 + (unsigned)(p2 == i2));
                    *q0 += 0xffffffffu;
                    c1 = (signed char)p0;
                    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((int)*mp >= (int)(unsigned)(unsigned char)((unsigned)l0 % (7u | 1u))), (unsigned)(short)(p2 - (p1 / (g1 | 1u))), 0xd946beddu); }
                } while (i1++ < 6u && (p2 >> ((unsigned)(w0 >> 29) & 31u)));
            }
            r0.x = (unsigned)((short)(m0 % (((unsigned)h0 + p1) | 1u)) > (signed char)(unsigned)l0);
        }
        if (fuel) {
            break; (void)((6u >> (r0.x & 31u)));
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)i1 >= (int)0x10000u), (garr[u2 & 7u] & 0x1586cc26u), (((unsigned)h0 * 0x7fffffffu) >> (v0 & 31u))); }
            v0 = ~(unsigned)(a0[i0 & 3u] < (unsigned)((unsigned)e0 && 5u));
            if (u3 == 7u) return (garr[i1 & 7u] >> (((unsigned)x0 - (unsigned)e0) & 31u));
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(p2 == (u2 - 0x7fffffffu)), (unsigned)(signed char)((unsigned)(short)(u3 / (g0 | 1u)) ^ (unsigned)h0), (unsigned)((unsigned)(garr[u2 & 7u] == u2) && (unsigned)f0)); }
            l0 = (long)((unsigned long)l0 + ((0x7fffffffu & i1) + (unsigned)b0));
        }
        { unsigned t2; double z2; if ((g1) & 1u) { t2 = ((unsigned)x0 & i2); z2 = (double)(((unsigned)((int)(4u - p2) < (int)0xbed9ec89u)) & 255u); } if ((g1) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            switch ((unsigned)((0x926d0479u + (unsigned)(w0 >> 29)) == g1) & 7u) {
                g0 = (unsigned)c0;
                { unsigned t3; double z3; if ((0xb9bdc8eau) & 1u) { t3 = ((a0[u1 & 3u] & (unsigned)s0) + g0); z3 = (double)(((unsigned)((short)0xae330596u > (signed char)garr[u2 & 7u])) & 255u); } if ((0xb9bdc8eau) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    if ((0x10000u ^ (unsigned)(x0 >> 70))) break;
                    w0 = w0 * 6364136223846793005ull + ((unsigned)c1 & (unsigned)h0);
                    if (u3 == 7u) return (unsigned)(short)(unsigned)((unsigned)s1 || (unsigned)(signed char)(unsigned)((v0 ^ 2u) || r0.y));
                    if (((unsigned)s0 + m0)) continue;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((u1 | *mp), (unsigned)(g1 < 0x7ecb033eu), (unsigned)((short)(u0 & (unsigned)s1) > (signed char)3u)); }
                }
                goto L4;
            }
            switch (((unsigned)b0 + g0) & 7u) {
                switch ((unsigned)(6u && garr[i1 & 7u]) & 7u) {
                    r0.y ^= p2;
                    u2 ^= (((unsigned)((int)p0 < (int)p2) / (a0[i0 & 3u] | 1u)) - (i2 / (r0.x | 1u)));
                    for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        garr[*mp & 7u] = (unsigned)(garr[i1 & 7u] < garr[i1 & 7u]);
                        case 1u: ;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)(unsigned)((short)0xd6e0806du > (signed char)(unsigned)h1) > (signed char)(unsigned)(w0 >> 29)), (unsigned)(x0 >> 70), (unsigned)((unsigned)c0 == 0x5645f7b2u)); }
                    }
                    do { if (--fuel == 0u) goto done;
                        *mp = (unsigned)s0;
                        case 0u: ;
                        do { if (--fuel == 0u) goto done;
                            if (u3 == 7u) return ((unsigned)((int)((unsigned)c0 / ((unsigned)d0 | 1u)) < (int)r0.y) + (v0 * i1));
                            *q0 = ((p0 + (unsigned)((unsigned)(w0 >> 29) && g0)) << (*q0 & 31u));
                            case 3u: ;
                            l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(unsigned)((unsigned)((int)((unsigned)e0 & (r0.y ^ (unsigned)e0)) >= (int)a0[i0 & 3u]) == (unsigned)w0));
                            if ((unsigned)(garr[i1 & 7u] || ((unsigned)s0 - 0x969a57feu))) break;
                        } while (i2++ < 3u && ((p1 / (0x85dc5a14u | 1u)) * u0));
                        w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)c1 >= (int)~(unsigned)((int)(unsigned)c0 >= (int)garr[u2 & 7u]));
                    } while (i1++ < 7u && ((unsigned)s1 * (unsigned)((int)garr[i1 & 7u] < (int)g1)));
                    default: ;
                }
            }
            if ((fuel << (p0 & 31u))) break;
            break; (void)((unsigned)((unsigned)(w0 >> 29) == ((unsigned)(w0 >> 29) ^ 5u)));
        }
        e0 = e0 * 0.5L + (long double)((0x383d9ef3u | ((unsigned)h0 >> (g0 & 31u))) & 1023u);
    }
    g1 += (~((unsigned)!(unsigned)(garr[u2 & 7u] || ~(p0 & (unsigned)f0)) % (i0 | 1u)) & (unsigned)x0);
    *q0 += ((unsigned)!(unsigned)((short)u2 > (signed char)(unsigned)c1) * (unsigned)((int)(unsigned)s0 < (int)0x4a7522e5u));
    if (((garr[u2 & 7u] * 4u) >> (0x10000u & 31u))) {
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0xffffffffu || (unsigned)d0), (unsigned)((short)(unsigned)(u2 || (unsigned)c1) > (signed char)a0[i0 & 3u]), ((unsigned)h1 >> (0x90374f34u & 31u))); }
    } else {
        do { if (--fuel == 0u) goto done;
            h0 = (short)~(unsigned)(*q0 || a0[i0 & 3u]);
            break; (void)((unsigned)((short)(unsigned)h0 > (signed char)p2));
        } while (i0++ < 5u && ((unsigned)((int)i0 < (int)g0) * 0xc5f16e98u));
        if ((unsigned)(w0 >> 29)) goto L4;
    }
    { unsigned t4; double z4; if (((unsigned)((int)0xd5d196u < (int)1u)) & 1u) { t4 = (0xffffffffu | (unsigned)d0); z4 = (double)((p0) & 255u); } if (((unsigned)((int)0xd5d196u < (int)1u)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        { unsigned t5; double z5; if (((u1 << ((unsigned)d0 & 31u))) & 1u) { t5 = (unsigned)(((unsigned)f0 / (r0.y | 1u)) == m0); z5 = (double)((((unsigned)w0 % (*mp | 1u))) & 255u); } if (((u1 << ((unsigned)d0 & 31u))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            x0 = x0 * 0x100000001b3ull + p0;
            f0 = f0 * 0.5f + (float)((unsigned)((int)((unsigned)s1 & 0x80000000u) < (int)0x10000u) & 255u);
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *mp = (unsigned)((0x27479b20u / ((unsigned)(signed char)(0x8db654fbu ? (unsigned)(x0 >> 70) : (unsigned)s1) | 1u)) || 0x8627e0cfu);
                    if (budget != 0u) { budget -= 1u; u3 = fn3(a0[u1 & 3u], ~(0x7374746au >> ((unsigned)(a0[i0 & 3u] && m0) & 31u)), i2); }
                    while ((0x10000u - (*q0 << (p1 & 31u)))) { if (--fuel == 0u) goto done;
                        a0[p1 & 3u] = ((0xd939b812u / ((unsigned)l0 | 1u)) + (unsigned)e0);
                    }
                    u2 = u2 * 0x9e3779b1u + (unsigned)(signed char)(unsigned)(fuel && 0xffffffffu);
                    r0.x = (unsigned)((short)(unsigned)s0 > (signed char)g1);
                }
            }
            s0 = (int)(unsigned)(short)((unsigned)h1 % (i2 | 1u));
            u1 ^= ((unsigned)(short)((unsigned)((unsigned)e0 || r0.y) - fuel) & (unsigned)(m0 && 2u));
            if ((unsigned)((int)i1 >= (int)(unsigned)((unsigned)(w0 >> 29) && fuel))) {
                g1 += 3u;
                u1 = (unsigned)(*q0 || ((unsigned)h1 % (0x80000000u | 1u)));
                u0 += (unsigned)((unsigned)e0 < v0);
                if (budget != 0u) { budget -= 1u; u1 = fn3(((unsigned)w0 / ((unsigned)b0 | 1u)), ((unsigned)(garr[i1 & 7u] == 2u) % (m0 | 1u)), (unsigned)(unsigned char)(unsigned)(8u || (unsigned)(short)(unsigned)(0x80000000u || a0[u1 & 3u]))); }
            } else {
                i2 = ((g1 + ((unsigned)(w0 >> 29) / (u1 | 1u))) / ((unsigned)e0 | 1u)) & 15u;
                i2 = (unsigned)h1 & 15u;
            }
        }
        if ((unsigned)x0) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)g0 >= (int)u0), (u2 * ((unsigned)w0 & r0.x)), (u0 + (unsigned)l0)); }
            s0 = (int)(p1 ^ 0x8efaa556u);
            l0 = (long)((unsigned long)l0 + (0u * -(unsigned)(0x4fe0b724u && ((unsigned)s0 % ((unsigned)w0 | 1u)))));
            if (((unsigned)w0 - (unsigned)((int)(unsigned)l0 >= (int)(unsigned)d0))) goto done;
            if ((unsigned)(-(unsigned)(3u == g0) < p2)) goto done;
        } else {
            d0 = d0 * 0.5 + (double)((unsigned)!((unsigned)h1 | ((unsigned)s1 + (unsigned)(-(unsigned)((int)p0 >= (int)0x10000u) || 0xffffffffu))) & 1023u);
            c0 = (unsigned char)(unsigned)!((0xffffffffu - (unsigned)(i2 < 2u)) * (unsigned)(i0 < (unsigned)h0));
            if (7u) goto done;
        }
        if (((unsigned)l0 % (((unsigned)x0 & a0[u1 & 3u]) | 1u))) goto L0;
    }
    if ((((unsigned)f0 + (unsigned)f0) ^ 5u)) goto L3;
    if ((unsigned)(p1 == p0)) goto L2;
    if ((unsigned)h0) goto L0;
    if ((u1 % (garr[i1 & 7u] | 1u))) {
        do { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)!(unsigned)((int)((unsigned)d0 << ((unsigned)c1 & 31u)) < (int)u3)) break;
                if ((unsigned)((int)r0.y < (int)garr[u2 & 7u])) break;
                r0.y ^= (0x10000u | (unsigned)(unsigned char)(a0[i0 & 3u] ? 0xb6d6b8c3u : p1));
                *q0 = ((unsigned)(signed char)(unsigned)((int)i1 < (int)(unsigned)(0x7b05cbd2u == 3u)) >> (i2 & 31u));
                if ((unsigned)c1) break;
            }
            { unsigned t6; double z6; if ((((unsigned)(unsigned char)(unsigned)((int)i1 < (int)g0) ^ 0x80000000u)) & 1u) { t6 = (unsigned)((*q0 ^ i0) < (unsigned)(w0 >> 29)); z6 = (double)(((unsigned)c1) & 255u); } if ((((unsigned)(unsigned char)(unsigned)((int)i1 < (int)g0) ^ 0x80000000u)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                do { if (--fuel == 0u) goto done;
                    *mp = ((0x7fffffffu % (0x3be40641u | 1u)) >> ((unsigned)((unsigned)s1 < u0) & 31u));
                    break; (void)(u1);
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)b0, ((u3 + (unsigned)h1) % ((unsigned)(x0 >> 70) | 1u)), (unsigned)((int)((unsigned)(w0 >> 29) * 0xce154bacu) >= (int)i1)); }
                    *q0 = (u1 - (unsigned)h0);
                } while (i1++ < 4u && (unsigned)d0);
                *q0 += (unsigned)!((u0 * ((unsigned)(w0 >> 29) << ((unsigned)(u2 || r0.x) & 31u))) * 3u);
            }
            d0 = d0 * 0.5 + (double)(8u & 1023u);
        } while (i0++ < 6u && (unsigned)((int)(unsigned)c1 < (int)(*q0 / (garr[i1 & 7u] | 1u))));
        if ((8u ? 0x10000u : 0x4c8bb1f3u)) goto L4;
    } else {
        if (u3 == 7u) return (0xa617656fu ? 2u : (0xdffaa939u >> (((unsigned)d0 & (unsigned)s1) & 31u)));
        { unsigned t7; double z7; if (((unsigned)((int)(unsigned)s1 >= (int)(unsigned)(garr[i1 & 7u] && (unsigned)s1))) & 1u) { t7 = ((unsigned)(x0 >> 70) + m0); z7 = (double)((((unsigned)e0 << (0xfd09adcfu & 31u))) & 255u); } if (((unsigned)((int)(unsigned)s1 >= (int)(unsigned)(garr[i1 & 7u] && (unsigned)s1))) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn3((a0[u1 & 3u] - (p2 >> (5u & 31u))), ((unsigned)((int)garr[u2 & 7u] < (int)*q0) / (p2 | 1u)), (unsigned)((unsigned)(unsigned char)(garr[i1 & 7u] * g0) < garr[u2 & 7u])); }
            }
            v0 = (unsigned)(((unsigned)l0 >> ((0x80000000u / (0x3e80b785u | 1u)) & 31u)) == (0x80000000u - *mp));
            if (0x6f3010c8u) goto done;
            if (((unsigned)(w0 >> 29) >> ((unsigned)h1 & 31u))) goto L3;
        }
    }
    c1 = (signed char)(unsigned)((short)garr[u2 & 7u] > (signed char)0x80000000u);
    if ((unsigned)((short)(unsigned)h0 > (signed char)(0xffffffffu | p2))) {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (g1) continue;
            break; (void)((unsigned)((unsigned)(short)(unsigned)((int)m0 >= (int)(unsigned)c1) && u2));
            s0 = (int)(0xc5ca8931u % (p2 | 1u));
            if ((unsigned)(fuel && (unsigned)w0)) {
                if ((0x776e3746u >> ((unsigned)((int)0xf064dfd4u >= (int)(unsigned)d0) & 31u))) goto L2;
                if (((unsigned)((unsigned)x0 || (unsigned)s1) ^ (unsigned)s0)) continue;
            } else {
                u3 ^= (unsigned)((int)(unsigned)c0 < (int)a0[i0 & 3u]);
            }
            r0.x = (unsigned)((unsigned)c0 < *q0);
            if (garr[u2 & 7u]) {
                if ((0xffffffffu * (unsigned)((int)0x5354f11fu < (int)g0))) break;
                m0 ^= ((unsigned)((int)(unsigned)!(0x9f3f018cu | 4u) < (int)(a0[i0 & 3u] / (u0 | 1u))) & 0x10000u);
                v0 = (unsigned)(signed char)(unsigned)(a0[u1 & 3u] || 0x10000u);
                if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)h0, (unsigned)((unsigned)(short)(unsigned)(i1 == 0x80000000u) == 6u), (unsigned)((unsigned)((int)u1 < (int)0xd2fb05a7u) || (unsigned)c1)); }
                b0 = (unsigned)((2u % ((unsigned)(w0 >> 29) | 1u)) < (unsigned)d0) != 0u;
                switch (*mp & 7u) {
                    case 6u: ;
                    case 4u: ;
                    if ((u1 / ((unsigned)(signed char)(unsigned)(0xffffffffu == (unsigned)x0) | 1u))) {
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((0x7fffffffu ^ 4u) | 0xec7561f2u), (unsigned)((unsigned)h0 && 0xbe779231u), ((unsigned)h0 & a0[i0 & 3u])); }
                        case 3u: ;
                        if (g0) continue;
                        goto L2;
                        r0.y ^= (unsigned)(unsigned char)(~((unsigned)d0 ^ garr[i1 & 7u]) ^ 0x10000u);
                        garr[((unsigned)s1 & p2) & 7u] = (unsigned)(0x10000u && (unsigned)l0);
                    }
                }
            } else {
                if (fuel < 8u) return (unsigned)((short)(p1 * (unsigned)b0) > (signed char)(unsigned)f0);
                break; (void)(((unsigned)(x0 >> 70) * (unsigned)(unsigned char)(0x79270c3eu * fuel)));
                if (fuel < 8u) return (unsigned)((int)(unsigned)(6u && 0x10000u) >= (int)(unsigned)d0);
            }
        }
        if ((unsigned)((int)(p1 * r0.y) < (int)garr[i1 & 7u])) goto L2;
        f0 = f0 * 0.5f + (float)(((unsigned)(w0 >> 29) & r0.y) & 255u);
    }
    if ((unsigned)w0) goto L3;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)(unsigned)c0;
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    v0 = (3u ^ (unsigned)(g0 == 0x10000u));
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        c1 = (signed char)((unsigned)e0 & (unsigned)((unsigned)(short)((unsigned)c0 * u1) == g1));
                    }
                    c0 = (unsigned char)((unsigned)c0 ^ 0xef97630u);
                } while (i0++ < 3u && (r0.x >> ((2u + garr[i1 & 7u]) & 31u)));
                if ((unsigned)((short)u2 > (signed char)(unsigned)((int)(unsigned)s1 >= (int)u1))) break;
                if (u2) break;
                x0 = x0 * 0x100000001b3ull + ((unsigned)l0 >> ((unsigned)s1 & 31u));
                h0 = (short)(unsigned)s1;
                { unsigned t8; double z8; if (((a0[i0 & 3u] ^ (unsigned)((short)a0[i0 & 3u] > (signed char)garr[i1 & 7u]))) & 1u) { t8 = u1; z8 = (double)((0x63cc6576u) & 255u); } if (((a0[i0 & 3u] ^ (unsigned)((short)a0[i0 & 3u] > (signed char)garr[i1 & 7u]))) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                    c1 = (signed char)((a0[i0 & 3u] * g1) * u2);
                    if ((unsigned)((int)(unsigned)l0 < (int)9u)) break;
                }
            }
            b0 = (v0 / (a0[i0 & 3u] | 1u)) != 0u;
            l0 = (long)((unsigned long)l0 + (unsigned)((short)garr[i1 & 7u] > (signed char)g0));
            if (budget != 0u) { budget -= 1u; u3 = fn1(r0.y, u3, ~(0x7fffffffu ^ 0x8694ed33u)); }
        }
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && r0.y) { if (--fuel == 0u) goto done;
            if (p2) {
                r0.y ^= ((unsigned)f0 % ((unsigned)(((unsigned)e0 << (a0[u1 & 3u] & 31u)) && ((unsigned)x0 % (r0.x | 1u))) | 1u));
                r0.x = (a0[i0 & 3u] / (u0 | 1u));
                do { if (--fuel == 0u) goto done;
                    break; (void)(0xf430bfb1u);
                    if (u0) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)((int)0xb09f30beu >= (int)m0) & 0xffffffffu), 0x53b1d87u, 0xaea44a65u); }
                } while (i2++ < 7u && (g1 / (8u | 1u)));
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)(garr[i1 & 7u]);
                    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)c1) break;
                        m0 ^= (((unsigned)s0 % (0xaa6eea3eu | 1u)) << ((unsigned)s1 & 31u));
                        e0 = e0 * 0.5L + (long double)((unsigned)(0x7fffffffu == ((unsigned)(w0 >> 29) & ((unsigned)(u1 || 5u) >> ((unsigned)e0 & 31u)))) & 1023u);
                        if (i0) {
                            u1 += (unsigned)(short)((unsigned)(v0 || (0x541f68aau - *mp)) - (p2 ^ u2));
                            if (0x25b1c984u) continue;
                            h0 = (short)(unsigned)(short)(0xf1478aa9u / (~((r0.y | 0xffffffffu) >> (0x80000000u & 31u)) | 1u));
                            if (((unsigned)b0 << (a0[i0 & 3u] & 31u))) continue;
                        }
                        if ((0xffffffffu | 6u)) goto L0;
                        goto L2;
                    }
                    q0 = &garr[(((unsigned)((int)0x80000000u < (int)u0) << (r0.x & 31u)) / (g1 | 1u)) & 7u];
                    if (~(unsigned)((int)i1 >= (int)0x5db86c05u)) {
                        r0.x = g1;
                        if (((unsigned)x0 | u0)) goto done;
                        if (((unsigned)x0 * (unsigned)c1)) goto L0;
                    }
                    if ((0xffffffffu ^ (unsigned)h0)) goto L4;
                    continue; (void)(((unsigned)h1 * 6u));
                }
                s0 = (int)((unsigned)l0 - (7u - (unsigned)((int)(unsigned)w0 < (int)a0[u1 & 3u])));
            }
            w0 ^= (unsigned long long)(unsigned)((unsigned)h1 || (unsigned)h0) << ((unsigned)((fuel | (unsigned)b0) && 0u) & 63u);
            g1 += (unsigned)h1;
            if (u3 == 7u) return ((unsigned)d0 - garr[i1 & 7u]);
            break; (void)((unsigned)(short)(i2 + (unsigned)(unsigned char)(unsigned)(p0 && 0x461d42dfu)));
            if (a0[i0 & 3u]) break;
        }
    }
    goto L1;
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)f0, (unsigned)h1, 0xa77d5165u); }
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)(w0 >> 29) < u3);
            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((unsigned)e0 == u0) >> (4u & 31u)), (unsigned)s0, -(((unsigned)s0 % ((unsigned)h0 | 1u)) * a0[u1 & 3u])); }
            if ((unsigned)(0xf7e1c699u || u2)) {
                if (budget != 0u) { budget -= 1u; u2 = fn0(u1, (unsigned)((unsigned)!(u2 - 0x80000000u) || *mp), (r0.x >> (1u & 31u))); }
                h1 = (unsigned short)(h1 + (g1 | u0));
                if ((unsigned)((short)((unsigned)h1 + a0[i0 & 3u]) > (signed char)m0)) goto L1;
                l0 = (long)((unsigned long)l0 + (unsigned)(((0xe3d55cb3u | (unsigned)c0) - (unsigned)h0) < ((unsigned)h1 >> (0x7fffffffu & 31u))));
                break; (void)(((0x67eaae37u - (unsigned)c1) ^ g1));
                if (fuel) goto L3;
            } else {
                u0 ^= (unsigned)(short)((0x8a6b2c09u << (0x186930d5u & 31u)) << (0xffffffffu & 31u));
                if (0x6ddd4d3fu) {
                    if ((unsigned)(w0 >> 29)) break;
                    a0[((unsigned)l0 - g1) & 3u] = (unsigned)((short)(i0 | fuel) > (signed char)(u3 - (unsigned)d0));
                    if ((unsigned)c1) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((0x80000000u * i1), ((r0.y | (unsigned)h1) % (0x3e71833fu | 1u)), 0xdb1d6091u); }
                    e0 = e0 * 0.5L + (long double)(0x80000000u & 1023u);
                    x0 = x0 * 0x100000001b3ull + i0;
                }
                d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)(u2 == fuel) * g1) < r0.y) & 1023u);
            }
            s0 = (int)(unsigned)(unsigned char)((unsigned)((short)v0 > (signed char)(p0 >> ((unsigned)s0 & 31u))) - (unsigned)(g0 || 4u));
        }
    } while (i0++ < 5u && (unsigned)((a0[i0 & 3u] - a0[u1 & 3u]) < (unsigned)c0));
    switch ((unsigned)!(u3 * 8u) & 7u) {
        if (0x10000u) goto L0;
        while (i0++ < 2u && ((unsigned)(unsigned char)(unsigned)((int)*q0 >= (int)2u) << (i1 & 31u))) { if (--fuel == 0u) goto done;
            { unsigned t9; double z9; if (((unsigned)(r0.x == ((unsigned)w0 & 3u))) & 1u) { t9 = (a0[u1 & 3u] & (0x1d0fe2d3u / (a0[u1 & 3u] | 1u))); z9 = (double)(((unsigned)l0) & 255u); } if (((unsigned)(r0.x == ((unsigned)w0 & 3u))) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                break; (void)(((unsigned)b0 / ((unsigned)((int)5u >= (int)r0.y) | 1u)));
                a0[u0 & 3u] = ((unsigned)((short)(unsigned)s1 > (signed char)a0[i0 & 3u]) ^ (unsigned)(~(0x80b670bbu / (3u | 1u)) && 0x80000000u));
                do { if (--fuel == 0u) goto done;
                    u3 = (u1 >> (5u & 31u));
                    case 4u: ;
                } while (i1++ < 4u && (0xb4bd621eu ^ 0x8c3f1a3bu));
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = (unsigned)((unsigned)s1 && (garr[i1 & 7u] ? (unsigned)s1 : (unsigned)d0));
                    case 5u: ;
                    i0 = (unsigned)(((i1 >> ((unsigned)b0 & 31u)) / (-((unsigned)s1 >> (*q0 & 31u)) | 1u)) < 8u) & 15u;
                }
                *q0 += (unsigned)!(u2 >> ((u3 ? a0[u1 & 3u] : a0[i0 & 3u]) & 31u));
                v0 = -((unsigned)((a0[i0 & 3u] & (unsigned)h1) == p1) - (unsigned)(p0 || (unsigned)s1));
            }
            if ((0x7fffffffu >> ((unsigned)h0 & 31u))) continue;
            case 7u: ;
        }
    }
    switch ((a0[u1 & 3u] ? (unsigned)x0 : *mp) & 7u) {
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)c1 & p0)) goto L2;
            case 3u: ;
            c0 = (unsigned char)4u;
        }
        break; (void)((unsigned)(garr[i1 & 7u] || p0));
        { unsigned t10; double z10; if (((g0 >> ((unsigned)(short)(unsigned)(*mp == 0x10000u) & 31u))) & 1u) { t10 = (i0 / (0x6cc639fbu | 1u)); z10 = (double)(((unsigned)(p1 || (0x67582f3au | garr[i1 & 7u]))) & 255u); } if (((g0 >> ((unsigned)(short)(unsigned)(*mp == 0x10000u) & 31u))) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)l0, (p2 & u0), (unsigned)(a0[i0 & 3u] < 0xaa004089u)); }
            break; (void)((unsigned)(g0 || g0));
            if (budget != 0u) { budget -= 1u; u3 = fn1((0x10000u << (r0.y & 31u)), ((unsigned)(unsigned char)((unsigned)f0 | g1) & (unsigned)h0), g1); }
        }
        for (;;) { if (--fuel == 0u) goto done;
            case 1u: ;
            case 2u: ;
        }
        g1 += (unsigned)((int)8u < (int)2u);
        do { if (--fuel == 0u) goto done;
            garr[0xe3b77f1eu & 7u] = (unsigned)(unsigned char)(unsigned)((unsigned)(0xc4c7ac9au || a0[u1 & 3u]) == (unsigned)c0);
            u0 += (unsigned)((unsigned)c0 == 0xc60da5aeu);
            f0 = f0 * 0.5f + (float)((0x2ebf3665u * (unsigned)((int)garr[i1 & 7u] < (int)0x8f0dbe3u)) & 255u);
            switch ((unsigned)(w0 >> 29) & 7u) {
                break; (void)((9u * (unsigned)s0));
                if ((garr[i1 & 7u] << (i2 & 31u))) goto done;
            }
        } while (i0++ < 5u && i1);
    }
    switch (4u & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn1(u2, i1, (unsigned)d0); }
        c0 = (unsigned char)(unsigned)((short)i1 > (signed char)(unsigned)((int)(unsigned)(signed char)(garr[u2 & 7u] << (2u & 31u)) < (int)7u));
        c1 = (signed char)(unsigned)f0;
        w0 ^= (unsigned long long)(r0.x + i1) << ((unsigned)((int)~(((unsigned)(w0 >> 29) / (p2 | 1u)) * 5u) >= (int)(unsigned)(i0 && 2u)) & 63u);
        case 5u: ;
    }
    w0 ^= (unsigned long long)((unsigned)s0 | u2) << ((unsigned)w0 & 63u);
    while (i0++ < 4u && ((unsigned)(x0 >> 70) << ((unsigned)c1 & 31u))) { if (--fuel == 0u) goto done;
        if (((unsigned)(0x10000u < i1) << (0x3126b95au & 31u))) {
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch ((unsigned)((unsigned)(x0 >> 70) || (unsigned)s1) & 7u) {
                    for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        goto L2;
                        h0 = (short)(unsigned)h1;
                        s0 = (int)((*q0 ? a0[u1 & 3u] : fuel) >> (3u & 31u));
                        s0 = (int)(r0.y | (unsigned)f0);
                        case 6u: ;
                    }
                    while (((unsigned)((short)(unsigned)e0 > (signed char)0x7fffffffu) | m0)) { if (--fuel == 0u) goto done;
                        g0 = (unsigned)((unsigned)c0 == (((unsigned)s0 | ((unsigned)x0 * fuel)) << (i1 & 31u)));
                        if (i2) goto L4;
                        case 7u: ;
                        s1 = (int)((unsigned)s1 + (unsigned)d0);
                        s1 = (int)((unsigned)s1 + 1u);
                    }
                    case 3u: ;
                    i1 = (0xffffffffu ? (a0[i0 & 3u] + i2) : *mp) & 15u;
                    *q0 = (unsigned)((short)u1 > (signed char)i1);
                    default: ;
                }
                break; (void)((unsigned)(*mp == (unsigned)(short)(u3 >> ((unsigned)(w0 >> 29) & 31u))));
                if (u3 == 7u) return 0xbd1b2900u;
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    u3 ^= (unsigned)(7u || 0xffffffffu);
                    u0 += (u1 - (((unsigned)(x0 >> 70) / (p1 | 1u)) - u3));
                    if ((unsigned)((int)g0 >= (int)u2)) continue;
                    *q0 += (((unsigned)(x0 >> 70) ? (unsigned)(signed char)(0x13f2186eu << ((unsigned)f0 & 31u)) : 0x10000u) << ((unsigned)f0 & 31u));
                    v0 = ((unsigned)((short)0x297c3e40u > (signed char)1u) & g1);
                }
            }
            v0 = (*q0 / ((unsigned)h0 | 1u));
            if ((unsigned)((short)m0 > (signed char)((unsigned)s1 | (unsigned)e0))) break;
            l0 = (long)((unsigned long)l0 + ((a0[i0 & 3u] - (0xffffffffu ? 8u : 0u)) * 0x80000000u));
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)g1 < (int)fuel), (9u | 0x80000000u), (p1 & i1)); }
            if (budget != 0u) { budget -= 1u; u1 = fn3(2u, u2, (g0 % ((unsigned)(x0 >> 70) | 1u))); }
        }
        if ((unsigned)l0) {
            do { if (--fuel == 0u) goto done;
                s0 = (int)-(a0[u1 & 3u] - (unsigned)((int)i1 >= (int)0x10000u));
            } while (i1++ < 4u && (0x3c753741u ^ (unsigned)((int)g1 >= (int)(unsigned)c0)));
        }
        if (6u) break;
        if ((unsigned)(0x5e96c16au && *mp)) goto L2;
        l0 = (long)((unsigned long)l0 + (6u & (unsigned)(i2 && (unsigned)h1)));
    }
    { unsigned t11; double z11; if (((r0.y % ((*mp & garr[u2 & 7u]) | 1u))) & 1u) { t11 = (unsigned)((int)(unsigned)((int)0xd6ccf79eu < (int)p1) < (int)(unsigned)s0); z11 = (double)(((unsigned)((int)(0x10000u | u2) < (int)(unsigned)d0)) & 255u); } if (((r0.y % ((*mp & garr[u2 & 7u]) | 1u))) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
        w0 = w0 * 6364136223846793005ull + (3u * (5u | (unsigned)l0));
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((short)u2 > (signed char)(unsigned)((int)i2 < (int)0x7fffffffu))) continue;
            do { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    break; (void)(-(unsigned)((short)(unsigned)(0u == g1) > (signed char)(unsigned)h1));
                    if ((unsigned)!(unsigned)(u2 == (u2 + fuel))) continue;
                    while (6u) { if (--fuel == 0u) goto done;
                        break; (void)(g1);
                        r0.y ^= (u2 & ((garr[i1 & 7u] - (0xdd742d6du & 0x80000000u)) >> ((unsigned)s1 & 31u)));
                        if (budget != 0u) { budget -= 1u; u0 = fn0(0x3d52d781u, ((unsigned)w0 * (unsigned)((int)(unsigned)x0 < (int)u1)), (unsigned)((short)(unsigned)s0 > (signed char)0x80000000u)); }
                        if (budget != 0u) { budget -= 1u; u1 = fn1((0x775f86a8u ? 0xffffffffu : i2), (unsigned)(signed char)((unsigned)s0 & 0xbc3d5ed5u), garr[u2 & 7u]); }
                        for (;;) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(0x80000000u || 0x1e364739u), r0.y, (unsigned)((int)3u >= (int)(unsigned)c1)); }
                            if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)((unsigned)(w0 >> 29) == *q0) << (0x51754bd1u & 31u)), (unsigned)((int)(unsigned)d0 < (int)(0x7fffffffu >> (garr[u2 & 7u] & 31u))), (unsigned)(u2 && i2)); }
                            if ((unsigned)s1) break;
                            h0 = (short)(2u - (0x10000u * (u1 % (0x309c2bf8u | 1u))));
                            a0[garr[i1 & 7u] & 3u] = (unsigned)((int)0x3372e6d8u < (int)(unsigned)(short)((unsigned)x0 + (unsigned)((unsigned)h0 == (unsigned)w0)));
                            x0 = x0 * 0x100000001b3ull + (unsigned)((int)(a0[u1 & 3u] << (0x19bd2855u & 31u)) >= (int)u1);
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)((unsigned)(garr[i1 & 7u] || (unsigned)(w0 >> 29)) | u3), (p0 >> (0xffffffffu & 31u)), (unsigned)(short)(0x803b1ea0u >> ((unsigned)e0 & 31u))); }
                    }
                    while (i0++ < 6u && i0) { if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)((*mp & ~((unsigned)l0 % (a0[i0 & 3u] | 1u))) & 1023u);
                    }
                } while (i2++ < 7u && (((unsigned)s0 / (7u | 1u)) ^ r0.y));
                *q0 = (0xffffffffu | ((5u & (0x10000u | fuel)) / (0x82bd0fau | 1u)));
                switch (p0 & 7u) {
                    switch (*q0 & 7u) {
                        if ((4u * *q0)) continue;
                        f0 = f0 * 0.5f + (float)((unsigned)((short)(unsigned)((int)p2 >= (int)(unsigned)s0) > (signed char)v0) & 255u);
                        while (i2++ < 3u && (((unsigned)x0 << ((unsigned)c1 & 31u)) >> ((unsigned)(w0 >> 29) & 31u))) { if (--fuel == 0u) goto done;
                            continue; (void)((unsigned)b0);
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0x10000u == (0x7fffffffu & v0)), (unsigned)s0, (unsigned)(x0 >> 70)); }
                            s1 = (int)((unsigned)s1 + (unsigned)h1);
                            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(signed char)(unsigned)((unsigned)l0 && g1), (v0 | (0xcc921b20u << ((unsigned)(w0 >> 29) & 31u))), (garr[u2 & 7u] - (unsigned)s0)); }
                            goto L3;
                            case 4u: ;
                        }
                    }
                }
                if ((u1 >> (0xca09e8d2u & 31u))) {
                    if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)(u2 && (unsigned)((short)u2 > (signed char)6u)), (garr[u2 & 7u] | ((unsigned)l0 / (p2 | 1u))), (unsigned)((short)(unsigned)((int)(unsigned)s0 >= (int)(unsigned)h1) > (signed char)0xffffffffu)); }
                    while ((unsigned)(0x6ac81bf0u == p2)) { if (--fuel == 0u) goto done;
                        r0.y ^= (unsigned)(unsigned char)((garr[i1 & 7u] / (u3 | 1u)) / (a0[i0 & 3u] | 1u));
                        if (u3 == 7u) return (unsigned)((int)(*q0 ? (unsigned)c0 : (unsigned)(x0 >> 70)) >= (int)(0x31ffd4cfu & (unsigned)l0));
                        c1 = (signed char)((unsigned)s0 / (0x10000u | 1u));
                        if (budget != 0u) { budget -= 1u; u0 = fn1(((0xffffffffu - g1) >> ((unsigned)h0 & 31u)), (unsigned)((short)(a0[i0 & 3u] - fuel) > (signed char)i2), r0.x); }
                        *q0 = (p1 * (unsigned)h1);
                        c0 = (unsigned char)((*mp >> (2u & 31u)) / ((unsigned)(r0.y && r0.x) | 1u));
                    }
                    if ((unsigned)!(unsigned)(p0 && (0xffffffffu % (0xeef3723u | 1u)))) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn3((u1 | (unsigned)(garr[u2 & 7u] || u2)), (unsigned)((int)0x7fffffffu < (int)0x7bad865u), 0x7fffffffu); }
                    if ((*q0 << (0x9c539b32u & 31u))) goto L2;
                    *mp = (((unsigned)s1 - a0[u1 & 3u]) - (unsigned)c1);
                } else {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((v0 | (unsigned)s1), 2u, p2); }
                    if (r0.x) break;
                }
            } while (i1++ < 3u && garr[u2 & 7u]);
        } while (i0++ < 4u && ((unsigned)(0x80000000u || p0) - garr[u2 & 7u]));
        if (budget != 0u) { budget -= 1u; u2 = fn3(fuel, (a0[i0 & 3u] & ((unsigned)s0 << (v0 & 31u))), ((unsigned)(w0 >> 29) + u1)); }
        if ((u1 ^ r0.x)) goto L4;
        while (0xa5b3b0f0u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)(w0 >> 29) || (i0 * 0x80000000u))) goto L0;
        }
    }
    while (i0++ < 2u && (0x3c9a5142u * (fuel & 0x10000u))) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)((int)7u >= (int)0x7fffffffu) & 1023u);
        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)l0 && (unsigned)b0) & 1023u);
        a0[(unsigned)(signed char)(a0[u1 & 3u] ^ (unsigned)c0) & 3u] = (garr[i1 & 7u] & (unsigned)(signed char)(0x10000u ^ (unsigned)((int)(unsigned)((int)0xffffffffu >= (int)(unsigned)s0) < (int)u3)));
        g0 = (0xffffffffu / ((unsigned)c0 | 1u));
        c0 = (unsigned char)(g1 & (unsigned)(6u < (unsigned)x0));
    }
    i2 = ((g0 / (2u | 1u)) >> ((unsigned)c1 & 31u)) & 15u;
    r0.x = (unsigned)(short)((unsigned)d0 >> ((unsigned)(((unsigned)x0 + (unsigned)s0) && (unsigned)b0) & 31u));
    *q0 += 0xffffffffu;
    switch ((unsigned)(unsigned char)(unsigned)((int)(unsigned)s1 >= (int)9u) & 7u) {
        *q0 = 0x12e7446cu;
        b0 = (unsigned)(0x39f174e2u && *q0) != 0u;
        if ((unsigned)((short)(unsigned)((short)r0.y > (signed char)(unsigned)d0) > (signed char)0x7fffffffu)) goto L3;
        if ((unsigned)(short)(garr[u2 & 7u] & 0x7fffffffu)) {
            if ((unsigned)((int)garr[i1 & 7u] < (int)7u)) goto done;
            if (0x90c06272u) {
                case 1u: ;
            }
            case 5u: ;
            switch ((unsigned)((int)p2 >= (int)0x3400a4e5u) & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn2(u3, (v0 & (7u & (unsigned)c1)), ((unsigned)(short)(0u & 0x80000000u) & i2)); }
                case 3u: ;
                case 4u: ;
                *q0 = (4u - ((unsigned)l0 - garr[u2 & 7u]));
            }
        } else {
            goto L2;
        }
        g0 = -(m0 & (unsigned)f0);
        r0.x = (*mp ? 0x3feda881u : v0);
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((short)r0.y > (signed char)(r0.y >> (a0[i0 & 3u] & 31u)))) {
            s0 = (int)((*q0 >> (a0[i0 & 3u] & 31u)) << ((p2 >> (*q0 & 31u)) & 31u));
            while (i1++ < 7u && (unsigned)((int)(unsigned)(p0 == i2) >= (int)0x8d1c0fedu)) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(signed char)(unsigned)(g0 && u0)) goto L4;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)(unsigned)f0 > (signed char)v0), ((unsigned)(w0 >> 29) / ((unsigned)((short)0x10000u > (signed char)0x64001b79u) | 1u)), (r0.x * 0xffffffffu)); }
                }
                if ((unsigned)(unsigned char)(0x998897bfu >> (((unsigned)c1 * i1) & 31u))) break;
                if ((0x10000u >> (u0 & 31u))) break;
                if (0xa297bd2fu) {
                    u3 += (unsigned)((int)3u < (int)(i2 % ((unsigned)c1 | 1u)));
                    r0.x = (unsigned)d0;
                    if (((unsigned)(w0 >> 29) ? g0 : 0xb5d580b4u)) break;
                    w0 ^= (unsigned long long)(unsigned)((int)8u >= (int)5u) << ((p2 >> (5u & 31u)) & 63u);
                    garr[((unsigned)s1 & (unsigned)f0) & 7u] = ((unsigned)((unsigned)b0 == ((unsigned)h1 & (unsigned)(u0 && (unsigned)s1))) + u1);
                }
                break; (void)((unsigned)((int)0xc0e0d8a4u >= (int)(unsigned)c0));
                u0 += (v0 << (i0 & 31u));
            }
            { unsigned t12; double z12; if (((p0 % (u2 | 1u))) & 1u) { t12 = 0x80000000u; z12 = (double)(((u3 + p2)) & 255u); } if (((p0 % (u2 | 1u))) & 1u) { u1 += t12; d0 = d0 * 0.5 + z12; }
                while (i1++ < 4u && (unsigned)(u2 || (unsigned)((int)1u < (int)(unsigned)e0))) { if (--fuel == 0u) goto done;
                    if ((unsigned)(signed char)((unsigned)(0x80000000u < fuel) >> (0xeb84d5a5u & 31u))) continue;
                    if (((i0 - (unsigned)(w0 >> 29)) - a0[u1 & 3u])) continue;
                    if (v0) break;
                    m0 ^= ((9u ? fuel : u2) * (unsigned)!(unsigned)(0x8ef44405u || (unsigned)x0));
                }
            }
            do { if (--fuel == 0u) goto done;
                if ((1u - r0.y)) goto L1;
                if ((v0 & ((unsigned)x0 + r0.y))) goto L4;
                switch ((unsigned)((v0 | a0[i0 & 3u]) && 0x81812d9bu) & 7u) {
                    case 3u: ;
                    c0 = (unsigned char)(unsigned)d0;
                    r0.y ^= (unsigned)(p0 || (m0 & (unsigned)c1));
                    if (budget != 0u) { budget -= 1u; u3 = fn1(0x7fffffffu, a0[i0 & 3u], (unsigned)(r0.x || fuel)); }
                    a0[(unsigned)b0 & 3u] = p1;
                    case 2u: ;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(p2, 2u, (unsigned)(x0 >> 70)); }
                m0 ^= ((unsigned)(unsigned char)(0xfaaaa0e8u >> ((unsigned)(*mp < garr[i1 & 7u]) & 31u)) + (unsigned)w0);
            } while (i1++ < 5u && ((i2 & (unsigned)h1) - u2));
            if (a0[i0 & 3u]) {
                h1 = (unsigned short)(h1 + (((unsigned)(0x7fffffffu < a0[u1 & 3u]) & (0xd8fb2ec8u ^ u2)) % (garr[u2 & 7u] | 1u)));
                h0 = (short)(unsigned)((1u % (g1 | 1u)) || (unsigned)(x0 >> 70));
            } else {
                if ((unsigned)((int)(unsigned)e0 < (int)0x80000000u)) goto L2;
                g0 = r0.y;
                if (((unsigned)(u0 < *mp) / ((unsigned)s1 | 1u))) {
                    c0 = (unsigned char)(unsigned)c0;
                    for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)m0 < (int)2u)) continue;
                        s1 = (int)((unsigned)s1 + (*q0 >> (((unsigned)((short)g0 > (signed char)p0) / (u3 | 1u)) & 31u)));
                        f0 = f0 * 0.5f + (float)((garr[i1 & 7u] - u0) & 255u);
                        break; (void)((g0 - (unsigned)(0x10000u || *mp)));
                    }
                    if (a0[i0 & 3u]) continue;
                }
            }
        } else {
            if (~((unsigned)c1 * 0x80000000u)) break;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(short)((unsigned)(w0 >> 29) & (unsigned)x0), (0xd4803c67u << ((unsigned)b0 & 31u)), ((unsigned)!((unsigned)f0 >> ((unsigned)d0 & 31u)) / (fuel | 1u))); }
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)4u > (signed char)(4u ^ r0.x)), (unsigned)(r0.y || (9u * (unsigned)h0)), (unsigned)((int)(unsigned)f0 < (int)0x3c492a53u)); }
        }
        if (((unsigned)c0 >> (a0[u1 & 3u] & 31u))) break;
        m0 ^= ((unsigned)s0 | ((unsigned)((short)0x10000u > (signed char)p1) - (m0 * (unsigned)f0)));
        f0 = f0 * 0.5f + (float)((unsigned)c1 & 255u);
    } while (i0++ < 3u && *mp);
    u1 += ((unsigned)c0 ? (unsigned)c0 : ((unsigned)s1 % (garr[i1 & 7u] | 1u)));
    while (i0++ < 6u && (unsigned)((short)5u > (signed char)(unsigned)c0)) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + ~((g0 << ((6u & (unsigned)(i0 == r0.x)) & 31u)) | 9u);
        while (i1++ < 3u && (unsigned)((int)*mp < (int)(0x80000000u | r0.x))) { if (--fuel == 0u) goto done;
            a0[0xc04b83d9u & 3u] = (unsigned)(signed char)(a0[i0 & 3u] % ((*q0 ? (unsigned)w0 : a0[u1 & 3u]) | 1u));
            if ((unsigned)((int)(unsigned)(x0 >> 70) < (int)0x8a5821e0u)) break;
        }
        g0 = fuel;
    }
    goto L0;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t13; double z13; if (((0xffffffffu & (unsigned)b0)) & 1u) { t13 = garr[i1 & 7u]; z13 = (double)(((unsigned)(0x6bb38c9bu || 0x25b0d9d2u)) & 255u); } if (((0xffffffffu & (unsigned)b0)) & 1u) { u1 += t13; d0 = d0 * 0.5 + z13; }
            if ((unsigned)e0) break;
            u1 += (unsigned)(g0 || ~((0x379dc78bu * (unsigned)w0) >> ((unsigned)c1 & 31u)));
            s0 = (int)u3;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)e0, garr[u2 & 7u], 0x7fffffffu); }
            do { if (--fuel == 0u) goto done;
                if (u1) break;
                h1 = (unsigned short)(h1 + -((unsigned)l0 >> ((unsigned)(short)(g1 + (unsigned)(x0 >> 70)) & 31u)));
                b0 = (u1 * ((unsigned)c1 & (0x10000u % (i0 | 1u)))) != 0u;
                m0 ^= (unsigned)c0;
                g1 += (0u + (unsigned)((int)1u >= (int)(unsigned)(w0 >> 29)));
            } while (i1++ < 3u && (0xf7514438u / ((garr[u2 & 7u] | 3u) | 1u)));
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)c1 == 0x7fffffffu);
        u3 += (m0 ? *q0 : *q0);
        if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)(7u || 1u), (p2 + p0), (unsigned)(0xffffffffu == 0xc2a0025u)); }
        if ((unsigned)f0) break;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(garr[i1 & 7u] && (unsigned)b0), (unsigned)l0, 4u); }
    r0.x = (p0 << (((unsigned)(0x80000000u && (g0 - 4u)) | 0xe31d6382u) & 31u));
    if ((unsigned)w0) goto L4;
    b0 = 7u != 0u;
    if (u3 == 7u) return 3u;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)2u >= (int)(7u ^ 0x3a8e9bf8u))) continue;
    }
    if (((unsigned)(x0 >> 70) & i0)) goto L1;
    while (i0++ < 5u && (unsigned)((int)8u < (int)(unsigned)f0)) { if (--fuel == 0u) goto done;
        u1 = u1 * 0x9e3779b1u + ((unsigned)(unsigned char)(*q0 / (m0 | 1u)) + (unsigned)!(unsigned)((v0 << (0x6277e132u & 31u)) || (unsigned)f0));
        b0 = (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)(signed char)((r0.x ? 0u : (unsigned)s0) + (unsigned)x0)) != 0u;
        if ((unsigned)((unsigned)w0 && (unsigned)(g1 == 3u))) goto L2;
        if (budget != 0u) { budget -= 1u; u3 = fn0((9u ^ fuel), 0x10000u, ((unsigned)x0 & ~(u3 % (i0 | 1u)))); }
        x0 = x0 * 0x100000001b3ull + (0u & u1);
        if (v0) {
            if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)((unsigned)((int)r0.x >= (int)garr[u2 & 7u]) < 0xda76020u), (unsigned)(short)(0x89fd996du >> (v0 & 31u)), -(garr[u2 & 7u] / (i2 | 1u))); }
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 4u, 0x4f03db44u, 0x7921c799u },
        { 11u, 0x166214feu, 0x7e9058f8u },
        { 13u, 0x3b6b8536u, 0x4bd267f2u },
        { 3u, 0xe44f7baeu, 0x6e8f3bb4u },
        { 10u, 0xe026f569u, 0x665a93ffu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
