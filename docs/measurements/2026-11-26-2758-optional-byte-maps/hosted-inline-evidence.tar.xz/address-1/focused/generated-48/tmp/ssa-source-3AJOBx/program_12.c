// test-ssa-source's program of seed 134000414 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xe3c6491cu, g1 = 0xc9ca281eu;
static unsigned garr[8] = { 0x82269f89u, 0x50acff4cu, 0x3bcbdb78u, 0x72a98d0du, 0xa86abbfcu, 0x98532280u, 0x5024702bu, 0xe91089fbu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch (((0xb41aa500u % (*mp | 1u)) / ((unsigned)h0 | 1u)) & 7u) {
        case 7u: ;
    }
    while (i0++ < 3u && 0xc035a59u) { if (--fuel == 0u) goto done;
        q0 = &garr[(unsigned)((int)(unsigned)((unsigned)c0 && 0x13c76f7du) < (int)(0xffffffffu & (unsigned)x0)) & 7u];
        { unsigned t0; double z0; if ((0x3c24c057u) & 1u) { t0 = ((unsigned)h1 >> ((unsigned)(w0 >> 29) & 31u)); z0 = (double)(((unsigned)((int)(unsigned)s0 >= (int)9u)) & 255u); } if ((0x3c24c057u) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            g0 = ((unsigned)l0 & (0x7fffffffu & (unsigned)(unsigned char)(unsigned)((int)r0.x < (int)p0)));
            r0.y ^= (unsigned)(signed char)(m0 ^ (garr[i1 & 7u] * g0));
            h1 = (unsigned short)(h1 + (unsigned)(0u == m0));
            continue; (void)(((unsigned)h0 >> (((unsigned)h0 - 0x80000000u) & 31u)));
        }
    }
    if (*mp) goto L2;
    w0 ^= (unsigned long long)(p0 + 4u) << ((unsigned)(short)(0x10000u >> (fuel & 31u)) & 63u);
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((0x2a1079c1u % ((p0 >> (2u & 31u)) | 1u))) {
            g0 = (unsigned)d0;
            l0 = (long)((unsigned long)l0 + (2u ^ (r0.y / (0x80000000u | 1u))));
        }
        continue; (void)(0x8da8541au);
        m0 ^= ((unsigned)((~(garr[i1 & 7u] + 0x7fffffffu) + a0[i0 & 3u]) < p2) * v0);
        if ((unsigned)((int)(unsigned)(w0 >> 29) < (int)garr[i1 & 7u])) break;
        if (((unsigned)!(g0 / (0x99fc26d1u | 1u)) + 0x10000u)) goto L4;
    }
    if ((0x10000u | fuel)) goto done;
    garr[(unsigned)f0 & 7u] = (unsigned)(u1 == (u2 % ((unsigned)f0 | 1u)));
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((int)3u >= (int)u0)) {
            do { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if ((i1) & 1u) { t1 = ((r0.y | 0xc6200c14u) * i1); z1 = (double)(((unsigned)(signed char)((unsigned)s0 % ((unsigned)(p2 == (unsigned)e0) | 1u))) & 255u); } if ((i1) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    x0 = x0 * 0x100000001b3ull + (p0 / (i0 | 1u));
                    L1: if (--fuel == 0u) goto done;
                    if (garr[u2 & 7u]) break;
                }
            } while (i1++ < 7u && ~(unsigned)((int)r0.y < (int)0x10000u));
        }
        u0 = u0 * 0x9e3779b1u + (5u << (u1 & 31u));
    } while (i0++ < 3u && (unsigned)((unsigned)(signed char)((unsigned)d0 << (0u & 31u)) == i0));
    goto L1;
    L2: if (--fuel == 0u) goto done;
    if (7u) {
        s1 = (int)((unsigned)s1 + (0x4d7cb949u ^ ((unsigned)(w0 >> 29) * 0xffffffffu)));
        if ((unsigned)(a0[u1 & 3u] && (unsigned)(0x10000u < i0))) goto done;
        L3: if (--fuel == 0u) goto done;
        if ((unsigned)(x0 >> 70)) goto L3;
    }
    e0 = e0 * 0.5L + (long double)((unsigned)c0 & 1023u);
    g1 += (unsigned)!(m0 ? g1 : (unsigned)f0);
    switch ((u1 + ((unsigned)e0 + 0xeb02e652u)) & 7u) {
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((unsigned)(a0[u1 & 3u] || ~((unsigned)(*q0 || (unsigned)(garr[u2 & 7u] && (unsigned)h1)) | (unsigned)x0)) & 1023u);
            L4: if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)(((unsigned)(unsigned char)((0x57038d71u % (0x1d1b6deeu | 1u)) >> (u1 & 31u)) * (unsigned)((int)g0 >= (int)0x80000000u)) & 255u);
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            garr[(unsigned)((unsigned)c1 && g1) & 7u] = (((unsigned)(x0 >> 70) / (0xf522477cu | 1u)) / ((unsigned)c0 | 1u));
            continue; (void)((unsigned)(g0 == g0));
        }
        s0 = (int)0x80000000u;
    }
    u2 = u2 * 0x9e3779b1u + (((unsigned)(w0 >> 29) | (unsigned)(w0 >> 29)) % (((unsigned)((int)0xbdafd688u < (int)p1) - 0x35877dacu) | 1u));
    if (((unsigned)(unsigned char)(0xffffffffu % (3u | 1u)) >> (2u & 31u))) goto L3;
    goto L4;
    r0.x = 0x8b5cdfbau;
    l0 = (long)((unsigned long)l0 + (-(0x7fa7d336u * 0xfa86296du) << ((unsigned)d0 & 31u)));
    h1 = (unsigned short)(h1 + (a0[i0 & 3u] % (((unsigned)(g0 && 0u) >> ((g1 >> ((unsigned)s1 & 31u)) & 31u)) | 1u)));
    u2 = (unsigned)((unsigned)(signed char)((4u | u2) + a0[u1 & 3u]) < (0x26c1048fu + 0x96cf09bu));
    w0 = w0 * 6364136223846793005ull + ((unsigned)s0 ^ (unsigned)(unsigned char)(unsigned)((int)(unsigned)d0 >= (int)(unsigned)(short)(garr[u2 & 7u] | (unsigned)s0)));
    if ((*q0 % (((unsigned)b0 / (6u | 1u)) | 1u))) goto L0;
    { unsigned t2; double z2; if ((((unsigned)w0 >> ((unsigned)d0 & 31u))) & 1u) { t2 = (0x80000000u * r0.y); z2 = (double)(((*mp * i1)) & 255u); } if ((((unsigned)w0 >> ((unsigned)d0 & 31u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        x0 = x0 * 0x100000001b3ull + (unsigned)(4u && ((unsigned)d0 % (r0.x | 1u)));
    }
    if ((unsigned)(3u == -(m0 / (0x4ec659d5u | 1u)))) goto L0;
    switch (((unsigned)l0 >> ((unsigned)(w0 >> 29) & 31u)) & 7u) {
        goto L1;
        if ((p0 | 0xa914f8b0u)) goto done;
        d0 = d0 * 0.5 + (double)((g0 % ((~(unsigned)((int)a0[i0 & 3u] >= (int)(g0 | 0x6f5e510bu)) / (a0[i0 & 3u] | 1u)) | 1u)) & 1023u);
    }
    do { if (--fuel == 0u) goto done;
        break; (void)((g0 >> (garr[u2 & 7u] & 31u)));
        c1 = (signed char)(i2 % (a0[u1 & 3u] | 1u));
        goto L1;
        { unsigned t3; double z3; if ((-(0xffffffffu - 0xf4304b05u)) & 1u) { t3 = (unsigned)c0; z3 = (double)(((unsigned)((6u & (unsigned)c0) == p2)) & 255u); } if ((-(0xffffffffu - 0xf4304b05u)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            if ((unsigned)((unsigned)(i1 == u1) < 6u)) {
                c0 = (unsigned char)(unsigned)(0x7fffffffu < u0);
                if ((m0 & (u3 + r0.x))) goto L0;
                u3 ^= 0x10000u;
                for (;;) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)(0x7fffffffu & 255u);
                    if ((unsigned)((short)0x7fffffffu > (signed char)g0)) break;
                }
                { unsigned t4; double z4; if ((fuel) & 1u) { t4 = p0; z4 = (double)(((unsigned)!((unsigned)l0 & 0x10000u)) & 255u); } if ((fuel) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    u0 += (unsigned)((unsigned)(fuel < garr[i1 & 7u]) < 0x7fffffffu);
                    u2 += (unsigned)((int)garr[i1 & 7u] >= (int)~(unsigned)((int)p2 < (int)0x7fffffffu));
                    if ((unsigned)(a0[u1 & 3u] < 0x7fffffffu)) break;
                    h0 = (short)(unsigned)((int)(g0 / (u1 | 1u)) < (int)(0x5ed61e4fu ^ 0x80000000u));
                    break; (void)(((unsigned)e0 << (g0 & 31u)));
                }
                a0[(unsigned)(short)(0x10000u % (u2 | 1u)) & 3u] = (unsigned)((int)((unsigned)(w0 >> 29) % ((unsigned)!(i1 & (unsigned)b0) | 1u)) >= (int)a0[i0 & 3u]);
            }
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)c0) break;
                g0 = (*mp + 0xf30a2b2u);
                g1 += (unsigned)(x0 >> 70);
            }
            u0 ^= (0xffffffffu ^ (0x7fffffffu >> ((unsigned)h1 & 31u)));
            if (((unsigned)d0 & a0[i0 & 3u])) continue;
        }
        u3 = u3 * 0x9e3779b1u + (p0 << ((unsigned)c0 & 31u));
        u1 += (g1 % ((unsigned)((short)m0 > (signed char)i0) | 1u));
    } while (i0++ < 7u && (unsigned)(signed char)(unsigned)((short)(unsigned)h0 > (signed char)(0xffffffffu - *mp)));
    switch (-((unsigned)s1 / (((unsigned)d0 - g0) | 1u)) & 7u) {
        case 4u: ;
        h1 = (unsigned short)(h1 + g1);
        do { if (--fuel == 0u) goto done;
            garr[((unsigned)s0 % (0x80000000u | 1u)) & 7u] = p1;
        } while (i0++ < 6u && (unsigned)c0);
        if (((unsigned)((short)(unsigned)b0 > (signed char)*mp) | 2u)) goto L0;
        break; (void)((unsigned)(1u && (g0 / (i1 | 1u))));
    }
    if (((unsigned)b0 + i0)) goto L3;
    if (r0.x) goto L0;
    if ((unsigned)x0) goto L3;
    r0.x = ((unsigned)(short)(i0 * a0[i0 & 3u]) % (u0 | 1u));
    f0 = f0 * 0.5f + (float)((m0 - p0) & 255u);
    if (((unsigned)e0 ^ (r0.x << ((unsigned)f0 & 31u)))) goto done;
    m0 ^= (unsigned)(x0 >> 70);
    { unsigned t5; double z5; if ((i2) & 1u) { t5 = r0.x; z5 = (double)(((((unsigned)s1 ^ i0) * 0xb28249beu)) & 255u); } if ((i2) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        if ((u3 - (unsigned)(garr[i1 & 7u] || 0x4e96a16bu))) goto L2;
        g1 += (unsigned)h1;
        if (u3 == 7u) return (unsigned)((int)r0.x < (int)(unsigned)(unsigned char)((unsigned)l0 | (unsigned)h0));
    }
    d0 = d0 * 0.5 + (double)(((unsigned)(v0 || (unsigned)(2u || u2)) & 2u) & 1023u);
    if (u0) goto L0;
    goto L2;
    *q0 = (unsigned)((0xffffffffu | ((unsigned)(signed char)(0x80000000u * 0xffffffffu) | (unsigned)b0)) || u2);
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= (((unsigned)(2u && (unsigned)c1) >> (i0 & 31u)) << (((unsigned)e0 - (unsigned)f0) & 31u));
        if ((unsigned)((unsigned)c1 || (unsigned)((int)*q0 < (int)(unsigned)b0))) break;
        if ((m0 ? i0 : garr[u2 & 7u])) break;
        b0 = (0x7fffffffu - a0[u1 & 3u]) != 0u;
        v0 = (unsigned)((int)((unsigned)s0 << (0xa1822d5au & 31u)) >= (int)(unsigned)h1);
        if ((8u & (unsigned)(garr[i1 & 7u] == a0[u1 & 3u]))) continue;
    }
    while (i0++ < 4u && (unsigned)(i2 || garr[u2 & 7u])) { if (--fuel == 0u) goto done;
        if ((i2 % ((unsigned)(w0 >> 29) | 1u))) {
            while ((unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
                if ((unsigned)(signed char)(0x5af927acu >> ((unsigned)w0 & 31u))) break;
                if (0x7fffffffu) break;
            }
            *q0 += (unsigned)((unsigned)((garr[i1 & 7u] % (u3 | 1u)) < 6u) == (unsigned)((int)u2 < (int)1u));
            while (i1++ < 6u && i2) { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)((short)(unsigned)(short)(unsigned)((int)0x80000000u < (int)(unsigned)((short)(unsigned)c0 > (signed char)a0[u1 & 3u])) > (signed char)(m0 + (unsigned)d0));
                while (i2++ < 3u && p2) { if (--fuel == 0u) goto done;
                    q0 = &garr[g1 & 7u];
                    if ((unsigned)((int)i2 < (int)(unsigned)(x0 >> 70))) break;
                }
            }
        } else {
            if (u3 == 7u) return ((g1 ^ (unsigned)((unsigned)h1 && *mp)) ? *q0 : (unsigned)(w0 >> 29));
            if (((unsigned)c1 >> ((4u << ((unsigned)l0 & 31u)) & 31u))) break;
            v0 = (*q0 & (3u & (unsigned)b0));
            if ((unsigned)((short)(m0 & 3u) > (signed char)u2)) {
                g1 += ((*mp & (unsigned)((unsigned)s0 && 0x500a51f6u)) / (0x7fffffffu | 1u));
            } else {
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    g1 += (unsigned)(2u == 0xccb8090du);
                    garr[(unsigned)(2u && (unsigned)(x0 >> 70)) & 7u] = 4u;
                }
            }
        }
    }
    if (0x7d827db3u) goto L0;
    if (u0) goto L3;
    if ((unsigned)(-(a0[i0 & 3u] - (unsigned)c1) == (unsigned)w0)) {
        u3 ^= 2u;
    } else {
        garr[(unsigned)((int)(unsigned)s1 < (int)garr[u2 & 7u]) & 7u] = (unsigned)((unsigned)h0 && (unsigned)(signed char)((unsigned)(signed char)((unsigned)((unsigned)w0 && 0x4e9302a8u) + (unsigned)l0) ^ (unsigned)w0));
    }
    goto L0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch ((unsigned)(unsigned char)(unsigned)((int)(unsigned)l0 < (int)a0[u1 & 3u]) & 7u) {
        if ((p2 ^ r0.y)) {
            if (u3 == 7u) return 6u;
            if ((unsigned)((int)m0 >= (int)(unsigned)c1)) {
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(0x4cd52165u || (unsigned)c0) && 0x10000u), (i2 | (i0 - g1)), (unsigned)b0); }
                g1 += (a0[u1 & 3u] % ((unsigned)(unsigned char)(((unsigned)e0 + 7u) + u1) | 1u));
                if (*q0) {
                    goto L4;
                    L0: if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + ((unsigned)(8u == p1) - (unsigned)(g0 && (unsigned)c1)));
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)f0 >> (1u & 31u)), (unsigned)(short)(a0[u1 & 3u] & -(u3 << (i1 & 31u))), 0xffffffffu); }
                    if ((0x80000000u ^ (5u << ((unsigned)c1 & 31u)))) goto L3;
                    if (((unsigned)h0 & (unsigned)h1)) {
                        c0 = (unsigned char)(g0 ? (0xffffffffu << (i0 & 31u)) : i0);
                        if ((unsigned)h1) {
                            if (fuel < 8u) return -(unsigned)(a0[i0 & 3u] == *mp);
                            u1 ^= (u1 & (unsigned)(((unsigned)(signed char)(unsigned)(0x8a2ccd43u == 8u) ^ p1) == g0));
                        } else {
                            garr[v0 & 7u] = (unsigned)((int)2u >= (int)(unsigned)x0);
                            case 5u: ;
                            L1: if (--fuel == 0u) goto done;
                            u2 += (unsigned)((unsigned)(r0.x && (unsigned)d0) < (u0 + (unsigned)c0));
                        }
                        u1 = u1 * 0x9e3779b1u + ((unsigned)((0xd19ae60cu / ((unsigned)(unsigned char)(unsigned)((short)u2 > (signed char)(unsigned)s0) | 1u)) || garr[i1 & 7u]) >> (*q0 & 31u));
                    }
                }
                L2: if (--fuel == 0u) goto done;
            }
            case 1u: ;
            L3: if (--fuel == 0u) goto done;
            switch ((unsigned)((short)(0x688f1747u | r0.x) > (signed char)(unsigned)s1) & 7u) {
                c0 = (unsigned char)0u;
                L4: if (--fuel == 0u) goto done;
            }
        } else {
            if (((garr[u2 & 7u] % (u3 | 1u)) % (i0 | 1u))) goto L4;
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)l0) break;
            garr[((unsigned)s0 / ((unsigned)l0 | 1u)) & 7u] = (unsigned)c0;
        }
        if ((i1 ? 5u : 0xcc62f43eu)) {
            c0 = (unsigned char)(unsigned)((unsigned)((int)i1 >= (int)(unsigned)(u3 && 7u)) == 7u);
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)f0, (0x1fc9c09eu << (fuel & 31u)), (unsigned)e0); }
        } else {
            case 4u: ;
            if (p2) goto L3;
        }
    }
    if (*q0) goto L3;
    u2 = u2 * 0x9e3779b1u + (unsigned)((unsigned)d0 && garr[u2 & 7u]);
    goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)(i1 && 0x86665a87u) == 4u), (fuel + i1), (unsigned)(short)((unsigned)((short)3u > (signed char)i1) + p1)); }
    if (i2) {
        *q0 += -((unsigned)(8u || a0[i0 & 3u]) / (garr[u2 & 7u] | 1u));
        if (((unsigned)((unsigned)(w0 >> 29) == r0.y) | 0xfbe56734u)) goto L2;
        if (budget != 0u) { budget -= 1u; u2 = fn0(0xb00257d3u, 1u, (unsigned)(0x80000000u || ((unsigned)e0 * 0xffffffffu))); }
        goto L4;
        goto L0;
    }
    while (i0++ < 7u && (unsigned)((unsigned)l0 < 0x81787d41u)) { if (--fuel == 0u) goto done;
        v0 = ((v0 ? *q0 : 0xffffffffu) % (0x80000000u | 1u));
        goto L0;
        h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)((unsigned)((int)v0 >= (int)~(4u / (u2 | 1u))) == (unsigned)c1) >= (int)(unsigned)d0));
        { unsigned t0; double z0; if (((unsigned)((int)i1 >= (int)(u2 | 1u))) & 1u) { t0 = (unsigned)e0; z0 = (double)(((unsigned)(0x7fffffffu < u3)) & 255u); } if (((unsigned)((int)i1 >= (int)(u2 | 1u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            if ((unsigned)h1) {
                *q0 += (u2 - 0x10000u);
                if ((unsigned)(((unsigned)d0 - 0xffffffffu) && 0xfa8d651u)) break;
                i0 = ((r0.x ^ (unsigned)b0) << (g0 & 31u)) & 15u;
                if ((unsigned)((int)(0u & (unsigned)e0) >= (int)0xb1ad57f6u)) break;
                do { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((m0 / (*mp | 1u)), (a0[u1 & 3u] - ~(g1 % (u1 | 1u))), (unsigned)((int)p1 >= (int)*q0)); }
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)((int)i2 >= (int)0x7fffffffu) >> ((unsigned)(x0 >> 70) & 31u)), (0x7fffffffu | 0xa5ad99fbu), ((3u * p0) | u2)); }
                        break; (void)((unsigned)((unsigned)w0 || 0x80000000u));
                    }
                } while (i1++ < 7u && (unsigned)(*mp && ((unsigned)h1 << (g0 & 31u))));
                if ((unsigned)(short)(unsigned)((int)0x80000000u < (int)0x80000000u)) goto L4;
            } else {
                { unsigned t1; double z1; if (((unsigned)f0) & 1u) { t1 = (unsigned)c0; z1 = (double)((~((unsigned)e0 % ((*q0 | 0x30911076u) | 1u))) & 255u); } if (((unsigned)f0) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    d0 = d0 * 0.5 + (double)(6u & 1023u);
                    do { if (--fuel == 0u) goto done;
                        u2 = u2 * 0x9e3779b1u + (unsigned)((int)*mp < (int)(unsigned)(i1 < (unsigned)(w0 >> 29)));
                    } while (i1++ < 7u && (unsigned)b0);
                    if ((unsigned)(2u && ~(unsigned)((int)v0 >= (int)0xb644beafu))) break;
                    *q0 += (unsigned)(unsigned char)(garr[i1 & 7u] << ((unsigned)s1 & 31u));
                    continue; (void)((i2 + (unsigned)(signed char)(unsigned)((short)u3 > (signed char)0x80000000u)));
                    l0 = (long)((unsigned long)l0 + ((unsigned)!(r0.x / (u3 | 1u)) ^ (0xba68e266u * (unsigned)(0x199bb574u || 7u))));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(0xf978c80fu, (((unsigned)w0 - r0.y) >> (u0 & 31u)), (unsigned)f0); }
                g1 += (unsigned)((0x7fffffffu % (g1 | 1u)) || ((u0 - (unsigned)b0) / (u0 | 1u)));
                w0 ^= (unsigned long long)(unsigned)((short)u3 > (signed char)(unsigned)c1) << ((-(((unsigned)((int)2u >= (int)(unsigned)l0) / (u0 | 1u)) & 0x1088028fu) << (a0[u1 & 3u] & 31u)) & 63u);
            }
            w0 = w0 * 6364136223846793005ull + (*q0 - ((unsigned)((fuel >> (*mp & 31u)) < (unsigned)s0) / ((unsigned)h1 | 1u)));
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)*q0 < (int)garr[i1 & 7u]), (p1 | (0xbbe168f7u | (unsigned)s0)), 0xfc179247u); }
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((garr[u2 & 7u] % ((unsigned)e0 | 1u)) < 3u), 0x76b3a5ebu, (unsigned)(p1 || 0x7fffffffu)); }
        }
        r0.y ^= (unsigned)((short)i0 > (signed char)(*mp >> ((unsigned)l0 & 31u)));
    }
    { unsigned t2; double z2; if ((((unsigned)l0 << ((p0 ^ (unsigned)f0) & 31u))) & 1u) { t2 = (unsigned)(unsigned char)(unsigned)(u1 == (unsigned)(unsigned char)(unsigned)((int)0x3b66495fu < (int)(unsigned)s0)); z2 = (double)(((unsigned)(u1 || u3)) & 255u); } if ((((unsigned)l0 << ((p0 ^ (unsigned)f0) & 31u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        goto L2;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)h1, ((unsigned)l0 << (r0.x & 31u)), i0); }
    if ((u2 % (((unsigned)f0 ^ 7u) | 1u))) {
        a0[g1 & 3u] = (unsigned)((int)u3 < (int)(unsigned)((unsigned)s0 && (unsigned)((int)i0 < (int)0x80000000u)));
        if ((unsigned)((int)0x11455e69u < (int)p2)) goto L4;
        s0 = (int)((unsigned)((unsigned)(signed char)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)2u) < u1) - (0xf2510db0u >> ((unsigned)w0 & 31u)));
    }
    if (((unsigned)b0 / ((unsigned)s0 | 1u))) {
        c0 = (unsigned char)(unsigned)(unsigned char)((unsigned)s1 & a0[u1 & 3u]);
        goto done;
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)s1 - *mp), ((unsigned)(8u && 0x19ceba79u) << (2u & 31u)), (0x80000000u << ((unsigned)b0 & 31u))); }
            while (i1++ < 4u && (unsigned)(0xa9c77a0fu == u0)) { if (--fuel == 0u) goto done;
                u0 = u0 * 0x9e3779b1u + ~(unsigned)((short)((unsigned)((int)0u >= (int)(unsigned)w0) - (unsigned)h0) > (signed char)(unsigned)(0x80000000u < 0xffffffffu));
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (r0.y) break;
                    if (u2) break;
                    l0 = (long)((unsigned long)l0 + (-((unsigned)(signed char)(0x7fffffffu << (0xd79e75bbu & 31u)) % (0x53e6f0e3u | 1u)) >> (u0 & 31u)));
                    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (p0) goto done;
                        if ((unsigned)((short)(0x7fffffffu | a0[i0 & 3u]) > (signed char)0x10000u)) {
                            r0.x = (unsigned)s0;
                            if ((unsigned)(signed char)((unsigned)((short)(unsigned)e0 > (signed char)u1) / (u2 | 1u))) break;
                            h0 = (short)(3u ^ (r0.x / (((unsigned)h0 * (0x80000000u * m0)) | 1u)));
                            c0 = (unsigned char)(((0x7fffffffu + 0x80000000u) & (unsigned)l0) * fuel);
                        }
                    }
                }
                if (m0) goto L4;
                if ((unsigned)(unsigned char)(unsigned)(9u || (unsigned)((short)0xfe2475e3u > (signed char)0x94f5d051u))) {
                    v0 = (0xc6713489u & (-(unsigned)(a0[i0 & 3u] < (unsigned)c0) << (-((unsigned)d0 ^ 0x123be763u) & 31u)));
                    if ((unsigned)((unsigned)((int)u3 < (int)*mp) && 0xb8666489u)) break;
                }
            }
            if (u0) break;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((0x952ed242u * (unsigned)(i0 && m0)), (unsigned)((g1 % ((unsigned)w0 | 1u)) == (unsigned)e0), a0[i0 & 3u]); }
        r0.y ^= ((unsigned)(short)(unsigned)(((unsigned)(i2 || 0x10000u) + 0x5e6e6896u) && r0.y) & 0xffffffffu);
        while (i0++ < 7u && ~(0xffffffffu * (5u / ((unsigned)h0 | 1u)))) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)d0 << ((unsigned)e0 & 31u)), (unsigned)(-(unsigned)(0x10000u || (unsigned)c0) && (unsigned)d0), u3); }
                if (2u) break;
                c0 = (unsigned char)((a0[i0 & 3u] - 4u) % (-(unsigned)((short)(unsigned)!(unsigned)(0x923139d5u || (unsigned)h1) > (signed char)(unsigned)c1) | 1u));
                if ((unsigned)((int)u2 < (int)*mp)) break;
                f0 = f0 * 0.5f + (float)(fuel & 255u);
                if (0x80000000u) break;
            }
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u3) break;
            }
            g0 = (0xc71e7af2u + (unsigned)(8u == 0xffffffffu));
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)0xe336fd40u < (int)((unsigned)h0 + fuel))) {
                    x0 = x0 * 0x100000001b3ull + (unsigned)(u1 < 0xffffffffu);
                    r0.y ^= (unsigned)(((((unsigned)b0 * (unsigned)c1) ^ (unsigned)(w0 >> 29)) | 0xffffffffu) && 0x10000u);
                    s0 = (int)((unsigned)s1 * (unsigned)h1);
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)s0 + (unsigned)((unsigned)f0 < 0x24385c23u)), 0x9d34e56fu, ((unsigned)((short)(unsigned)b0 > (signed char)u3) % (8u | 1u))); }
                }
                continue; (void)((0x2aa087bau * (7u & 0x7fffffffu)));
                break; (void)(((unsigned)(x0 >> 70) + 0x10000u));
            }
            s0 = (int)(unsigned)((int)a0[i0 & 3u] >= (int)(0xd3c16c39u / ((p2 + i2) | 1u)));
        }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((4u | (unsigned)(r0.y < (unsigned)d0)), (unsigned)(short)(unsigned)(r0.x && (unsigned)(x0 >> 70)), (fuel & p1)); }
    if (~((unsigned)f0 * (unsigned)((short)0x10000u > (signed char)0x80000000u))) goto done;
    if (((unsigned)(garr[u2 & 7u] && 0x10000u) - r0.x)) {
        goto L4;
        b0 = (unsigned)((short)i2 > (signed char)((unsigned)((short)8u > (signed char)0xf4663bd5u) * p1)) != 0u;
        while (i0++ < 2u && (unsigned)(0xffffffffu < a0[u1 & 3u])) { if (--fuel == 0u) goto done;
            if (a0[i0 & 3u]) {
                if ((i0 | (unsigned)(short)(unsigned)(i0 == u3))) goto L0;
                goto L3;
                w0 ^= (unsigned long long)(0xb456f6d2u / (a0[u1 & 3u] | 1u)) << (((unsigned)(garr[u2 & 7u] < (unsigned)l0) << ((unsigned)((unsigned)l0 == (unsigned)w0) & 31u)) & 63u);
            }
            s1 = (int)((unsigned)s1 + p1);
            switch (~(unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)d0) & 7u) {
                if ((unsigned)c1) continue;
                *q0 += 1u;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 0u: ;
                    if ((r0.x ^ 0xffffffffu)) goto done;
                }
                if ((unsigned)h0) goto L1;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    goto done;
                }
            }
            if ((unsigned)e0) {
                break; (void)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)((int)0x7fffffffu < (int)5u)));
                g0 = (unsigned)((short)(unsigned)(unsigned char)((unsigned)((unsigned)(0x10000u < g0) || g0) - 7u) > (signed char)(unsigned)l0);
                if (((unsigned)w0 << ((unsigned)((int)*q0 >= (int)0xd54bf833u) & 31u))) {
                    r0.y ^= ((unsigned)((unsigned)x0 || (unsigned)w0) >> ((p0 << (2u & 31u)) & 31u));
                    garr[(p1 * 3u) & 7u] = m0;
                    w0 ^= (unsigned long long)((unsigned)d0 - 0u) << ((unsigned)c0 & 63u);
                    *q0 += (unsigned)((int)(((unsigned)(x0 >> 70) ^ i0) ^ garr[u2 & 7u]) < (int)5u);
                    if (budget != 0u) { budget -= 1u; u1 = fn0(0x33252091u, (unsigned)((unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)s0) || 0x359a7010u), (p1 << (0x1cd7684bu & 31u))); }
                    break; (void)((unsigned)(short)((unsigned)(w0 >> 29) - (8u & (unsigned)x0)));
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)d0 > (signed char)0xc161b64bu), p0, (unsigned)(garr[i1 & 7u] || (unsigned)(short)(unsigned)(0x173b13f1u == *mp))); }
            }
        }
        if (0x838d0d1bu) {
            if (((r0.x ^ (unsigned)c0) + (unsigned)c0)) {
                goto L1;
            } else {
                switch ((unsigned)b0 & 7u) {
                    b0 = u1 != 0u;
                    if (fuel < 8u) return (g0 >> (garr[i1 & 7u] & 31u));
                    if ((0x7fffffffu % ((0xc4955f6cu * fuel) | 1u))) goto L2;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((garr[i1 & 7u] << ((u3 | *mp) & 31u)), 2u, ((unsigned)(w0 >> 29) >> (-(0x337d4b48u >> ((unsigned)s0 & 31u)) & 31u))); }
                    if (i0) {
                        goto L4;
                        case 3u: ;
                    }
                    if ((unsigned)((int)(0x672375b5u - (unsigned)s1) < (int)r0.x)) goto L1;
                }
                if ((unsigned)h1) {
                    if (budget != 0u) { budget -= 1u; u3 = fn0(4u, (unsigned)((unsigned)w0 && m0), m0); }
                } else {
                    if (0x9d51d321u) {
                        b0 = garr[i1 & 7u] != 0u;
                        if ((0x2628bc3bu % ((unsigned)f0 | 1u))) goto L1;
                        *mp = (unsigned)(0xae6085d8u || ((unsigned)(x0 >> 70) % ((p1 ^ 0x80000000u) | 1u)));
                        a0[(m0 >> (0x7fffffffu & 31u)) & 3u] = *q0;
                        e0 = e0 * 0.5L + (long double)(((unsigned)((short)5u > (signed char)(unsigned)w0) ^ (unsigned)(0xeee56ae8u == 0x7fffffffu)) & 1023u);
                        if (g0) goto L3;
                    } else {
                        b0 = (2u / (0u | 1u)) != 0u;
                    }
                }
                c0 = (unsigned char)((0x80000000u - 0x10000u) - (unsigned)(short)(*mp - garr[u2 & 7u]));
            }
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                b0 = (3u + (unsigned)(unsigned char)((unsigned)(unsigned char)(unsigned)((int)p0 >= (int)0x7fffffffu) | ((unsigned)d0 - (unsigned)s1))) != 0u;
            }
            if (((unsigned)f0 % (*mp | 1u))) {
                s0 = (int)(unsigned)((int)(unsigned)c1 < (int)garr[u2 & 7u]);
                u3 = u3 * 0x9e3779b1u + (~((unsigned)e0 ^ 0x52fcb1dbu) * (unsigned)h0);
                g1 += *mp;
                goto L2;
                r0.y ^= (garr[i1 & 7u] / (u0 | 1u));
                l0 = (long)((unsigned long)l0 + (unsigned)f0);
            }
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)r0.x >= (int)(unsigned)h0);
            *q0 += (unsigned)((int)g1 < (int)p2);
        }
        if (((unsigned)(signed char)(unsigned)((int)(unsigned)h1 < (int)(unsigned)s0) ^ (unsigned)w0)) goto L0;
    } else {
        h1 = (unsigned short)(h1 + (unsigned)((unsigned)l0 || (unsigned)!((unsigned)c0 ^ u1)));
        if (budget != 0u) { budget -= 1u; u1 = fn0(((p0 ^ garr[u2 & 7u]) * 8u), (0xffffffffu ^ (unsigned)(signed char)(garr[i1 & 7u] & 0x10000u)), (((unsigned)s1 + 8u) ^ i0)); }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((0xb77127a9u * (unsigned)(x0 >> 70)), 7u, (unsigned)(-(unsigned)((int)*q0 < (int)i0) || (unsigned)l0)); }
    d0 = d0 * 0.5 + (double)((~(unsigned)((unsigned)d0 || *q0) & i1) & 1023u);
    goto L2;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (*q0) continue;
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)(unsigned)(0x9da44569u || (unsigned)(0x5855618du == v0)), ((unsigned)d0 / (0x80000000u | 1u)), *q0); }
        goto L2;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            *q0 += ((unsigned)s1 / (0x10000u | 1u));
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(short)((unsigned)e0 / ((unsigned)!((unsigned)((int)garr[i1 & 7u] < (int)r0.y) ^ (unsigned)l0) | 1u)) < (unsigned)c1) & 255u);
            u3 ^= (0x10000u / ((unsigned)((short)g0 > (signed char)0x7fffffffu) | 1u));
            g1 += (unsigned)((short)((*q0 ^ (unsigned)((int)m0 >= (int)i1)) / (*mp | 1u)) > (signed char)0x4c728bd5u);
            if ((0xfe3eee3bu & 0x10000u)) break;
        }
    }
    if ((unsigned)(2u || 0x1a57d33bu)) {
        q0 = &garr[(unsigned)((3u | 0x7d3689u) == ((0xf6206b9eu + (unsigned)(x0 >> 70)) * u3)) & 7u];
        g1 += 1u;
        *q0 += (6u + (unsigned)b0);
    }
    if ((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)(short)(unsigned)(i2 == (unsigned)(w0 >> 29)))) goto L0;
    f0 = f0 * 0.5f + (float)(((unsigned)(1u < (0x7fffffffu / (garr[i1 & 7u] | 1u))) + a0[i0 & 3u]) & 255u);
    switch (0x9a9121fu & 7u) {
        case 2u: ;
        case 4u: ;
        { unsigned t3; double z3; if (((unsigned)((unsigned)s0 == r0.y)) & 1u) { t3 = (m0 ^ ((unsigned)c0 & (unsigned)(w0 >> 29))); z3 = (double)(((unsigned)c1) & 255u); } if (((unsigned)((unsigned)s0 == r0.y)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            e0 = e0 * 0.5L + (long double)(((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)l0) % ((r0.y * (unsigned)b0) | 1u)) & 1023u);
            do { if (--fuel == 0u) goto done;
                m0 ^= *mp;
                g0 = (unsigned)(0x10000u && 0x99b37d52u);
                q0 = &garr[(unsigned)(unsigned char)(unsigned)((p1 ^ 7u) && (((unsigned)l0 / (0xffef0379u | 1u)) & (unsigned)w0)) & 7u];
            } while (i0++ < 6u && ((unsigned)c1 >> ((g0 << ((unsigned)x0 & 31u)) & 31u)));
            r0.x = (unsigned)((unsigned)(v0 == *mp) && (unsigned)((short)(unsigned)c1 > (signed char)(unsigned)(unsigned char)(p1 ^ (unsigned)e0)));
            case 6u: ;
            b0 = (0x80000000u << (((unsigned)((unsigned)((short)p1 > (signed char)(unsigned)x0) < garr[i1 & 7u]) % ((unsigned)l0 | 1u)) & 31u)) != 0u;
        }
    }
    r0.x = (unsigned)(*q0 < (unsigned)c0);
    m0 ^= (unsigned)(i2 == (g1 & ((unsigned)(unsigned char)(unsigned)(g1 < 6u) ^ i2)));
    do { if (--fuel == 0u) goto done;
        while (i1++ < 7u && 0u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    r0.x = ((unsigned)(i1 < u0) * (unsigned)(i0 && (a0[u1 & 3u] / (0xffffffffu | 1u))));
                }
                if (((unsigned)(signed char)(unsigned)((unsigned)(x0 >> 70) == (unsigned)x0) / ((unsigned)s0 | 1u))) break;
                s0 = (int)0x778f849du;
                if (((unsigned)w0 * (unsigned)(garr[i1 & 7u] && *q0))) {
                    { unsigned t4; double z4; if (((unsigned)w0) & 1u) { t4 = (unsigned)((0x10000u >> (g1 & 31u)) == (unsigned)l0); z4 = (double)(((r0.x % (7u | 1u))) & 255u); } if (((unsigned)w0) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                        b0 = (0x10000u << ((unsigned)((int)0x42f3e491u < (int)(unsigned)(i0 == u2)) & 31u)) != 0u;
                    }
                    e0 = e0 * 0.5L + (long double)(((unsigned)(a0[u1 & 3u] && 0xac3b21a8u) - (0x26e58371u * (0x7fffffffu / (u1 | 1u)))) & 1023u);
                    while (i0++ < 4u && (unsigned)s1) { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)(unsigned)s1 << (((unsigned)x0 % (i0 | 1u)) & 63u);
                        h0 = (short)(unsigned)((unsigned)((int)(unsigned)h1 >= (int)0xd610ff46u) < 0xffffffffu);
                        if (((unsigned)h0 - (unsigned)b0)) continue;
                        for (;;) { if (--fuel == 0u) goto done;
                            if (((unsigned)f0 + 9u)) break;
                        }
                    }
                    if ((unsigned)(unsigned char)(unsigned)(0xffffffffu < ((unsigned)d0 << ((unsigned)w0 & 31u)))) break;
                    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        v0 = (unsigned)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)u3) || ((unsigned)((int)(unsigned)h0 >= (int)0xdc3fba82u) / (u3 | 1u)));
                    }
                    s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(unsigned)((int)fuel >= (int)0x80000000u));
                }
                w0 ^= (unsigned long long)(unsigned)!(unsigned)(g0 && 0xffffffffu) << (i0 & 63u);
            }
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)(short)(unsigned)((int)(unsigned)((unsigned)s0 < 0x1bc70c2fu) >= (int)p1);
            }
            while (i2++ < 4u && (0x3f87e893u >> ((unsigned)h1 & 31u))) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (m0 & ((unsigned)h1 >> (0x7fffffffu & 31u))));
            }
            if (p0) continue;
        }
    } while (i0++ < 5u && (unsigned)(short)(unsigned)((i0 / ((unsigned)d0 | 1u)) || (unsigned)f0));
    if ((unsigned)((p2 % (p2 | 1u)) && (unsigned)x0)) {
        goto L4;
    }
    r0.x = ((0xf6283bd7u - (unsigned)(short)(u1 + (p2 / (r0.y | 1u)))) | u1);
    goto done;
    u1 ^= ((0x9242c802u - (0xff11438eu >> ((unsigned)h0 & 31u))) * 7u);
    do { if (--fuel == 0u) goto done;
        v0 = ((unsigned)s1 << ((unsigned)((int)r0.y >= (int)(unsigned)h1) & 31u));
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)c0 & a0[i0 & 3u])) break;
        }
        for (;;) { if (--fuel == 0u) goto done;
            *q0 += (u1 | (unsigned)!((unsigned)(w0 >> 29) << ((unsigned)d0 & 31u)));
            break; (void)((p1 >> (i1 & 31u)));
            do { if (--fuel == 0u) goto done;
                g0 = ((unsigned)(unsigned char)(0x2d271017u - 0x83039934u) / ((u3 ^ (unsigned)((short)4u > (signed char)0x80000000u)) | 1u));
            } while (i2++ < 7u && (0x7e5786d4u | v0));
        }
    } while (i0++ < 2u && (3u >> (2u & 31u)));
    if ((unsigned)(g1 || 0x7409a128u)) goto L0;
    m0 ^= (unsigned)((short)(unsigned)((short)(unsigned)c0 > (signed char)1u) > (signed char)(unsigned)((unsigned)(i2 || v0) && 9u));
    *q0 += 0xffffffffu;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)p0 < (int)4u), (unsigned)(v0 && (unsigned)(signed char)(*mp | 0xd14242c4u)), (0xa277e4c4u % (*q0 | 1u))); }
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(g0 ^ (0xe749cf6du | m0)), ((p0 - (unsigned)d0) - 0x2e535f8cu), p2); }
            while ((0x10000u / (u0 | 1u))) { if (--fuel == 0u) goto done;
                while (i0++ < 4u && i1) { if (--fuel == 0u) goto done;
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)s1) {
                            i0 = (unsigned)((short)0x14c87e99u > (signed char)((0x80000000u ^ p2) / ((unsigned)w0 | 1u))) & 15u;
                            c1 = (signed char)(unsigned)!(unsigned)(((g0 ? p0 : (unsigned)b0) >> ((unsigned)s1 & 31u)) || 0x85c92af0u);
                            i0 = (0xf5eb7fc4u * 4u) & 15u;
                        }
                        w0 = w0 * 6364136223846793005ull + ((unsigned)((7u - 0xd2bc77e8u) < (v0 / (*mp | 1u))) ^ 0xffffffffu);
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)e0 || u3), (unsigned)((unsigned)w0 == r0.x), -(unsigned)(0x4bdc14c0u == (unsigned)(0x10000u < (unsigned)(x0 >> 70)))); }
                    }
                    d0 = d0 * 0.5 + (double)((unsigned)((short)0u > (signed char)(unsigned)(unsigned char)(i1 % ((unsigned)(6u == (unsigned)d0) | 1u))) & 1023u);
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0((garr[i1 & 7u] * 0x80000000u), (g0 + u3), a0[i0 & 3u]); }
                if (budget != 0u) { budget -= 1u; u3 = fn0(0xf0737a7du, (m0 << ((unsigned)((int)0x2e76d336u >= (int)1u) & 31u)), (unsigned)!(u2 + (unsigned)!(unsigned)(0xffffffffu || a0[u1 & 3u]))); }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(0x10000u, (unsigned)d0, 0x15637799u); }
            g0 = ((unsigned)f0 + 0xb5e963c9u);
            if ((unsigned)((unsigned)e0 < (unsigned)c1)) break;
        }
        if ((unsigned)((short)u2 > (signed char)(unsigned)e0)) continue;
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)(((unsigned)((unsigned)l0 || (unsigned)s0) / (((unsigned)(short)((unsigned)f0 << ((unsigned)x0 & 31u)) ^ u2) | 1u)) & 1023u);
        while (i1++ < 5u && ((unsigned)((int)0x772b3466u < (int)(unsigned)s1) ^ (unsigned)c0)) { if (--fuel == 0u) goto done;
            if (((unsigned)e0 | i0)) break;
            { unsigned t5; double z5; if (((*mp ^ (unsigned)b0)) & 1u) { t5 = (unsigned)((int)(unsigned)((short)(unsigned)h0 > (signed char)0u) >= (int)0xffffffffu); z5 = (double)(((i1 / ((8u % (2u | 1u)) | 1u))) & 255u); } if (((*mp ^ (unsigned)b0)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                if (g1) break;
                if (u3 == 7u) return (i0 * (unsigned)((unsigned)!(unsigned)((unsigned)s1 < (unsigned)f0) < (0xe6db5871u ^ 0x80000000u)));
            }
        }
    }
    goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)c1) goto L3;
    { unsigned t0; double z0; if ((0x80000000u) & 1u) { t0 = 0xd36a4c09u; z0 = (double)((r0.x) & 255u); } if ((0x80000000u) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        if (~(v0 & m0)) goto done;
        L0: if (--fuel == 0u) goto done;
        c0 = (unsigned char)(unsigned)(unsigned char)(p1 + (i1 * (u2 % ((m0 | g1) | 1u))));
        f0 = f0 * 0.5f + (float)((unsigned)(((0x80000000u % (r0.y | 1u)) + ~(0x7fffffffu + 0x7fffffffu)) == u1) & 255u);
        if ((unsigned)(((unsigned)(x0 >> 70) ^ r0.x) == (unsigned)(w0 >> 29))) {
            c0 = (unsigned char)(unsigned)(v0 < u2);
            c0 = (unsigned char)(unsigned)d0;
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((*q0 ? (unsigned)s0 : g1), 9u, ((unsigned)l0 % (0x550ebe7bu | 1u))); }
                if (((unsigned)c1 ^ ((unsigned)e0 & 3u))) break;
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    q0 = &garr[(unsigned)((int)g0 < (int)u1) & 7u];
                    goto L0;
                    if (fuel < 8u) return (u2 % ((unsigned)(i1 < 9u) | 1u));
                    d0 = d0 * 0.5 + (double)((unsigned)(((1u + p1) + r0.y) && (unsigned)c1) & 1023u);
                    g1 += (unsigned)(0x80d7986du == (m0 << (7u & 31u)));
                }
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)h1, (unsigned)(w0 >> 29), (unsigned)c1); }
                    f0 = f0 * 0.5f + (float)(((unsigned)s0 & 0x9aef16b4u) & 255u);
                    a0[g1 & 3u] = (unsigned)((int)i0 < (int)(unsigned)(signed char)(8u - (m0 ? fuel : (unsigned)c1)));
                    i1 = ((unsigned)e0 << (9u & 31u)) & 15u;
                    g0 = (unsigned)(unsigned char)(unsigned)((int)p0 >= (int)(unsigned)(((unsigned)f0 & (unsigned)s1) || (unsigned)((short)a0[i0 & 3u] > (signed char)8u)));
                    d0 = d0 * 0.5 + (double)(((unsigned)((short)3u > (signed char)*q0) % ((((unsigned)c1 * *q0) % (0x7fffffffu | 1u)) | 1u)) & 1023u);
                }
                if ((7u << (0xffffffffu & 31u))) break;
            }
            for (;;) { if (--fuel == 0u) goto done;
                r0.y ^= ((unsigned)((unsigned)((unsigned)x0 < u0) || garr[i1 & 7u]) * i2);
            }
        }
        while (i0++ < 4u && ((unsigned)x0 + (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)s1 >= (int)garr[i1 & 7u])) break;
                do { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)!(unsigned)(0xe171442eu || (m0 & (unsigned)(x0 >> 70))) & 1023u);
                    h0 = (short)(unsigned)(short)(unsigned)((int)p1 >= (int)0x10000u);
                    if ((unsigned)(signed char)(unsigned)((3u << ((unsigned)l0 & 31u)) == (unsigned)d0)) goto L4;
                    goto L2;
                } while (i2++ < 6u && m0);
            } while (i1++ < 5u && (unsigned)(a0[i0 & 3u] && (garr[i1 & 7u] & 0xffffffffu)));
            switch ((unsigned)(signed char)((unsigned)d0 * u1) & 7u) {
                if (((unsigned)s0 << (0x85fa5c65u & 31u))) break;
                if (i1) goto L4;
                w0 ^= (unsigned long long)0x5174c656u << ((u0 / ((a0[u1 & 3u] << (-(m0 | (unsigned)c1) & 31u)) | 1u)) & 63u);
                do { if (--fuel == 0u) goto done;
                    *q0 += ((unsigned)(*mp < (m0 / (p0 | 1u))) / (p0 | 1u));
                    s0 = (int)((unsigned)(unsigned char)((unsigned)((short)v0 > (signed char)i2) + (2u * g1)) ^ 0x10000u);
                    r0.x = (unsigned)((short)((unsigned)x0 % ((unsigned)b0 | 1u)) > (signed char)((unsigned)(unsigned char)(unsigned)((int)7u < (int)0x62f216adu) / ((unsigned)c1 | 1u)));
                    *q0 += ((7u ^ a0[i0 & 3u]) << (*mp & 31u));
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((short)(unsigned)l0 > (signed char)(i0 << (0x8c4cf932u & 31u)))) break;
                        u1 = u1 * 0x9e3779b1u + (unsigned)(short)((unsigned)((int)0x73aeaf2au < (int)(unsigned)s1) * ((unsigned)((unsigned)b0 < (unsigned)x0) % (u3 | 1u)));
                        *q0 = (0x10000u | 0x7fffffffu);
                        L1: if (--fuel == 0u) goto done;
                    }
                    if (u1) {
                        x0 = x0 * 0x100000001b3ull + a0[i0 & 3u];
                        break; (void)(g0);
                        switch (1u & 7u) {
                            L2: if (--fuel == 0u) goto done;
                            g1 += (1u << (((unsigned)l0 + (unsigned)!(0x7fffffffu + (unsigned)(short)(0xffffffffu << ((unsigned)s0 & 31u)))) & 31u));
                            h1 = (unsigned short)(h1 + i1);
                        }
                    }
                } while (i1++ < 5u && (unsigned)c0);
                i1 = (r0.y + (0x7fffffffu >> (4u & 31u))) & 15u;
            }
        }
    }
    if ((*mp % (garr[u2 & 7u] | 1u))) goto L1;
    c1 = (signed char)((unsigned)b0 & r0.y);
    if ((i1 * (unsigned)h1)) goto L2;
    s0 = (int)((0x80000000u / (a0[i0 & 3u] | 1u)) + p1);
    if ((*q0 - (unsigned)((unsigned)s1 && 0x94e1aa53u))) goto L2;
    L3: if (--fuel == 0u) goto done;
    u1 = ((4u << (4u & 31u)) & p0);
    L4: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)((unsigned)f0 ^ ((unsigned)x0 ^ i1)), ((unsigned)c0 / ((unsigned)f0 | 1u)), (unsigned)c0); }
    u0 ^= (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)((int)p1 >= (int)(unsigned)!(unsigned)((int)m0 >= (int)(unsigned)h0)));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && (unsigned)((unsigned)c1 || m0)) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if ((((0xffffffffu / (5u | 1u)) >> (0xffffffffu & 31u))) & 1u) { t1 = (unsigned)(unsigned char)(unsigned)((unsigned)b0 < 0x847b844bu); z1 = (double)((((u2 ^ (unsigned)h1) % (0x7fffffffu | 1u))) & 255u); } if ((((0xffffffffu / (5u | 1u)) >> (0xffffffffu & 31u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    *q0 = (unsigned)(signed char)(a0[u1 & 3u] % ((unsigned)h0 | 1u));
                    break; (void)((unsigned)s0);
                    switch (((unsigned)h1 >> ((unsigned)!(unsigned)((int)0x2c025948u >= (int)(unsigned)c0) & 31u)) & 7u) {
                        for (;;) { if (--fuel == 0u) goto done;
                            m0 ^= ((unsigned)w0 >> (i0 & 31u));
                            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)!((unsigned)b0 % ((4u * fuel) | 1u)), (unsigned)c0, (unsigned)d0); }
                            case 3u: ;
                            if (budget != 0u) { budget -= 1u; u2 = fn0((u1 / ((p0 - (unsigned)(x0 >> 70)) | 1u)), (unsigned)(unsigned char)(r0.y >> ((unsigned)(w0 >> 29) & 31u)), (unsigned)(signed char)(unsigned)((int)(unsigned)h0 < (int)fuel)); }
                            case 4u: ;
                            case 2u: ;
                        }
                        goto L3;
                        c0 = (unsigned char)(unsigned)((int)(-((unsigned)h1 << (u2 & 31u)) ? 0x80000000u : 5u) < (int)5u);
                        case 7u: ;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(0x80000000u || garr[u2 & 7u]), (unsigned)(i1 || p0), r0.x); }
                    }
                    x0 = x0 * 0x100000001b3ull + ((unsigned)e0 - (((unsigned)s1 >> (v0 & 31u)) - (0x8eeb3343u & garr[u2 & 7u])));
                }
                b0 = p0 != 0u;
            } while (i2++ < 6u && a0[u1 & 3u]);
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(fuel);
                switch ((0x80000000u % ((unsigned)w0 | 1u)) & 7u) {
                    if ((unsigned)(p0 && (unsigned)h1)) {
                        b0 = (unsigned)(i1 == (unsigned)h0) != 0u;
                    } else {
                        case 5u: ;
                        continue; (void)((r0.y + (unsigned)s1));
                        if (budget != 0u) { budget -= 1u; u1 = fn1((i2 & (unsigned)(w0 >> 29)), 0x8bed2769u, (unsigned)((int)1u >= (int)0x10000u)); }
                    }
                    if (u3 == 7u) return ((1u * a0[u1 & 3u]) * (unsigned)((unsigned)h1 || (unsigned)h1));
                    switch (((unsigned)s0 / ((fuel + (unsigned)s0) | 1u)) & 7u) {
                        case 5u: ;
                        case 1u: ;
                        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                            garr[(unsigned)(v0 && g1) & 7u] = (garr[u2 & 7u] ^ 0xd0ef7c1du);
                            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)w0 || 5u), (unsigned)((short)v0 > (signed char)3u), (unsigned)(unsigned char)(unsigned)((int)(unsigned)c0 < (int)(unsigned)((unsigned)h0 == p1))); }
                            if ((unsigned)(u2 < (fuel | 0x80000000u))) break;
                            s1 = (int)((unsigned)s1 + (1u >> ((unsigned)(x0 >> 70) & 31u)));
                            r0.x = ((u1 * p2) - u3);
                            case 2u: ;
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)h0 << (0x7fffffffu & 31u)), ((unsigned)(garr[u2 & 7u] && (unsigned)x0) - a0[u1 & 3u]), (8u | (unsigned)((int)*mp >= (int)1u))); }
                        default: ;
                    }
                }
                if (u3 == 7u) return ((unsigned)x0 + (unsigned)l0);
                if (u3 == 7u) return (a0[i0 & 3u] * u2);
                if ((unsigned)(short)(unsigned)((short)fuel > (signed char)5u)) {
                    if (budget != 0u) { budget -= 1u; u2 = fn1((p0 / (r0.x | 1u)), (unsigned)(unsigned char)(unsigned)((unsigned)l0 < garr[u2 & 7u]), 8u); }
                    s1 = (int)((unsigned)s1 + (((unsigned)!(unsigned)((unsigned)((int)0u < (int)i1) || g1) | (unsigned)h0) % (r0.x | 1u)));
                    if ((unsigned)(0xffffffffu && ~(7u << (0xfbc4f173u & 31u)))) {
                        q0 = &garr[(unsigned)!(*q0 ^ ((unsigned)((unsigned)((int)(unsigned)f0 >= (int)(unsigned)x0) < p0) >> (i1 & 31u))) & 7u];
                        if ((unsigned)!(unsigned)((unsigned)w0 < *q0)) break;
                        d0 = d0 * 0.5 + (double)((unsigned)((int)(p2 * 0x45a6e838u) >= (int)(unsigned)c1) & 1023u);
                        g0 = (unsigned)(0xd1e114d7u && (p2 & 0xa4fdbe4eu));
                        q0 = &garr[(unsigned)!((i2 ^ (unsigned)(w0 >> 29)) % ((garr[u2 & 7u] & (unsigned)h0) | 1u)) & 7u];
                        break; (void)((unsigned)c0);
                    } else {
                        if ((unsigned)(7u == *q0)) break;
                        m0 ^= (unsigned)((int)(unsigned)l0 >= (int)((unsigned)(garr[i1 & 7u] < *mp) + ((unsigned)f0 | (unsigned)s1)));
                        g0 = ((unsigned)((short)(r0.x ^ (unsigned)s1) > (signed char)(unsigned)((int)0xfaa7630du >= (int)i0)) + 0xffffffffu);
                        *q0 = ((0xbbc5ba94u ^ 8u) - (r0.x ^ ((unsigned)h0 ^ 4u)));
                    }
                } else {
                    x0 = x0 * 0x100000001b3ull + (unsigned)(r0.x < 0x318a6b33u);
                }
                if (u3 == 7u) return (unsigned)(signed char)(0x10000u >> ((unsigned)f0 & 31u));
            }
            if (1u) goto L0;
            if (6u) continue;
            r0.y ^= (0x10000u + (garr[u2 & 7u] - i2));
            { unsigned t2; double z2; if ((((unsigned)(short)(0x549e3951u ^ 8u) >> (0xa1e8e115u & 31u))) & 1u) { t2 = ((unsigned)l0 & (unsigned)c1); z2 = (double)(((((unsigned)x0 >> ((unsigned)l0 & 31u)) << (i0 & 31u))) & 255u); } if ((((unsigned)(short)(0x549e3951u ^ 8u) >> (0xa1e8e115u & 31u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                *q0 += ((unsigned)(w0 >> 29) + ((0x13dd20a5u ? fuel : i0) >> (i0 & 31u)));
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)f0, ((unsigned)l0 * i1), (u0 ? u3 : (unsigned)f0)); }
                if (fuel < 8u) return (unsigned)((short)0x17f61d9au > (signed char)(unsigned)b0);
                c1 = (signed char)(unsigned)((int)(g0 | 5u) >= (int)fuel);
                continue; (void)((unsigned)((unsigned)(x0 >> 70) || (unsigned)(x0 >> 70)));
            }
        }
    }
    if ((a0[u1 & 3u] & garr[i1 & 7u])) goto L3;
    if (u3 == 7u) return (unsigned)d0;
    if ((p1 ^ (u1 / (0x7fffffffu | 1u)))) {
        if ((u1 + m0)) goto L1;
    }
    d0 = d0 * 0.5 + (double)((unsigned)(0x759c1f7bu && (unsigned)x0) & 1023u);
    if (0x3e72f73fu) goto L0;
    i1 = (-(unsigned)(((unsigned)(w0 >> 29) ^ 0x7fffffffu) == a0[u1 & 3u]) >> (1u & 31u)) & 15u;
    if ((unsigned)((unsigned)b0 < 0x243f552u)) goto L1;
    if (-((unsigned)((int)g1 < (int)(unsigned)b0) * (unsigned)b0)) goto L1;
    while (i0++ < 2u && (unsigned)((int)(unsigned)((unsigned)c0 && *q0) < (int)fuel)) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)(0x3d3684b8u & 1023u);
        if ((unsigned)((short)7u > (signed char)1u)) break;
        garr[(4u * (unsigned)c0) & 7u] = g1;
        x0 = x0 * 0x100000001b3ull + (unsigned)(((p0 ^ u0) * i2) < 0x97922c7cu);
    }
    goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    L1: if (--fuel == 0u) goto done;
    c1 = (signed char)((p2 ^ 0x257c2d5u) / (((unsigned)(x0 >> 70) | ((unsigned)s0 << (p1 & 31u))) | 1u));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 2u && (unsigned)(((unsigned)c1 - (unsigned)c1) && 4u)) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + (unsigned)(7u < 0x10000u));
            do { if (--fuel == 0u) goto done;
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(1u < 0x80000000u)) goto L1;
                }
                g0 = ((8u | v0) - (u0 ^ (unsigned)(0xd58c48d0u || 0x80000000u)));
                if ((unsigned)((short)*mp > (signed char)-(unsigned)((int)0xbc27b963u < (int)0x3ae023d1u))) {
                    f0 = f0 * 0.5f + (float)(u3 & 255u);
                    if (((unsigned)((int)garr[i1 & 7u] >= (int)0xffffffffu) & (unsigned)x0)) break;
                    L2: if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((fuel << (3u & 31u)), (i2 ? 8u : (unsigned)l0), (unsigned)((short)(unsigned)c1 > (signed char)0x7fffffffu)); }
                } else {
                    do { if (--fuel == 0u) goto done;
                        if (0x4c6939eeu) goto L3;
                        if ((unsigned)(unsigned char)(0x34a90488u | 0x7fffffffu)) break;
                    } while (i0++ < 2u && (unsigned)((unsigned)c0 < (unsigned)((short)0xe839bd79u > (signed char)(unsigned)(w0 >> 29))));
                    if (((0x80000000u - i0) / ((unsigned)x0 | 1u))) {
                        u2 = u2 * 0x9e3779b1u + (unsigned)((unsigned)((short)0x2acaf5efu > (signed char)g0) < (0x80000000u + 0xeae5a4a4u));
                        break; (void)(2u);
                        if (u3 == 7u) return (p0 & (p0 >> ((unsigned)c0 & 31u)));
                    }
                    w0 = w0 * 6364136223846793005ull + ((unsigned)((short)0x10000u > (signed char)p0) * p2);
                    u1 ^= (0x80000000u ? (unsigned)(a0[u1 & 3u] == garr[i1 & 7u]) : u1);
                }
                if (u3 == 7u) return (unsigned)((unsigned)w0 && 0xffffffffu);
                while (i0++ < 5u && (g0 ^ g1)) { if (--fuel == 0u) goto done;
                    if ((unsigned)(unsigned char)(unsigned)((short)(unsigned)(short)(0x80000000u & (unsigned)s1) > (signed char)(unsigned)b0)) continue;
                }
                g1 += (unsigned)(((unsigned)l0 & 0x5a21057u) && p1);
            } while (i2++ < 2u && (unsigned)(unsigned char)(unsigned)((int)0x1110694du < (int)0x7fffffffu));
            w0 ^= (unsigned long long)(5u % (fuel | 1u)) << ((((unsigned)l0 | (u0 & 0u)) & (unsigned)((unsigned)s0 && 2u)) & 63u);
        }
        while (i1++ < 4u && (unsigned)!(unsigned)((p2 >> (r0.y & 31u)) || p1)) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + ((0xffffffffu ^ 0xe6114cfcu) / ((unsigned)(w0 >> 29) | 1u)));
            if (((unsigned)((int)0x82cc17c3u < (int)0x10000u) % (1u | 1u))) {
                L3: if (--fuel == 0u) goto done;
                switch (i0 & 7u) {
                    *q0 = (unsigned)((unsigned)c0 == a0[i0 & 3u]);
                    if ((1u * (unsigned)d0)) {
                        if ((unsigned)w0) {
                            if (budget != 0u) { budget -= 1u; u2 = fn0((((unsigned)h1 - (unsigned)(w0 >> 29)) * 0x10000u), (garr[u2 & 7u] ^ (i2 * u2)), (unsigned)(*mp == 0x7fffffffu)); }
                            case 1u: ;
                        } else {
                            if ((p2 >> (p1 & 31u))) continue;
                        }
                    }
                    f0 = f0 * 0.5f + (float)((unsigned)((int)0xffffffffu < (int)((unsigned)(w0 >> 29) - v0)) & 255u);
                    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)s1 == (unsigned)(signed char)(*mp & (0x7fffffffu << ((0x813e892du + fuel) & 31u)))));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn2((0xffffffffu / ((unsigned)((short)0x5e5c6e9eu > (signed char)0x80000000u) | 1u)), (0x43798fdau << (0xbd18ee3eu & 31u)), (unsigned)((unsigned)w0 < u2)); }
                v0 = (unsigned)((unsigned)((unsigned)(0x78c4d875u && (unsigned)(w0 >> 29)) && *q0) < -((unsigned)w0 + 9u));
            } else {
                *q0 += 0xffffffffu;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)w0, (g1 % ((unsigned)s0 | 1u)), (unsigned)(((unsigned)c1 | 7u) && u0)); }
            }
            l0 = (long)((unsigned long)l0 + ((unsigned)f0 * (unsigned)((unsigned)(a0[u1 & 3u] && (i1 << (p0 & 31u))) == (unsigned)w0)));
            L4: if (--fuel == 0u) goto done;
            if (-(i2 << (a0[u1 & 3u] & 31u))) break;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn2(((r0.y % (0x5001a3a6u | 1u)) | m0), ((unsigned)f0 | m0), ((unsigned)(0x80000000u < u2) + (unsigned)s0)); }
        if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)h0 * 5u), 0x10000u, (unsigned)(i0 && (unsigned)(p1 && (unsigned)(w0 >> 29)))); }
        if ((unsigned)((int)~(0u & 1u) >= (int)u2)) {
            if ((((unsigned)c1 % (4u | 1u)) * 0x2e21bb2u)) break;
            c0 = (unsigned char)(unsigned)(0x10000u == u2);
            break; (void)((unsigned)((int)(unsigned)(*mp == (unsigned)(w0 >> 29)) < (int)p1));
            switch ((unsigned)(signed char)(0x7fffffffu - (i1 + 0x7fffffffu)) & 7u) {
                u2 ^= (unsigned)(signed char)(1u >> ((u0 * 0x8b07bc39u) & 31u));
            }
            s1 = (int)((unsigned)s1 + -(unsigned)(r0.x < ((a0[u1 & 3u] / (0x10000u | 1u)) >> ((unsigned)(p1 < fuel) & 31u))));
        }
    }
    do { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((unsigned)(short)(unsigned)((garr[i1 & 7u] / ((unsigned)(x0 >> 70) | 1u)) < (g1 & i2)) & 255u);
        garr[(garr[u2 & 7u] >> (a0[u1 & 3u] & 31u)) & 7u] = (unsigned)(((unsigned)(x0 >> 70) | (u1 + 1u)) || (0xee564c0cu % (garr[u2 & 7u] | 1u)));
        break; (void)((unsigned)((short)(unsigned)h1 > (signed char)0x10000u));
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            u3 = u3 * 0x9e3779b1u + g0;
        }
        do { if (--fuel == 0u) goto done;
            s0 = (int)(unsigned)(0x10000u && i1);
            r0.x = (unsigned)(*q0 && p1);
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                goto done;
                r0.y ^= ((unsigned)(signed char)(fuel * m0) + ((i2 ^ u0) | (unsigned)h1));
                break; (void)((i2 - i2));
                r0.x = 0x7fffffffu;
                v0 = (unsigned)((p2 % ((unsigned)h0 | 1u)) || garr[i1 & 7u]);
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn1((0x75960919u % (((unsigned)c1 ^ 0x80000000u) | 1u)), ((unsigned)d0 >> (garr[i1 & 7u] & 31u)), (unsigned)(short)(unsigned)((short)(unsigned)c0 > (signed char)(unsigned)((int)(unsigned)l0 < (int)p2))); }
                    if (0x7fffffffu) break;
                    if (v0) break;
                    u1 = (unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)c0);
                    if (garr[i1 & 7u]) continue;
                    h1 = (unsigned short)(h1 + (0x80000000u ? i0 : (unsigned)((int)0xffffffffu >= (int)garr[i1 & 7u])));
                }
            }
            break; (void)(6u);
            while ((fuel * (0x3e101fa3u << (garr[i1 & 7u] & 31u)))) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)a0[u1 & 3u];
                if (u0) continue;
                if (0x10000u) break;
                if ((unsigned)x0) break;
            }
            if ((i2 + (garr[i1 & 7u] ^ a0[i0 & 3u]))) break;
        } while (i1++ < 2u && ((unsigned)h0 ^ ~(0xb2f2d8d3u & 0x12bbf63du)));
        l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)((short)(unsigned)(v0 && (unsigned)b0) > (signed char)0xffffffffu) < (int)(u0 - 8u)));
    } while (i0++ < 5u && 2u);
    goto L3;
    v0 = ((unsigned)h1 / (2u | 1u));
    g0 = (unsigned)!((unsigned)((unsigned)(u3 == 6u) && (unsigned)e0) % ((unsigned)(signed char)(i2 % (0u | 1u)) | 1u));
    if ((unsigned)s0) {
        if ((unsigned)((short)((unsigned)s0 * (unsigned)e0) > (signed char)r0.y)) goto L4;
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)s1 + (unsigned)l0)) break;
            g0 = (p1 + g0);
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((0x7fffffffu & 0x10000u) < p1), 3u, (u2 >> ((unsigned)c1 & 31u))); }
            switch ((unsigned)(x0 >> 70) & 7u) {
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 6u: ;
                    g1 += (fuel ? (unsigned)b0 : g0);
                    if (budget != 0u) { budget -= 1u; u1 = fn2(0x9042c9d2u, (unsigned)((short)0xf11e8333u > (signed char)(v0 & (unsigned)x0)), (*mp % (i0 | 1u))); }
                }
                while (i1++ < 5u && ((unsigned)(x0 >> 70) / (0xffffffffu | 1u))) { if (--fuel == 0u) goto done;
                    switch ((unsigned)((int)6u >= (int)(unsigned)h1) & 7u) {
                        d0 = d0 * 0.5 + (double)(((p2 + i0) | (unsigned)(unsigned char)((unsigned)((int)i0 >= (int)0xe9e1747cu) * m0)) & 1023u);
                        if ((unsigned)(short)(u2 & (unsigned)h1)) goto done;
                        switch ((unsigned)((int)~(unsigned)((int)8u >= (int)*q0) >= (int)0x7fffffffu) & 7u) {
                            *mp = (unsigned)(signed char)((unsigned)((unsigned)h0 && 0xffffffffu) ? 5u : 0x8c4155d4u);
                            s0 = (int)(unsigned)((i0 << (a0[i0 & 3u] & 31u)) && (unsigned)(w0 >> 29));
                            c0 = (unsigned char)(0xffffffffu + m0);
                        }
                        break; (void)((unsigned)(*mp || (0xffffffffu >> ((unsigned)h1 & 31u))));
                        w0 ^= (unsigned long long)(u0 - (unsigned)w0) << (r0.x & 63u);
                    }
                }
                m0 ^= (g1 << (p2 & 31u));
            }
            if ((p2 << ((unsigned)((unsigned)h1 < p0) & 31u))) continue;
            u1 = u1 * 0x9e3779b1u + (unsigned)((int)(0x80000000u ? (unsigned)s1 : i0) < (int)0x80000000u);
        }
        c0 = (unsigned char)(unsigned)(garr[u2 & 7u] || -(unsigned)((unsigned)(garr[i1 & 7u] == (0xffffffffu | 2u)) && i2));
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(short)(3u & u2), (unsigned)f0, (g1 - (unsigned)d0)); }
    } else {
        if ((0xffffffffu % (u3 | 1u))) goto done;
        a0[0x1af807f5u & 3u] = (((unsigned)e0 / (i0 | 1u)) >> ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)c0) & 31u));
        if (0x69b62467u) {
            if ((unsigned)(r0.x == 0x4e3db614u)) goto L3;
        }
        if ((unsigned)((int)a0[u1 & 3u] >= (int)i2)) {
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)((unsigned)s1 / (0x80000000u | 1u)) << (~((0x9a0f0cb6u - fuel) ^ r0.x) & 63u);
                break; (void)((r0.x / (m0 | 1u)));
                if ((unsigned)((int)(unsigned)c1 >= (int)(unsigned)l0)) {
                    switch (a0[u1 & 3u] & 7u) {
                        case 6u: ;
                        v0 = (i2 | (0xad77373au / ((*q0 | g0) | 1u)));
                        c1 = (signed char)(~(((unsigned)l0 + a0[i0 & 3u]) % (3u | 1u)) | fuel);
                    }
                    if ((u0 & i2)) break;
                }
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (garr[i1 & 7u]) {
                        if (u3) goto L0;
                        i1 = (unsigned)(a0[u1 & 3u] == u0) & 15u;
                    }
                    if (fuel < 8u) return (a0[i0 & 3u] % (5u | 1u));
                }
                b0 = ((unsigned)l0 * 0x80000000u) != 0u;
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)d0 % ((unsigned)(x0 >> 70) | 1u)), ((unsigned)b0 & (unsigned)(*q0 < 0xffffffffu)), i0); }
            }
        } else {
            if ((*mp / (((unsigned)e0 * 8u) | 1u))) goto L3;
        }
    }
    if ((r0.x / (6u | 1u))) {
        if (budget != 0u) { budget -= 1u; u3 = fn2(5u, (unsigned)(((unsigned)s0 ^ *mp) || (unsigned)d0), (unsigned)s0); }
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            g1 += ((0x4cfbb77eu / (u0 | 1u)) / (garr[i1 & 7u] | 1u));
            *q0 += (unsigned)(((0x10000u << ((unsigned)h0 & 31u)) & g1) || i1);
            u1 = 7u;
            if (budget != 0u) { budget -= 1u; u0 = fn0(3u, v0, 0x10000u); }
            if ((unsigned)(g0 || (unsigned)s1)) {
                if ((unsigned)(fuel || u3)) {
                    break; (void)(2u);
                    if (budget != 0u) { budget -= 1u; u0 = fn2(3u, ((unsigned)h0 >> (0x80000000u & 31u)), g0); }
                    while (i1++ < 6u && (unsigned)((int)0xffffffffu < (int)p1)) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn1(u3, (unsigned)(short)(0x5ca52c6cu % (p0 | 1u)), (unsigned)(0xab734e75u == (unsigned)(w0 >> 29))); }
                        s0 = (int)((unsigned)c0 << ((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)c0) & 31u));
                        m0 ^= (unsigned)((int)1u < (int)((unsigned)s1 ^ 0x80000000u));
                    }
                    for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        *q0 += ((r0.y & 0x2468638bu) % ((unsigned)(u1 < u0) | 1u));
                        if (budget != 0u) { budget -= 1u; u0 = fn2((9u % (a0[u1 & 3u] | 1u)), (unsigned)((int)(unsigned)(u0 < 1u) < (int)0x8572a293u), ((i1 ^ 0x413157aau) / ((unsigned)w0 | 1u))); }
                        b0 = (unsigned)(((0x3667280eu ^ (unsigned)h1) / (0x76a90016u | 1u)) && (i0 % (6u | 1u))) != 0u;
                        i1 = (unsigned)w0 & 15u;
                    }
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(0xe8a4f963u << ((u3 % ((unsigned)s0 | 1u)) & 31u)) >= (int)3u);
                }
                u2 = u2 * 0x9e3779b1u + ((unsigned)((int)((unsigned)b0 + (unsigned)(x0 >> 70)) < (int)(unsigned)l0) & 5u);
                continue; (void)(*q0);
                if ((unsigned)s0) break;
            } else {
                s1 = (int)((unsigned)s1 + (p0 & (5u << (((unsigned)b0 << ((unsigned)d0 & 31u)) & 31u))));
                if ((((unsigned)e0 >> ((unsigned)e0 & 31u)) | (unsigned)l0)) goto L3;
                continue; (void)((unsigned)(p1 < 0x10000u));
            }
        }
        if (fuel < 8u) return (unsigned)((int)r0.y >= (int)r0.y);
        do { if (--fuel == 0u) goto done;
            if (g0) break;
        } while (i0++ < 7u && (unsigned)(signed char)((unsigned)w0 % (a0[i0 & 3u] | 1u)));
    }
    if (0x80000000u) goto done;
    if (i2) goto L2;
    if (budget != 0u) { budget -= 1u; u3 = fn0((0xbd69c9c5u & (unsigned)c0), a0[i0 & 3u], ((unsigned)(x0 >> 70) - r0.y)); }
    f0 = f0 * 0.5f + (float)((g1 << (((unsigned)b0 << (9u & 31u)) & 31u)) & 255u);
    switch (((8u ^ (unsigned)s1) / (p2 | 1u)) & 7u) {
        case 7u: ;
    }
    if (u0) goto L0;
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)i1 >= (int)fuel);
    do { if (--fuel == 0u) goto done;
        if ((p2 & u0)) {
            h0 = (short)((unsigned)(0xf2b9e01au && -(u0 % ((unsigned)d0 | 1u))) % ((unsigned)s0 | 1u));
            h0 = (short)(unsigned)((unsigned)((short)0xb55ab88bu > (signed char)(unsigned)h1) == -(0x10000u / (fuel | 1u)));
            if (budget != 0u) { budget -= 1u; u3 = fn1(0x7fffffffu, -(u1 & (unsigned)c1), (unsigned)(signed char)(unsigned)((int)((unsigned)(w0 >> 29) % (2u | 1u)) >= (int)i2)); }
            g0 = (0x7327436cu >> ((unsigned)(p1 || ((unsigned)h1 & u3)) & 31u));
            if ((unsigned)((int)(unsigned)h0 < (int)(unsigned)(unsigned char)(0xdebd87e6u - 4u))) continue;
            switch (((unsigned)s1 / ((unsigned)c0 | 1u)) & 7u) {
                do { if (--fuel == 0u) goto done;
                    switch (8u & 7u) {
                        d0 = d0 * 0.5 + (double)(((0x7fffffffu + 0x812aa95u) & (5u ^ 9u)) & 1023u);
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)d0, (r0.y ? i1 : u1), p1); }
                    }
                    w0 ^= (unsigned long long)(unsigned)h0 << ((unsigned)(unsigned char)(unsigned)((int)0x6fd72966u < (int)v0) & 63u);
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((short)(unsigned)e0 > (signed char)0xfa5f4714u) || (unsigned)((short)g1 > (signed char)6u)));
                    m0 ^= 0x7fffffffu;
                    *q0 += (g1 ^ ((unsigned)(0xaf056f51u < r0.x) / (0x10000u | 1u)));
                } while (i1++ < 5u && (unsigned)(signed char)(unsigned)(0u == (unsigned)(signed char)(unsigned)((unsigned)c0 == g0)));
                u2 ^= (unsigned)(((unsigned)l0 % ((unsigned)x0 | 1u)) < (unsigned)(0x10000u || 4u));
                if ((unsigned)((0xffffffffu ^ 5u) || (unsigned)h1)) goto L0;
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)g0 > (signed char)a0[i0 & 3u]), ((unsigned)(x0 >> 70) >> (0x10000u & 31u)), (i1 * (unsigned)((unsigned)w0 == 0xa2035f57u))); }
                case 5u: ;
            }
        } else {
            u1 ^= (2u - ((a0[i0 & 3u] | 0x7fffffffu) * (unsigned)(0x882289d0u && i1)));
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)u1 < (int)8u), u1, (unsigned)(signed char)(a0[u1 & 3u] % ((unsigned)f0 | 1u))); }
                while (i2++ < 2u && (unsigned)(0x80000000u == 0xffffffffu)) { if (--fuel == 0u) goto done;
                    if ((unsigned)(i1 < i2)) break;
                    while (a0[i0 & 3u]) { if (--fuel == 0u) goto done;
                        s0 = (int)((unsigned)(v0 && u0) + u3);
                        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)(x0 >> 70) - (unsigned)(0x1b537e1u < (unsigned)c0)), (unsigned)((int)0x29e88753u >= (int)u1), u2); }
                        break; (void)((a0[u1 & 3u] << (i2 & 31u)));
                        if ((unsigned)f0) break;
                    }
                    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        c1 = (signed char)(unsigned)(0x10000u < 2u);
                        break; (void)(((unsigned)((unsigned)h0 == p0) + fuel));
                    }
                    x0 = x0 * 0x100000001b3ull + ((unsigned)((int)r0.y < (int)(unsigned)f0) | (unsigned)(signed char)((unsigned)s1 % (6u | 1u)));
                    u0 += (unsigned)((6u ? (unsigned)b0 : 7u) < 0xd625e9e3u);
                }
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn1(0x7aec8aa5u, -((2u & i0) % (p2 | 1u)), u2); }
                    i1 = (unsigned)((int)(unsigned)(signed char)(3u + u2) < (int)(garr[u2 & 7u] | (unsigned)((int)u0 < (int)(unsigned)(w0 >> 29)))) & 15u;
                    goto done;
                    if (6u) break;
                }
                b0 = ((unsigned)((short)v0 > (signed char)*mp) % ((unsigned)(x0 >> 70) | 1u)) != 0u;
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)u3 > (signed char)0x7cb2946fu)) continue;
                    if (g0) break;
                    c0 = (unsigned char)(unsigned)(((unsigned)(4u || 0xc160854bu) + a0[u1 & 3u]) || 0x837f188u);
                    switch (m0 & 7u) {
                        q0 = &garr[(0x10000u - m0) & 7u];
                        switch (0xf91529aau & 7u) {
                            e0 = e0 * 0.5L + (long double)((unsigned)(short)(((unsigned)(signed char)(unsigned)(g0 || (unsigned)c0) | garr[u2 & 7u]) * (unsigned)(short)(i1 << (0xe105044cu & 31u))) & 1023u);
                            u2 ^= (unsigned)((0x80000000u >> (m0 & 31u)) || (m0 ? 0u : (unsigned)w0));
                            h1 = (unsigned short)(h1 + (unsigned)(~(unsigned)((unsigned)(w0 >> 29) == (i1 * (unsigned)(short)(i1 << (a0[u1 & 3u] & 31u)))) < 0x7dbaefbbu));
                        }
                        garr[(unsigned)s0 & 7u] = ((0x7fffffffu >> ((p2 >> ((0x7fffffffu / (0x440ad923u | 1u)) & 31u)) & 31u)) ^ (unsigned)w0);
                    }
                    if ((unsigned)((int)r0.y < (int)r0.y)) {
                        a0[garr[u2 & 7u] & 3u] = (unsigned)((p0 >> ((unsigned)w0 & 31u)) < p2);
                        if ((unsigned)((unsigned)x0 && (unsigned)h1)) continue;
                    } else {
                        if (i0) break;
                    }
                }
                switch ((g1 ^ a0[i0 & 3u]) & 7u) {
                    g0 = 0xae582a23u;
                }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)9u >= (int)((unsigned)w0 * 0x20b60963u)), ((unsigned)f0 & garr[u2 & 7u]), g0); }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0x7d9f297eu == (unsigned)(garr[u2 & 7u] < (unsigned)d0)), (0x848eaf6au / (0x80000000u | 1u)), (unsigned)((unsigned)f0 || 0u)); }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn2(-(unsigned)((int)(unsigned)d0 >= (int)8u), (unsigned)((short)(unsigned)((unsigned)w0 == i0) > (signed char)fuel), (unsigned)((int)5u < (int)v0)); }
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)!(0xaf48c6fau % (*mp | 1u)), (unsigned)(u3 && g1), u0); }
    } while (i0++ < 6u && -(unsigned)(a0[u1 & 3u] && (i1 << (6u & 31u))));
    switch ((unsigned)((int)g0 >= (int)(unsigned)(short)(0xe2a2116cu | 0xffffffffu)) & 7u) {
        h0 = (short)0x88ba4c44u;
        case 4u: ;
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            g0 = ~(unsigned)((short)(i0 / (0x69c34d29u | 1u)) > (signed char)2u);
            m0 ^= (unsigned)(unsigned char)((unsigned)x0 >> ((unsigned)(r0.y || (unsigned)((unsigned)c1 && u0)) & 31u));
        }
        do { if (--fuel == 0u) goto done;
            case 0u: ;
            f0 = f0 * 0.5f + (float)(((unsigned)((unsigned)(u0 == g1) == (unsigned)s1) + 9u) & 255u);
        } while (i0++ < 4u && p0);
        q0 = &garr[((unsigned)(p2 == 0x306306f6u) | (unsigned)((garr[i1 & 7u] % (0x80000000u | 1u)) && (unsigned)f0)) & 7u];
        h0 = (short)((u1 | (m0 << ((unsigned)(g1 && m0) & 31u))) ^ 0x80000000u);
    }
    do { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)s1 < (int)(i2 % (v0 | 1u)));
        if (((unsigned)s1 * (unsigned)(signed char)(0x80000000u + 0x10000u))) {
            if ((unsigned)w0) break;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)d0, (unsigned)(short)((unsigned)(x0 >> 70) ^ *q0), (unsigned)(i0 && (unsigned)(short)(8u + (unsigned)(x0 >> 70)))); }
        }
        break; (void)(r0.y);
        a0[(unsigned)!(m0 * (unsigned)c0) & 3u] = (unsigned)(short)(u2 + ~((unsigned)b0 ^ a0[u1 & 3u]));
        if (-(m0 / ((unsigned)w0 | 1u))) break;
    } while (i0++ < 2u && ((unsigned)e0 & ((unsigned)f0 & 0x7a6fcf99u)));
    if (budget != 0u) { budget -= 1u; u1 = fn2(u1, 5u, (unsigned)e0); }
    if ((unsigned)((unsigned)b0 && r0.y)) goto L0;
    r0.x = 2u;
    i1 = (unsigned)((int)g0 < (int)((unsigned)(0x8ceba842u || (unsigned)s1) / (0x80000000u | 1u))) & 15u;
    if (((unsigned)((int)(unsigned)c1 >= (int)(unsigned)h0) | 0xffffffffu)) goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn0((i2 - 2u), m0, (unsigned)(x0 >> 70)); }
    goto L0;
    if ((unsigned)((int)u1 < (int)0x7fffffffu)) goto L3;
    if ((unsigned)(short)(unsigned)((int)g0 < (int)(unsigned)h1)) {
        { unsigned t0; double z0; if (((unsigned)!(r0.x >> (((unsigned)(w0 >> 29) ^ 0x866e1cf3u) & 31u))) & 1u) { t0 = ((unsigned)(w0 >> 29) + 0xfdc129e9u); z0 = (double)(((unsigned)s1) & 255u); } if (((unsigned)!(r0.x >> (((unsigned)(w0 >> 29) ^ 0x866e1cf3u) & 31u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            { unsigned t1; double z1; if (((unsigned)(short)(unsigned)(g0 && 3u)) & 1u) { t1 = (unsigned)e0; z1 = (double)(((unsigned)((int)(unsigned)c1 < (int)(1u * 0xfc8051e8u))) & 255u); } if (((unsigned)(short)(unsigned)(g0 && 3u)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                if (1u) goto L0;
                v0 = (p0 ^ m0);
                u1 = u1 * 0x9e3779b1u + (garr[i1 & 7u] >> (p2 & 31u));
                do { if (--fuel == 0u) goto done;
                    if (((unsigned)d0 / ((unsigned)(unsigned char)((unsigned)h1 ^ i1) | 1u))) break;
                    c1 = (signed char)(0x95caec07u | ((unsigned)((int)(unsigned)(w0 >> 29) < (int)0x7fffffffu) + (unsigned)e0));
                } while (i0++ < 4u && (unsigned)((short)0x8fa5591du > (signed char)0x7fffffffu));
                if (budget != 0u) { budget -= 1u; u2 = fn1((u2 + 0x8ac52df4u), g1, (unsigned)(a0[u1 & 3u] && u0)); }
            }
            e0 = e0 * 0.5L + (long double)(((unsigned)(short)((unsigned)e0 >> (r0.y & 31u)) / (0u | 1u)) & 1023u);
            if ((unsigned)(i2 || (unsigned)((int)v0 < (int)0x7fffffffu))) goto L2;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(short)(unsigned)((0x247062ecu % (0xbd8db183u | 1u)) && p1), 2u, ((unsigned)(w0 >> 29) | u2)); }
            goto L4;
            if (0x80000000u) goto L2;
        }
    }
    c0 = (unsigned char)(0xb615c9b7u & (unsigned)e0);
    goto done;
    r0.y ^= (a0[i0 & 3u] - (unsigned)((unsigned)((int)0x6aceff47u < (int)0xffffffffu) && 1u));
    { unsigned t2; double z2; if (((unsigned)(7u || i1)) & 1u) { t2 = (unsigned)c0; z2 = (double)(((unsigned)!(unsigned)(4u < v0)) & 255u); } if (((unsigned)(7u || i1)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        { unsigned t3; double z3; if ((fuel) & 1u) { t3 = (unsigned)(0x8a6c382fu && ((unsigned)w0 >> (u2 & 31u))); z3 = (double)(((0x7fffffffu >> (~(r0.y % (r0.y | 1u)) & 31u))) & 255u); } if ((fuel) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)(x0 >> 70);
            u0 += 0x93e8b77du;
        }
        *q0 = ((i2 % ((unsigned)c0 | 1u)) / (-(garr[u2 & 7u] | (r0.y ^ g1)) | 1u));
    }
    *q0 += (unsigned)((short)(unsigned)b0 > (signed char)0xa1bb07f4u);
    while (i0++ < 6u && (unsigned)((int)0x80000000u >= (int)5u)) { if (--fuel == 0u) goto done;
        r0.y ^= m0;
        while ((g1 / (((unsigned)h1 << (0xa04bcedau & 31u)) | 1u))) { if (--fuel == 0u) goto done;
            q0 = &garr[(0x80000000u / (((0x80000000u + (unsigned)((short)u1 > (signed char)(unsigned)(x0 >> 70))) + u1) | 1u)) & 7u];
            s0 = (int)(unsigned)((int)(6u << (u3 & 31u)) < (int)((unsigned)w0 + (unsigned)c1));
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                g1 += (unsigned)(u2 && (0x7fffffffu / (0x80000000u | 1u)));
                l0 = (long)((unsigned long)l0 + (unsigned)(garr[u2 & 7u] < u2));
                goto L0;
            }
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                u3 += 3u;
                if ((unsigned)((int)(unsigned)s0 >= (int)((unsigned)(x0 >> 70) | (unsigned)x0))) break;
                m0 ^= g0;
                i2 = (*mp * ((unsigned)x0 | (unsigned)(v0 && *q0))) & 15u;
            }
            u1 = ((unsigned)(3u || garr[i1 & 7u]) & 0xad35e04bu);
        }
        b0 = ((0x4ec5747du & ((unsigned)h0 & 0xd4ea6e97u)) ^ (fuel & 4u)) != 0u;
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)c1) break;
    } while (i0++ < 4u && (unsigned)(p0 || 9u));
    { unsigned t4; double z4; if (((g0 & 0x4ae2d07fu)) & 1u) { t4 = (unsigned)(a0[u1 & 3u] < ((unsigned)d0 / (i2 | 1u))); z4 = (double)(((unsigned)(v0 || (unsigned)x0)) & 255u); } if (((g0 & 0x4ae2d07fu)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(((unsigned)((int)0x2046dc73u >= (int)0x80000000u) - u2) & 1023u);
            if ((a0[i0 & 3u] + (0xffffffffu ^ 0x7fffffffu))) break;
            while ((0xd66a13c1u % ((unsigned)((int)fuel >= (int)r0.y) | 1u))) { if (--fuel == 0u) goto done;
                break; (void)((i2 % (v0 | 1u)));
            }
        }
    }
    *q0 += ((unsigned)((int)0x10000u >= (int)0x3ad40230u) >> (*mp & 31u));
    if ((unsigned)b0) {
        do { if (--fuel == 0u) goto done;
            if (g0) break;
            if ((unsigned)w0) continue;
            if (budget != 0u) { budget -= 1u; u2 = fn2((m0 * (0x2433f3fcu ^ g0)), (unsigned)((short)(unsigned)(g0 || i2) > (signed char)0x3722d5ddu), (garr[u2 & 7u] - (unsigned)h1)); }
            w0 = w0 * 6364136223846793005ull + ((u2 & 0x397330ebu) - ((unsigned)(unsigned char)(unsigned)((short)fuel > (signed char)g1) << (0x10000u & 31u)));
        } while (i0++ < 2u && (0u << ((unsigned)(unsigned char)(p1 / ((unsigned)c1 | 1u)) & 31u)));
        s1 = (int)((unsigned)s1 + (unsigned)(w0 >> 29));
    } else {
        if ((unsigned)w0) goto L3;
    }
    switch ((unsigned)x0 & 7u) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            g1 += (unsigned)((unsigned)e0 || (0xb5394f27u - *q0));
            if ((i1 << ((unsigned)f0 & 31u))) break;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= 1u;
                if (budget != 0u) { budget -= 1u; u0 = fn0(garr[i1 & 7u], (garr[u2 & 7u] >> (u1 & 31u)), 0xcf822879u); }
            }
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)(signed char)((unsigned)(signed char)(unsigned)(g1 == (unsigned)b0) * (unsigned)h0)) {
                    case 6u: ;
                    b0 = (i2 / ((unsigned)((short)(unsigned)h1 > (signed char)(unsigned)!((unsigned)w0 << (g1 & 31u))) | 1u)) != 0u;
                }
                case 1u: ;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)w0, (unsigned)((short)r0.x > (signed char)u1), (0xc96e28d9u % ((unsigned)w0 | 1u))); }
                while (i2++ < 6u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                    { unsigned t5; double z5; if (((unsigned)((int)i0 < (int)(unsigned)!(7u / ((unsigned)w0 | 1u)))) & 1u) { t5 = (unsigned)!((unsigned)(0x9f6db5e3u && u0) | (unsigned)f0); z5 = (double)(((unsigned)(9u || 5u)) & 255u); } if (((unsigned)((int)i0 < (int)(unsigned)!(7u / ((unsigned)w0 | 1u)))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                        b0 = ((unsigned)b0 & (unsigned)s1) != 0u;
                        *q0 = (((unsigned)(r0.x == (4u >> (p0 & 31u))) & garr[i1 & 7u]) / (fuel | 1u));
                        i0 = ((unsigned)(i1 || a0[u1 & 3u]) % (-(unsigned)(u2 || 0xef335552u) | 1u)) & 15u;
                        c1 = (signed char)(unsigned)(unsigned char)(unsigned)((a0[u1 & 3u] % ((unsigned)(i2 || g0) | 1u)) && (unsigned)(0x10000u == (unsigned)b0));
                        u0 = u0 * 0x9e3779b1u + (unsigned)(signed char)(0x4340724fu ? 4u : (unsigned)f0);
                        if ((v0 ? 0xc05131acu : (unsigned)c0)) {
                            m0 ^= -(unsigned)((short)(unsigned)((int)(0x7fffffffu - garr[i1 & 7u]) < (int)(unsigned)b0) > (signed char)p1);
                        }
                    }
                    do { if (--fuel == 0u) goto done;
                        case 5u: ;
                        if ((unsigned)(0x10000u || (unsigned)h0)) goto done;
                        break; (void)((unsigned)(u1 == p1));
                        goto L2;
                        h1 = (unsigned short)(h1 + (unsigned)((unsigned)((unsigned)(r0.y < ((unsigned)(x0 >> 70) / ((unsigned)l0 | 1u))) && garr[i1 & 7u]) == 7u));
                    } while (i0++ < 2u && (unsigned)(0x10000u || garr[i1 & 7u]));
                    break; (void)((unsigned)((unsigned)w0 && garr[u2 & 7u]));
                    if (budget != 0u) { budget -= 1u; u1 = fn1(((*mp >> ((unsigned)d0 & 31u)) * (unsigned)h1), (unsigned)((a0[u1 & 3u] ^ (unsigned)e0) && (unsigned)h1), (unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)m0 >= (int)i2) >= (int)0x5fdd4effu)); }
                }
                do { if (--fuel == 0u) goto done;
                    if (0xffffffffu) goto L0;
                    default: ;
                    case 0u: ;
                } while (i2++ < 5u && (0xf1bd5043u & 0x80000000u));
                if ((unsigned)(w0 >> 29)) {
                    d0 = d0 * 0.5 + (double)((unsigned)!(0x80000000u - g1) & 1023u);
                    if (budget != 0u) { budget -= 1u; u0 = fn2((9u * u2), *q0, r0.x); }
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + ((((r0.y * 8u) << (g1 & 31u)) | (unsigned)b0) - v0);
                        case 4u: ;
                        break;
                        case 7u: ;
                        w0 = w0 * 6364136223846793005ull + 0x10000u;
                        if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)(u0 == *q0) - garr[i1 & 7u]), 0x7fffffffu, (0xffffffffu / ((i1 & 0xffffffffu) | 1u))); }
                    }
                    u3 = u3 * 0x9e3779b1u + ((unsigned)((short)(9u & a0[i0 & 3u]) > (signed char)(unsigned)(x0 >> 70)) >> ((unsigned)!((unsigned)c0 >> (0x7fffffffu & 31u)) & 31u));
                    break; (void)((((unsigned)s1 % (u3 | 1u)) + 1u));
                }
            }
            do { if (--fuel == 0u) goto done;
                break;
                if (budget != 0u) { budget -= 1u; u1 = fn1(((r0.x % ((unsigned)f0 | 1u)) >> (i0 & 31u)), -(unsigned)((int)i1 >= (int)(unsigned)(signed char)(unsigned)(p1 && (unsigned)(w0 >> 29))), 8u); }
                if ((i1 * ((unsigned)c0 / (u1 | 1u)))) continue;
                if ((unsigned)((int)-(*mp / (*mp | 1u)) >= (int)(unsigned)x0)) continue;
                break;
                *q0 += (unsigned)x0;
            } while (i1++ < 6u && (0x1fc5ce6cu | 6u));
            switch ((unsigned)((int)0x80000000u >= (int)((unsigned)h0 << ((unsigned)e0 & 31u))) & 7u) {
                if (0x24f8461fu) goto L0;
                g0 = ~(unsigned)(0xffffffffu || (unsigned)h1);
                continue; (void)((~(unsigned)((unsigned)l0 < r0.y) ^ (unsigned)x0));
            }
        }
        u3 = (0x3489c85fu / (~(0xffffffffu | 0xffffffffu) | 1u));
        if ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)garr[u2 & 7u])) goto done;
        do { if (--fuel == 0u) goto done;
            break;
            if ((unsigned)((int)(unsigned)((short)6u > (signed char)0u) < (int)0x80000000u)) goto L2;
            garr[(unsigned)(g1 < i1) & 7u] = 0x80000000u;
            *q0 += 5u;
            g0 = (unsigned)((unsigned)d0 || 0xfa5e0705u);
        } while (i0++ < 6u && *mp);
        u1 = (unsigned)(*mp && (unsigned)(signed char)(unsigned)(i2 < m0));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while (i0++ < 4u && (m0 ^ (5u / (0x7fffffffu | 1u)))) { if (--fuel == 0u) goto done;
        b0 = (unsigned)e0 != 0u;
        continue; (void)(garr[i1 & 7u]);
        break; (void)((p2 & p0));
        L0: if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(short)(unsigned)((unsigned)(garr[i1 & 7u] < m0) < 0x10000u)) goto L1;
            *q0 = i2;
            break; (void)(((unsigned)(unsigned char)(unsigned)(p2 == 0xcf80da8u) ^ 0x80000000u));
            s1 = (int)((unsigned)s1 + ((unsigned)((unsigned)(w0 >> 29) && i0) ^ (unsigned)(((unsigned)s1 ^ (unsigned)b0) < p1)));
            v0 = ((unsigned)(short)(unsigned)((int)(p2 | a0[i0 & 3u]) < (int)(unsigned)(unsigned char)(unsigned)((int)0x4e3bef7eu < (int)1u)) * (unsigned)(x0 >> 70));
            h1 = (unsigned short)(h1 + 0xa36812a1u);
        } while (i1++ < 2u && (5u / (*mp | 1u)));
        b0 = (0x80000000u / ((unsigned)((unsigned)h1 && (unsigned)w0) | 1u)) != 0u;
    }
    u2 = (unsigned)((int)(unsigned)h0 < (int)m0);
    w0 ^= (unsigned long long)(a0[i0 & 3u] - g1) << ((unsigned)d0 & 63u);
    if ((unsigned)(u3 || (unsigned)h0)) {
        w0 ^= (unsigned long long)(unsigned)((short)a0[u1 & 3u] > (signed char)u1) << (-(unsigned)((unsigned)s0 == 0u) & 63u);
        goto L2;
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)x0) continue;
        }
        garr[(unsigned)((int)0xffffffffu < (int)(unsigned)h1) & 7u] = (unsigned)((int)1u >= (int)(m0 >> (p0 & 31u)));
        if (0xdc1c2724u) goto L3;
    }
    do { if (--fuel == 0u) goto done;
        if (0x7fffffffu) {
            L1: if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((unsigned)((int)m0 >= (int)(unsigned)((int)((unsigned)s1 >> (u1 & 31u)) >= (int)(unsigned)(w0 >> 29))) & 1023u);
            i1 = (unsigned)(g0 || ((unsigned)((int)i0 < (int)(unsigned)c1) >> (r0.y & 31u))) & 15u;
            v0 = (unsigned)(x0 >> 70);
        }
        switch (8u & 7u) {
            if ((p0 + r0.y)) goto L3;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)fuel < (int)(unsigned)(i0 < *q0))) break;
                    if ((*mp - u2)) {
                        *q0 = ((unsigned)c0 % ((unsigned)w0 | 1u));
                        a0[a0[i0 & 3u] & 3u] = ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)*mp) % ((u3 ? (unsigned)s1 : (unsigned)h1) | 1u));
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)b0 && (unsigned)s0), (unsigned)(0x10000u && (unsigned)l0), i0); }
                        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(short)(unsigned)((fuel / (m0 | 1u)) || (unsigned)s1) < u0) & 1023u);
                        g1 += 0x79294147u;
                    }
                    case 0u: ;
                    if ((0xa38b609du + 0xfd6906acu)) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn2((5u >> (p1 & 31u)), i0, (unsigned)(short)(unsigned)((int)(unsigned)b0 < (int)(unsigned)(x0 >> 70))); }
                    garr[*q0 & 7u] = r0.y;
                }
                u3 += u3;
                r0.x = (0xbd41029du % (0x80000000u | 1u));
                switch (u1 & 7u) {
                    g1 += u0;
                }
                if (((unsigned)b0 + (unsigned)b0)) {
                    x0 = x0 * 0x100000001b3ull + (g0 / (v0 | 1u));
                    u0 = u0 * 0x9e3779b1u + (1u & ((unsigned)(w0 >> 29) ^ a0[i0 & 3u]));
                    w0 ^= (unsigned long long)g0 << (0x80000000u & 63u);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn3((m0 ? (unsigned)(x0 >> 70) : p0), i0, (2u - 0x5994eca8u)); }
            }
            do { if (--fuel == 0u) goto done;
                case 5u: ;
                s0 = (int)(p1 % ((unsigned)c1 | 1u));
                if (~(unsigned)((int)0xedb28c85u < (int)a0[i0 & 3u])) break;
            } while (i1++ < 4u && (unsigned)(x0 >> 70));
            if (2u) break;
            v0 = (3u << ((unsigned)!(((0x7fffffffu % (i0 | 1u)) << (0x7fffffffu & 31u)) % (0xcb4849e2u | 1u)) & 31u));
            s1 = (int)((unsigned)s1 + (unsigned)!(v0 & 3u));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)c1 ^ p2), (0xffffffffu | (unsigned)s1), (p1 + 0x6bad351bu)); }
        if (((unsigned)(x0 >> 70) * (unsigned)(signed char)(fuel + (unsigned)c1))) {
            if ((unsigned)((short)(unsigned)e0 > (signed char)4u)) break;
            switch (-((unsigned)(w0 >> 29) >> ((unsigned)((unsigned)(w0 >> 29) == garr[i1 & 7u]) & 31u)) & 7u) {
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(0x10000u || (m0 ^ u2)), (-(2u | (unsigned)f0) % (g1 | 1u)), (i1 | (unsigned)(x0 >> 70))); }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(0xfb9c61fu, ((2u / ((unsigned)s0 | 1u)) * 0x80000000u), -(0x7fffffffu * ~(unsigned)((int)(unsigned)l0 < (int)(unsigned)e0))); }
                    r0.x = (unsigned)(x0 >> 70);
                    x0 = x0 * 0x100000001b3ull + (unsigned)!((0x80000000u + u3) & a0[i0 & 3u]);
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1(p0, -(unsigned)((int)(unsigned)((short)garr[i1 & 7u] > (signed char)0x7fffffffu) < (int)fuel), 0xbe7ea82bu); }
            }
            if ((unsigned)((short)1u > (signed char)u3)) goto L0;
            if (budget != 0u) { budget -= 1u; u3 = fn3((u0 >> ((unsigned)e0 & 31u)), (unsigned)!((unsigned)(g0 || (unsigned)(x0 >> 70)) % (0xffffffffu | 1u)), (unsigned)((int)(m0 - 0x80000000u) < (int)g1)); }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                garr[((unsigned)(w0 >> 29) ^ garr[i1 & 7u]) & 7u] = (p2 & (unsigned)c1);
                if ((*q0 / ((unsigned)d0 | 1u))) break;
                continue; (void)((unsigned)(unsigned char)(unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)!(i2 >> (*mp & 31u))));
            }
            if ((a0[u1 & 3u] & g0)) {
                g1 += (i1 << (((8u << (0xffffffffu & 31u)) >> ((*mp - garr[u2 & 7u]) & 31u)) & 31u));
                do { if (--fuel == 0u) goto done;
                    g1 += ~(unsigned)((0x1726223cu ^ i0) < 0x7fffffffu);
                    h0 = (short)((unsigned)((short)g1 > (signed char)a0[i0 & 3u]) >> ((unsigned)(u1 && (unsigned)w0) & 31u));
                } while (i1++ < 7u && (unsigned)(r0.y == (unsigned)(9u == (unsigned)x0)));
                break; (void)((unsigned)((short)(unsigned)!(r0.x * 0x3451ae86u) > (signed char)(unsigned)d0));
            }
        }
        s0 = (int)(unsigned)x0;
        while ((unsigned)(*mp && 6u)) { if (--fuel == 0u) goto done;
            q0 = &garr[-(u0 - 0x575e18dcu) & 7u];
            break; (void)((unsigned)((int)(i1 % ((unsigned)f0 | 1u)) < (int)garr[i1 & 7u]));
            { unsigned t0; double z0; if (((i1 & (unsigned)(w0 >> 29))) & 1u) { t0 = -(i0 % ((v0 % (i2 | 1u)) | 1u)); z0 = (double)(((unsigned)w0) & 255u); } if (((i1 & (unsigned)(w0 >> 29))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)(signed char)(unsigned)((int)0xf0655cdeu < (int)(a0[i0 & 3u] ^ u2)), (0x8e84b36bu ? 1u : i2), (unsigned)((int)p1 < (int)garr[u2 & 7u])); }
                break; (void)((m0 ^ i2));
                if (budget != 0u) { budget -= 1u; u3 = fn3(((m0 % (i2 | 1u)) / ((unsigned)(w0 >> 29) | 1u)), a0[i0 & 3u], (unsigned)(short)(unsigned)((unsigned)(0xc0dd21b9u || u1) || (unsigned)w0)); }
            }
            c1 = (signed char)(unsigned)!(0x5695de95u - (0x91c0c50cu ? (unsigned)l0 : 7u));
            l0 = (long)((unsigned long)l0 + r0.y);
        }
    } while (i0++ < 4u && (r0.y >> ((fuel & (unsigned)s1) & 31u)));
    *q0 = ((unsigned)h0 * ((i2 & garr[i1 & 7u]) >> ((unsigned)((int)a0[i0 & 3u] < (int)garr[i1 & 7u]) & 31u)));
    u2 = (u1 ^ garr[i1 & 7u]);
    { unsigned t1; double z1; if (((g1 + (unsigned)((int)(unsigned)s1 >= (int)7u))) & 1u) { t1 = 0x10000u; z1 = (double)((v0) & 255u); } if (((g1 + (unsigned)((int)(unsigned)s1 >= (int)7u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        if (fuel < 8u) return (8u - ((unsigned)s0 % ((unsigned)((int)~(unsigned)((int)r0.y >= (int)(unsigned)(w0 >> 29)) < (int)m0) | 1u)));
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((unsigned)e0 && (p0 / ((unsigned)(w0 >> 29) | 1u))), 0x80000000u, p0); }
        if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)x0, (unsigned)s1, (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0x382d397au)); }
        r0.y ^= -((r0.x << (*mp & 31u)) * (unsigned)(garr[i1 & 7u] && r0.y));
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)(unsigned)!(unsigned)(u0 && 8u);
            i0 = (unsigned)((int)((unsigned)s0 & u2) < (int)p1) & 15u;
        }
    }
    s1 = (int)((unsigned)s1 + ((unsigned)h0 << (((p2 << ((unsigned)w0 & 31u)) ^ 0xffffffffu) & 31u)));
    u0 = ((unsigned)(i0 < (unsigned)l0) / ((unsigned)(signed char)((unsigned)w0 * (unsigned)(x0 >> 70)) | 1u));
    L2: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)f0, (unsigned)((short)-(0x80000000u % (m0 | 1u)) > (signed char)0x10000u), (unsigned)w0); }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((0x7fffffffu | ((unsigned)s1 >> ((unsigned)f0 & 31u)))) continue;
        h1 = (unsigned short)(h1 + 0x10000u);
        if (u3 == 7u) return ((unsigned)((int)u3 < (int)(unsigned)c1) * (garr[u2 & 7u] | g0));
    }
    i0 = (unsigned)((unsigned)c1 == (unsigned)((0x10000u ? 0x80000000u : (unsigned)(w0 >> 29)) == 0x80000000u)) & 15u;
    h0 = (short)a0[u1 & 3u];
    if (((0x4253b84fu << (0xffffffffu & 31u)) - 0xb058e563u)) goto L2;
    q0 = &garr[((unsigned)(signed char)(unsigned)((short)u2 > (signed char)(r0.x - p2)) * r0.x) & 7u];
    g0 = (unsigned)((0xaf751ecfu + ((unsigned)w0 * 0x7fffffffu)) == (unsigned)(garr[u2 & 7u] == 0xadd18936u));
    if ((unsigned)(unsigned char)(((unsigned)(w0 >> 29) - u1) >> (*q0 & 31u))) goto L3;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        L3: if (--fuel == 0u) goto done;
        break; (void)((unsigned)(w0 >> 29));
        L4: if (--fuel == 0u) goto done;
        *mp = (7u ? (unsigned)((int)0x10000u >= (int)((unsigned)h0 + (unsigned)x0)) : 5u);
    }
    h0 = (short)i0;
    if ((0xf6826a54u * (unsigned)c1)) {
        c0 = (unsigned char)(unsigned)(((unsigned)x0 ^ 0xffffffffu) == garr[u2 & 7u]);
        m0 ^= i1;
        if ((unsigned)(short)((unsigned)s1 * ~(unsigned)((unsigned)(x0 >> 70) == 0x10000u))) goto done;
        v0 = (unsigned)(u3 || i2);
        if ((unsigned)!((unsigned)x0 % ((unsigned)((int)0x80000000u < (int)(unsigned)s0) | 1u))) goto done;
        if (((unsigned)f0 & (unsigned)((short)u1 > (signed char)0xd3d90afu))) goto L1;
    }
    r0.y ^= p2;
    { unsigned t2; double z2; if ((garr[i1 & 7u]) & 1u) { t2 = (p1 - (0u * 0x10000u)); z2 = (double)((((unsigned)f0 << (p2 & 31u))) & 255u); } if ((garr[i1 & 7u]) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        if (u0) goto L2;
        u1 ^= (((unsigned)e0 >> (g1 & 31u)) ^ ((unsigned)(w0 >> 29) ^ *q0));
    }
    { unsigned t3; double z3; if ((p0) & 1u) { t3 = (unsigned)e0; z3 = (double)((((unsigned)(0xffffffffu || garr[u2 & 7u]) + 0x10000u)) & 255u); } if ((p0) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        if ((unsigned)(x0 >> 70)) goto L0;
    }
    { unsigned t4; double z4; if (((unsigned)((i2 - (unsigned)c1) == a0[i0 & 3u])) & 1u) { t4 = (unsigned)(0xe5f9695fu && (unsigned)s0); z4 = (double)(((unsigned)(short)(unsigned)(fuel && 0x62152a35u)) & 255u); } if (((unsigned)((i2 - (unsigned)c1) == a0[i0 & 3u])) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
        d0 = d0 * 0.5 + (double)((unsigned)!(unsigned)((unsigned)((int)0x10000u < (int)u1) < ((3u % (9u | 1u)) & garr[i1 & 7u])) & 1023u);
        goto L3;
    }
    { unsigned t5; double z5; if ((((unsigned)s1 * g1)) & 1u) { t5 = u0; z5 = (double)((p1) & 255u); } if ((((unsigned)s1 * g1)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        while (i0++ < 3u && ((r0.x / (i0 | 1u)) & (unsigned)w0)) { if (--fuel == 0u) goto done;
            switch ((0x3c0fb265u * u3) & 7u) {
                i2 = (unsigned)(unsigned char)((unsigned)(short)(unsigned)((short)(unsigned)((int)(unsigned)c0 >= (int)0x17e5e28u) > (signed char)0x10000u) / (garr[u2 & 7u] | 1u)) & 15u;
            }
            continue; (void)((unsigned)w0);
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)s1, 2u, ~(unsigned)(0x80000000u || 2u)); }
        }
        m0 ^= ((unsigned)(short)((fuel << (-(unsigned)(0u < 0xffffffffu) & 31u)) << (g1 & 31u)) - u2);
        i0 = (unsigned)((int)0xd97a01ecu < (int)((unsigned)(u2 < garr[i1 & 7u]) | (unsigned)s1)) & 15u;
        if ((((unsigned)s1 | u0) - 0x72083c39u)) goto L2;
        s0 = (int)0xffffffffu;
        goto L1;
    }
    r0.x = (unsigned)(((unsigned)b0 * 0x7fffffffu) == 0x3361fa55u);
    r0.x = (((unsigned)s1 >> (((unsigned)c1 + (unsigned)h0) & 31u)) % (6u | 1u));
    l0 = (long)((unsigned long)l0 + (((unsigned)(x0 >> 70) ? i0 : 0x89d8cd03u) % ((unsigned)l0 | 1u)));
    h1 = (unsigned short)(h1 + (g1 % ((unsigned)(w0 >> 29) | 1u)));
    for (;;) { if (--fuel == 0u) goto done;
        u1 ^= r0.y;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (g0) continue;
            switch (0x5a56746bu & 7u) {
                case 1u: ;
                if (budget != 0u) { budget -= 1u; u2 = fn0(-(unsigned)(i1 == i1), ((unsigned)(0x962863b1u == 0x7fffffffu) << (i1 & 31u)), garr[u2 & 7u]); }
            }
            v0 = (unsigned)((unsigned)((unsigned)l0 < (unsigned)b0) < i1);
        }
        s0 = (int)(((unsigned)l0 * (0u / (a0[i0 & 3u] | 1u))) >> (g1 & 31u));
        u0 = u0 * 0x9e3779b1u + (unsigned)(unsigned char)(unsigned)((p0 << ((unsigned)e0 & 31u)) < a0[i0 & 3u]);
    }
    if ((unsigned)((0xdf93ddu & 0x10000u) == 7u)) {
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)b0, 0x7fffffffu, ((unsigned)(w0 >> 29) ^ (unsigned)(w0 >> 29))); }
        if ((unsigned)w0) {
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0(((garr[u2 & 7u] + a0[i0 & 3u]) * 2u), (i1 * a0[u1 & 3u]), (unsigned)(x0 >> 70)); }
                u1 += (r0.x << (((v0 & 0x80000000u) * (unsigned)!(unsigned)((int)(unsigned)w0 < (int)garr[u2 & 7u])) & 31u));
                goto L4;
                h1 = (unsigned short)(h1 + -(unsigned)((unsigned)((int)0xff82e705u < (int)(u2 / (u3 | 1u))) || 0x993e6e5eu));
                if (budget != 0u) { budget -= 1u; u0 = fn0((a0[i0 & 3u] ^ ((unsigned)s1 / (u0 | 1u))), u0, (unsigned)((unsigned)c1 && fuel)); }
            } while (i0++ < 6u && (unsigned)((r0.x / (p0 | 1u)) == u2));
            if ((unsigned)(r0.x || (unsigned)(i0 || fuel))) goto L4;
        } else {
            s1 = (int)((unsigned)s1 + (i0 << ((i0 ? (unsigned)((int)a0[u1 & 3u] >= (int)0u) : (unsigned)d0) & 31u)));
            if (budget != 0u) { budget -= 1u; u1 = fn2((2u ^ (unsigned)s0), (unsigned)((unsigned)!(unsigned)(p2 == *mp) || 0x7fffffffu), (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)(0x4fd33a37u || 0xffffffffu))); }
            if ((unsigned)((short)p2 > (signed char)(unsigned)(r0.x || (unsigned)f0))) goto L0;
            { unsigned t6; double z6; if (((unsigned)(x0 >> 70)) & 1u) { t6 = p2; z6 = (double)(((unsigned)(0x80000000u < 0x7fffffffu)) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(unsigned)((int)((1u >> (4u & 31u)) % ((r0.y * i1) | 1u)) >= (int)0x10000u) & 1023u);
                if (u3 == 7u) return ((unsigned)(w0 >> 29) + (unsigned)b0);
                switch ((1u | ((unsigned)(w0 >> 29) / ((unsigned)l0 | 1u))) & 7u) {
                    case 5u: ;
                    if (g1) goto L1;
                    b0 = (((0xffffffffu + 0x413a938fu) % (p0 | 1u)) & (unsigned)w0) != 0u;
                    case 7u: ;
                    case 3u: ;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)b0, 0x80000000u, 0x5d9dace6u); }
                if ((0xec1edd7au + 4u)) goto L3;
                if ((*q0 | ((unsigned)d0 << (u1 & 31u)))) goto L3;
            }
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 0u, 0x31c260dfu, 0x7e740dd6u },
        { 5u, 0x4711dcb9u, 0x553fdcebu },
        { 10u, 0x7492b02du, 0xae5243bbu },
        { 13u, 0x4a871e22u, 0xf3101ac8u },
        { 7u, 0x96f23e0du, 0xf538f56cu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
