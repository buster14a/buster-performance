// test-ssa-source's program of seed 134000415 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x1ae08b34u, g1 = 0x98d3cd68u;
static unsigned garr[8] = { 0x65f52ea8u, 0xb45c9261u, 0xaa74b486u, 0x600e1b50u, 0x34c0169eu, 0x2ab29173u, 0x7581a7a8u, 0xb76e651du };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    f0 = f0 * 0.5f + (float)((unsigned)(fuel && (0xb3345e3u ^ (unsigned)x0)) & 255u);
    if ((unsigned)(short)(unsigned)((unsigned)h0 && g1)) {
        if ((unsigned)(0x7fffffffu && ((unsigned)c0 - u3))) goto done;
        d0 = d0 * 0.5 + (double)(8u & 1023u);
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)u2;
            garr[u1 & 7u] = (unsigned)((unsigned)((unsigned)((int)v0 >= (int)(unsigned)((int)5u >= (int)(unsigned)c1)) < (unsigned)h0) == (unsigned)d0);
            if (((unsigned)x0 * (p2 >> (2u & 31u)))) {
                w0 ^= (unsigned long long)0x7fffffffu << (i2 & 63u);
            }
            if (((unsigned)(x0 >> 70) / ((unsigned)((int)0x7fffffffu >= (int)u3) | 1u))) break;
            if (r0.x) {
                w0 ^= (unsigned long long)(unsigned)!(8u ^ (unsigned)f0) << ((unsigned)((unsigned)c1 && ((0xc4802779u ? (unsigned)c1 : i1) ^ (unsigned)h1)) & 63u);
            } else {
                h0 = (short)m0;
            }
            { unsigned t0; double z0; if ((6u) & 1u) { t0 = (u3 % ((0xdd789f27u % (2u | 1u)) | 1u)); z0 = (double)(((unsigned)(short)((unsigned)x0 % (7u | 1u))) & 255u); } if ((6u) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                if (fuel < 8u) return (unsigned)((*mp + (unsigned)d0) < ~(r0.x / (((unsigned)(w0 >> 29) >> (4u & 31u)) | 1u)));
                if (0x7fffffffu) break;
            }
        }
        b0 = -(~((unsigned)h0 % (p0 | 1u)) ^ u1) != 0u;
        l0 = (long)((unsigned long)l0 + (unsigned)s1);
        while (i0++ < 7u && (2u ^ 0xc21369e0u)) { if (--fuel == 0u) goto done;
            if (0x86ab0942u) continue;
            *mp = (unsigned)((short)(unsigned)d0 > (signed char)(unsigned)((short)0xffffffffu > (signed char)(unsigned)(i1 && 8u)));
            v0 = (unsigned)e0;
        }
    }
    goto done;
    a0[0x10000u & 3u] = 0xe0572ba5u;
    if (3u) goto L3;
    b0 = ((unsigned)d0 % (6u | 1u)) != 0u;
    { unsigned t1; double z1; if ((((unsigned)l0 ^ (2u | (unsigned)c0))) & 1u) { t1 = ((p2 & (unsigned)c1) * p0); z1 = (double)((0x80000000u) & 255u); } if ((((unsigned)l0 ^ (2u | (unsigned)c0))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        u1 = (unsigned)((unsigned)(fuel < (unsigned)b0) == 0xffffffffu);
        garr[3u & 7u] = ((unsigned)((short)(unsigned)l0 > (signed char)((unsigned)s0 >> (0x575a2619u & 31u))) / (v0 | 1u));
    }
    if ((unsigned)!(0x80000000u / ((unsigned)b0 | 1u))) {
        if ((0xffffffffu & (unsigned)c0)) goto L4;
        h1 = (unsigned short)(h1 + 0xdb97ef9au);
    }
    { unsigned t2; double z2; if (((unsigned)(signed char)(2u - garr[i1 & 7u])) & 1u) { t2 = ((unsigned)l0 / (7u | 1u)); z2 = (double)(((unsigned)(((unsigned)c0 | 0x80000000u) && i2)) & 255u); } if (((unsigned)(signed char)(2u - garr[i1 & 7u])) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        goto L2;
    }
    if ((unsigned)l0) goto done;
    s1 = (int)((unsigned)s1 + (unsigned)((0x7fffffffu / (i1 | 1u)) || (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)l0)));
    d0 = d0 * 0.5 + (double)(~((m0 / ((unsigned)((int)i0 >= (int)8u) | 1u)) * 0x6652063au) & 1023u);
    L0: if (--fuel == 0u) goto done;
    garr[fuel & 7u] = (unsigned)w0;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + -(unsigned)((int)a0[i0 & 3u] >= (int)7u);
    }
    if ((unsigned)x0) {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((0x10000u << (0x6f5a223cu & 31u))) goto L0;
            L2: if (--fuel == 0u) goto done;
            if ((unsigned)((int)fuel >= (int)(8u << (0x6fd24154u & 31u)))) break;
            if ((unsigned)(w0 >> 29)) break;
            { unsigned t3; double z3; if (((r0.x & u2)) & 1u) { t3 = (0xffffffffu * ((unsigned)c0 + (unsigned)c0)); z3 = (double)((((unsigned)(unsigned char)(r0.y % (i2 | 1u)) << (u1 & 31u))) & 255u); } if (((r0.x & u2)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                switch (0x10000u & 7u) {
                    if ((unsigned)((unsigned)w0 < 0x80000000u)) {
                        L3: if (--fuel == 0u) goto done;
                        c1 = (signed char)(unsigned)(p0 == (unsigned)c0);
                        if (u3 == 7u) return ((unsigned)w0 & (unsigned)((short)(i1 - (unsigned)(0x80000000u == u2)) > (signed char)(unsigned)w0));
                        case 6u: ;
                        L4: if (--fuel == 0u) goto done;
                        if (garr[u2 & 7u]) continue;
                    }
                    if (((unsigned)((int)*q0 < (int)(unsigned)h1) + (unsigned)c0)) goto L0;
                }
                switch ((0x7fffffffu - (unsigned)((unsigned)w0 && (unsigned)s1)) & 7u) {
                    case 1u: ;
                    while (i1++ < 3u && (i0 * (unsigned)((short)0x10000u > (signed char)(unsigned)f0))) { if (--fuel == 0u) goto done;
                        r0.y ^= ((unsigned)(signed char)(0x81a5e0c3u ? garr[u2 & 7u] : fuel) & ((unsigned)f0 % (*q0 | 1u)));
                        if (0x80000000u) goto L4;
                        if (1u) continue;
                        u1 ^= (unsigned)(signed char)(unsigned)(0x10000u && 0x10000u);
                    }
                    case 3u: ;
                }
                i0 = (fuel << (m0 & 31u)) & 15u;
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (0xffffffffu) break;
                    h0 = (short)(unsigned)(signed char)((unsigned)b0 >> (3u & 31u));
                    r0.x = ((unsigned)((short)0u > (signed char)(unsigned)h0) / ((unsigned)((unsigned)s0 && a0[u1 & 3u]) | 1u));
                }
                if (((unsigned)((unsigned)l0 == 0x7fffffffu) % ((unsigned)h0 | 1u))) goto L2;
            }
            w0 ^= (unsigned long long)(unsigned)e0 << (garr[u2 & 7u] & 63u);
        }
        goto L1;
        if ((unsigned)((short)fuel > (signed char)(a0[i0 & 3u] % (m0 | 1u)))) goto L3;
        goto L3;
        { unsigned t4; double z4; if (((unsigned)w0) & 1u) { t4 = (i0 >> ((0x10000u & 0x255bf969u) & 31u)); z4 = (double)(((unsigned)h1) & 255u); } if (((unsigned)w0) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
            if ((unsigned)((unsigned)h0 || (a0[u1 & 3u] + p1))) goto done;
            while (i0++ < 3u && (unsigned)((int)u1 >= (int)0xafe55ef1u)) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)u1)) break;
                do { if (--fuel == 0u) goto done;
                    if (4u) {
                        u2 += ((unsigned)(7u < (unsigned)(i1 && 0x80000000u)) >> ((g1 << (0xaca9cf81u & 31u)) & 31u));
                        break; (void)((unsigned)h1);
                        c0 = (unsigned char)(u0 - (i1 % ((((unsigned)(w0 >> 29) + 0x25dd806u) % (g1 | 1u)) | 1u)));
                        if (0xb32e3f8u) break;
                    } else {
                        if ((unsigned)(i1 < u0)) break;
                        *mp = (unsigned)e0;
                    }
                    if ((p2 * (unsigned)!(1u & r0.x))) break;
                    w0 = w0 * 6364136223846793005ull + ((unsigned)l0 & (unsigned)f0);
                    do { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + g0);
                        if (u3 == 7u) return ((p2 ? (unsigned)(w0 >> 29) : 0x7fffffffu) | (0xe5e3f5efu | *mp));
                        if ((unsigned)((int)(unsigned)((unsigned)h0 == 0xbc2cc4du) >= (int)i0)) break;
                        u3 ^= ((unsigned)h0 & u2);
                        if (~(0xffffffffu | (unsigned)((short)u3 > (signed char)a0[u1 & 3u]))) continue;
                        r0.y ^= (unsigned)(w0 >> 29);
                    } while (i2++ < 7u && 8u);
                    if ((unsigned)w0) break;
                    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(p1 / (((unsigned)s0 << (((p1 & (unsigned)s1) ^ u3) & 31u)) | 1u)) & 1023u);
                } while (i1++ < 6u && (unsigned)(0x10000u || (m0 | v0)));
                g0 = 0x10000u;
                *q0 = (unsigned)h0;
                r0.x = (unsigned)((short)i2 > (signed char)garr[u2 & 7u]);
            }
            g0 = (unsigned)(u3 && p2);
            if ((unsigned)!((unsigned)((int)p2 < (int)0x7c01937u) + 0xc9774038u)) {
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (garr[i1 & 7u] << ((unsigned)(short)(*mp << ((*mp / (u0 | 1u)) & 31u)) & 31u));
                    r0.y ^= (fuel - u1);
                    switch ((((unsigned)d0 * (unsigned)(x0 >> 70)) + 0x5f8f7e89u) & 7u) {
                        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                            r0.x = p1;
                        }
                    }
                    for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)(w0 >> 29)) break;
                        if ((unsigned)(short)(unsigned)(5u < a0[u1 & 3u])) goto L1;
                        if ((m0 ^ 0x7700a6bdu)) continue;
                        u0 += ((unsigned)(unsigned char)(unsigned)((unsigned)l0 || (unsigned)l0) / ((unsigned)(x0 >> 70) | 1u));
                        u3 += (unsigned)(unsigned char)((0xbbc9b77fu | 7u) - ((unsigned)(signed char)(unsigned)((int)4u >= (int)a0[i0 & 3u]) ^ m0));
                        break; (void)(i0);
                    }
                }
            } else {
                if ((i0 << ((unsigned)(garr[u2 & 7u] && r0.x) & 31u))) {
                    u1 ^= ((r0.x - (r0.y >> (0x10000u & 31u))) % ((unsigned)c1 | 1u));
                    if (u0) goto L1;
                    goto done;
                    s1 = (int)((unsigned)s1 + (unsigned)!((unsigned)s1 ^ (0x80000000u % (0x72632f0du | 1u))));
                }
            }
            u1 = (4u ? garr[i1 & 7u] : r0.x);
            if ((p0 * (a0[i0 & 3u] ^ u1))) goto done;
        }
    } else {
        goto L1;
        if (((unsigned)(x0 >> 70) % (u3 | 1u))) {
            if ((unsigned)(p1 || ((unsigned)x0 | (unsigned)c0))) {
                garr[i0 & 7u] = (r0.x % ((unsigned)s0 | 1u));
                { unsigned t5; double z5; if (((i0 | (unsigned)(x0 >> 70))) & 1u) { t5 = (unsigned)d0; z5 = (double)(((unsigned)(garr[i1 & 7u] || 0xffffffffu)) & 255u); } if (((i0 | (unsigned)(x0 >> 70))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                    x0 = x0 * 0x100000001b3ull + (0u * 0x7fffffffu);
                    g0 = (unsigned)(((0xffffffffu | (r0.x ^ p1)) << (a0[i0 & 3u] & 31u)) || u0);
                    i0 = ((unsigned)(0x99ad8b53u && 0x7fffffffu) - (0x63e79471u & ((unsigned)x0 | p1))) & 15u;
                    goto L1;
                }
                r0.y ^= (~((unsigned)s0 % (1u | 1u)) >> ((0x80000000u >> (u0 & 31u)) & 31u));
                if (((0xffffffffu * v0) / (u3 | 1u))) goto L0;
            } else {
                goto L0;
                if (0xcaa36febu) goto L0;
            }
            if (((unsigned)(g1 < (unsigned)c0) * (unsigned)s1)) goto L0;
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                *q0 = ((unsigned)(m0 && (unsigned)(a0[u1 & 3u] || 0x80000000u)) & (unsigned)c0);
                if (-(unsigned)(0x2fb31f84u && p2)) continue;
                while (i1++ < 6u && fuel) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)0x7fffffffu < (int)(unsigned)x0)) break;
                    x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)(((unsigned)c0 ? (unsigned)c1 : a0[u1 & 3u]) == u0) == (unsigned)h0);
                }
                if ((((unsigned)(x0 >> 70) + r0.y) * 1u)) break;
            }
        }
        if ((7u | (m0 << ((unsigned)s1 & 31u)))) goto L3;
        *q0 = m0;
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)d0 ? *q0 : a0[i0 & 3u]));
        if (a0[i0 & 3u]) continue;
    }
    do { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)(((unsigned)d0 / ((u1 & 0u) | 1u)) == (unsigned)(0x2e277286u == 0x80000000u)));
        if (fuel < 8u) return (unsigned)h1;
    } while (i0++ < 2u && (p1 ^ (unsigned)d0));
    goto L3;
    goto L3;
    if (((unsigned)((int)(unsigned)s0 < (int)g1) | (unsigned)x0)) goto L1;
    m0 ^= (((unsigned)w0 * (unsigned)l0) ^ (r0.x | (g1 >> (0x7fffffffu & 31u))));
    if ((unsigned)((short)0x55712ccu > (signed char)(p2 | fuel))) goto L0;
    g1 += ((unsigned)w0 & (unsigned)((short)a0[i0 & 3u] > (signed char)u1));
    goto L1;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 6u && (unsigned)(u0 && (unsigned)s0)) { if (--fuel == 0u) goto done;
            if ((v0 ? 1u : u0)) goto L4;
            break; (void)((unsigned)((unsigned)h1 < u2));
            if ((unsigned)((int)r0.x >= (int)7u)) {
                a0[(i0 | u3) & 3u] = (unsigned)e0;
                s0 = (int)(((unsigned)w0 - (unsigned)s1) >> (0x10000u & 31u));
            }
            q0 = &garr[(0x10000u ^ ((unsigned)s1 ? i0 : v0)) & 7u];
            l0 = (long)((unsigned long)l0 + (unsigned)f0);
            u0 = (unsigned)(short)(unsigned)((unsigned)(*q0 || 0xffffffffu) && (0xe8f6ee3eu | (unsigned)s0));
        }
    }
    i0 = ~(unsigned)((short)-(unsigned)((unsigned)(7u || (unsigned)b0) < p2) > (signed char)i0) & 15u;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 += (unsigned)((short)(unsigned)(unsigned char)(garr[i1 & 7u] ^ m0) > (signed char)((a0[i0 & 3u] ^ (unsigned)f0) & (unsigned)b0));
        if (((unsigned)((int)0x19b43b6du >= (int)m0) - garr[i1 & 7u])) break;
        g0 = ((unsigned)b0 / ((unsigned)(p2 < (unsigned)(0xec441be2u < *q0)) | 1u));
        break; (void)((garr[u2 & 7u] ^ g1));
    }
    goto L2;
    b0 = (unsigned)(((i0 * garr[u2 & 7u]) >> (*q0 & 31u)) && a0[i0 & 3u]) != 0u;
    if ((unsigned)(0x10000u == i1)) {
        while (((unsigned)s1 | i0)) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + (0x3141a2e4u + ((m0 ^ *q0) ^ i1)));
            if ((1u / (0x5ad340a1u | 1u))) break;
        }
    }
    if ((unsigned)w0) {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)fuel < (int)0xffffffffu)) break;
            d0 = d0 * 0.5 + (double)((((unsigned)b0 / (0xc05fd74au | 1u)) << (r0.y & 31u)) & 1023u);
            u2 += ((unsigned)!(6u & r0.x) << (i2 & 31u));
        }
        c0 = (unsigned char)(p0 ? (0u ^ (unsigned)(x0 >> 70)) : 0x80000000u);
        while (i0++ < 6u && (p1 / ((unsigned)s1 | 1u))) { if (--fuel == 0u) goto done;
            if ((r0.y % ((unsigned)(fuel == (unsigned)x0) | 1u))) goto L4;
        }
        goto L3;
        f0 = f0 * 0.5f + (float)((((unsigned)((int)0x80000000u < (int)(unsigned)e0) * g0) / ((unsigned)(fuel || m0) | 1u)) & 255u);
        if ((i0 * 0xffffffffu)) goto L2;
    } else {
        u2 = u1;
        if (u3 == 7u) return (0x80000000u + (garr[u2 & 7u] ? 0x95159cc6u : p0));
        c0 = (unsigned char)(a0[i0 & 3u] % (1u | 1u));
        if (((unsigned)((int)(unsigned)l0 < (int)(unsigned)e0) - (unsigned)c1)) {
            u2 += ((unsigned)(6u < (unsigned)(w0 >> 29)) * fuel);
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    s0 = (int)(((unsigned)h0 + (unsigned)h0) * ((unsigned)s1 << ((unsigned)c0 & 31u)));
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)!(unsigned)(g0 && 0x7fffffffu) < (unsigned)(w0 >> 29)), (unsigned)(0x414b158au == i2), (garr[u2 & 7u] - g1)); }
    L0: if (--fuel == 0u) goto done;
    L1: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)(unsigned)(0x10000u && (garr[i1 & 7u] % (0x80000000u | 1u))), 0x4c4f2d99u, ((u2 ^ (unsigned)c1) << ((unsigned)(x0 >> 70) & 31u))); }
    a0[(unsigned)(i2 || a0[u1 & 3u]) & 3u] = (unsigned)((short)(unsigned)f0 > (signed char)(0x10000u + 0x15dfe677u));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = (unsigned)((unsigned)c1 && (unsigned)((unsigned)h0 && (unsigned)(w0 >> 29)));
        if (garr[u2 & 7u]) {
            s1 = (int)((unsigned)s1 + ((unsigned)b0 * (unsigned)(garr[u2 & 7u] || r0.x)));
        } else {
            *mp = (-(unsigned)((short)(unsigned)((short)0x80000000u > (signed char)a0[u1 & 3u]) > (signed char)(unsigned)x0) * 0x80000000u);
            switch (r0.x & 7u) {
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(m0 + (unsigned)s1) > (signed char)garr[u2 & 7u]), u0, p0); }
                case 4u: ;
            }
            break; (void)(0xffffffffu);
            h1 = (unsigned short)(h1 + (unsigned)(signed char)(i1 - (r0.y % ((8u * (u0 << (1u & 31u))) | 1u))));
        }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)s0, (unsigned)(short)(unsigned)((unsigned)b0 && i0), (garr[u2 & 7u] ^ (0x825800dcu & 0xffffffffu))); }
    L2: if (--fuel == 0u) goto done;
    switch (((unsigned)l0 << ((0xa87bdaf8u + i2) & 31u)) & 7u) {
        if ((unsigned)(3u || u3)) {
            do { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)(short)(9u + (unsigned)((int)u1 >= (int)a0[u1 & 3u])) >= (int)a0[i0 & 3u]) & 1023u);
                u1 += (unsigned)((g1 >> (5u & 31u)) == (unsigned)(w0 >> 29));
                do { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + ((unsigned)!((0x80000000u + i1) | 0x80000000u) >> (i0 & 31u)));
                    v0 = (i1 ? (unsigned)(unsigned char)(unsigned)((int)3u < (int)u0) : 0x79ac3e7eu);
                } while (i1++ < 7u && (unsigned)f0);
                if (budget != 0u) { budget -= 1u; u2 = fn0(((0x595f04acu + p1) ^ (unsigned)h0), u0, (unsigned)(u2 == (unsigned)((int)g0 >= (int)0x10000u))); }
            } while (i0++ < 4u && u3);
            if ((garr[u2 & 7u] - g1)) break;
            q0 = &garr[(unsigned)b0 & 7u];
        }
        goto L3;
        u3 += (((unsigned)x0 & ((u0 >> (0u & 31u)) % (*mp | 1u))) | (unsigned)b0);
        break; (void)((unsigned)(-(i1 | v0) == (unsigned)d0));
        L3: if (--fuel == 0u) goto done;
        s0 = (int)((v0 / ((7u ? 0x5650be98u : p1) | 1u)) + i1);
    }
    goto L3;
    while (i0++ < 4u && (v0 - garr[i1 & 7u])) { if (--fuel == 0u) goto done;
        u3 ^= (unsigned)(0x59c91d94u < ((0xffffffffu | (unsigned)d0) ^ 0xfd9027b0u));
        r0.x = (unsigned)(5u || ((((unsigned)s0 + (unsigned)(w0 >> 29)) << (0x21238572u & 31u)) ^ 0xb974a1c5u));
        f0 = f0 * 0.5f + (float)(p2 & 255u);
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)f0 ^ p0)) break;
            L4: if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(v0 & 1023u);
        }
        while (i1++ < 6u && ((unsigned)!(0x7b31fcddu * (unsigned)(w0 >> 29)) - 2u)) { if (--fuel == 0u) goto done;
            if ((unsigned)s0) {
                do { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((a0[u1 & 3u] << ((unsigned)l0 & 31u)) & 255u);
                    u0 = ((unsigned)((int)(r0.x + garr[u2 & 7u]) >= (int)8u) | 0x56fb5905u);
                    if ((unsigned)((unsigned)h0 < ((unsigned)d0 + 0u))) {
                        if ((unsigned)((short)(unsigned)s0 > (signed char)0xffffffffu)) goto L1;
                        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                            if ((0x38f7661du - *mp)) break;
                        }
                        c0 = (unsigned char)p1;
                        if ((unsigned)(g0 < p1)) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(~(unsigned)(g1 || 6u), -(0x10000u % (0xffffffffu | 1u)), (0x7fffffffu | p1)); }
                    } else {
                        if ((unsigned)(short)((unsigned)l0 & (v0 + u3))) {
                            w0 ^= (unsigned long long)u0 << ((unsigned)((short)(unsigned)((short)(unsigned)e0 > (signed char)(unsigned)w0) > (signed char)(garr[u2 & 7u] ^ (0x80aca8ebu + v0))) & 63u);
                            if (u2) break;
                            if ((i0 * 0x10000u)) break;
                            q0 = &garr[-(unsigned)((int)(unsigned)f0 >= (int)1u) & 7u];
                            g0 = 0x577fccbcu;
                        } else {
                            s0 = (int)(unsigned)((int)p0 >= (int)(*q0 % ((unsigned)(((unsigned)s1 % (g0 | 1u)) && u1) | 1u)));
                            e0 = e0 * 0.5L + (long double)(0x70898c0cu & 1023u);
                        }
                        i0 = 8u & 15u;
                    }
                } while (i2++ < 7u && g1);
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(-(unsigned)((short)(unsigned)d0 > (signed char)garr[i1 & 7u]) == i2), p0, (unsigned)(short)(unsigned)(u1 || (unsigned)(u1 < (unsigned)x0))); }
                u3 = u3 * 0x9e3779b1u + (u2 + (unsigned)((unsigned)((int)(unsigned)b0 >= (int)g1) && garr[u2 & 7u]));
                h1 = (unsigned short)(h1 + ((unsigned)c1 * (unsigned)b0));
                if (garr[i1 & 7u]) break;
            }
            while (i2++ < 6u && (unsigned)(short)(2u % (((unsigned)e0 / (8u | 1u)) | 1u))) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)((unsigned)(0x4eae1839u < a0[i0 & 3u]) - (unsigned)((int)p2 >= (int)i1));
                break; (void)(((unsigned)x0 - g0));
                d0 = d0 * 0.5 + (double)(((unsigned)(w0 >> 29) - 0x80000000u) & 1023u);
            }
            garr[(unsigned)b0 & 7u] = 0xac2e3591u;
            u0 ^= (p0 >> ((unsigned)(short)(*q0 * (unsigned)s1) & 31u));
            if ((unsigned)((unsigned)h1 < u2)) break;
        }
        if ((unsigned)(short)(unsigned)((int)(unsigned)d0 < (int)u2)) break;
    }
    i2 = i0 & 15u;
    i0 = (unsigned)((int)(unsigned)w0 < (int)(unsigned)w0) & 15u;
    if (0x8c031885u) goto L2;
    l0 = (long)((unsigned long)l0 + 4u);
    switch (-(5u + (unsigned)f0) & 7u) {
        q0 = &garr[(0x10000u + 0xd39db030u) & 7u];
        break; (void)((unsigned)!((unsigned)(3u || fuel) ^ (unsigned)c1));
        switch (((unsigned)d0 / (0xffffffffu | 1u)) & 7u) {
            if (garr[i1 & 7u]) break;
        }
        if (fuel < 8u) return ((unsigned)((unsigned)w0 == 0xd9003b31u) + 0xfab3baf9u);
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        c1 = (signed char)((fuel % (r0.x | 1u)) - (unsigned)b0);
        u3 = u3 * 0x9e3779b1u + (*q0 * (unsigned)b0);
    }
    if ((0xffffffffu << ((3u % (garr[i1 & 7u] | 1u)) & 31u))) goto L0;
    switch ((p2 ? (unsigned)c0 : 0x7fffffffu) & 7u) {
        if (budget != 0u) { budget -= 1u; u3 = fn0(4u, (unsigned)((int)2u >= (int)(unsigned)b0), (4u / ((unsigned)!(0x80000000u ^ u1) | 1u))); }
        w0 = w0 * 6364136223846793005ull + ((i0 & *q0) + ((unsigned)f0 / (~(unsigned)(8u == 0x10000u) | 1u)));
        if ((unsigned)(signed char)(fuel % ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)*mp) | 1u))) break;
        case 6u: ;
        switch ((unsigned)b0 & 7u) {
            u0 ^= ((unsigned)((i0 % (0x10000u | 1u)) && v0) | 4u);
        }
        i0 = (unsigned)((short)(6u ? (0x5b04b92bu % (garr[i1 & 7u] | 1u)) : p1) > (signed char)v0) & 15u;
    }
    { unsigned t0; double z0; if ((i0) & 1u) { t0 = (r0.x * (*mp * u3)); z0 = (double)(((unsigned)(unsigned char)(unsigned)((a0[i0 & 3u] | (unsigned)f0) == a0[i0 & 3u])) & 255u); } if ((i0) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        i0 = (unsigned)(0x80000000u || 8u) & 15u;
        if (budget != 0u) { budget -= 1u; u2 = fn0((r0.x + p1), ((unsigned)h0 << ((unsigned)((int)0x10000u >= (int)*q0) & 31u)), (i0 % (a0[u1 & 3u] | 1u))); }
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(a0[u1 & 3u] & 0xb3a21d15u) > (signed char)*q0), m0, u2); }
            if (5u) {
                *q0 += ((garr[u2 & 7u] ? (unsigned)((unsigned)c1 < r0.x) : i0) & (unsigned)s1);
            } else {
                if (g0) {
                    d0 = d0 * 0.5 + (double)((0xcf3138d4u ^ u0) & 1023u);
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)(unsigned char)(0x2f7c9e4eu & (unsigned)d0)) break;
                        e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(7u | *mp) & 1023u);
                        x0 = x0 * 0x100000001b3ull + ((unsigned)(0x2c93054au < (unsigned)((int)garr[i1 & 7u] < (int)0xffffffffu)) / (((unsigned)h1 << ((unsigned)(w0 >> 29) & 31u)) | 1u));
                        r0.x = ((0x3383300cu ^ ((unsigned)c1 & m0)) / ((unsigned)w0 | 1u));
                        d0 = d0 * 0.5 + (double)((unsigned)(garr[i1 & 7u] || (unsigned)(unsigned char)(i0 >> ((unsigned)(p0 && i1) & 31u))) & 1023u);
                    } while (i1++ < 6u && ((unsigned)((int)8u >= (int)p0) >> (p0 & 31u)));
                    b0 = (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)((int)(i2 & (unsigned)x0) >= (int)0xf572f3b2u)) != 0u;
                    r0.y ^= (unsigned)(i1 || 7u);
                }
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (unsigned)((unsigned)e0 || (unsigned)(0xbe8a61c4u == 0xffffffffu)) != 0u;
                }
                if ((unsigned)c1) {
                    switch ((unsigned)f0 & 7u) {
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(unsigned)!(unsigned)((int)0x80000000u < (int)5u) > (signed char)*mp), (1u % ((unsigned)l0 | 1u)), u2); }
                    }
                    u3 ^= (unsigned)((short)g1 > (signed char)0xffffffffu);
                    s1 = (int)((unsigned)s1 + ((unsigned)w0 | (unsigned)((int)0x4d0c622bu >= (int)i1)));
                } else {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((v0 / (m0 | 1u)), ((unsigned)f0 / ((0u >> (1u & 31u)) | 1u)), (unsigned)(a0[i0 & 3u] == (i1 ^ 0x10000u))); }
                    switch ((1u | u3) & 7u) {
                        if ((unsigned)e0) {
                            s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(x0 >> 70) == p0));
                            *mp = 0x9256d0eu;
                            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(*q0 < v0), (unsigned)((short)(unsigned)x0 > (signed char)(unsigned)d0), ((unsigned)h1 ? 0x41b0a460u : 0x10000u)); }
                            l0 = (long)((unsigned long)l0 + (unsigned)(4u || (unsigned)((int)u3 >= (int)-(a0[i0 & 3u] & (unsigned)x0))));
                            if (u3 == 7u) return (unsigned)((unsigned)w0 && 1u);
                        }
                        s1 = (int)((unsigned)s1 + (unsigned)!(a0[u1 & 3u] / ((unsigned)(unsigned char)((unsigned)b0 + 0x2ff356d2u) | 1u)));
                        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                            r0.y ^= (unsigned)((short)p0 > (signed char)m0);
                            case 1u: ;
                            g1 += ((unsigned)(w0 >> 29) ? 1u : (r0.y << (garr[i1 & 7u] & 31u)));
                            garr[p0 & 7u] = (g0 + *mp);
                            s0 = (int)((0xffffffffu & g0) >> ((unsigned)((int)((unsigned)c0 - u2) < (int)0x4617d5e6u) & 31u));
                        }
                        if ((unsigned)!(9u % ((0x2ba0ade3u << ((unsigned)h1 & 31u)) | 1u))) continue;
                    }
                    break; (void)((unsigned)(unsigned char)((unsigned)l0 << ((unsigned)(w0 >> 29) & 31u)));
                }
            }
            g0 = (0x10000u * 0xa3cda672u);
            while (((unsigned)(garr[u2 & 7u] || g0) / (garr[u2 & 7u] | 1u))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((7u * (i2 & p1)), (unsigned)(unsigned char)(unsigned)(0xffffffffu && (4u % ((unsigned)s1 | 1u))), (unsigned)((int)fuel < (int)*q0)); }
                g0 = ((0xf71ffe57u + a0[u1 & 3u]) * (unsigned)w0);
            }
            d0 = d0 * 0.5 + (double)((unsigned)((int)r0.y < (int)(unsigned)(r0.x || (unsigned)s0)) & 1023u);
            break; (void)((unsigned)(8u && (unsigned)((int)1u < (int)(unsigned)c1)));
        } while (i0++ < 4u && (g0 ^ (unsigned)((unsigned)w0 || 0x7fffffffu)));
        while (i0++ < 3u && (unsigned)h0) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)h1 << ((unsigned)((short)(unsigned)h1 > (signed char)0xffffffffu) & 63u);
        }
        if (u3 == 7u) return (unsigned)!(*q0 | 0xffffffffu);
    }
    r0.y ^= 0xdce1177bu;
    h0 = (short)fuel;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((int)(unsigned)h0 >= (int)0x48fae4e8u) | (unsigned)(x0 >> 70)), (unsigned)((unsigned)(0x10000u == fuel) || 9u), (unsigned)(p2 == (i0 % (0x80000000u | 1u)))); }
        w0 ^= (unsigned long long)0u << (((unsigned)x0 * ((g0 >> (0xffffffffu & 31u)) >> (i1 & 31u))) & 63u);
        if ((unsigned)((int)(unsigned)d0 >= (int)(unsigned)(w0 >> 29))) break;
        r0.y ^= 0xcf91379u;
        goto L0;
    } while (i0++ < 7u && ~(unsigned)(0x9d5b8a17u == *mp));
    if (0xdc7a644fu) goto L0;
    do { if (--fuel == 0u) goto done;
        r0.x = ((unsigned)(short)(unsigned)((int)(unsigned)((int)(unsigned)w0 < (int)u1) < (int)(unsigned)f0) * (unsigned)((int)(unsigned)e0 < (int)(unsigned)c0));
        if (((unsigned)((int)u3 < (int)0x10000u) - 0x10000u)) continue;
        u1 += (unsigned)((short)(unsigned)((unsigned)(short)(9u + 0u) == g1) > (signed char)(unsigned)(short)(p0 - *mp));
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if ((-(unsigned)(3u == (9u * g1))) & 1u) { t1 = (0x4b60cc3eu | 0x80000000u); z1 = (double)(((unsigned)((u1 + g1) && *q0)) & 255u); } if ((-(unsigned)(3u == (9u * g1))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                if (fuel < 8u) return (u0 & u2);
                s1 = (int)((unsigned)s1 + (unsigned)((int)r0.x < (int)(unsigned)(signed char)(m0 + (unsigned)s0)));
                h1 = (unsigned short)(h1 + (unsigned)((short)p2 > (signed char)*q0));
                if (budget != 0u) { budget -= 1u; u0 = fn0((g1 ^ (unsigned)(x0 >> 70)), 0u, ((unsigned)(w0 >> 29) ^ r0.y)); }
                continue; (void)((unsigned)(0xfeab7d1u && 6u));
                *mp = (unsigned)(signed char)(unsigned)((garr[i1 & 7u] >> (7u & 31u)) == i0);
            }
        }
        i0 = (unsigned)e0 & 15u;
    } while (i0++ < 3u && (2u ? (unsigned)d0 : i2));
    do { if (--fuel == 0u) goto done;
        u0 = u0 * 0x9e3779b1u + m0;
        if ((unsigned)x0) {
            x0 = x0 * 0x100000001b3ull + -((g1 | (unsigned)(w0 >> 29)) - (unsigned)(6u == r0.y));
            while (i1++ < 6u && (unsigned)(a0[u1 & 3u] && r0.x)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(0x80000000u, (unsigned)((short)i0 > (signed char)p2), 0x10000u); }
                if ((unsigned)((unsigned)b0 || v0)) break;
                if (((unsigned)s0 ? (unsigned)e0 : *q0)) break;
            }
            q0 = &garr[9u & 7u];
            goto L3;
            if (fuel < 8u) return *mp;
            f0 = f0 * 0.5f + (float)((unsigned)(0x4765a017u < (unsigned)((int)0x2a740452u < (int)(8u & u3))) & 255u);
        }
        d0 = d0 * 0.5 + (double)(r0.x & 1023u);
    } while (i0++ < 3u && (unsigned)x0);
    if ((p1 * 0x10000u)) goto L2;
    v0 = (g0 * (unsigned)x0);
    if (-(unsigned)(i0 == *q0)) goto L1;
    u2 = (unsigned)(short)(a0[u1 & 3u] | (unsigned)((unsigned)(x0 >> 70) && 6u));
    { unsigned t2; double z2; if (((unsigned)(unsigned char)((unsigned)(unsigned char)(u2 / (0x7fffffffu | 1u)) % (0x80000000u | 1u))) & 1u) { t2 = (0x5e26ba45u | 0x80000000u); z2 = (double)(((0xee9c9e11u ^ v0)) & 255u); } if (((unsigned)(unsigned char)((unsigned)(unsigned char)(u2 / (0x7fffffffu | 1u)) % (0x80000000u | 1u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        if ((unsigned)((short)v0 > (signed char)(unsigned)(w0 >> 29))) goto L1;
    }
    if (~((unsigned)x0 ^ (i0 - r0.x))) goto L2;
    if (fuel < 8u) return 1u;
    *q0 += g0;
    if (budget != 0u) { budget -= 1u; u2 = fn0((r0.x << ((p0 * p1) & 31u)), (v0 >> (3u & 31u)), ((unsigned)(w0 >> 29) + u0)); }
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)p1 >= (int)4u), r0.x, (0xcdbb3501u & a0[u1 & 3u])); }
    while ((unsigned)((short)(0xffffffffu << ((unsigned)(x0 >> 70) & 31u)) > (signed char)i0)) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)0x728ee796u >= (int)g1)) break;
        if (0x80000000u) break;
    }
    if ((unsigned)((short)(unsigned)w0 > (signed char)garr[u2 & 7u])) goto done;
    { unsigned t3; double z3; if (((unsigned)c0) & 1u) { t3 = (unsigned)((int)i0 < (int)(unsigned)(unsigned char)(unsigned)(i0 || fuel)); z3 = (double)((0x132fe629u) & 255u); } if (((unsigned)c0) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0((*mp ^ v0), (unsigned)((int)(unsigned)l0 < (int)fuel), (unsigned)((int)r0.x < (int)u3)); }
        goto L2;
        h0 = (short)(unsigned)(-(fuel ? (unsigned)b0 : garr[i1 & 7u]) == (unsigned)((int)(unsigned)l0 >= (int)0xebb0bd48u));
        if ((((unsigned)c0 - i1) % (0xb1e4db57u | 1u))) goto L2;
        v0 = ((unsigned)f0 / ((unsigned)h1 | 1u));
    }
    e0 = e0 * 0.5L + (long double)((6u + i2) & 1023u);
    u3 += (u1 ^ (unsigned)(signed char)(unsigned)(g0 == 0x7fffffffu));
    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(*mp == (unsigned)!(0xffffffffu * u2)) && u3));
    do { if (--fuel == 0u) goto done;
        b0 = (unsigned)((int)6u < (int)(unsigned)(u0 < (unsigned)w0)) != 0u;
        while (i1++ < 2u && (unsigned)(signed char)((0x7fffffffu / (m0 | 1u)) % (p1 | 1u))) { if (--fuel == 0u) goto done;
            g1 += ((unsigned)(w0 >> 29) & (1u + (unsigned)((unsigned)h0 || 0x80000000u)));
            break; (void)((unsigned)(unsigned char)(u2 * r0.y));
            if (budget != 0u) { budget -= 1u; u1 = fn0((m0 ^ (unsigned)((unsigned)c0 < v0)), u2, -(u3 % (garr[i1 & 7u] | 1u))); }
        }
        do { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= 5u;
                c1 = (signed char)(*q0 | ((unsigned)(x0 >> 70) - (1u << ((i1 % (0xffffffffu | 1u)) & 31u))));
                do { if (--fuel == 0u) goto done;
                    if ((a0[i0 & 3u] % (4u | 1u))) {
                        b0 = (unsigned)((short)2u > (signed char)(unsigned)(short)((unsigned)f0 << (((unsigned)(w0 >> 29) << (*mp & 31u)) & 31u))) != 0u;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((u1 + u1), u3, (unsigned)((int)u0 >= (int)0x67658c7u)); }
                        if ((unsigned)(4u && 0xc2998a8eu)) break;
                    }
                    g1 += (u3 ? (g0 + 3u) : (unsigned)c0);
                    f0 = f0 * 0.5f + (float)((0xc1658acbu + 0xb8c99658u) & 255u);
                } while (i0++ < 6u && (a0[i0 & 3u] & garr[u2 & 7u]));
                i0 = ((unsigned)h0 & 0x7fffffffu) & 15u;
            }
            i1 = 4u & 15u;
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)e0 >= (int)0xb0a7fa68u));
            continue; (void)(~(unsigned)(0x65dc32f8u && fuel));
        } while (i1++ < 4u && i0);
        for (;;) { if (--fuel == 0u) goto done;
            a0[0x98654cddu & 3u] = ((u2 << (i2 & 31u)) << ((unsigned)l0 & 31u));
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0xe1b30ebfu), (i1 ^ ~(unsigned)(u2 < p2)), (unsigned)(7u && p1)); }
            b0 = -((fuel ? (p1 / ((unsigned)x0 | 1u)) : u0) % (0x86491bd2u | 1u)) != 0u;
            if (0x7a3a1484u) break;
        }
        c1 = (signed char)((unsigned)((int)i1 >= (int)garr[u2 & 7u]) * (unsigned)((int)*q0 < (int)(0xac334586u / (p2 | 1u))));
        if ((unsigned)((int)(unsigned)((short)0xc729461eu > (signed char)(unsigned)c1) < (int)9u)) break;
    } while (i0++ < 7u && ((garr[u2 & 7u] + (unsigned)c1) / ((unsigned)x0 | 1u)));
    if (-(0xfd09701bu - 0x10000u)) goto L3;
    for (;;) { if (--fuel == 0u) goto done;
        switch ((unsigned)(0xd15229ddu || fuel) & 7u) {
            b0 = (unsigned)((((unsigned)b0 >> ((unsigned)c1 & 31u)) * 0xc26e2634u) == ~(0xd8046ed9u + 0xe729245eu)) != 0u;
            f0 = f0 * 0.5f + (float)((p0 / ((unsigned)(x0 >> 70) | 1u)) & 255u);
            h0 = (short)(0x7fffffffu % (i1 | 1u));
        }
        if (((unsigned)((short)1u > (signed char)m0) * (unsigned)(x0 >> 70))) {
            if (a0[i0 & 3u]) break;
            c0 = (unsigned char)(unsigned)(signed char)((unsigned)((0x81fa1a57u | a0[u1 & 3u]) == g1) % (*q0 | 1u));
            l0 = (long)((unsigned long)l0 + (unsigned)((short)((unsigned)c1 + g1) > (signed char)(unsigned)(unsigned char)(unsigned)((int)6u >= (int)(0xffffffffu << (i2 & 31u)))));
        }
        h1 = (unsigned short)(h1 + (unsigned)((i1 - u0) == 0u));
    }
    goto L4;
    if ((unsigned)c0) goto done;
    switch ((0xffffffffu ? (unsigned)s1 : (unsigned)w0) & 7u) {
        case 3u: ;
        e0 = e0 * 0.5L + (long double)(0x419fa815u & 1023u);
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(signed char)(unsigned)((unsigned)s1 < ((unsigned)e0 + (unsigned)b0)), ((unsigned)(7u == 0x80000000u) >> ((unsigned)w0 & 31u)), 0x63cd2eacu); }
        if ((unsigned)(unsigned char)(-(p0 / (a0[i0 & 3u] | 1u)) / (0x10000u | 1u))) goto L0;
        { unsigned t4; double z4; if (((unsigned)(fuel && ((unsigned)c1 % (p1 | 1u)))) & 1u) { t4 = (unsigned)(v0 < i1); z4 = (double)(((unsigned)(i0 || 7u)) & 255u); } if (((unsigned)(fuel && ((unsigned)c1 % (p1 | 1u)))) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            while (i0++ < 6u && ((unsigned)l0 >> ((u2 + 0xc86f6e94u) & 31u))) { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)s1) break;
                }
                garr[(a0[i0 & 3u] ^ 0x7fffffffu) & 7u] = (unsigned)((unsigned)((unsigned)x0 || i2) && p0);
                case 4u: ;
                if ((fuel * (unsigned)s0)) goto L3;
                if ((unsigned)((unsigned)b0 == u3)) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0x80000000u | u1), (unsigned)h0, (unsigned)(signed char)((unsigned)(w0 >> 29) ^ (unsigned)c1)); }
                    g1 += (unsigned)e0;
                    e0 = e0 * 0.5L + (long double)(0x9c2d8059u & 1023u);
                    break; (void)((((unsigned)l0 & p0) % (3u | 1u)));
                    *q0 = ((unsigned)(r0.x || 0x80000000u) ^ (unsigned)(0x2fde5b40u || p1));
                } else {
                    g1 += (unsigned)((unsigned)l0 < ~(((unsigned)s0 + (unsigned)((unsigned)h0 < garr[u2 & 7u])) + (unsigned)h1));
                    m0 ^= (unsigned)(unsigned char)(unsigned)((unsigned)e0 && 4u);
                    if ((unsigned)((int)g1 >= (int)p1)) {
                        do { if (--fuel == 0u) goto done;
                            case 6u: ;
                            c0 = (unsigned char)(((0x673a9af8u >> (0x81945328u & 31u)) ^ (unsigned)s0) * (unsigned)(g1 < u2));
                            default: ;
                            v0 = (unsigned)!(unsigned)((unsigned)((int)fuel >= (int)fuel) || ((unsigned)d0 ? *q0 : (unsigned)d0));
                            q0 = &garr[((unsigned)(x0 >> 70) + (*q0 ^ (unsigned)(a0[u1 & 3u] < r0.y))) & 7u];
                            x0 = x0 * 0x100000001b3ull + (unsigned)h1;
                        } while (i1++ < 6u && ((unsigned)((unsigned)e0 && 0x7fffffffu) >> (m0 & 31u)));
                        q0 = &garr[(unsigned)(signed char)((~(unsigned)(0xffffffffu || i0) * i2) & 0x10000u) & 7u];
                        h1 = (unsigned short)(h1 + (p2 << ((0x80000000u & (u2 | (unsigned)((int)p0 < (int)m0))) & 31u)));
                        if ((unsigned)(short)(unsigned)((int)(unsigned)d0 < (int)4u)) goto L3;
                    } else {
                        break; (void)((unsigned)((unsigned)(w0 >> 29) == fuel));
                        g1 += ((4u ^ (unsigned)h1) & ((unsigned)w0 & r0.x));
                        r0.y ^= u0;
                    }
                }
                d0 = d0 * 0.5 + (double)((unsigned)(short)(unsigned)((int)(unsigned)(0x80000000u || (unsigned)l0) < (int)2u) & 1023u);
            }
            u3 = u3 * 0x9e3779b1u + (unsigned)((p1 % (1u | 1u)) || u0);
            switch (~(0xc756553du << ((unsigned)h0 & 31u)) & 7u) {
                if ((unsigned)((unsigned)((short)(unsigned)e0 > (signed char)0x936be44fu) < r0.x)) break;
                case 1u: ;
                e0 = e0 * 0.5L + (long double)((unsigned)((short)0xffffffffu > (signed char)a0[u1 & 3u]) & 1023u);
                do { if (--fuel == 0u) goto done;
                    while (i1++ < 2u && (unsigned)((int)(unsigned)c0 < (int)p1)) { if (--fuel == 0u) goto done;
                        case 7u: ;
                        case 2u: ;
                        h1 = (unsigned short)(h1 + ((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)(w0 >> 29)) >> (-(unsigned)((int)0x268614c1u < (int)v0) & 31u)));
                        r0.x = (0x6bf5c9a5u ? (unsigned)w0 : p1);
                        { unsigned t5; double z5; if (((4u << (~(u3 % (9u | 1u)) & 31u))) & 1u) { t5 = ((unsigned)c1 - (g0 / (0xfa0f2ef3u | 1u))); z5 = (double)((2u) & 255u); } if (((4u << (~(u3 % (9u | 1u)) & 31u))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                            u0 += (unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)u2 >= (int)(unsigned)((short)3u > (signed char)((unsigned)f0 % (u2 | 1u)))) >= (int)0xa2476e42u);
                            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)a0[u1 & 3u] > (signed char)m0), (garr[i1 & 7u] / (2u | 1u)), p2); }
                        }
                    }
                    u1 = u1 * 0x9e3779b1u + ((((unsigned)l0 | 0xcd86980au) ^ 7u) + (unsigned)b0);
                    d0 = d0 * 0.5 + (double)((unsigned)(0x10000u == (unsigned)(unsigned char)(8u ^ p2)) & 1023u);
                    e0 = e0 * 0.5L + (long double)((*q0 | m0) & 1023u);
                    for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        default: ;
                        goto done;
                        *mp = -(0xc7f6a211u + 0x80000000u);
                        i1 = (unsigned)((int)(unsigned)((int)(unsigned)c0 < (int)m0) >= (int)0x93399d64u) & 15u;
                        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)l0 && (unsigned)((int)*mp >= (int)i0));
                        h1 = (unsigned short)(h1 + (9u >> (((unsigned)(unsigned char)(g1 - r0.y) + 9u) & 31u)));
                    }
                    { unsigned t6; double z6; if ((((unsigned)((int)8u < (int)garr[i1 & 7u]) / (i0 | 1u))) & 1u) { t6 = ~((unsigned)h1 * ~(9u + u3)); z6 = (double)((0x5e8c802du) & 255u); } if ((((unsigned)((int)8u < (int)garr[i1 & 7u]) / (i0 | 1u))) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                        if (budget != 0u) { budget -= 1u; u0 = fn0(p1, (fuel - p2), (unsigned)b0); }
                    }
                } while (i0++ < 4u && (unsigned)(unsigned char)(unsigned)((int)u1 >= (int)u2));
                break;
            }
            goto done;
            w0 = w0 * 6364136223846793005ull + (*mp * g1);
            if ((unsigned)(2u && (garr[u2 & 7u] / (v0 | 1u)))) {
                if (0xe2e7f3cdu) goto L0;
            }
        }
        break;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    u2 += ((((unsigned)((unsigned)c1 && (unsigned)s1) * 6u) & 5u) + r0.y);
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)!(unsigned)((int)u0 >= (int)a0[u1 & 3u]), u3, (a0[u1 & 3u] % (u1 | 1u))); }
    w0 = w0 * 6364136223846793005ull + (r0.x + ((unsigned)(0xde890a5cu < r0.y) ^ (p0 + p0)));
    u3 = ((unsigned)s1 / ((unsigned)b0 | 1u));
    w0 = w0 * 6364136223846793005ull + p0;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch ((0x80000000u << ((unsigned)f0 & 31u)) & 7u) {
                L0: if (--fuel == 0u) goto done;
            }
            L1: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1((i0 << (8u & 31u)), (unsigned)(short)(unsigned)(1u < 9u), (unsigned)((int)(unsigned)b0 >= (int)(unsigned)((short)0x62f91ae3u > (signed char)u2))); }
            i0 = ~(0xffffffffu * m0) & 15u;
            { unsigned t0; double z0; if (((u1 ^ (unsigned)((int)(unsigned)c0 < (int)0x7fffffffu))) & 1u) { t0 = (unsigned)((unsigned)s1 && -(0x10000u * 7u)); z0 = (double)(((-(0xffffffffu | 9u) + (unsigned)s1)) & 255u); } if (((u1 ^ (unsigned)((int)(unsigned)c0 < (int)0x7fffffffu))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(*q0 || 0x7fffffffu), (unsigned)e0, (0xf03c6658u + garr[u2 & 7u])); }
                g1 += (unsigned)(unsigned char)((unsigned)(6u < (unsigned)s1) * (unsigned)l0);
                do { if (--fuel == 0u) goto done;
                    if ((u2 % ((u0 * p2) | 1u))) goto L0;
                    if ((0xffffffffu << ((unsigned)h0 & 31u))) break;
                } while (i2++ < 5u && ((1u % ((unsigned)c1 | 1u)) & garr[u2 & 7u]));
            }
            i2 = 2u & 15u;
        }
        if ((unsigned)(0x16eb55d7u < 0xffffffffu)) break;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1((0x80000000u % (u3 | 1u)), 0x80000000u, (unsigned)((int)p1 < (int)(0x80000000u ^ r0.y))); }
    c1 = (signed char)(u1 ? 3u : u1);
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((0u << ((g0 >> ((unsigned)l0 & 31u)) & 31u))) goto L1;
        u1 += (p1 | ((unsigned)((int)0x7fffffffu < (int)(unsigned)c1) * (unsigned)h0));
        garr[(5u >> (a0[i0 & 3u] & 31u)) & 7u] = (unsigned)(m0 == (unsigned)d0);
        if (p2) break;
        if (u3 == 7u) return (unsigned)c1;
    }
    if (0xf69a2737u) goto done;
    if (budget != 0u) { budget -= 1u; u0 = fn0(7u, (0x80000000u & 8u), ((unsigned)c1 ? u2 : (unsigned)d0)); }
    if (-(garr[u2 & 7u] | (u3 | (unsigned)s1))) {
        v0 = ((unsigned)((unsigned)s1 == 8u) >> ((0x43e5053cu & (r0.x << (0x8043f08u & 31u))) & 31u));
        goto L2;
        *q0 = (unsigned)e0;
        if (fuel < 8u) return (unsigned)(((unsigned)l0 & p2) && (unsigned)((unsigned)c0 && r0.x));
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(signed char)((unsigned)!(0x10000u % ((unsigned)(w0 >> 29) | 1u)) % ((unsigned)h0 | 1u)), ((unsigned)b0 * (unsigned)(w0 >> 29)), 0xb3b8a87fu); }
        if ((unsigned)((a0[i0 & 3u] - 0x10000u) == *mp)) goto L0;
    } else {
        goto L0;
        r0.y ^= (unsigned)((int)~((unsigned)d0 >> (a0[i0 & 3u] & 31u)) >= (int)(0x7fffffffu + (i0 * 1u)));
        L2: if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            g0 = (unsigned)((unsigned)s1 == (0x7fffffffu ^ (garr[u2 & 7u] % ((8u % (i2 | 1u)) | 1u))));
            r0.y ^= (unsigned)(signed char)((fuel >> ((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)f0) & 31u)) ? 0xd6b42460u : u2);
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                while ((unsigned)(p1 && (unsigned)(signed char)(unsigned)(a0[u1 & 3u] < p0))) { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)((int)(g1 / (~(0xffffffffu << (3u & 31u)) | 1u)) < (int)(unsigned)!(i1 - garr[u2 & 7u]));
                    q0 = &garr[(garr[u2 & 7u] / ((unsigned)h0 | 1u)) & 7u];
                }
                i1 = (unsigned)(short)((unsigned)h0 | fuel) & 15u;
                u2 = u2 * 0x9e3779b1u + (unsigned)((int)(unsigned)(0xb45a9b6eu || ((unsigned)b0 % (r0.y | 1u))) < (int)(0xc8ec3990u - r0.y));
                u2 += (g1 << (r0.y & 31u));
                while (i2++ < 2u && (unsigned)(short)((0x80000000u << (0x3f2e80ddu & 31u)) + u3)) { if (--fuel == 0u) goto done;
                    if ((0x7fffffffu | r0.y)) {
                        L3: if (--fuel == 0u) goto done;
                    }
                    w0 = w0 * 6364136223846793005ull + ((unsigned)(signed char)(unsigned)((unsigned)f0 == (0x7fffffffu ^ 0xffffffffu)) >> ((r0.x * g1) & 31u));
                    s1 = (int)((unsigned)s1 + 3u);
                }
            }
            if ((unsigned)((unsigned)(u1 < (unsigned)c0) == 0x10000u)) goto L4;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((a0[u1 & 3u] & (unsigned)c1) || u2), (5u / ((unsigned)h1 | 1u)), 0x10000u); }
            switch ((unsigned)((int)((unsigned)c1 ^ (unsigned)x0) >= (int)p0) & 7u) {
                case 7u: ;
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)(unsigned char)(unsigned)((0x3bf831bdu / (u3 | 1u)) || -(*q0 >> (0x10000u & 31u)));
                    u2 = u2 * 0x9e3779b1u + (unsigned)b0;
                    L4: if (--fuel == 0u) goto done;
                    g0 = (unsigned)(g1 && (garr[i1 & 7u] & -(unsigned)((unsigned)s1 && *mp)));
                    { unsigned t1; double z1; if ((0xbaeef142u) & 1u) { t1 = (unsigned)((short)0x31dbc571u > (signed char)4u); z1 = (double)(((unsigned)((int)u3 < (int)(g1 * 0x30aec89u))) & 255u); } if ((0xbaeef142u) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                        goto L1;
                    }
                    m0 ^= (v0 / ((unsigned)((short)a0[u1 & 3u] > (signed char)p0) | 1u));
                }
            }
        } while (i0++ < 5u && (0xf9190f37u >> (*q0 & 31u)));
    }
    g0 = ((unsigned)(signed char)(unsigned)((g0 >> (i1 & 31u)) == (unsigned)h0) >> (u1 & 31u));
    if (p0) {
        u0 += (a0[i0 & 3u] - 0x80000000u);
        u2 = u2 * 0x9e3779b1u + (unsigned)(0x80000000u && a0[i0 & 3u]);
        h0 = (short)(unsigned)(unsigned char)(0x10000u >> ((unsigned)(u0 < u1) & 31u));
    } else {
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(a0[u1 & 3u] || i0), (0x80000000u / ((unsigned)((unsigned)(x0 >> 70) || i2) | 1u)), 0x80000000u); }
        switch (u0 & 7u) {
            x0 = x0 * 0x100000001b3ull + garr[i1 & 7u];
            if (budget != 0u) { budget -= 1u; u3 = fn0(r0.x, u3, (0x351366d2u * 7u)); }
            if ((0xffffffffu | (unsigned)s0)) goto L2;
            case 6u: ;
            u3 = ((unsigned)c0 * (unsigned)x0);
        }
    }
    u3 += -((unsigned)(unsigned char)(0x73d01518u ? r0.y : (unsigned)f0) % (0x6374c3cau | 1u));
    if ((unsigned)l0) goto L2;
    if (p1) goto L2;
    if (budget != 0u) { budget -= 1u; u3 = fn0(((0xffffffffu | p0) % (0x7fffffffu | 1u)), (unsigned)s0, ((unsigned)f0 | 3u)); }
    *mp = (unsigned)((int)((unsigned)c0 + 0x80000000u) >= (int)(unsigned)(i2 < (g0 % (i2 | 1u))));
    if (m0) goto L0;
    *mp = ((unsigned)(w0 >> 29) >> (0x7fffffffu & 31u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L0;
    h1 = (unsigned short)(h1 + ((unsigned)l0 & r0.y));
    u3 = u0;
    switch (9u & 7u) {
        m0 ^= (unsigned)(short)(unsigned)((int)(p1 ? r0.x : 0xe65dbae8u) >= (int)(a0[u1 & 3u] - (unsigned)(w0 >> 29)));
        s0 = (int)-(unsigned)((short)(unsigned)(short)(i2 << (0x80000000u & 31u)) > (signed char)(unsigned)((unsigned)d0 && (unsigned)b0));
        u0 = (((unsigned)((short)(unsigned)e0 > (signed char)0x7fffffffu) << (a0[i0 & 3u] & 31u)) & (m0 | 0x80000000u));
        goto L4;
    }
    while (i0++ < 6u && r0.y) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1((i0 % (9u | 1u)), 0x7fffffffu, i1); }
        L0: if (--fuel == 0u) goto done;
        continue; (void)((unsigned)((short)0x80000000u > (signed char)(garr[i1 & 7u] << (g0 & 31u))));
    }
    m0 ^= (fuel + 0x8ee11931u);
    for (;;) { if (--fuel == 0u) goto done;
        if ((0xffffffffu >> ((unsigned)s0 & 31u))) break;
        break; (void)((((unsigned)d0 >> ((unsigned)x0 & 31u)) - (unsigned)s1));
        c1 = (signed char)(unsigned)((short)(u2 - 0x10000u) > (signed char)i1);
        c0 = (unsigned char)((unsigned)e0 ^ ((unsigned)(signed char)(unsigned)((fuel % ((unsigned)b0 | 1u)) && a0[u1 & 3u]) >> (0x7fffffffu & 31u)));
        if (((unsigned)((int)p1 >= (int)fuel) << (r0.x & 31u))) {
            e0 = e0 * 0.5L + (long double)(((r0.x | m0) & (unsigned)d0) & 1023u);
            L1: if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                L2: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)f0, (unsigned)e0, (g0 >> ((unsigned)((int)8u < (int)(unsigned)h0) & 31u))); }
                if (0x10000u) break;
                g0 = (0u >> (2u & 31u));
                L3: if (--fuel == 0u) goto done;
            } while (i1++ < 4u && (unsigned)((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)d0) || r0.x));
        }
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn2(*q0, (unsigned)(x0 >> 70), (unsigned)w0); }
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)w0 < (unsigned)s0), (unsigned)(short)(unsigned)(garr[i1 & 7u] == 0xb30e1360u), 5u); }
        if (budget != 0u) { budget -= 1u; u2 = fn0((u2 ? a0[u1 & 3u] : u1), (unsigned)((unsigned)!(unsigned)((int)(unsigned)b0 >= (int)1u) || r0.y), (p2 << ((unsigned)f0 & 31u))); }
        s0 = (int)(unsigned)((unsigned)(unsigned char)((5u ^ garr[u2 & 7u]) << (i1 & 31u)) == (unsigned)e0);
        { unsigned t0; double z0; if (((unsigned)(x0 >> 70)) & 1u) { t0 = u2; z0 = (double)(((unsigned)e0) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (p0 * ((unsigned)s1 >> (0x9ac061d7u & 31u)));
                    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)d0, garr[u2 & 7u], ((unsigned)h1 / ((unsigned)(0xffffffffu || 0x7d4df290u) | 1u))); }
                        if ((unsigned)((0x9347da00u * 8u) && (unsigned)b0)) break;
                    }
                    b0 = ((unsigned)(g0 < u0) - 0xffffffffu) != 0u;
                    w0 ^= (unsigned long long)a0[i0 & 3u] << ((unsigned)(x0 >> 70) & 63u);
                    u2 += (unsigned)(unsigned char)(fuel % ((unsigned)((unsigned)((int)(unsigned)w0 >= (int)(unsigned)f0) || 0xfdeb166bu) | 1u));
                } while (i2++ < 3u && (unsigned)(4u < ((unsigned)s1 - 8u)));
                if (5u) break;
                r0.x = (((unsigned)h0 >> ((unsigned)(x0 >> 70) & 31u)) & (unsigned)d0);
                do { if (--fuel == 0u) goto done;
                    u1 += (unsigned)!(unsigned)((unsigned)((short)~((unsigned)e0 | 0x174f70afu) > (signed char)0x80000000u) == g0);
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((short)(unsigned)(0xef9dd3d0u || u0) > (signed char)(unsigned)s1), ((unsigned)f0 % (0x7fffffffu | 1u)), (garr[i1 & 7u] | (unsigned)s0)); }
                    continue; (void)(-(unsigned)((unsigned)(0x80000000u || p2) < (unsigned)(x0 >> 70)));
                    if ((unsigned)((int)(p0 ^ 0x80000000u) < (int)(unsigned)l0)) {
                        l0 = (long)((unsigned long)l0 + garr[i1 & 7u]);
                        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                            w0 ^= (unsigned long long)(a0[u1 & 3u] - 0x7fffffffu) << (((((v0 + 0x825a1dabu) - (unsigned)d0) / (8u | 1u)) % ((unsigned)h0 | 1u)) & 63u);
                            w0 ^= (unsigned long long)(i0 - (unsigned)c0) << ((unsigned)((short)p2 > (signed char)(unsigned)((int)g1 < (int)(unsigned)s1)) & 63u);
                            L4: if (--fuel == 0u) goto done;
                        }
                        if (((unsigned)(x0 >> 70) ^ 0xb32f7b7du)) break;
                        r0.y ^= (unsigned)((2u % ((unsigned)((int)(unsigned)e0 >= (int)g1) | 1u)) && (*mp * g1));
                        if (i2) break;
                    } else {
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)d0, (unsigned)!(unsigned)(1u || (unsigned)((short)garr[u2 & 7u] > (signed char)6u)), (fuel + -(unsigned)(g1 < (unsigned)c0))); }
                        if ((unsigned)(unsigned char)((unsigned)w0 % ((*mp & (unsigned)w0) | 1u))) break;
                        if (u0) break;
                        u1 = u1 * 0x9e3779b1u + ~((unsigned)((p0 << ((unsigned)c1 & 31u)) == 0x55c0c3f4u) >> ((unsigned)((short)u1 > (signed char)4u) & 31u));
                    }
                } while (i2++ < 3u && (unsigned)((unsigned)(i1 == a0[u1 & 3u]) == 0x10000u));
            }
            r0.y ^= (unsigned)((int)((unsigned)(p1 < i0) | 6u) >= (int)(unsigned)((int)a0[i0 & 3u] >= (int)0x10000u));
            while (i1++ < 4u && (7u - 9u)) { if (--fuel == 0u) goto done;
                if ((unsigned)(signed char)(0x10000u << ((unsigned)((int)(unsigned)c1 >= (int)(unsigned)c1) & 31u))) goto L1;
            }
            u1 ^= (unsigned)(short)(1u / ((*q0 >> (u1 & 31u)) | 1u));
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)d0 % ((p1 << (0x10000u & 31u)) | 1u)), (p0 | (unsigned)(w0 >> 29)), u2); }
        }
        r0.y ^= (unsigned)(v0 && ~(a0[u1 & 3u] << (-(u1 | (unsigned)h1) & 31u)));
    } while (i0++ < 5u && (*mp ^ (unsigned)s1));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[(i1 << (i1 & 31u)) & 3u] = (unsigned)((int)*mp < (int)(p2 - 0xffffffffu));
        while (i1++ < 7u && 0xc5ccf6dau) { if (--fuel == 0u) goto done;
            a0[(unsigned)(i0 < g0) & 3u] = ~(((unsigned)((*q0 << (p1 & 31u)) || i2) & (unsigned)c0) * a0[i0 & 3u]);
            if ((unsigned)((int)0x420b4872u < (int)(unsigned)h0)) break;
            { unsigned t1; double z1; if ((~((unsigned)(0x10000u == 0x833952adu) + *q0)) & 1u) { t1 = (unsigned)(4u < -(unsigned)(i2 < p0)); z1 = (double)((3u) & 255u); } if ((~((unsigned)(0x10000u == 0x833952adu) + *q0)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                if ((p2 * 8u)) break;
            }
            { unsigned t2; double z2; if ((~(unsigned)((*mp % (i0 | 1u)) == v0)) & 1u) { t2 = u1; z2 = (double)((((unsigned)h0 & ((unsigned)(x0 >> 70) | p2))) & 255u); } if ((~(unsigned)((*mp % (i0 | 1u)) == v0)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                if ((unsigned)(m0 && (g1 | u3))) break;
                f0 = f0 * 0.5f + (float)((unsigned)((int)0x43b4fb68u < (int)(unsigned)(0x7fffffffu == (unsigned)w0)) & 255u);
                x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)e0 || (fuel & i0));
            }
        }
        if ((unsigned)(8u == ((unsigned)b0 ^ p2))) {
            if (garr[u2 & 7u]) break;
            if ((unsigned)(v0 == garr[u2 & 7u])) continue;
            while (i1++ < 6u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                r0.x = (unsigned)((unsigned)((short)(unsigned)h0 > (signed char)0x80000000u) < (r0.y << (((unsigned)s1 ^ r0.y) & 31u)));
                h0 = (short)(unsigned)((int)0xffffffffu < (int)(unsigned)((short)(unsigned)f0 > (signed char)0x6ba45078u));
                b0 = 0x430e34e2u != 0u;
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((g0 - *q0)) break;
                }
            }
        }
    }
    if (g0) {
        w0 = w0 * 6364136223846793005ull + (i2 - 0xcc2f8ef4u);
        *q0 += i2;
        d0 = d0 * 0.5 + (double)(((unsigned)s1 >> ((unsigned)(i1 && (unsigned)(unsigned char)(unsigned)((short)(unsigned)b0 > (signed char)v0)) & 31u)) & 1023u);
        goto L1;
    } else {
        while (i0++ < 2u && p0) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)((short)*q0 > (signed char)p1) << ((unsigned)(r0.x == fuel) & 63u);
            do { if (--fuel == 0u) goto done;
                if (p1) break;
                *q0 = 0xffffffffu;
            } while (i1++ < 6u && p2);
            s1 = (int)((unsigned)s1 + garr[i1 & 7u]);
        }
        u1 ^= (unsigned)((unsigned)((unsigned)f0 == u3) < 7u);
        if ((((unsigned)(w0 >> 29) << (0x495e1ff7u & 31u)) / (u3 | 1u))) goto done;
        if (garr[u2 & 7u]) goto L2;
    }
    *mp = (unsigned)((int)-(i1 / ((unsigned)l0 | 1u)) >= (int)u0);
    if ((0x80000000u & (0xa1052edeu ^ (unsigned)w0))) goto L4;
    if ((unsigned)((int)0x73a0fedeu < (int)(unsigned)(short)(i2 | 0x16d90202u))) {
        *q0 += 0x615e3cf3u;
        c0 = (unsigned char)~(0x2c733b91u ^ (r0.x << ((unsigned)(p0 == 0x20411573u) & 31u)));
        do { if (--fuel == 0u) goto done;
            u0 += (unsigned)(0xcfccc713u == fuel);
            if ((unsigned)((int)(unsigned)(signed char)(unsigned)(*q0 < 8u) >= (int)0x10000u)) goto L0;
            if (budget != 0u) { budget -= 1u; u1 = fn1(a0[i0 & 3u], (unsigned)(signed char)(unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)((short)*q0 > (signed char)p0)), 1u); }
            if ((~(u1 << (g0 & 31u)) | garr[i1 & 7u])) break;
            { unsigned t3; double z3; if ((((unsigned)(w0 >> 29) - 0x7fffffffu)) & 1u) { t3 = ~((unsigned)((int)(unsigned)s1 >= (int)u1) + (unsigned)s0); z3 = (double)(((0xcb3e988bu - (unsigned)((int)0x9fd1f4d7u < (int)p1))) & 255u); } if ((((unsigned)(w0 >> 29) - 0x7fffffffu)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                if ((unsigned)(unsigned char)((unsigned)h1 % ((unsigned)((unsigned)h0 < p2) | 1u))) goto done;
                h1 = (unsigned short)(h1 + (unsigned)((int)((unsigned)c1 << (p0 & 31u)) < (int)0xccd7fd18u));
                g0 = (unsigned)((unsigned)((int)i1 < (int)fuel) && ((0x7fffffffu & a0[u1 & 3u]) | 0xaa084f9bu));
                if (budget != 0u) { budget -= 1u; u3 = fn2((0xdf371383u % ((unsigned)(short)(0x80000000u << ((unsigned)e0 & 31u)) | 1u)), (unsigned)(short)(3u << (v0 & 31u)), (unsigned)((short)4u > (signed char)(2u << (*mp & 31u)))); }
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(short)((unsigned)c0 - u2), (u3 | 0x80000000u), p1); }
        } while (i0++ < 6u && (0x10000u + i1));
        if ((unsigned)!(unsigned)((int)r0.y < (int)((unsigned)s1 & (unsigned)x0))) goto L4;
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)h0 >> ((unsigned)(garr[i1 & 7u] && i2) & 31u))) break;
            u0 += g1;
            if ((((unsigned)d0 >> (a0[i0 & 3u] & 31u)) - (unsigned)w0)) break;
            switch (a0[u1 & 3u] & 7u) {
                *mp = ((0x858c600bu & 0xffffffffu) + (unsigned)(unsigned char)((unsigned)(short)(i1 + u0) - (unsigned)b0));
                m0 ^= (unsigned)((short)((0x7145c4bau << (1u & 31u)) >> (0x80000000u & 31u)) > (signed char)(unsigned)h1);
                r0.y ^= (unsigned)(x0 >> 70);
                g1 += (unsigned)((int)p0 < (int)~(u0 % (g0 | 1u)));
                if (((unsigned)((int)(unsigned)e0 >= (int)0x18dfe635u) - p1)) goto L1;
                do { if (--fuel == 0u) goto done;
                    i0 = ((unsigned)(u3 == u0) & (unsigned)s1) & 15u;
                    u2 = u2 * 0x9e3779b1u + 9u;
                    case 3u: ;
                } while (i1++ < 2u && (g1 << (((unsigned)h1 - (unsigned)x0) & 31u)));
            }
            if ((unsigned)l0) break;
        }
        if ((unsigned)c0) goto L1;
    } else {
        if (budget != 0u) { budget -= 1u; u3 = fn1((4u / (g0 | 1u)), (unsigned)(a0[i0 & 3u] < u2), (p0 ? (unsigned)c1 : 0x80000000u)); }
        f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)((unsigned)s0 && i2) < (int)garr[u2 & 7u]) & 255u);
        do { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)(2u || (garr[i1 & 7u] | u2));
            if ((2u ^ 0xffffffffu)) continue;
            for (;;) { if (--fuel == 0u) goto done;
                switch ((a0[u1 & 3u] & ((unsigned)w0 * (unsigned)s1)) & 7u) {
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(w0 >> 29), ((unsigned)((unsigned)h1 && m0) >> (0xde33ec21u & 31u)), ((unsigned)e0 ? p2 : (unsigned)s1)); }
                    a0[i0 & 3u] = (unsigned)((int)((unsigned)(signed char)(unsigned)((int)(unsigned)((int)0xf6c611fbu < (int)0x3a876beau) >= (int)(unsigned)b0) - 1u) < (int)0xffffffffu);
                }
                if ((0x10000u * u0)) break;
                if ((0u >> ((unsigned)b0 & 31u))) goto L0;
            }
        } while (i0++ < 2u && -(0xcd0a7e1bu >> (p1 & 31u)));
        if (((*q0 ^ (unsigned)e0) >> (7u & 31u))) {
            if ((i2 + 0xffffffffu)) goto L0;
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)b0 << (u2 & 31u))) break;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(x0 >> 70), (g1 << ((unsigned)((unsigned)b0 == 4u) & 31u)), (u1 & (0x10000u * 0xc4b537dfu))); }
            if ((unsigned)(0x7fffffffu || i2)) goto L4;
            c0 = (unsigned char)~(*q0 & (unsigned)f0);
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)l0, (unsigned)(0x486779b4u == (0x10000u - 8u)), (unsigned)((int)g1 < (int)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)h0))); }
        } else {
            while ((i2 * u0)) { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)((unsigned)(0x50f723f4u || 1u) && i1);
            }
        }
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)f0 & 7u) {
            w0 = w0 * 6364136223846793005ull + ((unsigned)((unsigned)h0 || (unsigned)s0) >> (p1 & 31u));
            if (((garr[u2 & 7u] / ((unsigned)e0 | 1u)) + u0)) continue;
            if ((unsigned)((unsigned)f0 < (unsigned)c1)) {
                if (budget != 0u) { budget -= 1u; u2 = fn1(u3, (v0 | (unsigned)b0), -(unsigned)((unsigned)s1 || r0.y)); }
                while ((unsigned)((short)(m0 | p0) > (signed char)(unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)!((unsigned)(0x80000000u == (unsigned)h1) ^ (unsigned)(short)(unsigned)((short)0x30b83b4bu > (signed char)0xffffffffu)) < 0x98e5ae9fu));
                    if (u3 == 7u) return (unsigned)((int)(unsigned)d0 >= (int)u3);
                }
                if (4u) break;
                { unsigned t4; double z4; if ((2u) & 1u) { t4 = 0x3d87a977u; z4 = (double)((0u) & 255u); } if ((2u) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    garr[i0 & 7u] = (unsigned)f0;
                    r0.x = 0x7fffffffu;
                }
                case 1u: ;
            } else {
                g1 += (unsigned)(unsigned char)((unsigned)s1 - (m0 + (0x5b9f5db7u * (unsigned)h1)));
            }
            w0 = w0 * 6364136223846793005ull + 7u;
            l0 = (long)((unsigned long)l0 + (p2 ? (6u & *q0) : 1u));
        }
        *q0 += ~((unsigned)f0 ^ 9u);
        x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)c1 == r0.y) | 0x7fffffffu);
        do { if (--fuel == 0u) goto done;
            switch ((unsigned)s1 & 7u) {
                if ((unsigned)e0) {
                    if ((3u << ((unsigned)((unsigned)b0 && u3) & 31u))) break;
                    case 7u: ;
                    i0 = (garr[i1 & 7u] - (v0 ^ 0x10000u)) & 15u;
                    if ((unsigned)((int)p2 < (int)(unsigned)e0)) goto L0;
                }
            }
            while (i2++ < 7u && ((unsigned)e0 % ((unsigned)((int)1u < (int)u1) | 1u))) { if (--fuel == 0u) goto done;
                if ((unsigned)(a0[i0 & 3u] < i0)) goto L1;
                if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)(u3 < (unsigned)e0) >> (u0 & 31u)), (g0 % (4u | 1u)), (unsigned)(*q0 == (unsigned)(a0[u1 & 3u] && a0[u1 & 3u]))); }
                if ((unsigned)(g0 || (unsigned)(g1 < 2u))) {
                    if (((unsigned)h0 * (unsigned)s1)) goto L1;
                }
                c0 = (unsigned char)((unsigned)d0 * (garr[u2 & 7u] ? (unsigned)e0 : 0x80000000u));
            }
        } while (i1++ < 2u && (0xcb21dc88u ^ (unsigned)w0));
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(((unsigned)b0 << (g1 & 31u)) | (unsigned)(u3 && u3));
            *q0 += i1;
            if (budget != 0u) { budget -= 1u; u1 = fn0((u0 - 0x30f3f6bcu), g1, i0); }
            c1 = (signed char)(unsigned)((short)5u > (signed char)(0x178884a1u % ((unsigned)((short)(i0 / (i2 | 1u)) > (signed char)(unsigned)c1) | 1u)));
            f0 = f0 * 0.5f + (float)((u1 & (unsigned)b0) & 255u);
        }
    }
    if ((a0[i0 & 3u] >> (fuel & 31u))) {
        w0 ^= (unsigned long long)(7u - (unsigned)s0) << ((8u ? 0x60401f39u : (unsigned)((unsigned)h1 && 9u)) & 63u);
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1((r0.x + (unsigned)(w0 >> 29)), (unsigned)((short)p2 > (signed char)(unsigned)((short)(unsigned)e0 > (signed char)u0)), (unsigned)w0); }
        }
        u1 = ((unsigned)w0 / (0xd62e0e0du | 1u));
        if ((unsigned)(garr[i1 & 7u] == 9u)) goto done;
        if ((unsigned)!(unsigned)((unsigned)x0 || a0[i0 & 3u])) {
            d0 = d0 * 0.5 + (double)(((unsigned)((unsigned)c0 || (0xc9ba519bu + (unsigned)c1)) & p1) & 1023u);
            { unsigned t5; double z5; if (((unsigned)(p0 && (0x10000u << ((unsigned)x0 & 31u)))) & 1u) { t5 = (unsigned)(i0 && (unsigned)((unsigned)s0 == (unsigned)l0)); z5 = (double)((((unsigned)c1 ^ (unsigned)(unsigned char)(unsigned)((int)garr[i1 & 7u] < (int)garr[u2 & 7u]))) & 255u); } if (((unsigned)(p0 && (0x10000u << ((unsigned)x0 & 31u)))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                a0[0x8b2465cbu & 3u] = (a0[i0 & 3u] | ((p1 % ((unsigned)e0 | 1u)) << ((unsigned)((short)garr[i1 & 7u] > (signed char)garr[i1 & 7u]) & 31u)));
                if ((v0 - (9u >> (p1 & 31u)))) goto done;
                f0 = f0 * 0.5f + (float)(a0[i0 & 3u] & 255u);
                d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)l0 > (signed char)(5u >> ((unsigned)((unsigned)x0 || 0x7fffffffu) & 31u))) & 1023u);
                e0 = e0 * 0.5L + (long double)((g1 ^ (unsigned)s1) & 1023u);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(garr[i1 & 7u] && ((unsigned)(x0 >> 70) << (i1 & 31u))), (unsigned)((short)(unsigned)f0 > (signed char)(unsigned)l0), 2u); }
            if ((p1 * ((unsigned)(w0 >> 29) % ((unsigned)h0 | 1u)))) goto L0;
            g0 = (i2 * p2);
        } else {
            while (i0++ < 7u && 0xaa3d1cc8u) { if (--fuel == 0u) goto done;
                if (garr[i1 & 7u]) continue;
                if ((unsigned)((int)(v0 << (0x68c25a70u & 31u)) < (int)(unsigned)h0)) break;
            }
            while (i0++ < 5u && r0.y) { if (--fuel == 0u) goto done;
                c1 = (signed char)(garr[u2 & 7u] * (unsigned)h0);
                break; (void)(*mp);
                if ((unsigned)(m0 == (g1 - u3))) {
                    i2 = (unsigned)((int)fuel >= (int)(unsigned)(0x80000000u || (unsigned)((short)(unsigned)f0 > (signed char)0x7fffffffu))) & 15u;
                }
                *q0 = ((unsigned)((int)(unsigned)d0 >= (int)((unsigned)((int)u2 < (int)u1) | (unsigned)c1)) & 0x7fffffffu);
                break; (void)((unsigned)((unsigned)((int)g1 >= (int)0x6936a4aau) < fuel));
                if ((unsigned)!(garr[i1 & 7u] << (0xffffffffu & 31u))) {
                    do { if (--fuel == 0u) goto done;
                        switch (((unsigned)f0 * (unsigned)(7u == i0)) & 7u) {
                            case 6u: ;
                            if ((g0 % ((unsigned)(w0 >> 29) | 1u))) goto L2;
                            case 7u: ;
                            c0 = (unsigned char)(unsigned)((int)(i1 * 0xa887b610u) < (int)(unsigned)((unsigned)l0 == (unsigned)(0x10000u || 3u)));
                            if (fuel < 8u) return ((0xbd0cd23du + 7u) / ((unsigned)(4u || (0xe4da0b31u | 5u)) | 1u));
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn2((*q0 ^ ((unsigned)(x0 >> 70) - a0[i0 & 3u])), (unsigned)(p2 || (unsigned)w0), (p0 ? 0x7fffffffu : 0xffffffffu)); }
                    } while (i1++ < 2u && (unsigned)((int)(a0[i0 & 3u] % ((unsigned)c1 | 1u)) >= (int)g0));
                }
            }
            if ((r0.y >> ((i0 ^ (unsigned)f0) & 31u))) {
                if ((unsigned)(signed char)(8u | (unsigned)c1)) {
                    while (i0++ < 4u && 6u) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + ((unsigned)(u2 || fuel) & ~(1u | garr[u2 & 7u])));
                        switch ((unsigned)w0 & 7u) {
                            c0 = (unsigned char)(((unsigned)(w0 >> 29) << (0x10000u & 31u)) >> ((unsigned)(0x9f209028u < (unsigned)((unsigned)l0 < 0xaccec353u)) & 31u));
                            *q0 = u1;
                            q0 = &garr[(unsigned)(signed char)(unsigned)((8u ? (unsigned)b0 : 0x7fffffffu) && g0) & 7u];
                            case 5u: ;
                            if ((unsigned)c0) break;
                            h0 = (short)((unsigned)(short)(p2 + (unsigned)d0) + 7u);
                        }
                        i2 = 0xc3d01e60u & 15u;
                        if (garr[i1 & 7u]) goto L4;
                        if ((u2 << (((unsigned)(x0 >> 70) & 4u) & 31u))) break;
                        g1 += *mp;
                    }
                    g1 += (unsigned)((int)(unsigned)(i0 || (unsigned)c0) >= (int)0u);
                    *q0 += (unsigned)(*q0 && 0xb1a772c1u);
                    goto L4;
                } else {
                    c1 = (signed char)(unsigned)((short)i2 > (signed char)u0);
                    if (((unsigned)w0 ^ 9u)) goto L0;
                    do { if (--fuel == 0u) goto done;
                        *q0 = (0x10000u & (0x29ef0810u % ((g0 >> (9u & 31u)) | 1u)));
                    } while (i0++ < 7u && i2);
                    if ((i1 / (g1 | 1u))) goto L0;
                }
                { unsigned t6; double z6; if ((((unsigned)(p2 || (unsigned)b0) + (unsigned)h1)) & 1u) { t6 = (7u >> ((unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)s1) & 31u)); z6 = (double)(((unsigned)(u2 || (unsigned)h0)) & 255u); } if ((((unsigned)(p2 || (unsigned)b0) + (unsigned)h1)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                    u0 = u0 * 0x9e3779b1u + (unsigned)(((0xaa7f1b52u - 0xa2ca4533u) % (0x10000u | 1u)) == *mp);
                    m0 ^= (u1 | (unsigned)b0);
                    s1 = (int)((unsigned)s1 + ((0x7b4ac995u >> ((unsigned)(0x80000000u || u1) & 31u)) - (unsigned)l0));
                }
                u0 += (unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)c1);
                if (budget != 0u) { budget -= 1u; u1 = fn2((u0 >> (*q0 & 31u)), (unsigned)(*q0 == (unsigned)(v0 || (unsigned)c1)), (unsigned)((short)(unsigned)((int)g0 < (int)0x80000000u) > (signed char)fuel)); }
            } else {
                if ((a0[u1 & 3u] << (i1 & 31u))) goto L3;
                d0 = d0 * 0.5 + (double)(((unsigned)((short)6u > (signed char)(unsigned)l0) * (unsigned)s1) & 1023u);
                if (((unsigned)((int)0xf6f0a8d2u < (int)(unsigned)c0) << ((unsigned)s1 & 31u))) goto L3;
                if (budget != 0u) { budget -= 1u; u3 = fn1(6u, (u0 << (0x78dde700u & 31u)), (unsigned)((unsigned)h1 == (6u | 0x7fffffffu))); }
            }
        }
        while (i0++ < 6u && -(0x3f3257abu | (unsigned)h0)) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((0x80000000u / (g0 | 1u)) & 1023u);
                b0 = (unsigned)((int)u3 < (int)(unsigned)h1) != 0u;
                *q0 = (unsigned)((garr[i1 & 7u] << (0u & 31u)) || (unsigned)((int)*mp >= (int)u3));
                if (budget != 0u) { budget -= 1u; u1 = fn1(g0, ((unsigned)l0 + (unsigned)(r0.x == 1u)), ~(u2 ^ (u0 ^ 3u))); }
                if (0x10000u) break;
            }
            while (i1++ < 3u && ((unsigned)((int)0xffffffffu < (int)(unsigned)d0) * garr[u2 & 7u])) { if (--fuel == 0u) goto done;
                a0[u0 & 3u] = ((unsigned)(0xf7c3f8cu < 0xffffffffu) % (g0 | 1u));
            }
            { unsigned t7; double z7; if (((unsigned)(a0[i0 & 3u] && 1u)) & 1u) { t7 = 0u; z7 = (double)(((p2 >> (g1 & 31u))) & 255u); } if (((unsigned)(a0[i0 & 3u] && 1u)) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                do { if (--fuel == 0u) goto done;
                    r0.y ^= fuel;
                } while (i1++ < 7u && -(0x7fffffffu / (g1 | 1u)));
                u0 = u0 * 0x9e3779b1u + (unsigned)f0;
                *q0 = (unsigned)((short)(unsigned)w0 > (signed char)~(r0.y ^ (unsigned)c1));
                do { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        g1 += (unsigned)((int)(r0.y ^ (1u + p0)) >= (int)((unsigned)d0 << (r0.y & 31u)));
                        x0 = x0 * 0x100000001b3ull + -((garr[u2 & 7u] & g1) >> (((p1 - i1) ^ i0) & 31u));
                    }
                    break; (void)(2u);
                    if ((unsigned)(short)(unsigned)((unsigned)((int)p1 < (int)(unsigned)(w0 >> 29)) || i2)) break;
                    l0 = (long)((unsigned long)l0 + ((3u - i1) | 0x80000000u));
                    garr[(unsigned)(1u == garr[i1 & 7u]) & 7u] = (p1 % (u2 | 1u));
                } while (i1++ < 3u && (unsigned)w0);
            }
        }
    } else {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)((int)(0x299c47f5u << (fuel & 31u)) < (int)(unsigned)(unsigned char)(5u ? p0 : 7u));
            switch ((6u - a0[u1 & 3u]) & 7u) {
                if ((unsigned)((int)a0[u1 & 3u] >= (int)g1)) {
                    m0 ^= (0xffffffffu ^ (unsigned)((unsigned)b0 || (i0 / (v0 | 1u))));
                    *mp = a0[i0 & 3u];
                    if (budget != 0u) { budget -= 1u; u1 = fn0(-((unsigned)h0 * 1u), fuel, (unsigned)(0x8575cc49u || (unsigned)(garr[i1 & 7u] == 0x80000000u))); }
                    break; (void)(0x7fffffffu);
                }
                break; (void)((unsigned)h1);
                s1 = (int)((unsigned)s1 + (unsigned)(signed char)((0xffffffffu << (7u & 31u)) | (((unsigned)(w0 >> 29) ^ 0u) - (unsigned)w0)));
            }
            if ((garr[u2 & 7u] ^ (unsigned)d0)) goto L1;
            if (((unsigned)s1 / (3u | 1u))) break;
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(signed char)(unsigned)(fuel == (u3 - (unsigned)e0)), ((unsigned)l0 % ((a0[u1 & 3u] - 0xefa849f9u) | 1u)), 0xa7a046eau); }
                h0 = (short)(unsigned)(0xbe182ecfu == g0);
            }
            if (0x67541e3du) {
                while (i1++ < 7u && p2) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)x0 || (unsigned)(g1 == (unsigned)b0)), (unsigned)(u0 || *mp), 8u); }
                    *q0 += ((*mp << (0x7fffffffu & 31u)) >> ((unsigned)(short)(1u % (u3 | 1u)) & 31u));
                }
                break; (void)((unsigned)(signed char)(0x1314d71cu << (9u & 31u)));
                u1 ^= (p2 >> (((9u % ((unsigned)s1 | 1u)) % ((unsigned)c0 | 1u)) & 31u));
                b0 = (unsigned)((unsigned)((unsigned)x0 || garr[i1 & 7u]) && 2u) != 0u;
                l0 = (long)((unsigned long)l0 + 8u);
                u2 += (unsigned)((unsigned)((int)(unsigned)f0 >= (int)0x80000000u) || g1);
            } else {
                r0.x = (((unsigned)x0 ? (unsigned)w0 : (0x80000000u ^ 0x35319677u)) % (a0[u1 & 3u] | 1u));
                v0 = (unsigned)((int)((unsigned)(u3 && 0x80000000u) & 5u) < (int)0x10000u);
                l0 = (long)((unsigned long)l0 + ((unsigned)(0xa9775aa2u < (*mp & 0x7fffffffu)) / ((garr[u2 & 7u] % ((unsigned)h1 | 1u)) | 1u)));
                do { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (0x54f3d6d6u) goto L0;
                        break; (void)((unsigned)!(*mp >> (0xffffffffu & 31u)));
                        if ((unsigned)(p0 == (unsigned)((int)(unsigned)c0 >= (int)u2))) goto L2;
                    }
                    if ((unsigned)s0) break;
                    r0.x = (unsigned)((short)(unsigned)(short)(u1 / (u0 | 1u)) > (signed char)(unsigned)((unsigned)h0 == 5u));
                } while (i1++ < 2u && (unsigned)d0);
            }
        }
    }
    *q0 = 0x4d25c836u;
    if (budget != 0u) { budget -= 1u; u0 = fn0(p0, v0, 0xe0781ee9u); }
    garr[-((unsigned)d0 | 0x4f05d45eu) & 7u] = (unsigned)(unsigned char)(unsigned)((short)(unsigned)x0 > (signed char)a0[i0 & 3u]);
    if (((0xffffffffu | (unsigned)e0) + garr[i1 & 7u])) goto L0;
    do { if (--fuel == 0u) goto done;
        if ((m0 - u1)) goto L4;
        b0 = (unsigned)((unsigned)((0x7fffffffu * 0xb1989e60u) < garr[i1 & 7u]) == 2u) != 0u;
        s1 = (int)((unsigned)s1 + (unsigned)(((unsigned)x0 + (unsigned)((unsigned)e0 || (unsigned)f0)) && 0xffffffffu));
        if ((unsigned)((short)9u > (signed char)((unsigned)l0 / (m0 | 1u)))) {
            if (((m0 / (0x10000u | 1u)) ^ garr[i1 & 7u])) break;
            l0 = (long)((unsigned long)l0 + (0x471c3e6cu % ((2u + (i1 ? 0x10000u : 0x80d03da0u)) | 1u)));
            b0 = ((unsigned)((int)8u >= (int)(unsigned)e0) + ((unsigned)f0 * p2)) != 0u;
        } else {
            h0 = (short)((unsigned)h0 | garr[u2 & 7u]);
            if ((unsigned)((short)(unsigned)s0 > (signed char)i1)) goto L4;
            r0.x = 4u;
            switch ((fuel * ~((unsigned)c1 << (r0.x & 31u))) & 7u) {
                c0 = (unsigned char)fuel;
                garr[p0 & 7u] = (unsigned)((0x80000000u + 0x3456b284u) && u2);
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (0xf7fa16b0u) continue;
                    if (~(m0 | (unsigned)(0xe7139640u == p2))) continue;
                }
                h0 = (short)(unsigned)((unsigned)((int)(unsigned)c1 >= (int)(unsigned)((int)r0.y >= (int)0x7fffffffu)) == 0x80000000u);
            }
        }
        r0.y ^= p1;
    } while (i0++ < 7u && ((unsigned)(signed char)(p0 / (0x1a915d6u | 1u)) >> ((unsigned)h1 & 31u)));
    if ((unsigned)(short)((unsigned)c0 ^ p0)) {
        u0 = (unsigned)((int)(unsigned)c0 < (int)(unsigned)x0);
        goto done;
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            b0 = (unsigned)((4u ? u1 : 4u) && (unsigned)c0) != 0u;
            if ((unsigned)((unsigned)w0 || (unsigned)h0)) {
                break; (void)((((unsigned)s1 % (p2 | 1u)) | 4u));
                g0 = (7u >> ((unsigned)e0 & 31u));
                switch ((m0 % (2u | 1u)) & 7u) {
                    case 3u: ;
                    case 1u: ;
                    if (budget != 0u) { budget -= 1u; u3 = fn2((1u ^ (unsigned)(*mp < r0.y)), (p2 ^ garr[i1 & 7u]), 0x1f4ac45au); }
                    if ((g0 ^ ((unsigned)d0 | p0))) goto L0;
                    m0 ^= (unsigned)(0x7fffffffu && 9u);
                    case 0u: ;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn2((i0 >> (a0[i0 & 3u] & 31u)), (5u >> ((0x10000u / (0x10000u | 1u)) & 31u)), (unsigned)((int)u1 < (int)6u)); }
                r0.x = (unsigned)h1;
                w0 = w0 * 6364136223846793005ull + (9u + 0x10000u);
            }
            c1 = (signed char)u1;
            { unsigned t8; double z8; if (((0x9a6dac88u - (unsigned)h1)) & 1u) { t8 = i0; z8 = (double)(((unsigned)((unsigned)!(unsigned)((short)p0 > (signed char)(unsigned)h1) < p2)) & 255u); } if (((0x9a6dac88u - (unsigned)h1)) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                r0.x = 0x56dc045bu;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((fuel % (m0 | 1u)), (unsigned)((unsigned)w0 && g0), ~(unsigned)((unsigned)h1 == *q0)); }
                    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)x0 == ((unsigned)(u3 == r0.x) | (7u * r0.y)));
                    while (i2++ < 4u && (unsigned)((int)((unsigned)s1 - i1) < (int)0x1fc736d1u)) { if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)(signed char)((unsigned)w0 >> ((unsigned)((short)i2 > (signed char)u3) & 31u)) || -((unsigned)d0 | 0x99ed0215u));
                    }
                } while (i1++ < 2u && (u0 + m0));
                { unsigned t9; double z9; if ((u0) & 1u) { t9 = ((unsigned)s1 / ((unsigned)(i0 || p1) | 1u)); z9 = (double)(((unsigned)e0) & 255u); } if ((u0) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
                    break; (void)(~((unsigned)f0 ^ u0));
                    if (u3) break;
                }
            }
        }
    } else {
        if (0xffffffffu) goto done;
    }
    { unsigned t10; double z10; if (((g0 / (garr[i1 & 7u] | 1u))) & 1u) { t10 = (unsigned)(signed char)(unsigned)(p2 && 0x7fffffffu); z10 = (double)(((unsigned)((unsigned)(r0.x && (unsigned)h1) || (unsigned)d0)) & 255u); } if (((g0 / (garr[i1 & 7u] | 1u))) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
        *mp = (7u & garr[i1 & 7u]);
    }
    if (0x2c646d2cu) goto L4;
    r0.y ^= (unsigned)(unsigned char)(unsigned)((0xbad9fc6du << ((unsigned)e0 & 31u)) || fuel);
    if (-(p2 % ((unsigned)s1 | 1u))) goto L4;
    w0 = w0 * 6364136223846793005ull + (garr[u2 & 7u] ? (u0 ^ (unsigned)c0) : (unsigned)x0);
    goto L1;
    x0 = x0 * 0x100000001b3ull + (r0.x | (unsigned)b0);
    *q0 += (garr[i1 & 7u] ? p2 : (3u / ((unsigned)((int)p2 >= (int)p2) | 1u)));
    r0.y ^= (unsigned)(short)((unsigned)((unsigned)b0 < (unsigned)c1) * (unsigned)(*q0 && (6u / ((unsigned)(x0 >> 70) | 1u))));
    if (budget != 0u) { budget -= 1u; u0 = fn0(((i2 << (i2 & 31u)) + garr[i1 & 7u]), u2, (0xffffffffu >> (~(v0 | (unsigned)s1) & 31u))); }
    switch ((unsigned)(p0 && (unsigned)(g0 && 9u)) & 7u) {
        if ((unsigned)l0) {
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1(0xffffffffu, (unsigned)((unsigned)c0 && (unsigned)(0xffffffffu < 7u)), ((unsigned)(p0 || u0) ^ 0x23b7f504u)); }
            } while (i0++ < 5u && p2);
            if (budget != 0u) { budget -= 1u; u1 = fn1((u2 >> (g1 & 31u)), 0x10000u, (unsigned)c1); }
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)(p1 == i2) > (signed char)u0), ((unsigned)b0 / (i2 | 1u)), (unsigned)((unsigned)c0 || 0x7e941a05u)); }
                s1 = (int)((unsigned)s1 + (unsigned)(0x6d6267eeu && 8u));
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)v0 > (signed char)0xffffffffu);
            }
            case 7u: ;
            if ((unsigned)s0) goto L2;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)w0, 1u, (-((unsigned)x0 >> (1u & 31u)) ^ p1)); }
        }
    }
    r0.x = (((unsigned)(0x10000u || (unsigned)f0) | garr[u2 & 7u]) ^ ((unsigned)c1 & 1u));
    if ((unsigned)(u0 == u3)) goto L3;
    u2 ^= (u3 * (unsigned)e0);
    for (;;) { if (--fuel == 0u) goto done;
        h0 = (short)(4u | (unsigned)((unsigned)s0 && i1));
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i2) { if (--fuel == 0u) goto done;
            continue; (void)(((unsigned)(short)(unsigned)(*mp == 5u) >> ((unsigned)e0 & 31u)));
            break; (void)((unsigned)((unsigned)(0x80000000u < (unsigned)l0) || 2u));
            u3 += (((unsigned)((short)u0 > (signed char)*q0) >> (r0.y & 31u)) & g1);
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)*mp > (signed char)*mp), (unsigned)x0, (v0 * (2u << (v0 & 31u)))); }
            while (i2++ < 5u && (0x1d33daa1u | 3u)) { if (--fuel == 0u) goto done;
                if ((0x9b2aecf5u << ((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)w0) & 31u))) {
                    v0 = i1;
                    d0 = d0 * 0.5 + (double)((0xf9cfc5cu << (p1 & 31u)) & 1023u);
                    if (1u) continue;
                } else {
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(p1 && 0xb02dc023u) ^ 2u), (unsigned)(7u < 3u), ((unsigned)(x0 >> 70) | (unsigned)w0)); }
                    b0 = g0 != 0u;
                    garr[0x22912be7u & 7u] = (unsigned)((p1 * (unsigned)(x0 >> 70)) && (unsigned)((int)(unsigned)(w0 >> 29) < (int)0x7fffffffu));
                    if (*mp) break;
                }
                *mp = (unsigned)((int)u3 < (int)a0[i0 & 3u]);
            }
            w0 ^= (unsigned long long)(unsigned)!(unsigned)((unsigned)h1 && (unsigned)(x0 >> 70)) << ((a0[i0 & 3u] / ((unsigned)l0 | 1u)) & 63u);
        }
        u1 = (garr[i1 & 7u] - ((8u / ((unsigned)h1 | 1u)) - r0.y));
        if ((unsigned)l0) break;
        do { if (--fuel == 0u) goto done;
            break; (void)(((unsigned)d0 - p2));
        } while (i1++ < 7u && ((a0[u1 & 3u] - p0) % (a0[u1 & 3u] | 1u)));
        break; (void)((unsigned)(short)(unsigned)((short)r0.x > (signed char)fuel));
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(i1 || 0x80000000u), p2, (m0 ? p2 : a0[u1 & 3u])); }
    h0 = (short)(6u | p0);
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)9u < (int)u0), ((unsigned)l0 >> ((unsigned)e0 & 31u)), (unsigned)(8u < (a0[i0 & 3u] / (r0.y | 1u)))); }
    if ((unsigned)((int)(unsigned)l0 < (int)0x80000000u)) {
        if (fuel) goto L1;
        if (budget != 0u) { budget -= 1u; u1 = fn2((0x7fffffffu ? (unsigned)b0 : r0.x), (*mp / (((unsigned)h0 | u3) | 1u)), i2); }
        if (0x99bed2bu) goto done;
    } else {
        if (budget != 0u) { budget -= 1u; u1 = fn0(0xb576c766u, (p0 * *q0), (unsigned)((unsigned)((int)0x7fffffffu >= (int)(unsigned)(w0 >> 29)) || 0x3f3a7c62u)); }
        h0 = (short)a0[u1 & 3u];
        garr[a0[u1 & 3u] & 7u] = (unsigned)(i0 == u1);
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)9u)) break;
        }
    }
    if ((unsigned)(2u && (unsigned)(w0 >> 29))) goto L3;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 += (unsigned)((unsigned)(signed char)(((unsigned)x0 << (fuel & 31u)) ^ r0.x) && ((unsigned)l0 - i2));
        garr[8u & 7u] = ((0x7fffffffu | 1u) ^ ((unsigned)c1 | (unsigned)(short)(0x2c4cdcb7u | (unsigned)x0)));
    }
    s0 = (int)(1u * ((unsigned)((int)0x89962f3au >= (int)0u) << ((unsigned)s0 & 31u)));
    do { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)((short)-((unsigned)s1 & (r0.y & (unsigned)d0)) > (signed char)(unsigned)c1));
    } while (i0++ < 7u && (a0[i0 & 3u] / ((r0.y & 0x67fbd562u) | 1u)));
    u0 += garr[u2 & 7u];
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((-(p2 + (unsigned)e0) >> (((unsigned)(u2 == 2u) * 0x7fffffffu) & 31u)) & 1023u);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    s0 = (int)~(((unsigned)x0 | 0x7f79fcf0u) << ((unsigned)(0x7fffffffu < (unsigned)d0) & 31u));
    if ((unsigned)((4u << (r0.y & 31u)) == 0xffffffffu)) goto L4;
    f0 = f0 * 0.5f + (float)(6u & 255u);
    do { if (--fuel == 0u) goto done;
        break; (void)(r0.x);
        if ((unsigned)(0xd2b734abu < u2)) {
            if (budget != 0u) { budget -= 1u; u2 = fn1(((i2 >> (0xffffffffu & 31u)) / ((unsigned)h1 | 1u)), (0xae3b4037u ? 6u : fuel), ((unsigned)((unsigned)l0 || 0x7fffffffu) << (p2 & 31u))); }
            *mp = ((unsigned)(signed char)(unsigned)((short)(unsigned)f0 > (signed char)(7u ^ p1)) * (0x7fffffffu & i2));
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)h1 ^ (unsigned)((unsigned)s1 && (unsigned)e0))) break;
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(w0 >> 29) == m0), (unsigned)(0xffffffffu || u3), (7u % ((unsigned)d0 | 1u))); }
                    h1 = (unsigned short)(h1 + ((unsigned)((short)0x10000u > (signed char)(unsigned)b0) - p2));
                    w0 ^= (unsigned long long)(u2 ^ garr[u2 & 7u]) << (m0 & 63u);
                }
                if ((unsigned)(4u && (0xb0e5351u ^ 0xaf31691cu))) break;
                r0.y ^= (unsigned)(((a0[u1 & 3u] << (0xffffffffu & 31u)) * u1) == ((unsigned)s0 ^ i2));
                u1 ^= 0x50da021cu;
                *mp = (g1 ? 0xffffffffu : fuel);
            }
            break; (void)((unsigned)(u1 || (unsigned)((int)a0[i0 & 3u] < (int)garr[u2 & 7u])));
        }
        for (;;) { if (--fuel == 0u) goto done;
            u1 ^= -(((unsigned)l0 / ((0x10000u - (unsigned)s1) | 1u)) * 0x7fffffffu);
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)((int)(unsigned)(x0 >> 70) < (int)9u), 5u, (2u - (unsigned)((unsigned)c0 == (unsigned)h0))); }
            L0: if (--fuel == 0u) goto done;
        }
        switch ((unsigned)((short)0x79cdae43u > (signed char)(r0.x / ((unsigned)(w0 >> 29) | 1u))) & 7u) {
            L1: if (--fuel == 0u) goto done;
            if (2u) {
                if ((unsigned)!(0x10000u / ((unsigned)x0 | 1u))) goto L3;
                if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)c0 | i1), (unsigned)((unsigned)h1 == u0), ((unsigned)((unsigned)f0 < p0) % ((unsigned)d0 | 1u))); }
                goto L1;
            } else {
                do { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (*mp / ((unsigned)(x0 >> 70) | 1u)));
                } while (i1++ < 2u && (unsigned)((int)(unsigned)w0 >= (int)0x80000000u));
                if (budget != 0u) { budget -= 1u; u2 = fn1(r0.y, m0, (unsigned)(p2 && 7u)); }
            }
            for (;;) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((((unsigned)h1 / (0x7fffffffu | 1u)) << ((unsigned)(unsigned char)(unsigned)(a0[i0 & 3u] && (r0.y + 0xffffffffu)) & 31u)) & 255u);
                    if ((0x7fffffffu ^ ~(0x80000000u / (0x10000u | 1u)))) break;
                    c1 = (signed char)(r0.x ? (unsigned)s0 : (unsigned)b0);
                    r0.y ^= (i1 % ((v0 | (unsigned)(i1 < m0)) | 1u));
                    if (2u) goto L4;
                    case 5u: ;
                } while (i2++ < 7u && (unsigned)((unsigned)f0 || r0.x));
                u3 = u3 * 0x9e3779b1u + (u1 >> ((unsigned)(0x7fffffffu && 0x10000u) & 31u));
                u3 = u3 * 0x9e3779b1u + (0xffffffffu ? (0x80000000u & v0) : (unsigned)(x0 >> 70));
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)(u3 == fuel)) break;
                    L2: if (--fuel == 0u) goto done;
                }
                garr[0xb060c1f6u & 7u] = (unsigned)!(u0 ? (unsigned)c1 : (unsigned)h1);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)r0.x > (signed char)(unsigned)e0), (unsigned)d0, (unsigned)c1); }
            }
            switch (~(unsigned)(p1 && ((unsigned)f0 & (unsigned)s0)) & 7u) {
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    switch ((unsigned)!((r0.y + g0) | (unsigned)c1) & 7u) {
                        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(7u || u3), (i0 % ((unsigned)(0x7fffffffu && (unsigned)h0) | 1u)), (unsigned)((short)u1 > (signed char)(a0[i0 & 3u] / (i0 | 1u)))); }
                        *mp = (unsigned)((short)(unsigned)e0 > (signed char)2u);
                        L3: if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((0xde5b4678u << (u3 & 31u)) && p1), (0xffffffffu ^ 0xb6df9bccu), (((unsigned)(w0 >> 29) & u3) % (r0.y | 1u))); }
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)*mp < (int)garr[i1 & 7u]), (unsigned)(unsigned char)(2u * r0.x), u3); }
                        while (i2++ < 7u && (unsigned)((unsigned)s0 || u2)) { if (--fuel == 0u) goto done;
                            m0 ^= (unsigned)((int)i0 >= (int)u3);
                            case 3u: ;
                            u3 = (fuel >> (*mp & 31u));
                            L4: if (--fuel == 0u) goto done;
                            f0 = f0 * 0.5f + (float)(*mp & 255u);
                            if (*q0) break;
                        }
                    }
                }
            }
            default: ;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)e0, (v0 ^ 4u), r0.x); }
    } while (i0++ < 7u && (unsigned)(garr[i1 & 7u] == (unsigned)x0));
    if ((unsigned)(p1 && (unsigned)(u1 || *mp))) goto L1;
    if (budget != 0u) { budget -= 1u; u0 = fn2(i0, ((unsigned)w0 >> ((unsigned)x0 & 31u)), ((unsigned)e0 << (r0.y & 31u))); }
    if (0xf5ba0eeau) goto L4;
    if (budget != 0u) { budget -= 1u; u2 = fn0(~(unsigned)((int)a0[i0 & 3u] < (int)(unsigned)w0), ((unsigned)s1 << (7u & 31u)), (unsigned)(a0[u1 & 3u] == (0x4c39329au | 0x9224eef3u))); }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)u3 < (int)(unsigned)((short)(unsigned)h1 > (signed char)garr[i1 & 7u])), (unsigned)(0xffffffffu < (unsigned)((int)(unsigned)b0 >= (int)i1)), (unsigned)(unsigned char)(u3 / ((unsigned)(v0 == a0[i0 & 3u]) | 1u))); }
    goto L2;
    if (-((unsigned)(x0 >> 70) + 0xf481cab0u)) goto done;
    s0 = (int)(*mp ? 7u : ((unsigned)((int)i0 >= (int)(unsigned)w0) | i2));
    b0 = (unsigned)(short)(i1 + (unsigned)((short)0x3f4fd696u > (signed char)(unsigned)(0x10000u < 0x80000000u))) != 0u;
    if ((unsigned)s1) goto L3;
    switch ((unsigned)(u2 < g1) & 7u) {
        c1 = (signed char)(unsigned)((int)u2 < (int)((unsigned)((int)u0 < (int)v0) / ((0x80000000u - (unsigned)c0) | 1u)));
    }
    goto L2;
    l0 = (long)((unsigned long)l0 + (0xffffffffu + 1u));
    goto done;
    if ((unsigned)(2u || (unsigned)(x0 >> 70))) {
        u0 = (unsigned)((short)r0.x > (signed char)(unsigned)(x0 >> 70));
        if ((unsigned)((int)((unsigned)(x0 >> 70) * (unsigned)b0) < (int)u0)) goto done;
    }
    if (p1) {
        if ((unsigned)(p1 || (unsigned)s1)) {
            g0 = (((unsigned)d0 >> (0x80000000u & 31u)) % (2u | 1u));
            if ((unsigned)h1) {
                w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(unsigned)((short)(u0 + 0x80000000u) > (signed char)((unsigned)s0 % (0x10000u | 1u)));
                r0.y ^= (v0 | (a0[i0 & 3u] ? ((unsigned)w0 ^ i1) : 0x7ba0f21u));
                b0 = (unsigned)!((unsigned)s0 * (unsigned)((short)(unsigned)((int)(unsigned)d0 < (int)0xffffffffu) > (signed char)0xffffffffu)) != 0u;
                goto L2;
                if ((unsigned)((int)a0[i0 & 3u] < (int)0x80000000u)) goto L3;
                m0 ^= ((0xffffffffu << ((unsigned)h1 & 31u)) * p0);
            }
            r0.y ^= m0;
            c0 = (unsigned char)0x80000000u;
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)(w0 >> 29) && (unsigned)h1)) goto L4;
            }
        } else {
            i0 = (a0[u1 & 3u] - 0x80000000u) & 15u;
            if ((unsigned)((int)-(i0 * 0x78c15e5eu) < (int)(unsigned)h0)) goto L0;
            s1 = (int)((unsigned)s1 + (0x7c6ddd04u >> (-(unsigned)((unsigned)(2u || 0x8c5cf7afu) && (m0 >> (i0 & 31u))) & 31u)));
        }
        switch ((fuel | 3u) & 7u) {
            case 2u: ;
            switch ((0x7fffffffu / ((unsigned)s0 | 1u)) & 7u) {
                case 7u: ;
                d0 = d0 * 0.5 + (double)(((0x4e55d9d8u & a0[i0 & 3u]) + ((unsigned)h1 + *q0)) & 1023u);
                if (((unsigned)(a0[i0 & 3u] && (unsigned)x0) + 0x10000u)) break;
                m0 ^= ((unsigned)f0 * (unsigned)((unsigned)h0 < i0));
            }
            if (fuel) goto done;
            garr[0x7fffffffu & 7u] = (unsigned)((0x80000000u / (i2 | 1u)) && 0xffffffffu);
        }
        u0 ^= ((0x77f03a40u >> ((unsigned)b0 & 31u)) + r0.y);
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)h0, -(garr[u2 & 7u] ^ (unsigned)x0), -(unsigned)((short)*mp > (signed char)*mp)); }
        }
    } else {
        do { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)((u1 - 0xfb318378u) || (unsigned)e0) >> (1u & 31u)) < (int)6u));
            g1 += (unsigned)(((a0[i0 & 3u] ? 0x8eedf8d0u : m0) | (unsigned)s0) < 0x10000u);
            while ((2u + (unsigned)((unsigned)d0 && p0))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(0x10000u, (unsigned)s1, 0x9c2c782cu); }
                if (((unsigned)(unsigned char)(g0 / (5u | 1u)) * v0)) continue;
                if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)(6u < a0[u1 & 3u]) < (int)0x53c53cc5u)) break;
                *mp = ((fuel >> (7u & 31u)) / ((garr[i1 & 7u] % ((0x10000u * 0x80000000u) | 1u)) | 1u));
                q0 = &garr[(5u >> ((unsigned)h1 & 31u)) & 7u];
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)((int)3u < (int)(unsigned)(x0 >> 70)) || p1), 0x9495b65du, (unsigned)((int)i1 < (int)0x7fffffffu)); }
            }
        } while (i0++ < 5u && (r0.y + (unsigned)((int)0x10000u >= (int)(unsigned)(x0 >> 70))));
    }
    if ((unsigned)(short)((unsigned)s0 | (r0.y & 0x3328a2e2u))) goto L1;
    { unsigned t0; double z0; if ((-(unsigned)((unsigned)(w0 >> 29) < (unsigned)c0)) & 1u) { t0 = (unsigned)((unsigned)w0 || 0x10000u); z0 = (double)(((unsigned)(v0 && (unsigned)(v0 == p0))) & 255u); } if ((-(unsigned)((unsigned)(w0 >> 29) < (unsigned)c0)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        u2 = (unsigned)((int)0xdc49c16au < (int)2u);
        f0 = f0 * 0.5f + (float)(((unsigned)(0u == (unsigned)((short)(unsigned)h1 > (signed char)i1)) + garr[i1 & 7u]) & 255u);
        d0 = d0 * 0.5 + (double)(4u & 1023u);
        *mp = (unsigned)(g1 && (unsigned)(signed char)(a0[i0 & 3u] & r0.y));
    }
    r0.x = (0x54e2d176u ^ ((v0 - 8u) / ((unsigned)(0x5f26228au == u3) | 1u)));
    while (i0++ < 2u && ((unsigned)b0 ? (unsigned)w0 : (unsigned)x0)) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            garr[(a0[i0 & 3u] % (6u | 1u)) & 7u] = ((0x74865d79u * garr[i1 & 7u]) * 0xffffffffu);
            while ((a0[u1 & 3u] / (i0 | 1u))) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)(g0 < (unsigned)b0) & 255u);
                while (i0++ < 3u && (unsigned)(i1 || 0xb1353494u)) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)(unsigned)s1 < (int)(0xe51ff5ecu | (unsigned)b0))) break;
                    i0 = (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(9u ^ (unsigned)c1)) & 15u;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)c0, a0[i0 & 3u], ((unsigned)x0 >> (7u & 31u))); }
                }
                d0 = d0 * 0.5 + (double)((((unsigned)((unsigned)d0 && 0xdb01155fu) << ((unsigned)b0 & 31u)) ? u0 : (unsigned)f0) & 1023u);
                if (((unsigned)(x0 >> 70) * (unsigned)w0)) break;
                if (u3 == 7u) return (unsigned)((short)((unsigned)((unsigned)(w0 >> 29) || 0u) >> ((unsigned)e0 & 31u)) > (signed char)(unsigned)((unsigned)x0 == *mp));
            }
            for (;;) { if (--fuel == 0u) goto done;
                if (((unsigned)f0 + u3)) break;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)c1, (unsigned)(0x7fffffffu == p2), (unsigned)((u1 * u2) < u3)); }
            }
            if (((unsigned)((int)(unsigned)h0 < (int)a0[u1 & 3u]) / (fuel | 1u))) break;
            f0 = f0 * 0.5f + (float)((unsigned)(u2 || (unsigned)(signed char)(*q0 >> (garr[i1 & 7u] & 31u))) & 255u);
            if ((unsigned)((short)fuel > (signed char)0x9cdf42e8u)) break;
        } while (i1++ < 2u && (unsigned)((unsigned)w0 || (3u % (0x5a01ce98u | 1u))));
        u3 = u3 * 0x9e3779b1u + (unsigned)(8u == p2);
    }
    h0 = (short)(unsigned)s0;
    a0[(unsigned)(0xa554d249u || (unsigned)h0) & 3u] = i1;
    if (r0.x) goto L3;
    m0 ^= (unsigned)(u3 < (unsigned)f0);
    g0 = (unsigned)(short)(0x10000u - r0.x);
    *mp = (unsigned)(0x80000000u || ~(u2 ? (unsigned)(unsigned char)(fuel * 1u) : (unsigned)w0));
    do { if (--fuel == 0u) goto done;
        v0 = (6u | v0);
    } while (i0++ < 2u && u0);
    while (i0++ < 4u && (unsigned)((unsigned)e0 && (unsigned)b0)) { if (--fuel == 0u) goto done;
        if (-(unsigned)(u2 == (2u & (unsigned)d0))) break;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 7u, 0xfcb3c728u, 0xf8091df0u },
        { 14u, 0x75e3c535u, 0x464ac5bu },
        { 10u, 0x69789846u, 0x23ff268eu },
        { 3u, 0xc806f2eu, 0xa69c178du },
        { 0u, 0x2247ab1au, 0xd4736f17u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
