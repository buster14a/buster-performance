// test-ssa-source's program of seed 134000448 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x431a501cu, g1 = 0x6ac1c7e2u;
static unsigned garr[8] = { 0xd05f062au, 0x38e5db41u, 0xdac8ae63u, 0x159501cbu, 0x961ac930u, 0x9498a748u, 0xce7c34bfu, 0x7a93e0ceu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    d0 = d0 * 0.5 + (double)((unsigned)h0 & 1023u);
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (m0 % ((unsigned)((short)5u > (signed char)(unsigned)e0) | 1u));
        a0[(unsigned)((short)(unsigned)w0 > (signed char)5u) & 3u] = ((unsigned)((int)1u >= (int)garr[u2 & 7u]) >> ((unsigned)((short)g0 > (signed char)(unsigned)(a0[i0 & 3u] || 0xe3b40ebu)) & 31u));
        b0 = ((unsigned)l0 % (0xffffffffu | 1u)) != 0u;
        L0: if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (a0[i0 & 3u] + 0x38254543u));
        }
    }
    if (((unsigned)s1 + fuel)) goto done;
    if ((unsigned)(0x7fffffffu < (unsigned)(x0 >> 70))) {
        L1: if (--fuel == 0u) goto done;
        m0 ^= a0[u1 & 3u];
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)(signed char)(unsigned)(m0 < 4u);
            if (((unsigned)(3u == 0x2a80f019u) / (u0 | 1u))) {
                w0 ^= (unsigned long long)p1 << ((((unsigned)((short)r0.y > (signed char)fuel) & p1) & (i1 * g0)) & 63u);
                L2: if (--fuel == 0u) goto done;
                u1 += (unsigned)(p0 && 5u);
            }
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                b0 = (unsigned)((unsigned)e0 && r0.y) != 0u;
                break; (void)((unsigned)((int)0xd870f78bu < (int)(unsigned)h1));
                break; (void)((unsigned)((short)0x6bbce07du > (signed char)((unsigned)f0 & g1)));
                i1 = (p2 * g0) & 15u;
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                    *q0 = (u0 ^ u3);
                    c0 = (unsigned char)((8u - (u1 + (unsigned)!(unsigned)((unsigned)x0 && i2))) - i2);
                    w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)e0 > (signed char)((0x34d2cd16u >> (u2 & 31u)) ? 8u : u0));
                    u1 ^= ((unsigned)((int)(unsigned)d0 >= (int)fuel) * 0x7efeca4fu);
                }
                h1 = (unsigned short)(h1 + ((0x10000u / ((unsigned)s0 | 1u)) + -(unsigned)((int)0xf04f7a73u >= (int)p2)));
            }
            do { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (i2 % (-(9u >> ((unsigned)(signed char)(unsigned)(0x10000u == a0[i0 & 3u]) & 31u)) | 1u));
                w0 = w0 * 6364136223846793005ull + (u3 | ((unsigned)h0 + (r0.x | (0x8029dec0u / ((unsigned)c1 | 1u)))));
            } while (i1++ < 4u && (unsigned)((u1 | (unsigned)w0) == 7u));
            if ((unsigned)((unsigned)(w0 >> 29) == g1)) break;
        }
        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(unsigned)((int)p2 < (int)p2) & 1023u);
        for (;;) { if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
        }
        u0 ^= (0x8cfb0720u - (*q0 | r0.y));
    } else {
        e0 = e0 * 0.5L + (long double)(((unsigned)(p0 || (unsigned)w0) * ((unsigned)(x0 >> 70) % (0x5ac7a98cu | 1u))) & 1023u);
        if (((unsigned)c0 ^ 0x10000u)) goto done;
        r0.y ^= (unsigned)(i1 || ((unsigned)(m0 < (unsigned)e0) & (unsigned)(w0 >> 29)));
        if (r0.y) goto L2;
    }
    goto L0;
    if ((u2 % ((unsigned)(x0 >> 70) | 1u))) goto L4;
    do { if (--fuel == 0u) goto done;
        if (((unsigned)h0 - i0)) {
            if ((unsigned)(signed char)((unsigned)(x0 >> 70) * (unsigned)h0)) break;
            if ((unsigned)!(m0 - *mp)) break;
            if (((unsigned)s1 / ((unsigned)(short)((unsigned)w0 % (0u | 1u)) | 1u))) break;
            if ((unsigned)s0) break;
        } else {
            q0 = &garr[(unsigned)((int)(unsigned)c0 >= (int)(unsigned)l0) & 7u];
        }
        if (((i1 << (*mp & 31u)) << (u1 & 31u))) break;
        i2 = (fuel | ((unsigned)((u2 + 0x7fffffffu) && fuel) * (unsigned)(x0 >> 70))) & 15u;
        { unsigned t0; double z0; if (((u2 / (a0[i0 & 3u] | 1u))) & 1u) { t0 = (unsigned)(i2 == (8u / (i2 | 1u))); z0 = (double)((0xa3f8f9d4u) & 255u); } if (((u2 / (a0[i0 & 3u] | 1u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            *q0 += (unsigned)(0xffffffffu < (0x79460801u / ((unsigned)s1 | 1u)));
            h0 = (short)~(0x2ec72a62u | ((unsigned)(x0 >> 70) & 0x3da782bfu));
        }
        u3 += (unsigned)(signed char)(unsigned)((int)(unsigned)(m0 == 1u) >= (int)((unsigned)f0 << (a0[i0 & 3u] & 31u)));
    } while (i0++ < 7u && (unsigned)((unsigned)(x0 >> 70) == (8u - 0xffffffffu)));
    goto L0;
    if (((unsigned)s1 ^ ((unsigned)s1 & (unsigned)l0))) goto L2;
    { unsigned t1; double z1; if ((fuel) & 1u) { t1 = (unsigned)((short)0x10000u > (signed char)(unsigned)((int)(unsigned)e0 < (int)garr[u2 & 7u])); z1 = (double)(((unsigned)(fuel && g0)) & 255u); } if ((fuel) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        c1 = (signed char)((unsigned)s1 * (unsigned)l0);
    }
    switch ((unsigned)(u1 || a0[u1 & 3u]) & 7u) {
        m0 ^= (unsigned)((int)(unsigned)h0 < (int)((garr[i1 & 7u] | (unsigned)f0) >> (r0.x & 31u)));
        d0 = d0 * 0.5 + (double)((a0[i0 & 3u] ? (unsigned)x0 : a0[u1 & 3u]) & 1023u);
        case 3u: ;
        c0 = (unsigned char)((5u << (p0 & 31u)) ^ p0);
        goto L3;
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)*q0 >= (int)0x2f4f4f10u)) break;
        c0 = (unsigned char)((unsigned)s0 >> (((unsigned)(u3 == (unsigned)s1) ^ (i2 / (3u | 1u))) & 31u));
        { unsigned t2; double z2; if ((((unsigned)((int)i0 >= (int)p0) / (9u | 1u))) & 1u) { t2 = (unsigned)((unsigned)h1 || (unsigned)c0); z2 = (double)(((0x8cadd5b5u ^ (garr[u2 & 7u] / (p2 | 1u)))) & 255u); } if ((((unsigned)((int)i0 >= (int)p0) / (9u | 1u))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            if (((unsigned)(w0 >> 29) % (a0[u1 & 3u] | 1u))) break;
            if (((unsigned)(m0 < (unsigned)e0) ^ 2u)) break;
            break; (void)((unsigned)((g0 % ((unsigned)w0 | 1u)) || u3));
            if ((garr[u2 & 7u] << (0xa9194776u & 31u))) break;
            { unsigned t3; double z3; if (((unsigned)!(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)s0)) & 1u) { t3 = (unsigned)((int)u3 >= (int)(g1 % (0x8bff411du | 1u))); z3 = (double)(((u3 / ((u0 & 0u) | 1u))) & 255u); } if (((unsigned)!(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)s0)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                s0 = (int)(unsigned)s1;
                u3 = u3 * 0x9e3779b1u + ((unsigned)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)c1) < *mp) + (u0 >> (m0 & 31u)));
            }
            goto L0;
        }
        switch ((unsigned)s1 & 7u) {
            if ((0x80000000u ? (unsigned)f0 : garr[i1 & 7u])) {
                if (((unsigned)x0 & i0)) {
                    if (*q0) continue;
                    switch (g0 & 7u) {
                        if ((unsigned)s0) {
                            case 5u: ;
                            case 3u: ;
                            u3 = u3 * 0x9e3779b1u + p1;
                            g1 += (unsigned)(u1 == (unsigned)c0);
                            s1 = (int)((unsigned)s1 + (a0[i0 & 3u] - (unsigned)((unsigned)f0 || u3)));
                            s0 = (int)(unsigned)(-((unsigned)(*q0 || (unsigned)(w0 >> 29)) + ((unsigned)s1 % (i0 | 1u))) && (unsigned)e0);
                        }
                    }
                    case 7u: ;
                    if ((unsigned)(0x97587cecu < ((unsigned)l0 | r0.x))) continue;
                } else {
                    case 2u: ;
                }
                case 6u: ;
                g0 = (unsigned)(1u && 0xacecfb0fu);
            } else {
                if ((9u & 9u)) goto L2;
            }
            { unsigned t4; double z4; if (((((unsigned)d0 >> (*mp & 31u)) - u3)) & 1u) { t4 = ((unsigned)((short)u1 > (signed char)m0) ^ (unsigned)h1); z4 = (double)(((u2 >> ((unsigned)x0 & 31u))) & 255u); } if (((((unsigned)d0 >> (*mp & 31u)) - u3)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                if ((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)((unsigned)h0 && g1))) {
                    case 3u: ;
                    l0 = (long)((unsigned long)l0 + (unsigned)(((i2 + 0x10000u) * garr[i1 & 7u]) < (g1 ^ (unsigned)(x0 >> 70))));
                }
                l0 = (long)((unsigned long)l0 + (unsigned)(short)(u1 ^ (unsigned)((int)0x10000u < (int)-(3u ^ (u2 - 0x7fffffffu)))));
            }
            *mp = ((r0.y % (1u | 1u)) >> (0xdc528afdu & 31u));
        }
        s0 = (int)(*mp >> (a0[u1 & 3u] & 31u));
    }
    *mp = (unsigned)!(u1 % (g0 | 1u));
    goto done;
    if ((u2 ^ (0x1ed1f2d1u ^ (unsigned)w0))) goto L2;
    { unsigned t5; double z5; if ((6u) & 1u) { t5 = (unsigned)((short)3u > (signed char)0x7fffffffu); z5 = (double)((0x3b592cf1u) & 255u); } if ((6u) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
        if ((unsigned)(0x7fffffffu < 6u)) goto done;
    }
    if (u3 == 7u) return p0;
    s0 = (int)(a0[i0 & 3u] << (i1 & 31u));
    do { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)x0 & 1023u);
    } while (i0++ < 2u && (unsigned)((int)(0x80000000u % ((unsigned)c1 | 1u)) < (int)2u));
    garr[(unsigned)(unsigned char)(0x7bf4ffb6u + u3) & 7u] = (0xbb90d918u - u3);
    goto L1;
    if (0x7fffffffu) goto L0;
    if (fuel) {
        if (((p0 % (0u | 1u)) * p0)) goto L0;
        c1 = (signed char)(p2 % ((unsigned)((int)0x2149a01cu < (int)0x80000000u) | 1u));
        if ((unsigned)((int)9u < (int)r0.y)) goto L4;
        r0.x = ((unsigned)(unsigned char)(i2 >> (*q0 & 31u)) ^ ((unsigned)w0 - u2));
        do { if (--fuel == 0u) goto done;
            if (u1) {
                u1 = (unsigned)(w0 >> 29);
                u3 += (unsigned)(a0[u1 & 3u] == (unsigned)(x0 >> 70));
            }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)f0) break;
                { unsigned t6; double z6; if ((u2) & 1u) { t6 = p1; z6 = (double)(((unsigned)e0) & 255u); } if ((u2) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                    c0 = (unsigned char)*q0;
                    if ((unsigned)(0x80000000u < (unsigned)(1u && u3))) break;
                    h0 = (short)(unsigned)(((unsigned)w0 >> (0xde933ec3u & 31u)) && a0[i0 & 3u]);
                    if (0xffffffffu) break;
                    if (fuel < 8u) return ((6u - garr[u2 & 7u]) * (unsigned)(2u < 0x6b91ff56u));
                }
                while (i2++ < 3u && 0x80000000u) { if (--fuel == 0u) goto done;
                    if (g0) break;
                    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (((unsigned)c1 << ((unsigned)d0 & 31u))) break;
                    }
                    b0 = (9u % (p1 | 1u)) != 0u;
                    if (i0) break;
                    if ((garr[u2 & 7u] + u2)) break;
                }
                if ((r0.x ? (unsigned)(x0 >> 70) : a0[u1 & 3u])) continue;
                s1 = (int)((unsigned)s1 + -(unsigned)(((unsigned)h0 - i0) || 0x84820e0u));
                if (0x7fffffffu) break;
            } while (i1++ < 7u && 0x7fffffffu);
            x0 = x0 * 0x100000001b3ull + (((0x7fffffffu | garr[u2 & 7u]) % (p2 | 1u)) % (a0[u1 & 3u] | 1u));
            for (;;) { if (--fuel == 0u) goto done;
                break; (void)((garr[i1 & 7u] * 5u));
                d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)((short)r0.x > (signed char)0xf518156cu) < (int)(a0[u1 & 3u] % ((unsigned)s1 | 1u))) & 1023u);
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)h1 >> (u3 & 31u))) break;
                    if ((4u & (unsigned)b0)) continue;
                    if ((unsigned)(w0 >> 29)) break;
                    d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(garr[u2 & 7u] < (fuel ? (unsigned)c1 : u1)) || a0[i0 & 3u]) & 1023u);
                }
            }
            { unsigned t7; double z7; if (((unsigned)(0x80000000u < (unsigned)b0)) & 1u) { t7 = (unsigned)((short)6u > (signed char)1u); z7 = (double)(((a0[u1 & 3u] - r0.y)) & 255u); } if (((unsigned)(0x80000000u < (unsigned)b0)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                if (i1) break;
                a0[i1 & 3u] = garr[i1 & 7u];
                s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((short)a0[u1 & 3u] > (signed char)(r0.y * (unsigned)(v0 && p1))) || 4u));
                if ((unsigned)(7u && 0x3a3e432cu)) break;
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)7u;
                    break; (void)((u3 - (unsigned)e0));
                    l0 = (long)((unsigned long)l0 + (unsigned)h1);
                    h1 = (unsigned short)(h1 + (0x69916497u & *mp));
                }
                *mp = (0xbf300e1u / (((unsigned)b0 << ((unsigned)(signed char)(0u / ((unsigned)b0 | 1u)) & 31u)) | 1u));
            }
            c1 = (signed char)(unsigned)!((unsigned)w0 * ((*mp * 0xffffffffu) * (unsigned)h1));
        } while (i0++ < 2u && (unsigned)((int)0xec57bf00u >= (int)(unsigned)!(8u | 0xffffffffu)));
    }
    if (g1) goto done;
    c0 = (unsigned char)(i2 ? garr[i1 & 7u] : (unsigned)c0);
    goto L0;
    { unsigned t8; double z8; if (((unsigned)(*q0 < 5u)) & 1u) { t8 = (unsigned)w0; z8 = (double)(((unsigned)!((unsigned)(a0[u1 & 3u] && (unsigned)x0) + *q0)) & 255u); } if (((unsigned)(*q0 < 5u)) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
        if (i2) goto L1;
        if ((g0 % ((unsigned)((int)u0 >= (int)p2) | 1u))) goto done;
        if (((*q0 | u3) | i0)) goto L1;
        { unsigned t9; double z9; if (((*mp / (0x7fffffffu | 1u))) & 1u) { t9 = (unsigned)(0x10000u < *q0); z9 = (double)(((unsigned)((unsigned)h1 && (unsigned)c0)) & 255u); } if (((*mp / (0x7fffffffu | 1u))) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
            if ((unsigned)(short)(0xee7060b5u << (fuel & 31u))) goto L2;
            c1 = (signed char)(unsigned)((int)m0 < (int)0u);
            if (-(g0 | 3u)) goto L4;
            goto done;
            if (((unsigned)(x0 >> 70) * (unsigned)(6u || m0))) {
                if (((unsigned)f0 + g1)) {
                    c1 = (signed char)(r0.y >> ((unsigned)x0 & 31u));
                    if (r0.x) goto L2;
                    c1 = (signed char)((unsigned)(w0 >> 29) / ((unsigned)((p2 % ((v0 >> (0x3828db29u & 31u)) | 1u)) < (unsigned)w0) | 1u));
                    v0 = p2;
                    if (((unsigned)b0 << (((unsigned)s1 % (0xb080de8du | 1u)) & 31u))) {
                        u0 ^= ((unsigned)(w0 >> 29) % ((unsigned)((int)(unsigned)(x0 >> 70) < (int)0x7d477fdcu) | 1u));
                        if ((unsigned)((int)0x11ccc07fu >= (int)(unsigned)f0)) goto L2;
                        if ((0x7a7b3bdbu * (unsigned)h1)) goto L0;
                        a0[((unsigned)c1 + a0[u1 & 3u]) & 3u] = (((unsigned)((unsigned)c0 && v0) | i2) / ((unsigned)(5u < 0x80000000u) | 1u));
                    }
                    while ((0xffffffffu % (((unsigned)d0 ^ i2) | 1u))) { if (--fuel == 0u) goto done;
                        { unsigned t10; double z10; if ((i0) & 1u) { t10 = (r0.y << ((unsigned)x0 & 31u)); z10 = (double)((*q0) & 255u); } if ((i0) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
                            *q0 += ((unsigned)f0 & (unsigned)(w0 >> 29));
                            r0.y ^= (unsigned)((unsigned)((unsigned)(0x7fffffffu && (unsigned)f0) && garr[u2 & 7u]) || (r0.x ^ (unsigned)l0));
                            m0 ^= ((unsigned)(signed char)(9u * p2) % ((unsigned)(r0.x || *q0) | 1u));
                            f0 = f0 * 0.5f + (float)((((unsigned)(0x10000u < m0) >> (u1 & 31u)) ^ 1u) & 255u);
                        }
                        if ((unsigned)(a0[u1 & 3u] || (0x7fffffffu | (unsigned)d0))) goto L2;
                    }
                } else {
                    h0 = (short)3u;
                    goto L2;
                }
                r0.x = (unsigned)((unsigned)l0 == (3u >> ((p1 + a0[i0 & 3u]) & 31u)));
                if ((p1 | *mp)) {
                    if ((0x195cdf82u >> (0xbc26d751u & 31u))) goto L4;
                    e0 = e0 * 0.5L + (long double)((garr[u2 & 7u] - (unsigned)((unsigned)(x0 >> 70) || (unsigned)((int)((unsigned)h1 / (a0[i0 & 3u] | 1u)) >= (int)0x90893a1u))) & 1023u);
                    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)(signed char)(unsigned)((int)(unsigned)c0 >= (int)0x10000u)) break;
                        w0 = w0 * 6364136223846793005ull + (0x2b6d47f5u % ((unsigned)((short)p2 > (signed char)(u1 / (0x3fda59bau | 1u))) | 1u));
                        if ((((unsigned)d0 * 0x10000u) / (9u | 1u))) break;
                        if (u1) break;
                    }
                }
                h1 = (unsigned short)(h1 + (0xffffffffu + (unsigned)(a0[u1 & 3u] && 0xad6bc936u)));
                switch ((unsigned)c0 & 7u) {
                    { unsigned t11; double z11; if (((unsigned)h0) & 1u) { t11 = 1u; z11 = (double)((v0) & 255u); } if (((unsigned)h0) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
                        break; (void)(0xaf03be18u);
                        g1 += ((unsigned)((short)a0[i0 & 3u] > (signed char)i0) << ((unsigned)(r0.x || 3u) & 31u));
                        if (u3 == 7u) return 0x5549f0fdu;
                        x0 = x0 * 0x100000001b3ull + (unsigned)((int)m0 < (int)((unsigned)w0 + i1));
                        w0 ^= (unsigned long long)p0 << ((unsigned)((int)p0 >= (int)~(u0 + (0x80000000u | (unsigned)(a0[u1 & 3u] || u0)))) & 63u);
                    }
                    *q0 = (((unsigned)c0 ? (unsigned)c1 : u0) - m0);
                    { unsigned t12; double z12; if (((unsigned)!(unsigned)((int)(unsigned)h0 >= (int)(unsigned)((unsigned)(w0 >> 29) < 0xf73277b1u))) & 1u) { t12 = (unsigned)x0; z12 = (double)((((unsigned)((short)u2 > (signed char)(unsigned)(x0 >> 70)) | p1)) & 255u); } if (((unsigned)!(unsigned)((int)(unsigned)h0 >= (int)(unsigned)((unsigned)(w0 >> 29) < 0xf73277b1u))) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
                        g1 += (unsigned)(garr[u2 & 7u] < g0);
                        if (fuel < 8u) return (unsigned)((a0[u1 & 3u] >> (0x9d04969du & 31u)) == (unsigned)((int)i1 < (int)(g1 * v0)));
                        g1 += (unsigned)(short)((unsigned)s1 & (unsigned)x0);
                        case 2u: ;
                        r0.y ^= (garr[u2 & 7u] << ((unsigned)e0 & 31u));
                        case 7u: ;
                    }
                    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        default: ;
                        case 5u: ;
                        r0.y ^= (unsigned)((int)(0x471045c0u - 0xdb31ee16u) < (int)((unsigned)w0 ? i1 : u2));
                        if (((unsigned)h0 >> (p0 & 31u))) goto L0;
                        case 4u: ;
                    }
                    c0 = (unsigned char)(unsigned)f0;
                    *q0 += 0u;
                }
            }
            u2 = (unsigned)((unsigned)e0 == (unsigned)(a0[i0 & 3u] == u0));
        }
        goto L0;
        if ((unsigned)(short)(unsigned)(u3 < 7u)) goto L2;
    }
    if ((unsigned)(w0 >> 29)) goto L3;
    if (((unsigned)s1 << (~(unsigned)((unsigned)(x0 >> 70) < 0x80000000u) & 31u))) goto L3;
    { unsigned t13; double z13; if (((unsigned)((short)7u > (signed char)(unsigned)(fuel || u0))) & 1u) { t13 = (0x7fffffffu + u1); z13 = (double)(((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)h0)) & 255u); } if (((unsigned)((short)7u > (signed char)(unsigned)(fuel || u0))) & 1u) { u1 += t13; d0 = d0 * 0.5 + z13; }
        v0 = (unsigned)((int)u2 < (int)(unsigned)!((0x80000000u << (i2 & 31u)) ^ (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)s0)));
        while (i0++ < 5u && (unsigned)(short)(unsigned)((int)(unsigned)s0 >= (int)(unsigned)l0)) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)((m0 >> (garr[i1 & 7u] & 31u)));
                continue; (void)((unsigned)(((unsigned)b0 % (0xffffffffu | 1u)) < i1));
            }
            break; (void)((p0 ? *mp : (unsigned)f0));
        }
        q0 = &garr[(unsigned)((short)(a0[i0 & 3u] ? garr[i1 & 7u] : (unsigned)c1) > (signed char)0x10000u) & 7u];
        u0 = u0 * 0x9e3779b1u + ((unsigned)s1 * (unsigned)(w0 >> 29));
    }
    r0.x = -(unsigned)((r0.y * 8u) == (unsigned)(u2 || -(unsigned)((int)(unsigned)h1 >= (int)(unsigned)h1)));
    do { if (--fuel == 0u) goto done;
        g0 = ((garr[i1 & 7u] + m0) << ((unsigned)d0 & 31u));
        if ((unsigned)(m0 == 0x80000000u)) break;
        g1 += ((0x79d3b539u / ((unsigned)(x0 >> 70) | 1u)) ^ (0xffffffffu * 0xffffffffu));
        if ((unsigned)((short)a0[u1 & 3u] > (signed char)((unsigned)(x0 >> 70) + (unsigned)h0))) break;
        break; (void)(r0.y);
        r0.x = (unsigned)((int)0x10000u < (int)~((u3 % ((unsigned)c0 | 1u)) ^ (unsigned)(unsigned char)(p0 * (unsigned)f0)));
    } while (i0++ < 3u && 0xe60fc489u);
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 7u && ~((i2 - garr[i1 & 7u]) + i2)) { if (--fuel == 0u) goto done;
            switch ((i1 >> (0x9a22c6c2u & 31u)) & 7u) {
                while (i2++ < 3u && p1) { if (--fuel == 0u) goto done;
                    g1 += ((2u - (g1 << (2u & 31u))) + u0);
                }
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    case 1u: ;
                    while ((g0 ^ (unsigned)s0)) { if (--fuel == 0u) goto done;
                        case 0u: ;
                        u1 ^= (unsigned)((short)(unsigned)((u0 ? fuel : 0xd26aa668u) && u2) > (signed char)garr[i1 & 7u]);
                        goto done;
                        break; (void)(i2);
                        default: ;
                    }
                    u3 = (unsigned)((int)(0x80000000u - (unsigned)((unsigned)s0 && (unsigned)h0)) < (int)0x80000000u);
                    case 3u: ;
                }
                *mp = ((unsigned)c1 ^ (unsigned)(unsigned char)(r0.x >> (((unsigned)f0 >> (0x7f50278bu & 31u)) & 31u)));
                case 2u: ;
                garr[7u & 7u] = ((a0[i0 & 3u] + (u0 ^ ~(0x7fffffffu << (0x10000u & 31u)))) + u0);
                if (u3 == 7u) return (~(unsigned)(a0[u1 & 3u] < (unsigned)w0) / ((unsigned)(short)((unsigned)s0 & (m0 ^ 0x1ae6f577u)) | 1u));
            }
            if (u0) continue;
            switch (((unsigned)((int)0x7fffffffu >= (int)m0) << ((unsigned)h0 & 31u)) & 7u) {
                q0 = &garr[~(unsigned)((short)(0xfbd2ca1du ? p2 : *mp) > (signed char)0x1b8c9291u) & 7u];
                a0[(unsigned)(p2 && *mp) & 3u] = (fuel % ((2u - u1) | 1u));
            }
            c0 = (unsigned char)(unsigned)!(unsigned)((int)(unsigned)!((unsigned)(unsigned char)(unsigned)((short)r0.x > (signed char)(unsigned)((int)r0.y < (int)(unsigned)(x0 >> 70))) | i0) < (int)0xf0ce6d2fu);
            b0 = ((unsigned)d0 >> ((unsigned)(short)(((unsigned)c0 ^ garr[i1 & 7u]) / ((unsigned)((int)(unsigned)b0 >= (int)i2) | 1u)) & 31u)) != 0u;
        }
        if ((unsigned)(unsigned char)(unsigned)((0x499b6878u & garr[u2 & 7u]) && 8u)) break;
        do { if (--fuel == 0u) goto done;
            if (u0) break;
            u3 = u3 * 0x9e3779b1u + (0u % (((0u | p2) | 0xddc99dddu) | 1u));
            if (7u) break;
        } while (i1++ < 4u && v0);
    }
    u1 ^= ((unsigned)h1 & 0x7fffffffu);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch (g0 & 7u) {
        x0 = x0 * 0x100000001b3ull + 1u;
        if (budget != 0u) { budget -= 1u; u3 = fn0(-(unsigned)(u0 < 0x7fffffffu), (*mp * 0xdaa0332au), (unsigned)h0); }
        switch ((unsigned)w0 & 7u) {
            L0: if (--fuel == 0u) goto done;
            *mp = ((unsigned)((unsigned)((unsigned)h1 < a0[i0 & 3u]) == (unsigned)((int)g1 >= (int)(unsigned)h0)) % (2u | 1u));
            u2 = (((0xeb22e4au | *mp) * v0) * v0);
            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((int)p1 < (int)(0x10000u ^ (unsigned)w0)) || fuel));
        }
        { unsigned t0; double z0; if ((*q0) & 1u) { t0 = (unsigned)(unsigned char)(unsigned)(i2 < (0x10000u - p2)); z0 = (double)(((unsigned)((short)(unsigned)(garr[u2 & 7u] < (unsigned)s1) > (signed char)(unsigned)f0)) & 255u); } if ((*q0) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            v0 = (unsigned)((unsigned)(garr[i1 & 7u] && u0) < (unsigned)!(unsigned)((int)garr[u2 & 7u] < (int)(p1 + (unsigned)e0)));
            u2 = u2 * 0x9e3779b1u + 0x10000u;
            case 3u: ;
        }
    }
    c1 = (signed char)g1;
    L1: if (--fuel == 0u) goto done;
    r0.y ^= (unsigned)l0;
    if (budget != 0u) { budget -= 1u; u0 = fn0(0x2ff7258au, (unsigned)((int)(unsigned)b0 >= (int)p1), ((unsigned)(w0 >> 29) << (g1 & 31u))); }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[u1 & 3u] = (unsigned)((unsigned)(unsigned char)((unsigned)b0 ? *q0 : (unsigned)(0x10000u < p0)) && (unsigned)c0);
        while (i1++ < 5u && 0x10000u) { if (--fuel == 0u) goto done;
            switch (i0 & 7u) {
                g0 = (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)((short)0x7fffffffu > (signed char)p0));
            }
        }
        switch ((unsigned)(short)(unsigned)((int)0x7fffffffu < (int)(8u % (u1 | 1u))) & 7u) {
            *mp = (((unsigned)h1 ? (unsigned)((unsigned)(w0 >> 29) || 0x1d0eb2d0u) : a0[i0 & 3u]) >> ((unsigned)d0 & 31u));
            x0 = x0 * 0x100000001b3ull + (unsigned)((p1 + *q0) || 0u);
            switch ((unsigned)(0x80000000u < p0) & 7u) {
                m0 ^= (0u ^ (u0 >> ((unsigned)l0 & 31u)));
            }
        }
        { unsigned t1; double z1; if (((0x991387e5u + ((unsigned)c1 % (0xf8e0901au | 1u)))) & 1u) { t1 = (p1 - p2); z1 = (double)(((unsigned)(a0[i0 & 3u] < p0)) & 255u); } if (((0x991387e5u + ((unsigned)c1 % (0xf8e0901au | 1u)))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            a0[((unsigned)d0 >> ((unsigned)b0 & 31u)) & 3u] = (((unsigned)w0 % (g1 | 1u)) | (p2 & garr[u2 & 7u]));
        }
        if (((unsigned)d0 << (-(unsigned)(garr[u2 & 7u] == p0) & 31u))) goto L0;
    }
    g0 = (0xb911243cu ? (0xd7b7c4e7u | p0) : i0);
    s1 = (int)((unsigned)s1 + 0x1f90a03fu);
    goto L4;
    garr[(p2 & r0.y) & 7u] = (unsigned)((int)(unsigned)c0 < (int)(m0 & garr[u2 & 7u]));
    u3 = (unsigned)(u0 == *q0);
    x0 = x0 * 0x100000001b3ull + *mp;
    switch ((unsigned)((int)(unsigned)(0u && g1) < (int)0x7fffffffu) & 7u) {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                case 7u: ;
                a0[(unsigned)h1 & 3u] = ((*q0 - (unsigned)d0) + (0x7fffffffu * u1));
                a0[(unsigned)(p2 && g0) & 3u] = (unsigned)(short)(unsigned)((short)i0 > (signed char)(unsigned)((int)0x6c7fa648u < (int)fuel));
                case 2u: ;
                do { if (--fuel == 0u) goto done;
                    i0 = ((unsigned)(signed char)(p1 / ((unsigned)(0x285e95b1u && 0x7fffffffu) | 1u)) | p0) & 15u;
                    if (((unsigned)((int)p1 < (int)(unsigned)e0) ^ (unsigned)(x0 >> 70))) break;
                } while (i2++ < 5u && (unsigned)((int)(unsigned)(0x80000000u && i0) < (int)u2));
                if ((((unsigned)c1 << (0x35cd16c2u & 31u)) + (unsigned)c1)) break;
            }
            L2: if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
        }
        case 3u: ;
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        q0 = &garr[((0x9025b38du ^ 6u) + (unsigned)((unsigned)((short)(unsigned)h1 > (signed char)p2) < 9u)) & 7u];
    }
    if (0x80000000u) {
        goto L0;
        f0 = f0 * 0.5f + (float)((unsigned)c0 & 255u);
        if (budget != 0u) { budget -= 1u; u2 = fn0((fuel >> (0xffffffffu & 31u)), a0[i0 & 3u], (unsigned)!(unsigned)(i0 < 0x61ae39e7u)); }
        L4: if (--fuel == 0u) goto done;
        if (((unsigned)w0 >> (i2 & 31u))) {
            goto L1;
            if (r0.y) goto L1;
            if (0x80000000u) {
                w0 ^= (unsigned long long)(unsigned)(r0.x || v0) << (0x80000000u & 63u);
                switch (2u & 7u) {
                    case 5u: ;
                    if ((unsigned)(0x7fffffffu && 3u)) goto L4;
                    goto L4;
                    r0.x = (unsigned)((int)(unsigned)((int)(p0 | (unsigned)c0) < (int)(unsigned)f0) < (int)(unsigned)s1);
                    *q0 += (unsigned)b0;
                }
                while (((unsigned)w0 ^ (unsigned)s0)) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((unsigned)c0 & 255u);
                    if ((v0 - (u0 | 0u))) break;
                    h0 = (short)(unsigned)(unsigned char)(7u * (g1 & i2));
                }
                f0 = f0 * 0.5f + (float)(((u1 + i0) - (0x80000000u << ((unsigned)(x0 >> 70) & 31u))) & 255u);
                if (fuel < 8u) return (0x13f82446u - (unsigned)l0);
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)c1, (garr[i1 & 7u] >> (fuel & 31u)), (unsigned)(x0 >> 70)); }
            } else {
                if ((unsigned)((int)(unsigned)(1u && fuel) < (int)*q0)) {
                    if ((unsigned)((short)(unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) < (unsigned)b0) > (signed char)(unsigned)(w0 >> 29))) goto L2;
                    d0 = d0 * 0.5 + (double)((unsigned)((*mp & 0x26c14051u) || (unsigned)(0u == 2u)) & 1023u);
                    q0 = &garr[0x5da69cecu & 7u];
                    if (((unsigned)b0 | 0x9242e092u)) {
                        r0.y ^= (unsigned)(short)(unsigned)((unsigned)c1 && m0);
                        goto L2;
                        if (((0xd528cd11u & u2) % (1u | 1u))) goto L2;
                    } else {
                        goto L0;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(2u, ((unsigned)(u0 == i2) | (unsigned)b0), (0x80000000u - 0xffffffffu)); }
                    }
                    u2 = u2 * 0x9e3779b1u + ((unsigned)c0 | 0x9b699d10u);
                } else {
                    c1 = (signed char)7u;
                    goto L1;
                }
                while (i0++ < 3u && 0x2afdd01bu) { if (--fuel == 0u) goto done;
                    b0 = (unsigned)(unsigned char)(garr[i1 & 7u] ? (unsigned)c0 : 3u) != 0u;
                }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)h1 + (u2 * u3)), (*q0 & i0), (unsigned)h1); }
            w0 = w0 * 6364136223846793005ull + u3;
            i0 = ((unsigned)((unsigned)h0 && (unsigned)d0) / ((i2 << ((unsigned)(x0 >> 70) & 31u)) | 1u)) & 15u;
        } else {
            s1 = (int)((unsigned)s1 + 0x10000u);
        }
        goto L4;
    } else {
        if (budget != 0u) { budget -= 1u; u1 = fn0(((i2 + 6u) * a0[i0 & 3u]), r0.x, *q0); }
        c0 = (unsigned char)(unsigned)(short)(~(unsigned)((unsigned)w0 == (unsigned)c1) / ((unsigned)w0 | 1u));
        r0.y ^= (unsigned)((unsigned)((int)(unsigned)(w0 >> 29) >= (int)v0) && (unsigned)((int)~(0x20ebee96u * (unsigned)h0) < (int)(unsigned)h1));
    }
    h0 = (short)6u;
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(0xffffffffu - (unsigned)(*mp && (unsigned)f0)), v0, (unsigned)((unsigned)(0xc7ef9c57u < 0x1191206fu) == u3)); }
    if (u3 == 7u) return ((unsigned)h0 ^ (unsigned)d0);
    w0 ^= (unsigned long long)(5u / (p2 | 1u)) << ((unsigned)((p2 >> ((unsigned)c1 & 31u)) < a0[u1 & 3u]) & 63u);
    for (;;) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            s0 = (int)((a0[i0 & 3u] / ((unsigned)(g1 || (unsigned)f0) | 1u)) & (unsigned)s0);
        } while (i1++ < 4u && a0[i0 & 3u]);
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(garr[u2 & 7u] == (u3 << (8u & 31u))), ((unsigned)h0 ^ (unsigned)(x0 >> 70)), (unsigned)((5u / ((unsigned)c0 | 1u)) < (unsigned)x0)); }
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(w0 >> 29)) {
                *q0 += ((7u | 0x41b6f007u) | 2u);
                s0 = (int)(1u % ((unsigned)(short)(unsigned)(((unsigned)f0 * (unsigned)l0) < r0.x) | 1u));
                switch (-(garr[i1 & 7u] * (unsigned)(g1 < (unsigned)(w0 >> 29))) & 7u) {
                    q0 = &garr[(unsigned)((unsigned)((short)6u > (signed char)i1) == 0xffffffffu) & 7u];
                    x0 = x0 * 0x100000001b3ull + ((unsigned)e0 << ((unsigned)((int)0x7fffffffu < (int)(a0[i0 & 3u] * 9u)) & 31u));
                    if ((unsigned)!(unsigned)((short)*mp > (signed char)p1)) continue;
                    if ((garr[i1 & 7u] % ((m0 / (u2 | 1u)) | 1u))) {
                        i0 = (i2 * (unsigned)(0x80000000u && (unsigned)(w0 >> 29))) & 15u;
                        switch ((unsigned)((short)a0[u1 & 3u] > (signed char)a0[u1 & 3u]) & 7u) {
                            break; (void)((unsigned)!(((unsigned)(x0 >> 70) >> ((unsigned)b0 & 31u)) % (garr[i1 & 7u] | 1u)));
                            break; (void)((unsigned)x0);
                            r0.y ^= ((unsigned)((unsigned)s1 || ((unsigned)h1 * u3)) * 0x7fffffffu);
                        }
                        r0.y ^= 0x851e9c10u;
                        *mp = (0xffffffffu | ((unsigned)(0x6e18b140u == 0xe4e6a614u) & (unsigned)c0));
                    } else {
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)c0 | (unsigned)(short)((unsigned)s0 << (0x8328ab52u & 31u))), (0x7fffffffu % (0x10000u | 1u)), (unsigned)((unsigned)h0 && (unsigned)s0)); }
                        case 4u: ;
                    }
                    q0 = &garr[(unsigned)(fuel == (unsigned)((int)(unsigned)l0 >= (int)*q0)) & 7u];
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(u3, (v0 << (((unsigned)(x0 >> 70) ^ 7u) & 31u)), ((unsigned)b0 + garr[i1 & 7u])); }
                break; (void)((unsigned)((int)(unsigned)w0 >= (int)0x7fffffffu));
                r0.x = (unsigned)!((unsigned)(unsigned char)(i2 & 0x10000u) / (g1 | 1u));
            } else {
                c0 = (unsigned char)((0x7fffffffu >> ((*q0 / (0x7fffffffu | 1u)) & 31u)) ^ a0[u1 & 3u]);
                if (budget != 0u) { budget -= 1u; u1 = fn0(((0x48c3f301u & 0x70e663afu) << (0xffffffffu & 31u)), ((unsigned)c0 >> (garr[u2 & 7u] & 31u)), (unsigned)(a0[i0 & 3u] < 3u)); }
            }
            break; (void)((unsigned)((unsigned)l0 < (unsigned)((short)0x7a00c49bu > (signed char)0x8ed3df2cu)));
            *mp = i2;
            for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (u3 ? (unsigned)(u0 || fuel) : (unsigned)(0x10000u || 0xb0c769bfu)));
                    w0 = w0 * 6364136223846793005ull + 6u;
                    if ((unsigned)(signed char)((*q0 - g1) * p1)) {
                        do { if (--fuel == 0u) goto done;
                            i0 = (unsigned)(0x4e73078cu < (0x80000000u | garr[i1 & 7u])) & 15u;
                            if ((unsigned)((int)(unsigned)e0 < (int)(unsigned)((unsigned)l0 && g0))) goto L3;
                            u1 = (unsigned)h1;
                            if (((unsigned)(w0 >> 29) * i1)) break;
                            if ((0x30b986eau ^ (unsigned)(signed char)(0xc307aa38u / (garr[u2 & 7u] | 1u)))) break;
                            if ((((unsigned)x0 % (5u | 1u)) - u1)) break;
                        } while (i1++ < 2u && (unsigned)((short)6u > (signed char)((unsigned)b0 << ((unsigned)(x0 >> 70) & 31u))));
                        *q0 = (v0 ^ 0x7fffffffu);
                        u3 = u3 * 0x9e3779b1u + ((g0 % (0x7fffffffu | 1u)) + r0.y);
                        w0 ^= (unsigned long long)-(i2 / (0x782facb9u | 1u)) << ((unsigned)((unsigned)((unsigned)w0 < ((unsigned)e0 >> (0u & 31u))) || (unsigned)c1) & 63u);
                    } else {
                        if ((unsigned)(w0 >> 29)) break;
                        w0 = w0 * 6364136223846793005ull + (((fuel - (unsigned)w0) % (g1 | 1u)) * (unsigned)h1);
                        if (0x80000000u) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(0x56e7fa80u, (unsigned)((int)p2 >= (int)garr[i1 & 7u]), u3); }
                    }
                    u2 = u2 * 0x9e3779b1u + (unsigned)c1;
                    break; (void)((p0 / (i1 | 1u)));
                    u0 = u0 * 0x9e3779b1u + (m0 << ((unsigned)(0x2b94169au && 9u) & 31u));
                }
                *q0 = (unsigned)(short)(((unsigned)w0 % (a0[u1 & 3u] | 1u)) % (((g1 * *mp) << (i0 & 31u)) | 1u));
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)0xffffffffu > (signed char)6u)) goto L4;
                    switch ((r0.x ^ *q0) & 7u) {
                        f0 = f0 * 0.5f + (float)(~(~(8u % (g0 | 1u)) + ((unsigned)s0 % (i1 | 1u))) & 255u);
                        if (((0x2fcba40u << (u1 & 31u)) - r0.x)) continue;
                        case 3u: ;
                        r0.y ^= (((unsigned)d0 + r0.y) % (0xefc30aebu | 1u));
                        u3 = 0xa26a49fu;
                        s1 = (int)((unsigned)s1 + ((unsigned)(signed char)(g1 << (a0[u1 & 3u] & 31u)) / (0x80000000u | 1u)));
                    }
                } while (i0++ < 4u && (unsigned)((u1 << (0x7fffffffu & 31u)) || (unsigned)l0));
                b0 = (unsigned)(unsigned char)(unsigned)(1u || (unsigned)(short)(0x7fffffffu ^ p0)) != 0u;
            }
            b0 = -(unsigned)((u1 & ((unsigned)c0 / (u1 | 1u))) || p0) != 0u;
        }
        if (a0[i0 & 3u]) break;
        u0 += (unsigned)x0;
        if ((unsigned)s1) continue;
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)((unsigned)((short)0x57ab455au > (signed char)(i0 + 0xdbd22898u)) || 8u);
            s0 = (int)7u;
            if (budget != 0u) { budget -= 1u; u3 = fn0((3u - 0x41616602u), i1, (unsigned)(a0[u1 & 3u] < ~(m0 / (0x7fffffffu | 1u)))); }
            if ((unsigned)((int)(unsigned)s1 < (int)(unsigned)c0)) break;
            q0 = &garr[((unsigned)!(unsigned)((unsigned)(x0 >> 70) || (unsigned)c1) / (*q0 | 1u)) & 7u];
            i1 = (unsigned)e0 & 15u;
        } while (i1++ < 6u && (a0[u1 & 3u] << (0u & 31u)));
        u1 = u1 * 0x9e3779b1u + (unsigned)(((unsigned)((int)0xa5f58667u >= (int)g0) >> (4u & 31u)) && (unsigned)(w0 >> 29));
        if (fuel < 8u) return (0x80000000u ^ ((unsigned)(0x7fffffffu || 0x80000000u) * (i0 | p0)));
        if (fuel < 8u) return ((unsigned)((short)(unsigned)s0 > (signed char)i1) + (u3 - 0x4b10fb45u));
        a0[(unsigned)(*q0 == *mp) & 3u] = ((unsigned)(w0 >> 29) * g1);
        if ((unsigned)h1) break;
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = 0x929b6225u;
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0x10000u < ((unsigned)b0 % (p1 | 1u))), (i1 ? 8u : 5u), (unsigned)((a0[u1 & 3u] << (u1 & 31u)) && (unsigned)(w0 >> 29))); }
        u0 += (unsigned)(~(unsigned)((short)(unsigned)h1 > (signed char)0x10000u) || 0x7fffffffu);
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)u0 > (signed char)(unsigned)(w0 >> 29)), (u0 / ((unsigned)((int)(unsigned)c0 >= (int)0xffffffffu) | 1u)), (0u - (0u + (unsigned)w0))); }
            if ((r0.y ^ (unsigned)s1)) continue;
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)((int)0x2ac0c16eu >= (int)u1) - *mp)) {
                    d0 = d0 * 0.5 + (double)((unsigned)(x0 >> 70) & 1023u);
                    r0.y ^= -((((unsigned)l0 << ((unsigned)f0 & 31u)) * (2u * (unsigned)f0)) * 0x771082feu);
                    *q0 = m0;
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)((unsigned)d0 ^ 0x118997b9u) < (int)((0xffffffffu * 0xffffffffu) / (a0[u1 & 3u] | 1u)));
                garr[(0xffffffffu << (0x556ad603u & 31u)) & 7u] = (0x80000000u >> ((unsigned)(signed char)(*q0 >> (0x6c7db8a4u & 31u)) & 31u));
                v0 = (~(unsigned)((int)7u < (int)0xffffffffu) % ((unsigned)(7u && ((unsigned)(x0 >> 70) % (u1 | 1u))) | 1u));
                if ((unsigned)(((unsigned)e0 + p2) == p0)) break;
            }
        } while (i1++ < 4u && p1);
        do { if (--fuel == 0u) goto done;
            r0.y ^= ((((unsigned)(0x28913d56u < 0x813302e2u) / (u1 | 1u)) % ((unsigned)h0 | 1u)) >> (u3 & 31u));
            while (i2++ < 3u && (i1 / ((unsigned)(a0[i0 & 3u] || fuel) | 1u))) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)u2 < (int)0xed20e5b3u)) break;
            }
            { unsigned t2; double z2; if ((0x76508517u) & 1u) { t2 = (0x7fffffffu * (4u / (garr[u2 & 7u] | 1u))); z2 = (double)((((unsigned)c0 & i0)) & 255u); } if ((0x76508517u) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                if ((i0 << ((unsigned)!(5u * p2) & 31u))) goto L1;
            }
        } while (i1++ < 6u && (((unsigned)e0 % (5u | 1u)) % (r0.x | 1u)));
        s1 = (int)((unsigned)s1 + (unsigned)(-(0x7fffffffu / (0x3af7c230u | 1u)) || i0));
    }
    if (((unsigned)(x0 >> 70) ? u2 : g1)) {
        g1 += (v0 % (a0[i0 & 3u] | 1u));
        i1 = (unsigned)(short)(unsigned)(g0 || (unsigned)!(unsigned)((int)7u < (int)7u)) & 15u;
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)e0 < ~(r0.y | (unsigned)s0))) goto L0;
        u3 = u3 * 0x9e3779b1u + (unsigned)(u3 || i1);
        switch ((r0.x << ((unsigned)!(0x21d84604u ^ i0) & 31u)) & 7u) {
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)((unsigned)c0 || i1) < (int)garr[i1 & 7u])) break;
                if ((p0 >> (u2 & 31u))) goto L3;
                while (i2++ < 7u && p0) { if (--fuel == 0u) goto done;
                    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + ((0xd72579a3u << (*q0 & 31u)) % (((unsigned)f0 - p0) | 1u)));
                        if (budget != 0u) { budget -= 1u; u0 = fn0((m0 * i2), r0.x, ((*q0 + i0) / (6u | 1u))); }
                        *q0 += (unsigned)(unsigned char)(*q0 << ((unsigned)((int)(1u | ((unsigned)s0 & (unsigned)e0)) < (int)0xe7fc38b9u) & 31u));
                    }
                    h1 = (unsigned short)(h1 + ((a0[i0 & 3u] - (unsigned)(signed char)((unsigned)w0 << (((unsigned)s1 * a0[u1 & 3u]) & 31u))) % (6u | 1u)));
                    case 2u: ;
                    case 3u: ;
                    v0 = ((unsigned)((unsigned)c0 && m0) % (0xffffffffu | 1u));
                    case 1u: ;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((*mp << ((unsigned)f0 & 31u)), (unsigned)(unsigned char)(0x289db064u * 0u), (unsigned)!(u3 & 0x10000u)); }
                r0.y ^= -(unsigned)((int)0x932b24e7u >= (int)(0x10000u | u2));
                if (0xe2da368eu) {
                    f0 = f0 * 0.5f + (float)((unsigned)((int)((g0 - fuel) ? (unsigned)c1 : 6u) >= (int)m0) & 255u);
                } else {
                    garr[v0 & 7u] = (unsigned)!(a0[i0 & 3u] * 0x5a739d5bu);
                    *q0 = (unsigned)((int)9u < (int)((unsigned)c1 >> ((0xffffffffu ^ r0.x) & 31u)));
                    w0 = w0 * 6364136223846793005ull + ((unsigned)(*mp == p2) - 0x8eb1e51eu);
                }
            }
        }
        { unsigned t3; double z3; if ((u3) & 1u) { t3 = (5u % ((a0[i0 & 3u] >> (r0.y & 31u)) | 1u)); z3 = (double)(((unsigned)((*mp + (unsigned)b0) == 0x8ae48e78u)) & 255u); } if ((u3) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(signed char)(-((unsigned)h0 & 0x962256d6u) | 0x7fffffffu), (unsigned)(unsigned char)(unsigned)((int)(unsigned)x0 < (int)(unsigned)(signed char)(garr[u2 & 7u] & (unsigned)e0)), (unsigned)((unsigned)b0 < (r0.x / (p1 | 1u)))); }
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(v0 && v0), ((unsigned)((unsigned)s1 || (unsigned)(x0 >> 70)) ^ (unsigned)c0), (0x26a37cc6u & garr[u2 & 7u])); }
        }
        *q0 += (unsigned)((unsigned)h0 < ((unsigned)c0 % ((unsigned)h0 | 1u)));
        if (((unsigned)(3u < 0x727cc630u) - i1)) {
            switch (((unsigned)((int)(unsigned)(w0 >> 29) < (int)0xa9e117du) << (0x80000000u & 31u)) & 7u) {
                break; (void)((a0[u1 & 3u] + ((unsigned)c0 * (unsigned)(x0 >> 70))));
                w0 = w0 * 6364136223846793005ull + (unsigned)(9u && (unsigned)l0);
                while (i1++ < 4u && (unsigned)(p1 && 1u)) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (unsigned)c1;
                    *q0 = garr[u2 & 7u];
                    g0 = ((unsigned)w0 ^ (unsigned)((9u << (0x10000u & 31u)) < (garr[u2 & 7u] * r0.y)));
                    case 3u: ;
                    u0 = (v0 ? r0.x : (unsigned)(short)(u3 * i0));
                    if (((unsigned)h1 ? 0u : (unsigned)d0)) {
                        switch (g0 & 7u) {
                            if ((unsigned)((short)(unsigned)(u3 || 0x7fffffffu) > (signed char)0x90cd749cu)) break;
                            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)w0 + ~(u2 - (unsigned)c1)), ((unsigned)(x0 >> 70) + (r0.y - garr[u2 & 7u])), u2); }
                        }
                        case 5u: ;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(g1, ((unsigned)h1 >> (0xa9763ae7u & 31u)), u0); }
                    } else {
                        *mp = ((5u * m0) * u0);
                        *mp = (p0 - (unsigned)(x0 >> 70));
                        default: ;
                    }
                }
                v0 = ((unsigned)((a0[i0 & 3u] & p0) == (garr[i1 & 7u] * (unsigned)l0)) + 0x9ef8c148u);
            }
            if ((g0 - 0xed0812eau)) break;
        } else {
            g0 = ((unsigned)(a0[i0 & 3u] || u3) / ((unsigned)d0 | 1u));
            break; (void)((unsigned)((short)0xf165423fu > (signed char)(unsigned)d0));
            if (p1) goto L2;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((0xffffffffu << ((unsigned)s1 & 31u)) && garr[u2 & 7u]), (2u >> ((unsigned)c0 & 31u)), (unsigned)(signed char)(unsigned)((int)(unsigned)(0u < 0x80000000u) < (int)g0)); }
        }
    }
    l0 = (long)((unsigned long)l0 + (unsigned)c0);
    if (((unsigned)((int)i0 >= (int)u1) ^ g0)) goto L2;
    if ((unsigned)!(unsigned)((int)p0 >= (int)(0xffffffffu + garr[i1 & 7u]))) goto L3;
    d0 = d0 * 0.5 + (double)((((unsigned)c0 / ((garr[u2 & 7u] | garr[u2 & 7u]) | 1u)) >> ((unsigned)s1 & 31u)) & 1023u);
    v0 = (a0[i0 & 3u] + ((unsigned)s0 + (unsigned)((unsigned)d0 < ((unsigned)b0 ^ p0))));
    f0 = f0 * 0.5f + (float)(*mp & 255u);
    if ((unsigned)(unsigned char)(unsigned)((unsigned)((int)garr[i1 & 7u] < (int)(unsigned)h0) || u2)) goto L1;
    *q0 = (unsigned)((unsigned)c0 && (*mp ^ a0[i0 & 3u]));
    g1 += (8u | v0);
    e0 = e0 * 0.5L + (long double)((unsigned)((int)p1 >= (int)0xffffffffu) & 1023u);
    do { if (--fuel == 0u) goto done;
        if (7u) {
            continue; (void)((9u | 0xee296976u));
            if ((0x10000u ^ (unsigned)b0)) break;
            if ((unsigned)(0xf1e8ecf2u && (unsigned)e0)) {
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)((int)p0 >= (int)(unsigned)w0) < 4u)) break;
                    q0 = &garr[0x7fffffffu & 7u];
                    h0 = (short)(unsigned)((unsigned)c0 < (unsigned)(0x2b1492eu || i0));
                }
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)6u >= (int)*q0)) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(g1 == u0), (unsigned)(a0[i0 & 3u] < 0xb2359a5du), (unsigned)((int)0x2dc4138fu >= (int)u3)); }
                    i2 = (i0 & a0[i0 & 3u]) & 15u;
                    if (((unsigned)w0 + 0xcc155892u)) goto L1;
                    a0[(r0.x / ((unsigned)b0 | 1u)) & 3u] = (g1 >> (((unsigned)((int)0xdef62c23u >= (int)u1) << ((unsigned)c1 & 31u)) & 31u));
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(i2 < (unsigned)c1) - *mp), (a0[i0 & 3u] - (unsigned)(x0 >> 70)), (unsigned)(garr[i1 & 7u] < 9u)); }
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((0x4bef63b1u + (unsigned)s1), g1, ((unsigned)s0 - p1)); }
            }
        }
        if ((unsigned)(r0.y == 3u)) break;
        if ((unsigned)(short)(unsigned)(0x2015b00cu == u0)) break;
        *q0 = (0xff7ad5bu ? 0x7fffffffu : 0xe5133cf6u);
        if ((unsigned)c1) break;
    } while (i0++ < 5u && (p1 * (unsigned)s1));
    if ((unsigned)((int)9u < (int)(0x2a1fccf0u / (0xffffffffu | 1u)))) goto L2;
    goto L0;
    if ((unsigned)(9u < 0x7fffffffu)) goto L0;
    while (i0++ < 7u && (unsigned)l0) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if ((u0 - 0x39a52f8au)) {
                *q0 += (unsigned)((short)*mp > (signed char)(unsigned)((int)i1 < (int)g1));
                u0 = (unsigned)((int)(unsigned)d0 >= (int)(unsigned)((int)m0 >= (int)(0xb2feb055u * *q0)));
                if ((unsigned)(a0[i0 & 3u] == 0x7e5ff114u)) goto L1;
                h0 = (short)(unsigned)(garr[i1 & 7u] || p2);
                if (6u) continue;
                h0 = (short)((garr[u2 & 7u] * u3) % ((((unsigned)l0 + r0.x) % (4u | 1u)) | 1u));
            } else {
                break; (void)(((unsigned)s1 + (unsigned)((int)p0 >= (int)a0[u1 & 3u])));
                l0 = (long)((unsigned long)l0 + (unsigned)h0);
                q0 = &garr[(~(unsigned)((unsigned)b0 && (unsigned)((unsigned)((short)i0 > (signed char)(unsigned)e0) || fuel)) | fuel) & 7u];
                b0 = (7u + g1) != 0u;
            }
        } while (i1++ < 4u && (unsigned)((int)(unsigned)((unsigned)h1 < u0) >= (int)0x80000000u));
    }
    if (0x6f85907u) goto L2;
    if ((unsigned)((int)(unsigned)d0 >= (int)g0)) {
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (unsigned)w0;
            if (r0.x) {
                if ((2u << ((unsigned)((unsigned)b0 == (unsigned)w0) & 31u))) goto L3;
                while (i1++ < 4u && (unsigned)((short)(r0.y + p2) > (signed char)0x71941cfeu)) { if (--fuel == 0u) goto done;
                    switch ((unsigned)(u1 == g1) & 7u) {
                        continue; (void)(*mp);
                        case 2u: ;
                    }
                    if ((unsigned)(short)((unsigned)f0 / (v0 | 1u))) {
                        break; (void)((((unsigned)h1 - (unsigned)s1) + a0[u1 & 3u]));
                        r0.y ^= ((unsigned)((int)0xfe3f0ea2u >= (int)(unsigned)((int)(unsigned)s0 < (int)r0.y)) % ((unsigned)(w0 >> 29) | 1u));
                        for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                            if ((unsigned)((p1 | (unsigned)s1) || 2u)) goto L0;
                            s1 = (int)((unsigned)s1 + ((unsigned)e0 | (v0 * (unsigned)(r0.y < ~(unsigned)((int)v0 < (int)(unsigned)s1)))));
                            q0 = &garr[(unsigned)(~(g1 / (0xbf00dd2au | 1u)) && (unsigned)x0) & 7u];
                            g0 = ((m0 << (a0[i0 & 3u] & 31u)) >> ((unsigned)(0u || 0x7fffffffu) & 31u));
                            break; (void)(r0.y);
                        }
                    } else {
                        h0 = (short)(unsigned)(u1 || 0x10000u);
                    }
                    g1 += (unsigned)((v0 | ((unsigned)h1 & garr[i1 & 7u])) < (unsigned)w0);
                    { unsigned t4; double z4; if (((0xffffffffu + ~(unsigned)((int)5u < (int)i1))) & 1u) { t4 = ((0x1da7e694u >> ((unsigned)c1 & 31u)) >> (i0 & 31u)); z4 = (double)(((garr[i1 & 7u] - u3)) & 255u); } if (((0xffffffffu + ~(unsigned)((int)5u < (int)i1))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)w0, (p0 + 0x81e2808bu), ((unsigned)l0 + (garr[u2 & 7u] - (unsigned)(w0 >> 29)))); }
                    }
                    if (((unsigned)s0 % ((unsigned)!((unsigned)l0 + fuel) | 1u))) break;
                    if (0xf1505ae8u) {
                        break; (void)((unsigned)(i0 && (unsigned)h0));
                        s1 = (int)((unsigned)s1 + (9u * (unsigned)((int)(p1 * u3) < (int)garr[i1 & 7u])));
                        *q0 += (0x95713f07u / (*mp | 1u));
                    } else {
                        if (budget != 0u) { budget -= 1u; u0 = fn0(((g0 % (0x80000000u | 1u)) ^ p1), (unsigned)(*q0 && a0[u1 & 3u]), (unsigned)d0); }
                        if ((unsigned)((short)u0 > (signed char)2u)) break;
                        while (i2++ < 5u && (unsigned)(unsigned char)(unsigned)(7u || p1)) { if (--fuel == 0u) goto done;
                            m0 ^= (unsigned)((unsigned)h0 == (unsigned)(signed char)((unsigned)d0 | a0[u1 & 3u]));
                            f0 = f0 * 0.5f + (float)(((0x7fffffffu & (unsigned)!(unsigned)(p0 || 0x80000000u)) + (fuel / (g0 | 1u))) & 255u);
                            u1 += (u0 ^ garr[i1 & 7u]);
                            *q0 = ~((g1 | p2) / ((unsigned)(w0 >> 29) | 1u));
                            v0 = (unsigned)((int)(0xffffffffu & r0.y) >= (int)(unsigned)!(u3 << (4u & 31u)));
                        }
                    }
                }
                if (u2) break;
                while ((unsigned)(a0[i0 & 3u] < (unsigned)c1)) { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)fuel > (signed char)(unsigned)((int)0x490f4ef8u < (int)u0))) break;
                    if ((unsigned)(*mp || 0xeeb48728u)) break;
                    h0 = (short)((unsigned)(w0 >> 29) / (0x268b42f3u | 1u));
                    if ((unsigned)(0xffffffffu < (unsigned)f0)) {
                        if ((0x964ab736u | (unsigned)((unsigned)x0 < fuel))) break;
                        if (-(unsigned)((unsigned)(r0.x < 5u) || i1)) {
                            if (budget != 0u) { budget -= 1u; u3 = fn0((i0 / (*mp | 1u)), r0.y, garr[u2 & 7u]); }
                        } else {
                            f0 = f0 * 0.5f + (float)((unsigned)(5u && 0x7fffffffu) & 255u);
                            *q0 += (((i1 ^ (unsigned)f0) * (unsigned)b0) >> (u0 & 31u));
                        }
                        if (((unsigned)f0 ^ u3)) break;
                        while ((unsigned)(0x4d780092u < p0)) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(unsigned)(i0 && (unsigned)s0) > (signed char)i0), ((unsigned)e0 * 5u), g0); }
                            f0 = f0 * 0.5f + (float)((unsigned)(0x4618c6u && p2) & 255u);
                            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(w0 >> 29) % (0xffffffffu | 1u)), (unsigned)((int)0x1511125du >= (int)0x10000u), (unsigned)((int)i0 >= (int)0xdef03cd2u)); }
                            m0 ^= (unsigned)s0;
                            break; (void)((unsigned)(w0 >> 29));
                        }
                    } else {
                        e0 = e0 * 0.5L + (long double)(((unsigned)(signed char)((unsigned)((int)(unsigned)e0 >= (int)(unsigned)(w0 >> 29)) & *q0) % (u0 | 1u)) & 1023u);
                        if (((a0[u1 & 3u] + v0) << (u0 & 31u))) goto done;
                    }
                    *mp = (unsigned)((int)((unsigned)((short)a0[u1 & 3u] > (signed char)0x10000u) ^ (unsigned)d0) < (int)(unsigned)((short)(unsigned)b0 > (signed char)m0));
                }
                if (0x7fffffffu) break;
                if ((v0 & (unsigned)(0xffffffffu && u2))) {
                    a0[(0x80000000u - (unsigned)c1) & 3u] = ((unsigned)((int)g0 >= (int)0x9adfa6a1u) + *q0);
                    if (u3 == 7u) return ((unsigned)c0 - ((0x7fffffffu * (unsigned)h1) % (r0.y | 1u)));
                } else {
                    u1 += ((unsigned)(u2 && *mp) / ((unsigned)x0 | 1u));
                    g1 += 0x10000u;
                }
            } else {
                h0 = (short)u2;
                if ((unsigned)(0x7fffffffu || -(unsigned)((short)g1 > (signed char)0x7fffffffu))) break;
                f0 = f0 * 0.5f + (float)((unsigned)b0 & 255u);
                if (budget != 0u) { budget -= 1u; u1 = fn0((0u ^ 7u), (((unsigned)h1 % (p0 | 1u)) % ((unsigned)h1 | 1u)), (0x10000u >> (0xc44718afu & 31u))); }
            }
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (garr[i1 & 7u]) break;
                s0 = (int)(unsigned)((int)6u >= (int)(0x7fffffffu >> (((unsigned)s1 - ((unsigned)c0 - 0xffffffffu)) & 31u)));
                s0 = (int)((unsigned)((short)0xeea8d19u > (signed char)(unsigned)h1) + (unsigned)(unsigned char)(0x1f52d5c5u * g1));
                while (i2++ < 6u && 0x10000u) { if (--fuel == 0u) goto done;
                    m0 ^= (unsigned)(0x80000000u == a0[u1 & 3u]);
                    f0 = f0 * 0.5f + (float)((unsigned)(0x2ac36c10u && ((unsigned)d0 << (1u & 31u))) & 255u);
                    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        *q0 = (r0.y / (g0 | 1u));
                        continue; (void)(((unsigned)c0 << (0x2e7e45fbu & 31u)));
                        w0 = w0 * 6364136223846793005ull + (unsigned)c0;
                        if (((0x722953f8u | (unsigned)c1) % (p0 | 1u))) continue;
                    }
                }
                for (;;) { if (--fuel == 0u) goto done;
                    v0 = (unsigned)(u3 || 6u);
                    if ((m0 >> (*q0 & 31u))) break;
                    u0 = u1;
                }
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(a0[i0 & 3u] && 0u), i0, (unsigned)(unsigned char)(((unsigned)h1 << ((unsigned)c0 & 31u)) * fuel)); }
                    e0 = e0 * 0.5L + (long double)(-(unsigned)(((unsigned)(-(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)e0) && p0) >> ((unsigned)e0 & 31u)) == 0x7fffffffu) & 1023u);
                }
            }
            do { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)0x27d4bc81u << ((unsigned)((int)(unsigned)((int)(unsigned)(0x7fffffffu == fuel) >= (int)8u) >= (int)(unsigned)((int)(unsigned)h1 < (int)(unsigned)c1)) & 63u);
                    if ((unsigned)((unsigned)x0 == (unsigned)(short)(garr[i1 & 7u] & 0x10000u))) break;
                } while (i2++ < 7u && 0x40235bau);
                if ((unsigned)s0) break;
                c0 = (unsigned char)(unsigned)((unsigned)((int)(unsigned)((unsigned)c1 == (unsigned)(unsigned char)(unsigned)((unsigned)(w0 >> 29) < 0x2c7b570u)) < (int)u3) && 9u);
                switch ((0x10000u * (garr[i1 & 7u] / ((unsigned)e0 | 1u))) & 7u) {
                    r0.x = (0x10000u - (unsigned)w0);
                    u0 ^= (unsigned)((int)((unsigned)x0 ^ (u3 << ((unsigned)c0 & 31u))) >= (int)0xdac2833du);
                    u0 = (~(0xffffffffu ? (unsigned)h1 : (unsigned)(x0 >> 70)) % ((unsigned)c0 | 1u));
                    x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)(0x7fffffffu | (((unsigned)f0 * fuel) << (u0 & 31u)));
                }
            } while (i1++ < 5u && (garr[u2 & 7u] >> ((unsigned)((short)(unsigned)d0 > (signed char)0x4559495fu) & 31u)));
            *mp = (unsigned)h0;
            while (i1++ < 3u && 3u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((i2 % (((u3 >> ((unsigned)l0 & 31u)) % (0x7e43587au | 1u)) | 1u)) & 255u);
                e0 = e0 * 0.5L + (long double)(((unsigned)((int)(unsigned)((unsigned)s1 < 0xffffffffu) < (int)*mp) ^ 0xddc54b6u) & 1023u);
                u0 = u0 * 0x9e3779b1u + ((unsigned)e0 & (unsigned)((short)(unsigned)s1 > (signed char)0xffffffffu));
                f0 = f0 * 0.5f + (float)(((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)((unsigned)d0 && (unsigned)(x0 >> 70))) >> ((u0 >> (0x9a826500u & 31u)) & 31u)) & 255u);
            }
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (g0) break;
                h0 = (short)((unsigned)w0 << (0x80000000u & 31u));
            }
            s1 = (int)((unsigned)s1 + ((((unsigned)c1 | 0x7b527275u) & (4u * 0x80000000u)) << (0x347db176u & 31u)));
        }
        u1 = u1 * 0x9e3779b1u + (((unsigned)f0 ? (unsigned)(fuel || 0x10000u) : (unsigned)(w0 >> 29)) >> (g0 & 31u));
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch (((unsigned)w0 ? (unsigned)h1 : g0) & 7u) {
                if (fuel < 8u) return ((unsigned)(signed char)(2u ^ 0x6b2dcd8fu) << (u0 & 31u));
                g0 = (((0xefbbacd2u - i2) << (u2 & 31u)) << (*q0 & 31u));
                q0 = &garr[((garr[i1 & 7u] | (unsigned)x0) - (unsigned)l0) & 7u];
                if (budget != 0u) { budget -= 1u; u3 = fn0(garr[u2 & 7u], 1u, (*mp + *q0)); }
                if ((0x80000000u - (unsigned)!(unsigned)(p0 < (unsigned)h1))) goto L2;
                x0 = x0 * 0x100000001b3ull + (i0 * 0x7fffffffu);
            }
            break; (void)((unsigned)(signed char)(unsigned)((int)i0 < (int)g1));
            goto done;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (0x80000000u) break;
                u3 += (unsigned)((short)0x80000000u > (signed char)(a0[i0 & 3u] * a0[u1 & 3u]));
                if ((unsigned)(unsigned char)(6u % (fuel | 1u))) goto L1;
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0(0xaeeb3c00u, (unsigned)(m0 && 0x4a3983b7u), (unsigned)x0); }
    if ((0x193a611bu >> (u3 & 31u))) goto L0;
    v0 = (((unsigned)f0 / (0xcf073c9cu | 1u)) * r0.y);
    u0 += (0x17e37a7bu + (unsigned)!(unsigned)((short)(unsigned)e0 > (signed char)i0));
    u2 ^= ((unsigned)h1 * (0xffffffffu ^ *mp));
    if ((unsigned)((int)r0.y >= (int)u1)) goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u2 = fn1((g1 << (0x80000000u & 31u)), 0xc8ed654u, (unsigned)((int)9u >= (int)2u)); }
    L0: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u2 = fn1(-(0x10000u & (unsigned)h0), (unsigned)(0x3bb5b96u || garr[u2 & 7u]), (unsigned)((9u % (g0 | 1u)) || (unsigned)(x0 >> 70))); }
    { unsigned t0; double z0; if (((a0[i0 & 3u] ^ (unsigned)h1)) & 1u) { t0 = ((p0 | (unsigned)(w0 >> 29)) - fuel); z0 = (double)(((5u / (0x10000u | 1u))) & 255u); } if (((a0[i0 & 3u] ^ (unsigned)h1)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        h1 = (unsigned short)(h1 + ((unsigned)h0 | (unsigned)b0));
        if ((i0 / ((unsigned)(short)(0x49dff453u - (unsigned)c0) | 1u))) goto done;
        *q0 = (0x163b3d99u << ((unsigned)(short)(((a0[i0 & 3u] / (0x6e05abb1u | 1u)) - m0) | (unsigned)e0) & 31u));
        if ((i1 + 0xd71980b8u)) goto L4;
        r0.x = (((unsigned)b0 | p2) | (unsigned)(3u || 0x7fffffffu));
    }
    while (i0++ < 7u && (unsigned)!(unsigned)(r0.y < 0x8cb3c7a6u)) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            *q0 = ((unsigned)(i0 && (u2 + u3)) | p2);
        }
        if ((unsigned)(((unsigned)d0 + p1) == (unsigned)f0)) {
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (a0[i0 & 3u]) break;
                w0 = w0 * 6364136223846793005ull + (unsigned)(2u == (unsigned)c0);
                l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(r0.x ^ p1));
                if (fuel < 8u) return (g1 | (0x78609879u & (unsigned)e0));
                c1 = (signed char)(i2 | (m0 * p0));
            }
            while ((p2 >> (fuel & 31u))) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(i2 >> ((p0 / ((unsigned)w0 | 1u)) & 31u));
                b0 = ((unsigned)((int)(unsigned)h1 >= (int)(unsigned)s0) | 0x80000000u) != 0u;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)(0xa26dbbfu < (u2 * (unsigned)x0)) & 1023u);
                }
                x0 = x0 * 0x100000001b3ull + (0x8a46b99u << ((unsigned)s0 & 31u));
            }
            v0 = -(unsigned)(9u == garr[i1 & 7u]);
        }
        if ((0xd0069ebau >> ((unsigned)c0 & 31u))) {
            if (((0x10000u / (v0 | 1u)) | 0x80000000u)) break;
            if ((unsigned)((short)i1 > (signed char)u3)) goto L2;
            if ((p0 * (unsigned)((int)0xffffffffu < (int)4u))) break;
            h1 = (unsigned short)(h1 + (unsigned)(unsigned char)((unsigned)f0 % ((unsigned)c0 | 1u)));
        } else {
            u2 ^= ((i2 ^ (unsigned)((int)*mp < (int)-(unsigned)(0xffffffffu && (unsigned)b0))) - (unsigned)h1);
            L1: if (--fuel == 0u) goto done;
        }
        if ((unsigned)((short)7u > (signed char)(unsigned)(*q0 || garr[i1 & 7u]))) break;
    }
    u1 = (0xf4f33736u | (i1 << (a0[u1 & 3u] & 31u)));
    switch (((unsigned)b0 + *mp) & 7u) {
        if ((fuel | (unsigned)((int)p2 < (int)0x10000u))) goto L2;
        { unsigned t1; double z1; if (((unsigned)h1) & 1u) { t1 = *q0; z1 = (double)((p0) & 255u); } if (((unsigned)h1) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)garr[i1 & 7u] < (int)p1)) goto L3;
                    w0 = w0 * 6364136223846793005ull + u1;
                    if ((unsigned)h0) goto L1;
                }
            }
            garr[r0.y & 7u] = ((r0.x ^ g0) & i1);
        }
        if (((unsigned)l0 + a0[u1 & 3u])) break;
    }
    if (fuel < 8u) return (unsigned)((int)(0xc51777du | ((unsigned)e0 * u2)) < (int)0xb838e158u);
    goto L3;
    L2: if (--fuel == 0u) goto done;
    g1 += ((unsigned)c0 ? (unsigned)(w0 >> 29) : (*q0 ? 0x731abbd1u : u1));
    do { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)(garr[i1 & 7u] < 8u) << (5u & 31u)));
        if (0x7fffffffu) break;
        c1 = (signed char)(unsigned)((int)((unsigned)w0 - (unsigned)(short)(unsigned)(0x6e88f00bu && 9u)) < (int)(unsigned)d0);
        garr[(0xffffffffu ^ (unsigned)w0) & 7u] = ((r0.x + u3) & (unsigned)d0);
        { unsigned t2; double z2; if ((-(unsigned)((int)(unsigned)d0 >= (int)(unsigned)((short)i2 > (signed char)0x7fffffffu))) & 1u) { t2 = ((8u * 0x59da4128u) / (m0 | 1u)); z2 = (double)(((0u << ((0xdd1e9d3du + 0x865deaf6u) & 31u))) & 255u); } if ((-(unsigned)((int)(unsigned)d0 >= (int)(unsigned)((short)i2 > (signed char)0x7fffffffu))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)h1 < (int)garr[u2 & 7u]), (unsigned)((int)a0[u1 & 3u] >= (int)u2), ((unsigned)s1 / ((unsigned)w0 | 1u))); }
            f0 = f0 * 0.5f + (float)((unsigned)(signed char)(unsigned)((unsigned)s0 == ((unsigned)h1 ^ (unsigned)(u2 || 1u))) & 255u);
        }
        s1 = (int)((unsigned)s1 + (unsigned)w0);
    } while (i0++ < 4u && (*mp + *q0));
    if (u2) goto L4;
    do { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)(((0x8b6c5fedu % (0x10000u | 1u)) + a0[i0 & 3u]) & 1023u);
        l0 = (long)((unsigned long)l0 + g1);
        if ((0x92fbf37u + 4u)) {
            if (~(unsigned)((short)u0 > (signed char)r0.y)) break;
            L3: if (--fuel == 0u) goto done;
            if ((r0.y + (0x7fffffffu & *q0))) break;
            if ((unsigned)((short)(unsigned)s0 > (signed char)1u)) break;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t3; double z3; if ((((unsigned)s1 ^ garr[i1 & 7u])) & 1u) { t3 = (unsigned)d0; z3 = (double)((((unsigned)(garr[u2 & 7u] < garr[i1 & 7u]) << (u3 & 31u))) & 255u); } if ((((unsigned)s1 ^ garr[i1 & 7u])) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                    if (*mp) break;
                    if (budget != 0u) { budget -= 1u; u2 = fn1(p0, 1u, (7u ^ (unsigned)l0)); }
                    h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(unsigned)((unsigned)(0x10000u && a0[u1 & 3u]) && m0));
                    a0[(u2 % (g1 | 1u)) & 3u] = (((unsigned)((unsigned)c0 && 4u) >> ((unsigned)((short)i1 > (signed char)0xffffffffu) & 31u)) / (0x7fffffffu | 1u));
                    if ((u2 + ((unsigned)w0 << (0u & 31u)))) {
                        L4: if (--fuel == 0u) goto done;
                        u1 = u1 * 0x9e3779b1u + i1;
                        do { if (--fuel == 0u) goto done;
                            break; (void)(r0.y);
                        } while (i2++ < 5u && ((u1 >> (a0[i0 & 3u] & 31u)) / (u1 | 1u)));
                        e0 = e0 * 0.5L + (long double)((unsigned)c0 & 1023u);
                    } else {
                        v0 = (unsigned)c1;
                        g0 = garr[i1 & 7u];
                        if (budget != 0u) { budget -= 1u; u0 = fn0((0xec4be62fu | m0), (u3 >> (v0 & 31u)), (0x88f87025u % (1u | 1u))); }
                        g0 = i2;
                    }
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)(v0 < (unsigned)(u0 || (fuel / (i0 | 1u))));
            }
        } else {
            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(unsigned)((i0 * (unsigned)(6u < (unsigned)h1)) == (v0 << (i2 & 31u)));
            { unsigned t4; double z4; if ((u3) & 1u) { t4 = (*q0 + v0); z4 = (double)((0x70b94a69u) & 255u); } if ((u3) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                g1 += (unsigned)((9u + (unsigned)c0) == (unsigned)(short)(p0 ? (unsigned)x0 : v0));
            }
            c0 = (unsigned char)(0x24149095u * (unsigned)(g1 < i2));
        }
        break; (void)(((unsigned)h0 ? v0 : 3u));
    } while (i0++ < 3u && v0);
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = i1;
        do { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((((unsigned)b0 / (0x6856c279u | 1u)) & (unsigned)f0) & 1023u);
            if (budget != 0u) { budget -= 1u; u2 = fn0(((i1 >> (p2 & 31u)) % ((unsigned)(w0 >> 29) | 1u)), (i1 - (unsigned)(2u && r0.y)), ~(((unsigned)b0 % (r0.x | 1u)) - (unsigned)s1)); }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn1((m0 << ((unsigned)c1 & 31u)), r0.y, 0x7fffffffu); }
                if ((unsigned)(signed char)(*mp % (u2 | 1u))) break;
                if ((*mp ^ p1)) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)r0.x < (int)3u), (unsigned)s1, (unsigned)(*mp && v0)); }
                    u3 ^= (unsigned)(signed char)(u2 + (unsigned)((short)(unsigned)d0 > (signed char)((unsigned)f0 + i2)));
                    *q0 += (unsigned)(*q0 || ((unsigned)((short)g1 > (signed char)0xffffffffu) ^ i2));
                    s1 = (int)((unsigned)s1 + (unsigned)f0);
                }
                goto L2;
            } while (i2++ < 4u && (unsigned)((short)*mp > (signed char)(0x65cd10b5u << ((unsigned)(w0 >> 29) & 31u))));
        } while (i1++ < 7u && ((unsigned)c0 >> (u3 & 31u)));
        do { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((unsigned)b0 & 255u);
            if (((unsigned)l0 - r0.x)) {
                if (((unsigned)d0 % (i2 | 1u))) goto L3;
                *mp = (unsigned)((int)(unsigned)f0 < (int)(2u / (garr[i1 & 7u] | 1u)));
            }
            { unsigned t5; double z5; if ((*mp) & 1u) { t5 = (unsigned)((0x88d4bd8u ^ *q0) < 0xc364ae95u); z5 = (double)((((0x80000000u / (0x7fffffffu | 1u)) >> (p1 & 31u))) & 255u); } if ((*mp) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)w0, 0x80000000u, (u3 | 9u)); }
                w0 = w0 * 6364136223846793005ull + (0xb8f4fadcu + ((unsigned)h1 / ((6u ^ -(unsigned)(0x7fffffffu < r0.x)) | 1u)));
                if ((unsigned)(0xf299e6cau == (unsigned)(u0 < (unsigned)w0))) {
                    v0 = 0x4ca5e6aeu;
                    if (0u) break;
                }
            }
            goto L0;
            b0 = (unsigned)((unsigned)(g1 == p2) || 3u) != 0u;
        } while (i1++ < 4u && ((unsigned)l0 & i0));
    }
    do { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (0x7fffffffu - (unsigned)f0);
        u3 += (unsigned)((int)((unsigned)x0 / (a0[u1 & 3u] | 1u)) >= (int)(unsigned)((short)(i1 % (3u | 1u)) > (signed char)0x80000000u));
    } while (i0++ < 3u && garr[u2 & 7u]);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)l0) break;
            if ((unsigned)((int)(unsigned)b0 < (int)i0)) goto L0;
        } while (i1++ < 6u && (0x10000u * (fuel / ((unsigned)h0 | 1u))));
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0x757d7fbeu) break;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)s1 < (int)p1)) goto L0;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)(w0 >> 29) || p1), (unsigned)((int)(unsigned)l0 >= (int)(unsigned)(v0 && a0[i0 & 3u])), fuel); }
            if ((unsigned)((short)a0[i0 & 3u] > (signed char)r0.x)) break;
            if ((unsigned)(unsigned char)(g1 ^ (unsigned)(0xa842ab99u == (unsigned)f0))) {
                break; (void)(i2);
            }
        }
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)(0x24c42f3cu < 0xb8edb6bfu) || (*q0 % (6u | 1u))));
            }
            if ((g1 + (unsigned)e0)) continue;
            w0 ^= (unsigned long long)(unsigned)f0 << ((unsigned)((int)0x69d48375u < (int)p1) & 63u);
        }
    }
    if ((g1 % (0xbb38385au | 1u))) goto done;
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)!((garr[i1 & 7u] | (unsigned)(x0 >> 70)) - u0));
    } while (i0++ < 3u && (unsigned)l0);
    w0 = w0 * 6364136223846793005ull + (((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x96ec3764u) >> ((unsigned)b0 & 31u)) * (0x6064a30bu / ((unsigned)h0 | 1u)));
    garr[(5u / ((unsigned)x0 | 1u)) & 7u] = 0x10000u;
    u2 += ((unsigned)((short)5u > (signed char)(unsigned)f0) / ((unsigned)(u1 && (unsigned)(w0 >> 29)) | 1u));
    u3 = u3 * 0x9e3779b1u + (unsigned)e0;
    garr[(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)e0) & 7u] = a0[i0 & 3u];
    q0 = &garr[(garr[i1 & 7u] >> ((garr[i1 & 7u] / ((unsigned)((short)r0.y > (signed char)(a0[i0 & 3u] + p1)) | 1u)) & 31u)) & 7u];
    switch (g0 & 7u) {
        switch ((unsigned)(w0 >> 29) & 7u) {
            h1 = (unsigned short)(h1 + 0x7fffffffu);
            if ((p2 ^ (unsigned)c0)) {
                if (i2) {
                    d0 = d0 * 0.5 + (double)((a0[u1 & 3u] ? u0 : (unsigned)s0) & 1023u);
                    m0 ^= ((u0 * a0[i0 & 3u]) / (p1 | 1u));
                } else {
                    goto L0;
                    break; (void)((unsigned)(x0 >> 70));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(*q0, 0x80000000u, u3); }
                s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)f0 < (int)(unsigned)e0));
                b0 = (~(unsigned)(g0 || (unsigned)(w0 >> 29)) % ((unsigned)(unsigned char)(unsigned)((int)g1 < (int)*mp) | 1u)) != 0u;
            }
            i0 = (unsigned)(((unsigned)(x0 >> 70) + *q0) == fuel) & 15u;
            h0 = (short)((0x3bc6430eu - (unsigned)((int)g1 >= (int)(a0[i0 & 3u] % (i0 | 1u)))) ^ g1);
            case 3u: ;
        }
        for (;;) { if (--fuel == 0u) goto done;
            if (fuel < 8u) return (unsigned)((unsigned)s1 || (7u - u0));
        }
        c0 = (unsigned char)((0x4e62b20du + (unsigned)f0) / ((unsigned)(short)(m0 << (*q0 & 31u)) | 1u));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    c1 = (signed char)(unsigned)(g1 == (unsigned)h1);
    L0: if (--fuel == 0u) goto done;
    if (garr[i1 & 7u]) goto L0;
    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)((unsigned)l0 || u1) / (u1 | 1u)), (unsigned)(i0 == 0xfa09a986u), (u2 ^ (unsigned)e0)); }
    r0.y ^= (((r0.y ? 3u : r0.y) | a0[i0 & 3u]) | (unsigned)c1);
    *q0 = (u1 << ((unsigned)((int)fuel >= (int)v0) & 31u));
    goto L2;
    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)w0 || (unsigned)((int)m0 < (int)(*mp % (9u | 1u))));
    switch ((0x2080cc92u * (unsigned)c0) & 7u) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)d0) goto L3;
            L1: if (--fuel == 0u) goto done;
            if (((*q0 | p2) % (m0 | 1u))) goto L4;
            for (;;) { if (--fuel == 0u) goto done;
                if (~(r0.x - garr[i1 & 7u])) goto L1;
                f0 = f0 * 0.5f + (float)(((unsigned)f0 / (0x80cde035u | 1u)) & 255u);
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (0x9cceba59u + (unsigned)x0);
                    if ((unsigned)((unsigned)((short)(unsigned)x0 > (signed char)a0[u1 & 3u]) || p2)) continue;
                    r0.x = ((unsigned)((0u >> (u3 & 31u)) < (unsigned)x0) ^ (unsigned)c0);
                    a0[(unsigned)(0x3dfbacb1u < 5u) & 3u] = (((unsigned)l0 & (unsigned)b0) >> (((u1 * 0x7fffffffu) * 0x80000000u) & 31u));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn2(~(unsigned)(garr[u2 & 7u] == (u0 - u1)), p2, ((unsigned)x0 << (5u & 31u))); }
                i0 = (m0 & fuel) & 15u;
                switch (((unsigned)c1 ? 0x51185e4fu : *q0) & 7u) {
                    if ((0xde5941aau & r0.y)) goto L1;
                    while (0x7fffffffu) { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(v0 * (0xd1cac8f8u ? (unsigned)c1 : 5u));
                        h0 = (short)((7u + (unsigned)s0) - (fuel & 1u));
                        case 3u: ;
                        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u3 = fn2(0xffffffffu, m0, 1u); }
                            L2: if (--fuel == 0u) goto done;
                            case 1u: ;
                        }
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)h1 >= (int)(unsigned)b0));
                    }
                    v0 = (unsigned)x0;
                    x0 = x0 * 0x100000001b3ull + garr[i1 & 7u];
                    if (budget != 0u) { budget -= 1u; u3 = fn2(~((unsigned)(x0 >> 70) / ((unsigned)h0 | 1u)), (u2 | (unsigned)((int)i2 >= (int)(unsigned)l0)), (5u & (unsigned)((short)(unsigned)e0 > (signed char)garr[i1 & 7u]))); }
                    continue; (void)(p0);
                }
            }
            while (i1++ < 6u && ((fuel >> (*q0 & 31u)) & u3)) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)0xbe78ed69u < (int)u1)) break;
                do { if (--fuel == 0u) goto done;
                    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        v0 = (unsigned)((short)(unsigned)(signed char)(unsigned)(g1 == (unsigned)w0) > (signed char)a0[u1 & 3u]);
                        garr[0x4f9f1a1fu & 7u] = i1;
                        r0.y ^= ((unsigned)((int)0x10000u < (int)0x84da863cu) | (0xffffffffu & g1));
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)c1, 0x728f8ea2u, (unsigned)((int)(0x80000000u << (0x6d95f388u & 31u)) < (int)8u)); }
                        if (budget != 0u) { budget -= 1u; u0 = fn0((*mp ^ 9u), ((unsigned)c1 + 0x2a0e19e1u), garr[i1 & 7u]); }
                        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                            L3: if (--fuel == 0u) goto done;
                            if ((0x80000000u >> (4u & 31u))) goto L0;
                        }
                    }
                    if (u2) {
                        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)0xda9c2f7fu > (signed char)(0x80000000u - (unsigned)e0)), (p1 >> ((unsigned)((unsigned)d0 && 8u) & 31u)), (fuel + (unsigned)f0)); }
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)!(unsigned)((fuel | (unsigned)(w0 >> 29)) == 0xc7ccf006u), ((unsigned)c0 << (u1 & 31u)), (unsigned)(signed char)(unsigned)((int)(unsigned)(a0[u1 & 3u] == m0) < (int)r0.x)); }
                    }
                    b0 = (unsigned)(0x10000u < ~((unsigned)(x0 >> 70) ^ (fuel * g1))) != 0u;
                    if ((unsigned)((unsigned)c1 || (unsigned)!(unsigned)((unsigned)h1 < 0xd4582e7au))) {
                        g1 += ((unsigned)(unsigned char)((i2 | r0.x) << (2u & 31u)) + (unsigned)(0x12ecaef2u && 0x10000u));
                        x0 = x0 * 0x100000001b3ull + ((unsigned)x0 - (unsigned)!(unsigned)((unsigned)x0 || (unsigned)((short)(unsigned)l0 > (signed char)0x10000u)));
                        if (fuel < 8u) return (u3 ? 6u : u2);
                        L4: if (--fuel == 0u) goto done;
                    } else {
                        h0 = (short)(unsigned)(a0[i0 & 3u] && r0.y);
                        *q0 += (unsigned)((short)*q0 > (signed char)(unsigned)(garr[i1 & 7u] && ((unsigned)(w0 >> 29) / ((unsigned)s0 | 1u))));
                        h1 = (unsigned short)(h1 + ((unsigned)(signed char)((unsigned)c0 >> (8u & 31u)) >> ((0x80000000u % ((unsigned)((short)2u > (signed char)(unsigned)s1) | 1u)) & 31u)));
                    }
                    v0 = (((0x80000000u | (unsigned)(x0 >> 70)) >> (r0.x & 31u)) / ((unsigned)c1 | 1u));
                } while (i2++ < 3u && (u2 / (0x36763b44u | 1u)));
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        goto L2;
                        if (budget != 0u) { budget -= 1u; u1 = fn2(m0, (unsigned)((int)0x64f64425u >= (int)(unsigned)d0), (*q0 >> (u0 & 31u))); }
                        w0 = w0 * 6364136223846793005ull + g1;
                        m0 ^= (unsigned)(r0.x && ((unsigned)(p2 == g0) | (unsigned)(signed char)(unsigned)((int)m0 < (int)(unsigned)e0)));
                        break; (void)((g0 % (3u | 1u)));
                        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(w0 >> 29) % (0u | 1u)), (unsigned)(u1 || (unsigned)!((unsigned)e0 + 0x1a9b559eu)), -(r0.y >> (~(unsigned)((short)9u > (signed char)(unsigned)(x0 >> 70)) & 31u))); }
                    }
                }
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(x0 >> 70) == 6u), (unsigned)s1, ((unsigned)d0 + (unsigned)(short)(r0.x % (3u | 1u)))); }
        do { if (--fuel == 0u) goto done;
            switch ((unsigned)(a0[u1 & 3u] == (unsigned)f0) & 7u) {
                g0 = 0xffffffffu;
                e0 = e0 * 0.5L + (long double)(0x10000u & 1023u);
            }
            switch ((g0 / ((unsigned)(0x10000u || fuel) | 1u)) & 7u) {
                break; (void)((unsigned)((unsigned)((int)u3 < (int)0x10000u) == i0));
                goto done;
            }
            e0 = e0 * 0.5L + (long double)((0x8dc738e9u | 0x10000u) & 1023u);
            g1 += (((unsigned)w0 - (unsigned)((unsigned)f0 || r0.y)) + 0xd79eae9eu);
        } while (i0++ < 6u && (unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x80000000u));
    }
    goto L3;
    { unsigned t0; double z0; if (((unsigned)((short)(unsigned)(*q0 == (unsigned)d0) > (signed char)a0[u1 & 3u])) & 1u) { t0 = garr[i1 & 7u]; z0 = (double)((2u) & 255u); } if (((unsigned)((short)(unsigned)(*q0 == (unsigned)d0) > (signed char)a0[u1 & 3u])) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        x0 = x0 * 0x100000001b3ull + (1u | *q0);
    }
    goto L2;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((short)(unsigned)b0 > (signed char)i1)) {
            g1 += (u2 - (unsigned)!((unsigned)(unsigned char)(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)s0) + u2));
        }
        { unsigned t1; double z1; if (((0xde9d2e92u * i0)) & 1u) { t1 = (unsigned)((short)u0 > (signed char)i0); z1 = (double)((m0) & 255u); } if (((0xde9d2e92u * i0)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            h0 = (short)p0;
        }
        break; (void)(((0x7fffffffu & i0) ^ (unsigned)l0));
    } while (i0++ < 3u && (unsigned)(0xffffffffu < (unsigned)((short)1u > (signed char)garr[u2 & 7u])));
    u3 = u3 * 0x9e3779b1u + ((unsigned)(x0 >> 70) - 4u);
    if (((0x29b2da1fu & p0) | *q0)) goto L1;
    if ((u1 + (0x91f28707u | (unsigned)s0))) goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn1(~(0xf6b9d0b1u << (((unsigned)h1 | g1) & 31u)), (unsigned)((unsigned)h0 || ((unsigned)x0 ^ 0x5ced78beu)), 0xffffffffu); }
    { unsigned t2; double z2; if (((*q0 + (unsigned)s0)) & 1u) { t2 = (unsigned)((short)g0 > (signed char)0x9ed9609u); z2 = (double)(((0xffffffffu | (u0 % (u3 | 1u)))) & 255u); } if (((*q0 + (unsigned)s0)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        g1 += fuel;
        while (i0++ < 4u && (((unsigned)b0 / (g1 | 1u)) + r0.y)) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((0xffffffffu & (unsigned)h1) && (unsigned)(w0 >> 29)), 0xceead216u, (unsigned)(v0 < (0x10000u | (unsigned)h0))); }
                if ((u2 + (unsigned)w0)) break;
            }
            c0 = (unsigned char)(0xffffffffu - ((unsigned)s1 / ((unsigned)(u3 && p0) | 1u)));
            if (r0.y) {
                v0 = (((u3 / (0u | 1u)) | 0x3318b23cu) & a0[i0 & 3u]);
                while (i1++ < 3u && (unsigned)!(unsigned)(4u || (u0 + 0x4b7b2b92u))) { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((unsigned)w0 || ((unsigned)w0 | 0x684f47cdu))) break;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)i0 >= (int)p0), (unsigned)((unsigned)d0 && (unsigned)!(u1 * p1)), g1); }
                        continue; (void)((unsigned)(p0 && 0x10000u));
                    }
                    s1 = (int)((unsigned)s1 + (unsigned)(short)(unsigned)((int)(0xffffffffu + ~((unsigned)e0 ? (unsigned)c0 : (unsigned)b0)) < (int)garr[u2 & 7u]));
                    e0 = e0 * 0.5L + (long double)(m0 & 1023u);
                    g1 += (((unsigned)x0 % (p1 | 1u)) * 0x10000u);
                    break; (void)((unsigned)(unsigned char)(unsigned)(1u && 9u));
                    m0 ^= (*mp * r0.x);
                }
                f0 = f0 * 0.5f + (float)((unsigned)((((unsigned)(w0 >> 29) | g1) * garr[i1 & 7u]) && (unsigned)c0) & 255u);
                break; (void)((unsigned)(3u < g0));
            }
            while (0x6bcaf502u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)d0 * 7u), (unsigned)((short)(unsigned)((int)p1 < (int)(unsigned)e0) > (signed char)(unsigned)s0), (unsigned)((short)(unsigned)(p2 == 0xb95c98f6u) > (signed char)0x10000u)); }
                g0 = (*q0 | garr[u2 & 7u]);
            }
            l0 = (long)((unsigned long)l0 + (unsigned)(a0[u1 & 3u] && 0xefcf9e24u));
            while ((2u + ((unsigned)b0 ^ (unsigned)b0))) { if (--fuel == 0u) goto done;
                u0 ^= 0x14995157u;
                u3 = (unsigned)((int)((unsigned)(u2 && p2) + p2) >= (int)(u2 ^ 3u));
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)x0, (unsigned)((int)u0 >= (int)0xffffffffu), p0); }
        m0 ^= (unsigned)((unsigned)l0 < 0x80000000u);
        goto L4;
        if (u3 == 7u) return (unsigned)((unsigned)s1 || 5u);
    }
    for (;;) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2((8u << ((u3 - 0u) & 31u)), ((unsigned)x0 - (unsigned)(w0 >> 29)), ((unsigned)d0 - (p0 + fuel))); }
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0x80000000u || (unsigned)d0), ((0x7fffffffu % ((unsigned)h1 | 1u)) * g1), (unsigned)c1); }
        if (fuel < 8u) return ((unsigned)((short)(unsigned)c0 > (signed char)p0) - ((unsigned)s1 | 0xe91389e1u));
        { unsigned t3; double z3; if ((garr[i1 & 7u]) & 1u) { t3 = (unsigned)(a0[i0 & 3u] == (unsigned)(short)(0xdd818c2bu + a0[u1 & 3u])); z3 = (double)(((p2 + (unsigned)(0xf3f628e8u < p0))) & 255u); } if ((garr[i1 & 7u]) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            if (1u) {
                if (~((unsigned)f0 + (unsigned)c1)) goto done;
                u1 = (unsigned)!((unsigned)((unsigned)(signed char)(i0 * 0x262ca26eu) || a0[i0 & 3u]) & 0x10000u);
                break; (void)((0x10000u * p0));
                if (0x7fffffffu) break;
            }
            c0 = (unsigned char)6u;
        }
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(x0 >> 70), (unsigned)f0, (unsigned)((int)~((unsigned)x0 >> (0xe4494a94u & 31u)) < (int)garr[i1 & 7u])); }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t4; double z4; if (((unsigned)b0) & 1u) { t4 = (unsigned)((short)0x7b0c55au > (signed char)(unsigned)(u0 == fuel)); z4 = (double)((0xffffffffu) & 255u); } if (((unsigned)b0) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                if (u3 == 7u) return 0xf8dd8d0au;
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)f0 ^ (unsigned)((int)p1 < (int)(unsigned)l0)), 0xb2161e29u, u3); }
            }
            break; (void)((garr[u2 & 7u] ^ (g1 ^ i0)));
        }
        if ((((unsigned)s1 - garr[i1 & 7u]) + 0xdcf5c9deu)) {
            u3 += p2;
            if (p2) {
                e0 = e0 * 0.5L + (long double)((unsigned)(g1 && 7u) & 1023u);
            } else {
                if ((u2 * (unsigned)h1)) continue;
                switch ((unsigned)(signed char)(unsigned)((a0[u1 & 3u] % (i2 | 1u)) == 9u) & 7u) {
                    case 7u: ;
                    if (r0.y) break;
                    if ((unsigned)(0x7fffffffu || (unsigned)((unsigned)b0 && (unsigned)s0))) goto L4;
                    case 0u: ;
                    u1 = (unsigned)((unsigned)((unsigned)s0 == (unsigned)(signed char)((9u / (*q0 | 1u)) | r0.y)) < a0[u1 & 3u]);
                    { unsigned t5; double z5; if (((unsigned)e0) & 1u) { t5 = (0xaa59083cu ^ (unsigned)h1); z5 = (double)((i1) & 255u); } if (((unsigned)e0) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                        s0 = (int)-(unsigned)(i0 < (unsigned)f0);
                    }
                }
            }
            garr[0x91a8c92fu & 7u] = ((unsigned)((unsigned)s0 == *q0) >> ((unsigned)(x0 >> 70) & 31u));
            b0 = (fuel | (garr[u2 & 7u] * (unsigned)w0)) != 0u;
            if (fuel < 8u) return (unsigned)(m0 && (0xffffffffu / ((unsigned)x0 | 1u)));
            switch (((unsigned)h1 ? *mp : 7u) & 7u) {
                u1 += (unsigned)(garr[u2 & 7u] && (unsigned)((unsigned)s0 && (unsigned)((short)0x73222ddeu > (signed char)garr[i1 & 7u])));
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)r0.y >= (int)i0), -(*q0 ^ r0.x), (unsigned)((i2 >> ((unsigned)d0 & 31u)) && p2)); }
                *mp = (unsigned)e0;
                do { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)h0 || a0[i0 & 3u]) & 255u);
                    x0 = x0 * 0x100000001b3ull + (p2 >> ((unsigned)x0 & 31u));
                    case 2u: ;
                    case 6u: ;
                    m0 ^= ((unsigned)s0 ? p1 : p2);
                    if (budget != 0u) { budget -= 1u; u3 = fn1(a0[u1 & 3u], (unsigned)((int)8u < (int)r0.y), (unsigned)((unsigned)(w0 >> 29) == (3u | garr[u2 & 7u]))); }
                } while (i1++ < 7u && (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)d0));
                f0 = f0 * 0.5f + (float)(((unsigned)s1 + (0u / (0x7fffffffu | 1u))) & 255u);
            }
        } else {
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                u3 += (0x80000000u - ((unsigned)((int)p0 < (int)garr[u2 & 7u]) << (0xffffffffu & 31u)));
                q0 = &garr[(((unsigned)(w0 >> 29) % ((u0 % ((unsigned)c0 | 1u)) | 1u)) >> (p2 & 31u)) & 7u];
                if ((unsigned)e0) break;
                if ((m0 & (unsigned)h1)) goto L1;
                e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)(unsigned char)(0xbf3b4e44u & (unsigned)c1) >= (int)~(unsigned)(u0 || *q0)) & 1023u);
                u2 = u2 * 0x9e3779b1u + 0x80000000u;
            }
            switch ((r0.y - (unsigned)w0) & 7u) {
                break; (void)((unsigned)b0);
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    g1 += ((*q0 >> (9u & 31u)) + (unsigned)((int)(unsigned)(fuel < (unsigned)e0) >= (int)fuel));
                    r0.y ^= *q0;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1((u3 >> ((2u - (unsigned)x0) & 31u)), (unsigned)!((unsigned)c1 - (0x29a9ad2bu % (7u | 1u))), ((unsigned)e0 << ((u2 >> (0u & 31u)) & 31u))); }
                do { if (--fuel == 0u) goto done;
                    case 4u: ;
                    r0.y ^= 0x24f8fdbau;
                    u2 = (unsigned)(short)(-(garr[u2 & 7u] >> ((unsigned)((short)a0[u1 & 3u] > (signed char)u3) & 31u)) * i0);
                } while (i1++ < 3u && (unsigned)h1);
            }
        }
        do { if (--fuel == 0u) goto done;
            if (u3) {
                *q0 += (unsigned)(0x80000000u && (unsigned)((((unsigned)b0 / (a0[i0 & 3u] | 1u)) & v0) || i0));
                if (-(2u >> ((unsigned)s1 & 31u))) continue;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)x0, 6u, 0xffffffffu); }
                { unsigned t6; double z6; if ((((unsigned)h1 | 2u)) & 1u) { t6 = (i1 | r0.y); z6 = (double)(((v0 - (unsigned)d0)) & 255u); } if ((((unsigned)h1 | 2u)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                    if ((0x23548efau ^ (unsigned)(0x6ca27a55u && u3))) break;
                    w0 ^= (unsigned long long)~(0xdaae0b3cu - g1) << (i1 & 63u);
                }
                if (u2) break;
                switch (r0.y & 7u) {
                    c0 = (unsigned char)(unsigned)c1;
                    c1 = (signed char)(unsigned)((int)(unsigned)((int)0xffffffffu >= (int)a0[u1 & 3u]) >= (int)((unsigned)((int)p1 < (int)(unsigned)w0) >> ((unsigned)c1 & 31u)));
                    case 0u: ;
                    goto L4;
                }
            }
            u3 = u3 * 0x9e3779b1u + (unsigned)!(unsigned)((7u ? 0xaa072aa0u : (unsigned)(x0 >> 70)) < 7u);
            a0[(unsigned)((int)4u < (int)(unsigned)x0) & 3u] = (unsigned)((unsigned)f0 || (unsigned)((int)(unsigned)((unsigned)s1 && g1) >= (int)(unsigned)(0x7e9e9fd1u < *q0)));
            c1 = (signed char)(unsigned)c0;
        } while (i1++ < 4u && 0x7fffffffu);
        d0 = d0 * 0.5 + (double)(0xd20dcd6bu & 1023u);
        for (;;) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)(0u < (unsigned)((unsigned)((int)((unsigned)w0 | 0xffffffffu) < (int)garr[u2 & 7u]) == 0x7fffffffu));
            if ((unsigned)(unsigned char)((u1 << (i0 & 31u)) * 0x10000u)) goto L2;
            l0 = (long)((unsigned long)l0 + (a0[i0 & 3u] >> (((unsigned)(unsigned char)((unsigned)b0 * p2) % ((unsigned)d0 | 1u)) & 31u)));
            if (u3 == 7u) return ((unsigned)d0 / ((unsigned)b0 | 1u));
            if (0xc493fe34u) continue;
        }
    }
    if ((unsigned)h1) {
        u3 ^= ~(unsigned)((short)(unsigned)d0 > (signed char)u0);
        i2 = (unsigned)((int)0x1688e15u < (int)(unsigned)!(unsigned)(v0 || g0)) & 15u;
        if (((0x11fa2f3u | 1u) ^ (unsigned)w0)) goto L0;
    } else {
        b0 = (unsigned)(0u || i0) != 0u;
        if (budget != 0u) { budget -= 1u; u3 = fn2(u2, g1, (unsigned)(0x80000000u || (unsigned)(x0 >> 70))); }
        v0 = (p0 / (0xd97e9ecdu | 1u));
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1((i0 & (0u ^ u2)), (unsigned)((short)i0 > (signed char)(unsigned)(x0 >> 70)), 8u); }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (r0.y) {
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (a0[i0 & 3u]) break;
                }
                m0 ^= (unsigned)((int)(unsigned)c1 >= (int)p2);
                u3 = ((unsigned)s1 * 0x7fffffffu);
                w0 = w0 * 6364136223846793005ull + (u2 >> ((unsigned)w0 & 31u));
            }
            w0 = w0 * 6364136223846793005ull + 5u;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                u2 += (unsigned)((int)((unsigned)f0 << (u1 & 31u)) >= (int)(unsigned)((unsigned)((int)0x488561feu >= (int)(unsigned)h1) || 6u));
                *mp = (unsigned)(signed char)(((unsigned)h1 << ((unsigned)s0 & 31u)) - (u3 ? 8u : (unsigned)h1));
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)-(9u << (u3 & 31u)) >= (int)7u), (unsigned)!(v0 >> (g1 & 31u)), (unsigned)(6u == 7u)); }
            }
            if (((unsigned)d0 & 0x80000000u)) {
                u2 = u2 * 0x9e3779b1u + ((*q0 + 0x2492a918u) ^ (unsigned)((int)(unsigned)w0 >= (int)(unsigned)(x0 >> 70)));
                m0 ^= (((unsigned)d0 - p0) / (i2 | 1u));
                e0 = e0 * 0.5L + (long double)(5u & 1023u);
                while (i2++ < 2u && ((g1 / (u2 | 1u)) + (unsigned)d0)) { if (--fuel == 0u) goto done;
                    break; (void)(7u);
                }
                if (((unsigned)b0 << ((unsigned)!(5u - 0x80000000u) & 31u))) goto L1;
            }
        }
    }
    v0 = (unsigned)(((u2 - (unsigned)(w0 >> 29)) - a0[i0 & 3u]) || (0x10000u >> ((unsigned)x0 & 31u)));
    switch ((unsigned)(m0 < u0) & 7u) {
        goto L0;
        *q0 += ((unsigned)((unsigned)(4u && p1) == (unsigned)(w0 >> 29)) * (unsigned)(fuel || u1));
        if (p0) {
            do { if (--fuel == 0u) goto done;
                case 4u: ;
                i0 = i2 & 15u;
            } while (i0++ < 7u && ((unsigned)((int)r0.y >= (int)g0) - 0x80000000u));
            m0 ^= (unsigned)((unsigned)(i1 || ((unsigned)b0 & 0xffffffffu)) < u2);
            case 7u: ;
        }
    }
    garr[(unsigned)(0x7fffffffu == 0x35e0a125u) & 7u] = (unsigned)(unsigned char)((unsigned)!((unsigned)((short)4u > (signed char)0x80000000u) ^ garr[i1 & 7u]) - (unsigned)!(unsigned)((short)0x10000u > (signed char)garr[i1 & 7u]));
    if (((unsigned)h1 ^ 0x80000000u)) goto L1;
    *q0 = 0x10000u;
    w0 ^= (unsigned long long)((unsigned)l0 | 0xab65d163u) << ((unsigned)l0 & 63u);
    if ((unsigned)d0) goto L2;
    if (~(unsigned)((short)0x7fffffffu > (signed char)5u)) {
        switch ((r0.x + (0x6e8f1b88u ^ (unsigned)c1)) & 7u) {
            u0 += ((unsigned)(u0 || 0xffffffffu) | ((unsigned)s0 & 0xffffffffu));
            { unsigned t7; double z7; if (((unsigned)(u2 == p0)) & 1u) { t7 = ((unsigned)x0 - (unsigned)f0); z7 = (double)((garr[u2 & 7u]) & 255u); } if (((unsigned)(u2 == p0)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                x0 = x0 * 0x100000001b3ull + a0[u1 & 3u];
                if (budget != 0u) { budget -= 1u; u1 = fn0((-(p2 | (unsigned)c0) / (a0[u1 & 3u] | 1u)), (unsigned)(signed char)(unsigned)((unsigned)((short)u2 > (signed char)r0.x) || (unsigned)s1), (unsigned)((short)0x301a6700u > (signed char)a0[i0 & 3u])); }
                case 6u: ;
                if ((u0 ^ (unsigned)c1)) break;
                case 7u: ;
            }
        }
        if ((unsigned)(short)(m0 / (p2 | 1u))) goto L4;
    } else {
        u1 = u1 * 0x9e3779b1u + (unsigned)(signed char)(4u / ((unsigned)!(unsigned)((int)u2 >= (int)(unsigned)(unsigned char)((unsigned)c1 / (0x21e4e8d3u | 1u))) | 1u));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0(1u, (unsigned)((unsigned)((unsigned)x0 == 0xfd62f695u) || a0[i0 & 3u]), (r0.y + (unsigned)((unsigned)x0 == r0.y))); }
    if (v0) {
        if (budget != 0u) { budget -= 1u; u3 = fn1((*q0 >> (((unsigned)(x0 >> 70) - (unsigned)h0) & 31u)), (unsigned)!(unsigned)((int)9u >= (int)i0), (unsigned)((int)((unsigned)w0 | (unsigned)(w0 >> 29)) < (int)(unsigned)s0)); }
        if (a0[u1 & 3u]) {
            { unsigned t8; double z8; if (((unsigned)(unsigned char)(unsigned)(0x10000u == 0x80000000u)) & 1u) { t8 = ((unsigned)((int)fuel < (int)u2) >> (p1 & 31u)); z8 = (double)((i0) & 255u); } if (((unsigned)(unsigned char)(unsigned)(0x10000u == 0x80000000u)) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                if ((unsigned)(g0 || 3u)) goto done;
                l0 = (long)((unsigned long)l0 + (unsigned)f0);
                if (p0) {
                    *mp = (3u & (unsigned)((int)v0 >= (int)(unsigned)c0));
                    x0 = x0 * 0x100000001b3ull + ((unsigned)(r0.y || i0) >> ((unsigned)(0x10000u || -(unsigned)((int)p1 >= (int)5u)) & 31u));
                    if (garr[i1 & 7u]) goto L4;
                    h1 = (unsigned short)(h1 + u0);
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn2(*mp, (unsigned)((g1 << ((unsigned)h0 & 31u)) || 0xffffffffu), fuel); }
                    if ((unsigned)(0x7fffffffu == fuel)) goto done;
                    do { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + (unsigned)((short)0xffffffffu > (signed char)p1));
                    } while (i0++ < 7u && (0u << (*q0 & 31u)));
                    if ((3u & 0u)) goto L1;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn2(g0, (unsigned)((int)i2 < (int)(unsigned)((int)g0 >= (int)g0)), (unsigned)((unsigned)s0 || (unsigned)(r0.y && 7u))); }
                g1 += ((unsigned)(i0 < (unsigned)(short)((unsigned)e0 * 0x10000u)) & (unsigned)s1);
                switch ((unsigned)((int)(unsigned)e0 >= (int)((unsigned)b0 & 0x39172641u)) & 7u) {
                    x0 = x0 * 0x100000001b3ull + (unsigned)((int)(garr[i1 & 7u] ^ 1u) < (int)u1);
                    case 2u: ;
                    case 0u: ;
                    if (u3 == 7u) return (0x44dc543au & (unsigned)c1);
                    case 1u: ;
                    m0 ^= ((unsigned)b0 ^ (0x7fffffffu | ((unsigned)((unsigned)(x0 >> 70) == m0) * 0u)));
                }
            }
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((p2 + (garr[i1 & 7u] | 0x4bee2359u))) break;
                *mp = (unsigned)(0x10000u || (unsigned)((int)a0[i0 & 3u] >= (int)3u));
                if ((unsigned)(x0 >> 70)) continue;
            }
            s1 = (int)((unsigned)s1 + ((0x86ac7c9au - 0x360ccfc6u) << (a0[i0 & 3u] & 31u)));
            { unsigned t9; double z9; if ((p2) & 1u) { t9 = (0x80000000u >> ((9u - v0) & 31u)); z9 = (double)((0x10000u) & 255u); } if ((p2) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                if ((0xffffffffu / ((r0.x * p0) | 1u))) {
                    if (0xca89a402u) goto L0;
                    m0 ^= (unsigned)((int)(-((unsigned)l0 | (unsigned)(x0 >> 70)) + 0x7fffffffu) < (int)0x6efc310cu);
                } else {
                    c0 = (unsigned char)a0[i0 & 3u];
                    u2 += ~(unsigned)((unsigned)((unsigned)(3u < garr[u2 & 7u]) && 0x7fffffffu) < i2);
                    if (~(0x14bafaa7u ^ (unsigned)(0xf6a05f7du || 5u))) {
                        u2 += (unsigned)((short)(unsigned)(short)(unsigned)(0x7fffffffu || *q0) > (signed char)8u);
                        x0 = x0 * 0x100000001b3ull + (m0 / (a0[i0 & 3u] | 1u));
                    }
                    goto L4;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn2(v0, (unsigned)b0, ((unsigned)s0 % ((unsigned)d0 | 1u))); }
                garr[(unsigned)((int)(unsigned)w0 >= (int)5u) & 7u] = (unsigned)((int)(r0.y % ((unsigned)h1 | 1u)) >= (int)g0);
            }
            { unsigned t10; double z10; if ((~(8u & (unsigned)b0)) & 1u) { t10 = ((unsigned)((short)u2 > (signed char)u2) ^ 4u); z10 = (double)(((unsigned)(w0 >> 29)) & 255u); } if ((~(8u & (unsigned)b0)) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(*mp < m0), ((unsigned)c0 << ((0x80000000u / ((unsigned)x0 | 1u)) & 31u)), (g1 - g1)); }
                *q0 += (unsigned)(p0 || (8u >> ((unsigned)h0 & 31u)));
                b0 = (a0[u1 & 3u] + i0) != 0u;
                while (0x40b0cc75u) { if (--fuel == 0u) goto done;
                    if ((i1 & (p0 >> (i1 & 31u)))) break;
                    if ((unsigned)(i1 || a0[i0 & 3u])) break;
                    if ((4u & 8u)) continue;
                }
                s0 = (int)(unsigned)(u3 || u1);
                if ((unsigned)(unsigned char)(garr[i1 & 7u] + (unsigned)((unsigned)f0 == g0))) goto L4;
            }
            f0 = f0 * 0.5f + (float)((unsigned)w0 & 255u);
        }
    }
    if ((unsigned)b0) {
        if ((unsigned)((int)0xb28df6fbu < (int)i1)) goto L1;
        if (0x10000u) {
            q0 = &garr[(unsigned)((int)(unsigned)((unsigned)b0 || 0x7fffffffu) >= (int)(unsigned)c0) & 7u];
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)e0 & p2), (p1 | ((unsigned)w0 | u1)), ((unsigned)d0 ^ (unsigned)((int)i2 < (int)garr[u2 & 7u]))); }
            *q0 += (unsigned)(a0[u1 & 3u] && (unsigned)(signed char)(unsigned)((int)fuel >= (int)garr[i1 & 7u]));
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)r0.x > (signed char)(unsigned)c1), (unsigned)((unsigned)b0 || (unsigned)h0), (unsigned)h0); }
            if (budget != 0u) { budget -= 1u; u1 = fn0(0x10000u, garr[i1 & 7u], u0); }
            if (fuel < 8u) return (unsigned)((unsigned)((short)0x77cc80bau > (signed char)garr[u2 & 7u]) && (p2 - 0xad30448du));
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(v0 & 1023u);
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1(5u, 0x256c5d63u, (unsigned)((int)p2 < (int)v0)); }
    } else {
        if (p1) goto L0;
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            continue; (void)((unsigned)((unsigned)d0 < garr[i1 & 7u]));
            { unsigned t11; double z11; if ((garr[u2 & 7u]) & 1u) { t11 = i0; z11 = (double)(((unsigned)(short)(unsigned)(i1 < (0x43127243u + (unsigned)h1))) & 255u); } if ((garr[u2 & 7u]) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
                switch ((unsigned)(w0 >> 29) & 7u) {
                    g1 += ((g0 + (unsigned)h1) - 0x80000000u);
                    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)m0 >= (int)*q0), u3, (0xecc31668u << (p2 & 31u))); }
                    *mp = 0xc8338d10u;
                    q0 = &garr[(unsigned)((int)(unsigned)c1 < (int)(7u ^ (unsigned)(a0[i0 & 3u] || r0.y))) & 7u];
                    *mp = u0;
                    h0 = (short)(unsigned)(garr[u2 & 7u] && 8u);
                }
                *q0 = ((0x970ad02fu * (unsigned)((int)(unsigned)l0 < (int)4u)) & (unsigned)c0);
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(*mp, (fuel >> ((unsigned)s0 & 31u)), (*mp + 9u)); }
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((0x10000u | (unsigned)x0) == (unsigned)c1), 9u, 0x10000u); }
        }
        if ((unsigned)((u1 | r0.y) || (unsigned)h0)) goto L0;
        if ((unsigned)c0) goto L3;
    }
    { unsigned t12; double z12; if ((0xbd67cc3eu) & 1u) { t12 = ((unsigned)c1 << ((unsigned)(signed char)(u0 ^ 0x10000u) & 31u)); z12 = (double)((~(p2 - *mp)) & 255u); } if ((0xbd67cc3eu) & 1u) { u3 += t12; d0 = d0 * 0.5 + z12; }
        if (budget != 0u) { budget -= 1u; u1 = fn2(u0, (unsigned)(a0[u1 & 3u] == p0), ((unsigned)(a0[u1 & 3u] && 0x1cdd793fu) >> (0xb05ec35eu & 31u))); }
    }
    do { if (--fuel == 0u) goto done;
        while (i1++ < 4u && r0.x) { if (--fuel == 0u) goto done;
            while (i2++ < 5u && ((unsigned)(u2 && a0[i0 & 3u]) << (0xffffffffu & 31u))) { if (--fuel == 0u) goto done;
                i2 = (unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)(w0 >> 29)) & 15u;
            }
            garr[(0x80000000u + *q0) & 7u] = (unsigned)((short)p1 > (signed char)(unsigned)(~(unsigned)(m0 < (unsigned)w0) < 0xfae09121u));
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(w0 >> 29) || (garr[i1 & 7u] % ((unsigned)s0 | 1u))), garr[u2 & 7u], g1); }
        }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                u0 ^= ((r0.x + (unsigned)f0) | (r0.x ? a0[i0 & 3u] : g0));
                do { if (--fuel == 0u) goto done;
                    r0.x = (((unsigned)d0 & 0xffffffffu) - (unsigned)(w0 >> 29));
                } while (i0++ < 4u && ((0x7fffffffu | 7u) & 6u));
                if (0x80000000u) goto L1;
                do { if (--fuel == 0u) goto done;
                    if ((u2 & (unsigned)l0)) continue;
                    if ((unsigned)(short)(unsigned)(5u || 0x7fffffffu)) goto L4;
                    for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        switch ((unsigned)(*mp && (unsigned)d0) & 7u) {
                            if (0xc8289c8eu) goto L2;
                        }
                    }
                } while (i0++ < 2u && (unsigned)((int)garr[i1 & 7u] < (int)g1));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)s1 / (fuel | 1u)), p1, 0xdbeaa7dbu); }
            if (((unsigned)f0 | (unsigned)b0)) break;
            if ((a0[u1 & 3u] / ((r0.y ^ (unsigned)w0) | 1u))) {
                if (budget != 0u) { budget -= 1u; u0 = fn0(~(unsigned)((int)a0[i0 & 3u] < (int)(unsigned)(short)(unsigned)((unsigned)(x0 >> 70) && 3u)), (garr[u2 & 7u] / ((unsigned)h1 | 1u)), (unsigned)(i2 && (unsigned)w0)); }
                r0.x = ((6u >> (0x19e6d7a6u & 31u)) & (unsigned)!(1u >> (garr[i1 & 7u] & 31u)));
                if ((unsigned)((short)(0x7fffffffu * 0u) > (signed char)(unsigned)c0)) goto L0;
                if (u3 == 7u) return (unsigned)b0;
            } else {
                q0 = &garr[(unsigned)(signed char)(unsigned)(i2 < ((unsigned)((short)*q0 > (signed char)(unsigned)(0x4efde6f6u && g0)) / ((unsigned)x0 | 1u))) & 7u];
                *q0 = (unsigned)((short)(u3 >> (0x52e5e07cu & 31u)) > (signed char)(unsigned)(r0.x == (unsigned)((int)u1 >= (int)u0)));
                if ((unsigned)((unsigned)s1 && (unsigned)e0)) break;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(3u, (unsigned)(0x7fffffffu == fuel), (p0 >> (g1 & 31u))); }
        }
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (((0xffffffffu & (unsigned)l0) - garr[u2 & 7u])) {
                g0 = ((unsigned)((0x7fffffffu / (v0 | 1u)) == 0x5dcbc0adu) + ((unsigned)s1 << ((unsigned)s0 & 31u)));
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)r0.y > (signed char)(v0 * 7u)), (unsigned)((int)0xc3072333u >= (int)((unsigned)c1 << ((unsigned)(x0 >> 70) & 31u))), (fuel - (unsigned)(signed char)(unsigned)(u2 == i0))); }
                u2 = u2 * 0x9e3779b1u + ((unsigned)(short)((unsigned)c0 * 2u) - (unsigned)b0);
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)b0, garr[u2 & 7u], (i2 >> (0x80000000u & 31u))); }
                if ((0xbc047114u * 0x7fffffffu)) break;
            } else {
                if (r0.y) {
                    if (u3) break;
                }
                if (0x5fc4417cu) {
                    if (g0) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn2(0x37f8a019u, (unsigned)((unsigned)(a0[u1 & 3u] || 0xd8cc952du) || *mp), 0xd2494ec3u); }
                    break; (void)((6u >> ((unsigned)h0 & 31u)));
                    if ((unsigned)!(unsigned)(0u == *q0)) break;
                } else {
                    if (0xfdb703d6u) break;
                    a0[garr[u2 & 7u] & 3u] = ((unsigned)h0 * (unsigned)(6u == (((unsigned)d0 << ((unsigned)s1 & 31u)) - i0)));
                    q0 = &garr[m0 & 7u];
                    m0 ^= ((unsigned)d0 >> ((unsigned)s0 & 31u));
                }
                if ((unsigned)(unsigned char)(0x80000000u & (unsigned)((unsigned)h0 && (unsigned)s0))) break;
                switch (i1 & 7u) {
                    s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)(*mp < g1) < (int)0x4b499c27u));
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)g0 >= (int)(unsigned)s0), (unsigned)s1, g1); }
                    *mp = ((unsigned)b0 ^ p0);
                    case 0u: ;
                    c1 = (signed char)7u;
                    l0 = (long)((unsigned long)l0 + p0);
                }
            }
        }
        *q0 = (unsigned)c0;
        v0 = ((((unsigned)s0 << ((unsigned)s0 & 31u)) / (m0 | 1u)) / ((unsigned)((int)(unsigned)b0 < (int)u0) | 1u));
    } while (i0++ < 4u && (unsigned)(short)(unsigned)(~(u1 >> (0u & 31u)) && r0.x));
    if ((unsigned)!(unsigned)((int)fuel < (int)0x8ebd8156u)) goto L3;
    { unsigned t13; double z13; if (((unsigned)(((unsigned)c1 | 2u) < p1)) & 1u) { t13 = (unsigned)s1; z13 = (double)(((garr[i1 & 7u] | (unsigned)(a0[i0 & 3u] && u1))) & 255u); } if (((unsigned)(((unsigned)c1 | 2u) < p1)) & 1u) { u1 += t13; d0 = d0 * 0.5 + z13; }
        e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)((unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)h1) | (unsigned)((unsigned)e0 || (unsigned)(x0 >> 70))) & 1023u);
        if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)s1 * p2), (unsigned)h0, 0x10000u); }
        u2 ^= (unsigned)((unsigned)x0 || (unsigned)!((unsigned)c1 | (unsigned)c0));
        if ((unsigned)e0) goto done;
    }
    i1 = (unsigned)((p0 << ((unsigned)s1 & 31u)) < 0xeec984c8u) & 15u;
    *q0 += ((unsigned)l0 << ((unsigned)(signed char)(0x291901aau ? (0x43f0f401u & m0) : 0x80000000u) & 31u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u3 = fn2(-(unsigned)((unsigned)e0 || v0), (0x9d213491u / (p1 | 1u)), ((unsigned)c0 | a0[u1 & 3u])); }
    if ((1u ? u1 : (unsigned)c0)) goto L2;
    l0 = (long)((unsigned long)l0 + (unsigned)((int)r0.y < (int)(garr[u2 & 7u] & m0)));
    if ((unsigned)((unsigned)(v0 < g1) == *q0)) goto L1;
    if ((unsigned)((short)p2 > (signed char)0xd75c7f22u)) goto L2;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((0xffffffffu % (garr[i1 & 7u] | 1u))) break;
    }
    if (((unsigned)(signed char)((unsigned)c0 & r0.y) ^ a0[i0 & 3u])) {
        L0: if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)(3u & 255u);
        goto done;
    }
    L1: if (--fuel == 0u) goto done;
    if ((p2 ^ 0x10000u)) {
        if (budget != 0u) { budget -= 1u; u3 = fn0((i1 | (2u & (unsigned)b0)), ((unsigned)((int)u1 < (int)v0) * r0.y), (p0 >> ((unsigned)((short)m0 > (signed char)0xffffffffu) & 31u))); }
        if ((unsigned)((int)0x80000000u >= (int)(unsigned)!(unsigned)((short)(unsigned)w0 > (signed char)garr[u2 & 7u]))) goto done;
        u0 = (unsigned)(0x10000u || (unsigned)((i2 & r0.x) == (unsigned)e0));
        do { if (--fuel == 0u) goto done;
            L2: if (--fuel == 0u) goto done;
            if ((r0.y / (*mp | 1u))) continue;
        } while (i0++ < 6u && 0x6b97d53eu);
    } else {
        while (i0++ < 6u && i0) { if (--fuel == 0u) goto done;
            q0 = &garr[(unsigned)l0 & 7u];
            L3: if (--fuel == 0u) goto done;
            if (((unsigned)d0 + p0)) goto done;
            L4: if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)(0xffffffffu < ((unsigned)f0 % (0x4a7e5411u | 1u)));
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)l0 == (unsigned)!(unsigned)(7u == ~((unsigned)(0x639a21ffu == garr[u2 & 7u]) | (unsigned)s1))) & 255u);
        }
    }
    *mp = ((unsigned)(0x7fffffffu || (unsigned)f0) >> (((unsigned)h1 >> (0xffffffffu & 31u)) & 31u));
    { unsigned t0; double z0; if (((unsigned)(0x36ae9c46u == (unsigned)w0)) & 1u) { t0 = (a0[i0 & 3u] | 0xffffffffu); z0 = (double)((((unsigned)w0 >> ((0xd9089184u * 0x4fa30af3u) & 31u))) & 255u); } if (((unsigned)(0x36ae9c46u == (unsigned)w0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        do { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)b0 / (u2 | 1u)) == (7u + (i1 | i0))));
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((0x825a6215u | r0.x) < garr[i1 & 7u]), ((0x7fffffffu * 9u) + r0.x), (u0 << (i1 & 31u))); }
            u2 = (r0.x * (unsigned)(unsigned char)(unsigned)(0x7fffffffu && 0x56eb5972u));
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((r0.x | (unsigned)(*mp && *q0)));
                if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)w0 * 0xa89cbb62u), (unsigned)((short)*mp > (signed char)(unsigned)x0), p2); }
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((unsigned)x0 && (unsigned)c1), r0.y, -((unsigned)((short)(unsigned)l0 > (signed char)0xffffffffu) / (fuel | 1u))); }
                do { if (--fuel == 0u) goto done;
                    i0 = (unsigned)((short)(unsigned)l0 > (signed char)(m0 / (((unsigned)(signed char)((unsigned)b0 >> (i0 & 31u)) % (p0 | 1u)) | 1u))) & 15u;
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((u0 << (1u & 31u))) {
                            if (((unsigned)(short)(m0 & 8u) >> ((unsigned)d0 & 31u))) goto L1;
                            f0 = f0 * 0.5f + (float)((0xf78e45c0u | 4u) & 255u);
                            q0 = &garr[((unsigned)(signed char)(r0.y | *mp) | (8u ? u2 : (unsigned)e0)) & 7u];
                            if (budget != 0u) { budget -= 1u; u1 = fn1((*q0 / (u0 | 1u)), (unsigned)!(unsigned)(u0 && p1), 0x10000u); }
                            if ((unsigned)((int)(unsigned)(short)((unsigned)c1 << (g1 & 31u)) < (int)p0)) goto L0;
                        }
                    }
                } while (i2++ < 6u && ((7u + u1) * garr[u2 & 7u]));
            }
            g0 = (unsigned)(signed char)(i1 + u1);
        } while (i0++ < 5u && *mp);
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 2u && u0) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (((unsigned)s0 + (unsigned)x0) >> (((unsigned)l0 << ((unsigned)s1 & 31u)) & 31u));
                g0 = (unsigned)l0;
                if (budget != 0u) { budget -= 1u; u3 = fn3((0x44bcbd54u >> (u1 & 31u)), (0x80000000u - 9u), (unsigned)((unsigned)s0 == 0x7fffffffu)); }
            }
            goto L1;
            u3 = (((unsigned)w0 + a0[i0 & 3u]) ^ v0);
            *q0 = (unsigned)!((unsigned)s1 & (0x80000000u & (unsigned)c1));
            if (fuel < 8u) return (unsigned)((unsigned)(x0 >> 70) < (unsigned)(i2 && (unsigned)(0u && (0xc2eec50du / (0xc31d2d44u | 1u)))));
            h1 = (unsigned short)(h1 + ((unsigned)s1 | (p2 | 0x6f888eabu)));
        }
        f0 = f0 * 0.5f + (float)((((unsigned)e0 / (5u | 1u)) ? (unsigned)c1 : (unsigned)((short)(unsigned)w0 > (signed char)g1)) & 255u);
        if ((unsigned)(fuel == *mp)) goto L4;
        if (((unsigned)(signed char)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)i2) | (unsigned)d0)) goto L1;
    }
    g1 += (unsigned)((unsigned)(signed char)(unsigned)((unsigned)e0 || fuel) && (unsigned)(x0 >> 70));
    { unsigned t1; double z1; if (((unsigned)(((unsigned)w0 ^ (unsigned)l0) == 0x7fffffffu)) & 1u) { t1 = (i2 * (unsigned)((unsigned)s1 || (unsigned)c0)); z1 = (double)(((i1 % (7u | 1u))) & 255u); } if (((unsigned)(((unsigned)w0 ^ (unsigned)l0) == 0x7fffffffu)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        s1 = (int)((unsigned)s1 + (m0 * (u1 / ((5u << (((unsigned)(x0 >> 70) << (u3 & 31u)) & 31u)) | 1u))));
        if (i0) goto L3;
        garr[(0xb2557a79u + 8u) & 7u] = ((unsigned)(*q0 == 0xd049f240u) / (0x80000000u | 1u));
        if ((u3 - i1)) goto L4;
        d0 = d0 * 0.5 + (double)((unsigned)(short)(unsigned)((int)(unsigned)(0x7fffffffu == m0) < (int)(0xf21285beu ^ 4u)) & 1023u);
    }
    garr[(garr[u2 & 7u] << ((unsigned)x0 & 31u)) & 7u] = (~((unsigned)l0 ? 0x7ca43d6fu : p2) | (unsigned)(p1 && g1));
    q0 = &garr[(unsigned)((unsigned)!(unsigned)(a0[i0 & 3u] && (unsigned)((short)(unsigned)((int)p0 >= (int)1u) > (signed char)0xffffffffu)) && 0x10000u) & 7u];
    u0 ^= (unsigned)(0x80000000u == *mp);
    v0 = (unsigned)d0;
    e0 = e0 * 0.5L + (long double)((unsigned)(p2 == (unsigned)b0) & 1023u);
    if ((((unsigned)s1 << ((unsigned)h1 & 31u)) ^ a0[u1 & 3u])) {
        u0 += 0x911d87f0u;
        if (budget != 0u) { budget -= 1u; u2 = fn0((0x80000000u ^ (unsigned)(3u && 0x80000000u)), (0x2eacd9a4u + (a0[i0 & 3u] % ((unsigned)b0 | 1u))), (g1 << (g0 & 31u))); }
        f0 = f0 * 0.5f + (float)((unsigned)(((0xcf7e1aa7u % ((unsigned)((unsigned)l0 == 8u) | 1u)) >> (0x10000u & 31u)) == 0x1a57a9f0u) & 255u);
    }
    i0 = ((unsigned)c0 - (unsigned)((int)((unsigned)c0 * 0x95b72983u) >= (int)m0)) & 15u;
    if (-(unsigned)((int)(unsigned)(u3 == 0x7fffffffu) < (int)(unsigned)s0)) {
        if (-((i1 & u0) & 0x6b1a636fu)) goto L3;
        if (((garr[u2 & 7u] + a0[i0 & 3u]) - fuel)) goto L3;
        if (u1) goto L2;
        switch (((v0 - 0xaf3e7b0u) / (7u | 1u)) & 7u) {
            *mp = 2u;
            if (budget != 0u) { budget -= 1u; u3 = fn0((6u ? 0x80000000u : (unsigned)h0), (unsigned)((int)0x62b4fe49u < (int)0xbaa1d053u), (unsigned)(a0[u1 & 3u] || garr[u2 & 7u])); }
        }
        s1 = (int)((unsigned)s1 + 0x7fffffffu);
        goto L3;
    } else {
        w0 = w0 * 6364136223846793005ull + u1;
        if (u3 == 7u) return ((p2 * 0xbc23b7d1u) - (5u << (*mp & 31u)));
        w0 ^= (unsigned long long)v0 << ((unsigned)(short)((unsigned)s0 | (unsigned)((short)r0.x > (signed char)((unsigned)(u0 < (unsigned)s1) - *mp))) & 63u);
    }
    if ((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)e0)) goto done;
    s0 = (int)(unsigned)(short)(garr[u2 & 7u] << (0x80000000u & 31u));
    while ((unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)d0)) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)((unsigned)s0 | 0x6a005f5eu) < (int)(unsigned)f0)) break;
        { unsigned t2; double z2; if (((unsigned)(signed char)((unsigned)((int)0x7fffffffu >= (int)(unsigned)d0) - (unsigned)(w0 >> 29))) & 1u) { t2 = (unsigned)h1; z2 = (double)((p2) & 255u); } if (((unsigned)(signed char)((unsigned)((int)0x7fffffffu >= (int)(unsigned)d0) - (unsigned)(w0 >> 29))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            w0 ^= (unsigned long long)(i0 + (unsigned)c1) << ((u1 + (unsigned)((int)(unsigned)c1 < (int)*q0)) & 63u);
            if ((unsigned)(g0 == ((unsigned)h1 / (p0 | 1u)))) {
                u3 = u3 * 0x9e3779b1u + (unsigned)((int)(0x6759b4b8u ^ (unsigned)e0) < (int)((p0 * 0xffffffffu) - 0x447a3a9u));
                garr[(unsigned)(p1 < 6u) & 7u] = (unsigned)(x0 >> 70);
                w0 ^= (unsigned long long)(u0 << (0xc36a6f06u & 31u)) << ((unsigned)(u1 || (unsigned)(0u && ((unsigned)(unsigned char)(g1 ^ u1) & *mp))) & 63u);
            } else {
                u2 = u2 * 0x9e3779b1u + (0xffffffffu + *mp);
                r0.y ^= (0xc82c72b9u + (unsigned)((short)(unsigned)b0 > (signed char)fuel));
                if (u3) break;
            }
            { unsigned t3; double z3; if ((((unsigned)c0 ^ (unsigned)(0u || u0))) & 1u) { t3 = 5u; z3 = (double)((((r0.x & u1) - garr[u2 & 7u])) & 255u); } if ((((unsigned)c0 ^ (unsigned)(0u || u0))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                r0.y ^= (unsigned)(((unsigned)((unsigned)x0 < 0x73987fd3u) << (9u & 31u)) && 0x10000u);
            }
        }
        garr[(unsigned)w0 & 7u] = -((unsigned)((unsigned)x0 || 6u) | (unsigned)((int)(unsigned)w0 >= (int)0xc63694cfu));
        break; (void)((unsigned)(*q0 == r0.y));
        { unsigned t4; double z4; if (((garr[u2 & 7u] & r0.y)) & 1u) { t4 = (unsigned)(signed char)(0x317c6a5eu - (p2 | 0x2f85ba3fu)); z4 = (double)(((unsigned)((unsigned)((short)fuel > (signed char)(unsigned)c0) || 0x7fffffffu)) & 255u); } if (((garr[u2 & 7u] & r0.y)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            h1 = (unsigned short)(h1 + (unsigned)h0);
            if (u3) break;
            switch ((unsigned)((int)a0[i0 & 3u] >= (int)((unsigned)(x0 >> 70) / (*q0 | 1u))) & 7u) {
                h0 = (short)((unsigned)x0 * a0[u1 & 3u]);
            }
            continue; (void)((unsigned)s1);
            do { if (--fuel == 0u) goto done;
                if (((0xffffffffu >> (8u & 31u)) % (p0 | 1u))) {
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(short)(((unsigned)d0 << (0x8d56475cu & 31u)) << (r0.x & 31u)) || 0x80000000u) & 255u);
                    break; (void)(p0);
                } else {
                    if (0xffffffffu) continue;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)w0, 0x7afeeb1cu, (unsigned)((unsigned)h1 == (unsigned)((short)(unsigned)s0 > (signed char)m0))); }
                do { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)garr[i1 & 7u] << (((unsigned)e0 / ((unsigned)((short)0x7fffffffu > (signed char)m0) | 1u)) & 63u);
                    b0 = (unsigned)((unsigned)s0 || a0[i0 & 3u]) != 0u;
                    if (budget != 0u) { budget -= 1u; u3 = fn3(0x7fffffffu, (unsigned)(unsigned char)(garr[i1 & 7u] + (unsigned)h0), ((unsigned)((unsigned)f0 == p0) | (unsigned)f0)); }
                    g1 += (unsigned)((int)((a0[u1 & 3u] >> (*mp & 31u)) | (unsigned)b0) < (int)0xc29d6c99u);
                    if ((unsigned)((int)p0 < (int)(g0 & (unsigned)d0))) break;
                } while (i2++ < 6u && (0x80000000u | (u2 | g1)));
                if (0xdc32bbf9u) goto L0;
                if (p1) break;
            } while (i1++ < 4u && (0xffffffffu % (0x80000000u | 1u)));
        }
    }
    *mp = r0.y;
    goto L3;
    if ((unsigned)(signed char)(unsigned)(a0[u1 & 3u] == fuel)) goto L3;
    r0.y ^= ((unsigned)e0 * a0[i0 & 3u]);
    v0 = 0x416bdfdcu;
    h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)f0 >= (int)0x7fffffffu));
    i1 = (unsigned)(signed char)(unsigned)((int)(6u % ((unsigned)c1 | 1u)) < (int)u2) & 15u;
    if ((0xffffffffu / (((unsigned)h1 - (unsigned)(x0 >> 70)) | 1u))) goto L1;
    s1 = (int)((unsigned)s1 + ((i0 % (p0 | 1u)) / ((garr[i1 & 7u] << (0xe253cff1u & 31u)) | 1u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 15u, 0xeac28850u, 0xd16a0018u },
        { 8u, 0x9c4f9610u, 0xce089a22u },
        { 5u, 0xaf12ef19u, 0xa9a3a68cu },
        { 13u, 0xa65268f2u, 0xd09be171u },
        { 0u, 0xc7def982u, 0x89a47a87u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
