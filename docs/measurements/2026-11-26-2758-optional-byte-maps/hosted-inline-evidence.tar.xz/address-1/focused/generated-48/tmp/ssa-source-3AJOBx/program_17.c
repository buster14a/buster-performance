// test-ssa-source's program of seed 134000419 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xad0e5b5au, g1 = 0x431ef239u;
static unsigned garr[8] = { 0x5d8188aau, 0xd2aef088u, 0xefb974feu, 0xab0b452au, 0xd33f8e91u, 0x2122ac5u, 0x9194f295u, 0xa929948eu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    a0[0x1831f1d1u & 3u] = (unsigned)(0x7fffffffu && 0x849ecd97u);
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t0; double z0; if (((unsigned)(fuel || *mp)) & 1u) { t0 = ((unsigned)e0 >> (7u & 31u)); z0 = (double)((((unsigned)l0 << ((unsigned)!(unsigned)(r0.y && 0xffffffffu) & 31u))) & 255u); } if (((unsigned)(fuel || *mp)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            if (fuel < 8u) return ((unsigned)((int)0xf15274b0u >= (int)(unsigned)(w0 >> 29)) << ((unsigned)(0x6b20f579u == 4u) & 31u));
        }
    }
    garr[(unsigned)b0 & 7u] = (unsigned)(m0 && 9u);
    garr[(g0 | g0) & 7u] = (i1 << (((unsigned)((int)0xcec42a7bu < (int)u2) | i2) & 31u));
    u2 = ((u3 - (unsigned)e0) - (unsigned)((unsigned)d0 == p0));
    switch ((unsigned)(0xffffffffu && a0[i0 & 3u]) & 7u) {
        if (((unsigned)d0 << ((unsigned)s0 & 31u))) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            garr[3u & 7u] = (unsigned)c1;
            h0 = (short)(unsigned)(signed char)(unsigned)((a0[u1 & 3u] << ((unsigned)d0 & 31u)) || (0x7fffffffu * (0x134b440au / (0x646487e6u | 1u))));
            w0 = w0 * 6364136223846793005ull + (unsigned)(w0 >> 29);
            s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)s1 > (signed char)(unsigned)((int)u0 >= (int)u3)));
        }
        g0 = (unsigned)((0xe772d146u << ((unsigned)((int)(unsigned)(0x80000000u == r0.x) >= (int)*mp) & 31u)) < p0);
        b0 = (5u | (i0 << (garr[i1 & 7u] & 31u))) != 0u;
        case 4u: ;
        L0: if (--fuel == 0u) goto done;
    }
    do { if (--fuel == 0u) goto done;
        if ((0xba33cfe1u ^ (unsigned)s1)) {
            L1: if (--fuel == 0u) goto done;
            garr[(unsigned)c0 & 7u] = u0;
        }
        L2: if (--fuel == 0u) goto done;
    } while (i0++ < 7u && 0x6b8fffc5u);
    { unsigned t1; double z1; if ((((unsigned)b0 + g1)) & 1u) { t1 = (unsigned)((unsigned)((int)garr[i1 & 7u] < (int)u0) && u3); z1 = (double)(((unsigned)b0) & 255u); } if ((((unsigned)b0 + g1)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        q0 = &garr[(unsigned)((unsigned)(garr[i1 & 7u] && (unsigned)h0) || (((unsigned)w0 >> (u0 & 31u)) % ((unsigned)x0 | 1u))) & 7u];
        goto L1;
        *mp = (unsigned)((short)((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)((unsigned)c0 || a0[i0 & 3u])) / (u2 | 1u)) > (signed char)*mp);
    }
    s1 = (int)((unsigned)s1 + (i1 << (((u1 + 0x10000u) * r0.x) & 31u)));
    if ((unsigned)((int)0xffffffffu < (int)(unsigned)((unsigned)d0 && (unsigned)e0))) {
        { unsigned t2; double z2; if (((unsigned)(u3 && (u2 % (fuel | 1u)))) & 1u) { t2 = (unsigned)((int)(unsigned)(p0 && u1) >= (int)u0); z2 = (double)(((unsigned)e0) & 255u); } if (((unsigned)(u3 && (u2 % (fuel | 1u)))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            q0 = &garr[a0[u1 & 3u] & 7u];
            L3: if (--fuel == 0u) goto done;
        }
    }
    goto L1;
    if ((a0[i0 & 3u] & (unsigned)(unsigned char)(unsigned)(m0 && (unsigned)w0))) goto L2;
    L4: if (--fuel == 0u) goto done;
    l0 = (long)((unsigned long)l0 + (u1 ^ 0x9a9404e0u));
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)s0) < (unsigned)(unsigned char)(unsigned)(u0 < u2));
    }
    if (fuel < 8u) return (unsigned)((int)(unsigned)((unsigned)e0 || fuel) < (int)(unsigned)((int)(u3 & fuel) >= (int)0xffffffffu));
    goto done;
    switch ((unsigned)((int)0x10000u < (int)(unsigned)h0) & 7u) {
        break; (void)((r0.y >> (((unsigned)h1 ^ 0xb66feee8u) & 31u)));
        if ((unsigned)((unsigned)d0 < (unsigned)b0)) goto done;
        case 6u: ;
        r0.y ^= (unsigned)(~((unsigned)h0 / ((unsigned)e0 | 1u)) == (unsigned)c0);
        a0[(0x7fffffffu >> (i1 & 31u)) & 3u] = 0xae89c28u;
        case 2u: ;
    }
    h0 = (short)((unsigned)((int)5u >= (int)p0) | (*q0 ? 0x7fffffffu : u3));
    { unsigned t3; double z3; if (((((unsigned)h1 - 9u) % ((unsigned)h0 | 1u))) & 1u) { t3 = fuel; z3 = (double)((a0[i0 & 3u]) & 255u); } if (((((unsigned)h1 - 9u) % ((unsigned)h0 | 1u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        while (i0++ < 4u && (unsigned)c1) { if (--fuel == 0u) goto done;
            a0[(unsigned)(u1 || g1) & 3u] = (i0 / ((unsigned)h1 | 1u));
            while (i1++ < 2u && (unsigned)e0) { if (--fuel == 0u) goto done;
                break; (void)(((u0 ^ 9u) << (garr[u2 & 7u] & 31u)));
                w0 = w0 * 6364136223846793005ull + 0xbfb485eu;
                c1 = (signed char)((g0 >> ((unsigned)(x0 >> 70) & 31u)) ? u3 : ((unsigned)c1 << (fuel & 31u)));
                l0 = (long)((unsigned long)l0 + (r0.x - 0xba8ae805u));
                b0 = (u2 % ((unsigned)(5u == (unsigned)(signed char)(i0 - r0.y)) | 1u)) != 0u;
                break; (void)(i1);
            }
        }
    }
    s1 = (int)((unsigned)s1 + (unsigned)(0x80000000u < ((unsigned)s1 - ~(unsigned)((int)u1 < (int)(unsigned)(w0 >> 29)))));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((0xe52f4632u ? 9u : 0x161f446au)) goto L4;
    do { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (7u / (*mp | 1u)));
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)h1 && ((unsigned)s0 + (unsigned)x0)), (unsigned)((g1 | (unsigned)w0) == (unsigned)l0), 0x7fffffffu); }
        e0 = e0 * 0.5L + (long double)((unsigned)(v0 && ((unsigned)h0 | r0.y)) & 1023u);
        if (budget != 0u) { budget -= 1u; u3 = fn0((u3 & (garr[i1 & 7u] << (u1 & 31u))), (unsigned)!(unsigned)((short)r0.x > (signed char)fuel), (unsigned)((unsigned)((short)0x10000u > (signed char)u0) < g0)); }
    } while (i0++ < 6u && g1);
    u0 = (unsigned)(g1 && (unsigned)c1);
    goto L2;
    goto L4;
    do { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (0x80000000u >> ((unsigned)(signed char)((unsigned)(signed char)(garr[u2 & 7u] - 0xdc52e2efu) * u2) & 31u));
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)(p1 % ((unsigned)c0 | 1u)) > (signed char)g0)) break;
            garr[((unsigned)h0 << ((unsigned)e0 & 31u)) & 7u] = p1;
            q0 = &garr[(6u % ((unsigned)((int)0xe67ef088u >= (int)0x7fffffffu) | 1u)) & 7u];
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)h0 == (r0.y ^ (unsigned)h1)), (6u * (unsigned)(x0 >> 70)), (g0 + a0[i0 & 3u])); }
            if ((unsigned)(short)(8u % (((unsigned)f0 & v0) | 1u))) break;
        }
        f0 = f0 * 0.5f + (float)(((unsigned)((short)i2 > (signed char)0x10000u) % ((unsigned)(signed char)((unsigned)s0 ? garr[u2 & 7u] : i2) | 1u)) & 255u);
    } while (i0++ < 3u && ((3u % (p0 | 1u)) * 2u));
    if (budget != 0u) { budget -= 1u; u1 = fn0(r0.y, (unsigned)x0, (unsigned)((int)(unsigned)((unsigned)e0 == r0.x) < (int)a0[i0 & 3u])); }
    m0 ^= (unsigned)h0;
    e0 = e0 * 0.5L + (long double)((unsigned)(((0xbe8f417cu * (u0 - (unsigned)c0)) ^ p0) < 5u) & 1023u);
    u0 ^= -(unsigned)(0xe5c68a2eu == ((unsigned)h0 << (p2 & 31u)));
    goto L4;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            v0 = 0x18c2a02cu;
            if (i1) break;
        }
        s1 = (int)((unsigned)s1 + (unsigned)((int)0x600b4ca4u >= (int)v0));
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((int)3u < (int)u0) % (8u | 1u)), (unsigned)((unsigned)h0 < *mp), (unsigned)w0); }
            u2 ^= (unsigned)(w0 >> 29);
            q0 = &garr[i2 & 7u];
            if ((-(unsigned)((short)0xffffffffu > (signed char)r0.x) >> (u1 & 31u))) continue;
            if (fuel < 8u) return (unsigned)((int)2u >= (int)g0);
        }
        break; (void)((p0 % ((0x80000000u * (unsigned)s0) | 1u)));
        w0 ^= (unsigned long long)(0x2c7c4a02u % (g0 | 1u)) << ((unsigned)s1 & 63u);
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0(0xffffffffu, (unsigned)h0, (0xffffffffu & (unsigned)d0)); }
        break; (void)(((unsigned)h0 % (m0 | 1u)));
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)((unsigned)((short)g0 > (signed char)(unsigned)c1) / ((a0[u1 & 3u] / (0x78307055u | 1u)) | 1u));
            if ((0xe6c1bcdau ^ v0)) break;
            if (((unsigned)x0 & (unsigned)h0)) break;
        }
        continue; (void)((-(unsigned)((unsigned)s0 < (unsigned)f0) << ((unsigned)e0 & 31u)));
    } while (i0++ < 4u && *q0);
    a0[(unsigned)(0x7fffffffu == u0) & 3u] = p2;
    c1 = (signed char)(unsigned)((unsigned)((unsigned)(unsigned char)(unsigned)((int)m0 >= (int)7u) && (unsigned)((short)0x10000u > (signed char)0x8aa2890du)) < 0xffffffffu);
    h1 = (unsigned short)(h1 + i1);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)(g0 || (unsigned)e0) || i2), 0x80000000u, -(0x10000u + (unsigned)(signed char)(unsigned)((int)(unsigned)b0 >= (int)m0))); }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)((unsigned)d0 == (unsigned)w0) == (unsigned)(w0 >> 29)), ((unsigned)(a0[i0 & 3u] || 0xffffffffu) * a0[u1 & 3u]), (unsigned)((int)(unsigned)h0 >= (int)garr[i1 & 7u])); }
                if ((unsigned)((int)(r0.y & i2) < (int)garr[u2 & 7u])) break;
                if (0x10000u) goto L4;
                switch (((unsigned)(p1 || (unsigned)l0) - i2) & 7u) {
                    if (m0) continue;
                    if ((unsigned)((int)(unsigned)w0 >= (int)0x10000u)) continue;
                    s0 = (int)(unsigned)((i2 - i2) && (r0.x * (unsigned)h1));
                    L0: if (--fuel == 0u) goto done;
                    if ((0xd3eb9208u >> ((unsigned)d0 & 31u))) {
                        if (((unsigned)e0 | 0x80aff674u)) continue;
                    }
                }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((u0 - fuel), 0x10000u, (unsigned)!(unsigned)((short)u1 > (signed char)garr[i1 & 7u])); }
            u2 = (unsigned)((unsigned)d0 == 4u);
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)0u >= (int)p2), (unsigned)!(0u / ((unsigned)((int)(unsigned)l0 >= (int)p1) | 1u)), ((unsigned)(2u && 0xccf8180cu) + p2)); }
            if ((unsigned)(unsigned char)(unsigned)((int)0x4becf201u < (int)m0)) continue;
            L1: if (--fuel == 0u) goto done;
        }
        c0 = (unsigned char)9u;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            g0 = ((unsigned)f0 ? (0x80000000u << (garr[u2 & 7u] & 31u)) : ((unsigned)h0 | 0xe2ae5636u));
            u1 = u1 * 0x9e3779b1u + (i2 ^ (unsigned)((unsigned)(i2 < 3u) && (0xf1056ddfu + (unsigned)b0)));
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0(((u1 ^ p2) - (unsigned)(w0 >> 29)), ((unsigned)b0 - (unsigned)(signed char)(p2 - 8u)), ((*mp * u3) ^ 0u)); }
    if (budget != 0u) { budget -= 1u; u0 = fn0((0x98e72e0du % (0x7fffffffu | 1u)), (unsigned)((int)garr[i1 & 7u] < (int)*mp), ((unsigned)(fuel == u1) * (unsigned)b0)); }
    g0 = (0x10000u << (((unsigned)e0 / (i2 | 1u)) & 31u));
    if (u3 == 7u) return u3;
    l0 = (long)((unsigned long)l0 + (r0.y ^ (unsigned)((unsigned)((int)0x3622b673u < (int)(unsigned)l0) == (unsigned)((int)a0[i0 & 3u] < (int)fuel))));
    switch (((unsigned)h1 - (u2 << (r0.y & 31u))) & 7u) {
        case 1u: ;
        s0 = (int)(unsigned)((unsigned)(short)(unsigned)((unsigned)f0 < u2) && ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)h0) - 0x80000000u));
        if ((~((unsigned)s1 | 0x10000u) ^ i0)) {
            *mp = fuel;
            if ((unsigned)(signed char)(0u / ((unsigned)l0 | 1u))) break;
            c0 = (unsigned char)(4u << (a0[i0 & 3u] & 31u));
        } else {
            if ((0x6b4fe374u ? (unsigned)x0 : r0.y)) goto L4;
            if (2u) goto L3;
            goto done;
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= ((*mp >> (garr[u2 & 7u] & 31u)) * (0u & 0xffffffffu));
                L2: if (--fuel == 0u) goto done;
                case 7u: ;
                c0 = (unsigned char)((r0.y ^ (0xac3eaddau / (0x9630465fu | 1u))) ? r0.y : 0xa7a9c60eu);
            }
        }
        case 5u: ;
        garr[(p2 >> (u3 & 31u)) & 7u] = (unsigned)((int)(unsigned)f0 < (int)((unsigned)s1 & (unsigned)f0));
    }
    { unsigned t0; double z0; if ((((unsigned)c0 ^ 0x10000u)) & 1u) { t0 = (unsigned)(*mp || 0xffe0fe43u); z0 = (double)((*mp) & 255u); } if ((((unsigned)c0 ^ 0x10000u)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        L3: if (--fuel == 0u) goto done;
        if (~(unsigned)((int)u0 >= (int)u2)) goto L4;
        while (i0++ < 6u && (unsigned)((int)(unsigned)((int)(unsigned)c1 < (int)r0.y) >= (int)i0)) { if (--fuel == 0u) goto done;
            switch (((0xad183998u ^ 0x80000000u) | (unsigned)d0) & 7u) {
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)(r0.x < r0.x));
                    c1 = (signed char)((unsigned)b0 * 0xa69aa6d2u);
                    L4: if (--fuel == 0u) goto done;
                    v0 = (((unsigned)h1 << (g0 & 31u)) + 0x2359cbbu);
                }
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    while (i2++ < 3u && ((unsigned)(6u && (unsigned)c1) & u2)) { if (--fuel == 0u) goto done;
                        if ((unsigned)(garr[u2 & 7u] || 0x7fffffffu)) goto L3;
                        case 2u: ;
                        r0.y ^= 1u;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((0x58c00f71u >> (a0[i0 & 3u] & 31u)), (unsigned)s1, 4u); }
                    }
                    switch ((unsigned)(r0.x == (0x7fffffffu % (*q0 | 1u))) & 7u) {
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)a0[i0 & 3u] >= (int)2u), (0x7fffffffu - 0x7483bd46u), (unsigned)(p2 && ((unsigned)d0 - 0x71dfd002u))); }
                        i2 = i2 & 15u;
                        x0 = x0 * 0x100000001b3ull + (7u * (0xf9131ad9u << ((unsigned)x0 & 31u)));
                        u3 = u3 * 0x9e3779b1u + (unsigned)((short)p2 > (signed char)(unsigned)l0);
                    }
                    if (((garr[i1 & 7u] << (0xd6a08de2u & 31u)) ^ g0)) break;
                    case 6u: ;
                }
            }
        }
        while (i0++ < 3u && ((unsigned)x0 >> (u3 & 31u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(0x80000000u, (unsigned)((short)garr[u2 & 7u] > (signed char)0xffffffffu), (unsigned)((unsigned)h1 && fuel)); }
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + 5u);
                if ((unsigned)((unsigned)((int)(unsigned)e0 >= (int)0x10000u) < 0xdb055130u)) break;
                if (budget != 0u) { budget -= 1u; u2 = fn0(v0, 1u, (4u & 0xffffffffu)); }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)3u >= (int)u0), (unsigned)(u0 || (0x7fffffffu | (unsigned)b0)), g0); }
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0(((0xffffffffu / (0x10000u | 1u)) | i0), (unsigned)((int)r0.x < (int)(unsigned)s1), (unsigned)(u1 || (unsigned)s1)); }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0xffffffffu < u3), (unsigned)!(unsigned)(u1 && (i0 % (0x7fffffffu | 1u))), (unsigned)((short)0xffffffffu > (signed char)r0.y)); }
        }
    }
    while (i0++ < 7u && (unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)(unsigned char)((unsigned)((unsigned)(x0 >> 70) && 0x7fffffffu) + (unsigned)((int)(unsigned)f0 < (int)0x7fffffffu));
        i1 = ((unsigned)(4u < 0x613c390bu) >> ((unsigned)((unsigned)l0 && ((unsigned)s0 >> (i1 & 31u))) & 31u)) & 15u;
    }
    if ((garr[u2 & 7u] + (unsigned)((int)m0 >= (int)(unsigned)l0))) {
        switch (u2 & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)s1, (unsigned)((unsigned)((int)(unsigned)x0 < (int)(unsigned)s1) || p1), m0); }
            switch ((unsigned)(unsigned char)(0xffffffffu - (unsigned)l0) & 7u) {
                if (((unsigned)l0 | garr[i1 & 7u])) goto L3;
                while (i0++ < 5u && (unsigned)((int)g1 < (int)(unsigned)(9u && m0))) { if (--fuel == 0u) goto done;
                    if (1u) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((2u ^ (p0 - p1)), *mp, (unsigned)h1); }
                    e0 = e0 * 0.5L + (long double)(0x1016eb12u & 1023u);
                    *q0 += -(unsigned)((unsigned)c1 || (unsigned)((short)0x8c5dc885u > (signed char)g0));
                }
                if (((unsigned)((int)0xffffffffu < (int)(unsigned)e0) | garr[u2 & 7u])) goto L1;
                v0 = ~(-((8u << (u2 & 31u)) + (unsigned)e0) & 0x7fffffffu);
                if ((unsigned)(m0 == (unsigned)d0)) goto L2;
                e0 = e0 * 0.5L + (long double)(-((0x10000u ? (unsigned)(short)(*mp ^ i1) : *q0) >> (a0[i0 & 3u] & 31u)) & 1023u);
            }
            case 4u: ;
            if ((u3 ^ m0)) {
                if (((unsigned)w0 << ((unsigned)l0 & 31u))) goto L1;
                if (u1) {
                    if (garr[u2 & 7u]) goto L1;
                    e0 = e0 * 0.5L + (long double)(u2 & 1023u);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(x0 >> 70) | (unsigned)h1), (unsigned)!(unsigned)((int)0x10000u >= (int)((unsigned)d0 << (m0 & 31u))), (m0 & garr[u2 & 7u])); }
                } else {
                    a0[(unsigned)(0x185bc5a4u < (unsigned)d0) & 3u] = (unsigned)(0xffffffffu == p0);
                }
                if (0x10000u) break;
                do { if (--fuel == 0u) goto done;
                    goto L4;
                } while (i0++ < 3u && ((unsigned)f0 >> ((1u * 0x43641715u) & 31u)));
                h1 = (unsigned short)(h1 + ((7u >> (7u & 31u)) >> ((unsigned)s1 & 31u)));
                while (i0++ < 2u && (unsigned)(short)((unsigned)s1 ^ u2)) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)f0);
                    if (u3 == 7u) return ((unsigned)b0 * 0x80000000u);
                    default: ;
                    break;
                    *q0 = ((unsigned)e0 | ((unsigned)!(unsigned)((int)0u >= (int)6u) | (unsigned)((int)garr[u2 & 7u] < (int)u3)));
                }
            }
            case 7u: ;
        }
    } else {
        g1 += (unsigned)((9u >> (garr[i1 & 7u] & 31u)) == ((unsigned)x0 << (garr[u2 & 7u] & 31u)));
    }
    if (7u) goto L3;
    switch (((0x10000u - (unsigned)h1) & 6u) & 7u) {
        u3 += (unsigned)(short)((unsigned)(2u < 0xd249c7edu) & (unsigned)(x0 >> 70));
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if (((0x10000u / (r0.x | 1u))) & 1u) { t1 = (u0 ^ ~(m0 / (i0 | 1u))); z1 = (double)((i2) & 255u); } if (((0x10000u / (r0.x | 1u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                w0 = w0 * 6364136223846793005ull + (unsigned)!(9u >> ((unsigned)(a0[i0 & 3u] < (unsigned)(u1 || *mp)) & 31u));
                case 3u: ;
            }
            f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)((int)(0x539f3054u % (p1 | 1u)) < (int)0x5b4e7648u) >= (int)(u0 & (unsigned)(w0 >> 29))) & 255u);
            if (((unsigned)(*mp == (unsigned)e0) | (unsigned)f0)) goto L4;
            { unsigned t2; double z2; if ((0x7fffffffu) & 1u) { t2 = (p0 / ((unsigned)h1 | 1u)); z2 = (double)(((i2 * (unsigned)w0)) & 255u); } if ((0x7fffffffu) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                if ((unsigned)((unsigned)((int)0x80000000u >= (int)1u) == (unsigned)f0)) break;
                v0 = (8u ? 2u : 5u);
                if ((fuel - (5u / (0xffffffffu | 1u)))) goto L4;
                if (budget != 0u) { budget -= 1u; u3 = fn0(((a0[i0 & 3u] & (unsigned)e0) / (0x9d8963ceu | 1u)), (0u >> (p2 & 31u)), (g1 % ((unsigned)(w0 >> 29) | 1u))); }
                continue; (void)((unsigned)((int)(unsigned)x0 < (int)u2));
            }
        }
        if ((r0.y / (g0 | 1u))) {
            { unsigned t3; double z3; if ((r0.y) & 1u) { t3 = garr[i1 & 7u]; z3 = (double)((((unsigned)((unsigned)e0 && i0) / (4u | 1u))) & 255u); } if ((r0.y) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                h1 = (unsigned short)(h1 + (*mp * ((unsigned)x0 << ((unsigned)((int)g1 < (int)(unsigned)(u0 == p0)) & 31u))));
                if (p1) {
                    if (((unsigned)e0 << ((unsigned)c1 & 31u))) goto L3;
                }
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(unsigned char)((unsigned)f0 ^ g1) < -((unsigned)(signed char)(unsigned)(4u < u2) >> ((unsigned)b0 & 31u))) & 1023u);
                if ((((unsigned)h0 | (unsigned)s1) % ((unsigned)e0 | 1u))) break;
                *q0 += (unsigned)(short)(0x7fffffffu + (i0 & a0[i0 & 3u]));
                *mp = (unsigned)(~(~((unsigned)f0 ^ (0x8230a857u & i2)) % (i2 | 1u)) < (unsigned)b0);
            }
            case 6u: ;
            w0 = w0 * 6364136223846793005ull + ((v0 / (0x7fffffffu | 1u)) - (unsigned)(m0 < ((unsigned)b0 >> (p2 & 31u))));
            if (((unsigned)(signed char)(0x80000000u & (unsigned)f0) >> (i1 & 31u))) goto L0;
        } else {
            if ((unsigned)((int)(unsigned)h0 < (int)garr[u2 & 7u])) goto done;
        }
    }
    if ((unsigned)((int)(0x73e2416u * a0[u1 & 3u]) < (int)(unsigned)c0)) {
        goto done;
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(~(unsigned)((int)0xa35ea8b2u < (int)(unsigned)(short)(0x7fffffffu / (g0 | 1u))), i0, m0); }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(unsigned)((short)0xd50e8adbu > (signed char)r0.x), (unsigned)(signed char)(unsigned)((unsigned)h1 == (unsigned)c1), (unsigned)(v0 && (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)e0))); }
            } while (i1++ < 6u && (unsigned)((0x10000u / ((unsigned)x0 | 1u)) && 0x7fffffffu));
            garr[4u & 7u] = (unsigned)s1;
        } while (i0++ < 6u && (p2 ^ (unsigned)s1));
        s1 = (int)((unsigned)s1 + (unsigned)(*mp < *q0));
    } else {
        r0.y ^= u3;
        g1 += 0x3067352au;
        s0 = (int)(unsigned)((int)((unsigned)((int)0x7fffffffu >= (int)(unsigned)x0) - (unsigned)c1) < (int)(unsigned)((short)p1 > (signed char)u2));
        b0 = (unsigned)x0 != 0u;
    }
    b0 = 5u != 0u;
    switch ((0xffffffffu | (unsigned)s1) & 7u) {
        { unsigned t4; double z4; if (((u2 - (unsigned)(0x17b649fbu || (unsigned)d0))) & 1u) { t4 = (u0 / (r0.y | 1u)); z4 = (double)(((unsigned)(0xafb354a5u < (unsigned)(signed char)(i2 << ((unsigned)c1 & 31u)))) & 255u); } if (((u2 - (unsigned)(0x17b649fbu || (unsigned)d0))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)b0 < (int)(unsigned)s0), 2u, 0x10000u); }
        }
        u0 += (unsigned)((int)(unsigned)(unsigned char)((unsigned)c1 >> (u3 & 31u)) < (int)-(unsigned)((unsigned)(v0 && u0) && m0));
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(unsigned)(((unsigned)l0 ^ (unsigned)s0) || (unsigned)h0), 5u, (1u | (unsigned)(unsigned char)(*q0 & u3))); }
        case 3u: ;
    }
    if ((unsigned)((unsigned)d0 == r0.x)) goto L2;
    do { if (--fuel == 0u) goto done;
        g1 += i0;
    } while (i0++ < 3u && (unsigned)((int)(unsigned)l0 >= (int)0xa30bce9fu));
    d0 = d0 * 0.5 + (double)((((garr[i1 & 7u] - p1) >> ((unsigned)l0 & 31u)) >> ((unsigned)e0 & 31u)) & 1023u);
    if (budget != 0u) { budget -= 1u; u2 = fn0(((p2 >> ((unsigned)f0 & 31u)) - fuel), ((0u << (7u & 31u)) % ((unsigned)s1 | 1u)), u3); }
    if ((unsigned)!(p1 | a0[u1 & 3u])) goto L0;
    switch ((unsigned)(a0[i0 & 3u] < u0) & 7u) {
        if (fuel) {
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)h0, (unsigned)(short)((unsigned)((short)g1 > (signed char)garr[i1 & 7u]) - 0x7c9feb9au), 4u); }
            case 5u: ;
            u2 = u2 * 0x9e3779b1u + p2;
            if ((unsigned)((short)(unsigned)(garr[u2 & 7u] == a0[i0 & 3u]) > (signed char)g1)) {
                case 3u: ;
                while ((0x8cfdc222u & u1)) { if (--fuel == 0u) goto done;
                    u0 += (unsigned)(u2 == (unsigned)(u0 || ((unsigned)w0 ^ a0[u1 & 3u])));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((v0 | 0xa5546befu) && (unsigned)l0), 0xffffffffu, *q0); }
                    default: ;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((g1 ? r0.x : garr[u2 & 7u]), (unsigned)(signed char)(v0 & -(unsigned)((int)6u < (int)r0.y)), (u3 << (((unsigned)l0 & 5u) & 31u))); }
                while (i0++ < 3u && (unsigned)e0) { if (--fuel == 0u) goto done;
                    s0 = (int)(((a0[u1 & 3u] & p2) ^ 0u) & (unsigned)(fuel || u1));
                    m0 ^= (p1 | (fuel - g1));
                    q0 = &garr[((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)d0) << (2u & 31u)) & 7u];
                    u3 += ((unsigned)h1 + r0.y);
                    continue; (void)((unsigned)e0);
                }
                if ((i2 << (8u & 31u))) {
                    *q0 += ((unsigned)h1 % ((i1 - ((i1 & u2) % (u0 | 1u))) | 1u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)u1 > (signed char)i2), g1, (((unsigned)d0 >> (2u & 31u)) / (g1 | 1u))); }
                    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (2u) continue;
                    }
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        v0 = (9u | (unsigned)e0);
                    }
                    garr[u0 & 7u] = (unsigned)((a0[u1 & 3u] | ((unsigned)f0 - (unsigned)(unsigned char)(0x80000000u / (i1 | 1u)))) || 0x80000000u);
                }
                while (i0++ < 5u && (unsigned)((int)3u < (int)u2)) { if (--fuel == 0u) goto done;
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            case 6u: ;
                            f0 = f0 * 0.5f + (float)((unsigned)((short)0x10000u > (signed char)(unsigned)c1) & 255u);
                            if (budget != 0u) { budget -= 1u; u1 = fn0((g1 >> ((unsigned)h1 & 31u)), (unsigned)(4u || 0x739d2ffcu), (a0[u1 & 3u] / ((unsigned)s0 | 1u))); }
                            s1 = (int)((unsigned)s1 + 0x80000000u);
                            if ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)x0)) continue;
                        } while (i2++ < 7u && (unsigned)f0);
                        if (((0x9c9debebu << (u2 & 31u)) & r0.y)) goto L0;
                        garr[(p0 - garr[u2 & 7u]) & 7u] = (i2 / ((unsigned)(signed char)(r0.x * u2) | 1u));
                        case 0u: ;
                        m0 ^= 0xffffffffu;
                    }
                    case 1u: ;
                }
            } else {
                u1 ^= garr[u2 & 7u];
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)fuel < (int)(8u | (unsigned)h1));
                garr[((unsigned)w0 << ((unsigned)x0 & 31u)) & 7u] = a0[u1 & 3u];
                r0.y ^= ((0xa0d8bedbu / ((unsigned)(unsigned char)((unsigned)x0 & 0u) | 1u)) | (u3 + (unsigned)l0));
            }
        }
        break;
    }
    v0 = (unsigned)(0xffffffffu < (unsigned)((int)(unsigned)((unsigned)(x0 >> 70) == garr[u2 & 7u]) >= (int)(0xae9d7fbu ^ fuel)));
    { unsigned t5; double z5; if (((unsigned)((int)9u >= (int)((unsigned)c1 / ((unsigned)d0 | 1u)))) & 1u) { t5 = ((unsigned)(0xffffffffu == 2u) + 0xc39fd89bu); z5 = (double)(((((unsigned)(w0 >> 29) | p0) | g1)) & 255u); } if (((unsigned)((int)9u >= (int)((unsigned)c1 / ((unsigned)d0 | 1u)))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
        s1 = (int)((unsigned)s1 + i1);
        a0[a0[u1 & 3u] & 3u] = (i2 ? 9u : (unsigned)h0);
        if (fuel < 8u) return (garr[u2 & 7u] / ((unsigned)(*q0 || i2) | 1u));
        garr[v0 & 7u] = (unsigned)(3u || 0xffffffffu);
        g0 = (0x7fffffffu | (a0[i0 & 3u] - (unsigned)((unsigned)l0 == (unsigned)c0)));
    }
    r0.x = 0x7fffffffu;
    if ((unsigned)((short)a0[i0 & 3u] > (signed char)(2u - 0xf10cd3c8u))) {
        if (u3 == 7u) return ((unsigned)((short)0x10000u > (signed char)0u) | ((unsigned)(signed char)(unsigned)(5u < v0) * 4u));
    }
    goto L2;
    goto done;
    goto L4;
    q0 = &garr[((unsigned)(0xaf233fbbu == garr[i1 & 7u]) + 6u) & 7u];
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    u3 ^= -((0xffffffffu + (unsigned)(m0 < p2)) >> (((unsigned)w0 | 0x80000000u) & 31u));
    if ((unsigned)((int)0x80000000u < (int)v0)) {
        if (budget != 0u) { budget -= 1u; u2 = fn0(p2, (unsigned)!(fuel + (unsigned)((short)*q0 > (signed char)i1)), 0xffffffffu); }
        switch (((unsigned)d0 % (0x56f7e86cu | 1u)) & 7u) {
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(0x80000000u + (unsigned)c0) << (p0 & 63u);
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = (0xffffffffu * (p0 << ((unsigned)d0 & 31u)));
                    L0: if (--fuel == 0u) goto done;
                }
                if (u3 == 7u) return ((r0.x >> (garr[u2 & 7u] & 31u)) ? (unsigned)l0 : 0x80000000u);
            } while (i0++ < 3u && ((unsigned)f0 << (fuel & 31u)));
            f0 = f0 * 0.5f + (float)(((0x7fffffffu << (u0 & 31u)) << ((unsigned)(6u == (unsigned)(8u && u3)) & 31u)) & 255u);
            switch (0xabae3087u & 7u) {
                *mp = (unsigned)(unsigned char)(unsigned)((short)((unsigned)(unsigned char)(unsigned)((int)9u >= (int)(unsigned)(x0 >> 70)) & g0) > (signed char)(0x3e794a56u & 0xb674d7b6u));
                f0 = f0 * 0.5f + (float)(((unsigned)(p0 == (unsigned)s1) - (unsigned)((int)0x10000u >= (int)(unsigned)c0)) & 255u);
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)(x0 >> 70) && 4u), ((*mp / (0x295b7de4u | 1u)) + i1), 0x1db4da5au); }
            }
        }
    } else {
        m0 ^= ((unsigned)((0xffffffffu >> (v0 & 31u)) || garr[i1 & 7u]) | (unsigned)((int)g0 >= (int)r0.y));
        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)f0 & 0xffffffffu), (unsigned)((int)(unsigned)e0 < (int)(unsigned)(short)(g1 >> (m0 & 31u))), (unsigned)e0); }
        if (budget != 0u) { budget -= 1u; u3 = fn1(u2, ((unsigned)b0 % (((unsigned)e0 * 0x80000000u) | 1u)), g1); }
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((u3 << (((unsigned)h0 / (4u | 1u)) & 31u))) {
            if ((unsigned)(garr[u2 & 7u] || (i2 + r0.x))) break;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)!((unsigned)(0x7fffffffu < i1) + garr[i1 & 7u]), (unsigned)(r0.x && (unsigned)((int)u2 < (int)0u)), (unsigned)d0); }
        } else {
            goto L1;
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)x0 & (u1 / (a0[i0 & 3u] | 1u))), (unsigned)x0, (unsigned)c1); }
            { unsigned t0; double z0; if ((0x9bd9265cu) & 1u) { t0 = (g1 - (0x7fffffffu - 0xffffffffu)); z0 = (double)(((u3 + garr[u2 & 7u])) & 255u); } if ((0x9bd9265cu) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                w0 = w0 * 6364136223846793005ull + 0x4ce0ee6eu;
                L1: if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + *q0);
                r0.y ^= ((unsigned)(0x7fffffffu == (unsigned)h1) & (0x80000000u ^ 0xffffffffu));
                if ((unsigned)f0) continue;
            }
        }
        garr[(unsigned)(x0 >> 70) & 7u] = (((unsigned)(*q0 && (fuel | i1)) - (unsigned)b0) & (unsigned)e0);
        continue; (void)(((unsigned)c1 | (unsigned)x0));
        if (budget != 0u) { budget -= 1u; u2 = fn1(r0.y, (unsigned)h1, ((*q0 % (r0.y | 1u)) % (a0[i0 & 3u] | 1u))); }
    }
    { unsigned t1; double z1; if (((unsigned)((unsigned)c1 == 0xffffffffu)) & 1u) { t1 = (unsigned)((int)g0 < (int)(*mp * p1)); z1 = (double)(((4u ^ (unsigned)((unsigned)h1 < (unsigned)b0))) & 255u); } if (((unsigned)((unsigned)c1 == 0xffffffffu)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        u3 = u3 * 0x9e3779b1u + ((a0[i0 & 3u] >> ((unsigned)e0 & 31u)) * (unsigned)((int)(a0[i0 & 3u] + 0x10000u) < (int)(unsigned)c1));
        if (0x10000u) goto L1;
        { unsigned t2; double z2; if ((((8u | r0.y) % ((unsigned)x0 | 1u))) & 1u) { t2 = (garr[i1 & 7u] ^ 9u); z2 = (double)(((unsigned)(a0[u1 & 3u] && (fuel >> (4u & 31u)))) & 255u); } if ((((8u | r0.y) % ((unsigned)x0 | 1u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                L2: if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
            }
            L4: if (--fuel == 0u) goto done;
        }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((unsigned)(u1 || i1) & 255u);
            e0 = e0 * 0.5L + (long double)((unsigned)((short)0x10000u > (signed char)(0x7fffffffu - (unsigned)c0)) & 1023u);
            if ((unsigned)(u0 && 5u)) break;
            v0 = (unsigned)h0;
            if (u3 == 7u) return (unsigned)((unsigned)s1 == (unsigned)((short)p1 > (signed char)(unsigned)(x0 >> 70)));
            if (8u) goto L1;
        }
        if (i0) goto L1;
    }
    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)b0 || ((unsigned)d0 % (0x6491e0fau | 1u))));
    if (u3 == 7u) return ((0x3583a46eu / ((unsigned)l0 | 1u)) & ((unsigned)h1 / ((unsigned)(signed char)(unsigned)((int)(unsigned)c0 < (int)g0) | 1u)));
    if ((unsigned)((unsigned)((int)7u < (int)garr[u2 & 7u]) && (unsigned)h0)) {
        v0 = (unsigned)((int)(unsigned)((unsigned)h0 || (*q0 / (0x11978ec2u | 1u))) < (int)(unsigned)(w0 >> 29));
    } else {
        switch (((unsigned)x0 * fuel) & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)w0 >> (0xa1c77965u & 31u)), (r0.y % ((*q0 << ((unsigned)f0 & 31u)) | 1u)), (0x80000000u % (0x1718786fu | 1u))); }
            switch ((r0.x << (u1 & 31u)) & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn0((u3 - (unsigned)h1), (unsigned)((int)u2 >= (int)~(unsigned)(garr[u2 & 7u] || 0x10000u)), (unsigned)l0); }
                while (i0++ < 2u && ((unsigned)b0 & (unsigned)(8u || (unsigned)x0))) { if (--fuel == 0u) goto done;
                    if (6u) break;
                    break; (void)((0x69fa28eu % ((unsigned)(u0 && u1) | 1u)));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((i1 >> (a0[u1 & 3u] & 31u)), (unsigned)((unsigned)!((unsigned)h1 & 5u) < (unsigned)(w0 >> 29)), (unsigned)((int)(unsigned)b0 >= (int)4u)); }
                s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)((int)(unsigned)d0 < (int)p0) > (signed char)u0));
            }
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(((unsigned)c1 ^ 9u) < 0x7fffffffu), garr[u2 & 7u], (unsigned)(x0 >> 70)); }
            do { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 6u: ;
                    case 1u: ;
                }
                { unsigned t3; double z3; if (((unsigned)((int)(p1 >> (g1 & 31u)) < (int)(unsigned)h0)) & 1u) { t3 = (unsigned)h1; z3 = (double)(((unsigned)(unsigned char)(unsigned)(i0 == (u0 - (unsigned)b0))) & 255u); } if (((unsigned)((int)(p1 >> (g1 & 31u)) < (int)(unsigned)h0)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                    if (0xffffffffu) {
                        *q0 = (unsigned)((r0.x & (unsigned)(w0 >> 29)) < *mp);
                        if (p1) goto L3;
                        r0.x = ((r0.y >> (a0[i0 & 3u] & 31u)) - (r0.x - 0xba9019ccu));
                        i2 = u2 & 15u;
                    } else {
                        h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)c1 < (int)((1u | ((unsigned)c1 | 0x10000u)) | (unsigned)c0)));
                    }
                    c0 = (unsigned char)(unsigned)((int)(unsigned)(p0 || (unsigned)s1) >= (int)4u);
                    r0.x = (unsigned)(r0.x == -((unsigned)(unsigned char)(unsigned)((short)0xa0db1e0u > (signed char)0xe9eb8854u) + 8u));
                    case 3u: ;
                    b0 = (unsigned)(unsigned char)((fuel + (unsigned)(fuel < 0xffffffffu)) | (unsigned)((short)(unsigned)x0 > (signed char)(unsigned)h0)) != 0u;
                }
                u1 = u1 * 0x9e3779b1u + ((unsigned)((int)fuel < (int)(unsigned)(*q0 && (unsigned)(w0 >> 29))) % (8u | 1u));
                c0 = (unsigned char)(unsigned)(((unsigned)(r0.x && u1) + 7u) < fuel);
            } while (i0++ < 6u && (*mp / ((unsigned)x0 | 1u)));
            if (g1) {
                c0 = (unsigned char)(unsigned)(0x6724b9d8u == *q0);
                case 2u: ;
                d0 = d0 * 0.5 + (double)(((unsigned)x0 / ((unsigned)((unsigned)c0 < i1) | 1u)) & 1023u);
            } else {
                c1 = (signed char)(unsigned)((int)garr[u2 & 7u] >= (int)0x7fee90e6u);
            }
        }
        c1 = (signed char)((unsigned)(p0 && 0x7fffffffu) + (unsigned)e0);
        if (v0) goto L2;
        if ((v0 % (g0 | 1u))) goto L4;
    }
    { unsigned t4; double z4; if (((unsigned)((int)0x80000000u >= (int)0x7fffffffu)) & 1u) { t4 = 0x7fffffffu; z4 = (double)(((unsigned)((short)0x8d633dd4u > (signed char)v0)) & 255u); } if (((unsigned)((int)0x80000000u >= (int)0x7fffffffu)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        u1 = a0[i0 & 3u];
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)i2;
            f0 = f0 * 0.5f + (float)((9u * (unsigned)(unsigned char)(unsigned)(~(u3 >> ((unsigned)(x0 >> 70) & 31u)) && u0)) & 255u);
            if ((0x80000000u - (unsigned)h0)) break;
            if ((unsigned)f0) break;
            if ((*q0 + 0x80000000u)) break;
        }
        goto L3;
        d0 = d0 * 0.5 + (double)(((unsigned)e0 | 0x7fa71953u) & 1023u);
    }
    w0 = w0 * 6364136223846793005ull + -(0x7fffffffu % (p0 | 1u));
    goto L0;
    if ((unsigned)(w0 >> 29)) {
        if (i2) goto L0;
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)((unsigned)(6u < 4u) | (unsigned)((int)3u < (int)9u));
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(signed char)(0x997b6271u * p0) & (unsigned)c1), ((unsigned)(signed char)(u2 ^ (unsigned)c1) % (i2 | 1u)), (unsigned)((unsigned)l0 || (*q0 | 8u))); }
            while ((u2 * (unsigned)b0)) { if (--fuel == 0u) goto done;
                if (6u) {
                    if ((v0 << ((unsigned)(signed char)(unsigned)(5u && (unsigned)w0) & 31u))) break;
                    if ((unsigned)(((unsigned)c1 >> (a0[i0 & 3u] & 31u)) == 2u)) continue;
                    m0 ^= (unsigned)(0x80000000u && (m0 + p1));
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)s1 < (int)(unsigned)((short)m0 > (signed char)0x10000u));
                    c0 = (unsigned char)((unsigned)((short)0x4ff83f01u > (signed char)(unsigned)c0) * (unsigned)s0);
                } else {
                    break; (void)((unsigned)x0);
                    if (((unsigned)c0 + (i1 % (r0.x | 1u)))) break;
                    r0.y ^= (5u / ((unsigned)(signed char)(unsigned)((int)u0 >= (int)a0[u1 & 3u]) | 1u));
                    if ((unsigned)((short)g0 > (signed char)0x10000u)) continue;
                }
            }
            while (i1++ < 4u && g1) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1(i2, (unsigned)w0, (0xa1a626a9u + (m0 * garr[u2 & 7u]))); }
            }
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)l0 >> (a0[i0 & 3u] & 31u))) {
                    c0 = (unsigned char)(unsigned)(short)(a0[u1 & 3u] % (7u | 1u));
                }
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)s1, (u3 & 0xbb3e7543u), u1); }
            }
        }
        r0.x = (unsigned)d0;
        l0 = (long)((unsigned long)l0 + v0);
    } else {
        w0 ^= (unsigned long long)i2 << ((i2 ^ 0x605bd7b3u) & 63u);
        if ((unsigned)(w0 >> 29)) {
            goto done;
            goto L4;
            while (i0++ < 3u && -(a0[u1 & 3u] % ((unsigned)d0 | 1u))) { if (--fuel == 0u) goto done;
                i1 = (unsigned)!((unsigned)f0 << ((unsigned)(v0 || u0) & 31u)) & 15u;
            }
            c0 = (unsigned char)(unsigned)(((unsigned)s1 & (unsigned)(w0 >> 29)) == (0x980bc1f9u / (1u | 1u)));
            l0 = (long)((unsigned long)l0 + (3u & (i0 | u1)));
        } else {
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)c0 < (int)(0xffffffffu ^ (unsigned)c0))) break;
                if (0x10000u) continue;
                { unsigned t5; double z5; if ((((unsigned)e0 / ((garr[i1 & 7u] / ((unsigned)s0 | 1u)) | 1u))) & 1u) { t5 = (unsigned)(w0 >> 29); z5 = (double)(((unsigned)s1) & 255u); } if ((((unsigned)e0 / ((garr[i1 & 7u] / ((unsigned)s0 | 1u)) | 1u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                    if (0x10000u) continue;
                    if ((unsigned)(short)(8u ? 0x356ee483u : 0xffffffffu)) {
                        if ((unsigned)((int)(p2 * 5u) >= (int)0xffffffffu)) break;
                        if ((9u << ((unsigned)c1 & 31u))) break;
                        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                            m0 ^= (unsigned)((int)fuel < (int)8u);
                            w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)(r0.x && v0) > (signed char)(u0 - (0x10000u - 0x80000000u)));
                            e0 = e0 * 0.5L + (long double)((unsigned)(v0 && (((unsigned)(x0 >> 70) + (unsigned)h0) / (garr[u2 & 7u] | 1u))) & 1023u);
                        }
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn0((r0.x >> ((unsigned)((unsigned)e0 || 3u) & 31u)), (unsigned)(u2 && (p2 ^ u2)), u0); }
                    x0 = x0 * 0x100000001b3ull + (u2 ? (u2 >> (u0 & 31u)) : (0xf6d7f8d1u / ((unsigned)(w0 >> 29) | 1u)));
                    u0 = 0xaf5ba2cbu;
                    f0 = f0 * 0.5f + (float)(5u & 255u);
                }
                w0 ^= (unsigned long long)(unsigned)f0 << ((unsigned)((short)((unsigned)h0 ^ *q0) > (signed char)(p1 >> (r0.y & 31u))) & 63u);
                u3 = u3 * 0x9e3779b1u + (u2 - (unsigned)((u3 * (unsigned)s0) && (unsigned)f0));
            } while (i0++ < 6u && (unsigned)(0x1d6f07b6u < 0xe9430ab1u));
        }
        goto L3;
        v0 = ((fuel << ((unsigned)e0 & 31u)) % (0xffffffffu | 1u));
    }
    if (0x2aa42386u) goto L1;
    u0 = (*mp ? (v0 ^ a0[u1 & 3u]) : g0);
    q0 = &garr[((unsigned)h0 << (i0 & 31u)) & 7u];
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(a0[u1 & 3u] << ((unsigned)l0 & 31u)) >= (int)(unsigned)d0), (unsigned)((int)(unsigned)h0 < (int)(unsigned)(u0 == (unsigned)s1)), u1); }
    *q0 = -((unsigned)((int)8u >= (int)(r0.x ? (unsigned)(w0 >> 29) : i0)) % (0x80000000u | 1u));
    if ((i2 - m0)) goto L1;
    { unsigned t6; double z6; if ((0x91abf330u) & 1u) { t6 = (unsigned)(((unsigned)h1 | p0) < p2); z6 = (double)(((4u % ((0x80000000u / (i0 | 1u)) | 1u))) & 255u); } if ((0x91abf330u) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1((g1 * ((unsigned)c0 & r0.y)), (unsigned)!(u1 - 0x8fdab607u), (m0 | (0x10000u / ((unsigned)d0 | 1u)))); }
        }
        if (((garr[u2 & 7u] >> (p2 & 31u)) * 5u)) goto L2;
        if (u1) {
            u0 = *q0;
            while (g1) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)(unsigned)c1 > (signed char)i0)) break;
                if ((unsigned)(u0 == a0[i0 & 3u])) break;
            }
        }
    }
    for (;;) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)((unsigned)(0x70e8174au < 0x10000u) | garr[u2 & 7u]);
    }
    if ((unsigned)f0) {
        s0 = (int)(4u - 0xaa524219u);
        switch (5u & 7u) {
            w0 ^= (unsigned long long)0u << ((unsigned)((u0 >> ((garr[u2 & 7u] | fuel) & 31u)) && 0x10000u) & 63u);
            v0 = (unsigned)(r0.y == (unsigned)h1);
        }
        if (p0) goto L0;
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)(i2 == (unsigned)c0) & 7u) {
                c1 = (signed char)((g1 ? 0xa9adbe16u : u2) & 0x7fffffffu);
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    v0 = (unsigned)(((*mp | g0) / (0x80000000u | 1u)) || garr[u2 & 7u]);
                    case 7u: ;
                }
                d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((unsigned)((int)(unsigned)h1 < (int)7u) == r0.x) == garr[i1 & 7u]) & 1023u);
                m0 ^= (((unsigned)w0 >> (((unsigned)c0 | a0[i0 & 3u]) & 31u)) % ((unsigned)h1 | 1u));
                if (0x6815a378u) break;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    u0 ^= (unsigned)(x0 >> 70);
                    if ((unsigned)((int)(unsigned)l0 >= (int)(unsigned)(p0 < i0))) {
                        u1 = (unsigned)((short)(unsigned)c1 > (signed char)(0x7fffffffu - v0));
                    }
                    if (u2) {
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(a0[u1 & 3u] || (unsigned)(w0 >> 29)), (r0.x - i0), (unsigned)(0x80000000u < (6u - 0x30c9a5e1u))); }
                    } else {
                        m0 ^= (unsigned)(short)((2u & 0x30c5fd3du) + a0[u1 & 3u]);
                        default: ;
                        if (budget != 0u) { budget -= 1u; u1 = fn1(-(unsigned)(i1 && garr[u2 & 7u]), (unsigned)s1, (unsigned)h0); }
                    }
                    h1 = (unsigned short)(h1 + (0x106da790u + ((unsigned)(u1 || i2) + (i2 << ((unsigned)s1 & 31u)))));
                    do { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)(((unsigned)(signed char)(unsigned)((int)0x7fffffffu >= (int)2u) & (unsigned)((unsigned)d0 < (unsigned)d0)) & 1023u);
                        g1 += ((unsigned)w0 / ((unsigned)(0x6fb078f6u < (unsigned)w0) | 1u));
                    } while (i2++ < 5u && (unsigned)((int)fuel >= (int)8u));
                }
            }
            e0 = e0 * 0.5L + (long double)((unsigned)(i1 || u0) & 1023u);
            u1 ^= garr[u2 & 7u];
            switch (~(unsigned)(0x7fffffffu < (a0[u1 & 3u] * 0xe64890d0u)) & 7u) {
                { unsigned t7; double z7; if (((0x7fffffffu / (g1 | 1u))) & 1u) { t7 = a0[u1 & 3u]; z7 = (double)((((u3 % (0x80000000u | 1u)) | p1)) & 255u); } if (((0x7fffffffu / (g1 | 1u))) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                    case 2u: ;
                    while (i1++ < 4u && 0x17387586u) { if (--fuel == 0u) goto done;
                        s0 = (int)0x10000u;
                        u3 = u3 * 0x9e3779b1u + (7u + a0[i0 & 3u]);
                        goto L3;
                        if (u2) goto L1;
                        *mp = (unsigned)((int)(unsigned)s1 < (int)0u);
                    }
                    case 0u: ;
                }
                case 1u: ;
            }
        }
        if ((unsigned)x0) goto L4;
    } else {
        { unsigned t8; double z8; if (((unsigned)((int)0xdf4c15c2u < (int)garr[u2 & 7u])) & 1u) { t8 = (unsigned)((unsigned)((short)r0.y > (signed char)r0.x) == 0xffffffffu); z8 = (double)(((unsigned)((unsigned)c1 < g0)) & 255u); } if (((unsigned)((int)0xdf4c15c2u < (int)garr[u2 & 7u])) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
            u1 = u1 * 0x9e3779b1u + ((unsigned)(3u || 0x7fffffffu) + -(unsigned)((int)(unsigned)(short)(unsigned)((int)u3 < (int)0x7fffffffu) >= (int)u2));
            if (((unsigned)(0x80000000u == u3) / (4u | 1u))) goto L3;
        }
        switch ((unsigned)(signed char)(unsigned)((short)0x5e26d68au > (signed char)v0) & 7u) {
            h0 = (short)(i1 + ((unsigned)x0 & i2));
            if ((unsigned)(signed char)(u3 << (u1 & 31u))) goto L4;
            case 4u: ;
        }
        if (-(garr[i1 & 7u] | (unsigned)h0)) {
            goto L0;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn1((i1 / (garr[i1 & 7u] | 1u)), (unsigned)s1, v0); }
    }
    u1 = u1 * 0x9e3779b1u + (unsigned)(unsigned char)(((1u + (unsigned)x0) % (8u | 1u)) | p1);
    *mp = (unsigned)!((p0 ? 0xe38f12aeu : u2) | (u0 & u3));
    if ((fuel ^ i0)) goto done;
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)c1, ~(unsigned)((short)*mp > (signed char)g0), (*q0 ^ 0x10000u)); }
    *mp = (4u % (p2 | 1u));
    { unsigned t9; double z9; if ((u0) & 1u) { t9 = ((unsigned)d0 + 5u); z9 = (double)(((a0[i0 & 3u] >> ((unsigned)c0 & 31u))) & 255u); } if ((u0) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
        if (budget != 0u) { budget -= 1u; u0 = fn0(m0, (0x10000u << ((fuel ^ fuel) & 31u)), (unsigned)((int)(unsigned)((unsigned)(w0 >> 29) == p2) >= (int)(unsigned)d0)); }
    }
    while (i0++ < 5u && (0x61c762a1u - *q0)) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)((0x80000000u ^ 4u) - (unsigned)!(-(a0[u1 & 3u] >> (0x7fffffffu & 31u)) >> ((unsigned)f0 & 31u)));
        { unsigned t10; double z10; if ((0xffffffffu) & 1u) { t10 = (unsigned)(u0 && p0); z10 = (double)(((r0.x | *mp)) & 255u); } if ((0xffffffffu) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
            while (i1++ < 4u && 0x35ed4203u) { if (--fuel == 0u) goto done;
                u0 = u0 * 0x9e3779b1u + (unsigned)((int)i1 >= (int)i1);
                x0 = x0 * 0x100000001b3ull + u1;
            }
            u1 += (0x2fde5259u + ~(unsigned)(0x8746ebfu < (p0 ? fuel : fuel)));
            if (budget != 0u) { budget -= 1u; u1 = fn1((r0.y * (unsigned)c0), a0[u1 & 3u], (unsigned)c0); }
            break; (void)(((unsigned)s0 << ((unsigned)((int)m0 >= (int)(unsigned)l0) & 31u)));
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                u0 = u0 * 0x9e3779b1u + (unsigned)(unsigned char)(unsigned)((short)(0xffffffffu * ((unsigned)w0 | (unsigned)h1)) > (signed char)-(unsigned)(6u && (unsigned)s0));
                switch (r0.y & 7u) {
                    x0 = x0 * 0x100000001b3ull + ((unsigned)((int)(unsigned)c0 < (int)(unsigned)s1) << (((unsigned)w0 >> (r0.x & 31u)) & 31u));
                    u2 = (unsigned)(u3 || ((fuel * u3) ? 0x80000000u : v0));
                    d0 = d0 * 0.5 + (double)((unsigned)((6u & u0) < 0xec1da3f8u) & 1023u);
                }
                q0 = &garr[(m0 ? (unsigned)s1 : 0xffffffffu) & 7u];
            }
        }
        switch (((0x10000u ^ garr[i1 & 7u]) * (unsigned)h0) & 7u) {
            m0 ^= (unsigned)(0xa8d6bde8u == (unsigned)((fuel << ((unsigned)e0 & 31u)) == *mp));
            c1 = (signed char)(unsigned)!(0xc5a73fa6u & (unsigned)s1);
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((int)*q0 < (int)garr[u2 & 7u]) || fuel) & 255u);
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)0xffffffffu < (int)0x7fffffffu), ((p2 * *q0) / (p1 | 1u)), (unsigned)((int)(unsigned)((unsigned)h1 || r0.y) >= (int)(unsigned)(x0 >> 70))); }
        }
        x0 = x0 * 0x100000001b3ull + (0xeb7631fdu << ((unsigned)(u3 == (unsigned)(fuel < a0[i0 & 3u])) & 31u));
        i0 = (unsigned)!(unsigned)((int)(unsigned)h0 >= (int)(0x80000000u * u0)) & 15u;
    }
    x0 = x0 * 0x100000001b3ull + (((unsigned)s1 & (unsigned)((short)0u > (signed char)0x10000u)) / (u0 | 1u));
    h1 = (unsigned short)(h1 + (unsigned)(short)(garr[u2 & 7u] << (0u & 31u)));
    a0[garr[u2 & 7u] & 3u] = (garr[u2 & 7u] >> (0x80000000u & 31u));
    *q0 += (unsigned)((int)((unsigned)x0 | *q0) >= (int)(unsigned)((unsigned)l0 || ~(unsigned)(0x7fffffffu == p0)));
    s1 = (int)((unsigned)s1 + (unsigned)(i0 == 0xd7bbbeafu));
    if (((unsigned)(0xffffffffu && *q0) | i1)) goto L3;
    if (fuel < 8u) return (unsigned)((int)a0[u1 & 3u] < (int)(p1 & v0));
    s0 = (int)(unsigned)(((unsigned)c1 ? g0 : 0x10000u) || p1);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)h0, (unsigned)(0xffffffffu < u1), u3); }
    c0 = (unsigned char)0x10000u;
    e0 = e0 * 0.5L + (long double)(((unsigned)(u1 == i1) & (r0.y % (*q0 | 1u))) & 1023u);
    goto L1;
    L0: if (--fuel == 0u) goto done;
    *q0 += (unsigned)((unsigned)((u0 ^ *q0) < g1) || ((unsigned)b0 / (0x10000u | 1u)));
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)(unsigned)!(unsigned)(*q0 || 9u) < (int)(unsigned)c0), (4u ^ (unsigned)h0), p0); }
    g0 = (unsigned)(9u || ((unsigned)((short)fuel > (signed char)(unsigned)f0) / ((unsigned)c1 | 1u)));
    { unsigned t0; double z0; if ((0xffffffffu) & 1u) { t0 = p0; z0 = (double)(((unsigned)(short)(3u % (p0 | 1u))) & 255u); } if ((0xffffffffu) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        if ((m0 & (r0.y / (garr[u2 & 7u] | 1u)))) goto L0;
    }
    f0 = f0 * 0.5f + (float)((0x80000000u * (r0.x << (r0.x & 31u))) & 255u);
    { unsigned t1; double z1; if (((*q0 >> (0xffffffffu & 31u))) & 1u) { t1 = (unsigned)(0x3d589cb7u < u2); z1 = (double)(((unsigned)s1) & 255u); } if (((*q0 >> (0xffffffffu & 31u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((u3 % (i0 | 1u)), (0x172fb2e0u + 0xffffffffu), 0x10000u); }
            if (((unsigned)l0 | u2)) {
                w0 ^= (unsigned long long)(unsigned)d0 << ((unsigned)((short)0x7fffffffu > (signed char)((unsigned)b0 | (unsigned)(short)((unsigned)c1 - ((unsigned)(x0 >> 70) & 4u)))) & 63u);
                if ((unsigned)s1) break;
                L1: if (--fuel == 0u) goto done;
                while (i1++ < 3u && 0x10000u) { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (0x2bf22d75u - (unsigned)e0));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(x0 >> 70), ((unsigned)e0 | garr[i1 & 7u]), (g1 * (unsigned)e0)); }
                    if (*mp) break;
                    L2: if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        h0 = (short)(0x8cf40274u - r0.y);
                        if (budget != 0u) { budget -= 1u; u2 = fn1((a0[u1 & 3u] / ((unsigned)((short)i2 > (signed char)0x80000000u) | 1u)), (unsigned)(signed char)(unsigned)((int)(0x10000u & (unsigned)f0) >= (int)(unsigned)h1), (r0.x & 0xffffffffu)); }
                        *mp = (unsigned)((short)((unsigned)(short)(fuel / (a0[u1 & 3u] | 1u)) % ((a0[i0 & 3u] | 0x6000d293u) | 1u)) > (signed char)(unsigned)s1);
                    } while (i2++ < 4u && ((u0 % (0xd955deb7u | 1u)) - p1));
                    if (0xffffffffu) break;
                }
            }
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                goto L4;
                if ((a0[u1 & 3u] % (u2 | 1u))) goto L3;
                if (budget != 0u) { budget -= 1u; u0 = fn2(garr[u2 & 7u], ((unsigned)((short)r0.y > (signed char)garr[i1 & 7u]) - 0xffffffffu), ((unsigned)x0 / (a0[i0 & 3u] | 1u))); }
                s1 = (int)((unsigned)s1 + (unsigned)(r0.y || m0));
                u3 = (unsigned)(signed char)(unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)l0);
                f0 = f0 * 0.5f + (float)((unsigned)(u0 || (unsigned)((int)0x7fffffffu >= (int)(unsigned)h0)) & 255u);
            }
            while (garr[u2 & 7u]) { if (--fuel == 0u) goto done;
                *q0 = (unsigned)((int)(unsigned)((unsigned)c1 || ((unsigned)c0 / ((7u * p2) | 1u))) >= (int)0xffffffffu);
            }
        }
        goto L1;
        goto done;
    }
    u3 += ~((unsigned)((fuel | (unsigned)x0) < i2) ^ 9u);
    m0 ^= p0;
    *mp = (0x80000000u ? 0x24da677u : 0xffffffffu);
    { unsigned t2; double z2; if (((unsigned)h1) & 1u) { t2 = (unsigned)l0; z2 = (double)((p0) & 255u); } if (((unsigned)h1) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        h1 = (unsigned short)(h1 + (unsigned)((5u >> (((unsigned)s1 * 0xc478256bu) & 31u)) == ((unsigned)(w0 >> 29) | r0.y)));
        *mp = (i0 ^ (a0[u1 & 3u] * ((unsigned)(w0 >> 29) / (u3 | 1u))));
    }
    h1 = (unsigned short)(h1 + (unsigned)(signed char)((unsigned)(short)(unsigned)(u1 || i0) ? garr[u2 & 7u] : 1u));
    v0 = 0x10000u;
    q0 = &garr[(unsigned)(unsigned char)((unsigned)h0 & (unsigned)((int)(unsigned)e0 < (int)(m0 % (0x45d5022du | 1u)))) & 7u];
    switch (m0 & 7u) {
        l0 = (long)((unsigned long)l0 + 0x8512b3fu);
        *q0 = (unsigned)((int)~(((unsigned)s0 << (((unsigned)c1 % (g1 | 1u)) & 31u)) >> (0u & 31u)) < (int)(unsigned)f0);
        c1 = (signed char)(garr[u2 & 7u] | 0x70c9e0d2u);
        goto L2;
        switch ((garr[u2 & 7u] + (unsigned)(x0 >> 70)) & 7u) {
            c0 = (unsigned char)(0x51de50bcu | i2);
        }
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)5u;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((short)(unsigned)w0 > (signed char)u3), (unsigned)((unsigned)s0 == p1), ((unsigned)w0 - garr[u2 & 7u])); }
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((0xffffffffu & 0u), g0, (unsigned)(signed char)(unsigned)((int)(unsigned)((int)0xebd2aaddu < (int)garr[u2 & 7u]) < (int)(unsigned)s0)); }
    if (r0.x) goto L3;
    switch ((unsigned)(signed char)((unsigned)(x0 >> 70) % (i0 | 1u)) & 7u) {
        do { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)(0x769acd06u == p0) && 0x10000u)) {
                    while (i2) { if (--fuel == 0u) goto done;
                        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                            h1 = (unsigned short)(h1 + ((6u | (unsigned)(w0 >> 29)) + a0[u1 & 3u]));
                            a0[(i0 + p0) & 3u] = (0x80000000u / ((0x1ebb84f7u % (*q0 | 1u)) | 1u));
                            if (budget != 0u) { budget -= 1u; u3 = fn2((g0 >> (0xbbdace60u & 31u)), ((unsigned)(i0 || r0.x) - u3), u1); }
                            if ((u2 + ((unsigned)w0 << ((unsigned)c0 & 31u)))) goto L3;
                            e0 = e0 * 0.5L + (long double)(((0x10000u & 0x7fffffffu) / ((unsigned)(p0 || -(*q0 ^ a0[i0 & 3u])) | 1u)) & 1023u);
                            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)(2u < u2) % (0xa94ea695u | 1u)), 6u, (u1 % ((unsigned)s1 | 1u))); }
                        }
                        if ((i0 ^ (unsigned)((int)(unsigned)x0 < (int)p1))) goto L2;
                        r0.y ^= ((0xffffffffu % (0u | 1u)) >> (((unsigned)e0 - 0xabae265au) & 31u));
                        e0 = e0 * 0.5L + (long double)((unsigned)(((unsigned)f0 - (u2 + (unsigned)(x0 >> 70))) && ((unsigned)e0 % (2u | 1u))) & 1023u);
                    }
                }
                u2 ^= (unsigned)((unsigned)e0 < (m0 / (0x10000u | 1u)));
                if (fuel < 8u) return (unsigned)(0xdc602034u || u3);
                switch ((0x10000u - a0[i0 & 3u]) & 7u) {
                    w0 = w0 * 6364136223846793005ull + 0x80000000u;
                    b0 = (unsigned)(6u < ((unsigned)e0 >> (u3 & 31u))) != 0u;
                    u2 ^= (unsigned)!(unsigned)(0x7fffffffu && (unsigned)((int)g1 >= (int)p1));
                    L3: if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + 0x4996dabcu;
                    L4: if (--fuel == 0u) goto done;
                }
            }
            switch (p0 & 7u) {
                if ((unsigned)((int)((unsigned)l0 << ((unsigned)x0 & 31u)) < (int)(unsigned)h1)) break;
                x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)(unsigned)((unsigned)((int)(unsigned)((short)(unsigned)(*q0 == (unsigned)d0) > (signed char)6u) < (int)(unsigned)s0) == (unsigned)d0);
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return ((unsigned)((int)(unsigned)s0 < (int)g0) + ((6u % (g1 | 1u)) & (unsigned)s1));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)((short)4u > (signed char)garr[u2 & 7u]) == u0), (unsigned)(short)(5u % (a0[i0 & 3u] | 1u)), (unsigned)((unsigned)(w0 >> 29) || 4u)); }
                    w0 = w0 * 6364136223846793005ull + g0;
                }
                f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)(unsigned)((unsigned)h1 || a0[u1 & 3u]) < (int)~(i1 ^ (unsigned)l0)) >= (int)7u) & 255u);
                g1 += ((unsigned)((unsigned)(signed char)(i0 - garr[u2 & 7u]) == p2) & (unsigned)(x0 >> 70));
            }
            d0 = d0 * 0.5 + (double)((unsigned)(i2 == (6u >> (i0 & 31u))) & 1023u);
        } while (i0++ < 6u && (u3 * (0xa07daed6u & u0)));
        case 6u: ;
        *q0 += -((unsigned)d0 & ((u2 >> (u2 & 31u)) + i2));
    }
    switch (0u & 7u) {
        if ((((unsigned)e0 << (p0 & 31u)) >> (a0[u1 & 3u] & 31u))) goto L3;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(unsigned char)((garr[i1 & 7u] ^ g0) - 0x7fffffffu), (unsigned)((unsigned)e0 == g0), (4u & p0)); }
    s0 = (int)(unsigned)!(((u3 | 0x10000u) ^ 0xffffffffu) >> (4u & 31u));
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)x0 < (int)((v0 >> ((7u % (a0[i0 & 3u] | 1u)) & 31u)) >> (v0 & 31u)));
    *q0 += ((unsigned)(p1 < 0xffffffffu) % ((unsigned)l0 | 1u));
    g0 = ((u1 ? (unsigned)h0 : u3) | 2u);
    u2 = u2 * 0x9e3779b1u + ((unsigned)s0 ? (unsigned)c0 : (r0.y / ((garr[u2 & 7u] << (u0 & 31u)) | 1u)));
    while ((0x7fffffffu ? 0x831bbb2au : (unsigned)x0)) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)c0;
    }
    while (i2) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(x0 >> 70) << (0xffffffffu & 31u)), (unsigned)(short)(unsigned)((unsigned)e0 == (unsigned)((short)0xbc1efc6bu > (signed char)(unsigned)(x0 >> 70))), (unsigned)s0); }
            { unsigned t3; double z3; if (((unsigned)(unsigned char)(unsigned)((i1 >> (m0 & 31u)) == (unsigned)b0)) & 1u) { t3 = 3u; z3 = (double)(((0x33e7de34u + i2)) & 255u); } if (((unsigned)(unsigned char)(unsigned)((i1 >> (m0 & 31u)) == (unsigned)b0)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                h1 = (unsigned short)(h1 + 7u);
                q0 = &garr[(unsigned)(3u < (unsigned)x0) & 7u];
                *mp = (unsigned)(u3 || m0);
                if ((*mp + 0x7b7327fcu)) {
                    if ((0x94841930u & (unsigned)d0)) break;
                    { unsigned t4; double z4; if (((unsigned)(x0 >> 70)) & 1u) { t4 = 1u; z4 = (double)(((unsigned)(0x8b602026u || 9u)) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                        d0 = d0 * 0.5 + (double)((((unsigned)h1 % (u1 | 1u)) ^ -(v0 << ((unsigned)c1 & 31u))) & 1023u);
                    }
                    if (((unsigned)((int)i0 < (int)5u) % (p1 | 1u))) {
                        if (a0[i0 & 3u]) {
                            w0 ^= (unsigned long long)(unsigned)s0 << (~((unsigned)((int)0x10000u < (int)(unsigned)h1) >> ((unsigned)(0x8e913978u && fuel) & 31u)) & 63u);
                            h1 = (unsigned short)(h1 + (unsigned)(0x75cd3220u || p0));
                        } else {
                            if ((unsigned)!(0xffffffffu % (0x10000u | 1u))) break;
                            c1 = (signed char)8u;
                            break; (void)((unsigned)(garr[i1 & 7u] < (garr[i1 & 7u] * (unsigned)d0)));
                            e0 = e0 * 0.5L + (long double)((unsigned)((short)(0x80000000u * ((unsigned)b0 - garr[i1 & 7u])) > (signed char)u1) & 1023u);
                        }
                        if (budget != 0u) { budget -= 1u; u1 = fn1((2u ^ p1), (unsigned)((unsigned)(signed char)(p1 << ((unsigned)e0 & 31u)) == g0), (unsigned)s0); }
                        h0 = (short)(p0 / (6u | 1u));
                        if (u3) continue;
                        h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)((short)0u > (signed char)(9u ? garr[i1 & 7u] : u0)) >= (int)g1));
                    } else {
                        if (((u0 >> (0x80000000u & 31u)) | (unsigned)h0)) break;
                        s0 = (int)(unsigned)(unsigned char)(unsigned)((short)((unsigned)(x0 >> 70) & g1) > (signed char)(u2 - (p0 % ((unsigned)c0 | 1u))));
                        if (u2) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)((int)(unsigned)(w0 >> 29) >= (int)u3) || i1), 0x7fffffffu, (unsigned)(unsigned char)(0xbe425e24u + ((unsigned)c1 | 0x97dcab01u))); }
                    }
                    break; (void)((-(0x10000u & (unsigned)f0) >> (u1 & 31u)));
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn2(garr[i1 & 7u], (i0 << ((fuel | 0xc602904cu) & 31u)), ((unsigned)e0 * r0.y)); }
                    if ((unsigned)((short)0x80000000u > (signed char)r0.x)) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn1(~(a0[i0 & 3u] - (unsigned)((int)u1 >= (int)i1)), garr[i1 & 7u], (unsigned)((short)6u > (signed char)(7u - g1))); }
                    garr[(unsigned)s1 & 7u] = 7u;
                }
            }
            while (i2++ < 2u && p2) { if (--fuel == 0u) goto done;
                garr[0xffffffffu & 7u] = (unsigned)(-((unsigned)h1 >> (0xffffffffu & 31u)) || ((0x14c73057u & 8u) & i0));
                if ((*mp << (0xdc7e7269u & 31u))) {
                    q0 = &garr[a0[i0 & 3u] & 7u];
                    garr[(unsigned)((short)*mp > (signed char)u2) & 7u] = ((unsigned)((unsigned)((short)(unsigned)c1 > (signed char)0u) == (unsigned)(0xffffffffu < u0)) - (unsigned)(w0 >> 29));
                    l0 = (long)((unsigned long)l0 + ~((8u * a0[u1 & 3u]) | (unsigned)(u3 || 3u)));
                    u1 += (unsigned)((int)(unsigned)((short)3u > (signed char)(unsigned)x0) >= (int)(0x10000u | fuel));
                    c0 = (unsigned char)(unsigned)(signed char)((3u >> (a0[u1 & 3u] & 31u)) >> ((a0[u1 & 3u] - (unsigned)((unsigned)(w0 >> 29) < (unsigned)e0)) & 31u));
                } else {
                    c0 = (unsigned char)(unsigned)(unsigned char)(unsigned)((int)p2 < (int)((2u / (i2 | 1u)) * a0[u1 & 3u]));
                    goto L1;
                    s0 = (int)-(unsigned)((int)2u < (int)g1);
                }
                break; (void)(u1);
            }
            do { if (--fuel == 0u) goto done;
                *mp = (unsigned)((u1 - (unsigned)s0) && ((unsigned)(x0 >> 70) ^ u0));
                if (budget != 0u) { budget -= 1u; u3 = fn0((9u + (unsigned)((int)(unsigned)s0 >= (int)(unsigned)s1)), (unsigned)h1, -(unsigned)(i2 && (p1 / (p2 | 1u)))); }
                while (i0++ < 6u && (unsigned)b0) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)x0 & 2u), ((0xe88151b9u / (9u | 1u)) & (unsigned)d0), (unsigned)w0); }
                }
            } while (i2++ < 5u && (unsigned)((int)5u >= (int)r0.x));
            while (i2++ < 6u && (unsigned)(short)(a0[i0 & 3u] + 0xe2dfb8ecu)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(a0[u1 & 3u] < 0x61a15776u), u2, p1); }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s1, 0x10000u, (unsigned)((v0 * (unsigned)e0) == 0x1d69969fu)); }
                break; (void)(2u);
            }
        }
        l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)((i0 ? 0xffffffffu : 0x7fffffffu) && ((unsigned)(w0 >> 29) | u3)));
        if (budget != 0u) { budget -= 1u; u3 = fn1(*mp, ~((unsigned)(short)(unsigned)(3u || 4u) - 0x7fffffffu), (r0.x + (g1 << (0x54f4811u & 31u)))); }
        if (((unsigned)b0 & garr[u2 & 7u])) goto L2;
        if (((unsigned)(short)(unsigned)(g1 || garr[u2 & 7u]) / (m0 | 1u))) goto L2;
    }
    if ((unsigned)(m0 || ((unsigned)w0 | 0x615cd17au))) goto L1;
    do { if (--fuel == 0u) goto done;
        break; (void)((2u * *mp));
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(short)((unsigned)((unsigned)c0 || p2) | (unsigned)w0), (unsigned)((int)(unsigned)(unsigned char)(unsigned)(i0 < 0x80000000u) < (int)u3), garr[u2 & 7u]); }
        m0 ^= ((0xffffffffu ? (unsigned)w0 : *q0) % ((unsigned)e0 | 1u));
        if ((unsigned)((unsigned)((unsigned)d0 == p0) && (unsigned)(x0 >> 70))) continue;
    } while (i0++ < 6u && ((unsigned)s0 << ((unsigned)x0 & 31u)));
    if ((p1 & garr[i1 & 7u])) goto done;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)((int)(2u * r0.x) >= (int)0x4259bec1u));
        r0.x = (unsigned)(short)((u2 << ((unsigned)f0 & 31u)) | a0[u1 & 3u]);
        if (fuel < 8u) return (unsigned)(unsigned char)(((p1 / ((unsigned)w0 | 1u)) << (u0 & 31u)) + fuel);
        r0.x = (garr[u2 & 7u] ^ (unsigned)!((unsigned)(w0 >> 29) / ((0x4d8cdfa3u >> ((unsigned)!(u1 - 0xca984cdfu) & 31u)) | 1u)));
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 = u3 * 0x9e3779b1u + (unsigned)(((unsigned)((unsigned)h1 < 0xbfd41624u) - (unsigned)s1) < (unsigned)w0);
        if (r0.x) break;
        f0 = f0 * 0.5f + (float)((0x61275d8cu << ((unsigned)(0xbb8977eau || *mp) & 31u)) & 255u);
        goto L3;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)(signed char)(unsigned)((int)r0.x >= (int)3u) || u0)) break;
            h0 = (short)(r0.y * (u2 & (r0.y | u2)));
            if (((unsigned)b0 / (0x6e9c72e6u | 1u))) break;
            switch (*mp & 7u) {
                d0 = d0 * 0.5 + (double)((((unsigned)x0 / ((5u << (fuel & 31u)) | 1u)) - v0) & 1023u);
            }
        } while (i1++ < 2u && (unsigned)((int)(unsigned)c1 >= (int)((unsigned)(x0 >> 70) * (unsigned)x0)));
    }
    *q0 = (unsigned)(unsigned char)(unsigned)((int)(unsigned)((unsigned)((short)0xffffffffu > (signed char)(unsigned)((int)i2 >= (int)0x10000u)) == 0x876a781du) >= (int)9u);
    { unsigned t5; double z5; if ((p1) & 1u) { t5 = (unsigned)((int)(unsigned)((int)(unsigned)l0 >= (int)u2) >= (int)4u); z5 = (double)(((g1 | 0xcefaf086u)) & 255u); } if ((p1) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        w0 ^= (unsigned long long)v0 << ((0xb8c12843u ^ (((unsigned)(v0 && 0x439ea983u) << (p0 & 31u)) - garr[i1 & 7u])) & 63u);
        l0 = (long)((unsigned long)l0 + (unsigned)(i2 || ((unsigned)((unsigned)(x0 >> 70) || u3) << (((unsigned)s0 % ((unsigned)b0 | 1u)) & 31u))));
        if ((unsigned)((short)(unsigned)((int)(unsigned)f0 < (int)(unsigned)e0) > (signed char)i0)) goto done;
        w0 = w0 * 6364136223846793005ull + 0x7fffffffu;
        do { if (--fuel == 0u) goto done;
            switch ((unsigned)(unsigned char)(unsigned)((int)0x80000000u >= (int)r0.x) & 7u) {
                goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, u2, (unsigned)((short)0xed8fb91u > (signed char)-(0x10000u - g0))); }
            }
            break; (void)(i1);
        } while (i0++ < 6u && (p0 ^ garr[u2 & 7u]));
    }
    c1 = (signed char)(unsigned)((short)0xe9c8572u > (signed char)(*q0 >> (garr[u2 & 7u] & 31u)));
    if (((unsigned)c1 & (r0.y + 0x80000000u))) goto L1;
    if ((unsigned)(unsigned char)(0xbcbbbefdu * 0x6e8853eeu)) goto L2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)((unsigned)((short)0x7fffffffu > (signed char)a0[u1 & 3u]) || 0x80000000u)) {
        garr[u3 & 7u] = (unsigned)((int)(0x107b6cd9u * (unsigned)f0) >= (int)(unsigned)b0);
        h0 = (short)(unsigned)s1;
        goto L2;
        if (budget != 0u) { budget -= 1u; u1 = fn0(u1, (unsigned)h0, (unsigned)!(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)c0)); }
    }
    goto L2;
    if (~(p1 / ((unsigned)w0 | 1u))) goto L1;
    b0 = 0xb8290e98u != 0u;
    l0 = (long)((unsigned long)l0 + 0x7951c42du);
    v0 = g0;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((p2 + (unsigned)((unsigned)(w0 >> 29) && (unsigned)(short)(4u / (*mp | 1u)))) & 255u);
        { unsigned t0; double z0; if (((((unsigned)h1 << ((unsigned)s0 & 31u)) ^ 0x10000u)) & 1u) { t0 = (unsigned)((short)p1 > (signed char)(unsigned)e0); z0 = (double)((((unsigned)w0 & (unsigned)(u2 || (unsigned)s1))) & 255u); } if (((((unsigned)h1 << ((unsigned)s0 & 31u)) ^ 0x10000u)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            h0 = (short)(unsigned)d0;
            d0 = d0 * 0.5 + (double)((unsigned)h1 & 1023u);
        }
        goto L3;
    }
    goto L2;
    u2 ^= (unsigned)((short)(unsigned)h0 > (signed char)(unsigned)!(*q0 + (unsigned)b0));
    switch ((unsigned)((int)(2u / (0x10000u | 1u)) < (int)(unsigned)w0) & 7u) {
        if (budget != 0u) { budget -= 1u; u1 = fn1((4u % (g0 | 1u)), m0, 0u); }
        if (fuel < 8u) return (r0.x & 0x80000000u);
    }
    switch (7u & 7u) {
        { unsigned t1; double z1; if (((unsigned)((int)(unsigned)!(6u | (unsigned)b0) >= (int)0x36913a8eu)) & 1u) { t1 = (u0 ? g0 : garr[u2 & 7u]); z1 = (double)((7u) & 255u); } if (((unsigned)((int)(unsigned)!(6u | (unsigned)b0) >= (int)0x36913a8eu)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            { unsigned t2; double z2; if (((unsigned)(u3 || garr[u2 & 7u])) & 1u) { t2 = (i0 + (unsigned)l0); z2 = (double)(((unsigned)((int)fuel >= (int)(unsigned)x0)) & 255u); } if (((unsigned)(u3 || garr[u2 & 7u])) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                if (budget != 0u) { budget -= 1u; u0 = fn3(((unsigned)c0 % (((unsigned)c1 - 0x39df701cu) | 1u)), (garr[i1 & 7u] ? 0xffffffffu : (unsigned)s1), (0xffffffffu << (r0.x & 31u))); }
                c1 = (signed char)(unsigned)l0;
                h1 = (unsigned short)(h1 + ((unsigned)(*mp && r0.y) * (unsigned)(9u || 0x4e41ceb5u)));
                if (0xffffffffu) goto done;
                l0 = (long)((unsigned long)l0 + (0xcf4aedd2u >> ((unsigned)(fuel || 1u) & 31u)));
                if ((i1 & (unsigned)((int)0xa372b1d4u < (int)u2))) break;
            }
            u1 = u1 * 0x9e3779b1u + (unsigned)(-(0x19e2e3d6u | a0[u1 & 3u]) && ((i1 - *mp) ^ (unsigned)d0));
            switch ((unsigned)((short)(unsigned)!((unsigned)d0 >> (a0[u1 & 3u] & 31u)) > (signed char)0x5820226bu) & 7u) {
                L0: if (--fuel == 0u) goto done;
                r0.x = (unsigned)!((unsigned)!((0x80000000u << (a0[i0 & 3u] & 31u)) % (4u | 1u)) & (0x2c40e0ebu ^ (unsigned)s1));
                case 2u: ;
                L1: if (--fuel == 0u) goto done;
                b0 = (unsigned)!(0x1a93ab34u / (0xffffffffu | 1u)) != 0u;
                L2: if (--fuel == 0u) goto done;
            }
            break; (void)((unsigned)(signed char)(unsigned)(3u || r0.y));
            *q0 = (3u ? 0x10000u : i1);
        }
        if (budget != 0u) { budget -= 1u; u0 = fn2(((0x7fffffffu << ((unsigned)s1 & 31u)) | 0xffffffffu), (unsigned)s0, (unsigned)(((unsigned)h1 + i0) && u1)); }
        l0 = (long)((unsigned long)l0 + ((unsigned)(a0[i0 & 3u] || (unsigned)s0) % ((unsigned)((int)(unsigned)s0 < (int)(unsigned)x0) | 1u)));
    }
    goto done;
    if (budget != 0u) { budget -= 1u; u2 = fn2((i2 | ((unsigned)s1 ^ p2)), (unsigned)(short)(unsigned)((short)0x80000000u > (signed char)u0), (unsigned)(short)(0x80000000u ^ (unsigned)((short)(unsigned)c1 > (signed char)(unsigned)s0))); }
    g0 = ((unsigned)(short)((unsigned)!((unsigned)f0 | (unsigned)e0) >> ((unsigned)s0 & 31u)) | (unsigned)c1);
    if ((unsigned)(a0[u1 & 3u] && (unsigned)((int)(unsigned)s1 >= (int)*mp))) goto L3;
    L3: if (--fuel == 0u) goto done;
    if (0xc24a95dfu) goto L4;
    q0 = &garr[(unsigned)((int)(unsigned)h1 < (int)garr[u2 & 7u]) & 7u];
    i0 = (unsigned)((int)0xffffffffu >= (int)(unsigned)(u1 < (unsigned)((int)(unsigned)!(0x10000u + (unsigned)f0) >= (int)(unsigned)w0))) & 15u;
    s0 = (int)(unsigned)((int)(i0 ^ (unsigned)c0) < (int)(u3 + 0x9054b741u));
    if ((g1 - 0x7844294au)) goto L2;
    L4: if (--fuel == 0u) goto done;
    if ((unsigned)(u1 == 0x7fffffffu)) goto L2;
    { unsigned t3; double z3; if ((0x5190bef9u) & 1u) { t3 = (r0.x * 0xffffffffu); z3 = (double)(((unsigned)x0) & 255u); } if ((0x5190bef9u) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        if ((unsigned)(2u || garr[i1 & 7u])) goto L1;
        if ((0x80000000u * 6u)) goto L2;
        if (i2) goto done;
        u0 ^= (unsigned)((short)((unsigned)((int)i2 < (int)g0) << (3u & 31u)) > (signed char)(0xffffffffu | garr[i1 & 7u]));
        u3 ^= (u0 ^ 5u);
    }
    e0 = e0 * 0.5L + (long double)((((p0 ? garr[i1 & 7u] : p0) ^ u3) & 0x7df00fb0u) & 1023u);
    goto L0;
    if (u1) {
        if ((2u + (unsigned)((int)p1 >= (int)(unsigned)s0))) goto L0;
    } else {
        if ((unsigned)(m0 && (unsigned)((unsigned)c0 || 0xffffffffu))) goto L2;
        if (~((unsigned)(short)(unsigned)((int)v0 < (int)(unsigned)e0) * (unsigned)d0)) {
            if (((unsigned)w0 << ((unsigned)h1 & 31u))) goto L4;
            switch ((0xffffffffu << (u3 & 31u)) & 7u) {
                h1 = (unsigned short)(h1 + i1);
                case 1u: ;
                i0 = ((unsigned)(*q0 < 0xea0c540du) - 0x1cd79d66u) & 15u;
                b0 = ((0x68e2ff03u | 6u) - (unsigned)((unsigned)h1 && a0[i0 & 3u])) != 0u;
                v0 = 0xc812941bu;
            }
            if ((p2 & m0)) goto L4;
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)s1, (m0 ^ (unsigned)s0), ((unsigned)x0 - 0x938266b9u)); }
            goto done;
            while (((unsigned)f0 * (unsigned)f0)) { if (--fuel == 0u) goto done;
                goto done;
                if ((0u << (0xaa57c261u & 31u))) break;
                if ((0x2c565c35u / (v0 | 1u))) break;
            }
        }
        if ((0x4ef57a45u - u0)) goto L0;
        h0 = (short)((0x7fffffffu >> (p0 & 31u)) - (unsigned)(0x7fffffffu || u3));
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)b0;
    if ((unsigned)((int)(unsigned)((int)g0 >= (int)i0) < (int)a0[u1 & 3u])) goto done;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = ((unsigned)c0 >> (~(u3 + (unsigned)h1) & 31u));
        if (((unsigned)c0 - (0x2e158fd7u ^ 0x80000000u))) break;
        if ((unsigned)(signed char)((unsigned)(short)((unsigned)l0 - m0) | m0)) goto L0;
        garr[0x80000000u & 7u] = (unsigned)((int)(unsigned)((unsigned)x0 && i0) >= (int)((unsigned)((int)(unsigned)d0 < (int)(unsigned)l0) / ((unsigned)b0 | 1u)));
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)b0, (5u | p1), (unsigned)!(((unsigned)l0 >> (i1 & 31u)) << (garr[i1 & 7u] & 31u))); }
    do { if (--fuel == 0u) goto done;
        v0 = ((unsigned)e0 | i2);
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)fuel >= (int)a0[i0 & 3u]), 0x10000u, 0x80000000u); }
        switch ((unsigned)((unsigned)h1 < garr[i1 & 7u]) & 7u) {
            if ((unsigned)((unsigned)d0 == (unsigned)((short)8u > (signed char)u1))) {
                case 6u: ;
                if (budget != 0u) { budget -= 1u; u0 = fn0(a0[u1 & 3u], (p1 << (u2 & 31u)), (unsigned)(w0 >> 29)); }
                for (;;) { if (--fuel == 0u) goto done;
                    *mp = (0xd1f8d077u << ((2u >> ((unsigned)x0 & 31u)) & 31u));
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((int)0x8f980275u >= (int)(unsigned)s0) * i0), (unsigned)((short)0x5188923du > (signed char)(unsigned)!(unsigned)(u3 == i0)), (unsigned)(unsigned char)(unsigned)(garr[u2 & 7u] == 1u)); }
                    if (i1) break;
                }
                while (i1++ < 2u && 0xffffffffu) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn2(fuel, (0x8e47eea4u % (p0 | 1u)), (unsigned)e0); }
                    if ((0x10000u & ((unsigned)w0 % (p0 | 1u)))) {
                        x0 = x0 * 0x100000001b3ull + ((unsigned)(0x92152533u && (unsigned)l0) >> ((0x7fffffffu >> ((unsigned)c0 & 31u)) & 31u));
                        g1 += (7u >> (fuel & 31u));
                        break; (void)(((unsigned)s0 % (*mp | 1u)));
                        while (i2++ < 2u && (unsigned)(r0.y && (unsigned)d0)) { if (--fuel == 0u) goto done;
                            if (((unsigned)w0 - 0xd54ecc88u)) break;
                            default: ;
                            break; (void)((unsigned)((int)(unsigned)s0 >= (int)r0.x));
                            if (p0) goto L3;
                        }
                    } else {
                        r0.x = (garr[u2 & 7u] & (g0 - r0.x));
                        break; (void)((unsigned)w0);
                        e0 = e0 * 0.5L + (long double)(0xddfd0ee2u & 1023u);
                        case 5u: ;
                    }
                    a0[(unsigned)((int)(unsigned)x0 < (int)a0[i0 & 3u]) & 3u] = (0x7fffffffu ? (unsigned)((int)0x7fffffffu < (int)(unsigned)s0) : *q0);
                    case 3u: ;
                }
                break;
            } else {
                if ((unsigned)e0) break;
                s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((short)i1 > (signed char)0x7fffffffu) >= (int)(unsigned)((int)v0 < (int)a0[i0 & 3u])));
            }
        }
    } while (i0++ < 3u && (unsigned)s0);
    if (~(r0.x >> ((unsigned)(signed char)((unsigned)c1 >> (fuel & 31u)) & 31u))) {
        if ((i0 + (unsigned)x0)) goto L1;
        while (i0++ < 5u && (((unsigned)w0 ^ 0x86dd0d36u) - 0xa37e3c02u)) { if (--fuel == 0u) goto done;
            if ((unsigned)x0) {
                if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(unsigned char)(9u % (garr[i1 & 7u] | 1u)) % (0xb8038435u | 1u)), (unsigned)h0, (unsigned)(i2 || 8u)); }
                if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)(p0 < (unsigned)(x0 >> 70)), (unsigned)((int)0xea6b7f2cu >= (int)0x7fffffffu), 0xe58f6061u); }
                if ((unsigned)s0) break;
                if (((unsigned)c0 % (*q0 | 1u))) break;
                *q0 += (unsigned)x0;
                if (((unsigned)b0 - 5u)) {
                    if ((unsigned)((unsigned)x0 && 7u)) break;
                    i1 = ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)i0) >> ((unsigned)!(i1 / (a0[u1 & 3u] | 1u)) & 31u)) & 15u;
                } else {
                    if (v0) continue;
                    if ((unsigned)(i1 == (unsigned)(x0 >> 70))) break;
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        c1 = (signed char)(unsigned)(0x10000u && ((*q0 & 0xfcffd45bu) ? i1 : (unsigned)f0));
                        if ((unsigned)(signed char)(v0 & (g1 + 0x10000u))) goto L2;
                        continue; (void)((unsigned)((int)i2 >= (int)0x80000000u));
                    }
                }
            } else {
                do { if (--fuel == 0u) goto done;
                    if ((garr[i1 & 7u] & (unsigned)((int)(unsigned)s1 < (int)u0))) break;
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (8u) break;
                        if (budget != 0u) { budget -= 1u; u0 = fn3((p0 | (unsigned)c0), (0x80000000u >> ((unsigned)((short)0x9acf8056u > (signed char)0x1293aad1u) & 31u)), (unsigned)((short)i2 > (signed char)0x80000000u)); }
                    }
                    if (((unsigned)x0 % ((r0.x - garr[u2 & 7u]) | 1u))) break;
                } while (i1++ < 4u && (unsigned)((int)(unsigned)(signed char)(0xd7588445u * 6u) >= (int)g0));
                if (g1) goto L0;
                while ((unsigned)(unsigned char)(0x80000000u - 0x240c5c99u)) { if (--fuel == 0u) goto done;
                    if (g1) break;
                    if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)h1 ^ (2u >> (0x7fffffffu & 31u))), (unsigned)((int)(unsigned)s0 >= (int)0x22a23284u), 0x80000000u); }
                    u0 ^= 7u;
                    if (u2) break;
                }
            }
            if (2u) break;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)l0) {
                    *mp = (-(unsigned)(g1 || u1) ^ ((unsigned)c0 / (0x15f4484u | 1u)));
                    if (((unsigned)s0 | 0x42c4a9beu)) break;
                    if ((unsigned)((int)(unsigned)(signed char)(0xc91a6a99u - 0x10000u) < (int)a0[u1 & 3u])) break;
                    if (fuel < 8u) return ((unsigned)s0 % ((u1 & ((unsigned)(unsigned char)(0xffffffffu - (unsigned)s1) + 7u)) | 1u));
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((garr[i1 & 7u] * 1u) * 0xf38be095u), 1u, p1); }
                    i1 = (unsigned)((int)1u < (int)(unsigned)(short)(0x201b6434u + (v0 - i1))) & 15u;
                    *mp = (-(unsigned)((unsigned)((unsigned)h1 < 0xcd6bcd34u) == a0[u1 & 3u]) + (0x7fffffffu >> (p1 & 31u)));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(i0 && 3u), 8u, (unsigned)((short)(unsigned)e0 > (signed char)0u)); }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)w0, (unsigned)c0, (8u ^ (unsigned)((int)*q0 < (int)2u))); }
                if (budget != 0u) { budget -= 1u; u2 = fn1((0xeb560f2eu % (p1 | 1u)), (unsigned)(u1 < u0), ((unsigned)(x0 >> 70) - 0x10000u)); }
                if ((unsigned)x0) break;
            } while (i1++ < 2u && (unsigned)((garr[u2 & 7u] ^ v0) == (unsigned)b0));
            if ((u2 % ((0u << ((unsigned)(x0 >> 70) & 31u)) | 1u))) break;
            while (i1++ < 4u && (unsigned)((int)(unsigned)(signed char)(unsigned)(fuel || 7u) >= (int)*q0)) { if (--fuel == 0u) goto done;
                break; (void)(0x9c58a67cu);
                v0 = ((unsigned)h1 % (0x766114b3u | 1u));
                if ((unsigned)((short)0xdee41898u > (signed char)((unsigned)d0 - *q0))) continue;
            }
            c0 = (unsigned char)(unsigned)s0;
        }
        *q0 = ((1u * (2u & (unsigned)b0)) ^ (u2 ^ 0x9ae866d7u));
        while (i0++ < 7u && 0x80000000u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(signed char)((0x71a6320bu * (unsigned)s1) % ((unsigned)l0 | 1u)), (8u ^ 0x7436be8fu), (0xd926d12du % (0xfae58d2u | 1u))); }
            if (budget != 0u) { budget -= 1u; u2 = fn1((0x10000u * *mp), (unsigned)d0, ((unsigned)((unsigned)(w0 >> 29) < m0) | r0.y)); }
        }
        if (budget != 0u) { budget -= 1u; u1 = fn3((fuel % ((g1 / ((unsigned)s1 | 1u)) | 1u)), (unsigned)e0, (unsigned)((unsigned)(u0 && (unsigned)w0) == 0x4d1cbcd9u)); }
        switch (0x983c1735u & 7u) {
            v0 = (0xc4ddc4cdu % ((unsigned)((int)(r0.x ? fuel : 0xffffffffu) >= (int)(unsigned)l0) | 1u));
            case 5u: ;
            *q0 = (unsigned)c1;
            switch ((0u - 0x354b763eu) & 7u) {
                if ((unsigned)(0x10000u == p0)) goto done;
                if (((unsigned)((short)(unsigned)w0 > (signed char)i0) * (unsigned)(x0 >> 70))) break;
                if (r0.y) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)d0, (garr[i1 & 7u] % ((unsigned)((int)a0[u1 & 3u] < (int)0xffffffffu) | 1u)), (0x8513721cu * (unsigned)c1)); }
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    case 7u: ;
                }
                if ((unsigned)((short)(0xa150e3e0u - 2u) > (signed char)fuel)) {
                    if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(0xffffffffu && a0[u1 & 3u]), 0xffffffffu, 9u); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0(i2, r0.y, 0xbb4087d2u); }
                    if (7u) goto done;
                    i0 = ((unsigned)(((unsigned)w0 + 5u) && u0) >> ((unsigned)(0xbb81a668u < 0x10000u) & 31u)) & 15u;
                    d0 = d0 * 0.5 + (double)(fuel & 1023u);
                    u0 += (unsigned)(unsigned char)(p1 + 0xffffffffu);
                } else {
                    default: ;
                    h0 = (short)(u0 ^ 0x80000000u);
                    u1 += *mp;
                }
            }
            e0 = e0 * 0.5L + (long double)((-(unsigned)(u0 < 0x80000000u) + (2u - ((unsigned)h0 + u0))) & 1023u);
        }
    } else {
        if ((unsigned)(short)(unsigned)(0x5d9696fbu && a0[i0 & 3u])) goto done;
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)l0;
    *mp = a0[i0 & 3u];
    v0 = ((r0.x << (0xed2615efu & 31u)) % (*q0 | 1u));
    *q0 = (unsigned)(u1 || (unsigned)(a0[u1 & 3u] && a0[u1 & 3u]));
    f0 = f0 * 0.5f + (float)(0xd830eb6du & 255u);
    g1 += (0x42059151u & (unsigned)(g0 == 0xab0194a7u));
    goto done;
    if (((unsigned)h0 ^ 0x10000u)) goto L2;
    h0 = (short)(unsigned)((short)((0x3fbfb103u ? garr[u2 & 7u] : garr[u2 & 7u]) ^ 0x10000u) > (signed char)0xce39cd70u);
    switch (0x7fffffffu & 7u) {
        goto done;
        case 0u: ;
        if ((unsigned)((int)0x3af7d501u >= (int)g1)) break;
    }
    if (((unsigned)c1 ^ (unsigned)w0)) goto L4;
    *q0 += 5u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 10u, 0x50c30b6au, 0xd2af515cu },
        { 5u, 0x2c22f7bcu, 0x9af20be6u },
        { 9u, 0xb3701cfau, 0xd58bde55u },
        { 0u, 0x9a90fbdu, 0xd413f479u },
        { 6u, 0x683135c0u, 0x5d17d27du },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
