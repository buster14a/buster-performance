// test-ssa-source's program of seed 134000411 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xb3c6de7au, g1 = 0x38f43205u;
static unsigned garr[8] = { 0x2f6bdefu, 0x8341188fu, 0x140c4391u, 0xb5e6160eu, 0x346b709u, 0x1c55d9f7u, 0xb0a8f8e4u, 0xe413ed8eu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        v0 = 0u;
        if ((unsigned)w0) goto L1;
    }
    r0.y ^= (unsigned)(x0 >> 70);
    do { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + ((unsigned)(short)(unsigned)((short)9u > (signed char)fuel) >> (p1 & 31u)));
        switch ((0x56988f50u / ((unsigned)c1 | 1u)) & 7u) {
            L0: if (--fuel == 0u) goto done;
            if ((unsigned)(x0 >> 70)) {
                i1 = (unsigned)(short)(p0 % ((unsigned)((g1 ? 8u : p1) && (unsigned)d0) | 1u)) & 15u;
                b0 = (i1 | (unsigned)h1) != 0u;
                u1 ^= (fuel & ((unsigned)l0 / (*q0 | 1u)));
                L1: if (--fuel == 0u) goto done;
                switch (~((unsigned)s1 ^ *q0) & 7u) {
                    *q0 = g1;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((i1 | (unsigned)w0) && i1)) break;
                        switch (6u & 7u) {
                            l0 = (long)((unsigned long)l0 + (unsigned)s1);
                            c0 = (unsigned char)p0;
                            break; (void)(fuel);
                            garr[(unsigned)(unsigned char)(unsigned)((unsigned)s0 == 7u) & 7u] = ((unsigned)c1 * (0x80000000u ? (unsigned)(signed char)(6u | 0xe6788734u) : 0x417e60acu));
                        }
                        s0 = (int)(unsigned)((int)(unsigned)w0 >= (int)a0[u1 & 3u]);
                    } while (i1++ < 2u && r0.x);
                    q0 = &garr[((unsigned)(0xf02c8854u && (unsigned)(u1 || (unsigned)w0)) >> (garr[i1 & 7u] & 31u)) & 7u];
                    if ((unsigned)c1) break;
                }
            }
            if ((unsigned)((short)i2 > (signed char)v0)) {
                switch ((6u ^ (unsigned)c1) & 7u) {
                    L2: if (--fuel == 0u) goto done;
                    if ((unsigned)(signed char)(0x969cc4b5u | 0xffffffffu)) {
                        L3: if (--fuel == 0u) goto done;
                        r0.y ^= ((unsigned)(short)(unsigned)((unsigned)(w0 >> 29) < u2) - u3);
                        u1 += u1;
                        goto L0;
                    }
                    case 3u: ;
                    h0 = (short)((unsigned)(v0 == (unsigned)((short)fuel > (signed char)8u)) - 0x7fffffffu);
                }
                f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)(short)(garr[i1 & 7u] << (0xe7a52dcdu & 31u)) | -(g1 ^ i2)) < (unsigned)h1) & 255u);
            }
            r0.x = (unsigned)(3u == (p1 / ((unsigned)(signed char)((unsigned)e0 ? (unsigned)d0 : (unsigned)(x0 >> 70)) | 1u)));
            L4: if (--fuel == 0u) goto done;
        }
        u2 = ((unsigned)x0 / (p1 | 1u));
        while (i1++ < 5u && ((unsigned)x0 - (unsigned)b0)) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                a0[0x80000000u & 3u] = (unsigned)((unsigned)(i0 == *q0) == ((unsigned)c0 >> ((unsigned)c1 & 31u)));
                if (((unsigned)b0 << (((unsigned)d0 & p2) & 31u))) goto L2;
                { unsigned t0; double z0; if ((0x10000u) & 1u) { t0 = 0xffffffffu; z0 = (double)((((0x7fffffffu + 0x72cf016au) % (0x10000u | 1u))) & 255u); } if ((0x10000u) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                    if (r0.x) break;
                    m0 ^= (unsigned)!(unsigned)(((unsigned)s1 + i1) || a0[u1 & 3u]);
                    g1 += (unsigned)(unsigned char)(m0 ^ (unsigned)h1);
                    garr[((unsigned)(x0 >> 70) + (unsigned)d0) & 7u] = (0x7fffffffu % (0xffffffffu | 1u));
                }
            } while (i2++ < 7u && g0);
            if ((unsigned)(a0[u1 & 3u] < (unsigned)((unsigned)s1 || (unsigned)h0))) continue;
            if (u2) continue;
            break; (void)((0x585d510u << (~(unsigned)((short)r0.x > (signed char)(unsigned)f0) & 31u)));
            if ((r0.x * (unsigned)s1)) continue;
            if ((unsigned)((int)0x14c054du < (int)0u)) {
                if (((unsigned)(0x1b43bf4eu && (unsigned)h1) - 0x80000000u)) break;
                c1 = (signed char)(unsigned)(i2 < u1);
                if ((unsigned)(garr[i1 & 7u] || 0xffffffffu)) break;
                if ((0xba3d5e23u + (unsigned)f0)) {
                    x0 = x0 * 0x100000001b3ull + -((unsigned)((unsigned)b0 < g1) + (unsigned)((a0[i0 & 3u] / ((unsigned)s0 | 1u)) == r0.x));
                }
            }
        }
        { unsigned t1; double z1; if ((0xffffffffu) & 1u) { t1 = (unsigned)s1; z1 = (double)(((unsigned)((unsigned)(u1 || (unsigned)h0) || u2)) & 255u); } if ((0xffffffffu) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            c1 = (signed char)((unsigned)b0 & (u3 * i2));
            if (u3 == 7u) return m0;
            if (((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)l0) - fuel)) break;
        }
        x0 = x0 * 0x100000001b3ull + i0;
    } while (i0++ < 2u && ((unsigned)d0 ? *mp : i0));
    if ((unsigned)(0x10000u < (unsigned)((int)p0 >= (int)v0))) goto done;
    *q0 = (unsigned)(w0 >> 29);
    q0 = &garr[(r0.y & (unsigned)c1) & 7u];
    if ((0x26fdea44u ^ r0.x)) goto L0;
    if (fuel) {
        if ((unsigned)(0x24215f5u || (unsigned)((unsigned)s1 || garr[u2 & 7u]))) goto done;
    } else {
        u3 ^= (garr[i1 & 7u] + (unsigned)s1);
        g0 = *mp;
    }
    if (-((unsigned)f0 ^ (i2 & 0x73709959u))) {
        r0.y ^= (*mp / (garr[u2 & 7u] | 1u));
        goto L2;
        if (((unsigned)s1 ? (unsigned)h0 : g0)) goto L3;
    } else {
        if ((unsigned)c1) goto L0;
    }
    goto L3;
    d0 = d0 * 0.5 + (double)((2u + (i2 ^ (*q0 % (g1 | 1u)))) & 1023u);
    if ((u2 & m0)) {
        switch (((unsigned)(unsigned char)(*mp >> (u0 & 31u)) ^ 3u) & 7u) {
            case 0u: ;
            u2 = u2 * 0x9e3779b1u + (unsigned)x0;
            { unsigned t2; double z2; if (((i0 % ((unsigned)d0 | 1u))) & 1u) { t2 = (unsigned)(7u && u0); z2 = (double)((((unsigned)h1 * v0)) & 255u); } if (((i0 % ((unsigned)d0 | 1u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                *q0 += g0;
                h0 = (short)(unsigned)((unsigned)(0x9243f299u == (unsigned)l0) || (unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)(p2 && 0u)));
                goto L4;
                case 6u: ;
            }
            b0 = (unsigned)((short)(v0 - r0.y) > (signed char)(unsigned)((short)a0[u1 & 3u] > (signed char)(0xf2524188u + p0))) != 0u;
            h0 = (short)(unsigned)((int)(unsigned)((int)0x10000u < (int)0x7fffffffu) < (int)(i1 + (*q0 | m0)));
            case 5u: ;
        }
    }
    if (u3 == 7u) return (1u / ((0x10000u ? (unsigned)(x0 >> 70) : (unsigned)e0) | 1u));
    while (i0++ < 2u && 0x7fffffffu) { if (--fuel == 0u) goto done;
        g1 += m0;
        break; (void)((unsigned)((0x3f7a0f10u >> ((unsigned)e0 & 31u)) == (unsigned)l0));
        break; (void)(p1);
        u0 = ((unsigned)(x0 >> 70) + garr[u2 & 7u]);
        do { if (--fuel == 0u) goto done;
            if (((unsigned)c0 * 9u)) break;
            a0[(unsigned)h0 & 3u] = (0x5fed8de1u >> (u1 & 31u));
            if (0x80000000u) {
                u0 = ((unsigned)e0 | 8u);
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)h0 < 0x80000000u));
                q0 = &garr[(unsigned)(0x10000u == (unsigned)l0) & 7u];
                h1 = (unsigned short)(h1 + (v0 >> (*mp & 31u)));
            } else {
                if ((unsigned)(signed char)(i1 | (unsigned)(0x7fffffffu || 0x1dff5d79u))) break;
                if (((unsigned)s0 / (7u | 1u))) break;
            }
            x0 = x0 * 0x100000001b3ull + (unsigned)!((i0 / ((7u | g1) | 1u)) * (unsigned)(0x52343f2eu && *q0));
            for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)(0x7fffffffu == 1u) << ((unsigned)((int)((unsigned)s0 << ((unsigned)s0 & 31u)) < (int)(g1 % (0xccdbe8c8u | 1u))) & 63u);
                l0 = (long)((unsigned long)l0 + (8u >> (0u & 31u)));
            }
        } while (i1++ < 2u && (unsigned)((unsigned)((int)9u >= (int)u0) == (unsigned)c1));
    }
    if ((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)((short)(unsigned)e0 > (signed char)i0))) {
        if (p1) goto done;
        while ((0x80000000u / (p2 | 1u))) { if (--fuel == 0u) goto done;
            if (i2) {
                g0 = fuel;
                if ((unsigned)(0x20ab2fcfu || ~(unsigned)(0x81f1b152u == v0))) continue;
                m0 ^= ((p2 / (p1 | 1u)) | (0x6a03dd52u << (a0[i0 & 3u] & 31u)));
                q0 = &garr[(unsigned)((short)g1 > (signed char)((unsigned)((short)(unsigned)h1 > (signed char)a0[u1 & 3u]) ^ 0xffffffffu)) & 7u];
                if (((unsigned)(x0 >> 70) - 9u)) break;
            } else {
                if ((8u + garr[u2 & 7u])) break;
                r0.x = 0x7fffffffu;
                if ((0x7fffffffu << (a0[i0 & 3u] & 31u))) break;
            }
            g0 = garr[i1 & 7u];
        }
        { unsigned t3; double z3; if (((2u | 8u)) & 1u) { t3 = (0x10000u * (unsigned)e0); z3 = (double)((((unsigned)(short)(0x70f660ceu << (0x80000000u & 31u)) | i2)) & 255u); } if (((2u | 8u)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            v0 = (unsigned)((unsigned)l0 == i2);
            do { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)s0 < (unsigned)(short)(unsigned)(a0[u1 & 3u] < (unsigned)c0))) break;
                    x0 = x0 * 0x100000001b3ull + (0xd6728024u * (unsigned)(signed char)(unsigned)(i0 == r0.x));
                    u1 += ((unsigned)b0 >> ((unsigned)((unsigned)((9u ^ i2) == (unsigned)e0) || p1) & 31u));
                }
                i0 = (((unsigned)h0 ? (u0 >> ((unsigned)c1 & 31u)) : (unsigned)(x0 >> 70)) * r0.y) & 15u;
                if ((unsigned)(x0 >> 70)) goto L3;
                if ((p1 % ((i0 / ((unsigned)(x0 >> 70) | 1u)) | 1u))) break;
                w0 = w0 * 6364136223846793005ull + (unsigned)(fuel || (unsigned)((int)(unsigned)d0 >= (int)p0));
            } while (i0++ < 5u && (unsigned)h0);
            do { if (--fuel == 0u) goto done;
                switch ((unsigned)((int)((unsigned)x0 & g0) >= (int)a0[u1 & 3u]) & 7u) {
                    if (*q0) {
                        case 4u: ;
                        case 2u: ;
                        case 6u: ;
                        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                            case 0u: ;
                            case 7u: ;
                            default: ;
                        }
                    } else {
                        if (((unsigned)(x0 >> 70) / ((unsigned)b0 | 1u))) break;
                        break; (void)((unsigned)((int)(unsigned)((short)0x8a10b7a8u > (signed char)m0) < (int)9u));
                        a0[i1 & 3u] = (unsigned)(((unsigned)b0 - (unsigned)d0) == p0);
                    }
                }
                break; (void)(v0);
                e0 = e0 * 0.5L + (long double)((((unsigned)s1 & v0) / ((0xd4a5439du / (garr[i1 & 7u] | 1u)) | 1u)) & 1023u);
                if ((unsigned)(unsigned char)(unsigned)(g1 && 0x80000000u)) break;
                g1 += ((unsigned)x0 ? u2 : 0xc1c2dcdbu);
            } while (i0++ < 5u && (unsigned)((int)a0[u1 & 3u] >= (int)a0[u1 & 3u]));
        }
    } else {
        if (0x80000000u) goto L2;
        { unsigned t4; double z4; if (((0x9f0c0d03u - 0x276fc850u)) & 1u) { t4 = 8u; z4 = (double)((((9u * u0) % (6u | 1u))) & 255u); } if (((0x9f0c0d03u - 0x276fc850u)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
            if ((unsigned)((int)(unsigned)((short)a0[i0 & 3u] > (signed char)0x5f9faa1u) < (int)g0)) goto L2;
            goto L3;
            c1 = (signed char)(unsigned)(i2 || i0);
        }
        *q0 += (r0.x + ((unsigned)(x0 >> 70) ? *mp : 8u));
    }
    b0 = (unsigned)((u3 + p0) || (unsigned)(signed char)(unsigned)((int)(unsigned)l0 < (int)(unsigned)!(0u / ((unsigned)c0 | 1u)))) != 0u;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= (*mp / ((4u % ((unsigned)l0 | 1u)) | 1u));
        if ((g0 | (unsigned)s0)) break;
    }
    if ((0xffffffffu % ((unsigned)c0 | 1u))) {
        goto done;
        c0 = (unsigned char)0x10000u;
        g0 = ((unsigned)((unsigned)(x0 >> 70) == (unsigned)((short)(unsigned)s1 > (signed char)0u)) >> (i1 & 31u));
        { unsigned t5; double z5; if ((u3) & 1u) { t5 = (unsigned)f0; z5 = (double)(((i1 / ((unsigned)s0 | 1u))) & 255u); } if ((u3) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            if ((0x70c1f356u & (unsigned)w0)) {
                if (u2) goto L1;
                v0 = 0x2e9383f4u;
                if (((unsigned)h0 % ((unsigned)c0 | 1u))) goto done;
            }
            if (((unsigned)b0 + a0[u1 & 3u])) goto done;
            u1 += (p0 & (6u - (*mp / (0xd23ef649u | 1u))));
            while (i0++ < 3u && (unsigned)((short)p1 > (signed char)*mp)) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(-(unsigned)(a0[u1 & 3u] == (unsigned)s0) & 255u);
            }
            switch (((*q0 & (unsigned)(x0 >> 70)) % ((unsigned)(w0 >> 29) | 1u)) & 7u) {
                if ((unsigned)w0) break;
                f0 = f0 * 0.5f + (float)((*q0 - (unsigned)(short)(u0 << (((unsigned)c1 - u2) & 31u))) & 255u);
                case 5u: ;
                u0 = (unsigned)l0;
                *q0 += (((unsigned)(unsigned char)((unsigned)x0 & 0xac24853u) * u1) ^ (unsigned)(short)(g0 | i1));
                i1 = (unsigned)((int)0xcd9089e9u >= (int)(unsigned)l0) & 15u;
            }
        }
    } else {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t6; double z6; if (((p0 ? 9u : (unsigned)(x0 >> 70))) & 1u) { t6 = (0x80000000u % ((unsigned)(0x10000u < 3u) | 1u)); z6 = (double)((p0) & 255u); } if (((p0 ? 9u : (unsigned)(x0 >> 70))) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                if ((u3 ^ 0u)) break;
                a0[*q0 & 3u] = ((unsigned)((int)u3 < (int)g1) >> (((unsigned)((int)8u < (int)(unsigned)d0) << ((unsigned)s1 & 31u)) & 31u));
            }
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(((unsigned)e0 << ((unsigned)x0 & 31u)) || a0[i0 & 3u]));
                v0 = ((unsigned)((int)(p2 >> (r0.x & 31u)) >= (int)(unsigned)((int)(unsigned)l0 < (int)(unsigned)s1)) >> (0xa9f3b67cu & 31u));
                g1 += (0x10000u & ((unsigned)(0x10000u && 0x10000u) ^ (unsigned)w0));
                continue; (void)(g0);
                u1 += -((unsigned)(((unsigned)s0 + i0) == 8u) ^ g0);
            }
            break; (void)((unsigned)((short)0x10000u > (signed char)0x5ff1407fu));
            if (0x7fffffffu) break;
            q0 = &garr[((unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x2e931295u) >> (u3 & 31u)) & 7u];
        }
    }
    s1 = (int)((unsigned)s1 + (unsigned)((short)0x10000u > (signed char)(unsigned)((short)(unsigned)h0 > (signed char)(unsigned)((unsigned)e0 == (unsigned)l0))));
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        b0 = (unsigned)s0 != 0u;
        if ((unsigned)((unsigned)d0 || (unsigned)e0)) {
            f0 = f0 * 0.5f + (float)((unsigned)((int)0x7fffffffu >= (int)(unsigned)(*q0 == g1)) & 255u);
            if ((unsigned)((int)0x10000u < (int)r0.x)) {
                if ((g0 % (7u | 1u))) break;
                r0.x = (unsigned)(0x7fffffffu < ((m0 & (unsigned)h0) & 0x312a03e9u));
                h1 = (unsigned short)(h1 + (unsigned)((short)m0 > (signed char)*mp));
                c0 = (unsigned char)i0;
            } else {
                c0 = (unsigned char)(unsigned)((int)(unsigned)l0 >= (int)(6u % (u3 | 1u)));
            }
            if ((9u & ((unsigned)d0 | 0x10000u))) {
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(x0 >> 70)) break;
                    if (((unsigned)b0 | (i1 / (u3 | 1u)))) goto L0;
                    garr[(0xffffffffu % ((unsigned)e0 | 1u)) & 7u] = g0;
                }
                g0 = (unsigned)(0x163d0f1du || v0);
                goto done;
            } else {
                if ((a0[u1 & 3u] << (p1 & 31u))) break;
                if ((unsigned)(p0 || -(0x7fffffffu << ((unsigned)(w0 >> 29) & 31u)))) break;
                m0 ^= (u0 % (((2u - 2u) & i2) | 1u));
                for (;;) { if (--fuel == 0u) goto done;
                    g1 += (6u ? r0.x : (unsigned)(w0 >> 29));
                    m0 ^= (unsigned)((unsigned)((int)(unsigned)(u3 == 0x2e88d31au) < (int)5u) == (a0[i0 & 3u] | (unsigned)h1));
                    h1 = (unsigned short)(h1 + ((unsigned)(p1 || (unsigned)(garr[u2 & 7u] && 0x80000000u)) * (unsigned)(4u < r0.y)));
                }
            }
            if ((unsigned)((short)(unsigned)h1 > (signed char)0u)) continue;
            if (((r0.x >> (a0[i0 & 3u] & 31u)) | g0)) break;
            if ((unsigned)((unsigned)(0xe1bcf4a0u || r0.y) && (unsigned)d0)) break;
        }
    }
    u0 = u0 * 0x9e3779b1u + (garr[u2 & 7u] << (0x659fcc4eu & 31u));
    b0 = (p1 & 0x25ed9b22u) != 0u;
    r0.x = (u2 | -((unsigned)l0 % (r0.y | 1u)));
    s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)(unsigned char)((unsigned)l0 & 8u) >= (int)(a0[u1 & 3u] - 0xf6e6dacfu)));
    { unsigned t7; double z7; if ((((0x7fffffffu << (7u & 31u)) / ((unsigned)c0 | 1u))) & 1u) { t7 = (unsigned)f0; z7 = (double)(((unsigned)c0) & 255u); } if ((((0x7fffffffu << (7u & 31u)) / ((unsigned)c0 | 1u))) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
        if (~(a0[u1 & 3u] & (unsigned)c0)) goto L0;
        h1 = (unsigned short)(h1 + (unsigned)b0);
        do { if (--fuel == 0u) goto done;
            *q0 += (unsigned)((short)0u > (signed char)(garr[i1 & 7u] ? garr[i1 & 7u] : 0xa5f94c51u));
            if (fuel) break;
            { unsigned t8; double z8; if (((a0[u1 & 3u] - (u0 * (unsigned)(x0 >> 70)))) & 1u) { t8 = (unsigned)(unsigned char)(garr[i1 & 7u] + 0x8610b24eu); z8 = (double)(((i2 - (unsigned)h1)) & 255u); } if (((a0[u1 & 3u] - (u0 * (unsigned)(x0 >> 70)))) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                if (a0[u1 & 3u]) break;
                if ((0x62fe948du / (u3 | 1u))) goto L1;
                *mp = (unsigned)l0;
                i1 = (unsigned)((unsigned)((int)(unsigned)d0 < (int)((unsigned)d0 ^ (unsigned)c1)) && (*mp << (u3 & 31u))) & 15u;
                a0[(unsigned)e0 & 3u] = (unsigned)((short)(3u ^ (unsigned)c1) > (signed char)0xac6c2edu);
                u0 ^= (unsigned)((unsigned)((unsigned)f0 || 7u) < r0.y);
            }
            u0 = ((0x45c84cb1u + (0x514d2f8au % ((unsigned)d0 | 1u))) >> ((p2 << (v0 & 31u)) & 31u));
            do { if (--fuel == 0u) goto done;
                if (0u) break;
                c1 = (signed char)(unsigned)(0x7fffffffu && (unsigned)(x0 >> 70));
                { unsigned t9; double z9; if (((unsigned)((int)(unsigned)(0x7fffffffu < 0xe0fdb2eeu) >= (int)*mp)) & 1u) { t9 = (unsigned)((u2 >> ((unsigned)(w0 >> 29) & 31u)) < (unsigned)d0); z9 = (double)(((u2 - p2)) & 255u); } if (((unsigned)((int)(unsigned)(0x7fffffffu < 0xe0fdb2eeu) >= (int)*mp)) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                    i0 = (unsigned)(short)(unsigned)((short)(*q0 - (unsigned)w0) > (signed char)(unsigned)f0) & 15u;
                    h0 = (short)(unsigned)(signed char)((unsigned)((unsigned)s1 == (unsigned)c1) ? (unsigned)((int)i0 >= (int)7u) : (unsigned)b0);
                }
                g0 = ((unsigned)h0 / ((9u % ((unsigned)(*mp || (unsigned)(x0 >> 70)) | 1u)) | 1u));
                if (garr[u2 & 7u]) break;
                *mp = ((unsigned)d0 % ((8u / ((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)w0) | 1u)) | 1u));
            } while (i1++ < 7u && (a0[u1 & 3u] >> ((0xc09ccbf1u * 0xffffffffu) & 31u)));
        } while (i0++ < 4u && -(unsigned)((p0 << ((unsigned)s1 & 31u)) < 3u));
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = (unsigned)((unsigned)!(0x1ef28bu - (unsigned)(x0 >> 70)) < (p1 - ((unsigned)s0 * a0[i0 & 3u])));
        *mp = ((unsigned)c0 * (unsigned)(short)(unsigned)((unsigned)x0 < (unsigned)((int)1u >= (int)(unsigned)x0)));
        if ((6u - r0.y)) break;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((0xad22d1f9u * 0x10000u)) goto L2;
            }
        }
        h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)s1 > (signed char)u3));
        if (-(unsigned)(u1 && garr[i1 & 7u])) break;
    }
    if ((unsigned)(w0 >> 29)) goto done;
    r0.x = (unsigned)((int)garr[u2 & 7u] < (int)0xf5b1249bu);
    if ((unsigned)((unsigned)l0 || 0x80000000u)) goto L1;
    if (((unsigned)c1 % ((unsigned)h0 | 1u))) goto L4;
    goto L3;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)e0) break;
    }
    *q0 = (unsigned)(unsigned char)(unsigned)(garr[u2 & 7u] && ((6u & 0x92667c5bu) << (0xa3d9a0edu & 31u)));
    do { if (--fuel == 0u) goto done;
        if (((garr[u2 & 7u] << (a0[i0 & 3u] & 31u)) & *mp)) break;
        if ((unsigned)(p2 == 6u)) break;
    } while (i0++ < 2u && (unsigned)(short)(unsigned)((unsigned)x0 && (unsigned)s0));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        g0 = ((garr[i1 & 7u] % ((unsigned)c1 | 1u)) - (unsigned)((int)(0x80000000u << (0x1cc33371u & 31u)) < (int)i1));
        if (a0[u1 & 3u]) break;
        if (a0[u1 & 3u]) break;
    } while (i0++ < 3u && 0x629ec3b2u);
    { unsigned t0; double z0; if ((0x7fffffffu) & 1u) { t0 = (u2 << (7u & 31u)); z0 = (double)(((i2 >> (g0 & 31u))) & 255u); } if ((0x7fffffffu) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        while (i0++ < 5u && ((unsigned)e0 ^ (unsigned)!(p0 ^ (unsigned)x0))) { if (--fuel == 0u) goto done;
            if (u3 == 7u) return (unsigned)((int)u0 < (int)0x80000000u);
        }
    }
    if (garr[i1 & 7u]) {
        x0 = x0 * 0x100000001b3ull + (unsigned)(3u && (unsigned)c0);
        L0: if (--fuel == 0u) goto done;
        *q0 += (unsigned)((int)(unsigned)((int)p2 < (int)(unsigned)e0) >= (int)(unsigned)((short)(p0 / ((unsigned)e0 | 1u)) > (signed char)garr[i1 & 7u]));
        u0 = u0 * 0x9e3779b1u + (unsigned)((short)(unsigned)w0 > (signed char)(u3 | ((unsigned)l0 - (unsigned)(x0 >> 70))));
        m0 ^= a0[u1 & 3u];
    }
    if ((*q0 << ((7u / (p2 | 1u)) & 31u))) {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                garr[(*q0 / ((unsigned)c0 | 1u)) & 7u] = (unsigned)(short)(unsigned)((*mp - i1) || 0x10000u);
                w0 ^= (unsigned long long)*q0 << ((unsigned)((unsigned)(x0 >> 70) || ((unsigned)w0 / ((u3 - p0) | 1u))) & 63u);
                L2: if (--fuel == 0u) goto done;
            } while (i1++ < 2u && (v0 - -(p1 / (m0 | 1u))));
        }
        if ((unsigned)s1) {
            c0 = (unsigned char)~(unsigned)((unsigned)s0 || u1);
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)(w0 >> 29) >= (int)u1), (unsigned)c1, (unsigned)(((unsigned)f0 & 7u) < (unsigned)x0)); }
        } else {
            *q0 += (unsigned)(((unsigned)h0 << (u2 & 31u)) < (unsigned)((int)(unsigned)((int)u2 >= (int)0x2ebca90eu) >= (int)0x80000000u));
            i1 = ((unsigned)(0x66553331u && (unsigned)h0) >> (p2 & 31u)) & 15u;
            if ((unsigned)((unsigned)s1 || (unsigned)h0)) goto L1;
        }
        r0.x = (unsigned)((short)(unsigned)!(unsigned)(0xffffffffu < 0x6b7b88c0u) > (signed char)3u);
        if (0u) {
            switch ((0u % (0x80000000u | 1u)) & 7u) {
                u1 = (unsigned)((short)(g1 >> (i0 & 31u)) > (signed char)(unsigned)((int)p0 >= (int)a0[i0 & 3u]));
            }
            *q0 += ((unsigned)(w0 >> 29) * r0.y);
            u2 ^= u3;
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)(i0);
                r0.x = (unsigned)((int)4u < (int)m0);
            }
            garr[0xa1f68f2eu & 7u] = 7u;
            if ((0xffffffffu >> (p2 & 31u))) goto L2;
        } else {
            if ((unsigned)((unsigned)(*mp == fuel) && (unsigned)w0)) goto L2;
            if (budget != 0u) { budget -= 1u; u0 = fn0(0x10000u, (8u | g0), u1); }
        }
    } else {
        while (i0++ < 7u && 0xdde718d4u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)0xffffffffu < (int)(unsigned)c0)) goto L1;
            d0 = d0 * 0.5 + (double)((unsigned)(3u < ((unsigned)(0x39efe3d4u && (unsigned)x0) | ((unsigned)l0 ^ (unsigned)e0))) & 1023u);
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    while ((unsigned)b0) { if (--fuel == 0u) goto done;
                        if (fuel < 8u) return (unsigned)((int)(unsigned)h0 >= (int)0xeeddc065u);
                        a0[0x7fffffffu & 3u] = (0x9bd507dcu ? 4u : 0xea4ef6b9u);
                        u3 = u3 * 0x9e3779b1u + (0u ? (unsigned)(x0 >> 70) : u2);
                        break; (void)((unsigned)((int)g0 >= (int)0x10000u));
                    }
                }
            }
            goto L0;
        }
        if ((unsigned)((*mp >> (0x10000u & 31u)) && 3u)) goto L4;
        if (3u) goto L1;
        if ((u2 % ((0xffffffffu << (u0 & 31u)) | 1u))) {
            L3: if (--fuel == 0u) goto done;
            goto L2;
        }
    }
    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)!(unsigned)((unsigned)l0 < (unsigned)(0x73b32df3u && (unsigned)w0)) && (u1 / (0x57b8cd94u | 1u))));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = ((unsigned)l0 | m0);
        if (((unsigned)(x0 >> 70) + (unsigned)(r0.x < (unsigned)l0))) break;
        if ((unsigned)((unsigned)((short)garr[u2 & 7u] > (signed char)garr[u2 & 7u]) || 0xffffffffu)) goto L4;
        if ((unsigned)((short)2u > (signed char)-((unsigned)x0 % (0x10000u | 1u)))) break;
        l0 = (long)((unsigned long)l0 + ((1u & *mp) << (0x513d2025u & 31u)));
        f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)e0 < (int)(unsigned)x0) & 255u);
    }
    *q0 = (unsigned)(i2 < (unsigned)((int)(unsigned)s0 < (int)(3u % (0xec1335cfu | 1u))));
    L4: if (--fuel == 0u) goto done;
    while (i0++ < 5u && (a0[u1 & 3u] - (unsigned)d0)) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((g0 << (0u & 31u)), p0, i1); }
    }
    goto L1;
    c0 = (unsigned char)i0;
    if ((unsigned)(signed char)(0x7fffffffu + fuel)) goto L3;
    r0.y ^= (r0.x ? 0x12d7ff0fu : 0x4a700be6u);
    switch ((unsigned)(unsigned char)(unsigned)(u2 || i0) & 7u) {
        case 0u: ;
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)x0 < (int)(unsigned)((short)a0[i0 & 3u] > (signed char)0x10000u)), (0x10000u - (unsigned)((unsigned)s0 && u2)), (0x80000000u & (unsigned)f0)); }
        case 6u: ;
    }
    a0[(unsigned)(p1 < 3u) & 3u] = (((unsigned)(short)(unsigned)((int)0xea7851a5u < (int)2u) % (0x10000u | 1u)) >> ((unsigned)d0 & 31u));
    u3 += ((unsigned)(p1 < (unsigned)((short)(unsigned)(0x7fffffffu < g0) > (signed char)(unsigned)b0)) * g0);
    goto done;
    goto L2;
    h0 = (short)(u0 | (*q0 | *q0));
    goto L2;
    u0 ^= 0x7fffffffu;
    switch ((unsigned)((unsigned)c1 == (unsigned)((int)u2 >= (int)(unsigned)c1)) & 7u) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 6u: ;
                case 7u: ;
            }
            case 0u: ;
            while (i1++ < 2u && (unsigned)(p0 && (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)((int)6u >= (int)*q0);
                    if (1u) continue;
                    if (m0) {
                        case 4u: ;
                    } else {
                        default: ;
                        w0 ^= (unsigned long long)(unsigned)d0 << (((unsigned)d0 >> ((unsigned)((int)((unsigned)(u3 && g0) / (i0 | 1u)) >= (int)5u) & 31u)) & 63u);
                        if ((0x7fffffffu | (unsigned)h0)) goto L4;
                    }
                    e0 = e0 * 0.5L + (long double)((0xca277394u + *mp) & 1023u);
                }
                if ((unsigned)(g1 || (p2 ^ u0))) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)d0 || u3), g0, ((i0 * 0x7fffffffu) ^ g0)); }
                    c1 = (signed char)((unsigned)(2u < 8u) ^ 0x80000000u);
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)b0 ^ a0[u1 & 3u]), (unsigned)h0, (0x10000u / (p1 | 1u))); }
                    break; (void)((unsigned)((int)0x80000000u >= (int)(unsigned)(w0 >> 29)));
                    u0 += *mp;
                    r0.y ^= (unsigned)((unsigned)(unsigned char)((unsigned)((int)(unsigned)((unsigned)s1 && 2u) >= (int)0x70ce773bu) - u1) < (unsigned)w0);
                }
                if ((unsigned)((6u % (0x868f2b0du | 1u)) && 0xd4a9246au)) goto L3;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)(x0 >> 70) >= (int)v0), (((unsigned)l0 >> (*mp & 31u)) >> (0xe12742e4u & 31u)), (unsigned)c1); }
            }
            e0 = e0 * 0.5L + (long double)(1u & 1023u);
        }
        c0 = (unsigned char)(unsigned)(w0 >> 29);
        m0 ^= (unsigned)!((unsigned)((int)u0 >= (int)0u) ^ (unsigned)w0);
        if ((0x80000000u ? garr[u2 & 7u] : (unsigned)x0)) {
            q0 = &garr[((0x4ff58af5u | 4u) - 0x7fffffffu) & 7u];
            d0 = d0 * 0.5 + (double)((9u >> ((unsigned)s1 & 31u)) & 1023u);
        } else {
            u2 ^= (unsigned)h1;
            u3 ^= ((unsigned)h1 - (2u * v0));
            w0 = w0 * 6364136223846793005ull + (unsigned)(short)(unsigned)((unsigned)c1 && garr[u2 & 7u]);
            switch (p2 & 7u) {
                case 2u: ;
                case 7u: ;
                if ((unsigned)(((unsigned)w0 >> (p0 & 31u)) < 4u)) goto done;
                case 3u: ;
                if (budget != 0u) { budget -= 1u; u3 = fn0(1u, -(unsigned)(0x5bb1a09bu == (unsigned)(unsigned char)(unsigned)((short)garr[u2 & 7u] > (signed char)8u)), (unsigned)(i1 || 0x7fffffffu)); }
                if (u3 == 7u) return (unsigned)((unsigned)((i0 / (0xa83fdb2eu | 1u)) || (unsigned)x0) < 0xf3f97af4u);
            }
        }
    }
    do { if (--fuel == 0u) goto done;
        v0 = (unsigned)((0x10000u / (u3 | 1u)) < (unsigned)(1u && garr[u2 & 7u]));
        if ((0xd99b695u + *q0)) goto L1;
        c1 = (signed char)(i1 | (unsigned)(signed char)(0x80000000u << ((unsigned)x0 & 31u)));
        f0 = f0 * 0.5f + (float)((unsigned)(short)((unsigned)(short)(unsigned)((int)a0[u1 & 3u] < (int)(unsigned)b0) & (unsigned)s0) & 255u);
    } while (i0++ < 2u && (unsigned)(0x4388c041u < (0x10000u - (unsigned)f0)));
    if ((unsigned)(m0 < (unsigned)c1)) {
        if (fuel < 8u) return (0x80000000u ? (unsigned)s1 : 0xffffffffu);
    }
    if ((((unsigned)x0 + u3) * r0.x)) goto done;
    if ((unsigned)!(unsigned)((int)p0 >= (int)(unsigned)h1)) goto L1;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)*mp << ((unsigned)d0 & 63u);
            r0.y ^= (unsigned)((int)(*mp ^ (unsigned)((int)v0 >= (int)(unsigned)(w0 >> 29))) < (int)*mp);
        }
        w0 = w0 * 6364136223846793005ull + (-(unsigned)((int)g0 < (int)p1) % (0xe27503d6u | 1u));
    }
    c1 = (signed char)(unsigned)(0u && ((unsigned)((short)u2 > (signed char)(unsigned)s0) + (unsigned)(signed char)((unsigned)e0 / ((unsigned)f0 | 1u))));
    m0 ^= (unsigned)f0;
    do { if (--fuel == 0u) goto done;
        goto L0;
        f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)c1 * (unsigned)((short)0xc0cd5f4bu > (signed char)0x41e41476u)) < (0x10000u << (0xffffffffu & 31u))) & 255u);
        g1 += (unsigned)((int)(unsigned)(unsigned char)(0x4e8bb2bcu >> (g1 & 31u)) < (int)(0u + (unsigned)(1u || 7u)));
        a0[(0xffffffffu - 0xf42034c3u) & 3u] = 6u;
    } while (i0++ < 4u && (unsigned)(*q0 < i1));
    if (budget != 0u) { budget -= 1u; u1 = fn0((0x80000000u >> (3u & 31u)), 0xffffffffu, *mp); }
    a0[(unsigned)c1 & 3u] = *mp;
    if (budget != 0u) { budget -= 1u; u0 = fn0((0x80000000u >> ((i1 >> ((unsigned)d0 & 31u)) & 31u)), (unsigned)d0, (unsigned)e0); }
    if (-(unsigned)((unsigned)c0 == (unsigned)!(g0 << (p0 & 31u)))) goto L1;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0(u0, (unsigned)((unsigned)f0 && -(8u & (unsigned)h1)), (unsigned)x0); }
        s1 = (int)((unsigned)s1 + ((unsigned)(x0 >> 70) & (unsigned)(signed char)(0x39352b9eu ? 0xffffffffu : 0x610af665u)));
        u1 += ~(-(unsigned)(0x8ec8f705u < ((unsigned)(x0 >> 70) >> (6u & 31u))) / (0xffffffffu | 1u));
    }
    if ((unsigned)(0xe182f447u && (unsigned)(short)((unsigned)e0 + *mp))) goto done;
    { unsigned t1; double z1; if ((0x80000000u) & 1u) { t1 = u0; z1 = (double)(((unsigned)f0) & 255u); } if ((0x80000000u) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)f0 & 0xc1bd46b0u), (0x10000u % (r0.y | 1u)), (unsigned)((short)((unsigned)(x0 >> 70) >> (0xd21eb0a9u & 31u)) > (signed char)(unsigned)b0)); }
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)s1 || 0x10000u) & 255u);
    }
    s0 = (int)(4u * (unsigned)(g0 == (unsigned)((unsigned)e0 < u1)));
    if (budget != 0u) { budget -= 1u; u1 = fn0(a0[i0 & 3u], p1, (0x4fa8d1ceu | (unsigned)((int)*q0 >= (int)*q0))); }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)0x80000000u > (signed char)i1), ((unsigned)(w0 >> 29) ^ (unsigned)f0), (unsigned)((int)0x80000000u >= (int)0u)); }
        { unsigned t2; double z2; if (((garr[u2 & 7u] + 0xffffffffu)) & 1u) { t2 = (unsigned)(8u == ((unsigned)h0 >> (u0 & 31u))); z2 = (double)(((unsigned)((int)(unsigned)c1 >= (int)p2)) & 255u); } if (((garr[u2 & 7u] + 0xffffffffu)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            b0 = ((0xe941c8d7u ? (unsigned)(g0 == garr[u2 & 7u]) : u0) / ((unsigned)l0 | 1u)) != 0u;
            if ((3u % ((0x1ad869b8u * 0x7fffffffu) | 1u))) break;
            if (fuel < 8u) return ((unsigned)e0 ^ (unsigned)((int)p1 < (int)0x9d3507acu));
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (garr[u2 & 7u]) break;
            }
            garr[(unsigned)c1 & 7u] = ((v0 % ((unsigned)(((unsigned)c1 << (u3 & 31u)) == (unsigned)h0) | 1u)) * (unsigned)h1);
        }
        if (6u) continue;
        do { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        u1 = ((u1 % (i0 | 1u)) & (0x80000000u ? (unsigned)e0 : (unsigned)d0));
                        garr[(unsigned)(short)(u0 * 0xffffffffu) & 7u] = (u3 << ((unsigned)w0 & 31u));
                    }
                    h1 = (unsigned short)(h1 + (unsigned)(~(~(p1 + (unsigned)(x0 >> 70)) << (u0 & 31u)) < (unsigned)f0));
                } while (i0++ < 6u && (unsigned)(u3 < (unsigned)f0));
                w0 = w0 * 6364136223846793005ull + 7u;
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    garr[(unsigned)((unsigned)c1 || (unsigned)h1) & 7u] = ((unsigned)(short)((unsigned)((unsigned)(x0 >> 70) < 0x87c80487u) ^ g1) >> ((4u % ((unsigned)(w0 >> 29) | 1u)) & 31u));
                    break; (void)((unsigned)((unsigned)d0 < (0x7fffffffu << (a0[u1 & 3u] & 31u))));
                }
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    m0 ^= (v0 + 0xb679311au);
                    if ((unsigned)(unsigned char)(garr[i1 & 7u] ? u0 : 1u)) break;
                    w0 ^= (unsigned long long)v0 << ((a0[i0 & 3u] + (i2 | r0.x)) & 63u);
                }
            }
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                g1 += (9u | ((unsigned)s0 + (unsigned)!(4u | ((unsigned)e0 | i0))));
                r0.x = ((unsigned)!((unsigned)h1 + r0.y) ? u3 : (0xffffffffu & 0x80000000u));
                u1 += (9u - (unsigned)(5u || i1));
                *q0 = (p2 & (0x80000000u % ((unsigned)b0 | 1u)));
                if (budget != 0u) { budget -= 1u; u0 = fn0(g1, 0x212b679fu, (0xffffffffu | (unsigned)f0)); }
            }
            if ((0x80000000u % (m0 | 1u))) break;
            if ((unsigned)((short)g0 > (signed char)~(garr[i1 & 7u] << (i0 & 31u)))) break;
        } while (i1++ < 4u && ((unsigned)(p0 < p2) + (unsigned)(x0 >> 70)));
    } while (i0++ < 2u && ((unsigned)e0 - m0));
    if (((unsigned)b0 & (unsigned)h0)) {
        v0 = 8u;
    }
    if (((unsigned)((int)0xcfac2a8du < (int)*mp) / (a0[i0 & 3u] | 1u))) goto L4;
    if (*mp) {
        s1 = (int)((unsigned)s1 + (unsigned)((int)r0.x < (int)(6u | 0x80000000u)));
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)((unsigned)x0 || (unsigned)(x0 >> 70)) ^ *mp)) {
                { unsigned t3; double z3; if ((0x10000u) & 1u) { t3 = (unsigned)(0xf21c5386u < (garr[u2 & 7u] + (unsigned)l0)); z3 = (double)(((unsigned)!(fuel - u2)) & 255u); } if ((0x10000u) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                    h0 = (short)(unsigned)(i1 < (g1 >> (g1 & 31u)));
                    continue; (void)((unsigned)((unsigned)(signed char)((unsigned)w0 >> (0x7fffffffu & 31u)) || (unsigned)c0));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)((unsigned)f0 < fuel) || v0), garr[u2 & 7u], (unsigned)(r0.y || 9u)); }
                    if (g0) goto L1;
                }
                { unsigned t4; double z4; if (((garr[i1 & 7u] % (0xfb42a84cu | 1u))) & 1u) { t4 = (0x10000u - i1); z4 = (double)((1u) & 255u); } if (((garr[i1 & 7u] % (0xfb42a84cu | 1u))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)x0, (0x10000u - (unsigned)h0), ((unsigned)l0 % ((unsigned)((short)*mp > (signed char)m0) | 1u))); }
                    if ((unsigned)((g1 | 0xffffffffu) < (unsigned)b0)) goto L1;
                    { unsigned t5; double z5; if ((0xffffffffu) & 1u) { t5 = (3u * (unsigned)s1); z5 = (double)(((unsigned)((unsigned)((int)(unsigned)s1 >= (int)r0.x) == (unsigned)l0)) & 255u); } if ((0xffffffffu) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                        w0 ^= (unsigned long long)(unsigned)((int)0xffffffffu >= (int)garr[i1 & 7u]) << ((unsigned)f0 & 63u);
                        { unsigned t6; double z6; if (((6u / (i2 | 1u))) & 1u) { t6 = fuel; z6 = (double)((*mp) & 255u); } if (((6u / (i2 | 1u))) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                            u2 = 0xffffffffu;
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(((unsigned)c0 | 7u) == *mp), ((unsigned)(x0 >> 70) / (3u | 1u)), a0[i0 & 3u]); }
                            *q0 = u3;
                            if (0x7f6116f5u) break;
                            f0 = f0 * 0.5f + (float)(((unsigned)(short)(3u & (unsigned)((int)i1 < (int)5u)) / ((4u + 0x943d15c4u) | 1u)) & 255u);
                        }
                        if ((u2 | (unsigned)c1)) continue;
                        b0 = *mp != 0u;
                        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                            s1 = (int)((unsigned)s1 + ((unsigned)s1 ? (unsigned)c0 : (u1 >> (0x93f35eceu & 31u))));
                            w0 = w0 * 6364136223846793005ull + (unsigned)(short)(unsigned)(fuel < garr[u2 & 7u]);
                            u3 = u3 * 0x9e3779b1u + (unsigned)((unsigned)((int)0x85bfc2a6u < (int)garr[u2 & 7u]) < (unsigned)d0);
                            r0.x = (unsigned)((short)(unsigned)((unsigned)((int)0x10000u >= (int)0xb41dc596u) && (unsigned)w0) > (signed char)m0);
                        }
                        if (((unsigned)l0 + (unsigned)x0)) break;
                    }
                }
            } else {
                if (budget != 0u) { budget -= 1u; u0 = fn0(garr[u2 & 7u], (unsigned)((short)0xa97fe3bu > (signed char)i1), (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)((unsigned)(x0 >> 70) < *mp))); }
                break; (void)((0x4c1867f7u >> ((r0.y & (unsigned)f0) & 31u)));
            }
        }
        { unsigned t7; double z7; if ((i2) & 1u) { t7 = (unsigned)(x0 >> 70); z7 = (double)(((r0.y % ((unsigned)(x0 >> 70) | 1u))) & 255u); } if ((i2) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)c1 ^ 2u), (0x10000u >> ((unsigned)b0 & 31u)), p1); }
            *mp = ((unsigned)l0 % ((unsigned)((int)(p0 ^ u3) >= (int)(unsigned)c1) | 1u));
            do { if (--fuel == 0u) goto done;
                v0 = (unsigned)((unsigned)(*q0 == (unsigned)((unsigned)(x0 >> 70) == 6u)) == (unsigned)h1);
                d0 = d0 * 0.5 + (double)((u2 / ((unsigned)e0 | 1u)) & 1023u);
                if ((0x18b97977u - (unsigned)e0)) goto L0;
                f0 = f0 * 0.5f + (float)((0x683ab0cfu ^ *q0) & 255u);
                switch (((unsigned)b0 ^ (3u / (*mp | 1u))) & 7u) {
                    *q0 += ((unsigned)((int)-(garr[i1 & 7u] + 8u) >= (int)g1) + (g1 * g1));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((9u - (unsigned)((int)(unsigned)h0 < (int)3u)), ((unsigned)(w0 >> 29) ^ (unsigned)(2u && i1)), ((unsigned)x0 ^ ((unsigned)c0 / (i0 | 1u)))); }
                    u1 = r0.y;
                }
                if (((unsigned)(4u == r0.y) & 0xf7279daeu)) break;
            } while (i0++ < 2u && (unsigned)(0x5cd52baau == g1));
            if ((unsigned)((unsigned)x0 == 0u)) {
                while (i0++ < 7u && (unsigned)!((unsigned)f0 & 3u)) { if (--fuel == 0u) goto done;
                    if (u1) break;
                    break; (void)((unsigned)(0x10000u < (unsigned)b0));
                    if (((0x3d4c0716u << (m0 & 31u)) ^ garr[i1 & 7u])) break;
                    garr[(unsigned)((unsigned)b0 || i2) & 7u] = (7u % ((unsigned)((int)((unsigned)x0 + (unsigned)(x0 >> 70)) >= (int)(unsigned)((short)0x7fffffffu > (signed char)8u)) | 1u));
                }
                u3 = (garr[i1 & 7u] / (((unsigned)(7u && 0x10000u) << (0x7fffffffu & 31u)) | 1u));
            } else {
                garr[((unsigned)e0 - 0x7fffffffu) & 7u] = ((unsigned)((unsigned)e0 < (unsigned)(short)(0xffffffffu % (u1 | 1u))) % (a0[i0 & 3u] | 1u));
                goto L4;
                if ((unsigned)((0x1bcbab33u | *q0) == (unsigned)c1)) goto L4;
            }
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((short)(7u * i1) > (signed char)0xb31dd54u) || ((unsigned)h1 << ((unsigned)h0 & 31u)));
        f0 = f0 * 0.5f + (float)((v0 / (((unsigned)(g0 < garr[u2 & 7u]) & (unsigned)h0) | 1u)) & 255u);
        switch (garr[u2 & 7u] & 7u) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)p0 < (int)(unsigned)((short)v0 > (signed char)0xffffffffu)), r0.x, (u0 << ((unsigned)(u2 == (unsigned)w0) & 31u))); }
            l0 = (long)((unsigned long)l0 + ~((garr[u2 & 7u] % (p2 | 1u)) & 0x95723544u));
            { unsigned t8; double z8; if (((unsigned)!((unsigned)s1 >> ((4u % (a0[u1 & 3u] | 1u)) & 31u))) & 1u) { t8 = i1; z8 = (double)(((i1 << (0x7ab567deu & 31u))) & 255u); } if (((unsigned)!((unsigned)s1 >> ((4u % (a0[u1 & 3u] | 1u)) & 31u))) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                if (p2) goto done;
                if ((unsigned)(0x16f48e2eu < (unsigned)(*q0 == r0.y))) {
                    r0.y ^= (unsigned)((int)0x10000u < (int)(unsigned)x0);
                } else {
                    s1 = (int)((unsigned)s1 + -(7u ? 0xffffffffu : (g1 << (0x80000000u & 31u))));
                    break; (void)((0x1aff591du - 0xffffffffu));
                    u0 += (4u - i2);
                    case 1u: ;
                }
                u1 += (((u1 & (unsigned)h1) / ((unsigned)(x0 >> 70) | 1u)) * (unsigned)d0);
                s1 = (int)((unsigned)s1 + (i0 ^ (unsigned)s0));
            }
        }
    } else {
        r0.y ^= ~(unsigned)((int)4u < (int)(unsigned)((int)1u < (int)fuel));
        h0 = (short)(g1 % (0xe922fff8u | 1u));
        goto L1;
    }
    v0 = (*q0 / (0u | 1u));
    if ((unsigned)((int)((unsigned)h0 >> (0xe978e0a8u & 31u)) >= (int)*mp)) {
        if (budget != 0u) { budget -= 1u; u0 = fn0(~(*mp ^ (unsigned)(p0 && (unsigned)c1)), (unsigned)(g0 || (unsigned)(1u || u0)), (u1 & (unsigned)(signed char)(unsigned)((int)i1 < (int)(unsigned)c1))); }
        if (budget != 0u) { budget -= 1u; u1 = fn0((p1 ? g0 : p1), (i1 >> (i0 & 31u)), ((unsigned)c0 - g0)); }
    }
    if ((unsigned)((short)((unsigned)s0 & r0.y) > (signed char)*mp)) goto L3;
    if ((unsigned)((garr[u2 & 7u] | u0) || 0x189e22ffu)) goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u0 = fn0((garr[i1 & 7u] % (u3 | 1u)), -(unsigned)((int)4u >= (int)(unsigned)s0), p2); }
    q0 = &garr[(unsigned)(((unsigned)(0xf3294ff0u == (unsigned)w0) & *q0) < r0.y) & 7u];
    for (;;) { if (--fuel == 0u) goto done;
        u2 += (i1 << ((i0 << ((i1 ? p0 : garr[i1 & 7u]) & 31u)) & 31u));
        if ((0x72d48e26u / ((unsigned)l0 | 1u))) break;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)s0) {
                continue; (void)((unsigned)(0x727573fu < garr[u2 & 7u]));
            } else {
                a0[(a0[i0 & 3u] / (r0.x | 1u)) & 3u] = (unsigned)(unsigned char)(unsigned)(p1 < ((0x10000u - 0x7fffffffu) & 1u));
                L0: if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)(w0 >> 29) & 1023u);
                v0 = (unsigned)b0;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)p2 > (signed char)(0xb28f68ceu << (a0[i0 & 3u] & 31u))), (u2 | (unsigned)h1), (0x93c842d7u ^ (unsigned)d0)); }
            if ((0x2dbd50f2u / ((unsigned)c1 | 1u))) break;
            m0 ^= (*mp - (unsigned)c0);
            if ((unsigned)((unsigned)s1 == (unsigned)h1)) {
                x0 = x0 * 0x100000001b3ull + (i1 ? (u2 ? *q0 : a0[u1 & 3u]) : (unsigned)d0);
                if ((unsigned)(short)(unsigned)((int)garr[i1 & 7u] < (int)garr[i1 & 7u])) goto L3;
            }
        }
        w0 ^= (unsigned long long)0x58ae883bu << ((unsigned)((short)0x7fffffffu > (signed char)(((unsigned)s1 % (*mp | 1u)) & (unsigned)((unsigned)l0 && a0[i0 & 3u]))) & 63u);
    }
    while (i0++ < 7u && (unsigned)l0) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1(((0xa948fbe6u | g1) | (unsigned)h1), (0xb22072d8u | g1), ~((unsigned)w0 >> (a0[i0 & 3u] & 31u))); }
        L1: if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((short)0x7fffffffu > (signed char)(unsigned)d0) < (a0[u1 & 3u] % ((unsigned)(x0 >> 70) | 1u))) & 255u);
        { unsigned t0; double z0; if ((*q0) & 1u) { t0 = (unsigned)s0; z0 = (double)(((unsigned)((unsigned)((unsigned)(w0 >> 29) && (unsigned)c1) && 0x9bc7ebc7u)) & 255u); } if ((*q0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            if ((unsigned)((int)0x93aaf641u >= (int)2u)) {
                if ((unsigned)(short)(r0.x % (9u | 1u))) {
                    do { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + ((0x80000000u / (i2 | 1u)) >> ((unsigned)(short)(unsigned)(0x929bce97u < 0xee0df8f7u) & 31u));
                    } while (i1++ < 6u && ((unsigned)s0 | i2));
                    u0 ^= (unsigned)h1;
                    a0[0x845acebeu & 3u] = ((unsigned)(p1 && r0.x) & garr[i1 & 7u]);
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)f0 ^ (unsigned)((unsigned)x0 && 0xc14f3807u)), 6u, (unsigned)(unsigned char)(6u << ((unsigned)h0 & 31u))); }
                    continue; (void)((unsigned)((short)m0 > (signed char)(0x2d90c75cu + fuel)));
                } else {
                    c0 = (unsigned char)((unsigned)(*q0 || fuel) | 1u);
                    s1 = (int)((unsigned)s1 + ((unsigned)!(unsigned)(g0 == 0x657c4d22u) + (unsigned)h0));
                    s1 = (int)((unsigned)s1 + ((unsigned)w0 % (((unsigned)s0 ^ (unsigned)(signed char)(6u / (0x7fffffffu | 1u))) | 1u)));
                    L2: if (--fuel == 0u) goto done;
                }
                u2 += ((m0 | (unsigned)l0) / ((unsigned)((unsigned)f0 || (unsigned)d0) | 1u));
            } else {
                L3: if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                m0 ^= -(a0[i0 & 3u] / ((u1 & (unsigned)((unsigned)d0 && ((unsigned)c1 >> (0x10000u & 31u)))) | 1u));
            }
            break; (void)((unsigned)(u3 && 0x455d1d15u));
            if (u2) {
                if ((p0 << (~(a0[i0 & 3u] * 0x1da5e52fu) & 31u))) goto L1;
            }
            for (;;) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    switch (*mp & 7u) {
                        c0 = (unsigned char)((r0.x ? 5u : p1) * garr[i1 & 7u]);
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(3u < (0xc801fbb3u & 0xd4f3200au)), (unsigned)((int)((unsigned)d0 - (unsigned)h0) < (int)(unsigned)f0), (unsigned)(signed char)(1u * garr[u2 & 7u])); }
                        d0 = d0 * 0.5 + (double)(~(garr[i1 & 7u] + (unsigned)((int)i0 >= (int)garr[u2 & 7u])) & 1023u);
                        case 7u: ;
                    }
                    i1 = ((unsigned)((unsigned)w0 < (unsigned)s1) ^ 0x4d56e533u) & 15u;
                    goto L0;
                    if ((unsigned)(0x2fdd057u && (fuel & i0))) break;
                }
            }
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(g1 >> ((6u / (a0[u1 & 3u] | 1u)) & 31u));
                break; (void)((unsigned)s0);
                u3 = u3 * 0x9e3779b1u + (unsigned)d0;
                if ((unsigned)h0) break;
            }
            switch ((unsigned)(unsigned char)(unsigned)((int)(unsigned)d0 >= (int)u0) & 7u) {
                goto L2;
                r0.x = (m0 & ((unsigned)s0 / ((i0 | (0x7fffffffu / (0x4cc0dfbu | 1u))) | 1u)));
                continue; (void)((unsigned)d0);
                *q0 = (m0 ^ (unsigned)!(0xa1fade2au - -(u2 * garr[u2 & 7u])));
                if (-(unsigned)((short)u3 > (signed char)(p2 ^ u1))) break;
                if ((0x80000000u >> ((unsigned)f0 & 31u))) {
                    u2 = (unsigned)(signed char)(unsigned)((0x7fffffffu >> ((unsigned)w0 & 31u)) == ((unsigned)(x0 >> 70) >> (u2 & 31u)));
                    case 2u: ;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((1u & (unsigned)((unsigned)f0 && 9u)), ((unsigned)((short)8u > (signed char)(unsigned)w0) >> (i1 & 31u)), (unsigned)(short)((unsigned)s1 + ~(0xef4ecb9au % (0xfd3bd15eu | 1u)))); }
                    break; (void)((unsigned)((p0 >> (a0[i0 & 3u] & 31u)) || 8u));
                    break; (void)(m0);
                    c0 = (unsigned char)((unsigned)x0 % ((unsigned)((unsigned)h0 == i2) | 1u));
                } else {
                    case 5u: ;
                    c0 = (unsigned char)(6u / ((unsigned)(x0 >> 70) | 1u));
                    default: ;
                    break;
                }
            }
        }
        r0.y ^= ((unsigned)c0 << (((unsigned)c0 ? *mp : (unsigned)l0) & 31u));
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (fuel) {
            u2 = u2 * 0x9e3779b1u + (unsigned)((int)(p0 ^ 0xe6c68d16u) >= (int)p2);
            garr[*q0 & 7u] = (garr[i1 & 7u] / (-(unsigned)((short)g0 > (signed char)((unsigned)l0 & 0x10000u)) | 1u));
            if (((unsigned)c1 % ((unsigned)(0x7fffffffu || (unsigned)h1) | 1u))) break;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(i2 || ((unsigned)s1 & (unsigned)s0)), (fuel << (4u & 31u)), (p2 << (i0 & 31u))); }
        } else {
            *mp = (unsigned)(((unsigned)(signed char)(p0 >> ((unsigned)d0 & 31u)) | 0xe93db16au) < (unsigned)(short)(garr[u2 & 7u] % ((unsigned)f0 | 1u)));
        }
        *q0 += (unsigned)((unsigned)s1 || (unsigned)((int)a0[u1 & 3u] < (int)i2));
    }
    if ((unsigned)(((unsigned)s1 + 0x6bd28227u) < (unsigned)f0)) goto L4;
    if ((0x45ef919u + u1)) goto done;
    switch ((unsigned)((u2 & garr[u2 & 7u]) || (unsigned)l0) & 7u) {
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            v0 = (unsigned)((fuel | (unsigned)(w0 >> 29)) == 9u);
            { unsigned t1; double z1; if (((unsigned)(g1 || (unsigned)e0)) & 1u) { t1 = (unsigned)l0; z1 = (double)(((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)(p2 || r0.x))) & 255u); } if (((unsigned)(g1 || (unsigned)e0)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                break; (void)((p1 >> (0x116e51u & 31u)));
            }
            { unsigned t2; double z2; if (((unsigned)((int)(unsigned)d0 >= (int)p1)) & 1u) { t2 = 5u; z2 = (double)((p1) & 255u); } if (((unsigned)((int)(unsigned)d0 >= (int)p1)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)h1 < (int)2u);
                garr[0x430c1a31u & 7u] = ((unsigned)(unsigned char)(0x10000u / (a0[u1 & 3u] | 1u)) & ((unsigned)s1 ^ 3u));
                r0.x = ((unsigned)(1u < (unsigned)x0) << (-((unsigned)s0 & i1) & 31u));
                h0 = (short)(unsigned)((unsigned)f0 == 0x61257c02u);
                u2 += (((~(v0 | r0.x) ^ u2) ^ 0x603a497bu) << ((unsigned)l0 & 31u));
                if ((unsigned)((g0 * (unsigned)h1) || i2)) {
                    case 5u: ;
                    d0 = d0 * 0.5 + (double)((unsigned)(signed char)(v0 << (0xec762fcdu & 31u)) & 1023u);
                    case 6u: ;
                }
            }
            switch (a0[i0 & 3u] & 7u) {
                u2 += 0x10000u;
                e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(((unsigned)((int)9u < (int)(unsigned)e0) % ((unsigned)e0 | 1u)) + r0.x) & 1023u);
                do { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(unsigned)((int)(unsigned)c1 >= (int)(unsigned)l0) << ((unsigned)s1 & 63u);
                    r0.y ^= (r0.y | garr[i1 & 7u]);
                } while (i1++ < 7u && (0x3db37038u & (unsigned)(0x7fffffffu < (unsigned)s0)));
                if ((unsigned)b0) {
                    continue; (void)((g1 - garr[i1 & 7u]));
                    u2 = u2 * 0x9e3779b1u + (unsigned)(signed char)(((unsigned)((unsigned)l0 < (unsigned)h0) - (unsigned)s0) << (((unsigned)(x0 >> 70) / ((unsigned)c0 | 1u)) & 31u));
                }
            }
        }
        while ((i0 | 0x7fffffffu)) { if (--fuel == 0u) goto done;
            switch ((unsigned)f0 & 7u) {
                case 7u: ;
                if (~(unsigned)((int)(unsigned)l0 >= (int)(unsigned)((unsigned)c1 || *q0))) goto L4;
            }
        }
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 4u: ;
            default: ;
            case 0u: ;
            do { if (--fuel == 0u) goto done;
                switch (p2 & 7u) {
                    i2 = (unsigned)l0 & 15u;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(r0.x + 0x7fffffffu) < (int)0xf0b5eddbu), (garr[u2 & 7u] / ((unsigned)b0 | 1u)), (garr[i1 & 7u] % (0x7fffffffu | 1u))); }
                    case 3u: ;
                    c1 = (signed char)(u2 ? (unsigned)h1 : (unsigned)((int)(unsigned)s0 < (int)0x80000000u));
                }
                break; (void)((~(unsigned)((short)0x80000000u > (signed char)(unsigned)l0) % (i0 | 1u)));
                u2 += (((g1 << (i0 & 31u)) & 7u) / ((unsigned)((unsigned)x0 < a0[i0 & 3u]) | 1u));
                break;
            } while (i1++ < 2u && (unsigned)((unsigned)!(u1 | (unsigned)s1) && *mp));
        }
        break; (void)(((unsigned)e0 - 4u));
        h0 = (short)(u2 / ((unsigned)(p2 && (0x10000u + m0)) | 1u));
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 = u0 * 0x9e3779b1u + (v0 + (unsigned)l0);
    }
    if ((unsigned)(short)(0x10000u << (4u & 31u))) {
        h1 = (unsigned short)(h1 + v0);
        switch ((unsigned)((int)(unsigned)c0 >= (int)0x80000000u) & 7u) {
            case 0u: ;
        }
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (*mp) break;
    }
    switch (((unsigned)h1 >> ((unsigned)e0 & 31u)) & 7u) {
        w0 = w0 * 6364136223846793005ull + 0x7fffffffu;
    }
    if ((unsigned)((int)0x80000000u < (int)1u)) {
        switch ((unsigned)((int)(4u << (0x80000000u & 31u)) < (int)0u) & 7u) {
            case 0u: ;
            u2 = (0xe1b9c8c5u - (((u0 % (0x7930cde2u | 1u)) | 0x80000000u) ^ (unsigned)c1));
            if (budget != 0u) { budget -= 1u; u1 = fn0((0x790a90eau | (unsigned)s0), (unsigned)(p2 && v0), 0x6a7322dcu); }
            if ((unsigned)c0) {
                s0 = (int)(unsigned)((int)0x7fffffffu < (int)(0x10000u + (*mp ^ m0)));
                u2 = (((unsigned)(unsigned char)(1u | 0xb3a81fcfu) - (0xffffffffu - g1)) - 0xbca22403u);
                while (i0++ < 7u && (unsigned)((unsigned)e0 || 0x70165b11u)) { if (--fuel == 0u) goto done;
                    if (((unsigned)(w0 >> 29) + p2)) goto L2;
                    c0 = (unsigned char)(unsigned)(0x80000000u < (p1 & i0));
                }
                *q0 += (unsigned)f0;
                garr[(v0 & p1) & 7u] = 0x4e89dbacu;
                do { if (--fuel == 0u) goto done;
                    for (;;) { if (--fuel == 0u) goto done;
                        if ((unsigned)(garr[u2 & 7u] == 3u)) {
                            break; (void)(p1);
                            *mp = fuel;
                            h1 = (unsigned short)(h1 + (unsigned)(signed char)(g0 >> ((a0[i0 & 3u] / (0x7fffffffu | 1u)) & 31u)));
                        } else {
                            case 7u: ;
                            m0 ^= (unsigned)((unsigned)((short)(unsigned)c1 > (signed char)0x85e18fa3u) && p2);
                            if (0xb6fd67c7u) continue;
                            *q0 += (unsigned)(u2 == (unsigned)w0);
                        }
                        x0 = x0 * 0x100000001b3ull + (unsigned)((int)((u2 + i2) * (unsigned)((int)p1 >= (int)r0.y)) >= (int)(unsigned)(w0 >> 29));
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)((int)7u < (int)garr[i1 & 7u]) < (unsigned)c0), m0, (unsigned)((unsigned)e0 && 0xfe15f70cu)); }
                    }
                    for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        r0.x = fuel;
                        l0 = (long)((unsigned long)l0 + ((0xffffffffu + i2) * 1u));
                    }
                    if (0x77d2e43du) {
                        if (fuel < 8u) return (unsigned)(unsigned char)(5u / ((p2 ? 0xa0e5ee52u : ((unsigned)h0 & u0)) | 1u));
                        if (((unsigned)b0 | 0xdfaa601cu)) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)(unsigned)(6u < (u3 / ((unsigned)(w0 >> 29) | 1u))), (unsigned)c1, (unsigned)((int)i0 >= (int)0xea4852b0u)); }
                        d0 = d0 * 0.5 + (double)(((a0[u1 & 3u] + a0[u1 & 3u]) / ((unsigned)((int)0x7fffffffu >= (int)3u) | 1u)) & 1023u);
                        b0 = *mp != 0u;
                        case 1u: ;
                    } else {
                        a0[m0 & 3u] = ~(unsigned)(0x6e981013u < (r0.y * (8u & 0x10000u)));
                    }
                    *q0 = (unsigned)(4u == (unsigned)((unsigned)(signed char)(p1 + i1) && i1));
                } while (i0++ < 3u && (unsigned)(0x80000000u && 0xa3edbf8au));
            }
            l0 = (long)((unsigned long)l0 + (p1 ^ (0xa07f6678u % ((unsigned)((unsigned)x0 == (unsigned)((int)1u >= (int)garr[i1 & 7u])) | 1u))));
            case 2u: ;
        }
    }
    u0 = u0 * 0x9e3779b1u + ((unsigned)s1 + (unsigned)(short)(((unsigned)c0 * 0x9f02a3f4u) - a0[u1 & 3u]));
    if (((u2 % ((unsigned)w0 | 1u)) + i1)) goto L2;
    { unsigned t3; double z3; if (((unsigned)((unsigned)(x0 >> 70) < u1)) & 1u) { t3 = a0[u1 & 3u]; z3 = (double)(((unsigned)e0) & 255u); } if (((unsigned)((unsigned)(x0 >> 70) < u1)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        goto L3;
        u0 ^= (unsigned)((int)*q0 >= (int)(unsigned)c0);
        do { if (--fuel == 0u) goto done;
            s0 = (int)((unsigned)d0 % ((g1 * (unsigned)e0) | 1u));
            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(1u == *mp) & 8u), (unsigned)((unsigned)h0 == i1), (unsigned)(a0[u1 & 3u] == (unsigned)e0)); }
            r0.x = (unsigned)(signed char)((unsigned)(garr[u2 & 7u] || i0) << (0x303b5a1eu & 31u));
            *q0 += ((unsigned)s0 - (unsigned)l0);
            if ((unsigned)e0) break;
            if (p0) break;
        } while (i0++ < 5u && v0);
        if (budget != 0u) { budget -= 1u; u1 = fn0((0xed5d0252u / ((unsigned)b0 | 1u)), 0xc2bb01bfu, (unsigned)((int)(unsigned)(0x10000u == g0) >= (int)a0[u1 & 3u])); }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)c0 & 1023u);
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)l0, (unsigned)(signed char)(unsigned)(((unsigned)d0 ^ p1) < 0xa18ea6d0u), (unsigned)(unsigned char)(u1 + (unsigned)e0)); }
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return -(unsigned)(6u < (p2 | i2));
                s0 = (int)(*mp / (0xc89904eeu | 1u));
                h0 = (short)((unsigned)s0 / ((unsigned)(u1 || a0[u1 & 3u]) | 1u));
                if (g0) goto L2;
            }
            goto done;
        }
        s0 = (int)(i2 | (garr[u2 & 7u] << ((((unsigned)l0 << ((unsigned)c1 & 31u)) ^ 2u) & 31u)));
    }
    if (u3 == 7u) return ((unsigned)((int)(unsigned)((int)m0 >= (int)0x80000000u) < (int)0xaef44198u) | (u1 << ((unsigned)(w0 >> 29) & 31u)));
    if (budget != 0u) { budget -= 1u; u2 = fn0(((m0 ^ 0x10000u) / ((unsigned)c0 | 1u)), u2, (unsigned)((short)u0 > (signed char)(unsigned)(short)(unsigned)(0x93070586u < u3))); }
    goto L2;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (unsigned)(0xfb0c73c6u < 5u);
        if ((unsigned)(signed char)(m0 << (0xda6e4acau & 31u))) break;
        goto L2;
        while (i1++ < 2u && (unsigned)(short)(unsigned)((int)((unsigned)f0 / (r0.y | 1u)) >= (int)(unsigned)h1)) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn1(u3, (v0 / (0x80000000u | 1u)), (0x5b488376u + (*mp ^ 0xcadc998du))); }
                { unsigned t4; double z4; if (((unsigned)(w0 >> 29)) & 1u) { t4 = ((unsigned)l0 ^ (g0 / (g0 | 1u))); z4 = (double)(((unsigned)(short)((unsigned)l0 >> ((unsigned)!(p2 ^ (unsigned)s0) & 31u))) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    u1 = (unsigned)(unsigned char)(((0xa873bb1du + r0.x) | (0xffffffffu | garr[u2 & 7u])) * 0x3af640c8u);
                    garr[(a0[u1 & 3u] << (p2 & 31u)) & 7u] = ((unsigned)((unsigned)s1 && ((unsigned)l0 / (m0 | 1u))) >> (0x7fffffffu & 31u));
                    i0 = 0x7fffffffu & 15u;
                    x0 = x0 * 0x100000001b3ull + ((0x7fffffffu ^ -(unsigned)(0x7fffffffu < 0x7fffffffu)) + 3u);
                }
                s1 = (int)((unsigned)s1 + (a0[i0 & 3u] - (unsigned)(u3 < g0)));
                g1 += p2;
            } while (i2++ < 3u && (unsigned)((int)p1 < (int)0x80000000u));
        }
    }
    if (m0) goto done;
    u3 = u3 * 0x9e3779b1u + (unsigned)h0;
    u0 += (m0 | (unsigned)((int)(unsigned)f0 < (int)(unsigned)(unsigned char)(unsigned)((int)(unsigned)h1 < (int)0x4499e520u)));
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (fuel) {
                f0 = f0 * 0.5f + (float)(-(unsigned)((int)((garr[i1 & 7u] + 0x7fffffffu) & garr[u2 & 7u]) < (int)(u1 + garr[u2 & 7u])) & 255u);
                s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(x0 >> 70) < u0));
            } else {
                goto L1;
                garr[0x80000000u & 7u] = ((unsigned)s0 >> ((unsigned)c0 & 31u));
            }
            g1 += (unsigned)e0;
            g1 += (unsigned)(unsigned char)(p1 - (unsigned)x0);
            q0 = &garr[-(unsigned)((unsigned)(u0 == (unsigned)f0) && u2) & 7u];
            break; (void)(r0.y);
        }
        if (u3) break;
        if ((unsigned)!(unsigned)((short)(unsigned)((int)(unsigned)w0 >= (int)g1) > (signed char)0u)) goto L3;
        continue; (void)(((unsigned)d0 / (*mp | 1u)));
    } while (i0++ < 2u && 0xf5a70c3eu);
    goto L0;
    if (garr[u2 & 7u]) goto L0;
    if ((unsigned)d0) {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(w0 >> 29) << (*q0 & 31u)), a0[i0 & 3u], (0u ^ v0)); }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((int)garr[i1 & 7u] < (int)i1)) {
                    if (((u3 | (unsigned)d0) ^ p2)) goto L0;
                }
                { unsigned t5; double z5; if ((v0) & 1u) { t5 = (unsigned)((short)(unsigned)h0 > (signed char)(unsigned)(i0 < a0[u1 & 3u])); z5 = (double)(((unsigned)b0) & 255u); } if ((v0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    if (i0) goto done;
                    if ((unsigned)(unsigned char)(((unsigned)f0 | fuel) & (unsigned)w0)) break;
                }
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (6u) {
                        if ((unsigned)(unsigned char)(9u % ((unsigned)h0 | 1u))) break;
                        w0 = w0 * 6364136223846793005ull + (unsigned)(short)(unsigned)((short)(unsigned)(short)(g1 ^ (unsigned)((int)(0x653977d3u >> (8u & 31u)) < (int)(unsigned)d0)) > (signed char)r0.x);
                        break; (void)((u3 / ((unsigned)x0 | 1u)));
                        s1 = (int)((unsigned)s1 + (unsigned)((int)((unsigned)f0 << (r0.y & 31u)) >= (int)(9u & u1)));
                    }
                    break; (void)(0xc93e5987u);
                    if (u3 == 7u) return (m0 & ((unsigned)(w0 >> 29) ? -(3u | u0) : p0));
                }
                break; (void)((unsigned)(r0.y && (unsigned)(unsigned char)(0x3dddfe8u * (unsigned)f0)));
                g1 += ((unsigned)s0 | r0.x);
                if ((unsigned)(short)(unsigned)(((unsigned)w0 % (v0 | 1u)) || (unsigned)c1)) break;
            } while (i1++ < 3u && (unsigned)((unsigned)s0 || 0xd876176au));
        }
        if ((6u & (p0 - garr[u2 & 7u]))) goto L2;
        u1 = u1 * 0x9e3779b1u + ((unsigned)d0 << ((unsigned)((int)i0 < (int)9u) & 31u));
    }
    while (i0++ < 5u && (unsigned)e0) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)(0x1fca9bau & 1023u);
        u0 += ((unsigned)((short)(unsigned)!((unsigned)e0 % ((unsigned)l0 | 1u)) > (signed char)u0) >> (((unsigned)e0 ^ *q0) & 31u));
        if (*mp) break;
        if (*q0) {
            if (budget != 0u) { budget -= 1u; u1 = fn0(garr[u2 & 7u], (garr[u2 & 7u] & m0), ((unsigned)f0 * (i0 % (fuel | 1u)))); }
            w0 = w0 * 6364136223846793005ull + ((unsigned)w0 * (unsigned)s0);
        }
        a0[(unsigned)(signed char)(0u % ((unsigned)c1 | 1u)) & 3u] = (unsigned)(signed char)((unsigned)((unsigned)b0 < 0x80000000u) >> ((unsigned)((int)i2 < (int)-(u3 + g1)) & 31u));
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)((short)r0.x > (signed char)3u);
    for (;;) { if (--fuel == 0u) goto done;
        switch ((0u >> (p2 & 31u)) & 7u) {
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)e0 & 7u];
            }
            b0 = ~(0x80000000u << (u2 & 31u)) != 0u;
            h0 = (short)(0x10000u ^ p2);
        }
        switch (((unsigned)((unsigned)x0 && 7u) - (unsigned)w0) & 7u) {
            case 1u: ;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)e0, (unsigned)(signed char)(unsigned)(a0[i0 & 3u] && (unsigned)(w0 >> 29)), (0x7b487d23u >> (((unsigned)x0 % (0x80000000u | 1u)) & 31u))); }
        }
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)s1 < a0[i0 & 3u])) {
                l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)(x0 >> 70) - 0x7fffffffu) && ((m0 << ((unsigned)x0 & 31u)) >> (m0 & 31u))));
                i2 = (unsigned)h1 & 15u;
                break; (void)(((unsigned)((int)p0 >= (int)0xc290c626u) & 2u));
                if (r0.y) continue;
            }
            if (~(0x7fffffffu + m0)) break;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0(garr[i1 & 7u], (unsigned)((short)(m0 / ((unsigned)w0 | 1u)) > (signed char)0xffffffffu), -(0x37d4e248u << (i0 & 31u))); }
                while (i0++ < 6u && (unsigned)((short)0xffffffffu > (signed char)(unsigned)((int)0x80000000u >= (int)p2))) { if (--fuel == 0u) goto done;
                    h0 = (short)u0;
                }
                break; (void)((0x80000000u & (unsigned)(w0 >> 29)));
                if (budget != 0u) { budget -= 1u; u0 = fn0((((unsigned)x0 * (unsigned)l0) % (u2 | 1u)), (unsigned)!(unsigned)(u0 || (unsigned)(garr[u2 & 7u] && 0x975293d1u)), (p1 & (unsigned)h0)); }
            }
            a0[r0.x & 3u] = (unsigned)(0xffffffffu < (unsigned)((unsigned)(signed char)(0x7fffffffu - (unsigned)x0) == *q0));
            g1 += (((0x10000u | u1) >> ((*q0 >> (0u & 31u)) & 31u)) ^ 0x4ebbb12au);
            r0.x = (0xc0736d67u >> ((i1 ? 0x10000u : (unsigned)((int)0xc1f927a3u < (int)i2)) & 31u));
        }
        if ((u2 - r0.y)) goto L3;
        if ((unsigned)(signed char)(unsigned)((u3 + p2) || 0x3de77e60u)) break;
        while (i1++ < 2u && -(u2 ? *mp : u1)) { if (--fuel == 0u) goto done;
            if ((u1 * (g1 - p1))) break;
            if (g0) {
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (((4u << (p2 & 31u)) ^ (unsigned)w0)) goto L4;
                }
                if (0x7891be0eu) break;
                a0[(0x47f0b8fu ^ m0) & 3u] = (unsigned)!(unsigned)((short)(0x7317eab6u | (unsigned)x0) > (signed char)(unsigned)((unsigned)(i2 || 6u) || p2));
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)f0, (unsigned)(w0 >> 29), (unsigned)(i1 || 0x80000000u)); }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(x0 >> 70), 1u, (unsigned)(0x10000u && i2)); }
        }
    }
    m0 ^= (unsigned)(short)(0xffffffffu | g0);
    { unsigned t6; double z6; if (((unsigned)c0) & 1u) { t6 = (unsigned)((int)4u < (int)(unsigned)c1); z6 = (double)(((0xe43b6dd7u ^ 0xf98cd1c2u)) & 255u); } if (((unsigned)c0) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        r0.x = (unsigned)!((unsigned)((short)u1 > (signed char)v0) - i0);
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)(signed char)(0x4fa5ad2u >> ((unsigned)s1 & 31u)) || (unsigned)b0), g1, (unsigned)(7u < (unsigned)d0)); }
        if ((*q0 ^ ((unsigned)(x0 >> 70) / ((unsigned)(x0 >> 70) | 1u)))) goto L3;
        b0 = ((unsigned)((int)(unsigned)c1 >= (int)0xa4b7e8f7u) % (5u | 1u)) != 0u;
        if ((u3 >> (0x435b5385u & 31u))) {
            c0 = (unsigned char)(a0[u1 & 3u] << ((unsigned)(0xc5a2b121u && 0x80000000u) & 31u));
        } else {
            w0 ^= (unsigned long long)(unsigned)w0 << (((unsigned)!(unsigned)((short)i0 > (signed char)0x7fffffffu) ^ (u2 - 4u)) & 63u);
            c0 = (unsigned char)p2;
            i0 = (unsigned)(0x25a8ef15u && 0x1521e915u) & 15u;
            if ((unsigned)((int)(0x4cea2339u | a0[u1 & 3u]) >= (int)u0)) goto done;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)!(unsigned)(a0[u1 & 3u] == (unsigned)!(unsigned)((int)5u >= (int)*q0)), (unsigned)(signed char)((unsigned)w0 ^ g0), (unsigned)((short)5u > (signed char)u1)); }
    }
    w0 ^= (unsigned long long)8u << ((0xffffffffu % ((unsigned)((int)(unsigned)((unsigned)!(unsigned)((int)(unsigned)h0 < (int)*q0) == 8u) < (int)(unsigned)f0) | 1u)) & 63u);
    if ((unsigned)e0) {
        if ((unsigned)(short)(((unsigned)l0 * 0x6b5d11c3u) << (0x51d236c0u & 31u))) {
            goto L1;
            h0 = (short)(unsigned)(short)(m0 % ((u0 << ((unsigned)((short)(unsigned)c0 > (signed char)0xaa61eeddu) & 31u)) | 1u));
            { unsigned t7; double z7; if ((((unsigned)((int)p2 >= (int)*mp) & p1)) & 1u) { t7 = ((unsigned)w0 ^ (unsigned)h1); z7 = (double)((((unsigned)x0 << (garr[u2 & 7u] & 31u))) & 255u); } if ((((unsigned)((int)p2 >= (int)*mp) & p1)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                f0 = f0 * 0.5f + (float)(garr[u2 & 7u] & 255u);
                goto L2;
            }
            s1 = (int)((unsigned)s1 + 9u);
        }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((r0.y << ((r0.y ^ r0.y) & 31u)), (unsigned)((short)0x7fffffffu > (signed char)(unsigned)h0), (unsigned)((int)*q0 >= (int)(unsigned)(w0 >> 29))); }
            q0 = &garr[((unsigned)!((unsigned)((unsigned)h0 || 0x518c79e9u) + 0x10000u) & (0x7fffffffu | 0x621fe34bu)) & 7u];
            s1 = (int)((unsigned)s1 + ((0x7fffffffu ? *mp : u2) & a0[u1 & 3u]));
        }
        if ((((unsigned)c1 - u2) / (5u | 1u))) goto done;
        if ((v0 / (*mp | 1u))) goto L0;
        if ((unsigned)(7u == (unsigned)!(garr[u2 & 7u] << ((unsigned)l0 & 31u)))) goto L4;
    } else {
        while (i0++ < 7u && g1) { if (--fuel == 0u) goto done;
            if ((unsigned)(m0 || (unsigned)((int)(unsigned)s0 >= (int)v0))) break;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(short)((unsigned)(0x80000000u || 0x10000u) - garr[u2 & 7u]), (unsigned)(p0 < u3), (unsigned)((short)garr[i1 & 7u] > (signed char)((unsigned)w0 * p2))); }
            h1 = (unsigned short)(h1 + ((unsigned)s0 & (unsigned)(x0 >> 70)));
            v0 = -(unsigned)(6u || r0.y);
            break; (void)(g1);
            w0 = w0 * 6364136223846793005ull + (unsigned)(i1 || (unsigned)((int)(r0.x - ((unsigned)b0 ^ r0.x)) >= (int)fuel));
        }
    }
    if ((unsigned)s0) goto L0;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0((garr[u2 & 7u] << (0x80000000u & 31u)), *q0, (unsigned)(((unsigned)b0 * r0.y) || 0x602d3a17u)); }
        if (u3 == 7u) return ((unsigned)((int)((unsigned)l0 ? 0x7fffffffu : p0) < (int)garr[i1 & 7u]) % (i1 | 1u));
        if ((unsigned)w0) continue;
    }
    c0 = (unsigned char)(0x206a9562u << (((unsigned)e0 | (unsigned)b0) & 31u));
    if (budget != 0u) { budget -= 1u; u1 = fn0(0x2777c3f8u, ((v0 ^ (unsigned)w0) >> (r0.y & 31u)), i1); }
    if (((unsigned)(m0 == 0x10000u) & 4u)) {
        if ((unsigned)x0) {
            if ((0xe758ed4fu | (unsigned)s0)) {
                r0.y ^= ((unsigned)e0 << (p1 & 31u));
                s0 = (int)(unsigned)!((fuel % (a0[i0 & 3u] | 1u)) & (unsigned)(0x9f22a146u == (unsigned)l0));
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + g1);
                }
                while (i0++ < 4u && (unsigned)(g1 == 0x67652d20u)) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)0x7fffffffu << (-(6u - 0x7fffffffu) & 63u);
                    if (budget != 0u) { budget -= 1u; u3 = fn1(((m0 ^ *q0) ^ (unsigned)x0), (unsigned)((short)u0 > (signed char)(v0 - 6u)), (unsigned)s1); }
                    *q0 += 5u;
                }
                if ((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)s1)) goto L4;
            }
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(signed char)(unsigned)((int)(unsigned)(a0[u1 & 3u] == 0x3ea60af9u) < (int)garr[u2 & 7u])) break;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)h1 & 1023u);
                    q0 = &garr[(7u >> (p2 & 31u)) & 7u];
                    v0 = (((unsigned)(5u || 0x470a9015u) % (0x37c2335au | 1u)) << (i0 & 31u));
                    if ((unsigned)f0) break;
                }
                if ((0x1b68cb14u >> ((unsigned)(x0 >> 70) & 31u))) break;
            }
            w0 ^= (unsigned long long)((unsigned)c0 >> ((unsigned)h1 & 31u)) << ((unsigned)(0xec6e7ab8u < (unsigned)((unsigned)c0 && (unsigned)((int)i1 >= (int)*q0))) & 63u);
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)p1 >= (int)(unsigned)(short)((unsigned)w0 >> (fuel & 31u))), ((unsigned)b0 ^ 0x646d124cu), i1); }
            do { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((*mp << ((*q0 ^ u0) & 31u)) & 255u);
                if ((unsigned)((int)r0.y < (int)(garr[i1 & 7u] * 0x6b9f7eb5u))) break;
                { unsigned t8; double z8; if (((unsigned)(-(u0 >> (0x80000000u & 31u)) < a0[u1 & 3u])) & 1u) { t8 = (0x84c893a8u & i0); z8 = (double)((((unsigned)c1 << (((unsigned)c0 + (unsigned)s1) & 31u))) & 255u); } if (((unsigned)(-(u0 >> (0x80000000u & 31u)) < a0[u1 & 3u])) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                    break; (void)((unsigned)(fuel == (unsigned)(8u < a0[i0 & 3u])));
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn1(2u, (unsigned)((short)fuel > (signed char)(unsigned)(0xdb9f85d6u || 0xd89de6ebu)), (unsigned)((int)(unsigned)(w0 >> 29) >= (int)0x8d36f698u)); }
                    }
                }
                w0 ^= (unsigned long long)(p1 % (*q0 | 1u)) << (((unsigned)(short)(unsigned)((unsigned)(v0 || a0[u1 & 3u]) == (unsigned)b0) ^ 0x10000u) & 63u);
                { unsigned t9; double z9; if ((0x80000000u) & 1u) { t9 = (unsigned)((int)(0xffffffffu ^ i2) >= (int)0u); z9 = (double)(((unsigned)((short)i0 > (signed char)6u)) & 255u); } if ((0x80000000u) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                    if (garr[u2 & 7u]) break;
                    u2 += (unsigned)((int)v0 < (int)(unsigned)h0);
                    if ((unsigned)c1) break;
                }
                u3 ^= ((unsigned)((int)(unsigned)f0 >= (int)(unsigned)c0) ^ (unsigned)h0);
            } while (i0++ < 5u && (unsigned)(short)((unsigned)s1 / ((p0 - garr[i1 & 7u]) | 1u)));
        }
        if ((3u + (unsigned)c1)) goto L3;
        garr[5u & 7u] = (unsigned)((unsigned)h1 || u0);
    }
    do { if (--fuel == 0u) goto done;
        if (((unsigned)x0 | (unsigned)((int)0x7cc3b974u >= (int)g0))) {
            x0 = x0 * 0x100000001b3ull + (i0 << ((0xffffffffu * (unsigned)x0) & 31u));
            *q0 += (unsigned)((int)r0.y >= (int)(unsigned)(w0 >> 29));
            switch (0x6d6fdee7u & 7u) {
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)~(unsigned)(g0 || 0x2fb933bcu);
                    case 0u: ;
                    break; (void)((unsigned)(((unsigned)b0 - u3) || 0x7fffffffu));
                    s1 = (int)((unsigned)s1 + u3);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((i0 & i1) - u0), -(((unsigned)x0 + r0.y) + 0xffffffffu), ((unsigned)f0 ? 0xaf7d4dedu : 6u)); }
                }
            }
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)w0 % ((unsigned)b0 | 1u))) break;
                s1 = (int)((unsigned)s1 + (garr[i1 & 7u] * (u1 >> (garr[u2 & 7u] & 31u))));
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)c0 ^ 8u)) goto L3;
                    { unsigned t10; double z10; if (((unsigned)((unsigned)e0 && (i2 | g1))) & 1u) { t10 = u3; z10 = (double)((1u) & 255u); } if (((unsigned)((unsigned)e0 && (i2 | g1))) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                        if (((unsigned)x0 % (*mp | 1u))) goto L0;
                        m0 ^= (unsigned)((unsigned)((int)5u < (int)0x7fffffffu) && (unsigned)(w0 >> 29));
                        if (u3 == 7u) return (~(unsigned)(u3 || v0) & (unsigned)c1);
                    }
                    if ((unsigned)(unsigned char)(0x10000u - i0)) break;
                    if (((unsigned)s1 | (unsigned)h1)) break;
                    if (fuel < 8u) return (((unsigned)s1 + garr[u2 & 7u]) * (unsigned)w0);
                    x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)h0 || (unsigned)(x0 >> 70));
                }
                if ((((unsigned)h1 ^ (unsigned)c1) & (unsigned)l0)) break;
            }
        }
        if ((0x7b5b8253u ? (unsigned)(x0 >> 70) : r0.y)) break;
    } while (i0++ < 3u && (unsigned)(((unsigned)c1 * (unsigned)(x0 >> 70)) && 1u));
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (((unsigned)d0 % (garr[i1 & 7u] | 1u)) ^ 3u);
        do { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)(7u && 7u));
            v0 = (*mp ? 0x7fffffffu : (unsigned)e0);
            s1 = (int)((unsigned)s1 + -(unsigned)(*mp && (0x7fffffffu - (u2 * (unsigned)h0))));
            q0 = &garr[r0.y & 7u];
        } while (i1++ < 5u && fuel);
        r0.x = (v0 & (((unsigned)(0xffffffffu < u2) >> (u1 & 31u)) << (0x7fffffffu & 31u)));
    }
    for (;;) { if (--fuel == 0u) goto done;
        i0 = (unsigned)((i2 ^ *mp) < (unsigned)w0) & 15u;
        if (((unsigned)e0 + (i0 & 0u))) break;
        c1 = (signed char)(unsigned)(unsigned char)((unsigned)d0 ^ (i2 - 0x29a321cfu));
        switch ((unsigned)(*mp || (unsigned)h0) & 7u) {
            while (i1++ < 6u && ((4u >> (0x80000000u & 31u)) & v0)) { if (--fuel == 0u) goto done;
                if ((fuel & (unsigned)(short)(8u << ((unsigned)d0 & 31u)))) {
                    v0 = (a0[i0 & 3u] >> ((unsigned)!(m0 & i1) & 31u));
                    s1 = (int)((unsigned)s1 + (unsigned)((int)-((unsigned)f0 * g0) >= (int)a0[u1 & 3u]));
                } else {
                    case 4u: ;
                }
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    case 1u: ;
                    case 0u: ;
                }
                v0 = 0x74392183u;
                g0 = (0x97f4d258u ^ 0xffffffffu);
            }
            default: ;
            i1 = ((unsigned)((i0 & fuel) == (unsigned)f0) | (a0[u1 & 3u] / (0x9f053e96u | 1u))) & 15u;
            h0 = (short)(unsigned)((unsigned)((int)p2 < (int)((unsigned)l0 ^ 0xef324829u)) == (unsigned)(p2 && (unsigned)c1));
        }
        continue; (void)(2u);
        switch ((unsigned)(0xffffffffu || 0x7fffffffu) & 7u) {
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)f0);
                    case 7u: ;
                    s0 = (int)(unsigned)((unsigned)(*mp == (unsigned)((int)i0 >= (int)(unsigned)(w0 >> 29))) && 0x80000000u);
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)(0xdc685703u || u0) || m0), (unsigned)((unsigned)l0 == g1), (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)s0)); }
                    c1 = (signed char)(((unsigned)!(g0 | 0xc20b7023u) >> (0x7fffffffu & 31u)) << (4u & 31u));
                    e0 = e0 * 0.5L + (long double)(((v0 ^ garr[u2 & 7u]) + r0.y) & 1023u);
                } while (i2++ < 7u && (unsigned)(x0 >> 70));
                s1 = (int)((unsigned)s1 + (unsigned)((short)0x360536d4u > (signed char)((unsigned)e0 << (0x7f52367eu & 31u))));
                *mp = (unsigned)((unsigned)b0 || 0xff394bf5u);
                v0 = ((unsigned)(unsigned char)(fuel - a0[i0 & 3u]) | ((unsigned)e0 % ((unsigned)s1 | 1u)));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(unsigned char)((unsigned)e0 / ((0x2f82423au / ((unsigned)c0 | 1u)) | 1u)), (unsigned)l0, ((unsigned)(garr[i1 & 7u] || 0x359ad31du) ^ p1)); }
                switch (((unsigned)l0 * 0x80000000u) & 7u) {
                    s1 = (int)((unsigned)s1 + (unsigned)(x0 >> 70));
                    case 1u: ;
                    u1 ^= (0x586d8f59u << ((((unsigned)d0 ? 5u : 0x10000u) / (*q0 | 1u)) & 31u));
                    goto L2;
                }
            }
            if ((unsigned)((short)0x7fffffffu > (signed char)0xffffffffu)) continue;
            w0 ^= (unsigned long long)*mp << (((unsigned)((int)(unsigned)w0 >= (int)g0) | (unsigned)((2u % (u1 | 1u)) == (unsigned)s1)) & 63u);
        }
    }
    goto L3;
    if (~(unsigned)((int)8u < (int)garr[i1 & 7u])) {
        e0 = e0 * 0.5L + (long double)((unsigned)((int)(a0[i0 & 3u] ? p2 : a0[u1 & 3u]) >= (int)(unsigned)(i2 || u1)) & 1023u);
        h0 = (short)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0xffffffffu);
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)((unsigned)c0 ? u3 : i2)) goto L0;
            if ((g1 * ((unsigned)w0 << (p0 & 31u)))) goto L4;
            while (i1++ < 7u && (v0 >> (((unsigned)d0 * u0) & 31u))) { if (--fuel == 0u) goto done;
                if (0x3776828u) continue;
            }
            if ((unsigned)((short)0xffffffffu > (signed char)u0)) break;
            c1 = (signed char)(unsigned)c0;
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 = i1;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(0x80000000u && (unsigned)(unsigned char)(v0 & (unsigned)x0)), ((unsigned)(x0 >> 70) << ((*q0 >> (0x80000000u & 31u)) & 31u)), (unsigned)((unsigned)(i2 && r0.y) < p2)); }
            if (g1) {
                g0 = ((0xfa466eb8u ? ((unsigned)b0 - p0) : 5u) * (unsigned)s0);
                s0 = (int)((0x10000u / (0x92e72b71u | 1u)) & (garr[u2 & 7u] ^ (unsigned)(unsigned char)(unsigned)(*q0 || 0x431bb5bfu)));
                if (budget != 0u) { budget -= 1u; u3 = fn1(9u, (0x5f4b4614u | (unsigned)h0), (0x10000u + ((unsigned)s0 / ((unsigned)s1 | 1u)))); }
                x0 = x0 * 0x100000001b3ull + ((g0 - (unsigned)(0x80000000u == 0x5d1d1ee8u)) >> (u2 & 31u));
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)(u3 < r0.y);
                    if ((u1 - 2u)) break;
                }
            } else {
                do { if (--fuel == 0u) goto done;
                    g1 += ((unsigned)f0 << (i0 & 31u));
                    g0 = garr[u2 & 7u];
                    w0 = w0 * 6364136223846793005ull + (a0[i0 & 3u] & (unsigned)h0);
                    u3 = u3 * 0x9e3779b1u + (i2 * (u1 / ((unsigned)c0 | 1u)));
                } while (i1++ < 2u && r0.y);
            }
        }
    }
    if ((unsigned)(signed char)((g1 >> (g0 & 31u)) | 0x79e4e5d4u)) goto L4;
    c0 = (unsigned char)i2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(p2 < (unsigned)d0)) {
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)x0 || (unsigned)(unsigned char)(m0 + (unsigned)c0)));
        if ((8u << ((unsigned)e0 & 31u))) {
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(*mp == (unsigned)(x0 >> 70)), (unsigned)(unsigned char)((unsigned)s0 / (v0 | 1u)), (unsigned)((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(x0 >> 70)) == p1)); }
            if (budget != 0u) { budget -= 1u; u1 = fn2(0xffffffffu, 0x7fffffffu, ((garr[i1 & 7u] & m0) - *mp)); }
            goto L0;
            u2 += ~(unsigned)(r0.x && (fuel / (i1 | 1u)));
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((9u * 9u), *mp, (unsigned)(x0 >> 70)); }
                d0 = d0 * 0.5 + (double)(((((unsigned)h0 / ((unsigned)s1 | 1u)) << (*q0 & 31u)) / (*q0 | 1u)) & 1023u);
                h1 = (unsigned short)(h1 + (unsigned)(i1 && -((unsigned)l0 >> (*mp & 31u))));
            }
        } else {
            s0 = (int)(unsigned)((short)(unsigned)(short)(0x8aa7371au & 0xffffffffu) > (signed char)(unsigned)((int)(unsigned)b0 < (int)0xa6e0b3f3u));
        }
        if ((unsigned)s0) {
            r0.x = (i2 * (p0 ? ((unsigned)s0 / ((unsigned)s1 | 1u)) : garr[u2 & 7u]));
        } else {
            m0 ^= (unsigned)(short)((0xdd9cc728u >> (a0[i0 & 3u] & 31u)) << (0x80000000u & 31u));
            m0 ^= garr[i1 & 7u];
        }
        s0 = (int)(((unsigned)((short)p0 > (signed char)i0) + 5u) >> (i0 & 31u));
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(x0 >> 70), (unsigned)h1, (unsigned)(fuel < p1)); }
        g1 += (unsigned)(signed char)((unsigned)!(garr[i1 & 7u] ^ u1) & (unsigned)(unsigned char)(1u + (unsigned)(u0 < i1)));
    } else {
        goto done;
        c0 = (unsigned char)(g1 >> ((unsigned)(short)(-(7u | r0.y) - 0x19d5e405u) & 31u));
        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)((short)(unsigned)e0 > (signed char)r0.x) << (0xfa962eaeu & 31u)), (unsigned)(u1 && (unsigned)h1), (unsigned)!(unsigned)((short)((unsigned)h1 * a0[i0 & 3u]) > (signed char)g1)); }
    }
    if ((r0.x + r0.x)) goto done;
    if ((unsigned)((unsigned)s1 < *q0)) {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((*mp % ((unsigned)((int)(unsigned)h1 >= (int)u3) | 1u))) break;
            if ((unsigned)((short)garr[i1 & 7u] > (signed char)u3)) {
                garr[0x10000u & 7u] = ((unsigned)h0 << ((garr[u2 & 7u] << (i0 & 31u)) & 31u));
                if (garr[u2 & 7u]) goto L4;
                r0.x = (u2 - (u3 - (((unsigned)(x0 >> 70) - (unsigned)w0) - i0)));
                switch (~(p1 / (g0 | 1u)) & 7u) {
                    break; (void)(((0xffffffffu ^ v0) & (unsigned)c0));
                    if ((unsigned)s0) {
                        w0 ^= (unsigned long long)(unsigned)e0 << ((unsigned)((unsigned)l0 < p2) & 63u);
                        v0 = (unsigned)(v0 && (i2 | 0x10000u));
                        d0 = d0 * 0.5 + (double)(0xc56591du & 1023u);
                        c0 = (unsigned char)(((unsigned)s1 % (0x3b7fbc53u | 1u)) / ((unsigned)s1 | 1u));
                        case 4u: ;
                        while (i1++ < 3u && (unsigned)((int)(4u & (unsigned)(w0 >> 29)) >= (int)(unsigned)l0)) { if (--fuel == 0u) goto done;
                            w0 = w0 * 6364136223846793005ull + (g0 + v0);
                            r0.x = (garr[u2 & 7u] & (unsigned)((int)u0 < (int)((unsigned)(unsigned char)(r0.y + *q0) / (a0[u1 & 3u] | 1u))));
                            if ((unsigned)((int)0x327931e3u >= (int)(unsigned)((int)(unsigned)c0 >= (int)0x2beb27f1u))) goto L1;
                            c1 = (signed char)(unsigned)(unsigned char)(p0 >> (i2 & 31u));
                            if (8u) break;
                        }
                    } else {
                        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)(garr[i1 & 7u] ^ 0x3dc8eeabu) > (signed char)i2), (unsigned)(1u && 9u), (unsigned)(u0 || 0x4ef404deu)); }
                    }
                    u0 = u0 * 0x9e3779b1u + (r0.y << (a0[i0 & 3u] & 31u));
                    do { if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)(0x282ff6f9u & 1023u);
                        c0 = (unsigned char)(5u + -((unsigned)c0 / ((unsigned)h1 | 1u)));
                        if ((p2 & 0x436b875fu)) continue;
                        case 2u: ;
                    } while (i1++ < 5u && (unsigned)(((unsigned)w0 >> (0x50b6fcdfu & 31u)) == garr[u2 & 7u]));
                }
                if ((u2 % (0xd59e6b16u | 1u))) continue;
                v0 = ((6u << ((unsigned)x0 & 31u)) ^ (unsigned)((unsigned)h0 < g0));
            } else {
                break; (void)(((unsigned)s0 % ((unsigned)s0 | 1u)));
                if ((unsigned)((m0 % (p1 | 1u)) || 0x80000000u)) break;
                c0 = (unsigned char)(unsigned)((short)1u > (signed char)(unsigned)c0);
                m0 ^= (unsigned)(unsigned char)(unsigned)((int)(0x10000u + *q0) >= (int)(0xeb1ed6e6u << (0x10000u & 31u)));
            }
            if ((r0.x / (garr[i1 & 7u] | 1u))) {
                garr[r0.y & 7u] = (unsigned)((short)(unsigned)s1 > (signed char)(4u + r0.y));
                { unsigned t0; double z0; if (((unsigned)((m0 + r0.x) < 0xa76985d0u)) & 1u) { t0 = a0[i0 & 3u]; z0 = (double)(((unsigned)((unsigned)x0 < 0x10000u)) & 255u); } if (((unsigned)((m0 + r0.x) < 0xa76985d0u)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                    i1 = (unsigned)(signed char)(unsigned)((int)(unsigned)!(unsigned)((int)r0.x >= (int)(unsigned)(unsigned char)(unsigned)((int)r0.y < (int)9u)) >= (int)(unsigned)((unsigned)c0 == (unsigned)w0)) & 15u;
                }
                while (i1++ < 2u && (unsigned)(garr[i1 & 7u] < 0x80000000u)) { if (--fuel == 0u) goto done;
                    u2 = u2 * 0x9e3779b1u + ((unsigned)((unsigned)((int)0x2d145afu < (int)p2) || (unsigned)e0) + (unsigned)w0);
                    a0[(unsigned)(a0[u1 & 3u] && 2u) & 3u] = (unsigned)((short)p2 > (signed char)r0.y);
                    u2 += (unsigned)!((unsigned)l0 | garr[i1 & 7u]);
                    if (budget != 0u) { budget -= 1u; u1 = fn1(0x7be735d6u, r0.x, (unsigned)(((unsigned)f0 + (unsigned)d0) || g1)); }
                }
            } else {
                if (budget != 0u) { budget -= 1u; u0 = fn1(~((unsigned)(0x10000u == (unsigned)s1) >> (*q0 & 31u)), 1u, (0xecd2b803u | 0x9d8e44u)); }
                x0 = x0 * 0x100000001b3ull + ((unsigned)c1 % ((-(unsigned)((int)0x7fffffffu >= (int)p1) / (0x26a00c05u | 1u)) | 1u));
            }
            goto L1;
            if ((unsigned)((int)(unsigned)w0 < (int)((unsigned)c1 ^ g1))) {
                switch (2u & 7u) {
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)x0, 7u, (unsigned)((short)a0[i0 & 3u] > (signed char)fuel)); }
                    v0 = 2u;
                }
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn2(i2, (unsigned)((int)(unsigned)d0 >= (int)((unsigned)e0 ^ (unsigned)e0)), ((unsigned)b0 >> ((u1 >> (*q0 & 31u)) & 31u))); }
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        L0: if (--fuel == 0u) goto done;
                        if (((unsigned)s1 ^ (unsigned)(unsigned char)(unsigned)((short)*q0 > (signed char)(unsigned)w0))) continue;
                        u2 += 0xefb03621u;
                        v0 = ((0x122ca5du ? (unsigned)c1 : g0) | (unsigned)(x0 >> 70));
                        if ((unsigned)((int)(unsigned)s0 < (int)(unsigned)l0)) goto done;
                    }
                    g1 += (unsigned)((7u & (unsigned)((i0 + *q0) && 3u)) && 0xffffffffu);
                    switch (0x7fffffffu & 7u) {
                        *q0 += ((9u | ((unsigned)e0 & p1)) * (unsigned)s1);
                        garr[(unsigned)x0 & 7u] = v0;
                        case 4u: ;
                        w0 = w0 * 6364136223846793005ull + 6u;
                    }
                    if ((unsigned)c1) {
                        break; (void)(((unsigned)c1 * garr[u2 & 7u]));
                        i2 = (unsigned)(short)(unsigned)((u0 | (unsigned)s1) || (a0[i0 & 3u] & (unsigned)((short)p0 > (signed char)9u))) & 15u;
                        *q0 = (u1 + (unsigned)(0x7fffffffu < (unsigned)c0));
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(u3 == (i2 & 4u)), 0x10000u, (unsigned)((int)9u >= (int)p2)); }
                        if ((unsigned)(unsigned char)(r0.y - 0x80000000u)) goto done;
                    } else {
                        v0 = (unsigned)((int)a0[i0 & 3u] >= (int)(*q0 / ((0x80000000u * 0x23b4a779u) | 1u)));
                    }
                    if (0xffffffffu) break;
                } while (i1++ < 5u && (unsigned)w0);
            } else {
                { unsigned t1; double z1; if ((*mp) & 1u) { t1 = p1; z1 = (double)(((7u / (5u | 1u))) & 255u); } if ((*mp) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    while (i1++ < 3u && (unsigned)((unsigned)x0 || ((unsigned)(x0 >> 70) + u3))) { if (--fuel == 0u) goto done;
                        if (((7u + i0) ^ 0x3475f5adu)) break;
                    }
                    u3 ^= (unsigned)((unsigned)((unsigned)h0 == i2) && 0x3aab5ed2u);
                }
            }
            break; (void)((g1 << ((unsigned)l0 & 31u)));
        }
    } else {
        do { if (--fuel == 0u) goto done;
            u1 ^= (7u << ((unsigned)((int)(unsigned)((int)i2 < (int)p0) >= (int)(unsigned)s0) & 31u));
            g1 += (unsigned)(0x8ace1adau < (i0 / ((unsigned)c0 | 1u)));
        } while (i0++ < 2u && ((unsigned)h0 - (unsigned)((unsigned)e0 && u0)));
        m0 ^= (unsigned)((u3 ^ (unsigned)h1) && g0);
        r0.y ^= (((unsigned)(w0 >> 29) >> (g1 & 31u)) << ((unsigned)(x0 >> 70) & 31u));
    }
    goto L0;
    switch ((g0 ? (unsigned)w0 : g0) & 7u) {
        L1: if (--fuel == 0u) goto done;
        L2: if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (u3 == 7u) return a0[i0 & 3u];
            while (i1++ < 5u && (unsigned)((unsigned)((int)p1 >= (int)(unsigned)s0) == p0)) { if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
                { unsigned t2; double z2; if (((r0.x - (unsigned)((int)(unsigned)s0 >= (int)v0))) & 1u) { t2 = ((unsigned)((unsigned)d0 == 0x48b7e854u) & u2); z2 = (double)(((unsigned)(v0 && (0x7cf2db48u | 0x10000u))) & 255u); } if (((r0.x - (unsigned)((int)(unsigned)s0 >= (int)v0))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    if ((0x39537936u >> (a0[u1 & 3u] & 31u))) {
                        case 7u: ;
                        a0[(unsigned)((int)(unsigned)f0 >= (int)i0) & 3u] = (unsigned)((int)0x35acd995u >= (int)a0[i0 & 3u]);
                        L4: if (--fuel == 0u) goto done;
                        case 6u: ;
                    }
                }
                w0 ^= (unsigned long long)(i0 >> (i1 & 31u)) << ((unsigned)((short)0x7fffffffu > (signed char)((unsigned)w0 - ((unsigned)d0 & (unsigned)l0))) & 63u);
                default: ;
                u2 ^= (0xc3ed8e2u & p2);
                f0 = f0 * 0.5f + (float)((unsigned)((garr[u2 & 7u] % (r0.x | 1u)) < (0xffffffffu >> (8u & 31u))) & 255u);
            }
            if (((unsigned)h1 ^ (u3 & i0))) continue;
            case 2u: ;
            break;
            break;
        } while (i0++ < 7u && 0xdbc7bf79u);
        case 5u: ;
        c1 = (signed char)((unsigned)e0 ^ 0x7bb00156u);
    }
    { unsigned t3; double z3; if ((-(unsigned)(u3 == (unsigned)((int)r0.y >= (int)fuel))) & 1u) { t3 = garr[i1 & 7u]; z3 = (double)(((unsigned)((unsigned)h1 == p1)) & 255u); } if ((-(unsigned)(u3 == (unsigned)((int)r0.y >= (int)fuel))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        s1 = (int)((unsigned)s1 + (unsigned)(((*mp << (0xf2767a52u & 31u)) - *q0) && 0x9ccdda2eu));
        u3 += ((unsigned)((unsigned)d0 || 7u) ? a0[u1 & 3u] : (unsigned)x0);
        if ((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)h0)) goto L0;
        if ((unsigned)((short)~(unsigned)(0x7fffffffu < (unsigned)f0) > (signed char)(unsigned)f0)) goto L2;
        if ((-(unsigned)((short)garr[i1 & 7u] > (signed char)0x233e43a5u) % (p2 | 1u))) goto done;
    }
    { unsigned t4; double z4; if ((*mp) & 1u) { t4 = (0x138e5276u * (0x7fffffffu + 3u)); z4 = (double)(((unsigned)(garr[u2 & 7u] || (unsigned)((int)(unsigned)s1 >= (int)m0))) & 255u); } if ((*mp) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        if (budget != 0u) { budget -= 1u; u0 = fn2(0xa644ae82u, (((unsigned)s0 ^ 2u) | a0[u1 & 3u]), (unsigned)((int)0x10000u < (int)(unsigned)!(unsigned)((int)7u >= (int)garr[u2 & 7u]))); }
        h1 = (unsigned short)(h1 + (unsigned)((short)(u1 % ((unsigned)(x0 >> 70) | 1u)) > (signed char)(unsigned)(signed char)(0xf824d453u - (unsigned)((short)(unsigned)s0 > (signed char)garr[i1 & 7u]))));
        if ((unsigned)((r0.x - g1) && u2)) goto L0;
        w0 = w0 * 6364136223846793005ull + u1;
        switch (((unsigned)(a0[u1 & 3u] == 0x339f89e1u) * p0) & 7u) {
            if ((unsigned)(a0[u1 & 3u] == (unsigned)e0)) {
                s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)(short)(i1 >> (((unsigned)s0 | ((unsigned)(w0 >> 29) % ((unsigned)f0 | 1u))) & 31u)) > (signed char)u3));
                u1 = u1 * 0x9e3779b1u + ~(garr[u2 & 7u] & 0x10000u);
                s1 = (int)((unsigned)s1 + 3u);
            } else {
                goto done;
            }
            i0 = ((4u >> (0x7fffffffu & 31u)) & u2) & 15u;
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(r0.x && (unsigned)s0) % ((unsigned)l0 | 1u)), (unsigned)b0, (unsigned)(8u == i1)); }
        }
    }
    goto L2;
    goto L1;
    if (*mp) {
        e0 = e0 * 0.5L + (long double)(a0[i0 & 3u] & 1023u);
        if (budget != 0u) { budget -= 1u; u1 = fn0(0xd51eb556u, 9u, 4u); }
        x0 = x0 * 0x100000001b3ull + (~((v0 * (unsigned)c1) % (0x32a9a6eu | 1u)) & (unsigned)(0xf631561au == (unsigned)h0));
    }
    if (((unsigned)h1 ^ 6u)) goto L0;
    l0 = (long)((unsigned long)l0 + ((unsigned)((short)(a0[u1 & 3u] - m0) > (signed char)((unsigned)l0 >> (0x80000000u & 31u))) >> (5u & 31u)));
    if (i2) goto L0;
    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((short)0xf47e0599u > (signed char)m0) / (i2 | 1u)), (unsigned)((int)(unsigned)x0 >= (int)(unsigned)((unsigned)c1 && fuel)), (unsigned)l0); }
    c0 = (unsigned char)(p0 ^ (unsigned)((int)a0[u1 & 3u] >= (int)p0));
    r0.x = (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)e0);
    goto done;
    while (i0++ < 2u && (unsigned)((unsigned)(p0 || m0) || (unsigned)e0)) { if (--fuel == 0u) goto done;
        if ((unsigned)(fuel || u1)) {
            *mp = (unsigned)((int)~(unsigned)((int)0x80000000u >= (int)u0) < (int)((unsigned)h1 % ((unsigned)h1 | 1u)));
            r0.y ^= g0;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(9u < (unsigned)l0));
                l0 = (long)((unsigned long)l0 + (2u % ((unsigned)d0 | 1u)));
            }
            break; (void)(0x7fffffffu);
        }
        do { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((a0[u1 & 3u] / ((unsigned)((unsigned)s0 || ((unsigned)h0 << ((unsigned)s0 & 31u))) | 1u)) & 255u);
            s0 = (int)(unsigned)(unsigned char)(unsigned)(g1 < p1);
        } while (i1++ < 7u && (0x7535f985u + g1));
        c0 = (unsigned char)(unsigned)((short)i2 > (signed char)((0x80000000u / (i0 | 1u)) | u0));
        goto L4;
        if ((0xffffffffu ? (unsigned)x0 : (unsigned)d0)) {
            l0 = (long)((unsigned long)l0 + (unsigned)(-(a0[i0 & 3u] - (unsigned)c1) < -(unsigned)(1u == *mp)));
            while (i1++ < 6u && u2) { if (--fuel == 0u) goto done;
                u3 = u3 * 0x9e3779b1u + (unsigned)((unsigned)(signed char)(0x10000u / (fuel | 1u)) == (unsigned)((short)v0 > (signed char)0xf2586bf4u));
                e0 = e0 * 0.5L + (long double)(-(6u ? p0 : (unsigned)e0) & 1023u);
                if ((unsigned)(signed char)(1u | (unsigned)c1)) {
                    d0 = d0 * 0.5 + (double)(((unsigned)(p1 || ((unsigned)d0 * (2u * (unsigned)h0))) << (p0 & 31u)) & 1023u);
                    break; (void)((unsigned)w0);
                } else {
                    if ((unsigned)(u0 || (unsigned)d0)) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(signed char)(unsigned)(i0 < (unsigned)f0), (unsigned)(signed char)(0x10000u + (unsigned)((unsigned)(w0 >> 29) && 0u)), (a0[u1 & 3u] * 0x10000u)); }
                    break; (void)((unsigned)((unsigned)h1 < (unsigned)w0));
                }
                h1 = (unsigned short)(h1 + (unsigned)!(g1 | (g1 >> (u3 & 31u))));
            }
        } else {
            v0 = (*q0 & (unsigned)e0);
            r0.y ^= (unsigned)w0;
            break; (void)(((unsigned)(w0 >> 29) & ((unsigned)c1 - p1)));
        }
    }
    v0 = (unsigned)((int)p0 >= (int)(unsigned)x0);
    if ((unsigned)h0) goto L0;
    if ((unsigned)(unsigned char)((unsigned)s1 - (unsigned)b0)) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)((unsigned)(g0 && u2) == (unsigned)((unsigned)b0 || (u1 * (unsigned)w0)));
            l0 = (long)((unsigned long)l0 + (unsigned)d0);
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)((unsigned)x0 || 0x32dbeaf2u)), (m0 - *q0), (*q0 / (m0 | 1u))); }
        *q0 = ((unsigned)((int)m0 < (int)fuel) | (0x80000000u / ((unsigned)(signed char)(unsigned)((unsigned)l0 && (unsigned)h0) | 1u)));
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(unsigned char)((unsigned)((int)v0 >= (int)0x80000000u) | 8u), 0xe17e81e3u, (unsigned)((unsigned)l0 == ~(3u / (0xffffffffu | 1u)))); }
    }
    goto L4;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    r0.y ^= (8u ^ 0x80000000u);
    if (budget != 0u) { budget -= 1u; u2 = fn1((((unsigned)(x0 >> 70) << ((unsigned)h1 & 31u)) & v0), *mp, u2); }
    goto L3;
    if ((0x7ab67b39u & v0)) goto L1;
    while (i0++ < 3u && (unsigned)s1) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0((*mp & (unsigned)s1), 0xa692257cu, (unsigned)(i1 && (unsigned)w0)); }
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(0x27f47536u || i0)) {
                    e0 = e0 * 0.5L + (long double)((unsigned)e0 & 1023u);
                    u2 += -((unsigned)l0 ? (unsigned)w0 : 0xfe3cb4dcu);
                    g1 += (((unsigned)(w0 >> 29) % (i0 | 1u)) + (unsigned)(signed char)(garr[i1 & 7u] % (0x7fffffffu | 1u)));
                } else {
                    *q0 += ((unsigned)((unsigned)(x0 >> 70) == 0x57a8b45du) | (unsigned)((int)0x89a9d43bu >= (int)0xffffffffu));
                    break; (void)((6u + a0[i0 & 3u]));
                    if ((m0 | (unsigned)l0)) break;
                }
                r0.x = 0x10000u;
                do { if (--fuel == 0u) goto done;
                    while ((unsigned)((short)0x38f46d98u > (signed char)6u)) { if (--fuel == 0u) goto done;
                        if ((unsigned)(signed char)(unsigned)(0x80000000u || ((unsigned)s0 / (garr[i1 & 7u] | 1u)))) continue;
                        { unsigned t0; double z0; if ((((unsigned)s0 << (0xffffffffu & 31u))) & 1u) { t0 = ((0x10000u << (*q0 & 31u)) | 0x7fffffffu); z0 = (double)(((2u | (unsigned)(x0 >> 70))) & 255u); } if ((((unsigned)s0 << (0xffffffffu & 31u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                            l0 = (long)((unsigned long)l0 + (unsigned)(fuel < (0xf1c3ac9au >> ((unsigned)c0 & 31u))));
                            if ((unsigned)((unsigned)((unsigned)s0 && 0x2e71531du) < 0xbd10d7a5u)) break;
                            if (budget != 0u) { budget -= 1u; u0 = fn3((g0 + 0x10000u), (0x70575e82u << (i1 & 31u)), (unsigned)(short)(r0.x << (*q0 & 31u))); }
                            h0 = (short)(p0 + ((0x7fffffffu ? 3u : p2) | (unsigned)w0));
                            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)g1 >= (int)(v0 / (fuel | 1u))), (unsigned)((int)6u >= (int)(unsigned)(u2 || i1)), (u2 ^ (unsigned)((unsigned)f0 == 0x65f087e2u))); }
                            if ((unsigned)((unsigned)h1 || 0x1ccccc20u)) continue;
                        }
                        do { if (--fuel == 0u) goto done;
                            if ((m0 ^ (unsigned)(x0 >> 70))) goto L4;
                            s0 = (int)((0x80000000u - (unsigned)l0) << ((unsigned)c1 & 31u));
                            u2 = v0;
                        } while (i2++ < 7u && (unsigned)h1);
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(fuel && (unsigned)(w0 >> 29)), garr[i1 & 7u], (unsigned)h0); }
                    }
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        for (;;) { if (--fuel == 0u) goto done;
                            break; (void)(i1);
                            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(u2 || u0), (9u & fuel), u2); }
                            if (budget != 0u) { budget -= 1u; u2 = fn1((i1 * 5u), garr[i1 & 7u], (fuel + 0x7fffffffu)); }
                            c0 = (unsigned char)((u0 / (i1 | 1u)) & (m0 ^ (unsigned)h1));
                        }
                        m0 ^= (unsigned)l0;
                        w0 = w0 * 6364136223846793005ull + (9u * (unsigned)s1);
                        do { if (--fuel == 0u) goto done;
                            L0: if (--fuel == 0u) goto done;
                            if ((u0 / (0x7fffffffu | 1u))) break;
                            c1 = (signed char)(unsigned)(unsigned char)((0x80000000u | u0) % ((*mp - (unsigned)x0) | 1u));
                            w0 = w0 * 6364136223846793005ull + ((p2 << (7u & 31u)) ^ 9u);
                        } while (i2++ < 3u && (r0.x | u0));
                    }
                } while (i0++ < 3u && (unsigned)(m0 && (unsigned)((short)0xffffffffu > (signed char)(unsigned)c0)));
            } while (i2++ < 5u && 0x10000u);
            g0 = (0x80000000u ^ 5u);
            if (5u) {
                if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)s0 / ((unsigned)(w0 >> 29) | 1u)), (unsigned)((int)(unsigned)s1 >= (int)(unsigned)f0), ((unsigned)(signed char)(0x1142448bu + 0x10000u) + 0x7fffffffu)); }
                while (g1) { if (--fuel == 0u) goto done;
                    switch (fuel & 7u) {
                        if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)(w0 >> 29) % (0x7fffffffu | 1u)), (unsigned)((unsigned)s0 && (u1 | (unsigned)f0)), (unsigned)(0xee66d584u < ((unsigned)l0 - *mp))); }
                        if ((unsigned)((int)(unsigned)(7u || a0[u1 & 3u]) >= (int)*q0)) continue;
                        if (0x10000u) goto L4;
                    }
                }
                break; (void)((unsigned)(unsigned char)(unsigned)(g0 && (a0[i0 & 3u] & a0[i0 & 3u])));
            }
        } while (i1++ < 6u && (unsigned)((int)i0 >= (int)(unsigned)s1));
    }
    if (((unsigned)(x0 >> 70) / (g1 | 1u))) {
        r0.x = ((unsigned)((int)(unsigned)f0 < (int)(unsigned)(x0 >> 70)) / (*mp | 1u));
        c0 = (unsigned char)(u1 ^ 0xb18cc40fu);
        if (fuel < 8u) return (((*mp * (unsigned)f0) << ((unsigned)w0 & 31u)) | 9u);
        if ((garr[u2 & 7u] ^ i2)) {
            if (u3 == 7u) return (garr[i1 & 7u] % (0xbedfbd0eu | 1u));
            for (;;) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(u2, (unsigned)(4u == (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)c1)), (unsigned)((int)0x7fffffffu < (int)(0xffffffffu % (u2 | 1u)))); }
                    L1: if (--fuel == 0u) goto done;
                    switch (u1 & 7u) {
                        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)s0, (unsigned)((int)(r0.x ^ a0[i0 & 3u]) < (int)(unsigned)c1), ((0xffffffffu ^ 0x80000000u) % (u3 | 1u))); }
                        do { if (--fuel == 0u) goto done;
                            break; (void)((unsigned)l0);
                        } while (i2++ < 5u && (g0 | 0x7fffffffu));
                    }
                } while (i1++ < 6u && ((unsigned)s0 - (unsigned)s0));
            }
            l0 = (long)((unsigned long)l0 + (i1 % ((unsigned)e0 | 1u)));
            e0 = e0 * 0.5L + (long double)((unsigned)!(unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)(w0 >> 29)) & 1023u);
            { unsigned t1; double z1; if ((((unsigned)(i1 && a0[i0 & 3u]) / (i0 | 1u))) & 1u) { t1 = (0u * (p0 * u3)); z1 = (double)(((unsigned)(6u || (unsigned)(unsigned char)(unsigned)(i1 == i0))) & 255u); } if ((((unsigned)(i1 && a0[i0 & 3u]) / (i0 | 1u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)h1 == (unsigned)(x0 >> 70))) break;
                    { unsigned t2; double z2; if (((unsigned)(unsigned char)(u0 + (p0 >> (i0 & 31u)))) & 1u) { t2 = ((unsigned)c1 + (unsigned)h1); z2 = (double)((v0) & 255u); } if (((unsigned)(unsigned char)(u0 + (p0 >> (i0 & 31u)))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                        v0 = (((unsigned)h1 + u0) | (unsigned)((unsigned)(u0 == (unsigned)(w0 >> 29)) < garr[u2 & 7u]));
                        i1 = ((unsigned)((unsigned)c0 < 0xa9fb7e1bu) ? (unsigned)l0 : (unsigned)h1) & 15u;
                        if (((0x7fffffffu + u1) / (*q0 | 1u))) continue;
                        L2: if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + ~(((unsigned)s0 ^ 0x7fffffffu) % (0x89178759u | 1u));
                        q0 = &garr[(((unsigned)((short)(unsigned)d0 > (signed char)u1) * 0xb541bcdcu) - ((unsigned)b0 & 3u)) & 7u];
                    }
                    w0 = w0 * 6364136223846793005ull + (unsigned)h0;
                } while (i0++ < 3u && (unsigned)((unsigned)c0 && garr[i1 & 7u]));
                r0.y ^= (unsigned)c1;
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    h0 = (short)((unsigned)((int)p0 < (int)(p2 ^ p2)) ^ (p0 + 0x10000u));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((0x7e227d8u + a0[u1 & 3u]) && (unsigned)c0), (i0 >> (0x46833893u & 31u)), (unsigned)((int)0xcb4a1202u >= (int)0x1e2812c0u)); }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(i1 ^ 0xb4ba8941u), ((unsigned)w0 + 0x10000u), (unsigned)((int)(0x80000000u / (0xec6d9f6fu | 1u)) >= (int)0x7e3d1ae7u)); }
                    s1 = (int)((unsigned)s1 + ((garr[u2 & 7u] << (0x7fffffffu & 31u)) << (v0 & 31u)));
                }
                c0 = (unsigned char)((unsigned)((short)(unsigned)c0 > (signed char)g1) % ((unsigned)(short)(unsigned)(fuel == (unsigned)((short)*mp > (signed char)*q0)) | 1u));
            }
        } else {
            if ((unsigned)(unsigned char)((unsigned)b0 - (unsigned)c0)) {
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)c1, -((unsigned)e0 + (g0 & (unsigned)b0)), (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)l0)); }
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)d0, (g0 | p0), (unsigned)s0); }
                g0 = *q0;
            }
            a0[(unsigned)((int)*q0 >= (int)(unsigned)f0) & 3u] = (unsigned)((int)i1 >= (int)(u1 | i0));
            if (a0[u1 & 3u]) goto L3;
        }
    }
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)s1 < 0xffffffffu)) {
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)1u << ((8u * 3u) & 63u);
                while (i2++ < 6u && 0x7cc5eaf4u) { if (--fuel == 0u) goto done;
                    { unsigned t3; double z3; if (((unsigned)((int)garr[u2 & 7u] < (int)0x10000u)) & 1u) { t3 = (unsigned)d0; z3 = (double)(((unsigned)((short)0x5c3628a3u > (signed char)g0)) & 255u); } if (((unsigned)((int)garr[u2 & 7u] < (int)0x10000u)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                        s1 = (int)((unsigned)s1 + ((a0[i0 & 3u] << (i1 & 31u)) | p0));
                        u1 = (0x13ecd844u | (unsigned)((short)(g0 * 9u) > (signed char)0x367609e3u));
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((0xffffffffu >> (i0 & 31u)) | a0[u1 & 3u]), (unsigned)c1, (unsigned)!(unsigned)(((unsigned)f0 * r0.y) < 0x10000u)); }
                        r0.x = (unsigned)((unsigned)x0 && i2);
                    }
                    garr[(unsigned)c1 & 7u] = (unsigned)((int)(unsigned)(~(unsigned)((unsigned)e0 || g1) && 4u) >= (int)(unsigned)h1);
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        L3: if (--fuel == 0u) goto done;
                    }
                    break; (void)((unsigned)h0);
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(((unsigned)(w0 >> 29) << (0x10000u & 31u)) && 9u), (garr[u2 & 7u] + p2), (unsigned)((int)0x10000u < (int)m0)); }
                }
                r0.y ^= (unsigned)((short)0x471ffe7cu > (signed char)v0);
                L4: if (--fuel == 0u) goto done;
                u3 = u3 * 0x9e3779b1u + (u2 >> ((unsigned)((unsigned)((short)9u > (signed char)(unsigned)s1) < 7u) & 31u));
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(x0 >> 70), (unsigned)(((unsigned)c0 / (p2 | 1u)) || (unsigned)s1), (a0[i0 & 3u] * 0x10000u)); }
            }
            c0 = (unsigned char)(6u ^ ((unsigned)l0 ? 7u : 0x10000u));
            garr[(i0 % (0x6c28ca31u | 1u)) & 7u] = (0x7fffffffu & (unsigned)((int)9u < (int)g1));
        } else {
            { unsigned t4; double z4; if (((1u ^ 0x6524eb78u)) & 1u) { t4 = a0[u1 & 3u]; z4 = (double)((((unsigned)h0 ? 0u : v0)) & 255u); } if (((1u ^ 0x6524eb78u)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                w0 ^= (unsigned long long)u2 << (0x80000000u & 63u);
                w0 ^= (unsigned long long)(unsigned)((int)6u < (int)fuel) << ((unsigned)(4u || 3u) & 63u);
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((unsigned)l0 < (unsigned)s1) + (unsigned)b0), ~((unsigned)h0 | (unsigned)(0x82dab255u || (unsigned)(w0 >> 29))), (2u << ((unsigned)(4u == 0x80000000u) & 31u))); }
            }
            a0[u3 & 3u] = ((v0 & (unsigned)(p2 < 0xffffffffu)) & garr[i1 & 7u]);
            if (fuel < 8u) return (unsigned)((unsigned)(x0 >> 70) == p2);
        }
        garr[(unsigned)b0 & 7u] = (unsigned)!(unsigned)((int)*q0 >= (int)((unsigned)b0 - (unsigned)s0));
    }
    d0 = d0 * 0.5 + (double)((u1 | (0xa248bf2au ^ 9u)) & 1023u);
    if (0x10000u) goto L3;
    w0 ^= (unsigned long long)p2 << ((~(unsigned)(v0 && i0) & a0[u1 & 3u]) & 63u);
    goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn2(a0[u1 & 3u], ((unsigned)((int)0x2e5ed0e0u < (int)garr[u2 & 7u]) - 0x7fffffffu), (3u & p2)); }
    garr[4u & 7u] = -((i1 ? 0x80000000u : 1u) & (a0[u1 & 3u] - p2));
    if (g0) goto L2;
    { unsigned t5; double z5; if (((unsigned)!(v0 % ((unsigned)h0 | 1u))) & 1u) { t5 = (i0 | p0); z5 = (double)(((unsigned)(short)(p1 / (0x7076aec5u | 1u))) & 255u); } if (((unsigned)!(v0 % ((unsigned)h0 | 1u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
        v0 = ((unsigned)x0 % (v0 | 1u));
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((garr[i1 & 7u] + r0.y), (r0.x ^ (unsigned)h1), (7u / ((4u ^ r0.y) | 1u))); }
    if (6u) {
        if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)(signed char)(unsigned)(r0.x && i1), (unsigned)((unsigned)(x0 >> 70) == (unsigned)b0), ((unsigned)x0 + (unsigned)h0)); }
        switch ((0x22da1e2du * 0x80000000u) & 7u) {
            if (r0.y) {
                case 3u: ;
                break; (void)((m0 - i0));
                l0 = (long)((unsigned long)l0 + (6u << ((unsigned)(r0.y == ((unsigned)s1 << (fuel & 31u))) & 31u)));
                case 4u: ;
            }
            if (((unsigned)(x0 >> 70) / (i0 | 1u))) goto done;
            u1 ^= ((unsigned)((int)(unsigned)l0 >= (int)r0.x) / ((v0 % ((unsigned)(short)(0xffffffffu << (0xf1291965u & 31u)) | 1u)) | 1u));
        }
        l0 = (long)((unsigned long)l0 + (0xcb4e518eu / (((r0.y >> ((unsigned)s1 & 31u)) - (unsigned)x0) | 1u)));
        v0 = (unsigned)!(unsigned)((int)(g1 | (unsigned)h1) < (int)(unsigned)(garr[i1 & 7u] < *mp));
        if (budget != 0u) { budget -= 1u; u2 = fn3((8u / ((unsigned)d0 | 1u)), (0xf48a2c1du / ((unsigned)(2u || p1) | 1u)), ((unsigned)(w0 >> 29) | (unsigned)((int)p1 >= (int)0x4c6bcd16u))); }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((*mp ^ a0[i0 & 3u]), (unsigned)((int)u3 < (int)0x7abff955u), (0x10000u ? r0.y : 0x7fffffffu)); }
    if (r0.y) goto L3;
    u3 = u3 * 0x9e3779b1u + (unsigned)x0;
    while (i0++ < 5u && (p2 - p0)) { if (--fuel == 0u) goto done;
        if (i1) break;
        if ((unsigned)((short)(unsigned)((int)0x155438c0u < (int)(unsigned)h1) > (signed char)(unsigned)b0)) continue;
        if ((unsigned)(0xffffffffu && *q0)) break;
        if ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)h0)) goto L2;
    }
    s0 = (int)(unsigned)((short)(unsigned)((short)a0[u1 & 3u] > (signed char)u3) > (signed char)(0x7fffffffu / (*mp | 1u)));
    { unsigned t6; double z6; if ((garr[u2 & 7u]) & 1u) { t6 = i2; z6 = (double)(((unsigned)d0) & 255u); } if ((garr[u2 & 7u]) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
        *q0 += ((unsigned)((short)u3 > (signed char)(0x80000000u / (m0 | 1u))) + (unsigned)((int)(unsigned)w0 >= (int)(unsigned)c1));
        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(u0 || fuel) || (((unsigned)x0 + 4u) & 0x18fdf6ceu)) & 1023u);
        if ((unsigned)(unsigned char)(u3 ^ (unsigned)(w0 >> 29))) goto L0;
        if (((u0 * u1) / (p0 | 1u))) goto L1;
        if (budget != 0u) { budget -= 1u; u2 = fn2(*mp, -((unsigned)h0 >> (0x10000u & 31u)), 0u); }
        e0 = e0 * 0.5L + (long double)(((i2 << (u3 & 31u)) | (unsigned)(6u && a0[i0 & 3u])) & 1023u);
    }
    if (a0[i0 & 3u]) goto L4;
    u2 += (unsigned)(x0 >> 70);
    if (budget != 0u) { budget -= 1u; u3 = fn0(i1, (unsigned)((unsigned)e0 && ((unsigned)b0 << (garr[i1 & 7u] & 31u))), (i0 / ((m0 & (unsigned)f0) | 1u))); }
    if ((0x7fffffffu ^ (unsigned)(0x10000u == garr[u2 & 7u]))) {
        if ((unsigned)(unsigned char)((unsigned)(w0 >> 29) + g0)) goto L4;
        if ((0xeef87cfu ? 0u : 5u)) goto L3;
        if (((unsigned)e0 >> ((unsigned)s0 & 31u))) goto L2;
        goto L3;
        q0 = &garr[(unsigned)((r0.x ^ garr[u2 & 7u]) && (unsigned)((short)(unsigned)d0 > (signed char)a0[i0 & 3u])) & 7u];
        if (-((unsigned)(w0 >> 29) | (unsigned)(p0 && (unsigned)e0))) goto L1;
    } else {
        x0 = x0 * 0x100000001b3ull + ((unsigned)x0 ^ 0x7fffffffu);
        switch ((*mp << (p0 & 31u)) & 7u) {
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)s0 << (((unsigned)l0 - 0x80000000u) & 63u);
            }
        }
        if ((9u | 0x21ccdfd3u)) {
            w0 ^= (unsigned long long)(i1 & (unsigned)h1) << (((unsigned)b0 - (unsigned)c0) & 63u);
            if ((0xaaff8ccu * 4u)) goto done;
        }
        f0 = f0 * 0.5f + (float)(((unsigned)((unsigned)h1 < 0u) * (unsigned)((short)u2 > (signed char)(unsigned)e0)) & 255u);
    }
    if ((unsigned)e0) {
        if (budget != 0u) { budget -= 1u; u0 = fn1((0x8ca31d5du & (i1 >> (garr[u2 & 7u] & 31u))), (unsigned)h1, -(0x34ac390fu - *mp)); }
        if (fuel < 8u) return (unsigned)h1;
    } else {
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(((0x97d49db0u << (0x7fffffffu & 31u)) >> (1u & 31u)));
        }
        *mp = garr[i1 & 7u];
        if ((unsigned)f0) goto done;
    }
    c1 = (signed char)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x80000000u) & (unsigned)b0);
    if (((i2 % ((unsigned)(w0 >> 29) | 1u)) >> ((unsigned)d0 & 31u))) goto done;
    m0 ^= ((unsigned)((int)(unsigned)(w0 >> 29) < (int)v0) - (unsigned)(u1 || 0x7fffffffu));
    if (((unsigned)!((unsigned)w0 + 0u) & i1)) goto L2;
    if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)c1, (unsigned)(((unsigned)s0 ^ a0[u1 & 3u]) && m0), 0x4484b494u); }
    { unsigned t7; double z7; if (((5u << ((unsigned)e0 & 31u))) & 1u) { t7 = (u1 % (*q0 | 1u)); z7 = (double)((~(u2 / ((unsigned)((short)p1 > (signed char)fuel) | 1u))) & 255u); } if (((5u << ((unsigned)e0 & 31u))) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
        do { if (--fuel == 0u) goto done;
            i0 = ((unsigned)h1 + (unsigned)(i1 || (unsigned)((int)7u < (int)0x7fffffffu))) & 15u;
            u2 += ((unsigned)((short)p0 > (signed char)(unsigned)h1) - (unsigned)h1);
        } while (i0++ < 2u && (unsigned)(*q0 == ((unsigned)x0 & *q0)));
        goto L3;
        do { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + u1);
            { unsigned t8; double z8; if (((g1 % (0x7fffffffu | 1u))) & 1u) { t8 = (unsigned)(a0[u1 & 3u] == r0.y); z8 = (double)((((unsigned)(0x7fffffffu || m0) + g0)) & 255u); } if (((g1 % (0x7fffffffu | 1u))) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                l0 = (long)((unsigned long)l0 + (unsigned)((int)0x10000u >= (int)(unsigned)((int)fuel >= (int)(0xd1ce1d44u | 0x9fa96836u))));
                *q0 = (a0[u1 & 3u] << (((8u >> (i1 & 31u)) * i0) & 31u));
            }
            do { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + ((g0 + (1u ^ 0x80000000u)) / (r0.x | 1u)));
                { unsigned t9; double z9; if (((u0 - garr[u2 & 7u])) & 1u) { t9 = (unsigned)(signed char)((unsigned)x0 * garr[u2 & 7u]); z9 = (double)(((unsigned)((unsigned)(signed char)(g1 >> (0xffffffffu & 31u)) < (unsigned)f0)) & 255u); } if (((u0 - garr[u2 & 7u])) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                    if ((unsigned)(unsigned char)(m0 % ((unsigned)f0 | 1u))) break;
                    x0 = x0 * 0x100000001b3ull + 0xc9aa2afeu;
                }
            } while (i1++ < 2u && 4u);
        } while (i0++ < 2u && (unsigned)l0);
    }
    do { if (--fuel == 0u) goto done;
        { unsigned t10; double z10; if ((u2) & 1u) { t10 = (i0 ? r0.y : (unsigned)x0); z10 = (double)((m0) & 255u); } if ((u2) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
            u2 ^= ((unsigned)f0 | (unsigned)(fuel || g1));
        }
        while (i1++ < 7u && (r0.x << (4u & 31u))) { if (--fuel == 0u) goto done;
            while (i2++ < 5u && (unsigned)(garr[u2 & 7u] && p0)) { if (--fuel == 0u) goto done;
                if ((u1 % (0x22c55353u | 1u))) break;
                f0 = f0 * 0.5f + (float)((unsigned)(u0 && (unsigned)(*q0 || u1)) & 255u);
                if (((0xdefdd9e8u + 8u) ^ (unsigned)e0)) break;
            }
            if ((i1 * (a0[i0 & 3u] % (g1 | 1u)))) break;
            if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)c0 & 0xf02624d9u), ~((p1 | i1) >> (2u & 31u)), (((unsigned)l0 | p1) | (unsigned)l0)); }
            if (budget != 0u) { budget -= 1u; u1 = fn2((0xf33fbcc5u % (0x10000u | 1u)), ((unsigned)(w0 >> 29) ^ (unsigned)(unsigned char)(g1 >> ((unsigned)f0 & 31u))), (0x267eb59bu << (0x38041795u & 31u))); }
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((0x9295bd4u & (unsigned)s1));
                a0[0xd303316bu & 3u] = ((g1 << ((unsigned)(0x7fffffffu < 0x2f727efcu) & 31u)) >> (0xea42b2ecu & 31u));
                d0 = d0 * 0.5 + (double)(((unsigned)((short)(unsigned)h1 > (signed char)(unsigned)(p2 && u1)) + (unsigned)(unsigned char)(unsigned)(i1 && (unsigned)s0)) & 1023u);
                garr[(i0 << (a0[i0 & 3u] & 31u)) & 7u] = (unsigned)((int)((unsigned)c0 * (unsigned)h0) < (int)2u);
                r0.y ^= ((unsigned)((short)0x80000000u > (signed char)((unsigned)d0 - 0x10000u)) - (0x6d850025u << ((unsigned)d0 & 31u)));
                continue; (void)(u3);
            }
        }
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((unsigned)f0 || (unsigned)c1), fuel, (unsigned)(((unsigned)(w0 >> 29) % (p2 | 1u)) || p0)); }
        if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)(x0 >> 70) | 0x9346b2bbu), ((unsigned)(garr[i1 & 7u] == (unsigned)(x0 >> 70)) + 0xbde63341u), (0x80000000u * (unsigned)((int)(unsigned)f0 < (int)g0))); }
    } while (i0++ < 6u && ((unsigned)f0 & (0xffffffffu ^ 5u)));
    w0 = w0 * 6364136223846793005ull + ((unsigned)w0 % ((a0[i0 & 3u] | 3u) | 1u));
    u2 += ((unsigned)(x0 >> 70) % ((unsigned)(u2 < a0[i0 & 3u]) | 1u));
    if (budget != 0u) { budget -= 1u; u3 = fn2(*mp, i2, (u1 / (6u | 1u))); }
    while ((unsigned)x0) { if (--fuel == 0u) goto done;
        s0 = (int)((unsigned)!(unsigned)((unsigned)s0 == (unsigned)b0) / ((unsigned)((int)(unsigned)(0xffffffffu || (unsigned)h0) < (int)u3) | 1u));
        if (u0) break;
        garr[i0 & 7u] = (unsigned)((unsigned)((short)u3 > (signed char)u0) < (2u - (unsigned)(x0 >> 70)));
        switch ((0x39bd88a3u - (unsigned)(a0[i0 & 3u] || 8u)) & 7u) {
            if (p1) goto L0;
            if ((unsigned)((int)*q0 < (int)(0x177e11adu >> (0x34aeebf1u & 31u)))) break;
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 8u, 0x8f2ad4bfu, 0x2aa69c76u },
        { 9u, 0xe542f163u, 0x372f160bu },
        { 2u, 0xefde757u, 0xcd85c122u },
        { 10u, 0x4e590a1eu, 0xcdf591eau },
        { 3u, 0x550f82fau, 0x4e722328u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
