// test-ssa-source's program of seed 134000446 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x3fc5a3ffu, g1 = 0xeb0b6c5au;
static unsigned garr[8] = { 0x629cf7fbu, 0x7d9a33e9u, 0x18b161a1u, 0x40937ac8u, 0x3e93d6f4u, 0x319272d9u, 0xff05aecdu, 0xf660f4bau };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((0x7fffffffu * 0x7fffffffu)) goto L1;
    while ((1u ^ -(r0.x / (0x10000u | 1u)))) { if (--fuel == 0u) goto done;
        if (-(unsigned)((int)(unsigned)w0 < (int)(2u & (unsigned)(x0 >> 70)))) continue;
        switch ((0x28ab7e46u - (unsigned)s1) & 7u) {
            e0 = e0 * 0.5L + (long double)((unsigned)((r0.x | a0[u1 & 3u]) < u1) & 1023u);
            switch ((unsigned)h0 & 7u) {
                s0 = (int)(garr[i1 & 7u] * (unsigned)((int)u2 >= (int)(unsigned)((short)i0 > (signed char)0x10077254u)));
                L0: if (--fuel == 0u) goto done;
                r0.x = (unsigned)((int)(unsigned)(unsigned char)((unsigned)(w0 >> 29) ? (unsigned)h0 : i2) >= (int)0x7fffffffu);
                if (garr[u2 & 7u]) {
                    s1 = (int)((unsigned)s1 + (g0 + (u2 + garr[i1 & 7u])));
                    switch ((unsigned)s1 & 7u) {
                        case 3u: ;
                        L1: if (--fuel == 0u) goto done;
                    }
                    do { if (--fuel == 0u) goto done;
                        r0.y ^= (unsigned)!(u0 << (0xffffffffu & 31u));
                        L2: if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + ((unsigned)!(unsigned)((int)(unsigned)h1 < (int)a0[i0 & 3u]) * i1));
                        *mp = (m0 | (0u * 3u));
                        u3 += (-(unsigned)(0xe8a8a283u && g1) + 0x8795c0bfu);
                    } while (i1++ < 6u && (((unsigned)f0 & (unsigned)w0) - g0));
                    g0 = (unsigned)((unsigned)e0 || garr[i1 & 7u]);
                    s0 = (int)r0.y;
                    L3: if (--fuel == 0u) goto done;
                } else {
                    if (((unsigned)b0 & (unsigned)(*mp < r0.x))) goto L0;
                    do { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)((unsigned)!(((unsigned)(r0.x == (unsigned)s1) >> ((p2 - 0xc5e962bbu) & 31u)) & 1u) & 255u);
                        u3 = u3 * 0x9e3779b1u + (unsigned)((int)(8u >> ((unsigned)e0 & 31u)) >= (int)(unsigned)((unsigned)b0 < (unsigned)h0));
                        h0 = (short)(unsigned)(unsigned char)(unsigned)((short)*q0 > (signed char)(unsigned)(5u && (0xfb86ce2du << (a0[u1 & 3u] & 31u))));
                        case 3u: ;
                        L4: if (--fuel == 0u) goto done;
                    } while (i1++ < 2u && (unsigned)(0x80000000u && (unsigned)(short)(u0 | *mp)));
                    while (i1++ < 5u && (unsigned)(signed char)(unsigned)(0xff73c308u && (unsigned)(0x27bd1f5fu && 3u))) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + *mp);
                    }
                    q0 = &garr[(unsigned)((r0.x + (unsigned)l0) == garr[i1 & 7u]) & 7u];
                }
                *mp = (p2 ? (unsigned)(x0 >> 70) : (unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)b0));
                default: ;
            }
        }
        if (i2) break;
        if ((unsigned)((int)(unsigned)l0 >= (int)p0)) break;
    }
    r0.x = 0x46c1bc30u;
    q0 = &garr[(unsigned)((unsigned)l0 == 0x80000000u) & 7u];
    g0 = (unsigned)((int)(8u >> (0x7fffffffu & 31u)) >= (int)(a0[u1 & 3u] - g1));
    if ((p1 | 0x6f11f3e1u)) goto L2;
    if ((unsigned)((short)p2 > (signed char)u2)) goto L3;
    if ((unsigned)((int)(u3 % (5u | 1u)) >= (int)0xfa25477eu)) goto L1;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (a0[u1 & 3u] - (((unsigned)s0 | i2) + ((unsigned)x0 << (u3 & 31u)))));
        i0 = ((unsigned)h0 - 0x8db7e830u) & 15u;
    }
    e0 = e0 * 0.5L + (long double)(v0 & 1023u);
    u3 = (p0 | (unsigned)(0x7fffffffu < g0));
    if (i1) goto L3;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)d0) {
            w0 = w0 * 6364136223846793005ull + 0xbde34ec2u;
            if (((unsigned)((int)a0[u1 & 3u] < (int)u0) >> (0xf5506f7fu & 31u))) goto L2;
        } else {
            u2 ^= (unsigned)((int)((a0[i0 & 3u] % (u0 | 1u)) * (0xffffffffu << (garr[i1 & 7u] & 31u))) < (int)i1);
            i0 = i1 & 15u;
            break; (void)((unsigned)((unsigned)((int)g1 < (int)0xffffffffu) && 4u));
            for (;;) { if (--fuel == 0u) goto done;
                break; (void)(*q0);
                m0 ^= (1u >> ((unsigned)((short)g0 > (signed char)(unsigned)h0) & 31u));
                while ((unsigned)(short)(p1 << ((unsigned)(short)(unsigned)((short)0x7fffffffu > (signed char)(unsigned)b0) & 31u))) { if (--fuel == 0u) goto done;
                    switch ((7u ? u2 : *mp) & 7u) {
                        case 7u: ;
                        switch ((unsigned)c1 & 7u) {
                            x0 = x0 * 0x100000001b3ull + (u0 | g1);
                            if ((*mp * garr[i1 & 7u])) continue;
                        }
                    }
                }
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    i0 = (unsigned)(a0[i0 & 3u] == (unsigned)((int)2u >= (int)((0x69242399u * (unsigned)c1) << (9u & 31u)))) & 15u;
                    if (v0) break;
                    *q0 = (unsigned)(0xce2086b8u || (unsigned)(((unsigned)w0 & (unsigned)c0) && (0xd7121f8cu % (fuel | 1u))));
                }
                *mp = (unsigned)!(0xffffffffu % ((2u & u3) | 1u));
            }
        }
        if ((unsigned)h1) break;
    }
    goto L2;
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)u2 < (int)(unsigned)((int)~(unsigned)((short)(*q0 & 0x80000000u) > (signed char)g1) < (int)u1));
    w0 ^= (unsigned long long)(unsigned)((unsigned)l0 < (unsigned)s0) << (((unsigned)x0 >> ((a0[u1 & 3u] | 0x80000000u) & 31u)) & 63u);
    { unsigned t0; double z0; if (((unsigned)(x0 >> 70)) & 1u) { t0 = (p0 & (unsigned)(x0 >> 70)); z0 = (double)(((u3 % ((6u | a0[u1 & 3u]) | 1u))) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if (4u) goto L2;
        do { if (--fuel == 0u) goto done;
            if ((i0 % ((2u % (9u | 1u)) | 1u))) {
                s0 = (int)-((unsigned)(u1 || (unsigned)w0) * 0x56706b7au);
                w0 ^= (unsigned long long)u2 << (((5u >> (0x5df7b1c9u & 31u)) - 0x28de5d33u) & 63u);
                break; (void)((i0 & 1u));
                break; (void)((unsigned)(signed char)(unsigned)(fuel < r0.y));
                { unsigned t1; double z1; if ((0xffffffffu) & 1u) { t1 = (unsigned)((short)r0.y > (signed char)(unsigned)s0); z1 = (double)(((p0 ^ (8u + (unsigned)x0))) & 255u); } if ((0xffffffffu) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    if ((8u ^ 0xffffffffu)) break;
                    u2 = (unsigned)((short)0xf782cfd2u > (signed char)(unsigned)(u1 || (u2 / ((0xb2ea01d2u - g1) | 1u))));
                    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)h0 == (unsigned)((int)(unsigned)d0 < (int)i2));
                }
            }
            if (p0) break;
            if ((0x80000000u - a0[i0 & 3u])) break;
            { unsigned t2; double z2; if (((unsigned)((short)0x80000000u > (signed char)(unsigned)h0)) & 1u) { t2 = 0xd048621fu; z2 = (double)((i0) & 255u); } if (((unsigned)((short)0x80000000u > (signed char)(unsigned)h0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                if ((m0 | (unsigned)b0)) break;
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    a0[(unsigned)(m0 < fuel) & 3u] = ((unsigned)(g0 || g0) >> (~(p0 / ((unsigned)l0 | 1u)) & 31u));
                }
                if (u3 == 7u) return ((unsigned)l0 & (unsigned)f0);
                v0 = (unsigned)((0x80000000u % (*q0 | 1u)) == (unsigned)(6u || (unsigned)((int)(unsigned)h1 >= (int)0x5bdf4dfdu)));
                if (garr[i1 & 7u]) goto L2;
            }
        } while (i0++ < 4u && m0);
        if (((unsigned)l0 & (garr[u2 & 7u] ^ (unsigned)e0))) goto L4;
        *mp = 0x10000u;
        h0 = (short)g0;
        m0 ^= (unsigned)((short)(1u ^ fuel) > (signed char)(unsigned)f0);
    }
    goto L2;
    f0 = f0 * 0.5f + (float)(((unsigned)c1 >> (0x80000000u & 31u)) & 255u);
    i0 = (unsigned)((int)-(unsigned)((unsigned)((unsigned)b0 == 0x80000000u) && (unsigned)(i2 && r0.y)) < (int)garr[i1 & 7u]) & 15u;
    goto L4;
    switch ((i0 + (unsigned)s1) & 7u) {
        if ((unsigned)d0) break;
        s0 = (int)(*mp * 0x82782ac7u);
        switch ((unsigned)d0 & 7u) {
            do { if (--fuel == 0u) goto done;
                case 1u: ;
                c1 = (signed char)((unsigned)((short)8u > (signed char)(unsigned)f0) & ((unsigned)l0 >> ((unsigned)((int)0x7fffffffu >= (int)*q0) & 31u)));
                if (((*mp >> (p1 & 31u)) % (p0 | 1u))) continue;
                continue; (void)((unsigned)((short)p0 > (signed char)fuel));
                if ((unsigned)x0) continue;
            } while (i0++ < 6u && (unsigned)(0x1afcb3c8u || (4u | 0xce07c793u)));
            while (i0++ < 4u && (unsigned)(signed char)((unsigned)f0 - (unsigned)w0)) { if (--fuel == 0u) goto done;
                r0.x = (unsigned)((int)0x7fffffffu < (int)u0);
                h0 = (short)(unsigned)((unsigned)(short)((unsigned)((int)(unsigned)((short)(unsigned)c0 > (signed char)(unsigned)x0) < (int)fuel) << (garr[u2 & 7u] & 31u)) || garr[u2 & 7u]);
                switch (((unsigned)((int)(unsigned)c0 >= (int)m0) >> ((unsigned)h1 & 31u)) & 7u) {
                    f0 = f0 * 0.5f + (float)(((unsigned)b0 >> (((unsigned)h0 & p2) & 31u)) & 255u);
                    w0 = w0 * 6364136223846793005ull + (garr[u2 & 7u] | (m0 >> ((unsigned)((unsigned)b0 == u0) & 31u)));
                    continue; (void)(((unsigned)!(unsigned)((int)p0 >= (int)a0[i0 & 3u]) >> (m0 & 31u)));
                    do { if (--fuel == 0u) goto done;
                        goto L3;
                        h0 = (short)~(unsigned)((short)-(unsigned)((int)((g0 - u1) | (unsigned)w0) < (int)a0[u1 & 3u]) > (signed char)4u);
                        for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                            case 5u: ;
                            garr[(p0 * 0x10000u) & 7u] = (5u & p2);
                        }
                        *q0 += (unsigned)((int)(a0[i0 & 3u] & (unsigned)(signed char)((unsigned)c1 * (unsigned)s0)) >= (int)(0x4bd545f1u | i1));
                        if (~((unsigned)((short)0u > (signed char)4u) >> (u0 & 31u))) continue;
                    } while (i1++ < 4u && fuel);
                    if (u3 == 7u) return 0xffffffffu;
                }
                r0.x = ~((0xf7ec10efu * 0xffffffffu) ^ (unsigned)f0);
            }
            w0 = w0 * 6364136223846793005ull + (u3 << ((unsigned)((int)(unsigned)b0 < (int)(*q0 >> (7u & 31u))) & 31u));
        }
    }
    v0 = g1;
    do { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)(i0 && *q0);
        if (g1) break;
        *q0 += ((unsigned)!((unsigned)s1 >> (a0[i0 & 3u] & 31u)) ^ (unsigned)e0);
        c0 = (unsigned char)r0.x;
    } while (i0++ < 3u && (unsigned)((int)u1 < (int)m0));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            g0 = ((*mp ^ 0x376d72c0u) << (0x2856048bu & 31u));
            u1 = u1 * 0x9e3779b1u + v0;
            if (fuel < 8u) return ((7u + (unsigned)b0) >> (0x7fffffffu & 31u));
            r0.x = (unsigned)d0;
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)(0x1a49c04du && (unsigned)f0) < (unsigned)b0);
        u2 = (~(unsigned)((int)(i1 ? (unsigned)h1 : 0xdb1d94c7u) >= (int)7u) + 6u);
        do { if (--fuel == 0u) goto done;
            u1 ^= (p1 << (((unsigned)e0 + u2) & 31u));
            { unsigned t3; double z3; if (((unsigned)!((unsigned)s1 - (unsigned)(*q0 && m0))) & 1u) { t3 = (unsigned)((int)i1 < (int)(unsigned)(v0 || (unsigned)d0)); z3 = (double)((fuel) & 255u); } if (((unsigned)!((unsigned)s1 - (unsigned)(*q0 && m0))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                q0 = &garr[0x80000000u & 7u];
            }
            u3 = ((unsigned)((int)i0 >= (int)4u) | (*mp + (unsigned)((int)(unsigned)h0 >= (int)u1)));
            r0.y ^= a0[u1 & 3u];
        } while (i1++ < 6u && (unsigned)((int)garr[i1 & 7u] < (int)(i1 + 3u)));
        i0 = (unsigned)(m0 == (unsigned)(unsigned char)(unsigned)((int)(i0 >> (0x79d18a45u & 31u)) < (int)(unsigned)w0)) & 15u;
    }
    i1 = ((0x80000000u % ((unsigned)(w0 >> 29) | 1u)) / (0x9d2b2816u | 1u)) & 15u;
    switch ((unsigned)((int)garr[i1 & 7u] < (int)g1) & 7u) {
        switch ((unsigned)(garr[u2 & 7u] || (5u - (unsigned)h1)) & 7u) {
            m0 ^= -(unsigned)((0x80000000u >> ((garr[u2 & 7u] & (unsigned)c1) & 31u)) == 0xb5cb84d2u);
            goto L1;
            for (;;) { if (--fuel == 0u) goto done;
                h0 = (short)(unsigned)(unsigned char)(u1 + ((unsigned)(w0 >> 29) ? (unsigned)(x0 >> 70) : i2));
                *q0 = ((unsigned)d0 >> ((r0.y & 8u) & 31u));
                case 5u: ;
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(unsigned)((int)0x108867e8u < (int)u1) << (5u & 63u);
                }
            }
            q0 = &garr[0x10000u & 7u];
            case 6u: ;
        }
        w0 = w0 * 6364136223846793005ull + (0xffffffffu / ((unsigned)(short)(garr[u2 & 7u] >> (0xe2fdf0a1u & 31u)) | 1u));
        d0 = d0 * 0.5 + (double)(((unsigned)((int)(4u / ((0x312009a1u ^ garr[u2 & 7u]) | 1u)) >= (int)u3) << ((unsigned)b0 & 31u)) & 1023u);
    }
    if ((unsigned)(unsigned char)((unsigned)h0 * g0)) goto L2;
    if (r0.x) goto L3;
    if ((unsigned)l0) {
        do { if (--fuel == 0u) goto done;
            garr[(unsigned)((int)3u < (int)(unsigned)h1) & 7u] = (v0 << ((unsigned)((int)u0 < (int)(unsigned)x0) & 31u));
            *q0 += (unsigned)d0;
            c1 = (signed char)(unsigned)((short)(unsigned)(unsigned char)((unsigned)(signed char)(unsigned)(0xe5dec898u && (g0 | (unsigned)b0)) & u1) > (signed char)fuel);
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)(unsigned)(unsigned char)((((unsigned)h0 ? 0x8c75154bu : garr[u2 & 7u]) ^ 9u) << ((unsigned)d0 & 31u));
                goto L1;
            }
            if (a0[i0 & 3u]) break;
        } while (i0++ < 5u && (unsigned)(0xb98bbf79u == a0[u1 & 3u]));
    } else {
        if ((7u & (unsigned)b0)) goto L1;
        if ((unsigned)(signed char)(a0[u1 & 3u] | 0xffffffffu)) {
            { unsigned t4; double z4; if ((((i1 << (u1 & 31u)) + u2)) & 1u) { t4 = (unsigned)((int)i2 >= (int)-(unsigned)((int)(unsigned)l0 < (int)i1)); z4 = (double)(((unsigned)w0) & 255u); } if ((((i1 << (u1 & 31u)) + u2)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                w0 ^= (unsigned long long)((unsigned)e0 + g1) << ((garr[i1 & 7u] + m0) & 63u);
            }
            if ((unsigned)(unsigned char)((unsigned)((short)(unsigned)b0 > (signed char)0x98410e4cu) % (g0 | 1u))) goto L4;
        }
        u3 += (unsigned)((unsigned)(0xd3bf40b6u == a0[u1 & 3u]) == m0);
        goto L3;
    }
    w0 ^= (unsigned long long)((unsigned)(w0 >> 29) * g0) << ((unsigned)((int)a0[u1 & 3u] < (int)i2) & 63u);
    if ((0xf20ccc2au / ((unsigned)(w0 >> 29) | 1u))) {
        l0 = (long)((unsigned long)l0 + r0.y);
        u2 ^= (unsigned)(signed char)((unsigned)(((unsigned)(w0 >> 29) | r0.y) || (unsigned)f0) | (unsigned)w0);
        if ((0x10000u / ((unsigned)x0 | 1u))) {
            i0 = (unsigned)(w0 >> 29) & 15u;
        }
        do { if (--fuel == 0u) goto done;
            *q0 += (unsigned)((unsigned)f0 == (unsigned)((short)((unsigned)h1 ? v0 : p0) > (signed char)u0));
            if (p0) break;
        } while (i0++ < 3u && (unsigned)((unsigned)x0 == 0xffffffffu));
        *mp = -(unsigned)((int)9u < (int)0x80000000u);
        do { if (--fuel == 0u) goto done;
            m0 ^= (0x10000u * ((unsigned)l0 << (0x80000000u & 31u)));
            h1 = (unsigned short)(h1 + garr[i1 & 7u]);
        } while (i0++ < 2u && 0xffffffffu);
    } else {
        while ((unsigned)l0) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (i0) break;
                switch ((unsigned)(v0 == (g0 & (unsigned)h1)) & 7u) {
                    w0 = w0 * 6364136223846793005ull + (unsigned)c1;
                    e0 = e0 * 0.5L + (long double)((fuel % ((unsigned)(signed char)(unsigned)((int)0x10000u >= (int)(unsigned)f0) | 1u)) & 1023u);
                    case 6u: ;
                    b0 = (unsigned)(unsigned char)((unsigned)(0x886b4097u == 3u) | (unsigned)x0) != 0u;
                }
                break; (void)(0x80000000u);
            }
            if (g1) goto L3;
            break; (void)((unsigned)(signed char)(u1 ^ -(unsigned)(4u && g1)));
            l0 = (long)((unsigned long)l0 + (0x81e32c74u + (unsigned)((int)0x10000u >= (int)(unsigned)(0xffffffffu == 0xce4219fdu))));
            u2 += (unsigned)((unsigned)f0 < (unsigned)((short)0x82b076aeu > (signed char)v0));
            break; (void)(((unsigned)(u0 || (unsigned)d0) << (0x7fffffffu & 31u)));
        }
        switch (((unsigned)w0 & p0) & 7u) {
            q0 = &garr[1u & 7u];
        }
        s1 = (int)((unsigned)s1 + (unsigned)((int)(a0[i0 & 3u] ^ (unsigned)h1) < (int)((unsigned)((int)(unsigned)b0 < (int)0x7fffffffu) % (*mp | 1u))));
    }
    if ((fuel >> ((unsigned)x0 & 31u))) goto L2;
    { unsigned t5; double z5; if (((unsigned)((int)((unsigned)b0 >> (0x80000000u & 31u)) < (int)0x80000000u)) & 1u) { t5 = 2u; z5 = (double)(((unsigned)((unsigned)c1 || 0x7fffffffu)) & 255u); } if (((unsigned)((int)((unsigned)b0 >> (0x80000000u & 31u)) < (int)0x80000000u)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        if ((0x80000000u >> ((unsigned)d0 & 31u))) goto done;
        if ((unsigned)!(v0 ^ (unsigned)(0xc5ad6051u || (unsigned)b0))) goto L1;
        if (((unsigned)((int)a0[u1 & 3u] < (int)garr[u2 & 7u]) - a0[u1 & 3u])) goto L4;
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((1u ^ 0u));
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)c0) goto L2;
            }
        }
        goto L4;
        if (i0) goto L2;
    }
    goto done;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (0xffffffffu) break;
        } while (i1++ < 4u && (unsigned)(w0 >> 29));
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((p1 ^ v0)) break;
        d0 = d0 * 0.5 + (double)((p1 >> ((unsigned)((int)0xff4b65cdu < (int)(a0[i0 & 3u] / ((g1 & p2) | 1u))) & 31u)) & 1023u);
        i2 = ((a0[i0 & 3u] ? 0x92338686u : 0xf56c08dau) * (unsigned)((short)(unsigned)h0 > (signed char)0xffffffffu)) & 15u;
        if ((unsigned)l0) break;
        switch ((p2 | (*q0 & p0)) & 7u) {
            a0[i1 & 3u] = ((0x10000u * (unsigned)d0) * garr[u2 & 7u]);
        }
        if ((0xdd3a0a2fu ? g1 : fuel)) {
            if (((2u & 0xe4c10442u) + (unsigned)d0)) break;
            if (((unsigned)c1 ? (unsigned)s0 : (unsigned)l0)) break;
            e0 = e0 * 0.5L + (long double)(a0[u1 & 3u] & 1023u);
            s0 = (int)(unsigned)(((unsigned)s0 ? 6u : 3u) && (unsigned)(w0 >> 29));
            if ((unsigned)(fuel && (unsigned)b0)) {
                if (((unsigned)((unsigned)(x0 >> 70) < a0[u1 & 3u]) & i1)) continue;
                *mp = 0x7fffffffu;
                if (0u) break;
                c1 = (signed char)(~(0xa0e518d0u % (v0 | 1u)) >> ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)p1) & 31u));
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    u1 ^= (unsigned)(x0 >> 70);
                    g0 = (unsigned)(unsigned char)(unsigned)(((unsigned)x0 & u0) < 0x7fffffffu);
                    i2 = (g1 << ((unsigned)((int)((unsigned)l0 ? 0u : i1) < (int)(unsigned)c1) & 31u)) & 15u;
                }
                m0 ^= (unsigned)(unsigned char)((unsigned)((short)i0 > (signed char)(unsigned)(0xd9bf3f48u && r0.y)) | ((unsigned)e0 * 4u));
            }
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L3;
    if ((unsigned)((int)~(unsigned)((unsigned)h1 || (unsigned)w0) >= (int)(unsigned)f0)) goto L1;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            a0[(unsigned)(g1 || p1) & 3u] = (((unsigned)d0 * 0u) & ((unsigned)(u0 == 1u) << (0u & 31u)));
            if (g0) {
                { unsigned t0; double z0; if (((5u % (garr[i1 & 7u] | 1u))) & 1u) { t0 = ((unsigned)((int)g1 >= (int)*mp) | 9u); z0 = (double)(((unsigned)((v0 ^ (unsigned)x0) && u2)) & 255u); } if (((5u % (garr[i1 & 7u] | 1u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(-(unsigned)(i2 == (6u % (0xb76f255cu | 1u))), ((unsigned)l0 % (p1 | 1u)), (unsigned)f0); }
                    *mp = p1;
                    { unsigned t1; double z1; if (((unsigned)(w0 >> 29)) & 1u) { t1 = u2; z1 = (double)((0x60111ac0u) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                        *q0 += (unsigned)(unsigned char)(unsigned)((unsigned)(w0 >> 29) < ((garr[i1 & 7u] ^ (0x7f8e379u + 6u)) / ((unsigned)s1 | 1u)));
                    }
                    do { if (--fuel == 0u) goto done;
                        *q0 = (garr[i1 & 7u] << ((m0 ^ (unsigned)e0) & 31u));
                        a0[(unsigned)(a0[u1 & 3u] < v0) & 3u] = (unsigned)((0x3dbfb6e1u ? *q0 : i2) < ((unsigned)s0 + 0xfdd09d5au));
                        while ((i0 & fuel)) { if (--fuel == 0u) goto done;
                            if ((unsigned)((int)i1 < (int)p0)) break;
                            if (0u) goto L3;
                            u3 += (0xae37fe0eu - m0);
                            h1 = (unsigned short)(h1 + *q0);
                        }
                        break; (void)((1u % ((unsigned)b0 | 1u)));
                        w0 ^= (unsigned long long)(unsigned)(g0 == 0x67cfa9e3u) << (((unsigned)(u0 || (0x80000000u ^ fuel)) & 0xfb7a9c7au) & 63u);
                        if ((0x80000000u + (u3 * (unsigned)s0))) continue;
                    } while (i2++ < 7u && (unsigned)((i1 - (unsigned)s1) && 0xfeec3174u));
                }
                if ((unsigned)((unsigned)e0 == g1)) {
                    d0 = d0 * 0.5 + (double)(0x80000000u & 1023u);
                    d0 = d0 * 0.5 + (double)(((unsigned)!((unsigned)(unsigned char)((unsigned)(w0 >> 29) ? g0 : (unsigned)e0) ^ (unsigned)w0) & *mp) & 1023u);
                } else {
                    if (budget != 0u) { budget -= 1u; u0 = fn0(-((0x80218448u | 0x273f8bc7u) << (0u & 31u)), 0x95daed27u, *mp); }
                }
                l0 = (long)((unsigned long)l0 + (3u >> (((unsigned)h1 ? (unsigned)(i0 || 0x8a137fb6u) : u0) & 31u)));
                switch ((unsigned)(unsigned char)(unsigned)((int)0xea39e9ffu >= (int)(unsigned)s1) & 7u) {
                    L0: if (--fuel == 0u) goto done;
                }
                if ((garr[i1 & 7u] - (unsigned)((short)p0 > (signed char)(unsigned)h0))) break;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(x0 >> 70), (g1 << ((unsigned)c1 & 31u)), (unsigned)(unsigned char)(((unsigned)x0 | (unsigned)s1) * 0u)); }
            } else {
                continue; (void)((i2 + (i0 ^ 0x10000u)));
                garr[(i2 % (0x9c8c6207u | 1u)) & 7u] = ((unsigned)c1 ? 0x80000000u : (unsigned)s1);
                { unsigned t2; double z2; if ((i1) & 1u) { t2 = (unsigned)h1; z2 = (double)(((unsigned)((int)0x7fffffffu < (int)(unsigned)c0)) & 255u); } if ((i1) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    *mp = ((unsigned)(*mp && 0x24ec4181u) | (unsigned)(u0 || (unsigned)s0));
                    if (7u) goto L0;
                    r0.y ^= ~(0x80000000u & (p2 ? 0x10000u : i1));
                }
                if ((u0 << ((garr[u2 & 7u] - 0xb92389efu) & 31u))) continue;
            }
            a0[((unsigned)l0 / ((unsigned)f0 | 1u)) & 3u] = (((0x7fffffffu >> ((unsigned)s0 & 31u)) >> (i2 & 31u)) - 0x80000000u);
        }
        if ((unsigned)(0xa93503c9u < (unsigned)h1)) goto L2;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t3; double z3; if (((-(g0 / (0x6b576cc1u | 1u)) >> ((unsigned)h0 & 31u))) & 1u) { t3 = (unsigned)b0; z3 = (double)((((unsigned)((int)(unsigned)d0 < (int)0xffffffffu) >> (0x7fffffffu & 31u))) & 255u); } if (((-(g0 / (0x6b576cc1u | 1u)) >> ((unsigned)h0 & 31u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                if ((unsigned)(2u < (i2 >> (0x928ba7e6u & 31u)))) break;
                { unsigned t4; double z4; if (((unsigned)w0) & 1u) { t4 = 0xffffffffu; z4 = (double)((u2) & 255u); } if (((unsigned)w0) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                    if ((unsigned)(i2 && (unsigned)s1)) {
                        a0[(unsigned)((short)u0 > (signed char)0x46df8838u) & 3u] = (((unsigned)(unsigned char)((unsigned)b0 - u1) - ((unsigned)b0 + 0x201d4ea7u)) - garr[i1 & 7u]);
                        w0 = w0 * 6364136223846793005ull + (unsigned)(short)(unsigned)(0x10000u || p2);
                        L1: if (--fuel == 0u) goto done;
                    }
                    L2: if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                    a0[(unsigned)((unsigned)e0 || (unsigned)h0) & 3u] = (unsigned)(w0 >> 29);
                    if ((unsigned)((int)(unsigned)(x0 >> 70) < (int)0x7fffffffu)) break;
                    if (i2) break;
                }
                s1 = (int)((unsigned)s1 + ((((unsigned)w0 & i0) << (v0 & 31u)) ^ a0[i0 & 3u]));
            }
            if (-(1u ? 0x10000u : u2)) break;
        }
        f0 = f0 * 0.5f + (float)((unsigned)w0 & 255u);
    }
    e0 = e0 * 0.5L + (long double)(((0xffffffffu ? r0.y : (unsigned)((int)u1 < (int)(unsigned)w0)) / (0xd30c4aabu | 1u)) & 1023u);
    *q0 = (unsigned)((short)(((p2 % (r0.y | 1u)) % (1u | 1u)) - 0xc507829u) > (signed char)(unsigned)h0);
    if ((0x10000u - g0)) {
        goto L4;
        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((int)(r0.y % ((unsigned)(w0 >> 29) | 1u)) >= (int)p1) < (v0 & 0x10000u)));
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(signed char)(0x80000000u % (u1 | 1u)), ((unsigned)w0 / ((unsigned)h0 | 1u)), (unsigned)(x0 >> 70)); }
        b0 = (p2 & (u1 % ((unsigned)(signed char)(2u | fuel) | 1u))) != 0u;
    }
    goto done;
    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(short)(2u | 7u) || (unsigned)(w0 >> 29)));
    if ((unsigned)((int)(unsigned)(0u && 0x1fbc50dau) < (int)(unsigned)h1)) goto L3;
    if ((unsigned)(short)(0xde28eb6cu | 0xb3377dfbu)) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(u2);
        }
        { unsigned t5; double z5; if (((unsigned)(v0 == 6u)) & 1u) { t5 = (unsigned)w0; z5 = (double)((p2) & 255u); } if (((unsigned)(v0 == 6u)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            *q0 += (unsigned)(unsigned char)(0x10000u * (unsigned)(short)(unsigned)(1u == 7u));
            L4: if (--fuel == 0u) goto done;
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)((short)u0 > (signed char)g0) | (unsigned)l0)) break;
            continue; (void)(u0);
            if ((unsigned)e0) break;
            g1 += u3;
        }
    }
    g0 = (r0.x >> ((unsigned)((int)7u >= (int)a0[i0 & 3u]) & 31u));
    if (((unsigned)c0 / (fuel | 1u))) goto L4;
    if (i1) goto L2;
    d0 = d0 * 0.5 + (double)((0xee3e4388u & m0) & 1023u);
    goto L0;
    if (((unsigned)s0 & ((unsigned)b0 & i1))) goto L3;
    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)c0 * (unsigned)!(0x80000000u & p1)), ((unsigned)((int)(unsigned)(x0 >> 70) < (int)4u) << ((unsigned)(w0 >> 29) & 31u)), i2); }
    r0.x = ((unsigned)c0 + 0x7fffffffu);
    d0 = d0 * 0.5 + (double)((unsigned)((int)((unsigned)w0 - ((unsigned)(x0 >> 70) >> (m0 & 31u))) >= (int)0xffffffffu) & 1023u);
    w0 = w0 * 6364136223846793005ull + *q0;
    goto L3;
    if ((unsigned)s0) goto L1;
    if ((unsigned)(0x7fffffffu || (unsigned)((short)0x7fffffffu > (signed char)0x80000000u))) goto L4;
    for (;;) { if (--fuel == 0u) goto done;
        goto L2;
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0(g1, (0x10000u * p0), r0.x); }
            if ((unsigned)((int)(unsigned)x0 < (int)garr[u2 & 7u])) break;
        }
        do { if (--fuel == 0u) goto done;
            g0 = (unsigned)(7u || (unsigned)(signed char)(i0 * 0x10000u));
            w0 ^= (unsigned long long)((unsigned)h1 & *q0) << ((unsigned)h1 & 63u);
            if ((unsigned)(p2 < (unsigned)d0)) {
                while (i2++ < 3u && (i1 | (unsigned)(unsigned char)(0xb980ae82u + (unsigned)e0))) { if (--fuel == 0u) goto done;
                    u2 = ((unsigned)s0 / (g1 | 1u));
                    r0.x = (0x80000000u >> ((unsigned)b0 & 31u));
                    *q0 = ((unsigned)h0 % ((unsigned)((unsigned)((unsigned)c1 == (unsigned)b0) || (unsigned)((int)0xfe2651f1u >= (int)v0)) | 1u));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((0x46c2cd99u ? u1 : g1), (unsigned)c0, -(unsigned)(a0[i0 & 3u] < fuel)); }
                    s1 = (int)((unsigned)s1 + (a0[i0 & 3u] / ((unsigned)(0x8b58e4dau || (unsigned)(0x5fe86c80u == (unsigned)(signed char)(unsigned)(0x450fe16du && u2))) | 1u)));
                }
            } else {
                *q0 += (unsigned)((short)i0 > (signed char)0u);
                a0[(unsigned)((int)i1 >= (int)u1) & 3u] = (8u % (p0 | 1u));
                break; (void)(((i0 * (unsigned)c0) ^ *mp));
                a0[(unsigned)(short)(*mp << ((unsigned)l0 & 31u)) & 3u] = g0;
            }
            if ((unsigned)((short)(unsigned)x0 > (signed char)(7u / (7u | 1u)))) {
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)((unsigned)((p1 >> (0x5a93540eu & 31u)) || ((3u + 0x405d9114u) ^ 0x7fffffffu)) & 255u);
                        r0.x = (unsigned)((unsigned)((unsigned)(w0 >> 29) == p2) && (unsigned)(a0[u1 & 3u] == (u3 >> (1u & 31u))));
                        c0 = (unsigned char)(0xf1128299u << ((unsigned)x0 & 31u));
                        u0 += (unsigned)((unsigned)(u2 && a0[u1 & 3u]) == 0x5b4a1c75u);
                        u3 = u3 * 0x9e3779b1u + ((unsigned)(0u == i0) + ((r0.y * a0[u1 & 3u]) * (unsigned)c0));
                        if ((unsigned)!((unsigned)e0 % (u0 | 1u))) {
                            s1 = (int)((unsigned)s1 + (unsigned)((short)(a0[i0 & 3u] ^ (unsigned)l0) > (signed char)a0[i0 & 3u]));
                            if (0xffffffffu) break;
                        } else {
                            if ((i2 * (unsigned)s1)) break;
                        }
                    }
                    s1 = (int)((unsigned)s1 + ((unsigned)((0x78c038d8u - (unsigned)s0) || 0xa8b5d0d3u) | *mp));
                    c1 = (signed char)((unsigned)c1 + 1u);
                    while (((unsigned)e0 >> ((unsigned)l0 & 31u))) { if (--fuel == 0u) goto done;
                        u2 ^= (unsigned)((int)((unsigned)(u1 < (unsigned)(x0 >> 70)) >> ((unsigned)(r0.y < 0xffffffffu) & 31u)) >= (int)garr[i1 & 7u]);
                        if ((unsigned)((int)(p0 << (g1 & 31u)) >= (int)i0)) break;
                        if ((g0 ^ i0)) break;
                        r0.y ^= u2;
                    }
                }
            }
        } while (i1++ < 6u && m0);
        break; (void)((unsigned)h1);
    }
    if ((unsigned)((unsigned)(0x10000u == r0.y) < (unsigned)d0)) goto L3;
    garr[(unsigned)b0 & 7u] = 0xffffffffu;
    if (budget != 0u) { budget -= 1u; u3 = fn0(*mp, g1, (unsigned)((short)(unsigned)s0 > (signed char)0xf19f289du)); }
    switch ((0x10000u << (0x7fffffffu & 31u)) & 7u) {
        if (5u) {
            break; (void)((0x80000000u ^ (p0 * 0x10000u)));
            if ((u2 & a0[u1 & 3u])) {
                x0 = x0 * 0x100000001b3ull + (g1 * 0xef816331u);
                *q0 = (unsigned)h0;
                case 2u: ;
            }
            w0 ^= (unsigned long long)(unsigned)(a0[i0 & 3u] == u3) << ((fuel & *mp) & 63u);
            l0 = (long)((unsigned long)l0 + (unsigned)((short)(a0[u1 & 3u] | 0x9b71456u) > (signed char)(unsigned)(short)(unsigned)((int)0xbe39c816u >= (int)0x50b9472u)));
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn0(r0.y, i0, u1); }
            if ((unsigned)e0) break;
            if (budget != 0u) { budget -= 1u; u1 = fn0((*q0 + 0xffffffffu), 0x106d5b59u, (unsigned)((int)3u >= (int)r0.x)); }
            x0 = x0 * 0x100000001b3ull + u3;
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t6; double z6; if ((i0) & 1u) { t6 = (unsigned)((int)(unsigned)(w0 >> 29) >= (int)fuel); z6 = (double)((0x7fffffffu) & 255u); } if ((i0) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                u0 += (unsigned)((int)u2 < (int)u3);
                garr[(0xb45f3a6au / (u2 | 1u)) & 7u] = (unsigned)(v0 < 0xe33060ecu);
                case 1u: ;
                l0 = (long)((unsigned long)l0 + ((unsigned)e0 ? u2 : (unsigned)s0));
                m0 ^= (unsigned)d0;
            }
            if (~(unsigned)((int)0x10000u < (int)(2u + 0x23a2f113u))) {
                a0[(unsigned)((int)r0.x < (int)0xffffffffu) & 3u] = (unsigned)(w0 >> 29);
                b0 = ((unsigned)(short)(unsigned)(p2 == (unsigned)b0) >> (-(unsigned)(8u < 0x80000000u) & 31u)) != 0u;
                do { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        m0 ^= (unsigned)(x0 >> 70);
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((int)i1 >= (int)3u) >> (garr[u2 & 7u] & 31u)), 6u, ((unsigned)(*q0 && a0[i0 & 3u]) % (fuel | 1u))); }
                    { unsigned t7; double z7; if ((fuel) & 1u) { t7 = -(unsigned)((int)garr[u2 & 7u] >= (int)a0[u1 & 3u]); z7 = (double)(((unsigned)(9u && (0x10000u + garr[i1 & 7u]))) & 255u); } if ((fuel) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)c1 == ((unsigned)((int)u2 < (int)u3) << ((unsigned)(w0 >> 29) & 31u))) & 255u);
                        while (i2++ < 6u && (unsigned)((unsigned)e0 == (0x80000000u ^ *q0))) { if (--fuel == 0u) goto done;
                            default: ;
                            case 4u: ;
                        }
                        for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                            v0 = ((v0 & u3) | ((unsigned)e0 ? (unsigned)e0 : u0));
                            u0 ^= (unsigned)((short)(u0 >> ((unsigned)x0 & 31u)) > (signed char)a0[i0 & 3u]);
                        }
                        s0 = (int)p2;
                        a0[*q0 & 3u] = (unsigned)((unsigned)((unsigned)h1 == (unsigned)((unsigned)(m0 < i0) == 0x10000u)) && r0.x);
                    }
                    *q0 += 0x7fffffffu;
                    u3 ^= (garr[u2 & 7u] ? u3 : (unsigned)((int)(v0 >> (p1 & 31u)) >= (int)0xc945cb5fu));
                    break;
                } while (i1++ < 2u && fuel);
                if (((unsigned)b0 / ((unsigned)(u3 || (unsigned)h0) | 1u))) goto L0;
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    q0 = &garr[((((p0 >> (0x2ec50da0u & 31u)) >> ((unsigned)h1 & 31u)) / (i0 | 1u)) * 0x6683397du) & 7u];
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)s1 || (v0 << (a0[u1 & 3u] & 31u))));
                    break; (void)((0x70fd264au - (0x7fffffffu % (r0.x | 1u))));
                    r0.x = u3;
                    h1 = (unsigned short)(h1 + m0);
                }
                break;
            } else {
                c0 = (unsigned char)(unsigned)((short)-(a0[u1 & 3u] ? u2 : garr[i1 & 7u]) > (signed char)0x40c981beu);
                continue; (void)((unsigned)(x0 >> 70));
                a0[(0x80000000u % (8u | 1u)) & 3u] = (u1 ^ i1);
            }
            i0 = (0x8f6f9f1du + 0x4a49b3u) & 15u;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= (garr[u2 & 7u] * (unsigned)(v0 && (unsigned)(*q0 < p0)));
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((i2 ? m0 : m0), ((unsigned)((int)g0 < (int)garr[i1 & 7u]) / ((unsigned)d0 | 1u)), (unsigned)(u3 == u2)); }
        }
        for (;;) { if (--fuel == 0u) goto done;
            case 5u: ;
            w0 = w0 * 6364136223846793005ull + p0;
        }
    }
    goto L3;
    if (((unsigned)l0 >> (i1 & 31u))) goto L4;
    e0 = e0 * 0.5L + (long double)((unsigned)(0x415efc94u < 0x10000u) & 1023u);
    if ((unsigned)((unsigned)b0 && (9u * g0))) goto L3;
    if (((unsigned)(signed char)(unsigned)((short)u0 > (signed char)i0) - (unsigned)f0)) goto L4;
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(signed char)(unsigned)((unsigned)c1 && (unsigned)c1), (unsigned)h0, (unsigned)f0); }
    w0 = w0 * 6364136223846793005ull + p0;
    f0 = f0 * 0.5f + (float)((unsigned)((int)garr[i1 & 7u] < (int)(unsigned)(u3 < (unsigned)((short)(unsigned)!(r0.x - (unsigned)h1) > (signed char)u3))) & 255u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(x0 >> 70)) goto L3;
    if ((0x7fffffffu & (unsigned)x0)) goto L4;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if ((u3 | i0)) break;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)(w0 >> 29) | (unsigned)(short)(unsigned)(p2 || u1))) break;
                { unsigned t0; double z0; if ((i2) & 1u) { t0 = 0x615381bbu; z0 = (double)(((unsigned)s0) & 255u); } if ((i2) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                    if (((i1 >> ((unsigned)(w0 >> 29) & 31u)) - (unsigned)x0)) {
                        d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)((int)v0 >= (int)i2) - 0x8b1b3b16u) == ((unsigned)h1 ^ (unsigned)h1)) & 1023u);
                    } else {
                        while (i0++ < 6u && (unsigned)(g1 == (unsigned)((unsigned)w0 < (unsigned)(x0 >> 70)))) { if (--fuel == 0u) goto done;
                            d0 = d0 * 0.5 + (double)((u1 % ((unsigned)(v0 && fuel) | 1u)) & 1023u);
                        }
                        if (budget != 0u) { budget -= 1u; u1 = fn0(~(garr[i1 & 7u] % (p1 | 1u)), (9u % (0x10000u | 1u)), ((unsigned)s0 + a0[u1 & 3u])); }
                    }
                    if (r0.x) continue;
                    g1 += (unsigned)!((unsigned)(p2 || 0x80000000u) & *q0);
                    w0 ^= (unsigned long long)0x80000000u << (u1 & 63u);
                }
                continue; (void)((unsigned)((m0 % ((unsigned)w0 | 1u)) || (unsigned)l0));
                f0 = f0 * 0.5f + (float)((unsigned)c1 & 255u);
                { unsigned t1; double z1; if ((garr[u2 & 7u]) & 1u) { t1 = 0xc476be48u; z1 = (double)(((0x2af695ecu ^ 0xffffffffu)) & 255u); } if ((garr[u2 & 7u]) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    h1 = (unsigned short)(h1 + 3u);
                    do { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + garr[u2 & 7u]);
                        x0 = x0 * 0x100000001b3ull + ((unsigned)c0 ^ (unsigned)(0u || (unsigned)s0));
                        if ((unsigned)e0) break;
                        b0 = (unsigned)(0x80000000u || (unsigned)(garr[i1 & 7u] == (a0[i0 & 3u] ? (unsigned)h1 : a0[i0 & 3u]))) != 0u;
                    } while (i0++ < 3u && (unsigned)((unsigned)(0x80000000u == 0xbd2907e1u) || 1u));
                    s0 = (int)((unsigned)s1 * (unsigned)c1);
                    goto L1;
                    if ((unsigned)d0) break;
                    u1 = 0x80000000u;
                }
            }
            switch (i2 & 7u) {
                if (v0) continue;
                v0 = (unsigned)s1;
            }
            do { if (--fuel == 0u) goto done;
                v0 = 0x56591407u;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)(r0.y ^ (unsigned)w0), (unsigned)(((unsigned)c0 - (unsigned)c1) && 0xb33360e6u), (1u & (unsigned)(u2 || 0x10000u))); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0(0x32e3196bu, (unsigned)(short)((i1 << (m0 & 31u)) | v0), (u3 ^ *mp)); }
                    goto done;
                } while (i0++ < 5u && (unsigned)s1);
                if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)s0 * (unsigned)((int)r0.x >= (int)5u)), (unsigned)(unsigned char)((unsigned)((unsigned)(x0 >> 70) < 0x677627adu) + (unsigned)l0), 0x10000u); }
                L0: if (--fuel == 0u) goto done;
            } while (i2++ < 2u && 0x5556c31u);
        } while (i1++ < 4u && (unsigned)b0);
        a0[(unsigned)((int)g1 >= (int)0x7e7ff1cfu) & 3u] = (unsigned)((short)(unsigned)((int)(r0.y - r0.x) < (int)1u) > (signed char)g1);
        do { if (--fuel == 0u) goto done;
            if ((r0.x | (r0.x | 0xefe26209u))) break;
            if ((unsigned)((int)9u < (int)u0)) {
                if ((p0 << (u0 & 31u))) continue;
                if (garr[u2 & 7u]) {
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)((int)u0 < (int)(unsigned)c1) & 0x9a93a7f6u), (0x7817f64eu | p0), (unsigned)((int)4u < (int)0xbc11b50eu)); }
                    if ((1u ^ (unsigned)(p1 == fuel))) break;
                } else {
                    v0 = (p2 ? (unsigned)((int)i0 >= (int)u3) : (u0 - (unsigned)l0));
                }
                s0 = (int)(unsigned)((int)(0x9cbab82u % (((a0[i0 & 3u] % (u0 | 1u)) >> ((unsigned)(w0 >> 29) & 31u)) | 1u)) < (int)0x10000u);
                break; (void)((unsigned)(signed char)(unsigned)((short)((unsigned)s0 - v0) > (signed char)fuel));
            } else {
                u0 = u0 * 0x9e3779b1u + (m0 * (unsigned)((short)(unsigned)((int)(unsigned)l0 < (int)(unsigned)d0) > (signed char)(unsigned)x0));
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)b0, ((3u ^ p2) * g0), (unsigned)(r0.y < (unsigned)h1)); }
            }
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    u2 += 0u;
                } while (i0++ < 4u && (p0 % ((unsigned)((int)m0 < (int)r0.x) | 1u)));
            }
            if (0x80000000u) break;
            continue; (void)(~(unsigned)(0xda3c3d9cu || (unsigned)(short)(0x7fffffffu ^ 2u)));
            switch (v0 & 7u) {
                { unsigned t2; double z2; if ((0x7fffffffu) & 1u) { t2 = 0x80000000u; z2 = (double)(((*q0 & a0[i0 & 3u])) & 255u); } if ((0x7fffffffu) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    case 3u: ;
                    while (i2++ < 7u && ~(unsigned)(a0[u1 & 3u] || a0[i0 & 3u])) { if (--fuel == 0u) goto done;
                        a0[g1 & 3u] = (i2 - (unsigned)(u1 < (unsigned)h1));
                        u1 ^= (p2 ^ (5u - 0x10000u));
                        if ((unsigned)((unsigned)h1 == (unsigned)((int)2u >= (int)r0.y))) continue;
                        garr[(unsigned)(0x2f3f094du || i2) & 7u] = 0x80000000u;
                        switch (0x90061f21u & 7u) {
                            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(short)(unsigned)((int)4u >= (int)r0.x), 4u, 0u); }
                            s1 = (int)((unsigned)s1 + ((u2 % ((unsigned)((short)0x80000000u > (signed char)a0[i0 & 3u]) | 1u)) ^ (unsigned)(x0 >> 70)));
                        }
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn1(3u, i1, (((unsigned)h0 % ((unsigned)e0 | 1u)) + (unsigned)h0)); }
                    L1: if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        u2 ^= (unsigned)(((unsigned)h0 << ((unsigned)((unsigned)(w0 >> 29) == (unsigned)l0) & 31u)) || ((unsigned)c0 ^ 0xffffffffu));
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)h1, v0, (unsigned)((unsigned)s1 == *mp)); }
                        w0 = w0 * 6364136223846793005ull + r0.x;
                        if ((p2 | fuel)) {
                            u3 = (unsigned)(((unsigned)(garr[u2 & 7u] || v0) << (i2 & 31u)) && *q0);
                            case 5u: ;
                        }
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x7c5784a9u < (unsigned)(short)(unsigned)((int)garr[u2 & 7u] >= (int)0xd047c02au)), (unsigned)(x0 >> 70), ((unsigned)f0 * 0xfd40e800u)); }
                }
                if ((1u << ((i0 << (*q0 & 31u)) & 31u))) goto L1;
                w0 = w0 * 6364136223846793005ull + (0xc7ea8e0eu >> (((g0 - u0) & (i0 % (0xfd124adcu | 1u))) & 31u));
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)f0 < (int)(unsigned)(short)(unsigned)((u1 & (unsigned)f0) < (unsigned)((unsigned)(w0 >> 29) < (unsigned)d0)));
                h1 = (unsigned short)(h1 + (m0 >> ((unsigned)((short)3u > (signed char)*mp) & 31u)));
                if ((unsigned)((unsigned)s1 && ((unsigned)c0 / ((unsigned)h1 | 1u)))) break;
            }
        } while (i1++ < 4u && (9u + a0[i0 & 3u]));
        c1 = (signed char)(unsigned)((int)g1 < (int)(unsigned)(0x7fffffffu == (unsigned)(i2 && (unsigned)b0)));
        b0 = ((p0 / (~(unsigned)(7u < 0xa7267fcu) | 1u)) + (unsigned)((short)*mp > (signed char)fuel)) != 0u;
    }
    if (((v0 & 0xffffffffu) - fuel)) goto L1;
    if (((9u | (unsigned)w0) - *q0)) goto L3;
    e0 = e0 * 0.5L + (long double)((unsigned)(0x7fffffffu == (unsigned)x0) & 1023u);
    do { if (--fuel == 0u) goto done;
        c1 = (signed char)r0.y;
    } while (i0++ < 6u && 0x7fffffffu);
    if ((unsigned)(a0[i0 & 3u] || (unsigned)(signed char)((unsigned)e0 + 0xffffffffu))) {
        if ((unsigned)((unsigned)s0 && (unsigned)(fuel || 0x10000u))) goto L4;
        while (i0++ < 2u && (p1 | 8u)) { if (--fuel == 0u) goto done;
            if ((unsigned)(short)((unsigned)((int)0x7fffffffu < (int)garr[i1 & 7u]) % (2u | 1u))) goto L0;
            if (fuel < 8u) return ~(unsigned)((int)0x11ac8b33u < (int)(unsigned)w0);
        }
        if (u3) {
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)h1 % ((unsigned)(w0 >> 29) | 1u))) break;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    continue; (void)((0x96b382d4u ^ 0x10000u));
                    if (u3 == 7u) return (unsigned)((int)-((unsigned)((int)0x52043736u >= (int)(unsigned)f0) << (g1 & 31u)) >= (int)(unsigned)(0x10000u && v0));
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        L2: if (--fuel == 0u) goto done;
                        u3 ^= ((*mp / ((0x7fffffffu + 0x80000000u) | 1u)) >> ((unsigned)((int)9u >= (int)a0[u1 & 3u]) & 31u));
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(g1 || (unsigned)f0), (unsigned)!(unsigned)((unsigned)(x0 >> 70) == 0x10000u), (unsigned)s0); }
                    u1 = u3;
                }
                if ((unsigned)(g0 || (unsigned)(3u < 0x80000000u))) break;
                { unsigned t3; double z3; if ((((unsigned)c1 >> (r0.y & 31u))) & 1u) { t3 = (9u & -(unsigned)(v0 < (unsigned)x0)); z3 = (double)(((unsigned)e0) & 255u); } if ((((unsigned)c1 >> (r0.y & 31u))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    continue; (void)((unsigned)((short)u3 > (signed char)0x10000u));
                    if ((garr[i1 & 7u] - (fuel * *mp))) break;
                    d0 = d0 * 0.5 + (double)((r0.x | (*mp | i1)) & 1023u);
                    u3 ^= (unsigned)((unsigned)(0xffffffffu < ((unsigned)(short)(0x80000000u / ((unsigned)e0 | 1u)) >> (g0 & 31u))) < garr[i1 & 7u]);
                }
                l0 = (long)((unsigned long)l0 + (unsigned)(u0 && 8u));
                w0 ^= (unsigned long long)g1 << ((unsigned)!(unsigned)(i1 || 0x425aa138u) & 63u);
            }
            m0 ^= (unsigned)c0;
            h0 = (short)(fuel >> (u3 & 31u));
            if ((p1 % ((0xffffffffu * (unsigned)h1) | 1u))) goto done;
        }
        garr[(r0.y * 0x80000000u) & 7u] = 0x6adaa228u;
        do { if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
            c1 = (signed char)((unsigned)c1 % ((unsigned)c1 | 1u));
            u0 += (0xbb1dd18eu + ((unsigned)((int)(unsigned)(u2 || garr[u2 & 7u]) >= (int)*q0) >> (0x5098e258u & 31u)));
            { unsigned t4; double z4; if ((((unsigned)e0 - (unsigned)x0)) & 1u) { t4 = (unsigned)(((unsigned)(x0 >> 70) >> (*mp & 31u)) == garr[i1 & 7u]); z4 = (double)(((unsigned)((int)u1 < (int)0x80000000u)) & 255u); } if ((((unsigned)e0 - (unsigned)x0)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                while (i1++ < 6u && (garr[u2 & 7u] | garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((0xffffffffu | 0x10000u) == 0x113d5e1u), (unsigned)!(unsigned)((int)(unsigned)s1 >= (int)(unsigned)((unsigned)e0 || i1)), (a0[u1 & 3u] - (unsigned)h0)); }
                    for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        r0.y ^= (0x80000000u << (~(unsigned)(r0.y || p2) & 31u));
                    }
                    L4: if (--fuel == 0u) goto done;
                    if ((((unsigned)h1 >> ((unsigned)l0 & 31u)) | 0x7fffffffu)) continue;
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(garr[u2 & 7u], (unsigned)((short)*q0 > (signed char)(0x5c2d120cu | (unsigned)b0)), (unsigned)(signed char)(i1 + p1)); }
                        s0 = (int)(unsigned)((int)(unsigned)l0 >= (int)((unsigned)f0 / (2u | 1u)));
                        if ((garr[i1 & 7u] >> ((unsigned)h1 & 31u))) continue;
                        goto L3;
                        break; (void)((unsigned)(signed char)((unsigned)(x0 >> 70) + u2));
                        m0 ^= (unsigned)!(unsigned)((short)(u1 * (unsigned)c1) > (signed char)((unsigned)s1 >> ((unsigned)((unsigned)c1 < (unsigned)d0) & 31u)));
                    }
                }
                if ((unsigned)e0) goto L3;
                if (((unsigned)((unsigned)c1 && (unsigned)x0) << (p1 & 31u))) goto L4;
                s1 = (int)((unsigned)s1 + (unsigned)((int)9u >= (int)(unsigned)x0));
            }
        } while (i0++ < 2u && (unsigned)((int)0x3d83dcd0u >= (int)8u));
        { unsigned t5; double z5; if (((unsigned)((0x80000000u - (unsigned)h0) || 0x10000u)) & 1u) { t5 = (unsigned)(*mp == (i2 >> (i2 & 31u))); z5 = (double)(((unsigned)((int)0x1d33b537u >= (int)(unsigned)((int)u2 < (int)u2))) & 255u); } if (((unsigned)((0x80000000u - (unsigned)h0) || 0x10000u)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            u0 ^= (2u * *mp);
        }
    }
    do { if (--fuel == 0u) goto done;
        u1 = (unsigned)((unsigned)((int)p2 < (int)m0) == (garr[u2 & 7u] + (unsigned)x0));
        for (;;) { if (--fuel == 0u) goto done;
            if (1u) {
                while (((unsigned)(x0 >> 70) / (g0 | 1u))) { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)(g0 && (unsigned)((int)garr[i1 & 7u] < (int)(unsigned)(-(unsigned)(u1 || r0.y) && (unsigned)h1)));
                    if ((unsigned)((r0.y ^ p1) == p2)) goto done;
                    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        a0[(unsigned)((unsigned)e0 || 0xc9f94d99u) & 3u] = (unsigned)s0;
                        if ((unsigned)(0x80000000u == (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)w0))) break;
                        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                            m0 ^= ((r0.y >> (a0[u1 & 3u] & 31u)) | m0);
                            if (u3 == 7u) return *mp;
                            break; (void)(m0);
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(u3 || (unsigned)(signed char)(unsigned)(0u || (unsigned)d0)), (0x21ee859du + 0x725ba55au), ((unsigned)(r0.y && r0.y) | 0xcef04e49u)); }
                            g1 += ((a0[u1 & 3u] - (0x80000000u ? garr[i1 & 7u] : v0)) << (i1 & 31u));
                            u2 += (unsigned)(*q0 == (u2 / ((unsigned)(w0 >> 29) | 1u)));
                        }
                        break; (void)((unsigned)s0);
                    }
                    g0 = ((m0 / (0x2f7296b4u | 1u)) - (unsigned)((g1 >> ((unsigned)(w0 >> 29) & 31u)) || (unsigned)(x0 >> 70)));
                    if ((unsigned)l0) continue;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)(0x80000000u ^ (unsigned)c1), (unsigned)(0x43763695u == (unsigned)l0), ((unsigned)(short)(unsigned)((unsigned)h1 == garr[u2 & 7u]) - (unsigned)c0)); }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)(unsigned)((int)0x95bf01bau >= (int)r0.y) < (int)0x10000u), (unsigned)(7u || 9u), (unsigned)((unsigned)((unsigned)e0 || 0xffffffffu) || 1u)); }
                u2 = u2 * 0x9e3779b1u + (0x66abea80u / ((0x80000000u ^ (unsigned)(short)(unsigned)((int)*q0 < (int)4u)) | 1u));
                h0 = (short)(unsigned)((int)((m0 << (p0 & 31u)) - p0) >= (int)(p1 % (*mp | 1u)));
                do { if (--fuel == 0u) goto done;
                    r0.x = (i1 / ((0xffffffffu * *mp) | 1u));
                    if (i0) break;
                    h1 = (unsigned short)(h1 + (unsigned)(fuel < (i0 & ((unsigned)!(7u % ((unsigned)x0 | 1u)) << (0xffffffffu & 31u)))));
                } while (i2++ < 5u && (p0 * 0xffffffffu));
            }
            s1 = (int)((unsigned)s1 + (unsigned)c0);
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(u0 == (unsigned)l0), (6u ^ (garr[i1 & 7u] & fuel)), ((unsigned)l0 << ((unsigned)((int)(unsigned)b0 < (int)(unsigned)e0) & 31u))); }
            r0.y ^= ((unsigned)h1 ^ (unsigned)((u0 ^ 0x80000000u) == 0xff6f5d87u));
            s0 = (int)((0xafe5ac44u >> (1u & 31u)) - 0xffffffffu);
            if (budget != 0u) { budget -= 1u; u3 = fn0(garr[u2 & 7u], (unsigned)b0, (unsigned)(signed char)(unsigned)((int)(4u / (0x10000u | 1u)) >= (int)garr[i1 & 7u])); }
        }
    } while (i0++ < 6u && *q0);
    a0[((unsigned)d0 * (unsigned)b0) & 3u] = ((unsigned)((unsigned)((int)m0 >= (int)garr[u2 & 7u]) == (unsigned)(w0 >> 29)) >> (g0 & 31u));
    *q0 += ((0xbd151832u + (unsigned)h0) + ((unsigned)h0 >> (*q0 & 31u)));
    goto L2;
    if (0xa5e5842cu) goto L0;
    { unsigned t6; double z6; if (((unsigned)(4u || a0[i0 & 3u])) & 1u) { t6 = ((u2 ^ 4u) / ((unsigned)x0 | 1u)); z6 = (double)((((unsigned)f0 << (0xb7ffbc20u & 31u))) & 255u); } if (((unsigned)(4u || a0[i0 & 3u])) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        switch (~(unsigned)((unsigned)!(unsigned)((short)g0 > (signed char)(unsigned)w0) || v0) & 7u) {
            case 0u: ;
            i0 = 0x7fffffffu & 15u;
            switch (v0 & 7u) {
                e0 = e0 * 0.5L + (long double)((unsigned)(0x10000u || (v0 - r0.y)) & 1023u);
                s0 = (int)fuel;
            }
            c0 = (unsigned char)p1;
            case 4u: ;
        }
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)l0) break;
            if ((*mp >> (0x80000000u & 31u))) continue;
            *mp = (unsigned)((int)(v0 - (unsigned)h1) < (int)(unsigned)h1);
            h0 = (short)*mp;
            v0 = (unsigned)((unsigned)e0 && 0x80000000u);
            m0 ^= ((unsigned)h0 ? (*q0 & (unsigned)s0) : 4u);
        }
        { unsigned t7; double z7; if (((((unsigned)c0 << ((unsigned)c0 & 31u)) >> (a0[u1 & 3u] & 31u))) & 1u) { t7 = ((unsigned)s0 >> (((unsigned)s1 - 0xe6a0f071u) & 31u)); z7 = (double)(((*q0 / ((unsigned)(p0 || a0[i0 & 3u]) | 1u))) & 255u); } if (((((unsigned)c0 << ((unsigned)c0 & 31u)) >> (a0[u1 & 3u] & 31u))) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
            e0 = e0 * 0.5L + (long double)(((*mp + garr[u2 & 7u]) + (0x9f287483u + p1)) & 1023u);
        }
        { unsigned t8; double z8; if (((unsigned)((short)(fuel >> (0x7fffffffu & 31u)) > (signed char)0u)) & 1u) { t8 = 0x8371386au; z8 = (double)(((unsigned)((unsigned)(7u || r0.x) == (unsigned)s1)) & 255u); } if (((unsigned)((short)(fuel >> (0x7fffffffu & 31u)) > (signed char)0u)) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
            v0 = (unsigned)c0;
            if (((unsigned)w0 + (unsigned)c1)) goto L4;
            r0.x = i1;
            goto L2;
        }
        goto L3;
    }
    goto L2;
    a0[(unsigned)l0 & 3u] = 2u;
    goto done;
    { unsigned t9; double z9; if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(0xffffffffu ^ (unsigned)s1))) & 1u) { t9 = (unsigned)((unsigned)d0 || ((unsigned)s1 & u0)); z9 = (double)((((unsigned)s0 % ((g0 * garr[u2 & 7u]) | 1u))) & 255u); } if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(0xffffffffu ^ (unsigned)s1))) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
        v0 = (unsigned)(short)(i1 >> (0xb1ec6202u & 31u));
        w0 ^= (unsigned long long)(unsigned)((int)garr[i1 & 7u] >= (int)g1) << ((unsigned)(short)((p1 | (unsigned)(w0 >> 29)) | i1) & 63u);
    }
    if (((unsigned)x0 & (unsigned)((int)0x7cb44966u >= (int)g1))) goto done;
    goto done;
    u2 = u2 * 0x9e3779b1u + ~(unsigned)((short)r0.x > (signed char)8u);
    *q0 = (unsigned)(signed char)((unsigned)((short)((unsigned)h0 | (unsigned)(signed char)((unsigned)f0 & g0)) > (signed char)(unsigned)c0) | 0x80000000u);
    { unsigned t10; double z10; if ((i2) & 1u) { t10 = ((unsigned)((unsigned)c0 || a0[u1 & 3u]) | (unsigned)(x0 >> 70)); z10 = (double)(((i1 + i1)) & 255u); } if ((i2) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
        w0 ^= (unsigned long long)u3 << ((unsigned)((unsigned)h1 || (unsigned)((int)(a0[u1 & 3u] >> (a0[i0 & 3u] & 31u)) < (int)(unsigned)e0)) & 63u);
        h1 = (unsigned short)(h1 + (unsigned)(short)(i0 ^ (r0.y + (unsigned)(9u && (i2 | 0x10000u)))));
    }
    { unsigned t11; double z11; if (((1u << (i2 & 31u))) & 1u) { t11 = (garr[i1 & 7u] | (u2 + v0)); z11 = (double)(((unsigned)h1) & 255u); } if (((1u << (i2 & 31u))) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
        garr[(unsigned)((unsigned)h1 && (unsigned)f0) & 7u] = ((unsigned)l0 + (unsigned)((int)(a0[i0 & 3u] & u2) < (int)r0.y));
        if (((unsigned)f0 >> (0x80000000u & 31u))) goto L4;
        if (budget != 0u) { budget -= 1u; u3 = fn0((0xffffffffu & (unsigned)((short)(unsigned)w0 > (signed char)garr[i1 & 7u])), ((0x7fffffffu | 0xa6e7cfd8u) ^ (unsigned)h0), (i2 * 0xe027567cu)); }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((short)p1 > (signed char)(unsigned)((int)0x10000u < (int)(unsigned)c0)));
            g0 = (p1 - a0[u1 & 3u]);
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                while (i2++ < 4u && r0.y) { if (--fuel == 0u) goto done;
                    m0 ^= (unsigned)l0;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((garr[i1 & 7u] % (0xffffffffu | 1u)), (unsigned)s0, (unsigned)c1); }
                    *mp = (unsigned)((unsigned)b0 < p1);
                    if (((unsigned)b0 + (unsigned)((int)a0[u1 & 3u] < (int)0xffffffffu))) goto L1;
                    break; (void)(p1);
                }
                b0 = ((0x26d4ceefu | p2) - 0x10000u) != 0u;
                if ((unsigned)w0) break;
                g0 = r0.x;
                b0 = ((unsigned)(x0 >> 70) << ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(a0[u1 & 3u] ? m0 : (unsigned)b0)) & 31u)) != 0u;
                { unsigned t12; double z12; if ((((unsigned)((int)(unsigned)w0 < (int)p1) / (g1 | 1u))) & 1u) { t12 = (unsigned)(short)(p0 << ((0x7fffffffu & (unsigned)(w0 >> 29)) & 31u)); z12 = (double)(((unsigned)((int)(unsigned)((short)*mp > (signed char)0xe989c1abu) >= (int)(unsigned)c1)) & 255u); } if ((((unsigned)((int)(unsigned)w0 < (int)p1) / (g1 | 1u))) & 1u) { u0 += t12; d0 = d0 * 0.5 + z12; }
                    if (((unsigned)(x0 >> 70) % (fuel | 1u))) goto done;
                    if ((unsigned)c1) break;
                }
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0(0x46a20b84u, (a0[u1 & 3u] ^ (unsigned)((unsigned)x0 == 4u)), r0.y); }
            if (((unsigned)((short)g0 > (signed char)u3) | fuel)) break;
        }
    }
    s0 = (int)(unsigned)((i1 ^ (unsigned)((unsigned)e0 < garr[i1 & 7u])) == (unsigned)((int)u1 >= (int)m0));
    m0 ^= (garr[i1 & 7u] - (unsigned)h0);
    if ((unsigned)f0) {
        { unsigned t13; double z13; if (((unsigned)(2u == r0.x)) & 1u) { t13 = ((unsigned)((short)0x67a4674fu > (signed char)p2) ^ i2); z13 = (double)(((unsigned)(short)(u3 + (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)p1))) & 255u); } if (((unsigned)(2u == r0.x)) & 1u) { u3 += t13; d0 = d0 * 0.5 + z13; }
            x0 = x0 * 0x100000001b3ull + ((*q0 >> (((unsigned)(w0 >> 29) % ((*q0 * garr[u2 & 7u]) | 1u)) & 31u)) - 0x2234a831u);
            w0 = w0 * 6364136223846793005ull + (0x45f53dccu >> (((unsigned)c1 | ~(fuel >> ((unsigned)f0 & 31u))) & 31u));
            c0 = (unsigned char)(unsigned)((v0 % ((unsigned)((short)u0 > (signed char)0x7fffffffu) | 1u)) < (unsigned)(signed char)(unsigned)((short)*mp > (signed char)7u));
            if ((u0 ^ (unsigned)f0)) goto L0;
            f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)e0 % (0x7fffffffu | 1u)) < *mp) & 255u);
            c0 = (unsigned char)8u;
        }
        c1 = (signed char)(unsigned)(a0[i0 & 3u] && ((unsigned)(x0 >> 70) * (unsigned)(x0 >> 70)));
        l0 = (long)((unsigned long)l0 + (v0 & ((unsigned)h0 >> ((0xffffffffu | (unsigned)s1) & 31u))));
        if (-((unsigned)d0 / (4u | 1u))) {
            if (p2) goto L3;
            s0 = (int)(0x704708c9u + (2u >> ((unsigned)h0 & 31u)));
        } else {
            if (u0) goto L1;
            v0 = (unsigned)((unsigned)x0 < u1);
            *q0 += ((unsigned)(i0 < 0xe319081eu) | (unsigned)c1);
            if ((unsigned)(r0.x || 0x10000u)) goto done;
        }
    } else {
        if (0x7fffffffu) goto L1;
        if (((0x7a52eec4u - (unsigned)h0) ^ 0x80000000u)) goto L0;
    }
    q0 = &garr[(unsigned)f0 & 7u];
    i2 = (4u << (u0 & 31u)) & 15u;
    u1 ^= (a0[i0 & 3u] / ((u0 * ((unsigned)l0 + (unsigned)h1)) | 1u));
    goto done;
    { unsigned t14; double z14; if ((fuel) & 1u) { t14 = g0; z14 = (double)(((unsigned)(0x80000000u == (unsigned)x0)) & 255u); } if ((fuel) & 1u) { u3 += t14; d0 = d0 * 0.5 + z14; }
        s1 = (int)((unsigned)s1 + ((unsigned)c0 & u1));
        if (-(p1 * (unsigned)(u1 == 0x7fffffffu))) goto L2;
        q0 = &garr[((unsigned)l0 ^ ((unsigned)l0 ? p2 : garr[i1 & 7u])) & 7u];
        m0 ^= (unsigned)(short)(3u / ((*mp ? 3u : (unsigned)((unsigned)s1 == (unsigned)w0)) | 1u));
    }
    if (((unsigned)h1 * 3u)) goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn1(~(unsigned)((unsigned)d0 == r0.x), (unsigned)(*q0 && r0.x), garr[i1 & 7u]); }
    v0 = (u1 - u1);
    if (-(i0 ^ 3u)) goto done;
    if ((unsigned)((unsigned)((int)i0 >= (int)(unsigned)c0) && v0)) goto L0;
    q0 = &garr[(((unsigned)((short)(unsigned)c0 > (signed char)((unsigned)s1 | 0u)) / ((unsigned)s1 | 1u)) | (unsigned)h0) & 7u];
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch (i2 & 7u) {
        break; (void)((unsigned)((int)0x7fffffffu < (int)(0x80000000u & i0)));
        if (*q0) goto L2;
        m0 ^= (((unsigned)w0 & 0x7fffffffu) / (((unsigned)(w0 >> 29) - (unsigned)s0) | 1u));
    }
    goto L0;
    r0.x = (u0 - (((unsigned)s0 - 9u) >> (0x98fa5113u & 31u)));
    if (u1) goto L4;
    goto L1;
    s1 = (int)((unsigned)s1 + (unsigned)((p2 << (0x7fffffffu & 31u)) && 0x80000000u));
    L0: if (--fuel == 0u) goto done;
    q0 = &garr[(a0[u1 & 3u] + (unsigned)((int)0xffffffffu < (int)p2)) & 7u];
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)(m0 % ((unsigned)s1 | 1u)), (unsigned)(*mp || 7u), (0x10000u % ((unsigned)s0 | 1u))); }
    L1: if (--fuel == 0u) goto done;
    s0 = (int)(unsigned)((unsigned)((int)(unsigned)((unsigned)s0 || (unsigned)c0) < (int)(unsigned)(x0 >> 70)) < i2);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        g1 += ((unsigned)!(unsigned)(((unsigned)f0 << (a0[u1 & 3u] & 31u)) || (unsigned)((short)a0[u1 & 3u] > (signed char)0xac5c9744u)) * (unsigned)w0);
        continue; (void)((u3 % ((unsigned)c1 | 1u)));
        u2 += (unsigned)(((unsigned)f0 + (unsigned)b0) || 0xc103d88u);
        if (budget != 0u) { budget -= 1u; u2 = fn0((p0 + (6u + a0[i0 & 3u])), ((unsigned)c0 + p2), (unsigned)x0); }
        goto L1;
        *q0 = ((unsigned)((int)i2 >= (int)garr[u2 & 7u]) & (u1 / ((unsigned)((int)9u < (int)u3) | 1u)));
    }
    if (budget != 0u) { budget -= 1u; u2 = fn2(0x10000u, ~(garr[i1 & 7u] | (unsigned)e0), ((i2 & (unsigned)s1) ^ 0xa31bbec2u)); }
    c0 = (unsigned char)a0[u1 & 3u];
    g1 += ~(unsigned)((0xb8990518u ? g0 : (unsigned)w0) < 0u);
    s0 = (int)((unsigned)s0 | ((unsigned)((int)p0 >= (int)m0) + (unsigned)((int)garr[i1 & 7u] < (int)garr[u2 & 7u])));
    if ((unsigned)((short)(i0 << (0u & 31u)) > (signed char)(unsigned)c0)) {
        s1 = (int)((unsigned)s1 + a0[u1 & 3u]);
    } else {
        if (budget != 0u) { budget -= 1u; u3 = fn2(i0, (unsigned)f0, ((unsigned)(w0 >> 29) * 3u)); }
        g0 = i1;
    }
    L2: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u3 = fn0((2u >> ((unsigned)s1 & 31u)), (u3 / ((unsigned)w0 | 1u)), u2); }
    if (((unsigned)e0 % ((unsigned)(short)(5u - (unsigned)s0) | 1u))) {
        if ((garr[i1 & 7u] << (((unsigned)e0 >> (p2 & 31u)) & 31u))) goto L2;
        if ((unsigned)c0) goto L4;
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(signed char)(0xffffffffu ^ r0.y), (unsigned)l0, (u3 | (0x80000000u - (unsigned)d0))); }
        do { if (--fuel == 0u) goto done;
            r0.x = *mp;
            if ((unsigned)f0) break;
            break; (void)(0x80000000u);
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(u0 ^ g0);
                goto L4;
                c0 = (unsigned char)(unsigned)(signed char)((unsigned)(short)(unsigned)(i1 && i2) + (i1 & 0x7fffffffu));
                u2 = (unsigned)((unsigned)c1 && fuel);
            }
            L3: if (--fuel == 0u) goto done;
        } while (i0++ < 6u && u1);
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t0; double z0; if (((r0.x << ((unsigned)h0 & 31u))) & 1u) { t0 = (unsigned)(a0[i0 & 3u] && 7u); z0 = (double)((r0.x) & 255u); } if (((r0.x << ((unsigned)h0 & 31u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    w0 ^= (unsigned long long)*q0 << (0x253c5fd0u & 63u);
                    L4: if (--fuel == 0u) goto done;
                    if (u3 == 7u) return ((unsigned)h0 & (unsigned)!(unsigned)((short)garr[u2 & 7u] > (signed char)a0[i0 & 3u]));
                    *q0 = ((unsigned)h0 & (unsigned)((unsigned)(0x10000u < (7u % (0xffffffffu | 1u))) || r0.x));
                    b0 = (unsigned)(((unsigned)((short)0x80000000u > (signed char)fuel) & r0.y) == (unsigned)(x0 >> 70)) != 0u;
                }
                f0 = f0 * 0.5f + (float)((unsigned)!((unsigned)h0 / (0xc5259291u | 1u)) & 255u);
            }
        }
    }
    goto L1;
    v0 = (unsigned)(x0 >> 70);
    if ((unsigned)!((unsigned)(unsigned char)(r0.y & 0x3c67c0d7u) ^ r0.y)) goto L2;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)(1u | ((p2 | ((unsigned)c1 | u3)) / (0x4ca3dc8au | 1u)));
        *q0 = u1;
        *q0 = a0[u1 & 3u];
        switch ((unsigned)((unsigned)d0 || i1) & 7u) {
            f0 = f0 * 0.5f + (float)((unsigned)(p0 || (0xffffffffu % ((unsigned)(i0 || (unsigned)(garr[i1 & 7u] || 3u)) | 1u))) & 255u);
        }
        if ((unsigned)(w0 >> 29)) continue;
        garr[(unsigned)w0 & 7u] = (p1 | -(unsigned)(i0 && (~(unsigned)(*mp == m0) % (i0 | 1u))));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    a0[(i0 << (0x10000u & 31u)) & 3u] = (u0 << ((unsigned)((int)3u >= (int)a0[i0 & 3u]) & 31u));
    d0 = d0 * 0.5 + (double)((unsigned)(a0[u1 & 3u] && p2) & 1023u);
    *q0 = v0;
    r0.x = 0x80000000u;
    u3 = u3 * 0x9e3779b1u + i2;
    if (budget != 0u) { budget -= 1u; u1 = fn2((0x7fffffffu | r0.x), ((0x10000u * 2u) & (unsigned)b0), (unsigned)((short)7u > (signed char)(unsigned)s0)); }
    w0 ^= (unsigned long long)u2 << ((unsigned)(unsigned char)((unsigned)((unsigned)s0 < 0x10000u) ? *mp : (unsigned)(signed char)(0x10000u / (0xee370cb9u | 1u))) & 63u);
    a0[0u & 3u] = 0xe47add4eu;
    { unsigned t0; double z0; if (((i0 << ((1u * (unsigned)e0) & 31u))) & 1u) { t0 = (unsigned)((unsigned)(w0 >> 29) && (unsigned)(8u < g1)); z0 = (double)(((unsigned)((int)(unsigned)s1 < (int)p1)) & 255u); } if (((i0 << ((1u * (unsigned)e0) & 31u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        d0 = d0 * 0.5 + (double)((unsigned)(signed char)(unsigned)((unsigned)((unsigned)w0 == garr[u2 & 7u]) && (unsigned)((int)((unsigned)d0 & *mp) < (int)i2)) & 1023u);
    }
    m0 ^= (unsigned)f0;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)(unsigned char)((unsigned)(w0 >> 29) * p0), (unsigned)((short)6u > (signed char)a0[u1 & 3u]), (unsigned)(garr[i1 & 7u] || 0x7fffffffu)); }
        w0 = w0 * 6364136223846793005ull + (unsigned)((short)(9u << ((unsigned)((short)g1 > (signed char)9u) & 31u)) > (signed char)(a0[u1 & 3u] + p0));
        h0 = (short)((unsigned)(w0 >> 29) & (2u ? (r0.y * r0.y) : (unsigned)s1));
    }
    h0 = (short)(0x7fffffffu + ((m0 >> ((9u | 0x80000000u) & 31u)) << (0x558b6e71u & 31u)));
    b0 = i1 != 0u;
    h1 = (unsigned short)(h1 + (unsigned)((int)(((unsigned)l0 + 0x61756692u) ? u2 : i2) >= (int)(unsigned)h1));
    if ((unsigned)((int)((unsigned)w0 | p2) >= (int)m0)) {
        garr[0u & 7u] = (unsigned)((int)0xb77c0cc3u >= (int)(unsigned)s0);
        if ((unsigned)(i2 < 0x80000000u)) {
            if ((1u - (unsigned)(4u == garr[i1 & 7u]))) goto L2;
        } else {
            while (i0++ < 6u && r0.x) { if (--fuel == 0u) goto done;
                a0[2u & 3u] = ((m0 % ((unsigned)((int)g0 >= (int)0xa794f34u) | 1u)) | p0);
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + g0);
                }
                h0 = (short)7u;
                l0 = (long)((unsigned long)l0 + u1);
                do { if (--fuel == 0u) goto done;
                    if (*mp) goto L0;
                } while (i1++ < 2u && r0.y);
                v0 = ((unsigned)s0 / (((unsigned)(w0 >> 29) - (u2 ? 6u : *q0)) | 1u));
            }
            L0: if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)((int)(unsigned)(signed char)(fuel % ((unsigned)(x0 >> 70) | 1u)) < (int)(unsigned)w0);
            if ((unsigned)(r0.y == (unsigned)((int)4u < (int)(unsigned)s1))) goto L2;
        }
        goto L3;
        if (r0.x) goto L1;
        while (0x80000000u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)(short)(7u << (u0 & 31u)) && (unsigned)((int)*q0 < (int)garr[i1 & 7u])));
                x0 = x0 * 0x100000001b3ull + ((unsigned)((int)p2 < (int)0x80000000u) % (i2 | 1u));
                s0 = (int)((unsigned)h1 * (unsigned)((int)(0xe9000f16u ^ 5u) >= (int)(0x80000000u % (g0 | 1u))));
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0(0x80000000u, p2, (unsigned)((int)(p2 * 0xffffffffu) < (int)0x3ea6afdeu)); }
            if ((garr[i1 & 7u] / ((4u & 2u) | 1u))) {
                break; (void)((unsigned)((int)(unsigned)w0 < (int)(unsigned)b0));
                { unsigned t1; double z1; if (((unsigned)(8u < (unsigned)x0)) & 1u) { t1 = (unsigned)w0; z1 = (double)(((i0 | (v0 ^ (unsigned)(x0 >> 70)))) & 255u); } if (((unsigned)(8u < (unsigned)x0)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    h0 = (short)(2u % ((*mp - *q0) | 1u));
                    if (0x10000u) break;
                    m0 ^= (((unsigned)c0 ^ m0) - 0x53a1d767u);
                    if (fuel) break;
                    b0 = ((unsigned)d0 - 8u) != 0u;
                }
                while ((*q0 + ((unsigned)c0 + 0x5cc8ed84u))) { if (--fuel == 0u) goto done;
                    q0 = &garr[(unsigned)(((0xa5d44feeu & p2) % (fuel | 1u)) == (unsigned)c0) & 7u];
                    switch ((unsigned)(r0.y || (unsigned)d0) & 7u) {
                        { unsigned t2; double z2; if ((((unsigned)f0 % ((unsigned)d0 | 1u))) & 1u) { t2 = 0xff4b2919u; z2 = (double)(((((unsigned)e0 / ((unsigned)(w0 >> 29) | 1u)) % (i0 | 1u))) & 255u); } if ((((unsigned)f0 % ((unsigned)d0 | 1u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                            h1 = (unsigned short)(h1 + (unsigned)((int)0x5145abbeu < (int)garr[i1 & 7u]));
                            L1: if (--fuel == 0u) goto done;
                            a0[g0 & 3u] = (unsigned)(7u < -(unsigned)(0u && ((unsigned)((unsigned)f0 == 0xd4bb7180u) + u3)));
                            u1 += ((unsigned)(garr[u2 & 7u] < p1) - r0.y);
                            if (budget != 0u) { budget -= 1u; u3 = fn2(((p1 / (i1 | 1u)) >> ((unsigned)s0 & 31u)), (unsigned)d0, fuel); }
                            b0 = (unsigned)((short)i1 > (signed char)garr[u2 & 7u]) != 0u;
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)f0, ~(unsigned)((short)(unsigned)s1 > (signed char)i1), (unsigned)w0); }
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(unsigned)((int)2u >= (int)(u0 >> (0x62678bc6u & 31u))), p0, p1); }
                        case 7u: ;
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn2(3u, ~((unsigned)e0 % ((unsigned)h0 | 1u)), (unsigned)(signed char)(u2 | g0)); }
                    if (((unsigned)h0 % (r0.y | 1u))) goto L4;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)(v0 == 0x464cdf71u) & 7u), (unsigned)!(unsigned)(r0.x || u0), ((0x57e5584cu - 0x7fffffffu) | 0x80000000u)); }
                    *q0 = ((unsigned)h0 ? 2u : (unsigned)(signed char)(unsigned)((int)(unsigned)((unsigned)h0 || u0) >= (int)(unsigned)b0));
                }
            } else {
                if (u3 == 7u) return (i0 ^ v0);
                if (budget != 0u) { budget -= 1u; u1 = fn1(0x7fffffffu, m0, u0); }
                s0 = (int)(0xd9e64830u * 2u);
                if (0u) goto L4;
            }
            switch ((unsigned)((int)u3 >= (int)0xf7d4f248u) & 7u) {
                q0 = &garr[((unsigned)c1 | 0x80000000u) & 7u];
                { unsigned t3; double z3; if (((unsigned)(0xa802e7c3u && (i2 ^ 0x7fffffffu))) & 1u) { t3 = (unsigned)c1; z3 = (double)(((unsigned)((int)6u < (int)0x5949c5ebu)) & 255u); } if (((unsigned)(0xa802e7c3u && (i2 ^ 0x7fffffffu))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    continue; (void)((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)(short)(unsigned)(u3 < 0xffffffffu)));
                    L2: if (--fuel == 0u) goto done;
                    q0 = &garr[(unsigned)(unsigned char)(unsigned)(u1 || i1) & 7u];
                    continue; (void)(((unsigned)(r0.x && (unsigned)b0) % (9u | 1u)));
                    if ((unsigned)(1u || g0)) break;
                    l0 = (long)((unsigned long)l0 + ((unsigned)(g0 && (unsigned)h1) >> ((0x80000000u ^ (r0.x ^ u2)) & 31u)));
                }
                h1 = (unsigned short)(h1 + (m0 - -(unsigned)(1u || r0.x)));
                a0[0x81270837u & 3u] = (u0 << ((unsigned)((unsigned)(x0 >> 70) == (unsigned)w0) & 31u));
            }
        }
        goto L0;
    } else {
        q0 = &garr[(unsigned)(signed char)(unsigned)(a0[u1 & 3u] || (p1 ? 0x80000000u : a0[u1 & 3u])) & 7u];
        w0 ^= (unsigned long long)(unsigned)((unsigned)c0 == (unsigned)h1) << ((0xffffffffu | (unsigned)s1) & 63u);
        h1 = (unsigned short)(h1 + ((unsigned)(g1 && u2) / (0x5751cb62u | 1u)));
    }
    { unsigned t4; double z4; if (((0x19d2d378u & v0)) & 1u) { t4 = (unsigned)(w0 >> 29); z4 = (double)((((unsigned)h0 % (-(unsigned)(0xc2d476f4u && (unsigned)l0) | 1u))) & 255u); } if (((0x19d2d378u & v0)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        do { if (--fuel == 0u) goto done;
            switch (~((unsigned)(signed char)(unsigned)((unsigned)h1 && (unsigned)h0) ^ (unsigned)h0) & 7u) {
                s0 = (int)(unsigned)(0xc5d611c2u && (i2 * (unsigned)e0));
                u0 = (a0[i0 & 3u] >> (((unsigned)d0 * 0xffffffffu) & 31u));
                h1 = (unsigned short)(h1 + (0xb875179au + (unsigned)(9u == i0)));
                d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((unsigned)(w0 >> 29) && 0x80000000u) && (0xba3c9aedu << ((r0.x | fuel) & 31u))) & 1023u);
                u2 = (unsigned)(x0 >> 70);
                while (i1++ < 2u && (p2 % (0x80000000u | 1u))) { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)(((fuel % (0x2023aa66u | 1u)) * p2) || 0x2eee88c5u);
                    *q0 += fuel;
                    case 2u: ;
                    if (((u0 ^ r0.x) / (g1 | 1u))) continue;
                    r0.y ^= (unsigned)(unsigned char)((0x10000u % ((unsigned)s0 | 1u)) ^ (unsigned)((int)p0 < (int)(unsigned)(x0 >> 70)));
                    if (budget != 0u) { budget -= 1u; u3 = fn2(m0, u1, (unsigned)(0u < 0x53b02679u)); }
                }
            }
            while ((unsigned)(*q0 == (unsigned)!(r0.y | 2u))) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    continue; (void)((0x4c4841b8u % (((unsigned)b0 / (i1 | 1u)) | 1u)));
                } while (i2++ < 7u && (unsigned)((int)*q0 < (int)(unsigned)e0));
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((unsigned)((int)u3 >= (int)0x7fffffffu) == 0x10000u), (r0.y | 0xb6da8ccu), (((unsigned)l0 ^ (unsigned)l0) / ((unsigned)b0 | 1u))); }
                for (;;) { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)((((i1 + *q0) >> ((unsigned)d0 & 31u)) >> ((unsigned)h0 & 31u)) == (unsigned)w0);
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((short)garr[i1 & 7u] > (signed char)g1), m0, fuel); }
                }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)(unsigned)(signed char)(0x10000u + u2) >= (int)(unsigned)l0), (unsigned)h1, fuel); }
                do { if (--fuel == 0u) goto done;
                    u1 += (((unsigned)((short)garr[u2 & 7u] > (signed char)0xffffffffu) | 0x10000u) % ((unsigned)l0 | 1u));
                } while (i2++ < 2u && 0xb609a197u);
                L3: if (--fuel == 0u) goto done;
            }
            *mp = (unsigned)((0x5cc0a03cu + p2) == 0x7fffffffu);
        } while (i0++ < 5u && (m0 - 0xffffffffu));
        L4: if (--fuel == 0u) goto done;
    }
    if ((*mp ? garr[u2 & 7u] : (unsigned)c1)) goto L0;
    if ((unsigned)!((unsigned)h1 * 5u)) goto L3;
    u1 = u1 * 0x9e3779b1u + (m0 / ((unsigned)((short)1u > (signed char)0x760e92c7u) | 1u));
    if (p1) goto done;
    if ((unsigned)s1) goto L4;
    g0 = ((unsigned)((int)0xb57e593fu >= (int)0x5954bb93u) + (unsigned)(short)((unsigned)l0 * (unsigned)s0));
    if (((unsigned)((short)i0 > (signed char)p2) ^ 0x80000000u)) {
        if ((unsigned)(r0.y < 1u)) goto L1;
        if (budget != 0u) { budget -= 1u; u2 = fn2(0xd5a18e0cu, (unsigned)((unsigned)(p2 == i2) < 0x36891785u), (unsigned)(g0 == 0x10000u)); }
        l0 = (long)((unsigned long)l0 + (u0 % (0x63f4d78cu | 1u)));
        g1 += (unsigned)(p0 && (unsigned)(short)((unsigned)f0 >> (0x80000000u & 31u)));
        if (u3 == 7u) return (unsigned)(0x80000000u == (unsigned)(i0 < 0xffffffffu));
    } else {
        m0 ^= (unsigned)(((unsigned)(g0 == (unsigned)x0) / (0x10000u | 1u)) && u1);
        i0 = (i2 | (i1 ^ ((unsigned)(garr[u2 & 7u] || garr[i1 & 7u]) << ((unsigned)w0 & 31u)))) & 15u;
    }
    u1 = (6u * (garr[u2 & 7u] + (0x10000u >> (7u & 31u))));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 11u, 0x433d9132u, 0xa7dbc86fu },
        { 6u, 0xdde04775u, 0x6ab07dd0u },
        { 7u, 0xe4a55f4u, 0x3061d5e6u },
        { 6u, 0xf773c3a3u, 0xe3c029abu },
        { 6u, 0xd428432eu, 0x53317a7u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
