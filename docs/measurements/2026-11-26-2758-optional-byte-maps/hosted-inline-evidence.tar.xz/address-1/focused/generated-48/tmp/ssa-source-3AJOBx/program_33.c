// test-ssa-source's program of seed 134000435 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xfabd69fcu, g1 = 0x96abe9a0u;
static unsigned garr[8] = { 0xcfd513cfu, 0xd9e07dcfu, 0x51ef37beu, 0x7eea9324u, 0x641a31acu, 0x6503210u, 0x989442cu, 0xa580dd92u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(signed char)(unsigned)((unsigned)((int)m0 >= (int)(unsigned)(w0 >> 29)) || r0.y)) goto L3;
    u1 = (unsigned)((unsigned)!(0xffffffffu ^ g1) == (unsigned)f0);
    if ((unsigned)b0) goto L0;
    if ((unsigned)c1) {
        L0: if (--fuel == 0u) goto done;
    } else {
        s1 = (int)((unsigned)s1 + ((unsigned)(0x60ffdff0u < 0x5887c883u) >> (0u & 31u)));
        if (((unsigned)e0 & 0x80000000u)) {
            { unsigned t0; double z0; if (((u2 % ((unsigned)(0xe3c8e5d2u == 6u) | 1u))) & 1u) { t0 = (i1 | *q0); z0 = (double)(((u2 / (1u | 1u))) & 255u); } if (((u2 % ((unsigned)(0xe3c8e5d2u == 6u) | 1u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                a0[((unsigned)c0 + 0xfe5b6e67u) & 3u] = (unsigned)((int)0x9f2c7353u < (int)(2u + (p1 & m0)));
                do { if (--fuel == 0u) goto done;
                    if ((u2 + (unsigned)(x0 >> 70))) break;
                    if ((unsigned)(7u && 0xffffffffu)) {
                        *q0 = (m0 >> ((unsigned)d0 & 31u));
                    } else {
                        L1: if (--fuel == 0u) goto done;
                        if (fuel < 8u) return ((unsigned)!(u3 & ((unsigned)((int)g1 >= (int)0x80000000u) % (p0 | 1u))) & (unsigned)(x0 >> 70));
                    }
                } while (i0++ < 4u && 4u);
                L2: if (--fuel == 0u) goto done;
                q0 = &garr[~((a0[u1 & 3u] / (i1 | 1u)) * (unsigned)(unsigned char)(i1 & 0x80000000u)) & 7u];
                if (fuel < 8u) return ((unsigned)b0 | 0x7fffffffu);
                while ((unsigned)((unsigned)((int)g0 >= (int)g1) || r0.x)) { if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                    if (((unsigned)h1 & *q0)) continue;
                    L4: if (--fuel == 0u) goto done;
                    if ((unsigned)(9u || p1)) continue;
                    continue; (void)((0x80000000u & u1));
                }
            }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)d0) goto L0;
                i0 = ((unsigned)s1 % ((unsigned)b0 | 1u)) & 15u;
                if ((unsigned)((int)0xf43c7d54u >= (int)(unsigned)((int)6u >= (int)(unsigned)h1))) break;
                h1 = (unsigned short)(h1 + (unsigned)(((unsigned)(x0 >> 70) * u2) == (r0.y << (((unsigned)c0 - 0x10000u) & 31u))));
            } while (i0++ < 6u && 2u);
            u1 += (i1 >> (v0 & 31u));
            s0 = (int)g1;
        } else {
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                garr[v0 & 7u] = (p2 >> (m0 & 31u));
                goto L0;
                w0 ^= (unsigned long long)(5u / (garr[u2 & 7u] | 1u)) << ((0x10000u % (((unsigned)(fuel < 4u) << ((unsigned)l0 & 31u)) | 1u)) & 63u);
                v0 = ((unsigned)l0 ^ ((unsigned)(0xffffffffu == (unsigned)d0) ? m0 : 4u));
                x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)(unsigned char)(unsigned)((int)p0 < (int)(unsigned)((int)0xffffffffu < (int)i2)) && (unsigned)(short)((unsigned)s0 - (unsigned)x0));
                if ((unsigned)((short)i1 > (signed char)(0xffffffffu / (4u | 1u)))) goto L3;
            }
            *q0 = (unsigned)(g1 || (unsigned)(short)((unsigned)(w0 >> 29) >> ((unsigned)c1 & 31u)));
        }
    }
    if (((unsigned)d0 + ((unsigned)l0 + (unsigned)h0))) {
        r0.x = ((unsigned)(0x66d401eeu && (7u ^ (unsigned)(i2 < (unsigned)f0))) >> ((unsigned)h1 & 31u));
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(i0);
            f0 = f0 * 0.5f + (float)(fuel & 255u);
            if ((*mp ? 8u : g0)) break;
        }
    } else {
        if (u3 == 7u) return -(garr[i1 & 7u] >> ((unsigned)e0 & 31u));
        if ((unsigned)(signed char)(unsigned)((int)i1 >= (int)(unsigned)x0)) goto done;
        r0.x = (unsigned)((short)(r0.x ^ (unsigned)((int)0xf741deb1u >= (int)fuel)) > (signed char)(unsigned)((unsigned)l0 || 0xaf0d579fu));
        w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)((int)0x7fffffffu < (int)u1) > (signed char)(unsigned)!((unsigned)h1 ^ p2));
    }
    goto L2;
    x0 = x0 * 0x100000001b3ull + i0;
    if ((unsigned)c0) goto L3;
    if ((unsigned)e0) {
        e0 = e0 * 0.5L + (long double)((unsigned)((int)p2 < (int)(unsigned)((unsigned)c0 || 0xffffffffu)) & 1023u);
        for (;;) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + -(u3 * (unsigned)((short)6u > (signed char)(unsigned)f0));
            *q0 += (0xffffffffu - ((garr[i1 & 7u] + (0xd80a0b61u * 5u)) << (v0 & 31u)));
            r0.y ^= (4u / (0x19dda19eu | 1u));
            s0 = (int)(unsigned)(short)((6u / (0x80000000u | 1u)) * v0);
            if (u2) break;
            if ((unsigned)h1) break;
        }
        while (i0++ < 3u && i2) { if (--fuel == 0u) goto done;
            break; (void)((u3 / ((unsigned)(a0[i0 & 3u] < (unsigned)l0) | 1u)));
            c1 = (signed char)(unsigned)(unsigned char)(unsigned)((garr[i1 & 7u] - 0xeeb27fa8u) || (unsigned)(garr[i1 & 7u] && 0xffffffffu));
            *q0 = (unsigned)((int)(garr[u2 & 7u] & 0x10000u) < (int)(unsigned)e0);
            u0 += (p1 | 5u);
            while (i1++ < 4u && (unsigned)d0) { if (--fuel == 0u) goto done;
                if (((u2 / (garr[i1 & 7u] | 1u)) << (i1 & 31u))) continue;
                if ((((unsigned)s0 - g1) >> ((unsigned)s1 & 31u))) continue;
                if (u3 == 7u) return *mp;
                if ((2u - 5u)) break;
            }
            m0 ^= ((unsigned)((int)0x7fffffffu < (int)0xba2aed84u) >> (r0.x & 31u));
        }
        if (((unsigned)s0 << (0xfe2b467eu & 31u))) goto L1;
        if (((unsigned)(u3 && 0x10000u) >> (0xffffffffu & 31u))) goto L3;
    } else {
        while (i0++ < 4u && (0x5cabe73du | *q0)) { if (--fuel == 0u) goto done;
            if (p0) break;
            if (~((unsigned)e0 - 3u)) break;
            if (fuel < 8u) return (unsigned)((short)(7u >> ((unsigned)(r0.y == a0[u1 & 3u]) & 31u)) > (signed char)p1);
            if ((unsigned)(fuel < (unsigned)(u3 < (unsigned)h0))) continue;
            if (0x4a0398f6u) continue;
        }
        if (p0) goto L4;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(i2 == (unsigned)x0)) continue;
            u2 = ((unsigned)(u0 || (unsigned)(0xd3264d32u == (unsigned)s1)) / (((unsigned)(w0 >> 29) * 9u) | 1u));
            break; (void)((unsigned)s0);
        } while (i0++ < 7u && (unsigned)((int)0x10000u >= (int)0xffffffffu));
        if ((unsigned)((unsigned)s0 == ((unsigned)h0 << (0xc7c30fe9u & 31u)))) goto done;
    }
    while (i0++ < 4u && (unsigned)h0) { if (--fuel == 0u) goto done;
        if (~(unsigned)((int)(unsigned)e0 < (int)(unsigned)c0)) break;
    }
    if ((unsigned)((unsigned)!(unsigned)((short)g0 > (signed char)0x80000000u) == 0xffffffffu)) {
        u1 ^= fuel;
    } else {
        if (((unsigned)!((unsigned)c0 | u1) - r0.y)) goto L3;
        if (((unsigned)s0 + ((unsigned)w0 << (v0 & 31u)))) goto L0;
        do { if (--fuel == 0u) goto done;
            b0 = (unsigned)e0 != 0u;
            c0 = (unsigned char)(unsigned)(a0[u1 & 3u] && (unsigned)(short)(i0 - (unsigned)c0));
            if ((3u ^ g1)) break;
            d0 = d0 * 0.5 + (double)(((unsigned)((int)m0 >= (int)*q0) / ((0x9cdd0782u + 0xba001e77u) | 1u)) & 1023u);
        } while (i0++ < 7u && p1);
        switch ((unsigned)l0 & 7u) {
            if (m0) {
                case 4u: ;
            }
            case 0u: ;
        }
    }
    if ((unsigned)((unsigned)s0 < (unsigned)(p0 || 0xffffffffu))) goto L2;
    b0 = (((unsigned)h1 ? i1 : (unsigned)s0) / ((garr[i1 & 7u] + (unsigned)h1) | 1u)) != 0u;
    if ((unsigned)((i2 | *mp) || 1u)) goto L2;
    c0 = (unsigned char)(unsigned)(short)((p2 ^ 0x10000u) & 0xf4be78dcu);
    while (i0++ < 6u && -(unsigned)((unsigned)(w0 >> 29) && (unsigned)d0)) { if (--fuel == 0u) goto done;
        if ((0u + i0)) break;
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(signed char)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)(0x7fffffffu || u3))) break;
        if ((unsigned)(u2 == ((unsigned)d0 / (m0 | 1u)))) break;
        u1 ^= ((p2 >> ((unsigned)((unsigned)(x0 >> 70) == p2) & 31u)) << (m0 & 31u));
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)c0 < (int)(i0 >> (((unsigned)s0 >> (u2 & 31u)) & 31u)));
    a0[(0x19700e03u | 0x7fffffffu) & 3u] = (-(unsigned)(r0.x && (unsigned)!(0xffffffffu + 0xcbd4e7b5u)) << (0xffffffffu & 31u));
    if ((0x7fffffffu / ((u0 + p1) | 1u))) goto L3;
    if ((unsigned)((int)a0[u1 & 3u] < (int)0xffffffffu)) goto L1;
    r0.y ^= (unsigned)((int)u3 < (int)*mp);
    if (p1) {
        if (fuel < 8u) return ((((unsigned)s0 - u0) * ((unsigned)h0 ^ 5u)) << ((unsigned)f0 & 31u));
        while (((unsigned)s1 - ((unsigned)c1 * (unsigned)e0))) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)(0x10000u == (unsigned)(x0 >> 70)));
            for (;;) { if (--fuel == 0u) goto done;
                break; (void)(-(garr[i1 & 7u] / ((unsigned)l0 | 1u)));
                r0.y ^= (unsigned)(short)(g0 >> ((8u | (unsigned)((int)r0.x >= (int)(unsigned)c0)) & 31u));
                if ((unsigned)(9u || (unsigned)s0)) break;
                break; (void)((unsigned)(*q0 && r0.x));
                { unsigned t1; double z1; if (((unsigned)((int)4u >= (int)i1)) & 1u) { t1 = (unsigned)(0x7fffffffu == 0xffffffffu); z1 = (double)((0x4dfb80au) & 255u); } if (((unsigned)((int)4u >= (int)i1)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    break; (void)((unsigned)s0);
                    do { if (--fuel == 0u) goto done;
                        garr[(unsigned)((short)*mp > (signed char)0xd58c818fu) & 7u] = (r0.y << (((unsigned)(5u && 4u) ^ i2) & 31u));
                        if ((unsigned)(0x5f298447u == p2)) break;
                        break; (void)((g1 | (unsigned)(short)(u1 ^ 7u)));
                    } while (i2++ < 5u && (unsigned)h1);
                    r0.x = (unsigned)((int)0xffffffffu < (int)v0);
                    l0 = (long)((unsigned long)l0 + ((unsigned)(unsigned char)(m0 ^ u0) + r0.y));
                    *mp = (p2 % ((unsigned)c0 | 1u));
                }
                s1 = (int)((unsigned)s1 + 6u);
            }
            if (u3 == 7u) return (((unsigned)l0 | r0.x) + 0x73c4db2u);
        }
        q0 = &garr[v0 & 7u];
        c1 = (signed char)(unsigned)(short)(unsigned)(i2 == (unsigned)(0xffffffffu < 5u));
    }
    if (1u) {
        goto L2;
    } else {
        goto L3;
        for (;;) { if (--fuel == 0u) goto done;
            if (-((0x7fffffffu << (0x6938a3bau & 31u)) | 0x457a3e71u)) break;
            if ((p2 ^ (unsigned)b0)) {
                if ((unsigned)(unsigned char)(8u * i1)) break;
                break; (void)((unsigned)(w0 >> 29));
                if (u3 == 7u) return (unsigned)(signed char)(unsigned)((int)0x4149fa2du >= (int)(unsigned)(*mp && 0xdfbe1151u));
            } else {
                b0 = (unsigned)((unsigned)c0 < (unsigned)l0) != 0u;
                for (;;) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((unsigned)(signed char)(p0 << (*q0 & 31u)) & 255u);
                    if ((unsigned)(w0 >> 29)) break;
                    u2 ^= ~(unsigned)((unsigned)s1 < ((unsigned)((a0[i0 & 3u] | 1u) == 0xcc503973u) >> (garr[u2 & 7u] & 31u)));
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)d0 < u3) & 255u);
                }
                s1 = (int)((unsigned)s1 + r0.x);
                if ((((unsigned)c0 << ((unsigned)x0 & 31u)) / (a0[i0 & 3u] | 1u))) break;
            }
            u3 ^= i2;
            break; (void)(((unsigned)e0 % ((i0 - 8u) | 1u)));
            break; (void)((garr[u2 & 7u] ^ fuel));
            r0.x = (unsigned)(u2 < (i1 & g0));
        }
        f0 = f0 * 0.5f + (float)(((m0 | u2) | (unsigned)(x0 >> 70)) & 255u);
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(m0 < (unsigned)(i1 || 5u))) break;
            if (9u) continue;
            d0 = d0 * 0.5 + (double)((g1 + (unsigned)s1) & 1023u);
        } while (i0++ < 3u && (unsigned)(r0.x == m0));
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        c1 = (signed char)~(0x8824fda3u | v0);
        a0[(unsigned)((int)v0 >= (int)a0[u1 & 3u]) & 3u] = ((0x978d4b45u % (r0.y | 1u)) ^ (unsigned)((unsigned)((int)v0 < (int)0x7fffffffu) == (unsigned)(w0 >> 29)));
        break; (void)((unsigned)((short)a0[i0 & 3u] > (signed char)0x625deb17u));
        if ((unsigned)((int)3u < (int)(unsigned)h1)) break;
        do { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((((unsigned)f0 / (a0[u1 & 3u] | 1u)) | 0x2d48d2abu) == a0[i0 & 3u]) < 0x80000000u));
            do { if (--fuel == 0u) goto done;
                if (((unsigned)((int)(unsigned)s1 < (int)0x10000u) << ((unsigned)l0 & 31u))) {
                    for (;;) { if (--fuel == 0u) goto done;
                        if ((g0 | 2u)) break;
                        i0 = (0x80000000u / ((3u * p2) | 1u)) & 15u;
                        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                            l0 = (long)((unsigned long)l0 + (unsigned)h0);
                            break; (void)(g0);
                        }
                        if (((unsigned)c0 ? u1 : (unsigned)d0)) break;
                        g1 += (unsigned)(signed char)(unsigned)(0xeb7fda41u && ((fuel ? g0 : (unsigned)(x0 >> 70)) + garr[u2 & 7u]));
                    }
                }
                if (0x966fc113u) break;
                q0 = &garr[(unsigned)((int)*q0 < (int)(unsigned)f0) & 7u];
                if ((unsigned)((int)garr[i1 & 7u] >= (int)r0.x)) break;
                if ((unsigned)((unsigned)c0 == (g0 ^ fuel))) break;
                { unsigned t2; double z2; if (((fuel + u1)) & 1u) { t2 = (unsigned)((short)u1 > (signed char)((unsigned)e0 - *q0)); z2 = (double)(((unsigned)((int)r0.y < (int)(unsigned)e0)) & 255u); } if (((fuel + u1)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    u3 = u3 * 0x9e3779b1u + ((unsigned)((int)((unsigned)f0 ^ (unsigned)b0) >= (int)(m0 | 0x80000000u)) >> (garr[i1 & 7u] & 31u));
                    c0 = (unsigned char)((unsigned)((unsigned)d0 < (unsigned)w0) | (unsigned)e0);
                    s1 = (int)((unsigned)s1 + (unsigned)((int)(m0 ^ (0x775180cbu | fuel)) < (int)(unsigned)(w0 >> 29)));
                    v0 = (garr[u2 & 7u] << (p2 & 31u));
                }
            } while (i2++ < 4u && (unsigned)c1);
        } while (i1++ < 7u && (unsigned)((unsigned)(x0 >> 70) || 6u));
    }
    *q0 = (2u + (unsigned)x0);
    b0 = (((unsigned)s0 << ((0x79e396adu << (0xba97eb5fu & 31u)) & 31u)) / (g0 | 1u)) != 0u;
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((int)(unsigned)c1 < (int)g0));
        if (~(unsigned)(p1 == 0x8a50b0efu)) continue;
    } while (i0++ < 4u && (unsigned)((int)(unsigned)e0 < (int)m0));
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((int)0xffffffffu >= (int)(unsigned)x0));
        if ((g0 - 8u)) break;
    } while (i0++ < 4u && ((unsigned)h0 + 0xffffffffu));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)i0 > (signed char)v0)) break;
        { unsigned t3; double z3; if ((u2) & 1u) { t3 = a0[i0 & 3u]; z3 = (double)(((unsigned)((unsigned)f0 < u0)) & 255u); } if ((u2) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            goto L1;
            w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(((unsigned)d0 * i2) % (u0 | 1u));
        }
    }
    if ((0xffffffffu + r0.x)) goto L4;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)!((unsigned)f0 ^ 0x57c1fc66u)) goto L2;
    goto L3;
    v0 = ((unsigned)c0 << ((unsigned)c0 & 31u));
    g1 += (unsigned)((unsigned)(w0 >> 29) || (unsigned)!(0x9ad858c6u << ((0xffffffffu * r0.x) & 31u)));
    L0: if (--fuel == 0u) goto done;
    if ((g0 % (i2 | 1u))) goto L0;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
            break; (void)((0x10000u | (unsigned)s1));
            w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)((int)0x64b7adc7u >= (int)(unsigned)s0) > (signed char)(unsigned)(unsigned char)(unsigned)((short)v0 > (signed char)0x521c192bu));
            if ((p2 * (unsigned)b0)) {
                u0 += (unsigned)((4u >> (0x80000000u & 31u)) < (unsigned)((int)0xffffffffu < (int)(unsigned)s1));
                s0 = (int)(0u % ((unsigned)b0 | 1u));
                f0 = f0 * 0.5f + (float)((unsigned)s1 & 255u);
                *q0 += 0xdcd09e87u;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)l0, (fuel - 0x75c8ac66u), (p2 >> (0xffffffffu & 31u))); }
            if ((unsigned)(fuel < u2)) break;
        }
        w0 ^= (unsigned long long)g1 << (((unsigned)((short)((unsigned)(signed char)(0x873bca78u / (2u | 1u)) << (fuel & 31u)) > (signed char)g1) * p1) & 63u);
    }
    *q0 += (u0 * (i2 | (unsigned)(unsigned char)(g1 << (p0 & 31u))));
    if ((unsigned)((u2 & (unsigned)e0) == garr[i1 & 7u])) goto L3;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(unsigned char)(unsigned)(p2 && u0) >= (int)(unsigned)d0));
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)((unsigned)b0 < (unsigned)f0) < (int)0xffffffffu), (unsigned)!(unsigned)((short)garr[i1 & 7u] > (signed char)(p0 % (a0[i0 & 3u] | 1u))), (unsigned)(0xffffffffu == u1)); }
    if (((unsigned)h0 / (p1 | 1u))) {
        d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)d0 * p0) && p2) & 1023u);
    }
    u0 ^= (unsigned)((int)(unsigned)s1 >= (int)(a0[u1 & 3u] | p2));
    c1 = (signed char)1u;
    while (i0++ < 7u && (unsigned)f0) { if (--fuel == 0u) goto done;
        if (0x10000u) break;
        L2: if (--fuel == 0u) goto done;
        m0 ^= (u2 + ((unsigned)(x0 >> 70) - u1));
    }
    garr[((unsigned)d0 | garr[u2 & 7u]) & 7u] = (unsigned)((int)2u < (int)0x10000u);
    if ((unsigned)(w0 >> 29)) goto L2;
    u0 ^= (0xf38f8d07u % (0xe914095cu | 1u));
    if ((unsigned)((short)(unsigned)((short)0u > (signed char)0x7fffffffu) > (signed char)0x80000000u)) goto L0;
    if ((unsigned)(6u || 0x80000000u)) goto L4;
    do { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (unsigned)(-(unsigned)((short)a0[u1 & 3u] > (signed char)g0) < (unsigned)h0);
        if ((r0.y / (((unsigned)h1 * (unsigned)d0) | 1u))) {
            { unsigned t0; double z0; if (((unsigned)((int)v0 < (int)(unsigned)d0)) & 1u) { t0 = (unsigned)((int)0x902128a7u >= (int)i0); z0 = (double)(((unsigned)(signed char)(unsigned)(*q0 == (unsigned)(w0 >> 29))) & 255u); } if (((unsigned)((int)v0 < (int)(unsigned)d0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)((unsigned)d0 * p0) << ((unsigned)((unsigned)(*q0 < (unsigned)d0) < (4u - (unsigned)((int)m0 >= (int)0x4e9dc3c5u))) & 63u);
                    e0 = e0 * 0.5L + (long double)((unsigned)((int)0xc8cd63c1u >= (int)(unsigned)s1) & 1023u);
                    if ((unsigned)((int)i1 < (int)(unsigned)c1)) break;
                }
                if ((unsigned)!((unsigned)(0xaec5d00u == 0u) ^ (unsigned)l0)) break;
                garr[garr[u2 & 7u] & 7u] = (unsigned)((unsigned)(w0 >> 29) || (((unsigned)e0 | (unsigned)f0) << (i0 & 31u)));
                m0 ^= ((garr[i1 & 7u] - 0x5c3b5b04u) | 6u);
            }
            b0 = ((unsigned)((int)((unsigned)l0 ? 0xd0d93ed9u : r0.y) >= (int)(unsigned)c1) ^ *mp) != 0u;
            if (((unsigned)f0 * (unsigned)e0)) {
                if ((unsigned)((unsigned)(w0 >> 29) < garr[i1 & 7u])) {
                    L3: if (--fuel == 0u) goto done;
                    for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        r0.y ^= (0x4824ec25u ^ (unsigned)h0);
                        continue; (void)((unsigned)((int)u2 < (int)0x64a470c3u));
                        if ((unsigned)(w0 >> 29)) continue;
                    }
                    w0 ^= (unsigned long long)(0x80000000u - (unsigned)(x0 >> 70)) << ((unsigned)!(i0 & (unsigned)f0) & 63u);
                    q0 = &garr[(unsigned)(unsigned char)((unsigned)(i2 || (unsigned)(w0 >> 29)) & (unsigned)e0) & 7u];
                    if ((i1 / ((unsigned)((unsigned)l0 == u0) | 1u))) goto L2;
                }
                if ((unsigned)!(unsigned)((int)0x7a915166u >= (int)(unsigned)h0)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(u1 == 0x283a756bu), (unsigned)(*q0 == 0x7fffffffu), v0); }
                do { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)((int)0x1d24a1c3u >= (int)-((unsigned)(signed char)(6u | 0x16309f10u) ? i1 : p0));
                    i0 = (unsigned)b0 & 15u;
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((p0 / (g1 | 1u)), (unsigned)((unsigned)(x0 >> 70) < (unsigned)((int)0xea41cdaau >= (int)(unsigned)f0)), (unsigned)((unsigned)h1 && (unsigned)f0)); }
                        s0 = (int)(unsigned)((short)*mp > (signed char)i0);
                        if (((garr[u2 & 7u] * (unsigned)e0) - (unsigned)(w0 >> 29))) break;
                        u2 += a0[i0 & 3u];
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)6u < (int)(unsigned)((unsigned)c1 < (unsigned)l0)), ((unsigned)((unsigned)h0 < i2) >> ((unsigned)b0 & 31u)), 0x7fffffffu); }
                    }
                } while (i1++ < 6u && (unsigned)s0);
            }
        } else {
            u1 = u1 * 0x9e3779b1u + (((unsigned)c1 / (u2 | 1u)) & (0xa4ee9e65u / (a0[i0 & 3u] | 1u)));
        }
        L4: if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((1u | g1) || (unsigned)d0), (unsigned)d0, u0); }
                if (budget != 0u) { budget -= 1u; u1 = fn0(((0x10000u | r0.y) >> (a0[i0 & 3u] & 31u)), a0[u1 & 3u], m0); }
            }
            while (3u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)s0 / ((unsigned)d0 | 1u)), 0xd92e1605u, (unsigned)x0); }
                u1 = (unsigned)((short)a0[u1 & 3u] > (signed char)((unsigned)((int)*mp >= (int)(unsigned)(0u || u1)) / (garr[i1 & 7u] | 1u)));
                u1 = u1 * 0x9e3779b1u + 0x36551f77u;
                if (a0[i0 & 3u]) break;
                continue; (void)((unsigned)!((unsigned)c1 + 0xffffffffu));
            }
            w0 ^= (unsigned long long)((unsigned)e0 | (unsigned)c0) << ((u2 ? u3 : (m0 & (unsigned)(unsigned char)(unsigned)(p2 || 9u))) & 63u);
            if (((r0.x & 0xc595ee7eu) % (fuel | 1u))) break;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)d0, (unsigned)(i0 && *q0), ((g0 & 9u) * 2u)); }
        }
        garr[(5u - r0.y) & 7u] = (unsigned)((int)(unsigned)x0 < (int)(unsigned)c0);
        if (((unsigned)(garr[i1 & 7u] && (unsigned)x0) ^ r0.y)) {
            break; (void)(((*mp | u3) >> ((unsigned)e0 & 31u)));
        } else {
            s0 = (int)(unsigned)x0;
            h1 = (unsigned short)(h1 + -(unsigned)((int)(i0 / (u2 | 1u)) < (int)0xffffffffu));
        }
    } while (i0++ < 6u && (a0[u1 & 3u] % (i1 | 1u)));
    if ((unsigned)((unsigned)(a0[u1 & 3u] || 0x2ff76fa5u) || *mp)) goto L0;
    while (i0++ < 7u && (2u ? a0[i0 & 3u] : (unsigned)c1)) { if (--fuel == 0u) goto done;
        switch ((unsigned)((int)(p2 - 0xffffffffu) < (int)3u) & 7u) {
            switch ((0x10000u | (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)h1)) & 7u) {
                switch ((0x10000u * garr[i1 & 7u]) & 7u) {
                    h0 = (short)0x72214975u;
                    case 5u: ;
                }
            }
            e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)b0 < 0x186c55e2u) & 1023u);
            if (*mp) break;
            do { if (--fuel == 0u) goto done;
                case 4u: ;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    case 6u: ;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)(r0.y & 0xffffffffu), (unsigned)(unsigned char)((unsigned)h0 | 0xdd559342u), (*q0 ? (unsigned)w0 : (unsigned)x0)); }
                    x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)b0 - (unsigned)((unsigned)b0 || (unsigned)d0)) || p0);
                    case 1u: ;
                    goto L1;
                    case 0u: ;
                }
            } while (i1++ < 7u && ((unsigned)s0 % (a0[i0 & 3u] | 1u)));
            b0 = (u3 << ((((unsigned)l0 - p2) * (unsigned)c0) & 31u)) != 0u;
        }
        *q0 += ((unsigned)x0 ^ (garr[u2 & 7u] ^ (unsigned)s0));
        if (a0[i0 & 3u]) break;
        e0 = e0 * 0.5L + (long double)(((0x10000u | (unsigned)e0) % ((unsigned)(7u == u1) | 1u)) & 1023u);
        if (5u) {
            r0.x = (unsigned)d0;
        }
    }
    if (((unsigned)l0 & (unsigned)((short)(unsigned)c0 > (signed char)v0))) goto L1;
    if ((unsigned)(signed char)(i0 | (unsigned)s1)) goto L1;
    while (((unsigned)s0 - *q0)) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0(0xffffffffu, (*mp % (((unsigned)x0 & (unsigned)d0) | 1u)), u2); }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            i2 = (unsigned)(garr[u2 & 7u] < 0xaa7c5536u) & 15u;
            u0 = u0 * 0x9e3779b1u + ((unsigned)l0 - (unsigned)(0xffffffffu || u3));
            u3 += u0;
        }
        if (g0) {
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                u1 ^= ((p2 >> (r0.x & 31u)) - u1);
                if ((unsigned)(short)(p1 << ((i0 - (unsigned)s1) & 31u))) {
                    if ((unsigned)((short)0x2d25099fu > (signed char)(unsigned)s0)) continue;
                    if (0xffffffffu) goto L0;
                    if (0xffffffffu) {
                        if ((r0.x * 0x1afbb5adu)) break;
                        if (((unsigned)x0 / ((unsigned)b0 | 1u))) break;
                    } else {
                        while (i2++ < 5u && (unsigned)((int)(unsigned)h1 < (int)(unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                            garr[g1 & 7u] = (unsigned)((int)(0xe3894147u << (p1 & 31u)) >= (int)9u);
                            break; (void)((unsigned)c1);
                        }
                        if (0x7fffffffu) break;
                        if ((0xc063cdaau << ((unsigned)(0u || i2) & 31u))) goto L2;
                        u2 += (unsigned)((8u / ((unsigned)(short)(unsigned)((int)u3 < (int)i1) | 1u)) || 0x10000u);
                    }
                    g1 += (unsigned)((p1 | a0[u1 & 3u]) || 9u);
                    u2 ^= (unsigned)((short)(i0 + (unsigned)x0) > (signed char)(garr[u2 & 7u] << (0xeb43b747u & 31u)));
                    r0.y ^= (unsigned)((int)(u2 / (0xa8b30fbbu | 1u)) >= (int)-(0xffffffffu | p1));
                } else {
                    if (((unsigned)((int)fuel < (int)0x5458464eu) + (unsigned)h0)) break;
                    u1 = (((a0[i0 & 3u] & (unsigned)c1) / (garr[u2 & 7u] | 1u)) & 9u);
                    if (a0[i0 & 3u]) break;
                }
                break; (void)((0x80000000u ? fuel : 0xe136952u));
                h1 = (unsigned short)(h1 + (unsigned)(p1 || (unsigned)(unsigned char)(0x9e30b898u << (u3 & 31u))));
                switch (i2 & 7u) {
                    if ((unsigned)d0) goto L3;
                    while (i2++ < 5u && i1) { if (--fuel == 0u) goto done;
                        case 2u: ;
                        if (u3 == 7u) return ((unsigned)!((unsigned)c0 >> (v0 & 31u)) ? p1 : (unsigned)h1);
                        if ((unsigned)(0x10000u < 0xe3c97bacu)) {
                            g0 = (unsigned)h1;
                            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(w0 >> 29) ^ *mp), (unsigned)((unsigned)(0x3e53d713u || m0) == (unsigned)(x0 >> 70)), r0.x); }
                            c1 = (signed char)i0;
                            s0 = (int)(unsigned)(1u == (unsigned)(w0 >> 29));
                            w0 = w0 * 6364136223846793005ull + a0[i0 & 3u];
                        }
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s1, (unsigned)s1, garr[i1 & 7u]); }
                        q0 = &garr[u3 & 7u];
                        case 4u: ;
                    }
                    w0 ^= (unsigned long long)(u0 ^ i0) << (((p2 % (0xffffffffu | 1u)) % (u3 | 1u)) & 63u);
                    w0 ^= (unsigned long long)0xffffffffu << (((r0.y % ((unsigned)((short)5u > (signed char)a0[i0 & 3u]) | 1u)) >> (r0.x & 31u)) & 63u);
                    break; (void)(u0);
                }
            }
        } else {
            q0 = &garr[0xf08f8b39u & 7u];
            break; (void)((unsigned)x0);
        }
        s1 = (int)((unsigned)s1 + u1);
    }
    do { if (--fuel == 0u) goto done;
        while (i1++ < 3u && (m0 >> (0x80000000u & 31u))) { if (--fuel == 0u) goto done;
            if (r0.y) {
                i2 = (unsigned)!(unsigned)(((unsigned)w0 % ((unsigned)(w0 >> 29) | 1u)) < (unsigned)(0x10000u == 0xffffffffu)) & 15u;
                f0 = f0 * 0.5f + (float)(~(0x15e80388u / (-(unsigned)(m0 < (unsigned)f0) | 1u)) & 255u);
                while (i2++ < 2u && p2) { if (--fuel == 0u) goto done;
                    if ((unsigned)(w0 >> 29)) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((int)p2 < (int)(unsigned)x0) % (a0[i0 & 3u] | 1u)), (0x80000000u - 0xa2033ce4u), (unsigned)(unsigned char)(unsigned)(garr[i1 & 7u] && ((unsigned)(w0 >> 29) / ((unsigned)x0 | 1u)))); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0(~(fuel / (4u | 1u)), (g0 >> (g1 & 31u)), i1); }
                    c0 = (unsigned char)(unsigned)(u3 < (unsigned)c0);
                }
            }
            h0 = (short)((unsigned)((short)(unsigned)((int)0x80000000u < (int)u1) > (signed char)0xffffffffu) / ((unsigned)e0 | 1u));
            if ((unsigned)(short)(r0.y * i1)) break;
            do { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)d0 - p1));
                c1 = (signed char)((0x7fffffffu << ((unsigned)b0 & 31u)) & (0x10000u & (unsigned)((short)6u > (signed char)0xfcf85d27u)));
                break; (void)(0x7fffffffu);
                c1 = (signed char)((unsigned)(0x58c280ccu && *q0) ? r0.y : (0u << (0xffffffffu & 31u)));
                x0 = x0 * 0x100000001b3ull + (*mp / ((unsigned)(unsigned char)(unsigned)((short)(unsigned)(signed char)(unsigned)(0x10000u < (unsigned)(x0 >> 70)) > (signed char)fuel) | 1u));
                q0 = &garr[*mp & 7u];
            } while (i2++ < 5u && (unsigned)((int)0xfc22314cu < (int)a0[i0 & 3u]));
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)h0 * garr[i1 & 7u]), (m0 ? g1 : a0[u1 & 3u]), i0); }
        m0 ^= (((unsigned)c1 & 8u) >> ((u2 << ((unsigned)(short)(u3 ^ (unsigned)h0) & 31u)) & 31u));
        if (((unsigned)b0 & 0xd10a0cdfu)) continue;
    } while (i0++ < 7u && (unsigned)((short)0x2781fad9u > (signed char)i1));
    if (0x10000u) goto L3;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(*q0 == (unsigned)f0), g0, (unsigned)(short)(unsigned)(r0.y || (unsigned)c1)); }
    do { if (--fuel == 0u) goto done;
        u3 = (u3 + i0);
        if ((unsigned)((unsigned)(garr[u2 & 7u] && i0) && u3)) break;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(0xffffffffu < v0), ~(unsigned)(fuel || (unsigned)((int)(unsigned)f0 < (int)r0.y)), (0x80000000u - m0)); }
    } while (i0++ < 6u && i2);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)c1) goto L2;
    l0 = (long)((unsigned long)l0 + ((unsigned)d0 + (0u ^ ((a0[u1 & 3u] & (unsigned)s1) - 0xffffffffu))));
    if ((unsigned)(signed char)(unsigned)((short)(m0 / ((unsigned)(w0 >> 29) | 1u)) > (signed char)0xa783055u)) goto done;
    if ((g1 + (unsigned)(5u == u1))) goto done;
    if ((unsigned)((unsigned)w0 < u1)) goto L1;
    c0 = (unsigned char)(unsigned)((unsigned)(short)(unsigned)((int)p1 < (int)(unsigned)l0) < ((unsigned)((int)(unsigned)l0 >= (int)6u) / (fuel | 1u)));
    h0 = (short)((4u << (g0 & 31u)) ^ (unsigned)(short)(unsigned)(m0 || 0x7fffffffu));
    switch (p2 & 7u) {
        case 7u: ;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1(0u, a0[i0 & 3u], (unsigned)h1); }
    do { if (--fuel == 0u) goto done;
        if ((0x34dca03u & (unsigned)(w0 >> 29))) {
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)s0, (unsigned)((unsigned)e0 || (4u + u2)), (unsigned)(signed char)(fuel % (u2 | 1u))); }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)h0, (0x29f1e1c9u - (unsigned)f0), (2u ^ (unsigned)((int)*q0 < (int)0x7d6f74eeu))); }
        }
        if ((unsigned)(((unsigned)s0 ^ i1) == (unsigned)h1)) {
            h1 = (unsigned short)(h1 + ((a0[i0 & 3u] + m0) / ((unsigned)(unsigned char)(u3 / ((unsigned)((int)0xf57ffdb2u < (int)p0) | 1u)) | 1u)));
            switch ((fuel ^ 7u) & 7u) {
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        switch ((-(g1 + v0) * m0) & 7u) {
                            s0 = (int)i0;
                            case 3u: ;
                            m0 ^= ((0x7fffffffu >> ((unsigned)((int)(unsigned)b0 < (int)(unsigned)(w0 >> 29)) & 31u)) % ((a0[i0 & 3u] * 5u) | 1u));
                            L0: if (--fuel == 0u) goto done;
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn0((0x9235750au & (unsigned)f0), (unsigned)f0, -(unsigned)(i0 && (unsigned)((short)(unsigned)s1 > (signed char)(unsigned)b0))); }
                    }
                    *q0 = (0x430c4e6eu ? (unsigned)d0 : 0xed6631e0u);
                }
                { unsigned t0; double z0; if ((((unsigned)(0x58e28c4bu || (unsigned)s1) / (0x7fffffffu | 1u))) & 1u) { t0 = garr[u2 & 7u]; z0 = (double)((8u) & 255u); } if ((((unsigned)(0x58e28c4bu || (unsigned)s1) / (0x7fffffffu | 1u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                    if ((p0 + p1)) break;
                    f0 = f0 * 0.5f + (float)(6u & 255u);
                    c1 = (signed char)u0;
                    case 0u: ;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(g1, (2u & a0[u1 & 3u]), (unsigned)(i0 == 0x7fffffffu)); }
                }
                i1 = (9u - ((unsigned)(x0 >> 70) >> ((garr[u2 & 7u] >> (a0[u1 & 3u] & 31u)) & 31u))) & 15u;
                l0 = (long)((unsigned long)l0 + (-(p2 / (*mp | 1u)) - (unsigned)s1));
            }
        }
        h0 = (short)(unsigned)((int)r0.y < (int)(unsigned)((short)0xdd197f1au > (signed char)0u));
        if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)l0 < (int)u1)) goto L3;
    } while (i0++ < 7u && (0x10000u ? (unsigned)l0 : 0u));
    w0 ^= (unsigned long long)(unsigned)((int)i0 >= (int)(unsigned)x0) << ((unsigned)((0xfcd12a29u / (7u | 1u)) || r0.x) & 63u);
    c0 = (unsigned char)((0x80000000u >> (a0[i0 & 3u] & 31u)) * 6u);
    if ((unsigned)((unsigned)s0 || (unsigned)w0)) goto L4;
    if ((unsigned)((int)(unsigned)c0 < (int)fuel)) {
        switch ((unsigned)(short)(2u | i1) & 7u) {
            while (i0++ < 2u && (r0.y << ((0xffffffffu >> (0u & 31u)) & 31u))) { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                switch ((unsigned)b0 & 7u) {
                    u3 = (0x9e4a7799u / (((0x8981b833u * (unsigned)w0) / (0xee31d88du | 1u)) | 1u));
                    u3 = (0xb307af62u / ((unsigned)((int)0u < (int)r0.y) | 1u));
                    c1 = (signed char)((garr[u2 & 7u] * m0) | 0x7fffffffu);
                    f0 = f0 * 0.5f + (float)(((unsigned)(0u == (unsigned)(u0 || a0[i0 & 3u])) << (g0 & 31u)) & 255u);
                }
                i0 = ((unsigned)(short)((unsigned)h1 + (unsigned)(w0 >> 29)) % (*q0 | 1u)) & 15u;
                if (budget != 0u) { budget -= 1u; u0 = fn1(0xf2a5ea84u, (unsigned)(signed char)(unsigned)(0xaaa9dbadu == a0[u1 & 3u]), g1); }
            }
            switch ((unsigned)((int)v0 < (int)(unsigned)(w0 >> 29)) & 7u) {
                r0.y ^= ((unsigned)f0 ^ (g0 << ((i0 + 0x10000u) & 31u)));
                for (;;) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        c1 = (signed char)((g0 ^ 0x80000000u) - 0x1e00dc53u);
                    } while (i1++ < 7u && (unsigned)((unsigned)((int)1u >= (int)(unsigned)c0) == 0x312488efu));
                }
            }
            case 0u: ;
            if ((unsigned)b0) break;
            if ((7u >> ((v0 + u1) & 31u))) {
                for (;;) { if (--fuel == 0u) goto done;
                    garr[(unsigned)((int)fuel >= (int)0x7fffffffu) & 7u] = (unsigned)((unsigned)((int)v0 >= (int)0xbcb5ff8cu) == (unsigned)((int)(unsigned)w0 < (int)(unsigned)l0));
                    garr[(0x3fb80527u >> (1u & 31u)) & 7u] = i0;
                    if (((*q0 ^ fuel) * p1)) break;
                }
            } else {
                if (u0) goto L3;
            }
            L2: if (--fuel == 0u) goto done;
        }
        L3: if (--fuel == 0u) goto done;
    } else {
        goto done;
        if (p2) goto L1;
        if ((unsigned)((int)(fuel + i2) >= (int)garr[i1 & 7u])) goto L4;
        L4: if (--fuel == 0u) goto done;
    }
    if ((((unsigned)f0 << (0x26644b71u & 31u)) & g0)) {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)(unsigned)((unsigned)(unsigned char)(*q0 - 0x42f0bfbcu) == (unsigned)c1);
        }
    } else {
        goto L1;
        u2 = (r0.y ? garr[u2 & 7u] : ((unsigned)(x0 >> 70) & garr[i1 & 7u]));
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(((fuel - i2) / ((unsigned)c1 | 1u)));
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (m0) break;
            if (budget != 0u) { budget -= 1u; u1 = fn1((4u ^ garr[i1 & 7u]), ((unsigned)d0 & (unsigned)(u3 && u3)), (unsigned)((short)((unsigned)l0 - r0.x) > (signed char)r0.y)); }
        }
        if ((unsigned)((int)u3 < (int)g0)) continue;
    }
    a0[(u3 / (u0 | 1u)) & 3u] = (unsigned)h1;
    do { if (--fuel == 0u) goto done;
        if (~((unsigned)((int)*mp < (int)0xffffffffu) >> (0x7fffffffu & 31u))) break;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((p1 << (0xeec09d09u & 31u))) break;
        }
        u2 ^= ((g0 / (0xe6191067u | 1u)) % (((unsigned)b0 / (0xf49822fcu | 1u)) | 1u));
    } while (i0++ < 6u && (unsigned)d0);
    r0.y ^= (unsigned)(0xc7653decu == p1);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(short)(unsigned)(5u < p1)) continue;
        g1 += (unsigned)s0;
        garr[((unsigned)d0 & (unsigned)s1) & 7u] = (p0 ^ (unsigned)h1);
    }
    x0 = x0 * 0x100000001b3ull + 0x10000u;
    l0 = (long)((unsigned long)l0 + 0xffffffffu);
    s0 = (int)~(unsigned)(((garr[i1 & 7u] % (r0.x | 1u)) ^ 0xffffffffu) == (unsigned)(unsigned char)(7u << ((unsigned)l0 & 31u)));
    r0.x = (unsigned)s1;
    do { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)((int)(unsigned)(x0 >> 70) < (int)(u3 - p0));
    } while (i0++ < 2u && (g0 >> (*mp & 31u)));
    q0 = &garr[((unsigned)e0 & 8u) & 7u];
    if ((m0 & ((unsigned)b0 & (unsigned)h0))) goto L4;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)(((unsigned)((int)((unsigned)(w0 >> 29) << (v0 & 31u)) < (int)m0) + ((unsigned)f0 >> ((unsigned)(x0 >> 70) & 31u))) & 255u);
    }
    if (0x7fffffffu) goto L4;
    switch ((unsigned)((short)i0 > (signed char)(unsigned)(unsigned char)((unsigned)d0 % (g1 | 1u))) & 7u) {
        w0 ^= (unsigned long long)(unsigned)(u0 == 3u) << ((unsigned)((unsigned)(short)(u0 | 5u) || 7u) & 63u);
        case 2u: ;
        goto L1;
        if ((unsigned)!(u0 | g1)) {
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(((0u ^ p2) | (r0.x << ((unsigned)((unsigned)w0 || p0) & 31u))) & 255u);
                do { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(unsigned)l0 << ((fuel ? (unsigned)(w0 >> 29) : (unsigned)((unsigned)h1 < i2)) & 63u);
                    case 6u: ;
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        u1 = u1 * 0x9e3779b1u + (unsigned)(unsigned char)(unsigned)((short)(8u ^ 0x10000u) > (signed char)0xffffffffu);
                        case 4u: ;
                        case 7u: ;
                        *mp = (unsigned)((0x10000u * 0x1ad62892u) == ((unsigned)w0 - (0xd44fccd0u >> (m0 & 31u))));
                        u3 += (((unsigned)x0 ^ i0) << (0x7c52f989u & 31u));
                    }
                } while (i1++ < 5u && p0);
                if (m0) {
                    default: ;
                    break; (void)((unsigned)(p1 && 0u));
                    h1 = (unsigned short)(h1 + (3u - u0));
                } else {
                    *mp = 1u;
                    r0.x = (unsigned)(unsigned char)(u2 ? a0[u1 & 3u] : (r0.y + (unsigned)(r0.y || 6u)));
                }
                c0 = (unsigned char)(~(unsigned)((0xffffffffu >> (u0 & 31u)) || (unsigned)e0) + a0[u1 & 3u]);
                while (i1++ < 3u && (unsigned)((short)0x7fffffffu > (signed char)0xebf466eu)) { if (--fuel == 0u) goto done;
                    *q0 += (*mp ^ fuel);
                }
                break;
            }
            if ((unsigned)((unsigned)(0xb13a7e81u && r0.y) || 0x10000u)) goto L1;
            { unsigned t1; double z1; if (((unsigned)(unsigned char)(unsigned)(m0 || r0.y)) & 1u) { t1 = (unsigned)((int)(unsigned)((int)u2 >= (int)p0) < (int)r0.x); z1 = (double)(((unsigned)h1) & 255u); } if (((unsigned)(unsigned char)(unsigned)(m0 || r0.y)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                w0 = w0 * 6364136223846793005ull + (unsigned)(r0.y || (u1 - 5u));
                for (;;) { if (--fuel == 0u) goto done;
                    u1 ^= (unsigned)(u0 || (((unsigned)!(garr[u2 & 7u] << (u3 & 31u)) ^ g0) ^ (unsigned)s0));
                    break;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)l0, ((unsigned)f0 ? g1 : u2), (unsigned)((short)(unsigned)!(unsigned)(6u == p0) > (signed char)*mp)); }
                }
                s1 = (int)((unsigned)s1 + ((unsigned)e0 << (p2 & 31u)));
                b0 = (unsigned)h0 != 0u;
                if (garr[u2 & 7u]) {
                    if ((((unsigned)s0 + a0[u1 & 3u]) >> (i1 & 31u))) goto L4;
                    *q0 += u3;
                    switch (((unsigned)b0 / (r0.y | 1u)) & 7u) {
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)s0 | 0xaad147c9u), (unsigned)h1, (unsigned)((int)(garr[i1 & 7u] >> (0u & 31u)) < (int)0x16a92bb7u)); }
                    }
                    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)((int)(unsigned)((short)(unsigned)h0 > (signed char)(unsigned)(x0 >> 70)) < (int)((unsigned)h0 | 0x10000u)) & 1023u);
                    f0 = f0 * 0.5f + (float)((unsigned)((int)u1 < (int)(unsigned)((unsigned)(unsigned char)((unsigned)h1 << (fuel & 31u)) < p0)) & 255u);
                } else {
                    while (-(unsigned)((int)(unsigned)h1 >= (int)0x80000000u)) { if (--fuel == 0u) goto done;
                        case 5u: ;
                        switch (u1 & 7u) {
                            case 3u: ;
                            case 7u: ;
                            default: ;
                        }
                        c0 = (unsigned char)(unsigned)(v0 == (unsigned)((g1 + (unsigned)c0) && a0[u1 & 3u]));
                    }
                    q0 = &garr[((u3 * 0x2aac4502u) ^ 3u) & 7u];
                }
            }
            g1 += (((unsigned)l0 % (i2 | 1u)) & u1);
            if (garr[u2 & 7u]) {
                if ((((unsigned)(x0 >> 70) + 0x6596b19cu) + i0)) goto L0;
                goto L3;
            }
        } else {
            *q0 = (unsigned)((unsigned)!(p2 ? u0 : a0[u1 & 3u]) && u3);
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((0x8d0c132cu ^ 0x7fffffffu)) break;
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    switch (9u & 7u) {
                        if ((unsigned)((short)r0.x > (signed char)1u)) continue;
                        do { if (--fuel == 0u) goto done;
                            w0 ^= (unsigned long long)(2u % (i2 | 1u)) << (((0x66ea4ffcu & i2) * (unsigned)((short)p1 > (signed char)2u)) & 63u);
                            s1 = (int)((unsigned)s1 + (7u | (unsigned)((2u ^ 8u) < g0)));
                            case 6u: ;
                            if (fuel < 8u) return (unsigned)(u0 || ~(0x1eecd9d7u % ((unsigned)h1 | 1u)));
                            case 1u: ;
                        } while (i2++ < 4u && (unsigned)w0);
                        if ((r0.y ^ 0xc74a33d9u)) continue;
                        b0 = (p0 & (unsigned)x0) != 0u;
                        if ((fuel | (unsigned)(*mp && u1))) goto done;
                        g0 = (unsigned)(short)((*q0 >> (0x26d46259u & 31u)) & (unsigned)(signed char)(0xa1852a5eu % (i0 | 1u)));
                    }
                    c1 = (signed char)(unsigned)(4u < (unsigned)((int)8u < (int)u0));
                    switch ((9u ^ 0u) & 7u) {
                        case 2u: ;
                        u1 = -(unsigned)((short)0x2ae43f98u > (signed char)(unsigned)d0);
                        case 4u: ;
                    }
                    g0 = (unsigned)x0;
                    i2 = (0x10000u >> ((unsigned)(short)(unsigned)((int)(0xffffffffu * (unsigned)h0) >= (int)~(r0.x / (r0.x | 1u))) & 31u)) & 15u;
                    i0 = (unsigned)((int)(unsigned)c0 < (int)((p0 << (0x10000u & 31u)) << (i0 & 31u))) & 15u;
                }
            }
        }
        break;
    }
    while (i0++ < 4u && r0.y) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            while (i2++ < 6u && (unsigned)((short)(unsigned)b0 > (signed char)u2)) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)((short)-(a0[i0 & 3u] & 0x7fffffffu) > (signed char)r0.x));
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)s1 == (unsigned)l0)) goto L4;
                    *mp = ((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)d0) << (r0.x & 31u));
                }
                if (2u) break;
                q0 = &garr[(7u % ((unsigned)((int)0x7fffffffu >= (int)0u) | 1u)) & 7u];
                i2 = (((unsigned)f0 ^ (5u & fuel)) ^ (u1 - fuel)) & 15u;
                if ((unsigned)((short)(g0 * (unsigned)x0) > (signed char)g0)) break;
            }
            if ((-(p1 + 0xffffffffu) - 0x10000u)) goto L4;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(0x15ec6aadu == 0x7fffffffu), (((unsigned)e0 >> (0x1d9ff73au & 31u)) ^ 0x1ab8582cu), u1); }
            goto L4;
            if ((p0 << (0x10000u & 31u))) break;
            while (i2++ < 2u && 4u) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    q0 = &garr[(unsigned)(unsigned char)(unsigned)((int)p1 >= (int)(unsigned)b0) & 7u];
                }
                if (((0xffffffffu >> (0x92d37416u & 31u)) + (unsigned)c0)) {
                    h0 = (short)((unsigned)((int)0x7fffffffu < (int)0x7fffffffu) * (unsigned)(short)(i2 >> (((unsigned)l0 - 7u) & 31u)));
                    if (a0[u1 & 3u]) continue;
                    break; (void)((r0.x << (v0 & 31u)));
                    if (budget != 0u) { budget -= 1u; u0 = fn0(8u, (unsigned)(p2 < (p1 + 9u)), (unsigned)((int)(unsigned)((unsigned)s0 && (unsigned)b0) < (int)u0)); }
                    goto L1;
                } else {
                    if (((unsigned)(x0 >> 70) >> ((r0.x << (2u & 31u)) & 31u))) goto L4;
                    if ((unsigned)((int)(unsigned)e0 >= (int)((unsigned)s0 / (a0[u1 & 3u] | 1u)))) break;
                    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        while (i1++ < 3u && u2) { if (--fuel == 0u) goto done;
                            if (((fuel * 0x9ce41326u) ^ r0.x)) goto L4;
                            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(g1 && (unsigned)(w0 >> 29)) && 4u) & 1023u);
                            if (budget != 0u) { budget -= 1u; u3 = fn1((a0[u1 & 3u] / ((unsigned)(r0.y == (unsigned)s1) | 1u)), (((unsigned)b0 | i0) + (unsigned)h0), 0x7fffffffu); }
                        }
                        goto L0;
                        { unsigned t2; double z2; if ((-(0x8cd3b45au - m0)) & 1u) { t2 = (unsigned)((int)(unsigned)(x0 >> 70) < (int)v0); z2 = (double)(((unsigned)(short)(fuel | 0x7fffffffu)) & 255u); } if ((-(0x8cd3b45au - m0)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                            q0 = &garr[(((unsigned)s0 ^ 7u) - 0x7fffffffu) & 7u];
                        }
                        d0 = d0 * 0.5 + (double)((a0[u1 & 3u] - (unsigned)w0) & 1023u);
                    }
                    r0.x = (unsigned)(signed char)(unsigned)((r0.x * p0) == m0);
                }
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1(-((0x10000u ^ (unsigned)d0) / ((unsigned)s0 | 1u)), (unsigned)((short)garr[u2 & 7u] > (signed char)*mp), (unsigned)((short)u2 > (signed char)(0xffffffffu % ((unsigned)(w0 >> 29) | 1u)))); }
    if (0x10000u) {
        goto L4;
        if (fuel) goto L0;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    if ((unsigned)!(a0[i0 & 3u] | (unsigned)l0)) goto L1;
    *mp = ((unsigned)((int)0x959acf39u < (int)(unsigned)f0) * 0x54e4c585u);
    w0 ^= (unsigned long long)garr[i1 & 7u] << (((unsigned)((short)i0 > (signed char)0x7fffffffu) & (unsigned)((int)p1 >= (int)(unsigned)d0)) & 63u);
    *q0 += ((unsigned)h0 & (unsigned)((unsigned)x0 == 4u));
    goto L1;
    if (budget != 0u) { budget -= 1u; u2 = fn1((u0 % ((unsigned)((unsigned)h0 || a0[i0 & 3u]) | 1u)), (unsigned)d0, -(unsigned)((u0 & (unsigned)d0) < *q0)); }
    if ((unsigned)(6u || (unsigned)(x0 >> 70))) {
        u0 = (p0 ? (unsigned)((int)(unsigned)((unsigned)(x0 >> 70) && 9u) >= (int)0x7fffffffu) : (unsigned)(x0 >> 70));
        c1 = (signed char)(u1 + ((r0.y % (r0.x | 1u)) % ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)u2) | 1u)));
    } else {
        u3 = u3 * 0x9e3779b1u + (unsigned)(a0[u1 & 3u] || p2);
        r0.x = u3;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)s0, (unsigned)(signed char)(unsigned)((int)(unsigned)f0 < (int)a0[u1 & 3u]), (unsigned)l0); }
    if ((unsigned)(u1 && i2)) goto L3;
    while (i0++ < 2u && a0[i0 & 3u]) { if (--fuel == 0u) goto done;
        if ((m0 & 2u)) {
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(0x67da9414u == u2), (unsigned)e0, (p1 % (9u | 1u))); }
        } else {
            l0 = (long)((unsigned long)l0 + (fuel << ((unsigned)(signed char)(garr[u2 & 7u] ? (a0[i0 & 3u] >> (i2 & 31u)) : 6u) & 31u)));
            h0 = (short)(0x7adc3534u + (p2 - 3u));
            e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)d0 && (0x25712ad9u % ((unsigned)((unsigned)s1 == r0.y) | 1u))) & 1023u);
        }
    }
    r0.y ^= p2;
    if (fuel < 8u) return (i2 * (0x80000000u % (r0.y | 1u)));
    h0 = (short)(unsigned)((unsigned)((int)(unsigned)f0 < (int)p2) && (unsigned)l0);
    d0 = d0 * 0.5 + (double)((i1 << ((unsigned)h0 & 31u)) & 1023u);
    d0 = d0 * 0.5 + (double)((unsigned)((unsigned)e0 && u2) & 1023u);
    L1: if (--fuel == 0u) goto done;
    r0.y ^= (9u << ((unsigned)((0xffffffffu ^ 0xffffffffu) == u2) & 31u));
    goto done;
    u1 ^= ((unsigned)(a0[i0 & 3u] && (unsigned)s1) << ((unsigned)h0 & 31u));
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(g1 * g1) >= (int)3u), (4u | 0xd7dea350u), (unsigned)((short)(unsigned)((unsigned)c0 || (unsigned)e0) > (signed char)(unsigned)x0)); }
    goto L1;
    do { if (--fuel == 0u) goto done;
        { unsigned t0; double z0; if (((0x6843a497u << (p2 & 31u))) & 1u) { t0 = (unsigned)((unsigned)(0x2c786d42u && 8u) || garr[i1 & 7u]); z0 = (double)(((unsigned)((int)(unsigned)((int)g0 < (int)(unsigned)l0) < (int)0xaddbdfa1u)) & 255u); } if (((0x6843a497u << (p2 & 31u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            w0 = w0 * 6364136223846793005ull + ((unsigned)(x0 >> 70) - 2u);
            g1 += ((r0.x | (unsigned)w0) + (unsigned)((int)r0.y < (int)0xffffffffu));
            r0.y ^= (((unsigned)h0 % (r0.y | 1u)) << (a0[u1 & 3u] & 31u));
            a0[r0.y & 3u] = (m0 & p1);
            do { if (--fuel == 0u) goto done;
                if (0x7fffffffu) break;
                if (budget != 0u) { budget -= 1u; u0 = fn2(0xc5c6fbcau, (unsigned)((short)m0 > (signed char)0xb787be4cu), (unsigned)((unsigned)(fuel == 0x7fffffffu) && 0x80000000u)); }
                u0 = *mp;
                if ((p2 << ((unsigned)((short)garr[u2 & 7u] > (signed char)g1) & 31u))) {
                    for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        a0[0x8f1fbfc1u & 3u] = (unsigned)((0x95a02905u / (2u | 1u)) && (unsigned)s1);
                        switch ((unsigned)(signed char)((unsigned)c1 * (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)h1)) & 7u) {
                            if ((0x7fffffffu + v0)) goto L2;
                            L2: if (--fuel == 0u) goto done;
                            s0 = (int)(unsigned)((int)(unsigned)c0 >= (int)(unsigned)((int)i0 >= (int)0x10000u));
                            if (budget != 0u) { budget -= 1u; u1 = fn0((0xffffffffu % (0x17b917f2u | 1u)), (p1 >> ((p0 / (p2 | 1u)) & 31u)), ((unsigned)((int)0x30daf9cdu >= (int)9u) % ((unsigned)s1 | 1u))); }
                        }
                        if ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)((unsigned)e0 * 0u))) goto done;
                        w0 = w0 * 6364136223846793005ull + (unsigned)(short)(*q0 & *q0);
                    }
                } else {
                    if (~(unsigned)(i0 == 3u)) break;
                    while (i2++ < 4u && -(3u ? i2 : g1)) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(4u, (unsigned)(r0.y == ((unsigned)b0 | 1u)), 0x8a112ea6u); }
                        u2 = u2 * 0x9e3779b1u + (0xbed377u * (unsigned)(unsigned char)(unsigned)((int)(unsigned)d0 >= (int)g0));
                        if (budget != 0u) { budget -= 1u; u1 = fn2((1u / (u2 | 1u)), (unsigned)!((u0 % ((unsigned)f0 | 1u)) >> ((unsigned)d0 & 31u)), (unsigned)((short)7u > (signed char)g1)); }
                        r0.y ^= ((unsigned)(x0 >> 70) ? 0x10000u : ((unsigned)e0 ^ (unsigned)((short)u3 > (signed char)(unsigned)e0)));
                        { unsigned t1; double z1; if (((garr[u2 & 7u] * 8u)) & 1u) { t1 = g0; z1 = (double)((8u) & 255u); } if (((garr[u2 & 7u] * 8u)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                            L3: if (--fuel == 0u) goto done;
                        }
                        u1 = u1 * 0x9e3779b1u + ((unsigned)(0u < 0x8d51ae8eu) ^ (unsigned)(v0 || (unsigned)f0));
                    }
                    break; (void)(((unsigned)h0 + 0x7fffffffu));
                }
                d0 = d0 * 0.5 + (double)(((r0.y / (3u | 1u)) | g0) & 1023u);
            } while (i1++ < 2u && (unsigned)f0);
        }
        if ((unsigned)(unsigned char)((unsigned)e0 ^ garr[u2 & 7u])) break;
    } while (i0++ < 6u && (i1 | g1));
    while (i0++ < 2u && (unsigned)((unsigned)(*q0 == 0xe3d10719u) < (unsigned)c1)) { if (--fuel == 0u) goto done;
        u3 = (unsigned)(0x94fa2152u && r0.x);
        if (0x10000u) break;
    }
    s0 = (int)(3u + (unsigned)((short)u0 > (signed char)i0));
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)0x3a3bd329u < (int)(unsigned)(0x7fffffffu < g1)), i2, (unsigned)((unsigned)l0 == 0xffffffffu)); }
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(((unsigned)l0 - 2u) || (unsigned)(x0 >> 70)), (u0 >> (0x10000u & 31u)), (unsigned)(signed char)(unsigned)(7u || (unsigned)l0)); }
    if ((unsigned)((unsigned)h1 && (unsigned)s0)) goto L4;
    goto L4;
    m0 ^= ((unsigned)((int)(unsigned)(x0 >> 70) < (int)0x10000u) ^ (i0 << ((p2 % (*mp | 1u)) & 31u)));
    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((int)(unsigned)(1u == r0.y) < (int)-(unsigned)((unsigned)d0 < *mp)) || 0x7fffffffu) & 255u);
    if (u1) {
        if ((unsigned)s0) goto done;
    } else {
        if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)((unsigned)x0 == (unsigned)w0) / (5u | 1u)), (unsigned)s0, g1); }
    }
    *q0 = (0xe7ddf223u >> ((unsigned)(short)(unsigned)(u0 == (unsigned)(signed char)(u1 + 0x10000u)) & 31u));
    x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)(0x80000000u || (unsigned)(p1 == 0x80000000u)) > (signed char)r0.y);
    if (budget != 0u) { budget -= 1u; u1 = fn2((0x80000000u / ((unsigned)e0 | 1u)), (9u ^ ((unsigned)d0 * (unsigned)(x0 >> 70))), 0x80000000u); }
    if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)!(unsigned)(r0.x || (unsigned)h0) ^ (unsigned)h1), (unsigned)((int)(unsigned)((int)u2 < (int)garr[i1 & 7u]) >= (int)(unsigned)s1), (unsigned)((short)(unsigned)(*q0 == i2) > (signed char)i1)); }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            v0 = (r0.x + (unsigned)h1);
            if ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)(v0 == a0[i0 & 3u]))) {
                garr[0xbaa32b66u & 7u] = 1u;
                if (((unsigned)d0 % (a0[u1 & 3u] | 1u))) goto done;
                c0 = (unsigned char)(unsigned)f0;
            }
            do { if (--fuel == 0u) goto done;
                a0[p2 & 3u] = ((i1 % ((i0 & p1) | 1u)) * (g0 * 0x10000u));
                L4: if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (0x80000000u * 0x6bbe6441u));
                if (budget != 0u) { budget -= 1u; u0 = fn1((5u + (unsigned)d0), (*mp * ((unsigned)s0 | 3u)), (p2 << ((v0 >> (0xffffffffu & 31u)) & 31u))); }
            } while (i2++ < 7u && (unsigned)((short)p0 > (signed char)(unsigned)((int)(unsigned)h1 >= (int)0x7fffffffu)));
            if ((unsigned)(unsigned char)(u0 | r0.x)) break;
        } while (i1++ < 3u && (unsigned)b0);
        g0 = -((unsigned)((int)(unsigned)s0 < (int)0xffffffffu) / ((unsigned)l0 | 1u));
        if (budget != 0u) { budget -= 1u; u0 = fn2(~(1u | g0), (unsigned)((int)-(unsigned)(0x10000u < garr[u2 & 7u]) < (int)(unsigned)(w0 >> 29)), 1u); }
    }
    goto done;
    if ((unsigned)b0) {
        c0 = (unsigned char)(((unsigned)s1 ^ (unsigned)h0) + p2);
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2(p0, (unsigned)((short)0x611fab51u > (signed char)(unsigned)s1), (unsigned)((int)(3u % (0xffffffffu | 1u)) >= (int)(unsigned)c0)); }
                if ((unsigned)((int)0x89645de8u >= (int)(unsigned)((int)p1 < (int)(unsigned)b0))) {
                    u1 ^= i2;
                    if ((unsigned)((unsigned)f0 == (0x80a219a3u >> (0x8c8feb40u & 31u)))) break;
                    break; (void)((0xffffffffu ? (unsigned)c0 : p1));
                } else {
                    w0 = w0 * 6364136223846793005ull + (((unsigned)e0 + i2) + (unsigned)s0);
                    break; (void)((unsigned)(unsigned char)(unsigned)(g1 || (unsigned)(w0 >> 29)));
                }
                do { if (--fuel == 0u) goto done;
                    *mp = ((5u << (2u & 31u)) ? i2 : (unsigned)(unsigned char)((unsigned)w0 % (9u | 1u)));
                    break; (void)((m0 * u1));
                } while (i2++ < 3u && (u1 % (0x80000000u | 1u)));
            }
            l0 = (long)((unsigned long)l0 + 0x80000000u);
            if (u0) break;
            h0 = (short)(unsigned)((int)(unsigned)s0 < (int)((unsigned)s0 & (unsigned)(0xb14e84ebu < (unsigned)e0)));
            for (;;) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)!(unsigned)((5u >> (g0 & 31u)) == 0x80000000u));
                l0 = (long)((unsigned long)l0 + (unsigned)((u3 >> (0x10000u & 31u)) == ((unsigned)(w0 >> 29) >> (0xffffffffu & 31u))));
            }
            if ((unsigned)s0) {
                continue; (void)((unsigned)(x0 >> 70));
                w0 = w0 * 6364136223846793005ull + (9u & (unsigned)((unsigned)((int)0x7fffffffu < (int)g0) == garr[i1 & 7u]));
                w0 = w0 * 6364136223846793005ull + (0xc60cb3c0u + a0[u1 & 3u]);
                u3 = u3 * 0x9e3779b1u + (((unsigned)(w0 >> 29) ? 0x614ef9fcu : 0x5dfe2032u) / (u1 | 1u));
                u2 += ((unsigned)l0 << (i1 & 31u));
                if (budget != 0u) { budget -= 1u; u1 = fn2((2u | (unsigned)(unsigned char)((unsigned)w0 >> (g0 & 31u))), (unsigned)h1, (unsigned)(short)(unsigned)((short)0x10000u > (signed char)(unsigned)(signed char)(unsigned)(m0 == (unsigned)d0))); }
            } else {
                b0 = (unsigned)((int)(0xa58c21d0u % (~(unsigned)(0xe3cbf987u || v0) | 1u)) < (int)(unsigned)(w0 >> 29)) != 0u;
                if (((unsigned)s0 / ((a0[i0 & 3u] - v0) | 1u))) break;
                if ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)w0)) {
                    h0 = (short)(unsigned)(short)((unsigned)((int)*q0 >= (int)garr[i1 & 7u]) | a0[i0 & 3u]);
                    if ((unsigned)((int)(unsigned)((int)p1 >= (int)(unsigned)(w0 >> 29)) >= (int)(unsigned)f0)) break;
                    l0 = (long)((unsigned long)l0 + (garr[i1 & 7u] % (m0 | 1u)));
                }
            }
        }
    }
    v0 = (0xdebf422eu << (((unsigned)(w0 >> 29) - 5u) & 31u));
    goto L3;
    s0 = (int)(unsigned)((int)r0.x >= (int)((r0.y / (a0[u1 & 3u] | 1u)) | (*mp & 0xeda20fd8u)));
    goto L3;
    goto done;
    if ((0x7fffffffu % ((unsigned)c1 | 1u))) goto L2;
    for (;;) { if (--fuel == 0u) goto done;
        switch (~(((unsigned)e0 ^ 0xea792aabu) % (0u | 1u)) & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn1((1u >> ((0x77ee92cbu * 0xffffffffu) & 31u)), (0x80000000u / ((unsigned)h1 | 1u)), (unsigned)((int)(unsigned)d0 < (int)(unsigned)(r0.x || (unsigned)h1))); }
            b0 = (unsigned)((short)((unsigned)x0 + (unsigned)s1) > (signed char)(unsigned)w0) != 0u;
            d0 = d0 * 0.5 + (double)(((unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)((short)1u > (signed char)g0)) + 6u) & 1023u);
            if (budget != 0u) { budget -= 1u; u1 = fn1(0xab774f1fu, fuel, ((unsigned)w0 + (unsigned)b0)); }
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)h1, ((unsigned)d0 | ((unsigned)x0 / (0x7fffffffu | 1u))), (-(0x7ddb81c5u & u3) & 0x84ed5dbeu)); }
            if (r0.x) {
                h0 = (short)u3;
                if (u3 == 7u) return (unsigned)((unsigned)h0 && (g1 | garr[i1 & 7u]));
                while (i1++ < 2u && 0x711abc7au) { if (--fuel == 0u) goto done;
                    break; (void)(-(unsigned)((0x3a58d271u * 0x8b607f60u) && g0));
                    u1 = ((*q0 & (unsigned)(i2 == 0x29c518dau)) - g0);
                    w0 ^= (unsigned long long)(v0 ^ 0xffffffffu) << (a0[i0 & 3u] & 63u);
                    if (p0) continue;
                    break; (void)(0x80000000u);
                }
                { unsigned t2; double z2; if (((0xeabfd8b7u | 0xffffffffu)) & 1u) { t2 = (unsigned)w0; z2 = (double)(((unsigned)((int)0x18c7f5f6u < (int)(unsigned)w0)) & 255u); } if (((0xeabfd8b7u | 0xffffffffu)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    while (i1++ < 3u && (garr[u2 & 7u] ^ (unsigned)(short)(unsigned)(0x2be7d052u == (unsigned)h0))) { if (--fuel == 0u) goto done;
                        g0 = (unsigned)(signed char)(unsigned)((int)(unsigned)((p2 ? p0 : (unsigned)h0) && i1) < (int)u0);
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(0xcbb0a9a0u ^ 0xdc5e8b36u), (unsigned)!(0xffffffffu + (unsigned)(signed char)(unsigned)((int)(unsigned)x0 >= (int)i2)), g0); }
                        g0 = (0xffffffffu * u1);
                        case 6u: ;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((p2 ? u2 : v0), (unsigned)((v0 * u2) == (unsigned)c0), ((unsigned)s0 - (unsigned)h1)); }
                        g0 = (unsigned)(g1 < 0u);
                    }
                    r0.x = (~((3u - 0x7688c1e9u) + (unsigned)c1) ^ i1);
                    if ((unsigned)(short)(unsigned)((3u * (unsigned)(x0 >> 70)) || (unsigned)s1)) {
                        f0 = f0 * 0.5f + (float)((unsigned)((short)5u > (signed char)((4u + g1) * (unsigned)(w0 >> 29))) & 255u);
                        h0 = (short)((u3 + 0xe98d96eu) << ((0xaf25b2c6u & g0) & 31u));
                    } else {
                        case 4u: ;
                        a0[0x7fffffffu & 3u] = (unsigned)x0;
                        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(*mp < (p0 & g0)) == v0));
                        c1 = (signed char)((unsigned)(signed char)(i1 & ((unsigned)l0 ^ (unsigned)(x0 >> 70))) / ((g1 ^ (unsigned)h1) | 1u));
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(signed char)(unsigned)((short)u1 > (signed char)p2) == p2), u2, p2); }
                }
                if ((unsigned)(0x1fa9013du && (unsigned)((short)i1 > (signed char)(unsigned)x0))) goto L4;
            } else {
                case 2u: ;
                case 7u: ;
                q0 = &garr[((unsigned)x0 * (unsigned)(signed char)((0x10000u << ((unsigned)h0 & 31u)) ? 0x80000000u : (unsigned)c0)) & 7u];
                if ((0x80000000u % (a0[u1 & 3u] | 1u))) {
                    case 0u: ;
                    d0 = d0 * 0.5 + (double)((((unsigned)h0 & v0) * (unsigned)b0) & 1023u);
                    if ((unsigned)((int)garr[i1 & 7u] >= (int)g0)) break;
                } else {
                    a0[0x6159779fu & 3u] = (unsigned)((int)(unsigned)((r0.y - 0x80000000u) || u1) < (int)0u);
                    goto L1;
                }
            }
        }
        switch ((m0 + a0[u1 & 3u]) & 7u) {
            if ((unsigned)(5u < (unsigned)w0)) {
                if (0x6e936435u) {
                    d0 = d0 * 0.5 + (double)(((unsigned)(0x7fffffffu || 0xffffffffu) * (unsigned)h0) & 1023u);
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + -(((unsigned)s1 - (unsigned)(u1 || a0[i0 & 3u])) >> (0x706934a3u & 31u)));
                        case 1u: ;
                        u1 = u1 * 0x9e3779b1u + (((unsigned)w0 & 7u) >> ((unsigned)((int)(unsigned)((short)(unsigned)h0 > (signed char)(unsigned)c1) >= (int)fuel) & 31u));
                    }
                    f0 = f0 * 0.5f + (float)((r0.x & ((unsigned)e0 >> ((v0 + 0x99cd9611u) & 31u))) & 255u);
                }
                if ((unsigned)!(r0.x | (unsigned)x0)) break;
                while ((unsigned)((unsigned)(p2 < 0x7fffffffu) == u3)) { if (--fuel == 0u) goto done;
                    if (((unsigned)(x0 >> 70) % (5u | 1u))) continue;
                    goto L3;
                    *mp = garr[i1 & 7u];
                    u2 = (unsigned)(signed char)(unsigned)((unsigned)(short)(unsigned)((unsigned)((unsigned)f0 < p1) && u3) || (p0 / (1u | 1u)));
                    g1 += (unsigned)(((3u << (u2 & 31u)) ^ ((unsigned)f0 | a0[u1 & 3u])) && 0xa9e490d9u);
                }
                b0 = 0x80000000u != 0u;
                if ((unsigned)((unsigned)e0 && p2)) {
                    m0 ^= ((p0 | *q0) ? a0[u1 & 3u] : (unsigned)(signed char)((unsigned)f0 % (i2 | 1u)));
                    case 2u: ;
                    case 3u: ;
                    case 6u: ;
                    case 5u: ;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)9u >= (int)0xffffffffu), 0x411ecc37u, (unsigned)s0); }
            }
        }
        s0 = (int)(g1 - ~(unsigned)((int)(unsigned)((short)p2 > (signed char)i1) >= (int)(g0 >> (garr[u2 & 7u] & 31u))));
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t3; double z3; if (((unsigned)(m0 && (a0[u1 & 3u] % ((unsigned)b0 | 1u)))) & 1u) { t3 = (r0.y | 0xffffffffu); z3 = (double)(((unsigned)(unsigned char)(0u << (((unsigned)c1 * 0x2e4a9e2bu) & 31u))) & 255u); } if (((unsigned)(m0 && (a0[u1 & 3u] % ((unsigned)b0 | 1u)))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                x0 = x0 * 0x100000001b3ull + i0;
                do { if (--fuel == 0u) goto done;
                    { unsigned t4; double z4; if (((unsigned)!(g1 * a0[u1 & 3u])) & 1u) { t4 = (fuel ? g1 : (unsigned)l0); z4 = (double)((p2) & 255u); } if (((unsigned)!(g1 * a0[u1 & 3u])) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                        break; (void)(garr[i1 & 7u]);
                    }
                    if ((p0 + *q0)) continue;
                } while (i2++ < 3u && (unsigned)(w0 >> 29));
                u3 = u3 * 0x9e3779b1u + (unsigned)((int)(unsigned)(8u && *mp) >= (int)u0);
                *q0 = ((unsigned)(x0 >> 70) % (i1 | 1u));
                garr[(unsigned)((unsigned)(x0 >> 70) || p1) & 7u] = (unsigned)((int)0x545d0631u >= (int)(unsigned)(x0 >> 70));
                do { if (--fuel == 0u) goto done;
                    c1 = (signed char)((1u / ((unsigned)(unsigned char)(unsigned)((short)(unsigned)d0 > (signed char)p1) | 1u)) | 0x1e10b429u);
                    if (budget != 0u) { budget -= 1u; u1 = fn0(g0, v0, (unsigned)((unsigned)l0 < (g1 << (fuel & 31u)))); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0(0xf9596349u, (v0 | (unsigned)((int)2u >= (int)0u)), (~((unsigned)f0 | (unsigned)w0) - i0)); }
                    break; (void)((unsigned)((short)0x7fffffffu > (signed char)(unsigned)((int)p1 >= (int)0x729a94bcu)));
                } while (i2++ < 5u && (0x1a842d8cu - 0xf1310636u));
            }
            if (budget != 0u) { budget -= 1u; u1 = fn2((p2 << ((unsigned)d0 & 31u)), (3u - 0xc98506a1u), (unsigned)(unsigned char)((unsigned)(w0 >> 29) & (p2 % ((unsigned)w0 | 1u)))); }
        }
        if (((unsigned)e0 * 5u)) goto L2;
    }
    r0.x = ((unsigned)f0 ^ -(unsigned)((short)(0x10000u - (unsigned)s0) > (signed char)(unsigned)h0));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *q0 += u3;
    do { if (--fuel == 0u) goto done;
        if (0xffffffffu) {
            g0 = (((unsigned)(i1 || m0) << ((r0.y / (g1 | 1u)) & 31u)) % (0x3ab4d8e2u | 1u));
            { unsigned t0; double z0; if ((((unsigned)(short)((unsigned)e0 + i2) ^ 0xc84026beu)) & 1u) { t0 = ((u1 - i0) | a0[u1 & 3u]); z0 = (double)((p0) & 255u); } if ((((unsigned)(short)((unsigned)e0 + i2) ^ 0xc84026beu)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                c1 = (signed char)(unsigned)(signed char)((unsigned)((int)u2 >= (int)1u) << (*q0 & 31u));
                if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)s0, (unsigned)((int)(unsigned)f0 < (int)0u), ((u1 & p1) >> (*mp & 31u))); }
            }
            r0.x = (unsigned)((unsigned)(w0 >> 29) < 0x14613e04u);
            if ((0x7fffffffu >> (-(unsigned)(r0.x || garr[u2 & 7u]) & 31u))) break;
        } else {
            do { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(*mp || (unsigned)(unsigned char)(0xae914f46u / (a0[u1 & 3u] | 1u))), u1, (unsigned)((short)0x4880555fu > (signed char)(unsigned)((short)0xffffffffu > (signed char)(unsigned)e0))); }
                    g1 += (((unsigned)x0 & garr[u2 & 7u]) % ((0xffffffffu | *mp) | 1u));
                    r0.x = (u1 << (garr[i1 & 7u] & 31u));
                    s1 = (int)((unsigned)s1 + (0x7fffffffu ^ i0));
                    a0[0x8bbbc12u & 3u] = ((unsigned)((short)((unsigned)(x0 >> 70) ^ r0.x) > (signed char)u3) << ((i0 - i0) & 31u));
                    u2 = ((unsigned)(g0 && (unsigned)h0) % ((unsigned)(2u || p2) | 1u));
                } while (i2++ < 3u && (unsigned)((short)r0.x > (signed char)i1));
                L0: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn2(-((unsigned)(signed char)(unsigned)(garr[u2 & 7u] < m0) >> (u2 & 31u)), ((unsigned)(signed char)(unsigned)(*mp < 2u) * 1u), (unsigned)((short)(unsigned)c1 > (signed char)g1)); }
                *q0 = (unsigned)((int)i1 < (int)(unsigned)(short)(unsigned)((int)0x52a4638du < (int)(p0 - 0x7a0c2d25u)));
                g1 += (unsigned)c0;
                while (i2++ < 2u && ((unsigned)(unsigned char)(unsigned)(v0 == i0) * *q0)) { if (--fuel == 0u) goto done;
                    if (0x7fffffffu) {
                        f0 = f0 * 0.5f + (float)((unsigned)((int)u1 < (int)*mp) & 255u);
                        switch ((unsigned)(5u == (unsigned)c1) & 7u) {
                            u0 = ((unsigned)(((unsigned)c0 << (0x42c5c1d5u & 31u)) == (unsigned)!(unsigned)((unsigned)h0 || r0.x)) ^ 3u);
                            x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)((int)i1 >= (int)8u) || (unsigned)w0) >> (((unsigned)l0 >> (a0[u1 & 3u] & 31u)) & 31u));
                            c0 = (unsigned char)((unsigned)d0 / (a0[i0 & 3u] | 1u));
                            if (fuel < 8u) return a0[i0 & 3u];
                            w0 ^= (unsigned long long)0x10000u << (((unsigned)h0 - (unsigned)(0x7fffffffu || u1)) & 63u);
                        }
                    } else {
                        if (budget != 0u) { budget -= 1u; u1 = fn2((0x7f773184u & (a0[u1 & 3u] | p0)), (unsigned)(~(unsigned)(0x382b5a32u && u2) && 0u), (g1 & garr[i1 & 7u])); }
                        if (budget != 0u) { budget -= 1u; u2 = fn0(0x7fffffffu, (unsigned)((short)(p1 | 0x10000u) > (signed char)*mp), a0[i0 & 3u]); }
                        *q0 = (unsigned)((unsigned)(signed char)(unsigned)(-(unsigned)((short)r0.y > (signed char)0x429da106u) && 0x7fffffffu) || (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)f0));
                    }
                    u0 += (unsigned)(garr[u2 & 7u] < (g0 + garr[u2 & 7u]));
                    switch (0x7fffffffu & 7u) {
                        u0 = u0 * 0x9e3779b1u + (unsigned)(unsigned char)(g0 / (((unsigned)(0x3be31bbu < (unsigned)(x0 >> 70)) % (a0[u1 & 3u] | 1u)) | 1u));
                        d0 = d0 * 0.5 + (double)(i0 & 1023u);
                        L1: if (--fuel == 0u) goto done;
                        if (((unsigned)e0 + (unsigned)s1)) continue;
                    }
                    a0[(unsigned)e0 & 3u] = (p2 * 0xffffffffu);
                }
            } while (i1++ < 6u && (r0.y >> ((unsigned)s1 & 31u)));
            if ((unsigned)(w0 >> 29)) break;
            i0 = (unsigned)l0 & 15u;
        }
    } while (i0++ < 2u && (r0.x | (unsigned)h0));
    h0 = (short)a0[u1 & 3u];
    q0 = &garr[(unsigned)(((unsigned)((int)(unsigned)w0 >= (int)0xb59ae354u) ^ 2u) || (7u << (2u & 31u))) & 7u];
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 2u && (((unsigned)c1 >> ((unsigned)w0 & 31u)) / (garr[i1 & 7u] | 1u))) { if (--fuel == 0u) goto done;
            if (((unsigned)c0 * (0u ^ g1))) goto L0;
            if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)(unsigned char)((unsigned)h1 * g1) * (unsigned)h0), ((0xffffffffu >> ((unsigned)e0 & 31u)) - *q0), (*q0 * g0)); }
            r0.y ^= (unsigned)((int)(unsigned)(short)(p1 - (unsigned)h0) >= (int)((unsigned)h1 * m0));
        }
        v0 = (a0[u1 & 3u] * 0x7fffffffu);
    }
    goto L1;
    u3 = u3 * 0x9e3779b1u + ((unsigned)s1 - (unsigned)((short)(unsigned)(short)(unsigned)((unsigned)(7u && 0x80000000u) || *q0) > (signed char)(unsigned)s1));
    v0 = (unsigned)b0;
    c1 = (signed char)((unsigned)(x0 >> 70) + (unsigned)x0);
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (4u | (unsigned)(signed char)(~((unsigned)h1 / (p2 | 1u)) ^ u2)));
        if (-(0x2fa1ab94u / ((unsigned)(1u == (unsigned)d0) | 1u))) break;
        if (((unsigned)(x0 >> 70) << (0x7fffffffu & 31u))) {
            if ((unsigned)f0) goto done;
            { unsigned t1; double z1; if (((unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)f0)) & 1u) { t1 = 0xbe3dfb85u; z1 = (double)(((i1 - 0x10000u)) & 255u); } if (((unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)f0)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                w0 = w0 * 6364136223846793005ull + 0xffffffffu;
                if ((1u - 0x4902ba9fu)) break;
            }
            switch ((unsigned)(u3 == (unsigned)c0) & 7u) {
                case 2u: ;
                L2: if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + ((*q0 << (~(0xffffffffu >> ((unsigned)c1 & 31u)) & 31u)) << (4u & 31u)));
                if (0x10000u) {
                    d0 = d0 * 0.5 + (double)(a0[i0 & 3u] & 1023u);
                    L3: if (--fuel == 0u) goto done;
                    garr[0x80000000u & 7u] = (unsigned)((short)(unsigned)h0 > (signed char)((unsigned)(0x7fffffffu || 0x2d20e851u) ^ i1));
                    d0 = d0 * 0.5 + (double)(((unsigned)(short)(u2 | (unsigned)((int)a0[i0 & 3u] >= (int)0u)) >> ((unsigned)(signed char)((unsigned)c0 / (p1 | 1u)) & 31u)) & 1023u);
                    a0[i1 & 3u] = u1;
                    if (((unsigned)(0x7fffffffu == (unsigned)f0) - 0x7fffffffu)) continue;
                } else {
                    w0 ^= (unsigned long long)(unsigned)((unsigned)(x0 >> 70) && 8u) << (((unsigned)c0 | p1) & 63u);
                    e0 = e0 * 0.5L + (long double)((unsigned)!(unsigned)(((unsigned)(unsigned char)(0x10000u & (unsigned)d0) | (unsigned)f0) && (unsigned)(unsigned char)(i0 & (unsigned)f0)) & 1023u);
                    L4: if (--fuel == 0u) goto done;
                    i1 = (unsigned)(((unsigned)s0 / ((g1 % (i2 | 1u)) | 1u)) && r0.y) & 15u;
                }
                u2 = u2 * 0x9e3779b1u + (r0.x % (*mp | 1u));
                if (budget != 0u) { budget -= 1u; u0 = fn1(p2, (p0 * (unsigned)d0), (0xffffffffu % (a0[u1 & 3u] | 1u))); }
            }
            h0 = (short)(((u2 & (unsigned)x0) ^ p1) * u3);
        } else {
            q0 = &garr[-(a0[i0 & 3u] & (unsigned)(p2 && p2)) & 7u];
            continue; (void)((i2 ? 0x3593955eu : 5u));
        }
    }
    if ((unsigned)(unsigned char)((unsigned)s1 >> ((u1 ^ *q0) & 31u))) {
        switch (((unsigned)b0 >> ((unsigned)d0 & 31u)) & 7u) {
            *q0 += ((unsigned)c0 >> (((i0 * 9u) + (unsigned)((int)r0.y < (int)0x80000000u)) & 31u));
            r0.x = (0xffffffffu | (i2 % (u3 | 1u)));
            s1 = (int)((unsigned)s1 + i1);
        }
    }
    goto L4;
    if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)e0 & 0x65f3197fu), (unsigned)(u3 || garr[u2 & 7u]), (p0 >> ((m0 ^ garr[u2 & 7u]) & 31u))); }
    garr[0x7fffffffu & 7u] = (unsigned)((int)(unsigned)b0 < (int)(unsigned)((unsigned)(i1 < (i2 - (unsigned)s1)) && 0xf71d29c8u));
    { unsigned t2; double z2; if (((unsigned)((unsigned)l0 < p0)) & 1u) { t2 = (unsigned)(unsigned char)(0x48efa15u ^ 0xffffffffu); z2 = (double)(((unsigned)(3u < *mp)) & 255u); } if (((unsigned)((unsigned)l0 < p0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        do { if (--fuel == 0u) goto done;
            switch ((unsigned)l0 & 7u) {
                switch (4u & 7u) {
                    c0 = (unsigned char)((unsigned)((int)0x39f15a74u >= (int)(unsigned)x0) ^ a0[i0 & 3u]);
                    m0 ^= (unsigned)((p0 + (unsigned)w0) == u3);
                    switch ((unsigned)(garr[i1 & 7u] == r0.x) & 7u) {
                        d0 = d0 * 0.5 + (double)(((unsigned)(short)((unsigned)c0 / ((unsigned)b0 | 1u)) >> ((unsigned)(u2 && (unsigned)((int)u3 >= (int)i0)) & 31u)) & 1023u);
                    }
                    if (-(unsigned)((int)u2 >= (int)((unsigned)w0 >> (i2 & 31u)))) break;
                    goto L1;
                    if (u3 == 7u) return (unsigned)(unsigned char)(unsigned)((short)(unsigned)(signed char)(unsigned)(g1 == 0u) > (signed char)(i0 + 0xffffffffu));
                }
            }
            if ((unsigned)(0x80000000u < u2)) goto L0;
        } while (i0++ < 2u && (unsigned)(u2 && (unsigned)l0));
        while (i0++ < 2u && (unsigned)(v0 && 0x7fffffffu)) { if (--fuel == 0u) goto done;
            if (p0) break;
            goto L3;
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(0u && i0), (unsigned)((int)u0 < (int)m0), (u2 >> (0x73af1844u & 31u))); }
                if ((unsigned)(short)(g1 ^ ((unsigned)d0 & u2))) break;
                goto L4;
            }
            if ((unsigned)(0xcfcd0627u == 0xc45cf98fu)) goto L3;
            v0 = (unsigned)(((unsigned)(r0.x < 0xc322a5f4u) % (garr[u2 & 7u] | 1u)) == garr[u2 & 7u]);
        }
        if (((unsigned)h1 - fuel)) {
            e0 = e0 * 0.5L + (long double)(a0[i0 & 3u] & 1023u);
            i1 = (unsigned)(signed char)((unsigned)((int)u2 < (int)r0.x) + (unsigned)((fuel & r0.y) && (unsigned)c0)) & 15u;
            if (u1) goto done;
            h0 = (short)(unsigned)((short)(unsigned)((int)garr[i1 & 7u] < (int)0x8602d6adu) > (signed char)0xeb669b8du);
        } else {
            if (i1) goto L3;
        }
        if (4u) goto L1;
        u0 += (unsigned)(3u || (unsigned)(p1 == (unsigned)c0));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((u1 ^ g0), 0x7fffffffu, (unsigned)(0x53c2c161u == p1)); }
    if ((unsigned)(x0 >> 70)) goto L3;
    if ((unsigned)(*mp == ((unsigned)b0 & u2))) goto L2;
    e0 = e0 * 0.5L + (long double)((unsigned)s0 & 1023u);
    r0.y ^= (unsigned)((int)(unsigned)(signed char)(unsigned)((short)7u > (signed char)0xffffffffu) < (int)i0);
    if (u3 == 7u) return (unsigned)((short)(unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)s0) > (signed char)m0);
    if ((g1 / ((unsigned)(r0.x || 0x10000u) | 1u))) {
        f0 = f0 * 0.5f + (float)(((unsigned)(4u || p1) / ((unsigned)((int)0x7fffffffu >= (int)(unsigned)f0) | 1u)) & 255u);
        *q0 = (unsigned)((0x68cb2a04u - p2) && *mp);
        switch (~(unsigned)((short)(unsigned)!(i1 - 0xffffffffu) > (signed char)p0) & 7u) {
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 1u: ;
            }
        }
    }
    *q0 += -(unsigned)((short)(unsigned)(unsigned char)((unsigned)(w0 >> 29) + (unsigned)l0) > (signed char)((unsigned)e0 | (unsigned)c0));
    if (*q0) goto L1;
    b0 = ((unsigned)((int)(unsigned)(signed char)(u3 >> (garr[u2 & 7u] & 31u)) >= (int)0x6f591f2au) & i1) != 0u;
    { unsigned t3; double z3; if ((-(*q0 - *mp)) & 1u) { t3 = 2u; z3 = (double)((((unsigned)h0 & 3u)) & 255u); } if ((-(*q0 - *mp)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        s0 = (int)(unsigned)(unsigned char)(0x78d1164bu / ((unsigned)((int)6u < (int)(unsigned)b0) | 1u));
    }
    u1 = u1 * 0x9e3779b1u + ((unsigned)(short)(a0[i0 & 3u] ? (unsigned)(w0 >> 29) : r0.y) >> (0x80000000u & 31u));
    if ((9u & 9u)) goto L1;
    h1 = (unsigned short)(h1 + ((unsigned)c0 | a0[u1 & 3u]));
    h1 = (unsigned short)(h1 + (unsigned)((p1 * u3) || (unsigned)(unsigned char)((unsigned)(x0 >> 70) << ((unsigned)d0 & 31u))));
    while (i0++ < 6u && (unsigned)f0) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)0x27116f43u << ((unsigned)(((unsigned)(garr[u2 & 7u] == *mp) * (p2 * v0)) && *q0) & 63u);
        *mp = (g0 | 0x10000u);
        switch (-((v0 & fuel) ^ g0) & 7u) {
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                *mp = ((((fuel ^ r0.x) | (unsigned)d0) | 1u) / (0x80000000u | 1u));
                switch (g1 & 7u) {
                    g0 = ((unsigned)(unsigned char)(0x1531c472u << ((unsigned)e0 & 31u)) % ((unsigned)h0 | 1u));
                }
                *q0 += (unsigned)((short)((unsigned)s0 << (~(unsigned)(g1 || p2) & 31u)) > (signed char)(i1 + 0x954605e7u));
                case 2u: ;
                g1 += (unsigned)((0x80000000u & ((unsigned)(w0 >> 29) ^ u3)) == (unsigned)b0);
            }
            if (((unsigned)(4u < (unsigned)x0) >> (0x27a66d8bu & 31u))) goto done;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1((0xce204562u * u3), (garr[u2 & 7u] / ((unsigned)((short)(unsigned)h1 > (signed char)a0[i0 & 3u]) | 1u)), (p2 | r0.x)); }
        s0 = (int)(unsigned)((int)(i1 + m0) < (int)0x80000000u);
    }
    if (fuel < 8u) return (unsigned)(short)(unsigned)((unsigned)((int)r0.y < (int)7u) || (unsigned)(*mp && (unsigned)l0));
    { unsigned t4; double z4; if ((((unsigned)f0 % (r0.y | 1u))) & 1u) { t4 = (8u | (unsigned)((unsigned)d0 == 0x68417d5cu)); z4 = (double)((i1) & 255u); } if ((((unsigned)f0 % (r0.y | 1u))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        u3 = u3 * 0x9e3779b1u + (unsigned)(signed char)(((unsigned)s0 % (0x549117e3u | 1u)) * *q0);
        if (*mp) goto L1;
        if (m0) goto L2;
        c0 = (unsigned char)((unsigned)(short)(unsigned)((int)g0 < (int)0x80000000u) ^ ((unsigned)((int)(unsigned)f0 >= (int)*mp) ^ p1));
    }
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (i2) {
                u0 = (unsigned)((u0 / (v0 | 1u)) < (a0[u1 & 3u] << (v0 & 31u)));
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)h0, (unsigned)((unsigned)(4u || (unsigned)x0) && *q0), -(unsigned)((int)0xda7ff754u < (int)r0.x)); }
                if (((unsigned)(m0 && garr[i1 & 7u]) << (0xd8f609fcu & 31u))) continue;
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)w0 - (unsigned)(x0 >> 70)), a0[i0 & 3u], (a0[i0 & 3u] % (0x3c5eeef7u | 1u))); }
            } else {
                b0 = (unsigned)h0 != 0u;
                if (((unsigned)d0 & (unsigned)c1)) break;
                if (a0[u1 & 3u]) {
                    if (budget != 0u) { budget -= 1u; u1 = fn2(((p0 * (unsigned)h1) / (0xffffffffu | 1u)), (unsigned)x0, (unsigned)(1u == r0.y)); }
                    e0 = e0 * 0.5L + (long double)((unsigned)(r0.x < ((unsigned)h1 * -(0u & *q0))) & 1023u);
                    l0 = (long)((unsigned long)l0 + 0x10000u);
                } else {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(x0 >> 70), (unsigned)(((unsigned)(w0 >> 29) % (garr[i1 & 7u] | 1u)) || (unsigned)d0), (unsigned)((unsigned)h1 || 0x7d264673u)); }
                }
            }
            l0 = (long)((unsigned long)l0 + (~(unsigned)(3u && (unsigned)(unsigned char)(unsigned)((unsigned)l0 == u1)) ^ (5u - garr[i1 & 7u])));
            break; (void)((unsigned)(unsigned char)((unsigned)(x0 >> 70) - (unsigned)h0));
            if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)s1, ((unsigned)s1 & i2), 6u); }
        } while (i1++ < 5u && 0x7fffffffu);
        u1 = u1 * 0x9e3779b1u + -(7u << ((unsigned)((int)garr[u2 & 7u] >= (int)0xc126745u) & 31u));
        h0 = (short)(0x1812d3dbu ? a0[u1 & 3u] : (unsigned)x0);
    } while (i0++ < 4u && (p0 * 0x1c412dddu));
    f0 = f0 * 0.5f + (float)(r0.y & 255u);
    c1 = (signed char)(((unsigned)x0 ? 3u : (unsigned)(8u == (unsigned)(w0 >> 29))) << (p2 & 31u));
    a0[(unsigned)(*q0 && (unsigned)c1) & 3u] = ((unsigned)(unsigned char)(0xbf4a3da5u ? 0x7fffffffu : (unsigned)(x0 >> 70)) * u2);
    if (budget != 0u) { budget -= 1u; u3 = fn2((i0 >> (0x717eb6e6u & 31u)), garr[u2 & 7u], ((0x549d60e1u ^ v0) % ((unsigned)(x0 >> 70) | 1u))); }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)((unsigned)x0 < 0xcca282ebu) < (int)garr[i1 & 7u])) {
            d0 = d0 * 0.5 + (double)((unsigned)f0 & 1023u);
            if (((unsigned)(a0[i0 & 3u] < i0) << (0xffffffffu & 31u))) break;
            switch (p1 & 7u) {
                m0 ^= (unsigned)(unsigned char)((unsigned)(unsigned char)((unsigned)(8u < (unsigned)(signed char)(unsigned)((short)a0[i0 & 3u] > (signed char)0x80000000u)) / ((unsigned)s0 | 1u)) * 0x6be9d8e2u);
                h0 = (short)(garr[u2 & 7u] + (0x4b386df6u * (unsigned)c0));
                d0 = d0 * 0.5 + (double)(i0 & 1023u);
                u3 = (unsigned)(2u == 4u);
            }
            if ((6u << (0x7fffffffu & 31u))) break;
            while (i1++ < 4u && (unsigned)l0) { if (--fuel == 0u) goto done;
                if (((unsigned)h1 / (v0 | 1u))) goto L1;
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)x0, (unsigned)((int)p0 < (int)(unsigned)s0), ((u0 | a0[u1 & 3u]) - garr[u2 & 7u])); }
                u3 = (unsigned)!((unsigned)h0 ? u0 : p2);
                u3 ^= (p2 << ((r0.y >> ((unsigned)s0 & 31u)) & 31u));
                if (((unsigned)s1 | *mp)) break;
            }
        } else {
            l0 = (long)((unsigned long)l0 + (((unsigned)((int)(unsigned)(x0 >> 70) >= (int)r0.x) >> (((unsigned)w0 / (u3 | 1u)) & 31u)) % (garr[i1 & 7u] | 1u)));
        }
        break; (void)(1u);
    }
    if ((unsigned)(unsigned char)(-(unsigned)(u2 < p1) | i2)) goto L1;
    d0 = d0 * 0.5 + (double)((0xffffffffu * (unsigned)((int)p0 >= (int)0xe999217u)) & 1023u);
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)(p0 || (unsigned)x0) ^ (unsigned)s0)) break;
        s1 = (int)((unsigned)s1 + (unsigned)(garr[i1 & 7u] && (0x7fffffffu << (p1 & 31u))));
        i2 = (unsigned)((short)p1 > (signed char)(unsigned)((unsigned)((unsigned)s0 || (unsigned)s1) || 0xffffffffu)) & 15u;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)d0, 2u, 0xeca051a8u); }
        garr[u0 & 7u] = *mp;
    }
    { unsigned t5; double z5; if ((u0) & 1u) { t5 = p1; z5 = (double)((((unsigned)c0 | 0xffffffffu)) & 255u); } if ((u0) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
        g0 = -((unsigned)s0 % ((unsigned)(short)(~(unsigned)((unsigned)e0 || i2) / (0x42ecc627u | 1u)) | 1u));
        if ((unsigned)((short)0x10000u > (signed char)((unsigned)b0 & 1u))) goto done;
        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(unsigned char)((unsigned)f0 | ~(unsigned)((int)0x80000000u >= (int)0x23c9ef49u)) && 0x10000u) & 1023u);
        h1 = (unsigned short)(h1 + (unsigned)(u3 && i0));
    }
    while (i0++ < 3u && (unsigned)((int)(unsigned)(signed char)(0x3c4feee0u % ((unsigned)c1 | 1u)) < (int)i0)) { if (--fuel == 0u) goto done;
        if (((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)x0) - 0xffffffffu)) break;
    }
    f0 = f0 * 0.5f + (float)(*mp & 255u);
    goto L3;
    goto L3;
    r0.x = ((unsigned)(x0 >> 70) / ((unsigned)(short)(*mp - i1) | 1u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 5u, 0x41233492u, 0x4d11c0ffu },
        { 4u, 0x423f8c43u, 0xefda0b4eu },
        { 15u, 0xc8461198u, 0xa9faa115u },
        { 13u, 0x3f4cdb9u, 0x58c2f932u },
        { 7u, 0x3dacaaddu, 0x2e50daa7u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
