// test-ssa-source's program of seed 134000442 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x6e420297u, g1 = 0xb7652be9u;
static unsigned garr[8] = { 0x3b9f7c5bu, 0xe5380fd0u, 0xcfd911cu, 0x27de0476u, 0x4453e79fu, 0x63256f05u, 0xbfab2596u, 0x5829a7feu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (0x1887dec4u) {
        *mp = ((unsigned)s1 * ((p2 + *mp) - (unsigned)s1));
        while (i0++ < 3u && (unsigned)((r0.y * 7u) == g0)) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((int)(0x7fffffffu / (g0 | 1u)) >= (int)u0) || u3));
            if ((unsigned)((int)7u >= (int)m0)) break;
            { unsigned t0; double z0; if ((((unsigned)w0 * ((unsigned)d0 / (r0.y | 1u)))) & 1u) { t0 = 0xffffffffu; z0 = (double)((v0) & 255u); } if ((((unsigned)w0 * ((unsigned)d0 / (r0.y | 1u)))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                u3 ^= (u1 * fuel);
            }
        }
        while (i0++ < 7u && ((unsigned)x0 >> ((u1 % (fuel | 1u)) & 31u))) { if (--fuel == 0u) goto done;
            v0 = (unsigned)(short)(unsigned)((unsigned)b0 == (unsigned)((0x52e1c133u * 0xffffffffu) < (0xffffffffu >> (u3 & 31u))));
            if (2u) break;
            { unsigned t1; double z1; if (((fuel ^ (*mp - 9u))) & 1u) { t1 = (unsigned)(short)(unsigned)(((unsigned)e0 * 2u) && garr[i1 & 7u]); z1 = (double)((u1) & 255u); } if (((fuel ^ (*mp - 9u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)((short)(unsigned)((int)(unsigned)c0 < (int)(unsigned)((unsigned)s1 && 0x10000u)) > (signed char)i1) > (signed char)0x10000u));
                s1 = (int)((unsigned)s1 + (i0 >> ((unsigned)(signed char)(*q0 - (unsigned)f0) & 31u)));
                g0 = (3u ^ 3u);
                f0 = f0 * 0.5f + (float)(0xdc22cc33u & 255u);
                g0 = ((unsigned)((int)(p0 / (v0 | 1u)) < (int)0x6a9ebd0du) / ((unsigned)((int)(unsigned)f0 >= (int)(unsigned)x0) | 1u));
                if ((unsigned)(u1 == (unsigned)e0)) break;
            }
            h1 = (unsigned short)(h1 + u3);
            { unsigned t2; double z2; if (((unsigned)((short)(unsigned)((int)(unsigned)s1 < (int)a0[u1 & 3u]) > (signed char)(unsigned)(x0 >> 70))) & 1u) { t2 = i1; z2 = (double)((u3) & 255u); } if (((unsigned)((short)(unsigned)((int)(unsigned)s1 < (int)a0[u1 & 3u]) > (signed char)(unsigned)(x0 >> 70))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                break; (void)(u2);
                x0 = x0 * 0x100000001b3ull + (unsigned)!(p2 ? i0 : (p1 + 0x8efb83d3u));
                L0: if (--fuel == 0u) goto done;
                { unsigned t3; double z3; if ((0x3737abfdu) & 1u) { t3 = (unsigned)!((unsigned)h1 % ((unsigned)e0 | 1u)); z3 = (double)(((unsigned)e0) & 255u); } if ((0x3737abfdu) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    L1: if (--fuel == 0u) goto done;
                    b0 = (unsigned)((unsigned)c1 || (((unsigned)s1 / ((unsigned)s0 | 1u)) << ((8u << (g1 & 31u)) & 31u))) != 0u;
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)(0x7fffffffu && (unsigned)b0) < (int)(unsigned)c0);
                }
                L2: if (--fuel == 0u) goto done;
            }
        }
    } else {
        if ((unsigned)!(*mp * i0)) goto L4;
        v0 = (unsigned)((short)p2 > (signed char)0xffffffffu);
        L3: if (--fuel == 0u) goto done;
    }
    if ((unsigned)((short)fuel > (signed char)3u)) goto L3;
    if (fuel < 8u) return i1;
    if ((unsigned)((short)9u > (signed char)u2)) goto L4;
    do { if (--fuel == 0u) goto done;
        goto done;
        while ((unsigned)(9u < 1u)) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)~(0x64ed6b80u * 3u);
            if ((unsigned)(0u || *q0)) break;
            if (((unsigned)(x0 >> 70) | (unsigned)s1)) break;
        }
    } while (i0++ < 6u && garr[u2 & 7u]);
    goto L0;
    if (fuel < 8u) return (unsigned)((short)*q0 > (signed char)u1);
    i2 = m0 & 15u;
    h1 = (unsigned short)(h1 + ((unsigned)((short)p2 > (signed char)i0) >> (*mp & 31u)));
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (g1 / (((i2 % (fuel | 1u)) + (unsigned)(r0.x || g1)) | 1u)));
                garr[(r0.y ^ g1) & 7u] = (unsigned)(0x7fffffffu && (unsigned)((int)*q0 < (int)m0));
            }
            if ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)l0)) break;
            if (((unsigned)(w0 >> 29) | p0)) break;
            continue; (void)(~(i0 % (((unsigned)s1 ^ 7u) | 1u)));
            do { if (--fuel == 0u) goto done;
                v0 = (unsigned)((short)u1 > (signed char)(unsigned)c0);
                switch ((unsigned)(a0[i0 & 3u] < (0x1286bb47u ^ (unsigned)w0)) & 7u) {
                    if ((unsigned)(8u && 1u)) {
                        *q0 = ((unsigned)c1 - (((unsigned)((unsigned)d0 == (unsigned)w0) - p0) >> (g0 & 31u)));
                        if ((unsigned)(x0 >> 70)) {
                            if (u3 == 7u) return (unsigned)(garr[u2 & 7u] && 0xc207ba5u);
                            case 1u: ;
                        } else {
                            case 0u: ;
                            w0 = w0 * 6364136223846793005ull + 0x10000u;
                        }
                    }
                    break; (void)((unsigned)(garr[u2 & 7u] && (unsigned)l0));
                    { unsigned t4; double z4; if (((unsigned)((unsigned)((int)u2 >= (int)p0) < m0)) & 1u) { t4 = a0[i0 & 3u]; z4 = (double)((0xffffffffu) & 255u); } if (((unsigned)((unsigned)((int)u2 >= (int)p0) < m0)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                        u0 ^= ((0x11481657u << (*q0 & 31u)) | 0x274e74d4u);
                        l0 = (long)((unsigned long)l0 + ((garr[i1 & 7u] | (unsigned)b0) + 0x6f6e06bfu));
                        case 6u: ;
                    }
                    if (g0) break;
                }
            } while (i2++ < 6u && (i0 / (0x7fffffffu | 1u)));
        }
        if (p2) {
            if ((unsigned)((unsigned)c0 == (u2 ^ a0[u1 & 3u]))) break;
            if (-(0x7fffffffu ? i1 : r0.x)) break;
        }
        do { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)(1u < u0);
            w0 ^= (unsigned long long)u1 << ((~(4u << ((i2 % (0x1e58ddb1u | 1u)) & 31u)) & (unsigned)((unsigned)d0 && u0)) & 63u);
            m0 ^= (((unsigned)(a0[i0 & 3u] < (unsigned)w0) & 0xcc3ba10bu) >> ((unsigned)h1 & 31u));
        } while (i1++ < 2u && (unsigned)(u2 || u3));
        h0 = (short)((unsigned)h0 | ((5u | fuel) >> (g1 & 31u)));
        break; (void)(~(unsigned)(fuel || garr[u2 & 7u]));
    }
    m0 ^= (unsigned)(((3u & *mp) * a0[i0 & 3u]) < (unsigned)(g1 && (unsigned)s1));
    if (((unsigned)(signed char)(unsigned)((int)0xe4256f17u < (int)5u) & 0xbcb3146eu)) goto done;
    if ((unsigned)(unsigned char)((unsigned)((int)(unsigned)x0 < (int)g0) >> (u1 & 31u))) goto L1;
    h0 = (short)~(unsigned)((int)(unsigned)(0xffffffffu < 0x80000000u) < (int)(9u ? *q0 : p2));
    switch ((v0 + fuel) & 7u) {
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 5u: ;
        }
        break; (void)((u1 % ((unsigned)w0 | 1u)));
        goto L1;
        if ((0x7fffffffu & (unsigned)f0)) {
            break; (void)(u0);
            s0 = (int)0xffffffffu;
            u0 += (unsigned)(unsigned char)(((unsigned)c0 - (unsigned)s0) >> (*mp & 31u));
        } else {
            default: ;
        }
    }
    goto L1;
    f0 = f0 * 0.5f + (float)((unsigned)(0x7fffffffu && -(a0[u1 & 3u] + 0x10000u)) & 255u);
    if ((unsigned)(signed char)(unsigned)((int)(unsigned)(short)((unsigned)f0 + (unsigned)c0) < (int)u3)) {
        { unsigned t5; double z5; if ((((unsigned)s0 & (0x10000u + (unsigned)f0))) & 1u) { t5 = -(unsigned)((unsigned)s1 < 9u); z5 = (double)((7u) & 255u); } if ((((unsigned)s0 & (0x10000u + (unsigned)f0))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
            while ((*mp & 0xd6837f70u)) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)(u3 && ((u2 % ((unsigned)s1 | 1u)) - ~(unsigned)((short)(unsigned)h0 > (signed char)garr[i1 & 7u]))) & 255u);
                u3 = ((unsigned)((~((unsigned)(w0 >> 29) * (unsigned)f0) & 0x5b9c3c4u) < (unsigned)b0) / (i1 | 1u));
                continue; (void)(((unsigned)h0 | i1));
                s0 = (int)(unsigned)(u3 < (unsigned)s1);
            }
            garr[(unsigned)h1 & 7u] = (unsigned)(short)(((unsigned)(2u < u1) - g1) >> ((0x7fffffffu ^ (unsigned)(w0 >> 29)) & 31u));
            if ((u2 | (unsigned)(1u == 9u))) {
                if (fuel < 8u) return a0[i0 & 3u];
                g1 += ((unsigned)((int)(unsigned)((short)u1 > (signed char)g1) < (int)(1u / (v0 | 1u))) * 0xef61ea5u);
                if ((unsigned)((short)0x7fffffffu > (signed char)m0)) goto L4;
                *q0 = ((0xffffffffu ? p1 : *q0) << (2u & 31u));
                while (i0++ < 3u && (0xaa16530bu * ~(u2 / (a0[u1 & 3u] | 1u)))) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((((unsigned)(0u < 0x7fffffffu) ^ i1) * (0xb9596cc3u % (g1 | 1u))) & 255u);
                    if ((unsigned)((int)(g1 >> (p0 & 31u)) >= (int)3u)) break;
                }
            }
        }
    }
    f0 = f0 * 0.5f + (float)((unsigned)s1 & 255u);
    *q0 += -(unsigned)((int)((unsigned)(fuel == 0xa4d3ad54u) - (i2 | (unsigned)w0)) < (int)r0.x);
    while (i0++ < 6u && (unsigned)((unsigned)((int)0x7fffffffu >= (int)(unsigned)w0) < (unsigned)x0)) { if (--fuel == 0u) goto done;
        u2 ^= ((unsigned)(w0 >> 29) >> (0x10000u & 31u));
        q0 = &garr[((unsigned)(w0 >> 29) * a0[i0 & 3u]) & 7u];
        if ((a0[i0 & 3u] / (*mp | 1u))) break;
        l0 = (long)((unsigned long)l0 + ((8u * 0x2b77ec62u) & (p2 % ((unsigned)(signed char)(unsigned)((unsigned)e0 || 0x6681c73eu) | 1u))));
        do { if (--fuel == 0u) goto done;
            break; (void)((unsigned)(unsigned char)(unsigned)((int)v0 >= (int)(unsigned)e0));
            g1 += 0x671b0527u;
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)((unsigned)f0 & (0u + (r0.x >> (a0[i0 & 3u] & 31u)))) >= (int)p2);
        } while (i1++ < 5u && (unsigned)(short)((unsigned)w0 / ((unsigned)(3u || (unsigned)x0) | 1u)));
    }
    d0 = d0 * 0.5 + (double)(((unsigned)(x0 >> 70) % (((unsigned)((int)(unsigned)x0 < (int)(unsigned)d0) | (0x10000u + i2)) | 1u)) & 1023u);
    if (0x7880b8cdu) goto done;
    u1 ^= ((unsigned)x0 & ((unsigned)(0x3e84746fu && 0x80000000u) - (unsigned)c1));
    goto L1;
    h1 = (unsigned short)(h1 + ((unsigned)(0xfa173687u < (unsigned)s1) >> ((u2 >> ((unsigned)l0 & 31u)) & 31u)));
    switch (i1 & 7u) {
        g1 += 0x80000000u;
        case 5u: ;
        l0 = (long)((unsigned long)l0 + (unsigned)(0x7fffffffu && ((0x7fffffffu - (unsigned)d0) * a0[u1 & 3u])));
        if (1u) {
            d0 = d0 * 0.5 + (double)((unsigned)((int)1u >= (int)(0x389240f7u & (unsigned)e0)) & 1023u);
            m0 ^= ((unsigned)c1 << (9u & 31u));
            switch ((unsigned)x0 & 7u) {
                if ((p2 | (unsigned)((unsigned)s0 && g0))) break;
                a0[(unsigned)((int)(unsigned)l0 < (int)0x10000u) & 3u] = (unsigned)((int)0x10000u < (int)((fuel ? i1 : i1) / ((unsigned)w0 | 1u)));
                case 3u: ;
            }
            g1 += (unsigned)((unsigned)l0 || (unsigned)c0);
            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)l0 == garr[i1 & 7u]));
            r0.y ^= ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)2u) + 0x10000u);
        }
    }
    w0 = w0 * 6364136223846793005ull + ((unsigned)(unsigned char)(u3 / ((unsigned)d0 | 1u)) << (u0 & 31u));
    v0 = (unsigned)!(garr[u2 & 7u] + (unsigned)((int)(u1 + 3u) >= (int)(unsigned)f0));
    do { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (unsigned)((int)u1 < (int)0x1743c9cdu);
        { unsigned t6; double z6; if ((u3) & 1u) { t6 = ((unsigned)!(unsigned)((unsigned)h0 == (unsigned)s1) * (unsigned)c0); z6 = (double)(((unsigned)((int)g0 < (int)i2)) & 255u); } if ((u3) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
            break; (void)((unsigned)(unsigned char)((unsigned)x0 ^ (unsigned)h0));
            if ((unsigned)!(unsigned)((short)(garr[u2 & 7u] + 0x80000000u) > (signed char)0x175d069eu)) {
                do { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)((unsigned)(short)(g1 | u0) - 0x8f5ea3b1u));
                    if ((0x3b808e0cu & (unsigned)(p1 == r0.y))) continue;
                    c1 = (signed char)(unsigned)((int)-((unsigned)f0 >> ((unsigned)l0 & 31u)) < (int)garr[i1 & 7u]);
                } while (i1++ < 7u && ((unsigned)d0 >> (i0 & 31u)));
                if (0x80000000u) break;
                *mp = (unsigned)(unsigned char)(unsigned)((short)((unsigned)l0 >> ((unsigned)h0 & 31u)) > (signed char)((unsigned)(8u == (unsigned)c1) - (unsigned)h1));
                break; (void)((((unsigned)h0 & u3) << ((unsigned)(w0 >> 29) & 31u)));
                if (0x7fffffffu) {
                    if (((r0.y << (0xd71d1549u & 31u)) << ((unsigned)(x0 >> 70) & 31u))) break;
                    a0[(unsigned)(short)(r0.x % (5u | 1u)) & 3u] = (((g0 + (unsigned)e0) >> ((unsigned)(short)(unsigned)(0x7fffffffu < (unsigned)s1) & 31u)) - u2);
                    if ((unsigned)(w0 >> 29)) break;
                    if ((garr[u2 & 7u] & ((unsigned)d0 % (v0 | 1u)))) break;
                }
                switch (0x80000000u & 7u) {
                    continue; (void)(fuel);
                    if ((unsigned)x0) break;
                    if ((unsigned)l0) {
                        x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)w0 > (signed char)(u0 % ((r0.y << ((unsigned)(x0 >> 70) & 31u)) | 1u)));
                        s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((short)(i2 % ((unsigned)(0x7fffffffu == *q0) | 1u)) > (signed char)0xffffffffu) >= (int)4u));
                        case 7u: ;
                    }
                }
            } else {
                if ((unsigned)l0) {
                    if ((unsigned)((short)(unsigned)((short)8u > (signed char)m0) > (signed char)a0[i0 & 3u])) break;
                    a0[(unsigned)(x0 >> 70) & 3u] = *q0;
                    c1 = (signed char)((unsigned)(2u || p2) & 0x540e5265u);
                    if ((unsigned)((int)a0[u1 & 3u] >= (int)0x1f41fc51u)) break;
                    break; (void)(0u);
                    do { if (--fuel == 0u) goto done;
                        if (0xd64be26fu) continue;
                    } while (i1++ < 5u && (unsigned)((short)0x7fffffffu > (signed char)(unsigned)x0));
                } else {
                    c1 = (signed char)(unsigned)!(unsigned)((short)p1 > (signed char)(unsigned)h0);
                    if ((i1 - i1)) break;
                    m0 ^= (unsigned)c0;
                }
                if ((unsigned)((short)(unsigned)(*mp == (unsigned)d0) > (signed char)p1)) break;
                if ((unsigned)((unsigned)s1 && 0xa75a6d2au)) break;
                l0 = (long)((unsigned long)l0 + ((0x3d3ce403u % (g1 | 1u)) - 0xe0c8bf15u));
            }
            m0 ^= (unsigned)((0xffffffffu * a0[u1 & 3u]) && r0.x);
            { unsigned t7; double z7; if ((0xcd001d5u) & 1u) { t7 = (a0[u1 & 3u] & ((unsigned)(x0 >> 70) | (unsigned)(w0 >> 29))); z7 = (double)(((fuel & (garr[i1 & 7u] ^ p2))) & 255u); } if ((0xcd001d5u) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                if ((garr[i1 & 7u] - (unsigned)((int)garr[i1 & 7u] >= (int)u0))) continue;
            }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                u2 ^= ((unsigned)h0 % ((unsigned)((unsigned)s0 < 5u) | 1u));
                break; (void)((unsigned)(unsigned char)(a0[u1 & 3u] - a0[u1 & 3u]));
                if ((i2 | i2)) break;
                if ((a0[u1 & 3u] & 0u)) break;
            }
        }
    } while (i0++ < 5u && a0[u1 & 3u]);
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((u3 | p1)) goto done;
    }
    r0.x = u1;
    if (*q0) {
        garr[(unsigned)((unsigned)c1 == 0x7fffffffu) & 7u] = (unsigned)(((r0.y ^ (unsigned)d0) & 8u) || (1u / (2u | 1u)));
        b0 = ((g1 % ((unsigned)h1 | 1u)) ^ (unsigned)(g0 || (unsigned)((int)garr[i1 & 7u] < (int)9u))) != 0u;
        switch (-(0x80000000u << ((unsigned)(a0[i0 & 3u] == 3u) & 31u)) & 7u) {
            *q0 += (unsigned)s1;
            h0 = (short)(((unsigned)s1 | 4u) * (unsigned)(garr[u2 & 7u] == 0xffffffffu));
            s0 = (int)((unsigned)(0x80000000u < i0) & (unsigned)l0);
            if (((unsigned)(x0 >> 70) / ((unsigned)((short)*q0 > (signed char)2u) | 1u))) {
                case 1u: ;
                if (r0.x) goto L3;
                switch ((unsigned)x0 & 7u) {
                    u2 = u2 * 0x9e3779b1u + (unsigned)((int)(unsigned)c1 >= (int)(u2 - (unsigned)(x0 >> 70)));
                    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        a0[(unsigned)(p2 < u3) & 3u] = p0;
                        goto L4;
                        a0[(unsigned)c0 & 3u] = (unsigned)(signed char)((unsigned)w0 + 0x7fffffffu);
                        u2 = ((m0 - u2) - (r0.y / (((unsigned)c0 >> (0xf2e9a9adu & 31u)) | 1u)));
                        h1 = (unsigned short)(h1 + 8u);
                        case 5u: ;
                    }
                    case 4u: ;
                    case 2u: ;
                    *mp = (unsigned)s0;
                }
                if ((unsigned)(r0.y < ((unsigned)x0 >> ((unsigned)l0 & 31u)))) goto L1;
                s0 = (int)(unsigned)!(a0[i0 & 3u] / ((((i0 + 8u) | (unsigned)d0) & (unsigned)d0) | 1u));
            } else {
                if (((unsigned)((short)(unsigned)e0 > (signed char)u1) ^ 0u)) goto L1;
                b0 = ((unsigned)((short)0x10000u > (signed char)r0.x) - 0x10000u) != 0u;
            }
        }
        do { if (--fuel == 0u) goto done;
            if (0x7fffffffu) break;
            b0 = (unsigned)c0 != 0u;
        } while (i0++ < 2u && (7u % ((unsigned)f0 | 1u)));
        g1 += (unsigned)((unsigned)h0 == u0);
        goto L0;
    } else {
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)!(unsigned)((unsigned)c0 == (0xbf5e22a5u ^ 0x80000000u))) break;
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)x0 == (u1 & 0x3c5e8907u))) break;
                e0 = e0 * 0.5L + (long double)((unsigned)(0x10000u < (9u >> ((unsigned)(fuel < 5u) & 31u))) & 1023u);
                do { if (--fuel == 0u) goto done;
                    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)(5u == (unsigned)c1))) break;
                        l0 = (long)((unsigned long)l0 + ((unsigned)e0 << (u1 & 31u)));
                        break; (void)(((unsigned)h1 ^ 0xffffffffu));
                    }
                    if ((~(unsigned)((short)1u > (signed char)4u) >> (0x7fffffffu & 31u))) break;
                    break; (void)((unsigned)((8u | 8u) == p2));
                    { unsigned t8; double z8; if (((unsigned)((short)(unsigned)((short)i0 > (signed char)(unsigned)h1) > (signed char)(unsigned)s0)) & 1u) { t8 = (unsigned)((short)i2 > (signed char)0xd789da4fu); z8 = (double)(((unsigned)s1) & 255u); } if (((unsigned)((short)(unsigned)((short)i0 > (signed char)(unsigned)h1) > (signed char)(unsigned)s0)) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                        break; (void)(*mp);
                        break; (void)((unsigned)!(((unsigned)f0 & 0x80000000u) + garr[i1 & 7u]));
                        if ((unsigned)((short)0x68ea5e45u > (signed char)(unsigned)(signed char)(g1 << ((unsigned)c0 & 31u)))) break;
                    }
                    if (((unsigned)s1 / (garr[i1 & 7u] | 1u))) goto L4;
                } while (i2++ < 7u && 0xec3c7accu);
                c0 = (unsigned char)((unsigned)((int)(unsigned)d0 < (int)3u) & v0);
                m0 ^= (*q0 & (unsigned)((int)(unsigned)x0 >= (int)(unsigned)b0));
                if ((2u % (0u | 1u))) break;
            }
            e0 = e0 * 0.5L + (long double)(((unsigned)e0 * (unsigned)c0) & 1023u);
            if (~(1u & (0x10000u % (a0[i0 & 3u] | 1u)))) continue;
        }
        switch ((unsigned)((unsigned)c0 < u3) & 7u) {
            *q0 += (unsigned)(signed char)(unsigned)((int)0x76a6c6eeu >= (int)g0);
            switch (a0[u1 & 3u] & 7u) {
                v0 = (((0xa75689cbu + a0[i0 & 3u]) << (i1 & 31u)) ^ g1);
                l0 = (long)((unsigned long)l0 + (unsigned)(0x841a0156u < m0));
                *q0 = (0x7fffffffu << ((u2 | 0x6258f3dcu) & 31u));
                *q0 = (r0.y / ((unsigned)(0xd35af7ccu || (unsigned)((int)0xe17c940bu >= (int)(0xffffffffu & 0x2ef3e0dfu))) | 1u));
                if ((unsigned)!(0x10000u & (u1 >> (0xad75ca75u & 31u)))) goto L2;
            }
        }
        switch ((i1 / (((unsigned)e0 / (g0 | 1u)) | 1u)) & 7u) {
            s0 = (int)(((unsigned)b0 + i0) >> ((unsigned)((int)fuel < (int)(unsigned)(0x80000000u == *q0)) & 31u));
            r0.x = ((unsigned)d0 ? (unsigned)(0xbfba07f3u || (p1 * (unsigned)(x0 >> 70))) : (unsigned)h0);
        }
    }
    if ((unsigned)((int)(unsigned)d0 < (int)*q0)) {
        if ((unsigned)!(unsigned)(u0 || 0x10000u)) goto done;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(garr[i1 & 7u] < i0)) {
                while (i1++ < 3u && ((unsigned)h1 * 0x10000u)) { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)(0x10000u + 0x80000000u) << (a0[i0 & 3u] & 63u);
                        break; (void)(u2);
                        v0 = (unsigned)((unsigned)c0 == 0x10000u);
                        break; (void)((unsigned)((int)(0u * r0.y) < (int)g0));
                    }
                    if ((unsigned)(w0 >> 29)) break;
                    if ((unsigned)(*q0 == (6u - 0x7fffffffu))) break;
                    if ((0x7fffffffu + 1u)) break;
                    if (((unsigned)c1 * u2)) break;
                }
                switch ((unsigned)h1 & 7u) {
                    do { if (--fuel == 0u) goto done;
                        continue; (void)(7u);
                        *mp = ((unsigned)(w0 >> 29) + (unsigned)c1);
                    } while (i1++ < 7u && (r0.y ? 0x44b73d70u : r0.y));
                    garr[(unsigned)(0x80000000u && a0[i0 & 3u]) & 7u] = (unsigned)(((unsigned)(x0 >> 70) | (unsigned)(short)(garr[u2 & 7u] & (unsigned)(unsigned char)(garr[i1 & 7u] - (unsigned)w0))) == g0);
                }
            } else {
                q0 = &garr[((unsigned)(w0 >> 29) | (((unsigned)c0 + 5u) | (unsigned)(a0[u1 & 3u] < (unsigned)h1))) & 7u];
                if ((u1 << ((unsigned)e0 & 31u))) break;
                { unsigned t9; double z9; if ((~(unsigned)((unsigned)s1 < (unsigned)h0)) & 1u) { t9 = (unsigned)!((unsigned)(unsigned char)((unsigned)d0 & 0x10000u) / (u0 | 1u)); z9 = (double)(((unsigned)((short)(unsigned)(signed char)(u1 + i0) > (signed char)(unsigned)s0)) & 255u); } if ((~(unsigned)((unsigned)s1 < (unsigned)h0)) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                    if (0xcc6843c0u) break;
                    if (1u) continue;
                    *q0 = (unsigned)((int)((unsigned)h0 | -(8u >> (p0 & 31u))) >= (int)(0xffffffffu | g1));
                    w0 ^= (unsigned long long)i2 << (((unsigned)e0 | (unsigned)((int)(unsigned)f0 < (int)(unsigned)((unsigned)(short)(unsigned)(p1 == u3) == m0))) & 63u);
                    break; (void)((0xb678b36fu & (unsigned)f0));
                    if (a0[i0 & 3u]) break;
                }
                if (garr[u2 & 7u]) break;
            }
            u0 ^= (0x10000u / ((unsigned)(x0 >> 70) | 1u));
            c0 = (unsigned char)(*q0 - (0xb123c092u - (unsigned)b0));
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)((unsigned)w0 % (r0.y | 1u)) < (int)(unsigned)e0);
            break; (void)((unsigned)((int)(unsigned)(w0 >> 29) < (int)(8u << (0x80000000u & 31u))));
            e0 = e0 * 0.5L + (long double)((unsigned)((5u / (i0 | 1u)) == (unsigned)(p0 || u0)) & 1023u);
        } while (i0++ < 3u && u0);
        if (7u) goto L4;
        if ((unsigned)((unsigned)f0 < (unsigned)h0)) goto done;
        b0 = ~((unsigned)(signed char)(unsigned)(p1 && (garr[i1 & 7u] % (u1 | 1u))) << (5u & 31u)) != 0u;
    } else {
        w0 = w0 * 6364136223846793005ull + (0xa26b8101u * 0x7fffffffu);
    }
    switch ((*mp % (0x1b2157e9u | 1u)) & 7u) {
        switch (0xb75ed629u & 7u) {
            case 4u: ;
            h0 = (short)(unsigned)(signed char)(unsigned)((0x125b2f98u * g0) && ((unsigned)c0 + 0xffffffffu));
            default: ;
        }
        b0 = (0xffffffffu ^ 0x661e9d5cu) != 0u;
        do { if (--fuel == 0u) goto done;
            goto L2;
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(fuel || (unsigned)(0x7fffffffu || p1))) goto L2;
                q0 = &garr[~(0xffffffffu / (*q0 | 1u)) & 7u];
                if ((unsigned)(short)(0x10000u << ((unsigned)l0 & 31u))) break;
            }
            if (((unsigned)!(g0 / (0x80000000u | 1u)) * 0xc314767fu)) {
                case 3u: ;
            } else {
                if (garr[u2 & 7u]) {
                    s1 = (int)((unsigned)s1 + (u1 << (((unsigned)h0 * (unsigned)b0) & 31u)));
                    switch ((unsigned)(signed char)(unsigned)(4u && u2) & 7u) {
                        continue; (void)((((unsigned)c0 << (3u & 31u)) << (0xffffffffu & 31u)));
                    }
                    g1 += (unsigned)(signed char)((unsigned)h1 * 0x69c982eau);
                }
            }
            if ((unsigned)(unsigned char)(unsigned)(0x822a0edu || i0)) continue;
            case 6u: ;
        } while (i0++ < 4u && ((unsigned)((int)p1 < (int)0xffffffffu) ^ 0xa34cb0d1u));
        x0 = x0 * 0x100000001b3ull + ((unsigned)(v0 || 9u) % (0x10000u | 1u));
    }
    { unsigned t10; double z10; if (((unsigned)((int)0x7fffffffu < (int)(unsigned)(x0 >> 70))) & 1u) { t10 = ~(g1 + ((unsigned)d0 | r0.y)); z10 = (double)(((unsigned)e0) & 255u); } if (((unsigned)((int)0x7fffffffu < (int)(unsigned)(x0 >> 70))) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
        if (((unsigned)b0 | 0x9b406e01u)) goto L1;
    }
    if (i1) goto L4;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)h0 || 0xc870f4c7u)) break;
    }
    if ((u3 + 0x10000u)) goto L0;
    h1 = (unsigned short)(h1 + ((unsigned)((unsigned)(i0 || 0x80000000u) && (unsigned)!((unsigned)d0 / (g0 | 1u))) * (unsigned)b0));
    if (fuel < 8u) return 6u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (((i0 ^ 0xffffffffu) ^ u3)) goto L0;
    goto L1;
    if ((unsigned)(unsigned char)(((unsigned)c0 / (3u | 1u)) / ((unsigned)b0 | 1u))) goto L1;
    if ((0x9fafc75bu % (i0 | 1u))) goto L4;
    if ((unsigned)((short)m0 > (signed char)g1)) goto L3;
    goto done;
    if ((unsigned)(p2 || (unsigned)x0)) goto L1;
    if (u3 == 7u) return (unsigned)h0;
    v0 = u3;
    goto L1;
    if (i0) {
        goto L4;
    }
    if ((unsigned)(0xa2f0d16fu < r0.y)) {
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!(unsigned)((int)(unsigned)(a0[u1 & 3u] < (unsigned)c0) >= (int)9u), -(unsigned)((unsigned)s1 == a0[u1 & 3u]), ((unsigned)((short)(unsigned)s0 > (signed char)0x134a05b6u) + a0[i0 & 3u])); }
        L0: if (--fuel == 0u) goto done;
    } else {
        c0 = (unsigned char)(u3 - (unsigned)!(0x7fffffffu ^ (unsigned)((unsigned)s0 == a0[u1 & 3u])));
        d0 = d0 * 0.5 + (double)((0x7fffffffu ? r0.y : *mp) & 1023u);
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((garr[u2 & 7u] | r0.x), u2, 8u); }
    b0 = (unsigned)(short)(unsigned)((unsigned)((int)*q0 >= (int)(0xf7154fe5u + p1)) < -(0x80000000u >> (u3 & 31u))) != 0u;
    h0 = (short)(unsigned)((int)(0x10000u ? (unsigned)d0 : (unsigned)((int)i2 >= (int)a0[u1 & 3u])) < (int)r0.y);
    a0[(3u | (unsigned)(w0 >> 29)) & 3u] = ((unsigned)e0 / (((unsigned)(0x9a65842cu == 0x80000000u) + 0xffffffffu) | 1u));
    a0[a0[u1 & 3u] & 3u] = 6u;
    r0.x = (unsigned)((int)(unsigned)(u1 < (unsigned)h0) >= (int)(0x212d756bu * 0xffffffffu));
    *q0 += (r0.x | (p1 % (i1 | 1u)));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        v0 = (unsigned)!((unsigned)c1 & (unsigned)(0x7fffffffu == a0[u1 & 3u]));
        L1: if (--fuel == 0u) goto done;
    }
    h0 = (short)(unsigned)((unsigned)c1 < ((unsigned)h1 >> ((unsigned)(8u || 7u) & 31u)));
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(unsigned)(0x12a173beu == (unsigned)h0));
        while (((unsigned)(i2 || r0.y) / ((unsigned)(x0 >> 70) | 1u))) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)c1 < (int)(unsigned)w0)) break;
            q0 = &garr[((0x77645a4u + (unsigned)s1) % (((unsigned)((unsigned)f0 || 3u) / ((unsigned)s1 | 1u)) | 1u)) & 7u];
        }
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(((fuel ^ (unsigned)s0) - 0x7fffffffu), 1u, 0xd6db4b48u); }
        } while (i1++ < 5u && (u3 >> (i0 & 31u)));
        h1 = (unsigned short)(h1 + (((unsigned)!((unsigned)(x0 >> 70) | (unsigned)s1) << (0x7fffffffu & 31u)) * *q0));
    }
    i0 = ((unsigned)((unsigned)(signed char)(7u / ((unsigned)x0 | 1u)) && (unsigned)(w0 >> 29)) & -(unsigned)((short)0x10000u > (signed char)(unsigned)d0)) & 15u;
    if ((-(unsigned)((int)r0.y < (int)0x10000u) >> (0x171eba96u & 31u))) goto L2;
    g1 += ((unsigned)((unsigned)b0 == r0.x) << (u1 & 31u));
    while (((unsigned)s0 / (*mp | 1u))) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            *q0 += (unsigned)(signed char)((0x6490eda3u + ((0x9187c1b6u % (r0.y | 1u)) - 7u)) ^ fuel);
            *mp = -(2u * (unsigned)((unsigned)f0 < (unsigned)s0));
        }
        if ((unsigned)((int)(unsigned)((unsigned)b0 == (unsigned)c1) < (int)i2)) {
            h0 = (short)(unsigned)((unsigned)s0 || (unsigned)(short)((a0[i0 & 3u] ^ (unsigned)!(unsigned)((short)(unsigned)s1 > (signed char)0x5ab4d8a6u)) >> (garr[i1 & 7u] & 31u)));
            w0 = w0 * 6364136223846793005ull + (((unsigned)l0 + u1) >> ((garr[i1 & 7u] >> (u0 & 31u)) & 31u));
        } else {
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)s1 & -(a0[i0 & 3u] - fuel)), ~(unsigned)((int)(unsigned)x0 < (int)(0xffffffffu * 0xffffffffu)), g0); }
        }
        if ((r0.y >> (0x80000000u & 31u))) {
            switch ((unsigned)x0 & 7u) {
                if (0x80000000u) {
                    m0 ^= (unsigned)!(unsigned)((int)(unsigned)(0xca1f924cu && v0) < (int)(unsigned)c1);
                    v0 = ((unsigned)c1 ^ p0);
                    *q0 = ~(-(unsigned)(0x80000000u && 0x10000u) / (garr[u2 & 7u] | 1u));
                } else {
                    i1 = ((unsigned)(short)(garr[i1 & 7u] * 0x80000000u) >> (*mp & 31u)) & 15u;
                }
                case 7u: ;
                L2: if (--fuel == 0u) goto done;
                g0 = (4u * (unsigned)(-(unsigned)((int)4u < (int)i2) && a0[u1 & 3u]));
            }
            break; (void)(garr[i1 & 7u]);
            for (;;) { if (--fuel == 0u) goto done;
                if (((unsigned)x0 + (unsigned)s1)) {
                    if ((unsigned)((8u << (u3 & 31u)) == (unsigned)d0)) goto L4;
                    q0 = &garr[(0xb05df897u - (p0 | (unsigned)s0)) & 7u];
                }
                if ((unsigned)((int)r0.x < (int)(unsigned)l0)) {
                    do { if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + 0x10000u;
                        d0 = d0 * 0.5 + (double)(((unsigned)((short)1u > (signed char)u0) + ((unsigned)((int)i0 < (int)(unsigned)l0) | g1)) & 1023u);
                        r0.y ^= ~((unsigned)(fuel && (unsigned)c0) << ((unsigned)(v0 && v0) & 31u));
                    } while (i2++ < 7u && ~((unsigned)e0 + 0x2ce0fbcfu));
                    if (1u) {
                        u2 ^= (7u / ((3u << ((unsigned)d0 & 31u)) | 1u));
                        if (~(unsigned)((int)(unsigned)f0 >= (int)garr[u2 & 7u])) break;
                        s1 = (int)((unsigned)s1 + ((0x7fffffffu ^ 4u) | garr[i1 & 7u]));
                        if (i1) continue;
                        { unsigned t0; double z0; if (((unsigned)f0) & 1u) { t0 = (unsigned)(unsigned char)(unsigned)(i1 && p2); z0 = (double)(((g0 ^ (unsigned)((unsigned)s0 < (unsigned)l0))) & 255u); } if (((unsigned)f0) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                            v0 = ((unsigned)((int)0x438b3de2u >= (int)(((unsigned)s0 ^ garr[u2 & 7u]) * 0x7fffffffu)) + (unsigned)(w0 >> 29));
                            x0 = x0 * 0x100000001b3ull + (unsigned)b0;
                            L3: if (--fuel == 0u) goto done;
                            h0 = (short)g1;
                            break; (void)((unsigned)((int)0xa22f8149u >= (int)u1));
                            if ((unsigned)(signed char)(0xb8693365u % (p1 | 1u))) break;
                        }
                        *q0 = (unsigned)((short)i0 > (signed char)(unsigned)((int)0x678dc1a1u >= (int)u1));
                    } else {
                        if ((unsigned)((unsigned)e0 && (unsigned)(x0 >> 70))) goto L1;
                    }
                    u2 += (unsigned)c0;
                    r0.y ^= ((unsigned)((int)a0[u1 & 3u] < (int)i1) | (p1 >> ((0xc92f86d2u - (unsigned)e0) & 31u)));
                    break; (void)((unsigned)((unsigned)((short)(unsigned)s0 > (signed char)i0) || *q0));
                }
                if ((u1 >> ((0xf9a5bba7u % ((unsigned)d0 | 1u)) & 31u))) {
                    d0 = d0 * 0.5 + (double)((u1 / (0x7fffffffu | 1u)) & 1023u);
                } else {
                    d0 = d0 * 0.5 + (double)((unsigned)((int)((unsigned)s1 ^ 0x80000000u) < (int)(unsigned)(w0 >> 29)) & 1023u);
                    while (0x7fffffffu) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(-(unsigned)((unsigned)(fuel == p0) && 0xdc6b923fu), (unsigned)s1, (unsigned)(*q0 && (unsigned)((int)(unsigned)h1 < (int)fuel))); }
                        i0 = (unsigned)(p1 == r0.y) & 15u;
                    }
                    w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)(r0.x >> ((unsigned)c0 & 31u));
                    i2 = ((unsigned)w0 & (unsigned)((int)(u2 * (unsigned)h0) >= (int)(unsigned)((short)(unsigned)d0 > (signed char)0x9dfd5768u))) & 15u;
                }
                { unsigned t1; double z1; if ((*q0) & 1u) { t1 = i0; z1 = (double)(((i0 | u3)) & 255u); } if ((*q0) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    *mp = (unsigned)((int)(unsigned)((int)(p1 & ((unsigned)h1 % ((unsigned)s0 | 1u))) >= (int)p0) < (int)r0.x);
                    goto L1;
                    if ((6u ^ (0x7f232a13u | 0x7fffffffu))) continue;
                    break; (void)((a0[u1 & 3u] & (m0 * i2)));
                }
                if (i2) break;
                if ((unsigned)((int)p2 >= (int)((unsigned)e0 * r0.x))) {
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((int)0xffffffffu < (int)(unsigned)h1) - fuel), (unsigned)h0, (g0 + 0xfb029f9eu)); }
                }
            }
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (a0[i0 & 3u] & (unsigned)(short)((unsigned)x0 * 0xffffffffu)));
                h1 = (unsigned short)(h1 + 0x71ad8ef4u);
                if (((unsigned)!(0x7fffffffu & 0xffffffffu) >> ((unsigned)b0 & 31u))) {
                    break; (void)(((r0.x | (unsigned)b0) - u3));
                    c1 = (signed char)~(unsigned)((unsigned)(w0 >> 29) || (unsigned)(short)(unsigned)(5u || i1));
                    q0 = &garr[(((unsigned)e0 & u1) - ((unsigned)(garr[u2 & 7u] < 0x10000u) / ((unsigned)b0 | 1u))) & 7u];
                } else {
                    x0 = x0 * 0x100000001b3ull + garr[u2 & 7u];
                    q0 = &garr[(unsigned)((unsigned)(((unsigned)d0 * 0x10000u) && 0x7fffffffu) && 0xbc0532c0u) & 7u];
                    L4: if (--fuel == 0u) goto done;
                }
            }
        }
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((int)m0 >= (int)0xfc93ee95u)) {
            if ((0x826ca610u + -(unsigned)((int)r0.x < (int)(unsigned)h1))) continue;
        } else {
            if ((unsigned)(fuel < 7u)) break;
            *mp = (unsigned)((int)(u2 ^ *mp) < (int)(unsigned)((int)0xdb93f332u >= (int)0x7fffffffu));
        }
        q0 = &garr[(unsigned)h0 & 7u];
        w0 = w0 * 6364136223846793005ull + (unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)(u1 || (unsigned)h0));
        if ((0x80000000u >> ((unsigned)(short)((unsigned)c0 << ((unsigned)d0 & 31u)) & 31u))) break;
        if ((p0 * ((unsigned)(x0 >> 70) & fuel))) break;
    } while (i0++ < 7u && garr[u2 & 7u]);
    if ((unsigned)(-(unsigned)((unsigned)h0 == 0xffffffffu) < (unsigned)h0)) {
        do { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (i2) break;
                { unsigned t2; double z2; if ((((unsigned)l0 * 7u)) & 1u) { t2 = ((unsigned)((unsigned)h0 < g1) | (unsigned)h0); z2 = (double)(((unsigned)(unsigned char)(p1 + u3)) & 255u); } if ((((unsigned)l0 * 7u)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    *q0 += (unsigned)c1;
                    f0 = f0 * 0.5f + (float)(-((unsigned)(w0 >> 29) % (0xa12ce046u | 1u)) & 255u);
                    i0 = (p1 ? p2 : (unsigned)b0) & 15u;
                }
                switch ((unsigned)((short)0x80000000u > (signed char)*mp) & 7u) {
                    w0 ^= (unsigned long long)r0.y << (-(unsigned)(fuel == 9u) & 63u);
                    r0.x = *mp;
                    case 2u: ;
                }
                u3 += (unsigned)!(g1 ^ 0x1e43336au);
                if (0xffffffffu) break;
            }
            if ((unsigned)((unsigned)h0 && (unsigned)s1)) {
                u1 += (garr[i1 & 7u] >> ((r0.y << ((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)h0) & 31u)) & 31u));
            }
            if (fuel < 8u) return p1;
            if (((unsigned)(short)(u0 / (p0 | 1u)) / (p1 | 1u))) {
                e0 = e0 * 0.5L + (long double)((unsigned)(u1 && a0[i0 & 3u]) & 1023u);
                break; (void)(g0);
                *q0 = (unsigned)((int)garr[i1 & 7u] < (int)((unsigned)s0 >> ((unsigned)s0 & 31u)));
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + 0xffffffffu);
                    u2 = (p0 | 7u);
                    if ((unsigned)((unsigned)b0 || 0x4d7fbd05u)) break;
                    goto L4;
                    for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        u2 ^= ((unsigned)!(0xfe151347u >> (~((unsigned)h0 >> (i0 & 31u)) & 31u)) ^ a0[u1 & 3u]);
                        h1 = (unsigned short)(h1 + ((0xb44de5d4u & 9u) ^ i0));
                    }
                }
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(short)(2u << ((i2 & (unsigned)h0) & 31u))) {
                        *q0 = i0;
                        for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u3 = fn0(garr[u2 & 7u], (unsigned)((int)i0 < (int)(unsigned)(signed char)(unsigned)(g0 || u1)), (garr[u2 & 7u] & g1)); }
                            break; (void)((*mp / ((unsigned)d0 | 1u)));
                            if (0xd79074ecu) continue;
                            break; (void)(((unsigned)(x0 >> 70) ^ 6u));
                            if ((unsigned)e0) break;
                        }
                        u1 = u1 * 0x9e3779b1u + (6u + (0x30156ccbu | r0.x));
                    }
                    if (fuel < 8u) return (unsigned)((unsigned)((int)u1 >= (int)(unsigned)b0) == (0xa9ad215bu / ((unsigned)d0 | 1u)));
                    v0 = (0u / (m0 | 1u));
                }
                if ((unsigned)((unsigned)w0 == (unsigned)s0)) {
                    if (budget != 0u) { budget -= 1u; u0 = fn0(0x7fffffffu, 0x7fffffffu, (unsigned)((int)7u >= (int)((unsigned)s1 - 0x222ba3fcu))); }
                    a0[(unsigned)(v0 == a0[u1 & 3u]) & 3u] = ((i0 >> ((unsigned)b0 & 31u)) | ((unsigned)f0 & 5u));
                    *q0 += ((unsigned)((int)2u >= (int)(unsigned)e0) >> (-(unsigned)((unsigned)((short)m0 > (signed char)garr[i1 & 7u]) || i0) & 31u));
                }
            } else {
                if ((unsigned)(signed char)(unsigned)(*mp && i2)) {
                    if ((unsigned)((short)0x10000u > (signed char)(unsigned)f0)) {
                        g1 += (unsigned)(0x10000u || u0);
                        g1 += (unsigned)(0xffffffffu || 0xb5ccaf53u);
                        q0 = &garr[(unsigned)!(unsigned)(0x91ab5d62u < ((unsigned)((short)(unsigned)c0 > (signed char)0x80000000u) / (*q0 | 1u))) & 7u];
                        h1 = (unsigned short)(h1 + (unsigned)(signed char)(unsigned)((int)0x80000000u >= (int)0xffffffffu));
                        if ((unsigned)((int)0x1293c995u < (int)6u)) break;
                    }
                    if ((r0.x ? (unsigned)h1 : fuel)) break;
                    u1 = u1 * 0x9e3779b1u + -((unsigned)(0x488263c2u && p2) ? *q0 : (unsigned)((unsigned)s1 || 0x7431840cu));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((0xffffffffu + 3u), (unsigned)((int)0xffffffffu >= (int)(unsigned)e0), (unsigned)(i0 < (unsigned)((unsigned)c1 < (unsigned)d0))); }
                    if (0x3e8628e4u) goto done;
                }
                e0 = e0 * 0.5L + (long double)((0x9dcc90b0u - 0x10000u) & 1023u);
                continue; (void)((p2 + 0x10000u));
                do { if (--fuel == 0u) goto done;
                    h0 = (short)(unsigned)(unsigned char)(unsigned)(7u < (v0 ? u0 : (unsigned)c1));
                    if ((4u + v0)) break;
                    if ((p1 / (garr[i1 & 7u] | 1u))) goto L2;
                } while (i1++ < 5u && (unsigned)(u1 == (unsigned)s1));
            }
        } while (i0++ < 7u && (unsigned)(signed char)((unsigned)(w0 >> 29) ? u2 : p1));
        goto L4;
    }
    s1 = (int)((unsigned)s1 + (0x872a8d40u >> ((unsigned)h1 & 31u)));
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 6u && ((unsigned)e0 >> ((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)s0) & 31u))) { if (--fuel == 0u) goto done;
            r0.y ^= ((unsigned)((unsigned)x0 && 0x10000u) * ((unsigned)x0 + fuel));
            g1 += (unsigned)((unsigned)c0 == m0);
        }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                break; (void)(0x10000u);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0xa1dbd613u && u3), (unsigned)((unsigned)((unsigned)b0 && u0) && (unsigned)e0), (unsigned)!(unsigned)(0xe7bbaef1u || (unsigned)d0)); }
                if ((unsigned)((short)((unsigned)d0 << (g0 & 31u)) > (signed char)(unsigned)h1)) break;
                h1 = (unsigned short)(h1 + ((unsigned)h0 % ((unsigned)((short)(unsigned)((int)garr[u2 & 7u] < (int)garr[i1 & 7u]) > (signed char)0x80000000u) | 1u)));
                if (u3 == 7u) return ((u0 / (u1 | 1u)) | (unsigned)s0);
                r0.y ^= u2;
            } while (i2++ < 3u && ((unsigned)e0 + (unsigned)x0));
            continue; (void)((unsigned)h0);
            u3 += (0xffffffffu ^ (m0 / ((unsigned)x0 | 1u)));
        }
    }
    if ((unsigned)(w0 >> 29)) goto L0;
    m0 ^= (unsigned)((9u << (g0 & 31u)) == *mp);
    u2 ^= (unsigned)((int)i2 < (int)0x80000000u);
    do { if (--fuel == 0u) goto done;
        q0 = &garr[((unsigned)(x0 >> 70) | (unsigned)((int)8u < (int)6u)) & 7u];
        f0 = f0 * 0.5f + (float)((0x10000u * ((unsigned)h1 - (unsigned)(unsigned char)(i0 << ((unsigned)(a0[u1 & 3u] == u2) & 31u)))) & 255u);
        if (budget != 0u) { budget -= 1u; u2 = fn0((i1 - 1u), i0, (unsigned)(w0 >> 29)); }
        *q0 += (unsigned)(0xffffffffu < ((unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) || (*q0 * u0)) - 0x80000000u));
        r0.y ^= ((unsigned)((unsigned)(7u || 2u) < 3u) - (unsigned)e0);
        break; (void)(((unsigned)s0 ^ (u2 >> (u0 & 31u))));
    } while (i0++ < 6u && (unsigned)((unsigned)h1 && 7u));
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)l0, ((unsigned)((short)1u > (signed char)0x884e93ffu) % (0x10000u | 1u)), (((unsigned)(w0 >> 29) + (unsigned)f0) % (0x80000000u | 1u))); }
    w0 = w0 * 6364136223846793005ull + ((unsigned)b0 / (fuel | 1u));
    { unsigned t3; double z3; if ((*q0) & 1u) { t3 = ((0x63a02544u * (unsigned)l0) * (unsigned)(x0 >> 70)); z3 = (double)(((unsigned)(short)(unsigned)((unsigned)f0 < i2)) & 255u); } if ((*q0) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)g1;
            c0 = (unsigned char)r0.y;
            g0 = (unsigned)(short)((unsigned)((int)u3 >= (int)(0x46a872ceu % ((unsigned)e0 | 1u))) << (((unsigned)s0 - garr[u2 & 7u]) & 31u));
        }
        if ((unsigned)((int)(unsigned)h0 >= (int)0xd8005ffau)) {
            g1 += (u1 << ((unsigned)s0 & 31u));
            if (0u) goto L1;
        } else {
            if ((unsigned)((int)g1 >= (int)(unsigned)((int)u1 < (int)2u))) goto L0;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)c0 == i0)) break;
                if ((unsigned)!(unsigned)((unsigned)e0 == (unsigned)!(*mp << ((unsigned)b0 & 31u)))) break;
            } while (i0++ < 4u && (unsigned)(a0[i0 & 3u] < (unsigned)c0));
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(9u, (u1 - i0), 7u); }
            u0 = ((unsigned)f0 >> (((unsigned)c0 / ((unsigned)l0 | 1u)) & 31u));
        }
    }
    while (i0++ < 4u && (unsigned)f0) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((i0 % (0xe6816f85u | 1u)) & 1023u);
        break; (void)((unsigned)((unsigned)c0 && m0));
        while (i1++ < 6u && (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)((unsigned)e0 < g0))) { if (--fuel == 0u) goto done;
            u2 = u2 * 0x9e3779b1u + a0[i0 & 3u];
        }
        l0 = (long)((unsigned long)l0 + -(0x9847f1au & ((unsigned)(unsigned char)(unsigned)((short)u2 > (signed char)(unsigned)s0) ^ u0)));
        if ((unsigned)((short)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)a0[i0 & 3u]) > (signed char)u2)) {
            switch ((p2 ? g0 : (unsigned)s0) & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)w0 * (unsigned)(9u && garr[u2 & 7u])), (unsigned)h1, ((unsigned)d0 - (*mp * (unsigned)h0))); }
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)((int)g1 >= (int)(u2 & (unsigned)(w0 >> 29)));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!(u1 & a0[i0 & 3u]), (0x9b4df229u % (0xffffffffu | 1u)), 0xc3995a91u); }
                    break; (void)((unsigned)(unsigned char)(unsigned)(p1 < 6u));
                    u1 = u1 * 0x9e3779b1u + (unsigned)(0x4e3ddf5u < ((unsigned)l0 << (0xb369b165u & 31u)));
                }
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)f0 << (a0[i0 & 3u] & 31u)), 9u, (m0 << ((unsigned)((unsigned)c1 || (unsigned)e0) & 31u))); }
                    u2 ^= (*q0 >> ((unsigned)((unsigned)d0 == (unsigned)(unsigned char)(0x898f7a09u * u1)) & 31u));
                } while (i1++ < 4u && (u3 | *mp));
                if (fuel < 8u) return ((unsigned)((unsigned)(w0 >> 29) == g1) << (i2 & 31u));
                case 7u: ;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)b0), (p2 - 0xffffffffu), (i0 ? *mp : v0)); }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((a0[u1 & 3u] ^ v0), (unsigned)c1, *mp); }
    }
    switch ((unsigned)c0 & 7u) {
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(short)(p2 - 6u) % (0x10000u | 1u)), u2, (unsigned)((unsigned)d0 < 9u)); }
    }
    *q0 = (unsigned)(u2 < (*mp * (unsigned)(w0 >> 29)));
    if (budget != 0u) { budget -= 1u; u1 = fn0(-((unsigned)((int)u3 < (int)7u) << (*q0 & 31u)), (unsigned)(0x7fffffffu && u1), ((g1 & *q0) * 0xbe5fee40u)); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u0 = fn1(fuel, (unsigned)c1, r0.x); }
    r0.y ^= (unsigned)((unsigned)(*q0 && u2) == (unsigned)b0);
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(*mp == v0), (unsigned)c0, (unsigned)((int)u3 < (int)p0)); }
    x0 = x0 * 0x100000001b3ull + (a0[i0 & 3u] % ((unsigned)(signed char)(unsigned)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)a0[u1 & 3u]) < p0) | 1u));
    switch ((unsigned)x0 & 7u) {
        garr[((unsigned)(w0 >> 29) >> ((unsigned)s1 & 31u)) & 7u] = ((((unsigned)b0 / (i1 | 1u)) / (0x2a2f674bu | 1u)) % ((unsigned)(w0 >> 29) | 1u));
        case 3u: ;
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)h1), (unsigned)((int)0x10000u >= (int)p2), (unsigned)c1); }
        r0.y ^= ((unsigned)w0 / (p2 | 1u));
        w0 = w0 * 6364136223846793005ull + (unsigned)(*mp == (u1 >> (~(unsigned)((int)garr[i1 & 7u] < (int)(unsigned)c0) & 31u)));
        u0 += (unsigned)(short)(((unsigned)h0 >> ((unsigned)(w0 >> 29) & 31u)) << (0xe912f80du & 31u));
    }
    g1 += ~((g1 & (unsigned)h0) << ((0x7fffffffu | (unsigned)((int)0x10000u >= (int)(unsigned)l0)) & 31u));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((unsigned)(0u == 7u) < g1));
    }
    goto L3;
    if ((a0[i0 & 3u] ^ (0u & r0.y))) {
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((fuel << (p0 & 31u))) break;
            if ((3u & i0)) goto L1;
            { unsigned t0; double z0; if ((r0.y) & 1u) { t0 = (unsigned)l0; z0 = (double)((~(unsigned)((short)8u > (signed char)(unsigned)c0)) & 255u); } if ((r0.y) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                v0 = 0x1df0292cu;
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((0x7fffffffu & a0[i0 & 3u])) break;
                    u1 = (unsigned)(((unsigned)b0 % ((unsigned)h0 | 1u)) == (unsigned)(x0 >> 70));
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)0x7fffffffu >= (int)(unsigned)c0), g0, (unsigned)h1); }
                    L0: if (--fuel == 0u) goto done;
                    L1: if (--fuel == 0u) goto done;
                }
            }
        }
    } else {
        r0.y ^= ~((garr[i1 & 7u] + 6u) << ((unsigned)(x0 >> 70) & 31u));
        if (fuel < 8u) return (unsigned)(signed char)(g0 >> (0xffffffffu & 31u));
    }
    goto L1;
    if (~(0x6a4d36e7u & 0x7fffffffu)) {
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 7u && (unsigned)((short)(unsigned)h0 > (signed char)r0.x)) { if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if ((((unsigned)(g0 < (unsigned)(w0 >> 29)) % (i1 | 1u))) & 1u) { t1 = (unsigned)(r0.x || 4u); z1 = (double)((u2) & 255u); } if ((((unsigned)(g0 < (unsigned)(w0 >> 29)) % (i1 | 1u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    goto L3;
                    g0 = 0x10000u;
                    L2: if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + ((unsigned)(0xffffffffu == (0x80000000u + u0)) - 0x9ce8216au));
                }
                { unsigned t2; double z2; if (((unsigned)(a0[u1 & 3u] && i2)) & 1u) { t2 = ((unsigned)b0 | p2); z2 = (double)(((unsigned)((int)(unsigned)w0 < (int)8u)) & 255u); } if (((unsigned)(a0[u1 & 3u] && i2)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    x0 = x0 * 0x100000001b3ull + ~(unsigned)((int)(unsigned)e0 < (int)(a0[u1 & 3u] - a0[u1 & 3u]));
                    m0 ^= (unsigned)((unsigned)((int)p2 < (int)*mp) < ((unsigned)w0 | (0x10000u - 0xa2a282aau)));
                }
                if (0xc92ffda3u) goto L1;
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((*mp - (unsigned)c0), (unsigned)((u3 ^ (unsigned)b0) < 0x67294efcu), (g0 + (unsigned)h1)); }
                    L3: if (--fuel == 0u) goto done;
                    s0 = (int)garr[u2 & 7u];
                }
            }
            b0 = (unsigned)((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)c1) && ((fuel | (unsigned)s1) - p0)) != 0u;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((u2 & a0[i0 & 3u]) || i2)) break;
                c1 = (signed char)((0x9b2ce75au ^ ((unsigned)f0 ? u0 : (unsigned)l0)) * garr[u2 & 7u]);
                *q0 = 0x7fffffffu;
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    L4: if (--fuel == 0u) goto done;
                    if ((unsigned)((int)~(6u + r0.y) < (int)(unsigned)h1)) break;
                    c0 = (unsigned char)(((unsigned)h0 << (((unsigned)h1 ? fuel : u1) & 31u)) | (unsigned)b0);
                    break; (void)((*q0 * r0.x));
                }
                while (i2++ < 7u && (0xfb677434u / (p1 | 1u))) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return ((unsigned)h1 | ((unsigned)((int)u3 >= (int)(unsigned)h0) << ((unsigned)x0 & 31u)));
                    if (0x10000u) break;
                    break; (void)((unsigned)(u3 && (u1 >> (3u & 31u))));
                    i1 = ((unsigned)(w0 >> 29) << (a0[u1 & 3u] & 31u)) & 15u;
                    { unsigned t3; double z3; if ((*mp) & 1u) { t3 = (0x7221228fu - g1); z3 = (double)(((unsigned)(i0 == p0)) & 255u); } if ((*mp) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        a0[a0[u1 & 3u] & 3u] = ((unsigned)((int)u0 < (int)a0[i0 & 3u]) % (i1 | 1u));
                        if ((unsigned)(i1 < r0.y)) break;
                    }
                    switch (u0 & 7u) {
                        do { if (--fuel == 0u) goto done;
                            e0 = e0 * 0.5L + (long double)(((unsigned)((short)(fuel + u0) > (signed char)(unsigned)f0) & -(unsigned)((short)(unsigned)w0 > (signed char)i1)) & 1023u);
                            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)(w0 >> 29) ^ *mp), (unsigned)(signed char)((a0[i0 & 3u] * 0xedf5b952u) >> (7u & 31u)), 0x8129e9b9u); }
                            c0 = (unsigned char)((unsigned)((short)a0[i0 & 3u] > (signed char)((unsigned)h1 * (unsigned)b0)) - u2);
                        } while (i0++ < 7u && 9u);
                        i0 = ((unsigned)b0 % (0x7fffffffu | 1u)) & 15u;
                        b0 = (unsigned)(0x2772b8eu && (0x1f15801u - (unsigned)(w0 >> 29))) != 0u;
                        f0 = f0 * 0.5f + (float)((unsigned)((i2 / ((unsigned)b0 | 1u)) < m0) & 255u);
                        case 1u: ;
                    }
                }
                while (i2++ < 7u && (p2 ? 0u : 0x6c5b2c0au)) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(fuel, (unsigned)((int)*mp < (int)g0), (unsigned)((int)(unsigned)f0 >= (int)(unsigned)(u1 == (unsigned)c1))); }
                    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn1(~(a0[u1 & 3u] + (unsigned)x0), (0x707cf426u * 0xa52d331au), (unsigned)(unsigned char)(0x74eee9a7u + (0x80000000u + garr[u2 & 7u]))); }
                        a0[((unsigned)b0 & (unsigned)x0) & 3u] = (unsigned)((i1 / ((unsigned)((unsigned)((short)*q0 > (signed char)(unsigned)h1) < g1) | 1u)) == 0x5a2d15beu);
                        r0.x = (unsigned)((m0 + 0xffffffffu) < (a0[i0 & 3u] ^ (unsigned)((short)m0 > (signed char)fuel)));
                        if (((unsigned)b0 << ((unsigned)b0 & 31u))) continue;
                    }
                    goto L3;
                    switch ((unsigned)!((unsigned)(2u || i2) & (unsigned)s1) & 7u) {
                        v0 = (u0 | (unsigned)(r0.y && *q0));
                        if ((unsigned)((short)(unsigned)e0 > (signed char)u0)) continue;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)w0 ^ (unsigned)((int)u1 >= (int)u1)), (unsigned)((short)0x7fffffffu > (signed char)(unsigned)b0), (unsigned)(short)(unsigned)(*mp || (unsigned)(0x80000000u || 5u))); }
                        e0 = e0 * 0.5L + (long double)(3u & 1023u);
                        garr[(unsigned)(x0 >> 70) & 7u] = (unsigned)(((unsigned)((short)0x68680de7u > (signed char)(unsigned)h0) * (unsigned)w0) < (0x80000000u / ((unsigned)h1 | 1u)));
                    }
                    if (m0) break;
                }
            }
            u0 = u0 * 0x9e3779b1u + ((unsigned)s0 & p1);
        }
        if ((unsigned)(signed char)(p2 ^ (fuel ^ garr[i1 & 7u]))) goto L0;
        switch (g1 & 7u) {
            c1 = (signed char)((unsigned)(u1 == 0x7fffffffu) - (unsigned)((short)~(unsigned)(u1 && (unsigned)f0) > (signed char)(unsigned)h1));
            if ((unsigned)e0) {
                s1 = (int)((unsigned)s1 + (unsigned)(2u < -(m0 >> (v0 & 31u))));
            } else {
                l0 = (long)((unsigned long)l0 + (((unsigned)b0 - 2u) % ((u0 >> (2u & 31u)) | 1u)));
                u0 = (unsigned)h0;
                r0.x = (unsigned)(8u || (r0.x ? 0x10000u : i1));
            }
            switch (r0.y & 7u) {
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    case 5u: ;
                    goto L0;
                    c1 = (signed char)(unsigned)(((unsigned)c0 / (i2 | 1u)) < (unsigned)((int)p0 >= (int)u0));
                }
            }
            goto done;
            i0 = (unsigned)((unsigned)((unsigned)s0 < 0x44d8d0c3u) < 0x67423588u) & 15u;
        }
    } else {
        c0 = (unsigned char)((unsigned)((short)v0 > (signed char)*mp) | (unsigned)((int)(unsigned)((int)r0.x >= (int)r0.y) >= (int)0x9034ae82u));
        do { if (--fuel == 0u) goto done;
            a0[i0 & 3u] = (unsigned)(w0 >> 29);
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)e0, v0, garr[i1 & 7u]); }
            if (0x10000u) break;
            s1 = (int)((unsigned)s1 + (unsigned)!(unsigned)((unsigned)((int)3u >= (int)*mp) || (unsigned)(short)(v0 << (*mp & 31u))));
            i0 = (unsigned)((8u / ((unsigned)(unsigned char)(0xffffffffu << ((unsigned)((int)r0.x >= (int)(unsigned)(w0 >> 29)) & 31u)) | 1u)) == p1) & 15u;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)u3 >= (int)(u1 + 6u)), (0u >> (fuel & 31u)), 0x80000000u); }
        } while (i0++ < 6u && i1);
        if ((v0 / (-((unsigned)b0 & 0x8c33579u) | 1u))) {
            *q0 += (r0.y - ((unsigned)s1 ^ (unsigned)l0));
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(u1 < 5u) - (unsigned)d0), (unsigned)((u0 % (g0 | 1u)) || (unsigned)h0), (0x9524ad50u - ((unsigned)c1 ^ v0))); }
        }
    }
    if (((unsigned)w0 & m0)) {
        c0 = (unsigned char)(((unsigned)c1 % (r0.y | 1u)) / ((unsigned)c0 | 1u));
        { unsigned t4; double z4; if (((unsigned)((unsigned)c0 || g0)) & 1u) { t4 = (fuel ^ garr[i1 & 7u]); z4 = (double)((((unsigned)(p2 || garr[i1 & 7u]) ^ g1)) & 255u); } if (((unsigned)((unsigned)c0 || g0)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            g0 = ((unsigned)(a0[u1 & 3u] || (unsigned)e0) ^ 2u);
            b0 = (unsigned)(i1 && 0x7fffffffu) != 0u;
        }
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            a0[0x43455700u & 3u] = v0;
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(*q0 < (unsigned)((int)v0 < (int)u3))) break;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                g1 += (p2 ? 0u : r0.y);
                m0 ^= (unsigned)x0;
                g0 = (unsigned)(signed char)((unsigned)f0 - (unsigned)(a0[u1 & 3u] || (unsigned)(3u == (i2 % ((unsigned)(x0 >> 70) | 1u)))));
                do { if (--fuel == 0u) goto done;
                    break; (void)(garr[i1 & 7u]);
                    if ((0x80000000u % ((unsigned)(0x7fffffffu == i2) | 1u))) {
                        goto L2;
                        break; (void)((r0.y ^ (unsigned)((int)(unsigned)x0 < (int)(unsigned)d0)));
                        if (0xa937205du) break;
                        s0 = (int)(unsigned)b0;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)r0.x > (signed char)(unsigned)((int)0x80000000u < (int)(unsigned)(x0 >> 70))), (6u - 0x7fffffffu), (u0 * i1)); }
                        g0 = r0.y;
                    }
                    if ((unsigned)((short)(unsigned)s1 > (signed char)fuel)) {
                        u2 = ((a0[u1 & 3u] ? 0x10000u : (unsigned)(signed char)(unsigned)(*q0 || (unsigned)(w0 >> 29))) + fuel);
                        if (budget != 0u) { budget -= 1u; u3 = fn1(u0, 0x36746385u, u1); }
                    }
                } while (i2++ < 3u && (9u ? r0.y : a0[i0 & 3u]));
                *q0 = (unsigned)(signed char)((r0.y / (*mp | 1u)) ? r0.y : 0x90cf2251u);
            }
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (0xee0e342u >> ((unsigned)((unsigned)(a0[i0 & 3u] || (unsigned)x0) < (unsigned)e0) & 31u));
                { unsigned t5; double z5; if ((u2) & 1u) { t5 = ((unsigned)d0 / ((unsigned)f0 | 1u)); z5 = (double)(((unsigned)((int)a0[i0 & 3u] < (int)fuel)) & 255u); } if ((u2) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                    m0 ^= ((a0[i0 & 3u] ? u0 : (unsigned)!((unsigned)e0 + p1)) / (r0.x | 1u));
                    while ((unsigned)((unsigned)h0 || (unsigned)!(0xffffffffu >> ((unsigned)w0 & 31u)))) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((short)i0 > (signed char)g1));
                        if (0u) goto done;
                        e0 = e0 * 0.5L + (long double)((0u * ((6u >> (p0 & 31u)) / ((unsigned)((short)u1 > (signed char)(unsigned)s1) | 1u))) & 1023u);
                    }
                    if ((unsigned)(unsigned char)(0x7fffffffu >> (7u & 31u))) break;
                    continue; (void)((garr[u2 & 7u] << (*mp & 31u)));
                    b0 = (unsigned)((int)g0 >= (int)*q0) != 0u;
                    do { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)(0x3d3988bau & r0.y);
                        h1 = (unsigned short)(h1 + ((u0 - r0.x) ? (unsigned)l0 : u2));
                        if (budget != 0u) { budget -= 1u; u1 = fn0(a0[u1 & 3u], (unsigned)c1, (unsigned)((int)0x80000000u >= (int)7u)); }
                        goto L2;
                        goto L4;
                        break; (void)(-((unsigned)w0 ? (unsigned)e0 : (unsigned)c1));
                    } while (i2++ < 4u && ((unsigned)((int)(unsigned)w0 >= (int)garr[i1 & 7u]) ^ (unsigned)(x0 >> 70)));
                }
                switch (p2 & 7u) {
                    for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (((unsigned)(0x10000u < p0) >> (p0 & 31u))) break;
                        d0 = d0 * 0.5 + (double)((r0.x >> ((*q0 ^ (unsigned)((int)(unsigned)s0 < (int)(unsigned)((int)0x10000u >= (int)a0[u1 & 3u]))) & 31u)) & 1023u);
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)*mp >= (int)v0), ((unsigned)((short)u0 > (signed char)0x7083e93eu) * 0x7fffffffu), (unsigned)(0x80000000u || (unsigned)e0)); }
                        u3 ^= (p0 + 0x80000000u);
                        r0.y ^= ((unsigned)(garr[u2 & 7u] || fuel) ? (unsigned)((short)7u > (signed char)0x80000000u) : (unsigned)c0);
                    }
                }
            }
            switch (p2 & 7u) {
                r0.x = (g0 / (r0.y | 1u));
            }
            if ((0xa91d1806u << (u0 & 31u))) break;
        }
    }
    c0 = (unsigned char)-((u1 - u1) / (0x1c7ca50cu | 1u));
    { unsigned t6; double z6; if (((unsigned)f0) & 1u) { t6 = (7u + ((unsigned)f0 / (2u | 1u))); z6 = (double)(((m0 >> (0xe98151bdu & 31u))) & 255u); } if (((unsigned)f0) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
        u1 ^= ((unsigned)(u0 == garr[u2 & 7u]) << ((unsigned)((*q0 ^ 0x7fffffffu) == 0x7fffffffu) & 31u));
        q0 = &garr[(unsigned)((0x111a0cddu << (8u & 31u)) == (unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)s0 || (unsigned)h1) || (unsigned)h1)) & 7u];
    }
    if (0x6b0f380fu) goto L4;
    if (v0) {
        switch ((unsigned)(p2 && (unsigned)(r0.y && (unsigned)c0)) & 7u) {
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 6u: ;
            }
            if ((((unsigned)e0 / ((unsigned)s1 | 1u)) << (0xe70ff96cu & 31u))) break;
            *mp = (unsigned)((int)u3 >= (int)((unsigned)((unsigned)b0 < u3) - r0.x));
        }
        c0 = (unsigned char)1u;
        if ((0x7fffffffu | (p2 >> (garr[i1 & 7u] & 31u)))) goto L3;
    }
    for (;;) { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (0x7fffffffu << (u2 & 31u));
    }
    *mp = (u3 + (unsigned)e0);
    goto L2;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)((unsigned)c1 ^ u0) >= (int)(unsigned)e0), (unsigned)s1, (unsigned)c1); }
        c1 = (signed char)(unsigned)h1;
        if (budget != 0u) { budget -= 1u; u3 = fn0((p0 / ((unsigned)((unsigned)(w0 >> 29) == 9u) | 1u)), fuel, (unsigned)((unsigned)!(unsigned)(r0.y == 9u) == 1u)); }
        h0 = (short)((unsigned)(r0.y && ((unsigned)x0 << (garr[i1 & 7u] & 31u))) / ((unsigned)((unsigned)c1 && 5u) | 1u));
        if ((u1 * (0xbec02469u ^ 2u))) continue;
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t7; double z7; if (((unsigned)c0) & 1u) { t7 = (garr[u2 & 7u] / (p0 | 1u)); z7 = (double)((0x59ee7bedu) & 255u); } if (((unsigned)c0) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
            u3 += (unsigned)(0x924b0354u || (unsigned)(unsigned char)((3u >> ((unsigned)x0 & 31u)) / ((unsigned)s1 | 1u)));
        }
        if ((u2 / ((unsigned)c0 | 1u))) break;
    }
    u0 = ~((unsigned)((unsigned)x0 < (unsigned)h0) + (unsigned)(g1 < (unsigned)(x0 >> 70)));
    c0 = (unsigned char)(unsigned)((short)r0.x > (signed char)(unsigned)(0x10000u || (unsigned)e0));
    if ((0x80000000u << ((8u % (0x7fffffffu | 1u)) & 31u))) {
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)g0 > (signed char)r0.x), (unsigned)(short)(*q0 ^ 0xffffffffu), (u1 << (garr[i1 & 7u] & 31u))); }
        d0 = d0 * 0.5 + (double)(i1 & 1023u);
        goto L2;
        goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((0u >> ((unsigned)x0 & 31u)), (unsigned)(signed char)(0x538658fau + (unsigned)(w0 >> 29)), (0xffffffffu * 0x35368a21u)); }
        while (i0++ < 2u && i0) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(p2, 0xb04ed72fu, (unsigned)(i2 == (unsigned)(short)(0x80000000u & u0))); }
            if (u3) {
                u1 = u1 * 0x9e3779b1u + (unsigned)!(p1 % ((unsigned)((short)0x6023f682u > (signed char)(i1 << ((unsigned)(r0.y || p2) & 31u))) | 1u));
            }
            *q0 += m0;
            garr[(unsigned)((short)0xb901d083u > (signed char)(unsigned)(x0 >> 70)) & 7u] = (p1 >> (((unsigned)((int)(p0 ^ u2) < (int)9u) + (unsigned)x0) & 31u));
            u0 ^= (unsigned)((short)(*mp & (unsigned)f0) > (signed char)5u);
            break; (void)((unsigned)((int)a0[i0 & 3u] < (int)a0[u1 & 3u]));
        }
    }
    u3 += ((unsigned)((int)(unsigned)s0 < (int)6u) - m0);
    do { if (--fuel == 0u) goto done;
        if ((0xfc15c2d1u ^ 5u)) {
            i2 = (unsigned)((short)(unsigned)d0 > (signed char)((v0 ? 0x10000u : (unsigned)w0) >> (m0 & 31u))) & 15u;
            if ((unsigned)((short)(i0 ^ 2u) > (signed char)garr[i1 & 7u])) {
                c1 = (signed char)(unsigned)(short)(unsigned)(5u && *q0);
                switch (u1 & 7u) {
                    case 5u: ;
                    b0 = (7u + 0x68dd6541u) != 0u;
                }
                if ((unsigned)!(unsigned)((int)(unsigned)c0 < (int)p1)) break;
                g1 += ((m0 | i1) >> (u3 & 31u));
            } else {
                c0 = (unsigned char)m0;
                h0 = (short)(unsigned)s1;
            }
        }
        do { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((-(0u ? (unsigned)(u1 || a0[u1 & 3u]) : (unsigned)(w0 >> 29)) << (0x2cb2a088u & 31u)) & 1023u);
            for (;;) { if (--fuel == 0u) goto done;
                a0[(unsigned)c0 & 3u] = ((u1 * p0) ^ 0u);
                while (i0++ < 7u && *q0) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)~(unsigned)(g1 && 0x7fffffffu) >= (int)(unsigned)x0)) goto L2;
                    q0 = &garr[(u0 ? -((unsigned)s1 ? (unsigned)(x0 >> 70) : r0.y) : (unsigned)l0) & 7u];
                    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)x0 | (unsigned)(short)(unsigned)(*q0 == (unsigned)(w0 >> 29))), 0x10000u, -(unsigned)(0u == (unsigned)l0)); }
                    if (g0) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)r0.x >= (int)fuel), (unsigned)((int)r0.y >= (int)(4u + (unsigned)s1)), (unsigned)c1); }
                    h1 = (unsigned short)(h1 + (unsigned)s1);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1(p2, (unsigned)!(0xc0d76f38u ^ u1), ((unsigned)(u0 < p2) | 0xcf88f0eu)); }
                break; (void)(a0[i0 & 3u]);
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(0x7ccd3744u, 0x409e7336u, (((unsigned)(x0 >> 70) - (unsigned)h1) * a0[u1 & 3u])); }
                    w0 = w0 * 6364136223846793005ull + ((unsigned)h1 / ((p0 * g0) | 1u));
                    continue; (void)((unsigned)f0);
                }
            }
            break; (void)((unsigned)(x0 >> 70));
            h1 = (unsigned short)(h1 + r0.y);
            switch ((unsigned)((unsigned)x0 && u3) & 7u) {
                i2 = ((unsigned)((unsigned)x0 < ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)e0) << ((unsigned)h0 & 31u))) ^ 0x121be2efu) & 15u;
                case 0u: ;
                case 4u: ;
                while (i2++ < 3u && 0x80000000u) { if (--fuel == 0u) goto done;
                    default: ;
                    v0 = (i2 ^ ((unsigned)f0 | (unsigned)s0));
                    s0 = (int)(((unsigned)c1 ? fuel : i0) % (0x7fffffffu | 1u));
                    break;
                }
            }
        } while (i1++ < 4u && 0u);
        do { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)((short)(unsigned)!((unsigned)!(unsigned)(r0.x < (unsigned)s1) - (i0 ^ 0x5c74cc4eu)) > (signed char)a0[i0 & 3u]);
            q0 = &garr[((unsigned)((unsigned)(0xf6c350e2u < (unsigned)(w0 >> 29)) < (unsigned)s1) + (unsigned)d0) & 7u];
            b0 = (unsigned)((short)(unsigned)(garr[i1 & 7u] && 8u) > (signed char)(unsigned)!((unsigned)c0 ^ (garr[u2 & 7u] - 0x47c4ca3eu))) != 0u;
        } while (i1++ < 3u && (unsigned)s0);
        garr[(0xffffffffu * g1) & 7u] = (unsigned)((unsigned)b0 < (unsigned)l0);
        w0 ^= (unsigned long long)p0 << ((0xc38748bau ? (unsigned)c1 : (unsigned)(short)((unsigned)s1 % (v0 | 1u))) & 63u);
        { unsigned t8; double z8; if (((unsigned)((int)((unsigned)w0 / (u2 | 1u)) < (int)0x7fffffffu)) & 1u) { t8 = (0x7fffffffu + (u0 / (1u | 1u))); z8 = (double)((5u) & 255u); } if (((unsigned)((int)((unsigned)w0 / (u2 | 1u)) < (int)0x7fffffffu)) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
            if (((unsigned)d0 * 8u)) break;
            i2 = 0x4f80bfe0u & 15u;
            garr[(unsigned)(short)(i1 ^ 0x10000u) & 7u] = (unsigned)((unsigned)c1 || (unsigned)l0);
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(signed char)(unsigned)((int)r0.x < (int)(unsigned)w0), (unsigned)c0, garr[u2 & 7u]); }
            a0[(unsigned)s1 & 3u] = (unsigned)(signed char)(unsigned)((0x296dadeu | ((unsigned)c0 ^ 0x80000000u)) == i2);
        }
    } while (i0++ < 7u && garr[u2 & 7u]);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 = (0xd6e28fe5u ? i1 : (unsigned)b0);
        switch ((unsigned)((short)0x80000000u > (signed char)(unsigned)d0) & 7u) {
            goto L1;
            if ((4u | (unsigned)(w0 >> 29))) continue;
            case 3u: ;
        }
        u2 ^= (unsigned)(0x10000u && 0x10000u);
        if (fuel) continue;
    }
    if (fuel) goto L1;
    if ((9u & ((unsigned)b0 << (a0[u1 & 3u] & 31u)))) {
        if (budget != 0u) { budget -= 1u; u1 = fn1((5u % (0xed54f25eu | 1u)), (u3 & garr[i1 & 7u]), (unsigned)(x0 >> 70)); }
        if (0x10000u) {
            if ((((unsigned)h1 - m0) * u0)) goto L3;
            q0 = &garr[(7u - 5u) & 7u];
            goto L1;
            m0 ^= (unsigned)((int)0x7fffffffu < (int)(unsigned)(w0 >> 29));
            l0 = (long)((unsigned long)l0 + ((i2 * (unsigned)s1) & (unsigned)f0));
            goto L3;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)l0, (g0 >> ((garr[i1 & 7u] ^ a0[u1 & 3u]) & 31u)), (unsigned)h1); }
        w0 = w0 * 6364136223846793005ull + (unsigned)!(unsigned)(u2 && (*q0 | 0x209dac68u));
    }
    if (0xc995a04bu) goto L4;
    if (budget != 0u) { budget -= 1u; u2 = fn0(0x7fffffffu, (((unsigned)w0 % ((unsigned)(w0 >> 29) | 1u)) >> (v0 & 31u)), (unsigned)((unsigned)!((unsigned)w0 + (unsigned)l0) < i1)); }
    if ((unsigned)b0) goto L4;
    for (;;) { if (--fuel == 0u) goto done;
        while (i1++ < 3u && (r0.x & (unsigned)h1)) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)c0;
            *mp = (i2 - (fuel & fuel));
            { unsigned t9; double z9; if (((i2 & u3)) & 1u) { t9 = ~(unsigned)(u0 || u3); z9 = (double)(((unsigned)(signed char)(-(unsigned)((short)*q0 > (signed char)4u) + 0x59138938u)) & 255u); } if (((i2 & u3)) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
                if (0xffffffffu) goto done;
                if ((0x10000u | *mp)) break;
                q0 = &garr[*mp & 7u];
                if (budget != 0u) { budget -= 1u; u0 = fn0(4u, a0[i0 & 3u], (unsigned)(9u < (unsigned)c0)); }
                if ((unsigned)((int)(unsigned)c1 >= (int)(unsigned)b0)) break;
            }
            q0 = &garr[(unsigned)((int)(unsigned)(x0 >> 70) >= (int)4u) & 7u];
            g1 += (unsigned)d0;
            e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)(*mp * (unsigned)h1) & 1023u);
        }
        if ((u1 >> (i1 & 31u))) {
            goto L0;
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)p2 > (signed char)(7u / (p1 | 1u))), g0, (unsigned)(signed char)(unsigned)(0x8e55600bu || (unsigned)(w0 >> 29))); }
            continue; (void)(0xc9f45227u);
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)(v0 < 3u);
                w0 = w0 * 6364136223846793005ull + -((unsigned)((int)0x80000000u < (int)p1) << (((unsigned)l0 ^ (unsigned)(x0 >> 70)) & 31u));
                d0 = d0 * 0.5 + (double)(((unsigned)(fuel || ((unsigned)(w0 >> 29) | 0x90f0febu)) >> ((unsigned)d0 & 31u)) & 1023u);
            }
        }
        s0 = (int)(unsigned)(signed char)(i0 % (i1 | 1u));
        while ((unsigned)h1) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)((i0 / (u1 | 1u)));
                w0 = w0 * 6364136223846793005ull + (*mp * (fuel / (((unsigned)f0 * u3) | 1u)));
                if (0x951600ddu) goto L4;
            }
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                r0.x = (unsigned)c0;
                c1 = (signed char)((unsigned)x0 % (m0 | 1u));
                w0 = w0 * 6364136223846793005ull + (i0 << (u2 & 31u));
                if ((unsigned)(5u == m0)) {
                    if ((unsigned)((int)(unsigned)h1 < (int)i0)) break;
                    if ((unsigned)((short)9u > (signed char)u0)) break;
                    break; (void)(p1);
                    { unsigned t10; double z10; if (((unsigned)(short)(unsigned)((int)a0[u1 & 3u] < (int)garr[i1 & 7u])) & 1u) { t10 = (unsigned)(short)(((unsigned)c1 & 0x10000u) << (m0 & 31u)); z10 = (double)(((r0.y + 0x370e293au)) & 255u); } if (((unsigned)(short)(unsigned)((int)a0[u1 & 3u] < (int)garr[i1 & 7u])) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
                        if ((unsigned)((unsigned)!(p1 ^ (unsigned)e0) || (unsigned)x0)) break;
                        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(u3 == ((unsigned)h1 - i2)) && u1) & 1023u);
                    }
                    s0 = (int)-(p2 + (unsigned)(*q0 < garr[i1 & 7u]));
                }
                break; (void)((unsigned)((short)0xffffffffu > (signed char)(unsigned)((int)fuel >= (int)(unsigned)h0)));
            }
        }
        v0 = (unsigned)(((0xffffffffu << (0x3e7e2dfeu & 31u)) << ((unsigned)(short)(g0 | i1) & 31u)) && 0xffffffffu);
    }
    { unsigned t11; double z11; if (((unsigned)d0) & 1u) { t11 = (i1 * 4u); z11 = (double)(((a0[u1 & 3u] << ((unsigned)b0 & 31u))) & 255u); } if (((unsigned)d0) & 1u) { u3 += t11; d0 = d0 * 0.5 + z11; }
        goto L0;
        if ((unsigned)((int)u3 >= (int)*q0)) goto L1;
        switch ((unsigned)((unsigned)(8u == p2) && (unsigned)c0) & 7u) {
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 1u: ;
                if ((unsigned)e0) goto L2;
                h1 = (unsigned short)(h1 + 0xffffffffu);
            }
            case 4u: ;
            *q0 += (unsigned)(((0x4943bd4u / ((unsigned)w0 | 1u)) | *q0) && (unsigned)(x0 >> 70));
            s0 = (int)(unsigned)((int)(unsigned)(p1 < u2) < (int)(u1 << (u2 & 31u)));
            default: ;
            x0 = x0 * 0x100000001b3ull + (unsigned)d0;
        }
    }
    if (0xffffffffu) goto L0;
    if ((u3 - (unsigned)w0)) goto L3;
    goto done;
    x0 = x0 * 0x100000001b3ull + ((unsigned)e0 / ((a0[i0 & 3u] * a0[i0 & 3u]) | 1u));
    if (fuel < 8u) return fuel;
    { unsigned t12; double z12; if ((-(unsigned)((int)(unsigned)w0 < (int)0x8ee350e5u)) & 1u) { t12 = g0; z12 = (double)(((unsigned)((unsigned)x0 == 0x2f032486u)) & 255u); } if ((-(unsigned)((int)(unsigned)w0 < (int)0x8ee350e5u)) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
        do { if (--fuel == 0u) goto done;
            goto L2;
        } while (i0++ < 3u && v0);
    }
    while ((unsigned)(i1 < (u2 & fuel))) { if (--fuel == 0u) goto done;
        while ((unsigned)((int)g1 < (int)(unsigned)!((unsigned)s1 + 0xcbdb9e49u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)0x80000000u < (int)r0.x), (unsigned)l0, (unsigned)((unsigned)l0 == (unsigned)c0)); }
            do { if (--fuel == 0u) goto done;
                if (((unsigned)b0 + 0xffffffffu)) break;
                *q0 += (unsigned)((int)(unsigned)((short)*q0 > (signed char)(unsigned)c1) < (int)(unsigned)w0);
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    u3 += (unsigned)((short)a0[u1 & 3u] > (signed char)u0);
                    goto L2;
                    r0.x = ((unsigned)s1 ^ (unsigned)(v0 && p1));
                    if ((-(unsigned)((short)a0[u1 & 3u] > (signed char)0x7fffffffu) ^ u1)) break;
                    do { if (--fuel == 0u) goto done;
                        i2 = (p1 % ((unsigned)x0 | 1u)) & 15u;
                        f0 = f0 * 0.5f + (float)((unsigned)(x0 >> 70) & 255u);
                        a0[(unsigned)(0xffffffffu && 0xc3974f01u) & 3u] = 0xf59ea928u;
                    } while (i1++ < 6u && (unsigned)(short)((0xafeb9c39u & (unsigned)(w0 >> 29)) & m0));
                    break; (void)((unsigned)c0);
                }
                if ((unsigned)((int)0u >= (int)g0)) break;
                for (;;) { if (--fuel == 0u) goto done;
                    if ((g1 * (unsigned)l0)) break;
                }
                { unsigned t13; double z13; if ((0xc5b60697u) & 1u) { t13 = ((4u / (0x3d250b35u | 1u)) & (unsigned)h1); z13 = (double)(((0x968e1a62u % (g0 | 1u))) & 255u); } if ((0xc5b60697u) & 1u) { u3 += t13; d0 = d0 * 0.5 + z13; }
                    if ((unsigned)!(p0 | (unsigned)b0)) break;
                }
            } while (i2++ < 3u && a0[i0 & 3u]);
        }
        break; (void)((unsigned)((short)(unsigned)h1 > (signed char)v0));
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s0, 8u, (unsigned)(signed char)(p0 % (g1 | 1u))); }
            if (5u) break;
            b0 = ((unsigned)(w0 >> 29) | ((unsigned)(w0 >> 29) + 8u)) != 0u;
            if ((unsigned)b0) goto L4;
            if ((unsigned)((int)((unsigned)f0 / (v0 | 1u)) < (int)0xffffffffu)) continue;
        }
        x0 = x0 * 0x100000001b3ull + (0x34efd873u ^ (unsigned)d0);
    }
    a0[(v0 ^ (unsigned)(x0 >> 70)) & 3u] = (unsigned)((unsigned)((unsigned)(x0 >> 70) == u0) && (0x94e94034u << (0x7fffffffu & 31u)));
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1(g0, r0.y, (unsigned)(((unsigned)(x0 >> 70) * *mp) && p2)); }
    } while (i0++ < 4u && (unsigned)((int)(garr[u2 & 7u] - p1) < (int)(unsigned)s1));
    while (i0++ < 5u && (unsigned)(0x10000u && 9u)) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)((short)u2 > (signed char)i2) & 1023u);
        if ((unsigned)(m0 < 0x7fffffffu)) continue;
        for (;;) { if (--fuel == 0u) goto done;
            if (4u) break;
            do { if (--fuel == 0u) goto done;
                if (i2) continue;
            } while (i2++ < 3u && *q0);
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)(m0 < 0x10000u));
                if ((unsigned)((int)p0 < (int)(unsigned)(w0 >> 29))) break;
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((0xea6b6130u - g1)) break;
                    if (0xdb4e275cu) break;
                    *q0 = (unsigned)(w0 >> 29);
                    garr[(unsigned)c0 & 7u] = (unsigned)((int)0x80000000u < (int)(p1 ? u3 : garr[i1 & 7u]));
                }
                if (((unsigned)l0 - (unsigned)((int)p1 < (int)(unsigned)s1))) break;
                if ((unsigned)((int)(0x10000u - 9u) >= (int)v0)) break;
            }
            if (((unsigned)(signed char)(unsigned)((short)p1 > (signed char)(unsigned)c0) - (unsigned)b0)) {
                s0 = (int)(unsigned)((int)(u0 % ((0x7fffffffu << ((0x9473715eu | 0x485cd80bu) & 31u)) | 1u)) < (int)r0.x);
                u3 = (((unsigned)c1 % (fuel | 1u)) ? 9u : g0);
                l0 = (long)((unsigned long)l0 + (unsigned)((short)(u2 << ((unsigned)(x0 >> 70) & 31u)) > (signed char)(unsigned)!(unsigned)(r0.x == 0xffffffffu)));
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(((unsigned)f0 - (unsigned)c0) && i1)) {
                        c0 = (unsigned char)garr[i1 & 7u];
                        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                            g0 = (unsigned)(-(unsigned)((short)(unsigned)c1 > (signed char)(unsigned)d0) || (g0 ^ (0xaefc0c88u * garr[u2 & 7u])));
                            if ((unsigned)((unsigned)b0 && (r0.y * i0))) break;
                            c1 = (signed char)(unsigned)((int)(unsigned)e0 >= (int)(unsigned)s0);
                            u0 ^= i1;
                            if (0x178c9200u) break;
                        }
                        continue; (void)((unsigned)(unsigned char)(0x10000u % ((unsigned)((unsigned)w0 || (unsigned)h0) | 1u)));
                    } else {
                        if (0xc2126c74u) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(7u, ((unsigned)e0 >> (*mp & 31u)), v0); }
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(a0[i0 & 3u] && (unsigned)s1) % (i2 | 1u)), 0x1488e9a5u, (unsigned)(g0 == (unsigned)f0)); }
                    break; (void)((unsigned)((int)(0x10000u | (unsigned)c0) < (int)0xffffffffu));
                }
            } else {
                *mp = (((*q0 % (0x921c2225u | 1u)) * u3) ^ (unsigned)(u3 < 0x80000000u));
            }
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(i2 == (0x10000u | garr[u2 & 7u])), ((unsigned)(0x10000u && u3) * i2), ((unsigned)s0 / (0x54e1d623u | 1u))); }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(0u || (unsigned)(w0 >> 29)) ^ m0), (unsigned)((int)(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)s1) < (int)r0.x), (unsigned)((garr[u2 & 7u] + 0x1e046dfcu) < (unsigned)w0)); }
        l0 = (long)((unsigned long)l0 + fuel);
    }
    if ((unsigned)(a0[u1 & 3u] || (unsigned)((int)a0[u1 & 3u] < (int)g1))) {
        if (budget != 0u) { budget -= 1u; u3 = fn1(i0, (unsigned)(short)(unsigned)((unsigned)x0 || (unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)c1)), 0xe29f7d8du); }
        if ((unsigned)(signed char)(unsigned)(*mp == v0)) {
            q0 = &garr[((unsigned)((unsigned)f0 == (*mp * (unsigned)e0)) + (6u / (0xffffffffu | 1u))) & 7u];
            if (a0[i0 & 3u]) goto L0;
            if ((unsigned)f0) goto L3;
        } else {
            x0 = x0 * 0x100000001b3ull + (fuel ? fuel : *q0);
            goto L1;
        }
        *mp = ((unsigned)h1 / ((7u >> ((unsigned)((int)r0.x >= (int)(unsigned)l0) & 31u)) | 1u));
        *q0 = v0;
        if (((unsigned)x0 ^ u1)) goto L1;
        e0 = e0 * 0.5L + (long double)((unsigned)((p2 << (g1 & 31u)) == (0xd5d1f8ecu << (i0 & 31u))) & 1023u);
    }
    while (i0++ < 7u && (i1 & (unsigned)(u1 && garr[u2 & 7u]))) { if (--fuel == 0u) goto done;
        while ((unsigned)(signed char)((unsigned)x0 & (u2 << (garr[i1 & 7u] & 31u)))) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)(x0 >> 70) << ((unsigned)b0 & 63u);
            if ((unsigned)l0) goto done;
            w0 = w0 * 6364136223846793005ull + p0;
            if (u3 == 7u) return 7u;
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= ((0x7fffffffu | (unsigned)(w0 >> 29)) + (unsigned)!(i2 >> (u0 & 31u)));
                e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)((short)(unsigned)x0 > (signed char)(0x45b17b5eu ^ (unsigned)d0)) < (int)(unsigned)c0) & 1023u);
                if (budget != 0u) { budget -= 1u; u0 = fn0(-(unsigned)(((unsigned)w0 * 0xbebc4b2eu) || 7u), 0xa8955c2eu, (garr[i1 & 7u] * (fuel - (unsigned)w0))); }
                { unsigned t14; double z14; if (((unsigned)((short)0xf4d26bafu > (signed char)0x7fffffffu)) & 1u) { t14 = (unsigned)(v0 < (unsigned)w0); z14 = (double)((((unsigned)(1u < (unsigned)x0) * (unsigned)x0)) & 255u); } if (((unsigned)((short)0xf4d26bafu > (signed char)0x7fffffffu)) & 1u) { u3 += t14; d0 = d0 * 0.5 + z14; }
                    h0 = (short)~(unsigned)((1u & (unsigned)d0) && (u2 | a0[u1 & 3u]));
                    *mp = (u0 + 6u);
                    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (~(unsigned)((short)g0 > (signed char)(unsigned)((int)0xc8bc93e2u < (int)0x7fffffffu))) break;
                    }
                    x0 = x0 * 0x100000001b3ull + ((unsigned)((int)(unsigned)d0 >= (int)(unsigned)c0) - *q0);
                    if ((unsigned)(w0 >> 29)) goto L3;
                    g1 += r0.y;
                }
            }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(unsigned char)((i1 * 0x80000000u) * p2), (unsigned)(w0 >> 29), 1u); }
    }
    while (((unsigned)w0 % ((unsigned)(g1 && i2) | 1u))) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)(v0 == i2) & 1023u);
        r0.y ^= 0xfe668722u;
        if (budget != 0u) { budget -= 1u; u0 = fn0(u2, (unsigned)h1, (unsigned)(u2 && garr[u2 & 7u])); }
        continue; (void)(*q0);
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(p0 < (unsigned)((short)0xcbe4c3c2u > (signed char)(unsigned)c1)), m0, ((unsigned)((int)0x1ed01617u >= (int)(unsigned)(w0 >> 29)) << (r0.y & 31u))); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u1 = fn2((g1 | (unsigned)(0x80000000u || g1)), 0x1a79b5eau, garr[u2 & 7u]); }
    w0 = w0 * 6364136223846793005ull + a0[i0 & 3u];
    if (4u) goto L4;
    if (((unsigned)(w0 >> 29) / ((unsigned)w0 | 1u))) goto L4;
    if ((unsigned)c1) {
        switch ((unsigned)((unsigned)h0 && u1) & 7u) {
            if (i1) {
                f0 = f0 * 0.5f + (float)(1u & 255u);
                e0 = e0 * 0.5L + (long double)(0xffffffffu & 1023u);
                m0 ^= (unsigned)!(unsigned)((short)~(0xb27bcca4u ^ (unsigned)((int)(unsigned)c0 < (int)(unsigned)((unsigned)l0 < *mp))) > (signed char)i2);
            }
            if ((r0.y + (unsigned)(short)(0x10000u * u1))) {
                case 7u: ;
                case 4u: ;
            } else {
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)l0 << (0xcf979e60u & 31u))) break;
                    g1 += g0;
                    { unsigned t0; double z0; if (((unsigned)((unsigned)e0 == 0xffffffffu)) & 1u) { t0 = (i1 & a0[i0 & 3u]); z0 = (double)((((unsigned)b0 * 0xc3f91894u)) & 255u); } if (((unsigned)((unsigned)e0 == 0xffffffffu)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                        s0 = (int)0x80000000u;
                    }
                    break; (void)(2u);
                    if (0x80000000u) break;
                }
            }
            r0.x = (unsigned)((unsigned)(r0.y == a0[u1 & 3u]) == (unsigned)w0);
        }
    }
    if ((unsigned)((0x52a54e04u * (unsigned)d0) && (unsigned)d0)) goto L1;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 += (unsigned)((short)(0x82899b6cu % (r0.y | 1u)) > (signed char)(p2 ^ (unsigned)((int)0xf04ed74eu >= (int)u2)));
        c0 = (unsigned char)(unsigned)(0x66bdea47u == a0[u1 & 3u]);
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1(3u, (unsigned)(v0 < (v0 ^ (unsigned)e0)), ((i0 << (6u & 31u)) << ((unsigned)h1 & 31u))); }
        do { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)((int)(unsigned)(x0 >> 70) >= (int)p0);
            r0.x = r0.x;
            l0 = (long)((unsigned long)l0 + (unsigned)((6u ? v0 : (unsigned)l0) < ((unsigned)x0 >> (p2 & 31u))));
            do { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    L0: if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + m0);
                    if (((unsigned)b0 << (u3 & 31u))) break;
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + (unsigned)s1;
                    }
                    if ((unsigned)x0) break;
                    i0 = (unsigned)((int)g1 < (int)(unsigned)h1) & 15u;
                }
                switch ((p1 / (-(unsigned)((unsigned)x0 || 0x7fffffffu) | 1u)) & 7u) {
                    x0 = x0 * 0x100000001b3ull + (unsigned)(i1 || garr[u2 & 7u]);
                }
            } while (i2++ < 7u && 0x80000000u);
            if (((unsigned)h0 + 0x63d44fau)) goto L0;
            if ((garr[u2 & 7u] << (i2 & 31u))) continue;
        } while (i1++ < 7u && (0x7ee42859u >> (0xffffffffu & 31u)));
        L1: if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)(0x10000u || (unsigned)h1));
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(unsigned char)(unsigned)(0x80000000u == (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x7fffffffu))) {
            if ((unsigned)((int)0xba1720b0u >= (int)(r0.y >> (2u & 31u)))) break;
            u0 ^= u3;
            if (((unsigned)l0 >> ((0x7fffffffu % (g0 | 1u)) & 31u))) break;
            m0 ^= (unsigned)((int)0x7fffffffu < (int)u3);
            L2: if (--fuel == 0u) goto done;
        }
        { unsigned t1; double z1; if ((r0.y) & 1u) { t1 = (unsigned)(short)(0x10000u | ((unsigned)l0 + fuel)); z1 = (double)(((unsigned)!(unsigned)((unsigned)h0 == (unsigned)h0)) & 255u); } if ((r0.y) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            do { if (--fuel == 0u) goto done;
                b0 = (unsigned)f0 != 0u;
            } while (i1++ < 2u && ((unsigned)((int)0xd989260au < (int)0x2f133324u) + u0));
            do { if (--fuel == 0u) goto done;
                *q0 += (unsigned)(x0 >> 70);
            } while (i1++ < 5u && (0x1eea964du - a0[u1 & 3u]));
            if ((0x6e2e1916u | (unsigned)s1)) {
                break; (void)(((unsigned)s0 << ((unsigned)(signed char)(unsigned)((int)7u >= (int)0x80000000u) & 31u)));
                u2 = (unsigned)((unsigned)b0 == i2);
                g0 = (unsigned)!((unsigned)c1 * (unsigned)(unsigned char)(0x71f498a8u % (p2 | 1u)));
                do { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)h0 < (u2 | (*mp + garr[i1 & 7u]))) * (unsigned)e0);
                    if ((unsigned)((unsigned)c1 == p0)) break;
                    f0 = f0 * 0.5f + (float)((((unsigned)h1 ^ 0xffffffffu) & (0x10000u - 0xffffffffu)) & 255u);
                    u1 ^= (fuel % (g0 | 1u));
                } while (i1++ < 4u && (0xffffffffu ^ v0));
                if ((unsigned)((int)0xe90f6c92u < (int)(r0.y | (unsigned)b0))) break;
                if (budget != 0u) { budget -= 1u; u2 = fn0((0x7fffffffu % (0xf325b3d1u | 1u)), (unsigned)(short)(((unsigned)s1 - m0) % (0xa07d1256u | 1u)), (a0[u1 & 3u] / (g0 | 1u))); }
            } else {
                b0 = (unsigned)((int)(0xffffffffu * (unsigned)f0) < (int)(unsigned)b0) != 0u;
                if (budget != 0u) { budget -= 1u; u2 = fn0(0x7fffffffu, (unsigned)h0, (unsigned)(short)(unsigned)((int)fuel < (int)g1)); }
                L3: if (--fuel == 0u) goto done;
            }
            u2 += ((unsigned)h1 ? 0x45d711d1u : 0x10000u);
        }
        g0 = ((unsigned)((unsigned)h1 || p2) >> ((unsigned)e0 & 31u));
    }
    { unsigned t2; double z2; if ((-(unsigned)((int)0x10000u < (int)(0x7305bfd4u * 0x80000000u))) & 1u) { t2 = (i1 ^ (unsigned)(*mp < 8u)); z2 = (double)(((unsigned)(signed char)(unsigned)(0xffffffffu == garr[i1 & 7u])) & 255u); } if ((-(unsigned)((int)0x10000u < (int)(0x7305bfd4u * 0x80000000u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        w0 ^= (unsigned long long)(6u | (unsigned)c0) << ((unsigned)((short)u1 > (signed char)0x9f03626cu) & 63u);
    }
    if (0x10000u) {
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + ((unsigned)((short)u1 > (signed char)4u) - (unsigned)c1);
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(p2 || (unsigned)!(unsigned)((int)0x6941b770u < (int)(unsigned)s1)), (unsigned)(unsigned char)(unsigned)((short)(0x5327f535u | p1) > (signed char)v0), (unsigned)((int)u0 >= (int)(unsigned)f0)); }
            } while (i1++ < 3u && (unsigned)((int)g0 < (int)0u));
            if (p0) {
                { unsigned t3; double z3; if (((a0[u1 & 3u] & (unsigned)(w0 >> 29))) & 1u) { t3 = ((unsigned)b0 + u0); z3 = (double)((*q0) & 255u); } if (((a0[u1 & 3u] & (unsigned)(w0 >> 29))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    h1 = (unsigned short)(h1 + (unsigned)(3u == (unsigned)(unsigned char)(0x80000000u ? (unsigned)c1 : 0x80000000u)));
                    for (;;) { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)0x10000u << ((unsigned)((unsigned)(x0 >> 70) < (unsigned)((unsigned)l0 == 4u)) & 63u);
                        *q0 = (unsigned)f0;
                    }
                    u3 = u3 * 0x9e3779b1u + (unsigned)((int)(unsigned)(0u || 0x3a72fb18u) < (int)fuel);
                }
                if (fuel < 8u) return (unsigned)!((unsigned)((*q0 - 0x2652a43u) == 0xffffffffu) % ((unsigned)(x0 >> 70) | 1u));
                s1 = (int)((unsigned)s1 + r0.y);
                w0 ^= (unsigned long long)0xffffffffu << ((unsigned)(u0 || garr[u2 & 7u]) & 63u);
            } else {
                if ((0xf2620aedu % (0x59a4fbefu | 1u))) {
                    if (fuel < 8u) return (unsigned)((unsigned)(unsigned char)((unsigned)c1 ? u0 : p1) && g1);
                    c0 = (unsigned char)0x10000u;
                    if (u3 == 7u) return ((unsigned)((int)0x10000u >= (int)(unsigned)e0) * 0x80000000u);
                } else {
                    if ((unsigned)((int)0x9f2775b5u < (int)0x7fffffffu)) {
                        if (budget != 0u) { budget -= 1u; u2 = fn1(u1, (unsigned)(short)(u0 << (0x7fffffffu & 31u)), r0.y); }
                        i0 = (0x65e39023u - p1) & 15u;
                        goto L4;
                    }
                }
                x0 = x0 * 0x100000001b3ull + 0xd6c6c678u;
                if (budget != 0u) { budget -= 1u; u0 = fn1((2u ^ u3), (unsigned)((unsigned)x0 || 0xfcec3630u), (r0.x ? 0xc8743db1u : (unsigned)s1)); }
            }
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)h0 % (r0.y | 1u)), (*q0 & 0x11784ec1u), p0); }
                if (u2) break;
            }
            L4: if (--fuel == 0u) goto done;
            r0.x = (0x50f0b74u << ((unsigned)((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(signed char)((unsigned)c0 << ((unsigned)d0 & 31u))) == (unsigned)f0) & 31u));
            g1 += (unsigned)((short)(r0.x % ((a0[u1 & 3u] / ((r0.y >> (3u & 31u)) | 1u)) | 1u)) > (signed char)i2);
        } while (i0++ < 3u && ((unsigned)((unsigned)c0 == 0xa2faa93au) | 5u));
        if ((u1 + a0[u1 & 3u])) {
            if (budget != 0u) { budget -= 1u; u0 = fn1(2u, (unsigned)((short)(unsigned)c1 > (signed char)(r0.x ^ r0.y)), (r0.y >> (v0 & 31u))); }
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)c1) continue;
                if (0xffffffffu) {
                    l0 = (long)((unsigned long)l0 + (unsigned)l0);
                    h1 = (unsigned short)(h1 + ((unsigned)(u0 || (unsigned)e0) | (((unsigned)b0 | (unsigned)b0) * 1u)));
                    q0 = &garr[(0x7fffffffu - (unsigned)!(unsigned)((short)g1 > (signed char)u0)) & 7u];
                }
            }
            h1 = (unsigned short)(h1 + 0xb20a0502u);
        }
        c0 = (unsigned char)(unsigned)(short)(p0 % (0xffffffffu | 1u));
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            q0 = &garr[p0 & 7u];
            *q0 = ((unsigned)h1 / (a0[u1 & 3u] | 1u));
            if (budget != 0u) { budget -= 1u; u3 = fn2(0x66585878u, (unsigned)((int)(m0 ^ r0.y) >= (int)p1), (unsigned)l0); }
            b0 = (u2 & 4u) != 0u;
            *mp = p2;
            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)h0 || 0xb41b1348u);
        }
    }
    for (;;) { if (--fuel == 0u) goto done;
        b0 = (v0 | fuel) != 0u;
    }
    u1 ^= (unsigned)(signed char)(u2 & 0x80000000u);
    a0[(0u * (unsigned)d0) & 3u] = -((m0 | (0x7fffffffu & (unsigned)w0)) * ((unsigned)(w0 >> 29) - (unsigned)c0));
    switch ((unsigned)((unsigned)w0 < 0xc93f1e27u) & 7u) {
        q0 = &garr[(3u ^ (unsigned)((unsigned)s1 == (unsigned)((short)fuel > (signed char)(unsigned)(i1 || 0x10000u)))) & 7u];
        case 5u: ;
        { unsigned t4; double z4; if ((~(unsigned)((short)garr[u2 & 7u] > (signed char)i2)) & 1u) { t4 = (unsigned)(((unsigned)d0 & (unsigned)c1) < (unsigned)w0); z4 = (double)((((unsigned)((int)(unsigned)s1 >= (int)*mp) / (m0 | 1u))) & 255u); } if ((~(unsigned)((short)garr[u2 & 7u] > (signed char)i2)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            switch ((unsigned)((int)i0 >= (int)a0[u1 & 3u]) & 7u) {
                c1 = (signed char)*q0;
                *mp = (unsigned)(fuel == ((unsigned)((short)0xffffffffu > (signed char)(unsigned)(w0 >> 29)) << (*mp & 31u)));
                while (i0++ < 5u && ((unsigned)(w0 >> 29) ? m0 : i0)) { if (--fuel == 0u) goto done;
                    u3 = u3 * 0x9e3779b1u + (0xffffffffu + ((unsigned)(short)(unsigned)(0x92cf5c82u || u2) ^ (unsigned)(w0 >> 29)));
                    u2 = u2 * 0x9e3779b1u + (unsigned)!(unsigned)((unsigned)(signed char)(0xdf6f7844u % (0u | 1u)) == (0x7fffffffu | 0xc7896613u));
                    l0 = (long)((unsigned long)l0 + (0x447c0dcbu ? (unsigned)h1 : 0x62b5b748u));
                }
                if (a0[u1 & 3u]) {
                    case 1u: ;
                    goto L3;
                    goto L1;
                    g1 += (0x4676e7f1u ^ (unsigned)((int)0x2dd124c6u >= (int)(unsigned)(signed char)(unsigned)(1u || 1u)));
                } else {
                    w0 = w0 * 6364136223846793005ull + (unsigned)((short)(u2 ^ 0x8f57643du) > (signed char)i1);
                    g0 = (((unsigned)((short)1u > (signed char)g1) | garr[u2 & 7u]) + (unsigned)x0);
                }
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)u2 < (int)(unsigned)(0x10000u < (unsigned)s0));
            }
            if ((u1 & 0x7c4528c2u)) break;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)(unsigned)((short)6u > (signed char)(unsigned)c0) >= (int)(unsigned)x0), (unsigned)(r0.x || u3), p1); }
        }
    }
    if (a0[u1 & 3u]) {
        goto L0;
        u2 = u2 * 0x9e3779b1u + ((unsigned)(u1 == p0) - (unsigned)(u0 || 0x80000000u));
        i0 = 0x80000000u & 15u;
        u3 = u3 * 0x9e3779b1u + (unsigned)((int)fuel < (int)0xeaa8fde9u);
        if ((unsigned)(unsigned char)(unsigned)((unsigned)(0xa3d9cb4fu && (unsigned)c0) && p1)) goto L4;
    } else {
        if ((unsigned)e0) goto L2;
        *q0 += (unsigned)(0x75aa15cau == g0);
        if (u3) goto L2;
    }
    w0 = w0 * 6364136223846793005ull + (5u ^ ((unsigned)h0 & r0.y));
    do { if (--fuel == 0u) goto done;
        u0 += 1u;
        if (6u) {
            switch ((unsigned)s1 & 7u) {
                *mp = ((fuel - 3u) ^ 4u);
                w0 ^= (unsigned long long)0xffffffffu << ((unsigned)(signed char)((g0 % (garr[i1 & 7u] | 1u)) - ~(unsigned)((unsigned)x0 < 0x39bbc4a3u)) & 63u);
                if ((unsigned)x0) goto done;
                case 0u: ;
            }
            while ((unsigned)((int)u0 < (int)(unsigned)w0)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2(0xffffffffu, (unsigned)((int)(unsigned)e0 < (int)(unsigned)h0), 0x7fffffffu); }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)c0, (unsigned)((unsigned)((int)0x7fffffffu >= (int)garr[u2 & 7u]) == a0[u1 & 3u]), (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)f0)); }
                for (;;) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (i2 * 0xffffffffu));
                    garr[(unsigned)((int)v0 >= (int)u2) & 7u] = (unsigned)((int)(unsigned)((int)5u < (int)(unsigned)s0) >= (int)(unsigned)(signed char)(u2 % (0x8ba23e96u | 1u)));
                    { unsigned t5; double z5; if (((u3 * fuel)) & 1u) { t5 = (fuel * (unsigned)s1); z5 = (double)(((unsigned)f0) & 255u); } if (((u3 * fuel)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)x0 == (unsigned)f0), (unsigned)((int)p1 >= (int)0xc5d93688u), 0x842d3fc4u); }
                        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                            l0 = (long)((unsigned long)l0 + (0x6c8c6d2eu / ((0u >> ((unsigned)s1 & 31u)) | 1u)));
                            if ((unsigned)c0) break;
                            x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)s0 >= (int)(unsigned)d0);
                        }
                        if ((m0 | u2)) break;
                        if ((unsigned)(short)(unsigned)(garr[i1 & 7u] < 3u)) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)u1 > (signed char)(unsigned)b0), (8u + ((unsigned)h0 | i1)), 8u); }
                    }
                    break; (void)((unsigned)x0);
                }
            }
            if (5u) goto L2;
            u1 += (unsigned)((0x80000000u - 0xc907af4bu) == 9u);
            if ((unsigned)((0xffffffffu - (unsigned)s0) || i1)) break;
            if ((0x72439b8cu * (unsigned)x0)) break;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)-(unsigned)(i2 || fuel) < (int)6u), (unsigned)c1, ((unsigned)(unsigned char)(unsigned)(r0.x == u2) | *mp)); }
        if ((unsigned)(short)(unsigned)((unsigned)(0x80000000u == p0) || (unsigned)f0)) {
            if (fuel < 8u) return (((unsigned)c1 / (0x67c7d380u | 1u)) / ((unsigned)((int)0xffffffffu < (int)0x7d595eafu) | 1u));
            i0 = (unsigned)(((unsigned)(short)((unsigned)c0 % ((unsigned)w0 | 1u)) & (u3 / (a0[u1 & 3u] | 1u))) == v0) & 15u;
            if ((0x7fffffffu ^ (unsigned)((short)0x10000u > (signed char)a0[u1 & 3u]))) break;
            if (budget != 0u) { budget -= 1u; u2 = fn2((0x576589bfu % (((unsigned)w0 - (unsigned)l0) | 1u)), (unsigned)(unsigned char)(unsigned)(8u < 0x8b5400b2u), (unsigned)((short)(1u % ((unsigned)x0 | 1u)) > (signed char)p0)); }
        } else {
            c1 = (signed char)(unsigned)((int)(unsigned)c1 < (int)((2u - ((unsigned)h0 ^ u2)) - 0x66d2b3b9u));
            *q0 = (unsigned)x0;
            u1 = u1 * 0x9e3779b1u + (((unsigned)((int)(unsigned)x0 >= (int)(unsigned)(w0 >> 29)) << (0x6583a191u & 31u)) ? m0 : (unsigned)c1);
        }
        if ((u3 - *q0)) break;
    } while (i0++ < 6u && ((unsigned)e0 ^ (unsigned)c1));
    if (p2) {
        goto L3;
        w0 ^= (unsigned long long)(unsigned)h1 << ((((unsigned)b0 % ((unsigned)s0 | 1u)) % ((unsigned)w0 | 1u)) & 63u);
        if ((i1 / (0xffffffffu | 1u))) goto done;
    } else {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)((unsigned)((int)i1 < (int)(unsigned)x0) && u1) & 7u) {
                { unsigned t6; double z6; if (((unsigned)(u1 < 0x10000u)) & 1u) { t6 = (unsigned)b0; z6 = (double)(((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)b0)) & 255u); } if (((unsigned)(u1 < 0x10000u)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                    if (((unsigned)(fuel || i2) >> (a0[i0 & 3u] & 31u))) goto L4;
                    r0.x = 6u;
                    if ((unsigned)((4u ^ 4u) && i0)) continue;
                    case 0u: ;
                    for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((short)(unsigned)(0x80000000u < 0xffffffffu) > (signed char)(unsigned)(w0 >> 29))) break;
                        *q0 = (unsigned)((int)(unsigned)((int)p0 < (int)0xffffffffu) >= (int)(unsigned)((short)(unsigned)s1 > (signed char)r0.y));
                        default: ;
                        case 2u: ;
                        d0 = d0 * 0.5 + (double)(~(garr[u2 & 7u] / (garr[i1 & 7u] | 1u)) & 1023u);
                    }
                    if ((unsigned)h0) {
                        m0 ^= ~((unsigned)((int)a0[i0 & 3u] < (int)p0) - 0x86b4b72cu);
                        if (budget != 0u) { budget -= 1u; u0 = fn2((0x8c374339u * (a0[u1 & 3u] | 9u)), (unsigned)(((unsigned)c1 - (unsigned)(w0 >> 29)) && (unsigned)l0), 0x1cbc200eu); }
                        g1 += (*mp ? garr[u2 & 7u] : *mp);
                        case 6u: ;
                        m0 ^= (unsigned)((0x80000000u & (unsigned)d0) && 0xf33b8de2u);
                    }
                }
                a0[2u & 3u] = (g0 & (unsigned)((short)(0x4081fcf8u & 6u) > (signed char)(p2 - i1)));
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    u1 += (i0 | (r0.x / (0u | 1u)));
                }
                while (i1++ < 3u && ((unsigned)((int)(unsigned)c1 >= (int)a0[i0 & 3u]) << (u3 & 31u))) { if (--fuel == 0u) goto done;
                    g0 = -((9u + *mp) / (*q0 | 1u));
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)(((unsigned)(unsigned char)((unsigned)(2u == *mp) >> (3u & 31u)) >> ((0x10000u ^ 0x80000000u) & 31u)) & 255u);
                    }
                    break;
                    while ((unsigned)h0) { if (--fuel == 0u) goto done;
                        break;
                        u2 += (unsigned)((unsigned)(x0 >> 70) == (unsigned)((unsigned)((short)p2 > (signed char)(unsigned)s1) < (unsigned)(unsigned char)(unsigned)(8u < (unsigned)e0)));
                        break;
                        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)l0 % ((unsigned)l0 | 1u)), (unsigned)((int)0x7fffffffu >= (int)(unsigned)(x0 >> 70)), m0); }
                            b0 = (unsigned)(unsigned char)((unsigned)((int)r0.y < (int)0xa4236145u) & (unsigned)b0) != 0u;
                            case 7u: ;
                            if (0x4fce06au) break;
                            u0 ^= (unsigned)(garr[u2 & 7u] || 3u);
                            s0 = (int)(unsigned)((unsigned)l0 < (unsigned)x0);
                        }
                        continue; (void)((i2 % ((unsigned)(signed char)((unsigned)l0 << (r0.y & 31u)) | 1u)));
                    }
                }
            }
            { unsigned t7; double z7; if (((unsigned)((unsigned)(x0 >> 70) == (unsigned)(*mp == g0))) & 1u) { t7 = (unsigned)c0; z7 = (double)((((7u >> ((unsigned)s0 & 31u)) + 7u)) & 255u); } if (((unsigned)((unsigned)(x0 >> 70) == (unsigned)(*mp == g0))) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                *q0 = ((unsigned)x0 * ((unsigned)b0 + 0x936a34bdu));
                u2 = u2 * 0x9e3779b1u + (p0 | (unsigned)((int)r0.y < (int)(unsigned)(w0 >> 29)));
                while (i1++ < 4u && (unsigned)(short)((unsigned)c0 << (0x2773e5bfu & 31u))) { if (--fuel == 0u) goto done;
                    if (((unsigned)((int)8u < (int)0x2aa53443u) ^ 0x80000000u)) break;
                    s1 = (int)((unsigned)s1 + (unsigned)(g1 == 0xbcdc805bu));
                }
                do { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        g1 += u0;
                        i0 = ((unsigned)(i1 && 0x10000u) / ((0x80000000u - (unsigned)x0) | 1u)) & 15u;
                    }
                    if (0xffffffffu) break;
                } while (i1++ < 5u && (unsigned)((short)(*mp ^ i2) > (signed char)(unsigned)b0));
            }
        }
        if ((unsigned)((short)(unsigned)e0 > (signed char)a0[i0 & 3u])) goto L0;
    }
    goto L2;
    if ((*mp + ((unsigned)(w0 >> 29) * (unsigned)c1))) goto L0;
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)h0 < (int)r0.y), (a0[u1 & 3u] ? a0[u1 & 3u] : p2), (garr[i1 & 7u] % ((unsigned)((int)garr[i1 & 7u] < (int)0x2db5800eu) | 1u))); }
    if (0xf2e69844u) goto L4;
    if ((unsigned)((unsigned)(w0 >> 29) < r0.x)) goto L4;
    if (i0) goto L1;
    l0 = (long)((unsigned long)l0 + (6u % (0xd03576aau | 1u)));
    if (budget != 0u) { budget -= 1u; u3 = fn1((r0.y | (0xb6fb40adu + m0)), (unsigned)!(g1 ? (unsigned)b0 : (unsigned)s1), p2); }
    if ((unsigned)(p0 < (unsigned)((short)u1 > (signed char)*mp))) goto L4;
    goto L3;
    goto L3;
    { unsigned t8; double z8; if (((unsigned)f0) & 1u) { t8 = (((unsigned)d0 % (u0 | 1u)) - i0); z8 = (double)((((unsigned)d0 % ((unsigned)s0 | 1u))) & 255u); } if (((unsigned)f0) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
        if (budget != 0u) { budget -= 1u; u1 = fn2((0x94df00e0u / ((unsigned)s0 | 1u)), (unsigned)s0, (unsigned)f0); }
        do { if (--fuel == 0u) goto done;
            u1 = u1 * 0x9e3779b1u + (unsigned)w0;
            g0 = (u3 ^ 0x80000000u);
            if ((unsigned)((short)a0[u1 & 3u] > (signed char)(i2 - g1))) break;
            m0 ^= (unsigned)(a0[i0 & 3u] == (5u | 0x80000000u));
            c0 = (unsigned char)(unsigned)((unsigned)!(r0.y & 0xffffffffu) || i0);
            switch ((unsigned)d0 & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn0(garr[u2 & 7u], (fuel + 0x10000u), 3u); }
            }
        } while (i0++ < 5u && ((unsigned)(a0[u1 & 3u] < 0x7fffffffu) / ((unsigned)h0 | 1u)));
        r0.y ^= (v0 ? m0 : u2);
        do { if (--fuel == 0u) goto done;
            { unsigned t9; double z9; if (((p0 / (~(9u | p2) | 1u))) & 1u) { t9 = (p0 >> (a0[i0 & 3u] & 31u)); z9 = (double)(((unsigned)((*mp | a0[u1 & 3u]) && 0xd2ac76e9u)) & 255u); } if (((p0 / (~(9u | p2) | 1u))) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    i0 = (*q0 | *mp) & 15u;
                    break; (void)((unsigned)(w0 >> 29));
                    u1 = u1 * 0x9e3779b1u + ((p0 ? 0xa9b7afb9u : (unsigned)f0) * (6u * (unsigned)w0));
                    a0[i1 & 3u] = i2;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(unsigned)x0 > (signed char)(0x7b740b4eu - (unsigned)(x0 >> 70))), (unsigned)f0, 0x7d718701u); }
                    if ((unsigned)(short)(unsigned)(3u || garr[i1 & 7u])) break;
                }
                *q0 = ((1u ? 3u : (unsigned)((unsigned)x0 || 0x7fffffffu)) ^ u1);
                { unsigned t10; double z10; if (((unsigned)((int)*mp < (int)((unsigned)h0 & garr[u2 & 7u]))) & 1u) { t10 = p1; z10 = (double)(((u1 ? (unsigned)d0 : u0)) & 255u); } if (((unsigned)((int)*mp < (int)((unsigned)h0 & garr[u2 & 7u]))) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                    goto L0;
                    *mp = (unsigned)d0;
                }
                r0.y ^= (unsigned)((fuel / (0x507ed798u | 1u)) || ((unsigned)((int)garr[i1 & 7u] < (int)garr[u2 & 7u]) ^ 0xc8cfe7b8u));
                if ((unsigned)(((unsigned)(w0 >> 29) * a0[u1 & 3u]) && garr[i1 & 7u])) break;
            }
            if (((unsigned)c1 | i2)) {
                garr[0xcd1a9b8bu & 7u] = (unsigned)((p0 * 8u) == (unsigned)f0);
                if ((~((unsigned)s1 % (r0.y | 1u)) + (unsigned)x0)) goto L0;
                if ((0x7fffffffu + u1)) break;
                garr[(unsigned)f0 & 7u] = (unsigned)(((unsigned)c0 ^ a0[u1 & 3u]) && ((1u - 1u) / (0x5ac980c8u | 1u)));
                if (((6u >> (0x10000u & 31u)) >> (6u & 31u))) continue;
                u1 += (unsigned)((int)fuel < (int)a0[i0 & 3u]);
            } else {
                *q0 += (unsigned)(short)(unsigned)(0xffffffffu == (unsigned)(0x7fffffffu == u1));
                b0 = ((unsigned)!((r0.x + (unsigned)(w0 >> 29)) * 8u) & *q0) != 0u;
            }
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)((short)m0 > (signed char)(unsigned)f0));
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x10000u == (unsigned)!(unsigned)((short)(unsigned)s0 > (signed char)(unsigned)(x0 >> 70))), -(0xf09377dcu & (unsigned)(unsigned char)(unsigned)((short)(unsigned)h0 > (signed char)(unsigned)h1)), i2); }
                    a0[(unsigned)((short)(unsigned)c1 > (signed char)m0) & 3u] = (0x5d2e6946u * i2);
                    u3 += (((unsigned)h1 | g1) & (unsigned)((unsigned)((short)(unsigned)l0 > (signed char)u2) == (unsigned)w0));
                    switch ((unsigned)((unsigned)(signed char)(i2 | fuel) == 0xff2a825eu) & 7u) {
                        if (budget != 0u) { budget -= 1u; u3 = fn0(p2, ((unsigned)h0 >> ((unsigned)h0 & 31u)), 5u); }
                        l0 = (long)((unsigned long)l0 + r0.x);
                        break; (void)(1u);
                    }
                    if ((unsigned)!(g0 ? p1 : garr[u2 & 7u])) break;
                }
            }
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)h0 & 255u);
                if ((unsigned)((int)(0x80000000u % (0xffffffffu | 1u)) < (int)i2)) break;
                u1 ^= -(unsigned)((unsigned)h1 && (unsigned)((int)(unsigned)((int)v0 < (int)(unsigned)s0) >= (int)3u));
            }
        } while (i0++ < 5u && 0xf1a6a61u);
    }
    if (((unsigned)h1 ? p2 : 0x7fffffffu)) {
        switch (a0[u1 & 3u] & 7u) {
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)!(0xa11fa6f9u ? (unsigned)x0 : i0), (unsigned)(short)(a0[u1 & 3u] ^ *q0), -((unsigned)(x0 >> 70) & (garr[i1 & 7u] / ((unsigned)c0 | 1u)))); }
            if ((unsigned)((int)(unsigned)f0 < (int)*q0)) {
                u2 += ((unsigned)w0 ? (unsigned)c0 : r0.x);
            }
            h0 = (short)((g0 | fuel) >> (a0[i0 & 3u] & 31u));
            case 1u: ;
        }
        g1 += (unsigned)((unsigned)s1 == 0x123c0c42u);
        h0 = (short)(unsigned)(unsigned char)((unsigned)((unsigned)(i1 < (unsigned)c0) && (unsigned)((int)(unsigned)d0 < (int)(unsigned)f0)) + (unsigned)d0);
        goto done;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)(i2 % (a0[i0 & 3u] | 1u)) > (signed char)(unsigned)h1), i1, (unsigned)(0x7fffffffu && a0[i0 & 3u])); }
    f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)(1u < m0) & (unsigned)(x0 >> 70)) < (u1 / (0x7fffffffu | 1u))) & 255u);
    { unsigned t11; double z11; if (((unsigned)(*mp || (garr[i1 & 7u] >> ((unsigned)e0 & 31u)))) & 1u) { t11 = -(unsigned)((short)a0[i0 & 3u] > (signed char)3u); z11 = (double)((((0x80000000u << (0x7fffffffu & 31u)) * p0)) & 255u); } if (((unsigned)(*mp || (garr[i1 & 7u] >> ((unsigned)e0 & 31u)))) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
        u0 += (unsigned)(w0 >> 29);
        if (((unsigned)x0 | g1)) goto done;
        r0.y ^= ((unsigned)x0 ^ 0xffffffffu);
        e0 = e0 * 0.5L + (long double)(((r0.y ^ m0) ^ ((unsigned)s1 | (a0[u1 & 3u] & (unsigned)f0))) & 1023u);
        u1 += ~(unsigned)(0x266755c1u || (((unsigned)l0 >> (m0 & 31u)) | *mp));
    }
    goto L0;
    while (i0++ < 3u && (unsigned)(signed char)(unsigned)(0xbc7c1126u == (unsigned)w0)) { if (--fuel == 0u) goto done;
        *mp = v0;
        { unsigned t12; double z12; if ((9u) & 1u) { t12 = (1u ^ 0xffffffffu); z12 = (double)(((unsigned)b0) & 255u); } if ((9u) & 1u) { u3 += t12; d0 = d0 * 0.5 + z12; }
            if ((unsigned)((short)4u > (signed char)(unsigned)f0)) break;
            if ((unsigned)(short)(unsigned)(6u == (garr[u2 & 7u] % (*mp | 1u)))) break;
            if (fuel < 8u) return 0xc4d337e2u;
            l0 = (long)((unsigned long)l0 + (unsigned)(0x725f0e80u < (unsigned)(w0 >> 29)));
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)(unsigned)h0 < (int)(6u ^ 0x10000u)), (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)(garr[u2 & 7u] && i2)), (unsigned)((*q0 << ((unsigned)b0 & 31u)) && 0xffffffffu)); }
            v0 = ((unsigned)((int)u1 >= (int)p1) / ((p2 >> (0x10000u & 31u)) | 1u));
        }
        if ((garr[i1 & 7u] ^ (unsigned)x0)) break;
        *mp = 0x10000u;
        if (budget != 0u) { budget -= 1u; u3 = fn1((0x10000u * (unsigned)f0), ((unsigned)((int)0x10000u >= (int)u1) + (unsigned)f0), (unsigned)((short)(unsigned)b0 > (signed char)0xc91cdd31u)); }
    }
    if (p2) {
        g0 = (unsigned)(((unsigned)w0 % (0x80000000u | 1u)) == u2);
        switch (0x10000u & 7u) {
            case 3u: ;
            { unsigned t13; double z13; if (((0xbcd821e8u / ((u2 * 8u) | 1u))) & 1u) { t13 = 0x7fffffffu; z13 = (double)(((unsigned)((0x20c3b021u + 7u) < u2)) & 255u); } if (((0xbcd821e8u / ((u2 * 8u) | 1u))) & 1u) { u3 += t13; d0 = d0 * 0.5 + z13; }
                f0 = f0 * 0.5f + (float)((unsigned)((int)~(unsigned)((int)(unsigned)c1 < (int)((unsigned)d0 >> ((unsigned)x0 & 31u))) >= (int)(unsigned)(unsigned char)(u0 >> (garr[u2 & 7u] & 31u))) & 255u);
            }
            *mp = i0;
            { unsigned t14; double z14; if (((((unsigned)c1 >> ((unsigned)w0 & 31u)) >> ((unsigned)x0 & 31u))) & 1u) { t14 = (unsigned)((p2 | i1) == garr[i1 & 7u]); z14 = (double)((0xc40513d4u) & 255u); } if (((((unsigned)c1 >> ((unsigned)w0 & 31u)) >> ((unsigned)x0 & 31u))) & 1u) { u1 += t14; d0 = d0 * 0.5 + z14; }
                break; (void)((u3 % ((*q0 | *q0) | 1u)));
            }
            do { if (--fuel == 0u) goto done;
                g0 = (unsigned)s0;
                h1 = (unsigned short)(h1 + 0u);
                if (budget != 0u) { budget -= 1u; u0 = fn0(g1, (unsigned)b0, 0u); }
                f0 = f0 * 0.5f + (float)(((unsigned)f0 ^ (unsigned)s1) & 255u);
                switch (*mp & 7u) {
                    c0 = (unsigned char)((u3 >> (garr[i1 & 7u] & 31u)) | g0);
                }
            } while (i0++ < 6u && ((unsigned)(r0.x < fuel) & 0xffffffffu));
        }
        if ((0u % ((unsigned)(4u || 0x8767c13cu) | 1u))) goto L3;
        *q0 = (unsigned)((int)(g1 * 6u) >= (int)garr[i1 & 7u]);
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t15; double z15; if (((((unsigned)h0 | garr[i1 & 7u]) >> (*q0 & 31u))) & 1u) { t15 = (((unsigned)s0 - p2) / (u3 | 1u)); z15 = (double)(((0xffffffffu & (unsigned)((unsigned)b0 || u3))) & 255u); } if (((((unsigned)h0 | garr[i1 & 7u]) >> (*q0 & 31u))) & 1u) { u2 += t15; d0 = d0 * 0.5 + z15; }
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(0xffffffffu, i2, (unsigned)b0); }
                q0 = &garr[((unsigned)(unsigned char)(p1 | (unsigned)f0) ^ (p1 - (unsigned)((int)(unsigned)h1 < (int)i0))) & 7u];
                if ((*mp | (*q0 % (garr[u2 & 7u] | 1u)))) goto L0;
            }
            while (i1++ < 6u && (unsigned)((int)(unsigned)s0 >= (int)r0.x)) { if (--fuel == 0u) goto done;
                if (((unsigned)((short)i1 > (signed char)(unsigned)h1) ^ 8u)) {
                    switch ((unsigned)(unsigned char)((unsigned)(a0[i0 & 3u] < i1) / (3u | 1u)) & 7u) {
                        if ((unsigned)(w0 >> 29)) goto L1;
                    }
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        m0 ^= (unsigned)((0x36202eefu - fuel) < 4u);
                    }
                    v0 = ((unsigned)s1 << (0x80000000u & 31u));
                    for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((8u >> ((unsigned)e0 & 31u))) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(a0[i0 & 3u], *q0, i1); }
                        break; (void)(~(unsigned)((int)garr[i1 & 7u] < (int)(unsigned)(u1 == u0)));
                        { unsigned t16; double z16; if (((0x10000u % ((garr[u2 & 7u] >> ((unsigned)s1 & 31u)) | 1u))) & 1u) { t16 = ((unsigned)(0x7fffffffu == g1) % (p2 | 1u)); z16 = (double)((r0.y) & 255u); } if (((0x10000u % ((garr[u2 & 7u] >> ((unsigned)s1 & 31u)) | 1u))) & 1u) { u1 += t16; d0 = d0 * 0.5 + z16; }
                            s1 = (int)((unsigned)s1 + (unsigned)((short)(v0 << ((unsigned)(unsigned char)(0x6d8fd480u ^ 0x6a4a8dc2u) & 31u)) > (signed char)(unsigned)s1));
                            u2 ^= (unsigned)(short)(unsigned)(1u < (unsigned)!((unsigned)s0 * (unsigned)((unsigned)l0 && 0u)));
                        }
                    }
                    x0 = x0 * 0x100000001b3ull + ((unsigned)h0 + r0.y);
                }
                l0 = (long)((unsigned long)l0 + (p0 + (unsigned)b0));
                l0 = (long)((unsigned long)l0 + (0xffffffffu | (unsigned)(signed char)(unsigned)(0x6d67be51u < *mp)));
                v0 = (unsigned)(unsigned char)((unsigned)((unsigned)c1 || ~(p1 ^ i2)) ? 0x5fcb5979u : a0[u1 & 3u]);
                break; (void)((garr[i1 & 7u] << (u1 & 31u)));
                break; (void)(4u);
            }
        }
        if ((u3 ? i1 : (unsigned)c1)) {
            while (p1) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)((i0 / (a0[i0 & 3u] | 1u)) || (unsigned)h1));
                *q0 = 0xeae3c86au;
                u0 = u0 * 0x9e3779b1u + (fuel / (v0 | 1u));
                e0 = e0 * 0.5L + (long double)(-(unsigned)(~(unsigned)(g1 && (unsigned)l0) || (unsigned)((unsigned)l0 < g1)) & 1023u);
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((i0 | 0x960403e1u), 0x10000u, (unsigned)((unsigned)h0 < 0x80000000u)); }
            if (~((unsigned)s0 - (unsigned)(w0 >> 29))) break;
            break; (void)(((unsigned)w0 - *q0));
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)d0 & p2), p2, (0x7fffffffu % ((unsigned)(a0[i0 & 3u] && u0) | 1u))); }
        } else {
            if ((unsigned)c1) break;
        }
        goto L0;
        { unsigned t17; double z17; if ((((unsigned)w0 << (((unsigned)c1 - 0x67b599cu) & 31u))) & 1u) { t17 = (unsigned)((0xe32d8cbbu ^ (unsigned)l0) < (unsigned)c1); z17 = (double)(((unsigned)((int)0x80000000u >= (int)0x3a97753bu)) & 255u); } if ((((unsigned)w0 << (((unsigned)c1 - 0x67b599cu) & 31u))) & 1u) { u0 += t17; d0 = d0 * 0.5 + z17; }
            u2 += u3;
            g0 = (unsigned)(i2 < 0xfc94fa5fu);
            x0 = x0 * 0x100000001b3ull + 0xc65e500cu;
            if ((unsigned)((m0 & (unsigned)b0) == (unsigned)d0)) {
                *q0 += (unsigned)((0x9d373027u >> (m0 & 31u)) < (a0[i0 & 3u] + (unsigned)f0));
                if ((u2 + a0[u1 & 3u])) break;
            }
        }
    }
    while (i0++ < 4u && (0x80000000u ^ garr[u2 & 7u])) { if (--fuel == 0u) goto done;
        if (0xffffffffu) break;
        s0 = (int)0x7fffffffu;
        while ((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
            c1 = (signed char)((unsigned)s0 ? 8u : r0.y);
            { unsigned t18; double z18; if (((p1 / (u1 | 1u))) & 1u) { t18 = 7u; z18 = (double)((((unsigned)s0 << ((unsigned)c1 & 31u))) & 255u); } if (((p1 / (u1 | 1u))) & 1u) { u3 += t18; d0 = d0 * 0.5 + z18; }
                continue; (void)((unsigned)!(u2 >> (((unsigned)l0 - (unsigned)e0) & 31u)));
                break; (void)(0x7fffffffu);
                if (budget != 0u) { budget -= 1u; u0 = fn2(a0[i0 & 3u], (unsigned)(v0 < 0x16981fc6u), ~(unsigned)((int)((unsigned)l0 % ((unsigned)e0 | 1u)) < (int)0xffffffffu)); }
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s1 ? fuel : r0.x), (unsigned)((unsigned)(w0 >> 29) || (*mp >> (9u & 31u))), 0x7fffffffu); }
            }
            break; (void)((unsigned)(signed char)(unsigned)((int)(unsigned)s1 < (int)fuel));
            g1 += (0x3d0031ceu - 1u);
        }
        if (fuel < 8u) return (unsigned)h0;
        if (budget != 0u) { budget -= 1u; u0 = fn2(0x80000000u, (0x10000u & ((unsigned)f0 >> (r0.y & 31u))), ((unsigned)(w0 >> 29) * i0)); }
        if (fuel < 8u) return (unsigned)((short)(unsigned)c1 > (signed char)(unsigned)((int)0x80000000u < (int)(0x10000u * ~(unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)d0))));
    }
    if ((unsigned)(unsigned char)((unsigned)((int)0x80000000u < (int)g0) + p1)) goto L0;
    goto L1;
    if (garr[i1 & 7u]) {
        goto L4;
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                u0 = (unsigned)((short)(0xd0522f0bu ^ r0.y) > (signed char)m0);
                if ((unsigned)((int)(unsigned)(6u == u0) >= (int)(unsigned)x0)) continue;
                { unsigned t19; double z19; if (((unsigned)(signed char)(garr[u2 & 7u] << ((unsigned)(g1 && *q0) & 31u))) & 1u) { t19 = i0; z19 = (double)((p1) & 255u); } if (((unsigned)(signed char)(garr[u2 & 7u] << ((unsigned)(g1 && *q0) & 31u))) & 1u) { u2 += t19; d0 = d0 * 0.5 + z19; }
                    switch ((unsigned)(short)((a0[i0 & 3u] + 0x15bed6e9u) + i0) & 7u) {
                        f0 = f0 * 0.5f + (float)(((i0 % (i1 | 1u)) / (0x80000000u | 1u)) & 255u);
                        case 3u: ;
                    }
                    l0 = (long)((unsigned long)l0 + (fuel * (unsigned)f0));
                    v0 = ~(unsigned)(0x1e3074a7u && (unsigned)(0x80000000u || g1));
                }
                if ((unsigned)(signed char)(unsigned)(0x6c7025f4u == (g1 ^ (unsigned)c0))) goto L4;
                { unsigned t20; double z20; if ((0x80000000u) & 1u) { t20 = ((unsigned)b0 << (0x7fffffffu & 31u)); z20 = (double)((u2) & 255u); } if ((0x80000000u) & 1u) { u1 += t20; d0 = d0 * 0.5 + z20; }
                    u1 += ((unsigned)!(unsigned)((int)u3 < (int)p0) | p2);
                    w0 ^= (unsigned long long)(unsigned)h1 << ((0x2b48cc2cu & (unsigned)f0) & 63u);
                    if (m0) {
                        f0 = f0 * 0.5f + (float)((u2 * garr[u2 & 7u]) & 255u);
                        if (0x17d82fcdu) continue;
                        s1 = (int)((unsigned)s1 + (unsigned)s1);
                        garr[(7u - (unsigned)x0) & 7u] = (u1 / ((unsigned)e0 | 1u));
                        g0 = ((unsigned)((*q0 / (0x10000u | 1u)) == 5u) / ((i1 & (unsigned)f0) | 1u));
                    }
                    break; (void)((unsigned)(0xffffffffu || (unsigned)f0));
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)b0 == (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)c1)), (g0 ? a0[u1 & 3u] : 0x2aa722d2u), (unsigned)((unsigned)(w0 >> 29) < p2)); }
                }
                r0.x = v0;
            }
            q0 = &garr[((0xffffffffu % ((unsigned)((m0 | (unsigned)l0) == garr[u2 & 7u]) | 1u)) & (unsigned)d0) & 7u];
            if (budget != 0u) { budget -= 1u; u1 = fn1((0x10000u << (g1 & 31u)), (m0 % (*mp | 1u)), (unsigned)(0x10000u || 0xf38984b1u)); }
            if ((unsigned)((int)(unsigned)f0 >= (int)r0.y)) break;
            h1 = (unsigned short)(h1 + p1);
            if (((r0.y - 0x80000000u) + i0)) break;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn1(0x7fffffffu, ((unsigned)h1 ? 0xffffffffu : (unsigned)s0), garr[u2 & 7u]); }
        if ((unsigned)!((unsigned)s0 << ((unsigned)(r0.x && 9u) & 31u))) goto L0;
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(signed char)((0x80000000u << (0xc4f57a38u & 31u)) << (u0 & 31u)));
        g1 += (unsigned)(unsigned char)(unsigned)((int)8u < (int)u2);
        *q0 += ((unsigned)(signed char)(unsigned)((g1 % ((unsigned)(*mp || *mp) | 1u)) < i1) >> ((unsigned)s1 & 31u));
    }
    if ((u1 & ((unsigned)h1 * 0x84a2deb2u))) goto L2;
    if ((p2 / ((unsigned)x0 | 1u))) goto L2;
    r0.y ^= (unsigned)((short)garr[u2 & 7u] > (signed char)4u);
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)(0x7fffffffu && (0xd09a27b4u | 0x80000000u)) & 7u) {
            r0.y ^= (unsigned)((unsigned)(w0 >> 29) || r0.x);
            r0.y ^= (unsigned)((int)(unsigned)((int)u0 < (int)(unsigned)((int)(unsigned)d0 < (int)*mp)) < (int)(unsigned)((short)garr[u2 & 7u] > (signed char)r0.y));
            if (fuel < 8u) return (unsigned)((unsigned)(r0.x || (unsigned)(u1 == (unsigned)b0)) < ((unsigned)(x0 >> 70) ^ (unsigned)s1));
            { unsigned t21; double z21; if ((((unsigned)h0 ^ ((unsigned)l0 << ((unsigned)w0 & 31u)))) & 1u) { t21 = (unsigned)h0; z21 = (double)(((garr[u2 & 7u] >> (g0 & 31u))) & 255u); } if ((((unsigned)h0 ^ ((unsigned)l0 << ((unsigned)w0 & 31u)))) & 1u) { u1 += t21; d0 = d0 * 0.5 + z21; }
                if ((a0[u1 & 3u] << (0xe2aeae6du & 31u))) continue;
            }
            h0 = (short)i2;
        }
        if ((((unsigned)f0 / (m0 | 1u)) | 0xe0b465f5u)) {
            m0 ^= (u0 * u1);
            if ((unsigned)(*mp < (unsigned)((int)*mp < (int)(unsigned)s1))) goto L2;
            f0 = f0 * 0.5f + (float)((unsigned)((u2 ? (i0 * *mp) : (unsigned)s1) && (unsigned)s1) & 255u);
            continue; (void)((unsigned)s0);
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    garr[a0[i0 & 3u] & 7u] = ((i1 & (0xf17b65c0u | u0)) - ((unsigned)w0 - (unsigned)h1));
    d0 = d0 * 0.5 + (double)(0u & 1023u);
    if (budget != 0u) { budget -= 1u; u0 = fn3(((unsigned)(r0.y == (unsigned)x0) | r0.y), (fuel % (0x366bdfd2u | 1u)), 0x299c079bu); }
    goto L3;
    r0.x = (unsigned)((int)((unsigned)s0 - 9u) >= (int)(0xffffffffu - 0xf2342752u));
    if ((unsigned)(g1 == 0xffffffffu)) goto L1;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (p2) goto done;
        if (((0x9349d65fu << ((unsigned)s1 & 31u)) & p0)) {
            L0: if (--fuel == 0u) goto done;
            if (g0) break;
            L1: if (--fuel == 0u) goto done;
        }
        if (u3) break;
        h0 = (short)((unsigned)((int)(unsigned)h1 < (int)9u) | (unsigned)((unsigned)b0 && (unsigned)w0));
        break; (void)((unsigned)w0);
    }
    u2 = (((unsigned)f0 & 3u) | (unsigned)w0);
    v0 = ((unsigned)h0 % (g0 | 1u));
    if ((unsigned)s1) goto L1;
    if ((i1 & (r0.x * (unsigned)e0))) {
        if ((unsigned)((short)v0 > (signed char)(unsigned)d0)) {
            h1 = (unsigned short)(h1 + (unsigned)((int)r0.x >= (int)(unsigned)((unsigned)e0 || (v0 ? 0xa073b014u : 0xffffffffu))));
            if (((unsigned)f0 % ((0xffffffffu + 0x8a551757u) | 1u))) goto L3;
        } else {
            *q0 = (((unsigned)(0x75721976u < garr[i1 & 7u]) - (unsigned)(unsigned char)(unsigned)((int)(unsigned)h0 >= (int)1u)) * (unsigned)h0);
            u0 = (i2 % ((0x5398a0d3u % (0u | 1u)) | 1u));
        }
        if ((u0 / ((u3 >> (u0 & 31u)) | 1u))) goto L2;
        goto L4;
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((short)1u > (signed char)0xdcd8ac31u)) break;
        l0 = (long)((unsigned long)l0 + -(unsigned)((unsigned)c1 < 0x698110fu));
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(u1 || p0), ((unsigned)c0 - a0[u1 & 3u]), (unsigned)(unsigned char)(r0.y ^ m0)); }
    } while (i0++ < 4u && garr[i1 & 7u]);
    goto L0;
    switch (p2 & 7u) {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((0x27fa8a70u % (a0[u1 & 3u] | 1u)) & 1023u);
            case 7u: ;
        }
        { unsigned t0; double z0; if ((m0) & 1u) { t0 = (unsigned)e0; z0 = (double)((6u) & 255u); } if ((m0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            if (budget != 0u) { budget -= 1u; u0 = fn2((((unsigned)h1 ^ 0x3ae707a0u) << (i2 & 31u)), (unsigned)((unsigned)c0 == u2), v0); }
            if ((2u - m0)) break;
            garr[(unsigned)l0 & 7u] = (1u / (7u | 1u));
            w0 ^= (unsigned long long)(0xffffffffu ^ i1) << ((unsigned)(signed char)(u0 << (((unsigned)f0 ^ 5u) & 31u)) & 63u);
            { unsigned t1; double z1; if (((unsigned)(m0 || p1)) & 1u) { t1 = ((unsigned)h0 & 0xf0bed860u); z1 = (double)(((unsigned)((short)p1 > (signed char)0x10000u)) & 255u); } if (((unsigned)(m0 || p1)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                switch (0xd5a98d6u & 7u) {
                    a0[(unsigned)(short)(0x29b40759u >> ((unsigned)c1 & 31u)) & 3u] = u1;
                }
                case 3u: ;
            }
        }
        v0 = (unsigned)(signed char)(unsigned)((int)((unsigned)(2u || i2) << (r0.y & 31u)) >= (int)7u);
        do { if (--fuel == 0u) goto done;
            h0 = (short)(((unsigned)((short)((unsigned)e0 << (m0 & 31u)) > (signed char)0x80000000u) << ((unsigned)c0 & 31u)) >> (0xffffffffu & 31u));
            L2: if (--fuel == 0u) goto done;
            a0[p2 & 3u] = (unsigned)(0x80000000u || (6u + (unsigned)f0));
        } while (i0++ < 4u && 0x968aea6bu);
        if (((unsigned)c1 / (r0.x | 1u))) {
            u2 = ~(p1 >> ((0x80000000u ? p0 : m0) & 31u));
            e0 = e0 * 0.5L + (long double)((unsigned)s0 & 1023u);
            case 0u: ;
            L3: if (--fuel == 0u) goto done;
            if (-((unsigned)f0 >> ((unsigned)x0 & 31u))) goto L4;
            r0.x = ((unsigned)(w0 >> 29) * ((unsigned)((int)*mp >= (int)r0.y) ^ (unsigned)s0));
        }
    }
    L4: if (--fuel == 0u) goto done;
    b0 = (unsigned)(*q0 == ((unsigned)((int)p1 >= (int)(unsigned)f0) & (unsigned)b0)) != 0u;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(signed char)(unsigned)((i0 ^ m0) || (unsigned)c1)) break;
        if (budget != 0u) { budget -= 1u; u1 = fn3(((unsigned)l0 ? r0.y : r0.x), 2u, ((unsigned)e0 ^ (unsigned)f0)); }
        do { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + 0x11e799c8u);
            if (((a0[u1 & 3u] ^ 0u) << (garr[i1 & 7u] & 31u))) break;
            break; (void)((unsigned)(signed char)(((unsigned)b0 << ((unsigned)l0 & 31u)) & g0));
        } while (i1++ < 6u && ((*q0 + u3) << (*q0 & 31u)));
        if (budget != 0u) { budget -= 1u; u2 = fn1(((0x10000u - (unsigned)h0) << (i2 & 31u)), (unsigned)(i0 < 0xbf025794u), (unsigned)((int)((unsigned)c0 ^ 1u) < (int)u2)); }
        switch ((unsigned)((short)(unsigned)c1 > (signed char)0u) & 7u) {
            if ((unsigned)(0xfed3132du < (unsigned)(x0 >> 70))) break;
            if (budget != 0u) { budget -= 1u; u3 = fn1(~(((unsigned)s1 - (unsigned)x0) * (unsigned)s1), (unsigned)!(p1 ^ *q0), (unsigned)((int)4u >= (int)(unsigned)(signed char)(unsigned)((int)(unsigned)e0 >= (int)p1))); }
            h1 = (unsigned short)(h1 + (*mp >> ((unsigned)((short)(unsigned)(unsigned char)(u2 / (m0 | 1u)) > (signed char)(v0 & 7u)) & 31u)));
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(x0 >> 70) | (u0 & 2u)), (unsigned)(x0 >> 70), (unsigned)s0); }
        }
        continue; (void)(((unsigned)((unsigned)w0 < fuel) ^ (unsigned)s0));
    }
    if ((unsigned)((int)0x5fb295e2u >= (int)((unsigned)(w0 >> 29) << (0x5ed110eeu & 31u)))) goto L3;
    switch ((unsigned)((u1 << (fuel & 31u)) == (unsigned)l0) & 7u) {
        g0 = (i1 + ((unsigned)d0 | r0.y));
    }
    while (i0++ < 4u && (unsigned)!(unsigned)(((unsigned)s0 | (unsigned)s0) || 0xabd5d939u)) { if (--fuel == 0u) goto done;
        goto L2;
    }
    goto L3;
    switch ((((unsigned)d0 & u0) & 0xffffffffu) & 7u) {
        if (-(unsigned)((unsigned)(short)(*q0 >> (0x80000000u & 31u)) == (unsigned)c1)) {
            g1 += (unsigned)(signed char)(-(0u - (unsigned)((unsigned)b0 || a0[u1 & 3u])) | (unsigned)(x0 >> 70));
            x0 = x0 * 0x100000001b3ull + ((unsigned)((int)0xffffffffu >= (int)9u) & u3);
            *q0 += (((g1 | r0.y) - r0.x) << (-(g1 & 0x7fffffffu) & 31u));
            case 0u: ;
        }
        if (0x80000000u) break;
        if ((p1 - 0x5a3e3afu)) goto done;
        garr[(unsigned)(0x81846f21u < a0[u1 & 3u]) & 7u] = ((u0 ? 0x4ad2d70bu : (unsigned)(w0 >> 29)) ? 0x80000000u : u3);
    }
    m0 ^= ((unsigned)f0 & (0xffffffffu ? g0 : (unsigned)(0x10000u < 0xafc623d7u)));
    s0 = (int)(u0 << (i0 & 31u));
    if ((unsigned)((int)(unsigned)(g1 && 7u) < (int)(unsigned)s1)) goto L3;
    switch ((unsigned)e0 & 7u) {
        if ((unsigned)((unsigned)h1 && (unsigned)(r0.x == g0))) goto L4;
        c0 = (unsigned char)(unsigned)(unsigned char)(unsigned)((short)r0.y > (signed char)(unsigned)(unsigned char)((unsigned)l0 - (i1 * p1)));
        for (;;) { if (--fuel == 0u) goto done;
            case 6u: ;
            s0 = (int)((unsigned)b0 | a0[i0 & 3u]);
        }
    }
    switch ((g1 % (((unsigned)h1 & i1) | 1u)) & 7u) {
        *mp = ((unsigned)s0 ? g1 : (unsigned)f0);
        garr[((unsigned)(w0 >> 29) >> (0x635ca665u & 31u)) & 7u] = (unsigned)(9u && (i2 % ((unsigned)s0 | 1u)));
        x0 = x0 * 0x100000001b3ull + ((*q0 - 0xe578c05bu) * i1);
        if (0xdb42a87fu) {
            q0 = &garr[(3u & p0) & 7u];
            case 5u: ;
            x0 = x0 * 0x100000001b3ull + 6u;
            if ((unsigned)(0u || (unsigned)((short)0x167265bbu > (signed char)6u))) {
                if ((p0 % (1u | 1u))) {
                    case 4u: ;
                    for (;;) { if (--fuel == 0u) goto done;
                        u1 += 0xffffffffu;
                        if (budget != 0u) { budget -= 1u; u0 = fn1((0x613c7e1u % (i0 | 1u)), r0.x, ((8u << (u1 & 31u)) & g1)); }
                        if ((unsigned)(w0 >> 29)) break;
                        if ((9u | (unsigned)c0)) break;
                        if (v0) continue;
                        case 0u: ;
                    }
                    q0 = &garr[(unsigned)(a0[u1 & 3u] == v0) & 7u];
                }
                default: ;
                if (budget != 0u) { budget -= 1u; u0 = fn0(r0.y, (a0[i0 & 3u] % ((unsigned)c0 | 1u)), ((r0.x / (g1 | 1u)) >> (0xffffffffu & 31u))); }
            }
        } else {
            s0 = (int)((unsigned)(x0 >> 70) ^ 0u);
            if ((*mp | (unsigned)l0)) goto L2;
            goto L2;
            break;
        }
        case 1u: ;
        case 7u: ;
    }
    if ((unsigned)b0) {
        f0 = f0 * 0.5f + (float)((((garr[i1 & 7u] % ((unsigned)f0 | 1u)) & (unsigned)s0) << (0xd3bfad82u & 31u)) & 255u);
        *q0 = (unsigned)(((unsigned)s0 | 6u) == u1);
        while ((unsigned)(0xffffffffu && 0xffffffffu)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)0xffffffffu > (signed char)0xffffffffu), ((unsigned)b0 / (2u | 1u)), (unsigned)((int)*q0 < (int)(unsigned)l0)); }
            do { if (--fuel == 0u) goto done;
                *q0 = (-(r0.x % (((unsigned)c0 >> ((unsigned)w0 & 31u)) | 1u)) & (unsigned)w0);
                u0 = u0 * 0x9e3779b1u + ((unsigned)(signed char)((unsigned)h1 << (a0[u1 & 3u] & 31u)) * (unsigned)c0);
                r0.y ^= (1u + g1);
            } while (i1++ < 2u && ((unsigned)h1 ^ p1));
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch ((i0 * *q0) & 7u) {
                    if ((unsigned)((short)(unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)b0) > (signed char)garr[i1 & 7u])) break;
                    c0 = (unsigned char)(unsigned)d0;
                    if ((-(unsigned)((short)0x7fffffffu > (signed char)0x184c5b7cu) << (g0 & 31u))) continue;
                }
                if (0x8fc57025u) goto L3;
            }
            *mp = p0;
            { unsigned t2; double z2; if ((~(unsigned)((u0 | (unsigned)l0) == (unsigned)s1)) & 1u) { t2 = (r0.y << ((5u / (0x7fffffffu | 1u)) & 31u)); z2 = (double)((((m0 ^ u2) - r0.x)) & 255u); } if ((~(unsigned)((u0 | (unsigned)l0) == (unsigned)s1)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(short)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0xc7100374u), ((unsigned)d0 + (unsigned)((int)u0 >= (int)*mp)), (unsigned)((int)r0.y >= (int)0x7fffffffu)); }
                while (i1++ < 6u && (unsigned)((unsigned)(w0 >> 29) && 0xd0c59c3du)) { if (--fuel == 0u) goto done;
                    g0 = (unsigned)(0xffffffffu == (unsigned)l0);
                }
                if ((unsigned)(*q0 == (p2 % ((unsigned)x0 | 1u)))) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(unsigned)((int)0xbbcfd008u >= (int)(unsigned)((int)(unsigned)b0 >= (int)*mp)), u1, garr[i1 & 7u]); }
            }
        }
        s1 = (int)((unsigned)s1 + (r0.x - (unsigned)(unsigned char)(p1 % ((unsigned)(a0[i0 & 3u] == v0) | 1u))));
        do { if (--fuel == 0u) goto done;
            while (i1++ < 3u && (unsigned)((int)p1 >= (int)p0)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn3(garr[u2 & 7u], (unsigned)((unsigned)d0 || fuel), *mp); }
            }
            switch ((unsigned)((unsigned)l0 || 9u) & 7u) {
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)s1 - (unsigned)x0)) break;
                    continue; (void)(8u);
                }
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)0x702b2ceeu > (signed char)(unsigned)((short)0x8cd0ecb5u > (signed char)i2)), (p1 ^ 0x4b276124u), (unsigned)((1u % (0x2609bfb4u | 1u)) < 9u)); }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)u3 < (int)m0), (unsigned)(0x1dc56377u || (unsigned)((short)*mp > (signed char)0x315e7474u)), u2); }
            }
            if ((unsigned)(0xffffffffu < 0xe79d36a2u)) break;
            while ((r0.y << ((unsigned)s1 & 31u))) { if (--fuel == 0u) goto done;
                g1 += u1;
                if (garr[i1 & 7u]) break;
                if ((unsigned)((int)0xca37e28cu < (int)(0x93c98b53u & 0x33a6a274u))) continue;
            }
        } while (i0++ < 2u && ((0x10000u % (g1 | 1u)) - u0));
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)b0, v0, (u2 / (garr[u2 & 7u] | 1u))); }
    } else {
        while (i0++ < 6u && 0x10000u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)c1 && 0x1a908b57u)) break;
        }
        if ((0x10000u << ((unsigned)b0 & 31u))) goto L0;
    }
    b0 = (1u | (p1 / ((unsigned)l0 | 1u))) != 0u;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)(((unsigned)d0 | (unsigned)s0) == (u2 ? (unsigned)x0 : u0));
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + 0xffffffffu;
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                *q0 = ((unsigned)!(unsigned)(((unsigned)l0 % (p1 | 1u)) && (unsigned)h1) ^ i0);
                if ((*q0 ^ (unsigned)l0)) break;
                d0 = d0 * 0.5 + (double)((0x7fffffffu / (0u | 1u)) & 1023u);
                continue; (void)(garr[u2 & 7u]);
                *q0 = (unsigned)((int)(unsigned)c1 >= (int)0x438a8c43u);
                if (((3u & 0xe9019042u) * p2)) break;
            }
        }
        goto done;
        q0 = &garr[(unsigned)(signed char)(g0 * 1u) & 7u];
    }
    if ((unsigned)((unsigned)s0 && 0u)) {
        if (fuel < 8u) return (((unsigned)x0 / (((0x7fffffffu - *q0) & 0x7fffffffu) | 1u)) + 8u);
        g0 = (unsigned)((0xffffffffu & (unsigned)f0) || (0x10000u >> ((0u << ((unsigned)s0 & 31u)) & 31u)));
        h0 = (short)(*mp % (p2 | 1u));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 5u, 0xdf96da44u, 0x4caef9cdu },
        { 6u, 0x72b90e5cu, 0x2230d7bbu },
        { 13u, 0x1a5b8779u, 0x18dd35c3u },
        { 8u, 0xecb1ed3fu, 0x60054dc6u },
        { 7u, 0xe56cf6adu, 0x7a2ffc99u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
