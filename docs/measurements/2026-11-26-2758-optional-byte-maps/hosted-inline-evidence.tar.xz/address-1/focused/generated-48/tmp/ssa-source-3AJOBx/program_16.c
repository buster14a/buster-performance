// test-ssa-source's program of seed 134000418 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x2b3ed504u, g1 = 0x2d0ee064u;
static unsigned garr[8] = { 0x1a97c90u, 0x1093bb4du, 0xc8e02edfu, 0xdaa99617u, 0x6301da35u, 0x2cb6e7b9u, 0x50a860du, 0xbfe46f9au };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && (unsigned)h0) { if (--fuel == 0u) goto done;
            *q0 += (unsigned)(0xdddab966u < (unsigned)((int)r0.x < (int)fuel));
            do { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)(i0 || (unsigned)l0) && (unsigned)(x0 >> 70))) goto L0;
                h1 = (unsigned short)(h1 + (p1 | (unsigned)c0));
                g0 = (unsigned)(a0[i0 & 3u] && (unsigned)b0);
                s0 = (int)(unsigned)((unsigned)s1 == (unsigned)((unsigned)c1 || (unsigned)(*q0 < r0.x)));
                b0 = (unsigned)(0xd326f7bbu || 0xd5b31be0u) != 0u;
            } while (i2++ < 7u && (unsigned)((int)p1 < (int)0x1aeb7950u));
            if (u3 == 7u) return ((unsigned)(signed char)(unsigned)((short)(g1 >> (p0 & 31u)) > (signed char)0x7fffffffu) >> ((unsigned)!((unsigned)b0 + (unsigned)s1) & 31u));
        }
        if ((0x5a69ca9cu % ((u2 + i1) | 1u))) break;
    }
    if ((unsigned)(unsigned char)(a0[i0 & 3u] >> (((unsigned)c1 - garr[i1 & 7u]) & 31u))) goto L1;
    if (u3 == 7u) return (garr[u2 & 7u] | 0x10000u);
    switch (7u & 7u) {
        L1: if (--fuel == 0u) goto done;
        i1 = ((unsigned)c0 % ((unsigned)(w0 >> 29) | 1u)) & 15u;
        f0 = f0 * 0.5f + (float)(~((garr[i1 & 7u] | 0x10000u) ? (a0[u1 & 3u] - (unsigned)c0) : (unsigned)(w0 >> 29)) & 255u);
        switch (i0 & 7u) {
            goto L4;
            L2: if (--fuel == 0u) goto done;
            if ((1u ^ (g0 | (unsigned)e0))) break;
            u0 += (*q0 | i1);
            L3: if (--fuel == 0u) goto done;
            case 3u: ;
        }
        while (i0++ < 3u && (i1 * garr[u2 & 7u])) { if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
        }
        w0 = w0 * 6364136223846793005ull + i2;
    }
    switch ((0x7fffffffu << (p2 & 31u)) & 7u) {
        w0 = w0 * 6364136223846793005ull + (unsigned)!(unsigned)((int)(unsigned)(signed char)(garr[i1 & 7u] ^ u0) >= (int)p1);
        if ((unsigned)(short)(unsigned)((unsigned)c0 < u2)) {
            while (i0++ < 4u && (unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)r0.x;
                    case 6u: ;
                    u2 ^= (i0 << (r0.x & 31u));
                    u1 = (((unsigned)(0xe4b9e9d0u < ~(unsigned)(0xffffffffu < 0x891a866cu)) * (unsigned)h1) - r0.x);
                    case 7u: ;
                    if (((unsigned)b0 / ((unsigned)(5u == (unsigned)e0) | 1u))) goto done;
                } while (i1++ < 6u && 1u);
                case 3u: ;
                case 0u: ;
            }
            if ((8u ? *mp : a0[i0 & 3u])) {
                if ((unsigned)(u2 && (unsigned)h0)) goto L2;
                r0.y ^= (unsigned)((short)p1 > (signed char)v0);
            }
            h0 = (short)-(unsigned)((int)((unsigned)c0 & (unsigned)(w0 >> 29)) >= (int)g1);
            g1 += ((unsigned)(x0 >> 70) << (u2 & 31u));
            b0 = (unsigned)(unsigned char)(u1 ^ garr[i1 & 7u]) != 0u;
            if (((unsigned)c0 / (((unsigned)f0 / (0x7fffffffu | 1u)) | 1u))) {
                if (((unsigned)s0 / ((0x10000u << (i1 & 31u)) | 1u))) break;
            } else {
                *mp = (*mp - (unsigned)h1);
                default: ;
            }
        } else {
            while (i0++ < 5u && (0x7fffffffu + (unsigned)e0)) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(((unsigned)h0 >> ((unsigned)(unsigned char)(unsigned)((short)0xfc148861u > (signed char)(unsigned)((int)i1 < (int)(unsigned)w0)) & 31u)) & 1023u);
                if ((unsigned)((unsigned)s1 == (unsigned)f0)) goto L2;
                s0 = (int)(~(((unsigned)l0 / (1u | 1u)) * p0) << ((unsigned)!(unsigned)((int)i1 >= (int)7u) & 31u));
                break;
                a0[(g1 - p2) & 3u] = *mp;
                case 5u: ;
            }
            if ((unsigned)(0x10000u < p1)) break;
            do { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((int)(unsigned)h1 >= (int)((unsigned)c1 + (unsigned)h1)) || 0x87c4ead7u));
                c0 = (unsigned char)(fuel ^ ((unsigned)h1 % (m0 | 1u)));
                break;
                break;
            } while (i0++ < 5u && (unsigned)((unsigned)b0 || (p2 | u2)));
        }
        h1 = (unsigned short)(h1 + i2);
        break; (void)(r0.x);
        u3 += ((r0.y % ((unsigned)(x0 >> 70) | 1u)) & 0xaa3bdca6u);
        if ((unsigned)(g1 == p0)) {
            if ((unsigned)!(unsigned)((unsigned)b0 || 0xffffffffu)) goto done;
            if ((unsigned)((short)((unsigned)s0 * (unsigned)l0) > (signed char)2u)) {
                { unsigned t0; double z0; if ((((unsigned)s1 | 0xffffffffu)) & 1u) { t0 = (unsigned)((int)0xffffffffu >= (int)((unsigned)h1 & (unsigned)s1)); z0 = (double)(((0xffffffffu * (unsigned)w0)) & 255u); } if ((((unsigned)s1 | 0xffffffffu)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    u3 = u3 * 0x9e3779b1u + (unsigned)(((8u << ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)s0) & 31u)) << (0x7fffffffu & 31u)) || 0x647fbd0u);
                    while (i0++ < 6u && (p2 & r0.x)) { if (--fuel == 0u) goto done;
                        m0 ^= (2u | u3);
                    }
                }
            }
            goto L2;
            { unsigned t1; double z1; if (((unsigned)(*q0 == a0[i0 & 3u])) & 1u) { t1 = 0x7fffffffu; z1 = (double)(((unsigned)((short)0x10000u > (signed char)((unsigned)d0 >> (8u & 31u)))) & 255u); } if (((unsigned)(*q0 == a0[i0 & 3u])) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                h1 = (unsigned short)(h1 + ((unsigned)h0 & 0xd7f8dd02u));
                case 1u: ;
                goto L3;
                if (-(-(unsigned)((int)0xfbbf9291u < (int)0x7fffffffu) >> (fuel & 31u))) goto done;
                { unsigned t2; double z2; if (((unsigned)(x0 >> 70)) & 1u) { t2 = (i1 - 4u); z2 = (double)(((((unsigned)h1 >> ((unsigned)b0 & 31u)) >> (u0 & 31u))) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    x0 = x0 * 0x100000001b3ull + (unsigned)(w0 >> 29);
                    if (*q0) goto L0;
                    case 2u: ;
                }
            }
            case 4u: ;
            d0 = d0 * 0.5 + (double)(0x80000000u & 1023u);
        } else {
            u0 ^= ~((unsigned)e0 >> (1u & 31u));
            if (p0) {
                h0 = (short)p1;
            } else {
                s1 = (int)((unsigned)s1 + (unsigned)((short)a0[i0 & 3u] > (signed char)0xe684c583u));
                x0 = x0 * 0x100000001b3ull + g1;
                b0 = (unsigned)((unsigned)x0 < (unsigned)((unsigned)(unsigned char)(unsigned)((short)((unsigned)h1 >> ((unsigned)b0 & 31u)) > (signed char)m0) && p2)) != 0u;
                break;
            }
            if (0xb18a33bbu) {
                break;
                if (((fuel * garr[u2 & 7u]) - m0)) {
                    break;
                }
                r0.y ^= (unsigned)(signed char)((unsigned)(short)(unsigned)((short)0xb4d6ffeau > (signed char)(unsigned)((short)(unsigned)f0 > (signed char)((unsigned)e0 * 0xabe9baa6u))) ^ r0.y);
                u3 ^= (unsigned)(3u < (unsigned)((int)(r0.y + p1) < (int)(unsigned)s0));
                break;
                u3 ^= (unsigned)((int)(unsigned)(0xffffffffu && (unsigned)((int)4u >= (int)0xffffffffu)) < (int)(unsigned)(m0 == (unsigned)h1));
            } else {
                if ((0x10000u << (v0 & 31u))) break;
            }
            v0 = (r0.x - ((unsigned)x0 << (3u & 31u)));
        }
    }
    r0.y ^= -(((unsigned)c0 + (unsigned)(g1 || p2)) + (unsigned)(u2 < p1));
    f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)(0x4bbd51f4u && (unsigned)((int)9u >= (int)(unsigned)s0)) >= (int)0x7fffffffu) & 255u);
    do { if (--fuel == 0u) goto done;
        a0[(unsigned)h0 & 3u] = (unsigned)((a0[i0 & 3u] + (0u / ((unsigned)f0 | 1u))) || (unsigned)((int)p1 < (int)r0.x));
    } while (i0++ < 6u && (unsigned)e0);
    if ((unsigned)(((unsigned)h0 >> (2u & 31u)) || 4u)) goto L2;
    for (;;) { if (--fuel == 0u) goto done;
        q0 = &garr[((unsigned)s0 ? (unsigned)!(0x7fffffffu | u0) : ((unsigned)b0 / (p2 | 1u))) & 7u];
        do { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)(v0 == (unsigned)((unsigned)h0 == 0xff3e101bu));
        } while (i1++ < 5u && (unsigned)c0);
    }
    while ((p0 & u2)) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)*q0 << ((unsigned)w0 & 63u);
        q0 = &garr[((unsigned)c0 % ((unsigned)((unsigned)b0 || u2) | 1u)) & 7u];
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)*mp >= (int)m0)) break;
            break; (void)(g1);
            l0 = (long)((unsigned long)l0 + ~((p2 * (unsigned)c1) - (unsigned)h0));
            if (fuel < 8u) return ((unsigned)(signed char)(unsigned)((unsigned)l0 == (unsigned)b0) >> ((i1 & 0x44f107d5u) & 31u));
            u1 ^= (unsigned)(short)((((*q0 << ((unsigned)l0 & 31u)) - *q0) & 0xda8da0c7u) ^ 0xffffffffu);
        }
        { unsigned t3; double z3; if ((0x9d431b69u) & 1u) { t3 = (unsigned)!(unsigned)(0u || (unsigned)b0); z3 = (double)((a0[i0 & 3u]) & 255u); } if ((0x9d431b69u) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            if (a0[i0 & 3u]) break;
            u1 = (garr[i1 & 7u] - 7u);
            if (2u) break;
        }
        u1 = (unsigned)!(p2 - ((unsigned)(x0 >> 70) >> (3u & 31u)));
    }
    if (((unsigned)l0 << (0x80000000u & 31u))) {
        while (i0++ < 6u && ~(i0 / (u2 | 1u))) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + ((unsigned)x0 >> (-((unsigned)(x0 >> 70) & (unsigned)(garr[u2 & 7u] || (unsigned)l0)) & 31u)));
        }
        c0 = (unsigned char)(unsigned)(((unsigned)(x0 >> 70) - (unsigned)c0) || (0x3a0dc2f6u + (unsigned)((int)0xb6e15a6u >= (int)p0)));
        s1 = (int)((unsigned)s1 + (0u & 0x6cdc22e9u));
        do { if (--fuel == 0u) goto done;
            break; (void)(((unsigned)(0xffffffffu == (unsigned)x0) & 4u));
            u3 = u3 * 0x9e3779b1u + ((unsigned)(short)((unsigned)w0 - fuel) ? 0x5f04a071u : 0x3650e124u);
        } while (i0++ < 3u && ((unsigned)x0 & (unsigned)((int)(unsigned)x0 < (int)0x9f99dce0u)));
        h0 = (short)(unsigned)(unsigned char)((unsigned)(5u && (7u % (i2 | 1u))) ^ p1);
        switch ((0x9653abd2u ? 0x9f6cb1bfu : fuel) & 7u) {
            case 6u: ;
            f0 = f0 * 0.5f + (float)(((unsigned)((v0 >> (garr[u2 & 7u] & 31u)) == (unsigned)h0) ^ 0xe7a3b3d6u) & 255u);
            m0 ^= (0xffffffffu ^ (unsigned)((int)(unsigned)(a0[i0 & 3u] && g1) >= (int)(unsigned)s1));
        }
    } else {
        if ((0x1ab5369eu + (unsigned)((int)0x10000u < (int)garr[u2 & 7u]))) goto L3;
        if ((unsigned)b0) goto done;
        *q0 = (unsigned)((~(unsigned)((int)0x7fffffffu >= (int)0xcb2b061au) * 5u) && i0);
        q0 = &garr[((unsigned)(w0 >> 29) - 0xfb16ec35u) & 7u];
    }
    goto L2;
    if ((0x50cb306bu + i1)) goto L0;
    while (i0++ < 5u && ((unsigned)(w0 >> 29) >> (u3 & 31u))) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)(v0 < a0[i0 & 3u]));
                if (-(u2 << ((unsigned)c0 & 31u))) break;
                if ((unsigned)((short)0x62ad0fd4u > (signed char)fuel)) goto L2;
                while (i0++ < 5u && garr[u2 & 7u]) { if (--fuel == 0u) goto done;
                    a0[7u & 3u] = (garr[u2 & 7u] ^ (unsigned)((int)g0 >= (int)p0));
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)(unsigned)(short)(0xe3862948u * (unsigned)h0);
                    }
                    f0 = f0 * 0.5f + (float)((~(u1 << ((u3 / (1u | 1u)) & 31u)) % ((unsigned)s1 | 1u)) & 255u);
                    if (0x7fffffffu) {
                        if ((i2 % (0x59e286b2u | 1u))) break;
                        if ((unsigned)e0) break;
                    } else {
                        if (((unsigned)c0 + ~(m0 / (v0 | 1u)))) break;
                        if ((0x7919720du & p1)) break;
                    }
                }
                u3 = (unsigned)((int)(unsigned)l0 < (int)(0x10000u & (0x7fffffffu ^ p0)));
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((unsigned)((unsigned)w0 == fuel) & 1023u);
                    f0 = f0 * 0.5f + (float)((unsigned)(((u0 * 0xffffffffu) ^ (unsigned)d0) || (unsigned)e0) & 255u);
                    break; (void)(7u);
                }
            }
            u2 += ~(a0[i0 & 3u] << ((unsigned)((unsigned)(signed char)(r0.x | i1) == (unsigned)h1) & 31u));
            break; (void)(u2);
            while (i1) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)(unsigned char)((unsigned)w0 << (0x80000000u & 31u)) && r0.x)) break;
                *mp = 0x1ea2b2c8u;
                if (u1) break;
                while (i0++ < 6u && (unsigned)(i0 && *q0)) { if (--fuel == 0u) goto done;
                    r0.x = ((unsigned)w0 | (garr[u2 & 7u] ? p0 : 0x222f6551u));
                    d0 = d0 * 0.5 + (double)(((unsigned)(p0 < (unsigned)w0) + (unsigned)s0) & 1023u);
                    b0 = (p2 ^ -(unsigned)((int)0x4ad6e660u >= (int)0u)) != 0u;
                    if ((unsigned)h0) continue;
                    d0 = d0 * 0.5 + (double)((i0 ^ (unsigned)(x0 >> 70)) & 1023u);
                }
            }
            for (;;) { if (--fuel == 0u) goto done;
                while (i0++ < 3u && (unsigned)((short)(unsigned)x0 > (signed char)(unsigned)(7u == garr[u2 & 7u]))) { if (--fuel == 0u) goto done;
                    u3 += p0;
                }
                break; (void)(-(g1 - r0.y));
                r0.x = 0x10000u;
            }
            switch (0xffffffffu & 7u) {
                x0 = x0 * 0x100000001b3ull + ((unsigned)!((unsigned)(w0 >> 29) + g1) - p0);
                if (u3 == 7u) return ((unsigned)(short)(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)d0) - (unsigned)!((p1 % (i1 | 1u)) ^ 6u));
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = ((u1 ? p0 : u1) & (unsigned)(fuel == *q0));
                    g1 += (unsigned)(signed char)((unsigned)e0 + (0x1b711593u - (r0.x << (0xa8d6d323u & 31u))));
                    switch ((garr[i1 & 7u] ? i0 : 0xc9f4b0a1u) & 7u) {
                        w0 = w0 * 6364136223846793005ull + ~((unsigned)((unsigned)(short)((unsigned)b0 / ((unsigned)c1 | 1u)) == (unsigned)((int)(unsigned)d0 >= (int)(unsigned)e0)) << (a0[u1 & 3u] & 31u));
                        s1 = (int)((unsigned)s1 + (((unsigned)(w0 >> 29) + 2u) - 0x7128a6b1u));
                        case 0u: ;
                    }
                    if ((unsigned)((unsigned)(w0 >> 29) && (unsigned)(0xb47eb889u < (unsigned)d0))) continue;
                }
                if (u3 == 7u) return 7u;
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((0x80000000u & (unsigned)b0)) {
                        case 1u: ;
                    } else {
                        u0 = u2;
                        e0 = e0 * 0.5L + (long double)((unsigned)c0 & 1023u);
                    }
                    u2 = u2 * 0x9e3779b1u + ((unsigned)(unsigned char)(unsigned)((int)*mp < (int)*q0) % ((0xb1327c13u + 0x10000u) | 1u));
                    case 6u: ;
                    default: ;
                    switch ((unsigned)(u3 && (unsigned)((short)(unsigned)c0 > (signed char)r0.y)) & 7u) {
                        if ((unsigned)((unsigned)(w0 >> 29) < 0x80000000u)) {
                            case 7u: ;
                            g0 = -((0xffffffffu & i1) / ((unsigned)((int)((unsigned)(x0 >> 70) - (unsigned)x0) >= (int)0x80000000u) | 1u));
                            d0 = d0 * 0.5 + (double)((0x31cbc83bu - (unsigned)e0) & 1023u);
                            case 4u: ;
                            case 5u: ;
                        }
                    }
                    h1 = (unsigned short)(h1 + ~((unsigned)(unsigned char)(unsigned)(i1 == (unsigned)(a0[i0 & 3u] < (unsigned)c1)) >> (r0.y & 31u)));
                }
            }
        }
    }
    if ((unsigned)((int)(unsigned)(8u && 3u) < (int)(unsigned)x0)) {
        for (;;) { if (--fuel == 0u) goto done;
            if ((0xd4334160u + ((unsigned)e0 / (g1 | 1u)))) break;
            x0 = x0 * 0x100000001b3ull + ((unsigned)h1 | (unsigned)((short)(u2 | garr[u2 & 7u]) > (signed char)((unsigned)h1 & (unsigned)(w0 >> 29))));
            if ((v0 / (0x10000u | 1u))) {
                if ((unsigned)e0) break;
                g1 += ((u1 | 0x7fffffffu) + (0x10000u >> ((unsigned)d0 & 31u)));
            } else {
                if ((a0[i0 & 3u] | 0x80000000u)) break;
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    while (i2++ < 5u && (r0.y ? 0xd22e57f2u : (unsigned)w0)) { if (--fuel == 0u) goto done;
                        u3 = (unsigned)((unsigned)(u1 < (unsigned)s0) == ((u0 - u2) % (garr[i1 & 7u] | 1u)));
                    }
                    if ((unsigned)((short)0x80000000u > (signed char)(unsigned)d0)) {
                        s1 = (int)((unsigned)s1 + ((unsigned)h0 << (u2 & 31u)));
                        if ((r0.y / (g1 | 1u))) break;
                        break; (void)((unsigned)((short)(unsigned)s0 > (signed char)r0.x));
                        v0 = u3;
                    }
                    break; (void)((fuel / (4u | 1u)));
                }
                if ((unsigned)((int)i1 >= (int)(unsigned)f0)) {
                    if (0x9bf0cd76u) {
                        break; (void)(((unsigned)s1 << (i1 & 31u)));
                        i2 = (unsigned)b0 & 15u;
                        if (a0[u1 & 3u]) break;
                        h1 = (unsigned short)(h1 + (unsigned)(v0 || u0));
                    } else {
                        v0 = (unsigned)!((unsigned)l0 >> ((unsigned)((short)0x3b96a2b0u > (signed char)(unsigned)x0) & 31u));
                    }
                    g0 = ((a0[i0 & 3u] / ((unsigned)(unsigned char)(unsigned)(0x7fffffffu && 0xf3d95e1eu) | 1u)) | ((unsigned)e0 / (0x5bd7e464u | 1u)));
                    if (u3 == 7u) return ~(unsigned)((int)(unsigned)d0 >= (int)(unsigned)(((unsigned)l0 >> ((unsigned)h1 & 31u)) < ((unsigned)(x0 >> 70) & r0.y)));
                    do { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)(unsigned)(0xffffffffu < (unsigned)(w0 >> 29)) << ((unsigned)((unsigned)w0 == (unsigned)((int)(i0 << (fuel & 31u)) >= (int)p1)) & 63u);
                    } while (i1++ < 7u && (unsigned)(0xffffffffu || (a0[i0 & 3u] % ((unsigned)b0 | 1u))));
                    if (((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)m0) & (unsigned)h0)) break;
                    if (u3 == 7u) return (fuel / ((unsigned)(signed char)(unsigned)(fuel && ((unsigned)c0 - i2)) | 1u));
                }
                v0 = (unsigned)(x0 >> 70);
            }
        }
        goto done;
        { unsigned t4; double z4; if (((unsigned)h0) & 1u) { t4 = ((unsigned)((unsigned)h1 || 7u) | (unsigned)w0); z4 = (double)(((p0 << (((unsigned)(w0 >> 29) << (6u & 31u)) & 31u))) & 255u); } if (((unsigned)h0) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                s0 = (int)(unsigned)c0;
            }
            goto L3;
            while (i0++ < 6u && (unsigned)(0x749985e6u == p2)) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(0xbd0818adu == v0));
                c0 = (unsigned char)r0.y;
                if ((unsigned)((u3 - 4u) && 0xc58fa9f3u)) break;
                if (0u) break;
                break; (void)((a0[i0 & 3u] / ((unsigned)((int)r0.y < (int)0x7a271a19u) | 1u)));
            }
            if ((unsigned)((short)(unsigned)(4u == 0x7fffffffu) > (signed char)(unsigned)b0)) goto L4;
        }
        if (garr[u2 & 7u]) goto L2;
        while (i0++ < 6u && (i2 * r0.y)) { if (--fuel == 0u) goto done;
            u0 = (unsigned)((unsigned)x0 && ((unsigned)x0 | (0x6977e9a5u | p1)));
            if ((unsigned)((short)(unsigned)d0 > (signed char)u0)) break;
        }
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        goto L4;
        if (((unsigned)l0 ^ a0[u1 & 3u])) {
            if ((unsigned)(p2 && (unsigned)l0)) break;
            u2 = (unsigned)((int)((unsigned)(x0 >> 70) * (unsigned)d0) >= (int)garr[u2 & 7u]);
            { unsigned t5; double z5; if (((unsigned)(short)(u1 / (((unsigned)c1 >> (i2 & 31u)) | 1u))) & 1u) { t5 = ((unsigned)c1 ? m0 : 0x10000u); z5 = (double)((p2) & 255u); } if (((unsigned)(short)(u1 / (((unsigned)c1 >> (i2 & 31u)) | 1u))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                u2 += p2;
                x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(unsigned)((unsigned)s0 == (unsigned)((int)u3 >= (int)0x29b7fbc7u));
                m0 ^= (unsigned)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)garr[u2 & 7u]) < garr[u2 & 7u]);
                c0 = (unsigned char)(((7u * (6u >> (0x14b695du & 31u))) >> (7u & 31u)) + v0);
                if ((unsigned)(short)(fuel * 9u)) {
                    s1 = (int)((unsigned)s1 + (0xb2d40955u ^ (m0 << (i0 & 31u))));
                    e0 = e0 * 0.5L + (long double)((unsigned)!(unsigned)(p0 && (unsigned)((int)(unsigned)d0 < (int)0x2f55ea7cu)) & 1023u);
                    s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)(signed char)(unsigned)((unsigned)b0 == (unsigned)(4u || (unsigned)((unsigned)c0 && (unsigned)h0))) < (int)r0.y));
                }
            }
            if (r0.x) break;
        }
        goto L2;
        while ((unsigned)(unsigned char)(unsigned)((int)0x10000u >= (int)~(unsigned)((int)i1 >= (int)4u))) { if (--fuel == 0u) goto done;
            if ((unsigned)(0x30574ea4u || u2)) break;
            if ((((unsigned)l0 + 3u) - u2)) break;
            if (p1) break;
        }
        break; (void)(0x7fffffffu);
        break; (void)(r0.y);
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= ((u3 ? (u3 % (0x7fffffffu | 1u)) : (unsigned)(w0 >> 29)) * g0);
        u3 = u3 * 0x9e3779b1u + (a0[u1 & 3u] + u3);
        continue; (void)(((unsigned)s0 ? 7u : (unsigned)b0));
        garr[(unsigned)f0 & 7u] = (unsigned)(short)(~(0xd6bd336cu % (-((unsigned)s0 / (3u | 1u)) | 1u)) ^ g0);
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(0u == garr[i1 & 7u])) break;
            *mp = (unsigned)h1;
            if ((unsigned)((short)((unsigned)w0 | u2) > (signed char)0x4cc1912du)) {
                if ((unsigned)((int)(unsigned)(unsigned char)(p0 - 0xeacc0268u) < (int)m0)) {
                    if (0x41de63bcu) break;
                    if ((unsigned)(x0 >> 70)) goto L1;
                    break; (void)((unsigned)((int)(unsigned)s1 < (int)(unsigned)e0));
                    if ((unsigned)(i1 == 6u)) break;
                } else {
                    *q0 += ((((unsigned)f0 ^ p2) | i1) - fuel);
                    if ((p0 + m0)) {
                        if (i0) break;
                        *mp = (unsigned)(unsigned char)(((unsigned)l0 & 0x10000u) & (unsigned)!(u0 << ((unsigned)(g1 == p1) & 31u)));
                        d0 = d0 * 0.5 + (double)((p1 * i2) & 1023u);
                        garr[(*mp + 0xffffffffu) & 7u] = (unsigned)(signed char)(0xffffffffu - (unsigned)((unsigned)c1 == ((unsigned)e0 | 0x96abb8d6u)));
                        m0 ^= ((a0[u1 & 3u] >> ((unsigned)h1 & 31u)) & (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)(signed char)(unsigned)((short)p0 > (signed char)(unsigned)b0)));
                    } else {
                        break; (void)((0xaa922589u / ((unsigned)h1 | 1u)));
                        for (;;) { if (--fuel == 0u) goto done;
                            r0.x = (0x5715226eu - m0);
                            if ((unsigned)(signed char)(unsigned)(0x43a83cd4u && (5u & *mp))) break;
                            a0[(u1 >> (0xa2e51a76u & 31u)) & 3u] = (unsigned)(signed char)(unsigned)(p0 == (m0 * (unsigned)(signed char)(((unsigned)h1 << (r0.y & 31u)) >> (0x12c0f506u & 31u))));
                            v0 = (unsigned)!((unsigned)((int)(unsigned)c0 < (int)0x80000000u) | (unsigned)(0x16df3b83u == v0));
                            h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)l0 >= (int)garr[i1 & 7u]));
                        }
                    }
                    u2 ^= ((unsigned)((*mp >> (u2 & 31u)) < (unsigned)c0) % (*mp | 1u));
                }
            } else {
                if ((unsigned)s0) break;
                while (i2++ < 2u && (unsigned)c0) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)(g0 && 0x1e636af7u));
                    if ((unsigned)l0) goto L4;
                }
                if (m0) continue;
                u3 = (unsigned)(*mp == (unsigned)b0);
            }
            garr[(unsigned)((int)0x5a917e60u >= (int)i2) & 7u] = ((garr[u2 & 7u] * 3u) / (8u | 1u));
            *q0 = (unsigned)((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)((int)(unsigned)(p0 || 0xffffffffu) < (int)3u)) == garr[i1 & 7u]);
        }
        break; (void)((unsigned)(w0 >> 29));
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(2u || ((unsigned)d0 >> (*mp & 31u)))) {
            if ((r0.y * (unsigned)c0)) {
                if ((unsigned)((int)p2 >= (int)3u)) {
                    if ((unsigned)((int)~((unsigned)s1 - r0.x) < (int)i0)) continue;
                    c1 = (signed char)r0.x;
                    i0 = (unsigned)(v0 == (unsigned)s1) & 15u;
                    if ((unsigned)((unsigned)l0 && v0)) break;
                    if (u3 == 7u) return r0.y;
                    u1 = (unsigned)d0;
                }
            }
            v0 = (unsigned)(r0.x && (r0.y | 0x1cfb214eu));
        }
        break; (void)((unsigned)((unsigned)((int)0xb81dd636u < (int)a0[u1 & 3u]) || p0));
    }
    goto L4;
    goto done;
    if ((unsigned)w0) {
        u3 = u3 * 0x9e3779b1u + p0;
        if ((i1 ^ (unsigned)(short)((unsigned)e0 + p0))) goto L0;
        { unsigned t6; double z6; if (((unsigned)((int)i0 >= (int)(unsigned)b0)) & 1u) { t6 = 3u; z6 = (double)(((unsigned)(short)(0xffffffffu - (unsigned)(unsigned char)(u2 << ((unsigned)w0 & 31u)))) & 255u); } if (((unsigned)((int)i0 >= (int)(unsigned)b0)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            g0 = (unsigned)((int)0x61cf9853u < (int)(unsigned)w0);
            i0 = (unsigned)(*mp || fuel) & 15u;
            u0 += (unsigned)!(i2 * 7u);
            while (~(unsigned)((int)(unsigned)(*mp == p2) >= (int)p0)) { if (--fuel == 0u) goto done;
                if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)c1 >= (int)(unsigned)(i0 && (unsigned)(x0 >> 70)))) goto L4;
                w0 ^= (unsigned long long)*q0 << (((unsigned)l0 - (unsigned)(w0 >> 29)) & 63u);
                i0 = ((9u & a0[i0 & 3u]) | v0) & 15u;
            }
            h0 = (short)((unsigned)!(unsigned)(v0 || (unsigned)s0) * 4u);
        }
        if (garr[i1 & 7u]) goto L0;
        u2 ^= (p2 << ((((unsigned)(x0 >> 70) / ((unsigned)(0x23ec2f52u && 0x8b2a07d5u) | 1u)) >> (garr[u2 & 7u] & 31u)) & 31u));
        switch (((unsigned)(short)(a0[i0 & 3u] - fuel) & 0xe3cca543u) & 7u) {
            case 5u: ;
            if (0x7fffffffu) goto L3;
        }
    } else {
        if ((0x7fffffffu / ((unsigned)d0 | 1u))) goto L4;
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            goto done;
            switch (((unsigned)l0 & (unsigned)s1) & 7u) {
                case 6u: ;
                w0 ^= (unsigned long long)0x10000u << (1u & 63u);
                case 2u: ;
                if ((unsigned)((0x7fffffffu - g0) < m0)) break;
                case 3u: ;
            }
        }
        goto done;
        goto L3;
    }
    goto L2;
    { unsigned t7; double z7; if ((-(p2 ^ 0x10000u)) & 1u) { t7 = v0; z7 = (double)(((unsigned)(signed char)(unsigned)((int)v0 < (int)(0x4265f8eu << (fuel & 31u)))) & 255u); } if ((-(p2 ^ 0x10000u)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
        goto L3;
        b0 = p2 != 0u;
        if (fuel < 8u) return (unsigned)(0x80000000u && 0x461819edu);
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (fuel << ((0x796c3053u & a0[i0 & 3u]) & 31u));
        }
        for (;;) { if (--fuel == 0u) goto done;
            c1 = (signed char)p0;
            break; (void)((unsigned)((int)(unsigned)c0 >= (int)(0x80000000u - (unsigned)(x0 >> 70))));
            if (u3 == 7u) return (unsigned)f0;
        }
        if (9u) {
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (i2 % (0x10000u | 1u)));
                if (u3 == 7u) return (unsigned)(r0.y == ((unsigned)((int)9u < (int)(unsigned)c1) / ((unsigned)(x0 >> 70) | 1u)));
                switch ((unsigned)((int)4u < (int)(5u % ((unsigned)b0 | 1u))) & 7u) {
                    b0 = (((unsigned)c1 + (garr[u2 & 7u] | v0)) * (p1 >> (u2 & 31u))) != 0u;
                    if (u3 == 7u) return ((unsigned)(short)(unsigned)(((unsigned)c0 | 0xffffffffu) || (unsigned)s1) >> (*q0 & 31u));
                    case 7u: ;
                    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(x0 >> 70) && (unsigned)(m0 && 9u)));
                    if ((unsigned)((int)u2 < (int)3u)) continue;
                    l0 = (long)((unsigned long)l0 + (p0 << (((unsigned)h1 << (p1 & 31u)) & 31u)));
                }
                if ((unsigned)(2u && (unsigned)b0)) break;
            }
        }
    }
    { unsigned t8; double z8; if ((((unsigned)e0 + v0)) & 1u) { t8 = (u0 - (unsigned)s1); z8 = (double)(((unsigned)h1) & 255u); } if ((((unsigned)e0 + v0)) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
        if (m0) goto L1;
        if ((unsigned)((unsigned)(g0 == u1) == 0x9a901ef0u)) goto L1;
        { unsigned t9; double z9; if ((~(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)l0)) & 1u) { t9 = (unsigned)((int)(unsigned)b0 >= (int)-(unsigned)((int)(unsigned)c0 < (int)6u)); z9 = (double)(((unsigned)((int)(unsigned)(fuel && u3) < (int)*q0)) & 255u); } if ((~(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)l0)) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
            r0.y ^= g1;
            if ((i2 & 0xcaf7ecc3u)) {
                i0 = (unsigned)(0x80000000u || u0) & 15u;
            } else {
                if (m0) {
                    g1 += (unsigned)((unsigned)(0x5c5eebb4u && 0xffffffffu) && (unsigned)s0);
                    if (0xffffffffu) goto L3;
                }
                s1 = (int)((unsigned)s1 + (unsigned)(-(unsigned)(r0.x && garr[i1 & 7u]) && (m0 / (0x9acc3131u | 1u))));
                if ((unsigned)(0x10000u && (unsigned)w0)) goto L4;
            }
            switch ((unsigned)((int)*mp >= (int)(unsigned)(w0 >> 29)) & 7u) {
                case 3u: ;
                c1 = (signed char)(unsigned)(((unsigned)((int)fuel >= (int)u3) | 0x86e00969u) || (0xffffffffu + i0));
                if (7u) {
                    default: ;
                    case 1u: ;
                    a0[(unsigned)!(u3 / (p1 | 1u)) & 3u] = garr[u2 & 7u];
                    l0 = (long)((unsigned long)l0 + (unsigned)((int)(*q0 % (m0 | 1u)) < (int)((unsigned)x0 % (a0[u1 & 3u] | 1u))));
                    while (8u) { if (--fuel == 0u) goto done;
                        break;
                        a0[4u & 3u] = (unsigned)((int)(unsigned)h1 >= (int)(unsigned)h0);
                    }
                } else {
                    g0 = (unsigned)((i0 + r0.x) || i1);
                    case 6u: ;
                    goto done;
                    *mp = ((unsigned)c1 >> ((unsigned)(v0 && 0x5e93e21au) & 31u));
                }
                l0 = (long)((unsigned long)l0 + ((unsigned)l0 ^ (unsigned)((int)0x7fffffffu < (int)(unsigned)s1)));
                if (-(8u ? (unsigned)h1 : i0)) goto L3;
            }
        }
        r0.y ^= (unsigned)(signed char)(unsigned)(0xab4064dau && ((unsigned)b0 & ((unsigned)h1 + m0)));
        *q0 += (unsigned)((int)(unsigned)l0 < (int)(unsigned)f0);
        f0 = f0 * 0.5f + (float)(((unsigned)((int)(unsigned)h1 >= (int)p0) + (unsigned)((unsigned)s0 < (0x2e5bdf05u * (unsigned)e0))) & 255u);
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        s0 = (int)~(r0.y | (unsigned)!((unsigned)f0 + (unsigned)((int)0xdc85bb6au < (int)0x6a616acbu)));
        if (g0) continue;
        do { if (--fuel == 0u) goto done;
            c1 = (signed char)((0x7a41e764u >> ((unsigned)(5u == g0) & 31u)) | (0x80000000u / ((unsigned)l0 | 1u)));
        } while (i1++ < 7u && (p0 << (0x8d033a6eu & 31u)));
        if ((0x7fffffffu - (unsigned)s0)) break;
        garr[(unsigned)((int)1u >= (int)u3) & 7u] = ((i1 % (0x80000000u | 1u)) % (g0 | 1u));
        r0.x = (unsigned)((int)(unsigned)(i0 == (unsigned)b0) >= (int)(unsigned)b0);
    }
    goto L3;
    if ((*q0 - ((unsigned)b0 * 1u))) goto done;
    b0 = (0x10000u * (0xe6e3724bu + (unsigned)(u3 && 0x80000000u))) != 0u;
    c1 = (signed char)(unsigned)((int)(unsigned)((int)u2 < (int)2u) < (int)(*q0 >> (0u & 31u)));
    goto L2;
    do { if (--fuel == 0u) goto done;
        continue; (void)((unsigned)(v0 || i1));
        if (~(unsigned)(u3 == u0)) break;
    } while (i0++ < 4u && (unsigned)(signed char)(u1 / ((unsigned)b0 | 1u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    r0.y ^= (unsigned)(((unsigned)d0 ^ m0) || (a0[u1 & 3u] ^ u3));
    g0 = (unsigned)(short)(6u % (i1 | 1u));
    goto done;
    if (-(unsigned)((int)(unsigned)(unsigned char)(a0[i0 & 3u] - 0x5664986au) < (int)0u)) goto L4;
    while (i0++ < 6u && 2u) { if (--fuel == 0u) goto done;
        if ((unsigned)(u2 && (p1 & 0x67e312bbu))) break;
        l0 = (long)((unsigned long)l0 + (p2 + 8u));
        *q0 = (g1 % (0u | 1u));
        s0 = (int)(v0 % (((unsigned)!(0xaa08f466u / ((unsigned)b0 | 1u)) % (garr[i1 & 7u] | 1u)) | 1u));
        if (((unsigned)h0 ^ (unsigned)((unsigned)c0 || fuel))) break;
        if ((unsigned)((0x1ce806fdu / (0xffffffffu | 1u)) < r0.y)) {
            if ((unsigned)(signed char)((unsigned)(0xffffffffu && (unsigned)s1) >> (5u & 31u))) {
                for (;;) { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        h0 = (short)((unsigned)(w0 >> 29) << ((unsigned)!(u1 % (*mp | 1u)) & 31u));
                        break; (void)(((0xd91bfe7bu + u3) & garr[i1 & 7u]));
                        h1 = (unsigned short)(h1 + ((0x80000000u * (unsigned)c0) >> ((u3 & 0x7fffffffu) & 31u)));
                    }
                    if ((unsigned)((unsigned)c1 || (0x57211eddu - 0xffffffffu))) goto L2;
                    if ((m0 & 0xffffffffu)) goto L2;
                    b0 = (0x9feab812u ? 6u : *q0) != 0u;
                }
            } else {
                switch (((unsigned)h1 + 0x4eb5d0dbu) & 7u) {
                    *mp = (garr[u2 & 7u] % ((unsigned)l0 | 1u));
                    case 7u: ;
                    d0 = d0 * 0.5 + (double)((garr[i1 & 7u] / ((0x10000u << (0x7fffffffu & 31u)) | 1u)) & 1023u);
                    if (budget != 0u) { budget -= 1u; u1 = fn0((garr[u2 & 7u] * u0), ((unsigned)(g1 || (unsigned)(w0 >> 29)) << ((unsigned)l0 & 31u)), garr[i1 & 7u]); }
                    s0 = (int)(unsigned)((int)(unsigned)(w0 >> 29) < (int)(i0 | i1));
                }
                break; (void)((p1 - u3));
            }
            if (((unsigned)w0 * u2)) break;
        }
    }
    m0 ^= (unsigned)((int)(unsigned)(unsigned char)(unsigned)((int)0x4482b510u >= (int)(unsigned)e0) >= (int)0x7fffffffu);
    for (;;) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)w0 & (unsigned)((short)garr[u2 & 7u] > (signed char)u0)));
        { unsigned t0; double z0; if ((8u) & 1u) { t0 = ((0xec514dbcu >> (p2 & 31u)) << ((unsigned)w0 & 31u)); z0 = (double)((((unsigned)((short)0x5fefa082u > (signed char)0xdcf4eccdu) | 0xd367b47au)) & 255u); } if ((8u) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
                if ((unsigned)(0x2f513384u == 9u)) continue;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(g1 % (0xada9765eu | 1u)) < (int)g0), g0, (unsigned)(x0 >> 70)); }
                if ((a0[u1 & 3u] >> ((unsigned)(w0 >> 29) & 31u))) goto L1;
                w0 = w0 * 6364136223846793005ull + ((unsigned)!(unsigned)((short)0x3e292936u > (signed char)(unsigned)x0) % ((unsigned)h1 | 1u));
            }
            r0.x = (6u & (i1 % ((unsigned)((unsigned)w0 && 0x7fffffffu) | 1u)));
        }
        { unsigned t1; double z1; if (((unsigned)((int)(unsigned)(m0 || (unsigned)(x0 >> 70)) >= (int)(unsigned)h0)) & 1u) { t1 = (unsigned)!((unsigned)s0 ? v0 : 0x100d767bu); z1 = (double)((fuel) & 255u); } if (((unsigned)((int)(unsigned)(m0 || (unsigned)(x0 >> 70)) >= (int)(unsigned)h0)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            switch (~(unsigned)((unsigned)(u1 == a0[u1 & 3u]) && (unsigned)h1) & 7u) {
                e0 = e0 * 0.5L + (long double)((garr[u2 & 7u] + i0) & 1023u);
                if (u3 == 7u) return 2u;
                c0 = (unsigned char)*q0;
                if ((unsigned)((int)*q0 >= (int)(unsigned)!(r0.x << (i1 & 31u)))) {
                    u2 ^= 8u;
                    if ((unsigned)s0) break;
                    switch (((unsigned)((int)*q0 < (int)i2) ^ u3) & 7u) {
                        if ((unsigned)c1) break;
                        case 1u: ;
                        if ((unsigned)((short)0x4d1d432u > (signed char)0x3a68ca27u)) {
                            if ((((unsigned)c1 >> (0x7fffffffu & 31u)) + 0x49e76228u)) continue;
                            if (((unsigned)(x0 >> 70) | (p2 & (unsigned)b0))) goto L2;
                            case 7u: ;
                            default: ;
                            h0 = (short)(unsigned)(unsigned char)(unsigned)(g1 || (((unsigned)f0 << (u1 & 31u)) & *q0));
                        }
                    }
                } else {
                    if (budget != 0u) { budget -= 1u; u0 = fn0((r0.x & (p1 * fuel)), 0u, (unsigned)((unsigned)s0 && (unsigned)((int)0xc9dfb52au >= (int)(unsigned)c0))); }
                    L1: if (--fuel == 0u) goto done;
                    case 6u: ;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)((short)8u > (signed char)u1) || 0x39d8ba7du), u1, (unsigned)(0u < g1)); }
                c1 = (signed char)(0x10000u << (i0 & 31u));
            }
            if ((unsigned)((short)(unsigned)((short)i2 > (signed char)p2) > (signed char)*q0)) goto L1;
            L2: if (--fuel == 0u) goto done;
        }
        r0.y ^= (unsigned)(6u || (unsigned)w0);
        if (~(6u / (a0[i0 & 3u] | 1u))) break;
        b0 = ((unsigned)((unsigned)c1 < p1) | p0) != 0u;
    }
    a0[(unsigned)b0 & 3u] = ((unsigned)((int)(unsigned)(0x802e2d42u && 9u) < (int)9u) - i2);
    w0 = w0 * 6364136223846793005ull + (((unsigned)(0xcf1bafb5u == u0) | i1) - (unsigned)((unsigned)(w0 >> 29) || 0x6603da87u));
    if (((unsigned)((unsigned)s0 == 4u) << (r0.y & 31u))) {
        do { if (--fuel == 0u) goto done;
            if ((u2 * (unsigned)(x0 >> 70))) {
                f0 = f0 * 0.5f + (float)((unsigned)(g1 || (2u + (unsigned)(0x3e07218cu < 0x10000u))) & 255u);
                garr[((unsigned)h1 + 0x80000000u) & 7u] = (unsigned)(signed char)(0x80000000u + a0[u1 & 3u]);
                f0 = f0 * 0.5f + (float)((unsigned)((int)i1 >= (int)0x7fffffffu) & 255u);
                while (i1++ < 4u && (unsigned)((unsigned)h1 < r0.y)) { if (--fuel == 0u) goto done;
                    q0 = &garr[(unsigned)((short)0xffffffffu > (signed char)(unsigned)s0) & 7u];
                    if (*q0) {
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)l0, ((0x7fffffffu | r0.y) * (unsigned)h1), 0xffffffffu); }
                        if ((unsigned)d0) break;
                        if (u3 == 7u) return ((unsigned)((i2 ^ (unsigned)((int)(unsigned)c0 >= (int)0x6bc946d7u)) || 7u) / ((unsigned)w0 | 1u));
                        e0 = e0 * 0.5L + (long double)((0xffffffffu | (unsigned)(0x21b3c32du || *mp)) & 1023u);
                        u1 ^= (~(unsigned)(0xc546e6f2u == 7u) - (i2 >> ((fuel / (g1 | 1u)) & 31u)));
                    }
                }
            } else {
                while (i1++ < 2u && g1) { if (--fuel == 0u) goto done;
                    *q0 += -(unsigned)((7u % ((unsigned)(x0 >> 70) | 1u)) == (unsigned)l0);
                    *q0 = (unsigned)(signed char)(unsigned)(0xffffffffu || ((fuel / ((unsigned)l0 | 1u)) ? 2u : (unsigned)s1));
                    w0 ^= (unsigned long long)(unsigned)h1 << ((unsigned)((int)0xf9c81723u >= (int)(unsigned)(x0 >> 70)) & 63u);
                    i0 = (unsigned)(0xffffffffu < ((unsigned)s0 / ((garr[u2 & 7u] << (((unsigned)(x0 >> 70) | 0x81a4au) & 31u)) | 1u))) & 15u;
                    *q0 += u2;
                }
                if ((unsigned)(a0[u1 & 3u] || (unsigned)!(4u % (p2 | 1u)))) break;
                if ((0x80000000u ^ garr[u2 & 7u])) break;
                g1 += (unsigned)(((unsigned)s0 >> ((unsigned)s1 & 31u)) && p2);
            }
            break; (void)((unsigned)(6u == (unsigned)b0));
            u1 ^= (unsigned)((garr[u2 & 7u] | (unsigned)x0) && ((unsigned)c0 - (unsigned)s1));
        } while (i0++ < 4u && (unsigned)d0);
    } else {
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
        }
        if ((unsigned)(u3 && i0)) goto L2;
        f0 = f0 * 0.5f + (float)((unsigned)((int)*q0 >= (int)(unsigned)b0) & 255u);
    }
    b0 = ((unsigned)s1 - (unsigned)((int)r0.x < (int)(unsigned)c1)) != 0u;
    do { if (--fuel == 0u) goto done;
        u0 = (unsigned)(((unsigned)b0 * (v0 % (0x7cf25f34u | 1u))) == v0);
        if (((unsigned)h1 - (unsigned)(r0.x || 0xa59cd54fu))) break;
    } while (i0++ < 3u && (unsigned)l0);
    if ((unsigned)(i1 && u0)) goto L3;
    m0 ^= (unsigned)((int)i2 >= (int)garr[i1 & 7u]);
    L4: if (--fuel == 0u) goto done;
    if ((unsigned)(0x80000000u == i1)) goto L0;
    switch ((unsigned)(m0 && (unsigned)b0) & 7u) {
        case 4u: ;
        if (((unsigned)s0 / (*q0 | 1u))) goto L3;
        w0 = w0 * 6364136223846793005ull + 0x80000000u;
        while (i0++ < 7u && i2) { if (--fuel == 0u) goto done;
            *q0 = ((0xffffffffu ^ r0.y) & a0[i0 & 3u]);
        }
    }
    switch (0x80000000u & 7u) {
        b0 = (i1 % ((unsigned)!(unsigned)(fuel < (unsigned)((unsigned)c1 == 1u)) | 1u)) != 0u;
    }
    g1 += ((unsigned)(signed char)(unsigned)((short)0x467e477au > (signed char)i2) + (0x7fffffffu + a0[i0 & 3u]));
    l0 = (long)((unsigned long)l0 + ((unsigned)((int)r0.y >= (int)p1) >> ((unsigned)w0 & 31u)));
    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s0 << (0xc54e171eu & 31u)), a0[u1 & 3u], (u1 | u3)); }
    if (4u) {
        h0 = (short)(unsigned)((int)(unsigned)((int)(unsigned)(g1 < fuel) < (int)p2) >= (int)p0);
        a0[6u & 3u] = ~(unsigned)(p0 < 0x80000000u);
        u2 = ((5u / ((unsigned)b0 | 1u)) ^ (unsigned)((int)0x1b7230efu < (int)5u));
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x55da628bu < 8u), 6u, (0xffffffffu >> (u1 & 31u))); }
        } while (i0++ < 6u && (9u | r0.y));
        goto L1;
    } else {
        if ((unsigned)((short)r0.y > (signed char)i1)) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)8u >= (int)(unsigned)f0);
        if (3u) goto L2;
    }
    if (((unsigned)f0 / ((a0[u1 & 3u] >> (0x80000000u & 31u)) | 1u))) goto L3;
    if ((unsigned)((int)g1 < (int)garr[i1 & 7u])) goto L2;
    if ((0x7fffffffu & fuel)) {
        h0 = (short)(((unsigned)(x0 >> 70) / (4u | 1u)) - (unsigned)(a0[u1 & 3u] == 0xffffffffu));
        if ((unsigned)(short)((unsigned)e0 ? u0 : (unsigned)l0)) goto L2;
    } else {
        if (budget != 0u) { budget -= 1u; u0 = fn0((garr[u2 & 7u] << (0xf69ec78bu & 31u)), -(unsigned)(p2 || (unsigned)b0), *mp); }
        if (r0.x) {
            i0 = (v0 / ((8u + (unsigned)s1) | 1u)) & 15u;
            u2 = (2u | (unsigned)((unsigned)h0 || u3));
        } else {
            h1 = (unsigned short)(h1 + (unsigned)(g1 || *mp));
            if (0x7fffffffu) goto done;
            if (g1) goto L3;
            if (a0[u1 & 3u]) goto L1;
        }
        goto L2;
    }
    x0 = x0 * 0x100000001b3ull + (9u | (unsigned)d0);
    if (budget != 0u) { budget -= 1u; u3 = fn0(0u, (unsigned)(unsigned char)(unsigned)((unsigned)h1 < 0xffffffffu), (unsigned)((1u % ((unsigned)(x0 >> 70) | 1u)) || *mp)); }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (8u % (0x7fffffffu | 1u));
        if ((unsigned)((unsigned)((int)m0 < (int)4u) && v0)) goto L1;
        if (budget != 0u) { budget -= 1u; u2 = fn0((garr[u2 & 7u] - ((unsigned)l0 + i0)), (unsigned)((int)u2 < (int)(g0 ^ 0xafaf867bu)), (unsigned)l0); }
        goto L3;
    }
    if (0x80000000u) {
        i0 = (((unsigned)c0 / ((unsigned)c0 | 1u)) - (unsigned)((int)0u < (int)0x7c83435bu)) & 15u;
        { unsigned t2; double z2; if (((unsigned)(x0 >> 70)) & 1u) { t2 = (unsigned)((int)0x80000000u < (int)(unsigned)((int)fuel < (int)0xb73d550fu)); z2 = (double)(((unsigned)h1) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            switch (a0[u1 & 3u] & 7u) {
                do { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)((short)(unsigned)f0 > (signed char)0x10000u);
                    if (((unsigned)b0 - i2)) break;
                    s0 = (int)(unsigned)((int)p0 >= (int)(unsigned)((int)(unsigned)s1 < (int)a0[i0 & 3u]));
                    if (fuel < 8u) return u2;
                    if ((unsigned)((a0[i0 & 3u] - p2) < (unsigned)f0)) continue;
                    h1 = (unsigned short)(h1 + (unsigned)((int)i2 >= (int)*q0));
                } while (i0++ < 5u && 0x2cbb1ee1u);
            }
            if (*mp) {
                w0 ^= (unsigned long long)(unsigned)((int)(unsigned)h1 >= (int)0x8d307c2au) << ((unsigned)((i0 + u2) || (unsigned)(short)(unsigned)((int)p2 < (int)0xa3a418bau)) & 63u);
                *q0 += 0xffffffffu;
                c1 = (signed char)-(unsigned)(a0[i0 & 3u] == (unsigned)c1);
            } else {
                switch ((unsigned)w0 & 7u) {
                    if (i0) goto L2;
                }
                *q0 = ((0x80000000u & (unsigned)c1) | (1u ^ u2));
                x0 = x0 * 0x100000001b3ull + ((unsigned)h1 >> ((g1 ^ i2) & 31u));
                if (0x80000000u) {
                    *mp = ((unsigned)!(v0 << (0xffffffffu & 31u)) * (2u << ((u3 ^ (unsigned)s1) & 31u)));
                    while (i0++ < 5u && (unsigned)(a0[i0 & 3u] && *mp)) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(0x102f0edeu, (unsigned)b0, fuel); }
                        { unsigned t3; double z3; if ((~((unsigned)s0 ^ p2)) & 1u) { t3 = (0x81b92f7au >> ((unsigned)((unsigned)l0 && garr[u2 & 7u]) & 31u)); z3 = (double)(((*q0 / (-((unsigned)h1 - (unsigned)d0) | 1u))) & 255u); } if ((~((unsigned)s0 ^ p2)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                            a0[garr[i1 & 7u] & 3u] = (i1 - (v0 ? r0.x : (unsigned)b0));
                            l0 = (long)((unsigned long)l0 + ((unsigned)x0 << ((unsigned)((int)(unsigned)((short)(unsigned)((unsigned)c1 == 0x80000000u) > (signed char)r0.x) >= (int)garr[u2 & 7u]) & 31u)));
                            h0 = (short)(unsigned)((int)u2 < (int)(p0 % (u1 | 1u)));
                            u1 = ((u0 ? u3 : (unsigned)c0) % (0x10000u | 1u));
                            if (((unsigned)h0 % (8u | 1u))) continue;
                        }
                        d0 = d0 * 0.5 + (double)(g0 & 1023u);
                        do { if (--fuel == 0u) goto done;
                            if (-(0x7fffffffu ? 0x80000000u : (unsigned)(w0 >> 29))) break;
                            if (budget != 0u) { budget -= 1u; u3 = fn0(*mp, (((unsigned)w0 ^ (unsigned)x0) + 2u), 6u); }
                        } while (i1++ < 4u && (0xabf27787u ^ (unsigned)!(unsigned)(a0[u1 & 3u] || v0)));
                    }
                }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0x7fffffffu || 3u), (v0 - (unsigned)((short)a0[u1 & 3u] > (signed char)p1)), (7u / (u3 | 1u))); }
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                u2 = u2 * 0x9e3779b1u + (6u / (m0 | 1u));
                do { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(u2 & 0x7c66bf61u) << ((unsigned)!(unsigned)((unsigned)((short)(unsigned)(i0 && (unsigned)h0) > (signed char)i2) == i2) & 63u);
                    if (~(unsigned)((garr[i1 & 7u] << (p2 & 31u)) == 0xffffffffu)) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(a0[i0 & 3u], (p0 % ((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)s0) | 1u)), (unsigned)(0xd79a211bu || 0xffffffffu)); }
                    if (u2) continue;
                    goto L4;
                } while (i1++ < 2u && u0);
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((9u - ~(0x228d9493u | 0x64987329u)), -(8u ? 7u : i2), (unsigned)((int)(unsigned)d0 < (int)(unsigned)h0)); }
                    if ((g1 ^ (unsigned)s0)) break;
                    for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        *q0 = (7u ^ ((unsigned)(0x24989f29u == 0x6d7b56afu) * (m0 % ((unsigned)d0 | 1u))));
                        break; (void)((*q0 >> (8u & 31u)));
                        continue; (void)(((unsigned)s1 & (garr[u2 & 7u] + (unsigned)w0)));
                    }
                    continue; (void)((unsigned)((0xab519e7au << ((unsigned)d0 & 31u)) < 0x61a809d9u));
                }
                u0 = u0 * 0x9e3779b1u + (unsigned)((int)(unsigned)l0 < (int)(unsigned)(unsigned char)((unsigned)w0 / (3u | 1u)));
            }
            r0.x = (9u * 0xffffffffu);
        }
    }
    { unsigned t4; double z4; if (((3u - g1)) & 1u) { t4 = (u3 & ((unsigned)c1 | i2)); z4 = (double)((*mp) & 255u); } if (((3u - g1)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
        q0 = &garr[(unsigned)s1 & 7u];
        if ((g1 << (0x80000000u & 31u))) {
            q0 = &garr[~(unsigned)((int)g1 < (int)(unsigned)(0x7fffffffu && 7u)) & 7u];
            u1 ^= (unsigned)c1;
        } else {
            if ((unsigned)(0u && v0)) {
                if ((unsigned)(unsigned char)(unsigned)(1u == 0u)) goto done;
                u3 ^= (unsigned)w0;
                if (((7u - u0) & r0.y)) {
                    a0[(m0 | 0x10000u) & 3u] = (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)f0));
                    s1 = (int)((unsigned)s1 + (unsigned)(m0 && (unsigned)b0));
                    u2 = (7u ? 0xffffffffu : (unsigned)s1);
                    if ((unsigned)(short)(0x69bf48cau + (unsigned)((short)(unsigned)x0 > (signed char)(unsigned)l0))) goto L2;
                    if (0x80000000u) goto L2;
                    w0 ^= (unsigned long long)u2 << ((unsigned)((int)i2 >= (int)p0) & 63u);
                }
                if ((unsigned)((unsigned)((int)0x5185a015u >= (int)0xb885a96cu) == a0[i0 & 3u])) goto L3;
                { unsigned t5; double z5; if (((unsigned)((unsigned)e0 < fuel)) & 1u) { t5 = (a0[i0 & 3u] ^ (unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)h1)); z5 = (double)(((u3 % ((u0 & (unsigned)c1) | 1u))) & 255u); } if (((unsigned)((unsigned)e0 < fuel)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                    if ((unsigned)(0xffffffffu && i2)) goto L0;
                }
                s1 = (int)((unsigned)s1 + (unsigned)(u0 == 0u));
            } else {
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)!(unsigned)((unsigned)h0 == ((unsigned)c0 ? u1 : 0xf78f1766u)) > (signed char)4u);
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (7u) {
                        if (budget != 0u) { budget -= 1u; u0 = fn0((r0.y / ((*q0 - p2) | 1u)), (unsigned)((int)(8u << (p0 & 31u)) >= (int)p2), (m0 / ((unsigned)(short)(unsigned)((int)0xffffffffu >= (int)(unsigned)d0) | 1u))); }
                        i0 = (unsigned)((int)((unsigned)(x0 >> 70) ? a0[i0 & 3u] : i2) >= (int)(unsigned)h1) & 15u;
                        if (((unsigned)s1 / (((unsigned)c0 / (i1 | 1u)) | 1u))) break;
                        u3 += ((r0.y / (u1 | 1u)) % (0x80000000u | 1u));
                    } else {
                        s0 = (int)((unsigned)(signed char)(0x80000000u & u1) ^ (unsigned)b0);
                        c1 = (signed char)(i1 & (unsigned)((short)i2 > (signed char)8u));
                        m0 ^= v0;
                    }
                    while ((r0.y << ((unsigned)((int)u2 < (int)0x80000000u) & 31u))) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)w0 << ((unsigned)f0 & 31u)), (unsigned)f0, (0xffffffffu & (u2 % ((unsigned)w0 | 1u)))); }
                        d0 = d0 * 0.5 + (double)(((unsigned)(u2 == i0) + (0xe3540be8u % (0x7b28d8f8u | 1u))) & 1023u);
                    }
                    if ((0x80000000u * i0)) break;
                    garr[(fuel + i2) & 7u] = ((unsigned)(unsigned char)(unsigned)(v0 == u0) % (0x3c0e8a28u | 1u));
                    continue; (void)((i1 - r0.x));
                    w0 = w0 * 6364136223846793005ull + ((unsigned)(unsigned char)(5u ? (unsigned)w0 : p0) & u0);
                }
                q0 = &garr[(unsigned)(((unsigned)((unsigned)(x0 >> 70) == 0x10000u) ^ g1) && 0xfb160743u) & 7u];
                h0 = (short)(unsigned)!(v0 & (unsigned)h0);
            }
            goto L2;
        }
        if (0x80000000u) goto L0;
        goto L1;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        b0 = (unsigned)((short)(unsigned)s0 > (signed char)(unsigned)((short)u3 > (signed char)0x80000000u)) != 0u;
        h0 = (short)(unsigned)((g0 ^ g1) < u1);
    }
    goto L1;
    while (i0++ < 6u && (unsigned)(0xffffffffu < ((unsigned)b0 >> (u0 & 31u)))) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)((unsigned)(w0 >> 29) || (unsigned)s1) & p2));
        r0.x = 0x10000u;
        break; (void)((garr[i1 & 7u] ^ (p0 + u0)));
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((u0 >> ((unsigned)w0 & 31u)), *mp, (unsigned)((int)a0[u1 & 3u] >= (int)7u)); }
    u2 = (unsigned)((int)i1 >= (int)p2);
    for (;;) { if (--fuel == 0u) goto done;
        v0 = (unsigned)((short)(unsigned)((unsigned)s1 == (fuel >> (a0[i0 & 3u] & 31u))) > (signed char)(0x47640886u ^ 9u));
        if ((unsigned)((unsigned)((unsigned)c0 && 6u) == m0)) {
            if (m0) {
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)b0 ? (unsigned)w0 : i1)) break;
                }
                if ((unsigned)(7u || (unsigned)w0)) break;
                c1 = (signed char)(4u >> (*q0 & 31u));
                i2 = g0 & 15u;
                if (garr[u2 & 7u]) break;
            } else {
                s0 = (int)(unsigned)(short)(g0 % (5u | 1u));
                u0 = u0 * 0x9e3779b1u + (unsigned)((0x17b2b143u ? r0.x : 0x10000u) && u2);
            }
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((p1 + (unsigned)(short)(unsigned)(0x7fffffffu < g0))) break;
                c1 = (signed char)u3;
            }
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    b0 = ((unsigned)b0 % (((unsigned)(7u == garr[i1 & 7u]) ^ u3) | 1u)) != 0u;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(0xf2f85e48u, g0, (unsigned)(2u && (unsigned)e0)); }
                    if (((0x5f196fa9u * p2) & 0xad5aab53u)) {
                        r0.x = (unsigned)((unsigned)x0 < (unsigned)c0);
                        *mp = (unsigned)((short)(((unsigned)h1 >> (0x2000329au & 31u)) & (v0 ^ *q0)) > (signed char)garr[u2 & 7u]);
                        d0 = d0 * 0.5 + (double)((unsigned)(signed char)(0x10000u * (p2 - u1)) & 1023u);
                    }
                    garr[(unsigned)((unsigned)h0 || g1) & 7u] = ((unsigned)s1 - (unsigned)f0);
                    if ((unsigned)!(unsigned)((short)0xf6ed3375u > (signed char)(0x7fffffffu * 0x38df26f7u))) continue;
                    u3 ^= (unsigned)(((unsigned)!((unsigned)l0 | (unsigned)(short)((unsigned)(x0 >> 70) << (u0 & 31u))) >> (fuel & 31u)) < r0.y);
                }
            }
            h0 = (short)(unsigned)(garr[u2 & 7u] == (~(unsigned)(*mp == *q0) / ((unsigned)h1 | 1u)));
        }
        if ((unsigned)((short)0x80000000u > (signed char)(unsigned)d0)) break;
    }
    if ((r0.y ^ 9u)) goto L0;
    while (i0++ < 6u && (0x8a918d48u >> ((unsigned)((int)(unsigned)x0 < (int)5u) & 31u))) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0(garr[i1 & 7u], (unsigned)((int)8u >= (int)(unsigned)e0), 0xffffffffu); }
        if (-((unsigned)((int)(unsigned)x0 < (int)*q0) | 3u)) break;
        g0 = (p0 / (*q0 | 1u));
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(u3 && ((unsigned)c1 + 8u))) goto L0;
            d0 = d0 * 0.5 + (double)(((unsigned)s0 | (g1 >> ((unsigned)(x0 >> 70) & 31u))) & 1023u);
            break; (void)(7u);
            break; (void)(((unsigned)((int)g1 >= (int)0x10000u) & i1));
            if ((unsigned)((0x24644003u - (unsigned)l0) < p0)) break;
        }
        s1 = (int)((unsigned)s1 + (unsigned)(p0 < (unsigned)!(9u - (unsigned)w0)));
    }
    w0 = w0 * 6364136223846793005ull + ((u3 + p0) - 0xe33dede8u);
    d0 = d0 * 0.5 + (double)(a0[u1 & 3u] & 1023u);
    if ((unsigned)(short)((unsigned)h1 / ((unsigned)(u1 || 0xffffffffu) | 1u))) goto L4;
    { unsigned t6; double z6; if ((*mp) & 1u) { t6 = i2; z6 = (double)(((g0 % ((unsigned)((unsigned)e0 == p1) | 1u))) & 255u); } if ((*mp) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
        x0 = x0 * 0x100000001b3ull + (unsigned)((short)8u > (signed char)((i1 / ((unsigned)h1 | 1u)) << (p0 & 31u)));
        i2 = (unsigned)((short)(unsigned)e0 > (signed char)0x80000000u) & 15u;
    }
    r0.y ^= (unsigned)(*mp && g1);
    v0 = (0x93be1464u >> (u2 & 31u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    x0 = x0 * 0x100000001b3ull + fuel;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)((short)a0[u1 & 3u] > (signed char)((unsigned)w0 % (7u | 1u)));
            if (((unsigned)e0 / (r0.x | 1u))) continue;
            goto L4;
        }
    }
    { unsigned t0; double z0; if (((unsigned)((short)(unsigned)e0 > (signed char)r0.x)) & 1u) { t0 = g0; z0 = (double)((r0.y) & 255u); } if (((unsigned)((short)(unsigned)e0 > (signed char)r0.x)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        if ((unsigned)((short)(unsigned)x0 > (signed char)0xec073835u)) goto L2;
        c0 = (unsigned char)(unsigned)(((fuel | g0) + 0xa9ff1cf9u) < 2u);
    }
    m0 ^= -((unsigned)!((unsigned)s1 / ((unsigned)((int)0xcd1b2fcfu >= (int)0x80000000u) | 1u)) % (u1 | 1u));
    if (0x10000u) goto L3;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1(0x10000u, (3u << ((unsigned)(u3 == g1) & 31u)), ((unsigned)((unsigned)b0 || (unsigned)e0) / ((unsigned)f0 | 1u))); }
        u1 += (unsigned)(short)((unsigned)(signed char)(u0 | (8u * i2)) ^ (6u ^ u0));
        do { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(((unsigned)f0 - (garr[u2 & 7u] / ((unsigned)((unsigned)((int)(unsigned)s0 < (int)0xffffffffu) && 9u) | 1u))) & 1023u);
            for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= (unsigned)((r0.x | (8u >> ((unsigned)h1 & 31u))) == (unsigned)(u1 < r0.y));
                g1 += (unsigned)!(g0 + u3);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)(unsigned)((unsigned)d0 && (unsigned)d0), (unsigned)((unsigned)f0 == 0xffffffffu), (unsigned)b0); }
                q0 = &garr[((*mp ? ((unsigned)(w0 >> 29) + (unsigned)h0) : (unsigned)d0) << ((unsigned)w0 & 31u)) & 7u];
                w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(unsigned)((short)u3 > (signed char)(unsigned)(unsigned char)(unsigned)((short)(unsigned)(0x4519d56u || (unsigned)h0) > (signed char)i1));
                g0 = (-(unsigned)((unsigned)(a0[i0 & 3u] < r0.y) && g0) >> ((unsigned)(w0 >> 29) & 31u));
            }
            break; (void)(0x2ee20982u);
            b0 = (unsigned)((int)~(u2 & 0x10000u) < (int)(unsigned)((int)0x7fffffffu < (int)(unsigned)s0)) != 0u;
            while ((unsigned)((int)u1 >= (int)(unsigned)s0)) { if (--fuel == 0u) goto done;
                if (r0.x) {
                    if (fuel) break;
                    u3 += (unsigned)((int)8u >= (int)p0);
                } else {
                    L0: if (--fuel == 0u) goto done;
                    { unsigned t1; double z1; if ((-(unsigned)(u0 == 0xe5b82c54u)) & 1u) { t1 = ((unsigned)((unsigned)w0 < 0x7fffffffu) << ((unsigned)c0 & 31u)); z1 = (double)((u3) & 255u); } if ((-(unsigned)(u0 == 0xe5b82c54u)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                        if ((unsigned)!(unsigned)((int)u2 >= (int)(unsigned)c1)) break;
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)((short)i2 > (signed char)0x10000u) < (int)i0), 0u, ((unsigned)s0 / (p1 | 1u))); }
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)(unsigned)f0 >= (int)0x80000000u), (unsigned)((int)0x711639e4u >= (int)u0), -(unsigned)((short)0x7fffffffu > (signed char)0x10000u)); }
                    }
                    if (a0[u1 & 3u]) break;
                    break; (void)(((unsigned)x0 - (a0[u1 & 3u] % (1u | 1u))));
                }
                L1: if (--fuel == 0u) goto done;
                L2: if (--fuel == 0u) goto done;
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)0x80000000u << (~(0xdf68a604u / ((unsigned)(u3 || (unsigned)(x0 >> 70)) | 1u)) & 63u);
                    if ((unsigned)(2u && 0xffffffffu)) break;
                    l0 = (long)((unsigned long)l0 + ((unsigned)((int)(i1 | g0) >= (int)g0) >> (0x7fffffffu & 31u)));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)s1, (unsigned)(i2 && (unsigned)(i0 || u1)), 0x7fffffffu); }
                }
                *mp = ((i1 / ((unsigned)c1 | 1u)) % (6u | 1u));
                i0 = (unsigned)((0x80000000u * 0x80000000u) && (unsigned)l0) & 15u;
            }
        } while (i1++ < 4u && (0x7fffffffu - (unsigned)e0));
        *mp = (((i0 & 3u) / ((unsigned)(signed char)(g0 >> (garr[i1 & 7u] & 31u)) | 1u)) - g1);
        L3: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(9u && i2), (*q0 * 0xc27809cfu), ((unsigned)(u1 && r0.y) % (v0 | 1u))); }
    } while (i0++ < 4u && ((unsigned)b0 - garr[i1 & 7u]));
    r0.y ^= (unsigned)(unsigned char)(u2 ? 0x6e142924u : ((u2 / (0xb776c949u | 1u)) ^ 0xffffffffu));
    goto done;
    if ((unsigned)(a0[i0 & 3u] || 8u)) {
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            g1 += (r0.x & 0x10000u);
            if (budget != 0u) { budget -= 1u; u0 = fn1((*q0 | g0), ((unsigned)((short)i2 > (signed char)(unsigned)s1) + r0.x), (unsigned)(g0 < (i2 - 0x80000000u))); }
        }
        switch ((unsigned)((unsigned)h0 && (unsigned)(signed char)(unsigned)((short)p1 > (signed char)a0[u1 & 3u])) & 7u) {
            goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((u1 * (unsigned)((int)m0 < (int)(unsigned)e0)), p0, (unsigned)((int)8u >= (int)(unsigned)((unsigned)(w0 >> 29) && g1))); }
        }
    } else {
        { unsigned t2; double z2; if (((4u ^ i1)) & 1u) { t2 = (((unsigned)h0 ^ (unsigned)h0) - u3); z2 = (double)(((*q0 + (unsigned)l0)) & 255u); } if (((4u ^ i1)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            h1 = (unsigned short)(h1 + ((u2 << (2u & 31u)) / ((unsigned)(short)(0xa159d792u - 0x29f6f9b1u) | 1u)));
            goto L2;
        }
        r0.y ^= (unsigned)((int)6u >= (int)(unsigned)b0);
        { unsigned t3; double z3; if (((r0.x * (unsigned)c0)) & 1u) { t3 = p1; z3 = (double)((((unsigned)(x0 >> 70) + (u0 - (unsigned)f0))) & 255u); } if (((r0.x * (unsigned)c0)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            if (u3 == 7u) return ((v0 ? 0xffffffffu : r0.y) >> (0xe8174e40u & 31u));
        }
    }
    goto L3;
    if (r0.y) goto L4;
    L4: if (--fuel == 0u) goto done;
    g1 += 5u;
    do { if (--fuel == 0u) goto done;
        i1 = 5u & 15u;
        { unsigned t4; double z4; if ((((unsigned)(0x7fffffffu < (unsigned)f0) - 1u)) & 1u) { t4 = (unsigned)((unsigned)c1 || (unsigned)(short)((unsigned)e0 >> ((unsigned)x0 & 31u))); z4 = (double)(((2u * (unsigned)h1)) & 255u); } if ((((unsigned)(0x7fffffffu < (unsigned)f0) - 1u)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            switch ((unsigned)(x0 >> 70) & 7u) {
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((0xe8b96d56u - (unsigned)((unsigned)s0 < 0xffffffffu))) {
                        h1 = (unsigned short)(h1 + ((unsigned)((g1 >> (0x80713370u & 31u)) < (fuel >> (0x7fffffffu & 31u))) & (unsigned)h0));
                        g1 += (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)((unsigned)s0 || (unsigned)h1));
                    } else {
                        c1 = (signed char)(unsigned)(0x535aee04u == (unsigned)(a0[u1 & 3u] == (unsigned)((int)(unsigned)s0 < (int)(unsigned)l0)));
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0(p1, (g0 * (v0 & 0u)), r0.y); }
                    c1 = (signed char)((unsigned)s1 ^ (unsigned)((int)-(unsigned)((short)fuel > (signed char)m0) < (int)a0[u1 & 3u]));
                }
                while (i1++ < 6u && (unsigned)((short)m0 > (signed char)(unsigned)((unsigned)(x0 >> 70) < v0))) { if (--fuel == 0u) goto done;
                    if ((unsigned)x0) {
                        v0 = (unsigned)((int)u2 >= (int)(unsigned)d0);
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)!((unsigned)(unsigned char)(unsigned)(0xab3b824cu || (unsigned)s0) << ((unsigned)(x0 >> 70) & 31u)), 0x7fffffffu, (~((unsigned)x0 - *q0) | garr[i1 & 7u])); }
                        for (;;) { if (--fuel == 0u) goto done;
                            case 2u: ;
                            if ((r0.x - (unsigned)(signed char)(unsigned)((short)*q0 > (signed char)(unsigned)d0))) continue;
                            case 5u: ;
                            case 6u: ;
                            case 4u: ;
                        }
                        m0 ^= 0u;
                    } else {
                        if ((unsigned)((v0 << (0x10000u & 31u)) < garr[u2 & 7u])) goto L3;
                        d0 = d0 * 0.5 + (double)((unsigned)((short)(garr[u2 & 7u] & (unsigned)((short)g0 > (signed char)0xd17789b5u)) > (signed char)(m0 + i1)) & 1023u);
                        x0 = x0 * 0x100000001b3ull + (~(unsigned)((int)p1 >= (int)8u) % (i1 | 1u));
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn0((0x7cf49b31u - a0[u1 & 3u]), (unsigned)d0, (unsigned)((unsigned)((int)(unsigned)b0 < (int)p0) == 0xffffffffu)); }
                    goto L1;
                    break; (void)((unsigned)d0);
                    { unsigned t5; double z5; if ((0x80000000u) & 1u) { t5 = (unsigned)(signed char)((unsigned)s1 % ((0x10000u >> (i1 & 31u)) | 1u)); z5 = (double)(((0x10000u ? r0.x : 0xffffffffu)) & 255u); } if ((0x80000000u) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                        break; (void)((unsigned)((int)*q0 < (int)8u));
                        s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)((unsigned)l0 * 7u));
                        if (budget != 0u) { budget -= 1u; u0 = fn1((0x25f1f0afu << ((unsigned)c0 & 31u)), (unsigned)((unsigned)h0 || (unsigned)h0), (unsigned)l0); }
                    }
                    *q0 += (unsigned)b0;
                }
                *q0 += (unsigned)w0;
                if (budget != 0u) { budget -= 1u; u1 = fn1(4u, (unsigned)(short)(unsigned)(v0 < 0x18935cfdu), (unsigned)(0x7fffffffu == (unsigned)((short)r0.x > (signed char)(unsigned)h1))); }
                default: ;
                if (u3) continue;
            }
            v0 = (0xffffffffu >> ((0x7fffffffu ^ ~(r0.x | g1)) & 31u));
            if (budget != 0u) { budget -= 1u; u3 = fn1(g1, 2u, 5u); }
            if ((unsigned)(1u < (unsigned)((int)0x7a802d0au < (int)m0))) break;
            u0 ^= ((unsigned)(signed char)(0xe834a414u << ((unsigned)((unsigned)(0xef92a04fu < (unsigned)c0) && (unsigned)l0) & 31u)) * r0.y);
            if (((unsigned)((short)0x63136f41u > (signed char)i2) + (unsigned)x0)) break;
        }
        { unsigned t6; double z6; if (((unsigned)((int)(unsigned)x0 >= (int)7u)) & 1u) { t6 = 0xffffffffu; z6 = (double)(((unsigned)((0xffffffffu + u3) == (unsigned)w0)) & 255u); } if (((unsigned)((int)(unsigned)x0 >= (int)7u)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
            break; (void)((unsigned)(unsigned char)(unsigned)((unsigned)c0 == 0xffffffffu));
            u0 += 0x82deaa09u;
            d0 = d0 * 0.5 + (double)(((unsigned)((int)7u < (int)(unsigned)((unsigned)((int)(unsigned)h1 >= (int)2u) < 0u)) * (unsigned)(w0 >> 29)) & 1023u);
            h0 = (short)~((p2 % (fuel | 1u)) * (unsigned)((int)3u >= (int)0xac01b029u));
            if (-((unsigned)c0 ^ (unsigned)e0)) {
                continue; (void)((unsigned)(signed char)(unsigned)((short)(unsigned)s1 > (signed char)u2));
                if (u3 == 7u) return (unsigned)(signed char)(0x80000000u - 0xd3d822bfu);
                u3 += (unsigned)(4u == (unsigned)(w0 >> 29));
                u2 = u2 * 0x9e3779b1u + (unsigned)(short)(v0 * ((r0.x ^ (unsigned)c0) >> ((0u % ((unsigned)x0 | 1u)) & 31u)));
                break; (void)(((garr[u2 & 7u] | r0.x) % ((unsigned)w0 | 1u)));
            } else {
                r0.x = (unsigned)(((unsigned)((unsigned)((int)(unsigned)b0 >= (int)(unsigned)s1) < (unsigned)w0) & (unsigned)f0) == 2u);
                if (0x6e2639fdu) continue;
                if ((unsigned)((unsigned)h1 || 1u)) break;
            }
            switch ((r0.x << ((unsigned)((int)0xd6542394u < (int)u3) & 31u)) & 7u) {
                case 1u: ;
                do { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((1u - i0) & 1023u);
                    g1 += (unsigned)((unsigned)(0xbd0153bu || p1) || 0xdb17bffau);
                    *q0 = (unsigned)((unsigned)((int)i1 >= (int)0xa8abda64u) < m0);
                    case 5u: ;
                } while (i1++ < 3u && (unsigned)((int)1u < (int)(unsigned)((int)*mp >= (int)0x10000u)));
                goto L2;
                if ((unsigned)((int)((unsigned)s0 % (u2 | 1u)) < (int)(unsigned)d0)) goto L0;
                *q0 += (unsigned)((int)(unsigned)x0 >= (int)(unsigned)((int)(unsigned)(i1 < r0.y) < (int)fuel));
                h0 = (short)(unsigned)l0;
            }
        }
        if (v0) {
            if (-((unsigned)((int)(unsigned)c0 >= (int)u2) >> ((unsigned)f0 & 31u))) break;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)(unsigned)((short)u3 > (signed char)(unsigned)((int)(unsigned)(x0 >> 70) < (int)i1)), (unsigned)((int)(unsigned)((int)(unsigned)h1 >= (int)(unsigned)c1) >= (int)fuel), (a0[i0 & 3u] ^ (unsigned)(0x80000000u || i2))); }
            if (budget != 0u) { budget -= 1u; u0 = fn1(u1, (0x10000u & (i1 ^ g0)), (unsigned)(x0 >> 70)); }
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)f0, g1, (0x8d1d7decu & u0)); }
            w0 = w0 * 6364136223846793005ull + (((unsigned)s1 << ((unsigned)(unsigned char)(m0 ^ (unsigned)d0) & 31u)) * r0.y);
        }
    } while (i0++ < 3u && ((r0.x & a0[i0 & 3u]) << (v0 & 31u)));
    { unsigned t7; double z7; if ((((unsigned)b0 << (m0 & 31u))) & 1u) { t7 = ((unsigned)d0 | (unsigned)((short)(unsigned)f0 > (signed char)garr[u2 & 7u])); z7 = (double)(((unsigned)s0) & 255u); } if ((((unsigned)b0 << (m0 & 31u))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
        q0 = &garr[(0xfde06150u - (unsigned)s1) & 7u];
        r0.y ^= *q0;
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1((g0 << ((0xaf37c6bcu >> ((unsigned)w0 & 31u)) & 31u)), (unsigned)((int)p2 >= (int)u2), ((0xcec3e442u ^ g1) << (0x5f49132cu & 31u))); }
            switch ((unsigned)((int)garr[u2 & 7u] >= (int)g1) & 7u) {
                case 6u: ;
                m0 ^= (unsigned)((unsigned)((int)fuel < (int)(5u << ((unsigned)e0 & 31u))) || ((unsigned)e0 << (p0 & 31u)));
                default: ;
            }
            switch ((unsigned)(i0 || (m0 + p1)) & 7u) {
                if (u3 == 7u) return (unsigned)((short)0x625ff09cu > (signed char)p1);
                s0 = (int)(unsigned)(unsigned char)(unsigned)((int)r0.y >= (int)0x7fffffffu);
                w0 = w0 * 6364136223846793005ull + ((unsigned)((short)(unsigned)s0 > (signed char)0x5079b631u) % ((unsigned)(g1 && ((unsigned)x0 / ((unsigned)l0 | 1u))) | 1u));
                *q0 = ((unsigned)!(unsigned)((unsigned)x0 == (unsigned)(short)(unsigned)((unsigned)((unsigned)s0 < 0xffffffffu) == 8u)) / (r0.y | 1u));
                case 7u: ;
                s1 = (int)((unsigned)s1 + (unsigned)x0);
            }
            g0 = (m0 >> (p2 & 31u));
            i1 = (u1 - (0xcdfa0ecu ^ i1)) & 15u;
            if ((unsigned)((unsigned)(x0 >> 70) < (unsigned)(g0 || u0))) break;
        }
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)(m0 && (p1 ^ r0.x));
    w0 = w0 * 6364136223846793005ull + i2;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = (unsigned)((unsigned)(a0[u1 & 3u] || 1u) || (unsigned)(1u == u3));
        { unsigned t8; double z8; if (((unsigned)(0x7fffffffu || 7u)) & 1u) { t8 = 4u; z8 = (double)((u3) & 255u); } if (((unsigned)(0x7fffffffu || 7u)) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
            if (budget != 0u) { budget -= 1u; u2 = fn0(7u, (r0.x ^ m0), 0xffffffffu); }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return i1;
                if ((unsigned)((int)(unsigned)!(i1 & (unsigned)s1) < (int)0u)) break;
                x0 = x0 * 0x100000001b3ull + 8u;
                s1 = (int)((unsigned)s1 + u0);
                continue; (void)((unsigned)(short)(unsigned)(p1 || u3));
                v0 = (unsigned)((short)9u > (signed char)((g1 >> (6u & 31u)) - r0.y));
            }
            if ((unsigned)d0) continue;
            { unsigned t9; double z9; if ((p2) & 1u) { t9 = (a0[i0 & 3u] - (unsigned)(i0 == m0)); z9 = (double)(((unsigned)((short)9u > (signed char)u3)) & 255u); } if ((p2) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                v0 = (((unsigned)(g0 || (unsigned)d0) + garr[u2 & 7u]) / (0x80000000u | 1u));
                if ((unsigned)(r0.y && 0xc11e1366u)) goto L2;
                { unsigned t10; double z10; if ((0x10000u) & 1u) { t10 = v0; z10 = (double)((1u) & 255u); } if ((0x10000u) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)s0) break;
                        { unsigned t11; double z11; if (((0x80000000u ^ (0xffc6fdb4u << (garr[u2 & 7u] & 31u)))) & 1u) { t11 = (unsigned)((unsigned)e0 == *mp); z11 = (double)(((unsigned)((int)(unsigned)s0 >= (int)(unsigned)(p1 || 0x7fffffffu))) & 255u); } if (((0x80000000u ^ (0xffc6fdb4u << (garr[u2 & 7u] & 31u)))) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)i1 < (int)0x67aa1feau), (unsigned)b0, (unsigned)h1); }
                        }
                        if ((0xa33ba9acu + 0x10000u)) continue;
                        u0 ^= (5u / ((p1 & p1) | 1u));
                        s0 = (int)((unsigned)x0 | g0);
                        if ((unsigned)(u3 || 0x273475efu)) break;
                    }
                    w0 = w0 * 6364136223846793005ull + (unsigned)(short)(u1 * (unsigned)((int)p0 < (int)u3));
                    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)s1 - 3u), ((unsigned)c0 / ((unsigned)s1 | 1u)), ((unsigned)e0 | (r0.y + (unsigned)h0))); }
                }
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((unsigned)((short)((unsigned)c1 & (i1 | (unsigned)w0)) > (signed char)(unsigned)s1) & 255u);
                    if (-(unsigned)(p2 < (unsigned)b0)) break;
                    if ((0x7fffffffu - (unsigned)w0)) break;
                    u0 ^= ((unsigned)((int)i2 < (int)(unsigned)l0) * (p0 ^ u0));
                    c1 = (signed char)(7u ? 0x10000u : (unsigned)(unsigned char)(unsigned)((short)(unsigned)h0 > (signed char)(unsigned)(w0 >> 29)));
                }
            }
        }
        g1 += (p2 << ((unsigned)c0 & 31u));
        u0 = (unsigned)h0;
        if (u3 == 7u) return (unsigned)(*mp && ((unsigned)w0 ? (unsigned)((int)3u < (int)(unsigned)h1) : (unsigned)h1));
        if ((unsigned)(u2 == (unsigned)e0)) break;
    }
    w0 ^= (unsigned long long)u1 << (-((unsigned)x0 + (fuel | a0[i0 & 3u])) & 63u);
    b0 = (unsigned)((short)(unsigned)(short)(*mp >> (r0.y & 31u)) > (signed char)(unsigned)((unsigned)e0 == (unsigned)(r0.y == r0.y))) != 0u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(g0 || (unsigned)f0)) {
        g0 = (unsigned)((garr[u2 & 7u] << (g1 & 31u)) < u0);
        q0 = &garr[(unsigned)(p2 < 5u) & 7u];
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(r0.x < r0.x), (unsigned)((short)(unsigned)x0 > (signed char)u2), (0xc24c72d4u << ((unsigned)h0 & 31u))); }
        *q0 = (unsigned)(unsigned char)((unsigned)(i0 == ~(unsigned)((short)(unsigned)b0 > (signed char)v0)) / ((unsigned)s1 | 1u));
        c1 = (signed char)(unsigned)(0x8ae1a4dau || 9u);
    }
    switch ((unsigned)(a0[i0 & 3u] == 9u) & 7u) {
        case 5u: ;
        L0: if (--fuel == 0u) goto done;
        b0 = (unsigned)(0x80000000u < ((unsigned)((i1 ^ r0.x) == r0.x) - (unsigned)(w0 >> 29))) != 0u;
        if (((unsigned)f0 / (g0 | 1u))) {
            u1 = (unsigned)(0x80000000u && i2);
        } else {
            r0.y ^= (unsigned)((unsigned)(unsigned char)(u0 % ((unsigned)((short)v0 > (signed char)(unsigned)c1) | 1u)) || (unsigned)b0);
            for (;;) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (i1 ? garr[u2 & 7u] : i1));
                default: ;
                if ((unsigned)(signed char)(unsigned)((short)i1 > (signed char)0xce2c9936u)) goto L4;
                case 2u: ;
            }
            case 3u: ;
        }
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(~(unsigned)((unsigned)(signed char)(u1 / (g0 | 1u)) < (unsigned)(x0 >> 70)));
            c0 = (unsigned char)0xf315beceu;
            u0 ^= (~((unsigned)l0 >> (m0 & 31u)) >> (8u & 31u));
            L1: if (--fuel == 0u) goto done;
            if (7u) {
                if ((unsigned)((int)0x6033284cu >= (int)fuel)) {
                    h0 = (short)((unsigned)(unsigned char)(unsigned)(u1 && (unsigned)e0) & ((3u / ((unsigned)(x0 >> 70) | 1u)) >> (0x10000u & 31u)));
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)f0, ((unsigned)h0 ? a0[u1 & 3u] : p2), -((unsigned)w0 - *q0)); }
                } else {
                    v0 = 3u;
                    i1 = (r0.x + (i1 ^ (5u ^ 8u))) & 15u;
                    *mp = (a0[u1 & 3u] ? (unsigned)((int)(unsigned)l0 < (int)4u) : (unsigned)((int)(unsigned)c1 >= (int)0xe18f2e2au));
                    m0 ^= (unsigned)s0;
                }
                l0 = (long)((unsigned long)l0 + a0[i0 & 3u]);
                L2: if (--fuel == 0u) goto done;
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((-(0xbcd20f14u / (r0.y | 1u)) + 0xa56ea861u), 0x4d303813u, (unsigned)!(u1 ? 9u : garr[u2 & 7u])); }
    if (v0) {
        for (;;) { if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if (((9u & 0x2c45b4adu)) & 1u) { t0 = 0x80000000u; z0 = (double)(((a0[u1 & 3u] - p1)) & 255u); } if (((9u & 0x2c45b4adu)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                if ((i2 << ((unsigned)s0 & 31u))) goto L1;
                L3: if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(p2 || ((unsigned)b0 * p0)), (unsigned)((short)(unsigned)x0 > (signed char)(0xffffffffu | (unsigned)c1)), (unsigned)((int)*mp < (int)4u)); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((0xbaad043au + ((unsigned)x0 * (unsigned)l0)), 0xa4eed9e0u, ((unsigned)(g0 == (unsigned)c0) << (0x10000u & 31u))); }
                } while (i1++ < 5u && (unsigned)((unsigned)((short)0x10000u > (signed char)v0) || 0x10000u));
            }
        }
        s0 = (int)i1;
        l0 = (long)((unsigned long)l0 + 0x80000000u);
        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)f0 / (9u | 1u)), (unsigned)(0xffffffffu && (unsigned)(0x80000000u < (unsigned)l0)), (unsigned)((int)r0.y < (int)0xf03d8764u)); }
        if ((0u | i0)) goto L1;
    }
    if ((unsigned)(0x5bfbc560u && a0[i0 & 3u])) goto L3;
    u1 = u1 * 0x9e3779b1u + ((((unsigned)c0 / (*mp | 1u)) + (unsigned)d0) - (unsigned)(unsigned char)(unsigned)((short)p1 > (signed char)p0));
    if (-(unsigned)((unsigned)!(u2 + 0x80000000u) < 0x80000000u)) {
        { unsigned t1; double z1; if (((unsigned)s0) & 1u) { t1 = ((garr[u2 & 7u] * (unsigned)(x0 >> 70)) - u2); z1 = (double)((((unsigned)((int)0xb159b17fu < (int)(unsigned)w0) * (unsigned)s0)) & 255u); } if (((unsigned)s0) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            e0 = e0 * 0.5L + (long double)(((unsigned)((unsigned)(garr[u2 & 7u] < g0) == a0[u1 & 3u]) ^ fuel) & 1023u);
            switch (v0 & 7u) {
                if ((unsigned)s1) goto L4;
                u1 += (unsigned)(unsigned char)(unsigned)(5u || 0xffffffffu);
                *q0 += (unsigned)((unsigned)(unsigned char)((unsigned)(short)(unsigned)(u2 == 0x60c55824u) + (unsigned)(w0 >> 29)) == (unsigned)w0);
                case 4u: ;
                g0 = (p0 ^ (unsigned)((unsigned)f0 && u0));
            }
            if ((unsigned)((int)0x52afb4d1u >= (int)(unsigned)!((unsigned)h1 ^ 0x80000000u))) goto L2;
        }
        if ((unsigned)h1) goto L3;
        a0[(unsigned)((int)3u >= (int)0x7fffffffu) & 3u] = (unsigned)(((unsigned)(x0 >> 70) / (0x345d7f2fu | 1u)) || (unsigned)((unsigned)h0 < 5u));
        if (budget != 0u) { budget -= 1u; u1 = fn1(a0[i0 & 3u], (unsigned)((short)7u > (signed char)0x10000u), (unsigned)((int)(unsigned)w0 < (int)(i2 & r0.x))); }
        s0 = (int)(unsigned)((*q0 | r0.y) < (0xa69d6823u << (i1 & 31u)));
        h1 = (unsigned short)(h1 + ~(unsigned)((short)((unsigned)c0 * (unsigned)h0) > (signed char)(garr[i1 & 7u] | g1)));
    } else {
        for (;;) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(short)(0x6c2ba7b4u << (((unsigned)c1 % (0x30e7d9c8u | 1u)) & 31u))) break;
                while (i2++ < 2u && (unsigned)e0) { if (--fuel == 0u) goto done;
                    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        u3 ^= ((unsigned)x0 & (unsigned)((int)0x7fffffffu >= (int)p1));
                        u1 = (unsigned)((int)((*mp ^ u1) >> ((unsigned)(x0 >> 70) & 31u)) < (int)u3);
                    }
                    break; (void)((a0[u1 & 3u] - (unsigned)((int)(unsigned)s0 < (int)(unsigned)s1)));
                    if ((unsigned)((unsigned)((unsigned)b0 == (unsigned)c0) == (unsigned)s0)) break;
                    *q0 = garr[u2 & 7u];
                    if ((unsigned)((int)3u >= (int)(unsigned)c0)) break;
                    while (i0++ < 2u && 0xf65a6fa0u) { if (--fuel == 0u) goto done;
                        if (i1) break;
                        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn0(p0, u0, g0); }
                            if (~((unsigned)w0 + a0[u1 & 3u])) goto L3;
                            g1 += a0[i0 & 3u];
                        }
                        goto done;
                        if ((i2 % (0x80000000u | 1u))) continue;
                        if ((unsigned)h0) goto L0;
                    }
                }
            } while (i1++ < 4u && (p0 >> (r0.x & 31u)));
            if ((garr[u2 & 7u] ^ (r0.x * fuel))) {
                u0 ^= (0x10000u % (u0 | 1u));
                c1 = (signed char)((unsigned)e0 * (unsigned)s1);
                s0 = (int)(unsigned)(((a0[u1 & 3u] - (unsigned)s0) | 0x10000u) || (unsigned)((short)p1 > (signed char)0x5fe22831u));
            } else {
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)d0, 3u, (unsigned)(0x10000u && (0xc45b8b29u | g1))); }
                if ((p0 >> (((unsigned)x0 - r0.y) & 31u))) break;
                if (budget != 0u) { budget -= 1u; u2 = fn2(6u, g1, (unsigned)((unsigned)x0 && (unsigned)(g0 || (unsigned)b0))); }
                if (u3) break;
            }
            if (((unsigned)x0 | (unsigned)((int)i2 >= (int)i1))) break;
        }
    }
    c0 = (unsigned char)((0x62d1437du % (((unsigned)((int)(unsigned)s0 < (int)u3) - fuel) | 1u)) - (unsigned)s1);
    if ((0u * ((unsigned)b0 / (p1 | 1u)))) goto L4;
    *q0 += 0x2d738e8eu;
    if (0xc9dde93au) goto L1;
    if ((unsigned)h0) goto done;
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)g1 < (int)g0);
    switch ((unsigned)h0 & 7u) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)a0[u1 & 3u] < (int)p2), (0x7fffffffu ^ 0x426c447du), (-(0x2d7c25acu - r0.y) + (unsigned)l0)); }
        }
        goto L3;
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 0u: ;
            { unsigned t2; double z2; if ((u2) & 1u) { t2 = (unsigned)((short)garr[u2 & 7u] > (signed char)u3); z2 = (double)((u0) & 255u); } if ((u2) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                if ((unsigned)((short)r0.x > (signed char)0xffffffffu)) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)r0.x > (signed char)u0), u3, (unsigned)s1); }
                if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)w0 << (garr[u2 & 7u] & 31u)), ((unsigned)((int)(unsigned)e0 < (int)0x80000000u) | r0.y), ((9u + v0) - 0xffffffffu)); }
                break; (void)((unsigned)h1);
                if (0xccda34a7u) continue;
                if (budget != 0u) { budget -= 1u; u1 = fn1((0x7ebe0a1eu ^ (unsigned)(w0 >> 29)), (garr[u2 & 7u] | (unsigned)h1), ((a0[i0 & 3u] << (i1 & 31u)) | i0)); }
            }
        }
        d0 = d0 * 0.5 + (double)((unsigned)(g0 && 9u) & 1023u);
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 2u: ;
            if (fuel < 8u) return ((unsigned)c1 ? 0xabf867cdu : 0x80000000u);
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 6u: ;
            while (i1++ < 4u && (unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
                if ((unsigned)(unsigned char)(unsigned)((unsigned)((int)(unsigned)x0 < (int)garr[u2 & 7u]) < g1)) {
                    if (((unsigned)(0xe1ae57fdu == (unsigned)(x0 >> 70)) << (*q0 & 31u))) continue;
                } else {
                    for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        case 5u: ;
                        switch ((unsigned)!(g0 << ((unsigned)h0 & 31u)) & 7u) {
                            if ((*q0 - *q0)) goto L3;
                            *q0 += (unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)(w0 >> 29));
                            w0 ^= (unsigned long long)(unsigned)(signed char)((unsigned)d0 * *q0) << ((0x80000000u - ~(unsigned)(0x57d17780u < (garr[i1 & 7u] - 1u))) & 63u);
                            w0 = w0 * 6364136223846793005ull + 3u;
                            d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)x0 >= (int)m0) & 1023u);
                            q0 = &garr[(unsigned)((short)(g0 & *mp) > (signed char)(unsigned)h0) & 7u];
                        }
                    }
                    *q0 = (unsigned)(u2 || a0[i0 & 3u]);
                    goto L3;
                }
                u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)((int)(unsigned)d0 >= (int)0xd61a6664u) || (unsigned)(p2 < 0x393926ffu));
            }
            e0 = e0 * 0.5L + (long double)(-(unsigned)(0xffffffffu && (unsigned)((short)(unsigned)(p1 < (unsigned)(w0 >> 29)) > (signed char)((unsigned)h0 & p1))) & 1023u);
            default: ;
            g0 = (garr[i1 & 7u] >> (0x80000000u & 31u));
        }
    }
    goto L0;
    f0 = f0 * 0.5f + (float)(*q0 & 255u);
    goto L0;
    if (0x5d666b94u) goto done;
    if ((unsigned)((short)(unsigned)(u0 || (unsigned)c1) > (signed char)(unsigned)c1)) goto L2;
    u2 += (0x7c217fa1u * (unsigned)((short)(8u % (garr[i1 & 7u] | 1u)) > (signed char)u2));
    if ((garr[u2 & 7u] - 0xebbbe5afu)) goto L4;
    a0[fuel & 3u] = 0x8d30d98au;
    if ((unsigned)s1) goto L1;
    if (((unsigned)f0 + (unsigned)((unsigned)d0 == (unsigned)c1))) {
        { unsigned t3; double z3; if ((-(unsigned)((unsigned)c1 || 0xb9f3315bu)) & 1u) { t3 = (u2 / (0x753c9679u | 1u)); z3 = (double)(((unsigned)((int)*mp < (int)a0[i0 & 3u])) & 255u); } if ((-(unsigned)((unsigned)c1 || 0xb9f3315bu)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((int)m0 >= (int)(0x16622cb4u % (u1 | 1u))) == 0xf6967cfcu) & 1023u);
            while (i0++ < 7u && (unsigned)(garr[u2 & 7u] && m0)) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + ((((unsigned)e0 % (a0[i0 & 3u] | 1u)) << (fuel & 31u)) & (0x7fffffffu - 0xe93cbca4u)));
                if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(short)(v0 & (unsigned)f0) ^ (unsigned)c1), (unsigned)((p2 * 0x5edbbfabu) || garr[u2 & 7u]), (unsigned)((short)g1 > (signed char)0xffffffffu)); }
                break; (void)(m0);
            }
            if (budget != 0u) { budget -= 1u; u0 = fn2((r0.x / (u0 | 1u)), (0x80000000u * ((unsigned)(x0 >> 70) + (unsigned)s0)), ((unsigned)((short)a0[i0 & 3u] > (signed char)*q0) - 0xffffffffu)); }
        }
        w0 ^= (unsigned long long)(a0[u1 & 3u] | 3u) << ((unsigned)((int)(0xffffffffu & (0xffffffffu - (unsigned)s1)) < (int)(unsigned)h0) & 63u);
        v0 = (unsigned)((int)((unsigned)f0 ^ 0x80000000u) >= (int)((unsigned)(x0 >> 70) % ((garr[u2 & 7u] ^ (unsigned)w0) | 1u)));
        if (garr[u2 & 7u]) goto L3;
    }
    goto L2;
    i1 = (a0[i0 & 3u] + 0x7fffffffu) & 15u;
    *q0 += (unsigned)((*mp ^ 8u) < (4u * (a0[u1 & 3u] + u2)));
    u3 += 0xb114f8u;
    q0 = &garr[(g1 * (p1 >> (a0[i0 & 3u] & 31u))) & 7u];
    g0 = (unsigned)((int)~(((unsigned)h0 << (0x10000u & 31u)) - (unsigned)((unsigned)x0 < 0xf236bd99u)) >= (int)0x7fffffffu);
    a0[((unsigned)c1 + garr[u2 & 7u]) & 3u] = ((*q0 & 0x62cd34eeu) ^ (unsigned)((unsigned)d0 == r0.x));
    if (budget != 0u) { budget -= 1u; u0 = fn0(1u, (unsigned)(0xffffffffu || (unsigned)(w0 >> 29)), (garr[u2 & 7u] | (unsigned)x0)); }
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(g1 && (unsigned)c0), g0, (unsigned)((int)(unsigned)(g1 == (unsigned)l0) < (int)p0)); }
    d0 = d0 * 0.5 + (double)((unsigned)(g1 || p0) & 1023u);
    goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn0(((r0.y % ((unsigned)w0 | 1u)) << (0xd15213f8u & 31u)), i1, (unsigned)(short)((unsigned)(unsigned char)((unsigned)d0 + 4u) | 0xffffffffu)); }
    f0 = f0 * 0.5f + (float)((unsigned)((int)i0 < (int)m0) & 255u);
    do { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + r0.x;
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            u1 ^= ((unsigned)c1 << ((0xc8300260u ? *mp : 7u) & 31u));
            garr[0xffffffffu & 7u] = (unsigned)((short)((unsigned)c1 ^ ((unsigned)((unsigned)b0 || u1) * 3u)) > (signed char)0x7527f4aeu);
            break; (void)((*mp + (unsigned)x0));
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                u1 = 0x7fffffffu;
            }
            if ((unsigned)l0) break;
        }
        g0 = (5u - 4u);
        if (((unsigned)((short)0x26832ef9u > (signed char)u0) % (0x9a703843u | 1u))) goto L4;
    } while (i0++ < 2u && -(2u >> ((unsigned)((short)0xeac7824bu > (signed char)(unsigned)s1) & 31u)));
    if (((v0 / (9u | 1u)) / (*mp | 1u))) {
        m0 ^= ((*q0 / (1u | 1u)) >> (garr[u2 & 7u] & 31u));
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn2(-(0x10000u ^ (unsigned)(u0 && 0x71c6b91du)), r0.y, (unsigned)(short)((unsigned)d0 ^ (unsigned)(w0 >> 29))); }
        }
    }
    goto L3;
    if (i0) goto L0;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t4; double z4; if ((((unsigned)!(unsigned)(a0[i0 & 3u] && i1) % (5u | 1u))) & 1u) { t4 = (g0 % (7u | 1u)); z4 = (double)(((garr[i1 & 7u] - r0.x)) & 255u); } if ((((unsigned)!(unsigned)(a0[i0 & 3u] && i1) % (5u | 1u))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
            if ((unsigned)((int)(unsigned)s1 < (int)0xb8f6796au)) {
                u2 = (unsigned)c0;
                garr[u2 & 7u] = (unsigned)x0;
                e0 = e0 * 0.5L + (long double)((unsigned)(x0 >> 70) & 1023u);
                h1 = (unsigned short)(h1 + (0x38f43ecu & 0x934c59ddu));
                s1 = (int)((unsigned)s1 + ((0x60a52efbu ? 0x80000000u : 0x80000000u) ^ 0x10000u));
            } else {
                if (budget != 0u) { budget -= 1u; u1 = fn0(~(0x455b0010u >> (0xb0c8c2c6u & 31u)), (unsigned)(short)((unsigned)c1 & i0), 0x80000000u); }
            }
            break; (void)(0xffffffffu);
            if ((unsigned)((short)0x7fffffffu > (signed char)0x80000000u)) {
                switch ((unsigned)(signed char)((unsigned)(u2 == 0x10000u) % (v0 | 1u)) & 7u) {
                    case 5u: ;
                }
            } else {
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((int)0xeb151281u >= (int)u3) % ((unsigned)h1 | 1u)), (unsigned)s0, 0x3725314du); }
                *mp = ~(unsigned)((short)0x80000000u > (signed char)(unsigned)(signed char)(i2 * 0x80000000u));
            }
        }
        { unsigned t5; double z5; if (((unsigned)f0) & 1u) { t5 = (unsigned)(u2 == (0x3d99730cu + 0xb4ad7a91u)); z5 = (double)(((p2 / (r0.x | 1u))) & 255u); } if (((unsigned)f0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            q0 = &garr[(fuel - (0xffffffffu & (unsigned)s1)) & 7u];
        }
        switch ((g0 ^ *q0) & 7u) {
            if ((unsigned)((short)0x143caa8bu > (signed char)(u0 / (a0[u1 & 3u] | 1u)))) goto L4;
        }
        if (r0.y) {
            if (i0) break;
        } else {
            if (p2) break;
            switch (((0x80000000u % (0x7fffffffu | 1u)) | 0x589e93afu) & 7u) {
                continue; (void)((unsigned)(unsigned char)(unsigned)((unsigned)((short)(unsigned)s1 > (signed char)0x27596fbdu) || 0x5171fdf4u));
            }
            break; (void)((unsigned)(short)(unsigned)((short)(unsigned)((int)a0[i0 & 3u] < (int)*q0) > (signed char)(unsigned)h1));
            x0 = x0 * 0x100000001b3ull + (*q0 + (((unsigned)s1 * p2) % ((unsigned)(unsigned char)(garr[i1 & 7u] % ((unsigned)e0 | 1u)) | 1u)));
        }
        if ((unsigned)h0) {
            q0 = &garr[((unsigned)h0 / (0x873ada84u | 1u)) & 7u];
            if ((m0 - 0x81e29c62u)) {
                i1 = (4u + ((unsigned)c0 / ((unsigned)c1 | 1u))) & 15u;
            } else {
                if (((unsigned)f0 - u2)) goto L3;
                u3 += (unsigned)l0;
                i1 = (unsigned)((short)garr[i1 & 7u] > (signed char)((unsigned)(w0 >> 29) % (((unsigned)l0 ^ (unsigned)h1) | 1u))) & 15u;
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(8u, (unsigned)s0, (unsigned)(i2 && (unsigned)((int)6u < (int)u2))); }
                    if ((unsigned)((int)8u < (int)fuel)) {
                        if ((unsigned)((unsigned)(3u && i0) < i2)) break;
                        h0 = (short)~((0x7fffffffu * (unsigned)((short)4u > (signed char)(unsigned)s1)) >> (((unsigned)x0 * garr[i1 & 7u]) & 31u));
                        q0 = &garr[(p1 % (((unsigned)f0 & 0x7fffffffu) | 1u)) & 7u];
                    }
                    m0 ^= (unsigned)(p1 || (unsigned)s1);
                    break; (void)(9u);
                    s1 = (int)((unsigned)s1 + (m0 >> (v0 & 31u)));
                    *mp = 6u;
                }
            }
            if ((unsigned)((p1 * p0) < fuel)) {
                u1 = u1 * 0x9e3779b1u + (unsigned)((short)((unsigned)((a0[i0 & 3u] / (0xffffffffu | 1u)) && u0) / (0xb86c4fbcu | 1u)) > (signed char)i0);
                if (budget != 0u) { budget -= 1u; u3 = fn1(((p0 * p0) >> ((unsigned)l0 & 31u)), (unsigned)h1, ~(unsigned)((int)0xb3a3b72fu >= (int)((unsigned)(w0 >> 29) + 1u))); }
            } else {
                *q0 = (a0[u1 & 3u] << ((0xffffffffu ^ 2u) & 31u));
            }
        }
    }
    if (((unsigned)((unsigned)b0 < a0[i0 & 3u]) & i1)) {
        if (p2) {
            goto done;
        }
    } else {
        *mp = ((unsigned)((int)(unsigned)c0 >= (int)a0[i0 & 3u]) << (((unsigned)b0 + 0x10000u) & 31u));
    }
    *mp = (i0 * (5u - (unsigned)(0xadce459eu || (unsigned)w0)));
    c1 = (signed char)(unsigned)((unsigned)((short)p2 > (signed char)(0xee682b65u & p2)) < (unsigned)(short)((unsigned)s0 - 0x2d15527fu));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (unsigned)((int)(u0 - (unsigned)s1) >= (int)2u);
        { unsigned t6; double z6; if (((unsigned)(a0[u1 & 3u] == (unsigned)s1)) & 1u) { t6 = 1u; z6 = (double)((-(unsigned)((short)5u > (signed char)(0x60f7e63bu / ((unsigned)(w0 >> 29) | 1u)))) & 255u); } if (((unsigned)(a0[u1 & 3u] == (unsigned)s1)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
            b0 = (unsigned)((short)(unsigned)(short)(u1 & (unsigned)x0) > (signed char)(unsigned)(w0 >> 29)) != 0u;
            if ((unsigned)(x0 >> 70)) goto L4;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((p2 * 0x10000u), 8u, *q0); }
    }
    switch (0xeac8e580u & 7u) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((p1 - *mp)) goto L3;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t7; double z7; if (((unsigned)h1) & 1u) { t7 = (0xffffffffu << (0x2d81ceabu & 31u)); z7 = (double)(((unsigned)((int)(unsigned)w0 < (int)(unsigned)(signed char)(0xffffffffu >> (u0 & 31u)))) & 255u); } if (((unsigned)h1) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                    x0 = x0 * 0x100000001b3ull + (unsigned)((g1 + (unsigned)(garr[i1 & 7u] < (unsigned)x0)) < 5u);
                }
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(r0.x < a0[u1 & 3u]), ((unsigned)c1 / ((p1 >> (garr[u2 & 7u] & 31u)) | 1u)), m0); }
                while (i2++ < 7u && ~((unsigned)d0 & 3u)) { if (--fuel == 0u) goto done;
                    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)((0x4c3bb594u >> (-(unsigned)(9u < i0) & 31u)) & 1023u);
                        m0 ^= ((0xffffffffu & ((unsigned)f0 + (unsigned)l0)) + (unsigned)e0);
                        if (budget != 0u) { budget -= 1u; u3 = fn0((u3 ^ 0xf5609198u), (0u + 0x80000000u), (9u + u0)); }
                        m0 ^= ((0x10000u & (unsigned)((int)p0 < (int)0x7fffffffu)) << (r0.x & 31u));
                        w0 = w0 * 6364136223846793005ull + ~((g0 % (*q0 | 1u)) << (g1 & 31u));
                    }
                    *q0 += ((9u >> (g0 & 31u)) >> ((g0 ^ p0) & 31u));
                    if ((unsigned)((unsigned)h1 || (unsigned)(short)(*mp % (7u | 1u)))) continue;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)s1, (unsigned)((unsigned)d0 || (unsigned)((unsigned)l0 || 7u)), (i0 & u2)); }
                    r0.x = 0x7fffffffu;
                }
                if ((0x7fffffffu | (i0 | (unsigned)s0))) {
                    case 3u: ;
                    u1 = (u0 ? (2u % (0x95ed3f54u | 1u)) : i1);
                    if (r0.y) continue;
                    continue; (void)(((p1 / ((unsigned)c0 | 1u)) | (unsigned)c1));
                    g1 += (0xffffffffu + (unsigned)c1);
                }
            }
        }
    }
    if ((0xe55ef67cu % ((4u * garr[u2 & 7u]) | 1u))) {
        e0 = e0 * 0.5L + (long double)((0xd6f4536bu - v0) & 1023u);
        goto L2;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    d0 = d0 * 0.5 + (double)((0x10000u ? 0x7fffffffu : a0[i0 & 3u]) & 1023u);
    { unsigned t0; double z0; if (((unsigned)((unsigned)c1 && (unsigned)(7u || fuel))) & 1u) { t0 = (unsigned)h1; z0 = (double)(((((unsigned)h1 * (unsigned)c0) | 0x300b780fu)) & 255u); } if (((unsigned)((unsigned)c1 && (unsigned)(7u || fuel))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        q0 = &garr[0x7fffffffu & 7u];
        do { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((0x8fe4ee5u << (garr[u2 & 7u] & 31u)) >> (((unsigned)(signed char)(unsigned)((unsigned)c0 == (unsigned)l0) ^ (unsigned)l0) & 31u));
            c1 = (signed char)(unsigned)!(unsigned)((short)garr[u2 & 7u] > (signed char)0x80000000u);
            u1 += 0x7143c8cau;
            if (((garr[u2 & 7u] / ((unsigned)s1 | 1u)) << ((unsigned)x0 & 31u))) break;
            r0.x = (unsigned)!((a0[i0 & 3u] >> (7u & 31u)) ^ (*mp % (0x97b13726u | 1u)));
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)!((unsigned)((unsigned)e0 < u2) ^ g0), fuel, (u2 << (0u & 31u))); }
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    g1 += ~(0x87675d92u << ((unsigned)(0x6dd75e36u == (a0[i0 & 3u] >> ((unsigned)c0 & 31u))) & 31u));
                }
                g1 += (unsigned)((short)*mp > (signed char)a0[u1 & 3u]);
                a0[p2 & 3u] = (unsigned)!(unsigned)((int)(unsigned)w0 < (int)(unsigned)(x0 >> 70));
                if ((r0.x * 5u)) break;
            }
        } while (i0++ < 3u && (unsigned)(signed char)(0x80000000u & v0));
    }
    L0: if (--fuel == 0u) goto done;
    garr[(unsigned)e0 & 7u] = 0xffffffffu;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)((int)fuel < (int)0x17db104cu) == (unsigned)l0), (unsigned)(0x42948c6fu || (unsigned)(u1 && 0u)), (u2 | (unsigned)(w0 >> 29))); }
    }
    goto L4;
    if (i0) goto L0;
    L1: if (--fuel == 0u) goto done;
    if ((unsigned)d0) {
        if (budget != 0u) { budget -= 1u; u1 = fn1(u1, (unsigned)((int)garr[u2 & 7u] >= (int)(3u % (i0 | 1u))), (unsigned)w0); }
    } else {
        u0 = (unsigned)((short)u0 > (signed char)0xeb5478cau);
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if (0x80000000u) continue;
                a0[(unsigned)(x0 >> 70) & 3u] = -(unsigned)(a0[u1 & 3u] || i1);
            } while (i1++ < 3u && (0x7fffffffu & p2));
            h1 = (unsigned short)(h1 + r0.y);
        }
        while (i0++ < 3u && (unsigned)(0xbbc1063du == ((unsigned)(x0 >> 70) % ((unsigned)h1 | 1u)))) { if (--fuel == 0u) goto done;
            *q0 += ((unsigned)c1 % (0xffffffffu | 1u));
        }
    }
    goto L0;
    goto L3;
    if ((unsigned)((g0 >> ((unsigned)c0 & 31u)) < (unsigned)c1)) goto L2;
    switch (v0 & 7u) {
        switch (p2 & 7u) {
            u1 = ((unsigned)((0xa5fe655du - m0) && (unsigned)((int)r0.x >= (int)(unsigned)s0)) ^ r0.x);
        }
        garr[0xa42b50afu & 7u] = (unsigned)((short)(unsigned)c0 > (signed char)(unsigned)((unsigned)(0x7fffffffu < (unsigned)w0) == (0x7b7a77e5u | p2)));
        g0 = ~(((unsigned)(5u || u3) + 0xefc258bu) / (p2 | 1u));
        if ((unsigned)((int)r0.x < (int)i0)) break;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)(*q0 && (unsigned)l0) || u1), ((0xa6a984f4u << (1u & 31u)) / ((unsigned)c1 | 1u)), (unsigned)(w0 >> 29)); }
    goto L2;
    switch ((0x7d1c7d82u | *q0) & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn0(0x7fffffffu, ((0x80000000u * 0x10000u) - (unsigned)c1), u1); }
    }
    g1 += ((unsigned)b0 | (unsigned)(unsigned char)((u0 - 0x202c2e45u) | (unsigned)b0));
    f0 = f0 * 0.5f + (float)((unsigned)(i1 == (unsigned)((unsigned)d0 && u1)) & 255u);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (garr[i1 & 7u] & 7u) {
            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)!((unsigned)f0 * i1) && (unsigned)d0);
        }
        do { if (--fuel == 0u) goto done;
            q0 = &garr[(unsigned)(signed char)(unsigned)((short)(unsigned)(garr[u2 & 7u] && (unsigned)(garr[u2 & 7u] == i0)) > (signed char)(unsigned)c1) & 7u];
            if ((unsigned)((unsigned)(w0 >> 29) && u2)) {
                break; (void)(~(unsigned)(r0.x == 0u));
            }
        } while (i1++ < 5u && (unsigned)((int)0x5df1459bu >= (int)(u3 + garr[i1 & 7u])));
        if ((i1 | garr[u2 & 7u])) {
            if ((unsigned)w0) {
                break; (void)((unsigned)((int)0x7fffffffu < (int)u2));
                r0.x = (unsigned)((int)(unsigned)(garr[i1 & 7u] < (unsigned)c1) < (int)(unsigned)!(g1 - 0x7fffffffu));
                s0 = (int)((i2 << (*mp & 31u)) * (unsigned)(6u < 0x32ffe148u));
                s0 = (int)-((0u << ((unsigned)f0 & 31u)) ^ (r0.x | (unsigned)(2u < 0x10000u)));
                g1 += (unsigned)(fuel || garr[u2 & 7u]);
                v0 = (unsigned)((unsigned)h1 || (unsigned)(signed char)(((unsigned)s0 / ((0x4d538333u ^ p1) | 1u)) >> ((unsigned)s0 & 31u)));
            }
        }
        { unsigned t1; double z1; if (((unsigned)d0) & 1u) { t1 = i1; z1 = (double)(((unsigned)((int)0x8a69acd0u >= (int)((unsigned)x0 >> (i2 & 31u)))) & 255u); } if (((unsigned)d0) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            while (i1++ < 4u && (unsigned)((int)r0.y >= (int)(unsigned)((int)3u >= (int)(unsigned)f0))) { if (--fuel == 0u) goto done;
                break; (void)(garr[i1 & 7u]);
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + 0xa74b54ddu);
                    { unsigned t2; double z2; if (((unsigned)s0) & 1u) { t2 = (unsigned)(u1 == v0); z2 = (double)(((unsigned)f0) & 255u); } if (((unsigned)s0) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                        if (budget != 0u) { budget -= 1u; u1 = fn0(r0.y, (unsigned)(signed char)((0x85df4a04u & r0.y) ^ u1), (unsigned)((unsigned)e0 == 0u)); }
                    }
                    m0 ^= ((unsigned)((unsigned)s1 && v0) >> (a0[i0 & 3u] & 31u));
                }
                u3 = ((u2 ? 5u : (unsigned)h0) ^ (unsigned)(0xf3974e93u && 0x80000000u));
                if ((0x34db3b59u ? (unsigned)w0 : (unsigned)c1)) {
                    do { if (--fuel == 0u) goto done;
                        L2: if (--fuel == 0u) goto done;
                        c0 = (unsigned char)(((4u ^ v0) ^ 0x80000000u) % ((i1 - p0) | 1u));
                        a0[7u & 3u] = ((unsigned)!(a0[u1 & 3u] | (9u / (0x829dd1a5u | 1u))) << ((unsigned)x0 & 31u));
                        goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((unsigned)d0 < (unsigned)h1), (unsigned)((unsigned)(u0 < u1) == 0x7fffffffu), (unsigned)f0); }
                        u0 = u0 * 0x9e3779b1u + (unsigned)(((u1 >> ((unsigned)(1u == garr[u2 & 7u]) & 31u)) >> (p1 & 31u)) == 0x46ad7a12u);
                    } while (i2++ < 2u && u0);
                    while (i2++ < 5u && (unsigned)((unsigned)l0 < -(7u / (i2 | 1u)))) { if (--fuel == 0u) goto done;
                        L3: if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn1(i1, i2, (unsigned)!(0xffffffffu * (unsigned)e0)); }
                        r0.x = (unsigned)(garr[i1 & 7u] && p1);
                        *q0 += (i0 + (unsigned)((int)(unsigned)((unsigned)((unsigned)(w0 >> 29) < 0x3577aebfu) < 0x55cd8b36u) < (int)5u));
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)(garr[u2 & 7u] && i1) >> (p2 & 31u)), (0xffffffffu | *q0), (unsigned)(-((unsigned)d0 << (0x7fffffffu & 31u)) == (unsigned)e0)); }
                    L4: if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        i1 = (unsigned)(r0.y < 0x7fffffffu) & 15u;
                    }
                    r0.x = ~(unsigned)((unsigned)((v0 % (9u | 1u)) == 0xffffffffu) < i1);
                }
                while (i2++ < 7u && ((unsigned)e0 & (unsigned)(4u < i1))) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + 0x80000000u;
                    if ((i2 + (unsigned)((unsigned)(w0 >> 29) < 0x7fffffffu))) break;
                    s0 = (int)a0[i0 & 3u];
                    if ((unsigned)((int)(unsigned)f0 >= (int)u1)) {
                        if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)h0 - *q0), (unsigned)((unsigned)c0 == 9u), (unsigned)(0u || 0xbf7dabf2u)); }
                        m0 ^= 7u;
                        c1 = (signed char)(unsigned)((int)(6u - i0) < (int)(g1 + (unsigned)h0));
                        g0 = (unsigned)((short)u3 > (signed char)((unsigned)h1 + r0.x));
                        if ((0x80000000u - 0x26511dbbu)) break;
                        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                            b0 = (p1 - (unsigned)(short)(garr[u2 & 7u] << ((unsigned)s0 & 31u))) != 0u;
                            if ((g1 + (m0 + 0xfc9996d4u))) break;
                            q0 = &garr[(unsigned)((unsigned)(unsigned char)(u3 ^ *mp) || ((*q0 % ((unsigned)d0 | 1u)) >> (0x80000000u & 31u))) & 7u];
                            if (budget != 0u) { budget -= 1u; u3 = fn0((g1 * u3), 0x7b10c2b9u, (unsigned)((int)8u >= (int)g1)); }
                            e0 = e0 * 0.5L + (long double)((unsigned)((int)u0 >= (int)i2) & 1023u);
                            *q0 += (7u % (r0.y | 1u));
                        }
                    } else {
                        break; (void)(garr[u2 & 7u]);
                        u1 += (unsigned)((unsigned)((short)0xedb8ce46u > (signed char)0x80000000u) || (g1 ^ (unsigned)((int)(unsigned)l0 >= (int)0xc1c78f8u)));
                        b0 = 0x80000000u != 0u;
                    }
                    m0 ^= ~((unsigned)(w0 >> 29) - (i1 + m0));
                }
                switch ((6u % (4u | 1u)) & 7u) {
                    if ((9u << ((unsigned)c1 & 31u))) goto L0;
                    c1 = (signed char)(unsigned)((short)(garr[u2 & 7u] & u3) > (signed char)i2);
                    e0 = e0 * 0.5L + (long double)((r0.y ? 5u : g1) & 1023u);
                    if ((~(unsigned)((int)(unsigned)c1 < (int)0x80000000u) + (unsigned)(w0 >> 29))) {
                        f0 = f0 * 0.5f + (float)((unsigned)(0x8ae9c1f5u || (unsigned)((int)((u2 / (0x5bbc545fu | 1u)) / (i2 | 1u)) >= (int)(unsigned)s1)) & 255u);
                    } else {
                        r0.x = (unsigned)((int)(unsigned)((int)(unsigned)((unsigned)w0 && p2) >= (int)(unsigned)d0) >= (int)~(u1 * m0));
                        if (budget != 0u) { budget -= 1u; u2 = fn3(0x7fffffffu, (unsigned)!((0x67932fd6u << (i0 & 31u)) ^ a0[u1 & 3u]), ((unsigned)e0 ? (unsigned)c0 : (unsigned)h1)); }
                    }
                    garr[4u & 7u] = (unsigned)f0;
                }
            }
            if (((unsigned)(unsigned char)(0x6cee13c7u / (0x80000000u | 1u)) - 9u)) break;
            if (((0x10000u << (0xffffffffu & 31u)) + (unsigned)s0)) break;
            if ((0x5f2bc9e6u - (unsigned)c1)) {
                r0.x = ~((unsigned)(x0 >> 70) % ((unsigned)((int)(unsigned)((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)d0) || (unsigned)(w0 >> 29)) >= (int)p1) | 1u));
                q0 = &garr[(garr[u2 & 7u] + r0.x) & 7u];
                break; (void)(r0.y);
                l0 = (long)((unsigned long)l0 + ((unsigned)((int)(unsigned)s0 >= (int)(unsigned)c1) % (0x80000000u | 1u)));
                c0 = (unsigned char)(i1 / ((unsigned)!(0xffffffffu << (((unsigned)s0 & (unsigned)(p2 == r0.x)) & 31u)) | 1u));
                switch (((u3 << (0x10000u & 31u)) ^ u1) & 7u) {
                    u0 += (unsigned)(short)((unsigned)e0 & (unsigned)(unsigned char)(unsigned)(7u == 7u));
                    r0.x = -((unsigned)((int)3u >= (int)(unsigned)l0) + (unsigned)(u0 < (*mp >> (garr[u2 & 7u] & 31u))));
                    do { if (--fuel == 0u) goto done;
                        garr[(unsigned)h1 & 7u] = (m0 * (i1 - garr[u2 & 7u]));
                        h0 = (short)((i0 >> (u1 & 31u)) / ((unsigned)(unsigned char)(0x49dcab7u | (1u | 0xffffffffu)) | 1u));
                        r0.y ^= ((unsigned)x0 | (u1 + 8u));
                        case 1u: ;
                        w0 = w0 * 6364136223846793005ull + ((2u ? 0x6cf84572u : (unsigned)d0) ^ (unsigned)((unsigned)s1 == p1));
                        r0.x = ((unsigned)((short)(3u - (u1 ^ u0)) > (signed char)(unsigned)c1) >> ((unsigned)b0 & 31u));
                    } while (i1++ < 4u && (0u / ((unsigned)w0 | 1u)));
                    d0 = d0 * 0.5 + (double)((unsigned)((int)(i0 | (6u + m0)) < (int)(unsigned)e0) & 1023u);
                    r0.x = (m0 / ((unsigned)(x0 >> 70) | 1u));
                }
            }
        }
    }
    e0 = e0 * 0.5L + (long double)(((p1 * (unsigned)c0) - r0.x) & 1023u);
    if (budget != 0u) { budget -= 1u; u3 = fn1((0xfbd84ceu - (unsigned)((unsigned)(x0 >> 70) || 0xa46be34eu)), (unsigned)c1, ((unsigned)d0 << (4u & 31u))); }
    if ((unsigned)!(unsigned)((int)(unsigned)((int)p2 >= (int)i2) < (int)0xc1565543u)) {
        goto L4;
        a0[0x80000000u & 3u] = ((unsigned)c0 * ((0xc5b821u / (0x80000000u | 1u)) | u3));
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((unsigned)h1 == (0xf90ca0a2u / (6u | 1u))), (unsigned)(signed char)(r0.y ? u2 : a0[i0 & 3u]), ((unsigned)(x0 >> 70) | 0xf121b1ddu)); }
        if (7u) {
            e0 = e0 * 0.5L + (long double)((((unsigned)s0 << ((unsigned)((unsigned)f0 == i1) & 31u)) >> ((unsigned)(unsigned char)(0x7f2e687eu + 0x80000000u) & 31u)) & 1023u);
            switch (((unsigned)d0 ^ (unsigned)((int)fuel < (int)0x10000u)) & 7u) {
                h0 = (short)(unsigned)!(-(unsigned)(~(unsigned)((short)0x7fffffffu > (signed char)(unsigned)e0) == ((unsigned)s0 & garr[u2 & 7u])) ^ 6u);
            }
            if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((unsigned)(short)(p1 % (garr[i1 & 7u] | 1u)) == i1), (fuel - (i0 | 3u)), 0xb3d66250u); }
        }
        g0 = (unsigned)((short)((4u * (3u + 0xe823c089u)) | (unsigned)l0) > (signed char)u3);
        if ((unsigned)(4u && (unsigned)h1)) goto L3;
    }
    goto L2;
    u0 = (unsigned)(unsigned char)(r0.y | ((g1 ? 0x7e642821u : a0[i0 & 3u]) * r0.y));
    u3 = u3 * 0x9e3779b1u + u2;
    { unsigned t3; double z3; if (((r0.y << (g1 & 31u))) & 1u) { t3 = (unsigned)(*mp == u1); z3 = (double)((1u) & 255u); } if (((r0.y << (g1 & 31u))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        if (((unsigned)(r0.y < (unsigned)b0) << (i0 & 31u))) {
            if ((unsigned)((short)((unsigned)h0 ^ (unsigned)e0) > (signed char)(unsigned)e0)) goto L1;
            goto done;
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                g0 = ~((unsigned)(x0 >> 70) & (unsigned)(a0[i0 & 3u] == 0x27581684u));
                if ((unsigned)((int)p0 >= (int)(unsigned)e0)) break;
                r0.x = -(i0 | garr[i1 & 7u]);
                if (u2) {
                    s0 = (int)(0x1cc3bd98u / ((a0[i0 & 3u] + 6u) | 1u));
                    if (0xdaf4ae69u) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn2(m0, ~(unsigned)(m0 || 0xb26530c3u), (i2 ? 0x9d12dfa9u : 0x981d8499u)); }
                }
                if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)e0, (unsigned)b0, (((unsigned)(x0 >> 70) << ((unsigned)l0 & 31u)) ^ (unsigned)b0)); }
            }
            *q0 = (i0 % ((u3 << (0x10000u & 31u)) | 1u));
            l0 = (long)((unsigned long)l0 + p2);
        }
        if ((g0 << (p0 & 31u))) {
            if ((p0 - p0)) goto done;
            if (u3 == 7u) return 0x32f0e080u;
            if ((unsigned)w0) goto L2;
        }
        garr[(unsigned)x0 & 7u] = (unsigned)!((unsigned)d0 & (unsigned)c0);
        { unsigned t4; double z4; if (((unsigned)(fuel && u2)) & 1u) { t4 = 2u; z4 = (double)(((unsigned)(short)((unsigned)l0 + 0x7fffffffu)) & 255u); } if (((unsigned)(fuel && u2)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                while (i1++ < 5u && (unsigned)b0) { if (--fuel == 0u) goto done;
                    g0 = (0xffffffffu >> ((unsigned)(signed char)((unsigned)l0 | ((unsigned)d0 ? (unsigned)c1 : r0.x)) & 31u));
                    switch (garr[i1 & 7u] & 7u) {
                        *q0 += (1u >> ((unsigned)d0 & 31u));
                        case 6u: ;
                        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(short)((unsigned)s0 % ((unsigned)h1 | 1u)), (0xbbda3b84u ? (unsigned)(w0 >> 29) : 0x7fffffffu), (unsigned)f0); }
                    }
                    *mp = ((unsigned)((short)0x10000u > (signed char)((unsigned)l0 >> (0x22c40b22u & 31u))) + 0x10000u);
                }
                if ((unsigned)(short)(i1 + 0xf106262fu)) break;
                u1 ^= ((unsigned)(short)(r0.y + 0x7fffffffu) >> ((fuel | r0.y) & 31u));
                d0 = d0 * 0.5 + (double)((4u - (unsigned)s1) & 1023u);
                if ((unsigned)(short)(unsigned)(0xffffffffu < 0u)) break;
            }
        }
        do { if (--fuel == 0u) goto done;
            while (i1++ < 3u && (unsigned)((short)0x80000000u > (signed char)4u)) { if (--fuel == 0u) goto done;
                if (-((unsigned)x0 << ((unsigned)(w0 >> 29) & 31u))) break;
            }
            if ((unsigned)((short)0x69c9a651u > (signed char)8u)) break;
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(x0 >> 70), u0, 0x40d8b64fu); }
        } while (i0++ < 4u && 0xb99530fau);
    }
    if (u3 == 7u) return (unsigned)((int)0x7084603fu >= (int)u3);
    if (-(5u >> ((unsigned)f0 & 31u))) goto L2;
    m0 ^= (unsigned)(signed char)(((unsigned)((unsigned)b0 && (unsigned)(unsigned char)(i2 + *q0)) % ((unsigned)e0 | 1u)) >> (u1 & 31u));
    q0 = &garr[(u0 % ((unsigned)e0 | 1u)) & 7u];
    a0[((unsigned)h0 & r0.x) & 3u] = (unsigned)((a0[i0 & 3u] | garr[u2 & 7u]) == (0x72a7e050u - g0));
    r0.x = (unsigned)((unsigned)(unsigned char)(0xffffffffu ? p0 : 4u) == (0x63650b54u & 2u));
    if ((unsigned)(w0 >> 29)) goto L0;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t5; double z5; if ((((unsigned)c0 << ((unsigned)b0 & 31u))) & 1u) { t5 = (unsigned)(5u < (a0[i0 & 3u] << (*mp & 31u))); z5 = (double)(((unsigned)e0) & 255u); } if ((((unsigned)c0 << ((unsigned)b0 & 31u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            while ((garr[u2 & 7u] >> (0xd044e4c9u & 31u))) { if (--fuel == 0u) goto done;
                while ((unsigned)f0) { if (--fuel == 0u) goto done;
                    g1 += (0u + (v0 - (m0 - *mp)));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((r0.x - 0xffffffffu), (u3 >> ((unsigned)c0 & 31u)), (unsigned)((0xffffffffu ^ 0x75d9927fu) == (unsigned)e0)); }
                    g1 += (unsigned)((int)m0 < (int)1u);
                    garr[0x835e56a7u & 7u] = (u2 + (unsigned)s0);
                }
                if (5u) {
                    if (m0) break;
                    c0 = (unsigned char)(unsigned)(m0 && (fuel >> (u1 & 31u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)s1 < (int)(unsigned)c0), 0xffffffffu, (*mp + (unsigned)(m0 < (unsigned)(w0 >> 29)))); }
                    i0 = (9u / (-(unsigned)((0xed39367cu / (fuel | 1u)) && ((unsigned)s1 + (unsigned)s1)) | 1u)) & 15u;
                    if ((0xa709c73au / (u1 | 1u))) continue;
                }
                if (u3 == 7u) return 0x265e2a3fu;
                r0.x = a0[u1 & 3u];
                if (budget != 0u) { budget -= 1u; u1 = fn1((2u * (unsigned)h1), ((unsigned)(*mp < a0[u1 & 3u]) + *q0), ((unsigned)f0 | (0xc8fbf71eu - u0))); }
            }
            c1 = (signed char)(unsigned)(unsigned char)(m0 + (unsigned)f0);
            if ((unsigned)l0) break;
        }
        if ((unsigned)!(u0 << (9u & 31u))) break;
        if ((9u & p0)) break;
        d0 = d0 * 0.5 + (double)(((unsigned)(p2 || u3) - (unsigned)f0) & 1023u);
    }
    { unsigned t6; double z6; if ((a0[u1 & 3u]) & 1u) { t6 = (unsigned)((short)u2 > (signed char)7u); z6 = (double)((a0[u1 & 3u]) & 255u); } if ((a0[u1 & 3u]) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.x = u2;
            l0 = (long)((unsigned long)l0 + (unsigned)c1);
            if (-(7u | (unsigned)((unsigned)h1 && (unsigned)(x0 >> 70)))) break;
            do { if (--fuel == 0u) goto done;
                v0 = (0x10000u ^ (unsigned)((int)0x70cf1a24u >= (int)u3));
                s0 = (int)(unsigned)c1;
                s1 = (int)((unsigned)s1 + (unsigned)(w0 >> 29));
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (unsigned)((0xc63dd632u * fuel) == i0);
                    if (budget != 0u) { budget -= 1u; u3 = fn0((0x7385ebcdu - garr[i1 & 7u]), ((unsigned)h0 * 0u), (0x30869722u % (((unsigned)s1 / (u0 | 1u)) | 1u))); }
                    if ((unsigned)(signed char)(garr[i1 & 7u] | ((unsigned)(x0 >> 70) ^ (unsigned)c0))) goto L3;
                }
                goto L1;
            } while (i1++ < 2u && ((unsigned)e0 | (0x10000u << (6u & 31u))));
        }
    }
    h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)(a0[i0 & 3u] && i1) < (int)garr[u2 & 7u]));
    if (((unsigned)w0 ? *mp : a0[i0 & 3u])) goto L1;
    goto L3;
    if (budget != 0u) { budget -= 1u; u3 = fn3((0xffffffffu + p1), (p1 & 0x10000u), (unsigned)(r0.y < -(unsigned)(9u && (unsigned)e0))); }
    goto done;
    do { if (--fuel == 0u) goto done;
        if ((((unsigned)h1 * *q0) + (unsigned)s1)) break;
        s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)((int)v0 >= (int)0xa311096u)));
        switch (((unsigned)b0 << (0xe7b67776u & 31u)) & 7u) {
            if (budget != 0u) { budget -= 1u; u2 = fn3(8u, 0x10000u, ((unsigned)((unsigned)s1 == u1) + p0)); }
        }
    } while (i0++ < 3u && 0u);
    { unsigned t7; double z7; if (((unsigned)((short)(unsigned)w0 > (signed char)0xbdf4867eu)) & 1u) { t7 = (i1 % (p1 | 1u)); z7 = (double)((((unsigned)((unsigned)d0 == r0.y) << (r0.x & 31u))) & 255u); } if (((unsigned)((short)(unsigned)w0 > (signed char)0xbdf4867eu)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
        w0 = w0 * 6364136223846793005ull + (unsigned)(w0 >> 29);
        i0 = ((unsigned)(p2 == (u2 >> (0x1cf3697du & 31u))) << ((u3 / ((unsigned)w0 | 1u)) & 31u)) & 15u;
        c0 = (unsigned char)((0x9c9667e5u & (unsigned)x0) % (2u | 1u));
        x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)(8u < (unsigned)l0) > (signed char)(i2 / (u3 | 1u)));
        switch (-(unsigned)((int)(unsigned)s0 >= (int)r0.y) & 7u) {
            u2 ^= 7u;
            u1 = (unsigned)((int)0xc82d6451u < (int)(i2 - (unsigned)((unsigned)d0 == 0x80000000u)));
            if ((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)s1)) break;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0((1u - (unsigned)(x0 >> 70)), (unsigned)((short)0xbb1d1213u > (signed char)(garr[u2 & 7u] * u1)), 0x559d99d6u); }
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((g1 & (unsigned)(0x55d6f4ffu == 6u))) break;
                break; (void)(*mp);
                b0 = (0xd6b75362u + p0) != 0u;
                if ((unsigned)((int)*mp >= (int)0x80000000u)) break;
                if (p1) {
                    f0 = f0 * 0.5f + (float)((unsigned)!(unsigned)(garr[u2 & 7u] == (unsigned)(signed char)(unsigned)(v0 < -((u2 | 0x80000000u) << ((unsigned)h0 & 31u)))) & 255u);
                    if (((6u / (7u | 1u)) - 0x7fffffffu)) break;
                    if ((unsigned)w0) {
                        m0 ^= (unsigned)((i1 + 9u) && (unsigned)c1);
                        if (budget != 0u) { budget -= 1u; u0 = fn2((0x7fffffffu * (unsigned)((int)(unsigned)h0 < (int)0xffffffffu)), u3, (unsigned)(u1 == 0x59d251c7u)); }
                    } else {
                        w0 ^= (unsigned long long)(unsigned)f0 << (u3 & 63u);
                    }
                    garr[(unsigned)h0 & 7u] = (unsigned)(w0 >> 29);
                    f0 = f0 * 0.5f + (float)((p0 ^ (0x9f0ec3bau << ((7u - 7u) & 31u))) & 255u);
                    while (i0++ < 3u && (unsigned)f0) { if (--fuel == 0u) goto done;
                        if ((unsigned)(short)((unsigned)f0 | p0)) break;
                        c1 = (signed char)((0x4ecb2447u / (4u | 1u)) | ((unsigned)d0 << (0xffffffffu & 31u)));
                        if ((unsigned)((int)(unsigned)e0 >= (int)0xffb12273u)) break;
                        if (i2) break;
                        garr[(a0[i0 & 3u] ^ g1) & 7u] = (unsigned)((unsigned)((int)((unsigned)((int)g0 < (int)garr[u2 & 7u]) + *mp) >= (int)(unsigned)s1) < p1);
                    }
                } else {
                    goto L3;
                    continue; (void)((unsigned)(signed char)((unsigned)((int)0x7fffffffu >= (int)(unsigned)w0) * a0[i0 & 3u]));
                    g0 = (unsigned)((int)0x80000000u >= (int)0x6efff226u);
                }
            }
            switch (p0 & 7u) {
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(i2 == g0), 0x80000000u, m0); }
                *q0 += (unsigned)!((unsigned)((short)(garr[u2 & 7u] / ((unsigned)(garr[u2 & 7u] < u2) | 1u)) > (signed char)(unsigned)x0) << (p2 & 31u));
                continue; (void)((unsigned)(unsigned char)(*q0 - 0x7fffffffu));
                if (budget != 0u) { budget -= 1u; u2 = fn3(i0, ((unsigned)(signed char)(unsigned)((short)0x302d9675u > (signed char)*q0) - 8u), (0xd23f4b4au | (unsigned)c1)); }
                break; (void)((unsigned)(signed char)(u0 >> (u3 & 31u)));
            }
            w0 = w0 * 6364136223846793005ull + ((unsigned)d0 | (unsigned)(short)(u3 << (0x80000000u & 31u)));
            u2 += (unsigned)((int)(unsigned)s1 < (int)(unsigned)e0);
            if (((unsigned)((unsigned)x0 || 0x10000u) ^ i1)) break;
            b0 = (((unsigned)h1 >> ((unsigned)((int)~(0x7fffffffu % (0x10000u | 1u)) >= (int)p0) & 31u)) | (unsigned)f0) != 0u;
        }
        break; (void)((unsigned)h0);
        b0 = u3 != 0u;
        if ((garr[u2 & 7u] ^ (0x41607fdeu << (0x80000000u & 31u)))) continue;
        g1 += ((unsigned)(w0 >> 29) + 3u);
    }
    if (((unsigned)h1 << ((unsigned)e0 & 31u))) goto L1;
    for (;;) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)((short)0xdcebfcf1u > (signed char)(unsigned)(0xffffffffu && (unsigned)b0));
            if ((unsigned)(signed char)(unsigned)(*mp || (0x80000000u - i2))) break;
        }
    }
    if ((g1 % ((unsigned)e0 | 1u))) {
        h1 = (unsigned short)(h1 + u2);
        g0 = (unsigned)((int)(unsigned)((unsigned)h1 < (unsigned)w0) < (int)(unsigned)((int)a0[i0 & 3u] >= (int)(4u << ((unsigned)(w0 >> 29) & 31u))));
        goto L4;
        garr[(unsigned)(signed char)(unsigned)((short)4u > (signed char)(unsigned)(w0 >> 29)) & 7u] = (unsigned)(0u || r0.y);
        d0 = d0 * 0.5 + (double)((unsigned)d0 & 1023u);
    }
    if ((unsigned)c1) goto L3;
    do { if (--fuel == 0u) goto done;
        while (i1++ < 3u && (0x80000000u % (0xc97c9629u | 1u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)e0 << (0xffffffffu & 31u)), g0, ~(unsigned)((unsigned)((int)u1 >= (int)fuel) && a0[i0 & 3u])); }
        }
        if ((unsigned)(fuel || u1)) break;
        if (u3 == 7u) return ((unsigned)h0 | (unsigned)((int)*mp >= (int)p2));
        r0.y ^= ((1u << ((g0 | 6u) & 31u)) - (unsigned)(7u && r0.x));
        if (budget != 0u) { budget -= 1u; u0 = fn1((0u / (a0[u1 & 3u] | 1u)), (unsigned)((unsigned)c0 && (unsigned)h0), 0x80000000u); }
    } while (i0++ < 3u && (unsigned)b0);
    r0.y ^= (unsigned)((unsigned)(signed char)(g0 / (*q0 | 1u)) == 0x7fffffffu);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 8u, 0x75abffeau, 0x9250edf4u },
        { 9u, 0xb83b4198u, 0x9029314fu },
        { 4u, 0xddc09e6cu, 0xf0d03de5u },
        { 1u, 0xe8966528u, 0xc0a2b589u },
        { 13u, 0x7491d49cu, 0xc9e41216u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
