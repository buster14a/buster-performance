// test-ssa-source's program of seed 134000430 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x82d6021fu, g1 = 0x2548a055u;
static unsigned garr[8] = { 0xc18b421fu, 0x6e00f8a7u, 0xc59ac30du, 0xde7afc04u, 0xcb6e2e52u, 0xe0119541u, 0x943172c3u, 0x630748au };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    { unsigned t0; double z0; if (((0x7fffffffu >> (u2 & 31u))) & 1u) { t0 = 7u; z0 = (double)((0x80e5d799u) & 255u); } if (((0x7fffffffu >> (u2 & 31u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        goto L2;
        u2 = u2 * 0x9e3779b1u + p0;
        switch (2u & 7u) {
            w0 ^= (unsigned long long)8u << ((unsigned)((int)0xd11b271fu < (int)((unsigned)((unsigned)d0 && u2) & i1)) & 63u);
            for (;;) { if (--fuel == 0u) goto done;
                *q0 = (~(unsigned)(0x10000u == u1) % ((unsigned)(a0[i0 & 3u] == r0.x) | 1u));
                if (~(unsigned)(g0 < r0.y)) {
                    if (garr[u2 & 7u]) continue;
                    if (((unsigned)w0 % ((unsigned)(w0 >> 29) | 1u))) goto L3;
                } else {
                    h1 = (unsigned short)(h1 + (0x80000000u ^ 9u));
                    u0 += (i0 + (unsigned)(signed char)((r0.x * g1) ? 3u : 0xfd1e0d3au));
                }
                case 5u: ;
                if (u3 == 7u) return (unsigned)((v0 >> (0xfd22c445u & 31u)) < (u1 & (unsigned)l0));
                do { if (--fuel == 0u) goto done;
                    default: ;
                    g1 += (unsigned)((int)(unsigned)d0 >= (int)(unsigned)c0);
                    c0 = (unsigned char)(7u ? 0xffffffffu : (unsigned)(unsigned char)(unsigned)((int)(unsigned)((unsigned)e0 || 9u) >= (int)garr[u2 & 7u]));
                    L1: if (--fuel == 0u) goto done;
                    s0 = (int)garr[i1 & 7u];
                } while (i1++ < 3u && (unsigned)s0);
            }
            if (u3 == 7u) return v0;
        }
    }
    q0 = &garr[((unsigned)(p2 || (unsigned)(fuel < 3u)) >> ((unsigned)e0 & 31u)) & 7u];
    do { if (--fuel == 0u) goto done;
        L2: if (--fuel == 0u) goto done;
    } while (i0++ < 6u && (unsigned)((v0 & g0) == 0xa3fa8950u));
    s0 = (int)(((unsigned)((unsigned)(w0 >> 29) == (unsigned)s0) & garr[u2 & 7u]) - (unsigned)h1);
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((4u * (g1 ^ garr[i1 & 7u]))) {
            c1 = (signed char)(unsigned)(signed char)(p1 | (unsigned)(x0 >> 70));
            L3: if (--fuel == 0u) goto done;
            break; (void)(g0);
        } else {
            switch (3u & 7u) {
                if (((unsigned)((int)garr[i1 & 7u] < (int)0xe6bdf331u) + 0x2357075u)) continue;
                L4: if (--fuel == 0u) goto done;
                switch (0xc9ecbb5cu & 7u) {
                    h0 = (short)(unsigned)((unsigned)!(i2 ^ 0x7fffffffu) || 0xf0276a56u);
                    case 3u: ;
                    q0 = &garr[(0xffffffffu + m0) & 7u];
                }
            }
        }
        { unsigned t1; double z1; if ((garr[u2 & 7u]) & 1u) { t1 = (u0 >> (4u & 31u)); z1 = (double)((0u) & 255u); } if ((garr[u2 & 7u]) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            do { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)x0;
                break; (void)((unsigned)h1);
                w0 = w0 * 6364136223846793005ull + (((unsigned)c1 & u2) * (unsigned)(u3 < 0x7fffffffu));
                h0 = (short)((0xffffffffu * 9u) >> (u0 & 31u));
                if ((unsigned)((int)((unsigned)x0 * 0x85e3b88au) < (int)r0.x)) break;
            } while (i1++ < 7u && 0x80000000u);
            if (r0.y) break;
            if (fuel) {
                if ((unsigned)!((unsigned)d0 << ((0x80000000u ^ (unsigned)c0) & 31u))) break;
                if (fuel < 8u) return ((unsigned)(m0 && (unsigned)w0) | (r0.x + (unsigned)b0));
                if ((unsigned)(w0 >> 29)) break;
                s0 = (int)0u;
                if ((unsigned)((unsigned)s0 && u3)) break;
                if (((unsigned)l0 % ((unsigned)f0 | 1u))) break;
            } else {
                if ((unsigned)((int)0xffffffffu >= (int)(unsigned)s1)) break;
                d0 = d0 * 0.5 + (double)(u3 & 1023u);
                if (((unsigned)s1 & (unsigned)l0)) break;
                if ((unsigned)((int)(unsigned)w0 >= (int)(unsigned)x0)) break;
            }
            { unsigned t2; double z2; if (((unsigned)e0) & 1u) { t2 = (unsigned)((0x80000000u * *mp) && p1); z2 = (double)(((unsigned)(((unsigned)c0 | (unsigned)(x0 >> 70)) == garr[u2 & 7u])) & 255u); } if (((unsigned)e0) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                do { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        c1 = (signed char)(g0 & (unsigned)(unsigned char)(unsigned)((short)i1 > (signed char)a0[i0 & 3u]));
                        w0 = w0 * 6364136223846793005ull + a0[i0 & 3u];
                        c0 = (unsigned char)(unsigned)((unsigned)(unsigned char)(unsigned)(*mp || (7u & p2)) < u3);
                        d0 = d0 * 0.5 + (double)((unsigned)(0u && 0x80000000u) & 1023u);
                        if (fuel < 8u) return *q0;
                    } while (i2++ < 2u && (unsigned)(unsigned char)(unsigned)(((unsigned)(w0 >> 29) >> (garr[u2 & 7u] & 31u)) < 0x80000000u));
                    w0 = w0 * 6364136223846793005ull + (unsigned)((short)*q0 > (signed char)9u);
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)((unsigned)d0 & 1023u);
                    }
                } while (i1++ < 5u && (unsigned)s0);
                if ((p0 ^ garr[i1 & 7u])) goto done;
                c0 = (unsigned char)8u;
                w0 = w0 * 6364136223846793005ull + (unsigned)(short)(0x80db6449u - (unsigned)(((unsigned)!(unsigned)((unsigned)l0 || u1) * 3u) || (unsigned)s1));
            }
            break; (void)(((unsigned)((short)fuel > (signed char)g0) & p1));
            if (p0) break;
        }
        do { if (--fuel == 0u) goto done;
            g1 += fuel;
            break; (void)((fuel * 0x10000u));
        } while (i1++ < 6u && u3);
        goto L0;
        c1 = (signed char)(a0[u1 & 3u] / (a0[i0 & 3u] | 1u));
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(-(unsigned)((short)0xa18aa827u > (signed char)(u2 % (fuel | 1u))));
            w0 = w0 * 6364136223846793005ull + (unsigned)!(unsigned)((5u ? garr[u2 & 7u] : p0) < fuel);
            *q0 += (unsigned)(short)(unsigned)((int)(g1 & i2) >= (int)i2);
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)r0.y << (0xffffffffu & 63u);
                s0 = (int)p1;
                while (i0++ < 4u && (unsigned)(signed char)(0x80000000u ^ (g1 % (u1 | 1u)))) { if (--fuel == 0u) goto done;
                    break; (void)((0x80000000u & v0));
                    if (0xd9269d40u) goto L1;
                    if (((unsigned)(short)((unsigned)(x0 >> 70) % (0x80000000u | 1u)) + g0)) break;
                    if (((u0 & 6u) ^ 0xffffffffu)) {
                        e0 = e0 * 0.5L + (long double)(((((unsigned)(w0 >> 29) ^ r0.y) | i0) | 0xffffffffu) & 1023u);
                        if (garr[i1 & 7u]) break;
                        s0 = (int)(u1 + (unsigned)((int)0x80000000u >= (int)(unsigned)d0));
                    } else {
                        if ((unsigned)(0xd98c83b6u < 0x80000000u)) {
                            break; (void)((unsigned)(i0 || g1));
                            garr[(unsigned)(p2 == (unsigned)c1) & 7u] = (unsigned)((unsigned)h1 || (unsigned)(2u || (unsigned)s0));
                        }
                        f0 = f0 * 0.5f + (float)((garr[i1 & 7u] / ((unsigned)((short)(unsigned)c1 > (signed char)(garr[i1 & 7u] - 8u)) | 1u)) & 255u);
                        if ((unsigned)h1) continue;
                        w0 ^= (unsigned long long)(p2 % (i0 | 1u)) << ((g1 / ((unsigned)h1 | 1u)) & 63u);
                    }
                    { unsigned t3; double z3; if (((unsigned)(((unsigned)d0 * *q0) || 5u)) & 1u) { t3 = ((unsigned)w0 | 0xb7e22becu); z3 = (double)(((unsigned)((p1 ^ u2) == 0x7fffffffu)) & 255u); } if (((unsigned)(((unsigned)d0 * *q0) || 5u)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                        if (u1) break;
                        g0 = (unsigned)(((unsigned)w0 << (u2 & 31u)) == u3);
                        break; (void)(-(unsigned)((unsigned)f0 || garr[u2 & 7u]));
                        if ((unsigned)((r0.x >> (0x74d08b53u & 31u)) && i2)) goto L4;
                        if ((*q0 % ((0x1a5d75ecu % (*mp | 1u)) | 1u))) break;
                        if (((unsigned)l0 - (unsigned)((short)p2 > (signed char)p0))) {
                            goto done;
                            if ((unsigned)s0) break;
                            d0 = d0 * 0.5 + (double)(garr[u2 & 7u] & 1023u);
                            if (u3 == 7u) return 0x8cad5b73u;
                        }
                    }
                }
            }
        }
    }
    goto L0;
    if ((unsigned)((unsigned)((int)0xffffffffu >= (int)2u) == p2)) goto L1;
    if ((unsigned)((unsigned)x0 && 0x48d36f1du)) goto L4;
    *mp = ~((unsigned)((int)(r0.y & (unsigned)l0) >= (int)i0) / ((unsigned)(g1 == u0) | 1u));
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)(fuel || ((unsigned)x0 + 1u)));
    }
    if (((0x10000u | (unsigned)w0) ^ p0)) goto done;
    h1 = (unsigned short)(h1 + ~((unsigned)(short)(unsigned)((int)(unsigned)w0 >= (int)v0) << ((unsigned)s1 & 31u)));
    goto L0;
    if (((unsigned)l0 << (0x4c110d94u & 31u))) goto L3;
    s0 = (int)(2u >> (((unsigned)h1 ? 0x10000u : (unsigned)h1) & 31u));
    if ((0x10000u - (i2 % (u1 | 1u)))) {
        if ((fuel - (unsigned)(short)(unsigned)((int)a0[u1 & 3u] < (int)u0))) goto done;
        if (r0.x) goto done;
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((u2 | (unsigned)(0u || (unsigned)h1))) break;
            switch ((unsigned)c1 & 7u) {
                goto L0;
                case 6u: ;
                case 5u: ;
                case 3u: ;
                c0 = (unsigned char)p0;
                for (;;) { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)((unsigned)(-(u2 >> (i0 & 31u)) && 1u) & 1023u);
                        a0[0x7b889b15u & 3u] = -(g1 - (unsigned)((int)((unsigned)((unsigned)w0 && 8u) ^ 0x18483efeu) < (int)5u));
                        case 7u: ;
                    }
                    if (((2u >> (0x10000u & 31u)) ^ a0[i0 & 3u])) continue;
                    for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        default: ;
                        b0 = (v0 * 0xfb553259u) != 0u;
                        g1 += (i2 - u1);
                        { unsigned t4; double z4; if (((unsigned)((int)0x80000000u >= (int)0x3df887ccu)) & 1u) { t4 = (unsigned)(v0 || v0); z4 = (double)(((5u | p1)) & 255u); } if (((unsigned)((int)0x80000000u >= (int)0x3df887ccu)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                            w0 ^= (unsigned long long)(unsigned)((unsigned)h0 || 0x8c20101u) << ((unsigned)((short)(p0 ^ (0x5c3de86au ? (unsigned)b0 : (unsigned)(x0 >> 70))) > (signed char)0xdee927b4u) & 63u);
                            q0 = &garr[(i1 | r0.y) & 7u];
                            case 4u: ;
                            if (fuel < 8u) return (r0.y - (unsigned)d0);
                        }
                    }
                    case 1u: ;
                }
            }
        }
        goto L4;
    }
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (~(unsigned)(0x10000u < 0xddaa1e20u)) goto L4;
            if ((2u * *q0)) break;
            if ((unsigned)(short)(6u + (0xffffffffu << (a0[u1 & 3u] & 31u)))) break;
            break; (void)(~(unsigned)((short)i1 > (signed char)(unsigned)(a0[i0 & 3u] == (unsigned)h1)));
            m0 ^= i1;
        }
    } while (i0++ < 7u && (unsigned)((int)(unsigned)s1 >= (int)~((unsigned)d0 << (i0 & 31u))));
    goto L1;
    if ((0x8d23c75cu / ((unsigned)((int)a0[i0 & 3u] >= (int)garr[i1 & 7u]) | 1u))) {
        if ((a0[i0 & 3u] >> (*q0 & 31u))) goto L3;
        switch (u2 & 7u) {
            do { if (--fuel == 0u) goto done;
                case 6u: ;
                case 2u: ;
                if ((r0.x + v0)) break;
            } while (i0++ < 2u && (a0[i0 & 3u] >> ((unsigned)(0x68d8bdbu && (unsigned)f0) & 31u)));
            i2 = (unsigned)((int)*q0 >= (int)(0x52e5a525u << (*mp & 31u))) & 15u;
            if ((((unsigned)d0 & 0u) ^ fuel)) {
                c1 = (signed char)~(unsigned)((unsigned)e0 && (unsigned)(w0 >> 29));
            }
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                a0[(p0 | 0x80000000u) & 3u] = ((unsigned)((unsigned)b0 < (unsigned)f0) >> (((unsigned)h1 * (unsigned)d0) & 31u));
                u2 = u2 * 0x9e3779b1u + ~(unsigned)((unsigned)f0 < (unsigned)!(i2 % (0x10000u | 1u)));
                garr[(unsigned)s1 & 7u] = 0x7fffffffu;
                do { if (--fuel == 0u) goto done;
                    case 7u: ;
                    case 4u: ;
                } while (i1++ < 4u && (unsigned)((0xed2ed065u | 1u) == 0x30355eccu));
                if ((unsigned)(((unsigned)c0 & 0xffffffffu) == *mp)) continue;
                default: ;
            }
            m0 ^= (unsigned)((unsigned)(signed char)(m0 / (garr[u2 & 7u] | 1u)) == (unsigned)(x0 >> 70));
            d0 = d0 * 0.5 + (double)((unsigned)!(0x80000000u / (((unsigned)((int)0xffffffffu >= (int)(unsigned)h0) ? 0x95cde7b8u : (unsigned)b0) | 1u)) & 1023u);
        }
        if ((unsigned)(x0 >> 70)) {
            u0 = u0 * 0x9e3779b1u + ((unsigned)(signed char)(unsigned)((int)a0[u1 & 3u] >= (int)a0[i0 & 3u]) ^ (unsigned)h1);
            goto L0;
        } else {
            { unsigned t5; double z5; if ((u3) & 1u) { t5 = g1; z5 = (double)(((unsigned)(u3 && p1)) & 255u); } if ((u3) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                if ((unsigned)(signed char)(unsigned)((int)(unsigned)l0 >= (int)-((unsigned)w0 + 0xffffffffu))) goto L2;
                for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    g1 += (unsigned)!(g1 << ((unsigned)((short)0x9be42443u > (signed char)0x9c7694aeu) & 31u));
                }
                d0 = d0 * 0.5 + (double)((unsigned)((0x10000u & (unsigned)(a0[u1 & 3u] == (unsigned)e0)) < 0x51c39162u) & 1023u);
                goto L0;
                *q0 += (unsigned)((((unsigned)h1 | garr[u2 & 7u]) >> ((unsigned)(w0 >> 29) & 31u)) < 0x1be889fcu);
            }
            goto L4;
            for (;;) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(0x80000000u & 255u);
                *mp = (u2 ^ (unsigned)!(unsigned)(0x7fffffffu == -(7u * garr[u2 & 7u])));
                w0 = w0 * 6364136223846793005ull + 0x51bdfd25u;
            }
            u0 += (unsigned)((int)u0 >= (int)((unsigned)l0 / (6u | 1u)));
        }
        m0 ^= 0x82cf4668u;
    }
    if ((((unsigned)d0 & u2) + *mp)) goto L3;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(w0 >> 29)) break;
        break; (void)(8u);
        break; (void)(~(u0 & 0xffffffffu));
    } while (i0++ < 6u && (r0.y | (unsigned)b0));
    do { if (--fuel == 0u) goto done;
        while (i1++ < 4u && (9u | p0)) { if (--fuel == 0u) goto done;
            { unsigned t6; double z6; if (((unsigned)((short)0xffbfcad6u > (signed char)0xffffffffu)) & 1u) { t6 = 0xffffffffu; z6 = (double)((8u) & 255u); } if (((unsigned)((short)0xffbfcad6u > (signed char)0xffffffffu)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                if ((unsigned)l0) break;
                m0 ^= (unsigned)(unsigned char)(unsigned)((int)(unsigned)x0 < (int)p0);
                *mp = (unsigned)!(unsigned)((int)(0u - v0) < (int)0x80000000u);
                break; (void)((unsigned)!(unsigned)((int)0xd38852b0u >= (int)g0));
                s0 = (int)(unsigned)c1;
                while (i2++ < 6u && (unsigned)(v0 && r0.x)) { if (--fuel == 0u) goto done;
                    if (0xffffffffu) break;
                    if ((u0 | (i0 - 0x80000000u))) break;
                    if ((1u | u1)) goto L0;
                }
            }
            if (*mp) {
                if (0x10000u) break;
                u1 = (unsigned)((int)garr[u2 & 7u] < (int)0x80000000u);
                i1 = ((unsigned)h1 >> ((unsigned)(p0 == v0) & 31u)) & 15u;
            }
            if (9u) break;
            e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)((int)p2 >= (int)g0) & 1023u);
            h1 = (unsigned short)(h1 + ~(unsigned)((int)5u >= (int)(unsigned)d0));
            s1 = (int)((unsigned)s1 + 6u);
        }
        if (garr[u2 & 7u]) break;
    } while (i0++ < 3u && *mp);
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = (unsigned)((unsigned)((int)u2 < (int)g1) || (0xffffffffu | i0));
        if ((u0 + 0xffffffffu)) continue;
        d0 = d0 * 0.5 + (double)(((0x4b6357ddu - (unsigned)s1) + (unsigned)c0) & 1023u);
        if ((unsigned)((short)0x67f7978du > (signed char)(unsigned)w0)) break;
        if ((fuel ^ (0x9e996a4u >> (m0 & 31u)))) goto L4;
    }
    if (((unsigned)(4u == (unsigned)(x0 >> 70)) / (*q0 | 1u))) goto L0;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        u1 ^= (-(unsigned)((unsigned)((int)(unsigned)s0 < (int)*mp) && 5u) * i2);
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch (m0 & 7u) {
                do { if (--fuel == 0u) goto done;
                    *q0 += -(*q0 + ((unsigned)((short)u3 > (signed char)(5u | 0xb8c84ad7u)) >> (0xd5f4d0bfu & 31u)));
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(g0 == *q0) < u2));
                    if ((unsigned)f0) goto L0;
                    if ((unsigned)w0) break;
                } while (i2++ < 4u && ((unsigned)f0 + *mp));
            }
            if ((unsigned)!(((unsigned)c1 * g1) ^ 0x4de7d08au)) break;
            break; (void)((unsigned)s0);
            while (i2++ < 5u && r0.y) { if (--fuel == 0u) goto done;
                r0.x = (-(unsigned)((int)p0 < (int)garr[u2 & 7u]) & (0x396a9341u - u0));
            }
        }
        if ((unsigned)(4u && (unsigned)((int)0x50362eaeu < (int)g1))) {
            r0.x = ((*mp << (u3 & 31u)) % (0u | 1u));
            { unsigned t7; double z7; if ((~(garr[i1 & 7u] ^ 0x674629b7u)) & 1u) { t7 = (unsigned)(unsigned char)(unsigned)((int)*mp >= (int)v0); z7 = (double)(((unsigned)(a0[u1 & 3u] == garr[i1 & 7u])) & 255u); } if ((~(garr[i1 & 7u] ^ 0x674629b7u)) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                if ((unsigned)((int)(unsigned)l0 >= (int)(unsigned)(8u || garr[i1 & 7u]))) {
                    m0 ^= (a0[i0 & 3u] / ((3u / ((unsigned)d0 | 1u)) | 1u));
                } else {
                    h0 = (short)(*mp - 0x7fffffffu);
                    if ((unsigned)((short)(unsigned)f0 > (signed char)(0u - 3u))) continue;
                }
                *mp = (unsigned)((p2 | (unsigned)((int)p2 < (int)(unsigned)h1)) || 0x2fc787a0u);
                g1 += (((unsigned)((int)u0 < (int)r0.y) ? 0x3d8cb04eu : p1) / (7u | 1u));
                if ((0x9fec1277u + *mp)) break;
            }
            if ((((unsigned)(x0 >> 70) / ((unsigned)w0 | 1u)) | *mp)) break;
        } else {
            switch ((unsigned)((short)(unsigned)c1 > (signed char)garr[i1 & 7u]) & 7u) {
                if ((unsigned)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)fuel) == (unsigned)c0)) {
                    r0.y ^= (unsigned)(0x80000000u == (garr[i1 & 7u] % ((r0.y - u2) | 1u)));
                    continue; (void)((unsigned)(*mp == 0xffffffffu));
                    h0 = (short)((0xadfc63cbu * (unsigned)(w0 >> 29)) % ((unsigned)e0 | 1u));
                    case 3u: ;
                    if ((unsigned)((int)0xffffffffu >= (int)(unsigned)(g0 == (unsigned)c1))) goto L2;
                } else {
                    case 7u: ;
                    if ((6u << ((unsigned)((int)0xffffffffu < (int)(unsigned)e0) & 31u))) continue;
                    if (fuel < 8u) return ((unsigned)((int)i0 < (int)(unsigned)c0) | 0x3bb33fddu);
                    h0 = (short)(unsigned)((int)(unsigned)e0 >= (int)(unsigned)x0);
                }
                { unsigned t8; double z8; if (((p0 ? u0 : 0xa1a00cf9u)) & 1u) { t8 = (r0.x | fuel); z8 = (double)(((unsigned)((unsigned)(x0 >> 70) == (unsigned)(unsigned char)((unsigned)l0 + u0))) & 255u); } if (((p0 ? u0 : 0xa1a00cf9u)) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                    if ((p0 ? (unsigned)(x0 >> 70) : (unsigned)f0)) goto L2;
                }
                *q0 += v0;
            }
            break; (void)((i0 & (fuel >> (0xaea9548bu & 31u))));
            m0 ^= (((unsigned)(unsigned char)(v0 ^ 0x80d0a843u) * 0xc921e7f2u) ^ 0xffffffffu);
        }
        while (i1++ < 5u && ((unsigned)b0 - (a0[u1 & 3u] << (u2 & 31u)))) { if (--fuel == 0u) goto done;
            break; (void)(0xe43be905u);
            w0 = w0 * 6364136223846793005ull + (unsigned)(fuel || (unsigned)((unsigned)w0 || (9u >> ((unsigned)e0 & 31u))));
            if ((u0 - (unsigned)(w0 >> 29))) break;
        }
    }
    { unsigned t9; double z9; if (((unsigned)(unsigned char)((unsigned)s1 % (0xffffffffu | 1u))) & 1u) { t9 = (unsigned)((short)0x10000u > (signed char)0x83e4fd99u); z9 = (double)(((r0.x << (3u & 31u))) & 255u); } if (((unsigned)(unsigned char)((unsigned)s1 % (0xffffffffu | 1u))) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
        if (i2) {
            c0 = (unsigned char)(unsigned)(signed char)(unsigned)((short)(2u + 0x3413fbc3u) > (signed char)6u);
        }
        e0 = e0 * 0.5L + (long double)((0x10000u & (0x2d5082e6u * (unsigned)(short)((unsigned)e0 % (i1 | 1u)))) & 1023u);
    }
    if ((unsigned)c1) goto L4;
    x0 = x0 * 0x100000001b3ull + ((unsigned)(unsigned char)((*q0 ^ 4u) % ((unsigned)w0 | 1u)) % ((unsigned)(short)(unsigned)(8u == u3) | 1u));
    u0 += (0x10000u & (unsigned)c1);
    goto L4;
    f0 = f0 * 0.5f + (float)((((unsigned)h1 + (unsigned)h0) & (r0.y * r0.x)) & 255u);
    b0 = (unsigned)((short)i0 > (signed char)0x6e683a7u) != 0u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (((unsigned)h0 + (unsigned)(2u && 9u))) {
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)((int)r0.x < (int)u2) < u3), (0x7fffffffu % ((r0.y ^ (unsigned)e0) | 1u)), ((g0 / ((unsigned)h0 | 1u)) >> ((unsigned)w0 & 31u))); }
    } else {
        L0: if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + -(unsigned)((short)(8u ^ (unsigned)!(unsigned)((int)i1 < (int)a0[u1 & 3u])) > (signed char)(unsigned)s0));
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            u1 = ((unsigned)((int)(unsigned)s0 < (int)(unsigned)b0) ? ((unsigned)s0 % ((unsigned)s0 | 1u)) : u3);
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(((unsigned)w0 - (unsigned)x0) < garr[u2 & 7u]), ((unsigned)b0 >> ((unsigned)(signed char)(m0 >> (r0.y & 31u)) & 31u)), (p1 >> (fuel & 31u))); }
            }
            h1 = (unsigned short)(h1 + ((0x7fffffffu ^ (unsigned)x0) ^ (0x949d9fe0u & (i1 >> (p0 & 31u)))));
        }
        h1 = (unsigned short)(h1 + (r0.x & (7u << ((0x80000000u ? r0.y : i0) & 31u))));
    }
    switch (((unsigned)w0 / (6u | 1u)) & 7u) {
        garr[(unsigned)(short)(unsigned)(v0 < 0x7fffffffu) & 7u] = (((u0 - g1) % (u1 | 1u)) * (unsigned)(signed char)(0u << ((unsigned)b0 & 31u)));
        { unsigned t0; double z0; if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0x7fffffffu)) & 1u) { t0 = (unsigned)((int)(0x3da65329u | 0x80000000u) < (int)(unsigned)h1); z0 = (double)((0x7fffffffu) & 255u); } if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0x7fffffffu)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            { unsigned t1; double z1; if ((~(g1 % (p1 | 1u))) & 1u) { t1 = (unsigned)!(unsigned)((short)u1 > (signed char)(unsigned)c1); z1 = (double)((*mp) & 255u); } if ((~(g1 % (p1 | 1u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                w0 = w0 * 6364136223846793005ull + ((0xffffffffu ^ 4u) | 7u);
            }
            x0 = x0 * 0x100000001b3ull + (r0.y | (unsigned)(w0 >> 29));
            if (~(unsigned)((int)0xa8bae89cu >= (int)(u0 - 5u))) goto L4;
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                goto L2;
                i0 = (((unsigned)w0 & 0x7fffffffu) >> ((unsigned)(short)(unsigned)((int)0x7fffffffu >= (int)(unsigned)(signed char)(unsigned)((unsigned)x0 && 0xffffffffu)) & 31u)) & 15u;
                switch (0xd483e1f8u & 7u) {
                    L1: if (--fuel == 0u) goto done;
                    case 0u: ;
                    case 3u: ;
                }
            }
        }
        g0 = (unsigned)((m0 << ((3u / (r0.x | 1u)) & 31u)) < (0x53289507u >> (0x80000000u & 31u)));
        if ((unsigned)(short)(unsigned)((int)(unsigned)s1 < (int)u2)) {
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 6u: ;
                if ((unsigned)((int)(unsigned)s1 >= (int)0xd0ef9c06u)) continue;
                goto done;
            }
            L2: if (--fuel == 0u) goto done;
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
            }
        }
        case 2u: ;
        d0 = d0 * 0.5 + (double)(i0 & 1023u);
    }
    switch ((unsigned)((short)p2 > (signed char)garr[u2 & 7u]) & 7u) {
        w0 ^= (unsigned long long)0x7d33af3u << ((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)f0) & 63u);
        q0 = &garr[(unsigned)(short)((unsigned)((unsigned)x0 < (unsigned)(g0 && p0)) ? garr[i1 & 7u] : (unsigned)c1) & 7u];
        if ((unsigned)(1u < (0xffffffffu % (0xffffffffu | 1u)))) {
            L4: if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (((unsigned)w0 - p2) * garr[i1 & 7u]));
            h0 = (short)((unsigned)(*q0 && 4u) >> ((r0.x ^ g1) & 31u));
        } else {
            r0.x = ((unsigned)(garr[i1 & 7u] < (i1 + (p1 ^ (unsigned)(x0 >> 70)))) - 0x80000000u);
            m0 ^= (unsigned)h1;
        }
    }
    b0 = (unsigned)((int)(unsigned)((int)(unsigned)s1 >= (int)i1) < (int)(unsigned)c1) != 0u;
    if (r0.x) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                g0 = m0;
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (r0.y) break;
                    break; (void)(((unsigned)d0 * 0x80000000u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)0x8a809e17u > (signed char)p0), ~(unsigned)((short)((unsigned)b0 % (0x2016bc38u | 1u)) > (signed char)0xffffffffu), ((unsigned)h0 | u1)); }
                    *q0 += (unsigned)((p1 >> (0x2a1aed39u & 31u)) < (0x7fffffffu + p2));
                    r0.x = (((unsigned)s1 - (r0.x & (unsigned)(x0 >> 70))) - 0x10000u);
                }
                if ((unsigned)((int)8u < (int)(unsigned)(0xcf47e28cu == r0.y))) goto L2;
                for (;;) { if (--fuel == 0u) goto done;
                    u2 ^= (unsigned)(signed char)((unsigned)((unsigned)s0 == (0xd119bc47u ^ (unsigned)s0)) & (unsigned)x0);
                    if ((p1 ? m0 : 0x656e4f6eu)) {
                        l0 = (long)((unsigned long)l0 + (fuel & ~((i1 | (unsigned)h0) % ((0x280c20d0u - g1) | 1u))));
                        if (((unsigned)w0 & 0x221177a4u)) goto L1;
                        w0 = w0 * 6364136223846793005ull + (g0 + (unsigned)l0);
                        if (garr[u2 & 7u]) continue;
                        if ((r0.x / ((a0[i0 & 3u] - (unsigned)s1) | 1u))) goto L3;
                        g1 += ((unsigned)s1 + -((unsigned)((int)(8u & i0) < (int)0x547a9220u) * 0xba210abau));
                    }
                    goto L1;
                }
                q0 = &garr[(unsigned)(unsigned char)((0x30714b00u % ((unsigned)(short)(unsigned)((short)(unsigned)(unsigned char)(unsigned)((int)(unsigned)h1 < (int)*q0) > (signed char)0x760f8bbfu) | 1u)) / ((unsigned)b0 | 1u)) & 7u];
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(g0, (v0 / (v0 | 1u)), (unsigned)(8u == 0x7fffffffu)); }
                    if ((unsigned)((int)0xffffffffu >= (int)((unsigned)f0 << (p1 & 31u)))) {
                        r0.x = 0xffffffffu;
                    } else {
                        *mp = (unsigned)((0xdea3ab68u & (unsigned)s0) == *q0);
                        c0 = (unsigned char)a0[i0 & 3u];
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)x0 / ((p2 ^ (unsigned)d0) | 1u)), 0x245dcdbfu, ((4u * (unsigned)h1) / (0xffffffffu | 1u))); }
                    }
                }
            } while (i1++ < 4u && 0xffdcb16fu);
            x0 = x0 * 0x100000001b3ull + ((garr[u2 & 7u] ? g1 : 8u) & (i0 % ((unsigned)c1 | 1u)));
            if ((unsigned)(0xba4810a1u && 9u)) {
                garr[(unsigned)((short)(unsigned)b0 > (signed char)i0) & 7u] = (((0xa3a0f08fu << (0x57c1447au & 31u)) * u3) >> (0xffffffffu & 31u));
                q0 = &garr[((i2 ? 0x10000u : a0[i0 & 3u]) / ((unsigned)h0 | 1u)) & 7u];
                f0 = f0 * 0.5f + (float)(p2 & 255u);
            } else {
                break; (void)((unsigned)(u3 && 0x332b9196u));
                u1 = ((unsigned)(signed char)(unsigned)(g0 == 8u) & u2);
            }
            s0 = (int)0xf6507152u;
        }
        w0 = w0 * 6364136223846793005ull + (unsigned)((((unsigned)h0 << ((unsigned)l0 & 31u)) ^ p0) == garr[i1 & 7u]);
        if ((unsigned)(0x80000000u && (*mp + 0x80000000u))) goto done;
    } else {
        if (((unsigned)w0 ? fuel : garr[u2 & 7u])) goto L2;
        d0 = d0 * 0.5 + (double)(0x10000u & 1023u);
        if ((unsigned)(w0 >> 29)) goto done;
    }
    do { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)(u2 < (unsigned)e0) & 1023u);
        if (((unsigned)s0 + ((unsigned)(x0 >> 70) << (u0 & 31u)))) {
            r0.x = ((unsigned)(g0 && i0) << ((3u << ((0x10000u ^ (unsigned)d0) & 31u)) & 31u));
            if (*q0) {
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)s0, (unsigned)l0, (6u ^ 0x80000000u)); }
                    if ((0xffffffffu >> ((unsigned)s1 & 31u))) break;
                } while (i1++ < 3u && 1u);
                s0 = (int)(unsigned)(unsigned char)((garr[i1 & 7u] | i2) << (i1 & 31u));
            }
            m0 ^= (((unsigned)(w0 >> 29) << (((unsigned)x0 % (p1 | 1u)) & 31u)) + (unsigned)(x0 >> 70));
            if (budget != 0u) { budget -= 1u; u2 = fn0(0xadb045ecu, (0x62bf2be3u / (0x10000u | 1u)), (0x2381102u & -(unsigned)(i1 && u1))); }
            do { if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)(short)(0x7fffffffu ? ~(g0 * (unsigned)f0) : ((unsigned)s0 & 0x7fffffffu)) & 7u];
                q0 = &garr[(unsigned)(w0 >> 29) & 7u];
                { unsigned t2; double z2; if (((unsigned)(5u == 9u)) & 1u) { t2 = 0x2be79c9bu; z2 = (double)(((unsigned)(p1 < ((unsigned)w0 + u0))) & 255u); } if (((unsigned)(5u == 9u)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    switch (0x80000000u & 7u) {
                        u0 ^= (unsigned)(0x4249f581u == ((unsigned)!(a0[u1 & 3u] - ((unsigned)(x0 >> 70) + i1)) * i1));
                        case 7u: ;
                        case 1u: ;
                    }
                    c0 = (unsigned char)(unsigned)((unsigned)((int)(unsigned)s1 >= (int)0x7fffffffu) == ((i2 % (fuel | 1u)) * r0.x));
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s0 + p1), 0x10000u, ((0x80000000u * p2) - 0x80000000u)); }
                    { unsigned t3; double z3; if ((i1) & 1u) { t3 = ((unsigned)h1 >> (((unsigned)e0 + i0) & 31u)); z3 = (double)((r0.x) & 255u); } if ((i1) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        u3 += 0x682177deu;
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(0x80000000u * (unsigned)(short)(0x42b2f68eu ^ p2)), (i2 / (garr[i1 & 7u] | 1u)), r0.y); }
                    b0 = (unsigned)((int)p1 >= (int)(unsigned)((short)u0 > (signed char)r0.x)) != 0u;
                }
                u1 += ((garr[u2 & 7u] ^ ((unsigned)(i1 || a0[u1 & 3u]) * 0x10000u)) & garr[i1 & 7u]);
            } while (i1++ < 7u && (0xf490d836u & (unsigned)((unsigned)b0 == 0xcd163d25u)));
        } else {
            do { if (--fuel == 0u) goto done;
                if (((unsigned)d0 ^ ((unsigned)w0 - v0))) {
                    do { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + ((unsigned)(x0 >> 70) >> (v0 & 31u));
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)d0 + i1), (~(unsigned)((int)p0 >= (int)(unsigned)(x0 >> 70)) + 0xf634cdf7u), 0x655db012u); }
                    } while (i2++ < 2u && (unsigned)(w0 >> 29));
                    if ((0x80000000u / ((unsigned)(unsigned char)(m0 & (unsigned)d0) | 1u))) break;
                    g0 = 0x80000000u;
                    if ((i1 + -(fuel * fuel))) break;
                    q0 = &garr[(unsigned)((u0 & 1u) || 0x10000u) & 7u];
                    goto L2;
                }
            } while (i1++ < 5u && u1);
            if ((fuel / (g1 | 1u))) break;
            switch (i1 & 7u) {
                u0 = (unsigned)((unsigned)h0 || garr[u2 & 7u]);
                if (budget != 0u) { budget -= 1u; u0 = fn0(((0x80000000u * p0) - u3), a0[i0 & 3u], garr[u2 & 7u]); }
                *q0 += ((unsigned)((0xcadccafeu ^ 0x9a2831fbu) && i0) >> ((unsigned)!((unsigned)c1 | (unsigned)(x0 >> 70)) & 31u));
            }
        }
        if ((unsigned)(unsigned char)(unsigned)((unsigned)(unsigned char)(i2 % (a0[i0 & 3u] | 1u)) || 4u)) {
            do { if (--fuel == 0u) goto done;
                switch (m0 & 7u) {
                    while ((u0 * 0x80000000u)) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(g1, ((unsigned)((int)(unsigned)l0 < (int)g1) % (0x33be1101u | 1u)), p2); }
                        u2 += (unsigned)((int)(u1 | 0xb758568cu) < (int)((unsigned)h0 << (1u & 31u)));
                    }
                }
                if (r0.y) break;
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)((int)i1 < (int)r0.x) + u2)) break;
                    d0 = d0 * 0.5 + (double)((0xb0a8f92u % ((unsigned)!(unsigned)((short)0xffffffffu > (signed char)0x10000u) | 1u)) & 1023u);
                    if (u3 == 7u) return (unsigned)(0xf38274fu < garr[i1 & 7u]);
                    garr[(r0.x >> (u3 & 31u)) & 7u] = ((unsigned)h0 | (unsigned)s1);
                }
            } while (i1++ < 2u && ((a0[u1 & 3u] + garr[i1 & 7u]) ^ (unsigned)(x0 >> 70)));
            do { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (8u) break;
                    continue; (void)(*mp);
                    s1 = (int)((unsigned)s1 + (unsigned)x0);
                    if (0x10000u) break;
                    if (fuel < 8u) return ((unsigned)l0 / ((unsigned)((short)(unsigned)e0 > (signed char)i1) | 1u));
                    while ((unsigned)((int)(m0 + 0x10000u) >= (int)(unsigned)f0)) { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)(unsigned)e0 < (int)0x10000u)) goto L3;
                        if (0x35ee646eu) break;
                        break; (void)((0x80000000u / ((unsigned)((short)p1 > (signed char)(unsigned)d0) | 1u)));
                        u2 = u2 * 0x9e3779b1u + ((unsigned)(unsigned char)(unsigned)((int)(unsigned)l0 >= (int)0xffffffffu) + (p0 | 0x7fffffffu));
                    }
                }
                if (((unsigned)(u1 && 0xa59255ddu) % (0xffffffffu | 1u))) continue;
                if ((unsigned)(short)(*q0 ? 0x5b8ba92cu : u0)) continue;
                v0 = (unsigned)(unsigned char)(u0 | *q0);
                if ((unsigned)((unsigned)c1 || a0[u1 & 3u])) break;
            } while (i1++ < 6u && (0x80000000u >> ((0xffffffffu % ((unsigned)s1 | 1u)) & 31u)));
            while ((unsigned)((short)m0 > (signed char)r0.y)) { if (--fuel == 0u) goto done;
                u3 = u3 * 0x9e3779b1u + (((unsigned)x0 - (0x7fffffffu * 0xef21e1ccu)) + u2);
                garr[(unsigned)((int)g1 < (int)a0[i0 & 3u]) & 7u] = (unsigned)(((unsigned)((short)0xdb4a3254u > (signed char)r0.y) + (unsigned)l0) || (fuel + a0[u1 & 3u]));
                u0 += ((unsigned)((unsigned)w0 < fuel) >> (garr[u2 & 7u] & 31u));
                b0 = 0x6bcd56c7u != 0u;
                *q0 += (unsigned)((short)i2 > (signed char)((unsigned)e0 >> ((unsigned)(x0 >> 70) & 31u)));
                if ((0xebaf375au / (*q0 | 1u))) continue;
            }
            if ((unsigned)(w0 >> 29)) goto L4;
            u2 ^= ((unsigned)(signed char)(2u & p0) ^ (unsigned)s1);
        } else {
            if (u3) break;
        }
        goto L2;
    } while (i0++ < 2u && (unsigned)b0);
    goto L1;
    u1 = (unsigned)(a0[u1 & 3u] && (unsigned)(u3 || 0xd097bd55u));
    w0 = w0 * 6364136223846793005ull + (((unsigned)!((unsigned)c0 | (unsigned)(w0 >> 29)) | *mp) | (unsigned)((int)p0 < (int)u3));
    if (budget != 0u) { budget -= 1u; u0 = fn0(*mp, *mp, (~(garr[u2 & 7u] >> (u0 & 31u)) * (unsigned)s0)); }
    d0 = d0 * 0.5 + (double)(((unsigned)c1 << (i0 & 31u)) & 1023u);
    h0 = (short)(0x6a54e129u ^ i1);
    a0[a0[u1 & 3u] & 3u] = (unsigned)!(unsigned)((short)(unsigned)c1 > (signed char)(unsigned)(u3 || u3));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + ((unsigned)c1 % (0x8dd81779u | 1u)));
        v0 = ((unsigned)(w0 >> 29) << ((0x6dcae801u ^ (unsigned)((int)g1 < (int)(unsigned)c1)) & 31u));
        if ((unsigned)w0) {
            switch (a0[u1 & 3u] & 7u) {
                if ((unsigned)((unsigned)s1 && 6u)) continue;
                case 7u: ;
                x0 = x0 * 0x100000001b3ull + (unsigned)(short)((unsigned)(short)((unsigned)(signed char)(7u & 0xf3dae0c8u) | (unsigned)(short)(0xec8b9fffu % (u1 | 1u))) >> (0x92103871u & 31u));
            }
            m0 ^= ((unsigned)x0 | (unsigned)(w0 >> 29));
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)x0 >= (int)0x9678f143u)) break;
                if (budget != 0u) { budget -= 1u; u2 = fn0(0x10000u, (unsigned)e0, 0x352e3b19u); }
                r0.x = ((unsigned)(signed char)(unsigned)(i2 || p0) / (-((unsigned)s0 * (unsigned)((int)i0 >= (int)0xffffffffu)) | 1u));
            } while (i1++ < 5u && ((unsigned)s0 << ((unsigned)(x0 >> 70) & 31u)));
            i1 = ((0xffffffffu ^ *q0) ^ (u1 >> (9u & 31u))) & 15u;
        }
        g1 += (0x59a3af02u | a0[i0 & 3u]);
        if (((unsigned)h0 & (unsigned)((unsigned)(x0 >> 70) || u0))) continue;
    }
    switch ((u2 | ((unsigned)s1 | 3u)) & 7u) {
        *q0 = 0x72322153u;
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(*q0 < ((unsigned)((unsigned)c1 || a0[i0 & 3u]) << (g0 & 31u))) || *q0) & 255u);
        q0 = &garr[(fuel & (a0[u1 & 3u] % ((unsigned)c0 | 1u))) & 7u];
        if ((unsigned)s1) {
            goto L1;
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                u3 = (unsigned)((u0 ^ (0xf61fe9a9u ^ (unsigned)(w0 >> 29))) < (p2 / (g0 | 1u)));
                continue; (void)((0x80000000u & a0[i0 & 3u]));
                g0 = (((unsigned)((int)(unsigned)c0 >= (int)(unsigned)h1) * (unsigned)c1) & 6u);
                v0 = ((unsigned)h0 << ((unsigned)(0xad32393fu || ((unsigned)l0 & (unsigned)c0)) & 31u));
            }
            u0 ^= (u2 + (0x10000u | (unsigned)(x0 >> 70)));
            *mp = (unsigned)(signed char)((unsigned)((unsigned)(signed char)(0x10000u + 7u) < (unsigned)x0) | (0xffffffffu >> (0x80000000u & 31u)));
        } else {
            if (budget != 0u) { budget -= 1u; u2 = fn0(a0[u1 & 3u], (unsigned)((int)m0 < (int)i1), (unsigned)((short)((unsigned)s1 << (0xffffffffu & 31u)) > (signed char)5u)); }
            if (budget != 0u) { budget -= 1u; u3 = fn0(i1, (unsigned)(signed char)((p0 % ((unsigned)s1 | 1u)) ^ (unsigned)f0), a0[u1 & 3u]); }
        }
        if (garr[i1 & 7u]) {
            if (((unsigned)c1 + g0)) goto L0;
            goto done;
            h0 = (short)0x80000000u;
        }
    }
    e0 = e0 * 0.5L + (long double)((unsigned)((short)-(unsigned)((short)(unsigned)((int)0x6a93cc5eu < (int)*q0) > (signed char)4u) > (signed char)0x4f41aa80u) & 1023u);
    garr[g1 & 7u] = fuel;
    g0 = ((u2 / ((unsigned)f0 | 1u)) * 0x13aaa70u);
    u0 += ((4u & g1) + 8u);
    g1 += 4u;
    for (;;) { if (--fuel == 0u) goto done;
        u3 = (unsigned)((unsigned)l0 || (unsigned)((int)(unsigned)(fuel || (unsigned)s0) < (int)(0xc4e27816u & (unsigned)l0)));
        if (u3 == 7u) return v0;
    }
    switch (~(unsigned)((int)*q0 < (int)(0x80000000u << ((unsigned)f0 & 31u))) & 7u) {
        if (budget != 0u) { budget -= 1u; u3 = fn0(((0x80000000u << (fuel & 31u)) * (unsigned)e0), (i0 << (0x2d705750u & 31u)), i1); }
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)(((fuel & (unsigned)((unsigned)(0x1f395895u == u3) == fuel)) % (0xffffffffu | 1u)) & 255u);
                    u0 = u0 * 0x9e3779b1u + r0.y;
                }
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    case 0u: ;
                    if (u3 == 7u) return (unsigned)((int)(unsigned)w0 < (int)9u);
                    if (0x80000000u) {
                        if (budget != 0u) { budget -= 1u; u3 = fn0(i1, 0xffffffffu, (unsigned)((unsigned)x0 && (unsigned)(u3 && (unsigned)b0))); }
                        h1 = (unsigned short)(h1 + (unsigned)((int)7u < (int)fuel));
                        if (budget != 0u) { budget -= 1u; u0 = fn0(0xc08c9130u, (unsigned)((int)(unsigned)w0 >= (int)(unsigned)s1), 0x23292039u); }
                        garr[u3 & 7u] = (unsigned)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x80000000u) == (r0.x * (unsigned)(signed char)((unsigned)s0 & (unsigned)s1)));
                        e0 = e0 * 0.5L + (long double)((unsigned)!(unsigned)((int)(unsigned)(9u || 0xffffffffu) < (int)(unsigned)c0) & 1023u);
                    } else {
                        default: ;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(garr[i1 & 7u], (unsigned)((short)(unsigned)s1 > (signed char)u0), (unsigned)(3u && (u0 + 3u))); }
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)c0, i0, garr[u2 & 7u]); }
                    }
                }
                if (budget != 0u) { budget -= 1u; u3 = fn0((0x89bc3a6u % ((unsigned)d0 | 1u)), 9u, (0x1d7511ccu + (unsigned)(unsigned char)((unsigned)e0 | garr[u2 & 7u]))); }
                if ((unsigned)(0xffffffffu && (unsigned)w0)) {
                    garr[(6u >> ((unsigned)c0 & 31u)) & 7u] = -(1u << ((unsigned)l0 & 31u));
                    if ((*q0 & (unsigned)(0xa9bd1d5u && 0xffffffffu))) continue;
                    s1 = (int)((unsigned)s1 + (unsigned)(6u < (unsigned)(0x5c49e43bu || (unsigned)w0)));
                    s0 = (int)m0;
                    h1 = (unsigned short)(h1 + (unsigned)((int)r0.y >= (int)(unsigned)l0));
                } else {
                    w0 = w0 * 6364136223846793005ull + v0;
                    case 3u: ;
                    { unsigned t4; double z4; if ((~(unsigned)((int)5u < (int)v0)) & 1u) { t4 = (unsigned)((int)g1 >= (int)(unsigned)(w0 >> 29)); z4 = (double)(((unsigned)((short)(unsigned)e0 > (signed char)((unsigned)l0 / (u3 | 1u)))) & 255u); } if ((~(unsigned)((int)5u < (int)v0)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                        r0.x = (i1 - ((*mp >> (garr[i1 & 7u] & 31u)) / ((unsigned)(i2 == 0xc761874eu) | 1u)));
                        case 2u: ;
                    }
                }
                switch (u0 & 7u) {
                    break; (void)(((unsigned)(i2 && garr[i1 & 7u]) * garr[u2 & 7u]));
                    m0 ^= (unsigned)(7u < (unsigned)(0x10000u && r0.x));
                    case 5u: ;
                }
            }
            if (fuel < 8u) return -(i2 & m0);
            if (((unsigned)e0 & (unsigned)((unsigned)f0 && 0xffffffffu))) goto L0;
        }
        d0 = d0 * 0.5 + (double)((unsigned)((p1 / (r0.y | 1u)) || ((unsigned)c0 | (unsigned)(x0 >> 70))) & 1023u);
    }
    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(8u && u1) && (i1 >> (a0[u1 & 3u] & 31u))));
    if (v0) {
        if ((unsigned)((int)0x3ea945bu >= (int)(unsigned)e0)) {
            if (0xc411b20cu) {
                if ((unsigned)((int)0xb92c702au < (int)i1)) goto L1;
                goto L3;
                if ((g0 / (garr[i1 & 7u] | 1u))) goto done;
            } else {
                *q0 += ((i0 | (unsigned)c0) >> (((unsigned)(i2 && 0xb8077b78u) << (p2 & 31u)) & 31u));
                if ((0x7fffffffu % ((unsigned)(0x7fffffffu == 4u) | 1u))) goto L1;
                w0 ^= (unsigned long long)garr[i1 & 7u] << (6u & 63u);
                u2 = u2 * 0x9e3779b1u + ((0xaa1faae8u % (0x10000u | 1u)) / ((5u / (0x80000000u | 1u)) | 1u));
            }
            if ((0x2eea2b72u % (i0 | 1u))) {
                if (r0.x) {
                    if ((((unsigned)h1 & (unsigned)d0) - v0)) goto L1;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((garr[i1 & 7u] ^ 6u), (unsigned)(w0 >> 29), (garr[i1 & 7u] * g1)); }
                    v0 = (5u >> ((*q0 << (garr[i1 & 7u] & 31u)) & 31u));
                    if (u3) goto L1;
                    g1 += (7u >> ((0u | (unsigned)((int)9u < (int)0u)) & 31u));
                } else {
                    g1 += a0[u1 & 3u];
                    d0 = d0 * 0.5 + (double)((((unsigned)(unsigned char)(0x7d7c9372u >> (r0.y & 31u)) | (unsigned)(short)((unsigned)b0 + 0u)) << ((unsigned)h0 & 31u)) & 1023u);
                    c0 = (unsigned char)((0x88f6067du - ((unsigned)s0 ? 0x10000u : v0)) | 0x80000000u);
                    c1 = (signed char)((unsigned)!((unsigned)(w0 >> 29) / ((unsigned)((unsigned)s0 < i2) | 1u)) & (r0.y | *mp));
                }
                a0[0x7fffffffu & 3u] = (0xa730ad84u / ((unsigned)(2u && 0x80000000u) | 1u));
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((i1 + (unsigned)(unsigned char)(m0 | (unsigned)(u2 && 0x14d5083au))) & 1023u);
                    s1 = (int)((unsigned)s1 + (0x80000000u >> (*q0 & 31u)));
                    switch (((unsigned)c0 & (unsigned)c0) & 7u) {
                        case 6u: ;
                        while (((unsigned)(w0 >> 29) * (garr[u2 & 7u] - *mp))) { if (--fuel == 0u) goto done;
                            q0 = &garr[((unsigned)w0 / (((unsigned)((short)r0.x > (signed char)0x7fffffffu) - 0xeb158586u) | 1u)) & 7u];
                            if (budget != 0u) { budget -= 1u; u1 = fn0((((unsigned)(x0 >> 70) / (r0.y | 1u)) >> (a0[u1 & 3u] & 31u)), (p0 + u1), (p0 - a0[i0 & 3u])); }
                            if (~((0x80000000u % (u0 | 1u)) / (7u | 1u))) continue;
                            l0 = (long)((unsigned long)l0 + (unsigned)((int)0x7fffffffu < (int)((2u - (unsigned)w0) ? i1 : (unsigned)s1)));
                        }
                        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                            s0 = (int)(p2 & (unsigned)((unsigned)h0 < (unsigned)c0));
                        }
                        u1 = (((unsigned)(0x53308513u || u3) - (u0 - *mp)) & 0x80000000u);
                    }
                    break; (void)((unsigned)(i0 < (unsigned)(u1 && fuel)));
                    if (((unsigned)s0 * (unsigned)((int)(unsigned)h0 < (int)u0))) continue;
                }
                if (0xffffffffu) goto L4;
                if (6u) goto L1;
                goto L0;
            } else {
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((0x10000u % (fuel | 1u))) goto L0;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((p1 * a0[u1 & 3u]), (unsigned)(0u < i2), (unsigned)((int)0x8a6f7d9du >= (int)0x7fffffffu)); }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)g1 > (signed char)(unsigned)!(unsigned)((unsigned)f0 && (unsigned)x0)), (unsigned)(0x3a59248du || (unsigned)(w0 >> 29)), garr[i1 & 7u]); }
                    if ((unsigned)(unsigned char)(-((unsigned)f0 % (7u | 1u)) ^ p0)) break;
                    g0 = (0xfab85703u ? (unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)s0) : 0u);
                }
                if ((unsigned)(short)(0xffffffffu >> (p2 & 31u))) {
                    for (;;) { if (--fuel == 0u) goto done;
                        if ((unsigned)s1) {
                            break; (void)(~(unsigned)((unsigned)x0 < (unsigned)w0));
                            q0 = &garr[(unsigned)(signed char)(unsigned)((int)(g1 << (g1 & 31u)) < (int)u0) & 7u];
                            if (fuel) goto L4;
                            r0.y ^= 0x7d282644u;
                            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((0x7fffffffu + 0x7fffffffu) == a0[i0 & 3u]), ((unsigned)(x0 >> 70) | 0x10000u), (unsigned)((short)((unsigned)e0 + i1) > (signed char)(unsigned)l0)); }
                            if (r0.y) break;
                        }
                        u0 ^= (unsigned)(4u == (unsigned)(w0 >> 29));
                    }
                    b0 = g0 != 0u;
                    *mp = ((unsigned)(p1 || 0x13decdf1u) | ((unsigned)f0 >> (garr[u2 & 7u] & 31u)));
                    goto L3;
                    if (9u) goto L2;
                } else {
                    g0 = (unsigned)((int)0x7fffffffu < (int)m0);
                    goto L3;
                    r0.x = (unsigned)((short)(unsigned)c1 > (signed char)(unsigned)((unsigned)(p2 < g0) < (g1 * p0)));
                }
                switch ((u2 / (0x84ac7855u | 1u)) & 7u) {
                    if ((unsigned)((unsigned)((int)(unsigned)h1 >= (int)g1) || 3u)) break;
                }
                goto L4;
            }
            e0 = e0 * 0.5L + (long double)(((a0[u1 & 3u] - p0) + (g1 << (0x6e318050u & 31u))) & 1023u);
            if (i1) goto done;
            *mp = (*mp * (unsigned)e0);
            if ((unsigned)((short)g0 > (signed char)0x7fffffffu)) {
                while (i0++ < 3u && 0xdbee964bu) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (unsigned)e0);
                }
                u2 = (unsigned)((unsigned)d0 < (unsigned)c0);
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((p1 % (((unsigned)b0 & (unsigned)l0) | 1u)));
                    if ((i0 + (unsigned)((unsigned)c0 && (unsigned)c1))) break;
                    e0 = e0 * 0.5L + (long double)(6u & 1023u);
                    s1 = (int)((unsigned)s1 + ((u1 ? (unsigned)(w0 >> 29) : (unsigned)h0) + u0));
                }
            } else {
                r0.y ^= (fuel ? g0 : garr[i1 & 7u]);
            }
        }
        b0 = m0 != 0u;
        if (r0.x) goto L2;
        s0 = (int)((unsigned)((unsigned)(signed char)(unsigned)((short)(unsigned)x0 > (signed char)r0.y) || fuel) ^ i1);
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((0x48e53ed5u ^ 0x6b043afcu) / (8u | 1u))) continue;
                x0 = x0 * 0x100000001b3ull + ((0xffffffffu + garr[i1 & 7u]) & (unsigned)w0);
                l0 = (long)((unsigned long)l0 + (unsigned)(short)(((unsigned)c1 * 3u) + (unsigned)e0));
                u3 = ((unsigned)!(a0[i0 & 3u] - *q0) * 8u);
                b0 = (((unsigned)c0 ^ (0xcb7f0464u ? *mp : (unsigned)h1)) & p1) != 0u;
                w0 = w0 * 6364136223846793005ull + (unsigned)((6u >> ((0x6c00644cu % ((unsigned)c1 | 1u)) & 31u)) && 0x7fffffffu);
            }
            do { if (--fuel == 0u) goto done;
                c1 = (signed char)(unsigned)(signed char)((unsigned)((short)5u > (signed char)(unsigned)s0) / (((unsigned)((short)0x2bcc8dc3u > (signed char)u0) | 0xb90ef413u) | 1u));
            } while (i1++ < 6u && m0);
            u1 = u1 * 0x9e3779b1u + (unsigned)(0x80000000u || g0);
            g1 += ((unsigned)((int)(unsigned)c1 >= (int)0x10000u) | (((unsigned)x0 ^ i2) & p2));
            d0 = d0 * 0.5 + (double)(((u2 - 0x9e5faf93u) & (0x2c54e5c2u - (0xffffffffu * (unsigned)(w0 >> 29)))) & 1023u);
        }
        goto L1;
    } else {
        if (fuel < 8u) return (unsigned)((int)(unsigned)((unsigned)b0 && (r0.y + u3)) < (int)(unsigned)s1);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if (((unsigned)l0) & 1u) { t0 = -(unsigned)((0x80000000u % (g0 | 1u)) || u0); z0 = (double)((((unsigned)(unsigned char)(unsigned)(g1 || (unsigned)s0) ^ (unsigned)x0)) & 255u); } if (((unsigned)l0) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        switch (g0 & 7u) {
            if (fuel < 8u) return ((i1 & (unsigned)h0) << (9u & 31u));
            m0 ^= (unsigned)((u3 & (unsigned)(x0 >> 70)) || (0x6374cdcfu >> (7u & 31u)));
            b0 = (i1 / (i0 | 1u)) != 0u;
            case 5u: ;
            *mp = ((2u / (0xbb7df1cau | 1u)) | i0);
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if ((2u) & 1u) { t1 = i2; z1 = (double)((0x10000u) & 255u); } if ((2u) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    if ((unsigned)(short)((unsigned)(u0 || p2) << (garr[i1 & 7u] & 31u))) break;
                    u1 ^= ((unsigned)s0 * (r0.y & (unsigned)(5u && (unsigned)((short)v0 > (signed char)(unsigned)h1))));
                }
                e0 = e0 * 0.5L + (long double)((unsigned)(p0 && u3) & 1023u);
                u1 ^= (p2 + p1);
                b0 = 0xb89c27ecu != 0u;
                { unsigned t2; double z2; if ((((unsigned)(signed char)(r0.y * u2) % (0x80000000u | 1u))) & 1u) { t2 = -(unsigned)(garr[i1 & 7u] || (unsigned)(m0 && (unsigned)c0)); z2 = (double)((((unsigned)e0 | 4u)) & 255u); } if ((((unsigned)(signed char)(r0.y * u2) % (0x80000000u | 1u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    m0 ^= (0x80000000u + ((unsigned)d0 - (unsigned)((int)0xffffffffu >= (int)0x10000u)));
                    l0 = (long)((unsigned long)l0 + (unsigned)!(7u - 7u));
                }
            }
        }
        goto L0;
        goto L4;
        x0 = x0 * 0x100000001b3ull + ((r0.x % (v0 | 1u)) << ((unsigned)(g0 && garr[i1 & 7u]) & 31u));
        s1 = (int)((unsigned)s1 + i0);
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + 0x5f9608aeu;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(w0 >> 29) || (unsigned)((short)0x10000u > (signed char)((unsigned)(unsigned char)((unsigned)h1 * i1) + (unsigned)h0))) & 255u);
                    u2 += (g1 ? (unsigned)x0 : garr[u2 & 7u]);
                    v0 = (garr[u2 & 7u] ? 0x5dd62ecu : (unsigned)x0);
                    L0: if (--fuel == 0u) goto done;
                    L1: if (--fuel == 0u) goto done;
                }
                u2 = u2 * 0x9e3779b1u + ((((unsigned)d0 / (0x7fffffffu | 1u)) - (unsigned)s1) / (0x6dbdaefu | 1u));
                if ((0x59be8dc1u & 9u)) continue;
            }
            if ((unsigned)s0) break;
            c0 = (unsigned char)((unsigned)(w0 >> 29) | (unsigned)c1);
        }
    }
    L2: if (--fuel == 0u) goto done;
    r0.x = (0x6b9bed7fu * (unsigned)!(unsigned)((unsigned)(0x80000000u == 5u) < u1));
    e0 = e0 * 0.5L + (long double)(0x80000000u & 1023u);
    while (i0++ < 4u && (unsigned)(0x7fffffffu < i1)) { if (--fuel == 0u) goto done;
        { unsigned t3; double z3; if (((unsigned)(unsigned char)(unsigned)((short)9u > (signed char)(unsigned)c1)) & 1u) { t3 = (a0[u1 & 3u] * garr[i1 & 7u]); z3 = (double)(((1u >> (u2 & 31u))) & 255u); } if (((unsigned)(unsigned char)(unsigned)((short)9u > (signed char)(unsigned)c1)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            if ((garr[u2 & 7u] / ((unsigned)(w0 >> 29) | 1u))) {
                garr[(unsigned)(0x89d71bfcu || 0xffffffffu) & 7u] = ((i1 / (0x2a2a686au | 1u)) + 0x10000u);
                f0 = f0 * 0.5f + (float)((0x5751554cu >> ((unsigned)(signed char)((p1 + (unsigned)b0) / ((unsigned)((int)(unsigned)w0 >= (int)3u) | 1u)) & 31u)) & 255u);
                { unsigned t4; double z4; if (((unsigned)(8u && (unsigned)c1)) & 1u) { t4 = (unsigned)(m0 && (0x733be405u + u0)); z4 = (double)((0xb4efee7cu) & 255u); } if (((unsigned)(8u && (unsigned)c1)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                    l0 = (long)((unsigned long)l0 + u3);
                    u0 = u0 * 0x9e3779b1u + (unsigned)((short)(r0.y + ((unsigned)s1 - a0[i0 & 3u])) > (signed char)(unsigned)((unsigned)(w0 >> 29) && (unsigned)(w0 >> 29)));
                }
                *q0 = (unsigned)c1;
                if (0x10000u) break;
                break; (void)(((v0 - (unsigned)x0) | r0.y));
            } else {
                { unsigned t5; double z5; if ((u2) & 1u) { t5 = (unsigned)((unsigned)f0 < i1); z5 = (double)(((unsigned)((int)a0[u1 & 3u] < (int)0x63049d49u)) & 255u); } if ((u2) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(0x6d36139u, i1, 1u); }
                        *mp = (i0 >> (((((unsigned)l0 + m0) / (fuel | 1u)) * (unsigned)b0) & 31u));
                        if ((unsigned)(signed char)(0x7fffffffu + (2u - (unsigned)(w0 >> 29)))) continue;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((0xffffffffu / ((unsigned)w0 | 1u)), (unsigned)((unsigned)s1 == p0), (6u + *mp)); }
                        L3: if (--fuel == 0u) goto done;
                    }
                    a0[~(p2 << (0x9484cefcu & 31u)) & 3u] = (unsigned)!(6u & (unsigned)c0);
                }
            }
            L4: if (--fuel == 0u) goto done;
            if (r0.x) break;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((int)0x7fffffffu < (int)*q0)) continue;
                c0 = (unsigned char)(((unsigned)l0 ^ (unsigned)((short)5u > (signed char)(unsigned)w0)) * (7u >> (0x128e36c0u & 31u)));
            } while (i1++ < 6u && (unsigned)s0);
            u2 = (p2 * (unsigned)((short)(unsigned)c0 > (signed char)u0));
            { unsigned t6; double z6; if (((unsigned)((int)(0xffffffffu + 0x198c3afbu) >= (int)(unsigned)w0)) & 1u) { t6 = (unsigned)s1; z6 = (double)(((unsigned)(0x92ff4bf0u && i1)) & 255u); } if (((unsigned)((int)(0xffffffffu + 0x198c3afbu) >= (int)(unsigned)w0)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                if (p1) break;
                if ((unsigned)e0) break;
                if ((unsigned)((int)2u < (int)v0)) break;
                goto done;
                if ((p2 ? p1 : garr[u2 & 7u])) break;
                if (0xe2173403u) {
                    s1 = (int)((unsigned)s1 + (((u2 + 0x7fffffffu) * (unsigned)(signed char)(unsigned)((int)v0 < (int)(unsigned)d0)) & (unsigned)s1));
                    if (((unsigned)h1 >> (((unsigned)e0 * p2) & 31u))) continue;
                    u3 += ((g0 ? u0 : (u3 >> (g0 & 31u))) + (unsigned)b0);
                }
            }
        }
    }
    if ((unsigned)((int)((unsigned)b0 * (unsigned)h1) < (int)0x80000000u)) goto done;
    w0 = w0 * 6364136223846793005ull + (0x2cc7b06u ^ (fuel ? fuel : 0x7fffffffu));
    w0 = w0 * 6364136223846793005ull + ((i2 / (0xf5a8ee64u | 1u)) ^ i2);
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)(a0[u1 & 3u] || (unsigned)(w0 >> 29)) >= (int)garr[i1 & 7u])) break;
        if ((unsigned)((short)fuel > (signed char)p1)) break;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((u3 >> (p2 & 31u)) & 7u) {
            do { if (--fuel == 0u) goto done;
                { unsigned t7; double z7; if (((i2 ^ i2)) & 1u) { t7 = m0; z7 = (double)(((unsigned)((short)0xe4efd3a1u > (signed char)(unsigned)((unsigned)l0 && 0x8c60540u))) & 255u); } if (((i2 ^ i2)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                    x0 = x0 * 0x100000001b3ull + ((unsigned)c0 & (unsigned)((int)0xf3950f72u < (int)0x10000u));
                    f0 = f0 * 0.5f + (float)((unsigned)(u1 == (unsigned)h0) & 255u);
                }
                if (0x10000u) continue;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)((unsigned)(x0 >> 70) % (p2 | 1u)) < (int)a0[i0 & 3u]), (unsigned)((int)(unsigned)b0 < (int)0xffffffffu), 0u); }
            } while (i1++ < 7u && (0x2bae42e9u - 2u));
            *q0 = ((7u % (((unsigned)h0 % ((unsigned)((int)0x10000u < (int)u2) | 1u)) | 1u)) + (unsigned)h0);
            switch ((8u | (unsigned)l0) & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)c1 < (unsigned)((unsigned)e0 == 0x7fffffffu)), (unsigned)!(p1 + 0x8ea934e4u), (unsigned)c1); }
            }
        }
        do { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((p0 ^ ((unsigned)h1 + 0x30f888dcu))) break;
                    *mp = (unsigned)(((unsigned)c1 - i0) == (unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)(9u < 0x10000u)));
                    if ((unsigned)((int)0x4ec0113au >= (int)(unsigned)c1)) break;
                    *q0 = (unsigned)(unsigned char)((0x7fffffffu & (unsigned)x0) << ((unsigned)(signed char)(unsigned)((unsigned)((unsigned)w0 < (unsigned)w0) == 0xffffffffu) & 31u));
                    garr[(unsigned)b0 & 7u] = g0;
                }
                r0.x = (unsigned)(g0 < (unsigned)((unsigned)h0 || (unsigned)s1));
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((7u * (unsigned)(0xf6cd9e5u || p1)), (0x5df6c884u >> ((unsigned)x0 & 31u)), (unsigned)((unsigned)h0 || (3u << (4u & 31u)))); }
            if ((unsigned)s0) break;
            if (fuel < 8u) return ((unsigned)(r0.x || ~(u2 << (r0.y & 31u))) >> (garr[i1 & 7u] & 31u));
        } while (i1++ < 7u && 1u);
        if (u2) continue;
        if ((unsigned)(signed char)(unsigned)((unsigned)s1 && i1)) break;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(unsigned char)((unsigned)h1 + (unsigned)(w0 >> 29))) break;
            a0[0x7fffffffu & 3u] = 0xb73cf87du;
            u2 += (unsigned)((unsigned)f0 || ((unsigned)(p1 == (unsigned)(3u < 0x80000000u)) / (*mp | 1u)));
            l0 = (long)((unsigned long)l0 + 4u);
        } while (i1++ < 6u && (0u ? u0 : (unsigned)h1));
    }
    if (0xffffffffu) goto L3;
    while (i0++ < 6u && *mp) { if (--fuel == 0u) goto done;
        a0[0xbfc49432u & 3u] = 7u;
        if (budget != 0u) { budget -= 1u; u2 = fn0(7u, fuel, (unsigned)b0); }
        *q0 += (p1 - garr[i1 & 7u]);
        m0 ^= (unsigned)!((p1 - (unsigned)((int)(unsigned)x0 < (int)u3)) - 0xdc154b4eu);
    }
    *q0 = (unsigned)(a0[i0 & 3u] && 0x10000u);
    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)s0 == (unsigned)(p1 < 0x80000000u)));
    l0 = (long)((unsigned long)l0 + ((unsigned)(unsigned char)(unsigned)((unsigned)(x0 >> 70) < ~((unsigned)h1 + u3)) << (i0 & 31u)));
    *q0 = ((unsigned)s0 << ((0x10000u ^ p1) & 31u));
    s1 = (int)((unsigned)s1 + (unsigned)!((unsigned)(((unsigned)(x0 >> 70) * *q0) || 4u) << ((garr[u2 & 7u] << (7u & 31u)) & 31u)));
    if (((unsigned)x0 & 0xdc3c801eu)) goto L2;
    c1 = (signed char)(unsigned)s0;
    i2 = (unsigned)!(((r0.y << (0xc8554009u & 31u)) << (u0 & 31u)) << ((6u - g1) & 31u)) & 15u;
    for (;;) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (0x10000u * (unsigned)((short)a0[i0 & 3u] > (signed char)r0.x));
            if (budget != 0u) { budget -= 1u; u3 = fn1(i1, (3u - 0xc753d058u), (unsigned)((0x7fffffffu % ((unsigned)l0 | 1u)) == (unsigned)s1)); }
            c0 = (unsigned char)((unsigned)(short)(0x7fffffffu | i1) / (garr[i1 & 7u] | 1u));
        } while (i1++ < 7u && 5u);
        e0 = e0 * 0.5L + (long double)((unsigned)(w0 >> 29) & 1023u);
        while ((unsigned)((int)8u >= (int)(unsigned)c1)) { if (--fuel == 0u) goto done;
            u0 = u1;
            *mp = (unsigned)((unsigned)!((*mp & (3u % (u2 | 1u))) % ((unsigned)c1 | 1u)) || 0x761a2a4au);
            if (-(r0.y ^ 0x10000u)) break;
            if (g0) break;
            u3 += ((unsigned)((int)a0[i0 & 3u] < (int)1u) | garr[u2 & 7u]);
        }
    }
    if ((unsigned)((short)(u3 ^ (unsigned)s0) > (signed char)m0)) {
        if (*q0) goto L1;
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)f0 == (unsigned)s1);
    switch ((p0 & p0) & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)5u < (int)(unsigned)h1), 0x810138e1u, (unsigned)(short)((unsigned)(p2 < 0xcc7f0ca4u) - u0)); }
        c0 = (unsigned char)((unsigned)s1 - (unsigned)((short)(unsigned)c0 > (signed char)0x51923475u));
        if (u0) {
            { unsigned t8; double z8; if (((unsigned)((unsigned)(garr[i1 & 7u] && g0) && 5u)) & 1u) { t8 = u0; z8 = (double)(((5u << (garr[i1 & 7u] & 31u))) & 255u); } if (((unsigned)((unsigned)(garr[i1 & 7u] && g0) && 5u)) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                s0 = (int)(garr[u2 & 7u] | (unsigned)((int)(unsigned)w0 >= (int)((unsigned)(9u == p2) << (a0[u1 & 3u] & 31u))));
            }
            if ((0x10000u % (4u | 1u))) {
                e0 = e0 * 0.5L + (long double)((7u >> ((unsigned)(g1 && (0x10000u >> (i0 & 31u))) & 31u)) & 1023u);
                switch ((0x9cb23a61u | (unsigned)((int)0x80000000u < (int)0x7fffffffu)) & 7u) {
                    if (budget != 0u) { budget -= 1u; u0 = fn0(5u, (unsigned)(short)(unsigned)(i2 && p1), 0xdb9924aau); }
                    u3 = u3 * 0x9e3779b1u + ((*q0 % (0xffffffffu | 1u)) ^ (*mp % ((a0[u1 & 3u] << (0x80000000u & 31u)) | 1u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)-((unsigned)l0 & r0.x) > (signed char)p1), (unsigned)((int)p0 < (int)(i1 | 0x10000u)), (unsigned)c0); }
                    b0 = (unsigned)(~(unsigned)((int)0x80000000u < (int)m0) && 0x80000000u) != 0u;
                    u3 ^= (unsigned)b0;
                    u0 ^= ((unsigned)((g1 ^ u2) && p0) | (0x225b6c0fu + (unsigned)(x0 >> 70)));
                }
                if (fuel < 8u) return (unsigned)(0xe458c2d7u == ~(unsigned)((short)(5u + garr[i1 & 7u]) > (signed char)(unsigned)(fuel && (unsigned)b0)));
            } else {
                q0 = &garr[*q0 & 7u];
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)l0 < m0) & 1023u);
                if (budget != 0u) { budget -= 1u; u3 = fn0((5u >> ((unsigned)d0 & 31u)), 0x4ab73b32u, a0[u1 & 3u]); }
            }
            case 6u: ;
            if (garr[u2 & 7u]) break;
            for (;;) { if (--fuel == 0u) goto done;
                { unsigned t9; double z9; if (((p0 >> (r0.x & 31u))) & 1u) { t9 = (g0 / ((unsigned)s1 | 1u)); z9 = (double)((((unsigned)(x0 >> 70) & 0x3649a9e4u)) & 255u); } if (((p0 >> (r0.x & 31u))) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                    u1 = p1;
                    while ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)((unsigned)(w0 >> 29) || (unsigned)f0))) { if (--fuel == 0u) goto done;
                        if ((garr[u2 & 7u] % ((unsigned)e0 | 1u))) break;
                    }
                    f0 = f0 * 0.5f + (float)(((i1 - (unsigned)x0) >> (garr[i1 & 7u] & 31u)) & 255u);
                    goto L0;
                }
                i0 = m0 & 15u;
                *q0 += (((unsigned)!(unsigned)((short)garr[u2 & 7u] > (signed char)(p2 >> (u1 & 31u))) - 0x7fffffffu) & p0);
                while (3u) { if (--fuel == 0u) goto done;
                    v0 = (r0.x >> (0xd991afb1u & 31u));
                    case 0u: ;
                    l0 = (long)((unsigned long)l0 + ((unsigned)(garr[i1 & 7u] == p2) * (unsigned)(i2 == (unsigned)(p2 < u3))));
                }
            }
        }
        break; (void)((unsigned)(u0 || fuel));
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            default: ;
            case 4u: ;
            if (7u) break;
            continue; (void)(i1);
            while (i1++ < 6u && (unsigned)(p2 && (1u - (unsigned)h1))) { if (--fuel == 0u) goto done;
                break;
                { unsigned t10; double z10; if ((u2) & 1u) { t10 = (unsigned)l0; z10 = (double)((0x46393229u) & 255u); } if ((u2) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                    *q0 += (unsigned)((int)0x10000u >= (int)((g1 >> (u2 & 31u)) / (0xffffffffu | 1u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)s0 + (u3 / ((unsigned)c0 | 1u))), (0xffffffffu - (garr[i1 & 7u] - u2)), (0x320e7ba2u ^ 0u)); }
                    *mp = ((unsigned)h0 * p2);
                    *q0 = (r0.y >> ((unsigned)(x0 >> 70) & 31u));
                    break;
                }
                while ((0x7fffffffu - (unsigned)((short)7u > (signed char)g0))) { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)!(fuel >> (((unsigned)((int)(unsigned)h0 < (int)(fuel << (u0 & 31u))) | 0xffffffffu) & 31u));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((garr[i1 & 7u] + (unsigned)((int)i2 < (int)0x80000000u)), (unsigned)(unsigned char)((unsigned)e0 << (p1 & 31u)), (u3 / (*mp | 1u))); }
                }
            }
            case 7u: ;
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)d0 % (5u | 1u)), (unsigned)s1, (p0 % ((unsigned)((int)1u >= (int)u1) | 1u))); }
            u0 = u0 * 0x9e3779b1u + g1;
            break;
            case 1u: ;
            if (budget != 0u) { budget -= 1u; u2 = fn1(m0, (unsigned)d0, u2); }
        }
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)(p1 == (((unsigned)(w0 >> 29) % (7u | 1u)) * 1u));
    *q0 = ((unsigned)h0 >> ((unsigned)((short)(unsigned)f0 > (signed char)(0xffffffffu + r0.y)) & 31u));
    *q0 = (unsigned)((int)(unsigned)l0 >= (int)g1);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 ^= *q0;
        do { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)(u0 < (a0[i0 & 3u] * (unsigned)f0)));
            if (((garr[i1 & 7u] + 0xd8c4d842u) << (r0.y & 31u))) break;
            if (budget != 0u) { budget -= 1u; u2 = fn0(-(unsigned)((int)0x91dcc3e3u < (int)(unsigned)l0), 9u, a0[i0 & 3u]); }
        } while (i1++ < 6u && (unsigned)((unsigned)c0 == (unsigned)h1));
        if ((unsigned)l0) {
            if (-(unsigned)((int)garr[i1 & 7u] >= (int)(*mp & v0))) {
                q0 = &garr[~(unsigned)(((m0 - 0xd34fd663u) ^ (unsigned)l0) < 0xffffffffu) & 7u];
                c1 = (signed char)(unsigned)((int)(*q0 & 0x7fffffffu) < (int)(unsigned)w0);
            } else {
                if (budget != 0u) { budget -= 1u; u2 = fn1((0xb5b0abccu % (*mp | 1u)), (unsigned)((short)1u > (signed char)((unsigned)c1 / (u2 | 1u))), (unsigned)!(p1 / ((0x4eea6ef8u % (a0[i0 & 3u] | 1u)) | 1u))); }
                break; (void)(((unsigned)(x0 >> 70) ? u0 : 0xffffffffu));
                v0 = (unsigned)(i1 && ((unsigned)(m0 < 0x538f2e2cu) & 0xffffffffu));
                do { if (--fuel == 0u) goto done;
                    if ((0xd8e11e47u & 0x72a7bb9bu)) {
                        if ((*q0 % ((unsigned)((int)(unsigned)h1 < (int)i0) | 1u))) break;
                        u1 = ((0x3d541910u | (0xffffffffu ^ r0.x)) - p0);
                        continue; (void)(u1);
                    } else {
                        *q0 += (((0x71db860eu & i1) % ((garr[u2 & 7u] & m0) | 1u)) << (i1 & 31u));
                        c0 = (unsigned char)(a0[u1 & 3u] & (~(unsigned)(p1 == 0x1985acedu) / ((unsigned)c1 | 1u)));
                    }
                } while (i1++ < 6u && (unsigned)f0);
            }
            switch ((g1 << ((unsigned)c0 & 31u)) & 7u) {
                u3 ^= (unsigned)(((unsigned)s1 * i1) || -((unsigned)c0 ? 0x7fffffffu : *q0));
                if (p2) continue;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((0x10000u + a0[u1 & 3u]), ((unsigned)((int)r0.y >= (int)0xffffffffu) | (unsigned)(x0 >> 70)), a0[i0 & 3u]); }
        }
        r0.x = (0x2ad193fbu % ((unsigned)(short)(unsigned)((short)(unsigned)(short)(i0 / (-(unsigned)(0x10000u == v0) | 1u)) > (signed char)u2) | 1u));
        w0 ^= (unsigned long long)fuel << ((unsigned)((int)(0x10000u / (p2 | 1u)) >= (int)g1) & 63u);
    }
    if (((unsigned)c0 >> (0x10000u & 31u))) {
        if (3u) {
            g1 += (unsigned)(a0[u1 & 3u] || (unsigned)(signed char)(unsigned)(u3 && (i1 ? 6u : i1)));
        }
        a0[i2 & 3u] = (r0.x - (unsigned)c1);
        d0 = d0 * 0.5 + (double)(0x397e1093u & 1023u);
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (0x4ce0b778u) break;
            s0 = (int)(0x8c036389u >> (5u & 31u));
            *mp = (unsigned)(0xb002d596u || garr[u2 & 7u]);
            if ((unsigned)((short)0x2fb2d187u > (signed char)(unsigned)((int)0x195c33ecu >= (int)i1))) {
                if (((unsigned)w0 * (unsigned)x0)) break;
                m0 ^= (((unsigned)x0 ^ fuel) * p2);
            } else {
                *mp = (unsigned)(w0 >> 29);
                if ((v0 * u2)) break;
            }
            d0 = d0 * 0.5 + (double)((i0 ? (unsigned)!((unsigned)e0 + (0x80000000u % (0xffffffffu | 1u))) : 0xffffffffu) & 1023u);
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    *mp = (i0 ? i0 : (unsigned)(*q0 < u3));
                    break; (void)((unsigned)(unsigned char)(garr[u2 & 7u] - v0));
                } while (i2++ < 4u && 0x10000u);
                garr[(unsigned)((int)(unsigned)(x0 >> 70) >= (int)i2) & 7u] = ((unsigned)e0 << (0x4bf911cfu & 31u));
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)0u >= (int)((unsigned)s1 / (0x80000000u | 1u)))) break;
                    b0 = 0x37ac258fu != 0u;
                    if ((unsigned)((unsigned)s0 == 0u)) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)c1 * (unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) == a0[i0 & 3u])), ((unsigned)x0 - ((unsigned)w0 | 9u)), garr[u2 & 7u]); }
                    garr[r0.x & 7u] = ((unsigned)!(0xe96756ccu << ((unsigned)((int)8u >= (int)0x1e0d519au) & 31u)) << (u2 & 31u));
                    if (((unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) && v0) * (unsigned)e0)) break;
                } while (i2++ < 4u && (unsigned)(u1 == garr[i1 & 7u]));
                { unsigned t11; double z11; if (((unsigned)((int)4u >= (int)0xff7c922u)) & 1u) { t11 = (v0 ^ p2); z11 = (double)(((unsigned)((short)0xffffffffu > (signed char)(3u % (u2 | 1u)))) & 255u); } if (((unsigned)((int)4u >= (int)0xff7c922u)) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
                    if ((u1 + 0xd542bf1u)) break;
                    m0 ^= u2;
                    *mp = (g0 % (u2 | 1u));
                    if ((0x80000000u >> (v0 & 31u))) break;
                    if (((r0.x - (unsigned)s1) | g1)) continue;
                    continue; (void)((unsigned)d0);
                }
                g0 = (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)(0x63ca1d60u || (unsigned)!(unsigned)((int)*mp < (int)(0x4a709939u % ((unsigned)b0 | 1u)))));
            }
        }
        if ((*mp / ((unsigned)s0 | 1u))) {
            if (u3 == 7u) return ((unsigned)(unsigned char)(unsigned)(1u == p0) << ((*q0 + 0x10000u) & 31u));
            do { if (--fuel == 0u) goto done;
                *mp = (unsigned)(((i2 << (0x10000u & 31u)) - (unsigned)(w0 >> 29)) < g0);
                *q0 += ((unsigned)s1 - g1);
                *mp = (unsigned)((int)g0 < (int)(unsigned)((short)(unsigned)((int)7u >= (int)(unsigned)(x0 >> 70)) > (signed char)5u));
                *mp = (unsigned)((int)(unsigned)!(unsigned)((unsigned)(w0 >> 29) || (unsigned)(w0 >> 29)) < (int)(unsigned)(garr[i1 & 7u] < *q0));
                if (((1u * 9u) | 0xf881e6b4u)) goto L3;
            } while (i0++ < 4u && (unsigned)c1);
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)x0 ^ (unsigned)h1), (8u >> (a0[i0 & 3u] & 31u)), (unsigned)((int)m0 >= (int)-(unsigned)((int)8u < (int)v0))); }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(v0);
        while (i1++ < 2u && (unsigned)(short)((u1 % (0x63a9e941u | 1u)) << (0xffffffffu & 31u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1((0x65a37364u / (9u | 1u)), ((unsigned)d0 & (unsigned)e0), p0); }
            c1 = (signed char)(unsigned)((int)((0x10000u | 0x10000u) - 3u) >= (int)(unsigned)((unsigned)h1 || *mp));
            h0 = (short)((unsigned)c1 | garr[u2 & 7u]);
            { unsigned t12; double z12; if ((((unsigned)(short)(unsigned)((unsigned)d0 == (unsigned)(x0 >> 70)) % (i2 | 1u))) & 1u) { t12 = (0xc4d955e7u << (p1 & 31u)); z12 = (double)((((0x424b5649u / (g1 | 1u)) / ((unsigned)(x0 >> 70) | 1u))) & 255u); } if ((((unsigned)(short)(unsigned)((unsigned)d0 == (unsigned)(x0 >> 70)) % (i2 | 1u))) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
                break; (void)((unsigned)b0);
                if ((unsigned)((int)5u < (int)(unsigned)(short)(9u | (unsigned)l0))) {
                    h1 = (unsigned short)(h1 + ((unsigned)l0 ? a0[u1 & 3u] : garr[i1 & 7u]));
                    h1 = (unsigned short)(h1 + (u1 << ((r0.y ? (unsigned)s0 : i0) & 31u)));
                    u1 += 0x7fffffffu;
                }
                if ((unsigned)s1) break;
                if (budget != 0u) { budget -= 1u; u2 = fn1(0xe96235aau, 0x80000000u, garr[u2 & 7u]); }
                if ((unsigned)(0x7fffffffu == (unsigned)((int)*q0 >= (int)(unsigned)w0))) {
                    u0 += ((8u ^ (1u | u0)) ^ ((unsigned)c1 / ((unsigned)l0 | 1u)));
                    switch ((8u * (unsigned)(7u || i1)) & 7u) {
                        l0 = (long)((unsigned long)l0 + (unsigned)(signed char)((unsigned)((int)p1 < (int)*q0) >> (6u & 31u)));
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)b0 ^ r0.x), (unsigned)(0xc8249a8fu == 0u), (p2 | (2u * 9u))); }
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(w0 >> 29), ((unsigned)((unsigned)c1 || p2) / (garr[u2 & 7u] | 1u)), ((unsigned)(u1 == 0xffffffffu) << (u2 & 31u))); }
                    if (((unsigned)(unsigned char)(fuel << (garr[u2 & 7u] & 31u)) % ((unsigned)e0 | 1u))) break;
                    if (((0x10c7263bu ^ u1) >> (0xb8d0f5b2u & 31u))) break;
                } else {
                    break; (void)((a0[u1 & 3u] - (unsigned)(p2 == 0u)));
                }
            }
            while ((unsigned)((unsigned)c0 && (unsigned)h0)) { if (--fuel == 0u) goto done;
                while (i0++ < 2u && g0) { if (--fuel == 0u) goto done;
                    { unsigned t13; double z13; if (((unsigned)((unsigned)h0 || 0x7a8f8786u)) & 1u) { t13 = (unsigned)w0; z13 = (double)(((4u % ((unsigned)(g0 || 0xd93a583bu) | 1u))) & 255u); } if (((unsigned)((unsigned)h0 || 0x7a8f8786u)) & 1u) { u1 += t13; d0 = d0 * 0.5 + z13; }
                        do { if (--fuel == 0u) goto done;
                            if ((unsigned)l0) goto L4;
                        } while (i1++ < 6u && (unsigned)((int)p1 < (int)p0));
                        if ((unsigned)(fuel < r0.y)) break;
                        v0 = (unsigned)(unsigned char)(i0 >> ((unsigned)(x0 >> 70) & 31u));
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)w0, *q0, (r0.y & i2)); }
                        if (budget != 0u) { budget -= 1u; u2 = fn0(0x7fffffffu, (unsigned)((int)(unsigned)(9u || g1) >= (int)9u), (unsigned)!((0x26e95fbbu & (unsigned)x0) ^ 0x7fffffffu)); }
                    }
                }
                if ((unsigned)(u3 || (unsigned)s0)) {
                    break; (void)((unsigned)c1);
                    while (i0++ < 2u && p1) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + ~(fuel + ((unsigned)w0 * (r0.y ? (unsigned)c0 : 3u))));
                        s1 = (int)((unsigned)s1 + 0xf64677eau);
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)h1), (unsigned)(unsigned char)((unsigned)((int)1u >= (int)(unsigned)(x0 >> 70)) - *mp), (p0 / ((u2 + u0) | 1u))); }
                }
                if (((unsigned)x0 % (v0 | 1u))) break;
                if (p0) {
                    if ((unsigned)(0xaf50f6d3u == (unsigned)c1)) continue;
                    if (fuel < 8u) return 0x7fffffffu;
                    continue; (void)((unsigned)(r0.y && (unsigned)d0));
                    do { if (--fuel == 0u) goto done;
                        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                            r0.y ^= 0u;
                            e0 = e0 * 0.5L + (long double)(((unsigned)((int)*mp < (int)p2) << (*mp & 31u)) & 1023u);
                            if ((unsigned)((int)0xa660d66fu < (int)(0x720f0399u ^ (unsigned)l0))) break;
                        }
                        break; (void)(u2);
                        h0 = (short)(unsigned)((unsigned)(x0 >> 70) && *q0);
                        if ((unsigned)(x0 >> 70)) continue;
                    } while (i0++ < 7u && ((*mp | i2) | a0[i0 & 3u]));
                    break; (void)((unsigned)(signed char)(unsigned)((unsigned)((unsigned)b0 < p1) == (unsigned)s0));
                    break; (void)(0x80000000u);
                } else {
                    if (0x7fffffffu) continue;
                }
                *mp = (((unsigned)!((unsigned)(x0 >> 70) - 5u) + (unsigned)c0) | p1);
                *mp = ((unsigned)((unsigned)c0 && (u2 - r0.y)) % ((0xffffffffu ^ g0) | 1u));
            }
        }
        while (i1++ < 2u && ((g0 ^ i1) + i1)) { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)!((unsigned)(garr[u2 & 7u] == garr[u2 & 7u]) % ((unsigned)d0 | 1u));
            if (a0[i0 & 3u]) break;
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn1(u0, -(unsigned)(0xf3e43553u == p0), (unsigned)s0); }
                if (i2) break;
                { unsigned t14; double z14; if (((unsigned)c1) & 1u) { t14 = (unsigned)(short)((unsigned)s1 >> (p1 & 31u)); z14 = (double)((0x7fffffffu) & 255u); } if (((unsigned)c1) & 1u) { u3 += t14; d0 = d0 * 0.5 + z14; }
                    s1 = (int)((unsigned)s1 + (*mp + (*mp ^ fuel)));
                    break; (void)((unsigned)(short)(unsigned)(0xecf0d544u == (unsigned)c0));
                    u2 = u2 * 0x9e3779b1u + (unsigned)!(unsigned)((int)(unsigned)d0 >= (int)(0xffffffffu / ((unsigned)(x0 >> 70) | 1u)));
                    do { if (--fuel == 0u) goto done;
                        m0 ^= (unsigned)c0;
                        if (budget != 0u) { budget -= 1u; u0 = fn1(4u, (u1 - (unsigned)l0), (unsigned)((int)(unsigned)s0 < (int)(unsigned)(u2 || (unsigned)h1))); }
                    } while (i0++ < 7u && (unsigned)((short)(unsigned)(signed char)((unsigned)h1 / (0xfb0ed7c5u | 1u)) > (signed char)0x3073fa2bu));
                    h0 = (short)(unsigned)(signed char)((unsigned)f0 / (((0x178c3d32u >> ((0xba1686d5u << ((unsigned)h0 & 31u)) & 31u)) * 0x7fffffffu) | 1u));
                }
            }
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    u2 += (6u % (u2 | 1u));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((0x7fffffffu + ((unsigned)h0 | (unsigned)(x0 >> 70))), (unsigned)s1, (unsigned)((unsigned)s1 || (unsigned)((unsigned)h1 == u1))); }
                    if ((unsigned)!(unsigned)(0xb4373115u == (unsigned)c1)) break;
                    i1 = ((unsigned)f0 | ((unsigned)((int)0x30ed7c0du >= (int)u2) + v0)) & 15u;
                } while (i0++ < 5u && garr[i1 & 7u]);
                if (r0.x) goto L1;
                if (budget != 0u) { budget -= 1u; u3 = fn1(0xffffffffu, (unsigned)(unsigned char)((unsigned)s0 % ((unsigned)(w0 >> 29) | 1u)), (0xaab86579u | (unsigned)c1)); }
                h0 = (short)((~((unsigned)h0 & 0x7fffffffu) % (u1 | 1u)) | a0[u1 & 3u]);
                u2 += (4u ? (unsigned)l0 : (unsigned)c0);
            }
        }
        switch ((unsigned)h0 & 7u) {
            u1 = ((unsigned)l0 ^ 1u);
        }
    }
    u2 = u2 * 0x9e3779b1u + ((unsigned)x0 & (unsigned)(w0 >> 29));
    w0 = w0 * 6364136223846793005ull + i0;
    f0 = f0 * 0.5f + (float)(((unsigned)d0 & 0x10000u) & 255u);
    while (i0++ < 5u && 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)f0 & 7u) {
            f0 = f0 * 0.5f + (float)(((unsigned)!(unsigned)((int)(p1 * g1) < (int)r0.x) << (((unsigned)s1 | (unsigned)e0) & 31u)) & 255u);
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 7u: ;
                if (budget != 0u) { budget -= 1u; u3 = fn0((a0[u1 & 3u] ? 0xeb13482fu : g0), (unsigned)h1, (unsigned)(signed char)(0x6c0efce4u % ((unsigned)c1 | 1u))); }
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0(p2, (garr[i1 & 7u] ^ 0x10000u), (unsigned)w0); }
        *q0 += (unsigned)(i0 == (*q0 | m0));
        break; (void)(7u);
        if (budget != 0u) { budget -= 1u; u1 = fn1(0x3d03abb1u, (-(0x7fffffffu * 0xffffffffu) * i1), (unsigned)((int)(unsigned)c1 >= (int)(unsigned)((unsigned)w0 == u2))); }
        if ((unsigned)(u2 < 0x7fffffffu)) {
            q0 = &garr[((unsigned)x0 | u2) & 7u];
            if ((3u << ((unsigned)(i0 == 4u) & 31u))) break;
        }
    }
    switch (0x80000000u & 7u) {
        while (i0++ < 4u && (unsigned)w0) { if (--fuel == 0u) goto done;
            *q0 = ((0xfbd37f9du | r0.y) ^ (unsigned)s0);
            switch (~((unsigned)(unsigned char)(0u & (unsigned)c1) * (unsigned)(x0 >> 70)) & 7u) {
                case 0u: ;
                { unsigned t15; double z15; if (((i0 - p0)) & 1u) { t15 = *mp; z15 = (double)(((*q0 / (p2 | 1u))) & 255u); } if (((i0 - p0)) & 1u) { u3 += t15; d0 = d0 * 0.5 + z15; }
                    *mp = ((0x10000u | 6u) ^ u3);
                    g1 += ((unsigned)(unsigned char)((unsigned)((unsigned)h0 < 0xffffffffu) >> (p1 & 31u)) - (unsigned)(unsigned char)((unsigned)s0 >> ((unsigned)b0 & 31u)));
                }
            }
        }
        goto L3;
        break; (void)(((unsigned)l0 | 0u));
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)f0, (unsigned)((int)0xffffffffu >= (int)(m0 - m0)), ((i0 ^ i2) ^ g0)); }
    }
    if ((unsigned)!(5u & (unsigned)e0)) goto L4;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (*q0) break;
    }
    while ((r0.y << ((unsigned)(garr[i1 & 7u] == i1) & 31u))) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)((unsigned)((unsigned)h0 < (unsigned)f0) - (*mp >> ((unsigned)w0 & 31u)));
        if ((unsigned)(unsigned char)(0xef19f618u - p2)) break;
        { unsigned t16; double z16; if ((0x80000000u) & 1u) { t16 = ((p2 >> (0xab32d69u & 31u)) / (*q0 | 1u)); z16 = (double)((-(i2 * (i2 * 0x7fffffffu))) & 255u); } if ((0x80000000u) & 1u) { u3 += t16; d0 = d0 * 0.5 + z16; }
            if (r0.x) {
                r0.x = ((unsigned)((short)(unsigned)s0 > (signed char)0xd6c42be4u) % ((a0[i0 & 3u] % ((unsigned)(unsigned char)(u1 / (0x7e1b90b8u | 1u)) | 1u)) | 1u));
                l0 = (long)((unsigned long)l0 + ((unsigned)((int)0xffffffffu < (int)0xf8381041u) - (0xf315946fu ? u0 : 0x7fffffffu)));
                garr[i0 & 7u] = (((unsigned)d0 * ((unsigned)(i2 && u2) >> (*q0 & 31u))) / (0xffffffffu | 1u));
                u0 = (unsigned)e0;
                if ((unsigned)(6u < r0.x)) break;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0(v0, 9u, (unsigned)(((unsigned)h1 + (unsigned)e0) == m0)); }
            switch (r0.y & 7u) {
                if ((unsigned)w0) {
                    case 4u: ;
                    do { if (--fuel == 0u) goto done;
                        u3 ^= (unsigned)((int)1u >= (int)(unsigned)((8u % (0x99bebfb6u | 1u)) || a0[i0 & 3u]));
                        s0 = (int)(r0.y ^ (unsigned)s1);
                        if (budget != 0u) { budget -= 1u; u0 = fn1((garr[i1 & 7u] | 6u), (unsigned)(u1 && (unsigned)h1), 3u); }
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((p1 / (p1 | 1u)) % (g1 | 1u)), *q0, (unsigned)(0x6180dd11u == (unsigned)!(9u << (8u & 31u)))); }
                        f0 = f0 * 0.5f + (float)((~(4u - (unsigned)c0) + (unsigned)((int)p1 >= (int)(unsigned)b0)) & 255u);
                        e0 = e0 * 0.5L + (long double)(((unsigned)((int)(0x82a9a416u % (7u | 1u)) >= (int)(r0.y >> (garr[u2 & 7u] & 31u))) + (unsigned)b0) & 1023u);
                    } while (i1++ < 4u && 8u);
                    default: ;
                }
                c1 = (signed char)((unsigned)(x0 >> 70) ^ m0);
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((u1 + (p0 & 0x8fd4ca4fu))) continue;
                    if (((unsigned)(x0 >> 70) % (u2 | 1u))) break;
                }
                b0 = (((*q0 + 8u) / ((unsigned)(short)(unsigned)((int)6u >= (int)0x729b3c3bu) | 1u)) | garr[u2 & 7u]) != 0u;
            }
        }
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((i1 * 0x1a4f77f2u)) break;
        }
    }
    if ((unsigned)((unsigned)e0 && i0)) goto L2;
    h1 = (unsigned short)(h1 + (r0.x - p1));
    if ((unsigned)(unsigned char)(m0 * ((unsigned)x0 - p0))) {
        while (i0++ < 3u && (0u - 0x7fffffffu)) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)u0;
            switch ((unsigned)((i0 << (m0 & 31u)) || fuel) & 7u) {
                w0 = w0 * 6364136223846793005ull + ((unsigned)c0 | (3u + u3));
                u3 ^= (garr[u2 & 7u] * i2);
                garr[(unsigned)((unsigned)e0 == (unsigned)(w0 >> 29)) & 7u] = (unsigned)(*mp == (unsigned)h1);
                while (i1++ < 2u && p1) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + ((unsigned)x0 % ((0x1c59bd48u ^ (unsigned)(x0 >> 70)) | 1u)));
                }
                c0 = (unsigned char)(unsigned)(unsigned char)(unsigned)((short)0x60d0c95au > (signed char)0x80000000u);
                d0 = d0 * 0.5 + (double)(i2 & 1023u);
            }
            switch ((unsigned)(i0 && (unsigned)((int)4u < (int)0x78d51262u)) & 7u) {
                case 1u: ;
                if (budget != 0u) { budget -= 1u; u3 = fn1((u1 << (0xe86a3d14u & 31u)), ((unsigned)h0 + 0xffffffffu), (unsigned)((unsigned)((unsigned)s0 < g1) || 6u)); }
                if (p0) goto L1;
                i1 = (unsigned)((short)m0 > (signed char)0x1c5193acu) & 15u;
                d0 = d0 * 0.5 + (double)((unsigned)(r0.x || (unsigned)l0) & 1023u);
                case 5u: ;
            }
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                i2 = (unsigned)((int)(unsigned)(x0 >> 70) >= (int)-((unsigned)(x0 >> 70) + 0x80000000u)) & 15u;
                if (r0.y) break;
                *q0 += (unsigned)((unsigned)((unsigned)b0 < (unsigned)s0) && (unsigned)h0);
            }
            switch ((m0 & (5u & garr[u2 & 7u])) & 7u) {
                v0 = ((unsigned)f0 / ((unsigned)s1 | 1u));
                u3 = ((unsigned)x0 - 0x9c6c1b81u);
                case 2u: ;
                if (budget != 0u) { budget -= 1u; u0 = fn0((2u % (m0 | 1u)), (unsigned)(g1 || (unsigned)((int)v0 >= (int)9u)), (a0[u1 & 3u] - 3u)); }
                case 0u: ;
            }
            do { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (~((unsigned)(short)(u3 ^ *q0) % (g1 | 1u)) % ((unsigned)((unsigned)h1 || 0x10000u) | 1u));
                if (((0xd501ace6u >> ((unsigned)h0 & 31u)) - 0x10000u)) break;
                u1 = u1 * 0x9e3779b1u + (((unsigned)x0 << (8u & 31u)) / (0x7fffffffu | 1u));
                break; (void)((unsigned)((short)0xffffffffu > (signed char)(4u - 0x10000u)));
                if ((unsigned)(g0 && 2u)) break;
                if (((unsigned)e0 << (*mp & 31u))) continue;
            } while (i1++ < 3u && (a0[i0 & 3u] * 0xc29e0557u));
        }
    }
    while (i0++ < 4u && (unsigned)!(unsigned)(0x10000u == (unsigned)c0)) { if (--fuel == 0u) goto done;
        switch ((0x64e0b60fu ? u2 : 0u) & 7u) {
            c0 = (unsigned char)(*q0 ^ (unsigned)((int)0x10000u >= (int)(unsigned)s1));
            case 4u: ;
            u1 = (unsigned)((unsigned)(*q0 < garr[i1 & 7u]) && (0x80000000u >> ((unsigned)x0 & 31u)));
            while ((garr[u2 & 7u] & ((unsigned)s0 & a0[i0 & 3u]))) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return 0x26cfe803u;
                if ((0x96e5f24bu * 7u)) goto L2;
                case 7u: ;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)((unsigned)s0 ^ (unsigned)d0);
                    default: ;
                    if (((unsigned)(g1 == u3) | 0x80000000u)) continue;
                    r0.y ^= garr[i1 & 7u];
                }
            }
            q0 = &garr[(unsigned)!(unsigned)(0xffffffffu || (9u % ((u3 >> (0x96641f4bu & 31u)) | 1u))) & 7u];
        }
        if ((garr[i1 & 7u] % ((unsigned)((short)2u > (signed char)p1) | 1u))) continue;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(*mp == ((unsigned)w0 * 0x7fffffffu)), fuel, ((unsigned)(4u || 8u) + g0)); }
        if ((u3 >> (garr[u2 & 7u] & 31u))) goto L0;
        if ((unsigned)((int)(unsigned)d0 >= (int)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)v0))) goto L0;
    }
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            switch ((unsigned)((unsigned)(r0.y || 0xb30509au) == r0.y) & 7u) {
                garr[((unsigned)c1 % (0xfac55a46u | 1u)) & 7u] = (-((((unsigned)h0 % (a0[i0 & 3u] | 1u)) & g0) * (unsigned)l0) ^ r0.y);
                if ((garr[u2 & 7u] | (unsigned)c1)) goto L4;
            }
            while (i2++ < 2u && (unsigned)(fuel && (unsigned)((unsigned)b0 && r0.y))) { if (--fuel == 0u) goto done;
                u0 = u0 * 0x9e3779b1u + ~(unsigned)((unsigned)(u0 < a0[i0 & 3u]) || a0[u1 & 3u]);
                *mp = ((unsigned)(signed char)(unsigned)(0x7fffffffu < a0[i0 & 3u]) + (unsigned)w0);
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)(fuel * (unsigned)(8u || (unsigned)l0)), ((unsigned)c0 % (0x52cc09c5u | 1u)), (unsigned)(0x7fffffffu || ((unsigned)f0 - (unsigned)(w0 >> 29)))); }
                switch (0xffffffffu & 7u) {
                    *mp = 0x23ad38a2u;
                }
                u1 = u1 * 0x9e3779b1u + (unsigned)((int)(unsigned)d0 >= (int)(unsigned)((unsigned)s1 || (unsigned)l0));
                if ((unsigned)(unsigned char)(4u % ((unsigned)((int)(unsigned)h0 >= (int)0x80000000u) | 1u))) break;
            }
            x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)(a0[i0 & 3u] || (unsigned)x0) | p0) == (unsigned)d0);
            if (((unsigned)e0 % (p1 | 1u))) break;
            if ((unsigned)b0) break;
            if (((unsigned)((short)0x7fffffffu > (signed char)fuel) ^ 0x5bef64ffu)) break;
        } while (i1++ < 6u && (unsigned)(short)(fuel + (unsigned)w0));
        f0 = f0 * 0.5f + (float)(-(garr[u2 & 7u] ? (unsigned)c0 : u3) & 255u);
        *q0 += ((unsigned)((int)(*q0 * i1) >= (int)0xad575427u) + garr[u2 & 7u]);
        { unsigned t17; double z17; if (((fuel | 0x10000u)) & 1u) { t17 = (g0 >> (a0[u1 & 3u] & 31u)); z17 = (double)(((*q0 | (unsigned)(*mp || a0[i0 & 3u]))) & 255u); } if (((fuel | 0x10000u)) & 1u) { u3 += t17; d0 = d0 * 0.5 + z17; }
            break; (void)(u2);
        }
        goto L0;
    } while (i0++ < 3u && (r0.y ^ (unsigned)h1));
    if (8u) goto L3;
    *mp = 4u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *q0 += garr[u2 & 7u];
    c1 = (signed char)(r0.y * 2u);
    if (7u) {
        r0.y ^= (unsigned)(unsigned char)(unsigned)((unsigned)(signed char)(unsigned)((int)i1 >= (int)i2) && (unsigned)h1);
        for (;;) { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)(unsigned)f0 > (signed char)((unsigned)c0 ^ (unsigned)b0)), 0x7fffffffu, (unsigned)((int)0xffffffffu >= (int)u2)); }
            if (fuel < 8u) return (4u << ((p0 % (0xffffffffu | 1u)) & 31u));
            l0 = (long)((unsigned long)l0 + i2);
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 += (unsigned)((unsigned)(unsigned char)((unsigned)c0 * fuel) || ((unsigned)((int)u0 < (int)(unsigned)l0) + fuel));
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(r0.x || r0.x), ((unsigned)!((unsigned)b0 + (unsigned)d0) + (unsigned)x0), (unsigned)!(unsigned)(2u < p1)); }
                s0 = (int)(unsigned)(signed char)(0x50b9eb98u ^ u3);
                if ((0u | (unsigned)d0)) {
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(garr[i1 & 7u] || (unsigned)c1), (v0 & (unsigned)c1), (unsigned)((short)0x4e9d55c1u > (signed char)(u2 ^ 0u))); }
                    if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)f0 * fuel), (unsigned)!((unsigned)d0 - 0xffffffffu), fuel); }
                } else {
                    garr[(0x80000000u & v0) & 7u] = (unsigned)((short)(unsigned)((short)garr[i1 & 7u] > (signed char)i1) > (signed char)(unsigned)c1);
                }
                switch (((unsigned)((int)0x3528392fu < (int)0x7a67182au) | r0.y) & 7u) {
                    garr[0xffffffffu & 7u] = (unsigned)((unsigned)((int)(unsigned)(w0 >> 29) < (int)p2) < (unsigned)w0);
                    goto L4;
                    case 1u: ;
                }
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((0u - a0[u1 & 3u])) continue;
                    b0 = 3u != 0u;
                    if (budget != 0u) { budget -= 1u; u2 = fn1(((p1 | (unsigned)h1) << (8u & 31u)), (unsigned)(0xc54d8d19u || p0), 0xf4cc0d7cu); }
                    v0 = ((unsigned)(0x10000u == m0) / (0x7fffffffu | 1u));
                    if ((unsigned)((int)(unsigned)(garr[u2 & 7u] < 4u) < (int)*q0)) goto L3;
                    if (budget != 0u) { budget -= 1u; u3 = fn2(i1, (unsigned)!((0xffffffffu | a0[u1 & 3u]) * u1), (unsigned)c0); }
                }
            }
            if (0u) {
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)(signed char)(5u | u2) == (unsigned)s0), (unsigned)(((unsigned)(x0 >> 70) / (0x5d8703aau | 1u)) || 7u), (unsigned)((unsigned)e0 || (8u | u2))); }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)c0, (unsigned)x0, 0xa27dcb27u); }
                u1 = u1 * 0x9e3779b1u + fuel;
                *q0 += u3;
            } else {
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(unsigned char)(unsigned)((unsigned)((int)(unsigned)c0 < (int)p2) < 0xffffffffu), (0xf8035d51u << ((unsigned)((int)u2 < (int)6u) & 31u)), (unsigned)((short)(unsigned)((unsigned)s1 == 3u) > (signed char)7u)); }
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    while (i2++ < 7u && p2) { if (--fuel == 0u) goto done;
                        s0 = (int)a0[i0 & 3u];
                        h0 = (short)(unsigned)(0xe3aadb48u || r0.x);
                    }
                    g0 = (unsigned)(((unsigned)e0 - (unsigned)x0) < (g0 % (i1 | 1u)));
                    if ((v0 >> ((unsigned)s1 & 31u))) continue;
                    q0 = &garr[(unsigned)((unsigned)((int)0x10000u >= (int)0xb919576eu) || ((unsigned)s0 ^ (unsigned)(short)(0x10000u >> (i0 & 31u)))) & 7u];
                    c1 = (signed char)(i1 % (3u | 1u));
                }
                if (((unsigned)c1 + 8u)) break;
                g1 += (u2 - (unsigned)(x0 >> 70));
            }
        }
        r0.x = -(unsigned)((fuel % (a0[i0 & 3u] | 1u)) < ((unsigned)c1 + u1));
    } else {
        L1: if (--fuel == 0u) goto done;
        while (i0++ < 3u && r0.y) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1(~(unsigned)((int)g0 < (int)(unsigned)c1), (unsigned)(m0 && (unsigned)h0), u1); }
        }
    }
    e0 = e0 * 0.5L + (long double)((unsigned)(((0xb4a662a6u + (unsigned)h1) | (unsigned)s1) && u1) & 1023u);
    if (r0.x) {
        s0 = (int)(a0[u1 & 3u] << (g1 & 31u));
        h1 = (unsigned short)(h1 + 0xfbd1aca8u);
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(x0 >> 70), (unsigned)b0, p1); }
    }
    r0.y ^= (unsigned)(p1 < ((*mp ? g1 : (unsigned)x0) * u1));
    goto L4;
    if (*q0) goto L4;
    l0 = (long)((unsigned long)l0 + ((garr[u2 & 7u] & (unsigned)c0) & (unsigned)!(unsigned)(0x916b7ac0u || (unsigned)d0)));
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= (unsigned)(u0 || (2u ^ -(unsigned)(g1 < p2)));
    }
    if ((unsigned)(unsigned char)(unsigned)(p0 == (unsigned)e0)) goto L3;
    if ((unsigned)(w0 >> 29)) {
        w0 ^= (unsigned long long)a0[u1 & 3u] << (0x179e9a5eu & 63u);
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((int)(3u ^ 3u) >= (int)p1));
        }
        switch (p1 & 7u) {
            break; (void)(fuel);
            s1 = (int)((unsigned)s1 + (unsigned)(g1 < i0));
            s1 = (int)((unsigned)s1 + (unsigned)c1);
            i2 = ~(unsigned)((short)(unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)(w0 >> 29)) > (signed char)a0[i0 & 3u]) & 15u;
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(((p1 << (0x80000000u & 31u)) & 2u), (0x6a6b369au | (unsigned)((int)g1 < (int)0x10000u)), (0x10000u >> (i1 & 31u))); }
                u3 = u3 * 0x9e3779b1u + -(~(u3 + m0) / ((0x80000000u & (v0 << (0u & 31u))) | 1u));
                L2: if (--fuel == 0u) goto done;
                if ((p1 | (unsigned)((int)i2 >= (int)r0.x))) continue;
            }
        }
    }
    L3: if (--fuel == 0u) goto done;
    w0 = w0 * 6364136223846793005ull + (0x80000000u << (0xffffffffu & 31u));
    L4: if (--fuel == 0u) goto done;
    r0.x = 4u;
    a0[(unsigned)((int)0xffffffffu >= (int)0x7fffffffu) & 3u] = (unsigned)((short)0x7fffffffu > (signed char)p1);
    d0 = d0 * 0.5 + (double)(p2 & 1023u);
    if (fuel < 8u) return (unsigned)!((9u % ((unsigned)((short)(unsigned)(p0 || 0xffffffffu) > (signed char)i0) | 1u)) & a0[u1 & 3u]);
    v0 = (unsigned)(unsigned char)(v0 << (p2 & 31u));
    switch ((unsigned)((unsigned)l0 && (*mp >> ((unsigned)x0 & 31u))) & 7u) {
        goto L3;
        *mp = (unsigned)s0;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)e0, (unsigned)((int)0x687aab21u < (int)(unsigned)w0), *q0); }
    x0 = x0 * 0x100000001b3ull + (unsigned)(u3 || g1);
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(signed char)(unsigned)(garr[u2 & 7u] || ((unsigned)c0 - a0[i0 & 3u]))) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)(unsigned)x0 < (int)a0[i0 & 3u]), (unsigned)s1, ~(a0[u1 & 3u] / (r0.x | 1u))); }
    } while (i0++ < 6u && (unsigned)((unsigned)c1 == u1));
    w0 ^= (unsigned long long)0x77de668cu << ((unsigned)((short)9u > (signed char)(unsigned)((int)0x10000u >= (int)(unsigned)((short)0xdf77b322u > (signed char)(0xffffffffu % (0xa22deb79u | 1u))))) & 63u);
    if ((unsigned)(0xffffffffu < 0x6db54e8u)) goto done;
    l0 = (long)((unsigned long)l0 + (0xa6830852u ^ (unsigned)h0));
    for (;;) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((u0 + 0x80000000u) || (unsigned)c0), v0, (unsigned)(u0 && (0x10000u + (unsigned)(x0 >> 70)))); }
        d0 = d0 * 0.5 + (double)((i2 * (0x7a4fc98cu & 0x10000u)) & 1023u);
    }
    goto L1;
    a0[(0xffffffffu + 0x3e21ad30u) & 3u] = ((unsigned)((int)(unsigned)((int)0x91af6d3du < (int)garr[u2 & 7u]) >= (int)u1) << (a0[i0 & 3u] & 31u));
    do { if (--fuel == 0u) goto done;
        c1 = (signed char)(a0[i0 & 3u] * (unsigned)(unsigned char)(unsigned)((unsigned)s0 && p0));
        if (0x3d6ff2a5u) {
            q0 = &garr[(u0 << ((g0 * (unsigned)((unsigned)x0 == (unsigned)h1)) & 31u)) & 7u];
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((int)1u < (int)u1) || (unsigned)c1) & 255u);
            q0 = &garr[((fuel ? p0 : *mp) % ((unsigned)((int)r0.y < (int)(unsigned)(x0 >> 70)) | 1u)) & 7u];
            switch ((((unsigned)c0 ^ (unsigned)l0) % (garr[u2 & 7u] | 1u)) & 7u) {
                s0 = (int)(unsigned)(signed char)(m0 >> ((3u | i0) & 31u));
                if (budget != 0u) { budget -= 1u; u0 = fn2((r0.x - 0x56f6e622u), (unsigned)b0, (0xb8f82e3au % (0xffffffffu | 1u))); }
                r0.x = *q0;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    m0 ^= (unsigned)x0;
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)f0, *mp, (unsigned)!(unsigned)((unsigned)((short)p1 > (signed char)(unsigned)c0) || p1)); }
                    v0 = u3;
                    if (fuel < 8u) return (*mp & (unsigned)((fuel ? 3u : (unsigned)b0) < g1));
                }
            }
            d0 = d0 * 0.5 + (double)((i2 | (0x7fffffffu % (0x674f9872u | 1u))) & 1023u);
        } else {
            if (r0.x) {
                switch (((r0.x & 1u) + (unsigned)l0) & 7u) {
                    c1 = (signed char)(unsigned)(garr[u2 & 7u] < 3u);
                    if (budget != 0u) { budget -= 1u; u1 = fn2(0x80000000u, 0x80000000u, (unsigned)c0); }
                    case 4u: ;
                }
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)h1;
                    h1 = (unsigned short)(h1 + (0x1662156du - 1u));
                    garr[(0x95bbe4cdu ^ r0.y) & 7u] = (g1 + garr[u2 & 7u]);
                    l0 = (long)((unsigned long)l0 + (p2 / (r0.x | 1u)));
                    { unsigned t0; double z0; if (((unsigned)((int)p2 < (int)(0xc8bedf5cu % (0xc0509914u | 1u)))) & 1u) { t0 = (unsigned)f0; z0 = (double)(((unsigned)((unsigned)e0 < (0x94d93466u & (unsigned)c0))) & 255u); } if (((unsigned)((int)p2 < (int)(0xc8bedf5cu % (0xc0509914u | 1u)))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                        d0 = d0 * 0.5 + (double)((p2 & (a0[i0 & 3u] ^ g0)) & 1023u);
                        x0 = x0 * 0x100000001b3ull + -(a0[i0 & 3u] >> (((unsigned)(short)(unsigned)(garr[u2 & 7u] && (unsigned)!((unsigned)c0 & 9u)) / ((unsigned)w0 | 1u)) & 31u));
                        if ((unsigned)x0) break;
                    }
                }
                g1 += 0xffffffffu;
            } else {
                u2 ^= ((unsigned)h1 << (((unsigned)x0 ? (unsigned)((int)0u < (int)a0[i0 & 3u]) : p2) & 31u));
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t1; double z1; if (((unsigned)(8u || (unsigned)b0)) & 1u) { t1 = i2; z1 = (double)((i1) & 255u); } if (((unsigned)(8u || (unsigned)b0)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                        if (((p1 + *mp) - 0xa9e968cu)) continue;
                        if (budget != 0u) { budget -= 1u; u1 = fn2((p0 & fuel), (u2 & a0[i0 & 3u]), 0xa6d7935fu); }
                        if (((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)l0) + 0x7fffffffu)) break;
                        e0 = e0 * 0.5L + (long double)(-(0x604e1a46u % (u0 | 1u)) & 1023u);
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0xb393b5bau == (g1 ^ p2)), ((a0[i0 & 3u] & a0[i0 & 3u]) & (unsigned)x0), ((unsigned)((unsigned)x0 || r0.x) + 0x55f099b5u)); }
                        u0 ^= (0x265a7db8u % ((unsigned)e0 | 1u));
                    }
                    d0 = d0 * 0.5 + (double)(~((unsigned)(short)((unsigned)f0 - (*q0 & 0x9630122au)) + (0xffc0c0c1u & (unsigned)d0)) & 1023u);
                    v0 = p1;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)x0, (unsigned)((short)(unsigned)s1 > (signed char)p2), (unsigned)c1); }
                if ((unsigned)((unsigned)d0 < m0)) break;
            }
            if ((0xf039ff20u >> (0x529cb9c3u & 31u))) break;
        }
    } while (i0++ < 7u && (unsigned)d0);
    goto L2;
    if (0x10000u) {
        u3 ^= (unsigned)(0x5e5f1a3eu && (unsigned)w0);
        goto done;
        goto L0;
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            *mp = (u0 << ((unsigned)h1 & 31u));
            l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(unsigned)((unsigned)((int)0x91b7d9c7u >= (int)((unsigned)e0 / ((unsigned)e0 | 1u))) && ~(0x10000u << (2u & 31u))));
            l0 = (long)((unsigned long)l0 + (g0 & (unsigned)((int)(unsigned)b0 < (int)(p1 >> ((unsigned)f0 & 31u)))));
        }
        e0 = e0 * 0.5L + (long double)((unsigned)((int)r0.x >= (int)*mp) & 1023u);
        u0 ^= ((0xbae29756u & (unsigned)f0) / (p2 | 1u));
    }
    w0 ^= (unsigned long long)(unsigned)((int)(unsigned)f0 >= (int)(unsigned)f0) << (-((i0 - 0xe8fd9827u) * ((unsigned)!(unsigned)((int)(unsigned)d0 >= (int)i2) ^ garr[i1 & 7u])) & 63u);
    do { if (--fuel == 0u) goto done;
        if (fuel) goto L3;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)l0, (unsigned)((int)(9u & g1) < (int)p2), i1); }
        if ((unsigned)(signed char)(unsigned)((int)p0 >= (int)p1)) goto L4;
    } while (i0++ < 4u && (unsigned)(-(unsigned)((int)(unsigned)c0 < (int)0x7fffffffu) || i1));
    v0 = (unsigned)((short)i2 > (signed char)(unsigned)((int)(unsigned)(x0 >> 70) < (int)(*q0 ^ 0x7fffffffu)));
    *mp = -(unsigned)((short)(unsigned)s1 > (signed char)0u);
    s0 = (int)(((unsigned)s0 ? 7u : 0x10000u) >> (((unsigned)(x0 >> 70) * *mp) & 31u));
    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((u3 << (0x54c2f751u & 31u)) == 0xc917b839u), 7u, ((unsigned)w0 - (unsigned)((int)r0.x < (int)(unsigned)f0))); }
    if ((unsigned)b0) goto L4;
    { unsigned t2; double z2; if (((unsigned)c0) & 1u) { t2 = u1; z2 = (double)((0u) & 255u); } if (((unsigned)c0) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        if (0x3b75c988u) goto L2;
        if (budget != 0u) { budget -= 1u; u0 = fn2(~((unsigned)d0 - 0x7fffffffu), (r0.x >> (0xc11f54dbu & 31u)), (unsigned)((int)i2 >= (int)p0)); }
        s1 = (int)((unsigned)s1 + (unsigned)(signed char)((unsigned)(short)(*mp ? 0xa926ea08u : 0x62a8225au) / ((a0[i0 & 3u] >> (7u & 31u)) | 1u)));
        b0 = ((unsigned)!(unsigned)(i1 && v0) + (unsigned)(short)(unsigned)(r0.x == (unsigned)x0)) != 0u;
        d0 = d0 * 0.5 + (double)(((0x92e4d875u >> ((unsigned)h0 & 31u)) | (unsigned)s0) & 1023u);
    }
    if ((u2 + (r0.x * 0x7fffffffu))) {
        if (((unsigned)w0 * (unsigned)f0)) goto L1;
        if ((0x3934d7fcu * u3)) goto L2;
    }
    goto L0;
    if (r0.x) goto L1;
    u0 ^= (9u ^ (0x9adb94e1u * (unsigned)d0));
    if (((1u | r0.x) & 0x80000000u)) goto L4;
    u3 = u3 * 0x9e3779b1u + ((unsigned)(unsigned char)(0x1ab1e486u % (1u | 1u)) / ((unsigned)x0 | 1u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        v0 = (unsigned)((short)(garr[i1 & 7u] ^ g1) > (signed char)(g1 >> (0xffffffffu & 31u)));
        if ((unsigned)(u2 || 9u)) break;
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(unsigned char)(0x7fffffffu / (v0 | 1u)), i0, (unsigned)(signed char)(0u - (unsigned)((int)0x80000000u >= (int)5u))); }
        l0 = (long)((unsigned long)l0 + ((*q0 >> ((unsigned)((short)0xa700c463u > (signed char)u0) & 31u)) + g1));
        h1 = (unsigned short)(h1 + ((unsigned)(short)((unsigned)h0 * p2) - 0xb90c3dfau));
    } while (i0++ < 7u && ((i0 << (0xfdc3a50eu & 31u)) - 4u));
    do { if (--fuel == 0u) goto done;
        r0.y ^= (((unsigned)d0 ^ r0.y) & (unsigned)((short)0x7fffffffu > (signed char)u2));
        if ((unsigned)((short)0x7fffffffu > (signed char)i2)) break;
        l0 = (long)((unsigned long)l0 + ((4u ^ i1) + ~(0xffffffffu * a0[i0 & 3u])));
        L0: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn2((*mp / ((unsigned)e0 | 1u)), (unsigned)(signed char)(unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)!(unsigned)(u1 && u0)), ((unsigned)d0 | (unsigned)((int)u3 >= (int)i2))); }
        while (m0) { if (--fuel == 0u) goto done;
            r0.y ^= garr[i1 & 7u];
            e0 = e0 * 0.5L + (long double)((((unsigned)((unsigned)c1 == 0x16f8776au) >> (0xffffffffu & 31u)) * u3) & 1023u);
            r0.x = 0x3dede4c6u;
        }
    } while (i0++ < 4u && 5u);
    u2 ^= r0.x;
    u2 += (unsigned)((int)(unsigned)w0 < (int)((unsigned)(w0 >> 29) ? r0.x : a0[i0 & 3u]));
    if ((unsigned)(5u == 0x10000u)) {
        { unsigned t0; double z0; if ((m0) & 1u) { t0 = (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)((unsigned)e0 == a0[i0 & 3u])); z0 = (double)(((unsigned)(8u < (unsigned)h0)) & 255u); } if ((m0) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            if ((unsigned)(short)(i2 + i0)) goto L0;
            *mp = ((unsigned)(x0 >> 70) / (0x59254b2cu | 1u));
            if ((unsigned)(4u || (unsigned)h1)) goto done;
        }
    }
    if (0u) goto L0;
    r0.x = (unsigned)(p0 || (8u >> ((unsigned)s0 & 31u)));
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0xbb93347u < (garr[i1 & 7u] * 0x10000u)), ((unsigned)l0 / (~(unsigned)((int)(unsigned)b0 >= (int)0x48cefebau) | 1u)), (unsigned)s1); }
    i1 = (unsigned)(i2 || i2) & 15u;
    if ((unsigned)(signed char)(p1 / (g1 | 1u))) goto L0;
    g1 += (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)h0);
    l0 = (long)((unsigned long)l0 + i2);
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)-(0xe7515b04u - a0[u1 & 3u]) < (int)u0);
    if ((r0.x / ((unsigned)b0 | 1u))) {
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn2(g1, (unsigned)((short)p2 > (signed char)(unsigned)(unsigned char)(fuel | 0xcf690e95u)), ((unsigned)h0 - 0x80000000u)); }
        } while (i0++ < 2u && (u0 & (unsigned)(signed char)(unsigned)(m0 == 0x41b13dc3u)));
        do { if (--fuel == 0u) goto done;
            b0 = (*mp / (0x3839e1a2u | 1u)) != 0u;
            if (6u) {
                if (0x96551c4fu) {
                    h1 = (unsigned short)(h1 + (0u >> (p1 & 31u)));
                } else {
                    u3 = (unsigned)(fuel && 0x7fffffffu);
                    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((short)(0x7fffffffu & (unsigned)c0) > (signed char)(unsigned)c1), (garr[i1 & 7u] >> (-((unsigned)h1 | 0x6acfe394u) & 31u)), (0x3d3dde2au ? (unsigned)d0 : (unsigned)c1)); }
                }
                f0 = f0 * 0.5f + (float)(((unsigned)c0 % ((unsigned)((int)(unsigned)w0 >= (int)((unsigned)((int)m0 < (int)(unsigned)c0) / (a0[i0 & 3u] | 1u))) | 1u)) & 255u);
            }
            l0 = (long)((unsigned long)l0 + (unsigned)w0);
            u0 = (p0 ? p2 : p2);
        } while (i0++ < 7u && ((unsigned)c0 << ((i0 + 8u) & 31u)));
    } else {
        do { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                u3 = u3 * 0x9e3779b1u + 0x10000u;
                L1: if (--fuel == 0u) goto done;
                break; (void)((unsigned)(signed char)((unsigned)b0 % (2u | 1u)));
                w0 ^= (unsigned long long)(g1 >> (r0.x & 31u)) << ((unsigned)(garr[i1 & 7u] < i0) & 63u);
            }
            q0 = &garr[r0.y & 7u];
        } while (i0++ < 2u && ((unsigned)d0 ? a0[u1 & 3u] : 2u));
        u2 = u2 * 0x9e3779b1u + *q0;
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            i2 = (p2 & p2) & 15u;
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((0x80000000u & i2) < (unsigned)h1), ((unsigned)b0 - 1u), ((unsigned)d0 / (*mp | 1u))); }
            while ((unsigned)(0x26b98017u || u1)) { if (--fuel == 0u) goto done;
                *q0 += (0x976f72d9u ^ g1);
            }
            if ((a0[i0 & 3u] ^ p2)) goto L3;
        }
        do { if (--fuel == 0u) goto done;
            if (0xd64e23eau) continue;
            *q0 += (unsigned)((0x80000000u * (unsigned)f0) < ((unsigned)e0 ^ (unsigned)e0));
            if (i1) break;
            m0 ^= ((unsigned)(i2 == *mp) - (unsigned)(w0 >> 29));
            L2: if (--fuel == 0u) goto done;
            if (u2) continue;
        } while (i0++ < 2u && (u3 % ((0xf3a54164u % (0x7fffffffu | 1u)) | 1u)));
    }
    if ((unsigned)(unsigned char)(0x7fffffffu * 0x463a5cc2u)) {
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)((int)garr[u2 & 7u] < (int)9u) && r0.y), ((unsigned)(garr[u2 & 7u] || (unsigned)(w0 >> 29)) + u1), -(unsigned)((int)(unsigned)h0 >= (int)garr[u2 & 7u])); }
        *mp = ((unsigned)w0 >> ((unsigned)(garr[i1 & 7u] || garr[i1 & 7u]) & 31u));
        w0 ^= (unsigned long long)p1 << (-(g0 / ((unsigned)s1 | 1u)) & 63u);
    } else {
        L3: if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + ((unsigned)(0x51b2d21du < (unsigned)(((unsigned)w0 % (r0.y | 1u)) && u0)) / (0xb435f0beu | 1u));
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)u0;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(*q0 == (g0 & 0xd71e4fcdu)), i0, (unsigned)((int)((unsigned)c1 * 0x6b58410au) >= (int)5u)); }
            { unsigned t1; double z1; if ((0xffffffffu) & 1u) { t1 = (unsigned)(x0 >> 70); z1 = (double)((p2) & 255u); } if ((0xffffffffu) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)((int)0x80000000u < (int)0x80000000u) && a0[i0 & 3u]);
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)l0, (a0[i0 & 3u] >> (m0 & 31u)), (0x10000u << ((unsigned)(0xb5b1a7f2u && (unsigned)d0) & 31u))); }
                g1 += (unsigned)((int)((unsigned)b0 * p2) >= (int)0x7fffffffu);
                while (i1++ < 7u && (unsigned)((unsigned)d0 || 0xffffffffu)) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)garr[i1 & 7u] < (int)(i2 << ((unsigned)b0 & 31u)))) goto done;
                    break; (void)(((0x80000000u & (unsigned)w0) - 0x4a4b1bb4u));
                    goto L2;
                    u2 ^= (unsigned)((unsigned)!(unsigned)(0x61307ca6u < 0x8d49afa0u) && (0x17a31a2u ^ (unsigned)x0));
                }
            }
            do { if (--fuel == 0u) goto done;
                *q0 = ((unsigned)(x0 >> 70) ^ (unsigned)(0x80000000u == 0x6d83b34eu));
                if (g0) break;
            } while (i1++ < 3u && (unsigned)h0);
            for (;;) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    L4: if (--fuel == 0u) goto done;
                    if (3u) break;
                }
                garr[u2 & 7u] = ((unsigned)(w0 >> 29) << ((p2 * (unsigned)(0x7fffffffu && *q0)) & 31u));
                l0 = (long)((unsigned long)l0 + (unsigned)(w0 >> 29));
                q0 = &garr[a0[u1 & 3u] & 7u];
                r0.x = ((r0.y % ((unsigned)(((unsigned)(w0 >> 29) << (g1 & 31u)) && fuel) | 1u)) * g1);
                garr[-(unsigned)((int)i2 >= (int)r0.x) & 7u] = ((0xffffffffu >> ((unsigned)(x0 >> 70) & 31u)) & 0xd56e9083u);
            }
            g0 = (((unsigned)f0 % ((unsigned)(w0 >> 29) | 1u)) ? (unsigned)h0 : u3);
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(v0 < p1), (unsigned)!((fuel | (unsigned)l0) + 0x5decc6fcu), 0x80000000u); }
    switch (((0xe4bab89du & 6u) & r0.x) & 7u) {
        if (fuel < 8u) return (unsigned)(i1 && 8u);
        s0 = (int)(unsigned)(5u < (unsigned)((short)u0 > (signed char)((unsigned)s1 | (unsigned)(x0 >> 70))));
        break; (void)((unsigned)(garr[i1 & 7u] && g0));
        { unsigned t2; double z2; if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)i1)) & 1u) { t2 = (unsigned)x0; z2 = (double)(((unsigned)((unsigned)b0 == 0xe372a6c4u)) & 255u); } if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)i1)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)(v0 == r0.x) || garr[i1 & 7u]), (unsigned)(0xa2c28e2du == (unsigned)d0), (8u + (unsigned)e0)); }
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(*mp < *q0), (unsigned)(signed char)(p0 - (garr[i1 & 7u] / (0xffffffffu | 1u))), fuel); }
            u0 = u0 * 0x9e3779b1u + ((0x10000u / (r0.x | 1u)) + u2);
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)fuel >= (int)(garr[i1 & 7u] & garr[u2 & 7u])), (unsigned)c1, ((unsigned)s0 % (((unsigned)h1 ^ 0xffffffffu) | 1u))); }
            if (0x7fffffffu) goto L3;
            *q0 = (unsigned)(2u < ((unsigned)s1 * 0x9caa482u));
        }
    }
    for (;;) { if (--fuel == 0u) goto done;
        s0 = (int)(unsigned)((short)(0xd15d5271u & (0x5402551bu / (0x9d76f446u | 1u))) > (signed char)2u);
        g1 += (unsigned)h1;
    }
    if ((unsigned)h1) goto done;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn3(~((p2 ^ 0xffffffffu) / (0xffffffffu | 1u)), (unsigned)s1, p0); }
        f0 = f0 * 0.5f + (float)((0x9a6037bdu << ((unsigned)f0 & 31u)) & 255u);
    } while (i0++ < 4u && (unsigned)s1);
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)e0) goto L2;
        l0 = (long)((unsigned long)l0 + (0x10000u + 0x46afe834u));
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (g0) continue;
            s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(unsigned)((short)0x535231beu > (signed char)(2u ^ (unsigned)x0)));
            b0 = (unsigned)((short)*q0 > (signed char)(unsigned)((short)*mp > (signed char)garr[i1 & 7u])) != 0u;
            c1 = (signed char)(((unsigned)s0 - 0x305c29b1u) >> (0x720c067du & 31u));
            if (budget != 0u) { budget -= 1u; u2 = fn1((*q0 + (unsigned)x0), (unsigned)(p2 || g0), (*mp ^ *mp)); }
            g0 = (unsigned)((8u * (unsigned)!(unsigned)(p0 && (unsigned)h0)) == 0x6c6878fau);
        }
        if (u0) break;
        if (budget != 0u) { budget -= 1u; u0 = fn3(garr[u2 & 7u], (unsigned)(i0 < (unsigned)(garr[i1 & 7u] == (unsigned)(x0 >> 70))), ((unsigned)((int)p1 >= (int)(unsigned)s1) - i2)); }
        e0 = e0 * 0.5L + (long double)(garr[u2 & 7u] & 1023u);
    }
    if (((unsigned)f0 ? g1 : v0)) {
        u0 = u0 * 0x9e3779b1u + ((0x7312309u % (g1 | 1u)) % ((unsigned)(p0 && (v0 | u1)) | 1u));
        s0 = (int)(7u << ((unsigned)c1 & 31u));
        if (((unsigned)!((unsigned)s1 | 3u) ^ 6u)) goto L1;
        if (8u) goto done;
        goto L1;
    }
    q0 = &garr[((unsigned)h0 & (((unsigned)e0 ^ g0) - p1)) & 7u];
    if ((unsigned)h0) {
        u1 = (unsigned)((0x7fffffffu & r0.x) == (0x830c0b5eu * p1));
        if (garr[u2 & 7u]) {
            goto done;
            h0 = (short)((0x10000u | 0xffffffffu) / ((unsigned)(i2 || fuel) | 1u));
            goto L2;
        }
        if ((unsigned)(g1 || (unsigned)(*q0 || a0[u1 & 3u]))) goto L2;
    } else {
        while (-(0x7fffffffu & v0)) { if (--fuel == 0u) goto done;
            if ((unsigned)(unsigned char)(unsigned)(fuel && (unsigned)h1)) {
                g1 += (unsigned)(signed char)((p2 % ((unsigned)(0x10000u == 0x92cff0afu) | 1u)) + ((unsigned)w0 + v0));
                a0[(unsigned)(short)(unsigned)(garr[u2 & 7u] < r0.y) & 3u] = (unsigned)((int)0x80000000u >= (int)(unsigned)(short)(a0[i0 & 3u] | r0.x));
                c0 = (unsigned char)((8u | (unsigned)c0) * ((unsigned)w0 - g0));
                if ((unsigned)((unsigned)(w0 >> 29) == (0x228c34d6u % (0x6588fac6u | 1u)))) continue;
                if (((unsigned)(8u < (unsigned)e0) >> (*mp & 31u))) break;
                if (budget != 0u) { budget -= 1u; u3 = fn1(r0.x, ((i0 ^ 0xffffffffu) ^ u1), ((unsigned)!((unsigned)x0 ^ (unsigned)h0) | p2)); }
            } else {
                break; (void)(0xe29547bcu);
            }
            w0 ^= (unsigned long long)(unsigned)c1 << ((((*q0 % (*mp | 1u)) + g0) % ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)x0) | 1u)) & 63u);
            r0.y ^= (unsigned)((short)0xfe417071u > (signed char)(*mp << ((unsigned)(x0 >> 70) & 31u)));
            if (budget != 0u) { budget -= 1u; u0 = fn3(g0, (unsigned)s1, (unsigned)l0); }
        }
    }
    v0 = ((unsigned)c0 ^ (0x7fffffffu & (0x80000000u / ((i0 ^ garr[i1 & 7u]) | 1u))));
    if ((unsigned)((short)*mp > (signed char)(unsigned)c1)) goto L1;
    goto L1;
    switch (0x9048961eu & 7u) {
        case 4u: ;
    }
    { unsigned t3; double z3; if (((u3 - ((unsigned)(w0 >> 29) / (u2 | 1u)))) & 1u) { t3 = 0xa2abba57u; z3 = (double)(((unsigned)((p1 - r0.y) == 0xffffffffu)) & 255u); } if (((u3 - ((unsigned)(w0 >> 29) / (u2 | 1u)))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        d0 = d0 * 0.5 + (double)((unsigned)(signed char)(0x312361dbu + 9u) & 1023u);
        while (i0++ < 4u && (0x1dfed527u - (unsigned)s1)) { if (--fuel == 0u) goto done;
            *q0 = ((unsigned)f0 ^ r0.x);
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)(unsigned)s0 >= (int)*q0), (*mp % (0xffffffffu | 1u)), (0x4a89a919u * p0)); }
    c0 = (unsigned char)-(unsigned)((4u - ((unsigned)(x0 >> 70) & 0x57c4d537u)) && (unsigned)h1);
    if (budget != 0u) { budget -= 1u; u1 = fn3((p1 & (unsigned)d0), m0, (unsigned)((unsigned)f0 == garr[i1 & 7u])); }
    if ((8u + i1)) {
        h0 = (short)(unsigned)((unsigned)(m0 < (unsigned)(short)(8u * r0.x)) && (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)u0));
        if ((((unsigned)(x0 >> 70) ^ i0) ^ u3)) goto L0;
    }
    w0 ^= (unsigned long long)((unsigned)(x0 >> 70) | i2) << ((unsigned)((short)(i1 ? 0xffffffffu : (0x7fffffffu + p1)) > (signed char)(unsigned)x0) & 63u);
    c1 = (signed char)(unsigned)((short)*q0 > (signed char)2u);
    if (r0.x) goto L2;
    i0 = (unsigned)h1 & 15u;
    if (budget != 0u) { budget -= 1u; u0 = fn3(((unsigned)s1 ? fuel : *mp), (0xe4068676u >> (((unsigned)(x0 >> 70) - (unsigned)h0) & 31u)), (unsigned)(short)(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)((short)0x7fffffffu > (signed char)(unsigned)f0))); }
    c0 = (unsigned char)(unsigned)!(i2 ^ (p0 ? (unsigned)e0 : garr[u2 & 7u]));
    if (budget != 0u) { budget -= 1u; u0 = fn1((r0.y << ((unsigned)b0 & 31u)), u3, (unsigned)(*q0 < (unsigned)(signed char)(unsigned)((int)0x7fffffffu < (int)(unsigned)w0))); }
    if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)l0 & (unsigned)(a0[i0 & 3u] < u3)), 5u, ((unsigned)h1 / ((0x571755bau ^ (unsigned)f0) | 1u))); }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)s1) break;
        if ((unsigned)d0) continue;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch ((a0[i0 & 3u] / (((unsigned)w0 + i2) | 1u)) & 7u) {
                continue; (void)(u0);
            }
            m0 ^= *mp;
            b0 = (unsigned)((unsigned)((int)(unsigned)b0 < (int)0x211f06cfu) == (unsigned)(garr[i1 & 7u] < p0)) != 0u;
            if (budget != 0u) { budget -= 1u; u1 = fn0((((unsigned)x0 * 0x60461446u) & a0[u1 & 3u]), p2, (unsigned)s0); }
            x0 = x0 * 0x100000001b3ull + u2;
        }
    }
    m0 ^= u1;
    switch ((u1 >> (g1 & 31u)) & 7u) {
        if ((0x84c6837fu + i2)) goto L3;
        if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((int)0x10000u < (int)a0[u1 & 3u]), (unsigned)(0xeec86a41u || u0), (unsigned)(m0 < (unsigned)b0)); }
        u1 ^= ((unsigned)b0 ^ (a0[u1 & 3u] ? 8u : u1));
        d0 = d0 * 0.5 + (double)((((unsigned)(x0 >> 70) - u1) * p0) & 1023u);
        if (((unsigned)(signed char)(v0 << ((unsigned)l0 & 31u)) << ((unsigned)f0 & 31u))) goto L0;
        case 1u: ;
    }
    a0[i1 & 3u] = (((0x7fffffffu << ((unsigned)d0 & 31u)) >> (0xdad63e5cu & 31u)) & 0x10000u);
    u3 = (unsigned)(9u || m0);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 8u, 0xe8d6944fu, 0xfde45135u },
        { 6u, 0x4e4f9bd5u, 0x9cdc458cu },
        { 1u, 0xb683fc90u, 0x156408deu },
        { 6u, 0xcf670d0fu, 0x4db411bbu },
        { 14u, 0x5e6608cbu, 0x91379eabu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
