// test-ssa-source's program of seed 134000449 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x2ddc0709u, g1 = 0x7377c975u;
static unsigned garr[8] = { 0x87409a3du, 0x84e6f69du, 0x9510712fu, 0xa61398aau, 0x70bd06du, 0x80dc822du, 0xb56cc867u, 0x527b8028u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    { unsigned t0; double z0; if (((unsigned)(unsigned char)(unsigned)(i1 && (unsigned)((int)*q0 < (int)i2))) & 1u) { t0 = fuel; z0 = (double)(((unsigned)((int)0x1750f22au < (int)(unsigned)s1)) & 255u); } if (((unsigned)(unsigned char)(unsigned)(i1 && (unsigned)((int)*q0 < (int)i2))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        w0 ^= (unsigned long long)u0 << ((*q0 << ((unsigned)e0 & 31u)) & 63u);
        s1 = (int)((unsigned)s1 + p0);
        garr[(unsigned)x0 & 7u] = ((g0 >> (((unsigned)((int)p2 < (int)fuel) ^ 0x7fffffffu) & 31u)) % (6u | 1u));
        c0 = (unsigned char)(unsigned)f0;
        goto L0;
    }
    L1: if (--fuel == 0u) goto done;
    s1 = (int)((unsigned)s1 + (unsigned)h1);
    { unsigned t1; double z1; if (((0x2a069ad2u * (unsigned)((int)v0 >= (int)(unsigned)x0))) & 1u) { t1 = ((unsigned)((int)r0.x >= (int)g1) ^ (unsigned)e0); z1 = (double)(((unsigned)(a0[i0 & 3u] && ~(unsigned)((unsigned)h1 || 0x2fffe5aeu))) & 255u); } if (((0x2a069ad2u * (unsigned)((int)v0 >= (int)(unsigned)x0))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        goto L1;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(0x80000000u < 0xe2544540u)) {
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = (unsigned)((unsigned)((int)(g0 / (p0 | 1u)) >= (int)v0) && ((unsigned)(w0 >> 29) / (p2 | 1u)));
                    *mp = (unsigned)((unsigned)(short)(unsigned)(p0 < 0xc6019948u) || ((unsigned)b0 & (unsigned)((short)garr[i1 & 7u] > (signed char)r0.y)));
                    if ((unsigned)e0) break;
                    do { if (--fuel == 0u) goto done;
                        L2: if (--fuel == 0u) goto done;
                        L3: if (--fuel == 0u) goto done;
                    } while (i2++ < 3u && (u0 - 0x56c39d92u));
                }
                break; (void)((5u % ((fuel / (garr[u2 & 7u] | 1u)) | 1u)));
                switch (0x10000u & 7u) {
                    switch ((unsigned)c0 & 7u) {
                        m0 ^= ~(unsigned)((int)(unsigned)((short)(r0.y - (0x7e2f3916u - u0)) > (signed char)*q0) >= (int)(unsigned)d0);
                    }
                    a0[(g0 >> ((unsigned)l0 & 31u)) & 3u] = (unsigned)((garr[i1 & 7u] + u3) && (0x7743af51u ^ (unsigned)c0));
                    f0 = f0 * 0.5f + (float)((unsigned)((((unsigned)d0 - *mp) ? g1 : (unsigned)(x0 >> 70)) == 3u) & 255u);
                    if ((a0[i0 & 3u] * (unsigned)c1)) {
                        r0.x = (unsigned)l0;
                        c0 = (unsigned char)(unsigned)((short)(unsigned)(short)(r0.x ? 0xffffffffu : p2) > (signed char)((unsigned)(x0 >> 70) - 0xffffffffu));
                        goto L2;
                        break; (void)((unsigned)((int)m0 < (int)0x57eb7454u));
                        L4: if (--fuel == 0u) goto done;
                        case 5u: ;
                    } else {
                        case 1u: ;
                        u2 = (unsigned)(unsigned char)(((0x51d8b196u / (0xffffffffu | 1u)) + (unsigned)d0) - (unsigned)h1);
                        q0 = &garr[(fuel & 0xe9e56786u) & 7u];
                        case 6u: ;
                    }
                    case 7u: ;
                }
                while (i1++ < 4u && (0x10000u - (unsigned)(unsigned char)((unsigned)h0 << ((unsigned)c0 & 31u)))) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (((fuel | g1) | (a0[u1 & 3u] << (u2 & 31u))) - i0);
                    a0[(r0.x << (3u & 31u)) & 3u] = (unsigned)((unsigned)l0 || (0xffffffffu - (r0.x << (i0 & 31u))));
                    c0 = (unsigned char)((i1 >> ((unsigned)s1 & 31u)) ? m0 : i2);
                    break; (void)((*q0 % (a0[u1 & 3u] | 1u)));
                }
                break; (void)((r0.x & (2u / (5u | 1u))));
            }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                garr[(unsigned)((short)p2 > (signed char)g0) & 7u] = (unsigned)(unsigned char)(garr[i1 & 7u] + (unsigned)l0);
                break; (void)(p1);
                if ((7u / (0xffffffffu | 1u))) break;
            }
            do { if (--fuel == 0u) goto done;
                g0 = ((unsigned)x0 ? r0.x : 0x4341ae45u);
                if ((unsigned)((int)(unsigned)((int)0x34342643u < (int)a0[u1 & 3u]) >= (int)(unsigned)s0)) break;
            } while (i1++ < 3u && ~((p1 << ((unsigned)b0 & 31u)) | 7u));
            if (u3 == 7u) return (unsigned)(r0.y && (unsigned)!(i0 * (unsigned)((int)(unsigned)(short)((unsigned)(x0 >> 70) ^ u1) < (int)r0.x)));
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                u2 = ((0x10000u % ((unsigned)x0 | 1u)) << (g0 & 31u));
                break; (void)(garr[u2 & 7u]);
            }
            if ((unsigned)(i1 && ((unsigned)b0 - 0x2a4c20b7u))) goto done;
        }
        if ((unsigned)(short)(unsigned)((short)(unsigned)f0 > (signed char)(garr[i1 & 7u] | (unsigned)w0))) goto L2;
        *mp = (u0 & *q0);
        c0 = (unsigned char)i1;
    }
    for (;;) { if (--fuel == 0u) goto done;
        switch (0xffffffffu & 7u) {
            case 1u: ;
        }
        break; (void)(r0.x);
        do { if (--fuel == 0u) goto done;
            while (i2++ < 5u && (unsigned)e0) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (fuel / ((unsigned)(x0 >> 70) | 1u));
                if (0x7fffffffu) break;
            }
            *q0 = (unsigned)((int)(-(((unsigned)(w0 >> 29) % (a0[i0 & 3u] | 1u)) | (unsigned)(x0 >> 70)) % (0x7fffffffu | 1u)) >= (int)(unsigned)c0);
            if ((i0 >> (p0 & 31u))) continue;
            u3 = (unsigned)((~(unsigned)((int)fuel >= (int)(1u % (0xe4cda90bu | 1u))) / ((unsigned)h0 | 1u)) || 1u);
        } while (i1++ < 2u && (3u >> (8u & 31u)));
    }
    if ((unsigned)((int)u0 < (int)(unsigned)(w0 >> 29))) {
        { unsigned t2; double z2; if (((u2 / (0x2870b324u | 1u))) & 1u) { t2 = (u1 / ((unsigned)f0 | 1u)); z2 = (double)(((unsigned)(short)(((unsigned)w0 ^ 0x224794bbu) ^ 0x7fffffffu)) & 255u); } if (((u2 / (0x2870b324u | 1u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            h1 = (unsigned short)(h1 + 0x7fffffffu);
            if (u3 == 7u) return (unsigned)w0;
            r0.y ^= (unsigned)(p0 < r0.y);
            goto L2;
            *q0 = (unsigned)(signed char)((unsigned)f0 & u1);
            goto L2;
        }
    }
    { unsigned t3; double z3; if (((a0[i0 & 3u] ^ (unsigned)x0)) & 1u) { t3 = (0x7fffffffu ? 0x5f38e626u : 0x10000u); z3 = (double)(((u0 % ((unsigned)h0 | 1u))) & 255u); } if (((a0[i0 & 3u] ^ (unsigned)x0)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        while (i0++ < 7u && (unsigned)((short)u0 > (signed char)0x10000u)) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)w0 >= (int)0xffffffffu)) break;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                while (i2++ < 5u && (i0 - *mp)) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)((int)(0x7fffffffu - (unsigned)x0) >= (int)0x7fffffffu));
                    break; (void)((unsigned)!(2u >> (r0.y & 31u)));
                }
                if ((i2 >> ((r0.x | 0x10000u) & 31u))) break;
                garr[(i0 % ((unsigned)(w0 >> 29) | 1u)) & 7u] = (unsigned)h0;
                w0 = w0 * 6364136223846793005ull + p2;
            }
            q0 = &garr[((p1 ^ i2) % ((unsigned)f0 | 1u)) & 7u];
        }
        g1 += (unsigned)((int)(unsigned)(unsigned char)(0xb2eb4980u ? 0x80000000u : 1u) >= (int)((unsigned)(x0 >> 70) >> (p1 & 31u)));
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + 0x60cb4906u;
            break; (void)(r0.x);
            continue; (void)(((u1 >> (r0.x & 31u)) % ((unsigned)e0 | 1u)));
            if (*mp) break;
            if ((unsigned)(unsigned char)((u0 << ((unsigned)f0 & 31u)) + (unsigned)f0)) break;
            s0 = (int)(0x80000000u << (8u & 31u));
        }
    }
    e0 = e0 * 0.5L + (long double)(((unsigned)c0 * (unsigned)(a0[u1 & 3u] < r0.x)) & 1023u);
    *q0 = (p0 / (7u | 1u));
    while (i0++ < 4u && (unsigned)f0) { if (--fuel == 0u) goto done;
        break; (void)(~(unsigned)(0x10000u == (0x104302b3u + *mp)));
        m0 ^= ((unsigned)(p1 < 0xffb77329u) / ((m0 % (0x10000u | 1u)) | 1u));
        while ((unsigned)((unsigned)x0 || (r0.x | (unsigned)d0))) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + *q0;
        }
        r0.y ^= ((unsigned)((unsigned)s1 < v0) % (-(1u ^ 0x6459dbf0u) | 1u));
        break; (void)(0x7fffffffu);
        if ((garr[i1 & 7u] * (unsigned)c1)) break;
    }
    if (garr[i1 & 7u]) goto L3;
    if ((0xc71ff093u / (a0[i0 & 3u] | 1u))) goto L4;
    h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)((unsigned)b0 || (unsigned)l0) > (signed char)(r0.x ^ (unsigned)c0)));
    c0 = (unsigned char)p0;
    i2 = (unsigned)((short)(p2 + (unsigned)((int)(unsigned)((short)p2 > (signed char)r0.x) < (int)0x7fffffffu)) > (signed char)0x10000u) & 15u;
    if ((u2 ^ r0.x)) goto L0;
    goto L4;
    if (i2) goto L2;
    if (((unsigned)s0 ^ 0x8f9e452au)) goto done;
    l0 = (long)((unsigned long)l0 + a0[i0 & 3u]);
    c1 = (signed char)(g1 << ((fuel | v0) & 31u));
    *q0 = (unsigned)((int)0x1ea195f6u >= (int)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0xe3e93831u));
    l0 = (long)((unsigned long)l0 + ((0x7fffffffu ^ 6u) * ((0x80000000u << ((unsigned)(w0 >> 29) & 31u)) << (0x10000u & 31u))));
    goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((0x7fffffffu | 0x80000000u) < p2), (unsigned)((unsigned)(w0 >> 29) == (unsigned)b0), (0x80000000u | (a0[i0 & 3u] << (7u & 31u)))); }
    s0 = (int)(0x3f5e7792u % ((unsigned)((int)r0.x < (int)garr[u2 & 7u]) | 1u));
    L0: if (--fuel == 0u) goto done;
    if ((0x80000000u * *mp)) goto L3;
    if (((unsigned)(unsigned char)(unsigned)((short)(unsigned)f0 > (signed char)0xffffffffu) % (p1 | 1u))) {
        r0.y ^= ((unsigned)(u1 < ((unsigned)f0 | (unsigned)s1)) / ((unsigned)((short)r0.y > (signed char)u3) | 1u));
        e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)e0 > (signed char)-(u1 % (u1 | 1u))) & 1023u);
        { unsigned t0; double z0; if ((0xd140b5d6u) & 1u) { t0 = (unsigned)((unsigned)(1u == (unsigned)f0) && u2); z0 = (double)((((unsigned)c0 ? u3 : p0)) & 255u); } if ((0xd140b5d6u) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            u1 = (unsigned)(*mp || (i2 ? a0[i0 & 3u] : garr[i1 & 7u]));
            u3 ^= (unsigned)((int)(unsigned)x0 < (int)-(((unsigned)c1 | (unsigned)(u1 && 4u)) * 0x10000u));
            r0.y ^= (unsigned)((int)0x4a035b71u < (int)((0x46077e56u % ((unsigned)e0 | 1u)) & (unsigned)l0));
            { unsigned t1; double z1; if ((a0[i0 & 3u]) & 1u) { t1 = (u1 + 0x705c03c1u); z1 = (double)((((unsigned)d0 ^ 4u)) & 255u); } if ((a0[i0 & 3u]) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                L1: if (--fuel == 0u) goto done;
                goto L4;
                if ((unsigned)((unsigned)(unsigned char)(*mp ^ (unsigned)f0) < 0x8abefd20u)) goto done;
                if (i1) goto L3;
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)s0 && r0.y);
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s0, -(unsigned)((int)u1 >= (int)(unsigned)((int)*mp >= (int)(unsigned)b0)), (unsigned)c1); }
            }
            if ((unsigned)(signed char)(unsigned)(v0 && 0u)) goto L1;
        }
    } else {
        while (i0++ < 2u && ((unsigned)e0 | u0)) { if (--fuel == 0u) goto done;
            if ((0x10000u / ((m0 % (u0 | 1u)) | 1u))) goto L2;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                g1 += (unsigned)((int)-(unsigned)(0x4526620du < (unsigned)w0) < (int)i0);
                d0 = d0 * 0.5 + (double)((unsigned)((int)u1 < (int)((unsigned)(0x80000000u < (unsigned)h0) << (5u & 31u))) & 1023u);
            }
            r0.y ^= ((unsigned)w0 - 0x3c6c74f3u);
            u1 = u1 * 0x9e3779b1u + ((0xe91a025u * (unsigned)((int)p1 < (int)garr[i1 & 7u])) + (unsigned)(0x7fffffffu < 0x1514176du));
        }
        if (((unsigned)h1 << ((unsigned)e0 & 31u))) {
            u3 = (0x47233746u >> ((0x27c7eb5bu - ((unsigned)x0 << (0xa4f38af3u & 31u))) & 31u));
            if (0x52255cfdu) goto L2;
            if (0x27af89f3u) {
                switch ((8u - 9u) & 7u) {
                    s1 = (int)((unsigned)s1 + (unsigned)(0x7fffffffu < ((unsigned)f0 * (0xffffffffu ? garr[u2 & 7u] : 6u))));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((fuel * r0.y), 4u, (u0 | (unsigned)(2u < *q0))); }
                    garr[0x3e70a819u & 7u] = -(*mp * ((unsigned)c1 << (r0.x & 31u)));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(short)(unsigned)((short)(unsigned)s1 > (signed char)v0), r0.x, u0); }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)((unsigned)c1 < r0.x) || 1u), ((fuel | (unsigned)e0) * (unsigned)(w0 >> 29)), (0x25f4093du + 0xb374fce7u)); }
                    v0 = 0x7fffffffu;
                }
                w0 = w0 * 6364136223846793005ull + fuel;
                m0 ^= (unsigned)((int)(unsigned)(p0 && u2) >= (int)(p1 + (unsigned)e0));
                switch ((r0.y + (unsigned)e0) & 7u) {
                    v0 = (r0.y - (0x7fffffffu >> ((unsigned)x0 & 31u)));
                    w0 = w0 * 6364136223846793005ull + ((unsigned)(x0 >> 70) % (0xbc583199u | 1u));
                }
            } else {
                if ((u2 << (u1 & 31u))) goto L0;
                { unsigned t2; double z2; if ((((unsigned)(w0 >> 29) % (6u | 1u))) & 1u) { t2 = (unsigned)c0; z2 = (double)(((unsigned)(w0 >> 29)) & 255u); } if ((((unsigned)(w0 >> 29) % (6u | 1u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    *q0 = u3;
                    if ((((unsigned)s1 & (unsigned)c0) - p1)) {
                        if (garr[u2 & 7u]) goto L2;
                        L2: if (--fuel == 0u) goto done;
                        *q0 += (3u / ((unsigned)f0 | 1u));
                        if (((unsigned)(p2 && (unsigned)c1) | 0x7fffffffu)) goto L3;
                    } else {
                        goto L1;
                    }
                    b0 = ((unsigned)((int)(unsigned)s0 < (int)(unsigned)s1) - 0xf23a4b11u) != 0u;
                }
                L3: if (--fuel == 0u) goto done;
                if ((unsigned)((short)g1 > (signed char)(*q0 | 0x80000000u))) {
                    e0 = e0 * 0.5L + (long double)((v0 << (0x7fffffffu & 31u)) & 1023u);
                }
            }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((m0 >> ((i2 % ((unsigned)b0 | 1u)) & 31u)), (unsigned)((int)(unsigned)x0 < (int)6u), 2u); }
                if (0x942cc6b5u) break;
                switch ((1u | garr[u2 & 7u]) & 7u) {
                    if ((4u + (unsigned)((unsigned)s1 < 4u))) break;
                    h0 = (short)(unsigned)((int)m0 < (int)0x80000000u);
                    if (0x7fffffffu) break;
                }
            } while (i0++ < 4u && (unsigned)(unsigned char)(unsigned)((unsigned)x0 && 0xe7d9ea37u));
            q0 = &garr[(unsigned)((int)(*q0 % (r0.x | 1u)) >= (int)g1) & 7u];
        }
    }
    { unsigned t3; double z3; if ((u0) & 1u) { t3 = (u0 & (u2 - (unsigned)(x0 >> 70))); z3 = (double)(((unsigned)((unsigned)l0 && a0[i0 & 3u])) & 255u); } if ((u0) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
        u3 ^= (unsigned)((int)(unsigned)b0 < (int)(0xffffffffu ? 0x80000000u : ((unsigned)s1 ^ a0[i0 & 3u])));
        d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)c0 > (signed char)3u) & 1023u);
        if ((~(unsigned)((short)*q0 > (signed char)*q0) >> (p1 & 31u))) goto L1;
    }
    i0 = (fuel | (unsigned)((((unsigned)c0 | g1) % ((unsigned)c0 | 1u)) < g1)) & 15u;
    if (budget != 0u) { budget -= 1u; u3 = fn0((u3 >> (p0 & 31u)), ((unsigned)(w0 >> 29) * u3), 7u); }
    goto done;
    { unsigned t4; double z4; if ((((unsigned)((short)0x7fffffffu > (signed char)g0) * (unsigned)e0)) & 1u) { t4 = *mp; z4 = (double)((((unsigned)(*q0 && i2) & (unsigned)d0)) & 255u); } if ((((unsigned)((short)0x7fffffffu > (signed char)g0) * (unsigned)e0)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
        if ((unsigned)((short)(unsigned)x0 > (signed char)a0[i0 & 3u])) {
            h1 = (unsigned short)(h1 + 6u);
            goto L4;
        } else {
            c0 = (unsigned char)(unsigned)((unsigned)(0x10000u < u3) == (1u | (unsigned)(a0[i0 & 3u] == g0)));
            for (;;) { if (--fuel == 0u) goto done;
                continue; (void)(0x4d07ed15u);
                if ((unsigned)((unsigned)(w0 >> 29) || (u2 % (0xca9d5b90u | 1u)))) break;
            }
        }
        if ((0u / (garr[i1 & 7u] | 1u))) goto L1;
    }
    do { if (--fuel == 0u) goto done;
        break; (void)((0x7fffffffu / (0x7fffffffu | 1u)));
        goto L4;
        v0 = (unsigned)((unsigned)f0 && (unsigned)((unsigned)((unsigned)e0 && m0) && 0x723efb84u));
    } while (i0++ < 2u && -((unsigned)(signed char)((unsigned)(x0 >> 70) % (0x7fffffffu | 1u)) & u2));
    d0 = d0 * 0.5 + (double)((unsigned)((int)((unsigned)f0 - (unsigned)d0) >= (int)garr[u2 & 7u]) & 1023u);
    { unsigned t5; double z5; if (((((unsigned)h1 | 0x80000000u) - (unsigned)h1)) & 1u) { t5 = (i0 - ((unsigned)h0 | 0x10000u)); z5 = (double)(((unsigned)((int)(unsigned)h1 < (int)(5u >> (0x1a540528u & 31u)))) & 255u); } if (((((unsigned)h1 | 0x80000000u) - (unsigned)h1)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        w0 ^= (unsigned long long)0x10000u << (((unsigned)((int)7u < (int)(unsigned)d0) >> ((unsigned)w0 & 31u)) & 63u);
        r0.y ^= (m0 >> (u3 & 31u));
        goto L3;
        u3 ^= ((unsigned)w0 & 8u);
    }
    if ((unsigned)h1) goto L2;
    m0 ^= ((unsigned)((unsigned)((int)i1 >= (int)0x931587e3u) == (6u << (*mp & 31u))) / ((unsigned)h0 | 1u));
    if (budget != 0u) { budget -= 1u; u0 = fn0(u1, fuel, garr[u2 & 7u]); }
    if (budget != 0u) { budget -= 1u; u3 = fn0(~(0x1e11831fu >> (garr[u2 & 7u] & 31u)), (unsigned)((int)1u >= (int)(unsigned)((int)*mp < (int)(unsigned)w0)), (p2 >> (garr[u2 & 7u] & 31u))); }
    if (a0[i0 & 3u]) {
        r0.x = ((0x7fffffffu << (i0 & 31u)) >> (((unsigned)h0 << ((unsigned)(short)(a0[i0 & 3u] ^ 0x60195137u) & 31u)) & 31u));
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)c0, (unsigned)l0, (unsigned)((short)(unsigned)x0 > (signed char)(unsigned)((int)0x80000000u < (int)u3))); }
        switch ((unsigned)(w0 >> 29) & 7u) {
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *mp = (unsigned)((unsigned)((int)(unsigned)((int)p0 >= (int)u2) >= (int)u2) < r0.x);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)b0 - u1), g0, (u0 - (unsigned)l0)); }
                    *q0 = (unsigned)((int)(unsigned)c1 >= (int)6u);
                }
            }
            if (((*mp + a0[u1 & 3u]) ^ r0.y)) {
                if (budget != 0u) { budget -= 1u; u0 = fn0(0x3966b0e3u, (unsigned)(short)(((unsigned)e0 - g1) - p2), (unsigned)(m0 && (unsigned)s1)); }
            } else {
                u2 = (unsigned)(0xffffffffu == (unsigned)((int)(unsigned)((int)0xadc465a7u >= (int)0x1ddc76f8u) < (int)(g0 >> (5u & 31u))));
            }
        }
    } else {
        if (0x10000u) {
            { unsigned t6; double z6; if ((((unsigned)d0 * ((unsigned)(w0 >> 29) % (g0 | 1u)))) & 1u) { t6 = (unsigned)(0x7fffffffu == (u1 + fuel)); z6 = (double)(((unsigned)x0) & 255u); } if ((((unsigned)d0 * ((unsigned)(w0 >> 29) % (g0 | 1u)))) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                g0 = (unsigned)w0;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((i0 ^ p2) && g0), ~((unsigned)x0 - a0[u1 & 3u]), (unsigned)(unsigned char)((unsigned)c0 << ((unsigned)b0 & 31u))); }
                if (budget != 0u) { budget -= 1u; u2 = fn0((9u % (2u | 1u)), (i2 + i1), a0[u1 & 3u]); }
                if (budget != 0u) { budget -= 1u; u0 = fn0(i0, ((unsigned)(w0 >> 29) & (unsigned)(w0 >> 29)), (unsigned)((unsigned)h1 || 0u)); }
                if ((unsigned)((int)i2 < (int)g1)) goto L3;
                goto L4;
            }
        }
        w0 ^= (unsigned long long)(unsigned)(short)(2u / ((unsigned)s1 | 1u)) << ((unsigned)!(0xd67f3671u * (unsigned)((0x7b5f38deu ? p0 : 0x10000u) == *mp)) & 63u);
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)(signed char)(unsigned)((int)1u >= (int)p0) & 7u) {
                if ((unsigned)((int)(a0[u1 & 3u] >> (9u & 31u)) >= (int)garr[u2 & 7u])) goto L1;
                r0.y ^= (garr[i1 & 7u] / (0x60446276u | 1u));
                u0 ^= ((unsigned)((unsigned)(r0.x == r0.x) == fuel) ^ (unsigned)((unsigned)x0 == a0[u1 & 3u]));
                if (~(a0[i0 & 3u] ? garr[i1 & 7u] : garr[u2 & 7u])) continue;
                g0 = (unsigned)(u2 || (unsigned)((unsigned)((int)~(0xf5d35069u >> ((unsigned)e0 & 31u)) >= (int)*mp) || (unsigned)(x0 >> 70)));
                u1 = u1 * 0x9e3779b1u + (((unsigned)b0 + (unsigned)(w0 >> 29)) / (((unsigned)((int)r0.y < (int)0x10000u) * 0x6fcfa4dau) | 1u));
            }
            v0 = u0;
            { unsigned t7; double z7; if ((((*q0 / ((unsigned)f0 | 1u)) - 0x7b1e7da9u)) & 1u) { t7 = (unsigned)h1; z7 = (double)((*mp) & 255u); } if ((((*q0 / ((unsigned)f0 | 1u)) - 0x7b1e7da9u)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                garr[u1 & 7u] = (unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)(-(unsigned)(g0 && u2) == a0[u1 & 3u]));
                if ((unsigned)((unsigned)(w0 >> 29) < (i2 | i2))) break;
                if (((unsigned)b0 & ((unsigned)h1 / ((unsigned)s1 | 1u)))) break;
                garr[(unsigned)!(unsigned)((short)1u > (signed char)i0) & 7u] = (unsigned)(0xc7bc5788u && ((0x80000000u | 0x96d3b313u) % (9u | 1u)));
            }
            { unsigned t8; double z8; if (((unsigned)((int)i1 >= (int)i2)) & 1u) { t8 = (unsigned)(unsigned char)(unsigned)((int)0x10000u < (int)0x29766684u); z8 = (double)(((unsigned)((short)p2 > (signed char)(unsigned)h0)) & 255u); } if (((unsigned)((int)i1 >= (int)i2)) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                if (budget != 0u) { budget -= 1u; u2 = fn0(a0[u1 & 3u], ((unsigned)d0 | 6u), (unsigned)((unsigned)(a0[u1 & 3u] == (unsigned)s0) < u2)); }
                f0 = f0 * 0.5f + (float)(((unsigned)(signed char)(0x80000000u >> ((unsigned)s0 & 31u)) % (~(unsigned)((unsigned)h1 == 0x10000u) | 1u)) & 255u);
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)x0, (unsigned)(unsigned char)((unsigned)l0 - u0), r0.y); }
            while (i1++ < 7u && (p1 % (p2 | 1u))) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + ((unsigned)((unsigned)h0 == p2) - (unsigned)((3u % (*mp | 1u)) || (unsigned)(x0 >> 70))));
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(r0.x == (unsigned)d0) < garr[u2 & 7u]), 0xa1656c18u, 0xc566fdcu); }
                L4: if (--fuel == 0u) goto done;
            }
        }
    }
    switch ((0x989b6301u ^ (g0 / (6u | 1u))) & 7u) {
        q0 = &garr[(-((unsigned)x0 % (((garr[u2 & 7u] | i1) & (unsigned)e0) | 1u)) | g0) & 7u];
        if ((p0 >> (p2 & 31u))) {
            if ((0x10000u / (0xe49b9998u | 1u))) {
                if ((unsigned)((unsigned)e0 < (unsigned)((unsigned)h0 && (unsigned)(w0 >> 29)))) goto L1;
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)c0 & r0.y), (0x7fffffffu >> ((unsigned)(0xd9cec004u && 0x8509c6b8u) & 31u)), (unsigned)h1); }
            }
            s0 = (int)(garr[u2 & 7u] >> (((unsigned)h0 ^ (unsigned)(4u < i1)) & 31u));
            r0.x = (unsigned)(short)(unsigned)((int)0xffffffffu < (int)(unsigned)s0);
            f0 = f0 * 0.5f + (float)(((a0[i0 & 3u] * a0[u1 & 3u]) ^ 0x57d71675u) & 255u);
        } else {
            v0 = (unsigned)(short)(unsigned)(0x10000u || ((unsigned)w0 >> (u2 & 31u)));
        }
        s0 = (int)0u;
    }
    s0 = (int)(unsigned)((unsigned)(signed char)(g1 & 8u) == (unsigned)(m0 == 0xffffffffu));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (u3) {
            m0 ^= (unsigned)(0x57df3e46u == (u0 >> ((unsigned)s1 & 31u)));
            f0 = f0 * 0.5f + (float)((i1 + ((unsigned)f0 | (garr[i1 & 7u] >> (a0[i0 & 3u] & 31u)))) & 255u);
            if (budget != 0u) { budget -= 1u; u2 = fn0(p1, (u3 + (unsigned)e0), 0xd0d82e05u); }
        }
        i1 = (unsigned)(unsigned char)((unsigned)(short)(unsigned)((short)u0 > (signed char)p0) % ((unsigned)(r0.y < 0xffffffffu) | 1u)) & 15u;
        do { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + *mp;
            i0 = ((unsigned)d0 + (unsigned)((short)0xffffffffu > (signed char)u1)) & 15u;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)w0, (garr[u2 & 7u] / ((unsigned)((unsigned)d0 && 0x80000000u) | 1u)), 9u); }
            r0.x = (((unsigned)l0 % ((p0 >> ((unsigned)c1 & 31u)) | 1u)) ^ (unsigned)((int)(unsigned)x0 < (int)2u));
        } while (i1++ < 3u && ((u3 % ((unsigned)d0 | 1u)) * fuel));
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.x = ((unsigned)h0 & (((unsigned)(*mp < 6u) - (unsigned)c1) << ((unsigned)d0 & 31u)));
            h1 = (unsigned short)(h1 + ((unsigned)e0 % ((~(unsigned)(fuel == (unsigned)(w0 >> 29)) ^ 3u) | 1u)));
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (2u) break;
                s0 = (int)(unsigned)((short)(unsigned)(unsigned char)(unsigned)((int)(0x80000000u - (unsigned)(u1 && 0x80000000u)) < (int)u2) > (signed char)u3);
                garr[r0.x & 7u] = (unsigned)((int)(0x7fffffffu >> (garr[u2 & 7u] & 31u)) >= (int)m0);
            }
            switch ((p1 << (1u & 31u)) & 7u) {
                d0 = d0 * 0.5 + (double)((fuel ^ ((unsigned)x0 - g1)) & 1023u);
                if ((0xffffffffu << ((unsigned)((int)u2 < (int)u3) & 31u))) continue;
            }
            switch ((unsigned)(r0.x < 0x535af11du) & 7u) {
                u0 ^= (unsigned)s1;
                while (((unsigned)c1 * 0x80000000u)) { if (--fuel == 0u) goto done;
                    if ((unsigned)e0) {
                        if (0xe389f1f9u) goto L3;
                        continue; (void)((unsigned)((unsigned)s0 == (unsigned)b0));
                        if (r0.y) continue;
                        r0.x = ((v0 * garr[i1 & 7u]) + (unsigned)((int)0xa6679573u >= (int)p2));
                        if (r0.y) goto L1;
                    } else {
                        u3 = (8u - p0);
                    }
                    if (((unsigned)d0 >> (0x6d36cf18u & 31u))) goto L1;
                }
                { unsigned t9; double z9; if (((0xffffffffu ? u3 : 0xffffffffu)) & 1u) { t9 = (unsigned)((int)(unsigned)x0 < (int)p0); z9 = (double)(((unsigned)((int)0x10000u >= (int)(unsigned)!(unsigned)((short)(unsigned)h0 > (signed char)garr[u2 & 7u]))) & 255u); } if (((0xffffffffu ? u3 : 0xffffffffu)) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
                    case 7u: ;
                    { unsigned t10; double z10; if ((m0) & 1u) { t10 = *mp; z10 = (double)(((unsigned)w0) & 255u); } if ((m0) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
                        if (0x80000000u) break;
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)h0, (garr[i1 & 7u] - g0), r0.y); }
                    }
                    if (((unsigned)((unsigned)f0 == 4u) - 0x7fffffffu)) goto L2;
                    case 2u: ;
                    default: ;
                    if (v0) {
                        c1 = (signed char)(unsigned)((unsigned)l0 && r0.y);
                        u2 += (i2 ^ 3u);
                        if (budget != 0u) { budget -= 1u; u2 = fn0((0x8b295f7fu << ((unsigned)((int)0x80000000u < (int)a0[i0 & 3u]) & 31u)), (p2 & u3), ((unsigned)c1 % (-(unsigned)(0xa5dced37u == (unsigned)(w0 >> 29)) | 1u))); }
                        i2 = ((unsigned)(unsigned char)(unsigned)((int)(unsigned)s0 >= (int)0xef016f7fu) ^ (unsigned)w0) & 15u;
                        if ((unsigned)((short)0x114fa54bu > (signed char)(unsigned)!((unsigned)c1 | (unsigned)c1))) break;
                        *q0 = (unsigned)((0u - 4u) && 2u);
                    } else {
                        x0 = x0 * 0x100000001b3ull + (((unsigned)(unsigned char)(unsigned)((u1 & (unsigned)s0) == (unsigned)c0) & 0x4830352au) << ((unsigned)e0 & 31u));
                        break; (void)(0x67a23419u);
                        if (budget != 0u) { budget -= 1u; u1 = fn0(1u, (unsigned)s1, 1u); }
                    }
                }
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)(-((unsigned)d0 / (((unsigned)f0 - 0x80000000u) | 1u)) & 1023u);
                    g1 += (p2 * (((unsigned)l0 ^ g0) >> ((unsigned)((short)*q0 > (signed char)a0[u1 & 3u]) & 31u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(signed char)(unsigned)((short)i1 > (signed char)garr[i1 & 7u]), (unsigned)((unsigned)(w0 >> 29) || 0xd3015794u), ((unsigned)c0 / (3u | 1u))); }
                    if (budget != 0u) { budget -= 1u; u0 = fn0(6u, (unsigned)(0x10000u < (unsigned)x0), (r0.y & (unsigned)w0)); }
                    u3 = u3 * 0x9e3779b1u + (unsigned)x0;
                    w0 = w0 * 6364136223846793005ull + 0xd0d0f7f3u;
                }
            }
        }
        break; (void)((unsigned)h0);
    }
    do { if (--fuel == 0u) goto done;
        r0.y ^= ~((unsigned)(*q0 < r0.x) - (unsigned)(~(unsigned)((int)0xd260c313u >= (int)(unsigned)(w0 >> 29)) == 0x82b44e2cu));
        if ((unsigned)((int)u0 >= (int)g0)) {
            if ((u3 * (unsigned)((int)0x6ff09a2cu >= (int)(unsigned)l0))) continue;
            break; (void)(0xf8281fb7u);
            if ((0x32ad95cu / ((unsigned)(0xa9636a94u == 0x2eac808u) | 1u))) break;
            if (u3 == 7u) return (0u - (9u / (9u | 1u)));
        }
    } while (i0++ < 7u && (unsigned)(w0 >> 29));
    c0 = (unsigned char)(unsigned)(0x6fd04badu && 7u);
    if (v0) {
        u0 ^= r0.y;
        w0 ^= (unsigned long long)u1 << (((unsigned)(short)(unsigned)((unsigned)e0 || a0[u1 & 3u]) & ((unsigned)l0 ? a0[u1 & 3u] : (unsigned)c0)) & 63u);
        goto done;
        if (((m0 + (unsigned)s1) * 5u)) goto done;
        i0 = ((unsigned)x0 << ((unsigned)l0 & 31u)) & 15u;
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (a0[i0 & 3u]) goto L4;
        if ((0x80000000u & 2u)) goto L1;
        if (budget != 0u) { budget -= 1u; u3 = fn0(0xddd812a9u, (v0 - (unsigned)(w0 >> 29)), p1); }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0(8u, u3, ((unsigned)x0 + (unsigned)(unsigned char)(0xd3c73a57u + g0))); }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = fuel;
        b0 = (v0 * (unsigned)((unsigned)c1 == 0xe9b8e2beu)) != 0u;
        if (budget != 0u) { budget -= 1u; u1 = fn0(u2, (unsigned)(unsigned char)(unsigned)(i0 || (unsigned)f0), ((p1 - (unsigned)h0) & fuel)); }
    }
    if ((unsigned)l0) {
        if ((unsigned)!(unsigned)(fuel || (unsigned)(u2 == u2))) {
            goto L2;
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    q0 = &garr[0x70ada0afu & 7u];
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)((unsigned)d0 ^ -((unsigned)d0 >> (u1 & 31u))), (unsigned)l0, (unsigned)(x0 >> 70)); }
                }
                w0 ^= (unsigned long long)(r0.y * 3u) << ((0xffffffffu ^ (unsigned)e0) & 63u);
                r0.x = (9u / ((unsigned)s1 | 1u));
                g0 = (((i0 * u3) * (unsigned)(p2 == *q0)) + 9u);
                if (budget != 0u) { budget -= 1u; u1 = fn0(0xd1dd5871u, 0x10000u, ((unsigned)f0 + (u1 * (unsigned)c0))); }
                if (budget != 0u) { budget -= 1u; u3 = fn0(5u, u2, (unsigned)((unsigned)((int)p2 >= (int)a0[i0 & 3u]) && 4u)); }
            }
            if (0x7fffffffu) goto done;
        }
        c0 = (unsigned char)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(g1 + 9u));
        d0 = d0 * 0.5 + (double)((unsigned)(i2 || garr[i1 & 7u]) & 1023u);
        i0 = (unsigned)(0x7fffffffu == (unsigned)(short)((unsigned)((unsigned)b0 < 6u) + 0x10000u)) & 15u;
        if (u0) goto L4;
        if ((unsigned)((int)(r0.x << (0xb5693619u & 31u)) < (int)u2)) goto L0;
    }
    h1 = (unsigned short)(h1 + ((unsigned)(signed char)(3u * u2) - (unsigned)(w0 >> 29)));
    if ((unsigned)!((unsigned)d0 - i2)) {
        if (fuel) {
            a0[0xffffffffu & 3u] = (0x8b36a7bcu >> ((unsigned)(*q0 < (unsigned)(0xd2913457u == (unsigned)x0)) & 31u));
            w0 = w0 * 6364136223846793005ull + (unsigned)x0;
            if (~(u2 | (unsigned)h1)) {
                goto L4;
                h1 = (unsigned short)(h1 + ~(unsigned)((unsigned)h0 && 0xffffffffu));
                *q0 = (unsigned)(0xe7644cafu < (unsigned)(unsigned char)(p2 >> (((unsigned)h1 & 0x93844deu) & 31u)));
            } else {
                switch ((unsigned)((int)(unsigned)e0 < (int)(p1 % (p0 | 1u))) & 7u) {
                    garr[(7u | (unsigned)b0) & 7u] = (unsigned)((unsigned)x0 || a0[u1 & 3u]);
                    a0[(r0.y % (fuel | 1u)) & 3u] = ((unsigned)((a0[u1 & 3u] + (unsigned)(0x29b9d13fu < 0x80000000u)) && 0x80000000u) / (u0 | 1u));
                }
                if ((0xffffffffu % (i0 | 1u))) {
                    *q0 = (unsigned)(short)(m0 % (u1 | 1u));
                    *mp = (unsigned)(garr[i1 & 7u] || ((a0[i0 & 3u] ^ (unsigned)c1) >> (((unsigned)b0 + i0) & 31u)));
                    w0 = w0 * 6364136223846793005ull + ((unsigned)(p1 < 3u) * 0x7fffffffu);
                } else {
                    c0 = (unsigned char)-((unsigned)(3u && 0xcb3d14a4u) - (6u >> (p0 & 31u)));
                }
                m0 ^= (unsigned)((unsigned)(unsigned char)((unsigned)x0 & 4u) < (unsigned)d0);
                u0 += (unsigned)((int)9u >= (int)(unsigned)l0);
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)s1, (unsigned)(((unsigned)h1 ^ (unsigned)w0) < 0x7fffffffu), (unsigned)((short)~(unsigned)(g1 < m0) > (signed char)r0.x)); }
            do { if (--fuel == 0u) goto done;
                switch ((unsigned)((int)2u >= (int)0x10000u) & 7u) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)c0, ((unsigned)e0 + p0), 7u); }
                    i2 = garr[u2 & 7u] & 15u;
                    if (0xa1878928u) goto done;
                }
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (a0[i0 & 3u] * (unsigned)((int)(unsigned)(m0 < 0xffffffffu) >= (int)r0.y));
                    if ((unsigned)((unsigned)(w0 >> 29) && (unsigned)w0)) break;
                }
                if (0xffffffffu) break;
            } while (i0++ < 4u && 0x7fffffffu);
            if ((0u / ((unsigned)(signed char)(r0.y << ((unsigned)l0 & 31u)) | 1u))) goto L0;
        } else {
            goto done;
            do { if (--fuel == 0u) goto done;
                g0 = (a0[u1 & 3u] / ((unsigned)((unsigned)!(unsigned)((short)u0 > (signed char)u3) && (unsigned)l0) | 1u));
                if ((unsigned)h1) {
                    if (a0[u1 & 3u]) continue;
                    goto L1;
                    if ((p1 / ((unsigned)(0x7fffffffu && 0x80000000u) | 1u))) break;
                    if (7u) {
                        e0 = e0 * 0.5L + (long double)((p2 ^ 0x7fffffffu) & 1023u);
                        if ((unsigned)(0x80000000u || p1)) break;
                        if ((unsigned)(((unsigned)f0 / (garr[u2 & 7u] | 1u)) < 0x518196cau)) break;
                        if (a0[u1 & 3u]) break;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(u2 == 0x7fffffffu), -(u2 << ((unsigned)x0 & 31u)), (4u << ((unsigned)(unsigned char)((unsigned)c0 / (u2 | 1u)) & 31u))); }
                    }
                    for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        a0[0x7fffffffu & 3u] = (u3 + (unsigned)c1);
                        if ((u1 * ((unsigned)(x0 >> 70) | (unsigned)s1))) break;
                        v0 = (unsigned)(short)(u0 - (0x14b2c92fu ^ ((unsigned)x0 * (a0[u1 & 3u] % (garr[u2 & 7u] | 1u)))));
                        if (budget != 0u) { budget -= 1u; u2 = fn0(0x7fffffffu, p0, 0xaa316f1au); }
                    }
                    if (fuel < 8u) return (unsigned)(g1 < (unsigned)(short)(unsigned)((unsigned)!(r0.x & u2) && (unsigned)((unsigned)x0 == 4u)));
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)(v0 || p0) > (signed char)g0), (unsigned)((short)7u > (signed char)(unsigned)(x0 >> 70)), p0); }
                }
                u0 = u0 * 0x9e3779b1u + (unsigned)((int)i0 < (int)(unsigned)(1u == (unsigned)(x0 >> 70)));
                if ((r0.x * i1)) {
                    if (((unsigned)((short)u1 > (signed char)g1) >> (g0 & 31u))) goto done;
                }
                switch ((a0[u1 & 3u] ^ (*mp - (unsigned)c0)) & 7u) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0(i1, -(unsigned)((int)(0x80000000u / (0xffffffffu | 1u)) >= (int)*mp), -(unsigned)((unsigned)!(unsigned)(*mp || u1) == 0xe86dc1a0u)); }
                    c1 = (signed char)(unsigned)((int)v0 < (int)i0);
                    c1 = (signed char)~(((unsigned)b0 << (p0 & 31u)) | *q0);
                    a0[(unsigned)s1 & 3u] = (u1 << ((unsigned)(((unsigned)(x0 >> 70) * 0x5329c1dau) == r0.y) & 31u));
                }
            } while (i0++ < 4u && (unsigned)(signed char)(g1 + 1u));
        }
        r0.x = ((unsigned)w0 | 0xffffffffu);
        for (;;) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)(signed char)((u2 / ((0x4406e811u >> ((unsigned)((unsigned)c0 && garr[i1 & 7u]) & 31u)) | 1u)) >> (*q0 & 31u)) & 1023u);
            if ((unsigned)((unsigned)w0 && (unsigned)c0)) break;
        }
        if (((unsigned)((int)(unsigned)l0 < (int)(unsigned)s0) * (unsigned)s1)) {
            a0[(unsigned)c1 & 3u] = (((unsigned)h1 % ((u1 * m0) | 1u)) - (i0 % (0u | 1u)));
            c0 = (unsigned char)(unsigned)!(((unsigned)e0 + u0) | (unsigned)((int)(unsigned)c0 < (int)r0.x));
            i1 = (unsigned)((int)((unsigned)e0 - 0x6252c707u) >= (int)(unsigned)((int)0x80000000u >= (int)a0[u1 & 3u])) & 15u;
            while (i0++ < 6u && (unsigned)(signed char)(((unsigned)s1 << (0xb2883b05u & 31u)) >> ((unsigned)s1 & 31u))) { if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)((m0 & 0x384d56b7u) && ((unsigned)((short)(unsigned)c0 > (signed char)a0[u1 & 3u]) << (u3 & 31u))) & 7u];
                if ((unsigned)s1) {
                    x0 = x0 * 0x100000001b3ull + ((unsigned)(0xffffffffu || (1u << (garr[u2 & 7u] & 31u))) ^ g1);
                    g0 = (unsigned)((short)(unsigned)e0 > (signed char)7u);
                    if (a0[u1 & 3u]) break;
                    u0 = u0 * 0x9e3779b1u + (unsigned)(short)(g1 % (-(unsigned)((int)0x7fffffffu >= (int)((unsigned)(x0 >> 70) - 0xffffffffu)) | 1u));
                    q0 = &garr[((unsigned)((unsigned)f0 || garr[i1 & 7u]) & u3) & 7u];
                    m0 ^= u1;
                } else {
                    if (u3 == 7u) return (unsigned)(garr[i1 & 7u] || 2u);
                    l0 = (long)((unsigned long)l0 + (0xcc9d7505u + (unsigned)((short)g0 > (signed char)0x80000000u)));
                    do { if (--fuel == 0u) goto done;
                        while (i2++ < 6u && ((unsigned)x0 | (unsigned)((unsigned)c1 && (unsigned)h1))) { if (--fuel == 0u) goto done;
                            if (((garr[u2 & 7u] << (0x3d2c35c2u & 31u)) | u3)) break;
                            if ((unsigned)(0x10000u || (0x46454915u >> (p1 & 31u)))) break;
                            b0 = ((u2 << ((unsigned)c1 & 31u)) - -(unsigned)(garr[i1 & 7u] && (i1 - g1))) != 0u;
                            x0 = x0 * 0x100000001b3ull + ((unsigned)(r0.x && (unsigned)(i1 < i1)) / (0xacac9ddbu | 1u));
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn0(0x8175532au, (unsigned)b0, (unsigned)e0); }
                        if (1u) break;
                        m0 ^= (unsigned)h0;
                        e0 = e0 * 0.5L + (long double)((r0.x ^ 0xffffffffu) & 1023u);
                        for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                            u3 += (((unsigned)s1 % (u3 | 1u)) ^ ~(((unsigned)d0 << ((unsigned)(w0 >> 29) & 31u)) + 5u));
                            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)x0, p0, (unsigned)!((m0 - (unsigned)e0) & (unsigned)s0)); }
                            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(signed char)((unsigned)w0 + 0xeff478c4u), (u1 + (unsigned)((int)p1 < (int)(unsigned)c1)), (unsigned)((int)(unsigned)s1 < (int)(unsigned)((int)p0 < (int)fuel))); }
                            w0 ^= (unsigned long long)(unsigned)(0x556e1089u == i1) << ((a0[i0 & 3u] & (u1 * (unsigned)f0)) & 63u);
                            break; (void)((i2 << ((unsigned)s0 & 31u)));
                            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)(unsigned)((short)garr[u2 & 7u] > (signed char)7u) > (signed char)u2), 0xffffffffu, (unsigned)s1); }
                        }
                    } while (i1++ < 3u && (garr[u2 & 7u] - (unsigned)c0));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((g0 - (0xffffffffu - r0.y)), fuel, ((*q0 - a0[u1 & 3u]) % (7u | 1u))); }
                }
                { unsigned t11; double z11; if (((unsigned)(v0 == r0.y)) & 1u) { t11 = (unsigned)(unsigned char)(0x363c60c4u / ((unsigned)d0 | 1u)); z11 = (double)(((unsigned)((int)(0xc9ca0482u | 0xe78745dbu) >= (int)0xa62a2c5fu)) & 255u); } if (((unsigned)(v0 == r0.y)) & 1u) { u3 += t11; d0 = d0 * 0.5 + z11; }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((0xd74b2126u | 0xac173ee1u), (0x27551cf7u | (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)l0)), (i2 * (unsigned)c1)); }
                    if ((unsigned)((short)(0x7fffffffu << (garr[u2 & 7u] & 31u)) > (signed char)(unsigned)w0)) break;
                    x0 = x0 * 0x100000001b3ull + (6u / (5u | 1u));
                    f0 = f0 * 0.5f + (float)(((0x9d0333e7u % ((unsigned)(a0[i0 & 3u] && garr[u2 & 7u]) | 1u)) ^ u2) & 255u);
                    c1 = (signed char)(unsigned)(((r0.y * 0x10000u) / (m0 | 1u)) == (unsigned)x0);
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)b0 || i0));
                }
            }
        } else {
            if ((unsigned)((unsigned)l0 || 0x80000000u)) goto L4;
            if ((a0[i0 & 3u] >> ((r0.x >> (r0.x & 31u)) & 31u))) {
                if ((unsigned)(6u || (unsigned)((short)*q0 > (signed char)i1))) goto L4;
                i0 = (p0 / (-(5u << (g1 & 31u)) | 1u)) & 15u;
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((((unsigned)w0 - (unsigned)c0) * fuel), (m0 << ((v0 + (unsigned)f0) & 31u)), ((2u / ((unsigned)h0 | 1u)) >> (p2 & 31u))); }
                }
                goto L3;
                r0.y ^= (unsigned)(u0 || 9u);
                i0 = (unsigned)((int)i1 < (int)(unsigned)((int)3u < (int)0x662f50f0u)) & 15u;
            }
            if ((unsigned)((short)(unsigned)e0 > (signed char)garr[i1 & 7u])) goto L4;
        }
        x0 = x0 * 0x100000001b3ull + u3;
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((g1 - (unsigned)(signed char)(garr[i1 & 7u] + (unsigned)c1)), (0x647194au - 0xab2ec23eu), (g1 % ((unsigned)c0 | 1u))); }
                break; (void)(u1);
                u3 ^= (unsigned)((short)(unsigned)b0 > (signed char)(unsigned)((unsigned)s0 || (unsigned)((unsigned)c1 < i2)));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)s1, v0, g1); }
                continue; (void)((unsigned)x0);
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((0x10000u % (*q0 | 1u))) goto L4;
                }
            }
            f0 = f0 * 0.5f + (float)((unsigned)(short)(unsigned)((int)((p1 + (unsigned)d0) << (i0 & 31u)) >= (int)(4u % ((unsigned)(w0 >> 29) | 1u))) & 255u);
        }
    } else {
        switch (~((unsigned)w0 << ((unsigned)(short)(unsigned)(0u == (unsigned)s1) & 31u)) & 7u) {
            g0 = (((p0 | 5u) * (unsigned)(unsigned char)(unsigned)((unsigned)c0 == p2)) * 0x9d254f56u);
            if (-(unsigned)((unsigned)l0 && (unsigned)d0)) {
                m0 ^= 0x9edd2d87u;
                if ((unsigned)(unsigned char)(unsigned)((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)f0) && 3u)) goto L3;
                if (budget != 0u) { budget -= 1u; u3 = fn0((m0 / (6u | 1u)), u2, (unsigned)((unsigned)s1 && (unsigned)b0)); }
                switch ((r0.x * v0) & 7u) {
                    q0 = &garr[((unsigned)(-((unsigned)(x0 >> 70) << (g1 & 31u)) || 0xffffffffu) - m0) & 7u];
                }
            } else {
                case 5u: ;
                c1 = (signed char)(unsigned)((int)*mp >= (int)fuel);
                u2 = ((unsigned)(x0 >> 70) << ((unsigned)((unsigned)(w0 >> 29) || garr[i1 & 7u]) & 31u));
            }
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                g1 += (unsigned)((unsigned)((int)0x80000000u >= (int)(unsigned)((int)(a0[i0 & 3u] >> (g1 & 31u)) < (int)(unsigned)x0)) && (unsigned)(x0 >> 70));
                do { if (--fuel == 0u) goto done;
                    case 6u: ;
                    u1 = u1 * 0x9e3779b1u + (unsigned)c1;
                    garr[(unsigned)w0 & 7u] = ((unsigned)(*mp == (unsigned)((short)2u > (signed char)r0.y)) + (unsigned)(i2 || 9u));
                    switch ((unsigned)((int)(unsigned)x0 < (int)0x10000u) & 7u) {
                        c0 = (unsigned char)(unsigned)((int)*q0 >= (int)p1);
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)c0 < ((unsigned)l0 >> (m0 & 31u))), (unsigned)((int)(0x60466407u * fuel) < (int)(unsigned)c1), (a0[i0 & 3u] & r0.x)); }
                        u1 ^= ((unsigned)h0 & u0);
                    }
                } while (i1++ < 4u && (0x6d625a0bu - 0xc47189c8u));
                if ((0x10000u | (unsigned)c1)) {
                    l0 = (long)((unsigned long)l0 + ((unsigned)(unsigned char)(unsigned)((int)4u >= (int)(0x7fffffffu % (a0[i0 & 3u] | 1u))) + (unsigned)(u0 && (unsigned)h0)));
                    goto L4;
                    w0 ^= (unsigned long long)3u << (((unsigned)d0 >> ((unsigned)((unsigned)((int)i1 >= (int)((unsigned)w0 | i2)) == i0) & 31u)) & 63u);
                    s1 = (int)((unsigned)s1 + ((unsigned)c0 % ((unsigned)((int)g0 >= (int)(unsigned)w0) | 1u)));
                    d0 = d0 * 0.5 + (double)((unsigned)(a0[u1 & 3u] == 0xffffffffu) & 1023u);
                    c1 = (signed char)0x327aeb1cu;
                } else {
                    h0 = (short)(unsigned)((unsigned)l0 == (a0[u1 & 3u] ? (unsigned)s1 : (unsigned)((int)*q0 < (int)u3)));
                    u3 += (unsigned)(-(unsigned)(r0.x && ~(0u | u2)) || (p0 >> (0x651baf96u & 31u)));
                    r0.x = (unsigned)(a0[i0 & 3u] && (unsigned)w0);
                }
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = (unsigned)((int)(r0.y / (((unsigned)b0 << ((unsigned)d0 & 31u)) | 1u)) < (int)(unsigned)(w0 >> 29));
                    i0 = (unsigned)((unsigned)c1 && (unsigned)w0) & 15u;
                    d0 = d0 * 0.5 + (double)(0xffffffffu & 1023u);
                    for (;;) { if (--fuel == 0u) goto done;
                        r0.y ^= (unsigned)((short)(unsigned)((int)*mp < (int)1u) > (signed char)(unsigned)x0);
                        c1 = (signed char)((unsigned)(i2 || u0) & ((unsigned)h0 / (0x17bcee15u | 1u)));
                        e0 = e0 * 0.5L + (long double)((((unsigned)((int)0x80000000u >= (int)0x7fffffffu) / (u1 | 1u)) & (r0.y | 5u)) & 1023u);
                    }
                }
                if (u3 == 7u) return (((unsigned)((int)3u < (int)garr[u2 & 7u]) / ((unsigned)s1 | 1u)) & 2u);
            }
            goto L4;
            w0 ^= (unsigned long long)(p2 & 5u) << ((u3 / ((p1 + (0x217710a9u ? p2 : *mp)) | 1u)) & 63u);
            case 4u: ;
        }
        if (((unsigned)(x0 >> 70) * (unsigned)(g1 < *q0))) goto L4;
        b0 = 0xffffffffu != 0u;
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(0x10000u || u2)) {
            switch ((0x80000000u & (unsigned)!(0xabf26a16u << (7u & 31u))) & 7u) {
                u2 ^= (((unsigned)(0x58c1803eu == (unsigned)c0) & (unsigned)x0) ^ 1u);
                s1 = (int)((unsigned)s1 + (unsigned)((a0[i0 & 3u] ^ (unsigned)(w0 >> 29)) && ((unsigned)s0 * 5u)));
            }
            f0 = f0 * 0.5f + (float)((unsigned)((short)r0.x > (signed char)(0xefd6a8dbu >> ((unsigned)c0 & 31u))) & 255u);
            h1 = (unsigned short)(h1 + i1);
        }
        garr[(unsigned)(x0 >> 70) & 7u] = ((unsigned)d0 - *q0);
    } while (i0++ < 5u && (unsigned)(short)((unsigned)c1 & 5u));
    if ((unsigned)(unsigned char)((unsigned)c1 + (r0.x - (unsigned)s0))) {
        if (budget != 0u) { budget -= 1u; u1 = fn0(a0[u1 & 3u], ((unsigned)(x0 >> 70) ? (unsigned)c1 : 0x7fffffffu), u3); }
        if (0x10000u) goto L1;
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (g1) goto L4;
        }
        switch ((i2 << (8u & 31u)) & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)m0 >= (int)2u), (unsigned)(unsigned char)((unsigned)w0 % ((unsigned)s1 | 1u)), (unsigned)!(unsigned)((int)0x7fffffffu >= (int)p0)); }
            c0 = (unsigned char)((unsigned)((short)(unsigned)h1 > (signed char)(unsigned)d0) * (unsigned)((int)i0 >= (int)g0));
            if (((1u + 0xe28609b2u) / (garr[u2 & 7u] | 1u))) goto L1;
            l0 = (long)((unsigned long)l0 + r0.y);
            d0 = d0 * 0.5 + (double)(((unsigned)c0 * (unsigned)!((u1 - 0x80000000u) >> ((unsigned)(u1 && a0[u1 & 3u]) & 31u))) & 1023u);
            h1 = (unsigned short)(h1 + (unsigned)((int)(*q0 << ((unsigned)(0xffffffffu && m0) & 31u)) < (int)6u));
        }
        *mp = a0[u1 & 3u];
    } else {
        { unsigned t12; double z12; if (((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)w0)) & 1u) { t12 = (unsigned)((int)(unsigned)s1 < (int)(unsigned)x0); z12 = (double)(((unsigned)(g1 == p1)) & 255u); } if (((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)w0)) & 1u) { u0 += t12; d0 = d0 * 0.5 + z12; }
            b0 = (unsigned)((unsigned)((unsigned)h0 && 0x10000u) == (unsigned)c1) != 0u;
            f0 = f0 * 0.5f + (float)((unsigned)((int)(0x898a928u ? 4u : (p2 / (garr[i1 & 7u] | 1u))) >= (int)(unsigned)d0) & 255u);
            *mp = (unsigned)!(0u ? (unsigned)((short)a0[u1 & 3u] > (signed char)1u) : (unsigned)s1);
            u1 = a0[i0 & 3u];
            if ((unsigned)(u2 == 0x10000u)) goto L3;
        }
        goto L4;
    }
    if ((unsigned)c1) goto L1;
    w0 = w0 * 6364136223846793005ull + ((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)(w0 >> 29)) + (unsigned)((short)(u2 + 0x80000000u) > (signed char)6u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    w0 ^= (unsigned long long)v0 << ((unsigned)((unsigned)h1 == 0x74b736d5u) & 63u);
    if (((unsigned)(i0 < garr[u2 & 7u]) - i2)) goto L1;
    if (((0u - 0x8d2c638bu) | p2)) {
        L0: if (--fuel == 0u) goto done;
        *q0 += 0x7fffffffu;
    }
    { unsigned t0; double z0; if (((garr[u2 & 7u] << (i2 & 31u))) & 1u) { t0 = -(unsigned)((short)(unsigned)(*q0 < g0) > (signed char)i2); z0 = (double)((((garr[u2 & 7u] * 0x88531483u) >> ((unsigned)x0 & 31u))) & 255u); } if (((garr[u2 & 7u] << (i2 & 31u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        q0 = &garr[(unsigned)((int)p0 >= (int)(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)w0)) & 7u];
        g1 += ((unsigned)((int)(unsigned)f0 >= (int)(unsigned)c1) % ((unsigned)h1 | 1u));
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(((unsigned)e0 | 0x7fffffffu) && u3), i0, (unsigned)h1); }
        { unsigned t1; double z1; if ((((unsigned)l0 % (u1 | 1u))) & 1u) { t1 = ~(unsigned)((unsigned)c1 < 0x17402a26u); z1 = (double)(((unsigned)((0xe3affcafu >> ((unsigned)s1 & 31u)) < p1)) & 255u); } if ((((unsigned)l0 % (u1 | 1u))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            c1 = (signed char)1u;
            if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)s1 * (unsigned)((int)0x7fffffffu >= (int)(unsigned)w0)), (u1 ? u1 : 4u), (unsigned)((0xdf7167f9u + garr[u2 & 7u]) < (unsigned)(x0 >> 70))); }
        }
        s1 = (int)((unsigned)s1 + (unsigned)((short)i0 > (signed char)((unsigned)d0 * (unsigned)w0)));
    }
    if (((unsigned)(u3 == 0x72547336u) % (u1 | 1u))) goto L4;
    *mp = (*q0 >> (9u & 31u));
    *mp = ((unsigned)((int)(unsigned)l0 < (int)0x80000000u) >> ((1u / (0x10000u | 1u)) & 31u));
    l0 = (long)((unsigned long)l0 + (0x80000000u / (m0 | 1u)));
    if (~(a0[i0 & 3u] - p2)) goto L4;
    w0 ^= (unsigned long long)i2 << (r0.y & 63u);
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(0xe7c4f13fu || (0xffffffffu << ((unsigned)s1 & 31u))), 0xffffffffu, ~(0xc9cb3d0au << ((m0 | u1) & 31u))); }
    if (budget != 0u) { budget -= 1u; u2 = fn1((0x80000000u * (unsigned)(unsigned char)(unsigned)(0x201483e5u < p0)), (unsigned)((int)(unsigned)s1 < (int)(unsigned)c1), (unsigned)(x0 >> 70)); }
    switch (p1 & 7u) {
        *q0 = (0x4ac132fdu * (u3 % ((unsigned)h0 | 1u)));
        { unsigned t2; double z2; if (((unsigned)(p2 < v0)) & 1u) { t2 = (garr[i1 & 7u] / (r0.x | 1u)); z2 = (double)((((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0xe45c529eu) * (unsigned)h1)) & 255u); } if (((unsigned)(p2 < v0)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            g1 += (unsigned)((int)0xa69d610cu >= (int)(unsigned)((0xed312db4u | (5u >> ((unsigned)l0 & 31u))) || (unsigned)h1));
            do { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)(signed char)((unsigned)f0 ^ ((unsigned)(unsigned char)(u1 - 0xc2501b5fu) * (unsigned)l0)) & 1023u);
                switch (i0 & 7u) {
                    g0 = (unsigned)((unsigned)((unsigned)(u3 < u0) && (unsigned)h1) && (unsigned)(x0 >> 70));
                    c0 = (unsigned char)((unsigned)((short)a0[u1 & 3u] > (signed char)i1) << (-(garr[i1 & 7u] + u1) & 31u));
                    *q0 += (unsigned)(g0 < (unsigned)((unsigned)d0 || p1));
                }
            } while (i0++ < 6u && (i0 * v0));
        }
        g1 += ((p1 >> (g1 & 31u)) & (3u - 0x24421895u));
        if (0x80000000u) {
            u2 ^= (6u % ((unsigned)(a0[u1 & 3u] && a0[i0 & 3u]) | 1u));
        } else {
            if ((unsigned)((short)fuel > (signed char)(unsigned)(short)(i0 % (p1 | 1u)))) goto L3;
            *q0 += p2;
        }
    }
    if (u3) goto L0;
    goto L2;
    if (budget != 0u) { budget -= 1u; u3 = fn0(-(unsigned)(u0 && m0), ((0x27cffc99u + (unsigned)(w0 >> 29)) / ((unsigned)c0 | 1u)), garr[i1 & 7u]); }
    L1: if (--fuel == 0u) goto done;
    *q0 = ((8u >> (p0 & 31u)) & (unsigned)((int)(unsigned)s1 < (int)p0));
    switch ((unsigned)(0x7fffffffu || g0) & 7u) {
        while (i0++ < 6u && p2) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                s0 = (int)0xffffffffu;
                if ((0x7fffffffu * (unsigned)(u1 == garr[i1 & 7u]))) break;
            } while (i1++ < 3u && 8u);
            { unsigned t3; double z3; if (((unsigned)((short)(unsigned)!(unsigned)((int)m0 < (int)0x9a801c63u) > (signed char)(unsigned)(x0 >> 70))) & 1u) { t3 = ((g0 % (7u | 1u)) - 0x7fffffffu); z3 = (double)(((unsigned)h1) & 255u); } if (((unsigned)((short)(unsigned)!(unsigned)((int)m0 < (int)0x9a801c63u) > (signed char)(unsigned)(x0 >> 70))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                if ((u1 & (p1 | 0xd7921853u))) {
                    garr[8u & 7u] = (0xffffffffu % ((unsigned)s0 | 1u));
                }
            }
            continue; (void)(0u);
        }
        case 0u: ;
        h0 = (short)~(u0 * 7u);
        case 3u: ;
        l0 = (long)((unsigned long)l0 + ((unsigned)(x0 >> 70) / ((unsigned)(unsigned char)(unsigned)((short)(fuel - *mp) > (signed char)(unsigned)((int)0x19c75b10u >= (int)garr[u2 & 7u])) | 1u)));
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1((r0.y << (5u & 31u)), 9u, u3); }
    if (budget != 0u) { budget -= 1u; u2 = fn1(p2, (unsigned)((int)p0 < (int)(unsigned)(x0 >> 70)), 0x28582f3u); }
L2: if (--fuel == 0u) goto done;
L3: if (--fuel == 0u) goto done;
L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    c1 = (signed char)(unsigned)((short)(unsigned)(((unsigned)b0 % (p2 | 1u)) < (unsigned)h0) > (signed char)8u);
    if ((unsigned)((unsigned)(a0[i0 & 3u] || u1) < (unsigned)e0)) goto L2;
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(0x71ce6267u < 0xe4e1a0c1u), (unsigned)l0, (unsigned)e0); }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)c1, 0xffffffffu, ((u3 << (p1 & 31u)) ^ garr[i1 & 7u])); }
    if ((unsigned)((8u - garr[i1 & 7u]) == (unsigned)c0)) goto L2;
    m0 ^= (unsigned)((((i0 * m0) >> (p0 & 31u)) ^ (unsigned)l0) < 0xffffffffu);
    switch ((0x955eef84u + ~((unsigned)h0 & *q0)) & 7u) {
        q0 = &garr[g0 & 7u];
        switch (m0 & 7u) {
            if (budget != 0u) { budget -= 1u; u2 = fn1(~((unsigned)s1 >> ((unsigned)b0 & 31u)), -(unsigned)((unsigned)d0 || i0), -(i0 >> ((unsigned)((short)a0[i0 & 3u] > (signed char)*q0) & 31u))); }
            case 7u: ;
            if ((a0[i0 & 3u] - (unsigned)x0)) goto L2;
            a0[r0.x & 3u] = (unsigned)s1;
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)e0), m0, (0x10000u & ~((unsigned)(w0 >> 29) * a0[u1 & 3u]))); }
    f0 = f0 * 0.5f + (float)((unsigned)s0 & 255u);
    *mp = ((unsigned)x0 * (unsigned)x0);
    do { if (--fuel == 0u) goto done;
        *q0 = (unsigned)((unsigned)e0 < (unsigned)((unsigned)x0 == (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)s1)));
        s0 = (int)-(unsigned)((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)((short)m0 > (signed char)9u)) == (unsigned)!(unsigned)(2u < 0xffffffffu));
        h0 = (short)g0;
        L0: if (--fuel == 0u) goto done;
    } while (i0++ < 7u && (unsigned)((short)(garr[u2 & 7u] - (unsigned)x0) > (signed char)(unsigned)c0));
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(r0.y < (unsigned)c1), p2, (u3 + ((unsigned)w0 * 3u))); }
    *q0 = (unsigned)((u3 / ((unsigned)h1 | 1u)) && 0xa3f6d237u);
    if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)w0 - (unsigned)!(unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)w0)), u2, (unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)e0)); }
    goto L0;
    goto L3;
    goto L3;
    *mp = ~((unsigned)c0 + (a0[u1 & 3u] % (i0 | 1u)));
    L1: if (--fuel == 0u) goto done;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)(a0[u1 & 3u] - 0x89d5743au) << ((u1 / (((unsigned)(w0 >> 29) | g0) | 1u)) & 63u);
        for (;;) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)(u0 < (unsigned)(signed char)((unsigned)f0 << (0x80000000u & 31u)));
            u2 = u2 * 0x9e3779b1u + (unsigned)((short)(unsigned)((int)m0 < (int)a0[u1 & 3u]) > (signed char)(unsigned)((int)0x80000000u >= (int)0x5eb3a728u));
            m0 ^= (unsigned)((unsigned)s1 || (unsigned)((int)0x10000u < (int)u2));
            if ((5u << ((garr[i1 & 7u] << (u3 & 31u)) & 31u))) break;
        }
        goto L1;
        if (((unsigned)c1 + i1)) goto L1;
        if ((garr[i1 & 7u] << (r0.x & 31u))) break;
        if ((unsigned)(p0 == (unsigned)(w0 >> 29))) break;
    }
    while (-(i1 / ((unsigned)b0 | 1u))) { if (--fuel == 0u) goto done;
        if ((unsigned)(p1 || (unsigned)((int)1u < (int)v0))) goto L2;
        L2: if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)(unsigned char)(((unsigned)((int)u1 < (int)(unsigned)b0) * 2u) >> ((unsigned)c1 & 31u));
    }
    goto L2;
    g1 += ((unsigned)(4u < (unsigned)c0) << (((unsigned)h0 >> ((unsigned)x0 & 31u)) & 31u));
    u1 = (unsigned)(i0 == (unsigned)((short)r0.x > (signed char)4u));
L3: if (--fuel == 0u) goto done;
L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if (((unsigned)!((unsigned)s1 % (r0.y | 1u))) & 1u) { t0 = (0xfb0efd94u << ((0xeaf9c965u >> (garr[u2 & 7u] & 31u)) & 31u)); z0 = (double)(((unsigned)(0x84119759u && 0xa5db03bau)) & 255u); } if (((unsigned)!((unsigned)s1 % (r0.y | 1u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        h0 = (short)(p1 ^ (u2 + (unsigned)x0));
        if (5u) goto done;
        if ((unsigned)((int)g1 < (int)(unsigned)(signed char)(unsigned)(p1 && 0xffffffffu))) {
            if ((unsigned)((0x48685fe0u + p0) == u3)) goto L4;
            u3 = u3 * 0x9e3779b1u + ((unsigned)d0 * 4u);
            if ((unsigned)((int)(unsigned)!(unsigned)((int)(unsigned)h0 < (int)(unsigned)e0) >= (int)0xffffffffu)) goto L4;
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((0xffffffffu ? v0 : r0.x)) {
                    break; (void)((unsigned)(fuel || 0x80000000u));
                    r0.x = (*mp >> ((8u * r0.x) & 31u));
                    goto L3;
                    garr[(unsigned)w0 & 7u] = (garr[i1 & 7u] & 0x6c3b396du);
                    *q0 += (0x61524a8bu / ((a0[u1 & 3u] - (unsigned)w0) | 1u));
                    if (((unsigned)(x0 >> 70) + 0x9b1a1a23u)) {
                        if (u3 == 7u) return (r0.x & 0xffffffffu);
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(w0 >> 29), ((unsigned)s0 & (unsigned)(w0 >> 29)), r0.y); }
                        w0 = w0 * 6364136223846793005ull + (unsigned)(short)((u1 / (0xffffffffu | 1u)) ? *mp : (unsigned)e0);
                        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                            r0.y ^= 0x11c7f09au;
                            w0 = w0 * 6364136223846793005ull + r0.y;
                            if (budget != 0u) { budget -= 1u; u3 = fn3(((4u - (unsigned)s1) * *mp), (p0 >> ((0x18e650a7u + (unsigned)l0) & 31u)), (0x846a6d6du - (unsigned)(r0.x && p0))); }
                            if ((unsigned)((int)p2 >= (int)0x23264c7u)) goto L1;
                        }
                    }
                } else {
                    { unsigned t1; double z1; if (((unsigned)c0) & 1u) { t1 = (v0 * 0x7fffffffu); z1 = (double)(((a0[i0 & 3u] | (p0 >> (g1 & 31u)))) & 255u); } if (((unsigned)c0) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                        if ((u3 / ((garr[u2 & 7u] << (fuel & 31u)) | 1u))) break;
                        if (((unsigned)!(*q0 - 0x80000000u) & garr[i1 & 7u])) break;
                        *q0 = (unsigned)(1u && 3u);
                        g0 = (garr[u2 & 7u] & (unsigned)(short)(unsigned)((short)0x7fffffffu > (signed char)0x10000u));
                        if (budget != 0u) { budget -= 1u; u0 = fn3((5u << (0x9da981b2u & 31u)), (7u % (m0 | 1u)), (unsigned)(signed char)(unsigned)((unsigned)b0 == (unsigned)e0)); }
                        while (i1++ < 6u && (unsigned)(short)(unsigned)((int)0x10000u >= (int)((unsigned)e0 + (unsigned)s1))) { if (--fuel == 0u) goto done;
                            break; (void)((0x10000u ^ (unsigned)s1));
                            i2 = u0 & 15u;
                        }
                    }
                    u0 ^= ((0x80000000u ? i0 : a0[u1 & 3u]) - g0);
                    if (((unsigned)e0 ? 0x1fa15246u : 0xbb7bdc6bu)) break;
                    u0 = ~(unsigned)((short)i0 > (signed char)(unsigned)((unsigned)((short)i0 > (signed char)0x80000000u) && a0[i0 & 3u]));
                }
            }
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (0x7a2ba534u) break;
            }
        }
        h0 = (short)(unsigned)((short)(unsigned)(9u < (unsigned)c0) > (signed char)(0x10000u & *q0));
    }
    h0 = (short)0x2440c4e4u;
    h1 = (unsigned short)(h1 + 7u);
    s0 = (int)(*mp + 0xe08c5e59u);
    { unsigned t2; double z2; if ((0xa0a5963eu) & 1u) { t2 = 0x390b67a0u; z2 = (double)(((unsigned)(unsigned char)(unsigned)((short)m0 > (signed char)8u)) & 255u); } if ((0xa0a5963eu) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        if ((unsigned)(0x10000u < r0.x)) goto L3;
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            g1 += (fuel % (((unsigned)((short)(unsigned)w0 > (signed char)(unsigned)c1) | 1u) | 1u));
            goto L4;
            if ((unsigned)(0x80000000u && (p0 | (unsigned)w0))) goto L1;
            do { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (unsigned)h0;
                break; (void)(~((3u ^ fuel) ^ r0.y));
                { unsigned t3; double z3; if (((0x10000u | 0xfdd463b6u)) & 1u) { t3 = p1; z3 = (double)((g1) & 255u); } if (((0x10000u | 0xfdd463b6u)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                    garr[*mp & 7u] = (unsigned)((int)((unsigned)b0 & 0x7fffffffu) < (int)(0xffffffffu % (-(i2 >> (0x7fffffffu & 31u)) | 1u)));
                    while (i2++ < 3u && 0x80000000u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)9u < (int)(unsigned)l0)) continue;
                        if (((unsigned)s0 - (unsigned)w0)) continue;
                        L0: if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)(((unsigned)((unsigned)w0 || (unsigned)s1) & ~(0x10000u - ((unsigned)l0 % ((unsigned)d0 | 1u)))) & 1023u);
                        if (((u3 / (u1 | 1u)) % (a0[u1 & 3u] | 1u))) {
                            v0 = -(i0 - ((unsigned)((int)(garr[i1 & 7u] & (unsigned)f0) >= (int)0x7fffffffu) << (0xcd0a04fau & 31u)));
                            if (fuel) goto L4;
                            s0 = (int)((unsigned)((unsigned)(v0 || u1) && 7u) << ((unsigned)(0u == r0.x) & 31u));
                        } else {
                            v0 = ((unsigned)f0 * 0x342d3e6eu);
                        }
                        if ((unsigned)(short)(6u ^ i2)) break;
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)((int)*mp < (int)0x548e2446u) << ((unsigned)s1 & 31u)), (unsigned)((unsigned)x0 < (0x4d7614d8u - (unsigned)(x0 >> 70))), (p2 ^ ((unsigned)(x0 >> 70) | 0x10000u))); }
                }
                do { if (--fuel == 0u) goto done;
                    if (p0) goto L4;
                } while (i2++ < 4u && (0x3852a60eu << ((unsigned)!(unsigned)((int)7u < (int)garr[i1 & 7u]) & 31u)));
                if (budget != 0u) { budget -= 1u; u0 = fn0((i0 * (unsigned)e0), u3, 0xf7b38d55u); }
            } while (i1++ < 3u && (*q0 * fuel));
            if (budget != 0u) { budget -= 1u; u1 = fn1((*q0 ? (unsigned)s0 : 0u), (unsigned)h1, p0); }
        }
        if ((unsigned)(0x8b58126eu == p1)) goto L4;
        while (i0++ < 7u && -(unsigned)((unsigned)h0 || (unsigned)c1)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((0u * (unsigned)(0x668f7d2eu < u2)), ((unsigned)e0 | 8u), ~(0xf61e30f2u + (unsigned)(0xd2cf6934u && g0))); }
            e0 = e0 * 0.5L + (long double)(((unsigned)!(g1 ? (unsigned)s0 : 0x391e4c6du) - p2) & 1023u);
            r0.x = 6u;
            L1: if (--fuel == 0u) goto done;
        }
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(*q0 == (unsigned)b0)) {
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)((int)p2 < (int)r0.x));
                if ((unsigned)(unsigned char)(g0 & 0xffffffffu)) {
                    for (;;) { if (--fuel == 0u) goto done;
                        if (0x7fffffffu) continue;
                        i2 = (unsigned)((int)p0 >= (int)(unsigned)(((unsigned)(x0 >> 70) >> (i0 & 31u)) == (unsigned)!(unsigned)(0x252cfae9u < 0x2ed15be0u))) & 15u;
                        b0 = (unsigned)c1 != 0u;
                    }
                    if (*mp) break;
                }
                break; (void)(fuel);
                u0 = u0 * 0x9e3779b1u + ((unsigned)((int)(unsigned)((short)0x26a6651eu > (signed char)0x198f7a9fu) >= (int)(unsigned)s0) ^ (0x80000000u / (v0 | 1u)));
                u1 ^= (a0[u1 & 3u] - p2);
                do { if (--fuel == 0u) goto done;
                    g0 = (-(unsigned)((int)(unsigned)d0 >= (int)8u) >> ((unsigned)(g0 || u1) & 31u));
                    if ((unsigned)(unsigned char)(unsigned)(0x55d8c82au || r0.x)) continue;
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        g1 += (unsigned)((unsigned)!((unsigned)(i1 && (unsigned)(x0 >> 70)) / (7u | 1u)) || a0[i0 & 3u]);
                        if (budget != 0u) { budget -= 1u; u3 = fn2((u3 ^ (0xdd021069u >> (garr[u2 & 7u] & 31u))), g1, (unsigned)(0x7fffffffu < ((unsigned)l0 + fuel))); }
                    }
                    if ((unsigned)((unsigned)((int)i1 < (int)r0.x) || 0x8be7ed86u)) {
                        while (i0++ < 4u && (unsigned)((int)(m0 + p0) >= (int)(unsigned)h1)) { if (--fuel == 0u) goto done;
                            if ((4u >> (a0[u1 & 3u] & 31u))) break;
                            s0 = (int)0x10000u;
                            if (budget != 0u) { budget -= 1u; u3 = fn2((garr[i1 & 7u] ^ (unsigned)c1), (unsigned)((0x2cb9bd9bu % ((unsigned)b0 | 1u)) || garr[i1 & 7u]), u3); }
                            *mp = (unsigned)((int)fuel >= (int)garr[u2 & 7u]);
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn2(u2, (unsigned)(w0 >> 29), (unsigned)(0x97c2bb31u && (unsigned)(g1 && (unsigned)e0))); }
                        if (((unsigned)(0x7fffffffu == g0) * 0xffffffffu)) break;
                    }
                } while (i2++ < 7u && ((unsigned)((unsigned)s0 == (unsigned)c0) * i0));
            }
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)x0 << (fuel & 31u))) break;
                f0 = f0 * 0.5f + (float)(((unsigned)(unsigned char)((unsigned)e0 * 0xa10447c1u) ? ((unsigned)b0 % (6u | 1u)) : (unsigned)f0) & 255u);
                f0 = f0 * 0.5f + (float)(u1 & 255u);
            }
            q0 = &garr[(i2 & (unsigned)w0) & 7u];
            *q0 += u0;
            if (budget != 0u) { budget -= 1u; u3 = fn2((garr[u2 & 7u] + a0[u1 & 3u]), ((0xc4a5f18u & i1) % (i1 | 1u)), *mp); }
            goto done;
        } else {
            while ((unsigned)(p0 && a0[u1 & 3u])) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    switch ((unsigned)((int)r0.x >= (int)(unsigned)f0) & 7u) {
                        L2: if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn2(((garr[u2 & 7u] << (v0 & 31u)) * *mp), garr[u2 & 7u], (unsigned)(r0.y && i1)); }
                        g1 += 0x70e20c42u;
                        r0.y ^= (fuel & (unsigned)h1);
                    }
                    if (a0[i0 & 3u]) {
                        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(signed char)((unsigned)(w0 >> 29) - (unsigned)(8u == p2)), ((garr[u2 & 7u] << (0x89a0cfddu & 31u)) & p0), 0xffffffffu); }
                        g1 += (unsigned)(short)(unsigned)((int)0x1ba02e14u >= (int)((unsigned)s0 & (((unsigned)h1 & (unsigned)x0) >> (g1 & 31u))));
                        do { if (--fuel == 0u) goto done;
                            u0 = u0 * 0x9e3779b1u + (0x80000000u * (*mp << (g1 & 31u)));
                            f0 = f0 * 0.5f + (float)(((unsigned)l0 << ((unsigned)c1 & 31u)) & 255u);
                            m0 ^= ((0x7fffffffu / (0x6a1041d8u | 1u)) % ((u2 + 0x8683af3cu) | 1u));
                            c1 = (signed char)(unsigned)(x0 >> 70);
                            c0 = (unsigned char)((0xffffffffu >> ((unsigned)f0 & 31u)) & (i1 ? 0x55ea3abdu : i2));
                            L3: if (--fuel == 0u) goto done;
                        } while (i0++ < 6u && (unsigned)((int)(unsigned)((short)0x94e827f9u > (signed char)(unsigned)w0) < (int)(unsigned)c1));
                        if (budget != 0u) { budget -= 1u; u3 = fn3(0x7fffffffu, ((unsigned)((int)u2 < (int)(unsigned)h1) * r0.x), ~(unsigned)((int)m0 >= (int)9u)); }
                    }
                }
                L4: if (--fuel == 0u) goto done;
                b0 = (unsigned)d0 != 0u;
                continue; (void)(i2);
                while (-(garr[i1 & 7u] & 0x8d3e3cfbu)) { if (--fuel == 0u) goto done;
                    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        u1 = u1 * 0x9e3779b1u + (unsigned)(0xdd18bbcau && a0[i0 & 3u]);
                        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(0x9109329fu == u2) < 8u) & 1023u);
                        *q0 = ((unsigned)(short)(unsigned)(0x449abc3u && (unsigned)f0) / (0xb4680a36u | 1u));
                        m0 ^= (unsigned)((short)*q0 > (signed char)(~(u3 * 1u) & i2));
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)0xd1d3a9u >= (int)(0x38ee7b24u / ((unsigned)l0 | 1u))), *mp, (unsigned)(short)(a0[u1 & 3u] ? (unsigned)(x0 >> 70) : 0xedb4a676u)); }
                    a0[(unsigned)!(unsigned)((unsigned)(x0 >> 70) && i0) & 3u] = (unsigned)(7u || (6u ^ (m0 - 2u)));
                    c0 = (unsigned char)(unsigned)((unsigned)b0 || u0);
                }
            }
        }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((0x7fffffffu ^ -(unsigned)(g1 == (unsigned)w0))) break;
            while ((unsigned)((unsigned)h1 && (v0 - 0xfab42b7au))) { if (--fuel == 0u) goto done;
                i0 = (i0 + (unsigned)d0) & 15u;
                if (((unsigned)((int)r0.y < (int)0x4a15487bu) ^ 0u)) goto done;
            }
            i1 = (p2 % (garr[i1 & 7u] | 1u)) & 15u;
            h0 = (short)6u;
            b0 = i0 != 0u;
        }
        if ((unsigned)(6u && (unsigned)s0)) break;
    }
    s1 = (int)((unsigned)s1 + (unsigned)((5u + 1u) || g1));
    do { if (--fuel == 0u) goto done;
        if ((unsigned)s1) {
            if ((unsigned)((int)7u < (int)(0x2ed08fcau ^ 8u))) break;
            garr[u1 & 7u] = i1;
            do { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t4; double z4; if ((5u) & 1u) { t4 = ((unsigned)l0 ^ (unsigned)e0); z4 = (double)((0x7fffffffu) & 255u); } if ((5u) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                        if ((unsigned)(i0 < i0)) {
                            if (budget != 0u) { budget -= 1u; u0 = fn1((0xf4a20e6fu << ((unsigned)h1 & 31u)), ((unsigned)((unsigned)h1 || (unsigned)c0) ^ (unsigned)l0), (unsigned)s1); }
                            v0 = (unsigned)((i2 ? garr[u2 & 7u] : u0) == (unsigned)((int)(unsigned)w0 < (int)0xd8be3660u));
                            u1 += (unsigned)((unsigned)(unsigned char)(0xffffffffu & 0xffffffffu) == p0);
                            x0 = x0 * 0x100000001b3ull + ((unsigned)w0 ? r0.x : u3);
                        } else {
                            *q0 = (unsigned)!(unsigned)(((unsigned)((short)u1 > (signed char)p2) << (1u & 31u)) == (*mp % ((unsigned)s0 | 1u)));
                            if ((unsigned)(0x80000000u == 9u)) break;
                        }
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn2(0u, -(unsigned)((unsigned)w0 || (unsigned)((unsigned)s0 == *q0)), r0.y); }
                    u1 = ((unsigned)((int)(unsigned)((int)7u < (int)0x80000000u) < (int)i1) ^ (unsigned)(i1 < m0));
                }
                if (v0) break;
            } while (i1++ < 3u && (fuel >> (garr[i1 & 7u] & 31u)));
        }
        c0 = (unsigned char)(unsigned)((int)p2 < (int)(u3 ? (unsigned)b0 : (unsigned)b0));
    } while (i0++ < 6u && ((unsigned)c0 ? i0 : a0[i0 & 3u]));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        continue; (void)(~(unsigned)((unsigned)(0x7fffffffu == i0) || (unsigned)c0));
        u3 = u2;
    }
    if ((u0 + (unsigned)c0)) goto L1;
    if ((unsigned)s1) goto L3;
    if (*mp) goto L1;
    switch ((unsigned)((short)(unsigned)c1 > (signed char)r0.y) & 7u) {
        *q0 = ((unsigned)h0 - g1);
        if (budget != 0u) { budget -= 1u; u3 = fn3(a0[u1 & 3u], (unsigned)(0x960c19au < u1), (unsigned)(0xffffffffu && 0x7fffffffu)); }
    }
    switch (a0[u1 & 3u] & 7u) {
        while (i0++ < 7u && (unsigned)((int)(unsigned)h1 >= (int)(unsigned)s0)) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)((short)(unsigned)(signed char)(unsigned)(garr[i1 & 7u] == ((unsigned)s0 - 0xce4e28bu)) > (signed char)r0.y);
            if ((0x7fffffffu << (0xd1eaa564u & 31u))) {
                goto done;
                u2 = u2 * 0x9e3779b1u + (unsigned)((unsigned)((short)fuel > (signed char)(unsigned)x0) && (unsigned)l0);
                c1 = (signed char)(unsigned)(3u < (unsigned)((int)v0 >= (int)0x10000u));
                e0 = e0 * 0.5L + (long double)((0xffffffffu ? (u1 - r0.x) : 0x80000000u) & 1023u);
            }
            h1 = (unsigned short)(h1 + ((unsigned)b0 << ((0u ^ (unsigned)(p0 < (unsigned)c0)) & 31u)));
            while (i1++ < 6u && (unsigned)(0u < (unsigned)((int)0xffffffffu < (int)i0))) { if (--fuel == 0u) goto done;
                case 0u: ;
                if ((0xffffffffu << ((unsigned)(0xffffffffu == (unsigned)(w0 >> 29)) & 31u))) {
                    m0 ^= (unsigned)(m0 || ((unsigned)(x0 >> 70) & *mp));
                }
                if ((unsigned)c1) {
                    r0.x = ((unsigned)((unsigned)h0 == i2) >> ((unsigned)b0 & 31u));
                    v0 = (unsigned)(((unsigned)d0 << (((unsigned)s0 << (p2 & 31u)) & 31u)) && (unsigned)((int)r0.x < (int)(unsigned)h0));
                    i2 = *q0 & 15u;
                } else {
                    break; (void)(0xf58d128au);
                    goto L1;
                }
            }
        }
    }
    g0 = ((unsigned)((fuel / (r0.y | 1u)) < 3u) * (unsigned)((int)i2 < (int)g0));
    a0[(0xa3761092u - (unsigned)f0) & 3u] = 0x39b79ccu;
    v0 = ((unsigned)((int)(unsigned)((unsigned)(0x7fffffffu == 0x7fffffffu) && (unsigned)(x0 >> 70)) >= (int)0x1363a6du) % ((unsigned)e0 | 1u));
    do { if (--fuel == 0u) goto done;
        if (0x80000000u) {
            r0.y ^= (unsigned)((int)(unsigned)c1 >= (int)(unsigned)(unsigned char)((unsigned)!(unsigned)((int)(unsigned)w0 >= (int)*mp) >> (p1 & 31u)));
            i1 = (unsigned)h0 & 15u;
            v0 = u0;
            s1 = (int)((unsigned)s1 + i1);
            i1 = (unsigned)(signed char)(unsigned)(i2 || u1) & 15u;
            if ((unsigned)s1) break;
        } else {
            a0[(unsigned)(2u == i0) & 3u] = (unsigned)s0;
            if (budget != 0u) { budget -= 1u; u0 = fn1(0x80000000u, (unsigned)w0, (u1 / ((0x2f957759u << (u0 & 31u)) | 1u))); }
        }
        if ((unsigned)(w0 >> 29)) break;
        *q0 += -(unsigned)((int)(unsigned)(unsigned char)((unsigned)(0x29e0983bu || i1) << (p2 & 31u)) >= (int)(r0.x % (i0 | 1u)));
        if ((u0 >> ((garr[i1 & 7u] << (7u & 31u)) & 31u))) continue;
        do { if (--fuel == 0u) goto done;
            u3 += (p2 & (unsigned)h0);
            goto L3;
            switch (u2 & 7u) {
                if ((unsigned)(0x7fffffffu || r0.y)) goto L2;
                *mp = (unsigned)(unsigned char)(i0 * (unsigned)h1);
            }
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(r0.y & 255u);
                *q0 += (r0.x ? ~(unsigned)((unsigned)e0 && (p2 >> ((unsigned)s0 & 31u))) : p0);
            }
        } while (i1++ < 6u && (g0 - v0));
        if ((unsigned)(2u < (unsigned)e0)) break;
    } while (i0++ < 7u && ((unsigned)c0 & v0));
    if ((unsigned)f0) {
        if ((unsigned)((int)(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)c0) >= (int)*mp)) {
            if (budget != 0u) { budget -= 1u; u2 = fn3(v0, ((unsigned)s0 ^ (unsigned)((short)4u > (signed char)(unsigned)h0)), (unsigned)(unsigned char)((unsigned)((int)p0 < (int)fuel) / ((unsigned)l0 | 1u))); }
            if ((*q0 / (i2 | 1u))) {
                c1 = (signed char)(((unsigned)c0 ^ *q0) - u3);
            } else {
                c0 = (unsigned char)(unsigned)(unsigned char)(unsigned)((int)(g1 % (*q0 | 1u)) < (int)(2u % ((unsigned)e0 | 1u)));
                m0 ^= ((unsigned)d0 % ((unsigned)(0x52824a85u < (0xa0d52af4u % ((unsigned)c1 | 1u))) | 1u));
            }
            w0 ^= (unsigned long long)garr[u2 & 7u] << ((unsigned)!((unsigned)!(0xffffffffu >> ((unsigned)(u1 && (p1 | (unsigned)d0)) & 31u)) >> (2u & 31u)) & 63u);
            { unsigned t5; double z5; if (((unsigned)(0x8dcdcf74u || 0x80000000u)) & 1u) { t5 = (r0.y >> (0xe2443efu & 31u)); z5 = (double)(((unsigned)((int)r0.x >= (int)(a0[i0 & 3u] + (unsigned)l0))) & 255u); } if (((unsigned)(0x8dcdcf74u || 0x80000000u)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                if (0u) goto done;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn1((4u - (2u & 8u)), (unsigned)((unsigned)(garr[i1 & 7u] == (unsigned)b0) < p0), (unsigned)((short)u0 > (signed char)3u)); }
        }
        c0 = (unsigned char)(unsigned)!(unsigned)((unsigned)e0 || (p2 ^ (unsigned)(0u && 0x7fffffffu)));
    }
    u3 ^= ((unsigned)x0 & (unsigned)x0);
    if ((unsigned)(w0 >> 29)) goto L3;
    garr[0x7fffffffu & 7u] = garr[u2 & 7u];
    r0.x = garr[u2 & 7u];
    while ((unsigned)e0) { if (--fuel == 0u) goto done;
        if (1u) continue;
        if ((unsigned)(1u == (unsigned)((int)g1 >= (int)0xe919da4u))) {
            s0 = (int)((unsigned)((int)p2 < (int)(unsigned)s1) / ((((unsigned)(x0 >> 70) + garr[i1 & 7u]) << (0x80000000u & 31u)) | 1u));
            f0 = f0 * 0.5f + (float)((garr[i1 & 7u] % ((unsigned)(unsigned char)((i1 >> (garr[i1 & 7u] & 31u)) - p1) | 1u)) & 255u);
            m0 ^= (0x454e71c1u % ((g1 >> (0x580f72dbu & 31u)) | 1u));
            if (budget != 0u) { budget -= 1u; u1 = fn2((0x8be504b4u << (~(0x7932d97eu - 0xffffffffu) & 31u)), (0x36e5aa27u + (unsigned)((unsigned)c1 < 0x3850798fu)), (9u >> (0xffffffffu & 31u))); }
        }
    }
    x0 = x0 * 0x100000001b3ull + *q0;
    if ((unsigned)(short)(unsigned)((int)0x10d5c08du < (int)(unsigned)(signed char)(unsigned)(1u || 0x80000000u))) goto L1;
    switch ((unsigned)h0 & 7u) {
        break; (void)((unsigned)((unsigned)l0 || 0xffffffffu));
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 5u: ;
            { unsigned t6; double z6; if (((unsigned)((int)0x80000000u < (int)((unsigned)f0 - (unsigned)(x0 >> 70)))) & 1u) { t6 = p2; z6 = (double)(((unsigned)(u2 || (*mp >> (0x278c52f3u & 31u)))) & 255u); } if (((unsigned)((int)0x80000000u < (int)((unsigned)f0 - (unsigned)(x0 >> 70)))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                if (budget != 0u) { budget -= 1u; u3 = fn1(0x80000000u, g0, (unsigned)((short)(unsigned)(signed char)(unsigned)((int)(unsigned)(x0 >> 70) < (int)i0) > (signed char)0x10000u)); }
                u3 = 0x80000000u;
            }
            switch ((0xcc38dba8u * (unsigned)e0) & 7u) {
                break; (void)(((unsigned)((short)(unsigned)h1 > (signed char)0xffffffffu) + (unsigned)s1));
                case 4u: ;
                while (i1++ < 5u && (unsigned)((unsigned)(i1 < 0x176cd209u) || (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)((0xb6080944u | ((unsigned)(x0 >> 70) >> ((unsigned)(x0 >> 70) & 31u))) & 255u);
                    }
                    { unsigned t7; double z7; if ((((unsigned)(w0 >> 29) - 8u)) & 1u) { t7 = (unsigned)(p1 || garr[u2 & 7u]); z7 = (double)(((unsigned)(signed char)(unsigned)(a0[i0 & 3u] == 0xa7d9e759u)) & 255u); } if ((((unsigned)(w0 >> 29) - 8u)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)c1 >= (int)0x9172c62du), g1, ~(unsigned)(0x9e039b1cu && i1)); }
                    }
                    switch (p1 & 7u) {
                        s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)(6u && u2) > (signed char)0xb4ad5ecdu));
                        case 6u: ;
                    }
                    { unsigned t8; double z8; if (((unsigned)((short)*q0 > (signed char)fuel)) & 1u) { t8 = (unsigned)((int)(garr[u2 & 7u] * (unsigned)c1) >= (int)g0); z8 = (double)((((unsigned)b0 / ((unsigned)((unsigned)h1 < r0.x) | 1u))) & 255u); } if (((unsigned)((short)*q0 > (signed char)fuel)) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                        f0 = f0 * 0.5f + (float)(((unsigned)s1 - (unsigned)b0) & 255u);
                        { unsigned t9; double z9; if (((unsigned)(7u && (a0[i0 & 3u] & 0xffffffffu))) & 1u) { t9 = (fuel >> (garr[u2 & 7u] & 31u)); z9 = (double)(((unsigned)((unsigned)e0 == (r0.x + p2))) & 255u); } if (((unsigned)(7u && (a0[i0 & 3u] & 0xffffffffu))) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                            c0 = (unsigned char)((unsigned)c0 ? p0 : u2);
                        }
                    }
                    h1 = (unsigned short)(h1 + 0xe739c248u);
                }
            }
        }
        *q0 = (unsigned)((short)0xed7a0806u > (signed char)0x80000000u);
        case 0u: ;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 10u, 0xb41b6eb6u, 0xdb2cec23u },
        { 2u, 0xe5d98f25u, 0xc11dad15u },
        { 2u, 0xca625128u, 0xcca0ee4au },
        { 5u, 0xc0933b8eu, 0x23006854u },
        { 7u, 0x6d0358b3u, 0xc9dde4f1u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
