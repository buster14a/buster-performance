// test-ssa-source's program of seed 134000423 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xac638e3du, g1 = 0x436044f0u;
static unsigned garr[8] = { 0x950f3460u, 0xbad41feau, 0xa3023189u, 0x3aa21ae4u, 0x7e26484du, 0xcfdbaa47u, 0xc404cb93u, 0x15cff124u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)((int)(unsigned)(8u || 0x7fffffffu) < (int)v0) & 7u) {
            c1 = (signed char)(unsigned)(m0 == 0x10000u);
            case 0u: ;
        }
        switch ((unsigned)(g1 == (unsigned)c1) & 7u) {
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                u0 ^= -((unsigned)x0 & (unsigned)!(9u - *mp));
                L0: if (--fuel == 0u) goto done;
            }
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)h0) goto done;
                h1 = (unsigned short)(h1 + (i0 % ((unsigned)x0 | 1u)));
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    v0 = (0x10000u | ((unsigned)((short)(unsigned)b0 > (signed char)r0.y) & (unsigned)(x0 >> 70)));
                    if ((u0 / (0x434826e8u | 1u))) continue;
                }
                d0 = d0 * 0.5 + (double)(~(((unsigned)(w0 >> 29) * *mp) * ((unsigned)((unsigned)w0 && garr[u2 & 7u]) | v0)) & 1023u);
            }
            while (i1++ < 7u && 0xcd8bcbc2u) { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
            }
            L2: if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
        }
        if (p2) break;
        w0 ^= (unsigned long long)(unsigned)b0 << (((unsigned)!(unsigned)((unsigned)h1 && (unsigned)h0) + (unsigned)(u1 || (m0 ^ i0))) & 63u);
        e0 = e0 * 0.5L + (long double)((fuel | (unsigned)d0) & 1023u);
        if (u0) {
            break; (void)((unsigned)((int)(unsigned)(w0 >> 29) < (int)p1));
            g1 += (unsigned)h1;
            if ((u0 << (u1 & 31u))) continue;
            do { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (((unsigned)d0 >> ((unsigned)(short)(u2 >> (7u & 31u)) & 31u)) + p0);
                if ((0x603df96cu % (*q0 | 1u))) break;
                u3 ^= ((0xc1e02c0du - g1) + 0xe41c5857u);
                h1 = (unsigned short)(h1 + (p1 / ((unsigned)((unsigned)x0 == u0) | 1u)));
                while (i2++ < 3u && (unsigned)((short)(unsigned)(0x80000000u || 7u) > (signed char)fuel)) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)(a0[u1 & 3u] & 255u);
                    u2 ^= ((-(0x7dff4cf7u & 6u) >> (garr[i1 & 7u] & 31u)) & (unsigned)h0);
                    if ((u3 + (unsigned)h0)) {
                        h1 = (unsigned short)(h1 + (unsigned)((int)0x106a6b64u >= (int)0x10000u));
                        L4: if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + ((unsigned)(w0 >> 29) % (p2 | 1u));
                        v0 = ((unsigned)b0 << (*mp & 31u));
                    } else {
                        garr[(0x9ccfbb83u * u3) & 7u] = 0x74e3a4edu;
                    }
                    if ((p0 - i0)) break;
                }
                if ((p0 / (u0 | 1u))) {
                    if ((unsigned)((int)(unsigned)c0 < (int)p0)) break;
                }
            } while (i1++ < 6u && garr[i1 & 7u]);
        }
    }
    while (i0++ < 4u && (0xf8d5e4cdu * ~(2u * m0))) { if (--fuel == 0u) goto done;
        if ((unsigned)s0) break;
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t0; double z0; if ((0xffffffffu) & 1u) { t0 = (unsigned)((int)(unsigned)f0 < (int)(unsigned)e0); z0 = (double)((((unsigned)(m0 == (unsigned)(x0 >> 70)) % (8u | 1u))) & 255u); } if ((0xffffffffu) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            if ((unsigned)((unsigned)s0 || i1)) goto L4;
            w0 ^= (unsigned long long)(unsigned)c0 << (2u & 63u);
        }
        if (p0) goto L1;
        switch (9u & 7u) {
            *q0 = (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)(0x7547d947u && (0x7fffffffu % (a0[u1 & 3u] | 1u))));
            if (((g1 & (unsigned)x0) ^ 0xc615b91au)) {
                v0 = *mp;
                r0.y ^= (0x4450ee92u ? (unsigned)c0 : -(unsigned)(i2 < 0x5411f158u));
                case 6u: ;
                if ((garr[i1 & 7u] % (i1 | 1u))) goto L2;
                switch ((0xf0f6407eu / ((unsigned)((int)g1 < (int)0x63b4d578u) | 1u)) & 7u) {
                    v0 = -(-(unsigned)((unsigned)h1 == (4u << (g1 & 31u))) * (unsigned)(i2 && 0x7fffffffu));
                    a0[3u & 3u] = (unsigned)(short)((g1 * fuel) | ((unsigned)h1 % ((0x5adf24eau | (unsigned)l0) | 1u)));
                    u1 += (fuel | ((unsigned)((int)(unsigned)e0 < (int)garr[u2 & 7u]) + 0x10000u));
                    w0 ^= (unsigned long long)(unsigned)(unsigned char)(u2 | 2u) << ((i1 << ((unsigned)(p2 == a0[i0 & 3u]) & 31u)) & 63u);
                    case 6u: ;
                }
            }
        }
        a0[((unsigned)e0 % (2u | 1u)) & 3u] = ((unsigned)(short)((r0.x * 0x10000u) + i2) & ~((unsigned)s0 ^ 0x7fffffffu));
        c1 = (signed char)(((unsigned)c1 ? (unsigned)(w0 >> 29) : (unsigned)((short)m0 > (signed char)0x10000u)) % (0xffffffffu | 1u));
        { unsigned t1; double z1; if (((unsigned)(signed char)(unsigned)(fuel < i0)) & 1u) { t1 = (g1 * a0[i0 & 3u]); z1 = (double)((p2) & 255u); } if (((unsigned)(signed char)(unsigned)(fuel < i0)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            h0 = (short)0x7fffffffu;
            { unsigned t2; double z2; if ((0xffffffffu) & 1u) { t2 = ((unsigned)h0 & ((unsigned)f0 & (unsigned)d0)); z2 = (double)(((unsigned)((int)(unsigned)e0 < (int)(unsigned)((unsigned)b0 < (unsigned)l0))) & 255u); } if ((0xffffffffu) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                if ((unsigned)(w0 >> 29)) goto done;
                { unsigned t3; double z3; if (((unsigned)((unsigned)w0 < ((unsigned)d0 * m0))) & 1u) { t3 = (unsigned)(0xf9e75168u < (g0 ^ (unsigned)d0)); z3 = (double)(((0x94a6037au | 0x10000u)) & 255u); } if (((unsigned)((unsigned)w0 < ((unsigned)d0 * m0))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                    if ((*q0 ? 9u : fuel)) break;
                    if ((unsigned)s0) {
                        h1 = (unsigned short)(h1 + (p1 + (*q0 << ((0xffffffffu << ((unsigned)(*q0 == p1) & 31u)) & 31u))));
                        *q0 += (r0.y - 0x12903bdcu);
                        u1 += (unsigned)(garr[i1 & 7u] < a0[i0 & 3u]);
                        break; (void)(((unsigned)((int)0x43f57caeu < (int)u2) * p2));
                    } else {
                        s1 = (int)((unsigned)s1 + (((garr[i1 & 7u] ? (unsigned)e0 : r0.x) | (unsigned)s1) % ((unsigned)h0 | 1u)));
                        u3 = u3 * 0x9e3779b1u + ((unsigned)c1 & ~(fuel | ((unsigned)h1 * (unsigned)b0)));
                        while ((unsigned)(i1 == (unsigned)e0)) { if (--fuel == 0u) goto done;
                            w0 = w0 * 6364136223846793005ull + 0x2fc48bcau;
                            i0 = (g0 * i0) & 15u;
                        }
                    }
                    b0 = ((unsigned)(unsigned char)((unsigned)(7u < 0x10000u) | (unsigned)((int)0x6492a731u < (int)(unsigned)h0)) & garr[u2 & 7u]) != 0u;
                    { unsigned t4; double z4; if ((0xe69089f9u) & 1u) { t4 = (0x5840a53au * (0x34cf072du >> ((unsigned)(x0 >> 70) & 31u))); z4 = (double)(((unsigned)s1) & 255u); } if ((0xe69089f9u) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                        switch ((unsigned)(short)((unsigned)!((unsigned)l0 - (unsigned)(x0 >> 70)) % (u2 | 1u)) & 7u) {
                            u0 ^= (unsigned)((unsigned)(i0 || (r0.y & (unsigned)l0)) < (u2 << (garr[u2 & 7u] & 31u)));
                            case 7u: ;
                            case 3u: ;
                            if (fuel) break;
                            case 5u: ;
                        }
                        if ((unsigned)((unsigned)b0 && *q0)) continue;
                        garr[(unsigned)((unsigned)l0 == a0[i0 & 3u]) & 7u] = 0x31273f07u;
                        e0 = e0 * 0.5L + (long double)((unsigned)(((4u + (unsigned)b0) % ((unsigned)h0 | 1u)) < 0xffffffffu) & 1023u);
                    }
                }
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)s1 == r0.y);
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (g1) break;
                    if ((unsigned)((int)p1 < (int)3u)) continue;
                    v0 = (unsigned)!(4u + (unsigned)((int)0x7fffffffu < (int)0x80000000u));
                    if (-(unsigned)((int)((unsigned)b0 << (0xa0b4a463u & 31u)) < (int)g1)) continue;
                }
            }
        }
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)l0) goto L1;
        d0 = d0 * 0.5 + (double)(((unsigned)h0 + (0x3fcdf394u * (u2 % (*mp | 1u)))) & 1023u);
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (unsigned)((int)(unsigned)s1 >= (int)(unsigned)(signed char)(a0[i0 & 3u] + r0.y));
        if ((unsigned)s1) break;
        m0 ^= (unsigned)h1;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (0x7fffffffu) break;
            if (0x8c81314bu) break;
        }
        if (u0) goto L4;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (~(unsigned)((int)-(unsigned)(p1 || 0xf7da9fa9u) < (int)8u)) break;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (p0) break;
            if ((v0 + (unsigned)((int)(unsigned)e0 < (int)(unsigned)c0))) {
                if ((p0 % ((unsigned)c1 | 1u))) break;
                switch ((unsigned)((int)u0 >= (int)((unsigned)c0 | a0[u1 & 3u])) & 7u) {
                    for (;;) { if (--fuel == 0u) goto done;
                        case 1u: ;
                        r0.y ^= (p1 >> ((unsigned)c1 & 31u));
                    }
                    default: ;
                }
                { unsigned t5; double z5; if (((unsigned)d0) & 1u) { t5 = 0x80000000u; z5 = (double)(((unsigned)((short)g1 > (signed char)(unsigned)((int)garr[u2 & 7u] < (int)r0.y))) & 255u); } if (((unsigned)d0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    w0 ^= (unsigned long long)p2 << ((unsigned)h1 & 63u);
                    s0 = (int)((0x7fffffffu ? (unsigned)f0 : 0xdd180c27u) + garr[i1 & 7u]);
                    if (0x7fffffffu) {
                        garr[(0x80000000u >> (garr[u2 & 7u] & 31u)) & 7u] = (unsigned)((int)(unsigned)l0 >= (int)((unsigned)c1 << ((unsigned)w0 & 31u)));
                        if (i0) break;
                        if ((g1 ^ (u2 >> ((unsigned)b0 & 31u)))) break;
                    } else {
                        if ((unsigned)(signed char)(unsigned)((unsigned)w0 || (unsigned)c0)) break;
                        *q0 += (0xffffffffu * m0);
                    }
                    if (0xffffffffu) continue;
                }
            }
            if (fuel < 8u) return ((unsigned)h0 ^ ((v0 - u1) % ((i2 * g1) | 1u)));
            r0.x = (unsigned)(0x7653893fu && ((unsigned)c1 + 0x80000000u));
            if ((0x80000000u ^ 6u)) {
                if ((unsigned)(p0 < 0x80000000u)) continue;
            }
        }
    }
    g1 += ((0x81fdd239u % ((unsigned)h1 | 1u)) ? i2 : ((unsigned)l0 | g0));
    r0.x = p2;
    if ((unsigned)x0) goto L0;
    if ((unsigned)(r0.x == ((unsigned)c0 << (*mp & 31u)))) goto L4;
    if ((7u << (p0 & 31u))) goto L2;
    q0 = &garr[u2 & 7u];
    for (;;) { if (--fuel == 0u) goto done;
        *q0 += ((unsigned)s1 * ~(unsigned)((short)9u > (signed char)(unsigned)s1));
        if ((unsigned)(r0.y == ((unsigned)(w0 >> 29) + (unsigned)s1))) break;
    }
    if ((a0[u1 & 3u] ^ 0x3bed8c76u)) goto L1;
    if ((r0.x * u2)) goto L4;
    e0 = e0 * 0.5L + (long double)((unsigned)((p1 ^ ((unsigned)e0 / (0x7fffffffu | 1u))) || 0xff18d8dfu) & 1023u);
    do { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            if (0x96cea7f1u) goto L0;
            if (0xb5d596fdu) break;
        }
        w0 ^= (unsigned long long)((unsigned)s0 << (u3 & 31u)) << ((((7u % (i1 | 1u)) | (0x7fffffffu & 0x1bf1befu)) / ((unsigned)h1 | 1u)) & 63u);
        if ((1u * 0x80000000u)) {
            if (0xbdd00069u) {
                if ((unsigned)((int)*mp < (int)v0)) break;
                if (((unsigned)s0 ? v0 : 0xffffffffu)) break;
                break; (void)(p1);
                h0 = (short)((unsigned)(unsigned char)(0x7fffffffu / (*q0 | 1u)) / (garr[i1 & 7u] | 1u));
                if ((unsigned)s1) break;
            }
            while ((7u % (u0 | 1u))) { if (--fuel == 0u) goto done;
                if ((unsigned)(0x18ceea44u && (unsigned)(short)(unsigned)((int)0xffffffffu < (int)0xbb115258u))) break;
                q0 = &garr[(((3u % ((unsigned)b0 | 1u)) >> (r0.x & 31u)) >> (0x2e29c604u & 31u)) & 7u];
                if ((unsigned)((p1 % (0x1c1ebe02u | 1u)) == r0.x)) break;
                q0 = &garr[(unsigned)((p1 * u3) || (garr[i1 & 7u] ^ (unsigned)((int)r0.x < (int)0x7e453808u))) & 7u];
                if (((u3 + 0xb83a28c2u) & (unsigned)c1)) break;
            }
        } else {
            if ((1u >> (u0 & 31u))) {
                garr[(unsigned)s0 & 7u] = u0;
                s1 = (int)((unsigned)s1 + g0);
                if ((0x264d6212u ^ 0xffffffffu)) {
                    if (((unsigned)(signed char)(unsigned)(0x7fffffffu == a0[i0 & 3u]) % (m0 | 1u))) break;
                }
            } else {
                for (;;) { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        u1 += -((~(unsigned)(r0.x == 5u) - (unsigned)b0) >> ((unsigned)(w0 >> 29) & 31u));
                        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)h0 || (unsigned)(signed char)(unsigned)((int)p0 >= (int)r0.x)) & 1023u);
                        while (i0++ < 6u && (g1 & (unsigned)x0)) { if (--fuel == 0u) goto done;
                            if ((fuel % (p2 | 1u))) break;
                            g0 = (unsigned)(0xdca8fd88u && (p2 ? (unsigned)h1 : 2u));
                            u1 += (g1 % ((unsigned)f0 | 1u));
                            u3 ^= (u0 & (unsigned)w0);
                            if (5u) continue;
                            break; (void)((0x80000000u * (unsigned)!((unsigned)e0 & 0x80000000u)));
                        }
                        break; (void)(((unsigned)l0 ? (unsigned)h0 : 2u));
                        u1 = u1 * 0x9e3779b1u + (9u % ((unsigned)(unsigned char)((i2 * garr[i1 & 7u]) * 0x99279c05u) | 1u));
                        if (u3 == 7u) return (((unsigned)c0 & 0u) ? garr[u2 & 7u] : (u0 >> (0x10000u & 31u)));
                    }
                    q0 = &garr[(unsigned)!(unsigned)((unsigned)((unsigned)e0 && m0) && (i1 * v0)) & 7u];
                }
                if (0x7fffffffu) break;
            }
            continue; (void)((0x7fffffffu ? 0x80000000u : r0.y));
            l0 = (long)((unsigned long)l0 + (unsigned)!(((*mp >> ((unsigned)s1 & 31u)) - (unsigned)c0) / ((unsigned)(0xffffffffu && 0x10000u) | 1u)));
            if ((unsigned)((unsigned)(u3 < (unsigned)s0) < g0)) continue;
        }
        break; (void)((unsigned)((unsigned)((short)2u > (signed char)0xb3740bacu) && *mp));
        do { if (--fuel == 0u) goto done;
            if (m0) break;
            g0 = m0;
            if (~(unsigned)((int)r0.y >= (int)0x10000u)) goto L2;
            r0.x = ((0x82ce1294u - (r0.y - (unsigned)(x0 >> 70))) % (0x3b335cc6u | 1u));
            m0 ^= (4u >> ((unsigned)(p0 || p1) & 31u));
            break; (void)((fuel + 0x80000000u));
        } while (i1++ < 2u && i0);
        b0 = (unsigned)((v0 >> ((unsigned)x0 & 31u)) || (garr[i1 & 7u] & 9u)) != 0u;
    } while (i0++ < 4u && (unsigned)(0xffffffffu < 0x10000u));
    if ((unsigned)(signed char)(unsigned)((int)garr[u2 & 7u] >= (int)(u3 % (p1 | 1u)))) goto L3;
    if ((0x7eb29bc8u + ((unsigned)s1 | 2u))) goto L0;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (i1) break;
        }
        break; (void)((m0 & a0[i0 & 3u]));
        if ((unsigned)((int)(*mp & (unsigned)x0) < (int)0x80000000u)) break;
        { unsigned t6; double z6; if ((((p0 & u1) / (0x7fffffffu | 1u))) & 1u) { t6 = (p1 ^ r0.y); z6 = (double)(((unsigned)(signed char)(p2 % ((0x10000u - (unsigned)f0) | 1u))) & 255u); } if ((((p0 & u1) / (0x7fffffffu | 1u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            switch ((0xcbb88bd4u & 0x10000u) & 7u) {
                *mp = (unsigned)d0;
                r0.y ^= (0x80000000u * 0xffffffffu);
                if (g1) break;
            }
            e0 = e0 * 0.5L + (long double)((unsigned)s0 & 1023u);
            if (0x80e68061u) break;
            *q0 = (((unsigned)((int)g0 >= (int)*q0) % (*mp | 1u)) - u1);
            if ((unsigned)s1) break;
            g1 += ((unsigned)d0 ? (unsigned)l0 : (unsigned)w0);
        }
    }
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((int)0x80000000u < (int)(unsigned)f0));
    } while (i0++ < 5u && (unsigned)(i1 || (*mp | (unsigned)s0)));
    if ((unsigned)(u0 < 0x10000u)) goto done;
    if (((a0[u1 & 3u] / ((unsigned)(x0 >> 70) | 1u)) * 0x2b623b12u)) goto L4;
    if ((unsigned)((unsigned)h1 || (r0.x ^ (unsigned)(x0 >> 70)))) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *mp = (unsigned)((int)0x80000000u >= (int)((unsigned)s0 + (unsigned)(2u < u3)));
    if ((unsigned)((int)0x80000000u >= (int)((unsigned)x0 % (i2 | 1u)))) goto L4;
    f0 = f0 * 0.5f + (float)((unsigned)!((unsigned)b0 + r0.y) & 255u);
    if (((unsigned)h1 % (0x6fc78932u | 1u))) {
        h0 = (short)(unsigned)((unsigned)((int)g1 >= (int)(unsigned)c0) && (4u % (0xa9fcf5b5u | 1u)));
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)c1 | (unsigned)s0), ((unsigned)x0 / (0xffffffffu | 1u)), (unsigned)((short)((unsigned)h0 * i1) > (signed char)r0.y)); }
        e0 = e0 * 0.5L + (long double)(((unsigned)s1 | *mp) & 1023u);
        goto L2;
        if (budget != 0u) { budget -= 1u; u2 = fn0((2u % ((unsigned)(short)(unsigned)(0x24f74f3u == u1) | 1u)), (unsigned)(0x49c37184u == (unsigned)((int)p0 >= (int)u2)), (unsigned)(signed char)(unsigned)((unsigned)(short)(5u * (unsigned)(x0 >> 70)) == p2)); }
    }
    for (;;) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0((*mp % (i2 | 1u)), (unsigned)c0, ((unsigned)s0 << (i2 & 31u))); }
        for (;;) { if (--fuel == 0u) goto done;
            *mp = (*q0 << ((*q0 >> ((unsigned)!((unsigned)((int)(unsigned)e0 >= (int)g1) ^ *q0) & 31u)) & 31u));
            c0 = (unsigned char)(r0.y ^ (unsigned)(unsigned char)(0xffffffffu - 0x12f22b11u));
            a0[(unsigned)c0 & 3u] = (unsigned)((int)(unsigned)((short)(unsigned)(4u == 3u) > (signed char)0xffffffffu) < (int)(0u / (p0 | 1u)));
            if (-(unsigned)((int)(unsigned)(signed char)((unsigned)s1 / ((unsigned)w0 | 1u)) < (int)4u)) goto L3;
            *q0 = (unsigned)((int)g0 >= (int)(unsigned)(fuel || (a0[i0 & 3u] / ((unsigned)x0 | 1u))));
            if ((unsigned)(short)(0x9d1e9106u ? 0x80000000u : (unsigned)h0)) break;
        }
        w0 = w0 * 6364136223846793005ull + (unsigned)(((unsigned)c1 << (u0 & 31u)) || r0.y);
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((r0.y / (6u | 1u)), (((unsigned)w0 - r0.y) - 0x4301e14du), (unsigned)!(u3 ^ i2)); }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (p2 ^ a0[u1 & 3u]);
        { unsigned t0; double z0; if (((unsigned)(0xcb3e9e4au || p1)) & 1u) { t0 = (unsigned)((int)0x7fffffffu < (int)(0x9a99699u << ((unsigned)h0 & 31u))); z0 = (double)((i2) & 255u); } if (((unsigned)(0xcb3e9e4au || p1)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            L0: if (--fuel == 0u) goto done;
            if (((unsigned)h0 ? p2 : (unsigned)e0)) continue;
            i1 = 0x10000u & 15u;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch ((unsigned)((unsigned)c1 == r0.x) & 7u) {
                    c1 = (signed char)(unsigned)(0xffffffffu < (unsigned)(signed char)(unsigned)((unsigned)l0 == 9u));
                }
                goto L1;
                if (fuel < 8u) return ((unsigned)((int)0x80000000u < (int)garr[i1 & 7u]) - (unsigned)((short)0x80000000u > (signed char)(unsigned)(short)(unsigned)((short)0xef22c408u > (signed char)*q0)));
                if ((u1 ? p0 : *mp)) goto L2;
            }
            b0 = (unsigned)!((unsigned)h1 * (unsigned)((unsigned)(unsigned char)(unsigned)(i0 || (u3 / (0x80000000u | 1u))) == v0)) != 0u;
        }
        if (((unsigned)l0 ^ garr[i1 & 7u])) break;
        r0.x = (garr[u2 & 7u] | ((i1 + u2) & u2));
        i2 = ((0xffffffffu ^ (unsigned)x0) ^ (u1 * (v0 | 0xe05e965du))) & 15u;
    }
    switch ((unsigned)c0 & 7u) {
        h0 = (short)~(unsigned)(p0 == (unsigned)((int)((unsigned)l0 * p0) < (int)(unsigned)((int)9u < (int)0xffffffffu)));
        if (-(p2 ? p2 : (unsigned)c1)) goto L1;
        while ((0x2f94ed8fu % ((unsigned)(a0[u1 & 3u] < garr[i1 & 7u]) | 1u))) { if (--fuel == 0u) goto done;
            *q0 += (unsigned)(i0 < 4u);
        }
        v0 = p1;
        if (budget != 0u) { budget -= 1u; u0 = fn0((a0[u1 & 3u] / ((unsigned)w0 | 1u)), (unsigned)s0, ((unsigned)(x0 >> 70) + 0x27d4af22u)); }
    }
    if ((unsigned)(((unsigned)(w0 >> 29) + (unsigned)c0) && i0)) {
        i0 = (((unsigned)s1 & a0[i0 & 3u]) >> ((unsigned)(0xffffffffu < ((unsigned)c1 ^ (unsigned)h1)) & 31u)) & 15u;
        if (p0) goto L1;
    } else {
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (unsigned)(((u2 / ((unsigned)((short)m0 > (signed char)fuel) | 1u)) % (r0.y | 1u)) == r0.x));
                continue; (void)((0xffffffffu | i1));
                u3 = u3 * 0x9e3779b1u + ((unsigned)(signed char)(unsigned)(0x2572fc0bu < (i1 ? (unsigned)c1 : r0.x)) >> (fuel & 31u));
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    g0 = (((unsigned)((int)garr[u2 & 7u] >= (int)0x10000u) + p2) >> ((unsigned)c1 & 31u));
                    break; (void)(((u3 >> (g1 & 31u)) >> ((unsigned)x0 & 31u)));
                    b0 = ((unsigned)(unsigned char)(0x2fb225ebu - m0) | 8u) != 0u;
                    g1 += (2u ^ (unsigned)(((unsigned)b0 ? v0 : a0[i0 & 3u]) && g1));
                    while (i0++ < 3u && (unsigned)(short)(unsigned)((0x7fffffffu << (u2 & 31u)) == *mp)) { if (--fuel == 0u) goto done;
                        if (~((unsigned)((short)u2 > (signed char)(unsigned)(x0 >> 70)) >> (garr[i1 & 7u] & 31u))) continue;
                        if (((unsigned)((unsigned)c0 < (unsigned)w0) + 0xedb458c2u)) continue;
                        garr[(garr[i1 & 7u] * (unsigned)d0) & 7u] = u3;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(garr[i1 & 7u], (unsigned)(p0 < (0x9bb174f5u * (unsigned)(x0 >> 70))), (p2 / ((unsigned)f0 | 1u))); }
                    }
                }
            }
            g0 = (-(0xc07bb004u + 0x7fffffffu) % ((unsigned)h1 | 1u));
        }
    }
    *q0 = ~((unsigned)((0xebce55c5u + *q0) < garr[i1 & 7u]) << ((i2 >> ((unsigned)h0 & 31u)) & 31u));
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x6aff37d7u || (unsigned)!(unsigned)(i1 < g1)), (unsigned)x0, (unsigned)s0); }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)((int)u3 < (int)(unsigned)s1) && (unsigned)h1), (unsigned)((unsigned)(w0 >> 29) == (unsigned)w0), p1); }
    if ((unsigned)((unsigned)f0 < u0)) goto L2;
    { unsigned t1; double z1; if ((*mp) & 1u) { t1 = (*mp + 8u); z1 = (double)((((unsigned)x0 / ((r0.x & (unsigned)c1) | 1u))) & 255u); } if ((*mp) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        L2: if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (9u ? (r0.x | (unsigned)e0) : 8u);
        u0 += (u0 << (((unsigned)((unsigned)d0 || 0xc0969596u) / ((unsigned)(fuel || 0x53eec4ccu) | 1u)) & 31u));
        while ((unsigned)((short)(unsigned)(g0 < a0[i0 & 3u]) > (signed char)(unsigned)s1)) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)(0xffffffffu);
                q0 = &garr[(unsigned)((int)(unsigned)((int)(r0.x ^ (unsigned)c0) >= (int)3u) >= (int)0xc9cd8fc7u) & 7u];
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)0x8756192au > (signed char)(unsigned)b0), 0x7fffffffu, u2); }
            }
            if (0x5875bc1au) {
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    u0 = fuel;
                    if ((unsigned)((unsigned)(a0[i0 & 3u] || 4u) || (unsigned)c1)) {
                        *q0 = 0x80000000u;
                        for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                            garr[u1 & 7u] = ~(0x7fffffffu + (a0[i0 & 3u] & (unsigned)b0));
                            if ((0xfccd6b10u + ~((unsigned)w0 / (r0.y | 1u)))) goto L1;
                        }
                    }
                    u3 = u3 * 0x9e3779b1u + (unsigned)(fuel < 0x4964e413u);
                }
                { unsigned t2; double z2; if ((-(i2 / (*q0 | 1u))) & 1u) { t2 = ((unsigned)s0 % (garr[u2 & 7u] | 1u)); z2 = (double)(((unsigned)(i2 || a0[u1 & 3u])) & 255u); } if ((-(i2 / (*q0 | 1u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    L3: if (--fuel == 0u) goto done;
                    u3 = ((a0[i0 & 3u] ? p1 : 0x877f87fu) & a0[u1 & 3u]);
                    if ((7u | (unsigned)(u2 < u1))) continue;
                    f0 = f0 * 0.5f + (float)((unsigned)(short)(4u ^ (unsigned)s1) & 255u);
                    f0 = f0 * 0.5f + (float)(((unsigned)s1 + u1) & 255u);
                }
                i2 = (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)(u1 == *q0)) & 15u;
                h1 = (unsigned short)(h1 + i2);
            }
            s1 = (int)((unsigned)s1 + garr[u2 & 7u]);
            if (v0) goto L0;
            m0 ^= u1;
        }
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 += (((unsigned)h0 ^ (unsigned)h0) ^ ((unsigned)(signed char)(0x80000000u + 0xffffffffu) + *q0));
        }
        if ((u0 / ((unsigned)((int)0xd74f2e08u < (int)(unsigned)d0) | 1u))) goto done;
    }
    while (i0++ < 6u && -(unsigned)(0x28c820cfu == 0xf190260bu)) { if (--fuel == 0u) goto done;
        switch (-(~(unsigned)(m0 && 8u) & (unsigned)w0) & 7u) {
            s1 = (int)((unsigned)s1 + (0xffffffffu | ((unsigned)(0x4652c68bu == -(1u / (garr[i1 & 7u] | 1u))) ^ (unsigned)h1)));
            v0 = (unsigned)(unsigned char)((unsigned)((int)(unsigned)((unsigned)(0xbddb8008u == (unsigned)s1) && 0xffffffffu) >= (int)(unsigned)c0) ^ r0.y);
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 2u: ;
                { unsigned t3; double z3; if (((unsigned)((short)0x10000u > (signed char)5u)) & 1u) { t3 = (unsigned)((int)((unsigned)(x0 >> 70) & u2) < (int)i2); z3 = (double)((u0) & 255u); } if (((unsigned)((short)0x10000u > (signed char)5u)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    if ((unsigned)((int)v0 >= (int)p1)) goto L0;
                    L4: if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(signed char)(unsigned)((int)(unsigned)d0 < (int)0x10000u), (unsigned)((short)0x2f27a4c3u > (signed char)(unsigned)(0x719ba80du == 0xffffffffu)), ((unsigned)h1 | (unsigned)((unsigned)(x0 >> 70) < u0))); }
                    if (((7u >> (0x10000u & 31u)) / (r0.x | 1u))) continue;
                    if (((unsigned)h0 / ((unsigned)(a0[u1 & 3u] == g0) | 1u))) goto L1;
                }
            }
            switch ((unsigned)(signed char)(((unsigned)l0 % (a0[u1 & 3u] | 1u)) % (0x7fffffffu | 1u)) & 7u) {
                switch ((fuel << (fuel & 31u)) & 7u) {
                    case 5u: ;
                    if (u3 == 7u) return (unsigned)d0;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((u1 | (unsigned)l0) & (unsigned)x0), v0, (unsigned)w0); }
                    default: ;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)e0 / ((unsigned)h1 | 1u)), u3, ((unsigned)h1 & m0)); }
            }
        }
        if ((unsigned)(short)((unsigned)b0 >> (i1 & 31u))) break;
        c1 = (signed char)(u1 + (p2 >> ((unsigned)w0 & 31u)));
        if (a0[i0 & 3u]) {
            if ((unsigned)((unsigned)(unsigned char)(0u % ((unsigned)l0 | 1u)) == m0)) break;
        } else {
            f0 = f0 * 0.5f + (float)((0xffffffffu | (unsigned)(signed char)(*mp | (unsigned)l0)) & 255u);
            if (fuel) break;
            if (budget != 0u) { budget -= 1u; u3 = fn0(a0[u1 & 3u], (unsigned)((int)0xffffffffu >= (int)0x9342d95bu), (6u & p1)); }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((0xc7347b5du << (u2 & 31u)), u1, (unsigned)h0); }
        { unsigned t4; double z4; if (((unsigned)((int)(unsigned)c0 < (int)(unsigned)((unsigned)(x0 >> 70) || p1))) & 1u) { t4 = (unsigned)s0; z4 = (double)((g0) & 255u); } if (((unsigned)((int)(unsigned)c0 < (int)(unsigned)((unsigned)(x0 >> 70) || p1))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
            q0 = &garr[(r0.x ^ 0x7a4f4f9du) & 7u];
            if (9u) goto L1;
        }
    }
    m0 ^= ((unsigned)((int)m0 < (int)v0) | (5u + fuel));
    *q0 = (unsigned)((int)(unsigned)(x0 >> 70) < (int)((unsigned)h1 ^ 0x10000u));
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = (unsigned)(p1 && 0xc6ae812bu);
        if (budget != 0u) { budget -= 1u; u1 = fn0((u0 / (((unsigned)f0 + u2) | 1u)), ((unsigned)(x0 >> 70) * ((unsigned)f0 * garr[i1 & 7u])), fuel); }
    }
    goto L2;
    while (i0++ < 4u && (p0 + (0x7fffffffu << (garr[i1 & 7u] & 31u)))) { if (--fuel == 0u) goto done;
        m0 ^= ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)((unsigned)w0 && (unsigned)f0)) % (0x84dc7264u | 1u));
        h0 = (short)(unsigned)((short)*q0 > (signed char)(unsigned)s1);
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)((unsigned)x0 + u2);
            if (budget != 0u) { budget -= 1u; u2 = fn0((u2 * *mp), (u0 * i2), (u1 << ((unsigned)(0xe26d21ceu && a0[i0 & 3u]) & 31u))); }
        }
        { unsigned t5; double z5; if (((0xffffffffu ? v0 : 0xafa26459u)) & 1u) { t5 = ((unsigned)((int)0xd876a46u >= (int)g0) << (u3 & 31u)); z5 = (double)((~(unsigned)(v0 < (unsigned)((int)(unsigned)w0 < (int)v0))) & 255u); } if (((0xffffffffu ? v0 : 0xafa26459u)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)(unsigned)((short)r0.x > (signed char)i0), ((unsigned)c1 + ((unsigned)l0 * (unsigned)w0)), (unsigned)(p2 == u3)); }
        }
        c0 = (unsigned char)(unsigned)((unsigned)s1 == (unsigned)((unsigned)w0 < (unsigned)l0));
    }
    { unsigned t6; double z6; if ((0x202d984bu) & 1u) { t6 = (0xffffffffu * 0xe0a0ef0eu); z6 = (double)(((unsigned)(1u && ((unsigned)l0 / (p1 | 1u)))) & 255u); } if ((0x202d984bu) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
        if ((unsigned)((int)(u1 - (unsigned)(x0 >> 70)) < (int)r0.y)) {
            goto L3;
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (i1) continue;
                l0 = (long)((unsigned long)l0 + (unsigned)(p1 < ((unsigned)(0x7fffffffu || garr[i1 & 7u]) ? v0 : 0x10000u)));
                m0 ^= (unsigned)((7u >> ((*mp / (0x7a33ba5eu | 1u)) & 31u)) < 0x69ff7a3fu);
                m0 ^= ((1u + a0[u1 & 3u]) & p2);
            }
            e0 = e0 * 0.5L + (long double)((p0 - ~(r0.y ? (unsigned)w0 : (unsigned)s0)) & 1023u);
        } else {
            goto L4;
            g1 += (r0.x / ((unsigned)((short)(unsigned)((int)v0 >= (int)0x55745602u) > (signed char)(p0 % (0x7fffffffu | 1u))) | 1u));
            if ((unsigned)(u3 || (p2 / (i2 | 1u)))) goto L0;
        }
        if ((unsigned)(((unsigned)d0 | (unsigned)h1) && 0x141e3254u)) goto L1;
        goto L3;
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            g1 += ((unsigned)d0 ^ ~(-(0x901c06e1u & 8u) - *mp));
            x0 = x0 * 0x100000001b3ull + (~((unsigned)e0 ? (unsigned)(w0 >> 29) : (unsigned)x0) * 4u);
            *q0 += (3u >> (g1 & 31u));
            break; (void)((unsigned)(a0[i0 & 3u] == (unsigned)((unsigned)w0 < u3)));
        }
        goto L2;
        w0 = w0 * 6364136223846793005ull + 9u;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)(a0[u1 & 3u] || r0.y) < (int)0xffffffffu), (unsigned)(2u == m0), (unsigned)((u3 - 0x5dd2c749u) == g0)); }
    u1 += (unsigned)((int)-(0xffffffffu * (unsigned)w0) < (int)((unsigned)h1 << (0x10000u & 31u)));
    if (p1) {
        v0 = (unsigned)((int)0x69300f3bu < (int)(((unsigned)((int)u3 >= (int)m0) & garr[u2 & 7u]) | 0xff813a0au));
        goto L0;
    }
    u2 = (unsigned)((short)(0x97b46a5cu ? g0 : r0.x) > (signed char)(unsigned)b0);
    h0 = (short)((unsigned)c1 % (((unsigned)x0 ^ u0) | 1u));
    v0 = 0xa4a29817u;
    s0 = (int)(unsigned)(r0.y && -((v0 & 0x25ea379fu) >> ((unsigned)w0 & 31u)));
    if (7u) {
        s1 = (int)((unsigned)s1 + (unsigned)w0);
        garr[(unsigned)((int)p1 >= (int)u2) & 7u] = (a0[u1 & 3u] + 1u);
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(p2 & 1023u);
        }
    }
    garr[(unsigned)((unsigned)c1 || g1) & 7u] = r0.x;
    i0 = ((u2 - (v0 / (0xf4104c60u | 1u))) - (p0 - u3)) & 15u;
    { unsigned t7; double z7; if ((((unsigned)(w0 >> 29) & (unsigned)((unsigned)h1 || a0[i0 & 3u]))) & 1u) { t7 = (unsigned)(u0 && ((unsigned)l0 * 0x10000u)); z7 = (double)(((r0.x << (v0 & 31u))) & 255u); } if ((((unsigned)(w0 >> 29) & (unsigned)((unsigned)h1 || a0[i0 & 3u]))) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
        switch (garr[i1 & 7u] & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((0xd3ca402eu - 3u), (unsigned)(signed char)(unsigned)(i1 || r0.x), (unsigned)d0); }
            for (;;) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((int)(unsigned)(p2 == garr[u2 & 7u]) >= (int)0x1aaab770u) == garr[u2 & 7u]) & 1023u);
                if (((unsigned)h1 * a0[i0 & 3u])) goto L3;
                l0 = (long)((unsigned long)l0 + (u2 ? m0 : 4u));
            }
            g0 = (fuel << ((unsigned)e0 & 31u));
            u0 = u0 * 0x9e3779b1u + ((unsigned)h1 ^ ((unsigned)(unsigned char)(unsigned)((a0[u1 & 3u] >> (0xffffffffu & 31u)) == p0) - *mp));
            while (i0++ < 3u && (unsigned)e0) { if (--fuel == 0u) goto done;
                case 3u: ;
                x0 = x0 * 0x100000001b3ull + (unsigned)((0x7fffffffu - r0.x) || (p1 % ((unsigned)c0 | 1u)));
                v0 = ((unsigned)((int)(unsigned)d0 < (int)(unsigned)w0) | (unsigned)c1);
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = ((unsigned)x0 + v0);
                    c1 = (signed char)(p1 & (((unsigned)s1 - 0x391860abu) + v0));
                    case 5u: ;
                    case 4u: ;
                }
            }
            switch ((unsigned)((short)0x80000000u > (signed char)(unsigned)((int)0xd82c3a36u < (int)6u)) & 7u) {
                if ((unsigned)h0) {
                    s1 = (int)((unsigned)s1 + ((unsigned)(signed char)(unsigned)((unsigned)((unsigned)f0 && a0[i0 & 3u]) < u3) * i2));
                    if (u1) {
                        if (budget != 0u) { budget -= 1u; u0 = fn0((i1 >> (6u & 31u)), (unsigned)(unsigned char)(g0 - v0), (i0 - v0)); }
                        u2 = p0;
                        case 6u: ;
                        u0 += ~(unsigned)((short)(unsigned)h1 > (signed char)(garr[u2 & 7u] & (p1 / ((unsigned)s1 | 1u))));
                        h1 = (unsigned short)(h1 + (unsigned)((short)(garr[i1 & 7u] & 4u) > (signed char)m0));
                    } else {
                        h0 = (short)(i1 - ((unsigned)(signed char)((unsigned)((unsigned)f0 || (unsigned)w0) / ((unsigned)l0 | 1u)) ^ (unsigned)c0));
                        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                            m0 ^= (unsigned)((i2 / (g0 | 1u)) < g1);
                        }
                        c1 = (signed char)((unsigned)d0 | garr[i1 & 7u]);
                        u1 = g1;
                    }
                    if (0xffffffffu) break;
                }
                case 5u: ;
            }
        }
        c1 = (signed char)((unsigned)d0 % ((unsigned)d0 | 1u));
        { unsigned t8; double z8; if (((i2 & (r0.y - garr[i1 & 7u]))) & 1u) { t8 = (unsigned)!(unsigned)((int)r0.x >= (int)0x80000000u); z8 = (double)(((unsigned)(unsigned char)(0xffffffffu / (p2 | 1u))) & 255u); } if (((i2 & (r0.y - garr[i1 & 7u]))) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    v0 = (unsigned)((0x7fffffffu ? 6u : u1) || (unsigned)((int)(unsigned)c0 >= (int)(unsigned)d0));
                    if ((g0 ? u3 : u1)) break;
                    g0 = (unsigned)((int)(unsigned)f0 >= (int)2u);
                    if (garr[u2 & 7u]) goto L4;
                } while (i1++ < 2u && ((unsigned)d0 ? u1 : fuel));
                switch (i2 & 7u) {
                    goto done;
                }
            }
            r0.x = (5u + (unsigned)((short)p0 > (signed char)5u));
            switch (((unsigned)x0 * g1) & 7u) {
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t9; double z9; if ((((m0 * u1) * fuel)) & 1u) { t9 = (unsigned)((int)garr[i1 & 7u] >= (int)(0x9a5f426fu << (u0 & 31u))); z9 = (double)((0x80000000u) & 255u); } if ((((m0 * u1) * fuel)) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                        if ((unsigned)e0) {
                            *mp = ((0x7492a8b1u % ((unsigned)c0 | 1u)) * 0x10000u);
                            case 0u: ;
                            r0.x = ((unsigned)(g0 == ((unsigned)s1 + *mp)) | (0x530559d5u - 0x31c1a095u));
                        } else {
                            s0 = (int)(4u ? (unsigned)x0 : i2);
                        }
                    }
                    case 6u: ;
                    l0 = (long)((unsigned long)l0 + 0xb888e811u);
                    g1 += (0xd59668a1u | 0x642437b1u);
                    { unsigned t10; double z10; if ((garr[u2 & 7u]) & 1u) { t10 = (0xffffffffu & (0xd446e058u >> ((unsigned)w0 & 31u))); z10 = (double)(((unsigned)((short)fuel > (signed char)(unsigned)((unsigned)e0 < (unsigned)d0))) & 255u); } if ((garr[u2 & 7u]) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
                        if (budget != 0u) { budget -= 1u; u2 = fn0((0xabfae988u << (7u & 31u)), 7u, ((unsigned)w0 / (p2 | 1u))); }
                        while ((unsigned)((int)i2 >= (int)0xaf7614adu)) { if (--fuel == 0u) goto done;
                            h0 = (short)(unsigned)((int)*q0 < (int)4u);
                            r0.y ^= a0[i0 & 3u];
                        }
                        if (v0) {
                            v0 = (unsigned)(3u || (0xf5ea9366u | 0xffffffffu));
                            f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)(unsigned char)(i1 ^ g1) < (int)((unsigned)(short)((unsigned)h1 % ((unsigned)l0 | 1u)) >> (7u & 31u))) & 255u);
                            case 3u: ;
                        } else {
                            x0 = x0 * 0x100000001b3ull + (unsigned)(g1 == (unsigned)(r0.x == (unsigned)(u2 && m0)));
                            w0 = w0 * 6364136223846793005ull + (unsigned)(((unsigned)(x0 >> 70) % ((unsigned)(w0 >> 29) | 1u)) < (unsigned)l0);
                            x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)((int)(unsigned)w0 >= (int)(unsigned)((short)8u > (signed char)(unsigned)f0)) / (0x48074b98u | 1u)) && u1);
                        }
                        default: ;
                    }
                    m0 ^= (0x7fffffffu * ~((8u << (2u & 31u)) + 0x17a6bc7eu));
                }
                g1 += (unsigned)c0;
                while (i0++ < 4u && i2) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + ~(unsigned)(((unsigned)(w0 >> 29) - u3) && 0xd57c621u);
                    if ((unsigned)s0) continue;
                    c1 = (signed char)(unsigned)(0x9c0b070au && (((unsigned)c1 - 0x3ff468a5u) << ((unsigned)h0 & 31u)));
                    w0 ^= (unsigned long long)(0x89b9adb9u >> (0x7fffffffu & 31u)) << ((unsigned)((unsigned)((int)g0 < (int)0x5fba3763u) == (p2 >> (m0 & 31u))) & 63u);
                    r0.x = (unsigned)(short)((unsigned)((int)0x80000000u >= (int)p0) / (i0 | 1u));
                    break;
                }
                for (;;) { if (--fuel == 0u) goto done;
                    case 7u: ;
                    u3 ^= (unsigned)((short)(unsigned)h0 > (signed char)(unsigned)((unsigned)c0 < 0xb8aaa69cu));
                    while (i1++ < 5u && 0x80000000u) { if (--fuel == 0u) goto done;
                        break;
                        b0 = g1 != 0u;
                        case 2u: ;
                        goto L2;
                        case 1u: ;
                    }
                    if (((unsigned)d0 - 0xffffffffu)) continue;
                    m0 ^= r0.y;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((5u * garr[u2 & 7u]) | p1), (unsigned)((int)(unsigned)f0 >= (int)p1), p0); }
                }
                *q0 += (((p0 >> ((unsigned)h1 & 31u)) / (m0 | 1u)) | a0[u1 & 3u]);
            }
            if ((*q0 + (i0 + (unsigned)(w0 >> 29)))) {
                goto L2;
                goto L4;
            }
            g1 += (unsigned)(short)((unsigned)(unsigned char)(unsigned)(garr[i1 & 7u] == i0) % (((unsigned)((short)u3 > (signed char)(unsigned)d0) + (unsigned)(x0 >> 70)) | 1u));
            switch (~(unsigned)((7u ^ r0.x) || garr[u2 & 7u]) & 7u) {
                s1 = (int)((unsigned)s1 + (unsigned)(signed char)((0x7ac59f6au - (unsigned)w0) << ((unsigned)c1 & 31u)));
                s0 = (int)4u;
                for (;;) { if (--fuel == 0u) goto done;
                    if (~(unsigned)((unsigned)((int)a0[i0 & 3u] < (int)v0) == u2)) continue;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)g0 > (signed char)(unsigned)(w0 >> 29)), u0, p1); }
                b0 = (unsigned)((int)(unsigned)w0 >= (int)(unsigned)d0) != 0u;
            }
        }
    }
    m0 ^= 0xffffffffu;
    { unsigned t11; double z11; if ((u2) & 1u) { t11 = (0x6953e65fu + (unsigned)d0); z11 = (double)(((u2 - (0x11ed8008u * 6u))) & 255u); } if ((u2) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
        garr[fuel & 7u] = (unsigned)(garr[u2 & 7u] < (unsigned)b0);
        l0 = (long)((unsigned long)l0 + (((unsigned)e0 % (0x10000u | 1u)) % ((unsigned)d0 | 1u)));
    }
    if ((5u & 0x5806f893u)) {
        v0 = ~(unsigned)((unsigned)s0 < (0x10000u << ((unsigned)((short)garr[i1 & 7u] > (signed char)g1) & 31u)));
        u1 = ((a0[i0 & 3u] << ((unsigned)c1 & 31u)) >> ((unsigned)((unsigned)(0x8f636d91u < (unsigned)f0) == (unsigned)c1) & 31u));
        g1 += (unsigned)(0x5480e8a5u && ((unsigned)h1 | (unsigned)x0));
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((p1 * 0x10000u), (0xd9e29741u % ((unsigned)((int)v0 >= (int)(unsigned)c1) | 1u)), 8u); }
    if ((unsigned)(unsigned char)(unsigned)((unsigned)s0 < v0)) goto L3;
    g1 += ~(unsigned)(fuel < ((unsigned)c1 | (unsigned)h1));
    s1 = (int)((unsigned)s1 + (unsigned)x0);
    if ((unsigned)(short)((unsigned)w0 >> (0x272e7916u & 31u))) {
        do { if (--fuel == 0u) goto done;
            { unsigned t12; double z12; if (((unsigned)((short)u2 > (signed char)u0)) & 1u) { t12 = ((unsigned)((int)i1 < (int)0xc87fc133u) - 0x6aea7ebcu); z12 = (double)((garr[u2 & 7u]) & 255u); } if (((unsigned)((short)u2 > (signed char)u0)) & 1u) { u3 += t12; d0 = d0 * 0.5 + z12; }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)u3 > (signed char)0xffffffffu), (unsigned)((int)p2 < (int)fuel), a0[u1 & 3u]); }
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((unsigned)(signed char)(0xffffffffu % (p1 | 1u)) & 1023u);
                    break; (void)(((0x7fffffffu + 0x10000u) >> ((unsigned)(x0 >> 70) & 31u)));
                    l0 = (long)((unsigned long)l0 + (unsigned)(p1 && r0.y));
                }
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (0x10000u ^ garr[i1 & 7u]) != 0u;
                    { unsigned t13; double z13; if ((0x7cfd283eu) & 1u) { t13 = (u3 % ((u3 ^ 0xffffffffu) | 1u)); z13 = (double)(((unsigned)c0) & 255u); } if ((0x7cfd283eu) & 1u) { u3 += t13; d0 = d0 * 0.5 + z13; }
                        break; (void)((unsigned)((int)1u < (int)(unsigned)x0));
                        l0 = (long)((unsigned long)l0 + (unsigned)(0xffffffffu || (unsigned)c1));
                        if ((unsigned)((int)p1 >= (int)1u)) break;
                        { unsigned t14; double z14; if (((unsigned)(unsigned char)(unsigned)((int)(unsigned)(0x9baf3877u == g1) < (int)1u)) & 1u) { t14 = (unsigned)c0; z14 = (double)((u3) & 255u); } if (((unsigned)(unsigned char)(unsigned)((int)(unsigned)(0x9baf3877u == g1) < (int)1u)) & 1u) { u3 += t14; d0 = d0 * 0.5 + z14; }
                            if (budget != 0u) { budget -= 1u; u3 = fn0((u0 | u1), (unsigned)((unsigned)(x0 >> 70) && 1u), p2); }
                            g1 += (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(0x10000u | 6u));
                            h1 = (unsigned short)(h1 + (p0 >> (r0.y & 31u)));
                            if ((unsigned)((short)m0 > (signed char)(unsigned)c1)) break;
                            u0 = (unsigned)(((unsigned)c0 | (unsigned)((unsigned)s1 == i0)) || (u1 & 0xffffffffu));
                        }
                        if ((6u ? a0[i0 & 3u] : m0)) goto L4;
                    }
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)b0) break;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)s1, p2, (0x80000000u | 8u)); }
                    }
                }
                if ((unsigned)l0) goto L0;
                break; (void)((unsigned)(unsigned char)((unsigned)(0x3322377au < 0x80000000u) / (u0 | 1u)));
            }
            h0 = (short)i0;
            s0 = (int)(u1 * (u0 % ((1u % (g1 | 1u)) | 1u)));
        } while (i0++ < 7u && ~(unsigned)((short)0xffffffffu > (signed char)i1));
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)f0, 0x16c1a3ddu, (unsigned)((unsigned)(m0 && u1) && i0)); }
        if ((garr[i1 & 7u] ^ (8u % ((unsigned)f0 | 1u)))) goto done;
    } else {
        e0 = e0 * 0.5L + (long double)((unsigned)(u3 == (unsigned)(x0 >> 70)) & 1023u);
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(((0x7fffffffu ^ v0) / ((unsigned)w0 | 1u)));
            s0 = (int)i0;
            u3 ^= 1u;
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return ~(((r0.y / (0x5a627660u | 1u)) ^ u0) + *q0);
                r0.y ^= (7u ? a0[u1 & 3u] : *mp);
                f0 = f0 * 0.5f + (float)(u1 & 255u);
                u1 = u1 * 0x9e3779b1u + (fuel & (unsigned)!(unsigned)(((unsigned)c1 + 0x9ffbf337u) < 0u));
                s0 = (int)(unsigned)(-(unsigned)((int)(unsigned)c0 >= (int)((unsigned)f0 / ((unsigned)e0 | 1u))) == (p0 ^ g0));
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((v0 << (((unsigned)c0 >> ((unsigned)c0 & 31u)) & 31u)), (0x80c6349au << ((unsigned)w0 & 31u)), (unsigned)((0xffffffffu & (unsigned)c0) < 0xd4750194u)); }
        }
    }
    r0.x = ((unsigned)e0 + (unsigned)(x0 >> 70));
    if (garr[i1 & 7u]) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((fuel + 0xd3bd2ae5u) || a0[i0 & 3u]), (unsigned)(unsigned char)(unsigned)((unsigned)(x0 >> 70) || u3), 0xda134468u); }
    }
    c0 = (unsigned char)(unsigned)(w0 >> 29);
    g1 += (unsigned)((a0[i0 & 3u] ? (unsigned)l0 : g1) == i1);
    r0.x = (unsigned)(unsigned char)(unsigned)((short)(unsigned)h0 > (signed char)a0[i0 & 3u]);
    goto L0;
    goto L2;
    v0 = (unsigned)((short)(unsigned)((int)a0[u1 & 3u] >= (int)u3) > (signed char)i0);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    a0[m0 & 3u] = (unsigned)(signed char)((unsigned)((int)((unsigned)e0 ^ u1) < (int)(0xffffffffu | fuel)) + garr[i1 & 7u]);
    if (budget != 0u) { budget -= 1u; u1 = fn1(((i0 ^ u3) | (unsigned)h0), 0x80000000u, (unsigned)s0); }
    { unsigned t0; double z0; if (((unsigned)s1) & 1u) { t0 = 3u; z0 = (double)((((unsigned)e0 % (0x10000u | 1u))) & 255u); } if (((unsigned)s1) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)!(unsigned)((short)r0.x > (signed char)(m0 >> (0x15293971u & 31u))) & 7u) {
                { unsigned t1; double z1; if (((0u << (p1 & 31u))) & 1u) { t1 = (unsigned)s1; z1 = (double)((r0.x) & 255u); } if (((0u << (p1 & 31u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(r0.x << ((unsigned)(x0 >> 70) & 31u)), (unsigned)f0, (unsigned)h0); }
                    for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        for (;;) { if (--fuel == 0u) goto done;
                            continue; (void)((unsigned)(short)(g0 - ((unsigned)h0 - 0xe94ec671u)));
                            g0 = 0x80000000u;
                            if ((u1 + g0)) goto L2;
                            case 0u: ;
                            s1 = (int)((unsigned)s1 + (0xbe87bb0eu % ((i0 + (p2 >> (((unsigned)h0 & r0.y) & 31u))) | 1u)));
                        }
                        if ((m0 >> (0xffffffffu & 31u))) break;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((int)(unsigned)c1 < (int)0x7fffffffu) - a0[u1 & 3u]), (unsigned)e0, (unsigned)((unsigned)l0 && fuel)); }
                        r0.x = (unsigned)((int)(a0[i0 & 3u] | (-((unsigned)f0 % (0x7fffffffu | 1u)) - 2u)) >= (int)u2);
                    }
                    garr[(unsigned)h0 & 7u] = (unsigned)((short)(unsigned)s1 > (signed char)(r0.y / (i0 | 1u)));
                    L0: if (--fuel == 0u) goto done;
                    { unsigned t2; double z2; if (((unsigned)(g1 < (unsigned)f0)) & 1u) { t2 = a0[u1 & 3u]; z2 = (double)((fuel) & 255u); } if (((unsigned)(g1 < (unsigned)f0)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                        g0 = (unsigned)((unsigned)s0 || (g1 << ((unsigned)(x0 >> 70) & 31u)));
                        case 7u: ;
                        u1 ^= (unsigned)((int)(unsigned)!(unsigned)((int)p1 < (int)(p0 % ((unsigned)x0 | 1u))) < (int)(unsigned)(x0 >> 70));
                        u1 += ((unsigned)(i1 == (unsigned)((int)v0 >= (int)(m0 ^ (unsigned)w0))) >> (4u & 31u));
                    }
                    case 3u: ;
                }
                if (0xffffffffu) goto L2;
                case 1u: ;
            }
        }
        u3 ^= (unsigned)(8u && (unsigned)x0);
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 = (unsigned)(0xb3e55b66u && (unsigned)((int)7u < (int)0x80000000u));
            q0 = &garr[(unsigned)(garr[i1 & 7u] == (1u / (0x32b0ea82u | 1u))) & 7u];
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(signed char)(unsigned)(u0 < (unsigned)l0), (p2 - ((unsigned)e0 >> ((unsigned)f0 & 31u))), (unsigned)(p2 == i0)); }
            w0 ^= (unsigned long long)(p0 >> (1u & 31u)) << ((9u + (unsigned)c1) & 63u);
        }
    }
    u0 = u0 * 0x9e3779b1u + ((m0 % (a0[i0 & 3u] | 1u)) ? *mp : p2);
    L1: if (--fuel == 0u) goto done;
    L2: if (--fuel == 0u) goto done;
    if ((v0 / (0xd3248470u | 1u))) {
        w0 ^= (unsigned long long)(p1 ^ 6u) << (((0x80000000u / ((unsigned)(r0.y || (unsigned)c1) | 1u)) & (unsigned)((int)(unsigned)c0 < (int)(unsigned)c0)) & 63u);
        l0 = (long)((unsigned long)l0 + ~(unsigned)((int)((0x10000u + 2u) * a0[i0 & 3u]) < (int)0x482e6d13u));
        if ((u0 * (unsigned)(u0 == m0))) {
            x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)(0x80000000u % (((unsigned)(x0 >> 70) ? v0 : u1) | 1u));
            e0 = e0 * 0.5L + (long double)(((0x56afad19u & (unsigned)w0) ? (1u & a0[i0 & 3u]) : (unsigned)s0) & 1023u);
            while (i0++ < 6u && *q0) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                    u2 = u2 * 0x9e3779b1u + (u2 & (6u ? *mp : r0.x));
                    s1 = (int)((unsigned)s1 + 0x7de23880u);
                }
                *q0 += 1u;
            }
        } else {
            if (fuel) goto L2;
            v0 = (unsigned)((int)(0x20de5c5cu | (0x7fffffffu - (unsigned)((unsigned)h1 && u3))) >= (int)i1);
            if (budget != 0u) { budget -= 1u; u0 = fn1(0xed4a5afeu, g1, ((unsigned)((short)0xbb093feau > (signed char)(unsigned)w0) % (i2 | 1u))); }
            l0 = (long)((unsigned long)l0 + (unsigned)!(~((a0[i0 & 3u] * (unsigned)h1) >> (0x10000u & 31u)) << (p1 & 31u)));
        }
        s0 = (int)(unsigned)(((2u * 0xffffffffu) | 0x7fffffffu) < (r0.x & a0[i0 & 3u]));
    }
    goto L1;
    if ((unsigned)d0) {
        garr[r0.y & 7u] = (unsigned)(x0 >> 70);
        if ((*q0 ^ i0)) goto L2;
        u1 += (unsigned)s1;
        w0 = w0 * 6364136223846793005ull + (unsigned)(((unsigned)((unsigned)(x0 >> 70) == (unsigned)((int)0xedf36359u < (int)0x6db90fccu)) % (g0 | 1u)) && 0xfe275f50u);
        if (((unsigned)!(0x7fffffffu ^ 5u) << (garr[u2 & 7u] & 31u))) {
            *q0 = ((unsigned)d0 & (unsigned)((int)0x9e74d629u >= (int)(unsigned)((unsigned)f0 || (unsigned)(x0 >> 70))));
            if ((unsigned)!((1u + u3) | v0)) goto L0;
            goto L1;
            if ((*q0 % (p2 | 1u))) goto L4;
            q0 = &garr[(0x10000u ? (unsigned)x0 : 0xae1c9c98u) & 7u];
        } else {
            goto L1;
        }
        if (((unsigned)s1 / (0xe7b89719u | 1u))) {
            { unsigned t3; double z3; if ((0u) & 1u) { t3 = (unsigned)(0x80000000u || (unsigned)s1); z3 = (double)(((unsigned)(*q0 && 0xe1d9007du)) & 255u); } if ((0u) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                { unsigned t4; double z4; if ((0x80000000u) & 1u) { t4 = ~(unsigned)((unsigned)f0 < (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)h0)); z4 = (double)((garr[i1 & 7u]) & 255u); } if ((0x80000000u) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)((unsigned)e0 && ~((unsigned)w0 >> (fuel & 31u))) || g1) & 1023u);
                    i0 = (unsigned)f0 & 15u;
                    garr[(p0 + 0x10000u) & 7u] = ((0x80000000u % (garr[i1 & 7u] | 1u)) / ((unsigned)!((u0 >> (garr[u2 & 7u] & 31u)) >> (0u & 31u)) | 1u));
                    L4: if (--fuel == 0u) goto done;
                }
                c1 = (signed char)(((unsigned)x0 ^ (i2 % (a0[u1 & 3u] | 1u))) % ((unsigned)((short)(unsigned)s0 > (signed char)i0) | 1u));
                do { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + 0xffffffffu);
                    f0 = f0 * 0.5f + (float)((unsigned)((int)-(((unsigned)d0 - g1) % (fuel | 1u)) >= (int)(unsigned)l0) & 255u);
                    w0 ^= (unsigned long long)u0 << (((unsigned)w0 & (unsigned)!(unsigned)(g0 && (unsigned)c1)) & 63u);
                    if ((*q0 - garr[u2 & 7u])) continue;
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)(((a0[i0 & 3u] / (0x80000000u | 1u)) | 0xd8e99083u));
                    }
                    u0 = (0x80000000u << ((*mp % ((0xffffffffu / ((i1 * (unsigned)e0) | 1u)) | 1u)) & 31u));
                } while (i0++ < 6u && v0);
            }
            switch (((unsigned)f0 / (fuel | 1u)) & 7u) {
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((unsigned)(i1 < (m0 + (unsigned)w0)) & 1023u);
                    h1 = (unsigned short)(h1 + 0x87615542u);
                }
                u0 = ((v0 - a0[u1 & 3u]) & (unsigned)l0);
                u1 ^= (unsigned)((unsigned)(signed char)((unsigned)s0 % (((unsigned)f0 >> (0xffffffffu & 31u)) | 1u)) < ((unsigned)s1 % (g1 | 1u)));
                *mp = (unsigned)((unsigned)((int)((unsigned)d0 + (unsigned)w0) < (int)((unsigned)c1 | (unsigned)d0)) == u0);
                case 3u: ;
            }
            if (u3) goto L3;
            c0 = (unsigned char)(*mp / ((unsigned)s0 | 1u));
            v0 = ((8u & (unsigned)x0) & 0xffffffffu);
        }
    } else {
        switch ((p1 << (0xf05120a6u & 31u)) & 7u) {
            g0 = ((0x10000u >> ((unsigned)d0 & 31u)) - (unsigned)(signed char)((a0[u1 & 3u] - r0.x) & u1));
            if ((unsigned)((int)0xffffffffu >= (int)garr[u2 & 7u])) break;
            if (~(4u << (i2 & 31u))) {
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        garr[((unsigned)h0 >> (0xad67691eu & 31u)) & 7u] = v0;
                        a0[(unsigned)e0 & 3u] = (unsigned)s0;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)h1, ((garr[u2 & 7u] ^ garr[i1 & 7u]) | (unsigned)c1), (unsigned)(p0 && 0x899f9ed1u)); }
                        r0.y ^= -(0x7fffffffu % ((unsigned)b0 | 1u));
                        if ((0x308c9676u & r0.y)) goto L2;
                        for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                            r0.x = p1;
                            if (budget != 0u) { budget -= 1u; u3 = fn0((0x2e7c33a2u ? (unsigned)s1 : 0x7fffffffu), ((unsigned)(w0 >> 29) | (unsigned)l0), (unsigned)(p0 == (unsigned)((short)(unsigned)c1 > (signed char)(unsigned)e0))); }
                            case 0u: ;
                            d0 = d0 * 0.5 + (double)(((unsigned)(0x42ccde0fu == (unsigned)h0) ? (unsigned)f0 : (unsigned)c1) & 1023u);
                        }
                    }
                    { unsigned t5; double z5; if (((u2 % ((unsigned)h1 | 1u))) & 1u) { t5 = (unsigned)((unsigned)b0 && (i2 >> ((unsigned)s1 & 31u))); z5 = (double)(((unsigned)(i2 == g0)) & 255u); } if (((u2 % ((unsigned)h1 | 1u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                        g1 += (unsigned)b0;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(unsigned)((int)(unsigned)(x0 >> 70) < (int)1u) > (signed char)*q0), (unsigned)((short)(unsigned)((int)a0[i0 & 3u] < (int)0x47bf1b14u) > (signed char)v0), fuel); }
                    }
                    break; (void)(((unsigned)(signed char)(r0.x >> (a0[u1 & 3u] & 31u)) ^ 0xfa544019u));
                    case 3u: ;
                    if (u2) goto L4;
                }
                garr[(unsigned)(a0[u1 & 3u] < *q0) & 7u] = (unsigned)((int)((unsigned)l0 % (1u | 1u)) >= (int)((unsigned)w0 ? 6u : (unsigned)s1));
                a0[r0.x & 3u] = (p0 ? garr[u2 & 7u] : (unsigned)((short)(unsigned)(g1 < i0) > (signed char)0x20d442c7u));
                if (g0) goto L0;
            } else {
                { unsigned t6; double z6; if (((unsigned)(*q0 && 0x7fffffffu)) & 1u) { t6 = (unsigned)(signed char)((unsigned)((unsigned)f0 || u0) ^ 2u); z6 = (double)((((unsigned)((int)(unsigned)s1 < (int)0x7fffffffu) & 0x89026e1u)) & 255u); } if (((unsigned)(*q0 && 0x7fffffffu)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                    if (budget != 0u) { budget -= 1u; u2 = fn0(r0.y, ((unsigned)c0 / (i1 | 1u)), (unsigned)(unsigned char)((i2 | 7u) + v0)); }
                    *mp = ((unsigned)b0 << (*mp & 31u));
                    h1 = (unsigned short)(h1 + (9u | (unsigned)(unsigned char)(unsigned)((r0.y - 0xc9d20d12u) && p2)));
                }
                d0 = d0 * 0.5 + (double)(((unsigned)x0 ? (unsigned)((int)0x7fffffffu >= (int)0xec217340u) : 7u) & 1023u);
            }
            default: ;
            h1 = (unsigned short)(h1 + (0x80000000u ^ (unsigned)w0));
        }
        do { if (--fuel == 0u) goto done;
            if (r0.y) break;
        } while (i0++ < 7u && ((0xffffffffu - garr[i1 & 7u]) + p0));
    }
    if (*q0) {
        u3 ^= (unsigned)(short)(a0[u1 & 3u] ? u0 : 0x41895c88u);
        if (fuel < 8u) return (unsigned)(i2 && (unsigned)w0);
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)(((unsigned)d0 | ~(unsigned)((short)(unsigned)b0 > (signed char)7u)) << (u0 & 31u)) < (int)(unsigned)d0);
        u0 = (a0[u1 & 3u] * *q0);
    }
    while (i0++ < 4u && i0) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            q0 = &garr[((unsigned)b0 % (((unsigned)h1 % (garr[i1 & 7u] | 1u)) | 1u)) & 7u];
            if ((r0.y | 0x77675cebu)) break;
        }
        h0 = (short)(unsigned)(signed char)((unsigned)(w0 >> 29) | p2);
        if ((unsigned)h1) break;
        if (6u) {
            if ((unsigned)(w0 >> 29)) goto L4;
            if (budget != 0u) { budget -= 1u; u2 = fn1(4u, ((unsigned)s0 / (*mp | 1u)), ((i0 + i2) >> (u0 & 31u))); }
            a0[(5u / ((unsigned)h0 | 1u)) & 3u] = ((unsigned)((int)(unsigned)x0 < (int)(unsigned)l0) | 0x5977883eu);
            r0.x = (0xbbdd779du + (u2 & (unsigned)h0));
        } else {
            if (((unsigned)(0x7fffffffu || (unsigned)b0) + (unsigned)h1)) break;
        }
    }
    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((unsigned)((unsigned)h0 || i1) || (unsigned)(w0 >> 29)) && (garr[i1 & 7u] ^ 0xb8154b27u)));
    if (budget != 0u) { budget -= 1u; u0 = fn0(0xcffa23ccu, (u0 - 4u), (u3 % (i0 | 1u))); }
    { unsigned t7; double z7; if (((0x80000000u % ((unsigned)x0 | 1u))) & 1u) { t7 = (unsigned)(unsigned char)(0xce47ed6au | 0xab61a82eu); z7 = (double)(((unsigned)e0) & 255u); } if (((0x80000000u % ((unsigned)x0 | 1u))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
        d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)((unsigned)c1 == 0x7fffffffu) < (int)1u) & 1023u);
        goto L2;
        if (budget != 0u) { budget -= 1u; u3 = fn0(i2, ((unsigned)h1 - 0xffffffffu), (*q0 + 0xcdaef101u)); }
        for (;;) { if (--fuel == 0u) goto done;
            if (((unsigned)((int)3u >= (int)9u) - (unsigned)x0)) break;
            c1 = (signed char)(unsigned)(w0 >> 29);
            w0 ^= (unsigned long long)(unsigned)(u2 == u2) << ((unsigned)((int)((unsigned)l0 << ((unsigned)(unsigned char)(p0 * g0) & 31u)) < (int)(unsigned)(0u && (unsigned)s1)) & 63u);
        }
        goto L0;
        while (*mp) { if (--fuel == 0u) goto done;
            u0 += (u0 ? (p1 + i0) : (9u + u3));
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((p1 + (unsigned)w0), -(*q0 * (unsigned)w0), (u1 & 0x80000000u)); }
    while (i0++ < 3u && 0xf726aed5u) { if (--fuel == 0u) goto done;
        if (g1) {
            g1 += ((unsigned)(w0 >> 29) % ((unsigned)((garr[u2 & 7u] & fuel) || (unsigned)e0) | 1u));
        }
        c0 = (unsigned char)(3u % (i0 | 1u));
        if ((unsigned)(r0.y || (unsigned)((int)(unsigned)d0 >= (int)g1))) continue;
    }
    goto L0;
    u3 = u3 * 0x9e3779b1u + (u0 % ((p2 ^ (unsigned)h0) | 1u));
    if (i1) goto L3;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0(0xffffffffu, (unsigned)((unsigned)b0 || (unsigned)h1), ~(unsigned)((int)0x7fffffffu < (int)6u)); }
        if (budget != 0u) { budget -= 1u; u2 = fn1(i2, ((unsigned)d0 & (unsigned)((int)(unsigned)e0 < (int)0xffffffffu)), (unsigned)s1); }
        if ((0x4c772992u ^ (unsigned)h1)) break;
        if ((0xacffa3a3u % (p2 | 1u))) goto L0;
        if ((unsigned)(garr[i1 & 7u] < g1)) continue;
        goto L3;
    }
    f0 = f0 * 0.5f + (float)(((unsigned)b0 / ((unsigned)(signed char)((unsigned)f0 * garr[u2 & 7u]) | 1u)) & 255u);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            u2 += (unsigned)((short)(*q0 | (unsigned)w0) > (signed char)u1);
            x0 = x0 * 0x100000001b3ull + i2;
        } while (i1++ < 4u && (unsigned)((unsigned)(x0 >> 70) && 4u));
        *q0 += a0[i0 & 3u];
    }
    a0[(0xf832f086u + v0) & 3u] = ((unsigned)((short)g0 > (signed char)(unsigned)((int)(unsigned)e0 >= (int)(unsigned)e0)) / ((unsigned)d0 | 1u));
    e0 = e0 * 0.5L + (long double)((*mp ? u2 : 0x7fffffffu) & 1023u);
    if (u3 == 7u) return ((unsigned)w0 % (p0 | 1u));
    goto L1;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0xffffffffu) break;
        if (((unsigned)b0 & (unsigned)w0)) break;
        d0 = d0 * 0.5 + (double)((u2 % (((unsigned)w0 - (unsigned)(x0 >> 70)) | 1u)) & 1023u);
        do { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (i1 % (((unsigned)h0 & i0) | 1u)));
            if (budget != 0u) { budget -= 1u; u2 = fn1(0x10000u, 0x49b09171u, ((unsigned)((unsigned)s1 < r0.x) >> (m0 & 31u))); }
            r0.y ^= (unsigned)((0x7019d56du + ((unsigned)e0 ^ 0xf43a9095u)) == 0xffffffffu);
            if (((unsigned)c1 & i0)) {
                continue; (void)((u2 ^ g0));
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(8u && (unsigned)((short)fuel > (signed char)u0)), (0x80000000u | m0), m0); }
            } else {
                if ((9u ^ r0.y)) {
                    x0 = x0 * 0x100000001b3ull + 0xbecaac2bu;
                    d0 = d0 * 0.5 + (double)((unsigned)(signed char)(unsigned)(~(unsigned)(0u < (unsigned)(x0 >> 70)) && ((0x7fffffffu / (4u | 1u)) * *mp)) & 1023u);
                    e0 = e0 * 0.5L + (long double)(((unsigned)f0 % ((unsigned)!(((unsigned)h1 * g1) & 0u) | 1u)) & 1023u);
                    if (((unsigned)l0 + u1)) break;
                    c1 = (signed char)(unsigned)!((unsigned)h0 + u1);
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0(~((unsigned)((int)0x68d6da6eu >= (int)i2) * (unsigned)b0), (i1 * (unsigned)(p0 || (unsigned)x0)), 0xea7b24c9u); }
                if (u3) break;
            }
            g1 += a0[u1 & 3u];
        } while (i1++ < 7u && (unsigned)((int)(unsigned)(1u || (unsigned)(w0 >> 29)) < (int)0x7ec79dc2u));
        for (;;) { if (--fuel == 0u) goto done;
            u3 = (g1 ? (unsigned)h0 : 7u);
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)((short)i1 > (signed char)0x314ab2e2u) >= (int)8u), (u1 % ((unsigned)(short)(unsigned)(8u && 0u) | 1u)), r0.x); }
    }
    if ((*mp + p2)) goto L0;
    l0 = (long)((unsigned long)l0 + i0);
    for (;;) { if (--fuel == 0u) goto done;
        r0.y ^= ((unsigned)s1 * (unsigned)f0);
        if (i2) goto L4;
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)0u > (signed char)(p2 >> ((unsigned)b0 & 31u))), ((unsigned)(0u && i0) << (m0 & 31u)), (0x80000000u & (unsigned)((unsigned)b0 == 0x4ef156cbu))); }
        if ((unsigned)((unsigned)(w0 >> 29) || 0x80000000u)) {
            u1 = u1 * 0x9e3779b1u + (unsigned)(0x5e3a1dc6u || (unsigned)((int)3u < (int)v0));
        } else {
            if ((unsigned)(0x58cd6078u && a0[i0 & 3u])) break;
            if ((u2 * (unsigned)((int)fuel < (int)9u))) {
                if (fuel < 8u) return (p1 - p0);
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (((unsigned)h1 / (1u | 1u)) - 6u);
                    break; (void)((unsigned)(((unsigned)d0 - 0x10000u) < p1));
                    if (budget != 0u) { budget -= 1u; u1 = fn1((0x2d44f252u + 0x489d80abu), (unsigned)((int)0x68030a70u < (int)(unsigned)b0), (unsigned)(0xe604709au && 0x80000000u)); }
                    i0 = m0 & 15u;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)(unsigned)h1 > (signed char)*q0), (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)c1), (unsigned)(signed char)(0x3a6c697du << (6u & 31u))); }
                }
                *mp = (a0[i0 & 3u] & *q0);
                break; (void)((((unsigned)l0 | *q0) ^ 1u));
                f0 = f0 * 0.5f + (float)((unsigned)(short)((unsigned)((unsigned)((int)(unsigned)b0 < (int)0xb2f239deu) < fuel) + 0x7fffffffu) & 255u);
            } else {
                e0 = e0 * 0.5L + (long double)((unsigned)((int)0x44e3e2a5u < (int)g1) & 1023u);
            }
        }
        { unsigned t8; double z8; if (((unsigned)((short)(unsigned)h1 > (signed char)r0.y)) & 1u) { t8 = 0xb81bf724u; z8 = (double)((garr[i1 & 7u]) & 255u); } if (((unsigned)((short)(unsigned)h1 > (signed char)r0.y)) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
            u3 = (unsigned)c1;
            s1 = (int)((unsigned)s1 + (unsigned)((short)0xee5e0794u > (signed char)u0));
            do { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (((unsigned)f0 % ((unsigned)!(unsigned)(u1 < (unsigned)d0) | 1u)) % ((0x971f968cu & 4u) | 1u));
            } while (i1++ < 2u && (5u * u1));
        }
        if ((v0 * (unsigned)c1)) {
            m0 ^= (unsigned)x0;
        } else {
            f0 = f0 * 0.5f + (float)((unsigned)!((fuel ? u1 : p0) | u0) & 255u);
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((*q0 - (unsigned)((unsigned)f0 && r0.y))) break;
                if (2u) break;
                do { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(unsigned)(i0 == (unsigned)b0);
                    goto L0;
                } while (i2++ < 7u && (a0[u1 & 3u] << (0u & 31u)));
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn1(u3, ((unsigned)((int)p0 >= (int)*mp) >> (r0.x & 31u)), ~(g0 << ((0x8cec26e2u << (0u & 31u)) & 31u))); }
                    break; (void)((unsigned)(fuel && (unsigned)w0));
                    m0 ^= ((unsigned)(fuel && 0x1a35af21u) % ((unsigned)w0 | 1u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!((unsigned)(short)(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)e0) & *mp), 0x34618840u, 0x2d257ae2u); }
                }
                s0 = (int)(unsigned)((short)i1 > (signed char)((0x7fffffffu + g0) % (((unsigned)w0 << ((unsigned)s0 & 31u)) | 1u)));
                if ((unsigned)(0x6f5e2e90u < r0.y)) goto L3;
            }
            if ((3u * 0xffffffffu)) break;
        }
    }
    while (i0++ < 7u && (p1 >> (p1 & 31u))) { if (--fuel == 0u) goto done;
        r0.x = (unsigned)((short)0x2f85a901u > (signed char)(0u % ((unsigned)(x0 >> 70) | 1u)));
    }
    q0 = &garr[-(*mp << ((*mp / ((unsigned)(r0.y < u1) | 1u)) & 31u)) & 7u];
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)(r0.x && (unsigned)((int)(unsigned)l0 < (int)(unsigned)(short)((unsigned)c0 % ((garr[i1 & 7u] | r0.y) | 1u))));
            break; (void)(((unsigned)((int)0x757061f2u >= (int)(unsigned)d0) / (i2 | 1u)));
            if (1u) {
                if ((g0 * garr[u2 & 7u])) break;
                c0 = (unsigned char)(unsigned)(unsigned char)(unsigned)((u2 << (0xe103b9acu & 31u)) < (0x10000u ? (unsigned)h0 : (unsigned)e0));
                break; (void)((unsigned)((int)(unsigned)x0 >= (int)garr[u2 & 7u]));
                if ((unsigned)(short)(unsigned)((0x10000u >> (r0.y & 31u)) < g0)) break;
                if (g0) break;
            }
        }
        u1 ^= ((u0 ^ (unsigned)h0) / (5u | 1u));
        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)h0 < (unsigned)!(unsigned)(garr[i1 & 7u] && g0)) & 1023u);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    r0.x = (unsigned)(m0 == -(*mp + (unsigned)(x0 >> 70)));
    v0 = (unsigned)w0;
    m0 ^= (unsigned)((int)a0[u1 & 3u] >= (int)(g1 % ((m0 & p0) | 1u)));
    f0 = f0 * 0.5f + (float)(((unsigned)(0x80000000u || i2) * (((unsigned)d0 / ((unsigned)(w0 >> 29) | 1u)) >> ((unsigned)l0 & 31u))) & 255u);
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)d0 | (0x80000000u * 0x80000000u))) break;
        if (0x80000000u) goto L1;
        f0 = f0 * 0.5f + (float)(((unsigned)d0 / ((unsigned)((unsigned)(w0 >> 29) && (unsigned)((unsigned)h0 && p2)) | 1u)) & 255u);
        e0 = e0 * 0.5L + (long double)(((unsigned)((short)-((unsigned)l0 << ((unsigned)(x0 >> 70) & 31u)) > (signed char)(unsigned)((unsigned)w0 == i2)) - i0) & 1023u);
        if (u3) goto L2;
        if ((unsigned)((int)0x48fe5f46u < (int)(i2 * i1))) goto L3;
    }
    garr[*mp & 7u] = 0xffffffffu;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (g0) {
            r0.x = (unsigned)((short)((unsigned)(x0 >> 70) & 5u) > (signed char)(unsigned)(u0 < (unsigned)c0));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1((i0 % (0x7fffffffu | 1u)), (fuel & (unsigned)((int)(unsigned)d0 < (int)(unsigned)(x0 >> 70))), a0[i0 & 3u]); }
        *q0 = (unsigned)d0;
    }
    i0 = 0x80000000u & 15u;
    if (budget != 0u) { budget -= 1u; u0 = fn2(p2, (unsigned)(u1 == (unsigned)s1), (unsigned)(*mp == garr[u2 & 7u])); }
    *mp = ((unsigned)((int)(unsigned)(g1 == (p0 - u3)) >= (int)5u) + (unsigned)c0);
    if (budget != 0u) { budget -= 1u; u2 = fn0(u3, 0x7fffffffu, ((unsigned)((short)fuel > (signed char)g0) - 3u)); }
    switch (r0.x & 7u) {
        if (((unsigned)x0 - (unsigned)l0)) {
            g0 = (unsigned)(x0 >> 70);
            w0 ^= (unsigned long long)(i1 >> (1u & 31u)) << (((3u ^ (unsigned)((int)0xffffffffu >= (int)v0)) / (0xffffffffu | 1u)) & 63u);
            if (budget != 0u) { budget -= 1u; u3 = fn0(0x80000000u, ~(unsigned)((short)u3 > (signed char)-(0xffffffffu * *q0)), (p2 & (unsigned)f0)); }
            if ((unsigned)(signed char)(unsigned)((int)a0[u1 & 3u] >= (int)r0.y)) {
                if (~(u2 % (0x10000u | 1u))) goto L0;
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    case 4u: ;
                    r0.y ^= (unsigned)((int)u3 >= (int)(unsigned)((short)(g0 ? 0x7fffffffu : 0x7743cc97u) > (signed char)(unsigned)(x0 >> 70)));
                    garr[0x231d62c1u & 7u] = (unsigned)(0x7fffffffu == m0);
                }
                case 1u: ;
            } else {
                u0 = (unsigned)((unsigned)s1 == (0x10000u * p0));
                if (u3 == 7u) return ~(p1 / ((unsigned)(short)((unsigned)e0 << ((0x80000000u >> ((unsigned)d0 & 31u)) & 31u)) | 1u));
            }
            f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)(w0 >> 29) & ((unsigned)s1 * 3u)) == 0u) & 255u);
        }
        do { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + ~(unsigned)((int)(unsigned)((int)0x80000000u >= (int)r0.y) >= (int)(unsigned)(*q0 && 0xc131c6f9u));
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)(0xf8e2bdb6u || (unsigned)s1) || 0x7fffffffu), a0[u1 & 3u], (3u + 0x7fffffffu)); }
            r0.y ^= ((unsigned)((int)u1 >= (int)m0) * (unsigned)e0);
            garr[(0xffffffffu * (unsigned)f0) & 7u] = (unsigned)e0;
            v0 = ((unsigned)e0 ? (unsigned)b0 : (0x7e9162c8u % (0xffffffffu | 1u)));
        } while (i0++ < 7u && (p0 & 0x65191180u));
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                g0 = (unsigned)!((0xed87d06eu & ((unsigned)(signed char)(a0[u1 & 3u] * 0x5298ab20u) ^ (unsigned)e0)) * (unsigned)h1);
                if (budget != 0u) { budget -= 1u; u1 = fn0((3u - (unsigned)w0), (unsigned)((short)(0xffffffffu & i1) > (signed char)8u), (unsigned)(unsigned char)(unsigned)(i0 == (r0.y | 2u))); }
                case 0u: ;
            } while (i1++ < 4u && (unsigned)((int)4u >= (int)r0.x));
            if (u2) {
                default: ;
            }
            L0: if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
            *q0 = 0xffffffffu;
            u2 = (((unsigned)x0 ^ r0.y) >> (p1 & 31u));
        } while (i0++ < 7u && p0);
        if (((unsigned)(0x80000000u && fuel) | g1)) {
            goto L4;
            u1 ^= 0x10000u;
            L2: if (--fuel == 0u) goto done;
            if (fuel < 8u) return (*q0 ^ (unsigned)c0);
        }
    }
    if ((m0 - (unsigned)e0)) {
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (((0x276dc672u | *q0) - p1) ^ (unsigned)s0);
            if ((i2 ^ (unsigned)(2u || 0xffffffffu))) {
                switch ((unsigned)!((unsigned)x0 | 5u) & 7u) {
                    while ((unsigned)((short)u3 > (signed char)(unsigned)w0)) { if (--fuel == 0u) goto done;
                        g1 += (unsigned)(short)((0xffffffffu * 6u) ^ (unsigned)e0);
                        r0.x = ((unsigned)l0 + ((unsigned)(u2 || garr[u2 & 7u]) - m0));
                        if ((i2 ^ (u1 / (i0 | 1u)))) break;
                        s0 = (int)(((unsigned)x0 - 8u) ^ (unsigned)(-(0x80000000u ^ r0.x) || *q0));
                    }
                    L4: if (--fuel == 0u) goto done;
                    { unsigned t0; double z0; if (((unsigned)(unsigned char)(r0.x - (unsigned)d0)) & 1u) { t0 = (unsigned)f0; z0 = (double)(((0xffffffffu << ((unsigned)(*mp || p0) & 31u))) & 255u); } if (((unsigned)(unsigned char)(r0.x - (unsigned)d0)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                        if (budget != 0u) { budget -= 1u; u1 = fn0((0xf44cf55cu >> ((m0 * (unsigned)x0) & 31u)), (unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)(x0 >> 70)), (unsigned)c1); }
                        r0.x = (unsigned)(signed char)((unsigned)(((unsigned)h1 & u0) || garr[i1 & 7u]) / (u2 | 1u));
                        *q0 = ((u3 + 6u) ^ 0xa3c822e0u);
                        continue; (void)((unsigned)(r0.x && u1));
                        if ((((unsigned)f0 & (unsigned)c1) % ((unsigned)w0 | 1u))) {
                            case 3u: ;
                            x0 = x0 * 0x100000001b3ull + u3;
                            if (0xe815d988u) continue;
                            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)b0, ((unsigned)(u3 == u3) << (i1 & 31u)), (unsigned)s0); }
                            l0 = (long)((unsigned long)l0 + ((*q0 + (unsigned)(x0 >> 70)) - garr[u2 & 7u]));
                            default: ;
                        } else {
                            if ((unsigned)x0) goto L0;
                            if (((unsigned)d0 | ((unsigned)(w0 >> 29) % (0x74d7893du | 1u)))) goto L4;
                            w0 ^= (unsigned long long)i1 << (((unsigned)(signed char)(unsigned)((int)a0[i0 & 3u] >= (int)((unsigned)h1 << ((unsigned)h1 & 31u))) / ((0x7fffffffu << (0x3ca12ea8u & 31u)) | 1u)) & 63u);
                        }
                    }
                    h1 = (unsigned short)(h1 + (unsigned)!((garr[u2 & 7u] * i0) % (fuel | 1u)));
                    case 1u: ;
                    v0 = (unsigned)x0;
                }
                u1 += (unsigned)((unsigned)((unsigned)((unsigned)((int)fuel < (int)3u) < (unsigned)(x0 >> 70)) == g0) && (unsigned)(w0 >> 29));
                while (i1++ < 6u && r0.x) { if (--fuel == 0u) goto done;
                    switch ((unsigned)((short)r0.y > (signed char)u2) & 7u) {
                        case 2u: ;
                        if ((unsigned)((unsigned)(x0 >> 70) == (unsigned)!(unsigned)((unsigned)w0 == 0x10000u))) break;
                    }
                }
                if ((p2 / (4u | 1u))) break;
                break; (void)((unsigned)((int)v0 < (int)(6u - r0.y)));
                if (a0[i0 & 3u]) break;
            } else {
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((short)u3 > (signed char)(unsigned)x0), *mp, (unsigned)(unsigned char)(0x736ca902u << ((0xd20ab1dcu + v0) & 31u))); }
            }
            switch (*q0 & 7u) {
                { unsigned t1; double z1; if (((unsigned)(unsigned char)(garr[i1 & 7u] / ((unsigned)(garr[u2 & 7u] < 8u) | 1u))) & 1u) { t1 = ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x80000000u) + 4u); z1 = (double)(((garr[u2 & 7u] >> (((unsigned)h1 >> (i2 & 31u)) & 31u))) & 255u); } if (((unsigned)(unsigned char)(garr[i1 & 7u] / ((unsigned)(garr[u2 & 7u] < 8u) | 1u))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    g1 += (((unsigned)(short)(*q0 / (((unsigned)x0 << (fuel & 31u)) | 1u)) >> (0x94e995a9u & 31u)) ^ *mp);
                    case 1u: ;
                    if (budget != 0u) { budget -= 1u; u0 = fn2((8u << ((unsigned)(u0 || 9u) & 31u)), (0x1c2ad573u << ((6u & (unsigned)f0) & 31u)), (*mp * u1)); }
                }
                break; (void)((unsigned)!((unsigned)((unsigned)s0 < 0x7fffffffu) | (unsigned)(x0 >> 70)));
                case 6u: ;
                if ((0x7fffffffu >> (((unsigned)b0 % (a0[i0 & 3u] | 1u)) & 31u))) continue;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)l0, 9u, ((unsigned)f0 * (unsigned)f0)); }
                do { if (--fuel == 0u) goto done;
                    if (u3) break;
                } while (i1++ < 6u && (0xffffffffu | 3u));
            }
            if ((u2 | v0)) continue;
            g1 += (*q0 >> (0xffffffffu & 31u));
        }
    }
    u1 = (unsigned)((short)p2 > (signed char)(m0 << (0xc728a958u & 31u)));
    r0.y ^= fuel;
    if ((unsigned)((unsigned)(u0 < a0[i0 & 3u]) < (unsigned)c1)) goto L3;
    r0.x = (unsigned)((unsigned)(signed char)(unsigned)((int)(unsigned)((int)a0[u1 & 3u] >= (int)(u2 - v0)) < (int)0xffffffffu) && (unsigned)b0);
    if ((unsigned)((int)u2 < (int)(unsigned)(unsigned char)(unsigned)((int)r0.y >= (int)a0[u1 & 3u]))) goto L0;
    if ((u0 >> (((unsigned)c0 ^ 0xccad38abu) & 31u))) goto L3;
    if ((unsigned)(~(garr[u2 & 7u] * (unsigned)x0) < p1)) goto L2;
    if (7u) goto L0;
    if ((0xffffffffu / ((unsigned)((int)0x80000000u < (int)(unsigned)c0) | 1u))) goto L0;
    switch ((unsigned)((unsigned)h1 && (unsigned)((unsigned)x0 == (unsigned)s0)) & 7u) {
        while (i0++ < 3u && (unsigned)e0) { if (--fuel == 0u) goto done;
            u1 = (unsigned)(unsigned char)(unsigned)((int)r0.y < (int)((unsigned)d0 / (garr[u2 & 7u] | 1u)));
            m0 ^= (unsigned)((int)(unsigned)(u1 || 0xffffffffu) < (int)(unsigned)((int)(unsigned)(0x80a30a1au || r0.x) < (int)0xfca76305u));
            *q0 += (unsigned)((int)(garr[u2 & 7u] & i2) >= (int)(m0 >> (r0.y & 31u)));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)(unsigned)(u3 && 0x1492a945u), (3u >> (6u & 31u)), 0x419f9d2au); }
    }
    u1 = u1 * 0x9e3779b1u + -(unsigned)((int)(u3 / ((unsigned)(w0 >> 29) | 1u)) >= (int)(garr[i1 & 7u] & *mp));
    switch ((unsigned)((short)(u0 + r0.x) > (signed char)(unsigned)(x0 >> 70)) & 7u) {
        c0 = (unsigned char)(((unsigned)s1 + (unsigned)c0) / (0u | 1u));
    }
    switch (((garr[u2 & 7u] | u2) | (unsigned)b0) & 7u) {
        do { if (--fuel == 0u) goto done;
            case 7u: ;
            if ((p2 + p2)) {
                u3 ^= (unsigned)((short)(unsigned)(p1 == p0) > (signed char)r0.y);
            } else {
                if (-(unsigned)((int)(unsigned)w0 >= (int)(0x9bd7e9adu % (5u | 1u)))) {
                    if (u0) break;
                    do { if (--fuel == 0u) goto done;
                        case 4u: ;
                        s1 = (int)((unsigned)s1 + (~(unsigned)((short)m0 > (signed char)p2) * (unsigned)((int)fuel >= (int)(unsigned)(0x10000u || 0x6084a68fu))));
                        if (budget != 0u) { budget -= 1u; u2 = fn2(8u, (unsigned)(short)(m0 - (unsigned)l0), (0x9700b137u & (unsigned)c0)); }
                    } while (i1++ < 4u && (unsigned)((short)0xf913c848u > (signed char)0x680ddb23u));
                    if ((unsigned)(short)(unsigned)((int)7u >= (int)(unsigned)(1u || (unsigned)c1))) goto L3;
                    *q0 += (unsigned)(signed char)(unsigned)(*mp && (unsigned)(((unsigned)l0 / (0xffffffffu | 1u)) == 0x7fffffffu));
                    u3 = (u2 / (((unsigned)h1 / (u3 | 1u)) | 1u));
                    case 6u: ;
                } else {
                    h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(5u ^ 6u));
                    q0 = &garr[(unsigned)((unsigned)x0 < ((unsigned)s1 ? 0x7fffffffu : (unsigned)(r0.x == (unsigned)(x0 >> 70)))) & 7u];
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)((int)6u < (int)a0[i0 & 3u]) == m0), (0x864271b3u + (unsigned)((short)*mp > (signed char)i0)), ((u3 * r0.x) << ((unsigned)c0 & 31u))); }
                    s1 = (int)((unsigned)s1 + ~(unsigned)(u2 || (unsigned)(7u && (unsigned)h0)));
                }
                w0 = w0 * 6364136223846793005ull + i0;
            }
            do { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(3u & 1023u);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)!(unsigned)((int)3u < (int)r0.x) && 0x650bdeedu), *q0, (unsigned)(u2 || ~(unsigned)((short)0u > (signed char)u2))); }
                switch (((unsigned)c0 % (p0 | 1u)) & 7u) {
                    if (budget != 0u) { budget -= 1u; u2 = fn2((p1 / (u2 | 1u)), 0xffffffffu, (fuel | ((unsigned)h0 ^ 1u))); }
                }
            } while (i1++ < 6u && 9u);
            if ((*q0 + 0x7fffffffu)) goto L0;
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)c1, u3, (unsigned)((int)((unsigned)f0 << ((unsigned)s0 & 31u)) >= (int)u3)); }
            default: ;
        } while (i0++ < 2u && (0xb1559dbfu + (a0[i0 & 3u] * 2u)));
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (*mp + (unsigned)((unsigned)l0 < (unsigned)c1));
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)(short)((0x9d1864c7u & (unsigned)d0) + (unsigned)((int)p0 >= (int)0x9566bd5u));
        }
        do { if (--fuel == 0u) goto done;
            continue; (void)((r0.y & (unsigned)l0));
            if (((unsigned)((unsigned)h1 && (unsigned)x0) ^ (unsigned)s1)) break;
            break; (void)((unsigned)c0);
            q0 = &garr[i0 & 7u];
        } while (i1++ < 2u && (8u / ((i1 & 4u) | 1u)));
    }
    goto L2;
    if (((unsigned)(i2 && (unsigned)f0) + fuel)) {
        if ((unsigned)((int)0xfcab34f4u < (int)0x293c2b43u)) goto L3;
        *q0 = (i2 << (i2 & 31u));
        if ((unsigned)((short)(unsigned)((int)r0.x >= (int)8u) > (signed char)r0.x)) goto L3;
        do { if (--fuel == 0u) goto done;
            goto done;
        } while (i0++ < 6u && (0x80000000u << ((unsigned)((int)0x2072cda7u < (int)0x10000u) & 31u)));
        goto L3;
        g1 += ((unsigned)((unsigned)(*q0 == (unsigned)w0) && ~(0xffffffffu << ((unsigned)(x0 >> 70) & 31u))) * a0[i0 & 3u]);
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            continue; (void)(a0[i0 & 3u]);
            { unsigned t2; double z2; if (((unsigned)((int)u3 < (int)(unsigned)((int)garr[u2 & 7u] < (int)p2))) & 1u) { t2 = (p0 ^ -(0x55e38faau + 0u)); z2 = (double)((((unsigned)f0 >> ((unsigned)x0 & 31u))) & 255u); } if (((unsigned)((int)u3 < (int)(unsigned)((int)garr[u2 & 7u] < (int)p2))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                if (~(unsigned)((int)(unsigned)h1 < (int)(unsigned)h1)) break;
                if (((unsigned)d0 | (unsigned)(a0[u1 & 3u] || 4u))) break;
                switch ((unsigned)((int)(unsigned)h0 < (int)i1) & 7u) {
                    v0 = ((unsigned)f0 >> ((0xffffffffu * ~((unsigned)(unsigned char)(*mp >> (0x80000000u & 31u)) % (p2 | 1u))) & 31u));
                    case 6u: ;
                    case 0u: ;
                    u1 ^= (unsigned)(garr[u2 & 7u] || (unsigned)w0);
                    default: ;
                }
            }
            if ((0x80000000u - (unsigned)((int)0x4f7a9f72u < (int)u0))) goto L3;
            e0 = e0 * 0.5L + (long double)(((unsigned)l0 - (unsigned)e0) & 1023u);
        } while (i1++ < 7u && (unsigned)(*q0 < (g1 - m0)));
        c1 = (signed char)(unsigned)((short)3u > (signed char)(unsigned)((short)(5u + r0.x) > (signed char)p1));
        if ((unsigned)((short)i2 > (signed char)8u)) goto done;
        c0 = (unsigned char)(unsigned)c0;
        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)w0 & fuel), p0, (6u ^ (unsigned)((unsigned)c1 == fuel))); }
    }
    if ((r0.x ? 0xffffffffu : 0x7fffffffu)) {
        goto done;
        if (m0) {
            h1 = (unsigned short)(h1 + 6u);
        } else {
            u2 = u2 * 0x9e3779b1u + ((unsigned)(0x27951fc0u == (unsigned)c1) + (a0[i0 & 3u] % (u2 | 1u)));
            goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)((u1 << (i0 & 31u)) || (0x7fffffffu << ((unsigned)w0 & 31u))));
        }
    } else {
        goto L2;
        f0 = f0 * 0.5f + (float)((unsigned)f0 & 255u);
        if (((unsigned)s0 / ((u0 >> (u0 & 31u)) | 1u))) {
            if (0x10000u) goto L2;
        } else {
            if ((unsigned)((short)a0[i0 & 3u] > (signed char)(0x7fffffffu >> (p1 & 31u)))) {
                switch (((unsigned)!(unsigned)((unsigned)h0 || g1) * v0) & 7u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(fuel && 0x80000000u), 0x10000u, -((unsigned)(short)(unsigned)((unsigned)c0 || 5u) * v0)); }
                    break; (void)((unsigned)((unsigned)h0 || garr[u2 & 7u]));
                    case 5u: ;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(unsigned)(0xed68d549u && (0x7fffffffu ^ 3u)), (a0[u1 & 3u] % (0xffffffffu | 1u)), ((0xb6b6a150u & i2) >> (0xcb83d800u & 31u))); }
                    if (((unsigned)(x0 >> 70) / (6u | 1u))) {
                        r0.x = fuel;
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(7u ^ 0x3ee3cb48u)), (unsigned)(m0 && (unsigned)d0), (unsigned)(8u && (unsigned)(garr[u2 & 7u] == u3))); }
                        w0 = w0 * 6364136223846793005ull + ((unsigned)f0 >> ((unsigned)w0 & 31u));
                        h0 = (short)(unsigned)c0;
                        default: ;
                        case 3u: ;
                    } else {
                        goto L4;
                    }
                    i2 = ((unsigned)(a0[u1 & 3u] && a0[i0 & 3u]) | ~((unsigned)c1 * u2)) & 15u;
                }
                goto done;
                if (*q0) goto L2;
            }
            b0 = (unsigned)(short)(unsigned)(p1 < p2) != 0u;
        }
        v0 = (v0 ? 0x7fffffffu : u0);
    }
    if (((unsigned)!(v0 << ((unsigned)h0 & 31u)) << (a0[u1 & 3u] & 31u))) goto L4;
    if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)(i0 == (unsigned)b0) << ((unsigned)w0 & 31u)), p1, (p1 % (u2 | 1u))); }
    switch ((unsigned)((unsigned)h1 && (unsigned)((int)g1 < (int)0x80000000u)) & 7u) {
        s0 = (int)(unsigned)((int)(v0 * 0x7fffffffu) < (int)((unsigned)((int)m0 < (int)3u) >> ((unsigned)c0 & 31u)));
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)d0, ((unsigned)c0 & (0xeb019c91u % (a0[u1 & 3u] | 1u))), (unsigned)((short)((unsigned)f0 - garr[i1 & 7u]) > (signed char)0x10000u)); }
        case 6u: ;
        { unsigned t3; double z3; if (((*q0 % (0x10000u | 1u))) & 1u) { t3 = ((unsigned)d0 % (u0 | 1u)); z3 = (double)((i2) & 255u); } if (((*q0 % (0x10000u | 1u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            { unsigned t4; double z4; if ((((u1 + (unsigned)x0) & i2)) & 1u) { t4 = r0.x; z4 = (double)((u3) & 255u); } if ((((u1 + (unsigned)x0) & i2)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                *q0 = g1;
                s0 = (int)garr[i1 & 7u];
                switch ((unsigned)!(u3 ^ 0xffffffffu) & 7u) {
                    if ((p0 + 0xf1a3df7fu)) break;
                }
                default: ;
            }
        }
    }
    *mp = (unsigned)(g0 && (unsigned)!(i2 & 0x80000000u));
    w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)((unsigned)d0 & i1);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2((u3 + ((unsigned)c1 + u1)), (0xe6f26eefu | p1), (unsigned)h0); }
        if ((a0[i0 & 3u] + (i1 & 0u))) break;
        if ((unsigned)((unsigned)(x0 >> 70) == (unsigned)s0)) continue;
        c0 = (unsigned char)(unsigned)((int)p2 >= (int)(unsigned)b0);
        *q0 = (unsigned)((unsigned)((short)garr[i1 & 7u] > (signed char)i0) || i2);
        b0 = (unsigned)!(((unsigned)(x0 >> 70) << ((unsigned)e0 & 31u)) - (unsigned)e0) != 0u;
    }
    { unsigned t5; double z5; if ((((unsigned)h0 % (((unsigned)h1 >> (8u & 31u)) | 1u))) & 1u) { t5 = (unsigned)s1; z5 = (double)(((u0 - garr[i1 & 7u])) & 255u); } if ((((unsigned)h0 % (((unsigned)h1 >> (8u & 31u)) | 1u))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        if (budget != 0u) { budget -= 1u; u2 = fn1((*q0 | (0xdc19b57bu & 0x333201bfu)), ~(unsigned)(*q0 || *q0), -(unsigned)((unsigned)(unsigned char)(unsigned)((int)(unsigned)h1 >= (int)(unsigned)c0) == (unsigned)e0)); }
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)(unsigned)(p0 < 0xd1ef4a61u) > (signed char)(unsigned)c1), (unsigned)c1, (unsigned)((unsigned)c1 && i0)); }
        q0 = &garr[p1 & 7u];
    }
    u2 = *mp;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((v0 ? p0 : p1)) break;
        v0 = (~((unsigned)w0 % (g1 | 1u)) + (r0.x * *mp));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(u0 && (*mp + g0)), (u2 / ((unsigned)b0 | 1u)), (0x80000000u >> (u2 & 31u))); }
    goto L4;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 = ((unsigned)(short)(u2 % ((unsigned)h1 | 1u)) ^ r0.y);
    }
    { unsigned t0; double z0; if ((-((unsigned)h1 >> ((unsigned)(0xae0e2ed0u < (unsigned)(x0 >> 70)) & 31u))) & 1u) { t0 = ((2u << (a0[i0 & 3u] & 31u)) + g1); z0 = (double)(((unsigned)s0) & 255u); } if ((-((unsigned)h1 >> ((unsigned)(0xae0e2ed0u < (unsigned)(x0 >> 70)) & 31u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if (budget != 0u) { budget -= 1u; u2 = fn1((0xffffffffu + (unsigned)c0), 5u, (unsigned)((unsigned)f0 || garr[u2 & 7u])); }
        L0: if (--fuel == 0u) goto done;
        if ((*q0 & p1)) goto L4;
        if (u3 == 7u) return (unsigned)((unsigned)((int)(0x10000u / ((unsigned)b0 | 1u)) < (int)0x80000000u) == ((unsigned)b0 - (unsigned)c1));
        u0 += (unsigned)((short)(unsigned)(0x6176b802u < (unsigned)c1) > (signed char)garr[i1 & 7u]);
        h1 = (unsigned short)(h1 + (u3 / (m0 | 1u)));
    }
    if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)s0 - (unsigned)((unsigned)x0 || 0xbf8f74c5u)), 0xfc91d5e7u, -(0x7fffffffu >> (p1 & 31u))); }
    if ((unsigned)((0x80000000u / (4u | 1u)) < 5u)) goto L2;
    u0 ^= (p1 % ((unsigned)((unsigned)b0 && 0xebe05e2fu) | 1u));
    g1 += (0u >> (p1 & 31u));
    m0 ^= v0;
    goto L1;
    if (fuel < 8u) return (unsigned)(u1 == u1);
    if ((unsigned)(u2 < garr[i1 & 7u])) {
        e0 = e0 * 0.5L + (long double)(((unsigned)e0 * (r0.y << (fuel & 31u))) & 1023u);
        do { if (--fuel == 0u) goto done;
            if (i0) {
                if (g1) continue;
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)(0x550d7489u);
                    *q0 = fuel;
                    L1: if (--fuel == 0u) goto done;
                    m0 ^= 0x3fedf704u;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)(unsigned)s1 < (int)0x80000000u)) break;
                        break; (void)(((u0 + r0.x) / (8u | 1u)));
                    } while (i2++ < 4u && i1);
                }
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    u1 ^= u0;
                    if (budget != 0u) { budget -= 1u; u2 = fn2((u0 - 0x3b7ac385u), 0xffffffffu, 1u); }
                    if (budget != 0u) { budget -= 1u; u0 = fn1(5u, u1, (unsigned)(u0 && *mp)); }
                }
                if (fuel < 8u) return *mp;
            } else {
                i2 = (0x80000000u / ((unsigned)!((unsigned)((int)(unsigned)h1 < (int)0xc5f3250au) / (0x9967c91u | 1u)) | 1u)) & 15u;
                if (5u) continue;
                s1 = (int)((unsigned)s1 + (unsigned)(u0 == u2));
            }
            h1 = (unsigned short)(h1 + (unsigned)(short)(unsigned)(0x94cf4971u == u2));
        } while (i0++ < 6u && (~(0x79625ea1u ^ 0x14adb376u) >> ((unsigned)f0 & 31u)));
        *mp = (unsigned)((int)(unsigned)f0 >= (int)(unsigned)h1);
    }
    if (*mp) goto done;
    switch (((unsigned)x0 * 0x238fb129u) & 7u) {
        if (fuel < 8u) return (0x10000u % ((~(r0.x * (unsigned)(unsigned char)(g0 | 0x10000u)) + g0) | 1u));
    }
    u3 += (unsigned)((unsigned)(garr[u2 & 7u] || 0x80000000u) == p0);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)s1, (m0 % ((unsigned)x0 | 1u)), ((fuel / ((unsigned)s0 | 1u)) >> (p2 & 31u))); }
        if (((unsigned)c1 * g0)) break;
        if (-(unsigned)((short)(u3 % (g1 | 1u)) > (signed char)0x7fffffffu)) goto done;
    }
    L2: if (--fuel == 0u) goto done;
    i0 = ((0x10000u - ((a0[i0 & 3u] | (unsigned)d0) - (unsigned)f0)) >> (u3 & 31u)) & 15u;
    b0 = ((unsigned)(short)(unsigned)((short)(unsigned)(*mp || i0) > (signed char)0x10000u) >> (0xffffffffu & 31u)) != 0u;
    if (~(5u / ((g1 - (unsigned)e0) | 1u))) goto L2;
    if (garr[u2 & 7u]) goto L3;
    g1 += (unsigned)((int)-(~(0x52ace13bu << ((unsigned)e0 & 31u)) << (0x10000u & 31u)) >= (int)(unsigned)((unsigned)s1 || garr[i1 & 7u]));
    i0 = ((unsigned)(signed char)(5u + a0[u1 & 3u]) % ((unsigned)(a0[i0 & 3u] == ((unsigned)f0 / (0x137ef506u | 1u))) | 1u)) & 15u;
    c1 = (signed char)(r0.x ^ (unsigned)(i0 == (unsigned)x0));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + ((8u - (unsigned)b0) >> (0xd027b3e7u & 31u));
        h0 = (short)((unsigned)e0 + 0x90dd3b90u);
        s1 = (int)((unsigned)s1 + i2);
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            while ((unsigned)(r0.x == (unsigned)b0)) { if (--fuel == 0u) goto done;
                continue; (void)(-(0x80000000u | (unsigned)f0));
                s0 = (int)0x4042d675u;
            }
            if ((unsigned)((short)u2 > (signed char)0x21df249au)) break;
            c1 = (signed char)((fuel >> ((g0 - (unsigned)e0) & 31u)) - (unsigned)c1);
        }
        if ((unsigned)((short)0x12527047u > (signed char)p0)) continue;
    }
    switch (*mp & 7u) {
        { unsigned t1; double z1; if (((unsigned)(short)(6u ^ (unsigned)d0)) & 1u) { t1 = (unsigned)!((unsigned)((short)6u > (signed char)0x4e53ff7eu) & u3); z1 = (double)(((unsigned)((int)(unsigned)(i2 < 0x10000u) < (int)r0.x)) & 255u); } if (((unsigned)(short)(6u ^ (unsigned)d0)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            if ((-((unsigned)s1 >> ((unsigned)w0 & 31u)) + g0)) {
                garr[2u & 7u] = (unsigned)((short)((p0 * 7u) | (unsigned)c1) > (signed char)(unsigned)w0);
                L3: if (--fuel == 0u) goto done;
                if ((0x80000000u + (unsigned)(i2 < (unsigned)c1))) {
                    i2 = (unsigned)(7u == 0xffffffffu) & 15u;
                    *q0 = (unsigned)(p2 && (a0[i0 & 3u] / (0xffffffffu | 1u)));
                    m0 ^= (unsigned)(g1 == (unsigned)((int)0u >= (int)(unsigned)b0));
                    e0 = e0 * 0.5L + (long double)((unsigned)h1 & 1023u);
                    a0[(r0.y - 0xdd07c21u) & 3u] = (u3 % ((u1 - (6u ^ 0x10ac41a5u)) | 1u));
                    w0 ^= (unsigned long long)(unsigned)l0 << ((unsigned)((unsigned)s0 < (unsigned)((i0 / ((unsigned)h1 | 1u)) && (unsigned)(u1 < (unsigned)c0))) & 63u);
                }
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1((4u * g1), ((unsigned)(p2 < r0.x) ^ 5u), 0x3565c51au); }
            case 5u: ;
            if ((0x10000u | 5u)) {
                if (budget != 0u) { budget -= 1u; u3 = fn2(((p1 * 5u) % (0x7fffffffu | 1u)), (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)h0), ((unsigned)d0 * u3)); }
            }
        }
    }
    if (((0xda517ed9u - (unsigned)e0) / (9u | 1u))) goto done;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = -(unsigned)(i2 < 1u);
    }
    if ((*mp ? 7u : 5u)) goto L3;
    { unsigned t2; double z2; if (((unsigned)((unsigned)s0 < 3u)) & 1u) { t2 = u2; z2 = (double)(((g1 + 0xffffffffu)) & 255u); } if (((unsigned)((unsigned)s0 < 3u)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        w0 = w0 * 6364136223846793005ull + (((unsigned)f0 | (0xecf9b456u - r0.x)) >> ((unsigned)(u1 < 4u) & 31u));
        if (1u) goto L1;
    }
    { unsigned t3; double z3; if (((v0 | 0xffffffffu)) & 1u) { t3 = (p1 ^ (unsigned)((int)(unsigned)e0 >= (int)a0[i0 & 3u])); z3 = (double)(((-(unsigned)((unsigned)c1 < 0x80000000u) % (2u | 1u))) & 255u); } if (((v0 | 0xffffffffu)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            continue; (void)((v0 | ((unsigned)s0 * (unsigned)x0)));
            continue; (void)((unsigned)(((unsigned)w0 + 2u) || 0xffffffffu));
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((short)(unsigned)e0 > (signed char)garr[u2 & 7u]) ^ u2), ((unsigned)h0 % ((unsigned)((int)i2 >= (int)(unsigned)b0) | 1u)), (unsigned)(*q0 || (unsigned)((int)4u >= (int)r0.y))); }
        }
        L4: if (--fuel == 0u) goto done;
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)l0 * (unsigned)(x0 >> 70)), (unsigned)h0, (unsigned)((int)(unsigned)h1 < (int)0x98733ed9u)); }
            *q0 = (((unsigned)d0 ^ (unsigned)x0) ^ (m0 << ((unsigned)((short)0x76165167u > (signed char)0x7fffffffu) & 31u)));
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (fuel << ((unsigned)(0x5fadb887u || ~((0x7fffffffu >> (i1 & 31u)) % (a0[i0 & 3u] | 1u))) & 31u)));
            }
            f0 = f0 * 0.5f + (float)((5u + u0) & 255u);
            goto done;
            if ((unsigned)h0) break;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn3(r0.y, ((0x67b60ef6u | u2) * 0x7fffffffu), (unsigned)(a0[u1 & 3u] && 4u)); }
        if ((p1 / ((p2 * (unsigned)c1) | 1u))) {
            u0 += ((garr[i1 & 7u] << (u0 & 31u)) / (u2 | 1u));
            if ((unsigned)c0) {
                u0 = ((fuel * i1) % (i0 | 1u));
                m0 ^= 8u;
                if (((unsigned)(p2 || *q0) * garr[u2 & 7u])) goto L0;
                if (8u) goto L4;
            } else {
                if (u0) goto done;
                g0 = (unsigned)((short)0x6394c9b4u > (signed char)p1);
                h0 = (short)(i0 % (g0 | 1u));
                switch ((i1 | 0x6aa9e5e9u) & 7u) {
                    r0.y ^= (unsigned)((int)(unsigned)((int)0xffffffffu >= (int)(unsigned)s0) < (int)(unsigned)d0);
                    if (budget != 0u) { budget -= 1u; u0 = fn3(0x7fffffffu, ((unsigned)(0xd9fc0493u < i1) | 0xf0c8984fu), garr[i1 & 7u]); }
                    s0 = (int)(unsigned)!((unsigned)(0xffffffffu && (unsigned)h0) * (unsigned)(*q0 < (0x7fffffffu / ((unsigned)h0 | 1u))));
                    if ((4u >> ((unsigned)(4u < g0) & 31u))) {
                        h1 = (unsigned short)(h1 + (unsigned)(p1 == 0xffffffffu));
                    } else {
                        i0 = (garr[u2 & 7u] << ((*q0 & ((unsigned)h1 >> (0xb49cbd4cu & 31u))) & 31u)) & 15u;
                    }
                }
            }
            c1 = (signed char)(0x337e9d34u | (unsigned)((unsigned)((unsigned)d0 || i1) == (unsigned)((int)*mp >= (int)(unsigned)(x0 >> 70))));
            while (i0++ < 5u && ((unsigned)(7u && r0.y) ^ (unsigned)c1)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((*q0 - p2), (unsigned)l0, (unsigned)(*mp && i0)); }
                break; (void)(0xda3022d3u);
                x0 = x0 * 0x100000001b3ull + ((i0 % ((i2 / (r0.y | 1u)) | 1u)) | ((unsigned)s0 | (unsigned)s0));
                w0 = w0 * 6364136223846793005ull + ((unsigned)f0 << ((unsigned)((unsigned)(signed char)(2u << (0x7fffffffu & 31u)) < ((unsigned)c1 << ((unsigned)b0 & 31u))) & 31u));
                d0 = d0 * 0.5 + (double)((unsigned)(signed char)((u2 ^ 0x10000u) | (unsigned)(0x80000000u && u0)) & 1023u);
            }
        } else {
            f0 = f0 * 0.5f + (float)(((unsigned)(0x7fffffffu || (unsigned)d0) % ((unsigned)((unsigned)c0 && (unsigned)b0) | 1u)) & 255u);
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((0x10000u & (unsigned)(x0 >> 70)) == 0x10000u), ((unsigned)(a0[u1 & 3u] < u3) | 0x17108555u), (unsigned)c0); }
        }
        i0 = 0xffffffffu & 15u;
    }
    if ((0x7fffffffu ^ (unsigned)(signed char)(u3 + (unsigned)w0))) {
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)h1 >= (int)(unsigned)d0), -((m0 << (6u & 31u)) ^ (unsigned)h1), ((unsigned)(x0 >> 70) ^ (unsigned)h0)); }
        if (((unsigned)((unsigned)f0 && u0) << ((unsigned)f0 & 31u))) goto L0;
        if ((0x10000u % (((unsigned)w0 + (unsigned)w0) | 1u))) {
            *q0 += (unsigned)((short)(unsigned)s1 > (signed char)m0);
            for (;;) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)-(((unsigned)b0 | (0u - a0[u1 & 3u])) * (unsigned)((int)i0 < (int)u2));
            }
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((0x98ae496du ? *q0 : 0xdae2d112u)) break;
            }
            m0 ^= i2;
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (garr[u2 & 7u]) {
                    *q0 += (u3 - ((unsigned)(*q0 < (unsigned)(x0 >> 70)) | i0));
                }
                u1 = u1 * 0x9e3779b1u + (((unsigned)h1 - 0x7fffffffu) ^ ((unsigned)(i2 < *q0) ^ r0.x));
            }
        }
        x0 = x0 * 0x100000001b3ull + (u1 - 0x10000u);
        garr[(unsigned)((int)(unsigned)f0 >= (int)(unsigned)l0) & 7u] = (unsigned)d0;
    } else {
        x0 = x0 * 0x100000001b3ull + a0[i0 & 3u];
        switch ((unsigned)d0 & 7u) {
            r0.x = (unsigned)((9u + (unsigned)!(unsigned)((0x7fffffffu / (0x5c17e1f0u | 1u)) == v0)) == (unsigned)(x0 >> 70));
            r0.y ^= 6u;
            case 6u: ;
            goto done;
            h0 = (short)(garr[u2 & 7u] & (((unsigned)(x0 >> 70) << ((unsigned)c0 & 31u)) + ((unsigned)e0 / (*q0 | 1u))));
        }
        g0 = ((0x4fe08835u | *mp) % ((unsigned)((short)g0 > (signed char)0xffffffffu) | 1u));
        do { if (--fuel == 0u) goto done;
            if (((unsigned)((unsigned)l0 && v0) % (0x7fffffffu | 1u))) break;
            if ((unsigned)(unsigned char)(p2 - (unsigned)((int)2u >= (int)(unsigned)s1))) {
                switch ((0x3cb3d2b2u + (unsigned)((int)v0 >= (int)u2)) & 7u) {
                    l0 = (long)((unsigned long)l0 + 0xdfca012eu);
                    case 5u: ;
                    if ((0xffffffffu >> ((unsigned)x0 & 31u))) {
                        x0 = x0 * 0x100000001b3ull + (unsigned)(2u || (unsigned)c0);
                        case 1u: ;
                    } else {
                        a0[(5u % ((unsigned)h0 | 1u)) & 3u] = (0x87331ebeu >> (p2 & 31u));
                        u0 = i0;
                    }
                    u0 += ((unsigned)((int)0xffffffffu >= (int)g1) & (unsigned)((int)0u < (int)3u));
                }
                i0 = (unsigned)h0 & 15u;
                if (~(unsigned)((unsigned)!(0x80000000u << (fuel & 31u)) < (unsigned)s1)) break;
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)(m0 < u1) < (unsigned)((unsigned)((short)6u > (signed char)*q0) < g1)));
                if (*mp) break;
                if (budget != 0u) { budget -= 1u; u0 = fn1((p1 + (unsigned)(signed char)(unsigned)(v0 && 0x77e6f5a2u)), (unsigned)(short)(unsigned)((int)a0[u1 & 3u] < (int)7u), (u2 - r0.x)); }
            } else {
                w0 = w0 * 6364136223846793005ull + (unsigned)(g0 && (0xa928a41au / ((unsigned)e0 | 1u)));
                if ((unsigned)((unsigned)d0 == (0x7fffffffu | 0x2020ee44u))) goto L4;
                u2 += ((3u >> (fuel & 31u)) & g1);
                { unsigned t4; double z4; if ((0x7fffffffu) & 1u) { t4 = g1; z4 = (double)(((unsigned)(3u && (unsigned)c0)) & 255u); } if ((0x7fffffffu) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    if (4u) break;
                    w0 ^= (unsigned long long)(5u / (m0 | 1u)) << (((unsigned)(u0 < a0[i0 & 3u]) << ((unsigned)((int)(unsigned)w0 < (int)5u) & 31u)) & 63u);
                    c0 = (unsigned char)(unsigned)((int)(unsigned)s1 >= (int)*q0);
                    if (((unsigned)(i2 && (unsigned)l0) / (0x7fffffffu | 1u))) {
                        u3 = u3 * 0x9e3779b1u + (unsigned)((unsigned)h0 < (unsigned)(unsigned char)(unsigned)((p0 & p2) == (p0 >> (3u & 31u))));
                        if (((u3 & 6u) >> ((unsigned)c0 & 31u))) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((m0 - 0x80000000u) - (unsigned)w0), 0x854423bdu, fuel); }
                        if (budget != 0u) { budget -= 1u; u3 = fn3(((r0.y + (unsigned)l0) % (r0.y | 1u)), ~(garr[i1 & 7u] * (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)b0)), (*mp * 0x7fffffffu)); }
                    }
                    b0 = (unsigned)((short)(0x91f80ebbu ? i0 : garr[u2 & 7u]) > (signed char)(unsigned)(x0 >> 70)) != 0u;
                    w0 = w0 * 6364136223846793005ull + (unsigned)b0;
                }
            }
            if ((0x6abe6e62u / (a0[i0 & 3u] | 1u))) break;
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (0xffffffffu) break;
                u3 += u0;
                if ((p0 >> (9u & 31u))) break;
            }
            v0 = (unsigned)(short)((unsigned)(x0 >> 70) | (0xc6dd07a0u - (unsigned)b0));
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)w0 | 0x10000u), (0x96616c40u * (6u * *mp)), ((unsigned)f0 + (i1 / ((unsigned)d0 | 1u)))); }
        } while (i0++ < 3u && (u1 % (garr[u2 & 7u] | 1u)));
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = ((unsigned)c0 & i1);
        if (fuel) goto L3;
        if (0xd7af5f50u) {
            { unsigned t5; double z5; if (((unsigned)(short)(unsigned)(i1 == (p2 & (unsigned)w0))) & 1u) { t5 = (unsigned)h1; z5 = (double)(((0xffffffffu ? 7u : p0)) & 255u); } if (((unsigned)(short)(unsigned)(i1 == (p2 & (unsigned)w0))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                if ((unsigned)f0) continue;
                if ((1u % (1u | 1u))) break;
                if (0xf92e49ebu) {
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (-(~(g0 + g0) | (unsigned)h0)) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn3((0x9de1dd90u & (2u >> (0x5bdfa10u & 31u))), (i2 & 0xffffffffu), (0x8dffa99au >> ((unsigned)h0 & 31u))); }
                        if (((unsigned)h0 ^ 0x7fffffffu)) goto L4;
                    }
                    u0 ^= ((6u + (unsigned)h0) ^ -(2u / ((unsigned)((unsigned)h0 == p1) | 1u)));
                } else {
                    if (u3 == 7u) return *q0;
                }
                goto L1;
                if ((unsigned)(0x871c7ac8u && (unsigned)x0)) {
                    if ((unsigned)((short)((unsigned)c0 >> (garr[i1 & 7u] & 31u)) > (signed char)u0)) break;
                    { unsigned t6; double z6; if ((a0[i0 & 3u]) & 1u) { t6 = ((unsigned)(x0 >> 70) >> (p1 & 31u)); z6 = (double)((0x80000000u) & 255u); } if ((a0[i0 & 3u]) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                        b0 = ((4u - (unsigned)s0) + p1) != 0u;
                        if ((unsigned)((int)a0[u1 & 3u] >= (int)(0x57b5ebf7u + p1))) break;
                    }
                    if (m0) break;
                }
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (unsigned)(((unsigned)((int)p0 >= (int)(unsigned)x0) << ((unsigned)(w0 >> 29) & 31u)) == i2) != 0u;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((u2 ^ (unsigned)(p0 && 0x80000000u)), (unsigned)((int)r0.x >= (int)(unsigned)s1), u2); }
                    { unsigned t7; double z7; if ((0x4e5f0b9eu) & 1u) { t7 = (5u >> (0xc96810acu & 31u)); z7 = (double)(((unsigned)w0) & 255u); } if ((0x4e5f0b9eu) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                        if (-(unsigned)((int)i2 < (int)garr[u2 & 7u])) break;
                        d0 = d0 * 0.5 + (double)(p1 & 1023u);
                        r0.x = (unsigned)((int)i0 < (int)(unsigned)((0xffffffffu & (unsigned)((int)0x10000u >= (int)garr[i1 & 7u])) || r0.x));
                        d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)((unsigned)(x0 >> 70) == ~(unsigned)(0x10000u || (unsigned)b0)) >= (int)0x39bf544bu) & 1023u);
                        d0 = d0 * 0.5 + (double)(((1u << ((unsigned)(0x80000000u == 0x76f6e8bdu) & 31u)) | 4u) & 1023u);
                    }
                    w0 ^= (unsigned long long)~(unsigned)(0x7fffffffu && (unsigned)x0) << (((unsigned)h1 / (((0x680c8ae4u << (6u & 31u)) % (p1 | 1u)) | 1u)) & 63u);
                    u2 = ((9u ^ -((unsigned)e0 | garr[u2 & 7u])) % ((unsigned)d0 | 1u));
                }
            }
            do { if (--fuel == 0u) goto done;
                if ((-(0xcd8b7078u | 1u) | 0x5265e709u)) break;
                c0 = (unsigned char)(unsigned)c1;
                w0 ^= (unsigned long long)(unsigned)((short)5u > (signed char)g1) << ((unsigned)((unsigned)(short)(0x80000000u + 3u) && (unsigned)((int)9u < (int)a0[i0 & 3u])) & 63u);
                e0 = e0 * 0.5L + (long double)(0x10000u & 1023u);
            } while (i1++ < 6u && (unsigned)(garr[u2 & 7u] && 0u));
            g1 += (unsigned)(w0 >> 29);
            g0 = 4u;
            e0 = e0 * 0.5L + (long double)((unsigned)((int)(garr[u2 & 7u] + u2) >= (int)(unsigned)x0) & 1023u);
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)e0 || (unsigned)((short)0x7b6a3796u > (signed char)u2)), 0x80000000u, (0xea3e8f02u >> ((unsigned)((int)p0 < (int)r0.y) & 31u))); }
    }
    v0 = ((unsigned)(unsigned char)(unsigned)(0xb6f53b1du < (unsigned)!(unsigned)((int)2u >= (int)0x80000000u)) << (p0 & 31u));
    if (r0.x) goto L1;
    switch ((unsigned)(x0 >> 70) & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn0(i2, u0, (-(unsigned)((unsigned)d0 || i1) & (unsigned)w0)); }
    }
    c0 = (unsigned char)(unsigned)(w0 >> 29);
    e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)(unsigned)(((m0 % (0x7fffffffu | 1u)) - i2) && 0xba53d000u) & 1023u);
    goto L2;
    if (((4u / (v0 | 1u)) ^ u3)) goto L2;
    switch ((unsigned)((p1 >> (0x1084f4c7u & 31u)) && m0) & 7u) {
        if (fuel < 8u) return (unsigned)((unsigned)d0 && ((unsigned)(9u || u0) >> (6u & 31u)));
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1(i0, ((unsigned)e0 << (r0.y & 31u)), (4u & (unsigned)b0)); }
    if (g0) goto L0;
    h1 = (unsigned short)(h1 + (unsigned)((short)-((u1 * 4u) / ((0x80000000u / ((unsigned)s0 | 1u)) | 1u)) > (signed char)(unsigned)f0));
    do { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(unsigned char)((unsigned)e0 / ((unsigned)(x0 >> 70) | 1u)) < (unsigned)w0));
        e0 = e0 * 0.5L + (long double)(0x3dc95505u & 1023u);
        v0 = -(0x10000u << ((unsigned)((unsigned)l0 < u3) & 31u));
        r0.x = ((0x80000000u % (((unsigned)(x0 >> 70) * 0x7e263da9u) | 1u)) ^ (unsigned)(unsigned char)(2u ^ r0.x));
        s0 = (int)(-(unsigned)(u3 < m0) << (garr[i1 & 7u] & 31u));
    } while (i0++ < 3u && (unsigned)((int)3u >= (int)(unsigned)d0));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 13u, 0x2406586cu, 0xd92bb145u },
        { 3u, 0xf858c810u, 0xb9dcc757u },
        { 3u, 0x77a8e1a0u, 0x1853b78cu },
        { 14u, 0x2da171du, 0xa11af609u },
        { 1u, 0xc0b9d114u, 0xc59ce33au },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
