// test-ssa-source's program of seed 134000440 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xdb31306au, g1 = 0x4a0b3695u;
static unsigned garr[8] = { 0x712a570fu, 0x53ac8b3du, 0x752210dfu, 0x61e7e975u, 0x8d1e98feu, 0x1dfd549bu, 0x8b901b41u, 0x60501fc2u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        switch (*q0 & 7u) {
            if ((u3 + (r0.y * m0))) goto L1;
            if (((unsigned)d0 * (unsigned)s0)) {
                v0 = (unsigned)((unsigned)((int)(unsigned)h1 >= (int)(unsigned)d0) == ((unsigned)h0 - (unsigned)c1));
                f0 = f0 * 0.5f + (float)(0x83e3a6du & 255u);
                *q0 += (unsigned)((p1 ? v0 : (unsigned)l0) == ((unsigned)s0 ^ a0[i0 & 3u]));
                L0: if (--fuel == 0u) goto done;
            } else {
                garr[0xa7952fb6u & 7u] = (unsigned)(unsigned char)(unsigned)(u1 < (garr[i1 & 7u] >> (u3 & 31u)));
                d0 = d0 * 0.5 + (double)(((unsigned)((a0[i0 & 3u] ^ (unsigned)w0) || (unsigned)((int)v0 >= (int)(unsigned)s0)) & m0) & 1023u);
            }
            while (i1++ < 6u && (unsigned)((int)m0 >= (int)r0.y)) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(0xff07c385u << ((*mp / ((unsigned)(x0 >> 70) | 1u)) & 31u));
                if (0xf03d488bu) goto L3;
            }
            b0 = (0x874e1687u >> (i1 & 31u)) != 0u;
        }
    } while (i0++ < 2u && ((unsigned)s0 * (unsigned)s0));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)f0 ? i2 : a0[i0 & 3u])) break;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (0x80000000u) break;
        }
        if ((unsigned)((int)0x80000000u >= (int)-(p1 * *q0))) break;
    }
    goto L1;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 2u && (unsigned)(((unsigned)s1 - 0u) == 0xb6dc6a15u)) { if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(signed char)(0xb6aa5758u % ((unsigned)(unsigned char)(unsigned)((int)p2 < (int)i2) | 1u))) continue;
                break; (void)(p1);
                goto L4;
                break; (void)(p2);
                r0.x = (unsigned)((short)(unsigned)((unsigned)f0 < (unsigned)(w0 >> 29)) > (signed char)(unsigned)(signed char)(unsigned)((unsigned)f0 < (unsigned)x0));
            }
            if (-(0xffffffffu ? a0[u1 & 3u] : a0[u1 & 3u])) {
                if (0u) break;
                if ((unsigned)c0) break;
                if (fuel < 8u) return (unsigned)(0xb054bd53u || (unsigned)f0);
                s1 = (int)((unsigned)s1 + ((unsigned)((unsigned)c0 < m0) / ((unsigned)((short)fuel > (signed char)g1) | 1u)));
            } else {
                { unsigned t0; double z0; if (((unsigned)((0x7fffffffu << (a0[u1 & 3u] & 31u)) == u0)) & 1u) { t0 = r0.x; z0 = (double)(((unsigned)((int)0x249ed853u >= (int)(unsigned)l0)) & 255u); } if (((unsigned)((0x7fffffffu << (a0[u1 & 3u] & 31u)) == u0)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                    if (fuel < 8u) return (unsigned)((int)(*q0 ? (unsigned)c0 : *q0) >= (int)(i2 - u1));
                    switch ((unsigned)((unsigned)l0 || r0.x) & 7u) {
                        s0 = (int)*mp;
                        L2: if (--fuel == 0u) goto done;
                        if ((unsigned)(unsigned char)(5u / (p2 | 1u))) {
                            L3: if (--fuel == 0u) goto done;
                            f0 = f0 * 0.5f + (float)(((unsigned)e0 ^ i0) & 255u);
                        } else {
                            h1 = (unsigned short)(h1 + (unsigned)(((unsigned)h1 >> ((unsigned)e0 & 31u)) && (unsigned)!((unsigned)f0 % ((unsigned)(w0 >> 29) | 1u))));
                            if (((unsigned)s0 << (u2 & 31u))) continue;
                            w0 ^= (unsigned long long)(unsigned)((int)(unsigned)c1 >= (int)fuel) << ((0x80000000u & (unsigned)x0) & 63u);
                            v0 = (unsigned)((int)(unsigned)(u2 < p2) >= (int)i0);
                        }
                        e0 = e0 * 0.5L + (long double)((((unsigned)w0 << ((unsigned)d0 & 31u)) * 5u) & 1023u);
                    }
                    L4: if (--fuel == 0u) goto done;
                    if ((((unsigned)c1 >> (0xe361a416u & 31u)) << ((unsigned)s0 & 31u))) goto L2;
                    m0 ^= -(0x9ca26cdu ? (unsigned)f0 : (unsigned)w0);
                    if ((unsigned)((unsigned)(x0 >> 70) || 0x80000000u)) break;
                }
            }
            if (fuel < 8u) return (0x1ce9c291u >> ((0x80000000u / (u1 | 1u)) & 31u));
        }
        break; (void)(i2);
        if (((unsigned)(w0 >> 29) ? (unsigned)(w0 >> 29) : 0xda2560b2u)) break;
    }
    e0 = e0 * 0.5L + (long double)((u3 ? g0 : (m0 + (unsigned)(x0 >> 70))) & 1023u);
    r0.x = (r0.y << ((unsigned)((v0 << ((unsigned)(0x10000u < (unsigned)b0) & 31u)) || (unsigned)l0) & 31u));
    u1 += (unsigned)e0;
    u2 += (unsigned)((0u << (0xb243c0d9u & 31u)) && ((u2 % (garr[u2 & 7u] | 1u)) & (unsigned)s0));
    if (((unsigned)((unsigned)x0 && 0x60ef9671u) / (0x10000u | 1u))) goto L0;
    { unsigned t1; double z1; if (((unsigned)s1) & 1u) { t1 = 9u; z1 = (double)((((unsigned)e0 ^ m0)) & 255u); } if (((unsigned)s1) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        b0 = (v0 * ((unsigned)h1 / (r0.x | 1u))) != 0u;
        u2 = 0xb0ce8f3au;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (0x63e6eb25u) break;
            goto done;
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (-(unsigned)((short)0xb6938461u > (signed char)(unsigned)(i0 == i1))) goto L1;
                if (u2) goto L1;
                f0 = f0 * 0.5f + (float)((unsigned)((u2 * u0) || a0[i0 & 3u]) & 255u);
                c0 = (unsigned char)(garr[u2 & 7u] ^ (unsigned)(unsigned char)((unsigned)b0 >> ((unsigned)(unsigned char)(garr[u2 & 7u] & 0x80000000u) & 31u)));
            }
            if (g1) break;
        }
        q0 = &garr[(((r0.x * fuel) + 0x7fffffffu) >> ((unsigned)l0 & 31u)) & 7u];
        goto done;
        v0 = (unsigned)l0;
    }
    s1 = (int)((unsigned)s1 + 0u);
    if (0xf2a852cbu) {
        if (((unsigned)s0 * r0.y)) goto L3;
        goto L0;
        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(3u < (unsigned)c1) && ((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)h0) * p2)) & 1023u);
    } else {
        h1 = (unsigned short)(h1 + (u2 | a0[i0 & 3u]));
        u1 ^= (unsigned)!(((unsigned)d0 << (0x80000000u & 31u)) ^ *mp);
        if (((r0.x % (9u | 1u)) | 1u)) goto done;
        u3 ^= ((unsigned)(w0 >> 29) % (v0 | 1u));
    }
    u0 += (((unsigned)((short)(0x80000000u & garr[u2 & 7u]) > (signed char)(unsigned)s0) << ((unsigned)s0 & 31u)) + i2);
    if ((unsigned)s0) goto done;
    u1 += u1;
    d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)(a0[i0 & 3u] == 3u) - 0u) < i1) & 1023u);
    if (p0) goto L4;
    u1 ^= (unsigned)((0xeb65d744u << ((unsigned)s0 & 31u)) || *q0);
    switch (r0.x & 7u) {
        b0 = (unsigned)h1 != 0u;
        u2 += (unsigned)(unsigned char)(5u + 0x80000000u);
        if ((unsigned)(short)(unsigned)(u1 == (unsigned)((short)4u > (signed char)i0))) {
            case 0u: ;
            v0 = ((9u / (m0 | 1u)) - (((unsigned)s1 & (unsigned)e0) * a0[i0 & 3u]));
            case 4u: ;
        } else {
            case 2u: ;
            s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)h1 >= (int)0x6226cbf5u));
        }
    }
    if (8u) goto L1;
    do { if (--fuel == 0u) goto done;
        switch ((unsigned)l0 & 7u) {
            w0 = w0 * 6364136223846793005ull + (((unsigned)(w0 >> 29) % ((unsigned)(0x3541c484u == (unsigned)f0) | 1u)) >> (0x7fffffffu & 31u));
            if ((unsigned)((int)(unsigned)d0 >= (int)((unsigned)w0 | p1))) {
                case 5u: ;
            }
            b0 = ((~(unsigned)(0xb965cbf1u < 0x80000000u) % ((unsigned)c1 | 1u)) * *q0) != 0u;
            if ((unsigned)c1) {
                case 7u: ;
                e0 = e0 * 0.5L + (long double)(((unsigned)((short)(0x10000u | p2) > (signed char)u0) ^ p1) & 1023u);
                case 1u: ;
                garr[0x7fffffffu & 7u] = (unsigned)(unsigned char)(0xdbc0ea44u << (0x8d799b5u & 31u));
                if ((unsigned)(i1 && (unsigned)e0)) {
                    case 2u: ;
                    case 4u: ;
                    u3 += ((unsigned)((unsigned)((int)6u < (int)(unsigned)w0) || u2) - (unsigned)s1);
                    if ((unsigned)((short)(unsigned)((unsigned)d0 < 4u) > (signed char)(unsigned)s0)) goto L0;
                    if ((unsigned)(m0 && 0x4224c753u)) break;
                } else {
                    continue; (void)(0x7fffffffu);
                }
            }
            r0.x = (3u % (g0 | 1u));
            *q0 = 0xf07afbdbu;
        }
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            u3 = (unsigned)((int)((unsigned)h1 / ((unsigned)e0 | 1u)) >= (int)p2);
            *mp = 0x1e624d5eu;
            h1 = (unsigned short)(h1 + (unsigned)(short)(3u | ((unsigned)d0 + g1)));
            goto L1;
            goto L0;
            garr[(0x7fffffffu + i0) & 7u] = (unsigned)((4u | (garr[u2 & 7u] / (r0.y | 1u))) == (v0 | (unsigned)h1));
        }
        if ((p1 | r0.x)) {
            u2 ^= (unsigned)((int)u0 < (int)*mp);
            switch ((*mp ^ u2) & 7u) {
                r0.x = (unsigned)((int)(unsigned)f0 >= (int)(0xbc319d94u ? (unsigned)x0 : m0));
                case 4u: ;
                case 1u: ;
                q0 = &garr[u3 & 7u];
                case 2u: ;
            }
            while (i1++ < 3u && (0xbb14f079u >> (g1 & 31u))) { if (--fuel == 0u) goto done;
                if (u2) continue;
                break; (void)((0x10000u - ((unsigned)s0 / (0x3581dff5u | 1u))));
                *mp = (unsigned)((short)(unsigned)l0 > (signed char)i1);
                *q0 += a0[i0 & 3u];
                d0 = d0 * 0.5 + (double)(((v0 + i0) & (unsigned)(u1 == (0xffffffffu >> (u3 & 31u)))) & 1023u);
                r0.y ^= g0;
            }
            h1 = (unsigned short)(h1 + (unsigned)!(v0 << (u1 & 31u)));
        }
    } while (i0++ < 6u && ((unsigned)c0 | ((unsigned)e0 >> (r0.x & 31u))));
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)l0 && 0x7fffffffu)) {
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                garr[((unsigned)(w0 >> 29) >> (g0 & 31u)) & 7u] = (((unsigned)(i1 == (unsigned)c0) | i0) | (unsigned)s1);
            }
            q0 = &garr[(unsigned)(((g1 >> (v0 & 31u)) + (0xafa73f04u * 0x7fffffffu)) && (unsigned)x0) & 7u];
            do { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (i2 & (i2 ^ p0)));
                w0 = w0 * 6364136223846793005ull + (u2 >> (fuel & 31u));
                if ((0x7fffffffu << ((4u >> (9u & 31u)) & 31u))) break;
                if ((unsigned)((unsigned)d0 < u2)) break;
                if ((unsigned)(unsigned char)((unsigned)(x0 >> 70) ? *mp : 0xffffffffu)) break;
            } while (i1++ < 4u && (unsigned)((unsigned)b0 < (garr[i1 & 7u] / (u2 | 1u))));
        }
        if ((unsigned)e0) {
            break; (void)(((u2 - i1) & (unsigned)d0));
            garr[((unsigned)c1 / (6u | 1u)) & 7u] = r0.y;
            if (g1) break;
        }
        if ((fuel + (unsigned)x0)) break;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)((unsigned)e0 & u1);
            if (4u) break;
            m0 ^= 0x80000000u;
            if (((unsigned)(unsigned char)((unsigned)(w0 >> 29) << (i2 & 31u)) << (r0.x & 31u))) break;
        }
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(((unsigned)w0 ^ -(i1 ^ garr[u2 & 7u])) & 1023u);
            { unsigned t2; double z2; if (((unsigned)h1) & 1u) { t2 = (garr[i1 & 7u] - g1); z2 = (double)((g1) & 255u); } if (((unsigned)h1) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                u0 = u0 * 0x9e3779b1u + (unsigned)(0xffffffffu == (((unsigned)e0 % (r0.x | 1u)) | (unsigned)d0));
            }
        }
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(r0.x * p2) << (((unsigned)((unsigned)x0 < a0[u1 & 3u]) << (~((unsigned)(w0 >> 29) / (a0[i0 & 3u] | 1u)) & 31u)) & 63u);
        }
        s0 = (int)((((unsigned)e0 * 0x7fffffffu) + 0x980f7bd1u) | 0xffffffffu);
        goto L3;
        if ((0u + 0u)) goto L4;
        g0 = (unsigned)((i2 + ((unsigned)d0 ^ (unsigned)f0)) == (7u ^ r0.y));
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t3; double z3; if (((unsigned)(short)(unsigned)((7u ^ (unsigned)w0) == (unsigned)c0)) & 1u) { t3 = (unsigned)((int)0xb7e65489u >= (int)2u); z3 = (double)((((unsigned)b0 >> (u2 & 31u))) & 255u); } if (((unsigned)(short)(unsigned)((7u ^ (unsigned)w0) == (unsigned)c0)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            f0 = f0 * 0.5f + (float)(((0x6daff84cu * (unsigned)(signed char)(i2 % ((unsigned)s1 | 1u))) ^ 7u) & 255u);
            goto L4;
        }
        r0.x = ((unsigned)h1 * 0x22ec6c00u);
        if (fuel < 8u) return (unsigned)((int)a0[i0 & 3u] < (int)u0);
        if ((1u + (unsigned)w0)) break;
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (*mp & 7u) {
            case 4u: ;
            break; (void)((fuel << (0x80000000u & 31u)));
            *q0 = (unsigned)((int)(u2 >> (i2 & 31u)) < (int)0x80000000u);
            s1 = (int)((unsigned)s1 + (u2 & (unsigned)(x0 >> 70)));
            m0 ^= (p0 % (p0 | 1u));
            h0 = (short)(unsigned)((unsigned)c1 || *mp);
        }
        if (i1) break;
        if ((unsigned)((9u & (unsigned)s0) && (unsigned)f0)) {
            if ((unsigned)x0) break;
            if ((unsigned)((unsigned)((unsigned)c1 == *mp) == 2u)) break;
        } else {
            u3 ^= (unsigned)(((unsigned)h0 >> (u0 & 31u)) && m0);
            garr[(garr[u2 & 7u] << ((unsigned)e0 & 31u)) & 7u] = ((unsigned)(signed char)(*q0 & u2) + (unsigned)((short)8u > (signed char)(unsigned)e0));
        }
        if (((unsigned)x0 % (u3 | 1u))) continue;
        if ((p1 ^ 1u)) {
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)((short)p0 > (signed char)*q0) & 255u);
                a0[g0 & 3u] = (unsigned)((short)5u > (signed char)0x5cff89c9u);
                h1 = (unsigned short)(h1 + (0x10000u | m0));
                if ((1u + (unsigned)((unsigned)s1 == (unsigned)s0))) break;
                w0 = w0 * 6364136223846793005ull + ((a0[u1 & 3u] & 0xffffffffu) >> (-(u0 / (0x230bbe95u | 1u)) & 31u));
            }
            if (((unsigned)e0 / (0xb4de67b7u | 1u))) break;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    m0 ^= (unsigned)!(unsigned)((int)(unsigned)h1 < (int)(unsigned)((int)1u < (int)(unsigned)e0));
                    u2 = u2 * 0x9e3779b1u + ((unsigned)(short)(0x80000000u & a0[i0 & 3u]) + (unsigned)(p1 && 0xf88a9982u));
                    q0 = &garr[((0x10000u * 9u) + (0xffffffffu - (m0 + p2))) & 7u];
                } while (i2++ < 5u && (unsigned)((0x662f8417u + 0x80000000u) || 0x8939f59u));
                break; (void)(u0);
            }
            w0 ^= (unsigned long long)(unsigned)f0 << ((0x69cc9b0bu ^ 0x7fffffffu) & 63u);
        } else {
            if ((unsigned)((int)(0xe319d1c4u & garr[i1 & 7u]) < (int)u0)) {
                v0 = (unsigned)(unsigned char)(unsigned)((int)5u >= (int)((0xb779aec5u >> (v0 & 31u)) * (unsigned)((int)u0 >= (int)g1)));
                u2 = u2 * 0x9e3779b1u + ((0x7fffffffu + (unsigned)d0) | ((unsigned)h0 / (0x10000u | 1u)));
                if ((unsigned)(w0 >> 29)) goto L3;
                c1 = (signed char)r0.y;
            } else {
                b0 = ((unsigned)((unsigned)c0 < (a0[i0 & 3u] % (5u | 1u))) | (unsigned)(2u && 0xf2d6de50u)) != 0u;
            }
            if (~(0x66ef853eu * (unsigned)((short)(unsigned)c1 > (signed char)a0[i0 & 3u]))) break;
        }
    }
    while (~(unsigned)((short)r0.x > (signed char)(unsigned)c1)) { if (--fuel == 0u) goto done;
        if (((unsigned)(0x7ab998d0u == 0x98836623u) | 0xe7999240u)) break;
        e0 = e0 * 0.5L + (long double)((unsigned)((int)((unsigned)d0 * (unsigned)d0) >= (int)-((unsigned)s0 & (7u - (unsigned)e0))) & 1023u);
    }
    if ((unsigned)e0) goto L3;
    if ((u2 >> (4u & 31u))) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)s0 < p0)) break;
            v0 = (unsigned)!(unsigned)((int)(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)(signed char)(garr[u2 & 7u] * (unsigned)s1)) < (int)a0[i0 & 3u]);
            do { if (--fuel == 0u) goto done;
                break; (void)((unsigned)s1);
                u2 = (unsigned)((int)(unsigned)((int)u1 < (int)a0[i0 & 3u]) >= (int)(unsigned)w0);
            } while (i1++ < 3u && (unsigned)!(m0 - v0));
            break; (void)((6u & 0x10000u));
        }
        if ((unsigned)(u1 || a0[u1 & 3u])) {
            x0 = x0 * 0x100000001b3ull + garr[i1 & 7u];
            do { if (--fuel == 0u) goto done;
                q0 = &garr[((unsigned)((int)0x80000000u >= (int)i2) % (8u | 1u)) & 7u];
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)(signed char)(unsigned)((short)0xffffffffu > (signed char)((unsigned)(9u == g1) - garr[u2 & 7u]));
                    break; (void)(a0[i0 & 3u]);
                    if (u3 == 7u) return ((unsigned)(w0 >> 29) - a0[i0 & 3u]);
                }
                if ((unsigned)!(0xe0f2fef7u / ((unsigned)(signed char)(fuel - 0x80000000u) | 1u))) {
                    if (0x277e01c1u) goto L2;
                    m0 ^= (u0 ? 2u : (unsigned)d0);
                    if ((unsigned)(x0 >> 70)) break;
                } else {
                    i0 = 0xe8acd217u & 15u;
                }
            } while (i0++ < 4u && i0);
            if ((garr[u2 & 7u] ^ 8u)) goto L1;
        } else {
            while (i0++ < 5u && 0x10000u) { if (--fuel == 0u) goto done;
                if ((unsigned)c0) break;
                d0 = d0 * 0.5 + (double)((unsigned)((int)v0 >= (int)p0) & 1023u);
                s0 = (int)((unsigned)((short)g1 > (signed char)i1) << ((unsigned)(v0 && (unsigned)(short)(5u ^ (unsigned)(x0 >> 70))) & 31u));
                break; (void)(9u);
                i1 = (unsigned)(~(unsigned)((unsigned)(w0 >> 29) && (unsigned)((int)(unsigned)e0 < (int)(unsigned)(x0 >> 70))) < (unsigned)d0) & 15u;
                *mp = ((unsigned)(signed char)(i1 ? (unsigned)f0 : (unsigned)x0) & (unsigned)x0);
            }
        }
    }
    if (a0[u1 & 3u]) goto L4;
    if (a0[u1 & 3u]) goto L4;
    u1 += (unsigned)(signed char)(unsigned)((short)a0[i0 & 3u] > (signed char)((unsigned)f0 * (unsigned)d0));
    b0 = ((i0 + (unsigned)e0) / ((0xffffffffu | (unsigned)d0) | 1u)) != 0u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        continue; (void)((((unsigned)c1 << ((unsigned)b0 & 31u)) & (unsigned)c0));
        while (i1++ < 5u && (0xffffffffu % (0x7fffffffu | 1u))) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                v0 = ((((unsigned)(x0 >> 70) & (unsigned)c0) * 0xceff80e0u) * (*q0 % (garr[u2 & 7u] | 1u)));
                if (g1) break;
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    while (p0) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (0x12831ce2u << ((unsigned)h0 & 31u)));
                        if (((unsigned)(x0 >> 70) | (unsigned)((int)6u < (int)p0))) break;
                        goto L2;
                    }
                    g0 = (unsigned)((int)a0[u1 & 3u] >= (int)8u);
                    s1 = (int)((unsigned)s1 + 0x65da0268u);
                    L0: if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + ((p2 ? p0 : 0x7db0ed6u) + i1));
                    if ((i0 % (0xd2dd5ea4u | 1u))) break;
                }
            } while (i2++ < 6u && (unsigned)((short)0x1c33a193u > (signed char)5u));
            a0[(garr[u2 & 7u] & 2u) & 3u] = (g1 - (u1 - 0x999ecb0bu));
            s0 = (int)(unsigned)((int)(unsigned)(short)(unsigned)(a0[u1 & 3u] || (unsigned)e0) < (int)(unsigned)(unsigned char)((unsigned)c1 / ((unsigned)(v0 || (unsigned)w0) | 1u)));
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(-(garr[i1 & 7u] * p0) == m0), 0x1429c283u, (unsigned)((0xf7eeacdu / (v0 | 1u)) && (unsigned)x0)); }
            w0 = w0 * 6364136223846793005ull + (unsigned)(r0.y == (0x80000000u * u2));
            L1: if (--fuel == 0u) goto done;
        }
        r0.y ^= (garr[u2 & 7u] & p1);
        if ((r0.y ? (unsigned)c1 : 0xd59ff42eu)) break;
        if (r0.x) continue;
        if (budget != 0u) { budget -= 1u; u3 = fn0(garr[i1 & 7u], (unsigned)((short)i2 > (signed char)0x80000000u), i1); }
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)h1 < (int)0x4770a483u)) {
            x0 = x0 * 0x100000001b3ull + 8u;
            d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(unsigned)(garr[i1 & 7u] == ((unsigned)c1 ? 6u : r0.x)) & 1023u);
            r0.x = ((6u - 3u) / ((unsigned)b0 | 1u));
        }
        h1 = (unsigned short)(h1 + (unsigned)(signed char)(g1 * (unsigned)((unsigned)(signed char)((unsigned)f0 & m0) == (0x7cc2e7cau / (*q0 | 1u)))));
        break; (void)(((unsigned)(i0 || *mp) / (0xbe182ca8u | 1u)));
    }
    { unsigned t0; double z0; if (((unsigned)(0x7fffffffu == (unsigned)s1)) & 1u) { t0 = (unsigned)((int)(m0 | (unsigned)s1) >= (int)(unsigned)h0); z0 = (double)(((unsigned)((int)(u2 / (r0.y | 1u)) < (int)6u)) & 255u); } if (((unsigned)(0x7fffffffu == (unsigned)s1)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        while (i0++ < 6u && (unsigned)(unsigned char)(unsigned)(((unsigned)w0 >> (*mp & 31u)) || i1)) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                b0 = (unsigned)((unsigned)l0 < (0xec1d2ce8u << ((~(unsigned)(i0 == v0) >> (0xffffffffu & 31u)) & 31u))) != 0u;
                { unsigned t1; double z1; if (((i0 | (unsigned)(0xa94d81abu || (unsigned)x0))) & 1u) { t1 = 6u; z1 = (double)((0xa915bae5u) & 255u); } if (((i0 | (unsigned)(0xa94d81abu || (unsigned)x0))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    *q0 = (unsigned)((int)(unsigned)((int)0x7fffffffu >= (int)0x7fffffffu) >= (int)(r0.x >> (3u & 31u)));
                    m0 ^= (unsigned)h0;
                    c0 = (unsigned char)(0u - (1u * g0));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)b0, (0xc63c558eu * (unsigned)f0), (u0 ^ g0)); }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0(0x3d6d4e8au, v0, garr[u2 & 7u]); }
                l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)f0 + (unsigned)b0) || (u0 >> (*mp & 31u))));
                for (;;) { if (--fuel == 0u) goto done;
                    while (i0++ < 7u && (0xffffffffu | (unsigned)h1)) { if (--fuel == 0u) goto done;
                        if (u3) goto L1;
                        s0 = (int)(unsigned)((unsigned)s1 || (unsigned)(short)((unsigned)l0 / (u0 | 1u)));
                        switch ((unsigned)(0x7fffffffu || 0u) & 7u) {
                            r0.x = (unsigned)((short)(unsigned)((int)(unsigned)l0 >= (int)g1) > (signed char)(unsigned)((int)a0[i0 & 3u] >= (int)0xffffffffu));
                            u0 ^= (((i2 >> (0x80000000u & 31u)) / ((unsigned)(x0 >> 70) | 1u)) ^ 0x7fffffffu);
                            case 7u: ;
                            x0 = x0 * 0x100000001b3ull + ((((unsigned)s0 * 0x53288d73u) % (0xd7481804u | 1u)) % (0x4987febeu | 1u));
                        }
                        if ((unsigned)c1) break;
                        m0 ^= (unsigned)(r0.y || (unsigned)((short)(unsigned)c1 > (signed char)u1));
                        { unsigned t2; double z2; if (((unsigned)(short)(unsigned)((int)(unsigned)(i2 < u1) < (int)0x5b6a47bcu)) & 1u) { t2 = (unsigned)((short)(unsigned)d0 > (signed char)0xffffffffu); z2 = (double)(((u0 / (v0 | 1u))) & 255u); } if (((unsigned)(short)(unsigned)((int)(unsigned)(i2 < u1) < (int)0x5b6a47bcu)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                            if (u0) continue;
                        }
                    }
                    if ((a0[i0 & 3u] / ((unsigned)((int)a0[i0 & 3u] < (int)9u) | 1u))) continue;
                }
            }
            break; (void)(garr[u2 & 7u]);
            while (i1++ < 2u && ((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)h1) % (u0 | 1u))) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)((short)p0 > (signed char)1u));
                    f0 = f0 * 0.5f + (float)((unsigned)((short)(0x80000000u >> (p2 & 31u)) > (signed char)(unsigned)h0) & 255u);
                    f0 = f0 * 0.5f + (float)(garr[i1 & 7u] & 255u);
                    l0 = (long)((unsigned long)l0 + (unsigned)(0x51c5a33au < (0x80000000u & *q0)));
                    if (a0[u1 & 3u]) goto done;
                }
                break; (void)((p0 >> ((unsigned)((int)0xffffffffu < (int)(unsigned)(w0 >> 29)) & 31u)));
                L2: if (--fuel == 0u) goto done;
                m0 ^= (unsigned)((int)(0x80000000u + (unsigned)l0) >= (int)(unsigned)h1);
                x0 = x0 * 0x100000001b3ull + (unsigned)((((unsigned)d0 ? 6u : a0[u1 & 3u]) << (u0 & 31u)) && 0x3cc926bbu);
            }
            m0 ^= ((unsigned)(9u && 0x7fffffffu) / ((unsigned)(w0 >> 29) | 1u));
            if (fuel < 8u) return -(unsigned)((int)(unsigned)d0 < (int)g1);
        }
        if (0xa87500bfu) goto L4;
        do { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((unsigned)(unsigned char)(unsigned)(9u || fuel) % ((unsigned)f0 | 1u));
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)s1 < (int)a0[i0 & 3u]), (*mp ^ (0u << (p2 & 31u))), (-((unsigned)s0 * u0) | (unsigned)(x0 >> 70))); }
            goto done;
            switch ((a0[i0 & 3u] + i2) & 7u) {
                h1 = (unsigned short)(h1 + (garr[u2 & 7u] - (unsigned)x0));
                v0 = (u2 | (0x7fffffffu << (0x2b52cb0eu & 31u)));
                case 1u: ;
                g0 = r0.x;
                b0 = (unsigned)((unsigned)(*q0 || g0) && p0) != 0u;
                break; (void)(((fuel / (a0[i0 & 3u] | 1u)) ^ (unsigned)w0));
            }
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    switch (((unsigned)(signed char)(u1 / ((unsigned)f0 | 1u)) - (unsigned)e0) & 7u) {
                        if ((0x10000u << (((unsigned)(w0 >> 29) | 0x5d7dadffu) & 31u))) continue;
                    }
                    if (garr[u2 & 7u]) break;
                    L3: if (--fuel == 0u) goto done;
                    L4: if (--fuel == 0u) goto done;
                } while (i2++ < 6u && (p0 * (unsigned)(short)((unsigned)(w0 >> 29) ^ 0x80000000u)));
                if (budget != 0u) { budget -= 1u; u2 = fn0((fuel + fuel), (g1 ^ 0xfc2d364u), (unsigned)e0); }
                break; (void)(p2);
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    g0 = (unsigned)(~(unsigned)((short)*mp > (signed char)6u) && 8u);
                }
            }
            switch (((unsigned)x0 << (u1 & 31u)) & 7u) {
                if ((4u * (unsigned)c0)) continue;
                if ((((unsigned)l0 >> (i0 & 31u)) + (unsigned)c1)) break;
                if (-(unsigned)(a0[i0 & 3u] == (unsigned)s1)) goto L0;
            }
        } while (i0++ < 5u && -(0x7fffffffu + i0));
        u3 ^= (0xffffffffu >> (0x7fffffffu & 31u));
    }
    if ((unsigned)(short)((unsigned)d0 & garr[i1 & 7u])) {
        goto L3;
        if (garr[i1 & 7u]) goto done;
        f0 = f0 * 0.5f + (float)((unsigned)(w0 >> 29) & 255u);
        u1 += ~(unsigned)((3u ? 0x1b1a044u : (unsigned)d0) < (unsigned)f0);
    }
    goto L4;
    w0 = w0 * 6364136223846793005ull + (unsigned)(0x80000000u || (u2 & (unsigned)(unsigned char)(unsigned)((short)g1 > (signed char)p0)));
    switch (0x10000u & 7u) {
        a0[(m0 * v0) & 3u] = (g1 % ((u3 ^ (unsigned)((short)0x156057adu > (signed char)p1)) | 1u));
        case 4u: ;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(0x400fa2deu && (unsigned)((int)(unsigned)e0 < (int)u1)), (unsigned)(x0 >> 70), 1u); }
        if (a0[u1 & 3u]) goto done;
    }
    if (((unsigned)x0 % ((i0 | r0.y) | 1u))) {
        do { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 += (unsigned)(signed char)(unsigned)((p2 >> (u2 & 31u)) && (unsigned)!(unsigned)((int)0xb628a2f6u >= (int)0x7fffffffu));
                break; (void)((unsigned)(u1 && (unsigned)((int)u2 >= (int)r0.x)));
                if (u2) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)f0, 3u, (unsigned)h1); }
                    if ((unsigned)((unsigned)w0 == i0)) {
                        if (budget != 0u) { budget -= 1u; u3 = fn0(0x10000u, *q0, ~(unsigned)(0u || (unsigned)c1)); }
                        for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                            c0 = (unsigned char)u3;
                            g0 = ((unsigned)(u1 == i2) * (r0.y | (0xffffffffu % (p0 | 1u))));
                        }
                        if ((unsigned)(0xc0a2c546u || r0.y)) break;
                    }
                    break; (void)((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)h1));
                    goto L2;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)h0, (unsigned)e0, (unsigned)((int)0xe03baf38u >= (int)0xffffffffu)); }
                    l0 = (long)((unsigned long)l0 + ((unsigned)((short)*mp > (signed char)(unsigned)b0) % (((unsigned)x0 ? garr[i1 & 7u] : v0) | 1u)));
                } else {
                    r0.y ^= 0x80000000u;
                    a0[u1 & 3u] = (unsigned)((short)(unsigned)(8u && (unsigned)((unsigned)(x0 >> 70) || u3)) > (signed char)(unsigned)c1);
                }
                if (((unsigned)(signed char)(unsigned)((short)u3 > (signed char)3u) >> (0xd03b9544u & 31u))) break;
            }
            *mp = (unsigned)((0x10000u % (((unsigned)e0 - 0xf5130890u) | 1u)) < (garr[i1 & 7u] >> (0xffffffffu & 31u)));
            u1 += (unsigned)(signed char)(unsigned)((*q0 ? (unsigned)h1 : (unsigned)d0) && v0);
            if (garr[u2 & 7u]) {
                goto L2;
                { unsigned t3; double z3; if ((0xed8908f8u) & 1u) { t3 = (unsigned)(short)(unsigned)(r0.x || (m0 << (0x7fffffffu & 31u))); z3 = (double)(((unsigned)(6u < u1)) & 255u); } if ((0xed8908f8u) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    s1 = (int)((unsigned)s1 + 5u);
                }
                c0 = (unsigned char)(unsigned)(u3 == (6u / (*q0 | 1u)));
                if ((unsigned)(signed char)(unsigned)((short)6u > (signed char)(unsigned)!(m0 * 0x80000000u))) break;
                s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)s0 < (int)(unsigned)(unsigned char)(unsigned)((unsigned)b0 == (unsigned)h0)));
                c1 = (signed char)(0x775cfbbau & 0x9789010eu);
            } else {
                if (budget != 0u) { budget -= 1u; u2 = fn0(a0[i0 & 3u], (unsigned)((unsigned)h0 == (unsigned)w0), (unsigned)((unsigned)(unsigned char)(unsigned)(1u == i0) && 0x80000000u)); }
                if ((unsigned)c1) continue;
                i1 = (*q0 + (unsigned)(0x80000000u < (2u << (*q0 & 31u)))) & 15u;
            }
        } while (i0++ < 3u && ((unsigned)b0 / (0xecdaa5cdu | 1u)));
    } else {
        if ((0x10000u % (u3 | 1u))) goto L0;
        switch (u0 & 7u) {
            if ((~((unsigned)c1 - (unsigned)w0) >> (u0 & 31u))) goto L2;
            while (i0++ < 7u && a0[u1 & 3u]) { if (--fuel == 0u) goto done;
                case 7u: ;
                continue; (void)((unsigned)((int)3u >= (int)(unsigned)(short)(i0 & 5u)));
            }
            case 5u: ;
            a0[(0x197fb3aau + 9u) & 3u] = (unsigned)((short)2u > (signed char)(unsigned)(unsigned char)(0x10000u * ((unsigned)h0 % ((unsigned)(x0 >> 70) | 1u))));
            if (0x7fffffffu) {
                *mp = 0x7fffffffu;
                case 3u: ;
                r0.y ^= ((unsigned)((unsigned)l0 == m0) % ((unsigned)(u0 || a0[i0 & 3u]) | 1u));
            }
        }
        do { if (--fuel == 0u) goto done;
            if ((5u - g0)) goto done;
            v0 = -(unsigned)((i2 ? 0x602544e1u : 1u) < (a0[u1 & 3u] & 0xa9743bcbu));
            g0 = (unsigned)((unsigned)e0 < (unsigned)x0);
            g1 += (2u - (unsigned)s0);
            if (fuel < 8u) return (unsigned)((p2 | (garr[i1 & 7u] * m0)) && ((unsigned)h1 - 5u));
        } while (i0++ < 6u && 8u);
        u2 = u2 * 0x9e3779b1u + garr[i1 & 7u];
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((0xffd29c0bu & g1), (garr[u2 & 7u] & i2), g1); }
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((unsigned)(0x4d74430u == 0x58aae57eu) == 6u));
        if ((unsigned)(unsigned char)(r0.x >> (i0 & 31u))) {
            while (i1++ < 3u && (unsigned)(a0[i0 & 3u] == (unsigned)f0)) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    v0 = 0x80000000u;
                    if ((0xffffffffu << (garr[i1 & 7u] & 31u))) {
                        e0 = e0 * 0.5L + (long double)((unsigned)(r0.y == 0x5593cb1eu) & 1023u);
                        if (0xffffffffu) break;
                        *q0 += (unsigned)((unsigned)(unsigned char)(unsigned)(g1 && (8u ^ 0xd77aad10u)) || (unsigned)h0);
                    } else {
                        if (-(unsigned)((unsigned)x0 < (p1 - i0))) break;
                    }
                }
                { unsigned t4; double z4; if ((i0) & 1u) { t4 = a0[u1 & 3u]; z4 = (double)(((unsigned)(*mp == (unsigned)((short)(unsigned)h1 > (signed char)r0.x))) & 255u); } if ((i0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    b0 = fuel != 0u;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(short)((unsigned)d0 << ((i0 << ((unsigned)l0 & 31u)) & 31u)), u0, (i0 << (((unsigned)x0 % (v0 | 1u)) & 31u))); }
                    if ((unsigned)!(unsigned)(2u < 0xffffffffu)) {
                        garr[(unsigned)c1 & 7u] = 0xffffffffu;
                        u2 = (unsigned)(unsigned char)(unsigned)(~(unsigned)(r0.x < a0[i0 & 3u]) && 0x80000000u);
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(p2 << ((unsigned)b0 & 31u)) > (signed char)(unsigned)b0), ((u0 >> (0x10000u & 31u)) - fuel), (unsigned)s1); }
                        break; (void)((8u % (1u | 1u)));
                    } else {
                        h1 = (unsigned short)(h1 + (unsigned)((short)fuel > (signed char)(unsigned)(fuel == u1)));
                        for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                            continue; (void)((unsigned)(signed char)((r0.y >> (*mp & 31u)) & p2));
                        }
                    }
                    break; (void)((r0.x | 0xf42a554cu));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)b0, g1, ((u3 >> ((unsigned)c1 & 31u)) * (unsigned)x0)); }
                    break; (void)(0x7fffffffu);
                }
                b0 = ((unsigned)(unsigned char)(*q0 | 0x3e5224aau) >> (((unsigned)d0 + i2) & 31u)) != 0u;
                if ((unsigned)(unsigned char)(unsigned)(*mp == 0x10000u)) goto L1;
                r0.y ^= ((unsigned)(garr[i1 & 7u] < (unsigned)x0) | (u1 - u2));
                if ((unsigned)((short)p0 > (signed char)(p0 & (unsigned)h1))) goto L1;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((g0 & (unsigned)(0xffffffffu && (unsigned)f0)), (unsigned)s1, (unsigned)(0x23f0badu < r0.x)); }
            goto L2;
            if ((0x7ad2e01au * i0)) {
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)h0, (a0[u1 & 3u] * ((unsigned)w0 + (unsigned)e0)), (u3 / ((unsigned)((unsigned)c1 < a0[i0 & 3u]) | 1u))); }
                if (g1) goto L3;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)w0 < *q0)) goto L0;
                    a0[(0x7fffffffu + (unsigned)h1) & 3u] = 7u;
                    l0 = (long)((unsigned long)l0 + (unsigned)x0);
                    r0.x = a0[u1 & 3u];
                    h0 = (short)(unsigned)((unsigned)f0 == ((unsigned)e0 >> (*mp & 31u)));
                    r0.x = 0x10000u;
                }
            } else {
                e0 = e0 * 0.5L + (long double)(((unsigned)b0 >> ((unsigned)(0x679e1c8u && ~(0x7fffffffu ^ r0.y)) & 31u)) & 1023u);
                q0 = &garr[(unsigned)(unsigned char)(r0.y ^ 5u) & 7u];
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)!(unsigned)((int)(unsigned)c1 < (int)(unsigned)e0)) break;
                } while (i1++ < 6u && (r0.x & a0[i0 & 3u]));
                if ((3u - fuel)) break;
            }
        }
        continue; (void)((unsigned)h1);
    } while (i0++ < 5u && (unsigned)(a0[u1 & 3u] == 0x8c38e294u));
    if (budget != 0u) { budget -= 1u; u2 = fn0((v0 & ~(unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)c1)), ((unsigned)b0 ? (unsigned)f0 : u1), (2u * (unsigned)b0)); }
    b0 = (unsigned)(signed char)((unsigned)((unsigned)e0 < (unsigned)(unsigned char)(unsigned)(*q0 && 0x80000000u)) * ((unsigned)h1 >> (i2 & 31u))) != 0u;
    if (budget != 0u) { budget -= 1u; u1 = fn0(2u, ((0x6302a0b7u * *mp) + a0[i0 & 3u]), (unsigned)w0); }
    if (budget != 0u) { budget -= 1u; u3 = fn0(p0, u2, (0x80000000u * *q0)); }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)x0 + r0.x)) goto L1;
            if (a0[i0 & 3u]) {
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)d0 << (0x4259fb17u & 31u)), ((unsigned)((int)p0 >= (int)p0) / (9u | 1u)), (unsigned)(g0 && (i0 / (a0[i0 & 3u] | 1u)))); }
                s0 = (int)(unsigned)(*q0 || (((unsigned)h0 / (0xa2519a1du | 1u)) * (unsigned)((int)fuel >= (int)(unsigned)s0)));
                goto L0;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (unsigned)(0x10000u < (unsigned)s1);
                    g0 = (a0[i0 & 3u] * (r0.y / ((unsigned)d0 | 1u)));
                    do { if (--fuel == 0u) goto done;
                        if (((unsigned)c1 + (unsigned)l0)) goto L2;
                        b0 = (((unsigned)w0 / (garr[i1 & 7u] | 1u)) - 0xd8446c67u) != 0u;
                    } while (i0++ < 5u && (0xffffffffu ^ ((unsigned)s0 ^ *mp)));
                    if ((u2 ^ (unsigned)((int)(unsigned)(w0 >> 29) < (int)fuel))) break;
                }
            } else {
                q0 = &garr[((unsigned)f0 | ((0x80000000u * (unsigned)h1) << (6u & 31u))) & 7u];
            }
            s0 = (int)(a0[i0 & 3u] << ((unsigned)(0x6ae6a087u || ((unsigned)l0 & (unsigned)w0)) & 31u));
            if ((unsigned)((short)4u > (signed char)(unsigned)((short)(unsigned)h1 > (signed char)r0.x))) {
                { unsigned t5; double z5; if (((unsigned)(p1 && 0x234c3fc2u)) & 1u) { t5 = (unsigned)((unsigned)(x0 >> 70) < u2); z5 = (double)(((r0.y << ((unsigned)s0 & 31u))) & 255u); } if (((unsigned)(p1 && 0x234c3fc2u)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                    if ((unsigned)(0x80000000u && (unsigned)((int)(unsigned)s1 < (int)(unsigned)(w0 >> 29)))) break;
                    r0.y ^= (unsigned)!((unsigned)(8u < (unsigned)h0) - ((unsigned)e0 + i0));
                    while (i2++ < 2u && (unsigned)l0) { if (--fuel == 0u) goto done;
                        g1 += (v0 & (unsigned)!(8u ? r0.y : 0x80000000u));
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)w0, (fuel / ((4u % ((unsigned)d0 | 1u)) | 1u)), (unsigned)d0); }
                        break; (void)(6u);
                        if (((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)d0) % (*q0 | 1u))) {
                            g1 += (unsigned)((int)(unsigned)l0 >= (int)0x1a453f5cu);
                            r0.x = r0.y;
                            break; (void)((unsigned)((int)p1 < (int)(unsigned)(signed char)(unsigned)((int)(unsigned)c1 < (int)r0.x)));
                            w0 ^= (unsigned long long)(unsigned)h1 << ((unsigned)((int)(unsigned)f0 >= (int)(m0 << (p1 & 31u))) & 63u);
                            break; (void)((unsigned)((short)(unsigned)c0 > (signed char)g1));
                        }
                        s1 = (int)((unsigned)s1 + 0x7fffffffu);
                        if ((unsigned)d0) break;
                    }
                    c0 = (unsigned char)a0[u1 & 3u];
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        continue; (void)(u3);
                        if ((0x3fc8645u | (unsigned)(short)(1u >> (v0 & 31u)))) break;
                        w0 = w0 * 6364136223846793005ull + (unsigned)!((3u & a0[u1 & 3u]) & u1);
                        if (((unsigned)w0 >> (((unsigned)f0 - 0xdcb898cfu) & 31u))) goto L4;
                        h0 = (short)p0;
                    }
                    if ((7u | 1u)) continue;
                }
                if ((a0[i0 & 3u] / ((unsigned)(*q0 < 2u) | 1u))) continue;
            }
            if ((0x80000000u << ((unsigned)s0 & 31u))) break;
            switch ((unsigned)(1u && (unsigned)h1) & 7u) {
                case 7u: ;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        default: ;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(u0, 0x48df5979u, (((unsigned)c0 - garr[u2 & 7u]) | (unsigned)f0)); }
                        f0 = f0 * 0.5f + (float)(p2 & 255u);
                    }
                    if (0x10000u) break;
                    r0.x = (u1 * (unsigned)((unsigned)(w0 >> 29) && u2));
                    continue; (void)(0x356ff966u);
                }
                garr[(unsigned)h1 & 7u] = garr[u2 & 7u];
                r0.x = p1;
                r0.x = ((2u | g0) ? ((unsigned)c1 << (9u & 31u)) : (unsigned)(w0 >> 29));
                if (budget != 0u) { budget -= 1u; u0 = fn0(8u, (g0 ? garr[i1 & 7u] : 2u), 3u); }
            }
        }
    }
    garr[((unsigned)b0 ^ 0xd5bfc14fu) & 7u] = (a0[u1 & 3u] ^ (unsigned)(w0 >> 29));
    if ((unsigned)(w0 >> 29)) goto L4;
    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(signed char)(0x7fffffffu + (unsigned)l0) % (fuel | 1u)), u2, (unsigned)((short)0u > (signed char)(3u << (v0 & 31u)))); }
    f0 = f0 * 0.5f + (float)((unsigned)((*q0 / ((unsigned)f0 | 1u)) == (unsigned)((unsigned)f0 || (unsigned)(0x80000000u < *q0))) & 255u);
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)l0, -(unsigned)(0x739a49fu == 0x10000u), (unsigned)(u1 && (0x10000u % (i1 | 1u)))); }
    if (0xfa06b58du) {
        garr[(1u & (unsigned)f0) & 7u] = 0xa3cff27au;
    }
    if ((0x60746ff7u | 0x6a9370d9u)) goto L4;
    s0 = (int)(2u & (*mp ? 5u : 0xffffffffu));
    if (9u) goto L0;
    goto L0;
    s0 = (int)((0x80000000u ? (unsigned)l0 : g1) ^ (i2 + 1u));
    if (-(g1 ^ (unsigned)f0)) goto L3;
    w0 ^= (unsigned long long)(unsigned)d0 << (p1 & 63u);
    g0 = (*q0 | ~(unsigned)((int)(unsigned)(w0 >> 29) >= (int)a0[u1 & 3u]));
    if (0xb0e1523bu) {
        d0 = d0 * 0.5 + (double)((unsigned)(0xc3ed36a3u && (*q0 << (i0 & 31u))) & 1023u);
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)b0 < (int)(unsigned)((short)i2 > (signed char)garr[u2 & 7u])), ((unsigned)w0 << ((unsigned)((int)(unsigned)f0 >= (int)9u) & 31u)), (unsigned)d0); }
        if ((p1 >> (fuel & 31u))) {
            w0 ^= (unsigned long long)r0.x << ((unsigned)h1 & 63u);
        }
        u2 = u2 * 0x9e3779b1u + (unsigned)c1;
    } else {
        while (i0++ < 3u && (r0.y ^ i1)) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)((unsigned)s1 % (0x7fffffffu | 1u)) > (signed char)garr[u2 & 7u])) break;
        }
    }
    goto L0;
    r0.y ^= (unsigned)e0;
    u0 = u0 * 0x9e3779b1u + -((unsigned)h0 ? g1 : (9u | 4u));
    { unsigned t6; double z6; if ((r0.y) & 1u) { t6 = u2; z6 = (double)(((unsigned)(signed char)(unsigned)((unsigned)(garr[i1 & 7u] < 0x7fffffffu) < (unsigned)e0)) & 255u); } if ((r0.y) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
        if ((unsigned)((u1 / (0x4a1d8f12u | 1u)) == i1)) {
            i0 = ~(unsigned)((int)(unsigned)f0 >= (int)((unsigned)(0x80000000u == (0x88f7c384u / ((unsigned)w0 | 1u))) + 0x9104b100u)) & 15u;
        }
        if ((unsigned)c1) {
            if ((2u << ((unsigned)e0 & 31u))) goto done;
            q0 = &garr[(unsigned)(short)(unsigned)((int)v0 >= (int)(unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)*mp < (int)g1) < (int)0x5f6a5fffu)) & 7u];
        } else {
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= 0x4c641525u;
                s1 = (int)((unsigned)s1 + (unsigned)!(unsigned)(4u && (unsigned)(*mp < (unsigned)f0)));
                r0.x = ((unsigned)f0 % (m0 | 1u));
                if (budget != 0u) { budget -= 1u; u0 = fn0(0u, (unsigned)((int)(8u - 0xc8f61c6u) >= (int)garr[u2 & 7u]), -(v0 ? g0 : 0x5d5f5a51u)); }
                u1 ^= (unsigned)!(unsigned)((unsigned)((short)*mp > (signed char)0x7fffffffu) || u2);
                if (i0) {
                    if (garr[i1 & 7u]) break;
                    h0 = (short)((unsigned)(r0.y == (unsigned)(6u && u3)) << (i0 & 31u));
                    c1 = (signed char)(unsigned)((int)(1u * *mp) >= (int)0x80000000u);
                    if ((unsigned)(short)(v0 | 0x6bccee7u)) break;
                } else {
                    if (((unsigned)s0 / ((unsigned)s0 | 1u))) break;
                    r0.x = g1;
                    garr[(unsigned)(x0 >> 70) & 7u] = (unsigned)(i1 == (unsigned)((short)(0xffffffffu << ((unsigned)(signed char)(unsigned)((int)0x80000000u < (int)g0) & 31u)) > (signed char)p2));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((8u % (r0.y | 1u)), (unsigned)(2u && (unsigned)(short)((unsigned)f0 & g0)), (0x10000u << ((unsigned)(i0 && 5u) & 31u))); }
                }
            }
            m0 ^= (unsigned)((unsigned)h0 && (unsigned)((int)p2 >= (int)(a0[u1 & 3u] % ((i2 % (v0 | 1u)) | 1u))));
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(0x54a8814fu & 1023u);
                h0 = (short)(unsigned)(signed char)(garr[i1 & 7u] << (((unsigned)l0 & (unsigned)d0) & 31u));
                if (((u1 + a0[i0 & 3u]) + r0.y)) break;
                s0 = (int)(unsigned)x0;
                l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(0xb31336c7u && (unsigned)h0) >= (int)(unsigned)l0));
            }
            garr[p1 & 7u] = (-(((unsigned)s1 & 0xbfc6a55eu) - 0x79b62eedu) % (7u | 1u));
        }
        h1 = (unsigned short)(h1 + ((9u ^ a0[u1 & 3u]) & r0.x));
        if ((unsigned)w0) {
            do { if (--fuel == 0u) goto done;
                { unsigned t7; double z7; if (((unsigned)((int)(unsigned)((unsigned)h1 && (unsigned)h0) < (int)(unsigned)d0)) & 1u) { t7 = ((unsigned)(fuel < *mp) ^ g1); z7 = (double)((9u) & 255u); } if (((unsigned)((int)(unsigned)((unsigned)h1 && (unsigned)h0) < (int)(unsigned)d0)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                    break; (void)((unsigned)(v0 && ~((unsigned)c1 + (unsigned)h0)));
                    u1 ^= 0xef09cf49u;
                    if ((unsigned)s1) goto L2;
                    garr[(*mp >> (garr[u2 & 7u] & 31u)) & 7u] = ((unsigned)s0 << (garr[i1 & 7u] & 31u));
                    garr[(p1 + 0xe36005e1u) & 7u] = ((unsigned)(x0 >> 70) & (unsigned)((int)0x74215202u < (int)(unsigned)h0));
                }
                if (g1) {
                    if ((((unsigned)x0 * i2) >> (0x99d247edu & 31u))) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)l0, (u3 >> (i0 & 31u)), (unsigned)(unsigned char)(unsigned)((int)g1 < (int)p1)); }
                    if (((unsigned)l0 << ((unsigned)d0 & 31u))) break;
                    if (u1) break;
                    if (u1) break;
                } else {
                    if (((unsigned)f0 << ((unsigned)c0 & 31u))) continue;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((u0 & 2u) % (garr[i1 & 7u] | 1u)), (0x6424d23du ^ (garr[i1 & 7u] % ((unsigned)x0 | 1u))), (unsigned)(g1 < ((unsigned)b0 * (unsigned)w0))); }
                }
                if (3u) break;
                if (((r0.y * 0xffffffffu) / ((unsigned)c0 | 1u))) continue;
                q0 = &garr[(g0 % (0u | 1u)) & 7u];
                u0 ^= (u3 / (*q0 | 1u));
            } while (i0++ < 5u && ((unsigned)c0 << ((unsigned)c0 & 31u)));
            if (((r0.x & 3u) - p2)) {
                *q0 = (unsigned)(signed char)(0xde26d3cbu * (unsigned)(0xb60d1669u < (*mp / ((g0 * r0.x) | 1u))));
                if ((unsigned)(0x9d8760ecu && u0)) goto L1;
            }
            c1 = (signed char)((unsigned)b0 / ((unsigned)(short)((unsigned)((short)garr[i1 & 7u] > (signed char)(u3 & m0)) * 2u) | 1u));
        } else {
            while (i0++ < 2u && (unsigned)((int)0x74219340u < (int)(5u * 3u))) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(4u & 255u);
            }
        }
        u1 = (unsigned)(((unsigned)h0 ? (unsigned)h0 : (unsigned)(w0 >> 29)) == (g1 >> (fuel & 31u)));
    }
    u0 ^= ((unsigned)e0 % ((unsigned)((int)(unsigned)((unsigned)d0 == (9u >> (0x94a5d72cu & 31u))) < (int)0xa503af87u) | 1u));
    if (u2) goto done;
    u2 = u2 * 0x9e3779b1u + (0xa44679f9u ^ a0[u1 & 3u]);
    while (i0++ < 7u && (unsigned)(short)(unsigned)(a0[i0 & 3u] < ((unsigned)h1 & (unsigned)h0))) { if (--fuel == 0u) goto done;
        c1 = (signed char)((unsigned)h0 % (i1 | 1u));
        if ((unsigned)(signed char)(unsigned)((int)p0 >= (int)(a0[i0 & 3u] | 0x5e0cd739u))) break;
        if ((unsigned)((int)u3 < (int)g0)) break;
        h0 = (short)(unsigned)s1;
        u2 += *q0;
    }
    switch ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)e0) & 7u) {
        v0 = (unsigned)(short)(u0 - (unsigned)!(unsigned)((unsigned)e0 == ((r0.x | (unsigned)d0) / (i1 | 1u))));
        h0 = (short)((unsigned)(garr[u2 & 7u] || fuel) ^ 0x7fffffffu);
        case 5u: ;
        if (garr[i1 & 7u]) {
            goto L3;
            case 0u: ;
            goto L4;
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u0 = fn0(i1, (r0.x ^ 1u), ((u1 / ((unsigned)h1 | 1u)) % (9u | 1u))); }
    if (-(unsigned)((int)0x80000000u < (int)(unsigned)s1)) {
        do { if (--fuel == 0u) goto done;
            g0 = (unsigned)e0;
            if ((unsigned)b0) {
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)h1 + 0x7fffffffu), (garr[i1 & 7u] + (unsigned)s1), (garr[u2 & 7u] >> (0x5f48e0f8u & 31u))); }
                if ((unsigned)((int)u2 >= (int)(unsigned)(4u == p2))) break;
            }
            if (*mp) continue;
            a0[(unsigned)(unsigned char)(unsigned)((short)(unsigned)c0 > (signed char)(unsigned)s0) & 3u] = ((0x1b212ee3u ^ i2) | (unsigned)s1);
        } while (i0++ < 6u && (unsigned)(x0 >> 70));
        if (p2) {
            if (((0xdccf0e94u * (unsigned)w0) % (u2 | 1u))) {
                w0 = w0 * 6364136223846793005ull + (((unsigned)s1 - i0) - (unsigned)((unsigned)x0 && 0x10000u));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0(u1, ((unsigned)e0 + -(unsigned)((unsigned)d0 < (unsigned)s1)), 6u); }
            b0 = (0x62a9ca5eu * (v0 >> ((unsigned)((unsigned)e0 < *mp) & 31u))) != 0u;
            *q0 += ~(unsigned)((unsigned)x0 < (unsigned)(short)(p2 / (((unsigned)b0 / (0x2aeae8f4u | 1u)) | 1u)));
            if (budget != 0u) { budget -= 1u; u3 = fn1(0x79fb8770u, (unsigned)l0, ((g1 * (unsigned)c1) & p2)); }
        } else {
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(signed char)(p1 * 7u) + u2), (u3 ? r0.x : (unsigned)h1), i2); }
        }
        goto L1;
    } else {
        if ((((unsigned)c1 * 0x10000u) * i1)) goto L0;
    }
    if (((unsigned)((int)v0 < (int)a0[i0 & 3u]) * (unsigned)s1)) goto L4;
    u3 += (0x1e3277eeu % (((unsigned)!(unsigned)((int)u2 >= (int)(unsigned)(x0 >> 70)) >> ((unsigned)(6u || 6u) & 31u)) | 1u));
    if ((0x7fffffffu & (unsigned)(signed char)(8u ^ m0))) goto done;
    if (budget != 0u) { budget -= 1u; u2 = fn0(p1, (unsigned)((short)(unsigned)(signed char)(0x7fffffffu - u3) > (signed char)(unsigned)f0), (0x36680980u + (a0[i0 & 3u] * 4u))); }
    do { if (--fuel == 0u) goto done;
        while (i1++ < 7u && (g0 ^ (a0[i0 & 3u] % (a0[i0 & 3u] | 1u)))) { if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if (((unsigned)(unsigned char)(i0 << ((unsigned)c1 & 31u))) & 1u) { t0 = r0.y; z0 = (double)((((unsigned)(x0 >> 70) ^ (unsigned)x0)) & 255u); } if (((unsigned)(unsigned char)(i0 << ((unsigned)c1 & 31u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                u0 += 0x10000u;
                c0 = (unsigned char)(unsigned)(short)(i2 % ((0xad203209u >> ((unsigned)h0 & 31u)) | 1u));
            }
            if (budget != 0u) { budget -= 1u; u3 = fn1((0x7fffffffu & (unsigned)c1), (unsigned)(signed char)((unsigned)(x0 >> 70) + (unsigned)(w0 >> 29)), a0[i0 & 3u]); }
            m0 ^= (unsigned)h1;
        }
        break; (void)((unsigned)(0x10000u == -(unsigned)((unsigned)f0 < 6u)));
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)e0, (unsigned)(unsigned char)(unsigned)((short)2u > (signed char)(unsigned)c1), 0x80000000u); }
        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(unsigned char)(0xc534fb31u + g1) & u2), ((unsigned)w0 + (unsigned)((int)garr[u2 & 7u] < (int)u1)), (unsigned)((short)i0 > (signed char)1u)); }
    } while (i0++ < 2u && (unsigned)s1);
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        r0.y ^= 1u;
        if ((p0 * (unsigned)((int)(unsigned)(w0 >> 29) >= (int)0x7fffffffu))) {
            h0 = (short)g0;
            *q0 += ((0x10000u & u0) >> ((unsigned)e0 & 31u));
            a0[0xffffffffu & 3u] = u3;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(0xffffffffu || v0)) {
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (u3 == 7u) return (unsigned)w0;
                        if (0xb91d485du) break;
                        { unsigned t1; double z1; if ((r0.y) & 1u) { t1 = (unsigned)((unsigned)s1 && m0); z1 = (double)(((unsigned)((unsigned)(u1 == m0) < v0)) & 255u); } if ((r0.y) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                            if (a0[u1 & 3u]) break;
                            if (budget != 0u) { budget -= 1u; u3 = fn1(g0, (0x10000u >> (4u & 31u)), (unsigned)((short)m0 > (signed char)(i0 & 0x80000000u))); }
                            e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)((int)~(9u * garr[u2 & 7u]) >= (int)g1) >= (int)((unsigned)x0 - 0xffffffffu)) & 1023u);
                            q0 = &garr[(*q0 + (*q0 | (unsigned)c0)) & 7u];
                            if (fuel < 8u) return r0.y;
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(short)(0x80000000u ^ 0x10000u) / (v0 | 1u)), (g0 * 0xc28a574fu), u2); }
                        x0 = x0 * 0x100000001b3ull + 0x10000u;
                    }
                    do { if (--fuel == 0u) goto done;
                        *mp = (unsigned)s1;
                        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)!(1u ^ (unsigned)((int)5u >= (int)0xffffffffu)) == i0) & 1023u);
                        goto L1;
                        if (-(unsigned)(g0 && (u0 >> ((unsigned)b0 & 31u)))) break;
                    } while (i2++ < 6u && fuel);
                    goto L0;
                } else {
                    s1 = (int)((unsigned)s1 + (0u * (unsigned)(0x441249bbu && (unsigned)!((0x10000u + (unsigned)l0) % (garr[u2 & 7u] | 1u)))));
                    s0 = (int)(i0 | (unsigned)((unsigned)b0 == (unsigned)x0));
                    g0 = ((unsigned)l0 - p0);
                }
                r0.x = (unsigned)((unsigned)s0 || (unsigned)((unsigned)c1 < garr[i1 & 7u]));
            }
            { unsigned t2; double z2; if ((u2) & 1u) { t2 = (unsigned)(5u == (unsigned)s1); z2 = (double)(((unsigned)(u1 < (unsigned)(p2 || u1))) & 255u); } if ((u2) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                while (((*mp % (g0 | 1u)) / (*q0 | 1u))) { if (--fuel == 0u) goto done;
                    u0 ^= (unsigned)((int)~(0x76178008u / ((unsigned)(unsigned char)(i1 - v0) | 1u)) >= (int)(unsigned)(u3 && a0[i0 & 3u]));
                    if (r0.y) goto L3;
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        u1 += (unsigned)(((unsigned)(w0 >> 29) - a0[u1 & 3u]) < (p2 | i1));
                        if (budget != 0u) { budget -= 1u; u2 = fn1(3u, 0xffffffffu, (unsigned)(w0 >> 29)); }
                        L1: if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + r0.y;
                    }
                    if ((u3 << (((unsigned)(w0 >> 29) ^ (unsigned)b0) & 31u))) break;
                    u0 = (unsigned)((int)(unsigned)(2u < (p1 | (unsigned)s0)) < (int)(i2 / (p0 | 1u)));
                }
                break; (void)((unsigned)((unsigned)(0x78c674a2u == u2) && 0xffffffffu));
                if ((unsigned)(w0 >> 29)) {
                    if (budget != 0u) { budget -= 1u; u3 = fn1(0xb7d5c29au, r0.y, *mp); }
                    L2: if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (garr[u2 & 7u]) continue;
                        L4: if (--fuel == 0u) goto done;
                        if ((unsigned)(1u == *q0)) continue;
                        e0 = e0 * 0.5L + (long double)(p1 & 1023u);
                        if ((unsigned)b0) goto L2;
                        garr[(0xffffffffu >> (m0 & 31u)) & 7u] = -(unsigned)((int)(u1 / (0x7fffffffu | 1u)) >= (int)(unsigned)((short)r0.y > (signed char)(unsigned)b0));
                    }
                    switch ((unsigned)(short)(a0[u1 & 3u] % (p1 | 1u)) & 7u) {
                        x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)((short)p2 > (signed char)(unsigned)l0) < (int)i1);
                    }
                }
                c1 = (signed char)((unsigned)(x0 >> 70) * m0);
            }
            if ((unsigned)l0) goto L4;
        } else {
            break; (void)(*q0);
            do { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)((unsigned)((unsigned)(((unsigned)h0 & (unsigned)c1) < (unsigned)w0) < 0xffffffffu) || 8u);
                    c0 = (unsigned char)((0xffffffffu & a0[i0 & 3u]) / ((unsigned)d0 | 1u));
                    switch ((unsigned)x0 & 7u) {
                        l0 = (long)((unsigned long)l0 + 7u);
                        continue; (void)((unsigned)(short)(0x10000u << ((unsigned)(x0 >> 70) & 31u)));
                        if (0x7fffffffu) continue;
                        x0 = x0 * 0x100000001b3ull + (unsigned)((fuel ^ (unsigned)(w0 >> 29)) == (unsigned)l0);
                        case 1u: ;
                    }
                    c1 = (signed char)((unsigned)(signed char)(u1 / (2u | 1u)) ? (unsigned)d0 : (unsigned)(0x10000u == 0xc9794e50u));
                    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        u3 += ((unsigned)(signed char)(unsigned)(0u == m0) << ((unsigned)(u2 || (unsigned)s1) & 31u));
                        f0 = f0 * 0.5f + (float)(((r0.y ? ((unsigned)l0 + 0xffffffffu) : garr[u2 & 7u]) + 2u) & 255u);
                        h0 = (short)(unsigned)s1;
                        break; (void)((unsigned)c0);
                        break; (void)((unsigned)(m0 && 0u));
                    }
                }
                u0 = u0 * 0x9e3779b1u + (a0[i0 & 3u] >> ((unsigned)((garr[u2 & 7u] / (9u | 1u)) || (unsigned)(short)(unsigned)(0xffffffffu && p0)) & 31u));
                break; (void)((0x112176c0u + 0x709527ddu));
                if (((unsigned)(signed char)(0x7fffffffu % ((unsigned)f0 | 1u)) * 0xa236dd58u)) break;
                h0 = (short)(unsigned)!((7u / ((unsigned)(x0 >> 70) | 1u)) ^ (unsigned)h0);
                h1 = (unsigned short)(h1 + ((u3 << (m0 & 31u)) * ((unsigned)l0 | u0)));
            } while (i1++ < 5u && (0xffffffffu + 0x7fffffffu));
            u2 ^= ((r0.x ? (unsigned)(x0 >> 70) : g0) / ((0xffffffffu << ((unsigned)w0 & 31u)) | 1u));
        }
        l0 = (long)((unsigned long)l0 + ~((garr[u2 & 7u] % (((unsigned)(w0 >> 29) ? (unsigned)w0 : a0[u1 & 3u]) | 1u)) & (unsigned)h1));
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        q0 = &garr[(unsigned)(x0 >> 70) & 7u];
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(i2 < (u0 + 0xb586e494u))) {
                for (;;) { if (--fuel == 0u) goto done;
                    *q0 = ((unsigned)(0xd0dc626du || a0[u1 & 3u]) ? (unsigned)d0 : g1);
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)i0 > (signed char)9u), (i0 * m0), *q0); }
                }
                *q0 += 0xe5f0a6e9u;
                c1 = (signed char)(unsigned)(unsigned char)(~(a0[i0 & 3u] ^ (unsigned)((unsigned)w0 < a0[u1 & 3u])) / (((unsigned)(w0 >> 29) - *q0) | 1u));
                s0 = (int)(unsigned)(w0 >> 29);
            } else {
                b0 = (i0 ? v0 : p0) != 0u;
            }
            r0.y ^= (unsigned)(g0 && 0x10000u);
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)s1 << (((i1 - (5u ? i2 : u1)) - v0) & 63u);
                if ((u3 % ((unsigned)s1 | 1u))) continue;
                if (budget != 0u) { budget -= 1u; u3 = fn0((3u >> (0x10000u & 31u)), ~((unsigned)b0 * g0), ((unsigned)(short)(unsigned)((unsigned)h1 || (unsigned)(w0 >> 29)) | i2)); }
                if (fuel < 8u) return (unsigned)((int)8u >= (int)((0x3aa7bbf6u >> ((unsigned)((unsigned)c0 < r0.x) & 31u)) | 0x80000000u));
                if (budget != 0u) { budget -= 1u; u0 = fn0((a0[u1 & 3u] + r0.x), ((i1 >> (0x253ffd0au & 31u)) ^ p0), ((unsigned)h1 ? (unsigned)c1 : (unsigned)c1)); }
            }
            h0 = (short)((((unsigned)e0 - u1) + (u3 + (unsigned)l0)) - 0x51292a4au);
        } while (i1++ < 2u && 2u);
        if (budget != 0u) { budget -= 1u; u0 = fn1((r0.y * (0x7fffffffu >> (0xe46d784eu & 31u))), ((unsigned)h0 * (unsigned)w0), (unsigned)(signed char)(unsigned)(g1 == (0xffffffffu / (0x602ad77eu | 1u)))); }
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((0xf8bd4cf6u % ((0x10000u | p0) | 1u))) break;
            if ((unsigned)((g1 ^ 0xffffffffu) == 0x7fffffffu)) break;
            if ((unsigned)((5u | i0) || 0x7fffffffu)) goto L3;
            m0 ^= (0x80000000u | g1);
        }
        if ((unsigned)(short)(unsigned)((int)(unsigned)h0 < (int)(u3 & (unsigned)w0))) break;
    }
    switch (0x49c1c526u & 7u) {
        if (budget != 0u) { budget -= 1u; u1 = fn1(((v0 >> (0x8ad954a0u & 31u)) % (0x9c44ab8u | 1u)), (v0 & a0[u1 & 3u]), 5u); }
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(short)((unsigned)s0 / (*q0 | 1u))) {
                g1 += (unsigned)(-(unsigned)((short)(0xca1ae66eu / ((unsigned)x0 | 1u)) > (signed char)p2) == g1);
                if (u3 == 7u) return (unsigned)((unsigned)s0 == (unsigned)(signed char)((0x10000u | r0.y) | ((unsigned)e0 / (0xd7ebaf8eu | 1u))));
                case 1u: ;
                u0 += (unsigned)((unsigned)d0 || ((u2 * 0x789b8a60u) % (garr[i1 & 7u] | 1u)));
            } else {
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)h0 - *mp), r0.y, -(0x7a9f9fa9u / ((unsigned)c1 | 1u))); }
            }
            s1 = (int)((unsigned)s1 + ((0u / (0x7fffffffu | 1u)) + 8u));
            u0 = u0 * 0x9e3779b1u + (unsigned)!(i1 / (fuel | 1u));
        }
        if (((unsigned)b0 + (i2 - a0[u1 & 3u]))) {
            if ((unsigned)((unsigned)c1 || (unsigned)h0)) {
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(unsigned char)(unsigned)((short)~(*mp << (u2 & 31u)) > (signed char)0x10000u)) break;
                    for (;;) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)(unsigned)((*q0 - (unsigned)c0) || (unsigned)f0);
                    }
                    g0 = u0;
                    c0 = (unsigned char)((((unsigned)f0 ? 0xc371ee1cu : p0) * (unsigned)l0) - (unsigned)e0);
                    g1 += (unsigned)f0;
                    case 3u: ;
                }
                while (1u) { if (--fuel == 0u) goto done;
                    h0 = (short)(unsigned)((unsigned)(((unsigned)l0 % ((unsigned)h1 | 1u)) || *mp) && garr[u2 & 7u]);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(garr[i1 & 7u], (unsigned)(short)(unsigned)((int)0xe28d4068u >= (int)g1), (unsigned)((short)(unsigned)f0 > (signed char)(unsigned)((int)(unsigned)l0 >= (int)(unsigned)(w0 >> 29)))); }
                    default: ;
                    case 2u: ;
                    garr[0x7fffffffu & 7u] = (unsigned)(0xf146c464u < *mp);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(r0.x, ((unsigned)((short)0xffffffffu > (signed char)u2) + u3), (unsigned)s0); }
                }
                l0 = (long)((unsigned long)l0 + (9u * 0x80000000u));
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(((0x7675ed35u | (unsigned)h1) % (0x10000u | 1u)), (((unsigned)h0 % ((unsigned)s0 | 1u)) >> (u2 & 31u)), *mp); }
                    case 0u: ;
                    if (p2) {
                        if ((p1 & (unsigned)h1)) continue;
                        h0 = (short)(0x10000u % ((unsigned)((short)(unsigned)((short)i0 > (signed char)i2) > (signed char)0x7fffffffu) | 1u));
                        if ((unsigned)(x0 >> 70)) goto L3;
                    }
                } while (i0++ < 6u && (r0.x ? garr[u2 & 7u] : u2));
                case 6u: ;
            } else {
                h0 = (short)((unsigned)!(unsigned)((int)g1 < (int)0xa5708972u) & (unsigned)(*q0 == (g1 | g1)));
                v0 = (unsigned)l0;
                case 4u: ;
                u0 = (i2 * 0x7fffffffu);
            }
            i1 = (-(unsigned)((short)((unsigned)s1 << ((unsigned)w0 & 31u)) > (signed char)a0[u1 & 3u]) - (unsigned)b0) & 15u;
            for (;;) { if (--fuel == 0u) goto done;
                case 7u: ;
                c0 = (unsigned char)(((unsigned)h0 & garr[u2 & 7u]) % ((i1 & (unsigned)l0) | 1u));
                break;
            }
            { unsigned t3; double z3; if ((((r0.x % (i1 | 1u)) / ((unsigned)x0 | 1u))) & 1u) { t3 = (unsigned)(u2 && (unsigned)e0); z3 = (double)((u2) & 255u); } if ((((r0.x % (i1 | 1u)) / ((unsigned)x0 | 1u))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                { unsigned t4; double z4; if (((unsigned)((unsigned)(x0 >> 70) && (unsigned)l0)) & 1u) { t4 = (unsigned)f0; z4 = (double)((9u) & 255u); } if (((unsigned)((unsigned)(x0 >> 70) && (unsigned)l0)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    g0 = (unsigned)(((1u + (unsigned)(w0 >> 29)) << ((unsigned)s0 & 31u)) < g0);
                    s1 = (int)((unsigned)s1 + (unsigned)(g0 < (unsigned)((int)g1 < (int)(unsigned)(signed char)(i1 | (unsigned)d0))));
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(fuel && a0[u1 & 3u]), 0x7fffffffu, (unsigned)((int)(unsigned)s1 < (int)(unsigned)w0)); }
                    u1 = u1 * 0x9e3779b1u + garr[u2 & 7u];
                    x0 = x0 * 0x100000001b3ull + (unsigned)(short)(~(unsigned)(v0 < (unsigned)(0u && p1)) - i1);
                    q0 = &garr[-(i0 ^ p2) & 7u];
                }
                l0 = (long)((unsigned long)l0 + *mp);
                break;
                if (i1) {
                    r0.y ^= (unsigned)(signed char)(i2 % (u0 | 1u));
                    if (4u) goto L0;
                }
                for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (~(unsigned)((unsigned)x0 && (unsigned)e0)) {
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)(u1 << (a0[i0 & 3u] & 31u)), (unsigned)(short)((unsigned)(short)(i2 - 0x47df9181u) ^ (unsigned)h0), (unsigned)((short)u2 > (signed char)(unsigned)d0)); }
                    } else {
                        q0 = &garr[((unsigned)((short)p0 > (signed char)(unsigned)w0) >> (p0 & 31u)) & 7u];
                        u1 ^= (0xbe2c8340u >> (((0xe659bc03u / (r0.x | 1u)) + r0.x) & 31u));
                        w0 = w0 * 6364136223846793005ull + (unsigned)((int)(a0[i0 & 3u] * (unsigned)e0) >= (int)0xf605fd3du);
                    }
                    s1 = (int)((unsigned)s1 + 0xffffffffu);
                    *q0 += (unsigned)((int)(unsigned)c0 >= (int)((unsigned)(garr[u2 & 7u] && (unsigned)((short)(unsigned)f0 > (signed char)p0)) | 0x1d3a5b07u));
                }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)x0, ((unsigned)c0 | (unsigned)((int)(unsigned)b0 < (int)0x463cab73u)), (unsigned)((unsigned)l0 < (unsigned)l0)); }
        }
    }
    h0 = (short)((unsigned)((short)0xe52389a1u > (signed char)(unsigned)c0) - g0);
    if (((unsigned)((int)garr[u2 & 7u] >= (int)0xceca575bu) % (i2 | 1u))) goto L3;
    a0[(unsigned)((unsigned)s0 < 0x8f602befu) & 3u] = (unsigned)s1;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)l0 >= (int)i1)) {
            i2 = 0xffffffffu & 15u;
        } else {
            h1 = (unsigned short)(h1 + (unsigned)(0u == -((unsigned)(i0 && i0) >> (0x80000000u & 31u))));
            if (((unsigned)s1 | (unsigned)x0)) break;
        }
        if ((a0[i0 & 3u] % ((unsigned)c1 | 1u))) goto L0;
        u0 = u0 * 0x9e3779b1u + (r0.y >> (v0 & 31u));
    }
    if (((unsigned)h0 + g0)) {
        if (u3) {
            r0.y ^= ((unsigned)((unsigned)(v0 < a0[i0 & 3u]) || ~(unsigned)(0x10000u && m0)) - u1);
            if ((0x7fffffffu * -(unsigned)(u1 && (unsigned)d0))) goto L2;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(v0 && (unsigned)s0), (i0 * (unsigned)((unsigned)x0 < p0)), (0x7fffffffu - 0x7fffffffu)); }
                m0 ^= (unsigned)(~((unsigned)(unsigned char)((unsigned)(x0 >> 70) & p0) + 0xffffffffu) < (0xc32909ceu + (unsigned)e0));
                if (0x6af6da2cu) goto L0;
                if ((unsigned)(short)(8u << (0x80000000u & 31u))) continue;
                { unsigned t5; double z5; if (((unsigned)c1) & 1u) { t5 = ((unsigned)(x0 >> 70) << (0x92c2cca8u & 31u)); z5 = (double)((r0.x) & 255u); } if (((unsigned)c1) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (u3 == 7u) return p0;
                    }
                    if ((i1 * 6u)) break;
                    if ((fuel % (((unsigned)s1 / (m0 | 1u)) | 1u))) break;
                    *q0 = (6u ^ 0xffffffffu);
                }
            } while (i0++ < 3u && (unsigned)((int)i2 < (int)(unsigned)(w0 >> 29)));
            d0 = d0 * 0.5 + (double)((0x17f5d438u ^ u1) & 1023u);
        }
        do { if (--fuel == 0u) goto done;
            *q0 += ~(0u * (unsigned)(0xffffffffu == 4u));
        } while (i0++ < 6u && (unsigned)c0);
    }
    if (u0) {
        if ((unsigned)h0) {
            { unsigned t6; double z6; if ((u0) & 1u) { t6 = (*mp << (6u & 31u)); z6 = (double)((((unsigned)(x0 >> 70) + g1)) & 255u); } if ((u0) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                if ((r0.y & *q0)) goto done;
                if (garr[i1 & 7u]) goto L0;
                if (budget != 0u) { budget -= 1u; u0 = fn0((2u - r0.x), 4u, ((unsigned)((int)(unsigned)h0 >= (int)(unsigned)c0) * (unsigned)(w0 >> 29))); }
                if ((unsigned)(short)(0xe516c52cu % (0x6a36b16fu | 1u))) goto L3;
                if (((unsigned)l0 / ((unsigned)(x0 >> 70) | 1u))) goto L2;
                if ((unsigned)f0) {
                    e0 = e0 * 0.5L + (long double)((p2 >> (0xffffffffu & 31u)) & 1023u);
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((short)a0[u1 & 3u] > (signed char)0u) == (0x8fe46ad4u & (unsigned)c0)));
                } else {
                    if ((0xc2f3a1f7u - v0)) {
                        goto L2;
                    } else {
                        r0.x = ~(unsigned)(0xdcb0833cu || (unsigned)s0);
                        h0 = (short)(p2 ? u1 : (unsigned)(*q0 || i0));
                        if (0xffffffffu) goto L4;
                        if ((0x85f79e7bu % (i2 | 1u))) goto L2;
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(garr[i1 & 7u], (unsigned)((int)((unsigned)x0 - 6u) < (int)(unsigned)(w0 >> 29)), (m0 >> (0x83b9f39cu & 31u))); }
                    d0 = d0 * 0.5 + (double)((unsigned)b0 & 1023u);
                    if ((unsigned)s1) {
                        if (5u) goto done;
                        b0 = ((r0.y - (g0 + (unsigned)b0)) ^ *q0) != 0u;
                    }
                }
            }
            d0 = d0 * 0.5 + (double)((unsigned)(i2 || (unsigned)(p2 < (unsigned)(1u && (unsigned)(0x7fffffffu || (unsigned)(w0 >> 29))))) & 1023u);
            if (0x7fffffffu) goto L0;
            goto L3;
        } else {
            *q0 = (-(unsigned)(p1 && (unsigned)e0) >> ((unsigned)(short)((2u & (unsigned)x0) * (unsigned)f0) & 31u));
            l0 = (long)((unsigned long)l0 + (unsigned)((int)m0 >= (int)(unsigned)b0));
            while (i0++ < 5u && ((unsigned)c1 ^ (unsigned)e0)) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return ((unsigned)((short)(g0 << ((unsigned)l0 & 31u)) > (signed char)0xffffffffu) & garr[i1 & 7u]);
                if ((unsigned)(r0.x < (g0 + (unsigned)s0))) break;
                q0 = &garr[(unsigned)(unsigned char)(0x488c155du - *mp) & 7u];
                if (((unsigned)(w0 >> 29) * p1)) break;
                e0 = e0 * 0.5L + (long double)((4u & ((unsigned)e0 | 0x80000000u)) & 1023u);
            }
        }
        do { if (--fuel == 0u) goto done;
            garr[r0.y & 7u] = ((unsigned)((short)(unsigned)f0 > (signed char)((unsigned)(w0 >> 29) - u2)) * 4u);
            if ((*q0 * 0x10000u)) break;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(0x10000u < (unsigned)h1)) break;
                c1 = (signed char)(unsigned)((short)0xbb294b09u > (signed char)0xffffffffu);
                u3 = u3 * 0x9e3779b1u + (p0 | *q0);
                v0 = (unsigned)((unsigned)x0 && (unsigned)s1);
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)0x10000u < (int)(unsigned)c1), 0xfa5df90fu, (unsigned)(short)((unsigned)(fuel < (unsigned)d0) >> (p2 & 31u))); }
            break; (void)(((unsigned)(short)(u2 & (unsigned)c1) / ((unsigned)s0 | 1u)));
            *q0 += (p1 | u2);
        } while (i0++ < 5u && *mp);
        garr[(unsigned)((unsigned)x0 == 0x80000000u) & 7u] = ((unsigned)(g0 && 0x7fffffffu) - (unsigned)((int)(unsigned)s0 >= (int)fuel));
    } else {
        x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)((unsigned)(unsigned char)(p1 >> (u1 & 31u)) < (u3 << (r0.y & 31u))) >= (int)*q0);
        w0 ^= (unsigned long long)garr[u2 & 7u] << (r0.y & 63u);
        if (budget != 0u) { budget -= 1u; u2 = fn1(~(0x80000000u ? (unsigned)e0 : 0xdbb864edu), u0, ((u3 * *q0) | fuel)); }
        if ((unsigned)((short)g0 > (signed char)(unsigned)w0)) goto L2;
    }
    if ((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)(w0 >> 29))) goto L3;
    g0 = (u3 / ((unsigned)(x0 >> 70) | 1u));
    l0 = (long)((unsigned long)l0 + (((unsigned)(signed char)((unsigned)h0 * *mp) ? p0 : i2) * 0x7fffffffu));
    *mp = ~(unsigned)((unsigned)((short)(unsigned)c1 > (signed char)(unsigned)((a0[i0 & 3u] - 0x80000000u) < (unsigned)s0)) < (unsigned)l0);
    r0.x = (unsigned)(0x20ca27fdu || (unsigned)f0);
    if ((fuel | 0x7c0f02b7u)) goto done;
    c0 = (unsigned char)(unsigned)((int)p0 < (int)(unsigned)((short)p0 > (signed char)u1));
    w0 ^= (unsigned long long)(unsigned)(x0 >> 70) << (r0.y & 63u);
    if ((unsigned)h0) {
        if ((garr[i1 & 7u] & ((unsigned)(x0 >> 70) % (5u | 1u)))) goto done;
    }
    c0 = (unsigned char)(unsigned)(((unsigned)c1 << (0x7fffffffu & 31u)) < (unsigned)(g1 || 9u));
    g1 += (unsigned)f0;
    if ((unsigned)b0) goto L4;
    h1 = (unsigned short)(h1 + ((0x18fb5e3cu * m0) >> ((0xe57115fdu - p1) & 31u)));
    x0 = x0 * 0x100000001b3ull + (unsigned)((short)5u > (signed char)u3);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)((short)u1 > (signed char)(unsigned)f0) & 7u) {
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return (unsigned)((short)(unsigned)f0 > (signed char)(fuel & (*mp + g0)));
                w0 ^= (unsigned long long)(unsigned)(short)((unsigned)b0 / (u3 | 1u)) << ((v0 ? (unsigned)w0 : u1) & 63u);
                w0 ^= (unsigned long long)6u << (~((unsigned)((int)0xdfccc917u >= (int)0xb3160f18u) ^ ((unsigned)(u2 || p1) | g1)) & 63u);
                if (u1) continue;
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    while (i0++ < 2u && (8u << (*mp & 31u))) { if (--fuel == 0u) goto done;
                        if (i0) break;
                        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(i0 < (unsigned)w0) * (unsigned)c0), (4u >> (i2 & 31u)), (unsigned)((int)0xb8a24b3bu >= (int)~(i0 + u3))); }
                        case 1u: ;
                        switch ((0x44133bceu + (0xa2005223u / (4u | 1u))) & 7u) {
                            case 1u: ;
                            default: ;
                            case 5u: ;
                        }
                    }
                    case 2u: ;
                    b0 = (u1 >> (((unsigned)(signed char)((unsigned)h0 ? 8u : p0) >> (0xfa5ca526u & 31u)) & 31u)) != 0u;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)e0 - (unsigned)((unsigned)e0 || i0)), (unsigned)((0x7fffffffu | (unsigned)f0) || v0), (((unsigned)h1 ^ p0) / (a0[u1 & 3u] | 1u))); }
                }
            }
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 = (unsigned)((9u ^ (unsigned)l0) == *q0);
                if ((unsigned)((unsigned)h1 == 0x10000u)) break;
                l0 = (long)((unsigned long)l0 + ~(unsigned)(((unsigned)c0 >> (0xdc384d19u & 31u)) || u0));
                u2 += (((unsigned)c0 ^ (unsigned)c1) & 0x31c22169u);
                continue; (void)((unsigned)((int)(unsigned)c0 < (int)i1));
                l0 = (long)((unsigned long)l0 + p0);
            }
        }
        g0 = r0.y;
        do { if (--fuel == 0u) goto done;
            v0 = ((p1 * i0) >> ((unsigned)f0 & 31u));
            if (budget != 0u) { budget -= 1u; u2 = fn1(0x7fffffffu, *q0, (*mp + (unsigned)(w0 >> 29))); }
            g0 = garr[i1 & 7u];
            *q0 = (unsigned)((int)v0 >= (int)-(garr[i1 & 7u] * ~((1u % (g0 | 1u)) & p2)));
            s0 = (int)u0;
        } while (i1++ < 4u && (*mp >> ((unsigned)((int)2u >= (int)p0) & 31u)));
        break; (void)((unsigned)(p0 < a0[u1 & 3u]));
    }
    u2 = u2 * 0x9e3779b1u + *q0;
    w0 ^= (unsigned long long)(0x10000u << (7u & 31u)) << ((unsigned)((unsigned)((unsigned)((unsigned)(x0 >> 70) || (unsigned)l0) || (unsigned)(g1 || 2u)) || i0) & 63u);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        v0 = v0;
        q0 = &garr[(unsigned)(u3 && 0x7fffffffu) & 7u];
        s1 = (int)((unsigned)s1 + ~(g0 >> ((0x80000000u % (a0[u1 & 3u] | 1u)) & 31u)));
        s1 = (int)((unsigned)s1 + ((unsigned)s1 ^ p1));
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch (0xd2e51983u & 7u) {
                x0 = x0 * 0x100000001b3ull + (unsigned)(0x10000u < u0);
                case 4u: ;
                if ((unsigned)x0) {
                    m0 ^= g1;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((garr[u2 & 7u] + (unsigned)(x0 >> 70)), (unsigned)(6u == *mp), (unsigned)((unsigned)f0 < 0xbc2ce2abu)); }
                    default: ;
                    case 6u: ;
                } else {
                    if ((unsigned)(0x7fffffffu < 5u)) {
                        do { if (--fuel == 0u) goto done;
                            a0[0xffffffffu & 3u] = (unsigned)((unsigned)c1 == a0[i0 & 3u]);
                            continue; (void)(m0);
                        } while (i2++ < 2u && ((unsigned)d0 ^ 8u));
                    } else {
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)b0 && (u2 & g0)), (g0 - (unsigned)h1), (unsigned)(short)(0x8e9b857cu * (unsigned)(x0 >> 70))); }
                    }
                    switch ((-(unsigned)((unsigned)b0 < a0[u1 & 3u]) >> (i1 & 31u)) & 7u) {
                        for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                            case 1u: ;
                            u1 = u1 * 0x9e3779b1u + (unsigned)((short)(2u / (*q0 | 1u)) > (signed char)(unsigned)f0);
                            m0 ^= (unsigned)(unsigned char)(garr[i1 & 7u] ? g1 : 0x7fffffffu);
                            case 3u: ;
                        }
                        default: ;
                        v0 = (unsigned)((unsigned)s1 && 4u);
                        if (u2) break;
                        garr[0x462e42a6u & 7u] = (unsigned)f0;
                        g0 = ((unsigned)e0 + (unsigned)l0);
                    }
                }
                h1 = (unsigned short)(h1 + 0xffffffffu);
                s0 = (int)((unsigned)(short)(unsigned)((unsigned)((int)(unsigned)s1 < (int)r0.y) < (i1 - (unsigned)c0)) / (g1 | 1u));
            }
            f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)((short)(0xfd2c4b03u % (u3 | 1u)) > (signed char)(unsigned)d0) | (unsigned)b0) && *q0) & 255u);
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            u3 ^= ((unsigned)((0xee56dd52u * ((unsigned)f0 + g0)) < r0.x) % (u2 | 1u));
        }
    }
    if (((unsigned)(signed char)((unsigned)d0 % (0x80000000u | 1u)) * r0.y)) goto L3;
    switch (0x7fffffffu & 7u) {
        u0 ^= (unsigned)w0;
        if (budget != 0u) { budget -= 1u; u3 = fn0(-(unsigned)(p1 && g0), 3u, (-(unsigned)(i1 || g1) | (unsigned)(x0 >> 70))); }
        if ((u3 ^ r0.x)) goto L0;
        garr[(unsigned)b0 & 7u] = (0x7fffffffu << (*mp & 31u));
        case 2u: ;
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(~(r0.x * u3) || (unsigned)c1)) break;
        g1 += (unsigned)((unsigned)((int)0xed05d793u < (int)u0) && (p1 | v0));
        if ((unsigned)((short)(garr[i1 & 7u] - u2) > (signed char)0x36b43057u)) goto L2;
        if ((unsigned)c0) {
            h1 = (unsigned short)(h1 + 0x72f5c356u);
            if ((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)((unsigned)(w0 >> 29) == i2))) break;
        } else {
            while (i1++ < 5u && (unsigned)(unsigned char)(unsigned)(*mp || u0)) { if (--fuel == 0u) goto done;
                v0 = (unsigned)((unsigned)e0 == 0x10000u);
                break; (void)(m0);
                i2 = (garr[u2 & 7u] | (unsigned)(p0 < (r0.x & ((unsigned)(w0 >> 29) ^ 1u)))) & 15u;
                u0 = ((unsigned)((unsigned)((int)p1 < (int)u1) || (unsigned)c0) - (unsigned)(w0 >> 29));
                if (budget != 0u) { budget -= 1u; u1 = fn0(((0xb2829949u * g1) / (garr[i1 & 7u] | 1u)), ((u0 + (unsigned)x0) % ((unsigned)s0 | 1u)), u2); }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((0xe46d5c9eu | (unsigned)e0) == p0), (unsigned)((2u >> (p0 & 31u)) && 0x4e184643u), 0u); }
            if ((unsigned)((int)p1 >= (int)(unsigned)b0)) break;
            while ((unsigned)!((unsigned)h0 >> (4u & 31u))) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return (((unsigned)c0 ^ r0.y) & (unsigned)s0);
                w0 ^= (unsigned long long)(unsigned)s1 << ((unsigned)(unsigned char)((unsigned)((short)(0x7fffffffu >> (0x541fbdbau & 31u)) > (signed char)4u) + (unsigned)((unsigned)w0 && (unsigned)d0)) & 63u);
            }
        }
        m0 ^= (unsigned)((unsigned)!(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)w0) || (8u * garr[u2 & 7u]));
        break; (void)((unsigned)(x0 >> 70));
    }
    m0 ^= (*mp + r0.x);
    w0 = w0 * 6364136223846793005ull + (unsigned)x0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    f0 = f0 * 0.5f + (float)((unsigned)((int)0x4a8d01a0u < (int)((8u << (garr[i1 & 7u] & 31u)) << ((p0 * 7u) & 31u))) & 255u);
    i0 = ((unsigned)f0 ^ (garr[i1 & 7u] - (unsigned)((int)(unsigned)((int)u1 >= (int)0x59969ea1u) >= (int)(unsigned)b0))) & 15u;
    switch (((unsigned)((int)0x7fffffffu >= (int)0x83a51a37u) >> (0x10000u & 31u)) & 7u) {
        case 7u: ;
        case 5u: ;
        g0 = (unsigned)(m0 || (unsigned)(signed char)(unsigned)((0x7fffffffu - 7u) || 0x80000000u));
        u3 ^= ((unsigned)((int)i2 >= (int)a0[i0 & 3u]) - u1);
        if (fuel < 8u) return a0[i0 & 3u];
    }
    while (i0++ < 4u && 3u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + ((unsigned)(w0 >> 29) ^ -(r0.y ^ a0[u1 & 3u])));
        while (i1++ < 5u && (unsigned)(short)(unsigned)((r0.x & 0x33694a99u) == (unsigned)c0)) { if (--fuel == 0u) goto done;
            if ((unsigned)(u0 && 0xb44bb382u)) goto L0;
            r0.x = (unsigned)(unsigned char)(p0 % (*q0 | 1u));
        }
        { unsigned t0; double z0; if ((0xe96baf24u) & 1u) { t0 = (p2 - garr[u2 & 7u]); z0 = (double)(((0x7fffffffu ? 0x7fffffffu : fuel)) & 255u); } if ((0xe96baf24u) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            do { if (--fuel == 0u) goto done;
                if ((0xffffffffu / ((unsigned)(0x7fffffffu || 0x7fffffffu) | 1u))) break;
            } while (i1++ < 6u && (unsigned)(signed char)((unsigned)x0 ? m0 : *q0));
        }
    }
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)((int)i0 >= (int)i0) << (((0x7fffffffu << (8u & 31u)) & (unsigned)((int)(unsigned)h0 >= (int)((unsigned)(x0 >> 70) >> ((unsigned)x0 & 31u)))) & 63u);
            e0 = e0 * 0.5L + (long double)((8u << ((unsigned)((int)u2 >= (int)(unsigned)h0) & 31u)) & 1023u);
            if ((unsigned)(signed char)(unsigned)(0x10000u == 0x73642bdu)) {
                do { if (--fuel == 0u) goto done;
                    garr[(unsigned)b0 & 7u] = ((unsigned)((int)garr[u2 & 7u] < (int)a0[u1 & 3u]) >> (-((unsigned)h1 >> ((unsigned)(x0 >> 70) & 31u)) & 31u));
                    { unsigned t1; double z1; if (((unsigned)((unsigned)w0 < u0)) & 1u) { t1 = (unsigned)!(0x91f16959u % (u1 | 1u)); z1 = (double)(((((unsigned)(w0 >> 29) | m0) * (unsigned)(x0 >> 70))) & 255u); } if (((unsigned)((unsigned)w0 < u0)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                        if (budget != 0u) { budget -= 1u; u2 = fn1(9u, r0.y, (u0 % (((unsigned)x0 - (unsigned)s1) | 1u))); }
                        l0 = (long)((unsigned long)l0 + ((unsigned)(w0 >> 29) ^ 3u));
                        if ((p2 ? (unsigned)(x0 >> 70) : r0.x)) break;
                        if ((unsigned)(3u < (i1 - 0x10000u))) break;
                    }
                    L0: if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(unsigned)c1 << (((unsigned)d0 | p2) & 63u);
                } while (i2++ < 5u && (0x1b6bd8f3u + g1));
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((0x91a2fe5au * (unsigned)w0)) break;
                    break; (void)(a0[i0 & 3u]);
                    if (~(unsigned)((int)p2 < (int)(unsigned)e0)) continue;
                    a0[(unsigned)(unsigned char)((unsigned)f0 * m0) & 3u] = (7u | (unsigned)d0);
                    w0 = w0 * 6364136223846793005ull + garr[i1 & 7u];
                    *mp = (g0 | (0x7fffffffu & 0x10000u));
                }
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    a0[i1 & 3u] = (unsigned)(i0 && (unsigned)c1);
                    w0 = w0 * 6364136223846793005ull + (a0[u1 & 3u] ^ ((unsigned)(x0 >> 70) ? (g0 + 0xffffffffu) : garr[i1 & 7u]));
                    L1: if (--fuel == 0u) goto done;
                    g0 = 0xbb690b84u;
                    if (i0) {
                        *q0 = ((0xffffffffu ? 0x7fffffffu : 0x8155454u) * 5u);
                        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)h1, (unsigned)((unsigned)d0 && (r0.y & p0)), (unsigned)((int)0x6d69274au >= (int)(unsigned)(0xffffffffu == m0))); }
                        s0 = (int)(garr[u2 & 7u] - 1u);
                        r0.x = (unsigned)l0;
                        h0 = (short)(((unsigned)(x0 >> 70) / (0x171bc30bu | 1u)) << ((unsigned)c1 & 31u));
                        L2: if (--fuel == 0u) goto done;
                    }
                }
            } else {
                a0[*q0 & 3u] = (unsigned)(u0 < (4u >> (r0.y & 31u)));
                a0[(0xd8d8c77cu << (1u & 31u)) & 3u] = (0x1bcec2f5u << (((unsigned)x0 | (u0 << (fuel & 31u))) & 31u));
            }
        } while (i1++ < 6u && 0xaaa8a126u);
        goto L2;
        garr[(a0[i0 & 3u] | g1) & 7u] = (((unsigned)(x0 >> 70) & (unsigned)w0) & (unsigned)((short)u0 > (signed char)0x7fffffffu));
    } while (i0++ < 5u && v0);
    while (i0++ < 7u && -(unsigned)((int)(unsigned)w0 >= (int)i2)) { if (--fuel == 0u) goto done;
        goto L0;
    }
    q0 = &garr[(unsigned)(w0 >> 29) & 7u];
    L3: if (--fuel == 0u) goto done;
    if (0xffffffffu) {
        x0 = x0 * 0x100000001b3ull + (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)!(((unsigned)w0 << (g0 & 31u)) ^ 8u));
    }
    h1 = (unsigned short)(h1 + (((unsigned)b0 % (u3 | 1u)) & (unsigned)l0));
    if ((unsigned)((unsigned)d0 && ~(unsigned)(0x7fffffffu && (unsigned)c0))) {
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(((unsigned)s0 * *mp) && 0x7fffffffu), (garr[i1 & 7u] / ((unsigned)l0 | 1u)), (fuel - garr[i1 & 7u])); }
        *mp = ((unsigned)l0 | (unsigned)b0);
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((int)(unsigned)x0 >= (int)((unsigned)(w0 >> 29) | r0.x)), (unsigned)(short)(0x2aeeae3u * i2), (unsigned)((int)(unsigned)e0 < (int)u1)); }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)l0 + (unsigned)(0xe30c22e4u && 3u)), r0.x, (-(p1 * 0x84b1f180u) >> (fuel & 31u))); }
            m0 ^= (0x5a4f1189u * 0x10000u);
        }
        { unsigned t2; double z2; if (((unsigned)(x0 >> 70)) & 1u) { t2 = (0xffffffffu ^ 0x10000u); z2 = (double)((u1) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            if (g0) goto L4;
            if ((u3 & (unsigned)(unsigned char)(unsigned)((unsigned)d0 && 8u))) {
                d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)x0 < (int)u3) & 1023u);
            } else {
                if ((unsigned)((short)(unsigned)c1 > (signed char)(unsigned)((unsigned)h1 < 4u))) goto L4;
                if ((*mp & (unsigned)w0)) goto L0;
            }
            x0 = x0 * 0x100000001b3ull + (((unsigned)((int)u0 < (int)(unsigned)s0) - i0) % (r0.x | 1u));
        }
        l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(signed char)(r0.x | 5u) >= (int)(7u / ((2u | 0x10000u) | 1u))));
    }
    if ((p1 << ((0x10000u | u3) & 31u))) goto L3;
    if ((-(unsigned)((int)4u >= (int)0u) / (u2 | 1u))) goto done;
    b0 = ((unsigned)!((unsigned)f0 % (g0 | 1u)) - (unsigned)(short)(unsigned)((int)(unsigned)(x0 >> 70) < (int)0x7fffffffu)) != 0u;
    if ((unsigned)l0) goto L1;
    { unsigned t3; double z3; if (((unsigned)c1) & 1u) { t3 = (unsigned)((unsigned)((int)a0[i0 & 3u] >= (int)0x80000000u) == (unsigned)c1); z3 = (double)(((1u - 0xa448feeeu)) & 255u); } if (((unsigned)c1) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        l0 = (long)((unsigned long)l0 + ((unsigned)b0 | 0x7fffffffu));
        if (budget != 0u) { budget -= 1u; u1 = fn1((u1 % ((unsigned)x0 | 1u)), (unsigned)((int)(6u << (0x7fffffffu & 31u)) < (int)6u), ((unsigned)(0u || i0) | garr[u2 & 7u])); }
        u0 ^= 0xffffffffu;
        *q0 = (unsigned)(short)(unsigned)(((0x80000000u % (u0 | 1u)) | p1) < (unsigned)!((unsigned)x0 / (0x80000000u | 1u)));
        h1 = (unsigned short)(h1 + -(unsigned)((short)7u > (signed char)u1));
    }
    if (a0[u1 & 3u]) {
        if (i2) goto L1;
        m0 ^= (unsigned)((short)(((unsigned)b0 << (0u & 31u)) >> (((unsigned)s0 | a0[u1 & 3u]) & 31u)) > (signed char)*mp);
        if (p2) {
            { unsigned t4; double z4; if ((a0[i0 & 3u]) & 1u) { t4 = 0x7fffffffu; z4 = (double)((-((7u % (m0 | 1u)) / (fuel | 1u))) & 255u); } if ((a0[i0 & 3u]) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                x0 = x0 * 0x100000001b3ull + (unsigned)b0;
                q0 = &garr[-(garr[i1 & 7u] & r0.x) & 7u];
                a0[(4u / (i1 | 1u)) & 3u] = (r0.x / ((unsigned)c1 | 1u));
                if (0x10000u) goto L4;
                if ((unsigned)(signed char)(unsigned)((short)6u > (signed char)garr[i1 & 7u])) {
                    u1 = u1 * 0x9e3779b1u + 0x4df9a4d7u;
                    goto L2;
                    u1 = (((unsigned)(u1 == (p0 ^ 5u)) - u2) | *mp);
                    if ((unsigned)s0) goto L1;
                } else {
                    if ((unsigned)w0) goto L3;
                    switch (r0.x & 7u) {
                        w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)(6u / ((unsigned)h1 | 1u));
                        case 4u: ;
                        r0.x = (i2 * (unsigned)(garr[u2 & 7u] < fuel));
                        if (fuel < 8u) return (unsigned)(unsigned char)(unsigned)((int)0xdac243bau < (int)(p1 & (unsigned)e0));
                    }
                    s1 = (int)((unsigned)s1 + ~(unsigned)((int)0x9624d20fu >= (int)(0xdfa0d92au % (0x10000u | 1u))));
                    switch (((unsigned)h0 * (unsigned)b0) & 7u) {
                        case 3u: ;
                        e0 = e0 * 0.5L + (long double)(*q0 & 1023u);
                    }
                }
                d0 = d0 * 0.5 + (double)((unsigned)((unsigned)b0 == u1) & 1023u);
            }
            goto L2;
        } else {
            r0.y ^= (unsigned)((int)*mp >= (int)p0);
            w0 ^= (unsigned long long)(p1 << ((unsigned)s0 & 31u)) << ((unsigned)!((u1 ^ *mp) ^ (0x7fffffffu & (unsigned)b0)) & 63u);
            a0[(*q0 ^ 3u) & 3u] = (unsigned)((int)p1 >= (int)(unsigned)(short)(~(unsigned)((unsigned)(w0 >> 29) && m0) | (unsigned)(signed char)(0x2a0487f3u | (unsigned)f0)));
        }
    } else {
        u1 = u1 * 0x9e3779b1u + (unsigned)!(p1 % (g1 | 1u));
        if ((unsigned)x0) goto L3;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1((i0 * u2), i1, a0[u1 & 3u]); }
    u0 += i0;
    if (budget != 0u) { budget -= 1u; u3 = fn0(fuel, (unsigned)((unsigned)c1 < 2u), (v0 * i0)); }
    if ((unsigned)b0) goto L1;
    switch ((unsigned)b0 & 7u) {
        switch ((unsigned)((int)(unsigned)(u1 || r0.y) < (int)(unsigned)(x0 >> 70)) & 7u) {
            if ((unsigned)((int)8u >= (int)(unsigned)((unsigned)c0 < u1))) break;
            while (i0++ < 4u && 3u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)(unsigned)c0 >= (int)garr[u2 & 7u]), (r0.y - r0.x), (unsigned)(i1 == 1u)); }
            }
            h0 = (short)(unsigned)((short)(5u & m0) > (signed char)(unsigned)h0);
        }
        switch ((3u << (8u & 31u)) & 7u) {
            L4: if (--fuel == 0u) goto done;
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 2u: ;
                c1 = (signed char)(0x10000u % (u2 | 1u));
                r0.y ^= 0x4115d8e7u;
                while (i1++ < 6u && (unsigned)((int)0u >= (int)(unsigned)(0xd4f858f9u < u1))) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)((unsigned)(garr[u2 & 7u] && i2) || (0x408ae4d3u & ~(unsigned)((int)0xdc2773ffu >= (int)6u)));
                    x0 = x0 * 0x100000001b3ull + fuel;
                    g1 += (u2 ^ (4u | p1));
                    if (~(0xf27d9ac1u / ((0u % (*q0 | 1u)) | 1u))) {
                        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((short)(unsigned)h1 > (signed char)0xffffffffu), (unsigned)(signed char)(unsigned)((unsigned)!((unsigned)s0 ^ (unsigned)(w0 >> 29)) && 0xffffffffu), -(unsigned)((int)(unsigned)l0 >= (int)*q0)); }
                    } else {
                        if (budget != 0u) { budget -= 1u; u2 = fn0(6u, (unsigned)h0, (unsigned)!(unsigned)(fuel == (unsigned)((int)0u >= (int)p0))); }
                        if (budget != 0u) { budget -= 1u; u0 = fn1(((g1 & 0x751e2d54u) * 0x261aa85fu), 0xffffffffu, (3u | (unsigned)s1)); }
                        for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                            garr[(unsigned)w0 & 7u] = u2;
                            h1 = (unsigned short)(h1 + ((unsigned)(~((unsigned)b0 / (p1 | 1u)) == u3) >> (0xffffffffu & 31u)));
                        }
                        c1 = (signed char)((unsigned)f0 ? g0 : (unsigned)b0);
                    }
                    case 7u: ;
                }
                continue; (void)((unsigned)((int)1u >= (int)-(unsigned)((int)g0 >= (int)0xa8375776u)));
            }
            case 4u: ;
            u3 = -((unsigned)(garr[u2 & 7u] < (unsigned)h0) + (u2 ^ (unsigned)e0));
            u0 += ((unsigned)e0 ^ p1);
        }
        while (i0++ < 4u && (6u & 4u)) { if (--fuel == 0u) goto done;
            if ((unsigned)!((unsigned)!(unsigned)((int)0xe7514e10u >= (int)m0) + 4u)) goto L1;
            u3 ^= (unsigned)((int)0xffaf32au >= (int)0x63a8036u);
        }
        r0.y ^= (unsigned)((unsigned)(g0 == garr[u2 & 7u]) || (unsigned)((unsigned)(0x80000000u == 0x10000u) < (unsigned)s1));
    }
    if ((unsigned)e0) {
        b0 = (unsigned)((unsigned)(unsigned char)(u3 % ((unsigned)d0 | 1u)) < (unsigned)h0) != 0u;
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)((int)(unsigned)((unsigned)c1 < 0x80000000u) >= (int)(unsigned)(signed char)((unsigned)h1 + v0));
            if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)s1 % (0xaacf2841u | 1u)), -(unsigned)((short)(unsigned)s0 > (signed char)0x7fffffffu), (unsigned)(unsigned char)(unsigned)((int)r0.y < (int)(unsigned)(0x82994231u < (unsigned)(w0 >> 29)))); }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)(short)(garr[u2 & 7u] % (u2 | 1u)) | p0)) break;
                if ((unsigned)((unsigned)b0 < (unsigned)(0xf8513dadu && r0.x))) goto done;
                u0 += (0x80000000u << ((0x74485beau | m0) & 31u));
            }
            w0 ^= (unsigned long long)(0x3d17433cu & p0) << ((0xbfc41895u - garr[i1 & 7u]) & 63u);
        }
        while (i0++ < 3u && u1) { if (--fuel == 0u) goto done;
            if (((0xffffffffu << (i2 & 31u)) * g1)) break;
            while (i1++ < 7u && ((unsigned)(x0 >> 70) / (0x80000000u | 1u))) { if (--fuel == 0u) goto done;
                b0 = (unsigned)((unsigned)f0 && (unsigned)c1) != 0u;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((2u + (unsigned)((int)(unsigned)(0x10000u == a0[i0 & 3u]) < (int)0xf2cbb1c8u)) & 1023u);
                    d0 = d0 * 0.5 + (double)((4u / (6u | 1u)) & 1023u);
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)s0 | (0x1e727c0au << (garr[i1 & 7u] & 31u))), g1, (unsigned)((int)((unsigned)w0 ^ *mp) < (int)0x7fffffffu)); }
                    switch (((*mp << (p2 & 31u)) + fuel) & 7u) {
                        if ((fuel - (unsigned)x0)) goto done;
                        u1 += (r0.y ^ (i2 << ((unsigned)h1 & 31u)));
                        for (;;) { if (--fuel == 0u) goto done;
                            h1 = (unsigned short)(h1 + (unsigned)d0);
                            h1 = (unsigned short)(h1 + (unsigned)(i0 < (unsigned)((1u >> (p2 & 31u)) < ~(unsigned)(v0 || a0[u1 & 3u]))));
                            if ((unsigned)x0) break;
                            garr[(unsigned)c1 & 7u] = (unsigned)(w0 >> 29);
                        }
                        if ((a0[i0 & 3u] << (0x80000000u & 31u))) continue;
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)m0 > (signed char)2u), (unsigned)((int)(unsigned)((unsigned)f0 < 0x80000000u) >= (int)(unsigned)f0), (unsigned)(0x7fffffffu || (unsigned)(signed char)(unsigned)((int)0x10000u >= (int)6u))); }
                    }
                    break; (void)((unsigned)(short)((4u % (0x10000u | 1u)) / (0xffffffffu | 1u)));
                    r0.x = (unsigned)c0;
                }
                continue; (void)(i2);
                s0 = (int)9u;
            }
        }
        switch ((unsigned)c1 & 7u) {
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                *q0 += (unsigned)(short)(((unsigned)((unsigned)c1 || 0u) % ((0x10000u << ((unsigned)(w0 >> 29) & 31u)) | 1u)) >> (a0[u1 & 3u] & 31u));
            }
            u3 = u3 * 0x9e3779b1u + (unsigned)((unsigned)((short)(unsigned)!(0x80000000u ? garr[u2 & 7u] : (unsigned)b0) > (signed char)i2) && i0);
            if (budget != 0u) { budget -= 1u; u2 = fn0((0x80000000u ^ (unsigned)(*q0 == u0)), 0x10000u, (unsigned)c1); }
        }
        goto L0;
    } else {
        if (budget != 0u) { budget -= 1u; u1 = fn0((u0 / (0xffffffffu | 1u)), (unsigned)((unsigned)((short)0x596026fu > (signed char)8u) || u0), 0xaa164c58u); }
    }
    switch ((unsigned)((short)0xc3e9a94du > (signed char)(unsigned)s1) & 7u) {
        r0.y ^= -(unsigned)(0u || u0);
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (-((i0 ^ (unsigned)h0) | i2)) {
                x0 = x0 * 0x100000001b3ull + ~((unsigned)h1 * ((unsigned)c0 << (0x10000u & 31u)));
            } else {
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + p2);
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((int)(unsigned)(u3 < 0u) >= (int)fuel), (((unsigned)l0 << ((unsigned)f0 & 31u)) % (r0.x | 1u)), i2); }
                    case 0u: ;
                    s1 = (int)((unsigned)s1 + ((u1 & (unsigned)(0x15df6930u < (unsigned)f0)) + (unsigned)e0));
                }
                l0 = (long)((unsigned long)l0 + (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)h0));
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    default: ;
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(u0 == *mp), (unsigned)x0, (unsigned)(unsigned char)(0x571b6313u << ((unsigned)f0 & 31u))); }
                }
            }
            case 1u: ;
            if ((i2 * (unsigned)h1)) goto done;
            garr[(unsigned)((int)*q0 < (int)(unsigned)s1) & 7u] = (unsigned)(((unsigned)d0 >> ((0x10000u % (u1 | 1u)) & 31u)) < u0);
        }
    }
    s0 = (int)((unsigned)(signed char)((unsigned)h0 >> (g1 & 31u)) ^ (unsigned)(*q0 && garr[i1 & 7u]));
    if ((unsigned)(garr[u2 & 7u] || (unsigned)e0)) goto L1;
    if (a0[u1 & 3u]) {
        i0 = *q0 & 15u;
        goto L3;
        if (p0) goto L4;
        a0[(0x987cd447u >> (8u & 31u)) & 3u] = (3u << (((unsigned)((unsigned)(w0 >> 29) && u0) % (u3 | 1u)) & 31u));
        if ((0xe2961e3au * (unsigned)(unsigned char)(unsigned)((unsigned)h1 == 0x40d043acu))) {
            if (*mp) goto L2;
            switch (m0 & 7u) {
                u2 = u2 * 0x9e3779b1u + (unsigned)b0;
                goto done;
                u3 ^= (unsigned)(0x766c66c3u || (unsigned)(garr[i1 & 7u] || 0u));
                e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)!((i1 % (garr[u2 & 7u] | 1u)) ? 0x10000u : (unsigned)(w0 >> 29))) & 1023u);
                if (fuel < 8u) return *mp;
            }
            switch (6u & 7u) {
                for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    while (i1++ < 7u && (unsigned)((int)(unsigned)!((unsigned)d0 * 0x10000u) < (int)i1)) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(x0 >> 70), (unsigned)b0, (unsigned)(i2 < fuel)); }
                        u3 += (r0.x + p2);
                    }
                }
                e0 = e0 * 0.5L + (long double)(((unsigned)(unsigned char)(unsigned)((unsigned)(unsigned char)((unsigned)h0 / ((9u << (0x96cb58cbu & 31u)) | 1u)) == 0x70372b38u) ^ (unsigned)h1) & 1023u);
            }
            if ((p0 % (a0[u1 & 3u] | 1u))) goto L3;
            x0 = x0 * 0x100000001b3ull + (a0[i0 & 3u] % ((unsigned)((int)i1 >= (int)(unsigned)!(8u | 5u)) | 1u));
        } else {
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)l0);
                i2 = (unsigned)((short)6u > (signed char)0x25bc1c67u) & 15u;
                break; (void)(((unsigned)w0 ? (unsigned)w0 : i1));
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    b0 = g0 != 0u;
                    c0 = (unsigned char)(unsigned)(i0 || (unsigned)(8u < u3));
                    if ((unsigned)!(unsigned)(i1 || 0x729a08beu)) goto L2;
                }
            }
            switch ((unsigned)((unsigned)c0 || r0.x) & 7u) {
                r0.x = (unsigned)h1;
                s0 = (int)(0xdb0528cbu ^ (unsigned)x0);
                case 2u: ;
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(-((unsigned)h0 >> (0x80000000u & 31u)) || (unsigned)(x0 >> 70)), 8u, (unsigned)((int)~(unsigned)((unsigned)h0 || (unsigned)e0) < (int)9u)); }
                u1 = u1 * 0x9e3779b1u + (unsigned)e0;
            }
        }
    } else {
        if (budget != 0u) { budget -= 1u; u3 = fn1(0x10000u, (unsigned)(0xffffffffu && 8u), (unsigned)((int)(0x2403301eu / ((unsigned)s0 | 1u)) >= (int)a0[u1 & 3u])); }
        u0 = u0 * 0x9e3779b1u + (unsigned)h1;
        if ((unsigned)((r0.y >> (a0[u1 & 3u] & 31u)) && i2)) goto L1;
        if (budget != 0u) { budget -= 1u; u3 = fn2((m0 / ((unsigned)c0 | 1u)), (unsigned)(r0.x < (unsigned)((int)(unsigned)e0 < (int)(unsigned)s1)), (unsigned)((short)(unsigned)((int)2u < (int)3u) > (signed char)(unsigned)w0)); }
    }
    garr[(unsigned)(signed char)(unsigned)(0x7fffffffu || p2) & 7u] = i2;
    *mp = ((unsigned)(x0 >> 70) % ((unsigned)(short)((u2 / (0xffffffffu | 1u)) | (a0[u1 & 3u] ^ u0)) | 1u));
    goto L3;
    f0 = f0 * 0.5f + (float)((i0 / (u2 | 1u)) & 255u);
    if ((unsigned)((int)(r0.x + (unsigned)f0) < (int)(unsigned)s0)) goto L2;
    if ((g0 + u3)) goto L4;
    if (0x10000u) goto L2;
    if ((unsigned)f0) goto L3;
    l0 = (long)((unsigned long)l0 + ((unsigned)(u3 < (unsigned)d0) >> (((unsigned)d0 ? (unsigned)w0 : (unsigned)d0) & 31u)));
    while ((u2 << (g0 & 31u))) { if (--fuel == 0u) goto done;
        switch ((0xed6804e2u ^ 0x802d9a76u) & 7u) {
            if (fuel < 8u) return (0x7fffffffu ? (unsigned)((unsigned)h1 && (unsigned)c0) : a0[i0 & 3u]);
            w0 = w0 * 6364136223846793005ull + (*mp * (unsigned)((int)0x80000000u >= (int)p2));
        }
        if ((6u ? (unsigned)b0 : fuel)) {
            if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)c1 & p0), g0, v0); }
            goto L0;
        } else {
            s1 = (int)((unsigned)s1 + (((unsigned)h0 >> (5u & 31u)) / ((1u << (((unsigned)(x0 >> 70) % (u0 | 1u)) & 31u)) | 1u)));
        }
        if (((unsigned)c0 ^ (unsigned)w0)) break;
        *q0 += ((m0 << ((0x7fffffffu % (0x80000000u | 1u)) & 31u)) & (0u >> ((unsigned)l0 & 31u)));
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(5u && (unsigned)(w0 >> 29))) break;
            break; (void)(9u);
        }
        if ((unsigned)((int)(0x80000000u / (a0[u1 & 3u] | 1u)) >= (int)(unsigned)s0)) break;
    }
    if ((*mp - (unsigned)((unsigned)x0 || 0xe4c1d068u))) goto L1;
    if ((unsigned)e0) goto L1;
    c0 = (unsigned char)0x80000000u;
    goto L1;
    u1 = ((unsigned)s0 - garr[i1 & 7u]);
    do { if (--fuel == 0u) goto done;
        garr[p1 & 7u] = (r0.x - ((unsigned)((int)garr[u2 & 7u] >= (int)0xcb7eb44eu) % (0x80000000u | 1u)));
        if (fuel) break;
        garr[u1 & 7u] = (0x80000000u / ((0xf7d1db03u << ((garr[i1 & 7u] / ((unsigned)(x0 >> 70) | 1u)) & 31u)) | 1u));
        c1 = (signed char)-(r0.x / ((unsigned)(i0 == p0) | 1u));
        garr[(garr[u2 & 7u] & 0x5307afc8u) & 7u] = ((1u >> (8u & 31u)) ? g1 : (unsigned)((int)(unsigned)s1 >= (int)a0[i0 & 3u]));
        while ((r0.x * i2)) { if (--fuel == 0u) goto done;
            goto L1;
            for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((i2 & 0x554922c3u) & 1023u);
            }
            u0 = u0 * 0x9e3779b1u + (unsigned)!(unsigned)((int)(unsigned)x0 < (int)i2);
            g1 += ((unsigned)d0 - (unsigned)b0);
        }
    } while (i0++ < 6u && (0xc4d8c89bu % (-(i2 | g1) | 1u)));
    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)e0 / (u1 | 1u)), (unsigned)(r0.y || (unsigned)(u1 || 0xef5886f1u)), (unsigned)(short)((unsigned)e0 % ((u3 / (r0.x | 1u)) | 1u))); }
    w0 = w0 * 6364136223846793005ull + ((a0[u1 & 3u] & 4u) << ((unsigned)(w0 >> 29) & 31u));
    if ((fuel * r0.y)) goto L4;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if (((unsigned)(0x7fffffffu < a0[i0 & 3u])) & 1u) { t0 = (unsigned)((int)(fuel % (fuel | 1u)) < (int)0x7fffffffu); z0 = (double)(((((unsigned)l0 + (unsigned)b0) & (unsigned)c0)) & 255u); } if (((unsigned)(0x7fffffffu < a0[i0 & 3u])) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if ((unsigned)(signed char)(i1 + ((unsigned)x0 & (unsigned)h0))) {
            L0: if (--fuel == 0u) goto done;
        } else {
            w0 ^= (unsigned long long)-(a0[i0 & 3u] << (garr[i1 & 7u] & 31u)) << ((unsigned)(((unsigned)w0 * (unsigned)x0) == ((unsigned)(g0 < 1u) + 0xb5d7f3a0u)) & 63u);
            goto done;
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                v0 = ((unsigned)s0 * (((unsigned)h1 + 0u) - (0xec1e77eu - garr[i1 & 7u])));
                if (r0.x) goto L0;
                { unsigned t1; double z1; if (((4u << (i0 & 31u))) & 1u) { t1 = u1; z1 = (double)((3u) & 255u); } if (((4u << (i0 & 31u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        c1 = (signed char)fuel;
                        if ((unsigned)!(a0[i0 & 3u] / (p2 | 1u))) goto L2;
                        do { if (--fuel == 0u) goto done;
                            if ((unsigned)((int)(unsigned)(0x1547f9e3u == (unsigned)c0) >= (int)r0.x)) break;
                            *q0 = (((garr[u2 & 7u] - r0.y) / ((unsigned)(unsigned char)(a0[u1 & 3u] / ((unsigned)(w0 >> 29) | 1u)) | 1u)) >> (0x461a3de7u & 31u));
                            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)d0 + (unsigned)s0), (unsigned)((int)(unsigned)((int)u1 < (int)u1) >= (int)(unsigned)c0), (unsigned)((short)2u > (signed char)(unsigned)b0)); }
                            if ((m0 + garr[i1 & 7u])) break;
                        } while (i2++ < 5u && u2);
                        L1: if (--fuel == 0u) goto done;
                    }
                    c1 = (signed char)(unsigned)((unsigned)h1 || (5u >> (((unsigned)b0 / ((p2 / ((unsigned)(w0 >> 29) | 1u)) | 1u)) & 31u)));
                    if (budget != 0u) { budget -= 1u; u3 = fn0(~(p2 ^ u3), (unsigned)h1, ((unsigned)((unsigned)x0 < u1) + (unsigned)f0)); }
                    b0 = (unsigned)!((((unsigned)s1 - u2) - garr[i1 & 7u]) >> ((unsigned)((unsigned)s1 && a0[u1 & 3u]) & 31u)) != 0u;
                    w0 = w0 * 6364136223846793005ull + ((0x71197f07u >> ((unsigned)(w0 >> 29) & 31u)) << (((unsigned)h1 | (unsigned)s0) & 31u));
                }
            }
            { unsigned t2; double z2; if (((unsigned)((int)(unsigned)(u2 && p2) < (int)(unsigned)x0)) & 1u) { t2 = (unsigned)c0; z2 = (double)((((unsigned)(x0 >> 70) / (p0 | 1u))) & 255u); } if (((unsigned)((int)(unsigned)(u2 && p2) < (int)(unsigned)x0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)x0, 8u, (unsigned)s1); }
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)!(unsigned)((int)r0.y < (int)(unsigned)((unsigned)c1 || *q0)), (unsigned)((int)(unsigned)w0 >= (int)(g1 % ((unsigned)x0 | 1u))), ((i2 * m0) % (0u | 1u))); }
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    g1 += (unsigned)w0;
                    l0 = (long)((unsigned long)l0 + (unsigned)(short)(i2 - (p0 / (p0 | 1u))));
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn1(0xf05550f4u, (0x80000000u | 6u), (r0.x * 0x10000u)); }
                        L2: if (--fuel == 0u) goto done;
                        if (((unsigned)x0 & 0xffffffffu)) break;
                    } while (i1++ < 7u && (unsigned)w0);
                    if (garr[u2 & 7u]) continue;
                    if (budget != 0u) { budget -= 1u; u0 = fn2(-((unsigned)(w0 >> 29) ^ a0[u1 & 3u]), (*q0 ^ garr[u2 & 7u]), (r0.y / (((unsigned)(w0 >> 29) * m0) | 1u))); }
                    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((unsigned)x0 < (0x2471d9edu >> ((unsigned)(w0 >> 29) & 31u))), (0x10000u >> ((unsigned)x0 & 31u)), (unsigned)(0x6e76fd24u && (unsigned)(p0 || 0x80000000u))); }
                }
                u1 = u1 * 0x9e3779b1u + (r0.y ^ 0x89b6ed9u);
                L3: if (--fuel == 0u) goto done;
                if (fuel < 8u) return ~((unsigned)((int)(i1 - r0.x) >= (int)a0[i0 & 3u]) >> ((3u / (u0 | 1u)) & 31u));
            }
        }
        L4: if (--fuel == 0u) goto done;
        if ((unsigned)l0) goto L1;
        a0[(unsigned)!(u2 | (unsigned)c0) & 3u] = (unsigned)((unsigned)((int)0xffffffffu >= (int)(unsigned)c0) < 0xacded63bu);
    }
    if (-(u2 * (unsigned)(0x399b15bfu == u0))) goto L1;
    u3 = (unsigned)(0x84efe94au || garr[u2 & 7u]);
    if (budget != 0u) { budget -= 1u; u0 = fn3(((unsigned)c0 << (7u & 31u)), (unsigned)h1, (unsigned)(0x80000000u || i2)); }
    goto L1;
    r0.y ^= (i1 % (i0 | 1u));
    if (budget != 0u) { budget -= 1u; u0 = fn1((((unsigned)h0 & (unsigned)h1) & r0.y), (0x2e481c09u ^ (unsigned)h0), (u1 << ((p1 - (unsigned)(w0 >> 29)) & 31u))); }
    q0 = &garr[(unsigned)(signed char)(m0 ^ (unsigned)(w0 >> 29)) & 7u];
    *q0 = (unsigned)(0x7fffffffu && u2);
    goto L2;
    if ((6u * (unsigned)d0)) goto L1;
    goto L2;
    u0 = -(unsigned)(p0 < g0);
    *q0 += (i0 % ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)((short)p1 > (signed char)(unsigned)((short)0x10000u > (signed char)u2))) | 1u));
    u1 = u1 * 0x9e3779b1u + 4u;
    do { if (--fuel == 0u) goto done;
        if ((i2 + (unsigned)(0x9f2fdf06u < p1))) break;
    } while (i0++ < 5u && ((unsigned)f0 ^ 0x74a8af94u));
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(((unsigned)c1 & 5u) < garr[i1 & 7u]), (unsigned)s0, (unsigned)(0xffffffffu == m0)); }
    do { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)h0 > (signed char)0xa0713aabu));
        b0 = (r0.x << ((unsigned)(short)(3u | 0xffffffffu) & 31u)) != 0u;
        { unsigned t3; double z3; if (((unsigned)(unsigned char)((unsigned)c0 / ((unsigned)((int)8u >= (int)5u) | 1u))) & 1u) { t3 = (unsigned)((int)(*q0 + 0xffffffffu) < (int)v0); z3 = (double)(((fuel * (unsigned)f0)) & 255u); } if (((unsigned)(unsigned char)((unsigned)c0 / ((unsigned)((int)8u >= (int)5u) | 1u))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            { unsigned t4; double z4; if (((unsigned)((int)2u < (int)(unsigned)((short)g1 > (signed char)(unsigned)f0))) & 1u) { t4 = (unsigned)s1; z4 = (double)((p1) & 255u); } if (((unsigned)((int)2u < (int)(unsigned)((short)g1 > (signed char)(unsigned)f0))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                if (((unsigned)x0 | (p2 % (garr[i1 & 7u] | 1u)))) {
                    g1 += a0[u1 & 3u];
                    s1 = (int)((unsigned)s1 + i2);
                    a0[(unsigned)((short)6u > (signed char)fuel) & 3u] = (unsigned)((int)((unsigned)e0 & (unsigned)(x0 >> 70)) >= (int)0x10000u);
                    for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (0xffffffffu) break;
                        u1 ^= (unsigned)((short)(garr[u2 & 7u] / (5u | 1u)) > (signed char)u2);
                        if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(~(unsigned)((short)garr[u2 & 7u] > (signed char)0x80162476u) || u1), (p2 | u2), ~(unsigned)(3u < ((unsigned)s0 * i2))); }
                        r0.x = i1;
                    }
                    x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((unsigned)((int)(unsigned)(u2 == (unsigned)b0) >= (int)0xffffffffu) & (i0 >> ((unsigned)c0 & 31u)));
                    break; (void)(0x7fffffffu);
                }
                if ((unsigned)l0) continue;
                if (budget != 0u) { budget -= 1u; u1 = fn1(2u, ((unsigned)s0 / (0xfb147e86u | 1u)), ~((unsigned)x0 - (unsigned)c1)); }
                if (i2) goto L0;
                if (budget != 0u) { budget -= 1u; u0 = fn1(g0, p1, (u2 & (unsigned)(u0 || 7u))); }
                if (fuel) break;
            }
            *mp = (unsigned)(x0 >> 70);
            if ((r0.y / (0x7fffffffu | 1u))) break;
            if (budget != 0u) { budget -= 1u; u2 = fn2(~(unsigned)(g0 || (unsigned)x0), (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)x0), i0); }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)((unsigned)w0 & 0xc34df6dcu), (unsigned)(signed char)(p1 - (unsigned)(x0 >> 70)), (unsigned)d0); }
        }
        u0 = p0;
        if (0x80000000u) break;
    } while (i0++ < 4u && p0);
    u3 += (unsigned)(0xffffffffu < (garr[i1 & 7u] ^ ((unsigned)(w0 >> 29) + i0)));
    g0 = (unsigned)(0xffffffffu < g0);
    h1 = (unsigned short)(h1 + (0xf3d3849bu ^ ((unsigned)h1 ^ (unsigned)l0)));
    switch (((unsigned)(short)(unsigned)((short)0xf8c63c34u > (signed char)0xd0663252u) ^ 0x85ceb08du) & 7u) {
        r0.x = (unsigned)(2u || (p2 & ((unsigned)b0 - 3u)));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((unsigned)(a0[i0 & 3u] && (unsigned)l0) == (unsigned)b0), 0x7fffffffu, ((unsigned)d0 - 5u)); }
    u2 = (fuel % (i1 | 1u));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        i2 = (unsigned)((int)(p1 / (u1 | 1u)) >= (int)((unsigned)c1 / (9u | 1u))) & 15u;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(~(p2 / ((unsigned)((int)0x10000u >= (int)(unsigned)x0) | 1u)));
            if ((0x10000u ^ (unsigned)b0)) {
                continue; (void)((unsigned)(signed char)(unsigned)((int)u0 >= (int)(unsigned)c0));
                { unsigned t5; double z5; if ((g0) & 1u) { t5 = i0; z5 = (double)((u0) & 255u); } if ((g0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    if ((unsigned)((int)(unsigned)s1 < (int)(unsigned)(r0.y && (unsigned)f0))) {
                        break; (void)((unsigned)(unsigned char)(1u % (v0 | 1u)));
                        if (((unsigned)f0 & (unsigned)((int)u0 >= (int)*q0))) break;
                        if (u0) {
                            w0 ^= (unsigned long long)(*q0 | 0xffffffffu) << (~((r0.y - ~(unsigned)((int)(unsigned)x0 < (int)u3)) | 0x7fffffffu) & 63u);
                            break; (void)((unsigned)((9u * 0x7fffffffu) || i1));
                            if ((unsigned)((int)(unsigned)c0 >= (int)5u)) break;
                            s0 = (int)(unsigned)(unsigned char)(unsigned)(garr[u2 & 7u] < g0);
                        }
                        s1 = (int)((unsigned)s1 + (unsigned)(a0[u1 & 3u] && (unsigned)(*q0 == 0xadfaa04fu)));
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)0x941390ebu < (int)m0));
                        if (9u) continue;
                    } else {
                        if (-(unsigned)((unsigned)(w0 >> 29) && (unsigned)b0)) break;
                        while (i2++ < 6u && ((unsigned)l0 >> (p2 & 31u))) { if (--fuel == 0u) goto done;
                            s1 = (int)((unsigned)s1 + (-(unsigned)((unsigned)f0 == a0[i0 & 3u]) + p2));
                            if (0xd9c08190u) continue;
                            *q0 += (4u / ((unsigned)(short)(unsigned)(g0 || u2) | 1u));
                            garr[*mp & 7u] = (unsigned)((short)0xf805dc67u > (signed char)3u);
                        }
                        e0 = e0 * 0.5L + (long double)((u1 / ((unsigned)(signed char)(unsigned)((int)(unsigned)(garr[u2 & 7u] && 7u) < (int)*mp) | 1u)) & 1023u);
                    }
                }
                b0 = ((0x80000000u << (9u & 31u)) * (a0[u1 & 3u] << (0xffffffffu & 31u))) != 0u;
            }
            u1 = u1 * 0x9e3779b1u + ((unsigned)((short)0x1b50749cu > (signed char)a0[i0 & 3u]) << (garr[i1 & 7u] & 31u));
            r0.x = (unsigned)(u3 && g0);
            if ((unsigned)d0) break;
            if (((unsigned)(7u && (unsigned)l0) >> ((unsigned)(w0 >> 29) & 31u))) {
                d0 = d0 * 0.5 + (double)((unsigned)(signed char)((unsigned)((int)-(0x7fffffffu - g1) >= (int)(unsigned)s0) % (1u | 1u)) & 1023u);
                if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)x0, r0.y, r0.y); }
                break; (void)(((1u ^ fuel) * 0x10000u));
            }
        }
        u2 = u2 * 0x9e3779b1u + (unsigned)((0x2f4e3329u ^ a0[u1 & 3u]) < (unsigned)l0);
    }
    *q0 = 0x82925e4du;
    for (;;) { if (--fuel == 0u) goto done;
        r0.x = ((unsigned)!(unsigned)(0x3997de75u && (fuel | 0x165a93b4u)) << ((unsigned)((int)i1 >= (int)0x80000000u) & 31u));
        { unsigned t6; double z6; if (((0u / (*q0 | 1u))) & 1u) { t6 = (unsigned)(r0.y < 7u); z6 = (double)((garr[u2 & 7u]) & 255u); } if (((0u / (*q0 | 1u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            w0 ^= (unsigned long long)(unsigned)((int)(unsigned)(x0 >> 70) < (int)a0[u1 & 3u]) << ((fuel | ((unsigned)(u0 == 2u) - (garr[i1 & 7u] - 0x784f45c3u))) & 63u);
            w0 ^= (unsigned long long)0x110a7635u << (-((unsigned)c1 - m0) & 63u);
            *mp = 0x66fde66fu;
            if (3u) {
                s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((short)(unsigned)(i1 == (unsigned)((unsigned)e0 && g0)) > (signed char)(unsigned)x0) == m0));
                garr[(0xd014a47u + g0) & 7u] = (unsigned)c0;
                break; (void)(((fuel >> ((unsigned)b0 & 31u)) / (0xbf11dd6du | 1u)));
            }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                g1 += -(0xffffffffu ? (unsigned)(short)(u2 ? 0x80000000u : 8u) : (unsigned)l0);
                garr[a0[u1 & 3u] & 7u] = (unsigned)!(unsigned)((int)6u < (int)(0x4e85c11fu ^ p0));
                if (((unsigned)c1 % (0x67d59875u | 1u))) break;
                break; (void)((0x31c53985u + ((unsigned)b0 % ((unsigned)e0 | 1u))));
                s0 = (int)(unsigned)(short)(((unsigned)x0 * u2) | (unsigned)x0);
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)f0 == (unsigned)((int)*q0 < (int)0u)), ((0xffffffffu << ((unsigned)d0 & 31u)) << (0xffffffffu & 31u)), ~((unsigned)h0 + i2)); }
                    d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)(short)(0x80000000u + 0xe4a254d0u) < (int)(unsigned)h0) & 1023u);
                    *q0 = (unsigned)c0;
                    s1 = (int)((unsigned)s1 + (unsigned)((int)((unsigned)f0 & (u0 % (a0[i0 & 3u] | 1u))) < (int)p1));
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)e0 || 4u));
                    i0 = (p0 << ((g1 / ((unsigned)s1 | 1u)) & 31u)) & 15u;
                }
            }
            i2 = (unsigned)(((unsigned)(x0 >> 70) ^ u0) && (unsigned)(((unsigned)d0 % (r0.y | 1u)) && 0xff611e18u)) & 15u;
        }
        { unsigned t7; double z7; if ((g0) & 1u) { t7 = (unsigned)(w0 >> 29); z7 = (double)(((unsigned)(0xc65fef30u == (0xffffffffu | m0))) & 255u); } if ((g0) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
            if (budget != 0u) { budget -= 1u; u0 = fn0((1u + (unsigned)!(garr[i1 & 7u] << (0x3fa3d9cfu & 31u))), (unsigned)(unsigned char)((garr[u2 & 7u] & v0) >> (p2 & 31u)), -(0x10000u * (unsigned)w0)); }
            if ((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)s0)) break;
            if ((unsigned)(signed char)(6u << ((unsigned)(w0 >> 29) & 31u))) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn2((m0 << (((unsigned)b0 & (unsigned)s1) & 31u)), (3u << (i0 & 31u)), u1); }
        }
        if ((unsigned)e0) break;
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)0x901eafadu >= (int)(unsigned)((int)p0 >= (int)(unsigned)(short)(unsigned)((int)u1 >= (int)(unsigned)(i0 && 0u))));
    }
    u1 = u1 * 0x9e3779b1u + (unsigned)f0;
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)(signed char)(unsigned)(8u == *q0) == (unsigned)s1), (unsigned)(w0 >> 29), (unsigned)(i1 || fuel)); }
    s1 = (int)((unsigned)s1 + (unsigned)(u0 < p2));
    r0.x = garr[u2 & 7u];
    e0 = e0 * 0.5L + (long double)(garr[u2 & 7u] & 1023u);
    x0 = x0 * 0x100000001b3ull + (unsigned)((r0.y >> ((0x10000u - p1) & 31u)) == 9u);
    c1 = (signed char)((a0[i0 & 3u] << ((8u >> ((unsigned)(0xf2d88f72u || (unsigned)e0) & 31u)) & 31u)) - *q0);
    goto L1;
    if ((unsigned)((int)(unsigned)((int)fuel >= (int)p0) < (int)(unsigned)f0)) goto L4;
    goto L2;
    while (i0++ < 3u && (0xffffffffu & (unsigned)x0)) { if (--fuel == 0u) goto done;
        b0 = ((unsigned)((unsigned)c0 == (unsigned)x0) >> ((unsigned)(signed char)(6u & (p0 % (garr[u2 & 7u] | 1u))) & 31u)) != 0u;
        c1 = (signed char)0x7fffffffu;
        do { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)(short)(7u - (unsigned)(short)(u0 >> ((unsigned)(x0 >> 70) & 31u))));
            if (budget != 0u) { budget -= 1u; u1 = fn3(0xffffffffu, (unsigned)e0, (unsigned)(x0 >> 70)); }
            c0 = (unsigned char)(unsigned)((unsigned)s1 < (unsigned)h0);
            { unsigned t8; double z8; if ((a0[u1 & 3u]) & 1u) { t8 = ((unsigned)h1 - 0x240ed4eau); z8 = (double)((0xba6f80dcu) & 255u); } if ((a0[u1 & 3u]) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                do { if (--fuel == 0u) goto done;
                    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + (unsigned)(garr[u2 & 7u] == (unsigned)((int)8u >= (int)(unsigned)(u2 && g1)));
                        if (((unsigned)h0 * (unsigned)((unsigned)h1 < 0x7fffffffu))) break;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)d0 / ((unsigned)!(p2 / ((unsigned)h1 | 1u)) | 1u)), ((unsigned)h1 ^ (unsigned)((unsigned)h1 && 0x97559617u)), u1); }
                        goto L3;
                    }
                    g0 = (0x5fdf2590u % ((unsigned)c1 | 1u));
                    do { if (--fuel == 0u) goto done;
                        m0 ^= u2;
                        u3 = ((unsigned)((int)0u >= (int)0xffffffffu) / ((unsigned)(0xe18fac67u && i1) | 1u));
                    } while (i0++ < 4u && (unsigned)((short)r0.x > (signed char)u0));
                    if ((unsigned)((int)(unsigned)(w0 >> 29) < (int)~(*q0 % (v0 | 1u)))) break;
                    break; (void)((unsigned)!(unsigned)((int)r0.x < (int)0x56d577b9u));
                } while (i2++ < 3u && 4u);
                h1 = (unsigned short)(h1 + u2);
                b0 = (5u % ((unsigned)((int)i2 < (int)(*q0 | 8u)) | 1u)) != 0u;
                if (((0x80000000u >> (p0 & 31u)) + *q0)) break;
                if ((unsigned)(0x10000u < 0x995bf538u)) continue;
                v0 = (0x62297b3u ? (unsigned)f0 : (0x80000000u << (8u & 31u)));
            }
        } while (i1++ < 7u && (unsigned)((int)0x859ebf0eu < (int)(0xb5ee76d2u / ((unsigned)w0 | 1u))));
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                c0 = (unsigned char)0xdd076b8u;
                h0 = (short)(((unsigned)(*mp || u2) % (fuel | 1u)) << ((unsigned)!(u2 >> (fuel & 31u)) & 31u));
                if ((unsigned)(short)(6u / (0xffffffffu | 1u))) continue;
                s0 = (int)~(p0 & 0x7fffffffu);
                break; (void)(((unsigned)(7u || 0x8392f4f7u) | 0xffffffffu));
            } while (i2++ < 3u && (unsigned)((unsigned)x0 && 1u));
            if ((unsigned)((short)((unsigned)(w0 >> 29) * (unsigned)s1) > (signed char)u3)) continue;
            if ((unsigned)((int)(unsigned)l0 >= (int)((unsigned)c0 % (0xffffffffu | 1u)))) {
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)s0 || 0x9a3efa03u), (unsigned)!((unsigned)l0 ? 0x80000000u : g0), ((unsigned)(p1 || (unsigned)c0) - 0x16f7a483u)); }
                if (budget != 0u) { budget -= 1u; u2 = fn0(4u, (unsigned)(p2 == (*q0 % (u0 | 1u))), 0x10000u); }
                { unsigned t9; double z9; if ((fuel) & 1u) { t9 = (unsigned)(unsigned char)(unsigned)(((unsigned)x0 % (6u | 1u)) || (unsigned)f0); z9 = (double)((((unsigned)d0 / (a0[u1 & 3u] | 1u))) & 255u); } if ((fuel) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                    u0 = u0 * 0x9e3779b1u + ((((unsigned)f0 * r0.y) >> (u2 & 31u)) % (*q0 | 1u));
                    u1 = (*q0 & ((unsigned)b0 - 0x7fffffffu));
                    f0 = f0 * 0.5f + (float)((unsigned)((short)0x80000000u > (signed char)(0xc25be964u - 2u)) & 255u);
                }
                if (*mp) {
                    g1 += (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)((int)(unsigned)f0 < (int)(unsigned)((int)u0 >= (int)a0[i0 & 3u])));
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        *mp = r0.x;
                        continue; (void)(0xffffffffu);
                        if ((unsigned)(i2 && r0.y)) break;
                    }
                }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(u1 && (unsigned)c0), (unsigned)s0, (p2 ^ ((unsigned)e0 * (unsigned)l0))); }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(unsigned)(*q0 && (unsigned)!(0x1051eda1u + (unsigned)b0)), 6u, (unsigned)(u1 == (unsigned)l0)); }
            f0 = f0 * 0.5f + (float)(((unsigned)(1u || (unsigned)f0) - (m0 << (((unsigned)h0 & (unsigned)w0) & 31u))) & 255u);
        }
        m0 ^= (unsigned)((int)((unsigned)x0 | 0x7fffffffu) < (int)((unsigned)l0 - (i2 << (a0[i0 & 3u] & 31u))));
        b0 = (unsigned)((short)(*q0 & (unsigned)((unsigned)(x0 >> 70) || (unsigned)(w0 >> 29))) > (signed char)0xd5da2662u) != 0u;
    }
    v0 = (0x80000000u & (0xf249faccu >> (0x6804069au & 31u)));
    e0 = e0 * 0.5L + (long double)((unsigned)((short)g1 > (signed char)0x10000u) & 1023u);
    *q0 += (unsigned)((int)((unsigned)e0 / (0x80000000u | 1u)) < (int)(unsigned)(w0 >> 29));
    { unsigned t10; double z10; if ((0x659c6255u) & 1u) { t10 = garr[i1 & 7u]; z10 = (double)(((0x726ffbebu + fuel)) & 255u); } if ((0x659c6255u) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
        if (budget != 0u) { budget -= 1u; u2 = fn1((2u % (fuel | 1u)), (unsigned)((unsigned)s0 || (unsigned)(signed char)(4u >> (fuel & 31u))), ((unsigned)c0 ^ 1u)); }
        if (g1) {
            if (g1) goto L3;
            a0[(unsigned)h0 & 3u] = (p2 - ((0x53f9c310u % (0x7fffffffu | 1u)) / (0x10000u | 1u)));
            if (a0[i0 & 3u]) goto L4;
            { unsigned t11; double z11; if (((m0 + 0x10000u)) & 1u) { t11 = (unsigned)((int)9u < (int)*q0); z11 = (double)((((unsigned)(x0 >> 70) + 0x7c0541cdu)) & 255u); } if (((m0 + 0x10000u)) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
                if ((unsigned)c1) goto L1;
                if (budget != 0u) { budget -= 1u; u0 = fn3((0x7fffffffu ^ (i0 * r0.x)), (g0 % (((unsigned)(x0 >> 70) ^ 7u) | 1u)), ((unsigned)(unsigned char)(g1 + 2u) + i0)); }
                r0.y ^= (unsigned)((unsigned)h0 < -((unsigned)((short)(unsigned)f0 > (signed char)g0) & p2));
                if ((unsigned)((short)r0.y > (signed char)u3)) goto L2;
                u0 ^= (2u & (unsigned)(g0 == u2));
            }
            if (0xffffffffu) goto L4;
            if (-(p2 << ((p2 + (unsigned)c1) & 31u))) goto L3;
        } else {
            switch ((unsigned)((unsigned)f0 && 0x10000u) & 7u) {
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((*mp ^ u0)) continue;
                }
                if ((i1 & 4u)) break;
                do { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)b0 % (u1 | 1u)) || p1) & 255u);
                    if ((m0 / (0x80000000u | 1u))) break;
                    case 4u: ;
                } while (i0++ < 5u && ((garr[u2 & 7u] - 8u) >> (8u & 31u)));
                s1 = (int)((unsigned)s1 + (unsigned)((0x80000000u & (unsigned)((int)1u < (int)(unsigned)b0)) == (0x6d7d096cu >> ((unsigned)b0 & 31u))));
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)(unsigned)((unsigned)h1 && u1) > (signed char)0xffffffffu)) continue;
                    default: ;
                    w0 ^= (unsigned long long)~(unsigned)((int)0xffffffffu >= (int)(unsigned)d0) << ((unsigned)f0 & 63u);
                } while (i0++ < 6u && ((0xec2310f2u / (0x7fffffffu | 1u)) / ((unsigned)d0 | 1u)));
                case 1u: ;
            }
            *q0 += garr[i1 & 7u];
        }
        while (i0++ < 2u && (unsigned)((int)((unsigned)c0 % (0x7fffffffu | 1u)) < (int)0x3782793du)) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)(u2 && (unsigned)x0) << (-((unsigned)c0 << (((unsigned)s1 + (unsigned)l0) & 31u)) & 63u);
        }
        if ((unsigned)c0) goto L3;
    }
    if ((i0 ? 0x10000u : 0x10000u)) goto L2;
    r0.y ^= ((unsigned)h0 - r0.y);
    goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(u0 && u0), 0x80000000u, ((unsigned)s1 + i2)); }
    h0 = (short)~(unsigned)((short)(unsigned)(garr[u2 & 7u] && (unsigned)(x0 >> 70)) > (signed char)0xffffffffu);
    { unsigned t12; double z12; if (((((unsigned)s1 ^ 0x80000000u) / (0x10000u | 1u))) & 1u) { t12 = (a0[u1 & 3u] + (unsigned)c1); z12 = (double)(((unsigned)(4u < (unsigned)(0x663a3715u == (unsigned)(x0 >> 70)))) & 255u); } if (((((unsigned)s1 ^ 0x80000000u) / (0x10000u | 1u))) & 1u) { u0 += t12; d0 = d0 * 0.5 + z12; }
        a0[(unsigned)((short)0x7e34cac0u > (signed char)0x30b42e26u) & 3u] = ((unsigned)(0x80000000u < (unsigned)((int)i1 >= (int)m0)) << ((p2 | 0x80000000u) & 31u));
        if ((u3 / ((0xe92cbf02u * 0x45141d91u) | 1u))) {
            for (;;) { if (--fuel == 0u) goto done;
                if (p0) {
                    u3 = ((g0 % ((unsigned)((unsigned)c0 || (unsigned)w0) | 1u)) * (fuel / (u3 | 1u)));
                    if (budget != 0u) { budget -= 1u; u2 = fn3(a0[i0 & 3u], (u2 | (unsigned)(signed char)(unsigned)((unsigned)h0 < fuel)), 5u); }
                    q0 = &garr[(0x7fffffffu * i2) & 7u];
                    c1 = (signed char)u1;
                } else {
                    c1 = (signed char)(unsigned)(short)(unsigned)((short)i1 > (signed char)(unsigned)h0);
                    *q0 = (unsigned)s1;
                    goto L4;
                }
                d0 = d0 * 0.5 + (double)((unsigned)((0xa4769a8au * u2) || m0) & 1023u);
                c1 = (signed char)-(unsigned)((int)-(unsigned)((short)i1 > (signed char)i1) >= (int)p0);
                if (garr[u2 & 7u]) break;
            }
        } else {
            { unsigned t13; double z13; if (((((unsigned)(w0 >> 29) % (u0 | 1u)) << (1u & 31u))) & 1u) { t13 = ((unsigned)f0 ? (unsigned)l0 : 0u); z13 = (double)(((unsigned)(0x5ee48167u || (unsigned)f0)) & 255u); } if (((((unsigned)(w0 >> 29) % (u0 | 1u)) << (1u & 31u))) & 1u) { u2 += t13; d0 = d0 * 0.5 + z13; }
                goto done;
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((-(0x10000u - 3u) * (unsigned)x0), i1, ((unsigned)(5u || (unsigned)h1) >> (0x10000u & 31u))); }
                    if (budget != 0u) { budget -= 1u; u1 = fn1((i0 ? garr[i1 & 7u] : (unsigned)h1), (unsigned)(0xfa7c7dd8u && 1u), (-(i2 >> (0xa834cc88u & 31u)) * i0)); }
                    g1 += u0;
                }
                u2 += (unsigned)(signed char)(0x10000u << ((unsigned)((unsigned)s1 < (unsigned)s0) & 31u));
                if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)(i1 < (unsigned)c0) < (int)garr[u2 & 7u])) goto L2;
                r0.x = (0x80000000u >> ((unsigned)e0 & 31u));
                h0 = (short)(((u2 + (unsigned)x0) + (unsigned)(2u < 0xffffffffu)) - *q0);
            }
        }
        c1 = (signed char)(unsigned)((int)0xffffffffu >= (int)0x10000u);
    }
    if ((unsigned)w0) goto L4;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 12u, 0x62d752c1u, 0x482a3282u },
        { 1u, 0xca25133du, 0xbc343835u },
        { 5u, 0x2216c461u, 0x9ab30cb3u },
        { 14u, 0x274961d0u, 0xf51e1f8u },
        { 2u, 0x33982a4u, 0xc714d3ecu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
