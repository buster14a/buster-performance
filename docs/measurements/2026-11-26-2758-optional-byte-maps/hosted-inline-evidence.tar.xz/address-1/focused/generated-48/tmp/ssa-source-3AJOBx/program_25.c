// test-ssa-source's program of seed 134000427 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x84ea3c88u, g1 = 0x89d8f414u;
static unsigned garr[8] = { 0xcaf62a23u, 0x7130e33cu, 0xd1635774u, 0x197ac441u, 0x332f3640u, 0xe39473aau, 0xe9fb050cu, 0xb16fe9cbu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((m0 ^ (unsigned)(short)((unsigned)c1 & (unsigned)s0))) break;
        if (((unsigned)(r0.x && (unsigned)d0) - u3)) goto L2;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            garr[*mp & 7u] = (u2 % ((unsigned)((short)g1 > (signed char)(unsigned)!(unsigned)(3u && -(unsigned)(u0 == p2))) | 1u));
            l0 = (long)((unsigned long)l0 + ~(((unsigned)(v0 && 0xa6727b63u) | (unsigned)b0) + garr[u2 & 7u]));
        }
        garr[(0xb8c2587du ^ 1u) & 7u] = (garr[i1 & 7u] / (((unsigned)(unsigned char)(0x601a5193u >> ((unsigned)c1 & 31u)) >> ((a0[u1 & 3u] * fuel) & 31u)) | 1u));
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((unsigned)((int)p1 >= (int)(unsigned)h1) >> ((unsigned)((int)(unsigned)d0 >= (int)0x7fffffffu) & 31u));
        }
        *q0 = (unsigned)(1u == (unsigned)c0);
    }
    if ((unsigned)f0) goto L3;
    do { if (--fuel == 0u) goto done;
        r0.x = (unsigned)(((unsigned)s0 >> ((unsigned)h1 & 31u)) || (unsigned)((int)fuel >= (int)p0));
    } while (i0++ < 4u && (u3 / (8u | 1u)));
    *q0 += (unsigned)(short)(unsigned)((unsigned)!(unsigned)((int)((unsigned)(w0 >> 29) | 8u) < (int)u3) == -(4u - (unsigned)(w0 >> 29)));
    h0 = (short)(m0 % ((unsigned)(signed char)(unsigned)(*mp == a0[i0 & 3u]) | 1u));
    v0 = (unsigned)b0;
    u1 ^= (unsigned)(unsigned char)(unsigned)((int)(unsigned)d0 < (int)((unsigned)l0 >> ((v0 ^ 6u) & 31u)));
    { unsigned t0; double z0; if (((r0.y % (u1 | 1u))) & 1u) { t0 = (u0 % (0x7fffffffu | 1u)); z0 = (double)((i2) & 255u); } if (((r0.y % (u1 | 1u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        L0: if (--fuel == 0u) goto done;
        if ((unsigned)(r0.x < 0xeae180efu)) {
            g0 = ((8u << ((unsigned)(w0 >> 29) & 31u)) | *mp);
        } else {
            if (fuel) goto L1;
            while (i0++ < 5u && (unsigned)((short)(unsigned)(signed char)(garr[i1 & 7u] >> (garr[u2 & 7u] & 31u)) > (signed char)*q0)) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    L1: if (--fuel == 0u) goto done;
                }
                for (;;) { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        L2: if (--fuel == 0u) goto done;
                    }
                    l0 = (long)((unsigned long)l0 + (unsigned)((int)0x10000u < (int)0xe21d7208u));
                    r0.x = g1;
                    L3: if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((unsigned)(*q0 == r0.y) & 255u);
                }
                if ((unsigned)((int)a0[i0 & 3u] >= (int)0xfac3dbdbu)) break;
                garr[((unsigned)(w0 >> 29) ^ 0xffffffffu) & 7u] = ((0x36cdd539u / (2u | 1u)) * i2);
                break; (void)((unsigned)x0);
                g0 = (unsigned)((unsigned)!(a0[u1 & 3u] / ((unsigned)(fuel && 0xffffffffu) | 1u)) && i0);
            }
            *q0 += ((unsigned)w0 ? (unsigned)l0 : i2);
        }
    }
    goto L4;
    f0 = f0 * 0.5f + (float)((0x10000u & (unsigned)((int)i0 >= (int)(unsigned)((int)(unsigned)h0 >= (int)(unsigned)(0x2e0b93f4u == 6u)))) & 255u);
    if (g0) {
        L4: if (--fuel == 0u) goto done;
        if ((unsigned)(signed char)(unsigned)(0x7fffffffu || 0xffffffffu)) goto L0;
        g0 = i1;
        if ((r0.y << (((unsigned)h1 | u0) & 31u))) goto L0;
        l0 = (long)((unsigned long)l0 + (unsigned)((short)p2 > (signed char)0xc63af1c3u));
    }
    if ((unsigned)s1) goto L4;
    if ((0x7fffffffu % (*mp | 1u))) goto done;
    if ((garr[i1 & 7u] * g0)) goto done;
    goto L4;
    while (i0++ < 7u && (unsigned)(*q0 < p2)) { if (--fuel == 0u) goto done;
        s0 = (int)(unsigned)((int)p1 < (int)2u);
    }
    if (u1) goto L1;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            goto L1;
            break; (void)((unsigned)(0x10000u < v0));
            if ((i2 * (fuel | 0x154287f8u))) {
                a0[g0 & 3u] = (p2 & i0);
                break; (void)(a0[i0 & 3u]);
                break; (void)((unsigned)((int)m0 < (int)g1));
            } else {
                if (u2) {
                    c1 = (signed char)(p1 & (unsigned)(short)(fuel | 0x43649dc8u));
                    g0 = (unsigned)(0x7fffffffu < ((unsigned)h1 | (unsigned)d0));
                    h0 = (short)(g0 ? (garr[i1 & 7u] << (v0 & 31u)) : (1u - (unsigned)e0));
                    goto L4;
                    h0 = (short)(v0 | (unsigned)c1);
                }
                if (p2) {
                    if ((unsigned)(short)(0xb0fe966fu - 0x7fffffffu)) break;
                    if ((unsigned)((int)9u >= (int)(0xffffffffu / ((unsigned)f0 | 1u)))) goto L2;
                    if (u3 == 7u) return u1;
                    h1 = (unsigned short)(h1 + (unsigned)((int)(u1 - (unsigned)((int)*q0 >= (int)0x80000000u)) >= (int)p1));
                    if ((unsigned)(short)(i0 - (unsigned)(signed char)(0x99095fc9u % (u3 | 1u)))) break;
                    if (i0) break;
                }
                if ((unsigned)(unsigned char)((unsigned)f0 + (unsigned)l0)) break;
                *q0 = (unsigned)((int)p1 < (int)0x35b3d4f6u);
            }
            *q0 = (unsigned)(u2 || (v0 ? (unsigned)(garr[u2 & 7u] == i1) : (unsigned)c0));
            if ((unsigned)((short)0x3d3a0a8u > (signed char)u0)) break;
            b0 = (unsigned)!((unsigned)(u1 < (garr[i1 & 7u] >> (u3 & 31u))) & (p2 - 0u)) != 0u;
        }
        l0 = (long)((unsigned long)l0 + (unsigned)((int)u1 < (int)((unsigned)e0 | ((unsigned)c0 / (v0 | 1u)))));
        if (7u) {
            h0 = (short)(unsigned)((int)0x10000u >= (int)9u);
            f0 = f0 * 0.5f + (float)((unsigned)!((unsigned)((int)v0 < (int)(g0 >> (p0 & 31u))) - m0) & 255u);
            do { if (--fuel == 0u) goto done;
                if (v0) break;
                a0[0x7fffffffu & 3u] = ((0x2233a85u / (~(unsigned)((unsigned)x0 || 0x3f255006u) | 1u)) ^ 0xffffffffu);
                u0 ^= (0x7fffffffu | (unsigned)s1);
            } while (i1++ < 6u && ((unsigned)(w0 >> 29) * (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)(w0 >> 29))));
        }
        break; (void)((unsigned)(8u < (unsigned)(9u < (unsigned)x0)));
        if ((unsigned)(short)((unsigned)w0 - (unsigned)h1)) break;
        { unsigned t1; double z1; if (((unsigned)w0) & 1u) { t1 = 0xb6a627a8u; z1 = (double)(((unsigned)((int)(unsigned)(garr[i1 & 7u] || u3) < (int)(unsigned)s1)) & 255u); } if (((unsigned)w0) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            if ((u1 - 0x166bec68u)) break;
            v0 = (unsigned)(((unsigned)(unsigned char)(unsigned)((unsigned)x0 == i0) << ((unsigned)d0 & 31u)) == (unsigned)((unsigned)w0 < *q0));
            if ((unsigned)((int)(unsigned)((int)fuel >= (int)a0[u1 & 3u]) >= (int)7u)) {
                { unsigned t2; double z2; if ((0x7fffffffu) & 1u) { t2 = ((0xb48e19beu ^ 0x10000u) >> (0u & 31u)); z2 = (double)((a0[u1 & 3u]) & 255u); } if ((0x7fffffffu) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    if ((unsigned)h0) break;
                    for (;;) { if (--fuel == 0u) goto done;
                        if (8u) {
                            c1 = (signed char)((0x90c2b452u & (unsigned)c0) / ((((unsigned)h1 | garr[i1 & 7u]) >> (0x80000000u & 31u)) | 1u));
                            g1 += ((p1 << (p2 & 31u)) | (1u / ((unsigned)!(unsigned)((int)0x80000000u < (int)p1) | 1u)));
                        } else {
                            break; (void)((unsigned)(p1 || u2));
                        }
                        *q0 = fuel;
                        if (a0[u1 & 3u]) break;
                        w0 ^= (unsigned long long)u1 << ((unsigned)((int)(unsigned)s0 < (int)((unsigned)((*mp & 0x80000000u) < 0x10000u) ^ 1u)) & 63u);
                    }
                    x0 = x0 * 0x100000001b3ull + u1;
                    if (fuel < 8u) return (unsigned)(short)(i2 & (unsigned)s1);
                    switch ((fuel * 0u) & 7u) {
                        if ((unsigned)((int)0x80000000u >= (int)(unsigned)((unsigned)h0 || 0x7133b462u))) continue;
                        continue; (void)((unsigned)((unsigned)((int)m0 < (int)(unsigned)b0) || 5u));
                        u2 ^= *q0;
                        if ((r0.x - 7u)) goto L4;
                    }
                    break; (void)(garr[u2 & 7u]);
                }
                w0 = w0 * 6364136223846793005ull + ((unsigned)((short)a0[i0 & 3u] > (signed char)i2) / ((unsigned)((short)(unsigned)d0 > (signed char)0x2a6e58adu) | 1u));
                while (((g1 >> ((unsigned)(x0 >> 70) & 31u)) ^ i2)) { if (--fuel == 0u) goto done;
                    break; (void)(((unsigned)(w0 >> 29) / ((unsigned)s0 | 1u)));
                    if ((unsigned)h0) break;
                    if ((a0[u1 & 3u] << ((unsigned)(u3 || (unsigned)(x0 >> 70)) & 31u))) break;
                }
                a0[(0u + 0xfc54d945u) & 3u] = (((unsigned)((unsigned)b0 && p1) >> (8u & 31u)) % ((unsigned)((int)v0 >= (int)(unsigned)c1) | 1u));
                goto done;
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)((unsigned)c1 | 0x7fffffffu) > (signed char)0xffffffffu)) break;
                    d0 = d0 * 0.5 + (double)((unsigned)((short)(r0.y | a0[i0 & 3u]) > (signed char)(-(i2 | (unsigned)b0) / (g0 | 1u))) & 1023u);
                } while (i1++ < 6u && a0[i0 & 3u]);
            } else {
                if (garr[i1 & 7u]) break;
                if ((unsigned)s1) {
                    s0 = (int)((i1 ? (0x5c9bb6b7u & r0.y) : (unsigned)c0) - 0xda121b48u);
                    h0 = (short)(unsigned)(i2 || ((unsigned)h1 & g1));
                    x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((short)fuel > (signed char)r0.x) || (unsigned)e0);
                    if ((unsigned)(i2 && garr[u2 & 7u])) goto L1;
                }
                *mp = (unsigned)!(unsigned)((unsigned)(0xffffffffu && u3) && ((unsigned)c0 | (i1 - (unsigned)c0)));
            }
            h0 = (short)(unsigned)(((unsigned)(x0 >> 70) & (unsigned)(signed char)(5u % (4u | 1u))) && 0x67e7242au);
        }
    }
    if (*q0) {
        if (0x10000u) goto done;
        if ((6u & r0.x)) goto L4;
        goto L1;
        switch (p1 & 7u) {
            case 7u: ;
            case 4u: ;
            f0 = f0 * 0.5f + (float)(((((unsigned)s0 + 4u) ? 0x10000u : 0x3f000c9fu) | p2) & 255u);
            { unsigned t3; double z3; if (((unsigned)((short)(unsigned)(i2 == (unsigned)(x0 >> 70)) > (signed char)0x787379cdu)) & 1u) { t3 = (unsigned)((int)0xb89b25c7u < (int)(garr[i1 & 7u] | g1)); z3 = (double)(((unsigned)(x0 >> 70)) & 255u); } if (((unsigned)((short)(unsigned)(i2 == (unsigned)(x0 >> 70)) > (signed char)0x787379cdu)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                case 6u: ;
                *mp = ((garr[i1 & 7u] / (u3 | 1u)) % (((unsigned)f0 & 7u) | 1u));
                v0 = (unsigned)((short)a0[i0 & 3u] > (signed char)i2);
                if ((unsigned)!((unsigned)f0 << ((0x80000000u << (u2 & 31u)) & 31u))) {
                    default: ;
                } else {
                    case 1u: ;
                    b0 = (unsigned)((short)0xd0c57f31u > (signed char)(unsigned)x0) != 0u;
                    if ((i1 * (unsigned)((int)u1 < (int)0x7fffffffu))) {
                        h1 = (unsigned short)(h1 + (unsigned)((unsigned)c1 < a0[i0 & 3u]));
                        g1 += (unsigned)((unsigned)(m0 && u2) || (6u << ((unsigned)x0 & 31u)));
                        garr[(unsigned)((short)0x7fffffffu > (signed char)a0[u1 & 3u]) & 7u] = ~(0x507fa1e3u + ((unsigned)((short)u2 > (signed char)(unsigned)(short)((unsigned)w0 >> (i1 & 31u))) ^ garr[u2 & 7u]));
                    }
                }
                if (0xffffffffu) goto L2;
            }
            switch ((unsigned)x0 & 7u) {
                *mp = (unsigned)((short)0xfd164f8cu > (signed char)(unsigned)(signed char)(*mp - fuel));
                x0 = x0 * 0x100000001b3ull + ((u2 | p2) >> ((unsigned)(p1 == (u0 % (garr[i1 & 7u] | 1u))) & 31u));
                { unsigned t4; double z4; if (((r0.y % ((unsigned)((int)u3 >= (int)u1) | 1u))) & 1u) { t4 = 3u; z4 = (double)((((unsigned)x0 - 0x77c1a5b0u)) & 255u); } if (((r0.y % ((unsigned)((int)u3 >= (int)u1) | 1u))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                    e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)((short)p2 > (signed char)v0) && ((unsigned)e0 % (u2 | 1u))) & 1023u);
                    g0 = garr[u2 & 7u];
                    case 4u: ;
                }
            }
            goto L3;
        }
        if ((u0 ^ *mp)) goto L3;
        if ((unsigned)s0) {
            c0 = (unsigned char)((g1 ? 3u : 0x185cd62bu) % ((unsigned)x0 | 1u));
            q0 = &garr[((unsigned)h1 & ((p0 ? (unsigned)f0 : *q0) / (9u | 1u))) & 7u];
            c1 = (signed char)(p1 % ((unsigned)((unsigned)((short)a0[i0 & 3u] > (signed char)a0[i0 & 3u]) || 0xdc3e0107u) | 1u));
        }
    } else {
        l0 = (long)((unsigned long)l0 + (unsigned)((short)u3 > (signed char)0xa4dcd9b6u));
        for (;;) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)(signed char)((unsigned)b0 & *q0));
            if ((0x376420bbu + p0)) break;
            i2 = (unsigned)(x0 >> 70) & 15u;
            s0 = (int)(unsigned)((0x73bbf42fu | 0x80000000u) < (m0 - garr[u2 & 7u]));
        }
        r0.x = 9u;
        m0 ^= (unsigned)!(unsigned)(6u || (0x7fffffffu << ((unsigned)b0 & 31u)));
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)x0) {
            u3 = ((unsigned)(unsigned char)(0x10000u ? (unsigned)(g1 < (unsigned)l0) : (unsigned)c1) / ((unsigned)s1 | 1u));
        }
        g0 = (unsigned)(signed char)(unsigned)((short)-((unsigned)d0 * ((unsigned)w0 % (p1 | 1u))) > (signed char)(*q0 | (unsigned)s0));
        if ((*mp & (0x6b75257eu - (unsigned)f0))) break;
        v0 = (-(a0[u1 & 3u] ^ (unsigned)b0) % (((unsigned)s0 >> ((unsigned)b0 & 31u)) | 1u));
        switch ((unsigned)(short)(unsigned)((int)g1 < (int)-((unsigned)h0 - m0)) & 7u) {
            m0 ^= ~(unsigned)(2u && (u0 ^ (unsigned)(w0 >> 29)));
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 3u: ;
                f0 = f0 * 0.5f + (float)(((unsigned)(0x80000000u < (unsigned)(0u == (unsigned)d0)) ^ *q0) & 255u);
                w0 = w0 * 6364136223846793005ull + 0xb1c64b5eu;
                case 5u: ;
                if (u3 == 7u) return (unsigned)c0;
                default: ;
            }
            a0[(7u & i1) & 3u] = (unsigned)(short)(((r0.x & 0xffffffffu) - (unsigned)(short)((unsigned)s1 >> (m0 & 31u))) % (9u | 1u));
            if (u3) break;
        }
        for (;;) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)(signed char)(((unsigned)((int)r0.x >= (int)a0[u1 & 3u]) * p1) / ((unsigned)(unsigned char)(unsigned)((int)u0 >= (int)garr[i1 & 7u]) | 1u)) & 1023u);
                goto L3;
                q0 = &garr[(unsigned)((unsigned)(0x967eff6u && 2u) < garr[u2 & 7u]) & 7u];
                b0 = (unsigned)(u3 < p1) != 0u;
                if ((unsigned)((0x7fffffffu << ((unsigned)c0 & 31u)) < garr[i1 & 7u])) goto done;
            }
            if (6u) continue;
            { unsigned t5; double z5; if (((unsigned)!(p1 % (0x10000u | 1u))) & 1u) { t5 = ((unsigned)(short)(g1 % ((unsigned)c0 | 1u)) & i1); z5 = (double)((((unsigned)f0 + 0x850864c7u)) & 255u); } if (((unsigned)!(p1 % (0x10000u | 1u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                w0 = w0 * 6364136223846793005ull + (0xffffffffu % ((unsigned)s0 | 1u));
            }
            x0 = x0 * 0x100000001b3ull + ((unsigned)c0 ^ (unsigned)(0u || garr[i1 & 7u]));
            while ((unsigned)w0) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)-(unsigned)((unsigned)c1 || (unsigned)x0) << (((unsigned)(0x7fffffffu == (0x10000u >> ((unsigned)h0 & 31u))) * g1) & 63u);
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    v0 = (unsigned)((int)(unsigned)b0 >= (int)0x55e18433u);
                    g1 += ~(unsigned)(((unsigned)d0 ^ (4u << (garr[i1 & 7u] & 31u))) < (r0.x << ((unsigned)l0 & 31u)));
                    x0 = x0 * 0x100000001b3ull + 0x80000000u;
                    g0 = (0xad842e6du % (i2 | 1u));
                }
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)(0xf1da9a3fu);
                    while (i1++ < 2u && (u1 % ((unsigned)((int)p2 >= (int)garr[u2 & 7u]) | 1u))) { if (--fuel == 0u) goto done;
                        c1 = (signed char)3u;
                        if (6u) break;
                    }
                }
                if ((0x9ad6ae78u >> (((unsigned)f0 & (unsigned)l0) & 31u))) break;
                if ((unsigned)(signed char)((i1 * a0[i0 & 3u]) & fuel)) break;
            }
        }
    } while (i0++ < 7u && (0x10000u - *mp));
    if (((unsigned)h0 + (unsigned)((unsigned)f0 && 0xa756ba1fu))) goto L3;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = (unsigned)((0x31b6dae3u / (6u | 1u)) < ~(unsigned)(0x10000u == p0));
        if ((p1 << ((unsigned)(x0 >> 70) & 31u))) {
            u3 ^= (((unsigned)w0 * m0) & (unsigned)(v0 == u3));
            if ((0xef94f9d6u ? 0x9fbe927eu : m0)) continue;
            h0 = (short)(8u << (((unsigned)((int)0x31cd6fbu < (int)(unsigned)e0) / ((unsigned)((int)u3 >= (int)p2) | 1u)) & 31u));
            a0[(unsigned)((int)garr[u2 & 7u] < (int)4u) & 3u] = (g0 >> (0x80000000u & 31u));
            r0.x = g0;
        }
        c0 = (unsigned char)(0x80000000u >> (*mp & 31u));
    }
    if ((unsigned)((short)(unsigned)w0 > (signed char)(m0 / (u2 | 1u)))) goto L0;
    l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)((int)(unsigned)(short)((unsigned)l0 % (((unsigned)((int)r0.x >= (int)g1) << (0xcd4246f6u & 31u)) | 1u)) < (int)(unsigned)(x0 >> 70)));
    if ((unsigned)(((unsigned)(x0 >> 70) & u0) || i2)) goto L3;
    if ((unsigned)c1) {
        do { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    g1 += p2;
                } while (i2++ < 3u && ((unsigned)c0 << ((unsigned)c0 & 31u)));
                if ((0xffffffffu % ((unsigned)w0 | 1u))) break;
                u3 = u3 * 0x9e3779b1u + (unsigned)((unsigned)((int)(unsigned)c0 < (int)(u1 + (unsigned)(w0 >> 29))) && ((unsigned)d0 * 0x7fffffffu));
                if ((unsigned)(signed char)((unsigned)(w0 >> 29) | (unsigned)c1)) break;
            }
            r0.y ^= (m0 >> (7u & 31u));
            u2 = u2 * 0x9e3779b1u + (0x2d84e30u ^ i1);
            if (((unsigned)l0 / (((unsigned)l0 % ((unsigned)s1 | 1u)) | 1u))) break;
            d0 = d0 * 0.5 + (double)((unsigned)(signed char)(((unsigned)w0 ^ 4u) + 0x2e25880u) & 1023u);
            if (4u) break;
        } while (i0++ < 4u && a0[i0 & 3u]);
        b0 = -((unsigned)c0 ^ (unsigned)(3u < 7u)) != 0u;
        if (~((unsigned)(w0 >> 29) & 9u)) goto L2;
        switch (((unsigned)b0 ? (unsigned)h0 : (unsigned)d0) & 7u) {
            garr[g0 & 7u] = (i2 ? (p1 ? i2 : v0) : 0x10000u);
        }
        goto L2;
    } else {
        if (((unsigned)h1 >> (0x959a61ecu & 31u))) goto L4;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((p1 * garr[i1 & 7u]));
            d0 = d0 * 0.5 + (double)(garr[i1 & 7u] & 1023u);
            d0 = d0 * 0.5 + (double)((p0 ^ 1u) & 1023u);
            if ((unsigned)((unsigned)((unsigned)b0 == p0) || g1)) continue;
            u0 = u0 * 0x9e3779b1u + (0x7fffffffu >> (v0 & 31u));
            if ((unsigned)(x0 >> 70)) break;
        }
    }
    if (u1) goto L3;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 += (unsigned)((unsigned)!(p1 & g0) < ((unsigned)(w0 >> 29) + r0.y));
    }
    goto L0;
    x0 = x0 * 0x100000001b3ull + ((unsigned)h0 ? m0 : v0);
    if ((unsigned)l0) {
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((a0[i0 & 3u] % ((unsigned)h1 | 1u)));
            h1 = (unsigned short)(h1 + (2u / ((unsigned)!(i2 ^ (garr[u2 & 7u] + 3u)) | 1u)));
            while (i1++ < 2u && (unsigned)(a0[u1 & 3u] < (unsigned)(a0[u1 & 3u] || *q0))) { if (--fuel == 0u) goto done;
                if ((unsigned)e0) {
                    while (i2++ < 2u && ~(unsigned)((int)(unsigned)c0 >= (int)(unsigned)((unsigned)(x0 >> 70) == r0.y))) { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)(unsigned)f0 << (((unsigned)(unsigned char)(4u << ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)h1) & 31u)) * garr[i1 & 7u]) & 63u);
                        do { if (--fuel == 0u) goto done;
                            s1 = (int)((unsigned)s1 + (((0x80000000u & (unsigned)((unsigned)h0 == *mp)) / (fuel | 1u)) ^ (unsigned)c0));
                            if (((unsigned)((unsigned)h0 && 0x7fffffffu) - p2)) goto L4;
                            if ((unsigned)((int)0x80000000u < (int)(unsigned)(p1 < (unsigned)f0))) break;
                        } while (i0++ < 2u && 0xa3b7d00au);
                        e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)((unsigned)(signed char)(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)b0) - (p2 / (~(0xd3479d3fu >> (g1 & 31u)) | 1u))) & 1023u);
                        g0 = ((0x7fffffffu / ((0x2aa1f262u / (p0 | 1u)) | 1u)) & (unsigned)(short)((unsigned)s1 << ((unsigned)d0 & 31u)));
                        if ((unsigned)((int)u3 >= (int)(unsigned)e0)) break;
                    }
                    q0 = &garr[garr[u2 & 7u] & 7u];
                }
                b0 = (0x7fffffffu | (unsigned)((int)(unsigned)x0 < (int)((9u & (unsigned)h1) ^ (unsigned)e0))) != 0u;
                break; (void)((unsigned)((unsigned)s0 < r0.y));
                if ((u1 % ((unsigned)f0 | 1u))) break;
                i0 = (p2 % ((unsigned)(short)(unsigned)(7u || ((unsigned)(w0 >> 29) | -(unsigned)(p0 && p2))) | 1u)) & 15u;
            }
            break; (void)((unsigned)h0);
        }
        goto done;
        if (8u) goto done;
        if ((unsigned)(short)(0x3da0285au % ((unsigned)h0 | 1u))) goto L0;
        if ((unsigned)((int)0x10000u >= (int)a0[i0 & 3u])) goto L2;
    }
    { unsigned t6; double z6; if (((unsigned)(u1 && (unsigned)((short)(unsigned)h0 > (signed char)(unsigned)h1))) & 1u) { t6 = (unsigned)(signed char)(unsigned)((int)9u < (int)(unsigned)((int)i1 >= (int)g0)); z6 = (double)((g0) & 255u); } if (((unsigned)(u1 && (unsigned)((short)(unsigned)h0 > (signed char)(unsigned)h1))) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        goto L2;
        h0 = (short)(unsigned)(r0.x == (((unsigned)w0 | (unsigned)b0) - (unsigned)b0));
        garr[0x10000u & 7u] = (unsigned)((unsigned)(unsigned char)(0xf67286a6u << ((a0[u1 & 3u] - g0) & 31u)) || (i2 % ((unsigned)e0 | 1u)));
    }
    if ((unsigned)(i0 < (fuel / (0x7fffffffu | 1u)))) goto done;
    b0 = ((p0 << (0x10000u & 31u)) % ((0xe49efe8du ^ (unsigned)((int)0x10000u >= (int)0xffffffffu)) | 1u)) != 0u;
    if (((unsigned)b0 >> (garr[u2 & 7u] & 31u))) {
        c1 = (signed char)((unsigned)(fuel < g0) ^ -(unsigned)((unsigned)l0 || (0x10000u / (i1 | 1u))));
        if ((unsigned)((short)0x80000000u > (signed char)(unsigned)h1)) goto L2;
        c0 = (unsigned char)((0x7fffffffu / (((unsigned)b0 << ((unsigned)c1 & 31u)) | 1u)) - *q0);
        while (i0++ < 7u && ((unsigned)((unsigned)c1 || v0) ^ 9u)) { if (--fuel == 0u) goto done;
            g1 += (unsigned)(r0.x && (unsigned)(w0 >> 29));
            switch ((unsigned)(w0 >> 29) & 7u) {
                u0 = (u2 + g0);
            }
            w0 = w0 * 6364136223846793005ull + (u1 >> (p0 & 31u));
            if ((unsigned)d0) break;
            do { if (--fuel == 0u) goto done;
                break; (void)(((r0.x % ((unsigned)w0 | 1u)) % (0x10000u | 1u)));
                if (u2) break;
                break; (void)((unsigned)((short)*mp > (signed char)(9u * fuel)));
                if (8u) break;
            } while (i1++ < 2u && (u0 >> (u1 & 31u)));
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)((unsigned)(i0 == u1));
                break; (void)((~(unsigned)((unsigned)f0 && (unsigned)w0) & v0));
                u0 = (unsigned)f0;
                continue; (void)(((9u & p1) | 0x5980c301u));
            }
        }
    } else {
        for (;;) { if (--fuel == 0u) goto done;
            g0 = (unsigned)((unsigned)h1 && (0x10000u ^ *mp));
            if (((unsigned)(w0 >> 29) * (unsigned)s1)) goto L0;
        }
        c1 = (signed char)((unsigned)((unsigned)x0 < (0x6469de5cu << (a0[i0 & 3u] & 31u))) - (unsigned)c1);
        h0 = (short)~(((unsigned)(short)(unsigned)(0x10000u && a0[i0 & 3u]) ^ u0) % ((unsigned)c0 | 1u));
        x0 = x0 * 0x100000001b3ull + r0.y;
    }
    goto done;
    goto done;
    if (i0) goto L1;
    *q0 = ((unsigned)(signed char)(unsigned)(((unsigned)e0 >> (5u & 31u)) || ((unsigned)h0 % (0x5b04dea0u | 1u))) ^ g0);
    if (p1) {
        h0 = (short)(unsigned)(u2 < (unsigned)s0);
        if ((unsigned)(unsigned char)(0x10000u ^ 4u)) goto L0;
        if (-(0x1b456a27u << (4u & 31u))) goto L0;
    } else {
        r0.x = (unsigned)((int)(unsigned)(0x10000u < (r0.y / (0x80000000u | 1u))) >= (int)(unsigned)!(unsigned)(r0.x == (unsigned)e0));
        h1 = (unsigned short)(h1 + (unsigned)(0x7fffffffu < (((unsigned)(i0 == 0x114d076au) + garr[u2 & 7u]) | m0)));
        s1 = (int)((unsigned)s1 + (unsigned)(short)(0xb583a574u * (0xdd342ae4u & 0xc4f92d48u)));
    }
    { unsigned t7; double z7; if (((u3 * u1)) & 1u) { t7 = (unsigned)((unsigned)s1 < (unsigned)l0); z7 = (double)(((unsigned)(((unsigned)e0 >> ((unsigned)c0 & 31u)) < (unsigned)f0)) & 255u); } if (((u3 * u1)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
        for (;;) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                while (i2++ < 3u && ((unsigned)l0 | (unsigned)(u2 || i2))) { if (--fuel == 0u) goto done;
                    while ((v0 * 0xe893d889u)) { if (--fuel == 0u) goto done;
                        continue; (void)((unsigned)((unsigned)l0 < 0xf525fb6au));
                        b0 = (0xdae1ed2u | (unsigned)((unsigned)(x0 >> 70) == (unsigned)s1)) != 0u;
                        u0 = u0 * 0x9e3779b1u + ((unsigned)b0 % ((unsigned)h1 | 1u));
                        w0 = w0 * 6364136223846793005ull + (unsigned)c0;
                    }
                    if ((*mp * (r0.x << ((unsigned)s1 & 31u)))) break;
                    break; (void)((fuel % (((unsigned)c1 ^ (unsigned)c1) | 1u)));
                }
                m0 ^= u3;
                switch (((0x7fffffffu + i0) << (0xaf052168u & 31u)) & 7u) {
                    m0 ^= ((r0.y << (0xc5e874f9u & 31u)) << ((a0[i0 & 3u] + p1) & 31u));
                }
                break; (void)(((unsigned)(unsigned char)(u2 | i1) & (unsigned)l0));
                *q0 = (unsigned)(unsigned char)((unsigned)h0 % ((unsigned)(signed char)(1u % ((unsigned)x0 | 1u)) | 1u));
            }
        }
        l0 = (long)((unsigned long)l0 + (p0 % (i1 | 1u)));
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = (0x2a7c5b1au << (p2 & 31u));
        if ((i1 >> (6u & 31u))) break;
    }
    if ((8u | (u1 | 0x8a1ab005u))) goto L1;
    { unsigned t8; double z8; if ((2u) & 1u) { t8 = (0xb71f251fu - (4u % (0x938fb489u | 1u))); z8 = (double)(((unsigned)c0) & 255u); } if ((2u) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
        *q0 = ((unsigned)!((unsigned)s0 ^ ~(a0[u1 & 3u] ? 0xffffffffu : (unsigned)c1)) >> ((unsigned)e0 & 31u));
        if (i0) goto L1;
        w0 = w0 * 6364136223846793005ull + (unsigned)(*q0 < (unsigned)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)s1) || 0x80000000u));
        do { if (--fuel == 0u) goto done;
            m0 ^= i1;
            if (v0) break;
            switch ((i1 - 0xab99c071u) & 7u) {
                switch (r0.x & 7u) {
                    u3 ^= (unsigned)((garr[i1 & 7u] / (garr[u2 & 7u] | 1u)) && (unsigned)(a0[u1 & 3u] < (unsigned)x0));
                    a0[(unsigned)((unsigned)e0 || u0) & 3u] = (unsigned)((short)(unsigned)(*mp < (((unsigned)s1 / (0x3e8bcac1u | 1u)) >> ((unsigned)h1 & 31u))) > (signed char)u2);
                    u1 += ((unsigned)s1 - 0xa5e94603u);
                    case 2u: ;
                    w0 = w0 * 6364136223846793005ull + (unsigned)(short)((unsigned)e0 ^ (unsigned)!(unsigned)((int)r0.x >= (int)p0));
                }
                w0 = w0 * 6364136223846793005ull + (7u ^ (unsigned)h1);
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 4u: ;
                    u0 += -(((unsigned)(short)(u1 | g0) ^ 0x367da854u) % (0x41349215u | 1u));
                    v0 = (unsigned)(-(unsigned)(u1 == (unsigned)x0) && (unsigned)!(garr[i1 & 7u] & (unsigned)c0));
                    if ((0x22e8c9cdu % ((p0 | u3) | 1u))) goto L1;
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        s0 = (int)(unsigned)((unsigned)w0 == (g0 * (unsigned)(signed char)(fuel % (((unsigned)(w0 >> 29) - a0[u1 & 3u]) | 1u))));
                        s0 = (int)(unsigned)((unsigned)(i2 == 0x17b460fau) < 2u);
                        case 1u: ;
                        r0.x = fuel;
                        case 5u: ;
                        case 6u: ;
                    }
                }
                do { if (--fuel == 0u) goto done;
                    v0 = (unsigned)(u0 < (unsigned)h0);
                    u2 = u2 * 0x9e3779b1u + ((unsigned)c1 ^ ((unsigned)(unsigned char)(3u >> ((unsigned)h0 & 31u)) % (0xffffffffu | 1u)));
                    s0 = (int)((unsigned)((short)(garr[u2 & 7u] * 3u) > (signed char)(unsigned)f0) >> ((unsigned)(0x659e698fu == r0.x) & 31u));
                } while (i1++ < 5u && (unsigned)e0);
                if ((*q0 % ((unsigned)(a0[u1 & 3u] || p1) | 1u))) {
                    if (0x7fffffffu) continue;
                    case 0u: ;
                    s1 = (int)((unsigned)s1 + ~(((unsigned)h0 | (unsigned)((int)(unsigned)f0 >= (int)m0)) ^ (3u ^ r0.x)));
                    default: ;
                    break;
                    break; (void)((unsigned)((int)1u >= (int)garr[u2 & 7u]));
                }
                if (u3 == 7u) return ((0x7fffffffu | (unsigned)l0) + (0x7fffffffu / (0x1e019bd8u | 1u)));
            }
            c1 = (signed char)(p2 ? (unsigned)((short)0xe3dc1f44u > (signed char)(unsigned)(x0 >> 70)) : p2);
        } while (i0++ < 7u && 0xffffffffu);
    }
    l0 = (long)((unsigned long)l0 + ((unsigned)!(unsigned)((unsigned)s1 && 3u) << ((unsigned)((short)p0 > (signed char)(unsigned)(0x35733381u == p0)) & 31u)));
    if (*mp) {
        goto L2;
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 += (unsigned)((short)((unsigned)d0 >> (i2 & 31u)) > (signed char)8u);
            }
            s1 = (int)((unsigned)s1 + ((unsigned)((int)(unsigned)((unsigned)((int)0x10000u >= (int)garr[i1 & 7u]) < (unsigned)f0) >= (int)p0) << ((unsigned)b0 & 31u)));
            if (~((unsigned)h1 ^ (r0.y << (p2 & 31u)))) break;
            q0 = &garr[(g0 & (fuel ^ (p1 >> ((unsigned)x0 & 31u)))) & 7u];
            if (-((i0 << ((unsigned)(w0 >> 29) & 31u)) >> (a0[i0 & 3u] & 31u))) break;
        }
        f0 = f0 * 0.5f + (float)((unsigned)d0 & 255u);
        r0.y ^= ((unsigned)l0 << (0x7fffffffu & 31u));
        { unsigned t9; double z9; if (((i0 - (i1 >> (g0 & 31u)))) & 1u) { t9 = (unsigned)b0; z9 = (double)((((unsigned)h0 << (*q0 & 31u))) & 255u); } if (((i0 - (i1 >> (g0 & 31u)))) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
            if (((unsigned)h1 * (unsigned)((int)a0[i0 & 3u] >= (int)r0.x))) goto L2;
            do { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (unsigned)(v0 < (0x68930498u >> ((i0 * (unsigned)h0) & 31u))));
            } while (i0++ < 2u && v0);
            r0.x = (unsigned)((int)(v0 | fuel) < (int)(unsigned)(short)(r0.x | (unsigned)l0));
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (*mp) {
            if ((unsigned)((int)0x80000000u < (int)0u)) {
                c0 = (unsigned char)(unsigned)(0x30a3e5f5u && u1);
            }
        } else {
            if ((unsigned)(short)(unsigned)((i2 << (7u & 31u)) || u0)) break;
        }
        q0 = &garr[(unsigned)((unsigned)((short)v0 > (signed char)(unsigned)f0) && (unsigned)((int)(unsigned)s1 >= (int)i1)) & 7u];
        break; (void)((unsigned)((int)u1 >= (int)(unsigned)!(unsigned)((unsigned)e0 && (unsigned)b0)));
    }
    while (i0++ < 7u && (fuel ^ 4u)) { if (--fuel == 0u) goto done;
        goto L0;
        s1 = (int)((unsigned)s1 + -((unsigned)(w0 >> 29) * (unsigned)(short)(unsigned)((int)(0xabfb5e93u >> (r0.y & 31u)) < (int)u2)));
        a0[(unsigned)(signed char)(u0 | 0x80000000u) & 3u] = (m0 % (g0 | 1u));
    }
    if ((0x3e3dfc5cu & p1)) {
        l0 = (long)((unsigned long)l0 + 3u);
    } else {
        do { if (--fuel == 0u) goto done;
            *q0 = (unsigned)(0x10000u == garr[u2 & 7u]);
        } while (i0++ < 5u && ((unsigned)(0xffffffffu && u0) + 4u));
        switch ((a0[u1 & 3u] ^ (unsigned)c0) & 7u) {
            i0 = ((unsigned)(x0 >> 70) << ((unsigned)b0 & 31u)) & 15u;
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((p2 / (a0[i0 & 3u] | 1u)), i0, 0x80000000u); }
            for (;;) { if (--fuel == 0u) goto done;
                if ((i2 >> (0xffffffffu & 31u))) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0(0x16be2ccu, v0, (unsigned)((int)(unsigned)e0 < (int)(unsigned)!((unsigned)h0 % (0x768a1674u | 1u)))); }
                if (budget != 0u) { budget -= 1u; u3 = fn0(-(g0 | i0), (unsigned)((int)(unsigned)h0 >= (int)0xffffffffu), (0x299b3d17u % (5u | 1u))); }
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0(v0, m0, (unsigned)((p1 + (unsigned)l0) < 0x90770b1fu)); }
            if (budget != 0u) { budget -= 1u; u1 = fn0((0x5885f73fu | (i0 & fuel)), (unsigned)((unsigned)c0 || g1), (unsigned)(a0[i0 & 3u] < -(0xc8077e98u ^ garr[u2 & 7u]))); }
            u0 = ((unsigned)c1 ? (unsigned)(signed char)((unsigned)c1 | 0x80000000u) : 0xd5c73f1eu);
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(unsigned)c0 > (signed char)((unsigned)l0 >> ((unsigned)b0 & 31u))), ((unsigned)(g1 == 0xf71f28a4u) & r0.x), a0[i0 & 3u]); }
                u2 ^= ((unsigned)d0 ? 0x7fffffffu : ((a0[i0 & 3u] >> (g1 & 31u)) * *mp));
                switch (p0 & 7u) {
                    w0 ^= (unsigned long long)3u << (i1 & 63u);
                    if (u3) goto done;
                    if ((unsigned)((7u ^ r0.x) || (unsigned)w0)) {
                        u0 = ((a0[i0 & 3u] * (0xceb6a9f4u ^ (unsigned)h0)) & (unsigned)(7u < 0x10000u));
                    } else {
                        l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)h0) == (unsigned)!(g0 ^ i1)) ^ 0x4316e254u));
                        if (0x7fffffffu) goto L0;
                        w0 = w0 * 6364136223846793005ull + (((unsigned)w0 - a0[u1 & 3u]) | ((unsigned)(x0 >> 70) >> (((unsigned)s1 / ((unsigned)h1 | 1u)) & 31u)));
                    }
                    case 5u: ;
                    if (fuel < 8u) return (unsigned)((short)(~(unsigned)((int)u1 >= (int)p1) >> (0x7fffffffu & 31u)) > (signed char)0xffffffffu);
                }
                *q0 = (unsigned)(0xe5d8130u && (0xffffffffu ^ (unsigned)l0));
                if (i1) goto L1;
            } while (i1++ < 7u && garr[i1 & 7u]);
        }
        while (i0++ < 2u && (unsigned)((short)v0 > (signed char)((unsigned)s1 + *mp))) { if (--fuel == 0u) goto done;
            switch ((u2 + (unsigned)((short)a0[i0 & 3u] > (signed char)*q0)) & 7u) {
                if (((r0.x >> (i2 & 31u)) * 0x10000u)) {
                    goto L2;
                } else {
                    L0: if (--fuel == 0u) goto done;
                    *mp = (unsigned)(garr[i1 & 7u] && (2u + (i0 * 0x80000000u)));
                }
                if (((r0.y ^ 0x80000000u) ^ v0)) goto L1;
                switch (8u & 7u) {
                    u0 ^= (unsigned)(unsigned char)(unsigned)((int)(unsigned)x0 < (int)((unsigned)s1 / (5u | 1u)));
                    case 5u: ;
                    case 1u: ;
                    r0.x = (unsigned)((unsigned)c1 < (unsigned)(w0 >> 29));
                }
                case 1u: ;
            }
            x0 = x0 * 0x100000001b3ull + (r0.y >> (0x6daeea91u & 31u));
            h0 = (short)(unsigned)((unsigned)((short)(unsigned)c0 > (signed char)garr[i1 & 7u]) < u2);
            if ((0x78cadbb5u << (g0 & 31u))) {
                w0 ^= (unsigned long long)(unsigned)b0 << (((unsigned)((short)((unsigned)s0 + g1) > (signed char)(unsigned)!(p1 * 0xffffffffu)) - (unsigned)h1) & 63u);
                x0 = x0 * 0x100000001b3ull + g1;
                switch (u0 & 7u) {
                    if ((unsigned)w0) {
                        q0 = &garr[((unsigned)h1 >> (~(garr[u2 & 7u] % ((unsigned)(*q0 < 0x83980ae6u) | 1u)) & 31u)) & 7u];
                        break; (void)((g0 & (g0 - u2)));
                    }
                }
            }
            u2 += (unsigned)((short)(unsigned)(short)((unsigned)s1 >> (5u & 31u)) > (signed char)(unsigned)(0x52124e9au == (unsigned)s0));
        }
    }
    q0 = &garr[(0xbd41672fu ^ fuel) & 7u];
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)c0 & (5u / ((unsigned)b0 | 1u))), (unsigned)((short)fuel > (signed char)(0xffffffffu - r0.y)), -(unsigned)((0x80000000u & v0) < garr[u2 & 7u])); }
    i2 = (unsigned)(short)(((unsigned)(a0[i0 & 3u] == i2) << ((0x80000000u + *q0) & 31u)) % (0x6a5e168cu | 1u)) & 15u;
    goto L0;
    garr[g0 & 7u] = (unsigned)((unsigned)((unsigned)d0 == g1) || 7u);
    s1 = (int)((unsigned)s1 + ((unsigned)l0 * (unsigned)((short)2u > (signed char)(unsigned)f0)));
    goto L3;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t0; double z0; if ((0x88e6be5u) & 1u) { t0 = ((p2 + i2) + 6u); z0 = (double)((g1) & 255u); } if ((0x88e6be5u) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            continue; (void)((garr[i1 & 7u] & m0));
            if (~(unsigned)((short)u2 > (signed char)((unsigned)h1 & 0xb0f17efeu))) break;
            f0 = f0 * 0.5f + (float)((unsigned)((int)*q0 >= (int)0x48bda7dau) & 255u);
            if (((unsigned)(w0 >> 29) / (i2 | 1u))) break;
            e0 = e0 * 0.5L + (long double)(((m0 - (unsigned)((fuel % (a0[i0 & 3u] | 1u)) < 0x80000000u)) | *q0) & 1023u);
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((0x7fffffffu - 0x7fffffffu), (unsigned)(r0.y || *q0), (unsigned)((unsigned)s0 == (fuel | r0.y))); }
        L1: if (--fuel == 0u) goto done;
        garr[(i2 >> (i2 & 31u)) & 7u] = ~(unsigned)((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)h1) || (unsigned)(signed char)(((unsigned)d0 / ((unsigned)s0 | 1u)) & r0.x));
        *q0 = ((1u * (unsigned)d0) - u1);
    }
    q0 = &garr[(unsigned)((0xf98c007du << (a0[i0 & 3u] & 31u)) && (p2 >> ((unsigned)(a0[u1 & 3u] && i1) & 31u))) & 7u];
    q0 = &garr[-(((unsigned)((int)0x3d3fb4f0u < (int)g0) / (0x7fffffffu | 1u)) % (0xd70ae530u | 1u)) & 7u];
    { unsigned t1; double z1; if (((unsigned)(4u && g1)) & 1u) { t1 = (p1 & (unsigned)((unsigned)l0 == 6u)); z1 = (double)(((unsigned)((int)(unsigned)h1 >= (int)(unsigned)((short)u2 > (signed char)i1))) & 255u); } if (((unsigned)(4u && g1)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        b0 = (0x80000000u % (5u | 1u)) != 0u;
        r0.y ^= -(unsigned)((int)((unsigned)h1 ? 6u : 0xffffffffu) >= (int)0xeec832beu);
    }
    if ((u2 / (g1 | 1u))) {
        do { if (--fuel == 0u) goto done;
            if (0x3f07d651u) continue;
        } while (i0++ < 2u && (unsigned)((short)*mp > (signed char)5u));
        if (0x7fffffffu) {
            u1 = (0x7fffffffu / (-(unsigned)((int)p1 < (int)9u) | 1u));
        }
        do { if (--fuel == 0u) goto done;
            switch ((unsigned)c1 & 7u) {
                *q0 += (unsigned)(short)(i0 / (((0x4a094ce8u + i0) << (u3 & 31u)) | 1u));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0(fuel, ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)f0) - v0), (unsigned)(0x82911dffu || (5u + 3u))); }
        } while (i0++ < 3u && (unsigned)((int)(unsigned)h0 >= (int)u2));
        i0 = (((unsigned)!(unsigned)(i0 && p0) << ((unsigned)e0 & 31u)) + (unsigned)w0) & 15u;
    }
    if ((0xe8b312b9u << (v0 & 31u))) goto L4;
    if ((unsigned)w0) {
        q0 = &garr[(unsigned)h0 & 7u];
        goto L1;
        goto done;
        L2: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((2u << (((unsigned)w0 - 0x7869e94fu) & 31u)), (i0 << (u1 & 31u)), (unsigned)((unsigned)d0 || r0.x)); }
    }
    g0 = (unsigned)((unsigned)c0 == ~(unsigned)((int)0x80000000u < (int)(unsigned)(-(a0[u1 & 3u] | 0xf872f99fu) == 7u)));
    L3: if (--fuel == 0u) goto done;
    if (fuel) goto L4;
    switch ((unsigned)((int)(unsigned)(0x80000000u || 9u) >= (int)v0) & 7u) {
        *q0 = i1;
        i0 = (*mp & 8u) & 15u;
        if ((unsigned)((short)0u > (signed char)0xfa32b86fu)) break;
        if (budget != 0u) { budget -= 1u; u2 = fn0(*q0, (unsigned)((int)(unsigned)x0 >= (int)(unsigned)h1), r0.x); }
    }
    u3 ^= (unsigned)(a0[u1 & 3u] == 0xdfe27037u);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0(-(unsigned)((int)(unsigned)(m0 < (unsigned)e0) < (int)(unsigned)s0), (unsigned)((unsigned)d0 && i2), ((7u / (0x80000000u | 1u)) + i1)); }
        while (i1++ < 6u && (unsigned)((int)0x10000u < (int)0x5975f81du)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(g0, (unsigned)(short)(i0 - p0), (a0[i0 & 3u] ? 0x7fffffffu : p1)); }
            *q0 = ((u1 + 9u) * (4u << (fuel & 31u)));
            a0[(unsigned)(u0 && (unsigned)e0) & 3u] = (unsigned)((int)a0[i0 & 3u] < (int)v0);
            garr[(unsigned)((short)(unsigned)x0 > (signed char)g1) & 7u] = ((unsigned)e0 & 0x5817ed91u);
        }
        if ((0x7fffffffu | (unsigned)((int)p0 < (int)a0[u1 & 3u]))) goto L3;
        if (u3 == 7u) return (0x7830cb2u >> (g0 & 31u));
        while ((u3 | *mp)) { if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
        }
    }
    *q0 += (unsigned)(u0 && 0x7fffffffu);
    x0 = x0 * 0x100000001b3ull + (i0 ^ 0x10000u);
    if ((unsigned)(short)((unsigned)((unsigned)(x0 >> 70) && (unsigned)b0) / (g1 | 1u))) goto L0;
    goto L3;
    if (budget != 0u) { budget -= 1u; u0 = fn0((0x7fffffffu ? i1 : 0x1366f940u), ((unsigned)(fuel == fuel) | u0), (unsigned)((int)(unsigned)(w0 >> 29) >= (int)m0)); }
    if (budget != 0u) { budget -= 1u; u2 = fn0(a0[i0 & 3u], ((fuel ^ (unsigned)h0) / ((unsigned)l0 | 1u)), (0x7fffffffu / ((unsigned)c0 | 1u))); }
    d0 = d0 * 0.5 + (double)((unsigned)((int)0u < (int)-((unsigned)((int)u3 >= (int)i2) ^ (unsigned)(x0 >> 70))) & 1023u);
    if ((u2 % ((unsigned)(p0 && i2) | 1u))) goto L1;
    while (i0++ < 6u && (unsigned)l0) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)((short)(unsigned)((int)(0x10000u >> (((unsigned)x0 >> (0x80000000u & 31u)) & 31u)) < (int)(unsigned)(x0 >> 70)) > (signed char)g1);
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)(a0[u1 & 3u] | (i0 & (unsigned)w0));
            w0 ^= (unsigned long long)u1 << (g1 & 63u);
            if (((unsigned)b0 * 0x7fffffffu)) break;
            if ((unsigned)((short)(unsigned)w0 > (signed char)0xfd05f6dbu)) {
                d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)(0x3cf41f06u == (unsigned)(x0 >> 70)) < (int)((unsigned)e0 | (unsigned)(p2 == r0.x))) & 1023u);
                h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(unsigned)((unsigned)x0 && 3u));
            }
            if (((unsigned)((int)(unsigned)l0 < (int)r0.x) | (unsigned)b0)) break;
        }
        if (garr[i1 & 7u]) goto L0;
    }
    do { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (unsigned)(0u || (unsigned)((unsigned)s1 == garr[i1 & 7u]));
        if ((unsigned)((unsigned)s1 < u0)) break;
        if ((r0.y ? i0 : 0x97f8fe23u)) continue;
    } while (i0++ < 3u && (unsigned)!((unsigned)h0 | -(unsigned)((int)(unsigned)(x0 >> 70) < (int)p0)));
    if (garr[i1 & 7u]) goto L3;
    if ((unsigned)((int)garr[u2 & 7u] >= (int)5u)) goto L4;
    if ((0xffffffffu & (unsigned)((int)(unsigned)h0 < (int)1u))) goto done;
    c0 = (unsigned char)*mp;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)(0xf07aca5au || (unsigned)e0) & 7u) {
            i2 = (unsigned)(signed char)((unsigned)(0x19995b7u < 0x5468e901u) ^ 2u) & 15u;
            v0 = ((unsigned)(0u || (0x59c8a19au - (unsigned)x0)) % (i1 | 1u));
            l0 = (long)((unsigned long)l0 + (unsigned)w0);
            w0 = w0 * 6364136223846793005ull + fuel;
            if ((garr[u2 & 7u] - u3)) goto L2;
        }
    }
    if (u0) goto L4;
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)0xffffffffu >= (int)m0), (0x3b6dac28u - (unsigned)(p1 == (unsigned)d0)), *mp); }
    if (((unsigned)l0 ? 0x80000000u : i0)) {
        m0 ^= ((unsigned)((int)fuel < (int)(unsigned)w0) | 6u);
        if ((~(unsigned)((int)v0 >= (int)(unsigned)(x0 >> 70)) * 0x7fffffffu)) {
            r0.x = (u0 * 0x10000u);
        }
    }
    goto L3;
    do { if (--fuel == 0u) goto done;
        break; (void)(0x10000u);
    } while (i0++ < 3u && ((unsigned)l0 - (unsigned)((int)u3 >= (int)0x7fffffffu)));
    b0 = (-(u2 - ((garr[i1 & 7u] >> ((unsigned)f0 & 31u)) << (1u & 31u))) & (unsigned)b0) != 0u;
    if ((unsigned)d0) {
        v0 = (0xffffffffu / ((unsigned)(short)(i1 & i1) | 1u));
        if (6u) {
            b0 = 0x7fffffffu != 0u;
        }
    } else {
        if (0x53479dc3u) goto L0;
        if (((unsigned)(w0 >> 29) & (unsigned)l0)) goto done;
    }
    if ((unsigned)e0) {
        switch (((unsigned)h1 ^ (unsigned)w0) & 7u) {
            case 7u: ;
            if ((unsigned)((int)0xffffffffu >= (int)(0x10000u * garr[i1 & 7u]))) goto L4;
            for (;;) { if (--fuel == 0u) goto done;
                s0 = (int)(unsigned)e0;
                break; (void)((unsigned)((g1 & garr[i1 & 7u]) < 2u));
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(1u || 9u) && 0x10000u);
                { unsigned t2; double z2; if (((p2 % (0xbf77b099u | 1u))) & 1u) { t2 = (0xffffffffu << (0x80000000u & 31u)); z2 = (double)(((unsigned)!((unsigned)((int)m0 < (int)i1) & 0xa00ddf04u)) & 255u); } if (((p2 % (0xbf77b099u | 1u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    if (((unsigned)x0 - (unsigned)(signed char)((unsigned)c1 >> (3u & 31u)))) {
                        u1 ^= (unsigned)!(unsigned)(r0.x < (0x7fffffffu ? (4u - u3) : (unsigned)h0));
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)(unsigned)e0 > (signed char)p2), ((unsigned)(r0.y == 0x10000u) - (unsigned)s0), (0x4034e37du << ((unsigned)h0 & 31u))); }
                        b0 = (unsigned)((unsigned)f0 && (unsigned)((unsigned)((short)u0 > (signed char)u3) && u2)) != 0u;
                        b0 = ((fuel >> (*mp & 31u)) & (unsigned)!(u3 * (unsigned)((int)(unsigned)(w0 >> 29) >= (int)*mp))) != 0u;
                    }
                    case 1u: ;
                    h1 = (unsigned short)(h1 + (8u - ((unsigned)(short)(0x596a7bfeu ^ (unsigned)b0) * 0xffffffffu)));
                    i1 = (unsigned)(0xacfbccfdu < ((unsigned)(x0 >> 70) & 0xffffffffu)) & 15u;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(p2, (p0 - 0x27442a57u), (unsigned)(short)(unsigned)(0x7e1f1893u || (7u >> (u0 & 31u)))); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(r0.x && (unsigned)(w0 >> 29)) && (unsigned)l0), (*q0 ^ garr[u2 & 7u]), (unsigned)f0); }
                }
                goto L0;
            }
            case 0u: ;
            h0 = (short)(unsigned)(short)((unsigned)(u0 || (unsigned)c0) % ((u1 - (unsigned)s0) | 1u));
            g1 += (r0.y >> (0xffffffffu & 31u));
        }
        goto L1;
        if ((unsigned)c0) goto L4;
        r0.x = (a0[u1 & 3u] - (unsigned)((int)((unsigned)h0 + *mp) < (int)(unsigned)(short)(unsigned)(g0 && *mp)));
        if ((unsigned)(0x7fffffffu || (unsigned)(i2 == 0x7fffffffu))) goto L1;
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                switch ((unsigned)b0 & 7u) {
                    w0 = w0 * 6364136223846793005ull + (5u % ((unsigned)((unsigned)((int)(unsigned)h1 >= (int)a0[u1 & 3u]) && (unsigned)c0) | 1u));
                    x0 = x0 * 0x100000001b3ull + (u0 % (a0[i0 & 3u] | 1u));
                    u0 += (unsigned)(g1 || 0x7a9ebeb1u);
                    if (((unsigned)(x0 >> 70) >> ((a0[u1 & 3u] + r0.x) & 31u))) {
                        case 6u: ;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(u1, (unsigned)(signed char)(unsigned)(i2 < *mp), (0x80000000u / ((unsigned)(*q0 < (unsigned)b0) | 1u))); }
                        for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                            case 2u: ;
                            if ((((unsigned)c1 | g0) + (unsigned)w0)) continue;
                            h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)(i1 && (unsigned)c0) >= (int)(unsigned)f0));
                        }
                        for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                            l0 = (long)((unsigned long)l0 + ((unsigned)((short)garr[u2 & 7u] > (signed char)u2) & (unsigned)((int)(unsigned)x0 < (int)0x10000u)));
                            if (((0x98a47b08u >> (garr[u2 & 7u] & 31u)) / (p2 | 1u))) goto L2;
                            if ((v0 * 4u)) continue;
                            h0 = (short)fuel;
                            if (budget != 0u) { budget -= 1u; u1 = fn0(garr[i1 & 7u], a0[i0 & 3u], (unsigned)((short)(p1 & u1) > (signed char)0x80000000u)); }
                        }
                        case 0u: ;
                        case 7u: ;
                    }
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)(unsigned)((short)7u > (signed char)(unsigned)c1) >= (int)p1)) {
                            if (budget != 0u) { budget -= 1u; u1 = fn0(u0, (unsigned)((short)a0[u1 & 3u] > (signed char)fuel), 0x2f6985f9u); }
                            f0 = f0 * 0.5f + (float)((~((unsigned)s0 - 0x10000u) + (unsigned)c0) & 255u);
                            case 5u: ;
                            u0 += 0x7fffffffu;
                        }
                        v0 = (unsigned)!((unsigned)((short)*q0 > (signed char)(unsigned)c1) + (unsigned)f0);
                        if ((unsigned)(r0.x == g0)) continue;
                        a0[(8u - (unsigned)w0) & 3u] = (unsigned)((short)0x10000u > (signed char)((u1 >> (((unsigned)l0 ^ p0) & 31u)) * r0.x));
                        if (budget != 0u) { budget -= 1u; u0 = fn0((i2 + a0[i0 & 3u]), ~((unsigned)(short)(0x9a63a9edu % ((unsigned)f0 | 1u)) << ((unsigned)c0 & 31u)), (unsigned)(0x3c9dcd9au < r0.y)); }
                    } while (i2++ < 5u && 0xaa9e194eu);
                    m0 ^= r0.x;
                }
                if ((fuel ? i1 : 7u)) break;
                l0 = (long)((unsigned long)l0 + i1);
                m0 ^= (0x70426a7bu | (unsigned)(i1 && (i1 ^ (unsigned)h1)));
                switch (((unsigned)(9u == u0) << ((unsigned)(x0 >> 70) & 31u)) & 7u) {
                    if (u3 == 7u) return 0x80000000u;
                    *q0 = (0xeb8601c4u + (unsigned)e0);
                    e0 = e0 * 0.5L + (long double)((unsigned)((int)0xe1a60e86u >= (int)0u) & 1023u);
                }
            } while (i1++ < 5u && (unsigned)(unsigned char)(p1 % ((p1 ^ (unsigned)l0) | 1u)));
            { unsigned t3; double z3; if (((unsigned)((int)v0 >= (int)(unsigned)c1)) & 1u) { t3 = (unsigned)c0; z3 = (double)((9u) & 255u); } if (((unsigned)((int)v0 >= (int)(unsigned)c1)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)0x80000000u >= (int)(unsigned)((unsigned)e0 || 0x7fffffffu));
                s0 = (int)(0xc0aa0022u ? u2 : ((unsigned)x0 | (unsigned)l0));
            }
            if (u0) break;
        } while (i0++ < 4u && (unsigned)s0);
    }
    w0 = w0 * 6364136223846793005ull + (((unsigned)b0 + i0) ^ (unsigned)d0);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    u1 ^= (((unsigned)((int)(unsigned)(a0[i0 & 3u] && 0x7fffffffu) < (int)0x10000u) - 9u) >> (u2 & 31u));
    m0 ^= ((p1 >> (0x80000000u & 31u)) ^ (unsigned)((short)(unsigned)b0 > (signed char)i2));
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)b0, (unsigned)((short)u0 > (signed char)r0.y), (3u & (unsigned)(signed char)((unsigned)d0 >> (i1 & 31u)))); }
    while (i0++ < 6u && (*q0 | (p1 >> (u3 & 31u)))) { if (--fuel == 0u) goto done;
        if ((unsigned)!(unsigned)((unsigned)b0 == (unsigned)(p1 || 0x10000u))) {
            { unsigned t0; double z0; if ((((unsigned)l0 - *mp)) & 1u) { t0 = ((unsigned)x0 + ((unsigned)(x0 >> 70) | i2)); z0 = (double)(((0x10000u + (unsigned)c1)) & 255u); } if ((((unsigned)l0 - *mp)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                if (0x10000u) break;
                q0 = &garr[(garr[i1 & 7u] - ((u2 ? (unsigned)c0 : (unsigned)(w0 >> 29)) * u3)) & 7u];
                garr[8u & 7u] = (unsigned)l0;
                h0 = (short)(unsigned)(((unsigned)(r0.x == garr[i1 & 7u]) ^ (0x7fffffffu << (0x1681ae21u & 31u))) < 0x10000u);
                if (r0.y) goto L1;
            }
        }
    }
    if ((unsigned)(1u < 0x80000000u)) {
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(w0 >> 29) % (i2 | 1u)), (1u / (((unsigned)c1 - fuel) | 1u)), (unsigned)((unsigned)e0 == a0[i0 & 3u])); }
        c0 = (unsigned char)(g0 % ((p0 << (*q0 & 31u)) | 1u));
    } else {
        switch ((unsigned)(a0[i0 & 3u] || (unsigned)l0) & 7u) {
            case 5u: ;
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 6u: ;
                c0 = (unsigned char)(unsigned)((unsigned)(short)(unsigned)((int)0xe676e189u >= (int)m0) < (-(u2 >> (u3 & 31u)) << ((unsigned)(w0 >> 29) & 31u)));
            }
            if (p0) goto L3;
            case 4u: ;
        }
    }
    while (i0++ < 5u && (unsigned)s0) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        c0 = (unsigned char)(unsigned)((0x1bcd2fe7u / (0x15f6137bu | 1u)) && ((unsigned)((unsigned)b0 || 0x7fffffffu) + g1));
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            while (i2++ < 4u && (unsigned)!(r0.y % ((unsigned)s1 | 1u))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)0xffffffffu < (int)0x9ce62dcdu), ((unsigned)f0 ? (unsigned)d0 : m0), ~(0x85c013d4u << (r0.x & 31u))); }
            }
            if (budget != 0u) { budget -= 1u; u3 = fn1((i0 / (p1 | 1u)), 0x8a476505u, (unsigned)h1); }
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)0x80000000u > (signed char)(unsigned)((int)0x421b376bu < (int)(unsigned)b0))) continue;
                break; (void)(0x19c0399fu);
            }
            c0 = (unsigned char)(unsigned)((short)~((0xe93c1ebbu << ((unsigned)e0 & 31u)) + (unsigned)x0) > (signed char)((unsigned)s0 ^ p1));
            if (0x10000u) continue;
        }
        do { if (--fuel == 0u) goto done;
            break; (void)((0x512ee1bfu & 0xffffffffu));
            if ((0xcec6e53fu ? 0x80000000u : p0)) break;
        } while (i1++ < 5u && (garr[i1 & 7u] % ((unsigned)(*mp < (unsigned)d0) | 1u)));
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (1u) break;
        if ((2u >> (0x7a68af6du & 31u))) break;
        L1: if (--fuel == 0u) goto done;
    }
    if (((unsigned)((int)0x10000u >= (int)0x80000000u) - u3)) goto L1;
    do { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (unsigned)(signed char)(unsigned)((int)(unsigned)(0xaf932f8cu && fuel) < (int)fuel);
        if ((u0 ^ (unsigned)c1)) {
            garr[(unsigned)((unsigned)(w0 >> 29) && 2u) & 7u] = (unsigned)(x0 >> 70);
            if (0x3b29b7feu) {
                u1 = u1 * 0x9e3779b1u + (unsigned)((int)((unsigned)(0xa1507133u == 0x10000u) + 0x7fffffffu) >= (int)0x113c0cc3u);
                r0.y ^= (0xfbffebf3u >> ((unsigned)(w0 >> 29) & 31u));
            } else {
                L2: if (--fuel == 0u) goto done;
                if ((*q0 & a0[i0 & 3u])) {
                    L3: if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + r0.x);
                } else {
                    break; (void)((u1 / ((unsigned)d0 | 1u)));
                    L4: if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(unsigned char)(i0 * (0x80000000u | (unsigned)x0)), p2, (i1 << (p1 & 31u))); }
                    switch (((a0[i0 & 3u] << ((unsigned)f0 & 31u)) * 0x10000u) & 7u) {
                        case 6u: ;
                        f0 = f0 * 0.5f + (float)(g1 & 255u);
                    }
                }
                if (((unsigned)(0xffffffffu && (unsigned)(w0 >> 29)) / (m0 | 1u))) continue;
                if (budget != 0u) { budget -= 1u; u3 = fn1((3u % (p1 | 1u)), ~(unsigned)((unsigned)w0 == p2), (unsigned)(*q0 || (r0.y ^ r0.y))); }
            }
            if ((1u - (p1 | p1))) break;
        }
    } while (i0++ < 3u && (unsigned)(p1 < 8u));
    m0 ^= g0;
    if ((unsigned)b0) {
        g1 += g1;
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)((unsigned)s1 || 0xffffffffu));
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)((unsigned)c0 && 0x9976514bu) + r0.y), (0x7fffffffu * (v0 + 1u)), (v0 * 5u)); }
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)0x6890dc27u >= (int)u2), (unsigned)s0, (unsigned)f0); }
        }
        if ((unsigned)(((unsigned)c0 / (fuel | 1u)) || (unsigned)(x0 >> 70))) goto L3;
    } else {
        if (fuel < 8u) return (unsigned)((short)*mp > (signed char)0xb472d709u);
    }
    do { if (--fuel == 0u) goto done;
        switch ((i0 * (unsigned)l0) & 7u) {
            case 6u: ;
        }
    } while (i0++ < 7u && ((i0 & (unsigned)s0) / (i0 | 1u)));
    if (budget != 0u) { budget -= 1u; u2 = fn0(i0, i2, ((unsigned)f0 / ((unsigned)((int)4u >= (int)g1) | 1u))); }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)s0 - (unsigned)f0) == 0x80000000u));
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(signed char)(unsigned)(p2 < a0[u1 & 3u]) && a0[u1 & 3u]), ((unsigned)s0 & u0), i0); }
    if (budget != 0u) { budget -= 1u; u0 = fn1((p0 * 0xf08191cu), (u0 | u3), ((unsigned)(u2 == 1u) * u0)); }
    goto done;
    { unsigned t1; double z1; if ((((unsigned)s1 + a0[u1 & 3u])) & 1u) { t1 = 0x322811b1u; z1 = (double)(((unsigned)((int)(i0 >> (0x651e1550u & 31u)) < (int)(unsigned)h1)) & 255u); } if ((((unsigned)s1 + a0[u1 & 3u])) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        switch (i0 & 7u) {
            r0.x = u2;
            if (budget != 0u) { budget -= 1u; u2 = fn0(-(unsigned)((short)(unsigned)(signed char)(unsigned)((short)5u > (signed char)*q0) > (signed char)p0), ((unsigned)((unsigned)x0 && i0) * 6u), (g1 ^ (unsigned)((int)(unsigned)d0 >= (int)(unsigned)h1))); }
            r0.y ^= (unsigned)((int)i0 >= (int)p0);
            w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)c0 > (signed char)(unsigned)(8u && u3));
            case 4u: ;
            s1 = (int)((unsigned)s1 + (unsigned)((short)v0 > (signed char)a0[i0 & 3u]));
        }
        w0 ^= (unsigned long long)(m0 << (0x80000000u & 31u)) << (((fuel ^ (unsigned)c1) ^ ((unsigned)h1 >> (*q0 & 31u))) & 63u);
        if (p1) goto L2;
    }
    { unsigned t2; double z2; if (((u3 + (unsigned)(i0 && *mp))) & 1u) { t2 = ((unsigned)h1 | 0xc7346506u); z2 = (double)((p2) & 255u); } if (((u3 + (unsigned)(i0 && *mp))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        while (i0++ < 6u && r0.y) { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)((short)5u > (signed char)2u);
            if (budget != 0u) { budget -= 1u; u0 = fn1(g0, (v0 ^ (unsigned)l0), (unsigned)((short)garr[u2 & 7u] > (signed char)(*q0 - g1))); }
            continue; (void)(0x7fffffffu);
            if (u3 == 7u) return (unsigned)(a0[u1 & 3u] == -(((unsigned)s0 ^ 0x7fffffffu) * (fuel >> ((unsigned)(w0 >> 29) & 31u))));
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 += ((unsigned)(6u || (unsigned)(w0 >> 29)) | (unsigned)((i0 << (1u & 31u)) == u3));
        }
        c1 = (signed char)(unsigned)((short)m0 > (signed char)(unsigned)h1);
        switch ((unsigned)!(unsigned)(a0[u1 & 3u] == (unsigned)h0) & 7u) {
            { unsigned t3; double z3; if ((((r0.y & (unsigned)s0) & 0x80eae2du)) & 1u) { t3 = ~(unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)c0); z3 = (double)(((g1 % (garr[i1 & 7u] | 1u))) & 255u); } if ((((r0.y & (unsigned)s0) & 0x80eae2du)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                a0[*mp & 3u] = (unsigned)(signed char)((3u - (unsigned)x0) << (~(unsigned)((unsigned)x0 == p2) & 31u));
                garr[(unsigned)((int)(unsigned)c1 >= (int)i0) & 7u] = (unsigned)((int)((fuel * p0) << ((unsigned)e0 & 31u)) >= (int)(unsigned)l0);
                l0 = (long)((unsigned long)l0 + (unsigned)((short)(unsigned)(p0 == 0x2f42244bu) > (signed char)r0.x));
                if (budget != 0u) { budget -= 1u; u2 = fn0((0x10000u + p1), (i1 & (1u ^ 0x80000000u)), (-(unsigned)((int)u2 >= (int)garr[i1 & 7u]) % (p1 | 1u))); }
                if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)d0 / (0x7fffffffu | 1u)), (unsigned)(g1 == (*q0 + (unsigned)c1)), ((unsigned)d0 & (u1 % (g1 | 1u)))); }
            }
            *q0 += (unsigned)((int)g0 >= (int)p2);
        }
        *mp = (unsigned)(0x86a46d11u == (unsigned)h1);
        goto L4;
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((~((unsigned)s0 ^ garr[i1 & 7u]) + ((unsigned)s0 % (g1 | 1u))) & 1023u);
        u1 += (unsigned)((int)v0 < (int)(unsigned)((int)(0xd5135927u >> ((unsigned)s1 & 31u)) >= (int)fuel));
        break; (void)((u1 << (fuel & 31u)));
        if (((unsigned)w0 * (unsigned)h0)) break;
    }
    if (u3 == 7u) return u3;
    f0 = f0 * 0.5f + (float)(((unsigned)h0 & u3) & 255u);
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)x0, (unsigned)(0x599568d7u < *q0), (unsigned)((int)0x6c5df5b8u < (int)garr[i1 & 7u])); }
    switch (r0.y & 7u) {
        do { if (--fuel == 0u) goto done;
            *q0 = m0;
            g1 += (unsigned)f0;
        } while (i0++ < 2u && 5u);
        if ((unsigned)c1) goto L1;
        break; (void)((unsigned)!(g0 / (0xc09102f3u | 1u)));
        if ((unsigned)h1) goto L1;
    }
    *q0 = i0;
    goto L4;
    *q0 = (u3 | *mp);
    goto L4;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((u1 << (*q0 & 31u)) == u2)) break;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((0x80000000u / (0x9cbf7883u | 1u)) & 1023u);
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)((unsigned)c1 | v0) << ((u3 >> (0xaa76455eu & 31u)) & 63u);
                r0.y ^= (unsigned)(x0 >> 70);
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)c0 < u2), fuel, 0u); }
            } while (i2++ < 3u && (u3 | (unsigned)((int)0u >= (int)i2)));
        }
        d0 = d0 * 0.5 + (double)(u2 & 1023u);
        if (u3) goto L0;
        e0 = e0 * 0.5L + (long double)((unsigned)((short)p2 > (signed char)((unsigned)h0 << ((unsigned)((u1 + r0.y) && (unsigned)(x0 >> 70)) & 31u))) & 1023u);
        w0 ^= (unsigned long long)((unsigned)s0 * r0.x) << ((unsigned)(r0.x && u0) & 63u);
    }
    *q0 = (((unsigned)f0 - ((unsigned)d0 >> (garr[i1 & 7u] & 31u))) % ((unsigned)(v0 < 0xb23512dau) | 1u));
    if (((unsigned)f0 | (unsigned)w0)) goto done;
    g0 = (unsigned)!(((unsigned)b0 << (0x10000u & 31u)) | (r0.y - garr[u2 & 7u]));
    switch ((unsigned)((unsigned)c1 || 0xd2b20266u) & 7u) {
        s1 = (int)((unsigned)s1 + (unsigned)((int)7u >= (int)(m0 - i1)));
    }
    g1 += 0xffffffffu;
    u0 ^= ((0x6d819f9bu + 0xa13efef9u) / (((unsigned)(signed char)(unsigned)((int)0xe16c66afu >= (int)u0) * fuel) | 1u));
    s1 = (int)((unsigned)s1 + *q0);
    a0[garr[i1 & 7u] & 3u] = (unsigned)((int)(6u | 0x7fffffffu) < (int)(unsigned)(0x3aa907fdu == a0[u1 & 3u]));
    if (budget != 0u) { budget -= 1u; u0 = fn0(((i2 / (*q0 | 1u)) * i2), (unsigned)(signed char)(unsigned)((int)g0 >= (int)(3u + 0xffffffffu)), u3); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (a0[i0 & 3u]) goto L3;
    for (;;) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        if (((unsigned)(0xe5850be5u || *mp) / (u1 | 1u))) break;
        w0 = w0 * 6364136223846793005ull + 0x7fffffffu;
    }
    if ((unsigned)((unsigned)((unsigned)h1 && (unsigned)c0) == (unsigned)s0)) {
        { unsigned t0; double z0; if (((u1 - 0u)) & 1u) { t0 = (unsigned)(w0 >> 29); z0 = (double)(((unsigned)((unsigned)x0 < 7u)) & 255u); } if (((u1 - 0u)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)s0, (a0[i0 & 3u] - v0), (*mp ^ (unsigned)((int)r0.x < (int)(unsigned)c0))); }
        }
        garr[(unsigned)((int)r0.x < (int)(unsigned)c1) & 7u] = (p2 | u0);
        L1: if (--fuel == 0u) goto done;
    }
    e0 = e0 * 0.5L + (long double)((unsigned)((int)0xbed4199eu < (int)(unsigned)!(0xffffffffu << ((i1 + (unsigned)f0) & 31u))) & 1023u);
    if (u1) {
        if ((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)(u2 == 0xca52701au))) goto L4;
        h1 = (unsigned short)(h1 + (unsigned)(((unsigned)((unsigned)h1 || 0x1ffedf11u) + 0xffffffffu) && (u2 % (u0 | 1u))));
        switch ((unsigned)e0 & 7u) {
            L2: if (--fuel == 0u) goto done;
            m0 ^= ((5u - g1) / (((unsigned)f0 & 7u) | 1u));
            L3: if (--fuel == 0u) goto done;
        }
        f0 = f0 * 0.5f + (float)(((i2 & 7u) % ((((unsigned)(w0 >> 29) & 0x192a5108u) | (unsigned)l0) | 1u)) & 255u);
        if ((unsigned)(w0 >> 29)) goto L2;
        *q0 += (((g0 / (m0 | 1u)) * p1) / (2u | 1u));
    }
    garr[4u & 7u] = ((unsigned)f0 / (0xffffffffu | 1u));
    u1 ^= ((unsigned)f0 << (((unsigned)((i1 << (p0 & 31u)) && i1) << (p0 & 31u)) & 31u));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(0xffffffffu || (a0[u1 & 3u] ? p0 : (unsigned)(w0 >> 29))) < (unsigned)b0) & 1023u);
        h1 = (unsigned short)(h1 + ((unsigned)(i1 && 0x74884d28u) * (unsigned)c0));
        s0 = (int)(unsigned)(9u && ((u2 & u1) ^ 0x7fffffffu));
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)s1 == (0x80000000u ^ i0)), (0x10000u & 3u), (unsigned)((unsigned)s1 < 0xe16e58b2u)); }
        c1 = (signed char)(unsigned)c1;
        m0 ^= (unsigned)(0x80000000u && v0);
    }
    do { if (--fuel == 0u) goto done;
        u2 += ((unsigned)e0 ? (unsigned)b0 : 0x7fffffffu);
        if (((unsigned)!(unsigned)((int)0x7fffffffu < (int)0x295284f8u) % (a0[i0 & 3u] | 1u))) continue;
        if ((unsigned)(w0 >> 29)) {
            switch (garr[i1 & 7u] & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn0(u1, ((i2 / ((unsigned)c1 | 1u)) & (unsigned)(w0 >> 29)), ((unsigned)(0xe1eb0bd7u || 7u) - (unsigned)c1)); }
                w0 ^= (unsigned long long)(unsigned)(a0[i0 & 3u] || fuel) << (((unsigned)((int)(0x9e6db7d2u / (i2 | 1u)) < (int)(unsigned)w0) | (unsigned)x0) & 63u);
                d0 = d0 * 0.5 + (double)(0xb9b98707u & 1023u);
                d0 = d0 * 0.5 + (double)((unsigned)(short)((unsigned)h1 / ((unsigned)((int)v0 < (int)p2) | 1u)) & 1023u);
                if ((((unsigned)(w0 >> 29) | 0x9027280du) ^ u3)) continue;
            }
        } else {
            r0.x = -(6u + ~(-((unsigned)c1 ^ (unsigned)s1) >> (garr[i1 & 7u] & 31u)));
            x0 = x0 * 0x100000001b3ull + (0u + 0x7fffffffu);
            d0 = d0 * 0.5 + (double)(g1 & 1023u);
            *q0 += i2;
        }
        m0 ^= i1;
    } while (i0++ < 7u && 0xc0ffb594u);
    g1 += (r0.y | garr[u2 & 7u]);
    f0 = f0 * 0.5f + (float)(((unsigned)((short)g0 > (signed char)(unsigned)x0) * (unsigned)h1) & 255u);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)(unsigned)(unsigned char)(unsigned)((short)(unsigned)l0 > (signed char)0x13e76ea9u) << ((unsigned)!(unsigned)((unsigned)d0 || 0x91d37c17u) & 63u);
        if ((unsigned)(u1 < i0)) {
            if ((u2 - (unsigned)((unsigned)(w0 >> 29) == u1))) {
                if (p2) break;
                if ((unsigned)((int)a0[i0 & 3u] >= (int)0xec804061u)) break;
                if (fuel < 8u) return (0x7fffffffu | (unsigned)(x0 >> 70));
            } else {
                l0 = (long)((unsigned long)l0 + ((unsigned)((int)(unsigned)d0 < (int)i0) & (unsigned)((int)g0 < (int)fuel)));
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)(unsigned)s1 > (signed char)0x28d4a757u), (unsigned)h0, (unsigned)f0); }
                if (-(0x94178275u / (*mp | 1u))) {
                    if (0x58837662u) break;
                }
            }
            *q0 = 0x80000000u;
            garr[7u & 7u] = (unsigned)!(3u >> ((unsigned)b0 & 31u));
            switch ((unsigned)((unsigned)x0 == (unsigned)w0) & 7u) {
                break; (void)((unsigned)((short)p2 > (signed char)(unsigned)h0));
                case 5u: ;
                switch (0x80000000u & 7u) {
                    m0 ^= (unsigned)(0xca4533a9u < ((unsigned)h0 ^ (unsigned)(x0 >> 70)));
                }
                g0 = (unsigned)((int)(3u / ((unsigned)(w0 >> 29) | 1u)) >= (int)u1);
            }
        }
        if (u3 == 7u) return (unsigned)((int)(unsigned)l0 >= (int)*mp);
        q0 = &garr[(~(g0 ^ garr[i1 & 7u]) << (0x10000u & 31u)) & 7u];
    }
    while ((unsigned)(v0 || (unsigned)x0)) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            *q0 = (2u % ((((unsigned)b0 << (0u & 31u)) - u1) | 1u));
            g1 += (0x7fffffffu | 0xcdc3ed1eu);
        } while (i1++ < 3u && ((unsigned)c0 ? (unsigned)s1 : 0x7fffffffu));
        g0 = (unsigned)((unsigned)c0 == 0x7fffffffu);
        m0 ^= (unsigned)s0;
        if ((7u / ((unsigned)h0 | 1u))) break;
        l0 = (long)((unsigned long)l0 + ((unsigned)s0 >> (i0 & 31u)));
        L4: if (--fuel == 0u) goto done;
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)3u;
        if (budget != 0u) { budget -= 1u; u3 = fn0(u2, (unsigned)(x0 >> 70), 0xffffffffu); }
        while (i1++ < 7u && (unsigned)l0) { if (--fuel == 0u) goto done;
            if ((i0 | (unsigned)(0x19bac1bcu < 7u))) {
                s0 = (int)(((r0.x % (v0 | 1u)) ^ g0) >> (((unsigned)(w0 >> 29) | 0x7fffffffu) & 31u));
                if ((unsigned)!((unsigned)f0 << (u0 & 31u))) break;
                v0 = 3u;
            }
            { unsigned t1; double z1; if (((*mp & 0x50bdda06u)) & 1u) { t1 = ((p0 % ((unsigned)x0 | 1u)) % ((unsigned)s1 | 1u)); z1 = (double)(((unsigned)(signed char)(unsigned)(garr[i1 & 7u] || 3u)) & 255u); } if (((*mp & 0x50bdda06u)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)s0 && ((unsigned)(x0 >> 70) / (u0 | 1u))), (unsigned)((unsigned)e0 && garr[u2 & 7u]), ~(unsigned)((short)i0 > (signed char)(0x7fffffffu | garr[i1 & 7u]))); }
                c0 = (unsigned char)(fuel & m0);
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)h1, (p1 * u2), ((unsigned)(0xffffffffu == 0xffffffffu) + fuel)); }
                if (~((unsigned)e0 + 5u)) continue;
                if (((unsigned)h1 + (unsigned)c1)) break;
                { unsigned t2; double z2; if ((((a0[i0 & 3u] ^ v0) ^ 0xffffffffu)) & 1u) { t2 = (unsigned)!((unsigned)f0 << ((unsigned)w0 & 31u)); z2 = (double)(((0x7fffffffu ? i0 : p1)) & 255u); } if ((((a0[i0 & 3u] ^ v0) ^ 0xffffffffu)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    a0[u2 & 3u] = (g0 % (((unsigned)((int)(unsigned)(w0 >> 29) >= (int)0x57a1a58bu) >> ((unsigned)((int)2u >= (int)5u) & 31u)) | 1u));
                }
            }
            if (7u) goto L3;
            r0.y ^= (0x80000000u / (0xffffffffu | 1u));
            if ((0x6bf28d94u << (r0.y & 31u))) {
                { unsigned t3; double z3; if (((g1 >> (0xffffffffu & 31u))) & 1u) { t3 = 0xc2bf65c5u; z3 = (double)((0x80000000u) & 255u); } if (((g1 >> (0xffffffffu & 31u))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                    break; (void)((unsigned)l0);
                    if ((unsigned)((int)0x10000u >= (int)4u)) continue;
                    m0 ^= ((unsigned)w0 - ((unsigned)w0 | v0));
                    b0 = (unsigned)((int)(unsigned)s0 >= (int)(unsigned)s1) != 0u;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, (unsigned)(signed char)(unsigned)(garr[i1 & 7u] && *q0), (unsigned)((int)(unsigned)d0 >= (int)(0x10000u % (p0 | 1u)))); }
            } else {
                goto L1;
                a0[(u0 | 3u) & 3u] = (((unsigned)(short)(unsigned)(garr[u2 & 7u] == 8u) | (unsigned)(unsigned char)(unsigned)(fuel || 0x1191d63cu)) >> ((unsigned)h0 & 31u));
                break; (void)((m0 + 0x80000000u));
            }
            while (i2++ < 4u && ((unsigned)!(unsigned)((int)(unsigned)e0 >= (int)p2) / ((unsigned)h1 | 1u))) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(((i1 & m0) << (0xffffffffu & 31u)) & 1023u);
            }
        }
        if ((unsigned)((short)p1 > (signed char)v0)) {
            if ((unsigned)((unsigned)e0 || (1u - 0x98871501u))) continue;
            if ((unsigned)(m0 || (i0 % (0x10000u | 1u)))) goto L2;
            u2 += (((unsigned)(unsigned char)(unsigned)(0x80000000u == (unsigned)l0) - (unsigned)s1) % (((unsigned)c0 - r0.x) | 1u));
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)(unsigned)w0 < (int)(unsigned)d0), 0x1e60c72u, ((unsigned)(w0 >> 29) | (unsigned)e0)); }
            if (budget != 0u) { budget -= 1u; u0 = fn2(p2, (unsigned)(short)(fuel ? 0x7fffffffu : r0.x), p0); }
            if ((unsigned)l0) {
                if ((0x80000000u << (u3 & 31u))) break;
                g0 = (((garr[i1 & 7u] & (unsigned)s0) ^ p0) >> (v0 & 31u));
                s0 = (int)((((unsigned)d0 << (0xe7779b05u & 31u)) & (unsigned)b0) * (*q0 | 5u));
                w0 = w0 * 6364136223846793005ull + (*mp | (m0 ? g1 : garr[i1 & 7u]));
                v0 = (unsigned)((unsigned)(a0[i0 & 3u] && (unsigned)d0) < (unsigned)((0x2d503d61u - (unsigned)c1) || p2));
                if ((0x243d3e3bu | (unsigned)e0)) break;
            }
        } else {
            { unsigned t4; double z4; if ((-(unsigned)((unsigned)d0 == 0xffffffffu)) & 1u) { t4 = (r0.x ^ garr[u2 & 7u]); z4 = (double)(((unsigned)s0) & 255u); } if ((-(unsigned)((unsigned)d0 == 0xffffffffu)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                u3 += (a0[u1 & 3u] << (r0.x & 31u));
            }
            x0 = x0 * 0x100000001b3ull + (7u - g0);
        }
        a0[(unsigned)((int)0x80000000u < (int)0x10000u) & 3u] = ((unsigned)(0xffffffffu || *mp) >> (-(4u / (*q0 | 1u)) & 31u));
        if ((unsigned)(u0 < *mp)) break;
    }
    g1 += (5u * (9u % (u3 | 1u)));
    if ((unsigned)((short)i2 > (signed char)0x80000000u)) goto L2;
    if (a0[u1 & 3u]) goto L1;
    if (((unsigned)l0 * 0xe556c23au)) goto L3;
    b0 = (unsigned)(signed char)(unsigned)(0x2e911f36u || (((unsigned)c0 ^ garr[i1 & 7u]) & p0)) != 0u;
    switch (6u & 7u) {
        c0 = (unsigned char)(unsigned)(u0 < (unsigned)l0);
        case 5u: ;
        { unsigned t5; double z5; if ((0x9c580e46u) & 1u) { t5 = 0xc5ae33f7u; z5 = (double)(((unsigned)(((unsigned)f0 | r0.x) && i1)) & 255u); } if ((0x9c580e46u) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            r0.x = ((((unsigned)s1 >> ((p1 << (r0.y & 31u)) & 31u)) % ((unsigned)d0 | 1u)) & (unsigned)h0);
            e0 = e0 * 0.5L + (long double)(4u & 1023u);
        }
        { unsigned t6; double z6; if (((unsigned)(signed char)((unsigned)e0 - *mp)) & 1u) { t6 = (unsigned)(i2 < r0.y); z6 = (double)(((*mp << (0x80000000u & 31u))) & 255u); } if (((unsigned)(signed char)((unsigned)e0 - *mp)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            if ((9u | 0xa6f4dd85u)) goto L1;
            switch (u3 & 7u) {
                switch ((unsigned)((int)0x65e0aa63u < (int)(unsigned)w0) & 7u) {
                    if ((0x10000u * r0.y)) goto L4;
                    switch (a0[u1 & 3u] & 7u) {
                        if (budget != 0u) { budget -= 1u; u1 = fn1(garr[u2 & 7u], (unsigned)((int)(unsigned)((int)(unsigned)s0 >= (int)0x7fffffffu) < (int)0x7fffffffu), (1u % ((u2 * m0) | 1u))); }
                        case 1u: ;
                        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(w0 >> 29), ((unsigned)d0 & (u1 | i2)), (fuel - (unsigned)s0)); }
                    }
                    r0.x = ((unsigned)(w0 >> 29) - ((unsigned)(signed char)(unsigned)((int)5u >= (int)p1) * (unsigned)d0));
                    c0 = (unsigned char)(unsigned)(unsigned char)((unsigned)((unsigned)h0 == 0x10000u) >> ((fuel >> (0xffffffffu & 31u)) & 31u));
                    do { if (--fuel == 0u) goto done;
                        b0 = garr[u2 & 7u] != 0u;
                        break; (void)((unsigned)((unsigned)!(0x822f553u ^ u3) < u1));
                        case 3u: ;
                        continue; (void)((unsigned)((int)*q0 >= (int)0x7fffffffu));
                        l0 = (long)((unsigned long)l0 + -(unsigned)((int)(unsigned)c0 < (int)m0));
                    } while (i0++ < 4u && ((0x10000u << ((unsigned)h1 & 31u)) >> (u0 & 31u)));
                }
                a0[((unsigned)s1 % (i2 | 1u)) & 3u] = -(unsigned)((int)0x7fffffffu < (int)((unsigned)h0 | (unsigned)(signed char)(i2 >> (i1 & 31u))));
                case 2u: ;
                break; (void)((unsigned)e0);
                goto L2;
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn1((a0[i0 & 3u] << (u3 & 31u)), (unsigned)((0xf2068381u / (0x30d8716eu | 1u)) && (unsigned)h0), a0[u1 & 3u]); }
                    case 5u: ;
                    m0 ^= ((unsigned)s1 / ((g0 >> (5u & 31u)) | 1u));
                    w0 ^= (unsigned long long)(unsigned)d0 << (((unsigned)f0 ^ g1) & 63u);
                    if (u3 == 7u) return r0.x;
                    case 3u: ;
                }
            }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(u3 && (unsigned)(0x10000u < p1)), (unsigned)(w0 >> 29), (unsigned)((unsigned)w0 == 0x7fffffffu)); }
            } while (i0++ < 3u && p2);
            { unsigned t7; double z7; if (((unsigned)(short)(unsigned)(0x87313a8cu || 0x7fffffffu)) & 1u) { t7 = (unsigned)((short)(unsigned)c0 > (signed char)p1); z7 = (double)((((unsigned)(u0 == 0x5abf0f5u) / (i1 | 1u))) & 255u); } if (((unsigned)(short)(unsigned)(0x87313a8cu || 0x7fffffffu)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                { unsigned t8; double z8; if (((unsigned)l0) & 1u) { t8 = (0xffffffffu >> ((2u * p1) & 31u)); z8 = (double)(((unsigned)((int)(unsigned)l0 < (int)u1)) & 255u); } if (((unsigned)l0) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                    b0 = (unsigned)(0x2f6b633cu == -((unsigned)d0 ? ((unsigned)w0 * (unsigned)s1) : (unsigned)l0)) != 0u;
                    f0 = f0 * 0.5f + (float)(i0 & 255u);
                    w0 ^= (unsigned long long)(i0 ^ (unsigned)e0) << ((0x7fffffffu % (v0 | 1u)) & 63u);
                    if (budget != 0u) { budget -= 1u; u0 = fn2(i0, -(8u >> ((unsigned)l0 & 31u)), ((unsigned)((unsigned)l0 || 0x80000000u) | (unsigned)s1)); }
                    if ((unsigned)((int)4u >= (int)(unsigned)((int)0x76e1dac8u < (int)4u))) goto done;
                }
                if ((i0 / (0x4c40257au | 1u))) break;
                case 4u: ;
                if (u3 == 7u) return (unsigned)(0xeecc8503u == (garr[u2 & 7u] % (((unsigned)s1 - (unsigned)w0) | 1u)));
                if (0x80000000u) {
                    *mp = ((unsigned)e0 ^ 6u);
                    s1 = (int)((unsigned)s1 + (unsigned)(((unsigned)s1 - (unsigned)(short)(u3 * (unsigned)(signed char)(0u - (unsigned)(w0 >> 29)))) == 0x4bffba00u));
                    if (fuel) {
                        { unsigned t9; double z9; if (((unsigned)((unsigned)c1 && 0x14961b82u)) & 1u) { t9 = ((unsigned)c0 + (unsigned)((unsigned)h1 && (unsigned)s1)); z9 = (double)(((unsigned)((unsigned)(i2 < m0) < 0x85a4b6d4u)) & 255u); } if (((unsigned)((unsigned)c1 && 0x14961b82u)) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                            w0 ^= (unsigned long long)-(unsigned)((int)(unsigned)b0 < (int)(unsigned)s1) << (((unsigned)((unsigned)h0 && r0.y) * (unsigned)s1) & 63u);
                            *q0 = (unsigned)((int)(unsigned)!((garr[i1 & 7u] % (i2 | 1u)) & u0) >= (int)6u);
                            *q0 += (unsigned)x0;
                            case 3u: ;
                            break; (void)((unsigned)((int)0xb9d9e632u >= (int)(u0 & i0)));
                        }
                        if ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)0xffffffffu)) goto L1;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(a0[u1 & 3u], ((u0 % (i2 | 1u)) >> (0x6fc14834u & 31u)), ((unsigned)(signed char)(unsigned)((short)(unsigned)l0 > (signed char)m0) - v0)); }
                        m0 ^= (-(i2 >> (u1 & 31u)) | (u3 - (unsigned)f0));
                        if (0x80000000u) break;
                    }
                } else {
                    l0 = (long)((unsigned long)l0 + (6u ^ ~(0xa5665d3eu / (0x10000u | 1u))));
                    case 7u: ;
                }
            }
        }
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            b0 = (0x7fffffffu - 0x7fffffffu) != 0u;
            if ((unsigned)((short)2u > (signed char)0x10000u)) continue;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)l0, (unsigned)h0, ((unsigned)(w0 >> 29) | 0x193d5e8fu)); }
    }
    while (i0++ < 5u && -(unsigned)((short)0xc2a002b7u > (signed char)0u)) { if (--fuel == 0u) goto done;
        r0.x = (unsigned)((short)0xd8f55be8u > (signed char)((unsigned)x0 ^ (0xf119d4a9u % (p2 | 1u))));
        c0 = (unsigned char)(unsigned)(0xd290a02u == (unsigned)(3u < i1));
        switch ((unsigned)((int)(unsigned)h1 < (int)3u) & 7u) {
            b0 = (unsigned)!((*q0 + ((unsigned)c0 - *q0)) ^ (g1 | i2)) != 0u;
            if (budget != 0u) { budget -= 1u; u0 = fn0(garr[u2 & 7u], (unsigned)(a0[i0 & 3u] || 0x4d454091u), (unsigned)(0xc9c04d15u || (u3 & m0))); }
            while (0xc6f4a5b3u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(((unsigned)c1 / (u0 | 1u)) || 0u), r0.x, (i0 / ((unsigned)h1 | 1u))); }
                garr[(1u / ((unsigned)f0 | 1u)) & 7u] = (0x67fb6f1du ^ u0);
            }
            case 3u: ;
            u1 += (-(u3 + (unsigned)h1) >> ((4u | (unsigned)((int)(unsigned)e0 >= (int)(unsigned)f0)) & 31u));
        }
        if ((p2 & (0x7fffffffu / (p0 | 1u)))) {
            for (;;) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)!((unsigned)((int)*q0 < (int)0u) + (unsigned)(i2 || 3u)) & 255u);
                break; (void)(7u);
                if ((unsigned)((i0 & (unsigned)s1) < 0x3387554fu)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(u1 == ((unsigned)e0 * 0xffffffffu)), (unsigned)(u1 < (unsigned)(short)((unsigned)s1 ^ u1)), ((unsigned)(x0 >> 70) | g0)); }
                *mp = ((unsigned)((int)3u >= (int)(unsigned)f0) >> (g1 & 31u));
            }
            u1 = ((p1 ? m0 : u2) ^ (unsigned)(*mp < 0x80000000u));
            if (budget != 0u) { budget -= 1u; u0 = fn1(((0x55979cd2u & m0) + 0x80000000u), i1, (unsigned)(4u < (unsigned)f0)); }
            if (budget != 0u) { budget -= 1u; u0 = fn0((a0[u1 & 3u] << (i1 & 31u)), (unsigned)((int)(unsigned)w0 >= (int)(unsigned)((unsigned)h1 || (unsigned)(w0 >> 29))), u1); }
        }
        { unsigned t10; double z10; if (((unsigned)((int)(unsigned)c1 < (int)-(0xd4606014u % (p2 | 1u)))) & 1u) { t10 = i0; z10 = (double)(((unsigned)b0) & 255u); } if (((unsigned)((int)(unsigned)c1 < (int)-(0xd4606014u % (p2 | 1u)))) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                garr[~(r0.y ^ 0x1d2e16e9u) & 7u] = (unsigned)((int)(unsigned)(unsigned char)(unsigned)((int)(u3 << (9u & 31u)) >= (int)0x80000000u) >= (int)(unsigned)(short)(unsigned)(p2 || 7u));
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)(unsigned)s0 < (int)u1), (unsigned)(u2 < ~((unsigned)d0 % (0xb236b367u | 1u))), ((unsigned)d0 ? (unsigned)c1 : (unsigned)b0)); }
                if ((unsigned)(4u || 0x10000u)) break;
                if (((0x80000000u / (7u | 1u)) - 0x1694f84u)) break;
            }
            l0 = (long)((unsigned long)l0 + (u0 * r0.y));
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(fuel < ((unsigned)(w0 >> 29) & i1)), (0x7fffffffu * (unsigned)x0), 0x10000u); }
        }
        q0 = &garr[(unsigned)((short)p1 > (signed char)*q0) & 7u];
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 6u && r0.y) { if (--fuel == 0u) goto done;
            *q0 = a0[i0 & 3u];
            while ((unsigned)(p1 && 0x601de6fcu)) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)0u << ((unsigned)((int)(unsigned)e0 >= (int)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)((unsigned)h1 - (unsigned)(0xa2fb8104u || *q0)))) & 63u);
            }
            w0 = w0 * 6364136223846793005ull + a0[u1 & 3u];
            do { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)s1 & ((unsigned)h1 ^ 0x80000000u)));
                h0 = (short)(u3 | a0[u1 & 3u]);
                w0 ^= (unsigned long long)(unsigned)((int)0xffffffffu >= (int)8u) << ((-(u1 >> (0x3e1eb014u & 31u)) * u0) & 63u);
                if (~((unsigned)((int)(unsigned)h0 >= (int)(unsigned)c0) / (p2 | 1u))) break;
                *q0 = (unsigned)((unsigned)!(unsigned)(0xef09989u && (garr[u2 & 7u] ^ 6u)) < 7u);
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)h1 << (0x24f00ab7u & 31u)), -(g1 & (unsigned)(r0.y && 0xec81f804u)), (unsigned)(signed char)(u1 & *q0)); }
            } while (i2++ < 6u && p2);
            while (i2++ < 4u && (0x10000u & (unsigned)(p1 && 0x1e34da5bu))) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + ~((unsigned)h1 - u0);
                break; (void)(((unsigned)s1 - (unsigned)(x0 >> 70)));
                if (garr[u2 & 7u]) continue;
                h0 = (short)(unsigned)!(unsigned)((int)(unsigned)(p2 && ((unsigned)h0 >> (u2 & 31u))) < (int)(unsigned)s1);
            }
        }
    }
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((unsigned)((unsigned)(x0 >> 70) == a0[u1 & 3u]) < (unsigned)(w0 >> 29)));
        *q0 = (unsigned)(fuel && garr[i1 & 7u]);
        g0 = (unsigned)(garr[i1 & 7u] || (unsigned)w0);
        while (i1++ < 6u && (0x7fffffffu / (0x7fffffffu | 1u))) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if (0x23d594dbu) break;
                if (0xa483b1eeu) {
                    do { if (--fuel == 0u) goto done;
                        break; (void)(0x80000000u);
                        if (i0) break;
                        if (u1) break;
                        if ((0x9b376a83u ^ *mp)) continue;
                        break; (void)(0x80000000u);
                    } while (i0++ < 6u && (unsigned)(p1 || (unsigned)(w0 >> 29)));
                    i0 = ((garr[i1 & 7u] << (garr[i1 & 7u] & 31u)) % (((unsigned)x0 / (*mp | 1u)) | 1u)) & 15u;
                    i1 = (((unsigned)h0 | (unsigned)((unsigned)(w0 >> 29) == (unsigned)h1)) % ((unsigned)(short)(5u + (unsigned)e0) | 1u)) & 15u;
                    *q0 = fuel;
                    break; (void)(-(unsigned)(g0 < u0));
                }
            } while (i2++ < 7u && ((unsigned)s0 % ((i1 >> (g0 & 31u)) | 1u)));
            r0.x = 4u;
            goto L0;
            x0 = x0 * 0x100000001b3ull + a0[u1 & 3u];
            l0 = (long)((unsigned long)l0 + p2);
        }
    } while (i0++ < 3u && (unsigned)((unsigned)((int)u2 >= (int)i1) < 0x7fffffffu));
    c1 = (signed char)(v0 * (*q0 << ((a0[i0 & 3u] * fuel) & 31u)));
    c1 = (signed char)(unsigned)!((unsigned)((int)8u >= (int)9u) / (g1 | 1u));
    i1 = (0x80000000u / (0x10000u | 1u)) & 15u;
    if (((0x7fffffffu + p2) + (unsigned)(w0 >> 29))) goto done;
    if ((6u | 0x586b9b5bu)) goto L0;
    if (((unsigned)c0 - (i0 | p2))) {
        switch ((unsigned)(garr[u2 & 7u] < (unsigned)b0) & 7u) {
            { unsigned t11; double z11; if ((5u) & 1u) { t11 = (unsigned)((unsigned)(0xffffffffu < 2u) == i2); z11 = (double)((fuel) & 255u); } if ((5u) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
                case 3u: ;
                s1 = (int)((unsigned)s1 + ((unsigned)(w0 >> 29) << ((unsigned)(m0 < garr[i1 & 7u]) & 31u)));
                g0 = (unsigned)(unsigned char)(r0.y & (unsigned)((unsigned)e0 && 0x80000000u));
                while (i0++ < 6u && (a0[i0 & 3u] - 0xa4beec98u)) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (unsigned)((g0 / ((unsigned)c0 | 1u)) || *q0);
                    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((unsigned)h1 && (unsigned)(m0 && u0)), (1u - 0x10000u), r0.y); }
                    case 6u: ;
                    switch ((unsigned)((unsigned)((int)g0 < (int)(unsigned)f0) && 0x80000000u) & 7u) {
                        do { if (--fuel == 0u) goto done;
                            v0 = (0x7fffffffu - 0x718b0ea0u);
                            if ((unsigned)!((unsigned)s0 / ((unsigned)(p0 || (unsigned)c1) | 1u))) break;
                            g0 = (0x7fffffffu - (unsigned)b0);
                            if (u1) break;
                            *q0 = (unsigned)(i1 == (unsigned)x0);
                            x0 = x0 * 0x100000001b3ull + ((unsigned)e0 << ((unsigned)b0 & 31u));
                        } while (i1++ < 6u && (unsigned)(signed char)(unsigned)(0x73b6ba04u || (unsigned)c0));
                        u3 += ((1u + fuel) << ((8u * (unsigned)(3u || g1)) & 31u));
                        h0 = (short)((1u * u1) * (unsigned)d0);
                        case 7u: ;
                        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)c1 | (m0 & u3)), (unsigned)w0, (unsigned)(3u < u0)); }
                    }
                    f0 = f0 * 0.5f + (float)(p1 & 255u);
                }
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)(unsigned)(x0 >> 70) >= (int)0xb2ba11dbu), ((unsigned)e0 << (garr[i1 & 7u] & 31u)), (unsigned)(short)((unsigned)d0 >> (((unsigned)c1 | 0x50bb508cu) & 31u))); }
        if ((unsigned)((unsigned)e0 == (unsigned)(x0 >> 70))) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)(fuel ^ (unsigned)f0) > (signed char)0u), ((unsigned)w0 >> ((unsigned)(0x7fffffffu < 0x1246e447u) & 31u)), 0xdc2a08ecu); }
    } else {
        switch ((unsigned)(short)(u2 | (unsigned)(0x8ae8fd1cu < 0u)) & 7u) {
            h0 = (short)(unsigned)(signed char)(unsigned)(0x80000000u && u1);
            v0 = (unsigned)((short)0xe817fa67u > (signed char)(unsigned)(garr[i1 & 7u] == ((i1 >> (0x80000000u & 31u)) ^ fuel)));
        }
    }
    if ((4u / ((unsigned)d0 | 1u))) {
        if (fuel) goto L0;
        g1 += ((unsigned)((int)v0 >= (int)2u) - i2);
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            goto L3;
            g1 += *q0;
            if ((0xa6fd2017u * (unsigned)x0)) break;
            r0.y ^= (unsigned)(signed char)(unsigned)((unsigned)f0 && (9u / (0x7a088d0bu | 1u)));
        }
        h0 = (short)(u1 >> (-(unsigned)((int)(unsigned)((unsigned)w0 == 8u) >= (int)(u2 - p0)) & 31u));
        if ((unsigned)(i2 == 2u)) goto L1;
    } else {
        *mp = ~(unsigned)(0xfd7244ecu || ~((0x947c1f58u / (((unsigned)d0 / (p2 | 1u)) | 1u)) | u0));
        goto L1;
    }
    if ((*mp << ((unsigned)d0 & 31u))) goto L4;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)(i0 && p1) >> (m0 & 31u)) && (unsigned)e0) & 1023u);
    goto L3;
    u2 = u2 * 0x9e3779b1u + (unsigned)(((0xd4f47792u >> ((unsigned)h1 & 31u)) | 3u) == (p0 >> ((unsigned)s0 & 31u)));
    if (0x17506e59u) {
        s1 = (int)((unsigned)s1 + (unsigned)(signed char)((unsigned)b0 | (0xbedc32fau << (0xfde48ce8u & 31u))));
        u1 = (unsigned)((short)((g1 << (1u & 31u)) << ((unsigned)l0 & 31u)) > (signed char)(unsigned)w0);
        g1 += (*q0 + *mp);
        if ((unsigned)(w0 >> 29)) {
            if (~(unsigned)(a0[u1 & 3u] || *q0)) goto L3;
        } else {
            l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)((unsigned)((int)(unsigned)f0 < (int)(3u * (unsigned)b0)) >> ((unsigned)((unsigned)h1 == *mp) & 31u)));
            d0 = d0 * 0.5 + (double)(5u & 1023u);
        }
    } else {
        goto L1;
    }
    goto done;
    s1 = (int)((unsigned)s1 + (unsigned)(1u == (unsigned)((int)(0xf6177281u + (unsigned)d0) >= (int)(p1 & 0xda6a173fu))));
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)(w0 >> 29) >= (int)(4u - 0xffffffffu));
    switch ((unsigned)x0 & 7u) {
        case 5u: ;
        if ((v0 ? (unsigned)c1 : p0)) break;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((i1 ^ 0xa10613acu), (unsigned)(signed char)(r0.x * (0x7d142a8bu / ((unsigned)f0 | 1u))), 0xebdcd02fu); }
            if (*mp) {
                case 4u: ;
                while (i1++ < 6u && (garr[u2 & 7u] ^ 0u)) { if (--fuel == 0u) goto done;
                    b0 = (a0[i0 & 3u] | (unsigned)((short)p2 > (signed char)(0xdd136fb0u << (fuel & 31u)))) != 0u;
                    while (i2++ < 6u && ~(unsigned)(((unsigned)b0 + a0[u1 & 3u]) < 2u)) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)(unsigned)((short)p1 > (signed char)((unsigned)((int)(unsigned)b0 >= (int)(unsigned)d0) ^ g1));
                        g1 += ((unsigned)!(fuel * 0xb0c46028u) / ((fuel | (unsigned)e0) | 1u));
                    }
                    d0 = d0 * 0.5 + (double)((unsigned)!(unsigned)((short)(unsigned)(unsigned char)(4u * garr[u2 & 7u]) > (signed char)(unsigned)!(unsigned)(((unsigned)(x0 >> 70) | (unsigned)w0) < (unsigned)w0)) & 1023u);
                    if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)((unsigned)l0 == ((unsigned)l0 + v0)), (unsigned)((int)(unsigned)b0 >= (int)0x7fffffffu), ((unsigned)(a0[u1 & 3u] < *q0) ^ 0u)); }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn3(((unsigned)s0 | ((unsigned)e0 << ((unsigned)x0 & 31u))), g0, i0); }
                d0 = d0 * 0.5 + (double)((unsigned)(short)(unsigned)((int)(*q0 ? v0 : u1) >= (int)(unsigned)(m0 == (unsigned)h1)) & 1023u);
                w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)((p0 / (i0 | 1u)) << (u1 & 31u));
            }
        } while (i0++ < 7u && (unsigned)x0);
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (i0 | ((unsigned)e0 - (unsigned)(x0 >> 70)));
            L0: if (--fuel == 0u) goto done;
            if (-(unsigned)((int)(unsigned)(x0 >> 70) >= (int)m0)) continue;
            L1: if (--fuel == 0u) goto done;
        }
        if (garr[u2 & 7u]) goto L4;
    }
    if ((0xbd7b51b5u | fuel)) {
        if (4u) goto L2;
        goto L3;
        goto L3;
        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)s1 == (unsigned)(signed char)(u1 ^ (unsigned)e0)));
        if ((unsigned)(short)((0x4c3edc0bu << (a0[i0 & 3u] & 31u)) + (unsigned)f0)) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)0x40f7a472u >= (int)a0[i0 & 3u]), (unsigned)f0, (unsigned)((short)(unsigned)(p1 == (unsigned)e0) > (signed char)*mp)); }
    }
    L2: if (--fuel == 0u) goto done;
    *q0 = ((5u ? 0x80000000u : (unsigned)s0) * ~(unsigned)((int)(unsigned)h1 >= (int)(unsigned)s1));
    L3: if (--fuel == 0u) goto done;
    if (g0) {
        if (u3 == 7u) return (unsigned)!(unsigned)((int)0xffffffffu >= (int)(unsigned)(garr[i1 & 7u] || 0x80000000u));
        m0 ^= (unsigned)((unsigned)f0 || (0x4250411u | u0));
        v0 = (unsigned)(u3 && u0);
        *q0 = ((v0 * 8u) ? 5u : u2);
        *q0 = (1u / (0x8cf68b1fu | 1u));
    }
    switch (p2 & 7u) {
        if (budget != 0u) { budget -= 1u; u1 = fn2((u3 / ((unsigned)c1 | 1u)), (unsigned)((short)m0 > (signed char)(unsigned)x0), (unsigned)((int)2u >= (int)((unsigned)f0 - (unsigned)(w0 >> 29)))); }
        e0 = e0 * 0.5L + (long double)(g1 & 1023u);
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1(7u, (((unsigned)e0 & fuel) / (r0.y | 1u)), (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)((int)g0 < (int)0xffffffffu))); }
            while (garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)s1 >= (int)(unsigned)(short)(unsigned)((int)(g1 | 0x10000u) < (int)(a0[i0 & 3u] % (0x7fffffffu | 1u))));
                    if ((unsigned)((int)(unsigned)s0 >= (int)(unsigned)e0)) goto L0;
                    garr[(g1 >> (garr[i1 & 7u] & 31u)) & 7u] = ((unsigned)d0 ? 0x99f802dcu : *q0);
                }
                if ((unsigned)!(unsigned)((unsigned)(g0 < (unsigned)w0) && 0u)) continue;
                w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(unsigned)(0x80000000u || (unsigned)((short)u1 > (signed char)0x7fffffffu));
                l0 = (long)((unsigned long)l0 + 7u);
            }
            case 2u: ;
        }
        L4: if (--fuel == 0u) goto done;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn2((garr[u2 & 7u] ? g0 : 8u), (0xb6f59a10u >> ((unsigned)h0 & 31u)), ((u1 / ((unsigned)c1 | 1u)) ^ u2)); }
    while (i0++ < 3u && (unsigned)c0) { if (--fuel == 0u) goto done;
        if ((u2 % (a0[i0 & 3u] | 1u))) {
            *mp = (unsigned)((0xce1f30ddu % (u3 | 1u)) == g1);
            if ((6u * ((unsigned)e0 / (g0 | 1u)))) continue;
            if ((0xe05c274du / (5u | 1u))) break;
            u1 ^= ((unsigned)(signed char)(unsigned)((short)g1 > (signed char)g1) - garr[i1 & 7u]);
        }
        garr[0xeaf9d10eu & 7u] = (7u << (0x7ddef702u & 31u));
        do { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)w0;
            garr[i1 & 7u] = 1u;
            break; (void)((unsigned)(x0 >> 70));
            if ((a0[i0 & 3u] >> (r0.x & 31u))) break;
            if ((0x9cae1c8eu ? g0 : v0)) goto L4;
            if ((unsigned)c0) continue;
        } while (i1++ < 6u && (unsigned)((int)0xe7395a6du >= (int)((unsigned)(x0 >> 70) % (0u | 1u))));
        i0 = (unsigned)((int)((unsigned)(x0 >> 70) | 9u) >= (int)i2) & 15u;
        break; (void)((unsigned)(p1 && (unsigned)(w0 >> 29)));
        if ((a0[i0 & 3u] + g0)) break;
    }
    h1 = (unsigned short)(h1 + ((unsigned)c1 - (unsigned)(0xffffffffu == a0[i0 & 3u])));
    while (i0++ < 3u && (g0 - (p2 << (3u & 31u)))) { if (--fuel == 0u) goto done;
        { unsigned t0; double z0; if (((0x7fffffffu | (unsigned)(x0 >> 70))) & 1u) { t0 = garr[u2 & 7u]; z0 = (double)(((2u ^ (unsigned)(w0 >> 29))) & 255u); } if (((0x7fffffffu | (unsigned)(x0 >> 70))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            if ((*q0 - v0)) {
                u2 ^= (unsigned)((unsigned)h1 < ((u3 << ((unsigned)c1 & 31u)) << ((unsigned)((short)0x69e0a8b5u > (signed char)(unsigned)h1) & 31u)));
                c0 = (unsigned char)(unsigned)((int)(0xfd2d933au & (unsigned)f0) < (int)(unsigned)((unsigned)c0 < (3u * (unsigned)b0)));
                if ((unsigned)((int)0x7fffffffu >= (int)(unsigned)!(r0.y % (0x80000000u | 1u)))) continue;
            }
            c1 = (signed char)(unsigned)(short)(unsigned)((garr[i1 & 7u] / (u1 | 1u)) == (unsigned)(((unsigned)h0 * 7u) || 0x80000000u));
            break; (void)((unsigned)(0x7fffffffu < i2));
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(0xffffffffu, ((unsigned)(7u < (unsigned)l0) << (0xb98f6c83u & 31u)), (unsigned)((int)v0 >= (int)(2u - i2))); }
    do { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)((i2 % ((unsigned)c1 | 1u)) && (0x7fffffffu - (unsigned)h0)));
        *mp = ~((unsigned)((int)i2 >= (int)0x10000u) << (0x10000u & 31u));
        if (0xffffffffu) break;
        switch ((unsigned)((int)p2 >= (int)(unsigned)c0) & 7u) {
            *mp = (unsigned)((int)(unsigned)!((unsigned)h0 / (((unsigned)b0 + (unsigned)c1) | 1u)) >= (int)(0xffffffffu % (7u | 1u)));
            if (((unsigned)s0 & (6u | a0[i0 & 3u]))) {
                if (((g1 & r0.y) + a0[u1 & 3u])) goto L0;
                f0 = f0 * 0.5f + (float)(0x10000u & 255u);
            }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(5u < fuel)) break;
                *mp = ((unsigned)(w0 >> 29) * ((unsigned)h1 | (unsigned)e0));
                u2 ^= (((unsigned)((unsigned)(x0 >> 70) && 4u) - 0x4ddb6764u) << ((unsigned)h1 & 31u));
            } while (i1++ < 7u && *q0);
            r0.y ^= (unsigned)(w0 >> 29);
            if ((3u >> ((unsigned)e0 & 31u))) {
                w0 = w0 * 6364136223846793005ull + -(unsigned)((unsigned)((short)m0 > (signed char)r0.y) || (0x575cc07fu + (unsigned)(p1 == fuel)));
                { unsigned t1; double z1; if (((a0[u1 & 3u] ^ (m0 & (unsigned)h0))) & 1u) { t1 = ((unsigned)d0 & (unsigned)!(0x98803bacu | (unsigned)f0)); z1 = (double)((((1u ^ (unsigned)(w0 >> 29)) / (a0[u1 & 3u] | 1u))) & 255u); } if (((a0[u1 & 3u] ^ (m0 & (unsigned)h0))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)(w0 >> 29) + (u3 & garr[i1 & 7u])), (unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) || (unsigned)((int)u3 < (int)u3)), p2); }
                    garr[8u & 7u] = (u1 * ((unsigned)(fuel || p1) % ((*mp - (unsigned)d0) | 1u)));
                    g1 += (5u + (unsigned)((unsigned)((unsigned)s0 < (unsigned)h1) && 0x72597d9au));
                    *q0 = ((*mp * (unsigned)l0) * (unsigned)((short)p2 > (signed char)6u));
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)1u >= (int)(unsigned)c0);
            }
            switch ((0xd4d2cc82u / (0xb1021288u | 1u)) & 7u) {
                h0 = (short)(a0[u1 & 3u] + 2u);
                w0 ^= (unsigned long long)(0x613fd50du / (0x13ae841du | 1u)) << (0xc623e39u & 63u);
            }
        }
        r0.x = (~(unsigned)((unsigned)c1 == ((unsigned)s0 << (i2 & 31u))) + 0x7fffffffu);
    } while (i0++ < 7u && (unsigned)h1);
    if ((unsigned)x0) {
        h0 = (short)((2u >> (p1 & 31u)) % (fuel | 1u));
        do { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + ((unsigned)(*mp < (unsigned)c1) - (fuel ? (unsigned)h1 : 0x16a5f9b0u)));
            { unsigned t2; double z2; if (((unsigned)(short)(unsigned)((g0 * i0) && (unsigned)(x0 >> 70))) & 1u) { t2 = ((unsigned)(v0 && i0) & 0x77c13f53u); z2 = (double)((((unsigned)(w0 >> 29) ^ a0[i0 & 3u])) & 255u); } if (((unsigned)(short)(unsigned)((g0 * i0) && (unsigned)(x0 >> 70))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                c0 = (unsigned char)(unsigned)h0;
                if (budget != 0u) { budget -= 1u; u0 = fn0(((i0 >> (*q0 & 31u)) & *mp), (unsigned)s1, (unsigned)!(p0 << (0x2806f8cdu & 31u))); }
                w0 ^= (unsigned long long)(4u + (unsigned)s0) << (((unsigned)c0 & (unsigned)((unsigned)e0 && r0.y)) & 63u);
                if ((unsigned)((short)*q0 > (signed char)(unsigned)c0)) goto L3;
                if (0x80000000u) continue;
                if ((unsigned)(v0 && (unsigned)((short)u0 > (signed char)(unsigned)h1))) break;
            }
        } while (i0++ < 6u && ((i2 >> (0x29740a5au & 31u)) >> ((unsigned)h1 & 31u)));
        i1 = ((0xffffffffu - (unsigned)(5u && (unsigned)w0)) ? (unsigned)e0 : (unsigned)d0) & 15u;
    }
    c0 = (unsigned char)((unsigned)((int)(a0[i0 & 3u] << (0x7fffffffu & 31u)) < (int)(unsigned)e0) / ((0x10000u ^ garr[u2 & 7u]) | 1u));
    w0 ^= (unsigned long long)(p2 | *q0) << ((0x101d9917u - (i0 ? 0x58ee982fu : g0)) & 63u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 15u, 0x33d0d40du, 0x66b52c72u },
        { 5u, 0x6faed2f3u, 0xa051498eu },
        { 10u, 0xac7930eeu, 0x8713fecbu },
        { 3u, 0x533e7fb1u, 0xc74e7554u },
        { 4u, 0x5679a144u, 0xb52d99b6u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
