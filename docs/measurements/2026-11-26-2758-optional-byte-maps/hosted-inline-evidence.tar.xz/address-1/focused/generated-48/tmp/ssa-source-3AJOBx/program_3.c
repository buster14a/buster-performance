// test-ssa-source's program of seed 134000405 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xf7c280bau, g1 = 0x9763253cu;
static unsigned garr[8] = { 0xb6d67dc0u, 0x9445399au, 0x4098c468u, 0x2a4374e9u, 0x649eaa36u, 0xfd7b2d63u, 0xe3ed863fu, 0x3b0b9c10u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((((unsigned)b0 << (u2 & 31u)) / (g0 | 1u))) goto L0;
    h1 = (unsigned short)(h1 + (-(1u >> (0x1b816c0u & 31u)) & (7u & (unsigned)l0)));
    { unsigned t0; double z0; if (((m0 >> (v0 & 31u))) & 1u) { t0 = (unsigned)l0; z0 = (double)((((unsigned)s1 << (0x80000000u & 31u))) & 255u); } if (((m0 >> (v0 & 31u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if (fuel < 8u) return ((p0 & p0) + 0x80000000u);
        u1 = u1 * 0x9e3779b1u + (0x7fffffffu & (((fuel + 0x80000000u) & u0) / (m0 | 1u)));
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)b0) goto L1;
            a0[(unsigned)e0 & 3u] = (p0 * (unsigned)((short)((unsigned)b0 + u1) > (signed char)(3u ^ (unsigned)f0)));
            if (((unsigned)f0 + u2)) break;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
                if (~((2u * 8u) + p2)) {
                    w0 ^= (unsigned long long)(unsigned)d0 << ((unsigned)(short)(unsigned)(fuel && (r0.x * (unsigned)(6u == (unsigned)(w0 >> 29)))) & 63u);
                } else {
                    if (fuel < 8u) return (unsigned)((short)i0 > (signed char)a0[i0 & 3u]);
                }
            }
            a0[(unsigned)((short)i0 > (signed char)3u) & 3u] = (fuel >> ((unsigned)(short)((unsigned)l0 - 0xebf02b06u) & 31u));
        }
        w0 ^= (unsigned long long)2u << (~(0xfa925a36u / ((garr[i1 & 7u] % (*q0 | 1u)) | 1u)) & 63u);
        if ((unsigned)((unsigned)w0 == ((unsigned)(x0 >> 70) / (m0 | 1u)))) goto L0;
        L1: if (--fuel == 0u) goto done;
    }
    s0 = (int)((unsigned)(x0 >> 70) * 0xffffffffu);
    g1 += (unsigned)(unsigned char)(u2 * p2);
    switch ((((unsigned)c0 * i0) ^ 5u) & 7u) {
        L2: if (--fuel == 0u) goto done;
        g1 += (unsigned)(short)(((unsigned)((int)(6u << ((unsigned)c0 & 31u)) >= (int)(unsigned)(x0 >> 70)) + a0[u1 & 3u]) - fuel);
        for (;;) { if (--fuel == 0u) goto done;
            if (0x312a00b8u) break;
            i1 = 7u & 15u;
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 0u: ;
                c0 = (unsigned char)m0;
                L3: if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                m0 ^= (unsigned)(short)(a0[i0 & 3u] ? 0x95778adu : *mp);
            }
            default: ;
        }
        break; (void)(u1);
    }
    if ((7u % ((unsigned)(u1 || 3u) | 1u))) {
        v0 = ((unsigned)((3u % (r0.x | 1u)) || a0[u1 & 3u]) % (v0 | 1u));
        switch (u0 & 7u) {
            s1 = (int)((unsigned)s1 + ((unsigned)((int)(0x225e0135u | 1u) >= (int)a0[i0 & 3u]) % (*q0 | 1u)));
            s0 = (int)(unsigned)!(unsigned)((~(unsigned)((short)3u > (signed char)u0) - 0x80000000u) || 0x80000000u);
        }
        s1 = (int)((unsigned)s1 + (0x8f4fa1bfu / ((unsigned)e0 | 1u)));
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)(unsigned char)((g1 ? 4u : 0x7fffffffu) << (g0 & 31u));
        }
    } else {
        switch (~(p0 - m0) & 7u) {
            f0 = f0 * 0.5f + (float)((unsigned)w0 & 255u);
            r0.y ^= ((unsigned)f0 ? 0x86e5245eu : (unsigned)h1);
        }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            u2 = u2 * 0x9e3779b1u + a0[i0 & 3u];
            { unsigned t1; double z1; if ((((unsigned)(0x7fffffffu || 0x7fffffffu) - u0)) & 1u) { t1 = r0.y; z1 = (double)((((unsigned)!(garr[i1 & 7u] + p1) << ((unsigned)f0 & 31u))) & 255u); } if ((((unsigned)(0x7fffffffu || 0x7fffffffu) - u0)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                if ((p0 - (unsigned)e0)) break;
                goto L0;
                r0.x = (garr[u2 & 7u] - p0);
                u0 = g0;
            }
        }
        do { if (--fuel == 0u) goto done;
            goto L4;
            if ((unsigned)c0) break;
            { unsigned t2; double z2; if (((unsigned)((short)~(unsigned)((int)u2 < (int)0x49118ecfu) > (signed char)(unsigned)c0)) & 1u) { t2 = (0x80000000u / ((unsigned)w0 | 1u)); z2 = (double)(((unsigned)((int)(1u - (unsigned)b0) >= (int)(unsigned)w0)) & 255u); } if (((unsigned)((short)~(unsigned)((int)u2 < (int)0x49118ecfu) > (signed char)(unsigned)c0)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                break; (void)((unsigned)(w0 >> 29));
            }
        } while (i0++ < 2u && m0);
        r0.x = ((unsigned)s0 * p1);
    }
    goto done;
    switch ((0x44023236u * 0x87b2c80cu) & 7u) {
        case 0u: ;
        default: ;
        *mp = p2;
        while (i0++ < 3u && 2u) { if (--fuel == 0u) goto done;
            v0 = 0x41af8defu;
            w0 ^= (unsigned long long)(unsigned)(a0[u1 & 3u] || 1u) << ((unsigned)((int)(unsigned)(unsigned char)(9u % ((p1 + u2) | 1u)) >= (int)(unsigned)c1) & 63u);
            { unsigned t3; double z3; if (((unsigned)((int)(unsigned)f0 >= (int)(1u - (unsigned)w0))) & 1u) { t3 = (0xffffffffu - (unsigned)(x0 >> 70)); z3 = (double)((p2) & 255u); } if (((unsigned)((int)(unsigned)f0 >= (int)(1u - (unsigned)w0))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                case 1u: ;
                c0 = (unsigned char)(u2 << (r0.x & 31u));
                break;
            }
            u1 = (unsigned)(v0 && 0x9f50ec35u);
            if (0x41786a4cu) break;
        }
        if ((unsigned)((int)(unsigned)!(unsigned)(i1 && (unsigned)l0) >= (int)0xcf333372u)) {
            u3 += ~(unsigned)(((unsigned)((short)0xf3669eaau > (signed char)(unsigned)(x0 >> 70)) % (0x7fffffffu | 1u)) < (unsigned)((int)0x8ce03ad3u < (int)i2));
            case 4u: ;
            case 7u: ;
            if (v0) break;
            break;
            *q0 += (unsigned)(((9u | (0xb047345fu + g0)) >> (u2 & 31u)) && p1);
        }
        r0.y ^= ((0xd6d9868cu << ((0x7fffffffu | 0xc4ce237fu) & 31u)) >> (*q0 & 31u));
    }
    if ((unsigned)(i2 && (unsigned)c0)) {
        garr[3u & 7u] = (unsigned)(w0 >> 29);
        g0 = (unsigned)(signed char)(fuel >> ((unsigned)((int)(unsigned)s0 >= (int)0x80000000u) & 31u));
        if ((unsigned)l0) goto L0;
        goto done;
        if ((0x21530a7du * ((unsigned)h0 + fuel))) goto L3;
    }
    if (i1) goto L4;
    if (((unsigned)!(unsigned)((int)0xbda117e5u >= (int)*q0) - g1)) goto done;
    w0 = w0 * 6364136223846793005ull + g0;
    s1 = (int)((unsigned)s1 + ((unsigned)(0xbc127654u || *mp) + (unsigned)h1));
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)r0.x > (signed char)(unsigned)((short)u0 > (signed char)g0))) continue;
        if ((*mp - g0)) {
            *mp = (unsigned)(unsigned char)(unsigned)((int)4u < (int)(unsigned)((int)*q0 < (int)(unsigned)(w0 >> 29)));
            do { if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)(i1 == u2) & 7u];
            } while (i1++ < 3u && (unsigned)s1);
            c0 = (unsigned char)(unsigned)((unsigned)f0 || (unsigned)((int)((unsigned)(w0 >> 29) & (unsigned)c0) >= (int)i0));
            if ((unsigned)(unsigned char)(unsigned)((int)g0 >= (int)r0.y)) break;
            if ((0x80000000u * 0xbc8e7b06u)) break;
            d0 = d0 * 0.5 + (double)(((unsigned)(x0 >> 70) | (0xd7b4fa83u / ((unsigned)(w0 >> 29) | 1u))) & 1023u);
        } else {
            g0 = (unsigned)((i1 >> (a0[u1 & 3u] & 31u)) < r0.x);
            break; (void)((a0[u1 & 3u] - 0x7fffffffu));
        }
        while (~(u1 - (unsigned)((short)(unsigned)e0 > (signed char)p0))) { if (--fuel == 0u) goto done;
            if ((unsigned)((r0.x >> (r0.y & 31u)) && *q0)) goto L3;
            switch (fuel & 7u) {
                case 2u: ;
                h0 = (short)((0x645696f1u ^ a0[u1 & 3u]) * u0);
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    *q0 += ((unsigned)(w0 >> 29) / (g0 | 1u));
                    case 0u: ;
                    w0 ^= (unsigned long long)p0 << ((unsigned)((short)(unsigned)c1 > (signed char)(unsigned)((short)0xc7cd8afdu > (signed char)(unsigned)((short)0xb8444eccu > (signed char)u3))) & 63u);
                    case 4u: ;
                }
                case 5u: ;
            }
            if ((unsigned)f0) break;
            u1 = u1 * 0x9e3779b1u + (unsigned)s0;
        }
        if ((unsigned)(u3 || (*mp >> (g0 & 31u)))) break;
        if ((unsigned)((unsigned)h0 == ((unsigned)d0 | garr[u2 & 7u]))) break;
        h1 = (unsigned short)(h1 + (unsigned)(u1 < u0));
    }
    q0 = &garr[((unsigned)(unsigned char)((unsigned)c0 + (unsigned)l0) >> (u1 & 31u)) & 7u];
    *q0 = 0xda310fd1u;
    if (p1) goto L1;
    goto L2;
    if ((unsigned)((int)0x4073ab0cu >= (int)6u)) goto L4;
    if ((0x10000u / ((a0[u1 & 3u] ^ 0xf68b2dc7u) | 1u))) {
        { unsigned t4; double z4; if (((unsigned)f0) & 1u) { t4 = a0[i0 & 3u]; z4 = (double)((a0[u1 & 3u]) & 255u); } if (((unsigned)f0) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                u3 ^= (3u >> ((u0 * 0xf7c2918eu) & 31u));
                h0 = (short)(unsigned)((int)(unsigned)s0 < (int)v0);
            }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)(garr[i1 & 7u] && u0) || u2)) break;
                h1 = (unsigned short)(h1 + (0x46314c72u + (unsigned)w0));
                *q0 = (unsigned)((u3 & (unsigned)s1) == (unsigned)h0);
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)u2 >= (int)(unsigned)((int)0xffffffffu >= (int)7u))) break;
                }
                break; (void)((unsigned)(i1 < (unsigned)((int)(unsigned)h0 >= (int)0x7058191bu)));
            } while (i0++ < 5u && 0x10000u);
            *q0 += p0;
            if ((unsigned)(w0 >> 29)) goto L2;
        }
        *mp = (unsigned)h1;
        x0 = x0 * 0x100000001b3ull + (unsigned)(p1 < 0xffffffffu);
    }
    *q0 = (*mp >> (0xd40d32e4u & 31u));
    goto L1;
    if (a0[u1 & 3u]) goto done;
    { unsigned t5; double z5; if (((*mp + (unsigned)w0)) & 1u) { t5 = (unsigned)((short)a0[u1 & 3u] > (signed char)(i1 << ((unsigned)h1 & 31u))); z5 = (double)(((0xffffffffu + 0x80000000u)) & 255u); } if (((*mp + (unsigned)w0)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        if (((0x752f1bcau * u0) + (unsigned)c1)) {
            goto L2;
        } else {
            if (0u) goto L0;
            if ((r0.x & (unsigned)l0)) goto L3;
        }
        if (((i1 << (3u & 31u)) + 1u)) {
            switch ((unsigned)(~(unsigned)((unsigned)s0 && m0) == 0xffffffffu) & 7u) {
                u1 = u1 * 0x9e3779b1u + (0x5e2e43b7u * (unsigned)((int)0x7fffffffu < (int)0x284353d9u));
                r0.y ^= ((unsigned)(short)((unsigned)h1 | (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)(w0 >> 29))) / ((unsigned)s1 | 1u));
                w0 = w0 * 6364136223846793005ull + (unsigned)(5u < v0);
                case 4u: ;
                if ((unsigned)(u2 == 0x70a10e94u)) break;
            }
            if ((unsigned)e0) {
                c0 = (unsigned char)(unsigned)((short)(r0.x >> (0x10000u & 31u)) > (signed char)*q0);
                m0 ^= (r0.x % (0x9b6d07cdu | 1u));
                while (i0++ < 3u && -(unsigned)((g1 << ((unsigned)w0 & 31u)) || (unsigned)d0)) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)(short)(g0 >> ((unsigned)(fuel || 0xf59d6d4au) & 31u)));
                    if (~(p2 ^ u1)) goto L4;
                    break; (void)(*q0);
                    b0 = (unsigned)(i1 < ((0xbdec1851u - (unsigned)s1) & (a0[i0 & 3u] % ((unsigned)c1 | 1u)))) != 0u;
                    if (0x7fffffffu) break;
                    u1 ^= (unsigned)(a0[i0 & 3u] && (r0.x << ((unsigned)!(unsigned)((int)(unsigned)f0 >= (int)0x5b4f0beu) & 31u)));
                }
                if (-(unsigned)(fuel || garr[u2 & 7u])) goto L1;
                s0 = (int)((unsigned)s0 ? 0x1e0dce93u : ~(unsigned)(*mp == ~(a0[i0 & 3u] + i2)));
            }
            { unsigned t6; double z6; if (((unsigned)(signed char)(unsigned)((int)(unsigned)f0 < (int)0x9ea913c6u)) & 1u) { t6 = ((unsigned)x0 ^ p0); z6 = (double)(((unsigned)l0) & 255u); } if (((unsigned)(signed char)(unsigned)((int)(unsigned)f0 < (int)0x9ea913c6u)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                do { if (--fuel == 0u) goto done;
                    s0 = (int)0x7fffffffu;
                    if (((unsigned)(*mp == i0) << ((unsigned)h0 & 31u))) break;
                } while (i0++ < 7u && u2);
                *mp = a0[u1 & 3u];
                if (fuel < 8u) return (g1 & fuel);
                goto L0;
                for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)(0x10000u && (unsigned)(short)(9u / (garr[i1 & 7u] | 1u))));
                    h1 = (unsigned short)(h1 + p1);
                    r0.y ^= (unsigned)w0;
                    if ((unsigned)((unsigned)h0 || i0)) break;
                    if ((i0 / (((unsigned)(w0 >> 29) >> (*q0 & 31u)) | 1u))) break;
                    l0 = (long)((unsigned long)l0 + ((unsigned)b0 ^ (unsigned)(short)(unsigned)((u2 >> (3u & 31u)) || ((unsigned)c1 / ((unsigned)h0 | 1u)))));
                }
            }
            if (i2) goto L4;
            if (*q0) {
                r0.y ^= (9u ^ (unsigned)(v0 == 0x49f1ac6bu));
                if (a0[i0 & 3u]) goto L0;
                a0[(unsigned)!(garr[u2 & 7u] * 0x80000000u) & 3u] = ((unsigned)l0 & 0x80000000u);
                if ((unsigned)h1) goto L2;
            }
            c1 = (signed char)(unsigned)h0;
        } else {
            if (p1) goto L1;
            a0[(unsigned)h0 & 3u] = (unsigned)h1;
            u2 = u2 * 0x9e3779b1u + (~(unsigned)((unsigned)(0x7fffffffu == r0.y) || (unsigned)e0) % ((unsigned)(signed char)(unsigned)((unsigned)e0 < (unsigned)d0) | 1u));
        }
        switch (((unsigned)s0 << (p1 & 31u)) & 7u) {
            do { if (--fuel == 0u) goto done;
                if (a0[i0 & 3u]) continue;
            } while (i0++ < 7u && (unsigned)((p2 * v0) && (unsigned)b0));
            case 5u: ;
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= (garr[u2 & 7u] >> ((0x10000u | garr[i1 & 7u]) & 31u));
                r0.x = (unsigned)(short)(unsigned)((short)((unsigned)((int)p1 >= (int)i0) * (unsigned)h1) > (signed char)(unsigned)(short)(0xffffffffu + a0[i0 & 3u]));
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 4u: ;
                    switch (0x80000000u & 7u) {
                        c0 = (unsigned char)u2;
                        case 6u: ;
                    }
                    l0 = (long)((unsigned long)l0 + (((unsigned)h1 % (1u | 1u)) % ((unsigned)(signed char)(unsigned)(u1 && 0x8880ca06u) | 1u)));
                    h1 = (unsigned short)(h1 + p1);
                    u2 += (4u >> (g1 & 31u));
                }
            }
            garr[4u & 7u] = (unsigned)((p2 % (garr[u2 & 7u] | 1u)) && (p1 ^ 0xa377d742u));
        }
        goto L0;
        l0 = (long)((unsigned long)l0 + (unsigned)((int)-(a0[u1 & 3u] / (0x7fffffffu | 1u)) < (int)(unsigned)c0));
        if ((unsigned)(u0 && (u0 + 0xac49330du))) {
            if ((unsigned)e0) goto L2;
            goto L2;
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (0x20c65ccfu + (unsigned)((unsigned)((int)i0 >= (int)p1) == (g0 & v0))));
                u2 ^= a0[u1 & 3u];
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)-(unsigned)(r0.y < v0) < (int)(unsigned)(unsigned char)(unsigned)(0x7fffffffu || 0x3cbe7238u));
                if ((unsigned)(short)(unsigned)((unsigned)e0 && 2u)) break;
                u2 = ((unsigned)s0 ^ (unsigned)(unsigned char)(((unsigned)b0 >> (4u & 31u)) - 3u));
                w0 ^= (unsigned long long)v0 << ((unsigned)((int)(unsigned)((int)u0 < (int)r0.x) >= (int)((0x7fffffffu & garr[u2 & 7u]) ^ (unsigned)c1)) & 63u);
            }
            garr[(9u << (p1 & 31u)) & 7u] = (0x62d43cdu / ((unsigned)((int)(unsigned)h1 >= (int)(p2 ? u2 : g0)) | 1u));
        } else {
            s0 = (int)(((unsigned)c0 % (p1 | 1u)) + i1);
            h1 = (unsigned short)(h1 + ((unsigned)h0 % ((unsigned)((int)(unsigned)c1 >= (int)(unsigned)((int)fuel >= (int)(unsigned)(w0 >> 29))) | 1u)));
            h1 = (unsigned short)(h1 + 0xeae848du);
            w0 = w0 * 6364136223846793005ull + (unsigned)((v0 ? 6u : 0x80000000u) && 0x80000000u);
        }
    }
    r0.y ^= (unsigned)((((unsigned)c1 ? u1 : (unsigned)(w0 >> 29)) ^ i2) && (unsigned)x0);
    u3 = ((unsigned)((short)((unsigned)d0 & (unsigned)s0) > (signed char)i2) << ((unsigned)!(*q0 * fuel) & 31u));
    r0.y ^= ((unsigned)s0 & *mp);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if (((unsigned)((short)a0[i0 & 3u] > (signed char)i2)) & 1u) { t0 = (unsigned)!(unsigned)(v0 == fuel); z0 = (double)(((unsigned)((short)(0x10000u - 9u) > (signed char)i1)) & 255u); } if (((unsigned)((short)a0[i0 & 3u] > (signed char)i2)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(garr[u2 & 7u] < r0.y)) {
                b0 = u3 != 0u;
                s1 = (int)((unsigned)s1 + ((unsigned)s1 - 0x51370f65u));
                if ((unsigned)(short)(unsigned)((unsigned)l0 == (unsigned)(u2 == 0x80000000u))) goto L3;
                w0 ^= (unsigned long long)(unsigned)((int)(unsigned)e0 < (int)(unsigned)f0) << (((3u | (4u << (0xc52344e0u & 31u))) << (u3 & 31u)) & 63u);
            }
            do { if (--fuel == 0u) goto done;
                v0 = (unsigned)(garr[u2 & 7u] && (v0 % ((unsigned)((int)(unsigned)(signed char)(unsigned)(garr[u2 & 7u] && p2) >= (int)0x425ff0e3u) | 1u)));
            } while (i1++ < 2u && (p2 * (unsigned)(g0 && 3u)));
        }
        w0 = w0 * 6364136223846793005ull + (0x10000u & (unsigned)f0);
    }
    while (i0++ < 7u && i2) { if (--fuel == 0u) goto done;
        if ((unsigned)(signed char)(0xb242413du % (0xffffffffu | 1u))) {
            while (i1++ < 5u && 0x80000000u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)!(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)8u) & 1023u);
                { unsigned t1; double z1; if (((-(unsigned)((int)fuel < (int)i1) & i2)) & 1u) { t1 = (p2 ? p0 : u0); z1 = (double)((~(r0.y & v0)) & 255u); } if (((-(unsigned)((int)fuel < (int)i1) & i2)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    *q0 += (unsigned)((int)(unsigned)f0 >= (int)i0);
                    if (i0) break;
                    { unsigned t2; double z2; if ((~(u0 | r0.x)) & 1u) { t2 = ((unsigned)c0 ^ (unsigned)(signed char)(g0 + *q0)); z2 = (double)(((unsigned)((0x7fffffffu & i1) || 0xffffffffu)) & 255u); } if ((~(u0 | r0.x)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                        h1 = (unsigned short)(h1 + (-((unsigned)h1 / (0x7fffffffu | 1u)) | i0));
                        *q0 += u2;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((9u + m0), (0x3fa72067u * ((unsigned)(x0 >> 70) << (0xffffffffu & 31u))), garr[u2 & 7u]); }
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(u1 && *q0), i2, (unsigned)w0); }
                    i0 = *q0 & 15u;
                }
                if ((unsigned)((int)(unsigned)s1 < (int)(unsigned)w0)) break;
            }
            switch ((unsigned)!(p2 | (unsigned)b0) & 7u) {
                u2 = u2 * 0x9e3779b1u + i2;
                f0 = f0 * 0.5f + (float)(u3 & 255u);
                case 1u: ;
            }
            { unsigned t3; double z3; if (((0x61cad807u % (i1 | 1u))) & 1u) { t3 = (unsigned)(short)((unsigned)((unsigned)b0 < 9u) << (a0[i0 & 3u] & 31u)); z3 = (double)(((i0 + u1)) & 255u); } if (((0x61cad807u % (i1 | 1u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                if (budget != 0u) { budget -= 1u; u3 = fn0((((unsigned)b0 >> (g0 & 31u)) / (0x58750bc0u | 1u)), (*q0 + (unsigned)c1), v0); }
                if ((unsigned)s0) break;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(0x4a8944deu < u1), r0.x, (3u / (a0[u1 & 3u] | 1u))); }
            while (i1++ < 7u && u3) { if (--fuel == 0u) goto done;
                h0 = (short)(unsigned)(r0.x < a0[i0 & 3u]);
                if (0x80000000u) goto done;
                goto L4;
                if ((u2 * (i1 & 0x7fffffffu))) goto L4;
                if (((unsigned)(signed char)((unsigned)h1 / (garr[i1 & 7u] | 1u)) % (0xffffffffu | 1u))) {
                    switch ((unsigned)((unsigned)((int)(unsigned)x0 >= (int)p1) < u3) & 7u) {
                        break; (void)(((unsigned)(w0 >> 29) - 0xffffffffu));
                        do { if (--fuel == 0u) goto done;
                            u3 += fuel;
                            if (((unsigned)d0 << (p0 & 31u))) break;
                            u3 += -(p1 << ((a0[i0 & 3u] ? 0xffffffffu : (unsigned)(x0 >> 70)) & 31u));
                        } while (i2++ < 7u && (unsigned)((int)r0.x >= (int)(unsigned)e0));
                        { unsigned t4; double z4; if ((garr[u2 & 7u]) & 1u) { t4 = (1u >> (-(u3 & (unsigned)s0) & 31u)); z4 = (double)((((fuel * r0.x) >> ((unsigned)h1 & 31u))) & 255u); } if ((garr[u2 & 7u]) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                            L0: if (--fuel == 0u) goto done;
                            d0 = d0 * 0.5 + (double)((unsigned)((short)g1 > (signed char)(unsigned)d0) & 1023u);
                            h1 = (unsigned short)(h1 + -(unsigned)((short)(unsigned)((int)garr[u2 & 7u] < (int)(unsigned)c1) > (signed char)garr[u2 & 7u]));
                            w0 ^= (unsigned long long)(6u & 0x7fffffffu) << ((unsigned)((short)0x65041a99u > (signed char)0xffffffffu) & 63u);
                            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)d0 | (0x7fffffffu >> (u1 & 31u))), (unsigned)h1, u2); }
                        }
                    }
                }
            }
        } else {
            *q0 = (*mp + 6u);
        }
        f0 = f0 * 0.5f + (float)((*mp ^ r0.x) & 255u);
        u3 += ((unsigned)s0 / (((unsigned)h0 + ((unsigned)f0 % ((unsigned)c0 | 1u))) | 1u));
        continue; (void)(a0[i0 & 3u]);
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(short)(unsigned)(r0.x < 0x3ab39b90u)) break;
        x0 = x0 * 0x100000001b3ull + (unsigned)((int)1u < (int)(p1 << ((0x19cee15u >> (p0 & 31u)) & 31u)));
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (((unsigned)w0 ^ fuel) ^ (unsigned)((int)g1 >= (int)v0));
            if (((unsigned)b0 | (6u << ((unsigned)c1 & 31u)))) break;
            while (i2++ < 7u && ((unsigned)((short)r0.y > (signed char)0xf47c4ab8u) * 0x80000000u)) { if (--fuel == 0u) goto done;
                if ((*q0 + 0x10000u)) {
                    { unsigned t5; double z5; if (((-((unsigned)c0 % (0u | 1u)) - garr[u2 & 7u])) & 1u) { t5 = (unsigned)(u1 || (unsigned)(fuel == 8u)); z5 = (double)(((unsigned)(u1 || (unsigned)s0)) & 255u); } if (((-((unsigned)c0 % (0u | 1u)) - garr[u2 & 7u])) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!(unsigned)((int)fuel < (int)p2), ((unsigned)d0 | (unsigned)!(unsigned)((unsigned)d0 || a0[i0 & 3u])), ((unsigned)x0 | (unsigned)x0)); }
                        if (0x1a509629u) break;
                        L1: if (--fuel == 0u) goto done;
                        *q0 += (unsigned)((int)(unsigned)!(0x431b1b0fu ? (unsigned)s1 : (unsigned)l0) >= (int)4u);
                        s1 = (int)((unsigned)s1 + ((unsigned)(w0 >> 29) % ((unsigned)(signed char)(fuel ? fuel : 9u) | 1u)));
                    }
                    if (p0) break;
                    v0 = (unsigned)((short)(unsigned)((unsigned)(x0 >> 70) && (m0 - (unsigned)b0)) > (signed char)a0[u1 & 3u]);
                    l0 = (long)((unsigned long)l0 + ~(a0[u1 & 3u] + (unsigned)((4u % ((unsigned)h0 | 1u)) == 0x6aaf9e64u)));
                }
                while (i0++ < 5u && (unsigned)(fuel < ((unsigned)c0 << (g0 & 31u)))) { if (--fuel == 0u) goto done;
                    if ((g0 % (((unsigned)w0 & 2u) | 1u))) goto L2;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!(i1 | i2), ((unsigned)h0 % ((0x10000u / ((unsigned)d0 | 1u)) | 1u)), (unsigned)(signed char)(unsigned)((int)(unsigned)s1 >= (int)(0xc461b8cbu | r0.y))); }
                    if ((a0[i0 & 3u] ? 0x84cf064cu : (unsigned)l0)) goto L2;
                    if (u3 == 7u) return (r0.y ^ ((r0.x - u3) - (unsigned)b0));
                    if ((unsigned)(x0 >> 70)) goto L4;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((u2 | (unsigned)((int)v0 < (int)garr[u2 & 7u])), 2u, 1u); }
            }
            if ((unsigned)(x0 >> 70)) break;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(0x1e09e229u, ((unsigned)h1 * *q0), (unsigned)(u2 || -(unsigned)((int)(unsigned)h0 < (int)g1))); }
    }
    if (u2) {
        if ((unsigned)(0u == ((unsigned)h0 & 0xf577982cu))) goto L4;
        switch ((unsigned)((unsigned)e0 || (unsigned)((int)i1 < (int)p2)) & 7u) {
            *q0 += ((unsigned)((int)p1 >= (int)(unsigned)c1) << (1u & 31u));
            while (i0++ < 7u && ((unsigned)s1 ? r0.y : g0)) { if (--fuel == 0u) goto done;
                if (a0[i0 & 3u]) {
                    if ((r0.x + ~(unsigned)((unsigned)x0 < (unsigned)d0))) continue;
                } else {
                    case 5u: ;
                    L2: if (--fuel == 0u) goto done;
                }
                l0 = (long)((unsigned long)l0 + 0x7fffffffu);
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)c1 < (int)(i2 | 0x6dece9adu));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)((short)*q0 > (signed char)garr[u2 & 7u]) && 0x7fffffffu), (unsigned)(m0 || 7u), ((unsigned)h0 - (unsigned)(0xce04f621u == m0))); }
        }
        if (1u) goto L3;
    } else {
        { unsigned t6; double z6; if (((unsigned)((int)0x80000000u >= (int)0x10000u)) & 1u) { t6 = 3u; z6 = (double)(((unsigned)((unsigned)s0 && p1)) & 255u); } if (((unsigned)((int)0x80000000u >= (int)0x10000u)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            w0 ^= (unsigned long long)((unsigned)(x0 >> 70) - (unsigned)s1) << ((unsigned)(0xe1ac8c9eu == ((unsigned)s1 ? 0x10000u : 0x8cd154fdu)) & 63u);
        }
        w0 ^= (unsigned long long)0xb468b664u << (((unsigned)(unsigned char)(unsigned)((short)(unsigned)(short)((unsigned)l0 - (unsigned)c1) > (signed char)i1) | (unsigned)e0) & 63u);
        m0 ^= (unsigned)((int)((unsigned)((int)(unsigned)b0 < (int)u3) ? 0x7fffffffu : garr[i1 & 7u]) < (int)0x21e44842u);
    }
    h1 = (unsigned short)(h1 + (unsigned)!(unsigned)((int)((unsigned)b0 + (m0 ? p0 : 9u)) >= (int)r0.y));
    if (u2) {
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!((unsigned)e0 ^ 0x852cdbcau), i1, u0); }
        switch (0u & 7u) {
            w0 = w0 * 6364136223846793005ull + (unsigned)w0;
        }
        if ((unsigned)((int)r0.x < (int)(0x5573c516u >> (0x70faa453u & 31u)))) goto done;
    }
    r0.x = (m0 % ((garr[u2 & 7u] % (5u | 1u)) | 1u));
    if ((unsigned)e0) goto L4;
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)5u), ((unsigned)x0 + ~(unsigned)((int)v0 < (int)(unsigned)s0)), u2); }
    u2 ^= (unsigned)((int)(unsigned)((a0[i0 & 3u] & u1) == (unsigned)(w0 >> 29)) >= (int)(fuel / (0x69b6bf64u | 1u)));
    if (i2) {
        garr[(unsigned)s1 & 7u] = (unsigned)(r0.x && ((p1 % (0x7fffffffu | 1u)) >> (u3 & 31u)));
        r0.x = i1;
        s0 = (int)((v0 & m0) - (u2 >> (8u & 31u)));
        switch ((unsigned)((int)7u >= (int)i1) & 7u) {
            if ((unsigned)(m0 && (unsigned)((unsigned)(x0 >> 70) < (unsigned)w0))) goto L4;
        }
    } else {
        u2 = (fuel ? (i0 << (0xc22dbc0fu & 31u)) : 2u);
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(unsigned)(1u < (unsigned)(0x9097744cu || i2)), 0x5c77317cu, p1); }
        goto L1;
    }
    q0 = &garr[(unsigned)((r0.y + (unsigned)(short)(unsigned)(a0[i0 & 3u] && u1)) == (unsigned)((unsigned)c0 || u1)) & 7u];
    b0 = (unsigned)(((unsigned)((int)*mp < (int)i2) | r0.x) && (unsigned)c0) != 0u;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= (unsigned)(short)((7u - (unsigned)((garr[i1 & 7u] ^ (unsigned)h0) || m0)) * 0x10000u);
        do { if (--fuel == 0u) goto done;
            g0 = ((unsigned)(0xffffffffu == 0x8594a2c1u) % ((unsigned)c0 | 1u));
            a0[8u & 3u] = a0[i0 & 3u];
            if ((unsigned)(unsigned char)(unsigned)(0xffffffffu == m0)) break;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(unsigned)w0 > (signed char)0xffffffffu), (unsigned)((unsigned)d0 || (unsigned)(0x7fffffffu && u3)), 0x3ec263f8u); }
        } while (i1++ < 4u && 1u);
        goto L4;
    }
    g0 = ((~(1u * 0xb2830e70u) & (unsigned)(0x80000000u < u0)) >> ((unsigned)s0 & 31u));
    { unsigned t7; double z7; if ((((unsigned)s0 << (*mp & 31u))) & 1u) { t7 = (unsigned)x0; z7 = (double)(((unsigned)(signed char)((unsigned)h1 ^ (unsigned)l0)) & 255u); } if ((((unsigned)s0 << (*mp & 31u))) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
        if ((unsigned)((unsigned)(8u && a0[u1 & 3u]) < m0)) {
            if (budget != 0u) { budget -= 1u; u1 = fn0(((g1 - *mp) & 8u), 9u, (unsigned)e0); }
        } else {
            if (budget != 0u) { budget -= 1u; u2 = fn0(-((unsigned)l0 | a0[u1 & 3u]), (unsigned)(0x7fffffffu && fuel), (unsigned)(0xffffffffu < p0)); }
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(i1, (*q0 * (unsigned)f0), (unsigned)(signed char)(unsigned)((unsigned)((short)5u > (signed char)9u) < i0)); }
                L3: if (--fuel == 0u) goto done;
            }
            do { if (--fuel == 0u) goto done;
                *mp = (unsigned)!(unsigned)(5u == 0x7fffffffu);
                if (((unsigned)(signed char)(g0 / (p2 | 1u)) ^ p0)) {
                    if ((unsigned)l0) break;
                    r0.y ^= (unsigned)x0;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0x22482115u % (v0 | 1u)), (9u | 0x6f910062u), ~(unsigned)((garr[u2 & 7u] ^ p0) || a0[i0 & 3u])); }
                    v0 = ((unsigned)h0 / ((3u - (r0.x - 0x5cddbedeu)) | 1u));
                } else {
                    if ((~(0xffffffffu * i0) + a0[i0 & 3u])) break;
                    if (garr[i1 & 7u]) break;
                }
            } while (i0++ < 2u && ((unsigned)((short)garr[u2 & 7u] > (signed char)p0) / ((unsigned)h1 | 1u)));
            q0 = &garr[((0x2921d892u % (0x10000u | 1u)) % ((unsigned)f0 | 1u)) & 7u];
        }
        L4: if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (0xffffffffu | (unsigned)f0);
        a0[v0 & 3u] = ((unsigned)e0 - garr[u2 & 7u]);
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)b0 >> ((unsigned)h1 & 31u)), 0xc4516ba3u, (g1 + 0x7fffffffu)); }
    if (budget != 0u) { budget -= 1u; u3 = fn0((8u + (unsigned)w0), ((unsigned)(x0 >> 70) % ((p0 | (unsigned)(w0 >> 29)) | 1u)), (unsigned)b0); }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = ((u2 ? (unsigned)f0 : garr[i1 & 7u]) % (garr[u2 & 7u] | 1u));
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            g1 += ((unsigned)f0 / ((garr[u2 & 7u] ? (unsigned)(x0 >> 70) : i1) | 1u));
            x0 = x0 * 0x100000001b3ull + (unsigned)((int)((unsigned)h0 % (6u | 1u)) >= (int)i2);
            if (budget != 0u) { budget -= 1u; u2 = fn0((fuel * u3), garr[u2 & 7u], ((m0 % (0x9ab89477u | 1u)) << (a0[i0 & 3u] & 31u))); }
            *q0 += (unsigned)((short)(unsigned)(a0[i0 & 3u] < (unsigned)c0) > (signed char)(unsigned)!((unsigned)c0 % (0x50799dadu | 1u)));
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)s0 - (p2 * u2)), (unsigned)((unsigned)w0 || a0[u1 & 3u]), ((g1 % ((unsigned)d0 | 1u)) / ((unsigned)l0 | 1u))); }
            if ((g0 * (i0 % ((unsigned)(x0 >> 70) | 1u)))) {
                if (8u) break;
                if ((unsigned)w0) goto L0;
                if (i2) goto L0;
            }
        }
        l0 = (long)((unsigned long)l0 + ((unsigned)!(a0[u1 & 3u] ^ 0xb82f3db5u) & (unsigned)e0));
        while (i1++ < 3u && 0x7fffffffu) { if (--fuel == 0u) goto done;
            if (fuel < 8u) return (1u >> ((unsigned)((0x80000000u << ((unsigned)c1 & 31u)) && (unsigned)s1) & 31u));
        }
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((short)fuel > (signed char)u2)) break;
        if (i0) break;
        c0 = (unsigned char)(((unsigned)s1 | (unsigned)(garr[i1 & 7u] && 0xc9d45993u)) % ((i0 << (a0[i0 & 3u] & 31u)) | 1u));
        if ((0xe2b81aadu | v0)) {
            while (i1++ < 2u && (unsigned)(0x1eb6a0b4u < 0x7fffffffu)) { if (--fuel == 0u) goto done;
                if (~(a0[i0 & 3u] ^ 0x10000u)) goto L1;
                continue; (void)((unsigned)((int)*mp < (int)(unsigned)w0));
                m0 ^= p2;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(p1 && 6u)) {
                        u1 = u1 * 0x9e3779b1u + v0;
                        s1 = (int)((unsigned)s1 + (unsigned)(fuel < (unsigned)h1));
                        if (0x2553e96bu) break;
                        h1 = (unsigned short)(h1 + -(unsigned)(0xf73b0e1cu && ((unsigned)((unsigned)e0 && g1) | 0x9a40c462u)));
                    }
                    if (fuel < 8u) return (unsigned)((unsigned)(0x9e27da2eu && (5u ^ garr[i1 & 7u])) < (unsigned)(w0 >> 29));
                    *q0 = ((unsigned)(signed char)(unsigned)(u0 == ((0x80000000u / (u0 | 1u)) << (i2 & 31u))) >> (3u & 31u));
                    h1 = (unsigned short)(h1 + (u0 >> (5u & 31u)));
                }
                break; (void)(i1);
                while (i2++ < 6u && ~(u3 >> (4u & 31u))) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)(g1 & 1023u);
                    if (((unsigned)(unsigned char)(unsigned)(garr[i1 & 7u] < m0) ^ p2)) break;
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)((a0[u1 & 3u] - (unsigned)s1));
                    }
                    garr[8u & 7u] = (unsigned)((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)h0) == (unsigned)((int)i1 < (int)u2));
                }
            }
        } else {
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)(w0 >> 29) == 0x30bbc04eu), (unsigned)s0, (0x204737bdu * 6u)); }
            if ((unsigned)((unsigned)((unsigned)f0 == m0) < 0x10000u)) break;
            if (p1) break;
            if ((p0 << ((unsigned)h0 & 31u))) break;
        }
        if ((unsigned)(unsigned char)((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)c0) | v0)) {
            *mp = (unsigned)((int)(unsigned)(a0[i0 & 3u] == 1u) >= (int)a0[i0 & 3u]);
            switch ((unsigned)((short)u3 > (signed char)(unsigned)!(5u << (g0 & 31u))) & 7u) {
                if ((((unsigned)h1 % (7u | 1u)) + 0u)) {
                    c1 = (signed char)-(unsigned)((short)5u > (signed char)((unsigned)h1 & (0xe22b4d75u / (7u | 1u))));
                    case 3u: ;
                } else {
                    if ((p1 + (unsigned)((int)u3 < (int)i0))) continue;
                }
                garr[2u & 7u] = (u2 + (garr[u2 & 7u] / (u2 | 1u)));
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(unsigned)(0x10000u == (unsigned)((int)(unsigned)(p0 < i2) >= (int)(v0 | p2)));
                    *q0 = (unsigned)((int)0xffffffffu < (int)(0x80000000u << ((unsigned)l0 & 31u)));
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0(-(unsigned)(u1 && i1), (unsigned)((unsigned)h1 || (unsigned)(x0 >> 70)), (unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)c1 < (unsigned)(x0 >> 70)) && *q0)); }
            }
            if ((unsigned)((int)(unsigned)h1 >= (int)v0)) goto L4;
            h1 = (unsigned short)(h1 + (unsigned)((unsigned)e0 == 2u));
            w0 = w0 * 6364136223846793005ull + v0;
        }
        l0 = (long)((unsigned long)l0 + -(0x80000000u ? m0 : garr[u2 & 7u]));
    } while (i0++ < 5u && (unsigned)((int)(unsigned)(signed char)((unsigned)l0 << (i2 & 31u)) < (int)v0));
    if (budget != 0u) { budget -= 1u; u3 = fn0(u3, m0, (9u | (unsigned)(v0 && 0x97959730u))); }
    *q0 = ((-(unsigned)((short)(unsigned)l0 > (signed char)garr[u2 & 7u]) & (unsigned)((int)(unsigned)h1 < (int)garr[i1 & 7u])) ^ i0);
    r0.x = (((unsigned)(x0 >> 70) | 0x10000u) << ((unsigned)((int)2u < (int)0x7fffffffu) & 31u));
    if (4u) goto done;
    h1 = (unsigned short)(h1 + ((unsigned)s1 ? (unsigned)e0 : (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)(x0 >> 70))));
    *q0 = ((p0 ^ (unsigned)c0) + *mp);
    if (p0) goto L3;
    while (((u2 + 2u) & (unsigned)h0)) { if (--fuel == 0u) goto done;
        if (u3 == 7u) return ((9u / (0xffffffffu | 1u)) ^ garr[i1 & 7u]);
        *q0 = -(unsigned)(garr[i1 & 7u] || ((u0 % ((unsigned)b0 | 1u)) % ((unsigned)(0u && 8u) | 1u)));
        if (((unsigned)f0 >> ((3u * (unsigned)w0) & 31u))) break;
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)h1 | 0u), i2, ((unsigned)(m0 && 0x10000u) ^ (unsigned)s1)); }
        if (((unsigned)f0 | v0)) {
            if (g0) {
                if ((0xa87726e1u * garr[i1 & 7u])) goto L0;
                u1 ^= 0x80000000u;
            }
        }
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(v0);
        m0 ^= ((unsigned)(short)(p0 ? 5u : 5u) + (unsigned)x0);
        r0.y ^= p1;
        if (((unsigned)(short)(*mp + i1) | g0)) break;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (-(0x7fffffffu % ((unsigned)w0 | 1u)) & (unsigned)((short)0x2d6df55bu > (signed char)(unsigned)(x0 >> 70)));
            if (m0) break;
            u2 = (unsigned)(0x6d2908e0u && (unsigned)((short)garr[i1 & 7u] > (signed char)fuel));
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!((unsigned)((short)(unsigned)c0 > (signed char)u2) ^ 0x5e94287du), (unsigned)(signed char)(0x7fffffffu - (unsigned)(p0 == 0xffffffffu)), ((unsigned)x0 - 2u)); }
    while (i0++ < 5u && (unsigned)((int)i2 >= (int)(r0.x | *q0))) { if (--fuel == 0u) goto done;
        { unsigned t8; double z8; if ((~((unsigned)(short)(0x178cfa47u & 0x780af9feu) | 0xe5303224u)) & 1u) { t8 = ((unsigned)l0 << ((unsigned)(x0 >> 70) & 31u)); z8 = (double)((5u) & 255u); } if ((~((unsigned)(short)(0x178cfa47u & 0x780af9feu) | 0xe5303224u)) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
            g0 = (u3 % (((unsigned)s1 ? 9u : 0x7fffffffu) | 1u));
            if ((3u & (unsigned)!(i0 % (0xa82bc5b6u | 1u)))) goto L2;
            if (budget != 0u) { budget -= 1u; u0 = fn0(0x7e1d6233u, (unsigned)(signed char)((unsigned)(x0 >> 70) * ((unsigned)(w0 >> 29) & (unsigned)w0)), (unsigned)(signed char)(*q0 & 0xa0b61c5eu)); }
            if ((unsigned)x0) break;
        }
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (a0[i0 & 3u]) goto done;
        }
        if (((unsigned)((int)(unsigned)e0 < (int)0x10000u) / ((unsigned)d0 | 1u))) continue;
        if ((unsigned)(g0 == 0x10000u)) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)w0, (2u | g0), (unsigned)(signed char)(i2 >> ((0x7fffffffu - i2) & 31u))); }
            h0 = (short)((unsigned)s0 >> (m0 & 31u));
            if (budget != 0u) { budget -= 1u; u0 = fn0(i2, (unsigned)((short)p1 > (signed char)(unsigned)(short)(unsigned)((unsigned)(w0 >> 29) && u0)), ~(2u >> ((unsigned)((short)0x2ba15fdfu > (signed char)u1) & 31u))); }
        }
        u2 ^= ((unsigned)x0 - (0xffffffffu >> (u3 & 31u)));
    }
    goto L4;
    garr[0xbc2d3f4du & 7u] = p1;
    { unsigned t9; double z9; if (((unsigned)((unsigned)w0 || (unsigned)x0)) & 1u) { t9 = 0x4db2410u; z9 = (double)((~((unsigned)(u1 < i0) % (i0 | 1u))) & 255u); } if (((unsigned)((unsigned)w0 || (unsigned)x0)) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
        u1 = u1 * 0x9e3779b1u + (u0 * (unsigned)((unsigned)(0u && (unsigned)e0) && 4u));
        if ((u2 / (0x908e1970u | 1u))) goto L1;
    }
    { unsigned t10; double z10; if ((u3) & 1u) { t10 = r0.x; z10 = (double)((((unsigned)s0 * u3)) & 255u); } if ((u3) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
        { unsigned t11; double z11; if (((0x439beb0au / (0xabb1edc2u | 1u))) & 1u) { t11 = 0xcc3d2b78u; z11 = (double)((((unsigned)c0 * (unsigned)(unsigned char)(0xdbcc83d5u << (m0 & 31u)))) & 255u); } if (((0x439beb0au / (0xabb1edc2u | 1u))) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
            if (budget != 0u) { budget -= 1u; u3 = fn0(g0, (unsigned)(garr[u2 & 7u] < (6u / (0x731110a4u | 1u))), (unsigned)((short)(unsigned)(signed char)(p1 >> (r0.x & 31u)) > (signed char)u2)); }
            u3 = u3 * 0x9e3779b1u + (((unsigned)((unsigned)(w0 >> 29) && p0) % ((0x15db8cc1u % (u3 | 1u)) | 1u)) << (p1 & 31u));
            if ((unsigned)((int)garr[i1 & 7u] < (int)(unsigned)w0)) goto L4;
            while ((0x1eb7fd7eu + (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
                if (0xffffffffu) continue;
                g0 = (unsigned)e0;
                if ((unsigned)(short)(unsigned)(0x7e4bb0e9u == (unsigned)((short)m0 > (signed char)r0.y))) break;
                w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(g0 & 0xd70905bfu);
                break; (void)(4u);
            }
        }
        for (;;) { if (--fuel == 0u) goto done;
            if ((u3 ^ 0x51da1540u)) break;
        }
        if (a0[i0 & 3u]) goto done;
        b0 = (unsigned)(unsigned char)((unsigned)c1 | (unsigned)(w0 >> 29)) != 0u;
        { unsigned t12; double z12; if (((unsigned)((2u * (unsigned)f0) && m0)) & 1u) { t12 = ((u0 + 0u) / ((unsigned)c0 | 1u)); z12 = (double)((7u) & 255u); } if (((unsigned)((2u * (unsigned)f0) && m0)) & 1u) { u0 += t12; d0 = d0 * 0.5 + z12; }
            while (i0++ < 2u && (unsigned)((unsigned)(unsigned char)(u1 << ((unsigned)(x0 >> 70) & 31u)) == v0)) { if (--fuel == 0u) goto done;
                if (((0xc93b9c1cu % (0xaeb9f0e6u | 1u)) & (unsigned)h0)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0(~(unsigned)((int)(unsigned)x0 >= (int)m0), ((unsigned)b0 - p2), ~(m0 ^ p2)); }
                if (u3 == 7u) return (unsigned)((int)((unsigned)s1 * u1) < (int)(p2 / (~(unsigned)(0x3077e184u == garr[i1 & 7u]) | 1u)));
                if ((0x8c5f9831u ^ 2u)) {
                    l0 = (long)((unsigned long)l0 + ((unsigned)d0 + (g0 - (unsigned)h1)));
                }
            }
            *q0 = (unsigned)(unsigned char)((unsigned)(unsigned char)((unsigned)(i2 || (unsigned)s1) / (g0 | 1u)) * (unsigned)x0);
            if ((unsigned)((int)(unsigned)((short)i2 > (signed char)garr[u2 & 7u]) >= (int)(unsigned)c0)) goto L3;
        }
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (0x7fffffffu % ((unsigned)s1 | 1u));
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((4u * 0x746e019u));
            u2 = u2 * 0x9e3779b1u + ~(unsigned)((int)0u >= (int)(unsigned)e0);
        }
        if ((unsigned)c0) {
            i1 = (a0[u1 & 3u] & (unsigned)(x0 >> 70)) & 15u;
            { unsigned t13; double z13; if (((0x7fffffffu | (unsigned)f0)) & 1u) { t13 = (unsigned)(signed char)(unsigned)((int)(*mp % (u2 | 1u)) < (int)(unsigned)w0); z13 = (double)(((unsigned)s1) & 255u); } if (((0x7fffffffu | (unsigned)f0)) & 1u) { u0 += t13; d0 = d0 * 0.5 + z13; }
                s0 = (int)p0;
                switch (0xffffffffu & 7u) {
                    case 3u: ;
                    case 0u: ;
                    u1 = u1 * 0x9e3779b1u + ((unsigned)f0 >> (0xc31421f7u & 31u));
                    w0 ^= (unsigned long long)a0[i0 & 3u] << (~(u1 & ~(unsigned)((int)(3u ? p1 : 3u) < (int)(unsigned)h0)) & 63u);
                }
                b0 = (i1 * (unsigned)(*q0 == 0x7fffffffu)) != 0u;
                s0 = (int)*q0;
            }
        }
        do { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (((unsigned)(short)((unsigned)(x0 >> 70) ^ 0x9aeff792u) << (i1 & 31u)) | (unsigned)(signed char)(r0.y + 0x7fffffffu)));
        } while (i1++ < 5u && (unsigned)(signed char)(0x10000u << ((unsigned)((int)g1 >= (int)7u) & 31u)));
        { unsigned t14; double z14; if ((((unsigned)e0 | (*q0 * 0x10000u))) & 1u) { t14 = (r0.y | (unsigned)(short)(u2 | fuel)); z14 = (double)(((unsigned)(p2 && (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)i0))) & 255u); } if ((((unsigned)e0 | (*q0 * 0x10000u))) & 1u) { u0 += t14; d0 = d0 * 0.5 + z14; }
            u0 = u0 * 0x9e3779b1u + (fuel + r0.x);
            g0 = (-(i0 >> (2u & 31u)) - (unsigned)(signed char)(v0 * (0x76738b66u >> (a0[i0 & 3u] & 31u))));
        }
    }
    b0 = -(7u << ((unsigned)!(v0 - (unsigned)((short)(garr[u2 & 7u] << (0xafbf36f0u & 31u)) > (signed char)garr[u2 & 7u])) & 31u)) != 0u;
    v0 = (unsigned)(signed char)((unsigned)h0 >> (p2 & 31u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    while (i0++ < 4u && (p2 + (unsigned)(unsigned char)(a0[u1 & 3u] + (unsigned)h1))) { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (p2 * 4u);
        x0 = x0 * 0x100000001b3ull + ((0x7fffffffu + (unsigned)((unsigned)x0 && (unsigned)e0)) << ((unsigned)(unsigned char)((unsigned)c1 * (unsigned)s0) & 31u));
        goto L4;
        if (((i2 >> (0x10000u & 31u)) ^ u2)) break;
        *mp = ((unsigned)c0 - r0.x);
    }
    w0 ^= (unsigned long long)(unsigned)c0 << ((unsigned)((unsigned)(short)(0x6525ac07u * r0.x) == (unsigned)(w0 >> 29)) & 63u);
    g1 += (fuel * 0xffffffffu);
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((short)0x7fffffffu > (signed char)0xbb021716u), 9u, (unsigned)((int)(unsigned)e0 < (int)(unsigned)(0xffffffffu == p0))); }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((int)fuel >= (int)(unsigned)((int)0x80000000u >= (int)r0.x))) {
            b0 = (0xffffffffu & (unsigned)(((i2 | u2) ^ *mp) < p0)) != 0u;
            w0 = w0 * 6364136223846793005ull + (0x89e8d357u >> ((9u | (unsigned)!(garr[i1 & 7u] - (unsigned)s1)) & 31u));
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (0xffffffffu >> ((0x624b930cu ^ (8u - 0x1564610du)) & 31u));
                f0 = f0 * 0.5f + (float)(((unsigned)e0 & (unsigned)((int)(unsigned)h0 < (int)fuel)) & 255u);
                if (budget != 0u) { budget -= 1u; u2 = fn1((u0 * 9u), ((unsigned)d0 ? (unsigned)w0 : 9u), (unsigned)(u3 < (unsigned)f0)); }
                a0[(u0 + m0) & 3u] = (0x80000000u ? 0x8dced0a9u : (unsigned)x0);
            }
            break; (void)((unsigned)(0x10000u || (unsigned)c1));
        }
        g1 += (unsigned)(signed char)((unsigned)(short)((unsigned)c1 - v0) & 0x10000u);
    } while (i0++ < 3u && ((unsigned)w0 | fuel));
    if ((unsigned)(short)(m0 << ((unsigned)(p1 == (unsigned)s1) & 31u))) goto done;
    switch ((unsigned)(0x61646801u && i2) & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)(u3 >> (0xffffffffu & 31u)) > (signed char)(unsigned)d0), (unsigned)c1, (unsigned)((int)0x8b9e93b1u >= (int)9u)); }
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)b0 & 7u) {
            u3 += (p0 * *q0);
            if ((unsigned)((int)u1 < (int)(unsigned)s1)) goto L0;
            if (budget != 0u) { budget -= 1u; u3 = fn1(-(0xffffffffu % (u3 | 1u)), (unsigned)(u2 || (*q0 / (r0.x | 1u))), (unsigned)((int)(*mp << (0x7fffffffu & 31u)) < (int)(unsigned)b0)); }
            if ((5u * u0)) break;
        }
        *mp = (unsigned)((int)(unsigned)((short)(0xa0285098u ^ (unsigned)e0) > (signed char)(i1 / ((unsigned)h1 | 1u))) >= (int)0x80000000u);
    }
    goto L3;
    l0 = (long)((unsigned long)l0 + ((unsigned)s1 * v0));
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)c1 == 6u)) break;
        d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)((unsigned)h1 < (unsigned)x0) > (signed char)((0x801045f9u & 0x7fffffffu) % ((unsigned)(w0 >> 29) | 1u))) & 1023u);
        a0[(v0 - g0) & 3u] = (a0[i0 & 3u] + (unsigned)((int)fuel >= (int)garr[i1 & 7u]));
        h0 = (short)(unsigned)(((unsigned)((short)(unsigned)w0 > (signed char)0x10000u) ^ (0xffffffffu & 0xefe7a52u)) && (unsigned)w0);
        u3 = (unsigned)((i1 - u1) || ((u2 - r0.x) * 0xffffffffu));
    }
    d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)h1 + (unsigned)h0) && (unsigned)d0) & 1023u);
    goto L4;
    L1: if (--fuel == 0u) goto done;
    L2: if (--fuel == 0u) goto done;
    if ((unsigned)((short)0x856f701bu > (signed char)(unsigned)s1)) goto done;
    goto L2;
    L3: if (--fuel == 0u) goto done;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)(fuel && (fuel ? 0x67389d43u : ((unsigned)w0 ^ 1u))));
        switch (i1 & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)(5u >> ((unsigned)f0 & 31u)), (p0 << ((unsigned)x0 & 31u)), (unsigned)((int)(unsigned)h0 < (int)i2)); }
            { unsigned t0; double z0; if (((unsigned)!(3u >> ((unsigned)(0xffffffffu < 0x80000000u) & 31u))) & 1u) { t0 = i2; z0 = (double)((((p1 ^ 0xffffffffu) >> ((unsigned)h1 & 31u))) & 255u); } if (((unsigned)!(3u >> ((unsigned)(0xffffffffu < 0x80000000u) & 31u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                if ((unsigned)(short)(unsigned)(m0 == 0x7fffffffu)) goto L0;
                s1 = (int)((unsigned)s1 + (unsigned)((int)m0 < (int)(unsigned)!(unsigned)(u3 == (unsigned)(6u || 0xbf1a75dbu))));
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)g1 >= (int)p1)) {
                        break; (void)((0x2b8e15aeu << (p2 & 31u)));
                        for (;;) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn0(i0, 0x10000u, (unsigned)((int)4u < (int)u3)); }
                            q0 = &garr[g0 & 7u];
                            m0 ^= (unsigned)((unsigned)((0x10000u + u2) < (unsigned)s0) || ~(garr[i1 & 7u] - r0.x));
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(u2 && (unsigned)(w0 >> 29)), (unsigned)((int)0x10000u >= (int)g1), (unsigned)((unsigned)(u1 < (unsigned)h1) == (unsigned)w0)); }
                        d0 = d0 * 0.5 + (double)((unsigned)f0 & 1023u);
                        L4: if (--fuel == 0u) goto done;
                        h0 = (short)(((unsigned)((unsigned)w0 == (unsigned)d0) + (unsigned)((unsigned)c0 < m0)) ^ (unsigned)s0);
                    } else {
                        s0 = (int)(unsigned)(garr[i1 & 7u] || (a0[i0 & 3u] * (unsigned)e0));
                        if (garr[i1 & 7u]) break;
                        if ((*q0 << (0x4a9b2068u & 31u))) continue;
                        d0 = d0 * 0.5 + (double)((0x10000u >> (r0.x & 31u)) & 1023u);
                    }
                    case 2u: ;
                    v0 = ((unsigned)((int)(unsigned)s1 >= (int)(unsigned)l0) + ((6u * g1) % (1u | 1u)));
                    while (i2++ < 2u && (unsigned)((short)5u > (signed char)(unsigned)x0)) { if (--fuel == 0u) goto done;
                        if (((unsigned)h1 ? 0x7fffffffu : (unsigned)s1)) continue;
                        r0.y ^= ((u3 + (unsigned)f0) % ((unsigned)d0 | 1u));
                        *mp = (unsigned)((unsigned)h1 && (*q0 | (unsigned)((int)6u >= (int)0x10000u)));
                    }
                } while (i1++ < 4u && (unsigned)((short)(unsigned)x0 > (signed char)0x69b12c25u));
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0xffffffffu && 8u), (unsigned)(0xa12683e8u && (unsigned)l0), (2u | (unsigned)d0)); }
        do { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                a0[(unsigned)c0 & 3u] = u3;
                x0 = x0 * 0x100000001b3ull + ((unsigned)(2u == 0x95a3a1c0u) | ((unsigned)(w0 >> 29) << (0x10000u & 31u)));
                g1 += *mp;
                switch ((u2 << ((unsigned)!(0x5057239fu + u0) & 31u)) & 7u) {
                    continue; (void)(~(fuel & a0[u1 & 3u]));
                    a0[*mp & 3u] = (unsigned)((short)(unsigned)c1 > (signed char)(i1 * (i1 << ((unsigned)(p0 == u3) & 31u))));
                    c1 = (signed char)((unsigned)w0 / ((r0.x * a0[i0 & 3u]) | 1u));
                }
                if (u3 == 7u) return (unsigned)((unsigned)d0 || u3);
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)b0 < (unsigned)d0), (i2 & a0[u1 & 3u]), (unsigned)d0); }
            }
            switch (~((0x80000000u + *q0) * garr[i1 & 7u]) & 7u) {
                u3 += (fuel ^ (p2 >> ((unsigned)(i1 && (unsigned)c0) & 31u)));
                u3 = u3 * 0x9e3779b1u + p1;
            }
        } while (i1++ < 7u && (unsigned)b0);
        c1 = (signed char)((g0 & (unsigned)(w0 >> 29)) - (unsigned)(0xffffffffu || 0x906bb4a2u));
        if (~(i2 - (unsigned)!(3u % (2u | 1u)))) break;
    }
    if (2u) goto L1;
    if ((unsigned)((int)(unsigned)l0 < (int)i2)) goto done;
    if ((unsigned)((int)0x3544e619u < (int)r0.y)) {
        do { if (--fuel == 0u) goto done;
            continue; (void)((unsigned)((unsigned)c1 == (unsigned)c0));
            if ((unsigned)(g0 == r0.y)) {
                v0 = (unsigned)e0;
                if (budget != 0u) { budget -= 1u; u3 = fn0(0x7fffffffu, (unsigned)(i2 || (unsigned)(0x80000000u || 0x7fffffffu)), g0); }
            }
            s0 = (int)(r0.y * ((unsigned)f0 % ((unsigned)c0 | 1u)));
            w0 ^= (unsigned long long)(unsigned)(w0 >> 29) << ((unsigned)((0x10000u | g0) || ((unsigned)x0 % (*mp | 1u))) & 63u);
        } while (i0++ < 2u && (unsigned)w0);
        e0 = e0 * 0.5L + (long double)((unsigned)(i0 && (unsigned)((short)(unsigned)((int)u2 < (int)fuel) > (signed char)(unsigned)f0)) & 1023u);
        if ((unsigned)((unsigned)((int)(unsigned)s0 < (int)i1) || u2)) goto L1;
        if (garr[i1 & 7u]) {
            s1 = (int)((unsigned)s1 + (((unsigned)s0 / (0x80000000u | 1u)) >> (((unsigned)(x0 >> 70) << ((unsigned)(w0 >> 29) & 31u)) & 31u)));
            goto L1;
            d0 = d0 * 0.5 + (double)((garr[i1 & 7u] + 0xffffffffu) & 1023u);
            if (((*q0 + g0) % (0x10000u | 1u))) goto L2;
            do { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    q0 = &garr[(~(unsigned)((unsigned)s0 < p1) + *mp) & 7u];
                } while (i1++ < 5u && (unsigned)((int)(unsigned)(0x10000u || r0.x) < (int)0x77a35a0fu));
                if (((unsigned)((short)u2 > (signed char)0xffffffffu) >> (g0 & 31u))) break;
                garr[g1 & 7u] = 0xe8702137u;
                g0 = (unsigned)((int)((4u ^ 0xdc4e2feau) & (unsigned)l0) >= (int)p1);
                h1 = (unsigned short)(h1 + (unsigned)((short)((0xd27eefd3u & (unsigned)f0) | (unsigned)s0) > (signed char)(unsigned)(short)(0x7fb9663bu >> (8u & 31u))));
            } while (i0++ < 3u && (unsigned)c0);
            if (i0) {
                a0[g0 & 3u] = (unsigned)(3u < (unsigned)(signed char)(fuel % ((m0 ^ (unsigned)h1) | 1u)));
                if (0x51158c7au) {
                    v0 = ((unsigned)((int)(unsigned)l0 >= (int)u1) / (~(unsigned)((int)0x10000u < (int)u3) | 1u));
                    h1 = (unsigned short)(h1 + (unsigned)(0x73a4514au < r0.y));
                    garr[(unsigned)((unsigned)e0 && p2) & 7u] = (unsigned)((short)0x7fffffffu > (signed char)(unsigned)(signed char)(unsigned)((int)((unsigned)h0 | a0[u1 & 3u]) >= (int)(unsigned)b0));
                    *q0 = *mp;
                    *q0 += (0x61724044u + (unsigned)(((unsigned)f0 ^ (unsigned)(5u == u1)) < u1));
                }
                *q0 = (5u + m0);
                d0 = d0 * 0.5 + (double)((u2 - i1) & 1023u);
                g1 += 0xffffffffu;
            }
        } else {
            c1 = (signed char)(unsigned)(u3 && 0xd6138b21u);
            while (i0++ < 7u && (0x12c8bf38u % (garr[i1 & 7u] | 1u))) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    if (((unsigned)(signed char)(a0[u1 & 3u] << (m0 & 31u)) ^ g0)) break;
                    if (0x7fffffffu) goto L4;
                    if ((unsigned)((int)*mp < (int)(unsigned)h1)) continue;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0x58496324u % ((unsigned)e0 | 1u)), (unsigned)((int)p1 >= (int)(unsigned)(w0 >> 29)), ((unsigned)l0 % ((unsigned)c1 | 1u))); }
                }
                if (r0.y) break;
                q0 = &garr[i2 & 7u];
                if (budget != 0u) { budget -= 1u; u3 = fn1(r0.y, (fuel ? g1 : 0x7fffffffu), (garr[i1 & 7u] >> (u1 & 31u))); }
            }
            b0 = (unsigned)((int)v0 < (int)(*q0 + *mp)) != 0u;
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn1(garr[u2 & 7u], ((r0.y + u0) ^ u2), (unsigned)(0xffffffffu || (unsigned)((unsigned)f0 < fuel))); }
    if (((unsigned)(7u == a0[u1 & 3u]) ^ (unsigned)x0)) goto L0;
    { unsigned t1; double z1; if (((unsigned)s0) & 1u) { t1 = (0x80000000u / (r0.y | 1u)); z1 = (double)(((unsigned)((int)p2 < (int)(unsigned)(unsigned char)(unsigned)(u3 == 0x10000u))) & 255u); } if (((unsigned)s0) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        while (i0++ < 4u && 0x7fffffffu) { if (--fuel == 0u) goto done;
            if ((0x80000000u - (0xe9e260d8u / (0x7fffffffu | 1u)))) {
                d0 = d0 * 0.5 + (double)((6u / (*mp | 1u)) & 1023u);
                if ((0x10000u * 0x10000u)) break;
            }
            w0 ^= (unsigned long long)(unsigned)(*q0 || r0.x) << (((((unsigned)(w0 >> 29) * p0) ^ (unsigned)((unsigned)b0 && 0x7fffffffu)) << (6u & 31u)) & 63u);
            if ((unsigned)(unsigned char)(unsigned)(5u < (i2 % (garr[i1 & 7u] | 1u)))) break;
            c1 = (signed char)((unsigned)(0x2023f26u && 0x84ff69a1u) * ((unsigned)(0x80000000u == 0x80000000u) << ((unsigned)c1 & 31u)));
            if (u3 == 7u) return (unsigned)e0;
        }
        garr[0x80000000u & 7u] = ((unsigned)((unsigned)((int)p1 < (int)*mp) && u3) + (unsigned)((short)u0 > (signed char)i2));
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(unsigned char)(unsigned)(0xfb9b7887u && (unsigned)(0x82e32579u || (unsigned)f0)), 6u, 0xba4e556cu); }
    c1 = (signed char)(unsigned)(w0 >> 29);
    l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(0x4fdd7856u ^ (unsigned)((int)0xffffffffu >= (int)r0.y)));
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            switch ((unsigned)(signed char)(unsigned)((short)i2 > (signed char)0x10000u) & 7u) {
                i1 = ~(((unsigned)(w0 >> 29) ? (unsigned)s0 : 7u) << (-(p1 | (unsigned)w0) & 31u)) & 15u;
                u1 += ((unsigned)(short)(unsigned)((int)(u1 % (garr[u2 & 7u] | 1u)) < (int)p2) - (unsigned)c0);
                case 7u: ;
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(short)(4u ^ p2) || 6u) & 255u);
                continue; (void)((unsigned)(unsigned char)(r0.x << (a0[u1 & 3u] & 31u)));
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)fuel;
                    x0 = x0 * 0x100000001b3ull + (unsigned)(((i0 << (a0[u1 & 3u] & 31u)) >> (garr[i1 & 7u] & 31u)) == (unsigned)(u0 && p2));
                    s0 = (int)(p0 ^ 0x7fffffffu);
                    w0 = w0 * 6364136223846793005ull + (unsigned)(u2 < (unsigned)w0);
                    while (i0++ < 4u && (p1 + 0xffffffffu)) { if (--fuel == 0u) goto done;
                        if (0xf394ad4cu) break;
                        if (fuel < 8u) return (unsigned)((int)(unsigned)(w0 >> 29) >= (int)u3);
                        if (budget != 0u) { budget -= 1u; u0 = fn0((u0 << ((unsigned)(unsigned char)((unsigned)h0 % ((unsigned)w0 | 1u)) & 31u)), ((unsigned)l0 - *q0), garr[i1 & 7u]); }
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(a0[i0 & 3u] && (unsigned)c1), (unsigned)h1, i1); }
                        case 4u: ;
                        h1 = (unsigned short)(h1 + (unsigned)(p1 == ((p0 * 0xdcc79952u) >> (0x10000u & 31u))));
                    }
                }
            }
            m0 ^= ((unsigned)w0 * 9u);
            break; (void)(~((unsigned)s0 ^ i2));
        } while (i1++ < 7u && 0x7fffffffu);
        { unsigned t2; double z2; if (((unsigned)((unsigned)b0 == (0x7fffffffu ^ 0x1e8cf597u))) & 1u) { t2 = (unsigned)((unsigned)c1 < (unsigned)x0); z2 = (double)(((unsigned)((int)0x80000000u >= (int)(i2 >> ((unsigned)(x0 >> 70) & 31u)))) & 255u); } if (((unsigned)((unsigned)b0 == (0x7fffffffu ^ 0x1e8cf597u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            if (budget != 0u) { budget -= 1u; u1 = fn0((0x80000000u - (unsigned)d0), (unsigned)((short)(unsigned)s0 > (signed char)(unsigned)f0), ((unsigned)h0 & r0.y)); }
        }
        if ((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)c0)) goto L0;
        continue; (void)(0x80000000u);
        if (((unsigned)!((unsigned)b0 ^ (unsigned)c0) * r0.y)) {
            g0 = (-(unsigned)((unsigned)c1 && (unsigned)h0) | (unsigned)f0);
            if (u0) break;
            if ((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)((int)m0 >= (int)(unsigned)(w0 >> 29)))) {
                if ((0xffffffffu >> ((unsigned)d0 & 31u))) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0(i2, ((unsigned)h0 - (g1 << ((unsigned)w0 & 31u))), *q0); }
                if ((a0[i0 & 3u] << (0x4ef9037u & 31u))) break;
                goto L2;
                if ((unsigned)(0x7fffffffu || r0.y)) continue;
                e0 = e0 * 0.5L + (long double)(0x7fffffffu & 1023u);
            }
            if (((unsigned)h1 - 0xffffffffu)) goto L4;
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)h1, (garr[u2 & 7u] / (u2 | 1u)), (0x7855cadbu & (unsigned)((unsigned)h0 || garr[u2 & 7u]))); }
        }
        m0 ^= (((unsigned)e0 * 0x9c32b84u) & u3);
    } while (i0++ < 2u && (unsigned)!(unsigned)((unsigned)((int)r0.x < (int)(unsigned)c1) < (unsigned)e0));
    if ((p0 | 0x80000000u)) {
        if ((unsigned)h1) goto L0;
        if (r0.x) {
            if (-((unsigned)(w0 >> 29) & (unsigned)x0)) {
                if (budget != 0u) { budget -= 1u; u1 = fn0((fuel << ((unsigned)x0 & 31u)), r0.y, (unsigned)e0); }
                e0 = e0 * 0.5L + (long double)((((unsigned)!((unsigned)f0 | (unsigned)(unsigned char)(g0 << ((unsigned)b0 & 31u))) % (p0 | 1u)) >> (g0 & 31u)) & 1023u);
                for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    v0 = (0xc762f38du * g1);
                    v0 = (unsigned)((short)(u2 / ((unsigned)h1 | 1u)) > (signed char)((unsigned)s1 + (unsigned)((short)9u > (signed char)0xc676facbu)));
                    if ((unsigned)(i2 && (unsigned)b0)) break;
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        goto L2;
                        if ((unsigned)d0) break;
                        m0 ^= (a0[i0 & 3u] * 0u);
                        if ((unsigned)s1) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(r0.y, 0x80000000u, g1); }
                        do { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u1 = fn0((u1 % (p1 | 1u)), ((unsigned)!(unsigned)(r0.x < p2) << ((unsigned)h0 & 31u)), (unsigned)((unsigned)s1 || g0)); }
                            e0 = e0 * 0.5L + (long double)((4u + (unsigned)s0) & 1023u);
                            a0[(unsigned)c0 & 3u] = (u2 * (0x4f74938eu / ((unsigned)(0x26e2be93u && m0) | 1u)));
                            a0[(a0[u1 & 3u] | a0[i0 & 3u]) & 3u] = (g0 + (unsigned)((int)0xe0f3b986u < (int)(r0.x | i0)));
                            *q0 += (unsigned)((u2 % ((1u + g0) | 1u)) && (0xffffffffu << ((unsigned)l0 & 31u)));
                            m0 ^= (*mp ? u0 : (0x80000000u & garr[u2 & 7u]));
                        } while (i2++ < 7u && ((unsigned)h0 & (unsigned)(signed char)(0x80000000u / ((unsigned)c0 | 1u))));
                    }
                }
                u2 = (unsigned)(((unsigned)(u2 || (unsigned)c1) / (garr[i1 & 7u] | 1u)) || garr[i1 & 7u]);
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)s1, ((p2 << (*mp & 31u)) << (0x7fffffffu & 31u)), 7u); }
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)(w0 >> 29) || (r0.x - garr[u2 & 7u])), (u2 & (unsigned)d0), 8u); }
                    u1 = u1 * 0x9e3779b1u + ((unsigned)((unsigned)e0 == (unsigned)((unsigned)l0 < m0)) & (9u | 3u));
                    q0 = &garr[(0xb801092du / ((unsigned)((unsigned)l0 == (unsigned)d0) | 1u)) & 7u];
                }
                if (0x4a6fa0eau) goto L4;
            }
            s0 = (int)((u2 ? (0x7fffffffu / ((unsigned)h0 | 1u)) : 0x9ec209e2u) / ((unsigned)f0 | 1u));
        }
        if ((unsigned)(w0 >> 29)) goto L2;
        v0 = (unsigned)((short)-(unsigned)((unsigned)(p0 && p1) == (unsigned)c1) > (signed char)(unsigned)((int)(unsigned)w0 < (int)u0));
        x0 = x0 * 0x100000001b3ull + (0x10000u >> (a0[i0 & 3u] & 31u));
    } else {
        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((short)u1 > (signed char)i1) || 0xffffffffu));
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)d0, (u2 >> ((unsigned)(x0 >> 70) & 31u)), (r0.y >> ((8u << (0x5a2fb76du & 31u)) & 31u))); }
    }
    u1 = (((0x7fffffffu >> ((unsigned)w0 & 31u)) >> (i0 & 31u)) * a0[i0 & 3u]);
    s1 = (int)((unsigned)s1 + u2);
    switch (u0 & 7u) {
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (5u) {
                e0 = e0 * 0.5L + (long double)(((unsigned)((int)u1 < (int)((unsigned)h0 % (0u | 1u))) * (*q0 >> ((unsigned)l0 & 31u))) & 1023u);
                g0 = (unsigned)((9u >> (0xffffffffu & 31u)) == (unsigned)((int)0x10000u < (int)0xea6bf51fu));
                x0 = x0 * 0x100000001b3ull + (*mp << ((0x80000000u | (unsigned)s0) & 31u));
            } else {
                case 1u: ;
            }
            i0 = (unsigned)((int)(unsigned)x0 < (int)(0x7fffffffu & (unsigned)s1)) & 15u;
            s0 = (int)(unsigned)(short)(garr[i1 & 7u] & (unsigned)((5u / ((unsigned)l0 | 1u)) || (unsigned)((int)a0[i0 & 3u] < (int)g0)));
            f0 = f0 * 0.5f + (float)(((unsigned)h0 - (((unsigned)e0 << ((unsigned)l0 & 31u)) / ((u2 + (unsigned)d0) | 1u))) & 255u);
        }
        if (budget != 0u) { budget -= 1u; u2 = fn1((((unsigned)f0 * 2u) % (u0 | 1u)), (unsigned)((short)g0 > (signed char)(unsigned)(w0 >> 29)), p1); }
        default: ;
    }
    { unsigned t3; double z3; if ((0x80000000u) & 1u) { t3 = (unsigned)((int)r0.y < (int)-((unsigned)c1 + 3u)); z3 = (double)((u1) & 255u); } if ((0x80000000u) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        l0 = (long)((unsigned long)l0 + (r0.y ? (unsigned)s0 : (unsigned)h1));
        if (0xffffffffu) goto L3;
        switch ((i1 % (~(unsigned)(6u && u2) | 1u)) & 7u) {
            goto done;
            u3 += (((unsigned)((int)i0 < (int)0x6a9c2b25u) / (-(unsigned)(r0.y < (unsigned)l0) | 1u)) & (unsigned)c0);
            do { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)(*q0);
                    while (i2++ < 6u && (*q0 % (5u | 1u))) { if (--fuel == 0u) goto done;
                        case 3u: ;
                        garr[(r0.y ^ r0.y) & 7u] = (unsigned)x0;
                    }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(x0 >> 70), (garr[i1 & 7u] | ((unsigned)(w0 >> 29) & u2)), ((unsigned)s0 ? p0 : r0.x)); }
            } while (i0++ < 6u && (unsigned)c0);
            case 0u: ;
        }
        goto L2;
        i0 = (unsigned)((short)fuel > (signed char)i1) & 15u;
        while (i0++ < 5u && (unsigned)(unsigned char)((unsigned)e0 % (u2 | 1u))) { if (--fuel == 0u) goto done;
            *q0 += ((unsigned)c1 * (unsigned)(w0 >> 29));
            if ((unsigned)((unsigned)d0 == (unsigned)(signed char)(unsigned)((short)u1 > (signed char)(unsigned)h1))) goto L4;
            if (*mp) continue;
            do { if (--fuel == 0u) goto done;
                break; (void)(a0[i0 & 3u]);
                h0 = (short)2u;
                h1 = (unsigned short)(h1 + (unsigned)(w0 >> 29));
                v0 = m0;
                h1 = (unsigned short)(h1 + 1u);
                break; (void)(~(unsigned)((short)(i2 * 2u) > (signed char)0x80000000u));
            } while (i1++ < 3u && (3u % (0x80000000u | 1u)));
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                u3 ^= ((unsigned)((short)0x7fffffffu > (signed char)p0) ? 0xd06993a9u : ((unsigned)e0 & garr[u2 & 7u]));
                if (budget != 0u) { budget -= 1u; u3 = fn1((*mp % (i0 | 1u)), 0x8b906e5du, ((unsigned)d0 % ((unsigned)f0 | 1u))); }
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((u2 & p0)) goto L1;
                    c1 = (signed char)(unsigned)((unsigned)((int)p1 < (int)r0.x) || p1);
                    if (budget != 0u) { budget -= 1u; u2 = fn1(0x10000u, (1u - *q0), p1); }
                    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)((unsigned)h1 - ((unsigned)w0 / (0xa3ff6c8eu | 1u))) & 1023u);
                    u3 = (unsigned)((int)(0xd1942350u + r0.y) < (int)((unsigned)d0 * (unsigned)s1));
                    if ((unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)(x0 >> 70) && p1) == g0)) break;
                }
                if (((m0 * 0xa3092732u) << (r0.y & 31u))) break;
                if ((unsigned)((int)(unsigned)(unsigned char)(u3 >> (garr[i1 & 7u] & 31u)) >= (int)m0)) break;
                if ((unsigned)(r0.x == u3)) {
                    b0 = ((7u ? p2 : (unsigned)(signed char)(unsigned)((unsigned)f0 < 7u)) / (*q0 | 1u)) != 0u;
                } else {
                    h0 = (short)(unsigned)(((unsigned)h1 | ((unsigned)d0 * (unsigned)x0)) && 0xd3f8d651u);
                    if ((unsigned)(((unsigned)s1 % (0x7fffffffu | 1u)) == 0x7fffffffu)) goto done;
                    if (i1) {
                        g0 = (0x481dc97au * 0xba855722u);
                        l0 = (long)((unsigned long)l0 + u2);
                    }
                }
            }
            s0 = (int)(8u / ((unsigned)e0 | 1u));
        }
    }
    if ((i2 << (0x10000u & 31u))) goto L3;
    if ((unsigned)(0xe02201d4u == ~(unsigned)(r0.x || 0xffffffffu))) goto L1;
    s1 = (int)((unsigned)s1 + ((0x7fffffffu >> ((unsigned)(4u == (unsigned)(x0 >> 70)) & 31u)) / (((unsigned)w0 & *mp) | 1u)));
    *q0 = (m0 / ((unsigned)c0 | 1u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)h1) goto L0;
    if (p0) goto L2;
    u0 = (unsigned)c0;
    s1 = (int)((unsigned)s1 + ((unsigned)((unsigned)s1 == 0xb1931d60u) * g1));
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)4u >= (int)(6u * (unsigned)x0)), ((unsigned)((unsigned)c0 == 0xb9f36b46u) * 0x80000000u), (unsigned)((int)0x7fffffffu >= (int)(unsigned)(signed char)(unsigned)((int)(unsigned)c1 >= (int)(unsigned)w0))); }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
            i1 = -((unsigned)(signed char)(unsigned)(1u || g1) << (g1 & 31u)) & 15u;
            g0 = (0x7fffffffu << (8u & 31u));
            if (budget != 0u) { budget -= 1u; u3 = fn2(0x80000000u, 7u, (unsigned)(w0 >> 29)); }
            if (garr[i1 & 7u]) break;
            if (0x7fffffffu) continue;
        }
        e0 = e0 * 0.5L + (long double)(v0 & 1023u);
    }
    m0 ^= ((unsigned)((p2 >> (0x8cc8ce44u & 31u)) < (unsigned)h0) / ((unsigned)(0x10000u == garr[i1 & 7u]) | 1u));
    if (fuel < 8u) return ((unsigned)((unsigned)((int)(unsigned)c0 >= (int)u3) < i2) & (0u - u2));
    if ((0x10000u * g1)) goto done;
    do { if (--fuel == 0u) goto done;
        r0.y ^= (u2 ^ u3);
    } while (i0++ < 4u && p0);
    if ((unsigned)s0) {
        h1 = (unsigned short)(h1 + ((unsigned)((int)u1 < (int)u2) / ((unsigned)((short)(unsigned)c1 > (signed char)fuel) | 1u)));
        if (budget != 0u) { budget -= 1u; u0 = fn0(u3, (a0[i0 & 3u] * (unsigned)((unsigned)s1 < (unsigned)(w0 >> 29))), (3u * m0)); }
        m0 ^= r0.x;
        q0 = &garr[(r0.y ? 6u : (unsigned)c0) & 7u];
        for (;;) { if (--fuel == 0u) goto done;
            if (((unsigned)e0 / (fuel | 1u))) goto L3;
            s0 = (int)(unsigned)(short)(unsigned)(-(unsigned)((int)((unsigned)x0 + (unsigned)s1) < (int)m0) && r0.x);
            { unsigned t0; double z0; if ((u0) & 1u) { t0 = (unsigned)(signed char)(p2 << ((unsigned)((int)r0.y >= (int)(unsigned)c1) & 31u)); z0 = (double)(((unsigned)(p1 && (unsigned)((int)(unsigned)c0 < (int)(unsigned)c1))) & 255u); } if ((u0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                L1: if (--fuel == 0u) goto done;
                m0 ^= *q0;
                u0 += (0x4b277324u ^ 5u);
                L2: if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)(unsigned char)(0x7fffffffu ^ u1) ^ (unsigned)c1)) break;
                }
            }
            for (;;) { if (--fuel == 0u) goto done;
                goto L0;
                goto L2;
                r0.x = (unsigned)((int)(unsigned)((int)(unsigned)f0 >= (int)u0) >= (int)(unsigned)x0);
                if (budget != 0u) { budget -= 1u; u0 = fn1((0x63baac29u - -(unsigned)((int)(unsigned)c1 < (int)r0.y)), (0xffffffffu & (unsigned)((unsigned)s1 && (unsigned)s1)), (0x2e4976ddu + (*mp + 1u))); }
            }
        }
        u3 = (unsigned)(i2 || (unsigned)(1u == m0));
    } else {
        x0 = x0 * 0x100000001b3ull + ~(a0[i0 & 3u] >> ((unsigned)e0 & 31u));
        switch ((g0 << ((unsigned)l0 & 31u)) & 7u) {
            a0[~(unsigned)(a0[u1 & 3u] == 0x7fffffffu) & 3u] = ~((unsigned)(signed char)((unsigned)(signed char)(u2 - r0.y) * (unsigned)s1) * (0x402e59e6u + (unsigned)h1));
            case 7u: ;
            u3 += ((unsigned)!(unsigned)(p2 == 5u) | (unsigned)s0);
        }
    }
    if (0u) {
        u1 = (unsigned)!(unsigned)((unsigned)((unsigned)(r0.y && u1) == 0xf901b1u) == -(unsigned)((short)0x80000000u > (signed char)0x546801f5u));
        u0 = u0 * 0x9e3779b1u + ((unsigned)(x0 >> 70) / ((unsigned)s0 | 1u));
        do { if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
        } while (i0++ < 4u && (unsigned)(signed char)(unsigned)((int)u1 < (int)0xdf92df6du));
        u3 = (unsigned)c0;
        if (budget != 0u) { budget -= 1u; u2 = fn0(0x77132251u, (0xf7fbff5cu / ((unsigned)c0 | 1u)), (unsigned)((int)9u < (int)(unsigned)(0u || garr[i1 & 7u]))); }
        goto L1;
    }
    if (0x80000000u) goto done;
    f0 = f0 * 0.5f + (float)((*mp / ((unsigned)(((unsigned)c1 / (3u | 1u)) || (p0 + a0[u1 & 3u])) | 1u)) & 255u);
    if ((unsigned)((unsigned)w0 < i1)) {
        switch (0x80000000u & 7u) {
            if ((unsigned)(short)(unsigned)((short)9u > (signed char)(unsigned)(garr[i1 & 7u] || 8u))) {
                u0 ^= ((-(unsigned)(v0 == g0) / (3u | 1u)) << ((unsigned)h1 & 31u));
                L4: if (--fuel == 0u) goto done;
                break; (void)((unsigned)s0);
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(signed char)(a0[i0 & 3u] << ((unsigned)(r0.x || 0x76de336fu) & 31u)), i0, a0[i0 & 3u]); }
                v0 = ((0x53dba440u | u0) | ((fuel * 0x7fffffffu) ^ garr[u2 & 7u]));
                if ((unsigned)w0) break;
            }
            while (i0++ < 6u && u1) { if (--fuel == 0u) goto done;
                case 4u: ;
                while (g0) { if (--fuel == 0u) goto done;
                    case 1u: ;
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        case 3u: ;
                    }
                    break; (void)((unsigned)((short)(fuel * r0.x) > (signed char)v0));
                    c1 = (signed char)(unsigned)(unsigned char)(u0 / (~(i2 * 0xc3e22fc2u) | 1u));
                    g0 = (unsigned)(signed char)((unsigned)(w0 >> 29) ^ ((i2 / (~(unsigned)(i2 || garr[u2 & 7u]) | 1u)) % (u2 | 1u)));
                }
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 5u: ;
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn2((p1 | (unsigned)(signed char)(a0[i0 & 3u] ^ p1)), (a0[u1 & 3u] | (unsigned)(0x517a35bu < *mp)), 0u); }
                    } while (i2++ < 2u && (unsigned)(signed char)(unsigned)((int)(p1 ^ (unsigned)s0) >= (int)(unsigned)w0));
                    if (-(unsigned)((short)9u > (signed char)0xeb0c41a6u)) goto L2;
                    while (i2++ < 5u && (unsigned)d0) { if (--fuel == 0u) goto done;
                        *q0 += 0x2c778ea4u;
                        garr[(unsigned)((unsigned)e0 && (unsigned)f0) & 7u] = ((unsigned)((int)0xfb2a9427u >= (int)0u) >> (g0 & 31u));
                        u0 ^= (fuel & p1);
                    }
                    goto L0;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0(i1, (v0 % (garr[u2 & 7u] | 1u)), ((unsigned)(x0 >> 70) | (unsigned)(x0 >> 70))); }
                while (~(u1 * 0xfd51a626u)) { if (--fuel == 0u) goto done;
                    g1 += (unsigned)(short)((0xf12d3ecdu * (unsigned)c0) >> ((0xbc861049u & u2) & 31u));
                    b0 = (unsigned)((int)((unsigned)h0 | r0.x) < (int)p0) != 0u;
                    g0 = (unsigned)((unsigned)(w0 >> 29) || (unsigned)((int)(unsigned)(garr[i1 & 7u] < (unsigned)((int)u1 >= (int)5u)) < (int)(unsigned)s0));
                    g0 = 0x7fffffffu;
                }
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 6u: ;
                    if (u3 == 7u) return ((unsigned)(signed char)(1u + (i0 + (unsigned)c1)) | u3);
                    c1 = (signed char)(unsigned)s1;
                    if ((unsigned)((unsigned)(x0 >> 70) || garr[u2 & 7u])) continue;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)h1, (a0[u1 & 3u] % (((unsigned)(x0 >> 70) - 0x234ad9e8u) | 1u)), ((unsigned)((short)(unsigned)c1 > (signed char)0xffffffffu) << ((unsigned)d0 & 31u))); }
                    while ((unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
                        *mp = ((0x10000u | 9u) / ((unsigned)((int)(unsigned)(0x10000u || 0x7fffffffu) >= (int)*mp) | 1u));
                        m0 ^= r0.x;
                        if ((unsigned)c1) continue;
                        e0 = e0 * 0.5L + (long double)(p0 & 1023u);
                        if (u3) break;
                        d0 = d0 * 0.5 + (double)(((unsigned)l0 - u1) & 1023u);
                    }
                }
            }
            if (((p0 | (unsigned)d0) * (unsigned)l0)) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((a0[u1 & 3u] * (unsigned)(p2 && 0x2292c3f7u)), *mp, (0u + u2)); }
        }
        while (i0++ < 2u && (4u - p1)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)c0 % (v0 | 1u)), (unsigned)(2u || p1), (unsigned)(short)(0x80000000u << ((unsigned)s0 & 31u))); }
            l0 = (long)((unsigned long)l0 + (~(unsigned)(r0.x == (unsigned)c0) + 0xdd13b58bu));
            if ((p0 - garr[i1 & 7u])) break;
            do { if (--fuel == 0u) goto done;
                u2 += (2u << (2u & 31u));
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)f0, (m0 - 7u), a0[u1 & 3u]); }
                    s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(unsigned)(((unsigned)f0 ? (m0 ^ (unsigned)e0) : a0[u1 & 3u]) || (unsigned)c0));
                    w0 = w0 * 6364136223846793005ull + (unsigned)l0;
                } while (i2++ < 6u && u2);
                for (;;) { if (--fuel == 0u) goto done;
                    { unsigned t1; double z1; if ((u3) & 1u) { t1 = (unsigned)h0; z1 = (double)(((unsigned)(p0 || 0x45cd0ab5u)) & 255u); } if ((u3) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                        if ((unsigned)!(unsigned)((int)(unsigned)(u3 && 4u) < (int)0xc1b6e10eu)) break;
                        l0 = (long)((unsigned long)l0 + (i0 ^ (unsigned)h1));
                    }
                    if ((a0[i0 & 3u] | 0x10000u)) continue;
                    *q0 = ((r0.y ? 0xc86b5785u : u2) - (0x7fffffffu + garr[i1 & 7u]));
                    g0 = ((garr[u2 & 7u] ^ 0xffffffffu) | (0x10000u ^ 2u));
                    if ((unsigned)(0xc6ae0e77u < (unsigned)c0)) break;
                    switch (0x95be660au & 7u) {
                        s0 = (int)(unsigned)((short)(unsigned)(3u < (unsigned)x0) > (signed char)(unsigned)d0);
                    }
                }
                i1 = ((unsigned)(short)((9u & (unsigned)x0) / (p1 | 1u)) >> ((unsigned)!((unsigned)s0 ^ u0) & 31u)) & 15u;
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)!(fuel << (*q0 & 31u)), (r0.x | (unsigned)(short)(unsigned)((int)(unsigned)h1 < (int)(unsigned)h1)), (unsigned)(signed char)(r0.x - garr[u2 & 7u])); }
            } while (i1++ < 3u && (0x3bd9e2du | u3));
        }
        goto L3;
    } else {
        i0 = (fuel ^ (unsigned)((int)1u < (int)(unsigned)!(unsigned)((short)g1 > (signed char)(unsigned)((int)0x132acc32u >= (int)r0.x)))) & 15u;
        u3 += ((unsigned)((unsigned)h1 == 9u) + 0x2abfc33eu);
        if (budget != 0u) { budget -= 1u; u1 = fn2(9u, (unsigned)!(unsigned)((unsigned)b0 && (unsigned)h0), (0x34a4a504u & garr[u2 & 7u])); }
    }
    if ((0x98712292u >> (0xc93c75b1u & 31u))) goto L2;
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)p0 >= (int)fuel), g1, r0.x); }
    v0 = ((*mp & 0x80000000u) ^ 3u);
    if (budget != 0u) { budget -= 1u; u3 = fn0((0xb48dd74au ^ ((unsigned)(w0 >> 29) - fuel)), u3, (unsigned)(x0 >> 70)); }
    u1 = (*mp ? v0 : u3);
    u0 ^= (unsigned)((unsigned)((unsigned)((short)((unsigned)(w0 >> 29) + u0) > (signed char)6u) < (unsigned)s1) || 0x7fffffffu);
    c0 = (unsigned char)(unsigned)((int)(unsigned)((int)r0.x >= (int)(unsigned)w0) >= (int)(unsigned)c0);
    *q0 = ((unsigned)(i2 || (unsigned)(r0.y && g1)) ^ m0);
    u0 = (unsigned)(u0 == ((unsigned)x0 << (r0.y & 31u)));
    goto L4;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)(signed char)(unsigned)(a0[u1 & 3u] == (6u + fuel)) & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)c1, u3, 7u); }
            x0 = x0 * 0x100000001b3ull + ((unsigned)s1 + (unsigned)(7u == 0x80000000u));
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 = (0xffffffffu / ((p2 << ((unsigned)b0 & 31u)) | 1u));
            }
            if ((unsigned)w0) break;
            if ((garr[u2 & 7u] % (0u | 1u))) {
                b0 = ((p1 % (2u | 1u)) / (u1 | 1u)) != 0u;
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)s0 | 5u), (fuel & 0xe2bcbd5bu), (unsigned)((int)~(unsigned)(a0[u1 & 3u] && r0.y) >= (int)0x10000u)); }
                    b0 = (unsigned)((garr[u2 & 7u] - u2) || (((unsigned)b0 + (unsigned)h0) % (7u | 1u))) != 0u;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)x0 == u3), (unsigned)(signed char)(unsigned)((unsigned)c1 || (0x4e214c41u / (0x877f2a57u | 1u))), ((unsigned)s0 & 0x10000u)); }
                    g0 = (unsigned)(signed char)((unsigned)(w0 >> 29) & (unsigned)d0);
                    { unsigned t2; double z2; if (((unsigned)s0) & 1u) { t2 = (0x268c0cfdu * 4u); z2 = (double)((-((unsigned)(0x80142487u || (unsigned)c1) | 0x10000u)) & 255u); } if (((unsigned)s0) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                        goto L1;
                        *q0 += (unsigned)(garr[i1 & 7u] == (unsigned)(unsigned char)(unsigned)((short)(unsigned)((int)(unsigned)(w0 >> 29) < (int)p2) > (signed char)u1));
                    }
                    goto L2;
                }
            }
        }
        s1 = (int)((unsigned)s1 + (3u | (7u * 0x10000u)));
        { unsigned t3; double z3; if (((unsigned)((unsigned)s1 < (unsigned)(0x58f3412u == (unsigned)w0))) & 1u) { t3 = (unsigned)l0; z3 = (double)((g1) & 255u); } if (((unsigned)((unsigned)s1 < (unsigned)(0x58f3412u == (unsigned)w0))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            q0 = &garr[(unsigned)(short)(unsigned)((int)0x10000u < (int)(((unsigned)s1 * ((unsigned)h0 - (unsigned)h0)) & (unsigned)s0)) & 7u];
            if (u1) {
                a0[(3u - r0.x) & 3u] = (unsigned)((unsigned)f0 && (0x80000000u | (unsigned)c0));
                u2 = 1u;
            } else {
                switch ((unsigned)(8u && p0) & 7u) {
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(7u, i0, (unsigned)(short)(0x16858b7au + 0x5b1311bbu)); }
                        u0 = ((unsigned)b0 & (unsigned)((int)7u >= (int)5u));
                    } while (i1++ < 3u && ((unsigned)((int)i1 < (int)garr[i1 & 7u]) ^ 0x7fffffffu));
                    break; (void)(0x260c7784u);
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)d0, ((unsigned)h0 >> ((a0[i0 & 3u] ^ (unsigned)s0) & 31u)), (unsigned)s0); }
            }
            g0 = (unsigned)((int)(unsigned)((int)(unsigned)(x0 >> 70) < (int)*mp) < (int)p1);
            g1 += ((unsigned)d0 + (u3 ^ (9u / (r0.y | 1u))));
            u2 += (unsigned)(w0 >> 29);
        }
        if ((unsigned)((short)u0 > (signed char)i2)) break;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)b0 ? 0x7fffffffu : u3)) break;
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                v0 = ((unsigned)(u3 < a0[i0 & 3u]) % (0xd16ef79eu | 1u));
                if ((unsigned)((unsigned)(short)(unsigned)((int)i1 < (int)m0) == r0.x)) break;
            }
        }
        goto L3;
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)(i1 & 7u);
        r0.y ^= (unsigned)((int)((unsigned)b0 & garr[i1 & 7u]) < (int)i0);
    }
    e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)(short)(g0 * 0x4642d7d3u) < (int)(unsigned)s0) & 1023u);
    g1 += ((p0 % (garr[u2 & 7u] | 1u)) << ((unsigned)!(unsigned)((int)garr[u2 & 7u] < (int)0x6f2f0a67u) & 31u));
    if ((unsigned)(a0[i0 & 3u] && (unsigned)(short)((unsigned)w0 + 0x10000u))) goto L0;
    if ((unsigned)((int)p0 < (int)(unsigned)d0)) goto L2;
    if (((unsigned)f0 << ((unsigned)e0 & 31u))) goto L1;
    r0.y ^= (unsigned)((int)(0x5e405b54u & u3) >= (int)~(unsigned)(6u && (unsigned)e0));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            garr[(0x10000u % (0x10000u | 1u)) & 7u] = (unsigned)c1;
            w0 ^= (unsigned long long)(unsigned)w0 << ((0xe2e359e4u * (unsigned)((int)v0 < (int)(unsigned)b0)) & 63u);
            u0 ^= (((unsigned)x0 ^ 8u) / ((unsigned)(0xffffffffu && 6u) | 1u));
            if ((((unsigned)s0 ^ 2u) / (garr[u2 & 7u] | 1u))) break;
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(x0 >> 70) < (int)9u));
        }
        break; (void)(0xffffffffu);
        g0 = (unsigned)(0x10000u || (unsigned)(short)((unsigned)((int)(unsigned)x0 >= (int)u1) / ((p0 + r0.x) | 1u)));
        if ((unsigned)((int)g1 < (int)g1)) continue;
        s0 = (int)(0xbaa06886u ^ garr[i1 & 7u]);
        h0 = (short)(r0.x % ((7u | i1) | 1u));
    }
    { unsigned t0; double z0; if (((unsigned)((fuel / ((unsigned)b0 | 1u)) < g0)) & 1u) { t0 = ((unsigned)d0 << (i0 & 31u)); z0 = (double)(((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)s0)) & 255u); } if (((unsigned)((fuel / ((unsigned)b0 | 1u)) < g0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        goto L0;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn3((i2 * (u1 * (unsigned)h0)), ((unsigned)w0 * v0), (0x10000u & 0x80000000u)); }
    c1 = (signed char)((unsigned)((int)0x6a80e6d5u < (int)0x208b9f3du) & a0[i0 & 3u]);
    w0 ^= (unsigned long long)-(0x4412382fu >> (garr[i1 & 7u] & 31u)) << ((0u % ((unsigned)c0 | 1u)) & 63u);
    *mp = ((unsigned)((int)(0x10944129u / (a0[i0 & 3u] | 1u)) < (int)(unsigned)((int)u1 >= (int)(unsigned)e0)) + (unsigned)(w0 >> 29));
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)(unsigned)((int)(unsigned)l0 >= (int)8u) >= (int)*q0), ((unsigned)((short)2u > (signed char)u2) & (unsigned)(x0 >> 70)), (g0 % (1u | 1u))); }
    if (u0) goto done;
    if (((unsigned)((int)u1 >= (int)u0) * 0x7fffffffu)) goto L3;
    r0.x = 3u;
    if (0x10000u) goto L3;
    v0 = -((unsigned)((short)(unsigned)h1 > (signed char)0x9e05367eu) - (unsigned)e0);
    if (0x2a3980f2u) {
        if (garr[i1 & 7u]) {
            w0 = w0 * 6364136223846793005ull + (((unsigned)(w0 >> 29) % (((unsigned)d0 >> (2u & 31u)) | 1u)) << ((unsigned)(w0 >> 29) & 31u));
            while (i0++ < 4u && (9u - g1)) { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if (((unsigned)(0xd0be3548u == (unsigned)(w0 >> 29))) & 1u) { t1 = (unsigned)(w0 >> 29); z1 = (double)(((unsigned)((unsigned)s0 == g0)) & 255u); } if (((unsigned)(0xd0be3548u == (unsigned)(w0 >> 29))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    b0 = ((unsigned)h1 + (0x2e5298c7u - (unsigned)((unsigned)e0 && u1))) != 0u;
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        m0 ^= (unsigned)((short)6u > (signed char)*mp);
                        e0 = e0 * 0.5L + (long double)(g1 & 1023u);
                    }
                    g0 = ((u3 * 4u) ^ (unsigned)(u2 < i0));
                    if (((unsigned)w0 << (0x10000u & 31u))) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn3(i2, ((0x126cb2e2u * garr[i1 & 7u]) % (fuel | 1u)), (0u * (unsigned)(0xdf8314b6u == 0x10000u))); }
                    u0 ^= 0x48e314c9u;
                }
                L1: if (--fuel == 0u) goto done;
            }
            w0 = w0 * 6364136223846793005ull + (u1 ^ (unsigned)w0);
        } else {
            h0 = (short)((u3 + (unsigned)((unsigned)l0 || 0x1400e2bfu)) * p1);
            f0 = f0 * 0.5f + (float)(((0x10000u - r0.x) ^ garr[i1 & 7u]) & 255u);
            if ((g0 | (fuel % (i1 | 1u)))) goto done;
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(r0.x < (a0[i0 & 3u] / (p1 | 1u)))) break;
                while ((unsigned)h1) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + ~((unsigned)d0 | (unsigned)(short)(unsigned)(r0.y < 4u));
                    L2: if (--fuel == 0u) goto done;
                }
                break; (void)((unsigned)(w0 >> 29));
                b0 = ((unsigned)d0 ? g1 : (r0.y ^ *mp)) != 0u;
            }
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + 9u;
            if (((unsigned)e0 % ((unsigned)((unsigned)l0 == (unsigned)c1) | 1u))) break;
            g0 = a0[u1 & 3u];
            u3 += (unsigned)((int)(unsigned)((int)0xffffffffu < (int)*mp) >= (int)((unsigned)c0 << ((unsigned)(w0 >> 29) & 31u)));
        }
        L3: if (--fuel == 0u) goto done;
    }
    switch (i0 & 7u) {
        *q0 = ((unsigned)((unsigned)c1 < (unsigned)x0) | (i0 / ((i2 >> (a0[i0 & 3u] & 31u)) | 1u)));
        w0 = w0 * 6364136223846793005ull + ~(unsigned)(p0 < (unsigned)((int)0xfde9950eu >= (int)v0));
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            b0 = (unsigned)b0 != 0u;
            u0 ^= (2u << ((g0 - a0[i0 & 3u]) & 31u));
            r0.x = (unsigned)((int)(unsigned)(short)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(u0 >> (u1 & 31u))) >= (int)(p0 * 3u));
            continue; (void)((unsigned)((unsigned)((int)i0 < (int)1u) && 0u));
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)(signed char)((unsigned)x0 + 0x80000000u) >> (*mp & 31u))) break;
            }
        }
        while (i0++ < 3u && (unsigned)((int)(unsigned)(0x10000u == u2) >= (int)0x10000u)) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(8u & 1023u);
            if ((1u ^ (unsigned)(g1 == (unsigned)w0))) continue;
        }
    }
    if ((u1 % (0xffffffffu | 1u))) goto done;
    c0 = (unsigned char)2u;
    switch (((unsigned)c0 >> (((unsigned)s0 % (v0 | 1u)) & 31u)) & 7u) {
        if (budget != 0u) { budget -= 1u; u1 = fn2((fuel - 0x10000u), ~(fuel & u1), (unsigned)((int)u2 >= (int)i2)); }
        case 3u: ;
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(0xd56fe64cu, (g0 * p2), (unsigned)l0); }
        }
        w0 ^= (unsigned long long)(unsigned)((int)a0[i0 & 3u] >= (int)v0) << (i0 & 63u);
        case 7u: ;
        case 1u: ;
    }
    *q0 += i2;
    d0 = d0 * 0.5 + (double)((unsigned)((int)6u < (int)(unsigned)c1) & 1023u);
    a0[(unsigned)(8u && g1) & 3u] = ~(((unsigned)b0 / (7u | 1u)) ^ 0x10000u);
L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 3u, 0xcbeac323u, 0xa454ab44u },
        { 4u, 0x4e89f6f5u, 0x489f3a95u },
        { 13u, 0x8e3a2965u, 0x91e3b268u },
        { 5u, 0x30470ec1u, 0x17eadeddu },
        { 5u, 0xac8055ffu, 0x727f19f2u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
