// test-ssa-source's program of seed 134000407 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xa976bad3u, g1 = 0xae8388cfu;
static unsigned garr[8] = { 0xcdebc2fbu, 0xad9b9726u, 0x2127bcedu, 0x7d342812u, 0x38246ac4u, 0x9a1a2694u, 0x7499b2f8u, 0x76f9543au };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if ((p1) & 1u) { t0 = (p2 + (unsigned)f0); z0 = (double)(((unsigned)(short)(unsigned)((short)p2 > (signed char)((unsigned)x0 & 0x80000000u))) & 255u); } if ((p1) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)(((unsigned)c1 % (0x10000u | 1u)) + 0x1426251du);
        if ((unsigned)((unsigned)e0 || *q0)) goto L1;
        while (i0++ < 5u && (unsigned)(u2 == u3)) { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
            while (i1++ < 4u && (1u + (unsigned)x0)) { if (--fuel == 0u) goto done;
                if ((unsigned)l0) break;
                *q0 = (unsigned)x0;
            }
            L1: if (--fuel == 0u) goto done;
        }
        goto L2;
        if (-(0x10000u << (r0.y & 31u))) goto L0;
    }
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (i0) goto done;
            switch ((u2 % ((*q0 % (r0.x | 1u)) | 1u)) & 7u) {
                goto L0;
                L2: if (--fuel == 0u) goto done;
            }
            *q0 = ((unsigned)c1 + (unsigned)s1);
        }
        if (0x80000000u) break;
        *mp = (g0 % ((1u / (p2 | 1u)) | 1u));
        { unsigned t1; double z1; if (((p0 + (p0 - i2))) & 1u) { t1 = ((unsigned)((unsigned)(w0 >> 29) || (unsigned)c0) % (r0.y | 1u)); z1 = (double)(((0x7fffffffu + (0xea4cf4b2u | 9u))) & 255u); } if (((p0 + (p0 - i2))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            if (((0x7fffffffu + i2) / (7u | 1u))) {
                if (0x45a9e291u) break;
                u1 += g0;
                if ((unsigned)((unsigned)s1 || (unsigned)s0)) {
                    g0 = (unsigned)((int)(unsigned)(0x80000000u && u0) >= (int)(0u ^ 1u));
                    if (3u) goto L4;
                    while (i1++ < 4u && (p2 ? p2 : a0[i0 & 3u])) { if (--fuel == 0u) goto done;
                        if ((u2 / (p2 | 1u))) break;
                        break; (void)((unsigned)((unsigned)h0 == u0));
                        *q0 += (m0 | p1);
                        m0 ^= r0.x;
                        u0 += ((3u * (0x7fffffffu / (u2 | 1u))) << (0x6db6429eu & 31u));
                        i1 = (2u >> ((unsigned)((unsigned)((short)p2 > (signed char)u3) == 4u) & 31u)) & 15u;
                    }
                    L3: if (--fuel == 0u) goto done;
                }
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return ((unsigned)(u2 < (unsigned)w0) | (unsigned)((int)0x7fffffffu >= (int)(r0.x & 0x10000u)));
                    L4: if (--fuel == 0u) goto done;
                    if ((unsigned)((int)v0 < (int)(unsigned)s0)) break;
                    goto L0;
                }
            } else {
                c0 = (unsigned char)(unsigned)(signed char)(u3 / (0xf909324u | 1u));
                if ((unsigned)(x0 >> 70)) break;
                if (v0) goto done;
                if ((a0[i0 & 3u] + 3u)) break;
            }
            if (((unsigned)c0 | (unsigned)((int)g0 < (int)(unsigned)e0))) break;
        }
        m0 ^= ~(i0 ? (unsigned)(5u || 0x10000u) : a0[u1 & 3u]);
        if (g1) break;
    } while (i0++ < 5u && (((unsigned)h0 * fuel) / (0u | 1u)));
    if ((unsigned)((unsigned)s0 == 0x80000000u)) goto done;
    goto L1;
    if ((unsigned)(unsigned char)(unsigned)(0x80000000u || 7u)) goto L4;
    switch ((((unsigned)s1 & i0) << (6u & 31u)) & 7u) {
        a0[0x8f110b15u & 3u] = ~((unsigned)(x0 >> 70) % (-(r0.x + (unsigned)(5u == m0)) | 1u));
        if (((unsigned)(x0 >> 70) >> (i0 & 31u))) {
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 1u: ;
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *mp = (unsigned)e0;
                    continue; (void)((unsigned)((unsigned)((unsigned)s0 || i1) && 0xffffffffu));
                }
                case 0u: ;
                if ((unsigned)((short)(unsigned)l0 > (signed char)0x19eff420u)) continue;
                v0 = (fuel ? (unsigned)(unsigned char)(unsigned)((int)m0 < (int)p0) : (unsigned)((int)(unsigned)h0 >= (int)g0));
            }
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t2; double z2; if (((unsigned)l0) & 1u) { t2 = 1u; z2 = (double)(((unsigned)((unsigned)w0 && ((unsigned)d0 >> (u3 & 31u)))) & 255u); } if (((unsigned)l0) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    case 4u: ;
                    c1 = (signed char)(unsigned)((int)m0 >= (int)0xd3b41f2du);
                }
                continue; (void)((i1 ^ (unsigned)h0));
                break; (void)((0xf2427c16u << (p0 & 31u)));
                u1 = u1 * 0x9e3779b1u + (unsigned)((int)(unsigned)(short)(unsigned)((int)1u >= (int)0xffffffffu) < (int)p0);
            }
            h1 = (unsigned short)(h1 + ((unsigned)e0 | u3));
            g0 = (unsigned)((unsigned)h1 < 0x67c039efu);
        }
        { unsigned t3; double z3; if (((*q0 ^ (unsigned)((unsigned)h1 || i0))) & 1u) { t3 = m0; z3 = (double)((((unsigned)((unsigned)c1 && (unsigned)s1) + 6u)) & 255u); } if (((*q0 ^ (unsigned)((unsigned)h1 || i0))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            m0 ^= (u3 ? a0[u1 & 3u] : u3);
            break; (void)(~((unsigned)(0xbaeb9187u == *q0) * 1u));
            case 6u: ;
            i0 = (6u & 0x7fffffffu) & 15u;
        }
    }
    if ((r0.y / ((*mp << (*mp & 31u)) | 1u))) {
        l0 = (long)((unsigned long)l0 + (unsigned)(1u && r0.y));
        goto L2;
    }
    u2 += u2;
    goto L2;
    s1 = (int)((unsigned)s1 + ((unsigned)((short)(unsigned)w0 > (signed char)0x3d67a8f9u) * (unsigned)(short)(u3 + (unsigned)x0)));
    switch (~(u2 | 5u) & 7u) {
        g1 += (unsigned)((int)(m0 | i2) >= (int)((unsigned)l0 << (i1 & 31u)));
        case 3u: ;
        case 0u: ;
        { unsigned t4; double z4; if ((0x80000000u) & 1u) { t4 = (unsigned)c1; z4 = (double)((u0) & 255u); } if ((0x80000000u) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            if (((unsigned)f0 / (r0.x | 1u))) goto L3;
        }
        if ((unsigned)((int)(unsigned)!((unsigned)(w0 >> 29) >> (0x80000000u & 31u)) < (int)fuel)) {
            if ((unsigned)((int)0x6d1f83f8u >= (int)(unsigned)((int)(unsigned)f0 < (int)i2))) break;
            if ((unsigned)s1) {
                case 5u: ;
                default: ;
                m0 ^= (unsigned)((unsigned)b0 == (unsigned)(x0 >> 70));
                m0 ^= (unsigned)((int)((v0 << (i2 & 31u)) & i0) < (int)(unsigned)l0);
                case 2u: ;
            }
            break;
            { unsigned t5; double z5; if ((((garr[i1 & 7u] - 0xbb7cbe49u) * 0x80000000u)) & 1u) { t5 = (unsigned)(i0 && (unsigned)((int)2u < (int)fuel)); z5 = (double)((u3) & 255u); } if ((((garr[i1 & 7u] - 0xbb7cbe49u) * 0x80000000u)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                u3 = (0x6f496bb4u & ((-(0xc70c701cu * 0x80000000u) >> (a0[u1 & 3u] & 31u)) * (unsigned)x0));
                c0 = (unsigned char)(9u % (0x7fffffffu | 1u));
                while (i0++ < 7u && (unsigned)((int)(unsigned)b0 >= (int)(unsigned)b0)) { if (--fuel == 0u) goto done;
                    if ((0x9187eee4u + u3)) continue;
                }
                v0 = (unsigned)((unsigned)h1 && (unsigned)((int)(garr[i1 & 7u] * (unsigned)h0) >= (int)p0));
                s0 = (int)((unsigned)f0 + (unsigned)d0);
                break;
            }
        } else {
            u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)s1 || ((unsigned)s0 - ((unsigned)x0 << (u2 & 31u))));
        }
        break;
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(((unsigned)(x0 >> 70) | fuel) < r0.y)) goto L3;
    }
    x0 = x0 * 0x100000001b3ull + (a0[i0 & 3u] & (unsigned)((short)r0.x > (signed char)((unsigned)h1 >> (i2 & 31u))));
    if ((unsigned)((short)(unsigned)!(unsigned)((int)(unsigned)w0 >= (int)(unsigned)l0) > (signed char)0x7fffffffu)) {
        while (i0++ < 6u && (unsigned)((int)*q0 < (int)(0x926f1733u / ((unsigned)e0 | 1u)))) { if (--fuel == 0u) goto done;
            *q0 += (unsigned)((int)0x7fffffffu >= (int)~((unsigned)l0 + r0.y));
            if ((unsigned)!(0x7fffffffu << ((a0[u1 & 3u] * 0x204f587bu) & 31u))) {
                if ((unsigned)((unsigned)(x0 >> 70) && (unsigned)d0)) break;
                f0 = f0 * 0.5f + (float)((unsigned)(0xffffffffu < (u0 & 7u)) & 255u);
                *mp = a0[i0 & 3u];
                break; (void)((unsigned)h0);
            } else {
                if (((unsigned)((unsigned)(w0 >> 29) || u3) >> (i2 & 31u))) break;
                g1 += ((unsigned)h0 - (unsigned)(x0 >> 70));
                { unsigned t6; double z6; if ((5u) & 1u) { t6 = g0; z6 = (double)((u2) & 255u); } if ((5u) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                    if (((p2 / (i2 | 1u)) / (i1 | 1u))) break;
                    { unsigned t7; double z7; if (((unsigned)s0) & 1u) { t7 = (0x4973c58cu % (0x9d97ce4bu | 1u)); z7 = (double)(((unsigned)((int)(0xffffffffu << ((unsigned)h1 & 31u)) >= (int)0xffffffffu)) & 255u); } if (((unsigned)s0) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                        if ((unsigned)((int)((unsigned)f0 * 0x7fffffffu) >= (int)(unsigned)d0)) break;
                        if ((unsigned)b0) break;
                        { unsigned t8; double z8; if (((0x197e4ae4u - fuel)) & 1u) { t8 = ((unsigned)(i1 && 7u) ^ fuel); z8 = (double)(((unsigned)((unsigned)x0 < (unsigned)(signed char)(unsigned)((short)(unsigned)e0 > (signed char)1u))) & 255u); } if (((0x197e4ae4u - fuel)) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                            goto L2;
                            if ((unsigned)(unsigned char)(4u | r0.y)) break;
                            if ((unsigned)(u2 == ((unsigned)h0 - a0[i0 & 3u]))) break;
                            if ((unsigned)(0x1e3ece4fu || 0x5f6cb67u)) break;
                            l0 = (long)((unsigned long)l0 + (unsigned)((int)0x7fffffffu >= (int)(unsigned)((unsigned)(i1 == i0) && (unsigned)c1)));
                            if ((fuel * *q0)) break;
                        }
                    }
                    a0[0xffffffffu & 3u] = (unsigned)((0x7fffffffu ^ 7u) && (3u | ((unsigned)(x0 >> 70) * 8u)));
                    u1 = ((unsigned)((int)3u >= (int)8u) % (((unsigned)d0 & g0) | 1u));
                }
                if ((unsigned)(0x7fffffffu || garr[u2 & 7u])) break;
            }
        }
    } else {
        x0 = x0 * 0x100000001b3ull + (unsigned)((short)u1 > (signed char)(unsigned)!(0x7fffffffu ? g1 : fuel));
        do { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)((short)(unsigned)(*mp == (p0 << (u2 & 31u))) > (signed char)r0.x);
            if ((unsigned)f0) break;
            break; (void)(((unsigned)x0 / (6u | 1u)));
            if (((unsigned)(signed char)(0x7fffffffu | (unsigned)l0) | r0.y)) {
                if ((unsigned)((unsigned)b0 == (unsigned)((short)u2 > (signed char)*mp))) {
                    if ((unsigned)s1) break;
                    break; (void)((*mp << ((unsigned)c1 & 31u)));
                }
                g1 += (unsigned)((int)(0xf7701420u % (i0 | 1u)) >= (int)(unsigned)((int)0xc17fd137u >= (int)*mp));
                if (((u3 >> (0x80000000u & 31u)) ^ (unsigned)l0)) break;
                { unsigned t9; double z9; if ((((unsigned)((short)(unsigned)l0 > (signed char)p2) - (unsigned)x0)) & 1u) { t9 = (unsigned)x0; z9 = (double)(((*mp >> (g1 & 31u))) & 255u); } if ((((unsigned)((short)(unsigned)l0 > (signed char)p2) - (unsigned)x0)) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                    if (0u) break;
                }
                if (*mp) break;
                u1 = ~(i0 >> ((unsigned)(short)(p1 % (garr[i1 & 7u] | 1u)) & 31u));
            }
            break; (void)((unsigned)h0);
            if ((unsigned)(a0[u1 & 3u] == 1u)) break;
        } while (i0++ < 2u && garr[u2 & 7u]);
        goto L1;
    }
    v0 = ((unsigned)h0 & garr[u2 & 7u]);
    h0 = (short)(unsigned)((int)0x7fffffffu < (int)(i0 >> (*mp & 31u)));
    m0 ^= m0;
    f0 = f0 * 0.5f + (float)(p2 & 255u);
    g0 = *mp;
    l0 = (long)((unsigned long)l0 + u2);
    c1 = (signed char)(0x6c698362u % (0xffffffffu | 1u));
    if (r0.x) goto L2;
    i1 = (0u - u2) & 15u;
    if ((unsigned)(short)(unsigned)((int)u1 < (int)u2)) goto L2;
    { unsigned t10; double z10; if (((unsigned)h1) & 1u) { t10 = 0xffffffffu; z10 = (double)(((unsigned)((int)0xffffffffu >= (int)(unsigned)f0)) & 255u); } if (((unsigned)h1) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            q0 = &garr[(((unsigned)f0 - ((unsigned)f0 << (p0 & 31u))) * (unsigned)s0) & 7u];
        }
        goto L4;
        if (((u0 - (unsigned)l0) % (0x80f3ec86u | 1u))) goto L4;
        if ((unsigned)e0) goto L0;
        q0 = &garr[(unsigned)((0u ^ a0[i0 & 3u]) && g1) & 7u];
        goto L2;
    }
    switch (p1 & 7u) {
        { unsigned t11; double z11; if (((unsigned)((short)1u > (signed char)r0.y)) & 1u) { t11 = (unsigned)((short)garr[i1 & 7u] > (signed char)0xc02366e2u); z11 = (double)(((5u % ((unsigned)(w0 >> 29) | 1u))) & 255u); } if (((unsigned)((short)1u > (signed char)r0.y)) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
            case 3u: ;
            w0 = w0 * 6364136223846793005ull + 7u;
        }
        if (((unsigned)s1 % (0xd37acdfbu | 1u))) {
            switch ((unsigned)(short)(unsigned)(p1 || (unsigned)(w0 >> 29)) & 7u) {
                b0 = ((unsigned)((int)i0 < (int)6u) + (u3 & ((unsigned)c0 << ((unsigned)c0 & 31u)))) != 0u;
                if ((u0 & (unsigned)h0)) break;
                *q0 = ((*q0 - (0x739d9e17u * (unsigned)(x0 >> 70))) ^ 0x80000000u);
                if ((unsigned)(unsigned char)(p1 | 0x7fffffffu)) break;
                s0 = (int)(unsigned)(signed char)((unsigned)h0 >> ((unsigned)((9u - (0x7fffffffu | *q0)) == fuel) & 31u));
            }
            case 1u: ;
            s0 = (int)(unsigned)((int)(unsigned)((unsigned)s1 == i0) >= (int)(unsigned)(a0[i0 & 3u] == (unsigned)((short)i0 > (signed char)(unsigned)h1)));
            *mp = 0x628e2216u;
        } else {
            case 4u: ;
            f0 = f0 * 0.5f + (float)(p0 & 255u);
            case 6u: ;
            w0 = w0 * 6364136223846793005ull + 0xdb484b62u;
        }
        if (((unsigned)((short)p2 > (signed char)*mp) << (u2 & 31u))) {
            while (i0++ < 5u && g0) { if (--fuel == 0u) goto done;
                case 5u: ;
                s0 = (int)((unsigned)d0 + ((unsigned)e0 ^ u1));
                case 0u: ;
                switch ((5u * ((unsigned)h0 % (u0 | 1u))) & 7u) {
                    case 7u: ;
                    if (*q0) goto L0;
                    d0 = d0 * 0.5 + (double)((((*mp & 0x10000u) ^ (unsigned)(x0 >> 70)) + ((unsigned)(w0 >> 29) % (a0[u1 & 3u] | 1u))) & 1023u);
                    case 2u: ;
                    case 0u: ;
                }
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (0x10000u) goto L1;
                }
                w0 ^= (unsigned long long)((unsigned)s1 / (m0 | 1u)) << ((unsigned)(i0 == g1) & 63u);
            }
            default: ;
            u2 ^= (0xfb26d985u ? (p0 / (i1 | 1u)) : v0);
        } else {
            break;
            u0 = (*mp / (a0[i0 & 3u] | 1u));
        }
        goto done;
    }
    if (u3 == 7u) return (unsigned)(0x10000u < u2);
    if ((unsigned)((unsigned)h1 == 0x7fffffffu)) goto L0;
    goto L3;
    if (0xd39339e6u) goto L0;
    if (u2) {
        m0 ^= (unsigned)((u2 ? u0 : (unsigned)(x0 >> 70)) || m0);
        goto L0;
        d0 = d0 * 0.5 + (double)((fuel * 2u) & 1023u);
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)((int)(unsigned)!(0xe8648384u * 8u) < (int)~(unsigned)(i0 && i0));
        }
        while (i0++ < 7u && (unsigned)s1) { if (--fuel == 0u) goto done;
            break; (void)(5u);
            c1 = (signed char)v0;
        }
    }
    switch (v0 & 7u) {
        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)f0 == (0xffffffffu | (unsigned)(g0 < p0)));
        x0 = x0 * 0x100000001b3ull + (unsigned)((short)~(unsigned)(i0 == 0xf87d529au) > (signed char)m0);
        s0 = (int)(i0 - (unsigned)(x0 >> 70));
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)(x0 >> 70) & 7u) {
                c1 = (signed char)(unsigned)((short)r0.y > (signed char)(unsigned)((unsigned)!(unsigned)((int)0x80000000u >= (int)p1) == p0));
                { unsigned t12; double z12; if (((unsigned)(0x80000000u < a0[u1 & 3u])) & 1u) { t12 = (unsigned)(g0 || (unsigned)d0); z12 = (double)((~((unsigned)w0 ^ (unsigned)((int)(unsigned)c0 < (int)(unsigned)h0))) & 255u); } if (((unsigned)(0x80000000u < a0[u1 & 3u])) & 1u) { u1 += t12; d0 = d0 * 0.5 + z12; }
                    case 4u: ;
                    v0 = (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)(w0 >> 29));
                    goto L1;
                    g0 = (0x7fffffffu + (unsigned)b0);
                }
            }
            u3 = (unsigned)(u2 || garr[u2 & 7u]);
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 7u: ;
            }
            f0 = f0 * 0.5f + (float)(((r0.y | ((unsigned)e0 ^ 7u)) >> (r0.x & 31u)) & 255u);
        }
        case 3u: ;
        r0.y ^= (((unsigned)s0 - 0x10000u) / ((garr[i1 & 7u] ^ i1) | 1u));
    }
    r0.x = (((a0[u1 & 3u] | (p0 ^ u2)) % ((unsigned)w0 | 1u)) / (*mp | 1u));
    g0 = ((unsigned)f0 << ((unsigned)(unsigned char)(0x9d56a139u & -(unsigned)((unsigned)b0 < (unsigned)!(0x59adda18u ^ (unsigned)c1))) & 31u));
    r0.x = (unsigned)!(5u - (g1 + (0x1034955du * 0xc692977au)));
    c0 = (unsigned char)((unsigned)(~(0xe9e607fdu / ((g1 / (a0[i0 & 3u] | 1u)) | 1u)) == (unsigned)w0) + (unsigned)b0);
    if ((unsigned)((short)garr[u2 & 7u] > (signed char)(a0[i0 & 3u] & 0xffffffffu))) {
        if ((unsigned)s0) {
            if ((i2 ? i1 : (unsigned)l0)) goto L3;
            goto done;
        } else {
            u0 += (unsigned)(i2 < a0[i0 & 3u]);
        }
        if ((unsigned)(a0[i0 & 3u] == 0xffffffffu)) goto L4;
        a0[(0xffffffffu | 0x7fffffffu) & 3u] = 0x1b6155aau;
    }
    g0 = ((unsigned)((int)(unsigned)(w0 >> 29) < (int)a0[u1 & 3u]) ^ i2);
    garr[garr[i1 & 7u] & 7u] = (unsigned)(0xffffffffu && (unsigned)d0);
    q0 = &garr[i0 & 7u];
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    r0.x = (g0 - (~((unsigned)w0 % ((unsigned)w0 | 1u)) % ((unsigned)(x0 >> 70) | 1u)));
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(0xc10203d6u == garr[i1 & 7u])) {
            if ((unsigned)h0) {
                while (i1++ < 5u && (unsigned)(signed char)(unsigned)((unsigned)c0 || (unsigned)s1)) { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)c0, 0xe824617cu, (unsigned)l0); }
                        garr[(5u << ((unsigned)c0 & 31u)) & 7u] = (a0[u1 & 3u] >> ((unsigned)((unsigned)h1 || 0xffffffffu) & 31u));
                        m0 ^= (unsigned)(p0 == ((unsigned)b0 & u0));
                        h1 = (unsigned short)(h1 + r0.x);
                        u2 = (unsigned)(short)(((unsigned)c0 ? (unsigned)s0 : (*mp | 0x7fffffffu)) >> ((unsigned)l0 & 31u));
                        if (0x80000000u) break;
                    }
                    u0 += u1;
                    { unsigned t0; double z0; if ((0x792d9ffbu) & 1u) { t0 = (unsigned)((int)(4u / (0x10000u | 1u)) < (int)4u); z0 = (double)(((unsigned)(g1 < ((unsigned)c1 + 5u))) & 255u); } if ((0x792d9ffbu) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                        continue; (void)(*mp);
                    }
                    if (((u0 + a0[u1 & 3u]) | p2)) break;
                    break; (void)((a0[u1 & 3u] ^ (g1 / (m0 | 1u))));
                    if ((v0 - 9u)) goto L1;
                }
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + ((unsigned)!(unsigned)((int)0x9630a3cfu < (int)r0.x) ^ (0x8a34b4d5u | (unsigned)((int)(unsigned)d0 >= (int)u2)));
                }
            }
            e0 = e0 * 0.5L + (long double)((unsigned)e0 & 1023u);
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(p2 || u0) << (0xffffffffu & 31u)), (m0 - r0.x), 0xffffffffu); }
            do { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)(i1 < (unsigned)(w0 >> 29));
                e0 = e0 * 0.5L + (long double)(((unsigned)((unsigned)(w0 >> 29) && (unsigned)l0) << (((unsigned)w0 ? r0.y : (unsigned)c1) & 31u)) & 1023u);
                u2 = (unsigned)((0xffffffffu ? u2 : (p1 % (garr[i1 & 7u] | 1u))) || garr[u2 & 7u]);
                q0 = &garr[((r0.x - (unsigned)(0x7fffffffu || *q0)) / (((unsigned)(x0 >> 70) << ((unsigned)f0 & 31u)) | 1u)) & 7u];
            } while (i1++ < 5u && u2);
            switch (8u & 7u) {
                L0: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((0x7fffffffu - u0), 0x9a88a812u, (u3 / (i0 | 1u))); }
                break; (void)((unsigned)((int)(unsigned)s1 >= (int)garr[i1 & 7u]));
                while ((unsigned)(0x10000u && 0xe2238e37u)) { if (--fuel == 0u) goto done;
                    if (((unsigned)w0 % ((unsigned)(*mp < 0u) | 1u))) continue;
                    u1 = ((r0.x + (unsigned)s1) >> ((v0 / (((unsigned)(x0 >> 70) * (unsigned)b0) | 1u)) & 31u));
                    x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)s1 < (int)(i2 % ((0x962a6d08u >> (0xffffffffu & 31u)) | 1u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(2u && 0x7d97d4d0u), p0, (unsigned)(w0 >> 29)); }
                    for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        q0 = &garr[((unsigned)e0 ^ 0x4dca41e9u) & 7u];
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(4u | *q0) < (int)(unsigned)f0), (garr[u2 & 7u] >> ((unsigned)b0 & 31u)), i0); }
                        r0.x = 0x10000u;
                        w0 ^= (unsigned long long)0x80000000u << ((3u & r0.x) & 63u);
                        if ((unsigned)c1) break;
                        case 5u: ;
                    }
                }
            }
        }
        if (0x96dc995bu) break;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + u0);
            if (0x80000000u) continue;
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)b0;
                s0 = (int)(unsigned)((unsigned)!(unsigned)(4u < 0x80000000u) == ((unsigned)w0 / ((unsigned)s1 | 1u)));
            }
            if (((unsigned)h1 >> (((unsigned)f0 / (p1 | 1u)) & 31u))) continue;
        }
        *q0 = i0;
    }
    switch (((unsigned)(x0 >> 70) ? garr[i1 & 7u] : (unsigned)b0) & 7u) {
        if ((unsigned)((short)(unsigned)s0 > (signed char)0x374254du)) {
            u2 ^= ((u1 * (unsigned)h0) | 0xffffffffu);
            L1: if (--fuel == 0u) goto done;
        } else {
            if (garr[i1 & 7u]) {
                case 4u: ;
                { unsigned t1; double z1; if ((((unsigned)w0 / (0x80000000u | 1u))) & 1u) { t1 = a0[i0 & 3u]; z1 = (double)(((6u % ((unsigned)b0 | 1u))) & 255u); } if ((((unsigned)w0 / (0x80000000u | 1u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)h0 < (int)(unsigned)(unsigned char)(unsigned)(g1 < a0[u1 & 3u])) & 1023u);
                    if (((0x71ad6f0au * m0) - 0x80000000u)) {
                        if ((unsigned)((unsigned)l0 < (unsigned)e0)) break;
                        if (a0[i0 & 3u]) goto L4;
                    }
                    *mp = (0x55ff29d3u | (unsigned)((unsigned)((short)(unsigned)h1 > (signed char)p2) == u3));
                    u3 += (unsigned)(g1 < (unsigned)((int)-(unsigned)(0x78bfce49u || p1) < (int)0x5251e62u));
                    if (((unsigned)s1 & (unsigned)h0)) goto L0;
                    u0 ^= (i2 + garr[u2 & 7u]);
                }
                for (;;) { if (--fuel == 0u) goto done;
                    garr[(u2 >> (fuel & 31u)) & 7u] = -(0xe2b9307du ? (unsigned)h1 : p2);
                    break; (void)(-((unsigned)(unsigned char)((unsigned)c0 * 0x7328da7fu) * 0x6bcf2813u));
                    if ((*mp >> ((unsigned)(unsigned char)(i2 + 0x10000u) & 31u))) {
                        case 0u: ;
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s1, (0xebd597a0u / ((0x7fffffffu % (g1 | 1u)) | 1u)), (unsigned)((unsigned)((short)m0 > (signed char)g0) || u2)); }
                        w0 = w0 * 6364136223846793005ull + (unsigned)((int)((unsigned)x0 + (unsigned)x0) >= (int)(6u % ((unsigned)w0 | 1u)));
                    } else {
                        case 6u: ;
                    }
                }
                a0[(unsigned)(signed char)(unsigned)((unsigned)b0 < *mp) & 3u] = (u2 + -((i0 * *mp) << (0xe8efea1bu & 31u)));
            }
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                g1 += g1;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)(m0 == (unsigned)h1) == p2), (unsigned)(unsigned char)((unsigned)x0 >> (garr[u2 & 7u] & 31u)), (i1 ^ (unsigned)w0)); }
            }
        }
        while ((0x24b68be1u >> (-(unsigned)(0x9dfa27f4u || p2) & 31u))) { if (--fuel == 0u) goto done;
            r0.y ^= ~(((unsigned)c0 | (unsigned)e0) * p2);
            default: ;
            for (;;) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(signed char)(unsigned)(u0 && r0.y));
                q0 = &garr[((unsigned)(x0 >> 70) * a0[i0 & 3u]) & 7u];
                if ((unsigned)((int)(unsigned)(*mp == v0) >= (int)i0)) break;
                x0 = x0 * 0x100000001b3ull + ((0xe846733du >> (v0 & 31u)) / (6u | 1u));
                b0 = (unsigned)(x0 >> 70) != 0u;
                a0[((unsigned)w0 / (i1 | 1u)) & 3u] = (*q0 / ((9u ? fuel : 0x80000000u) | 1u));
            }
            break;
        }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0(*mp, (unsigned)((unsigned)c1 < (unsigned)f0), 0xffffffffu); }
    for (;;) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)s0 && i2)) break;
        }
    }
    r0.x = (unsigned)!(*q0 >> ((8u | (unsigned)((int)(unsigned)(w0 >> 29) >= (int)fuel)) & 31u));
    m0 ^= ((unsigned)(x0 >> 70) - (i1 % (p0 | 1u)));
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((i1 >> (r0.x & 31u))) break;
    }
    u2 = (unsigned)((int)(unsigned)e0 >= (int)(unsigned)(v0 < (unsigned)(unsigned char)(unsigned)((int)0x7fffffffu < (int)(unsigned)(w0 >> 29))));
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)(short)(g0 - (m0 + 0u)));
        u0 ^= (unsigned)x0;
        if (p0) break;
    }
    do { if (--fuel == 0u) goto done;
        v0 = (unsigned)((int)-(unsigned)((((unsigned)c1 + a0[u1 & 3u]) | 8u) == v0) >= (int)g0);
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)h1 && (unsigned)c0)) break;
            L2: if (--fuel == 0u) goto done;
            if (v0) break;
        }
        if (((unsigned)c1 << ((unsigned)s0 & 31u))) {
            switch ((0x80000000u - (unsigned)(unsigned char)(*mp + a0[i0 & 3u])) & 7u) {
                { unsigned t2; double z2; if (((unsigned)l0) & 1u) { t2 = fuel; z2 = (double)((5u) & 255u); } if (((unsigned)l0) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    u0 = ((unsigned)((int)(unsigned)b0 < (int)u2) >> ((unsigned)((int)4u < (int)5u) & 31u));
                    r0.y ^= (((unsigned)c1 / (((unsigned)h0 & *mp) | 1u)) & i2);
                    if (3u) {
                        w0 = w0 * 6364136223846793005ull + (r0.x ^ (unsigned)((int)p0 < (int)m0));
                        if ((unsigned)((int)i2 >= (int)(unsigned)h1)) break;
                        m0 ^= (r0.x * a0[u1 & 3u]);
                        w0 ^= (unsigned long long)((unsigned)c1 ^ garr[i1 & 7u]) << ((0x10000u & (unsigned)!(unsigned)((int)(unsigned)d0 < (int)(0x4b927631u & v0))) & 63u);
                    } else {
                        L3: if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)((unsigned)w0 & 1023u);
                        h1 = (unsigned short)(h1 + (unsigned)(garr[i1 & 7u] || (unsigned)!(garr[u2 & 7u] & 0x54cdc34cu)));
                    }
                    if (a0[i0 & 3u]) continue;
                    s1 = (int)((unsigned)s1 + ((m0 + p1) << (p2 & 31u)));
                }
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((0x7fffffffu << ((unsigned)(w0 >> 29) & 31u)), (unsigned)((short)(0x7a531740u % ((unsigned)s1 | 1u)) > (signed char)0xcf4a7d4u), (unsigned)((short)(unsigned)x0 > (signed char)(unsigned)((short)i1 > (signed char)*mp))); }
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)((r0.x ^ fuel) * (unsigned)(signed char)(u3 >> ((unsigned)b0 & 31u)));
                x0 = x0 * 0x100000001b3ull + i2;
                { unsigned t3; double z3; if (((unsigned)((short)u2 > (signed char)0x6cbe14ceu)) & 1u) { t3 = ((unsigned)b0 & g1); z3 = (double)((u3) & 255u); } if (((unsigned)((short)u2 > (signed char)0x6cbe14ceu)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    if (p2) goto L4;
                    if ((unsigned)(r0.y == (garr[u2 & 7u] + a0[u1 & 3u]))) break;
                    *q0 = (unsigned)f0;
                    *q0 = ((unsigned)((*mp & *q0) == u0) | ~(unsigned)(1u || *mp));
                    c1 = (signed char)(u3 / ((unsigned)(unsigned char)(garr[i1 & 7u] ^ ((unsigned)c1 >> (g0 & 31u))) | 1u));
                    continue; (void)((p1 - g1));
                }
                d0 = d0 * 0.5 + (double)(~(g0 * ((unsigned)w0 % (((unsigned)b0 % ((0x80000000u - *mp) | 1u)) | 1u))) & 1023u);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(2u == fuel), ((unsigned)d0 + u2), (unsigned)!(unsigned)((0x80000000u >> (g0 & 31u)) || (unsigned)s0)); }
            if (((unsigned)x0 >> (8u & 31u))) {
                L4: if (--fuel == 0u) goto done;
                if ((a0[i0 & 3u] | i1)) break;
                if (u3 == 7u) return (r0.x * (unsigned)((int)garr[i1 & 7u] < (int)u3));
                while (i1++ < 6u && (unsigned)(signed char)(u1 % (p1 | 1u))) { if (--fuel == 0u) goto done;
                    if (i1) continue;
                }
                f0 = f0 * 0.5f + (float)(a0[u1 & 3u] & 255u);
                if (budget != 0u) { budget -= 1u; u2 = fn0(3u, (unsigned)((unsigned)((unsigned)h1 == (unsigned)h1) && i2), r0.y); }
            }
        }
    } while (i0++ < 2u && 0x10000u);
    if ((((unsigned)h0 * p2) % (garr[u2 & 7u] | 1u))) goto done;
    e0 = e0 * 0.5L + (long double)((unsigned)!((unsigned)(unsigned char)(unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)d0) << ((((unsigned)h0 / (p2 | 1u)) / (5u | 1u)) & 31u)) & 1023u);
    goto L4;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 ^= (unsigned)((unsigned)((short)(0x80000000u & g1) > (signed char)g0) == (unsigned)((short)(unsigned)x0 > (signed char)a0[i0 & 3u]));
    }
    for (;;) { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (unsigned)((int)((unsigned)w0 << ((unsigned)w0 & 31u)) >= (int)(unsigned)(signed char)(unsigned)((int)(unsigned)(0x80577e57u && (unsigned)(w0 >> 29)) >= (int)7u));
    }
    switch (4u & 7u) {
        do { if (--fuel == 0u) goto done;
            case 2u: ;
            r0.y ^= (0x2be43e7eu - (r0.y << (u0 & 31u)));
            v0 = ((unsigned)s0 | (-(unsigned)(9u && (unsigned)((short)0x89eb587cu > (signed char)m0)) - m0));
            case 4u: ;
            v0 = (~(unsigned)((int)i0 < (int)(unsigned)((int)9u >= (int)i2)) & (u0 * (unsigned)d0));
        } while (i0++ < 2u && ((unsigned)h1 | (fuel << (0x7fffffffu & 31u))));
    }
    goto L2;
    f0 = f0 * 0.5f + (float)(((unsigned)!(u1 >> (garr[u2 & 7u] & 31u)) >> (garr[i1 & 7u] & 31u)) & 255u);
    goto L4;
    d0 = d0 * 0.5 + (double)((unsigned)(p1 && 0x54ecb06du) & 1023u);
    do { if (--fuel == 0u) goto done;
        i0 = (unsigned)((short)(0xffffffffu + ((unsigned)x0 + (1u & 6u))) > (signed char)0x10000u) & 15u;
        if (fuel < 8u) return ((unsigned)((unsigned)(x0 >> 70) < 5u) % ((unsigned)((unsigned)(6u < u0) < 0x20243da7u) | 1u));
        u2 += (unsigned)!(0xeaa3e1ffu | (unsigned)((int)7u >= (int)(unsigned)f0));
    } while (i0++ < 7u && (unsigned)((int)(unsigned)h1 >= (int)((unsigned)w0 + p0)));
    r0.y ^= (unsigned)(a0[i0 & 3u] < u3);
    switch (8u & 7u) {
        case 5u: ;
        switch (((u2 / (a0[i0 & 3u] | 1u)) << (*q0 & 31u)) & 7u) {
            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((unsigned)(0x80000000u < v0) ^ (unsigned)e0);
            case 3u: ;
        }
    }
    if ((unsigned)((short)0x7fffffffu > (signed char)9u)) {
        m0 ^= ((unsigned)((unsigned)(signed char)(*mp * m0) < u2) + (unsigned)x0);
    }
    goto L1;
    goto L4;
    goto L3;
    switch ((p1 | ((unsigned)h1 ^ *q0)) & 7u) {
        f0 = f0 * 0.5f + (float)(((unsigned)(x0 >> 70) << ((unsigned)(unsigned char)(unsigned)((int)(i0 % ((unsigned)((short)(unsigned)d0 > (signed char)r0.x) | 1u)) >= (int)6u) & 31u)) & 255u);
    }
    c1 = (signed char)((unsigned)(i1 == (unsigned)((short)(unsigned)f0 > (signed char)(unsigned)((int)(unsigned)l0 >= (int)(unsigned)h0))) + 0x7fffffffu);
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + ((unsigned)(unsigned char)(unsigned)(p2 || 1u) << ((unsigned)h1 & 31u)));
        { unsigned t4; double z4; if (((0x892e67b6u ^ u3)) & 1u) { t4 = (unsigned)!(u2 % (9u | 1u)); z4 = (double)(((unsigned)(a0[i0 & 3u] == 3u)) & 255u); } if (((0x892e67b6u ^ u3)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            b0 = (unsigned)(garr[u2 & 7u] == (unsigned)e0) != 0u;
            q0 = &garr[(unsigned)((unsigned)((int)0xffffffffu >= (int)(0x7fffffffu + u0)) == (unsigned)((int)*mp < (int)0x10000u)) & 7u];
            u0 = ((unsigned)c1 >> (0xe03feb57u & 31u));
        }
        if ((p0 ? r0.x : 0x7fffffffu)) goto L2;
        switch ((unsigned)((int)0x41b5d18fu >= (int)0x719cdd33u) & 7u) {
            *q0 += (unsigned)((short)~(p0 - *q0) > (signed char)v0);
            case 6u: ;
            i0 = (unsigned)(((0x4a81b9e3u ^ (unsigned)h0) ^ 0x2c2c0623u) < (unsigned)(u0 && (unsigned)d0)) & 15u;
            c1 = (signed char)garr[u2 & 7u];
            if (budget != 0u) { budget -= 1u; u3 = fn0((0xffffffffu - (unsigned)b0), r0.x, (unsigned)((int)0x80000000u >= (int)(unsigned)((int)(unsigned)h0 < (int)g0))); }
            l0 = (long)((unsigned long)l0 + ((garr[u2 & 7u] ^ 3u) / ((p0 >> ((unsigned)w0 & 31u)) | 1u)));
        }
        while (i1++ < 4u && (unsigned)((unsigned)d0 || 2u)) { if (--fuel == 0u) goto done;
            if ((unsigned)!(unsigned)(0x2eb4393fu < *q0)) continue;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0x80000000u && r0.y), (unsigned)s1, 9u); }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(~(unsigned)((unsigned)(w0 >> 29) || (u1 - i2)), (7u >> (p2 & 31u)), (((unsigned)s1 << (*q0 & 31u)) % (0xb2bc9153u | 1u))); }
    }
    if ((unsigned)(signed char)(unsigned)((2u ^ a0[i0 & 3u]) == p1)) goto L0;
    goto L1;
    g1 += 0u;
    b0 = (unsigned)(9u == (0x10000u >> (~(unsigned)((int)u0 >= (int)garr[u2 & 7u]) & 31u))) != 0u;
    i0 = (p2 | garr[u2 & 7u]) & 15u;
    if (fuel < 8u) return (u3 * (unsigned)!(0x1c730893u << ((0xc90f2f29u + (unsigned)d0) & 31u)));
    v0 = -(unsigned)((short)(0xff72292bu >> ((0xbb9f816eu + 0x80000000u) & 31u)) > (signed char)(a0[i0 & 3u] >> ((unsigned)e0 & 31u)));
    do { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (unsigned)s0;
        do { if (--fuel == 0u) goto done;
            garr[(unsigned)(short)(4u | i2) & 7u] = (unsigned)((0u | 0x3fe1f399u) == p1);
            if (budget != 0u) { budget -= 1u; u0 = fn0(p1, (unsigned)((short)(unsigned)(g0 == 0x80000000u) > (signed char)*q0), ((0x46cfdcf3u * (unsigned)f0) & 0xd16f8698u)); }
            if ((a0[i0 & 3u] >> ((unsigned)((unsigned)w0 && 2u) & 31u))) {
                v0 = (unsigned)((unsigned)(w0 >> 29) < 0x10000u);
                if (budget != 0u) { budget -= 1u; u0 = fn0(a0[u1 & 3u], (unsigned)(3u < (p1 >> (0xffffffffu & 31u))), v0); }
                break; (void)(i2);
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((int)0x10000u >= (int)(unsigned)d0) & u1), 0xa0f297a7u, (unsigned)b0); }
            }
            if (u3 == 7u) return ((((unsigned)w0 >> (m0 & 31u)) << (r0.y & 31u)) ^ 0xc9f21dfeu);
            if (p1) break;
            switch ((unsigned)(short)(unsigned)((unsigned)x0 || 0xeeb82219u) & 7u) {
                if ((u3 & 0x2346694fu)) continue;
                i2 = (unsigned)(x0 >> 70) & 15u;
            }
        } while (i1++ < 3u && (0x80000000u ^ p0));
    } while (i0++ < 6u && (unsigned)(((unsigned)s0 >> (0x22284183u & 31u)) && i1));
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)((unsigned)c1 < -(garr[u2 & 7u] & ((0x7fffffffu - p1) | (unsigned)b0)));
        if (garr[u2 & 7u]) goto done;
        x0 = x0 * 0x100000001b3ull + (unsigned)(p2 < (i2 | i1));
        if ((unsigned)c0) break;
    }
    r0.x = (i0 & fuel);
    g1 += (unsigned)((short)4u > (signed char)u0);
    r0.y ^= 5u;
    if (((unsigned)!((unsigned)l0 % (0x983eec5bu | 1u)) / ((unsigned)f0 | 1u))) goto L4;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)s1) goto L4;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0(*q0, r0.y, (unsigned)!((0xa86ca2c5u * fuel) + (unsigned)s1)); }
            while (i2++ < 4u && (unsigned)((int)0x3d251bdau >= (int)0x9e3eaf3fu)) { if (--fuel == 0u) goto done;
                if (u0) {
                    e0 = e0 * 0.5L + (long double)((unsigned)!(((unsigned)c0 ? 3u : 1u) & i2) & 1023u);
                    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(0x2502b66cu == garr[u2 & 7u]) & p2), -(unsigned)(g1 < u2), (unsigned)((int)(fuel + 8u) >= (int)0xc015d573u)); }
                        s0 = (int)(unsigned)(x0 >> 70);
                        garr[((unsigned)s0 - 0x10000u) & 7u] = (unsigned)(short)(u3 * (unsigned)c0);
                        h0 = (short)(4u * (-(0x97d0cfbfu ? garr[i1 & 7u] : p2) % ((unsigned)x0 | 1u)));
                    }
                    f0 = f0 * 0.5f + (float)((unsigned)((short)0x10000u > (signed char)(unsigned)(0x10000u < 0xd50ee0a1u)) & 255u);
                    c1 = (signed char)(fuel * (unsigned)w0);
                    c0 = (unsigned char)((unsigned)f0 << (((unsigned)c1 ^ i2) & 31u));
                }
            }
            if ((0x3f99f1b1u >> (0xa607271fu & 31u))) {
                s0 = (int)((unsigned)h1 ? 0x2c57d971u : (unsigned)((int)(unsigned)c1 < (int)r0.x));
                goto done;
            }
            u3 += (-(unsigned)((short)a0[i0 & 3u] > (signed char)p1) % (-(u3 & 0x318fde14u) | 1u));
            if ((m0 ^ ((unsigned)d0 ^ 0x7fffffffu))) {
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(0x98b797eeu && *mp)) break;
                    if ((unsigned)f0) break;
                }
                *q0 = ((unsigned)x0 & u3);
                if (p2) break;
            }
        } while (i1++ < 5u && (unsigned)l0);
        for (;;) { if (--fuel == 0u) goto done;
            if (((unsigned)h1 % ((v0 >> (0x7fffffffu & 31u)) | 1u))) break;
            s1 = (int)((unsigned)s1 + ~(unsigned)(p0 && (*mp % (1u | 1u))));
            switch (0x5606e65bu & 7u) {
                q0 = &garr[(unsigned)((int)(0x6745338eu | g1) >= (int)0x4fc5e522u) & 7u];
                case 2u: ;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((p0 ? i1 : (unsigned)(x0 >> 70)), ((unsigned)c0 / (r0.y | 1u)), (unsigned)((unsigned)w0 && (garr[u2 & 7u] ^ 0x3e206ab6u))); }
        }
        if ((unsigned)b0) {
            if ((garr[i1 & 7u] ^ (unsigned)x0)) break;
            h1 = (unsigned short)(h1 + (unsigned)(0x83449f83u < (unsigned)((unsigned)s0 || (0x80000000u ^ (unsigned)h1))));
            if ((unsigned)((short)i1 > (signed char)(unsigned)h1)) {
                if ((unsigned)(short)((unsigned)h1 + *q0)) break;
                e0 = e0 * 0.5L + (long double)(((garr[i1 & 7u] | ((unsigned)(w0 >> 29) ^ a0[u1 & 3u])) >> ((unsigned)(w0 >> 29) & 31u)) & 1023u);
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)f0, 4u, (unsigned)(unsigned char)((unsigned)e0 & u0)); }
                h0 = (short)(unsigned)((int)0u < (int)(unsigned)l0);
                if (budget != 0u) { budget -= 1u; u1 = fn0(0x7fffffffu, (unsigned)(5u && ((unsigned)h0 >> ((unsigned)b0 & 31u))), (unsigned)((g1 % ((unsigned)s0 | 1u)) && (unsigned)e0)); }
            } else {
                q0 = &garr[i0 & 7u];
            }
            if (fuel < 8u) return (unsigned)((int)(unsigned)(u0 && (unsigned)d0) >= (int)(u0 * garr[u2 & 7u]));
            h1 = (unsigned short)(h1 + -(unsigned)(v0 < (i2 | 0xffffffffu)));
            i2 = ((g1 + 0x10000u) ^ ((i0 >> (i2 & 31u)) / (g0 | 1u))) & 15u;
        } else {
            w0 = w0 * 6364136223846793005ull + ((unsigned)((unsigned)h1 < (unsigned)(x0 >> 70)) ^ (unsigned)s0);
        }
        if (((unsigned)(i2 || garr[i1 & 7u]) / (p0 | 1u))) break;
        break; (void)(((0x540404f9u + p2) + i1));
    }
    h0 = (short)(unsigned)((short)((unsigned)((int)(r0.x - 0x80000000u) >= (int)g0) | (unsigned)x0) > (signed char)0x4d2a69fcu);
    goto L2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    u2 += (m0 ? (unsigned)c0 : p2);
    v0 = (-(unsigned)((int)(unsigned)s1 < (int)(unsigned)w0) + (i1 ? 6u : 0x420317au));
    w0 ^= (unsigned long long)(unsigned)((short)(unsigned)l0 > (signed char)v0) << ((g0 ^ 0x7fffffffu) & 63u);
    if (r0.y) goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn1((0x10000u ? 0x80000000u : 0xb5ce108u), (unsigned)((int)0x24eb9192u < (int)u0), (m0 - r0.x)); }
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(0x86745b1cu || 9u), ((9u - 0xb430086eu) % (0u | 1u)), (unsigned)((short)g0 > (signed char)0x80000000u)); }
    if (((0x755b7e82u & u1) & (unsigned)c1)) goto L3;
    e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)f0 < (unsigned)s0) & 1023u);
    u1 += (unsigned)((unsigned)((0x10000u & (unsigned)b0) == 0xb6bdac97u) == (unsigned)(w0 >> 29));
    switch ((5u << (((unsigned)d0 ^ (unsigned)c1) & 31u)) & 7u) {
        { unsigned t0; double z0; if ((u2) & 1u) { t0 = u3; z0 = (double)((r0.x) & 255u); } if ((u2) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            c0 = (unsigned char)(unsigned)((u0 ^ fuel) || (unsigned)((short)(unsigned)h0 > (signed char)garr[i1 & 7u]));
            if (fuel < 8u) return (6u % ((fuel ? (unsigned)w0 : 0xae2bab30u) | 1u));
            if ((0xffffffffu ^ (unsigned)s0)) goto done;
            garr[i1 & 7u] = ((0u ^ u0) / (0x32ef373cu | 1u));
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(p0 | (unsigned)h1) << (fuel & 63u);
                    L0: if (--fuel == 0u) goto done;
                    if (9u) continue;
                    e0 = e0 * 0.5L + (long double)((unsigned)!(((unsigned)d0 - (unsigned)s0) ^ (i1 - (*mp | 6u))) & 1023u);
                    if ((u2 & (unsigned)(x0 >> 70))) break;
                } while (i1++ < 7u && (unsigned)c0);
                if (budget != 0u) { budget -= 1u; u2 = fn0(0x10000u, (0x3a8ce777u & fuel), (unsigned)d0); }
            }
        }
        if ((unsigned)(short)(0x10000u / (0xaa9357c0u | 1u))) {
            b0 = (unsigned)(signed char)(unsigned)((int)p0 < (int)(unsigned)(x0 >> 70)) != 0u;
            *mp = (u2 | p2);
            while (i0++ < 4u && ~((unsigned)l0 >> ((0xffffffffu ^ garr[u2 & 7u]) & 31u))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1((0xbea4f3a8u << (0x10000u & 31u)), ((unsigned)((int)r0.y < (int)(unsigned)c0) / (0xf089ee06u | 1u)), ((unsigned)x0 | (a0[i0 & 3u] ^ v0))); }
                w0 = w0 * 6364136223846793005ull + (unsigned)(a0[u1 & 3u] || ((unsigned)w0 % (g0 | 1u)));
                g0 = ((g1 & ((unsigned)h0 / (p1 | 1u))) ^ (p1 / (0xffffffffu | 1u)));
                m0 ^= (unsigned)(signed char)(i0 << (-((unsigned)e0 / (m0 | 1u)) & 31u));
                if (budget != 0u) { budget -= 1u; u2 = fn0((m0 + (unsigned)c0), (unsigned)(short)((unsigned)x0 * (r0.y / (i2 | 1u))), 0x80000000u); }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)*mp < (int)r0.x), *q0, (i0 % (garr[i1 & 7u] | 1u))); }
            }
            { unsigned t1; double z1; if ((-(unsigned)((unsigned)c0 == garr[i1 & 7u])) & 1u) { t1 = (0xaf59dfc4u % ((unsigned)b0 | 1u)); z1 = (double)(((unsigned)((unsigned)((int)p2 < (int)r0.x) && (unsigned)d0)) & 255u); } if ((-(unsigned)((unsigned)c0 == garr[i1 & 7u])) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                a0[(unsigned)(*q0 && g0) & 3u] = ((unsigned)((unsigned)s0 < (unsigned)((unsigned)b0 && r0.y)) - 0xfac4ad1fu);
                if (((unsigned)((short)garr[i1 & 7u] > (signed char)a0[u1 & 3u]) - (unsigned)l0)) break;
                *q0 = ((unsigned)(i1 == 3u) % (p1 | 1u));
                do { if (--fuel == 0u) goto done;
                    u0 = (unsigned)(0xbfb49be2u == (unsigned)!(unsigned)((unsigned)(signed char)(unsigned)((int)9u >= (int)(unsigned)w0) < (unsigned)((unsigned)b0 < garr[u2 & 7u])));
                    c0 = (unsigned char)0x10000u;
                    e0 = e0 * 0.5L + (long double)((unsigned)s1 & 1023u);
                    x0 = x0 * 0x100000001b3ull + (0x80000000u * i0);
                    b0 = (unsigned)(((unsigned)d0 ? (unsigned)((int)0x80000000u >= (int)(unsigned)e0) : garr[i1 & 7u]) || *mp) != 0u;
                } while (i0++ < 5u && a0[i0 & 3u]);
                if ((unsigned)(short)(g1 % (r0.x | 1u))) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0(u1, (unsigned)(v0 && (unsigned)(i0 && 5u)), ((a0[u1 & 3u] + (unsigned)s1) | p1)); }
                    h0 = (short)((1u | m0) * 0x7fffffffu);
                    do { if (--fuel == 0u) goto done;
                        case 0u: ;
                        g0 = (unsigned)((int)(unsigned)(a0[u1 & 3u] || u1) >= (int)((unsigned)l0 ^ (u0 + 0x62434086u)));
                    } while (i0++ < 4u && (unsigned)(g1 && (unsigned)c0));
                    v0 = (unsigned)((int)g1 < (int)(unsigned)s1);
                    do { if (--fuel == 0u) goto done;
                        switch (((unsigned)(short)(0x21cc572bu / ((unsigned)s0 | 1u)) / (u3 | 1u)) & 7u) {
                            L1: if (--fuel == 0u) goto done;
                        }
                        L2: if (--fuel == 0u) goto done;
                        b0 = (unsigned)(g0 == ((unsigned)((short)u2 > (signed char)((unsigned)h0 / (0xc777ac3eu | 1u))) << (0xffffffffu & 31u))) != 0u;
                        goto L0;
                    } while (i0++ < 6u && 0x5c20d62eu);
                }
                u1 ^= (unsigned)f0;
            }
        }
    }
    L3: if (--fuel == 0u) goto done;
    L4: if (--fuel == 0u) goto done;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)c0 * (i0 / (0x33aa8fffu | 1u)))) {
            if (0xdaee9e35u) break;
            if ((unsigned)((short)i1 > (signed char)u3)) {
                m0 ^= (unsigned)((int)(unsigned)(0u || 0xffffffffu) < (int)(unsigned)l0);
                { unsigned t2; double z2; if (((p2 * (unsigned)(a0[u1 & 3u] < 0x10000u))) & 1u) { t2 = r0.y; z2 = (double)(((-(0xffffffffu ^ (unsigned)w0) % (0xffffffffu | 1u))) & 255u); } if (((p2 * (unsigned)(a0[u1 & 3u] < 0x10000u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(((unsigned)w0 * (unsigned)(u2 < (unsigned)(w0 >> 29))) ^ r0.x));
                    switch ((unsigned)x0 & 7u) {
                        u0 ^= (unsigned)(0x90ad686u && (unsigned)(w0 >> 29));
                        *q0 += -(unsigned)((unsigned)((int)(m0 % (p2 | 1u)) < (int)a0[u1 & 3u]) < (unsigned)(x0 >> 70));
                        a0[(unsigned)((short)r0.y > (signed char)(unsigned)c1) & 3u] = (unsigned)!(unsigned)((unsigned)((unsigned)(x0 >> 70) < (unsigned)b0) || ((unsigned)c1 ^ v0));
                    }
                    break; (void)(u0);
                }
                switch ((unsigned)(unsigned char)((r0.y ^ u2) << (m0 & 31u)) & 7u) {
                    *mp = g1;
                    h0 = (short)-(((unsigned)l0 >> ((unsigned)s0 & 31u)) / (p1 | 1u));
                    u2 = -(m0 % ((unsigned)x0 | 1u));
                    case 5u: ;
                }
            }
            if ((unsigned)(unsigned char)(unsigned)((unsigned)h0 && (unsigned)((int)(unsigned)s1 < (int)(unsigned)w0))) break;
            *q0 = (unsigned)((int)u3 < (int)0x10000u);
        } else {
            if (fuel < 8u) return (*q0 % (-(unsigned)(0x220ea4b6u || (unsigned)((short)(unsigned)w0 > (signed char)0x3b07f2ddu)) | 1u));
            if ((garr[u2 & 7u] | (unsigned)l0)) break;
            if ((m0 ^ ((unsigned)c0 ^ m0))) goto L1;
            r0.x = (unsigned)(short)(garr[i1 & 7u] ^ (unsigned)((int)0x80000000u >= (int)5u));
        }
        *q0 = ((unsigned)(((unsigned)(w0 >> 29) >> ((unsigned)s1 & 31u)) == (unsigned)w0) - (unsigned)c0);
        while (i1++ < 4u && -(0xfb3cb992u * (unsigned)c0)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)f0 == i1), (unsigned)((int)(unsigned)(x0 >> 70) < (int)0x244082fau), (*mp << ((unsigned)w0 & 31u))); }
            if (garr[u2 & 7u]) {
                g1 += ((unsigned)((short)0xffffffffu > (signed char)garr[u2 & 7u]) - (unsigned)(((unsigned)e0 * u0) == 3u));
                *mp = ((unsigned)((short)u2 > (signed char)(unsigned)((int)(unsigned)d0 >= (int)(v0 % ((unsigned)(w0 >> 29) | 1u)))) / (u1 | 1u));
            }
            if (u3 == 7u) return ~(unsigned)(*q0 < u2);
        }
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            *q0 = ((unsigned)((short)fuel > (signed char)a0[u1 & 3u]) << ((unsigned)((int)a0[u1 & 3u] < (int)u2) & 31u));
            while (i2++ < 7u && (unsigned)d0) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (r0.y & (unsigned)((short)p1 > (signed char)(unsigned)(6u == (unsigned)(x0 >> 70))));
                i0 = ((unsigned)((int)garr[u2 & 7u] < (int)0xe1a4755fu) >> (u3 & 31u)) & 15u;
                if (0xb65c05f5u) break;
            }
        }
        if ((9u >> ((0xffffffffu % (p1 | 1u)) & 31u))) break;
    }
    q0 = &garr[(unsigned)((7u ? *mp : a0[u1 & 3u]) && garr[i1 & 7u]) & 7u];
    if (((unsigned)h0 << (-(p2 | (unsigned)(x0 >> 70)) & 31u))) goto L2;
    if ((((unsigned)h1 >> ((unsigned)l0 & 31u)) << ((unsigned)x0 & 31u))) goto L4;
    { unsigned t3; double z3; if ((i1) & 1u) { t3 = ((unsigned)(x0 >> 70) / ((unsigned)((int)i2 < (int)v0) | 1u)); z3 = (double)(((unsigned)(unsigned char)(6u & (unsigned)h1)) & 255u); } if ((i1) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        switch (((unsigned)d0 | (unsigned)c0) & 7u) {
            garr[garr[i1 & 7u] & 7u] = (((unsigned)f0 * p2) >> ((0xc08766e7u + 0x80000000u) & 31u));
            e0 = e0 * 0.5L + (long double)((-(unsigned)((short)0x82c0f273u > (signed char)0x36375caau) - (unsigned)(unsigned char)(0x26fe6f39u * (garr[i1 & 7u] % (p0 | 1u)))) & 1023u);
            case 2u: ;
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(5u || 0x10000u), i0, (unsigned)((unsigned)((short)0xe75ef083u > (signed char)6u) < 0xbb406433u)); }
            }
        }
    }
    if (0x10000u) goto L3;
    g0 = (unsigned)((unsigned)(0x7b77d876u == (unsigned)h1) || p1);
    f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)((unsigned)(fuel == (unsigned)h0) && *mp) >= (int)g0) & 255u);
    i1 = (unsigned)(p0 && (unsigned)l0) & 15u;
    w0 = w0 * 6364136223846793005ull + (unsigned)(-(unsigned)(*mp || (unsigned)d0) < (unsigned)(signed char)(0x983c5496u ^ p2));
    u2 += u1;
    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)(p1 == (unsigned)c0) & 1023u);
    if (budget != 0u) { budget -= 1u; u2 = fn0(garr[i1 & 7u], (unsigned)(r0.x == (unsigned)h1), (unsigned)f0); }
    while (i0++ < 7u && ((7u ^ (unsigned)l0) & m0)) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)(-(v0 / (((unsigned)((unsigned)h0 && (unsigned)(signed char)(0x234448e9u - 7u)) / ((unsigned)c0 | 1u)) | 1u)) & 1023u);
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + 0xb9477d0bu);
            if (fuel) continue;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn1(0xb706b263u, 3u, ((unsigned)(3u && g1) | (unsigned)x0)); }
            } while (i2++ < 3u && (unsigned)b0);
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((int)0x2b89f741u < (int)0x7fffffffu) + a0[i0 & 3u]), ~(u3 - i1), ((unsigned)b0 + i2)); }
        }
        if (((0x10000u + (unsigned)l0) + v0)) {
            w0 ^= (unsigned long long)(unsigned)(0xffffffffu == u0) << (((1u | p1) & m0) & 63u);
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)w0)) goto done;
                w0 ^= (unsigned long long)(unsigned)!(unsigned)(p0 && u1) << ((unsigned)((int)i0 < (int)(0x31662edbu & u0)) & 63u);
                if ((1u & (m0 / ((unsigned)f0 | 1u)))) goto L0;
                if ((unsigned)c0) break;
            } while (i1++ < 7u && (*mp + p0));
            l0 = (long)((unsigned long)l0 + (unsigned)((0x80000000u | (((unsigned)(x0 >> 70) >> (0x445e3b84u & 31u)) / ((unsigned)x0 | 1u))) < 1u));
            h0 = (short)~((unsigned)(unsigned char)((*q0 * 0xa5fb93a9u) / (0x80000000u | 1u)) % (0xc3333398u | 1u));
        } else {
            s0 = (int)(unsigned)((unsigned)((unsigned)h1 && m0) && ((unsigned)c0 >> ((unsigned)s0 & 31u)));
            if (budget != 0u) { budget -= 1u; u1 = fn1((u0 ^ 9u), (unsigned)((short)(garr[u2 & 7u] << ((unsigned)x0 & 31u)) > (signed char)0x5ba09ce1u), (0xffffffffu - (unsigned)((int)0u < (int)(unsigned)l0))); }
            h0 = (short)i1;
        }
        u2 = 7u;
    }
    c1 = (signed char)(*mp % ((unsigned)f0 | 1u));
    d0 = d0 * 0.5 + (double)((fuel ^ (0x80000000u >> (0x10000u & 31u))) & 1023u);
    if (((unsigned)(x0 >> 70) % (v0 | 1u))) {
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1(3u, -((unsigned)x0 << ((unsigned)(short)((unsigned)s0 << (0x3975134cu & 31u)) & 31u)), (unsigned)c1); }
            l0 = (long)((unsigned long)l0 + (u1 ^ 3u));
            { unsigned t4; double z4; if ((i1) & 1u) { t4 = (unsigned)((int)(unsigned)s0 < (int)g0); z4 = (double)(((unsigned)(signed char)(unsigned)((fuel << (0xdaec8efdu & 31u)) && (unsigned)s1)) & 255u); } if ((i1) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                break; (void)((-(unsigned)((unsigned)h0 == 0x10000u) - a0[i0 & 3u]));
                if ((unsigned)((int)(1u - p0) < (int)m0)) {
                    if (p2) break;
                } else {
                    if ((g1 | (unsigned)((short)*q0 > (signed char)*q0))) break;
                    if ((unsigned)(0x7fffffffu < 0x30e3a587u)) break;
                    m0 ^= ((p0 - m0) ^ p0);
                }
            }
            if (u3 == 7u) return (unsigned)((int)(u0 | 0x10000u) >= (int)u1);
        } while (i0++ < 2u && (unsigned)(short)(unsigned)((short)(r0.y / (fuel | 1u)) > (signed char)0xffffffffu));
        a0[garr[u2 & 7u] & 3u] = (p0 + (unsigned)(0x294ba189u || (unsigned)c0));
        do { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + garr[i1 & 7u]);
            x0 = x0 * 0x100000001b3ull + (a0[u1 & 3u] & (a0[i0 & 3u] ^ u0));
        } while (i0++ < 5u && ((p1 << (garr[i1 & 7u] & 31u)) >> (r0.y & 31u)));
        if (fuel < 8u) return (((unsigned)l0 ^ u0) * 0xffffffffu);
    } else {
        b0 = (unsigned)(u3 || ~(0x80000000u ? 0xf8c2653u : *mp)) != 0u;
    }
    d0 = d0 * 0.5 + (double)(((unsigned)h1 / ((((u1 | (unsigned)d0) / (i1 | 1u)) - 0x7fffffffu) | 1u)) & 1023u);
    goto L0;
    if ((unsigned)((unsigned)s1 == (0x80000000u * (unsigned)c0))) goto L0;
    if ((0x29ad6c36u * 0xaad54afu)) {
        e0 = e0 * 0.5L + (long double)((((unsigned)((short)(unsigned)s0 > (signed char)i2) - u0) >> (((unsigned)s0 / ((unsigned)b0 | 1u)) & 31u)) & 1023u);
        q0 = &garr[(unsigned)(g1 && *q0) & 7u];
    }
    if ((unsigned)(m0 == 8u)) {
        switch ((unsigned)((short)(unsigned)h1 > (signed char)p1) & 7u) {
            *mp = (unsigned)(6u < (unsigned)(-(unsigned)(0xa558911u && (unsigned)h1) == (unsigned)((short)(unsigned)b0 > (signed char)g0)));
            s0 = (int)(unsigned)(((p0 ? (unsigned)c0 : (unsigned)c1) >> ((unsigned)l0 & 31u)) || (unsigned)c0);
            do { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)s0);
                garr[(unsigned)((int)r0.y >= (int)garr[i1 & 7u]) & 7u] = *mp;
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *q0 += (v0 >> ((unsigned)(p0 || g0) & 31u));
                    if ((r0.y * (unsigned)!(0xf08e58dau * fuel))) break;
                    *mp = i0;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((6u % (u3 | 1u)), (unsigned)((short)i2 > (signed char)g0), ((0xf3124d5eu + v0) + u1)); }
                }
                u0 ^= (unsigned)l0;
            } while (i0++ < 5u && ((unsigned)f0 * (unsigned)((unsigned)c0 == a0[i0 & 3u])));
            r0.x = (unsigned)d0;
            if (budget != 0u) { budget -= 1u; u0 = fn0(0x80000000u, 0x80000000u, (unsigned)((int)(unsigned)((int)(unsigned)b0 < (int)(unsigned)w0) < (int)*q0)); }
        }
        switch (i1 & 7u) {
            garr[*mp & 7u] = (unsigned)c1;
            do { if (--fuel == 0u) goto done;
                if (~(unsigned)((short)0xa4215fa4u > (signed char)(unsigned)h0)) continue;
                c0 = (unsigned char)(0xa204c043u ? (unsigned)((unsigned)(i2 == (unsigned)x0) || (unsigned)s1) : 0xe6898f5fu);
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    garr[(unsigned)((unsigned)(x0 >> 70) || g1) & 7u] = 0x7fffffffu;
                    u1 = -(unsigned)(5u == fuel);
                    g0 = (unsigned)!(i2 % (g1 | 1u));
                }
                if ((unsigned)(r0.y && 0x7fffffffu)) goto L2;
                c0 = (unsigned char)(0xffffffffu ? (0xb9d678bcu ? a0[u1 & 3u] : (unsigned)s0) : a0[i0 & 3u]);
            } while (i0++ < 6u && a0[u1 & 3u]);
            { unsigned t5; double z5; if ((a0[i0 & 3u]) & 1u) { t5 = 0x2e363ae9u; z5 = (double)(((i1 % ((unsigned)(short)(6u & 0xffffffffu) | 1u))) & 255u); } if ((a0[i0 & 3u]) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (u2 % ((unsigned)l0 | 1u));
                    *mp = (*q0 + ((unsigned)d0 / ((fuel % ((unsigned)w0 | 1u)) | 1u)));
                    case 7u: ;
                    switch (p1 & 7u) {
                        s0 = (int)(unsigned)((a0[u1 & 3u] - g1) && (unsigned)(short)(unsigned)(v0 && i2));
                        for (;;) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn0((0xf838b2dau & (unsigned)((int)a0[u1 & 3u] >= (int)a0[u1 & 3u])), (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)s0), (unsigned)((int)i0 < (int)p1)); }
                            i0 = ((unsigned)w0 + (u1 ? (unsigned)c0 : (unsigned)d0)) & 15u;
                            if ((((unsigned)c0 ^ 8u) | u3)) break;
                        }
                        *q0 += (unsigned)(signed char)(i2 ^ (0xfd41def5u ^ (unsigned)d0));
                        case 4u: ;
                    }
                }
                i1 = ((unsigned)f0 ? (unsigned)f0 : 0x10000u) & 15u;
                c1 = (signed char)(g0 >> (a0[u1 & 3u] & 31u));
            }
        }
        switch (((unsigned)h1 + ((unsigned)h0 / ((unsigned)c1 | 1u))) & 7u) {
            u0 = u0 * 0x9e3779b1u + (unsigned)((int)(m0 + g1) >= (int)0x6cc79d90u);
            if ((unsigned)(6u && u0)) break;
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                g0 = (unsigned)(short)(0x80000000u / (a0[i0 & 3u] | 1u));
                while (i1++ < 3u && (unsigned)((unsigned)((int)a0[i0 & 3u] < (int)0xffffffffu) < (unsigned)h0)) { if (--fuel == 0u) goto done;
                    if (3u) continue;
                    r0.x = (0x63f2611u & (1u ? v0 : (unsigned)c1));
                    case 7u: ;
                }
                case 6u: ;
                u0 += (6u ^ ((unsigned)l0 % ((a0[i0 & 3u] << (4u & 31u)) | 1u)));
                if (u3 == 7u) return (unsigned)l0;
                h1 = (unsigned short)(h1 + (unsigned)(0x899d9095u || (unsigned)x0));
            }
            e0 = e0 * 0.5L + (long double)((unsigned)((g0 | (unsigned)h0) || (a0[i0 & 3u] - p0)) & 1023u);
            if ((unsigned)((a0[i0 & 3u] >> (0x10000u & 31u)) == garr[u2 & 7u])) {
                { unsigned t6; double z6; if (((unsigned)((p2 * 6u) < (unsigned)(x0 >> 70))) & 1u) { t6 = (unsigned)s1; z6 = (double)((((unsigned)((int)u0 < (int)(unsigned)h1) * 0x7fffffffu)) & 255u); } if (((unsigned)((p2 * 6u) < (unsigned)(x0 >> 70))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                    default: ;
                    u3 = u3 * 0x9e3779b1u + (0xaa09d579u << ((unsigned)(0xffffffffu || (unsigned)l0) & 31u));
                    if (p1) goto L2;
                    s0 = (int)(unsigned)((unsigned)(8u < p0) || p2);
                    if ((unsigned)((int)(unsigned)b0 < (int)g1)) goto L0;
                    if ((unsigned)(r0.x == (unsigned)f0)) {
                        s1 = (int)((unsigned)s1 + ((v0 % (*q0 | 1u)) + (unsigned)((unsigned)w0 && (unsigned)(0x7fffffffu && 0x10000u))));
                    } else {
                        if ((0x76b39a99u & (g0 & 0xc696f701u))) break;
                    }
                }
                { unsigned t7; double z7; if (((unsigned)s1) & 1u) { t7 = 0x7fffffffu; z7 = (double)((((unsigned)b0 & g1)) & 255u); } if (((unsigned)s1) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                    { unsigned t8; double z8; if ((i2) & 1u) { t8 = ((unsigned)(0x10000u && u3) & p0); z8 = (double)(((unsigned)s0) & 255u); } if ((i2) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                        case 5u: ;
                        c1 = (signed char)(((0u << (0x10000u & 31u)) + 7u) ^ (0x64a5c908u * g1));
                        if (fuel) goto done;
                    }
                    g0 = ((unsigned)b0 / (u1 | 1u));
                    e0 = e0 * 0.5L + (long double)(-(i2 << ((unsigned)(((unsigned)s1 >> (0x7fffffffu & 31u)) == (unsigned)f0) & 31u)) & 1023u);
                    s0 = (int)(g1 * ((unsigned)s0 + a0[i0 & 3u]));
                    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)(unsigned)(signed char)(unsigned)((int)(unsigned)x0 < (int)(unsigned)((unsigned)l0 < (unsigned)((short)(0xffffffffu / ((unsigned)x0 | 1u)) > (signed char)*mp)));
                    }
                    if ((unsigned)(7u == (unsigned)(g0 == fuel))) goto L3;
                }
                d0 = d0 * 0.5 + (double)(((unsigned)(*q0 || (0x5e0057e4u | (unsigned)(short)(p1 % (2u | 1u)))) + 0x10000u) & 1023u);
                if ((unsigned)((unsigned)!(0u % ((unsigned)w0 | 1u)) && v0)) break;
            }
            break;
        }
        do { if (--fuel == 0u) goto done;
            u2 = u2 * 0x9e3779b1u + ((unsigned)((short)p0 > (signed char)0xd9201cd0u) % (((unsigned)l0 << ((v0 << ((unsigned)s1 & 31u)) & 31u)) | 1u));
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(0x9326ef2eu - u3) < (int)(unsigned)(x0 >> 70)), (unsigned)((int)g0 >= (int)i2), (a0[i0 & 3u] << ((garr[u2 & 7u] & i0) & 31u))); }
            { unsigned t9; double z9; if ((0x80000000u) & 1u) { t9 = ((unsigned)((int)0x80771051u >= (int)0x7fffffffu) % (u0 | 1u)); z9 = (double)((p1) & 255u); } if ((0x80000000u) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                if (budget != 0u) { budget -= 1u; u0 = fn0(i0, ((unsigned)c0 | 7u), ((unsigned)c0 % (8u | 1u))); }
                break; (void)(m0);
                c1 = (signed char)(unsigned)!(unsigned)((int)3u >= (int)i2);
            }
            break; (void)(0xe5fbcb78u);
        } while (i0++ < 5u && (unsigned)l0);
    }
    v0 = ((((unsigned)l0 * 3u) >> (0x80000000u & 31u)) - 0xffffffffu);
    if (0xb82c62bu) goto L2;
    *mp = a0[i0 & 3u];
    f0 = f0 * 0.5f + (float)((unsigned)c0 & 255u);
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)h1 >= (int)i1), (unsigned)((int)p0 < (int)r0.x), (unsigned)(6u && (0x10000u % ((unsigned)e0 | 1u)))); }
    { unsigned t10; double z10; if (((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)(x0 >> 70))) & 1u) { t10 = (unsigned)l0; z10 = (double)((0x80000000u) & 255u); } if (((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)(x0 >> 70))) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
        g0 = -(p1 * r0.x);
        goto L0;
    }
    { unsigned t11; double z11; if (((unsigned)b0) & 1u) { t11 = (unsigned)((short)1u > (signed char)(unsigned)((int)0xb61b7ea0u < (int)r0.x)); z11 = (double)((~(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)((unsigned)c0 < 2u))) & 255u); } if (((unsigned)b0) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
        v0 = (unsigned)!(unsigned)(p1 == (unsigned)((int)((unsigned)f0 / (0x10000u | 1u)) >= (int)0x10000u));
        switch (v0 & 7u) {
            x0 = x0 * 0x100000001b3ull + ((unsigned)c1 & i1);
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)garr[i1 & 7u] > (signed char)((unsigned)e0 * 0x80000000u)), (garr[u2 & 7u] + a0[u1 & 3u]), (i0 ? u1 : u3)); }
            if ((unsigned)h1) {
                b0 = (*mp >> ((unsigned)(0x3a05b450u < 9u) & 31u)) != 0u;
                *q0 += (0x70809a88u - (garr[i1 & 7u] % ((unsigned)h0 | 1u)));
                v0 = (*q0 ? 0x80000000u : 0x80000000u);
                if ((unsigned)b0) goto L2;
                m0 ^= (unsigned)((int)p1 < (int)0x10000u);
            }
            e0 = e0 * 0.5L + (long double)(((unsigned)((garr[i1 & 7u] - 2u) && (unsigned)((short)(unsigned)x0 > (signed char)a0[u1 & 3u])) - g1) & 1023u);
            if (((unsigned)x0 << ((unsigned)((short)(unsigned)w0 > (signed char)0x80000000u) & 31u))) break;
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                h0 = (short)(unsigned)((short)((unsigned)h0 & (unsigned)(0x7fffffffu || (garr[u2 & 7u] ^ (unsigned)e0))) > (signed char)1u);
                w0 = w0 * 6364136223846793005ull + (((unsigned)((unsigned)c0 && p1) | p2) << ((i2 | r0.x) & 31u));
            }
        }
        if (((unsigned)c0 - ((unsigned)s0 | 0xffffffffu))) goto done;
        c0 = (unsigned char)(((0x7fffffffu & 0xfeba34c6u) % (garr[u2 & 7u] | 1u)) % (u0 | 1u));
        goto L1;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((garr[u2 & 7u] | (unsigned)((unsigned)l0 == p2)), (unsigned)((short)(unsigned)d0 > (signed char)(unsigned)!(u3 << ((unsigned)h1 & 31u))), u0); }
    { unsigned t12; double z12; if ((((0xffffffffu - i2) - (unsigned)h0)) & 1u) { t12 = (unsigned)((int)8u < (int)(unsigned)((short)m0 > (signed char)(unsigned)f0)); z12 = (double)((i2) & 255u); } if ((((0xffffffffu - i2) - (unsigned)h0)) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
        c0 = (unsigned char)0xffffffffu;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(0x10000u, (p1 | (p2 & (unsigned)x0)), ((unsigned)s1 ^ (6u * fuel))); }
        } while (i0++ < 4u && (unsigned)h1);
    }
    if ((3u - (1u >> (m0 & 31u)))) goto L0;
    r0.y ^= (unsigned)((unsigned)d0 || (unsigned)((int)-(unsigned)(u3 == (unsigned)h1) < (int)(unsigned)((unsigned)c1 < i0)));
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (m0) {
            if (budget != 0u) { budget -= 1u; u2 = fn0(0x7fffffffu, u0, i2); }
            if (a0[i0 & 3u]) break;
            l0 = (long)((unsigned long)l0 + (unsigned)(short)(unsigned)((int)(unsigned)((short)(unsigned)((short)0x2af495e4u > (signed char)i2) > (signed char)0xf6778f26u) >= (int)(unsigned)s1));
            while (r0.x) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(a0[i0 & 3u] - (0x7fffffffu * 0x7fffffffu));
                c0 = (unsigned char)(unsigned)e0;
            }
            do { if (--fuel == 0u) goto done;
                c0 = (unsigned char)g1;
                break; (void)((unsigned)((0xd6cb3b99u >> (0x80000000u & 31u)) < *q0));
                w0 = w0 * 6364136223846793005ull + ((unsigned)(unsigned char)(i0 << (p2 & 31u)) * (0xffffffffu + m0));
            } while (i1++ < 3u && ((unsigned)(w0 >> 29) + (unsigned)w0));
            for (;;) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (g0 | ((g1 & 5u) - g0));
            }
        } else {
            r0.x = (unsigned)((short)0xffffffffu > (signed char)(unsigned)l0);
            goto L3;
        }
        while (i1++ < 6u && (unsigned)(signed char)(unsigned)((unsigned)l0 || a0[u1 & 3u])) { if (--fuel == 0u) goto done;
            u2 ^= (unsigned)((unsigned)((int)v0 < (int)g0) < 0x9c040d4au);
            if (v0) break;
            if ((unsigned)b0) break;
            i2 = (unsigned)(((0x7fffffffu - (unsigned)h0) >> (1u & 31u)) || v0) & 15u;
            g1 += (unsigned)(g1 == (9u >> (u0 & 31u)));
            if (a0[i0 & 3u]) break;
        }
        e0 = e0 * 0.5L + (long double)((unsigned)d0 & 1023u);
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(u0 < m0), (unsigned)((unsigned)((unsigned)x0 || p2) && (unsigned)h0), (unsigned)c0); }
        goto L2;
        b0 = -(unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)(unsigned char)(((unsigned)b0 - v0) >> (p0 & 31u))) != 0u;
    }
    g1 += ((unsigned)((int)(7u | (unsigned)h0) < (int)(unsigned)(x0 >> 70)) << ((p0 - (unsigned)x0) & 31u));
    u2 += ((4u - r0.y) * (unsigned)((unsigned)e0 == fuel));
    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(0x10000u == u0) % (garr[u2 & 7u] | 1u)), (unsigned)((int)5u < (int)garr[i1 & 7u]), 0x10000u); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)((unsigned)((short)(unsigned)d0 > (signed char)6u) < (unsigned)s1)) {
        if (budget != 0u) { budget -= 1u; u0 = fn0(~(unsigned)(u2 || ((unsigned)h1 * 0x10000u)), 0x49b52da2u, (unsigned)((short)((unsigned)h1 * v0) > (signed char)u2)); }
        h0 = (short)(0x2706d783u ? (u1 % ((u2 >> ((unsigned)(w0 >> 29) & 31u)) | 1u)) : r0.y);
        if (fuel < 8u) return (unsigned)((unsigned)(i1 || (unsigned)c1) == (unsigned)((short)i0 > (signed char)i0));
    }
    for (;;) { if (--fuel == 0u) goto done;
        if ((r0.y / ((i2 >> (a0[u1 & 3u] & 31u)) | 1u))) break;
        if (budget != 0u) { budget -= 1u; u2 = fn0(0x233006bau, (unsigned)f0, (unsigned)b0); }
        if (m0) continue;
        if (((unsigned)l0 - (unsigned)s0)) break;
        l0 = (long)((unsigned long)l0 + 2u);
    }
    *q0 = (0x80000000u - (unsigned)h0);
    L0: if (--fuel == 0u) goto done;
    s0 = (int)(unsigned)((unsigned)(0x4d7341b1u || i1) && p1);
    while (i0++ < 5u && (0x80000000u - (unsigned)(unsigned char)(unsigned)(r0.x == 0x80000000u))) { if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
        u2 ^= (unsigned)(short)(0x64e901f2u / ((p1 >> (0xbd247428u & 31u)) | 1u));
        L2: if (--fuel == 0u) goto done;
        if (u3) break;
    }
    i0 = (unsigned)((a0[i0 & 3u] ^ (unsigned)(unsigned char)(unsigned)((int)(unsigned)h1 < (int)i1)) == (unsigned)((int)0x1ed3e47eu < (int)(unsigned)d0)) & 15u;
    goto done;
    if ((unsigned)h1) goto L4;
    if (a0[u1 & 3u]) goto L4;
    if (0x10000u) {
        goto L4;
    }
    g1 += (-(unsigned)((int)0x10000u < (int)(unsigned)c0) ^ (unsigned)((short)m0 > (signed char)a0[u1 & 3u]));
    switch ((unsigned)(short)(fuel ^ (garr[u2 & 7u] ^ p0)) & 7u) {
        s0 = (int)((unsigned)c1 * 9u);
        *q0 = (((unsigned)f0 & (unsigned)c1) % (((p1 % ((unsigned)l0 | 1u)) << (garr[u2 & 7u] & 31u)) | 1u));
        d0 = d0 * 0.5 + (double)((unsigned)((int)(9u >> (u2 & 31u)) >= (int)((unsigned)(unsigned char)((unsigned)d0 * 1u) - u0)) & 1023u);
        while (g1) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((unsigned)h0 & 255u);
            case 6u: ;
        }
        if (fuel < 8u) return (unsigned)(unsigned char)((0xecaef134u >> (0xc10580cfu & 31u)) >> (p2 & 31u));
        i1 = (unsigned)(x0 >> 70) & 15u;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(unsigned char)((unsigned)s0 + ((unsigned)l0 & 0xcef82eeau)), 0x24275842u, (unsigned)(signed char)(unsigned)((int)(unsigned)(w0 >> 29) < (int)2u)); }
    if ((r0.x * ((unsigned)s1 + (unsigned)h1))) {
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)e0, (p0 >> (~(a0[u1 & 3u] * v0) & 31u)), ((unsigned)(w0 >> 29) % (r0.y | 1u))); }
        if ((unsigned)(m0 < r0.y)) goto L2;
        if ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)c1)) goto L4;
    } else {
        switch (((v0 & (unsigned)c0) + 8u) & 7u) {
            if ((5u + (unsigned)f0)) {
                if (fuel < 8u) return ((unsigned)((unsigned)(0x7fffffffu && 0x224f4e9u) < 0x7fffffffu) >> (0xa5cad12fu & 31u));
                *mp = ((unsigned)d0 + ((unsigned)(*mp || (unsigned)((int)0x80000000u < (int)a0[i0 & 3u])) - (unsigned)h1));
                case 4u: ;
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn2(i2, m0, (0x7fffffffu & g0)); }
                    L3: if (--fuel == 0u) goto done;
                    L4: if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)(~(unsigned)((i0 ^ a0[i0 & 3u]) || (unsigned)c1) & 1023u);
                }
                if ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)((int)0xe5bf1d46u >= (int)garr[u2 & 7u]))) {
                    case 3u: ;
                    { unsigned t0; double z0; if ((((unsigned)(unsigned char)(0x464dc730u & 0x9334c0dau) / ((unsigned)x0 | 1u))) & 1u) { t0 = a0[u1 & 3u]; z0 = (double)((g1) & 255u); } if ((((unsigned)(unsigned char)(0x464dc730u & 0x9334c0dau) / ((unsigned)x0 | 1u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                        b0 = (unsigned)((unsigned)(unsigned char)(*q0 << (-(0xffffffffu & g0) & 31u)) == (unsigned)c1) != 0u;
                        garr[(0xb0a62e82u + garr[u2 & 7u]) & 7u] = ((unsigned)(short)(i0 ^ a0[u1 & 3u]) + ((u2 >> ((unsigned)w0 & 31u)) | (unsigned)c0));
                    }
                } else {
                    s1 = (int)((unsigned)s1 + ((unsigned)!(p1 | 9u) * (unsigned)(w0 >> 29)));
                    v0 = (unsigned)(unsigned char)((unsigned)c0 & ((unsigned)!((unsigned)w0 - 0x80000000u) | 0xffffffffu));
                    if (budget != 0u) { budget -= 1u; u3 = fn1(p0, (0x2b208986u | (0x88bcfdeu | (unsigned)(w0 >> 29))), (u0 & (u2 >> (8u & 31u)))); }
                    x0 = x0 * 0x100000001b3ull + (0x80000000u + i0);
                }
            } else {
                l0 = (long)((unsigned long)l0 + p0);
                goto L2;
            }
        }
        if (0xd9082246u) goto done;
    }
    q0 = &garr[(unsigned)(short)((unsigned)s1 + garr[u2 & 7u]) & 7u];
    if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)(0xe6989b2du || garr[u2 & 7u]) >> ((unsigned)h1 & 31u)), (unsigned)(1u && 0x31805dbbu), (unsigned)(i2 == (unsigned)((short)5u > (signed char)0xe39dda27u))); }
    if (4u) goto done;
    h0 = (short)(unsigned)h0;
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)x0, (0x43538ec2u >> (*q0 & 31u)), (0u & (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)x0))); }
    u3 = u3 * 0x9e3779b1u + ((unsigned)((unsigned)f0 == g1) ^ garr[i1 & 7u]);
    if ((2u >> (m0 & 31u))) goto L4;
    if ((unsigned)(m0 == (0x39d514b3u << ((unsigned)h0 & 31u)))) goto L3;
    x0 = x0 * 0x100000001b3ull + (unsigned)(0xdfcc50du && 0xffffffffu);
    if (budget != 0u) { budget -= 1u; u2 = fn2((0x98fb8151u + (unsigned)w0), 0x10000u, (4u + u0)); }
    if (budget != 0u) { budget -= 1u; u3 = fn2(0x7f8475fcu, (unsigned)((short)v0 > (signed char)((unsigned)d0 / (p0 | 1u))), (unsigned)((unsigned)(x0 >> 70) && (u0 ^ g0))); }
    e0 = e0 * 0.5L + (long double)(v0 & 1023u);
    *q0 += -((0x10000u >> (*q0 & 31u)) * (unsigned)((unsigned)c0 || 0x998eaa5au));
    if (p1) goto L1;
    switch ((0x10000u % (0x80000000u | 1u)) & 7u) {
        g1 += p1;
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)c0, (unsigned)(unsigned char)((unsigned)((int)i1 < (int)(unsigned)d0) + (unsigned)d0), (3u - (unsigned)w0)); }
        while (i0++ < 3u && (fuel + (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)h1 || 0xffffffffu)) {
                { unsigned t1; double z1; if (((unsigned)l0) & 1u) { t1 = (unsigned)((int)(unsigned)x0 >= (int)0x10000u); z1 = (double)(((unsigned)(signed char)((unsigned)e0 | 0x10000u)) & 255u); } if (((unsigned)l0) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    while (i1++ < 5u && 3u) { if (--fuel == 0u) goto done;
                        switch ((unsigned)((short)0x10000u > (signed char)(unsigned)((unsigned)e0 && (unsigned)l0)) & 7u) {
                            if (budget != 0u) { budget -= 1u; u1 = fn1(-((unsigned)h0 - u2), ((unsigned)w0 + garr[u2 & 7u]), m0); }
                            case 4u: ;
                            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((unsigned)((short)0xffffffffu > (signed char)i0) || 0xffffffffu), (unsigned)((unsigned)(0x80000000u == u1) == 7u), a0[i0 & 3u]); }
                            h1 = (unsigned short)(h1 + (6u ? 0x862b8e01u : (u1 - g1)));
                            g1 += ((unsigned)(unsigned char)(0x93338e0bu ^ (unsigned)((int)r0.y < (int)(unsigned)s1)) / ((unsigned)((unsigned)(w0 >> 29) || i1) | 1u));
                            if ((unsigned)h1) continue;
                        }
                        if ((unsigned)((unsigned)e0 || (unsigned)d0)) break;
                    }
                    continue; (void)((unsigned)!(0xffffffffu >> ((unsigned)f0 & 31u)));
                    if ((unsigned)(i2 == (unsigned)(unsigned char)(0x33849958u / ((unsigned)(w0 >> 29) | 1u)))) break;
                    case 6u: ;
                    for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        m0 ^= ((0x80000000u ^ (unsigned)((int)(5u / ((unsigned)(w0 >> 29) | 1u)) >= (int)(unsigned)l0)) >> (8u & 31u));
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)w0 ^ (unsigned)f0), (g0 / (i2 | 1u)), 3u); }
                }
                i0 = (unsigned)((int)u1 < (int)(unsigned)l0) & 15u;
                if (0x208a932du) {
                    d0 = d0 * 0.5 + (double)((unsigned)(i2 == 0x80000000u) & 1023u);
                    case 4u: ;
                    b0 = ((p0 + (unsigned)(garr[u2 & 7u] && i1)) * (0x10000u - u2)) != 0u;
                    c0 = (unsigned char)i0;
                    switch (u3 & 7u) {
                        if (u2) goto done;
                        f0 = f0 * 0.5f + (float)((unsigned)((u1 * (unsigned)(x0 >> 70)) == *mp) & 255u);
                        if ((unsigned)l0) break;
                    }
                } else {
                    *q0 += ((r0.x ^ (unsigned)(x0 >> 70)) / (i2 | 1u));
                }
                case 3u: ;
            } else {
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)u3 >= (int)0x63dcda34u)) continue;
                    r0.x = ((unsigned)((0x80000000u & (unsigned)h1) || 9u) & (unsigned)x0);
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)(unsigned)(unsigned char)(0x4e0bf5c2u % (garr[u2 & 7u] | 1u));
                        q0 = &garr[0x7fffffffu & 7u];
                        default: ;
                        u3 ^= (unsigned)!(9u ^ 0x22f3a64du);
                    }
                    do { if (--fuel == 0u) goto done;
                        a0[0x8dd46ce2u & 3u] = (0x80000000u & (unsigned)((int)*mp < (int)u2));
                        if (fuel) goto done;
                        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                            u2 += 8u;
                            break;
                            r0.x = ((unsigned)b0 | (unsigned)((short)(fuel - (unsigned)(short)(0x209b1fe1u % (u0 | 1u))) > (signed char)0x80000000u));
                            g0 = ((unsigned)(0xd0880afdu < garr[i1 & 7u]) | i0);
                            if ((unsigned)(v0 || 5u)) break;
                            g1 += ((unsigned)((unsigned)h0 && v0) / ((garr[u2 & 7u] ^ ((unsigned)b0 + (unsigned)(x0 >> 70))) | 1u));
                        }
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(5u == (unsigned)((int)i1 < (int)(unsigned)l0)), 0x6a13b830u, -((unsigned)h0 | (unsigned)(w0 >> 29))); }
                    } while (i2++ < 7u && (unsigned)b0);
                    if (((unsigned)f0 << (5u & 31u))) {
                        garr[(unsigned)((short)g1 > (signed char)g0) & 7u] = -(4u / (0x10000u | 1u));
                        if (0x7fffffffu) continue;
                        do { if (--fuel == 0u) goto done;
                            break; (void)((6u - (unsigned)c0));
                            v0 = (unsigned)(unsigned char)(a0[i0 & 3u] + (0x10000u >> (garr[i1 & 7u] & 31u)));
                            *q0 = ((unsigned)l0 % (u2 | 1u));
                        } while (i2++ < 4u && ((unsigned)!(unsigned)((short)0x10000u > (signed char)r0.y) ^ 0x9d8d4d78u));
                        e0 = e0 * 0.5L + (long double)((unsigned)(a0[u1 & 3u] == -(((unsigned)d0 >> (8u & 31u)) << ((unsigned)(unsigned char)(unsigned)((unsigned)s0 < 0x7cc582e3u) & 31u))) & 1023u);
                        { unsigned t2; double z2; if ((((unsigned)l0 / (2u | 1u))) & 1u) { t2 = (unsigned)((short)(unsigned)(g1 < 3u) > (signed char)v0); z2 = (double)(((0xffffffffu << ((unsigned)(w0 >> 29) & 31u))) & 255u); } if ((((unsigned)l0 / (2u | 1u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                            m0 ^= ~(2u << ((2u / ((unsigned)((unsigned)((int)u0 < (int)r0.x) < (unsigned)d0) | 1u)) & 31u));
                            case 1u: ;
                            h1 = (unsigned short)(h1 + (unsigned)(((unsigned)x0 & *q0) && i1));
                        }
                    } else {
                        b0 = g0 != 0u;
                        u3 = u3 * 0x9e3779b1u + (unsigned)((int)0x8e5c28c1u >= (int)p2);
                        if ((unsigned)(short)(unsigned)(0x14ebb342u == g0)) break;
                        if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)((int)0xffffffffu >= (int)(unsigned)s1) >> (0u & 31u)), (unsigned)(0x7fffffffu && (unsigned)c0), fuel); }
                    }
                    case 0u: ;
                }
            }
            if (fuel < 8u) return (p2 >> (0xede5fad0u & 31u));
        }
        do { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (unsigned)(u2 || u0);
            if (0xb25868d8u) {
                do { if (--fuel == 0u) goto done;
                    r0.y ^= 0xffffffffu;
                    if ((unsigned)(short)(unsigned)(0x667ccd1bu || (unsigned)c0)) break;
                    b0 = *mp != 0u;
                    if (((unsigned)(g0 || p2) << ((unsigned)s1 & 31u))) continue;
                    if (0xd3d5cd18u) break;
                } while (i1++ < 7u && (unsigned)x0);
                a0[1u & 3u] = (g1 >> (u2 & 31u));
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(i2 && p1), ((0x80000000u ^ (unsigned)l0) & 0xb3de6ba3u), (5u ^ (unsigned)(garr[u2 & 7u] == a0[u1 & 3u]))); }
            }
        } while (i0++ < 6u && (unsigned)(signed char)(unsigned)(u3 == (unsigned)d0));
        case 7u: ;
        a0[(unsigned)(signed char)((unsigned)x0 * i0) & 3u] = (v0 - *mp);
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(r0.y ^ garr[i1 & 7u]) < (int)u3)) goto L2;
        if (budget != 0u) { budget -= 1u; u3 = fn1((0x7fffffffu - (unsigned)h0), u1, ((unsigned)h0 ^ a0[i0 & 3u])); }
        if (budget != 0u) { budget -= 1u; u2 = fn0((p0 & (v0 - u3)), (unsigned)(*q0 && (unsigned)(fuel == i2)), (unsigned)d0); }
    } while (i0++ < 5u && a0[u1 & 3u]);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= ((unsigned)((short)*q0 > (signed char)garr[i1 & 7u]) & (garr[u2 & 7u] & 0xf9f5374au));
        s1 = (int)((unsigned)s1 + (unsigned)(signed char)(u1 ^ (unsigned)(0xb370ef07u && r0.x)));
    }
    do { if (--fuel == 0u) goto done;
        g0 = u1;
        g0 = (0x10000u % ((unsigned)(p2 && g1) | 1u));
        if (((unsigned)c1 >> ((unsigned)(w0 >> 29) & 31u))) {
            { unsigned t3; double z3; if ((u0) & 1u) { t3 = (unsigned)(*mp == (r0.x | i1)); z3 = (double)(((g0 | (unsigned)d0)) & 255u); } if ((u0) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                if ((unsigned)((unsigned)((int)u1 < (int)*q0) && (unsigned)h1)) break;
                x0 = x0 * 0x100000001b3ull + (unsigned)(u1 == g1);
            }
            r0.x = (unsigned)((short)((unsigned)s1 | p2) > (signed char)((unsigned)c1 << (((unsigned)e0 << (7u & 31u)) & 31u)));
            u2 = u2 * 0x9e3779b1u + (unsigned)((int)(unsigned)((int)(unsigned)d0 >= (int)(unsigned)(u0 == fuel)) >= (int)(i0 % (i1 | 1u)));
            while (i1++ < 5u && (unsigned)(g1 < (unsigned)b0)) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return (unsigned)((int)9u < (int)((8u ^ r0.x) / (((unsigned)f0 / (p1 | 1u)) | 1u)));
                r0.x = (((unsigned)b0 / (u0 | 1u)) * ~(unsigned)((unsigned)(unsigned char)((unsigned)h0 % ((unsigned)c0 | 1u)) || u2));
                if ((unsigned)((unsigned)(*q0 == 5u) == garr[i1 & 7u])) {
                    if ((unsigned)s1) break;
                    break; (void)(u3);
                    r0.x = ((unsigned)h1 * 7u);
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(*mp && (unsigned)(0x80000000u && 0x7fffffffu)), (unsigned)x0, (unsigned)(x0 >> 70)); }
                    break; (void)((unsigned)h1);
                }
                v0 = (p0 << (garr[i1 & 7u] & 31u));
            }
        } else {
            while (i1++ < 7u && (fuel << ((unsigned)c1 & 31u))) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + ((unsigned)w0 * (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)s1)));
                c0 = (unsigned char)((unsigned)((int)fuel >= (int)0xb38a83feu) | (unsigned)(short)(0xffffffffu & r0.x));
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(unsigned)l0 > (signed char)i0), -(unsigned)((unsigned)(x0 >> 70) == 0x80000000u), r0.x); }
            }
            v0 = (unsigned)!(unsigned)((int)(unsigned)(((unsigned)e0 ^ *q0) && u1) >= (int)9u);
            if (u3 == 7u) return u3;
        }
        r0.y ^= ((unsigned)(p1 && *mp) | ((unsigned)((unsigned)w0 == p2) << (u0 & 31u)));
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)(~(unsigned)((int)(unsigned)s1 >= (int)(unsigned)((int)i2 >= (int)(unsigned)h1)) && (unsigned)(0x6e20e156u || (unsigned)(w0 >> 29))) & 1023u);
        }
    } while (i0++ < 3u && (unsigned)((int)0x9a9f6621u < (int)(6u - p2)));
    if ((unsigned)!((unsigned)s1 ? i0 : i1)) {
        if ((unsigned)((unsigned)c1 && (unsigned)h1)) goto L0;
        x0 = x0 * 0x100000001b3ull + (8u % (((u1 % (((unsigned)b0 | v0) | 1u)) >> (0x80000000u & 31u)) | 1u));
        b0 = ((unsigned)((unsigned)!(unsigned)(0x1b0fccf8u < (a0[u1 & 3u] ^ a0[i0 & 3u])) == (unsigned)f0) * u2) != 0u;
        u3 += (unsigned)(short)((m0 | u2) + (unsigned)((int)u0 < (int)p1));
    } else {
        goto L0;
        *q0 += (unsigned)(short)(unsigned)((short)2u > (signed char)u3);
    }
    goto L4;
    if ((unsigned)x0) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((fuel << (g0 & 31u)), ((unsigned)x0 >> ((unsigned)((short)(unsigned)c1 > (signed char)0xef2302c3u) & 31u)), (unsigned)(0x4e56dffbu < 0x7628dbcu)); }
        if (0x80000000u) goto L3;
        if ((unsigned)((int)(unsigned)c0 < (int)(unsigned)b0)) {
            b0 = ((unsigned)(w0 >> 29) % ((unsigned)((u0 ^ (unsigned)(w0 >> 29)) < 0x80000000u) | 1u)) != 0u;
        }
    }
    a0[(0x10000u & garr[u2 & 7u]) & 3u] = ((p2 + 6u) * ((unsigned)b0 ^ 0x10000u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + ((unsigned)d0 % ((unsigned)((int)(5u / ((unsigned)x0 | 1u)) < (int)~(*q0 << (u1 & 31u))) | 1u));
        f0 = f0 * 0.5f + (float)((-((5u * (unsigned)h0) + (unsigned)((int)0xffffffffu < (int)0x10000u)) * 0x10000u) & 255u);
    }
    a0[(unsigned)s1 & 3u] = (unsigned)((int)(unsigned)s0 >= (int)(unsigned)((short)(unsigned)h1 > (signed char)0x53382ce7u));
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(-(*q0 / (i0 | 1u)) ^ (unsigned)c0) >= (int)(unsigned)c1);
    for (;;) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                while (i0++ < 2u && (unsigned)(short)(unsigned)((int)g1 < (int)(0x10000u ^ v0))) { if (--fuel == 0u) goto done;
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        g0 = (2u >> ((unsigned)((int)g1 < (int)i0) & 31u));
                        b0 = -(unsigned)(g0 || (((unsigned)c0 % (0xb8720bd3u | 1u)) ^ p1)) != 0u;
                        q0 = &garr[((((unsigned)(x0 >> 70) ^ p0) / (i1 | 1u)) - garr[i1 & 7u]) & 7u];
                    }
                    if ((p0 % ((unsigned)l0 | 1u))) {
                        g1 += (i2 ? 3u : garr[i1 & 7u]);
                        s1 = (int)((unsigned)s1 + (unsigned)(x0 >> 70));
                        L1: if (--fuel == 0u) goto done;
                    } else {
                        s1 = (int)((unsigned)s1 + ((unsigned)(0x80000000u == 0x35fe5052u) >> ((unsigned)((short)(0xffffffffu + (unsigned)x0) > (signed char)(unsigned)s0) & 31u)));
                        d0 = d0 * 0.5 + (double)((unsigned)(signed char)((*mp >> ((unsigned)h0 & 31u)) ^ (unsigned)(signed char)((unsigned)((int)garr[u2 & 7u] >= (int)fuel) % (p1 | 1u))) & 1023u);
                    }
                    if ((unsigned)(signed char)(unsigned)((int)(*mp << (u1 & 31u)) < (int)(unsigned)s1)) {
                        g0 = (unsigned)((unsigned)w0 == (unsigned)(unsigned char)((unsigned)((unsigned)d0 < (unsigned)s0) << (fuel & 31u)));
                        if ((garr[i1 & 7u] ^ 4u)) break;
                        if ((g0 + (unsigned)s1)) break;
                        r0.x = (garr[i1 & 7u] ^ (p0 | 0xbcf5e8c6u));
                        for (;;) { if (--fuel == 0u) goto done;
                            u3 ^= (((unsigned)((short)(unsigned)e0 > (signed char)4u) << (0u & 31u)) + (2u & (unsigned)e0));
                            *mp = r0.y;
                            L2: if (--fuel == 0u) goto done;
                            i0 = (g0 - (unsigned)((int)0x7fffffffu >= (int)(unsigned)l0)) & 15u;
                        }
                        if (((unsigned)(i1 || a0[i0 & 3u]) & 0x80f4bb14u)) {
                            if ((*mp / (g1 | 1u))) continue;
                            garr[(unsigned)((int)garr[u2 & 7u] < (int)(unsigned)l0) & 7u] = ((0xde4b8bfu % (garr[u2 & 7u] | 1u)) & (5u * *q0));
                            if (7u) continue;
                        } else {
                            u3 = 0xc46642a2u;
                            if ((unsigned)s1) break;
                        }
                    } else {
                        goto L2;
                        e0 = e0 * 0.5L + (long double)((unsigned)(0x23d53436u || ((garr[u2 & 7u] >> (p0 & 31u)) + 0xff2cbdfu)) & 1023u);
                    }
                }
                *q0 += (garr[i1 & 7u] << (~(~(*q0 ? *q0 : 0xf6412d16u) ^ 0xffffffffu) & 31u));
                r0.x = (a0[u1 & 3u] ? (unsigned)((int)p0 < (int)9u) : g0);
            }
            if (u3 == 7u) return (0x80000000u & *mp);
            break; (void)((unsigned)c0);
            h0 = (short)(unsigned)((short)(unsigned)b0 > (signed char)(unsigned)((int)(unsigned)(unsigned char)(4u << (0xffffffffu & 31u)) < (int)(unsigned)!(*q0 & 0x80000000u)));
        }
    }
    goto L1;
    w0 = w0 * 6364136223846793005ull + ((unsigned)(w0 >> 29) * ~(unsigned)((short)~(0xa9a9ee71u / (p1 | 1u)) > (signed char)(unsigned)(signed char)(5u & 0xffffffffu)));
    L3: if (--fuel == 0u) goto done;
    if (*mp) goto L3;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        u2 = ((g1 + g1) + (unsigned)e0);
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(x0 >> 70), (p1 << ((5u & i2) & 31u)), (unsigned)h1); }
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(r0.y < 0x3f5e5a9au) < (int)(unsigned)f0));
            h1 = (unsigned short)(h1 + (unsigned)((int)~((unsigned)f0 | 3u) < (int)(unsigned)((int)(unsigned)w0 < (int)(unsigned)h1)));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((short)a0[i0 & 3u] > (signed char)0x80000000u), (unsigned)(0xffffffffu < (unsigned)l0), g1); }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)((unsigned)(p0 || i0) && (unsigned)((int)(unsigned)h1 < (int)(unsigned)l0));
                if (((unsigned)(0xffffffffu || u2) >> (p1 & 31u))) break;
                if (p2) break;
                s1 = (int)((unsigned)s1 + ((unsigned)x0 | (unsigned)(unsigned char)(r0.y % ((unsigned)c0 | 1u))));
            } while (i2++ < 4u && 0xb45cc10eu);
            f0 = f0 * 0.5f + (float)((0x17a0e072u / (u0 | 1u)) & 255u);
            if ((~(i0 % ((unsigned)s0 | 1u)) * 0x2c048252u)) continue;
            { unsigned t0; double z0; if (((unsigned)((fuel - r0.y) && 4u)) & 1u) { t0 = 0x96a1b605u; z0 = (double)((a0[u1 & 3u]) & 255u); } if (((unsigned)((fuel - r0.y) && 4u)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                u0 = u0 * 0x9e3779b1u + (((unsigned)((unsigned)x0 == i2) - 0xb6900fe4u) / (m0 | 1u));
                s1 = (int)((unsigned)s1 + (fuel & (unsigned)x0));
            }
            s0 = (int)((fuel % ((unsigned)e0 | 1u)) % (0x80000000u | 1u));
        }
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(0u < u3)) break;
        x0 = x0 * 0x100000001b3ull + (unsigned)d0;
        do { if (--fuel == 0u) goto done;
            b0 = a0[i0 & 3u] != 0u;
            switch ((unsigned)!(i1 >> (g1 & 31u)) & 7u) {
                case 1u: ;
                u1 += ((garr[i1 & 7u] * a0[i0 & 3u]) | (unsigned)!((r0.x / (0x7fffffffu | 1u)) ^ (unsigned)(w0 >> 29)));
                h1 = (unsigned short)(h1 + (r0.x | (unsigned)d0));
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)l0 && 0xffffffffu) & 1023u);
                do { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (unsigned)b0;
                } while (i2++ < 3u && (unsigned)(signed char)(g1 * (unsigned)s1));
            }
            r0.y ^= ((unsigned)(signed char)(0xba4d1dc1u + r0.x) << (((unsigned)(w0 >> 29) << ((unsigned)((int)(unsigned)b0 >= (int)0x80000000u) & 31u)) & 31u));
        } while (i1++ < 4u && 0xffffffffu);
        e0 = e0 * 0.5L + (long double)(((unsigned)(w0 >> 29) << ((garr[i1 & 7u] | ((unsigned)w0 + i2)) & 31u)) & 1023u);
        goto L1;
        a0[0xbc8efb79u & 3u] = (p1 & (i1 << ((unsigned)s0 & 31u)));
    }
    L4: if (--fuel == 0u) goto done;
    goto L4;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (p0 | fuel);
        w0 ^= (unsigned long long)(u3 << (g1 & 31u)) << ((0x6d442fd5u ? (unsigned)c1 : 0xfbc1833eu) & 63u);
        break; (void)((unsigned)h1);
        { unsigned t1; double z1; if (((unsigned)b0) & 1u) { t1 = 0x491eedc4u; z1 = (double)((((g0 << (u2 & 31u)) ^ i0)) & 255u); } if (((unsigned)b0) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            c1 = (signed char)(p2 - (unsigned)(unsigned char)(unsigned)((unsigned)d0 && p1));
            w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)(0xbeb84efu + (unsigned)(unsigned char)(unsigned)((int)0x7e9f6f06u < (int)(unsigned)(0x7fffffffu || (unsigned)!(unsigned)((unsigned)s0 < (unsigned)s1))));
            while (i1++ < 6u && i0) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)h1 < (int)garr[i1 & 7u]));
                if ((*q0 / (~(g0 - r0.y) | 1u))) break;
            }
        }
    }
    { unsigned t2; double z2; if (((unsigned)(0xffffffffu < 0xa1c0bec5u)) & 1u) { t2 = (unsigned)!((unsigned)l0 ? 0xffffffffu : p1); z2 = (double)((g1) & 255u); } if (((unsigned)(0xffffffffu < 0xa1c0bec5u)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        u0 += 0x290c831du;
        u0 ^= (*mp - (unsigned)((unsigned)(x0 >> 70) < (unsigned)s1));
    }
    if (u2) {
        r0.x = 0x9ebec06bu;
    } else {
        h0 = (short)(unsigned)(signed char)(unsigned)((short)g0 > (signed char)(r0.y - (*q0 + 0xffffffffu)));
        if (p1) goto L1;
    }
    if (((unsigned)(x0 >> 70) - 0xa2a020bu)) goto L4;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t3; double z3; if ((((unsigned)c1 + r0.x)) & 1u) { t3 = i2; z3 = (double)((-(unsigned)((unsigned)h0 && 0x828ad4ffu)) & 255u); } if ((((unsigned)c1 + r0.x)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            { unsigned t4; double z4; if ((i0) & 1u) { t4 = (unsigned)c0; z4 = (double)(((unsigned)(u2 < (unsigned)(x0 >> 70))) & 255u); } if ((i0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                h0 = (short)(((r0.x % (0x43ee2008u | 1u)) + 0xe5bb1597u) ? p1 : (unsigned)w0);
                switch (i2 & 7u) {
                    d0 = d0 * 0.5 + (double)(-((unsigned)h0 << (0x6648a078u & 31u)) & 1023u);
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        h0 = (short)(unsigned)h1;
                        l0 = (long)((unsigned long)l0 + (0xb7101891u | 0x43a1a3fbu));
                        case 7u: ;
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn3(*mp, (u3 & (unsigned)d0), i1); }
                    case 4u: ;
                    i0 = (unsigned)((int)((unsigned)s1 ? 0x712f119au : (unsigned)h1) < (int)(unsigned)((int)(unsigned)h0 < (int)garr[u2 & 7u])) & 15u;
                    w0 ^= (unsigned long long)(i2 >> (0x80000000u & 31u)) << (((unsigned)h1 + (unsigned)(short)((unsigned)c0 >> ((1u * fuel) & 31u))) & 63u);
                }
                s1 = (int)((unsigned)s1 + (u1 ^ (unsigned)(garr[u2 & 7u] && (unsigned)b0)));
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((u2 - (unsigned)(0x251e5492u || (unsigned)(w0 >> 29))), (unsigned)(short)((unsigned)(u1 == r0.x) / (6u | 1u)), (unsigned)(-(p1 << (0x47e4a29au & 31u)) < 0x7fffffffu)); }
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn2(a0[i0 & 3u], (unsigned)((int)5u < (int)0xa2ba1499u), -(unsigned)((short)u3 > (signed char)(unsigned)l0)); }
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)l0 == 0x7fffffffu), 5u, m0); }
                    break; (void)(1u);
                    if ((p0 ? (unsigned)h1 : 0x10000u)) break;
                    if ((unsigned)((int)u3 >= (int)((unsigned)(x0 >> 70) | (unsigned)w0))) break;
                }
                if (((unsigned)((int)(unsigned)f0 < (int)(unsigned)(w0 >> 29)) & (unsigned)c1)) break;
                w0 ^= (unsigned long long)7u << ((unsigned)(6u && garr[i1 & 7u]) & 63u);
                switch ((unsigned)((unsigned)(p0 || 0x8162c3dbu) == 0xfecf6eebu) & 7u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0(m0, (0xc8e4a5abu << (i2 & 31u)), p2); }
                    g1 += ((unsigned)l0 ? 4u : 0x10000u);
                }
                if ((unsigned)((int)(unsigned)c0 >= (int)(unsigned)((unsigned)d0 == v0))) break;
                r0.y ^= (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)(unsigned char)((unsigned)(3u || 0x80000000u) + g0));
            }
            e0 = e0 * 0.5L + (long double)((unsigned)((int)(a0[u1 & 3u] - 1u) >= (int)u3) & 1023u);
        }
        *mp = (0xffffffffu >> ((1u >> ((unsigned)(signed char)(0x3027957cu ^ garr[i1 & 7u]) & 31u)) & 31u));
        { unsigned t5; double z5; if ((6u) & 1u) { t5 = (unsigned)((int)1u < (int)garr[i1 & 7u]); z5 = (double)((0x3421ad73u) & 255u); } if ((6u) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
            *q0 += (fuel % ((r0.x ? (unsigned)f0 : (p0 | 0x7fffffffu)) | 1u));
            g0 = (unsigned)((unsigned)s0 == (g0 + r0.x));
            *q0 += (a0[i0 & 3u] ^ ((unsigned)e0 ^ (unsigned)w0));
            while (i1++ < 6u && (unsigned)((int)(unsigned)h1 < (int)(*q0 - (unsigned)h1))) { if (--fuel == 0u) goto done;
                s0 = (int)(unsigned)d0;
                if (0x7fffffffu) {
                    w0 ^= (unsigned long long)(u1 + 0xeb27d626u) << ((unsigned)(short)((unsigned)(w0 >> 29) ? u1 : (unsigned)e0) & 63u);
                    if (budget != 0u) { budget -= 1u; u0 = fn2(p1, (unsigned)((int)0x6c2e0a46u >= (int)(unsigned)((int)i0 < (int)0x80000000u)), i1); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0(~(m0 ^ u1), (unsigned)h1, (unsigned)h1); }
                    if ((unsigned)((int)*q0 < (int)0x10000u)) continue;
                } else {
                    if (0x7fffffffu) {
                        if ((unsigned)s1) break;
                    } else {
                        if (p1) break;
                        if (~(((unsigned)c0 | v0) << ((unsigned)(x0 >> 70) & 31u))) break;
                        if (((unsigned)(a0[u1 & 3u] || r0.x) / ((unsigned)d0 | 1u))) break;
                    }
                    g1 += 0xed23d215u;
                }
                c0 = (unsigned char)0x470222ddu;
            }
            *mp = (0x2d3290b5u & r0.y);
        }
        while (i1++ < 2u && -((unsigned)c1 ^ (unsigned)f0)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)s0 >> (0xbc9c406cu & 31u)), 0x10000u, (unsigned)e0); }
            *q0 = (unsigned)(short)(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)(0x6b3745d9u == ((unsigned)e0 | 0xf4fa5ae6u)));
            c1 = (signed char)-(u1 + (a0[u1 & 3u] ^ (0x80000000u ? a0[u1 & 3u] : a0[i0 & 3u])));
            h0 = (short)(unsigned)((short)0x192f3a90u > (signed char)(unsigned)((int)v0 >= (int)i2));
            while (i2++ < 4u && ((unsigned)((int)r0.y >= (int)garr[u2 & 7u]) ^ (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                while (i0++ < 4u && v0) { if (--fuel == 0u) goto done;
                    break; (void)(1u);
                    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)s0, i1, (unsigned)(0xf9bafba8u == (unsigned)((int)g1 < (int)fuel))); }
                    w0 = w0 * 6364136223846793005ull + (*q0 - (unsigned)w0);
                    if (fuel < 8u) return (unsigned)!(unsigned)((unsigned)h0 < ((unsigned)s0 * (((unsigned)s0 | (unsigned)d0) ^ 0x80000000u)));
                    if (budget != 0u) { budget -= 1u; u0 = fn0(0x80000000u, (unsigned)((short)(fuel / (*mp | 1u)) > (signed char)8u), (i0 + (unsigned)!(r0.x * (unsigned)l0))); }
                }
                do { if (--fuel == 0u) goto done;
                    if ((fuel * i2)) goto L3;
                } while (i0++ < 6u && (unsigned)(0x7fffffffu == 0x5441ebcau));
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn2(fuel, (unsigned)((unsigned)((short)(unsigned)d0 > (signed char)7u) || i2), p1); }
        if (budget != 0u) { budget -= 1u; u1 = fn2(0x62969f5au, (unsigned)h1, (unsigned)(x0 >> 70)); }
    }
    h1 = (unsigned short)(h1 + (a0[i0 & 3u] & (unsigned)((int)i0 < (int)(unsigned)((unsigned)d0 || ~(a0[u1 & 3u] * (unsigned)f0)))));
    u3 = ((unsigned)(0x9d3dae4eu < 0x80000000u) << ((0x10000u << (garr[u2 & 7u] & 31u)) & 31u));
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)w0, (unsigned)((int)0xffffffffu < (int)6u), ((unsigned)!(unsigned)((unsigned)d0 == u1) % ((unsigned)f0 | 1u))); }
    f0 = f0 * 0.5f + (float)(((unsigned)(short)(0x7fffffffu & g0) - (unsigned)s0) & 255u);
    m0 ^= 0u;
    u1 += (unsigned)((int)(unsigned)(unsigned char)(fuel / (0x80000000u | 1u)) >= (int)(unsigned)s0);
    goto L0;
    u1 = u1 * 0x9e3779b1u + (fuel << (((m0 ^ (unsigned)c1) ^ (unsigned)e0) & 31u));
    v0 = (unsigned)(p1 || ((unsigned)s0 | p0));
    if (((unsigned)e0 | r0.x)) {
        goto L3;
    } else {
        if ((3u / (u0 | 1u))) {
            switch (r0.x & 7u) {
                while (i0++ < 2u && ((unsigned)(x0 >> 70) << ((unsigned)((int)p1 < (int)(unsigned)w0) & 31u))) { if (--fuel == 0u) goto done;
                    if (((unsigned)s0 >> (0x80000000u & 31u))) break;
                    if ((unsigned)((int)r0.y < (int)(v0 % (u1 | 1u)))) {
                        if ((((unsigned)d0 + (unsigned)h0) & (unsigned)f0)) continue;
                        case 2u: ;
                        case 4u: ;
                        break; (void)((unsigned)(signed char)(unsigned)((unsigned)h0 || 2u));
                    }
                    continue; (void)((unsigned)((short)p2 > (signed char)6u));
                    if (0xa3ea861fu) goto L3;
                    u3 = u3 * 0x9e3779b1u + (unsigned)(short)(((unsigned)h0 + 0x8dc7d8eu) / ((u2 & v0) | 1u));
                    do { if (--fuel == 0u) goto done;
                        if ((*q0 - (unsigned)(unsigned char)((unsigned)b0 % ((unsigned)(w0 >> 29) | 1u)))) continue;
                        u3 = u3 * 0x9e3779b1u + (unsigned)((int)(7u - 0x800d3279u) < (int)((unsigned)((int)u0 < (int)u0) * 1u));
                        v0 = ((unsigned)(short)(4u % (u0 | 1u)) << ((unsigned)((unsigned)c1 && (i0 + a0[u1 & 3u])) & 31u));
                        if ((*mp ^ (unsigned)b0)) goto L0;
                        a0[(fuel | 0x80000000u) & 3u] = (((unsigned)l0 >> (r0.y & 31u)) | v0);
                        default: ;
                    } while (i1++ < 4u && ((unsigned)c1 | i0));
                }
                w0 ^= (unsigned long long)(unsigned)!(0x80000000u & v0) << (((unsigned)(2u && (unsigned)((int)u1 >= (int)(unsigned)c0)) >> ((0x61c30eb5u / (a0[i0 & 3u] | 1u)) & 31u)) & 63u);
            }
            m0 ^= ((i0 ? 0xa62957cu : (unsigned)(short)(unsigned)((int)i2 >= (int)(unsigned)s0)) + p0);
        }
        h0 = (short)(unsigned)e0;
        do { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)((unsigned)l0 == *mp) * u2), (0x10000u - (unsigned)s0), (unsigned)(garr[u2 & 7u] && g1)); }
                break; (void)(0x3ee04e4u);
                *q0 = ((unsigned)f0 ? u0 : (unsigned)((int)9u < (int)(unsigned)c1));
            }
            if (garr[u2 & 7u]) {
                garr[(unsigned)x0 & 7u] = u2;
                garr[(1u * 0x10000u) & 7u] = (unsigned)((short)6u > (signed char)u2);
            } else {
                goto done;
                l0 = (long)((unsigned long)l0 + (2u / (((unsigned)s0 | (0xffffffffu * (unsigned)f0)) | 1u)));
                while (i1++ < 2u && 0xffffffffu) { if (--fuel == 0u) goto done;
                    if ((u0 % ((unsigned)(short)(8u >> (0xea9ca7b7u & 31u)) | 1u))) break;
                    u0 ^= 0x891fffc7u;
                    r0.y ^= ((unsigned)f0 | ((0xda4a2cd9u | (unsigned)(g1 && (unsigned)(x0 >> 70))) & (unsigned)f0));
                    do { if (--fuel == 0u) goto done;
                        g0 = (unsigned)w0;
                    } while (i2++ < 5u && (7u & (unsigned)d0));
                    u1 ^= (unsigned)(unsigned char)((unsigned)s1 ^ ((unsigned)h1 & (unsigned)((short)0x10000u > (signed char)(unsigned)((unsigned)f0 && 0x80000000u))));
                }
            }
            while (i1++ < 3u && ((unsigned)d0 * ((unsigned)(x0 >> 70) | v0))) { if (--fuel == 0u) goto done;
                if ((((unsigned)x0 - (unsigned)f0) >> (i0 & 31u))) {
                    u3 ^= ((unsigned)x0 | (unsigned)((int)i2 < (int)(unsigned)(0xff96db74u || *q0)));
                    if ((unsigned)((unsigned)x0 && *mp)) continue;
                    if ((*mp ^ (unsigned)(6u < (unsigned)x0))) break;
                    e0 = e0 * 0.5L + (long double)((g1 << (fuel & 31u)) & 1023u);
                    i0 = (0x80000000u * (unsigned)l0) & 15u;
                }
                if ((unsigned)c0) {
                    q0 = &garr[(unsigned)(4u || (unsigned)d0) & 7u];
                    *q0 += (unsigned)(unsigned char)(unsigned)(0x18076e31u && (i1 >> ((unsigned)((int)(unsigned)b0 < (int)m0) & 31u)));
                    for (;;) { if (--fuel == 0u) goto done;
                        if ((6u ? 0x94988cafu : 0xa0704311u)) break;
                        g0 = (unsigned)(unsigned char)((unsigned)e0 ^ g0);
                        if ((unsigned)b0) break;
                    }
                } else {
                    v0 = (unsigned)(signed char)(unsigned)(-((unsigned)((p1 + 5u) < 0xc4234408u) & (unsigned)h0) || garr[i1 & 7u]);
                    c1 = (signed char)((unsigned)(0x7b047a8bu < (unsigned)d0) % ((unsigned)s0 | 1u));
                    c0 = (unsigned char)((v0 - fuel) * v0);
                }
                c1 = (signed char)(unsigned)((unsigned)((int)0x10000u < (int)(unsigned)h1) || ((unsigned)e0 | (unsigned)f0));
                { unsigned t6; double z6; if ((((unsigned)c1 << (r0.x & 31u))) & 1u) { t6 = (unsigned)((short)5u > (signed char)(unsigned)(a0[u1 & 3u] || 0x60d5a0b8u)); z6 = (double)((p0) & 255u); } if ((((unsigned)c1 << (r0.x & 31u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                    a0[g1 & 3u] = (unsigned)((unsigned)(i1 == p0) && 7u);
                    m0 ^= -(((unsigned)h0 % ((unsigned)(short)(unsigned)((unsigned)s1 < p2) | 1u)) & 0x74e29705u);
                    if (budget != 0u) { budget -= 1u; u3 = fn2(1u, (unsigned)(0x7fffffffu || 0x55faca40u), (g0 << (garr[u2 & 7u] & 31u))); }
                    break; (void)(6u);
                    u1 += (unsigned)((unsigned)(0x80000000u || ((unsigned)(x0 >> 70) * i1)) || (u2 * i2));
                }
                u1 ^= (u2 ? r0.x : p1);
            }
            break; (void)((a0[i0 & 3u] | (unsigned)(x0 >> 70)));
            l0 = (long)((unsigned long)l0 + (0x7fffffffu | i2));
        } while (i0++ < 6u && (unsigned)((r0.x & p1) || 8u));
        if ((p0 ^ 0xe38efabu)) goto L2;
    }
    if (((unsigned)(x0 >> 70) & garr[u2 & 7u])) goto L1;
    if (0xee55a443u) goto L4;
    h1 = (unsigned short)(h1 + (unsigned)(short)(unsigned)((unsigned)h1 == (unsigned)c1));
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)w0 < (int)(unsigned)((unsigned)c1 && u1))) break;
        if ((a0[u1 & 3u] & (unsigned)(u0 < 0x7fffffffu))) continue;
    } while (i0++ < 6u && *mp);
    w0 = w0 * 6364136223846793005ull + (unsigned)(r0.y || ((unsigned)((short)p0 > (signed char)i1) / (7u | 1u)));
    if (((unsigned)c1 ^ (unsigned)((int)(unsigned)x0 < (int)p1))) {
        l0 = (long)((unsigned long)l0 + (-(g0 % (r0.y | 1u)) * (unsigned)((int)g1 < (int)g0)));
        m0 ^= (unsigned)((int)3u >= (int)0xffffffffu);
        while (i0++ < 4u && (unsigned)((m0 ^ i0) || g1)) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                g1 += (unsigned)((short)-((unsigned)x0 & r0.x) > (signed char)0x10000u);
                if (budget != 0u) { budget -= 1u; u0 = fn2(garr[u2 & 7u], i1, (u0 | p0)); }
                w0 ^= (unsigned long long)i2 << ((unsigned)((*q0 << (u0 & 31u)) && p0) & 63u);
                if ((unsigned)(6u < (unsigned)w0)) break;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)0x482baa87u >= (int)(unsigned)s0), 6u, 0xb5ce1a73u); }
            *q0 = r0.y;
            if ((unsigned)d0) continue;
            continue; (void)((*mp - 2u));
        }
        q0 = &garr[~((r0.x / (*mp | 1u)) >> ((unsigned)w0 & 31u)) & 7u];
        goto L0;
        a0[((unsigned)s1 + m0) & 3u] = 0x50d13901u;
    }
    switch ((unsigned)((unsigned)x0 || (unsigned)!(0xea414b5bu ^ 0x80000000u)) & 7u) {
        u3 += (unsigned)s0;
        while (i0++ < 7u && (unsigned)((i2 - (unsigned)s1) == (unsigned)e0)) { if (--fuel == 0u) goto done;
            if ((unsigned)!(unsigned)((4u ^ (unsigned)e0) < 0x80000000u)) break;
            switch (0x5e3ccab2u & 7u) {
                if (0x7fffffffu) {
                    if ((unsigned)((short)0x24477f4u > (signed char)u3)) {
                        case 1u: ;
                        i0 = i2 & 15u;
                    }
                    g0 = 9u;
                    break; (void)((unsigned)(0x80000000u && 0xffffffffu));
                    w0 = w0 * 6364136223846793005ull + (unsigned)(7u == (unsigned)h0);
                    l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)((unsigned)((unsigned)(x0 >> 70) < v0) << ((unsigned)(8u < fuel) & 31u)));
                    *q0 = p1;
                }
            }
            u2 = (((unsigned)c1 * 2u) + 8u);
            h1 = (unsigned short)(h1 + (unsigned)((int)((unsigned)(w0 >> 29) * 5u) >= (int)(unsigned)(5u == u0)));
            c0 = (unsigned char)(((unsigned)e0 * (unsigned)h0) + (0x5b85e87bu ? 0x10000u : 0xffffffffu));
            case 5u: ;
        }
    }
    g0 = ((0x7fffffffu | i1) % (1u | 1u));
    while (i0++ < 2u && (unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)c0)) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)((unsigned)d0 ^ (unsigned)(x0 >> 70)) << (((unsigned)l0 * (0xd8ff69f6u * *q0)) & 63u);
            }
        }
        { unsigned t7; double z7; if ((((unsigned)(5u < i1) >> ((unsigned)l0 & 31u))) & 1u) { t7 = (unsigned)((int)~(i1 >> (v0 & 31u)) < (int)(unsigned)(x0 >> 70)); z7 = (double)((((unsigned)e0 + (0xffffffffu ^ (unsigned)c0))) & 255u); } if ((((unsigned)(5u < i1) >> ((unsigned)l0 & 31u))) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
            *mp = (r0.x - (unsigned)(1u == ((unsigned)(w0 >> 29) | u2)));
        }
        break; (void)((unsigned)((unsigned)x0 == (unsigned)b0));
        i1 = (unsigned)(r0.x < ((unsigned)w0 % (8u | 1u))) & 15u;
        w0 = w0 * 6364136223846793005ull + 0x7fffffffu;
    }
    a0[(unsigned)l0 & 3u] = ((unsigned)c1 % (0u | 1u));
    goto done;
    { unsigned t8; double z8; if (((p1 ? (unsigned)e0 : 0x7fffffffu)) & 1u) { t8 = (unsigned)((int)u3 >= (int)3u); z8 = (double)(((0x10000u & 6u)) & 255u); } if (((p1 ? (unsigned)e0 : 0x7fffffffu)) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
        if ((unsigned)((int)(r0.y << (0xa3ff1208u & 31u)) < (int)i0)) goto L4;
    }
    if (fuel < 8u) return (g0 * (unsigned)((int)((unsigned)(i2 || i2) * 0x80000000u) >= (int)r0.y));
    { unsigned t9; double z9; if ((i1) & 1u) { t9 = (m0 % (*q0 | 1u)); z9 = (double)((0xc8aeab04u) & 255u); } if ((i1) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
        e0 = e0 * 0.5L + (long double)((((unsigned)c1 / (u1 | 1u)) | r0.y) & 1023u);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 1u, 0x9508fa35u, 0x652b1b29u },
        { 2u, 0xc2b279e6u, 0x537e918bu },
        { 0u, 0x8a5e38edu, 0xd013bb56u },
        { 8u, 0x4ed18845u, 0xd30cd744u },
        { 4u, 0xe80eecdau, 0x17376775u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
