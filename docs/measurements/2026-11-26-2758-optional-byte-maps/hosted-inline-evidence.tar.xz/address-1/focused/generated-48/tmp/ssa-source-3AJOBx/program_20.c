// test-ssa-source's program of seed 134000422 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x5b55a96au, g1 = 0xaac914deu;
static unsigned garr[8] = { 0xcb7aa315u, 0x439fd7edu, 0x2f4bec18u, 0xdee1da4bu, 0x2f5ee210u, 0x8e0d1a11u, 0xe19e66dcu, 0xdb29d922u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    L1: if (--fuel == 0u) goto done;
    { unsigned t0; double z0; if (((0x7fffffffu & (unsigned)h1)) & 1u) { t0 = (unsigned)((unsigned)h1 < u3); z0 = (double)(((unsigned)((int)i1 >= (int)m0)) & 255u); } if (((0x7fffffffu & (unsigned)h1)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        L2: if (--fuel == 0u) goto done;
    }
    goto done;
    if (((unsigned)x0 % (v0 | 1u))) goto L4;
    r0.y ^= (unsigned)((short)(unsigned)(2u && (unsigned)w0) > (signed char)(unsigned)c1);
    c1 = (signed char)garr[i1 & 7u];
    if ((0x7fffffffu << (p0 & 31u))) goto L2;
    c1 = (signed char)(unsigned)(8u || (unsigned)((int)(unsigned)(*mp < (unsigned)(short)(unsigned)(u1 || i1)) < (int)a0[u1 & 3u]));
    if ((unsigned)((int)1u >= (int)p0)) {
        i2 = ((unsigned)((int)p2 >= (int)u3) | (0u & p1)) & 15u;
        c0 = (unsigned char)(unsigned)((short)0u > (signed char)i0);
    } else {
        goto L2;
    }
    if ((fuel / ((u2 / (g1 | 1u)) | 1u))) {
        q0 = &garr[(i1 & 1u) & 7u];
        w0 ^= (unsigned long long)((unsigned)b0 % (a0[i0 & 3u] | 1u)) << ((unsigned)d0 & 63u);
    } else {
        { unsigned t1; double z1; if (((unsigned)(r0.y < (9u & fuel))) & 1u) { t1 = (unsigned)((short)g1 > (signed char)(unsigned)c1); z1 = (double)(((unsigned)((int)2u >= (int)0xffffffffu)) & 255u); } if (((unsigned)(r0.y < (9u & fuel))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            b0 = (unsigned)((int)0u < (int)(unsigned)(short)(unsigned)(((unsigned)h1 / ((unsigned)h1 | 1u)) && v0)) != 0u;
            s0 = (int)((unsigned)(0xe12d0295u == (unsigned)h0) ^ (unsigned)l0);
            g0 = (unsigned)((unsigned)x0 && g1);
            u1 ^= (unsigned)((u2 - (u1 << ((unsigned)(x0 >> 70) & 31u))) || 0x7fffffffu);
            h0 = (short)r0.x;
        }
        c0 = (unsigned char)((unsigned)(unsigned char)(unsigned)(u2 == 7u) & (unsigned)(p0 == (unsigned)s0));
        goto L4;
    }
    s0 = (int)((unsigned)(0x80000000u && (2u | 0x80000000u)) | u1);
    if (1u) goto done;
    L3: if (--fuel == 0u) goto done;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)l0) {
            if ((unsigned)!(unsigned)(i1 == p0)) break;
            L4: if (--fuel == 0u) goto done;
        } else {
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                i2 = (((unsigned)s0 | i2) - 0x2afdc0a0u) & 15u;
                r0.x = ((g1 * (unsigned)((unsigned)f0 < p1)) | 6u);
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)s1) break;
                    if ((unsigned)b0) break;
                    if (6u) break;
                    if (0x10000u) continue;
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((0x5c1023e4u + (unsigned)(i1 || 0x1d183bb6u))) break;
                        u1 += (unsigned)b0;
                    }
                    if (u3 == 7u) return (3u ^ 0xdc920f4u);
                } while (i2++ < 2u && ((unsigned)x0 << (garr[i1 & 7u] & 31u)));
                if ((unsigned)((3u >> (0x10000u & 31u)) || garr[i1 & 7u])) break;
                { unsigned t2; double z2; if ((((unsigned)d0 * (0x3e0799fbu ^ 5u))) & 1u) { t2 = (0xffffffffu * a0[u1 & 3u]); z2 = (double)((0x7fffffffu) & 255u); } if ((((unsigned)d0 * (0x3e0799fbu ^ 5u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    if (0x10000u) goto L3;
                }
            }
        }
    } while (i0++ < 3u && (unsigned)((unsigned)e0 || 0xb357b9b3u));
    *q0 += (a0[i0 & 3u] - (unsigned)e0);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((garr[u2 & 7u] % ((unsigned)(0x7fffffffu < (0x9ea1c964u + u0)) | 1u)) & 255u);
    }
    u2 = u2 * 0x9e3779b1u + (unsigned)(~(4u | 0x1caa8013u) < 0xb7cecbd6u);
    c0 = (unsigned char)(unsigned)(u2 || (p1 - (unsigned)c1));
    if ((unsigned)l0) goto L4;
    s1 = (int)((unsigned)s1 + (u2 >> (u1 & 31u)));
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)c0 || p1)) continue;
        *q0 = (garr[i1 & 7u] % (((r0.y | (unsigned)s0) | 0xe14ae9a6u) | 1u));
        do { if (--fuel == 0u) goto done;
            if ((g0 | (unsigned)(5u || 0x413364e5u))) break;
            s1 = (int)((unsigned)s1 + (0x7fffffffu * (*q0 << (p1 & 31u))));
            u3 = (unsigned)((int)p1 >= (int)0xc92e0b4du);
            u1 = ((unsigned)!((unsigned)(w0 >> 29) + a0[i0 & 3u]) ? 0x10000u : (0x1f73bdcbu >> (r0.x & 31u)));
        } while (i1++ < 6u && (unsigned)((int)(i0 / (a0[i0 & 3u] | 1u)) < (int)i1));
        *q0 = g1;
        m0 ^= (unsigned)((short)r0.y > (signed char)(unsigned)(p2 == (unsigned)f0));
        break; (void)(p0);
    } while (i0++ < 6u && (unsigned)(v0 < 0x1e84a901u));
    switch ((unsigned)(signed char)(unsigned)((int)0xce2b26beu >= (int)p1) & 7u) {
        switch (~((p0 >> ((unsigned)h1 & 31u)) * 0x80000000u) & 7u) {
            u2 ^= (unsigned)((int)i0 < (int)(v0 | u3));
            f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)((int)(unsigned)l0 < (int)(p2 ? i1 : (unsigned)b0)) >= (int)garr[u2 & 7u]) & 255u);
            *q0 += (unsigned)x0;
            *q0 += (unsigned)(signed char)(unsigned)((short)((unsigned)((short)7u > (signed char)0xe052e848u) << ((unsigned)(short)((unsigned)(x0 >> 70) - 4u) & 31u)) > (signed char)garr[i1 & 7u]);
        }
    }
    switch (a0[i0 & 3u] & 7u) {
        while (i0++ < 3u && (((unsigned)(w0 >> 29) & p2) ^ 0x10000u)) { if (--fuel == 0u) goto done;
            r0.x = *mp;
            c0 = (unsigned char)(unsigned)((unsigned)d0 && (unsigned)h0);
            i0 = u3 & 15u;
            break; (void)(((unsigned)x0 & (unsigned)(p2 == a0[i0 & 3u])));
            l0 = (long)((unsigned long)l0 + (0xaab979e0u + (9u << (u0 & 31u))));
        }
        if ((unsigned)s0) goto L2;
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (a0[u1 & 3u]) {
                if ((1u - r0.y)) {
                    u0 += (0xffffffffu + (unsigned)(g0 || (unsigned)x0));
                    b0 = (unsigned)((unsigned)b0 && a0[u1 & 3u]) != 0u;
                    case 5u: ;
                    while ((unsigned)(m0 || (unsigned)h0)) { if (--fuel == 0u) goto done;
                        *q0 = (unsigned)!((unsigned)(0x80000000u && (unsigned)h1) ^ (((unsigned)x0 % (5u | 1u)) << (0x10000u & 31u)));
                        u2 += fuel;
                        for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                            u2 = (unsigned)(unsigned char)(unsigned)(0xffffffffu < i2);
                        }
                        break; (void)((unsigned)((int)0xcae56532u >= (int)(u3 * i1)));
                    }
                } else {
                    if (0x81141de0u) break;
                    if (0x2d4a9f29u) goto L3;
                    g1 += ((unsigned)((short)6u > (signed char)0x80000000u) + u3);
                }
                u2 ^= (garr[i1 & 7u] / ((garr[i1 & 7u] ? u0 : p1) | 1u));
            } else {
                u0 = (0xffffffffu << ((unsigned)l0 & 31u));
                u0 += ((unsigned)((unsigned)w0 && (9u * (unsigned)x0)) & p1);
                u1 ^= (unsigned)(unsigned char)((v0 >> ((unsigned)h1 & 31u)) + (0u & (unsigned)((int)p1 >= (int)0x308a0747u)));
                a0[p1 & 3u] = (unsigned)((unsigned)x0 < (unsigned)((short)0x10000u > (signed char)0xb5782b78u));
            }
            case 4u: ;
            if (0u) break;
            if ((unsigned)(a0[u1 & 3u] == garr[u2 & 7u])) goto L0;
            h1 = (unsigned short)(h1 + 0x80000000u);
        }
        goto L1;
        u3 += ((unsigned)h0 << (7u & 31u));
    }
    if ((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)c0)) goto L0;
    s1 = (int)((unsigned)s1 + (unsigned)(0x10000u && (unsigned)h0));
    if ((u2 + i0)) {
        if (((unsigned)s0 ^ ((unsigned)s1 - i0))) goto L2;
    } else {
        goto L1;
        c0 = (unsigned char)(unsigned)s0;
    }
    switch (6u & 7u) {
        r0.y ^= (i1 >> (((unsigned)((unsigned)h1 || i0) - (unsigned)(u2 == a0[u1 & 3u])) & 31u));
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch (((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)c1) | garr[u2 & 7u]) & 7u) {
                case 6u: ;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + (unsigned)(u0 == (*q0 >> (0xe4077c42u & 31u))));
                        if (fuel < 8u) return -((0x5a3fd03cu ^ (unsigned)c0) >> (~(p1 | (0xffffffffu + i2)) & 31u));
                        w0 ^= (unsigned long long)p0 << ((unsigned)(0x10000u == (unsigned)(*mp || (unsigned)((int)r0.y < (int)(0x7fffffffu >> (0xf2cda7a1u & 31u))))) & 63u);
                    } while (i2++ < 4u && ((unsigned)s1 & i0));
                    { unsigned t3; double z3; if (((unsigned)c1) & 1u) { t3 = ((unsigned)((int)garr[i1 & 7u] >= (int)0xb737b395u) - 0x7fffffffu); z3 = (double)((0xb35d164bu) & 255u); } if (((unsigned)c1) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        q0 = &garr[(unsigned)((p1 - (unsigned)h0) < (0x317bc2f7u / (i2 | 1u))) & 7u];
                        case 2u: ;
                    }
                }
                g0 = g0;
                case 0u: ;
                u3 ^= (0xffffffffu >> ((((unsigned)((int)6u >= (int)(unsigned)h0) + (unsigned)l0) + *q0) & 31u));
                continue; (void)(((8u & 9u) / ((unsigned)d0 | 1u)));
            }
            f0 = f0 * 0.5f + (float)((unsigned)((((unsigned)!(unsigned)((unsigned)b0 || 0x10000u) | i1) << ((unsigned)(x0 >> 70) & 31u)) < 0x70d7d284u) & 255u);
            *mp = (unsigned)((int)(unsigned)(u1 == (unsigned)((int)0x6b6eb276u >= (int)*mp)) < (int)i2);
            goto done;
            u1 += (a0[u1 & 3u] ^ (u2 * (unsigned)s1));
            case 2u: ;
        }
        case 0u: ;
        m0 ^= ~(unsigned)((int)(unsigned)b0 < (int)(g0 / ((unsigned)e0 | 1u)));
    }
    if ((0xe51f69c7u << (u0 & 31u))) goto L2;
    if (a0[i0 & 3u]) {
        u1 = (unsigned)c1;
        if ((unsigned)(signed char)(0x10000u ? 0xc0d05c98u : (unsigned)h0)) goto done;
    }
    h1 = (unsigned short)(h1 + (unsigned)(short)(unsigned)(u2 && (8u ^ fuel)));
    while (i0++ < 5u && (unsigned)(signed char)((4u << (0x5612474au & 31u)) & 0x9ee20acdu)) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            *mp = (unsigned)((unsigned)(*mp == a0[i0 & 3u]) && (unsigned)!((unsigned)((short)i2 > (signed char)0xffffffffu) & u1));
        }
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)d0) goto L1;
        }
        h1 = (unsigned short)(h1 + ((u2 << ((unsigned)x0 & 31u)) | 0x10000u));
        break; (void)((u1 % (p0 | 1u)));
        c0 = (unsigned char)((unsigned)x0 << (0u & 31u));
    }
    q0 = &garr[(0xb23aa797u % ((unsigned)((short)(unsigned)((int)p0 < (int)0x3dd05916u) > (signed char)a0[i0 & 3u]) | 1u)) & 7u];
    goto done;
    do { if (--fuel == 0u) goto done;
        switch (0x32a4a9au & 7u) {
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= ((unsigned)(v0 && (unsigned)(x0 >> 70)) * (unsigned)((unsigned)((int)(unsigned)s1 < (int)0xffffffffu) == (unsigned)f0));
                s0 = (int)r0.x;
            }
            u2 += (unsigned)(short)(unsigned)((unsigned)l0 && u2);
        }
        if ((unsigned)!(4u >> ((unsigned)(x0 >> 70) & 31u))) {
            u1 = (unsigned)x0;
            continue; (void)((unsigned)(short)(p0 / (0x2eaeb771u | 1u)));
            { unsigned t4; double z4; if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0u)) & 1u) { t4 = (0x4f26983eu * u0); z4 = (double)(((unsigned)h1) & 255u); } if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0u)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                u1 += (p0 | p0);
                break; (void)((0x7fffffffu * (m0 / (8u | 1u))));
            }
            if ((unsigned)l0) continue;
            { unsigned t5; double z5; if (((unsigned)l0) & 1u) { t5 = (0x80000000u ? (unsigned)e0 : 0xb7d4229bu); z5 = (double)((p0) & 255u); } if (((unsigned)l0) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                l0 = (long)((unsigned long)l0 + (0x7fffffffu | (unsigned)(unsigned char)((unsigned)((unsigned)(x0 >> 70) == 0xffffffffu) | (unsigned)((unsigned)c0 && u3))));
                if (5u) goto L4;
                e0 = e0 * 0.5L + (long double)(((unsigned)(7u || (unsigned)x0) ? (unsigned)(x0 >> 70) : (unsigned)(x0 >> 70)) & 1023u);
                if ((unsigned)(-(v0 - p0) && garr[i1 & 7u])) break;
                m0 ^= *q0;
            }
            l0 = (long)((unsigned long)l0 + u1);
        }
        goto L4;
    } while (i0++ < 5u && (unsigned)((unsigned)(w0 >> 29) && ((unsigned)(x0 >> 70) | (unsigned)s0)));
    if (i0) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + u3;
        *q0 = (g1 | u0);
        if (budget != 0u) { budget -= 1u; u3 = fn0(((0x7fffffffu % (p1 | 1u)) << (0x80000000u & 31u)), garr[i1 & 7u], (unsigned)((unsigned)((unsigned)w0 == i2) || (unsigned)w0)); }
        *q0 = i0;
        f0 = f0 * 0.5f + (float)((7u + ((unsigned)((int)((unsigned)s1 << (*q0 & 31u)) < (int)p0) / (i2 | 1u))) & 255u);
    }
    goto L2;
    L0: if (--fuel == 0u) goto done;
    switch ((unsigned)((short)2u > (signed char)(*mp << (p0 & 31u))) & 7u) {
        if (garr[u2 & 7u]) break;
        L1: if (--fuel == 0u) goto done;
    }
    *q0 = (unsigned)!(fuel >> ((unsigned)((short)*q0 > (signed char)(unsigned)e0) & 31u));
    b0 = fuel != 0u;
    while (i0++ < 5u && (unsigned)b0) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)((int)(1u ? fuel : 1u) < (int)0x3bf78443u);
        g1 += (u2 + (unsigned)((short)(unsigned)c1 > (signed char)a0[i0 & 3u]));
        r0.y ^= (unsigned)(w0 >> 29);
    }
    if ((0x80000000u >> (r0.x & 31u))) goto L4;
    c0 = (unsigned char)i1;
    if ((unsigned)((int)(i0 / (u2 | 1u)) < (int)r0.x)) goto L2;
    if ((unsigned)(signed char)((0xdc1da9b6u / ((unsigned)l0 | 1u)) ^ 1u)) goto L1;
    *mp = ((unsigned)(signed char)(*q0 * (unsigned)b0) | (unsigned)((int)0x7fffffffu < (int)(unsigned)((unsigned)x0 == 0xd22c7850u)));
    if (((unsigned)d0 * (unsigned)c0)) {
        L2: if (--fuel == 0u) goto done;
        garr[(garr[i1 & 7u] * (unsigned)s1) & 7u] = r0.x;
        if (0xbfe04a46u) {
            garr[(unsigned)(1u == *q0) & 7u] = (((unsigned)l0 | (unsigned)c1) - (unsigned)(x0 >> 70));
            if (budget != 0u) { budget -= 1u; u0 = fn0(p0, ((unsigned)b0 << ((unsigned)c0 & 31u)), (unsigned)(8u && (unsigned)e0)); }
            if ((unsigned)l0) goto done;
            u3 += (unsigned)(unsigned char)(unsigned)((short)~(unsigned)((unsigned)h0 && 5u) > (signed char)garr[u2 & 7u]);
            while (i0++ < 3u && (0xffffffffu | 1u)) { if (--fuel == 0u) goto done;
                if (r0.y) break;
                if (u3 == 7u) return r0.x;
                if ((0x3647686cu / (p2 | 1u))) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0((a0[i0 & 3u] - 0x7a2f4dbeu), (unsigned)((int)r0.x >= (int)((unsigned)(w0 >> 29) >> (0xf2a8fc36u & 31u))), -(*q0 + fuel)); }
                m0 ^= (unsigned)l0;
            }
        }
        if ((unsigned)((short)(unsigned)(a0[u1 & 3u] < u0) > (signed char)0xb2558db6u)) {
            *mp = ((*mp & (unsigned)d0) & (unsigned)(0x80000000u < p1));
            L3: if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
        }
        if ((u3 >> ((unsigned)!(0x6f9b37b4u | (unsigned)l0) & 31u))) goto L2;
        x0 = x0 * 0x100000001b3ull + ((unsigned)((int)u2 >= (int)(unsigned)!(0x7fffffffu - (unsigned)s1)) >> (0x8b38aefu & 31u));
    } else {
        w0 = w0 * 6364136223846793005ull + (unsigned)(((unsigned)e0 - 0u) < v0);
    }
    do { if (--fuel == 0u) goto done;
        m0 ^= (unsigned)(0xa41b1f1du || ((unsigned)s1 | i0));
        w0 ^= (unsigned long long)(unsigned)h1 << ((0xffffffffu << ((unsigned)h0 & 31u)) & 63u);
        while (i1++ < 7u && (p2 ^ 9u)) { if (--fuel == 0u) goto done;
            if (2u) break;
            if (~(~((unsigned)(w0 >> 29) * p1) | 2u)) break;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(7u == 0x7fffffffu), ((unsigned)(0x10000u == 0x6be1f6d0u) ^ 0xffffffffu), 0xfa2f3009u); }
        while (i1++ < 5u && (unsigned)((unsigned)(x0 >> 70) && (unsigned)(a0[i0 & 3u] && (unsigned)d0))) { if (--fuel == 0u) goto done;
            while (i2++ < 6u && (unsigned)(signed char)((unsigned)x0 * (unsigned)s0)) { if (--fuel == 0u) goto done;
                while (i0++ < 4u && ~((p2 - (unsigned)h0) & garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                    if (u3) break;
                    l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)c1 / ((unsigned)c0 | 1u)) >= (int)i2));
                    if ((unsigned)(*mp && ((unsigned)c1 * g0))) goto L0;
                    *q0 = ((unsigned)((int)(unsigned)c0 >= (int)r0.x) >> ((a0[u1 & 3u] | 0x99f0060bu) & 31u));
                    break; (void)(((m0 << (p0 & 31u)) ^ (unsigned)s0));
                    *mp = (unsigned)(((i0 - 5u) / ((unsigned)d0 | 1u)) && (unsigned)e0);
                }
                u3 = ((i1 & p2) * (unsigned)((short)4u > (signed char)(*mp ^ (unsigned)h0)));
                while (i0++ < 3u && p0) { if (--fuel == 0u) goto done;
                    if (0xffffffffu) goto L2;
                }
                while ((unsigned)f0) { if (--fuel == 0u) goto done;
                    break; (void)(u3);
                    break; (void)((0x10000u * 0x80000000u));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)x0, (unsigned)(short)(0xd8ba336eu >> (0x80000000u & 31u)), ((7u % ((unsigned)w0 | 1u)) & (unsigned)s0)); }
                    break; (void)((unsigned)((int)(unsigned)b0 >= (int)0x10000u));
                }
            }
            g1 += -((unsigned)(short)(u2 | 0x80000000u) | 0x80000000u);
            if ((v0 >> ((unsigned)((short)i1 > (signed char)r0.x) & 31u))) goto L4;
            v0 = (unsigned)((int)u0 >= (int)(unsigned)((short)0x7fffffffu > (signed char)(*q0 | (unsigned)h1)));
        }
    } while (i0++ < 4u && (p2 % ((unsigned)c0 | 1u)));
    if (budget != 0u) { budget -= 1u; u2 = fn0((0xc14afdeu / ((unsigned)((int)0x92e44640u >= (int)(unsigned)s1) | 1u)), ((unsigned)x0 << ((unsigned)(i2 < 6u) & 31u)), (unsigned)(0x203bb48u < (2u << (g1 & 31u)))); }
    if (((unsigned)s0 & (m0 >> (m0 & 31u)))) {
        switch ((unsigned)((int)garr[u2 & 7u] < (int)0xffffffffu) & 7u) {
            case 0u: ;
            case 3u: ;
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((4u * garr[u2 & 7u])) break;
                if ((unsigned)h1) break;
                f0 = f0 * 0.5f + (float)((g0 ^ (unsigned)l0) & 255u);
                c0 = (unsigned char)u0;
            }
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(u2 | *mp) << ((unsigned)((unsigned)w0 || 8u) & 63u);
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)c1, -((unsigned)l0 & 0x610e5a04u), garr[u2 & 7u]); }
                u2 = u2 * 0x9e3779b1u + ((fuel / (u1 | 1u)) & (unsigned)((int)2u < (int)(i1 >> ((unsigned)(x0 >> 70) & 31u))));
            } while (i0++ < 4u && (unsigned)h1);
            u3 = u3 * 0x9e3779b1u + ((p0 >> ((unsigned)((unsigned)l0 < 0x346e9b3fu) & 31u)) * (unsigned)(0x80000000u == g0));
        }
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)r0.x < (int)(unsigned)(0x10000u || r0.x));
        while (((unsigned)(u0 || fuel) & 0u)) { if (--fuel == 0u) goto done;
            *q0 = ((unsigned)s1 / ((unsigned)(signed char)(0x12797cdcu - a0[u1 & 3u]) | 1u));
            x0 = x0 * 0x100000001b3ull + (unsigned)(0x7fffffffu < (unsigned)l0);
            if ((unsigned)l0) break;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)garr[i1 & 7u] < (int)(unsigned)(0xc9de5b96u == (unsigned)h1)), (unsigned)(unsigned char)((unsigned)h1 * 0x23a4698du), ((unsigned)h0 - (unsigned)c1)); }
            } while (i1++ < 5u && (unsigned)(i0 == (unsigned)((int)(unsigned)(x0 >> 70) < (int)v0)));
            { unsigned t0; double z0; if (((unsigned)c0) & 1u) { t0 = (((unsigned)(x0 >> 70) % (p0 | 1u)) & i0); z0 = (double)((i1) & 255u); } if (((unsigned)c0) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                break; (void)((a0[i0 & 3u] >> (garr[i1 & 7u] & 31u)));
            }
        }
        if (u3 == 7u) return (unsigned)(signed char)(unsigned)(u2 && i2);
        goto L1;
    } else {
        do { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(v0 | 5u) << ((((unsigned)d0 - g1) / (0xad8284cdu | 1u)) & 63u);
            while (i1++ < 2u && 9u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0(r0.x, (u2 % (-(unsigned)(i1 == (unsigned)x0) | 1u)), (v0 & m0)); }
                r0.y ^= (unsigned)((int)garr[i1 & 7u] < (int)(v0 ? garr[i1 & 7u] : (unsigned)(w0 >> 29)));
                if (((unsigned)((int)(unsigned)h1 < (int)0xc65eb00au) - *q0)) {
                    if ((unsigned)(g1 || (unsigned)c1)) goto L0;
                    break; (void)(0x10000u);
                    if ((a0[i0 & 3u] & i0)) break;
                    goto done;
                } else {
                    { unsigned t1; double z1; if ((*q0) & 1u) { t1 = (1u | a0[u1 & 3u]); z1 = (double)(((0xffffffffu + 0x7fffffffu)) & 255u); } if ((*q0) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                        c0 = (unsigned char)(p0 + (0xe67740b7u | (0xe1810c26u % ((unsigned)d0 | 1u))));
                        r0.x = (p2 >> ((unsigned)((int)0x80000000u >= (int)*mp) & 31u));
                        if ((unsigned)(x0 >> 70)) break;
                        if ((unsigned)c1) break;
                        i2 = (3u ^ i0) & 15u;
                    }
                    f0 = f0 * 0.5f + (float)(((unsigned)(0x58fb696fu < (unsigned)h1) % ((unsigned)(signed char)(unsigned)((unsigned)b0 == r0.y) | 1u)) & 255u);
                    f0 = f0 * 0.5f + (float)((p1 * (unsigned)(x0 >> 70)) & 255u);
                }
                continue; (void)(0xffffffffu);
                if ((unsigned)(signed char)(u1 * (unsigned)(unsigned char)(*q0 / ((unsigned)s1 | 1u)))) break;
            }
            switch (((unsigned)((int)0x80000000u >= (int)(unsigned)c1) + 0u) & 7u) {
                if ((unsigned)h1) {
                    case 6u: ;
                    h0 = (short)(unsigned)(short)(unsigned)((int)(0x1137a16bu | (unsigned)((short)v0 > (signed char)(unsigned)(0xbb1bc2b7u < 0u))) >= (int)(unsigned)h0);
                    if ((u1 % ((unsigned)(0x850ad532u && (unsigned)e0) | 1u))) continue;
                    if ((0x93b2689cu % (7u | 1u))) break;
                }
                { unsigned t2; double z2; if ((0x272594bcu) & 1u) { t2 = g1; z2 = (double)(((unsigned)(i2 == (garr[u2 & 7u] * 0x20abf1dau))) & 255u); } if ((0x272594bcu) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    v0 = (unsigned)(g1 && (0x1b4c1b0cu - (i1 - (unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) || (unsigned)d0))));
                    garr[0x3400d9c6u & 7u] = (unsigned)((unsigned)(short)(u1 * 0x857ccc3u) && (unsigned)d0);
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        g0 = (a0[i0 & 3u] % (u2 | 1u));
                        if (budget != 0u) { budget -= 1u; u0 = fn0((0xc7051ef7u << ((unsigned)(0x38e75293u < (unsigned)s0) & 31u)), 0xf0947a25u, (0x6e848541u - (unsigned)((unsigned)c0 < u1))); }
                        v0 = (unsigned)((int)(unsigned)!(unsigned)((unsigned)b0 < (unsigned)b0) < (int)0x10000u);
                        q0 = &garr[7u & 7u];
                        if ((u3 >> ((p2 + 2u) & 31u))) break;
                        for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                            case 0u: ;
                            u2 = u2 * 0x9e3779b1u + (0xf408a4acu * (unsigned)!((unsigned)e0 | garr[i1 & 7u]));
                            if ((unsigned)(garr[i1 & 7u] && garr[i1 & 7u])) goto L0;
                        }
                    }
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        case 2u: ;
                        case 1u: ;
                        default: ;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(i2, ((unsigned)e0 & -(0xb24d8ee4u >> (p2 & 31u))), (unsigned)((short)(unsigned)h1 > (signed char)*mp)); }
                    }
                    a0[(0x7fffffffu | g1) & 3u] = ((unsigned)(g1 < 0xa95eefd0u) / ((p1 * 9u) | 1u));
                }
                case 3u: ;
                m0 ^= (0x82177f91u / (((unsigned)f0 * ~(unsigned)((int)g0 >= (int)(unsigned)((unsigned)w0 == i0))) | 1u));
            }
            g0 = i0;
            if (u0) continue;
        } while (i0++ < 6u && 0xffffffffu);
        goto L1;
        a0[p0 & 3u] = (unsigned)!((unsigned)(g1 && 0u) - (unsigned)c1);
        *mp = (((garr[i1 & 7u] + g1) & (unsigned)((int)(unsigned)x0 < (int)(unsigned)s1)) * r0.x);
    }
    s0 = (int)(unsigned)(u0 < g0);
    g1 += (unsigned)((unsigned)(0x9b33ef8au || (unsigned)d0) < ~(u2 ? p2 : (unsigned)s1));
    if (((unsigned)h1 % (u2 | 1u))) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(unsigned char)((unsigned)((int)6u < (int)v0) % ((unsigned)h0 | 1u)), (unsigned)(fuel < (unsigned)f0), (unsigned)((int)(unsigned)((int)0x80000000u >= (int)i0) >= (int)u2)); }
        s0 = (int)((unsigned)h1 - (unsigned)(0x88c4600eu == (4u ^ i0)));
        if (a0[i0 & 3u]) {
            goto L1;
            while (i0++ < 4u && garr[u2 & 7u]) { if (--fuel == 0u) goto done;
                if ((0xffffffffu & (unsigned)((unsigned)c0 < p1))) goto done;
                u2 += (unsigned)(short)((unsigned)b0 ? (i1 | a0[i0 & 3u]) : (unsigned)b0);
                if ((unsigned)(9u && (unsigned)l0)) break;
                if ((u3 / ((unsigned)(*q0 == 9u) | 1u))) goto L4;
            }
            goto L2;
            b0 = (unsigned)(-(r0.y ? garr[i1 & 7u] : *mp) || garr[i1 & 7u]) != 0u;
        }
        d0 = d0 * 0.5 + (double)(i2 & 1023u);
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((u2 / (0x80000000u | 1u)) << (u1 & 31u)), (unsigned)(0x1a4dc451u == i0), (unsigned)((int)a0[i0 & 3u] >= (int)(u0 * (unsigned)(x0 >> 70)))); }
            while (i1++ < 6u && (unsigned)h1) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(((i0 >> ((unsigned)d0 & 31u)) / (0x5a11be65u | 1u)), (*mp % ((unsigned)c1 | 1u)), (unsigned)((int)0x7fffffffu >= (int)p2)); }
                if ((garr[u2 & 7u] * 8u)) break;
            }
            u3 = (unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) == (r0.y ? a0[i0 & 3u] : 0xb42553afu));
        } while (i0++ < 6u && (unsigned)(((unsigned)w0 >> (p0 & 31u)) == garr[u2 & 7u]));
    } else {
        w0 ^= (unsigned long long)(unsigned)f0 << (((r0.x - (9u >> (0x7fffffffu & 31u))) & (unsigned)(unsigned char)((unsigned)h0 & 0xfb8c765du)) & 63u);
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x80000000u && m0), (-(unsigned)(fuel < garr[u2 & 7u]) / (g0 | 1u)), a0[u1 & 3u]); }
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            *mp = ((unsigned)b0 * (unsigned)(x0 >> 70));
            if (budget != 0u) { budget -= 1u; u2 = fn0((p0 & (unsigned)e0), (0u / ((unsigned)((int)0x367d19e8u < (int)(unsigned)e0) | 1u)), (unsigned)b0); }
            while (i1++ < 4u && (unsigned)((int)0x7fffffffu >= (int)(unsigned)l0)) { if (--fuel == 0u) goto done;
                while (i2++ < 4u && r0.y) { if (--fuel == 0u) goto done;
                    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(-(*mp + (u1 * (unsigned)d0)), ((unsigned)(w0 >> 29) & ((unsigned)w0 + 0xffffffffu)), (unsigned)w0); }
                    }
                }
                if (r0.y) break;
                if ((unsigned)((unsigned)e0 && (unsigned)(signed char)(unsigned)(u3 || *mp))) goto L2;
            }
            if (u3 == 7u) return (0xeeb6d896u / ((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)(w0 >> 29)) | 1u));
            c1 = (signed char)(i1 ? (0x10000u >> ((a0[i0 & 3u] - (unsigned)f0) & 31u)) : (unsigned)b0);
            if (fuel < 8u) return (garr[i1 & 7u] + (unsigned)((unsigned)h1 || 0xab030b4fu));
        }
    }
    u2 ^= ((unsigned)((int)p1 >= (int)(unsigned)(w0 >> 29)) % (5u | 1u));
    if ((unsigned)((unsigned)!(unsigned)((int)(unsigned)l0 < (int)6u) || 0x1aa739c6u)) goto L2;
    do { if (--fuel == 0u) goto done;
        if ((0x8aa278c7u + (unsigned)h0)) goto L4;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            v0 = i2;
        }
        switch ((unsigned)((unsigned)c1 == 0xf6de6b28u) & 7u) {
            x0 = x0 * 0x100000001b3ull + (a0[i0 & 3u] % (0xffffffffu | 1u));
            *q0 = (unsigned)!(unsigned)((unsigned)((int)v0 >= (int)4u) < ((unsigned)x0 ^ -((unsigned)h1 / (i2 | 1u))));
        }
        if (3u) {
            if ((a0[u1 & 3u] | (unsigned)(signed char)(r0.y >> (p2 & 31u)))) goto L1;
            switch ((unsigned)h0 & 7u) {
                case 4u: ;
                u3 ^= (-(0x64a6ee5cu ^ (unsigned)d0) / (1u | 1u));
                if ((m0 ^ 0x3d904662u)) {
                    x0 = x0 * 0x100000001b3ull + (u3 + u3);
                }
                *mp = (unsigned)e0;
                v0 = v0;
                if (0xffffffffu) goto L1;
            }
            if ((unsigned)(0x567b79c2u && ~(0xc8d649u % (0x7fffffffu | 1u)))) goto done;
            { unsigned t3; double z3; if (((unsigned)((int)(unsigned)s1 >= (int)(u3 | u2))) & 1u) { t3 = (m0 << (6u & 31u)); z3 = (double)(((m0 ? g1 : 3u)) & 255u); } if (((unsigned)((int)(unsigned)s1 >= (int)(u3 | u2))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                switch ((0x1dc0013eu ^ (unsigned)w0) & 7u) {
                    w0 ^= (unsigned long long)(unsigned)((short)r0.x > (signed char)garr[i1 & 7u]) << (u1 & 63u);
                }
                h0 = (short)(i1 & (unsigned)e0);
                w0 ^= (unsigned long long)0x7fffffffu << ((unsigned)(signed char)((3u * u3) / ((unsigned)(signed char)((unsigned)(g1 == a0[u1 & 3u]) / ((unsigned)(w0 >> 29) | 1u)) | 1u)) & 63u);
                break; (void)(p2);
            }
            if (u3 == 7u) return (r0.y / (~(unsigned)((int)0x10000u < (int)0u) | 1u));
        }
        if (i2) {
            g1 += ((unsigned)l0 / ((unsigned)w0 | 1u));
            goto L4;
            w0 = w0 * 6364136223846793005ull + ((unsigned)(v0 < (unsigned)((short)(unsigned)x0 > (signed char)0x80000000u)) << (0x7fffffffu & 31u));
            g0 = ((p2 - 0x80000000u) << ((unsigned)l0 & 31u));
            goto L0;
            { unsigned t4; double z4; if ((p0) & 1u) { t4 = (*q0 * (unsigned)((short)0x7fffffffu > (signed char)(unsigned)s1)); z4 = (double)(((p1 * (unsigned)((unsigned)w0 == 0xffffffffu))) & 255u); } if ((p0) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(x0 >> 70), (unsigned)f0, (unsigned)((short)(a0[i0 & 3u] + (unsigned)x0) > (signed char)(unsigned)b0)); }
                if ((unsigned)((int)(8u - 0x7fffffffu) < (int)i0)) goto L4;
            }
        } else {
            v0 = ((unsigned)(unsigned char)(p1 >> (*mp & 31u)) ? (unsigned)l0 : 0x948915fau);
            if ((r0.x * u1)) break;
            if (0x6c2dff48u) break;
        }
    } while (i0++ < 5u && ((*mp ^ g0) & u0));
    while (((0x7fffffffu - 0x7ee65987u) >> (0xf80e156cu & 31u))) { if (--fuel == 0u) goto done;
        if (3u) break;
        r0.x = (unsigned)((short)(unsigned)(signed char)(unsigned)(r0.x == (unsigned)(signed char)((unsigned)f0 & garr[u2 & 7u])) > (signed char)(unsigned)c0);
        v0 = ((unsigned)h0 ^ v0);
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(unsigned char)(unsigned)((unsigned)e0 || garr[u2 & 7u]), (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)b0), (unsigned)h1); }
        r0.y ^= (unsigned)(signed char)((m0 & (unsigned)h0) >> ((unsigned)b0 & 31u));
    }
    g0 = 0x239d999eu;
    if (4u) goto done;
    if ((i2 << (0xfd283590u & 31u))) {
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)h1 < 0xffffffffu), garr[i1 & 7u], garr[i1 & 7u]); }
        if (budget != 0u) { budget -= 1u; u1 = fn0(g0, (9u << (fuel & 31u)), (unsigned)((int)(unsigned)f0 < (int)~(p1 % (i0 | 1u)))); }
        if (0x80000000u) goto L1;
    }
    goto L3;
    if (((unsigned)f0 << ((unsigned)((int)i2 < (int)(unsigned)e0) & 31u))) {
        if (u3 == 7u) return (*mp % ((unsigned)c0 | 1u));
        u3 += (unsigned)!(((unsigned)l0 ^ (unsigned)c1) & (unsigned)(w0 >> 29));
        if ((unsigned)((int)(unsigned)h0 < (int)(7u << (r0.x & 31u)))) goto done;
        if (m0) goto L1;
    }
    *mp = ((p0 - (unsigned)s1) << ((4u | (0x80000000u + (unsigned)d0)) & 31u));
    r0.x = (unsigned)((r0.y / ((unsigned)s1 | 1u)) < (u1 << (0xffffffffu & 31u)));
    c1 = (signed char)((unsigned)!(garr[u2 & 7u] + r0.y) * 2u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(p0 && u3), ((unsigned)f0 * (unsigned)d0), ((unsigned)w0 >> (1u & 31u))); }
    switch (((unsigned)((unsigned)s0 < (unsigned)b0) - (unsigned)c1) & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn1((0xd2c5d8c4u ^ (unsigned)(w0 >> 29)), (unsigned)(p2 == (unsigned)h0), 0xbcdc0a7du); }
        if (u3 == 7u) return i2;
        { unsigned t0; double z0; if (((0x80000000u | (unsigned)((int)r0.x < (int)(unsigned)(x0 >> 70)))) & 1u) { t0 = -((unsigned)((int)v0 >= (int)0x24b89a48u) + 0x80000000u); z0 = (double)(((unsigned)((int)0xfacf6195u >= (int)(unsigned)h0)) & 255u); } if (((0x80000000u | (unsigned)((int)r0.x < (int)(unsigned)(x0 >> 70)))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            if (u3 == 7u) return ((unsigned)((int)v0 >= (int)*q0) * (fuel << (g0 & 31u)));
        }
        if ((((unsigned)l0 << (fuel & 31u)) ^ g1)) {
            if (fuel < 8u) return 0xe94f671fu;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1(((g0 - (unsigned)w0) / (u1 | 1u)), ~(i1 + 0x5c927367u), ((unsigned)(unsigned char)(6u ^ p1) >> (r0.y & 31u))); }
                for (;;) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + ((unsigned)(i0 == 1u) / ((unsigned)((short)0x80000000u > (signed char)(unsigned)((int)u3 < (int)u1)) | 1u));
                    c1 = (signed char)((unsigned)w0 % ((unsigned)!(unsigned)(((p0 ^ u2) | 0x80000000u) < (unsigned)b0) | 1u));
                    b0 = ((r0.x ^ v0) ^ 0xffffffffu) != 0u;
                    L0: if (--fuel == 0u) goto done;
                }
                goto done;
                u0 = (0x7fffffffu & (unsigned)(x0 >> 70));
            } while (i0++ < 4u && 0x80000000u);
            h1 = (unsigned short)(h1 + (unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)(*q0 == p2)));
            e0 = e0 * 0.5L + (long double)(((unsigned)!(unsigned)((short)((unsigned)h0 * r0.y) > (signed char)v0) ^ 0x2d56ef1fu) & 1023u);
            case 5u: ;
        }
        if ((fuel << (2u & 31u))) goto L2;
    }
    m0 ^= (unsigned)(short)(unsigned)(((unsigned)h1 & (unsigned)(unsigned char)(unsigned)((int)(i1 + (unsigned)h0) >= (int)(unsigned)(w0 >> 29))) && (unsigned)w0);
    if ((unsigned)w0) {
        u1 += ((unsigned)(unsigned char)(0x3ee97b5bu + 0x58d77e30u) + 3u);
    } else {
        h0 = (short)(u3 ^ (unsigned)((unsigned)(w0 >> 29) && 0u));
    }
    m0 ^= (i2 | ((-(unsigned)(i0 && a0[i0 & 3u]) - i0) | 9u));
    a0[(m0 << (0x7fffffffu & 31u)) & 3u] = (8u - (unsigned)d0);
    do { if (--fuel == 0u) goto done;
        u2 += 9u;
        L1: if (--fuel == 0u) goto done;
    } while (i0++ < 6u && 0x80000000u);
    w0 ^= (unsigned long long)r0.x << ((unsigned)(short)((unsigned)c1 / ((unsigned)((short)(unsigned)c0 > (signed char)0xffffffffu) | 1u)) & 63u);
    switch ((garr[i1 & 7u] * (unsigned)((int)m0 >= (int)(unsigned)e0)) & 7u) {
        u2 = u2 * 0x9e3779b1u + ((m0 << (r0.x & 31u)) + r0.y);
    }
    b0 = (unsigned)(signed char)((unsigned)((unsigned)x0 && (unsigned)((int)0xeee942b8u >= (int)(unsigned)h1)) >> ((unsigned)f0 & 31u)) != 0u;
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)h0 ^ 0xffffffffu), (1u + (unsigned)w0), p0); }
    while (i0++ < 7u && ((0x4d9d107au / (0x35d0d9f6u | 1u)) ^ 0x10000u)) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)*mp > (signed char)u2)) {
            if ((unsigned)e0) goto L2;
            break; (void)(0xb010f283u);
            b0 = ((unsigned)(x0 >> 70) & 0xffffffffu) != 0u;
            *q0 += (p0 & 3u);
            *mp = (unsigned)((unsigned)s1 == (unsigned)((unsigned)e0 < (a0[i0 & 3u] ^ 0x7fffffffu)));
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                while (i2++ < 6u && (garr[i1 & 7u] - 0x9ce32401u)) { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)d0 == (0x7fffffffu | 4u))) {
                        if (budget != 0u) { budget -= 1u; u2 = fn1((a0[u1 & 3u] ^ v0), (unsigned)((short)r0.y > (signed char)g1), ((unsigned)h1 % ((unsigned)s1 | 1u))); }
                        s0 = (int)(g0 - (6u << (*mp & 31u)));
                        u0 += (((unsigned)e0 / (8u | 1u)) / (((7u / (0x85080d05u | 1u)) & (unsigned)x0) | 1u));
                        if ((unsigned)d0) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn1(0x7ac9a83eu, (unsigned)((unsigned)(w0 >> 29) == 0xa4a9e031u), *mp); }
                    } else {
                        do { if (--fuel == 0u) goto done;
                            m0 ^= (unsigned)h0;
                            if (budget != 0u) { budget -= 1u; u0 = fn1(0x10000u, ((unsigned)h0 % ((unsigned)l0 | 1u)), u1); }
                            break; (void)(((unsigned)((int)(unsigned)e0 >= (int)0xff535ab8u) >> ((unsigned)c1 & 31u)));
                            *q0 += (0xbd1f6219u ^ (0x7fffffffu % (2u | 1u)));
                            q0 = &garr[u3 & 7u];
                        } while (i0++ < 7u && 0u);
                    }
                    r0.x = (-(0xa9dd9215u / (0x3b60477du | 1u)) * (unsigned)(unsigned char)((unsigned)c1 << (m0 & 31u)));
                    continue; (void)(((unsigned)f0 / (u3 | 1u)));
                    if (fuel) continue;
                    if ((unsigned)b0) continue;
                    h0 = (short)(0x726d02b6u % ((unsigned)(g0 && (unsigned)(p1 || 0xd34860f9u)) | 1u));
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)u0 >= (int)(unsigned)(w0 >> 29));
                c0 = (unsigned char)~(unsigned)((unsigned)d0 && a0[u1 & 3u]);
                continue; (void)((unsigned)(short)((unsigned)s0 << ((0x54d52298u & r0.y) & 31u)));
                if ((0x10000u / (p2 | 1u))) break;
                if ((5u % (a0[i0 & 3u] | 1u))) break;
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)(*q0 || a0[u1 & 3u]) && 0x91edcca1u), (unsigned)(unsigned char)((unsigned)f0 ^ r0.y), (unsigned)(unsigned char)((unsigned)(r0.x < 0x10000u) - 0x7fffffffu)); }
        switch (4u & 7u) {
            break; (void)(~(0x2b75b7bbu & (unsigned)(u0 || (unsigned)d0)));
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)4u >= (int)0xffffffffu), a0[i0 & 3u], *q0); }
            if ((unsigned)((short)(unsigned)s0 > (signed char)((unsigned)e0 % ((unsigned)h1 | 1u)))) break;
            if ((unsigned)s1) continue;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(unsigned char)(*mp + 0xf2ca45d9u), (~(v0 + 0xa069c1a1u) ^ a0[i0 & 3u]), (unsigned)((int)fuel >= (int)(0x10000u * *q0))); }
        }
        if (-(unsigned)((int)0xdc8470bbu < (int)u2)) break;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.x = (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)(i1 || u2));
            if (i1) break;
            w0 ^= (unsigned long long)(m0 % (0x80000000u | 1u)) << ((0x10c1883du | (0x22319f35u | (unsigned)b0)) & 63u);
            c0 = (unsigned char)(((p2 & (0xffffffffu & 0x571297d8u)) & (unsigned)s1) | 0x6ec5009cu);
        }
        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(short)(i0 - (0xa95d46b2u & ~(garr[i1 & 7u] ^ (unsigned)b0))) && g1) & 1023u);
    }
    if ((unsigned)(0x10000u && r0.x)) {
        if (u0) goto L2;
        if (budget != 0u) { budget -= 1u; u0 = fn1((0x79a26e33u >> (((unsigned)w0 << (u3 & 31u)) & 31u)), ((unsigned)(signed char)(unsigned)(i1 == u2) % (0xaf233342u | 1u)), (unsigned)((unsigned)d0 < ~(unsigned)((int)m0 >= (int)u3))); }
        u0 += ((unsigned)((0x80000000u % ((unsigned)d0 | 1u)) && (unsigned)x0) * *q0);
        *mp = (0xb3d9b814u & 0xa7770d07u);
        x0 = x0 * 0x100000001b3ull + ((0x10000u - (unsigned)f0) & (unsigned)((int)u0 >= (int)0xa703454au));
        goto L2;
    } else {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.x = ((0x80000000u % ((unsigned)x0 | 1u)) + garr[i1 & 7u]);
            s0 = (int)(v0 << (*mp & 31u));
            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(u0 < (unsigned)((unsigned)(w0 >> 29) == (unsigned)e0)) == 0x7c0fd63du);
            m0 ^= (unsigned)c1;
            if ((unsigned)c1) break;
            if (((unsigned)c1 | (unsigned)((unsigned)(w0 >> 29) == 0xffffffffu))) break;
        }
        goto L0;
        if (budget != 0u) { budget -= 1u; u2 = fn0((0x80000000u >> ((unsigned)((int)g0 < (int)0x10000u) & 31u)), (unsigned)(i0 || 5u), garr[i1 & 7u]); }
    }
    goto L0;
    if ((unsigned)((int)(0x26c267d3u + 4u) < (int)8u)) {
        L2: if (--fuel == 0u) goto done;
    } else {
        s1 = (int)((unsigned)s1 + (unsigned)s0);
        if (budget != 0u) { budget -= 1u; u3 = fn0((u0 ^ (unsigned)((unsigned)s0 && garr[u2 & 7u])), (r0.y & (unsigned)((int)(unsigned)d0 >= (int)0xc7fcd95au)), (*q0 % ((unsigned)l0 | 1u))); }
        q0 = &garr[r0.x & 7u];
        if ((r0.y ? 0xbd79a1b9u : (unsigned)e0)) goto L1;
    }
    L3: if (--fuel == 0u) goto done;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)(unsigned char)((unsigned)d0 * p1) & 7u) {
            if (p2) goto L4;
            do { if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if ((7u) & 1u) { t1 = (unsigned)((short)0x514cf647u > (signed char)u0); z1 = (double)(((unsigned)(r0.y == (r0.x + (unsigned)x0))) & 255u); } if ((7u) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    garr[(unsigned)(a0[i0 & 3u] == p1) & 7u] = (unsigned)h1;
                    f0 = f0 * 0.5f + (float)(~(unsigned)((unsigned)(signed char)(6u * (unsigned)(i2 && i0)) < 4u) & 255u);
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)0x7fffffffu < (int)(unsigned)(0x46255920u && 9u)), (unsigned)((int)u3 >= (int)i2), 0x80000000u); }
                    if (fuel < 8u) return *mp;
                    if (budget != 0u) { budget -= 1u; u1 = fn1(u0, a0[u1 & 3u], (0x10000u & (v0 ^ u0))); }
                    e0 = e0 * 0.5L + (long double)((unsigned)h0 & 1023u);
                }
                m0 ^= (7u << (0x20edf0c5u & 31u));
                if ((unsigned)((int)*mp < (int)(unsigned)((int)0x10000u >= (int)(unsigned)c0))) break;
            } while (i1++ < 5u && (unsigned)(w0 >> 29));
            if (budget != 0u) { budget -= 1u; u2 = fn0((0x10000u / ((0xc8756cb1u + (unsigned)(w0 >> 29)) | 1u)), (unsigned)(g0 && (unsigned)!(unsigned)((short)6u > (signed char)(unsigned)w0)), (unsigned)x0); }
            g0 = (unsigned)!((unsigned)((short)(unsigned)((int)(unsigned)c0 >= (int)p0) > (signed char)(unsigned)(signed char)(unsigned)(i0 == 0x7fffffffu)) | 0xbfced957u);
            { unsigned t2; double z2; if ((-(i2 * a0[u1 & 3u])) & 1u) { t2 = (fuel & (0u * u0)); z2 = (double)(((unsigned)(unsigned char)((0x6378f514u << (8u & 31u)) % ((unsigned)s0 | 1u))) & 255u); } if ((-(i2 * a0[u1 & 3u])) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                if ((unsigned)((short)*mp > (signed char)(unsigned)((unsigned)s0 && i2))) goto L0;
                if (budget != 0u) { budget -= 1u; u3 = fn1((fuel >> ((0xfed3dd12u / ((unsigned)h0 | 1u)) & 31u)), a0[i0 & 3u], (unsigned)(short)(m0 * 0x2f71b8a4u)); }
                u3 = u3 * 0x9e3779b1u + (unsigned)(unsigned char)(g0 >> ((((unsigned)h1 & (unsigned)(v0 && v0)) << (r0.x & 31u)) & 31u));
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    goto L2;
                    g0 = (unsigned)!((unsigned)((int)a0[u1 & 3u] >= (int)u0) >> ((unsigned)((short)0xc7e68b83u > (signed char)a0[u1 & 3u]) & 31u));
                    case 0u: ;
                    do { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)((0xa3dea011u / ((fuel * (unsigned)((int)((unsigned)c0 * u3) < (int)g0)) | 1u)) & 255u);
                        i0 = g0 & 15u;
                        default: ;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(g1, (unsigned)((unsigned)c0 == p0), (unsigned)(r0.x && 0x80000000u)); }
                    } while (i2++ < 6u && r0.y);
                }
                if ((unsigned)e0) continue;
                q0 = &garr[(-(0x465c2429u / (g0 | 1u)) % (0x7fffffffu | 1u)) & 7u];
            }
            case 2u: ;
        }
        L4: if (--fuel == 0u) goto done;
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + ((p2 - u2) >> (0x4faa76b1u & 31u)));
        q0 = &garr[0xffffffffu & 7u];
        w0 = w0 * 6364136223846793005ull + ((u1 * (g1 / ((unsigned)c0 | 1u))) & (u3 + 0x7fffffffu));
        f0 = f0 * 0.5f + (float)((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)x0) & 255u);
        a0[(unsigned)h0 & 3u] = ((0xfdc15fd5u << (*q0 & 31u)) - ((r0.y * 0x10000u) / (0x8ae51d75u | 1u)));
        if ((unsigned)(u3 == (unsigned)((unsigned)h1 || 0xa9fcd621u))) continue;
    }
    switch ((fuel * 2u) & 7u) {
        l0 = (long)((unsigned long)l0 + (u1 >> ((unsigned)d0 & 31u)));
        s1 = (int)((unsigned)s1 + (v0 - *mp));
    }
    if ((p2 ^ r0.y)) goto L4;
    { unsigned t3; double z3; if ((g0) & 1u) { t3 = (unsigned)(0xffffffffu && 2u); z3 = (double)(((unsigned)((short)0x71c320aau > (signed char)(unsigned)(unsigned char)(0x4028be6u ^ 0x10000u))) & 255u); } if ((g0) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (8u) break;
            if ((g1 % (((unsigned)s1 & 0xffffffffu) | 1u))) break;
            if ((unsigned)(v0 && (unsigned)c0)) break;
        }
        l0 = (long)((unsigned long)l0 + (unsigned)((int)(7u >> ((unsigned)w0 & 31u)) < (int)~(0x66faeb6du >> ((unsigned)c1 & 31u))));
        q0 = &garr[(fuel * 0x10000u) & 7u];
        if ((unsigned)e0) goto done;
        if ((7u | r0.y)) goto L1;
    }
    while (i0++ < 3u && (a0[i0 & 3u] * 6u)) { if (--fuel == 0u) goto done;
        if ((u2 & (unsigned)((int)(unsigned)s0 >= (int)6u))) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)((short)7u > (signed char)(unsigned)s0));
        u0 = ((unsigned)((int)m0 < (int)(unsigned)c1) | (unsigned)((u2 >> ((unsigned)b0 & 31u)) == (unsigned)l0));
        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)d0 | (unsigned)s0), 0x239f2b0bu, 0u); }
        while (i1++ < 3u && (0x10000u << (garr[i1 & 7u] & 31u))) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((unsigned)c0 * 0x4baed950u) & 1023u);
            while (i2++ < 7u && u2) { if (--fuel == 0u) goto done;
                garr[(unsigned)(unsigned char)(u2 ^ (unsigned)(x0 >> 70)) & 7u] = (unsigned)((unsigned)e0 < (unsigned)c1);
                if (budget != 0u) { budget -= 1u; u2 = fn0(u0, (unsigned)((int)(unsigned)(v0 < 7u) < (int)(unsigned)(x0 >> 70)), (u0 ^ u2)); }
                if (g0) break;
                while (i0++ < 4u && (unsigned)!(0x2b54bd7u ^ (unsigned)w0)) { if (--fuel == 0u) goto done;
                    if (0x10000u) break;
                    { unsigned t4; double z4; if ((0x7fffffffu) & 1u) { t4 = (m0 + (p0 + 0xc966115au)); z4 = (double)((i1) & 255u); } if ((0x7fffffffu) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                        r0.x = (unsigned)(((unsigned)f0 >> ((0x75211532u ^ 0x7fffffffu) & 31u)) || a0[i0 & 3u]);
                        u0 = (unsigned)((int)((0x972bc651u % ((unsigned)((unsigned)f0 || i1) | 1u)) & (unsigned)e0) >= (int)v0);
                        b0 = *mp != 0u;
                    }
                    do { if (--fuel == 0u) goto done;
                        v0 = (0x82c8c3edu * (unsigned)s1);
                        h0 = (short)(unsigned)(short)((unsigned)((int)(u2 % ((unsigned)f0 | 1u)) >= (int)(unsigned)(x0 >> 70)) & (unsigned)s1);
                        if ((g0 + i2)) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((0x3a9f037fu >> ((unsigned)s1 & 31u)), 0xffffffffu, (unsigned)c1); }
                        u0 += (0x7fffffffu - (unsigned)(short)(0x2ff0ae8fu / (a0[u1 & 3u] | 1u)));
                    } while (i1++ < 2u && v0);
                    g1 += (unsigned)(0x88482b19u == (((unsigned)(5u == (unsigned)e0) << (0xca550ef1u & 31u)) ^ i2));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)l0, (r0.x | (unsigned)(p0 && 0xffffffffu)), (unsigned)(v0 || (unsigned)((int)p2 >= (int)0x8522c974u))); }
            }
            c1 = (signed char)((unsigned)s0 ? (unsigned)s1 : (unsigned)((unsigned)e0 < (unsigned)l0));
        }
    }
    f0 = f0 * 0.5f + (float)(((unsigned)(u3 && (unsigned)(x0 >> 70)) * 0x10000u) & 255u);
    while ((unsigned)(((unsigned)b0 % (r0.y | 1u)) == (unsigned)l0)) { if (--fuel == 0u) goto done;
        if (u1) {
            if (r0.y) break;
            a0[(unsigned)(0xe39e6cefu == (unsigned)c1) & 3u] = g0;
            u0 = u0 * 0x9e3779b1u + r0.y;
            if ((0xffffffffu << (0x7fffffffu & 31u))) break;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)b0 & a0[i0 & 3u]), garr[u2 & 7u], (unsigned)!((unsigned)x0 % (0xffffffffu | 1u))); }
        }
    }
    if ((unsigned)((unsigned)w0 == (unsigned)x0)) goto L4;
    *mp = (unsigned)((int)(unsigned)(i0 && ((unsigned)(w0 >> 29) >> (u2 & 31u))) < (int)(unsigned)((int)garr[u2 & 7u] < (int)a0[i0 & 3u]));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)h0) {
            e0 = e0 * 0.5L + (long double)(((8u / ((unsigned)(w0 >> 29) | 1u)) << ((unsigned)(((unsigned)s1 * a0[u1 & 3u]) < 9u) & 31u)) & 1023u);
            u1 ^= ((unsigned)h0 - (8u >> ((unsigned)s0 & 31u)));
        }
    }
    goto L0;
    g0 = (unsigned)c1;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (garr[i1 & 7u] & 7u) {
            l0 = (long)((unsigned long)l0 + (3u & u2));
            case 7u: ;
            if ((i1 << ((u1 - fuel) & 31u))) continue;
        }
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)0x3a33f095u << (-(unsigned)(6u < (unsigned)!((unsigned)s1 & garr[i1 & 7u])) & 63u);
            c1 = (signed char)(unsigned)((short)((unsigned)((int)(unsigned)e0 < (int)a0[u1 & 3u]) % ((unsigned)(x0 >> 70) | 1u)) > (signed char)(unsigned)(p0 && u2));
        }
        c1 = (signed char)(m0 + i1);
    }
    goto L3;
    m0 ^= ((unsigned)!((unsigned)h1 >> ((0x7fffffffu * (unsigned)((short)*mp > (signed char)3u)) & 31u)) & g1);
    g1 += (0u / (u3 | 1u));
    a0[(0x202ae214u + 0xffffffffu) & 3u] = (*mp / (6u | 1u));
    b0 = (u0 - fuel) != 0u;
    if (budget != 0u) { budget -= 1u; u2 = fn0((2u * a0[i0 & 3u]), (unsigned)x0, garr[u2 & 7u]); }
    u0 += (unsigned)((int)m0 >= (int)((unsigned)h0 / (-(unsigned)((int)(*mp - i2) < (int)garr[i1 & 7u]) | 1u)));
    if (budget != 0u) { budget -= 1u; u2 = fn1((u3 | (unsigned)f0), (unsigned)(unsigned char)(0x10000u / ((i1 + (unsigned)(w0 >> 29)) | 1u)), (unsigned)((short)0x7fffffffu > (signed char)(unsigned)((unsigned)l0 && a0[i0 & 3u]))); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    g1 += 0x10000u;
    if ((v0 ^ (unsigned)(signed char)(a0[u1 & 3u] * 0xc0939732u))) goto done;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn2(u1, g0, g1); }
        x0 = x0 * 0x100000001b3ull + ~(0x204dc358u ? (unsigned)f0 : ((unsigned)c0 + (unsigned)(w0 >> 29)));
    } while (i0++ < 7u && ((p2 << (0x88e5ec8cu & 31u)) ^ g1));
    if (0xffffffffu) goto L4;
    goto L4;
    L0: if (--fuel == 0u) goto done;
    b0 = ((a0[u1 & 3u] * 4u) & ((unsigned)((int)(unsigned)d0 < (int)(unsigned)d0) << ((unsigned)e0 & 31u))) != 0u;
    if ((unsigned)((short)g1 > (signed char)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)c1))) goto L3;
    if (a0[i0 & 3u]) {
        if ((0xffffffffu + 1u)) goto L3;
        g1 += (unsigned)(0x7fffffffu && (u1 + p0));
        if ((((unsigned)e0 % (0x10000u | 1u)) + 0x80000000u)) {
            l0 = (long)((unsigned long)l0 + (unsigned)((short)i1 > (signed char)-(unsigned)(*q0 && (u0 + g1))));
            m0 ^= (((unsigned)s1 * a0[i0 & 3u]) % (((unsigned)(w0 >> 29) ? (unsigned)b0 : (unsigned)d0) | 1u));
            goto L3;
            d0 = d0 * 0.5 + (double)(0x533606f1u & 1023u);
        } else {
            *q0 += (a0[u1 & 3u] - (p2 >> ((unsigned)s1 & 31u)));
            g0 = ((unsigned)(g1 < a0[u1 & 3u]) % (p2 | 1u));
            l0 = (long)((unsigned long)l0 + (unsigned)((int)garr[u2 & 7u] < (int)(i2 ^ ((unsigned)h0 | 3u))));
            if ((unsigned)!(unsigned)(((unsigned)(x0 >> 70) & i2) == 2u)) {
                r0.x = (unsigned)((short)(unsigned)x0 > (signed char)v0);
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)!(unsigned)((int)9u >= (int)m0)) {
                        b0 = (unsigned)((short)p0 > (signed char)0x2a66ed69u) != 0u;
                        break; (void)(*q0);
                        g0 = (unsigned)h0;
                        i0 = (unsigned)!(unsigned)((int)((unsigned)f0 / ((unsigned)c0 | 1u)) < (int)(unsigned)(a0[u1 & 3u] && (unsigned)!(unsigned)(0x44bcdfb6u == r0.x))) & 15u;
                        b0 = (unsigned)(g0 && (unsigned)(((unsigned)b0 / ((*mp % ((unsigned)h0 | 1u)) | 1u)) < (unsigned)(x0 >> 70))) != 0u;
                        s0 = (int)0xffffffffu;
                    } else {
                        u3 ^= (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)(w0 >> 29));
                        e0 = e0 * 0.5L + (long double)((unsigned)f0 & 1023u);
                    }
                    a0[*q0 & 3u] = (unsigned)c1;
                    if (u3 == 7u) return ((unsigned)d0 << ((i1 & r0.y) & 31u));
                } while (i0++ < 6u && (unsigned)(0x80000000u || v0));
                goto done;
                *q0 += i1;
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)w0) continue;
                } while (i0++ < 5u && (0x355e8657u % ((unsigned)x0 | 1u)));
            } else {
                v0 = ((*q0 - 0x80000000u) - (i0 & (unsigned)c0));
                x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)((0xffffffffu ? p2 : 0xdb790b4eu) - (unsigned)(4u && 0x51f1977fu));
                e0 = e0 * 0.5L + (long double)((*mp | u1) & 1023u);
            }
        }
        c0 = (unsigned char)(unsigned)!(unsigned)(i2 < (unsigned)((unsigned)d0 == r0.y));
        do { if (--fuel == 0u) goto done;
            u3 = (unsigned)((int)((unsigned)(u1 == (unsigned)c0) & 0x941d6aadu) >= (int)((unsigned)s0 << (u1 & 31u)));
            r0.y ^= (0x80000000u ^ (unsigned)(g1 || garr[u2 & 7u]));
        } while (i0++ < 2u && (unsigned)(signed char)(unsigned)(0x23b6c540u && (unsigned)c0));
        if (v0) goto L2;
    } else {
        d0 = d0 * 0.5 + (double)(((unsigned)(unsigned char)((unsigned)h1 >> ((*q0 + (unsigned)((short)u2 > (signed char)(unsigned)b0)) & 31u)) * i1) & 1023u);
        i0 = (unsigned)(short)((unsigned)((unsigned)f0 && (u1 << ((unsigned)(x0 >> 70) & 31u))) % (a0[i0 & 3u] | 1u)) & 15u;
        a0[(unsigned)!(unsigned)((unsigned)b0 == 1u) & 3u] = ((unsigned)c0 / ((unsigned)b0 | 1u));
    }
    { unsigned t0; double z0; if (((a0[u1 & 3u] / ((8u | garr[i1 & 7u]) | 1u))) & 1u) { t0 = (unsigned)h0; z0 = (double)(((unsigned)((int)0xef2d40dcu < (int)2u)) & 255u); } if (((a0[u1 & 3u] / ((8u | garr[i1 & 7u]) | 1u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        L1: if (--fuel == 0u) goto done;
        goto L1;
        r0.x = 0x10000u;
        goto L0;
        switch (0x993c58e4u & 7u) {
            m0 ^= (unsigned)((r0.x | garr[u2 & 7u]) < (unsigned)(signed char)(unsigned)((short)0x7fffffffu > (signed char)u0));
            break; (void)((unsigned)f0);
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)e0, (0x8833dd74u << (g0 & 31u)), (unsigned)((int)2u >= (int)fuel)); }
        }
        for (;;) { if (--fuel == 0u) goto done;
            if ((0x7fffffffu - 5u)) continue;
            do { if (--fuel == 0u) goto done;
                r0.y ^= i0;
                if (r0.y) break;
                f0 = f0 * 0.5f + (float)((~(unsigned)((short)(unsigned)d0 > (signed char)(0u ? i2 : (unsigned)b0)) - g1) & 255u);
                L2: if (--fuel == 0u) goto done;
            } while (i1++ < 5u && (unsigned)h1);
            u1 ^= (unsigned)((p1 ^ (unsigned)s1) || (unsigned)(short)(unsigned)(garr[u2 & 7u] == garr[i1 & 7u]));
            if ((v0 | (unsigned)((int)(unsigned)l0 >= (int)1u))) break;
        }
    }
    if ((unsigned)(signed char)(v0 >> (r0.y & 31u))) {
        if (((0xffffffffu - (unsigned)s1) >> (*q0 & 31u))) {
            L3: if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if (((unsigned)c0) & 1u) { t1 = ((unsigned)((int)(unsigned)s0 >= (int)(unsigned)c1) | (unsigned)s1); z1 = (double)((u3) & 255u); } if (((unsigned)c0) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                w0 = w0 * 6364136223846793005ull + (0x80000000u * *mp);
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(unsigned char)(((unsigned)h0 ^ (unsigned)(w0 >> 29)) ^ 0xffffffffu), (7u / ((unsigned)((unsigned)h1 || (unsigned)h1) | 1u)), (unsigned)(signed char)(i2 ^ g0)); }
                if (((unsigned)(w0 >> 29) & 3u)) goto L2;
                if (((unsigned)x0 & (unsigned)((short)0xffffffffu > (signed char)*mp))) {
                    *q0 += (unsigned)(unsigned char)(unsigned)((int)6u >= (int)(0x550450d2u & (unsigned)(6u || garr[i1 & 7u])));
                    r0.y ^= ((unsigned)(unsigned char)(g1 & (unsigned)s0) & (unsigned)(short)(unsigned)((int)(unsigned)f0 < (int)i0));
                    a0[(unsigned)(a0[u1 & 3u] < (unsigned)(w0 >> 29)) & 3u] = u3;
                    { unsigned t2; double z2; if (((r0.y - 1u)) & 1u) { t2 = 8u; z2 = (double)(((unsigned)x0) & 255u); } if (((r0.y - 1u)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                        goto L3;
                        b0 = (unsigned)(signed char)(r0.x + (unsigned)((int)(unsigned)c0 < (int)((unsigned)s0 ^ g0))) != 0u;
                        h0 = (short)(m0 - (unsigned)s1);
                        if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)(unsigned char)(unsigned)(0x4d3afa89u < p0) * i0), (unsigned)(2u < 0x87435cfu), ((unsigned)b0 ^ (0xe260c67bu & 0x80000000u))); }
                        while (i0++ < 2u && (unsigned)((int)(unsigned)((int)(unsigned)b0 < (int)g0) >= (int)(unsigned)x0)) { if (--fuel == 0u) goto done;
                            r0.y ^= garr[u2 & 7u];
                            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)f0 || fuel) & 1023u);
                            continue; (void)(((unsigned)d0 << (garr[i1 & 7u] & 31u)));
                            *q0 = (0u & (unsigned)l0);
                            q0 = &garr[0x10000u & 7u];
                            x0 = x0 * 0x100000001b3ull + garr[i1 & 7u];
                        }
                    }
                    if (fuel < 8u) return (0x4c8e779fu >> (r0.y & 31u));
                } else {
                    L4: if (--fuel == 0u) goto done;
                    b0 = (unsigned)((unsigned)c0 || 5u) != 0u;
                    if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)((int)(unsigned)h0 >= (int)u3) << ((unsigned)x0 & 31u)), (unsigned)(i1 == (0x10000u & 0u)), 0x29b2c61eu); }
                    u1 ^= ((unsigned)x0 << ((unsigned)((int)8u >= (int)u0) & 31u));
                }
                if (u3 == 7u) return (0x80000000u + (r0.x ^ (unsigned)(g0 < 2u)));
            }
        } else {
            m0 ^= (unsigned)(0xae1c65d9u || (unsigned)(4u && ((unsigned)d0 % (*q0 | 1u))));
        }
    } else {
        if (budget != 0u) { budget -= 1u; u2 = fn2(i1, (*q0 | v0), (unsigned)((short)(unsigned)s0 > (signed char)(unsigned)(u0 || (unsigned)f0))); }
        h0 = (short)garr[u2 & 7u];
        if ((unsigned)h1) goto L3;
        if (budget != 0u) { budget -= 1u; u0 = fn0(u2, (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)(x0 >> 70)), ~(unsigned)((u3 | garr[i1 & 7u]) == u0)); }
    }
    g0 = g0;
    if ((0xb62318e1u * 0x263a0d11u)) goto L3;
    for (;;) { if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)(short)((unsigned)(garr[i1 & 7u] < u3) - (p0 + (unsigned)x0));
        s0 = (int)((0u >> (2u & 31u)) + (unsigned)(w0 >> 29));
        c0 = (unsigned char)(unsigned)(0xffffffffu == (unsigned)((unsigned)(i1 || (g1 << (i1 & 31u))) < 0xffffffffu));
        b0 = (unsigned)((int)(unsigned)(8u < (unsigned)(unsigned char)(i1 | (unsigned)(x0 >> 70))) >= (int)0xffffffffu) != 0u;
    }
    u2 = (0xffffffffu ? u3 : 0xffffffffu);
    if (0x7fffffffu) goto L2;
    g1 += ((unsigned)e0 ^ 6u);
    if (((unsigned)l0 ^ 0x80000000u)) goto L2;
    goto L2;
    *q0 += p1;
    while (i0++ < 5u && (unsigned)b0) { if (--fuel == 0u) goto done;
        m0 ^= ((unsigned)b0 ? u3 : (unsigned)(x0 >> 70));
        { unsigned t3; double z3; if (((unsigned)(8u || (unsigned)((int)(unsigned)s0 >= (int)r0.x))) & 1u) { t3 = ((p1 % (p0 | 1u)) & 0xabae60feu); z3 = (double)((0xa5854f08u) & 255u); } if (((unsigned)(8u || (unsigned)((int)(unsigned)s0 >= (int)r0.x))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            i0 = ((unsigned)c0 & u3) & 15u;
            if ((unsigned)((int)0x7fffffffu >= (int)i0)) break;
            if ((unsigned)s1) {
                u0 = u1;
                i2 = ((unsigned)((5u << ((unsigned)x0 & 31u)) == 0xa12ab535u) << (r0.y & 31u)) & 15u;
            } else {
                do { if (--fuel == 0u) goto done;
                    r0.x = (i2 * (unsigned)((unsigned)h0 == u2));
                } while (i1++ < 6u && (unsigned)((unsigned)d0 == (u3 % ((unsigned)s0 | 1u))));
                if (((unsigned)c1 << (((unsigned)c1 << ((unsigned)c1 & 31u)) & 31u))) {
                    *q0 = (0xafe17833u / ((unsigned)(v0 < g0) | 1u));
                    x0 = x0 * 0x100000001b3ull + (((unsigned)s1 >> ((unsigned)((unsigned)(x0 >> 70) && (p0 ^ 0x7fffffffu)) & 31u)) + p2);
                    { unsigned t4; double z4; if (((unsigned)((int)(unsigned)s0 < (int)(unsigned)e0)) & 1u) { t4 = (0x68ef4a8cu ^ u3); z4 = (double)((((unsigned)b0 ^ i0)) & 255u); } if (((unsigned)((int)(unsigned)s0 < (int)(unsigned)e0)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                        if (budget != 0u) { budget -= 1u; u3 = fn0((a0[i0 & 3u] / ((unsigned)b0 | 1u)), (unsigned)((unsigned)((int)0x7a74a110u < (int)(unsigned)c0) && i1), 0xd43e48aau); }
                        s1 = (int)((unsigned)s1 + (unsigned)(a0[u1 & 3u] && (unsigned)(w0 >> 29)));
                    }
                    q0 = &garr[(8u + (g1 & (unsigned)(0x10000u == g0))) & 7u];
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn1(7u, (unsigned)(unsigned char)(unsigned)((int)(0xffffffffu ^ (unsigned)(x0 >> 70)) < (int)0x10000u), ((unsigned)((int)u3 < (int)(unsigned)s1) / (u2 | 1u))); }
                }
            }
            if (budget != 0u) { budget -= 1u; u0 = fn2(0x10000u, (unsigned)(unsigned char)(unsigned)((short)((unsigned)w0 | u0) > (signed char)r0.y), *q0); }
            u1 = (((r0.y % ((unsigned)d0 | 1u)) | 0x73cd0dcbu) - v0);
        }
        switch ((unsigned)((int)(unsigned)h1 >= (int)u0) & 7u) {
            *q0 += a0[i0 & 3u];
            *mp = ((unsigned)c1 >> ((unsigned)(x0 >> 70) & 31u));
        }
        q0 = &garr[(unsigned)!(u0 ? 0x9bdbe7dau : (garr[i1 & 7u] | u3)) & 7u];
        if ((u0 ^ (unsigned)(6u == u0))) {
            if (((unsigned)e0 * (unsigned)h1)) continue;
            continue; (void)((u3 - 0xffffffffu));
            break; (void)((0x80000000u % ((p1 << (u3 & 31u)) | 1u)));
            if (((unsigned)(signed char)(unsigned)((int)i1 >= (int)(unsigned)w0) << ((unsigned)(w0 >> 29) & 31u))) break;
            if (((unsigned)e0 ^ ((unsigned)h0 >> (m0 & 31u)))) goto done;
        } else {
            if ((0x10000u + g1)) break;
            if ((unsigned)((int)(i2 >> (g0 & 31u)) >= (int)i2)) {
                garr[9u & 7u] = (unsigned)(a0[i0 & 3u] == 0x7fffffffu);
                if (budget != 0u) { budget -= 1u; u3 = fn2(-(unsigned)(((unsigned)c1 >> (0x10000u & 31u)) && m0), (unsigned)(signed char)((unsigned)s0 | (unsigned)(0x2ad4ee4bu && (unsigned)b0)), 0x816de560u); }
                *mp = (unsigned)(signed char)(unsigned)(((unsigned)l0 - (unsigned)l0) == (i0 >> ((unsigned)((unsigned)e0 == i0) & 31u)));
                switch (0x80000000u & 7u) {
                    if (u3) break;
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)(garr[i1 & 7u] && r0.y) < (int)g0);
                }
            } else {
                if (budget != 0u) { budget -= 1u; u2 = fn1((7u % (0xffffffffu | 1u)), ((unsigned)w0 >> (~(unsigned)((unsigned)(x0 >> 70) && 9u) & 31u)), ((unsigned)e0 << ((g1 << (i2 & 31u)) & 31u))); }
                do { if (--fuel == 0u) goto done;
                    goto L2;
                    if (0x80000000u) goto L0;
                    if (0x7fffffffu) break;
                    *q0 = (g0 & (unsigned)((int)(unsigned)s0 < (int)(unsigned)l0));
                    { unsigned t5; double z5; if ((g0) & 1u) { t5 = (i2 * 0x10000u); z5 = (double)((g0) & 255u); } if ((g0) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)x0 % (garr[i1 & 7u] | 1u)), (garr[i1 & 7u] & r0.x), (unsigned)l0); }
                        if ((i2 << (0xffffffffu & 31u))) goto L2;
                        w0 ^= (unsigned long long)(unsigned)(m0 && v0) << (((unsigned)(unsigned char)(0x10000u + ((unsigned)x0 % ((unsigned)h1 | 1u))) & i1) & 63u);
                        e0 = e0 * 0.5L + (long double)((1u | ((((unsigned)d0 % (garr[i1 & 7u] | 1u)) ^ v0) & 0xe37849edu)) & 1023u);
                        break; (void)(0x80000000u);
                    }
                } while (i1++ < 2u && *q0);
                switch (i2 & 7u) {
                    case 6u: ;
                    continue; (void)(0xffffffffu);
                }
                v0 = (i2 ^ 3u);
            }
        }
        i0 = (unsigned)(unsigned char)(unsigned)((unsigned)((unsigned)c0 == (unsigned)f0) && u2) & 15u;
    }
    f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)((int)*q0 < (int)g0) >= (int)p0) & 255u);
    if ((unsigned)!(garr[i1 & 7u] ? g0 : 0xf56704bu)) goto L1;
    *mp = (u1 % ((unsigned)((m0 + garr[i1 & 7u]) && 4u) | 1u));
    r0.y ^= (unsigned)!(unsigned)(((unsigned)b0 & i0) && g0);
    if (1u) {
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)fuel >= (int)(unsigned)s1), (unsigned)(w0 >> 29), (unsigned)((short)p0 > (signed char)g1)); }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)((unsigned)((int)(unsigned)h1 >= (int)(unsigned)(signed char)((unsigned)s1 ^ (unsigned)b0)) || m0);
            break; (void)((unsigned)((int)fuel < (int)m0));
            continue; (void)((unsigned)((unsigned)f0 || (unsigned)((unsigned)(w0 >> 29) == g1)));
            if ((8u - p2)) {
                break; (void)((unsigned)((int)0u >= (int)(unsigned)d0));
                *mp = (unsigned)((short)m0 > (signed char)(*mp >> (((unsigned)((int)i2 >= (int)u0) >> (r0.y & 31u)) & 31u)));
                while ((0x7fffffffu * 0xf689b674u)) { if (--fuel == 0u) goto done;
                    if (2u) break;
                }
                q0 = &garr[(unsigned)(((unsigned)((int)4u < (int)p2) - 0x80000000u) == i2) & 7u];
            }
            e0 = e0 * 0.5L + (long double)((unsigned)c0 & 1023u);
        }
        s0 = (int)(unsigned)((short)(unsigned)(a0[u1 & 3u] < (unsigned)((int)(r0.x - i2) < (int)p0)) > (signed char)(unsigned)d0);
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)(0x342a5830u);
                if ((unsigned)((short)g1 > (signed char)0x9e148f28u)) break;
                break; (void)((0x10000u - ((unsigned)e0 * i0)));
                if ((unsigned)(x0 >> 70)) break;
            }
        }
        f0 = f0 * 0.5f + (float)((unsigned)((int)*mp >= (int)(unsigned)b0) & 255u);
    } else {
        { unsigned t6; double z6; if (((unsigned)((int)i1 < (int)p2)) & 1u) { t6 = 0x3bb6cb05u; z6 = (double)(((unsigned)(i1 < (unsigned)((int)0x80000000u < (int)u1))) & 255u); } if (((unsigned)((int)i1 < (int)p2)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
            h0 = (short)((unsigned)(unsigned char)(0x7fffffffu / (0x7fffffffu | 1u)) << ((0x57024dfau >> ((unsigned)(signed char)(unsigned)(5u && 0xa2539757u) & 31u)) & 31u));
            goto L3;
            { unsigned t7; double z7; if ((garr[i1 & 7u]) & 1u) { t7 = (unsigned)x0; z7 = (double)((((unsigned)b0 >> (0x7fffffffu & 31u))) & 255u); } if ((garr[i1 & 7u]) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                if ((0x80000000u / (0x1a88b20fu | 1u))) goto L0;
                goto L0;
            }
            b0 = (unsigned)(signed char)((unsigned)c1 | ((unsigned)(x0 >> 70) << (0xbb825126u & 31u))) != 0u;
            goto L4;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn2(*q0, u0, (unsigned)((short)0xa55fc62u > (signed char)(unsigned)((unsigned)h1 && 9u))); }
        goto L2;
    }
    garr[a0[i0 & 3u] & 7u] = ((r0.y ^ (unsigned)d0) + (0x52033128u | 6u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((~((unsigned)w0 / (i2 | 1u)) + (unsigned)e0)) goto L1;
    while (i0++ < 7u && g0) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)p2 < (int)(unsigned)(a0[i0 & 3u] == 0xf2fbd661u)), (unsigned)(g0 && (unsigned)b0), (u3 ^ 0x4204b4b5u)); }
        g1 += (unsigned)c1;
        *q0 += ((unsigned)(u3 && 0x4a630451u) - 1u);
        *q0 = ((unsigned)(5u || -(i1 - v0)) / (0xcba67dcdu | 1u));
        if ((unsigned)(a0[u1 & 3u] || g0)) {
            { unsigned t0; double z0; if (((p1 % (p2 | 1u))) & 1u) { t0 = i2; z0 = (double)(((unsigned)f0) & 255u); } if (((p1 % (p2 | 1u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + 0x7fffffffu;
                    g1 += 7u;
                    if (budget != 0u) { budget -= 1u; u0 = fn2((0xc39e0919u % (0xd97c5b47u | 1u)), (unsigned)b0, ((unsigned)s0 * p0)); }
                }
                for (;;) { if (--fuel == 0u) goto done;
                    continue; (void)(((a0[u1 & 3u] * (unsigned)(w0 >> 29)) % (0x80000000u | 1u)));
                    if (garr[u2 & 7u]) break;
                    c1 = (signed char)0x10000u;
                    *mp = (unsigned)(a0[u1 & 3u] == (unsigned)(unsigned char)(unsigned)(v0 && (a0[i0 & 3u] << ((0x2da203d8u >> ((unsigned)b0 & 31u)) & 31u))));
                    goto done;
                }
                if (g1) break;
            }
            break; (void)(((unsigned)e0 + (garr[u2 & 7u] << (*q0 & 31u))));
            if (*q0) {
                x0 = x0 * 0x100000001b3ull + (unsigned)(~(garr[i1 & 7u] % ((unsigned)(w0 >> 29) | 1u)) && (unsigned)((unsigned)((int)(unsigned)x0 >= (int)(unsigned)f0) || u1));
                w0 ^= (unsigned long long)(unsigned)c1 << (0xf974dc20u & 63u);
                if (budget != 0u) { budget -= 1u; u2 = fn1(u1, (unsigned)((int)0xfa796a95u < (int)0xffffffffu), 0x7fffffffu); }
                u1 += (unsigned)((unsigned)(signed char)((unsigned)e0 * (unsigned)s0) < (unsigned)(5u < p1));
                x0 = x0 * 0x100000001b3ull + (unsigned)(g0 == (((unsigned)s1 >> (2u & 31u)) ^ u1));
            }
            if (0x7fffffffu) {
                continue; (void)(a0[i0 & 3u]);
            } else {
                if (8u) {
                    l0 = (long)((unsigned long)l0 + ((unsigned)h0 + ((unsigned)(x0 >> 70) & (unsigned)w0)));
                    break; (void)((0x3db93381u * u1));
                    h0 = (short)*q0;
                    L0: if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)~(6u % (0u | 1u)) < (int)0x89bc9398u), (unsigned)(((unsigned)s0 * p2) && garr[i1 & 7u]), ((unsigned)s0 / (u3 | 1u))); }
                }
            }
            if (fuel < 8u) return v0;
            if (((unsigned)h1 % (((unsigned)x0 + 0x40f77810u) | 1u))) continue;
        } else {
            if (budget != 0u) { budget -= 1u; u0 = fn3((r0.y % ((8u + (unsigned)l0) | 1u)), (unsigned)(2u || (unsigned)((unsigned)s0 || i0)), (0xffffffffu & 0xa191cb36u)); }
            L1: if (--fuel == 0u) goto done;
            m0 ^= (unsigned)((int)p1 < (int)u0);
        }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            *mp = (unsigned)((unsigned)((int)0u >= (int)(unsigned)h0) && 0xffffffffu);
            if (0x246cfdb2u) goto L1;
            v0 = g1;
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0(((9u + 0xffffffffu) / (r0.y | 1u)), (unsigned)((short)r0.x > (signed char)g0), *q0); }
    if (((unsigned)e0 << ((unsigned)!(unsigned)(0x257ebf58u == 0x432a71f7u) & 31u))) {
        u2 ^= (unsigned)((unsigned)c0 == g0);
    } else {
        if (((0xffffffffu - (unsigned)s1) << (0x7fffffffu & 31u))) {
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(signed char)(unsigned)((short)(unsigned)((int)8u >= (int)0u) > (signed char)0x29f59542u), (unsigned)x0, (p2 - (unsigned)s0)); }
            if ((unsigned)(unsigned char)(u3 ^ (unsigned)s0)) goto L2;
            if ((unsigned)(unsigned char)(((unsigned)c0 + 4u) + a0[i0 & 3u])) goto L1;
            h0 = (short)*q0;
            *q0 = (unsigned)(i1 < 8u);
        } else {
            L2: if (--fuel == 0u) goto done;
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)(unsigned char)((unsigned)(short)((unsigned)h1 << (4u & 31u)) & (p1 << (((unsigned)h0 * (unsigned)x0) & 31u)));
                break; (void)((a0[i0 & 3u] % ((unsigned)(x0 >> 70) | 1u)));
                L3: if (--fuel == 0u) goto done;
                g1 += ((8u ^ garr[u2 & 7u]) & (0x7aa92922u >> (0xc4731365u & 31u)));
            }
        }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((2u + p1)) goto L4;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0(-(r0.y ? i2 : m0), (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)l0), p2); }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(0x6a34f05eu || g0)) continue;
            if ((unsigned)(0x7fffffffu || 0x2bf1e978u)) continue;
            if (budget != 0u) { budget -= 1u; u1 = fn1(0xffffffffu, (a0[u1 & 3u] + (unsigned)((int)u3 >= (int)i1)), 0x7fffffffu); }
        } while (i0++ < 4u && (~(*q0 << (u2 & 31u)) / (u2 | 1u)));
    }
    if ((unsigned)(i2 == (unsigned)(fuel == (unsigned)w0))) goto done;
    x0 = x0 * 0x100000001b3ull + -(unsigned)((unsigned)(short)(m0 & (unsigned)(x0 >> 70)) < (unsigned)(unsigned char)(0x77e4b73bu - (6u ^ a0[u1 & 3u])));
    r0.y ^= (((i1 + (m0 * r0.x)) + 0xffffffffu) | (unsigned)b0);
    if ((p1 | (unsigned)s1)) goto L3;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + ((unsigned)x0 + (unsigned)e0);
        if (g0) break;
    }
    w0 ^= (unsigned long long)(unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) && a0[u1 & 3u]) << ((unsigned)(unsigned char)(unsigned)((int)9u < (int)((unsigned)(0x341a76b5u && 0x1f1b2e3cu) << ((unsigned)((int)0x7fffffffu >= (int)fuel) & 31u))) & 63u);
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(3u && 0x106d343fu), i1, (0xc7bb2bacu << ((unsigned)((int)i0 < (int)(unsigned)e0) & 31u))); }
    do { if (--fuel == 0u) goto done;
        u3 = (p2 / (0x80000000u | 1u));
    } while (i0++ < 7u && (unsigned)(g1 && g0));
    c0 = (unsigned char)(0x80000000u + (unsigned)(~(unsigned)((int)(unsigned)(x0 >> 70) < (int)r0.x) || (unsigned)((unsigned)x0 == a0[i0 & 3u])));
    r0.y ^= u2;
    if (a0[u1 & 3u]) {
        w0 ^= (unsigned long long)(unsigned)(w0 >> 29) << ((unsigned)e0 & 63u);
        if (3u) goto L4;
    } else {
        if (0x10000u) goto done;
    }
    switch ((unsigned)((unsigned)w0 < (unsigned)(short)(unsigned)((int)i1 < (int)i2)) & 7u) {
        L4: if (--fuel == 0u) goto done;
    }
    if (fuel) goto L2;
    if ((unsigned)x0) goto L4;
    h0 = (short)((g1 ? 0x15fb156au : (unsigned)!(unsigned)(fuel || (unsigned)s0)) >> ((unsigned)f0 & 31u));
    while (-(unsigned)((int)i1 < (int)0x10000u)) { if (--fuel == 0u) goto done;
        *q0 = ((1u & (unsigned)s0) - (unsigned)(u2 == (0x15494015u - (unsigned)h0)));
        break; (void)(((unsigned)(0x7fffffffu < (unsigned)h0) << ((unsigned)x0 & 31u)));
        if (budget != 0u) { budget -= 1u; u3 = fn1((i1 << (*q0 & 31u)), (0x2e4f77d3u - i1), (unsigned)(short)(u2 / ((0xa78e3f53u << ((unsigned)f0 & 31u)) | 1u))); }
        while (i1++ < 7u && (unsigned)f0) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)h1 / ((unsigned)(*q0 < 0x10000u) | 1u)), (unsigned)((unsigned)s1 && u1), (g0 * *q0)); }
            if ((unsigned)b0) break;
        }
        if (((u0 / ((unsigned)b0 | 1u)) * *q0)) break;
        w0 ^= (unsigned long long)(unsigned)h1 << (((unsigned)w0 % ((unsigned)x0 | 1u)) & 63u);
    }
    if (u3 == 7u) return ((~((unsigned)b0 >> (0x10000u & 31u)) / ((unsigned)f0 | 1u)) + 0xffffffffu);
    if (0x573c0ed4u) goto L2;
    switch ((unsigned)(unsigned char)(unsigned)((short)(unsigned)(1u < 0x289c9336u) > (signed char)p0) & 7u) {
        switch ((*mp ? *mp : 0x7fffffffu) & 7u) {
            case 3u: ;
            if ((unsigned)((short)(unsigned)((short)u1 > (signed char)0xa8fca7d4u) > (signed char)(unsigned)x0)) {
                *q0 = -(0x10000u >> ((unsigned)((unsigned)c0 < 0x7fffffffu) & 31u));
            }
            default: ;
            if ((unsigned)((short)3u > (signed char)u1)) {
                case 7u: ;
                if (budget != 0u) { budget -= 1u; u1 = fn3((0xbf25a42u % (((unsigned)h0 >> (i2 & 31u)) | 1u)), (unsigned)((unsigned)(x0 >> 70) || 8u), ((u2 ^ r0.y) + i1)); }
                if ((unsigned)((int)(unsigned)s1 >= (int)u2)) goto L4;
                i0 = (unsigned)((int)(unsigned)((short)(g1 / (a0[u1 & 3u] | 1u)) > (signed char)4u) >= (int)0x80000000u) & 15u;
                q0 = &garr[((unsigned)x0 << (1u & 31u)) & 7u];
                if (((unsigned)(p1 == (unsigned)l0) - p1)) goto L2;
            } else {
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(0x77faa9ccu < (unsigned)s0), 8u, (unsigned)(short)((unsigned)h1 * (unsigned)c1)); }
                if ((unsigned)((unsigned)x0 || u1)) goto L4;
                if ((unsigned)((int)0x79b1374eu >= (int)(unsigned)(4u == u1))) goto L3;
                if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)(1u < u1) * 0xdd92869eu), g1, (g0 % ((v0 * 0x8821139u) | 1u))); }
            }
            { unsigned t1; double z1; if ((v0) & 1u) { t1 = 6u; z1 = (double)(((unsigned)h1) & 255u); } if ((v0) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                i0 = (unsigned)((short)u0 > (signed char)(5u << ((unsigned)(garr[u2 & 7u] < ((unsigned)d0 & (unsigned)(w0 >> 29))) & 31u))) & 15u;
                if ((unsigned)((unsigned)w0 || garr[u2 & 7u])) goto L0;
                x0 = x0 * 0x100000001b3ull + (0xffffffffu << ((unsigned)c0 & 31u));
                a0[(0x7fffffffu * (unsigned)(x0 >> 70)) & 3u] = ~(0x80000000u ^ (unsigned)((unsigned)((short)g1 > (signed char)r0.x) < (unsigned)(garr[i1 & 7u] || 0xffffffffu)));
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((unsigned)e0 < 0x2be1edc6u), (unsigned)h1, 3u); }
            }
            q0 = &garr[(unsigned)!(unsigned)((int)*mp < (int)p0) & 7u];
        }
    }
    q0 = &garr[((unsigned)(x0 >> 70) & garr[u2 & 7u]) & 7u];
    if (budget != 0u) { budget -= 1u; u1 = fn1(r0.x, (unsigned)(unsigned char)(unsigned)(fuel == 0x7fffffffu), (0x10000u ? u0 : 0x5fb1869bu)); }
    goto done;
    f0 = f0 * 0.5f + (float)((i0 - garr[u2 & 7u]) & 255u);
    { unsigned t2; double z2; if (((unsigned)((short)(unsigned)(5u && (unsigned)f0) > (signed char)0x80000000u)) & 1u) { t2 = (*mp + (r0.y | (unsigned)(x0 >> 70))); z2 = (double)(((m0 + (unsigned)s1)) & 255u); } if (((unsigned)((short)(unsigned)(5u && (unsigned)f0) > (signed char)0x80000000u)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        while (i0++ < 2u && -(unsigned)((short)(unsigned)(signed char)(8u - g0) > (signed char)u0)) { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)(unsigned)((5u / ((unsigned)x0 | 1u)) || 0x211ddbc4u)) {
                w0 = w0 * 6364136223846793005ull + (9u << (g1 & 31u));
                if (2u) goto done;
                h1 = (unsigned short)(h1 + (unsigned)(7u && g0));
            } else {
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)h0) break;
                    break; (void)((unsigned)((int)(unsigned)e0 >= (int)0u));
                    if ((u2 / (7u | 1u))) {
                        while (i2++ < 2u && 0x10000u) { if (--fuel == 0u) goto done;
                            break; (void)((0u / ((unsigned)(short)((unsigned)l0 * u2) | 1u)));
                        }
                        f0 = f0 * 0.5f + (float)((0x2f8cc1eeu << (((unsigned)f0 ? (unsigned)c0 : (unsigned)s1) & 31u)) & 255u);
                        for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                            if ((unsigned)((int)0xbcbb51ecu >= (int)v0)) break;
                        }
                    } else {
                        c0 = (unsigned char)(*mp - (unsigned)h0);
                        if (fuel < 8u) return (unsigned)((int)0x6c96809du >= (int)(0xc6889162u << ((u2 << ((unsigned)x0 & 31u)) & 31u)));
                        *q0 += m0;
                        g1 += m0;
                    }
                    if ((unsigned)((unsigned)s0 < (unsigned)c0)) {
                        w0 = w0 * 6364136223846793005ull + (unsigned)(i1 && (unsigned)((int)(i1 ^ 0x80000000u) < (int)(unsigned)((int)0xee864757u >= (int)u2)));
                        if ((unsigned)(signed char)(unsigned)((int)g1 >= (int)(0xffffffffu + u3))) break;
                        h0 = (short)(unsigned)(unsigned char)((unsigned)c1 * (u1 | g1));
                        u2 += ((unsigned)(9u == (unsigned)b0) ^ 0x6ead4defu);
                        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(w0 >> 29), ((unsigned)s0 >> (u2 & 31u)), ((unsigned)w0 - (p1 % (0xcf99cd58u | 1u)))); }
                    }
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)0xffffffffu >= (int)0xddc85ea8u), (unsigned)((unsigned)h1 == 0xffffffffu), (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)(0xae8ba240u && 0xffffffffu))); }
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (g0) {
                        if ((u1 / (i1 | 1u))) break;
                        h0 = (short)(unsigned)(signed char)(unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)((0u & (unsigned)l0) == (unsigned)f0));
                        l0 = (long)((unsigned long)l0 + ((unsigned)h0 << (0x1716b2fau & 31u)));
                        s1 = (int)((unsigned)s1 + (unsigned)((int)(garr[u2 & 7u] ? a0[u1 & 3u] : p0) < (int)2u));
                        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)d0 || (((unsigned)h1 * g0) ^ (unsigned)((int)a0[i0 & 3u] < (int)7u)));
                        r0.y ^= (unsigned)((int)r0.y >= (int)p2);
                    } else {
                        *q0 += (unsigned)(((unsigned)h1 & r0.x) || (0x3e979c85u ^ 0x10000u));
                        break; (void)(-(unsigned)(u0 || (unsigned)f0));
                        if (0x10000u) continue;
                        u3 ^= (unsigned)(unsigned char)((0x7fffffffu % (i1 | 1u)) + (unsigned)c0);
                    }
                    if (0x8fd6d8bbu) {
                        do { if (--fuel == 0u) goto done;
                            if (garr[u2 & 7u]) break;
                        } while (i2++ < 6u && (8u / ((unsigned)h1 | 1u)));
                        e0 = e0 * 0.5L + (long double)(0x80000000u & 1023u);
                    }
                    h0 = (short)(0x7fffffffu | (((unsigned)x0 ? garr[u2 & 7u] : 0x58ce89deu) - p2));
                    break; (void)((unsigned)((int)r0.y >= (int)6u));
                    c1 = (signed char)(unsigned)l0;
                    break; (void)((unsigned)(x0 >> 70));
                }
            }
            g0 = (unsigned)c0;
            if (((i1 - r0.x) % ((unsigned)h1 | 1u))) break;
            for (;;) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(u0 && (unsigned)((unsigned)e0 == (unsigned)d0)));
                if ((unsigned)((garr[u2 & 7u] % (0u | 1u)) == 0xcb30b177u)) continue;
                if (budget != 0u) { budget -= 1u; u1 = fn1(i0, (0x7fffffffu & (8u - (unsigned)c1)), -(a0[u1 & 3u] >> ((unsigned)(0x1f53e40bu || 0x1c202944u) & 31u))); }
                if (budget != 0u) { budget -= 1u; u0 = fn3((0x80000000u & 9u), (unsigned)((int)(u3 & (unsigned)(x0 >> 70)) < (int)*mp), (0x7fffffffu - (p2 / ((unsigned)s0 | 1u)))); }
                if (p0) goto L0;
            }
            c0 = (unsigned char)*mp;
            r0.x = (unsigned)((int)(5u << (0x21653dd5u & 31u)) < (int)(0u ^ 0x1561be3eu));
        }
    }
    g1 += (unsigned)((short)~((unsigned)w0 >> (i2 & 31u)) > (signed char)0xcc6910ddu);
    switch ((unsigned)((int)~(v0 << ((unsigned)s1 & 31u)) < (int)(unsigned)d0) & 7u) {
        { unsigned t3; double z3; if ((((unsigned)e0 - ((unsigned)s0 - u1))) & 1u) { t3 = (5u + m0); z3 = (double)(((u2 / (0xbcde07eu | 1u))) & 255u); } if ((((unsigned)e0 - ((unsigned)s0 - u1))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            goto done;
            u3 += ~((~(unsigned)(0x80000000u == (unsigned)!(unsigned)(a0[i0 & 3u] < (unsigned)(w0 >> 29))) + i0) + p1);
            if (u1) goto L0;
            if ((unsigned)(*mp && a0[u1 & 3u])) {
                b0 = (unsigned)((int)(v0 | garr[u2 & 7u]) < (int)(*mp % (0x10000u | 1u))) != 0u;
                if (0x7fffffffu) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)x0 ? i0 : 0x80000000u), (unsigned)(unsigned char)((unsigned)(w0 >> 29) | 0x6fbf56a5u), p1); }
                    if (0x78dc0beau) goto L3;
                    r0.x = ((unsigned)(u2 < 9u) | garr[i1 & 7u]);
                }
            }
            a0[(unsigned)((unsigned)b0 && 0x7fffffffu) & 3u] = (unsigned)h0;
        }
        if (fuel < 8u) return (g0 / ((v0 ? (0x875d5f1cu & (unsigned)c1) : 6u) | 1u));
        while (i0++ < 7u && (0x10000u + (unsigned)(i2 < garr[i1 & 7u]))) { if (--fuel == 0u) goto done;
            if ((0x1d6a6932u & (0x7e30b360u - p1))) {
                w0 = w0 * 6364136223846793005ull + (unsigned)!(fuel + 0x7fffffffu);
                if (garr[u2 & 7u]) {
                    r0.y ^= ((unsigned)(unsigned char)(fuel % (1u | 1u)) % (a0[i0 & 3u] | 1u));
                    do { if (--fuel == 0u) goto done;
                        case 1u: ;
                        break; (void)((r0.x >> ((unsigned)(a0[i0 & 3u] && (unsigned)h1) & 31u)));
                        case 5u: ;
                        goto L2;
                        if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((unsigned)h0 < 0x10000u), 0x7fffffffu, ((unsigned)f0 - (9u % (p1 | 1u)))); }
                    } while (i1++ < 5u && (0x80000000u - ((unsigned)e0 & (unsigned)(w0 >> 29))));
                    for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        case 4u: ;
                        s0 = (int)((unsigned)c0 >> (~(0x80000000u * (unsigned)!((unsigned)(w0 >> 29) / (0x8af28828u | 1u))) & 31u));
                        u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)(8u == -(unsigned)(0x80000000u && (unsigned)((unsigned)s1 == (unsigned)h0))) < r0.y);
                        r0.y ^= (4u + (fuel ? g1 : u3));
                        if ((unsigned)((unsigned)(u0 || 0x10000u) || (unsigned)s1)) {
                            if ((unsigned)!((unsigned)c0 & 6u)) goto L4;
                            goto L3;
                        } else {
                            w0 ^= (unsigned long long)*mp << (((unsigned)(0xb84f2012u && (unsigned)s1) | (unsigned)(short)((unsigned)d0 ^ (unsigned)x0)) & 63u);
                            if (u3 == 7u) return (*mp % (0xffffffffu | 1u));
                            if (budget != 0u) { budget -= 1u; u1 = fn1(u3, (unsigned)x0, p2); }
                            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)d0, (unsigned)s1, ((unsigned)h1 / (-(*q0 * (unsigned)d0) | 1u))); }
                        }
                        default: ;
                    }
                }
                i0 = (unsigned)(v0 < ~(unsigned)(u0 || p2)) & 15u;
            } else {
                while (i1++ < 2u && (g0 & *mp)) { if (--fuel == 0u) goto done;
                    g1 += (i2 ? (unsigned)h1 : (unsigned)(short)(unsigned)((short)(*mp << ((unsigned)c0 & 31u)) > (signed char)(unsigned)e0));
                    h0 = (short)(unsigned)(0u || (unsigned)((int)0xb7685334u < (int)(unsigned)(i0 && 0x80000000u)));
                    l0 = (long)((unsigned long)l0 + ~(*mp ^ garr[u2 & 7u]));
                    u0 = u0 * 0x9e3779b1u + p2;
                }
                case 6u: ;
                if ((0xa1679945u * ((unsigned)(w0 >> 29) | (unsigned)s1))) break;
                case 0u: ;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn2(~(unsigned)((unsigned)l0 || (unsigned)((short)0xf3b1b000u > (signed char)(unsigned)(w0 >> 29))), (unsigned)w0, i2); }
            if ((v0 | (unsigned)h0)) {
                b0 = i0 != 0u;
                break;
                d0 = d0 * 0.5 + (double)(((0x10000u * 7u) + (unsigned)!(garr[u2 & 7u] << (0x62ee8548u & 31u))) & 1023u);
                case 7u: ;
            } else {
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    while (i2++ < 5u && ((0x7fffffffu * (unsigned)d0) - p2)) { if (--fuel == 0u) goto done;
                        if (~((0u ^ g0) | p0)) continue;
                        q0 = &garr[(unsigned)(signed char)(0x7fffffffu % (0x16ae479fu | 1u)) & 7u];
                        switch ((unsigned)(w0 >> 29) & 7u) {
                            x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)e0 < (unsigned)f0) & 0x7fffffffu);
                            case 7u: ;
                            default: ;
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)x0 >= (int)(unsigned)s1), (0xa4c56fceu * (unsigned)c0), u1); }
                    }
                    do { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)((((garr[i1 & 7u] ? (unsigned)h0 : p2) & 8u) / ((unsigned)w0 | 1u)) & 1023u);
                        if ((unsigned)c1) break;
                        if (a0[u1 & 3u]) break;
                    } while (i2++ < 3u && (unsigned)((short)(p0 % (i1 | 1u)) > (signed char)i0));
                }
                garr[((unsigned)x0 ^ r0.x) & 7u] = (unsigned)(m0 < (p0 << (0xffffffffu & 31u)));
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (9u) break;
                }
            }
            if ((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)w0)) goto L1;
            if (i2) {
                if (p0) continue;
                if (u3 == 7u) return (unsigned)((int)(m0 * 0x7fffffffu) >= (int)(unsigned)(0xffffffffu || 5u));
                if (((unsigned)((short)(unsigned)w0 > (signed char)0x10000u) / ((unsigned)s0 | 1u))) {
                    if ((((unsigned)h0 >> (8u & 31u)) << ((unsigned)h1 & 31u))) continue;
                } else {
                    m0 ^= 1u;
                    i1 = (~(i0 ^ i0) - r0.x) & 15u;
                    u3 = (unsigned)(((unsigned)((short)p1 > (signed char)u3) ? 5u : (unsigned)e0) < 0x7fffffffu);
                    m0 ^= (unsigned)((unsigned)(i2 || i0) < (unsigned)h1);
                }
            }
            if (i2) goto L4;
        }
        case 3u: ;
    }
    switch ((unsigned)((3u & i2) || 0xc56a2d96u) & 7u) {
        if (((0x37dbc54u % (g1 | 1u)) ^ u2)) {
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                u3 = (((unsigned)c0 * 0x7fffffffu) + (unsigned)(signed char)(0xb3ac2063u ? m0 : a0[i0 & 3u]));
                b0 = r0.y != 0u;
            }
            c0 = (unsigned char)4u;
        } else {
            f0 = f0 * 0.5f + (float)((5u / ((unsigned)((g1 & p1) || (4u - 0xf497f868u)) | 1u)) & 255u);
        }
        while (i0++ < 3u && (*q0 / ((unsigned)(7u && 0x9f3c843au) | 1u))) { if (--fuel == 0u) goto done;
            u0 = (8u ? (unsigned)b0 : (unsigned)(signed char)(unsigned)((short)0xffffffffu > (signed char)0x10000u));
            do { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)((int)0x10000u < (int)(0xffffffffu - (unsigned)(0x80000000u && 0x7fffffffu))) & 1023u);
            } while (i1++ < 6u && (v0 ^ u3));
            l0 = (long)((unsigned long)l0 + -(p1 | (unsigned)c1));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)c0 ^ m0), (u2 & 0x4fb6d8a0u), (0x577d9629u + 2u)); }
        while (i0++ < 7u && ((unsigned)(0x692f4779u < *mp) / ((unsigned)h0 | 1u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)(signed char)((unsigned)(w0 >> 29) % ((unsigned)((short)0x80000000u > (signed char)i0) | 1u)), (unsigned)(garr[u2 & 7u] || 0x7fffffffu), (unsigned)((short)(unsigned)((int)(unsigned)s0 >= (int)0x80000000u) > (signed char)7u)); }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        r0.x = ((*mp | fuel) - (unsigned)c1);
                        s1 = (int)((unsigned)s1 + (unsigned)(0x10000u || (unsigned)w0));
                        u2 = u2 * 0x9e3779b1u + (unsigned)((int)2u >= (int)(unsigned)!(unsigned)((v0 << (p1 & 31u)) && (unsigned)(short)(u1 - i0)));
                        if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)w0, ((unsigned)c1 % (0x7fffffffu | 1u)), 0x7fffffffu); }
                    }
                    g0 = u1;
                    x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)x0 || a0[i0 & 3u]);
                    v0 = (unsigned)((short)*mp > (signed char)0x7fffffffu);
                    e0 = e0 * 0.5L + (long double)(((unsigned)c1 | 0x7fffffffu) & 1023u);
                }
                c0 = (unsigned char)0xe7fef493u;
                c1 = (signed char)(u0 | fuel);
                s0 = (int)(g0 | (r0.x / ((unsigned)s1 | 1u)));
                while (i2++ < 4u && r0.y) { if (--fuel == 0u) goto done;
                    case 1u: ;
                    case 3u: ;
                    case 6u: ;
                }
            }
        }
    }
    v0 = 7u;
    for (;;) { if (--fuel == 0u) goto done;
        if ((0x7fffffffu | 0x80000000u)) break;
    }
    g0 = (unsigned)((short)(unsigned)(unsigned char)(g0 % ((unsigned)((int)8u < (int)(unsigned)w0) | 1u)) > (signed char)(8u | (unsigned)h0));
    if (~(garr[i1 & 7u] - (unsigned)b0)) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 14u, 0xa8e9db7eu, 0xdebfa910u },
        { 5u, 0x1628052eu, 0x75a27d0u },
        { 8u, 0x816cc8f3u, 0xc1dc2dfeu },
        { 2u, 0xd3e92717u, 0x42545c8u },
        { 3u, 0x7b2b3cdu, 0x4fd53413u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
