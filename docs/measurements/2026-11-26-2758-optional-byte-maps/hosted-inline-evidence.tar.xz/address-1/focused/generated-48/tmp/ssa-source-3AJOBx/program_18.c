// test-ssa-source's program of seed 134000420 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xe8e97587u, g1 = 0xdb701076u;
static unsigned garr[8] = { 0xfe6c77b5u, 0x75c730a7u, 0x4aa35aafu, 0xd7f50f45u, 0x47f775d2u, 0xb59698c0u, 0x26ddf5a6u, 0x96912363u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    h0 = (short)3u;
    for (;;) { if (--fuel == 0u) goto done;
        g0 = (i0 % (((unsigned)h1 >> (u2 & 31u)) | 1u));
        if ((unsigned)(p1 == (unsigned)e0)) {
            w0 ^= (unsigned long long)g1 << ((((unsigned)!(unsigned)((int)garr[u2 & 7u] < (int)0x10000u) / (*mp | 1u)) >> (r0.y & 31u)) & 63u);
            h1 = (unsigned short)(h1 + (unsigned)f0);
            L0: if (--fuel == 0u) goto done;
        }
        m0 ^= (((unsigned)s1 & (0x80000000u + ((unsigned)b0 & (unsigned)l0))) >> ((unsigned)h1 & 31u));
        for (;;) { if (--fuel == 0u) goto done;
            *mp = (((unsigned)e0 + i1) | r0.x);
        }
        *q0 = garr[i1 & 7u];
        break; (void)(u0);
    }
    L1: if (--fuel == 0u) goto done;
    if (*q0) {
        goto done;
        if ((3u | (u0 >> (a0[u1 & 3u] & 31u)))) goto L1;
        a0[g0 & 3u] = ((unsigned)(unsigned char)(p2 >> ((unsigned)((unsigned)s0 < (unsigned)s1) & 31u)) >> (7u & 31u));
        if (v0) {
            goto L0;
            while (i0++ < 6u && 7u) { if (--fuel == 0u) goto done;
                g0 = (p0 - (unsigned)(*mp && (unsigned)s1));
                for (;;) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((unsigned)l0 & 1023u);
                    if (fuel < 8u) return (((0xbc554644u << ((unsigned)d0 & 31u)) / (0x101a04fcu | 1u)) / ((unsigned)l0 | 1u));
                    i2 = (unsigned)(~(3u ^ ((unsigned)((unsigned)e0 && 0x7fffffffu) << (0u & 31u))) || 0xe347b2bdu) & 15u;
                    c0 = (unsigned char)(~(0x7fffffffu + u2) / ((unsigned)((unsigned)(g1 || (unsigned)s1) == (unsigned)c1) | 1u));
                }
                v0 = *mp;
            }
            r0.y ^= (unsigned)((short)(unsigned)(p2 && g1) > (signed char)a0[u1 & 3u]);
            w0 = w0 * 6364136223846793005ull + (u2 / ((unsigned)d0 | 1u));
        } else {
            if ((unsigned)(p0 && ((unsigned)c0 | u0))) goto L3;
            if ((unsigned)(1u == (unsigned)l0)) {
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)garr[u2 & 7u] >= (int)a0[i0 & 3u])) goto L4;
                    u1 += (0x7fffffffu ? 0x7fffffffu : (unsigned)l0);
                    v0 = (((unsigned)((unsigned)((short)0x2a84e150u > (signed char)(unsigned)f0) < 2u) % ((unsigned)f0 | 1u)) >> (0xce98dcbbu & 31u));
                }
                s0 = (int)(unsigned)(signed char)((unsigned)h0 ? (unsigned)(w0 >> 29) : (unsigned)(unsigned char)((unsigned)s1 | u1));
                do { if (--fuel == 0u) goto done;
                    i0 = (unsigned)((int)((unsigned)s0 >> ((unsigned)b0 & 31u)) < (int)(0xb50b12c7u | i1)) & 15u;
                    L2: if (--fuel == 0u) goto done;
                    r0.y ^= ((p0 * fuel) << ((garr[i1 & 7u] ^ 0xa70bcee1u) & 31u));
                    L3: if (--fuel == 0u) goto done;
                } while (i0++ < 7u && ((v0 + (unsigned)x0) - 0xbe220d52u));
            }
        }
        goto done;
        if (*q0) goto L2;
    } else {
        x0 = x0 * 0x100000001b3ull + (((unsigned)s0 ^ (unsigned)((short)(unsigned)h0 > (signed char)(0x97440b9eu >> (p2 & 31u)))) << (0x2dc93a02u & 31u));
        L4: if (--fuel == 0u) goto done;
        if (m0) goto L3;
        u3 = (*q0 % ((unsigned)((int)(unsigned)(*q0 || 0xf628d8e9u) >= (int)((unsigned)s1 * u1)) | 1u));
    }
    for (;;) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && (unsigned)((unsigned)w0 && a0[u1 & 3u])) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)u1 << (((r0.y - i2) + ~((unsigned)l0 * (unsigned)l0)) & 63u);
            if (*q0) break;
            if ((unsigned)((unsigned)d0 && (unsigned)f0)) break;
            e0 = e0 * 0.5L + (long double)(((unsigned)((u3 >> (8u & 31u)) < (unsigned)h0) ^ 0x9331aefu) & 1023u);
            for (;;) { if (--fuel == 0u) goto done;
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    u1 ^= (unsigned)((unsigned)c1 || ((r0.x | i0) / ((unsigned)s1 | 1u)));
                }
                break; (void)((2u | v0));
                if (((u0 & (unsigned)l0) ^ 0x40c685fu)) break;
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((a0[i0 & 3u] % ((unsigned)((short)u0 > (signed char)*q0) | 1u))) break;
                }
            }
            f0 = f0 * 0.5f + (float)(0x80000000u & 255u);
        }
        if ((unsigned)(u3 == (unsigned)(x0 >> 70))) break;
        g1 += (i2 + (unsigned)x0);
        do { if (--fuel == 0u) goto done;
            b0 = (unsigned)(short)(unsigned)((short)(unsigned)w0 > (signed char)((unsigned)e0 + ((unsigned)e0 - a0[i0 & 3u]))) != 0u;
        } while (i1++ < 4u && (*q0 * (unsigned)(unsigned char)(unsigned)(fuel || i2)));
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(short)((unsigned)((unsigned)(signed char)(unsigned)(g0 && 8u) == g1) << (r0.x & 31u)) && a0[i0 & 3u]));
    }
    if ((unsigned)(unsigned char)(garr[i1 & 7u] - (unsigned)((int)g1 >= (int)i0))) {
        if ((unsigned)(signed char)(unsigned)((int)(0x10000u - u3) < (int)0x561daa74u)) goto done;
        if (((unsigned)l0 ^ (p2 << ((unsigned)h0 & 31u)))) goto L1;
        { unsigned t0; double z0; if (((g1 | 3u)) & 1u) { t0 = (unsigned)x0; z0 = (double)(((unsigned)(unsigned char)(unsigned)((int)(0x80000000u & fuel) < (int)i1)) & 255u); } if (((g1 | 3u)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            switch ((unsigned)((int)p0 >= (int)r0.x) & 7u) {
                u3 = (unsigned)((unsigned)(x0 >> 70) == -((unsigned)(8u == fuel) << ((unsigned)(w0 >> 29) & 31u)));
            }
            goto L0;
            if (0xffffffffu) goto L4;
        }
        if (*q0) goto L2;
        if ((g0 ^ r0.y)) goto done;
        if (g1) goto L2;
    }
    if ((a0[u1 & 3u] - (unsigned)e0)) goto L0;
    w0 ^= (unsigned long long)(unsigned)f0 << ((unsigned)(0x7fffffffu || (unsigned)((9u / (0x9a27619u | 1u)) < (unsigned)c0)) & 63u);
    switch (((unsigned)(x0 >> 70) | (unsigned)((int)(unsigned)h1 >= (int)u1)) & 7u) {
        if ((unsigned)((int)u3 < (int)r0.x)) {
            case 5u: ;
            case 3u: ;
            do { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)((int)g1 >= (int)0x10000u) & 1023u);
                case 0u: ;
                case 7u: ;
                f0 = f0 * 0.5f + (float)((8u / (u1 | 1u)) & 255u);
                default: ;
            } while (i0++ < 3u && (unsigned)(short)(((unsigned)s0 % (0u | 1u)) ^ (unsigned)x0));
        }
    }
    w0 ^= (unsigned long long)0xff64d14eu << (i0 & 63u);
    f0 = f0 * 0.5f + (float)((unsigned)((*mp % (g1 | 1u)) < (r0.x & (0xc3309735u | u3))) & 255u);
    { unsigned t1; double z1; if ((r0.x) & 1u) { t1 = ((unsigned)(v0 < 0x882c4322u) * u0); z1 = (double)((0xffffffffu) & 255u); } if ((r0.x) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        { unsigned t2; double z2; if (((-(0xf068a09au / (r0.x | 1u)) / (p0 | 1u))) & 1u) { t2 = (unsigned)(0x7fffffffu == garr[u2 & 7u]); z2 = (double)(((unsigned)c0) & 255u); } if (((-(0xf068a09au / (r0.x | 1u)) / (p0 | 1u))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            i0 = (0x7fffffffu | ((unsigned)(short)(0x80000000u + (unsigned)(x0 >> 70)) * (garr[i1 & 7u] << (0xde6356d7u & 31u)))) & 15u;
            if (0xffffffffu) goto L3;
            if ((unsigned)(w0 >> 29)) goto L2;
            *q0 += ((unsigned)s0 % ((unsigned)((int)*mp < (int)a0[i0 & 3u]) | 1u));
            goto done;
            if ((0x10000u / ((0xffffffffu >> (u0 & 31u)) | 1u))) goto L2;
        }
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)!((unsigned)(x0 >> 70) * (unsigned)(unsigned char)(unsigned)((short)(unsigned)l0 > (signed char)*mp))) break;
            if ((unsigned)s1) break;
            r0.y ^= garr[u2 & 7u];
            goto done;
        }
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)(x0 >> 70)) break;
            w0 ^= (unsigned long long)a0[i0 & 3u] << ((0x80000000u & (unsigned)d0) & 63u);
            if (p1) {
                *mp = ((unsigned)w0 * (unsigned)((unsigned)((unsigned)h0 < (unsigned)c0) == (unsigned)(w0 >> 29)));
                w0 ^= (unsigned long long)(u0 << ((unsigned)b0 & 31u)) << ((unsigned)x0 & 63u);
                d0 = d0 * 0.5 + (double)((garr[u2 & 7u] | p1) & 1023u);
                e0 = e0 * 0.5L + (long double)((unsigned)((int)garr[i1 & 7u] < (int)(unsigned)((int)(unsigned)h1 < (int)(unsigned)c0)) & 1023u);
                if ((unsigned)e0) break;
            } else {
                if ((unsigned)x0) continue;
                if (1u) {
                    g0 = (unsigned)((unsigned)s1 == 0xce2b871cu);
                    if (m0) {
                        if ((unsigned)((unsigned)x0 < (unsigned)(p2 && u2))) break;
                        c0 = (unsigned char)(unsigned)(u2 && (unsigned)(0xc6dcf8b8u && (unsigned)h1));
                        w0 ^= (unsigned long long)(unsigned)(g1 == 0x10000u) << (((v0 / (p1 | 1u)) >> (a0[u1 & 3u] & 31u)) & 63u);
                        a0[((unsigned)w0 % (0xffffffffu | 1u)) & 3u] = ((unsigned)(a0[i0 & 3u] || a0[i0 & 3u]) - ((unsigned)d0 - (0x10000u | garr[i1 & 7u])));
                        h1 = (unsigned short)(h1 + ((unsigned)(u3 == 0x7fffffffu) / (fuel | 1u)));
                        i0 = -((unsigned)(x0 >> 70) + ((0x80000000u / (5u | 1u)) % (((unsigned)b0 * 3u) | 1u))) & 15u;
                    } else {
                        m0 ^= (~((0xc765abaeu | u0) + (unsigned)l0) | a0[u1 & 3u]);
                    }
                    break; (void)((unsigned)(x0 >> 70));
                    x0 = x0 * 0x100000001b3ull + ((0xf2eb15deu | i2) + 0x70faafcfu);
                } else {
                    if ((unsigned)(0x80000000u == g0)) break;
                    break; (void)((unsigned)(*mp || 0xffffffffu));
                }
                g0 = (unsigned)(i1 || p0);
                g0 = (unsigned)(-(unsigned)(fuel || (unsigned)(4u || u3)) == 0xffffffffu);
            }
            switch ((unsigned)(short)(0x7fffffffu | (unsigned)(v0 == (unsigned)h1)) & 7u) {
                if ((unsigned)(0xcf5a320eu && (unsigned)b0)) continue;
                w0 = w0 * 6364136223846793005ull + (-((unsigned)s1 % ((u1 - (unsigned)h1) | 1u)) & u1);
                *q0 = (unsigned)(signed char)((unsigned)w0 | 0x44960800u);
                case 5u: ;
            }
        }
        g1 += (unsigned)((unsigned)s1 == (unsigned)((int)a0[u1 & 3u] < (int)u0));
        *q0 = (unsigned)!(garr[i1 & 7u] << (9u & 31u));
    }
    do { if (--fuel == 0u) goto done;
        s0 = (int)(unsigned)(unsigned char)(((unsigned)f0 % ((unsigned)w0 | 1u)) % ((unsigned)((short)(unsigned)(fuel || (unsigned)l0) > (signed char)0xffffffffu) | 1u));
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)((int)a0[u1 & 3u] < (int)v0) & 7u) {
                h1 = (unsigned short)(h1 + (-(unsigned)((unsigned)s0 == (unsigned)(v0 && v0)) - 0x323fe482u));
                case 0u: ;
                h0 = (short)(unsigned)c1;
            }
        }
        do { if (--fuel == 0u) goto done;
            s0 = (int)(unsigned)((unsigned)((int)u3 >= (int)(unsigned)h0) == (6u / ((p0 - a0[u1 & 3u]) | 1u)));
            continue; (void)(((u2 % (i0 | 1u)) << (2u & 31u)));
            for (;;) { if (--fuel == 0u) goto done;
                h0 = (short)(unsigned)((unsigned)h1 == (unsigned)(6u && ((*mp << ((unsigned)x0 & 31u)) % (a0[u1 & 3u] | 1u))));
                m0 ^= (unsigned)(unsigned char)((unsigned)e0 * (unsigned)((int)(unsigned)l0 >= (int)0xffffffffu));
                if ((unsigned)((0x7832f5e5u & 0x7fffffffu) && 0x7ce1efb6u)) break;
            }
            if ((unsigned)((int)g0 >= (int)0xffffffffu)) break;
        } while (i1++ < 7u && (unsigned)(0x13a6211cu || 6u));
        s1 = (int)((unsigned)s1 + (unsigned)((int)0x80000000u < (int)(unsigned)!(unsigned)(v0 || u3)));
        continue; (void)((fuel ^ (unsigned)((int)*q0 >= (int)0u)));
        if ((v0 & g0)) {
            m0 ^= (((unsigned)e0 << ((unsigned)d0 & 31u)) + g0);
            s1 = (int)((unsigned)s1 + (p1 ? (unsigned)e0 : (unsigned)c0));
            s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)(r0.y < r0.y) >= (int)((unsigned)((unsigned)f0 || p0) / (4u | 1u))));
        } else {
            v0 = ~(unsigned)((int)(unsigned)l0 >= (int)((u0 - (unsigned)s1) / ((unsigned)s1 | 1u)));
            *q0 = (unsigned)(signed char)(u2 % ((unsigned)((int)(((unsigned)x0 << (0x80000000u & 31u)) % ((unsigned)c0 | 1u)) >= (int)garr[i1 & 7u]) | 1u));
            if ((unsigned)(short)(m0 / ((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)s0) | 1u))) goto done;
        }
    } while (i0++ < 2u && (u2 >> (((unsigned)s0 % (2u | 1u)) & 31u)));
    if (u0) goto L1;
    if (fuel < 8u) return (-(u3 - garr[i1 & 7u]) / ((unsigned)(signed char)(0x1f8daa07u & *mp) | 1u));
    w0 = w0 * 6364136223846793005ull + (p1 / ((unsigned)(0u < ((unsigned)h0 - 1u)) | 1u));
    goto L1;
    if (g0) goto L4;
    if ((unsigned)(6u < (unsigned)(w0 >> 29))) goto done;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (a0[i0 & 3u]) continue;
        e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)((short)a0[u1 & 3u] > (signed char)garr[u2 & 7u]) < (int)((unsigned)c0 << ((unsigned)l0 & 31u))) & 1023u);
        *q0 = (unsigned)(unsigned char)(garr[i1 & 7u] ^ (((unsigned)s1 ? 0xffffffffu : p0) | 0x122e069cu));
        if (v0) break;
        switch (((i0 % ((unsigned)x0 | 1u)) + garr[u2 & 7u]) & 7u) {
            v0 = (((unsigned)(x0 >> 70) ^ (unsigned)(((unsigned)f0 << ((unsigned)e0 & 31u)) && u0)) << (garr[u2 & 7u] & 31u));
            case 2u: ;
            *mp = ((u1 + ((unsigned)b0 % (u1 | 1u))) >> ((unsigned)(8u < *mp) & 31u));
        }
    }
    w0 = w0 * 6364136223846793005ull + 0u;
    i0 = -(((unsigned)(0xa06c5105u < p2) / (p0 | 1u)) & (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)l0)) & 15u;
    if ((unsigned)(g1 && -(unsigned)(r0.y < 9u))) goto L3;
    w0 = w0 * 6364136223846793005ull + (~(0xffffffffu * 0x7fffffffu) + 3u);
    if ((unsigned)((int)p0 < (int)(unsigned)(x0 >> 70))) goto L0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u1 = fn0(0xffffffffu, (g0 * (a0[i0 & 3u] - (unsigned)d0)), (unsigned)(8u && p0)); }
    { unsigned t0; double z0; if (((unsigned)((short)*mp > (signed char)2u)) & 1u) { t0 = ((unsigned)((int)(unsigned)x0 < (int)0x7bfd4a29u) / (0x7fffffffu | 1u)); z0 = (double)(((unsigned)(w0 >> 29)) & 255u); } if (((unsigned)((short)*mp > (signed char)2u)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        *mp = ~((unsigned)(garr[i1 & 7u] || r0.y) + 0x80000000u);
        if ((i2 - garr[u2 & 7u])) {
            d0 = d0 * 0.5 + (double)(((unsigned)f0 & ~(unsigned)(u2 == garr[u2 & 7u])) & 1023u);
            if (~(unsigned)((short)0x5755211u > (signed char)0xffffffffu)) goto L4;
            a0[(unsigned)s1 & 3u] = 0x7fffffffu;
            if ((unsigned)((int)(unsigned)((int)garr[u2 & 7u] >= (int)u0) < (int)i0)) goto L0;
            v0 = ((unsigned)f0 ? g0 : 0x7fffffffu);
            if ((i2 << (0xffffffffu & 31u))) {
                { unsigned t1; double z1; if ((2u) & 1u) { t1 = (0xe23e33c4u & 0x5c61667fu); z1 = (double)((((unsigned)(u2 < *q0) >> (a0[u1 & 3u] & 31u))) & 255u); } if ((2u) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    q0 = &garr[((0x291314ceu + m0) % ((p1 | (unsigned)f0) | 1u)) & 7u];
                }
                for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)i1 > (signed char)*mp)) break;
                    *q0 += (unsigned)(5u || r0.x);
                    if ((unsigned)b0) {
                        for (;;) { if (--fuel == 0u) goto done;
                            b0 = (0x3a25145du / ((unsigned)((unsigned)l0 || garr[u2 & 7u]) | 1u)) != 0u;
                            g0 = (((unsigned)c1 - (unsigned)h1) % ((unsigned)((unsigned)w0 < (unsigned)(3u || (unsigned)b0)) | 1u));
                            if (budget != 0u) { budget -= 1u; u2 = fn0(r0.y, -(i2 >> ((unsigned)x0 & 31u)), (8u ^ 0x2aa1b0e8u)); }
                            v0 = (~(8u + i2) >> (0x5ccba6edu & 31u));
                            if (budget != 0u) { budget -= 1u; u2 = fn0((a0[i0 & 3u] + g1), ((unsigned)h0 ? fuel : fuel), (unsigned)x0); }
                        }
                        f0 = f0 * 0.5f + (float)((unsigned)x0 & 255u);
                        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                            l0 = (long)((unsigned long)l0 + 7u);
                        }
                        if (u3 == 7u) return (unsigned)(short)(unsigned)((int)(unsigned)(unsigned char)(a0[i0 & 3u] | (unsigned)((unsigned)c0 < 4u)) >= (int)(unsigned)((short)0xffffffffu > (signed char)garr[i1 & 7u]));
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)((short)1u > (signed char)0x8a6388c2u) || p2), r0.x, (unsigned)(g1 < 6u)); }
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!(p0 ^ (unsigned)b0), (r0.x - g1), ~((8u ^ i0) << ((unsigned)b0 & 31u))); }
                    } else {
                        m0 ^= (unsigned)((int)g1 >= (int)p1);
                        if ((garr[i1 & 7u] | 0xffffffffu)) break;
                        continue; (void)(i0);
                    }
                }
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)f0 && 0u);
                if (budget != 0u) { budget -= 1u; u2 = fn0(((r0.y / (g1 | 1u)) / (u0 | 1u)), (unsigned)((short)(unsigned)b0 > (signed char)r0.y), (unsigned)(*mp || u1)); }
                w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(unsigned)(((unsigned)(x0 >> 70) * 0x7fffffffu) < (unsigned)s0);
            } else {
                i0 = (unsigned)(short)((g1 % (p1 | 1u)) ^ a0[i0 & 3u]) & 15u;
                a0[-(fuel + a0[u1 & 3u]) & 3u] = ((0x10000u + u2) ^ (unsigned)((unsigned)c0 && u0));
                goto L1;
                u2 = u2 * 0x9e3779b1u + ((unsigned)b0 ? i0 : u0);
            }
        } else {
            w0 = w0 * 6364136223846793005ull + (5u & (unsigned)((0x80000000u / (0x80000000u | 1u)) < (unsigned)s0));
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (fuel < 8u) return ((unsigned)((int)(unsigned)h0 < (int)(unsigned)x0) + g1);
            break; (void)(6u);
            while (i1++ < 7u && ~((unsigned)((short)r0.y > (signed char)u2) - 0xffffffffu)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(garr[u2 & 7u], (fuel + garr[u2 & 7u]), p2); }
            }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(*q0, (2u + (unsigned)(short)(v0 | (unsigned)h0)), (unsigned)(p0 || *mp)); }
        w0 ^= (unsigned long long)0x10000u << (((unsigned)((unsigned)x0 < 0x80000000u) & (unsigned)x0) & 63u);
    }
    if (((unsigned)w0 + r0.x)) {
        { unsigned t2; double z2; if (((unsigned)(p2 && i0)) & 1u) { t2 = -(unsigned)(4u || (0xffffffffu * m0)); z2 = (double)(((unsigned)h1) & 255u); } if (((unsigned)(p2 && i0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            h0 = (short)(unsigned)(((unsigned)(p2 < u1) + 9u) && 0x95f743c4u);
            if (budget != 0u) { budget -= 1u; u0 = fn0(~(0x80000000u >> ((unsigned)((short)0x7fffffffu > (signed char)v0) & 31u)), (unsigned)((int)7u < (int)u1), (unsigned)(u0 && (unsigned)s0)); }
        }
        for (;;) { if (--fuel == 0u) goto done;
            if (((unsigned)h1 & ~(fuel & 0x7fffffffu))) break;
        }
        if ((0xfa817248u % ((unsigned)((int)6u >= (int)(unsigned)e0) | 1u))) goto done;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            u0 = u0 * 0x9e3779b1u + ((unsigned)h1 / (garr[u2 & 7u] | 1u));
            u2 = (unsigned)(w0 >> 29);
            q0 = &garr[0x7fffffffu & 7u];
        }
    }
    if (((unsigned)(0x80000000u && i1) + p0)) {
        if ((unsigned)h1) goto L2;
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(0x7fffffffu, a0[u1 & 3u], (((unsigned)x0 - u2) & (unsigned)s1)); }
            *q0 += 0xffffffffu;
            if (((0x80000000u - (unsigned)l0) | u3)) break;
        }
    }
    if ((u0 % (g0 | 1u))) {
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((0xffffffffu * (unsigned)d0), (unsigned)(short)(a0[i0 & 3u] * p0), (unsigned)(signed char)((unsigned)(w0 >> 29) % (0u | 1u))); }
            if ((unsigned)(short)((unsigned)((short)3u > (signed char)i1) & g1)) break;
            if (((unsigned)(0x6727e73du < (unsigned)c0) / (garr[u2 & 7u] | 1u))) goto L2;
        } while (i0++ < 6u && (unsigned)((short)0xffffffffu > (signed char)(unsigned)(0xb6b013bfu && 0xccdcbf0bu)));
        v0 = (p1 | (unsigned)((short)(unsigned)((short)(unsigned)f0 > (signed char)0x7fffffffu) > (signed char)(unsigned)e0));
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)!(unsigned)(((unsigned)w0 << (v0 & 31u)) || ~(0x76ef6266u * (unsigned)(i1 == 0xffffffffu)));
            if (fuel < 8u) return (unsigned)((int)(0x80000000u ? r0.y : 4u) >= (int)*q0);
            if (((u2 + (unsigned)h1) / ((unsigned)l0 | 1u))) goto L0;
        }
    } else {
        if ((i2 - 0x54a2853bu)) {
            if ((p2 & (unsigned)((short)(unsigned)b0 > (signed char)9u))) goto done;
            do { if (--fuel == 0u) goto done;
                b0 = (0x10000u / ((unsigned)b0 | 1u)) != 0u;
                if (u3 == 7u) return (u0 & (r0.x - g0));
            } while (i0++ < 7u && (i2 | 0xf01ba64fu));
        }
        L0: if (--fuel == 0u) goto done;
    }
    *mp = (unsigned)(0xc333de34u == (unsigned)f0);
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 = u0 * 0x9e3779b1u + (~(fuel ^ (unsigned)s1) | garr[i1 & 7u]);
        h0 = (short)0x10000u;
        *q0 = (unsigned)(unsigned char)((unsigned)(a0[u1 & 3u] == (p0 + u2)) ^ (unsigned)((unsigned)c1 == v0));
        if (3u) break;
        L1: if (--fuel == 0u) goto done;
    }
    goto L0;
    g1 += ((unsigned)(w0 >> 29) * (unsigned)((unsigned)!(0xfc553fe4u + (unsigned)((int)r0.y < (int)i1)) && 3u));
    while (i0++ < 5u && (unsigned)d0) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0xffffffffu)) break;
    }
    garr[(0x9aed2c0u & u1) & 7u] = ((((unsigned)b0 * (unsigned)h0) & ((unsigned)l0 * (unsigned)s1)) << (i1 & 31u));
    if ((unsigned)((unsigned)(w0 >> 29) || (unsigned)e0)) goto L1;
    *mp = ((0xffffffffu % (v0 | 1u)) & u1);
    L2: if (--fuel == 0u) goto done;
    if (g1) goto L0;
    switch (0x10000u & 7u) {
        goto L2;
        f0 = f0 * 0.5f + (float)(((unsigned)w0 - a0[i0 & 3u]) & 255u);
        L3: if (--fuel == 0u) goto done;
        if ((v0 & (p1 << ((unsigned)c0 & 31u)))) {
            h0 = (short)(unsigned)((4u << (u0 & 31u)) < ((unsigned)(7u < g0) - m0));
        } else {
            i0 = (unsigned)!(1u / ((unsigned)((u3 / ((unsigned)s0 | 1u)) < (unsigned)x0) | 1u)) & 15u;
            if ((unsigned)((unsigned)w0 || 0xf1fd3623u)) goto L2;
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                i1 = (((unsigned)((int)p1 < (int)0x25d4a56au) + (unsigned)h1) & (unsigned)s1) & 15u;
                m0 ^= (8u * r0.x);
                l0 = (long)((unsigned long)l0 + (unsigned)((short)u0 > (signed char)(3u + a0[i0 & 3u])));
                if ((garr[u2 & 7u] - i0)) continue;
                *q0 += ((g0 + p2) & 0xb27b56c6u);
            }
        }
        case 5u: ;
    }
    q0 = &garr[(garr[u2 & 7u] | (u3 ^ 8u)) & 7u];
    e0 = e0 * 0.5L + (long double)((p1 / (0x80000000u | 1u)) & 1023u);
    if (0x8fcd2cecu) goto L4;
    h1 = (unsigned short)(h1 + (unsigned)(a0[i0 & 3u] || (i0 ? 0x10000u : *mp)));
    if ((unsigned)l0) goto L4;
    c1 = (signed char)garr[i1 & 7u];
    switch ((0xebdca634u << (garr[u2 & 7u] & 31u)) & 7u) {
        m0 ^= 0x415ecef9u;
        v0 = ((i1 / (0x80000000u | 1u)) * u2);
    }
    if (((unsigned)w0 ^ (unsigned)(x0 >> 70))) {
        goto done;
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((v0 << (m0 & 31u)));
            h0 = (short)0xffffffffu;
            garr[0xffffffffu & 7u] = -(unsigned)((int)(unsigned)(w0 >> 29) < (int)9u);
            i0 = (unsigned)(0xffffffffu || (9u * 0xffffffffu)) & 15u;
            if ((unsigned)(((unsigned)w0 / (garr[u2 & 7u] | 1u)) && p0)) continue;
            if (garr[i1 & 7u]) break;
        }
        goto L4;
        g0 = (unsigned)((short)(((i2 / ((unsigned)s1 | 1u)) * i1) << (0xfc4d4545u & 31u)) > (signed char)i1);
    } else {
        L4: if (--fuel == 0u) goto done;
        if (p0) {
            *q0 += p1;
            h1 = (unsigned short)(h1 + (unsigned)(x0 >> 70));
            u3 ^= (unsigned)((short)(i2 | (unsigned)!(unsigned)((short)u0 > (signed char)u3)) > (signed char)p1);
            u2 += ((unsigned)x0 & ((unsigned)f0 & 0x10000u));
        } else {
            if ((g1 << (((unsigned)b0 ^ garr[u2 & 7u]) & 31u))) goto L1;
            if ((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)(p1 || (unsigned)(w0 >> 29)))) goto done;
            c0 = (unsigned char)(p2 << ((unsigned)(1u && a0[i0 & 3u]) & 31u));
            if ((unsigned)((short)(m0 % ((unsigned)c0 | 1u)) > (signed char)0x80000000u)) goto L1;
        }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            *mp = 2u;
            u3 += (unsigned)(signed char)(a0[u1 & 3u] * u0);
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                b0 = (((((unsigned)b0 / (p0 | 1u)) / ((unsigned)e0 | 1u)) - g0) - (unsigned)e0) != 0u;
                break; (void)((unsigned)((int)(g1 * 0xf9716957u) < (int)2u));
                while (i2++ < 7u && ((unsigned)(garr[u2 & 7u] == u3) | u3)) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(fuel, u1, (unsigned)((unsigned)c0 == *mp)); }
                }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((fuel % (0x726a1655u | 1u)), ~(garr[i1 & 7u] ? r0.x : fuel), 0x33923f03u); }
            m0 ^= (unsigned)(short)(0x62714352u - (unsigned)(m0 || (unsigned)((short)0x10000u > (signed char)0xe9a3c083u)));
        }
        goto done;
    }
    c0 = (unsigned char)(unsigned)!((unsigned)!(unsigned)((int)v0 >= (int)(unsigned)l0) * 6u);
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)!((unsigned)((unsigned)h1 == 6u) >> (((unsigned)f0 * (unsigned)b0) & 31u)));
        switch (((unsigned)w0 / (garr[u2 & 7u] | 1u)) & 7u) {
            if ((unsigned)c1) {
                case 2u: ;
                if (0x10000u) goto L3;
                if ((unsigned)(unsigned char)(2u / ((garr[u2 & 7u] + u3) | 1u))) goto L3;
                if (budget != 0u) { budget -= 1u; u3 = fn0(p0, ((unsigned)((short)(unsigned)d0 > (signed char)1u) % (0x4eda4cfdu | 1u)), (unsigned)((short)0xeb087998u > (signed char)(unsigned)(w0 >> 29))); }
                if (((unsigned)((short)p2 > (signed char)(unsigned)(x0 >> 70)) / ((unsigned)l0 | 1u))) {
                    m0 ^= (unsigned)(signed char)((0xffffffffu * (0xc29dea2eu / ((unsigned)((int)*mp >= (int)p0) | 1u))) ^ 0xf7275683u);
                    garr[(unsigned)(unsigned char)(g0 | 0x10000u) & 7u] = (unsigned)((int)v0 < (int)(unsigned)c1);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(*q0, (unsigned)s1, (0xd8a76b7du << (*mp & 31u))); }
                    if ((unsigned)x0) goto L0;
                    case 7u: ;
                    u1 += 6u;
                }
                f0 = f0 * 0.5f + (float)(((a0[i0 & 3u] / (u2 | 1u)) ^ r0.y) & 255u);
            }
            if (0x10000u) goto L3;
            s0 = (int)(unsigned)((int)(0x7fffffffu - (unsigned)f0) < (int)(fuel >> (0x80000000u & 31u)));
            if (((unsigned)(i2 == u2) & garr[i1 & 7u])) goto L1;
        }
        if ((p0 + ((unsigned)(w0 >> 29) & 0xffffffffu))) goto L3;
        u1 = ((unsigned)x0 / ((unsigned)h1 | 1u));
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (-((unsigned)c0 >> (0xf7492fb9u & 31u))) break;
        do { if (--fuel == 0u) goto done;
            v0 = ((unsigned)(9u == (unsigned)c0) / (((0x80000000u - 0x7fffffffu) ^ a0[u1 & 3u]) | 1u));
        } while (i1++ < 2u && 2u);
        if ((unsigned)((int)0xffffffffu >= (int)p1)) break;
        garr[(unsigned)(*q0 && u1) & 7u] = (unsigned)(g1 == (unsigned)(0x364a8686u && (9u << ((unsigned)(w0 >> 29) & 31u))));
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            g0 = garr[u2 & 7u];
            v0 = u3;
            i2 = a0[u1 & 3u] & 15u;
        }
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)(unsigned)(unsigned char)(garr[i1 & 7u] % (0x633b4600u | 1u)) > (signed char)(unsigned)c0)) break;
                c1 = (signed char)((unsigned)(short)(0xffffffffu | v0) | 8u);
                if ((unsigned)((unsigned)((unsigned)s1 == 0x48050ea5u) || 0x18e3abcdu)) break;
            }
            if ((0xffffffffu - garr[u2 & 7u])) continue;
            do { if (--fuel == 0u) goto done;
                u1 = u1 * 0x9e3779b1u + i1;
                if (6u) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0(fuel, (0x6934d6e8u - (unsigned)h1), ((0x195cf511u + (unsigned)s0) << ((unsigned)e0 & 31u))); }
                if (fuel < 8u) return 0x4c5fdb14u;
                d0 = d0 * 0.5 + (double)(~(unsigned)((short)0x31a94049u > (signed char)(4u % (0xa9017u | 1u))) & 1023u);
            } while (i2++ < 7u && (unsigned)((unsigned)c1 < 0xffffffffu));
            switch (a0[u1 & 3u] & 7u) {
                if (budget != 0u) { budget -= 1u; u1 = fn0(i2, 0xffffffffu, (unsigned)((int)(unsigned)c1 >= (int)5u)); }
                u0 = u0 * 0x9e3779b1u + (unsigned)(signed char)(unsigned)((unsigned)d0 && (unsigned)d0);
            }
            { unsigned t3; double z3; if (((0x866aaef1u >> ((unsigned)s1 & 31u))) & 1u) { t3 = (unsigned)b0; z3 = (double)(((u3 & (unsigned)e0)) & 255u); } if (((0x866aaef1u >> ((unsigned)s1 & 31u))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                i0 = (unsigned)(0x80000000u && (unsigned)f0) & 15u;
            }
        } while (i1++ < 7u && (unsigned)(u1 == (unsigned)c1));
        do { if (--fuel == 0u) goto done;
            break; (void)((m0 * (0x80000000u + 0x6fb319ceu)));
            { unsigned t4; double z4; if ((((unsigned)!(unsigned)((int)u1 < (int)0x4d172fc6u) & 0x10000u)) & 1u) { t4 = (unsigned)((int)0x80000000u >= (int)(unsigned)((short)0x80000000u > (signed char)i1)); z4 = (double)((*q0) & 255u); } if ((((unsigned)!(unsigned)((int)u1 < (int)0x4d172fc6u) & 0x10000u)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                u1 = u1 * 0x9e3779b1u + (garr[i1 & 7u] ^ -((unsigned)f0 ? (1u - (unsigned)s0) : i2));
                while (i2++ < 3u && (unsigned)(unsigned char)(unsigned)(u1 == (unsigned)h0)) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + g0);
                    u1 ^= (p2 % (((unsigned)((int)(unsigned)h0 < (int)(unsigned)x0) ^ v0) | 1u));
                    if (((unsigned)(w0 >> 29) + (unsigned)((int)i1 >= (int)8u))) continue;
                    s1 = (int)((unsigned)s1 + ((0x99be260u + i2) / (v0 | 1u)));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(signed char)(unsigned)((v0 & v0) < (unsigned)x0), u1, (4u ^ -(unsigned)(0u < (unsigned)f0))); }
                }
                if ((unsigned)c1) goto done;
                *q0 += (u3 / ((unsigned)(w0 >> 29) | 1u));
            }
            if (garr[u2 & 7u]) break;
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)(0x838bd5ceu < (unsigned)d0) << ((unsigned)(0u || ((unsigned)s1 + (unsigned)(9u < (unsigned)b0))) & 63u);
                *mp = ((unsigned)((int)(unsigned)!((unsigned)f0 << (g1 & 31u)) >= (int)garr[u2 & 7u]) | (9u % ((unsigned)b0 | 1u)));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)(w0 >> 29) < (int)0xbd2e7b7bu), v0, (unsigned)(short)(unsigned)((unsigned)s0 && fuel)); }
            } while (i2++ < 3u && (unsigned)(0xea82f5e9u < 0xed9c7ccdu));
            i0 = 0xc5430e3cu & 15u;
        } while (i1++ < 2u && (unsigned)h0);
        if ((unsigned)(u2 == -(1u * *mp))) break;
        if (budget != 0u) { budget -= 1u; u3 = fn0(6u, ((unsigned)f0 * (unsigned)c1), 0xabdfa5abu); }
    }
    if ((unsigned)(short)(g0 * i2)) goto L4;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0((fuel << (0x7fffffffu & 31u)), (unsigned)(signed char)(v0 & (0x80000000u + (unsigned)f0)), ((unsigned)(u2 < 0x80000000u) & 8u)); }
    } while (i0++ < 2u && (unsigned)((int)p2 < (int)garr[u2 & 7u]));
    u3 = (unsigned)((int)r0.x >= (int)(u0 >> ((unsigned)h1 & 31u)));
    while (i0++ < 2u && ((unsigned)((int)u2 >= (int)3u) % (0x13bd61c1u | 1u))) { if (--fuel == 0u) goto done;
        if ((u1 >> ((unsigned)((unsigned)e0 == i1) & 31u))) break;
        if (((garr[u2 & 7u] + 6u) & r0.x)) break;
    }
    { unsigned t5; double z5; if ((0xe4536018u) & 1u) { t5 = (unsigned)(short)(3u / ((unsigned)(0x7f018707u && p2) | 1u)); z5 = (double)((u2) & 255u); } if ((0xe4536018u) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
        i0 = (unsigned)h1 & 15u;
        c1 = (signed char)((unsigned)(unsigned char)(unsigned)(u0 == (unsigned)s0) / (6u | 1u));
        if (v0) goto done;
    }
    if (0xffffffffu) goto L2;
    a0[g0 & 3u] = (((unsigned)c0 ^ (unsigned)((r0.y ^ (unsigned)s1) == m0)) & p2);
    if ((m0 - (unsigned)h0)) {
        while (i0++ < 2u && (unsigned)(0xffffffffu && ((unsigned)(x0 >> 70) % ((unsigned)h1 | 1u)))) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)(0xffffffffu < (unsigned)((unsigned)((unsigned)x0 == u1) < a0[i0 & 3u])));
            garr[(unsigned)(short)(unsigned)(3u == i0) & 7u] = ((unsigned)(signed char)(m0 & (unsigned)f0) - u0);
            if ((unsigned)(v0 && (3u >> (g0 & 31u)))) break;
            v0 = -(unsigned)((unsigned)h0 && (unsigned)((short)0x2263b274u > (signed char)(unsigned)l0));
            e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)((unsigned)(unsigned char)(garr[u2 & 7u] * (unsigned)c0) << ((unsigned)((unsigned)(9u < 7u) || 0x14325cceu) & 31u)) & 1023u);
            u2 += (0x1beaecb2u >> ((unsigned)s1 & 31u));
        }
        goto L3;
        do { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)!(u2 | (0xffffffffu | 0u))) continue;
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return ((unsigned)((int)r0.y < (int)5u) * *q0);
                    if (budget != 0u) { budget -= 1u; u1 = fn0(r0.y, (unsigned)((short)(0x10000u / (r0.y | 1u)) > (signed char)0xb7825225u), (unsigned)(short)(u3 + (unsigned)(*mp == (unsigned)(x0 >> 70)))); }
                    if (((unsigned)d0 + g0)) goto done;
                    if (((unsigned)h1 ^ -(0xffffffffu << (1u & 31u)))) break;
                    if ((u1 >> ((unsigned)((int)g1 >= (int)g0) & 31u))) break;
                }
                s1 = (int)((unsigned)s1 + (unsigned)((m0 | (unsigned)(a0[u1 & 3u] < u2)) == ((unsigned)h1 + (unsigned)d0)));
            }
        } while (i0++ < 5u && 0x80000000u);
        s0 = (int)(g0 >> (r0.y & 31u));
        g0 = garr[i1 & 7u];
        garr[i2 & 7u] = -(~(unsigned)(0x10000u < 0x431a0a83u) | (unsigned)c0);
    } else {
        if (fuel) {
            h0 = (short)0x2d29f17cu;
            q0 = &garr[a0[u1 & 3u] & 7u];
            do { if (--fuel == 0u) goto done;
                if ((unsigned)x0) break;
                *q0 += 0x71c564b1u;
                *q0 = (i2 ? 0u : (0x10000u % (6u | 1u)));
                goto done;
                x0 = x0 * 0x100000001b3ull + ((i2 | garr[i1 & 7u]) + 6u);
            } while (i0++ < 7u && 0x10000u);
        } else {
            if (((unsigned)l0 << ((r0.y % (0xd628b3bdu | 1u)) & 31u))) goto L0;
            s0 = (int)0x3281e05fu;
            g1 += r0.x;
        }
        garr[u0 & 7u] = ((0x7c9bb9d3u >> ((unsigned)h0 & 31u)) + ((unsigned)x0 | (unsigned)h0));
        switch ((unsigned)f0 & 7u) {
            g1 += (unsigned)(signed char)((unsigned)((int)0x10000u >= (int)a0[u1 & 3u]) >> (0x80000000u & 31u));
        }
        goto L3;
    }
    r0.y ^= -(unsigned)(~(unsigned)((short)p2 > (signed char)(unsigned)((int)8u >= (int)u3)) && (i1 * 9u));
    if (g1) goto L2;
    do { if (--fuel == 0u) goto done;
        b0 = 0xffffffffu != 0u;
        if ((unsigned)!((6u & 0xdbde5bf0u) - 0x7fffffffu)) break;
        break; (void)((unsigned)(x0 >> 70));
        h0 = (short)(((unsigned)(signed char)((unsigned)h1 + (u2 << ((unsigned)s1 & 31u))) % (0xeecbee24u | 1u)) >> (u0 & 31u));
        *mp = (unsigned)s0;
        *q0 += ((g1 * 0x10000u) & u3);
    } while (i0++ < 3u && (unsigned)l0);
    if ((0x10000u & p1)) goto L2;
    *q0 += *q0;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((9u | 0x6cbca293u) / (0xb5203ffu | 1u))) goto L2;
        if ((unsigned)(unsigned char)(-(unsigned)((unsigned)b0 && 0x68871f53u) >> ((unsigned)x0 & 31u))) goto L3;
        l0 = (long)((unsigned long)l0 + (unsigned)(u3 && 0x75eb9c36u));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(0x332f1483u == 0xd647c44fu)) {
        while (i0++ < 7u && ((unsigned)l0 << (u3 & 31u))) { if (--fuel == 0u) goto done;
            while (i1++ < 2u && (0x7fffffffu - (a0[i0 & 3u] & (unsigned)h1))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)h1 << (((unsigned)h0 / (0xb58d6d8bu | 1u)) & 31u)), (unsigned)((int)m0 < (int)(unsigned)(w0 >> 29)), 0x10000u); }
                L0: if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)garr[i1 & 7u] << ((unsigned)((int)garr[i1 & 7u] < (int)0x80000000u) & 63u);
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)l0 - (unsigned)h0), ((unsigned)((int)g1 >= (int)i2) - r0.x), i2); }
                if ((unsigned)!(unsigned)((r0.x % ((unsigned)b0 | 1u)) == (unsigned)f0)) goto L2;
            }
            e0 = e0 * 0.5L + (long double)((0x7fffffffu % (r0.x | 1u)) & 1023u);
        }
    } else {
        d0 = d0 * 0.5 + (double)(0x7fffffffu & 1023u);
        if (0xffffffffu) goto L4;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)(6u || r0.y) >> (i0 & 31u)), -(unsigned)((short)(unsigned)((int)p2 < (int)0x10000u) > (signed char)p2), (unsigned)((short)(unsigned)(v0 && 0x80000000u) > (signed char)0x7fffffffu)); }
    w0 = w0 * 6364136223846793005ull + (unsigned)h1;
    while (i0++ < 3u && i2) { if (--fuel == 0u) goto done;
        u3 ^= ((a0[u1 & 3u] - (unsigned)d0) & (0xffffffffu & 0xd6a0ec47u));
        switch ((unsigned)c0 & 7u) {
            L1: if (--fuel == 0u) goto done;
            a0[(unsigned)(short)(m0 << (0x10000u & 31u)) & 3u] = 9u;
            if (fuel) {
                garr[garr[i1 & 7u] & 7u] = (unsigned)((int)(unsigned)(signed char)((unsigned)s0 ^ a0[u1 & 3u]) >= (int)((unsigned)c1 << (*mp & 31u)));
                if (((unsigned)s0 % (garr[u2 & 7u] | 1u))) continue;
                case 6u: ;
            }
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((v0 - 4u)) break;
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    while (~((unsigned)h0 | (unsigned)((int)(unsigned)s1 >= (int)garr[u2 & 7u]))) { if (--fuel == 0u) goto done;
                        L2: if (--fuel == 0u) goto done;
                        u1 = u1 * 0x9e3779b1u + (unsigned)(((unsigned)x0 ^ 0xffffffffu) == ((0x1434bb86u - p1) >> ((unsigned)h1 & 31u)));
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)h0 == (unsigned)((short)(unsigned)w0 > (signed char)3u)), (unsigned)((int)(u3 % (5u | 1u)) < (int)p0), (8u / (0xcbe323cfu | 1u))); }
                    }
                    { unsigned t0; double z0; if (((v0 / (u0 | 1u))) & 1u) { t0 = (unsigned)w0; z0 = (double)((0u) & 255u); } if (((v0 / (u0 | 1u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                        continue; (void)((unsigned)((unsigned)c0 < (unsigned)c1));
                        if (budget != 0u) { budget -= 1u; u3 = fn1(0xffffffffu, (unsigned)(i0 && (6u ^ a0[i0 & 3u])), a0[i0 & 3u]); }
                    }
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn1(((g1 >> (garr[u2 & 7u] & 31u)) & a0[u1 & 3u]), ((unsigned)((unsigned)s0 && 9u) / (p2 | 1u)), (unsigned)d0); }
                        case 4u: ;
                        L3: if (--fuel == 0u) goto done;
                    }
                }
                case 7u: ;
                b0 = ((unsigned)w0 * 5u) != 0u;
                break; (void)(0x80000000u);
                c1 = (signed char)((unsigned)c1 / ((unsigned)((short)0x10000u > (signed char)v0) | 1u));
            }
        }
        L4: if (--fuel == 0u) goto done;
        garr[(unsigned)(r0.x && 0x87453da8u) & 7u] = (5u / (r0.y | 1u));
        if ((0x7fffffffu / ((unsigned)((int)g0 >= (int)(unsigned)w0) | 1u))) break;
    }
    { unsigned t1; double z1; if (((v0 * (v0 * 0x8ea1433cu))) & 1u) { t1 = (unsigned)f0; z1 = (double)(((unsigned)((unsigned)c1 < (p2 + g0))) & 255u); } if (((v0 * (v0 * 0x8ea1433cu))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        if (budget != 0u) { budget -= 1u; u0 = fn1((m0 << (garr[u2 & 7u] & 31u)), (u2 + (unsigned)((int)4u < (int)i2)), (unsigned)(garr[u2 & 7u] == 0xccb3d142u)); }
        *q0 += (unsigned)(*q0 || (unsigned)((short)1u > (signed char)(unsigned)h1));
        *q0 += ((unsigned)f0 << ((unsigned)((short)u3 > (signed char)garr[i1 & 7u]) & 31u));
    }
    c1 = (signed char)(unsigned)(3u == (unsigned)x0);
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x7fffffffu < (unsigned)s1), (0x10000u + 5u), p2); }
    l0 = (long)((unsigned long)l0 + (((unsigned)d0 % ((unsigned)(0x10000u && (unsigned)(0x285c1c51u == u2)) | 1u)) ^ p1));
    if ((0xe4d25dfeu | (unsigned)(w0 >> 29))) goto L1;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        b0 = 4u != 0u;
        r0.y ^= (6u + (0xb36a81b4u % (8u | 1u)));
        g1 += -(unsigned)((garr[i1 & 7u] << (p1 & 31u)) < ((unsigned)h0 - a0[u1 & 3u]));
    }
    switch (((unsigned)(0x80000000u && 0x10000u) * 0x7fffffffu) & 7u) {
        case 6u: ;
        if (budget != 0u) { budget -= 1u; u2 = fn0(-(unsigned)(0x1bbc4097u < (unsigned)(0xd491bd32u == 1u)), a0[i0 & 3u], a0[u1 & 3u]); }
        f0 = f0 * 0.5f + (float)((6u ? 0xc37f4a37u : 0xb050701eu) & 255u);
        goto L0;
        case 5u: ;
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        i2 = (unsigned)(8u < 0x80000000u) & 15u;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)l0) break;
            do { if (--fuel == 0u) goto done;
                if ((u1 & ~(0x7d43a6c2u - i1))) {
                    g0 = (unsigned)((short)(unsigned)b0 > (signed char)(0x10000u ^ 0x7fffffffu));
                    break; (void)((unsigned)!(g0 - (unsigned)!(unsigned)(0x80000000u < 5u)));
                    u3 ^= (unsigned)((unsigned)(2u && (unsigned)h0) < (unsigned)(x0 >> 70));
                }
                g0 = ((unsigned)(unsigned char)((unsigned)e0 >> ((unsigned)x0 & 31u)) + ~(unsigned)(r0.y == 0x80000000u));
                if (budget != 0u) { budget -= 1u; u0 = fn1(9u, (unsigned)b0, (p0 >> ((r0.y * 0xcd8b96eau) & 31u))); }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)0x1ae6c972u < (int)i1), (unsigned)(unsigned char)(unsigned)(9u || (unsigned)(0x80000000u == i1)), (unsigned)(4u == (unsigned)s0)); }
            } while (i2++ < 6u && 0x80000000u);
            *q0 += (unsigned)((unsigned)((int)(0x10000u >> ((unsigned)s0 & 31u)) >= (int)0x10000u) < (unsigned)c0);
            a0[(unsigned)((int)(unsigned)s0 >= (int)i0) & 3u] = ((u0 << (0xe0b3886u & 31u)) >> (0xc84ac73u & 31u));
        }
        switch ((unsigned)b0 & 7u) {
            x0 = x0 * 0x100000001b3ull + (unsigned)((p2 * (unsigned)(x0 >> 70)) < 0xebfa80d2u);
            h1 = (unsigned short)(h1 + (unsigned)((short)((unsigned)(p2 && 8u) + 0xa3e11a5bu) > (signed char)(unsigned)s0));
            case 5u: ;
        }
        *q0 = (-(unsigned)(0x7cce0bb9u || 0x10000u) % ((unsigned)s1 | 1u));
        if ((unsigned)((unsigned)e0 || p1)) break;
    }
    u3 ^= ~(((unsigned)(p2 || u1) - m0) << ((unsigned)((short)0xbecbd20bu > (signed char)(unsigned)l0) & 31u));
    if ((unsigned)((i0 % (g0 | 1u)) < (unsigned)h0)) {
        if ((((unsigned)c1 & 8u) | (unsigned)b0)) goto L1;
        switch (((unsigned)f0 << (i0 & 31u)) & 7u) {
            *mp = 0x10000u;
            break; (void)((unsigned)(garr[u2 & 7u] == ~((unsigned)(w0 >> 29) % (i2 | 1u))));
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (-(unsigned)((0x7fffffffu | 7u) || r0.y)) break;
            if (-(0xe8d89614u / (0x2355d7b2u | 1u))) break;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(unsigned char)(unsigned)(m0 < (unsigned)(x0 >> 70)), p0, g1); }
            if (budget != 0u) { budget -= 1u; u1 = fn1((0x80000000u & (*q0 ^ 0x7fffffffu)), (unsigned)((int)(i0 >> (p0 & 31u)) >= (int)u2), r0.y); }
            h0 = (short)(unsigned)(signed char)(((unsigned)(p0 < garr[u2 & 7u]) >> (0xffffffffu & 31u)) << ((unsigned)(0x80000000u < m0) & 31u));
        }
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(signed char)((unsigned)(x0 >> 70) | (unsigned)(0x94e5b4a7u == garr[u2 & 7u])));
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            continue; (void)((p0 - (unsigned)(u0 || u0)));
            r0.y ^= (unsigned)d0;
        }
        continue; (void)(0xffffffffu);
        i1 = (unsigned)((unsigned)w0 && garr[i1 & 7u]) & 15u;
        if ((i0 + p2)) break;
        if ((unsigned)(unsigned char)(i1 << (0x8d27b572u & 31u))) goto L3;
    }
    if ((unsigned)((unsigned)(*q0 == *mp) < a0[u1 & 3u])) {
        *q0 += (m0 | v0);
        u2 += (unsigned)(w0 >> 29);
        s0 = (int)(-(v0 + (unsigned)(w0 >> 29)) ^ (a0[i0 & 3u] >> (u2 & 31u)));
        if (0x80000000u) {
            for (;;) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)(5u < -((unsigned)h0 ? (unsigned)h0 : (unsigned)(0u == i0))));
                if ((-(5u - 0x10000u) % ((unsigned)x0 | 1u))) break;
                if ((unsigned)(~(9u << ((unsigned)f0 & 31u)) == (unsigned)c0)) {
                    f0 = f0 * 0.5f + (float)(u1 & 255u);
                    m0 ^= (unsigned)((int)(unsigned)((int)(unsigned)h1 < (int)(unsigned)f0) >= (int)-(u2 + (9u + (unsigned)s0)));
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)(((~((unsigned)x0 & 0xca2711au) << ((0x80000000u ^ (unsigned)s1) & 31u)) + i1) & 255u);
                        d0 = d0 * 0.5 + (double)(((unsigned)w0 >> ((unsigned)((0x80000000u + i1) == (r0.x >> ((unsigned)s1 & 31u))) & 31u)) & 1023u);
                        *q0 = (unsigned)((fuel + g0) && (unsigned)d0);
                        a0[(unsigned)(unsigned char)(unsigned)((unsigned)(w0 >> 29) || (unsigned)(x0 >> 70)) & 3u] = m0;
                        if (u3 == 7u) return (unsigned)h1;
                        do { if (--fuel == 0u) goto done;
                            m0 ^= (7u - (unsigned)h0);
                            w0 ^= (unsigned long long)p1 << (((a0[u1 & 3u] * (u1 + (unsigned)f0)) * (*q0 - (unsigned)h0)) & 63u);
                            if (budget != 0u) { budget -= 1u; u1 = fn0(g0, (7u + (u3 << (u3 & 31u))), (a0[i0 & 3u] - u0)); }
                            if ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)p0)) break;
                        } while (i2++ < 6u && (unsigned)((unsigned)(fuel && 0x10000u) || (unsigned)s1));
                    }
                } else {
                    if (((unsigned)(r0.x < 5u) / (0x65d9851bu | 1u))) goto L4;
                }
                d0 = d0 * 0.5 + (double)((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)((unsigned)l0 == 0x10000u)) & 1023u);
            }
            d0 = d0 * 0.5 + (double)(*q0 & 1023u);
            x0 = x0 * 0x100000001b3ull + u3;
            g1 += (0x91c803beu - (unsigned)((short)((unsigned)((int)a0[u1 & 3u] < (int)*q0) & garr[u2 & 7u]) > (signed char)0xbd568535u));
            g1 += v0;
        }
    }
    if (0x814e5775u) goto done;
    i0 = 6u & 15u;
    *mp = (unsigned)((int)((unsigned)l0 + fuel) < (int)((unsigned)((short)0xc9dc0115u > (signed char)garr[i1 & 7u]) & 0xc8f4f8f3u));
    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)f0 * garr[u2 & 7u]), (unsigned)(signed char)(u1 - u1), (unsigned)(v0 && fuel)); }
    u2 = (r0.y * p2);
    i1 = (unsigned)!((6u / (((0xc7982336u & p2) * u2) | 1u)) << (0x80000000u & 31u)) & 15u;
    if (((p1 / (0x3800c539u | 1u)) ^ (unsigned)c0)) {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (r0.x) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if (0x4295fc73u) break;
                    s0 = (int)(0u * g1);
                    if ((unsigned)(0x1902d5d5u || 4u)) {
                        u3 = (0xdc53158eu & (garr[u2 & 7u] % ((0xffffffffu << ((unsigned)c1 & 31u)) | 1u)));
                        if (-(unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)(w0 >> 29))) continue;
                    }
                    break; (void)(v0);
                    h1 = (unsigned short)(h1 + (unsigned)(i2 < (unsigned)((int)(unsigned)s1 >= (int)(unsigned)s0)));
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(a0[u1 & 3u] && (((unsigned)l0 << (v0 & 31u)) * m0)) || garr[i1 & 7u]));
                } while (i2++ < 5u && 0xbb9d376fu);
                if (fuel) {
                    q0 = &garr[((u3 / (m0 | 1u)) >> ((unsigned)h0 & 31u)) & 7u];
                    if (budget != 0u) { budget -= 1u; u1 = fn0(p0, (a0[i0 & 3u] >> ((unsigned)c0 & 31u)), (unsigned)x0); }
                    if (((unsigned)(short)((unsigned)(w0 >> 29) - (unsigned)l0) ^ 0xdb55dec0u)) {
                        e0 = e0 * 0.5L + (long double)(4u & 1023u);
                        *q0 = ((unsigned)h1 ? 1u : (unsigned)((int)5u >= (int)0x9d241b2u));
                    }
                    break; (void)(r0.x);
                    garr[i1 & 7u] = (unsigned)c0;
                }
                d0 = d0 * 0.5 + (double)(a0[i0 & 3u] & 1023u);
            }
        }
        if ((unsigned)(short)(p2 ^ (unsigned)((short)i0 > (signed char)u2))) {
            goto L2;
            u0 = (unsigned)(g0 && (unsigned)(unsigned char)(p2 >> ((unsigned)s0 & 31u)));
            for (;;) { if (--fuel == 0u) goto done;
                h0 = (short)(unsigned)(short)(9u % (3u | 1u));
            }
        }
        h0 = (short)(unsigned)((int)(unsigned)(signed char)((unsigned)((int)(unsigned)l0 < (int)0x9cdb064du) ^ r0.y) < (int)(unsigned)l0);
        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)s0 | (unsigned)(w0 >> 29)), 4u, i0); }
    }
    do { if (--fuel == 0u) goto done;
        g1 += ((unsigned)((int)-(unsigned)((int)0x72710412u < (int)(unsigned)(x0 >> 70)) >= (int)(unsigned)((unsigned)f0 || (unsigned)c1)) >> (p0 & 31u));
        l0 = (long)((unsigned long)l0 + u3);
    } while (i0++ < 2u && (g0 * (unsigned)(x0 >> 70)));
    { unsigned t2; double z2; if (((unsigned)((unsigned)e0 == (unsigned)((short)0x90aac70u > (signed char)a0[i0 & 3u]))) & 1u) { t2 = (unsigned)((unsigned)c0 == garr[i1 & 7u]); z2 = (double)((garr[u2 & 7u]) & 255u); } if (((unsigned)((unsigned)e0 == (unsigned)((short)0x90aac70u > (signed char)a0[i0 & 3u]))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        i0 = (((unsigned)(short)((unsigned)e0 % ((unsigned)h0 | 1u)) - (unsigned)e0) << ((p2 / ((unsigned)(x0 >> 70) | 1u)) & 31u)) & 15u;
        switch ((unsigned)(short)(0x20f58b2bu ? 9u : 6u) & 7u) {
            if ((unsigned)h0) goto L1;
            if (0xa3d99d67u) goto L4;
            if (u3 == 7u) return (p0 << (p0 & 31u));
        }
    }
    goto done;
    goto L0;
    do { if (--fuel == 0u) goto done;
        i0 = (g0 / (((u1 % (*mp | 1u)) % (g1 | 1u)) | 1u)) & 15u;
        if ((unsigned)((int)0x10000u < (int)0x7fffffffu)) goto L2;
        if ((g0 / ((unsigned)c0 | 1u))) goto L1;
        if (((g0 % (*q0 | 1u)) - u0)) break;
        while (i1++ < 2u && (unsigned)(short)(unsigned)((unsigned)((int)*mp < (int)0x80000000u) && u3)) { if (--fuel == 0u) goto done;
            if (0x7fffffffu) goto done;
            if (u3 == 7u) return (*mp ? ((unsigned)f0 / (i0 | 1u)) : 0x62dfa062u);
            break; (void)((0x10000u ^ i1));
            if ((unsigned)s1) {
                u2 += (unsigned)((int)(unsigned)d0 >= (int)*q0);
                if (0xffffffffu) break;
                b0 = ((unsigned)e0 - u2) != 0u;
                garr[(unsigned)(i2 && u3) & 7u] = (0xf0212cd2u & 5u);
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (((unsigned)((unsigned)c1 == a0[i0 & 3u]) ^ (unsigned)((int)garr[u2 & 7u] < (int)0u)) ^ 0x7fffffffu);
                    if (0u) goto L2;
                    s1 = (int)((unsigned)s1 + ((u1 >> (r0.x & 31u)) % ((unsigned)(x0 >> 70) | 1u)));
                    c0 = (unsigned char)((unsigned)s0 ^ -(unsigned)((unsigned)b0 || ((unsigned)h0 >> (i1 & 31u))));
                    *q0 += r0.y;
                }
            }
            x0 = x0 * 0x100000001b3ull + g1;
            c1 = (signed char)((a0[u1 & 3u] & (unsigned)s1) * u0);
        }
    } while (i0++ < 2u && (unsigned)(8u || 0x10000u));
    v0 = (garr[u2 & 7u] >> (a0[i0 & 3u] & 31u));
    if ((unsigned)(unsigned char)(garr[i1 & 7u] << ((unsigned)x0 & 31u))) goto L0;
    r0.y ^= r0.y;
    switch (~(unsigned)(fuel < (0x74cc5779u ^ garr[i1 & 7u])) & 7u) {
        m0 ^= ~((unsigned)s0 >> ((p2 | ((unsigned)c1 ? u2 : (unsigned)c1)) & 31u));
        u3 += i1;
    }
    h1 = (unsigned short)(h1 + ((unsigned)s0 & (unsigned)s0));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((~(unsigned)(7u < (unsigned)c1) / (-(unsigned)((int)v0 < (int)0x55b4f0a3u) | 1u)) & 1023u);
        s0 = (int)(unsigned)c0;
        u0 += (unsigned)s1;
        a0[0x5a15c3cau & 3u] = (unsigned)((short)((unsigned)(x0 >> 70) << ((a0[u1 & 3u] + 0x7fffffffu) & 31u)) > (signed char)p1);
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t3; double z3; if (((unsigned)(w0 >> 29)) & 1u) { t3 = (unsigned)(m0 < (unsigned)s0); z3 = (double)(((unsigned)((int)i0 < (int)i1)) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            x0 = x0 * 0x100000001b3ull + ((unsigned)(0x81127037u < 0x80000000u) ? p1 : r0.x);
            { unsigned t4; double z4; if (((unsigned)f0) & 1u) { t4 = 0x64b3ea51u; z4 = (double)(((v0 % (g1 | 1u))) & 255u); } if (((unsigned)f0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                h1 = (unsigned short)(h1 + (unsigned)(6u && (r0.x ? *mp : u0)));
                b0 = (unsigned)((unsigned)(x0 >> 70) && (unsigned)(w0 >> 29)) != 0u;
            }
            switch ((unsigned)(a0[u1 & 3u] == i0) & 7u) {
                if (0x96422aa7u) {
                    case 7u: ;
                    u3 = (unsigned)((unsigned)b0 && 2u);
                    s0 = (int)(unsigned)!((0x80000000u & garr[u2 & 7u]) ^ (unsigned)x0);
                    x0 = x0 * 0x100000001b3ull + (unsigned)(m0 && (unsigned)(x0 >> 70));
                    a0[0xffffffffu & 3u] = (u1 ? (u3 ^ (unsigned)(x0 >> 70)) : (unsigned)h0);
                }
                f0 = f0 * 0.5f + (float)(((unsigned)((int)g1 < (int)(unsigned)c1) - (unsigned)((unsigned)b0 || ((unsigned)s0 & p0))) & 255u);
                if ((0x80000000u >> ((unsigned)(g0 == m0) & 31u))) continue;
                u0 += (unsigned)((short)(unsigned)(0x10000u || 0xffffffffu) > (signed char)(unsigned)s0);
                *mp = (unsigned)((short)((unsigned)(x0 >> 70) & (unsigned)(0x10000u < (unsigned)h0)) > (signed char)(unsigned)(i1 < (unsigned)(w0 >> 29)));
            }
            i2 = (unsigned)((short)u2 > (signed char)(unsigned)(x0 >> 70)) & 15u;
            u0 += (0x5eacc2du * 0xab41e913u);
            w0 ^= (unsigned long long)(unsigned)(signed char)(unsigned)(p1 == (unsigned)h0) << ((unsigned)c1 & 63u);
        }
        if ((unsigned)(r0.y == i2)) break;
        if (u1) break;
    }
    goto done;
    if ((unsigned)((int)0u < (int)4u)) {
        if ((unsigned)((int)3u < (int)garr[i1 & 7u])) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)b0, ((unsigned)h0 * p2), ((u1 << ((unsigned)b0 & 31u)) << (0x7fffffffu & 31u))); }
        if ((unsigned)(((unsigned)d0 * *mp) < 0xe8aef7bdu)) goto L2;
        if ((unsigned)((int)9u < (int)0x59ddf502u)) goto done;
        while ((unsigned)((int)0x9faf4333u < (int)(unsigned)(short)(0xffffffffu | (unsigned)l0))) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(((unsigned)c0 >> ((unsigned)c0 & 31u)) | (unsigned)c0));
            while (i1++ < 3u && m0) { if (--fuel == 0u) goto done;
                c1 = (signed char)r0.y;
                r0.x = (unsigned)((*mp - ((0xf35a91aeu - 0xfa66a843u) | m0)) || 0xaf612fd1u);
            }
            m0 ^= (unsigned)((unsigned)(x0 >> 70) || (unsigned)(garr[u2 & 7u] || ((unsigned)f0 * (unsigned)h0)));
            u3 += (unsigned)(signed char)(unsigned)(i0 < (unsigned)(x0 >> 70));
            r0.y ^= (unsigned)((short)(unsigned)(unsigned char)((garr[u2 & 7u] ^ i2) >> (0xe38cbaebu & 31u)) > (signed char)r0.y);
        }
    }
    if ((0u + ((unsigned)w0 << (i0 & 31u)))) goto L4;
    f0 = f0 * 0.5f + (float)((unsigned)(short)(fuel * (unsigned)(w0 >> 29)) & 255u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    r0.y ^= (unsigned)((unsigned)(unsigned char)(unsigned)(((unsigned)s1 / (fuel | 1u)) < u2) || 0x10000u);
    l0 = (long)((unsigned long)l0 + (unsigned)(short)(unsigned)((int)(unsigned)!((unsigned)(x0 >> 70) / (garr[i1 & 7u] | 1u)) < (int)0x10000u));
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)e0, (unsigned)f0, ((i1 | i2) * i2)); }
    if ((unsigned)((unsigned)((int)0xffffffffu >= (int)(unsigned)d0) < u0)) {
        h1 = (unsigned short)(h1 + (v0 + ((unsigned)d0 - 0x1c4c28fcu)));
        L0: if (--fuel == 0u) goto done;
        goto L0;
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)b0, (*mp | (unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)x0)), (p1 - p0)); }
        while (i0++ < 6u && (((unsigned)(x0 >> 70) & (unsigned)c1) << ((unsigned)x0 & 31u))) { if (--fuel == 0u) goto done;
            g0 = (unsigned)((short)0xdb770403u > (signed char)u3);
            if ((m0 ^ (a0[u1 & 3u] + 0x7fffffffu))) goto L0;
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(unsigned char)((unsigned)c0 / (8u | 1u)), (9u / (u1 | 1u)), ((unsigned)(unsigned char)(a0[u1 & 3u] - 0x197be723u) / (p1 | 1u))); }
            goto L1;
        }
        if (garr[u2 & 7u]) goto L0;
    } else {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((u1 ^ (unsigned)(x0 >> 70))) goto done;
            a0[(unsigned)!(g1 % (p0 | 1u)) & 3u] = (0x9a0384beu / (0x319b67e0u | 1u));
            while (i1++ < 4u && (unsigned)(0x10000u == (unsigned)((int)(unsigned)d0 >= (int)0x6644fdf8u))) { if (--fuel == 0u) goto done;
                if ((unsigned)s0) continue;
                f0 = f0 * 0.5f + (float)((0x80000000u % (6u | 1u)) & 255u);
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1(0xf3734432u, (unsigned)((unsigned)!(a0[i0 & 3u] >> ((unsigned)h0 & 31u)) && r0.y), ((unsigned)!(unsigned)((short)m0 > (signed char)garr[u2 & 7u]) << (p2 & 31u))); }
        }
        i0 = (unsigned)((int)(unsigned)x0 < (int)a0[u1 & 3u]) & 15u;
        h0 = (short)0x10000u;
        switch (u2 & 7u) {
            do { if (--fuel == 0u) goto done;
                if (u0) continue;
                u1 ^= ((unsigned)d0 + (u3 | i2));
                while (i1++ < 6u && (unsigned)s0) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)(short)((9u & (unsigned)(a0[i0 & 3u] < (unsigned)s1)) ^ u1) & 1023u);
                    if (i1) break;
                }
                switch (v0 & 7u) {
                    L1: if (--fuel == 0u) goto done;
                    if ((unsigned)(g0 || (unsigned)h0)) break;
                    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)h0 == (((unsigned)c0 * i1) - 0x4b11a59u)));
                    case 2u: ;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)(unsigned)x0 >= (int)(a0[i0 & 3u] << (r0.y & 31u))), (0u << ((unsigned)(p0 == 0xe4ac4d95u) & 31u)), 1u); }
            } while (i0++ < 6u && (unsigned)((g1 % (0xc44a4fcu | 1u)) < 0x9ad2d54du));
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)(m0 | 0xe6dfa9b0u), (unsigned)((unsigned)(4u || 5u) < u3), (0xd4443467u ? 6u : 0xe6b0b6afu)); }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)(i1 ^ m0) > (signed char)r0.x), ((garr[i1 & 7u] - (unsigned)h0) >> (u3 & 31u)), (unsigned)(1u == 0x80000000u)); }
            } while (i0++ < 6u && (3u % ((5u << (garr[i1 & 7u] & 31u)) | 1u)));
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)d0 >> (garr[i1 & 7u] & 31u)), -(0xac5e7fcdu | (garr[u2 & 7u] | 2u)), ((unsigned)(w0 >> 29) ^ (v0 % (i1 | 1u)))); }
            s0 = (int)(unsigned)((int)p1 < (int)(*mp / ((unsigned)h0 | 1u)));
            r0.x = (unsigned)e0;
            f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(unsigned)((int)v0 < (int)(unsigned)e0) & 255u);
        }
    }
    if ((unsigned)((int)u0 < (int)r0.y)) {
        m0 ^= (unsigned)d0;
        if (((unsigned)c0 >> ((unsigned)s0 & 31u))) goto L0;
    } else {
        m0 ^= p1;
    }
    { unsigned t0; double z0; if (((unsigned)(short)(0xffffffffu & m0)) & 1u) { t0 = ((a0[i0 & 3u] >> ((unsigned)c0 & 31u)) << (0x80000000u & 31u)); z0 = (double)(((0x9ee17f24u | 3u)) & 255u); } if (((unsigned)(short)(0xffffffffu & m0)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        if ((i0 - (unsigned)w0)) {
            L2: if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((0x1452ef7eu * (unsigned)(r0.x && i1)) & 255u);
            r0.x = (unsigned)(~(unsigned)((int)v0 < (int)p2) < 0xb670db27u);
            h0 = (short)((a0[u1 & 3u] ? 0xe7378f6fu : (fuel - fuel)) | i2);
            if ((unsigned)(signed char)(0x23a51a87u << ((unsigned)(unsigned char)(p2 % ((unsigned)x0 | 1u)) & 31u))) {
                r0.y ^= ~(0xf092bbbu >> ((unsigned)(p1 && p1) & 31u));
                w0 = w0 * 6364136223846793005ull + ~(unsigned)((unsigned)(0u < (unsigned)x0) || -(u1 / (0xffffffffu | 1u)));
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)l0), (unsigned)(unsigned char)(i1 ? 8u : 0x10000u), garr[u2 & 7u]); }
            }
            if (((u2 >> (0x9ded7718u & 31u)) % (9u | 1u))) goto L1;
        }
        g1 += (g0 << ((unsigned)(*q0 || (unsigned)(*mp == 9u)) & 31u));
        u3 = u3 * 0x9e3779b1u + ((unsigned)(signed char)(0x827c4d2au >> ((0xa9cba6d4u | u1) & 31u)) * 4u);
        if (fuel < 8u) return ((unsigned)(u2 && (-(unsigned)(i0 && i2) + 2u)) % (p0 | 1u));
        L3: if (--fuel == 0u) goto done;
    }
    u2 ^= (unsigned)((int)(unsigned)d0 >= (int)(unsigned)((int)i2 >= (int)0x68f05932u));
    while (i0++ < 6u && (0x958a71a5u >> (((unsigned)h1 >> (8u & 31u)) & 31u))) { if (--fuel == 0u) goto done;
        b0 = *mp != 0u;
        L4: if (--fuel == 0u) goto done;
        if ((unsigned)(unsigned char)(unsigned)(u3 && (unsigned)(w0 >> 29))) {
            i0 = (unsigned)((short)(unsigned)((i0 % (i0 | 1u)) && 0xffffffffu) > (signed char)fuel) & 15u;
            switch (((unsigned)d0 & u2) & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn1(g1, v0, (unsigned)((unsigned)x0 || (a0[u1 & 3u] ^ (unsigned)h1))); }
                case 1u: ;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)((int)u0 < (int)i1) + 0x7fffffffu), (2u & m0), ((unsigned)f0 / (6u | 1u))); }
            break; (void)(7u);
            break; (void)(1u);
        } else {
            if ((unsigned)(6u || (unsigned)s1)) {
                if (((unsigned)((short)m0 > (signed char)garr[i1 & 7u]) / (0x80000000u | 1u))) continue;
                if (budget != 0u) { budget -= 1u; u2 = fn2(-(g1 << ((unsigned)((short)(unsigned)c1 > (signed char)p2) & 31u)), (u2 % (g1 | 1u)), ((unsigned)(6u == 1u) % (4u | 1u))); }
                break; (void)(((unsigned)d0 & u2));
                w0 ^= (unsigned long long)(fuel | (unsigned)s1) << (((unsigned)s0 ? g0 : (unsigned)x0) & 63u);
            }
        }
        w0 ^= (unsigned long long)(unsigned)((int)u2 < (int)u1) << ((unsigned)s1 & 63u);
    }
    if ((unsigned)w0) goto L2;
    garr[u2 & 7u] = (unsigned)((0x7bc2a462u * (unsigned)w0) || (unsigned)((unsigned)h0 == garr[i1 & 7u]));
    if (-(unsigned)((int)(unsigned)h0 >= (int)((unsigned)e0 << (a0[i0 & 3u] & 31u)))) {
        if ((unsigned)s1) goto L1;
    }
    if (3u) goto done;
    x0 = x0 * 0x100000001b3ull + 0x6450f33du;
    if ((unsigned)((unsigned)h0 < (p2 ^ (unsigned)w0))) goto L3;
    while (7u) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)(signed char)(0xda6810c8u + 6u);
        *mp = ((unsigned)((unsigned)((int)8u < (int)0x7e89766bu) || *mp) % (v0 | 1u));
        if (budget != 0u) { budget -= 1u; u2 = fn2(3u, u2, (unsigned)(short)(unsigned)((unsigned)h0 && *mp)); }
        u1 = u1 * 0x9e3779b1u + (unsigned)(short)((unsigned)d0 ^ (unsigned)e0);
        w0 = w0 * 6364136223846793005ull + (((unsigned)b0 << ((unsigned)s1 & 31u)) ^ (unsigned)((unsigned)(a0[u1 & 3u] && 0x80000000u) || (unsigned)(x0 >> 70)));
        i1 = (unsigned)((9u >> ((unsigned)b0 & 31u)) == (unsigned)s1) & 15u;
    }
    if ((unsigned)((int)(0xffffffffu & (unsigned)l0) >= (int)(unsigned)b0)) goto L2;
    switch ((unsigned)!((unsigned)c0 - (unsigned)(0x5176ccf5u || 0xd54d56au)) & 7u) {
        if ((unsigned)l0) {
            d0 = d0 * 0.5 + (double)(((unsigned)((unsigned)c0 && 2u) % ((unsigned)(x0 >> 70) | 1u)) & 1023u);
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)l0, (unsigned)d0, i2); }
            q0 = &garr[(v0 << (((unsigned)x0 - (unsigned)c0) & 31u)) & 7u];
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(short)(unsigned)((int)9u >= (int)(unsigned)l0)) goto L4;
            if ((g1 * a0[i0 & 3u])) break;
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)((unsigned)(signed char)(((i1 | (unsigned)c1) ^ 0x7fffffffu) ^ 0xcc489bfbu) == (unsigned)c0);
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)h1 < (unsigned)(p0 < m0)), (unsigned)((int)u1 >= (int)(unsigned)((short)(unsigned)e0 > (signed char)p1)), ((unsigned)e0 + ((unsigned)b0 | 9u))); }
        }
    }
    { unsigned t1; double z1; if ((fuel) & 1u) { t1 = (a0[i0 & 3u] << (p2 & 31u)); z1 = (double)((0x3d381809u) & 255u); } if ((fuel) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        a0[(unsigned)(signed char)(unsigned)((short)0x10000u > (signed char)v0) & 3u] = r0.x;
        if (((unsigned)c0 >> ((unsigned)h1 & 31u))) {
            while (i0++ < 4u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                while (i1++ < 7u && ((*q0 & p2) * r0.y)) { if (--fuel == 0u) goto done;
                    if (g1) {
                        b0 = (unsigned)(m0 < -(i2 ^ r0.y)) != 0u;
                        break; (void)((unsigned)(signed char)(unsigned)(garr[u2 & 7u] < (m0 >> (0xffffffffu & 31u))));
                        w0 = w0 * 6364136223846793005ull + (unsigned)((int)(0x98d2ea4fu & 0x893e3b70u) < (int)p1);
                        do { if (--fuel == 0u) goto done;
                            if ((unsigned)((unsigned)d0 == (unsigned)(0x680fb665u || 2u))) continue;
                            r0.y ^= (unsigned)l0;
                            x0 = x0 * 0x100000001b3ull + (unsigned)((short)(0xcd2735e8u >> (4u & 31u)) > (signed char)i1);
                            h1 = (unsigned short)(h1 + ((v0 << (2u & 31u)) + 0x7fffffffu));
                            if (budget != 0u) { budget -= 1u; u3 = fn2(0x10000u, (unsigned)(g0 && (unsigned)(w0 >> 29)), (fuel & a0[i0 & 3u])); }
                            e0 = e0 * 0.5L + (long double)(((0x5696079fu - (unsigned)((short)(unsigned)((int)9u >= (int)p0) > (signed char)3u)) >> ((unsigned)f0 & 31u)) & 1023u);
                        } while (i2++ < 4u && 0x10000u);
                        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((int)i2 >= (int)a0[u1 & 3u]) == (unsigned)(0x10f1fb3u == 0xffffffffu)));
                        while (i2++ < 5u && (r0.x >> (r0.y & 31u))) { if (--fuel == 0u) goto done;
                            u0 ^= 0x5c2a26f9u;
                            goto L0;
                            c1 = (signed char)(unsigned)((unsigned)(short)(0x10000u + u1) || ((unsigned)c1 ^ i0));
                        }
                    } else {
                        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)h1, (unsigned)(4u && (unsigned)((unsigned)c0 && garr[i1 & 7u])), ((unsigned)c0 ^ (unsigned)(*q0 < p0))); }
                    }
                }
                x0 = x0 * 0x100000001b3ull + 0x7fffffffu;
            }
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((0x83c26a4au | i1)) {
                    if (u3 == 7u) return ((unsigned)h0 + (g1 % (((unsigned)e0 % (1u | 1u)) | 1u)));
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)x0, (unsigned)(6u || 5u), p0); }
                } else {
                    if ((unsigned)(u2 < (unsigned)s1)) break;
                    if ((6u & (unsigned)c1)) break;
                }
                x0 = x0 * 0x100000001b3ull + ((unsigned)((short)r0.x > (signed char)0xf0cf64dau) & (g1 / (((unsigned)c0 & 2u) | 1u)));
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t2; double z2; if (((unsigned)(unsigned char)(((unsigned)(x0 >> 70) ^ (unsigned)x0) + (unsigned)f0)) & 1u) { t2 = p0; z2 = (double)((-(7u - a0[i0 & 3u])) & 255u); } if (((unsigned)(unsigned char)(((unsigned)(x0 >> 70) ^ (unsigned)x0) + (unsigned)f0)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                        if (((unsigned)c0 * 7u)) goto L3;
                        if ((unsigned)((short)u2 > (signed char)(unsigned)(0u && (unsigned)w0))) {
                            if ((0xffffffffu & fuel)) break;
                            h0 = (short)((unsigned)(w0 >> 29) << (m0 & 31u));
                        } else {
                            e0 = e0 * 0.5L + (long double)((unsigned)((int)i1 >= (int)r0.x) & 1023u);
                        }
                        if (budget != 0u) { budget -= 1u; u1 = fn1((0x10000u / (2u | 1u)), (unsigned)f0, (unsigned)h1); }
                        if (fuel < 8u) return ((unsigned)c0 + (((unsigned)((int)9u >= (int)(unsigned)(w0 >> 29)) >> (i1 & 31u)) << (p2 & 31u)));
                        break; (void)((u2 / ((unsigned)f0 | 1u)));
                    }
                    while (i2++ < 7u && (unsigned)((unsigned)d0 || (unsigned)(*q0 && (unsigned)c0))) { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)(unsigned)(signed char)(unsigned)((unsigned)x0 && u0) < (int)0x80000000u)) continue;
                        if ((1u + (i2 ^ 0x7fffffffu))) break;
                        if ((u0 ^ (unsigned)x0)) goto L1;
                        u1 = (unsigned)((int)(fuel + 0xffffffffu) >= (int)(unsigned)((unsigned)d0 == 0xd5990066u));
                        continue; (void)(i0);
                    }
                }
            }
        } else {
            v0 = (0x9d96bdffu & r0.x);
            goto L2;
            c0 = (unsigned char)(unsigned)(short)(unsigned)(0x7fffffffu < ((0x37e8b617u + (unsigned)f0) + (unsigned)(0xf7592e9u < v0)));
        }
        r0.y ^= (0x10000u >> (a0[i0 & 3u] & 31u));
        *q0 = ((unsigned)(0x7fffffffu && ~((unsigned)e0 ? garr[u2 & 7u] : r0.y)) & (unsigned)c0);
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + ((i2 ? (unsigned)(w0 >> 29) : 6u) * (unsigned)x0));
        w0 = w0 * 6364136223846793005ull + (2u - ((unsigned)w0 >> (0u & 31u)));
        if ((unsigned)c1) {
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(short)(0x7ae90cbbu ? (unsigned)e0 : 0xffffffffu), ((unsigned)f0 / (p1 | 1u)), (unsigned)(9u || (g1 - 0x3a6a6454u))); }
            if ((unsigned)(0x10000u < (unsigned)s0)) break;
            if ((unsigned)((0xffffffffu * (unsigned)h0) || garr[u2 & 7u])) break;
        } else {
            if ((unsigned)b0) break;
            if (~(unsigned)((short)a0[i0 & 3u] > (signed char)p1)) goto L3;
            c0 = (unsigned char)0x31214c40u;
            if ((garr[u2 & 7u] ^ garr[i1 & 7u])) break;
        }
        u3 = 0xffffffffu;
    }
    if (0x10000u) goto L3;
    while (i0++ < 2u && (((unsigned)w0 / (0u | 1u)) ^ 0x7fffffffu)) { if (--fuel == 0u) goto done;
        break; (void)(((i0 / (m0 | 1u)) - 0x2fafb4eu));
        if (0x2e20b8bfu) goto L4;
        if (u3 == 7u) return (9u >> ((unsigned)f0 & 31u));
        if (5u) goto L2;
        if ((u0 ^ (unsigned)s0)) {
            if (0xa699da27u) continue;
            if (budget != 0u) { budget -= 1u; u2 = fn2((garr[u2 & 7u] + 0x7fffffffu), (p0 << ((unsigned)d0 & 31u)), a0[i0 & 3u]); }
        } else {
            switch ((0x4acb3e03u | *q0) & 7u) {
                { unsigned t3; double z3; if (((unsigned)((int)(unsigned)b0 < (int)(unsigned)s1)) & 1u) { t3 = p2; z3 = (double)(((unsigned)((int)v0 >= (int)1u)) & 255u); } if (((unsigned)((int)(unsigned)b0 < (int)(unsigned)s1)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    break; (void)(((0x7fffffffu ^ 0x717283fu) << (fuel & 31u)));
                    switch ((unsigned)((unsigned)(w0 >> 29) == a0[i0 & 3u]) & 7u) {
                        s0 = (int)((unsigned)(short)(unsigned)((unsigned)s1 || 0xa38f81aau) * 0xfffc478fu);
                        case 0u: ;
                        r0.x = (((a0[i0 & 3u] % (i2 | 1u)) >> ((unsigned)d0 & 31u)) << (i2 & 31u));
                        h1 = (unsigned short)(h1 + (unsigned)((int)(a0[u1 & 3u] % (0xaf91b8f6u | 1u)) < (int)1u));
                        c1 = (signed char)(unsigned)((int)(unsigned)(*q0 == (unsigned)(i1 < garr[i1 & 7u])) < (int)*mp);
                        e0 = e0 * 0.5L + (long double)(r0.x & 1023u);
                    }
                    if ((unsigned)!(unsigned)((unsigned)b0 == ((unsigned)s0 % ((unsigned)f0 | 1u)))) {
                        if ((unsigned)(0xf255494eu || (unsigned)h0)) continue;
                    }
                    u1 = (v0 << ((unsigned)x0 & 31u));
                    if ((g1 | (0x10000u & 4u))) break;
                }
                if ((unsigned)(u1 && (unsigned)((int)6u >= (int)garr[i1 & 7u]))) {
                    garr[(unsigned)(a0[i0 & 3u] == *mp) & 7u] = (unsigned)((int)0xa527ea13u >= (int)(unsigned)l0);
                    if (u3 == 7u) return (u3 + (unsigned)((short)(unsigned)(m0 < 0x10000u) > (signed char)0x7fffffffu));
                    u3 ^= ((a0[u1 & 3u] + p1) + (6u + (unsigned)s0));
                    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)d0 == (unsigned)(((unsigned)s0 * (unsigned)e0) < 0x10000u)));
                    if ((unsigned)((unsigned)s0 < fuel)) {
                        *q0 = (fuel % ((unsigned)(a0[u1 & 3u] == (unsigned)h0) | 1u));
                        case 2u: ;
                        default: ;
                        case 1u: ;
                        l0 = (long)((unsigned long)l0 + ~(unsigned)((short)(i2 / (u3 | 1u)) > (signed char)p2));
                    }
                } else {
                    g0 = (unsigned)((unsigned)(r0.x && 0x10000u) && 0xacfb98bfu);
                    f0 = f0 * 0.5f + (float)((p2 | (0x7fffffffu / (0x80000000u | 1u))) & 255u);
                }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((0xadb8ce79u % (u3 | 1u)), (unsigned)w0, (unsigned)(unsigned char)((unsigned)(w0 >> 29) | 0x7fffffffu)); }
            while (i1++ < 5u && ((unsigned)w0 << (g1 & 31u))) { if (--fuel == 0u) goto done;
                { unsigned t4; double z4; if ((((unsigned)(unsigned char)(0xd3fe28a9u + u3) << ((unsigned)h1 & 31u))) & 1u) { t4 = (unsigned)((int)(unsigned)h0 >= (int)(unsigned)f0); z4 = (double)((((unsigned)(unsigned char)(unsigned)((int)(unsigned)w0 < (int)(unsigned)h0) << (0x80000000u & 31u))) & 255u); } if ((((unsigned)(unsigned char)(0xd3fe28a9u + u3) << ((unsigned)h1 & 31u))) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                    { unsigned t5; double z5; if ((p0) & 1u) { t5 = ((unsigned)((short)u3 > (signed char)v0) & v0); z5 = (double)(((unsigned)(x0 >> 70)) & 255u); } if ((p0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                        if ((unsigned)s0) break;
                        if (budget != 0u) { budget -= 1u; u0 = fn1((0x10000u | i0), 0u, (unsigned)c0); }
                        e0 = e0 * 0.5L + (long double)((p0 << ((u0 + (unsigned)(0x10000u && (unsigned)((int)u0 >= (int)(unsigned)x0))) & 31u)) & 1023u);
                    }
                    if (p2) continue;
                    if ((unsigned)(garr[i1 & 7u] && 0x52d8ec32u)) goto L0;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn2(garr[u2 & 7u], (unsigned)((short)a0[u1 & 3u] > (signed char)8u), (unsigned)((short)v0 > (signed char)(unsigned)h0)); }
                if ((m0 << ((unsigned)(v0 == 0xaf48c5bu) & 31u))) break;
                g0 = ((u2 + u3) * ((unsigned)(w0 >> 29) ? g1 : v0));
            }
        }
        if ((unsigned)e0) goto L2;
    }
    u2 = u2 * 0x9e3779b1u + (i0 | (unsigned)((unsigned)s0 && (0xd270eb87u ? (unsigned)h1 : (unsigned)s1)));
    switch (~((unsigned)(unsigned char)(0x10000u + garr[u2 & 7u]) ^ 0u) & 7u) {
        goto L4;
        goto L1;
        case 6u: ;
        { unsigned t6; double z6; if ((~((unsigned)w0 ? r0.x : g1)) & 1u) { t6 = ((unsigned)c0 ^ (unsigned)(x0 >> 70)); z6 = (double)(((unsigned)(short)(unsigned)(0xffffffffu == (unsigned)(unsigned char)(3u ^ p0))) & 255u); } if ((~((unsigned)w0 ? r0.x : g1)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            if (u2) {
                u1 = (unsigned)((short)a0[i0 & 3u] > (signed char)i2);
                s1 = (int)((unsigned)s1 + u2);
                f0 = f0 * 0.5f + (float)(((unsigned)f0 / ((unsigned)e0 | 1u)) & 255u);
                h1 = (unsigned short)(h1 + ((unsigned)!(((unsigned)w0 << ((unsigned)e0 & 31u)) * (unsigned)e0) | (*mp ^ 0x7fffffffu)));
            }
            if ((unsigned)((int)(unsigned)s1 < (int)(unsigned)c0)) goto L1;
            if (budget != 0u) { budget -= 1u; u3 = fn0((u0 / ((unsigned)((unsigned)b0 && 7u) | 1u)), (unsigned)e0, (v0 ^ (unsigned)(0xa8a48833u == (unsigned)f0))); }
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 0u: ;
                if (0x2c82b26cu) {
                    case 5u: ;
                }
                d0 = d0 * 0.5 + (double)((garr[i1 & 7u] - 3u) & 1023u);
            }
            case 1u: ;
        }
        case 7u: ;
    }
    *q0 += (unsigned)f0;
    i2 = ~(u1 / (0x80000000u | 1u)) & 15u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    r0.y ^= (unsigned)((short)0xf571dfbbu > (signed char)v0);
    if ((unsigned)((short)(unsigned)l0 > (signed char)0x5100f480u)) {
        s1 = (int)((unsigned)s1 + ((unsigned)((short)u1 > (signed char)0x7fffffffu) / (((*q0 * 0xffffffffu) << (1u & 31u)) | 1u)));
        d0 = d0 * 0.5 + (double)(((unsigned)((int)(unsigned)(w0 >> 29) >= (int)r0.x) * (unsigned)(signed char)((unsigned)c1 - (unsigned)(fuel == 0xfeadce71u))) & 1023u);
        l0 = (long)((unsigned long)l0 + (*q0 | (unsigned)((unsigned)s0 == u2)));
        v0 = (unsigned)(signed char)(u0 & (unsigned)(0x7fffffffu == 0xb4be91e8u));
        switch (0x9065e662u & 7u) {
            *q0 += (unsigned)(9u || (unsigned)e0);
        }
        goto L4;
    } else {
        if ((garr[i1 & 7u] + 2u)) goto L3;
    }
    r0.y ^= (unsigned)((unsigned)h1 < u2);
    if ((i0 * (unsigned)(signed char)(*q0 << (*mp & 31u)))) goto L4;
    s1 = (int)((unsigned)s1 + (~(*q0 * garr[i1 & 7u]) & (1u | 0x6ada1424u)));
    { unsigned t0; double z0; if ((((unsigned)l0 | -(unsigned)(u3 && u0))) & 1u) { t0 = 0xf9c6641du; z0 = (double)(((unsigned)((int)p0 < (int)(unsigned)s0)) & 255u); } if ((((unsigned)l0 | -(unsigned)(u3 && u0))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        L0: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn3((u0 >> (i2 & 31u)), (((unsigned)x0 << (v0 & 31u)) >> (7u & 31u)), 0x49c746a7u); }
        s0 = (int)((unsigned)((int)v0 < (int)r0.x) >> (0x5eec92fbu & 31u));
        L1: if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)(short)((((unsigned)h1 ^ p1) % (0xb7013dd3u | 1u)) ^ u3) & 1023u);
        switch (6u & 7u) {
            if (u1) {
                if ((unsigned)(r0.x && ((unsigned)(x0 >> 70) - a0[i0 & 3u]))) {
                    *q0 += (*q0 | (unsigned)l0);
                    goto L3;
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s1, (unsigned)h1, (0x8dec11d4u + r0.x)); }
                    case 4u: ;
                    s0 = (int)3u;
                    g0 = (unsigned)(0xb2193ca6u == (unsigned)((int)0xffffffffu >= (int)a0[i0 & 3u]));
                }
                if (r0.y) goto done;
                L2: if (--fuel == 0u) goto done;
                if (fuel < 8u) return 0x80000000u;
            } else {
                u0 += ((unsigned)c0 | (r0.x / (0x80000000u | 1u)));
            }
        }
    }
    switch (((0xf01b511u % (p0 | 1u)) << ((unsigned)h0 & 31u)) & 7u) {
        u0 = u0 * 0x9e3779b1u + (5u ^ (0xa4d9ff82u % (p1 | 1u)));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn1(a0[i0 & 3u], (unsigned)((unsigned)(1u || i2) < g1), 0x10000u); }
    if (9u) goto L2;
    goto L1;
    r0.y ^= ((r0.x ? 1u : i0) & p2);
    c1 = (signed char)(unsigned)(signed char)(~(((unsigned)s1 % (4u | 1u)) - 0x7fffffffu) / (i2 | 1u));
    garr[u3 & 7u] = (unsigned)(p1 && (unsigned)(short)(0x3b0be15bu + u3));
    h1 = (unsigned short)(h1 + (*q0 * p2));
    { unsigned t1; double z1; if (((unsigned)((int)(unsigned)((int)u0 >= (int)(unsigned)h0) >= (int)(unsigned)h0)) & 1u) { t1 = 9u; z1 = (double)((0xd7ac0ea9u) & 255u); } if (((unsigned)((int)(unsigned)((int)u0 >= (int)(unsigned)h0) >= (int)(unsigned)h0)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        m0 ^= (u2 % ((unsigned)(*q0 == 9u) | 1u));
        if (budget != 0u) { budget -= 1u; u2 = fn3(i2, (0xbb285d17u >> ((unsigned)(i0 && a0[i0 & 3u]) & 31u)), p0); }
        *q0 += (unsigned)((unsigned)((short)i2 > (signed char)p2) || (unsigned)(g0 < i2));
        u3 = u3 * 0x9e3779b1u + (u2 & (unsigned)((int)(unsigned)((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)p0) == i1) >= (int)0xb5e3401u));
        L3: if (--fuel == 0u) goto done;
    }
    r0.y ^= 0u;
    h1 = (unsigned short)(h1 + (((unsigned)s0 - 0u) / ((unsigned)((int)(unsigned)s0 < (int)(unsigned)h1) | 1u)));
    if ((0x14c4eaf6u ^ v0)) goto done;
    g0 = (unsigned)(x0 >> 70);
    if ((unsigned)c0) {
        u0 = (unsigned)(unsigned char)(unsigned)((unsigned)((unsigned)c1 || 0xbd60f0b2u) || (unsigned)((short)u2 > (signed char)fuel));
        s1 = (int)((unsigned)s1 + ((unsigned)h0 | (*mp - p0)));
    }
    if (((unsigned)s1 << (m0 & 31u))) goto L3;
    q0 = &garr[(unsigned)(((unsigned)c1 - (unsigned)((r0.y % (fuel | 1u)) < 0x80000000u)) && (unsigned)s1) & 7u];
    if ((unsigned)c1) goto L4;
    c0 = (unsigned char)(unsigned)((0u | u3) < (unsigned)d0);
    u0 += (unsigned)(((unsigned)(unsigned char)(2u % ((unsigned)(w0 >> 29) | 1u)) % (u1 | 1u)) == (unsigned)w0);
    v0 = (unsigned)(signed char)((unsigned)((short)g1 > (signed char)u2) - ~(unsigned)(u1 == 0xffffffffu));
    *mp = (unsigned)(0xffffffffu == (unsigned)((unsigned)!((unsigned)s1 ? i0 : p1) && u3));
    switch ((unsigned)(unsigned char)((unsigned)b0 ? r0.y : p0) & 7u) {
        if (9u) break;
        if ((unsigned)h1) goto L2;
        b0 = (unsigned)(v0 || (unsigned)((int)(0x762eba3au >> (0x2b6c1123u & 31u)) >= (int)0x473f871eu)) != 0u;
        while (i0++ < 6u && (unsigned)(signed char)(1u * (unsigned)c0)) { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)!(((0x80000000u ? r0.x : g0) / (garr[u2 & 7u] | 1u)) % (p2 | 1u));
            u0 += (unsigned)!(*mp + (unsigned)((int)(unsigned)e0 < (int)v0));
        }
        garr[(i1 >> (g0 & 31u)) & 7u] = (unsigned)(w0 >> 29);
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)s0, (unsigned)l0, ((unsigned)s0 | 7u)); }
        }
    }
    goto done;
    if (-(0xffffffffu - (unsigned)s1)) goto L0;
L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 12u, 0xff485c92u, 0x3f8cc756u },
        { 9u, 0x509bcaccu, 0x276814c5u },
        { 1u, 0x7a5fd6e6u, 0xc37781f2u },
        { 13u, 0xc63ed953u, 0xe4d9bbdu },
        { 15u, 0xdd74f0au, 0x52c5e1efu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
