// test-ssa-source's program of seed 134000436 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xce8633e7u, g1 = 0x283424beu;
static unsigned garr[8] = { 0x2dd339cdu, 0x329c9743u, 0x6fcbcbd8u, 0x79944fa9u, 0xa10c410bu, 0x6d3bc484u, 0xac9692b2u, 0x1eb65812u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if (((unsigned)((int)(unsigned)((short)u1 > (signed char)(unsigned)e0) < (int)(unsigned)(w0 >> 29))) & 1u) { t0 = p0; z0 = (double)((g1) & 255u); } if (((unsigned)((int)(unsigned)((short)u1 > (signed char)(unsigned)e0) < (int)(unsigned)(w0 >> 29))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        *mp = ((unsigned)((int)0xec2ccb60u < (int)a0[u1 & 3u]) / ((unsigned)((unsigned)((short)3u > (signed char)g1) && 4u) | 1u));
        if ((r0.y >> (4u & 31u))) goto L1;
        if (0xffffffffu) goto L2;
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)((int)((unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)d0) | 0x43f56aa4u) < (int)2u) & 1023u);
            if (~(unsigned)((short)*q0 > (signed char)(unsigned)x0)) break;
            *mp = (u0 - 9u);
        }
        if (r0.y) {
            c0 = (unsigned char)(~(unsigned)((int)m0 >= (int)(unsigned)s1) - (unsigned)s0);
            u2 ^= u2;
            while (i0++ < 3u && (5u * g0)) { if (--fuel == 0u) goto done;
                if (~(7u & g0)) break;
                f0 = f0 * 0.5f + (float)(4u & 255u);
                f0 = f0 * 0.5f + (float)((unsigned)(7u == (unsigned)!((g0 + v0) | r0.y)) & 255u);
                if (-(0x382a208du * v0)) {
                    u1 += i0;
                    b0 = (unsigned)(signed char)(*q0 + (unsigned)(0x8424414bu < i1)) != 0u;
                    if ((a0[i0 & 3u] << (v0 & 31u))) {
                        if (u3 == 7u) return (unsigned)((int)(0xf9fd9364u - (unsigned)h1) >= (int)((p1 ^ m0) * g0));
                    }
                    L0: if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((0x80000000u & ((unsigned)d0 << (a0[i0 & 3u] & 31u))) & 1023u);
                }
            }
            if (p2) {
                s0 = (int)(unsigned)(short)(unsigned)((unsigned)(u3 < (unsigned)(short)(unsigned)(0x80000000u < 0xab6a3e83u)) == 0x9965e06u);
            }
            *q0 += (((unsigned)e0 - (unsigned)l0) ^ 0xbb201d41u);
            L1: if (--fuel == 0u) goto done;
        }
        i0 = (unsigned)((*mp << ((unsigned)(0x10000u || (unsigned)(p0 < (unsigned)h0)) & 31u)) || p2) & 15u;
    }
    L2: if (--fuel == 0u) goto done;
    L3: if (--fuel == 0u) goto done;
    u0 = (2u | m0);
    *mp = (i1 ^ 0x80000000u);
    switch ((unsigned)((int)(unsigned)f0 >= (int)*mp) & 7u) {
        if (u1) break;
    }
    if ((0x80000000u + 8u)) {
        if (((unsigned)s1 & g1)) goto done;
        { unsigned t1; double z1; if ((r0.x) & 1u) { t1 = a0[i0 & 3u]; z1 = (double)(((fuel >> ((unsigned)c1 & 31u))) & 255u); } if ((r0.x) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            if (((unsigned)(short)(1u - garr[u2 & 7u]) * r0.y)) {
                u3 ^= ((garr[i1 & 7u] << (u2 & 31u)) & ((unsigned)(*q0 < g1) << (u1 & 31u)));
                if ((*q0 & p0)) goto L0;
                goto L1;
                L4: if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        s0 = (int)(unsigned)d0;
                        s1 = (int)((unsigned)s1 + ((r0.x ^ u2) * (0x7fffffffu / ((unsigned)(w0 >> 29) | 1u))));
                        r0.y ^= (unsigned)((unsigned)((int)*mp < (int)((unsigned)(i1 == 3u) ^ p0)) && 9u);
                        if (p0) break;
                        break; (void)((u1 ^ 0x976eca42u));
                    }
                    u1 = u1 * 0x9e3779b1u + (unsigned)(((9u | 0u) + (unsigned)d0) < (unsigned)!(2u - fuel));
                    x0 = x0 * 0x100000001b3ull + 0xb97b90eau;
                    break; (void)(((i1 * 0xb182438fu) / (9u | 1u)));
                    b0 = ~(unsigned)((unsigned)c1 || r0.x) != 0u;
                } while (i0++ < 6u && i2);
            }
            if (i1) goto L3;
        }
        h1 = (unsigned short)(h1 + (p1 + (i1 * (0xbf7634e3u * i1))));
        if (0u) {
            if ((unsigned)((short)u1 > (signed char)u0)) goto L2;
            do { if (--fuel == 0u) goto done;
                if ((u2 / (m0 | 1u))) {
                    if (((unsigned)(signed char)(unsigned)((int)u0 < (int)(unsigned)(w0 >> 29)) >> (u3 & 31u))) break;
                    if (((unsigned)((unsigned)x0 && g0) << (v0 & 31u))) break;
                    if ((0x77011519u % (u2 | 1u))) goto L3;
                    break; (void)(1u);
                }
                w0 ^= (unsigned long long)a0[i0 & 3u] << ((v0 % (((unsigned)((unsigned)(x0 >> 70) || 0x10000u) % ((fuel << ((unsigned)x0 & 31u)) | 1u)) | 1u)) & 63u);
                if (i2) continue;
                if ((unsigned)((int)(0xb51d588eu >> (r0.x & 31u)) < (int)(unsigned)h1)) break;
            } while (i0++ < 5u && (u3 - 0xffffffffu));
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)(unsigned char)(-(g0 ? 0xffffffffu : 0x7fffffffu) + p2) & 7u];
                w0 ^= (unsigned long long)m0 << ((unsigned)((int)((unsigned)(short)(r0.y & r0.x) - (unsigned)e0) < (int)(0xef88e47cu + (unsigned)h0)) & 63u);
            }
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)garr[u2 & 7u] > (signed char)2u)) break;
            switch ((unsigned)c0 & 7u) {
                w0 ^= (unsigned long long)0xe4aa391u << (0x340e9d77u & 63u);
                if (9u) {
                    if (0x16471136u) continue;
                } else {
                    case 1u: ;
                    default: ;
                }
                i1 = (unsigned)(7u && ((0xb0fb730du + 5u) / (0xfcc16559u | 1u))) & 15u;
                x0 = x0 * 0x100000001b3ull + (garr[i1 & 7u] | (unsigned)(signed char)(unsigned)((short)0x29322735u > (signed char)a0[i0 & 3u]));
            }
            d0 = d0 * 0.5 + (double)((((unsigned)s1 % ((0xfe684d9u * 0x85d12b97u) | 1u)) * ((unsigned)w0 + 0x809ae3efu)) & 1023u);
            u3 ^= (r0.x & (unsigned)d0);
            m0 ^= g0;
        }
        h1 = (unsigned short)(h1 + (0xffffffffu * (unsigned)((unsigned)((unsigned)b0 || (unsigned)w0) && 0x10000u)));
    } else {
        if (((*q0 ^ 0x58154c66u) | (unsigned)c0)) {
            *mp = (unsigned)(-(*q0 ? (unsigned)((int)u2 < (int)a0[i0 & 3u]) : p0) == i0);
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)((a0[u1 & 3u] - 0xff98469eu) | (u3 - (unsigned)w0));
                break; (void)((m0 >> (-((unsigned)e0 + g1) & 31u)));
                if (((unsigned)f0 ^ 0x2e3abf9cu)) {
                    a0[(unsigned)f0 & 3u] = ((unsigned)f0 % ((unsigned)x0 | 1u));
                    r0.x = ((unsigned)e0 + (0xeb82028au << (2u & 31u)));
                    switch ((unsigned)w0 & 7u) {
                        if (((unsigned)e0 & 5u)) goto L1;
                    }
                    break; (void)((unsigned)((int)(unsigned)f0 >= (int)0xc1ef4e3u));
                } else {
                    x0 = x0 * 0x100000001b3ull + (p2 & 0xfec5ca48u);
                    if (g1) break;
                    *mp = (unsigned)(i0 || (unsigned)(u3 || (unsigned)(0x9d601eb4u || (unsigned)!(g1 ^ (unsigned)f0))));
                    garr[(unsigned)((short)(unsigned)c0 > (signed char)u0) & 7u] = ((unsigned)w0 ? (unsigned)h0 : p2);
                }
                u3 ^= (i2 >> (0xfc9ed4c2u & 31u));
                if (a0[u1 & 3u]) break;
                u1 = (unsigned)e0;
            }
            r0.x = (unsigned)(0xcac03f51u || p0);
            switch (((4u >> (a0[u1 & 3u] & 31u)) << (8u & 31u)) & 7u) {
                if ((unsigned)(0u && g0)) break;
                if (u3 == 7u) return (unsigned)(signed char)(unsigned)((int)u1 < (int)(unsigned)c0);
                case 6u: ;
                if (u0) goto L4;
                case 3u: ;
            }
            if ((unsigned)((int)0x10000u < (int)(9u & (unsigned)h0))) goto L4;
            u2 = ((unsigned)d0 ^ (unsigned)(m0 < (0x7b8cefe4u >> (0x7fffffffu & 31u))));
        }
        if (g0) goto L4;
        if ((unsigned)((int)g1 >= (int)(unsigned)((short)g0 > (signed char)a0[u1 & 3u]))) goto L0;
    }
    if (0xe49a31fu) goto L4;
    b0 = (unsigned)(fuel == v0) != 0u;
    goto L3;
    g1 += (((unsigned)h1 - (unsigned)b0) << ((unsigned)(a0[i0 & 3u] && 2u) & 31u));
    { unsigned t2; double z2; if (((garr[i1 & 7u] | (0xb1d010afu << ((unsigned)l0 & 31u)))) & 1u) { t2 = u2; z2 = (double)((((garr[i1 & 7u] ^ (unsigned)b0) % (0x80000000u | 1u))) & 255u); } if (((garr[i1 & 7u] | (0xb1d010afu << ((unsigned)l0 & 31u)))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        { unsigned t3; double z3; if (((unsigned)((short)u2 > (signed char)(p0 >> (7u & 31u)))) & 1u) { t3 = (unsigned)(x0 >> 70); z3 = (double)(((4u + 2u)) & 255u); } if (((unsigned)((short)u2 > (signed char)(p0 >> (7u & 31u)))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            if ((unsigned)((short)0x7af6f0e3u > (signed char)8u)) {
                if (i1) goto L2;
                if (0x10000u) goto done;
            } else {
                goto L1;
            }
            q0 = &garr[((unsigned)((0x80000000u * r0.x) == (unsigned)(w0 >> 29)) << (i1 & 31u)) & 7u];
            if (4u) goto L3;
            if ((p0 & (7u - u3))) goto L3;
        }
        { unsigned t4; double z4; if ((8u) & 1u) { t4 = ~(unsigned)((a0[i0 & 3u] * (unsigned)c1) && u2); z4 = (double)((-((0x7ecbcca1u % (0x10000u | 1u)) << (3u & 31u))) & 255u); } if ((8u) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            *q0 += ((unsigned)((unsigned)d0 < 0xeab71bc7u) / ((unsigned)((short)g0 > (signed char)*mp) | 1u));
            if ((unsigned)((short)7u > (signed char)a0[i0 & 3u])) goto L2;
            while (~((0x6e56ad22u & r0.x) | (unsigned)b0)) { if (--fuel == 0u) goto done;
                break; (void)(((i2 % (u2 | 1u)) | u1));
                if (g1) continue;
                b0 = (unsigned)b0 != 0u;
                e0 = e0 * 0.5L + (long double)(((i0 % (6u | 1u)) * (unsigned)f0) & 1023u);
                if ((garr[i1 & 7u] & 8u)) {
                    break; (void)((0x7fffffffu & (unsigned)e0));
                } else {
                    do { if (--fuel == 0u) goto done;
                        r0.x = 0xda02ca28u;
                        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((int)(unsigned)((short)6u > (signed char)(unsigned)h0) < (int)3u) < u2));
                        break; (void)((unsigned)((int)0xffffffffu >= (int)4u));
                        h0 = (short)(unsigned)((int)2u >= (int)(g0 ^ (7u / (9u | 1u))));
                    } while (i1++ < 4u && (unsigned)((unsigned)h0 || (unsigned)s0));
                }
                if ((unsigned)(5u == r0.x)) break;
            }
        }
    }
    if (((unsigned)((unsigned)f0 < 0xc706ac44u) * (unsigned)s1)) goto L4;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((u3 & 0x7fffffffu));
        r0.x = (unsigned)c1;
        while (i1++ < 5u && (unsigned)((int)(unsigned)(x0 >> 70) < (int)g0)) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((unsigned)((short)(u2 << (3u & 31u)) > (signed char)u3) / (i1 | 1u));
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                u2 = (unsigned)(0x6f94db3fu == 7u);
                break; (void)((a0[u1 & 3u] << (r0.y & 31u)));
                break; (void)(9u);
                if ((unsigned)(3u && g0)) break;
                l0 = (long)((unsigned long)l0 + (p1 >> (u0 & 31u)));
                if ((unsigned)d0) break;
            }
        }
        { unsigned t5; double z5; if ((((unsigned)c1 % ((unsigned)(signed char)(m0 ^ (unsigned)c1) | 1u))) & 1u) { t5 = (unsigned)(3u == (unsigned)(signed char)(unsigned)(0xffffffffu == (unsigned)e0)); z5 = (double)(((unsigned)(signed char)(p0 - (unsigned)(short)(unsigned)((int)r0.y < (int)2u))) & 255u); } if ((((unsigned)c1 % ((unsigned)(signed char)(m0 ^ (unsigned)c1) | 1u))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            if (0xf97ea942u) break;
            if ((5u / ((unsigned)s1 | 1u))) continue;
            *q0 = (0xffffffffu | (unsigned)x0);
        }
    }
    if (u3 == 7u) return ((unsigned)(0x10000u && (0x6ca69b3cu - u1)) % (6u | 1u));
    if ((unsigned)((unsigned)(u0 && (unsigned)(w0 >> 29)) || 0x10000u)) {
        f0 = f0 * 0.5f + (float)(((unsigned)((short)(unsigned)w0 > (signed char)(unsigned)h0) ^ r0.y) & 255u);
        if (((unsigned)(x0 >> 70) * (2u % (0x1a1bb42fu | 1u)))) goto done;
        if (0u) goto done;
        if ((unsigned)((int)garr[u2 & 7u] < (int)i1)) goto L2;
        d0 = d0 * 0.5 + (double)((*mp >> (garr[u2 & 7u] & 31u)) & 1023u);
    } else {
        l0 = (long)((unsigned long)l0 + (unsigned)((int)0x80000000u >= (int)i0));
        while (i0++ < 2u && ((unsigned)b0 | (unsigned)w0)) { if (--fuel == 0u) goto done;
            if (*q0) {
                if (fuel < 8u) return (garr[u2 & 7u] * (a0[u1 & 3u] * (unsigned)(x0 >> 70)));
                g0 = ((unsigned)f0 / (0x2da13fb7u | 1u));
            }
        }
        while (i0++ < 5u && (unsigned)d0) { if (--fuel == 0u) goto done;
            if (*mp) break;
            c0 = (unsigned char)(unsigned)(((unsigned)e0 | a0[i0 & 3u]) == ((unsigned)((unsigned)x0 && u0) | garr[i1 & 7u]));
            continue; (void)((unsigned)((int)(unsigned)(p0 == 6u) < (int)(unsigned)x0));
            if (((unsigned)s1 & p1)) break;
        }
        c0 = (unsigned char)(unsigned)d0;
    }
    s1 = (int)((unsigned)s1 + 9u);
    s0 = (int)(9u / ((unsigned)((short)((u0 & (unsigned)d0) / ((unsigned)h0 | 1u)) > (signed char)0xa6f50569u) | 1u));
    { unsigned t6; double z6; if (((unsigned)((unsigned)e0 == (unsigned)(m0 < garr[i1 & 7u]))) & 1u) { t6 = (unsigned)(unsigned char)((0x7e46f5b4u - 6u) * (unsigned)x0); z6 = (double)((g0) & 255u); } if (((unsigned)((unsigned)e0 == (unsigned)(m0 < garr[i1 & 7u]))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
        garr[(u3 % (0x10000u | 1u)) & 7u] = ((unsigned)(w0 >> 29) + 0x12aecfa9u);
        if ((unsigned)((int)(unsigned)((short)i0 > (signed char)*q0) < (int)r0.y)) goto L3;
        if ((0xffffffffu - p2)) {
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(~(garr[u2 & 7u] ^ u3) || r0.y)) break;
                if (((unsigned)s1 + 3u)) continue;
                v0 = ((unsigned)(short)((a0[i0 & 3u] ^ 4u) ^ 0x83419418u) << (((unsigned)c0 / (r0.y | 1u)) & 31u));
                if (m0) break;
                if (9u) break;
            }
            if (*q0) goto L4;
            goto L3;
            if (p2) goto L0;
            if (((unsigned)h1 * i2)) goto L3;
            a0[(unsigned)(g0 == 1u) & 3u] = (unsigned)w0;
        } else {
            c1 = (signed char)0x10000u;
            w0 = w0 * 6364136223846793005ull + (unsigned)d0;
            g1 += (0x80000000u << ((unsigned)((short)i1 > (signed char)0xffffffffu) & 31u));
        }
        *q0 += (((unsigned)l0 + (unsigned)c1) % ((0xbc2bd099u >> ((unsigned)(short)(unsigned)((int)0u >= (int)i1) & 31u)) | 1u));
        w0 ^= (unsigned long long)1u << (((unsigned)s1 ? 0x10000u : 6u) & 63u);
    }
    { unsigned t7; double z7; if ((((unsigned)s1 % (((unsigned)h0 % ((unsigned)c0 | 1u)) | 1u))) & 1u) { t7 = (unsigned)(0x639399c8u < 3u); z7 = (double)((((unsigned)(v0 && i2) * (unsigned)l0)) & 255u); } if ((((unsigned)s1 % (((unsigned)h0 % ((unsigned)c0 | 1u)) | 1u))) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
        s1 = (int)((unsigned)s1 + (unsigned)((0xf3835a97u + 0u) == (unsigned)d0));
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                while (i2++ < 4u && (v0 & 6u)) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)(unsigned)(short)(9u + a0[u1 & 3u]) >= (int)(unsigned)s0)) break;
                    if ((unsigned)(0x7fffffffu < 0x80000000u)) break;
                    c0 = (unsigned char)((8u << (p2 & 31u)) >> ((i0 % ((unsigned)s1 | 1u)) & 31u));
                    if ((unsigned)c0) break;
                    h0 = (short)(unsigned)((int)u0 < (int)(a0[i0 & 3u] * (0xffffffffu + (unsigned)w0)));
                }
            }
            if (*q0) break;
            d0 = d0 * 0.5 + (double)(((unsigned)x0 >> ((unsigned)(0x52f51069u < g0) & 31u)) & 1023u);
            g1 += (unsigned)(unsigned char)(unsigned)((unsigned)f0 && i1);
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((unsigned)(v0 < u2) & 1023u);
            c0 = (unsigned char)(8u ^ ((0x67d76224u % (u3 | 1u)) >> (i0 & 31u)));
            while (i1++ < 7u && 0x10000u) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)0xcb97c45u < (int)(unsigned)(short)(unsigned)((short)(r0.y << (4u & 31u)) > (signed char)0xebf1a486u));
                if (((unsigned)h0 ? p1 : (unsigned)h0)) break;
            }
            if ((unsigned)(0x63a4dee6u == (u2 - 0xffffffffu))) break;
        }
        if ((unsigned)((unsigned)b0 || i0)) goto L1;
        if (u3 == 7u) return (unsigned)((unsigned)e0 < (unsigned)((unsigned)h1 == ((unsigned)x0 / (3u | 1u))));
        goto L3;
    }
    goto L3;
    if (((unsigned)s1 >> ((unsigned)e0 & 31u))) goto L1;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        v0 = (unsigned)h1;
        if ((i0 - (unsigned)b0)) continue;
        { unsigned t8; double z8; if ((-(unsigned)(v0 || (unsigned)(unsigned char)(unsigned)((unsigned)c1 < 0x1c58e6b4u))) & 1u) { t8 = (unsigned)!(unsigned)((int)a0[u1 & 3u] >= (int)i2); z8 = (double)((0x80000000u) & 255u); } if ((-(unsigned)(v0 || (unsigned)(unsigned char)(unsigned)((unsigned)c1 < 0x1c58e6b4u))) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
            if (((unsigned)(x0 >> 70) ^ (unsigned)(unsigned char)((unsigned)w0 - i0))) break;
            if (g0) {
                switch ((unsigned)w0 & 7u) {
                    if ((i0 * (unsigned)(x0 >> 70))) continue;
                    if ((9u | u3)) break;
                    u2 = (unsigned)(0xffffffffu == (unsigned)(0xffffffffu == (0x292e210cu | 7u)));
                    case 7u: ;
                    u3 ^= -(((8u - 0xfa5b4fd8u) * 2u) | (unsigned)(0x10000u == i1));
                    r0.y ^= (g1 % ((unsigned)((int)(unsigned)c0 < (int)(unsigned)d0) | 1u));
                }
                if (6u) break;
                b0 = ((g0 * (unsigned)h0) * (unsigned)((unsigned)c1 && (0x9f8b8cedu >> (m0 & 31u)))) != 0u;
                if ((unsigned)(signed char)(g0 ? 0xe8e4154u : p2)) {
                    x0 = x0 * 0x100000001b3ull + ((fuel | (unsigned)((unsigned)b0 == (unsigned)e0)) + (0x10000u % (fuel | 1u)));
                    if ((unsigned)e0) goto L1;
                    u0 ^= (8u << (((unsigned)h0 & (unsigned)(w0 >> 29)) & 31u));
                    if (u3 == 7u) return ((unsigned)((int)(a0[u1 & 3u] + p1) < (int)0x895423fau) + (unsigned)h1);
                    break; (void)(r0.x);
                } else {
                    for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        g1 += ((p1 - ((unsigned)((int)(unsigned)d0 < (int)0x9ff2d4ceu) / ((unsigned)f0 | 1u))) ^ (unsigned)l0);
                        u0 ^= (unsigned)(signed char)(fuel - fuel);
                        u3 = u3 * 0x9e3779b1u + ~((unsigned)((int)v0 < (int)(unsigned)e0) ^ (unsigned)((unsigned)s0 < 7u));
                        u3 = u3 * 0x9e3779b1u + (unsigned)((int)(unsigned)s0 < (int)(0x7fffffffu + (unsigned)(short)(u2 >> ((unsigned)(signed char)(unsigned)((unsigned)b0 && p1) & 31u))));
                    }
                    a0[p2 & 3u] = (unsigned)((short)(a0[u1 & 3u] & i1) > (signed char)0xffffffffu);
                }
                break; (void)(g1);
            } else {
                if ((unsigned)(unsigned char)((unsigned)c1 << ((unsigned)h1 & 31u))) break;
            }
            x0 = x0 * 0x100000001b3ull + (0x7fffffffu + (unsigned)(x0 >> 70));
            g0 = (*q0 / ((unsigned)!(unsigned)(r0.x < (0xe2212c28u % (0x9993e1a5u | 1u))) | 1u));
        }
        if ((0x80000000u & (a0[u1 & 3u] % (u2 | 1u)))) {
            r0.y ^= ((unsigned)d0 << (garr[u2 & 7u] & 31u));
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)0xdc5951b4u;
            }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)(g0 == 0x740527d0u) < p1)) break;
                w0 = w0 * 6364136223846793005ull + ((unsigned)b0 ? 0xab3d6893u : a0[u1 & 3u]);
                m0 ^= (((unsigned)h0 % ((unsigned)(signed char)((unsigned)h1 ^ (unsigned)x0) | 1u)) ^ 0xffffffffu);
            } while (i1++ < 2u && (unsigned)(i0 == (unsigned)(g0 && 0x7fffffffu)));
            e0 = e0 * 0.5L + (long double)((i0 >> (p1 & 31u)) & 1023u);
            while (i1++ < 7u && ((unsigned)d0 ^ g0)) { if (--fuel == 0u) goto done;
                if (u3) break;
                { unsigned t9; double z9; if (((unsigned)((short)r0.x > (signed char)7u)) & 1u) { t9 = ((p1 % (i0 | 1u)) >> (p1 & 31u)); z9 = (double)(((u3 % ((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)d0) | 1u))) & 255u); } if (((unsigned)((short)r0.x > (signed char)7u)) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                    g0 = (6u % (((unsigned)(short)(0x80000000u - (unsigned)((int)r0.y < (int)fuel)) << (v0 & 31u)) | 1u));
                    if ((u0 / (((unsigned)f0 - (unsigned)w0) | 1u))) break;
                    if ((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)(short)(unsigned)((unsigned)h1 == p2))) goto done;
                    while (((unsigned)e0 + (unsigned)((int)(unsigned)b0 < (int)*mp))) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((int)i2 >= (int)p1));
                        d0 = d0 * 0.5 + (double)((8u | 0x80000000u) & 1023u);
                        if (0xcac03d02u) break;
                        continue; (void)((unsigned)(0u < (*q0 >> ((unsigned)e0 & 31u))));
                    }
                    if (r0.x) break;
                }
                b0 = (m0 << ((m0 * (unsigned)e0) & 31u)) != 0u;
                v0 = ((unsigned)h1 ? (unsigned)((short)u2 > (signed char)*mp) : (0x8f374d1au + 0x96b7b30au));
                continue; (void)((unsigned)(p1 == ((unsigned)b0 * (unsigned)f0)));
            }
            w0 ^= (unsigned long long)r0.x << (((unsigned)f0 % (-(unsigned)(garr[i1 & 7u] == (unsigned)(garr[i1 & 7u] || p0)) | 1u)) & 63u);
        }
        u0 += ((unsigned)(g1 == (unsigned)(x0 >> 70)) << ((i1 >> (i0 & 31u)) & 31u));
    }
    for (;;) { if (--fuel == 0u) goto done;
        if ((u0 ? 1u : 0xffffffffu)) goto done;
        if (u3) break;
        w0 = w0 * 6364136223846793005ull + ((0x7fffffffu & 2u) & (a0[i0 & 3u] * (unsigned)(r0.x == (unsigned)w0)));
    }
    if ((a0[i0 & 3u] ^ fuel)) {
        u3 ^= (6u | (unsigned)w0);
        if ((garr[i1 & 7u] + (unsigned)s1)) goto L2;
        goto done;
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t10; double z10; if ((((unsigned)d0 * 0x80000000u)) & 1u) { t10 = (v0 ^ ((unsigned)c1 * (unsigned)b0)); z10 = (double)((((unsigned)s0 >> (a0[i0 & 3u] & 31u))) & 255u); } if ((((unsigned)d0 * 0x80000000u)) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
                if ((garr[i1 & 7u] & p2)) break;
                goto L2;
            }
            if (4u) {
                r0.x = (unsigned)((int)0xdbf94677u < (int)p2);
            }
            if ((unsigned)w0) continue;
            if ((u0 >> ((unsigned)b0 & 31u))) {
                g0 = (unsigned)((short)(unsigned)(signed char)((unsigned)(p0 || 0x80000000u) | (unsigned)s0) > (signed char)(unsigned)w0);
                if (((unsigned)f0 & garr[i1 & 7u])) break;
                h0 = (short)(0x20d2876du ^ v0);
            } else {
                if (garr[i1 & 7u]) break;
                c0 = (unsigned char)(unsigned)(0x10000u < (v0 ^ 7u));
                if (u3 == 7u) return ((unsigned)d0 ? (0x7fffffffu & a0[u1 & 3u]) : (unsigned)x0);
            }
            switch ((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)(signed char)((unsigned)(w0 >> 29) >> (p1 & 31u))) & 7u) {
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)g1 >= (int)(unsigned)h0);
                case 5u: ;
                case 2u: ;
                case 0u: ;
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 1u: ;
                    break; (void)((unsigned)(0xffffffffu < (unsigned)((int)v0 < (int)(unsigned)s1)));
                    if (0x10000u) {
                        default: ;
                        *q0 = (unsigned)(unsigned char)(unsigned)((short)0x80000000u > (signed char)(0x7fffffffu ? 9u : (unsigned)x0));
                        h1 = (unsigned short)(h1 + ((unsigned)s0 ^ 0x496ad5a5u));
                    }
                    if ((unsigned)((int)(m0 >> ((unsigned)x0 & 31u)) >= (int)(unsigned)(w0 >> 29))) continue;
                }
                switch (((unsigned)(w0 >> 29) * m0) & 7u) {
                    g1 += -((unsigned)d0 - (unsigned)b0);
                    u3 ^= (unsigned)((int)0xffffffffu >= (int)(0x10000u + g0));
                    case 2u: ;
                    c0 = (unsigned char)0xffffffffu;
                    garr[(unsigned)(signed char)(unsigned)((unsigned)h1 == (unsigned)h0) & 7u] = fuel;
                }
            }
        }
        { unsigned t11; double z11; if (((unsigned)((unsigned)c1 == u0)) & 1u) { t11 = (unsigned)b0; z11 = (double)(((unsigned)e0) & 255u); } if (((unsigned)((unsigned)c1 == u0)) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
            if (0x6abe2666u) goto L0;
            goto L0;
            d0 = d0 * 0.5 + (double)(((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)s1) - (unsigned)(*mp == 0x8a54b559u)) & 1023u);
        }
        goto done;
    }
    u2 = (unsigned)(((*mp >> (g0 & 31u)) ^ *q0) || (u0 << (p1 & 31u)));
    q0 = &garr[(unsigned)(8u || ((unsigned)(signed char)(0xce5f0566u << ((v0 >> ((unsigned)c1 & 31u)) & 31u)) / (*mp | 1u))) & 7u];
    garr[(unsigned)f0 & 7u] = ((unsigned)l0 >> (((((unsigned)(x0 >> 70) ^ (unsigned)b0) - 0xa3ecb6f2u) + (unsigned)b0) & 31u));
    do { if (--fuel == 0u) goto done;
        h0 = (short)((unsigned)((int)(unsigned)c1 < (int)i2) + -((unsigned)(fuel == (unsigned)e0) << (0x10000u & 31u)));
        if ((unsigned)((int)0u < (int)m0)) {
            continue; (void)((unsigned)(i2 && (0xac840da4u + (unsigned)s1)));
            { unsigned t12; double z12; if ((0x3f516531u) & 1u) { t12 = (unsigned)(g1 < garr[i1 & 7u]); z12 = (double)((((unsigned)s0 | *q0)) & 255u); } if ((0x3f516531u) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
                s1 = (int)((unsigned)s1 + (unsigned)!(*mp >> (m0 & 31u)));
                *q0 += (0x80000000u << ((unsigned)e0 & 31u));
                if ((unsigned)((unsigned)(p2 < g1) < (unsigned)h0)) goto L1;
                r0.x = (unsigned)l0;
            }
            u3 = u3 * 0x9e3779b1u + (garr[i1 & 7u] & (u0 & (unsigned)d0));
        } else {
            e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)(unsigned char)(unsigned)(0xea363d03u || ((unsigned)s1 << ((unsigned)w0 & 31u))) > (signed char)*mp) & 1023u);
        }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((u3 + 0x279559f6u) && 0x80000000u)) break;
            if ((r0.x % (v0 | 1u))) {
                f0 = f0 * 0.5f + (float)((2u - (unsigned)((int)(fuel >> (i2 & 31u)) < (int)p1)) & 255u);
                c0 = (unsigned char)(unsigned)(unsigned char)(unsigned)((u3 - 0xffffffffu) == 0x10000u);
                if (((unsigned)(w0 >> 29) + 0x24edc6c7u)) break;
                do { if (--fuel == 0u) goto done;
                    break; (void)((((unsigned)c1 | 0x10000u) << (*mp & 31u)));
                    break; (void)(r0.x);
                    switch (p0 & 7u) {
                        continue; (void)(0u);
                        c0 = (unsigned char)(a0[u1 & 3u] << ((u2 % ((unsigned)l0 | 1u)) & 31u));
                        a0[(unsigned)s1 & 3u] = (unsigned)((short)(unsigned)e0 > (signed char)0xffffffffu);
                        continue; (void)((a0[i0 & 3u] & (unsigned)!((unsigned)l0 ^ p0)));
                    }
                } while (i2++ < 3u && (unsigned)(0x7fffffffu < 0xa89b1360u));
                if ((unsigned)(signed char)((unsigned)(w0 >> 29) / (*q0 | 1u))) break;
                if (i2) break;
            }
            *mp = i0;
        }
        *mp = (unsigned)((unsigned)((unsigned)s1 == ((unsigned)b0 >> ((unsigned)b0 & 31u))) < (unsigned)c1);
    } while (i0++ < 7u && (unsigned)(0x7fffffffu || v0));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (r0.x & p1);
        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((int)(unsigned)(x0 >> 70) < (int)((unsigned)h0 | 0xffffffffu)) < (unsigned)s1) & 1023u);
        e0 = e0 * 0.5L + (long double)((unsigned)(r0.x || v0) & 1023u);
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)s1 == (unsigned)s0)) goto L3;
            if (((unsigned)(i2 && 0xeee273e0u) - (unsigned)c0)) {
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + -(unsigned)((a0[i0 & 3u] ? ((unsigned)d0 << ((unsigned)(w0 >> 29) & 31u)) : m0) && r0.x);
                        if ((unsigned)x0) continue;
                        if ((unsigned)((short)(unsigned)c1 > (signed char)garr[u2 & 7u])) goto done;
                        c1 = (signed char)6u;
                        break; (void)(0x10000u);
                    } while (i0++ < 5u && 0xe5dc4f4u);
                    v0 = (0x8e30585fu / (0x10000u | 1u));
                    r0.y ^= p1;
                    if (u0) break;
                }
                f0 = f0 * 0.5f + (float)(u3 & 255u);
                switch ((unsigned)((int)*mp >= (int)garr[i1 & 7u]) & 7u) {
                    case 3u: ;
                    if (r0.x) goto L1;
                    if (0x10000u) goto L3;
                    g0 = 0xc79e6d6du;
                }
                if (~(garr[u2 & 7u] & (unsigned)s0)) break;
            } else {
                if ((unsigned)(short)(0xae74d87cu / ((unsigned)((int)p2 >= (int)0xffffffffu) | 1u))) continue;
            }
        } while (i1++ < 6u && (unsigned)((int)(unsigned)w0 < (int)0x80000000u));
    }
    switch ((a0[u1 & 3u] ^ m0) & 7u) {
        case 7u: ;
        v0 = (unsigned)(signed char)((unsigned)c1 % ((unsigned)(a0[i0 & 3u] < (unsigned)((int)0x7fffffffu >= (int)(0xf9abb1b4u / ((unsigned)c0 | 1u)))) | 1u));
        while (i0++ < 2u && ((unsigned)((short)p0 > (signed char)(unsigned)c0) << (p0 & 31u))) { if (--fuel == 0u) goto done;
            case 0u: ;
            case 2u: ;
            if ((unsigned)w0) {
                case 5u: ;
                s1 = (int)((unsigned)s1 + (unsigned)d0);
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    m0 ^= (unsigned)((short)(fuel + u0) > (signed char)(unsigned)(x0 >> 70));
                    default: ;
                }
                if ((u3 * u3)) {
                    if ((unsigned)(fuel == ((unsigned)(w0 >> 29) & 0x7fffffffu))) {
                        d0 = d0 * 0.5 + (double)((v0 << ((unsigned)((0xf31bb671u * p2) == (unsigned)f0) & 31u)) & 1023u);
                        if ((0xe3f0abb0u - (unsigned)c0)) {
                            break;
                        }
                        if ((unsigned)(0x4f2c81d2u < (unsigned)e0)) goto L0;
                        g1 += u1;
                        break;
                    } else {
                        break;
                        case 6u: ;
                        l0 = (long)((unsigned long)l0 + (unsigned)(*mp && i2));
                    }
                    { unsigned t13; double z13; if ((fuel) & 1u) { t13 = garr[i1 & 7u]; z13 = (double)(((unsigned)!(v0 | (unsigned)h1)) & 255u); } if ((fuel) & 1u) { u0 += t13; d0 = d0 * 0.5 + z13; }
                        case 4u: ;
                        u3 = r0.x;
                        *mp = (0xffffffffu + 0x80000000u);
                        if ((unsigned)f0) continue;
                        break;
                    }
                    c1 = (signed char)(unsigned)(m0 == (fuel | (unsigned)b0));
                    break;
                }
                break;
                *q0 += 0xe25372b6u;
            }
            *q0 += (unsigned)((short)fuel > (signed char)0x9bed031au);
            x0 = x0 * 0x100000001b3ull + i1;
        }
    }
    d0 = d0 * 0.5 + (double)((unsigned)((unsigned)c0 < ((unsigned)x0 ? (unsigned)(short)(i1 | 0x8044b73du) : p2)) & 1023u);
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (((unsigned)h0 ^ 0xb4029e83u) & 7u) {
            break; (void)((g1 & (0xa576b765u / (g1 | 1u))));
            switch ((7u + (0x10000u / (1u | 1u))) & 7u) {
                continue; (void)(g1);
                case 1u: ;
                case 3u: ;
                case 7u: ;
            }
            x0 = x0 * 0x100000001b3ull + (u3 % (u2 | 1u));
            q0 = &garr[0x80000000u & 7u];
        }
        do { if (--fuel == 0u) goto done;
            continue; (void)((0x10000u ^ garr[i1 & 7u]));
            if ((unsigned)((int)(unsigned)((unsigned)h1 || 1u) >= (int)0xd89bcef7u)) break;
            break; (void)(((u3 ^ (unsigned)d0) * u1));
            if (6u) {
                if (((unsigned)s0 - g1)) break;
                if ((unsigned)((unsigned)w0 == ((unsigned)c1 % (r0.y | 1u)))) break;
            }
        } while (i1++ < 3u && ((g1 - (unsigned)w0) >> (i0 & 31u)));
    }
    if (((unsigned)((int)(unsigned)h0 < (int)u2) | (unsigned)x0)) {
        s0 = (int)(unsigned)((int)(unsigned)((int)-((unsigned)x0 - 0xf96bd809u) < (int)*mp) < (int)0x80000000u);
        v0 = (unsigned)(*mp < (unsigned)(w0 >> 29));
        if ((g1 * g1)) goto done;
    } else {
        if (4u) {
            if ((unsigned)((int)i1 >= (int)p2)) {
                b0 = -(*mp % (g1 | 1u)) != 0u;
            } else {
                garr[(0x8c0d996u * v0) & 7u] = (unsigned)((short)0xc67daac6u > (signed char)(m0 ^ (p2 & 0x7fffffffu)));
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((u3 + (a0[i0 & 3u] ? garr[i1 & 7u] : (unsigned)w0)) & 1023u);
                    c1 = (signed char)(unsigned)(x0 >> 70);
                }
                if ((unsigned)b0) goto L0;
            }
            if ((unsigned)s1) goto L2;
            switch (((unsigned)((unsigned)b0 || m0) * 0xffffffffu) & 7u) {
                if (fuel < 8u) return (unsigned)(8u == (unsigned)((int)(unsigned)((unsigned)c1 && u1) < (int)(unsigned)c0));
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    case 6u: ;
                }
                case 3u: ;
                break; (void)((unsigned)b0);
                if ((unsigned)!((unsigned)(w0 >> 29) >> (fuel & 31u))) goto L1;
            }
        } else {
            if ((unsigned)((int)3u < (int)0xd98316c5u)) goto L3;
        }
        w0 = w0 * 6364136223846793005ull + (((unsigned)l0 ^ (unsigned)s0) | 0xffffffffu);
    }
    s1 = (int)((unsigned)s1 + (r0.x << ((unsigned)h0 & 31u)));
    g0 = (unsigned)c0;
    goto L0;
    if (((u3 % ((unsigned)h0 | 1u)) % (p0 | 1u))) goto L1;
    for (;;) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(fuel || (unsigned)c1));
        if ((v0 ^ 0xa3a8bae1u)) {
            *q0 += (unsigned)f0;
        } else {
            l0 = (long)((unsigned long)l0 + r0.x);
            r0.x = (unsigned)s1;
            if ((unsigned)(short)((unsigned)c0 >> ((unsigned)d0 & 31u))) {
                if ((unsigned)(0xb474bcebu == (unsigned)s0)) goto L1;
                if (garr[i1 & 7u]) goto L0;
                if (-(unsigned)((int)((unsigned)(w0 >> 29) / ((unsigned)(x0 >> 70) | 1u)) >= (int)u3)) break;
            }
        }
        g1 += (unsigned)!((unsigned)!(m0 & (unsigned)(garr[i1 & 7u] < (unsigned)h0)) & u2);
        while (i1++ < 4u && (p1 | garr[u2 & 7u])) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + i0);
        }
        u3 = u3 * 0x9e3779b1u + ((u1 * 0x10000u) / ((unsigned)!(unsigned)((i1 & 0x1ee4e5c8u) || (unsigned)(w0 >> 29)) | 1u));
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (i0 + ~(i0 / (m0 | 1u)));
    }
    { unsigned t14; double z14; if (((7u / ((v0 ^ 0x64c85486u) | 1u))) & 1u) { t14 = ((unsigned)((int)0xc6ec4b3au < (int)(unsigned)h1) | (unsigned)s1); z14 = (double)((((unsigned)(short)(g0 & i0) | 0xa11adf63u)) & 255u); } if (((7u / ((v0 ^ 0x64c85486u) | 1u))) & 1u) { u1 += t14; d0 = d0 * 0.5 + z14; }
        b0 = (unsigned)(short)((unsigned)!(unsigned)((int)*q0 >= (int)5u) << (u3 & 31u)) != 0u;
        if (u0) goto L4;
        if (0xb13c1b65u) {
            { unsigned t15; double z15; if ((u2) & 1u) { t15 = (unsigned)!(unsigned)(u3 < 0xffffffffu); z15 = (double)((((unsigned)((short)v0 > (signed char)v0) & (unsigned)l0)) & 255u); } if ((u2) & 1u) { u3 += t15; d0 = d0 * 0.5 + z15; }
                goto done;
            }
            if (6u) goto done;
            garr[(garr[u2 & 7u] / (8u | 1u)) & 7u] = r0.y;
            goto L3;
            if ((unsigned)((short)(4u + 0x10000u) > (signed char)(unsigned)e0)) {
                c0 = (unsigned char)((unsigned)l0 % ((r0.y >> (p1 & 31u)) | 1u));
                b0 = (0xb7cb3261u | 1u) != 0u;
                { unsigned t16; double z16; if (((unsigned)(0xc4de97aau == u1)) & 1u) { t16 = (0x85aed81eu / (p1 | 1u)); z16 = (double)((((unsigned)e0 - (unsigned)d0)) & 255u); } if (((unsigned)(0xc4de97aau == u1)) & 1u) { u3 += t16; d0 = d0 * 0.5 + z16; }
                    goto done;
                    goto L2;
                    switch (fuel & 7u) {
                        case 5u: ;
                        u3 ^= ((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)(signed char)(8u / (0xe70cfeeau | 1u))) + (unsigned)x0);
                        q0 = &garr[((unsigned)((short)(unsigned)s0 > (signed char)(*q0 * (unsigned)l0)) | (unsigned)(u1 < g1)) & 7u];
                    }
                    if (a0[u1 & 3u]) {
                        if ((p0 % (0x7fffffffu | 1u))) goto done;
                        if ((unsigned)(0x80000000u == 0x10000u)) goto L0;
                    } else {
                        if ((unsigned)((unsigned)(0x80000000u == 0x57e5027eu) == i1)) goto L1;
                        if ((0xdef2825au + a0[u1 & 3u])) {
                            goto L4;
                            if (0x10000u) goto L2;
                            if ((unsigned)((short)0xffffffffu > (signed char)*q0)) goto L0;
                        } else {
                            if (u3 == 7u) return (p2 & (unsigned)(x0 >> 70));
                            f0 = f0 * 0.5f + (float)(((unsigned)h1 | ((unsigned)x0 * (unsigned)s1)) & 255u);
                            a0[(p2 | u3) & 3u] = (7u & (unsigned)l0);
                            if (0x10000u) goto done;
                        }
                        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                            v0 = (unsigned)(((unsigned)h1 >> (v0 & 31u)) && (unsigned)!(u2 << (fuel & 31u)));
                        }
                        if ((unsigned)((int)(unsigned)((int)(unsigned)h1 >= (int)0x10000u) < (int)i1)) goto L3;
                    }
                    if ((unsigned)((short)(0x7fffffffu >> (garr[u2 & 7u] & 31u)) > (signed char)0x10000u)) goto L3;
                    if ((unsigned)(unsigned char)((unsigned)w0 & (unsigned)(0x82eb207du < (unsigned)l0))) goto L4;
                }
                goto L0;
                { unsigned t17; double z17; if (((unsigned)h0) & 1u) { t17 = (0x10000u << (5u & 31u)); z17 = (double)((((unsigned)c0 ^ (unsigned)c1)) & 255u); } if (((unsigned)h0) & 1u) { u3 += t17; d0 = d0 * 0.5 + z17; }
                    if ((unsigned)(p0 == garr[i1 & 7u])) goto L4;
                    if ((0x4a3af9fbu ^ 0x80000000u)) goto L4;
                    if (u3 == 7u) return (unsigned)((short)g0 > (signed char)(0x80000000u ? ((unsigned)b0 / ((unsigned)d0 | 1u)) : a0[i0 & 3u]));
                }
            } else {
                if ((i1 << (fuel & 31u))) goto L4;
                if (u3) {
                    h0 = (short)0x10000u;
                }
                w0 = w0 * 6364136223846793005ull + ((unsigned)!(0xffffffffu + (unsigned)h0) * (u3 & 7u));
            }
            if (((unsigned)(x0 >> 70) & (0xd2af945u & 0x7b42529du))) goto L0;
        }
        *q0 += (unsigned)((short)(unsigned)f0 > (signed char)garr[u2 & 7u]);
        e0 = e0 * 0.5L + (long double)(9u & 1023u);
    }
    goto L2;
    if (((unsigned)l0 | fuel)) goto L3;
    if ((unsigned)l0) goto L4;
    if (r0.x) {
        if ((unsigned)((int)(unsigned)s1 < (int)0x80000000u)) goto L3;
        if (*mp) goto L1;
    } else {
        if ((fuel * u0)) goto L0;
    }
    goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            b0 = ((0xd95612f9u ^ u2) + *mp) != 0u;
            { unsigned t0; double z0; if (((unsigned)((int)(unsigned)l0 < (int)garr[i1 & 7u])) & 1u) { t0 = (4u ^ a0[i0 & 3u]); z0 = (double)(((unsigned)((int)(unsigned)w0 < (int)0x80000000u)) & 255u); } if (((unsigned)((int)(unsigned)l0 < (int)garr[i1 & 7u])) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                break; (void)(0xeedc534fu);
                if ((unsigned)e0) break;
                c0 = (unsigned char)(unsigned)((unsigned)f0 == (0x80000000u >> (-(0x8b04f6e0u / (*q0 | 1u)) & 31u)));
                if (r0.x) break;
                while (i2++ < 7u && (unsigned)((int)g0 >= (int)(unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                    { unsigned t1; double z1; if (((v0 >> ((unsigned)((int)r0.y >= (int)p1) & 31u))) & 1u) { t1 = p1; z1 = (double)(((unsigned)((m0 - 0x10000u) && (unsigned)f0)) & 255u); } if (((v0 >> ((unsigned)((int)r0.y >= (int)p1) & 31u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                        u1 = u1 * 0x9e3779b1u + 0u;
                        break; (void)(p1);
                    }
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(g1 | 0xa5a214a0u) < (int)m0), (unsigned)(unsigned char)(unsigned)((unsigned)(unsigned char)((unsigned)s1 % (u3 | 1u)) == (unsigned)h0), ((unsigned)s0 >> ((i0 / (0x464cabb4u | 1u)) & 31u))); }
            }
            if ((1u | (unsigned)((short)g0 > (signed char)a0[u1 & 3u]))) break;
            w0 = w0 * 6364136223846793005ull + (0xd13d0e5eu ? (unsigned)f0 : (~(4u - 0x80000000u) % (0x6498b409u | 1u)));
            { unsigned t2; double z2; if ((((u2 % (garr[i1 & 7u] | 1u)) & 0x54e015b2u)) & 1u) { t2 = (unsigned)(i1 < (unsigned)h0); z2 = (double)(((unsigned)((int)9u < (int)v0)) & 255u); } if ((((u2 % (garr[i1 & 7u] | 1u)) & 0x54e015b2u)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                f0 = f0 * 0.5f + (float)(u1 & 255u);
                switch (((unsigned)x0 >> ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x269c95dcu) & 31u)) & 7u) {
                    r0.x = (((unsigned)(p0 && 8u) >> ((unsigned)(short)(unsigned)(0x275bef87u || (unsigned)b0) & 31u)) | (unsigned)e0);
                    if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, (unsigned)(w0 >> 29), (unsigned)((garr[u2 & 7u] << (0x74693119u & 31u)) || v0)); }
                    L0: if (--fuel == 0u) goto done;
                    if (0x80000000u) break;
                    if ((fuel - (unsigned)c0)) {
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)(unsigned)(0x25ce1ab9u == m0), (unsigned)l0, 5u); }
                        L1: if (--fuel == 0u) goto done;
                        u2 = ((a0[u1 & 3u] & (u1 & (unsigned)b0)) / (2u | 1u));
                    } else {
                        if (budget != 0u) { budget -= 1u; u3 = fn0(p0, (i1 << (u0 & 31u)), (unsigned)(short)(unsigned)((short)0x21b65310u > (signed char)(unsigned)x0)); }
                        *q0 = 0xb12b62au;
                        g1 += (unsigned)(7u || 0x80000000u);
                    }
                }
                { unsigned t3; double z3; if (((unsigned)((r0.y ^ a0[u1 & 3u]) || (unsigned)h0)) & 1u) { t3 = 4u; z3 = (double)(((unsigned)x0) & 255u); } if (((unsigned)((r0.y ^ a0[u1 & 3u]) || (unsigned)h0)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    break; (void)(r0.x);
                }
                garr[0x80000000u & 7u] = (unsigned)(unsigned char)(unsigned)((int)u0 >= (int)i1);
                s0 = (int)(unsigned)(8u || (unsigned)(w0 >> 29));
            }
            x0 = x0 * 0x100000001b3ull + (unsigned)(0x80000000u < (unsigned)((unsigned)(u2 && i1) < i0));
        }
        m0 ^= (unsigned)((unsigned)((int)0x10000u >= (int)-(unsigned)(1u && m0)) < p2);
        s0 = (int)(unsigned)(fuel < ((p1 << (u2 & 31u)) * (unsigned)w0));
    } while (i0++ < 6u && 0xf23ade4bu);
    e0 = e0 * 0.5L + (long double)((v0 + r0.y) & 1023u);
    goto L1;
    if (p2) goto L3;
    L2: if (--fuel == 0u) goto done;
    { unsigned t4; double z4; if (((0x10000u ? (unsigned)h0 : 0xe974f191u)) & 1u) { t4 = (unsigned)c0; z4 = (double)((p0) & 255u); } if (((0x10000u ? (unsigned)h0 : 0xe974f191u)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        do { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)((0xffffffffu - 0x7fffffffu) || garr[i1 & 7u]) & 1023u);
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((5u - 0x9763a4f4u) && (unsigned)c0), (garr[i1 & 7u] >> ((unsigned)s1 & 31u)), ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x80e6d8bu) << ((unsigned)c0 & 31u))); }
                if (g1) break;
                f0 = f0 * 0.5f + (float)(((unsigned)h0 | (unsigned)h1) & 255u);
                h1 = (unsigned short)(h1 + (unsigned)(0x7fffffffu == 6u));
            }
        } while (i0++ < 5u && (unsigned)(0xdbe6cd68u < g1));
    }
    if ((unsigned)(x0 >> 70)) goto L1;
    if (i0) {
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((-(g0 - 0u) - (unsigned)((short)4u > (signed char)1u)) & 1023u);
            do { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)w0;
                r0.y ^= (unsigned)!(~(unsigned)((int)garr[u2 & 7u] >= (int)m0) - (unsigned)e0);
                if (fuel < 8u) return (v0 ^ (unsigned)h1);
                if (budget != 0u) { budget -= 1u; u1 = fn0((0x14019e88u & (unsigned)(x0 >> 70)), (unsigned)(signed char)(4u + 7u), g0); }
            } while (i1++ < 5u && (unsigned)(r0.y || (unsigned)((unsigned)f0 || r0.y)));
            { unsigned t5; double z5; if (((i0 / ((unsigned)(i2 < (unsigned)f0) | 1u))) & 1u) { t5 = ((unsigned)d0 << ((unsigned)(1u || (unsigned)l0) & 31u)); z5 = (double)(((unsigned)((int)(unsigned)(short)((unsigned)d0 - (unsigned)(w0 >> 29)) < (int)0xe55e3f55u)) & 255u); } if (((i0 / ((unsigned)(i2 < (unsigned)f0) | 1u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                if ((9u ? (unsigned)x0 : (unsigned)d0)) break;
                if (budget != 0u) { budget -= 1u; u2 = fn0((u1 + (unsigned)l0), ((unsigned)h1 | (unsigned)(short)(garr[u2 & 7u] & u0)), garr[i1 & 7u]); }
                c0 = (unsigned char)(unsigned)(p2 && (unsigned)(short)(((unsigned)c1 * (unsigned)(x0 >> 70)) * garr[i1 & 7u]));
                if (0x80000000u) goto L0;
                break; (void)(m0);
                L3: if (--fuel == 0u) goto done;
            }
            s0 = (int)(unsigned)((p2 ? 4u : 0xf13ef2bcu) && 0x10000u);
        }
        if ((0xffffffffu + 3u)) goto L4;
    }
    if ((unsigned)(i1 < (unsigned)b0)) {
        goto done;
        switch (((unsigned)h1 << (i1 & 31u)) & 7u) {
            if (u3 == 7u) return ((unsigned)d0 % ((unsigned)((unsigned)x0 == 0x64fabe2cu) | 1u));
            if (budget != 0u) { budget -= 1u; u0 = fn0(p1, 0xcfaede90u, r0.x); }
            L4: if (--fuel == 0u) goto done;
        }
        if ((unsigned)((short)r0.x > (signed char)(unsigned)!(unsigned)((int)a0[i0 & 3u] < (int)g1))) goto L3;
        if (~(fuel | u3)) goto L4;
    } else {
        goto L4;
        x0 = x0 * 0x100000001b3ull + (unsigned)((int)0x11a61703u < (int)(unsigned)((0x7fffffffu - 0x20eb1e71u) || (unsigned)b0));
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(0xffffffffu < 6u) < (3u + a0[i0 & 3u])));
    }
    do { if (--fuel == 0u) goto done;
        while (i1++ < 2u && (unsigned)((unsigned)(signed char)(0x10000u + u0) == (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((unsigned)(unsigned char)(unsigned)((short)(unsigned)b0 > (signed char)(p1 >> (0x80000000u & 31u))) - (r0.x | (unsigned)b0)) & 1023u);
            break; (void)(-(unsigned)((short)0xf6753250u > (signed char)g1));
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                u2 = ((unsigned)((short)0x80000000u > (signed char)0xffffffffu) % ((unsigned)(u1 || v0) | 1u));
            }
        }
        if ((unsigned)((r0.x >> ((unsigned)h1 & 31u)) && (unsigned)b0)) break;
        if (u1) continue;
        switch (4u & 7u) {
            g0 = (unsigned)((int)9u < (int)(3u % ((g0 + 0x10000u) | 1u)));
            case 4u: ;
            break; (void)((0u - (unsigned)(short)(garr[i1 & 7u] | 1u)));
            g1 += (unsigned)((unsigned)(signed char)(unsigned)((unsigned)(a0[i0 & 3u] == (unsigned)((int)9u < (int)(unsigned)(x0 >> 70))) || 0u) < p2);
            case 1u: ;
        }
        e0 = e0 * 0.5L + (long double)((unsigned)((short)(0xb9914365u ^ u0) > (signed char)8u) & 1023u);
    } while (i0++ < 3u && (unsigned)(~(r0.x & (unsigned)f0) || 8u));
    h0 = (short)0x10000u;
    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)h1 - (unsigned)((int)a0[u1 & 3u] < (int)0xffffffffu)), r0.x, 0xffffffffu); }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((garr[i1 & 7u] / (4u | 1u)) >> (0x486ecd21u & 31u))) {
            if (budget != 0u) { budget -= 1u; u2 = fn0((i1 | (unsigned)(garr[u2 & 7u] || u3)), 2u, (unsigned)!(garr[i1 & 7u] / ((unsigned)b0 | 1u))); }
            l0 = (long)((unsigned long)l0 + (i1 / ((unsigned)s1 | 1u)));
            m0 ^= (((unsigned)w0 - (unsigned)(w0 >> 29)) >> ((unsigned)((short)p0 > (signed char)u2) & 31u));
            r0.x = (unsigned)((int)(u0 * (3u ^ g1)) >= (int)0x80000000u);
        } else {
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                garr[(unsigned)((unsigned)b0 || r0.y) & 7u] = ((unsigned)(unsigned char)(unsigned)((int)0xf10f71a1u < (int)(unsigned)(signed char)(unsigned)((int)r0.x >= (int)(0x5c4a77a1u >> (0u & 31u)))) - 0x80000000u);
                q0 = &garr[(unsigned)(5u < (u2 << ((unsigned)(a0[u1 & 3u] == (unsigned)w0) & 31u))) & 7u];
                w0 = w0 * 6364136223846793005ull + (0xd59ebd76u % ((unsigned)d0 | 1u));
                if (a0[u1 & 3u]) continue;
            }
            if ((unsigned)((unsigned)(x0 >> 70) == r0.y)) {
                for (;;) { if (--fuel == 0u) goto done;
                    *q0 = (unsigned)((short)0xffffffffu > (signed char)(unsigned)(unsigned char)(unsigned)(0x80000000u && 5u));
                    f0 = f0 * 0.5f + (float)(g0 & 255u);
                    break; (void)(v0);
                    h0 = (short)(unsigned)((unsigned)h1 || (unsigned)x0);
                    if ((unsigned)x0) break;
                    q0 = &garr[((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)s1) | (unsigned)((short)garr[u2 & 7u] > (signed char)0xffffffffu)) & 7u];
                }
                s0 = (int)p2;
                r0.x = ((unsigned)s0 / ((unsigned)((unsigned)((unsigned)e0 || g0) && (unsigned)x0) | 1u));
                if ((unsigned)!(((unsigned)h0 - (unsigned)s1) & i1)) break;
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)s1 >> ((unsigned)((unsigned)l0 == 0xffffffffu) & 31u))) goto L4;
                    u1 = (unsigned)((int)((u2 * a0[i0 & 3u]) / (0x80000000u | 1u)) < (int)(8u + *q0));
                    v0 = garr[i1 & 7u];
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0x8696e312u == (unsigned)((int)(unsigned)h0 < (int)0x10000u)), ((unsigned)(unsigned char)(*mp ^ i0) - 7u), -(7u ^ u1)); }
            } else {
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)b0) continue;
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(0x6fd5f5b3u, (unsigned)(u1 < (0x2c7df99au - i2)), (g1 | (unsigned)h0)); }
                    }
                    q0 = &garr[(unsigned)((*q0 | (unsigned)(w0 >> 29)) || ((unsigned)(0xffffffffu == 8u) - (unsigned)s1)) & 7u];
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        q0 = &garr[(unsigned)((int)(unsigned)(x0 >> 70) >= (int)((u0 | -(unsigned)(fuel == i0)) ^ 0xfece944bu)) & 7u];
                        garr[(unsigned)((int)fuel < (int)(unsigned)b0) & 7u] = ((unsigned)h1 - u2);
                    }
                }
                break; (void)((unsigned)(short)(unsigned)(3u == (unsigned)((int)(unsigned)c1 < (int)9u)));
            }
        }
        break; (void)(i2);
    }
    { unsigned t6; double z6; if ((garr[u2 & 7u]) & 1u) { t6 = 3u; z6 = (double)((i0) & 255u); } if ((garr[u2 & 7u]) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(w0 >> 29), (unsigned)!(unsigned)((int)(r0.y * a0[i0 & 3u]) < (int)i1), ((unsigned)l0 * (unsigned)w0)); }
        if (fuel < 8u) return i2;
        goto L1;
    }
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            a0[((unsigned)s0 ^ r0.y) & 3u] = (0x7fffffffu - (unsigned)((int)(unsigned)(short)((unsigned)s1 | 9u) >= (int)(*mp | r0.x)));
            goto L4;
        } while (i1++ < 7u && (unsigned)(signed char)(unsigned)((int)r0.x >= (int)(unsigned)((short)0xc7853a02u > (signed char)i1)));
        g0 = 0x10000u;
        break; (void)((unsigned)(g0 && garr[i1 & 7u]));
        switch ((unsigned)!(u0 * (unsigned)(short)(0x34f7538bu >> ((unsigned)s1 & 31u))) & 7u) {
            r0.x = ((g0 & (unsigned)s0) - (r0.y | (unsigned)s1));
            c1 = (signed char)((u0 << (p2 & 31u)) + 0x97977903u);
            r0.x = ((unsigned)((2u & garr[i1 & 7u]) == g0) * p2);
            case 0u: ;
        }
    } while (i0++ < 5u && ((unsigned)(*mp && 0x10000u) << (9u & 31u)));
    if (6u) {
        if ((unsigned)!(unsigned)(((unsigned)s1 | (unsigned)f0) || 0xcbd82b34u)) {
            if (budget != 0u) { budget -= 1u; u0 = fn0(0x18882b71u, (unsigned)((unsigned)h0 == 0x80000000u), (unsigned)((unsigned)b0 < ~(u3 << ((unsigned)(w0 >> 29) & 31u)))); }
            garr[(unsigned)l0 & 7u] = ((a0[u1 & 3u] >> (i1 & 31u)) / ((unsigned)l0 | 1u));
            switch ((unsigned)(garr[u2 & 7u] && u0) & 7u) {
                if ((unsigned)((int)p1 >= (int)p0)) {
                    if ((unsigned)(0x5c11a0c5u == (unsigned)c0)) {
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((m0 << (u2 & 31u)) ^ (unsigned)c1), (unsigned)(short)((unsigned)c1 ^ a0[u1 & 3u]), (u1 + m0)); }
                        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(unsigned char)(unsigned)((unsigned)c0 < m0) & 4u), i2, 0x80000000u); }
                        c0 = (unsigned char)((unsigned)f0 % (i1 | 1u));
                        s1 = (int)((unsigned)s1 + i2);
                        h1 = (unsigned short)(h1 + ((unsigned)e0 >> (((unsigned)e0 % ((unsigned)s1 | 1u)) & 31u)));
                        case 1u: ;
                    } else {
                        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                            case 2u: ;
                            c0 = (unsigned char)(unsigned)(*q0 && *mp);
                            case 6u: ;
                            case 0u: ;
                            g0 = (i2 & (unsigned)d0);
                            x0 = x0 * 0x100000001b3ull + ((unsigned)x0 >> (((unsigned)((int)0x7544ac83u >= (int)(unsigned)(garr[u2 & 7u] && i0)) + 0x80000000u) & 31u));
                        }
                        l0 = (long)((unsigned long)l0 + ((unsigned)((int)g0 >= (int)~(unsigned)((unsigned)(w0 >> 29) || p2)) - 0xbb63620bu));
                        v0 = ((*mp - 0x10000u) << ((unsigned)(unsigned char)(unsigned)(0x288c61acu < (0xaf6bdf47u >> (*q0 & 31u))) & 31u));
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)x0 < (unsigned)c0), (u0 | (unsigned)((unsigned)e0 && fuel)), i0); }
                    }
                    { unsigned t7; double z7; if ((0u) & 1u) { t7 = (unsigned)(short)(unsigned)((short)m0 > (signed char)0u); z7 = (double)(((*q0 * i1)) & 255u); } if ((0u) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                        if (0x10000u) break;
                        h0 = (short)(unsigned)(unsigned char)(unsigned)((unsigned)(garr[u2 & 7u] && a0[u1 & 3u]) || p1);
                        switch ((0x10000u << ((unsigned)e0 & 31u)) & 7u) {
                            s0 = (int)((unsigned)s1 * (unsigned)((unsigned)(short)(0xb885ac1au >> ((unsigned)(x0 >> 70) & 31u)) || 0xffffffffu));
                        }
                        break; (void)(((unsigned)c0 << (p0 & 31u)));
                        default: ;
                        if ((7u | 0xbcb78368u)) break;
                    }
                    u3 += *q0;
                    break;
                    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((p1 >> (0x7fffffffu & 31u)) || g1)) continue;
                        x0 = x0 * 0x100000001b3ull + (u2 ^ ~(unsigned)((int)4u >= (int)u0));
                        m0 ^= (*q0 + 0x154f38abu);
                        r0.y ^= (unsigned)((unsigned)(w0 >> 29) == (unsigned)((int)(unsigned)((unsigned)b0 == 0x7fffffffu) < (int)(0x723bcf01u | v0)));
                        if ((g1 >> (p0 & 31u))) continue;
                        if (((unsigned)c0 ? g1 : 8u)) goto L0;
                    }
                    c1 = (signed char)g1;
                } else {
                    while (i0++ < 7u && (unsigned)(unsigned char)(unsigned)((int)i2 >= (int)6u)) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)((0x7fffffffu % ((unsigned)e0 | 1u)) ? (unsigned)c1 : ((unsigned)h1 & u3));
                    }
                }
                h1 = (unsigned short)(h1 + 7u);
                goto L3;
                *mp = (((unsigned)!(0x80000000u + v0) + (unsigned)h0) | (unsigned)l0);
                h1 = (unsigned short)(h1 + (r0.y / (u2 | 1u)));
            }
        }
        if ((unsigned)c1) goto done;
        m0 ^= m0;
        x0 = x0 * 0x100000001b3ull + (unsigned)((short)((fuel + (unsigned)(x0 >> 70)) | u0) > (signed char)(unsigned)((int)2u < (int)0xffffffffu));
    }
    x0 = x0 * 0x100000001b3ull + r0.x;
    if (((unsigned)w0 & ((unsigned)l0 << (1u & 31u)))) goto L2;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)((unsigned)d0 == (unsigned)d0);
        { unsigned t8; double z8; if ((((unsigned)x0 >> (a0[u1 & 3u] & 31u))) & 1u) { t8 = v0; z8 = (double)(((unsigned)((unsigned)(w0 >> 29) < 4u)) & 255u); } if ((((unsigned)x0 >> (a0[u1 & 3u] & 31u))) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
            i0 = (unsigned)((unsigned)(((unsigned)(x0 >> 70) / (8u | 1u)) < g0) || i2) & 15u;
            { unsigned t9; double z9; if (((0x10000u ? (unsigned)c1 : (unsigned)s1)) & 1u) { t9 = r0.x; z9 = (double)(((unsigned)(short)((unsigned)e0 * 3u)) & 255u); } if (((0x10000u ? (unsigned)c1 : (unsigned)s1)) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                { unsigned t10; double z10; if (((unsigned)(fuel == i0)) & 1u) { t10 = (fuel << (0x80000000u & 31u)); z10 = (double)(((unsigned)(unsigned char)(0xd15889c7u ^ (unsigned)((unsigned)h1 == p1))) & 255u); } if (((unsigned)(fuel == i0)) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                    c1 = (signed char)(*mp & (unsigned)(g1 && (a0[i0 & 3u] % (0x7fffffffu | 1u))));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)b0 >= (int)(garr[i1 & 7u] ^ 0xff2c6865u)), (unsigned)s0, 0xd39089e3u); }
                    g0 = p2;
                    if ((unsigned)((int)u3 < (int)u1)) {
                        if ((u1 * (unsigned)s1)) break;
                        e0 = e0 * 0.5L + (long double)(5u & 1023u);
                    } else {
                        if ((unsigned)((int)v0 >= (int)0x80000000u)) goto L2;
                        *q0 += (unsigned)(p0 || (unsigned)!(*q0 + (0xb5853b61u ^ fuel)));
                    }
                    break; (void)((unsigned)c0);
                }
                a0[u2 & 3u] = ((unsigned)((unsigned)s1 == v0) ? m0 : a0[u1 & 3u]);
                if (0x10000u) goto L3;
            }
        }
        g1 += (p2 / ((unsigned)((int)(unsigned)((short)(unsigned)e0 > (signed char)garr[u2 & 7u]) < (int)p1) | 1u));
        if (3u) continue;
        x0 = x0 * 0x100000001b3ull + (unsigned)(w0 >> 29);
        while (i1++ < 6u && 8u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((g1 & (unsigned)s0) + i0), ((unsigned)(w0 >> 29) >> (p0 & 31u)), garr[i1 & 7u]); }
        }
    }
    if ((unsigned)((int)8u < (int)((unsigned)(w0 >> 29) << (0x682d2c9fu & 31u)))) goto L1;
    goto L4;
    if (r0.x) goto done;
    x0 = x0 * 0x100000001b3ull + (r0.y + (unsigned)(g1 == (fuel ? r0.y : a0[u1 & 3u])));
    r0.y ^= ((unsigned)d0 >> (5u & 31u));
    *mp = 3u;
    if ((unsigned)(a0[i0 & 3u] && (unsigned)((int)fuel >= (int)u0))) goto L1;
    if (u2) goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    m0 ^= ((unsigned)d0 << (0x80000000u & 31u));
    { unsigned t0; double z0; if (((unsigned)((int)0x80000000u >= (int)(unsigned)c1)) & 1u) { t0 = (unsigned)(0x7fffffffu || (unsigned)c1); z0 = (double)(((unsigned)(((unsigned)e0 << (2u & 31u)) == g1)) & 255u); } if (((unsigned)((int)0x80000000u >= (int)(unsigned)c1)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if (budget != 0u) { budget -= 1u; u1 = fn0(((i0 + *mp) % (g0 | 1u)), (unsigned)h1, (unsigned)(((unsigned)f0 - *mp) && p0)); }
        u2 = 3u;
        L0: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0(0xffffffffu, (0x80000000u & 6u), 0x7fffffffu); }
        L1: if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + g0);
    }
    goto L2;
    s1 = (int)((unsigned)s1 + (0xe659b6fdu / ((unsigned)e0 | 1u)));
    switch (~(m0 & (unsigned)(unsigned char)(a0[i0 & 3u] * v0)) & 7u) {
        case 5u: ;
        default: ;
        if ((i1 + (unsigned)b0)) break;
        case 1u: ;
        if (*mp) {
            q0 = &garr[~(((unsigned)((int)0xddd72d99u >= (int)7u) - a0[u1 & 3u]) & (0x10000u - 0xffffffffu)) & 7u];
            l0 = (long)((unsigned long)l0 + (unsigned)b0);
            u0 ^= (0x78d778d3u / (((unsigned)(3u == r0.y) << (garr[u2 & 7u] & 31u)) | 1u));
            g1 += (unsigned)s1;
        }
        u1 += (r0.y * 0xb036c6b5u);
    }
    b0 = (unsigned)!(unsigned)((unsigned)((int)(unsigned)e0 < (int)(unsigned)x0) || a0[u1 & 3u]) != 0u;
    goto L0;
    garr[(unsigned)h0 & 7u] = 0xffffffffu;
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)s1 == 0xba432d90u), ((*mp * fuel) | (unsigned)c0), ((unsigned)b0 | p0)); }
    goto done;
    L2: if (--fuel == 0u) goto done;
    if ((0u | (unsigned)d0)) {
        if ((unsigned)((int)2u < (int)(unsigned)f0)) goto L0;
        if ((0u + 0u)) goto L2;
    } else {
        if ((garr[u2 & 7u] << ((0x4d516564u & 0xad8078b8u) & 31u))) {
            if (i1) goto L4;
            x0 = x0 * 0x100000001b3ull + ((0xaf6ed556u ? 9u : r0.y) - (unsigned)s1);
            { unsigned t1; double z1; if (((r0.y % ((unsigned)((unsigned)c1 && fuel) | 1u))) & 1u) { t1 = (unsigned)(signed char)((unsigned)h0 & ((unsigned)d0 % (5u | 1u))); z1 = (double)((((unsigned)c1 / ((unsigned)(*q0 == *mp) | 1u))) & 255u); } if (((r0.y % ((unsigned)((unsigned)c1 && fuel) | 1u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)d0 / ((unsigned)c1 | 1u)) < (int)((*q0 % (garr[i1 & 7u] | 1u)) | (unsigned)c1)));
                if (budget != 0u) { budget -= 1u; u1 = fn1((g0 & 0x298a90f5u), r0.x, (unsigned)(0xffffffffu < (g0 / (u0 | 1u)))); }
                { unsigned t2; double z2; if ((v0) & 1u) { t2 = 0x7fffffffu; z2 = (double)(((0x574018c1u | (0xe9e02035u * (unsigned)l0))) & 255u); } if ((v0) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    v0 = ((2u | 0xf5fa0413u) >> ((unsigned)((int)(unsigned)d0 < (int)(unsigned)h1) & 31u));
                }
                goto L2;
            }
            L3: if (--fuel == 0u) goto done;
        } else {
            *q0 = (unsigned)(i2 || ((unsigned)f0 - (unsigned)b0));
            while (i0++ < 2u && ((unsigned)s0 << ((unsigned)(unsigned char)(unsigned)((int)0x7fffffffu < (int)0x8b0eda64u) & 31u))) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)(short)(i1 | p0) << ((unsigned)(r0.y < 0x80000000u) & 63u);
                i1 = (unsigned)((int)g1 >= (int)garr[i1 & 7u]) & 15u;
                { unsigned t3; double z3; if ((((0xffffffffu + 0xb217fd84u) + (unsigned)(w0 >> 29))) & 1u) { t3 = r0.y; z3 = (double)((((unsigned)x0 / (g1 | 1u))) & 255u); } if ((((0xffffffffu + 0xb217fd84u) + (unsigned)(w0 >> 29))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    *mp = ((unsigned)((int)(unsigned)h0 < (int)(unsigned)s1) >> ((unsigned)((unsigned)h1 == (unsigned)h1) & 31u));
                    a0[9u & 3u] = v0;
                }
            }
            f0 = f0 * 0.5f + (float)(((g1 * u1) % (0x10000u | 1u)) & 255u);
            L4: if (--fuel == 0u) goto done;
        }
        if (u3 == 7u) return ((unsigned)(x0 >> 70) + ((unsigned)((int)(unsigned)(x0 >> 70) < (int)a0[i0 & 3u]) + 0x4ed5ea20u));
        if ((unsigned)(unsigned char)(~((unsigned)h1 << ((unsigned)x0 & 31u)) % (g1 | 1u))) {
            w0 ^= (unsigned long long)(unsigned)e0 << (((unsigned)w0 | (u3 - (r0.x / ((unsigned)(0x1bb1cf60u && garr[i1 & 7u]) | 1u)))) & 63u);
            goto L0;
            while (p1) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)d0 < (int)r0.x)) break;
                if ((i2 / ((0x37cde54au | 0x7fffffffu) | 1u))) {
                    if ((unsigned)((unsigned)b0 && 0x95b77004u)) break;
                    if ((i1 / (i1 | 1u))) break;
                    d0 = d0 * 0.5 + (double)((unsigned)((fuel / (0xffffffffu | 1u)) || (unsigned)((short)garr[i1 & 7u] > (signed char)r0.x)) & 1023u);
                }
                if (*q0) break;
                break; (void)(0x10000u);
            }
            g0 = garr[u2 & 7u];
            if ((0x85c343b2u & (unsigned)h0)) {
                if (0x10000u) {
                    if ((unsigned)h0) goto L2;
                    if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)d0 + i2), (((unsigned)s0 << (r0.x & 31u)) % (fuel | 1u)), 0x10000u); }
                    if (budget != 0u) { budget -= 1u; u1 = fn1((i1 >> (0xab5a755bu & 31u)), ((unsigned)c0 ? (unsigned)b0 : *q0), 0x10000u); }
                    { unsigned t4; double z4; if (((4u - r0.x)) & 1u) { t4 = (unsigned)(v0 || (fuel >> (4u & 31u))); z4 = (double)(((garr[i1 & 7u] / ((*q0 * 0x10000u) | 1u))) & 255u); } if (((4u - r0.x)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                        if ((unsigned)((int)r0.y >= (int)(unsigned)s0)) goto done;
                        g1 += ((unsigned)(short)(garr[u2 & 7u] - (unsigned)h0) - (unsigned)h0);
                        if (v0) goto L1;
                        if ((9u ? 6u : (unsigned)s0)) goto L1;
                        if (-(unsigned)(m0 < (unsigned)s1)) goto L0;
                    }
                }
                r0.x = (1u >> ((i1 >> ((unsigned)w0 & 31u)) & 31u));
                goto L3;
            }
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(x0 >> 70) || (unsigned)l0) & 255u);
        }
        goto L1;
    }
    g1 += (unsigned)(8u || r0.y);
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0((a0[u1 & 3u] >> (r0.x & 31u)), (unsigned)((short)i2 > (signed char)0x7fffffffu), (unsigned)l0); }
        if ((0x10000u >> (u2 & 31u))) goto L3;
        { unsigned t5; double z5; if ((*mp) & 1u) { t5 = (unsigned)(0xb16cdf9au < 0x9499d115u); z5 = (double)(((unsigned)(unsigned char)((p2 + 0xffffffffu) & (unsigned)c1)) & 255u); } if ((*mp) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((r0.y ^ 1u)) break;
                    { unsigned t6; double z6; if ((*mp) & 1u) { t6 = (unsigned)((int)(unsigned)((unsigned)(x0 >> 70) < u1) >= (int)(unsigned)(x0 >> 70)); z6 = (double)(((unsigned)s0) & 255u); } if ((*mp) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                        d0 = d0 * 0.5 + (double)((unsigned)(p2 == (g1 | g1)) & 1023u);
                    }
                    while (i0++ < 3u && (r0.y >> ((unsigned)f0 & 31u))) { if (--fuel == 0u) goto done;
                        u3 = u3 * 0x9e3779b1u + (0x10000u << (g1 & 31u));
                        i0 = ((p2 % (i1 | 1u)) * ((u1 / (a0[u1 & 3u] | 1u)) << (u1 & 31u))) & 15u;
                        garr[(unsigned)!(a0[u1 & 3u] >> ((unsigned)(w0 >> 29) & 31u)) & 7u] = (unsigned)(short)(i1 & (u3 % ((unsigned)e0 | 1u)));
                        break; (void)((g0 ^ m0));
                        for (;;) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)c1 * (unsigned)s0), (unsigned)((short)0x75ced200u > (signed char)*mp), (p2 % (*q0 | 1u))); }
                            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)e0 >> (((unsigned)x0 - *q0) & 31u)), (unsigned)((unsigned)s1 < 0x902a23b0u), (0x10000u + (unsigned)c1)); }
                        }
                        h1 = (unsigned short)(h1 + (unsigned)(x0 >> 70));
                    }
                    u3 ^= (unsigned)((int)(unsigned)f0 >= (int)(unsigned)(w0 >> 29));
                    u1 += ((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)e0) + ((unsigned)e0 % (6u | 1u)));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn1((0x10000u | u1), (v0 & (unsigned)((int)(unsigned)h1 >= (int)6u)), g0); }
                q0 = &garr[~(unsigned)((int)((unsigned)s1 & fuel) < (int)0x9cea2e3cu) & 7u];
            }
        }
        v0 = ((unsigned)((u2 * (unsigned)((int)0xb22741aau >= (int)(unsigned)s0)) && garr[i1 & 7u]) & g0);
        *q0 = ((0xd0f67b99u * (unsigned)(short)(u2 << (r0.y & 31u))) * r0.y);
    }
    if (((unsigned)((short)a0[i0 & 3u] > (signed char)0x7fffffffu) / (garr[u2 & 7u] | 1u))) goto done;
    do { if (--fuel == 0u) goto done;
        garr[((unsigned)w0 >> (a0[u1 & 3u] & 31u)) & 7u] = (u0 * r0.x);
        u2 += (garr[u2 & 7u] << (((unsigned)c0 ? 0xb141dc47u : 9u) & 31u));
        m0 ^= u2;
    } while (i0++ < 5u && (unsigned)((int)0x7fffffffu < (int)1u));
    switch ((unsigned)(short)((unsigned)s0 ? p2 : u2) & 7u) {
        u0 = (0x3518dfb1u >> (-(6u - 0x93505c0cu) & 31u));
        { unsigned t7; double z7; if ((((unsigned)w0 - p0)) & 1u) { t7 = g1; z7 = (double)(((unsigned)(w0 >> 29)) & 255u); } if ((((unsigned)w0 - p0)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
            break; (void)(a0[i0 & 3u]);
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)!((unsigned)c1 | i0), (unsigned)!((unsigned)(a0[u1 & 3u] < 0xd1acc82cu) << (p2 & 31u)), (unsigned)!((unsigned)b0 % (0x80000000u | 1u))); }
            if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)h1 >> ((unsigned)((short)fuel > (signed char)u1) & 31u)), (unsigned)((short)i0 > (signed char)g0), v0); }
            case 4u: ;
            if ((0x67d01375u / (a0[i0 & 3u] | 1u))) goto L4;
        }
        case 7u: ;
    }
    s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)((p1 + r0.x) << (((unsigned)h1 % (5u | 1u)) & 31u)));
    do { if (--fuel == 0u) goto done;
        if (a0[u1 & 3u]) {
            w0 ^= (unsigned long long)garr[u2 & 7u] << ((i1 & (g0 - 0xffffffffu)) & 63u);
        }
        if ((unsigned)(unsigned char)(0u % ((0xffffffffu / (0x7fffffffu | 1u)) | 1u))) break;
    } while (i0++ < 7u && (unsigned)(short)((i2 * (unsigned)(w0 >> 29)) & 0xdee2cfa2u));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 += (i2 ? 0x7fffffffu : p0);
        if (budget != 0u) { budget -= 1u; u3 = fn1(i0, ((unsigned)h0 ^ (unsigned)s1), 0x72d41106u); }
    }
    while ((unsigned)(7u == *mp)) { if (--fuel == 0u) goto done;
        { unsigned t8; double z8; if (((0x5b0217a0u * (unsigned)b0)) & 1u) { t8 = (0xdbf3b64au ? *mp : garr[i1 & 7u]); z8 = (double)((a0[i0 & 3u]) & 255u); } if (((0x5b0217a0u * (unsigned)b0)) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
            u3 ^= -(i1 * (0x1e9c7fdbu & ((unsigned)h0 & a0[u1 & 3u])));
        }
        if (p0) {
            u0 = (unsigned)((0x10000u + (garr[u2 & 7u] >> ((unsigned)f0 & 31u))) < (unsigned)x0);
            w0 ^= (unsigned long long)0x2011e1bdu << ((i1 - 0xffffffffu) & 63u);
            break; (void)(1u);
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0((*q0 ^ -(unsigned)((short)p1 > (signed char)1u)), (unsigned)((short)(unsigned)l0 > (signed char)v0), u1); }
        if ((i2 * (r0.y - (unsigned)f0))) goto L1;
        if (-(0x10000u | 4u)) break;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(a0[i0 & 3u] && (unsigned)h1), p1, 0xb3cc718eu); }
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= (unsigned)((unsigned)(0x7fffffffu < (unsigned)c0) || u2);
        do { if (--fuel == 0u) goto done;
            a0[(unsigned)((short)i0 > (signed char)a0[u1 & 3u]) & 3u] = (unsigned)((9u & ~((unsigned)(0x7fffffffu == g0) % (0x7fffffffu | 1u))) || i1);
        } while (i1++ < 5u && (u0 ? v0 : 0xd46ac2aau));
        if (((unsigned)c0 >> ((unsigned)e0 & 31u))) break;
        do { if (--fuel == 0u) goto done;
            u3 = (r0.y - (unsigned)h1);
            if ((unsigned)(signed char)(0xf7191816u * a0[u1 & 3u])) break;
            r0.x = (unsigned)((unsigned)h1 < (unsigned)(~(unsigned)((short)(unsigned)l0 > (signed char)u3) < p1));
            if ((unsigned)((int)(a0[u1 & 3u] / (0x4462046cu | 1u)) >= (int)0x82830133u)) goto done;
            if ((unsigned)(0x6862907fu && (unsigned)((unsigned)s0 || u1))) {
                if (i1) break;
                f0 = f0 * 0.5f + (float)((u0 << ((u2 * (unsigned)h0) & 31u)) & 255u);
            } else {
                if (budget != 0u) { budget -= 1u; u1 = fn0(a0[i0 & 3u], (i2 - p0), (u2 ^ 0x10000u)); }
                if ((unsigned)e0) break;
            }
            w0 = w0 * 6364136223846793005ull + (0u | 0x6029c8d5u);
        } while (i1++ < 3u && ((unsigned)(w0 >> 29) << (((unsigned)c1 + (unsigned)f0) & 31u)));
        if (((unsigned)((short)fuel > (signed char)0xffffffffu) & (unsigned)e0)) continue;
        *q0 += *q0;
    }
    { unsigned t9; double z9; if (((unsigned)((int)0x10000u >= (int)(unsigned)x0)) & 1u) { t9 = (unsigned)((int)(unsigned)s1 < (int)9u); z9 = (double)(((unsigned)(0x80000000u == (unsigned)((int)(unsigned)w0 >= (int)*mp))) & 255u); } if (((unsigned)((int)0x10000u >= (int)(unsigned)x0)) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
        u0 = (unsigned)s0;
        while (i0++ < 7u && 0x10000u) { if (--fuel == 0u) goto done;
            while ((unsigned)c0) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)g1 >= (int)7u)) goto L2;
            }
            if (r0.x) break;
            *q0 = (m0 % ((i0 << ((unsigned)((unsigned)f0 == g1) & 31u)) | 1u));
        }
    }
    if (fuel < 8u) return ((unsigned)(0x25fc8514u && u3) & (unsigned)(short)(unsigned)(((unsigned)(x0 >> 70) + m0) < 0x10000u));
    while (p0) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            *q0 += (a0[i0 & 3u] ? (unsigned)((short)(unsigned)(a0[i0 & 3u] < i0) > (signed char)0x80000000u) : 0x5c085a96u);
            switch ((unsigned)d0 & 7u) {
                case 2u: ;
            }
        } while (i1++ < 4u && (unsigned)c1);
        b0 = (unsigned)(1u || p0) != 0u;
    }
    c0 = (unsigned char)(unsigned)((unsigned)(v0 < u2) && 4u);
    if ((a0[u1 & 3u] | a0[u1 & 3u])) goto done;
    if (budget != 0u) { budget -= 1u; u0 = fn1(a0[u1 & 3u], m0, -(g0 * (unsigned)((unsigned)(w0 >> 29) < u3))); }
    goto L4;
    x0 = x0 * 0x100000001b3ull + 0x10000u;
    u0 += (unsigned)(short)(r0.x | i1);
    h0 = (short)(unsigned)((int)(unsigned)(i1 < (v0 ^ g1)) < (int)0x4e1586f5u);
    do { if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)((int)0xae216d48u >= (int)(p2 ? 4u : (unsigned)(5u || 0xc9bca6a3u)));
        q0 = &garr[(0xffffffffu - (garr[u2 & 7u] / ((unsigned)f0 | 1u))) & 7u];
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(-(unsigned)((unsigned)h1 || 0xffffffffu) || (unsigned)l0)) goto L4;
            break; (void)(((unsigned)l0 % (fuel | 1u)));
            break; (void)((unsigned)((short)(unsigned)(a0[i0 & 3u] == 0x7fffffffu) > (signed char)u3));
            *q0 = (unsigned)((int)i2 < (int)(p2 - (unsigned)((int)m0 >= (int)i0)));
        }
        switch ((unsigned)(m0 == (unsigned)s1) & 7u) {
            *q0 = ((unsigned)(w0 >> 29) - p1);
            g1 += (unsigned)(signed char)((unsigned)!((unsigned)(w0 >> 29) | garr[u2 & 7u]) + (unsigned)((int)fuel >= (int)(unsigned)(unsigned char)((unsigned)c1 % (i0 | 1u))));
            case 5u: ;
            a0[(unsigned)f0 & 3u] = (unsigned)((short)(unsigned)w0 > (signed char)(((unsigned)c0 + 6u) - 4u));
        }
    } while (i0++ < 7u && (0xffffffffu >> (*mp & 31u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    g0 = (0xffffffffu + a0[i0 & 3u]);
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(r0.y && -(unsigned)((int)(unsigned)d0 < (int)(unsigned)d0)), (0xf073354cu & r0.y), (unsigned)c0); }
    do { if (--fuel == 0u) goto done;
        if (((v0 ^ (unsigned)e0) & m0)) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((garr[i1 & 7u] | 0xffffffffu), (unsigned)((int)0x80000000u < (int)*mp), (g0 ^ (unsigned)s1)); }
        }
        break; (void)((unsigned)(unsigned char)(0xffffffffu | u3));
        if ((unsigned)(u0 < (unsigned)f0)) goto done;
    } while (i0++ < 2u && (unsigned)(w0 >> 29));
    if ((unsigned)(8u || 0x8e369711u)) goto L4;
    w0 ^= (unsigned long long)p0 << ((unsigned)(-(unsigned)((int)0xa5337eceu >= (int)7u) < u0) & 63u);
    u3 = (g0 >> (7u & 31u));
    goto L1;
    s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((int)(unsigned)!(0xffffffffu / (a0[u1 & 3u] | 1u)) < (int)a0[i0 & 3u]) < (int)i2));
    s0 = (int)(unsigned)(0xe5d19c29u < (unsigned)e0);
    while (i0++ < 2u && i1) { if (--fuel == 0u) goto done;
        if ((unsigned)(p2 < (unsigned)(x0 >> 70))) break;
        switch ((unsigned)(u1 && (unsigned)((int)u2 >= (int)(unsigned)c0)) & 7u) {
            u2 = p2;
        }
        if (*q0) {
            a0[garr[u2 & 7u] & 3u] = (unsigned)((7u - (unsigned)((int)(unsigned)h0 < (int)(unsigned)s1)) && ((unsigned)s0 % ((unsigned)d0 | 1u)));
            L0: if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (g1) {
                    if ((unsigned)(p2 == -(0x751fac9au * 0x52621425u))) break;
                    c1 = (signed char)~(unsigned)(g1 == fuel);
                    if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)l0 % (g0 | 1u)), (0xffffffffu + (unsigned)(x0 >> 70)), ((0x7cc0210fu - 0x7a670952u) / ((unsigned)d0 | 1u))); }
                    L1: if (--fuel == 0u) goto done;
                }
                L2: if (--fuel == 0u) goto done;
                b0 = (u2 | (unsigned)((int)(0x7fffffffu | (unsigned)c0) < (int)0xffffffffu)) != 0u;
                if (-(unsigned)((short)i0 > (signed char)(unsigned)(signed char)(u2 * u0))) break;
                if ((p2 / (0x37e4d9eeu | 1u))) continue;
            }
        } else {
            if (((3u / ((unsigned)x0 | 1u)) * 0x289f85f1u)) continue;
            r0.y ^= ((unsigned)((short)(unsigned)((int)0x7fffffffu >= (int)i2) > (signed char)(unsigned)((int)garr[i1 & 7u] >= (int)5u)) * (unsigned)x0);
            u3 ^= ((unsigned)((short)u2 > (signed char)((unsigned)f0 / ((unsigned)l0 | 1u))) * (unsigned)(0xae78abd9u || (unsigned)s0));
        }
        b0 = 0xffffffffu != 0u;
        if (fuel < 8u) return ((unsigned)(signed char)(unsigned)((int)u2 < (int)4u) % ((unsigned)c1 | 1u));
        switch (~(unsigned)(g1 || 0x80000000u) & 7u) {
            case 6u: ;
            v0 = ((unsigned)x0 - ((unsigned)d0 % (i1 | 1u)));
        }
    }
    if (p0) goto L0;
    goto L3;
    { unsigned t0; double z0; if (((unsigned)c1) & 1u) { t0 = ((unsigned)h1 % (u2 | 1u)); z0 = (double)((((unsigned)h0 ^ u1)) & 255u); } if (((unsigned)c1) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        if (budget != 0u) { budget -= 1u; u1 = fn2(-(u1 | p0), (unsigned)(9u == g0), (unsigned)((int)(unsigned)e0 < (int)0x57d17870u)); }
        garr[i1 & 7u] = (unsigned)((int)garr[u2 & 7u] < (int)garr[i1 & 7u]);
        do { if (--fuel == 0u) goto done;
            *q0 = 2u;
            h1 = (unsigned short)(h1 + (unsigned)f0);
            if (u3 == 7u) return (unsigned)(((unsigned)(0xea2a57cbu == 0x341c4504u) << (0x7fffffffu & 31u)) && (unsigned)c1);
            g1 += ((unsigned)((unsigned)b0 || 9u) & (a0[u1 & 3u] ^ u1));
            L3: if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
        } while (i0++ < 2u && g1);
        goto L1;
        h0 = (short)(((unsigned)h1 % ((unsigned)h0 | 1u)) >> (u1 & 31u));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((0x38be983bu * (unsigned)e0) == g1), 0x7fffffffu, (unsigned)(unsigned char)(unsigned)((int)v0 >= (int)u1)); }
    { unsigned t1; double z1; if (((unsigned)!(a0[u1 & 3u] << ((0x80000000u | fuel) & 31u))) & 1u) { t1 = (unsigned)(9u || (0xc37cf5du % ((unsigned)(x0 >> 70) | 1u))); z1 = (double)(((0x80000000u - (unsigned)s1)) & 255u); } if (((unsigned)!(a0[u1 & 3u] << ((0x80000000u | fuel) & 31u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        f0 = f0 * 0.5f + (float)((unsigned)x0 & 255u);
        if (i0) goto L3;
        switch ((unsigned)(unsigned char)((unsigned)((unsigned)d0 || 5u) - a0[i0 & 3u]) & 7u) {
            u0 ^= -(u1 >> ((unsigned)(0xffffffffu < (8u + 3u)) & 31u));
            case 1u: ;
            case 7u: ;
            e0 = e0 * 0.5L + (long double)(u2 & 1023u);
            q0 = &garr[g1 & 7u];
        }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(0x8f33c559u == m0), (unsigned)!(unsigned)((unsigned)c1 == r0.y), (unsigned)l0); }
            w0 = w0 * 6364136223846793005ull + (unsigned)f0;
            x0 = x0 * 0x100000001b3ull + (unsigned)((short)(8u + i1) > (signed char)((unsigned)d0 & 7u));
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(4u || i0), (unsigned)(0x80000000u == 0xef89e8abu), (unsigned)(signed char)(unsigned)((int)(unsigned)l0 < (int)(*q0 * m0))); }
            if ((4u >> ((unsigned)e0 & 31u))) break;
            switch ((unsigned)(a0[i0 & 3u] || (unsigned)l0) & 7u) {
                break; (void)((unsigned)(short)(garr[u2 & 7u] >> ((unsigned)d0 & 31u)));
            }
        }
    }
    if ((unsigned)(u1 == (unsigned)(0xffffffffu < 0x80000000u))) {
        switch (fuel & 7u) {
            case 3u: ;
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)e0 << (garr[i1 & 7u] & 31u)), (unsigned)((unsigned)c0 && (g1 | 0x6bf4867u)), 0xd160250du); }
            default: ;
            if (fuel) {
                *mp = ((*q0 & *mp) << (((unsigned)((unsigned)l0 && 2u) | 0x7fffffffu) & 31u));
                if ((unsigned)!(unsigned)(garr[u2 & 7u] == *mp)) goto L2;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((0xfef48182u * u2), 0x2bc0ef01u, (unsigned)((*q0 & 0x7e48202bu) == 0x80000000u)); }
                    { unsigned t2; double z2; if ((((unsigned)(unsigned char)(unsigned)(3u && (unsigned)x0) << ((unsigned)c1 & 31u))) & 1u) { t2 = (unsigned)(*q0 < (unsigned)(0xd4df74a6u && fuel)); z2 = (double)((((unsigned)h1 & (unsigned)x0)) & 255u); } if ((((unsigned)(unsigned char)(unsigned)(3u && (unsigned)x0) << ((unsigned)c1 & 31u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                        continue; (void)((unsigned)((0x905ef286u / (i1 | 1u)) || 0xd8272bd1u));
                        u2 = u2 * 0x9e3779b1u + (unsigned)((unsigned)c1 == (garr[u2 & 7u] ^ 0x80000000u));
                        i1 = 8u & 15u;
                        if (u3 == 7u) return ((unsigned)((int)(unsigned)e0 >= (int)(v0 & *q0)) - (unsigned)h1);
                        case 4u: ;
                        continue; (void)(((unsigned)s0 >> ((unsigned)c1 & 31u)));
                    }
                    *mp = (unsigned)(unsigned char)(unsigned)((int)(unsigned)(0x7fffffffu < u2) >= (int)((u3 ^ (unsigned)d0) >> (0x2c91a5d7u & 31u)));
                } while (i0++ < 5u && ((unsigned)x0 >> (0xa0038f52u & 31u)));
                q0 = &garr[(0x80000000u & (unsigned)((int)(a0[u1 & 3u] << (fuel & 31u)) < (int)5u)) & 7u];
                if ((unsigned)(x0 >> 70)) {
                    if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)w0 | 0x4d2e751du), (*q0 ? u1 : 4u), (r0.x % ((0x91d8c492u >> (0x957cc211u & 31u)) | 1u))); }
                    x0 = x0 * 0x100000001b3ull + 0x307e3d9u;
                    *q0 = (unsigned)((unsigned)d0 || ((unsigned)((unsigned)s0 == (0u + p2)) << (8u & 31u)));
                } else {
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)c1 >= (int)(unsigned)((unsigned)(w0 >> 29) == 0x10000u));
                    s0 = (int)(unsigned)(short)((unsigned)((unsigned)h0 < (unsigned)f0) - (u3 ? 6u : u0));
                    if (budget != 0u) { budget -= 1u; u3 = fn2((u2 + 6u), (0x8ac123c8u & 0x7fffffffu), (0x3d8057c4u + 0x10000u)); }
                    a0[(unsigned)((unsigned)d0 || *q0) & 3u] = (unsigned)(0xef698dddu && (0x80000000u >> (*q0 & 31u)));
                }
            }
            u1 ^= ((unsigned)s0 ? fuel : (unsigned)((int)(unsigned)b0 >= (int)(0x45f5ce88u + (unsigned)l0)));
            h0 = (short)((unsigned)(short)(garr[u2 & 7u] + 9u) / ((unsigned)(0x10b9fc3bu && (unsigned)c1) | 1u));
        }
        if (~(0x10000u << (u2 & 31u))) {
            goto done;
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return (2u / ((unsigned)(short)(p0 - g0) | 1u));
                if ((unsigned)(p1 || (unsigned)x0)) continue;
                if (i1) {
                    h1 = (unsigned short)(h1 + ((g1 - 9u) & (unsigned)c0));
                    if (p2) break;
                    { unsigned t3; double z3; if (((unsigned)h1) & 1u) { t3 = (unsigned)(g0 < (unsigned)w0); z3 = (double)(((unsigned)f0) & 255u); } if (((unsigned)h1) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                            v0 = 1u;
                        }
                        if ((unsigned)(signed char)(unsigned)((unsigned)e0 && (unsigned)(unsigned char)(u2 / ((unsigned)c1 | 1u)))) break;
                        u0 = u0 * 0x9e3779b1u + ~(unsigned)((int)0xffffffffu >= (int)((unsigned)f0 ? garr[i1 & 7u] : a0[u1 & 3u]));
                        if (u2) break;
                        i2 = (unsigned)s1 & 15u;
                        break; (void)((p2 ^ (unsigned)s1));
                    }
                }
                if (((unsigned)e0 << ((unsigned)h1 & 31u))) break;
                f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)l0 < (int)~(0x78c1aae7u % (((unsigned)(0x7fffffffu < (unsigned)d0) & (unsigned)h1) | 1u))) & 255u);
                if ((unsigned)(u3 || (unsigned)((unsigned)h0 == a0[u1 & 3u]))) break;
            }
            *q0 = (unsigned)(short)(a0[i0 & 3u] ^ (0x80000000u - 0x10000u));
            if (((unsigned)w0 ^ 0x80000000u)) {
                if (budget != 0u) { budget -= 1u; u3 = fn2(0x7fffffffu, (-((unsigned)h0 % (p2 | 1u)) + (unsigned)s0), (u1 ? 0xffffffffu : 0x80000000u)); }
                if (budget != 0u) { budget -= 1u; u1 = fn2(0x7fffffffu, (unsigned)(0x48021514u || (i2 << (9u & 31u))), 7u); }
                w0 ^= (unsigned long long)(unsigned)b0 << (r0.x & 63u);
                *q0 += 0x80000000u;
                goto L4;
            }
            h1 = (unsigned short)(h1 + (unsigned)((unsigned)(x0 >> 70) || (u2 << (0xffffffffu & 31u))));
            r0.x = (unsigned)(g0 || 0x35fd7811u);
        }
        if ((unsigned)!(unsigned)(0x10000u || g0)) {
            while (i0++ < 7u && (unsigned)((unsigned)(w0 >> 29) && 4u)) { if (--fuel == 0u) goto done;
                if ((3u * *mp)) {
                    c1 = (signed char)(unsigned)(short)(p1 | 6u);
                    goto L0;
                    if ((0x638b40f3u ^ 0xffffffffu)) break;
                    *mp = (unsigned)(signed char)(unsigned)(((unsigned)e0 * r0.x) && -(0xe965047fu | r0.y));
                    if (0xb7768137u) break;
                    c0 = (unsigned char)(g0 << (0x10000u & 31u));
                }
                h1 = (unsigned short)(h1 + (unsigned)(g1 < 0xffffffffu));
                if (((4u >> ((unsigned)s1 & 31u)) * 0x7fffffffu)) goto L2;
                r0.x = (unsigned)((unsigned)c0 && (unsigned)(0x10000u || ((unsigned)h0 ^ (unsigned)s0)));
            }
            if (budget != 0u) { budget -= 1u; u3 = fn2(g0, 5u, ((p2 ^ v0) | (unsigned)x0)); }
            if (((unsigned)d0 << (6u & 31u))) goto L0;
            a0[g1 & 3u] = (v0 >> ((unsigned)s1 & 31u));
            if ((unsigned)((short)-(unsigned)((int)5u < (int)(unsigned)x0) > (signed char)(unsigned)h0)) goto L2;
            if ((2u | 0x80000000u)) goto L3;
        } else {
            if (budget != 0u) { budget -= 1u; u3 = fn0(m0, ((garr[i1 & 7u] * (unsigned)c0) | (unsigned)(w0 >> 29)), *mp); }
            if ((unsigned)(((unsigned)(w0 >> 29) + a0[u1 & 3u]) || v0)) goto L1;
        }
        if ((u0 % (0x80000000u | 1u))) goto L2;
    } else {
        if ((unsigned)((short)6u > (signed char)5u)) goto L1;
    }
    *mp = a0[u1 & 3u];
    if (budget != 0u) { budget -= 1u; u0 = fn1((i2 / (((unsigned)s0 - 0x3ef9e7f1u) | 1u)), ((unsigned)x0 / ((g0 - u2) | 1u)), (unsigned)(unsigned char)((unsigned)b0 & 0xffffffffu)); }
    if (budget != 0u) { budget -= 1u; u2 = fn1((0xffffffffu % (garr[i1 & 7u] | 1u)), (unsigned)h0, ((g0 | (unsigned)s0) % (0xb0a7c1fcu | 1u))); }
    m0 ^= -((unsigned)l0 << ((unsigned)(p2 == (unsigned)h1) & 31u));
    { unsigned t4; double z4; if (((unsigned)((int)u2 >= (int)0x80000000u)) & 1u) { t4 = (unsigned)((unsigned)h0 == i2); z4 = (double)(((unsigned)d0) & 255u); } if (((unsigned)((int)u2 >= (int)0x80000000u)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            u1 += (unsigned)((int)p1 < (int)(u3 | p1));
            *q0 = (unsigned)((int)garr[i1 & 7u] >= (int)garr[u2 & 7u]);
        }
        if (0x3c8e0814u) goto L2;
        w0 = w0 * 6364136223846793005ull + (unsigned)((short)p2 > (signed char)0xffffffffu);
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(garr[i1 & 7u]);
            if (v0) break;
            if ((0x3cc9d201u << (((unsigned)s1 - p0) & 31u))) goto L1;
            do { if (--fuel == 0u) goto done;
                u3 += r0.x;
                l0 = (long)((unsigned long)l0 + (unsigned)((short)(4u + (0x10000u & v0)) > (signed char)(unsigned)b0));
                if (((0x80000000u | 0x86c2921u) - u1)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)c1 * i1), garr[u2 & 7u], (unsigned)(unsigned char)((unsigned)(g0 && (unsigned)f0) - fuel)); }
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((short)(garr[i1 & 7u] * g0) > (signed char)0x10000u), (0x13366f7cu ? u0 : 0x62e23cf7u), (unsigned)(unsigned char)(0x55e6e976u & (unsigned)c1)); }
                { unsigned t5; double z5; if (((p2 & v0)) & 1u) { t5 = ((unsigned)c0 + 0xeb4f82a6u); z5 = (double)(((6u + garr[u2 & 7u])) & 255u); } if (((p2 & v0)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    if ((unsigned)w0) break;
                    c0 = (unsigned char)(unsigned)c0;
                    if ((3u ^ g1)) break;
                    if ((unsigned)((int)*mp < (int)a0[u1 & 3u])) {
                        if ((unsigned)(short)((unsigned)h1 ? a0[i0 & 3u] : 0xffffffffu)) break;
                        d0 = d0 * 0.5 + (double)((8u / (g0 | 1u)) & 1023u);
                    }
                    break; (void)((0x1daceb8au ^ (unsigned)(fuel == g0)));
                }
            } while (i1++ < 6u && 0xffffffffu);
            g0 = (unsigned)!((0x7fffffffu / ((unsigned)h0 | 1u)) ? (unsigned)(unsigned char)(0x32439b61u >> (0x95941199u & 31u)) : (unsigned)h1);
        }
        if ((a0[u1 & 3u] % ((unsigned)c1 | 1u))) {
            { unsigned t6; double z6; if ((1u) & 1u) { t6 = 0x6d21eac9u; z6 = (double)((0x933a3c44u) & 255u); } if ((1u) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                goto L3;
                goto L4;
                if ((unsigned)((unsigned)s0 || (unsigned)(x0 >> 70))) goto L3;
                if (0xae2fc456u) goto L3;
                if ((unsigned)((short)u3 > (signed char)(unsigned)((int)(unsigned)e0 >= (int)0x506fcfc4u))) goto done;
            }
        }
    }
    l0 = (long)((unsigned long)l0 + ((r0.x - (unsigned)w0) << ((fuel << ((unsigned)(p2 || u1) & 31u)) & 31u)));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        v0 = a0[u1 & 3u];
    }
    garr[u2 & 7u] = (unsigned)(i1 < 1u);
    do { if (--fuel == 0u) goto done;
        garr[u3 & 7u] = ((unsigned)((int)*q0 >= (int)u2) & i0);
        continue; (void)(u3);
    } while (i0++ < 3u && (0x24a3704fu + (unsigned)d0));
    u3 = u3;
    g1 += (((unsigned)s0 >> ((unsigned)b0 & 31u)) & g0);
    if ((p1 | p2)) goto L2;
    if ((p1 << ((unsigned)w0 & 31u))) {
        goto L3;
        if (p1) goto done;
    } else {
        if (((unsigned)e0 % (0x3bfbdfa0u | 1u))) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)((short)garr[u2 & 7u] > (signed char)garr[u2 & 7u]) < (int)i0), (unsigned)w0, (unsigned)((short)((unsigned)l0 & 4u) > (signed char)(unsigned)e0)); }
        u1 = u1 * 0x9e3779b1u + (((unsigned)(x0 >> 70) ^ g0) >> ((unsigned)((int)0x648ab73cu >= (int)(garr[u2 & 7u] & (unsigned)c0)) & 31u));
        goto done;
    }
    f0 = f0 * 0.5f + (float)(((unsigned)(p1 < *mp) - 0xd1ad778eu) & 255u);
    if ((unsigned)((int)v0 < (int)(0u ^ p0))) goto L3;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((u0 - 0xe4e560d1u));
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)!(*q0 & (unsigned)x0), ((unsigned)x0 >> ((unsigned)((unsigned)w0 || u2) & 31u)), (a0[u1 & 3u] >> ((unsigned)b0 & 31u))); }
    }
    if ((m0 % (p0 | 1u))) goto L3;
    *q0 = (unsigned)((int)0x80000000u < (int)(unsigned)((int)(unsigned)h1 >= (int)0x10000u));
    if ((unsigned)(x0 >> 70)) {
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1(0x7fffffffu, (unsigned)(0xa801aa8bu < 0xcee740d5u), (0xf4a85799u ^ (unsigned)(r0.y < u1))); }
        } while (i0++ < 7u && ((unsigned)h0 | (unsigned)f0));
        if (i1) {
            do { if (--fuel == 0u) goto done;
                if ((2u ? 0xffffffffu : m0)) continue;
                l0 = (long)((unsigned long)l0 + (unsigned)c1);
            } while (i0++ < 5u && (unsigned)((unsigned)(unsigned char)(unsigned)(0x46239c5bu && (unsigned)(x0 >> 70)) < (unsigned)w0));
            goto L4;
            { unsigned t7; double z7; if (((0x7fffffffu - 1u)) & 1u) { t7 = (unsigned)s0; z7 = (double)(((unsigned)((*mp << (m0 & 31u)) < garr[i1 & 7u])) & 255u); } if (((0x7fffffffu - 1u)) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)h0 >= (int)fuel), (unsigned)(unsigned char)(0x80000000u - (unsigned)(m0 || (unsigned)d0)), 0x66761491u); }
            }
        }
        if ((m0 << (g1 & 31u))) goto L0;
    }
    if (0xcaa4afceu) {
        c1 = (signed char)a0[i0 & 3u];
    }
    if (((0u / (garr[i1 & 7u] | 1u)) % (0x66f0ef41u | 1u))) {
        switch (((unsigned)b0 % (garr[i1 & 7u] | 1u)) & 7u) {
            w0 ^= (unsigned long long)(unsigned)w0 << (((p2 % (0x80000000u | 1u)) / (p0 | 1u)) & 63u);
        }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)s1 < (unsigned)c1)) goto L2;
            b0 = (unsigned)((int)*q0 < (int)u0) != 0u;
        } while (i0++ < 2u && (p0 | m0));
        if ((unsigned)h1) goto L2;
    }
    u1 = (2u << (0xffffffffu & 31u));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((unsigned)(p0 && ((unsigned)h1 - g1)) & 255u);
        if ((unsigned)((int)u2 < (int)(unsigned)(g0 < 4u))) break;
        m0 ^= (unsigned)(0x80000000u || (unsigned)(short)(unsigned)((unsigned)(a0[u1 & 3u] && 0x2f8d9addu) == 0x80000000u));
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (((1u + (unsigned)l0) & 4u)) break;
            if ((unsigned)((unsigned)(short)(unsigned)(0x213e04b2u || 0x28113bcu) && 1u)) break;
            if (budget != 0u) { budget -= 1u; u3 = fn0((i1 << (-(0x7fffffffu & 0x49b6bb7eu) & 31u)), (unsigned)(unsigned char)(8u ^ (unsigned)((int)r0.x >= (int)fuel)), (m0 % ((0x80000000u * u1) | 1u))); }
            while ((unsigned)c0) { if (--fuel == 0u) goto done;
                { unsigned t8; double z8; if (((unsigned)((i1 & g0) && (unsigned)x0)) & 1u) { t8 = 0x10000u; z8 = (double)(((0x80000000u << (fuel & 31u))) & 255u); } if (((unsigned)((i1 & g0) && (unsigned)x0)) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                    c0 = (unsigned char)(unsigned)((unsigned)d0 < (unsigned)s1);
                    if (u3) break;
                    i1 = ~((g0 / (0x7fffffffu | 1u)) ^ (unsigned)(short)(i2 << (u1 & 31u))) & 15u;
                    if (u3 == 7u) return (unsigned)((unsigned)d0 || (m0 ? garr[u2 & 7u] : (unsigned)b0));
                    if ((1u * p2)) break;
                    h1 = (unsigned short)(h1 + (unsigned)(((unsigned)s1 * (unsigned)(unsigned char)(u2 / ((unsigned)s0 | 1u))) && i0));
                }
                if (((0x7fffffffu * (unsigned)l0) * (unsigned)c0)) {
                    break; (void)((unsigned)(signed char)(0x2a964bafu >> (p0 & 31u)));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!((a0[u1 & 3u] + (unsigned)(w0 >> 29)) * 7u), (unsigned)((unsigned)(short)(m0 | u0) == 8u), (unsigned)b0); }
                    if (fuel < 8u) return ((unsigned)(x0 >> 70) ? 2u : (unsigned)c0);
                    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((int)(unsigned)w0 < (int)fuel));
                        break; (void)((unsigned)x0);
                        break; (void)(((unsigned)(x0 >> 70) ? g1 : a0[i0 & 3u]));
                        h0 = (short)(unsigned)(0x60c814e6u && u0);
                    }
                    u1 ^= (0x1f4fbeafu ^ i2);
                    switch (garr[u2 & 7u] & 7u) {
                        if ((a0[u1 & 3u] >> (0xf2bd418cu & 31u))) goto L0;
                        b0 = ((unsigned)((int)(0x2f20019cu >> ((unsigned)f0 & 31u)) < (int)fuel) << (0xffffffffu & 31u)) != 0u;
                        garr[(unsigned)(unsigned char)(2u + *q0) & 7u] = (((unsigned)w0 ^ 0u) % (((unsigned)c0 << ((unsigned)s0 & 31u)) | 1u));
                    }
                }
                break; (void)(3u);
                { unsigned t9; double z9; if ((*q0) & 1u) { t9 = (unsigned)(signed char)((p2 & garr[i1 & 7u]) << (9u & 31u)); z9 = (double)((9u) & 255u); } if ((*q0) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                    if ((unsigned)(unsigned char)(unsigned)((int)a0[i0 & 3u] < (int)0xf705623fu)) goto L1;
                    m0 ^= (unsigned)(p1 == ((i2 % ((unsigned)s1 | 1u)) << (0u & 31u)));
                    if (0x7fffffffu) break;
                }
                l0 = (long)((unsigned long)l0 + ((unsigned)(unsigned char)(3u | ~(0x90f0360cu / (u2 | 1u))) | m0));
                r0.x = (garr[i1 & 7u] * (unsigned)h0);
            }
        }
        u3 = u3 * 0x9e3779b1u + *mp;
        w0 ^= (unsigned long long)((unsigned)(x0 >> 70) + (unsigned)c1) << (((unsigned)(signed char)(unsigned)((unsigned)(6u < (unsigned)f0) < v0) / (0x8fdbc25cu | 1u)) & 63u);
    }
    while (i0++ < 7u && (unsigned)((short)v0 > (signed char)(unsigned)h1)) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            if ((r0.y | (0u >> (0x7fffffffu & 31u)))) goto L1;
            garr[4u & 7u] = (((unsigned)((unsigned)e0 || a0[i0 & 3u]) | 0u) ^ i1);
            if (budget != 0u) { budget -= 1u; u3 = fn1((fuel % (u3 | 1u)), p2, ((unsigned)(x0 >> 70) | (unsigned)(short)(u0 >> (r0.y & 31u)))); }
            if ((u1 * (0xffffffffu / (p0 | 1u)))) goto L2;
            switch ((*mp / (u2 | 1u)) & 7u) {
                if (budget != 0u) { budget -= 1u; u0 = fn2(0x10000u, 0x9b7dcc85u, (0x3661bff0u * a0[i0 & 3u])); }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)!(unsigned)((short)0xd70a8c25u > (signed char)((unsigned)l0 + 2u)), (unsigned)((unsigned)c0 == (r0.x ^ (unsigned)c1)), ((unsigned)((int)i2 >= (int)a0[i0 & 3u]) | 0x80000000u)); }
                { unsigned t10; double z10; if (((unsigned)(signed char)((0xa694377fu & (unsigned)d0) + 9u)) & 1u) { t10 = garr[i1 & 7u]; z10 = (double)(((unsigned)(w0 >> 29)) & 255u); } if (((unsigned)(signed char)((0xa694377fu & (unsigned)d0) + 9u)) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
                    if (0u) {
                        *mp = (unsigned)((short)r0.y > (signed char)(4u ? (unsigned)d0 : (unsigned)(0xd0dc1e1bu || i1)));
                        case 7u: ;
                        r0.y ^= (unsigned)((short)(unsigned)((int)(unsigned)((unsigned)b0 || garr[i1 & 7u]) >= (int)0x10000u) > (signed char)(unsigned)((int)(unsigned)h1 < (int)p0));
                    } else {
                        i2 = (u1 / (2u | 1u)) & 15u;
                    }
                    if (((unsigned)l0 | a0[u1 & 3u])) break;
                    u2 += ((unsigned)(0xffffffffu == 2u) - u0);
                    u2 ^= (a0[u1 & 3u] | (unsigned)(signed char)(0x7fffffffu + (unsigned)(0xe088de05u < 0x962401a5u)));
                    if (*mp) continue;
                    { unsigned t11; double z11; if ((((1u >> ((unsigned)w0 & 31u)) + a0[i0 & 3u])) & 1u) { t11 = 2u; z11 = (double)(((unsigned)e0) & 255u); } if ((((1u >> ((unsigned)w0 & 31u)) + a0[i0 & 3u])) & 1u) { u3 += t11; d0 = d0 * 0.5 + z11; }
                        x0 = x0 * 0x100000001b3ull + (unsigned)((((p1 | 0x46cc519du) << (p2 & 31u)) + *mp) < (unsigned)w0);
                        if (*mp) break;
                        q0 = &garr[(unsigned)((int)(unsigned)f0 < (int)(unsigned)h1) & 7u];
                        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)0x80000000u < (int)p0), *q0, ((unsigned)b0 >> (0x35647623u & 31u))); }
                        if (budget != 0u) { budget -= 1u; u2 = fn2((8u | ((unsigned)w0 ^ 0xa935f451u)), (unsigned)(short)(m0 >> (m0 & 31u)), (0x10000u << ((unsigned)(signed char)(unsigned)((int)0xa62ba950u < (int)0xffffffffu) & 31u))); }
                    }
                }
                s0 = (int)(unsigned)(a0[u1 & 3u] == (unsigned)((int)0xb6b6db6eu < (int)(unsigned)b0));
                a0[(g0 / (0x55527b67u | 1u)) & 3u] = (unsigned)((p1 & 0x567326e9u) || ((unsigned)(x0 >> 70) >> ((unsigned)(0xae74a831u || garr[u2 & 7u]) & 31u)));
                if (garr[i1 & 7u]) break;
            }
            if ((i0 + -(0x95015642u >> (u0 & 31u)))) break;
        }
        if ((unsigned)!(i0 - (0x80000000u % (0x860e5368u | 1u)))) break;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                *mp = ((unsigned)(*mp || 0x7fffffffu) * p2);
                m0 ^= (unsigned)(-(unsigned)((int)7u >= (int)(unsigned)f0) == garr[i1 & 7u]);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn1((g1 * (unsigned)((unsigned)b0 == (unsigned)h1)), (*mp * (unsigned)b0), ((unsigned)s0 ^ (g0 | (unsigned)f0))); }
        }
        break; (void)((unsigned)(w0 >> 29));
        x0 = x0 * 0x100000001b3ull + (((unsigned)h1 ? i0 : 0x6f269569u) * (unsigned)(x0 >> 70));
        if ((unsigned)((unsigned)d0 == a0[i0 & 3u])) break;
    }
    { unsigned t12; double z12; if ((((unsigned)((int)(unsigned)s0 >= (int)9u) | (unsigned)(w0 >> 29))) & 1u) { t12 = ((r0.y >> ((unsigned)h1 & 31u)) & p0); z12 = (double)((0x7fffffffu) & 255u); } if ((((unsigned)((int)(unsigned)s0 >= (int)9u) | (unsigned)(w0 >> 29))) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
        if (v0) goto L4;
        goto L3;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    g0 = (unsigned)((short)(garr[u2 & 7u] ^ (unsigned)w0) > (signed char)0x7fffffffu);
    b0 = (unsigned)(signed char)(fuel >> ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)b0) & 31u)) != 0u;
    if ((unsigned)(unsigned char)(unsigned)(g1 && ((unsigned)s0 * u3))) {
        if ((unsigned)((unsigned)l0 || u0)) goto L2;
        u2 = u2 * 0x9e3779b1u + (unsigned)((unsigned)((unsigned)x0 == (*q0 - (unsigned)f0)) || 0x7fffffffu);
        u1 = (unsigned)((int)u2 >= (int)(0xe6ed63e9u * (unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)(a0[i0 & 3u] == p0))));
        if (budget != 0u) { budget -= 1u; u3 = fn2(r0.x, a0[u1 & 3u], (0x7fffffffu & ((unsigned)h0 * (unsigned)h1))); }
    }
    *q0 = (unsigned)((short)(u2 / (5u | 1u)) > (signed char)(unsigned)!((unsigned)l0 * (unsigned)(x0 >> 70)));
    if (budget != 0u) { budget -= 1u; u1 = fn2(garr[i1 & 7u], (unsigned)(0x399d25b1u < (unsigned)(short)(*q0 - u3)), (0xffffffffu | (unsigned)(0xcbbe86e1u < (unsigned)b0))); }
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(w0 >> 29), ((unsigned)((int)0x819addu >= (int)(unsigned)d0) << (1u & 31u)), (unsigned)(0x10000u || (unsigned)((short)u2 > (signed char)0x7fffffffu))); }
    w0 = w0 * 6364136223846793005ull + 8u;
    x0 = x0 * 0x100000001b3ull + g1;
    do { if (--fuel == 0u) goto done;
        if (-((unsigned)e0 >> ((unsigned)w0 & 31u))) goto done;
        break; (void)(((unsigned)b0 << (0x483cac6bu & 31u)));
        { unsigned t0; double z0; if ((0x7fffffffu) & 1u) { t0 = (i0 * 0x7fffffffu); z0 = (double)((u3) & 255u); } if ((0x7fffffffu) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)x0 && a0[u1 & 3u]), (unsigned)(short)(unsigned)(g0 && 0x77813965u), -(unsigned)((int)(unsigned)!(unsigned)(p2 < 0x80000000u) >= (int)u0)); }
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(x0 >> 70)) break;
            }
            w0 = w0 * 6364136223846793005ull + (unsigned)(0x32b5ab6fu < ((unsigned)(unsigned char)(0x10000u % ((unsigned)b0 | 1u)) / ((3u << (0x1ba6026fu & 31u)) | 1u)));
        }
        *mp = (unsigned)(0x80000000u || u1);
        { unsigned t1; double z1; if (((p2 >> ((unsigned)!(unsigned)((int)u2 >= (int)0x80000000u) & 31u))) & 1u) { t1 = (p0 ^ (g1 - 3u)); z1 = (double)(((8u ? (unsigned)h1 : 0u)) & 255u); } if (((p2 >> ((unsigned)!(unsigned)((int)u2 >= (int)0x80000000u) & 31u))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            e0 = e0 * 0.5L + (long double)((unsigned)((int)v0 >= (int)2u) & 1023u);
            u2 ^= (unsigned)!((unsigned)((unsigned)f0 && (unsigned)b0) << ((unsigned)((short)0xa6969515u > (signed char)g0) & 31u));
            garr[((unsigned)h0 * *q0) & 7u] = ((unsigned)!(0x6bf398f2u ^ (unsigned)(signed char)(*mp % ((unsigned)(i1 || i2) | 1u))) / (garr[i1 & 7u] | 1u));
            c0 = (unsigned char)i1;
            s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)((unsigned)x0 & 0xea2d3391u));
        }
    } while (i0++ < 5u && ((0x6adfc62du % ((unsigned)x0 | 1u)) << (5u & 31u)));
    u0 = (0x10000u & (u1 >> ((unsigned)w0 & 31u)));
    m0 ^= 0xd2159c24u;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        q0 = &garr[(unsigned)((int)0xd03c9afbu < (int)(unsigned)(p2 == (9u - garr[i1 & 7u]))) & 7u];
        if ((g1 & (unsigned)((int)0u < (int)*q0))) break;
        if ((unsigned)(a0[i0 & 3u] == ((unsigned)d0 ^ *mp))) goto done;
        while (i1++ < 4u && ~(unsigned)((int)(unsigned)h0 < (int)u2)) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)!(unsigned)((unsigned)(r0.x && a0[i0 & 3u]) || (garr[i1 & 7u] ? u1 : 8u)));
                h1 = (unsigned short)(h1 + (unsigned)((short)((garr[i1 & 7u] % (0xd01e98a8u | 1u)) * r0.x) > (signed char)((unsigned)s0 * (unsigned)w0)));
            }
        }
        r0.x = (((unsigned)(unsigned char)((unsigned)w0 ^ ((unsigned)s1 >> ((unsigned)h1 & 31u))) << (2u & 31u)) + (unsigned)s1);
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(0x3d2b5d64u && ((unsigned)w0 << (0x80000000u & 31u))), (unsigned)((short)0u > (signed char)(unsigned)s0), (unsigned)w0); }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)e0 - r0.y), -(unsigned)((int)1u < (int)(unsigned)c1), (0x29f13fffu | 7u)); }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = (unsigned)((unsigned)(0x7fffffffu < 4u) && (1u / ((unsigned)(short)((unsigned)b0 & u0) | 1u)));
        { unsigned t2; double z2; if ((0x9801238bu) & 1u) { t2 = (v0 >> (u3 & 31u)); z2 = (double)(((unsigned)((short)(*mp * (unsigned)x0) > (signed char)r0.x)) & 255u); } if ((0x9801238bu) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            f0 = f0 * 0.5f + (float)(((g0 >> (0x47dfd41bu & 31u)) ? m0 : (unsigned)e0) & 255u);
            if ((p2 << (0xe9ee80c8u & 31u))) break;
            switch ((i2 ^ 0x10000u) & 7u) {
                m0 ^= ((unsigned)(w0 >> 29) - i0);
                v0 = ~(unsigned)((unsigned)l0 || ((garr[u2 & 7u] ? 3u : (unsigned)w0) | (unsigned)w0));
                b0 = (unsigned)((short)v0 > (signed char)*q0) != 0u;
                if ((unsigned)((int)0x7fffffffu >= (int)(unsigned)c1)) {
                    u3 = u3 * 0x9e3779b1u + (unsigned)(0xffffffffu < (0x7fffffffu % ((unsigned)l0 | 1u)));
                } else {
                    s1 = (int)((unsigned)s1 + (unsigned)(p0 < (unsigned)(p1 && (unsigned)(((unsigned)s1 ^ 4u) == 0x80000000u))));
                }
                if (budget != 0u) { budget -= 1u; u0 = fn2(p2, (unsigned)(g0 && ((unsigned)x0 % (garr[i1 & 7u] | 1u))), (unsigned)(signed char)(p2 << (((unsigned)s1 * u0) & 31u))); }
                g1 += (i2 - (unsigned)((short)(unsigned)((unsigned)d0 < 0x7fffffffu) > (signed char)~(unsigned)(0xffffffffu || 0xffffffffu)));
            }
            if ((((unsigned)f0 / (*mp | 1u)) & u1)) {
                if ((unsigned)(x0 >> 70)) continue;
            } else {
                g1 += (unsigned)(0x776edf44u || (unsigned)h1);
                do { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)h1) / (((u3 + (unsigned)f0) % (r0.y | 1u)) | 1u)));
                    switch ((6u | *mp) & 7u) {
                        w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)((int)(unsigned)x0 >= (int)(unsigned)s1) && (unsigned)((int)*q0 < (int)((unsigned)(w0 >> 29) % (p1 | 1u))));
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)s1, ((unsigned)(signed char)(fuel >> (a0[i0 & 3u] & 31u)) / (p2 | 1u)), ((unsigned)x0 % ((unsigned)(0x14e91334u < 0x10000u) | 1u))); }
                        *q0 = (unsigned)(9u && ((unsigned)h1 ? (unsigned)c1 : (u2 << (0x80000000u & 31u))));
                        while ((unsigned)(0x80000000u < p0)) { if (--fuel == 0u) goto done;
                            if (((unsigned)e0 & (a0[u1 & 3u] | (unsigned)s1))) continue;
                            case 1u: ;
                            m0 ^= (v0 & (0x71055e90u ^ a0[i0 & 3u]));
                            if (budget != 0u) { budget -= 1u; u1 = fn1(i2, (unsigned)s0, (unsigned)(signed char)((unsigned)c1 / (u0 | 1u))); }
                            v0 = (unsigned)((short)(unsigned)(unsigned char)((unsigned)((int)p0 >= (int)(unsigned)f0) + 0xf7b85c61u) > (signed char)u1);
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn0(-((unsigned)((short)r0.x > (signed char)u1) * 0xffffffffu), (unsigned)h1, (unsigned)(short)((unsigned)s0 >> (-(unsigned)((int)0xd15336f5u < (int)0x7fffffffu) & 31u))); }
                    }
                    garr[(u1 / (0x1af6ae3bu | 1u)) & 7u] = ((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)(unsigned char)(fuel - 0x248c46bfu)) * (unsigned)(signed char)(0xffffffffu ^ 0x962b5b31u));
                    u0 = u0 * 0x9e3779b1u + (unsigned)((int)0x10000u < (int)*mp);
                } while (i1++ < 4u && ((unsigned)e0 / (0x43f54b7cu | 1u)));
            }
        }
        if (r0.y) break;
        if (8u) break;
    }
    r0.x = ((unsigned)c1 * (unsigned)c0);
    do { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + ((unsigned)b0 ? i2 : (*mp & (unsigned)((int)g1 < (int)m0)));
        c1 = (signed char)((unsigned)((int)r0.x < (int)(unsigned)(*mp < p0)) - (unsigned)(short)(u2 / (garr[u2 & 7u] | 1u)));
    } while (i0++ < 4u && a0[i0 & 3u]);
    b0 = (unsigned)(9u && ((0xba41295eu / (7u | 1u)) % (0xf8a32dc3u | 1u))) != 0u;
    L0: if (--fuel == 0u) goto done;
    if ((u3 * 1u)) goto done;
    L1: if (--fuel == 0u) goto done;
    if (u3 == 7u) return 3u;
    v0 = (0xb20b2d41u % ((unsigned)e0 | 1u));
    switch ((unsigned)((int)a0[u1 & 3u] >= (int)0xc5f366c8u) & 7u) {
        *mp = (unsigned)(0x80000000u && (unsigned)(x0 >> 70));
        u2 = ((fuel << (0x7fffffffu & 31u)) + (u2 ? g0 : v0));
    }
    r0.x = (((unsigned)s0 << (v0 & 31u)) | (unsigned)((unsigned)((int)i2 >= (int)(unsigned)e0) && (unsigned)h0));
    if ((unsigned)((short)(unsigned)(m0 || u0) > (signed char)0x10000u)) goto L0;
    if ((9u ^ (unsigned)(x0 >> 70))) {
        goto L2;
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (u2) continue;
        }
        if (0x9d761cddu) {
            goto L2;
            if ((unsigned)e0) goto L0;
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)(0xac4c3d86u && r0.x) << ((unsigned)((int)(unsigned)(short)(unsigned)((unsigned)x0 == (unsigned)((int)fuel < (int)(unsigned)f0)) < (int)(m0 % ((unsigned)b0 | 1u))) & 63u);
                goto L1;
                l0 = (long)((unsigned long)l0 + (r0.x / ((unsigned)((int)(unsigned)(signed char)(unsigned)((int)0x80000000u < (int)p2) < (int)(unsigned)(short)(unsigned)((unsigned)(x0 >> 70) < fuel)) | 1u)));
                if (((unsigned)(signed char)(6u % (0x80000000u | 1u)) / ((unsigned)f0 | 1u))) {
                    L2: if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)!((g0 << (p0 & 31u)) >> ((unsigned)h0 & 31u)) < (int)(0x7fffffffu << (0x10000u & 31u))));
                    w0 ^= (unsigned long long)(*mp * g1) << ((unsigned)((unsigned)((int)p1 >= (int)(unsigned)d0) && (unsigned)(signed char)(unsigned)(9u == (p1 >> (0x80000000u & 31u)))) & 63u);
                } else {
                    if (((unsigned)(*mp || (unsigned)h1) / (p2 | 1u))) continue;
                }
            } while (i0++ < 2u && (unsigned)(short)(unsigned)((int)v0 >= (int)(7u + (unsigned)l0)));
            for (;;) { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t3; double z3; if (((fuel >> ((unsigned)(short)(a0[u1 & 3u] & 0xd5ab36bu) & 31u))) & 1u) { t3 = (unsigned)(7u < garr[i1 & 7u]); z3 = (double)((((*mp * p1) | 0x7866a85u)) & 255u); } if (((fuel >> ((unsigned)(short)(a0[u1 & 3u] & 0xd5ab36bu) & 31u))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                        if ((r0.x + u0)) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)!(unsigned)(a0[u1 & 3u] && v0), p1, (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)*mp)); }
                        if (budget != 0u) { budget -= 1u; u1 = fn2(0x3390a72fu, (unsigned)((short)0x3886c24bu > (signed char)0x36714992u), 0x10000u); }
                        for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                            break; (void)(a0[u1 & 3u]);
                            if ((a0[i0 & 3u] % (u0 | 1u))) break;
                            u2 = ((unsigned)x0 + (p2 / ((unsigned)s1 | 1u)));
                            l0 = (long)((unsigned long)l0 + -(0x80000000u & 0x300e3ea4u));
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(short)(5u | p2) & 0x7f45217u), (unsigned)((int)u2 >= (int)*q0), (~((unsigned)(x0 >> 70) * 0x7fffffffu) + (unsigned)f0)); }
                        m0 ^= ((*q0 / (0x262478fu | 1u)) & (unsigned)((unsigned)b0 || p0));
                    }
                    w0 ^= (unsigned long long)g1 << (((0xffffffffu << (((unsigned)d0 + r0.y) & 31u)) % (*q0 | 1u)) & 63u);
                    while (i2++ < 5u && 7u) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)3u;
                        if ((u0 ? 0x10000u : fuel)) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)x0, (a0[u1 & 3u] | (unsigned)((int)0xffffffffu >= (int)v0)), ~(i2 / ((unsigned)w0 | 1u))); }
                        garr[(unsigned)c1 & 7u] = (unsigned)(((unsigned)(p1 < i1) % (0x7fffffffu | 1u)) || v0);
                    }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn3(u3, (unsigned)(x0 >> 70), (unsigned)(unsigned char)(unsigned)((unsigned)d0 < m0)); }
            }
            if ((i0 ^ (unsigned)!((unsigned)d0 | (unsigned)b0))) goto L4;
        }
        if ((g1 % ((0xffffffffu + 0x10000u) | 1u))) goto L1;
    } else {
        do { if (--fuel == 0u) goto done;
            *q0 += (unsigned)((int)4u < (int)(unsigned)(r0.y && 0x13fbb0c1u));
        } while (i0++ < 6u && garr[i1 & 7u]);
        garr[(r0.x ^ i2) & 7u] = 9u;
        while (i0++ < 4u && -(5u % ((unsigned)(short)(r0.x - 0xd8f68cc8u) | 1u))) { if (--fuel == 0u) goto done;
            garr[(5u % (a0[i0 & 3u] | 1u)) & 7u] = (unsigned)(8u < 0xa6466a3u);
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (*mp) {
                    goto L4;
                    h0 = (short)((unsigned)f0 + 2u);
                    q0 = &garr[3u & 7u];
                }
                c1 = (signed char)(unsigned)((int)(8u - 3u) >= (int)((unsigned)d0 << ((unsigned)s0 & 31u)));
                if (8u) break;
                u1 = 0u;
                L3: if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((0x7e8ff60fu >> ((unsigned)((short)(unsigned)l0 > (signed char)((unsigned)w0 % ((unsigned)h0 | 1u))) & 31u)) & 1023u);
            }
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return (unsigned)!(p2 / ((unsigned)((int)0x10000u >= (int)garr[i1 & 7u]) | 1u));
            }
            if (0xffffffffu) break;
            if (~(g1 / ((unsigned)s1 | 1u))) {
                u2 += u1;
            } else {
                d0 = d0 * 0.5 + (double)(((unsigned)x0 ? m0 : 6u) & 1023u);
                if (((unsigned)s1 * 0x10000u)) {
                    if (u3 == 7u) return (unsigned)((int)(0x80000000u * (unsigned)(x0 >> 70)) >= (int)0x7fffffffu);
                } else {
                    u2 = (unsigned)l0;
                    if (m0) break;
                }
                w0 ^= (unsigned long long)(unsigned)((short)m0 > (signed char)0xffffffffu) << ((0x7fffffffu / ((((unsigned)s1 >> (p0 & 31u)) + (unsigned)s1) | 1u)) & 63u);
            }
            *q0 += 0u;
        }
    }
    if ((unsigned)(0x7fffffffu || (unsigned)l0)) {
        u0 = ((i2 ^ v0) & (unsigned)(unsigned char)(unsigned)((unsigned)x0 == (unsigned)(signed char)(p2 & 0x5612ffd4u)));
        { unsigned t4; double z4; if (((p0 * m0)) & 1u) { t4 = (u0 * (unsigned)b0); z4 = (double)((((unsigned)b0 ? 0x7fffffffu : r0.y)) & 255u); } if (((p0 * m0)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            u1 ^= (u0 & (1u + 0x7fffffffu));
            L4: if (--fuel == 0u) goto done;
            if ((unsigned)(r0.x || (unsigned)f0)) {
                if (((unsigned)!(0xf8055485u % (0xbf717d5cu | 1u)) / (v0 | 1u))) goto L3;
                goto L0;
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((3u * p0) && 0x10000u), u2, (unsigned)(signed char)(8u & 0x14597995u)); }
                *q0 = ((unsigned)c1 / (0x10000u | 1u));
            }
            goto L3;
            goto L0;
            *q0 = u3;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn2((0x80000000u & (unsigned)((short)2u > (signed char)0xbd3306a1u)), (0x80000000u / (0u | 1u)), (unsigned)((short)u2 > (signed char)(unsigned)(x0 >> 70))); }
        a0[*q0 & 3u] = a0[i0 & 3u];
        if (budget != 0u) { budget -= 1u; u3 = fn3(((u3 & fuel) % ((unsigned)(x0 >> 70) | 1u)), (unsigned)!((unsigned)f0 | (unsigned)((int)0xa1dd0c6u >= (int)0xffffffffu)), (unsigned)f0); }
        do { if (--fuel == 0u) goto done;
            i0 = (unsigned)((int)fuel < (int)(unsigned)l0) & 15u;
            { unsigned t5; double z5; if (((u0 | 0xa41a19fcu)) & 1u) { t5 = (unsigned)((unsigned)f0 < a0[u1 & 3u]); z5 = (double)((((garr[i1 & 7u] & 1u) >> (*mp & 31u))) & 255u); } if (((u0 | 0xa41a19fcu)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                garr[(unsigned)(0u == 5u) & 7u] = (unsigned)((int)0u < (int)*q0);
                g1 += (unsigned)((unsigned)e0 == (unsigned)((short)0x80000000u > (signed char)(p1 >> (0xc3d79b37u & 31u))));
                r0.x = (0x7fffffffu | (u2 >> ((0x7fffffffu << (0xe6358843u & 31u)) & 31u)));
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn2(((g1 & (unsigned)f0) * m0), ((unsigned)b0 >> ((unsigned)f0 & 31u)), (a0[i0 & 3u] % ((unsigned)f0 | 1u))); }
                    c1 = (signed char)((5u ? 0x80000000u : (unsigned)s1) % ((unsigned)d0 | 1u));
                }
                r0.x = (unsigned)((int)(unsigned)((unsigned)s0 == (unsigned)h0) >= (int)(unsigned)h1);
                if (budget != 0u) { budget -= 1u; u1 = fn3(*mp, (0x635a1be3u - (unsigned)(9u == p0)), (unsigned)(((unsigned)s0 | 2u) < (unsigned)l0)); }
            }
            for (;;) { if (--fuel == 0u) goto done;
                a0[(unsigned)(signed char)(unsigned)((unsigned)s0 < u2) & 3u] = (unsigned)(signed char)((unsigned)(x0 >> 70) ? (unsigned)x0 : u2);
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)(r0.y && (unsigned)(x0 >> 70)) > (signed char)0xffffffffu), ((unsigned)(x0 >> 70) ? (unsigned)b0 : r0.y), (0u ? 9u : r0.x)); }
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)((short)0x4eb92487u > (signed char)(unsigned)f0) & 1023u);
                }
                l0 = (long)((unsigned long)l0 + (unsigned)s1);
            }
            garr[(unsigned)((int)0xeb9a1ea3u >= (int)p0) & 7u] = ((unsigned)(unsigned char)((unsigned)c1 % ((unsigned)c0 | 1u)) % (a0[u1 & 3u] | 1u));
        } while (i0++ < 7u && (a0[u1 & 3u] + (unsigned)b0));
    }
    switch (~(unsigned)(a0[i0 & 3u] < (unsigned)d0) & 7u) {
        c0 = (unsigned char)(unsigned)l0;
        *q0 += ((unsigned)(m0 && i1) * (unsigned)((int)m0 >= (int)(unsigned)((unsigned)c1 && *q0)));
        switch (((unsigned)(0x9236f8ecu || (unsigned)b0) >> (*mp & 31u)) & 7u) {
            r0.x = (unsigned)b0;
        }
        if (u3 == 7u) return ((unsigned)d0 / ((unsigned)((int)(unsigned)(unsigned char)(m0 ^ 0x9b72df9cu) < (int)a0[i0 & 3u]) | 1u));
        if (i1) break;
        { unsigned t6; double z6; if ((0x80000000u) & 1u) { t6 = (unsigned)((short)i2 > (signed char)((unsigned)(x0 >> 70) % (0x86e939aau | 1u))); z6 = (double)((u3) & 255u); } if ((0x80000000u) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            { unsigned t7; double z7; if ((((0x94244e39u * (unsigned)f0) / ((unsigned)d0 | 1u))) & 1u) { t7 = 0xb3ba3df6u; z7 = (double)(((unsigned)((int)0xd4462e84u >= (int)4u)) & 255u); } if ((((0x94244e39u * (unsigned)f0) / ((unsigned)d0 | 1u))) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                case 6u: ;
            }
            q0 = &garr[*mp & 7u];
            u2 = u2 * 0x9e3779b1u + (unsigned)(((unsigned)f0 + p1) || (unsigned)((int)r0.y >= (int)((unsigned)c1 ^ u1)));
            default: ;
            w0 ^= (unsigned long long)0x10000u << ((((unsigned)b0 >> (i1 & 31u)) / ((unsigned)(x0 >> 70) | 1u)) & 63u);
            switch ((unsigned)h1 & 7u) {
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    v0 = (r0.y / (0xcd8a2feeu | 1u));
                    l0 = (long)((unsigned long)l0 + (unsigned)(p0 || 7u));
                    if (~(0x25e18122u | garr[u2 & 7u])) {
                        u3 = ((7u - a0[u1 & 3u]) | (unsigned)(short)(unsigned)(u2 || 0x6115076bu));
                        u0 = u0 * 0x9e3779b1u + ((unsigned)(r0.x < m0) / (r0.y | 1u));
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)c1, (unsigned)((unsigned)((int)i0 >= (int)(unsigned)f0) == 0x80000000u), 8u); }
                        case 2u: ;
                    } else {
                        u1 = (0x1f0fe8feu >> (((unsigned)s1 ? g0 : v0) & 31u));
                        if (0x80000000u) goto L2;
                        r0.x = (v0 >> (((unsigned)h0 + 0x10000u) & 31u));
                        switch ((unsigned)((unsigned)(w0 >> 29) == (unsigned)(p1 < 7u)) & 7u) {
                            h1 = (unsigned short)(h1 + (unsigned)(((unsigned)l0 >> ((unsigned)h0 & 31u)) && ((p0 * a0[u1 & 3u]) * i0)));
                            q0 = &garr[(unsigned)((unsigned)((short)v0 > (signed char)i2) && (unsigned)((unsigned)((int)0u >= (int)(unsigned)e0) == 9u)) & 7u];
                        }
                    }
                    h0 = (short)((unsigned)h0 >> (((unsigned)c0 * a0[u1 & 3u]) & 31u));
                }
                default: ;
            }
        }
    }
    if (-(0x7fffffffu | (unsigned)(signed char)(r0.x & 0x2ad769fbu))) goto L3;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(g0, ((unsigned)h1 | (unsigned)l0), -(unsigned)(u3 == u0)); }
            u2 += (0x10000u ? u0 : 0x8a7cd96eu);
            if ((u1 * ((unsigned)b0 & 0x365d9a92u))) break;
            c1 = (signed char)g0;
            if (((unsigned)(w0 >> 29) >> ((unsigned)((int)garr[i1 & 7u] >= (int)0x87f2603cu) & 31u))) break;
        } while (i1++ < 6u && (unsigned)(p2 < 0x318c2d3u));
        if ((unsigned)((unsigned)((unsigned)w0 == (unsigned)b0) == a0[u1 & 3u])) {
            e0 = e0 * 0.5L + (long double)(-((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)x0) ? u2 : r0.x) & 1023u);
            if ((r0.x - a0[u1 & 3u])) break;
            break; (void)(7u);
        }
        { unsigned t8; double z8; if ((0x80000000u) & 1u) { t8 = u2; z8 = (double)((-(unsigned)((int)u1 >= (int)(u2 & 0x80000000u))) & 255u); } if ((0x80000000u) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
            if (((unsigned)x0 / ((4u >> ((unsigned)d0 & 31u)) | 1u))) break;
            break; (void)((r0.y >> (i0 & 31u)));
            r0.x = -(1u * (v0 & 8u));
            garr[((unsigned)h1 << (g0 & 31u)) & 7u] = ((0x10000u / (5u | 1u)) * (p2 ? v0 : (unsigned)c0));
            break; (void)(*q0);
        }
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)!(unsigned)(0x66d12bd6u == (unsigned)(*mp == g1)), 0xffffffffu, (unsigned)((unsigned)f0 && 0xacb9f24u)); }
        break; (void)(((unsigned)(x0 >> 70) << (0x10000u & 31u)));
        break; (void)((unsigned)e0);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 7u, 0x161e5ac5u, 0xd369e14u },
        { 13u, 0x7ae5f027u, 0x84d1ceau },
        { 9u, 0xf0df0885u, 0x73d3f5c0u },
        { 4u, 0xa290b92eu, 0x6b36bc88u },
        { 7u, 0x25de052eu, 0x6821b3dau },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
