// test-ssa-source's program of seed 134000416 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x331f3fc6u, g1 = 0x1a33bc12u;
static unsigned garr[8] = { 0x5fd5ddd4u, 0xa49962ccu, 0xa36bb491u, 0x5cc3516bu, 0xefb19e22u, 0xfc9201dfu, 0x963c43bbu, 0x1cf6e184u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    garr[p0 & 7u] = (a0[i0 & 3u] ? (unsigned)((short)((unsigned)c1 / (8u | 1u)) > (signed char)u0) : r0.y);
    L0: if (--fuel == 0u) goto done;
    c1 = (signed char)(unsigned)((unsigned)((unsigned)l0 || 4u) == ((unsigned)(x0 >> 70) ? *mp : 0x7fffffffu));
    L1: if (--fuel == 0u) goto done;
    switch (a0[i0 & 3u] & 7u) {
        while ((p2 ^ (unsigned)(4u && 5u))) { if (--fuel == 0u) goto done;
            *q0 = ((unsigned)c1 + (unsigned)c0);
        }
        { unsigned t0; double z0; if (((r0.x << ((2u + i2) & 31u))) & 1u) { t0 = (1u + (garr[i1 & 7u] + 0x98937aa1u)); z0 = (double)((((unsigned)((short)p2 > (signed char)3u) | 0xdb75a354u)) & 255u); } if (((r0.x << ((2u + i2) & 31u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            L2: if (--fuel == 0u) goto done;
            if (((unsigned)w0 >> (r0.y & 31u))) goto L3;
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((0x7fffffffu / ((unsigned)(*q0 || 0xfc3208e0u) | 1u))) continue;
                if ((9u * i0)) break;
                L3: if (--fuel == 0u) goto done;
            }
            if ((unsigned)e0) {
                b0 = (p0 ^ ((unsigned)s1 % (fuel | 1u))) != 0u;
                w0 ^= (unsigned long long)(unsigned)((int)0x10000u < (int)0xee4885b3u) << ((unsigned)(0x80000000u == (r0.y << (r0.y & 31u))) & 63u);
                b0 = ((unsigned)c0 ? 4u : (unsigned)(i2 || (unsigned)s1)) != 0u;
                if (i0) {
                    L4: if (--fuel == 0u) goto done;
                    g0 = (unsigned)((int)5u < (int)u1);
                    case 0u: ;
                    w0 ^= (unsigned long long)((unsigned)d0 & v0) << (-(unsigned)((unsigned)((int)~((unsigned)b0 & fuel) < (int)9u) && r0.x) & 63u);
                }
                r0.x = (unsigned)((int)i0 >= (int)0x10000u);
            } else {
                garr[((unsigned)(w0 >> 29) & (unsigned)(x0 >> 70)) & 7u] = ((0xbf3c4410u ^ u3) >> ((unsigned)(5u || garr[u2 & 7u]) & 31u));
                *q0 = (((unsigned)h1 >> (p0 & 31u)) << ((m0 % ((unsigned)f0 | 1u)) & 31u));
                *mp = (unsigned)(unsigned char)(unsigned)((unsigned)((short)(4u - (unsigned)b0) > (signed char)(unsigned)h1) == (unsigned)((int)4u < (int)*mp));
            }
            c0 = (unsigned char)(0x80000000u * (unsigned)(short)(0xffffffffu ? 0xce53ec13u : 0x7fffffffu));
        }
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)(a0[i0 & 3u] << ((unsigned)((int)i0 >= (int)u2) & 31u));
            case 7u: ;
            case 5u: ;
            for (;;) { if (--fuel == 0u) goto done;
                case 2u: ;
                if ((unsigned)((short)*mp > (signed char)r0.x)) break;
                default: ;
                case 3u: ;
                case 4u: ;
                c1 = (signed char)~(unsigned)((unsigned)(0x74a117eeu && 0x8ca880d5u) < (unsigned)x0);
            }
            s0 = (int)(unsigned)((unsigned)b0 && ((unsigned)l0 >> ((unsigned)(short)((unsigned)(w0 >> 29) * p1) & 31u)));
            if ((0x10000u & 0x4e83cbfeu)) continue;
        }
        break;
        c0 = (unsigned char)(((unsigned)d0 + 0xad563aa9u) & 0x7fffffffu);
        *mp = (unsigned)c0;
    }
    if ((unsigned)((int)p1 < (int)a0[i0 & 3u])) goto L4;
    goto L1;
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (u0) break;
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)(w0 >> 29) < (int)i0)) break;
                switch (0xacc690a2u & 7u) {
                    c1 = (signed char)(garr[u2 & 7u] << ((unsigned)((short)fuel > (signed char)(unsigned)((unsigned)h1 && ((unsigned)x0 * garr[u2 & 7u]))) & 31u));
                    if (0x7fffffffu) goto L1;
                }
                if ((unsigned)(short)((unsigned)h0 << ((unsigned)((int)(unsigned)f0 >= (int)u2) & 31u))) goto L4;
            }
        }
        b0 = (unsigned)(short)(unsigned)(i0 < g0) != 0u;
    } while (i0++ < 7u && ~(0x10000u | (garr[u2 & 7u] ^ u2)));
    switch (9u & 7u) {
        if ((unsigned)(0x1d3ca49bu || (unsigned)s0)) break;
    }
    d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(unsigned)((short)p0 > (signed char)(unsigned)s1) & 1023u);
    do { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((unsigned)(0x3c2e81aeu || (6u ^ r0.x)) & 1023u);
        if (((i1 - *q0) * i0)) {
            h0 = (short)(unsigned)b0;
            break; (void)((unsigned)((m0 / (p2 | 1u)) || 0xffffffffu));
            u3 += (*mp ? r0.x : 0x10000u);
            u0 = (unsigned)!(0x5d7cdab5u & (a0[i0 & 3u] * (unsigned)(garr[i1 & 7u] < 0x7fffffffu)));
            while (i1++ < 6u && (0xc8ca511u << (p0 & 31u))) { if (--fuel == 0u) goto done;
                if ((0x10000u - 0x10000u)) continue;
                if (0xac89e4edu) break;
                u1 = u1 * 0x9e3779b1u + (unsigned)(((0x1fcf31b8u ? a0[u1 & 3u] : 0x7fffffffu) % (0x10000u | 1u)) && (unsigned)w0);
            }
        } else {
            while ((unsigned)((p1 ^ 0x8ae78c39u) < garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)b0;
                    r0.x = (a0[u1 & 3u] & (unsigned)(fuel || (unsigned)l0));
                    i2 = (3u + -(6u * ((unsigned)e0 + g0))) & 15u;
                    w0 ^= (unsigned long long)0x5832dfadu << (((unsigned)!(unsigned)(0xda875a81u && (unsigned)((short)0xffffffffu > (signed char)0u)) | 0xe27d7e8du) & 63u);
                    r0.x = (a0[u1 & 3u] % (garr[u2 & 7u] | 1u));
                    break; (void)((unsigned)((unsigned)l0 < ((unsigned)x0 >> (p1 & 31u))));
                }
                if ((garr[u2 & 7u] >> (((unsigned)f0 & garr[i1 & 7u]) & 31u))) break;
                do { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)(u3 == (unsigned)b0)) break;
                        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                            garr[(unsigned)((short)7u > (signed char)i1) & 7u] = ((((unsigned)h1 >> (7u & 31u)) % (0x5f4956ebu | 1u)) >> ((unsigned)x0 & 31u));
                            break; (void)((unsigned)(0xffffffffu && i1));
                        }
                        u0 += (unsigned)((int)(unsigned)(p2 || 0x10000u) >= (int)(unsigned)((int)i1 < (int)(unsigned)c0));
                        c0 = (unsigned char)((unsigned)((short)v0 > (signed char)(unsigned)((*mp % (0x80000000u | 1u)) < i2)) << (0x7fffffffu & 31u));
                    } while (i0++ < 7u && (a0[u1 & 3u] % ((unsigned)(0xffffffffu < (unsigned)(x0 >> 70)) | 1u)));
                    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)e0) {
                            u0 = ((unsigned)((int)(u3 | 0x1b97834bu) >= (int)(unsigned)h0) / ((unsigned)((short)fuel > (signed char)(unsigned)h1) | 1u));
                            s0 = (int)(unsigned)!((unsigned)((int)((p0 - (unsigned)l0) >> (u2 & 31u)) < (int)fuel) << (u2 & 31u));
                            q0 = &garr[((i1 / ((unsigned)d0 | 1u)) ^ (unsigned)(x0 >> 70)) & 7u];
                        }
                        if (i0) {
                            r0.x = (i2 * 0xffffffffu);
                            f0 = f0 * 0.5f + (float)(6u & 255u);
                            s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)(short)((unsigned)x0 % ((unsigned)e0 | 1u)) < (int)(0x8855afd7u * (unsigned)x0)));
                            b0 = (5u + i0) != 0u;
                            if (((unsigned)x0 - g1)) break;
                            *q0 += (0x7fffffffu / ((unsigned)(x0 >> 70) | 1u));
                        } else {
                            h1 = (unsigned short)(h1 + ~(((2u | u0) + (unsigned)f0) % (0x80000000u | 1u)));
                        }
                        e0 = e0 * 0.5L + (long double)((p1 * i0) & 1023u);
                        if (((unsigned)(x0 >> 70) & (unsigned)h1)) goto L0;
                        break; (void)((unsigned)s0);
                    }
                    h1 = (unsigned short)(h1 + ((u3 << (garr[u2 & 7u] & 31u)) & (unsigned)(g1 < a0[u1 & 3u])));
                    h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)((int)0xffffffffu < (int)((g0 & (unsigned)d0) | i0)) > (signed char)(unsigned)f0));
                    while (i0++ < 7u && (unsigned)((short)p2 > (signed char)m0)) { if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(0x7fffffffu - *q0);
                    }
                } while (i2++ < 3u && 0xffffffffu);
                q0 = &garr[(unsigned)!(((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)c1) << (5u & 31u)) ? garr[u2 & 7u] : *q0) & 7u];
                garr[*q0 & 7u] = ((unsigned)c0 ? (0x7fffffffu / ((unsigned)c0 | 1u)) : (unsigned)((unsigned)(x0 >> 70) || 0xffffffffu));
                if ((unsigned)!(unsigned)((int)r0.y >= (int)0x47421fa7u)) break;
            }
            if ((unsigned)(0xffffffffu && 0x10000u)) break;
            while (i1++ < 5u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)(a0[i0 & 3u] && 0x10000u) & 1023u);
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    u0 += 0xa95f82a0u;
                    u2 = u2 * 0x9e3779b1u + (unsigned)((short)1u > (signed char)(i2 % (*q0 | 1u)));
                    if (0x81cb0788u) break;
                }
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)(r0.y);
                }
                do { if (--fuel == 0u) goto done;
                    u2 = u2 * 0x9e3779b1u + a0[i0 & 3u];
                    if ((((unsigned)d0 >> ((unsigned)e0 & 31u)) * a0[u1 & 3u])) continue;
                    if (fuel < 8u) return (unsigned)(short)(unsigned)((r0.y & 4u) == (unsigned)((unsigned)s1 == (unsigned)l0));
                    if ((unsigned)((unsigned)((int)v0 >= (int)(unsigned)w0) == 0x113096f9u)) break;
                } while (i2++ < 4u && ((unsigned)h0 - (unsigned)(u0 && 0x10000u)));
                break; (void)((unsigned)h0);
                if (g0) continue;
            }
        }
    } while (i0++ < 6u && -((unsigned)b0 << (a0[i0 & 3u] & 31u)));
    if ((0xad4c3e61u + p2)) {
        g0 = (unsigned)((int)i0 < (int)-(unsigned)((int)p0 < (int)8u));
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)(unsigned char)(unsigned)(((3u / (2u | 1u)) * (unsigned)l0) && (unsigned)(signed char)(unsigned)((int)0xa004ad51u < (int)i1));
            g0 = ((unsigned)(short)(unsigned)(u0 || u0) ^ 1u);
            f0 = f0 * 0.5f + (float)(((m0 ^ garr[u2 & 7u]) * *q0) & 255u);
        }
        s1 = (int)((unsigned)s1 + (unsigned)!((unsigned)!(unsigned)((unsigned)h1 && i0) * -(unsigned)((int)2u < (int)(unsigned)s0)));
        m0 ^= (unsigned)(((unsigned)x0 * 0x10000u) == (unsigned)(signed char)(*mp * u1));
        if ((unsigned)c0) goto L4;
    }
    if ((unsigned)(unsigned char)(r0.x - (unsigned)((int)u3 < (int)u1))) goto done;
    if (0x80000000u) goto L3;
    if (((unsigned)s1 | ((unsigned)s0 & i0))) goto L1;
    g1 += (g1 ^ 0x10000u);
    if (u2) goto L4;
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((p2 | (v0 / (garr[i1 & 7u] | 1u)))) break;
            switch ((-(unsigned)((int)3u < (int)0x220aa98u) - u0) & 7u) {
                for (;;) { if (--fuel == 0u) goto done;
                    case 4u: ;
                    case 5u: ;
                    w0 = w0 * 6364136223846793005ull + (0x7fffffffu / (i2 | 1u));
                    case 6u: ;
                }
                default: ;
                m0 ^= (a0[u1 & 3u] << ((unsigned)x0 & 31u));
                s0 = (int)((unsigned)l0 / (u2 | 1u));
                e0 = e0 * 0.5L + (long double)(0x6f4bd61cu & 1023u);
                if ((0x309e0b14u >> (0xdee3d9d2u & 31u))) {
                    u1 ^= (0x24c9da5bu + u3);
                    e0 = e0 * 0.5L + (long double)((unsigned)(((unsigned)c1 << ((unsigned)d0 & 31u)) < (unsigned)((unsigned)(0x80000000u == 9u) || (unsigned)l0)) & 1023u);
                    if (u0) goto L2;
                    if ((p0 & fuel)) {
                        do { if (--fuel == 0u) goto done;
                            h0 = (short)((g1 % (0x7fffffffu | 1u)) * p1);
                            if ((unsigned)(0x83338ca8u || p1)) continue;
                            g0 = -((unsigned)c1 / ((unsigned)!((unsigned)(signed char)((unsigned)e0 % (u2 | 1u)) | (u0 | (unsigned)h0)) | 1u));
                            u0 += (unsigned)((int)(unsigned)(x0 >> 70) < (int)*q0);
                            s0 = (int)((m0 + garr[u2 & 7u]) % ((unsigned)(short)((fuel >> (5u & 31u)) / (0x7fffffffu | 1u)) | 1u));
                        } while (i2++ < 2u && (unsigned)((short)(unsigned)b0 > (signed char)m0));
                        case 7u: ;
                        u2 ^= a0[u1 & 3u];
                        s0 = (int)((unsigned)(0xffffffffu == 0x10000u) & (unsigned)s1);
                    } else {
                        if ((unsigned)((unsigned)((short)0x33515d34u > (signed char)a0[u1 & 3u]) < r0.y)) {
                            *mp = (unsigned)(m0 || (unsigned)((unsigned)h0 < r0.y));
                            goto L3;
                            d0 = d0 * 0.5 + (double)(((unsigned)s0 + 0xfe8293ebu) & 1023u);
                        }
                        break;
                        v0 = (unsigned)((short)(0x10000u & (unsigned)s0) > (signed char)((unsigned)((unsigned)s1 || 0x80000000u) << ((unsigned)c0 & 31u)));
                        break;
                    }
                    r0.x = (unsigned)((unsigned)f0 || (unsigned)!(unsigned)(u3 == (0xe6f5b639u * a0[u1 & 3u])));
                    if (9u) {
                        if ((unsigned)(unsigned char)(unsigned)((short)7u > (signed char)((unsigned)c0 >> ((unsigned)c0 & 31u)))) goto L2;
                        e0 = e0 * 0.5L + (long double)(~(0x7fffffffu ? r0.x : (unsigned)(i1 || (unsigned)b0)) & 1023u);
                    } else {
                        *mp = ~((unsigned)w0 << ((m0 * u0) & 31u));
                        s0 = (int)-((fuel >> (p2 & 31u)) / ((unsigned)w0 | 1u));
                        if (fuel < 8u) return (unsigned)(*q0 == 0x7fffffffu);
                        *q0 = (((unsigned)s0 >> (5u & 31u)) % (0x10000u | 1u));
                    }
                }
            }
        }
        { unsigned t1; double z1; if ((((unsigned)h0 + (unsigned)s1)) & 1u) { t1 = ((unsigned)(short)(0x73b213e1u | 0x10000u) / (0u | 1u)); z1 = (double)(((unsigned)((int)i0 < (int)(unsigned)s0)) & 255u); } if ((((unsigned)h0 + (unsigned)s1)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            s1 = (int)((unsigned)s1 + (unsigned)((int)0x9eb475a5u < (int)1u));
            u2 = (((unsigned)(x0 >> 70) ^ garr[i1 & 7u]) * (unsigned)c1);
            { unsigned t2; double z2; if ((0x38250dfbu) & 1u) { t2 = (unsigned)w0; z2 = (double)((r0.y) & 255u); } if ((0x38250dfbu) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                q0 = &garr[fuel & 7u];
                if ((0x167b0e0cu / ((unsigned)x0 | 1u))) {
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)(garr[u2 & 7u] < (unsigned)(signed char)(unsigned)((int)(unsigned)l0 >= (int)0x4d74a426u))) goto L3;
                        if ((0x80000000u % (3u | 1u))) break;
                        do { if (--fuel == 0u) goto done;
                            u0 = (unsigned)(((unsigned)f0 - (unsigned)w0) == (0xf6b8267u ^ ((unsigned)h1 * 0x836ae5a6u)));
                            *q0 += (unsigned)((unsigned)((a0[u1 & 3u] ? i1 : (unsigned)w0) || 0x10000u) < 0x3075587fu);
                        } while (i2++ < 6u && (unsigned)x0);
                    } while (i1++ < 2u && (unsigned)((0x43f9cb71u / (v0 | 1u)) == (unsigned)l0));
                    if (0x80000000u) {
                        if ((4u ^ ((unsigned)l0 % (i0 | 1u)))) break;
                        if (((unsigned)s1 * i1)) break;
                        e0 = e0 * 0.5L + (long double)(((p1 >> (u1 & 31u)) | ((unsigned)(unsigned char)((unsigned)d0 + fuel) + u1)) & 1023u);
                        u0 = u0 * 0x9e3779b1u + (unsigned)((int)(0x10000u | (unsigned)x0) >= (int)((unsigned)c1 + 0xb7a8f13fu));
                        if ((unsigned)(short)(unsigned)((int)(unsigned)(0x80000000u == i0) < (int)0x808d1c1cu)) break;
                    } else {
                        *q0 = ((0x3706613eu * 0xcf93462eu) << ((p2 | ((unsigned)c0 - 0u)) & 31u));
                        if ((unsigned)(0x7bd5fc5u < u0)) break;
                        *q0 += (unsigned)((int)9u < (int)0x10000u);
                        c1 = (signed char)(unsigned)b0;
                    }
                    b0 = (((unsigned)l0 % (0x84d6460du | 1u)) ^ (unsigned)w0) != 0u;
                }
                if (((unsigned)s1 + (*mp >> (p2 & 31u)))) {
                    if (((unsigned)s0 ^ g1)) break;
                    if ((unsigned)((int)0x10000u >= (int)a0[i0 & 3u])) continue;
                } else {
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)x0);
                        if ((unsigned)(signed char)((3u | garr[i1 & 7u]) / (0xffffffffu | 1u))) break;
                        break; (void)(*mp);
                        g0 = (unsigned)s0;
                    }
                    if (((unsigned)h1 | ((unsigned)s0 / (r0.y | 1u)))) continue;
                    *q0 = ((0x10000u >> (garr[i1 & 7u] & 31u)) - (unsigned)(0x80000000u == (u1 | 0x3405d339u)));
                    break; (void)(p1);
                }
            }
            if ((3u << (u0 & 31u))) continue;
            h1 = (unsigned short)(h1 + 1u);
        }
        if (~((unsigned)((unsigned)e0 == 3u) * (unsigned)d0)) break;
        r0.x = (unsigned)((int)0x10000u < (int)u1);
        g0 = ((unsigned)(x0 >> 70) ? 0xbb5de510u : (0xec8dce02u + u1));
    } while (i0++ < 6u && ((p1 / ((unsigned)b0 | 1u)) & u0));
    u3 += ((unsigned)(w0 >> 29) / (((unsigned)b0 ^ (unsigned)((int)(unsigned)(0x80000000u < 0xaf839c0fu) >= (int)g1)) | 1u));
    { unsigned t3; double z3; if (((unsigned)c0) & 1u) { t3 = ((unsigned)h0 - (unsigned)((int)0x1bed3609u >= (int)5u)); z3 = (double)((((unsigned)l0 | 0xd44f50c1u)) & 255u); } if (((unsigned)c0) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        if (i0) goto L2;
        switch (0x1e39e54u & 7u) {
            case 7u: ;
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            u2 += (unsigned)((unsigned)(signed char)((unsigned)h0 | (fuel - 0xffffffffu)) && m0);
            m0 ^= ((unsigned)s0 & (garr[u2 & 7u] * ((unsigned)!(u0 | 0u) - (unsigned)x0)));
            *q0 = (unsigned)((int)(unsigned)(i2 && (unsigned)((unsigned)(unsigned char)(0x2e9ba0fau / (i0 | 1u)) < 0x7fffffffu)) < (int)(unsigned)d0);
            if (((unsigned)b0 & p2)) continue;
            u3 += ((unsigned)s1 << (((unsigned)(0x10000u == 0x7fffffffu) ^ v0) & 31u));
            if ((unsigned)s0) {
                if (fuel < 8u) return a0[u1 & 3u];
                v0 = ((unsigned)f0 ? u1 : (unsigned)s0);
                r0.y ^= (unsigned)((unsigned)b0 == 0xe37ea69eu);
                if ((u2 | 0xffffffffu)) goto L1;
            }
        }
        if ((unsigned)((int)((unsigned)s0 - (unsigned)e0) < (int)u2)) {
            if ((0x2d36788fu | 0x7fffffffu)) goto L3;
        }
        for (;;) { if (--fuel == 0u) goto done;
            break; (void)(*mp);
            if (m0) continue;
            if ((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)((int)0x8215b32du < (int)garr[i1 & 7u]))) {
                garr[((unsigned)h1 - 9u) & 7u] = (8u ? (unsigned)f0 : u3);
                if ((unsigned)!((unsigned)l0 * (unsigned)f0)) break;
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(i0 && (9u >> (0xffffffffu & 31u))) && (unsigned)((unsigned)l0 < 0xe17b4d7du)) & 255u);
                w0 ^= (unsigned long long)(a0[u1 & 3u] / (u0 | 1u)) << ((0x7fffffffu - (unsigned)((unsigned)((int)(unsigned)l0 < (int)(unsigned)((int)(unsigned)w0 < (int)0x2000f2f3u)) && 3u)) & 63u);
                { unsigned t4; double z4; if (((((unsigned)f0 * (unsigned)(x0 >> 70)) | (unsigned)c1)) & 1u) { t4 = 9u; z4 = (double)((((p2 * 7u) / (6u | 1u))) & 255u); } if (((((unsigned)f0 * (unsigned)(x0 >> 70)) | (unsigned)c1)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                    u2 = u2 * 0x9e3779b1u + ((unsigned)e0 % (0x7d50f26au | 1u));
                    e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)(unsigned)((unsigned)(0x10000u || r0.y) == r0.y) & 1023u);
                    if (((unsigned)c1 + p2)) {
                        a0[0xe7f2a21cu & 3u] = v0;
                        if ((unsigned)l0) break;
                        v0 = (unsigned)!(unsigned)((int)i0 < (int)1u);
                        if (((unsigned)((short)r0.y > (signed char)u1) / (i0 | 1u))) continue;
                        goto done;
                    }
                    if (((unsigned)c0 ^ (0x80000000u * r0.y))) break;
                    c1 = (signed char)3u;
                }
            } else {
                if ((a0[u1 & 3u] | (unsigned)(a0[i0 & 3u] == garr[u2 & 7u]))) break;
                a0[(7u - 2u) & 3u] = 0x10000u;
            }
            w0 ^= (unsigned long long)(unsigned)(0x5b950a8u || 0x1db1f49du) << ((unsigned)c0 & 63u);
            continue; (void)((unsigned)(9u && 0xe4783480u));
        }
    }
    r0.y ^= (unsigned)((short)u0 > (signed char)(unsigned)((int)(unsigned)h1 < (int)(0x80000000u - (unsigned)(0x80000000u == (unsigned)c1))));
    for (;;) { if (--fuel == 0u) goto done;
        b0 = (unsigned)((short)(unsigned)h0 > (signed char)(3u / (r0.x | 1u))) != 0u;
        if (u3 == 7u) return (unsigned)((unsigned)(short)(i1 % (u3 | 1u)) || (r0.x - 8u));
        { unsigned t5; double z5; if (((unsigned)((int)(0xa8da9882u & u3) >= (int)u1)) & 1u) { t5 = (g1 + 0x10000u); z5 = (double)((p1) & 255u); } if (((unsigned)((int)(0xa8da9882u & u3) >= (int)u1)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            switch (a0[u1 & 3u] & 7u) {
                *q0 = (p2 % ((unsigned)(signed char)(unsigned)((int)(unsigned)((int)(unsigned)h1 >= (int)i2) < (int)(fuel + p2)) | 1u));
                if (i1) goto L3;
                if (fuel < 8u) return u3;
                if (fuel < 8u) return g1;
                v0 = (0x48287f71u * (unsigned)((short)fuel > (signed char)v0));
                while (i1++ < 3u && ((unsigned)(i1 && g0) % (0x811e50dau | 1u))) { if (--fuel == 0u) goto done;
                    case 5u: ;
                    if ((unsigned)(unsigned char)(0xffffffffu << ((unsigned)((short)0x10000u > (signed char)8u) & 31u))) continue;
                }
            }
            while (i1++ < 4u && 0x893d7981u) { if (--fuel == 0u) goto done;
                if ((unsigned)h1) break;
                garr[(0xa2fd67dbu / (u3 | 1u)) & 7u] = (unsigned)(r0.x && (i1 % (0x80000000u | 1u)));
                r0.x = (((unsigned)(u2 || g0) & (0x80000000u | (unsigned)c1)) ^ 2u);
                r0.x = (unsigned)(g1 < (0xd0cebb00u >> ((unsigned)h1 & 31u)));
                v0 = *mp;
            }
            if (r0.x) continue;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)w0 ? (unsigned)f0 : *mp)) break;
                break; (void)(u3);
                switch (-(garr[i1 & 7u] & (unsigned)w0) & 7u) {
                    case 1u: ;
                    s0 = (int)((0x10000u / (u2 | 1u)) / (*q0 | 1u));
                }
                if ((unsigned)(unsigned char)(p1 - (4u << ((unsigned)h1 & 31u)))) break;
                if (~(unsigned)((int)0x4247845u >= (int)a0[u1 & 3u])) break;
                u0 += (unsigned)((short)(unsigned)(i1 && (unsigned)(a0[u1 & 3u] || (unsigned)h0)) > (signed char)0x93ba5e3bu);
            }
            if ((unsigned)c0) goto L0;
        }
        if ((unsigned)h1) {
            e0 = e0 * 0.5L + (long double)((((unsigned)f0 << (~(2u ? g0 : 0xffffffffu) & 31u)) ^ m0) & 1023u);
        }
    }
    if ((u2 - fuel)) goto L0;
    goto L2;
    c1 = (signed char)((unsigned)(w0 >> 29) | i1);
    e0 = e0 * 0.5L + (long double)((unsigned)!(unsigned)((short)(4u + 0x7fffffffu) > (signed char)((p1 << (fuel & 31u)) % ((unsigned)c1 | 1u))) & 1023u);
    goto L0;
    l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)e0 & (unsigned)(short)(unsigned)(p1 < (unsigned)((int)i0 >= (int)(unsigned)c1))) < (int)*mp));
    goto L4;
    if ((unsigned)((unsigned)l0 == (unsigned)c0)) {
        u1 = (unsigned)(((unsigned)h1 * (unsigned)l0) < (p2 * r0.x));
    } else {
        l0 = (long)((unsigned long)l0 + -(0x126a23beu * (unsigned)(0x10000u || 0x7fffffffu)));
    }
    if ((unsigned)c0) {
        q0 = &garr[(unsigned)((unsigned)l0 || (unsigned)(0x80000000u < 0x71fec9c6u)) & 7u];
        if (((unsigned)h0 << (p2 & 31u))) goto L3;
        switch ((unsigned)(0xffffffffu == (unsigned)((short)p1 > (signed char)(unsigned)x0)) & 7u) {
            switch ((unsigned)(g1 < 0xffffffffu) & 7u) {
                case 5u: ;
                { unsigned t6; double z6; if (((unsigned)(((unsigned)s1 * (unsigned)e0) < a0[i0 & 3u])) & 1u) { t6 = (unsigned)((short)4u > (signed char)(0x80000000u - u0)); z6 = (double)((((unsigned)c1 - (a0[i0 & 3u] + garr[u2 & 7u]))) & 255u); } if (((unsigned)(((unsigned)s1 * (unsigned)e0) < a0[i0 & 3u])) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                    case 7u: ;
                    if (g0) {
                        default: ;
                        a0[v0 & 3u] = (unsigned)((unsigned)x0 < (2u - (0xcfcd68d1u - p2)));
                        f0 = f0 * 0.5f + (float)(((((unsigned)d0 ? u1 : (unsigned)l0) / ((unsigned)x0 | 1u)) & g0) & 255u);
                        if (0xffffffffu) break;
                        s1 = (int)((unsigned)s1 + ((unsigned)w0 % ((0xffffffffu - 7u) | 1u)));
                    }
                    while (i0++ < 4u && (a0[i0 & 3u] << ((4u ^ 0x7fffffffu) & 31u))) { if (--fuel == 0u) goto done;
                        case 0u: ;
                        case 3u: ;
                        m0 ^= 0xf8da4336u;
                    }
                    case 4u: ;
                    if ((unsigned)s1) goto L0;
                    u0 = ((i2 << ((unsigned)l0 & 31u)) % ((0x216258ccu >> (i2 & 31u)) | 1u));
                }
                break;
            }
            u2 += (0x6fe08badu << (-(i1 / (*mp | 1u)) & 31u));
            case 5u: ;
            if (((unsigned)((int)0u < (int)a0[i0 & 3u]) | fuel)) break;
            if ((unsigned)(short)(p2 % ((unsigned)d0 | 1u))) goto L0;
        }
    } else {
        s1 = (int)((unsigned)s1 + (unsigned)!(unsigned)((short)p1 > (signed char)((unsigned)c1 << ((unsigned)((p1 & 0x7fffffffu) < i2) & 31u))));
    }
    if ((unsigned)((int)(unsigned)c1 < (int)u2)) goto L4;
    if ((unsigned)(*mp < *mp)) goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    m0 ^= (unsigned)((unsigned)(1u == (unsigned)(u0 && (i2 / (i1 | 1u)))) == *mp);
    switch ((unsigned)(unsigned char)(0x80000000u << ((unsigned)((unsigned)h1 || r0.y) & 31u)) & 7u) {
        h1 = (unsigned short)(h1 + (i1 << ((*q0 >> (0x80000000u & 31u)) & 31u)));
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0(6u, (unsigned)(a0[i0 & 3u] == ((unsigned)c0 - 0xffffffffu)), 0xbcbcc8bbu); }
            if ((unsigned)((unsigned)(unsigned char)(0x10000u & g1) < (unsigned)(x0 >> 70))) {
                case 3u: ;
                if (a0[i0 & 3u]) break;
            }
            if (u3 == 7u) return *mp;
            if ((0x73e0cda0u | (unsigned)c0)) {
                case 6u: ;
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)l0 ^ (unsigned)(w0 >> 29)), ((unsigned)w0 % (~(r0.y >> (a0[u1 & 3u] & 31u)) | 1u)), (0x80000000u ? (unsigned)h1 : (unsigned)w0)); }
                h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)(0x10000u < (v0 & 0x10000u)) >= (int)garr[i1 & 7u]));
                if ((i1 | 7u)) continue;
                if ((unsigned)(i2 < fuel)) break;
            } else {
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(unsigned)((short)(unsigned)((unsigned)(x0 >> 70) || r0.y) > (signed char)r0.x), (unsigned)((unsigned)h0 == u1), (unsigned)(u3 < r0.y)); }
                g1 += (unsigned)((int)(unsigned)(p1 < (unsigned)(w0 >> 29)) < (int)(unsigned)(x0 >> 70));
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((i0 ^ g1) < (unsigned)x0), (u2 - (unsigned)!((unsigned)h0 * 0x6d53d7c8u)), -(u2 << ((unsigned)((unsigned)h0 || garr[i1 & 7u]) & 31u))); }
            }
            v0 = (v0 | (a0[i0 & 3u] * (unsigned)d0));
            while (i1++ < 4u && m0) { if (--fuel == 0u) goto done;
                if (((0xffffffffu | a0[u1 & 3u]) & u1)) break;
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)b0) break;
                    L0: if (--fuel == 0u) goto done;
                    if ((*mp / (0x80000000u | 1u))) break;
                }
                c0 = (unsigned char)0x80000000u;
                i1 = (unsigned)((short)garr[i1 & 7u] > (signed char)((unsigned)(unsigned char)(unsigned)((unsigned)d0 == 2u) ? v0 : 2u)) & 15u;
                q0 = &garr[((garr[i1 & 7u] << ((a0[u1 & 3u] * (unsigned)(x0 >> 70)) & 31u)) / ((0x2ad12523u % (0x64355f17u | 1u)) | 1u)) & 7u];
                case 1u: ;
            }
        } while (i0++ < 2u && (0x4af5a065u | (r0.y << (*mp & 31u))));
        q0 = &garr[(unsigned)((unsigned)s1 || (garr[i1 & 7u] + (i1 + (m0 & (unsigned)b0)))) & 7u];
        default: ;
    }
    w0 ^= (unsigned long long)(unsigned)(garr[i1 & 7u] < 0x426b7b63u) << ((u3 ^ 0x6f2af387u) & 63u);
    if ((1u & p0)) goto L3;
    { unsigned t0; double z0; if ((0x10000u) & 1u) { t0 = (unsigned)x0; z0 = (double)(((unsigned)c1) & 255u); } if ((0x10000u) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        a0[(unsigned)((int)i2 >= (int)(unsigned)h1) & 3u] = (unsigned)(short)(unsigned)((int)((unsigned)c0 - *q0) >= (int)((unsigned)c1 ? 0x78c83c6fu : 0x1f4808ffu));
    }
    if (u3 == 7u) return -((unsigned)((int)u0 < (int)(unsigned)s1) ^ p0);
    d0 = d0 * 0.5 + (double)((0xad116ba9u | (fuel ? (unsigned)w0 : v0)) & 1023u);
    if (0x10000u) goto L4;
    goto L3;
    d0 = d0 * 0.5 + (double)((unsigned)h1 & 1023u);
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((p2 ^ (unsigned)(unsigned char)(unsigned)((unsigned)c0 || *mp))) break;
        if ((unsigned)((int)7u < (int)(i0 - a0[i0 & 3u]))) {
            do { if (--fuel == 0u) goto done;
                c1 = (signed char)((unsigned)s0 % ((i1 ^ 0xffffffffu) | 1u));
                switch (((unsigned)f0 * g0) & 7u) {
                    case 2u: ;
                    switch ((unsigned)((int)i1 >= (int)(unsigned)h1) & 7u) {
                        if (((unsigned)(x0 >> 70) ^ (unsigned)(i0 == p2))) goto done;
                        *q0 += ((2u / (m0 | 1u)) ^ (unsigned)c0);
                    }
                    if ((unsigned)x0) continue;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(unsigned)((0xd9a5e6a5u | u1) < u0), (unsigned)((1u - p0) || r0.x), (((unsigned)c0 & m0) + i2)); }
                }
            } while (i1++ < 5u && (unsigned)(signed char)(unsigned)((unsigned)s0 || 0x7ff48053u));
            u1 = u1 * 0x9e3779b1u + (unsigned)((int)u0 >= (int)(unsigned)((int)(unsigned)f0 < (int)0xffffffffu));
            if ((unsigned)(short)(0x80000000u * (unsigned)l0)) {
                { unsigned t1; double z1; if (((unsigned)(unsigned char)(unsigned)(u0 == (unsigned)(short)(unsigned)((unsigned)c1 < 0x7fffffffu))) & 1u) { t1 = ((0x72f223c7u * (unsigned)s0) & (unsigned)w0); z1 = (double)(((unsigned)h1) & 255u); } if (((unsigned)(unsigned char)(unsigned)(u0 == (unsigned)(short)(unsigned)((unsigned)c1 < 0x7fffffffu))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    l0 = (long)((unsigned long)l0 + p0);
                    while (*mp) { if (--fuel == 0u) goto done;
                        *mp = ((*q0 >> (m0 & 31u)) * (unsigned)((short)(unsigned)x0 > (signed char)(unsigned)l0));
                        if ((2u + g0)) break;
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn0(0x1924d656u, (p0 - (unsigned)w0), (0u ^ a0[u1 & 3u])); }
                    switch ((unsigned)!(u0 | ((unsigned)w0 + (unsigned)f0)) & 7u) {
                        case 3u: ;
                        case 5u: ;
                        e0 = e0 * 0.5L + (long double)((unsigned)(a0[i0 & 3u] < (unsigned)(0x8720aacau < 0xffffffffu)) & 1023u);
                        if ((unsigned)(short)((unsigned)s1 * (unsigned)(0x10000u && (unsigned)b0))) {
                            h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)((int)(unsigned)(unsigned char)((unsigned)(w0 >> 29) + 0xee530f0fu) >= (int)0x80000000u) < (int)(unsigned)w0));
                            if (*mp) goto L4;
                            L1: if (--fuel == 0u) goto done;
                            case 2u: ;
                            if ((u0 + (unsigned)(unsigned char)(unsigned)((int)(unsigned)l0 < (int)fuel))) continue;
                        } else {
                            L2: if (--fuel == 0u) goto done;
                            goto L4;
                            default: ;
                        }
                        goto done;
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((r0.y % (0xffffffffu | 1u)), (((unsigned)c0 ^ i0) / (u0 | 1u)), (unsigned)e0); }
                }
                garr[0x10000u & 7u] = (unsigned)(v0 < (unsigned)(i0 < 2u));
                if ((unsigned)((6u >> (r0.y & 31u)) < g1)) break;
                f0 = f0 * 0.5f + (float)(((unsigned)h1 / ((unsigned)((unsigned)h0 && (i0 % ((unsigned)c0 | 1u))) | 1u)) & 255u);
                u3 += i2;
            }
        }
        *q0 = ((unsigned)((unsigned)((unsigned)(x0 >> 70) || p2) < (unsigned)d0) << ((2u / (0x80000000u | 1u)) & 31u));
        { unsigned t2; double z2; if (((i0 >> ((v0 + i0) & 31u))) & 1u) { t2 = (p2 - (unsigned)((unsigned)d0 < 0x7fffffffu)); z2 = (double)((~(unsigned)((unsigned)s1 && 0x9b6fcf16u)) & 255u); } if (((i0 >> ((v0 + i0) & 31u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            b0 = (((unsigned)(short)(garr[i1 & 7u] << (2u & 31u)) ^ (unsigned)d0) << (0x7fffffffu & 31u)) != 0u;
            a0[(unsigned)(r0.y && 0x41a58a23u) & 3u] = u3;
            s1 = (int)((unsigned)s1 + (unsigned)((int)a0[i0 & 3u] < (int)(g0 + (unsigned)((unsigned)x0 == 9u))));
        }
        L3: if (--fuel == 0u) goto done;
        break; (void)((unsigned)(g0 < (unsigned)h0));
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        q0 = &garr[(unsigned)((unsigned)((int)(unsigned)e0 < (int)u1) && (unsigned)((int)m0 >= (int)(unsigned)((unsigned)h0 < 4u))) & 7u];
        m0 ^= -(0x10000u / ((unsigned)((int)i1 < (int)(unsigned)(w0 >> 29)) | 1u));
        v0 = ((garr[u2 & 7u] / (i2 | 1u)) | (unsigned)((unsigned)h1 || (garr[u2 & 7u] << (a0[u1 & 3u] & 31u))));
        do { if (--fuel == 0u) goto done;
            if ((*mp + (p2 / (0x1515c02eu | 1u)))) break;
        } while (i1++ < 7u && u2);
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                switch ((0xbcf09ad4u >> (u0 & 31u)) & 7u) {
                    if (budget != 0u) { budget -= 1u; u3 = fn0(i2, ((unsigned)h1 - (p2 * 0x2c3623dbu)), (unsigned)((int)r0.y >= (int)a0[u1 & 3u])); }
                }
                break; (void)((unsigned)((a0[i0 & 3u] ^ 0u) < 4u));
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t3; double z3; if ((fuel) & 1u) { t3 = p0; z3 = (double)(((unsigned)((short)8u > (signed char)(unsigned)(u2 < 0x10000u))) & 255u); } if ((fuel) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        u0 = (unsigned)(-(unsigned)(((unsigned)x0 % ((unsigned)s0 | 1u)) < 5u) == (unsigned)((int)0x7ec2891fu < (int)r0.y));
                    }
                    do { if (--fuel == 0u) goto done;
                        if (*q0) break;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((u0 / (0x7fffffffu | 1u)), (unsigned)(unsigned char)(unsigned)((int)((unsigned)h0 % (0x80000000u | 1u)) < (int)garr[u2 & 7u]), (unsigned)((unsigned)d0 == 6u)); }
                        i2 = 0x314c14c9u & 15u;
                        w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)w0 < (unsigned)l0);
                        u2 = (g1 | ((unsigned)(w0 >> 29) ? (unsigned)b0 : 0x717cf59au));
                        if (budget != 0u) { budget -= 1u; u3 = fn0(1u, (unsigned)((short)(unsigned)((int)(unsigned)x0 >= (int)p0) > (signed char)(unsigned)x0), u0); }
                    } while (i1++ < 3u && (unsigned)((int)(2u >> (0u & 31u)) < (int)r0.y));
                }
                if ((unsigned)h0) break;
            } while (i2++ < 6u && ((i2 & (unsigned)c1) % (garr[i1 & 7u] | 1u)));
            r0.x = (unsigned)((unsigned)(x0 >> 70) || 6u);
            if ((unsigned)s0) goto L0;
        }
    }
    if (garr[i1 & 7u]) goto done;
    if ((garr[u2 & 7u] * (g0 * m0))) goto L3;
    do { if (--fuel == 0u) goto done;
        if ((((unsigned)(w0 >> 29) % ((unsigned)(x0 >> 70) | 1u)) << (garr[i1 & 7u] & 31u))) break;
        r0.y ^= m0;
        do { if (--fuel == 0u) goto done;
            if (0xedc03384u) break;
        } while (i1++ < 2u && (unsigned)(short)(unsigned)(((unsigned)c0 % ((unsigned)c0 | 1u)) && 0x9b770416u));
        do { if (--fuel == 0u) goto done;
            a0[0xb81488eeu & 3u] = (unsigned)c0;
            if ((unsigned)((unsigned)f0 < (v0 + a0[i0 & 3u]))) {
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)c0, (m0 - p0), (unsigned)(7u || p2)); }
            } else {
                switch ((garr[i1 & 7u] << (6u & 31u)) & 7u) {
                    case 2u: ;
                    while (i2++ < 7u && ((unsigned)h1 % (fuel | 1u))) { if (--fuel == 0u) goto done;
                        switch ((unsigned)(garr[u2 & 7u] || ((unsigned)s1 << (0xf9568c15u & 31u))) & 7u) {
                            if (budget != 0u) { budget -= 1u; u0 = fn0(v0, (unsigned)(a0[i0 & 3u] < (unsigned)((int)i1 < (int)u1)), ((unsigned)c1 / (((unsigned)b0 + 0x80000000u) | 1u))); }
                            m0 ^= (unsigned)(x0 >> 70);
                        }
                        r0.y ^= (unsigned)(*mp || (unsigned)((int)(unsigned)s1 >= (int)(p1 & 3u)));
                        if (u3 == 7u) return 6u;
                    }
                    case 6u: ;
                    if ((unsigned)((int)v0 >= (int)0x8fc10d1bu)) goto L0;
                }
                h1 = (unsigned short)(h1 + (unsigned)((int)-((unsigned)(signed char)(0u | 0xffffffffu) % ((unsigned)(signed char)(unsigned)((short)(unsigned)h0 > (signed char)garr[i1 & 7u]) | 1u)) < (int)(unsigned)f0));
            }
            g0 = (unsigned)(unsigned char)(unsigned)((int)3u >= (int)a0[i0 & 3u]);
            l0 = (long)((unsigned long)l0 + (unsigned)(0x1cfc0a7bu && (unsigned)(g0 < (unsigned)(short)(((unsigned)s0 - 0x7153a994u) ^ 0xffffffffu))));
            if ((g0 + (unsigned)(0x48db2ec0u == *mp))) goto L0;
            switch (((unsigned)h0 ^ p0) & 7u) {
                u2 = u2 * 0x9e3779b1u + (unsigned)(i0 < ((4u + (0x172ec6bdu % (g1 | 1u))) & g1));
                break; (void)((unsigned)(0x80000000u < (unsigned)b0));
                u2 = (u1 - g1);
                *q0 = (garr[i1 & 7u] - p1);
                if ((unsigned)(signed char)(unsigned)((short)(unsigned)x0 > (signed char)3u)) break;
            }
        } while (i1++ < 4u && (i2 / (0x7fffffffu | 1u)));
        if ((unsigned)(((unsigned)w0 - r0.y) < g0)) break;
        switch ((unsigned)((int)(0xd19d3407u % ((unsigned)x0 | 1u)) < (int)i2) & 7u) {
            if (budget != 0u) { budget -= 1u; u2 = fn0(u2, (unsigned)(9u && (unsigned)((short)u3 > (signed char)0x10000u)), (5u + (unsigned)c1)); }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(6u || (u0 - 0u)), (3u + (unsigned)(0xb88e2ca3u < (unsigned)c0)), u2); }
        }
    } while (i0++ < 5u && 0x80000000u);
    while (-(unsigned)((int)(unsigned)(w0 >> 29) < (int)v0)) { if (--fuel == 0u) goto done;
        break; (void)(((0x26021f04u | 0u) / ((unsigned)c1 | 1u)));
        do { if (--fuel == 0u) goto done;
            if (((unsigned)h1 ^ garr[i1 & 7u])) goto L1;
            g1 += (unsigned)((int)((unsigned)(r0.x == a0[i0 & 3u]) % (1u | 1u)) < (int)((unsigned)f0 % ((unsigned)x0 | 1u)));
            c1 = (signed char)((unsigned)((unsigned)(x0 >> 70) || (unsigned)((short)u3 > (signed char)(unsigned)((int)v0 < (int)0x80000000u))) + u1);
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (~(r0.x % (0x1e3e3887u | 1u))) break;
            }
            f0 = f0 * 0.5f + (float)((unsigned)((short)0x7fffffffu > (signed char)0xcaf43a78u) & 255u);
        } while (i1++ < 3u && ((r0.y << (a0[i0 & 3u] & 31u)) >> ((unsigned)s0 & 31u)));
    }
    if ((0x4fbcfb82u + fuel)) {
        w0 = w0 * 6364136223846793005ull + (unsigned)!((unsigned)((int)6u >= (int)(unsigned)l0) * ~(0x80000000u * 8u));
    } else {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)c0 || (unsigned)(u2 < 0xffffffffu))) break;
            u1 = ((1u + (unsigned)s1) ^ (unsigned)((short)(unsigned)(0xafac6022u || p0) > (signed char)i0));
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)u3 << ((unsigned)(unsigned char)(unsigned)((int)(unsigned)((short)g1 > (signed char)0x10000u) >= (int)(0x100ebafau + (unsigned)((short)0xe21d7cfeu > (signed char)0x10000u))) & 63u);
                if (u3 == 7u) return (unsigned)((int)0x1350a93eu >= (int)(unsigned)((unsigned)e0 || (unsigned)f0));
                if (budget != 0u) { budget -= 1u; u1 = fn0((0u >> (((unsigned)(w0 >> 29) % (u2 | 1u)) & 31u)), (unsigned)((short)u1 > (signed char)(unsigned)!(g1 % (7u | 1u))), (unsigned)d0); }
            }
            break; (void)(a0[i0 & 3u]);
            switch ((unsigned)(signed char)(unsigned)(0x10000u || 0x10000u) & 7u) {
                case 6u: ;
                if ((0x10000u - (u3 / (5u | 1u)))) continue;
                case 7u: ;
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(*q0 == (unsigned)h0), (unsigned)(1u == (unsigned)((short)fuel > (signed char)*mp)), (unsigned)(short)(unsigned)((int)(8u - (unsigned)x0) >= (int)(unsigned)w0)); }
    }
    h0 = (short)(garr[i1 & 7u] >> ((unsigned)l0 & 31u));
    g1 += (unsigned)((int)(unsigned)c1 < (int)0xa523d157u);
    if (budget != 0u) { budget -= 1u; u3 = fn0(0u, (r0.x ^ a0[u1 & 3u]), (a0[u1 & 3u] << ((0xb3c0a9a7u % ((unsigned)f0 | 1u)) & 31u))); }
    if (0xacbbbf9u) goto L0;
    if ((0x80000000u * u2)) goto L1;
    switch (((unsigned)s1 << (((unsigned)x0 >> (fuel & 31u)) & 31u)) & 7u) {
        if (budget != 0u) { budget -= 1u; u3 = fn0(garr[i1 & 7u], (garr[u2 & 7u] / (u3 | 1u)), (unsigned)(((unsigned)w0 << (0x7fffffffu & 31u)) || 0x80000000u)); }
        goto L4;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)d0 < *mp), (3u | (unsigned)(0x10000u || 6u)), (unsigned)(0x4b6fb16fu || (unsigned)(p0 || 0x35d65bddu))); }
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(0x954b12c1u & garr[u2 & 7u]) << ((unsigned)(signed char)((5u ^ (unsigned)d0) ^ 0x7fffffffu) & 63u);
                f0 = f0 * 0.5f + (float)((3u * (unsigned)s0) & 255u);
            }
            if ((unsigned)((unsigned)h0 < r0.y)) continue;
            u3 ^= u2;
            case 7u: ;
            u0 = ~((unsigned)(signed char)(unsigned)((int)p1 < (int)0x83904f4bu) * (0x11a4a974u * (unsigned)h0));
        }
        garr[(unsigned)l0 & 7u] = (unsigned)((int)(unsigned)!(0x49f9e03au - 0xb15b7a49u) < (int)(unsigned)((short)r0.y > (signed char)(unsigned)s1));
    }
    h0 = (short)0x10000u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    b0 = (unsigned)((int)0xe7b87ae5u < (int)0xffffffffu) != 0u;
    g1 += (unsigned)(signed char)(unsigned)(1u < (unsigned)c1);
    m0 ^= (unsigned)e0;
    switch ((unsigned)s0 & 7u) {
        L0: if (--fuel == 0u) goto done;
        goto L1;
    }
    u0 += (unsigned)(short)(v0 ? (unsigned)!(unsigned)((u0 ^ *q0) == (unsigned)(x0 >> 70)) : (unsigned)c1);
    if (p2) goto L0;
    L1: if (--fuel == 0u) goto done;
    c0 = (unsigned char)(unsigned)((int)(unsigned)h1 >= (int)(unsigned)f0);
    if (garr[u2 & 7u]) {
        *q0 += ((1u ? p2 : 0xffffffffu) & (unsigned)l0);
        { unsigned t0; double z0; if ((r0.y) & 1u) { t0 = ((unsigned)d0 % (0xffffffffu | 1u)); z0 = (double)(((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)c1)) & 255u); } if ((r0.y) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            if (0x80000000u) goto L1;
            L2: if (--fuel == 0u) goto done;
            goto L1;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(a0[u1 & 3u] < (u3 - (unsigned)w0)), a0[u1 & 3u], fuel); }
            r0.y ^= a0[i0 & 3u];
        }
        if ((unsigned)!(unsigned)((short)((unsigned)d0 % (0xffffffffu | 1u)) > (signed char)a0[i0 & 3u])) {
            if ((unsigned)(short)((unsigned)h0 + (0xe91b0c47u + (unsigned)l0))) goto done;
            d0 = d0 * 0.5 + (double)((fuel | *q0) & 1023u);
            u3 += ((unsigned)l0 ? g1 : u0);
            goto L3;
            while ((r0.x + (unsigned)(0x80000000u || m0))) { if (--fuel == 0u) goto done;
                u3 += (0xded6d5f6u & (unsigned)x0);
            }
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + ((r0.x << ((p1 * i0) & 31u)) ^ (unsigned)(unsigned char)((unsigned)w0 + r0.x)));
        }
        c0 = (unsigned char)(unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)(signed char)(m0 ? 0x5b497302u : u2));
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)f0 == 4u)) break;
            u0 = u0 * 0x9e3779b1u + (i1 - ((unsigned)(w0 >> 29) & i0));
            if (u3 == 7u) return (unsigned)((unsigned)d0 == (unsigned)((unsigned)((unsigned)((int)0x58c3eae7u < (int)(unsigned)(x0 >> 70)) || (unsigned)s0) && u0));
            { unsigned t1; double z1; if (((u0 / (r0.x | 1u))) & 1u) { t1 = (unsigned)(0xc713ffeu == ((unsigned)c1 - (unsigned)s1)); z1 = (double)(((((unsigned)e0 * 0x5b62139u) | 0x7c47da6fu)) & 255u); } if (((u0 / (r0.x | 1u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                break; (void)((((unsigned)h0 << (m0 & 31u)) + (unsigned)s0));
            }
            if ((unsigned)(9u == (*mp ^ 1u))) {
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)e0 * u0), (i2 << (0xffffffffu & 31u)), 8u); }
                r0.y ^= ((unsigned)(short)(0xf838a304u + (i0 - 0x22b55e06u)) - u3);
                u2 = (unsigned)((unsigned)((9u % ((unsigned)c1 | 1u)) && (unsigned)f0) && u2);
                if (0u) break;
            } else {
                continue; (void)(((unsigned)(w0 >> 29) * 0x3ce97ce1u));
                { unsigned t2; double z2; if (((unsigned)h1) & 1u) { t2 = 0x80000000u; z2 = (double)((g1) & 255u); } if (((unsigned)h1) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    if ((~(0x10000u * 0xffffffffu) ^ r0.y)) break;
                    r0.x = ((unsigned)(r0.x || u2) % (garr[i1 & 7u] | 1u));
                    if ((unsigned)((unsigned)x0 == (i2 ^ (unsigned)h0))) {
                        if ((a0[i0 & 3u] << ((unsigned)((unsigned)c1 || u0) & 31u))) goto done;
                        { unsigned t3; double z3; if ((5u) & 1u) { t3 = (unsigned)((int)((unsigned)s0 << (0x5518c59u & 31u)) >= (int)p2); z3 = (double)(((unsigned)((short)(unsigned)(i2 == (unsigned)(x0 >> 70)) > (signed char)u2)) & 255u); } if ((5u) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                            L3: if (--fuel == 0u) goto done;
                        }
                        r0.y ^= (unsigned)((0xebcc0a48u ^ 0xbe019935u) && (unsigned)(0xc216ecau && (i0 << (*q0 & 31u))));
                    }
                    if ((unsigned)(garr[i1 & 7u] && (unsigned)s1)) {
                        m0 ^= 3u;
                        *q0 += (unsigned)(signed char)(unsigned)((int)a0[u1 & 3u] >= (int)(4u << (p1 & 31u)));
                        if ((r0.x >> (0x9926faadu & 31u))) break;
                        for (;;) { if (--fuel == 0u) goto done;
                            if (fuel < 8u) return (unsigned)(x0 >> 70);
                            L4: if (--fuel == 0u) goto done;
                        }
                        if (~(i2 | 0x10000u)) break;
                    }
                }
            }
            if ((garr[u2 & 7u] << (*q0 & 31u))) break;
        } while (i0++ < 5u && 7u);
    } else {
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)e0, (unsigned)(unsigned char)(unsigned)((unsigned)d0 || (unsigned)(x0 >> 70)), (0x80000000u ? m0 : a0[u1 & 3u])); }
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= ((unsigned)x0 + (v0 | (unsigned)x0));
        x0 = x0 * 0x100000001b3ull + (unsigned)((short)(garr[u2 & 7u] * 4u) > (signed char)(unsigned)(9u == (unsigned)(p0 == (unsigned)c1)));
        while (i1++ < 2u && p0) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)s1, 0xffffffffu, fuel); }
            if (v0) break;
            while (i2++ < 5u && 0xffffffffu) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)(i1 % ((unsigned)s1 | 1u)) > (signed char)(unsigned)b0)) break;
                if (p0) break;
            }
            f0 = f0 * 0.5f + (float)((u3 << ((unsigned)((int)g0 < (int)p1) & 31u)) & 255u);
            { unsigned t4; double z4; if (((unsigned)(signed char)((unsigned)w0 - (unsigned)(unsigned char)(unsigned)(g1 == 0xa0d4b48du))) & 1u) { t4 = (unsigned)l0; z4 = (double)((((unsigned)b0 + (unsigned)l0)) & 255u); } if (((unsigned)(signed char)((unsigned)w0 - (unsigned)(unsigned char)(unsigned)(g1 == 0xa0d4b48du))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                u1 ^= (m0 << ((0x7fffffffu << ((unsigned)e0 & 31u)) & 31u));
                if ((((unsigned)l0 - p2) % (i1 | 1u))) break;
                q0 = &garr[(unsigned)((int)(u3 - u2) >= (int)0x8699d3b2u) & 7u];
                u2 = u2 * 0x9e3779b1u + (0x80000000u ^ p1);
            }
            d0 = d0 * 0.5 + (double)((unsigned)((int)(0xad650d7eu & (unsigned)h1) >= (int)(unsigned)(unsigned char)(unsigned)(0x7fffffffu || (unsigned)(w0 >> 29))) & 1023u);
        }
        { unsigned t5; double z5; if (((unsigned)(garr[i1 & 7u] < (unsigned)(short)(a0[u1 & 3u] - u1))) & 1u) { t5 = g0; z5 = (double)((((unsigned)(i0 || (unsigned)w0) << (r0.x & 31u))) & 255u); } if (((unsigned)(garr[i1 & 7u] < (unsigned)(short)(a0[u1 & 3u] - u1))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            if (budget != 0u) { budget -= 1u; u2 = fn0(r0.y, p0, (unsigned)l0); }
            *q0 = (unsigned)((int)(2u / ((unsigned)h1 | 1u)) >= (int)((unsigned)e0 ? (unsigned)(w0 >> 29) : (unsigned)l0));
        }
    }
    if ((unsigned)d0) {
        if (u3 == 7u) return g0;
        if (((unsigned)((short)r0.x > (signed char)0x7fffffffu) & i2)) goto L1;
        goto L1;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((((unsigned)e0 % (p1 | 1u)) + *q0)) break;
        }
        a0[0x80000000u & 3u] = (0x10000u / ((unsigned)l0 | 1u));
    }
    goto L4;
    if ((unsigned)(0x7fffffffu && 4u)) goto L2;
    if (((unsigned)s0 | (unsigned)c1)) goto L1;
    s1 = (int)((unsigned)s1 + (unsigned)(((unsigned)d0 | p2) == (unsigned)((unsigned)b0 < (1u * (unsigned)h0))));
    if ((garr[i1 & 7u] ^ 9u)) goto L4;
    if (5u) {
        u0 = (unsigned)(short)(unsigned)((unsigned)((unsigned)((short)(unsigned)((short)g0 > (signed char)garr[i1 & 7u]) > (signed char)i1) || *q0) && r0.x);
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)(0x28b32925u % ((unsigned)h1 | 1u))) goto L4;
            s1 = (int)((unsigned)s1 + 0x23cea883u);
        } while (i0++ < 3u && ((unsigned)b0 >> ((unsigned)((short)i2 > (signed char)0xffffffffu) & 31u)));
        r0.y ^= ((1u >> ((unsigned)w0 & 31u)) & p1);
        if ((unsigned)((int)fuel >= (int)((unsigned)l0 % ((unsigned)d0 | 1u)))) goto L1;
        if ((unsigned)((int)u0 < (int)(unsigned)(8u < g1))) goto L4;
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)(~(unsigned)((unsigned)c0 && 0xe8b93e7eu) == ((unsigned)b0 / ((u2 - i1) | 1u)));
        g0 = (m0 / (((unsigned)h0 & 4u) | 1u));
        f0 = f0 * 0.5f + (float)(r0.x & 255u);
        if (((garr[u2 & 7u] * g0) / (i0 | 1u))) continue;
        if ((unsigned)(signed char)(~(unsigned)((int)0xffffffffu >= (int)(unsigned)x0) % ((unsigned)c0 | 1u))) continue;
        *q0 = (unsigned)((unsigned)((int)0x7fffffffu >= (int)p2) == (0x10000u & 0x80000000u));
    }
    if ((unsigned)e0) goto L4;
    switch ((6u * r0.x) & 7u) {
        case 4u: ;
        garr[(unsigned)s1 & 7u] = fuel;
        r0.x = (2u | r0.x);
        l0 = (long)((unsigned long)l0 + -(unsigned)((0x7fffffffu >> ((5u >> (8u & 31u)) & 31u)) || u2));
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)0x80000000u > (signed char)(unsigned)c1), (unsigned)b0, a0[i0 & 3u]); }
    w0 = w0 * 6364136223846793005ull + (0x10626ae5u / ((unsigned)(i2 || (unsigned)(short)(unsigned)(r0.x || fuel)) | 1u));
    if ((unsigned)((short)(unsigned)s1 > (signed char)0xee5cd366u)) goto L4;
    if ((u3 & 0x1347d92au)) goto L1;
    g1 += (unsigned)e0;
    goto L2;
    if ((unsigned)((unsigned)x0 == u1)) goto L1;
    if (-(0x7fffffffu >> (0x7fffffffu & 31u))) {
        r0.y ^= (unsigned)(p1 < *q0);
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1(0x5faee128u, (unsigned)(p1 || u3), garr[u2 & 7u]); }
            switch (0x7fffffffu & 7u) {
                { unsigned t6; double z6; if (((unsigned)(x0 >> 70)) & 1u) { t6 = (unsigned)((int)garr[u2 & 7u] < (int)((unsigned)l0 << (0xdc68de04u & 31u))); z6 = (double)((0x60c5137bu) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                    case 6u: ;
                    do { if (--fuel == 0u) goto done;
                        v0 = (unsigned)(0x80000000u || (r0.x & v0));
                        u0 = garr[u2 & 7u];
                        if (garr[u2 & 7u]) goto L1;
                    } while (i1++ < 2u && (p2 / ((unsigned)f0 | 1u)));
                    switch (((a0[i0 & 3u] % (0x148e462au | 1u)) | garr[i1 & 7u]) & 7u) {
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)b0 / (garr[i1 & 7u] | 1u)), 0x43203de3u, (unsigned)(short)(0xffffffffu | (unsigned)d0)); }
                        case 6u: ;
                        g1 += ((unsigned)b0 | (unsigned)(w0 >> 29));
                    }
                }
                case 2u: ;
                case 4u: ;
            }
            if ((unsigned)f0) break;
            if (((unsigned)b0 >> ((unsigned)(x0 >> 70) & 31u))) break;
        }
        u1 ^= (0xfc8bbac6u - (r0.y - (unsigned)((unsigned)((int)0x26457a7eu >= (int)0x7d4c8218u) || (unsigned)h0)));
        if (0x4764be81u) goto done;
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 += (unsigned)(unsigned char)(i0 ^ ((0x80000000u | garr[i1 & 7u]) >> (7u & 31u)));
        if ((unsigned)((3u | 1u) < *q0)) break;
        c0 = (unsigned char)(unsigned)(signed char)((unsigned)s1 + a0[i0 & 3u]);
        if (a0[u1 & 3u]) {
            if (0x170a1062u) {
                while (((unsigned)(x0 >> 70) << ((unsigned)w0 & 31u))) { if (--fuel == 0u) goto done;
                    if ((unsigned)(0x10000u == i1)) break;
                    break; (void)(0x10000u);
                    if ((unsigned)(signed char)(unsigned)(a0[i0 & 3u] || 0x7fffffffu)) break;
                }
                { unsigned t7; double z7; if ((((unsigned)c0 % (garr[u2 & 7u] | 1u))) & 1u) { t7 = a0[u1 & 3u]; z7 = (double)(((unsigned)(0x7fffffffu == (fuel / ((unsigned)w0 | 1u)))) & 255u); } if ((((unsigned)c0 % (garr[u2 & 7u] | 1u))) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                    a0[(unsigned)(i0 || u2) & 3u] = (unsigned)((int)((unsigned)((int)i2 >= (int)(unsigned)c0) ? 0xe73fa470u : 0x7fffffffu) >= (int)(unsigned)(x0 >> 70));
                    switch (((unsigned)((unsigned)s0 || 2u) + 0x80000000u) & 7u) {
                        case 4u: ;
                        r0.x = (a0[i0 & 3u] | 2u);
                        u2 += (g1 % (i0 | 1u));
                    }
                }
                w0 ^= (unsigned long long)(unsigned)(0x53a7ecfdu == u2) << ((unsigned)((short)(unsigned)l0 > (signed char)(0xc59dd56au >> ((unsigned)l0 & 31u))) & 63u);
                r0.y ^= g0;
            }
        } else {
            *q0 = (unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)(0x856c232bu < u1));
            s0 = (int)(unsigned)((short)((unsigned)e0 % (u1 | 1u)) > (signed char)*q0);
        }
    }
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)(x0 >> 70)) break;
        if ((g1 | garr[u2 & 7u])) {
            g0 = (unsigned)((int)p1 >= (int)(unsigned)((short)(unsigned)e0 > (signed char)(r0.x | (unsigned)e0)));
            s0 = (int)((unsigned)f0 * (unsigned)((0x7fffffffu & (unsigned)h1) && -(unsigned)(r0.y == g0)));
            l0 = (long)((unsigned long)l0 + (1u ? p1 : (~((unsigned)d0 << ((unsigned)h1 & 31u)) - a0[u1 & 3u])));
            a0[(unsigned)w0 & 3u] = (unsigned)((unsigned)((0x10000u / (0xf67bb4fau | 1u)) < *q0) && ((unsigned)s0 / (v0 | 1u)));
        } else {
            if ((unsigned)((int)i0 >= (int)0x413b35f4u)) {
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)(u0);
                    if (budget != 0u) { budget -= 1u; u0 = fn1(5u, 0x53e5a349u, *q0); }
                    break; (void)(garr[i1 & 7u]);
                    w0 = w0 * 6364136223846793005ull + (unsigned)(3u || (unsigned)(unsigned char)(0xfe17f148u % ((*mp % (0xffffffffu | 1u)) | 1u)));
                    if ((unsigned)(short)((unsigned)d0 - 3u)) break;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn1((0xffffffffu >> ((unsigned)d0 & 31u)), (unsigned)x0, (unsigned)((short)(unsigned)h0 > (signed char)((unsigned)(x0 >> 70) | (unsigned)h1))); }
                { unsigned t8; double z8; if ((0x8a0d84e3u) & 1u) { t8 = (8u & (a0[i0 & 3u] | (unsigned)d0)); z8 = (double)(((unsigned)(p2 || 6u)) & 255u); } if ((0x8a0d84e3u) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (p0) break;
                        c1 = (signed char)(unsigned)((unsigned)(a0[u1 & 3u] < (unsigned)e0) || (unsigned)(5u == 0xadf2f4beu));
                        *mp = g0;
                    }
                    { unsigned t9; double z9; if (((unsigned)((int)(unsigned)((unsigned)w0 == (unsigned)(w0 >> 29)) >= (int)0xd2609f4bu)) & 1u) { t9 = (((unsigned)l0 << (0x10000u & 31u)) << (0x824b3d89u & 31u)); z9 = (double)((~(v0 & r0.y)) & 255u); } if (((unsigned)((int)(unsigned)((unsigned)w0 == (unsigned)(w0 >> 29)) >= (int)0xd2609f4bu)) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
                        g1 += *q0;
                        u1 += (0u ? 6u : ((unsigned)b0 ^ (unsigned)s0));
                        if (0x7fffffffu) break;
                        continue; (void)((g1 ^ 2u));
                        if ((unsigned)((unsigned)h1 && (unsigned)f0)) break;
                        continue; (void)((unsigned)e0);
                    }
                    f0 = f0 * 0.5f + (float)(((unsigned)((short)u3 > (signed char)3u) + (p0 << (5u & 31u))) & 255u);
                    if (budget != 0u) { budget -= 1u; u0 = fn0((u2 << ((unsigned)l0 & 31u)), (unsigned)(signed char)(0x2780247cu ? garr[u2 & 7u] : (unsigned)e0), (((unsigned)h0 % ((unsigned)h1 | 1u)) * 4u)); }
                }
                m0 ^= (unsigned)((u1 << (g0 & 31u)) && 9u);
            }
        }
        s0 = (int)(unsigned)(a0[u1 & 3u] && i0);
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)a0[u1 & 3u] < (int)(0x4bae00f9u / ((unsigned)h0 | 1u)));
    }
    *mp = -(unsigned)(p0 == (unsigned)((unsigned)(x0 >> 70) < i1));
    if (*q0) {
        h0 = (short)1u;
    }
    if (0x80000000u) goto L3;
    q0 = &garr[(0x80000000u ^ (unsigned)((short)garr[u2 & 7u] > (signed char)(p0 + (6u * 3u)))) & 7u];
    for (;;) { if (--fuel == 0u) goto done;
        h0 = (short)(unsigned)((short)(i2 / ((unsigned)l0 | 1u)) > (signed char)0x3e1ce163u);
        l0 = (long)((unsigned long)l0 + (unsigned)s0);
        m0 ^= ((unsigned)d0 * (g0 & ((unsigned)h1 + (unsigned)!(6u | (unsigned)h0))));
    }
    a0[~(a0[i0 & 3u] + 0x82795103u) & 3u] = g0;
    while (0x16595755u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)s0 & garr[i1 & 7u]), 2u, ((unsigned)(u3 || fuel) >> (0x3c08578eu & 31u))); }
        if ((unsigned)b0) {
            e0 = e0 * 0.5L + (long double)((0x10000u ^ 0xdcf6bf3u) & 1023u);
            v0 = 5u;
            *q0 += ((0xbb5bcbe9u + (unsigned)h0) | (unsigned)e0);
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                u2 ^= (unsigned)((unsigned)f0 < (unsigned)((int)r0.y < (int)u1));
                if (i1) break;
                do { if (--fuel == 0u) goto done;
                    h0 = (short)(unsigned)((int)((unsigned)((int)p0 >= (int)a0[i0 & 3u]) * 0u) >= (int)(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)h1));
                    h1 = (unsigned short)(h1 + 0x959adef7u);
                    while (i0++ < 2u && -(unsigned)(((unsigned)s1 << (0x80000000u & 31u)) < g1)) { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)(unsigned)((unsigned)c0 < g0) < (int)(unsigned)s1)) break;
                        break; (void)(p1);
                        if (fuel < 8u) return (((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)c1) ^ 0xba78e22u) ^ (5u % ((unsigned)e0 | 1u)));
                        w0 = w0 * 6364136223846793005ull + (unsigned)(short)(0x80000000u / ((unsigned)((short)v0 > (signed char)(unsigned)((short)(u0 * 0x7fffffffu) > (signed char)*q0)) | 1u));
                        s0 = (int)(u0 - i2);
                    }
                    if ((unsigned)!((u3 >> (r0.x & 31u)) >> (0x7fffffffu & 31u))) break;
                    b0 = (unsigned)h1 != 0u;
                    if ((unsigned)((unsigned)b0 && 0x3f9297d3u)) {
                        b0 = (unsigned)(signed char)(unsigned)(0x15c9c9cfu && (unsigned)s0) != 0u;
                        break; (void)(0x80000000u);
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(signed char)((unsigned)((unsigned)(w0 >> 29) == g1) / (g1 | 1u)), 0x8b58e455u, (7u % (u2 | 1u))); }
                        break; (void)((unsigned)((0x9f895a51u - 0xdd7d7258u) && u0));
                    } else {
                        if ((0x7fffffffu | garr[u2 & 7u])) break;
                        r0.y ^= (g1 - (unsigned)(signed char)(unsigned)((short)(unsigned)(u2 || (u1 + 0x80000000u)) > (signed char)u1));
                        *q0 += (unsigned)((unsigned)(5u && (unsigned)(w0 >> 29)) || (g0 | p2));
                        switch ((v0 ? 0xffffffffu : 0u) & 7u) {
                            case 5u: ;
                            *mp = (unsigned)(9u < ((m0 >> ((unsigned)e0 & 31u)) / ((unsigned)b0 | 1u)));
                        }
                    }
                } while (i2++ < 3u && (unsigned)s1);
            }
            r0.y ^= (unsigned)((unsigned)(((unsigned)l0 ^ (unsigned)(x0 >> 70)) == (unsigned)b0) == (unsigned)((unsigned)s0 || 0x7d01c3fcu));
        }
        { unsigned t10; double z10; if ((0x7fffffffu) & 1u) { t10 = (unsigned)(8u || (unsigned)(signed char)(unsigned)((short)r0.x > (signed char)6u)); z10 = (double)((1u) & 255u); } if ((0x7fffffffu) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)((a0[i0 & 3u] % (u2 | 1u)) | (unsigned)h0), i0, (fuel & 0x10000u)); }
                h1 = (unsigned short)(h1 + (unsigned)((int)0xd3986877u < (int)3u));
                if ((unsigned)(short)(((unsigned)(w0 >> 29) * (unsigned)s1) * garr[u2 & 7u])) break;
                break; (void)((unsigned)((int)(unsigned)b0 >= (int)(unsigned)(short)(u0 ^ 0xbd62a6a4u)));
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((v0 << ((unsigned)b0 & 31u)), (unsigned)(u0 || (unsigned)h0), (a0[u1 & 3u] - (unsigned)s1)); }
                    c0 = (unsigned char)(((unsigned)(unsigned char)(0x7fffffffu * u2) - g0) << (fuel & 31u));
                    if (((unsigned)w0 / ((unsigned)s1 | 1u))) {
                        m0 ^= (unsigned)h1;
                        if ((a0[i0 & 3u] >> (7u & 31u))) break;
                    } else {
                        a0[(0x33d62104u / (0x7fffffffu | 1u)) & 3u] = ((((unsigned)h1 | 0u) & u3) ^ (unsigned)((int)v0 < (int)(unsigned)c1));
                        if ((((unsigned)s1 << (0x2a8ff62du & 31u)) >> (0xa591c64du & 31u))) continue;
                    }
                    if (-(p0 - (unsigned)!(a0[i0 & 3u] * (unsigned)h0))) break;
                    break; (void)(((unsigned)f0 | u0));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((i1 << ((unsigned)l0 & 31u)), (r0.y << (fuel & 31u)), (unsigned)((int)(unsigned)((int)g0 < (int)(unsigned)s0) < (int)i1)); }
                }
                *q0 += (unsigned)(short)(unsigned)(u0 == garr[i1 & 7u]);
            } while (i1++ < 5u && ((unsigned)(8u && 0xe8633280u) / (r0.y | 1u)));
            if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(a0[u1 & 3u] == 0x7fffffffu) / (*mp | 1u)), (i0 >> ((unsigned)l0 & 31u)), 5u); }
            do { if (--fuel == 0u) goto done;
                if (~((unsigned)(u1 || garr[u2 & 7u]) >> (0x80000000u & 31u))) break;
                if ((unsigned)((int)(unsigned)c0 >= (int)u0)) break;
                if (0xef754555u) goto L1;
            } while (i1++ < 4u && (unsigned)((short)(unsigned)f0 > (signed char)p0));
            f0 = f0 * 0.5f + (float)((unsigned)((p0 * (unsigned)f0) || i1) & 255u);
            w0 = w0 * 6364136223846793005ull + (u3 + (m0 - a0[u1 & 3u]));
            h0 = (short)*mp;
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(u1, ((0xffffffffu % (0x5b5a5fa1u | 1u)) % ((unsigned)c0 | 1u)), ((unsigned)b0 - (unsigned)s0)); }
    if ((unsigned)(g0 == (unsigned)(0xac55c2bdu == p2))) {
        i0 = (unsigned)((int)(unsigned)(0x2a87c028u == 5u) >= (int)(unsigned)((int)p0 < (int)(0x7fffffffu << (r0.x & 31u)))) & 15u;
        switch (((unsigned)h1 << ((unsigned)h1 & 31u)) & 7u) {
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(0x58ce2288u, (((unsigned)h1 / ((unsigned)h1 | 1u)) << ((unsigned)c1 & 31u)), (unsigned)(unsigned char)((0x7c046027u & (unsigned)b0) / ((unsigned)e0 | 1u))); }
                r0.x = (unsigned)(unsigned char)(unsigned)(p1 || 0xffffffffu);
                *q0 = (unsigned)((short)(unsigned)(r0.y || a0[i0 & 3u]) > (signed char)0x10000u);
                u2 = u2 * 0x9e3779b1u + ((0x10000u / (*q0 | 1u)) * 0x81c89e28u);
                goto L1;
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(short)(unsigned)(4u < i2), (0x10000u ? (unsigned)f0 : *q0), (unsigned)((int)0x80000000u < (int)g0)); }
            } while (i0++ < 7u && u3);
            while (i0++ < 6u && (unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
                if (((unsigned)d0 % (p2 | 1u))) goto L3;
                continue; (void)(u2);
            }
        }
    } else {
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t11; double z11; if (((unsigned)((int)(a0[i0 & 3u] & *q0) < (int)0x80000000u)) & 1u) { t11 = (0u << ((unsigned)h1 & 31u)); z11 = (double)((~((unsigned)(x0 >> 70) ? i0 : r0.x)) & 255u); } if (((unsigned)((int)(a0[i0 & 3u] & *q0) < (int)0x80000000u)) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
                u2 = 0x342d3c93u;
                { unsigned t12; double z12; if (((unsigned)!(p1 - (unsigned)(g1 == (unsigned)d0))) & 1u) { t12 = (unsigned)((short)0x6b005b4cu > (signed char)g0); z12 = (double)(((unsigned)!(0x7fffffffu % ((unsigned)(v0 < (unsigned)(x0 >> 70)) | 1u))) & 255u); } if (((unsigned)!(p1 - (unsigned)(g1 == (unsigned)d0))) & 1u) { u1 += t12; d0 = d0 * 0.5 + z12; }
                    c1 = (signed char)(unsigned)(((unsigned)x0 | 0xffffffffu) || (((unsigned)b0 - g0) ^ 6u));
                }
                m0 ^= (unsigned)((int)(unsigned)w0 >= (int)0x7bf572aau);
            }
            h0 = (short)(unsigned)b0;
            e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(u1 && a0[u1 & 3u]) && (unsigned)h0) & 1023u);
        }
        if (((unsigned)s1 - r0.y)) goto L1;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1(a0[i0 & 3u], ((unsigned)((unsigned)h0 && *q0) & i0), (m0 / (a0[i0 & 3u] | 1u))); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while (i0++ < 3u && 0xb788b413u) { if (--fuel == 0u) goto done;
        if (0xcf58223cu) {
            e0 = e0 * 0.5L + (long double)((unsigned)(p2 < ((unsigned)f0 % ((unsigned)l0 | 1u))) & 1023u);
            r0.y ^= (unsigned)(signed char)((unsigned)h0 + 0xb6401a08u);
            h0 = (short)(1u & *q0);
            c0 = (unsigned char)(unsigned)((int)v0 < (int)p0);
        } else {
            goto L0;
            do { if (--fuel == 0u) goto done;
                if (0x10000u) break;
                do { if (--fuel == 0u) goto done;
                    u2 ^= (0x76354cd5u & (unsigned)((int)0x80000000u >= (int)0x24781f41u));
                    while ((unsigned)(0x6b77fdb7u && 9u)) { if (--fuel == 0u) goto done;
                        switch ((0xffffffffu & 1u) & 7u) {
                            L0: if (--fuel == 0u) goto done;
                            L1: if (--fuel == 0u) goto done;
                        }
                        break; (void)((unsigned)e0);
                        *q0 += i2;
                        b0 = (unsigned)l0 != 0u;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(p2, ((m0 | p0) << (r0.y & 31u)), 0x80000000u); }
                        if (budget != 0u) { budget -= 1u; u3 = fn0((((unsigned)d0 / ((unsigned)c1 | 1u)) / ((unsigned)(x0 >> 70) | 1u)), ~(unsigned)((short)u1 > (signed char)(unsigned)(i1 == v0)), (unsigned)(signed char)(unsigned)((a0[i0 & 3u] ^ 0x194b2d35u) && garr[u2 & 7u])); }
                    }
                    while (i0++ < 3u && *q0) { if (--fuel == 0u) goto done;
                        if ((0x5a6b722eu / (u2 | 1u))) break;
                        break; (void)((unsigned)s0);
                        m0 ^= ((0xf5a10e11u / (i1 | 1u)) - (unsigned)((int)(unsigned)(unsigned char)((unsigned)e0 ^ a0[i0 & 3u]) >= (int)(unsigned)(x0 >> 70)));
                        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                            a0[((unsigned)x0 ^ 0x10000u) & 3u] = (unsigned)((int)(0x10000u - (unsigned)h0) >= (int)(unsigned)((unsigned)b0 < ((unsigned)c0 | u3)));
                            r0.x = (unsigned)((unsigned)(signed char)((unsigned)e0 - r0.y) || (((unsigned)d0 >> ((unsigned)x0 & 31u)) - 1u));
                            if ((unsigned)w0) break;
                            s1 = (int)((unsigned)s1 + (unsigned)((unsigned)l0 == (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)e0)));
                            d0 = d0 * 0.5 + (double)((unsigned)((short)fuel > (signed char)((unsigned)f0 % ((garr[i1 & 7u] | p2) | 1u))) & 1023u);
                        }
                        c1 = (signed char)(2u + (unsigned)x0);
                        i0 = ((unsigned)(short)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)(1u - r0.x)) / (2u | 1u)) & 15u;
                    }
                } while (i2++ < 7u && ((g0 ^ 0x885dab1fu) & v0));
                if ((0xae4a7f77u << ((unsigned)l0 & 31u))) break;
                w0 ^= (unsigned long long)(unsigned)((int)u0 >= (int)garr[i1 & 7u]) << ((u2 * (unsigned)(w0 >> 29)) & 63u);
                garr[(2u & r0.y) & 7u] = ((((g1 | 0xffffffffu) * 0x7fffffffu) << (i0 & 31u)) + (unsigned)h0);
                do { if (--fuel == 0u) goto done;
                    if ((0xa18a1474u / (u3 | 1u))) goto L0;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((4u ^ (unsigned)((int)(unsigned)x0 >= (int)0x7fffffffu)), (unsigned)c1, (unsigned)(u1 == ((unsigned)(x0 >> 70) ^ m0))); }
                    if (p0) break;
                } while (i2++ < 6u && ((unsigned)h0 << (4u & 31u)));
            } while (i1++ < 7u && (g1 | a0[i0 & 3u]));
        }
        L2: if (--fuel == 0u) goto done;
        switch ((unsigned)((0xffffffffu & *mp) || 0xffffffffu) & 7u) {
            { unsigned t0; double z0; if (((unsigned)((int)i1 < (int)(unsigned)(w0 >> 29))) & 1u) { t0 = (u3 - p0); z0 = (double)(((unsigned)(r0.x && (unsigned)h1)) & 255u); } if (((unsigned)((int)i1 < (int)(unsigned)(w0 >> 29))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                goto L1;
                if (((unsigned)s0 >> ((unsigned)e0 & 31u))) continue;
                if ((m0 & (unsigned)d0)) break;
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    i1 = (unsigned)((int)(3u ? (unsigned)c0 : garr[i1 & 7u]) >= (int)fuel) & 15u;
                }
            }
        }
        continue; (void)((unsigned)(unsigned char)(unsigned)((int)(i1 + (unsigned)s0) >= (int)p1));
        { unsigned t1; double z1; if (((unsigned)!(garr[u2 & 7u] >> (((unsigned)(x0 >> 70) | 0xf24e96c5u) & 31u))) & 1u) { t1 = 0xc63b16edu; z1 = (double)(((*mp ^ (unsigned)c0)) & 255u); } if (((unsigned)!(garr[u2 & 7u] >> (((unsigned)(x0 >> 70) | 0xf24e96c5u) & 31u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            if (r0.x) break;
            *q0 = (g0 % (((unsigned)w0 << (u0 & 31u)) | 1u));
        }
    }
    m0 ^= -(unsigned)((int)((unsigned)c0 * (((unsigned)w0 >> (7u & 31u)) ^ (unsigned)s1)) < (int)7u);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((unsigned)((0x10000u / (0x10000u | 1u)) && (unsigned)((int)g0 < (int)0x80000000u)) & 255u);
        goto L0;
        do { if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
            if ((i0 | m0)) {
                if ((unsigned)((unsigned)h0 < *mp)) {
                    if ((a0[i0 & 3u] >> ((unsigned)(w0 >> 29) & 31u))) break;
                    *q0 += 0xffffffffu;
                    break; (void)((unsigned)(((unsigned)b0 + a0[u1 & 3u]) && r0.x));
                } else {
                    u0 = u0 * 0x9e3779b1u + r0.x;
                    if (fuel < 8u) return (unsigned)((short)r0.y > (signed char)v0);
                }
                if (((unsigned)((int)p2 >= (int)(unsigned)d0) & (unsigned)f0)) break;
                s0 = (int)(0x40b5e8ddu >> ((unsigned)b0 & 31u));
                if ((unsigned)((short)i1 > (signed char)0xffffffffu)) break;
            }
            s1 = (int)((unsigned)s1 + (unsigned)!(p0 & ~((unsigned)(signed char)((unsigned)b0 - 0xffffffffu) ? (unsigned)s0 : a0[i0 & 3u])));
            *mp = (unsigned)((int)((unsigned)s1 ? i0 : (unsigned)(signed char)((unsigned)h1 % (0xaa416292u | 1u))) >= (int)0x63569e5u);
        } while (i1++ < 7u && (unsigned)((unsigned)l0 == (garr[i1 & 7u] / (1u | 1u))));
        c0 = (unsigned char)(unsigned)((int)(*q0 << ((unsigned)h0 & 31u)) < (int)(unsigned)h1);
    }
    u2 += ((unsigned)e0 + 7u);
    garr[(9u ^ 0xc08e8afu) & 7u] = r0.y;
    do { if (--fuel == 0u) goto done;
        L4: if (--fuel == 0u) goto done;
        { unsigned t2; double z2; if ((0x10000u) & 1u) { t2 = (p0 << ((unsigned)h1 & 31u)); z2 = (double)(((g1 + garr[u2 & 7u])) & 255u); } if ((0x10000u) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (((unsigned)d0 ? r0.x : (unsigned)s1) - (p2 >> (0x80000000u & 31u))));
            }
            m0 ^= (unsigned)((unsigned)(x0 >> 70) && 0x4a7a4d92u);
            s1 = (int)((unsigned)s1 + ((0x91d6acdfu - 0x41bf7f13u) >> ((unsigned)((int)2u >= (int)(unsigned)c1) & 31u)));
            if ((unsigned)((unsigned)((unsigned)d0 == (unsigned)x0) == i2)) break;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                r0.x = (unsigned)(((unsigned)f0 ? 0u : 0x10000u) || i2);
                s1 = (int)((unsigned)s1 + ((unsigned)(1u || garr[i1 & 7u]) + (0u ? r0.y : *mp)));
                e0 = e0 * 0.5L + (long double)(*mp & 1023u);
                i2 = (unsigned)((unsigned)(g0 == (unsigned)(x0 >> 70)) || ((unsigned)(signed char)((unsigned)c1 * u2) | (unsigned)e0)) & 15u;
                e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)((short)(0x58023c20u << (0x10000u & 31u)) > (signed char)~(unsigned)((int)a0[i0 & 3u] < (int)(unsigned)c0)) > (signed char)r0.x) & 1023u);
                if (0x80000000u) continue;
            }
        }
    } while (i0++ < 7u && (unsigned)(0x80000000u || (unsigned)(x0 >> 70)));
    if ((unsigned)h1) {
        if (r0.x) goto L2;
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)(short)(*mp >> (0xb04fe53fu & 31u)));
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)i1 < (int)i0), (unsigned)(signed char)(0xffffffffu | (0x16da6175u & i2)), (unsigned)(0x63b56343u == garr[u2 & 7u])); }
        }
        switch ((0xffffffffu | r0.x) & 7u) {
            c0 = (unsigned char)(garr[u2 & 7u] / ((unsigned)f0 | 1u));
            case 3u: ;
            case 5u: ;
            u2 = (0x864d3aafu & (unsigned)((short)i1 > (signed char)r0.y));
        }
        *q0 = (~(i0 ? (garr[i1 & 7u] ^ (unsigned)s0) : (unsigned)f0) * (unsigned)l0);
    }
    *q0 += (u1 - ((u3 >> (0x1ba127d7u & 31u)) & (unsigned)e0));
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t3; double z3; if (((i2 << ((unsigned)(signed char)(unsigned)((unsigned)c0 || 5u) & 31u))) & 1u) { t3 = (0x1cb2416u & (u3 / ((unsigned)c0 | 1u))); z3 = (double)((((unsigned)(unsigned char)(unsigned)((short)(unsigned)s1 > (signed char)0xdc85e0ddu) | u2)) & 255u); } if (((i2 << ((unsigned)(signed char)(unsigned)((unsigned)c0 || 5u) & 31u))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            i0 = a0[u1 & 3u] & 15u;
            if (((1u & (unsigned)e0) & g0)) break;
            if ((unsigned)(5u || 3u)) {
                if (0x821487f2u) break;
                if (((unsigned)((unsigned)h1 == i0) | (unsigned)h0)) {
                    c1 = (signed char)(unsigned)((int)(unsigned)c0 < (int)(0u + 1u));
                    m0 ^= (unsigned)(unsigned char)(((unsigned)x0 | ~(unsigned)((int)(unsigned)f0 < (int)p1)) ^ p0);
                    u3 ^= ((unsigned)((int)4u < (int)(unsigned)(u1 || u1)) & (unsigned)!(unsigned)(a0[u1 & 3u] < r0.x));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((g1 - 7u), ((unsigned)w0 << (g0 & 31u)), (unsigned)((unsigned)((int)p1 < (int)g1) || 0x3d6e29beu)); }
                } else {
                    if ((unsigned)(unsigned char)((unsigned)((int)0x54b7c25du >= (int)(unsigned)e0) << ((unsigned)s1 & 31u))) break;
                }
                goto L2;
                while (i1++ < 3u && 0xdad0c8cu) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (unsigned)h0;
                    if (i0) {
                        if ((unsigned)((int)a0[u1 & 3u] >= (int)garr[u2 & 7u])) break;
                        if (((unsigned)s0 - (unsigned)((int)(unsigned)c0 >= (int)0x1e2c9011u))) break;
                    }
                    u1 = (unsigned)((unsigned)(0x10000u && v0) < ~((p1 / ((unsigned)d0 | 1u)) >> (0x26323162u & 31u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)h1, -(i1 ? (unsigned)c1 : 0xffffffffu), 0x80000000u); }
                    while (i2++ < 7u && 4u) { if (--fuel == 0u) goto done;
                        break; (void)(p0);
                        continue; (void)((unsigned)c0);
                        break; (void)(g0);
                        *q0 += (unsigned)(unsigned char)(r0.y - ((i1 - (unsigned)d0) - i0));
                        if ((r0.x % ((unsigned)c0 | 1u))) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn2(u3, (0x7fffffffu / (0u | 1u)), 0xcbdfa42fu); }
                    }
                    w0 = w0 * 6364136223846793005ull + g0;
                }
                r0.x = (((unsigned)x0 * 0x8f73a763u) >> ((0x80000000u ? (unsigned)(w0 >> 29) : 0xffffffffu) & 31u));
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(0xffffffffu || p1), a0[u1 & 3u], (unsigned)(i0 && (unsigned)d0)); }
            } else {
                s1 = (int)((unsigned)s1 + (0x25e835b2u ? (unsigned)(*q0 == (unsigned)(short)(2u & g0)) : 0x6a75c57cu));
            }
            c1 = (signed char)(unsigned)w0;
        }
        b0 = ((unsigned)(0xaafebfc7u == a0[u1 & 3u]) % (u1 | 1u)) != 0u;
        if ((unsigned)(m0 < 0x80000000u)) break;
        if (((unsigned)(signed char)(0x5e3ccf7fu - (unsigned)x0) | 0x760fcc4bu)) {
            w0 ^= (unsigned long long)(p1 / (garr[u2 & 7u] | 1u)) << (((unsigned)(signed char)(m0 >> ((i2 | 0x5ab3dfa2u) & 31u)) % (p2 | 1u)) & 63u);
            f0 = f0 * 0.5f + (float)(-((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)((unsigned)c0 == 0x80000000u)) << ((unsigned)l0 & 31u)) & 255u);
            if (((unsigned)((unsigned)f0 < (unsigned)c0) - 6u)) {
                d0 = d0 * 0.5 + (double)(((3u / (u0 | 1u)) | (unsigned)((int)0x4c7d104du >= (int)0x10000u)) & 1023u);
                if ((unsigned)(-((unsigned)l0 & 0xc3db5384u) < m0)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn1(0x60a699a7u, (unsigned)((int)v0 >= (int)(unsigned)((int)r0.x < (int)0u)), (unsigned)e0); }
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)f0 << ((unsigned)d0 & 31u))) {
                        u1 += (unsigned)((int)(0xffffffffu * a0[i0 & 3u]) < (int)(0u + *mp));
                        c0 = (unsigned char)(0x25cc0eb8u ^ u1);
                        switch ((unsigned)((short)(unsigned)(g1 && 0x80000000u) > (signed char)g1) & 7u) {
                            w0 ^= (unsigned long long)a0[i0 & 3u] << ((unsigned)s1 & 63u);
                            case 3u: ;
                        }
                        *mp = (unsigned)((short)(unsigned)(short)(unsigned)((int)i0 < (int)(unsigned)((unsigned)(unsigned char)(unsigned)((int)(unsigned)s1 >= (int)u1) || *q0)) > (signed char)garr[i1 & 7u]);
                        if (((unsigned)c0 + u1)) {
                            if ((v0 << (r0.y & 31u))) break;
                            w0 = w0 * 6364136223846793005ull + (unsigned)(-((unsigned)(x0 >> 70) << ((unsigned)(0x7fffffffu < v0) & 31u)) && (unsigned)h0);
                            f0 = f0 * 0.5f + (float)(*mp & 255u);
                            garr[v0 & 7u] = ((unsigned)((0x773d16a4u + (unsigned)(x0 >> 70)) || *mp) % (((unsigned)s0 - u2) | 1u));
                            if (5u) goto L2;
                        } else {
                            u2 = ((unsigned)s0 & p2);
                            *q0 = (0x10000u | (unsigned)(u1 && fuel));
                            goto L2;
                        }
                    }
                    a0[r0.x & 3u] = (unsigned)(signed char)(unsigned)((garr[i1 & 7u] * (unsigned)s0) < (unsigned)(g0 || (unsigned)e0));
                }
            }
        } else {
            if ((unsigned)(unsigned char)(unsigned)(0xffffffffu && 3u)) continue;
            if (((u3 << ((unsigned)b0 & 31u)) & p1)) break;
            if ((unsigned)((short)((unsigned)(w0 >> 29) ^ (unsigned)l0) > (signed char)p2)) {
                s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)((unsigned)(unsigned char)(unsigned)((int)r0.x < (int)(unsigned)c1) / ((unsigned)e0 | 1u)));
                h1 = (unsigned short)(h1 + (unsigned)(u1 && (unsigned)!(*mp | (unsigned)(u1 == (0xc63d16c1u ^ 0x10000u)))));
                if ((unsigned)(i2 == (1u / (0x78167ac4u | 1u)))) continue;
            }
        }
        { unsigned t4; double z4; if (((p2 * (unsigned)f0)) & 1u) { t4 = (m0 % (fuel | 1u)); z4 = (double)((0xcf6c992u) & 255u); } if (((p2 * (unsigned)f0)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
            if ((unsigned)h1) {
                break; (void)((unsigned)(signed char)(unsigned)((int)*mp < (int)r0.x));
                do { if (--fuel == 0u) goto done;
                    if ((0x7fffffffu ? (unsigned)w0 : (unsigned)s1)) goto L0;
                    for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        h0 = (short)(unsigned)(short)(unsigned)((short)(unsigned)c1 > (signed char)0x7fffffffu);
                        f0 = f0 * 0.5f + (float)(u1 & 255u);
                        if ((unsigned)e0) break;
                        if ((u0 / (g1 | 1u))) break;
                        i1 = (unsigned)l0 & 15u;
                        if (fuel < 8u) return ((g1 ? g1 : (unsigned)f0) * u2);
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(x0 >> 70) / ((unsigned)s0 | 1u)), (unsigned)((int)(unsigned)c0 >= (int)*mp), (6u + p1)); }
                } while (i1++ < 2u && 0xe2d79f59u);
                c0 = (unsigned char)((((unsigned)c0 & 0u) >> ((unsigned)f0 & 31u)) >> (3u & 31u));
            }
            *q0 = (0x5176c874u & 0x622f479fu);
        }
        continue; (void)((unsigned)(g1 || ((unsigned)c0 - (unsigned)c0)));
    }
    while (i0++ < 7u && (i1 ^ (unsigned)b0)) { if (--fuel == 0u) goto done;
        m0 ^= ((unsigned)(0x10000u == (unsigned)(v0 && u2)) ? 0x7fb35ceu : (unsigned)f0);
    }
    for (;;) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2((0x7fffffffu & (unsigned)e0), (unsigned)((unsigned)((short)p1 > (signed char)(unsigned)(x0 >> 70)) < (unsigned)(x0 >> 70)), (0x80000000u + (u1 ^ (unsigned)e0))); }
        switch (((unsigned)d0 >> ((unsigned)d0 & 31u)) & 7u) {
            u0 = (unsigned)(x0 >> 70);
            *q0 += (unsigned)l0;
        }
        u1 = u1 * 0x9e3779b1u + ((unsigned)s0 | (unsigned)((short)(unsigned)w0 > (signed char)(u2 * g0)));
        u1 += (unsigned)(unsigned char)(unsigned)((unsigned)(0xca169da4u < garr[i1 & 7u]) && (0x874e4c1du & 0x779417bcu));
        { unsigned t5; double z5; if (((unsigned)((short)fuel > (signed char)(unsigned)c1)) & 1u) { t5 = ((unsigned)s0 & (unsigned)d0); z5 = (double)((v0) & 255u); } if (((unsigned)((short)fuel > (signed char)(unsigned)c1)) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
            if ((unsigned)(u2 || g1)) {
                s1 = (int)((unsigned)s1 + u1);
                e0 = e0 * 0.5L + (long double)(v0 & 1023u);
                m0 ^= (unsigned)(0x9b98fb20u || ((unsigned)(p0 || garr[u2 & 7u]) & 0x710cb829u));
                continue; (void)((2u - a0[u1 & 3u]));
                *q0 += ((unsigned)h0 | (unsigned)e0);
                if ((unsigned)((int)(unsigned)(g0 < 3u) >= (int)8u)) break;
            }
            while (i1++ < 6u && r0.x) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)h0, (r0.x ? 0x80000000u : a0[u1 & 3u]), (unsigned)(unsigned char)((unsigned)s0 & 0x7fffffffu)); }
            }
        }
    }
    if ((unsigned)(unsigned char)((9u % ((unsigned)x0 | 1u)) - (unsigned)f0)) goto done;
    *mp = (*mp >> ((unsigned)((short)((0u & 0x550150fcu) | 0xb0443c70u) > (signed char)a0[u1 & 3u]) & 31u));
    goto L3;
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(-(r0.x + u2) >> ((unsigned)b0 & 31u)), (0x80000000u | 0xe179a15bu), (unsigned)(garr[u2 & 7u] == (unsigned)((short)0xffffffffu > (signed char)i0))); }
    u3 += u3;
    if ((unsigned)(0xffffffffu == garr[u2 & 7u])) {
        if (garr[i1 & 7u]) goto L3;
        if ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(r0.x + (unsigned)h1))) {
            if ((unsigned)e0) goto done;
            while (i0++ < 7u && ((unsigned)h0 & (unsigned)(u2 || p2))) { if (--fuel == 0u) goto done;
                *q0 = 0x66e34378u;
            }
        } else {
            if (g1) goto done;
        }
        goto L4;
        u2 ^= (unsigned)(u0 || (unsigned)!(unsigned)((int)u0 < (int)u3));
        v0 = (u2 % ((m0 * (unsigned)c0) | 1u));
    } else {
        if (((unsigned)!(unsigned)((unsigned)w0 < u2) ^ garr[i1 & 7u])) {
            while (i0++ < 3u && (unsigned)d0) { if (--fuel == 0u) goto done;
                if (-((unsigned)((unsigned)s1 || p1) >> (4u & 31u))) break;
                q0 = &garr[(unsigned)(short)((unsigned)(w0 >> 29) ? (0x10000u >> (i1 & 31u)) : (unsigned)(m0 < 0u)) & 7u];
                w0 ^= (unsigned long long)(unsigned)x0 << ((unsigned)((int)(unsigned)c1 >= (int)i1) & 63u);
                w0 = w0 * 6364136223846793005ull + ((unsigned)f0 >> (((unsigned)(v0 || 0xbb34da6au) - p2) & 31u));
                s0 = (int)(unsigned)((int)5u >= (int)g1);
            }
        }
        switch (6u & 7u) {
            garr[(unsigned)s0 & 7u] = ((unsigned)(*mp == 7u) ^ r0.y);
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 3u: ;
                b0 = (i0 / (a0[u1 & 3u] | 1u)) != 0u;
                if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)s0 ^ i0), ((unsigned)w0 >> (u0 & 31u)), r0.x); }
                switch (((unsigned)h1 ^ a0[u1 & 3u]) & 7u) {
                    v0 = m0;
                    for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        s0 = (int)(0x7fffffffu | (unsigned)s0);
                    }
                    if ((unsigned)((short)0xc7b241c2u > (signed char)v0)) goto L1;
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        r0.y ^= (8u | ((unsigned)(signed char)(*mp << (*mp & 31u)) << (0x7fffffffu & 31u)));
                        *q0 += (0x80000000u >> (u2 & 31u));
                        s0 = (int)(0u >> (4u & 31u));
                        q0 = &garr[((unsigned)((r0.x + g0) && (unsigned)c1) ? (unsigned)h1 : garr[u2 & 7u]) & 7u];
                        if (((unsigned)c1 - (unsigned)(g0 || u1))) goto L2;
                        if (fuel < 8u) return (unsigned)(short)(8u >> ((unsigned)f0 & 31u));
                    }
                    *q0 += (unsigned)(unsigned char)(*q0 & (unsigned)(0x80000000u < (unsigned)c0));
                }
                w0 ^= (unsigned long long)(unsigned)(1u && 9u) << (-(unsigned)(r0.x < (fuel << (fuel & 31u))) & 63u);
            }
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                b0 = ((unsigned)s0 ^ ((unsigned)(0x18e5e210u < (unsigned)h0) ^ a0[u1 & 3u])) != 0u;
                c0 = (unsigned char)((unsigned)(0xeaac6668u && p1) - (u2 / (7u | 1u)));
                goto L3;
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)f0, (unsigned)(0xa4e3d525u || r0.x), ((unsigned)((int)(unsigned)c1 < (int)7u) ^ g1)); }
        goto L0;
    }
    goto L2;
    d0 = d0 * 0.5 + (double)(4u & 1023u);
    c0 = (unsigned char)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)s1) + (unsigned)s0);
    u0 += (((((unsigned)s0 >> (u2 & 31u)) * u2) % (*q0 | 1u)) & i0);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t6; double z6; if ((((r0.y / (0xaef216a0u | 1u)) | (unsigned)h0)) & 1u) { t6 = -((unsigned)((int)(unsigned)x0 >= (int)0x630ac19cu) ^ (unsigned)(w0 >> 29)); z6 = (double)((((g0 + (unsigned)l0) - (unsigned)c1)) & 255u); } if ((((r0.y / (0xaef216a0u | 1u)) | (unsigned)h0)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
            if ((unsigned)(0x10000u == 0x1079e33eu)) break;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(unsigned char)((unsigned)((int)1u >= (int)u0) + 0xc9e3aff6u), (unsigned)((unsigned)b0 < (unsigned)((unsigned)(w0 >> 29) < u2)), p1); }
                break; (void)((0x7fffffffu ? i0 : 0x55365abbu));
            }
        }
        switch ((unsigned)(signed char)(unsigned)((int)*mp < (int)fuel) & 7u) {
            case 5u: ;
            goto L4;
            e0 = e0 * 0.5L + (long double)(((unsigned)((int)p0 < (int)(unsigned)s0) ? (unsigned)l0 : (m0 + a0[u1 & 3u])) & 1023u);
        }
        if (((unsigned)h0 << ((u1 * (unsigned)h1) & 31u))) break;
        *mp = ((*q0 & (fuel / (m0 | 1u))) * 0xa11a2422u);
        *q0 = (u0 << ((unsigned)(g1 == p0) & 31u));
    }
    if (v0) {
        while ((unsigned)l0) { if (--fuel == 0u) goto done;
            *q0 = (unsigned)(r0.x < (unsigned)s1);
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)((short)r0.y > (signed char)(unsigned)b0) >> (u0 & 31u)), ((unsigned)((int)i0 < (int)3u) >> (g1 & 31u)), ((i1 * (unsigned)x0) / (p0 | 1u))); }
            if ((unsigned)(0x1b1fd4cbu < (5u * 5u))) {
                break; (void)(r0.x);
                if ((unsigned)((0x665de6a5u / (0x87b2e0f2u | 1u)) || 0x10000u)) {
                    while (i1++ < 6u && (unsigned)((unsigned)f0 && (0xffffffffu & i2))) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn1(v0, ((0x30d41ff1u * p2) ^ 0x32d80eacu), *q0); }
                        continue; (void)((unsigned)((int)g1 >= (int)*mp));
                        c1 = (signed char)(unsigned)(signed char)(unsigned)((int)(unsigned)b0 >= (int)(unsigned)(signed char)(unsigned)(4u && u0));
                    }
                    c0 = (unsigned char)(unsigned)((short)(unsigned)f0 > (signed char)(unsigned)s0);
                    break; (void)((p0 ^ 1u));
                } else {
                    c1 = (signed char)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)r0.y) | (i1 + (unsigned)(signed char)(g1 & (unsigned)(x0 >> 70))));
                    do { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)(signed char)(m0 << (r0.x & 31u)));
                        if (budget != 0u) { budget -= 1u; u1 = fn1(garr[u2 & 7u], (unsigned)w0, (r0.x ^ u0)); }
                        break; (void)(g1);
                        if ((unsigned)c0) break;
                        r0.y ^= (garr[u2 & 7u] & a0[i0 & 3u]);
                        switch ((unsigned)(w0 >> 29) & 7u) {
                            case 7u: ;
                            if (((unsigned)c0 / ((g1 * 3u) | 1u))) continue;
                            break; (void)(-((unsigned)(a0[u1 & 3u] && r0.y) - i0));
                            m0 ^= (unsigned)((int)~(u0 % (u3 | 1u)) < (int)(unsigned)((unsigned)(short)(u3 << (0x9d7fed7au & 31u)) < i1));
                            u0 += (unsigned)(((unsigned)d0 >> ((unsigned)(short)(unsigned)((short)(9u << ((unsigned)h1 & 31u)) > (signed char)(unsigned)d0) & 31u)) == 0x1f3528e8u);
                            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)c0 && v0));
                        }
                    } while (i1++ < 6u && (unsigned)((short)p0 > (signed char)p2));
                    g0 = (unsigned)((int)3u < (int)(unsigned)((int)0x7fffffffu < (int)fuel));
                }
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(i0 < 7u), i1, (unsigned)(signed char)((unsigned)((short)u0 > (signed char)r0.x) ^ (unsigned)(w0 >> 29))); }
        c0 = (unsigned char)(p0 >> ((unsigned)(x0 >> 70) & 31u));
        g1 += (0x7fffffffu + (unsigned)b0);
    }
    while (i0++ < 2u && (a0[i0 & 3u] >> (u1 & 31u))) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)(unsigned)(r0.y && g1) > (signed char)(unsigned)l0)) goto L3;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((p0 / (i0 | 1u)) & 1023u);
        { unsigned t7; double z7; if (((unsigned)((int)i0 < (int)(unsigned)c1)) & 1u) { t7 = (unsigned)((short)*q0 > (signed char)u0); z7 = (double)((0xffffffffu) & 255u); } if (((unsigned)((int)i0 < (int)(unsigned)c1)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
            q0 = &garr[(((unsigned)((int)(unsigned)s0 < (int)r0.x) ^ i2) | (unsigned)(0xc716ea35u || 9u)) & 7u];
            a0[(unsigned)((int)0x99d20fbfu >= (int)(unsigned)(w0 >> 29)) & 3u] = (unsigned)b0;
            break; (void)(v0);
            if (u2) break;
        }
        if ((unsigned)e0) break;
        l0 = (long)((unsigned long)l0 + ((unsigned)!(i1 ^ (unsigned)h0) | i2));
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)c1 && *mp)) break;
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    q0 = &garr[(unsigned)((0xe4182d0bu - 0x10000u) < (unsigned)b0) & 7u];
    if (u3 == 7u) return ((unsigned)!(unsigned)((p0 / (garr[u2 & 7u] | 1u)) && 0x32daac94u) & (r0.y * 5u));
    m0 ^= (((unsigned)(x0 >> 70) + (unsigned)x0) | ((unsigned)(w0 >> 29) ? a0[i0 & 3u] : i0));
    while (i0++ < 3u && 0xffffffffu) { if (--fuel == 0u) goto done;
        if ((unsigned)l0) {
            e0 = e0 * 0.5L + (long double)(((a0[i0 & 3u] | (unsigned)b0) & (m0 - (unsigned)((int)0x20b7e866u >= (int)(unsigned)l0))) & 1023u);
            if ((unsigned)((int)8u < (int)(unsigned)(a0[i0 & 3u] < *q0))) {
                i0 = -(unsigned)((int)((unsigned)s1 * (unsigned)((int)i2 >= (int)0x80000000u)) >= (int)1u) & 15u;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)e0, (unsigned)x0, (u0 | p0)); }
            } else {
                L0: if (--fuel == 0u) goto done;
                { unsigned t0; double z0; if (((unsigned)(0x943097bdu < (unsigned)s1)) & 1u) { t0 = (0xa4deb0c5u * -(a0[u1 & 3u] << (r0.x & 31u))); z0 = (double)(((unsigned)((int)0xd41d2e9u >= (int)i1)) & 255u); } if (((unsigned)(0x943097bdu < (unsigned)s1)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                    u0 ^= (a0[u1 & 3u] >> (-(unsigned)((int)((3u << (v0 & 31u)) + 9u) < (int)m0) & 31u));
                    u2 = u2 * 0x9e3779b1u + (unsigned)((int)0x10000u < (int)(0x80000000u + m0));
                    if ((unsigned)(r0.x == ((unsigned)s0 & (unsigned)h1))) break;
                    f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(unsigned)(0x8f961b6cu && (unsigned)h1) & 255u);
                }
                u0 += (unsigned)(0x80000000u || 6u);
            }
            d0 = d0 * 0.5 + (double)((a0[u1 & 3u] ^ (unsigned)h1) & 1023u);
        }
    }
    if ((unsigned)(0xcf3c5bb4u < 0xe9442b0cu)) goto L2;
    if (((unsigned)f0 & (unsigned)(short)(*q0 % ((unsigned)s1 | 1u)))) goto done;
    u0 = u0 * 0x9e3779b1u + (unsigned)(unsigned char)(0x80000000u + (unsigned)(signed char)(unsigned)(8u || g0));
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 = ((unsigned)(8u && (unsigned)(x0 >> 70)) + i0);
        break; (void)((unsigned)h1);
        if (fuel < 8u) return (unsigned)!(((unsigned)(w0 >> 29) + (unsigned)((unsigned)h0 < (i1 >> ((unsigned)c1 & 31u)))) & 9u);
    }
    for (;;) { if (--fuel == 0u) goto done;
        i0 = ((unsigned)s1 - (unsigned)!(unsigned)(0x75d9d2e6u == ((unsigned)(u0 || a0[u1 & 3u]) | 0x7fffffffu))) & 15u;
    }
    f0 = f0 * 0.5f + (float)((unsigned)(signed char)(0u % (((unsigned)((short)0x7fffffffu > (signed char)garr[u2 & 7u]) & 3u) | 1u)) & 255u);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = *q0;
    }
    w0 = w0 * 6364136223846793005ull + (((unsigned)((int)0x7fffffffu >= (int)0xd115523fu) << (v0 & 31u)) & (unsigned)(garr[u2 & 7u] || 0x80000000u));
    if ((unsigned)((unsigned)((short)6u > (signed char)0xaabe55a4u) < 0xffffffffu)) {
        i0 = ((unsigned)h1 / (((unsigned)h1 << (i0 & 31u)) | 1u)) & 15u;
        L1: if (--fuel == 0u) goto done;
        u1 += (p0 | ((unsigned)c1 + u1));
        for (;;) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)-(unsigned)(*mp < m0);
                if (budget != 0u) { budget -= 1u; u0 = fn0(p0, (r0.y | g0), (garr[i1 & 7u] & (unsigned)((short)i1 > (signed char)(unsigned)d0))); }
            }
            g0 = ((unsigned)(fuel && r0.y) ^ (unsigned)(g1 < 0xffffffffu));
        }
    } else {
        u1 = u2;
        if ((unsigned)(short)(unsigned)((int)r0.y >= (int)u3)) {
            u0 = u0 * 0x9e3779b1u + ((unsigned)d0 % ((unsigned)(7u < 0x10000u) | 1u));
            if ((unsigned)(short)(0x27741fd6u ^ (p2 & u2))) {
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)c0 == (unsigned)e0)) goto L1;
                }
                u3 = u3 * 0x9e3779b1u + r0.x;
                h0 = (short)r0.y;
                v0 = ((unsigned)d0 + -((unsigned)l0 ^ u0));
            }
            L2: if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)s1 < p1)) {
                s0 = (int)(0x80000000u ^ ((unsigned)w0 ^ (unsigned)(x0 >> 70)));
                *q0 += (unsigned)(((unsigned)(w0 >> 29) ? 0x5f3449a8u : (unsigned)(signed char)(0xbea63f67u >> (garr[u2 & 7u] & 31u))) || garr[i1 & 7u]);
            } else {
                c0 = (unsigned char)(unsigned)((int)((unsigned)(i0 && (unsigned)s0) - u0) < (int)8u);
                c1 = (signed char)((unsigned)(8u < (unsigned)f0) + (fuel << (5u & 31u)));
                for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (7u) {
                            h1 = (unsigned short)(h1 + (unsigned)(0x7fffffffu == (r0.y & g1)));
                            *mp = (unsigned)(signed char)(unsigned)((unsigned)s0 == 0xf0ff6d28u);
                            s0 = (int)(((unsigned)(((unsigned)h0 | 0x7f60fa01u) < 0xf6d8f360u) & (unsigned)b0) * m0);
                            L3: if (--fuel == 0u) goto done;
                            l0 = (long)((unsigned long)l0 + -(unsigned)(r0.y && (unsigned)(unsigned char)(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)e0)));
                            if (budget != 0u) { budget -= 1u; u1 = fn0((0xf29658cfu * a0[i0 & 3u]), (unsigned)((int)(unsigned)((short)a0[i0 & 3u] > (signed char)0x1938a02du) < (int)m0), u3); }
                        } else {
                            L4: if (--fuel == 0u) goto done;
                            *q0 = r0.y;
                        }
                        if ((unsigned)(signed char)(unsigned)(u0 && (unsigned)(signed char)((unsigned)f0 >> (3u & 31u)))) break;
                        a0[0xc5b0b1c7u & 3u] = (unsigned)h0;
                        s1 = (int)((unsigned)s1 + (u3 * (~(unsigned)(0x80000000u < u3) & (unsigned)e0)));
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)s1 & (unsigned)s0), (unsigned)((unsigned)s1 < ((unsigned)l0 >> (u3 & 31u))), (unsigned)(0x6eecbdf1u || (u1 - (unsigned)d0))); }
                    break; (void)((unsigned)((0xd477cbadu << (r0.x & 31u)) || 7u));
                }
            }
            if (0x10000u) {
                if (budget != 0u) { budget -= 1u; u3 = fn3(-(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)s0), (unsigned)(x0 >> 70), 0xcf6512e3u); }
                if ((unsigned)e0) goto L4;
                if (budget != 0u) { budget -= 1u; u0 = fn2((0xf0e98b1cu << ((unsigned)((int)a0[i0 & 3u] >= (int)*mp) & 31u)), (unsigned)((unsigned)((short)(unsigned)w0 > (signed char)i0) < (unsigned)x0), (unsigned)(garr[i1 & 7u] || 0x3767e668u)); }
                if ((unsigned)e0) goto L2;
                if ((unsigned)(u0 && i2)) {
                    goto L3;
                    if ((unsigned)(x0 >> 70)) {
                        r0.x = p2;
                        x0 = x0 * 0x100000001b3ull + ((unsigned)w0 & garr[u2 & 7u]);
                        goto done;
                    } else {
                        if ((p1 << (fuel & 31u))) {
                            if ((r0.y ? (unsigned)s1 : 0u)) goto L1;
                            goto L3;
                            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)4u > (signed char)u2), (unsigned)(unsigned char)(unsigned)((p2 ^ 5u) && 0x80000000u), 0x3ae62bf1u); }
                        }
                        b0 = ((unsigned)(w0 >> 29) + fuel) != 0u;
                    }
                    if ((unsigned)(unsigned char)(0x7fffffffu ^ (v0 * p2))) goto done;
                    u3 = u3 * 0x9e3779b1u + (unsigned)(v0 < (0u * -((unsigned)w0 ^ 0x80000000u)));
                    m0 ^= ((unsigned)w0 & ~(r0.y >> ((u1 >> (((unsigned)f0 ^ a0[u1 & 3u]) & 31u)) & 31u)));
                    if (budget != 0u) { budget -= 1u; u3 = fn2((3u - 0u), ((i2 << ((unsigned)c0 & 31u)) % ((unsigned)h1 | 1u)), -(unsigned)((unsigned)((int)0xb0a73574u >= (int)r0.x) || 0x80000000u)); }
                } else {
                    while (u0) { if (--fuel == 0u) goto done;
                        if ((0x7fffffffu % (0x502a7959u | 1u))) break;
                        v0 = (unsigned)h1;
                        l0 = (long)((unsigned long)l0 + ((unsigned)h1 | (0xffffffffu / ((unsigned)((int)(unsigned)((unsigned)(x0 >> 70) < u3) < (int)9u) | 1u))));
                        v0 = ((unsigned)((unsigned)d0 && garr[u2 & 7u]) % ((unsigned)(unsigned char)(unsigned)((short)u2 > (signed char)(unsigned)!((unsigned)c0 * *q0)) | 1u));
                        if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)d0 - p1), fuel, (unsigned)(4u && (unsigned)h0)); }
                        w0 ^= (unsigned long long)7u << ((unsigned)((short)i2 > (signed char)0x10000u) & 63u);
                    }
                    s0 = (int)((unsigned)(r0.x || (unsigned)b0) / (((unsigned)f0 * 0xe0ce189bu) | 1u));
                    r0.y ^= (unsigned)((g1 & 0x80000000u) && a0[u1 & 3u]);
                    if (*mp) goto L0;
                }
            }
        } else {
            goto L0;
            goto done;
            switch ((0x7fffffffu ^ (0x80000000u * (unsigned)l0)) & 7u) {
                case 1u: ;
                if (u3 == 7u) return (p1 | (garr[u2 & 7u] | (i0 - a0[i0 & 3u])));
                if (budget != 0u) { budget -= 1u; u0 = fn1((0x7b03a58eu | (g0 + 0x80000000u)), p2, (unsigned)((int)g0 < (int)(unsigned)f0)); }
            }
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)h1 - (0xc75c6a22u & (unsigned)b0)), (unsigned)(i1 && (unsigned)!(unsigned)((int)2u >= (int)*q0)), g0); }
            while (garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                *q0 = 0x628e2e6bu;
                c0 = (unsigned char)(m0 ^ garr[i1 & 7u]);
                if (budget != 0u) { budget -= 1u; u3 = fn1(0x10000u, (unsigned)(((unsigned)l0 * 0xc2975ed6u) || fuel), (u0 | ((unsigned)(x0 >> 70) ^ (unsigned)c1))); }
            }
            if ((unsigned)e0) {
                garr[g1 & 7u] = (unsigned)((int)(unsigned)((int)(unsigned)d0 < (int)garr[u2 & 7u]) < (int)0xffffffffu);
                b0 = ((unsigned)(x0 >> 70) ^ (unsigned)x0) != 0u;
            }
        }
        g0 = ((unsigned)!(1u ^ (unsigned)h1) >> ((9u / ((unsigned)(w0 >> 29) | 1u)) & 31u));
    }
    u0 = u0 * 0x9e3779b1u + (unsigned)((int)(unsigned)h1 < (int)0xdb29bf8du);
    l0 = (long)((unsigned long)l0 + ((unsigned)e0 ? (unsigned)(0x1b6f9778u == 0xffffffffu) : u0));
    s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)((0x10000u - 3u) * (unsigned)((short)0x488dbd6u > (signed char)p0)));
    switch ((unsigned)(0xffffffffu || g0) & 7u) {
        case 1u: ;
        goto L3;
        a0[v0 & 3u] = (unsigned)((short)u0 > (signed char)0xffffffffu);
    }
    if ((unsigned)((int)i0 < (int)(unsigned)((unsigned)c1 < 0x38bf787fu))) {
        if ((unsigned)(x0 >> 70)) {
            l0 = (long)((unsigned long)l0 + (unsigned)e0);
            if (((unsigned)(0x1f35fe41u == v0) - (unsigned)e0)) goto L4;
            if ((unsigned)((short)p1 > (signed char)i1)) goto L2;
            *mp = ((unsigned)h1 >> ((unsigned)(signed char)(r0.y >> (u2 & 31u)) & 31u));
        } else {
            u0 = ((unsigned)b0 << (0xcde22fccu & 31u));
            if ((i2 & 0x80000000u)) {
                m0 ^= (unsigned)(((p2 * (unsigned)h0) - u0) < 0x7fffffffu);
                r0.x = (unsigned)(unsigned char)(0x10000u & (unsigned)((unsigned)c0 == g0));
                goto L0;
                x0 = x0 * 0x100000001b3ull + (0xbe4b9b3du >> (p1 & 31u));
                if ((0x1fefde33u - a0[i0 & 3u])) {
                    if (budget != 0u) { budget -= 1u; u1 = fn3(1u, ((unsigned)s1 & (3u ^ (unsigned)l0)), p0); }
                } else {
                    c0 = (unsigned char)(i0 ? m0 : 0xffffffffu);
                }
                *q0 += ((unsigned)e0 & ((2u ? (unsigned)(x0 >> 70) : 0xffffffffu) * (unsigned)(w0 >> 29)));
            } else {
                a0[(unsigned)((int)0x80000000u >= (int)(unsigned)s1) & 3u] = (unsigned)(unsigned char)(unsigned)((short)(0xffffffffu - 0x80000000u) > (signed char)0x7fffffffu);
                if (i0) goto done;
                for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (0x7fffffffu % ((unsigned)s1 | 1u));
                }
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(short)(unsigned)((int)g0 < (int)0x7fffffffu), 0x53515ac9u, (unsigned)((int)0u < (int)0x7fffffffu)); }
            }
            *mp = (unsigned)((i1 | *q0) == 0x10000u);
            if (budget != 0u) { budget -= 1u; u2 = fn0((a0[u1 & 3u] & 0xd3ccb616u), *q0, -(((unsigned)b0 - 0x46c24fbau) + (unsigned)c0)); }
        }
        l0 = (long)((unsigned long)l0 + u1);
        goto L4;
        *mp = ((unsigned)(signed char)((a0[i0 & 3u] << ((unsigned)w0 & 31u)) ? p1 : v0) - garr[i1 & 7u]);
        b0 = (unsigned)(signed char)((0x7fffffffu << ((unsigned)f0 & 31u)) >> (((unsigned)c1 | 0xd640c647u) & 31u)) != 0u;
    } else {
        u1 += i0;
        if (m0) {
            while (i0++ < 5u && (unsigned)(u0 == garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                r0.x = (unsigned)c1;
            }
            u0 ^= (unsigned)((unsigned)((int)0x10000u >= (int)(unsigned)w0) && p0);
        } else {
            c1 = (signed char)(unsigned)((short)0x7fffffffu > (signed char)(0x304445bdu - p2));
            { unsigned t1; double z1; if (((unsigned)((unsigned)s1 || *q0)) & 1u) { t1 = (u0 % (fuel | 1u)); z1 = (double)(((unsigned)(0u < (unsigned)x0)) & 255u); } if (((unsigned)((unsigned)s1 || *q0)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                r0.y ^= (unsigned)s1;
                if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)w0 - i0), (((unsigned)s1 ^ r0.x) * 0u), (unsigned)((int)(unsigned)s1 < (int)0x3f3ed6bdu)); }
            }
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(signed char)(0x48cb9fafu % ((u0 << ((unsigned)h1 & 31u)) | 1u))) break;
            }
            goto L0;
        }
    }
    if ((unsigned)(g1 == (0xa70907a9u ^ 0x10000u))) {
        do { if (--fuel == 0u) goto done;
            a0[(unsigned)(unsigned char)(p1 + (unsigned)f0) & 3u] = ~(unsigned)(0xb4e070a0u < ((unsigned)e0 / (v0 | 1u)));
            f0 = f0 * 0.5f + (float)((g1 - u2) & 255u);
        } while (i0++ < 3u && (unsigned)(p2 || (unsigned)s1));
        do { if (--fuel == 0u) goto done;
            if (~(0x80000000u & *mp)) continue;
            if (fuel < 8u) return ((unsigned)x0 >> (((unsigned)f0 >> (0xf42e3fcdu & 31u)) & 31u));
            r0.y ^= (unsigned)((int)(unsigned)(1u && *mp) < (int)(unsigned)!(unsigned)((int)0x20578e75u >= (int)(unsigned)(signed char)((unsigned)(x0 >> 70) + m0)));
            h1 = (unsigned short)(h1 + (unsigned)s1);
            u0 += *mp;
        } while (i0++ < 6u && (unsigned)((int)(unsigned)(unsigned char)((unsigned)h0 & 0x80000000u) >= (int)i2));
    } else {
        g0 = (unsigned)(9u || m0);
    }
    do { if (--fuel == 0u) goto done;
        m0 ^= (unsigned)((short)-(unsigned)((short)(unsigned)f0 > (signed char)p0) > (signed char)(unsigned)(unsigned char)(unsigned)((int)*mp < (int)(*q0 * r0.x)));
        switch (*mp & 7u) {
            c1 = (signed char)9u;
            if ((m0 - (9u >> (0u & 31u)))) break;
            case 6u: ;
            case 3u: ;
        }
        if ((unsigned)(short)(unsigned)(*mp || (a0[i0 & 3u] / (0xffffffffu | 1u)))) goto L4;
    } while (i0++ < 7u && (unsigned)(signed char)(-(u3 - (unsigned)b0) - p1));
    switch ((unsigned)!(*q0 % ((unsigned)((int)r0.x >= (int)7u) | 1u)) & 7u) {
        goto L0;
        garr[u3 & 7u] = 0x80000000u;
        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)(unsigned char)(r0.y << (g0 & 31u)) + u1), g1, (unsigned)(a0[u1 & 3u] || (unsigned)!((unsigned)s1 >> ((unsigned)x0 & 31u)))); }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn2((0xffffffffu % (0xffffffffu | 1u)), (unsigned)((int)(unsigned)l0 >= (int)*mp), ((unsigned)s0 ^ 0x10000u)); }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((unsigned)e0 & 1023u);
        while (i1++ < 3u && (0xcc784ee5u ^ garr[u2 & 7u])) { if (--fuel == 0u) goto done;
            a0[(unsigned)f0 & 3u] = (unsigned)(short)((unsigned)!(unsigned)((short)i2 > (signed char)7u) - u0);
            *mp = (unsigned)((int)(unsigned)(0x10000u < u3) >= (int)(unsigned)c1);
            if (0x10000u) break;
            s0 = (int)(unsigned)(0x10000u < 0u);
            i0 = (unsigned)(((unsigned)c0 + m0) && g1) & 15u;
            if ((3u << ((unsigned)((short)0x7fffffffu > (signed char)u3) & 31u))) break;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn2((p2 ^ 0xc75db7b6u), (unsigned)((unsigned)s1 && (unsigned)f0), (unsigned)(6u && (unsigned)s1)); }
        c1 = (signed char)(unsigned)e0;
        if ((unsigned)((int)(unsigned)((int)(unsigned)(x0 >> 70) < (int)a0[u1 & 3u]) < (int)i2)) continue;
    }
    w0 ^= (unsigned long long)0x10000u << (((unsigned)(unsigned char)(unsigned)((short)((unsigned)s1 / (i1 | 1u)) > (signed char)(unsigned)(x0 >> 70)) >> (0x80000000u & 31u)) & 63u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 4u, 0x2a1acc8du, 0xb7cb6869u },
        { 11u, 0x3c831659u, 0x1a6529dbu },
        { 9u, 0x297ac9a6u, 0x3b9ba646u },
        { 13u, 0x8df5869eu, 0xe5adee8bu },
        { 7u, 0x9982e9ebu, 0x224f13cfu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
