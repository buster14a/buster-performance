// test-ssa-source's program of seed 134000417 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xb5f78b29u, g1 = 0x365af942u;
static unsigned garr[8] = { 0x590e03d2u, 0x7b7461acu, 0x811ffb3au, 0x2810a526u, 0x3a0ec329u, 0x750b6cb2u, 0xdccd0018u, 0x38fc81b1u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    u3 = (m0 | 6u);
    switch ((unsigned)f0 & 7u) {
        if (((unsigned)(short)(unsigned)(*q0 || (unsigned)d0) + 1u)) goto L1;
        while (i0++ < 5u && (unsigned)(unsigned char)(unsigned)(((unsigned)(x0 >> 70) - 0x80000000u) && 0x41c1a9aau)) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + (unsigned)((int)~(unsigned)((0xffffffffu * (unsigned)(signed char)(garr[i1 & 7u] % ((unsigned)l0 | 1u))) == (unsigned)h0) >= (int)u1));
            L0: if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if (((unsigned)((int)p1 < (int)0x10000u)) & 1u) { t0 = p0; z0 = (double)(((i0 | (unsigned)(unsigned char)(unsigned)((unsigned)h0 < g0))) & 255u); } if (((unsigned)((int)p1 < (int)0x10000u)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                x0 = x0 * 0x100000001b3ull + (0x7fffffffu | garr[u2 & 7u]);
            }
            if ((unsigned)(short)(u1 ^ (a0[u1 & 3u] ^ (unsigned)(x0 >> 70)))) goto L3;
        }
    }
    goto done;
    if ((unsigned)(0xfd2112dbu || 0xffffffffu)) goto done;
    g1 += (g1 * (unsigned)(9u == (unsigned)(a0[u1 & 3u] || (unsigned)((int)(unsigned)b0 < (int)(unsigned)x0))));
    garr[(unsigned)((int)0x7fffffffu < (int)(unsigned)w0) & 7u] = (unsigned)(-(i0 ^ g1) && (u3 & 0u));
    s0 = (int)(unsigned)(short)(unsigned)((int)0u >= (int)(unsigned)((unsigned)f0 < (unsigned)((unsigned)(signed char)(u0 | (unsigned)(x0 >> 70)) || u1)));
    L1: if (--fuel == 0u) goto done;
    *q0 = (g0 << ((unsigned)((unsigned)l0 && (0x80000000u ? u1 : a0[i0 & 3u])) & 31u));
    if ((6u / (fuel | 1u))) goto L0;
    if (-((unsigned)h0 % (7u | 1u))) goto L0;
    if ((unsigned)(0x80000000u < (m0 % (p2 | 1u)))) goto L0;
    if ((a0[i0 & 3u] + a0[u1 & 3u])) goto L1;
    if ((unsigned)!(u3 + 0xffffffffu)) {
        w0 ^= (unsigned long long)8u << (u3 & 63u);
    }
    L2: if (--fuel == 0u) goto done;
    h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)(0u == 0xe1e6d97cu) >= (int)(unsigned)((int)0x80000000u < (int)u3)));
    h0 = (short)(garr[i1 & 7u] ? (unsigned)c0 : fuel);
    L3: if (--fuel == 0u) goto done;
    switch (v0 & 7u) {
        break; (void)((unsigned)((int)2u < (int)(unsigned)h1));
        L4: if (--fuel == 0u) goto done;
        case 1u: ;
        default: ;
    }
    e0 = e0 * 0.5L + (long double)(((*q0 ^ 3u) + (garr[u2 & 7u] ^ m0)) & 1023u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(p2 || (unsigned)(unsigned char)(7u - u2))) goto L4;
    w0 = w0 * 6364136223846793005ull + ((unsigned)((unsigned)e0 == ((unsigned)c0 + (unsigned)x0)) % (((unsigned)(w0 >> 29) - a0[u1 & 3u]) | 1u));
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x6de77667u && u3), (unsigned)(4u || (unsigned)(0xf5cedbf2u && (unsigned)h1)), ~(0xe367249bu ? (unsigned)x0 : a0[u1 & 3u])); }
    do { if (--fuel == 0u) goto done;
        i0 = u2 & 15u;
        if ((g1 * (*q0 >> ((unsigned)s0 & 31u)))) break;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)h0 && (unsigned)e0), 0xd1192725u, (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)((int)0x80ff7818u < (int)i1))); }
            if (((unsigned)l0 ^ (unsigned)s0)) {
                if (-((unsigned)c0 - (unsigned)e0)) break;
                if ((fuel / (8u | 1u))) goto L3;
                s1 = (int)((unsigned)s1 + (0x7fffffffu / ((unsigned)((int)(unsigned)s1 < (int)garr[i1 & 7u]) | 1u)));
                break; (void)((unsigned)(short)(unsigned)((unsigned)h0 < 0x53a0e0bau));
            }
            while (i2++ < 2u && ~(unsigned)(1u < (unsigned)x0)) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)b0 < (int)0x586ed551u)) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(8u && ((unsigned)x0 | i1)), (((unsigned)d0 & (unsigned)h0) << (5u & 31u)), (unsigned)b0); }
                    v0 = (unsigned)(6u == ((unsigned)x0 / (u3 | 1u)));
                    g0 = (u1 - garr[u2 & 7u]);
                    goto L3;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(p1, 1u, r0.x); }
                }
                f0 = f0 * 0.5f + (float)((unsigned)((int)g1 >= (int)p1) & 255u);
                *q0 += ((unsigned)(0xac82fc3fu && 0x7fffffffu) % ((unsigned)(v0 && u3) | 1u));
                w0 ^= (unsigned long long)0x10000u << (((unsigned)(unsigned char)(~(unsigned)((int)fuel >= (int)m0) / ((unsigned)(short)(v0 | p1) | 1u)) * 9u) & 63u);
                c1 = (signed char)u2;
                if ((u2 & 0x10000u)) break;
            }
            if ((p0 + p1)) {
                break; (void)((fuel / (0xc2668450u | 1u)));
                v0 = (unsigned)(short)(unsigned)(p1 < 0xb7376aeeu);
            } else {
                w0 = w0 * 6364136223846793005ull + (g0 / (*q0 | 1u));
            }
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                g1 += g1;
                m0 ^= u1;
                switch (((unsigned)(u0 || (unsigned)s1) >> (0x80000000u & 31u)) & 7u) {
                    while (i0++ < 6u && ((garr[u2 & 7u] % ((unsigned)s1 | 1u)) * u0)) { if (--fuel == 0u) goto done;
                        L0: if (--fuel == 0u) goto done;
                        break; (void)(0x52041a35u);
                        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u2 = fn0(((0x10000u % ((unsigned)(x0 >> 70) | 1u)) / ((unsigned)e0 | 1u)), (unsigned)l0, (unsigned)w0); }
                            if ((unsigned)((short)u2 > (signed char)(unsigned)((int)(unsigned)c1 >= (int)u3))) continue;
                        }
                        case 7u: ;
                    }
                    g0 = ((u1 % ((unsigned)l0 | 1u)) - (u1 ? 0xc6d3080du : 0xffffffffu));
                    *mp = (unsigned)s0;
                    u1 ^= (unsigned)(w0 >> 29);
                    case 3u: ;
                    do { if (--fuel == 0u) goto done;
                        default: ;
                        L1: if (--fuel == 0u) goto done;
                    } while (i0++ < 7u && p0);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)c1 | r0.x), ((5u - i0) / (0x7fffffffu | 1u)), (-(unsigned)(*q0 && u3) | g1)); }
                g1 += ~(g0 * garr[u2 & 7u]);
            }
            g1 += (p0 / ((unsigned)((short)g0 > (signed char)(unsigned)h0) | 1u));
        }
        g0 = p0;
        w0 ^= (unsigned long long)u2 << (r0.x & 63u);
    } while (i0++ < 5u && (i2 - (unsigned)((unsigned)h0 == 3u)));
    while (i0++ < 7u && (unsigned)((int)(unsigned)((short)*mp > (signed char)i0) >= (int)i0)) { if (--fuel == 0u) goto done;
        if (~(p0 * (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)h0))) {
            if ((unsigned)((unsigned)b0 < (unsigned)(unsigned char)(unsigned)(garr[i1 & 7u] < *mp))) break;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)2u < (int)(unsigned)((int)4u >= (int)0xe890ead5u)), (unsigned)((short)~(8u * garr[u2 & 7u]) > (signed char)0xffffffffu), ~(unsigned)(p0 < (unsigned)b0)); }
            h1 = (unsigned short)(h1 + ((0x94ab6716u + u2) ? (unsigned)(p0 || (unsigned)h0) : (unsigned)d0));
            v0 = (unsigned)(w0 >> 29);
            l0 = (long)((unsigned long)l0 + (g1 >> (-(unsigned)(u3 == (3u << ((unsigned)h0 & 31u))) & 31u)));
            u3 ^= 0x7fffffffu;
        }
        do { if (--fuel == 0u) goto done;
            switch ((unsigned)h0 & 7u) {
                b0 = ((g1 ^ (0x80000000u ^ 0x80000000u)) / ((*mp >> (g0 & 31u)) | 1u)) != 0u;
                r0.x = (p1 >> ((unsigned)((int)(unsigned)c1 >= (int)(unsigned)((garr[i1 & 7u] & u2) == p2)) & 31u));
                if ((p0 % ((unsigned)((short)i2 > (signed char)*mp) | 1u))) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0(i0, r0.x, (p0 ^ r0.y)); }
                    c0 = (unsigned char)(unsigned)((((unsigned)f0 + fuel) | 0x7fffffffu) || ((unsigned)c1 % (g1 | 1u)));
                    if (((unsigned)l0 - 8u)) break;
                    if (u3 == 7u) return (g0 ^ (unsigned)((unsigned)e0 < ((unsigned)b0 | garr[u2 & 7u])));
                    h0 = (short)~((unsigned)(garr[i1 & 7u] < u1) / (0x87d7a6d6u | 1u));
                    w0 ^= (unsigned long long)(0x6bfbaa86u / (g0 | 1u)) << ((unsigned)l0 & 63u);
                } else {
                    u2 += (g1 ^ 0x9a3e365bu);
                    if (u3 == 7u) return u1;
                }
            }
            c1 = (signed char)((unsigned)e0 % ((unsigned)((short)p0 > (signed char)g0) | 1u));
            h0 = (short)(unsigned)((0x1f6ea4aeu % (u2 | 1u)) < (unsigned)((unsigned)x0 && (unsigned)l0));
            if (((0x80000000u & *mp) - i2)) {
                d0 = d0 * 0.5 + (double)(m0 & 1023u);
            }
        } while (i1++ < 7u && (unsigned)((short)u2 > (signed char)0xffffffffu));
    }
    if ((i0 / ((unsigned)((int)p1 < (int)(unsigned)h1) | 1u))) goto L2;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)h1 ? (unsigned)(x0 >> 70) : 0xffffffffu), (unsigned)((int)~(unsigned)((int)garr[u2 & 7u] >= (int)i2) >= (int)r0.x), (unsigned)(signed char)(g1 ^ 3u)); }
        u3 += (p1 | (unsigned)((short)((unsigned)h0 * i1) > (signed char)(unsigned)e0));
    } while (i0++ < 3u && (unsigned)h1);
    goto L1;
    if (0xa285ef8fu) goto L1;
    if ((u2 % (0xffffffffu | 1u))) {
        if ((unsigned)f0) goto L3;
        L2: if (--fuel == 0u) goto done;
        i1 = ((unsigned)((short)i0 > (signed char)8u) & (unsigned)((unsigned)x0 && (1u - 0xffffffffu))) & 15u;
    }
    e0 = e0 * 0.5L + (long double)((unsigned)(((a0[i0 & 3u] ? p2 : (unsigned)s0) % ((unsigned)h1 | 1u)) == 8u) & 1023u);
    c1 = (signed char)(unsigned)f0;
    *mp = (garr[u2 & 7u] >> (0x80000000u & 31u));
    g1 += (unsigned)((int)(unsigned)l0 < (int)(unsigned)s0);
    if ((0x7fffffffu * 0x10000u)) {
        *mp = (p0 - (unsigned)s0);
    } else {
        c1 = (signed char)((unsigned)w0 * (unsigned)(6u || (unsigned)w0));
        goto L0;
    }
    if ((unsigned)(g1 < r0.y)) goto L2;
    r0.x = (unsigned)((int)(9u >> (((u2 % (u2 | 1u)) / (6u | 1u)) & 31u)) >= (int)(unsigned)f0);
    while ((unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            v0 = r0.x;
        }
    }
    r0.x = (unsigned)(short)(unsigned)((short)(g0 << ((unsigned)w0 & 31u)) > (signed char)(r0.y * (unsigned)l0));
    if ((unsigned)(0x50e7ebc3u || 8u)) {
        b0 = (unsigned)c0 != 0u;
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((((unsigned)s1 + 0x80000000u) / (0x80000000u | 1u)), (5u * (unsigned)((short)6u > (signed char)(unsigned)c1)), ((unsigned)c1 / ((unsigned)l0 | 1u))); }
            garr[u3 & 7u] = (u3 % ((((unsigned)h1 >> (v0 & 31u)) * i0) | 1u));
            do { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((r0.x * p1) & 255u);
                s1 = (int)((unsigned)s1 + ((unsigned)((int)0xa13ee5d7u < (int)(unsigned)((int)0x10000u >= (int)(unsigned)s1)) << ((unsigned)b0 & 31u)));
            } while (i1++ < 7u && 3u);
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)h1), (((unsigned)x0 & (unsigned)s0) | p0), (unsigned)(signed char)(unsigned)(9u || (unsigned)(0u || u2))); }
            }
        }
    }
    v0 = r0.y;
    goto L2;
    if ((unsigned)((int)a0[i0 & 3u] < (int)0x7fffffffu)) {
        while (i0++ < 3u && u2) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(i1 == 2u), ((unsigned)e0 + 0xef49adb6u), (unsigned)((0xac49c947u / (0x80000000u | 1u)) == 5u)); }
            c0 = (unsigned char)(unsigned)b0;
            h1 = (unsigned short)(h1 + (unsigned)(((unsigned)e0 >> (0x487f6689u & 31u)) == (unsigned)(unsigned char)(unsigned)((short)0xcd2689e3u > (signed char)0x5684cdfu)));
            i0 = (unsigned)((int)0x953801ceu < (int)(2u | (unsigned)(i2 < (unsigned)f0))) & 15u;
        }
        if ((unsigned)(w0 >> 29)) {
            a0[i1 & 3u] = (unsigned)(short)(5u - (unsigned)((unsigned)((short)0x107c67du > (signed char)r0.y) && garr[i1 & 7u]));
            for (;;) { if (--fuel == 0u) goto done;
                u3 += ((unsigned)(4u || (unsigned)(unsigned char)(unsigned)((short)*q0 > (signed char)i0)) % (0x7fffffffu | 1u));
                g1 += (a0[i0 & 3u] << (((r0.x >> ((unsigned)c1 & 31u)) >> ((unsigned)c0 & 31u)) & 31u));
                if (9u) break;
                if (i1) {
                    g0 = (r0.y ? 0x25e43261u : fuel);
                    goto L3;
                } else {
                    if (((unsigned)h0 / (p1 | 1u))) {
                        if ((0x10000u - (4u ^ i1))) break;
                        u0 += ((((unsigned)c1 / (p1 | 1u)) & (unsigned)f0) ? (unsigned)s0 : p0);
                    }
                    if ((unsigned)((int)i0 < (int)(unsigned)e0)) break;
                    i0 = (g1 & ((unsigned)(r0.x < (unsigned)s0) & (unsigned)((unsigned)c0 == 7u))) & 15u;
                    if ((unsigned)h1) break;
                }
                u3 ^= (a0[u1 & 3u] | (r0.x | 4u));
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(0xa31d4a5du && i1), p1, (~(a0[i0 & 3u] % (g1 | 1u)) | u0)); }
            }
        }
        c1 = (signed char)(7u ^ (0u ? 0x7fffffffu : (unsigned)(u2 == m0)));
        h0 = (short)(unsigned)((unsigned)d0 == (u0 / ((unsigned)(x0 >> 70) | 1u)));
        if ((0x26997850u ? 0xffffffffu : (unsigned)(x0 >> 70))) {
            L3: if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
        }
    } else {
        a0[(unsigned)c0 & 3u] = (unsigned)((int)(unsigned)h1 < (int)fuel);
        goto L4;
        if (budget != 0u) { budget -= 1u; u2 = fn0(-(4u / (p2 | 1u)), (i1 - (unsigned)((int)0xffffffffu >= (int)garr[u2 & 7u])), ((unsigned)b0 + 3u)); }
    }
    u3 = (unsigned)(0x80000000u || 4u);
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(unsigned)((v0 / ((0x3af36cbcu >> (((unsigned)b0 & (unsigned)s1) & 31u)) | 1u)) && i2);
        switch ((unsigned)(short)(unsigned)((int)r0.x >= (int)(unsigned)(5u == 0x2917c0aeu)) & 7u) {
            { unsigned t0; double z0; if (((0u >> (g1 & 31u))) & 1u) { t0 = (unsigned)x0; z0 = (double)((~((unsigned)(fuel < *mp) + 0x80000000u)) & 255u); } if (((0u >> (g1 & 31u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                h1 = (unsigned short)(h1 + (unsigned)(i0 == 0x1e9f5e3fu));
                if (p0) {
                    m0 ^= (unsigned)((int)a0[u1 & 3u] < (int)(garr[i1 & 7u] ? (i2 << ((unsigned)h1 & 31u)) : (unsigned)f0));
                    g0 = (unsigned)((int)((unsigned)x0 + (unsigned)((g1 | (unsigned)s1) < 0x1cba6f4bu)) < (int)(unsigned)h1);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(-(0xe50027f8u + (a0[u1 & 3u] * r0.x)), u1, ((unsigned)d0 ? g1 : a0[i0 & 3u])); }
                } else {
                    i0 = (g0 + (unsigned)l0) & 15u;
                    for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        g0 = (((unsigned)(i0 < *mp) + a0[u1 & 3u]) * (unsigned)w0);
                        do { if (--fuel == 0u) goto done;
                            if (0xe6ca59du) goto L3;
                        } while (i2++ < 7u && (p0 - 0x10000u));
                        case 5u: ;
                        if ((unsigned)((short)(unsigned)!(1u + 3u) > (signed char)*q0)) break;
                    }
                }
                if ((0x60f871feu ^ 0x7fffffffu)) break;
                garr[(2u ^ 0xffffffffu) & 7u] = (unsigned)((int)-(m0 / (0x10000u | 1u)) >= (int)0x50248d61u);
            }
            g0 = 0xc5a89ef9u;
            if ((unsigned)(signed char)(unsigned)((unsigned)c0 && 0x7fffffffu)) goto L4;
        }
        if ((v0 ? p2 : (unsigned)w0)) continue;
    }
    if ((unsigned)((short)v0 > (signed char)(*mp / (u2 | 1u)))) goto L0;
    if ((unsigned)((unsigned)s1 == garr[u2 & 7u])) goto L1;
    for (;;) { if (--fuel == 0u) goto done;
        g1 += p2;
    }
    goto L2;
    if (((9u << (g0 & 31u)) | i2)) goto done;
    if ((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)s1)) goto L4;
    r0.x = u3;
    while (i0++ < 5u && (p0 - (6u << (fuel & 31u)))) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)((int)g1 < (int)(unsigned)(4u || (p1 * u0)));
        if (((garr[i1 & 7u] & (unsigned)d0) % ((unsigned)(w0 >> 29) | 1u))) break;
        u1 ^= (((unsigned)l0 % ((unsigned)h1 | 1u)) + g1);
        if (budget != 0u) { budget -= 1u; u0 = fn0(*q0, ~(unsigned)((int)v0 >= (int)garr[u2 & 7u]), a0[i0 & 3u]); }
    }
    if (p0) goto L4;
    *q0 += (unsigned)h1;
    *mp = -(unsigned)((short)(i2 ^ (unsigned)(x0 >> 70)) > (signed char)u1);
    if (((6u & (unsigned)d0) + 5u)) goto L2;
    s1 = (int)((unsigned)s1 + 0x10000u);
    i0 = (((unsigned)d0 + v0) | (unsigned)((int)g0 < (int)p0)) & 15u;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (unsigned)((int)0x10000u >= (int)a0[u1 & 3u]);
        e0 = e0 * 0.5L + (long double)(1u & 1023u);
        garr[p0 & 7u] = p2;
        if ((unsigned)((int)~((unsigned)d0 >> ((unsigned)b0 & 31u)) >= (int)*mp)) break;
    }
    q0 = &garr[(v0 & 7u) & 7u];
    if (p2) goto done;
    { unsigned t1; double z1; if (((unsigned)c1) & 1u) { t1 = ((unsigned)w0 - (unsigned)((int)r0.y < (int)0u)); z1 = (double)((5u) & 255u); } if (((unsigned)c1) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        if (m0) goto L0;
        *q0 = (unsigned)(u1 == (0xfe35604du % (0xddd6a9eeu | 1u)));
        if (budget != 0u) { budget -= 1u; u3 = fn0(((3u << (0x8df780b4u & 31u)) >> ((unsigned)d0 & 31u)), (9u | (unsigned)(u3 && (unsigned)(w0 >> 29))), a0[u1 & 3u]); }
        r0.y ^= p1;
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(signed char)(u0 ^ (unsigned)h0) < (unsigned)c0), (unsigned)((int)(unsigned)h0 < (int)(unsigned)s1), r0.x); }
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        while ((unsigned)(short)(8u ^ (unsigned)(short)(unsigned)((short)9u > (signed char)m0))) { if (--fuel == 0u) goto done;
            if ((unsigned)f0) break;
            break; (void)((unsigned)(signed char)(0xf8d90458u & garr[i1 & 7u]));
            garr[(unsigned)((unsigned)s1 < p0) & 7u] = (v0 % ((0x19f0ae9fu >> (i2 & 31u)) | 1u));
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)s1;
        if ((0u & u1)) {
            if (0x10000u) {
                *mp = -(i2 & u2);
            } else {
                g0 = ((unsigned)(unsigned char)(i0 >> (0x5cc2f058u & 31u)) % (((unsigned)b0 & (a0[u1 & 3u] << (p1 & 31u))) | 1u));
                if ((unsigned)x0) break;
                if (garr[u2 & 7u]) {
                    u2 = u2 * 0x9e3779b1u + (unsigned)((int)((unsigned)f0 + 2u) < (int)a0[i0 & 3u]);
                    switch ((0x624278cfu >> ((unsigned)s1 & 31u)) & 7u) {
                        { unsigned t2; double z2; if ((i2) & 1u) { t2 = (-(0x7fffffffu / ((unsigned)x0 | 1u)) - i1); z2 = (double)(((unsigned)((int)a0[i0 & 3u] < (int)u1)) & 255u); } if ((i2) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                            h0 = (short)~(i0 << ((unsigned)(w0 >> 29) & 31u));
                            c0 = (unsigned char)(unsigned)(0x5b6a8d07u || (0xc8c1ffe9u >> (0xdad7c29cu & 31u)));
                            case 6u: ;
                            l0 = (long)((unsigned long)l0 + (((unsigned)((unsigned)l0 && fuel) + (unsigned)e0) ^ (unsigned)(5u || (unsigned)(x0 >> 70))));
                            if (u3 == 7u) return (0x10000u >> (0x49a74f1au & 31u));
                            case 3u: ;
                        }
                    }
                    do { if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(u3 | (unsigned)((int)*q0 < (int)i1));
                        goto done;
                        continue; (void)(u2);
                    } while (i1++ < 7u && 3u);
                }
            }
            if ((unsigned)((short)(unsigned)x0 > (signed char)a0[i0 & 3u])) continue;
            b0 = ((unsigned)b0 & i1) != 0u;
        }
    }
    d0 = d0 * 0.5 + (double)((i0 % (((unsigned)c0 % (0xffffffffu | 1u)) | 1u)) & 1023u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    w0 = w0 * 6364136223846793005ull + (0xf7cf513eu / (0x10000u | 1u));
    { unsigned t0; double z0; if ((garr[i1 & 7u]) & 1u) { t0 = (p2 << (0xffffffffu & 31u)); z0 = (double)(((unsigned)!(unsigned)((unsigned)c1 < 0x7fffffffu)) & 255u); } if ((garr[i1 & 7u]) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if ((((unsigned)s1 >> (0x1b6ab313u & 31u)) - u3)) {
            goto L0;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)d0, g0, 0xffffffffu); }
            if ((unsigned)((short)4u > (signed char)(unsigned)x0)) {
                i0 = ((0xbf2310fau >> (i0 & 31u)) - garr[u2 & 7u]) & 15u;
                v0 = (unsigned)((int)0x80000000u < (int)(0xffffffffu << (0x80000000u & 31u)));
                if (((unsigned)((short)(unsigned)b0 > (signed char)0xac904b28u) >> (0x7fffffffu & 31u))) goto L4;
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((short)garr[u2 & 7u] > (signed char)0x80000000u) * (unsigned)(w0 >> 29)), g1, (unsigned)((short)*q0 > (signed char)0x7fffffffu)); }
                a0[(unsigned)((unsigned)e0 && (unsigned)h0) & 3u] = (unsigned)(signed char)(unsigned)((unsigned)(u3 == 0xb1ab5394u) && ((unsigned)s1 * fuel));
                if ((garr[i1 & 7u] * 0x7fffffffu)) {
                    if (((unsigned)d0 * (unsigned)((unsigned)s1 == p0))) goto L4;
                    i0 = (unsigned)(4u == i1) & 15u;
                    r0.x = (m0 % ((unsigned)l0 | 1u));
                    if ((r0.x | (0x80000000u & 0u))) goto L2;
                    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)h1 & p1), (unsigned)h1, (unsigned)!(unsigned)((short)0xffffffffu > (signed char)(unsigned)(0xffffffffu < (unsigned)s1))); }
                } else {
                    if ((unsigned)!(unsigned)((short)4u > (signed char)0x10000u)) {
                        L0: if (--fuel == 0u) goto done;
                        *q0 = -(unsigned)(0x80000000u && (unsigned)f0);
                        c1 = (signed char)(unsigned)((int)(p0 - (u3 | (unsigned)(x0 >> 70))) < (int)(unsigned)(unsigned char)(unsigned)((short)a0[u1 & 3u] > (signed char)p0));
                    }
                    h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)c1 >= (int)(unsigned)e0));
                }
            } else {
                goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn1((((unsigned)(x0 >> 70) * (unsigned)c0) / (0xffffffffu | 1u)), -(r0.x + (unsigned)((short)*q0 > (signed char)a0[i0 & 3u])), (unsigned)s0); }
                if (budget != 0u) { budget -= 1u; u1 = fn0((u2 & *q0), (unsigned)(0xc9c56856u || u1), (a0[i0 & 3u] - garr[u2 & 7u])); }
                g1 += (unsigned)((int)(unsigned)((int)v0 < (int)(unsigned)((int)m0 >= (int)8u)) >= (int)(a0[i0 & 3u] << (*mp & 31u)));
            }
            i0 = (unsigned)(0x80000000u < fuel) & 15u;
            q0 = &garr[(unsigned)(u0 < u1) & 7u];
        }
        if (u3 == 7u) return 8u;
        if (budget != 0u) { budget -= 1u; u3 = fn0(3u, 0x10000u, (u3 + g0)); }
        g1 += (u1 << (0xffffffffu & 31u));
        goto L1;
        while (g1) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + (unsigned)(2u == p0));
        }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((0x7fffffffu << ((unsigned)s0 & 31u)), g0, (unsigned)((unsigned)(w0 >> 29) == p1)); }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(x0 >> 70) * (unsigned)c0), (unsigned)c0, (unsigned)((int)u0 >= (int)0x7fffffffu)); }
        if (((unsigned)((int)g1 < (int)(unsigned)(x0 >> 70)) & garr[i1 & 7u])) goto L0;
    } while (i0++ < 2u && (unsigned)((short)0x10000u > (signed char)((unsigned)l0 >> (p2 & 31u))));
    garr[(unsigned)((int)5u >= (int)0xffffffffu) & 7u] = (0xd81c111bu / ((unsigned)(unsigned char)(0xffffffffu ? 5u : 1u) | 1u));
    h1 = (unsigned short)(h1 + ((unsigned)w0 ^ (unsigned)((short)0x1ebe9ff1u > (signed char)(unsigned)(x0 >> 70))));
    L1: if (--fuel == 0u) goto done;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)s1 - 0xc0df2647u), ((unsigned)f0 - (unsigned)c0), ((unsigned)s1 - ((unsigned)b0 + g1))); }
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (0xffffffffu) break;
                u1 = g0;
                { unsigned t1; double z1; if (((unsigned)((unsigned)e0 || m0)) & 1u) { t1 = (unsigned)(unsigned char)(unsigned)((short)(unsigned)((int)u2 < (int)0x39826dc2u) > (signed char)0x17c84afcu); z1 = (double)(((unsigned)(short)(0xffffffffu - g1)) & 255u); } if (((unsigned)((unsigned)e0 || m0)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    e0 = e0 * 0.5L + (long double)(-(0xb4d4b714u & 0x10000u) & 1023u);
                    u3 += (a0[u1 & 3u] - ((unsigned)((int)6u < (int)0u) | (unsigned)((short)u1 > (signed char)a0[u1 & 3u])));
                    s1 = (int)((unsigned)s1 + ((unsigned)((unsigned)x0 && (u2 << (0x476fd948u & 31u))) - -(0x92fb033du / ((unsigned)(x0 >> 70) | 1u))));
                    if ((unsigned)(signed char)(unsigned)((short)u3 > (signed char)a0[i0 & 3u])) break;
                    u0 += (unsigned)x0;
                }
                r0.y ^= ~((u1 + p2) % ((0x10000u >> (0xffffffffu & 31u)) | 1u));
            }
        } while (i1++ < 4u && (a0[i0 & 3u] * ((unsigned)h1 ^ (unsigned)f0)));
        do { if (--fuel == 0u) goto done;
            break; (void)((unsigned)!(0xb76dbc1cu * i0));
            if (1u) break;
            c0 = (unsigned char)((unsigned)((short)(unsigned)s1 > (signed char)r0.y) * (r0.x - 5u));
            if (budget != 0u) { budget -= 1u; u2 = fn1(a0[u1 & 3u], (0xffcc76f1u << (p1 & 31u)), p1); }
            i0 = (((unsigned)w0 / ((unsigned)(w0 >> 29) | 1u)) / (((unsigned)h1 | (0x10000u % (garr[u2 & 7u] | 1u))) | 1u)) & 15u;
        } while (i1++ < 6u && (unsigned)((short)0x80000000u > (signed char)u1));
        if ((unsigned)((int)a0[i0 & 3u] < (int)0x66783e5du)) {
            while (i1++ < 3u && (unsigned)!(5u ? 0u : (unsigned)f0)) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)0x10000u << ((1u & i1) & 63u);
                garr[(a0[i0 & 3u] >> (a0[u1 & 3u] & 31u)) & 7u] = (unsigned)((short)0xcf04e066u > (signed char)u1);
                d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)(i1 == 0xbc4a0776u) < (int)(unsigned)(0x80000000u < (v0 ^ (unsigned)(w0 >> 29)))) & 1023u);
            }
            w0 ^= (unsigned long long)g1 << (((u0 % (m0 | 1u)) ^ ((unsigned)l0 * 3u)) & 63u);
            switch ((unsigned)e0 & 7u) {
                do { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + ((0x6b4d7491u + (unsigned)!((unsigned)h1 ? 0x7fffffffu : (unsigned)h0)) & 0xffffffffu));
                    r0.x = (unsigned)(i2 == (0x5f059352u - 0x7fffffffu));
                    u0 += (unsigned)(x0 >> 70);
                    c0 = (unsigned char)(unsigned)l0;
                    g0 = (0xdcd69ebdu << (0x7c8a2cb2u & 31u));
                    f0 = f0 * 0.5f + (float)(p1 & 255u);
                } while (i1++ < 2u && (g1 << ((unsigned)((int)(unsigned)f0 < (int)(unsigned)c0) & 31u)));
                while (i1++ < 5u && (unsigned)(u1 && p0)) { if (--fuel == 0u) goto done;
                    if (~(unsigned)((short)4u > (signed char)u2)) goto L2;
                    switch ((r0.x & i0) & 7u) {
                        c1 = (signed char)(garr[i1 & 7u] + 0x61fe4101u);
                        u2 ^= (unsigned)(p2 < 0x10000u);
                        *mp = ((unsigned)c1 >> ((0x7fffffffu ? 3u : (u2 << ((unsigned)h1 & 31u))) & 31u));
                    }
                    goto L2;
                }
                if ((unsigned)((int)(unsigned)f0 < (int)(unsigned)((int)(unsigned)s1 < (int)0xffffffffu))) continue;
            }
            if (7u) continue;
            if ((garr[u2 & 7u] ? 0x7fffffffu : 8u)) continue;
        }
        if ((unsigned)(short)(unsigned)((short)(i0 - (unsigned)s1) > (signed char)4u)) continue;
        while (i1++ < 2u && p1) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(((unsigned)((short)(garr[i1 & 7u] / ((unsigned)c1 | 1u)) > (signed char)p0) & (unsigned)(0x7fffffffu < fuel)) & 1023u);
            u1 = u1 * 0x9e3779b1u + ((unsigned)x0 % ((unsigned)(short)(unsigned)((int)*mp < (int)garr[i1 & 7u]) | 1u));
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                b0 = garr[u2 & 7u] != 0u;
                c1 = (signed char)0xd108fadeu;
            }
            a0[(m0 + (unsigned)b0) & 3u] = (((unsigned)(w0 >> 29) ^ (unsigned)c0) / ((unsigned)d0 | 1u));
        }
    }
    goto L2;
    v0 = (i2 - ((unsigned)(unsigned char)(a0[i0 & 3u] % (p0 | 1u)) & (unsigned)((short)*mp > (signed char)p1)));
    if ((unsigned)(short)(unsigned)(0xa0ae3ddcu || v0)) goto L1;
    if ((unsigned)(4u || i2)) goto L3;
    do { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((garr[i1 & 7u] % (p1 | 1u)) & 1023u);
        L2: if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + m0;
        break; (void)((unsigned)(u2 && 0x80000000u));
        g0 = (unsigned)((unsigned)(garr[i1 & 7u] && 5u) && ((unsigned)((int)2u >= (int)i0) * 0xb57b645du));
    } while (i0++ < 5u && (unsigned)x0);
    goto L1;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (-((unsigned)f0 * (unsigned)w0)) break;
        L3: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0((0xffffffffu & (0x28564baeu * (unsigned)b0)), (0x80000000u ^ i2), (m0 ? (unsigned)c1 : g1)); }
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(-(unsigned)((int)a0[u1 & 3u] >= (int)garr[u2 & 7u]));
        }
    }
    *q0 = (unsigned)((g1 * 5u) && (unsigned)((int)(unsigned)w0 >= (int)*q0));
    goto L0;
    { unsigned t2; double z2; if (((*mp / ((unsigned)(garr[u2 & 7u] && 8u) | 1u))) & 1u) { t2 = (unsigned)(0x80000000u == 0x54d36af0u); z2 = (double)(((garr[u2 & 7u] * (unsigned)h1)) & 255u); } if (((*mp / ((unsigned)(garr[u2 & 7u] && 8u) | 1u))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        do { if (--fuel == 0u) goto done;
            if (u3 == 7u) return (garr[i1 & 7u] & (unsigned)!(unsigned)((int)u1 < (int)((unsigned)h0 * 0u)));
            b0 = ((p0 * g0) << ((unsigned)(i0 < (unsigned)d0) & 31u)) != 0u;
            *mp = ~(unsigned)((unsigned)((short)(unsigned)((int)(unsigned)c0 >= (int)u1) > (signed char)(unsigned)s1) || p2);
            goto done;
            L4: if (--fuel == 0u) goto done;
            if ((g1 & (unsigned)(0x519f5d7au < (unsigned)x0))) break;
        } while (i0++ < 7u && (unsigned)b0);
        if ((unsigned)(unsigned char)(unsigned)((unsigned)w0 < p1)) goto L2;
        q0 = &garr[u1 & 7u];
        if (budget != 0u) { budget -= 1u; u2 = fn0(garr[i1 & 7u], (*mp << (((unsigned)x0 >> (0x34b68de9u & 31u)) & 31u)), (m0 / (3u | 1u))); }
        d0 = d0 * 0.5 + (double)(-((unsigned)!(unsigned)((short)0x7fffffffu > (signed char)0x96f7f068u) / ((garr[i1 & 7u] % ((unsigned)(6u && 0xffffffffu) | 1u)) | 1u)) & 1023u);
        q0 = &garr[(unsigned)((int)0xffffffffu < (int)(unsigned)(*mp && *q0)) & 7u];
    }
    goto L4;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)s0, (unsigned)(w0 >> 29), (unsigned)l0); }
        *mp = 9u;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(garr[u2 & 7u] || (0x42959415u >> (1u & 31u))), 0x80000000u, (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(g1 >> ((unsigned)d0 & 31u)))); }
        if (g1) break;
    }
    { unsigned t3; double z3; if ((6u) & 1u) { t3 = (a0[u1 & 3u] & (unsigned)f0); z3 = (double)((0x10fa0fd5u) & 255u); } if ((6u) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        if ((unsigned)((unsigned)l0 == m0)) goto L3;
        do { if (--fuel == 0u) goto done;
            g0 = 8u;
            if (fuel < 8u) return (garr[i1 & 7u] * (unsigned)((int)(unsigned)w0 < (int)g1));
            u2 = (unsigned)((int)*q0 < (int)((unsigned)(a0[u1 & 3u] || i1) << (*mp & 31u)));
            if (((unsigned)((int)(unsigned)(w0 >> 29) >= (int)*mp) & (unsigned)c0)) break;
        } while (i0++ < 7u && u3);
        if ((unsigned)c0) goto done;
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)((5u >> (p2 & 31u)) | (unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)f0 || p1) || p2));
            u3 += ((0x77e60f5fu >> ((0xda79b02eu * (p0 % ((unsigned)c1 | 1u))) & 31u)) - 1u);
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)(short)(0x7fffffffu + fuel) << ((i0 >> (0xffffffffu & 31u)) & 63u);
                continue; (void)((unsigned)((int)(unsigned)(0x7fffffffu || *q0) < (int)(unsigned)x0));
                if ((g0 ^ (unsigned)((unsigned)(x0 >> 70) < r0.y))) {
                    if (fuel < 8u) return (unsigned)(unsigned char)(unsigned)(*mp < u0);
                    v0 = (unsigned)b0;
                    break; (void)((unsigned)w0);
                    if (budget != 0u) { budget -= 1u; u2 = fn0(u3, ((unsigned)x0 & (unsigned)h0), g0); }
                } else {
                    while (i2++ < 4u && (unsigned)(signed char)(unsigned)((unsigned)s1 || (unsigned)s0)) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((r0.x << ((unsigned)c0 & 31u)) == g1));
                        *mp = p1;
                        r0.x = ((unsigned)(signed char)(*mp + 5u) / (~(i1 ^ 0x10000u) | 1u));
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)9u > (signed char)a0[u1 & 3u]), p1, ((0x10000u / ((unsigned)s0 | 1u)) << (i2 & 31u))); }
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)f0, (0x7fffffffu << ((unsigned)(unsigned char)(unsigned)(0xffffffffu || (unsigned)f0) & 31u)), ((unsigned)(signed char)(0xd0090cau + p0) + garr[u2 & 7u])); }
                        *mp = (unsigned)((5u & ((unsigned)b0 - p0)) || garr[u2 & 7u]);
                    }
                }
                g1 += (unsigned)((int)(unsigned)(r0.x < 0xa3784fdeu) < (int)(unsigned)!(u2 ? v0 : 0x302d73a7u));
                g1 += (unsigned)((unsigned)(p0 < 0x411df112u) || *q0);
                i2 = (unsigned)((int)((unsigned)(x0 >> 70) >> ((unsigned)s0 & 31u)) >= (int)m0) & 15u;
            }
            a0[((unsigned)h1 / (0x10000u | 1u)) & 3u] = ((unsigned)!(0x80000000u ^ g0) % ((*q0 - (unsigned)l0) | 1u));
            if ((fuel / ((unsigned)((int)garr[u2 & 7u] < (int)a0[u1 & 3u]) | 1u))) break;
            if (0x6932a3a4u) {
                if ((unsigned)((short)(unsigned)l0 > (signed char)u0)) break;
                if (u0) break;
                while (i1++ < 6u && (p1 >> ((unsigned)((unsigned)s1 == (unsigned)(x0 >> 70)) & 31u))) { if (--fuel == 0u) goto done;
                    { unsigned t4; double z4; if ((7u) & 1u) { t4 = u3; z4 = (double)(((v0 - *mp)) & 255u); } if ((7u) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                        *mp = (garr[u2 & 7u] & -(unsigned)((short)u3 > (signed char)fuel));
                        do { if (--fuel == 0u) goto done;
                            if (u3 == 7u) return (unsigned)f0;
                            b0 = ((6u & (unsigned)c1) / ((unsigned)((short)(garr[u2 & 7u] & u0) > (signed char)(unsigned)f0) | 1u)) != 0u;
                        } while (i2++ < 4u && ((unsigned)c0 << (((unsigned)(w0 >> 29) << (0xb06b6497u & 31u)) & 31u)));
                        h1 = (unsigned short)(h1 + (unsigned)(4u && a0[i0 & 3u]));
                        if ((u1 / (0xccb862f1u | 1u))) break;
                        f0 = f0 * 0.5f + (float)(((*mp << ((unsigned)(unsigned char)(unsigned)((unsigned)c1 || (unsigned)((int)(unsigned)x0 < (int)u0)) & 31u)) * g1) & 255u);
                        *q0 += ((unsigned)((short)r0.x > (signed char)garr[i1 & 7u]) * (unsigned)((unsigned)c0 || i1));
                    }
                    if (((unsigned)h1 ^ (unsigned)(u3 || 0x80000000u))) {
                        if (budget != 0u) { budget -= 1u; u1 = fn1((u2 ? (unsigned)(x0 >> 70) : *q0), (unsigned)((int)m0 >= (int)v0), ((unsigned)(w0 >> 29) ? 0xd6c4516cu : (unsigned)(x0 >> 70))); }
                        if (budget != 0u) { budget -= 1u; u1 = fn1((0xa117a994u * (unsigned)f0), (fuel % (garr[i1 & 7u] | 1u)), -((unsigned)c0 / (g0 | 1u))); }
                    } else {
                        if (i1) break;
                        r0.x = (unsigned)((int)((p1 + v0) % ((unsigned)e0 | 1u)) >= (int)(0x10000u / (0x80000000u | 1u)));
                    }
                    if (0xcaeae1ccu) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(garr[i1 & 7u] && 0x1513c6a9u), 0x80000000u, (unsigned)(unsigned char)((unsigned)h0 % ((0u >> (4u & 31u)) | 1u))); }
                }
                if ((u0 | (unsigned)l0)) break;
                b0 = 4u != 0u;
                if ((((unsigned)e0 / ((unsigned)f0 | 1u)) | p0)) goto L4;
            } else {
                l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(x0 >> 70) < 0xe96d6942u));
            }
        }
        switch ((unsigned)((short)a0[u1 & 3u] > (signed char)((unsigned)c0 >> (2u & 31u))) & 7u) {
            c0 = (unsigned char)(unsigned)((short)*mp > (signed char)(unsigned)(w0 >> 29));
            *q0 += (unsigned)h0;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(g1 == fuel), (0xa5cb15aeu / ((unsigned)l0 | 1u)), 2u); }
            if (((unsigned)e0 + ((unsigned)s0 - 0xce998e73u))) goto L2;
            switch (i0 & 7u) {
                l0 = (long)((unsigned long)l0 + (unsigned)((short)i0 > (signed char)(unsigned)(signed char)((a0[u1 & 3u] % (fuel | 1u)) | (0u + (unsigned)c0))));
                f0 = f0 * 0.5f + (float)(0u & 255u);
                break; (void)(0x9e459efdu);
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)((int)g1 < (int)0x9c7a7f02u) || u1), (9u / ((unsigned)l0 | 1u)), p0); }
                case 1u: ;
            }
        }
        f0 = f0 * 0.5f + (float)((u0 % (i2 | 1u)) & 255u);
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((i2 * ((unsigned)b0 & g0)), -(unsigned)((int)u2 < (int)(unsigned)(0x80000000u == (unsigned)s1)), (unsigned)e0); }
    i2 = (unsigned)h0 & 15u;
    do { if (--fuel == 0u) goto done;
        s0 = (int)p2;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)(1u == (unsigned)w0) < 9u), -(r0.y | g1), (unsigned)(signed char)((unsigned)(i2 < (unsigned)e0) ^ (unsigned)l0)); }
        if ((unsigned)e0) {
            v0 = (unsigned)!(unsigned)((unsigned)(x0 >> 70) == (u2 | i0));
            u3 ^= (unsigned)((short)(m0 ? (unsigned)(w0 >> 29) : (unsigned)!(unsigned)((int)0x10000u >= (int)v0)) > (signed char)(unsigned)f0);
            u0 += ((i1 | 0x7fffffffu) >> ((unsigned)d0 & 31u));
            if ((p0 << ((i0 & m0) & 31u))) break;
            do { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)(unsigned char)(u1 - (unsigned)(0x80000000u == (unsigned)((int)(unsigned)h1 >= (int)r0.x)));
                if (((i2 % (5u | 1u)) >> ((unsigned)x0 & 31u))) continue;
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)x0 == 0x442608b3u)) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0xb1ce42e1u < 0xffffffffu), (unsigned)(u0 < 5u), (unsigned)!(*q0 + 5u)); }
                    if ((g1 & 0x10000u)) continue;
                    *q0 = ~((0xcb38f543u & 0x80000000u) + p2);
                    s0 = (int)((((unsigned)(w0 >> 29) ^ g1) ^ (a0[u1 & 3u] / ((unsigned)f0 | 1u))) / ((unsigned)e0 | 1u));
                    v0 = (unsigned)(signed char)(unsigned)((int)((unsigned)(w0 >> 29) - (0xd52288f4u / (v0 | 1u))) < (int)(unsigned)((unsigned)d0 && (unsigned)x0));
                } while (i2++ < 2u && (unsigned)(u1 || 0x7fffffffu));
            } while (i1++ < 2u && u3);
        }
        goto L0;
        x0 = x0 * 0x100000001b3ull + (unsigned)((int)0x548bb98u >= (int)((unsigned)h1 ? ((unsigned)b0 >> (5u & 31u)) : a0[i0 & 3u]));
        u0 = (u3 & (9u | (unsigned)w0));
    } while (i0++ < 7u && (p1 * 0x23ba339u));
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(short)((unsigned)((int)p0 >= (int)v0) << (garr[u2 & 7u] & 31u)), (unsigned)(0x9e293950u < u0), 0x7fffffffu); }
    } while (i0++ < 5u && (fuel | (0x50dc4e9u + 0x54826565u)));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)f0));
        if ((unsigned)(1u < (unsigned)c1)) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(unsigned)((short)(unsigned)b0 > (signed char)((unsigned)s0 >> (u3 & 31u))), (0xffffffffu / ((unsigned)(x0 >> 70) | 1u)), (0x76ab1860u & a0[i0 & 3u])); }
        } else {
            h0 = (short)(((p1 / ((unsigned)c0 | 1u)) ^ r0.x) | (unsigned)e0);
            garr[(unsigned)((short)(unsigned)s0 > (signed char)(unsigned)d0) & 7u] = (u3 >> (((u0 & 0xa7babf0du) >> (4u & 31u)) & 31u));
            if ((unsigned)((unsigned)x0 || (unsigned)((short)(unsigned)b0 > (signed char)0xd7015f43u))) {
                x0 = x0 * 0x100000001b3ull + *mp;
                if ((unsigned)((int)(u2 ^ r0.x) >= (int)(unsigned)e0)) break;
                *q0 = (unsigned)(signed char)(((unsigned)l0 + (unsigned)d0) | (u0 << (0x8656620u & 31u)));
                r0.x = (u1 >> (u1 & 31u));
                s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((int)(g0 | garr[i1 & 7u]) < (int)(unsigned)b0) == (unsigned)((int)(unsigned)x0 >= (int)garr[u2 & 7u])));
            }
            if (0xac68ef9bu) goto L4;
        }
    }
    if ((0x474955e3u / ((unsigned)s0 | 1u))) {
        goto L4;
        m0 ^= ((0xf7ecab5cu * garr[u2 & 7u]) % ((unsigned)(x0 >> 70) | 1u));
        m0 ^= m0;
        { unsigned t5; double z5; if ((((p2 - 8u) - 3u)) & 1u) { t5 = (6u % (0x48d9beu | 1u)); z5 = (double)(((unsigned)(unsigned char)((unsigned)(w0 >> 29) ? 0x7fffffffu : i2)) & 255u); } if ((((p2 - 8u) - 3u)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            h0 = (short)((unsigned)e0 - 0u);
        }
        c0 = (unsigned char)(((unsigned)h0 ? u3 : (unsigned)h1) ^ p1);
        *mp = (u0 >> ((((0x831cdfd1u >> ((unsigned)s0 & 31u)) | 0x7fffffffu) ^ (unsigned)d0) & 31u));
    } else {
        v0 = i0;
        { unsigned t6; double z6; if (((unsigned)(signed char)(u0 ? p2 : (unsigned)l0)) & 1u) { t6 = ((unsigned)((int)(unsigned)h0 >= (int)0x80000000u) * 0x4d0b48c0u); z6 = (double)((u1) & 255u); } if (((unsigned)(signed char)(u0 ? p2 : (unsigned)l0)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            e0 = e0 * 0.5L + (long double)((unsigned)(short)(unsigned)((unsigned)((int)(unsigned)l0 >= (int)*q0) && u1) & 1023u);
        }
        c1 = (signed char)fuel;
    }
    u2 = (unsigned)((unsigned)!((unsigned)e0 | (m0 | 0u)) || 0xffffffffu);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        garr[(unsigned)((unsigned)c0 < i2) & 7u] = (unsigned)!(((unsigned)s1 * -(0x7fffffffu & (unsigned)c0)) >> ((9u + u2) & 31u));
        if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)l0 % (r0.x | 1u)), (unsigned)(0x10000u && r0.x), 0x762a21b9u); }
    } while (i0++ < 7u && (m0 % ((unsigned)((int)p0 >= (int)p2) | 1u)));
    { unsigned t0; double z0; if (((unsigned)(0x2e02affu && (unsigned)w0)) & 1u) { t0 = ((unsigned)(x0 >> 70) + garr[i1 & 7u]); z0 = (double)(((0x80000000u | (unsigned)c1)) & 255u); } if (((unsigned)(0x2e02affu && (unsigned)w0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if (a0[u1 & 3u]) {
            u2 += m0;
            *mp = ((unsigned)!((unsigned)((int)r0.y < (int)*q0) << (0x7fffffffu & 31u)) % ((unsigned)w0 | 1u));
            i2 = *mp & 15u;
        }
        if (~((i2 - 0xda5b0f26u) ^ 4u)) goto L0;
        if (u0) goto L3;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((garr[i1 & 7u] >> (6u & 31u))) goto L1;
        }
    }
    do { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(unsigned)(0x5ff415fdu < (unsigned)d0);
        w0 ^= (unsigned long long)r0.x << ((a0[u1 & 3u] / (garr[u2 & 7u] | 1u)) & 63u);
        if ((unsigned)c0) {
            if ((unsigned)d0) {
                break; (void)((unsigned)((int)(fuel >> (*q0 & 31u)) >= (int)(unsigned)f0));
            }
        } else {
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)(0x4160a999u - (p2 / ((unsigned)x0 | 1u))), 0x6880db48u, g0); }
                if ((unsigned)(short)(0x73ceb477u >> (p2 & 31u))) continue;
                if (fuel < 8u) return (i1 ? 0xffffffffu : 8u);
            }
        }
    } while (i0++ < 2u && m0);
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((0x9fcc5a9bu - g1)) {
                L0: if (--fuel == 0u) goto done;
            } else {
                w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)((unsigned)(r0.y || p2) / ((unsigned)(u1 < 0xffffffffu) | 1u));
                m0 ^= ((-((unsigned)c1 | m0) | (unsigned)((int)p2 < (int)i1)) & 0u);
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)0x98d35eafu >= (int)0x39883744u), 0xe1299ce7u, ((unsigned)s0 >> ((unsigned)((int)(unsigned)h0 >= (int)0xc0e0a860u) & 31u))); }
            }
            u0 += (unsigned)h1;
            if ((unsigned)(short)(((unsigned)w0 & 8u) % ((unsigned)(x0 >> 70) | 1u))) break;
            if (fuel < 8u) return (0x10000u / ((unsigned)((int)(i0 & garr[u2 & 7u]) < (int)(0x8224c08cu ^ p0)) | 1u));
            if ((unsigned)x0) {
                { unsigned t1; double z1; if (((unsigned)(short)(0x64d4e75cu | (unsigned)x0)) & 1u) { t1 = (unsigned)(6u || (unsigned)((short)0x10000u > (signed char)(unsigned)x0)); z1 = (double)((~(i0 / (((unsigned)w0 | 9u) | 1u))) & 255u); } if (((unsigned)(short)(0x64d4e75cu | (unsigned)x0)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    w0 = w0 * 6364136223846793005ull + ((unsigned)!(0xcbe86ea3u & (*mp % (a0[u1 & 3u] | 1u))) ? u0 : *q0);
                    L1: if (--fuel == 0u) goto done;
                    h0 = (short)((*q0 * ((unsigned)(x0 >> 70) | u0)) | (unsigned)e0);
                    if ((r0.y * (a0[u1 & 3u] % (p0 | 1u)))) break;
                    *q0 += -(unsigned)((g0 * (unsigned)(unsigned char)((unsigned)b0 * 5u)) && (garr[i1 & 7u] + 0xd46f1060u));
                    if ((unsigned)((unsigned)s1 || 0x8308f51cu)) break;
                }
                u1 += ((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)h1) ? (unsigned)s1 : p1);
                switch (p1 & 7u) {
                    w0 = w0 * 6364136223846793005ull + (unsigned)(0xa49501e6u || ((unsigned)!(unsigned)((int)0xf9da5373u < (int)i2) - 8u));
                    l0 = (long)((unsigned long)l0 + 5u);
                    *mp = (((unsigned)w0 << ((r0.y & 4u) & 31u)) & (unsigned)s1);
                }
                L2: if (--fuel == 0u) goto done;
            }
            u3 = (unsigned)((unsigned)f0 < u2);
        }
        if ((unsigned)(w0 >> 29)) {
            while (i1++ < 7u && (unsigned)((unsigned)((unsigned)f0 || *mp) || 1u)) { if (--fuel == 0u) goto done;
                while ((unsigned)((int)(unsigned)h1 < (int)fuel)) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((unsigned)d0 & 1023u);
                    x0 = x0 * 0x100000001b3ull + 4u;
                    break; (void)(*q0);
                    if ((unsigned)((short)v0 > (signed char)u3)) continue;
                }
                r0.y ^= (unsigned)!(unsigned)((int)(unsigned)x0 < (int)0x10000u);
                c0 = (unsigned char)~((unsigned)(u2 < (unsigned)(signed char)(unsigned)(garr[u2 & 7u] || (unsigned)(x0 >> 70))) ^ (garr[u2 & 7u] & 0x83b16a2fu));
                g0 = (unsigned)((0xef3cb043u | r0.x) == (unsigned)f0);
            }
        }
    } while (i0++ < 5u && (unsigned)(signed char)(unsigned)((unsigned)(signed char)(garr[u2 & 7u] & (unsigned)b0) && (unsigned)x0));
    if ((unsigned)(0x80000000u < p2)) goto L3;
    { unsigned t2; double z2; if ((0xb0851563u) & 1u) { t2 = (0xb346a2ccu % ((0xffffffffu >> (g0 & 31u)) | 1u)); z2 = (double)(((unsigned)(*q0 || *mp)) & 255u); } if ((0xb0851563u) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        h0 = (short)(unsigned)!((unsigned)((short)0xfd50ae5bu > (signed char)(unsigned)(r0.y == 0x964ef5aau)) - u2);
        i1 = (v0 / (0xc3d2f0b4u | 1u)) & 15u;
        w0 ^= (unsigned long long)(unsigned)!((unsigned)c0 & i0) << ((unsigned)((short)(unsigned)((unsigned)((unsigned)d0 && u3) < garr[u2 & 7u]) > (signed char)(unsigned)(0x10000u || (unsigned)c0)) & 63u);
        if ((i1 ? p1 : r0.x)) {
            if ((unsigned)((0x19cec7aeu + 0xffffffffu) < i2)) {
                if ((unsigned)((unsigned)((int)v0 < (int)4u) && 0x7fffffffu)) goto L1;
                if ((p0 & (unsigned)((int)(unsigned)(x0 >> 70) < (int)0xffffffffu))) {
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)l0 ^ p0), (unsigned)(0xa4a3c1u == p1), (r0.y << (*q0 & 31u))); }
                    *mp = (i2 >> (((u0 << ((unsigned)h1 & 31u)) % (((unsigned)(w0 >> 29) - 0x3832100bu) | 1u)) & 31u));
                    { unsigned t3; double z3; if (((unsigned)(0xd7523e3fu || 2u)) & 1u) { t3 = *q0; z3 = (double)((0x50f9a8f5u) & 255u); } if (((unsigned)(0xd7523e3fu || 2u)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                        x0 = x0 * 0x100000001b3ull + 9u;
                        s0 = (int)(0x7fffffffu - (unsigned)(signed char)(unsigned)(garr[i1 & 7u] && *mp));
                        do { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)garr[i1 & 7u] >= (int)*q0), 0x80000000u, (0xe9f58a33u - 0xbf2adf9bu)); }
                            L3: if (--fuel == 0u) goto done;
                            u1 += (unsigned)c0;
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(((unsigned)x0 >> (garr[u2 & 7u] & 31u)) || (unsigned)w0), (u3 >> (0x13f3e3c8u & 31u)), (v0 ^ (unsigned)e0)); }
                            if ((unsigned)l0) goto L3;
                            c1 = (signed char)((p1 >> (0x41dfa782u & 31u)) | (unsigned)(p2 && 0x80000000u));
                        } while (i0++ < 4u && -(unsigned)((unsigned)b0 < i1));
                        if ((unsigned)(short)(unsigned)(i2 || (p0 * r0.x))) goto L1;
                        c1 = (signed char)(unsigned)((int)p2 < (int)(unsigned)((int)(unsigned)(unsigned char)((unsigned)b0 | a0[u1 & 3u]) >= (int)(0x80000000u % (i0 | 1u))));
                    }
                    do { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + i2);
                        g1 += *q0;
                        if (i0) break;
                        g0 = 0x80000000u;
                    } while (i0++ < 6u && (unsigned)(garr[u2 & 7u] == (unsigned)c0));
                    h1 = (unsigned short)(h1 + (0x80000000u & garr[i1 & 7u]));
                } else {
                    while (i0++ < 3u && 0x10000u) { if (--fuel == 0u) goto done;
                        break; (void)((0xa736e080u / (p0 | 1u)));
                        r0.x = (((unsigned)e0 >> (0x7fffffffu & 31u)) ^ (unsigned)((int)u1 >= (int)(unsigned)x0));
                    }
                    d0 = d0 * 0.5 + (double)((((unsigned)c1 ? (r0.x - (unsigned)w0) : (unsigned)h1) - 0x7fffffffu) & 1023u);
                }
                { unsigned t4; double z4; if (((unsigned)((int)0x7fffffffu >= (int)0x42f4e017u)) & 1u) { t4 = (unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)i0 >= (int)(unsigned)f0) >= (int)u2); z4 = (double)(((unsigned)((9u >> (u2 & 31u)) || u2)) & 255u); } if (((unsigned)((int)0x7fffffffu >= (int)0x42f4e017u)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    if (budget != 0u) { budget -= 1u; u1 = fn2((g1 | v0), ~(unsigned)((short)i0 > (signed char)0u), (unsigned)((short)0x10000u > (signed char)v0)); }
                    u2 += (0xffffffffu + ((unsigned)(g1 == (unsigned)f0) * (unsigned)h0));
                }
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    v0 = (unsigned)(unsigned char)(unsigned)(((unsigned)((8u << ((unsigned)e0 & 31u)) < u1) / ((unsigned)s0 | 1u)) || 0xeae68808u);
                }
                e0 = e0 * 0.5L + (long double)(u3 & 1023u);
                goto L1;
            }
        } else {
            x0 = x0 * 0x100000001b3ull + (unsigned)((short)0x80000000u > (signed char)4u);
            { unsigned t5; double z5; if ((0xf912606eu) & 1u) { t5 = p1; z5 = (double)((((unsigned)h0 - 2u)) & 255u); } if ((0xf912606eu) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)(unsigned)c0 < (int)(unsigned)s0), (*q0 % ((unsigned)((short)5u > (signed char)garr[u2 & 7u]) | 1u)), ((unsigned)s0 - (g1 & p2))); }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn2(0xffffffffu, (unsigned)c0, (v0 >> (*mp & 31u))); }
        }
        switch ((unsigned)(0x10000u == 0x80000000u) & 7u) {
            s1 = (int)((unsigned)s1 + (i2 & (unsigned)((unsigned)b0 && 0x10000u)));
            do { if (--fuel == 0u) goto done;
                b0 = (unsigned)!((unsigned)f0 >> ((unsigned)(short)((unsigned)(garr[i1 & 7u] == (unsigned)l0) | u3) & 31u)) != 0u;
                while (i1++ < 3u && (unsigned)(unsigned char)(r0.y ^ fuel)) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)(((unsigned)((int)6u < (int)m0) | (unsigned)((short)(0x43c3366eu * g0) > (signed char)(unsigned)e0)) & 1023u);
                    v0 = (unsigned)!(unsigned)((unsigned)((short)*mp > (signed char)g0) || (unsigned)(u3 < (unsigned)(i0 || *q0)));
                    { unsigned t6; double z6; if ((0xffffffffu) & 1u) { t6 = (unsigned)(unsigned char)(u2 % ((unsigned)(w0 >> 29) | 1u)); z6 = (double)(((unsigned)(short)(0x80000000u - r0.y)) & 255u); } if ((0xffffffffu) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                        u0 = u0 * 0x9e3779b1u + (i1 * r0.y);
                        m0 ^= (unsigned)((short)(unsigned)h1 > (signed char)(0x10000u ? (unsigned)h0 : 0x21408cfbu));
                        break; (void)(((unsigned)e0 & (unsigned)s0));
                    }
                    garr[0x5403acd8u & 7u] = 0x722edd9bu;
                    r0.y ^= ((unsigned)b0 ^ 0xf65b8a28u);
                    L4: if (--fuel == 0u) goto done;
                }
                switch (g0 & 7u) {
                    do { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)0x10000u << (~(unsigned)((int)(unsigned)((int)g1 >= (int)a0[i0 & 3u]) < (int)(unsigned)(short)((unsigned)((int)m0 < (int)(unsigned)h1) | r0.x)) & 63u);
                        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((int)(unsigned)x0 >= (int)0x10000u), ((unsigned)b0 ? (unsigned)h1 : g1), (unsigned)(short)((unsigned)((short)(unsigned)b0 > (signed char)a0[i0 & 3u]) / (0x70e3c5f0u | 1u))); }
                        if (u3 == 7u) return ((unsigned)((short)m0 > (signed char)fuel) | (m0 >> (i2 & 31u)));
                        c1 = (signed char)((m0 & 4u) % ((p0 >> (-(0xaa2abd1bu ^ (unsigned)h1) & 31u)) | 1u));
                        if (u3 == 7u) return (unsigned)(((unsigned)b0 << ((unsigned)d0 & 31u)) || (unsigned)(short)(unsigned)(1u || r0.y));
                        u0 = (unsigned)(signed char)(unsigned)((int)(1u >> (0x10000u & 31u)) < (int)(unsigned)((short)(unsigned)l0 > (signed char)u1));
                    } while (i1++ < 6u && (garr[i1 & 7u] << (g1 & 31u)));
                    goto L1;
                }
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 5u: ;
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        g0 = (unsigned)c0;
                        s0 = (int)((unsigned)((short)(u2 ^ p2) > (signed char)i2) - (7u | m0));
                        if (fuel < 8u) return (unsigned)(short)(u1 ^ (unsigned)((int)3u < (int)((unsigned)(x0 >> 70) % (a0[u1 & 3u] | 1u))));
                    }
                    c1 = (signed char)-(3u % ((0x32d5078bu | (0xcb22d1b4u | u2)) | 1u));
                    for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn1(*q0, ((unsigned)b0 & 0x54a4dfb1u), (0xc70beb85u << (u3 & 31u))); }
                        switch (0x64c094c5u & 7u) {
                            m0 ^= ((unsigned)d0 ^ (9u ^ (unsigned)((short)0x7fffffffu > (signed char)(unsigned)h0)));
                        }
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(w0 >> 29) + v0), (unsigned)((int)a0[i0 & 3u] >= (int)g0), 0x99a719f6u); }
                        if ((0x7fffffffu - 0u)) continue;
                    }
                }
                h0 = (short)(unsigned)(unsigned char)(((unsigned)h0 % ((unsigned)((unsigned)c1 || (unsigned)d0) | 1u)) / ((unsigned)((short)0u > (signed char)a0[i0 & 3u]) | 1u));
                case 0u: ;
            } while (i0++ < 6u && (unsigned)(unsigned char)(unsigned)(0x80000000u || (unsigned)e0));
        }
        while (i0++ < 5u && ((0x5884d2bdu % (0x7fffffffu | 1u)) >> (4u & 31u))) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                a0[g0 & 3u] = ~((unsigned)(a0[u1 & 3u] && i0) ^ (v0 | 0x1cc15cefu));
                s0 = (int)(unsigned)((unsigned)c0 < i2);
                if (a0[i0 & 3u]) {
                    l0 = (long)((unsigned long)l0 + ~(0xe2ee2d38u % (v0 | 1u)));
                    { unsigned t7; double z7; if (((p2 & u2)) & 1u) { t7 = (p1 ? (unsigned)c0 : (unsigned)c1); z7 = (double)(((unsigned)f0) & 255u); } if (((p2 & u2)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                        if (budget != 0u) { budget -= 1u; u1 = fn0(0x7fffffffu, (unsigned)b0, r0.x); }
                    }
                    r0.y ^= (unsigned)((i0 - (unsigned)h1) && (unsigned)(7u || (unsigned)h0));
                }
                while (i2++ < 7u && (a0[u1 & 3u] >> ((unsigned)(0x7fffffffu == (unsigned)d0) & 31u))) { if (--fuel == 0u) goto done;
                    continue; (void)((unsigned)(a0[i0 & 3u] < g1));
                    for (;;) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn2((0x158cd888u | ((unsigned)(w0 >> 29) >> (i0 & 31u))), ((unsigned)(*mp == i1) / ((unsigned)s0 | 1u)), (8u & i0)); }
                        switch ((0x7fffffffu + (unsigned)((unsigned)f0 == u3)) & 7u) {
                            u0 = u0 * 0x9e3779b1u + (unsigned)((int)(unsigned)b0 >= (int)p0);
                            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)b0 >= (int)u1), ~(garr[i1 & 7u] / (fuel | 1u)), 0x80000000u); }
                            case 7u: ;
                            u2 = (a0[i0 & 3u] ^ (unsigned)f0);
                            case 4u: ;
                        }
                        break; (void)((unsigned)((int)(unsigned)c1 >= (int)(unsigned)((int)9u < (int)0x10000u)));
                    }
                    c0 = (unsigned char)(unsigned)((unsigned)s0 == ~(((unsigned)c0 - (unsigned)(3u && (unsigned)c1)) & 0x403f5d01u));
                    b0 = ((unsigned)c1 & a0[i0 & 3u]) != 0u;
                }
                e0 = e0 * 0.5L + (long double)((unsigned)((8u * (unsigned)(*mp == 0x74d02926u)) == p1) & 1023u);
                m0 ^= (unsigned)s0;
            }
            g1 += (unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)b0 < m0) == (unsigned)(u0 == 0xffffffffu));
            if (a0[i0 & 3u]) {
                g1 += (m0 & 4u);
                while (i1++ < 3u && 0x40be703u) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (((unsigned)(w0 >> 29) & (unsigned)((int)0xe586504du >= (int)-(unsigned)((int)(unsigned)e0 >= (int)g1))) + garr[u2 & 7u]);
                    w0 = w0 * 6364136223846793005ull + (unsigned)(1u == 0x10000u);
                    while (i2++ < 2u && a0[u1 & 3u]) { if (--fuel == 0u) goto done;
                        u3 ^= ((unsigned)(p1 == 0x106199afu) % (0xbd8f0ff5u | 1u));
                        if (p1) break;
                        continue; (void)(p0);
                    }
                }
                if ((0x80000000u - ((unsigned)b0 | (unsigned)c0))) continue;
            } else {
                e0 = e0 * 0.5L + (long double)((unsigned)(short)((unsigned)(unsigned char)(g1 ? 7u : (unsigned)(0x7fffffffu || (unsigned)s1)) / (7u | 1u)) & 1023u);
                while (((unsigned)c1 / (r0.x | 1u))) { if (--fuel == 0u) goto done;
                    if ((unsigned)c0) continue;
                    q0 = &garr[0x7fffffffu & 7u];
                }
                if (u3) {
                    switch ((3u / ((unsigned)h1 | 1u)) & 7u) {
                        c1 = (signed char)(v0 % (((unsigned)d0 ? 0x994d5dd1u : 2u) | 1u));
                        s0 = (int)((r0.x ? 0xe8717c8au : (unsigned)e0) * (unsigned)l0);
                        g0 = (unsigned)((unsigned)(w0 >> 29) && ((r0.y & p0) % (7u | 1u)));
                        if ((unsigned)(p1 && (unsigned)x0)) {
                            if ((a0[u1 & 3u] >> (0x10000u & 31u))) break;
                            e0 = e0 * 0.5L + (long double)((6u + (unsigned)((unsigned)l0 && (unsigned)(*q0 || -(r0.x ^ (unsigned)e0)))) & 1023u);
                            if (budget != 0u) { budget -= 1u; u2 = fn0((0xd72d1f76u * v0), (unsigned)((u2 + i2) < (unsigned)s1), (unsigned)((int)(unsigned)(u1 && i1) < (int)u0)); }
                            e0 = e0 * 0.5L + (long double)((0xe74f6ec6u % (((unsigned)(p0 && u0) & fuel) | 1u)) & 1023u);
                        } else {
                            d0 = d0 * 0.5 + (double)((((unsigned)c1 * (unsigned)s0) << ((2u * (r0.y & (unsigned)l0)) & 31u)) & 1023u);
                            goto L0;
                        }
                        r0.y ^= (unsigned)(unsigned char)((0x80000000u / (a0[i0 & 3u] | 1u)) >> ((unsigned)((short)u3 > (signed char)(unsigned)((int)0x80000000u >= (int)(unsigned)b0)) & 31u));
                        a0[(unsigned)(0x80000000u && (unsigned)c1) & 3u] = u0;
                    }
                    { unsigned t8; double z8; if ((((unsigned)(signed char)((unsigned)(x0 >> 70) << ((unsigned)c1 & 31u)) - u3)) & 1u) { t8 = (unsigned)((int)(a0[u1 & 3u] % ((unsigned)(x0 >> 70) | 1u)) >= (int)0x8d5f3de3u); z8 = (double)(((unsigned)((int)0xf6222d80u >= (int)(r0.y >> (3u & 31u)))) & 255u); } if ((((unsigned)(signed char)((unsigned)(x0 >> 70) << ((unsigned)c1 & 31u)) - u3)) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                        if (((unsigned)((int)(unsigned)c1 >= (int)(unsigned)w0) | 1u)) continue;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)c0, (unsigned)((short)(unsigned)((short)i2 > (signed char)(unsigned)h0) > (signed char)0x7fffffffu), (unsigned)((fuel << (0x10000u & 31u)) || 4u)); }
                        if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)h0 >> ((unsigned)c0 & 31u)), 0xcdd8029bu, (0x10000u | p2)); }
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(unsigned)((int)-((unsigned)b0 & fuel) >= (int)(unsigned)h0), p0, 5u); }
                    }
                }
                g0 = 3u;
            }
            if ((unsigned)((int)p0 >= (int)g1)) break;
        }
    }
    goto L4;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(r0.y || i1)) break;
    } while (i0++ < 7u && (unsigned)(p2 == (unsigned)(unsigned char)(0x7fffffffu % (0x10000u | 1u))));
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)f0 ^ *mp), (unsigned)(short)((unsigned)c0 ? u1 : u3), 0x7fffffffu); }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 += 0x1dd10fb3u;
        u1 = (*mp / (*q0 | 1u));
        if (i2) break;
        { unsigned t9; double z9; if (((a0[u1 & 3u] + 3u)) & 1u) { t9 = ((p0 - (unsigned)h1) - 0xae402167u); z9 = (double)(((unsigned)((short)0xa59635b8u > (signed char)((unsigned)c0 << (4u & 31u)))) & 255u); } if (((a0[u1 & 3u] + 3u)) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
            continue; (void)(~((unsigned)c0 % (~(unsigned)((int)(unsigned)l0 >= (int)0x2f1ac93du) | 1u)));
        }
        *q0 = (unsigned)f0;
    }
    x0 = x0 * 0x100000001b3ull + 0xfd53d150u;
    if (((unsigned)s0 ^ (u2 - p0))) goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn2(~(i1 & (unsigned)d0), p0, ((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)(w0 >> 29)) + 3u)); }
    c1 = (signed char)(unsigned)((u0 % (8u | 1u)) == u2);
    g1 += ((unsigned)(signed char)(g1 / ((unsigned)e0 | 1u)) << (((u2 + u0) & (unsigned)h0) & 31u));
    if ((p0 ? p0 : (unsigned)e0)) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((p2 >> (u1 & 31u)), -(unsigned)((int)p0 >= (int)g0), (unsigned)(unsigned char)(i2 % (g1 | 1u))); }
        if (((unsigned)f0 & (i2 - 0x10000u))) {
            *q0 += (((0x80000000u | 0x7fffffffu) ^ a0[u1 & 3u]) / (0xb00027b3u | 1u));
            if (((unsigned)(short)(unsigned)((int)0x80000000u < (int)2u) << ((unsigned)(x0 >> 70) & 31u))) goto L0;
            s1 = (int)((unsigned)s1 + m0);
            l0 = (long)((unsigned long)l0 + ((0x7fffffffu ^ (unsigned)((int)garr[i1 & 7u] >= (int)0x88f08df2u)) << (r0.y & 31u)));
            goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((0x71699ee0u / (garr[i1 & 7u] | 1u)) || 0xffffffffu), (unsigned)(unsigned char)(unsigned)((unsigned)((int)fuel < (int)r0.y) < fuel), ((unsigned)h1 + 0x10000u)); }
        } else {
            m0 ^= (*mp - (unsigned)e0);
        }
        v0 = (unsigned)(signed char)((*q0 | (unsigned)(w0 >> 29)) + ((0x80000000u & (unsigned)x0) << (7u & 31u)));
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            garr[(unsigned)b0 & 7u] = (0x10000u % ((unsigned)((int)a0[i0 & 3u] >= (int)0x10000u) | 1u));
            w0 = w0 * 6364136223846793005ull + (unsigned)h1;
            r0.x = (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)(signed char)(u2 ? (unsigned)s0 : 0x10000u));
            do { if (--fuel == 0u) goto done;
                v0 = (unsigned)(unsigned char)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(4u + (0xffffffffu % ((unsigned)c0 | 1u))));
                while (i2++ < 5u && (unsigned)((int)0u >= (int)(unsigned)((int)(unsigned)(x0 >> 70) < (int)p2))) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((2u >> (6u & 31u)), (0x6bcd8bdau ? 0x9b185dadu : (unsigned)x0), (unsigned)!((unsigned)(short)(*mp << (0x24955cbau & 31u)) % ((unsigned)e0 | 1u))); }
                    u0 ^= (garr[i1 & 7u] | r0.y);
                    break; (void)(((unsigned)d0 ^ ~(unsigned)(p2 || a0[i0 & 3u])));
                    r0.y ^= (unsigned)((unsigned)(garr[i1 & 7u] < i2) && ((unsigned)c1 ? a0[i0 & 3u] : (unsigned)e0));
                    if (2u) goto L4;
                    *q0 += -((unsigned)c1 << ((garr[i1 & 7u] << (0xcc9782e6u & 31u)) & 31u));
                }
                l0 = (long)((unsigned long)l0 + (garr[i1 & 7u] % (((unsigned)b0 + ((unsigned)c0 | 0xffffffffu)) | 1u)));
                if ((unsigned)((short)0x10000u > (signed char)(0u - garr[i1 & 7u]))) break;
                if (fuel < 8u) return ((unsigned)((unsigned)x0 == 0x80000000u) & 8u);
                h1 = (unsigned short)(h1 + (u2 + 0xffffffffu));
            } while (i1++ < 4u && (unsigned)e0);
        }
        e0 = e0 * 0.5L + (long double)((8u | 0x547b1319u) & 1023u);
    }
    if (0u) {
        if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)b0 ? p2 : a0[u1 & 3u]), (unsigned)(x0 >> 70), (unsigned)((short)fuel > (signed char)(0x10000u ^ (unsigned)d0))); }
        r0.y ^= (unsigned)(garr[u2 & 7u] && (0xb7822b7cu - (0x38f720c9u << (a0[i0 & 3u] & 31u))));
        if (*q0) goto L0;
        if ((unsigned)((int)(unsigned)x0 < (int)g0)) {
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)((unsigned)s0 ^ ~(unsigned)(0xffffffffu || (unsigned)!(unsigned)((int)(i1 % (garr[u2 & 7u] | 1u)) >= (int)(unsigned)c0)));
            }
            *q0 = (unsigned)(x0 >> 70);
            l0 = (long)((unsigned long)l0 + (unsigned)x0);
            if (budget != 0u) { budget -= 1u; u3 = fn2((p0 & (unsigned)(u2 || (unsigned)c1)), (unsigned)((unsigned)c1 == (*mp + *mp)), (6u % ((u1 - 0x25564a49u) | 1u))); }
            goto L3;
        } else {
            if (fuel < 8u) return (((unsigned)x0 ? (unsigned)c1 : (unsigned)((unsigned)x0 < v0)) + p0);
        }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)c1) continue;
            if (budget != 0u) { budget -= 1u; u2 = fn2(v0, (a0[i0 & 3u] & 0xffffffffu), ((unsigned)d0 >> (v0 & 31u))); }
            *q0 = ~(unsigned)((unsigned)b0 && (a0[i0 & 3u] / ((0x80000000u - r0.x) | 1u)));
            x0 = x0 * 0x100000001b3ull + (p2 * 7u);
            break; (void)(((unsigned)((int)(unsigned)c0 >= (int)0x32b42f43u) & m0));
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t10; double z10; if ((7u) & 1u) { t10 = i1; z10 = (double)(((fuel + (3u >> ((unsigned)w0 & 31u)))) & 255u); } if ((7u) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                    break; (void)((unsigned)((unsigned)h0 == (unsigned)f0));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((0xae433bd1u % ((unsigned)e0 | 1u)), r0.x, (unsigned)((short)0xffffffffu > (signed char)~(unsigned)((int)v0 >= (int)(unsigned)(x0 >> 70)))); }
                    if (~(unsigned)((int)0xd791a7eau >= (int)(*q0 >> (0xad5e325eu & 31u)))) {
                        if ((i0 - a0[i0 & 3u])) continue;
                        f0 = f0 * 0.5f + (float)((unsigned)(x0 >> 70) & 255u);
                        if ((unsigned)f0) {
                            if (budget != 0u) { budget -= 1u; u3 = fn2(((u3 & 0x1372f15cu) + 9u), ((unsigned)(w0 >> 29) ? fuel : (unsigned)(w0 >> 29)), (0x7fffffffu << ((0x10000u * 0x17724876u) & 31u))); }
                            if (budget != 0u) { budget -= 1u; u1 = fn1(u3, *q0, r0.y); }
                            if ((unsigned)s0) break;
                            f0 = f0 * 0.5f + (float)((g0 ^ (0xdb9a36b2u & g0)) & 255u);
                            u1 ^= ((unsigned)l0 | (unsigned)h1);
                        } else {
                            if ((i2 >> (r0.x & 31u))) break;
                            r0.x = ~(unsigned)(0xffffffffu || ((unsigned)w0 ^ *q0));
                            goto L1;
                            *q0 = -(unsigned)(i1 && (g1 | 6u));
                        }
                        *mp = (unsigned)(u2 == (unsigned)((int)(unsigned)s1 < (int)(unsigned)l0));
                        u0 = u0 * 0x9e3779b1u + (unsigned)((int)((unsigned)c1 | *q0) < (int)(unsigned)((int)*mp >= (int)(unsigned)d0));
                    }
                    d0 = d0 * 0.5 + (double)(*q0 & 1023u);
                }
                { unsigned t11; double z11; if (((m0 & u2)) & 1u) { t11 = (unsigned)((unsigned)s1 < 0x44daf773u); z11 = (double)((((unsigned)c0 / (fuel | 1u))) & 255u); } if (((m0 & u2)) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
                    if (*q0) break;
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)c0;
                for (;;) { if (--fuel == 0u) goto done;
                    goto L1;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)w0 - (unsigned)(x0 >> 70)), (*mp % (u0 | 1u)), (unsigned)(w0 >> 29)); }
            }
        } while (i0++ < 3u && garr[i1 & 7u]);
        { unsigned t12; double z12; if (((unsigned)(0x916acba4u && 0x806cb4d2u)) & 1u) { t12 = (unsigned)((int)v0 >= (int)garr[i1 & 7u]); z12 = (double)((0x7fffffffu) & 255u); } if (((unsigned)(0x916acba4u && 0x806cb4d2u)) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
            h1 = (unsigned short)(h1 + (unsigned)((int)(0x10000u / (0x87daad7u | 1u)) >= (int)u3));
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if (-(((unsigned)d0 / ((unsigned)b0 | 1u)) | 0xf9c54fecu)) break;
                    switch ((*q0 - i0) & 7u) {
                        u2 = u2 * 0x9e3779b1u + (unsigned)(6u && (unsigned)((unsigned)x0 && (unsigned)c1));
                    }
                    { unsigned t13; double z13; if ((0x7fffffffu) & 1u) { t13 = i1; z13 = (double)(((unsigned)(signed char)((i0 | (unsigned)b0) & (unsigned)(w0 >> 29))) & 255u); } if ((0x7fffffffu) & 1u) { u1 += t13; d0 = d0 * 0.5 + z13; }
                        if ((unsigned)(3u < i2)) goto L0;
                        if ((unsigned)h0) goto L0;
                    }
                    *q0 += (unsigned)((8u << (2u & 31u)) < u1);
                } while (i1++ < 7u && (unsigned)(u2 || u0));
                if (((g0 << (0x80000000u & 31u)) + 0x80000000u)) continue;
                if (~(unsigned)(g0 && r0.y)) {
                    switch (((unsigned)(w0 >> 29) ^ 0u) & 7u) {
                        garr[p0 & 7u] = (unsigned)((unsigned)((int)i1 >= (int)0x7fffffffu) || (unsigned)((unsigned)h0 && fuel));
                        b0 = ((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)(v0 < (unsigned)c0)) - 7u) != 0u;
                        goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(0x4e5d0978u && g1), (0x2e8149c8u | 0x978550ddu), ((unsigned)x0 << ((unsigned)((unsigned)e0 < u0) & 31u))); }
                    }
                    c1 = (signed char)(i1 * (unsigned)((short)(0x80000000u / (p2 | 1u)) > (signed char)fuel));
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)s1) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)g0 < (int)*q0), (unsigned)(short)(unsigned)((int)(unsigned)w0 < (int)0xe0d8ae6u), ((unsigned)c0 ^ u3)); }
                        for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                            continue; (void)(u1);
                            if ((0xfa2f9a50u | (unsigned)((int)(unsigned)s0 < (int)r0.x))) goto L1;
                            break; (void)((unsigned)(w0 >> 29));
                            r0.y ^= i0;
                        }
                        h1 = (unsigned short)(h1 + (unsigned)!(-(unsigned)((int)6u < (int)p2) + (unsigned)((int)(unsigned)(short)((unsigned)c1 ^ 0x80000000u) >= (int)u2)));
                    }
                    d0 = d0 * 0.5 + (double)((unsigned)!(unsigned)((short)9u > (signed char)*q0) & 1023u);
                    r0.x = -(unsigned)((unsigned)(0x788aa158u < (unsigned)w0) == 0xcd914086u);
                }
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    u3 = u3 * 0x9e3779b1u + ((unsigned)((unsigned)h0 == (unsigned)(a0[u1 & 3u] < (unsigned)(x0 >> 70))) - u0);
                    s1 = (int)((unsigned)s1 + (unsigned)((int)((unsigned)h0 / ((unsigned)s0 | 1u)) < (int)(unsigned)(unsigned char)(unsigned)(p0 == (r0.y >> ((unsigned)d0 & 31u)))));
                    u2 += -(unsigned)((unsigned)(((unsigned)c0 ? p2 : i2) == 0xffffffffu) || 0x222eed5du);
                }
                if ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)((unsigned)c0 / (g0 | 1u)))) continue;
                if ((r0.y / ((unsigned)((int)0x80000000u < (int)(unsigned)s0) | 1u))) break;
            }
            *q0 = (*mp ^ (unsigned)((unsigned)((unsigned)c1 || v0) && (unsigned)f0));
            while (i0++ < 2u && (5u << (u1 & 31u))) { if (--fuel == 0u) goto done;
                u2 = (unsigned)(1u && p2);
            }
            if ((9u ^ (unsigned)((short)i2 > (signed char)i0))) goto L1;
            goto L1;
        }
    }
    while (i0++ < 2u && (unsigned)h1) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(v0 == u2), g1, -(unsigned)(((unsigned)(x0 >> 70) | (unsigned)(x0 >> 70)) && (unsigned)c0)); }
            if (budget != 0u) { budget -= 1u; u1 = fn1(0x4f28ef31u, (unsigned)((int)0x80000000u < (int)1u), (unsigned)((unsigned)(w0 >> 29) == 4u)); }
            do { if (--fuel == 0u) goto done;
                if (v0) {
                    if (g1) {
                        u2 += (~(unsigned)((int)(unsigned)h0 < (int)v0) / ((g0 >> (p1 & 31u)) | 1u));
                        while (i0++ < 4u && (unsigned)e0) { if (--fuel == 0u) goto done;
                            v0 = 0x10000u;
                            b0 = ((i1 & i0) & 0x80000000u) != 0u;
                            r0.y ^= (unsigned)((int)((unsigned)(7u < v0) & garr[i1 & 7u]) >= (int)(unsigned)s0);
                            if ((unsigned)(r0.y == (unsigned)s1)) break;
                        }
                    } else {
                        u2 = (unsigned)(4u < (0x10000u / (8u | 1u)));
                        if (budget != 0u) { budget -= 1u; u3 = fn2((m0 / (g0 | 1u)), (*q0 * i2), (unsigned)((unsigned)(signed char)(garr[i1 & 7u] | (unsigned)c0) && a0[u1 & 3u])); }
                    }
                }
                if (budget != 0u) { budget -= 1u; u1 = fn1((u1 - (2u ^ 0xffffffffu)), (g1 | *q0), fuel); }
            } while (i2++ < 2u && (unsigned)((unsigned)c1 == (unsigned)((int)v0 >= (int)g1)));
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(-(unsigned)(0x80000000u == (*mp * (unsigned)((int)(unsigned)b0 >= (int)0x10000u))) & 1023u);
            }
            r0.x = ~(p2 * (8u - 5u));
            do { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (0x80000000u ^ (unsigned)w0);
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(u0 == i2), i0, u1); }
                r0.x = ((unsigned)(i0 || (unsigned)f0) ^ -(unsigned)((unsigned)e0 || p0));
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)x0) break;
                    for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)~(g1 + i2) << (6u & 63u);
                        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)h0, (unsigned)(garr[u2 & 7u] || a0[i0 & 3u]), (unsigned)((int)(unsigned)e0 < (int)(unsigned)c1)); }
                    }
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (((unsigned)b0 - (unsigned)((short)1u > (signed char)p1))) break;
                        continue; (void)((m0 << ((garr[i1 & 7u] ^ 0xd6e614fdu) & 31u)));
                        x0 = x0 * 0x100000001b3ull + (i0 ^ 0x482f6cd9u);
                    }
                    if ((unsigned)(signed char)(unsigned)(0x4ea54caeu && (unsigned)s0)) goto L3;
                    g0 = (unsigned)((int)i2 >= (int)(((unsigned)e0 - 0x80000000u) | fuel));
                    if ((unsigned)((int)0x10000u >= (int)0xbc2b3691u)) continue;
                } while (i0++ < 6u && (unsigned)(u2 == v0));
            } while (i2++ < 5u && ((unsigned)(0xdf8abe6du < fuel) & 0x2df8a2b2u));
        } while (i1++ < 4u && ((unsigned)c0 * (5u * i0)));
    }
    r0.x = 5u;
    switch ((unsigned)((short)0x12ec5f6cu > (signed char)0xffffffffu) & 7u) {
        case 3u: ;
        if ((unsigned)((short)(unsigned)b0 > (signed char)r0.y)) goto L4;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)0x99843a31u >= (int)(unsigned)c0), ((unsigned)((short)p1 > (signed char)0x80000000u) + (unsigned)h1), (unsigned)((unsigned)(8u < u1) || u2)); }
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((7u - i0) & 1023u);
        s1 = (int)((unsigned)s1 + (unsigned)((((unsigned)x0 >> (0x80000000u & 31u)) >> (p2 & 31u)) == (u2 << (0xffffffffu & 31u))));
        while (i0) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn2(garr[i1 & 7u], (unsigned)(w0 >> 29), 1u); }
            { unsigned t14; double z14; if ((5u) & 1u) { t14 = (unsigned)(u3 || (r0.x | (unsigned)w0)); z14 = (double)(((g0 & 3u)) & 255u); } if ((5u) & 1u) { u0 += t14; d0 = d0 * 0.5 + z14; }
                garr[g1 & 7u] = ((garr[u2 & 7u] / ((unsigned)c1 | 1u)) - (unsigned)(i1 || (unsigned)(0x80000000u && 0xc1cfbdf5u)));
                x0 = x0 * 0x100000001b3ull + (1u / (4u | 1u));
            }
            while (i2++ < 7u && (unsigned)d0) { if (--fuel == 0u) goto done;
                garr[((unsigned)l0 >> ((unsigned)s1 & 31u)) & 7u] = (unsigned)((*q0 % (garr[i1 & 7u] | 1u)) == i0);
            }
            if ((unsigned)d0) {
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)((int)(unsigned)x0 >= (int)p0) && r0.y), 3u, 8u); }
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((int)p0 < (int)i0) / ((unsigned)f0 | 1u)), 2u, (u1 + ((unsigned)w0 * m0))); }
                h1 = (unsigned short)(h1 + (g0 & ((unsigned)e0 - 0x80000000u)));
                *q0 += (unsigned)((unsigned)(short)(unsigned)((unsigned)f0 && 1u) < (unsigned)((short)(unsigned)c1 > (signed char)(0xffffffffu * a0[u1 & 3u])));
            } else {
                continue; (void)((7u - 0x83996e29u));
            }
        }
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)0x10000u >= (int)((unsigned)((int)a0[i0 & 3u] < (int)*q0) >> (0x63880341u & 31u)));
        f0 = f0 * 0.5f + (float)(0x10000u & 255u);
    }
    w0 ^= (unsigned long long)(0xe691149u / ((unsigned)(x0 >> 70) | 1u)) << (i0 & 63u);
    i0 = ((unsigned)x0 & -((unsigned)s1 ? p1 : 0x7fffffffu)) & 15u;
    u1 = u1 * 0x9e3779b1u + (unsigned)s0;
    switch ((unsigned)!(unsigned)((int)r0.y >= (int)fuel) & 7u) {
        if (budget != 0u) { budget -= 1u; u2 = fn2(0xe303ce45u, (unsigned)s1, (unsigned)c1); }
        do { if (--fuel == 0u) goto done;
            s0 = (int)(unsigned)l0;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(a0[u1 & 3u] < 0x7fffffffu), (unsigned)((int)(unsigned)l0 < (int)(unsigned)h1), (garr[i1 & 7u] - ((unsigned)h0 - 0xad27dd2eu))); }
            w0 = w0 * 6364136223846793005ull + 0xffffffffu;
        } while (i0++ < 6u && (unsigned)f0);
        u0 += ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)c0) >> ((u2 / ((i2 * g1) | 1u)) & 31u));
    }
    u2 += ((unsigned)f0 % (7u | 1u));
    do { if (--fuel == 0u) goto done;
        h0 = (short)(unsigned)((int)u3 >= (int)(unsigned)((unsigned)d0 && (r0.y << (garr[u2 & 7u] & 31u))));
    } while (i0++ < 3u && (unsigned)s1);
    while (i0++ < 5u && (u3 - g1)) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)fuel >= (int)-((unsigned)e0 - (unsigned)f0))) continue;
        if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)e0 & (p0 & (unsigned)s0)), (v0 + 4u), (unsigned)((int)u2 >= (int)(unsigned)(0x8d146da7u == m0))); }
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)e0 * 0xffffffffu), (unsigned)(p1 == (unsigned)((short)i1 > (signed char)(unsigned)s1)), (unsigned)h0); }
            u1 += ((0xb6398569u ^ (unsigned)((unsigned)h0 && 4u)) & (unsigned)l0);
            if ((unsigned)(u0 && 5u)) goto L0;
            s0 = (int)((unsigned)h0 / (((unsigned)(w0 >> 29) ? (unsigned)c1 : m0) | 1u));
        }
        *mp = ((unsigned)b0 - garr[i1 & 7u]);
    }
    w0 ^= (unsigned long long)(0x237c8907u | (unsigned)h0) << ((3u - ((u3 - (unsigned)((int)garr[i1 & 7u] < (int)(unsigned)c0)) << ((unsigned)(x0 >> 70) & 31u))) & 63u);
    goto L0;
    if ((v0 >> (u0 & 31u))) goto L4;
    if ((unsigned)(g1 < (u2 & u1))) goto L3;
    *q0 = (unsigned)(unsigned char)(unsigned)((int)(unsigned)((short)(unsigned)d0 > (signed char)4u) < (int)(a0[u1 & 3u] | u1));
    while ((unsigned)((unsigned)d0 && i1)) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)d0, (unsigned)((unsigned)c0 == 9u), 7u); }
        g0 = (unsigned)(0xf2ff9d7fu == (unsigned)((short)(6u / ((unsigned)s1 | 1u)) > (signed char)7u));
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)g0)) {
            while (i1++ < 2u && (unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn2(((7u & 5u) + 0x80000000u), (unsigned)!(r0.y - i1), (p0 - (i1 / ((unsigned)(x0 >> 70) | 1u)))); }
                while ((unsigned)((short)g1 > (signed char)(unsigned)w0)) { if (--fuel == 0u) goto done;
                    s0 = (int)(p0 % ((r0.y + (unsigned)(5u == (unsigned)c1)) | 1u));
                    if ((r0.y - p2)) break;
                    u3 += garr[u2 & 7u];
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((i1 << (r0.y & 31u)) | (unsigned)s1), (unsigned)!(*mp << (p0 & 31u)), (unsigned)(short)(1u >> ((unsigned)s1 & 31u))); }
                    if ((i1 ^ i2)) {
                        u3 = u3 * 0x9e3779b1u + (((unsigned)(x0 >> 70) + p0) | 9u);
                        c1 = (signed char)(unsigned)((short)i1 > (signed char)(r0.y << (u0 & 31u)));
                    } else {
                        w0 ^= (unsigned long long)(unsigned)!(unsigned)((unsigned)c0 < 0xaffb1058u) << ((unsigned)((int)g0 >= (int)(unsigned)h1) & 63u);
                    }
                }
                if ((g0 & (0xcc9af7c8u | 9u))) {
                    *mp = (0xf00b6226u | ((unsigned)s1 / (v0 | 1u)));
                    if ((unsigned)(0x10000u < 0x39184856u)) {
                        b0 = (unsigned)((int)(unsigned)s1 < (int)i0) != 0u;
                        if (budget != 0u) { budget -= 1u; u1 = fn2((*q0 * p0), (unsigned)(r0.x == (unsigned)x0), (unsigned)(fuel == (unsigned)e0)); }
                    }
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)(unsigned)b0 < (int)(unsigned)h0)) goto L1;
                        break; (void)((unsigned)((short)garr[u2 & 7u] > (signed char)~(unsigned)((short)(unsigned)c1 > (signed char)0u)));
                        switch (p0 & 7u) {
                            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(w0 >> 29), -(garr[i1 & 7u] << (a0[i0 & 3u] & 31u)), (unsigned)((short)(unsigned)(u1 == 1u) > (signed char)(unsigned)l0)); }
                            garr[(u2 ^ u1) & 7u] = (1u * g0);
                            d0 = d0 * 0.5 + (double)((8u % (0xffffffffu | 1u)) & 1023u);
                            g1 += ((unsigned)((int)(unsigned)(p1 == a0[i0 & 3u]) >= (int)(unsigned)d0) | (unsigned)((short)5u > (signed char)(unsigned)x0));
                            if ((unsigned)b0) goto L4;
                        }
                        a0[(unsigned)(0x18afbb67u && (unsigned)l0) & 3u] = (unsigned)((int)(unsigned)!(0x7fffffffu % ((u3 + (*q0 << ((unsigned)w0 & 31u))) | 1u)) >= (int)u2);
                        garr[0x80000000u & 7u] = 8u;
                    }
                    w0 ^= (unsigned long long)((unsigned)(x0 >> 70) << (0x307d6523u & 31u)) << ((unsigned)e0 & 63u);
                    u0 ^= (unsigned)s1;
                } else {
                    c0 = (unsigned char)m0;
                    r0.y ^= ((i2 << (i0 & 31u)) + ~(0x8e293e59u | (2u / (m0 | 1u))));
                    m0 ^= (r0.y << ((unsigned)f0 & 31u));
                }
                v0 = (i2 << ((unsigned)h1 & 31u));
                *q0 = (unsigned)x0;
            }
            if (((unsigned)(0xe16688e8u == i2) | 0xffffffffu)) goto done;
            if (0xe5e6d350u) goto done;
        } else {
            if (((*mp % (0xf5a453deu | 1u)) % (u0 | 1u))) goto L3;
            u3 = u3 * 0x9e3779b1u + (unsigned)(((unsigned)(w0 >> 29) ^ r0.x) == p1);
            break; (void)((unsigned)(u0 < 0x74fde06fu));
        }
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1((v0 / (((unsigned)b0 + u3) | 1u)), i0, (unsigned)(0xffffffffu == (unsigned)((unsigned)f0 == 0x10000u))); }
        }
        f0 = f0 * 0.5f + (float)(((unsigned)b0 - (r0.y & 0u)) & 255u);
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (fuel) {
                f0 = f0 * 0.5f + (float)((g1 ^ 0x5d7fac91u) & 255u);
                g0 = (unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)(signed char)(unsigned)((int)0xffffffffu < (int)~(unsigned)(0x4c44287u && fuel)));
                m0 ^= (unsigned)(0xd989bcc9u < (fuel >> (m0 & 31u)));
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn1(u0, (unsigned)(short)((unsigned)s1 * 7u), (garr[i1 & 7u] ^ a0[i0 & 3u])); }
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)!(unsigned)((short)u3 > (signed char)(0xffffffffu ^ r0.x)), (unsigned)((unsigned)c1 < g0), (unsigned)((int)0xcbc4ced1u >= (int)(u1 * (unsigned)c0))); }
                    if (0x7fffffffu) break;
                    *q0 += (unsigned)((unsigned)c0 || 4u);
                }
            } else {
                if (budget != 0u) { budget -= 1u; u2 = fn0((0xa221a6du | 4u), (unsigned)s1, (unsigned)(x0 >> 70)); }
                if ((fuel - (2u >> (a0[u1 & 3u] & 31u)))) continue;
                if (((unsigned)b0 / (2u | 1u))) break;
                if (budget != 0u) { budget -= 1u; u1 = fn1(((p0 ^ u3) % ((unsigned)e0 | 1u)), (unsigned)d0, 0x974e0801u); }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0(p1, ((unsigned)h0 * 0x80000000u), (r0.x >> (u0 & 31u))); }
            { unsigned t15; double z15; if ((((unsigned)((int)a0[i0 & 3u] < (int)u2) / (i0 | 1u))) & 1u) { t15 = ((unsigned)d0 - (unsigned)((short)i0 > (signed char)u1)); z15 = (double)(((unsigned)((int)(unsigned)(x0 >> 70) < (int)8u)) & 255u); } if ((((unsigned)((int)a0[i0 & 3u] < (int)u2) / (i0 | 1u))) & 1u) { u3 += t15; d0 = d0 * 0.5 + z15; }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(u1 == 0xf7fde7afu), (unsigned)(short)(unsigned)((int)(unsigned)s0 >= (int)0x80000000u), (unsigned)((short)(v0 << (0x80000000u & 31u)) > (signed char)garr[u2 & 7u])); }
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)!(u1 ^ (i0 * u0)), (0x7fffffffu * (unsigned)(w0 >> 29)), (unsigned)((unsigned)c1 < i2)); }
                if (garr[i1 & 7u]) break;
            }
            if (g1) break;
            a0[(unsigned)((int)0xa367510eu < (int)0xffffffffu) & 3u] = (((unsigned)x0 ^ a0[u1 & 3u]) ^ 7u);
            u1 ^= (unsigned)(short)(u2 % (((unsigned)f0 / ((a0[i0 & 3u] % (0x80000000u | 1u)) | 1u)) | 1u));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)c0, (fuel | (0xffffffffu | a0[u1 & 3u])), (*mp % ((p1 & (unsigned)h1) | 1u))); }
    } while (i0++ < 6u && p2);
    if ((0x10000u * -(m0 * i0))) goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn2(*q0, (0xec368dcfu << ((unsigned)c0 & 31u)), (unsigned)(a0[i0 & 3u] < m0)); }
    if ((unsigned)((int)garr[u2 & 7u] < (int)0x652838d9u)) goto L1;
    if (p2) goto L4;
    goto L1;
    u0 ^= ((5u >> (g0 & 31u)) >> (((unsigned)(0xdaa83575u < a0[u1 & 3u]) % (*mp | 1u)) & 31u));
    if (r0.x) goto L4;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)v0 > (signed char)p0)) break;
        do { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)d0, ((unsigned)x0 % ((unsigned)((int)(unsigned)e0 >= (int)(unsigned)c0) | 1u)), p2); }
                c0 = (unsigned char)(fuel % (((unsigned)(0x3ed5bdccu < u3) ^ ((unsigned)e0 >> (0x8ce0188fu & 31u))) | 1u));
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)(unsigned)((int)garr[i1 & 7u] >= (int)0x29aa0cc0u) < (int)0xc365b38au)) {
                        h0 = (short)(unsigned)((unsigned)((int)4u < (int)p2) == (unsigned)(x0 >> 70));
                    } else {
                        i2 = (unsigned)f0 & 15u;
                        u0 += 0x80000000u;
                        c1 = (signed char)(6u ? (unsigned)((unsigned)c0 && v0) : (unsigned)((int)p0 >= (int)0x62896700u));
                        if (budget != 0u) { budget -= 1u; u3 = fn0(0x7fffffffu, i1, (0x10000u & (unsigned)((short)p0 > (signed char)7u))); }
                    }
                    g1 += ((unsigned)c1 + (unsigned)h1);
                    r0.x = ((unsigned)w0 | (unsigned)(unsigned char)(r0.x % ((u3 * (unsigned)s1) | 1u)));
                }
                *mp = (unsigned)((int)(unsigned)!((unsigned)l0 + i2) < (int)0x80000000u);
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((short)fuel > (signed char)7u) / (4u | 1u)), (unsigned)e0, ((unsigned)f0 & (unsigned)s0)); }
            }
        } while (i1++ < 7u && (unsigned)((1u & u2) || m0));
        switch ((0xc3990193u ^ (unsigned)b0) & 7u) {
            case 0u: ;
            do { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(0xffffffffu < (fuel / (*q0 | 1u))) < (unsigned)c0) & 1023u);
                u0 = ((unsigned)s1 % ((9u >> ((unsigned)(w0 >> 29) & 31u)) | 1u));
                if (budget != 0u) { budget -= 1u; u0 = fn0(7u, (unsigned)(9u < (unsigned)((short)(unsigned)d0 > (signed char)5u)), (unsigned)s1); }
                default: ;
                { unsigned t16; double z16; if (((unsigned)(unsigned char)(unsigned)(0x8ce72204u && (unsigned)x0)) & 1u) { t16 = (0xffffffffu % ((unsigned)h0 | 1u)); z16 = (double)(((unsigned)(0x80000000u && 0x54111535u)) & 255u); } if (((unsigned)(unsigned char)(unsigned)(0x8ce72204u && (unsigned)x0)) & 1u) { u1 += t16; d0 = d0 * 0.5 + z16; }
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((short)7u > (signed char)(unsigned)x0), (1u % ((unsigned)w0 | 1u)), 1u); }
                    do { if (--fuel == 0u) goto done;
                        a0[(0xc773ea6u ^ g1) & 3u] = (unsigned)((int)1u < (int)(unsigned)d0);
                        case 3u: ;
                        while ((unsigned)(signed char)(0xffffffffu + p2)) { if (--fuel == 0u) goto done;
                            i0 = ((garr[i1 & 7u] - v0) * (unsigned)(r0.y || (unsigned)!(0x3a8de8cfu << (i0 & 31u)))) & 15u;
                            break; (void)(((unsigned)l0 - (unsigned)c0));
                        }
                        g1 += (g1 - ((0x80000000u ? i0 : (unsigned)f0) * v0));
                        h1 = (unsigned short)(h1 + ((unsigned)e0 | (unsigned)b0));
                        h1 = (unsigned short)(h1 + (unsigned)(short)((unsigned)h1 % (0xb842702bu | 1u)));
                    } while (i2++ < 4u && (unsigned)(signed char)(*mp << (0x9252cae0u & 31u)));
                    if (a0[u1 & 3u]) {
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)b0, (unsigned)((unsigned)(w0 >> 29) || *q0), (unsigned)(short)(*mp % (i0 | 1u))); }
                        g1 += (unsigned)(u0 || (1u << (u0 & 31u)));
                        for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                            break; (void)((unsigned)((unsigned)e0 == (unsigned)((unsigned)s1 == garr[i1 & 7u])));
                            goto L3;
                        }
                    } else {
                        continue; (void)((unsigned)s0);
                        switch (3u & 7u) {
                            case 3u: ;
                        }
                    }
                }
            } while (i1++ < 6u && (unsigned)((unsigned)c1 == (1u - 0x80000000u)));
            do { if (--fuel == 0u) goto done;
                c1 = (signed char)((4u - (0x10000u % (p2 | 1u))) ^ (p2 >> (0xe2490073u & 31u)));
                if ((p0 & garr[i1 & 7u])) break;
                *q0 = (unsigned)((int)(unsigned)((int)((unsigned)(w0 >> 29) * (unsigned)d0) < (int)0x23e125beu) < (int)0x24b9c07bu);
                e0 = e0 * 0.5L + (long double)((unsigned)((int)-(unsigned)((unsigned)(a0[i0 & 3u] && (r0.x ^ 0x79a80f7eu)) == 3u) >= (int)m0) & 1023u);
            } while (i1++ < 5u && (unsigned)((unsigned)c1 < m0));
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)h0, (unsigned)(signed char)(unsigned)((unsigned)c1 < (unsigned)w0), ((unsigned)w0 << ((unsigned)(w0 >> 29) & 31u))); }
            d0 = d0 * 0.5 + (double)((*mp >> ((a0[u1 & 3u] + p0) & 31u)) & 1023u);
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t17; double z17; if (((unsigned)((unsigned)x0 || (unsigned)((short)0x9d6a8c3cu > (signed char)0xffffffffu))) & 1u) { t17 = (unsigned)(0xffffffffu || (0x80000000u >> (r0.x & 31u))); z17 = (double)((m0) & 255u); } if (((unsigned)((unsigned)x0 || (unsigned)((short)0x9d6a8c3cu > (signed char)0xffffffffu))) & 1u) { u2 += t17; d0 = d0 * 0.5 + z17; }
                    x0 = x0 * 0x100000001b3ull + ((unsigned)(x0 >> 70) >> (3u & 31u));
                }
            }
        }
        u0 += (garr[i1 & 7u] * (garr[u2 & 7u] % (p1 | 1u)));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (r0.x) {
        h0 = (short)-(unsigned)((int)(((unsigned)b0 % (0xffffffffu | 1u)) * (unsigned)h0) >= (int)g1);
        h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)(signed char)(*q0 / (2u | 1u)) < (int)(~(7u % (0xffffffffu | 1u)) << (0xffffffffu & 31u))));
        r0.x = (((unsigned)(0x80000000u == (unsigned)(w0 >> 29)) % ((7u >> (5u & 31u)) | 1u)) & (unsigned)h0);
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 = ((garr[i1 & 7u] * 5u) | (unsigned)l0);
            if ((*q0 | (u0 - a0[i0 & 3u]))) {
                { unsigned t0; double z0; if (((unsigned)((short)(3u + (unsigned)h1) > (signed char)8u)) & 1u) { t0 = (unsigned)w0; z0 = (double)((g0) & 255u); } if (((unsigned)((short)(3u + (unsigned)h1) > (signed char)8u)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)x0, (a0[i0 & 3u] >> ((unsigned)c0 & 31u)), u1); }
                    h0 = (short)(unsigned)((short)(unsigned)d0 > (signed char)(g0 * (0xeecf01c6u + a0[i0 & 3u])));
                    if (fuel < 8u) return -(((unsigned)(x0 >> 70) | (unsigned)c0) | (unsigned)(signed char)(0x10000u - (unsigned)d0));
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)3u < (int)g1);
                    break; (void)(0x10000u);
                }
            } else {
                e0 = e0 * 0.5L + (long double)((((unsigned)c0 / (0x7fffffffu | 1u)) % ((unsigned)(r0.y < (unsigned)l0) | 1u)) & 1023u);
                continue; (void)((unsigned)((int)(unsigned)l0 >= (int)m0));
                if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)h0, ((unsigned)(x0 >> 70) | r0.x), (0xf1f65373u / ((unsigned)((int)(unsigned)c1 < (int)7u) | 1u))); }
            }
            { unsigned t1; double z1; if ((((unsigned)(*q0 || 0x3cced8d0u) ^ (unsigned)c0)) & 1u) { t1 = 0xf9f3c423u; z1 = (double)((((unsigned)((int)(unsigned)(x0 >> 70) < (int)p0) / ((unsigned)h0 | 1u))) & 255u); } if ((((unsigned)(*q0 || 0x3cced8d0u) ^ (unsigned)c0)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (u3 == 7u) return (unsigned)!(unsigned)(3u < ~((unsigned)x0 ^ (unsigned)c1));
                        *q0 = (unsigned)((int)((unsigned)(signed char)(u3 ^ r0.x) ^ i0) < (int)0u);
                        L0: if (--fuel == 0u) goto done;
                        if ((((unsigned)h1 * (unsigned)l0) ^ 0xbf5869aeu)) break;
                    }
                }
                *q0 += (unsigned)!((unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) && (i1 >> ((unsigned)e0 & 31u))) ^ *mp);
                while (i1++ < 3u && g0) { if (--fuel == 0u) goto done;
                    a0[0x79f10ff5u & 3u] = ((unsigned)((int)6u >= (int)7u) ^ (unsigned)(short)(g0 & (unsigned)((int)(unsigned)f0 >= (int)0xffffffffu)));
                    r0.y ^= ((unsigned)(short)(unsigned)((unsigned)x0 && (unsigned)((int)(unsigned)s0 >= (int)r0.x)) + (unsigned)l0);
                    r0.y ^= (unsigned)!(0xb86421c4u << ((unsigned)(w0 >> 29) & 31u));
                    { unsigned t2; double z2; if (((unsigned)(v0 < (unsigned)(r0.y || (unsigned)s0))) & 1u) { t2 = (unsigned)!((unsigned)f0 ^ (unsigned)(unsigned char)(0xda86ee05u * (unsigned)d0)); z2 = (double)((8u) & 255u); } if (((unsigned)(v0 < (unsigned)(r0.y || (unsigned)s0))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                        break; (void)((unsigned)(w0 >> 29));
                        break; (void)((unsigned)((int)(unsigned)l0 < (int)7u));
                        if (0x80000000u) {
                            *q0 = ((fuel % (8u | 1u)) >> (8u & 31u));
                            if (budget != 0u) { budget -= 1u; u2 = fn0((~(9u << ((unsigned)s1 & 31u)) / (0x70e4aa0fu | 1u)), (unsigned)s0, v0); }
                            r0.y ^= (unsigned)((int)0x80000000u < (int)*mp);
                            if ((unsigned)((unsigned)(w0 >> 29) || (0u * 0x10000u))) break;
                            s1 = (int)((unsigned)s1 + (p2 & (unsigned)s1));
                        } else {
                            L1: if (--fuel == 0u) goto done;
                            if (0x5e46989fu) break;
                            a0[(unsigned)((short)i2 > (signed char)m0) & 3u] = (u0 << ((u2 | 0xfd85dca7u) & 31u));
                            v0 = ((unsigned)(short)((unsigned)!(0xd2db9670u << ((unsigned)(signed char)(unsigned)(g1 < (unsigned)(x0 >> 70)) & 31u)) - garr[i1 & 7u]) ^ u0);
                        }
                    }
                    h1 = (unsigned short)(h1 + ~(unsigned)(0x77189au && u2));
                }
            }
        }
        goto L0;
        if (p0) goto L0;
    } else {
        e0 = e0 * 0.5L + (long double)((p2 + g1) & 1023u);
    }
    r0.y ^= (unsigned)((unsigned)s0 == ((unsigned)e0 - (unsigned)w0));
    if ((unsigned)((short)0x24956ae4u > (signed char)0xffffffffu)) goto L2;
    if ((unsigned)((short)(unsigned)d0 > (signed char)9u)) goto L3;
    while (i0++ < 7u && ((unsigned)f0 ^ 0x80000000u)) { if (--fuel == 0u) goto done;
        r0.y ^= ((u2 & (unsigned)c1) << (((u1 >> ((unsigned)(x0 >> 70) & 31u)) % (u2 | 1u)) & 31u));
        L2: if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)((int)0x7fffffffu < (int)(unsigned)h1));
    }
    if (((unsigned)!(unsigned)(p1 && r0.y) ^ (unsigned)(x0 >> 70))) goto L1;
    { unsigned t3; double z3; if (((unsigned)f0) & 1u) { t3 = (((unsigned)h0 >> (u1 & 31u)) | (unsigned)w0); z3 = (double)(((unsigned)(5u || (unsigned)((unsigned)l0 && (unsigned)f0))) & 255u); } if (((unsigned)f0) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        goto L0;
        if ((4u - (a0[u1 & 3u] / (0xffffffffu | 1u)))) goto L1;
        l0 = (long)((unsigned long)l0 + ((unsigned)(x0 >> 70) * (unsigned)(2u == 0x80000000u)));
    }
    w0 ^= (unsigned long long)(unsigned)((int)fuel < (int)9u) << ((0x80000000u ? 0x6d65604cu : (unsigned)b0) & 63u);
    f0 = f0 * 0.5f + (float)((2u ? 0x7fffffffu : garr[u2 & 7u]) & 255u);
    switch ((unsigned)h1 & 7u) {
        if ((1u % (a0[u1 & 3u] | 1u))) {
            g1 += (6u - (1u % (r0.x | 1u)));
            if (budget != 0u) { budget -= 1u; u1 = fn1((garr[u2 & 7u] * ((unsigned)x0 % (0x7fffffffu | 1u))), (unsigned)c0, (unsigned)((short)(unsigned)c0 > (signed char)(unsigned)s0)); }
        } else {
            goto L1;
            v0 = -(r0.y ? *q0 : g0);
            if (((unsigned)(signed char)((unsigned)f0 ^ (unsigned)l0) / (u3 | 1u))) break;
        }
        h0 = (short)(unsigned)x0;
        x0 = x0 * 0x100000001b3ull + (unsigned)((short)((unsigned)s0 << (2u & 31u)) > (signed char)(7u & 0xffffffffu));
        if (u3 == 7u) return fuel;
    }
    { unsigned t4; double z4; if ((0xdc252224u) & 1u) { t4 = (unsigned)((5u ^ p1) && 4u); z4 = (double)(((unsigned)((unsigned)(0xfc38824u || garr[i1 & 7u]) || (unsigned)f0)) & 255u); } if ((0xdc252224u) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        while (i0++ < 5u && (0xffffffffu ? 0xffffffffu : (unsigned)s1)) { if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
        }
        if ((unsigned)l0) goto L4;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)h0, (unsigned)c1, (p1 / (*mp | 1u))); }
    if (budget != 0u) { budget -= 1u; u1 = fn3((((unsigned)(x0 >> 70) - g0) & (unsigned)h0), (0x10000u + (0x22f30e0fu & u1)), (unsigned)((unsigned)((short)v0 > (signed char)(unsigned)(x0 >> 70)) || 0xcf491b7fu)); }
    goto done;
    if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)(unsigned char)(i0 ^ (unsigned)e0), ((unsigned)(x0 >> 70) * p2), m0); }
    u2 = u2 * 0x9e3779b1u + (unsigned)((int)(g0 + garr[i1 & 7u]) >= (int)(unsigned)(p0 == 0x5b467576u));
    goto L1;
    q0 = &garr[(i0 + 0u) & 7u];
    goto done;
    x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(unsigned)((unsigned)d0 == u3);
    L4: if (--fuel == 0u) goto done;
    if ((unsigned)((u0 & (unsigned)w0) == 0x622e7b10u)) goto L2;
    h1 = (unsigned short)(h1 + (unsigned)b0);
    if ((0x221da4a5u >> ((unsigned)(u1 < 0x7fffffffu) & 31u))) {
        { unsigned t5; double z5; if ((u0) & 1u) { t5 = 3u; z5 = (double)(((unsigned)c0) & 255u); } if ((u0) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            if (budget != 0u) { budget -= 1u; u0 = fn0((6u - ((unsigned)f0 - (unsigned)c0)), (m0 * (r0.x * 5u)), (g0 << ((unsigned)b0 & 31u))); }
        }
        if (m0) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((unsigned)c1 || p0) && (garr[i1 & 7u] | garr[u2 & 7u])));
    }
    u3 += ((unsigned)(((unsigned)h0 % (0xffffffffu | 1u)) == garr[i1 & 7u]) >> ((p1 & fuel) & 31u));
    if (~(garr[u2 & 7u] & g1)) {
        while (i0++ < 7u && (unsigned)(4u && a0[i0 & 3u])) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)!((unsigned)(i2 == 0x1a865b76u) - ((unsigned)c0 - (unsigned)(short)(unsigned)(0x7fffffffu || p2)));
            *q0 += (1u | i2);
            if ((unsigned)(9u == (unsigned)h1)) {
                u2 = u2 * 0x9e3779b1u + (p2 * ((2u >> (r0.x & 31u)) * (unsigned)e0));
            }
        }
        goto L2;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)(unsigned)(2u < u2), 0xa2da51f3u, ((unsigned)d0 >> (p2 & 31u))); }
        if ((unsigned)((unsigned)s1 && (unsigned)(0xcd8402b9u || 0x10000u))) goto L1;
        if (budget != 0u) { budget -= 1u; u1 = fn0((u3 >> ((r0.y << (garr[i1 & 7u] & 31u)) & 31u)), (unsigned)b0, (p0 & r0.y)); }
    }
    *q0 = ((unsigned)d0 / (0x177db7e1u | 1u));
    goto L1;
    while (i0++ < 5u && i2) { if (--fuel == 0u) goto done;
        while ((unsigned)((unsigned)(u3 == garr[i1 & 7u]) == u0)) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)a0[u1 & 3u] > (signed char)p2)) break;
            b0 = 0xaf02648cu != 0u;
            if ((unsigned)h1) goto L4;
            if (budget != 0u) { budget -= 1u; u0 = fn2(0x80000000u, (g1 % (7u | 1u)), (unsigned)(p1 || u3)); }
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)l0, (unsigned)((unsigned)s0 == *mp), (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)(garr[i1 & 7u] == (unsigned)(x0 >> 70)))); }
        }
        break; (void)((unsigned)((unsigned)((int)0u < (int)0xffffffffu) < 0x4a65005cu));
        *mp = 0xffffffffu;
        d0 = d0 * 0.5 + (double)((unsigned)(signed char)((unsigned)((short)(0xffffffffu << (v0 & 31u)) > (signed char)(unsigned)((short)(unsigned)s1 > (signed char)v0)) * (unsigned)f0) & 1023u);
        if ((0xffffffffu * (unsigned)((int)a0[u1 & 3u] >= (int)i1))) continue;
    }
    e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)((unsigned)(x0 >> 70) && (unsigned)(signed char)((unsigned)(*q0 || garr[u2 & 7u]) * (unsigned)x0)) && 0x7fffffffu) & 1023u);
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(signed char)(0x54082f29u << ((unsigned)((short)i2 > (signed char)(unsigned)d0) & 31u)), (unsigned)(p0 && fuel), (unsigned)b0); }
    r0.x = (unsigned)(signed char)((unsigned)w0 ? 0x258fcf79u : i0);
    if ((unsigned)s0) goto done;
    if (i0) goto L2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 14u, 0x4a7cb3b4u, 0x568ac44du },
        { 12u, 0x4f124954u, 0x1194c7afu },
        { 1u, 0xa06183b1u, 0xe676ba0bu },
        { 4u, 0xaea3d0f8u, 0x5ce425c1u },
        { 12u, 0x1f13a7b6u, 0x328a101du },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
