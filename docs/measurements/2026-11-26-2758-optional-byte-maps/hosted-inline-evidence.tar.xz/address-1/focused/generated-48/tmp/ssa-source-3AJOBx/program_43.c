// test-ssa-source's program of seed 134000445 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xd8cb67eau, g1 = 0xa4fdbf99u;
static unsigned garr[8] = { 0xc36c1f8cu, 0xf0ce650eu, 0x51977efu, 0xdbbab7cu, 0xee79aaeu, 0xd49e5e6fu, 0x607ed109u, 0x911b38f3u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if (((((unsigned)e0 ^ p2) + g1)) & 1u) { t0 = ((u1 << (0xab7554f5u & 31u)) & i0); z0 = (double)(((unsigned)(short)(fuel >> (u2 & 31u))) & 255u); } if (((((unsigned)e0 ^ p2) + g1)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        d0 = d0 * 0.5 + (double)(1u & 1023u);
        L0: if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
        if ((0xffffffffu & (unsigned)h1)) {
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)!(unsigned)((0x6635e7abu ^ *q0) == 9u)) {
                    if ((unsigned)(0x10000u || (0xffffffffu * a0[u1 & 3u]))) break;
                    s1 = (int)((unsigned)s1 + (unsigned)((0x968f3c6au / (~(unsigned)((int)1u >= (int)u1) | 1u)) == (unsigned)((short)0x7fffffffu > (signed char)p1)));
                    if ((unsigned)((int)(a0[i0 & 3u] % (r0.x | 1u)) < (int)i1)) goto L0;
                    if (fuel < 8u) return 0x66a39112u;
                }
                if (((unsigned)(0x10000u < *mp) + p2)) break;
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (unsigned)((int)0x7fffffffu >= (int)(u1 * r0.x)));
                    if ((unsigned)(fuel || (7u >> (u0 & 31u)))) break;
                    l0 = (long)((unsigned long)l0 + (unsigned)(g0 || (unsigned)(u2 < 0x45909753u)));
                }
                s1 = (int)((unsigned)s1 + ((unsigned)f0 << (((unsigned)(2u && 6u) / (*mp | 1u)) & 31u)));
                e0 = e0 * 0.5L + (long double)(((unsigned)s1 / ((v0 - m0) | 1u)) & 1023u);
            }
            L2: if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
            g1 += ((unsigned)((short)7u > (signed char)m0) | ((unsigned)(w0 >> 29) << (5u & 31u)));
            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((0xffffffffu >> ((unsigned)c0 & 31u)) >> (garr[u2 & 7u] & 31u));
        } else {
            g0 = ((unsigned)(p1 || 0xffffffffu) * 6u);
            switch ((unsigned)(fuel || 3u) & 7u) {
                if ((unsigned)((short)(a0[i0 & 3u] & 0x80000000u) > (signed char)0u)) goto L2;
                c0 = (unsigned char)~(unsigned)(0xf3f91584u || 0xc03f3b88u);
                h1 = (unsigned short)(h1 + -(((0x1bf20de2u * p1) | (unsigned)x0) << ((5u & i1) & 31u)));
            }
        }
        if (u3 == 7u) return (unsigned)((int)0x4fa4b9f3u >= (int)(unsigned)c0);
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(g0 == g0) || i0));
    }
    if (p1) {
        L4: if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (p0 ^ (unsigned)b0);
        if ((unsigned)(short)(0u - 0x79daaaebu)) goto L4;
        if (a0[u1 & 3u]) {
            goto L4;
            v0 = (p2 % ((unsigned)((r0.y ^ (unsigned)f0) && (*mp | 0xff85f783u)) | 1u));
            f0 = f0 * 0.5f + (float)((unsigned)(signed char)(unsigned)((garr[i1 & 7u] >> ((u0 & m0) & 31u)) || i2) & 255u);
            if (((unsigned)f0 / (p0 | 1u))) goto L0;
        } else {
            goto L0;
            r0.y ^= 0x80000000u;
            d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)(w0 >> 29)) % (fuel | 1u)) < (*mp % (g1 | 1u))) & 1023u);
            goto L0;
        }
        d0 = d0 * 0.5 + (double)((((2u / (0u | 1u)) | 0xf5479af4u) * 7u) & 1023u);
        switch ((unsigned)f0 & 7u) {
            if ((unsigned)((int)(unsigned)((unsigned)w0 || 0xffffffffu) < (int)(unsigned)f0)) break;
            if (fuel < 8u) return ((unsigned)w0 ^ (unsigned)f0);
        }
    } else {
        goto L2;
        if ((((unsigned)e0 >> (g0 & 31u)) - 0x80000000u)) goto L2;
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            q0 = &garr[(*mp % (*mp | 1u)) & 7u];
            if ((unsigned)f0) goto L2;
            goto L1;
            f0 = f0 * 0.5f + (float)((p1 + 4u) & 255u);
        }
        goto L2;
    }
    if ((0u * (unsigned)((short)(unsigned)x0 > (signed char)(unsigned)f0))) {
        if ((unsigned)(u2 < 0x5f993338u)) {
            if ((unsigned)s1) goto L1;
        } else {
            g1 += ((unsigned)(unsigned char)((unsigned)!(0x7e59aad1u % ((unsigned)!(v0 >> (u3 & 31u)) | 1u)) >> (g0 & 31u)) % ((unsigned)s0 | 1u));
            if ((unsigned)(v0 && (unsigned)!(unsigned)((int)u0 < (int)4u))) goto L2;
        }
    } else {
        if (0xd8fde06du) goto L1;
        u0 = p2;
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            u1 = 4u;
            break; (void)((unsigned)(r0.x || (unsigned)((short)garr[i1 & 7u] > (signed char)u0)));
            break; (void)((unsigned)((short)(0x7789f72bu & i1) > (signed char)(unsigned)b0));
            continue; (void)((unsigned)d0);
        }
    }
    switch ((m0 ^ (i0 + 0x10000u)) & 7u) {
        case 2u: ;
        goto done;
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            u1 ^= (0x6d83a922u ? 0u : (fuel | p1));
            if ((unsigned)((int)(1u >> ((unsigned)b0 & 31u)) >= (int)*q0)) {
                u0 = (0u * 0xffffffffu);
                case 4u: ;
                do { if (--fuel == 0u) goto done;
                    h0 = (short)(unsigned)(short)(9u >> (p0 & 31u));
                    continue; (void)(u3);
                    h0 = (short)(unsigned)((int)(unsigned)x0 >= (int)u3);
                    do { if (--fuel == 0u) goto done;
                        case 5u: ;
                        *q0 += (unsigned)!(0x64e5daddu | (unsigned)(0x8e8e9e2bu && p1));
                    } while (i2++ < 2u && ((unsigned)c1 - 0u));
                    c0 = (unsigned char)(unsigned)(g1 < (unsigned)((0x7fffffffu & i2) < g0));
                    *q0 += ((unsigned)h1 * (unsigned)((unsigned)((int)(unsigned)(0xbe40a953u < (unsigned)(w0 >> 29)) >= (int)p2) == (unsigned)(x0 >> 70)));
                } while (i1++ < 4u && (1u - 4u));
            }
            case 6u: ;
            default: ;
        }
    }
    i1 = (unsigned)((int)((unsigned)(w0 >> 29) << (0x10000u & 31u)) >= (int)((unsigned)f0 / ((unsigned)b0 | 1u))) & 15u;
    v0 = (*q0 * (r0.y - 0xbc864353u));
    if (((unsigned)s1 << ((0x80000000u % ((unsigned)c0 | 1u)) & 31u))) goto L2;
    r0.y ^= (unsigned)!(((u0 ^ *mp) >> (5u & 31u)) / ((unsigned)h0 | 1u));
    if ((unsigned)((0x6236bf5cu ^ p1) || (unsigned)d0)) goto L4;
    switch ((unsigned)(unsigned char)(unsigned)(m0 < 0xffffffffu) & 7u) {
        v0 = (unsigned)((int)(unsigned)((unsigned)x0 == (unsigned)h0) >= (int)(((unsigned)e0 << (0u & 31u)) ^ (unsigned)b0));
        u0 = u0 * 0x9e3779b1u + (0x89802fbu ^ a0[i0 & 3u]);
    }
    if (((u2 >> (4u & 31u)) % (u1 | 1u))) goto done;
    *q0 += (unsigned)(((unsigned)s0 ^ u3) == 3u);
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)d0);
            a0[5u & 3u] = r0.x;
            d0 = d0 * 0.5 + (double)(((unsigned)h0 % ((0xf01a0b29u + (unsigned)((short)0x80000000u > (signed char)(unsigned)((short)0x620299c7u > (signed char)(unsigned)f0))) | 1u)) & 1023u);
            if ((unsigned)(i1 < 0xffffffffu)) break;
            goto L1;
        }
        if (p0) break;
        w0 ^= (unsigned long long)(r0.y * (unsigned)f0) << ((unsigned)(short)(((unsigned)(0xffffffffu == 0x10000u) - i0) + 0x80000000u) & 63u);
        h1 = (unsigned short)(h1 + (0x7fffffffu & (unsigned)(fuel < *q0)));
        h1 = (unsigned short)(h1 + (unsigned)(short)(unsigned)((short)u1 > (signed char)garr[u2 & 7u]));
    } while (i0++ < 6u && (unsigned)((int)i2 >= (int)u0));
    if ((8u / (p0 | 1u))) {
        while ((unsigned)((int)0xbea14145u >= (int)p1)) { if (--fuel == 0u) goto done;
            switch ((r0.y ^ 0xa287a199u) & 7u) {
                h1 = (unsigned short)(h1 + ((unsigned)((int)(unsigned)((int)(unsigned)x0 < (int)(unsigned)c1) >= (int)garr[u2 & 7u]) + m0));
                r0.y ^= (0xe89ac0f4u - ((unsigned)(i0 == u0) * i1));
                case 3u: ;
                if (7u) continue;
                if (((unsigned)((unsigned)(x0 >> 70) && 0x5bee6ecfu) >> (p0 & 31u))) break;
            }
            if ((8u << (*q0 & 31u))) break;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((p0 << ((unsigned)c0 & 31u)));
                m0 ^= (8u - (unsigned)((int)(unsigned)d0 >= (int)fuel));
                f0 = f0 * 0.5f + (float)((a0[i0 & 3u] % ((unsigned)d0 | 1u)) & 255u);
                u2 += ((0x7fffffffu - 0xffffffffu) ^ (unsigned)(short)(unsigned)((int)g0 >= (int)u2));
            }
            break; (void)(4u);
            while (i1++ < 3u && (unsigned)f0) { if (--fuel == 0u) goto done;
                if (-((unsigned)s0 - a0[u1 & 3u])) break;
                c1 = (signed char)((unsigned)(i1 || u1) - -(unsigned)((garr[i1 & 7u] & 0x80000000u) || (unsigned)l0));
                if (((unsigned)s0 * 0xffffffffu)) break;
                if (p2) break;
                g0 = (unsigned)(short)((0u ? 0xffffffffu : 0u) & 7u);
                do { if (--fuel == 0u) goto done;
                    g0 = r0.y;
                    x0 = x0 * 0x100000001b3ull + (unsigned)!(unsigned)(0x80000000u < p2);
                    g0 = ((unsigned)c0 - (unsigned)((int)((unsigned)b0 | 9u) < (int)(unsigned)h1));
                    *mp = (unsigned)(signed char)(v0 >> ((unsigned)((int)9u >= (int)(unsigned)c0) & 31u));
                } while (i2++ < 2u && 7u);
            }
        }
    } else {
        u0 = (unsigned)((short)(unsigned)h0 > (signed char)((garr[i1 & 7u] >> (0x80000000u & 31u)) << (0x7b888162u & 31u)));
    }
    c1 = (signed char)(unsigned)(signed char)((0x673caf05u & (unsigned)(x0 >> 70)) & (unsigned)((int)(unsigned)(x0 >> 70) >= (int)v0));
    while (i0++ < 2u && (unsigned)h1) { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)((int)(unsigned)(v0 < 0xeddb7563u) >= (int)3u);
    }
    i2 = (0x36e33119u & (5u + (g1 << ((unsigned)h1 & 31u)))) & 15u;
    goto L1;
    do { if (--fuel == 0u) goto done;
        if (~(unsigned)(1u < -((unsigned)b0 / ((unsigned)c0 | 1u)))) break;
    } while (i0++ < 7u && ((unsigned)c0 - r0.x));
    w0 = w0 * 6364136223846793005ull + (unsigned)!(unsigned)(0x7fffffffu && (((unsigned)s1 ? r0.x : 0x80000000u) >> (u3 & 31u)));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((2u * (i2 << ((unsigned)l0 & 31u)))) break;
        while ((unsigned)c0) { if (--fuel == 0u) goto done;
            r0.x = (unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)(a0[u1 & 3u] || g0));
            if ((r0.y ? g1 : r0.x)) goto L3;
            w0 = w0 * 6364136223846793005ull + (unsigned)(short)(unsigned)((unsigned)((int)0xd0abcc94u >= (int)(unsigned)((int)*q0 < (int)u1)) == (3u << (i0 & 31u)));
            switch (((unsigned)(w0 >> 29) | u1) & 7u) {
                f0 = f0 * 0.5f + (float)((unsigned)(0xe4a4afc2u == 7u) & 255u);
                case 6u: ;
                w0 = w0 * 6364136223846793005ull + 0x791dbb28u;
                c1 = (signed char)((unsigned)((m0 ^ 0x3afde8c2u) == 0x10000u) << (0x8dedc829u & 31u));
            }
            c0 = (unsigned char)(unsigned)((unsigned)((short)(unsigned)b0 > (signed char)r0.x) && ~(g0 & (unsigned)((short)garr[u2 & 7u] > (signed char)p0)));
        }
    }
    if (7u) goto L1;
    if (((i0 | 0xe43d9680u) >> (p0 & 31u))) goto L3;
    if (((m0 << (*mp & 31u)) | m0)) goto L3;
    h0 = (short)(unsigned)(unsigned char)(unsigned)(0x7b72ea11u && 4u);
    garr[(unsigned)c0 & 7u] = ((unsigned)((int)v0 >= (int)(unsigned)h1) - (m0 - r0.y));
    goto done;
    goto L1;
    l0 = (long)((unsigned long)l0 + a0[i0 & 3u]);
    do { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (garr[u2 & 7u] ^ (unsigned)!(((unsigned)(i0 == r0.y) - a0[u1 & 3u]) / (i0 | 1u))));
    } while (i0++ < 2u && (*mp + (0x10000u ^ 0xcb5bdbb2u)));
    l0 = (long)((unsigned long)l0 + ((unsigned)(0x7fffffffu || (unsigned)b0) / (u3 | 1u)));
    if (0xf352019au) {
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                goto L3;
            }
            if (fuel < 8u) return (unsigned)((short)i1 > (signed char)(fuel << ((unsigned)w0 & 31u)));
            if (v0) goto L1;
        }
        if (fuel < 8u) return (0x80000000u << ((unsigned)d0 & 31u));
        if ((1u >> ((v0 * (unsigned)w0) & 31u))) goto L4;
        goto L2;
        if ((unsigned)(m0 == 0x10000u)) {
            if (g0) goto L1;
        }
        switch ((unsigned)(0x4c6cdd50u && (unsigned)s1) & 7u) {
            case 2u: ;
            do { if (--fuel == 0u) goto done;
                case 4u: ;
                default: ;
                if (fuel < 8u) return ((unsigned)((short)(garr[u2 & 7u] >> ((unsigned)e0 & 31u)) > (signed char)0xb8fb6fbu) >> (0x10000u & 31u));
            } while (i0++ < 3u && (u2 ^ ((unsigned)c0 - g1)));
            if ((unsigned)(unsigned char)(i2 % (p0 | 1u))) {
                if (fuel < 8u) return (unsigned)((int)0x80000000u < (int)(2u << ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)9u) & 31u)));
                c1 = (signed char)(unsigned)(short)((unsigned)b0 ^ (unsigned)s0);
                b0 = (unsigned)((m0 << (0xfc2761adu & 31u)) == ((unsigned)(garr[i1 & 7u] == (unsigned)(w0 >> 29)) % (r0.y | 1u))) != 0u;
                goto L3;
                case 3u: ;
                u1 += (v0 | (unsigned)((unsigned)(short)((g1 << (a0[u1 & 3u] & 31u)) ^ (unsigned)d0) || (unsigned)e0));
            } else {
                for (;;) { if (--fuel == 0u) goto done;
                    if ((p1 + *mp)) continue;
                }
            }
            if ((unsigned)c1) goto L2;
        }
    } else {
        if ((((unsigned)c1 % ((unsigned)c1 | 1u)) << ((unsigned)e0 & 31u))) goto done;
        if ((m0 ^ (unsigned)(u1 || u1))) goto L4;
    }
    goto L0;
    a0[(unsigned)(unsigned char)(unsigned)((int)i0 < (int)(unsigned)w0) & 3u] = 0x21e51b6u;
    switch (u0 & 7u) {
        if (g1) goto L0;
        case 5u: ;
        do { if (--fuel == 0u) goto done;
            continue; (void)(((unsigned)x0 * u2));
            case 0u: ;
            x0 = x0 * 0x100000001b3ull + (i1 & 0x10000u);
        } while (i0++ < 6u && p2);
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)2u < (int)a0[u1 & 3u])) break;
        switch (0x10000u & 7u) {
            r0.x = ((unsigned)((int)0x4cd75e95u < (int)0x80000000u) | (0x9333d6bdu ^ 6u));
            i1 = (unsigned)(unsigned char)(unsigned)((int)0x5ed9e67au < (int)p2) & 15u;
            a0[(unsigned)c1 & 3u] = (*mp << ((unsigned)((short)i0 > (signed char)8u) & 31u));
        }
        garr[(i2 % (5u | 1u)) & 7u] = (unsigned)!(((unsigned)l0 ? a0[u1 & 3u] : 0xd3b28a15u) - (unsigned)d0);
        for (;;) { if (--fuel == 0u) goto done;
            while ((i2 >> (0x20ef6e49u & 31u))) { if (--fuel == 0u) goto done;
                break; (void)((r0.y << (0xdc681763u & 31u)));
                if (v0) break;
            }
        }
        while ((0xe6909747u * (3u | (unsigned)s1))) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((unsigned)((int)9u >= (int)4u) ? i0 : (unsigned)c1);
            a0[*q0 & 3u] = (unsigned)(((3u | (unsigned)h0) | (unsigned)c1) == (u3 & (unsigned)f0));
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            u1 ^= (i0 / ((i0 >> ((unsigned)(x0 >> 70) & 31u)) | 1u));
            if ((unsigned)(unsigned char)((unsigned)(0xbc149042u && 1u) - (unsigned)c1)) break;
            if ((unsigned)((int)0x13096da4u >= (int)(unsigned)d0)) break;
        }
    }
    while (i0++ < 4u && (unsigned)(a0[u1 & 3u] == p1)) { if (--fuel == 0u) goto done;
        { unsigned t1; double z1; if ((garr[i1 & 7u]) & 1u) { t1 = (a0[i0 & 3u] >> (1u & 31u)); z1 = (double)(((unsigned)(0xc63b2e1eu || g1)) & 255u); } if ((garr[i1 & 7u]) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            if ((unsigned)(*q0 || garr[u2 & 7u])) break;
            break; (void)((unsigned)(short)(unsigned)((int)garr[i1 & 7u] >= (int)p1));
            h1 = (unsigned short)(h1 + (unsigned)((short)*q0 > (signed char)(unsigned)s0));
            w0 ^= (unsigned long long)garr[u2 & 7u] << (((i2 ^ (unsigned)h1) * garr[i1 & 7u]) & 63u);
        }
        if (garr[u2 & 7u]) break;
        { unsigned t2; double z2; if ((((unsigned)w0 & 2u)) & 1u) { t2 = 0xfc8f17fu; z2 = (double)((g0) & 255u); } if ((((unsigned)w0 & 2u)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            c0 = (unsigned char)(unsigned)((int)0x7fffffffu >= (int)(unsigned)((2u & a0[u1 & 3u]) == 0x10000u));
            c1 = (signed char)-(unsigned)(0x5f77c5b0u || (0xffffffffu + (unsigned)((unsigned)d0 && (unsigned)((short)(unsigned)b0 > (signed char)0xa1a8226du))));
            b0 = ((unsigned)b0 - r0.x) != 0u;
            e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(x0 >> 70) && (0x7fffffffu + g1)) & 1023u);
            if (u3 == 7u) return (p2 % (p1 | 1u));
        }
    }
    { unsigned t3; double z3; if (((unsigned)l0) & 1u) { t3 = p1; z3 = (double)(((0x80000000u - (a0[u1 & 3u] << (m0 & 31u)))) & 255u); } if (((unsigned)l0) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
        *mp = 0xe47b004eu;
    }
    s1 = (int)((unsigned)s1 + ((unsigned)!((unsigned)h1 % (((unsigned)(w0 >> 29) % ((unsigned)((int)p1 >= (int)9u) | 1u)) | 1u)) >> (0x10000u & 31u)));
    if ((unsigned)(short)(0x80000000u * (unsigned)!(0xf9662b8fu / (garr[i1 & 7u] | 1u)))) goto done;
    goto L0;
    if ((unsigned)((short)(unsigned)w0 > (signed char)(unsigned)s1)) goto L4;
    while (i0++ < 5u && ((unsigned)x0 * (unsigned)l0)) { if (--fuel == 0u) goto done;
        u2 += ((unsigned)x0 & (unsigned)(((unsigned)(short)(unsigned)((unsigned)c1 == a0[u1 & 3u]) >> (fuel & 31u)) < 0xb328b1b1u));
        { unsigned t4; double z4; if ((((p1 * (unsigned)h0) + 0x80000000u)) & 1u) { t4 = (unsigned)(unsigned char)(0x10000u % ((u2 | r0.x) | 1u)); z4 = (double)((((*mp + garr[u2 & 7u]) / (6u | 1u))) & 255u); } if ((((p1 * (unsigned)h0) + 0x80000000u)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
            c1 = (signed char)~(g0 & (unsigned)((int)-(0xf47b565eu - g1) >= (int)(unsigned)s1));
            v0 = (unsigned)(0xffffffffu && ((unsigned)(x0 >> 70) * p2));
            x0 = x0 * 0x100000001b3ull + ((unsigned)w0 % ((unsigned)(signed char)(0x7fffffffu ? (g0 << (0xf37bb50eu & 31u)) : (unsigned)l0) | 1u));
        }
        c1 = (signed char)(unsigned)((short)(unsigned)c0 > (signed char)(a0[i0 & 3u] - (unsigned)(w0 >> 29)));
        f0 = f0 * 0.5f + (float)(-((unsigned)h1 * (unsigned)b0) & 255u);
        h0 = (short)((unsigned)s0 & m0);
        if (0x33eb5716u) {
            u0 = u0 * 0x9e3779b1u + ((i2 ^ 0x2021c189u) / ((0xb71be4afu >> ((unsigned)c0 & 31u)) | 1u));
            { unsigned t5; double z5; if (((*mp * (unsigned)((short)p1 > (signed char)i0))) & 1u) { t5 = (garr[u2 & 7u] >> (i0 & 31u)); z5 = (double)(((unsigned)c0) & 255u); } if (((*mp * (unsigned)((short)p1 > (signed char)i0))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                goto done;
                s1 = (int)((unsigned)s1 + (unsigned)(short)(unsigned)((unsigned)(unsigned char)(unsigned)((short)a0[u1 & 3u] > (signed char)((unsigned)h0 | 5u)) && (unsigned)((int)(unsigned)s1 < (int)(unsigned)e0)));
                break; (void)((g1 / ((0x4744357du & u3) | 1u)));
                v0 = r0.x;
                if ((unsigned)((short)v0 > (signed char)4u)) goto L0;
            }
            if ((unsigned)(v0 < 0x7fffffffu)) break;
            if (((unsigned)w0 & garr[i1 & 7u])) goto L0;
            if (((1u ^ i1) / (2u | 1u))) goto L4;
            break; (void)((unsigned)(unsigned char)(unsigned)((short)(unsigned)((short)0x40fffc85u > (signed char)garr[i1 & 7u]) > (signed char)u0));
        } else {
            l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)((unsigned)((int)(unsigned)w0 < (int)g1) == (g1 << (p2 & 31u))));
            if ((i0 * g1)) break;
            if (0x80000000u) goto L0;
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    v0 = (unsigned)(unsigned char)(unsigned)(i1 == ~(unsigned)((int)r0.y < (int)((unsigned)d0 * i0)));
    c1 = (signed char)(unsigned)((unsigned)!((unsigned)(x0 >> 70) * (unsigned)(x0 >> 70)) && (unsigned)((short)m0 > (signed char)(unsigned)b0));
    while (i0++ < 3u && ((unsigned)w0 & i0)) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((((unsigned)(unsigned char)(unsigned)((short)i1 > (signed char)u3) >> ((unsigned)b0 & 31u)) % ((unsigned)(9u < (unsigned)w0) | 1u)) & 255u);
        switch ((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)e0) & 7u) {
            break; (void)(((unsigned)(w0 >> 29) - a0[u1 & 3u]));
            g0 = (unsigned)((short)(unsigned)(0x8cbb0dacu || u1) > (signed char)((unsigned)((unsigned)(x0 >> 70) < v0) / (garr[i1 & 7u] | 1u)));
            L1: if (--fuel == 0u) goto done;
        }
        if (g1) break;
        garr[(unsigned)(2u && (unsigned)x0) & 7u] = (unsigned)(unsigned char)(unsigned)((int)((unsigned)w0 & (unsigned)c0) < (int)i0);
        if (budget != 0u) { budget -= 1u; u0 = fn0(~((g1 ^ *q0) << (0u & 31u)), ((unsigned)(x0 >> 70) >> ((unsigned)((int)(unsigned)l0 < (int)0x7fffffffu) & 31u)), 0xbc6b4048u); }
        i0 = ((unsigned)c1 + p0) & 15u;
    }
    do { if (--fuel == 0u) goto done;
        while (i1++ < 5u && ((unsigned)(x0 >> 70) * (0xed4e4475u | *q0))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)s0 < (unsigned)((int)(unsigned)c0 >= (int)(unsigned)(x0 >> 70))), 4u, (i1 % (0xffffffffu | 1u))); }
            g0 = (((unsigned)d0 % (0x10000u | 1u)) % (0x2add566bu | 1u));
            goto L4;
        }
        q0 = &garr[((u3 << (a0[i0 & 3u] & 31u)) | 3u) & 7u];
        if (((unsigned)s0 / ((unsigned)(w0 >> 29) | 1u))) {
            if (3u) goto L4;
            while ((unsigned)(unsigned char)((unsigned)s0 - (unsigned)w0)) { if (--fuel == 0u) goto done;
                L2: if (--fuel == 0u) goto done;
                if (((unsigned)(w0 >> 29) >> (r0.y & 31u))) break;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    while (i0++ < 5u && (i2 * *q0)) { if (--fuel == 0u) goto done;
                        if (u3 == 7u) return r0.y;
                        if ((0xcee39680u % (u0 | 1u))) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)e0) || 0xff7d89aau), i1, garr[i1 & 7u]); }
                        r0.y ^= -(unsigned)((unsigned)h0 == (0xd5e08d54u / (-(unsigned)(3u < a0[u1 & 3u]) | 1u)));
                    }
                    break; (void)(0xc583a547u);
                    goto L1;
                    b0 = (unsigned)(5u && 9u) != 0u;
                    r0.y ^= (unsigned)((unsigned)(unsigned char)((unsigned)!(r0.y >> ((unsigned)s0 & 31u)) * 2u) == (unsigned)((short)fuel > (signed char)v0));
                    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        continue; (void)(((unsigned)s1 + ((unsigned)x0 >> (0x400c02dbu & 31u))));
                        r0.y ^= (unsigned)(unsigned char)((unsigned)d0 - (unsigned)c1);
                    }
                }
                q0 = &garr[(unsigned)((int)(unsigned)(8u == p0) >= (int)((unsigned)l0 / (garr[i1 & 7u] | 1u))) & 7u];
            }
            goto L4;
            L3: if (--fuel == 0u) goto done;
            a0[(unsigned)(0x60ec62e1u < (unsigned)d0) & 3u] = (unsigned)((int)(2u * (unsigned)(x0 >> 70)) >= (int)(unsigned)((short)(unsigned)e0 > (signed char)(p1 / ((unsigned)d0 | 1u))));
            r0.x = (-(p2 ? (unsigned)x0 : (unsigned)s0) & 1u);
        }
        w0 ^= (unsigned long long)(unsigned)((unsigned)(x0 >> 70) < 5u) << ((unsigned)(short)(0x15759886u >> (g1 & 31u)) & 63u);
        *q0 = (unsigned)b0;
        L4: if (--fuel == 0u) goto done;
    } while (i0++ < 5u && ((unsigned)d0 * u2));
    { unsigned t0; double z0; if ((((unsigned)h0 ^ (unsigned)d0)) & 1u) { t0 = (garr[u2 & 7u] ^ fuel); z0 = (double)(((9u ^ (unsigned)c0)) & 255u); } if ((((unsigned)h0 ^ (unsigned)d0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        goto L4;
        g1 += (*mp ? ((unsigned)d0 | r0.x) : (v0 * (unsigned)e0));
        i0 = (unsigned)((int)0x10000u >= (int)p2) & 15u;
        garr[(m0 + (unsigned)w0) & 7u] = ((unsigned)b0 ? 0u : (r0.x & (unsigned)d0));
    }
    l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)(w0 >> 29) < r0.x) | (unsigned)(u3 < i0)));
    if (0x136ce816u) {
        u3 = u3 * 0x9e3779b1u + ((unsigned)((short)3u > (signed char)fuel) ^ (unsigned)(((unsigned)h1 % (0x6ea9b097u | 1u)) || 0x80000000u));
        goto L1;
        if (g0) goto L3;
        if (budget != 0u) { budget -= 1u; u3 = fn0((0x147a1b1cu % ((unsigned)h0 | 1u)), (unsigned)h1, 8u); }
        if ((g1 + p1)) {
            goto L4;
            if ((unsigned)b0) goto L2;
        } else {
            q0 = &garr[(unsigned)(unsigned char)((unsigned)w0 & 0u) & 7u];
            u2 = (0x10000u ? p2 : i0);
            switch (a0[i0 & 3u] & 7u) {
                case 3u: ;
                if (((unsigned)w0 | g0)) goto done;
                u1 += ((unsigned)((short)(*q0 + 2u) > (signed char)u1) / (0x7fffffffu | 1u));
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(signed char)(unsigned)((short)2u > (signed char)u0) << (0x83b115cbu & 31u)), ((unsigned)(short)(unsigned)(0x1ffe6cc2u == 0xfad16c1u) / (i1 | 1u)), ~(u0 >> ((g1 | p1) & 31u))); }
            }
        }
        do { if (--fuel == 0u) goto done;
            if (((unsigned)(0xd247b907u || (unsigned)(w0 >> 29)) & 0x7fffffffu)) goto L0;
            if (((unsigned)s1 | (unsigned)(0x3444f36au < (unsigned)b0))) goto L1;
            if ((*q0 | (unsigned)(x0 >> 70))) break;
            break; (void)(v0);
            h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(unsigned)((int)0xa602313au >= (int)u1));
            i1 = (unsigned)c0 & 15u;
        } while (i0++ < 3u && (0x73c111b3u | (unsigned)!(0xe2bb9f6du & garr[i1 & 7u])));
    }
    if (((unsigned)(unsigned char)(u0 >> (garr[u2 & 7u] & 31u)) + 0x10000u)) goto L4;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)(unsigned)((unsigned)d0 || p0), (a0[i0 & 3u] + 0u), (unsigned)((short)(unsigned)c0 > (signed char)(unsigned)c0)); }
        { unsigned t1; double z1; if ((a0[i0 & 3u]) & 1u) { t1 = (m0 / (6u | 1u)); z1 = (double)(((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)e0)) & 255u); } if ((a0[i0 & 3u]) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            r0.y ^= ((8u >> ((unsigned)c1 & 31u)) - r0.y);
            { unsigned t2; double z2; if ((6u) & 1u) { t2 = (unsigned)b0; z2 = (double)(((unsigned)(signed char)((unsigned)h0 + (p2 + *q0))) & 255u); } if ((6u) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                break; (void)((0x1a76d8eau >> (i0 & 31u)));
                break; (void)((unsigned)!(unsigned)(r0.y || 0x3ca9944cu));
                break; (void)((4u >> (r0.y & 31u)));
                if ((unsigned)(garr[u2 & 7u] && 0u)) continue;
            }
        }
        l0 = (long)((unsigned long)l0 + (unsigned)!(5u - (unsigned)b0));
        i1 = (5u + (unsigned)((int)0x7b200b5cu < (int)(unsigned)(unsigned char)(unsigned)(i0 < (unsigned)b0))) & 15u;
    }
    do { if (--fuel == 0u) goto done;
        { unsigned t3; double z3; if ((u0) & 1u) { t3 = *mp; z3 = (double)(((unsigned)(*mp || (unsigned)(u2 || (unsigned)d0))) & 255u); } if ((u0) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            if ((*mp % (((unsigned)h0 - 0x80000000u) | 1u))) break;
            if ((unsigned)((int)(9u | p1) >= (int)(unsigned)(x0 >> 70))) goto L4;
            d0 = d0 * 0.5 + (double)(((unsigned)!((unsigned)c0 | (unsigned)(signed char)(unsigned)(4u || (m0 << (g0 & 31u)))) & 9u) & 1023u);
            g0 = (unsigned)(signed char)(i0 ? (0x9748c1ceu * (unsigned)b0) : 6u);
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)c1, (unsigned)((int)g0 < (int)0x80000000u), ((unsigned)((unsigned)h1 && (unsigned)s0) + 0u)); }
        }
        if ((unsigned)f0) {
            e0 = e0 * 0.5L + (long double)((2u << (0x7fffffffu & 31u)) & 1023u);
            h1 = (unsigned short)(h1 + 0x4f734771u);
            if ((unsigned)(0x5961ae88u == a0[u1 & 3u])) continue;
        }
    } while (i0++ < 5u && (a0[i0 & 3u] - (unsigned)c0));
    do { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (unsigned)!((unsigned)w0 * ((unsigned)((int)(unsigned)(garr[i1 & 7u] < fuel) >= (int)(unsigned)c1) << (i0 & 31u)));
        if ((unsigned)(2u || i1)) break;
        if ((unsigned)((int)((unsigned)h0 ^ a0[i0 & 3u]) < (int)a0[i0 & 3u])) goto L0;
    } while (i0++ < 4u && (unsigned)((int)0x7fffffffu >= (int)0x1a723603u));
    if ((0x5f5e1ab8u % (((unsigned)h0 + i1) | 1u))) goto L4;
    if (i2) goto done;
    switch ((unsigned)((short)6u > (signed char)(garr[i1 & 7u] % ((unsigned)f0 | 1u))) & 7u) {
        while ((i1 << (r0.y & 31u))) { if (--fuel == 0u) goto done;
            h0 = (short)(r0.x + (unsigned)((short)*q0 > (signed char)0x10000u));
            while ((unsigned)(0xffffffffu < (i1 + u3))) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    q0 = &garr[(unsigned)((unsigned)b0 || 0xd315109du) & 7u];
                    switch (0xa65399a8u & 7u) {
                        if (budget != 0u) { budget -= 1u; u2 = fn0((a0[u1 & 3u] * ((unsigned)c0 & p2)), (unsigned)((int)r0.x >= (int)(unsigned)((short)0x7fffffffu > (signed char)(unsigned)h0)), ((fuel / ((unsigned)x0 | 1u)) << ((unsigned)c0 & 31u))); }
                    }
                    case 0u: ;
                    if (u3 == 7u) return (unsigned)((unsigned)s1 || 0x10000u);
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)w0 + (unsigned)(m0 == 7u)), (0x80000000u & (0x49653051u + *q0)), a0[u1 & 3u]); }
                s0 = (int)(unsigned)(fuel < (unsigned)w0);
                s0 = (int)(unsigned)((unsigned)!(unsigned)((unsigned)w0 || garr[u2 & 7u]) || ((unsigned)c1 - 9u));
            }
        }
        if ((unsigned)s1) goto L1;
        s1 = (int)((unsigned)s1 + (unsigned)(0x80000000u < (unsigned)e0));
    }
    while (i0++ < 3u && (unsigned)((short)(p0 % ((unsigned)h0 | 1u)) > (signed char)0xd8b99dd6u)) { if (--fuel == 0u) goto done;
        u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)h0 < (unsigned)e0);
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)s0 & (unsigned)((int)(unsigned)f0 < (int)0x9bdaeffau))) {
                w0 ^= (unsigned long long)2u << ((unsigned)((short)(0x10000u % (0xffffffffu | 1u)) > (signed char)r0.x) & 63u);
                v0 = ((unsigned)d0 ^ ((g0 >> (~((unsigned)(w0 >> 29) ^ p2) & 31u)) >> ((unsigned)c0 & 31u)));
            }
            if (-(unsigned)((unsigned)(x0 >> 70) == (unsigned)((int)fuel < (int)0x10000u))) {
                w0 = w0 * 6364136223846793005ull + (p1 % (((unsigned)(signed char)(r0.x ^ 6u) - 0x10000u) | 1u));
            } else {
                break; (void)((unsigned)((unsigned)(w0 >> 29) < (unsigned)s1));
            }
            if ((unsigned)((int)(1u % (p1 | 1u)) < (int)0x7fffffffu)) break;
            if (budget != 0u) { budget -= 1u; u0 = fn0((v0 + (6u / ((unsigned)l0 | 1u))), -(unsigned)(*mp || 0x7fffffffu), (unsigned)((unsigned)(x0 >> 70) == 4u)); }
            if (~(unsigned)(p2 || 0xd6ed832bu)) break;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0(u0, (unsigned)((int)i0 >= (int)(unsigned)e0), (((unsigned)x0 / (v0 | 1u)) ^ (unsigned)s1)); }
        g1 += (*q0 ^ *q0);
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0(u3, i2, (m0 ^ garr[u2 & 7u])); }
            if ((0x5fe4e4b9u ^ r0.y)) break;
            u3 += (unsigned)((0xb999a476u - u1) == (unsigned)(0x7fffffffu && (unsigned)(w0 >> 29)));
            w0 = w0 * 6364136223846793005ull + ((a0[u1 & 3u] / (i0 | 1u)) + (0xa85a1c94u + ((unsigned)(w0 >> 29) * i0)));
            u2 = garr[i1 & 7u];
            u1 = (8u & (p0 - 4u));
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((i2 << (0xf30283f8u & 31u)), (unsigned)(*mp || (unsigned)(0x7fffffffu == fuel)), ((a0[u1 & 3u] - 0xe9a5320bu) * (unsigned)x0)); }
    if ((unsigned)((int)6u < (int)(unsigned)(m0 || r0.x))) goto L4;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)x0 < (int)a0[u1 & 3u]), ~(p0 & ((unsigned)e0 + 0xee73f68au)), ((unsigned)x0 * (0x3ff86244u + g1))); }
        l0 = (long)((unsigned long)l0 + (unsigned)(u1 < u2));
        if ((g0 ? 1u : (unsigned)s1)) {
            w0 ^= (unsigned long long)p0 << (((unsigned)((int)u2 >= (int)(unsigned)f0) ? *mp : (unsigned)(w0 >> 29)) & 63u);
            c0 = (unsigned char)(unsigned)((int)(unsigned)((short)0x62a67401u > (signed char)((unsigned)d0 ^ (unsigned)h1)) < (int)0xffffffffu);
            w0 = w0 * 6364136223846793005ull + (unsigned)(*mp || (0x10000u % ((unsigned)(x0 >> 70) | 1u)));
            break; (void)((u0 - 0x49461a0fu));
        }
        if (p2) {
            h0 = (short)(unsigned)!((unsigned)(g0 < 0u) * (p0 - 6u));
            switch (((unsigned)w0 * p1) & 7u) {
                if (((unsigned)c0 - (*q0 / (u2 | 1u)))) {
                    h1 = (unsigned short)(h1 + (((unsigned)h0 | (0x7fffffffu / (~(unsigned)((int)*mp >= (int)0u) | 1u))) | (unsigned)s0));
                    f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)((int)p0 < (int)5u) < (int)garr[i1 & 7u]) & 255u);
                } else {
                    s1 = (int)((unsigned)s1 + (unsigned)(signed char)(unsigned)(0x65168885u && g0));
                    b0 = ((fuel & p1) >> (p1 & 31u)) != 0u;
                    case 0u: ;
                    case 3u: ;
                }
            }
        }
        if ((unsigned)(8u || p0)) {
            e0 = e0 * 0.5L + (long double)(((unsigned)s0 % ((unsigned)!(-((unsigned)h1 + p1) / ((unsigned)(x0 >> 70) | 1u)) | 1u)) & 1023u);
            c1 = (signed char)u2;
        } else {
            break; (void)((0x80000000u ^ (a0[i0 & 3u] << (g1 & 31u))));
            h0 = (short)((unsigned)((short)i2 > (signed char)u0) * g1);
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)c0 - (m0 >> (0x10000u & 31u))), (unsigned)(r0.y && (unsigned)(unsigned char)(unsigned)((unsigned)(x0 >> 70) || fuel)), (unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)a0[u1 & 3u] < (int)*q0) >= (int)0x10000u)); }
            q0 = &garr[(unsigned)(short)((unsigned)((short)(unsigned)((int)0x75e26afcu >= (int)(unsigned)h1) > (signed char)(unsigned)s0) - (0x80000000u % (0x1b5fc6a5u | 1u))) & 7u];
        }
    }
    u3 += (unsigned)((0x7fffffffu % ((0xf6dd83e7u >> ((unsigned)h0 & 31u)) | 1u)) && ((unsigned)e0 << (u3 & 31u)));
    switch ((unsigned)(m0 < ((unsigned)s0 & r0.y)) & 7u) {
        e0 = e0 * 0.5L + (long double)(((unsigned)(short)(unsigned)(0xb3ecbbeeu < 0x80000000u) | garr[u2 & 7u]) & 1023u);
        if ((unsigned)((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)s1) || 6u)) {
            b0 = (0u & 0x8db6fe31u) != 0u;
            if ((unsigned)x0) goto L3;
            if (budget != 0u) { budget -= 1u; u1 = fn0(r0.y, (unsigned)((short)(unsigned)((short)g1 > (signed char)(unsigned)e0) > (signed char)0x22d726bbu), (0xfdffb4bdu << (6u & 31u))); }
        } else {
            h0 = (short)(unsigned)(m0 == (*mp & (unsigned)e0));
        }
        { unsigned t4; double z4; if (((0x10000u % ((r0.x | *mp) | 1u))) & 1u) { t4 = p2; z4 = (double)(((0x52ce380au | (u1 + r0.x))) & 255u); } if (((0x10000u % ((r0.x | *mp) | 1u))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
            v0 = ~((unsigned)c0 | i1);
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)!(unsigned)((a0[u1 & 3u] ^ v0) || (unsigned)h0)) goto L0;
                if ((unsigned)(short)(0x7fffffffu & (unsigned)f0)) break;
                h0 = (short)(fuel & (unsigned)((int)*q0 >= (int)(unsigned)(x0 >> 70)));
                l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(i1 || (unsigned)l0) || (unsigned)f0));
                case 7u: ;
                if ((unsigned)c0) continue;
            }
            r0.y ^= ((a0[i0 & 3u] ^ (unsigned)e0) >> ((unsigned)c0 & 31u));
        }
    }
    if ((unsigned)(x0 >> 70)) {
        r0.y ^= (unsigned)((unsigned)(signed char)(9u - u2) < 0x91f08cd8u);
        if ((u3 * v0)) goto L2;
        switch ((u1 % (0u | 1u)) & 7u) {
            v0 = (unsigned)((unsigned)(g0 == v0) < (unsigned)c1);
            case 7u: ;
            case 2u: ;
            garr[(garr[i1 & 7u] * 0x8e80dc8u) & 7u] = ~(unsigned)((unsigned)(w0 >> 29) || 0xeb7260cdu);
            x0 = x0 * 0x100000001b3ull + (unsigned)x0;
        }
        if (((unsigned)h1 | 0x36383570u)) goto done;
    }
    g0 = (unsigned)((unsigned)(a0[u1 & 3u] || 0xbd63d0a0u) < (9u ^ 0xffffffffu));
    if ((unsigned)(8u || (unsigned)l0)) goto done;
    r0.x = (i0 & (unsigned)(0xffffffffu && ((unsigned)f0 - (unsigned)d0)));
    if ((i1 | (unsigned)(0xccc84efu == u0))) goto L0;
    *mp = (unsigned)((int)(unsigned)s0 < (int)r0.x);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    f0 = f0 * 0.5f + (float)((unsigned)(~(unsigned)((int)0x7fffffffu < (int)0xf4c0ac52u) || (unsigned)((unsigned)d0 < (unsigned)d0)) & 255u);
    l0 = (long)((unsigned long)l0 + ((unsigned)(short)((unsigned)(w0 >> 29) & 0x8d2b6bf0u) >> ((unsigned)(u1 && 0x7fffffffu) & 31u)));
    x0 = x0 * 0x100000001b3ull + ((unsigned)c1 % ((unsigned)((p1 % (a0[i0 & 3u] | 1u)) && (a0[u1 & 3u] - r0.x)) | 1u));
    a0[(unsigned)(unsigned char)(5u & 8u) & 3u] = 0x10000u;
    if (budget != 0u) { budget -= 1u; u1 = fn1((g0 % (7u | 1u)), (unsigned)((unsigned)h0 || g1), (unsigned)((unsigned)((int)i2 >= (int)(unsigned)f0) || 0x10000u)); }
    r0.x = ((unsigned)l0 << (0x7f58a06au & 31u));
    { unsigned t0; double z0; if ((i1) & 1u) { t0 = (unsigned)((int)4u >= (int)(*q0 | (unsigned)(w0 >> 29))); z0 = (double)(((unsigned)l0) & 255u); } if ((i1) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        L0: if (--fuel == 0u) goto done;
        if ((unsigned)!(0xffffffffu ^ r0.y)) goto L2;
        switch ((unsigned)((int)a0[i0 & 3u] >= (int)0xea2fe63u) & 7u) {
            L1: if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + ((0x277dac6au << (0x7fffffffu & 31u)) ? *q0 : (unsigned)w0));
        }
    }
    i0 = (unsigned)((int)(unsigned)((unsigned)(short)(0xc88d2e5cu >> (g0 & 31u)) < i1) < (int)((unsigned)h0 * 0x46b91a3cu)) & 15u;
    g0 = (unsigned)c0;
    u2 = a0[i0 & 3u];
    for (;;) { if (--fuel == 0u) goto done;
        switch ((unsigned)((short)(unsigned)((int)fuel < (int)0x10000u) > (signed char)p1) & 7u) {
            if ((unsigned)((unsigned)(w0 >> 29) && (unsigned)(6u || u0))) goto L4;
            if ((garr[u2 & 7u] / ((unsigned)((unsigned)w0 || 0xf7362fe4u) | 1u))) goto L1;
            u1 = (i0 & (unsigned)l0);
            garr[(unsigned)((short)u2 > (signed char)*q0) & 7u] = ((unsigned)(unsigned char)(unsigned)((short)v0 > (signed char)(((unsigned)s0 ^ a0[u1 & 3u]) / ((unsigned)l0 | 1u))) + (unsigned)c0);
            if (budget != 0u) { budget -= 1u; u3 = fn1(8u, ((unsigned)c0 + (unsigned)(u1 && (unsigned)c0)), ((unsigned)((int)0xd7924d24u < (int)(unsigned)h0) - 7u)); }
            *q0 += ((unsigned)((unsigned)h0 && 0x5daa7d38u) / (p1 | 1u));
        }
    }
    L2: if (--fuel == 0u) goto done;
    if (((unsigned)(*q0 || 0x10000u) - g1)) goto L0;
    for (;;) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((r0.y % ((unsigned)(unsigned char)((unsigned)(a0[u1 & 3u] == u1) + (unsigned)d0) | 1u)) & 255u);
    }
    L3: if (--fuel == 0u) goto done;
    w0 ^= (unsigned long long)(unsigned)d0 << (p2 & 63u);
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((int)(unsigned)d0 < (int)3u) + r0.x), 0x80000000u, ((unsigned)b0 / ((unsigned)(x0 >> 70) | 1u))); }
    L4: if (--fuel == 0u) goto done;
    if ((unsigned)((0x10000u + 0u) || 4u)) goto L3;
    do { if (--fuel == 0u) goto done;
        g0 = ((*mp + r0.x) * (r0.y + g0));
        g0 = ((g0 / (0x80000000u | 1u)) >> (garr[i1 & 7u] & 31u));
        do { if (--fuel == 0u) goto done;
            if (u3 == 7u) return *mp;
            *q0 += (4u >> (v0 & 31u));
            break; (void)(((unsigned)d0 >> ((unsigned)(signed char)(u2 - 0x193c08deu) & 31u)));
            if (m0) {
                if ((unsigned)(a0[i0 & 3u] || (unsigned)x0)) break;
            }
        } while (i1++ < 3u && (unsigned)((short)7u > (signed char)~(unsigned)((unsigned)c0 == (unsigned)b0)));
    } while (i0++ < 5u && (unsigned)((int)r0.x >= (int)(unsigned)(w0 >> 29)));
    goto L1;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 += (unsigned)((int)u1 >= (int)-(((unsigned)((int)0xb71adee5u < (int)g0) << (6u & 31u)) << ((unsigned)s0 & 31u)));
        d0 = d0 * 0.5 + (double)(((unsigned)b0 & (p0 << (u2 & 31u))) & 1023u);
        while (i1++ < 7u && (0x2711766cu >> (1u & 31u))) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)g0 << ((unsigned)s0 & 63u);
        }
        x0 = x0 * 0x100000001b3ull + ((unsigned)(garr[i1 & 7u] || (unsigned)s1) | (unsigned)(0x10000u && 5u));
        { unsigned t1; double z1; if (((unsigned)s0) & 1u) { t1 = ((unsigned)(w0 >> 29) + (unsigned)(i1 < (unsigned)b0)); z1 = (double)(((unsigned)s1) & 255u); } if (((unsigned)s0) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            q0 = &garr[(unsigned)((int)v0 < (int)(2u << (p0 & 31u))) & 7u];
            g0 = (((unsigned)h1 >> (0x50670098u & 31u)) ^ u2);
            if (budget != 0u) { budget -= 1u; u2 = fn1((p0 - (unsigned)l0), (unsigned)((short)(unsigned)(0xfced389du < i2) > (signed char)r0.y), 0xffffffffu); }
        }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0(0xe0fa0ad9u, (unsigned)(x0 >> 70), -((0x68817f48u / (0x10000u | 1u)) % ((unsigned)h0 | 1u))); }
    h1 = (unsigned short)(h1 + ((unsigned)((short)0x59514650u > (signed char)0xade85c27u) ? 0xbc0d364cu : (unsigned)h1));
    if ((unsigned)((unsigned)f0 == garr[i1 & 7u])) goto L2;
    if ((0xdee1e748u & (0x80000000u | 0x10000u))) goto L4;
    r0.x = ((unsigned)c1 * 0x843c3365u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (-(unsigned)((unsigned)e0 == (unsigned)e0)) goto L4;
    do { if (--fuel == 0u) goto done;
        switch ((unsigned)h1 & 7u) {
            *q0 = (fuel << ((r0.x - (unsigned)(short)(0x59d13907u - r0.y)) & 31u));
            c0 = (unsigned char)(unsigned)(short)(unsigned)((0x18132167u / ((0x54f12837u - 8u) | 1u)) < (unsigned)((short)7u > (signed char)(unsigned)s0));
        }
        goto L0;
        *q0 += ((unsigned)x0 & g1);
        if ((0x7fffffffu - (fuel >> (0xaa6b745cu & 31u)))) {
            q0 = &garr[(0xfc0fa1a3u * u0) & 7u];
            if ((unsigned)(x0 >> 70)) break;
            if (budget != 0u) { budget -= 1u; u0 = fn1((p2 - 8u), (i2 ? garr[i1 & 7u] : r0.x), u3); }
            if (((unsigned)e0 >> ((unsigned)!(unsigned)((int)garr[i1 & 7u] >= (int)v0) & 31u))) goto L0;
            m0 ^= (unsigned)b0;
            u3 += (~(unsigned)((int)(unsigned)h0 >= (int)v0) & (unsigned)x0);
        } else {
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((int)0x10000u >= (int)0x10000u), garr[u2 & 7u], (unsigned)((int)fuel < (int)(0x80000000u & (unsigned)l0))); }
        }
    } while (i0++ < 2u && ((i1 * 5u) & *mp));
    w0 ^= (unsigned long long)(unsigned)((int)g0 >= (int)garr[i1 & 7u]) << (i0 & 63u);
    u0 ^= -((unsigned)((short)p1 > (signed char)(unsigned)s1) - (unsigned)s0);
    *mp = (unsigned)(r0.y == (unsigned)x0);
    g0 = (unsigned)((unsigned)((int)i0 < (int)i0) && fuel);
    switch ((unsigned)((int)p1 < (int)g0) & 7u) {
        case 6u: ;
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((0x10000u & 0xadf2a8b7u)) break;
            h1 = (unsigned short)(h1 + ((unsigned)e0 & (unsigned)h0));
            if (budget != 0u) { budget -= 1u; u1 = fn0(garr[u2 & 7u], 0x89d337eu, ((unsigned)s1 - 0xffffffffu)); }
        }
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)h1 == *mp), (unsigned)(v0 || (unsigned)e0), (unsigned)((unsigned)c0 < u1)); }
            if (0x74f1a24fu) {
                do { if (--fuel == 0u) goto done;
                    u3 = u3 * 0x9e3779b1u + 4u;
                    if ((0x9248d68cu - (unsigned)(short)(unsigned)(g0 || g1))) break;
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn2(fuel, (i1 ? p1 : garr[u2 & 7u]), a0[u1 & 3u]); }
                        m0 ^= ((u1 | a0[i0 & 3u]) / ((unsigned)((i1 & (unsigned)l0) == 3u) | 1u));
                        v0 = (u3 % (0xd79ec6d6u | 1u));
                        switch (((unsigned)(x0 >> 70) | (unsigned)(0x10000u == u2)) & 7u) {
                            w0 ^= (unsigned long long)garr[u2 & 7u] << (m0 & 63u);
                            c0 = (unsigned char)(unsigned)((p1 & p0) < garr[u2 & 7u]);
                            if (fuel < 8u) return (unsigned)(((0x133ed5e4u + i0) % ((unsigned)c1 | 1u)) && (unsigned)((short)u3 > (signed char)(unsigned)(x0 >> 70)));
                        }
                    }
                    switch ((unsigned)(6u == i1) & 7u) {
                        L0: if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)((unsigned)s0 & 1023u);
                    }
                    h0 = (short)((unsigned)(0xffffffffu == (unsigned)!(unsigned)(2u == 0x58f7408fu)) >> (((unsigned)c1 | (unsigned)s0) & 31u));
                } while (i2++ < 5u && a0[i0 & 3u]);
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)((int)(unsigned)f0 < (int)(unsigned)c0) || u1), (garr[u2 & 7u] ^ *mp), (unsigned)((short)0xaa0a510au > (signed char)(unsigned)((short)(unsigned)c0 > (signed char)g0))); }
                if (budget != 0u) { budget -= 1u; u3 = fn2(~(unsigned)(7u < ~(0xffffffffu / (0x10000u | 1u))), ((unsigned)x0 * 0xea8fe7a0u), (unsigned)(r0.x < (*q0 * (unsigned)(w0 >> 29)))); }
            } else {
                h0 = (short)((unsigned)(0xffffffffu == u0) * (unsigned)(short)(unsigned)((int)i2 >= (int)(0u & (unsigned)w0)));
                if (budget != 0u) { budget -= 1u; u0 = fn2(r0.y, ~(0x45504e50u / ((unsigned)c0 | 1u)), (u3 - i2)); }
                if ((0xffffffffu >> (*q0 & 31u))) break;
                if (budget != 0u) { budget -= 1u; u1 = fn1(g1, ((unsigned)w0 / ((unsigned)x0 | 1u)), ((unsigned)d0 | u3)); }
            }
        } while (i1++ < 2u && ((unsigned)x0 * (unsigned)d0));
        do { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(i0 ^ i0) << (((unsigned)(0xffffffffu == 0x80000000u) >> (0xffffffffu & 31u)) & 63u);
            h0 = (short)*mp;
        } while (i1++ < 5u && 0x2d835e69u);
        f0 = f0 * 0.5f + (float)((unsigned)!(p2 ^ (((unsigned)c1 & 0x7fffffffu) | (0xb4f1b1aeu % (0x80000000u | 1u)))) & 255u);
    }
    v0 = (unsigned)((-(1u / ((unsigned)c0 | 1u)) / (0x10000u | 1u)) == (r0.x + 2u));
    if (fuel < 8u) return -(unsigned)(*q0 < ((fuel ^ (unsigned)h1) ? a0[u1 & 3u] : 0x3a7c2580u));
    L1: if (--fuel == 0u) goto done;
    s1 = (int)((unsigned)s1 + (0x80000000u + (4u ? 0x7fffffffu : 0x1387528eu)));
    g1 += (unsigned)((short)p2 > (signed char)p1);
    m0 ^= (9u + (unsigned)c1);
    L2: if (--fuel == 0u) goto done;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)f0 < (unsigned)((short)(unsigned)s0 > (signed char)(unsigned)x0)), ((unsigned)b0 ^ (fuel | i2)), (unsigned)((int)i1 < (int)(fuel >> (0x7fffffffu & 31u)))); }
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        L3: if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (p1 | ((unsigned)f0 << (p2 & 31u)));
            L4: if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if (0x5da6e9b7u) break;
                if (((unsigned)(w0 >> 29) + *mp)) continue;
                while (i0++ < 6u && 5u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)((int)0x10000u >= (int)(unsigned)w0))) goto L3;
                    f0 = f0 * 0.5f + (float)(((unsigned)(a0[u1 & 3u] == u0) / ((unsigned)(5u == 4u) | 1u)) & 255u);
                    *q0 = (i2 << ((unsigned)d0 & 31u));
                    if ((unsigned)d0) break;
                    r0.y ^= u1;
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)(unsigned char)(unsigned)((int)(unsigned)h0 < (int)(v0 * g1)) == 0u));
                }
                w0 = w0 * 6364136223846793005ull + (i1 * (0x5b2cf1e0u % ((unsigned)s1 | 1u)));
                if ((unsigned)c0) {
                    v0 = (unsigned)!(r0.y - i2);
                } else {
                    u0 = (0x9cb56588u | (unsigned)((unsigned)d0 < *mp));
                    h1 = (unsigned short)(h1 + ((unsigned)(0xc55068a0u < (0xffffffffu % ((unsigned)w0 | 1u))) % (((unsigned)h1 - a0[i0 & 3u]) | 1u)));
                    { unsigned t0; double z0; if (((unsigned)((int)a0[i0 & 3u] < (int)0x7fffffffu)) & 1u) { t0 = (unsigned)((int)(0x3bffb76u << ((unsigned)d0 & 31u)) >= (int)0xb0bf9a34u); z0 = (double)((p1) & 255u); } if (((unsigned)((int)a0[i0 & 3u] < (int)0x7fffffffu)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                        if (garr[i1 & 7u]) break;
                    }
                    g1 += (i0 << (5u & 31u));
                }
            } while (i2++ < 5u && (unsigned)!(unsigned)((unsigned)((short)u3 > (signed char)(unsigned)b0) == i1));
            if (*q0) break;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0(r0.x, (unsigned)(m0 && (unsigned)(signed char)(unsigned)(p1 || 7u)), (unsigned)e0); }
    }
    goto L0;
    if ((unsigned)((7u + (unsigned)(x0 >> 70)) || (unsigned)f0)) goto L3;
    if ((u2 - garr[i1 & 7u])) {
        if ((g0 << (0xdb5535dfu & 31u))) goto L2;
        while (((unsigned)((unsigned)(w0 >> 29) == garr[i1 & 7u]) ^ u1)) { if (--fuel == 0u) goto done;
            r0.y ^= (0x80000000u / ((unsigned)s0 | 1u));
            if ((unsigned)(signed char)(unsigned)((unsigned)((unsigned)h1 == 0x10000u) || u0)) break;
            s1 = (int)((unsigned)s1 + (g1 | p0));
        }
        m0 ^= ((unsigned)d0 * g0);
        r0.x = (unsigned)((int)(unsigned)((short)(unsigned)c0 > (signed char)0xffffffffu) >= (int)u1);
    }
    if ((unsigned)((int)*q0 >= (int)i1)) goto L4;
    a0[(unsigned)(short)((unsigned)c0 + (unsigned)s1) & 3u] = (unsigned)(u3 < ((unsigned)(unsigned char)(a0[u1 & 3u] / ((unsigned)c1 | 1u)) << ((unsigned)(signed char)((unsigned)(x0 >> 70) & *mp) & 31u)));
    if (p0) goto L0;
    if (((unsigned)h1 & a0[u1 & 3u])) goto L1;
    if (0xbd8cb35au) goto L3;
    if (-((unsigned)e0 - *q0)) goto L2;
    garr[v0 & 7u] = ((unsigned)(signed char)((0x7fffffffu / (0x6b5e6036u | 1u)) & (unsigned)l0) / (r0.y | 1u));
    if ((unsigned)(unsigned char)(*q0 ^ p0)) {
        for (;;) { if (--fuel == 0u) goto done;
            if (-(unsigned)((int)0x830b8b15u >= (int)p0)) break;
        }
    } else {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)(unsigned)(garr[i1 & 7u] || 0xffffffffu) > (signed char)(unsigned)h1)) goto L2;
            *q0 = (unsigned)((short)0xa1ca4f3eu > (signed char)(unsigned)((int)g1 < (int)(garr[i1 & 7u] * (1u * fuel))));
            while (i1++ < 6u && (unsigned)(garr[i1 & 7u] && ((unsigned)w0 / (v0 | 1u)))) { if (--fuel == 0u) goto done;
                if ((i1 * 2u)) break;
                if (((0x80000000u - i2) % (0x7fffffffu | 1u))) break;
            }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn2((0xffffffffu << (p0 & 31u)), (unsigned)!((unsigned)x0 >> ((unsigned)e0 & 31u)), 0xffffffffu); }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)(w0 >> 29) + 7u), (unsigned)s1, (unsigned)((short)u1 > (signed char)i2)); }
    *mp = (unsigned)((unsigned)(unsigned char)(unsigned)((0x7fffffffu % (*mp | 1u)) == 0xa214c903u) < 0u);
    for (;;) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)(r0.x & 1023u);
    }
    if (0xb8cc4c7eu) {
        if ((unsigned)c1) goto done;
        c1 = (signed char)(unsigned)f0;
        goto L1;
        if (budget != 0u) { budget -= 1u; u1 = fn0((g1 * (0xffffffffu - i1)), ((unsigned)d0 << (garr[i1 & 7u] & 31u)), (unsigned)s0); }
    }
    while ((unsigned)(signed char)(unsigned)((unsigned)(x0 >> 70) == (r0.x + 0x9ffb5596u))) { if (--fuel == 0u) goto done;
        switch ((unsigned)((int)5u < (int)v0) & 7u) {
            switch ((unsigned)c0 & 7u) {
                if ((unsigned)((int)((unsigned)w0 ^ 5u) < (int)(unsigned)h0)) {
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        u2 = (0x4cfa6b7du + 0xefed511eu);
                    }
                    v0 = ((unsigned)((unsigned)x0 && 0x80000000u) % ((unsigned)b0 | 1u));
                    r0.x = (u3 << ((unsigned)(signed char)(4u - *q0) & 31u));
                    h0 = (short)(a0[u1 & 3u] | (unsigned)(unsigned char)(unsigned)((short)(2u | 0x10000u) > (signed char)garr[i1 & 7u]));
                    c0 = (unsigned char)((unsigned)x0 / ((unsigned)d0 | 1u));
                    *q0 += (p1 / (garr[u2 & 7u] | 1u));
                }
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t1; double z1; if ((garr[i1 & 7u]) & 1u) { t1 = (unsigned)!(unsigned)(i2 || 9u); z1 = (double)(((r0.y / ((unsigned)l0 | 1u))) & 255u); } if ((garr[i1 & 7u]) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                        u2 ^= (u1 >> (((unsigned)f0 / ((unsigned)(x0 >> 70) | 1u)) & 31u));
                        case 7u: ;
                        case 3u: ;
                        case 5u: ;
                        if (((unsigned)w0 ? *q0 : 5u)) continue;
                        u2 = 0x7fffffffu;
                    }
                    if (0xd07b5c95u) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn2(0x8b3df0e7u, (0x86a775e5u ^ (unsigned)(1u == 0x36ace6bau)), (u3 >> ((unsigned)d0 & 31u))); }
                }
                u3 = ~(unsigned)((int)((unsigned)((int)0x80000000u < (int)garr[u2 & 7u]) << (0x7fffffffu & 31u)) < (int)(unsigned)h1);
                if (fuel < 8u) return ((unsigned)((int)0xed0eb0a9u >= (int)(unsigned)c1) ^ (unsigned)(0x10000u < 1u));
                default: ;
            }
            case 0u: ;
        }
        { unsigned t2; double z2; if (((unsigned)(x0 >> 70)) & 1u) { t2 = (unsigned)b0; z2 = (double)((a0[i0 & 3u]) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            if ((unsigned)((int)(g1 + 1u) < (int)i2)) continue;
        }
        continue; (void)((unsigned)(signed char)(unsigned)((int)r0.x >= (int)(unsigned)(garr[u2 & 7u] && i2)));
    }
    switch ((unsigned)((int)(0xffffffffu << ((unsigned)x0 & 31u)) >= (int)m0) & 7u) {
        g0 = (unsigned)(x0 >> 70);
        if ((unsigned)(short)(unsigned)((unsigned)c0 < garr[u2 & 7u])) {
            { unsigned t3; double z3; if (((unsigned)((int)0xfacaae34u < (int)1u)) & 1u) { t3 = 0x7fffffffu; z3 = (double)((a0[i0 & 3u]) & 255u); } if (((unsigned)((int)0xfacaae34u < (int)1u)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                x0 = x0 * 0x100000001b3ull + ((unsigned)b0 ^ a0[u1 & 3u]);
                case 3u: ;
            }
        }
        e0 = e0 * 0.5L + (long double)(((unsigned)f0 | (unsigned)(((unsigned)(w0 >> 29) % (p0 | 1u)) == i2)) & 1023u);
        q0 = &garr[(unsigned)(u2 || ((unsigned)e0 ? u1 : *mp)) & 7u];
        e0 = e0 * 0.5L + (long double)((0x34b8290eu << (u2 & 31u)) & 1023u);
    }
    s1 = (int)((unsigned)s1 + (u3 << ((r0.x % (*mp | 1u)) & 31u)));
    goto L2;
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)d0 | 5u), (unsigned)h0, (unsigned)((short)fuel > (signed char)(unsigned)(signed char)(unsigned)((unsigned)x0 == garr[u2 & 7u]))); }
    goto L3;
    b0 = ((i2 | (unsigned)(w0 >> 29)) - -(unsigned)(i1 == (u2 >> (u1 & 31u)))) != 0u;
    goto L4;
    v0 = (unsigned)((short)(unsigned)(unsigned char)((2u | (unsigned)l0) ? (unsigned)e0 : i1) > (signed char)(unsigned)c1);
    if ((p1 % ((unsigned)(u3 < 0xda5a32d1u) | 1u))) goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        *mp = (unsigned)((unsigned)(7u || 6u) && ((i2 << ((unsigned)s1 & 31u)) | garr[u2 & 7u]));
        *q0 = 0xffffffffu;
        i1 = (unsigned)((unsigned)((short)v0 > (signed char)*q0) || (unsigned)e0) & 15u;
    } while (i0++ < 7u && (unsigned)f0);
    m0 ^= (unsigned)(u1 || (i2 << (u1 & 31u)));
    e0 = e0 * 0.5L + (long double)((((unsigned)f0 << (0x10000u & 31u)) << ((unsigned)(w0 >> 29) & 31u)) & 1023u);
    if ((unsigned)(short)(unsigned)((r0.x / (g1 | 1u)) && (unsigned)l0)) goto L2;
    if ((i0 & r0.y)) goto L2;
    if ((unsigned)(r0.x == (unsigned)(u1 || u0))) goto L3;
    if (((unsigned)(short)(unsigned)(fuel < 7u) / (0x15fbc382u | 1u))) goto L0;
    while (((unsigned)((unsigned)x0 || g0) + *mp)) { if (--fuel == 0u) goto done;
        while (i1++ < 7u && ((unsigned)h1 << (0x80000000u & 31u))) { if (--fuel == 0u) goto done;
            u0 ^= (unsigned)((int)(unsigned)b0 < (int)(unsigned)(0xc0c9a7f6u < (unsigned)s0));
            while (i2++ < 7u && (unsigned)((short)u2 > (signed char)(unsigned)s1)) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    m0 ^= ((unsigned)(unsigned char)(unsigned)(a0[u1 & 3u] == -(unsigned)(0x367def5u < u0)) << (a0[u1 & 3u] & 31u));
                    if ((unsigned)d0) {
                        m0 ^= -(0x969f5c60u ? ((unsigned)(unsigned char)(unsigned)(0x80000000u == u0) + a0[i0 & 3u]) : u0);
                    }
                    *q0 = (4u ^ (unsigned)((unsigned)((int)(garr[i1 & 7u] << (r0.x & 31u)) < (int)i0) < (unsigned)(w0 >> 29)));
                    goto L1;
                    f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)((unsigned)l0 & ((unsigned)l0 % ((unsigned)h1 | 1u))) & 255u);
                    if (garr[u2 & 7u]) goto done;
                } while (i0++ < 7u && (unsigned)s1);
                if (((unsigned)(x0 >> 70) % (p2 | 1u))) break;
            }
            a0[0xe7dd659du & 3u] = (-(unsigned)(0xbc3fec04u && (5u / (0x80000000u | 1u))) ^ (unsigned)((int)0xad60b8ceu >= (int)0xc0db549eu));
            r0.x = (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)c1);
            g0 = (unsigned)!(unsigned)(((unsigned)x0 % (r0.y | 1u)) < (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)g1));
            u2 = u2 * 0x9e3779b1u + (unsigned)(x0 >> 70);
        }
        goto L3;
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(r0.x * ((unsigned)e0 << (0x4075916eu & 31u)));
        if ((u0 ^ g1)) break;
        b0 = (unsigned)(unsigned char)(unsigned)(u3 || 0x80000000u) != 0u;
    }
    *q0 += (garr[i1 & 7u] % (9u | 1u));
    *q0 = (a0[u1 & 3u] * (unsigned)s1);
    if (budget != 0u) { budget -= 1u; u2 = fn2(0x2c5cf433u, (unsigned)s0, ((unsigned)(w0 >> 29) - (unsigned)x0)); }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        q0 = &garr[(a0[i0 & 3u] ? (unsigned)((short)r0.x > (signed char)garr[i1 & 7u]) : 9u) & 7u];
        if (((i2 + 4u) >> (4u & 31u))) break;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (0xffffffffu) {
                *mp = ((unsigned)((int)0x7501642du >= (int)0x80000000u) << ((unsigned)((int)i0 < (int)((unsigned)c1 & (unsigned)(x0 >> 70))) & 31u));
                u1 = u1 * 0x9e3779b1u + garr[i1 & 7u];
                if (budget != 0u) { budget -= 1u; u3 = fn1((*q0 + (0xffffffffu + 0x8c1bfa29u)), v0, (unsigned)(signed char)(unsigned)((unsigned)w0 && (unsigned)((short)(unsigned)s1 > (signed char)0x10000u))); }
            } else {
                q0 = &garr[(unsigned)((int)(0x7fffffffu ^ (unsigned)e0) >= (int)(unsigned)l0) & 7u];
                if (0xffffffffu) goto L3;
                if ((g1 << (g0 & 31u))) {
                    c0 = (unsigned char)(unsigned)((7u / ((unsigned)(x0 >> 70) | 1u)) < (unsigned)(4u == 0x50275fccu));
                    w0 = w0 * 6364136223846793005ull + u3;
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        *q0 = 0xf03c561cu;
                        x0 = x0 * 0x100000001b3ull + (unsigned)(g0 == 0x10000u);
                        goto L2;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(i0, (g0 << (5u & 31u)), ((a0[u1 & 3u] - 0x7b047b7du) + (unsigned)(w0 >> 29))); }
                        if ((fuel | 2u)) break;
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)7u > (signed char)(unsigned)((int)garr[u2 & 7u] < (int)p1)), (0x80000000u << (0x7fffffffu & 31u)), (unsigned)(signed char)(unsigned)(i0 == (unsigned)((short)a0[i0 & 3u] > (signed char)p0))); }
                    }
                    L1: if (--fuel == 0u) goto done;
                    continue; (void)(a0[i0 & 3u]);
                }
                a0[u0 & 3u] = (0xffffffffu + ((unsigned)((unsigned)h0 || u0) ^ (unsigned)h0));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)(unsigned)(i2 == (unsigned)s1) < (int)0xffffffffu), (unsigned)b0, ((0u + a0[i0 & 3u]) % (0x10000u | 1u))); }
            if (budget != 0u) { budget -= 1u; u1 = fn2(0xdb76e2du, (unsigned)(signed char)((unsigned)h1 / (0u | 1u)), 0xc12fee00u); }
            L2: if (--fuel == 0u) goto done;
            goto L1;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(0x8828a795u || 0x82dcb608u), (unsigned)c1, (5u | (0x61fbf620u / (0x80000000u | 1u)))); }
    }
    if ((i1 + i2)) {
        q0 = &garr[(unsigned)((5u ^ g1) && (unsigned)((int)m0 >= (int)(unsigned)h1)) & 7u];
    }
    if ((6u << ((unsigned)(garr[u2 & 7u] && *mp) & 31u))) goto done;
    h1 = (unsigned short)(h1 + (unsigned)((int)(0xffffffffu % ((unsigned)(short)((unsigned)h1 ^ 0xfd5355au) | 1u)) < (int)u3));
    if (1u) goto L3;
    switch (((unsigned)h1 & (unsigned)(signed char)(3u - (unsigned)h0)) & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)(signed char)((unsigned)c1 >> ((unsigned)c1 & 31u)), u1, (unsigned)(x0 >> 70)); }
    }
    L3: if (--fuel == 0u) goto done;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(3u == (unsigned)e0)) continue;
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)1u >= (int)(garr[i1 & 7u] + p1)), i2, (unsigned)(signed char)(unsigned)(p2 && p1)); }
        if ((((unsigned)h0 + (unsigned)x0) | (unsigned)c1)) {
            s1 = (int)((unsigned)s1 + ((unsigned)!(unsigned)((int)(unsigned)d0 >= (int)(unsigned)h1) >> ((u2 << (a0[i0 & 3u] & 31u)) & 31u)));
            if (((unsigned)h1 & (0x7fffffffu ^ 0x631be471u))) break;
            { unsigned t0; double z0; if ((g0) & 1u) { t0 = (0x10000u & v0); z0 = (double)(((0x8364ecf2u + p1)) & 255u); } if ((g0) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                if (budget != 0u) { budget -= 1u; u3 = fn0(u0, (garr[i1 & 7u] % ((unsigned)(short)(unsigned)(0x10195166u == (unsigned)x0) | 1u)), (unsigned)s1); }
                L4: if (--fuel == 0u) goto done;
                b0 = 0x7fffffffu != 0u;
                *q0 = m0;
                if (budget != 0u) { budget -= 1u; u1 = fn2(0xffffffffu, (unsigned)(garr[u2 & 7u] || (i0 * (unsigned)b0)), (unsigned)c0); }
            }
            m0 ^= (unsigned)((short)i0 > (signed char)(unsigned)(short)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)s0));
            if (garr[i1 & 7u]) goto L0;
        } else {
            u2 += ((a0[u1 & 3u] - m0) % ((unsigned)d0 | 1u));
        }
        { unsigned t1; double z1; if (((u0 % ((unsigned)(w0 >> 29) | 1u))) & 1u) { t1 = a0[u1 & 3u]; z1 = (double)(((a0[i0 & 3u] << ((unsigned)(fuel && r0.x) & 31u))) & 255u); } if (((u0 % ((unsigned)(w0 >> 29) | 1u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            r0.x = (u3 - r0.y);
            c0 = (unsigned char)(unsigned)(i2 == (unsigned)((int)(unsigned)l0 >= (int)(unsigned)s0));
            if (budget != 0u) { budget -= 1u; u1 = fn3((0u >> (7u & 31u)), 0x10000u, (0x10000u | (0x7fffffffu * i1))); }
            if (fuel < 8u) return ((unsigned)h1 ? r0.y : (unsigned)(i0 && garr[u2 & 7u]));
            if (((unsigned)d0 ^ (unsigned)(6u || g0))) break;
        }
        while (i1++ < 3u && (unsigned)((int)(unsigned)x0 >= (int)(unsigned)e0)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)(i0 < 0x10000u) >> ((unsigned)(w0 >> 29) & 31u)), (7u % (u3 | 1u)), (0x10000u >> (0x7b7a3775u & 31u))); }
            s1 = (int)((unsigned)s1 + (unsigned)h0);
            if (budget != 0u) { budget -= 1u; u1 = fn2(v0, (unsigned)!(unsigned)(g1 == (*q0 * (unsigned)s0)), (unsigned)((short)1u > (signed char)m0)); }
            f0 = f0 * 0.5f + (float)((unsigned)((int)*q0 >= (int)8u) & 255u);
        }
    }
    { unsigned t2; double z2; if (((unsigned)!((unsigned)x0 / ((unsigned)(0x10000u && m0) | 1u))) & 1u) { t2 = ((unsigned)h1 * (unsigned)l0); z2 = (double)((((0x10000u * 1u) * 0x10000u)) & 255u); } if (((unsigned)!((unsigned)x0 / ((unsigned)(0x10000u && m0) | 1u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        e0 = e0 * 0.5L + (long double)((unsigned)((short)*q0 > (signed char)(unsigned)((short)(unsigned)x0 > (signed char)(unsigned)(x0 >> 70))) & 1023u);
        if ((unsigned)(a0[i0 & 3u] || 7u)) goto L4;
        v0 = (0xffffffffu << (garr[u2 & 7u] & 31u));
    }
    u3 = ~(unsigned)((unsigned)w0 && (unsigned)h1);
    r0.y ^= (unsigned)x0;
    q0 = &garr[*q0 & 7u];
    while (i0++ < 7u && r0.x) { if (--fuel == 0u) goto done;
        break; (void)(0x80000000u);
        do { if (--fuel == 0u) goto done;
            if ((5u - ((unsigned)l0 / ((unsigned)h0 | 1u)))) continue;
            d0 = d0 * 0.5 + (double)((unsigned)(0x10000u < p0) & 1023u);
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)((int)(0xa5923d8cu - 7u) < (int)i0) < (int)0xcd3c7953u));
            for (;;) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(v0 >> (g0 & 31u)) << (0xdedcddbfu & 63u);
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)u3 > (signed char)(unsigned)((unsigned)c0 || (unsigned)w0)), garr[i1 & 7u], (unsigned)d0); }
                x0 = x0 * 0x100000001b3ull + (0x3412d18fu ^ p1);
                u1 = (unsigned)((unsigned)h1 < ((unsigned)(w0 >> 29) - (unsigned)(short)(a0[u1 & 3u] + ((unsigned)f0 ^ 0xd5283fc8u))));
            }
        } while (i1++ < 3u && ((unsigned)(0x9be0b4cdu < r0.y) - 0x54c4850bu));
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)((unsigned)b0 >> (0x55685a2cu & 31u))) break;
            break; (void)(fuel);
            if (fuel) break;
        }
        if (g1) break;
    }
    i0 = (a0[u1 & 3u] / ((unsigned)(9u < (0xf43e62d7u & (unsigned)(0xbbde9cd7u == fuel))) | 1u)) & 15u;
    e0 = e0 * 0.5L + (long double)((4u ? (unsigned)(0x134fcc7au && r0.y) : 1u) & 1023u);
    goto L0;
    goto done;
    *q0 += (unsigned)((int)(unsigned)((int)(unsigned)s1 >= (int)p1) < (int)i0);
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((unsigned)((p2 & garr[u2 & 7u]) == (2u ^ (unsigned)d0)) & 255u);
    }
    do { if (--fuel == 0u) goto done;
        r0.x = *mp;
        while (i1++ < 3u && (unsigned)((unsigned)b0 && *q0)) { if (--fuel == 0u) goto done;
            if ((garr[i1 & 7u] % ((0x9e5555a4u - garr[i1 & 7u]) | 1u))) break;
        }
        u1 ^= (unsigned)(fuel == (unsigned)h0);
    } while (i0++ < 4u && (unsigned)(u0 && p2));
    if ((unsigned)w0) {
        if ((fuel >> (garr[i1 & 7u] & 31u))) {
            w0 ^= (unsigned long long)((unsigned)w0 + g1) << ((unsigned)(unsigned char)(unsigned)((short)(unsigned)x0 > (signed char)(unsigned)((int)0u >= (int)(unsigned)h0)) & 63u);
            if ((unsigned)((int)0x7fffffffu >= (int)(0xffffffffu ^ 0x7fffffffu))) goto done;
            switch ((g1 + 0xad34982du) & 7u) {
                w0 = w0 * 6364136223846793005ull + (0u & (unsigned)(0xffffffffu == garr[i1 & 7u]));
            }
            w0 ^= (unsigned long long)(garr[i1 & 7u] + a0[i0 & 3u]) << ((((unsigned)x0 / (a0[u1 & 3u] | 1u)) / ((3u | (unsigned)(0x7fffffffu < *q0)) | 1u)) & 63u);
            u1 = u1 * 0x9e3779b1u + (2u % (((unsigned)(unsigned char)(unsigned)((int)p1 >= (int)*mp) % (m0 | 1u)) | 1u));
            e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)((p2 * i2) < g1) < (int)i1) & 1023u);
        } else {
            goto L2;
            do { if (--fuel == 0u) goto done;
                r0.y ^= v0;
                if (0x81b3366au) break;
                x0 = x0 * 0x100000001b3ull + (unsigned)(0x3a52dda5u || garr[u2 & 7u]);
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(0xffffffffu == (unsigned)(short)(unsigned)((int)0x10000u >= (int)0x10000u)), (p0 & 0xd30dd516u), ~(fuel << (p2 & 31u))); }
            } while (i0++ < 5u && ~(u0 * 2u));
        }
        if ((garr[u2 & 7u] * (unsigned)w0)) {
            goto L3;
            goto L0;
            goto L3;
            *q0 += (unsigned)(-(unsigned)((unsigned)d0 || (unsigned)h0) || ((0x10bc8eefu & u3) >> (u1 & 31u)));
            if (budget != 0u) { budget -= 1u; u0 = fn1(i0, (0xffffffffu + (unsigned)l0), (unsigned)((int)0x22b65c3bu < (int)garr[i1 & 7u])); }
        } else {
            goto done;
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)(x0 >> 70) & 255u);
                for (;;) { if (--fuel == 0u) goto done;
                    u2 ^= (unsigned)(w0 >> 29);
                    x0 = x0 * 0x100000001b3ull + ((unsigned)((int)0xb4dada5au >= (int)8u) ^ (unsigned)((unsigned)c0 == 5u));
                    i0 = (unsigned)((unsigned)(unsigned char)(0x7fffffffu * ((unsigned)x0 * i1)) < (unsigned)((short)(unsigned)s0 > (signed char)g1)) & 15u;
                    c1 = (signed char)((unsigned)(x0 >> 70) % ((unsigned)((int)r0.y < (int)p0) | 1u));
                    if (3u) {
                        if (budget != 0u) { budget -= 1u; u3 = fn3((i2 / (3u | 1u)), 0xa11f2c4au, (unsigned)(w0 >> 29)); }
                    }
                    r0.y ^= (unsigned)((r0.y % ((0xffffffffu * 0x80000000u) | 1u)) || 0x7fffffffu);
                }
                *mp = (p0 * (unsigned)((short)p1 > (signed char)(unsigned)h0));
                if ((unsigned)((int)(unsigned)h0 < (int)0x80000000u)) goto L3;
            }
            do { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + ((unsigned)(a0[i0 & 3u] || (7u | fuel)) / ((unsigned)d0 | 1u));
                if (budget != 0u) { budget -= 1u; u1 = fn1((0x86bf0e1fu / ((0x7fffffffu ^ 0x80000000u) | 1u)), (p1 ^ (0xcc2a0eb0u | (unsigned)d0)), (unsigned)(signed char)(unsigned)(((unsigned)w0 % (0xc5b2f4bu | 1u)) || m0)); }
                switch ((unsigned)l0 & 7u) {
                    if (budget != 0u) { budget -= 1u; u2 = fn1(u2, 0x39ceeeefu, (unsigned)((unsigned)d0 && (garr[i1 & 7u] / (g0 | 1u)))); }
                    case 6u: ;
                    case 7u: ;
                    h1 = (unsigned short)(h1 + 0x3622359fu);
                    *mp = v0;
                    if (u3 == 7u) return g0;
                }
            } while (i0++ < 3u && ((unsigned)w0 & m0));
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 7u, 0x8728625u, 0x3d614955u },
        { 10u, 0x8f9a62cu, 0x58d5be7u },
        { 11u, 0xbe62984cu, 0x3b8aba9fu },
        { 10u, 0x57781f5cu, 0xe8e9d36du },
        { 11u, 0x5056bfe3u, 0xc2365a4eu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
