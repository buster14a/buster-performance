// test-ssa-source's program of seed 134000437 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x43aadd28u, g1 = 0x7ec00a9cu;
static unsigned garr[8] = { 0x54560fb5u, 0x7795a58bu, 0x7f4cded0u, 0x7976591cu, 0x1e48677u, 0x2c284666u, 0xcbdc4a39u, 0xb139c4fau };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(a0[i0 & 3u] < (unsigned)(g0 || 0xadbc852fu))) goto L4;
    garr[((unsigned)h0 + 0xffffffffu) & 7u] = -((unsigned)s0 >> ((unsigned)s1 & 31u));
    c1 = (signed char)(unsigned)((0x80000000u | (unsigned)c0) || 0x80000000u);
    c0 = (unsigned char)(unsigned)h0;
    while ((u1 % ((0x4ee14483u % (0x87eae4e0u | 1u)) | 1u))) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)0xa4eb72d4u << ((unsigned)(((unsigned)h1 + 1u) < (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)(w0 >> 29))) & 63u);
        m0 ^= (unsigned)!((i1 - *q0) / ((unsigned)d0 | 1u));
        w0 ^= (unsigned long long)(unsigned)(3u && 0x7fffffffu) << ((garr[i1 & 7u] - (0x5c75b966u / (7u | 1u))) & 63u);
    }
    b0 = ((unsigned)(signed char)(g0 & 0x2c758038u) & (0x7fffffffu ? u2 : 0xe74cc721u)) != 0u;
    switch ((unsigned)c1 & 7u) {
        h1 = (unsigned short)(h1 + (0u >> ((0x7fffffffu >> (8u & 31u)) & 31u)));
        i0 = (unsigned)d0 & 15u;
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[0x244827ffu & 3u] = (0xce345c4fu << (((unsigned)b0 * (unsigned)h0) & 31u));
        if (g1) {
            h1 = (unsigned short)(h1 + (unsigned)((i2 << ((unsigned)(w0 >> 29) & 31u)) || (unsigned)e0));
        } else {
            L0: if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
        }
    }
    L2: if (--fuel == 0u) goto done;
    u0 = u0 * 0x9e3779b1u + (unsigned)(signed char)((unsigned)(w0 >> 29) >> (0x10000u & 31u));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        L3: if (--fuel == 0u) goto done;
        L4: if (--fuel == 0u) goto done;
    }
    r0.y ^= ((unsigned)l0 / (r0.y | 1u));
    if (0xffffffffu) goto L1;
    if (*mp) goto L1;
    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)((int)(unsigned)b0 < (int)v0) & 1023u);
    if (-((unsigned)((int)(unsigned)w0 < (int)fuel) << (0x3e054ec8u & 31u))) {
        u2 += (unsigned)((unsigned)(unsigned char)(unsigned)((short)(unsigned)((int)(unsigned)w0 < (int)0x1b0198f2u) > (signed char)1u) < i1);
        if (fuel < 8u) return (u0 ^ (unsigned)(unsigned char)(i0 / (-(0x1a4e85ceu >> ((7u + r0.y) & 31u)) | 1u)));
        if (((a0[i0 & 3u] % ((unsigned)(w0 >> 29) | 1u)) & v0)) goto L0;
    } else {
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)((a0[i0 & 3u] / (i2 | 1u)) | u2) >= (int)v0);
        v0 = (unsigned)(3u && (r0.x % ((unsigned)((int)(a0[i0 & 3u] % ((unsigned)f0 | 1u)) >= (int)(unsigned)f0) | 1u)));
        *q0 = (unsigned)((int)0x7fffffffu >= (int)v0);
    }
    m0 ^= (unsigned)!(unsigned)(a0[i0 & 3u] < ((unsigned)(signed char)((unsigned)s1 ? i0 : 0x7deb5708u) / (1u | 1u)));
    for (;;) { if (--fuel == 0u) goto done;
        continue; (void)((unsigned)(r0.y == (unsigned)e0));
        if ((u0 | fuel)) break;
        r0.x = (unsigned)(8u && (unsigned)(w0 >> 29));
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (0u) break;
            if ((0xffffffffu >> ((unsigned)(x0 >> 70) & 31u))) {
                g1 += (unsigned)((int)(unsigned)w0 < (int)(unsigned)x0);
                if ((i0 + (unsigned)((int)0x114fb6f7u < (int)*q0))) continue;
                if (i2) break;
                u3 += (unsigned)l0;
                r0.y ^= (r0.y ? (unsigned)c0 : (unsigned)(2u < 6u));
            } else {
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    garr[((unsigned)s0 + u1) & 7u] = ((p0 - m0) << (p0 & 31u));
                    r0.y ^= (i2 / (0xd7b8943au | 1u));
                    continue; (void)((unsigned)((unsigned)((unsigned)f0 && 0x9cbaa379u) == 0x80000000u));
                    { unsigned t0; double z0; if (((i0 / ((0x46d23b5eu << (r0.y & 31u)) | 1u))) & 1u) { t0 = (a0[i0 & 3u] * r0.y); z0 = (double)(((unsigned)w0) & 255u); } if (((i0 / ((0x46d23b5eu << (r0.y & 31u)) | 1u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                        if ((unsigned)(a0[i0 & 3u] < (0x70d40392u ^ 5u))) break;
                        if ((r0.y % (1u | 1u))) {
                            *q0 = (unsigned)(g0 < g1);
                            v0 = (0x12b69866u << (p0 & 31u));
                            s1 = (int)((unsigned)s1 + (unsigned)((unsigned)x0 && p1));
                            d0 = d0 * 0.5 + (double)(((unsigned)f0 | (unsigned)l0) & 1023u);
                        }
                        if (u0) break;
                        q0 = &garr[((unsigned)h0 - ((*q0 * (3u | garr[i1 & 7u])) | 0x80000000u)) & 7u];
                        b0 = (unsigned)((int)fuel >= (int)(unsigned)(0x62569f52u == i2)) != 0u;
                        if (((unsigned)x0 + ((unsigned)c0 - (unsigned)(x0 >> 70)))) break;
                    }
                    if (m0) break;
                }
                if ((unsigned)(((unsigned)l0 >> (0x80000000u & 31u)) < garr[i1 & 7u])) break;
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + 5u);
                }
                *q0 = (unsigned)(unsigned char)((m0 + (u2 << (p2 & 31u))) + (unsigned)c0);
            }
            if ((unsigned)(short)(v0 / (0x3cc4f9f2u | 1u))) goto done;
            s0 = (int)(~(u1 ? u2 : (unsigned)x0) % (0x49a6a6acu | 1u));
            do { if (--fuel == 0u) goto done;
                break; (void)((unsigned)((int)v0 < (int)*mp));
                *q0 = (unsigned)s1;
                b0 = 6u != 0u;
                e0 = e0 * 0.5L + (long double)((unsigned)(m0 < 0x80000000u) & 1023u);
                if ((unsigned)e0) break;
            } while (i2++ < 4u && (unsigned)(0xffffffffu && (unsigned)b0));
        }
        if ((2u ^ (unsigned)((short)(unsigned)d0 > (signed char)5u))) {
            u2 = (unsigned)f0;
            if ((i0 >> (p1 & 31u))) break;
            u1 = u1 * 0x9e3779b1u + ((unsigned)d0 % (i0 | 1u));
            *q0 += (9u + (unsigned)x0);
        } else {
            switch (((0x208109f2u / ((unsigned)b0 | 1u)) << (a0[i0 & 3u] & 31u)) & 7u) {
                if ((unsigned)(fuel == u2)) goto L3;
                if (u3 == 7u) return (unsigned)(signed char)(0x6ed7bbd8u - ~(unsigned)((int)3u < (int)((unsigned)(x0 >> 70) - u3)));
                case 5u: ;
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 4u: ;
                    u2 = u2 * 0x9e3779b1u + ((0x80000000u + 0x80000000u) * (unsigned)(r0.x == 7u));
                    case 1u: ;
                }
                d0 = d0 * 0.5 + (double)(0x10000u & 1023u);
                break; (void)((unsigned)d0);
            }
            *q0 = (unsigned)f0;
            { unsigned t1; double z1; if (((p2 + ((unsigned)x0 >> ((unsigned)d0 & 31u)))) & 1u) { t1 = (unsigned)!(unsigned)((short)i0 > (signed char)fuel); z1 = (double)((p1) & 255u); } if (((p2 + ((unsigned)x0 >> ((unsigned)d0 & 31u)))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((r0.x - (unsigned)((int)garr[u2 & 7u] >= (int)0x7fffffffu)));
                    break; (void)(((*mp >> ((unsigned)c0 & 31u)) % (p1 | 1u)));
                    break; (void)((unsigned)(garr[i1 & 7u] < (a0[i0 & 3u] % (0x10000u | 1u))));
                    break; (void)(0xcce4f7b0u);
                }
                if ((unsigned)c1) goto L4;
                break; (void)(0x7fffffffu);
                break; (void)(((unsigned)(7u < 9u) & (unsigned)b0));
                x0 = x0 * 0x100000001b3ull + ((unsigned)h1 - (unsigned)w0);
            }
        }
        v0 = (unsigned)c1;
    }
    goto L0;
    x0 = x0 * 0x100000001b3ull + (*q0 % (0x80000000u | 1u));
    for (;;) { if (--fuel == 0u) goto done;
        switch ((unsigned)h0 & 7u) {
            b0 = (unsigned)(short)(unsigned)(u3 || r0.y) != 0u;
            if (u3 == 7u) return (0x7fffffffu * (unsigned)((unsigned)((unsigned)e0 == (unsigned)c0) < (unsigned)c1));
            b0 = a0[i0 & 3u] != 0u;
        }
        u3 += ((unsigned)x0 >> (p2 & 31u));
    }
    i0 = ((unsigned)c1 + ((unsigned)x0 / (i2 | 1u))) & 15u;
    garr[(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)h1) & 7u] = (unsigned)((int)0xffffffffu >= (int)(unsigned)(unsigned char)((unsigned)!(v0 ? 3u : (unsigned)w0) + (unsigned)c1));
    garr[0x80000000u & 7u] = 0x451f35f2u;
    if (((unsigned)d0 / (0xf3ac1096u | 1u))) {
        if ((unsigned)((short)u2 > (signed char)0xffffffffu)) goto L3;
        c1 = (signed char)(((unsigned)!((unsigned)(0xd42bd768u < 0xcbf8f984u) % (0x16492093u | 1u)) - 0x80000000u) & 0x7fffffffu);
        goto done;
        if ((unsigned)(short)(u1 + u2)) goto L4;
        u1 = 0x7cb2c107u;
        if (r0.y) goto L4;
    }
    goto done;
    goto L0;
    e0 = e0 * 0.5L + (long double)(fuel & 1023u);
    if (fuel < 8u) return (unsigned)d0;
    if (((unsigned)h1 ^ i0)) {
        do { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)h1 << ((unsigned)(u2 || g0) & 63u);
            r0.y ^= 8u;
            u0 ^= (unsigned)((int)(unsigned)!(i1 >> (r0.y & 31u)) < (int)(0x80000000u + (unsigned)((short)0xfe30016au > (signed char)fuel)));
            u1 = (0x16a63459u & v0);
            break; (void)((8u / (-(a0[u1 & 3u] - i1) | 1u)));
        } while (i0++ < 7u && r0.y);
        w0 = w0 * 6364136223846793005ull + (-(garr[i1 & 7u] - 0x10000u) << (a0[i0 & 3u] & 31u));
        goto L0;
    } else {
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            b0 = (unsigned)((int)(unsigned)(x0 >> 70) >= (int)a0[u1 & 3u]) != 0u;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (unsigned)f0);
                if ((unsigned)(signed char)(unsigned)(((unsigned)w0 + 0x10000u) < m0)) break;
            }
            break; (void)((unsigned)((int)6u >= (int)(0x10000u % (garr[i1 & 7u] | 1u))));
            if ((unsigned)((int)(unsigned)d0 < (int)i1)) continue;
        }
        goto done;
        if ((a0[i0 & 3u] * i0)) goto L3;
    }
    e0 = e0 * 0.5L + (long double)((((unsigned)((int)i1 >= (int)0x7fffffffu) & (unsigned)e0) >> (u1 & 31u)) & 1023u);
    m0 ^= ((unsigned)(x0 >> 70) | 0x38d1ff66u);
    h0 = (short)((unsigned)(signed char)(a0[i0 & 3u] % ((unsigned)!(unsigned)(((unsigned)(x0 >> 70) % (a0[i0 & 3u] | 1u)) < (unsigned)h0) | 1u)) - a0[i0 & 3u]);
    if ((unsigned)((int)(unsigned)d0 >= (int)p0)) goto L1;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((fuel | 3u) ^ a0[u1 & 3u])) {
            if ((unsigned)!(unsigned)(i1 < 0x43651f1bu)) break;
            if (((unsigned)(p2 == u0) + v0)) break;
            if (r0.y) continue;
            break; (void)((*q0 + (unsigned)((unsigned)s0 < 2u)));
        } else {
            v0 = u1;
            do { if (--fuel == 0u) goto done;
                break; (void)(fuel);
                break; (void)((unsigned)(i0 == (0xe90a0059u / ((unsigned)(x0 >> 70) | 1u))));
                if ((unsigned)c0) break;
                continue; (void)((unsigned)w0);
            } while (i1++ < 7u && (unsigned)((int)p0 >= (int)((unsigned)h1 | u3)));
            if (((unsigned)(x0 >> 70) | fuel)) {
                break; (void)((((unsigned)x0 - (unsigned)s0) & 0x10000u));
                if (((unsigned)c1 ^ g1)) break;
                c1 = (signed char)~(0x144924f8u & (unsigned)((short)(unsigned)((int)5u < (int)(unsigned)l0) > (signed char)((unsigned)b0 % (0x10000u | 1u))));
            } else {
                if (p2) break;
                e0 = e0 * 0.5L + (long double)((u2 + (unsigned)((int)0u >= (int)0x616f3d7bu)) & 1023u);
                break; (void)((((unsigned)s0 % ((unsigned)c1 | 1u)) % (0xffffffffu | 1u)));
                if ((m0 ^ 0x80000000u)) break;
            }
        }
        b0 = 0u != 0u;
        if ((unsigned)d0) {
            if ((unsigned)((unsigned)d0 || (unsigned)e0)) break;
            m0 ^= ((unsigned)d0 ? (0xa64c806u << (u2 & 31u)) : (0x80000000u << (0u & 31u)));
        } else {
            if ((9u | 0x2cfa2e18u)) break;
            i2 = (unsigned)((short)garr[u2 & 7u] > (signed char)(p1 >> ((unsigned)w0 & 31u))) & 15u;
            b0 = p2 != 0u;
        }
        e0 = e0 * 0.5L + (long double)((unsigned)!((unsigned)((r0.x & (unsigned)(w0 >> 29)) < (3u | p2)) - u1) & 1023u);
        { unsigned t2; double z2; if ((~(5u >> (0x7dbb067cu & 31u))) & 1u) { t2 = a0[i0 & 3u]; z2 = (double)(((unsigned)((unsigned)h1 || i2)) & 255u); } if ((~(5u >> (0x7dbb067cu & 31u))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            break; (void)(((*mp ^ (unsigned)c0) % ((unsigned)(w0 >> 29) | 1u)));
            *q0 = ((unsigned)h0 ^ (0x3823a24u / ((unsigned)(signed char)(unsigned)(r0.x == 0x80000000u) | 1u)));
        }
    }
    switch ((u0 / ((unsigned)h1 | 1u)) & 7u) {
        do { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + 0x7fffffffu;
                case 2u: ;
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = ((v0 / (-((unsigned)(unsigned char)(unsigned)((short)u0 > (signed char)1u) % (i0 | 1u)) | 1u)) + r0.x);
                }
            }
            if (u1) {
                r0.y ^= a0[i0 & 3u];
                b0 = ((p1 << ((unsigned)c1 & 31u)) + (u3 - garr[i1 & 7u])) != 0u;
            } else {
                if ((unsigned)(u0 == (unsigned)(w0 >> 29))) {
                    u1 = (unsigned)((int)5u >= (int)u1);
                    f0 = f0 * 0.5f + (float)((unsigned)((int)((unsigned)(0x80000000u || fuel) << (((unsigned)b0 & 0u) & 31u)) >= (int)(unsigned)e0) & 255u);
                    if ((unsigned)(5u == (unsigned)((int)(unsigned)s1 >= (int)(unsigned)(x0 >> 70)))) continue;
                    c0 = (unsigned char)p2;
                    q0 = &garr[((unsigned)b0 + 9u) & 7u];
                } else {
                    d0 = d0 * 0.5 + (double)((((unsigned)x0 | (garr[u2 & 7u] | (unsigned)f0)) << ((*q0 + p1) & 31u)) & 1023u);
                    default: ;
                    q0 = &garr[(unsigned)!((unsigned)((unsigned)s1 || (unsigned)f0) << (~(unsigned)(*q0 < (i2 % ((unsigned)f0 | 1u))) & 31u)) & 7u];
                }
                switch ((unsigned)(i2 && 0x10000u) & 7u) {
                    if (0x181d2f72u) break;
                    c0 = (unsigned char)(unsigned)(unsigned char)(0x860a1adfu / ((unsigned)((i0 << (0x7f090d95u & 31u)) < 0x80000000u) | 1u));
                    r0.x = ((unsigned)(0xe4c3bcd3u == u3) - (unsigned)b0);
                    do { if (--fuel == 0u) goto done;
                        q0 = &garr[((0xffffffffu ? (unsigned)b0 : p0) | (unsigned)((int)0x80000000u < (int)5u)) & 7u];
                        case 4u: ;
                        case 3u: ;
                    } while (i1++ < 2u && (unsigned)(m0 < (p2 / ((unsigned)s0 | 1u))));
                    c0 = (unsigned char)0x80000000u;
                }
                d0 = d0 * 0.5 + (double)(0x10000u & 1023u);
                if (((unsigned)(u3 < (unsigned)h1) | (unsigned)d0)) continue;
            }
            case 6u: ;
            if (2u) goto L4;
            case 1u: ;
        } while (i0++ < 2u && (fuel - a0[i0 & 3u]));
        if (((4u ^ 0xba71df6u) ^ i2)) goto L3;
        while (i0++ < 3u && ((unsigned)l0 << (g0 & 31u))) { if (--fuel == 0u) goto done;
            *mp = (0xe0267ebcu % ((unsigned)((unsigned)((int)((unsigned)h1 - 0x7fffffffu) < (int)(unsigned)x0) < u3) | 1u));
            if (6u) {
                garr[(unsigned)x0 & 7u] = (unsigned)((int)(garr[u2 & 7u] + (unsigned)d0) < (int)6u);
            } else {
                w0 = w0 * 6364136223846793005ull + ((unsigned)l0 + r0.y);
                i2 = (unsigned)((unsigned)(signed char)((unsigned)(x0 >> 70) | (unsigned)!(3u >> (0xffffffffu & 31u))) < (unsigned)(fuel || (unsigned)e0)) & 15u;
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)h1 < (int)((unsigned)b0 / (0x7fffffffu | 1u)));
                if ((unsigned)s0) {
                    case 3u: ;
                    break;
                    r0.x = (unsigned)((p0 / ((unsigned)x0 | 1u)) == (unsigned)((unsigned)((unsigned)c1 == garr[i1 & 7u]) == a0[i0 & 3u]));
                    if ((9u | 2u)) break;
                    case 4u: ;
                    case 7u: ;
                }
            }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                *mp = ((unsigned)((int)(unsigned)l0 >= (int)0x80000000u) | v0);
                g0 = ((0x98b0524au % ((unsigned)c0 | 1u)) | 0x4981d7cdu);
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((0xdff16f23u << ((r0.y + (unsigned)d0) & 31u))) goto L4;
                    h1 = (unsigned short)(h1 + (unsigned)(signed char)(unsigned)((short)(a0[u1 & 3u] ^ 0x544b68b9u) > (signed char)(0xe93d2f5bu * 0x10000u)));
                }
                if ((0x1f7a0fcfu % (*mp | 1u))) break;
                break;
                a0[(unsigned)(signed char)(unsigned)((unsigned)s1 || 0xffffffffu) & 3u] = (r0.y * (unsigned)h0);
            }
        }
        if ((p2 % (7u | 1u))) {
            s1 = (int)((unsigned)s1 + (unsigned)(1u < r0.x));
        }
    }
    switch ((7u | (unsigned)c0) & 7u) {
        case 5u: ;
        case 2u: ;
        g1 += (unsigned)(unsigned char)(unsigned)((int)0u < (int)(unsigned)(*mp == (unsigned)x0));
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)garr[u2 & 7u] >= (int)((unsigned)s0 | 0xee0a8a0u))) {
                default: ;
                switch (0xffffffffu & 7u) {
                    r0.x = p2;
                }
                if ((unsigned)h0) continue;
                e0 = e0 * 0.5L + (long double)(((8u * 0x7fffffffu) - (unsigned)((unsigned)f0 == (*mp + garr[u2 & 7u]))) & 1023u);
                w0 ^= (unsigned long long)(unsigned)((int)0x80000000u >= (int)0u) << (((unsigned)(0x80000000u || *mp) * m0) & 63u);
                do { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (unsigned)s1);
                    *q0 = (unsigned)((int)((unsigned)c0 & g0) >= (int)(unsigned)c0);
                    *q0 = -((p2 | (unsigned)s0) % (((unsigned)c1 * i2) | 1u));
                    s0 = (int)((unsigned)c1 >> ((u2 << (-((unsigned)s1 ? garr[i1 & 7u] : u0) & 31u)) & 31u));
                    for (;;) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (unsigned)(short)(unsigned)((int)(unsigned)h1 >= (int)g1));
                        if (garr[u2 & 7u]) continue;
                        { unsigned t3; double z3; if ((0x4927e0c0u) & 1u) { t3 = p2; z3 = (double)((0x7fffffffu) & 255u); } if ((0x4927e0c0u) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                            h1 = (unsigned short)(h1 + ((0u ^ (unsigned)b0) | (p0 >> ((unsigned)(3u && u0) & 31u))));
                            if (((unsigned)s1 - (unsigned)h1)) continue;
                            break;
                            case 4u: ;
                            v0 = (unsigned)(4u == *mp);
                            if ((unsigned)(8u && (unsigned)((int)(unsigned)e0 >= (int)p2))) break;
                        }
                        if ((unsigned)((int)((unsigned)s0 - (unsigned)d0) < (int)i0)) goto L1;
                        while ((unsigned)(i0 || r0.x)) { if (--fuel == 0u) goto done;
                            m0 ^= (unsigned)((short)((unsigned)((short)0x80000000u > (signed char)2u) / (g0 | 1u)) > (signed char)u3);
                            i0 = -((p0 * (0u - a0[i0 & 3u])) << ((unsigned)c0 & 31u)) & 15u;
                            a0[(unsigned)b0 & 3u] = (unsigned)w0;
                            break;
                            *mp = (p2 % (g1 | 1u));
                            c0 = (unsigned char)((unsigned)h0 ^ ((unsigned)((int)p0 >= (int)7u) << ((unsigned)(0xffffffffu && 0xc7e5749fu) & 31u)));
                        }
                    }
                    case 3u: ;
                } while (i1++ < 6u && (unsigned)((int)u1 < (int)fuel));
            } else {
                while ((6u - garr[u2 & 7u])) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)(garr[u2 & 7u] == ((unsigned)(signed char)((unsigned)h0 + *mp) % ((unsigned)d0 | 1u))) >= (int)(unsigned)w0));
                    case 7u: ;
                    goto L3;
                }
            }
        }
    }
    d0 = d0 * 0.5 + (double)(0x9477daf9u & 1023u);
    garr[(unsigned)h1 & 7u] = (unsigned)(signed char)(9u + g0);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)f0) {
        u1 ^= ((a0[u1 & 3u] + 0x18585c24u) >> ((0x7fffffffu | (unsigned)(x0 >> 70)) & 31u));
        u1 ^= (u2 ^ (((unsigned)(w0 >> 29) + *mp) / (((unsigned)(w0 >> 29) % (u3 | 1u)) | 1u)));
        if ((0xe1e477f8u & (unsigned)s1)) goto L2;
    }
    if ((u0 << (0xffffffffu & 31u))) goto L4;
    if (p1) goto done;
    while (i0++ < 5u && 0x48baae54u) { if (--fuel == 0u) goto done;
        g0 = (unsigned)(0x7fffffffu < *q0);
        i2 = (unsigned)(0xb021a5beu < ((unsigned)c1 / (0x69aba5e5u | 1u))) & 15u;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            while (i2++ < 3u && 0x10000u) { if (--fuel == 0u) goto done;
                if (0u) break;
                break; (void)((a0[i0 & 3u] ^ p0));
                if ((unsigned)c1) break;
                if ((unsigned)((short)7u > (signed char)0x10000u)) {
                    h1 = (unsigned short)(h1 + (((unsigned)c1 / ((0xffffffffu >> ((unsigned)(x0 >> 70) & 31u)) | 1u)) * p2));
                }
                garr[(unsigned)(unsigned char)(0x80000000u - u0) & 7u] = (unsigned)((short)(unsigned)(i2 || (m0 - 0xe347450u)) > (signed char)(unsigned)((int)(unsigned)(x0 >> 70) < (int)3u));
            }
            break; (void)((i2 << (0xbb2e7a49u & 31u)));
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(unsigned char)(unsigned)(0u == (unsigned)(g1 == 0x166dbc25u)), (unsigned)(x0 >> 70), -((unsigned)(fuel == 8u) - *q0)); }
            if ((unsigned)h1) {
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    goto L4;
                }
                *mp = ((unsigned)s0 / (0xffffffffu | 1u));
                s0 = (int)(unsigned)(u0 == (unsigned)((int)(unsigned)s0 >= (int)0x45a6ac5du));
                if (a0[u1 & 3u]) break;
                w0 = w0 * 6364136223846793005ull + (unsigned)((short)5u > (signed char)(unsigned)(0u < 0x8c8791e4u));
            } else {
                if ((unsigned)(signed char)(unsigned)((int)6u < (int)5u)) break;
                if (0x80000000u) break;
                while (i2++ < 4u && (unsigned)((unsigned)((unsigned)f0 && 0x8b417dfu) || i0)) { if (--fuel == 0u) goto done;
                    L0: if (--fuel == 0u) goto done;
                    r0.x = (unsigned)(short)((unsigned)!(unsigned)((unsigned)((short)0x10000u > (signed char)u1) || 0xffffffffu) << (((unsigned)c0 << ((unsigned)h0 & 31u)) & 31u));
                    L1: if (--fuel == 0u) goto done;
                    q0 = &garr[p1 & 7u];
                    if ((unsigned)((short)u0 > (signed char)(3u / (a0[i0 & 3u] | 1u)))) continue;
                }
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)s1, (0xd927190au & 0x811b473au), (*mp / ((unsigned)(v0 < 7u) | 1u))); }
                    a0[(unsigned)(p1 || (unsigned)c0) & 3u] = (unsigned)c0;
                    i0 = (~(unsigned)(u0 == (unsigned)e0) ^ v0) & 15u;
                    r0.y ^= ((unsigned)e0 << (4u & 31u));
                    do { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(garr[i1 & 7u] ? 0x7fffffffu : u2) & 255u);
                        L2: if (--fuel == 0u) goto done;
                        r0.x = ((unsigned)h1 ^ (0xf0ecee50u * 0x7fffffffu));
                        c0 = (unsigned char)-(unsigned)((short)v0 > (signed char)*mp);
                        if ((0xe186c2e9u ^ (unsigned)((int)*q0 >= (int)7u))) goto L4;
                        L3: if (--fuel == 0u) goto done;
                    } while (i0++ < 7u && a0[i0 & 3u]);
                } while (i2++ < 3u && (unsigned)l0);
            }
        }
        w0 = w0 * 6364136223846793005ull + -(unsigned)((0xffffffffu + (0x3e10bd03u / ((unsigned)h1 | 1u))) < g1);
    }
    if (fuel < 8u) return (unsigned)((unsigned)x0 < (i2 >> ((u1 ? 6u : 0xf4ad2ff6u) & 31u)));
    if (a0[i0 & 3u]) goto done;
    r0.y ^= (0x10000u << (2u & 31u));
    goto done;
    m0 ^= (unsigned)(-((unsigned)(1u || a0[u1 & 3u]) % (0x10000u | 1u)) || i0);
    switch (((m0 & (unsigned)h1) << (fuel & 31u)) & 7u) {
        w0 = w0 * 6364136223846793005ull + ((((unsigned)(x0 >> 70) / (0x80000000u | 1u)) ^ 0x7fffffffu) % ((unsigned)((unsigned)s0 < r0.x) | 1u));
        if (((unsigned)(u0 && p2) * (unsigned)h0)) {
            e0 = e0 * 0.5L + (long double)(((0x80000000u >> ((unsigned)b0 & 31u)) & (r0.y ^ 0xffffffffu)) & 1023u);
            do { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    u1 = u1 * 0x9e3779b1u + ~(0x35a0c4d1u * (0xbe3c3a09u | 5u));
                    g1 += (unsigned)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)5u) == ((unsigned)((int)(unsigned)e0 >= (int)u1) % (5u | 1u)));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((garr[i1 & 7u] ^ i1), ((unsigned)b0 ^ (unsigned)s0), (unsigned)x0); }
                }
                c1 = (signed char)((unsigned)e0 / (0x80000000u | 1u));
            } while (i0++ < 7u && (unsigned)((int)*q0 < (int)(unsigned)c1));
            if ((4u % ((unsigned)((int)0x10000u < (int)0x47def97fu) | 1u))) goto L4;
        }
        switch (*q0 & 7u) {
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                u2 ^= (unsigned)(((unsigned)(w0 >> 29) % ((unsigned)l0 | 1u)) == 7u);
                h0 = (short)(unsigned)((unsigned)e0 < 0xffffffffu);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)*mp >= (int)p0), p0, (unsigned)((unsigned)b0 || 8u)); }
                w0 ^= (unsigned long long)(p1 + 3u) << ((g1 << ((unsigned)h0 & 31u)) & 63u);
            }
            case 1u: ;
            if (((unsigned)d0 + a0[u1 & 3u])) {
                if ((unsigned)((int)(unsigned)f0 >= (int)(5u ^ 0x80000000u))) break;
                case 4u: ;
            } else {
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)w0, (0x391fab70u + u0), (unsigned)((unsigned)c1 && (unsigned)((unsigned)l0 || (unsigned)h0))); }
                    u3 += ~(~(unsigned)((unsigned)(x0 >> 70) || (unsigned)(signed char)(unsigned)((unsigned)b0 && u3)) & 0x777eb474u);
                    case 0u: ;
                } while (i0++ < 7u && ((0xe1d354f9u - 0x80000000u) / (0xfa79e4e4u | 1u)));
                goto L0;
            }
        }
    }
    v0 = (unsigned)(0x7fffffffu == (0x80000000u ^ (unsigned)((unsigned)b0 || p0)));
    while (i0++ < 3u && (unsigned)s0) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + ((unsigned)s0 / (i0 | 1u)));
        if ((unsigned)((int)p0 >= (int)~(unsigned)(a0[i0 & 3u] < 0xb4989908u))) {
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)s1, r0.y, ((unsigned)((short)0x80000000u > (signed char)p2) * 0xdb91b3a2u)); }
                garr[(p2 % ((unsigned)f0 | 1u)) & 7u] = (g1 / (u1 | 1u));
                i0 = (unsigned)(short)(unsigned)(0xffffffffu == 0x3e1181a1u) & 15u;
                do { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)(((0xffffffffu >> (7u & 31u)) - (unsigned)f0) & 1023u);
                    e0 = e0 * 0.5L + (long double)((unsigned)s0 & 1023u);
                } while (i2++ < 4u && (unsigned)((int)(unsigned)l0 >= (int)(0x92c1ce9cu | (unsigned)f0)));
                g0 = (unsigned)(a0[u1 & 3u] || 0x10000u);
            }
            switch ((0xe27e8b49u & garr[i1 & 7u]) & 7u) {
                d0 = d0 * 0.5 + (double)(((unsigned)(x0 >> 70) - (*q0 - p0)) & 1023u);
                case 6u: ;
                m0 ^= (unsigned)(g1 < (unsigned)l0);
            }
        }
        if ((unsigned)!(u2 << ((unsigned)c1 & 31u))) {
            f0 = f0 * 0.5f + (float)((unsigned)b0 & 255u);
        }
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= ((unsigned)((int)3u < (int)0xd2b0fa3au) - *mp);
        if ((0x7fffffffu ^ (unsigned)d0)) {
            continue; (void)((unsigned)((short)0x10000u > (signed char)(i1 ^ 0x10000u)));
            s1 = (int)((unsigned)s1 + (unsigned)(signed char)(0xffffffffu - (unsigned)((unsigned)s0 || 0x83b0e0beu)));
            if ((unsigned)((unsigned)s1 || (unsigned)(8u && (unsigned)(w0 >> 29)))) {
                *q0 += (unsigned)(i2 == (unsigned)(0x80000000u < u0));
            } else {
                v0 = (unsigned)(unsigned char)(u0 - garr[i1 & 7u]);
            }
            q0 = &garr[(unsigned)((unsigned)(x0 >> 70) == (unsigned)((unsigned)c0 && 0x10000u)) & 7u];
            if ((unsigned)e0) break;
        } else {
            break; (void)(((unsigned)d0 ? i2 : 0x10000u));
            if ((unsigned)(g1 < m0)) break;
        }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((int)g0 < (int)p2)) continue;
            c0 = (unsigned char)-(i1 << ((0xf74dab9fu >> (u0 & 31u)) & 31u));
            c1 = (signed char)(unsigned)s0;
            goto L3;
        } while (i1++ < 5u && 0x30ef5e8u);
        goto L2;
        switch ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)~(unsigned)(0x78ccff5au < 0xffffffffu)) & 7u) {
            { unsigned t0; double z0; if (((p1 * (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)r0.y))) & 1u) { t0 = (unsigned)(-(p0 & (unsigned)h0) == 4u); z0 = (double)((((unsigned)c1 << (0xf6f00d1u & 31u))) & 255u); } if (((p1 * (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)r0.y))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                if ((unsigned)(short)(8u ^ 8u)) goto L1;
                s0 = (int)(0x80000000u | (a0[i0 & 3u] % (i1 | 1u)));
                for (;;) { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        q0 = &garr[(p1 / (((unsigned)w0 ^ 5u) | 1u)) & 7u];
                        f0 = f0 * 0.5f + (float)((((unsigned)s0 >> ((unsigned)d0 & 31u)) | p2) & 255u);
                        goto L1;
                    }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)c1 && 9u), (i1 - (unsigned)(a0[u1 & 3u] || r0.x)), garr[u2 & 7u]); }
                if (((unsigned)b0 % (g0 | 1u))) {
                    case 5u: ;
                    case 7u: ;
                } else {
                    while (i1++ < 4u && (unsigned)(*q0 == (8u >> (0x10000u & 31u)))) { if (--fuel == 0u) goto done;
                        continue; (void)(0x1f44ea59u);
                        if ((unsigned)((unsigned)((short)i2 > (signed char)i0) || 2u)) goto L1;
                        i2 = -(unsigned)((int)u1 < (int)((unsigned)h0 << ((unsigned)w0 & 31u))) & 15u;
                        r0.y ^= ((0x80000000u << ((unsigned)h1 & 31u)) * (unsigned)(0x30d07d52u == 1u));
                        r0.x = ((i0 + p2) * (*q0 + 0x49ae4cc8u));
                        u3 = u3 * 0x9e3779b1u + 7u;
                    }
                    q0 = &garr[(0x8a075bd5u % ((unsigned)((short)1u > (signed char)-(unsigned)(p0 || (p1 + garr[u2 & 7u]))) | 1u)) & 7u];
                    if (budget != 0u) { budget -= 1u; u0 = fn0(0xffffffffu, (unsigned)(short)(unsigned)((unsigned)d0 && (0x10000u % (r0.y | 1u))), 9u); }
                }
                garr[r0.x & 7u] = (unsigned)((int)(unsigned)(u1 && (unsigned)(0u < (0xffffffffu * (unsigned)l0))) < (int)0x7fffffffu);
            }
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(0x7474cb2u & 0x10000u), (unsigned)s0, (a0[i0 & 3u] % (0xa24ecf7du | 1u))); }
                a0[(i0 / ((unsigned)h0 | 1u)) & 3u] = (((g1 << ((unsigned)c0 & 31u)) - garr[u2 & 7u]) * 0xfd336320u);
                default: ;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((a0[i0 & 3u] << (0u & 31u)) == u3), (unsigned)(0xa58d2be1u < (unsigned)(0u < u2)), (unsigned)((unsigned)x0 || a0[i0 & 3u])); }
                e0 = e0 * 0.5L + (long double)(((unsigned)l0 & u3) & 1023u);
            }
        }
    }
    e0 = e0 * 0.5L + (long double)((unsigned)((int)0x92f81f97u >= (int)fuel) & 1023u);
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0(~(unsigned)((unsigned)(x0 >> 70) || ((unsigned)h0 - 0x10000u)), (0x7fffffffu ^ (unsigned)b0), r0.x); }
        if (budget != 0u) { budget -= 1u; u3 = fn0(2u, (unsigned)(r0.y && (unsigned)c1), g0); }
        r0.y ^= (unsigned)(*mp || i0);
    }
    if (a0[u1 & 3u]) goto L3;
    q0 = &garr[((unsigned)((int)(v0 ? (unsigned)x0 : (unsigned)f0) >= (int)0x10000u) * 0x4f604dfbu) & 7u];
    *q0 += (unsigned)(signed char)((unsigned)c0 - 3u);
    switch (((unsigned)c0 ^ ~(garr[u2 & 7u] % ((unsigned)(x0 >> 70) | 1u))) & 7u) {
        if (u1) {
            h0 = (short)(unsigned)((unsigned)((short)5u > (signed char)0xffffffffu) < 0xc4ce1370u);
            a0[(unsigned)c0 & 3u] = ((garr[i1 & 7u] * (p2 / (u2 | 1u))) >> ((unsigned)((short)0xffffffffu > (signed char)(unsigned)b0) & 31u));
            break; (void)(*q0);
            switch ((unsigned)(signed char)(unsigned)(i0 < 0x8067582eu) & 7u) {
                do { if (--fuel == 0u) goto done;
                    case 7u: ;
                } while (i0++ < 2u && ((unsigned)(w0 >> 29) << ((unsigned)(signed char)(1u | p1) & 31u)));
                default: ;
                if ((unsigned)(w0 >> 29)) {
                    q0 = &garr[p2 & 7u];
                    if (((a0[u1 & 3u] + 0x7fffffffu) << ((unsigned)x0 & 31u))) break;
                    c0 = (unsigned char)(unsigned)(signed char)((i1 % (0x80000000u | 1u)) * (unsigned)((short)p0 > (signed char)(unsigned)s1));
                    while ((unsigned)w0) { if (--fuel == 0u) goto done;
                        u1 = (unsigned)(u2 < u2);
                        case 4u: ;
                        u3 = (m0 >> (u3 & 31u));
                    }
                    q0 = &garr[(((unsigned)c0 - 0x7fffffffu) / (0xbf8a38a1u | 1u)) & 7u];
                }
                if ((0x7fffffffu ? (unsigned)h1 : a0[i0 & 3u])) goto done;
                s1 = (int)((unsigned)s1 + (4u >> (6u & 31u)));
                s1 = (int)((unsigned)s1 + (unsigned)(0x72505133u || (unsigned)h1));
            }
            if ((unsigned)((int)r0.x < (int)p1)) goto L0;
        }
        u0 = (3u | ((fuel * p0) / (u0 | 1u)));
    }
    { unsigned t1; double z1; if (((unsigned)((unsigned)((short)i1 > (signed char)(unsigned)f0) == u3)) & 1u) { t1 = (unsigned)((short)(0x7fffffffu | (unsigned)s1) > (signed char)0x80000000u); z1 = (double)((*q0) & 255u); } if (((unsigned)((unsigned)((short)i1 > (signed char)(unsigned)f0) == u3)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        *q0 += (garr[i1 & 7u] | (0x1da70bfbu ^ i0));
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)0xd47def4du > (signed char)0x10000u), (unsigned)((unsigned)s1 == 0x80000000u), (0x7fffffffu + 0x5dd7f59cu)); }
        if ((unsigned)((unsigned)((unsigned)l0 || 0xffffffffu) == (unsigned)d0)) goto L0;
        *mp = ~(unsigned)((short)(unsigned)((unsigned)(1u < p2) < (unsigned)s1) > (signed char)g0);
    }
    do { if (--fuel == 0u) goto done;
        i0 = (unsigned)((unsigned)(unsigned char)(0xdc205f1u ? 0xffffffffu : -(r0.x * 5u)) < i2) & 15u;
        s1 = (int)((unsigned)s1 + (p1 / ((i0 / ((*q0 - 0x10000u) | 1u)) | 1u)));
        if (0x10000u) {
            d0 = d0 * 0.5 + (double)(-((i1 & 5u) | (unsigned)((unsigned)((unsigned)d0 || garr[i1 & 7u]) || 0x10000u)) & 1023u);
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)0xc6cf86f2u > (signed char)(unsigned)(0xffffffffu && (unsigned)l0))) break;
                break; (void)((unsigned)(p1 < (v0 / (p1 | 1u))));
                w0 = w0 * 6364136223846793005ull + (0xffffffffu * 0xffffffffu);
                *q0 += g0;
            }
            while (i1++ < 5u && g0) { if (--fuel == 0u) goto done;
                if ((g0 | (unsigned)((int)(unsigned)b0 >= (int)0xdecab570u))) break;
                g1 += (unsigned)(0xffffffffu == (*q0 % (0xa866e956u | 1u)));
            }
            s1 = (int)((unsigned)s1 + garr[i1 & 7u]);
        }
        break; (void)(garr[u2 & 7u]);
        w0 = w0 * 6364136223846793005ull + (p0 >> (((3u >> ((unsigned)(signed char)((unsigned)c0 * 7u) & 31u)) * *mp) & 31u));
    } while (i0++ < 3u && (u3 ^ (0xffffffffu << ((unsigned)(w0 >> 29) & 31u))));
    while ((u2 * garr[u2 & 7u])) { if (--fuel == 0u) goto done;
        if ((unsigned)w0) break;
        u3 = (i2 * 0x10000u);
        break; (void)(((unsigned)c1 << (i1 & 31u)));
        break; (void)(0x80000000u);
        switch ((unsigned)((unsigned)s0 < (unsigned)!(a0[u1 & 3u] + (unsigned)s1)) & 7u) {
            s0 = (int)(unsigned)(signed char)((unsigned)h0 << ((unsigned)((int)6u >= (int)(unsigned)(w0 >> 29)) & 31u));
            case 0u: ;
            u3 += (*mp ? (r0.y % (8u | 1u)) : fuel);
        }
        w0 ^= (unsigned long long)(unsigned)(short)((unsigned)s0 ^ (unsigned)h1) << (~(fuel << (((unsigned)(x0 >> 70) / ((unsigned)s1 | 1u)) & 31u)) & 63u);
    }
    while ((unsigned)((0x7fffffffu * (unsigned)l0) || p1)) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)w0, (unsigned)((unsigned)(g0 && a0[u1 & 3u]) == g1), ((unsigned)h1 / ((unsigned)f0 | 1u))); }
        if ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)!(unsigned)((int)(unsigned)w0 < (int)(unsigned)(x0 >> 70)))) goto L4;
    }
    if (i2) goto L4;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t2; double z2; if ((0xf93f56c7u) & 1u) { t2 = ((unsigned)w0 << (4u & 31u)); z2 = (double)((m0) & 255u); } if ((0xf93f56c7u) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            if (-(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)(short)((unsigned)(w0 >> 29) >> (garr[i1 & 7u] & 31u)))) break;
            c1 = (signed char)(i1 + (unsigned)((short)0x80000000u > (signed char)0x10000u));
            if (fuel) break;
        }
        while (((unsigned)((int)0u < (int)0xffffffffu) * 0xffffffffu)) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)(short)(unsigned)((int)0xffffffffu < (int)0xca32581du) << (fuel & 63u);
            h0 = (short)0x80000000u;
        }
        d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)(((unsigned)b0 * (unsigned)s0) && 0xc0af879au) < (int)3u) & 1023u);
        s0 = (int)(0x10000u - 0x7fffffffu);
        c0 = (unsigned char)a0[i0 & 3u];
    }
    for (;;) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0((((unsigned)c0 ^ (unsigned)s1) - fuel), (unsigned)(signed char)(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)((int)u0 >= (int)i2)), r0.x); }
        switch ((unsigned)((int)(unsigned)(0x80000000u || 0x1b67ae94u) < (int)v0) & 7u) {
            b0 = 0xffffffffu != 0u;
        }
        break; (void)(((unsigned)(signed char)(unsigned)(8u || 6u) << ((unsigned)h1 & 31u)));
        u2 = u2 * 0x9e3779b1u + u0;
        u2 += (unsigned)((unsigned)(signed char)(8u & 0x300046aau) && ((unsigned)s0 << ((unsigned)(m0 && 3u) & 31u)));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (0x533d2d71u) goto done;
    v0 = (0x80000000u ^ m0);
    if ((a0[i0 & 3u] & 2u)) goto L4;
    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)e0 && (unsigned)(signed char)(8u - ((unsigned)f0 | *mp))));
    if (m0) goto L0;
    if ((p1 ? (unsigned)b0 : v0)) {
        e0 = e0 * 0.5L + (long double)(((unsigned)((int)r0.x >= (int)0x7fffffffu) | (0x80000000u * p0)) & 1023u);
    } else {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)*q0 >= (int)u2), (unsigned)(u1 || p0), p2); }
            r0.y ^= ((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)x0) % ((unsigned)(g0 == (unsigned)s0) | 1u));
            w0 = w0 * 6364136223846793005ull + (unsigned)((garr[u2 & 7u] % ((unsigned)f0 | 1u)) || (unsigned)!(m0 | 0x95f24641u));
            u3 ^= (unsigned)(p1 && (unsigned)(unsigned char)(unsigned)((short)~((unsigned)h0 & garr[u2 & 7u]) > (signed char)a0[u1 & 3u]));
            r0.x = ((unsigned)((unsigned)d0 == m0) % ((m0 & 0x7fffffffu) | 1u));
            L0: if (--fuel == 0u) goto done;
        }
        if ((0x7fffffffu ^ (6u % (0x8203c78u | 1u)))) goto L0;
    }
    r0.x = ((unsigned)((int)((unsigned)h1 | (unsigned)d0) < (int)(unsigned)(0x809cccacu && 0u)) % (u1 | 1u));
    u3 = ~(garr[i1 & 7u] >> (u1 & 31u));
    { unsigned t0; double z0; if (((unsigned)(*mp && (unsigned)b0)) & 1u) { t0 = (unsigned)(i0 && ((unsigned)(x0 >> 70) >> (r0.x & 31u))); z0 = (double)(((unsigned)((short)(0xffffffffu & 0x10000u) > (signed char)(unsigned)d0)) & 255u); } if (((unsigned)(*mp && (unsigned)b0)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        w0 ^= (unsigned long long)(unsigned)((short)0x10000u > (signed char)v0) << ((a0[i0 & 3u] << ((unsigned)(garr[u2 & 7u] || (7u / ((0xffffffffu * 0xfd51faebu) | 1u))) & 31u)) & 63u);
        w0 ^= (unsigned long long)((unsigned)(w0 >> 29) & garr[i1 & 7u]) << ((unsigned)((u1 / (u0 | 1u)) == (unsigned)((int)(unsigned)s1 < (int)(unsigned)(0x64c65d34u < (unsigned)l0))) & 63u);
        u0 ^= (u3 & (p2 + (unsigned)((int)(0x5e8d9d6du & u2) < (int)(unsigned)b0)));
        l0 = (long)((unsigned long)l0 + u1);
        { unsigned t1; double z1; if ((8u) & 1u) { t1 = (unsigned)((short)((unsigned)e0 * 1u) > (signed char)(unsigned)s1); z1 = (double)((((unsigned)(x0 >> 70) % ((unsigned)w0 | 1u))) & 255u); } if ((8u) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            w0 ^= (unsigned long long)-(0xcbc53691u ^ u2) << (((unsigned)b0 - (a0[u1 & 3u] / ((unsigned)x0 | 1u))) & 63u);
            u1 ^= (unsigned)((short)4u > (signed char)p1);
            do { if (--fuel == 0u) goto done;
                if (((unsigned)d0 ^ (0x808d105fu >> (p0 & 31u)))) break;
                while (i1++ < 7u && ((a0[u1 & 3u] >> ((unsigned)b0 & 31u)) & (unsigned)s0)) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0xffffffffu + (unsigned)b0), i2, (unsigned)((unsigned)((int)g1 >= (int)0x10000u) < 0xb92f8bdfu)); }
                    if (budget != 0u) { budget -= 1u; u3 = fn1((u3 << ((unsigned)e0 & 31u)), p2, (unsigned)(u2 == 0x80000000u)); }
                    { unsigned t2; double z2; if ((((unsigned)((unsigned)f0 == i1) >> (0xb0504965u & 31u))) & 1u) { t2 = (i1 % (3u | 1u)); z2 = (double)(((unsigned)((short)(unsigned)h0 > (signed char)0xffffffffu)) & 255u); } if ((((unsigned)((unsigned)f0 == i1) >> (0xb0504965u & 31u))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                        continue; (void)(0x10000u);
                        if (g1) break;
                    }
                }
                if ((unsigned)(short)(~((unsigned)h0 / (0x10000u | 1u)) & p2)) break;
                c1 = (signed char)(u1 * (0x3e10aa25u & i1));
                w0 ^= (unsigned long long)0xffffffffu << ((a0[u1 & 3u] << (0x80000000u & 31u)) & 63u);
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    h0 = (short)((unsigned)!(g1 * (unsigned)c1) - (unsigned)((unsigned)e0 && garr[i1 & 7u]));
                    while (i2++ < 5u && (a0[i0 & 3u] << ((unsigned)s0 & 31u))) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)(0x7fffffffu ? 0x64f195d5u : (unsigned)((short)u3 > (signed char)0x7fffffffu));
                        g1 += (u1 * ~(unsigned)((unsigned)!(m0 - (u3 & 0u)) && (unsigned)(w0 >> 29)));
                        u1 = (unsigned)(signed char)(unsigned)((unsigned)((int)p1 >= (int)p0) < (unsigned)(short)(unsigned)((unsigned)((unsigned)f0 && u1) && 0x60d68617u));
                        g1 += p1;
                    }
                    goto L2;
                    e0 = e0 * 0.5L + (long double)((a0[i0 & 3u] ? u2 : (unsigned)s1) & 1023u);
                    continue; (void)(*q0);
                }
            } while (i0++ < 7u && 7u);
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((fuel ^ (unsigned)((short)u2 > (signed char)(unsigned)h0)) & 1023u);
                if (u3 == 7u) return 4u;
                e0 = e0 * 0.5L + (long double)((((unsigned)s1 * *q0) ? (p1 / ((unsigned)(x0 >> 70) | 1u)) : (unsigned)s0) & 1023u);
                v0 = (u1 & (u2 ? ((unsigned)l0 & garr[u2 & 7u]) : a0[u1 & 3u]));
                if ((unsigned)((short)9u > (signed char)r0.x)) {
                    if (v0) goto L4;
                    garr[4u & 7u] = 0x45346deu;
                } else {
                    L1: if (--fuel == 0u) goto done;
                }
                L2: if (--fuel == 0u) goto done;
            }
            if (((unsigned)b0 * (unsigned)(0x10000u < (unsigned)s0))) goto L4;
        }
    }
    goto L3;
    goto L1;
    if ((2u >> (6u & 31u))) {
        switch (((unsigned)c0 % (fuel | 1u)) & 7u) {
            goto L1;
            *q0 = (3u | i0);
            if (a0[i0 & 3u]) goto L2;
            u3 ^= (unsigned)(0x10000u == r0.x);
            break; (void)(0x8a1fcde8u);
        }
        while (i0++ < 3u && (unsigned)((unsigned)(w0 >> 29) && ~(unsigned)((unsigned)(w0 >> 29) < r0.x))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((((unsigned)e0 - r0.y) / (0xad265eb2u | 1u)), ((unsigned)d0 >> (p1 & 31u)), (unsigned)((unsigned)l0 == 0x20a9d9b7u)); }
            do { if (--fuel == 0u) goto done;
                if (~(g1 / (4u | 1u))) goto L1;
                r0.y ^= (unsigned)((int)(unsigned)(r0.y == 0xffffffffu) < (int)garr[i1 & 7u]);
                g0 = (unsigned)((0xa176600bu << (v0 & 31u)) < fuel);
                L3: if (--fuel == 0u) goto done;
                h0 = (short)((unsigned)!((unsigned)(x0 >> 70) % ((unsigned)s1 | 1u)) >> ((unsigned)h1 & 31u));
            } while (i1++ < 4u && ((0xffffffffu | (unsigned)c0) - (unsigned)x0));
            if ((unsigned)f0) {
                L4: if (--fuel == 0u) goto done;
                if (0x7fffffffu) break;
                break; (void)(i0);
            }
            if ((unsigned)c1) break;
            if ((3u / ((unsigned)(0x80000000u < m0) | 1u))) break;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((0xe010a547u / (0u | 1u)) || 0x10000u), (unsigned)(r0.y && (unsigned)!(unsigned)(u1 < 0xffffffffu)), (unsigned)(signed char)(u3 / ((unsigned)(w0 >> 29) | 1u))); }
        }
        a0[(unsigned)!(8u << (u3 & 31u)) & 3u] = (unsigned)(0x79bfb238u == 0x815f70a0u);
        if (budget != 0u) { budget -= 1u; u2 = fn1(4u, (unsigned)(unsigned char)(unsigned)((int)garr[u2 & 7u] < (int)(unsigned)c0), (unsigned)(fuel == (unsigned)x0)); }
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(m0 || (unsigned)w0), (garr[i1 & 7u] & (unsigned)w0), (0u >> (((unsigned)d0 * (unsigned)s0) & 31u))); }
    }
    if (((unsigned)l0 + (g1 >> (u2 & 31u)))) goto L0;
    u0 = (unsigned)(m0 || (unsigned)(a0[i0 & 3u] || 0xffffffffu));
    *mp = (unsigned)((unsigned)((int)(unsigned)w0 < (int)*mp) < (unsigned)s1);
    while (i0++ < 3u && 0xffffffffu) { if (--fuel == 0u) goto done;
        g0 = (unsigned)(short)(unsigned)((unsigned)h1 || 0x10000u);
        i0 = (unsigned)((i2 >> ((unsigned)(unsigned char)((unsigned)b0 >> (garr[i1 & 7u] & 31u)) & 31u)) || 0xd1092c6du) & 15u;
        g1 += ((a0[u1 & 3u] ^ (unsigned)(short)(unsigned)((unsigned)(m0 && i1) || a0[u1 & 3u])) & v0);
        a0[(unsigned)(x0 >> 70) & 3u] = ((unsigned)b0 / (p2 | 1u));
        u3 = (unsigned)((*q0 % (a0[i0 & 3u] | 1u)) || (unsigned)((int)(garr[i1 & 7u] % (0x16f20a85u | 1u)) >= (int)(unsigned)h0));
    }
    s0 = (int)(unsigned)(a0[i0 & 3u] || 9u);
    if ((unsigned)l0) goto L1;
    h1 = (unsigned short)(h1 + (u1 ? (unsigned)e0 : garr[u2 & 7u]));
    goto L1;
    c1 = (signed char)(r0.x % (a0[u1 & 3u] | 1u));
    h1 = (unsigned short)(h1 + (0xffffffffu | 0x80000000u));
    u1 = (2u | (unsigned)s0);
    d0 = d0 * 0.5 + (double)((unsigned)!((unsigned)f0 + (unsigned)x0) & 1023u);
    b0 = (unsigned)((short)m0 > (signed char)0xc84fc7d7u) != 0u;
    goto L3;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(((unsigned)d0 | (unsigned)c0) < i1)) goto L3;
        if ((unsigned)((unsigned)((short)u2 > (signed char)u1) == g1)) goto L4;
        if (u3) {
            b0 = 0x80000000u != 0u;
            if ((9u * (unsigned)((unsigned)s0 || 0u))) break;
            break; (void)((unsigned)b0);
            i2 = (unsigned)((unsigned)(4u && 0xb8271ab4u) && u2) & 15u;
            switch ((unsigned)((short)-(unsigned)(9u < (unsigned)l0) > (signed char)0x720c15bau) & 7u) {
                a0[6u & 3u] = (unsigned)((short)(a0[i0 & 3u] - (a0[i0 & 3u] - 3u)) > (signed char)v0);
                if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)b0 & (5u & (unsigned)x0)), ((unsigned)((unsigned)(w0 >> 29) && 5u) << (a0[i0 & 3u] & 31u)), 8u); }
            }
            if ((unsigned)((short)(unsigned)h1 > (signed char)0x7fffffffu)) break;
        }
    } while (i0++ < 7u && (unsigned)b0);
    switch (a0[i0 & 3u] & 7u) {
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s1 >> ((unsigned)(r0.x && u1) & 31u)), (*mp ? 0x9a4afca6u : (unsigned)x0), ((unsigned)(u2 < m0) - 7u)); }
        case 7u: ;
    }
    *q0 = (7u >> (u1 & 31u));
    if (0x10000u) {
        e0 = e0 * 0.5L + (long double)((i2 - *q0) & 1023u);
    } else {
        if (budget != 0u) { budget -= 1u; u1 = fn0((((unsigned)w0 % ((unsigned)s1 | 1u)) >> (garr[u2 & 7u] & 31u)), 0x7fffffffu, 0x2afcb3d2u); }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t3; double z3; if (((p1 >> ((unsigned)(r0.x == 0x7fffffffu) & 31u))) & 1u) { t3 = (unsigned)((short)(0xffffffffu & p1) > (signed char)8u); z3 = (double)((((unsigned)(p2 < (unsigned)s0) - i0)) & 255u); } if (((p1 >> ((unsigned)(r0.x == 0x7fffffffu) & 31u))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                if ((unsigned)(w0 >> 29)) break;
                if (((unsigned)f0 + 0x7fffffffu)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((i2 % ((unsigned)w0 | 1u)) < 0x2c7a4aa5u), p0, (unsigned)!((unsigned)c0 / (0xffffffffu | 1u))); }
                v0 = r0.y;
            }
            f0 = f0 * 0.5f + (float)((unsigned)(x0 >> 70) & 255u);
            if ((9u * (unsigned)((unsigned)s0 < a0[u1 & 3u]))) break;
            if ((unsigned)(p1 && r0.x)) goto L2;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)c0 == r0.x), (unsigned)(short)(0xffffffffu ? (unsigned)(x0 >> 70) : g0), ~(2u % ((unsigned)((short)p0 > (signed char)(unsigned)e0) | 1u))); }
        }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch (0xffffffffu & 7u) {
                while (i1++ < 2u && (0x4e435100u % (0x80000000u | 1u))) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(*mp, ((unsigned)(unsigned char)(p1 >> (3u & 31u)) | garr[i1 & 7u]), (v0 ^ (unsigned)((int)0x5f42c49du < (int)*q0))); }
                }
            }
        }
    }
    if ((unsigned)w0) goto L2;
    do { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + 0x7fffffffu);
        if (((unsigned)(short)(i0 & i1) + u0)) {
            if (i0) break;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((9u + (0x41f949a7u - 0xcb3d3663u))) break;
                g0 = (unsigned)(short)(0x686a03d1u % ((unsigned)c1 | 1u));
                u1 ^= ((0x2e26cc20u >> (*mp & 31u)) | i0);
                switch ((unsigned)h0 & 7u) {
                    q0 = &garr[*q0 & 7u];
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(0u || 0x6e23ae1eu), (unsigned)(((unsigned)c0 - (unsigned)s1) || a0[i0 & 3u]), 0x7fffffffu); }
                }
                b0 = (garr[i1 & 7u] * ((0xffffffffu / ((unsigned)h0 | 1u)) - (0x7fffffffu + u3))) != 0u;
            }
            if ((0x10000u | -(unsigned)((int)r0.y >= (int)(unsigned)s0))) break;
            if ((unsigned)((short)0xffffffffu > (signed char)a0[i0 & 3u])) continue;
        } else {
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(0xefe6a375u == 1u)) break;
                c0 = (unsigned char)((unsigned)w0 & ((unsigned)l0 * (unsigned)x0));
            } while (i1++ < 4u && g0);
            if ((garr[u2 & 7u] - 0x12043dcau)) {
                *q0 += (unsigned)((int)a0[i0 & 3u] >= (int)p2);
                do { if (--fuel == 0u) goto done;
                    garr[0xffffffffu & 7u] = 0xe0be43fdu;
                    u1 = u1 * 0x9e3779b1u + (unsigned)s1;
                } while (i1++ < 7u && (((unsigned)c1 / (0x516a00c8u | 1u)) + (unsigned)w0));
                w0 = w0 * 6364136223846793005ull + (garr[i1 & 7u] ^ (unsigned)d0);
                break; (void)(((unsigned)(x0 >> 70) << (i2 & 31u)));
                u2 += (g0 << (0xa2f668bdu & 31u));
                if (((0x644ad958u | v0) & u1)) break;
            }
            while (i1++ < 2u && (unsigned)(short)(unsigned)((int)(unsigned)c0 >= (int)(unsigned)(signed char)((unsigned)x0 ^ garr[u2 & 7u]))) { if (--fuel == 0u) goto done;
                while (i2++ < 2u && (unsigned)c1) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(u3, (unsigned)((unsigned)s0 < 0xffffffffu), (0x8d2869d7u * (unsigned)((int)p0 < (int)0xffffffffu))); }
                    if (fuel) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)(r0.x - (unsigned)b0), (*mp % ((unsigned)x0 | 1u)), (unsigned)((int)9u >= (int)(unsigned)(a0[u1 & 3u] == (unsigned)f0))); }
                    *q0 = ((unsigned)(unsigned char)(unsigned)((int)(unsigned)h0 >= (int)0xd36a557eu) ^ (u1 + 0xb33356f7u));
                    switch ((unsigned)((unsigned)(x0 >> 70) && (unsigned)c0) & 7u) {
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)b0 == (unsigned)((short)g0 > (signed char)3u)), (unsigned)((int)0x58bb8ef2u >= (int)(unsigned)l0), *mp); }
                        *q0 = (unsigned)((short)i1 > (signed char)(unsigned)(((unsigned)w0 << ((unsigned)h1 & 31u)) && (1u + 0x4432357fu)));
                        u2 = u2 * 0x9e3779b1u + (unsigned)(0x80000000u == 0x84924709u);
                        f0 = f0 * 0.5f + (float)(((0x80000000u / (3u | 1u)) ^ (unsigned)(a0[u1 & 3u] < u2)) & 255u);
                    }
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(~(((unsigned)s1 << (0x7fffffffu & 31u)) * p2), p1, (unsigned)(0x10000u && (unsigned)c0)); }
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    garr[(u3 - (unsigned)b0) & 7u] = *mp;
                    if ((0x1fdb233au * 0x10000u)) break;
                }
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)h1) break;
                    r0.y ^= (u2 & (unsigned)!((unsigned)e0 | 0x10000u));
                    f0 = f0 * 0.5f + (float)(*mp & 255u);
                    while (i0++ < 7u && ((unsigned)!(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)s0) * (unsigned)d0)) { if (--fuel == 0u) goto done;
                        u2 += ((unsigned)w0 >> ((0x10000u | (unsigned)(w0 >> 29)) & 31u));
                        u0 ^= (unsigned)(short)(0u - ((unsigned)(unsigned char)(unsigned)((int)6u >= (int)(unsigned)h1) | 7u));
                        w0 ^= (unsigned long long)(unsigned)s0 << ((0xb6ecfdafu * garr[u2 & 7u]) & 63u);
                        goto L4;
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)h1 < (int)(unsigned)s0), u3, (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)h0)); }
                }
                l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(unsigned)((int)0xffffffffu < (int)0x5f0a53d6u));
                v0 = (unsigned)(garr[u2 & 7u] || 0xdc8571u);
            }
            if (fuel) {
                h1 = (unsigned short)(h1 + (0x7fffffffu ^ (unsigned)(short)(unsigned)(a0[u1 & 3u] < 0x80000000u)));
                if (u3 == 7u) return (i0 / ((5u ^ i2) | 1u));
                *mp = (0xfb37683fu ^ p2);
                s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(signed char)((unsigned)(x0 >> 70) & g0) == (0xffffffffu / (u3 | 1u))));
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if (((u3 / ((unsigned)c1 | 1u)) - (unsigned)w0)) break;
                        w0 ^= (unsigned long long)0x80000000u << ((unsigned)s0 & 63u);
                        do { if (--fuel == 0u) goto done;
                            x0 = x0 * 0x100000001b3ull + (unsigned)(w0 >> 29);
                            a0[((unsigned)c1 >> (i1 & 31u)) & 3u] = (p2 % (u0 | 1u));
                            if ((unsigned)(signed char)(p0 << ((unsigned)c0 & 31u))) break;
                            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)c0 / ((unsigned)s0 | 1u)), (0x10000u >> ((unsigned)c0 & 31u)), (0x10000u + u0)); }
                            *q0 += (*mp << (((0x58f1972u * 0x9b87413du) >> ((unsigned)(u3 == fuel) & 31u)) & 31u));
                            r0.x = (unsigned)(unsigned char)(unsigned)((int)0xffffffffu >= (int)(*q0 ? 3u : (unsigned)s0));
                        } while (i0++ < 2u && (unsigned)((short)(unsigned)!(0u & p1) > (signed char)(unsigned)h0));
                        if (budget != 0u) { budget -= 1u; u3 = fn1(0x80000000u, ((unsigned)s1 * (unsigned)((int)0u >= (int)(unsigned)x0)), 0x543f9e24u); }
                        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                            if ((unsigned)((int)(unsigned)((unsigned)(w0 >> 29) && 0xffffffffu) < (int)(unsigned)s0)) break;
                            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)w0, (unsigned)(a0[i0 & 3u] || v0), (m0 - a0[i0 & 3u])); }
                            if ((unsigned)((unsigned)(x0 >> 70) < 0x2a155293u)) goto L2;
                            if ((unsigned)(x0 >> 70)) break;
                            u3 += (unsigned)((unsigned)(x0 >> 70) == ((unsigned)c0 - (0x80000000u << (u0 & 31u))));
                            if (budget != 0u) { budget -= 1u; u1 = fn0(0x10000u, (u2 * 0x7fffffffu), (unsigned)((unsigned)c1 || (unsigned)(0x4ab3ea71u < 0xad261b4du))); }
                        }
                        if (7u) break;
                    } while (i2++ < 7u && (p1 / ((unsigned)s1 | 1u)));
                    { unsigned t4; double z4; if ((i0) & 1u) { t4 = ((unsigned)((int)*mp < (int)m0) << (0xffffffffu & 31u)); z4 = (double)(((unsigned)(*q0 || 5u)) & 255u); } if ((i0) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                        u2 ^= (unsigned)((int)(unsigned)((int)u1 >= (int)u2) < (int)(unsigned)((short)(7u ^ 0xffffffffu) > (signed char)r0.x));
                    }
                    r0.x = (unsigned)((int)p2 >= (int)r0.y);
                }
                s0 = (int)(unsigned)((short)(unsigned)!(unsigned)((unsigned)c1 || u2) > (signed char)0x7fffffffu);
            } else {
                *mp = ((unsigned)(2u == p0) - (unsigned)(x0 >> 70));
            }
        }
        { unsigned t5; double z5; if ((((unsigned)(p1 || i1) << (*q0 & 31u))) & 1u) { t5 = (unsigned)((unsigned)b0 || 9u); z5 = (double)((((unsigned)((int)0xc0b3ad6eu < (int)(unsigned)(w0 >> 29)) - *q0)) & 255u); } if ((((unsigned)(p1 || i1) << (*q0 & 31u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                i2 = u2 & 15u;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s1, u0, 2u); }
            }
            g1 += (unsigned)((unsigned)l0 == i2);
            c0 = (unsigned char)(r0.y * *q0);
            c1 = (signed char)((unsigned)!(unsigned)(p1 && 0xbf47c213u) + 0x80000000u);
        }
    } while (i0++ < 6u && -(a0[i0 & 3u] & 0x7fffffffu));
    if (m0) goto done;
    if ((i2 + 0x15d78f09u)) goto L4;
    e0 = e0 * 0.5L + (long double)((0xd4a992a5u ^ (u2 ^ 5u)) & 1023u);
    goto L0;
    { unsigned t6; double z6; if ((5u) & 1u) { t6 = (unsigned)((unsigned)c1 || (unsigned)((short)(unsigned)h0 > (signed char)p1)); z6 = (double)(((unsigned)((int)(unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)e0) < (int)u0)) & 255u); } if ((5u) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        u1 = ((unsigned)(x0 >> 70) % ((u3 ^ garr[i1 & 7u]) | 1u));
    }
    *q0 += 0xbfe9b24au;
    if (((unsigned)w0 ? 7u : p1)) goto L1;
    *q0 += ((unsigned)b0 - u1);
    v0 = (unsigned)((short)((unsigned)((unsigned)w0 && 0xffffffffu) >> (m0 & 31u)) > (signed char)0x80000000u);
    if (0x80000000u) {
        r0.x = ((unsigned)((short)g1 > (signed char)1u) / ((0x5bbffe75u - (unsigned)s0) | 1u));
        u0 ^= ((-(0x10000u % (r0.x | 1u)) & g1) / (*q0 | 1u));
    } else {
        r0.x = (u3 - (m0 ? 0x80000000u : (unsigned)((unsigned)w0 || (unsigned)c0)));
    }
    i2 = (g0 / ((unsigned)((unsigned)x0 && a0[i0 & 3u]) | 1u)) & 15u;
    if (((unsigned)s1 >> (((unsigned)c0 ^ 0x7fffffffu) & 31u))) {
        u2 = (garr[u2 & 7u] - i2);
        r0.y ^= (unsigned)c0;
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)5u >= (int)0xc5896e2eu), ((unsigned)s1 * 3u), (unsigned)(x0 >> 70)); }
        g0 = (unsigned)(short)(unsigned)((int)((unsigned)x0 & (unsigned)w0) >= (int)(unsigned)(unsigned char)(unsigned)((int)i2 < (int)p0));
        { unsigned t7; double z7; if (((0x80000000u << (0x5d2bafe4u & 31u))) & 1u) { t7 = 0xebb2d1cfu; z7 = (double)(((0xffffffffu | (8u >> (i1 & 31u)))) & 255u); } if (((0x80000000u << (0x5d2bafe4u & 31u))) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return (u3 >> (((p2 ^ 0x80000000u) ? 0x5672e13fu : *q0) & 31u));
                { unsigned t8; double z8; if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)*q0)) & 1u) { t8 = 0x679a545u; z8 = (double)((~(unsigned)(5u == (u2 >> (i1 & 31u)))) & 255u); } if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)*q0)) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                    if (((*q0 >> ((unsigned)f0 & 31u)) << (*mp & 31u))) goto L4;
                    c0 = (unsigned char)(unsigned)(unsigned char)((unsigned)c0 % (-(unsigned)((unsigned)b0 || (unsigned)h0) | 1u));
                    r0.y ^= (unsigned)((unsigned)((unsigned)d0 < u3) || (2u << (i1 & 31u)));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)w0, u0, garr[u2 & 7u]); }
                if ((unsigned)((short)0xb7ad48b9u > (signed char)(unsigned)(garr[i1 & 7u] == i1))) continue;
                *q0 += (unsigned)((unsigned)b0 == (unsigned)f0);
                f0 = f0 * 0.5f + (float)((garr[u2 & 7u] >> (m0 & 31u)) & 255u);
            }
            { unsigned t9; double z9; if ((r0.x) & 1u) { t9 = u1; z9 = (double)((0xffffffffu) & 255u); } if ((r0.x) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                c0 = (unsigned char)(unsigned)((short)((0u >> ((unsigned)e0 & 31u)) - 0x73cd7950u) > (signed char)(unsigned)(a0[u1 & 3u] || p1));
                u1 = u1 * 0x9e3779b1u + (i0 * u2);
            }
            if ((unsigned)(p2 || (*mp & 5u))) {
                if ((unsigned)h0) goto L2;
                if ((0x57135acau & u2)) goto L0;
                do { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((6u | (unsigned)s0) & 1023u);
                    while ((((unsigned)e0 << (0x7fffffffu & 31u)) / (p1 | 1u))) { if (--fuel == 0u) goto done;
                        switch ((3u * u2) & 7u) {
                            if (budget != 0u) { budget -= 1u; u3 = fn1(p0, 0xffffffffu, ((unsigned)h0 / (*q0 | 1u))); }
                        }
                        if ((unsigned)c1) goto L1;
                        break; (void)((unsigned)((int)*mp < (int)(unsigned)c0));
                        if (-(i2 | 0x4ad531e7u)) goto L3;
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn1((0x120b4a9cu << (0xc54cba37u & 31u)), ((unsigned)d0 + 5u), (u2 / (g1 | 1u))); }
                } while (i0++ < 3u && v0);
                if ((g0 | ((unsigned)x0 * (unsigned)s1))) goto L3;
                s1 = (int)((unsigned)s1 + (u3 % ((unsigned)h0 | 1u)));
                goto L0;
            }
        }
    }
    c0 = (unsigned char)(unsigned)d0;
    if ((0x7fffffffu ^ (i0 | (unsigned)b0))) {
        s1 = (int)((unsigned)s1 + (((unsigned)h1 | (a0[i0 & 3u] % ((unsigned)h0 | 1u))) >> ((r0.y ^ (unsigned)w0) & 31u)));
        while (i0++ < 7u && i0) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0x94581f68u || (u0 % ((unsigned)x0 | 1u))), (*mp >> (p0 & 31u)), (unsigned)!(unsigned)((int)(unsigned)b0 < (int)(unsigned)l0)); }
        }
        g1 += (unsigned)((int)(unsigned)!((i0 / (a0[u1 & 3u] | 1u)) << ((u2 * (unsigned)c1) & 31u)) < (int)5u);
        u3 = (0x22448f3cu / (1u | 1u));
        if (((unsigned)w0 * 0x7fffffffu)) {
            if ((unsigned)((unsigned)l0 == ((unsigned)f0 | (unsigned)s0))) goto L1;
        } else {
            if ((i2 * r0.y)) goto L0;
            u1 = u1 * 0x9e3779b1u + (unsigned)c0;
        }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(((unsigned)(x0 >> 70) + u1) == m0)) goto L3;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((int)-(unsigned)(u1 || 0x80000000u) >= (int)0x10000u)) {
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)(0x80000000u & 1023u);
                        if (budget != 0u) { budget -= 1u; u3 = fn1(0x5bce273au, (unsigned)(g1 < ((unsigned)h0 - 0xf9ddb8c7u)), u2); }
                        h1 = (unsigned short)(h1 + (9u + (i2 >> ((unsigned)e0 & 31u))));
                        b0 = (r0.x | (unsigned)((int)r0.x < (int)(v0 << ((unsigned)((int)0xb4bcb34eu < (int)(unsigned)s1) & 31u)))) != 0u;
                        do { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn1((0x7fffffffu / (-((unsigned)s0 * r0.y) | 1u)), (i0 % (0xffffffffu | 1u)), ((unsigned)x0 | 8u)); }
                            if ((*mp * 0xffffffffu)) break;
                            if ((unsigned)(unsigned char)((unsigned)d0 + (unsigned)((short)r0.y > (signed char)3u))) continue;
                        } while (i0++ < 4u && ((0x7fffffffu + (unsigned)(x0 >> 70)) * u1));
                        f0 = f0 * 0.5f + (float)(((unsigned)((int)i0 < (int)0x24fc11e0u) + ((unsigned)(9u && u3) / (*mp | 1u))) & 255u);
                    }
                    s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)e0 < (int)i1));
                    i0 = (i0 ^ (((unsigned)(x0 >> 70) % (i0 | 1u)) & u1)) & 15u;
                    l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(unsigned)((unsigned)((int)u0 >= (int)(unsigned)(p2 || 0xffffffffu)) && r0.x));
                    if (budget != 0u) { budget -= 1u; u3 = fn1(4u, (unsigned)!(unsigned)((int)(p0 / (0x7fffffffu | 1u)) < (int)0x7fffffffu), v0); }
                } else {
                    break; (void)((*mp >> ((unsigned)((short)0x10000u > (signed char)(unsigned)w0) & 31u)));
                    q0 = &garr[(unsigned)((unsigned)((int)(unsigned)l0 >= (int)(0xd3680234u ? i2 : 9u)) || 0xe2f7d131u) & 7u];
                    q0 = &garr[(unsigned)((unsigned)b0 || (a0[u1 & 3u] + garr[u2 & 7u])) & 7u];
                    u2 ^= (unsigned)((unsigned)!(p2 ^ a0[i0 & 3u]) < (unsigned)((int)fuel < (int)i1));
                }
            } while (i1++ < 5u && (unsigned)(signed char)(r0.x >> (garr[i1 & 7u] & 31u)));
            if ((unsigned)w0) {
                w0 = w0 * 6364136223846793005ull + (0x80000000u + (0x6b8eff91u | ((unsigned)(w0 >> 29) & i0)));
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)!(((unsigned)f0 + 1u) >> ((unsigned)s0 & 31u)), (0xee29af85u + (0x10000u - 0xe977bd18u)), ~(unsigned)(2u == (unsigned)(0x4a265864u == a0[u1 & 3u]))); }
            }
            if ((unsigned)(i0 == ((unsigned)h0 + g0))) break;
        } while (i0++ < 4u && (unsigned)((int)*mp < (int)(unsigned)c0));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if ((0x80000000u) & 1u) { t0 = (unsigned)((int)(unsigned)(unsigned char)(unsigned)(0xffffffffu < (unsigned)h0) >= (int)u0); z0 = (double)(((unsigned)(short)(0x10000u * p2)) & 255u); } if ((0x80000000u) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        if (((unsigned)h1 ^ 0x80000000u)) {
            goto L1;
            s0 = (int)(unsigned)((int)fuel >= (int)0x10000u);
            a0[((unsigned)f0 / (0xffffffffu | 1u)) & 3u] = (unsigned)(fuel && (unsigned)(3u == (unsigned)((0x10000u + 0x216fde95u) == i2)));
        }
        goto L0;
        i2 = (unsigned)c1 & 15u;
        u3 = (0xffffffffu - p1);
        if ((unsigned)((short)(p1 % (garr[u2 & 7u] | 1u)) > (signed char)0xec8e04c8u)) goto L4;
        if ((unsigned)(1u < (i2 / ((unsigned)c0 | 1u)))) {
            h1 = (unsigned short)(h1 + (unsigned)((unsigned)((int)(p0 << (r0.y & 31u)) < (int)g0) && (unsigned)(a0[i0 & 3u] == (unsigned)e0)));
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)((unsigned)d0 && u1) < p1), ((unsigned)l0 << ((unsigned)(x0 >> 70) & 31u)), (0x8be2b19cu ? (unsigned)(w0 >> 29) : p0)); }
            if (u3) goto L3;
        } else {
            i0 = (unsigned)((unsigned)((int)(unsigned)((int)(0x35f9dbd7u ^ (unsigned)x0) < (int)u0) < (int)*q0) || 0xfecd3ca4u) & 15u;
            switch ((0x12278820u << ((unsigned)l0 & 31u)) & 7u) {
                g0 = a0[i0 & 3u];
                if ((unsigned)((int)(0x80000000u % (4u | 1u)) >= (int)(unsigned)w0)) {
                    g1 += (unsigned)h0;
                    s1 = (int)((unsigned)s1 + (unsigned)!(unsigned)((int)(i2 * (unsigned)((int)(unsigned)(w0 >> 29) >= (int)g0)) < (int)r0.x));
                    while ((unsigned)c0) { if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(unsigned)((int)(i2 >> (a0[i0 & 3u] & 31u)) >= (int)((unsigned)e0 % (u2 | 1u))) & 1023u);
                        *q0 = 7u;
                    }
                    u2 = ((unsigned)(w0 >> 29) - (unsigned)(0u || 0xc3a12264u));
                }
                h1 = (unsigned short)(h1 + (unsigned)((int)0xb52f374eu >= (int)(0x10000u + 3u)));
                { unsigned t1; double z1; if (((unsigned)s0) & 1u) { t1 = (a0[u1 & 3u] ^ g1); z1 = (double)((0xff8c0de3u) & 255u); } if (((unsigned)s0) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    m0 ^= (unsigned)((*q0 | (unsigned)h0) == (unsigned)s0);
                    a0[u1 & 3u] = (unsigned)((int)(8u % (i1 | 1u)) >= (int)(unsigned)((unsigned)l0 == a0[u1 & 3u]));
                    case 1u: ;
                }
                c0 = (unsigned char)(unsigned)((short)(unsigned)((int)*mp >= (int)(unsigned)(p2 || (unsigned)(x0 >> 70))) > (signed char)0x80000000u);
            }
            w0 = w0 * 6364136223846793005ull + (0xde28ba67u << ((u0 << (*q0 & 31u)) & 31u));
        }
    }
    *q0 += ~((unsigned)((unsigned)d0 && u3) | (unsigned)b0);
    goto L2;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)h0) break;
        for (;;) { if (--fuel == 0u) goto done;
            goto L0;
            if (((g0 + 0u) - p1)) break;
            while (i2++ < 7u && (unsigned)(p0 == (*q0 << (garr[u2 & 7u] & 31u)))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(0x7fffffffu, (unsigned)c0, g0); }
            }
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (i1) break;
                L0: if (--fuel == 0u) goto done;
                if ((unsigned)((int)garr[i1 & 7u] >= (int)0x963921e6u)) goto L2;
            }
            q0 = &garr[5u & 7u];
        }
        *q0 += (unsigned)(u0 == (unsigned)(signed char)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)fuel));
        a0[(unsigned)(9u == (unsigned)c1) & 3u] = (2u & (unsigned)(0x80000000u == (unsigned)w0));
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)d0) break;
        }
    } while (i0++ < 7u && (0x80000000u % (m0 | 1u)));
    *q0 = ((unsigned)(short)(unsigned)((unsigned)(x0 >> 70) == i1) % (0x80000000u | 1u));
    if (a0[i0 & 3u]) {
        for (;;) { if (--fuel == 0u) goto done;
            if (i1) goto L4;
            if (budget != 0u) { budget -= 1u; u3 = fn0(a0[u1 & 3u], (0xbf8e0e60u >> ((unsigned)(u2 && garr[i1 & 7u]) & 31u)), a0[u1 & 3u]); }
        }
        if (0u) goto L1;
        if (budget != 0u) { budget -= 1u; u0 = fn1((0x10000u ? 0xffffffffu : (unsigned)w0), ((unsigned)(w0 >> 29) | (unsigned)(w0 >> 29)), (0xf48a5920u % (0x4a8c20d1u | 1u))); }
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (-(unsigned)((unsigned)((int)i1 < (int)r0.x) && u0)) continue;
        do { if (--fuel == 0u) goto done;
            if ((g1 ^ i1)) break;
            r0.y ^= i2;
            u2 ^= (unsigned)w0;
        } while (i1++ < 7u && (unsigned)(((unsigned)h0 ^ u3) < 0u));
        m0 ^= (unsigned)(((unsigned)((short)v0 > (signed char)(unsigned)(x0 >> 70)) | fuel) < ((unsigned)(x0 >> 70) / ((unsigned)(x0 >> 70) | 1u)));
        u2 += (unsigned)((short)(unsigned)d0 > (signed char)(unsigned)!(0x10000u * p0));
        if (garr[u2 & 7u]) continue;
        d0 = d0 * 0.5 + (double)((unsigned)e0 & 1023u);
    }
    L1: if (--fuel == 0u) goto done;
    if ((i1 - 0xa656daabu)) goto L2;
    u0 += ((0x9bfe2d38u >> ((unsigned)c0 & 31u)) >> ((unsigned)(short)(7u ? 0x9d53c2d8u : i0) & 31u));
    f0 = f0 * 0.5f + (float)((i0 + 5u) & 255u);
    if (p2) goto L1;
    goto done;
    switch ((u0 + u0) & 7u) {
        c1 = (signed char)(unsigned)!(unsigned)(0xc7972811u && ((unsigned)b0 - (unsigned)h0));
        c0 = (unsigned char)(unsigned)(((unsigned)((int)(unsigned)h0 >= (int)(unsigned)e0) + (unsigned)((int)u2 >= (int)0x7fffffffu)) && 6u);
        switch ((unsigned)(signed char)(unsigned)((short)(unsigned)h0 > (signed char)*mp) & 7u) {
            case 1u: ;
            L2: if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(0x1c3fb41cu >> (0xd7c990b5u & 31u)) << ((unsigned)((0xdfb100fdu ? p2 : (unsigned)f0) || ((unsigned)c1 & (unsigned)c0)) & 63u);
            u1 = u1 * 0x9e3779b1u + ~((unsigned)x0 / ((unsigned)((unsigned)(x0 >> 70) && (unsigned)s0) | 1u));
            while (i0++ < 4u && (unsigned)((0xd0fa8a96u - 0x80000000u) && (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (unsigned)(0x7fffffffu || (unsigned)((short)(unsigned)(short)(0xf6613489u ^ 0x10000u) > (signed char)(unsigned)(0xe85577a1u || 0xa30511ccu)));
            }
        }
        switch ((i2 & (unsigned)s1) & 7u) {
            break; (void)((unsigned)((unsigned)(fuel < r0.x) || (unsigned)h0));
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((2u + (unsigned)d0) || (unsigned)h1)) goto L2;
                *q0 = ((3u - (unsigned)c1) ? (unsigned)l0 : (0x10000u % (u3 | 1u)));
                L3: if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)((short)0u > (signed char)(unsigned)((unsigned)c0 && (((unsigned)s1 * 9u) % ((unsigned)h0 | 1u))));
                q0 = &garr[(unsigned)((unsigned)(short)(unsigned)((int)(unsigned)w0 >= (int)0x7fffffffu) && 0xf326432au) & 7u];
            } while (i0++ < 3u && 0x80000000u);
            if ((p1 / (0x6854e97u | 1u))) {
                while (i0++ < 5u && ~((*q0 ^ (unsigned)e0) % ((unsigned)h1 | 1u))) { if (--fuel == 0u) goto done;
                    if (((unsigned)f0 / (g0 | 1u))) break;
                    *q0 += (unsigned)((0x80000000u % (0x10000u | 1u)) < (unsigned)((unsigned)x0 && (unsigned)c1));
                }
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = (0u % ((unsigned)s1 | 1u));
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((short)i0 > (signed char)garr[i1 & 7u]) * 4u), (0x10000u % ((unsigned)(7u < (unsigned)(w0 >> 29)) | 1u)), fuel); }
                        { unsigned t2; double z2; if ((((unsigned)s1 | ((unsigned)h1 | 0x7fffffffu))) & 1u) { t2 = (((unsigned)s1 | (unsigned)c0) % (garr[i1 & 7u] | 1u)); z2 = (double)((*q0) & 255u); } if ((((unsigned)s1 | ((unsigned)h1 | 0x7fffffffu))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                            case 0u: ;
                            *q0 += (unsigned)(((unsigned)c1 % ((unsigned)(4u && 0x10000u) | 1u)) || *q0);
                            u3 ^= ~(unsigned)((int)0xbb77a22du < (int)i0);
                            i0 = (unsigned)(unsigned char)((0x10000u & a0[u1 & 3u]) - ((unsigned)c0 << ((unsigned)!(r0.x + 0x75b24150u) & 31u))) & 15u;
                            *q0 += ((unsigned)((short)(unsigned)((int)m0 >= (int)(unsigned)x0) > (signed char)0x9b43a01bu) - v0);
                            r0.x = (v0 * (unsigned)(short)(unsigned)((int)3u < (int)a0[i0 & 3u]));
                        }
                        for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                            L4: if (--fuel == 0u) goto done;
                            if ((unsigned)x0) break;
                            l0 = (long)((unsigned long)l0 + (*q0 ? (unsigned)c0 : m0));
                            case 7u: ;
                            s1 = (int)((unsigned)s1 + -((unsigned)(p2 == (unsigned)(w0 >> 29)) ? a0[u1 & 3u] : fuel));
                        }
                    } while (i1++ < 4u && (unsigned)((short)(unsigned)s0 > (signed char)u3));
                    w0 = w0 * 6364136223846793005ull + ((unsigned)(p1 && 6u) % ((unsigned)(short)(garr[i1 & 7u] ? (unsigned)l0 : u2) | 1u));
                    if ((u3 * (unsigned)x0)) {
                        goto L1;
                    }
                    break; (void)(((unsigned)(g0 == p2) + u1));
                    u0 ^= (unsigned)((1u / (0x10000u | 1u)) < ((unsigned)((int)0x10000u >= (int)1u) - g1));
                }
                if (budget != 0u) { budget -= 1u; u3 = fn0((u3 | 0x80000000u), (unsigned)(0x10000u || 0x10000u), (unsigned)((unsigned)f0 < (unsigned)((unsigned)l0 < *mp))); }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)u2 < (int)0x88110c44u), ((unsigned)((unsigned)l0 < (unsigned)b0) >> (u1 & 31u)), (unsigned)f0); }
            }
            w0 ^= (unsigned long long)(unsigned)(w0 >> 29) << ((p1 % (i0 | 1u)) & 63u);
        }
    }
    if ((unsigned)(unsigned char)((0x7fffffffu | i2) | (unsigned)d0)) goto done;
    while (i0++ < 3u && ((0x10000u * 0x10000u) >> (g1 & 31u))) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((i0 - 0x10000u)) break;
            if (2u) break;
            if ((unsigned)((int)0xb099939au < (int)a0[i0 & 3u])) break;
            break; (void)(0xffffffffu);
            h0 = (short)(u1 >> (-(unsigned)((unsigned)((unsigned)c0 < (unsigned)f0) && (0x10000u + p2)) & 31u));
            { unsigned t3; double z3; if (((8u ? v0 : a0[u1 & 3u])) & 1u) { t3 = (u2 & i0); z3 = (double)(((unsigned)(short)(7u >> ((unsigned)h0 & 31u))) & 255u); } if (((8u ? v0 : a0[u1 & 3u])) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                if (p0) {
                    i1 = (unsigned)(short)(unsigned)(((unsigned)(short)(0u * (unsigned)w0) & (unsigned)b0) == (unsigned)(i0 && (unsigned)h0)) & 15u;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((unsigned)!(unsigned)(0x749aaffau && (unsigned)h1) == i2)) continue;
                        i0 = (unsigned)(i1 < (unsigned)(garr[u2 & 7u] && (unsigned)x0)) & 15u;
                        break; (void)((unsigned)((unsigned)(a0[i0 & 3u] == (unsigned)b0) < (unsigned)w0));
                    } while (i2++ < 6u && ((0xffffffffu ^ 0xa4066612u) % (g0 | 1u)));
                    m0 ^= (0xfa3db945u | ((unsigned)l0 ^ 5u));
                }
                continue; (void)((unsigned)(g1 || i0));
                h0 = (short)(0x7fffffffu & (u0 ^ (unsigned)(garr[u2 & 7u] < *q0)));
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0(i0, u1, (unsigned)(unsigned char)(a0[u1 & 3u] * (unsigned)(signed char)(m0 & i2))); }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (-(unsigned)(u1 < 8u)) break;
            if (0x7fffffffu) break;
            if ((i2 | ~(garr[i1 & 7u] & 6u))) {
                break; (void)((unsigned)((unsigned)h0 || (unsigned)(0xffffffffu || 0xb76269du)));
                do { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (unsigned)s1;
                    switch ((5u << ((unsigned)w0 & 31u)) & 7u) {
                        s0 = (int)(a0[u1 & 3u] ^ (unsigned)(signed char)(unsigned)((short)r0.y > (signed char)u0));
                        x0 = x0 * 0x100000001b3ull + ((i1 >> (5u & 31u)) & ((unsigned)h0 + 0x7fffffffu));
                        w0 ^= (unsigned long long)8u << ((3u ^ i0) & 63u);
                    }
                    u2 ^= (unsigned)((unsigned)(0x631c4b59u && (unsigned)(0xffc4d6dau || a0[u1 & 3u])) == 0x80000000u);
                    if ((unsigned)b0) break;
                    if ((unsigned)((int)0xdf72d08u >= (int)g0)) break;
                    u0 = u0 * 0x9e3779b1u + (3u >> (0x7fffffffu & 31u));
                } while (i2++ < 5u && (0x147d2435u + p2));
                i2 = (((0xdc81dc94u + 0x3ea5a580u) / (r0.y | 1u)) - (p1 << (9u & 31u))) & 15u;
                g0 = (unsigned)d0;
                garr[*mp & 7u] = (unsigned)((int)(unsigned)(signed char)(r0.x / ((unsigned)h1 | 1u)) >= (int)(u0 % (r0.y | 1u)));
                { unsigned t4; double z4; if ((((unsigned)d0 - garr[i1 & 7u])) & 1u) { t4 = 5u; z4 = (double)((0xffffffffu) & 255u); } if ((((unsigned)d0 - garr[i1 & 7u])) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(signed char)((9u - 4u) - garr[i1 & 7u]), garr[i1 & 7u], (unsigned)c1); }
                    if (((unsigned)((short)6u > (signed char)garr[i1 & 7u]) / (*q0 | 1u))) break;
                    garr[((unsigned)d0 / (i2 | 1u)) & 7u] = (unsigned)(unsigned char)(unsigned)((unsigned)d0 < ((unsigned)l0 ^ (unsigned)h1));
                    for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (0x9af577afu) break;
                        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                            c0 = (unsigned char)(0xc53c8ae6u | (unsigned)((int)0x8c5741a2u >= (int)a0[u1 & 3u]));
                            a0[(*mp + 0xdeb19172u) & 3u] = (0xffffffffu % (((unsigned)e0 ^ (unsigned)(x0 >> 70)) | 1u));
                            if ((unsigned)((unsigned)d0 || 0x80000000u)) goto L0;
                        }
                        l0 = (long)((unsigned long)l0 + i2);
                    }
                    if ((unsigned)(((unsigned)f0 / ((unsigned)h0 | 1u)) && r0.y)) {
                        if (0x6d11885bu) break;
                    }
                    d0 = d0 * 0.5 + (double)(((unsigned)e0 + (u3 ? 4u : a0[i0 & 3u])) & 1023u);
                }
            } else {
                s0 = (int)(unsigned)(short)(i1 << ((m0 ? 4u : u2) & 31u));
            }
            goto L3;
        }
        *mp = (unsigned)((int)(0x10000u + (unsigned)x0) < (int)0x7fffffffu);
    }
    if ((0xffffffffu - p1)) goto done;
    x0 = x0 * 0x100000001b3ull + fuel;
    goto L0;
    if ((*q0 ? garr[u2 & 7u] : v0)) {
        u0 = u0 * 0x9e3779b1u + (unsigned)c1;
        switch ((unsigned)((unsigned)l0 || (unsigned)(signed char)(unsigned)((unsigned)e0 && r0.y)) & 7u) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)s0 || (fuel + (unsigned)f0)), 2u, p2); }
            if (budget != 0u) { budget -= 1u; u0 = fn0((0xffffffffu - (unsigned)((int)r0.x >= (int)(unsigned)c0)), 0x7fffffffu, g0); }
            w0 = w0 * 6364136223846793005ull + 0x52a55a6bu;
            s1 = (int)((unsigned)s1 + (unsigned)(signed char)((unsigned)(i1 == 6u) ^ (unsigned)(w0 >> 29)));
        }
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((8u >> (r0.x & 31u)) == (unsigned)(x0 >> 70)), ((r0.x | u2) * i1), ((unsigned)s1 % (0x2e918ef4u | 1u))); }
    }
    goto L2;
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)c0, (unsigned)((g0 / ((unsigned)(w0 >> 29) | 1u)) == (unsigned)w0), ((unsigned)((short)a0[u1 & 3u] > (signed char)1u) / ((unsigned)h0 | 1u))); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L2;
    L0: if (--fuel == 0u) goto done;
    l0 = (long)((unsigned long)l0 + (unsigned)(2u < 9u));
    if ((unsigned)((int)p0 >= (int)0xffffffffu)) {
        { unsigned t0; double z0; if ((((unsigned)x0 / (0x10000u | 1u))) & 1u) { t0 = (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)f0); z0 = (double)(((unsigned)c0) & 255u); } if ((((unsigned)x0 / (0x10000u | 1u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            if (v0) goto done;
            c1 = (signed char)(unsigned)((unsigned)(0x80000000u == (5u >> ((unsigned)s0 & 31u))) < (unsigned)!(garr[u2 & 7u] | u1));
            a0[((unsigned)c0 / ((unsigned)f0 | 1u)) & 3u] = (0xe643781u / ((unsigned)(signed char)(0x474f9426u ? (unsigned)!(unsigned)((int)garr[u2 & 7u] < (int)*mp) : 0x10000u) | 1u));
            s1 = (int)((unsigned)s1 + (*q0 ? (unsigned)(x0 >> 70) : (*mp & 0x3a389a9cu)));
            r0.y ^= ((unsigned)w0 % ((i2 & (r0.y + (unsigned)s1)) | 1u));
        }
    } else {
        switch ((unsigned)((unsigned)f0 < (unsigned)((short)9u > (signed char)*mp)) & 7u) {
            w0 = w0 * 6364136223846793005ull + ((unsigned)(0x4fdafce8u == (unsigned)c0) | p0);
            r0.y ^= ((-(unsigned)((int)(unsigned)l0 < (int)0x7fffffffu) / ((garr[i1 & 7u] - p1) | 1u)) + (unsigned)b0);
        }
        *q0 += (unsigned)((short)u1 > (signed char)a0[u1 & 3u]);
    }
    while (i0++ < 2u && (unsigned)w0) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= u0;
            f0 = f0 * 0.5f + (float)((unsigned)(p2 == (unsigned)c1) & 255u);
            u0 = (unsigned)x0;
            if (u3 == 7u) return ((0x10000u & (unsigned)((short)(unsigned)s1 > (signed char)(unsigned)s1)) + a0[i0 & 3u]);
            L1: if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (fuel < 8u) return ~(1u - (a0[i0 & 3u] * (unsigned)f0));
                        L2: if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)g0 << (((unsigned)((int)(2u ^ (unsigned)(x0 >> 70)) >= (int)(unsigned)(x0 >> 70)) / (((unsigned)b0 + (unsigned)c1) | 1u)) & 63u);
                    }
                    if (((unsigned)((int)u2 < (int)g0) % (p1 | 1u))) break;
                    { unsigned t1; double z1; if (((u2 + u3)) & 1u) { t1 = 0xffffffffu; z1 = (double)(((r0.x % (5u | 1u))) & 255u); } if (((u2 + u3)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                        if (fuel < 8u) return ((((unsigned)(x0 >> 70) * 0xffffffffu) % ((unsigned)x0 | 1u)) - (unsigned)((int)0x7fffffffu < (int)(unsigned)(x0 >> 70)));
                        s1 = (int)((unsigned)s1 + (0x45e807c9u * u2));
                        if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(signed char)((unsigned)((int)*q0 < (int)(unsigned)s1) >> (a0[i0 & 3u] & 31u)), *mp, (unsigned)(short)(unsigned)((unsigned)b0 == garr[u2 & 7u])); }
                    }
                }
            }
        }
    }
    for (;;) { if (--fuel == 0u) goto done;
        if (1u) continue;
        goto L1;
    }
    w0 ^= (unsigned long long)(p0 & i1) << ((fuel ^ u3) & 63u);
    if ((0x7f5d1425u % (a0[i0 & 3u] | 1u))) {
        w0 ^= (unsigned long long)i1 << (((7u | garr[u2 & 7u]) / ((p2 % ((unsigned)(w0 >> 29) | 1u)) | 1u)) & 63u);
    }
    h0 = (short)(unsigned)(unsigned char)((0u & 0x4fab1fefu) & r0.x);
    { unsigned t2; double z2; if (((unsigned)(garr[i1 & 7u] == 7u)) & 1u) { t2 = 0x1a58debbu; z2 = (double)(((unsigned)s1) & 255u); } if (((unsigned)(garr[i1 & 7u] == 7u)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        q0 = &garr[(unsigned)((short)(r0.y ^ (unsigned)l0) > (signed char)a0[u1 & 3u]) & 7u];
        *q0 = (u3 * (unsigned)(9u || (garr[u2 & 7u] % (2u | 1u))));
    }
    { unsigned t3; double z3; if (((unsigned)!(i2 ? u1 : i2)) & 1u) { t3 = (unsigned)(signed char)(8u - -(0xffffffffu << ((unsigned)(w0 >> 29) & 31u))); z3 = (double)((8u) & 255u); } if (((unsigned)!(i2 ? u1 : i2)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        L3: if (--fuel == 0u) goto done;
        { unsigned t4; double z4; if (((0x6a9087bau << (g1 & 31u))) & 1u) { t4 = (p1 & (a0[u1 & 3u] / ((unsigned)w0 | 1u))); z4 = (double)(((unsigned)((short)fuel > (signed char)(unsigned)w0)) & 255u); } if (((0x6a9087bau << (g1 & 31u))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            L4: if (--fuel == 0u) goto done;
            u2 = u2 * 0x9e3779b1u + (0x21e22591u << (u1 & 31u));
            if ((*mp * 0xc6f76e77u)) goto L3;
            *q0 += ((u0 | 8u) ^ (m0 % (p0 | 1u)));
        }
        goto L3;
        if ((unsigned)((int)0x80000000u < (int)(unsigned)((int)u0 >= (int)*q0))) goto L4;
        *mp = (unsigned)((int)8u < (int)(unsigned)c1);
    }
    v0 = (unsigned)((unsigned)(((unsigned)s1 << (4u & 31u)) < (garr[u2 & 7u] * (unsigned)h0)) < 0xc0f1eb3u);
    if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)(signed char)((unsigned)(x0 >> 70) | u1) % ((unsigned)w0 | 1u)), ((unsigned)d0 ^ (a0[i0 & 3u] - r0.y)), garr[i1 & 7u]); }
    if (p1) goto L3;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        g1 += (unsigned)(0xffffffffu == garr[i1 & 7u]);
        c1 = (signed char)(unsigned)!((unsigned)((int)garr[i1 & 7u] >= (int)g1) % (((*mp / (0x10000u | 1u)) * u3) | 1u));
    }
    if ((a0[u1 & 3u] - (*mp + a0[u1 & 3u]))) goto L3;
    r0.x = fuel;
    do { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)(((0x7fffffffu % ((unsigned)c0 | 1u)) / ((unsigned)(short)((unsigned)c1 >> (r0.x & 31u)) | 1u)) & 255u);
        if (0x80000000u) {
            u1 += ((unsigned)((int)*mp >= (int)0xc880af8fu) / ((unsigned)c1 | 1u));
            { unsigned t5; double z5; if (((unsigned)((int)r0.x < (int)2u)) & 1u) { t5 = 0x10000u; z5 = (double)(((unsigned)((short)a0[u1 & 3u] > (signed char)(0x99d0a8bu | (unsigned)e0))) & 255u); } if (((unsigned)((int)r0.x < (int)2u)) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                do { if (--fuel == 0u) goto done;
                    garr[0x4b8a8293u & 7u] = ((u0 >> ((unsigned)x0 & 31u)) * ~(unsigned)((int)3u < (int)0xffffffffu));
                } while (i1++ < 7u && (unsigned)(0x778f9ee8u == (unsigned)((short)0xf072b7c7u > (signed char)p2)));
                if ((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)((int)i2 >= (int)a0[i0 & 3u]))) {
                    if ((((unsigned)(w0 >> 29) >> (0xffffffffu & 31u)) / (fuel | 1u))) break;
                } else {
                    if ((unsigned)((fuel & 2u) < 0x10000u)) break;
                    x0 = x0 * 0x100000001b3ull + ((unsigned)!(3u - -((unsigned)b0 ? (unsigned)e0 : 4u)) | 1u);
                    *q0 = ((unsigned)c0 * ((r0.y * (unsigned)w0) & i2));
                    f0 = f0 * 0.5f + (float)((unsigned)((short)*q0 > (signed char)i0) & 255u);
                }
                switch (0u & 7u) {
                    break; (void)((unsigned)!(unsigned)((unsigned)s0 < (unsigned)w0));
                }
                switch (((0x80000000u + u1) ^ *q0) & 7u) {
                    v0 = (unsigned)((unsigned)(w0 >> 29) == (unsigned)(u2 == (unsigned)(x0 >> 70)));
                    if (budget != 0u) { budget -= 1u; u2 = fn1((garr[i1 & 7u] % (8u | 1u)), u3, (unsigned)((unsigned)s0 || 0x7fffffffu)); }
                }
                if ((unsigned)c1) goto L1;
                if ((unsigned)(p0 || -(unsigned)((int)p1 >= (int)r0.x))) break;
            }
            if ((unsigned)((int)(unsigned)h1 >= (int)0xa13b1a1au)) {
                r0.y ^= (0u >> ((unsigned)(0u || 0x80000000u) & 31u));
                break; (void)((unsigned)h0);
                if (budget != 0u) { budget -= 1u; u0 = fn1((0xf4cdb9bu / (a0[i0 & 3u] | 1u)), ~(unsigned)((short)(unsigned)f0 > (signed char)g0), i0); }
                if ((unsigned)(0x10000u || garr[i1 & 7u])) break;
                if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((int)0x7fffffffu < (int)m0), ((unsigned)c1 / (0x80000000u | 1u)), (a0[u1 & 3u] - 4u)); }
                switch (i1 & 7u) {
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((short)(unsigned)(i2 && 4u) > (signed char)g0), (unsigned)(fuel == (unsigned)!(a0[u1 & 3u] >> (*q0 & 31u))), (unsigned)(i2 && p1)); }
                    e0 = e0 * 0.5L + (long double)((unsigned)l0 & 1023u);
                    case 3u: ;
                    r0.x = (((unsigned)s1 - v0) * (unsigned)((unsigned)(0x80000000u || 0xffffffffu) || (unsigned)d0));
                    do { if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + ((unsigned)h1 * (i1 << ((unsigned)((unsigned)e0 || u0) & 31u)));
                        if ((unsigned)(x0 >> 70)) continue;
                        if (~(0x10000u / ((unsigned)f0 | 1u))) break;
                        if ((unsigned)(*q0 || (unsigned)(i2 || 0x49c65b96u))) break;
                    } while (i1++ < 7u && (0x9b7a1bc5u ^ ((unsigned)d0 - (unsigned)c1)));
                    s0 = (int)((unsigned)s0 & r0.x);
                }
            } else {
                f0 = f0 * 0.5f + (float)((unsigned)(i1 && 0xffffffffu) & 255u);
                if ((0xffffffffu & (unsigned)h0)) goto L0;
            }
        } else {
            v0 = ((unsigned)((short)6u > (signed char)(unsigned)(short)((unsigned)c0 - (unsigned)h1)) / (3u | 1u));
        }
        c1 = (signed char)(unsigned)((int)(unsigned)((int)0x15672862u >= (int)u3) < (int)(unsigned)e0);
    } while (i0++ < 4u && (1u / ((garr[u2 & 7u] * garr[i1 & 7u]) | 1u)));
    goto L1;
    a0[p2 & 3u] = (((unsigned)((short)r0.y > (signed char)0x10000u) + (unsigned)((unsigned)c1 && p1)) << (u0 & 31u));
    if (u3 == 7u) return (unsigned)((unsigned)h0 < (unsigned)(w0 >> 29));
    if ((unsigned)(0xffffffffu && (unsigned)s0)) {
        h0 = (short)7u;
        u2 = u2 * 0x9e3779b1u + ((unsigned)(i1 < (unsigned)h1) ? u1 : (u3 | garr[i1 & 7u]));
    } else {
        *q0 += (((unsigned)f0 * *q0) >> ((unsigned)c0 & 31u));
        if (garr[u2 & 7u]) {
            if (budget != 0u) { budget -= 1u; u0 = fn3((0x84bf0ddeu % ((unsigned)(x0 >> 70) | 1u)), ((unsigned)b0 << ((p0 << (0x80000000u & 31u)) & 31u)), r0.y); }
            u0 += (unsigned)(0xba58b2aeu && (1u - (unsigned)((int)(unsigned)f0 >= (int)(unsigned)d0)));
            *q0 += (0xbd35785cu ? (unsigned)c0 : garr[i1 & 7u]);
            if (((unsigned)e0 ^ v0)) {
                h1 = (unsigned short)(h1 + (i2 & (unsigned)h1));
                h0 = (short)(unsigned)(signed char)(0x7fffffffu ^ (unsigned)s0);
                for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)((int)((u2 % (0x258c21a6u | 1u)) >> ((unsigned)(unsigned char)((unsigned)s0 << (a0[u1 & 3u] & 31u)) & 31u)) >= (int)i0);
                    if ((unsigned)(unsigned char)(unsigned)(i2 && 0xffffffffu)) continue;
                    *q0 += (unsigned)(short)(((unsigned)e0 * i0) & (unsigned)(x0 >> 70));
                    continue; (void)((unsigned)((unsigned)c1 < 8u));
                    h1 = (unsigned short)(h1 + (unsigned)(a0[i0 & 3u] == (unsigned)((int)(unsigned)c1 >= (int)(r0.x & (unsigned)w0))));
                    if ((unsigned)(a0[i0 & 3u] && a0[i0 & 3u])) break;
                }
                switch (4u & 7u) {
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((int)u3 >= (int)(a0[u1 & 3u] >> (0xffffffffu & 31u))), (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)w0), (unsigned)e0); }
                    if ((unsigned)(i0 == (r0.y / (r0.y | 1u)))) goto done;
                    if ((unsigned)(short)((unsigned)f0 ? u0 : (unsigned)l0)) {
                        g1 += (7u * (unsigned)((short)(unsigned)(short)(unsigned)((int)v0 >= (int)0xffffffffu) > (signed char)(unsigned)(short)(i1 % (1u | 1u))));
                        case 0u: ;
                    } else {
                        case 6u: ;
                        default: ;
                        q0 = &garr[(unsigned)((short)(unsigned)c0 > (signed char)r0.x) & 7u];
                    }
                }
                if (p1) {
                    u0 ^= 0xdd299c44u;
                } else {
                    while (i0++ < 3u && (i0 + (p0 / ((unsigned)l0 | 1u)))) { if (--fuel == 0u) goto done;
                        g0 = (unsigned)(u0 < a0[i0 & 3u]);
                        if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)((unsigned)c0 == i0) - 8u), (~(unsigned)((int)(unsigned)l0 >= (int)i0) >> (6u & 31u)), (unsigned)b0); }
                        { unsigned t6; double z6; if (((unsigned)((unsigned)h0 < 0x80000000u)) & 1u) { t6 = (unsigned)(w0 >> 29); z6 = (double)(((unsigned)(r0.y < (r0.x | u2))) & 255u); } if (((unsigned)((unsigned)h0 < 0x80000000u)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)h1, ((unsigned)f0 ? 0x7fffffffu : (unsigned)l0), 5u); }
                            break; (void)((unsigned)((unsigned)s1 && (unsigned)h0));
                            h0 = (short)m0;
                            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)d0 && 0x4004e2b3u), (unsigned)(u3 && (unsigned)(p2 < 0x7fffffffu)), r0.y); }
                            garr[g0 & 7u] = (((unsigned)(*q0 && r0.x) - (unsigned)(x0 >> 70)) << (garr[i1 & 7u] & 31u));
                        }
                        if ((0x80000000u | (unsigned)(short)(garr[u2 & 7u] >> (0x10000u & 31u)))) goto done;
                        if (-(unsigned)((unsigned)(0x498b4a21u == g1) || 0x7fffffffu)) break;
                    }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(fuel || a0[u1 & 3u]), (unsigned)((short)0x10000u > (signed char)(unsigned)(w0 >> 29)), (a0[i0 & 3u] / (garr[u2 & 7u] | 1u))); }
            }
        }
        *mp = (unsigned)(u0 || r0.x);
        { unsigned t7; double z7; if (((unsigned)e0) & 1u) { t7 = (unsigned)((int)0x7fffffffu >= (int)(7u + (unsigned)(x0 >> 70))); z7 = (double)((((unsigned)(x0 >> 70) % (garr[i1 & 7u] | 1u))) & 255u); } if (((unsigned)e0) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
            if ((unsigned)d0) goto L1;
            if ((unsigned)(i2 < p1)) goto L0;
            while (i0++ < 6u && (r0.y ^ (0x7fffffffu + u0))) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(short)((unsigned)e0 & u2));
                g0 = (unsigned)((int)(0x80000000u % (i1 | 1u)) < (int)~(0x7fffffffu - (unsigned)(0x80000000u || 4u)));
                goto L2;
                if (budget != 0u) { budget -= 1u; u3 = fn3(g1, a0[u1 & 3u], i2); }
                if (budget != 0u) { budget -= 1u; u0 = fn2((0u * u3), (unsigned)((int)(unsigned)b0 >= (int)0x80000000u), (unsigned)((short)(unsigned)((int)(unsigned)w0 < (int)a0[i0 & 3u]) > (signed char)(unsigned)s1)); }
            }
            if ((4u - r0.x)) goto L0;
            r0.x = (unsigned)(short)(((unsigned)((int)(unsigned)e0 < (int)p0) % ((unsigned)c1 | 1u)) + (p0 + i2));
        }
    }
    e0 = e0 * 0.5L + (long double)((unsigned)((int)0x72ca5b34u < (int)(unsigned)((int)p2 < (int)garr[u2 & 7u])) & 1023u);
    if (0xcb31bf3du) goto L0;
    if (budget != 0u) { budget -= 1u; u3 = fn2((0xffffffffu % ((u0 * g0) | 1u)), i2, u3); }
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)((int)*q0 >= (int)i2)), (unsigned)d0, ((unsigned)((unsigned)s1 && (unsigned)h0) >> (p1 & 31u))); }
    if ((0x86419870u >> ((unsigned)(unsigned char)((unsigned)d0 ^ (unsigned)b0) & 31u))) {
        c1 = (signed char)(0xa909c433u << ((unsigned)(9u || a0[u1 & 3u]) & 31u));
        if ((0xffffffffu & (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)a0[u1 & 3u]))) goto L0;
        d0 = d0 * 0.5 + (double)(~((unsigned)((int)i0 >= (int)(unsigned)(w0 >> 29)) & (((unsigned)x0 % (u0 | 1u)) - 1u)) & 1023u);
        m0 ^= (unsigned)((int)(unsigned)s1 >= (int)0x7fffffffu);
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((p1 << (*mp & 31u)));
            w0 ^= (unsigned long long)((unsigned)h1 + 0xffffffffu) << (r0.y & 63u);
        }
        do { if (--fuel == 0u) goto done;
            if (fuel < 8u) return (unsigned)((int)(unsigned)c0 >= (int)((unsigned)b0 >> ((unsigned)c1 & 31u)));
            { unsigned t8; double z8; if (((0x99b77e2fu >> (0x10000u & 31u))) & 1u) { t8 = (g1 / (garr[u2 & 7u] | 1u)); z8 = (double)((((unsigned)c0 + (unsigned)h0)) & 255u); } if (((0x99b77e2fu >> (0x10000u & 31u))) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                v0 = (unsigned)((int)i1 >= (int)r0.x);
                if (budget != 0u) { budget -= 1u; u0 = fn3(garr[i1 & 7u], (unsigned)b0, (unsigned)((short)(unsigned)c0 > (signed char)(unsigned)!(unsigned)((short)(unsigned)e0 > (signed char)fuel))); }
                u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)h1 || (unsigned)(*mp == u0));
                if (6u) continue;
                c0 = (unsigned char)((unsigned)(signed char)(p1 & 8u) + r0.x);
                q0 = &garr[(unsigned)s0 & 7u];
            }
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((u1 << (0x80000000u & 31u))) {
                    m0 ^= p2;
                    d0 = d0 * 0.5 + (double)(((unsigned)(garr[i1 & 7u] == ((unsigned)(w0 >> 29) + u0)) + 5u) & 1023u);
                    if ((unsigned)((unsigned)(i2 < i2) && 2u)) break;
                    switch (((unsigned)e0 - (unsigned)x0) & 7u) {
                        x0 = x0 * 0x100000001b3ull + (unsigned)(0x8f120590u < *mp);
                        s0 = (int)~(0x8e805903u / (*mp | 1u));
                        x0 = x0 * 0x100000001b3ull + ((a0[u1 & 3u] ^ 0x90304c1cu) / ((g0 - (unsigned)(w0 >> 29)) | 1u));
                        x0 = x0 * 0x100000001b3ull + ((unsigned)l0 & ((unsigned)c1 | (unsigned)(w0 >> 29)));
                        s0 = (int)((unsigned)!(u1 & a0[u1 & 3u]) >> ((g1 ^ r0.x) & 31u));
                        case 1u: ;
                    }
                    l0 = (long)((unsigned long)l0 + ((((unsigned)(w0 >> 29) | (a0[i0 & 3u] >> ((unsigned)c1 & 31u))) + 0x7fffffffu) * u1));
                }
                r0.y ^= ((unsigned)d0 / ((p1 + (unsigned)f0) | 1u));
                if (budget != 0u) { budget -= 1u; u0 = fn0(a0[i0 & 3u], (0xe9efe0f5u + 0xffffffffu), (0xf4a9bcfu + 0x10000u)); }
                if (p2) goto L0;
            }
            a0[0xb71edf6fu & 3u] = -(unsigned)((*mp >> (5u & 31u)) == p1);
            if ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)((int)*mp < (int)(unsigned)c1))) break;
        } while (i0++ < 5u && (unsigned)((int)(unsigned)(u2 == p2) < (int)0xffffffffu));
    }
    { unsigned t9; double z9; if ((g1) & 1u) { t9 = (p1 - (0xdba9fc8au ^ u2)); z9 = (double)(((a0[i0 & 3u] & 0x7fffffffu)) & 255u); } if ((g1) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
        if (i1) goto L2;
        m0 ^= (((unsigned)e0 + (unsigned)((int)garr[i1 & 7u] < (int)0xffffffffu)) | -(unsigned)(i0 == a0[u1 & 3u]));
    }
    g1 += (0xbb509a4du ? 0x10000u : 0xffffffffu);
    r0.x = (unsigned)(((7u - 4u) + (unsigned)(u3 && garr[i1 & 7u])) < 0xcd445493u);
    if (budget != 0u) { budget -= 1u; u0 = fn0((1u | u2), (unsigned)(w0 >> 29), ((unsigned)(signed char)(u2 - 7u) & (unsigned)e0)); }
    do { if (--fuel == 0u) goto done;
        s0 = (int)(unsigned)((int)~(unsigned)((int)(unsigned)h1 >= (int)0x7fffffffu) >= (int)-(g0 << (*mp & 31u)));
        if (u0) break;
        if ((unsigned)x0) break;
        h1 = (unsigned short)(h1 + (unsigned)!((0xffffffffu + p2) >> ((g0 | 0u) & 31u)));
        w0 ^= (unsigned long long)(0xd7cf554u | (unsigned)h0) << (garr[u2 & 7u] & 63u);
    } while (i0++ < 2u && (u3 + a0[i0 & 3u]));
    if ((unsigned)((unsigned)x0 || 0x7fffffffu)) goto L3;
    if ((unsigned)(i0 == ((unsigned)b0 * g1))) {
        switch (i1 & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)!(unsigned)((short)0xbf1e8e5du > (signed char)v0), (unsigned)(r0.x || (p2 - 6u)), ((*mp >> ((unsigned)s0 & 31u)) * 0xffffffffu)); }
            case 5u: ;
            case 0u: ;
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (0x10000u) break;
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    i0 = r0.x & 15u;
                    g0 = 0x8d671891u;
                    garr[(unsigned)((int)(unsigned)s1 >= (int)(unsigned)(w0 >> 29)) & 7u] = (unsigned)((int)0x54473ff5u >= (int)~(unsigned)(u2 && 0x10000u));
                }
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn2((0x10000u << ((0xffffffffu & (unsigned)(w0 >> 29)) & 31u)), (unsigned)((short)(unsigned)s0 > (signed char)(i0 - garr[i1 & 7u])), ((unsigned)b0 ^ 1u)); }
    }
    e0 = e0 * 0.5L + (long double)(((p2 | garr[u2 & 7u]) >> (fuel & 31u)) & 1023u);
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)d0) {
            if (0x80000000u) {
                u0 = (unsigned)((short)(unsigned)(i2 == 1u) > (signed char)(unsigned)!(unsigned)(((unsigned)x0 * r0.x) || (unsigned)w0));
                e0 = e0 * 0.5L + (long double)(5u & 1023u);
                q0 = &garr[(unsigned)((unsigned)((unsigned)c0 < (*mp & fuel)) || (unsigned)(u3 && *q0)) & 7u];
            }
            break; (void)(p1);
            *q0 += (unsigned)((int)2u >= (int)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(garr[i1 & 7u] ^ u3)));
        }
        goto L2;
        while (i1++ < 4u && (unsigned)((int)0xfffa16bu >= (int)u1)) { if (--fuel == 0u) goto done;
            continue; (void)((unsigned)((int)i1 < (int)(unsigned)w0));
            if (((r0.x << ((unsigned)h0 & 31u)) + u2)) break;
            if ((0x9de1c73cu + (unsigned)((int)0u < (int)0xbb576447u))) break;
            u2 = u2 * 0x9e3779b1u + (unsigned)(signed char)(unsigned)(p2 < v0);
            c1 = (signed char)(unsigned)(signed char)((unsigned)(((unsigned)(x0 >> 70) ^ (unsigned)h1) && u2) * 0x797679d9u);
            for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(0u && g0)) break;
                s1 = (int)((unsigned)s1 + (unsigned)(p0 && ((unsigned)(short)(unsigned)(u3 < (0x80000000u << (0x80000000u & 31u))) & (unsigned)(x0 >> 70))));
                if ((garr[i1 & 7u] << ((u3 << (u3 & 31u)) & 31u))) goto L1;
                *q0 += (u2 + (unsigned)((int)(unsigned)c0 < (int)4u));
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn2(0u, ((unsigned)l0 & g1), 5u); }
                    break; (void)((*mp << (7u & 31u)));
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(w0 >> 29), -((unsigned)s0 << ((unsigned)(w0 >> 29) & 31u)), (unsigned)((short)(unsigned)((unsigned)h1 && (unsigned)l0) > (signed char)0x73c0b2f0u)); }
                    v0 = (unsigned)(signed char)((unsigned)((unsigned)e0 == 0x45f38477u) % (*q0 | 1u));
                    for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(*q0 < m0), (3u % (u2 | 1u)), (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)e0)); }
                    }
                }
                m0 ^= (unsigned)(signed char)((unsigned)(~(unsigned)((int)(unsigned)s1 >= (int)(unsigned)c1) < 0x2be45880u) >> ((unsigned)(0xeba506b3u < g1) & 31u));
            }
        }
        break; (void)((unsigned)((int)(unsigned)(w0 >> 29) < (int)(*mp / (g1 | 1u))));
        { unsigned t10; double z10; if (((v0 << ((u1 & 0x80000000u) & 31u))) & 1u) { t10 = u0; z10 = (double)(((unsigned)(signed char)(unsigned)((unsigned)l0 && 0xa7b7b818u)) & 255u); } if (((v0 << ((u1 & 0x80000000u) & 31u))) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
            *q0 += ~((-(a0[i0 & 3u] >> (p2 & 31u)) << (p0 & 31u)) | (unsigned)s1);
            s1 = (int)((unsigned)s1 + -(9u - (unsigned)(short)(unsigned)((int)r0.x >= (int)*mp)));
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)((int)0x9fc1bf65u < (int)(unsigned)d0);
    }
    while (i0++ < 7u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)(((unsigned)((int)0x7fffffffu < (int)7u) / ((8u & u3) | 1u)) & 255u);
            { unsigned t11; double z11; if ((a0[i0 & 3u]) & 1u) { t11 = ((unsigned)b0 << ((r0.x & 0xe1388050u) & 31u)); z11 = (double)(((unsigned)(short)((unsigned)f0 << ((8u * p0) & 31u))) & 255u); } if ((a0[i0 & 3u]) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
                m0 ^= (unsigned)((0x830b293cu & *q0) && (unsigned)((int)0xcf2e2187u < (int)9u));
                h1 = (unsigned short)(h1 + ((-(0x10000u | garr[u2 & 7u]) / (v0 | 1u)) >> (m0 & 31u)));
                break; (void)(((unsigned)f0 + ((unsigned)e0 * u1)));
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(unsigned char)(0xfad78b84u - 0x2b3f61c9u), (unsigned)((int)(unsigned)f0 >= (int)(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)c0)), (m0 - i1)); }
                f0 = f0 * 0.5f + (float)(garr[i1 & 7u] & 255u);
            }
            continue; (void)((a0[u1 & 3u] * (unsigned)d0));
        }
        continue; (void)(6u);
        if ((0x454ae17fu >> ((unsigned)l0 & 31u))) continue;
        r0.x = a0[u1 & 3u];
    }
    { unsigned t12; double z12; if ((((unsigned)h1 ? (unsigned)c0 : (unsigned)b0)) & 1u) { t12 = ((unsigned)l0 % (m0 | 1u)); z12 = (double)(((u2 ? (unsigned)h0 : a0[i0 & 3u])) & 255u); } if ((((unsigned)h1 ? (unsigned)c0 : (unsigned)b0)) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
        goto L4;
        u2 = (unsigned)(6u || (unsigned)((int)p2 < (int)0x10000u));
        goto L3;
        if (budget != 0u) { budget -= 1u; u3 = fn0(u2, (unsigned)((unsigned)s0 && (unsigned)(fuel && 0xb31b38abu)), 0x80000000u); }
    }
    *mp = ~((unsigned)(p1 && (unsigned)e0) ^ (unsigned)(i1 || (unsigned)(u0 && (unsigned)h0)));
    if (((unsigned)l0 ^ (unsigned)((unsigned)s0 == 0xa226a6a1u))) {
        goto L1;
        if ((3u - 0xbe68fff0u)) {
            goto done;
            if ((unsigned)c0) goto L3;
            if ((unsigned)(0x1054f51au && (unsigned)l0)) {
                do { if (--fuel == 0u) goto done;
                    if (((unsigned)x0 % ((0x17a99fbau ^ (unsigned)f0) | 1u))) break;
                    { unsigned t13; double z13; if (((unsigned)!(unsigned)((short)p1 > (signed char)p1)) & 1u) { t13 = 0x10000u; z13 = (double)(((garr[i1 & 7u] ? u2 : v0)) & 255u); } if (((unsigned)!(unsigned)((short)p1 > (signed char)p1)) & 1u) { u0 += t13; d0 = d0 * 0.5 + z13; }
                        if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)w0 / (((unsigned)c0 | (unsigned)s0) | 1u)), (a0[i0 & 3u] << ((unsigned)((short)u3 > (signed char)(unsigned)(x0 >> 70)) & 31u)), garr[i1 & 7u]); }
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)0xcb16a2d9u >= (int)*mp), (fuel / (0x10000u | 1u)), (unsigned)(*mp < u0)); }
                        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                            goto L2;
                            break; (void)((u2 / ((unsigned)c1 | 1u)));
                            if ((unsigned)c0) break;
                            h1 = (unsigned short)(h1 + (i0 << (((unsigned)w0 ? 7u : ((unsigned)b0 | fuel)) & 31u)));
                            w0 = w0 * 6364136223846793005ull + ((unsigned)((unsigned)b0 == i2) ^ (0x4e4a261du ? (unsigned)d0 : (unsigned)x0));
                        }
                        if (a0[i0 & 3u]) break;
                        g1 += (unsigned)(unsigned char)(0x106ba432u >> ((unsigned)(unsigned char)(unsigned)((i1 % (p2 | 1u)) && a0[u1 & 3u]) & 31u));
                        if ((unsigned)h1) continue;
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn2((i2 & (unsigned)c0), (a0[i0 & 3u] << ((unsigned)(g1 && (unsigned)d0) & 31u)), ((unsigned)(x0 >> 70) + (v0 % (0x7a10cffau | 1u)))); }
                    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)r0.y < (int)*q0), (unsigned)(w0 >> 29), (unsigned)((int)p1 >= (int)i0)); }
                } while (i0++ < 4u && (0x9ff8e0e9u & i1));
                for (;;) { if (--fuel == 0u) goto done;
                    garr[m0 & 7u] = 9u;
                    { unsigned t14; double z14; if (((unsigned)((0u / (garr[i1 & 7u] | 1u)) || v0)) & 1u) { t14 = (unsigned)(x0 >> 70); z14 = (double)(((*q0 << (u2 & 31u))) & 255u); } if (((unsigned)((0u / (garr[i1 & 7u] | 1u)) || v0)) & 1u) { u3 += t14; d0 = d0 * 0.5 + z14; }
                        m0 ^= ((unsigned)e0 * ~((unsigned)w0 ? (unsigned)c0 : 0x80000000u));
                        while (i1++ < 4u && (unsigned)(p0 || (unsigned)d0)) { if (--fuel == 0u) goto done;
                            w0 ^= (unsigned long long)(r0.y * garr[i1 & 7u]) << ((unsigned)((short)r0.y > (signed char)((unsigned)x0 * (unsigned)l0)) & 63u);
                            if ((g0 | 0x80000000u)) break;
                            if ((m0 + u1)) goto L2;
                            if ((unsigned)((unsigned)l0 == (unsigned)x0)) break;
                            if (((unsigned)x0 % (4u | 1u))) break;
                        }
                        break; (void)((unsigned)f0);
                        goto L1;
                        break; (void)((i1 * (unsigned)(0x2ccb7897u < (unsigned)s1)));
                    }
                    i0 = (*q0 << ((6u ^ (((unsigned)s0 - (unsigned)x0) + 0xc2ac529fu)) & 31u)) & 15u;
                    m0 ^= (6u ^ i2);
                }
                goto L4;
                e0 = e0 * 0.5L + (long double)(((a0[i0 & 3u] - (p1 ^ 0u)) / (r0.x | 1u)) & 1023u);
            }
            goto done;
        } else {
            goto L3;
        }
        if ((unsigned)((unsigned)d0 || 6u)) goto L1;
    } else {
        c0 = (unsigned char)(unsigned)(i0 || 4u);
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (4u) break;
            if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((unsigned)(w0 >> 29) == u0), (0x80000000u * 1u), (unsigned)!(0xffffffffu * (unsigned)c0)); }
            *q0 += (0u | (unsigned)(short)(unsigned)((int)(((unsigned)(w0 >> 29) % (0xffffffffu | 1u)) % (r0.x | 1u)) >= (int)(unsigned)h1));
        }
    }
    if ((garr[u2 & 7u] << (((unsigned)s1 % ((unsigned)l0 | 1u)) & 31u))) goto done;
    switch ((unsigned)(0x5adb716u < p0) & 7u) {
        if (budget != 0u) { budget -= 1u; u2 = fn3(0xde9cc23eu, (-(unsigned)((int)0x7fffffffu >= (int)m0) % (0xbc5fef74u | 1u)), *mp); }
        f0 = f0 * 0.5f + (float)((unsigned)((0xa2e7115au % ((unsigned)(unsigned char)((unsigned)b0 >> (g0 & 31u)) | 1u)) || 6u) & 255u);
        while (i0++ < 5u && (unsigned)((*q0 + u2) < p1)) { if (--fuel == 0u) goto done;
            s0 = (int)((p0 ^ (unsigned)e0) ? (unsigned)((int)(unsigned)s1 < (int)v0) : (unsigned)l0);
            if ((unsigned)c1) break;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (unsigned)d0;
                    case 4u: ;
                    if ((unsigned)(short)(0x7fffffffu % (0x80000000u | 1u))) continue;
                    if (-(unsigned)((unsigned)!(0x117079ffu + r0.x) && u3)) continue;
                    d0 = d0 * 0.5 + (double)((u3 + (i0 ? 5u : i0)) & 1023u);
                }
                default: ;
                h0 = (short)(unsigned)!(unsigned)(0x73f57c86u && (unsigned)!((*mp - v0) + (unsigned)(signed char)(2u & a0[i0 & 3u])));
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    case 5u: ;
                }
                if ((unsigned)h1) continue;
            }
        }
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = (0xf749b97au + garr[i1 & 7u]);
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(w0 >> 29)) {
                if (((unsigned)((unsigned)h0 || 0x80000000u) % (v0 | 1u))) break;
            }
            b0 = (unsigned)(0x80000000u < (unsigned)(garr[u2 & 7u] || u3)) != 0u;
            u0 ^= (unsigned)(0xed01db0u && (r0.y | 0u));
        }
        if (((unsigned)((int)g0 < (int)p2) << (g0 & 31u))) continue;
        h1 = (unsigned short)(h1 + (4u % ((unsigned)(0x83b437f1u && 0x79454109u) | 1u)));
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(p1 && (v0 & i1)), (unsigned)(0xffffffffu == (unsigned)w0), (unsigned)(unsigned char)((u0 - 0x10000u) % (5u | 1u))); }
    }
    m0 ^= (u1 / ((unsigned)(w0 >> 29) | 1u));
    *mp = 0x54740cc9u;
    switch ((unsigned)((short)(garr[u2 & 7u] / ((unsigned)h1 | 1u)) > (signed char)r0.y) & 7u) {
        if ((unsigned)(x0 >> 70)) {
            case 6u: ;
            c0 = (unsigned char)(unsigned)(signed char)((unsigned)(u0 && 8u) >> (0xffffffffu & 31u));
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)h1 == (unsigned)c1), (unsigned)(u1 == (unsigned)f0), (unsigned)w0); }
            if ((v0 / (v0 | 1u))) break;
            f0 = f0 * 0.5f + (float)(((unsigned)((int)(unsigned)(u0 || (*q0 & u3)) >= (int)7u) << (v0 & 31u)) & 255u);
        } else {
            if ((unsigned)d0) goto L1;
            f0 = f0 * 0.5f + (float)((((unsigned)f0 ? (0xffffffffu & v0) : 0x10000u) & 0x80000000u) & 255u);
            m0 ^= 6u;
            if ((unsigned)((v0 * v0) == (unsigned)(w0 >> 29))) {
                u0 ^= (i0 ^ (unsigned)((short)6u > (signed char)(unsigned)h1));
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)0xffffffffu > (signed char)0xffffffffu), (unsigned)(signed char)(u0 / (0xb7df0842u | 1u)), (unsigned)c1); }
                if ((unsigned)f0) goto L0;
                case 7u: ;
                r0.x = (garr[i1 & 7u] % (0x80000000u | 1u));
                x0 = x0 * 0x100000001b3ull + (p0 * ((unsigned)(unsigned char)(unsigned)(p0 && 2u) & (a0[i0 & 3u] % ((unsigned)f0 | 1u))));
            } else {
                u1 = u1 * 0x9e3779b1u + (unsigned)(((unsigned)(short)(unsigned)((int)0x10000u >= (int)((unsigned)s0 - (unsigned)d0)) & u1) || 0x80000000u);
                if (budget != 0u) { budget -= 1u; u3 = fn1((((unsigned)(w0 >> 29) / ((unsigned)x0 | 1u)) >> (0x3bbd73f9u & 31u)), (1u << ((unsigned)((short)(unsigned)s0 > (signed char)6u) & 31u)), i0); }
                f0 = f0 * 0.5f + (float)((0x10000u ? (unsigned)h0 : fuel) & 255u);
                h0 = (short)(unsigned)s0;
            }
        }
        case 1u: ;
        do { if (--fuel == 0u) goto done;
            c1 = (signed char)*q0;
            s0 = (int)(unsigned)(u2 && 5u);
            if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(short)(unsigned)(r0.y < u3), (unsigned)((int)(unsigned)l0 < (int)(unsigned)(garr[u2 & 7u] && p1)), *q0); }
            if ((6u ? 0x7fffffffu : (unsigned)b0)) break;
            default: ;
        } while (i0++ < 7u && (unsigned)(9u == ((unsigned)w0 / ((unsigned)h0 | 1u))));
        for (;;) { if (--fuel == 0u) goto done;
            continue; (void)(0u);
            if (9u) continue;
            a0[(unsigned)((short)*mp > (signed char)(unsigned)(x0 >> 70)) & 3u] = (unsigned)((p1 - ((i2 ^ garr[u2 & 7u]) | 1u)) == 0x80000000u);
            r0.y ^= (0xffffffffu * 0xfefbbda4u);
        }
    }
    if ((a0[u1 & 3u] + (unsigned)(unsigned char)(unsigned)((short)0x7fffffffu > (signed char)2u))) {
        goto L3;
        d0 = d0 * 0.5 + (double)(0u & 1023u);
    } else {
        goto done;
        g1 += (((unsigned)x0 / (-(0u & 0x6c5ede6fu) | 1u)) & (0x5aaa00ffu - (unsigned)h1));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 13u, 0xd59941ffu, 0xcfc5f03fu },
        { 10u, 0x9378ff5du, 0x3c208be6u },
        { 15u, 0x7a8fd47bu, 0xbcba9501u },
        { 7u, 0xe51b1705u, 0x121e171bu },
        { 5u, 0x6124755au, 0x87311c59u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
