// test-ssa-source's program of seed 134000409 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xc1f1b536u, g1 = 0x59cd740u;
static unsigned garr[8] = { 0xe4597ebbu, 0x192f7cabu, 0x7173e262u, 0x9d8c1a40u, 0x65a10d25u, 0x4ef72314u, 0x3699ae6bu, 0x80e8a179u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (m0) {
        if ((v0 ^ 0x8c270345u)) {
            do { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + ((unsigned)((short)7u > (signed char)a0[u1 & 3u]) + p2));
                r0.y ^= ((unsigned)e0 ? 0x265e3af2u : ~(0x7fffffffu - ((unsigned)s0 << ((unsigned)d0 & 31u))));
                if ((unsigned)(a0[u1 & 3u] || 0xd6e17e13u)) break;
                if ((a0[i0 & 3u] * 0x80000000u)) {
                    if (~(u0 % ((unsigned)h1 | 1u))) {
                        goto L0;
                        L0: if (--fuel == 0u) goto done;
                        a0[(unsigned)((int)i0 < (int)r0.x) & 3u] = (unsigned)((int)(unsigned)(0x7fffffffu && (unsigned)(((unsigned)w0 ^ 0x430eb18fu) || *q0)) >= (int)(unsigned)(w0 >> 29));
                        break; (void)(~(unsigned)((int)garr[i1 & 7u] >= (int)u0));
                        b0 = (unsigned)((short)((unsigned)((unsigned)b0 < garr[i1 & 7u]) | (unsigned)(x0 >> 70)) > (signed char)u0) != 0u;
                        g0 = (unsigned)((short)0x7fffffffu > (signed char)(unsigned)((unsigned)s0 && r0.y));
                    } else {
                        switch (((unsigned)(a0[u1 & 3u] || p0) * (unsigned)s0) & 7u) {
                            if ((unsigned)((short)(unsigned)f0 > (signed char)u1)) continue;
                            *mp = ((unsigned)(*q0 < (unsigned)e0) ^ (unsigned)((short)0xc6f8a97cu > (signed char)(unsigned)((int)garr[u2 & 7u] >= (int)p2)));
                        }
                    }
                    { unsigned t0; double z0; if (((unsigned)((unsigned)(garr[i1 & 7u] == m0) < 0x10000u)) & 1u) { t0 = ((unsigned)h0 | 9u); z0 = (double)(((i0 & i1)) & 255u); } if (((unsigned)((unsigned)(garr[i1 & 7u] == m0) < 0x10000u)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                        if ((unsigned)f0) continue;
                        L1: if (--fuel == 0u) goto done;
                        u3 = u3 * 0x9e3779b1u + (unsigned)((int)m0 >= (int)(fuel + (unsigned)((int)(unsigned)c0 >= (int)-(0x21c12d11u - (unsigned)h0))));
                        b0 = (unsigned)(unsigned char)(unsigned)(3u < (unsigned)w0) != 0u;
                        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                            i2 = 2u & 15u;
                            L2: if (--fuel == 0u) goto done;
                            if ((i0 & ((unsigned)d0 + (unsigned)s0))) continue;
                            f0 = f0 * 0.5f + (float)(0x80000000u & 255u);
                            i0 = -(0x10000u << ((unsigned)f0 & 31u)) & 15u;
                            if ((unsigned)(signed char)(0xffffffffu ^ p1)) break;
                        }
                        if (p2) break;
                    }
                    b0 = (unsigned)h0 != 0u;
                    L3: if (--fuel == 0u) goto done;
                }
                while (i1++ < 5u && (unsigned)((int)i2 >= (int)u3)) { if (--fuel == 0u) goto done;
                    c1 = (signed char)(unsigned)(unsigned char)(unsigned)((i0 + 4u) && (i0 << ((unsigned)((short)p2 > (signed char)0xb8114fa3u) & 31u)));
                    *q0 = (unsigned)(unsigned char)((unsigned)d0 << (p0 & 31u));
                    for (;;) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + ((unsigned)e0 >> (~(unsigned)(a0[u1 & 3u] && *mp) & 31u)));
                        if ((unsigned)(w0 >> 29)) goto L0;
                        f0 = f0 * 0.5f + (float)((unsigned)c0 & 255u);
                        *mp = ((unsigned)((unsigned)h1 && u2) ? 0x7fffffffu : 0x1078806eu);
                        b0 = (i1 % ((0x80000000u % ((unsigned)!(unsigned)((short)3u > (signed char)0x68499948u) | 1u)) | 1u)) != 0u;
                        c0 = (unsigned char)(unsigned)!(unsigned)((unsigned)b0 == ((unsigned)(x0 >> 70) ? fuel : i1));
                    }
                }
            } while (i0++ < 7u && (unsigned)((int)*mp < (int)m0));
            while ((unsigned)s0) { if (--fuel == 0u) goto done;
                u0 = u0 * 0x9e3779b1u + (unsigned)((0x7fffffffu / (0x24473ba7u | 1u)) == (unsigned)(unsigned char)(0x7dc46fb5u * garr[i1 & 7u]));
            }
            do { if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                u3 += (((p0 << ((unsigned)w0 & 31u)) + 0x80000000u) - a0[i0 & 3u]);
                w0 ^= (unsigned long long)(unsigned)((int)i0 < (int)u3) << (((unsigned)((int)a0[i0 & 3u] < (int)g1) | (r0.y + (i2 | p1))) & 63u);
                g1 += (unsigned)(((unsigned)b0 - *mp) < (unsigned)s0);
            } while (i0++ < 4u && (unsigned)b0);
        } else {
            *q0 = ((unsigned)(garr[i1 & 7u] && v0) % ((((unsigned)s1 / (i0 | 1u)) + u1) | 1u));
        }
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((*mp << (u3 & 31u)));
    }
    q0 = &garr[i0 & 7u];
    if ((unsigned)(0xddc11c2eu || 1u)) goto done;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)s1 == i1)) break;
        if ((fuel ^ (unsigned)(unsigned char)((unsigned)l0 >> (0x7cc6c31fu & 31u)))) {
            while ((unsigned)((unsigned)x0 == 0x10000u)) { if (--fuel == 0u) goto done;
                u2 = u2 * 0x9e3779b1u + ((unsigned)b0 ? m0 : r0.x);
                c0 = (unsigned char)(unsigned)(short)(p0 * (unsigned)((unsigned)x0 == ((unsigned)s1 & (unsigned)w0)));
            }
            while (i1++ < 7u && (unsigned)((unsigned)e0 && i2)) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)(0x80000000u);
                    if (0x6e6c7dd6u) break;
                    { unsigned t1; double z1; if (((p1 | garr[i1 & 7u])) & 1u) { t1 = (unsigned)(r0.x && (unsigned)(0x443c67bbu && m0)); z1 = (double)((-((unsigned)(i1 == 0x70aafa99u) & i2)) & 255u); } if (((p1 | garr[i1 & 7u])) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                        if (u3 == 7u) return (unsigned)((short)(0x7fffffffu + p2) > (signed char)i2);
                        switch (-(r0.y + 7u) & 7u) {
                            case 2u: ;
                            r0.y ^= ((5u ^ (unsigned)b0) * 5u);
                        }
                        c1 = (signed char)(0x10000u ^ *q0);
                        a0[(unsigned)((int)0x10000u >= (int)0x40606e0eu) & 3u] = (0xb326c7eau | i0);
                    }
                }
                do { if (--fuel == 0u) goto done;
                    if (~((unsigned)((short)(unsigned)s1 > (signed char)*mp) << (p2 & 31u))) break;
                    while (i0++ < 2u && (u0 / (r0.x | 1u))) { if (--fuel == 0u) goto done;
                        if (((unsigned)(short)(unsigned)(u2 < (unsigned)h0) & 9u)) break;
                        { unsigned t2; double z2; if (((u1 & p2)) & 1u) { t2 = -((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)h1) << (u0 & 31u)); z2 = (double)(((g1 >> (0xe4f6b125u & 31u))) & 255u); } if (((u1 & p2)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                            break; (void)(u3);
                            r0.x = (unsigned)((short)(unsigned)((unsigned)(w0 >> 29) < 9u) > (signed char)((unsigned)h1 + (unsigned)s0));
                        }
                        if (0x80000000u) break;
                        if (v0) break;
                        if ((unsigned)c1) break;
                    }
                    h0 = (short)(unsigned)((int)*q0 < (int)u2);
                    break; (void)((0x2eb0d5b5u ^ p2));
                    *mp = ((u1 >> ((unsigned)c1 & 31u)) + (unsigned)b0);
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        while (i1++ < 7u && (unsigned)s0) { if (--fuel == 0u) goto done;
                            s1 = (int)((unsigned)s1 + (p1 & (unsigned)e0));
                        }
                        goto L3;
                        if ((unsigned)((int)p2 < (int)((unsigned)(w0 >> 29) >> (2u & 31u)))) goto L2;
                    }
                } while (i2++ < 5u && g1);
                if (0x80000000u) goto L4;
            }
        } else {
            if (g0) break;
        }
        if (0xffffffffu) break;
        for (;;) { if (--fuel == 0u) goto done;
            i2 = (unsigned)((unsigned)h1 || (unsigned)((unsigned)c0 == (unsigned)l0)) & 15u;
            if (((unsigned)(w0 >> 29) % ((a0[u1 & 3u] ^ (unsigned)(x0 >> 70)) | 1u))) break;
        }
    }
    b0 = -(unsigned)((unsigned)(u0 && (u2 >> ((unsigned)b0 & 31u))) || (0x10000u + 0x80000000u)) != 0u;
    if (((unsigned)h1 << ((unsigned)((unsigned)x0 && a0[i0 & 3u]) & 31u))) goto L1;
    if ((*mp + 0xffffffffu)) goto done;
    s1 = (int)((unsigned)s1 + (unsigned)((int)0x80000000u < (int)(unsigned)c0));
    do { if (--fuel == 0u) goto done;
        if (((unsigned)(w0 >> 29) + 9u)) goto L4;
        while (i1++ < 4u && ((unsigned)((short)2u > (signed char)0x80000000u) << (a0[i0 & 3u] & 31u))) { if (--fuel == 0u) goto done;
            *mp = 0u;
        }
        if (7u) break;
    } while (i0++ < 6u && (unsigned)d0);
    switch ((unsigned)((int)0xffffffffu >= (int)(unsigned)(0xffffffffu && u2)) & 7u) {
        if ((unsigned)e0) break;
        case 0u: ;
        case 2u: ;
        r0.y ^= i0;
        u1 = u1 * 0x9e3779b1u + ((g1 << ((unsigned)f0 & 31u)) | (unsigned)((unsigned)x0 == p2));
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)s0 & 7u) {
            a0[(garr[u2 & 7u] << (u3 & 31u)) & 3u] = u2;
            while (i1++ < 3u && p1) { if (--fuel == 0u) goto done;
                case 7u: ;
                case 6u: ;
                h0 = (short)*mp;
            }
            continue; (void)((unsigned)((unsigned)b0 || garr[u2 & 7u]));
            default: ;
            case 5u: ;
            case 3u: ;
        }
        while ((unsigned)((short)0x7fffffffu > (signed char)u1)) { if (--fuel == 0u) goto done;
            *mp = -(unsigned)((unsigned)c1 && (7u >> (0x7fffffffu & 31u)));
            if ((0x122eeeb6u << ((garr[i1 & 7u] | 0x10000u) & 31u))) break;
            u0 = (unsigned)!(unsigned)((int)(unsigned)((short)((unsigned)(*q0 || i2) % (0u | 1u)) > (signed char)(unsigned)c0) >= (int)fuel);
            if (~(g0 + u2)) break;
        }
        do { if (--fuel == 0u) goto done;
            while ((-(unsigned)((short)0x7fffffffu > (signed char)(unsigned)(x0 >> 70)) ^ 0xac7a2259u)) { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)x0) {
                        garr[(unsigned)d0 & 7u] = ((unsigned)((p2 >> (g0 & 31u)) == ((unsigned)e0 & (unsigned)x0)) / (p2 | 1u));
                        if (((unsigned)(w0 >> 29) - (unsigned)s0)) break;
                        v0 = (unsigned)(~(unsigned)((int)6u < (int)u0) == (r0.y / (p0 | 1u)));
                        if ((unsigned)(unsigned char)(unsigned)((int)m0 < (int)*q0)) break;
                        if (3u) break;
                        w0 = w0 * 6364136223846793005ull + ((unsigned)s1 & (unsigned)((unsigned)((int)0x7fffffffu >= (int)garr[u2 & 7u]) < (i1 << (0xb121d34u & 31u))));
                    }
                    break; (void)(0xffffffffu);
                    break; (void)((unsigned)w0);
                    break; (void)(i0);
                    s1 = (int)((unsigned)s1 + (0x7fffffffu + (unsigned)d0));
                }
                break; (void)(~(unsigned)(u0 == garr[u2 & 7u]));
                continue; (void)((unsigned)x0);
                s1 = (int)((unsigned)s1 + (unsigned)!((unsigned)e0 / (((unsigned)((int)*q0 < (int)*q0) | 8u) | 1u)));
            }
            h0 = (short)(p2 ^ 0x7fffffffu);
            h1 = (unsigned short)(h1 + (unsigned)((p1 / (1u | 1u)) && 7u));
            switch (((unsigned)s1 ^ 0xffffffffu) & 7u) {
                e0 = e0 * 0.5L + (long double)(((unsigned)(v0 == ((unsigned)s1 >> ((unsigned)(unsigned char)(unsigned)((unsigned)c0 < 0x10000u) & 31u))) / (p1 | 1u)) & 1023u);
            }
            if (i2) goto L0;
            if ((unsigned)((int)r0.y >= (int)m0)) break;
        } while (i1++ < 6u && (unsigned)(((unsigned)(w0 >> 29) & 1u) && *q0));
        if ((5u - u3)) break;
        break; (void)(p2);
        if (u3 == 7u) return 4u;
    }
    if ((unsigned)((short)(1u & 0xbe39d937u) > (signed char)(unsigned)x0)) goto L0;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((0x88f83ca7u >> (((unsigned)l0 | 0x7fffffffu) & 31u))) continue;
        if (((unsigned)d0 / (0xcbd43417u | 1u))) break;
        w0 ^= (unsigned long long)(unsigned)s1 << ((unsigned)(0x423c0a4bu || ((p0 % (fuel | 1u)) & r0.x)) & 63u);
        c0 = (unsigned char)0x80000000u;
        if ((unsigned)(((unsigned)x0 | 0x10000u) < 0xffdcc6cfu)) break;
    }
    m0 ^= (unsigned)(0xffffffffu || (unsigned)(w0 >> 29));
    *q0 = ((unsigned)s1 - ((unsigned)((unsigned)e0 && 8u) << (i1 & 31u)));
    if (a0[i0 & 3u]) goto L1;
    if ((unsigned)(x0 >> 70)) goto L1;
    if ((unsigned)(garr[i1 & 7u] && (p2 % ((unsigned)d0 | 1u)))) goto L1;
    w0 = w0 * 6364136223846793005ull + (unsigned)(0x7fffffffu || ((unsigned)(x0 >> 70) << (p1 & 31u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    m0 ^= 0x80000000u;
    if ((unsigned)((int)((unsigned)w0 / (g0 | 1u)) >= (int)garr[u2 & 7u])) goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(x0 >> 70) - (unsigned)!((unsigned)h1 + u1)), 0x80000000u, (unsigned)l0); }
    c0 = (unsigned char)(((u0 / (0x80000000u | 1u)) - 4u) / (p2 | 1u));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)w0 < (5u | 0x80000000u))) break;
        q0 = &garr[(((unsigned)s1 / ((unsigned)w0 | 1u)) % ((unsigned)!((unsigned)((short)(unsigned)b0 > (signed char)4u) ^ g0) | 1u)) & 7u];
    }
    do { if (--fuel == 0u) goto done;
        g1 += fuel;
        break; (void)(u0);
    } while (i0++ < 3u && (unsigned)((short)a0[i0 & 3u] > (signed char)0xe172735fu));
    if ((*q0 * a0[u1 & 3u])) {
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)h0);
                    L0: if (--fuel == 0u) goto done;
                    { unsigned t0; double z0; if (((unsigned)((short)(unsigned)((int)a0[i0 & 3u] < (int)0x80000000u) > (signed char)(unsigned)h1)) & 1u) { t0 = (unsigned)((short)(unsigned)c0 > (signed char)(unsigned)c1); z0 = (double)(((unsigned)(signed char)(fuel + 0xffffffffu)) & 255u); } if (((unsigned)((short)(unsigned)((int)a0[i0 & 3u] < (int)0x80000000u) > (signed char)(unsigned)h1)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((8u + a0[u1 & 3u]) ^ 0x728cfb76u), 0xfa3d7160u, ((i2 & 0x80000000u) % (i0 | 1u))); }
                        if (u3 == 7u) return (a0[i0 & 3u] << (0x77b158b2u & 31u));
                    }
                    h0 = (short)((unsigned)((6u - u3) < 2u) / (5u | 1u));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)h0, ((unsigned)(x0 >> 70) >> (((unsigned)b0 + 4u) & 31u)), (unsigned)(unsigned char)(unsigned)((int)g0 >= (int)r0.y)); }
                    u2 ^= (unsigned)(u1 || *q0);
                } while (i2++ < 7u && (unsigned)e0);
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(0x10000u + (1u & (unsigned)(unsigned char)(unsigned)((short)6u > (signed char)fuel)));
                }
                w0 ^= (unsigned long long)(garr[u2 & 7u] | 0x80000000u) << ((8u / (0xc3a77750u | 1u)) & 63u);
                if (budget != 0u) { budget -= 1u; u0 = fn0(0x80000000u, (0x7fffffffu - 9u), (0x6ac0883u ? 0x8f2a70bcu : 0xb1e224cu)); }
                if ((unsigned)((int)garr[u2 & 7u] < (int)5u)) break;
            }
            h1 = (unsigned short)(h1 + ((unsigned)d0 ^ 0x7fffffffu));
            break; (void)((unsigned)(x0 >> 70));
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 = *q0;
                x0 = x0 * 0x100000001b3ull + (unsigned)(short)(unsigned)((int)(unsigned)(0x655c242au < (unsigned)(fuel || 5u)) < (int)((unsigned)l0 - (unsigned)(w0 >> 29)));
                continue; (void)(9u);
                s0 = (int)((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)e0) + (m0 % (0x451af0b4u | 1u)));
                if ((unsigned)((int)(unsigned)w0 >= (int)0x3d021358u)) break;
            }
            if ((unsigned)(m0 && (unsigned)h1)) {
                h1 = (unsigned short)(h1 + i0);
                if ((unsigned)((0x7fffffffu * a0[u1 & 3u]) || (unsigned)f0)) {
                    if ((u2 >> ((0x10000u % (0xbce3a009u | 1u)) & 31u))) break;
                    *mp = ((unsigned)e0 ^ (unsigned)s0);
                    if ((g1 % (i0 | 1u))) goto L4;
                    v0 = (unsigned)(0xe48b4609u < (garr[u2 & 7u] - p1));
                    L1: if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(a0[i0 & 3u], (unsigned)((unsigned)c0 < v0), ((unsigned)c0 / ((u1 * 8u) | 1u))); }
                }
                m0 ^= ((unsigned)((int)(unsigned)((unsigned)l0 == (0x84c8ccf5u ^ 6u)) < (int)(unsigned)w0) / (a0[i0 & 3u] | 1u));
                s0 = (int)(unsigned)(unsigned char)(unsigned)((int)(unsigned)((short)fuel > (signed char)0x6fa62dd9u) < (int)(garr[i1 & 7u] + (unsigned)h1));
            } else {
                if ((unsigned)x0) break;
                if ((u0 % ((m0 ^ u0) | 1u))) break;
                { unsigned t1; double z1; if (((u2 | u0)) & 1u) { t1 = 2u; z1 = (double)(((unsigned)((int)u3 >= (int)(0x6ea6fb22u | p1))) & 255u); } if (((u2 | u0)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    f0 = f0 * 0.5f + (float)(((4u - p0) & garr[i1 & 7u]) & 255u);
                }
                x0 = x0 * 0x100000001b3ull + ((unsigned)(w0 >> 29) % ((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)h1) | 1u));
            }
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            L2: if (--fuel == 0u) goto done;
            if ((0xe5aeb0aeu ^ u1)) {
                *q0 = (r0.y / ((unsigned)e0 | 1u));
                h0 = (short)(unsigned)(signed char)(unsigned)(((garr[i1 & 7u] - 0x886a591eu) + (unsigned)l0) == (g0 - 0x1f3120cdu));
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (0x7fffffffu | (unsigned)(g0 == a0[i0 & 3u])));
                    if ((unsigned)(unsigned char)(0x68f3cd38u ? (unsigned)f0 : 0x9bb6c72eu)) {
                        if ((0x7fffffffu | (unsigned)x0)) continue;
                        m0 ^= (unsigned)s1;
                    } else {
                        l0 = (long)((unsigned long)l0 + ((unsigned)((short)(unsigned)h1 > (signed char)m0) - (unsigned)((int)garr[i1 & 7u] >= (int)(g0 << (a0[u1 & 3u] & 31u)))));
                    }
                }
                if ((r0.y ? u0 : 0x80000000u)) goto L3;
            } else {
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!(unsigned)(0xffffffffu == (unsigned)c0), (unsigned)(garr[i1 & 7u] || (unsigned)x0), 0x80000000u); }
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                }
                { unsigned t2; double z2; if (((unsigned)l0) & 1u) { t2 = u1; z2 = (double)(((2u + r0.y)) & 255u); } if (((unsigned)l0) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    w0 = w0 * 6364136223846793005ull + (0x48ef96bau << ((0x88fa740du | (unsigned)!((p0 ^ garr[i1 & 7u]) % ((unsigned)s1 | 1u))) & 31u));
                    r0.y ^= (unsigned)!(unsigned)((int)u2 < (int)(unsigned)d0);
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(g1 && p1), (unsigned)w0, u2); }
                }
                L4: if (--fuel == 0u) goto done;
            }
        }
        while (i0++ < 7u && (m0 % ((unsigned)b0 | 1u))) { if (--fuel == 0u) goto done;
            a0[(u0 + garr[u2 & 7u]) & 3u] = (u2 ^ (unsigned)(short)((unsigned)c0 << ((unsigned)h0 & 31u)));
            r0.y ^= (unsigned)(w0 >> 29);
        }
        goto L4;
    } else {
        l0 = (long)((unsigned long)l0 + (((0xf782a7e1u * p1) - (unsigned)(x0 >> 70)) | (unsigned)h0));
        if ((~((unsigned)h1 * (unsigned)f0) | p1)) goto L2;
    }
    for (;;) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (fuel) goto L4;
            u0 = i1;
            if ((0u / ((unsigned)((unsigned)f0 && *q0) | 1u))) {
                s0 = (int)(unsigned)(((unsigned)x0 % ((unsigned)d0 | 1u)) || (unsigned)((int)(unsigned)c0 < (int)0xffffffffu));
                if ((unsigned)x0) break;
            } else {
                break; (void)(0xffffffffu);
                break; (void)((unsigned)(i0 == garr[i1 & 7u]));
                if ((unsigned)(v0 || (unsigned)b0)) continue;
                r0.x = ((unsigned)h0 ? garr[i1 & 7u] : ((0xe3c62380u - (unsigned)b0) / ((unsigned)d0 | 1u)));
            }
        }
        while (i1++ < 2u && (0xbd42ed8eu << ((unsigned)(x0 >> 70) & 31u))) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((unsigned)((short)((unsigned)(x0 >> 70) + *mp) > (signed char)((unsigned)s0 & 0x7fffffffu)) & 1023u);
            r0.y ^= ((unsigned)((short)(unsigned)l0 > (signed char)v0) % ((unsigned)!(0xb8489ff8u / (m0 | 1u)) | 1u));
        }
    }
    if (((unsigned)((int)v0 < (int)(unsigned)w0) >> (*mp & 31u))) goto L4;
    if (0x58b4a5f1u) {
        { unsigned t3; double z3; if ((0xffffffffu) & 1u) { t3 = garr[u2 & 7u]; z3 = (double)(((unsigned)(short)(u3 >> (p2 & 31u))) & 255u); } if ((0xffffffffu) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            goto L2;
        }
    } else {
        a0[((unsigned)b0 & u3) & 3u] = (unsigned)((int)(0x7fffffffu >> (((unsigned)h1 % (i0 | 1u)) & 31u)) >= (int)*q0);
    }
    if ((unsigned)(unsigned char)((unsigned)s0 | m0)) {
        while (i0++ < 5u && (unsigned)((int)u3 >= (int)fuel)) { if (--fuel == 0u) goto done;
            s0 = (int)-(unsigned)((short)(unsigned)s1 > (signed char)((unsigned)d0 & v0));
            continue; (void)(((r0.y / ((unsigned)h0 | 1u)) + 0u));
            u0 ^= (unsigned)((int)(p0 - garr[u2 & 7u]) < (int)0x10000u);
        }
        if ((unsigned)(*mp < g1)) goto L4;
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    g0 = (u3 & (unsigned)(short)((0x861ff2c3u % (3u | 1u)) & (unsigned)((int)m0 >= (int)p1)));
                    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (2u) break;
                        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                            break; (void)((unsigned)(signed char)((unsigned)(r0.y < 0xf821c8c4u) & g0));
                            u1 += ((unsigned)(x0 >> 70) + (r0.y % (m0 | 1u)));
                            l0 = (long)((unsigned long)l0 + ((p0 & 1u) ^ 0x4c6637adu));
                        }
                        if ((unsigned)(0xffffffffu && 0xffffffffu)) goto done;
                    }
                } while (i2++ < 2u && i1);
                while (i2++ < 6u && 0x8faff9c2u) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (((unsigned)c0 + (unsigned)((short)(unsigned)l0 > (signed char)p2)) % ((unsigned)(8u < 0x1c116b6eu) | 1u));
                    d0 = d0 * 0.5 + (double)((0x5b336c4eu & ((unsigned)!(a0[u1 & 3u] - 0x135aa9d0u) << (garr[u2 & 7u] & 31u))) & 1023u);
                    w0 ^= (unsigned long long)0x21b7a96eu << (a0[u1 & 3u] & 63u);
                    if (m0) {
                        goto L3;
                        m0 ^= (unsigned)((u0 >> ((unsigned)(w0 >> 29) & 31u)) < (garr[i1 & 7u] << ((unsigned)l0 & 31u)));
                        r0.x = g0;
                        r0.y ^= 0x80000000u;
                        b0 = ~((r0.x << ((unsigned)s0 & 31u)) & i0) != 0u;
                    }
                    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        b0 = (unsigned)((int)((unsigned)x0 ? garr[i1 & 7u] : (unsigned)(unsigned char)(garr[i1 & 7u] % ((unsigned)(x0 >> 70) | 1u))) < (int)g0) != 0u;
                        a0[garr[i1 & 7u] & 3u] = ((unsigned)((unsigned)(short)(i0 & (unsigned)l0) || (p0 << (2u & 31u))) % (u2 | 1u));
                        continue; (void)((unsigned)((int)(0x80000000u % (0x3fccb567u | 1u)) >= (int)1u));
                        *q0 += (unsigned)d0;
                        if ((a0[i0 & 3u] + fuel)) break;
                    }
                    if (0x25108ed0u) break;
                }
            } while (i1++ < 3u && (unsigned)(0x7fffffffu < 0xffffffffu));
        }
        if ((unsigned)((unsigned)s1 < u0)) {
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)h0 << ((unsigned)e0 & 63u);
                s1 = (int)((unsigned)s1 + (unsigned)(0xffffffffu == ((unsigned)e0 * 9u)));
                if ((a0[i0 & 3u] * (unsigned)d0)) goto L4;
            } while (i0++ < 7u && ((u3 / (0xffffffffu | 1u)) - u1));
            if ((unsigned)(signed char)((unsigned)(unsigned char)(unsigned)((unsigned)d0 < 0x115513cu) & 0u)) goto L3;
            while (i0++ < 6u && 0x7fffffffu) { if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)!((unsigned)(signed char)(unsigned)((int)0x638a9947u >= (int)u2) - (garr[u2 & 7u] * (unsigned)(signed char)(unsigned)((int)0x65a72db0u >= (int)u2))) & 7u];
                u2 ^= (unsigned)!(0xffffffffu >> ((unsigned)(unsigned char)((unsigned)b0 / ((unsigned)c0 | 1u)) & 31u));
                u0 = ((unsigned)(short)(u2 ^ (unsigned)h0) | (unsigned)((unsigned)(short)(0xffffffffu | 7u) == 3u));
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)s1, (a0[i0 & 3u] | garr[i1 & 7u]), (unsigned)((unsigned)(signed char)(unsigned)(garr[i1 & 7u] && (unsigned)s0) || i0)); }
                l0 = (long)((unsigned long)l0 + (*mp * (0x10000u | g1)));
                if (5u) {
                    x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)(w0 >> 29) || (unsigned)(signed char)((unsigned)c1 + v0)) * (unsigned)(i2 && (unsigned)f0));
                    g0 = (unsigned)((int)((0x10000u ^ a0[i0 & 3u]) << (-((unsigned)l0 | garr[u2 & 7u]) & 31u)) < (int)(unsigned)e0);
                    b0 = ((unsigned)(p1 || g0) % (i2 | 1u)) != 0u;
                    f0 = f0 * 0.5f + (float)(a0[u1 & 3u] & 255u);
                }
            }
            if ((unsigned)((unsigned)b0 == (a0[u1 & 3u] ^ g1))) goto L2;
            if (((unsigned)x0 | 0x98780247u)) goto L1;
        } else {
            goto L2;
        }
        do { if (--fuel == 0u) goto done;
            while (i1++ < 7u && (0x10000u / ((unsigned)c0 | 1u))) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)~(*mp & (i0 >> (3u & 31u)));
                if ((((unsigned)x0 >> (1u & 31u)) / (p0 | 1u))) {
                    if (((unsigned)l0 | u2)) goto L4;
                    if ((unsigned)w0) goto L2;
                    *q0 += (unsigned)(unsigned char)(0xa92906d0u / (0xffffffffu | 1u));
                    g0 = garr[i1 & 7u];
                    goto L1;
                }
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((u2 * v0), ((unsigned)!((unsigned)(w0 >> 29) ^ 0x75232522u) | garr[i1 & 7u]), ((unsigned)d0 % ((unsigned)c0 | 1u))); }
                    u0 ^= (unsigned)c0;
                    g1 += (0x7fffffffu << (((unsigned)f0 ? 0x7fffffffu : p0) & 31u));
                    x0 = x0 * 0x100000001b3ull + (3u + (unsigned)((unsigned)f0 == (unsigned)(m0 < ((unsigned)f0 + (unsigned)e0))));
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0(m0, (unsigned)s1, (unsigned)s0); }
                goto L3;
                if (4u) goto L2;
            }
            g0 = 9u;
            continue; (void)((0x10000u - (unsigned)b0));
            f0 = f0 * 0.5f + (float)((((unsigned)d0 | u3) ^ (unsigned)(signed char)((unsigned)((int)p1 < (int)(unsigned)(w0 >> 29)) << (p2 & 31u))) & 255u);
        } while (i0++ < 3u && (2u + p2));
        m0 ^= (unsigned)f0;
    } else {
        if (0x7fffffffu) goto L0;
        q0 = &garr[(unsigned)((int)(unsigned)((unsigned)c0 < a0[u1 & 3u]) < (int)r0.y) & 7u];
        goto L0;
    }
    garr[(1u - (unsigned)d0) & 7u] = ((unsigned)l0 & (a0[i0 & 3u] % ((unsigned)s1 | 1u)));
    garr[garr[u2 & 7u] & 7u] = *mp;
    if ((unsigned)((0x80000000u % (0x10000u | 1u)) && u1)) goto L3;
    { unsigned t4; double z4; if (((unsigned)(3u || 0x10000u)) & 1u) { t4 = (p2 + (unsigned)b0); z4 = (double)((((0x7fffffffu ^ 0u) - (unsigned)s1)) & 255u); } if (((unsigned)(3u || 0x10000u)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
        if (((unsigned)h0 ? i0 : garr[i1 & 7u])) goto done;
        if (((g1 ^ 0x3bdddd17u) / (0u | 1u))) goto done;
        *mp = (unsigned)((u3 ? (unsigned)h1 : fuel) == (0x974b98d4u % (u0 | 1u)));
    }
    c0 = (unsigned char)(unsigned)(unsigned char)(unsigned)(garr[u2 & 7u] || (unsigned)((0xffffffffu * garr[u2 & 7u]) < i1));
    switch ((p2 * 0x10000u) & 7u) {
        w0 = w0 * 6364136223846793005ull + 7u;
        s1 = (int)((unsigned)s1 + -(fuel * 0xffffffffu));
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch (0x6789429bu & 7u) {
                if ((unsigned)((unsigned)d0 == (unsigned)((unsigned)s0 == p0))) goto L3;
                i2 = ((unsigned)x0 | r0.x) & 15u;
                case 7u: ;
                *mp = (unsigned)((0x80000000u - r0.y) && (unsigned)(short)(unsigned)((int)(*q0 % (0x80000000u | 1u)) >= (int)(unsigned)e0));
                b0 = (unsigned)(signed char)(unsigned)((int)r0.x >= (int)(unsigned)h0) != 0u;
                if (((unsigned)x0 | 0x80000000u)) {
                    { unsigned t5; double z5; if (((unsigned)(0xb5d777a8u && g0)) & 1u) { t5 = ~(0x80000000u / ((unsigned)(w0 >> 29) | 1u)); z5 = (double)(((a0[u1 & 3u] / ((fuel >> ((unsigned)h0 & 31u)) | 1u))) & 255u); } if (((unsigned)(0xb5d777a8u && g0)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                        w0 ^= (unsigned long long)(a0[i0 & 3u] ^ (unsigned)c0) << ((unsigned)x0 & 63u);
                        switch (0x38f62f43u & 7u) {
                            if ((p0 | (8u ^ *q0))) break;
                            h1 = (unsigned short)(h1 + ((unsigned)s1 * p2));
                        }
                        switch ((unsigned)(short)(unsigned)((int)r0.x < (int)(unsigned)(w0 >> 29)) & 7u) {
                            *mp = (0x114bddadu - (unsigned)((a0[u1 & 3u] * 0x80000000u) && 0xddcf43cbu));
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)w0, u3, (*q0 % (0x10000u | 1u))); }
                        d0 = d0 * 0.5 + (double)((unsigned)(0xf7127549u == (0x4d471a7fu >> (((unsigned)f0 / (0xffffffffu | 1u)) & 31u))) & 1023u);
                    }
                    r0.x = (unsigned)((short)(unsigned)((short)(unsigned)c1 > (signed char)((unsigned)f0 ^ 4u)) > (signed char)(unsigned)w0);
                    s0 = (int)(5u % ((((unsigned)(x0 >> 70) + (unsigned)c1) >> (g1 & 31u)) | 1u));
                }
            }
            case 7u: ;
            f0 = f0 * 0.5f + (float)(((p0 >> (p0 & 31u)) & -(unsigned)((short)0x7fffffffu > (signed char)u0)) & 255u);
            h0 = (short)9u;
        }
        *mp = (unsigned)(*q0 == ((unsigned)b0 ^ (unsigned)c1));
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((3u % (0xda1282f7u | 1u)), *q0, (unsigned)((unsigned)((int)(unsigned)x0 >= (int)m0) && 5u)); }
        } while (i0++ < 6u && r0.x);
    }
    c1 = (signed char)(a0[u1 & 3u] - 6u);
    *q0 = (fuel % ((unsigned)((int)(*q0 % (u2 | 1u)) >= (int)r0.x) | 1u));
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(short)(unsigned)(i0 || 0x10000u)) continue;
                if (budget != 0u) { budget -= 1u; u0 = fn0((1u << (g1 & 31u)), (unsigned)s1, (unsigned)((unsigned)w0 || u2)); }
                if (0xffffffffu) break;
                if ((unsigned)(unsigned char)(r0.x | u1)) goto L4;
            } while (i2++ < 2u && (r0.x + u2));
            v0 = ((unsigned)h0 ^ ((unsigned)h1 ? 0x694d97a3u : r0.y));
            do { if (--fuel == 0u) goto done;
                a0[((unsigned)f0 >> ((unsigned)h0 & 31u)) & 3u] = (unsigned)(a0[u1 & 3u] == (unsigned)(garr[i1 & 7u] < (unsigned)(a0[u1 & 3u] && a0[i0 & 3u])));
                if ((unsigned)((unsigned)(9u || i1) < 0xdecc43d8u)) {
                    if (0x3f1db435u) {
                        *q0 += (unsigned)s0;
                        b0 = (unsigned)(u2 < (unsigned)((v0 / ((0x80000000u - garr[i1 & 7u]) | 1u)) || 6u)) != 0u;
                        if ((unsigned)b0) break;
                        if ((i1 + (unsigned)d0)) continue;
                    } else {
                        goto L1;
                        c1 = (signed char)(*q0 + (unsigned)((unsigned)l0 || (unsigned)((int)-(unsigned)(r0.y == 2u) < (int)(unsigned)h1)));
                        goto L0;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(garr[u2 & 7u], 0x67b48badu, (0xffffffffu / (i1 | 1u))); }
                    }
                    l0 = (long)((unsigned long)l0 + (unsigned)(0x2c3d1d5au || (unsigned)((int)0xffffffffu < (int)((0x8a4103fcu / (0xffffffffu | 1u)) + 0x615f5510u))));
                } else {
                    *q0 = ((unsigned)x0 / (p1 | 1u));
                    u2 += (unsigned)(-((unsigned)s1 >> (i0 & 31u)) || garr[i1 & 7u]);
                    h1 = (unsigned short)(h1 + 3u);
                    r0.y ^= (unsigned)((int)garr[i1 & 7u] >= (int)i0);
                }
                break; (void)((unsigned)((int)0x80000000u < (int)(unsigned)b0));
            } while (i2++ < 7u && a0[u1 & 3u]);
            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)h1 - (unsigned)(0xffffffffu == (unsigned)l0)), (unsigned)(signed char)(unsigned)((short)u1 > (signed char)(unsigned)l0), (unsigned)f0); }
            if (((i1 * 0x80000000u) % (garr[u2 & 7u] | 1u))) break;
            if (0x10000u) {
                garr[(unsigned)((unsigned)h0 < i2) & 7u] = (unsigned)((short)(unsigned)s0 > (signed char)0xf43ffa78u);
                g0 = 0xe9f82327u;
            }
        }
        break; (void)(p2);
    } while (i0++ < 5u && (unsigned)c1);
    h0 = (short)((unsigned)(((unsigned)l0 ? a0[i0 & 3u] : 8u) == p0) + 0x80000000u);
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)p1 >= (int)(unsigned)f0), v0, 3u); }
    u2 ^= ((0xef0d4efcu ^ (unsigned)(w0 >> 29)) << ((garr[i1 & 7u] >> ((unsigned)((short)(unsigned)h0 > (signed char)0x7fffffffu) & 31u)) & 31u));
    d0 = d0 * 0.5 + (double)(((0x5c9fbe43u - 0x41ad9aa6u) * (unsigned)((0x3d6b8c8bu >> (r0.y & 31u)) || p2)) & 1023u);
    w0 = w0 * 6364136223846793005ull + ((unsigned)(0xe801ad0bu < 0x9ed2f846u) / ((unsigned)(short)((unsigned)l0 & 2u) | 1u));
    *q0 += (~(p1 - (unsigned)s0) * (r0.x + g1));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    u0 = (unsigned)(fuel == r0.x);
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(*q0 && (r0.x * 3u)));
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(unsigned)c0 > (signed char)p1), p0, 0xffffffffu); }
    }
    if ((unsigned)((int)(v0 * 0x80000000u) < (int)i0)) goto L4;
    h0 = (short)(p2 / ((unsigned)((short)p0 > (signed char)garr[i1 & 7u]) | 1u));
    { unsigned t0; double z0; if (((unsigned)((unsigned)l0 == (unsigned)c0)) & 1u) { t0 = (unsigned)((int)(unsigned)s0 < (int)5u); z0 = (double)((((unsigned)f0 << ((garr[u2 & 7u] << (fuel & 31u)) & 31u))) & 255u); } if (((unsigned)((unsigned)l0 == (unsigned)c0)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        switch ((r0.y & 0x7fffffffu) & 7u) {
            case 2u: ;
            if (8u) {
                v0 = (unsigned)c0;
                if ((unsigned)c1) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(a0[u1 & 3u] == u2), (u2 - 0x1dec7271u), r0.y); }
                    e0 = e0 * 0.5L + (long double)(~(unsigned)((int)(unsigned)(signed char)(unsigned)((int)m0 >= (int)8u) < (int)r0.x) & 1023u);
                    switch ((unsigned)(w0 >> 29) & 7u) {
                        s1 = (int)((unsigned)s1 + (unsigned)(signed char)((unsigned)f0 << (((unsigned)(3u && a0[i0 & 3u]) ^ 1u) & 31u)));
                        L0: if (--fuel == 0u) goto done;
                        if (0x10000u) {
                            q0 = &garr[(v0 - (unsigned)f0) & 7u];
                            s1 = (int)((unsigned)s1 + (((unsigned)(r0.x == 0xf95d07d6u) % (0x80000000u | 1u)) % ((u1 & a0[i0 & 3u]) | 1u)));
                        }
                        u0 += ((unsigned)x0 | (unsigned)(unsigned char)((0u / (0u | 1u)) - (0xb92e06ffu / ((unsigned)w0 | 1u))));
                        break; (void)((unsigned)((unsigned)((unsigned)(w0 >> 29) < u0) == 4u));
                        s0 = (int)0xc3793eaau;
                    }
                    f0 = f0 * 0.5f + (float)(((unsigned)l0 | (unsigned)((p2 + 0x44f1cffcu) == (unsigned)w0)) & 255u);
                }
                v0 = (2u & (unsigned)(x0 >> 70));
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(short)(8u * 6u), (unsigned)(6u == (unsigned)((int)g0 >= (int)0xffffffffu)), p1); }
            }
            if (0x81f66927u) goto done;
        }
    }
    a0[(0x80000000u & 2u) & 3u] = ((unsigned)((int)(unsigned)h1 < (int)garr[u2 & 7u]) / ((unsigned)s0 | 1u));
    if ((unsigned)(a0[u1 & 3u] && (unsigned)w0)) goto L3;
    do { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((unsigned)(~(i1 - i2) == (unsigned)!(g1 * g1)) & 1023u);
    } while (i0++ < 5u && (i0 * (unsigned)((int)(unsigned)e0 >= (int)m0)));
    if ((unsigned)((int)u1 >= (int)0x5a7082fcu)) {
        if (~((unsigned)d0 | g0)) goto L1;
    }
    while (i0++ < 5u && ((fuel << ((unsigned)d0 & 31u)) - (unsigned)l0)) { if (--fuel == 0u) goto done;
        r0.y ^= ((unsigned)(7u && garr[u2 & 7u]) >> ((a0[u1 & 3u] ? (unsigned)h1 : g0) & 31u));
        if (budget != 0u) { budget -= 1u; u2 = fn0((5u / (0x888f8cc5u | 1u)), (unsigned)(unsigned char)(0x7fffffffu % (garr[u2 & 7u] | 1u)), 3u); }
    }
    if ((unsigned)!((unsigned)x0 - (unsigned)(x0 >> 70))) goto L3;
    c0 = (unsigned char)((unsigned)(p1 || (unsigned)(unsigned char)(unsigned)((int)(unsigned)(r0.x < 0x10000u) < (int)(unsigned)s1)) + 0x7fffffffu);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((unsigned)x0 ^ (unsigned)(i1 || 0x80000000u));
            u0 = (u3 << (~(~(unsigned)((short)0xc0eade12u > (signed char)g1) + u2) & 31u));
        }
        if (((unsigned)c0 - (fuel | p1))) {
            garr[0u & 7u] = (unsigned)e0;
            b0 = (unsigned)(0x10000u && p0) != 0u;
        }
        switch ((unsigned)((short)(unsigned)(signed char)(0x843e00f5u << ((unsigned)(w0 >> 29) & 31u)) > (signed char)*q0) & 7u) {
            a0[(i1 ^ 7u) & 3u] = (unsigned)((unsigned)((short)(unsigned)((int)0xffffffffu >= (int)(u3 & 0xdedd98b8u)) > (signed char)a0[i0 & 3u]) || 5u);
            i0 = (unsigned)(u3 && p0) & 15u;
        }
        h1 = (unsigned short)(h1 + (unsigned)((~(0xd52f1d68u << (garr[i1 & 7u] & 31u)) / (2u | 1u)) == g1));
        *mp = (unsigned)c1;
        *q0 += (unsigned)(short)(unsigned)((unsigned)((unsigned)(g0 || 0xb0676e64u) < (unsigned)s0) == (unsigned)((unsigned)b0 || (unsigned)c0));
    }
    switch (((p0 % (0xac58c1b0u | 1u)) & fuel) & 7u) {
        if (fuel < 8u) return ~(unsigned)(4u == (0xaf0f4ff5u >> ((unsigned)(w0 >> 29) & 31u)));
        g0 = (unsigned)((unsigned)s0 && (unsigned)l0);
        if (budget != 0u) { budget -= 1u; u0 = fn0((*q0 / (fuel | 1u)), ((unsigned)l0 >> ((unsigned)(i0 == g1) & 31u)), (0x7fffffffu * (unsigned)(w0 >> 29))); }
        if (budget != 0u) { budget -= 1u; u2 = fn0(0xaf6f9456u, (fuel + (unsigned)h0), 0x10000u); }
        while ((6u ^ (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + ((p2 >> (4u & 31u)) >> (r0.y & 31u)));
            u2 = (unsigned)((short)r0.x > (signed char)(unsigned)(fuel || p2));
            s1 = (int)((unsigned)s1 + (g1 >> ((a0[u1 & 3u] | 0x92b12872u) & 31u)));
            if ((unsigned)((short)m0 > (signed char)0x7b433ccfu)) {
                e0 = e0 * 0.5L + (long double)((p0 / ((0x10000u & 0xc3ada2d2u) | 1u)) & 1023u);
                s1 = (int)((unsigned)s1 + -((0xe4c47d7bu << (g1 & 31u)) % (0x47f43faeu | 1u)));
            }
            c0 = (unsigned char)6u;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                s0 = (int)garr[i1 & 7u];
                b0 = (unsigned)((int)u2 >= (int)i2) != 0u;
                h1 = (unsigned short)(h1 + 0xffffffffu);
                if (budget != 0u) { budget -= 1u; u2 = fn1(0x10000u, 0x7fffffffu, (unsigned)((p2 ^ p0) == p1)); }
                if (budget != 0u) { budget -= 1u; u3 = fn1((i0 & fuel), (unsigned)!(unsigned)((0x7fffffffu | u2) < 1u), (unsigned)(a0[u1 & 3u] || (unsigned)h1)); }
            }
        }
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((((unsigned)(3u || u1) - i2) * (unsigned)e0) & 255u);
        if ((unsigned)((int)(unsigned)w0 < (int)(unsigned)(u1 && 0x10000u))) break;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch (fuel & 7u) {
                l0 = (long)((unsigned long)l0 + (g1 - (unsigned)((int)*mp >= (int)(unsigned)((int)(unsigned)c0 >= (int)(garr[u2 & 7u] & p0)))));
                case 5u: ;
            }
            u2 += (unsigned)(signed char)(unsigned)((int)(unsigned)(u3 || r0.y) >= (int)((unsigned)e0 % ((unsigned)(short)(unsigned)((int)garr[u2 & 7u] >= (int)fuel) | 1u)));
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                switch ((unsigned)(u0 && (g0 * 4u)) & 7u) {
                    g0 = (unsigned)d0;
                    i1 = p0 & 15u;
                    L1: if (--fuel == 0u) goto done;
                }
                { unsigned t1; double z1; if ((g1) & 1u) { t1 = (unsigned)c1; z1 = (double)(((unsigned)(v0 && u1)) & 255u); } if ((g1) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    s0 = (int)-(unsigned)((unsigned)((int)(0x7fffffffu << (u2 & 31u)) < (int)(unsigned)d0) && (unsigned)((int)u1 < (int)r0.y));
                    v0 = ((unsigned)s1 ? u2 : *q0);
                    for (;;) { if (--fuel == 0u) goto done;
                        s0 = (int)(unsigned)(signed char)(((unsigned)((unsigned)d0 || r0.y) | (unsigned)l0) ^ (unsigned)(*mp && 0x756609ceu));
                        if (budget != 0u) { budget -= 1u; u0 = fn0(2u, i1, 9u); }
                        if (garr[i1 & 7u]) break;
                        s1 = (int)((unsigned)s1 + 0x10000u);
                    }
                    u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)((unsigned)((int)0xfe4f6648u >= (int)((unsigned)c1 ^ 1u)) && u3) || (unsigned)c0);
                    u3 = u3 * 0x9e3779b1u + (unsigned)(unsigned char)((unsigned)((int)a0[u1 & 3u] < (int)0x10000u) | 0x41381cecu);
                }
                if (u0) continue;
                a0[(unsigned)!(*q0 ^ 0xf8f9ebbeu) & 3u] = (unsigned)(fuel == ((unsigned)c0 * (0x10000u | i2)));
                if ((unsigned)(g1 || ~(unsigned)(3u && (unsigned)d0))) {
                    L2: if (--fuel == 0u) goto done;
                }
                m0 ^= (unsigned)b0;
            }
            if ((r0.y % ((fuel - 2u) | 1u))) break;
        }
        l0 = (long)((unsigned long)l0 + ((g0 - i2) | u0));
        if ((unsigned)!(garr[i1 & 7u] << ((unsigned)((int)(unsigned)b0 >= (int)1u) & 31u))) break;
    }
    while ((unsigned)e0) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)0x9c6f5679u;
        b0 = a0[u1 & 3u] != 0u;
        continue; (void)((unsigned)((int)m0 < (int)a0[u1 & 3u]));
        if ((unsigned)(unsigned char)(r0.y ^ 0x7fffffffu)) continue;
    }
    { unsigned t2; double z2; if ((((u0 % ((unsigned)l0 | 1u)) - 0u)) & 1u) { t2 = 0x80000000u; z2 = (double)((g0) & 255u); } if ((((u0 % ((unsigned)l0 | 1u)) - 0u)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        if ((unsigned)(w0 >> 29)) goto L0;
    }
    u3 = 0x5ff3e873u;
    u1 += (unsigned)(0xeeee0470u || 0x34264a9au);
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (g1 / ((unsigned)(i2 || fuel) | 1u)));
        if ((unsigned)(0x38153ce8u && ((unsigned)d0 ^ 0xdc0e8eecu))) break;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            while (i2++ < 3u && (unsigned)((unsigned)(g1 && r0.x) < (unsigned)e0)) { if (--fuel == 0u) goto done;
                *q0 = ((unsigned)((int)g0 < (int)garr[i1 & 7u]) << (8u & 31u));
                if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(x0 >> 70) ^ (p1 - 0xffffffffu)), ((unsigned)((int)0x2c76898cu < (int)garr[i1 & 7u]) << (0x80000000u & 31u)), 0x881eb0d8u); }
                break; (void)((unsigned)(unsigned char)(m0 - (3u * (unsigned)w0)));
            }
            if ((0xffffffffu * garr[u2 & 7u])) goto L2;
            e0 = e0 * 0.5L + (long double)((unsigned)((int)*q0 >= (int)0xffffffffu) & 1023u);
        }
        d0 = d0 * 0.5 + (double)((unsigned)((int)0xffffffffu < (int)((unsigned)f0 ? (unsigned)c0 : (unsigned)x0)) & 1023u);
        while (i1++ < 6u && (unsigned)(unsigned char)(unsigned)(a0[u1 & 3u] == u1)) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)s0 & 1023u);
            if ((unsigned)l0) {
                q0 = &garr[(unsigned)(unsigned char)(unsigned)((int)(unsigned)(x0 >> 70) < (int)*mp) & 7u];
                b0 = ((unsigned)s1 - 0x80000000u) != 0u;
                if ((0xbbcdbaceu + u3)) goto L1;
                b0 = (unsigned)((unsigned)b0 || (0x10000u + 0x80000000u)) != 0u;
                u1 += ((unsigned)((int)(0x7fffffffu | 0x10000u) >= (int)(unsigned)((int)(unsigned)d0 < (int)3u)) % (r0.y | 1u));
                w0 ^= (unsigned long long)0x49b7eb2fu << ((0x2eb5884au ^ (unsigned)s1) & 63u);
            } else {
                l0 = (long)((unsigned long)l0 + (8u / ((unsigned)((short)9u > (signed char)(unsigned)s0) | 1u)));
                if ((unsigned)((int)0x7fffffffu < (int)(unsigned)(a0[i0 & 3u] || *q0))) break;
                s0 = (int)(7u ^ ((unsigned)w0 + u3));
                u3 += (unsigned)((int)r0.x < (int)(i1 ? (unsigned)(w0 >> 29) : i0));
            }
            continue; (void)(~(unsigned)((int)(v0 + p1) < (int)0x7fffffffu));
            for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)a0[u1 & 3u] >= (int)r0.x)) continue;
                L3: if (--fuel == 0u) goto done;
                u3 ^= ((unsigned)((int)2u < (int)0x80000000u) * (unsigned)(u3 == 0x280a4f8au));
                if (budget != 0u) { budget -= 1u; u3 = fn0(-(unsigned)(u2 && g1), i0, (unsigned)(signed char)(garr[i1 & 7u] * (unsigned)c1)); }
            }
            *q0 = (unsigned)(w0 >> 29);
            while ((unsigned)((unsigned)(unsigned char)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)d0) || 0x7fffffffu)) { if (--fuel == 0u) goto done;
                h0 = (short)(unsigned)!(0x80000000u >> ((unsigned)l0 & 31u));
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((0x80000000u << ((unsigned)c1 & 31u)) == m0), (unsigned)((g0 & (unsigned)c1) || i0), ((unsigned)s0 - 6u)); }
                if (m0) {
                    L4: if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)b0 == (unsigned)c1) & 255u);
                    x0 = x0 * 0x100000001b3ull + (unsigned)((int)i0 >= (int)((unsigned)h0 + 0xd2405886u));
                    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)a0[u1 & 3u] << ((0x83fbb97bu * (p0 % (u1 | 1u))) & 63u);
                        if (u3 == 7u) return (unsigned)((int)(unsigned)h1 >= (int)*q0);
                    }
                    a0[g1 & 3u] = (unsigned)((int)((p2 ^ 0x80000000u) ^ (unsigned)h1) >= (int)(unsigned)b0);
                } else {
                    break; (void)((unsigned)((int)(0x80000000u >> (r0.y & 31u)) < (int)0x10000u));
                }
                r0.y ^= ((-(0u % (i1 | 1u)) ^ g1) - i2);
                *q0 = (0x4af15e65u & (unsigned)(r0.x || (unsigned)(0x80000000u || a0[u1 & 3u])));
                { unsigned t3; double z3; if (((unsigned)((unsigned)((int)i2 >= (int)(unsigned)w0) == (unsigned)f0)) & 1u) { t3 = m0; z3 = (double)(((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)(g1 && p1))) & 255u); } if (((unsigned)((unsigned)((int)i2 >= (int)(unsigned)w0) == (unsigned)f0)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    f0 = f0 * 0.5f + (float)((unsigned)((0xd1875f8eu + ((unsigned)w0 & i0)) || v0) & 255u);
                    if ((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)(0xcd56f3eau < (unsigned)c0))) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)d0 && i2), garr[i1 & 7u], (((unsigned)e0 | *mp) * (unsigned)h1)); }
                    do { if (--fuel == 0u) goto done;
                        if (u1) {
                            if ((unsigned)(w0 >> 29)) break;
                            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(u1 < 1u) * p1), (unsigned)(v0 == 0x7fffffffu), ((0xae03ed7u | i0) * (unsigned)h1)); }
                            v0 = (unsigned)(signed char)(0x182a1153u ^ p1);
                            c0 = (unsigned char)(unsigned)(((unsigned)c1 / (8u | 1u)) || (unsigned)((int)0x7fffffffu >= (int)(unsigned)h1));
                            u0 ^= (unsigned)((0x8ce38c99u % (0xc8513146u | 1u)) < ((unsigned)d0 >> (garr[i1 & 7u] & 31u)));
                        }
                        if ((unsigned)(short)(unsigned)((unsigned)(w0 >> 29) < m0)) continue;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(3u && (*q0 * i1)), 0x15b11523u, (unsigned)(unsigned char)(0x10000u >> ((unsigned)f0 & 31u))); }
                        if ((unsigned)((0xfdc82ad5u / (p2 | 1u)) < 3u)) break;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(u1, ~(unsigned)(garr[i1 & 7u] < 0xffffffffu), ((unsigned)((unsigned)f0 || g1) % ((unsigned)s1 | 1u))); }
                        if (((unsigned)x0 >> ((unsigned)(unsigned char)(0x10000u + u2) & 31u))) {
                            if (budget != 0u) { budget -= 1u; u0 = fn1((v0 << ((unsigned)c1 & 31u)), (unsigned)(unsigned char)(unsigned)(g1 && (unsigned)e0), ((unsigned)(x0 >> 70) >> (a0[i0 & 3u] & 31u))); }
                            if ((unsigned)((short)m0 > (signed char)u3)) break;
                            if (budget != 0u) { budget -= 1u; u1 = fn1((0x5ff0cd0au & (unsigned)h0), (unsigned)((0x7fffffffu + (unsigned)c0) < a0[i0 & 3u]), (unsigned)(m0 == m0)); }
                            d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)l0 >= (int)(unsigned)(0x10000u && i2)) & 1023u);
                        }
                    } while (i0++ < 2u && ~(u2 + (fuel % (r0.x | 1u))));
                    c0 = (unsigned char)((m0 * 0x86e459f1u) - 0x80000000u);
                }
            }
        }
        if ((unsigned)e0) break;
    }
    *mp = (*q0 & *q0);
    while (i0++ < 3u && 2u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0(a0[i0 & 3u], (unsigned)((int)1u < (int)(unsigned)d0), i1); }
            if ((unsigned)((int)(unsigned)d0 < (int)(unsigned)(r0.y == (unsigned)(w0 >> 29)))) break;
            if (((unsigned)e0 % (p2 | 1u))) break;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)(*mp % ((i2 * (unsigned)e0) | 1u)), ((unsigned)x0 * i0), (unsigned)((short)9u > (signed char)0x7fffffffu)); }
        }
        switch (((unsigned)f0 >> ((unsigned)c0 & 31u)) & 7u) {
            switch (a0[u1 & 3u] & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0xffffffffu < (unsigned)w0), ((unsigned)((int)0u < (int)garr[i1 & 7u]) - u3), 0x10000u); }
            }
            while ((0x8a85a9f2u ? (unsigned)e0 : (unsigned)s1)) { if (--fuel == 0u) goto done;
                m0 ^= fuel;
                i2 = (u1 + p2) & 15u;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)0x458958f7u < (int)p2), (6u % (r0.x | 1u)), (unsigned)((int)6u >= (int)(unsigned)s0)); }
            }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)((short)0xffffffffu > (signed char)u3));
                v0 = (m0 & garr[u2 & 7u]);
                q0 = &garr[0x80000000u & 7u];
                case 1u: ;
            }
            { unsigned t4; double z4; if (((unsigned)s1) & 1u) { t4 = (u2 >> (i1 & 31u)); z4 = (double)(((0x80000000u / ((unsigned)b0 | 1u))) & 255u); } if (((unsigned)s1) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                e0 = e0 * 0.5L + (long double)((i0 >> (r0.y & 31u)) & 1023u);
            }
        }
        while (i1++ < 7u && ((unsigned)f0 - (garr[u2 & 7u] * (unsigned)e0))) { if (--fuel == 0u) goto done;
            if ((0x7fffffffu + (u3 * u2))) {
                break; (void)(i1);
                while ((unsigned)(u3 || (a0[i0 & 3u] % (0x5639806u | 1u)))) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)!(0x10000u - 1u) == (p0 % ((0x80000000u / (i2 | 1u)) | 1u))) & 255u);
                    goto L2;
                    c1 = (signed char)(((unsigned)(w0 >> 29) >> (g1 & 31u)) - ((m0 * (unsigned)f0) - garr[u2 & 7u]));
                    a0[g0 & 3u] = ~(-((unsigned)h0 + (unsigned)b0) * (0x10000u & g1));
                }
                if (m0) break;
                g0 = ((v0 >> (*mp & 31u)) >> ((unsigned)h0 & 31u));
            } else {
                h0 = (short)(unsigned)(2u && (unsigned)(x0 >> 70));
                if ((0x5fa04a23u * u1)) continue;
                u2 = (unsigned)(((unsigned)((int)(unsigned)h1 < (int)(unsigned)(x0 >> 70)) | garr[u2 & 7u]) || v0);
            }
        }
        if ((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)d0)) break;
        *q0 += (unsigned)(unsigned char)((unsigned)(short)(unsigned)((int)9u < (int)(unsigned)c0) * p0);
        i2 = (unsigned)(short)(unsigned)(g1 == 0xffffffffu) & 15u;
    }
    if (((unsigned)(w0 >> 29) & 0x3359af18u)) {
        x0 = x0 * 0x100000001b3ull + (((unsigned)h0 % ((unsigned)c1 | 1u)) % (i0 | 1u));
        u3 = (unsigned)(p2 < (unsigned)c0);
        w0 ^= (unsigned long long)0xffffffffu << (((0x7fffffffu << (3u & 31u)) ^ (unsigned)c0) & 63u);
    } else {
        if (-(8u << (*q0 & 31u))) goto L0;
    }
    do { if (--fuel == 0u) goto done;
        *q0 = ((8u ^ 0xffffffffu) ^ (unsigned)l0);
        if (-((unsigned)h0 | (unsigned)((short)i0 > (signed char)0x80000000u))) break;
        if (-(unsigned)((short)(unsigned)e0 > (signed char)(unsigned)(x0 >> 70))) {
            if ((unsigned)((short)0x565a44afu > (signed char)9u)) {
                if (budget != 0u) { budget -= 1u; u1 = fn1((r0.y | (unsigned)w0), p1, (unsigned)(u3 == (p2 + (unsigned)w0))); }
                if (0u) {
                    s0 = (int)((unsigned)(unsigned char)(a0[i0 & 3u] ? 0x408988cau : garr[i1 & 7u]) | r0.y);
                    if (0xffffffffu) break;
                    v0 = (unsigned)((unsigned)!(unsigned)((short)(unsigned)((int)(unsigned)h1 >= (int)garr[i1 & 7u]) > (signed char)*mp) < (p1 + i0));
                    x0 = x0 * 0x100000001b3ull + ((unsigned)e0 >> ((i2 - g1) & 31u));
                    if (budget != 0u) { budget -= 1u; u2 = fn1(0x7fffffffu, (g0 << (0xba41eeb3u & 31u)), -(unsigned)((int)(unsigned)d0 < (int)0xd680cfa9u)); }
                } else {
                    if ((0x10000u ^ fuel)) break;
                    if (5u) {
                        if (budget != 0u) { budget -= 1u; u2 = fn1((0x65800e9au | (i0 - u2)), 5u, (unsigned)((*mp >> ((unsigned)h0 & 31u)) || 0x4bf46998u)); }
                        c1 = (signed char)(((unsigned)s0 ? v0 : 0xd5d9257cu) | (2u >> (8u & 31u)));
                        i2 = (unsigned)!(((unsigned)(unsigned char)((unsigned)b0 << (0xdfd5bb12u & 31u)) ^ u3) + (unsigned)h0) & 15u;
                    } else {
                        if (2u) break;
                    }
                    switch ((unsigned)(short)(i1 ^ (unsigned)b0) & 7u) {
                        continue; (void)((unsigned)((int)0xffffffffu >= (int)0x8a974037u));
                        if (u3 == 7u) return (unsigned)((short)(0x7fffffffu ? 2u : (0x22af1354u % (g0 | 1u))) > (signed char)r0.y);
                    }
                    i0 = (unsigned)((short)i2 > (signed char)(u0 >> (5u & 31u))) & 15u;
                }
                goto L0;
                if (fuel) break;
                s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(-(unsigned)((unsigned)x0 == 0x81c0092fu) < 0x7fffffffu) || (unsigned)((short)g1 > (signed char)i2)));
            } else {
                e0 = e0 * 0.5L + (long double)((u0 << ((unsigned)((int)i2 >= (int)r0.y) & 31u)) & 1023u);
            }
            while (i1++ < 7u && p1) { if (--fuel == 0u) goto done;
                if ((unsigned)(short)(p1 >> ((unsigned)e0 & 31u))) continue;
                *q0 = (unsigned)(v0 < u3);
                if (budget != 0u) { budget -= 1u; u3 = fn0((0xffffffffu >> ((0x5d43457cu >> (0x76bcaa43u & 31u)) & 31u)), i1, (unsigned)(0x80000000u < (unsigned)(0xffffffffu || 0x10000u))); }
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)f0 << (p1 & 31u)), (i2 % ((unsigned)((unsigned)e0 < 0x5cefc8u) | 1u)), (unsigned)((int)p1 >= (int)(unsigned)b0)); }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)s0), 0x6b5ccc1cu, (unsigned)f0); }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((0x3a47acdu | ((unsigned)b0 | 0x10000u)), i2, (unsigned)(a0[i0 & 3u] == (0x7fffffffu << (0xffffffffu & 31u)))); }
        }
    } while (i0++ < 5u && (unsigned)h1);
    i1 = ((1u - (unsigned)e0) % ((unsigned)s1 | 1u)) & 15u;
    while (i0++ < 7u && (unsigned)((unsigned)e0 && (unsigned)b0)) { if (--fuel == 0u) goto done;
        { unsigned t5; double z5; if (((i2 + i2)) & 1u) { t5 = (unsigned)l0; z5 = (double)((((unsigned)b0 + 0x10000u)) & 255u); } if (((i2 + i2)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            if ((unsigned)((short)i2 > (signed char)5u)) break;
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (((unsigned)(w0 >> 29) * u0)) {
        c0 = (unsigned char)((unsigned)w0 - m0);
    } else {
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((0x7fffffffu | (g0 % (0xe22de790u | 1u))));
            L0: if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + fuel;
            do { if (--fuel == 0u) goto done;
                g1 += ((unsigned)f0 | (3u * u2));
            } while (i1++ < 4u && (unsigned)(short)((unsigned)w0 / (((unsigned)c0 * i0) | 1u)));
            if ((8u * (unsigned)(garr[u2 & 7u] < p0))) {
                if (v0) break;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (garr[u2 & 7u]) break;
                    if ((5u ^ 0x52511c9bu)) break;
                }
                u3 ^= 0x10000u;
                b0 = (((unsigned)(short)(i2 % (r0.y | 1u)) >> (a0[u1 & 3u] & 31u)) & ((unsigned)x0 - (unsigned)l0)) != 0u;
            } else {
                break; (void)(*mp);
                a0[(g0 ^ 0u) & 3u] = ((unsigned)(short)((unsigned)h1 >> (0x7fffffffu & 31u)) + u1);
            }
        }
        f0 = f0 * 0.5f + (float)((unsigned)(garr[u2 & 7u] || ~(unsigned)((short)0x10000u > (signed char)9u)) & 255u);
        if ((unsigned)(garr[u2 & 7u] && (unsigned)((short)g0 > (signed char)(unsigned)l0))) goto done;
        *mp = (fuel % (-(0x80000000u << ((0x7fffffffu % (0x447fd2cbu | 1u)) & 31u)) | 1u));
    }
    switch ((unsigned)s1 & 7u) {
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(i0 == *q0) - a0[u1 & 3u]), 0x5690bf4eu, ((unsigned)c0 ^ g0)); }
        r0.y ^= ((unsigned)(*q0 == u0) << (1u & 31u));
        do { if (--fuel == 0u) goto done;
            if (1u) {
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)(((unsigned)((int)(unsigned)c0 < (int)(unsigned)f0) % (0xe28f6a60u | 1u)) & 1023u);
                    case 0u: ;
                    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(unsigned char)(unsigned)((int)u1 < (int)0xaa47400au), (unsigned)((unsigned)h0 || (unsigned)(signed char)(unsigned)((int)p2 >= (int)g0)), (unsigned)(i1 || (unsigned)(unsigned char)(unsigned)((int)u2 >= (int)(unsigned)x0))); }
                    switch (0xada4cf9au & 7u) {
                        *q0 = ((unsigned)((int)4u < (int)*mp) ^ p0);
                    }
                }
                default: ;
                h1 = (unsigned short)(h1 + (~(a0[u1 & 3u] << (0x1af56e23u & 31u)) % ((unsigned)(x0 >> 70) | 1u)));
            } else {
                g1 += (unsigned)((short)(unsigned)(0x2842bf74u < 6u) > (signed char)0x80000000u);
                r0.y ^= (unsigned)((int)(unsigned)c0 >= (int)garr[i1 & 7u]);
                if (0x10000u) continue;
            }
            continue; (void)((garr[i1 & 7u] % (0xeaecc150u | 1u)));
            r0.x = p2;
            *q0 = (p2 & ((unsigned)(0xe24f47bdu == 5u) + 1u));
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                s0 = (int)(unsigned)((unsigned)((int)0x80000000u >= (int)(unsigned)((short)0x7fffffffu > (signed char)1u)) || 7u);
                goto L4;
            }
            g0 = (i0 ? g0 : 0x2c4cbf19u);
        } while (i0++ < 6u && 0x837c934u);
        case 2u: ;
        for (;;) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)(short)(unsigned)(0x10de0b8cu == (unsigned)((unsigned)((unsigned)l0 < *mp) < (0xbaf32765u / ((unsigned)(w0 >> 29) | 1u))));
            u1 = u1 * 0x9e3779b1u + ((u3 ^ (unsigned)d0) - ((unsigned)d0 | (unsigned)((short)0x68b8bdadu > (signed char)a0[i0 & 3u])));
            *q0 += (unsigned)((m0 | r0.y) || g1);
            b0 = 2u != 0u;
            L1: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1(*mp, -(4u * i2), (unsigned)s1); }
        }
    }
    { unsigned t0; double z0; if (((unsigned)c1) & 1u) { t0 = (g1 & fuel); z0 = (double)(((a0[u1 & 3u] - (unsigned)s1)) & 255u); } if (((unsigned)c1) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        u1 = u1 * 0x9e3779b1u + (((unsigned)c1 ^ ((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)e0) - r0.y)) >> (*q0 & 31u));
        if (budget != 0u) { budget -= 1u; u2 = fn0(0x10000u, (r0.x & (unsigned)((unsigned)(x0 >> 70) || p1)), ~(5u ^ (r0.y % ((unsigned)s1 | 1u)))); }
        g1 += ((((unsigned)x0 | *q0) + g0) * ((unsigned)f0 % ((unsigned)f0 | 1u)));
        { unsigned t1; double z1; if (((g1 ^ 0xa7ed8d63u)) & 1u) { t1 = ((unsigned)b0 * 0x4da65667u); z1 = (double)((~(p2 ^ (unsigned)((short)u0 > (signed char)(unsigned)(w0 >> 29)))) & 255u); } if (((g1 ^ 0xa7ed8d63u)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            L2: if (--fuel == 0u) goto done;
            goto done;
            while (i0++ < 4u && g0) { if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((unsigned)x0 || (unsigned)x0), (unsigned)l0, ((unsigned)h0 | 0x10000u)); }
                f0 = f0 * 0.5f + (float)(((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)s0) ^ ((unsigned)(w0 >> 29) ? 0x888c5f40u : (unsigned)d0)) & 255u);
                f0 = f0 * 0.5f + (float)((unsigned)s1 & 255u);
            }
        }
        *q0 = (0x80000000u ? (unsigned)x0 : 0x7fffffffu);
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(p2 && (unsigned)(g1 < u1)), (unsigned)(0x10000u || (p0 & 0x10000u)), (unsigned)(short)(fuel >> ((i1 % ((unsigned)e0 | 1u)) & 31u))); }
    }
    for (;;) { if (--fuel == 0u) goto done;
        if (u3 == 7u) return 0xffffffffu;
        m0 ^= (unsigned)((int)a0[i0 & 3u] < (int)((unsigned)b0 * v0));
        m0 ^= ((unsigned)d0 << ((unsigned)(unsigned char)(unsigned)((int)(i1 / (r0.x | 1u)) >= (int)(unsigned)(p2 < (unsigned)d0)) & 31u));
        h1 = (unsigned short)(h1 + a0[u1 & 3u]);
        do { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (0xf495188du >> (u1 & 31u));
        } while (i1++ < 3u && 1u);
        { unsigned t2; double z2; if (((unsigned)((int)*q0 < (int)u3)) & 1u) { t2 = (unsigned)!(unsigned)((short)r0.x > (signed char)0x7fffffffu); z2 = (double)(((unsigned)x0) & 255u); } if (((unsigned)((int)*q0 < (int)u3)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            if ((unsigned)((int)(garr[u2 & 7u] >> (*q0 & 31u)) >= (int)(unsigned)s0)) continue;
            d0 = d0 * 0.5 + (double)(u3 & 1023u);
            h0 = (short)(unsigned)(0x10000u || (unsigned)!(0x2eb90f63u % ((unsigned)e0 | 1u)));
            L4: if (--fuel == 0u) goto done;
            while (i1++ < 3u && (0xffffffffu ^ (unsigned)c0)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)3u > (signed char)(0u >> (0x2504d37fu & 31u))), (i0 + (unsigned)(signed char)(unsigned)(a0[u1 & 3u] == (unsigned)s1)), ~(unsigned)((unsigned)(x0 >> 70) && (8u & 0xa6528139u))); }
                u0 += ~(unsigned)((int)garr[i1 & 7u] >= (int)i1);
                m0 ^= u0;
            }
            g0 = (unsigned)((unsigned)((int)(0x80000000u - p0) >= (int)i0) == *mp);
        }
    }
    v0 = (unsigned)((int)(unsigned)h0 >= (int)(unsigned)((int)(unsigned)d0 >= (int)(a0[i0 & 3u] | u0)));
    h0 = (short)((0x7fffffffu % ((p2 | u1) | 1u)) % (fuel | 1u));
    while ((unsigned)((int)(unsigned)((unsigned)e0 && (unsigned)h0) < (int)(unsigned)d0)) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(w0 >> 29) * r0.y), (unsigned)(w0 >> 29), ((unsigned)x0 ? garr[i1 & 7u] : 0xa85489c6u)); }
        *q0 = (unsigned)(short)(unsigned)((u2 << (p0 & 31u)) == (2u << ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)p0) & 31u)));
        switch ((unsigned)!(i2 & (unsigned)!(unsigned)((unsigned)s1 < 2u)) & 7u) {
            *q0 = (unsigned)f0;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)(0x7fffffffu % (0x636f9290u | 1u)), (unsigned)(signed char)((unsigned)e0 >> (fuel & 31u)), (unsigned)c1); }
        }
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            garr[((unsigned)s0 * (unsigned)h0) & 7u] = (1u | garr[i1 & 7u]);
            r0.y ^= (unsigned)((int)v0 >= (int)(unsigned)x0);
        }
        while ((unsigned)s1) { if (--fuel == 0u) goto done;
            break; (void)(2u);
            continue; (void)((((unsigned)(x0 >> 70) ^ 0x80000000u) | (unsigned)h1));
            while (i2++ < 5u && (unsigned)((int)p1 < (int)i1)) { if (--fuel == 0u) goto done;
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    *q0 += (0x80000000u + (unsigned)l0);
                    i0 = (u0 * 0x80000000u) & 15u;
                    if ((unsigned)(signed char)(g1 ^ 7u)) break;
                }
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)((int)(unsigned)s0 < (int)u1) && (unsigned)((unsigned)(w0 >> 29) && ((unsigned)c0 >> (0x9386616bu & 31u)))));
                u2 ^= (0x7d482c6au ^ (a0[u1 & 3u] + 0u));
                if (((8u << (5u & 31u)) & 1u)) break;
                x0 = x0 * 0x100000001b3ull + (i1 + 6u);
                { unsigned t3; double z3; if ((((unsigned)(x0 >> 70) | m0)) & 1u) { t3 = (r0.y + (unsigned)s1); z3 = (double)(((unsigned)s1) & 255u); } if ((((unsigned)(x0 >> 70) | m0)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        switch ((unsigned)(r0.x < (0x80000000u | g0)) & 7u) {
                            goto L3;
                        }
                        if ((*q0 >> (((unsigned)f0 * garr[u2 & 7u]) & 31u))) break;
                        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((short)(unsigned)x0 > (signed char)u0) && (unsigned)(signed char)(0xb3a57f6u & p0)));
                        if (u3 == 7u) return (unsigned)((unsigned)(0u < (1u / (u0 | 1u))) && 0x3f157884u);
                    }
                    u0 = (0x41dfad3au & (6u ^ 0x7fffffffu));
                    g0 = (unsigned)(0x861c2a9eu < u2);
                }
            }
            m0 ^= ((unsigned)(0xdbcd3fa9u && p0) ^ ((unsigned)h1 - 3u));
            u0 = u0 * 0x9e3779b1u + (unsigned)((int)p2 < (int)(unsigned)((unsigned)((unsigned)f0 == ((unsigned)f0 | 0x2240c516u)) == (unsigned)h1));
        }
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)((int)i2 < (int)0x33551dbdu) > (signed char)g1);
        if (p1) break;
        *q0 = ((unsigned)((1u - u3) < ~(0x7fffffffu * *q0)) - p2);
    }
    { unsigned t4; double z4; if (((unsigned)(i2 && (unsigned)c1)) & 1u) { t4 = (unsigned)(0x80000000u == (g0 - r0.y)); z4 = (double)((0x447ae831u) & 255u); } if (((unsigned)(i2 && (unsigned)c1)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
        do { if (--fuel == 0u) goto done;
            if (p1) goto L2;
            u0 = 0x7fffffffu;
        } while (i0++ < 4u && (i1 << ((unsigned)f0 & 31u)));
        if ((unsigned)((int)6u < (int)1u)) goto L3;
        s0 = (int)0x10000u;
        if ((unsigned)((short)u0 > (signed char)g0)) {
            g0 = (unsigned)(short)(m0 + (p1 - 0x2a5d3bafu));
            a0[(0x10000u * 0x80000000u) & 3u] = ((unsigned)x0 & (unsigned)d0);
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(5u, (0x23364c6bu & (unsigned)((unsigned)(x0 >> 70) < u3)), (0x28c8c310u >> (p2 & 31u))); }
                *q0 = (unsigned)((short)(0x10000u << (0xd70fdeefu & 31u)) > (signed char)u0);
            } while (i0++ < 2u && 8u);
            if (((p0 + u0) * 0x474082b9u)) goto L4;
        } else {
            w0 = w0 * 6364136223846793005ull + ((unsigned)!((unsigned)((int)u2 < (int)0xba87570du) - u3) - (unsigned)((int)0x7690edaeu < (int)(unsigned)f0));
        }
    }
    f0 = f0 * 0.5f + (float)((i1 + (p0 ? (0xf6211db8u ^ (unsigned)w0) : 0x80000000u)) & 255u);
    if (fuel < 8u) return (unsigned)((unsigned)s0 == 8u);
    if ((unsigned)(8u == p0)) {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + 0xd72874f0u);
                q0 = &garr[garr[u2 & 7u] & 7u];
            } while (i1++ < 4u && r0.x);
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)l0 << (garr[i1 & 7u] & 31u)), a0[i0 & 3u], (unsigned)(short)(unsigned)((garr[u2 & 7u] / ((unsigned)d0 | 1u)) && a0[u1 & 3u])); }
            if ((unsigned)h0) break;
        }
        x0 = x0 * 0x100000001b3ull + ((unsigned)(x0 >> 70) >> ((unsigned)((int)v0 >= (int)r0.y) & 31u));
        if ((unsigned)(signed char)(unsigned)((int)a0[u1 & 3u] >= (int)a0[i0 & 3u])) {
            if ((unsigned)((unsigned)c1 || i2)) goto done;
            if ((unsigned)(unsigned char)(unsigned)((short)((unsigned)s1 >> (9u & 31u)) > (signed char)fuel)) goto L4;
            if (p1) {
                if (budget != 0u) { budget -= 1u; u1 = fn0(0x7fffffffu, (unsigned)((short)(unsigned)((int)g1 >= (int)0x5324ce5fu) > (signed char)0x2003ffd7u), ((unsigned)f0 - (unsigned)f0)); }
                m0 ^= (8u % ((unsigned)(w0 >> 29) | 1u));
                if (u3 == 7u) return (((0xccfb80cdu % ((unsigned)(x0 >> 70) | 1u)) | 0x55807c2fu) >> ((unsigned)(i2 == (unsigned)f0) & 31u));
            } else {
                r0.y ^= ((unsigned)((unsigned)((int)0x7fffffffu >= (int)(unsigned)w0) < (g1 & (unsigned)c0)) & g1);
            }
            s0 = (int)(1u | (unsigned)c1);
            *q0 += (garr[i1 & 7u] | r0.x);
            u3 ^= ((0x7ec2764eu | p2) >> (g1 & 31u));
        } else {
            if (budget != 0u) { budget -= 1u; u0 = fn0(((0x39c9c918u + p0) % (5u | 1u)), i0, (unsigned)l0); }
            if ((unsigned)((short)(unsigned)(*q0 == (unsigned)c0) > (signed char)(unsigned)e0)) goto L1;
            { unsigned t5; double z5; if ((~(unsigned)((int)(0x63342decu % (i0 | 1u)) >= (int)(unsigned)(x0 >> 70))) & 1u) { t5 = (unsigned)((short)(unsigned)w0 > (signed char)9u); z5 = (double)(((unsigned)c0) & 255u); } if ((~(unsigned)((int)(0x63342decu % (i0 | 1u)) >= (int)(unsigned)(x0 >> 70))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                if ((unsigned)((int)i2 >= (int)p1)) goto done;
                if (((unsigned)(x0 >> 70) + 0x80000000u)) goto L1;
            }
        }
        if ((unsigned)((u3 % (*q0 | 1u)) && 0x80000000u)) {
            if (u3) goto L3;
            goto L1;
        }
        { unsigned t6; double z6; if (((unsigned)(unsigned char)(unsigned)(0xf26e708du && (unsigned)f0)) & 1u) { t6 = ((p2 | 0x10000u) & a0[u1 & 3u]); z6 = (double)((0x2eeb9996u) & 255u); } if (((unsigned)(unsigned char)(unsigned)(0xf26e708du && (unsigned)f0)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
            goto L0;
            while (i0++ < 6u && (-(unsigned)((int)i0 >= (int)0x50f5861du) << (g0 & 31u))) { if (--fuel == 0u) goto done;
                u2 = ((2u / (0x80000000u | 1u)) & (8u << ((unsigned)((int)0x7fffffffu < (int)0xe19b3c77u) & 31u)));
                s1 = (int)((unsigned)s1 + (0x9f54944bu / ((unsigned)!(unsigned)((*mp | (unsigned)x0) == a0[u1 & 3u]) | 1u)));
                m0 ^= (fuel | (unsigned)(signed char)(-(unsigned)((unsigned)w0 || v0) ^ ((unsigned)(w0 >> 29) >> ((unsigned)l0 & 31u))));
                while (i1++ < 6u && (unsigned)(fuel && (unsigned)h0)) { if (--fuel == 0u) goto done;
                    if ((unsigned)(((unsigned)h0 | u3) < g1)) break;
                    goto L1;
                    u1 ^= (unsigned)(x0 >> 70);
                    g1 += r0.x;
                    s0 = (int)(unsigned)((int)m0 >= (int)(unsigned)(r0.x && *q0));
                    d0 = d0 * 0.5 + (double)((p1 | (unsigned)((int)(unsigned)d0 < (int)fuel)) & 1023u);
                }
                h1 = (unsigned short)(h1 + (((unsigned)((int)(unsigned)d0 >= (int)5u) - fuel) ^ (g0 << (r0.y & 31u))));
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn1(garr[u2 & 7u], i2, *mp); }
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        u1 = u1 * 0x9e3779b1u + 0x7fffffffu;
    }
    c0 = (unsigned char)(p1 / ((unsigned)(r0.y < 2u) | 1u));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = 0xafaf93dbu;
    }
    goto L1;
    goto L1;
    if ((u2 & 0x7fffffffu)) {
        goto L2;
        if ((unsigned)((short)(unsigned)c1 > (signed char)r0.y)) goto L0;
        if ((0xaeae2ba4u & ((unsigned)(w0 >> 29) | *mp))) goto done;
        if ((unsigned)(p0 || (unsigned)(3u || u1))) goto done;
        q0 = &garr[((unsigned)b0 & 0u) & 7u];
    }
    if (m0) goto done;
    if ((unsigned)(w0 >> 29)) {
        u0 ^= u1;
        if (fuel < 8u) return (~(((unsigned)(w0 >> 29) << ((unsigned)w0 & 31u)) & ((unsigned)c0 / (i0 | 1u))) << (m0 & 31u));
    }
    if ((4u >> (((unsigned)s0 / (a0[i0 & 3u] | 1u)) & 31u))) goto L0;
    u1 = (unsigned)s0;
    while (i0++ < 4u && (*q0 ^ (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
        while (i1++ < 7u && ((unsigned)w0 << ((unsigned)(g1 || 2u) & 31u))) { if (--fuel == 0u) goto done;
            r0.x = (unsigned)(garr[i1 & 7u] || (p2 - u0));
        }
        if (((unsigned)f0 % ((garr[u2 & 7u] - i1) | 1u))) break;
    }
    v0 = (unsigned)((int)5u < (int)a0[u1 & 3u]);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 ^= ((unsigned)b0 << (0x7fffffffu & 31u));
        while ((unsigned)(g1 || (u3 * (unsigned)x0))) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                *q0 += (((unsigned)!(unsigned)(a0[i0 & 3u] && (unsigned)s1) - 0x80000000u) << ((unsigned)c1 & 31u));
                if (budget != 0u) { budget -= 1u; u1 = fn0((a0[u1 & 3u] - ~(p0 + (unsigned)(x0 >> 70))), (7u / (u2 | 1u)), (unsigned)s0); }
                if (3u) break;
            } while (i2++ < 2u && g0);
            if (0xffffffffu) {
                if (0x10000u) goto L4;
                i2 = (u0 + (unsigned)e0) & 15u;
                if ((garr[u2 & 7u] ^ a0[u1 & 3u])) break;
                if ((unsigned)(short)(u0 * 0x10000u)) continue;
                if (p1) {
                    while (i2++ < 4u && 0x64b64d5eu) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(p1 || m0), (unsigned)((int)(u1 << ((unsigned)(x0 >> 70) & 31u)) >= (int)0x7fffffffu), (a0[i0 & 3u] & 4u)); }
                    }
                    if ((unsigned)((int)0x10000u < (int)(unsigned)f0)) continue;
                    if (a0[u1 & 3u]) continue;
                    g1 += ((unsigned)c0 | (unsigned)c0);
                    *q0 += (unsigned)((unsigned)s0 || ((unsigned)e0 / ((unsigned)(w0 >> 29) | 1u)));
                } else {
                    *q0 = (unsigned)((int)a0[u1 & 3u] >= (int)(p2 + garr[u2 & 7u]));
                    if ((unsigned)((unsigned)x0 < g1)) break;
                    *mp = p0;
                    *q0 += (0x1a704120u + ((u0 << (4u & 31u)) & ((unsigned)b0 * u0)));
                }
            }
        }
    }
    if ((9u >> (6u & 31u))) {
        if (budget != 0u) { budget -= 1u; u3 = fn0(*q0, (i1 / ((i1 / (m0 | 1u)) | 1u)), 0x10000u); }
        if ((unsigned)(0x5a30a356u == i2)) goto done;
        x0 = x0 * 0x100000001b3ull + ((0x7fffffffu - (g0 & (unsigned)l0)) % ((unsigned)(garr[i1 & 7u] && 0x80000000u) | 1u));
        if ((p2 >> ((0x7fffffffu + p1) & 31u))) {
            while (i0++ < 3u && (unsigned)((int)p1 < (int)(unsigned)b0)) { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((garr[i1 & 7u] << ((unsigned)(4u < p1) & 31u)) & 255u);
                    break; (void)((unsigned)(signed char)(unsigned)((int)4u < (int)(unsigned)e0));
                    c1 = (signed char)(0x7fffffffu << (0xffffffffu & 31u));
                    g1 += (0u ? 0x37dbee4u : 0x4f1aedadu);
                    h0 = (short)(unsigned)((unsigned)h1 || (unsigned)((int)(unsigned)((unsigned)((unsigned)l0 && (unsigned)c0) || (unsigned)f0) < (int)g0));
                }
            }
            while (i0++ < 2u && (unsigned)l0) { if (--fuel == 0u) goto done;
                *q0 = (unsigned)((short)(fuel | (unsigned)e0) > (signed char)(unsigned)((unsigned)(0xbd03734bu || 0xa58ce8b6u) && 0x212812eu));
            }
            w0 = w0 * 6364136223846793005ull + (unsigned)(u3 == *q0);
            *q0 += (unsigned)s1;
            L0: if (--fuel == 0u) goto done;
        } else {
            g0 = p0;
            if ((fuel % (a0[u1 & 3u] | 1u))) goto L2;
            if (budget != 0u) { budget -= 1u; u2 = fn1((p2 - (unsigned)d0), (garr[u2 & 7u] - (unsigned)(garr[i1 & 7u] == (unsigned)f0)), g0); }
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                h0 = (short)(0x3f1ae5c8u << ((1u ^ p1) & 31u));
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)*mp > (signed char)(unsigned)h1), (p0 / (garr[i1 & 7u] | 1u)), p2); }
                switch ((unsigned)(((unsigned)c0 - 3u) == (unsigned)d0) & 7u) {
                    while ((4u + (unsigned)e0)) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((unsigned)h0 && (fuel << ((unsigned)e0 & 31u))), 0x9f3c0560u, 5u); }
                        v0 = ((unsigned)s1 >> (m0 & 31u));
                        garr[((unsigned)h0 + a0[u1 & 3u]) & 7u] = i1;
                        if (((unsigned)c1 - (unsigned)f0)) goto done;
                        s1 = (int)((unsigned)s1 + (a0[u1 & 3u] - (unsigned)f0));
                    }
                    q0 = &garr[((u2 & (unsigned)(signed char)(((unsigned)x0 / ((unsigned)b0 | 1u)) / ((unsigned)(x0 >> 70) | 1u))) << ((unsigned)(x0 >> 70) & 31u)) & 7u];
                    w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)((unsigned)(0x4b4a1f77u || a0[u1 & 3u]) * (unsigned)((short)(unsigned)x0 > (signed char)(unsigned)(w0 >> 29)));
                    h0 = (short)(unsigned)(signed char)(unsigned)(u0 || (unsigned)((int)(unsigned)(x0 >> 70) >= (int)7u));
                    m0 ^= (unsigned)((r0.y * 0x1c5073acu) && (unsigned)((int)6u < (int)(m0 >> (7u & 31u))));
                }
                while (i1++ < 4u && 0x6e80e589u) { if (--fuel == 0u) goto done;
                    L1: if (--fuel == 0u) goto done;
                    goto L3;
                    break; (void)((unsigned)c1);
                }
                h1 = (unsigned short)(h1 + (unsigned)((int)8u < (int)(u0 - (unsigned)((unsigned)w0 < (unsigned)(x0 >> 70)))));
            }
        }
    } else {
        w0 = w0 * 6364136223846793005ull + ((unsigned)s0 >> ((unsigned)c0 & 31u));
    }
    if ((unsigned)(u0 == 0x80000000u)) {
        goto L4;
        v0 = ((0x10000u >> (i1 & 31u)) >> ((unsigned)(8u && (unsigned)c1) & 31u));
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)(((unsigned)w0 + 5u) == g0);
            switch (((unsigned)s0 << (i0 & 31u)) & 7u) {
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(((unsigned)c1 - (unsigned)x0) < i2), ((unsigned)c1 / (v0 | 1u)), 0x7fffffffu); }
                if (budget != 0u) { budget -= 1u; u0 = fn3(((unsigned)w0 - g1), (unsigned)((unsigned)c1 == (1u * 0u)), i2); }
                if (budget != 0u) { budget -= 1u; u3 = fn2((m0 * (unsigned)h0), (unsigned)(signed char)(unsigned)((int)v0 < (int)0xffffffffu), (unsigned)((int)(3u << (a0[u1 & 3u] & 31u)) >= (int)(unsigned)h1)); }
                goto L3;
            }
            if (i2) break;
            m0 ^= (3u / ((unsigned)((short)(unsigned)f0 > (signed char)((unsigned)f0 | (unsigned)h1)) | 1u));
            continue; (void)(-(unsigned)((unsigned)f0 && (1u + (unsigned)e0)));
        }
    }
    f0 = f0 * 0.5f + (float)(((unsigned)(short)(unsigned)(0xffffffffu && (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)(x0 >> 70))) << ((garr[i1 & 7u] >> ((unsigned)b0 & 31u)) & 31u)) & 255u);
    for (;;) { if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)((short)(unsigned)c0 > (signed char)((unsigned)h0 + (unsigned)((int)i2 < (int)(9u - (unsigned)h1))));
        r0.y ^= ((unsigned)h0 & 0x7474a172u);
        h0 = (short)((unsigned)s1 / ((unsigned)(unsigned char)(unsigned)(((unsigned)b0 / ((unsigned)((unsigned)h1 || *q0) | 1u)) < 9u) | 1u));
        f0 = f0 * 0.5f + (float)((0x10000u | fuel) & 255u);
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(~((u1 << (0xc7c1bc9u & 31u)) % (a0[u1 & 3u] | 1u)));
            if (budget != 0u) { budget -= 1u; u3 = fn3((p0 ^ 0xffffffffu), (unsigned)((short)0x11d7ac19u > (signed char)0xffffffffu), (*mp | p0)); }
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((int)i0 >= (int)0x10000u) && (unsigned)((int)(unsigned)l0 >= (int)0x62990d7eu));
            i0 = (~(unsigned)((short)0x6fae86cbu > (signed char)(unsigned)((int)3u >= (int)9u)) + r0.y) & 15u;
            if ((unsigned)!((unsigned)((unsigned)f0 || u1) + u3)) break;
            g1 += (unsigned)((unsigned)h0 && (unsigned)((int)0x7fffffffu >= (int)(unsigned)d0));
        }
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)((0x7fffffffu ^ u0) == 2u);
            s1 = (int)((unsigned)s1 + (unsigned)((short)u2 > (signed char)(unsigned)((short)r0.x > (signed char)-(unsigned)((unsigned)((int)*q0 >= (int)*mp) || u0))));
            continue; (void)((((unsigned)b0 | (unsigned)c0) * p1));
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)x0, ((8u - i2) ^ fuel), (unsigned)(signed char)(u2 >> (p0 & 31u))); }
                { unsigned t0; double z0; if (((a0[u1 & 3u] / (9u | 1u))) & 1u) { t0 = (unsigned)!(i2 | g1); z0 = (double)(((unsigned)((int)(unsigned)((unsigned)(x0 >> 70) == 6u) >= (int)v0)) & 255u); } if (((a0[u1 & 3u] / (9u | 1u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                    while (i0++ < 4u && *q0) { if (--fuel == 0u) goto done;
                        continue; (void)((unsigned)(unsigned char)(u0 & (unsigned)(u2 && (unsigned)x0)));
                    }
                    g1 += ((unsigned)d0 & (unsigned)c1);
                    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        r0.y ^= (p0 % (g1 | 1u));
                        u2 ^= u1;
                        switch ((fuel >> ((unsigned)((unsigned)(w0 >> 29) == 0xee8c0de9u) & 31u)) & 7u) {
                            goto L0;
                            v0 = 3u;
                            if ((unsigned)((unsigned)(x0 >> 70) == ((unsigned)h0 ^ 0x7fffffffu))) continue;
                            r0.x = ((unsigned)(u0 && *q0) | r0.x);
                        }
                    }
                    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        r0.y ^= (unsigned)(4u && garr[i1 & 7u]);
                        L2: if (--fuel == 0u) goto done;
                        a0[u1 & 3u] = ((u3 | garr[i1 & 7u]) << ((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)f0) & 31u));
                    }
                }
                if (~((unsigned)e0 ? 0x138a7e60u : garr[i1 & 7u])) {
                    u1 = (p2 % (r0.x | 1u));
                    u1 = u1 * 0x9e3779b1u + (unsigned)(garr[u2 & 7u] && u3);
                    h1 = (unsigned short)(h1 + (unsigned)((garr[i1 & 7u] + (unsigned)s1) || (unsigned)l0));
                    b0 = 0xffffffffu != 0u;
                }
                v0 = 0x7fffffffu;
                v0 = (0x4903202cu ? 0xc8e408a2u : u3);
                L3: if (--fuel == 0u) goto done;
            }
            switch ((garr[u2 & 7u] & (unsigned)(*mp || (unsigned)s0)) & 7u) {
                w0 = w0 * 6364136223846793005ull + (p1 / ((unsigned)((short)(i0 ? u0 : 6u) > (signed char)2u) | 1u));
                if (u1) continue;
                L4: if (--fuel == 0u) goto done;
                *q0 += r0.y;
                g0 = (0x7fffffffu * ((unsigned)f0 & (r0.y & (fuel + i1))));
                if (budget != 0u) { budget -= 1u; u1 = fn1((a0[i0 & 3u] / (5u | 1u)), g1, (unsigned)s1); }
            }
            h1 = (unsigned short)(h1 + g1);
        } while (i1++ < 7u && (((unsigned)(x0 >> 70) + r0.x) / ((unsigned)x0 | 1u)));
        if (budget != 0u) { budget -= 1u; u2 = fn3((u2 >> (p2 & 31u)), (r0.y ? (unsigned)(x0 >> 70) : r0.y), r0.x); }
    }
    if ((unsigned)((0x10000u << (0xf3247d42u & 31u)) == (unsigned)s0)) goto L0;
    h0 = (short)(unsigned)((int)((unsigned)d0 << ((unsigned)!(unsigned)((unsigned)c0 || 0xd6cca320u) & 31u)) >= (int)(unsigned)((int)0u >= (int)0x80000000u));
    { unsigned t1; double z1; if (((unsigned)(w0 >> 29)) & 1u) { t1 = ((0x32450fdbu % (9u | 1u)) << ((unsigned)c1 & 31u)); z1 = (double)(((-(unsigned)((unsigned)s0 || garr[u2 & 7u]) - 0xa94691c3u)) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((unsigned)e0 + (unsigned)(3u < i0)) & 1023u);
            do { if (--fuel == 0u) goto done;
                switch (r0.x & 7u) {
                    if ((unsigned)(6u && v0)) {
                        case 2u: ;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)s1, p1, 8u); }
                        *q0 = (a0[i0 & 3u] << (1u & 31u));
                        default: ;
                        if (((unsigned)w0 << (0xa130c6ddu & 31u))) break;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(i1, 2u, (0x96acc7aau % ((unsigned)h1 | 1u))); }
                    } else {
                        if (~(u0 >> (g0 & 31u))) break;
                        m0 ^= (unsigned)(0x836b49d6u && (unsigned)(x0 >> 70));
                    }
                    if ((u0 % ((unsigned)((int)4u < (int)*mp) | 1u))) continue;
                    u2 ^= ((u2 | (unsigned)((unsigned)c0 < v0)) % ((unsigned)!(unsigned)(a0[i0 & 3u] < *q0) | 1u));
                    if (((fuel - 7u) + (unsigned)h1)) goto L4;
                }
                if (u3 == 7u) return ((unsigned)((unsigned)l0 || p1) ^ -(unsigned)((short)2u > (signed char)(unsigned)c0));
            } while (i1++ < 6u && (unsigned)(r0.x == *mp));
            if ((unsigned)((unsigned)f0 || g1)) {
                c0 = (unsigned char)0x10000u;
            } else {
                if (((unsigned)(signed char)(unsigned)(a0[i0 & 3u] || (unsigned)f0) >> (0x1da03379u & 31u))) break;
            }
        }
        g0 = (5u ^ (((unsigned)l0 ? a0[u1 & 3u] : i1) & 0xffffffffu));
        d0 = d0 * 0.5 + (double)(garr[i1 & 7u] & 1023u);
        if ((unsigned)c1) goto L2;
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)x0, (unsigned)(x0 >> 70), (unsigned)(x0 >> 70)); }
    }
    switch (((unsigned)(u2 == (unsigned)d0) & 0x80000000u) & 7u) {
        case 1u: ;
        if ((0xffffffffu | u1)) goto L0;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            *mp = (0x7fffffffu ^ (p2 + (*q0 % ((unsigned)((unsigned)l0 || 0x79601af7u) | 1u))));
            switch ((i1 % ((unsigned)x0 | 1u)) & 7u) {
                m0 ^= p2;
                u2 += ((0x7fffffffu * (unsigned)((unsigned)h0 == (unsigned)(a0[i0 & 3u] < (unsigned)x0))) & *mp);
                if ((unsigned)((int)0u < (int)(unsigned)e0)) {
                    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(unsigned char)(garr[u2 & 7u] + (unsigned)s1), ((unsigned)h1 ^ (r0.x ^ (unsigned)l0)), fuel); }
                    while (i1++ < 5u && (unsigned)((unsigned)l0 && (m0 + 0x9694a58cu))) { if (--fuel == 0u) goto done;
                        r0.x = fuel;
                        r0.x = (unsigned)(i0 < 0x10000u);
                        u0 = u0 * 0x9e3779b1u + ((unsigned)(p0 == ~((unsigned)(w0 >> 29) - 0x7fffffffu)) ? (unsigned)c0 : p2);
                    }
                    u2 = 5u;
                    e0 = e0 * 0.5L + (long double)(((i2 + g0) / (a0[u1 & 3u] | 1u)) & 1023u);
                    case 6u: ;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(g1, (r0.x & -(garr[u2 & 7u] ^ u2)), (unsigned)!(unsigned)((int)2u < (int)0x10000u)); }
                }
            }
            u3 += (9u * (unsigned)(~(0x80000000u << (0xe44c5e2bu & 31u)) && (unsigned)s0));
            f0 = f0 * 0.5f + (float)(((unsigned)(0x7fffffffu && 4u) - u0) & 255u);
            u2 = ((unsigned)b0 + (0x80000000u ? m0 : p1));
        }
        while (i0++ < 6u && (unsigned)(short)(unsigned)((int)(unsigned)s1 < (int)(unsigned)((int)0x10000u >= (int)p0))) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)((int)u0 >= (int)(unsigned)s0);
            case 4u: ;
        }
    }
    { unsigned t2; double z2; if ((p0) & 1u) { t2 = 0x9f3852cbu; z2 = (double)(((1u >> ((unsigned)e0 & 31u))) & 255u); } if ((p0) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        if ((unsigned)((int)(0x82bc6a93u + 0u) >= (int)1u)) goto L4;
    }
    { unsigned t3; double z3; if ((0x7fffffffu) & 1u) { t3 = (unsigned)((int)(unsigned)l0 >= (int)*mp); z3 = (double)(((a0[i0 & 3u] << (*q0 & 31u))) & 255u); } if ((0x7fffffffu) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        if ((a0[u1 & 3u] ^ (unsigned)(p0 || (unsigned)d0))) {
            if ((unsigned)(8u < (unsigned)h0)) goto done;
            { unsigned t4; double z4; if (((((unsigned)s0 / ((unsigned)s0 | 1u)) & (unsigned)h0)) & 1u) { t4 = (unsigned)((unsigned)(x0 >> 70) == 8u); z4 = (double)((i1) & 255u); } if (((((unsigned)s0 / ((unsigned)s0 | 1u)) & (unsigned)h0)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                for (;;) { if (--fuel == 0u) goto done;
                    if (v0) break;
                    break; (void)((7u / ((unsigned)(0x80000000u || i0) | 1u)));
                    if ((unsigned)h0) break;
                    r0.x = 0x72294c4fu;
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((unsigned)((unsigned)h0 && *mp) || u2));
                        break; (void)(r0.y);
                    }
                    u0 += ((unsigned)w0 << (u3 & 31u));
                }
                e0 = e0 * 0.5L + (long double)((garr[i1 & 7u] - g1) & 1023u);
            }
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)(i1 < (unsigned)f0) >> (0x80000000u & 31u))) goto L4;
                }
                s1 = (int)((unsigned)s1 + (0x10000u * (unsigned)((int)(u3 ^ (6u ^ 9u)) < (int)(unsigned)x0)));
            }
            if ((9u << ((unsigned)((unsigned)(w0 >> 29) || 0x7fffffffu) & 31u))) goto L3;
            if ((garr[i1 & 7u] / (r0.y | 1u))) {
                { unsigned t5; double z5; if ((5u) & 1u) { t5 = (unsigned)w0; z5 = (double)((((unsigned)(w0 >> 29) | (unsigned)(p2 && 0x94d3d452u))) & 255u); } if ((5u) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(0xffffffffu || a0[i0 & 3u]), *q0, (unsigned)((int)3u < (int)(unsigned)h0)); }
                }
                if ((unsigned)h0) goto L2;
                if (3u) goto L1;
            }
        } else {
            if ((unsigned)((unsigned)(g1 || i0) < 0xffffffffu)) {
                goto done;
                if ((unsigned)(p0 == (unsigned)w0)) {
                    if (((unsigned)((int)0x10000u < (int)u1) | fuel)) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(p2, (unsigned)h0, ~((8u * (unsigned)b0) | i1)); }
                } else {
                    u1 ^= ((unsigned)w0 / (p2 | 1u));
                    if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)s0 - u0), (unsigned)s0, (unsigned)(5u || (unsigned)((int)g1 < (int)u2))); }
                    h0 = (short)((unsigned)((unsigned)d0 < (unsigned)(garr[u2 & 7u] == (unsigned)d0)) % ((unsigned)l0 | 1u));
                }
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    u3 ^= (unsigned)c0;
                }
                if (8u) goto L2;
                v0 = ((a0[u1 & 3u] ? g1 : u0) - p1);
            } else {
                if ((unsigned)h0) goto L2;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1((garr[u2 & 7u] << (i0 & 31u)), 0x80000000u, ((0x90f4bedau - i2) & 0x83117d3u)); }
        }
        do { if (--fuel == 0u) goto done;
            switch ((unsigned)w0 & 7u) {
                u0 = u0 * 0x9e3779b1u + (unsigned)!(a0[i0 & 3u] / (((unsigned)b0 / (p1 | 1u)) | 1u));
                w0 ^= (unsigned long long)0xffffffffu << ((unsigned)((int)(unsigned)(0x7fffffffu < (unsigned)(g1 < garr[i1 & 7u])) < (int)(unsigned)((int)u0 >= (int)garr[i1 & 7u])) & 63u);
                d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)((short)7u > (signed char)0x34c6595bu) >= (int)(*mp | (unsigned)(m0 == garr[u2 & 7u]))) & 1023u);
                { unsigned t6; double z6; if (((unsigned)(short)(unsigned)((short)0x776deb80u > (signed char)(p0 & u0))) & 1u) { t6 = (unsigned)x0; z6 = (double)(((a0[i0 & 3u] - (unsigned)(p1 || p1))) & 255u); } if (((unsigned)(short)(unsigned)((short)0x776deb80u > (signed char)(p0 & u0))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                    case 5u: ;
                    f0 = f0 * 0.5f + (float)(((unsigned)(short)(7u >> (garr[u2 & 7u] & 31u)) ^ ((unsigned)e0 % ((unsigned)s1 | 1u))) & 255u);
                    w0 ^= (unsigned long long)p0 << ((unsigned)s1 & 63u);
                    garr[fuel & 7u] = ((8u % ((unsigned)(unsigned char)(unsigned)(p1 == (unsigned)(0x10000u == (unsigned)h0)) | 1u)) ^ a0[i0 & 3u]);
                }
                if (fuel) goto L2;
            }
            q0 = &garr[(((unsigned)c1 << (g0 & 31u)) ^ (6u ? 0x1b45e565u : (unsigned)(x0 >> 70))) & 7u];
            garr[(unsigned)((short)0x10000u > (signed char)(unsigned)c1) & 7u] = -(2u | (unsigned)s1);
        } while (i0++ < 3u && (unsigned)((int)(unsigned)(w0 >> 29) < (int)p1));
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)0x91105c39u > (signed char)(unsigned)(unsigned char)(0xf0118c4bu / ((unsigned)h1 | 1u))), (unsigned)(((unsigned)x0 << (1u & 31u)) < garr[i1 & 7u]), ((unsigned)(unsigned char)(m0 * 0x54ff7e9fu) ^ 0xffffffffu)); }
            if ((unsigned)(short)(p2 % (fuel | 1u))) goto L2;
            *q0 = (unsigned)s0;
            if ((unsigned)((u1 & i1) < 0x8c3909fbu)) break;
            if (budget != 0u) { budget -= 1u; u3 = fn1((g0 ^ g0), r0.y, (((unsigned)f0 ^ (unsigned)e0) * 0x80000000u)); }
        }
        u2 = (unsigned)((int)(a0[u1 & 3u] / (((unsigned)h1 - ((unsigned)b0 / (u2 | 1u))) | 1u)) >= (int)(unsigned)c0);
        w0 = w0 * 6364136223846793005ull + (unsigned)h0;
        if (budget != 0u) { budget -= 1u; u2 = fn3(g1, ((0x7fffffffu & (unsigned)(w0 >> 29)) | garr[u2 & 7u]), (unsigned)d0); }
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (((unsigned)(r0.x && garr[i1 & 7u]) * 5u)) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)h1 == m0)) break;
            while (i2++ < 4u && (unsigned)((0x7edaa37u | i2) == g0)) { if (--fuel == 0u) goto done;
                if ((unsigned)((i1 + 0x10000u) || garr[u2 & 7u])) {
                    if (0x80000000u) break;
                } else {
                    if ((unsigned)(fuel || (u0 ^ u0))) {
                        *q0 += 8u;
                        if ((unsigned)((i1 << ((unsigned)l0 & 31u)) || m0)) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((0xd9f4a678u << ((unsigned)l0 & 31u)) & 0x10000u), u3, (unsigned)(short)(unsigned)(u2 == 0x7fffffffu)); }
                    } else {
                        break; (void)((garr[u2 & 7u] >> (-(8u & 8u) & 31u)));
                        if ((unsigned)(signed char)(2u >> (i1 & 31u))) break;
                    }
                    u1 = ((unsigned)b0 / (fuel | 1u));
                }
            }
            r0.y ^= (unsigned)((int)*mp < (int)((unsigned)((unsigned)w0 < 0xd6f5ec3du) + (0x1af5c859u & 3u)));
            w0 ^= (unsigned long long)(unsigned)((short)u3 > (signed char)(unsigned)w0) << ((unsigned)((unsigned)h1 < (((unsigned)(w0 >> 29) & u3) * (p2 % (0xd95294f1u | 1u)))) & 63u);
            break; (void)(((unsigned)(w0 >> 29) / (garr[i1 & 7u] | 1u)));
        }
        if (budget != 0u) { budget -= 1u; u1 = fn3(-(u2 + garr[u2 & 7u]), (unsigned)(4u || u2), (g0 >> (1u & 31u))); }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((garr[u2 & 7u] % (g1 | 1u)));
            if (budget != 0u) { budget -= 1u; u0 = fn0(~(unsigned)((int)(unsigned)(x0 >> 70) >= (int)u1), (p0 | 0xbab9b5f2u), -(unsigned)(2u < ((unsigned)x0 - *q0))); }
            switch ((unsigned)(*q0 || (u0 << (*q0 & 31u))) & 7u) {
                *q0 += (unsigned)((int)(0x80000000u >> ((unsigned)((short)0x258ec5e5u > (signed char)u0) & 31u)) < (int)(unsigned)((int)(unsigned)e0 >= (int)(unsigned)f0));
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)h1, (unsigned)((int)0x10000u < (int)0x7fffffffu), (0xf9f29c00u ^ (unsigned)f0)); }
            }
        }
        if ((0x10000u >> (p1 & 31u))) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0x10000u < (7u ^ (unsigned)w0)), u2, (unsigned)(w0 >> 29)); }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)0xffffffffu > (signed char)u1), (unsigned)(unsigned char)(garr[u2 & 7u] / ((unsigned)(signed char)(unsigned)((int)garr[u2 & 7u] < (int)*mp) | 1u)), 0x11a14a16u); }
            if (~((unsigned)c1 * (unsigned)s0)) break;
        }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)g1 > (signed char)0x69f3772cu), p2, i0); }
    if (budget != 0u) { budget -= 1u; u1 = fn3((*mp | 0xffffffffu), (unsigned)((int)(unsigned)s1 >= (int)0x926371d9u), ((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)c1) - 0xf97845f9u)); }
    g1 += ((unsigned)!(unsigned)(0x7eb775d9u == *mp) + 0x10000u);
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)(unsigned)(unsigned char)(unsigned)(0x7fffffffu < 0x10000u) >= (int)(unsigned)c1), (unsigned)(signed char)(unsigned)(0x10000u || (0xffffffffu ^ (unsigned)h0)), (unsigned)((short)(unsigned)b0 > (signed char)2u)); }
        if ((unsigned)(short)((unsigned)(x0 >> 70) + 1u)) break;
        *q0 += (unsigned)h0;
        while (i1++ < 4u && (unsigned)((int)2u < (int)u0)) { if (--fuel == 0u) goto done;
            s0 = (int)((0x684663d7u << (p0 & 31u)) % (i0 | 1u));
            switch ((unsigned)(0xc47ba702u < g1) & 7u) {
                while (((unsigned)((short)(unsigned)s0 > (signed char)u2) % (v0 | 1u))) { if (--fuel == 0u) goto done;
                    i0 = 6u & 15u;
                    c0 = (unsigned char)(unsigned)((fuel * (unsigned)h0) || (unsigned)((int)(8u | 2u) < (int)0x7fffffffu));
                    b0 = (unsigned)(9u < (unsigned)((short)m0 > (signed char)((0xffffffffu - v0) * p2))) != 0u;
                }
            }
            h1 = (unsigned short)(h1 + ((unsigned)f0 % ((unsigned)((unsigned)l0 < ((p1 + p1) << (g1 & 31u))) | 1u)));
            g1 += -(unsigned)((short)(unsigned)((unsigned)(p0 || (unsigned)d0) == 0x80000000u) > (signed char)(unsigned)c0);
            break; (void)((unsigned)(short)(unsigned)(2u == (unsigned)h1));
            switch ((g1 & (unsigned)c1) & 7u) {
                if ((unsigned)(x0 >> 70)) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(unsigned)(p2 || m0), (-(unsigned)(0xcfb2af9du < 5u) + 8u), (u1 << ((unsigned)h0 & 31u))); }
                }
                h1 = (unsigned short)(h1 + (a0[u1 & 3u] ? u3 : (unsigned)((short)(p1 - u1) > (signed char)a0[u1 & 3u])));
            }
        }
    }
    while (i0++ < 3u && (unsigned)((int)0x3ab01281u >= (int)fuel)) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((int)(unsigned)d0 >= (int)(unsigned)(*q0 || r0.x)));
        if ((i2 - a0[i0 & 3u])) break;
        m0 ^= (unsigned)(short)(unsigned)((int)(unsigned)f0 >= (int)(unsigned)((short)(v0 * 5u) > (signed char)0x10000u));
        if ((unsigned)l0) {
            break; (void)((unsigned)e0);
            w0 ^= (unsigned long long)(unsigned)((int)fuel < (int)0xdbfcd20eu) << ((unsigned)((short)(unsigned)(r0.y == 0x80000000u) > (signed char)((0x10000u | u1) & (unsigned)c0)) & 63u);
        } else {
            if ((0x80000000u % (p1 | 1u))) goto L2;
            if ((unsigned)((int)(unsigned)x0 < (int)(unsigned)f0)) break;
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)c1, m0, 0x19e3f80cu); }
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(x0 >> 70) || i2) & 1023u);
                w0 ^= (unsigned long long)(unsigned)((unsigned)x0 && g0) << ((*mp >> ((i2 << (a0[u1 & 3u] & 31u)) & 31u)) & 63u);
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    u0 = (unsigned)((0x10000u >> (((unsigned)s1 * i0) & 31u)) && (unsigned)f0);
                    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        g1 += (unsigned)(unsigned char)(unsigned)((short)(unsigned)((unsigned)w0 && (unsigned)x0) > (signed char)(unsigned)s0);
                        h0 = (short)(2u * (3u - (unsigned)h1));
                    }
                    b0 = (unsigned)s0 != 0u;
                    c0 = (unsigned char)(((a0[i0 & 3u] << (a0[i0 & 3u] & 31u)) >> (6u & 31u)) >> (garr[u2 & 7u] & 31u));
                    u0 = (unsigned)(p1 && (unsigned)((unsigned)d0 || 5u));
                    if ((unsigned)(w0 >> 29)) {
                        goto L0;
                        h1 = (unsigned short)(h1 + r0.x);
                        c1 = (signed char)((unsigned)c1 / (((unsigned)h1 % ((unsigned)((short)7u > (signed char)4u) | 1u)) | 1u));
                        switch (m0 & 7u) {
                            if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)h1 ^ 0x56241316u), (unsigned)((0x80000000u - 0x80000000u) && 0x80000000u), (unsigned)(short)(u2 / ((unsigned)c1 | 1u))); }
                        }
                        v0 = (unsigned)(x0 >> 70);
                    } else {
                        r0.y ^= (p0 ^ (unsigned)l0);
                        if (budget != 0u) { budget -= 1u; u2 = fn0(p2, (unsigned)s1, (*q0 >> ((*q0 / ((unsigned)c1 | 1u)) & 31u))); }
                    }
                }
                if ((unsigned)(2u && v0)) break;
            }
        }
    }
    do { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)h1 / (*q0 | 1u)) >= (int)6u));
    } while (i0++ < 3u && (p2 << (0x80000000u & 31u)));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1(i1, ((i1 << (0x80000000u & 31u)) + v0), 0x350d6398u); }
        if ((unsigned)!(unsigned)((short)(unsigned)f0 > (signed char)0x8ca0d540u)) {
            if (0xaa13a2fdu) goto L2;
            goto L4;
            if ((unsigned)(short)(9u / ((unsigned)!(unsigned)((int)0x19adea2du < (int)u0) | 1u))) goto done;
            do { if (--fuel == 0u) goto done;
                if (((unsigned)x0 ? (unsigned)c0 : (unsigned)x0)) break;
            } while (i1++ < 5u && (unsigned)(0xffffffffu || *q0));
            r0.x = ((a0[u1 & 3u] | 8u) % (0x80000000u | 1u));
        }
        { unsigned t7; double z7; if (((g1 << (u0 & 31u))) & 1u) { t7 = (0x10000u * garr[i1 & 7u]); z7 = (double)((7u) & 255u); } if (((g1 << (u0 & 31u))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
            g1 += (((unsigned)f0 ? (unsigned)e0 : (unsigned)b0) % (0x10000u | 1u));
            switch (0x10000u & 7u) {
                f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(((m0 & (unsigned)w0) | (unsigned)f0) + (p1 << (p2 & 31u))) & 255u);
                if (budget != 0u) { budget -= 1u; u3 = fn2((i0 % ((unsigned)((short)u2 > (signed char)(unsigned)x0) | 1u)), (0x7fffffffu / (0xa29be9beu | 1u)), (unsigned)(a0[u1 & 3u] < r0.x)); }
                { unsigned t8; double z8; if (((unsigned)s0) & 1u) { t8 = (unsigned)((int)(unsigned)x0 >= (int)(u0 * (unsigned)x0)); z8 = (double)(((p1 / (0x80000000u | 1u))) & 255u); } if (((unsigned)s0) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                    goto L4;
                    case 4u: ;
                    u2 += ~(unsigned)((unsigned)(unsigned char)(0x9d74e9b1u % ((unsigned)s0 | 1u)) || (unsigned)((i2 << (0x7fffffffu & 31u)) && (unsigned)d0));
                    u0 = (unsigned)((unsigned)(short)((unsigned)e0 | 1u) < (unsigned)(0xde98f585u || (unsigned)(0u < u1)));
                    b0 = (~((unsigned)h0 << (0x10000u & 31u)) / ((0x7fffffffu ^ (unsigned)x0) | 1u)) != 0u;
                    u1 = 0x10000u;
                }
                u2 ^= g1;
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(0xd2393e71u == (u2 % ((unsigned)h1 | 1u))) && (unsigned)s1) & 1023u);
            }
            if ((unsigned)(signed char)(i2 & (r0.y | garr[i1 & 7u]))) continue;
            if ((unsigned)((short)*q0 > (signed char)g1)) break;
        }
    }
    { unsigned t9; double z9; if (((unsigned)((unsigned)(x0 >> 70) && (unsigned)(4u && r0.x))) & 1u) { t9 = (a0[u1 & 3u] ? 8u : 8u); z9 = (double)(((unsigned)((int)0x5df126b1u < (int)(unsigned)b0)) & 255u); } if (((unsigned)((unsigned)(x0 >> 70) && (unsigned)(4u && r0.x))) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
        goto L0;
        do { if (--fuel == 0u) goto done;
            r0.y ^= (g1 ^ (unsigned)(9u && (unsigned)l0));
        } while (i0++ < 4u && u0);
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            a0[0x7fffffffu & 3u] = 2u;
            if (g0) goto L0;
        }
        if (0x134df94eu) goto L2;
        while (i0++ < 5u && fuel) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(((unsigned)c1 >> (0x69e440c0u & 31u)) & (r0.x >> ((unsigned)d0 & 31u))));
                c1 = (signed char)((unsigned)x0 >> ((unsigned)(p0 || ((unsigned)d0 & (unsigned)c1)) & 31u));
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)h1, (unsigned)(i2 == (unsigned)(x0 >> 70)), (unsigned)((short)8u > (signed char)i0)); }
                if (a0[i0 & 3u]) break;
                continue; (void)((unsigned)w0);
            }
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(r0.y || (unsigned)(w0 >> 29)), (unsigned)((3u | 9u) && 0x10000u), i2); }
                do { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return -(unsigned)((int)4u < (int)(unsigned)(unsigned char)(0x1765913du ^ a0[i0 & 3u]));
                    do { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)(unsigned)((unsigned)(x0 >> 70) || 5u) << ((unsigned)((int)*q0 < (int)(unsigned)c0) & 63u);
                        a0[0xc82b93fau & 3u] = m0;
                    } while (i0++ < 5u && 0x3f4b17e0u);
                    do { if (--fuel == 0u) goto done;
                        if (garr[u2 & 7u]) {
                            if (u3 == 7u) return (unsigned)((unsigned)e0 < g0);
                            if (((unsigned)(garr[i1 & 7u] || 1u) - (unsigned)l0)) break;
                            c1 = (signed char)(7u * p2);
                        } else {
                            q0 = &garr[-(((unsigned)(w0 >> 29) >> ((unsigned)((short)i1 > (signed char)(0x80000000u / (0x7fffffffu | 1u))) & 31u)) ^ (unsigned)w0) & 7u];
                        }
                        if ((unsigned)((unsigned)c1 == ((unsigned)s0 & i0))) break;
                    } while (i0++ < 4u && (unsigned)w0);
                    w0 = w0 * 6364136223846793005ull + (fuel / (p2 | 1u));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((m0 ^ 7u), (i1 + (unsigned)((int)(unsigned)s1 >= (int)(unsigned)f0)), a0[i0 & 3u]); }
                } while (i2++ < 7u && (((unsigned)s0 ^ (unsigned)(x0 >> 70)) << (0x3128d7f2u & 31u)));
                if (i0) {
                    r0.y ^= (unsigned)((unsigned)c0 && ((0x6deff1cfu ^ m0) << (0x7fffffffu & 31u)));
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)(signed char)(0x825379deu ? (unsigned)f0 : u1)) {
                            if ((unsigned)((int)p1 < (int)0xbf3424ceu)) break;
                            v0 = (u1 % (3u | 1u));
                            if ((unsigned)(unsigned char)((unsigned)c0 / (0x264c1c7au | 1u))) break;
                        }
                        if ((p1 << (((unsigned)f0 | 0x9950e7bcu) & 31u))) break;
                        break; (void)((unsigned)(garr[u2 & 7u] == (0x10000u & *mp)));
                    }
                    if (((unsigned)((short)r0.y > (signed char)0xbe7f36b5u) & 0x10000u)) break;
                    if (u3 == 7u) return ((unsigned)((int)p0 < (int)0xb7d61d79u) - ((unsigned)c0 | g1));
                    break; (void)(((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0u) | (unsigned)(w0 >> 29)));
                }
                c0 = (unsigned char)((unsigned)(short)(8u * (unsigned)((short)(unsigned)((int)0xffffffffu < (int)i0) > (signed char)0x7fffffffu)) | u2);
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)w0, -(unsigned)((int)0x10000u < (int)0x10000u), 0x2a77975eu); }
                if ((unsigned)(unsigned char)(unsigned)((int)garr[u2 & 7u] < (int)(g1 * 4u))) break;
            }
            h0 = (short)((0x10000u / ((unsigned)f0 | 1u)) ^ (i1 - (unsigned)d0));
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn2(~((unsigned)(x0 >> 70) + (0x10000u ^ (unsigned)f0)), (unsigned)((unsigned)((unsigned)x0 && (unsigned)(w0 >> 29)) < (unsigned)s0), -(i2 >> ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)a0[i0 & 3u]) & 31u))); }
    if ((0x80000000u | i2)) goto L1;
    do { if (--fuel == 0u) goto done;
        s0 = (int)((unsigned)f0 % ((unsigned)(w0 >> 29) | 1u));
        b0 = (3u & (r0.y >> ((unsigned)h0 & 31u))) != 0u;
    } while (i0++ < 2u && (unsigned)b0);
    u3 = (unsigned)(garr[i1 & 7u] < (unsigned)x0);
    h1 = (unsigned short)(h1 + (unsigned)((int)v0 < (int)*mp));
    if (u3 == 7u) return ~((unsigned)((0x7fffffffu * 0x7fffffffu) || 0xc9118da8u) / ((unsigned)x0 | 1u));
    s1 = (int)((unsigned)s1 + 0x4245cdd0u);
    x0 = x0 * 0x100000001b3ull + (unsigned)(x0 >> 70);
    c1 = (signed char)(unsigned)((int)0xb1f6c073u < (int)0xfb2ec123u);
    if (-((unsigned)(*q0 < a0[u1 & 3u]) | 0x9b5f4ef4u)) goto L4;
    if ((fuel ^ 0x80000000u)) goto L3;
    e0 = e0 * 0.5L + (long double)((unsigned)!(unsigned)((int)(a0[u1 & 3u] % ((((unsigned)h1 + 3u) ^ 6u) | 1u)) < (int)i1) & 1023u);
    if (budget != 0u) { budget -= 1u; u0 = fn3(p2, (9u ^ i2), r0.y); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 2u, 0xf9d5a215u, 0xe3c95f44u },
        { 14u, 0x2ba44c82u, 0x2034a3ffu },
        { 9u, 0x366605beu, 0x6ae6b587u },
        { 7u, 0xd5102750u, 0xb5a90fe3u },
        { 13u, 0xec1b8966u, 0xe2540551u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
