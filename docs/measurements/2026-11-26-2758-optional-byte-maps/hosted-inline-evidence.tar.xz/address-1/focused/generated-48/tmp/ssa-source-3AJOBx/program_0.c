// test-ssa-source's program of seed 134000402 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x38e4e481u, g1 = 0x97a5b9eu;
static unsigned garr[8] = { 0x434eeaacu, 0xaf086cfau, 0xe43c55eu, 0xa1e19b9fu, 0x19882c5fu, 0x6c4b8d02u, 0x8cf57bfau, 0x2eb47973u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L0;
    for (;;) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        break; (void)((unsigned)((int)-(unsigned)((unsigned)f0 || garr[u2 & 7u]) < (int)u1));
        L1: if (--fuel == 0u) goto done;
        c1 = (signed char)((unsigned)h0 >> ((unsigned)c0 & 31u));
        do { if (--fuel == 0u) goto done;
            g0 = 0x7fffffffu;
            L2: if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                switch (((unsigned)((short)fuel > (signed char)u2) - r0.x) & 7u) {
                    g0 = ((garr[i1 & 7u] << (i0 & 31u)) >> (0x8fd5e7a5u & 31u));
                    if (fuel < 8u) return (unsigned)((int)((p2 / (0xffffffffu | 1u)) & (unsigned)(u3 < a0[i0 & 3u])) < (int)(unsigned)(x0 >> 70));
                    if ((unsigned)(0x35ae41e4u && (unsigned)!(unsigned)((int)0x303b071eu < (int)garr[u2 & 7u]))) continue;
                    s0 = (int)g0;
                }
                g1 += ((unsigned)d0 ^ (unsigned)(0x41d53579u == ~(p2 | v0)));
                if (fuel < 8u) return i0;
            }
            *q0 += (0x2efd90b7u - 0u);
            e0 = e0 * 0.5L + (long double)((i0 << ((unsigned)(r0.x || 0x836c8226u) & 31u)) & 1023u);
            break; (void)(u0);
        } while (i1++ < 2u && (unsigned)(u3 < (unsigned)(0xffffffffu == (unsigned)c0)));
    }
    if ((unsigned)((i0 ^ a0[i0 & 3u]) && (unsigned)d0)) {
        L3: if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)e0 && ((unsigned)(u0 == 7u) + (unsigned)(signed char)(unsigned)(0x80000000u && 0x10000u))) & 255u);
    }
    switch ((unsigned)((int)(unsigned)c0 < (int)(g0 - (unsigned)w0)) & 7u) {
        m0 ^= (unsigned)(short)((unsigned)l0 | (unsigned)(6u < (unsigned)f0));
        m0 ^= 2u;
        { unsigned t0; double z0; if (((g1 & (unsigned)l0)) & 1u) { t0 = (r0.x - (unsigned)(8u == (unsigned)c0)); z0 = (double)((0xb965654eu) & 255u); } if (((g1 & (unsigned)l0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            s1 = (int)((unsigned)s1 + (r0.y ? (*q0 % (0x33e2a047u | 1u)) : u1));
        }
        for (;;) { if (--fuel == 0u) goto done;
            *q0 += (unsigned)((int)garr[u2 & 7u] >= (int)6u);
            while (i1++ < 7u && (unsigned)(i1 || (unsigned)l0)) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)((unsigned)l0 << ((unsigned)((short)(unsigned)f0 > (signed char)i1) & 31u)) & 1023u);
                { unsigned t1; double z1; if (((0xac7866e3u % ((g0 >> (r0.y & 31u)) | 1u))) & 1u) { t1 = (r0.x | (unsigned)((short)0x10000u > (signed char)0xffffffffu)); z1 = (double)(((unsigned)(unsigned char)(unsigned)((short)r0.y > (signed char)0xd4956b71u)) & 255u); } if (((0xac7866e3u % ((g0 >> (r0.y & 31u)) | 1u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    L4: if (--fuel == 0u) goto done;
                    *q0 = (unsigned)((int)(((unsigned)(0xf0229b7cu && 0x10000u) / (0x7f31d944u | 1u)) % (6u | 1u)) < (int)(unsigned)c0);
                    case 4u: ;
                }
                case 1u: ;
            }
            default: ;
        }
        case 7u: ;
        while (i0++ < 7u && (unsigned)((unsigned)s1 || 0u)) { if (--fuel == 0u) goto done;
            case 3u: ;
            if (u3 == 7u) return r0.y;
            h0 = (short)((unsigned)s0 + 0x80000000u);
            g1 += (p1 % ((unsigned)c0 | 1u));
            break;
        }
    }
    w0 ^= (unsigned long long)p1 << ((unsigned)(signed char)(unsigned)((unsigned)s0 || 9u) & 63u);
    if (((unsigned)(short)(unsigned)(0x80000000u < a0[i0 & 3u]) ^ p1)) goto L4;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)f0) break;
        break; (void)(~(unsigned)(i1 == p0));
        if ((unsigned)(short)(v0 % (garr[i1 & 7u] | 1u))) break;
        if ((unsigned)((int)p2 < (int)(unsigned)l0)) break;
        if ((*q0 | (unsigned)(r0.y < (unsigned)b0))) break;
    } while (i0++ < 2u && ((0x3569903du << (i0 & 31u)) >> (0x94960ca3u & 31u)));
    while (i0++ < 3u && ((unsigned)(u3 == u3) / (0x80000000u | 1u))) { if (--fuel == 0u) goto done;
        { unsigned t2; double z2; if (((0xf54e2941u ? g1 : *q0)) & 1u) { t2 = 6u; z2 = (double)(((unsigned)(signed char)(7u & 4u)) & 255u); } if (((0xf54e2941u ? g1 : *q0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            while (((unsigned)(w0 >> 29) | u1)) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(garr[i1 & 7u] == 0x7fffffffu))) continue;
                if (((unsigned)(x0 >> 70) * i2)) break;
                d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(p1 * (r0.y ? p2 : i1)) & 1023u);
                v0 = ((a0[i0 & 3u] + 8u) - r0.y);
                if (g0) {
                    if ((i1 | u3)) continue;
                    h1 = (unsigned short)(h1 + ~(unsigned)((unsigned)((int)(0xffffffffu - p1) < (int)r0.y) == g0));
                    if ((unsigned)(0x67c927edu < u1)) break;
                    break; (void)(((unsigned)d0 >> ((unsigned)s0 & 31u)));
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)(~((unsigned)(short)(unsigned)((int)i1 < (int)(unsigned)((unsigned)s0 && p0)) << (0xffffffffu & 31u)) & 255u);
                        s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(unsigned)((g1 & (unsigned)c1) && 8u));
                        if ((i2 * (unsigned)(x0 >> 70))) continue;
                        h0 = (short)(unsigned)((int)(unsigned)(signed char)(unsigned)((short)((unsigned)(x0 >> 70) - (*mp / (i0 | 1u))) > (signed char)4u) >= (int)a0[u1 & 3u]);
                    }
                }
                v0 = ((unsigned)s1 | 0x10000u);
            }
            do { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((0xe91fee0au + (unsigned)(unsigned char)((unsigned)b0 % (a0[u1 & 3u] | 1u)))) break;
                    q0 = &garr[(((unsigned)w0 & fuel) % (*q0 | 1u)) & 7u];
                }
                d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)((int)garr[u2 & 7u] < (int)(fuel / (p2 | 1u))) >= (int)r0.y) & 1023u);
                b0 = ((unsigned)h1 ? (unsigned)d0 : (unsigned)b0) != 0u;
                i2 = (unsigned)((int)(unsigned)(u1 || a0[i0 & 3u]) >= (int)0xffffffffu) & 15u;
            } while (i1++ < 4u && (unsigned)(signed char)(0x7fffffffu << (g1 & 31u)));
        }
        if ((unsigned)((unsigned)(w0 >> 29) || (unsigned)w0)) break;
    }
    do { if (--fuel == 0u) goto done;
        if ((a0[u1 & 3u] ^ (unsigned)((unsigned)e0 || u1))) goto done;
        if ((unsigned)(7u && p2)) break;
        if ((unsigned)((unsigned)s0 == (u0 | 0xffffffffu))) break;
        if ((4u * (unsigned)((short)u1 > (signed char)i1))) break;
        break; (void)((unsigned)(0x92dc5cceu || 0x975867feu));
        u3 += (8u + u1);
    } while (i0++ < 4u && ((unsigned)l0 >> ((unsigned)h1 & 31u)));
    if ((unsigned)((short)u2 > (signed char)(garr[i1 & 7u] | u1))) goto L3;
    h0 = (short)~(((unsigned)!(0x12fac0feu - a0[i0 & 3u]) - (unsigned)!(m0 ^ (unsigned)b0)) << (0x41c34094u & 31u));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            while (i2++ < 3u && fuel) { if (--fuel == 0u) goto done;
                *q0 += (unsigned)(0x90f9089du == (0x10000u & (unsigned)((int)7u >= (int)0x10000u)));
                v0 = (unsigned)(*mp || 0xb5866350u);
                break; (void)((unsigned)(w0 >> 29));
                u2 = u2 * 0x9e3779b1u + (unsigned)((int)((u0 - 0x7fffffffu) - 0x8d42f36fu) >= (int)(unsigned)h0);
                garr[((unsigned)s1 / (0x7a5eead5u | 1u)) & 7u] = -((unsigned)x0 % ((unsigned)b0 | 1u));
            }
            e0 = e0 * 0.5L + (long double)(7u & 1023u);
            if (0x5b00fffbu) break;
            if ((unsigned)(m0 == (unsigned)h0)) break;
            x0 = x0 * 0x100000001b3ull + ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)u3) % (((5u - (unsigned)h1) - p0) | 1u));
        } while (i1++ < 5u && ((unsigned)(garr[i1 & 7u] && r0.x) | 0xc755253bu));
    }
    { unsigned t3; double z3; if (((unsigned)((int)0x80000000u < (int)(unsigned)((unsigned)s1 && p1))) & 1u) { t3 = (0x11dc0aadu << ((unsigned)!(unsigned)(fuel == g1) & 31u)); z3 = (double)((((unsigned)c1 | 0x7fffffffu)) & 255u); } if (((unsigned)((int)0x80000000u < (int)(unsigned)((unsigned)s1 && p1))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        if (0xffffffffu) {
            { unsigned t4; double z4; if (((0xb569f9e0u - (unsigned)!(p1 % (9u | 1u)))) & 1u) { t4 = (0xc1d664f4u / ((a0[u1 & 3u] % (fuel | 1u)) | 1u)); z4 = (double)(((0x10000u ^ (unsigned)l0)) & 255u); } if (((0xb569f9e0u - (unsigned)!(p1 % (9u | 1u)))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                if (1u) goto L3;
                r0.x = (unsigned)((0x91033143u + (unsigned)h1) < (unsigned)s0);
                b0 = (unsigned)(r0.y < r0.x) != 0u;
                if ((unsigned)e0) goto L3;
                goto L1;
            }
            u1 += (unsigned)((int)(unsigned)((short)(unsigned)(u2 || m0) > (signed char)1u) >= (int)(unsigned)(0x10000u && u3));
            switch ((unsigned)(short)(((unsigned)x0 - 0xffffffffu) * g0) & 7u) {
                w0 ^= (unsigned long long)(unsigned)c0 << ((((unsigned)(w0 >> 29) % ((unsigned)b0 | 1u)) << ((unsigned)(x0 >> 70) & 31u)) & 63u);
                case 5u: ;
                if (0xffffffffu) break;
                do { if (--fuel == 0u) goto done;
                    garr[u2 & 7u] = ((unsigned)x0 * 0xffffffffu);
                    if ((unsigned)(signed char)((unsigned)b0 / (((unsigned)x0 << ((unsigned)e0 & 31u)) | 1u))) continue;
                    case 4u: ;
                } while (i0++ < 3u && (unsigned)x0);
            }
            goto L3;
        } else {
            { unsigned t5; double z5; if (((7u & 0xedc90625u)) & 1u) { t5 = ((unsigned)b0 | (unsigned)c0); z5 = (double)((a0[i0 & 3u]) & 255u); } if (((7u & 0xedc90625u)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                goto L3;
                if ((unsigned)((u2 + (unsigned)l0) < 0xffffffffu)) goto L3;
                u0 ^= (9u >> (i2 & 31u));
                u2 = ((unsigned)(x0 >> 70) & (unsigned)((int)0x80000000u < (int)(a0[i0 & 3u] ^ ((unsigned)c1 ^ p0))));
            }
            if ((unsigned)w0) {
                if (fuel < 8u) return (0x70a5b813u * (unsigned)h0);
                c1 = (signed char)(unsigned)((((unsigned)x0 / (r0.x | 1u)) - (unsigned)s0) < (0xc915ae04u ^ (unsigned)(x0 >> 70)));
                *q0 += (unsigned)((unsigned)c0 && (*mp | (unsigned)x0));
                r0.y ^= (*mp % (garr[u2 & 7u] | 1u));
            }
            while (i0++ < 5u && (unsigned)(signed char)(unsigned)((int)(1u << ((unsigned)f0 & 31u)) < (int)u3)) { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)x0 + (unsigned)!(p0 ^ i2)));
                c0 = (unsigned char)0x80000000u;
            }
        }
        u0 ^= ((0x80000000u % (0x282896dfu | 1u)) << ((unsigned)d0 & 31u));
    }
    while (((unsigned)e0 ^ ((unsigned)w0 - garr[u2 & 7u]))) { if (--fuel == 0u) goto done;
        if ((0x631e6862u * 5u)) {
            if (0x941f2a46u) break;
            w0 = w0 * 6364136223846793005ull + (unsigned)h0;
        } else {
            break; (void)(0x482c7f3bu);
            *mp = ((unsigned)x0 + ((unsigned)d0 / ((unsigned)((int)0x89e8d053u >= (int)(u1 >> (g0 & 31u))) | 1u)));
        }
        if ((unsigned)((int)m0 < (int)r0.y)) {
            if (3u) break;
            g1 += (unsigned)(signed char)(g1 & ((unsigned)f0 ^ (unsigned)((int)(unsigned)h1 < (int)(a0[u1 & 3u] * r0.y))));
        } else {
            break; (void)((unsigned)(3u < u0));
        }
        g0 = (unsigned)((short)(unsigned)((unsigned)s0 == (i1 ? 0xffffffffu : (unsigned)c1)) > (signed char)(unsigned)(x0 >> 70));
        while (i1++ < 3u && 0x7b6cc42bu) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                u1 ^= (unsigned)((*mp ^ 0x80000000u) && ((unsigned)(signed char)((unsigned)w0 * 0xdd6a7aa8u) << (0x80000000u & 31u)));
            }
        }
    }
    if ((i2 / ((unsigned)h0 | 1u))) goto L1;
    do { if (--fuel == 0u) goto done;
        if (g0) break;
        if (0x2b00fe0u) {
            if (g0) break;
        } else {
            e0 = e0 * 0.5L + (long double)(((unsigned)(x0 >> 70) + u0) & 1023u);
            *mp = ((unsigned)((int)(unsigned)x0 < (int)m0) ^ (unsigned)((int)(unsigned)w0 >= (int)0x78184f8du));
        }
        if (7u) break;
        i0 = (unsigned)(short)(((unsigned)((unsigned)c1 && 0x7322636du) - u0) - (u2 ^ m0)) & 15u;
        g1 += (unsigned)((int)(unsigned)(garr[i1 & 7u] == garr[u2 & 7u]) >= (int)(unsigned)(x0 >> 70));
    } while (i0++ < 3u && (unsigned)(w0 >> 29));
    if ((-(u3 & (unsigned)l0) ^ a0[i0 & 3u])) goto L3;
    e0 = e0 * 0.5L + (long double)(((unsigned)e0 | (0xffffffffu ^ (unsigned)!((unsigned)c0 & 6u))) & 1023u);
    if (r0.y) goto L4;
    if ((unsigned)(x0 >> 70)) goto L1;
    goto L1;
    if ((unsigned)((int)(unsigned)c0 < (int)a0[u1 & 3u])) goto L1;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (r0.y * (unsigned)!(unsigned)((int)u1 < (int)((unsigned)h1 ? 0x87da0888u : (unsigned)f0)));
        if ((*q0 >> ((unsigned)((unsigned)c0 && a0[u1 & 3u]) & 31u))) break;
        if (6u) break;
        if ((p0 << (4u & 31u))) break;
        x0 = x0 * 0x100000001b3ull + (unsigned)(i1 || (unsigned)((r0.y - garr[i1 & 7u]) || u3));
    }
    if (r0.x) {
        s0 = (int)(unsigned)(r0.x == (unsigned)c1);
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(u1 >> (((7u | 4u) ? r0.x : (unsigned)c0) & 31u)) & 1023u);
            if (garr[u2 & 7u]) {
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)(g1 || (0x10000u ^ 0xd89d4bcdu))) break;
                } while (i1++ < 5u && (unsigned)e0);
                r0.y ^= ((0x43d2f162u % (m0 | 1u)) / (4u | 1u));
                if ((unsigned)(*mp == (unsigned)(2u == p1))) {
                    if (garr[u2 & 7u]) continue;
                    u2 ^= (unsigned)(short)((unsigned)(short)(((unsigned)((int)(unsigned)d0 < (int)0x7fffffffu) ^ (unsigned)s0) << (r0.y & 31u)) | 8u);
                    if ((garr[i1 & 7u] % ((unsigned)(p0 && garr[i1 & 7u]) | 1u))) break;
                } else {
                    *q0 = (3u >> ((unsigned)((unsigned)h0 && (unsigned)w0) & 31u));
                    if ((unsigned)l0) break;
                }
                w0 = w0 * 6364136223846793005ull + (r0.y / ((*mp ? p0 : r0.y) | 1u));
                continue; (void)(((unsigned)c0 ? (unsigned)e0 : g0));
                s0 = (int)(unsigned)((short)garr[u2 & 7u] > (signed char)((unsigned)l0 * (0x10000u ? a0[u1 & 3u] : (unsigned)f0)));
            } else {
                g0 = ((unsigned)s0 + (unsigned)(u3 || (unsigned)((int)2u >= (int)~((unsigned)(w0 >> 29) % (9u | 1u)))));
                garr[(unsigned)((int)u1 >= (int)0x10000u) & 7u] = ((m0 ^ (unsigned)c1) - 0x5766166du);
            }
        }
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            *mp = (unsigned)((unsigned)h1 < (unsigned)((unsigned)x0 < (unsigned)h1));
            r0.y ^= (unsigned)(0u < p1);
            d0 = d0 * 0.5 + (double)(0xc1967bc4u & 1023u);
            if (((unsigned)s0 ^ (0xffffffffu ^ r0.y))) break;
        }
        if ((unsigned)l0) goto L0;
    } else {
        i2 = a0[u1 & 3u] & 15u;
        if ((unsigned)((unsigned)b0 < ~((unsigned)x0 | (unsigned)s0))) goto L3;
        if (0x57c831eu) goto L2;
        while ((unsigned)(garr[u2 & 7u] && 0xffffffffu)) { if (--fuel == 0u) goto done;
            if (((unsigned)(w0 >> 29) ? 0xa2bf7ac9u : p0)) goto L4;
            if ((0xcbbffd5u ^ (unsigned)x0)) break;
            break; (void)((unsigned)(short)(0xc1cb675au * i2));
        }
    }
    if (m0) goto done;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t6; double z6; if ((garr[u2 & 7u]) & 1u) { t6 = 0x54fc35du; z6 = (double)(((unsigned)(g0 || i1)) & 255u); } if ((garr[u2 & 7u]) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
            do { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + -(~(unsigned)(2u == (unsigned)b0) * (unsigned)d0));
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(u1 < (unsigned)b0)) break;
                    u3 ^= ((unsigned)!(unsigned)((unsigned)((int)u0 >= (int)a0[i0 & 3u]) < 0x7fffffffu) * (unsigned)((unsigned)w0 || r0.y));
                    break; (void)((unsigned)d0);
                    if (((unsigned)d0 | r0.x)) break;
                    for (;;) { if (--fuel == 0u) goto done;
                        goto L3;
                        q0 = &garr[(unsigned)((i0 >> (*mp & 31u)) && (unsigned)e0) & 7u];
                        if ((unsigned)c0) goto L2;
                        break; (void)(((unsigned)x0 | (unsigned)h1));
                        if ((i1 - r0.y)) break;
                    }
                    if ((unsigned)((unsigned)e0 == (unsigned)l0)) break;
                }
                if (-((unsigned)(w0 >> 29) << ((fuel + (unsigned)(x0 >> 70)) & 31u))) break;
                r0.x = (unsigned)((unsigned)((unsigned)!(unsigned)(g1 == garr[i1 & 7u]) < p2) == 8u);
                break; (void)((unsigned)(signed char)((unsigned)(i2 < (unsigned)c0) >> (i0 & 31u)));
            } while (i1++ < 3u && g0);
            m0 ^= ((unsigned)d0 << ((unsigned)((int)1u >= (int)(unsigned)b0) & 31u));
            if ((unsigned)((int)u3 >= (int)a0[i0 & 3u])) break;
            break; (void)(a0[i0 & 3u]);
        }
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t7; double z7; if ((((unsigned)s1 >> (9u & 31u))) & 1u) { t7 = (unsigned)((unsigned)s1 < 0x7fffffffu); z7 = (double)((p1) & 255u); } if ((((unsigned)s1 >> (9u & 31u))) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
            u0 = (((unsigned)f0 * (unsigned)((0x37ce5f0fu | r0.y) || 0x26c74ea5u)) % (r0.x | 1u));
            l0 = (long)((unsigned long)l0 + (0x80000000u % ((0x646b1b30u ? 9u : fuel) | 1u)));
        }
        { unsigned t8; double z8; if ((u1) & 1u) { t8 = (unsigned)((int)(unsigned)c0 < (int)0xffffffffu); z8 = (double)(((unsigned)b0) & 255u); } if ((u1) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
            r0.x = (unsigned)d0;
            continue; (void)(~(p0 - (unsigned)(w0 >> 29)));
            while (i1++ < 7u && (unsigned)(unsigned char)(unsigned)(g0 && 0x840a57cdu)) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(signed char)(unsigned)((int)*q0 >= (int)(2u | 2u)));
                if (0x7fffffffu) goto L3;
                v0 = -(a0[u1 & 3u] / ((unsigned)h1 | 1u));
            }
        }
        if ((garr[u2 & 7u] - g1)) {
            if (0x73ba1e90u) break;
        } else {
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)f0 < (int)(a0[i0 & 3u] * i2))) goto done;
                if (u3 == 7u) return (unsigned)(short)(unsigned)((int)r0.x < (int)(0x118f8fc0u ^ (unsigned)!((unsigned)b0 ? 8u : 0x86bd4b6cu)));
                *q0 = (~((unsigned)h0 / (0x10000u | 1u)) & (9u ^ (unsigned)((int)0xfc22b359u < (int)p0)));
                f0 = f0 * 0.5f + (float)((~(8u | 0xedc78abdu) ^ (6u / (9u | 1u))) & 255u);
                if (p1) break;
                if (i2) break;
            }
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)((int)0x10000u < (int)(unsigned)f0);
                    if (0x7fffffffu) break;
                } while (i2++ < 4u && g0);
            }
            c0 = (unsigned char)p2;
            q0 = &garr[fuel & 7u];
        }
        if ((unsigned)s1) break;
        m0 ^= (6u ^ ((unsigned)(x0 >> 70) * m0));
        if ((unsigned)x0) break;
    }
    if (fuel < 8u) return (unsigned)((unsigned)(w0 >> 29) && (unsigned)(short)(unsigned)(i1 || 0x10000u));
    w0 = w0 * 6364136223846793005ull + ((unsigned)x0 - (v0 + a0[u1 & 3u]));
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)((int)(unsigned)x0 >= (int)m0) || v0)) {
            if ((i1 >> ((unsigned)((int)*q0 >= (int)2u) & 31u))) break;
            if ((unsigned)((int)garr[u2 & 7u] >= (int)(0x375a4899u | g1))) continue;
            if ((unsigned)((int)(g1 >> (m0 & 31u)) < (int)(unsigned)(x0 >> 70))) {
                if ((unsigned)((int)u2 >= (int)0x10000u)) {
                    if ((unsigned)((int)0x80000000u >= (int)(unsigned)((int)0x10000u < (int)0x7fffffffu))) break;
                    if (((unsigned)c0 - (*q0 ^ 0x5bd89ec8u))) goto L1;
                    if ((r0.y ? 8u : (unsigned)l0)) break;
                    goto L3;
                } else {
                    if ((a0[u1 & 3u] & 0x7fffffffu)) break;
                    if (0xffffffffu) {
                        if (garr[i1 & 7u]) break;
                        if ((unsigned)(w0 >> 29)) break;
                        q0 = &garr[(unsigned)(u3 == *q0) & 7u];
                        garr[((unsigned)l0 / ((unsigned)f0 | 1u)) & 7u] = 4u;
                    }
                }
                while (7u) { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        m0 ^= (i0 * *mp);
                        do { if (--fuel == 0u) goto done;
                            w0 ^= (unsigned long long)(unsigned)((int)(unsigned)s1 >= (int)m0) << (((unsigned)(signed char)(g1 >> (u2 & 31u)) ^ (r0.y * (unsigned)x0)) & 63u);
                            g1 += (0x52450d22u >> ((unsigned)b0 & 31u));
                            u2 ^= (unsigned)x0;
                            x0 = x0 * 0x100000001b3ull + ((r0.y >> ((unsigned)((short)0x80000000u > (signed char)0x73359affu) & 31u)) - g0);
                            e0 = e0 * 0.5L + (long double)((-(unsigned)(i2 < (0xe117b51au * (unsigned)c0)) - 0xffffffffu) & 1023u);
                            if (v0) break;
                        } while (i0++ < 4u && (g1 - (m0 & (unsigned)f0)));
                        if ((0x4532d8d0u - (0x7fffffffu | *mp))) break;
                    }
                    while (i2++ < 7u && (unsigned)((unsigned)f0 && (0x698f1928u / (u2 | 1u)))) { if (--fuel == 0u) goto done;
                        u1 = u1 * 0x9e3779b1u + ((unsigned)((unsigned)((short)u3 > (signed char)(unsigned)!(i0 >> (*mp & 31u))) < 0xffffffffu) ^ 1u);
                        break; (void)((((unsigned)(w0 >> 29) ^ u0) & (unsigned)(w0 >> 29)));
                        if ((unsigned)d0) break;
                        break; (void)((0xe9f5438eu >> ((unsigned)b0 & 31u)));
                    }
                    if (-(i0 - 0xf2da6a5u)) {
                        h1 = (unsigned short)(h1 + (((unsigned)s0 - (unsigned)h0) | (unsigned)((unsigned)((unsigned)s1 < (unsigned)s0) && 1u)));
                        if ((unsigned)(short)(-(i0 << (*mp & 31u)) << (0xf682e13u & 31u))) break;
                        m0 ^= (unsigned)(signed char)(unsigned)((~((unsigned)l0 ^ 8u) | (unsigned)f0) == (unsigned)c0);
                        b0 = 0x7ac15312u != 0u;
                    } else {
                        w0 ^= (unsigned long long)(unsigned)((unsigned)(x0 >> 70) == garr[i1 & 7u]) << ((a0[u1 & 3u] % ((unsigned)(a0[i0 & 3u] && p1) | 1u)) & 63u);
                    }
                    break; (void)(8u);
                    if (((unsigned)(w0 >> 29) ^ (a0[i0 & 3u] + (unsigned)h1))) goto L1;
                    if (((unsigned)e0 % (garr[u2 & 7u] | 1u))) break;
                }
                u0 = a0[u1 & 3u];
                garr[(unsigned)(g0 && (unsigned)l0) & 7u] = ((garr[i1 & 7u] & g1) % ((unsigned)(a0[i0 & 3u] == (unsigned)d0) | 1u));
            } else {
                continue; (void)((0x36b88aeau << (g0 & 31u)));
                u0 = u0 * 0x9e3779b1u + 0x10000u;
                if (~(unsigned)((6u + p0) == p2)) break;
                if ((0x80000000u ? 8u : 0x7fffffffu)) goto L2;
            }
        }
    }
    goto L2;
    goto L3;
    if (u3) goto done;
    if ((*mp ^ (unsigned)d0)) goto done;
    m0 ^= g0;
    r0.y ^= ((unsigned)(0x168d08e9u < (m0 ^ r0.y)) - (unsigned)(g1 == 1u));
    e0 = e0 * 0.5L + (long double)((unsigned)((i2 - (unsigned)(x0 >> 70)) < a0[u1 & 3u]) & 1023u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (i0) break;
        L0: if (--fuel == 0u) goto done;
        u1 ^= fuel;
        garr[((unsigned)w0 - 0xffffffffu) & 7u] = ((unsigned)(w0 >> 29) | (0x41c8ba37u / (0xb6c3732bu | 1u)));
        while ((unsigned)!(unsigned)(0x10000u && (unsigned)c1)) { if (--fuel == 0u) goto done;
            continue; (void)(((unsigned)s0 | (unsigned)(u2 || u0)));
        }
    }
    if ((unsigned)(short)(0xd1c0094bu | (unsigned)((unsigned)d0 || garr[u2 & 7u]))) {
        while (i0++ < 4u && 0x80000000u) { if (--fuel == 0u) goto done;
            *q0 += (((unsigned)c1 >> (1u & 31u)) - (unsigned)(unsigned char)(p2 ? (unsigned)b0 : g1));
            u1 ^= i2;
            u2 += (i1 ^ (((unsigned)h1 >> ((unsigned)(w0 >> 29) & 31u)) << (*q0 & 31u)));
            q0 = &garr[(unsigned)((unsigned)((int)0x51855afcu < (int)0x2d805152u) && (0xffffffffu >> (a0[i0 & 3u] & 31u))) & 7u];
        }
        goto L3;
        *q0 = (unsigned)(signed char)((*q0 * (unsigned)b0) << (p2 & 31u));
        L1: if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (m0 / ((unsigned)((int)(unsigned)((unsigned)s0 || 0x6e06b035u) < (int)(p1 ^ (unsigned)w0)) | 1u)));
    } else {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            u0 = u0 * 0x9e3779b1u + (unsigned)((short)g0 > (signed char)0x3b885fb0u);
            if (budget != 0u) { budget -= 1u; u2 = fn0(((u2 * p2) * p1), 0xd106c02au, (unsigned)((int)0x7fffffffu >= (int)((unsigned)b0 << (r0.y & 31u)))); }
        }
        L2: if (--fuel == 0u) goto done;
    }
    if ((unsigned)x0) goto L3;
    if ((unsigned)((short)a0[u1 & 3u] > (signed char)0xd37fd564u)) {
        s1 = (int)((unsigned)s1 + (0xffffffffu | (unsigned)h1));
        m0 ^= (0x80000000u ^ (unsigned)(signed char)((unsigned)f0 - g0));
        e0 = e0 * 0.5L + (long double)(((unsigned)(i1 && (1u / (0x899be769u | 1u))) * 0x10000u) & 1023u);
    }
    if (u3 == 7u) return ((unsigned)s0 / (0x7fffffffu | 1u));
    if ((((unsigned)l0 << (garr[i1 & 7u] & 31u)) - 0x7fffffffu)) {
        L3: if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            g1 += ((((unsigned)b0 | g0) / (0x4f12feb8u | 1u)) << (((unsigned)c0 - (unsigned)s1) & 31u));
            L4: if (--fuel == 0u) goto done;
            continue; (void)((unsigned)(short)(6u ^ 0xffffffffu));
        } while (i0++ < 3u && (unsigned)((int)(unsigned)c1 >= (int)*q0));
        switch ((unsigned)!(unsigned)((unsigned)s1 && (unsigned)(p1 == (unsigned)w0)) & 7u) {
            while (i0++ < 3u && (unsigned)w0) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (unsigned)(~(unsigned)(0xd907a9edu || m0) == (unsigned)((short)a0[i0 & 3u] > (signed char)v0)));
                s0 = (int)(unsigned)((int)a0[u1 & 3u] >= (int)0x10000u);
                x0 = x0 * 0x100000001b3ull + ((unsigned)!(unsigned)((short)*mp > (signed char)0xffffffffu) + (unsigned)(2u || (unsigned)w0));
                l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)e0 < garr[i1 & 7u]) + 7u));
                if ((unsigned)(short)(0u >> (u0 & 31u))) goto L3;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((short)i0 > (signed char)(unsigned)c1) ^ (unsigned)s1), (unsigned)((int)9u < (int)7u), (r0.x >> (0x14e94dc0u & 31u))); }
        }
        if ((unsigned)((unsigned)f0 && (unsigned)c0)) {
            { unsigned t0; double z0; if (((unsigned)((unsigned)b0 && (unsigned)(p1 || 0xc3bbca10u))) & 1u) { t0 = (u0 - m0); z0 = (double)(((u1 << (u1 & 31u))) & 255u); } if (((unsigned)((unsigned)b0 && (unsigned)(p1 || 0xc3bbca10u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                c0 = (unsigned char)(unsigned)((int)r0.y >= (int)(v0 + (*mp << (garr[u2 & 7u] & 31u))));
                e0 = e0 * 0.5L + (long double)((unsigned)((u1 / ((unsigned)h0 | 1u)) < (unsigned)(0x10000u || p1)) & 1023u);
                switch ((unsigned)(signed char)(i0 & g0) & 7u) {
                    h0 = (short)0x7fffffffu;
                    do { if (--fuel == 0u) goto done;
                        u2 = (unsigned)((unsigned)(signed char)((unsigned)h1 ^ *q0) < (4u << ((unsigned)b0 & 31u)));
                        i0 = (unsigned)s0 & 15u;
                        switch ((unsigned)((short)(unsigned)((int)a0[u1 & 3u] < (int)0xeea69f2au) > (signed char)r0.y) & 7u) {
                            case 0u: ;
                            if (budget != 0u) { budget -= 1u; u2 = fn0(*q0, -(fuel - (unsigned)((short)0x34d27132u > (signed char)r0.y)), ((unsigned)((unsigned)s1 < 0x1c879908u) << (garr[i1 & 7u] & 31u))); }
                            w0 ^= (unsigned long long)(unsigned)(g0 || p2) << ((i2 >> (((unsigned)e0 + (unsigned)l0) & 31u)) & 63u);
                            garr[(unsigned)(short)(unsigned)(0x7fffffffu && 0xe80f7a4eu) & 7u] = (a0[u1 & 3u] - 0xffffffffu);
                            goto L0;
                            if ((0x10000u / (*q0 | 1u))) goto L0;
                        }
                        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(p0 && (unsigned)c1) < (unsigned)((int)((unsigned)l0 / (0x46d6c9fdu | 1u)) < (int)1u)));
                    } while (i0++ < 6u && r0.y);
                    b0 = 3u != 0u;
                    case 2u: ;
                }
            }
            if (((unsigned)(w0 >> 29) ^ (unsigned)(0x7fffffffu == (unsigned)s1))) goto L1;
            while (i0++ < 3u && (u1 >> ((unsigned)((short)2u > (signed char)p2) & 31u))) { if (--fuel == 0u) goto done;
                if (((2u ^ p2) * g0)) {
                    garr[(5u * (unsigned)d0) & 7u] = (unsigned)((5u * (0x10000u ^ 5u)) == 0xa5570ef3u);
                }
                h0 = (short)(((unsigned)((int)(u1 >> (r0.y & 31u)) < (int)i0) << (r0.y & 31u)) / (0x20a5640fu | 1u));
                if (budget != 0u) { budget -= 1u; u1 = fn0(5u, i2, (g1 >> (0x235784d5u & 31u))); }
                do { if (--fuel == 0u) goto done;
                    v0 = (unsigned)(((unsigned)(x0 >> 70) - (unsigned)(m0 < garr[i1 & 7u])) && (unsigned)((short)u0 > (signed char)(unsigned)s0));
                    if (-(0x531a2c10u | (p0 - 0x846ac584u))) break;
                    d0 = d0 * 0.5 + (double)(0u & 1023u);
                    w0 = w0 * 6364136223846793005ull + *mp;
                } while (i1++ < 6u && ((unsigned)s0 * (unsigned)!(unsigned)((short)(unsigned)s0 > (signed char)(unsigned)c0)));
            }
            g1 += ((unsigned)h0 << (i1 & 31u));
        }
    } else {
        goto L3;
    }
    if ((unsigned)(p2 && (unsigned)f0)) {
        q0 = &garr[(0x4f18757cu / ((unsigned)(unsigned char)((0x9e1a0d0du << ((unsigned)e0 & 31u)) - m0) | 1u)) & 7u];
        u2 += (unsigned)(((unsigned)x0 ^ u2) < (unsigned)b0);
        goto L2;
        if ((unsigned)(w0 >> 29)) goto L0;
    } else {
        goto L1;
        if ((unsigned)((short)garr[u2 & 7u] > (signed char)5u)) goto L4;
        if (p1) goto L2;
    }
    *mp = (((unsigned)c1 >> ((unsigned)c0 & 31u)) << ((unsigned)s0 & 31u));
    if (5u) goto done;
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)6u < (int)(unsigned)(i0 || (unsigned)w0)), (((unsigned)h0 % (6u | 1u)) | p1), (unsigned)(v0 || a0[i0 & 3u])); }
    if ((unsigned)((int)(unsigned)e0 >= (int)(unsigned)f0)) {
        if ((unsigned)((short)i0 > (signed char)(unsigned)(5u && g0))) {
            r0.x = ((unsigned)((unsigned)((int)(unsigned)(x0 >> 70) < (int)9u) < fuel) - a0[u1 & 3u]);
            a0[7u & 3u] = ((unsigned)s1 ^ (unsigned)(2u && r0.y));
        }
        q0 = &garr[(unsigned)((int)fuel >= (int)(0x10000u & 6u)) & 7u];
        if (u3 == 7u) return (unsigned)((unsigned)(w0 >> 29) == (u2 * (0x1d94d25cu + (unsigned)h0)));
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)e0 && p1)) break;
        if ((unsigned)c0) break;
        if ((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)h0)) {
            if ((m0 % ((i1 - r0.y) | 1u))) break;
            q0 = &garr[((unsigned)((int)(a0[u1 & 3u] | 0x10000u) >= (int)(unsigned)e0) ^ (unsigned)((int)6u < (int)r0.x)) & 7u];
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(v0 && (unsigned)(8u && (unsigned)e0)), 0x38e640e7u, (unsigned)b0); }
            u3 += -((unsigned)((int)6u < (int)(unsigned)s1) | 0x7fffffffu);
            if (((unsigned)f0 ^ (unsigned)d0)) {
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (p0) {
                        r0.y ^= 0x70e79402u;
                        h1 = (unsigned short)(h1 + 0xb1baf840u);
                    } else {
                        b0 = ((unsigned)h0 % (r0.x | 1u)) != 0u;
                    }
                    if (((u2 * garr[u2 & 7u]) / (*mp | 1u))) break;
                }
                *mp = (unsigned)((int)(unsigned)((unsigned)c1 < r0.y) >= (int)(unsigned)d0);
                switch ((unsigned)w0 & 7u) {
                    u3 = u3 * 0x9e3779b1u + (unsigned)(0xf00b1499u || 0u);
                    { unsigned t1; double z1; if ((((unsigned)e0 ? *mp : *mp)) & 1u) { t1 = 0xb011b11cu; z1 = (double)(((unsigned)(i1 < (0x1f439795u << ((unsigned)h1 & 31u)))) & 255u); } if ((((unsigned)e0 ? *mp : *mp)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                        case 0u: ;
                        w0 ^= (unsigned long long)p1 << ((-(unsigned)((int)5u < (int)0xfc98fd26u) / (v0 | 1u)) & 63u);
                    }
                }
                if (i1) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0(0u, (5u >> (u3 & 31u)), (unsigned)s0); }
                while (i1++ < 7u && r0.x) { if (--fuel == 0u) goto done;
                    break; (void)(~(u2 | 3u));
                    u0 = ((garr[u2 & 7u] - (0x1f6d3dc5u ^ 5u)) - 0xffffffffu);
                    u1 = (0u + (unsigned)(v0 || 0x7895050eu));
                    if (r0.y) break;
                    if ((unsigned)s0) break;
                    if ((v0 << (4u & 31u))) break;
                }
            } else {
                if ((unsigned)(signed char)((unsigned)c1 << (0xcb31e986u & 31u))) break;
            }
            if ((unsigned)((short)i0 > (signed char)(unsigned)(i2 || i0))) {
                r0.y ^= -(unsigned)((int)m0 < (int)(~(0x7fffffffu - (unsigned)c1) / ((fuel << ((unsigned)b0 & 31u)) | 1u)));
                if (*q0) goto L2;
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)x0 == (unsigned)((u0 - 0x7fffffffu) || p0)) & 255u);
            } else {
                *mp = u0;
            }
        } else {
            a0[0x80000000u & 3u] = (unsigned)((unsigned)((short)(unsigned)h1 > (signed char)0xfcc9776cu) || ((unsigned)h0 & (unsigned)!(0x343309eeu ^ u2)));
            h0 = (short)(unsigned)(((unsigned)s0 << (0x9aefac36u & 31u)) < (0xffffffffu * 3u));
            if ((unsigned)!(9u + 7u)) {
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)(-((0x7fffffffu & i1) / (((unsigned)s1 - u2) | 1u)) || 0u);
                }
            } else {
                if ((fuel << (u2 & 31u))) break;
                continue; (void)(6u);
            }
            if (((a0[i0 & 3u] / ((unsigned)(w0 >> 29) | 1u)) - i0)) goto L4;
        }
        if (i0) goto L2;
    } while (i0++ < 5u && (0xd6a8d8e0u * (0u / ((unsigned)s0 | 1u))));
    l0 = (long)((unsigned long)l0 + -(unsigned)((int)(unsigned)((short)r0.y > (signed char)(unsigned)((unsigned)e0 == (unsigned)h0)) < (int)(unsigned)((unsigned)d0 || u1)));
    g0 = 0x80000000u;
    h0 = (short)((unsigned)(0x2d3cf6a0u && *q0) / (((0xaeb022d4u * garr[u2 & 7u]) << (p0 & 31u)) | 1u));
    if (0xcf3bfc2eu) goto L3;
    if ((unsigned)((short)(unsigned)(5u || 0xffffffffu) > (signed char)i1)) goto L0;
    if ((garr[i1 & 7u] * u2)) {
        if ((4u | u3)) {
            do { if (--fuel == 0u) goto done;
                if (((4u | (unsigned)x0) * garr[i1 & 7u])) break;
                if (((unsigned)(m0 < fuel) & i0)) break;
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (0xffffffffu) break;
                    if (fuel < 8u) return (unsigned)(~(unsigned)((int)(0xe2cd9fe2u | (unsigned)(x0 >> 70)) < (int)((unsigned)(x0 >> 70) % ((unsigned)l0 | 1u))) && 4u);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(0xffffffffu, (0u - i2), (unsigned)!(unsigned)((i2 - *mp) && *q0)); }
                }
                garr[p1 & 7u] = ((unsigned)(short)((unsigned)((p2 | 0u) || u2) + *mp) & (unsigned)s0);
            } while (i0++ < 4u && (unsigned)w0);
            if (garr[u2 & 7u]) {
                if ((unsigned)(garr[i1 & 7u] || i0)) goto L0;
            } else {
                v0 = (unsigned)(signed char)((unsigned)h0 ^ 0x80000000u);
                h1 = (unsigned short)(h1 + (unsigned)(0x10000u == ((unsigned)c0 % (v0 | 1u))));
                w0 = w0 * 6364136223846793005ull + (u0 + (unsigned)s0);
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((0u * garr[u2 & 7u]), ((*mp / (r0.x | 1u)) << ((unsigned)x0 & 31u)), (*q0 | (unsigned)(0xdd7c0686u || a0[u1 & 3u]))); }
            if (0x719a7ccau) goto L0;
        }
        u2 = (m0 >> ((unsigned)h0 & 31u));
        u0 ^= (unsigned)(p1 == (unsigned)((int)1u >= (int)(unsigned)(short)((unsigned)c1 ? a0[u1 & 3u] : m0)));
        while ((unsigned)b0) { if (--fuel == 0u) goto done;
            h0 = (short)(0x80000000u ^ 0x94ab6e0fu);
            break; (void)((unsigned)!(unsigned)(0xfbdfe28du == (unsigned)(w0 >> 29)));
            goto L4;
            m0 ^= (unsigned)((short)(unsigned)b0 > (signed char)((unsigned)((int)4u >= (int)1u) / ((u1 ^ (unsigned)(w0 >> 29)) | 1u)));
            h0 = (short)-(i0 ^ (r0.x - 0xe9bb8a79u));
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)((int)0x80000000u < (int)(unsigned)(short)(unsigned)((int)(unsigned)(unsigned char)(unsigned)((int)0x25a62139u >= (int)(unsigned)c1) >= (int)i0)) & 255u);
                break; (void)((unsigned)h0);
            }
        }
        if (((unsigned)f0 ? 2u : (unsigned)c1)) goto done;
    }
    g0 = ((unsigned)((int)0x1df12c9cu < (int)0x10000u) % (u2 | 1u));
    q0 = &garr[(unsigned)!((unsigned)(0xffffffffu == 0x80000000u) + (unsigned)((0xfe6d8cbfu | u0) < (unsigned)c1)) & 7u];
    if (budget != 0u) { budget -= 1u; u3 = fn0((0xd358a6ceu % (8u | 1u)), (unsigned)(signed char)((unsigned)d0 ? (unsigned)b0 : 0x1501ef25u), (unsigned)(((unsigned)c0 ^ (unsigned)x0) == a0[u1 & 3u])); }
    d0 = d0 * 0.5 + (double)((a0[i0 & 3u] ^ ((m0 << (0x80000000u & 31u)) << (-(unsigned)(m0 < (unsigned)(x0 >> 70)) & 31u))) & 1023u);
    if ((unsigned)(((unsigned)s1 >> (0x10000u & 31u)) || a0[i0 & 3u])) goto done;
    { unsigned t2; double z2; if (((u1 + 0x10000u)) & 1u) { t2 = 0x80000000u; z2 = (double)(((unsigned)((short)garr[u2 & 7u] > (signed char)garr[i1 & 7u])) & 255u); } if (((u1 + 0x10000u)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        c0 = (unsigned char)(*mp & (unsigned)c1);
        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)w0 - (unsigned)(*mp < (unsigned)x0)), (unsigned)(short)(r0.y * i2), a0[i0 & 3u]); }
        r0.x = (unsigned)((unsigned)e0 == (unsigned)c1);
        if ((unsigned)((int)0x8d174654u >= (int)(unsigned)h1)) goto L0;
    }
    while (i0++ < 7u && 0xcd3fdc68u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if ((0xe044a5f3u / (((unsigned)(w0 >> 29) + a0[u1 & 3u]) | 1u))) {
                if (((unsigned)(signed char)(unsigned)(p2 == 4u) * (unsigned)c0)) {
                    e0 = e0 * 0.5L + (long double)((u3 | (unsigned)d0) & 1023u);
                    w0 = w0 * 6364136223846793005ull + m0;
                    h1 = (unsigned short)(h1 + ((unsigned)w0 + ((unsigned)w0 << (0u & 31u))));
                    goto L2;
                }
            } else {
                if ((unsigned)((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)b0) == (unsigned)w0)) break;
                { unsigned t3; double z3; if (((unsigned)((int)0x9fee52ecu < (int)(unsigned)s0)) & 1u) { t3 = (unsigned)(signed char)(unsigned)(g0 && (unsigned)d0); z3 = (double)((((unsigned)((int)0x10000u < (int)5u) & 0xffffffffu)) & 255u); } if (((unsigned)((int)0x9fee52ecu < (int)(unsigned)s0)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)f0, (unsigned)l0, (*q0 % (0u | 1u))); }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(-(0x4f2c6395u << (u0 & 31u)), (unsigned)((int)0x80000000u >= (int)(5u << (g1 & 31u))), (g0 | fuel)); }
                    r0.y ^= (unsigned)((short)fuel > (signed char)0u);
                    u1 = (u3 ? (unsigned)(0xcccc4u || (unsigned)b0) : v0);
                    h1 = (unsigned short)(h1 + (unsigned)c1);
                }
                { unsigned t4; double z4; if (((unsigned)(garr[u2 & 7u] == (unsigned)h0)) & 1u) { t4 = 1u; z4 = (double)((p1) & 255u); } if (((unsigned)(garr[u2 & 7u] == (unsigned)h0)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                    if (((unsigned)c1 | (1u | (unsigned)(w0 >> 29)))) continue;
                    if ((i0 & ((unsigned)c1 >> (fuel & 31u)))) break;
                    a0[((unsigned)s0 / (8u | 1u)) & 3u] = garr[u2 & 7u];
                    c0 = (unsigned char)0xffffffffu;
                }
                if (0x4b9044a6u) continue;
            }
            switch (6u & 7u) {
                w0 ^= (unsigned long long)(r0.x >> (p1 & 31u)) << ((((garr[i1 & 7u] ? (unsigned)e0 : 0x80000000u) ^ (unsigned)c0) | 6u) & 63u);
                if (0x80000000u) break;
            }
            if ((unsigned)(short)(unsigned)((unsigned)(*q0 || (unsigned)h1) == 0x80000000u)) continue;
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(-((*q0 * (unsigned)(w0 >> 29)) >> (v0 & 31u)), (u2 % ((unsigned)(short)(unsigned)((int)i1 < (int)0x80000000u) | 1u)), (unsigned)(short)(unsigned)((unsigned)((short)m0 > (signed char)a0[i0 & 3u]) < (unsigned)s1)); }
                r0.x = (unsigned)(signed char)(garr[i1 & 7u] << ((unsigned)(signed char)((unsigned)h0 % (fuel | 1u)) & 31u));
                if ((6u >> ((unsigned)!(0x42c352edu + p2) & 31u))) continue;
                m0 ^= (unsigned)((int)(g1 & i0) < (int)(unsigned)((int)p1 >= (int)(unsigned)(w0 >> 29)));
            }
        } while (i1++ < 2u && (0x3927a2f0u | ((unsigned)h0 ^ 5u)));
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0x80000000u && (unsigned)((int)(unsigned)e0 < (int)p1)), (1u ^ ((unsigned)l0 << (g1 & 31u))), (0x7fffffffu << ((unsigned)h1 & 31u))); }
    }
    while (0x7a222105u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0((0x7fffffffu % (i0 | 1u)), i0, (unsigned)d0); }
        v0 = (unsigned)c1;
        w0 = w0 * 6364136223846793005ull + (unsigned)(((0xffffffffu & i1) * (unsigned)(signed char)(4u % ((unsigned)s0 | 1u))) || p2);
        if ((unsigned)d0) goto L4;
    }
    u3 = ((u2 << (0u & 31u)) | 0xd6664388u);
    if (budget != 0u) { budget -= 1u; u1 = fn0(u1, (unsigned)(unsigned char)(unsigned)((unsigned)l0 < g0), (unsigned)((int)a0[i0 & 3u] < (int)u0)); }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[(unsigned)((unsigned)s0 < (unsigned)h1) & 3u] = (unsigned)h1;
        c1 = (signed char)(unsigned)(signed char)(7u % ((g0 | (unsigned)h1) | 1u));
        break; (void)((unsigned)((int)a0[i0 & 3u] >= (int)0x198e8dc7u));
        if ((unsigned)((unsigned)(x0 >> 70) < u3)) {
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((unsigned)(g0 && i2) & 255u);
                    g1 += (fuel / (((unsigned)(i2 < 0xc3078c38u) % ((unsigned)((int)fuel >= (int)u0) | 1u)) | 1u));
                    do { if (--fuel == 0u) goto done;
                        if ((i2 << (((unsigned)w0 - i2) & 31u))) continue;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(g0, (unsigned)((int)p2 >= (int)(unsigned)s1), (4u ^ (unsigned)l0)); }
                        e0 = e0 * 0.5L + (long double)((unsigned)!((i2 * (unsigned)(unsigned char)(unsigned)((int)(unsigned)(signed char)((unsigned)s1 * 6u) >= (int)a0[u1 & 3u])) / (g0 | 1u)) & 1023u);
                        if (budget != 0u) { budget -= 1u; u0 = fn0((0x7fffffffu % ((0x80000000u & p0) | 1u)), (unsigned)((short)m0 > (signed char)u0), (((unsigned)c0 - 5u) ^ 7u)); }
                    } while (i0++ < 3u && u3);
                    e0 = e0 * 0.5L + (long double)((unsigned)((short)i0 > (signed char)0x7fffffffu) & 1023u);
                    v0 = ((unsigned)(m0 || (unsigned)(w0 >> 29)) | (m0 & garr[i1 & 7u]));
                } while (i2++ < 2u && ((u1 / (garr[i1 & 7u] | 1u)) & (unsigned)b0));
                if ((unsigned)(signed char)(unsigned)((int)(unsigned)(w0 >> 29) < (int)a0[i0 & 3u])) continue;
                if (v0) {
                    h0 = (short)(p0 << (0x8f6672bcu & 31u));
                    { unsigned t5; double z5; if (((9u % ((unsigned)((unsigned)h1 == (unsigned)s0) | 1u))) & 1u) { t5 = (u1 - 0xffffffffu); z5 = (double)((((unsigned)l0 | 0x80000000u)) & 255u); } if (((9u % ((unsigned)((unsigned)h1 == (unsigned)s0) | 1u))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                        break; (void)(((unsigned)s1 ^ ((unsigned)h1 + (unsigned)l0)));
                        e0 = e0 * 0.5L + (long double)((0xffffffffu & ((unsigned)c1 >> (r0.x & 31u))) & 1023u);
                        while (i2++ < 4u && (unsigned)((int)(unsigned)x0 >= (int)p1)) { if (--fuel == 0u) goto done;
                            u3 += (unsigned)!(u3 % ((fuel | ((unsigned)h0 ? p0 : 6u)) | 1u));
                            d0 = d0 * 0.5 + (double)((unsigned)(x0 >> 70) & 1023u);
                            if ((a0[u1 & 3u] >> ((unsigned)l0 & 31u))) goto done;
                            i0 = (unsigned)((int)(unsigned)!(~((unsigned)(*q0 < v0) / (0x10000u | 1u)) % (v0 | 1u)) < (int)r0.y) & 15u;
                            if ((p0 / (1u | 1u))) break;
                        }
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)h1, (0x7cab185au | 0x80000000u), (unsigned)d0); }
                    if ((i1 % ((r0.x / (3u | 1u)) | 1u))) break;
                    switch (-(7u % (((unsigned)f0 % (0x7fffffffu | 1u)) | 1u)) & 7u) {
                        d0 = d0 * 0.5 + (double)((unsigned)((int)((unsigned)(0x10000u < 5u) ? 0xa438aadu : fuel) >= (int)8u) & 1023u);
                        { unsigned t6; double z6; if ((-(unsigned)((int)r0.y < (int)r0.x)) & 1u) { t6 = i2; z6 = (double)(((unsigned)((int)u0 < (int)(unsigned)(short)(unsigned)(v0 < u1))) & 255u); } if ((-(unsigned)((int)r0.y < (int)r0.x)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                            w0 ^= (unsigned long long)(unsigned)(p1 < (unsigned)s1) << ((unsigned)((int)(unsigned)h1 >= (int)(unsigned)(u0 == i2)) & 63u);
                            s0 = (int)g0;
                            case 3u: ;
                            if (budget != 0u) { budget -= 1u; u0 = fn0(a0[u1 & 3u], ((unsigned)s0 ^ 0xcd2dfb62u), (unsigned)e0); }
                        }
                        case 1u: ;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)c0, i1, ((u3 + (unsigned)x0) | p1)); }
                        case 0u: ;
                    }
                    if ((unsigned)(unsigned char)(unsigned)(r0.x && *mp)) break;
                } else {
                    x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)h0 > (signed char)garr[u2 & 7u]);
                    if ((unsigned)((int)1u >= (int)2u)) break;
                }
                break; (void)(a0[i0 & 3u]);
            }
            if (0x3401b99du) {
                if ((fuel * u2)) {
                    break; (void)(p1);
                } else {
                    if ((unsigned)(u2 < (unsigned)((unsigned)(x0 >> 70) && p1))) break;
                    u1 = ((unsigned)((int)(0x616afd14u % (0x10000u | 1u)) >= (int)(unsigned)h1) - (unsigned)s1);
                }
            } else {
                break; (void)((unsigned)!(unsigned)((short)(0xffffffffu - (unsigned)e0) > (signed char)(unsigned)b0));
            }
        }
    }
    if ((unsigned)((unsigned)l0 || 0x63a7525au)) goto done;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(unsigned)((int)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)c1) < (int)(unsigned)c1), (unsigned)l0, ((unsigned)w0 % (*mp | 1u))); }
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            switch (((unsigned)c0 + m0) & 7u) {
                r0.x = (unsigned)(g0 < (a0[u1 & 3u] + 0x10000u));
                b0 = (0xffffffffu / ((unsigned)((short)r0.y > (signed char)(unsigned)((8u ^ i2) == (unsigned)c1)) | 1u)) != 0u;
                if (budget != 0u) { budget -= 1u; u2 = fn0(i0, ((unsigned)(0x12d09225u && fuel) << (i1 & 31u)), (unsigned)x0); }
                case 4u: ;
                h0 = (short)0xec5254e6u;
                c1 = (signed char)(unsigned)((unsigned)((unsigned)(x0 >> 70) || *q0) < g1);
            }
            if (0xd50bf79u) break;
            r0.y ^= (unsigned)c1;
            { unsigned t7; double z7; if ((0xffffffffu) & 1u) { t7 = (unsigned)((int)*q0 >= (int)~(a0[u1 & 3u] % (fuel | 1u))); z7 = (double)((garr[u2 & 7u]) & 255u); } if ((0xffffffffu) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                if (a0[u1 & 3u]) {
                    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(2u || r0.y) == g0));
                    u2 = u2 * 0x9e3779b1u + (r0.x >> (*q0 & 31u));
                    if ((unsigned)(*q0 || (p1 ^ 0x80000000u))) break;
                    s0 = (int)(unsigned)((int)((u0 - (unsigned)(x0 >> 70)) | 6u) < (int)((unsigned)h0 | 0x6a842ceau));
                    if ((unsigned)(short)(g1 ^ fuel)) break;
                    d0 = d0 * 0.5 + (double)(((u0 * (unsigned)((int)i1 >= (int)0x80000000u)) * 0xffffffffu) & 1023u);
                }
                e0 = e0 * 0.5L + (long double)((unsigned)(~(a0[i0 & 3u] - (5u % (r0.y | 1u))) && (unsigned)s1) & 1023u);
                if ((0x195c6827u % ((unsigned)(p1 || u2) | 1u))) goto L3;
                if ((unsigned)((unsigned)(r0.y || 0u) == m0)) break;
                if (budget != 0u) { budget -= 1u; u0 = fn0(*mp, (unsigned)w0, (m0 + r0.y)); }
            }
            x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)c0 >= (int)r0.y);
        } while (i1++ < 3u && a0[u1 & 3u]);
        break; (void)(((unsigned)(w0 >> 29) - (unsigned)((short)(unsigned)x0 > (signed char)u3)));
        x0 = x0 * 0x100000001b3ull + r0.y;
        x0 = x0 * 0x100000001b3ull + (unsigned)((r0.y + u0) || -((unsigned)(signed char)(m0 / (a0[u1 & 3u] | 1u)) / ((unsigned)f0 | 1u)));
        if ((0x7fffffffu >> (a0[i0 & 3u] & 31u))) {
            d0 = d0 * 0.5 + (double)((unsigned)e0 & 1023u);
        } else {
            { unsigned t8; double z8; if (((unsigned)x0) & 1u) { t8 = (unsigned)(0x553844dfu && 7u); z8 = (double)((~(unsigned)((unsigned)h0 == (unsigned)s0)) & 255u); } if (((unsigned)x0) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                r0.x = (unsigned)((int)(i0 | garr[u2 & 7u]) < (int)((unsigned)l0 ? (unsigned)e0 : (unsigned)h0));
                if (i0) continue;
                if ((unsigned)(short)(7u + p0)) {
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)((unsigned)!((p0 ? ((unsigned)c1 << (garr[i1 & 7u] & 31u)) : 6u) << (u1 & 31u)) & 1023u);
                        h0 = (short)(unsigned)(8u < u0);
                        m0 ^= (unsigned)w0;
                        u3 ^= ((unsigned)(1u || u3) & 1u);
                        switch (((unsigned)c1 ^ 0x6b6475bcu) & 7u) {
                            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)h0 * (unsigned)((short)0x81e956bfu > (signed char)(unsigned)f0)), (unsigned)(0x10000u == (m0 + garr[i1 & 7u])), ((unsigned)s0 + p0)); }
                            case 5u: ;
                            x0 = x0 * 0x100000001b3ull + (unsigned)((short)(0x7fffffffu ^ (*q0 & 0xffffffffu)) > (signed char)0xb68e401du);
                        }
                        b0 = (unsigned)((i0 ? g0 : (unsigned)c1) < (unsigned)l0) != 0u;
                    }
                    f0 = f0 * 0.5f + (float)(((0x80000000u ^ 4u) * (a0[i0 & 3u] & 0xffffffffu)) & 255u);
                }
                r0.y ^= (((unsigned)h0 >> (m0 & 31u)) << (0x817de50eu & 31u));
                if (r0.y) {
                    h1 = (unsigned short)(h1 + ((g1 % ((unsigned)l0 | 1u)) % (((unsigned)l0 % (0x2bf7e296u | 1u)) | 1u)));
                    if ((u0 | (unsigned)e0)) goto done;
                }
            }
            a0[u3 & 3u] = (unsigned)s1;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(unsigned char)(p2 - (unsigned)(signed char)(r0.x >> (i1 & 31u)))) break;
                h0 = (short)(unsigned)((unsigned)c0 || (unsigned)(6u && p0));
            }
            break; (void)((unsigned)(((unsigned)l0 * i0) < u0));
        }
        for (;;) { if (--fuel == 0u) goto done;
            i0 = ((0x14b5f69du | v0) + (unsigned)((unsigned)(*mp < garr[i1 & 7u]) == 0x670c30b9u)) & 15u;
            { unsigned t9; double z9; if ((i1) & 1u) { t9 = (unsigned)((int)u0 >= (int)0xd1e13b5bu); z9 = (double)(((((unsigned)(w0 >> 29) * a0[i0 & 3u]) & a0[u1 & 3u])) & 255u); } if ((i1) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                g0 = (unsigned)(signed char)((unsigned)h1 >> (0x7fffffffu & 31u));
                if ((unsigned)c0) break;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(short)(p0 * (unsigned)d0), (i1 / (v0 | 1u)), u0); }
            d0 = d0 * 0.5 + (double)((a0[i0 & 3u] ? 0x10000u : u0) & 1023u);
        }
    } while (i0++ < 7u && -((unsigned)s0 ^ ((unsigned)h1 + 0x759797dbu)));
    switch ((unsigned)((int)(unsigned)b0 < (int)0x9af90907u) & 7u) {
        r0.y ^= (a0[i0 & 3u] % ((unsigned)(u3 || 0xc3beb1a5u) | 1u));
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((1u * 0x80000000u), (unsigned)(0xffffffffu < v0), *q0); }
            } while (i1++ < 6u && (unsigned)((unsigned)h0 == a0[u1 & 3u]));
        }
        case 2u: ;
        w0 ^= (unsigned long long)(unsigned)w0 << (0x7fffffffu & 63u);
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= ((unsigned)(short)(unsigned)((short)~(unsigned)((short)(unsigned)b0 > (signed char)0xffffffffu) > (signed char)(0xf7e73044u / ((unsigned)(w0 >> 29) | 1u))) | g0);
            if ((p1 + (unsigned)s0)) continue;
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)w0) goto L4;
            }
        }
        switch ((unsigned)e0 & 7u) {
            if (p2) goto L0;
            { unsigned t10; double z10; if ((((unsigned)s1 & 2u)) & 1u) { t10 = (unsigned)(w0 >> 29); z10 = (double)(((((unsigned)w0 & fuel) / (a0[u1 & 3u] | 1u))) & 255u); } if ((((unsigned)s1 & 2u)) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((short)p2 > (signed char)3u) - a0[u1 & 3u]), (unsigned)((unsigned)w0 && (v0 >> (g1 & 31u))), r0.x); }
                if ((unsigned)h1) goto L2;
                if (i0) {
                    s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)((short)5u > (signed char)(unsigned)((unsigned)w0 && a0[u1 & 3u])) > (signed char)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)m0)));
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s1 | a0[u1 & 3u]), (unsigned)(signed char)(6u + (unsigned)(w0 >> 29)), (unsigned)s1); }
                    case 5u: ;
                    default: ;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((garr[i1 & 7u] & (unsigned)h1), ((unsigned)f0 >> (~(0xf92131c3u ^ u1) & 31u)), 0xc889cb43u); }
                }
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(unsigned)w0 > (signed char)0x437bbabcu), (unsigned)(signed char)(unsigned)((int)*q0 < (int)4u), (unsigned)((int)p2 >= (int)(unsigned)w0)); }
            do { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)r0.y >= (int)0x80000000u), (i1 / ((0xb617838bu / (i0 | 1u)) | 1u)), (unsigned)l0); }
                    if ((unsigned)s1) break;
                    case 4u: ;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)l0 << (u3 & 31u)), ((unsigned)l0 ? 0x1dfada6du : (unsigned)w0), (unsigned)((int)5u >= (int)i0)); }
                    while (i2++ < 2u && (9u >> ((unsigned)l0 & 31u))) { if (--fuel == 0u) goto done;
                        continue; (void)((unsigned)h0);
                        m0 ^= ((unsigned)(i0 && r0.y) ? (unsigned)(short)(unsigned)((unsigned)l0 == (unsigned)h1) : fuel);
                        s1 = (int)((unsigned)s1 + garr[u2 & 7u]);
                        g0 = (unsigned)(unsigned char)(a0[u1 & 3u] / (0x10000u | 1u));
                        u0 = u0 * 0x9e3779b1u + (unsigned)(r0.y || fuel);
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)d0, (u2 * (unsigned)((unsigned)b0 < 8u)), ((unsigned)w0 ^ 0xc9925022u)); }
                    }
                }
                d0 = d0 * 0.5 + (double)(i1 & 1023u);
            } while (i0++ < 3u && (3u / (a0[i0 & 3u] | 1u)));
            while (i0++ < 3u && (unsigned)(short)(0x10000u << ((unsigned)f0 & 31u))) { if (--fuel == 0u) goto done;
                *q0 += *q0;
                b0 = (unsigned)f0 != 0u;
                e0 = e0 * 0.5L + (long double)(p1 & 1023u);
                if ((unsigned)w0) {
                    goto L2;
                    case 7u: ;
                    if ((unsigned)h0) break;
                }
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)~(unsigned)((int)(unsigned)l0 >= (int)fuel) >= (int)(unsigned)((int)(unsigned)((unsigned)w0 == p0) < (int)(unsigned)c0));
                s1 = (int)((unsigned)s1 + (unsigned)(u0 == (unsigned)(w0 >> 29)));
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(signed char)(p2 + (unsigned)x0), 5u, ((unsigned)(short)(unsigned)((short)u3 > (signed char)(unsigned)l0) + p0)); }
    i0 = (unsigned)x0 & 15u;
    g1 += (0x10000u % (a0[u1 & 3u] | 1u));
    u1 = 3u;
    u0 = (unsigned)((short)(0x1854d27fu ? garr[u2 & 7u] : g1) > (signed char)(unsigned)((int)a0[i0 & 3u] < (int)u1));
    v0 = (unsigned)x0;
    u1 = u1 * 0x9e3779b1u + (unsigned)!(((unsigned)(w0 >> 29) | (unsigned)((int)0u < (int)(unsigned)h1)) | 0u);
    if ((unsigned)(unsigned char)(unsigned)(garr[u2 & 7u] && m0)) goto done;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)((int)g1 < (int)i2);
    }
    if ((unsigned)((int)u1 < (int)r0.y)) goto L4;
    c0 = (unsigned char)(unsigned)b0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)d0) goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(x0 >> 70), (0x80000000u ? (unsigned)f0 : 8u), (unsigned)((unsigned)(short)(unsigned)((unsigned)l0 && 0u) == (unsigned)h0)); }
    c1 = (signed char)a0[u1 & 3u];
    g1 += u0;
    if ((unsigned)((int)(unsigned)w0 < (int)u1)) {
        goto L4;
        w0 ^= (unsigned long long)(unsigned)(u1 && garr[i1 & 7u]) << ((p2 + (unsigned)c1) & 63u);
        while (i0++ < 2u && (((unsigned)(x0 >> 70) + u0) >> ((unsigned)w0 & 31u))) { if (--fuel == 0u) goto done;
            continue; (void)(v0);
            if ((v0 - 0xffffffffu)) break;
            break; (void)((unsigned)(short)(unsigned)((unsigned)e0 < 0xffffffffu));
            L0: if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (0xffffffffu) {
                    do { if (--fuel == 0u) goto done;
                        g1 += 0xffffffffu;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((r0.x | a0[u1 & 3u]), (unsigned)((int)0xffffffffu >= (int)*mp), (unsigned)s1); }
                        h0 = (short)a0[i0 & 3u];
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(u2 || (0xc6058179u << ((unsigned)f0 & 31u))), ((0x80000000u >> ((unsigned)d0 & 31u)) >> (garr[u2 & 7u] & 31u)), (v0 << ((r0.x * v0) & 31u))); }
                        w0 = w0 * 6364136223846793005ull + i0;
                    } while (i2++ < 3u && (0x10000u % ((unsigned)s0 | 1u)));
                    for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (u1) break;
                        if ((r0.y + 8u)) break;
                        { unsigned t0; double z0; if ((((unsigned)e0 / ((unsigned)w0 | 1u))) & 1u) { t0 = (unsigned)((short)(unsigned)s0 > (signed char)(unsigned)(w0 >> 29)); z0 = (double)((((unsigned)e0 & 0x80000000u)) & 255u); } if ((((unsigned)e0 / ((unsigned)w0 | 1u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                            q0 = &garr[((unsigned)c1 / ((unsigned)e0 | 1u)) & 7u];
                            if (u1) goto L0;
                            if (~(unsigned)(fuel < *mp)) continue;
                            q0 = &garr[-(a0[i0 & 3u] ^ (p0 - u2)) & 7u];
                            L1: if (--fuel == 0u) goto done;
                            if (u1) break;
                        }
                        u3 = u3 * 0x9e3779b1u + garr[u2 & 7u];
                    }
                    { unsigned t1; double z1; if ((((unsigned)x0 * -(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)m0))) & 1u) { t1 = (unsigned)(8u || ((unsigned)(w0 >> 29) / ((unsigned)d0 | 1u))); z1 = (double)((garr[u2 & 7u]) & 255u); } if ((((unsigned)x0 * -(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)m0))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                        if (~(((unsigned)h0 * 0xffffffffu) / ((unsigned)c1 | 1u))) continue;
                        if ((unsigned)((short)a0[u1 & 3u] > (signed char)0xd3f17643u)) goto done;
                        r0.y ^= i1;
                        g0 = 2u;
                        u0 += (unsigned)!(unsigned)((short)0xd20131b9u > (signed char)~(unsigned)((unsigned)w0 < (unsigned)(signed char)(p0 * 0x10000u)));
                    }
                    d0 = d0 * 0.5 + (double)((unsigned)!(unsigned)((unsigned)h0 && (2u | (unsigned)!(fuel / (i2 | 1u)))) & 1023u);
                    if (u3) continue;
                    x0 = x0 * 0x100000001b3ull + (u1 >> ((unsigned)(r0.x < a0[u1 & 3u]) & 31u));
                } else {
                    f0 = f0 * 0.5f + (float)((unsigned)f0 & 255u);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1(0x700c5a45u, ((unsigned)c0 % (m0 | 1u)), (unsigned)((unsigned)!(unsigned)(fuel && (unsigned)c1) < i1)); }
                switch (3u & 7u) {
                    if ((unsigned)!((unsigned)(w0 >> 29) ^ ((unsigned)d0 ^ 0u))) goto L1;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(a0[i0 & 3u] < -((unsigned)b0 + 8u)), ((unsigned)h0 << ((unsigned)((int)(unsigned)d0 < (int)(unsigned)e0) & 31u)), ((unsigned)e0 << (0xf315bf9bu & 31u))); }
                    d0 = d0 * 0.5 + (double)(((unsigned)l0 | (unsigned)((unsigned)(0x1269b340u == 0x2f4c6c70u) || i2)) & 1023u);
                    h1 = (unsigned short)(h1 + (((unsigned)d0 & (0u ^ i0)) * (unsigned)((unsigned)e0 == u2)));
                    case 0u: ;
                    goto L0;
                }
                if (((unsigned)((short)i0 > (signed char)(unsigned)l0) | 5u)) break;
                *mp = (unsigned)((0xac353056u ? (unsigned)(w0 >> 29) : (unsigned)((unsigned)b0 || i0)) && 0x80000000u);
            }
            u3 += (((unsigned)w0 & m0) * fuel);
        }
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t2; double z2; if ((g1) & 1u) { t2 = r0.y; z2 = (double)((((0xffffffffu & 2u) | (unsigned)h0)) & 255u); } if ((g1) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                v0 = (unsigned)(0xeb630e8bu < (unsigned)((unsigned)(x0 >> 70) && (0x96ae0af3u & 3u)));
                q0 = &garr[((0u ^ u3) | ((unsigned)((short)0x20a8a2f8u > (signed char)0xffffffffu) ^ 0xe49fe0a6u)) & 7u];
                m0 ^= (unsigned)(0xffffffffu && (0x7fffffffu | (unsigned)(0x10000u && (unsigned)h1)));
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(unsigned char)(unsigned)((int)(unsigned)c1 >= (int)(unsigned)(0xb17e534u == garr[u2 & 7u])), ((0x80000000u >> ((unsigned)x0 & 31u)) - (unsigned)(x0 >> 70)), (unsigned)((unsigned)((unsigned)(x0 >> 70) < u3) && v0)); }
                x0 = x0 * 0x100000001b3ull + (((unsigned)b0 | (unsigned)((int)m0 >= (int)(unsigned)w0)) / ((unsigned)w0 | 1u));
            }
            break; (void)(0xa965bffbu);
            L2: if (--fuel == 0u) goto done;
        }
        *mp = (((unsigned)d0 << (u1 & 31u)) / ((p2 | (unsigned)!(unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)h0)) | 1u));
        L3: if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(0xfb2c25cdu & 1023u);
            for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1(u0, ~(4u ^ *mp), ((0x7fffffffu ^ 1u) / (0x7fffffffu | 1u))); }
                s0 = (int)(unsigned)((4u / (((unsigned)(unsigned char)(unsigned)((short)p1 > (signed char)(unsigned)l0) * (unsigned)s0) | 1u)) || (unsigned)h0);
                w0 ^= (unsigned long long)(6u - 6u) << ((((a0[u1 & 3u] << (0x6e274adbu & 31u)) / ((unsigned)h1 | 1u)) ^ (unsigned)!(unsigned)(0xfc9acd1cu && 0x1d943614u)) & 63u);
                if ((0xf50ce584u << (v0 & 31u))) {
                    { unsigned t3; double z3; if (((*q0 - (unsigned)h0)) & 1u) { t3 = garr[u2 & 7u]; z3 = (double)((0xeb9ae629u) & 255u); } if (((*q0 - (unsigned)h0)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)(fuel == (unsigned)b0) || 0x69d4fec0u), 0x8dc0c3b7u, (unsigned)((unsigned)((int)0x6ddddd70u >= (int)9u) == g1)); }
                        w0 ^= (unsigned long long)(unsigned)(u0 || m0) << ((unsigned)s1 & 63u);
                        r0.y ^= (unsigned)(signed char)(unsigned)((unsigned)h0 == (0xffffffffu / ((unsigned)!(unsigned)(u2 && (unsigned)s0) | 1u)));
                        *q0 += ((unsigned)c0 | g0);
                    }
                    h1 = (unsigned short)(h1 + ~(r0.y % (0x407c24b5u | 1u)));
                    goto done;
                    goto L4;
                    L4: if (--fuel == 0u) goto done;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)0x80000000u < (int)0xffffffffu), (unsigned)(0x2d851a04u < 8u), (unsigned)(short)(unsigned)((short)r0.y > (signed char)u0)); }
                w0 ^= (unsigned long long)(unsigned)w0 << (u0 & 63u);
            }
        }
        break; (void)((*mp & (a0[u1 & 3u] - 0x6359d69au)));
        u0 = (unsigned)((*q0 | g1) && (unsigned)b0);
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)((short)0x10000u > (signed char)2u);
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)h0, (0xd66e6cbau / (p1 | 1u)), (0xa20fce69u & 0xc1f263d6u)); }
    while (i0++ < 3u && (0xffffffffu % ((unsigned)(w0 >> 29) | 1u))) { if (--fuel == 0u) goto done;
        { unsigned t4; double z4; if (((unsigned)((v0 - (unsigned)w0) && 6u)) & 1u) { t4 = ((unsigned)(w0 >> 29) & 0xcb034c40u); z4 = (double)(((unsigned)((short)0xe2555daau > (signed char)(unsigned)((short)fuel > (signed char)(unsigned)(w0 >> 29)))) & 255u); } if (((unsigned)((v0 - (unsigned)w0) && 6u)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
            if (((i0 | garr[i1 & 7u]) & (unsigned)h0)) {
                e0 = e0 * 0.5L + (long double)((unsigned)f0 & 1023u);
                if (u3 == 7u) return p1;
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(8u ? (unsigned)e0 : v0);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1(0x8ad32f1u, (i1 - ((unsigned)c0 & u1)), (unsigned)((int)(unsigned)!(unsigned)((unsigned)l0 < 2u) < (int)(unsigned)h1)); }
                if ((unsigned)(unsigned char)((unsigned)(unsigned char)(unsigned)((unsigned)w0 && g1) - 3u)) break;
                { unsigned t5; double z5; if ((fuel) & 1u) { t5 = (unsigned)!(unsigned)((short)*q0 > (signed char)(p2 ^ i2)); z5 = (double)((((unsigned)(x0 >> 70) ? 0u : 9u)) & 255u); } if ((fuel) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(short)(0x10000u / ((unsigned)d0 | 1u)) << (a0[i0 & 3u] & 31u)), (0xffffffffu - i0), (unsigned)(0x4e7dce02u && (g0 + (unsigned)l0))); }
                    if ((0x6242f45cu ? p1 : (unsigned)h0)) goto L3;
                }
            } else {
                if ((unsigned)(0xe62a8183u == p1)) break;
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)0x80000000u < (int)(0x10000u | g1)), (unsigned)(unsigned char)(fuel / (m0 | 1u)), (unsigned)d0); }
            }
        }
        *q0 = (unsigned)(a0[u1 & 3u] && (unsigned)(x0 >> 70));
        for (;;) { if (--fuel == 0u) goto done;
            m0 ^= a0[u1 & 3u];
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)x0, (unsigned)e0, ((unsigned)h0 - (unsigned)(0xe1845243u == (unsigned)b0))); }
            if (0x10000u) break;
            { unsigned t6; double z6; if (((unsigned)s0) & 1u) { t6 = (unsigned)c1; z6 = (double)(((unsigned)d0) & 255u); } if (((unsigned)s0) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                u3 += (unsigned)(unsigned char)(0x65996ce9u << (0xd9b39476u & 31u));
            }
            break; (void)((unsigned)(0u < a0[u1 & 3u]));
            { unsigned t7; double z7; if ((((u0 << (r0.y & 31u)) | a0[u1 & 3u])) & 1u) { t7 = ((unsigned)c0 >> ((unsigned)(i0 || (unsigned)(x0 >> 70)) & 31u)); z7 = (double)((a0[i0 & 3u]) & 255u); } if ((((u0 << (r0.y & 31u)) | a0[u1 & 3u])) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                d0 = d0 * 0.5 + (double)((((unsigned)!((unsigned)l0 & 0x65677304u) & (unsigned)w0) >> ((i1 / (0xe899e57cu | 1u)) & 31u)) & 1023u);
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(0xc0ad734fu && r0.y) / ((unsigned)x0 | 1u)), (7u >> (((unsigned)c0 << (i1 & 31u)) & 31u)), ((unsigned)w0 >> ((unsigned)l0 & 31u))); }
            }
        }
        if ((4u % ((unsigned)b0 | 1u))) break;
        break; (void)(((unsigned)s0 & (unsigned)(i1 || i0)));
        while (i1++ < 4u && 8u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)((int)(unsigned)l0 < (int)(0x80000000u / (((unsigned)e0 ? 0x69c2a5edu : (unsigned)x0) | 1u)));
            u2 += (((unsigned)s1 << (garr[u2 & 7u] & 31u)) * u0);
        }
    }
    goto L2;
    if (budget != 0u) { budget -= 1u; u2 = fn0(p0, (u2 / (garr[i1 & 7u] | 1u)), (p0 + (unsigned)s0)); }
    if ((unsigned)((int)0xe25fef13u >= (int)(unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)h0))) goto L1;
    switch ((unsigned)(garr[u2 & 7u] && p1) & 7u) {
        if (u3 == 7u) return ((unsigned)!(unsigned)((int)u3 >= (int)u3) / (((unsigned)(w0 >> 29) ? (unsigned)c0 : r0.x) | 1u));
        if ((u3 / (i2 | 1u))) break;
        { unsigned t8; double z8; if (((i1 * (unsigned)(6u < 0x10000u))) & 1u) { t8 = (unsigned)c1; z8 = (double)((u2) & 255u); } if (((i1 * (unsigned)(6u < 0x10000u))) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
            if ((a0[i0 & 3u] / (a0[u1 & 3u] | 1u))) break;
            case 6u: ;
            i1 = ((a0[i0 & 3u] << ((unsigned)(0xf098dc19u && (unsigned)((int)0x63220d31u < (int)a0[u1 & 3u])) & 31u)) ^ 0x70b160fcu) & 15u;
            u0 = u0 * 0x9e3779b1u + (unsigned)(p2 || (unsigned)(((unsigned)c0 << ((unsigned)(w0 >> 29) & 31u)) || i2));
        }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)a0[i0 & 3u];
            *q0 = (m0 * g0);
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(r0.x < fuel) << (i1 & 31u)), (unsigned)c0, fuel); }
                case 0u: ;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(fuel == garr[u2 & 7u]), (unsigned)h0, (unsigned)h0); }
                    case 3u: ;
                    f0 = f0 * 0.5f + (float)(~(unsigned)((int)(unsigned)(0x10000u && ((unsigned)(x0 >> 70) ? i1 : (unsigned)h1)) >= (int)0x7fffffffu) & 255u);
                    c0 = (unsigned char)((0xdcde11c5u ^ (unsigned)((int)r0.y < (int)(unsigned)e0)) & (unsigned)((int)i1 < (int)(unsigned)(x0 >> 70)));
                } while (i2++ < 5u && (unsigned)((unsigned)(x0 >> 70) || i2));
                if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, (unsigned)(garr[u2 & 7u] || -(i0 | m0)), (unsigned)((int)(*q0 - (unsigned)s1) < (int)p1)); }
                garr[(unsigned)s0 & 7u] = (unsigned)(u1 || garr[i1 & 7u]);
                s0 = (int)(unsigned)((int)u0 < (int)(unsigned)((int)0u >= (int)0xffffffffu));
            }
        }
        case 7u: ;
    }
    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((short)(unsigned)(signed char)(unsigned)((unsigned)d0 || (unsigned)(x0 >> 70)) > (signed char)0x80000000u) == (0x1a209a8u ^ i0)));
    { unsigned t9; double z9; if (((((unsigned)e0 | (unsigned)(w0 >> 29)) | p2)) & 1u) { t9 = ((g1 << (0x10000u & 31u)) - (unsigned)d0); z9 = (double)(((unsigned)x0) & 255u); } if (((((unsigned)e0 | (unsigned)(w0 >> 29)) | p2)) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
        if (0xffffffffu) goto L2;
        if ((unsigned)(u2 || 0x80000000u)) goto L2;
        u2 = u2 * 0x9e3779b1u + (i2 % ((unsigned)((short)u0 > (signed char)(unsigned)h0) | 1u));
        h1 = (unsigned short)(h1 + ((0x10000u % (i2 | 1u)) << ((0xe4a0a76du | 7u) & 31u)));
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (garr[u2 & 7u]) break;
            switch (((unsigned)(w0 >> 29) + (p0 << (0xacf8af4eu & 31u))) & 7u) {
                case 7u: ;
                if (u3 == 7u) return 0x80000000u;
                u2 = (unsigned)(p1 || (unsigned)w0);
            }
            if ((unsigned)((unsigned)(x0 >> 70) && 0x97024129u)) break;
            v0 = (-((unsigned)((int)4u < (int)i2) ^ 7u) & (unsigned)x0);
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)e0 || 9u), (unsigned)(p0 == m0), (unsigned)(0x80000000u && v0)); }
    }
    w0 ^= (unsigned long long)fuel << (u3 & 63u);
    while (i0++ < 3u && (unsigned)(0x7fffffffu == r0.x)) { if (--fuel == 0u) goto done;
        if ((*mp + g1)) {
            continue; (void)((u1 % ((p1 << (p0 & 31u)) | 1u)));
            if ((i1 % (a0[i0 & 3u] | 1u))) break;
            h1 = (unsigned short)(h1 + (((unsigned)s0 % ((unsigned)s1 | 1u)) % ((unsigned)(a0[i0 & 3u] < p0) | 1u)));
            if (0u) continue;
            if ((0xffffffffu - (unsigned)s0)) goto done;
            do { if (--fuel == 0u) goto done;
                if (fuel < 8u) return (0x7fffffffu * (unsigned)(p1 < u1));
                c1 = (signed char)6u;
                if (budget != 0u) { budget -= 1u; u0 = fn1((0x7fffffffu >> ((unsigned)(*q0 || 0x141f4816u) & 31u)), (unsigned)(short)((0x80000000u << (g1 & 31u)) >> (g0 & 31u)), (unsigned)b0); }
                break; (void)(fuel);
                if (0xffffffffu) break;
            } while (i1++ < 2u && (unsigned)((int)0xffffffffu < (int)(unsigned)l0));
        } else {
            u0 = ((unsigned)((g0 << ((unsigned)s1 & 31u)) < 0x3f33fcfbu) >> (r0.y & 31u));
            if ((unsigned)((unsigned)c0 < (i1 ^ (unsigned)h0))) goto L2;
            *mp = (unsigned)(short)(((unsigned)((unsigned)l0 < 0x80000000u) + v0) / (0x7fffffffu | 1u));
            if (((unsigned)((int)(unsigned)s1 >= (int)0x88bbeaa3u) * (unsigned)b0)) break;
        }
        if ((unsigned)l0) break;
        if ((unsigned)(unsigned char)(unsigned)(*mp || m0)) break;
        { unsigned t10; double z10; if (((unsigned)w0) & 1u) { t10 = (unsigned)(*q0 && (unsigned)h1); z10 = (double)((m0) & 255u); } if (((unsigned)w0) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
            { unsigned t11; double z11; if ((0xa5af3bb2u) & 1u) { t11 = ~(p1 >> (0xffffffffu & 31u)); z11 = (double)((((unsigned)c0 | -(7u ^ a0[u1 & 3u]))) & 255u); } if ((0xa5af3bb2u) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
                if ((unsigned)((short)(unsigned)(0x6b23d005u && u3) > (signed char)m0)) goto L0;
            }
            s1 = (int)((unsigned)s1 + (unsigned)(garr[u2 & 7u] == (0x964affe1u << ((unsigned)c0 & 31u))));
            r0.y ^= (unsigned)!(unsigned)((i2 ? 8u : u2) || (unsigned)b0);
            if (i1) break;
            if (r0.x) goto L0;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)(*q0 << (5u & 31u)), (r0.y >> (2u & 31u)), (unsigned)((unsigned)f0 < 0xffffffffu)); }
        }
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (i1) break;
                *mp = (unsigned)((0x10000u / (*q0 | 1u)) == p2);
                s0 = (int)(unsigned)(((*mp % (garr[u2 & 7u] | 1u)) - (unsigned)c1) && p1);
                u2 += ((~(unsigned)(0xd11d8b67u == 9u) + 0xffffffffu) ? 0u : 0x7fffffffu);
                do { if (--fuel == 0u) goto done;
                    break; (void)(((unsigned)(0x88711a44u || p2) | (unsigned)(w0 >> 29)));
                } while (i0++ < 4u && (unsigned)!((unsigned)(x0 >> 70) * fuel));
                if (budget != 0u) { budget -= 1u; u0 = fn1(~(5u << (0x10000u & 31u)), garr[u2 & 7u], ((unsigned)s1 << (0x7fffffffu & 31u))); }
            }
            m0 ^= ((u2 | a0[i0 & 3u]) + ((unsigned)h0 ^ ((unsigned)(w0 >> 29) / ((unsigned)s1 | 1u))));
            c0 = (unsigned char)fuel;
            if (0x76b5c14eu) break;
        }
    }
    s0 = (int)(unsigned)((unsigned)(unsigned char)(((unsigned)(w0 >> 29) >> (0xffffffffu & 31u)) + (unsigned)(x0 >> 70)) == r0.y);
    *mp = (unsigned)((unsigned)h0 || i1);
    switch (*q0 & 7u) {
        goto L0;
        if ((unsigned)!(unsigned)(i0 || u2)) goto L1;
        if ((unsigned)h1) {
            goto L0;
            *mp = (unsigned)((short)(unsigned)(~(unsigned)((unsigned)x0 < 0x6c59ac3bu) && (unsigned)!((unsigned)(w0 >> 29) + (unsigned)s1)) > (signed char)g0);
        }
        case 2u: ;
        do { if (--fuel == 0u) goto done;
            u0 += (p1 + garr[u2 & 7u]);
        } while (i0++ < 6u && p0);
        switch (0x2d7db4c0u & 7u) {
            e0 = e0 * 0.5L + (long double)((unsigned)c0 & 1023u);
            q0 = &garr[((unsigned)(0xffffffffu && a0[u1 & 3u]) << ((unsigned)((short)*mp > (signed char)(unsigned)c0) & 31u)) & 7u];
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1((0x7fffffffu ^ (unsigned)w0), (unsigned)((int)(g0 >> ((unsigned)c0 & 31u)) >= (int)0x30156dbu), (0xffffffffu << (u2 & 31u))); }
                case 1u: ;
                r0.y ^= ((unsigned)l0 | ((unsigned)(p1 < (unsigned)(x0 >> 70)) + (unsigned)((unsigned)x0 && (unsigned)l0)));
                if ((p2 * (unsigned)l0)) {
                    h1 = (unsigned short)(h1 + (unsigned)((int)1u < (int)(unsigned)(*q0 < 0xbab03790u)));
                    b0 = ((unsigned)((int)(0x4dd2ff8au << (p1 & 31u)) >= (int)(unsigned)b0) >> (((unsigned)b0 % (6u | 1u)) & 31u)) != 0u;
                }
                l0 = (long)((unsigned long)l0 + (0xf4d92277u << ((0x80000000u % (i1 | 1u)) & 31u)));
            }
            if ((unsigned)(garr[u2 & 7u] == (unsigned)((unsigned)c0 < (unsigned)f0))) break;
            e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)(m0 < (0u >> ((unsigned)((unsigned)(0x10000u < (unsigned)e0) || (unsigned)x0) & 31u))) & 1023u);
        }
    }
    u0 += (i2 & (unsigned)((u2 & a0[u1 & 3u]) || 7u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    a0[4u & 3u] = (unsigned)(unsigned char)((unsigned)(short)(g1 ^ 7u) + (unsigned)c0);
    if (0x1f6435u) goto L1;
    if ((unsigned)((unsigned)b0 && (unsigned)(w0 >> 29))) {
        if (u1) goto L1;
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            garr[(*q0 - 0x7fffffffu) & 7u] = (unsigned)((((unsigned)f0 | (unsigned)(x0 >> 70)) - 0xffffffffu) || (i2 % (g0 | 1u)));
            if (u3 == 7u) return (unsigned)(~(0x1dd6538du << (0x4ee528e5u & 31u)) && (unsigned)(signed char)(u1 << ((unsigned)(short)(0xffffffffu >> (p1 & 31u)) & 31u)));
        }
        *q0 = ((unsigned)f0 & (unsigned)c0);
    } else {
        if ((u1 % (0x98ae88b9u | 1u))) {
            l0 = (long)((unsigned long)l0 + -(garr[i1 & 7u] - (u1 / (v0 | 1u))));
            goto done;
            u1 += (u1 << ((((unsigned)h1 % (3u | 1u)) >> ((unsigned)c0 & 31u)) & 31u));
        } else {
            switch (((unsigned)d0 & 0x80000000u) & 7u) {
                w0 ^= (unsigned long long)(9u >> (1u & 31u)) << ((unsigned)((unsigned)(x0 >> 70) < ((unsigned)((int)(*q0 & m0) >= (int)(unsigned)d0) << (i0 & 31u))) & 63u);
                if (r0.x) goto L1;
                a0[(unsigned)h1 & 3u] = (p1 % (((unsigned)s0 ? 1u : (unsigned)(g1 || a0[i0 & 3u])) | 1u));
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(garr[u2 & 7u] < (unsigned)c1) / ((unsigned)s1 | 1u)), u1, garr[i1 & 7u]); }
                if (v0) goto L0;
                if ((unsigned)(w0 >> 29)) {
                    c1 = (signed char)(garr[i1 & 7u] << (p0 & 31u));
                    c0 = (unsigned char)((a0[i0 & 3u] - (unsigned)((unsigned)c1 || a0[i0 & 3u])) ^ (unsigned)(w0 >> 29));
                    if (0x10000u) goto done;
                    q0 = &garr[(i1 ? 0x9aab7af0u : (unsigned)(short)(unsigned)((short)0x10000u > (signed char)(unsigned)(signed char)(unsigned)(fuel < (unsigned)h0))) & 7u];
                    u3 = ((3u - (unsigned)s0) | ((unsigned)((unsigned)(w0 >> 29) == 0u) / (garr[i1 & 7u] | 1u)));
                    if (budget != 0u) { budget -= 1u; u2 = fn0(u1, 0xbc1e361du, 0x46a72e15u); }
                } else {
                    u1 += (unsigned)f0;
                    if (budget != 0u) { budget -= 1u; u0 = fn2(0u, u2, *mp); }
                }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn2(9u, ((fuel | r0.x) ^ 4u), (unsigned)((int)(unsigned)!(unsigned)((unsigned)b0 == (unsigned)e0) >= (int)0xffffffffu)); }
        }
        goto L3;
        L0: if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + ((0x54921519u << ((0x3b41f01u ^ (0x10000u | 0x5c42019u)) & 31u)) ^ (unsigned)c1));
    }
    r0.y ^= ((u3 / (0x10000u | 1u)) % (0x7fffffffu | 1u));
    if (((unsigned)w0 + 0x58531124u)) {
        if (budget != 0u) { budget -= 1u; u0 = fn1((g1 / (garr[i1 & 7u] | 1u)), (unsigned)((int)(u2 + (unsigned)(w0 >> 29)) >= (int)v0), (unsigned)((short)(unsigned)((unsigned)x0 || u1) > (signed char)(unsigned)s1)); }
        while (i0++ < 3u && (unsigned)(0x80000000u || (unsigned)!(r0.x % ((unsigned)c1 | 1u)))) { if (--fuel == 0u) goto done;
            u2 ^= ((((unsigned)h1 ? g1 : u2) * 0x8b6bb184u) << (u3 & 31u));
            q0 = &garr[(((unsigned)x0 | 0x80000000u) * ((unsigned)h1 + -(g1 - p1))) & 7u];
            if ((0x10000u ^ 0x262c3f7cu)) {
                { unsigned t0; double z0; if (((unsigned)((short)(unsigned)f0 > (signed char)fuel)) & 1u) { t0 = (unsigned)h1; z0 = (double)(((unsigned)(signed char)(i2 ^ u0)) & 255u); } if (((unsigned)((short)(unsigned)f0 > (signed char)fuel)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                    c1 = (signed char)-(unsigned)((unsigned)(short)((unsigned)(7u < (unsigned)l0) >> ((unsigned)f0 & 31u)) == ((unsigned)b0 - (unsigned)h1));
                    i0 = (0xe91f9beu - u1) & 15u;
                    *q0 += (a0[u1 & 3u] - ((unsigned)d0 << ((unsigned)((int)(unsigned)c1 >= (int)(unsigned)!(0x8fb1512u & 3u)) & 31u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)*mp >= (int)((unsigned)c0 * 0x10000u)), a0[u1 & 3u], (0xffffffffu - 0xffffffffu)); }
                    L1: if (--fuel == 0u) goto done;
                }
                g1 += (unsigned)((unsigned)((short)0x746a81d6u > (signed char)(unsigned)s0) || 0x7fffffffu);
                if (*q0) {
                    { unsigned t1; double z1; if (((a0[i0 & 3u] % (((unsigned)s0 + 8u) | 1u))) & 1u) { t1 = (p0 | (unsigned)(r0.x == (unsigned)(w0 >> 29))); z1 = (double)(((unsigned)(short)(unsigned)(((unsigned)h1 >> (i2 & 31u)) && i2)) & 255u); } if (((a0[i0 & 3u] % (((unsigned)s0 + 8u) | 1u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                        if (((unsigned)((int)(unsigned)l0 < (int)*mp) * 0x7fffffffu)) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((garr[i1 & 7u] << (0x7fffffffu & 31u)) || a0[u1 & 3u]), (((unsigned)b0 | m0) << (*mp & 31u)), (0x5f008013u / (0xe0ac3650u | 1u))); }
                        if (budget != 0u) { budget -= 1u; u0 = fn1((0xa5c235a2u & 0x5b5bb8eeu), (m0 ^ (unsigned)l0), (unsigned)h0); }
                        if ((unsigned)e0) break;
                        if ((unsigned)((short)u1 > (signed char)p0)) break;
                    }
                    i0 = (unsigned)(x0 >> 70) & 15u;
                    v0 = ((unsigned)f0 >> ((unsigned)(x0 >> 70) & 31u));
                    L2: if (--fuel == 0u) goto done;
                }
                i2 = ((unsigned)w0 | 0x7fffffffu) & 15u;
                if ((unsigned)((int)v0 < (int)0xbed2fc75u)) continue;
            }
        }
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (u0) goto L2;
        r0.y ^= (unsigned)(signed char)(garr[i1 & 7u] / ((g0 - 0xf09ec0c5u) | 1u));
        { unsigned t2; double z2; if ((9u) & 1u) { t2 = (i2 | (unsigned)(short)(a0[i0 & 3u] - p0)); z2 = (double)(((unsigned)((int)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)garr[i1 & 7u]) >= (int)a0[i0 & 3u])) & 255u); } if ((9u) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)h0 + (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)(x0 >> 70))), (unsigned)((unsigned)(signed char)(unsigned)(i1 || 0xd563d12u) < (unsigned)b0), (unsigned)(unsigned char)(~(unsigned)((int)(unsigned)c0 >= (int)7u) * 0u)); }
            switch ((unsigned)s1 & 7u) {
                L3: if (--fuel == 0u) goto done;
                if ((unsigned)h1) {
                    h0 = (short)0x7fffffffu;
                    x0 = x0 * 0x100000001b3ull + (unsigned)(0x80000000u && ((unsigned)h0 ? p0 : 0u));
                    do { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)(-(unsigned)((int)r0.y >= (int)(unsigned)(g1 == p1)) & 1023u);
                        do { if (--fuel == 0u) goto done;
                            a0[(unsigned)((unsigned)l0 && (unsigned)h1) & 3u] = (0x80000000u >> ((unsigned)w0 & 31u));
                            f0 = f0 * 0.5f + (float)((unsigned)(signed char)(unsigned)(fuel == 1u) & 255u);
                            *q0 += ((8u & (unsigned)(x0 >> 70)) * (a0[i0 & 3u] ^ a0[i0 & 3u]));
                            q0 = &garr[8u & 7u];
                            b0 = 0xeff2e896u != 0u;
                            L4: if (--fuel == 0u) goto done;
                        } while (i2++ < 6u && (r0.y << ((unsigned)(signed char)(unsigned)(m0 && 5u) & 31u)));
                        break; (void)((unsigned)((int)0xffffffffu >= (int)i1));
                        while (i2++ < 5u && (unsigned)s0) { if (--fuel == 0u) goto done;
                            u3 = u3 * 0x9e3779b1u + (unsigned)(i1 < (unsigned)(0xffffffffu || (unsigned)h0));
                            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(p2 && (unsigned)(5u < 0xffffffffu)), (9u % (0x10000u | 1u)), (unsigned)(0x10000u < ((unsigned)(w0 >> 29) + g0))); }
                        }
                    } while (i1++ < 5u && (4u / (((unsigned)c0 / (v0 | 1u)) | 1u)));
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)d0 == v0), (unsigned)c1, (garr[u2 & 7u] << ((unsigned)x0 & 31u))); }
                } else {
                    b0 = (unsigned)(signed char)(m0 - (2u + ((unsigned)b0 * (6u + a0[i0 & 3u])))) != 0u;
                }
                for (;;) { if (--fuel == 0u) goto done;
                    garr[(unsigned)((short)(unsigned)x0 > (signed char)(unsigned)l0) & 7u] = ((unsigned)(7u || (r0.y / (u3 | 1u))) + (unsigned)(i2 < i1));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((unsigned)e0 && 0x5c6531cdu), (i2 | ((unsigned)s0 - (unsigned)x0)), (0xffffffffu % (u1 | 1u))); }
                continue; (void)((unsigned)((short)0xec2dfc90u > (signed char)(unsigned)s0));
            }
            break; (void)((0x80000000u & v0));
            h1 = (unsigned short)(h1 + i2);
        }
        if (((unsigned)(w0 >> 29) >> ((unsigned)!(unsigned)((unsigned)(x0 >> 70) == fuel) & 31u))) break;
        if ((unsigned)b0) break;
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)(short)(unsigned)((int)(unsigned)h0 < (int)0x8b804368u);
    c0 = (unsigned char)(unsigned)(unsigned char)((unsigned)w0 + (unsigned)(p1 == (0xfaa0fba0u * ((unsigned)d0 ^ 0x80000000u))));
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = ((((unsigned)e0 ? (unsigned)l0 : i0) & 6u) << ((unsigned)d0 & 31u));
        break; (void)((u0 ? i1 : m0));
        r0.x = (unsigned)(2u || (unsigned)(x0 >> 70));
        if (fuel) {
            goto L3;
            if ((unsigned)c0) {
                if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)x0 - 0x10000u), (u1 * (unsigned)(0xffffffffu || u1)), ((unsigned)h0 / ((0x80000000u * u0) | 1u))); }
            } else {
                u3 = u3 * 0x9e3779b1u + (unsigned)((int)((garr[u2 & 7u] / (fuel | 1u)) - (unsigned)(p2 && 6u)) < (int)i1);
            }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(i0 || 4u) | (unsigned)s1), (unsigned)((int)(unsigned)((int)(unsigned)f0 >= (int)0xe22034b6u) < (int)garr[i1 & 7u]), (unsigned)(signed char)((unsigned)(i2 < fuel) / (4u | 1u))); }
                switch (((unsigned)w0 << ((unsigned)w0 & 31u)) & 7u) {
                    b0 = (unsigned)((unsigned)w0 == (unsigned)s0) != 0u;
                    a0[(i2 * (unsigned)e0) & 3u] = ((unsigned)b0 / (u3 | 1u));
                    if (u3 == 7u) return ((r0.x | (unsigned)h1) ? (6u | (unsigned)l0) : g1);
                    if (a0[i0 & 3u]) break;
                }
            } while (i1++ < 7u && (unsigned)(signed char)(unsigned)((short)(unsigned)h0 > (signed char)0x80000000u));
        }
        v0 = (unsigned)(short)((unsigned)(*q0 < garr[i1 & 7u]) / ((unsigned)(x0 >> 70) | 1u));
    }
    g0 = ~(unsigned)((unsigned)((int)g0 < (int)2u) || (unsigned)((0xffffffffu ^ i0) && 9u));
    g1 += (unsigned)!(unsigned)((short)4u > (signed char)(1u & 0xac08b68fu));
    if (budget != 0u) { budget -= 1u; u3 = fn1((u3 | garr[u2 & 7u]), (unsigned)(signed char)(i1 & (unsigned)x0), 0xffffffffu); }
    do { if (--fuel == 0u) goto done;
        if ((5u / ((unsigned)s1 | 1u))) {
            d0 = d0 * 0.5 + (double)((unsigned)(signed char)(unsigned)((int)0x80000000u >= (int)p2) & 1023u);
            r0.x = (0x4ff46f9au ^ 0x7b177f8eu);
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch (0u & 7u) {
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((0x77279ee7u ^ 0x80000000u) == 0x6e26fc8fu), ((unsigned)(signed char)(0x7fffffffu & garr[u2 & 7u]) & 2u), (unsigned)((unsigned)d0 && (i2 % (0x28a04fdbu | 1u)))); }
                    l0 = (long)((unsigned long)l0 + *mp);
                    b0 = ((i2 << (g0 & 31u)) - u0) != 0u;
                    if ((garr[u2 & 7u] >> ((0x7fffffffu * a0[i0 & 3u]) & 31u))) {
                        case 0u: ;
                        if ((unsigned)(short)(unsigned)((int)(unsigned)f0 < (int)0x8b7a20dfu)) {
                            default: ;
                        } else {
                            r0.x = (unsigned)((unsigned)e0 < ((unsigned)d0 & (unsigned)l0));
                            case 7u: ;
                        }
                        i0 = (unsigned)((int)(unsigned)w0 >= (int)0x80000000u) & 15u;
                        if (fuel < 8u) return (unsigned)((unsigned)!(unsigned)(5u < ((0xb81109dcu * 0xd4796a01u) / (0xb3502f20u | 1u))) == 0xe39c3e71u);
                        u3 ^= (unsigned)(p1 < (0x80000000u | a0[u1 & 3u]));
                    } else {
                        v0 = (((unsigned)h1 % (0xa8587d0fu | 1u)) | g1);
                        *q0 = (unsigned)(5u && 7u);
                        if ((unsigned)((int)u1 >= (int)(unsigned)w0)) continue;
                        break;
                    }
                    u2 += (unsigned)(short)(unsigned)((int)(r0.x << ((unsigned)l0 & 31u)) < (int)(unsigned)(r0.y < (unsigned)s0));
                    break;
                }
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)c1 / ((unsigned)h1 | 1u)), -(i0 * (unsigned)x0), (unsigned)(x0 >> 70)); }
            u0 = (((unsigned)h0 ? *mp : (unsigned)(w0 >> 29)) ^ p1);
            b0 = (unsigned)((int)*q0 >= (int)2u) != 0u;
        }
        u1 ^= (unsigned)((int)(unsigned)h0 < (int)(unsigned)f0);
    } while (i0++ < 5u && (unsigned)((short)0x7fffffffu > (signed char)0xe9fd05f9u));
    if (0x80000000u) goto L1;
    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(short)(unsigned)((int)(unsigned)c0 < (int)0xffffffffu) << (1u & 31u)), (unsigned)((unsigned)s0 < p0), (unsigned)f0); }
    c0 = (unsigned char)(unsigned)((unsigned)((short)a0[i0 & 3u] > (signed char)i2) || (unsigned)s0);
    if ((unsigned)!(0xffffffffu % (2u | 1u))) goto L0;
    do { if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)(unsigned char)(garr[u2 & 7u] << (g1 & 31u));
        b0 = (unsigned)(*mp < *mp) != 0u;
        break; (void)((u1 % ((0x10000u ^ 0xffffffffu) | 1u)));
        *q0 = (unsigned)s1;
    } while (i0++ < 3u && ((unsigned)(p2 || (unsigned)s0) ^ p2));
    u0 ^= (unsigned)(-(p2 >> (v0 & 31u)) || i2);
    if (i2) {
        if (((unsigned)((short)p1 > (signed char)0x10000u) * 0x10000u)) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)(w0 >> 29));
        if ((0x7fffffffu % ((unsigned)(short)(p1 * (unsigned)x0) | 1u))) goto done;
        *q0 = 0xffffffffu;
        h1 = (unsigned short)(h1 + ((unsigned)h0 | (unsigned)w0));
        while (i0++ < 4u && (unsigned)!((unsigned)(x0 >> 70) | 0x10000u)) { if (--fuel == 0u) goto done;
            goto done;
            s0 = (int)(unsigned)(0x80000000u < 0xffffffffu);
            if ((~(garr[i1 & 7u] + 0x795d3bd8u) % ((unsigned)s0 | 1u))) break;
        }
    } else {
        if (budget != 0u) { budget -= 1u; u0 = fn0(-(7u >> ((unsigned)c1 & 31u)), (unsigned)h0, 6u); }
        *q0 += (unsigned)((unsigned)(short)(v0 % (1u | 1u)) || (unsigned)h1);
        u1 += (unsigned)((unsigned)h1 || (unsigned)h1);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (((unsigned)c1 / (-(unsigned)((int)garr[i1 & 7u] < (int)0x28a49068u) | 1u))) {
        L0: if (--fuel == 0u) goto done;
        while (i0++ < 5u && ((unsigned)(a0[i0 & 3u] == 0xffffffffu) & (unsigned)h0)) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)((int)fuel < (int)(m0 + (unsigned)l0)) & 1023u);
            *q0 += (unsigned)(0x16423b7cu && 0x7fffffffu);
            if ((0x7fffffffu % ((unsigned)s1 | 1u))) {
                if (m0) break;
                s1 = (int)((unsigned)s1 + (unsigned)!(unsigned)(((unsigned)(x0 >> 70) * (6u >> (i2 & 31u))) && ~(unsigned)(0x627a25a9u && 0x57f7948au)));
                m0 ^= ((unsigned)((int)(g0 + u2) >= (int)0xb0c7a29du) - (unsigned)!(unsigned)((short)p0 > (signed char)0xffffffffu));
                if ((unsigned)((unsigned)(r0.x < 0x7fffffffu) < (unsigned)x0)) break;
            } else {
                s0 = (int)(a0[u1 & 3u] / ((unsigned)(short)(unsigned)((unsigned)((unsigned)((int)0x82e60a99u < (int)p1) && (unsigned)h1) == g1) | 1u));
                while (i1++ < 4u && ((unsigned)x0 ^ *mp)) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return u0;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(v0, (0x7fffffffu - (unsigned)f0), (0x33149beeu ^ (unsigned)s1)); }
                    if (budget != 0u) { budget -= 1u; u3 = fn1((2u - ((unsigned)c0 / (fuel | 1u))), (u1 << (1u & 31u)), ((v0 & 0x7fffffffu) >> (0xffffffffu & 31u))); }
                }
                if (-(unsigned)(0x31c66cbcu == g1)) continue;
                L1: if (--fuel == 0u) goto done;
            }
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                a0[-(v0 << ((unsigned)l0 & 31u)) & 3u] = (2u ^ (unsigned)(v0 || (unsigned)e0));
                goto L3;
                if ((r0.y - (unsigned)d0)) goto L3;
                u2 = u2 * 0x9e3779b1u + (unsigned)(x0 >> 70);
                c0 = (unsigned char)5u;
            }
            b0 = (unsigned)(0x7fffffffu && *q0) != 0u;
            h1 = (unsigned short)(h1 + (unsigned)h0);
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)(unsigned char)((unsigned)c1 * 0u) + *mp), (0x7fffffffu | (unsigned)((int)(unsigned)h0 < (int)g1)), 0x2e4ff308u); }
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn3(0x1d2995e1u, (unsigned)(short)(u2 * 0x7fffffffu), garr[u2 & 7u]); }
            L2: if (--fuel == 0u) goto done;
            *q0 += ((unsigned)e0 + (unsigned)s0);
            L3: if (--fuel == 0u) goto done;
        }
    }
    *mp = ((unsigned)w0 >> (g1 & 31u));
    while (i0++ < 3u && p2) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(unsigned)(g1 && 0xe950e517u);
        if ((unsigned)(fuel || (unsigned)e0)) {
            while (i1++ < 6u && ((unsigned)w0 & u1)) { if (--fuel == 0u) goto done;
                goto L3;
                if ((unsigned)((0x80000000u * (unsigned)c1) && p0)) break;
                *q0 += (g0 << (2u & 31u));
                u0 = u0 * 0x9e3779b1u + (unsigned)!(unsigned)((unsigned)((short)2u > (signed char)0xf66c022cu) == ((unsigned)e0 / (u1 | 1u)));
                if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)d0, (unsigned)((unsigned)((unsigned)c1 == a0[u1 & 3u]) || 1u), 4u); }
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn3((u1 >> ((unsigned)((short)v0 > (signed char)(unsigned)d0) & 31u)), 5u, ((p2 / (0xffffffffu | 1u)) << (1u & 31u))); }
    switch (g1 & 7u) {
        for (;;) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + ((unsigned)(0x80000000u == (unsigned)(i1 < garr[u2 & 7u])) | garr[i1 & 7u]));
            c1 = (signed char)-((garr[u2 & 7u] | 0x7a036f79u) * (unsigned)l0);
        }
        while ((unsigned)(0xffffffffu < (0x80000000u ^ p1))) { if (--fuel == 0u) goto done;
            break; (void)(9u);
            c0 = (unsigned char)((unsigned)((short)0xffffffffu > (signed char)(unsigned)(x0 >> 70)) | 0x7fffffffu);
            case 1u: ;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 2u: ;
                r0.y ^= ((unsigned)((short)i1 > (signed char)0x80000000u) + p2);
                q0 = &garr[((unsigned)(x0 >> 70) * (unsigned)(unsigned char)(unsigned)((int)(unsigned)((unsigned)e0 && (unsigned)b0) >= (int)(unsigned)((short)0x80000000u > (signed char)p1))) & 7u];
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)(8u + 0xd78319efu) < (int)garr[u2 & 7u]), 0x84cf66b1u, ((unsigned)e0 / (0x80000000u | 1u))); }
                h0 = (short)v0;
            }
            while (i1++ < 6u && ((unsigned)((unsigned)s0 && p0) % ((unsigned)w0 | 1u))) { if (--fuel == 0u) goto done;
                if ((unsigned)w0) goto L4;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (unsigned)h0;
                    if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)!((1u * 0u) / (0x25f3bf74u | 1u)), (0xc9427daau % (i1 | 1u)), (unsigned)((unsigned)l0 == (unsigned)s1)); }
                    goto L0;
                    if (0x10000u) {
                        if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)((int)g0 >= (int)(unsigned)h0) & 0xa39a5e77u), p2, (unsigned)((unsigned)((unsigned)l0 == 0x7fffffffu) && r0.x)); }
                        L4: if (--fuel == 0u) goto done;
                        case 4u: ;
                        h1 = (unsigned short)(h1 + (-(unsigned)((int)u0 >= (int)garr[i1 & 7u]) << ((unsigned)b0 & 31u)));
                        f0 = f0 * 0.5f + (float)((unsigned)((r0.y + 0xaca2ae2eu) < (0x10000u ^ (i2 / (p1 | 1u)))) & 255u);
                    } else {
                        if (budget != 0u) { budget -= 1u; u0 = fn3(((unsigned)c1 & u1), u3, (0u ^ u2)); }
                    }
                }
            }
            default: ;
        }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 0u: ;
            case 6u: ;
            if (((unsigned)b0 & (unsigned)f0)) goto done;
            if ((unsigned)(short)((0xdd8fca28u * (unsigned)s1) + 0xffffffffu)) {
                continue; (void)((((unsigned)s0 | i2) ^ i2));
                break;
                g1 += ((unsigned)w0 % (((unsigned)h1 << (g0 & 31u)) | 1u));
                u0 ^= (unsigned)((unsigned)b0 || (unsigned)((int)r0.x < (int)0x74195059u));
            }
        }
    }
    w0 ^= (unsigned long long)(unsigned)(x0 >> 70) << ((0x929a42e7u % (0x612892fdu | 1u)) & 63u);
    if (a0[i0 & 3u]) goto L3;
    goto done;
    if ((unsigned)((unsigned)c0 && (unsigned)(i0 && 3u))) goto L1;
    x0 = x0 * 0x100000001b3ull + (unsigned)((short)u3 > (signed char)4u);
    w0 ^= (unsigned long long)(g1 + (unsigned)x0) << (-((unsigned)(w0 >> 29) % (((0x80000000u >> (v0 & 31u)) & i0) | 1u)) & 63u);
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (8u + (0x7fffffffu | 0xea946710u));
        if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)(unsigned char)(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)((short)0x80000000u > (signed char)0x5c128c69u)), (6u / ((unsigned)d0 | 1u)), (p2 ? 0x199dd164u : i2)); }
        c1 = (signed char)(unsigned)((unsigned)x0 || (unsigned)c1);
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((a0[u1 & 3u] ? r0.y : 0x8a03f89cu)) continue;
            if (((unsigned)e0 ^ 0x3e1c689eu)) goto L2;
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((0xffffffffu / ((unsigned)(w0 >> 29) | 1u))) {
                    if (i2) break;
                } else {
                    g1 += (unsigned)((int)p1 < (int)(unsigned)((short)g0 > (signed char)(0x6316771fu / ((unsigned)((unsigned)l0 && i2) | 1u))));
                    s1 = (int)((unsigned)s1 + 0x86c78accu);
                }
                d0 = d0 * 0.5 + (double)((((unsigned)(0xb29a1b86u == g1) | (unsigned)w0) / ((r0.x % ((unsigned)(x0 >> 70) | 1u)) | 1u)) & 1023u);
                *mp = (garr[i1 & 7u] - 0xd3023505u);
                l0 = (long)((unsigned long)l0 + (unsigned)(signed char)((0x84a76bc7u - 0x52c3ed33u) - ~(unsigned)((*mp >> (u3 & 31u)) || p2)));
                if (budget != 0u) { budget -= 1u; u3 = fn2((-(g1 + (unsigned)s0) * p0), r0.x, (unsigned)(((unsigned)l0 - u0) || *mp)); }
            }
            c0 = (unsigned char)(fuel | garr[u2 & 7u]);
        }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.x = (unsigned)((short)u0 > (signed char)(unsigned)c1);
            if ((unsigned)!(unsigned)((unsigned)w0 && p0)) break;
            g1 += (unsigned)(signed char)(u0 * (unsigned)((unsigned)(g0 && (unsigned)(w0 >> 29)) < ((unsigned)s1 - 0x7fffffffu)));
            { unsigned t0; double z0; if (((6u ? 0xffffffffu : p2)) & 1u) { t0 = (r0.y + (fuel * 0x1e534d5fu)); z0 = (double)(((garr[u2 & 7u] * (unsigned)l0)) & 255u); } if (((6u ? 0xffffffffu : p2)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                break; (void)(9u);
                if ((unsigned)((unsigned)l0 == g0)) break;
                if (budget != 0u) { budget -= 1u; u1 = fn2(p1, 0x30e6ff5eu, 0x10000u); }
                if (u1) break;
                f0 = f0 * 0.5f + (float)((unsigned)(g0 == (unsigned)x0) & 255u);
            }
            u1 = ((unsigned)((int)*q0 < (int)(unsigned)(garr[i1 & 7u] == *mp)) & (unsigned)((int)*q0 >= (int)0x7fffffffu));
        }
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)c1 + r0.y), -(unsigned)(a0[u1 & 3u] == m0), (unsigned)(unsigned char)(v0 * (unsigned)h1)); }
        u1 ^= m0;
        *q0 += (unsigned)(((unsigned)h0 / (0x10000u | 1u)) == (0x10000u / (8u | 1u)));
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        garr[p0 & 7u] = (unsigned)((int)i2 >= (int)(unsigned)h1);
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)((unsigned)e0 >> (garr[u2 & 7u] & 31u));
            if (budget != 0u) { budget -= 1u; u1 = fn3(0xfe1fe2b5u, 0xffffffffu, ((unsigned)(a0[i0 & 3u] && garr[i1 & 7u]) + *q0)); }
            *mp = (unsigned)(short)((((unsigned)c1 | 0xe3fa9ce2u) - *q0) % ((unsigned)((int)4u < (int)4u) | 1u));
            break; (void)((unsigned)((unsigned)d0 || 0x5f90ea9du));
        }
        u0 ^= (unsigned)((unsigned)((int)u2 >= (int)0xf17b1a28u) < (unsigned)c1);
    }
    switch ((unsigned)((unsigned)c1 == (unsigned)(u1 < 0x10000u)) & 7u) {
        if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)s0 - (unsigned)(unsigned char)(u0 << (0xd44f2c97u & 31u))), i1, (unsigned)(7u < *q0)); }
        case 1u: ;
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)s1, 0x7fffffffu, (unsigned)h1); }
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= p2;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)f0);
                    h1 = (unsigned short)(h1 + (unsigned)((short)v0 > (signed char)*mp));
                    v0 = i1;
                    u3 = u3 * 0x9e3779b1u + (unsigned)((int)(unsigned)((unsigned)((int)u0 < (int)p2) < 0xfa9298b9u) < (int)(unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)l0));
                    default: ;
                }
                g1 += (0xaa78f9bdu << ((unsigned)l0 & 31u));
            }
            r0.y ^= ((unsigned)((int)0x7783dd48u < (int)*mp) >> (a0[u1 & 3u] & 31u));
            if (budget != 0u) { budget -= 1u; u1 = fn3((~(v0 / ((unsigned)l0 | 1u)) / (3u | 1u)), ((unsigned)(0u && p2) % (0x7fffffffu | 1u)), (~(8u * a0[u1 & 3u]) / ((unsigned)c0 | 1u))); }
            if (budget != 0u) { budget -= 1u; u1 = fn1(fuel, (unsigned)(short)(unsigned)((unsigned)(w0 >> 29) || r0.y), (unsigned)((int)a0[u1 & 3u] < (int)8u)); }
            break; (void)(((unsigned)h1 % ((unsigned)x0 | 1u)));
        }
        while (0x83baa4c3u) { if (--fuel == 0u) goto done;
            if (~(u1 % ((unsigned)l0 | 1u))) break;
            v0 = ((0x23eb3d37u >> (6u & 31u)) / ((unsigned)(unsigned char)(v0 + (*mp & 8u)) | 1u));
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)((int)1u >= (int)(unsigned)h1) < (unsigned)l0)) {
                    case 0u: ;
                    case 5u: ;
                    if (a0[u1 & 3u]) {
                        v0 = i2;
                        while (i2++ < 5u && (unsigned)((unsigned)s0 || *q0)) { if (--fuel == 0u) goto done;
                            *q0 = (p2 ? (unsigned)d0 : 0x7fffffffu);
                            e0 = e0 * 0.5L + (long double)(((4u >> (*mp & 31u)) << ((unsigned)(fuel || (unsigned)((int)i1 < (int)m0)) & 31u)) & 1023u);
                            s1 = (int)((unsigned)s1 + (unsigned)(p2 == (unsigned)(x0 >> 70)));
                        }
                        { unsigned t1; double z1; if (((r0.y + a0[u1 & 3u])) & 1u) { t1 = ((unsigned)((int)u3 >= (int)7u) - u1); z1 = (double)((((unsigned)(p0 && a0[u1 & 3u]) + p0)) & 255u); } if (((r0.y + a0[u1 & 3u])) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                            if ((r0.x ? 0x7fffffffu : 8u)) break;
                        }
                        v0 = (0x80000000u ^ (u1 / ((0x80000000u % ((0x80000000u >> ((unsigned)e0 & 31u)) | 1u)) | 1u)));
                        a0[(0x80000000u >> ((unsigned)s0 & 31u)) & 3u] = ((i2 / ((0xcceac898u & r0.y) | 1u)) & ((unsigned)w0 + i2));
                        if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((int)0xbb7b1832u >= (int)(0xa9cf0208u << (p0 & 31u))), (p1 + m0), (unsigned)((short)6u > (signed char)i0)); }
                    } else {
                        w0 = w0 * 6364136223846793005ull + 0x99e233b1u;
                        if (m0) {
                            case 4u: ;
                            u2 = u2 * 0x9e3779b1u + (p1 | (unsigned)((int)(unsigned)(r0.y || (unsigned)!(m0 & (unsigned)c1)) >= (int)(unsigned)d0));
                            case 2u: ;
                            break; (void)(6u);
                            if ((garr[u2 & 7u] | (p2 - 0x10000u))) continue;
                            break;
                        }
                        a0[(unsigned)(6u || 0xcd71c930u) & 3u] = (unsigned)((int)(unsigned)((int)0x10000u < (int)(unsigned)l0) < (int)fuel);
                        b0 = (((unsigned)((short)0x3048c3aeu > (signed char)u2) >> (0x80000000u & 31u)) << (u2 & 31u)) != 0u;
                    }
                    continue; (void)((p2 * (unsigned)(signed char)(3u << (0x10000u & 31u))));
                    break;
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)0xe92b5277u < (int)0xffffffffu), (unsigned)(*mp && (unsigned)(short)((unsigned)(w0 >> 29) % (0x10bb51f0u | 1u))), (1u - garr[u2 & 7u])); }
                }
            }
        }
        while (i0++ < 6u && (unsigned)(signed char)((unsigned)s0 & a0[i0 & 3u])) { if (--fuel == 0u) goto done;
            if ((*mp | i1)) break;
            m0 ^= (0x7fffffffu | ((unsigned)s1 ? (m0 / (0x10000u | 1u)) : garr[u2 & 7u]));
            if (p2) goto L2;
        }
    }
    if (1u) {
        l0 = (long)((unsigned long)l0 + (unsigned)(garr[u2 & 7u] && fuel));
        goto L2;
        switch ((unsigned)((unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)s0) == 0x7a83f18fu) & 7u) {
            case 0u: ;
        }
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)c1);
            if ((unsigned)s0) break;
            b0 = (p1 & garr[i1 & 7u]) != 0u;
            u2 = (unsigned)(unsigned char)((unsigned)((unsigned)s0 == (unsigned)w0) ^ (*q0 << (r0.x & 31u)));
            m0 ^= ((unsigned)b0 - ((unsigned)((int)(unsigned)(x0 >> 70) < (int)g0) - (unsigned)(5u == g1)));
            { unsigned t2; double z2; if (((unsigned)((unsigned)l0 == ((unsigned)h1 | garr[u2 & 7u]))) & 1u) { t2 = (i0 + (unsigned)((int)garr[i1 & 7u] < (int)m0)); z2 = (double)((garr[i1 & 7u]) & 255u); } if (((unsigned)((unsigned)l0 == ((unsigned)h1 | garr[u2 & 7u]))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                if (0xffffffffu) goto L1;
            }
        }
        e0 = e0 * 0.5L + (long double)(u3 & 1023u);
    } else {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((~(p1 >> (p2 & 31u)) / ((unsigned)w0 | 1u))) break;
                if (u3) continue;
                if (budget != 0u) { budget -= 1u; u1 = fn0((garr[u2 & 7u] << (0x80000000u & 31u)), u3, (unsigned)(w0 >> 29)); }
                if ((unsigned)(unsigned char)(unsigned)((unsigned)(u3 && *mp) || i1)) break;
            }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                q0 = &garr[0x80000000u & 7u];
                break; (void)(0x912c1569u);
                do { if (--fuel == 0u) goto done;
                    goto L2;
                    g0 = -(unsigned)((short)(unsigned)(7u < (unsigned)b0) > (signed char)2u);
                } while (i2++ < 5u && ~(unsigned)((int)r0.x < (int)-((unsigned)c0 << (7u & 31u))));
                if (((unsigned)((short)u0 > (signed char)(unsigned)(w0 >> 29)) & (unsigned)(w0 >> 29))) break;
            }
            if (u3 == 7u) return (unsigned)((int)((unsigned)e0 * (unsigned)s0) >= (int)(unsigned)(g1 || g1));
            if (((unsigned)f0 % ((0x5b208cfau * i0) | 1u))) {
                if ((*mp << ((unsigned)((short)*mp > (signed char)*q0) & 31u))) continue;
                { unsigned t3; double z3; if ((0x80000000u) & 1u) { t3 = (unsigned)((int)(0xf5674a3au % (0x10000u | 1u)) >= (int)p2); z3 = (double)((u3) & 255u); } if ((0x80000000u) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    if ((unsigned)((int)0x10000u < (int)(unsigned)h1)) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(0x10000u, i2, (p0 + (0xffffffffu - *mp))); }
                    if (fuel < 8u) return ((*q0 ^ g1) + (((unsigned)w0 & 0x1092dc72u) + 0xffffffffu));
                    w0 = w0 * 6364136223846793005ull + (0x10000u | 4u);
                    u0 = u0 * 0x9e3779b1u + (unsigned)(w0 >> 29);
                }
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (u1 ? r0.y : u1);
                    if (budget != 0u) { budget -= 1u; u0 = fn1((p0 * (unsigned)x0), (unsigned)l0, ~((unsigned)b0 % ((2u - (unsigned)w0) | 1u))); }
                    if ((unsigned)(u3 == p2)) {
                        if (p2) continue;
                        if ((unsigned)b0) goto L0;
                        garr[(u0 / ((unsigned)(w0 >> 29) | 1u)) & 7u] = -((unsigned)s1 - u2);
                        *mp = 5u;
                        do { if (--fuel == 0u) goto done;
                            l0 = (long)((unsigned long)l0 + 9u);
                            m0 ^= (unsigned)((unsigned)d0 < garr[i1 & 7u]);
                            f0 = f0 * 0.5f + (float)(0x80000000u & 255u);
                            break; (void)((unsigned)c0);
                            if (budget != 0u) { budget -= 1u; u2 = fn3(u0, 0x356950acu, (unsigned)((int)(p0 / ((unsigned)l0 | 1u)) < (int)0x7ee85049u)); }
                        } while (i2++ < 2u && (unsigned)(short)(unsigned)((i2 % (fuel | 1u)) && i0));
                        if (budget != 0u) { budget -= 1u; u1 = fn0(*q0, (unsigned)((short)p0 > (signed char)(unsigned)(g0 && u0)), (unsigned)(w0 >> 29)); }
                    } else {
                        x0 = x0 * 0x100000001b3ull + (unsigned)((int)g0 >= (int)((unsigned)((int)(unsigned)h1 >= (int)r0.y) >> (0xaa3fde52u & 31u)));
                        i0 = m0 & 15u;
                        break; (void)((unsigned)(w0 >> 29));
                        s1 = (int)((unsigned)s1 + (unsigned)!(unsigned)((unsigned)(x0 >> 70) && 2u));
                    }
                    r0.x = (unsigned)((0x7fffffffu ? (unsigned)l0 : a0[u1 & 3u]) || (a0[i0 & 3u] / (6u | 1u)));
                    h1 = (unsigned short)(h1 + -(unsigned)((int)(0xd8af6b2u ^ (5u ? p0 : u2)) < (int)(unsigned)c0));
                    l0 = (long)((unsigned long)l0 + ~((unsigned)!(unsigned)(0x974a4d8bu == (unsigned)l0) >> (((unsigned)((int)p0 >= (int)(unsigned)f0) | (unsigned)f0) & 31u)));
                }
                g0 = (unsigned)((unsigned)((short)6u > (signed char)r0.y) < (unsigned)((int)(0x7fffffffu & (unsigned)w0) >= (int)garr[u2 & 7u]));
            } else {
                d0 = d0 * 0.5 + (double)((unsigned)w0 & 1023u);
                if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)((unsigned)(g1 || g1) || u1), (0xffffffffu | (unsigned)(unsigned char)(unsigned)((unsigned)(x0 >> 70) == 0x7fffffffu)), (unsigned)((unsigned)s1 < 0xbba3ec47u)); }
                g1 += (unsigned)(0x709736ddu || 0x7fffffffu);
            }
        }
    }
    u1 = -(unsigned)((unsigned)d0 && a0[i0 & 3u]);
    q0 = &garr[m0 & 7u];
    if (((unsigned)(w0 >> 29) & a0[i0 & 3u])) goto L2;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0xffffffffu) break;
        while ((unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
            c1 = (signed char)((unsigned)e0 >> ((unsigned)((int)g0 >= (int)0xffffffffu) & 31u));
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(0x80000000u == (*mp & garr[u2 & 7u])), ((unsigned)d0 / ((5u / ((unsigned)(x0 >> 70) | 1u)) | 1u)), (0x80000000u % (0x80000000u | 1u))); }
            g1 += (unsigned)((int)i1 < (int)(unsigned)c1);
            do { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + -((unsigned)s0 | (unsigned)((short)i2 > (signed char)0x8613e0cau)));
                    if ((unsigned)(w0 >> 29)) goto L4;
                    if (u0) goto done;
                    d0 = d0 * 0.5 + (double)(((unsigned)(0xffffffffu && (unsigned)s0) * *mp) & 1023u);
                    if (0x9c0e8c98u) break;
                }
                m0 ^= (0x10000u & (u2 >> ((unsigned)((unsigned)w0 || g0) & 31u)));
            } while (i2++ < 5u && 0xffffffffu);
            if (7u) {
                if (m0) {
                    if (0x31b565c8u) break;
                    continue; (void)(a0[u1 & 3u]);
                } else {
                    c0 = (unsigned char)(unsigned)((unsigned)c0 && u1);
                    r0.x = (unsigned)(unsigned char)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)g1) + ((unsigned)s1 ? 7u : (unsigned)f0));
                    c0 = (unsigned char)(unsigned)(short)(0x80000000u << ((0xffffffffu & (unsigned)e0) & 31u));
                    *q0 = (unsigned)(signed char)(0u * v0);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)w0, (unsigned)(signed char)(u2 ^ (u2 - (unsigned)c0)), (unsigned)b0); }
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)((unsigned)w0 == r0.y) >= (int)garr[i1 & 7u]), (unsigned)((unsigned)h0 || (unsigned)(u0 || (unsigned)s0)), (2u / ((unsigned)(0x10000u || 6u) | 1u))); }
                break; (void)(6u);
                h0 = (short)(unsigned)(unsigned char)(unsigned)(*q0 && (unsigned)((v0 >> (0x79a3bfcfu & 31u)) && (unsigned)(x0 >> 70)));
            }
            g1 += ((r0.x | 0xaaacf6b9u) / ((8u * (p0 % ((unsigned)x0 | 1u))) | 1u));
        }
        break; (void)((unsigned)((int)(unsigned)(signed char)(*mp + g1) < (int)r0.y));
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)(~(unsigned)(i2 || u1) && (unsigned)h1) & 1023u);
        }
        if ((u2 + (unsigned)!(unsigned)((unsigned)(w0 >> 29) || u2))) {
            while (i1++ < 7u && u1) { if (--fuel == 0u) goto done;
                break; (void)(a0[i0 & 3u]);
                if ((unsigned)((int)(unsigned)(p1 == p1) >= (int)4u)) goto L4;
                h0 = (short)(unsigned)c1;
            }
            *mp = (unsigned)(signed char)((unsigned)b0 + (unsigned)((short)0x7fffffffu > (signed char)(fuel ? 0x80000000u : p2)));
            *q0 = ((unsigned)f0 + (0u >> (g0 & 31u)));
        }
        s1 = (int)((unsigned)s1 + u0);
    }
    u3 += 0x80000000u;
    w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x80000000u);
    goto L1;
    goto L0;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((4u * m0) && r0.y), (unsigned)(((unsigned)c0 << (fuel & 31u)) && m0), ((unsigned)((int)(unsigned)b0 < (int)a0[u1 & 3u]) + 0x8bb20ef2u)); }
    e0 = e0 * 0.5L + (long double)((unsigned)(0x1e8e3f79u && 0x7fffffffu) & 1023u);
    if ((i0 | a0[i0 & 3u])) goto L4;
    { unsigned t4; double z4; if (((unsigned)s1) & 1u) { t4 = (unsigned)(signed char)(unsigned)((int)i2 < (int)0xffffffffu); z4 = (double)((0xffffffffu) & 255u); } if (((unsigned)s1) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        v0 = (unsigned)(short)((r0.x | (unsigned)c0) * (garr[u2 & 7u] & i2));
        garr[(unsigned)(0x1b544d12u == 0x9f75eb65u) & 7u] = (garr[u2 & 7u] + (((unsigned)s0 | 0xc2b03800u) + (unsigned)((int)(unsigned)c1 < (int)0x10000u)));
        if (u2) goto L4;
        if ((unsigned)((short)r0.x > (signed char)0xcb90034eu)) goto L0;
        u3 = (0x329ad62cu + (unsigned)((int)(unsigned)d0 >= (int)i0));
        i2 = p1 & 15u;
    }
    i1 = ((0x10000u ? 0xac5437b0u : fuel) >> ((unsigned)l0 & 31u)) & 15u;
    goto L4;
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(x0 >> 70), (unsigned)c1, (unsigned)(3u || (unsigned)l0)); }
    goto L4;
    d0 = d0 * 0.5 + (double)(((unsigned)f0 & (unsigned)((short)4u > (signed char)u2)) & 1023u);
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(short)(6u / (p2 | 1u))) {
            do { if (--fuel == 0u) goto done;
                i0 = 0x33df035cu & 15u;
            } while (i1++ < 2u && (*mp & 0x2d67abu));
            if ((unsigned)(short)(unsigned)((short)2u > (signed char)0xfa599cefu)) {
                do { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(-(unsigned)(u1 == (unsigned)(w0 >> 29)) << ((p1 / (0x10000u | 1u)) & 31u)));
                    if (((unsigned)f0 & (unsigned)w0)) {
                        for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                            h0 = (short)(a0[i0 & 3u] - i2);
                            c1 = (signed char)(unsigned)(signed char)(u2 ? u2 : 0x82c2d883u);
                            l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(*q0 >> ((unsigned)(((unsigned)(w0 >> 29) * r0.x) || (unsigned)(unsigned char)(unsigned)(0xca9420c9u && 3u)) & 31u)));
                            r0.x = (unsigned)((int)*q0 >= (int)((0u % (garr[i1 & 7u] | 1u)) % ((unsigned)x0 | 1u)));
                            if ((unsigned)((unsigned)((int)v0 < (int)u3) < i2)) goto L2;
                            a0[(unsigned)h0 & 3u] = r0.y;
                        }
                        m0 ^= ~(0x155d1f3cu * ((unsigned)(x0 >> 70) / ((unsigned)((int)(0xd5009e88u * g1) < (int)0xcdb7cb55u) | 1u)));
                        s1 = (int)((unsigned)s1 + (u1 >> (0xffffffffu & 31u)));
                    }
                } while (i1++ < 6u && ((u0 ^ fuel) ^ a0[i0 & 3u]));
            }
        }
        do { if (--fuel == 0u) goto done;
            u3 = u3 * 0x9e3779b1u + (((unsigned)h0 / (v0 | 1u)) / (~((unsigned)h0 + (unsigned)h1) | 1u));
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)5u >= (int)(unsigned)s1), (unsigned)(signed char)(unsigned)((unsigned)w0 == p1), (unsigned)e0); }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((p1 ^ m0) || 0u), (unsigned)((int)((unsigned)b0 << (garr[u2 & 7u] & 31u)) < (int)v0), a0[u1 & 3u]); }
            if (8u) {
                if ((unsigned)(unsigned char)(v0 % (8u | 1u))) break;
                while (i2++ < 7u && (unsigned)(0x704dc09u && 0x7589d766u)) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)(8u < g1));
                }
                if ((i2 | ((unsigned)c1 % ((unsigned)l0 | 1u)))) continue;
                switch (((unsigned)s1 % ((unsigned)d0 | 1u)) & 7u) {
                    x0 = x0 * 0x100000001b3ull + (unsigned)d0;
                    if ((p1 / ((unsigned)((unsigned)x0 == p2) | 1u))) goto L1;
                    case 7u: ;
                    c1 = (signed char)(((unsigned)c1 ? (0xe8c4baecu - (unsigned)x0) : p0) | p2);
                }
            }
            if (0x10000u) break;
            m0 ^= ((unsigned)e0 - ((unsigned)l0 + (-(unsigned)((int)a0[u1 & 3u] < (int)garr[i1 & 7u]) | (unsigned)d0)));
        } while (i1++ < 5u && 0xd0d9607au);
        g0 = (((unsigned)x0 / (u3 | 1u)) * (unsigned)(short)((unsigned)(unsigned char)(0xffffffffu | a0[u1 & 3u]) & u0));
        *q0 += ((unsigned)((unsigned)(x0 >> 70) < 0x10000u) % ((unsigned)(i0 || a0[i0 & 3u]) | 1u));
        c0 = (unsigned char)(5u / (2u | 1u));
    }
    r0.y ^= (unsigned)(u2 < a0[i0 & 3u]);
    if (((unsigned)s1 % (0x2ffb5a0du | 1u))) {
        h0 = (short)(unsigned)(~((unsigned)b0 / (0x80000000u | 1u)) || (unsigned)((int)0x7fffffffu >= (int)0x9fbb8c52u));
    } else {
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((r0.x + (unsigned)((int)p0 < (int)m0))) {
                    q0 = &garr[((~((unsigned)s0 * (unsigned)s0) & (unsigned)c1) & p2) & 7u];
                    if ((g0 * (unsigned)(g1 == 0xffffffffu))) break;
                    i0 = (unsigned)((unsigned)((short)0xffffffffu > (signed char)u1) < (a0[i0 & 3u] ? (unsigned)w0 : 7u)) & 15u;
                } else {
                    if (((unsigned)s1 * g1)) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)b0, (r0.y + ((unsigned)e0 ^ u2)), (unsigned)(signed char)(unsigned)(p1 && (unsigned)((short)(unsigned)x0 > (signed char)p0))); }
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)c1 == (unsigned)(i2 < *mp)), (1u - 0x80000000u), (unsigned)(5u && 0x80000000u)); }
                }
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(signed char)((unsigned)(u0 || a0[i0 & 3u]) | p1), (unsigned)l0, (unsigned)((unsigned)c0 == a0[u1 & 3u])); }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(0x7fffffffu == (unsigned)((short)(unsigned)d0 > (signed char)r0.x)), 0x7fffffffu, 0xffffffffu); }
                if (garr[u2 & 7u]) continue;
            } while (i1++ < 2u && a0[u1 & 3u]);
            a0[(unsigned)((int)fuel < (int)0xe1db3490u) & 3u] = ~(m0 >> ((unsigned)s1 & 31u));
            goto L2;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)c0, (u0 | (unsigned)c1), 0x7fffffffu); }
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (unsigned)x0;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    switch (0x80000000u & 7u) {
                        u2 += p2;
                    }
                    r0.y ^= (unsigned)((int)(((unsigned)c1 + 6u) ? 0x7360bd5fu : (unsigned)f0) >= (int)(unsigned)s1);
                    if ((0xe8fe2f1au * 0x296d6dd1u)) break;
                    if (u0) {
                        q0 = &garr[(unsigned)((short)r0.y > (signed char)(unsigned)(w0 >> 29)) & 7u];
                        g0 = (unsigned)(a0[i0 & 3u] < i1);
                        w0 = w0 * 6364136223846793005ull + ((garr[u2 & 7u] >> (i2 & 31u)) & (r0.x << ((unsigned)(0xe6c211aeu < a0[u1 & 3u]) & 31u)));
                    } else {
                        c0 = (unsigned char)(unsigned)((unsigned)((short)(m0 * (unsigned)l0) > (signed char)(unsigned)x0) && 3u);
                    }
                    g1 += (0x4b69aeb1u << (2u & 31u));
                }
                if (((unsigned)((unsigned)w0 && (unsigned)x0) % (0xffffffffu | 1u))) break;
                if (budget != 0u) { budget -= 1u; u2 = fn3(0x7fffffffu, ((unsigned)h1 & (unsigned)(*q0 || g1)), (unsigned)((int)((unsigned)w0 + i1) >= (int)0xd71e8720u)); }
                switch ((unsigned)x0 & 7u) {
                    c0 = (unsigned char)((unsigned)((int)u2 >= (int)0x42598c8cu) ^ g0);
                    h0 = (short)(unsigned)((short)u1 > (signed char)((unsigned)(w0 >> 29) & g1));
                    if ((unsigned)(a0[i0 & 3u] == g1)) continue;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)9u < (int)*mp), (0xffffffffu * fuel), (m0 << ((unsigned)(x0 >> 70) & 31u))); }
                    a0[-(r0.x << ((unsigned)h1 & 31u)) & 3u] = ((p0 ^ (unsigned)x0) >> (0x80000000u & 31u));
                    case 0u: ;
                }
            }
            if (0x6b36b599u) break;
        }
    }
    do { if (--fuel == 0u) goto done;
        if (*q0) break;
    } while (i0++ < 2u && (*q0 ^ (unsigned)((unsigned)(x0 >> 70) == (unsigned)h0)));
    if (budget != 0u) { budget -= 1u; u0 = fn1(6u, (unsigned)((unsigned)(0xf9c6bad6u || u1) < 0x80000000u), i1); }
    d0 = d0 * 0.5 + (double)(6u & 1023u);
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)*q0 < (int)v0), (-(u3 % (*q0 | 1u)) % (a0[i0 & 3u] | 1u)), (unsigned)((unsigned)h1 == *q0)); }
        while (i1++ < 2u && v0) { if (--fuel == 0u) goto done;
            goto L4;
            break; (void)((unsigned)(0x80000000u || (unsigned)((int)*mp >= (int)p1)));
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)(unsigned char)(a0[u1 & 3u] >> (0x7fffffffu & 31u));
                    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((unsigned)w0 < ((unsigned)s1 - a0[i0 & 3u])), (unsigned)d0, ~(unsigned)((unsigned)((int)0x80000000u >= (int)(unsigned)d0) && u3)); }
                    v0 = ((unsigned)w0 / ((unsigned)f0 | 1u));
                }
                a0[(unsigned)c1 & 3u] = (unsigned)((0x16771552u | (unsigned)w0) || g0);
                garr[v0 & 7u] = 0x7fffffffu;
            }
            r0.x = (p2 * g1);
            u1 ^= 0xa1b673edu;
            if (fuel < 8u) return (u2 << (0xe39adfbfu & 31u));
        }
        do { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)(x0 >> 70));
            a0[i1 & 3u] = (4u * 8u);
            h0 = (short)(unsigned)(unsigned char)(unsigned)((int)0x45b80d8au < (int)(g0 >> (i0 & 31u)));
            r0.y ^= (0x4fe1fbd3u - (unsigned)((int)(unsigned)l0 < (int)i1));
            g0 = (unsigned)(*q0 && (unsigned)((int)u3 < (int)u1));
            *q0 = ((unsigned)c0 & (unsigned)(0u && (unsigned)b0));
        } while (i1++ < 6u && ~(fuel & g1));
        if ((unsigned)((int)g1 < (int)(a0[u1 & 3u] + p2))) break;
        break; (void)(u0);
    }
    if (budget != 0u) { budget -= 1u; u1 = fn2(3u, (((unsigned)s1 + 0x10000u) | (unsigned)(w0 >> 29)), (unsigned)x0); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 11u, 0xd8261ae3u, 0x95d4c681u },
        { 2u, 0x70c2a69fu, 0x708e1374u },
        { 14u, 0xc6631627u, 0xaa638ff7u },
        { 15u, 0x337128eeu, 0x975ee66au },
        { 3u, 0x3d8f8abau, 0xc453d8a6u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
