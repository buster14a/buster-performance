static int own_pages(void) { return 123; }
int getpagesize(void) __attribute__((alias("own_pages")));
static int counter = 41;
extern int opterr __attribute__((alias("counter")));
int main(void) { int (*page)(void) = getpagesize; return (getpagesize() != 123) + (page() != 123) * 2 + (opterr != 41) * 4; }
