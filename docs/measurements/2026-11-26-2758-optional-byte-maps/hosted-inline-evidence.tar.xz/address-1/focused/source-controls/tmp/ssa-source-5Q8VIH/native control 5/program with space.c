long next(long x) { return x + 1; } long tail(long x) { __attribute__((musttail)) return next(x); } int main(void) { return tail(1) != 2; }
