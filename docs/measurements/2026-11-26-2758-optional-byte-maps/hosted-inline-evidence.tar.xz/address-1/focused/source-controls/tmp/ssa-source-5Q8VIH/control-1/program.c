extern void exit(int); int main(void) { exit(23); return 0; }
