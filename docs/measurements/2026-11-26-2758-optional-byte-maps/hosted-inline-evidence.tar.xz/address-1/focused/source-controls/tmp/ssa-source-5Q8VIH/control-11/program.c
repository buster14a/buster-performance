extern int strcmp(const char *, const char *); extern char *getenv(const char *);
int main(int argc, char **argv, char **envp) { return argc != 1 || strcmp(argv[0], "program") != 0 || argv[1] != 0 || envp[0] != 0 ||
getenv("BUSTER_SSA_SOURCE_NATIVE_SENTINEL") != 0; }
