extern void exit(int); int main(void) { exit(255); return 0; }
