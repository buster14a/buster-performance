typedef void (*Handler)(int); extern Handler signal(int, Handler); static void handler(int s) { (void)s; }
int main(void) { signal(10, handler); return 0; }
