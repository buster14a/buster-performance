#include <value.h>
extern long write(int, const void *, unsigned long);
int main(void) { volatile int n = 6; int sum = 0; for (int i = 0; i < n; ++i) sum += (i & 1) ? i : i + 1;
write(1, "native\n", 7); write(2, "error\n", 6); return sum == 18 && SSA_SOURCE_VALUE + SSA_SOURCE_FORCED == 22 ? 7 : 8; }
