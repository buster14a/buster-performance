extern int atexit(void (*)(void)); static void handler(void) {}
int main(void) { return atexit(handler); }
