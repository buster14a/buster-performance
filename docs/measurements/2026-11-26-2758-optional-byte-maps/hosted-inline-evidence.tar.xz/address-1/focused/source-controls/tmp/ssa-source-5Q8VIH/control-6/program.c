extern void qsort(void *, unsigned long, unsigned long, int (*)(const void *, const void *));
static int compare(const void *a, const void *b) { return *(const int *)a - *(const int *)b; }
int main(void) { int a[3] = {3, 1, 2}; qsort(a, 3, sizeof(int), compare); return 0; }
