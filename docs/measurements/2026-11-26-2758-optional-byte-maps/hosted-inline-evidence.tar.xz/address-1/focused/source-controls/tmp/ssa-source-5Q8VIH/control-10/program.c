static int one(void) { return 1; }
static int (*resolve(void))(void) { return one; }
int dispatched(void) __attribute__((ifunc("resolve")));
int main(void) { return dispatched() - 1; }
