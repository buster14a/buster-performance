extern long write(int, const void *, unsigned long); int main(void) { write(1, "actual\n", 7); return 0; }
