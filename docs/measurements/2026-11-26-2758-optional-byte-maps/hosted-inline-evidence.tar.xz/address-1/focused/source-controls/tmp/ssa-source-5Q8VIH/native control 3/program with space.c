extern unsigned alarm(unsigned); int main(void) { alarm(0); volatile unsigned x = 0; for (;;) ++x; }
