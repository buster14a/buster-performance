extern int close(int); int main(void) { for (int fd = 3; fd < 4096; ++fd) close(fd); return 7; }
