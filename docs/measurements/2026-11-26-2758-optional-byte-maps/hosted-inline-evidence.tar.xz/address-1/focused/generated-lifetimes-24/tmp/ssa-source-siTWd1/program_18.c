// test-ssa-source's program of seed 141000441 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xf5720c7fu, g1 = 0xe90433cau;
static unsigned garr[8] = { 0xe3508829u, 0xec8224b0u, 0x135f8b04u, 0xe9d546dbu, 0x25fee334u, 0x2a9b5519u, 0x17f14577u, 0xa86f3782u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *mp = ((m0 ? 3u : (unsigned)h1) - 0x8f789d73u);
    s0 = (int)((p2 + (unsigned)h0) << ((((unsigned)(x0 >> 70) & (unsigned)h0) ^ 0xb2bbdd25u) & 31u));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = ((m0 | 2u) & (unsigned)((short)3u > (signed char)(unsigned)((int)(unsigned)f0 >= (int)m0)));
        i0 = ((unsigned)(0xd957785u || (unsigned)c1) ^ fuel) & 15u;
        if ((unsigned)((int)u3 >= (int)r0.y)) {
            if ((r0.x - (unsigned)(signed char)(unsigned)(*q0 == g0))) {
                r0.y ^= 4u;
                if ((3u % ((unsigned)l0 | 1u))) {
                    if (u3 == 7u) return (unsigned)(m0 && (unsigned)((int)(unsigned)((int)2u >= (int)(unsigned)c1) >= (int)r0.x));
                    if (((unsigned)e0 / ((unsigned)((unsigned)h1 < 0u) | 1u))) continue;
                    if ((unsigned)!(unsigned)((unsigned)h1 < (unsigned)(signed char)(a0[u1 & 3u] * 0xeb377b5bu))) break;
                } else {
                    for (;;) { if (--fuel == 0u) goto done;
                        u2 ^= -(unsigned)((short)0x80f3fd34u > (signed char)(unsigned)((int)r0.y < (int)((unsigned)x0 & a0[u1 & 3u])));
                    }
                }
                L0: if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                r0.x = (unsigned)l0;
            }
            if (((unsigned)b0 << (i1 & 31u))) {
                *mp = (unsigned)(unsigned char)((unsigned)((short)0xffffffffu > (signed char)(unsigned)(x0 >> 70)) | (unsigned)(w0 >> 29));
                L2: if (--fuel == 0u) goto done;
                h0 = (short)(0x1c9981c7u * (unsigned)((unsigned)x0 && (garr[i1 & 7u] * r0.x)));
            } else {
                if (fuel < 8u) return (unsigned)((2u ^ *q0) == *mp);
                c0 = (unsigned char)(unsigned)(5u == (unsigned)!(unsigned)((int)(unsigned)x0 < (int)(unsigned)((int)0u < (int)(unsigned)(v0 && g1))));
                do { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (p2) break;
                        s1 = (int)((unsigned)s1 + r0.y);
                        L3: if (--fuel == 0u) goto done;
                        u3 = (((unsigned)((unsigned)l0 == *mp) - (r0.y + 0x10000u)) | r0.x);
                        s0 = (int)((r0.x & (unsigned)d0) / (i1 | 1u));
                        L4: if (--fuel == 0u) goto done;
                    }
                    *q0 = *q0;
                    a0[(unsigned)(0x62736b04u || *q0) & 3u] = (i1 / (i2 | 1u));
                    if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)(0xcd40df17u < (unsigned)w0) < (int)v0)) break;
                    if (0x7fffffffu) break;
                } while (i1++ < 5u && (0xa15f297fu | fuel));
            }
            if (((unsigned)b0 * (unsigned)x0)) continue;
        }
        u2 += (0xad3ee948u % (-(unsigned)(a0[i0 & 3u] == u1) | 1u));
    }
    *mp = ((unsigned)((unsigned)c1 || (unsigned)b0) ^ (unsigned)((int)*mp >= (int)-((unsigned)e0 * p1)));
    goto done;
    g0 = (u1 / (((unsigned)h0 | a0[i0 & 3u]) | 1u));
    if ((unsigned)((int)(6u % (0x82333ebdu | 1u)) < (int)(unsigned)(w0 >> 29))) goto L4;
    if ((unsigned)(x0 >> 70)) goto L1;
    if (r0.y) {
        if (((unsigned)((int)r0.x >= (int)(unsigned)(x0 >> 70)) | (unsigned)x0)) goto L1;
        while (i0++ < 5u && (p0 - m0)) { if (--fuel == 0u) goto done;
            break; (void)(-(0xffffffffu - (unsigned)((int)9u >= (int)(unsigned)f0)));
            r0.y ^= p0;
            garr[-(8u / (fuel | 1u)) & 7u] = (unsigned)((int)(unsigned)((unsigned)c0 == (unsigned)h0) < (int)(unsigned)e0);
            *q0 += (*q0 & ((unsigned)((unsigned)l0 == (unsigned)c0) / ((unsigned)(short)(unsigned)((short)(unsigned)b0 > (signed char)p0) | 1u)));
        }
        while (i0++ < 4u && (*mp & (unsigned)c1)) { if (--fuel == 0u) goto done;
            h0 = (short)m0;
            c1 = (signed char)((unsigned)((unsigned)c0 && ((unsigned)!(v0 / (6u | 1u)) ^ (unsigned)x0)) % ((unsigned)f0 | 1u));
            h0 = (short)a0[i0 & 3u];
            { unsigned t0; double z0; if (((unsigned)((unsigned)s1 && (r0.y / (g0 | 1u)))) & 1u) { t0 = garr[u2 & 7u]; z0 = (double)(((unsigned)c0) & 255u); } if (((unsigned)((unsigned)s1 && (r0.y / (g0 | 1u)))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                if (((unsigned)e0 ? p0 : (unsigned)w0)) break;
                garr[i0 & 7u] = ((unsigned)w0 * g0);
            }
        }
        if (0x7a8c7dc5u) goto L4;
        x0 = x0 * 0x100000001b3ull + ((unsigned)!(unsigned)((unsigned)s1 < (unsigned)w0) - (unsigned)(w0 >> 29));
    } else {
        if ((unsigned)w0) goto L1;
        if ((0x14dedd9eu % ((p2 / ((unsigned)b0 | 1u)) | 1u))) goto done;
        { unsigned t1; double z1; if (((2u - (unsigned)d0)) & 1u) { t1 = 1u; z1 = (double)((((2u & 8u) - 7u)) & 255u); } if (((2u - (unsigned)d0)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            s1 = (int)((unsigned)s1 + (unsigned)((int)u0 >= (int)(unsigned)h0));
            while (i0++ < 2u && (unsigned)(0xbae964c3u && (unsigned)x0)) { if (--fuel == 0u) goto done;
                if ((unsigned)(signed char)((unsigned)d0 - (unsigned)w0)) break;
                *mp = (unsigned)!((unsigned)b0 ^ (unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)(short)((unsigned)(r0.y < u2) * u3)));
            }
        }
    }
    while (i0++ < 2u && (garr[i1 & 7u] ^ 0xffffffffu)) { if (--fuel == 0u) goto done;
        if (g1) {
            e0 = e0 * 0.5L + (long double)(((unsigned)e0 ^ (unsigned)(x0 >> 70)) & 1023u);
            if ((p2 / ((unsigned)((int)0x10000u >= (int)1u) | 1u))) break;
            if (((i1 ^ (unsigned)w0) & *q0)) break;
        }
        m0 ^= a0[u1 & 3u];
        switch ((garr[u2 & 7u] - (unsigned)((int)(unsigned)s1 < (int)9u)) & 7u) {
            { unsigned t2; double z2; if (((0x74f7a1f8u / (p2 | 1u))) & 1u) { t2 = (unsigned)((int)(0x9259021fu + garr[i1 & 7u]) >= (int)0x7fffffffu); z2 = (double)(((unsigned)(i0 == (unsigned)!(a0[i0 & 3u] ^ 0x10497f34u))) & 255u); } if (((0x74f7a1f8u / (p2 | 1u))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                q0 = &garr[(unsigned)(u3 && ((unsigned)h0 ? u0 : 0x80000000u)) & 7u];
                case 0u: ;
                break; (void)((unsigned)(signed char)(unsigned)((int)(unsigned)(signed char)((unsigned)h1 % (0x80000000u | 1u)) >= (int)7u));
            }
            m0 ^= (unsigned)b0;
            g1 += (unsigned)(g0 == (unsigned)((int)(unsigned)((short)fuel > (signed char)u1) < (int)4u));
            if (u3 == 7u) return ((unsigned)e0 ? 0xed23b57du : r0.y);
            if (((unsigned)s0 | r0.x)) break;
        }
        u0 ^= ((unsigned)h1 >> (m0 & 31u));
        if (u3 == 7u) return (unsigned)((short)u0 > (signed char)((3u / (2u | 1u)) ^ (8u << (a0[u1 & 3u] & 31u))));
        { unsigned t3; double z3; if (((unsigned)(0x80000000u == ((unsigned)c1 / (9u | 1u)))) & 1u) { t3 = (a0[i0 & 3u] ^ 5u); z3 = (double)(((unsigned)(0x10000u == (unsigned)(0x7fffffffu || 0x4422024au))) & 255u); } if (((unsigned)(0x80000000u == ((unsigned)c1 / (9u | 1u)))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(2u && (unsigned)e0)) break;
            }
        }
    }
    if (((unsigned)((int)0x80000000u < (int)0x6d89ae23u) | 0x7fffffffu)) goto L1;
    *q0 = ((unsigned)(x0 >> 70) | (unsigned)((unsigned)(w0 >> 29) || r0.y));
    g0 = ((unsigned)((int)0xe9a1399cu < (int)u3) - i0);
    a0[(unsigned)((int)i2 >= (int)g1) & 3u] = (unsigned)((8u - (unsigned)f0) || (unsigned)(signed char)(0x8b9f1fc8u % (((unsigned)c1 << (0x7fffffffu & 31u)) | 1u)));
    r0.y ^= (u3 << (fuel & 31u));
    goto L2;
    e0 = e0 * 0.5L + (long double)(((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)s0) << (((unsigned)h0 ? 0x9180273fu : (unsigned)w0) & 31u)) & 1023u);
    while (i0++ < 5u && (0x6b2d96b3u * garr[u2 & 7u])) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(9u == (unsigned)w0));
        while (i1++ < 4u && *mp) { if (--fuel == 0u) goto done;
            i0 = ~(2u & (unsigned)e0) & 15u;
            garr[0xffffffffu & 7u] = (unsigned)l0;
            if ((p1 % (*q0 | 1u))) break;
            s1 = (int)((unsigned)s1 + (unsigned)((5u + (unsigned)(u0 && (unsigned)(w0 >> 29))) == 8u));
        }
        if ((unsigned)((g0 * (unsigned)x0) && r0.x)) continue;
        break; (void)((unsigned)d0);
        if (((unsigned)(short)(unsigned)((short)i0 > (signed char)a0[u1 & 3u]) - *mp)) break;
        l0 = (long)((unsigned long)l0 + ((unsigned)c0 ^ (i0 ^ 4u)));
    }
    u0 = ((unsigned)e0 - a0[u1 & 3u]);
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)((int)(unsigned)(x0 >> 70) < (int)g1))) break;
        c1 = (signed char)(m0 ^ m0);
        q0 = &garr[(unsigned)(short)(unsigned)(p2 && (i0 | u0)) & 7u];
        if (0x605c7fa0u) {
            if ((6u / (1u | 1u))) break;
            garr[(unsigned)e0 & 7u] = ((unsigned)(signed char)((unsigned)d0 / (0xffffffffu | 1u)) ^ (u1 << ((unsigned)((short)r0.x > (signed char)0x7fffffffu) & 31u)));
        } else {
            switch ((u1 & r0.y) & 7u) {
                i2 = (unsigned)!(unsigned)((short)0xf290502bu > (signed char)(1u ? g1 : (unsigned)h1)) & 15u;
                case 4u: ;
                if (u3 == 7u) return ((unsigned)((short)u1 > (signed char)(unsigned)w0) * ((unsigned)((int)0x10000u >= (int)*q0) >> (g0 & 31u)));
            }
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (r0.x) break;
        L0: if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)(short)(~(u3 | 0x7fffffffu) & 0x4dbfa5b8u);
    }
    if (u3) goto L1;
    *q0 += -((unsigned)b0 % (garr[u2 & 7u] | 1u));
    e0 = e0 * 0.5L + (long double)((unsigned)(m0 < (unsigned)b0) & 1023u);
    q0 = &garr[(unsigned)((short)((unsigned)((unsigned)(r0.y < (unsigned)c0) < r0.y) ^ 6u) > (signed char)(unsigned)l0) & 7u];
    s0 = (int)((g1 | fuel) % (((unsigned)(short)((unsigned)d0 | (unsigned)s1) | p1) | 1u));
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            if (u3 == 7u) return (unsigned)h1;
            if (u3 == 7u) return (~(garr[i1 & 7u] >> (((unsigned)c0 * i2) & 31u)) - (unsigned)((short)(unsigned)s0 > (signed char)0x7fffffffu));
            continue; (void)((unsigned)((short)fuel > (signed char)0x652169e4u));
        }
        break; (void)((unsigned)((short)r0.x > (signed char)((unsigned)f0 + 9u)));
        *q0 += (unsigned)((int)(unsigned)c1 >= (int)((unsigned)(w0 >> 29) + (unsigned)((int)p2 < (int)p0)));
        L1: if (--fuel == 0u) goto done;
        if (3u) continue;
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.x = (unsigned)(unsigned char)(unsigned)((int)p1 >= (int)(unsigned)s0);
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)h0) || u2), (unsigned)((short)0x10000u > (signed char)(unsigned)((unsigned)b0 && i2)), a0[u1 & 3u]); }
            if (u0) break;
            *q0 = (unsigned)((int)*mp < (int)(unsigned)e0);
        }
    }
    L2: if (--fuel == 0u) goto done;
    goto L0;
    w0 ^= (unsigned long long)(unsigned)s1 << (((i2 / (m0 | 1u)) >> (0x9d4a257eu & 31u)) & 63u);
    q0 = &garr[(unsigned)((short)i2 > (signed char)((m0 | p1) - (unsigned)((int)0x10000u < (int)v0))) & 7u];
    if ((unsigned)!(unsigned)((unsigned)(w0 >> 29) || (i1 + (unsigned)h1))) {
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)l0 >= (int)0xdd63247au), (unsigned)((unsigned)c1 && g1), 0x81e7d0d5u); }
    } else {
        x0 = x0 * 0x100000001b3ull + *q0;
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(x0 >> 70) ? (unsigned)d0 : r0.y), 7u, r0.x); }
        L3: if (--fuel == 0u) goto done;
        if ((0x80000000u + (unsigned)s0)) goto L2;
    } while (i0++ < 2u && (0x10000u & a0[u1 & 3u]));
    u2 += (unsigned)((int)(0u - (unsigned)d0) < (int)(unsigned)((int)(unsigned)c0 >= (int)(0x3ce0efa9u - m0)));
    if (budget != 0u) { budget -= 1u; u2 = fn0(a0[u1 & 3u], (unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)w0 == (unsigned)l0) || (unsigned)h1), 0xf9c9c6cu); }
    c1 = (signed char)(unsigned)((unsigned)w0 < (7u % (i1 | 1u)));
    if ((unsigned)l0) {
        if (budget != 0u) { budget -= 1u; u1 = fn0(p2, (unsigned)s0, (g0 * (3u | 6u))); }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)u2 >= (int)0xffffffffu), ((unsigned)d0 ? v0 : (unsigned)w0), 0x57ccfc3cu); }
            L4: if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((int)(unsigned)(x0 >> 70) < (int)0x34e49acbu) < (unsigned)((unsigned)c1 && 0x3d0ae4b0u)));
            if (budget != 0u) { budget -= 1u; u0 = fn0(-(unsigned)((short)(unsigned)d0 > (signed char)0xa438e400u), ((6u / ((unsigned)l0 | 1u)) | r0.x), 6u); }
        }
        d0 = d0 * 0.5 + (double)((((unsigned)e0 + i1) & (0x26475587u / ((4u - 0xd34fb325u) | 1u))) & 1023u);
        goto L4;
        *mp = (unsigned)((unsigned)(unsigned char)(unsigned)((short)0x14dd2275u > (signed char)p1) || ((unsigned)(p2 || (unsigned)s0) | m0));
    } else {
        w0 = w0 * 6364136223846793005ull + (((unsigned)((short)0xffffffffu > (signed char)0xffffffffu) ^ 0u) % ((unsigned)c1 | 1u));
    }
    *mp = ~(unsigned)((short)(garr[u2 & 7u] ^ (*q0 * u2)) > (signed char)(unsigned)h0);
    if (budget != 0u) { budget -= 1u; u2 = fn0(a0[u1 & 3u], ((a0[i0 & 3u] << (0xffffffffu & 31u)) - (unsigned)s1), (0x25610cb8u << (0x10000u & 31u))); }
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            g1 += i2;
            do { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    continue; (void)((u3 % ((unsigned)((short)a0[u1 & 3u] > (signed char)0x1a7b31cu) | 1u)));
                    if ((i0 >> (6u & 31u))) break;
                    break; (void)(0xe0961ef0u);
                }
                g0 = garr[i1 & 7u];
                c0 = (unsigned char)(6u + (unsigned)h0);
                *q0 += (p0 ^ (3u ^ ((unsigned)c0 ? u2 : m0)));
                l0 = (long)((unsigned long)l0 + ((i0 / (0xdf9a382bu | 1u)) / ((0x6de7aa93u + (unsigned)(signed char)(unsigned)((unsigned)s0 == 0xefa88263u)) | 1u)));
            } while (i2++ < 2u && 7u);
            break; (void)((a0[u1 & 3u] | u3));
            r0.y ^= (unsigned)(unsigned char)(unsigned)(m0 < *mp);
            if (((unsigned)((int)i1 >= (int)(unsigned)(w0 >> 29)) << (0x10000u & 31u))) {
                if (((unsigned)f0 / ((unsigned)(short)(unsigned)(0xf1f0a17du && r0.y) | 1u))) continue;
                q0 = &garr[(unsigned)((short)(*mp - (unsigned)f0) > (signed char)0x4bfb7c23u) & 7u];
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (0x80000000u % (8u | 1u)));
                    do { if (--fuel == 0u) goto done;
                        if (((unsigned)((short)*q0 > (signed char)0x10000u) + 0xd5d3a68fu)) continue;
                        while (i1++ < 3u && (*q0 >> (p2 & 31u))) { if (--fuel == 0u) goto done;
                            if (-(unsigned)(4u < (unsigned)c1)) break;
                        }
                        break; (void)((3u - (unsigned)x0));
                        r0.x = (unsigned)((p1 * ((unsigned)e0 & ((unsigned)w0 + (unsigned)c1))) < g1);
                    } while (i0++ < 4u && (unsigned)((int)0x8cc335d4u >= (int)(i2 * 0x7fffffffu)));
                    if ((i2 | (unsigned)e0)) goto L4;
                    m0 ^= (unsigned)((int)(unsigned)(short)(unsigned)(0x80000000u < 0xffffffffu) >= (int)p2);
                }
                w0 ^= (unsigned long long)2u << ((unsigned)(signed char)((unsigned)((unsigned)w0 && (fuel + p2)) >> (0x10000u & 31u)) & 63u);
                *q0 += ((0x16d7c850u * (unsigned)(signed char)(0x2ecc5116u % (i2 | 1u))) | (unsigned)(8u || (unsigned)c1));
            } else {
                m0 ^= 0x135ada8du;
                if (g0) break;
            }
        } while (i1++ < 6u && (unsigned)((g0 * (unsigned)w0) < a0[i0 & 3u]));
        if (u3 == 7u) return ((unsigned)w0 | r0.x);
        h1 = (unsigned short)(h1 + ((unsigned)((unsigned)w0 < r0.x) | ((unsigned)d0 & i1)));
        if ((unsigned)(*mp == 0u)) break;
    } while (i0++ < 2u && (unsigned)(u2 || garr[u2 & 7u]));
    { unsigned t0; double z0; if (((fuel << (*mp & 31u))) & 1u) { t0 = a0[i0 & 3u]; z0 = (double)((((unsigned)w0 & (unsigned)e0)) & 255u); } if (((fuel << (*mp & 31u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)e0) break;
            if ((unsigned)l0) continue;
            if ((garr[u2 & 7u] ^ (unsigned)h0)) break;
            g1 += (unsigned)(*q0 && ((unsigned)s1 | 0xffffffffu));
            if (((unsigned)x0 & (unsigned)(w0 >> 29))) {
                do { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)(signed char)((p1 >> ((unsigned)s0 & 31u)) % ((g1 * (unsigned)l0) | 1u));
                    do { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + (unsigned)((short)m0 > (signed char)((0u * u3) ^ 0xa009f6d4u));
                        a0[u2 & 3u] = (unsigned)((garr[i1 & 7u] + ~(0x10000u >> (*q0 & 31u))) && g1);
                    } while (i2++ < 4u && (unsigned)((unsigned)l0 == 0x80000000u));
                    if ((6u / (p1 | 1u))) break;
                } while (i1++ < 6u && m0);
                if ((m0 / ((unsigned)((short)u0 > (signed char)(unsigned)d0) | 1u))) break;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(8u, (unsigned)(w0 >> 29), (unsigned)!((*mp / (0xcfcde3deu | 1u)) - r0.x)); }
                    if ((unsigned)(0x80000000u == (unsigned)e0)) goto done;
                    if (*q0) break;
                    l0 = (long)((unsigned long)l0 + p1);
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0xaba8b2fau - g1), (unsigned)((int)(unsigned)d0 >= (int)u2), (0x225e64ebu << (2u & 31u))); }
                } while (i1++ < 5u && (unsigned)((int)(unsigned)h1 >= (int)(unsigned)(w0 >> 29)));
            } else {
                q0 = &garr[(unsigned)!(unsigned)(g0 && 3u) & 7u];
                if ((0xe27a99c9u >> (g1 & 31u))) {
                    u3 += (unsigned)f0;
                    if (0u) goto L2;
                } else {
                    f0 = f0 * 0.5f + (float)((i0 << ((unsigned)((int)((unsigned)f0 >> (0x4de3bfa0u & 31u)) >= (int)(unsigned)l0) & 31u)) & 255u);
                    c1 = (signed char)(unsigned)(((*q0 | (*q0 & (unsigned)s1)) >> (v0 & 31u)) == (unsigned)w0);
                }
            }
            if ((unsigned)(unsigned char)(unsigned)(0xffffffffu == (unsigned)l0)) goto L4;
        }
        if (a0[i0 & 3u]) goto L4;
    }
    if ((r0.y & r0.x)) goto L4;
    goto L2;
    goto L0;
    if ((unsigned)(*mp == (fuel + (unsigned)c0))) goto L2;
    a0[((unsigned)h0 & (unsigned)c1) & 3u] = ((*mp - u1) - (unsigned)(short)(0xffffffffu ^ (unsigned)((short)v0 > (signed char)u3)));
    d0 = d0 * 0.5 + (double)(garr[u2 & 7u] & 1023u);
    if (budget != 0u) { budget -= 1u; u3 = fn0((p0 & 0x5a108fdeu), 0x80000000u, ((unsigned)((short)(unsigned)h0 > (signed char)0x80000000u) ^ (unsigned)l0)); }
    x0 = x0 * 0x100000001b3ull + ((unsigned)(w0 >> 29) ? (unsigned)((int)6u < (int)u0) : (unsigned)w0);
    if ((~(u3 >> (u1 & 31u)) | (unsigned)w0)) {
        if (0x12ff0f41u) goto L1;
        goto L4;
        if (v0) goto L2;
        if ((unsigned)((short)p2 > (signed char)(unsigned)(p0 || 0x89d4a53du))) goto L3;
    } else {
        if (0xa3a39a50u) goto L1;
        u1 += (unsigned)((unsigned)h1 || (unsigned)b0);
    }
    if ((r0.y ? (unsigned)c1 : (unsigned)b0)) goto L2;
    u3 = 1u;
    if (budget != 0u) { budget -= 1u; u1 = fn0(garr[i1 & 7u], p0, (p0 + (unsigned)((int)u0 >= (int)garr[u2 & 7u]))); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if ((p2) & 1u) { t0 = (unsigned)(signed char)(a0[u1 & 3u] << ((0x7fffffffu & (unsigned)l0) & 31u)); z0 = (double)(((unsigned)((int)r0.x < (int)(*q0 + 0x7fffffffu))) & 255u); } if ((p2) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        *q0 += 5u;
    }
    goto L1;
    i0 = (p2 / (g1 | 1u)) & 15u;
    if ((unsigned)(0xcf159a49u && (p2 + g1))) {
        L0: if (--fuel == 0u) goto done;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((short)u2 > (signed char)0xffffffffu));
            if (fuel < 8u) return -(g1 << (((unsigned)(short)(0x80000000u << (g1 & 31u)) + r0.x) & 31u));
            w0 = w0 * 6364136223846793005ull + (9u / ((0xa71b3714u / ((unsigned)(i1 == garr[i1 & 7u]) | 1u)) | 1u));
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)2u < (int)a0[u1 & 3u]), 1u, 0x282106dbu); }
        }
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
            L2: if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(((unsigned)(9u && 3u) * (unsigned)(short)(unsigned)((unsigned)d0 == i0)) & 1023u);
            if (i1) {
                if ((0xc2982647u ^ (garr[u2 & 7u] >> (a0[i0 & 3u] & 31u)))) break;
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(x0 >> 70) / ((unsigned)(garr[u2 & 7u] < (unsigned)f0) | 1u)), (garr[i1 & 7u] & (unsigned)b0), garr[i1 & 7u]); }
                    v0 = ((unsigned)b0 << ((g0 & r0.y) & 31u));
                    u1 ^= (unsigned)((int)(unsigned)l0 < (int)(m0 ? p0 : (unsigned)c1));
                }
            } else {
                i1 = ((unsigned)h1 >> (0x7890ebf3u & 31u)) & 15u;
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    c1 = (signed char)(*mp % ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)(x0 >> 70)) | 1u));
                    if ((unsigned)h0) break;
                    break; (void)(((unsigned)((unsigned)b0 == (unsigned)e0) & (unsigned)e0));
                    if ((unsigned)((int)(unsigned)w0 >= (int)(unsigned)c0)) goto done;
                    L3: if (--fuel == 0u) goto done;
                    s0 = (int)(p0 << ((u3 | fuel) & 31u));
                }
                *mp = ((unsigned)d0 - ((unsigned)d0 * ~(u1 << ((unsigned)h0 & 31u))));
                *mp = (0x61ac688cu * v0);
            }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn1(0xa47cd513u, (*mp / (p1 | 1u)), (unsigned)((short)(unsigned)c1 > (signed char)(unsigned)(u2 && (unsigned)(w0 >> 29)))); }
        if ((unsigned)(a0[u1 & 3u] < (g1 * (unsigned)x0))) goto L0;
        while (i0++ < 4u && (unsigned)(fuel || (unsigned)d0)) { if (--fuel == 0u) goto done;
            if (u3 == 7u) return ((unsigned)(g0 < ((unsigned)l0 * 0x498b4924u)) << (8u & 31u));
            r0.y ^= (unsigned)(0x5a36459fu || (u2 + (7u & g0)));
        }
    } else {
        goto L3;
    }
    while (i0++ < 5u && (unsigned)c1) { if (--fuel == 0u) goto done;
        u1 = *mp;
        switch ((unsigned)((unsigned)x0 && (0x10000u - p1)) & 7u) {
            d0 = d0 * 0.5 + (double)((((unsigned)((int)(unsigned)c0 >= (int)(0xe073e159u * 0x10000u)) ^ garr[u2 & 7u]) / (8u | 1u)) & 1023u);
            while (i1++ < 3u && (unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(0x80000000u / (0xd6415b30u | 1u)) >= (int)(unsigned)h1), (7u | ((unsigned)s0 % (u2 | 1u))), i1); }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(v0 || (r0.x | 0x10000u)), (unsigned)(a0[u1 & 3u] || (unsigned)h1), (unsigned)(signed char)((unsigned)h1 ? garr[i1 & 7u] : 2u)); }
                if (budget != 0u) { budget -= 1u; u1 = fn1(0x7fffffffu, (unsigned)(x0 >> 70), 5u); }
                garr[(0x432135a7u | 2u) & 7u] = (unsigned)(short)((unsigned)e0 - (unsigned)((short)(garr[i1 & 7u] + ~(unsigned)((int)(unsigned)f0 >= (int)0x7fffffffu)) > (signed char)(unsigned)c1));
                if ((fuel | (fuel | g1))) continue;
                *q0 = (~((unsigned)(short)(fuel * 0x9d7660b7u) | 0x80000000u) - (unsigned)(p0 || *q0));
            }
            x0 = x0 * 0x100000001b3ull + (unsigned)!(unsigned)((int)a0[i0 & 3u] < (int)4u);
        }
        if (((unsigned)h0 * 0x80000000u)) {
            s0 = (int)(garr[i1 & 7u] >> ((unsigned)(u1 && 0x7fffffffu) & 31u));
        } else {
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                *mp = (5u | (8u & (unsigned)((unsigned)c1 || u0)));
                break; (void)(((unsigned)(0xffffffffu < 9u) & a0[u1 & 3u]));
            }
        }
        e0 = e0 * 0.5L + (long double)(((unsigned)c1 - 9u) & 1023u);
        if (fuel < 8u) return ((unsigned)((int)(unsigned)s0 >= (int)v0) * (g1 | p1));
        if ((unsigned)(((unsigned)e0 % (0x10000u | 1u)) || 0xd9845a48u)) break;
    }
    if ((((unsigned)x0 | 9u) >> (0x80000000u & 31u))) goto L0;
    do { if (--fuel == 0u) goto done;
        if ((p2 % ((unsigned)h0 | 1u))) break;
    } while (i0++ < 5u && g0);
    do { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (g1 ? (unsigned)w0 : i2));
        x0 = x0 * 0x100000001b3ull + (unsigned)d0;
    } while (i0++ < 2u && ((unsigned)w0 * p0));
    s0 = (int)(unsigned)((int)(unsigned)(p2 && fuel) < (int)(~((unsigned)s1 * 0x7fffffffu) / (*mp | 1u)));
    if (((unsigned)(5u == (unsigned)c1) & (unsigned)x0)) goto L1;
    if ((0x80000000u | 0x10000u)) goto L3;
    if ((unsigned)((int)((unsigned)s1 - (unsigned)h1) < (int)4u)) goto L4;
    switch ((unsigned)(signed char)(0x9d8ef7e5u << (u3 & 31u)) & 7u) {
        b0 = (unsigned)(v0 < fuel) != 0u;
    }
    garr[i2 & 7u] = (0x80000000u % ((r0.y & (unsigned)s0) | 1u));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        g1 += ((unsigned)c1 >> (v0 & 31u));
    }
    if (((unsigned)(garr[i1 & 7u] == garr[u2 & 7u]) - 3u)) goto L2;
    goto L1;
    u1 = u3;
    switch ((0xf4badbfcu - r0.x) & 7u) {
        *mp = (unsigned)(unsigned char)((2u << ((unsigned)s1 & 31u)) ? *mp : (unsigned)((int)i2 >= (int)a0[u1 & 3u]));
        case 0u: ;
        if ((p2 * 0x80000000u)) {
            case 2u: ;
            v0 = (unsigned)(0x7fffffffu && (unsigned)h0);
            u2 = (0x3727e171u ? 0x438a517eu : a0[i0 & 3u]);
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(g1 == 0xdb64515fu), (fuel + m0), (unsigned)(signed char)(0xdb7d318fu | (unsigned)c1)); }
            goto L3;
            case 3u: ;
        }
        *q0 += (1u >> ((unsigned)(x0 >> 70) & 31u));
    }
    while (i0++ < 2u && (unsigned)((int)(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(x0 >> 70)) >= (int)(unsigned)l0)) { if (--fuel == 0u) goto done;
        if ((0x5d9e7c09u << ((unsigned)e0 & 31u))) {
            v0 = ((unsigned)(unsigned char)(unsigned)(i2 || -(unsigned)((int)u0 < (int)0x9b1fbf1u)) * (unsigned)(x0 >> 70));
            if ((7u - (unsigned)b0)) break;
            if ((m0 & 0x10000u)) break;
            w0 ^= (unsigned long long)(unsigned)((int)3u < (int)m0) << ((unsigned)(unsigned char)(unsigned)((short)7u > (signed char)0xffffffffu) & 63u);
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)(signed char)((unsigned)e0 >> ((unsigned)l0 & 31u)) < m0), -(unsigned)((int)0x80000000u < (int)g1), ((unsigned)(short)(unsigned)((int)(unsigned)s0 >= (int)(unsigned)(x0 >> 70)) ^ r0.y)); }
            u3 = (unsigned)s1;
        }
        i0 = (0xb34564c5u / ((unsigned)((short)(unsigned)(~(1u - 0x80000000u) || fuel) > (signed char)0xf2443bd4u) | 1u)) & 15u;
        while (i1++ < 2u && ((fuel << (u0 & 31u)) / (fuel | 1u))) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)s1 || v0);
            if ((unsigned)(short)(a0[i0 & 3u] - (unsigned)s0)) break;
        }
        if (fuel < 8u) return ((unsigned)f0 ^ (0x10000u % (0xe43413bcu | 1u)));
    }
    { unsigned t1; double z1; if (((unsigned)(signed char)((unsigned)c0 / (i2 | 1u))) & 1u) { t1 = 0xffffffffu; z1 = (double)(((unsigned)(short)((unsigned)w0 ^ 0x10000u)) & 255u); } if (((unsigned)(signed char)((unsigned)c0 / (i2 | 1u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        { unsigned t2; double z2; if ((0x10000u) & 1u) { t2 = (unsigned)!(unsigned)((int)((unsigned)l0 - 6u) >= (int)2u); z2 = (double)(((unsigned)((short)i0 > (signed char)(unsigned)((unsigned)(w0 >> 29) == 0xe57c9b19u))) & 255u); } if ((0x10000u) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            a0[u2 & 3u] = (unsigned)!((unsigned)h0 / (0x5d74578au | 1u));
            goto done;
        }
        while (i0++ < 6u && (unsigned)(short)((unsigned)(x0 >> 70) ^ ((unsigned)b0 ^ 5u))) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(-(unsigned)(((unsigned)h0 >> (4u & 31u)) && ((unsigned)h0 + 0x80000000u)) & 1023u);
            switch ((p1 / (i0 | 1u)) & 7u) {
                switch (p2 & 7u) {
                    r0.y ^= (p2 ? (unsigned)h0 : (unsigned)(w0 >> 29));
                    s1 = (int)((unsigned)s1 + ((unsigned)((7u / (v0 | 1u)) && 0x80000000u) >> ((unsigned)b0 & 31u)));
                    if (*q0) goto L3;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((a0[i0 & 3u] % (((unsigned)h0 & *q0) | 1u)), 0x640523ffu, (unsigned)(signed char)(5u << ((unsigned)(w0 >> 29) & 31u))); }
                    if ((garr[u2 & 7u] ^ (unsigned)(p0 && (unsigned)(w0 >> 29)))) continue;
                }
                case 7u: ;
                goto done;
                goto L1;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)((unsigned)h1 < garr[u2 & 7u]) == a0[i0 & 3u]), ((r0.y + 0x10000u) >> (i1 & 31u)), (a0[u1 & 3u] / (0x333bb2cbu | 1u))); }
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)x0 / ((unsigned)((int)garr[u2 & 7u] < (int)garr[i1 & 7u]) | 1u)), ((unsigned)h0 + 4u), r0.y); }
            u1 = u1 * 0x9e3779b1u + 0x9d879021u;
        }
    }
    if (garr[i1 & 7u]) goto L1;
    *q0 += ((0u | (*mp & i1)) - 0u);
    if ((unsigned)((short)(unsigned)(g1 == 0x1f53d89du) > (signed char)0x877f82dbu)) goto L4;
    x0 = x0 * 0x100000001b3ull + (5u - (unsigned)(x0 >> 70));
    s0 = (int)(i1 % ((unsigned)(signed char)(0x446f4b0du * (unsigned)(x0 >> 70)) | 1u));
    goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)i0 >= (int)(u1 % (u1 | 1u))), p2, (unsigned)((int)((unsigned)s1 / (i1 | 1u)) >= (int)2u)); }
    if (v0) goto L4;
    while (i0++ < 7u && (unsigned)w0) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + 2u);
        v0 = (unsigned)s1;
        if ((unsigned)h1) break;
        continue; (void)((0xffffffffu >> ((unsigned)!((unsigned)c1 - i0) & 31u)));
        g1 += ((unsigned)((int)(unsigned)b0 < (int)(unsigned)h1) ? v0 : (unsigned)e0);
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(((unsigned)s0 - u1) < (unsigned)s1), (0x10000u << ((unsigned)(p2 < i1) & 31u)), ((unsigned)d0 * (unsigned)(x0 >> 70))); }
    }
    do { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (unsigned)b0;
        r0.y ^= i0;
        if (budget != 0u) { budget -= 1u; u0 = fn1(a0[u1 & 3u], m0, 0x4931441cu); }
        break; (void)(((unsigned)(unsigned char)(unsigned)((int)g0 < (int)(unsigned)s1) << (0xcd600f00u & 31u)));
        e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)(u0 / ((unsigned)w0 | 1u)) & 1023u);
    } while (i0++ < 5u && ((unsigned)w0 >> ((p2 - i1) & 31u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        { unsigned t0; double z0; if (((0x46e13a6u % ((unsigned)l0 | 1u))) & 1u) { t0 = 0x80000000u; z0 = (double)(((i1 / (r0.x | 1u))) & 255u); } if (((0x46e13a6u % ((unsigned)l0 | 1u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            L1: if (--fuel == 0u) goto done;
            switch ((unsigned)((int)p2 >= (int)p2) & 7u) {
                if (budget != 0u) { budget -= 1u; u0 = fn2(m0, garr[i1 & 7u], (unsigned)e0); }
                w0 ^= (unsigned long long)(0xe53da034u - u3) << (p0 & 63u);
            }
            while (i1++ < 2u && (unsigned)((unsigned)(0x7fffffffu || p2) < (unsigned)b0)) { if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if ((7u) & 1u) { t1 = ((unsigned)s0 ^ ((unsigned)h1 >> (a0[u1 & 3u] & 31u))); z1 = (double)(((u2 | 0x80000000u)) & 255u); } if ((7u) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    w0 ^= (unsigned long long)a0[i0 & 3u] << ((u3 << ((unsigned)(i0 < a0[u1 & 3u]) & 31u)) & 63u);
                    i2 = i1 & 15u;
                    if (g0) goto L0;
                }
                if (g1) break;
                while (i2++ < 3u && ((unsigned)f0 * u3)) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn2((8u - (unsigned)h0), ((unsigned)h1 ? (unsigned)d0 : u3), 0x80000000u); }
                    if (0xf975452u) break;
                }
            }
            if (budget != 0u) { budget -= 1u; u3 = fn1((u2 % ((unsigned)w0 | 1u)), (unsigned)(garr[i1 & 7u] == (unsigned)h1), (a0[i0 & 3u] % (5u | 1u))); }
            for (;;) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + r0.y);
            }
            switch ((0x80000000u - 1u) & 7u) {
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)(unsigned)(signed char)((unsigned)c1 & 0xd4cc9419u) > (signed char)0x6f9b0b7fu)) break;
                }
            }
        }
        b0 = (unsigned)s0 != 0u;
        garr[r0.y & 7u] = (unsigned)((int)i0 >= (int)(unsigned)((short)(unsigned)(signed char)(0xffffffffu % ((unsigned)l0 | 1u)) > (signed char)p0));
        { unsigned t2; double z2; if ((0x6a3b8660u) & 1u) { t2 = ((unsigned)(g0 || i0) >> (g0 & 31u)); z2 = (double)(((unsigned)(unsigned char)(r0.y & (unsigned)(m0 < p0))) & 255u); } if ((0x6a3b8660u) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            if (budget != 0u) { budget -= 1u; u1 = fn1((i1 << ((unsigned)(0x80000000u && (unsigned)e0) & 31u)), (unsigned)((unsigned)((int)*q0 < (int)0x9396128cu) || 3u), (unsigned)((int)i2 < (int)((unsigned)s0 + 0xc6cbc607u))); }
            while (i1++ < 3u && 0x6e8915b6u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if (((unsigned)h1 ^ (unsigned)((int)(unsigned)f0 >= (int)0x10000u))) break;
                    switch ((unsigned)(unsigned char)(fuel % (0x7fffffffu | 1u)) & 7u) {
                        c1 = (signed char)(unsigned)c1;
                        goto done;
                    }
                    a0[(unsigned)(short)(unsigned)(p1 || i0) & 3u] = (0x2c1af068u % ((unsigned)((int)7u >= (int)(p1 % (garr[i1 & 7u] | 1u))) | 1u));
                    a0[i2 & 3u] = (unsigned)s1;
                } while (i2++ < 3u && (unsigned)(m0 < garr[u2 & 7u]));
                if (0x80000000u) goto L3;
                g1 += (unsigned)((unsigned)s1 == (unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)((int)u0 >= (int)(0x64803028u >> ((unsigned)(w0 >> 29) & 31u)))));
                d0 = d0 * 0.5 + (double)(~((unsigned)f0 + garr[u2 & 7u]) & 1023u);
                L2: if (--fuel == 0u) goto done;
                if (u3 == 7u) return ((u3 % (0xffffffffu | 1u)) * garr[u2 & 7u]);
            }
            if ((garr[i1 & 7u] % (0x391121b0u | 1u))) continue;
            d0 = d0 * 0.5 + (double)(2u & 1023u);
            if (a0[i0 & 3u]) goto L1;
        }
        e0 = e0 * 0.5L + (long double)(((unsigned)(unsigned char)(1u ^ v0) ^ (i2 % ((unsigned)c0 | 1u))) & 1023u);
    }
    garr[(unsigned)c1 & 7u] = (0x6bdc5c30u / (r0.x | 1u));
    if (((unsigned)(x0 >> 70) / ((unsigned)d0 | 1u))) goto L0;
    L3: if (--fuel == 0u) goto done;
    if (u0) {
        goto L3;
        *q0 = ((unsigned)d0 * u1);
        u0 = u0 * 0x9e3779b1u + (garr[i1 & 7u] * p1);
        switch (u0 & 7u) {
            goto L4;
            f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)e0 / ((p0 << (a0[u1 & 3u] & 31u)) | 1u)) == (unsigned)s0) & 255u);
            case 4u: ;
            u1 += ((unsigned)(x0 >> 70) & (unsigned)e0);
        }
    } else {
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(short)(0u / (p1 | 1u)), ((unsigned)f0 * u1), (0xe660a3cbu % ((unsigned)((short)garr[i1 & 7u] > (signed char)garr[i1 & 7u]) | 1u))); }
        *mp = ((unsigned)((int)3u >= (int)(unsigned)h1) ? u0 : i2);
        goto done;
        u1 = u1 * 0x9e3779b1u + ((((unsigned)((int)0x80000000u < (int)a0[i0 & 3u]) - r0.x) % (0x20b4edbdu | 1u)) - (unsigned)b0);
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)x0) continue;
        s0 = (int)(u1 & (unsigned)x0);
        if ((unsigned)b0) continue;
        L4: if (--fuel == 0u) goto done;
    }
    l0 = (long)((unsigned long)l0 + ((unsigned)h1 | -(unsigned)(i1 || 0x10000u)));
    *q0 += (unsigned)((unsigned)((int)(unsigned)b0 < (int)fuel) && (unsigned)(unsigned char)(0x7fffffffu - 0x10000u));
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)d0, (0x65d6c22bu >> (*q0 & 31u)), ((unsigned)(fuel < i0) ^ 0x80000000u)); }
    switch (-((unsigned)((int)(unsigned)c0 >= (int)r0.x) * 0x5b88e951u) & 7u) {
        d0 = d0 * 0.5 + (double)(((unsigned)((int)(unsigned)((int)(unsigned)x0 >= (int)8u) >= (int)(unsigned)c1) >> (i1 & 31u)) & 1023u);
        if (~((unsigned)l0 ^ ((unsigned)f0 % ((unsigned)s1 | 1u)))) goto L1;
        f0 = f0 * 0.5f + (float)(((i2 & a0[u1 & 3u]) << ((unsigned)((unsigned)c0 || ((unsigned)(w0 >> 29) * (unsigned)c1)) & 31u)) & 255u);
        if (i0) goto done;
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 5u && u2) { if (--fuel == 0u) goto done;
                while (i2++ < 3u && ~((unsigned)s1 % ((unsigned)d0 | 1u))) { if (--fuel == 0u) goto done;
                    goto L0;
                    { unsigned t3; double z3; if ((r0.x) & 1u) { t3 = (unsigned)((int)(p1 + (unsigned)(w0 >> 29)) < (int)(unsigned)s1); z3 = (double)((0x8a89a97du) & 255u); } if ((r0.x) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                        switch (u1 & 7u) {
                            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)b0 % ((unsigned)(a0[i0 & 3u] && r0.x) | 1u)), u2, (unsigned)!((unsigned)h1 | (unsigned)h1)); }
                            w0 ^= (unsigned long long)((unsigned)(x0 >> 70) / (4u | 1u)) << (g0 & 63u);
                            e0 = e0 * 0.5L + (long double)(((unsigned)(((unsigned)f0 >> (0x80000000u & 31u)) || (unsigned)(u3 || 0x80000000u)) << (5u & 31u)) & 1023u);
                        }
                        goto L0;
                        if (budget != 0u) { budget -= 1u; u3 = fn2((g0 >> (i2 & 31u)), (garr[u2 & 7u] - i2), (unsigned)s0); }
                        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)f0, (unsigned)(g0 < 0x10000u), ((unsigned)e0 - i2)); }
                        continue; (void)(((unsigned)f0 & 6u));
                        w0 ^= (unsigned long long)(*mp % (p2 | 1u)) << ((a0[u1 & 3u] ^ ((unsigned)((int)0x10000u < (int)u1) % ((unsigned)(unsigned char)(5u << ((unsigned)l0 & 31u)) | 1u))) & 63u);
                    }
                    l0 = (long)((unsigned long)l0 + ((0x7fffffffu % (7u | 1u)) * (unsigned)((int)u1 >= (int)(unsigned)c1)));
                    { unsigned t4; double z4; if ((((unsigned)l0 % ((*mp / ((unsigned)l0 | 1u)) | 1u))) & 1u) { t4 = (unsigned)(w0 >> 29); z4 = (double)((~(unsigned)(i2 == 7u)) & 255u); } if ((((unsigned)l0 % ((*mp / ((unsigned)l0 | 1u)) | 1u))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                        g1 += ((fuel * garr[i1 & 7u]) + a0[u1 & 3u]);
                    }
                    if (0xdd83556au) goto L0;
                    *q0 = (unsigned)(fuel == i0);
                }
                v0 = (unsigned)(unsigned char)(unsigned)((unsigned)((short)5u > (signed char)(unsigned)w0) || (unsigned)h0);
                continue; (void)((unsigned)(unsigned char)(m0 >> ((unsigned)c1 & 31u)));
                if (((unsigned)s1 - u2)) {
                    u1 = (unsigned)((short)v0 > (signed char)0x3b046ed5u);
                }
            }
            { unsigned t5; double z5; if (((unsigned)(0xffffffffu && *mp)) & 1u) { t5 = 0x72139896u; z5 = (double)(((unsigned)(i2 || ~(fuel % (v0 | 1u)))) & 255u); } if (((unsigned)(0xffffffffu && *mp)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                { unsigned t6; double z6; if ((((unsigned)(r0.x && (unsigned)h0) | 0x7fffffffu)) & 1u) { t6 = (unsigned)((int)g0 >= (int)(unsigned)((short)4u > (signed char)0x80000000u)); z6 = (double)(((unsigned)((unsigned)(0x6a86578cu || i1) < v0)) & 255u); } if ((((unsigned)(r0.x && (unsigned)h0) | 0x7fffffffu)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                    switch ((unsigned)((unsigned)l0 || *q0) & 7u) {
                        if ((unsigned)(x0 >> 70)) break;
                        case 7u: ;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(signed char)(unsigned)((int)(unsigned)h1 >= (int)((unsigned)x0 >> (v0 & 31u))), *mp, g0); }
                        r0.x = (i1 % (2u | 1u));
                        if (budget != 0u) { budget -= 1u; u2 = fn2(g0, 8u, 1u); }
                    }
                    r0.x = (unsigned)((4u | *mp) && a0[u1 & 3u]);
                    garr[a0[i0 & 3u] & 7u] = 2u;
                    case 6u: ;
                    s1 = (int)((unsigned)s1 + (-((unsigned)((int)0x75a51ceu < (int)(unsigned)l0) | 0xdf0c37aau) & 0x1bc58c9eu));
                }
                case 7u: ;
                r0.x = ((unsigned)((short)u1 > (signed char)(unsigned)h1) & (garr[i1 & 7u] >> ((unsigned)(signed char)((unsigned)l0 / ((unsigned)s0 | 1u)) & 31u)));
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)s1 + 3u)) continue;
                    m0 ^= (unsigned)((int)i2 >= (int)(0x7fffffffu * (0x10000u >> (0x10000u & 31u))));
                    if ((unsigned)(((unsigned)h1 << ((unsigned)l0 & 31u)) < 0x80000000u)) goto L0;
                    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)(w0 >> 29) + (unsigned)((int)a0[u1 & 3u] >= (int)garr[i1 & 7u])), (unsigned)s1, (u0 >> ((unsigned)w0 & 31u))); }
                    garr[r0.y & 7u] = ((fuel >> ((unsigned)((int)(unsigned)w0 >= (int)(unsigned)((unsigned)l0 == (unsigned)h1)) & 31u)) + p1);
                    h1 = (unsigned short)(h1 + (unsigned)(1u == (unsigned)((int)(unsigned)d0 >= (int)(unsigned)c1)));
                }
                while (i1++ < 7u && (unsigned)b0) { if (--fuel == 0u) goto done;
                    m0 ^= (r0.y % (((u0 * 4u) - (unsigned)c1) | 1u));
                    if ((unsigned)l0) {
                        g0 = (0x76ecba4fu & (unsigned)h0);
                        *q0 = ((unsigned)(9u && 4u) / ((unsigned)(r0.y || (unsigned)s1) | 1u));
                        case 5u: ;
                        u1 += (i1 | 0x8c664edbu);
                        s0 = (int)-(unsigned)((unsigned)(3u || (unsigned)f0) == (unsigned)e0);
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)s1 < (int)((unsigned)x0 >> ((unsigned)l0 & 31u))), (unsigned)!(unsigned)((unsigned)h1 || p2), i0); }
                    }
                }
                if (0x253dc0b2u) break;
            }
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((a0[i0 & 3u] >> ((unsigned)(unsigned char)(unsigned)((short)0x7d5dc0f2u > (signed char)(unsigned)l0) & 31u)), (unsigned)((int)(unsigned)h0 >= (int)(unsigned)c1), (unsigned)((u1 << (u3 & 31u)) < *q0)); }
                u3 ^= (((unsigned)(x0 >> 70) ^ 8u) ^ (unsigned)s0);
                r0.x = ((unsigned)((short)u3 > (signed char)3u) / ((unsigned)((int)u0 < (int)a0[i0 & 3u]) | 1u));
            }
            continue; (void)(((unsigned)l0 >> ((unsigned)h0 & 31u)));
            default: ;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn2((7u % ((unsigned)c1 | 1u)), u2, (a0[u1 & 3u] << ((unsigned)c1 & 31u))); }
            }
        }
        w0 ^= (unsigned long long)p1 << (i2 & 63u);
    }
    if (garr[i1 & 7u]) goto L3;
    if (0x80000000u) goto L4;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 = (0x80000000u % ((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)s1) | 1u));
        c1 = (signed char)((unsigned)c1 | (unsigned)h0);
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)b0, (i0 % ((unsigned)((unsigned)h1 || g1) | 1u)), (unsigned)(3u < (unsigned)b0)); }
        m0 ^= (5u - g1);
    }
    if (g0) {
        if (((m0 * 0x7c4277c1u) << ((unsigned)d0 & 31u))) goto L3;
        while (i0++ < 5u && a0[u1 & 3u]) { if (--fuel == 0u) goto done;
            continue; (void)(*q0);
            u1 += (unsigned)(signed char)(p2 >> ((unsigned)b0 & 31u));
            switch ((unsigned)(0x9035edefu == u0) & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn2((~(garr[i1 & 7u] / (*q0 | 1u)) - (unsigned)c0), ((unsigned)w0 ^ garr[i1 & 7u]), ((unsigned)(i1 || i0) ^ 0x10000u)); }
            }
            if (0x6d82ff41u) break;
            if (budget != 0u) { budget -= 1u; u1 = fn1((0x35e919c6u * (0x10000u >> (0x8925201bu & 31u))), ((unsigned)c1 + 0x10000u), (unsigned)((int)0xe8073e0u < (int)(fuel - u0))); }
        }
        switch ((unsigned)h0 & 7u) {
            d0 = d0 * 0.5 + (double)((4u % (-((unsigned)((unsigned)c0 < 6u) << ((unsigned)(signed char)(unsigned)(u0 && garr[i1 & 7u]) & 31u)) | 1u)) & 1023u);
        }
        g1 += i0;
    } else {
        r0.y ^= (unsigned)((7u & (unsigned)c0) && (i1 ? r0.x : 2u));
        if (budget != 0u) { budget -= 1u; u1 = fn1((0x80000000u ? 4u : (unsigned)(x0 >> 70)), ((unsigned)d0 - 6u), (unsigned)(short)(unsigned)((int)u3 >= (int)0xffffffffu)); }
        if ((unsigned)((int)(unsigned)((int)0xdeff731du >= (int)0xbe5d576u) < (int)0xc114bd0cu)) goto done;
        if (~((unsigned)c1 & (unsigned)d0)) goto L4;
    }
    c1 = (signed char)~(i1 ? (0x10000u ? p1 : *q0) : (unsigned)b0);
    g0 = ((unsigned)(0x80000000u && 0xf83d4a75u) + m0);
    c1 = (signed char)(v0 & a0[i0 & 3u]);
    if ((unsigned)((int)7u >= (int)(unsigned)(w0 >> 29))) goto done;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)c1) break;
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= (unsigned)((int)0xffffffffu >= (int)0x7fffffffu);
                u3 ^= ((unsigned)((int)v0 >= (int)fuel) & (unsigned)!(garr[i1 & 7u] / (~(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)v0) | 1u)));
                while (i0++ < 5u && 3u) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (*mp & ((0x7f1becdbu & (unsigned)(u3 < (unsigned)e0)) * garr[i1 & 7u]));
                    *q0 += (0x153042f2u ^ (unsigned)f0);
                    w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)((short)g0 > (signed char)p0) > (signed char)(unsigned)(unsigned char)(unsigned)((short)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)v0) > (signed char)(unsigned)d0));
                    if (g1) continue;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)(1u + i2), (unsigned)f0, (unsigned)(-(0x7fffffffu >> (*q0 & 31u)) && i0)); }
            }
            if ((unsigned)(v0 < i2)) continue;
            c0 = (unsigned char)((unsigned)(unsigned char)(0xee8da46au - i2) ^ garr[u2 & 7u]);
        }
        if ((unsigned)w0) continue;
        b0 = (unsigned)((short)u3 > (signed char)(unsigned)(signed char)((unsigned)(x0 >> 70) ? (unsigned)(0xffffffffu == (unsigned)c1) : (unsigned)(w0 >> 29))) != 0u;
        q0 = &garr[(unsigned)((unsigned)(0x80000000u || (unsigned)s1) < (unsigned)((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0x8b93da18u) || 0x12e436f6u)) & 7u];
    } while (i0++ < 2u && ((unsigned)((short)i0 > (signed char)u2) << (i1 & 31u)));
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)s1) goto L1;
        if ((1u * -(unsigned)(p1 < g1))) break;
    }
    switch ((unsigned)(short)(unsigned)((unsigned)((unsigned)(x0 >> 70) || i2) < garr[u2 & 7u]) & 7u) {
        if ((~(unsigned)(m0 < (unsigned)d0) % (garr[u2 & 7u] | 1u))) {
            if ((unsigned)((i0 >> (0x8f335f6cu & 31u)) || i2)) {
                case 2u: ;
                c1 = (signed char)(unsigned)(short)(unsigned)((unsigned)(w0 >> 29) && *mp);
                if ((unsigned)(1u || (unsigned)e0)) break;
                if ((0u + (unsigned)e0)) {
                    if (6u) goto L1;
                    r0.x = (garr[i1 & 7u] * (unsigned)d0);
                    h0 = (short)(unsigned)(r0.x && (unsigned)((short)(((unsigned)l0 - (unsigned)c1) + 9u) > (signed char)(unsigned)(w0 >> 29)));
                    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)h0, (unsigned)(m0 == 0x4d5179c3u), (unsigned)((short)(u2 << ((unsigned)c0 & 31u)) > (signed char)4u)); }
                    i1 = (unsigned)h1 & 15u;
                    if (r0.y) goto L3;
                }
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    while (i1++ < 5u && 0x294895aeu) { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)((unsigned)(short)((unsigned)(w0 >> 29) ? (unsigned)(signed char)((unsigned)(0x9cd629d5u || 0x10000u) / (a0[i0 & 3u] | 1u)) : a0[i0 & 3u]) & 1023u);
                        case 6u: ;
                    }
                    do { if (--fuel == 0u) goto done;
                        case 0u: ;
                    } while (i1++ < 3u && ((r0.y - u2) + (unsigned)c1));
                    s0 = (int)(unsigned)!((unsigned)s0 - (unsigned)((unsigned)((int)a0[i0 & 3u] < (int)u1) && (unsigned)b0));
                    if (budget != 0u) { budget -= 1u; u1 = fn0(*q0, i0, -(unsigned)(*q0 && g1)); }
                    x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)c0 == 6u) / ((unsigned)((short)0x7fffffffu > (signed char)p2) | 1u));
                }
                case 7u: ;
            } else {
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(0x7fffffffu == fuel) || (unsigned)(u3 || u2)) & 255u);
                u3 ^= (unsigned)((int)garr[i1 & 7u] < (int)0u);
            }
        }
        if ((garr[u2 & 7u] / ((unsigned)((int)6u < (int)(unsigned)h0) | 1u))) break;
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((unsigned)(x0 >> 70) < (unsigned)(x0 >> 70)), r0.y, ((0x7fffffffu % (4u | 1u)) % ((unsigned)l0 | 1u))); }
        if ((unsigned)((int)(6u / (i0 | 1u)) < (int)1u)) break;
        w0 ^= (unsigned long long)((unsigned)e0 % ((unsigned)d0 | 1u)) << (((unsigned)(w0 >> 29) % ((unsigned)(p1 < (garr[i1 & 7u] << (p2 & 31u))) | 1u)) & 63u);
        u0 = u0 * 0x9e3779b1u + u0;
    }
    v0 = ((unsigned)((int)fuel < (int)(unsigned)(w0 >> 29)) ^ r0.y);
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)0x7fffffffu >= (int)(0xffffffffu / (0xf8924d82u | 1u))), (i1 << ((unsigned)(signed char)((unsigned)f0 % ((unsigned)d0 | 1u)) & 31u)), ~(2u * (unsigned)(x0 >> 70))); }
            q0 = &garr[(~(unsigned)(6u == (unsigned)e0) / (~(unsigned)((int)(unsigned)s0 >= (int)(unsigned)(u0 || (unsigned)w0)) | 1u)) & 7u];
            if ((8u >> ((unsigned)(0x80000000u && g1) & 31u))) {
                r0.y ^= 0x30913055u;
                if ((unsigned)(g0 == (unsigned)(w0 >> 29))) break;
                w0 ^= (unsigned long long)p1 << ((0x7fffffffu | 0xffffffffu) & 63u);
                if (budget != 0u) { budget -= 1u; u2 = fn2((u3 & (unsigned)(g1 && 3u)), v0, (unsigned)((unsigned)x0 || (unsigned)e0)); }
                c0 = (unsigned char)0xcba52a31u;
            }
            while (i2++ < 3u && (unsigned)((unsigned)(u3 < p2) == 0xe32eb7c4u)) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + -((unsigned)b0 ? (unsigned)c0 : 0xd0a68694u);
                u0 ^= (0x61277064u - ((unsigned)e0 & 4u));
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)(u3 && 0xdcf20f63u) < u1)) {
                        if (budget != 0u) { budget -= 1u; u2 = fn0(p1, ((unsigned)(0x7fffffffu == (unsigned)l0) & r0.x), (i0 | (unsigned)(*q0 || *q0))); }
                    } else {
                        break; (void)(((unsigned)(i2 || (unsigned)d0) * (unsigned)w0));
                        if (budget != 0u) { budget -= 1u; u2 = fn0(0x7fffffffu, p1, 0x5363d4f3u); }
                    }
                    if ((unsigned)(signed char)(unsigned)((int)g0 >= (int)(unsigned)(short)(p1 % (g1 | 1u)))) break;
                    if ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)u1)) break;
                    if (0xf3654055u) break;
                    if ((unsigned)((unsigned)f0 == (g0 + (unsigned)s1))) break;
                    if (0x7fffffffu) break;
                }
                if (u2) {
                    if ((unsigned)(3u < (unsigned)(4u || 0x7de93f1eu))) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)a0[u1 & 3u] >= (int)m0), -((unsigned)c0 ^ p1), garr[i1 & 7u]); }
                    if (((unsigned)h1 - m0)) break;
                    a0[(unsigned)(0u == p2) & 3u] = (i1 ? (unsigned)h1 : 0x10000u);
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)((9u & i1) || r0.x) && p2));
                }
            }
            d0 = d0 * 0.5 + (double)(((unsigned)e0 - (0x4e5d58f2u << (0xd168f6bdu & 31u))) & 1023u);
        }
        garr[(unsigned)((int)0u < (int)0x10000u) & 7u] = r0.x;
        *q0 = *mp;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)(0xda63900bu | 0xd49f0e1u) > (signed char)7u)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0xd926be93u == (unsigned)!(0x80000000u + 5u)), (unsigned)x0, ((unsigned)(w0 >> 29) - 9u)); }
                c0 = (unsigned char)((((garr[i1 & 7u] ^ 0x80000000u) << (0x7fffffffu & 31u)) - 7u) << (p2 & 31u));
                *q0 += (unsigned)((unsigned)((unsigned)(unsigned char)((unsigned)s1 - (unsigned)e0) && garr[i1 & 7u]) < ((unsigned)x0 & 5u));
                if (budget != 0u) { budget -= 1u; u3 = fn2(2u, (unsigned)c1, ((unsigned)s0 * (0x80000000u << ((unsigned)(w0 >> 29) & 31u)))); }
            }
        }
        switch ((unsigned)(u3 || (unsigned)s1) & 7u) {
            continue; (void)(((unsigned)f0 | (0xb052bfe1u << ((unsigned)(x0 >> 70) & 31u))));
            u0 ^= (u2 % (u2 | 1u));
        }
    } while (i0++ < 5u && (0x80000000u % ((unsigned)b0 | 1u)));
    if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)s0 & (unsigned)w0), a0[u1 & 3u], ((unsigned)(w0 >> 29) / ((garr[i1 & 7u] % ((unsigned)s1 | 1u)) | 1u))); }
    if ((unsigned)((unsigned)d0 && g0)) goto done;
    if ((unsigned)((int)p0 >= (int)0u)) goto done;
    if ((unsigned)!(garr[u2 & 7u] << (-(0xf057e4u << (fuel & 31u)) & 31u))) goto L0;
    goto L0;
    if (a0[i0 & 3u]) goto L2;
    r0.x = (unsigned)(9u == (unsigned)w0);
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn2(p1, (unsigned)c1, 0x10000u); }
        }
        m0 ^= (unsigned)((unsigned)l0 && (i2 | (unsigned)c1));
        if (budget != 0u) { budget -= 1u; u0 = fn2((r0.x / ((unsigned)c0 | 1u)), ((unsigned)w0 * (unsigned)c0), ((unsigned)c1 | 0x45c06d18u)); }
        if ((garr[i1 & 7u] & (unsigned)l0)) break;
        if (((unsigned)((unsigned)w0 || g0) | 2u)) break;
        if (((unsigned)(x0 >> 70) % ((unsigned)c0 | 1u))) {
            while (i1++ < 7u && (unsigned)(garr[u2 & 7u] < p1)) { if (--fuel == 0u) goto done;
                if ((p0 - 9u)) break;
                c1 = (signed char)g0;
                w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)((-((unsigned)h1 % (v0 | 1u)) % (0u | 1u)) / (a0[u1 & 3u] | 1u));
                b0 = (unsigned)(((7u - (unsigned)e0) * u0) < (unsigned)(signed char)(*mp | i1)) != 0u;
            }
            if ((unsigned)((int)u2 >= (int)garr[i1 & 7u])) {
                u2 += (m0 * (3u << ((0x7fffffffu / ((0x779ee28au - (unsigned)(w0 >> 29)) | 1u)) & 31u)));
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)(signed char)(unsigned)((unsigned)f0 == (unsigned)x0) == 0x7fffffffu), 0x88244a09u, (0x86406b38u * 0x54e6e9c6u)); }
                if (-((unsigned)w0 / (((unsigned)s0 % (0x80000000u | 1u)) | 1u))) goto L3;
            } else {
                if ((i1 % ((0u & p1) | 1u))) {
                    g0 = ((unsigned)((unsigned)(x0 >> 70) && *mp) << (((unsigned)(8u || u2) | u1) & 31u));
                    m0 ^= (unsigned)((unsigned)h1 || (unsigned)(short)(unsigned)((int)(unsigned)(unsigned char)(unsigned)(u2 == g0) >= (int)0xe60a52c7u));
                    v0 = (unsigned)s0;
                    w0 = w0 * 6364136223846793005ull + (u3 ? 8u : (unsigned)((int)(g0 + (unsigned)d0) >= (int)u2));
                } else {
                    if ((a0[i0 & 3u] ^ -(unsigned)((short)(unsigned)w0 > (signed char)0x7fffffffu))) goto L2;
                    a0[fuel & 3u] = ((unsigned)c0 | 6u);
                }
                if (((unsigned)c1 << (p2 & 31u))) break;
            }
            while ((u3 | p0)) { if (--fuel == 0u) goto done;
                q0 = &garr[(a0[u1 & 3u] - ((unsigned)(signed char)(unsigned)((int)(unsigned)f0 >= (int)0x4cc05a74u) % (0x63e4f256u | 1u))) & 7u];
            }
            if (((a0[i0 & 3u] & (unsigned)s0) % (i2 | 1u))) break;
        } else {
            *q0 = (unsigned)((short)4u > (signed char)(1u << (6u & 31u)));
        }
    }
    if ((unsigned)(2u && (unsigned)b0)) {
        { unsigned t7; double z7; if (((unsigned)((int)(unsigned)(g1 || 6u) >= (int)5u)) & 1u) { t7 = (unsigned)(u1 < fuel); z7 = (double)(((0x6eb77d50u ^ p2)) & 255u); } if (((unsigned)((int)(unsigned)(g1 || 6u) >= (int)5u)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
            h0 = (short)((unsigned)!(0x10000u + 6u) >> ((unsigned)((short)0xffffffffu > (signed char)0x7fffffffu) & 31u));
            if ((unsigned)(w0 >> 29)) {
                u3 += (unsigned)(*q0 < garr[i1 & 7u]);
                *mp = a0[i0 & 3u];
            }
        }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (-(unsigned)((int)(unsigned)(signed char)(0x11b34b82u * fuel) < (int)0x7fffffffu)) break;
            i2 = ((unsigned)(0x35acde00u == (unsigned)((int)(unsigned)s0 >= (int)u2)) * (unsigned)s0) & 15u;
            x0 = x0 * 0x100000001b3ull + ((unsigned)l0 - (unsigned)s1);
        }
        if ((unsigned)(u0 || 0xb83688bcu)) {
            switch (u0 & 7u) {
                s1 = (int)((unsigned)s1 + (0x80000000u << (((6u >> ((unsigned)w0 & 31u)) + (p2 * *mp)) & 31u)));
            }
            *q0 += (unsigned)(unsigned char)((((unsigned)(x0 >> 70) * p0) & (unsigned)l0) / (-(unsigned)((int)p0 < (int)0x10000u) | 1u));
            if ((unsigned)(0x94719a9eu || (garr[u2 & 7u] >> ((unsigned)s0 & 31u)))) {
                if ((0x10000u ? *mp : 0x80000000u)) goto L4;
                if (budget != 0u) { budget -= 1u; u2 = fn1(u2, (garr[i1 & 7u] | u3), (*mp ? i1 : u0)); }
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)(unsigned)(0x878314c9u == (unsigned)c1) >= (int)*q0)) break;
                    if (p0) break;
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((int)(unsigned)e0 < (int)r0.x));
                        u2 = (unsigned)((int)(garr[i1 & 7u] - i0) < (int)((unsigned)c0 / ((unsigned)c1 | 1u)));
                        if (budget != 0u) { budget -= 1u; u3 = fn2(g0, 3u, p2); }
                    }
                    if (((unsigned)b0 * (unsigned)(p0 || g1))) break;
                } while (i0++ < 6u && *q0);
                goto L1;
                g0 = a0[i0 & 3u];
            } else {
                u1 += (unsigned)(signed char)((unsigned)((int)(u0 & fuel) >= (int)p0) % (p0 | 1u));
                d0 = d0 * 0.5 + (double)((unsigned)((unsigned)h0 && garr[i1 & 7u]) & 1023u);
                if (budget != 0u) { budget -= 1u; u3 = fn1(r0.y, -((unsigned)(0xffffffffu || 7u) | u2), (g1 / (g0 | 1u))); }
            }
            goto L4;
            u1 ^= (unsigned)((int)((unsigned)s0 | 0u) < (int)((unsigned)(short)(unsigned)((short)(unsigned)x0 > (signed char)4u) ^ (unsigned)f0));
        } else {
            if (((unsigned)c1 + u0)) {
                c1 = (signed char)0u;
                g1 += (((unsigned)((unsigned)b0 || 0x80000000u) - *q0) - (unsigned)h0);
                while (i0++ < 6u && (unsigned)((short)0x7fffffffu > (signed char)0x10000u)) { if (--fuel == 0u) goto done;
                    if (m0) {
                        if (p0) continue;
                        if (garr[u2 & 7u]) goto L3;
                    }
                    u3 = (unsigned)c1;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)0x7fffffffu < (int)u0), a0[i0 & 3u], (unsigned)!(unsigned)((short)g1 > (signed char)(unsigned)b0)); }
                    u3 ^= (0xffffffffu / ((unsigned)((int)0x7fffffffu >= (int)u3) | 1u));
                    if (((unsigned)(*mp && (unsigned)c0) % (fuel | 1u))) continue;
                    i2 = (unsigned)((int)-(p2 + g1) >= (int)v0) & 15u;
                }
                if ((p1 - 0x10000u)) goto L4;
                goto done;
                if ((unsigned)((int)(unsigned)s0 < (int)(unsigned)((unsigned)h0 < 9u))) goto L3;
            } else {
                if (i1) goto L3;
            }
            goto L1;
            if (budget != 0u) { budget -= 1u; u2 = fn2((4u - (unsigned)c1), 3u, v0); }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)h1, (unsigned)((int)(0x3d5ff076u >> ((unsigned)h0 & 31u)) >= (int)0x561fe266u), (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)(0x7fffffffu && 0x80000000u))); }
        }
        if ((0u >> (0x7fffffffu & 31u))) goto L4;
    }
    x0 = x0 * 0x100000001b3ull + ((0x96a3075eu + (garr[u2 & 7u] / (a0[u1 & 3u] | 1u))) << ((unsigned)s0 & 31u));
    h1 = (unsigned short)(h1 + (0x7fffffffu >> (g0 & 31u)));
    for (;;) { if (--fuel == 0u) goto done;
        b0 = (unsigned)x0 != 0u;
        if ((9u - -(v0 * 0x41979e94u))) break;
        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)c1 & (unsigned)c1), 0x80000000u, (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)(9u || 1u))); }
        c1 = (signed char)(unsigned)((int)(unsigned)((int)(unsigned)s0 < (int)a0[u1 & 3u]) >= (int)(unsigned)(unsigned char)(*q0 % ((unsigned)b0 | 1u)));
    }
    if (g1) goto done;
    garr[8u & 7u] = (unsigned)((unsigned)e0 || ((unsigned)w0 & (unsigned)s0));
    h1 = (unsigned short)(h1 + *mp);
    switch ((unsigned)(i2 < (0x80000000u & 9u)) & 7u) {
        u3 = (unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)(signed char)(unsigned)(3u < 0x46a0ee52u) < (unsigned)!(unsigned)(1u && g1)) < (unsigned)e0);
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(u3 - 1u) << ((unsigned)!(((u3 / (r0.y | 1u)) & g0) & (unsigned)((int)u0 < (int)0xffffffffu)) & 63u);
            x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)c0 % (v0 | 1u)) && 0x7fffffffu);
            { unsigned t8; double z8; if (((a0[u1 & 3u] * 0x8b85e30u)) & 1u) { t8 = (0x80000000u - 0x72a7d74fu); z8 = (double)((((u1 | 5u) & a0[i0 & 3u])) & 255u); } if (((a0[u1 & 3u] * 0x8b85e30u)) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                if ((unsigned)(unsigned char)(8u | (unsigned)h1)) continue;
                l0 = (long)((unsigned long)l0 + (unsigned)b0);
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(i1, 4u, 0x77b3194fu); }
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)b0, (unsigned)!(unsigned)(u0 == p0), ((i1 - 0x7fffffffu) - 0xb9ab7097u)); }
                }
            }
        }
        switch ((unsigned)(1u == (unsigned)(signed char)(unsigned)(*q0 && 0xf93b72fu)) & 7u) {
            switch (((unsigned)c1 >> ((a0[u1 & 3u] % (u0 | 1u)) & 31u)) & 7u) {
                if (budget != 0u) { budget -= 1u; u1 = fn0((fuel * (unsigned)(unsigned char)(unsigned)(7u == (unsigned)c0)), m0, ((unsigned)(w0 >> 29) << (~(4u / (0xffffffffu | 1u)) & 31u))); }
            }
            c0 = (unsigned char)(g1 & (unsigned)(w0 >> 29));
        }
        h0 = (short)(unsigned)h1;
        if (0u) goto L0;
    }
    c1 = (signed char)((unsigned)(unsigned char)(unsigned)((unsigned)(x0 >> 70) < (unsigned)(u3 && u2)) / (8u | 1u));
    if ((unsigned)((int)0x38589695u >= (int)(unsigned)((int)garr[u2 & 7u] >= (int)i2))) {
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(x0 >> 70), (unsigned)(0u < (unsigned)c0), ((unsigned)((unsigned)(x0 >> 70) == (unsigned)h0) & 0u)); }
        { unsigned t9; double z9; if (((unsigned)((unsigned)h0 || (unsigned)((short)(unsigned)h0 > (signed char)*mp))) & 1u) { t9 = (unsigned)((unsigned)!(unsigned)((short)u3 > (signed char)(unsigned)c1) || 0x10000u); z9 = (double)(((0xffffffffu * u3)) & 255u); } if (((unsigned)((unsigned)h0 || (unsigned)((short)(unsigned)h0 > (signed char)*mp))) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
            g1 += -(0x10000u ? p2 : (unsigned)c0);
        }
        d0 = d0 * 0.5 + (double)((u1 % ((-((unsigned)w0 << ((unsigned)c0 & 31u)) + (unsigned)s1) | 1u)) & 1023u);
        while (((unsigned)x0 ^ (0x243722bu % (4u | 1u)))) { if (--fuel == 0u) goto done;
            s0 = (int)0x80000000u;
            u0 += (unsigned)((unsigned)((int)(unsigned)(w0 >> 29) < (int)m0) == (a0[u1 & 3u] ? g0 : (unsigned)f0));
            { unsigned t10; double z10; if ((*mp) & 1u) { t10 = ((unsigned)f0 >> (0x10000u & 31u)); z10 = (double)((((unsigned)s0 * (unsigned)h1)) & 255u); } if ((*mp) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
                q0 = &garr[(unsigned)(((unsigned)e0 / ((unsigned)c0 | 1u)) || (0xd0814e49u / (v0 | 1u))) & 7u];
                *q0 = (~(((unsigned)h0 ^ 0x7cd4eebbu) / ((4u / (0x7fffffffu | 1u)) | 1u)) >> (i2 & 31u));
                continue; (void)((g0 ^ a0[u1 & 3u]));
                if (p0) break;
                x0 = x0 * 0x100000001b3ull + ((unsigned)h0 ^ (unsigned)h1);
                if (((unsigned)c1 / ((0x10000u >> (7u & 31u)) | 1u))) {
                    f0 = f0 * 0.5f + (float)((unsigned)(fuel < r0.y) & 255u);
                    for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (i1) {
                            e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)w0 || (unsigned)!((unsigned)s1 % ((unsigned)(g0 && 0xbe3579fcu) | 1u))) & 1023u);
                        } else {
                            break; (void)(0x7fffffffu);
                            if (m0) break;
                            u3 ^= -(0xffffffffu / ((unsigned)c0 | 1u));
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn1((0x10000u ^ 0x7b209251u), (((unsigned)h0 * r0.x) / (p2 | 1u)), (unsigned)(5u == r0.y)); }
                        c1 = (signed char)(unsigned)((int)v0 >= (int)0x8bd01a6au);
                        break; (void)((unsigned)((unsigned)e0 || (unsigned)s0));
                    }
                    s0 = (int)*q0;
                    u3 ^= u3;
                    if (((unsigned)(x0 >> 70) % ((*mp ^ u3) | 1u))) break;
                    break; (void)((unsigned)(0xffffffffu || 0xd49c85efu));
                } else {
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)c0, 0x9f75eb38u, (0x10000u & (unsigned)(p1 && (unsigned)s0))); }
                }
            }
            u1 ^= garr[u2 & 7u];
            if (budget != 0u) { budget -= 1u; u3 = fn2(garr[i1 & 7u], p0, ((unsigned)e0 ^ *q0)); }
            if (((unsigned)f0 & (unsigned)((unsigned)h1 && u2))) break;
        }
        if ((unsigned)e0) goto L0;
        h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)(0xff4bec97u || 0x12f81bcu) > (signed char)(*mp | 4u)));
    } else {
        goto done;
        goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn2(0u, 0xffffffffu, ((v0 | (unsigned)(w0 >> 29)) - 0xc3941b4u)); }
        if (budget != 0u) { budget -= 1u; u1 = fn0(i2, (unsigned)(signed char)((unsigned)c1 << (0x80000000u & 31u)), ((0xffffffffu | r0.x) - (unsigned)s1)); }
    }
    if ((0x35a2f3f8u + (unsigned)c1)) {
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)w0 == (unsigned)((short)*mp > (signed char)0x7fffffffu)), (unsigned)(unsigned char)(unsigned)((unsigned)h0 || (2u << ((unsigned)(x0 >> 70) & 31u))), (unsigned)(w0 >> 29)); }
        } while (i0++ < 4u && (unsigned)((unsigned)d0 == 0x33bb8dbbu));
        g1 += 0x9426ca2du;
        if ((unsigned)((int)u2 >= (int)(unsigned)c0)) {
            goto L0;
            if (budget != 0u) { budget -= 1u; u3 = fn2(((5u % (i0 | 1u)) << (r0.x & 31u)), (unsigned)(x0 >> 70), ((unsigned)l0 / (0xffffffffu | 1u))); }
        } else {
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (p0) break;
            }
            if (u3 == 7u) return -((4u << ((unsigned)(w0 >> 29) & 31u)) << ((unsigned)(((unsigned)x0 | (unsigned)(w0 >> 29)) < *mp) & 31u));
        }
    }
    *q0 += (m0 % ((unsigned)b0 | 1u));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = (r0.x | (unsigned)(short)(0x7fffffffu + u3));
        w0 ^= (unsigned long long)(i0 + 7u) << (((unsigned)e0 * (unsigned)h1) & 63u);
        { unsigned t11; double z11; if (((i0 * i0)) & 1u) { t11 = 0xffffffffu; z11 = (double)(((unsigned)((int)*mp < (int)(unsigned)(x0 >> 70))) & 255u); } if (((i0 * i0)) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
            if (budget != 0u) { budget -= 1u; u0 = fn1((0x7fffffffu >> ((unsigned)((int)garr[u2 & 7u] >= (int)u3) & 31u)), ((unsigned)(x0 >> 70) << (i0 & 31u)), (*mp / ((unsigned)((unsigned)h1 == garr[i1 & 7u]) | 1u))); }
            h0 = (short)0xecc04016u;
            while ((0x10000u / (((unsigned)s0 | i0) | 1u))) { if (--fuel == 0u) goto done;
                u1 += g1;
                if (*mp) break;
                if ((i0 / ((unsigned)c0 | 1u))) break;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((unsigned)(*mp < 0xffffffffu) & 1023u);
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)(7u && (unsigned)s1) || (unsigned)b0), (unsigned)s0, r0.y); }
                    if ((v0 / ((unsigned)s1 | 1u))) {
                        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                            f0 = f0 * 0.5f + (float)(((unsigned)!(unsigned)(0x6256c843u == (unsigned)(garr[u2 & 7u] == 3u)) | (unsigned)(*mp && 2u)) & 255u);
                            d0 = d0 * 0.5 + (double)((unsigned)((int)0x53ef8b3fu >= (int)v0) & 1023u);
                            w0 ^= (unsigned long long)(i2 / ((unsigned)f0 | 1u)) << (0x7fffffffu & 63u);
                            if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)((unsigned)l0 == 0x2fb21b76u) + *q0), ((unsigned)l0 >> (u3 & 31u)), g0); }
                            c0 = (unsigned char)r0.x;
                            w0 ^= (unsigned long long)m0 << (((unsigned)(garr[i1 & 7u] && r0.y) / (((unsigned)x0 ? (unsigned)l0 : v0) | 1u)) & 63u);
                        }
                        if (9u) break;
                        garr[1u & 7u] = ((unsigned)e0 * (0x7fffffffu % (u2 | 1u)));
                    }
                }
                w0 ^= (unsigned long long)(7u >> (0xffffffffu & 31u)) << ((0x81666162u ^ i1) & 63u);
                switch (((unsigned)f0 - u1) & 7u) {
                    m0 ^= (a0[u1 & 3u] << (g1 & 31u));
                    if (budget != 0u) { budget -= 1u; u2 = fn0(-((unsigned)((int)u1 >= (int)0x10000u) + 0x10000u), ((0x228a73a9u >> (4u & 31u)) - *mp), (u1 ^ 0xffffffffu)); }
                    if ((0u + (unsigned)((int)r0.x >= (int)0x30fcd36u))) break;
                }
            }
            u3 += ((unsigned)f0 ^ v0);
            if (0xffffffffu) break;
        }
        switch ((p2 ^ (m0 / ((unsigned)b0 | 1u))) & 7u) {
            q0 = &garr[0x10000u & 7u];
            if (budget != 0u) { budget -= 1u; u2 = fn0(p2, (unsigned)(unsigned char)((unsigned)(x0 >> 70) ? p2 : p2), (unsigned)((unsigned)c1 && *mp)); }
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(7u < 0xb1bf208u), (unsigned)(signed char)(i1 << (((unsigned)h1 % (garr[u2 & 7u] | 1u)) & 31u)), (unsigned)!(unsigned)((int)0x80000000u < (int)-((unsigned)c0 & fuel))); }
            if ((0xa6f9dbfbu | 0x7fffffffu)) break;
            case 6u: ;
        }
    }
    { unsigned t12; double z12; if ((((unsigned)d0 << (r0.y & 31u))) & 1u) { t12 = (unsigned)h0; z12 = (double)((((5u >> (0x80000000u & 31u)) << (9u & 31u))) & 255u); } if ((((unsigned)d0 << (r0.y & 31u))) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
        for (;;) { if (--fuel == 0u) goto done;
            goto L1;
        }
    }
    do { if (--fuel == 0u) goto done;
        goto L1;
    } while (i0++ < 2u && ((0u / (garr[i1 & 7u] | 1u)) | r0.y));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch ((3u ^ r0.y) & 7u) {
        while (g0) { if (--fuel == 0u) goto done;
            g0 = ((unsigned)((short)(unsigned)w0 > (signed char)(unsigned)l0) / (a0[i0 & 3u] | 1u));
            L0: if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + ~((unsigned)e0 << ((unsigned)(short)((unsigned)(*q0 < u0) % ((unsigned)(signed char)(unsigned)(g1 == r0.y) | 1u)) & 31u));
            w0 = w0 * 6364136223846793005ull + (0x1b2e9007u | (unsigned)s0);
        }
        if ((*q0 & 4u)) goto L0;
        r0.y ^= (unsigned)l0;
        if (i0) {
            if (u3 == 7u) return (unsigned)((int)1u >= (int)0x10000u);
            if (budget != 0u) { budget -= 1u; u3 = fn1(i1, 0xffffffffu, (unsigned)(0x78c0e933u == 0x80000000u)); }
        }
    }
    c1 = (signed char)(*q0 >> (((unsigned)f0 % ((unsigned)h1 | 1u)) & 31u));
    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(signed char)((unsigned)(x0 >> 70) % (i1 | 1u)) << (0xffffffffu & 31u)), 0x5e7889e6u, r0.x); }
    if ((0x14d61705u + (unsigned)((short)p0 > (signed char)7u))) {
        goto done;
        if ((p1 / (i0 | 1u))) goto L2;
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)!(unsigned)((int)(unsigned)x0 < (int)i2) == u2));
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0(0x373c02cau, ((unsigned)(x0 >> 70) % (0x7fffffffu | 1u)), (4u << ((unsigned)(signed char)((unsigned)h0 | (unsigned)(x0 >> 70)) & 31u))); }
    } else {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(x0 >> 70), (0xc474119fu << ((unsigned)(*mp < (unsigned)(x0 >> 70)) & 31u)), (unsigned)((short)(unsigned)l0 > (signed char)1u)); }
            if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)!(5u + 0xbdc240aau) | 5u), p0, (unsigned)e0); }
            if ((unsigned)(9u || 0x7fffffffu)) break;
            w0 = w0 * 6364136223846793005ull + ((unsigned)l0 % (((unsigned)l0 * (unsigned)f0) | 1u));
        }
        i1 = (unsigned)((short)(unsigned)!((unsigned)((int)5u < (int)(unsigned)d0) % ((unsigned)d0 | 1u)) > (signed char)u1) & 15u;
        s1 = (int)((unsigned)s1 + (((0x63da3f06u << ((unsigned)w0 & 31u)) >> ((unsigned)f0 & 31u)) - (unsigned)x0));
        d0 = d0 * 0.5 + (double)((unsigned)(0x451ec074u || p0) & 1023u);
    }
    if (fuel < 8u) return 0x80000000u;
    if (3u) goto L3;
    u2 ^= (6u ^ garr[u2 & 7u]);
    if (~(unsigned)((int)(0xdce39401u | 7u) >= (int)0u)) {
        switch (*q0 & 7u) {
            i0 = (unsigned)(garr[u2 & 7u] == (unsigned)(p0 || 7u)) & 15u;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn2((u1 ^ 5u), (a0[u1 & 3u] >> (4u & 31u)), (unsigned)((garr[u2 & 7u] - 3u) < 4u)); }
                if (((unsigned)!((unsigned)s0 ^ a0[i0 & 3u]) / (3u | 1u))) goto L2;
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)s0, (*mp * (unsigned)c0), (unsigned)(u3 && (*mp >> ((unsigned)h0 & 31u)))); }
                if ((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)(0x8048b6a8u && (unsigned)l0))) goto L1;
            } while (i0++ < 2u && (((unsigned)h0 - r0.y) % (0xffffffffu | 1u)));
            if (~(0x7dde8c9eu << (p1 & 31u))) {
                while (-(*mp & ((unsigned)h1 * u0))) { if (--fuel == 0u) goto done;
                    L1: if (--fuel == 0u) goto done;
                }
                g0 = (unsigned)(unsigned char)((unsigned)b0 >> ((unsigned)((*mp - (unsigned)c1) || (u3 + 0x93ac19d6u)) & 31u));
                switch ((unsigned)(signed char)((2u + garr[u2 & 7u]) % (*mp | 1u)) & 7u) {
                    f0 = f0 * 0.5f + (float)((p2 | ((unsigned)(w0 >> 29) + (0u ^ 1u))) & 255u);
                    case 6u: ;
                    r0.x = (0x10000u << (0xf771d105u & 31u));
                    r0.x = -(g1 | (unsigned)w0);
                    if (6u) break;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)r0.y > (signed char)(unsigned)(x0 >> 70)), (unsigned)f0, 2u); }
                }
                L2: if (--fuel == 0u) goto done;
                while (8u) { if (--fuel == 0u) goto done;
                    if (0x80000000u) {
                        b0 = ((unsigned)((unsigned)l0 < (unsigned)(0x7625f9f9u == 0x10000u)) / ((8u % (g0 | 1u)) | 1u)) != 0u;
                        r0.y ^= (unsigned)(u1 || (p0 ? ((unsigned)f0 - (unsigned)h1) : (unsigned)x0));
                        l0 = (long)((unsigned long)l0 + ((unsigned)((short)i1 > (signed char)0xffffffffu) | (unsigned)!(unsigned)(0x5f277683u && 0xffffffffu)));
                        if (((unsigned)w0 & g0)) continue;
                    }
                    case 6u: ;
                }
            } else {
                garr[(u1 * 0u) & 7u] = ((unsigned)s0 * (unsigned)(2u == (unsigned)!((0x80000000u * r0.x) & r0.x)));
                b0 = ~(unsigned)((int)((unsigned)f0 + (0xffffffffu ^ (unsigned)!(1u << (u2 & 31u)))) >= (int)(unsigned)e0) != 0u;
                for (;;) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (0x7fffffffu - (((unsigned)e0 ? g1 : 0x6582edc8u) ^ (unsigned)x0)));
                }
            }
            L3: if (--fuel == 0u) goto done;
        }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (0xffffffffu) break;
            *q0 = (0x10000u & (unsigned)((int)(unsigned)((int)r0.x < (int)((unsigned)s1 + *q0)) >= (int)(unsigned)b0));
            if (r0.y) {
                if ((unsigned)((int)*mp >= (int)i1)) break;
                if (i2) {
                    if ((m0 & -(0xffffffffu - r0.y))) goto L2;
                    if (((v0 << (p0 & 31u)) << (*q0 & 31u))) continue;
                    goto done;
                    x0 = x0 * 0x100000001b3ull + 4u;
                    while (i1++ < 7u && 0x10000u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(p1, ((*q0 >> (i1 & 31u)) % (2u | 1u)), i1); }
                        if (r0.y) goto L4;
                        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(0xffffffffu || (v0 ^ 5u)) == ((unsigned)(x0 >> 70) + i1)));
                        l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)(p2 < ((unsigned)(x0 >> 70) ^ (unsigned)x0)) - i2) || 0xffffffffu));
                        L4: if (--fuel == 0u) goto done;
                        if (-(i2 & (unsigned)(x0 >> 70))) break;
                    }
                } else {
                    break; (void)(-(g1 ^ fuel));
                    c0 = (unsigned char)(unsigned)e0;
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        u0 = ((unsigned)(0x80000000u && (unsigned)l0) ^ ((unsigned)h1 & (unsigned)((unsigned)x0 == g0)));
                        if (0x10000u) goto L0;
                    }
                }
            }
            if ((p1 - 5u)) break;
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(v0 || (unsigned)x0), -(r0.x | ((unsigned)c0 / ((unsigned)e0 | 1u))), 0x769b1effu); }
        }
        goto L1;
        if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)f0, fuel, ((unsigned)((int)(unsigned)s0 >= (int)0x789537c0u) & 4u)); }
    }
    if ((unsigned)((unsigned)((int)0x10000u >= (int)*q0) == 7u)) goto L3;
    v0 = (unsigned)((unsigned)(unsigned char)(unsigned)((int)0x7fffffffu >= (int)(unsigned)(*mp < fuel)) < (u1 << (0x940da9bu & 31u)));
    goto L2;
    c0 = (unsigned char)((unsigned)e0 ^ (unsigned)(garr[u2 & 7u] && (0x985a7637u / ((unsigned)w0 | 1u))));
    if ((p1 << (0xa757eca6u & 31u))) goto L4;
    w0 ^= (unsigned long long)*q0 << (~(unsigned)((unsigned)s0 == (unsigned)(x0 >> 70)) & 63u);
    if ((unsigned)(p1 || (unsigned)(w0 >> 29))) goto L2;
    if ((unsigned)((unsigned)b0 < (unsigned)((int)(unsigned)f0 >= (int)m0))) goto L0;
    while (i0++ < 6u && ((a0[u1 & 3u] >> ((unsigned)l0 & 31u)) << ((unsigned)b0 & 31u))) { if (--fuel == 0u) goto done;
        if ((unsigned)l0) {
            garr[(unsigned)h0 & 7u] = ((unsigned)e0 ? (unsigned)(unsigned char)(unsigned)(4u == v0) : (unsigned)c0);
            garr[g0 & 7u] = (unsigned)(4u < (unsigned)s1);
            s1 = (int)((unsigned)s1 + a0[i0 & 3u]);
            if (((unsigned)d0 << (((unsigned)b0 - (unsigned)s0) & 31u))) continue;
        }
        { unsigned t0; double z0; if ((0x10000u) & 1u) { t0 = 0x5465a4a9u; z0 = (double)(((5u / ((unsigned)w0 | 1u))) & 255u); } if ((0x10000u) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            r0.y ^= 0xffffffffu;
            break; (void)(3u);
            x0 = x0 * 0x100000001b3ull + (unsigned)((int)0xffffffffu < (int)(unsigned)(0x3162a15au && p2));
            if (u3 == 7u) return (unsigned)((short)r0.y > (signed char)6u);
            m0 ^= (unsigned)((int)a0[i0 & 3u] >= (int)(0x80000000u << (0x7fffffffu & 31u)));
        }
        u0 += 0xffffffffu;
        if ((unsigned)((unsigned)(unsigned char)(v0 & 0x7fffffffu) && 1u)) goto L3;
        break; (void)(*q0);
    }
    if (i0) goto done;
    i0 = (i1 ? u2 : ((unsigned)c1 + 4u)) & 15u;
    if ((2u - (unsigned)c1)) {
        *q0 += (((unsigned)(w0 >> 29) << (0xe11699e9u & 31u)) + i1);
        l0 = (long)((unsigned long)l0 + (p2 % ((unsigned)(garr[u2 & 7u] && (unsigned)d0) | 1u)));
        while (g0) { if (--fuel == 0u) goto done;
            r0.x = (unsigned)(short)(unsigned)((int)(i0 * u1) >= (int)((r0.y ^ 9u) / (*q0 | 1u)));
            do { if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if (((unsigned)(*mp && (unsigned)c1)) & 1u) { t1 = m0; z1 = (double)(((unsigned)((short)(unsigned)((unsigned)h0 < (unsigned)(x0 >> 70)) > (signed char)8u)) & 255u); } if (((unsigned)(*mp && (unsigned)c1)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    v0 = (unsigned)(unsigned char)(unsigned)((short)(unsigned)x0 > (signed char)((unsigned)(0x80000000u == 0x80000000u) - ((unsigned)h1 * 0xa3168e6au)));
                    if (budget != 0u) { budget -= 1u; u2 = fn1(*mp, ~(garr[u2 & 7u] % (i0 | 1u)), (unsigned)(0xffffffffu && (unsigned)(unsigned char)(*mp >> (0xc4856d52u & 31u)))); }
                    break; (void)((unsigned)c1);
                    w0 ^= (unsigned long long)((unsigned)e0 & (unsigned)c1) << ((unsigned)((short)(unsigned)(signed char)((a0[u1 & 3u] + 0u) << ((unsigned)(w0 >> 29) & 31u)) > (signed char)(unsigned)h0) & 63u);
                    if (0xa12c80efu) break;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)r0.y), 5u, (unsigned)((int)(5u % (r0.x | 1u)) >= (int)0x7fffffffu)); }
                if ((unsigned)(((unsigned)h0 % ((unsigned)d0 | 1u)) == 9u)) break;
                for (;;) { if (--fuel == 0u) goto done;
                    *mp = ((fuel - (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)w0)) - (unsigned)s1);
                    s1 = (int)((unsigned)s1 + ((unsigned)w0 / ((unsigned)((unsigned)s0 < u3) | 1u)));
                    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn2(i1, (unsigned)(short)((unsigned)(p0 && 0x80000000u) | 0xffffffffu), -(((unsigned)f0 | 1u) << ((unsigned)f0 & 31u))); }
                        if ((unsigned)e0) break;
                        e0 = e0 * 0.5L + (long double)((unsigned)e0 & 1023u);
                        c0 = (unsigned char)(unsigned)s0;
                        break; (void)(0x2e8d70fu);
                    }
                }
            } while (i1++ < 5u && (unsigned)((unsigned)((short)(unsigned)w0 > (signed char)0x98492f5cu) && 0x10000u));
            switch ((unsigned)c0 & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)f0 % (0xd644b60au | 1u)), (unsigned)h0, (unsigned)(u3 || 0x10000u)); }
                case 5u: ;
            }
        }
        switch (garr[i1 & 7u] & 7u) {
            case 4u: ;
            if (m0) goto L2;
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((int)(unsigned)h0 < (int)i0) < (unsigned)(0xe8feb5u || 0x307ec9acu)) & 255u);
        }
        switch ((unsigned)(short)((0x10000u % ((unsigned)h1 | 1u)) / (0x5432caf6u | 1u)) & 7u) {
            d0 = d0 * 0.5 + (double)((u1 & (0x7fffffffu >> ((unsigned)c1 & 31u))) & 1023u);
            *q0 += (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)(short)(0x7fffffffu - 0x7fffffffu));
            case 7u: ;
            switch ((unsigned)((int)v0 < (int)*mp) & 7u) {
                case 0u: ;
                q0 = &garr[((unsigned)e0 % (((unsigned)h0 * p2) | 1u)) & 7u];
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    u1 = ((fuel + 0xffffffffu) * 0xffffffffu);
                    default: ;
                    while (i1++ < 5u && (unsigned)(signed char)(unsigned)((short)(*q0 ^ *mp) > (signed char)0xf41c7debu)) { if (--fuel == 0u) goto done;
                        *q0 += ((unsigned)c1 % ((unsigned)(short)(unsigned)(v0 == a0[i0 & 3u]) | 1u));
                        h0 = (short)((unsigned)((int)i0 >= (int)0x7fffffffu) >> (i1 & 31u));
                        garr[(0x5e02273au % (0x80000000u | 1u)) & 7u] = 0x6a3005ceu;
                        c1 = (signed char)(0x7fffffffu + fuel);
                        w0 = w0 * 6364136223846793005ull + ((unsigned)((int)(unsigned)e0 < (int)*mp) << ((unsigned)(u1 && u0) & 31u));
                    }
                    do { if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)((0x711b1775u & 2u) & 1023u);
                        e0 = e0 * 0.5L + (long double)((((unsigned)s1 ^ (unsigned)s1) - (unsigned)b0) & 1023u);
                        if ((unsigned)((short)u1 > (signed char)*q0)) continue;
                    } while (i1++ < 5u && (unsigned)(short)(8u >> ((unsigned)s1 & 31u)));
                }
            }
            c0 = (unsigned char)(5u + (p2 | (0x10000u ^ 0u)));
        }
        q0 = &garr[(unsigned)(signed char)(u0 | (unsigned)(i2 || i1)) & 7u];
    }
    if ((0xffffffffu ^ a0[u1 & 3u])) goto L4;
    if ((unsigned)(0xb90039fau < r0.y)) goto done;
    if (budget != 0u) { budget -= 1u; u3 = fn1(u1, a0[u1 & 3u], (3u * (unsigned)w0)); }
    s0 = (int)(unsigned)((unsigned)c1 < g0);
    if (budget != 0u) { budget -= 1u; u2 = fn3(((p1 + a0[i0 & 3u]) - r0.x), *mp, (unsigned)(0x3c53049au < i0)); }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = (unsigned)(signed char)(unsigned)(r0.x || (*q0 >> (*q0 & 31u)));
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((3u ^ (unsigned)(a0[u1 & 3u] && 0xeba1d33du)), (fuel ^ (unsigned)((int)8u >= (int)i1)), (i2 - (*q0 ^ (unsigned)h1))); }
    d0 = d0 * 0.5 + (double)((*mp - 0x7fffffffu) & 1023u);
    goto L1;
    s1 = (int)((unsigned)s1 + ((unsigned)(signed char)((unsigned)x0 - 0xffffffffu) % ((r0.x ? *mp : r0.x) | 1u)));
    switch ((0x10000u | 0x7fffffffu) & 7u) {
        v0 = (unsigned)((int)(((unsigned)e0 ? (unsigned)h1 : g1) & i0) < (int)u0);
        if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)((int)5u >= (int)(unsigned)h1), (unsigned)!((unsigned)w0 + 4u), (*mp * r0.x)); }
        goto L0;
        if ((unsigned)(x0 >> 70)) goto L1;
        switch ((unsigned)(0x694d01b7u == 0x4e16c413u) & 7u) {
            s1 = (int)((unsigned)s1 + ((unsigned)c0 ? (unsigned)(unsigned char)(unsigned)((unsigned)((short)*q0 > (signed char)9u) || *q0) : v0));
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)0x10000u;
                u0 = u0 * 0x9e3779b1u + ((0x10000u / (garr[i1 & 7u] | 1u)) | r0.x);
                *mp = (8u ? (unsigned)!((unsigned)(x0 >> 70) & (unsigned)f0) : p2);
            }
            if ((unsigned)h1) {
                h1 = (unsigned short)(h1 + garr[u2 & 7u]);
                v0 = ((a0[u1 & 3u] ? p2 : v0) % ((unsigned)((int)r0.y < (int)(unsigned)b0) | 1u));
                if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)w0, 0x10000u, (unsigned)w0); }
                if (*mp) goto L3;
            }
            if ((unsigned)((short)*mp > (signed char)9u)) break;
            u2 += ((unsigned)((int)(unsigned)c1 >= (int)0xc489d62eu) / ((a0[i0 & 3u] | (unsigned)x0) | 1u));
            u2 = ((v0 ^ (u0 ? 0x513fed2u : u1)) & (unsigned)h0);
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)0xcb739a18u > (signed char)(unsigned)((int)u1 < (int)0xffffffffu)), ((unsigned)c1 & (unsigned)s1), (unsigned)((unsigned)(signed char)(0x2c02b5b9u / (0x2502e123u | 1u)) == 0xd3e7b0e0u)); }
    if ((0x6a963d41u + (v0 - 3u))) {
        if ((m0 * 0x10000u)) goto L3;
        e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)((v0 >> (~(unsigned)((int)0xe2602e4bu >= (int)*mp) & 31u)) & 8u) & 1023u);
    } else {
        goto L4;
    }
    if (((unsigned)d0 | u1)) {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn2((i1 >> ((unsigned)w0 & 31u)), (unsigned)(p1 < (unsigned)((short)r0.y > (signed char)v0)), (((unsigned)f0 & u2) / (7u | 1u))); }
            if ((unsigned)((7u | 0x7fffffffu) == i0)) {
                if ((2u >> ((unsigned)l0 & 31u))) break;
                if ((unsigned)((int)0x7fffffffu < (int)0x26dbb276u)) goto L3;
                u3 += (unsigned)(8u == 0x7fffffffu);
            } else {
                u2 = (0x36a6d4d5u ^ (8u >> ((unsigned)(short)(unsigned)(u2 || (unsigned)x0) & 31u)));
                *mp = (unsigned)(g0 < (g1 / (i2 | 1u)));
                r0.y ^= ((unsigned)((int)(unsigned)w0 < (int)p0) | 0x2e374fc6u);
                *mp = -((unsigned)b0 << (0x155451aeu & 31u));
            }
        }
        u0 += (unsigned)((int)(*q0 % (0x7fffffffu | 1u)) >= (int)0xffffffffu);
        a0[(unsigned)((short)i1 > (signed char)8u) & 3u] = (unsigned)((int)-(unsigned)((unsigned)h0 == (unsigned)h1) >= (int)0xb2806cecu);
        f0 = f0 * 0.5f + (float)(u2 & 255u);
        u2 ^= ~(unsigned)(((unsigned)f0 & p1) < u0);
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (u0) continue;
    }
    *q0 = 0x264bf5c1u;
    if (budget != 0u) { budget -= 1u; u3 = fn2((*q0 % (4u | 1u)), (unsigned)((short)(unsigned)!(unsigned)(4u < 0xffffffffu) > (signed char)(unsigned)l0), (unsigned)(signed char)(unsigned)((int)1u >= (int)(unsigned)((short)r0.y > (signed char)(unsigned)b0))); }
    s1 = (int)((unsigned)s1 + (v0 & garr[i1 & 7u]));
    h1 = (unsigned short)(h1 + ((u2 ? (unsigned)(u1 || p2) : (unsigned)c0) - (unsigned)e0));
    u1 = (unsigned)(unsigned char)(u1 & m0);
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(unsigned)(garr[u2 & 7u] == (unsigned)((short)(unsigned)e0 > (signed char)a0[u1 & 3u]));
    }
    switch ((m0 % (0xffffffffu | 1u)) & 7u) {
        if ((unsigned)s0) {
            do { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (0xffffffffu | g0);
                    *q0 = p2;
                }
            } while (i0++ < 4u && (unsigned)(x0 >> 70));
            if ((unsigned)x0) goto L1;
        } else {
            goto L0;
            if (budget != 0u) { budget -= 1u; u3 = fn2(0x9703eeeau, ((unsigned)c1 + 0x815975cau), ~((a0[u1 & 3u] + u1) | 0xffffffffu)); }
            i1 = (unsigned)(unsigned char)((unsigned)((int)0x194ab784u < (int)*q0) - ((unsigned)(unsigned char)(unsigned)((int)(unsigned)h1 < (int)(unsigned)b0) >> (i1 & 31u))) & 15u;
            case 2u: ;
        }
        q0 = &garr[(unsigned)(signed char)(unsigned)(r0.y || (r0.x + 0x7fffffffu)) & 7u];
        break; (void)((unsigned)h1);
        while (i0++ < 3u && ((unsigned)s0 | (unsigned)c0)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(((p1 & 0x458f6de5u) / (0x131bb040u | 1u)), (unsigned)(u0 || (unsigned)(u2 == r0.x)), (unsigned)h0); }
            if (0x18cb937du) continue;
            c1 = (signed char)((unsigned)c0 % ((0x80000000u ^ (i0 / (g0 | 1u))) | 1u));
        }
        case 7u: ;
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)(5u || (unsigned)h0);
    }
    if (((unsigned)h1 ? g0 : fuel)) goto L0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 10u, 0xde7fc72cu, 0xd52cdd3fu },
        { 10u, 0x8eef4510u, 0xc583800eu },
        { 12u, 0xc976327au, 0xc7f514b5u },
        { 4u, 0xa1372035u, 0xb0b191eau },
        { 12u, 0x8d44614cu, 0x3cda7593u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
