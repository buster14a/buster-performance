// test-ssa-source's program of seed 141000435 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x9f91cf9u, g1 = 0xac2b807du;
static unsigned garr[8] = { 0x3500acceu, 0x41b3a149u, 0x2f9792b4u, 0xeb240b68u, 0x9754f217u, 0x85d417e3u, 0x6254c8deu, 0x3924878du };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (u3 == 7u) return g0;
    if ((0x26a442a9u * (unsigned)l0)) goto L0;
    goto done;
    L0: if (--fuel == 0u) goto done;
    { unsigned t0; double z0; if (((unsigned)(((unsigned)e0 - a0[i0 & 3u]) == (unsigned)l0)) & 1u) { t0 = *mp; z0 = (double)((((i1 / ((unsigned)(w0 >> 29) | 1u)) >> (u1 & 31u))) & 255u); } if (((unsigned)(((unsigned)e0 - a0[i0 & 3u]) == (unsigned)l0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if ((unsigned)(unsigned char)((unsigned)(unsigned char)(unsigned)(0x57673bd5u || u3) + 0xffffffffu)) {
            while (i0++ < 2u && 5u) { if (--fuel == 0u) goto done;
                r0.x = -(unsigned)(i1 == (unsigned)(short)(0xffffffffu ? 0x55446c15u : p0));
                L1: if (--fuel == 0u) goto done;
            }
            a0[(unsigned)(p2 == u3) & 3u] = (g1 * (unsigned)h0);
            *mp = (unsigned)((int)i1 < (int)((unsigned)f0 - i0));
            g1 += ((0x10000u * (unsigned)h1) ^ (unsigned)(x0 >> 70));
        } else {
            L2: if (--fuel == 0u) goto done;
        }
        switch ((unsigned)(0xffffffffu == garr[i1 & 7u]) & 7u) {
            w0 = w0 * 6364136223846793005ull + (unsigned)(0x7a054972u == p2);
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (0xca76a656u) {
                        u3 = u3 * 0x9e3779b1u + (0x7fffffffu + ((0x74ce29c1u % (p1 | 1u)) | 0x1b2923d2u));
                        g0 = (unsigned)((short)0x7badf4b5u > (signed char)i1);
                        goto L1;
                        case 2u: ;
                        L3: if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + ~(r0.x ^ a0[i0 & 3u]);
                    }
                    v0 = ((unsigned)((int)(unsigned)s0 >= (int)((unsigned)c0 % (0x7fffffffu | 1u))) | 0x7fffffffu);
                    { unsigned t1; double z1; if (((0x28caca91u << ((unsigned)(3u < 1u) & 31u))) & 1u) { t1 = (unsigned)(a0[i0 & 3u] && 0x10000u); z1 = (double)((((i2 + fuel) << (0x80000000u & 31u))) & 255u); } if (((0x28caca91u << ((unsigned)(3u < 1u) & 31u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                        d0 = d0 * 0.5 + (double)(((unsigned)h0 / (0x79080ed1u | 1u)) & 1023u);
                    }
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + (unsigned)((int)((i2 >> ((unsigned)s0 & 31u)) - i1) >= (int)(i1 | 0x11c4844cu));
                        u1 += (unsigned)(w0 >> 29);
                    }
                    if ((unsigned)(0xffffffffu < u2)) goto L0;
                    case 1u: ;
                }
                *q0 += -(unsigned)((unsigned)d0 && g0);
                u1 += (unsigned)((int)(0xea2a4a37u ^ (unsigned)h1) >= (int)(unsigned)d0);
                case 5u: ;
                default: ;
                case 4u: ;
            }
        }
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + garr[i1 & 7u]);
            e0 = e0 * 0.5L + (long double)(((unsigned)(8u == i1) ^ (unsigned)e0) & 1023u);
        } while (i1++ < 7u && (unsigned)(unsigned char)(unsigned)((unsigned)(0x10000u < m0) && r0.x));
    }
    if (g1) {
        L4: if (--fuel == 0u) goto done;
        u1 = u1 * 0x9e3779b1u + (unsigned)(short)(4u * (unsigned)s0);
    } else {
        a0[0x10000u & 3u] = -((unsigned)(p1 || (unsigned)s1) + r0.y);
        if ((unsigned)(*q0 == v0)) goto done;
        goto done;
    }
    f0 = f0 * 0.5f + (float)(5u & 255u);
    do { if (--fuel == 0u) goto done;
        v0 = (unsigned)(-(5u & 0x403e5101u) < (unsigned)x0);
    } while (i0++ < 2u && (*mp - (unsigned)x0));
    s1 = (int)((unsigned)s1 + ((unsigned)(0x80000000u < g1) - (fuel * (v0 & 5u))));
    *q0 = ((0xffffffffu / (r0.y | 1u)) + (unsigned)((unsigned)b0 || u0));
    if ((unsigned)b0) {
        r0.y ^= (unsigned)(p1 && ~(unsigned)(r0.y < p1));
        g1 += (unsigned)(signed char)(unsigned)((int)(unsigned)d0 >= (int)(unsigned)((int)(unsigned)s0 < (int)9u));
    }
    if (((unsigned)x0 * g1)) goto L1;
    goto L4;
    i2 = 0xd8209e47u & 15u;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (unsigned)e0;
        u2 = u2 * 0x9e3779b1u + 5u;
        break; (void)(((unsigned)c0 - *mp));
        if ((unsigned)(u3 == g0)) break;
        if ((unsigned)c1) {
            l0 = (long)((unsigned long)l0 + fuel);
            break; (void)(~(((unsigned)(w0 >> 29) / (fuel | 1u)) >> (u1 & 31u)));
        } else {
            continue; (void)((unsigned)x0);
        }
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)(((unsigned)((int)(unsigned)w0 >= (int)(unsigned)(x0 >> 70)) | (unsigned)c1) ^ (a0[u1 & 3u] << (u3 & 31u)));
    }
    r0.x = (unsigned)s1;
    if ((unsigned)((unsigned)((int)*q0 >= (int)(unsigned)l0) < garr[u2 & 7u])) {
        c1 = (signed char)~(unsigned)(p1 && r0.y);
        r0.y ^= (fuel * (unsigned)s1);
    }
    while (i0++ < 2u && u3) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            g1 += ~((unsigned)l0 ? u1 : ((unsigned)f0 & ~(unsigned)((int)(unsigned)f0 >= (int)(unsigned)l0)));
            if ((0xffffffffu >> ((unsigned)((int)(unsigned)w0 < (int)g0) & 31u))) continue;
            g0 = (p2 | r0.y);
            if ((unsigned)(((unsigned)b0 | i0) || i0)) break;
        } while (i1++ < 2u && (unsigned)((short)0x3fea11e9u > (signed char)(unsigned)(0xffffffffu && g0)));
        break; (void)(r0.y);
        x0 = x0 * 0x100000001b3ull + ((0x7fffffffu ? fuel : (unsigned)f0) << ((unsigned)b0 & 31u));
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)((int)0xf6c359efu >= (int)i1));
            garr[(unsigned)((unsigned)(w0 >> 29) || 0x6d7ecc51u) & 7u] = (((unsigned)s1 ? (unsigned)w0 : (unsigned)s0) / (garr[u2 & 7u] | 1u));
            h1 = (unsigned short)(h1 + ((0x183c19fdu >> (garr[u2 & 7u] & 31u)) >> ((2u << ((unsigned)((unsigned)x0 && (unsigned)s1) & 31u)) & 31u)));
        }
        while (5u) { if (--fuel == 0u) goto done;
            while (i2++ < 2u && (8u - i1)) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    garr[(unsigned)(fuel && 0xffffffffu) & 7u] = (p0 - 0xffffffffu);
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        a0[(unsigned)((unsigned)s1 && (unsigned)(x0 >> 70)) & 3u] = a0[u1 & 3u];
                        x0 = x0 * 0x100000001b3ull + 0x80000000u;
                        garr[(unsigned)((unsigned)h1 || 0x72c53ce0u) & 7u] = (0x26493534u % ((6u << (fuel & 31u)) | 1u));
                    }
                    break; (void)((unsigned)((int)a0[i0 & 3u] < (int)a0[i0 & 3u]));
                    if ((unsigned)(r0.x && p0)) continue;
                    garr[(unsigned)(u2 == 0x80000000u) & 7u] = (unsigned)((unsigned)l0 < (5u << ((unsigned)s1 & 31u)));
                }
                if (u3) goto L0;
            }
        }
    }
    if ((r0.y | (0x7fffffffu / (u1 | 1u)))) goto done;
    if ((v0 << ((unsigned)(0x92388a24u && 0x10000u) & 31u))) goto L3;
    h0 = (short)((unsigned)c0 >> ((unsigned)(u0 || (unsigned)s0) & 31u));
    if (u3 == 7u) return (unsigned)!(unsigned)((int)(unsigned)s1 < (int)(unsigned)((int)(unsigned)(garr[u2 & 7u] < fuel) >= (int)a0[u1 & 3u]));
    for (;;) { if (--fuel == 0u) goto done;
        break; (void)((0x9665723au % (1u | 1u)));
        break; (void)((0x80000000u * (0x1e955b8du ^ (unsigned)x0)));
        if ((unsigned)(short)(unsigned)((unsigned)c1 || 0x10000u)) break;
        if ((p1 * 0x9e4a1b6au)) goto L1;
        break; (void)((unsigned)((int)(unsigned)s1 >= (int)(0x132ebadbu - 0xe10fa2d8u)));
        if ((unsigned)((unsigned)h0 == (u2 * p2))) break;
    }
    s0 = (int)(0xa9242bdbu | (unsigned)(i2 < g0));
    goto L0;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        garr[0xe0bf6b4eu & 7u] = (unsigned)(0x10000u == (fuel * i2));
    }
    if (0x2ff9ca1eu) goto L2;
    if (fuel < 8u) return garr[i1 & 7u];
    if (p1) goto L2;
    l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)h1 << (((unsigned)(x0 >> 70) * u2) & 31u)) == 0x192caa0au));
    a0[(unsigned)(p2 || garr[u2 & 7u]) & 3u] = (i2 + (unsigned)((unsigned)(unsigned char)(a0[i0 & 3u] + u2) < i2));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            while (i2++ < 3u && (unsigned)((short)i1 > (signed char)(unsigned)s0)) { if (--fuel == 0u) goto done;
                if ((unsigned)!(((unsigned)d0 + (unsigned)b0) | 2u)) continue;
                goto done;
                *mp = (unsigned)((short)v0 > (signed char)((unsigned)b0 ? (unsigned)f0 : m0));
                if ((garr[i1 & 7u] ^ *mp)) break;
                f0 = f0 * 0.5f + (float)((0x80000000u * (unsigned)((short)p1 > (signed char)3u)) & 255u);
            }
            if ((unsigned)(signed char)(u1 - ((unsigned)(w0 >> 29) & 5u))) break;
            r0.y ^= ((unsigned)f0 & (unsigned)(short)((unsigned)(x0 >> 70) << ((unsigned)c0 & 31u)));
            r0.x = (0x10000u >> (garr[i1 & 7u] & 31u));
        }
        if (g1) break;
        v0 = (unsigned)(unsigned char)(0x10000u + (unsigned)((int)(unsigned)c0 >= (int)*mp));
        i2 = (unsigned)((unsigned)((short)((0x80000000u | i2) % ((unsigned)c1 | 1u)) > (signed char)i0) && (unsigned)s0) & 15u;
    }
    if ((unsigned)(w0 >> 29)) goto L0;
    do { if (--fuel == 0u) goto done;
        if (9u) break;
        { unsigned t2; double z2; if (((unsigned)(signed char)(unsigned)((int)~(0x10000u >> ((unsigned)c1 & 31u)) >= (int)(unsigned)f0)) & 1u) { t2 = a0[u1 & 3u]; z2 = (double)(((i2 | 0x824e2f37u)) & 255u); } if (((unsigned)(signed char)(unsigned)((int)~(0x10000u >> ((unsigned)c1 & 31u)) >= (int)(unsigned)f0)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            if (((unsigned)d0 << ((unsigned)h1 & 31u))) {
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    u2 = (u2 << ((1u ? (unsigned)f0 : (unsigned)c1) & 31u));
                    u0 ^= ((u3 - *mp) * (0x43aea0dfu - (unsigned)((int)(unsigned)f0 >= (int)(unsigned)f0)));
                    for (;;) { if (--fuel == 0u) goto done;
                        { unsigned t3; double z3; if ((*q0) & 1u) { t3 = 1u; z3 = (double)(((unsigned)((unsigned)l0 || (unsigned)e0)) & 255u); } if ((*q0) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                            if (g0) break;
                            g0 = ((*q0 + (unsigned)x0) | 1u);
                            break; (void)((-(unsigned)(garr[i1 & 7u] < r0.x) % (0xffffffffu | 1u)));
                            g0 = -(unsigned)((unsigned)((int)(unsigned)(u1 == (unsigned)e0) >= (int)(unsigned)((unsigned)d0 == 0xffffffffu)) == *q0);
                        }
                        x0 = x0 * 0x100000001b3ull + (m0 * (unsigned)(w0 >> 29));
                    }
                    l0 = (long)((unsigned long)l0 + (u2 ^ (((a0[u1 & 3u] << (a0[i0 & 3u] & 31u)) | 0x7fffffffu) ^ *mp)));
                    garr[u0 & 7u] = (0xc30f267cu >> (((unsigned)c0 & 0x10000u) & 31u));
                }
                if ((0x10000u ^ u3)) break;
            }
            garr[garr[u2 & 7u] & 7u] = -(unsigned)((int)~(fuel + ((unsigned)h0 << ((unsigned)d0 & 31u))) < (int)(m0 << (i2 & 31u)));
            if ((unsigned)(w0 >> 29)) {
                if ((u2 * (0xdade2c3bu + a0[u1 & 3u]))) break;
                *mp = (1u + (((unsigned)((unsigned)h1 < (unsigned)w0) * (unsigned)c1) + (unsigned)(w0 >> 29)));
                continue; (void)((0xffffffffu % (u0 | 1u)));
                if ((unsigned)(signed char)(unsigned)((short)(unsigned)b0 > (signed char)(r0.y % ((unsigned)c0 | 1u)))) break;
                while (0u) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (unsigned)!((0x10000u << (0x8a62f60du & 31u)) | p1);
                    c0 = (unsigned char)((unsigned)((short)((unsigned)h1 ? (unsigned)h1 : p0) > (signed char)r0.y) + g0);
                }
            } else {
                v0 = -(unsigned)(6u && g0);
            }
            if ((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)f0)) goto done;
        }
        if ((0xffffffffu / (0x7fffffffu | 1u))) break;
        if ((i1 & (unsigned)h1)) continue;
        break; (void)((0xac2514d1u % ((unsigned)c0 | 1u)));
    } while (i0++ < 5u && (unsigned)((int)~(i2 + (unsigned)h1) < (int)(unsigned)(w0 >> 29)));
    if ((unsigned)x0) {
        goto L3;
        if ((p0 + 9u)) goto L2;
        if (fuel < 8u) return (unsigned)((unsigned)s0 < 0x10000u);
        h0 = (short)g1;
    }
    { unsigned t4; double z4; if (((unsigned)d0) & 1u) { t4 = garr[u2 & 7u]; z4 = (double)(((3u + fuel)) & 255u); } if (((unsigned)d0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        switch ((((unsigned)c1 | 0x4f444bc1u) % ((unsigned)(x0 >> 70) | 1u)) & 7u) {
            while (i0++ < 2u && (garr[i1 & 7u] & g0)) { if (--fuel == 0u) goto done;
                a0[u1 & 3u] = (unsigned)((int)(unsigned)((int)(unsigned)h0 < (int)*mp) < (int)(unsigned)(x0 >> 70));
                h1 = (unsigned short)(h1 + (unsigned)w0);
                if (-(unsigned)((short)(a0[i0 & 3u] | 0u) > (signed char)1u)) goto done;
                while (((0xf5773e31u | (unsigned)(x0 >> 70)) & p1)) { if (--fuel == 0u) goto done;
                    r0.y ^= g0;
                    if ((unsigned)h1) goto L3;
                    case 3u: ;
                    goto L2;
                    if ((0x80000000u + ((unsigned)l0 ^ *q0))) goto L4;
                    do { if (--fuel == 0u) goto done;
                        case 0u: ;
                        garr[garr[i1 & 7u] & 7u] = (unsigned)((unsigned)h0 == (unsigned)(0xc9a25decu == (unsigned)l0));
                    } while (i2++ < 7u && (unsigned)(signed char)(p0 + *mp));
                }
                case 1u: ;
                switch ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)(w0 >> 29)) & 7u) {
                    case 1u: ;
                    if ((unsigned)e0) {
                        s0 = (int)((9u / (*mp | 1u)) & (0x7fffffffu >> (8u & 31u)));
                        do { if (--fuel == 0u) goto done;
                            q0 = &garr[(unsigned)(v0 || (0xffffffffu ? 0xea9885a6u : a0[u1 & 3u])) & 7u];
                        } while (i1++ < 7u && ((unsigned)x0 ? u2 : (unsigned)e0));
                        if (u3 == 7u) return ((unsigned)b0 | r0.y);
                        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                            if ((unsigned)((int)i2 < (int)(unsigned)(short)(unsigned)((int)(unsigned)d0 < (int)a0[u1 & 3u]))) goto done;
                        }
                    }
                    h0 = (short)((unsigned)s1 * (unsigned)s1);
                    case 2u: ;
                    switch (0x7fffffffu & 7u) {
                        b0 = ((unsigned)c1 / ((unsigned)((0x6a472a30u << (((unsigned)e0 % (p0 | 1u)) & 31u)) == u0) | 1u)) != 0u;
                        if ((unsigned)(signed char)(unsigned)((unsigned)((short)(unsigned)x0 > (signed char)garr[i1 & 7u]) < (unsigned)d0)) goto L1;
                    }
                }
            }
            do { if (--fuel == 0u) goto done;
                while ((g1 * (unsigned)(p0 == i1))) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (~(2u * i2) % ((unsigned)((short)p0 > (signed char)(unsigned)x0) | 1u));
                    l0 = (long)((unsigned long)l0 + (unsigned)l0);
                    for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((g0 ^ 0xffffffffu)) break;
                        default: ;
                        if (0x10000u) {
                            case 2u: ;
                            break;
                            case 7u: ;
                            q0 = &garr[(p0 & u3) & 7u];
                            m0 ^= (unsigned)((int)0x7d325d16u < (int)(p0 * (unsigned)(m0 || (unsigned)b0)));
                        }
                        c1 = (signed char)(unsigned)(short)(unsigned)(garr[u2 & 7u] < 8u);
                    }
                    case 6u: ;
                    q0 = &garr[(u0 >> ((u1 & 6u) & 31u)) & 7u];
                    break;
                }
                u3 = u3 * 0x9e3779b1u + (unsigned)((0x833ae5f0u - (0xffffffffu | 0x7fffffffu)) || 0x7fffffffu);
                break;
                *q0 += (g1 + 8u);
                break;
                if ((0xffffffffu | (unsigned)(0xd9dbdacu < p1))) {
                    break;
                    r0.y ^= (unsigned)(3u || a0[i0 & 3u]);
                    *q0 = (unsigned)(0x3d3f963bu == (r0.x ? *mp : 0x7fffffffu));
                    e0 = e0 * 0.5L + (long double)(8u & 1023u);
                }
            } while (i0++ < 5u && u3);
            break;
            switch ((fuel ^ 0x72b48140u) & 7u) {
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    u1 = u1 * 0x9e3779b1u + (unsigned)(signed char)(-((unsigned)((int)7u < (int)0x80000000u) | 0x7fffffffu) + (unsigned)f0);
                    h0 = (short)(unsigned)(short)((unsigned)((short)i2 > (signed char)(unsigned)s0) >> ((unsigned)(fuel && i2) & 31u));
                    garr[(unsigned)((short)(unsigned)c0 > (signed char)6u) & 7u] = (i1 / (*q0 | 1u));
                }
            }
        }
    }
    if ((unsigned)(fuel == r0.y)) goto done;
    if (0xdee3a6f5u) {
        h0 = (short)(unsigned)((int)((*mp ? 0x80000000u : 0x80000000u) & 0x88e3e1a4u) >= (int)0x4cbc265cu);
        if ((unsigned)((p0 + p0) && 0x80000000u)) goto L3;
        { unsigned t5; double z5; if (((unsigned)(signed char)(unsigned)((short)i2 > (signed char)g1)) & 1u) { t5 = (unsigned)(unsigned char)(unsigned)((int)(r0.x + u3) < (int)5u); z5 = (double)(((unsigned)s0) & 255u); } if (((unsigned)(signed char)(unsigned)((short)i2 > (signed char)g1)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            if ((unsigned)((int)(unsigned)((int)(unsigned)s0 >= (int)(unsigned)f0) < (int)0x653240b0u)) goto L4;
            if ((unsigned)((int)-(unsigned)(0x80000000u || r0.x) >= (int)p2)) goto L2;
            while (i0++ < 4u && (u2 << ((unsigned)x0 & 31u))) { if (--fuel == 0u) goto done;
                if ((unsigned)b0) goto L4;
                if ((0x8f4236e5u % ((unsigned)d0 | 1u))) goto done;
                if ((unsigned)s0) continue;
            }
            if (((unsigned)h0 >> (0x97feddu & 31u))) goto L1;
            garr[p0 & 7u] = u2;
        }
        do { if (--fuel == 0u) goto done;
            u1 = (((unsigned)(signed char)(unsigned)(0x80000000u && i2) - p1) & u0);
            if (0x80000000u) break;
            break; (void)((unsigned)((unsigned)f0 < (0x97bfa2d0u / ((unsigned)l0 | 1u))));
            u2 += ((unsigned)((unsigned)s0 || (unsigned)(w0 >> 29)) >> ((unsigned)c0 & 31u));
            break; (void)(((unsigned)((unsigned)x0 == (unsigned)s0) | m0));
            if (r0.y) break;
        } while (i0++ < 2u && ((unsigned)x0 ? p1 : (unsigned)s0));
    } else {
        if (8u) goto L2;
        if (u1) goto L2;
    }
    h1 = (unsigned short)(h1 + (unsigned)(*q0 && 9u));
    goto L3;
    *q0 += ((unsigned)(signed char)(0xffffffffu << (0u & 31u)) / (p0 | 1u));
    goto L1;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(p0 || 3u)) goto L0;
            a0[(u0 * p2) & 3u] = (0x47e03c26u << ((1u ? r0.y : *mp) & 31u));
            r0.y ^= ((g0 ^ 0xcac7e0a2u) ^ (0x3da0c60cu ^ i1));
            garr[u1 & 7u] = (p1 - (*mp ^ i2));
            for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (-(unsigned)((short)0xa9ff2385u > (signed char)g0)) break;
            }
            if ((0x80000000u << (i1 & 31u))) break;
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            *mp = 0x10000u;
            l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)((int)u0 >= (int)(0x10000u * u2)));
            l0 = (long)((unsigned long)l0 + 0x80000000u);
        }
        i0 = *mp & 15u;
        e0 = e0 * 0.5L + (long double)(i1 & 1023u);
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((int)0x10000u >= (int)(unsigned)c0)) break;
            v0 = (~(unsigned)((unsigned)((unsigned)(w0 >> 29) < (unsigned)e0) && p2) * (unsigned)d0);
            f0 = f0 * 0.5f + (float)((unsigned)(x0 >> 70) & 255u);
            if ((0x10000u | (a0[u1 & 3u] * i1))) goto L1;
            u2 += (0xc772635fu * (unsigned)s1);
        } while (i1++ < 2u && (a0[i0 & 3u] & i0));
    }
    for (;;) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((int)u0 < (int)8u));
        d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)((short)(unsigned)((int)(unsigned)h1 >= (int)(unsigned)s1) > (signed char)(unsigned)e0) > (signed char)(unsigned)x0) & 1023u);
    }
    g0 = ((4u | 0xd7b4b075u) | 0u);
    goto L0;
    s1 = (int)((unsigned)s1 + ((i0 * 0x26e1a8b4u) ^ *mp));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)h1 && (unsigned)(0xffffffffu == (unsigned)c0)), (unsigned)((int)v0 < (int)p2), 3u); }
    if ((garr[i1 & 7u] << (u1 & 31u))) goto L2;
    d0 = d0 * 0.5 + (double)(((unsigned)(garr[u2 & 7u] || ((unsigned)h0 << (0x145c6c92u & 31u))) % (r0.y | 1u)) & 1023u);
    if (0x80000000u) goto L4;
    h1 = (unsigned short)(h1 + g0);
    c1 = (signed char)a0[u1 & 3u];
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)((unsigned)e0 - 0x10000u), (0x12eb390cu & (*mp / (6u | 1u))), (unsigned)h1); }
    m0 ^= (((unsigned)(w0 >> 29) / (*mp | 1u)) ^ u2);
    if (budget != 0u) { budget -= 1u; u0 = fn0((garr[u2 & 7u] / ((unsigned)((int)g1 >= (int)a0[i0 & 3u]) | 1u)), 5u, (unsigned)(i1 < p0)); }
    if ((unsigned)(short)(unsigned)(-(r0.y + (unsigned)e0) < 0x21f2cbeau)) {
        m0 ^= ((r0.x + (unsigned)c1) ^ (unsigned)h1);
        { unsigned t0; double z0; if (((unsigned)(8u < *q0)) & 1u) { t0 = m0; z0 = (double)(((unsigned)((int)(unsigned)(x0 >> 70) < (int)((unsigned)(w0 >> 29) % (garr[u2 & 7u] | 1u)))) & 255u); } if (((unsigned)(8u < *q0)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            if ((unsigned)(w0 >> 29)) {
                e0 = e0 * 0.5L + (long double)(((0xffffffffu ? (unsigned)(u3 || a0[i0 & 3u]) : (unsigned)c1) * 0xe91e83fcu) & 1023u);
            } else {
                switch ((unsigned)((int)0x80000000u < (int)-((unsigned)f0 % ((unsigned)f0 | 1u))) & 7u) {
                    if ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(0xefd6dd30u >> (0x7fffffffu & 31u)))) goto L1;
                    while (i0++ < 7u && (unsigned)f0) { if (--fuel == 0u) goto done;
                        *q0 = (unsigned)((int)(unsigned)((int)9u < (int)(unsigned)!(r0.x & 3u)) < (int)p1);
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)((short)v0 > (signed char)(a0[u1 & 3u] >> (g0 & 31u))) >= (int)(unsigned)h0));
                        L0: if (--fuel == 0u) goto done;
                        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((0x249152aeu << ((unsigned)s0 & 31u)) < 0x80000000u), (unsigned)!(g1 - a0[u1 & 3u]), (*mp << (garr[i1 & 7u] & 31u))); }
                            b0 = ((7u * (unsigned)e0) + (unsigned)((unsigned)s0 || ~(unsigned)((short)p0 > (signed char)(unsigned)h1))) != 0u;
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)e0 < (int)0x13422a5au), p0, ((unsigned)!(unsigned)((int)0xffffffffu < (int)0u) * (unsigned)(x0 >> 70))); }
                            if (budget != 0u) { budget -= 1u; u2 = fn0(*q0, garr[u2 & 7u], (*q0 & m0)); }
                            m0 ^= (i1 ? u3 : m0);
                            u1 += ~((unsigned)((short)0xffffffffu > (signed char)fuel) * (unsigned)((unsigned)x0 && 0x602f2798u));
                        }
                    }
                    if (u3 == 7u) return ((garr[u2 & 7u] / (r0.y | 1u)) << (0xb782dd5cu & 31u));
                    do { if (--fuel == 0u) goto done;
                        if (((unsigned)w0 - (unsigned)(w0 >> 29))) {
                            u0 = u0 * 0x9e3779b1u + -(unsigned)((int)(unsigned)((short)p0 > (signed char)0xffffffffu) < (int)r0.y);
                            u2 += (unsigned)(-((unsigned)l0 / (u3 | 1u)) || (unsigned)((short)(unsigned)((int)u0 < (int)0x1cfc3282u) > (signed char)0x9410b1a6u));
                            garr[(unsigned)f0 & 7u] = i1;
                            c1 = (signed char)(unsigned)(short)(unsigned)((short)i2 > (signed char)0x7fffffffu);
                            if (budget != 0u) { budget -= 1u; u2 = fn0((0x38c6f613u ^ 0xa058003cu), (unsigned)(unsigned char)(unsigned)((int)0x7fffffffu >= (int)0x7fffffffu), ((unsigned)c1 >> (0x80000000u & 31u))); }
                            if (0x18ad50d8u) goto L3;
                        } else {
                            w0 ^= (unsigned long long)(unsigned)(3u == (unsigned)h0) << ((unsigned)((short)*mp > (signed char)a0[i0 & 3u]) & 63u);
                            L1: if (--fuel == 0u) goto done;
                            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(((unsigned)c0 % (~(0x6eefc247u - (unsigned)s0) | 1u)) % (0x442dfa1cu | 1u));
                            goto L1;
                        }
                        q0 = &garr[r0.x & 7u];
                        L2: if (--fuel == 0u) goto done;
                        r0.y ^= ((unsigned)(0x41558e8cu && (u1 % ((unsigned)s1 | 1u))) ^ a0[u1 & 3u]);
                    } while (i0++ < 5u && 0xffffffffu);
                    while (i0++ < 3u && (unsigned)((short)r0.y > (signed char)(unsigned)e0)) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (unsigned)h0);
                        if (u0) {
                            i0 = u1 & 15u;
                            u2 += (unsigned)((int)(unsigned)h0 >= (int)((unsigned)((unsigned)(w0 >> 29) == 7u) << ((0x80000000u + u0) & 31u)));
                            if ((unsigned)f0) break;
                            x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)((unsigned)(unsigned char)(0x5f6b4b06u / ((unsigned)(4u && 2u) | 1u)) | (unsigned)w0);
                            q0 = &garr[(unsigned)((unsigned)(short)(i2 ? a0[i0 & 3u] : fuel) && 6u) & 7u];
                        }
                    }
                }
                u0 = u0 * 0x9e3779b1u + ((0xffffffffu - i1) % ((unsigned)((unsigned)e0 < p2) | 1u));
            }
            L3: if (--fuel == 0u) goto done;
            m0 ^= (unsigned)(i2 && (fuel ? 7u : p0));
            switch ((unsigned)c0 & 7u) {
                for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        g0 = (unsigned)((unsigned)((int)garr[u2 & 7u] >= (int)a0[i0 & 3u]) < ((unsigned)f0 / ((unsigned)(i1 < (unsigned)x0) | 1u)));
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)((short)(unsigned)s0 > (signed char)0xa9388c1cu) >> (*q0 & 31u)), (garr[u2 & 7u] >> ((unsigned)(m0 == *q0) & 31u)), 7u); }
                        w0 ^= (unsigned long long)(6u - u1) << ((unsigned)(short)((i1 ? (unsigned)e0 : (7u | (unsigned)w0)) & 0x7fffffffu) & 63u);
                    }
                    break; (void)((unsigned)(short)(*mp & garr[i1 & 7u]));
                }
            }
            x0 = x0 * 0x100000001b3ull + ((unsigned)h1 | u3);
            if (budget != 0u) { budget -= 1u; u0 = fn0((u2 | ((unsigned)x0 * (unsigned)(w0 >> 29))), ((p0 >> ((unsigned)(x0 >> 70) & 31u)) - a0[i0 & 3u]), 2u); }
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((r0.y ? u0 : 4u), ((u3 & u1) >> ((unsigned)h0 & 31u)), 0x7fffffffu); }
    L4: if (--fuel == 0u) goto done;
    if ((unsigned)d0) goto L3;
    x0 = x0 * 0x100000001b3ull + 0x76c7d269u;
    if ((unsigned)(p2 || (g1 / (0x8ae7c99u | 1u)))) goto L2;
    x0 = x0 * 0x100000001b3ull + (garr[u2 & 7u] % (p2 | 1u));
    i0 = (unsigned)((short)u1 > (signed char)(unsigned)(short)((unsigned)s1 >> ((unsigned)c0 & 31u))) & 15u;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)s0 & 7u) {
            w0 ^= (unsigned long long)(unsigned)s0 << (((unsigned)s0 << (((r0.x & 0x80000000u) & (unsigned)x0) & 31u)) & 63u);
            if (budget != 0u) { budget -= 1u; u3 = fn0((*q0 | u3), u1, (unsigned)!(unsigned)(*q0 == i1)); }
            case 3u: ;
            if (budget != 0u) { budget -= 1u; u0 = fn0((0x10000u % (a0[i0 & 3u] | 1u)), ~((unsigned)s0 << ((unsigned)e0 & 31u)), (-(7u << ((unsigned)c1 & 31u)) * garr[i1 & 7u])); }
            if ((0x10000u % ((unsigned)(w0 >> 29) | 1u))) {
                h0 = (short)(8u >> ((unsigned)((short)0x7ee56b61u > (signed char)g0) & 31u));
                *q0 += (unsigned)((int)0xcc0b5e19u >= (int)(unsigned)e0);
                if (~(i0 >> (9u & 31u))) break;
                case 4u: ;
                w0 ^= (unsigned long long)g0 << (0x767c10bcu & 63u);
                x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)(unsigned)((int)0xffffffffu < (int)(g0 * (u2 % ((unsigned)e0 | 1u))));
            } else {
                { unsigned t1; double z1; if ((((unsigned)((unsigned)c1 < (unsigned)h0) | (unsigned)s1)) & 1u) { t1 = (8u ? (unsigned)x0 : 2u); z1 = (double)(((unsigned)((int)0x7fffffffu >= (int)(unsigned)w0)) & 255u); } if ((((unsigned)((unsigned)c1 < (unsigned)h0) | (unsigned)s1)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    if ((unsigned)((int)r0.x >= (int)(unsigned)s0)) goto L4;
                }
                break; (void)((2u >> ((unsigned)((int)p2 < (int)0xb9bd47d7u) & 31u)));
            }
        }
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                break; (void)((unsigned)h1);
                if (((unsigned)(short)(m0 ^ 0xc7ee537cu) * v0)) break;
                for (;;) { if (--fuel == 0u) goto done;
                    h0 = (short)(0x80000000u << ((u1 ? g0 : (unsigned)e0) & 31u));
                    if (((unsigned)(short)((unsigned)c0 % (fuel | 1u)) / (0x10000u | 1u))) break;
                    u2 ^= (garr[i1 & 7u] / ((unsigned)(p0 == p2) | 1u));
                }
                *q0 += ((*q0 >> ((unsigned)((short)(unsigned)w0 > (signed char)0xef88d2dcu) & 31u)) / (*mp | 1u));
                { unsigned t2; double z2; if (((unsigned)((unsigned)b0 || a0[i0 & 3u])) & 1u) { t2 = (0x85d8da31u >> (garr[u2 & 7u] & 31u)); z2 = (double)(((unsigned)((short)((unsigned)(w0 >> 29) * (unsigned)x0) > (signed char)v0)) & 255u); } if (((unsigned)((unsigned)b0 || a0[i0 & 3u])) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    r0.y ^= ~(u1 | (unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)i0 >= (int)0x7fffffffu) < (int)0x6c0b1e8du));
                    if (budget != 0u) { budget -= 1u; u3 = fn0(fuel, (unsigned)(signed char)((unsigned)((int)u2 < (int)0x7fffffffu) << (0x10000u & 31u)), 3u); }
                    if (budget != 0u) { budget -= 1u; u2 = fn0(0xffffffffu, (u0 - (unsigned)(0x252f45b2u < a0[u1 & 3u])), *q0); }
                    if (((unsigned)(p2 && u2) >> ((unsigned)h0 & 31u))) break;
                    if ((0xb3fead1fu ^ i1)) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(6u, (unsigned)((i1 >> (*mp & 31u)) < (unsigned)(x0 >> 70)), (unsigned)((int)0x8f1ee87cu >= (int)(u3 >> (8u & 31u)))); }
                }
            } while (i2++ < 4u && (0x7fffffffu + u2));
            q0 = &garr[(unsigned)((short)(unsigned)h0 > (signed char)v0) & 7u];
            *mp = ((unsigned)(unsigned char)(unsigned)((unsigned)((int)(unsigned)(w0 >> 29) >= (int)r0.x) == 3u) + fuel);
            h0 = (short)((unsigned)b0 - i2);
            i0 = ((unsigned)!(unsigned)((unsigned)(0x10000u == garr[i1 & 7u]) || (unsigned)!(unsigned)(u1 == (unsigned)d0)) | m0) & 15u;
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((0x7fffffffu * (unsigned)c1)) break;
                switch ((unsigned)(signed char)(unsigned)(garr[i1 & 7u] || (v0 | r0.x)) & 7u) {
                    *q0 += ((0xbf332307u / (g0 | 1u)) | (unsigned)((int)(unsigned)(w0 >> 29) < (int)0x80000000u));
                    case 6u: ;
                }
                if (((0xffffffffu | fuel) >> (8u & 31u))) goto L4;
                if (budget != 0u) { budget -= 1u; u0 = fn0(u3, (unsigned)((unsigned)s0 && (unsigned)(9u || 2u)), ((unsigned)h1 | 0xffffffffu)); }
                m0 ^= 0x32fe86dfu;
                for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)((unsigned)((short)(unsigned)s1 > (signed char)*mp) && m0));
                    if ((0x10000u / (garr[i1 & 7u] | 1u))) break;
                    w0 = w0 * 6364136223846793005ull + (unsigned)(p0 < (unsigned)(garr[i1 & 7u] && 0x9c835a60u));
                    *mp = ((unsigned)c0 * (unsigned)((int)i0 >= (int)0x3775e2d7u));
                    w0 ^= (unsigned long long)0u << ((unsigned)(signed char)(unsigned)((fuel << ((unsigned)((unsigned)(0xffb7a7au || garr[i1 & 7u]) == p2) & 31u)) && 0xb025ff0bu) & 63u);
                }
            }
        } while (i1++ < 3u && (g0 ? fuel : (unsigned)(w0 >> 29)));
    }
    goto done;
    s0 = (int)(unsigned)((int)(i2 * (i1 >> (0x10000u & 31u))) >= (int)(r0.x >> (0x9498f065u & 31u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch ((unsigned)((int)u2 < (int)(unsigned)(0x7fffffffu < (unsigned)d0)) & 7u) {
        s0 = (int)(0x1e297c5bu & (unsigned)h0);
        garr[((unsigned)h0 | 0x10000u) & 7u] = (unsigned)e0;
        switch ((unsigned)((int)6u < (int)garr[u2 & 7u]) & 7u) {
            L0: if (--fuel == 0u) goto done;
        }
        case 7u: ;
        u0 += (unsigned)(unsigned char)(unsigned)((unsigned)(u3 == 0x80000000u) == 2u);
        case 1u: ;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)l0 ^ (m0 * r0.y)), ((unsigned)d0 << (v0 & 31u)), (unsigned)(unsigned char)((unsigned)f0 ? r0.y : 0xbaaf0de2u)); }
    h0 = (short)(unsigned)(short)(unsigned)(~(u0 - ~(unsigned)(0xffffffffu && (unsigned)x0)) && 0x5d1bef71u);
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)i2 > (signed char)a0[u1 & 3u]), (unsigned)(p1 == (*mp - 0x6b5d5996u)), (3u << (2u & 31u))); }
    if ((i2 ^ 0x5e0bcf1fu)) goto L4;
    if ((unsigned)!((unsigned)s0 / (*q0 | 1u))) goto L4;
    while (i0++ < 6u && 0x7fffffffu) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            if (((unsigned)f0 + u2)) goto L0;
        }
    }
    e0 = e0 * 0.5L + (long double)((6u % ((2u * (unsigned)e0) | 1u)) & 1023u);
    if ((p0 >> ((m0 >> ((unsigned)f0 & 31u)) & 31u))) goto L1;
    goto L2;
    { unsigned t0; double z0; if ((((r0.x | 0u) << (g1 & 31u))) & 1u) { t0 = 0x7fffffffu; z0 = (double)(((unsigned)c1) & 255u); } if ((((r0.x | 0u) << (g1 & 31u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        v0 = (unsigned)b0;
    }
    i1 = (unsigned)w0 & 15u;
    while (i0++ < 2u && 0x80000000u) { if (--fuel == 0u) goto done;
        v0 = (unsigned)(short)((unsigned)((short)3u > (signed char)(0x9cc851dbu << (0xbfffbe39u & 31u))) ^ (unsigned)b0);
        if (g1) {
            if (u0) {
                while (i1++ < 5u && ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)(x0 >> 70)) & 2u)) { if (--fuel == 0u) goto done;
                    b0 = ((unsigned)s1 & (unsigned)(unsigned char)(0x94ac86b0u % ((p1 % (0x34870da9u | 1u)) | 1u))) != 0u;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((unsigned)e0 < (unsigned)h0) - (unsigned)w0), (unsigned)h0, ((unsigned)(unsigned char)(unsigned)(0xedd41c2cu == p0) + (unsigned)c0)); }
                }
                *q0 += (unsigned)((short)p1 > (signed char)(r0.x + (unsigned)(x0 >> 70)));
                *q0 += ((unsigned)l0 * ((unsigned)s1 << (garr[i1 & 7u] & 31u)));
            }
            if ((unsigned)(p1 && 0xc4b13185u)) {
                do { if (--fuel == 0u) goto done;
                    c1 = (signed char)-(~(i0 & (unsigned)((int)(g1 << (garr[i1 & 7u] & 31u)) >= (int)0x80000000u)) << (u0 & 31u));
                    s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)!(unsigned)((short)(unsigned)h1 > (signed char)a0[i0 & 3u]) > (signed char)0x7fffffffu));
                    break; (void)((unsigned)((unsigned)(w0 >> 29) == (unsigned)(x0 >> 70)));
                } while (i1++ < 3u && 0x877edfeeu);
                if (p0) break;
            }
            w0 = w0 * 6364136223846793005ull + (((8u / (i1 | 1u)) / (8u | 1u)) << (4u & 31u));
            m0 ^= ((unsigned)d0 ? (unsigned)x0 : u0);
            do { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                if (((6u ^ 0xa98d8077u) / (*q0 | 1u))) break;
                { unsigned t1; double z1; if ((0x80000000u) & 1u) { t1 = ((unsigned)c1 * 0u); z1 = (double)(((0xa1ee3192u * *mp)) & 255u); } if ((0x80000000u) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    q0 = &garr[(unsigned)(unsigned char)((garr[i1 & 7u] << (0x10000u & 31u)) >> ((unsigned)c0 & 31u)) & 7u];
                    if (u0) goto L3;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)s0, fuel, (unsigned)!(v0 - (4u << (a0[u1 & 3u] & 31u)))); }
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(((unsigned)h1 >> (r0.y & 31u)) == i0), *q0, ((p1 >> ((unsigned)h0 & 31u)) * (unsigned)h0)); }
                    L2: if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((0x80000000u % (0x10000u | 1u)), 0x7fffffffu, 0xaf7df4a9u); }
                }
                if ((p1 / (u2 | 1u))) {
                    if ((-(a0[i0 & 3u] * v0) ^ u2)) goto L0;
                    L3: if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((9u * (unsigned)l0), (unsigned)(0x38ce8ba9u && 0x5327b952u), 0u); }
                    switch ((unsigned)(short)((unsigned)d0 ^ (v0 ^ 0xfd86edd8u)) & 7u) {
                        if (u3 == 7u) return ((unsigned)f0 ^ (unsigned)h0);
                        case 0u: ;
                        f0 = f0 * 0.5f + (float)((~(0xeef69ea1u - 0x10000u) % ((unsigned)(unsigned char)(unsigned)(*q0 < (unsigned)s0) | 1u)) & 255u);
                        if ((unsigned)((short)(unsigned)e0 > (signed char)0x10000u)) goto L2;
                    }
                    h1 = (unsigned short)(h1 + (unsigned)(unsigned char)((unsigned)((unsigned)(x0 >> 70) == (0u ? 0x6bf504e2u : (unsigned)(x0 >> 70))) + (unsigned)(w0 >> 29)));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((0x10000u - p0), 0x10000u, (unsigned)((int)*q0 < (int)g0)); }
                }
                f0 = f0 * 0.5f + (float)((unsigned)b0 & 255u);
                if ((0x10000u & (unsigned)((short)i2 > (signed char)0x80000000u))) goto L3;
            } while (i1++ < 4u && 0x80000000u);
        }
        g0 = (unsigned)(signed char)(unsigned)((0x10000u * g1) < *mp);
    }
    f0 = f0 * 0.5f + (float)((unsigned)h0 & 255u);
    if (((unsigned)f0 - (i0 + 9u))) {
        if ((p2 << (0x10000u & 31u))) goto L2;
        u2 += ((unsigned)((unsigned)c1 && 0xffffffffu) + (unsigned)f0);
        f0 = f0 * 0.5f + (float)(((0x10000u ^ (0x10000u ^ p1)) & a0[u1 & 3u]) & 255u);
        h1 = (unsigned short)(h1 + a0[u1 & 3u]);
    } else {
        u1 = (unsigned)c0;
    }
    goto done;
    if (((unsigned)l0 - a0[i0 & 3u])) goto L1;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        L4: if (--fuel == 0u) goto done;
    }
    l0 = (long)((unsigned long)l0 + ((unsigned)s1 % (u3 | 1u)));
    if (g1) goto done;
    r0.x = (unsigned)(0xc6a01660u || (unsigned)((unsigned)h0 || (0x313eab2au << (i1 & 31u))));
    c1 = (signed char)((0x10000u ? 0x15e12f20u : 0x7fffffffu) - ~(0x1c61b5ffu & 0x3e621f14u));
    do { if (--fuel == 0u) goto done;
        if (((unsigned)l0 * p1)) break;
    } while (i0++ < 7u && (4u >> (g1 & 31u)));
    w0 ^= (unsigned long long)(unsigned)(i0 == i0) << (0xde65f1c3u & 63u);
    if ((unsigned)(p0 < (u1 << ((unsigned)s0 & 31u)))) {
        u1 ^= (unsigned)((short)((unsigned)c1 << (((unsigned)x0 << ((unsigned)s1 & 31u)) & 31u)) > (signed char)garr[u2 & 7u]);
        if (((unsigned)((int)(unsigned)h1 < (int)(unsigned)e0) << ((unsigned)d0 & 31u))) goto done;
        goto L3;
    }
    h1 = (unsigned short)(h1 + 0x53166fb8u);
    goto L0;
    u2 ^= (v0 / (~(unsigned)((short)a0[u1 & 3u] > (signed char)*mp) | 1u));
    q0 = &garr[0xffffffffu & 7u];
    if (u3 == 7u) return ((unsigned)c1 + 0xffffffffu);
    v0 = (unsigned)((unsigned)(5u || (unsigned)s0) || ((unsigned)c1 >> ((unsigned)x0 & 31u)));
    if (budget != 0u) { budget -= 1u; u2 = fn0(-(u3 << (9u & 31u)), (0xc60726du * 4u), 0x6075321eu); }
    if ((a0[i0 & 3u] - p1)) {
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            u3 ^= (unsigned)((unsigned)((unsigned)(signed char)(unsigned)(0x4bc2f55cu && a0[i0 & 3u]) || (unsigned)(unsigned char)(a0[i0 & 3u] / (0x80000000u | 1u))) == (unsigned)e0);
            if ((((unsigned)(w0 >> 29) - p1) + (unsigned)s1)) {
                if (p2) break;
                v0 = ((0x574c28b7u % ((unsigned)l0 | 1u)) | (unsigned)(short)(*mp + ((unsigned)d0 / (r0.x | 1u))));
            } else {
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)((unsigned)l0 - 0xffffffffu) >= (int)(unsigned)((int)0x7fffffffu >= (int)(unsigned)h0));
                break; (void)(p0);
                if (0x33bfe870u) {
                    v0 = (unsigned)(0x80000000u == 0x7922db9du);
                } else {
                    if ((a0[u1 & 3u] << ((unsigned)l0 & 31u))) break;
                }
                if (0x10000u) {
                    if ((unsigned)(0xf329f4ceu == 3u)) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((g1 | ((unsigned)(w0 >> 29) % (0xcdb8d269u | 1u))), ((i0 * (unsigned)c0) % ((unsigned)s1 | 1u)), (unsigned)s0); }
                    s0 = (int)(u0 / ((unsigned)d0 | 1u));
                    if ((unsigned)((int)*mp < (int)u2)) {
                        u2 ^= (unsigned)(x0 >> 70);
                        if (budget != 0u) { budget -= 1u; u1 = fn1(a0[u1 & 3u], (unsigned)(0x10000u && (unsigned)((int)0x80000000u < (int)0xdd70530fu)), (unsigned)(g0 && *mp)); }
                        r0.y ^= (unsigned)c0;
                        v0 = (unsigned)x0;
                    }
                    while (i1++ < 2u && (u0 + (unsigned)f0)) { if (--fuel == 0u) goto done;
                        switch ((unsigned)(((unsigned)(w0 >> 29) << (0xf2de84bfu & 31u)) || garr[i1 & 7u]) & 7u) {
                            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(g0 < a0[u1 & 3u]), 0x6aeaefd2u, (unsigned)(*mp || (unsigned)(signed char)(unsigned)(a0[u1 & 3u] && 0x20e89705u))); }
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)x0, (unsigned)c0, ((unsigned)h1 - (unsigned)b0)); }
                        break; (void)(((unsigned)s0 & (0x7fffffffu & (unsigned)b0)));
                        r0.y ^= (unsigned)((short)(unsigned)(r0.y == m0) > (signed char)(unsigned)s1);
                        c0 = (unsigned char)((unsigned)b0 / ((unsigned)(0x1f8ac334u < a0[u1 & 3u]) | 1u));
                    }
                    do { if (--fuel == 0u) goto done;
                        *mp = ((unsigned)l0 / ((unsigned)(9u == i0) | 1u));
                        if (((unsigned)d0 ^ (unsigned)b0)) goto L4;
                        if (~(u1 - (unsigned)(0xffffffffu || 6u))) break;
                        *mp = (unsigned)((int)(unsigned)(((unsigned)f0 | u0) && g0) >= (int)u0);
                        for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                            g0 = (unsigned)l0;
                            if (budget != 0u) { budget -= 1u; u1 = fn1((0xc5c5a60du - (unsigned)((int)0x7fffffffu >= (int)u2)), (unsigned)((short)(unsigned)w0 > (signed char)6u), a0[u1 & 3u]); }
                            e0 = e0 * 0.5L + (long double)((unsigned)(signed char)((0x80000000u - 0xffffffffu) | 0xffffffffu) & 1023u);
                            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(0xffffffffu == (unsigned)((unsigned)c1 < u2)), (unsigned)((int)(unsigned)s1 < (int)(unsigned)((unsigned)(x0 >> 70) < *q0)), (m0 / ((unsigned)((int)garr[i1 & 7u] >= (int)fuel) | 1u))); }
                            if (((p1 | (unsigned)c1) - (unsigned)h1)) break;
                        }
                        if ((i1 % (0x3c20c0e1u | 1u))) break;
                    } while (i1++ < 6u && (unsigned)(u1 || r0.y));
                } else {
                    w0 ^= (unsigned long long)0xcbbed257u << (((unsigned)((unsigned)(w0 >> 29) == r0.y) * i0) & 63u);
                    e0 = e0 * 0.5L + (long double)((((p2 + 0x2445fd06u) * (unsigned)f0) | (unsigned)((int)0xffffffffu < (int)7u)) & 1023u);
                }
            }
            a0[(v0 * i2) & 3u] = ~((unsigned)s0 >> ((unsigned)(w0 >> 29) & 31u));
        }
        if ((unsigned)f0) goto L0;
        garr[(unsigned)(0xffffffffu < 0x80000000u) & 7u] = (6u - u1);
    }
    h0 = (short)(unsigned)((int)*mp < (int)(0x10000u ^ p1));
    if ((unsigned)(fuel && (unsigned)h1)) goto L3;
    r0.x = p0;
    w0 = w0 * 6364136223846793005ull + i0;
    if ((((unsigned)w0 >> ((unsigned)c0 & 31u)) >> (0x7fffffffu & 31u))) goto L2;
    { unsigned t2; double z2; if (((unsigned)((short)(fuel / (a0[u1 & 3u] | 1u)) > (signed char)0x10000u)) & 1u) { t2 = 3u; z2 = (double)(((-(unsigned)((unsigned)h0 || 8u) - (unsigned)e0)) & 255u); } if (((unsigned)((short)(fuel / (a0[u1 & 3u] | 1u)) > (signed char)0x10000u)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        if (budget != 0u) { budget -= 1u; u0 = fn0(0x39ca37bdu, 0xc8d68b69u, ((unsigned)(m0 && (unsigned)f0) + a0[i0 & 3u])); }
        if ((unsigned)((int)(unsigned)c0 < (int)p1)) goto L0;
        { unsigned t3; double z3; if (((unsigned)c1) & 1u) { t3 = (unsigned)((short)*q0 > (signed char)*mp); z3 = (double)((m0) & 255u); } if (((unsigned)c1) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            l0 = (long)((unsigned long)l0 + ~(((*mp >> (0xfaf8b86cu & 31u)) / (1u | 1u)) << (u2 & 31u)));
            if ((unsigned)(signed char)(unsigned)((short)(u1 >> (0x80000000u & 31u)) > (signed char)*q0)) goto L2;
            c0 = (unsigned char)(unsigned)(((unsigned)((unsigned)b0 && (unsigned)(0xfca247ccu < u0)) ^ (unsigned)b0) == (unsigned)d0);
            f0 = f0 * 0.5f + (float)((unsigned)d0 & 255u);
        }
    }
    if (0xc307cb01u) {
        s0 = (int)((unsigned)h1 ? (unsigned)(0xffffffffu && (unsigned)d0) : (unsigned)s0);
        h0 = (short)(unsigned)((int)fuel < (int)*mp);
        while (i0++ < 5u && 0x7fffffffu) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(u2 % ((unsigned)(w0 >> 29) | 1u)) >= (int)u2)) goto L0;
            if (*mp) continue;
            break; (void)(0x3bbcca10u);
            f0 = f0 * 0.5f + (float)(((unsigned)d0 / ((unsigned)((unsigned)d0 || u2) | 1u)) & 255u);
            do { if (--fuel == 0u) goto done;
                h0 = (short)(unsigned)(((((unsigned)c0 - (unsigned)c0) & *mp) ^ m0) && (unsigned)l0);
            } while (i1++ < 5u && (unsigned)l0);
            break; (void)(~((unsigned)(0x10000u || (unsigned)(w0 >> 29)) / (p0 | 1u)));
        }
    } else {
        if (((unsigned)c1 ? 0x10000u : 0xae91f10eu)) goto L4;
        if (fuel < 8u) return (unsigned)((int)(unsigned)x0 >= (int)a0[u1 & 3u]);
    }
    c0 = (unsigned char)(unsigned)((m0 ? (unsigned)b0 : (*q0 << ((unsigned)w0 & 31u))) == 0u);
    { unsigned t4; double z4; if (((unsigned)(0xffffffffu < i1)) & 1u) { t4 = u1; z4 = (double)(((p0 - 0x6d8bf58u)) & 255u); } if (((unsigned)(0xffffffffu < i1)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(fuel && a0[i0 & 3u]), (0x8b31616bu - (unsigned)c1), *mp); }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t5; double z5; if (((unsigned)(unsigned char)(a0[i0 & 3u] >> (u0 & 31u))) & 1u) { t5 = (r0.x + a0[i0 & 3u]); z5 = (double)(((unsigned)((int)(unsigned)e0 < (int)(0xa70923d0u << (r0.y & 31u)))) & 255u); } if (((unsigned)(unsigned char)(a0[i0 & 3u] >> (u0 & 31u))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                while (i1++ < 6u && 0xa2fca646u) { if (--fuel == 0u) goto done;
                    b0 = (8u % ((unsigned)(w0 >> 29) | 1u)) != 0u;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(0x10000u == i2) / (v0 | 1u)), (i0 % ((unsigned)(x0 >> 70) | 1u)), (g0 ^ 8u)); }
                    if (-((unsigned)s0 >> (*mp & 31u))) continue;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s0 / (r0.y | 1u)), (unsigned)(0x9f04605fu && *mp), ((unsigned)(signed char)(unsigned)(0x45c19301u || 0xb63c0f6au) >> ((unsigned)d0 & 31u))); }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(garr[i1 & 7u], (0xb674e4fbu << ((unsigned)(0x765d33abu || 0x40d1d775u) & 31u)), ~(unsigned)((short)v0 > (signed char)(i0 & p2))); }
                }
                if (((unsigned)(garr[i1 & 7u] == (unsigned)c0) & (unsigned)c1)) break;
                if ((unsigned)x0) break;
                f0 = f0 * 0.5f + (float)(~(5u ^ (garr[i1 & 7u] % ((unsigned)l0 | 1u))) & 255u);
            }
            g0 = 0x80000000u;
        }
        if ((unsigned)((short)g0 > (signed char)u3)) goto L4;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)((unsigned)b0 / ((m0 >> (u3 & 31u)) | 1u))) {
                if ((unsigned)(short)(p0 ? (unsigned)d0 : 0xffffffffu)) {
                    *q0 += ((unsigned)(signed char)(garr[i1 & 7u] / ((8u / (garr[u2 & 7u] | 1u)) | 1u)) + fuel);
                } else {
                    u2 = u2 * 0x9e3779b1u + (unsigned)((short)-(0x80000000u | (unsigned)((short)g1 > (signed char)0xffffffffu)) > (signed char)(unsigned)(short)(garr[u2 & 7u] << (0xffffffffu & 31u)));
                    if ((unsigned)l0) break;
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)h1 || (unsigned)((int)(unsigned)c0 < (int)(3u << (0xffffffffu & 31u)))));
                        f0 = f0 * 0.5f + (float)(~((unsigned)((unsigned)d0 < 3u) ^ (u3 / ((unsigned)((int)0xe1411926u >= (int)5u) | 1u))) & 255u);
                    }
                }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(*q0, 3u, (unsigned)!(unsigned)((int)garr[i1 & 7u] >= (int)garr[u2 & 7u])); }
        } while (i0++ < 6u && (p2 % ((unsigned)(signed char)(3u - (unsigned)s0) | 1u)));
        goto L2;
    }
    switch (u2 & 7u) {
        case 7u: ;
        case 1u: ;
        garr[((unsigned)s1 - 0xdece1fc8u) & 7u] = (0x80000000u / (-(unsigned)(9u || a0[u1 & 3u]) | 1u));
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)h1) break;
        do { if (--fuel == 0u) goto done;
            if ((v0 << ((p1 >> (g0 & 31u)) & 31u))) break;
        } while (i1++ < 2u && (p0 / ((unsigned)((short)0xaafcca43u > (signed char)(unsigned)f0) | 1u)));
        if (u2) break;
    } while (i0++ < 7u && (unsigned)((int)u2 < (int)(unsigned)(p2 || (unsigned)(x0 >> 70))));
    goto L0;
    if ((unsigned)(*q0 && (r0.x / (0x80000000u | 1u)))) goto L2;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + ~(unsigned)((int)7u >= (int)0xbac69a09u);
        if (((unsigned)e0 + (unsigned)((int)(unsigned)l0 < (int)r0.x))) {
            h0 = (short)g1;
            g1 += (unsigned)((unsigned)h1 < r0.x);
        }
        if (budget != 0u) { budget -= 1u; u0 = fn1((7u << (p2 & 31u)), (g0 + (g0 | (unsigned)f0)), 0x1fefe731u); }
        h0 = (short)(((unsigned)w0 + 0x46800c48u) & (unsigned)((unsigned)f0 || g0));
        if ((unsigned)((int)p2 >= (int)0xa0ff2cddu)) continue;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch (r0.x & 7u) {
        f0 = f0 * 0.5f + (float)(((unsigned)(6u && (unsigned)c0) | (r0.x - i2)) & 255u);
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)w0 * 6u) || 1u);
            switch (g1 & 7u) {
                if (-(0x80000000u >> (a0[i0 & 3u] & 31u))) {
                    case 6u: ;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((short)0xffffffffu > (signed char)(unsigned)((short)i2 > (signed char)garr[u2 & 7u]))) goto L0;
                        switch ((i1 & (unsigned)(0x13d845bau || (unsigned)d0)) & 7u) {
                            L1: if (--fuel == 0u) goto done;
                            L2: if (--fuel == 0u) goto done;
                            *q0 = (unsigned)((i2 ? 0x8a702143u : i1) < 0xc9c267bcu);
                            s0 = (int)(unsigned)(short)(unsigned)(0x337d037bu == (unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)c0 && p0) || u0));
                            if ((v0 + p2)) goto L1;
                        }
                        goto L1;
                    } while (i1++ < 5u && (0xffffffffu >> (0xd9ccc27u & 31u)));
                    if (budget != 0u) { budget -= 1u; u3 = fn1(u2, (unsigned)((int)a0[u1 & 3u] >= (int)1u), (unsigned)((int)v0 < (int)(unsigned)x0)); }
                    v0 = (~(unsigned)((unsigned)e0 == fuel) / ((unsigned)(signed char)(unsigned)(fuel || (unsigned)(signed char)(unsigned)((short)v0 > (signed char)u0)) | 1u));
                } else {
                    if (((unsigned)(i1 || garr[u2 & 7u]) | (unsigned)f0)) {
                        v0 = ~(unsigned)((int)(unsigned)h0 < (int)(0x37a76212u / ((unsigned)((unsigned)w0 < (unsigned)e0) | 1u)));
                        s0 = (int)(((0x20840229u + (unsigned)d0) - 0x49f94e6du) - 0x10000u);
                        L3: if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            i0 = (unsigned)((int)(8u << ((unsigned)((int)0x10000u < (int)(unsigned)(0x30fd7f9fu == r0.y)) & 31u)) >= (int)(unsigned)b0) & 15u;
                            if (fuel < 8u) return (unsigned)((short)((unsigned)w0 + ~((unsigned)x0 & (unsigned)d0)) > (signed char)i0);
                            x0 = x0 * 0x100000001b3ull + (unsigned)((int)~(unsigned)((int)0xffffffffu >= (int)*q0) < (int)(unsigned)((int)v0 < (int)(0x7fffffffu | fuel)));
                        } while (i1++ < 2u && 0x4b04f243u);
                        if ((unsigned)c0) continue;
                        case 2u: ;
                    }
                }
                g0 = ~((unsigned)((int)0x80000000u >= (int)4u) / ((g0 * (a0[i0 & 3u] % (r0.y | 1u))) | 1u));
                l0 = (long)((unsigned long)l0 + (u0 >> ((unsigned)((int)(garr[i1 & 7u] % (m0 | 1u)) < (int)garr[u2 & 7u]) & 31u)));
            }
            w0 = w0 * 6364136223846793005ull + (((0x10000u / (*mp | 1u)) * fuel) / (0x24c7dd86u | 1u));
            case 4u: ;
        }
        do { if (--fuel == 0u) goto done;
            g0 = v0;
        } while (i0++ < 2u && (unsigned)((garr[i1 & 7u] % (a0[i0 & 3u] | 1u)) || u2));
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)(unsigned)((int)u0 < (int)g1) >= (int)(unsigned)x0), r0.y, g0); }
        c0 = (unsigned char)(3u >> (((0x4395dd2du - (unsigned)h0) | (unsigned)(x0 >> 70)) & 31u));
        case 6u: ;
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)s0 ? (unsigned)e0 : (unsigned)(x0 >> 70)) && (unsigned)(x0 >> 70));
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)w0 & 7u) {
            L4: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)x0 >> (a0[i0 & 3u] & 31u)), (unsigned)(1u && (unsigned)((int)0x7fffffffu < (int)6u)), ((unsigned)c0 << (5u & 31u))); }
            { unsigned t0; double z0; if ((((0x80000000u & (unsigned)s1) + 7u)) & 1u) { t0 = (p1 >> (0xffffffffu & 31u)); z0 = (double)(((unsigned)(signed char)(unsigned)(i2 && (unsigned)!(unsigned)(1u == (unsigned)(w0 >> 29)))) & 255u); } if ((((0x80000000u & (unsigned)s1) + 7u)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)w0) {
                        g1 += ((r0.y ? a0[i0 & 3u] : r0.y) | (0xffffffffu + 0x10000u));
                        *mp = 9u;
                        for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                            b0 = (0x80000000u * (unsigned)((int)(unsigned)h0 < (int)(unsigned)(short)(unsigned)(i2 && (unsigned)s1))) != 0u;
                        }
                    }
                    r0.x = (unsigned)((int)(*q0 << (0x7fb27561u & 31u)) >= (int)((unsigned)(unsigned char)(unsigned)((int)0x10000u < (int)(unsigned)s0) | a0[i0 & 3u]));
                    u3 += (unsigned)e0;
                    i0 = (unsigned)(0x56cb632eu && 0x8d8fb7a4u) & 15u;
                    r0.x = (p0 ^ m0);
                }
                q0 = &garr[(unsigned)((unsigned)((short)garr[u2 & 7u] > (signed char)7u) && (unsigned)f0) & 7u];
                case 1u: ;
            }
            break; (void)(r0.x);
            x0 = x0 * 0x100000001b3ull + 9u;
            *mp = ((r0.x & u2) & (0x80000000u | (6u + a0[i0 & 3u])));
        }
        i0 = garr[i1 & 7u] & 15u;
        h1 = (unsigned short)(h1 + ((unsigned)(signed char)(unsigned)((int)0xe04a38ebu >= (int)g1) ^ a0[i0 & 3u]));
        a0[(u0 ^ v0) & 3u] = (unsigned)((unsigned)(unsigned char)(3u << ((((unsigned)c0 | 0xffffffffu) / (8u | 1u)) & 31u)) && p0);
    }
    h1 = (unsigned short)(h1 + (unsigned)(*mp < ((unsigned)(unsigned char)(r0.x & 1u) ? i1 : p1)));
    if (budget != 0u) { budget -= 1u; u2 = fn1(a0[i0 & 3u], 0xb03dab91u, (0xb2497d17u + (unsigned)l0)); }
    if (((unsigned)((unsigned)h0 && garr[i1 & 7u]) >> ((unsigned)w0 & 31u))) {
        if ((((unsigned)w0 << (0xe3837b8u & 31u)) / (0x5bdc195au | 1u))) {
            if ((unsigned)(short)((unsigned)c1 ^ 0xd199e479u)) goto L1;
        } else {
            if (r0.x) goto L2;
            if (((0xdffecceu * u1) ^ (unsigned)f0)) {
                *q0 += (r0.x >> ((unsigned)l0 & 31u));
                e0 = e0 * 0.5L + (long double)(((6u % (0x7fffffffu | 1u)) ^ u0) & 1023u);
                h0 = (short)(unsigned)((short)~(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)i1) > (signed char)(unsigned)(0xa57a57f2u && v0));
            }
            if ((unsigned)!(garr[u2 & 7u] / (0xffffffffu | 1u))) goto done;
            h1 = (unsigned short)(h1 + (unsigned)(4u < (i1 | (unsigned)(unsigned char)(fuel * i2))));
        }
        for (;;) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)d0;
            if (a0[i0 & 3u]) break;
            break; (void)((u3 * (fuel | 0x7727c7f3u)));
            s1 = (int)((unsigned)s1 + (0xffffffffu / (((unsigned)e0 - (~(r0.x / ((unsigned)x0 | 1u)) - a0[u1 & 3u])) | 1u)));
            u3 ^= 0x7f5ed184u;
        }
        if ((unsigned)((int)0xffffffffu >= (int)u3)) goto L4;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)(unsigned char)(unsigned)((int)(unsigned)w0 >= (int)0x2db95099u) == (unsigned)h0), ((unsigned)x0 ? 0xffffffffu : (unsigned)(w0 >> 29)), (unsigned)!(unsigned)(0x7fffffffu == (0x80000000u | a0[u1 & 3u]))); }
        if (garr[u2 & 7u]) {
            goto L0;
            if (1u) {
                if (((unsigned)l0 * (unsigned)((int)(unsigned)c1 < (int)u2))) goto L0;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)!(garr[u2 & 7u] >> (((unsigned)c0 % (a0[i0 & 3u] | 1u)) & 31u)), (unsigned)((unsigned)(i0 == garr[i1 & 7u]) < (unsigned)c1), ((unsigned)h1 - r0.y)); }
                goto L1;
                u2 ^= ((6u - (r0.x >> ((r0.x << (g0 & 31u)) & 31u))) | *mp);
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(i0 == u3) < (unsigned)e0);
            } else {
                d0 = d0 * 0.5 + (double)((unsigned)(p0 && (p1 + i0)) & 1023u);
            }
        } else {
            i1 = (unsigned)((unsigned)((int)0x7a4ea8bcu < (int)(0x80000000u * 8u)) == (unsigned)((short)0x76ddcd79u > (signed char)(unsigned)c0)) & 15u;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)e0 || (unsigned)d0), (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)!((unsigned)c0 << (6u & 31u))), ((unsigned)(unsigned char)(a0[i0 & 3u] / (5u | 1u)) & i2)); }
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                h0 = (short)u3;
                b0 = (unsigned)(x0 >> 70) != 0u;
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)((unsigned)f0 | (unsigned)x0) > (signed char)i2), v0, 7u); }
                if (budget != 0u) { budget -= 1u; u3 = fn0((0x866df650u - m0), (((unsigned)b0 >> (garr[i1 & 7u] & 31u)) >> (6u & 31u)), u2); }
                if ((unsigned)b0) goto L1;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)c1, ((unsigned)(garr[i1 & 7u] < 0xa8d1be1bu) / (fuel | 1u)), 3u); }
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)s0, *mp, ((unsigned)w0 % (fuel | 1u))); }
        }
    }
    garr[*q0 & 7u] = i1;
    if ((0x98900a46u % ((unsigned)h1 | 1u))) goto L1;
    *q0 += ((unsigned)w0 & (0x80000000u << ((unsigned)s0 & 31u)));
    if (0x80000000u) goto L4;
    if (budget != 0u) { budget -= 1u; u2 = fn2((*mp % ((unsigned)h1 | 1u)), (unsigned)((short)0x5c2cab90u > (signed char)(unsigned)((int)(unsigned)h0 >= (int)fuel)), ((unsigned)h1 - 0x10000u)); }
    u2 = u2 * 0x9e3779b1u + (unsigned)(x0 >> 70);
    while (i0++ < 3u && p0) { if (--fuel == 0u) goto done;
        { unsigned t1; double z1; if (((0x7fffffffu >> ((garr[u2 & 7u] << (u3 & 31u)) & 31u))) & 1u) { t1 = p1; z1 = (double)(((0x10000u * p1)) & 255u); } if (((0x7fffffffu >> ((garr[u2 & 7u] << (u3 & 31u)) & 31u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            if (((unsigned)b0 >> ((unsigned)b0 & 31u))) break;
            h1 = (unsigned short)(h1 + ((unsigned)b0 % ((unsigned)(short)(unsigned)((int)0xfc38270eu >= (int)(unsigned)h1) | 1u)));
        }
        break; (void)((unsigned)(unsigned char)(unsigned)(p0 == ~(i2 << (v0 & 31u))));
        do { if (--fuel == 0u) goto done;
            if (0x80000000u) goto L3;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)d0, v0, (unsigned)w0); }
        } while (i1++ < 7u && (unsigned)(short)((unsigned)s0 >> (0x10000u & 31u)));
        f0 = f0 * 0.5f + (float)((unsigned)w0 & 255u);
        continue; (void)((0x80000000u ^ i1));
        do { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)!((unsigned)((int)(r0.y << ((g1 / (u1 | 1u)) & 31u)) < (int)(unsigned)h0) + 0xc548b5a2u));
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                h0 = (short)(unsigned)((int)((unsigned)e0 / (5u | 1u)) < (int)(i1 | p0));
                if (budget != 0u) { budget -= 1u; u3 = fn0((fuel >> ((unsigned)(9u && u3) & 31u)), (unsigned)(short)(unsigned)(0x80000000u && (unsigned)(r0.x == u1)), garr[u2 & 7u]); }
                if (-(unsigned)((short)fuel > (signed char)(unsigned)((int)6u >= (int)0x7fffffffu))) break;
                c1 = (signed char)0x2fbc17eeu;
                if (fuel < 8u) return (unsigned)(short)((p0 << (-(2u >> ((unsigned)b0 & 31u)) & 31u)) - fuel);
                break; (void)((unsigned)e0);
            }
        } while (i1++ < 4u && (unsigned)d0);
    }
    if (u3 == 7u) return (unsigned)((int)(unsigned)(unsigned char)(a0[i0 & 3u] ? 0x4c9c44d1u : (unsigned)e0) < (int)(unsigned)(7u < 0xffffffffu));
    if (budget != 0u) { budget -= 1u; u0 = fn0(0xae84d407u, (unsigned)(0xac3cf7fcu < i1), (u2 | (unsigned)(0x10000u == v0))); }
    g0 = ((unsigned)x0 * 6u);
    r0.x = (unsigned)((int)((unsigned)(x0 >> 70) & (unsigned)((int)8u >= (int)0x35c519f6u)) < (int)(0x3ab77901u / (p1 | 1u)));
    goto L2;
    if (budget != 0u) { budget -= 1u; u1 = fn2(p2, 0xffffffffu, -(8u - (unsigned)(0x7fffffffu < 0x80000000u))); }
    if (budget != 0u) { budget -= 1u; u3 = fn1((8u | p2), u1, ((unsigned)((short)i2 > (signed char)(unsigned)e0) - m0)); }
    w0 ^= (unsigned long long)(unsigned)(0x459c3513u || (unsigned)x0) << (((unsigned)b0 % (0xf60feb6eu | 1u)) & 63u);
    w0 = w0 * 6364136223846793005ull + ((unsigned)((unsigned)x0 && 0x7fffffffu) | (p2 * (unsigned)((short)0u > (signed char)2u)));
    switch ((unsigned)(0xffffffffu || (unsigned)l0) & 7u) {
        c1 = (signed char)u3;
        a0[r0.x & 3u] = i0;
    }
    switch ((unsigned)((unsigned)(signed char)(unsigned)((short)0x8a995bbeu > (signed char)p2) || (unsigned)f0) & 7u) {
        case 3u: ;
        *mp = garr[u2 & 7u];
        f0 = f0 * 0.5f + (float)(0xfff0df27u & 255u);
        goto L0;
    }
    switch (0x10000u & 7u) {
        if ((6u + (unsigned)d0)) break;
        if (i2) goto done;
        if ((unsigned)(unsigned char)(unsigned)(0xffffffffu || fuel)) {
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                g1 += (unsigned)(short)(unsigned)((int)(0x37125435u ^ (unsigned)(m0 && p1)) < (int)i0);
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(0x3ba6c77fu && (unsigned)h0), (unsigned)b0, u3); }
                v0 = ((unsigned)!((unsigned)f0 ? 4u : (unsigned)h1) | u1);
                case 0u: ;
                case 2u: ;
                *q0 = (u0 + m0);
            }
            switch (5u & 7u) {
                m0 ^= (unsigned)(0x80000000u || (unsigned)(short)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)s1));
                case 4u: ;
                if (*q0) break;
                if (~((unsigned)((unsigned)h1 < 0x69e928bu) + p0)) {
                    u3 ^= (((r0.y - (unsigned)c1) << (0xffffffffu & 31u)) << ((g1 | u3) & 31u));
                    i2 = (unsigned)c1 & 15u;
                    case 7u: ;
                    while (i0++ < 2u && (unsigned)((short)(unsigned)((short)fuel > (signed char)i2) > (signed char)(unsigned)s1)) { if (--fuel == 0u) goto done;
                        r0.x = ((u1 + (unsigned)((unsigned)s0 == (unsigned)e0)) << (1u & 31u));
                        if (u3 == 7u) return (unsigned)((int)0x7fffffffu >= (int)0xbee4fe76u);
                    }
                } else {
                    r0.y ^= (7u ^ r0.x);
                    default: ;
                }
            }
            d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(garr[u2 & 7u] * v0)) & 1023u);
            default: ;
            if ((unsigned)(unsigned char)((0x7fffffffu >> ((unsigned)f0 & 31u)) + (unsigned)(x0 >> 70))) goto L1;
            r0.y ^= (unsigned)((short)(unsigned)h1 > (signed char)(*q0 ^ u1));
        } else {
            break;
            w0 ^= (unsigned long long)(unsigned)h0 << ((m0 ^ (unsigned)(x0 >> 70)) & 63u);
        }
        if ((unsigned)f0) break;
        switch ((unsigned)d0 & 7u) {
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((3u + r0.y) < (unsigned)c1), (unsigned)(unsigned char)(0x80000000u & i0), (unsigned)!(unsigned)(3u || garr[i1 & 7u])); }
            g0 = (unsigned)((unsigned)((int)(unsigned)((int)i2 < (int)(unsigned)(x0 >> 70)) >= (int)*q0) < p0);
            s0 = (int)(((0xeba612e8u >> (a0[i0 & 3u] & 31u)) << (0x10000u & 31u)) + (unsigned)s0);
            if (((unsigned)((int)(unsigned)w0 < (int)i0) & garr[u2 & 7u])) {
                case 6u: ;
                goto L2;
                w0 ^= (unsigned long long)(p1 / (a0[i0 & 3u] | 1u)) << ((u3 >> ((unsigned)(unsigned char)(unsigned)((unsigned)s0 && i0) & 31u)) & 63u);
                s1 = (int)((unsigned)s1 + (unsigned)f0);
                case 0u: ;
                if (budget != 0u) { budget -= 1u; u2 = fn1(0x5af7fb91u, ((unsigned)((short)0xffffffffu > (signed char)0xffffffffu) % (i2 | 1u)), (a0[u1 & 3u] ^ (unsigned)(a0[i0 & 3u] < (unsigned)c0))); }
            } else {
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)e0 && ((0xffffffffu << ((unsigned)c0 & 31u)) & 0xffffffffu)) & 1023u);
            }
            if ((*mp / ((unsigned)c0 | 1u))) goto L0;
        }
        d0 = d0 * 0.5 + (double)(p2 & 1023u);
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(x0 >> 70), i0, (m0 + (unsigned)(x0 >> 70))); }
    if ((unsigned)(unsigned char)(unsigned)(u1 < (i0 / (i0 | 1u)))) goto L4;
    if ((0xa312e914u ^ a0[u1 & 3u])) {
        e0 = e0 * 0.5L + (long double)((unsigned)((short)u3 > (signed char)u1) & 1023u);
    } else {
        if ((unsigned)(x0 >> 70)) goto L0;
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)(0x7fffffffu < (unsigned)(i2 || (unsigned)f0)) & 7u) {
                garr[r0.y & 7u] = ((unsigned)(short)(unsigned)(0x10000u && 0x679d71a1u) - u3);
                case 4u: ;
                a0[(unsigned)((unsigned)(x0 >> 70) < u3) & 3u] = (0x7fffffffu % ((unsigned)(w0 >> 29) | 1u));
                g1 += ((unsigned)e0 - (p2 % ((5u ? u0 : (unsigned)h1) | 1u)));
                e0 = e0 * 0.5L + (long double)(~(unsigned)((int)0x20874d3bu >= (int)((a0[i0 & 3u] / ((unsigned)h0 | 1u)) << (fuel & 31u))) & 1023u);
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)h0 % (u0 | 1u)), (unsigned)(unsigned char)(unsigned)((short)u2 > (signed char)(unsigned)l0), ((unsigned)(x0 >> 70) & (i1 >> (0xffffffffu & 31u)))); }
            }
            q0 = &garr[(unsigned)((int)(unsigned)h0 < (int)(0x7fffffffu & 0x7fffffffu)) & 7u];
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)d0, (p2 | (4u * 0u)), (unsigned)h1); }
            { unsigned t2; double z2; if (((unsigned)((unsigned)(unsigned char)(unsigned)(fuel < 0x7fffffffu) || g0)) & 1u) { t2 = (3u / (g0 | 1u)); z2 = (double)(((unsigned)(fuel && (unsigned)((int)(unsigned)s1 < (int)m0))) & 255u); } if (((unsigned)((unsigned)(unsigned char)(unsigned)(fuel < 0x7fffffffu) || g0)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                switch ((i2 / (garr[u2 & 7u] | 1u)) & 7u) {
                    case 1u: ;
                    garr[(unsigned)(x0 >> 70) & 7u] = (unsigned)(((unsigned)x0 ^ (unsigned)(8u || i1)) == (8u - 0xebf3ae4fu));
                }
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (4u >> (0xa419143cu & 31u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((0xd96ca140u - g1), a0[i0 & 3u], 6u); }
                    switch (((unsigned)(0xffffffffu == (unsigned)s0) & 0x7fffffffu) & 7u) {
                        v0 = (unsigned)((short)9u > (signed char)0x10000u);
                        if ((unsigned)(x0 >> 70)) {
                            *mp = -(3u % ((unsigned)(0x95607290u && ((unsigned)(a0[i0 & 3u] || (unsigned)c0) << ((unsigned)(w0 >> 29) & 31u))) | 1u));
                            case 7u: ;
                            h1 = (unsigned short)(h1 + ((unsigned)h1 | (unsigned)(short)((unsigned)b0 % (0x2f494cd7u | 1u))));
                            m0 ^= (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(0x7fffffffu << ((unsigned)w0 & 31u)));
                            c0 = (unsigned char)(0x986410f1u >> ((unsigned)h1 & 31u));
                        } else {
                            if (((6u ^ (unsigned)e0) & (unsigned)(x0 >> 70))) goto L2;
                            a0[u0 & 3u] = ((unsigned)((int)(unsigned)!((unsigned)(w0 >> 29) % (0xeeb16cf0u | 1u)) >= (int)0xffffffffu) >> (((unsigned)s0 << (0u & 31u)) & 31u));
                            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)d0, (unsigned)(fuel || (unsigned)(short)(unsigned)((unsigned)l0 || m0)), 7u); }
                            v0 = ((unsigned)c1 & (unsigned)w0);
                        }
                    }
                }
                *mp = (((unsigned)((int)*q0 >= (int)(unsigned)(short)(fuel % (u1 | 1u))) - a0[u1 & 3u]) % ((unsigned)l0 | 1u));
                if ((unsigned)((int)7u >= (int)0x334fc6d7u)) break;
                if (2u) goto L2;
            }
            if ((2u ^ p1)) continue;
            if (u3 == 7u) return ((unsigned)(unsigned char)(i0 - ~(unsigned)((int)(unsigned)l0 < (int)p2)) + 6u);
        }
    }
    *q0 = (unsigned)(unsigned char)(unsigned)((short)u1 > (signed char)(unsigned)b0);
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)(unsigned char)(unsigned)(0x42294388u < 0x10000u) < (int)(unsigned)c1);
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        v0 = (unsigned)((0xc84fab62u + (unsigned)((int)(unsigned)s0 < (int)(unsigned)c1)) == u3);
        if ((unsigned)(w0 >> 29)) {
            m0 ^= ((garr[u2 & 7u] + v0) | 8u);
            s1 = (int)((unsigned)s1 + v0);
            if (v0) {
                a0[(p1 + u0) & 3u] = g0;
                g1 += 2u;
            } else {
                do { if (--fuel == 0u) goto done;
                    c1 = (signed char)(u1 - ((unsigned)c0 + (unsigned)c1));
                    continue; (void)(((unsigned)(a0[i0 & 3u] || 0xb5a1543u) >> (*mp & 31u)));
                    i2 = (unsigned)((int)*q0 < (int)2u) & 15u;
                    if ((((unsigned)w0 ^ r0.x) % (0xb77261c5u | 1u))) break;
                } while (i1++ < 7u && (fuel ? m0 : *mp));
                { unsigned t3; double z3; if (((garr[u2 & 7u] & (5u * garr[u2 & 7u]))) & 1u) { t3 = (unsigned)!((unsigned)b0 ? (unsigned)w0 : 0xffffffffu); z3 = (double)(((i1 & 0xffffffffu)) & 255u); } if (((garr[u2 & 7u] & (5u * garr[u2 & 7u]))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                    w0 ^= (unsigned long long)0xffffffffu << ((unsigned)(r0.y < u3) & 63u);
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(0x8c16403au == (unsigned)c1), (unsigned)((unsigned)(r0.y && (unsigned)c1) == a0[u1 & 3u]), (0x10000u ? p0 : (unsigned)b0)); }
                    *mp = r0.x;
                    b0 = ((unsigned)((short)p0 > (signed char)(unsigned)(x0 >> 70)) - (unsigned)c1) != 0u;
                    *mp = (g1 | (0x7fffffffu / ((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)l0) | 1u)));
                    r0.y ^= (unsigned)(signed char)((1u / (u2 | 1u)) ? (unsigned)b0 : r0.x);
                }
                a0[(unsigned)(m0 && (unsigned)w0) & 3u] = (unsigned)((int)(unsigned)(w0 >> 29) >= (int)u2);
            }
        } else {
            d0 = d0 * 0.5 + (double)((unsigned)((short)((u3 & (unsigned)h1) << ((0x7fffffffu + (unsigned)l0) & 31u)) > (signed char)(unsigned)c1) & 1023u);
            a0[0x80000000u & 3u] = 0x6b7df3eau;
        }
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)(unsigned)(short)(unsigned)((unsigned)((int)*mp >= (int)0x10000u) < u3);
            u0 = (unsigned)(m0 == (unsigned)(unsigned char)(unsigned)((short)(unsigned)c1 > (signed char)(9u + (unsigned)!(0x651eaa36u << (a0[u1 & 3u] & 31u)))));
        }
        v0 = (v0 / ((unsigned)((int)(unsigned)(2u || v0) >= (int)0xffffffffu) | 1u));
        u0 ^= (~(unsigned)((int)(u0 << (i0 & 31u)) >= (int)0xffffffffu) ^ (unsigned)(unsigned char)((unsigned)b0 ^ u3));
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(p2 < u2), (unsigned)c0, (unsigned)(unsigned char)((unsigned)(0x4658cedeu && m0) + *mp)); }
            while (i2++ < 7u && 0x7cd0e615u) { if (--fuel == 0u) goto done;
                u2 ^= (i0 + (unsigned)(unsigned char)(unsigned)((unsigned)((unsigned)d0 < a0[i0 & 3u]) == (unsigned)(x0 >> 70)));
                *q0 = ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)a0[i0 & 3u]) - (unsigned)(0x79aac381u == (unsigned)(0x80000000u && (unsigned)(x0 >> 70))));
                if (budget != 0u) { budget -= 1u; u0 = fn2(v0, 3u, (unsigned)(signed char)((unsigned)s0 / (0x8723151eu | 1u))); }
                if (budget != 0u) { budget -= 1u; u3 = fn2((garr[u2 & 7u] ^ m0), (g1 << (0x1555c2fu & 31u)), (unsigned)((short)p0 > (signed char)(unsigned)(unsigned char)(u1 + i2))); }
                do { if (--fuel == 0u) goto done;
                    *q0 = (((unsigned)b0 * (unsigned)((short)m0 > (signed char)u1)) + u3);
                    if ((u1 ? u2 : 0xffffffffu)) break;
                    if (1u) {
                        if ((unsigned)b0) goto L4;
                        i0 = (unsigned)((short)(unsigned)(v0 || (unsigned)h0) > (signed char)(unsigned)(x0 >> 70)) & 15u;
                        q0 = &garr[~(0x2a3671e6u | *q0) & 7u];
                        if ((unsigned)f0) continue;
                    } else {
                        *q0 = i2;
                    }
                    if (3u) {
                        w0 = w0 * 6364136223846793005ull + (p0 % ((unsigned)(short)(i2 << ((unsigned)x0 & 31u)) | 1u));
                        continue; (void)(*mp);
                        if (v0) break;
                        *q0 = p0;
                    } else {
                        a0[(0x7988e217u * (unsigned)c1) & 3u] = garr[i1 & 7u];
                        if (m0) goto L0;
                        if ((unsigned)((unsigned)c1 == (unsigned)d0)) continue;
                    }
                } while (i0++ < 5u && (((unsigned)h1 - (unsigned)x0) + r0.x));
            }
        } while (i1++ < 6u && (unsigned)(unsigned char)(unsigned)(g1 || (unsigned)((unsigned)h1 < 2u)));
    }
    do { if (--fuel == 0u) goto done;
        if (((unsigned)s0 >> ((unsigned)c1 & 31u))) {
            if (0xa6b7e6f7u) break;
        }
    } while (i0++ < 6u && (unsigned)h0);
    { unsigned t4; double z4; if ((9u) & 1u) { t4 = ((unsigned)l0 | 4u); z4 = (double)((((unsigned)c1 + (i1 << (r0.x & 31u)))) & 255u); } if ((9u) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        if (((unsigned)s1 & 0x7fffffffu)) goto L1;
        if ((3u ^ 0x10000u)) {
            if (((unsigned)h1 + (9u * g1))) goto L3;
            if ((0x28ee0f1fu & (u3 + i1))) goto L1;
            if ((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)x0)) goto L2;
            u2 ^= -(p0 ? (unsigned)(w0 >> 29) : ((unsigned)c0 % ((i0 - a0[i0 & 3u]) | 1u)));
            if ((unsigned)((0xffffffffu - u0) < fuel)) goto L3;
        } else {
            if (budget != 0u) { budget -= 1u; u0 = fn1(8u, *mp, i2); }
        }
        r0.x = ((unsigned)s1 << (((unsigned)(x0 >> 70) - (unsigned)l0) & 31u));
        if (((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)h0) & 6u)) goto done;
        { unsigned t5; double z5; if ((a0[u1 & 3u]) & 1u) { t5 = 0xb3bc3748u; z5 = (double)((((unsigned)h1 ^ (unsigned)(7u == 1u))) & 255u); } if ((a0[u1 & 3u]) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            while (i0++ < 6u && (8u | 8u)) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)3u < (int)(garr[i1 & 7u] * (unsigned)w0))) break;
                *mp = ((unsigned)h1 % (i0 | 1u));
                w0 ^= (unsigned long long)(garr[i1 & 7u] & v0) << ((r0.y * g1) & 63u);
            }
            garr[7u & 7u] = (g0 ^ u1);
            if (0xc8d6e403u) {
                goto L0;
                goto done;
                i2 = ((i0 ^ 0x4297a34eu) << (u2 & 31u)) & 15u;
                if (*mp) goto L4;
                if ((5u - p1)) goto L1;
            }
        }
        if ((unsigned)((short)0xb8233c81u > (signed char)(r0.x % (7u | 1u)))) goto L3;
    }
    do { if (--fuel == 0u) goto done;
        h0 = (short)((unsigned)b0 + garr[u2 & 7u]);
        switch (4u & 7u) {
            if (0x1151e246u) continue;
        }
        if (((unsigned)((int)0xc77fd66cu < (int)7u) ^ p1)) break;
        g0 = (unsigned)w0;
        break; (void)(*q0);
        *mp = (unsigned)((unsigned)e0 || a0[i0 & 3u]);
    } while (i0++ < 4u && 3u);
    { unsigned t6; double z6; if (((u3 % (r0.y | 1u))) & 1u) { t6 = (m0 >> (*q0 & 31u)); z6 = (double)((0x80000000u) & 255u); } if (((u3 % (r0.y | 1u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
        if ((u2 - a0[u1 & 3u])) goto L2;
        e0 = e0 * 0.5L + (long double)((0xcce0e782u >> (((unsigned)(w0 >> 29) << (0xffffffffu & 31u)) & 31u)) & 1023u);
        l0 = (long)((unsigned long)l0 + (-(unsigned)(0x6b25904fu == 0xffffffffu) * 0x80000000u));
        do { if (--fuel == 0u) goto done;
            m0 ^= ((unsigned)w0 % ((g0 + 8u) | 1u));
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)((int)g1 < (int)u1) ^ 0xf889a2b7u));
                if (0xffffffffu) break;
                continue; (void)(((unsigned)(signed char)(p0 & a0[u1 & 3u]) ^ 0x80000000u));
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (unsigned)(4u == u3) != 0u;
                    w0 = w0 * 6364136223846793005ull + (garr[u2 & 7u] ? (unsigned)f0 : (unsigned)c1);
                    break; (void)((unsigned)(0x2921333eu && u3));
                }
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (((unsigned)(short)(unsigned)((int)(0xc2bce22eu * (unsigned)x0) >= (int)0x758f087bu) / ((unsigned)s1 | 1u)) << (r0.x & 31u)) != 0u;
                    if ((unsigned)((int)(0x7fffffffu / (1u | 1u)) >= (int)(unsigned)e0)) continue;
                    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)c1, (unsigned)((0x7fffffffu ^ (unsigned)f0) || garr[u2 & 7u]), (unsigned)(w0 >> 29)); }
                    if ((unsigned)e0) {
                        if (budget != 0u) { budget -= 1u; u2 = fn0(0xb0222a6u, (unsigned)(5u == r0.x), (*mp / (((unsigned)d0 * 0x10000u) | 1u))); }
                        do { if (--fuel == 0u) goto done;
                            u3 = u3 * 0x9e3779b1u + i0;
                            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(signed char)(unsigned)((u1 << (3u & 31u)) < fuel), (unsigned)!(9u | 0x72ca699u), (*mp / ((unsigned)e0 | 1u))); }
                        } while (i0++ < 7u && u1);
                    } else {
                        if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)c1 + u3), ~((unsigned)d0 << (0x60fd7d76u & 31u)), (p0 | 0xffffffffu)); }
                    }
                    r0.x = fuel;
                }
                goto L3;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)d0, (unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)d0), (unsigned)(0x7fffffffu < 0xffffffffu)); }
            b0 = (unsigned)((short)((unsigned)h0 + (0x35b97344u * (unsigned)((int)i0 < (int)0x70a2e486u))) > (signed char)garr[u2 & 7u]) != 0u;
            if ((8u ? garr[i1 & 7u] : (unsigned)x0)) break;
            if ((garr[u2 & 7u] ^ (unsigned)c0)) break;
        } while (i0++ < 7u && (unsigned)s1);
    }
    switch ((unsigned)(0x10000u || 0x38c2f55cu) & 7u) {
        if (fuel < 8u) return (unsigned)((unsigned)l0 || -((0xffffffffu << (p0 & 31u)) & (unsigned)b0));
        r0.x = (0x94ef187u & (unsigned)((short)r0.x > (signed char)(p2 ^ g0)));
        r0.x = (unsigned)!(3u / ((0xd99ac17du << ((unsigned)f0 & 31u)) | 1u));
        do { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((unsigned)!(0x7fffffffu >> (u3 & 31u)) / (0xe152751du | 1u)) & 1023u);
        } while (i0++ < 5u && (unsigned)(signed char)(unsigned)(g0 && (unsigned)e0));
        do { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                r0.x = (p0 / ((unsigned)l0 | 1u));
                garr[(u2 >> (0xa30e892du & 31u)) & 7u] = ((-(unsigned)((int)(unsigned)f0 < (int)(unsigned)(r0.y || p2)) >> (p2 & 31u)) ^ (unsigned)l0);
                c1 = (signed char)-(i1 << ((unsigned)(u0 < ((unsigned)w0 * 6u)) & 31u));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1((((unsigned)l0 * *mp) + (unsigned)s0), (unsigned)!(4u >> (g1 & 31u)), ((garr[u2 & 7u] ^ fuel) % (0xe931f263u | 1u))); }
            case 3u: ;
        } while (i0++ < 4u && (unsigned)((short)8u > (signed char)u0));
        s1 = (int)((unsigned)s1 + (-(unsigned)((int)(unsigned)((unsigned)s0 || 0x80000000u) < (int)i2) + ((unsigned)d0 + p0)));
    }
    { unsigned t7; double z7; if ((((unsigned)s0 ^ (unsigned)(signed char)(9u % (0x56ce96bau | 1u)))) & 1u) { t7 = p0; z7 = (double)(((m0 % (p1 | 1u))) & 255u); } if ((((unsigned)s0 ^ (unsigned)(signed char)(9u % (0x56ce96bau | 1u)))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
        *q0 = (unsigned)((int)((unsigned)w0 | 8u) >= (int)(unsigned)(0x896e385fu && 0x80000000u));
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.x = i1;
            u1 += (r0.y >> (3u & 31u));
            c1 = (signed char)((unsigned)f0 / (((0xffffffffu + 0xffffffffu) / ((i0 * i1) | 1u)) | 1u));
            while (i2++ < 7u && ((unsigned)((int)0x80000000u < (int)8u) / (0x9a5de4ddu | 1u))) { if (--fuel == 0u) goto done;
                if ((unsigned)!(0x80000000u ^ (*q0 ^ (unsigned)h1))) break;
                break; (void)((unsigned)(w0 >> 29));
                if ((unsigned)((int)(unsigned)((unsigned)h1 || 1u) >= (int)(unsigned)s0)) {
                    if ((0x7fffffffu & garr[i1 & 7u])) break;
                    if ((i0 & 0xdfbd8702u)) break;
                    if ((((unsigned)b0 & a0[u1 & 3u]) >> (9u & 31u))) break;
                } else {
                    g1 += (unsigned)((short)(unsigned)((int)r0.x < (int)fuel) > (signed char)0x10000u);
                    u3 += (-(7u + *mp) + ((unsigned)!(6u & (unsigned)(w0 >> 29)) | (unsigned)e0));
                }
            }
        }
        i1 = (unsigned)((short)r0.x > (signed char)r0.y) & 15u;
        break; (void)((unsigned)(0x1da85c11u == u2));
        h0 = (short)(unsigned)x0;
        if ((unsigned)(short)(unsigned)((int)8u >= (int)g0)) {
            v0 = u1;
            { unsigned t8; double z8; if (((p2 & m0)) & 1u) { t8 = (unsigned)(short)(unsigned)((int)(unsigned)(4u && p0) >= (int)garr[u2 & 7u]); z8 = (double)(((unsigned)!(i0 - -(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)2u))) & 255u); } if (((p2 & m0)) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                if ((unsigned)l0) break;
                i0 = ~((unsigned)b0 | ((unsigned)(p0 == g1) + (unsigned)w0)) & 15u;
                break; (void)(((unsigned)(u3 < 5u) >> (*mp & 31u)));
                if (budget != 0u) { budget -= 1u; u0 = fn0(8u, (unsigned)(p0 < i0), ((i1 & 1u) * (unsigned)f0)); }
                garr[(unsigned)s1 & 7u] = (unsigned)(*q0 && 0x3cb646adu);
                if (budget != 0u) { budget -= 1u; u1 = fn0((0x86ff2f00u & a0[i0 & 3u]), (unsigned)((0xcb179b5fu - u1) < 0x735b8256u), (p1 * (unsigned)(0x12d8ce42u < 0x9ecec75du))); }
            }
            if ((unsigned)((int)u1 < (int)(unsigned)((int)0xaf0fecffu < (int)i0))) goto L2;
        }
        break; (void)((unsigned)(fuel || (unsigned)x0));
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)-(unsigned)((int)*mp >= (int)i2) << ((unsigned)((int)i2 < (int)(unsigned)(5u && (unsigned)((int)u0 < (int)(unsigned)h1))) & 63u);
        if (budget != 0u) { budget -= 1u; u2 = fn0(a0[u1 & 3u], (unsigned)(short)(*mp >> (garr[u2 & 7u] & 31u)), (u0 ? 0xbbc5c1d7u : 5u)); }
    }
    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)c1 && (unsigned)((int)r0.x >= (int)2u)) & 255u);
    if ((0x10000u >> ((p1 / (0x38fd483bu | 1u)) & 31u))) goto L2;
    switch ((unsigned)(signed char)((unsigned)e0 * *mp) & 7u) {
        r0.y ^= (unsigned)(short)(unsigned)((int)(unsigned)(signed char)(unsigned)((int)0x88d55d11u >= (int)(fuel + g1)) < (int)(unsigned)(0u && 0xffffffffu));
        i1 = (unsigned)((short)(unsigned)(short)((unsigned)(a0[i0 & 3u] || v0) << ((unsigned)f0 & 31u)) > (signed char)i1) & 15u;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)w0) {
        b0 = (unsigned)((int)((garr[i1 & 7u] + r0.y) * 3u) >= (int)(unsigned)(a0[u1 & 3u] && r0.x)) != 0u;
        if (-(unsigned)((int)(unsigned)(w0 >> 29) < (int)(*q0 | 0xd4cedd0bu))) goto L0;
        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((int)g0 >= (int)*q0) && (unsigned)(garr[u2 & 7u] == r0.x)) & 1023u);
        L0: if (--fuel == 0u) goto done;
        *q0 += (garr[u2 & 7u] & u1);
    } else {
        switch ((unsigned)((int)(unsigned)c0 < (int)v0) & 7u) {
            f0 = f0 * 0.5f + (float)((unsigned)w0 & 255u);
            h0 = (short)(p0 & (unsigned)c1);
            L1: if (--fuel == 0u) goto done;
        }
        *q0 += (unsigned)(~(unsigned)((int)(unsigned)l0 >= (int)(unsigned)f0) == ~(p1 - u3));
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 += (unsigned)(((unsigned)(w0 >> 29) ? 0u : 0x6bd505f5u) == (unsigned)w0);
        u0 += ((0x80000000u ? (unsigned)s0 : i2) % (v0 | 1u));
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (0xba8b87cu) {
                s1 = (int)((unsigned)s1 + (7u + a0[i0 & 3u]));
                if ((8u * (unsigned)s1)) continue;
                if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)(p0 == *mp), (2u / ((u0 % (3u | 1u)) | 1u)), (u1 * m0)); }
                q0 = &garr[(unsigned)((int)0x10000u < (int)(unsigned)(9u && (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)(x0 >> 70)))) & 7u];
                if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)(i2 || (unsigned)(unsigned char)(g0 ^ (unsigned)s1)), (unsigned)((int)0xeda19c14u < (int)i0), *mp); }
                if (budget != 0u) { budget -= 1u; u0 = fn1((i2 & *mp), (v0 + (unsigned)(w0 >> 29)), (g0 ? 0x80000000u : r0.y)); }
            } else {
                if (u3 == 7u) return (unsigned)((2u - (unsigned)d0) == i1);
            }
            s1 = (int)((unsigned)s1 + (unsigned)(((r0.y - i0) ^ (unsigned)s0) || (unsigned)s0));
            break; (void)(((unsigned)c1 * (unsigned)x0));
            i2 = (unsigned)((int)4u >= (int)u0) & 15u;
            if (budget != 0u) { budget -= 1u; u0 = fn1((u2 & 9u), ((unsigned)d0 / (0xb0df6d60u | 1u)), 0xb8578bbfu); }
        }
        g1 += (i0 * (-(unsigned)(0x8d90de35u == a0[u1 & 3u]) ? (unsigned)s1 : (unsigned)h0));
        continue; (void)((unsigned)((int)5u >= (int)(u3 / (fuel | 1u))));
    }
    if (g0) goto L4;
    if ((unsigned)((r0.x / (2u | 1u)) && (unsigned)l0)) goto done;
    s0 = (int)((unsigned)(6u < v0) % ((*q0 / ((unsigned)((int)u2 < (int)(unsigned)h0) | 1u)) | 1u));
    goto L0;
    a0[garr[i1 & 7u] & 3u] = (unsigned)((0xffffffffu & (unsigned)l0) == (u2 - (unsigned)(signed char)(unsigned)(u3 < g0)));
    if (((unsigned)((short)i0 > (signed char)u3) >> (i2 & 31u))) goto L3;
    c0 = (unsigned char)-((unsigned)h0 >> (7u & 31u));
    { unsigned t0; double z0; if (((unsigned)!(1u ^ u2)) & 1u) { t0 = (u2 % (m0 | 1u)); z0 = (double)((0x10000u) & 255u); } if (((unsigned)!(1u ^ u2)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((unsigned)x0 == r0.y) >= (int)(unsigned)(short)(unsigned)(9u == r0.y)));
        for (;;) { if (--fuel == 0u) goto done;
            *q0 += (u1 | (u3 ^ (unsigned)s1));
        }
        m0 ^= (unsigned)x0;
    }
    L2: if (--fuel == 0u) goto done;
    goto L4;
    if ((unsigned)(8u < (p0 << (r0.y & 31u)))) {
        w0 ^= (unsigned long long)(0xd5c3766eu - (unsigned)h1) << ((unsigned)b0 & 63u);
    } else {
        c1 = (signed char)(unsigned)((int)((unsigned)((unsigned)(w0 >> 29) == a0[i0 & 3u]) / (i2 | 1u)) < (int)~(unsigned)((short)0xffffffffu > (signed char)(unsigned)x0));
        s0 = (int)(unsigned)((short)-(0x86193d85u % ((unsigned)x0 | 1u)) > (signed char)5u);
        { unsigned t1; double z1; if (((unsigned)((int)0xca11572cu < (int)(unsigned)(garr[i1 & 7u] < (unsigned)e0))) & 1u) { t1 = 0x1b844267u; z1 = (double)((i2) & 255u); } if (((unsigned)((int)0xca11572cu < (int)(unsigned)(garr[i1 & 7u] < (unsigned)e0))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            g0 = (unsigned)(0xffffffffu && (unsigned)((unsigned)((unsigned)e0 == 0x6dcd418u) < u0));
            if ((unsigned)!((0x50690060u / ((unsigned)(w0 >> 29) | 1u)) % (*mp | 1u))) goto done;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(unsigned char)(0xb5c7acb4u * v0), (unsigned)((int)(9u ^ 2u) >= (int)(unsigned)(x0 >> 70)), (((unsigned)e0 * r0.y) % ((unsigned)b0 | 1u))); }
                if (((0x901bb025u & 0xf0090ebeu) | (unsigned)w0)) break;
                switch (*q0 & 7u) {
                    if ((unsigned)((short)(unsigned)(unsigned char)(p0 ^ u0) > (signed char)i2)) continue;
                    case 3u: ;
                    u1 ^= (unsigned)h0;
                }
                r0.y ^= ((unsigned)x0 ^ ~(unsigned)((int)(g0 | 0xffffffffu) < (int)(3u % (0x10000u | 1u))));
                { unsigned t2; double z2; if (((0x9d7ae2e9u ^ garr[u2 & 7u])) & 1u) { t2 = (0xe888c6d3u + i0); z2 = (double)(((u3 * 3u)) & 255u); } if (((0x9d7ae2e9u ^ garr[u2 & 7u])) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    goto L4;
                    if ((0x6c984d5au >> (u3 & 31u))) goto L1;
                    continue; (void)((unsigned)(short)(unsigned)((short)i0 > (signed char)(unsigned)(0x80000000u || u3)));
                }
            } while (i0++ < 4u && (unsigned)((unsigned)s0 && 0x331641d5u));
            if (((0x10000u * a0[u1 & 3u]) * u2)) {
                r0.y ^= ((garr[i1 & 7u] >> (((unsigned)b0 << ((unsigned)(*mp < (unsigned)b0) & 31u)) & 31u)) >> (r0.x & 31u));
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (garr[i1 & 7u]) break;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn0(3u, -(unsigned)(p0 || (0x80000000u / ((unsigned)h0 | 1u))), p0); }
                x0 = x0 * 0x100000001b3ull + ((a0[i0 & 3u] % (0xd46dd3afu | 1u)) & (unsigned)((short)m0 > (signed char)(unsigned)!(v0 % (a0[u1 & 3u] | 1u))));
            }
        }
        if ((unsigned)((unsigned)(x0 >> 70) == (unsigned)x0)) {
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)l0 * *q0), (7u % (((unsigned)l0 | a0[u1 & 3u]) | 1u)), (unsigned)((int)(unsigned)b0 < (int)i1)); }
            e0 = e0 * 0.5L + (long double)((unsigned)(short)(unsigned)((unsigned)f0 == (unsigned)((unsigned)(x0 >> 70) && (unsigned)((short)0xf4de100cu > (signed char)(unsigned)e0))) & 1023u);
            h0 = (short)(unsigned)((unsigned)((short)g0 > (signed char)r0.x) < *mp);
        } else {
            s0 = (int)(unsigned)((unsigned)((fuel % ((unsigned)f0 | 1u)) == (unsigned)h0) || 0x80000000u);
            e0 = e0 * 0.5L + (long double)((unsigned)(short)((u2 * (unsigned)((short)(unsigned)c0 > (signed char)i1)) << ((unsigned)s1 & 31u)) & 1023u);
            if (budget != 0u) { budget -= 1u; u1 = fn3(((unsigned)c1 / ((garr[u2 & 7u] - *q0) | 1u)), (unsigned)(p1 && 0x7fffffffu), (unsigned)((unsigned)s1 && ((unsigned)s1 + 0x10000u))); }
        }
    }
    h0 = (short)((unsigned)((short)r0.y > (signed char)u1) * (garr[u2 & 7u] * (unsigned)c1));
    do { if (--fuel == 0u) goto done;
        continue; (void)((0x10000u % ((unsigned)f0 | 1u)));
        do { if (--fuel == 0u) goto done;
            { unsigned t3; double z3; if ((m0) & 1u) { t3 = i2; z3 = (double)(((5u + *q0)) & 255u); } if ((m0) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                *q0 = 2u;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)c1, 0x10000u, g1); }
        } while (i1++ < 7u && (p0 * g0));
        L3: if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                garr[((unsigned)h0 + (unsigned)h0) & 7u] = (0xf269eddfu / (((0xd8b62859u << ((unsigned)d0 & 31u)) - (unsigned)c0) | 1u));
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)w0, (r0.x ^ (unsigned)c0), (7u - (unsigned)h1)); }
                if (-(unsigned)((int)(0x139821d2u % (i0 | 1u)) < (int)0x10000u)) break;
                if (u3 == 7u) return (4u * 0x7fffffffu);
                u0 = u0 * 0x9e3779b1u + ((unsigned)e0 % (a0[i0 & 3u] | 1u));
                { unsigned t4; double z4; if ((((unsigned)((int)(unsigned)h0 < (int)m0) | 0x10000u)) & 1u) { t4 = 5u; z4 = (double)((0xffffffffu) & 255u); } if ((((unsigned)((int)(unsigned)h0 < (int)m0) | 0x10000u)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                    if ((unsigned)((int)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)c0) < (int)(unsigned)b0)) break;
                    g0 = (((unsigned)x0 % (((unsigned)x0 ^ (unsigned)h0) | 1u)) * (unsigned)x0);
                }
            } while (i2++ < 5u && (a0[i0 & 3u] | (unsigned)((unsigned)f0 && *q0)));
            *mp = ((unsigned)((int)i2 < (int)i2) + (unsigned)(a0[u1 & 3u] == 0x80000000u));
            L4: if (--fuel == 0u) goto done;
        } while (i1++ < 7u && (0xc9dcf7au ^ 0x1b93ecdbu));
    } while (i0++ < 4u && (g0 | a0[u1 & 3u]));
    { unsigned t5; double z5; if (((unsigned)(signed char)((unsigned)d0 * a0[i0 & 3u])) & 1u) { t5 = (unsigned)(u2 < 6u); z5 = (double)((fuel) & 255u); } if (((unsigned)(signed char)((unsigned)d0 * a0[i0 & 3u])) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
        if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)d0, (a0[u1 & 3u] ^ 2u), (unsigned)(0xffffffffu == (unsigned)(w0 >> 29))); }
        s0 = (int)((unsigned)(w0 >> 29) + g0);
        goto done;
        if (-(0x80000000u - (*mp ^ r0.y))) {
            if (budget != 0u) { budget -= 1u; u1 = fn3((r0.x ^ garr[u2 & 7u]), (unsigned)b0, (unsigned)((int)r0.y >= (int)((unsigned)(w0 >> 29) & (unsigned)l0))); }
            if (budget != 0u) { budget -= 1u; u2 = fn1((0x80000000u / (~(garr[u2 & 7u] << (0x10000u & 31u)) | 1u)), (unsigned)((short)(unsigned)((int)p0 < (int)(unsigned)w0) > (signed char)(unsigned)c1), (unsigned)(0u || (unsigned)(signed char)(unsigned)((unsigned)b0 < (unsigned)l0))); }
        }
    }
    g0 = (4u * (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)w0));
    switch ((unsigned)l0 & 7u) {
        u2 = u2 * 0x9e3779b1u + (m0 * 5u);
        { unsigned t6; double z6; if (((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)c0)) & 1u) { t6 = (unsigned)(p0 || 0xdafdf33eu); z6 = (double)(((a0[i0 & 3u] ^ 0x998b6323u)) & 255u); } if (((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)c0)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
            d0 = d0 * 0.5 + (double)((0xffffffffu | (unsigned)(x0 >> 70)) & 1023u);
            case 0u: ;
        }
        r0.y ^= (((unsigned)w0 + u0) / (v0 | 1u));
        c1 = (signed char)((0xc903cd23u + 0x7fffffffu) | -((unsigned)l0 - (unsigned)(x0 >> 70)));
    }
    if ((0xd26f340eu ^ u1)) goto L0;
    l0 = (long)((unsigned long)l0 + (fuel * i1));
    s1 = (int)((unsigned)s1 + (unsigned)((int)(0xffffffffu - (g0 ^ (unsigned)((short)0x7fffffffu > (signed char)(unsigned)h0))) >= (int)a0[u1 & 3u]));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (*q0) break;
        r0.y ^= 0xff6d2f6eu;
        u2 = (m0 >> (0x6ed74825u & 31u));
        s1 = (int)((unsigned)s1 + ((unsigned)((int)0x10000u >= (int)(unsigned)(x0 >> 70)) % ((unsigned)l0 | 1u)));
        break; (void)(p2);
    }
    if ((unsigned)!(unsigned)((short)(unsigned)d0 > (signed char)(unsigned)w0)) {
        do { if (--fuel == 0u) goto done;
            if (i0) break;
        } while (i0++ < 3u && -((unsigned)w0 / (9u | 1u)));
        *q0 = ((0x7fffffffu / (0x7fffffffu | 1u)) * 0x47d611au);
        do { if (--fuel == 0u) goto done;
            if (0x80000000u) {
                if (budget != 0u) { budget -= 1u; u1 = fn3(((unsigned)(w0 >> 29) * (unsigned)((short)0u > (signed char)0x7fffffffu)), v0, u1); }
                s1 = (int)((unsigned)s1 + (unsigned)(signed char)(unsigned)((int)(unsigned)(0x8914783cu && 0xb646de70u) >= (int)(v0 + (unsigned)c0)));
                s0 = (int)((unsigned)(*q0 == 8u) - a0[i0 & 3u]);
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    continue; (void)((unsigned)((unsigned)s0 < *mp));
                    r0.y ^= (r0.y ? p0 : 6u);
                }
            } else {
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)g1 > (signed char)0x7fffffffu), 0xce17ad9fu, u1); }
                break; (void)((0x954b9d1au * -(unsigned)(g1 || i0)));
                u1 = (unsigned)((int)(p0 << (i2 & 31u)) >= (int)(p0 ^ (unsigned)(0u == (unsigned)f0)));
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (-(i1 * 0x5ffc86e8u)) break;
                    if (p1) {
                        g0 = a0[i0 & 3u];
                    } else {
                        g0 = (0x80000000u + (unsigned)s1);
                    }
                    if (0x7fffffffu) break;
                    if ((unsigned)((int)8u < (int)0x7fffffffu)) continue;
                }
            }
            continue; (void)(((unsigned)((int)(unsigned)h0 < (int)u3) - i2));
            do { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((u3 & ((unsigned)((unsigned)e0 < (unsigned)l0) * p0)) & 1023u);
                u1 = (0xd3b087deu | (1u + a0[u1 & 3u]));
                if (budget != 0u) { budget -= 1u; u1 = fn2((p1 & u3), (0x4d0bd7e7u / (5u | 1u)), ((unsigned)(i2 || (unsigned)w0) / ((unsigned)(w0 >> 29) | 1u))); }
                a0[(unsigned)(i0 == m0) & 3u] = (r0.x - *mp);
            } while (i1++ < 6u && ((unsigned)f0 >> (u1 & 31u)));
            if ((unsigned)(signed char)(0x7fffffffu << (g0 & 31u))) break;
            w0 = w0 * 6364136223846793005ull + ((unsigned)(9u || 1u) ^ (*q0 << (u2 & 31u)));
            if (budget != 0u) { budget -= 1u; u3 = fn1(p1, ((unsigned)f0 & (unsigned)((int)g0 >= (int)6u)), ((unsigned)b0 + (unsigned)b0)); }
        } while (i0++ < 6u && (unsigned)(0x7fffffffu && garr[i1 & 7u]));
        if (7u) goto L2;
        c1 = (signed char)((unsigned)b0 ? (fuel | 0xffffffffu) : (unsigned)((int)u3 < (int)(unsigned)h0));
    }
    do { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)((unsigned)e0 << (u2 & 31u)) < (int)(*mp << ((unsigned)e0 & 31u)));
        break; (void)((unsigned)((unsigned)e0 || ~(2u | *mp)));
        b0 = ((unsigned)h1 << ((garr[u2 & 7u] ? 0x80000000u : (unsigned)(x0 >> 70)) & 31u)) != 0u;
    } while (i0++ < 6u && 0xcdb31703u);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        u2 += ((unsigned)(garr[i1 & 7u] || i1) / ((0u >> (fuel & 31u)) | 1u));
        if (((unsigned)h0 / ((u1 ^ fuel) | 1u))) goto L0;
        h1 = (unsigned short)(h1 + ~(4u ? a0[u1 & 3u] : (unsigned)h1));
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((short)((unsigned)s1 % ((unsigned)b0 | 1u)) > (signed char)p0), (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)((short)8u > (signed char)(unsigned)w0)), (a0[i0 & 3u] - (*mp - p1))); }
        if ((unsigned)((unsigned)h1 && 7u)) continue;
        break; (void)(-(i2 + p0));
    }
    u0 += p2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 4u, 0x2ec38f30u, 0xf7ed507bu },
        { 2u, 0x220b4c1eu, 0xabe8bbaeu },
        { 8u, 0xeb3116bcu, 0xd591c87au },
        { 15u, 0x8a631465u, 0x6da7d1b7u },
        { 12u, 0xd65f8df0u, 0x1c584f80u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
