// test-ssa-source's program of seed 141000437 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x76afb0e3u, g1 = 0x8d97a09du;
static unsigned garr[8] = { 0xc0dbe07du, 0x8419fae5u, 0xd12a6721u, 0xe23625dfu, 0x474a652u, 0xf3105037u, 0xe3ae913du, 0x59bb4c12u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
        L2: if (--fuel == 0u) goto done;
        if ((1u << ((a0[i0 & 3u] / (0x3b08c85bu | 1u)) & 31u))) break;
        L3: if (--fuel == 0u) goto done;
        *q0 = u2;
        L4: if (--fuel == 0u) goto done;
    }
    if (((r0.x * g0) % ((unsigned)h1 | 1u))) goto L4;
    if ((5u / (garr[i1 & 7u] | 1u))) goto L1;
    s1 = (int)((unsigned)s1 + (r0.y | garr[i1 & 7u]));
    i1 = (unsigned)(((unsigned)((unsigned)f0 || g1) << ((unsigned)h1 & 31u)) || 6u) & 15u;
    if ((unsigned)(x0 >> 70)) {
        c1 = (signed char)(0x7fffffffu ^ (unsigned)((int)(unsigned)c0 >= (int)(9u & fuel)));
        r0.x = (0x80000000u << ((unsigned)(0x4760a690u && a0[i0 & 3u]) & 31u));
    } else {
        a0[(i0 * (unsigned)h0) & 3u] = (a0[i0 & 3u] + 8u);
    }
    q0 = &garr[(unsigned)!((m0 & 0x10000u) >> (((unsigned)(a0[u1 & 3u] == (unsigned)(x0 >> 70)) % (0x10000u | 1u)) & 31u)) & 7u];
    if ((unsigned)((unsigned)((int)(unsigned)(x0 >> 70) < (int)0x10000u) || g0)) {
        for (;;) { if (--fuel == 0u) goto done;
            r0.y ^= (((unsigned)s0 - 0x7fffffffu) << ((unsigned)l0 & 31u));
            break; (void)(0x2a2d6950u);
            if ((0x85103f09u ? a0[i0 & 3u] : u0)) break;
        }
        if ((unsigned)((int)p1 < (int)(i0 - r0.x))) goto L1;
        u3 ^= (unsigned)(short)(8u - (0x80000000u ^ i2));
        if ((unsigned)(0x80000000u < (0x3b67904au | garr[i1 & 7u]))) goto L3;
    } else {
        h1 = (unsigned short)(h1 + (unsigned)(6u || ((0x7fffffffu + v0) << (1u & 31u))));
        if ((unsigned)((unsigned)(short)(4u / (8u | 1u)) && 0x10000u)) {
            s1 = (int)((unsigned)s1 + 6u);
            { unsigned t0; double z0; if ((0xffffffffu) & 1u) { t0 = ~(u3 + u2); z0 = (double)(((0x7fffffffu % ((unsigned)!(i2 ^ p0) | 1u))) & 255u); } if ((0xffffffffu) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                *q0 += (unsigned)((p0 | (unsigned)(w0 >> 29)) == 0u);
                u3 += (((a0[u1 & 3u] & u1) >> ((unsigned)h1 & 31u)) & *mp);
                d0 = d0 * 0.5 + (double)((unsigned)((0x12687936u % ((unsigned)l0 | 1u)) || i1) & 1023u);
                g1 += 0xffffffffu;
            }
            m0 ^= ((unsigned)(unsigned char)(unsigned)(3u < (unsigned)w0) ^ (unsigned)(unsigned char)(unsigned)((short)(unsigned)d0 > (signed char)u3));
            if ((unsigned)((unsigned)w0 < u2)) goto L2;
        }
    }
    r0.x = (unsigned)(g1 < p1);
    goto L4;
    if ((unsigned)(g1 && u1)) {
        s1 = (int)((unsigned)s1 + (unsigned)(x0 >> 70));
        h1 = (unsigned short)(h1 + r0.x);
        if ((a0[i0 & 3u] ? m0 : 7u)) goto L2;
    } else {
        if (2u) goto L4;
        if (5u) {
            s1 = (int)((unsigned)s1 + (((7u ^ (unsigned)(short)(*mp + (unsigned)f0)) >> (a0[u1 & 3u] & 31u)) ^ g0));
            if ((u0 | p1)) goto L4;
            goto done;
        } else {
            x0 = x0 * 0x100000001b3ull + ((unsigned)(w0 >> 29) + 4u);
            d0 = d0 * 0.5 + (double)((a0[i0 & 3u] + (g1 << (u0 & 31u))) & 1023u);
            x0 = x0 * 0x100000001b3ull + (unsigned)((0x3edf7e5eu % ((unsigned)(signed char)((unsigned)l0 | p1) | 1u)) == ((unsigned)e0 / (0x7fffffffu | 1u)));
        }
        goto L4;
        if (u1) goto done;
    }
    q0 = &garr[3u & 7u];
    r0.y ^= (unsigned)((short)~(0x80000000u + u1) > (signed char)0xffffffffu);
    if ((unsigned)(w0 >> 29)) goto L0;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        while ((unsigned)c0) { if (--fuel == 0u) goto done;
            if ((unsigned)(((unsigned)d0 / ((unsigned)w0 | 1u)) == garr[u2 & 7u])) {
                break; (void)((unsigned)((unsigned)h1 < 0xd19b1a9cu));
            } else {
                break; (void)((-((unsigned)d0 + garr[u2 & 7u]) >> (p0 & 31u)));
                if (r0.y) break;
                g1 += (((unsigned)c1 - 0x80000000u) + (unsigned)!(unsigned)((4u & (unsigned)d0) || 9u));
                u3 = u3 * 0x9e3779b1u + ((a0[u1 & 3u] ? fuel : (unsigned)d0) % ((a0[u1 & 3u] + 4u) | 1u));
            }
        }
        { unsigned t1; double z1; if (((*q0 >> ((unsigned)(0x10000u < i0) & 31u))) & 1u) { t1 = (unsigned)(*q0 < 0x2f5647d5u); z1 = (double)(((unsigned)(w0 >> 29)) & 255u); } if (((*q0 >> ((unsigned)(0x10000u < i0) & 31u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            if ((unsigned)(x0 >> 70)) break;
            if (8u) {
                if (((0x10000u ^ 0xffffffffu) + i0)) {
                    l0 = (long)((unsigned long)l0 + (-(unsigned)((int)fuel >= (int)0x7fffffffu) | ((7u - 0xf7ebe5a1u) / ((unsigned)h1 | 1u))));
                    garr[(unsigned)(u3 || p2) & 7u] = (unsigned)(0xf811d0a2u || ((unsigned)d0 & 2u));
                } else {
                    garr[~((unsigned)e0 ^ u0) & 7u] = (u1 << (0x80000000u & 31u));
                    g0 = (unsigned)!(unsigned)((int)(0x93a0dca1u ^ 0xffffffffu) < (int)(unsigned)((unsigned)l0 == (unsigned)c1));
                }
                c1 = (signed char)(0xd080cab8u | ((unsigned)(w0 >> 29) * (unsigned)s0));
                s0 = (int)(unsigned)(m0 < ~(unsigned)(u3 == 0xd612566u));
            }
        }
    }
    while (i0++ < 4u && (unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)((short)7u > (signed char)(unsigned)w0) || *mp)) continue;
    }
    *q0 += u3;
    if ((unsigned)((unsigned)(w0 >> 29) || 0xb0b8dfbfu)) goto L0;
    if (fuel < 8u) return 7u;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && ((unsigned)b0 & u2)) { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t2; double z2; if (((r0.x >> (i0 & 31u))) & 1u) { t2 = (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)x0); z2 = (double)(((0x68fe8e45u % (garr[u2 & 7u] | 1u))) & 255u); } if (((r0.x >> (i0 & 31u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    s0 = (int)(((unsigned)f0 + i2) >> (((unsigned)h0 * 0x80000000u) & 31u));
                }
            }
            a0[*mp & 3u] = (unsigned)((short)~((unsigned)h0 % (*mp | 1u)) > (signed char)0x9474ef9au);
            break; (void)((unsigned)(p1 < 0x80000000u));
            *q0 = (p0 ^ 9u);
            if ((0x590c2abu ^ u0)) goto L0;
        }
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(v0);
            if ((((unsigned)b0 ^ *q0) >> (g0 & 31u))) break;
            goto L4;
            if (p1) break;
        }
        switch ((unsigned)e0 & 7u) {
            goto L2;
            case 6u: ;
        }
        if (*mp) break;
        *q0 = (0xcd3bdd38u - (garr[i1 & 7u] / ((unsigned)((int)0x7fffffffu < (int)(unsigned)w0) | 1u)));
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((0xee3c72fbu + 4u)) break;
        if (fuel) break;
    }
    if (0u) {
        if (((i1 | *mp) & m0)) goto L0;
        switch ((((unsigned)(x0 >> 70) ^ *mp) ^ p1) & 7u) {
            e0 = e0 * 0.5L + (long double)(m0 & 1023u);
            { unsigned t3; double z3; if (((*mp | (unsigned)(signed char)(unsigned)((int)0xb99b6cdcu < (int)v0))) & 1u) { t3 = u1; z3 = (double)(((((unsigned)c0 % (1u | 1u)) % (0xb44a7f97u | 1u))) & 255u); } if (((*mp | (unsigned)(signed char)(unsigned)((int)0xb99b6cdcu < (int)v0))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                case 1u: ;
                do { if (--fuel == 0u) goto done;
                    case 0u: ;
                    c1 = (signed char)(8u >> ((0xbae5ab0u ^ (unsigned)((short)(a0[u1 & 3u] & v0) > (signed char)0xffffffffu)) & 31u));
                    case 3u: ;
                    *q0 = (unsigned)s0;
                } while (i0++ < 6u && (unsigned)((int)fuel < (int)p0));
                u3 += (unsigned)((short)(unsigned)f0 > (signed char)(unsigned)((int)u1 < (int)(unsigned)c0));
            }
            garr[(unsigned)(short)(u1 / (0x10000u | 1u)) & 7u] = (((unsigned)s1 & g0) & *mp);
        }
        goto L3;
        w0 ^= (unsigned long long)(unsigned)(0xcc3b32b8u && 0x80000000u) << (((unsigned)h0 << (g0 & 31u)) & 63u);
        if ((0x3e02a3beu - (unsigned)((unsigned)x0 < (unsigned)e0))) {
            if ((0xffffffffu + 4u)) goto L3;
            while (i0++ < 4u && (unsigned)(unsigned char)((unsigned)h1 ? u2 : r0.y)) { if (--fuel == 0u) goto done;
                if ((unsigned)(short)(m0 | (unsigned)x0)) break;
                break; (void)(p1);
            }
            while (i0++ < 5u && ((unsigned)s1 / (r0.x | 1u))) { if (--fuel == 0u) goto done;
                if (0xffffffffu) break;
                if ((unsigned)e0) break;
            }
            d0 = d0 * 0.5 + (double)((0xc7794a49u ^ *q0) & 1023u);
        } else {
            goto L2;
        }
    } else {
        if ((unsigned)((short)(fuel % (1u | 1u)) > (signed char)0x7fffffffu)) goto L2;
        w0 ^= (unsigned long long)(garr[u2 & 7u] << (u3 & 31u)) << (((unsigned)((int)garr[u2 & 7u] >= (int)6u) / (((unsigned)d0 * -((unsigned)c0 & a0[u1 & 3u])) | 1u)) & 63u);
    }
    if (0xe3989775u) goto L1;
    goto done;
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            g0 = i0;
            r0.y ^= ((a0[i0 & 3u] * (unsigned)(garr[u2 & 7u] == 5u)) << (r0.y & 31u));
            if ((unsigned)(signed char)((unsigned)(garr[u2 & 7u] && 0x80000000u) / ((unsigned)s0 | 1u))) break;
            while (i2++ < 2u && (unsigned)(i1 == (unsigned)((int)0x10000u < (int)2u))) { if (--fuel == 0u) goto done;
                if (((unsigned)(fuel < a0[u1 & 3u]) >> (i2 & 31u))) break;
                if ((unsigned)!((unsigned)c1 + (unsigned)h0)) {
                    e0 = e0 * 0.5L + (long double)((0x80000000u / ((unsigned)((unsigned)h1 == (unsigned)((unsigned)(a0[i0 & 3u] && i0) < (unsigned)h0)) | 1u)) & 1023u);
                    *q0 += (0x80000000u ? a0[i0 & 3u] : (unsigned)w0);
                    if ((unsigned)((unsigned)x0 || (unsigned)(x0 >> 70))) break;
                    break; (void)(((unsigned)(unsigned char)(0x379e1ddfu / (i2 | 1u)) ^ p2));
                } else {
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)(unsigned char)(~(fuel * (unsigned)(w0 >> 29)) + *mp)) {
                            q0 = &garr[(unsigned)h1 & 7u];
                            *q0 += (p0 - (unsigned)((short)v0 > (signed char)3u));
                            e0 = e0 * 0.5L + (long double)((unsigned)((0x7fffffffu ? v0 : 0u) == (unsigned)h1) & 1023u);
                            d0 = d0 * 0.5 + (double)((unsigned)((short)garr[u2 & 7u] > (signed char)0x7fffffffu) & 1023u);
                            garr[(unsigned)d0 & 7u] = (0x783e8ecdu >> (0x53e643c3u & 31u));
                            q0 = &garr[((unsigned)s0 ? 0xdf962329u : (unsigned)(signed char)((unsigned)l0 | 7u)) & 7u];
                        } else {
                            if (((unsigned)l0 << ((unsigned)(0x4530918au && 0x80000000u) & 31u))) break;
                            l0 = (long)((unsigned long)l0 + ((unsigned)(x0 >> 70) & 0u));
                        }
                        *mp = (u0 - (unsigned)((8u & 0x80000000u) || v0));
                        b0 = (unsigned)((unsigned)((0xffffffffu << (m0 & 31u)) == (unsigned)e0) == -(p0 * g1)) != 0u;
                        l0 = (long)((unsigned long)l0 + ((unsigned)h1 * 0x5d00c25eu));
                    } while (i0++ < 3u && (unsigned)(signed char)(unsigned)((short)(unsigned)b0 > (signed char)0x10000u));
                }
                u0 ^= 9u;
                break; (void)(0x3b9e63fu);
                g0 = (4u ^ (unsigned)((short)g1 > (signed char)garr[u2 & 7u]));
            }
            if (v0) break;
        }
        i1 = (unsigned)(signed char)(7u % ((unsigned)(m0 < (unsigned)w0) | 1u)) & 15u;
        a0[i1 & 3u] = 0xd80c8966u;
        if ((((unsigned)l0 / (u2 | 1u)) >> (0x80000000u & 31u))) break;
    } while (i0++ < 3u && (u1 >> (((unsigned)s1 >> (fuel & 31u)) & 31u)));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0x842bdfd4u) goto L1;
        do { if (--fuel == 0u) goto done;
            goto L0;
            if ((garr[u2 & 7u] - (unsigned)(x0 >> 70))) break;
            if (i2) break;
            if ((unsigned)((int)g0 < (int)0xad99f763u)) continue;
            if (-((unsigned)(signed char)(unsigned)((short)0x103449a7u > (signed char)(unsigned)b0) - (unsigned)h0)) break;
        } while (i1++ < 5u && (unsigned)(r0.y < (unsigned)((short)(unsigned)h0 > (signed char)(unsigned)s0)));
        l0 = (long)((unsigned long)l0 + 8u);
        { unsigned t4; double z4; if (((unsigned)x0) & 1u) { t4 = (unsigned)((unsigned)l0 == (unsigned)(4u && (unsigned)(x0 >> 70))); z4 = (double)(((unsigned)(0x80000000u || 3u)) & 255u); } if (((unsigned)x0) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)c0 < 5u)) break;
                break; (void)(((a0[i0 & 3u] ^ g0) % (a0[u1 & 3u] | 1u)));
                switch ((0x80000000u - (i2 | (unsigned)f0)) & 7u) {
                    if (fuel < 8u) return ((g1 % (*q0 | 1u)) % ((unsigned)e0 | 1u));
                    case 3u: ;
                    if ((0x7fffffffu + (unsigned)e0)) goto L2;
                    if ((0x3d1699acu / (a0[u1 & 3u] | 1u))) goto L2;
                    switch (0x7fffffffu & 7u) {
                        case 2u: ;
                        case 3u: ;
                        v0 = (0xab3f4fb4u ? u1 : -(v0 ^ (unsigned)(x0 >> 70)));
                        u2 += (unsigned)((garr[i1 & 7u] | g0) == u3);
                    }
                    f0 = f0 * 0.5f + (float)(0x9922fba4u & 255u);
                }
                if (9u) break;
                break; (void)((unsigned)(0x80000000u && ((unsigned)s0 * (unsigned)f0)));
            }
            if ((unsigned)c1) continue;
            b0 = (0xf03a4424u >> (4u & 31u)) != 0u;
            w0 = w0 * 6364136223846793005ull + (unsigned)(a0[i0 & 3u] || (unsigned)c1);
            break; (void)((3u / (garr[u2 & 7u] | 1u)));
            *q0 = ((unsigned)b0 & ((unsigned)(0xffffffffu && (unsigned)d0) + 0x3b3fcb79u));
        }
    }
    b0 = 0x9f201f1cu != 0u;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0x80000000u) break;
        if ((g1 ^ (0u + i2))) {
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (p1) break;
                x0 = x0 * 0x100000001b3ull + ((unsigned)(0x7fffffffu && (unsigned)d0) >> (((unsigned)!(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)p1) ^ v0) & 31u));
            }
            u1 += (r0.x ^ ((unsigned)((short)(unsigned)x0 > (signed char)2u) * g1));
            { unsigned t5; double z5; if (((garr[u2 & 7u] + (0xffffffffu - 2u))) & 1u) { t5 = (unsigned)s1; z5 = (double)((i0) & 255u); } if (((garr[u2 & 7u] + (0xffffffffu - 2u))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                a0[(unsigned)(unsigned char)(unsigned)(0xc6180815u < (unsigned)d0) & 3u] = r0.y;
                if (fuel < 8u) return (r0.y * (unsigned)(w0 >> 29));
                break; (void)((unsigned)((unsigned)((short)0x10000u > (signed char)0x40516ba9u) < a0[i0 & 3u]));
            }
            do { if (--fuel == 0u) goto done;
                break; (void)(u0);
                if (i1) {
                    i0 = (unsigned)((int)2u >= (int)(6u ? 0xffffffffu : u2)) & 15u;
                    if (0x370eb8d4u) break;
                } else {
                    w0 ^= (unsigned long long)((unsigned)(x0 >> 70) % (v0 | 1u)) << ((r0.x - (unsigned)s1) & 63u);
                }
            } while (i1++ < 2u && r0.x);
            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(x0 >> 70) < p0) & 1023u);
        }
    }
    *q0 = (unsigned)(~(0x10000u & 0x715c47du) == (unsigned)x0);
    *q0 += 0xffffffffu;
    l0 = (long)((unsigned long)l0 + 0x67bd1e99u);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        goto L4;
        if (a0[i0 & 3u]) continue;
        break; (void)((p2 / (i1 | 1u)));
        c0 = (unsigned char)(unsigned)((int)(7u % (0x46fd50c7u | 1u)) >= (int)(2u | 0x7fffffffu));
        if ((unsigned)((unsigned)w0 < (unsigned)((int)(unsigned)d0 < (int)p2))) break;
    }
    if (((a0[u1 & 3u] + v0) - (unsigned)s0)) {
        if (((unsigned)e0 | 6u)) {
            if (u2) goto done;
            w0 ^= (unsigned long long)garr[i1 & 7u] << ((fuel - (unsigned)c1) & 63u);
            c0 = (unsigned char)0x9812073fu;
            if (((unsigned)f0 & (unsigned)d0)) goto L2;
        }
    } else {
        if ((4u & (unsigned)((int)u2 < (int)a0[u1 & 3u]))) goto L0;
        if (u3) goto done;
        switch ((garr[i1 & 7u] * 9u) & 7u) {
            case 3u: ;
            e0 = e0 * 0.5L + (long double)(((2u - 3u) ^ ((unsigned)(signed char)(m0 % ((unsigned)s1 | 1u)) % (u3 | 1u))) & 1023u);
            case 5u: ;
            case 0u: ;
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)s0 >= (int)(unsigned)((int)(unsigned)(4u || 0x9a070b3u) >= (int)(a0[u1 & 3u] % (p2 | 1u))));
    }
    if (r0.y) goto L3;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 3u && m0) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if (0x97730605u) break;
                garr[a0[u1 & 3u] & 7u] = (unsigned)(signed char)(unsigned)((unsigned)h1 && (unsigned)x0);
                s0 = (int)(unsigned)((u3 * (a0[u1 & 3u] >> ((unsigned)c0 & 31u))) == (unsigned)(5u == (unsigned)(x0 >> 70)));
                if ((unsigned)(unsigned char)(u3 ? 0xffffffffu : m0)) break;
                if (i0) break;
                garr[(unsigned)((int)v0 >= (int)0x10000u) & 7u] = (unsigned)(short)(unsigned)((unsigned)h1 || *mp);
            } while (i2++ < 7u && 0xadc54508u);
            g1 += garr[i1 & 7u];
            break; (void)(((unsigned)h0 << ((unsigned)c0 & 31u)));
        }
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            garr[garr[u2 & 7u] & 7u] = m0;
            while (*q0) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)((unsigned)s0 || r0.x));
                u0 = (u1 / (garr[i1 & 7u] | 1u));
            }
            e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)((short)0xffffffffu > (signed char)0x10000u) > (signed char)i1) & 1023u);
            if ((*mp + (unsigned)((int)(unsigned)b0 >= (int)r0.x))) {
                r0.x = ((p1 ? (unsigned)l0 : 0x871119d2u) * (unsigned)(r0.x == (unsigned)f0));
                b0 = -(unsigned)((int)(unsigned)((short)(unsigned)x0 > (signed char)((unsigned)s1 * (unsigned)l0)) >= (int)0x84388d11u) != 0u;
                if (((u2 % ((unsigned)c0 | 1u)) / (*mp | 1u))) break;
                c0 = (unsigned char)(((unsigned)((int)4u < (int)i0) % (*q0 | 1u)) * 0x8a481764u);
                i0 = 0xa23e6ec7u & 15u;
            }
            do { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(u3 & 1023u);
            } while (i2++ < 3u && 0x38ba90e6u);
        }
        { unsigned t6; double z6; if (((v0 << (~(m0 ^ 0x579e7e64u) & 31u))) & 1u) { t6 = ((0x7f1ec40eu % (0xcb39e830u | 1u)) + 0x3554f49fu); z6 = (double)(((unsigned)(r0.x || (unsigned)d0)) & 255u); } if (((v0 << (~(m0 ^ 0x579e7e64u) & 31u))) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
            if ((unsigned)((unsigned)(unsigned char)(p1 ^ (unsigned)s0) || p0)) break;
            x0 = x0 * 0x100000001b3ull + (unsigned)l0;
            if (u3 == 7u) return (0x7eabb82eu % ((garr[i1 & 7u] - (unsigned)l0) | 1u));
            if ((((unsigned)b0 >> (0x10000u & 31u)) << ((unsigned)e0 & 31u))) goto L0;
            if ((unsigned)!(unsigned)((short)(unsigned)s1 > (signed char)6u)) break;
            a0[(unsigned)((unsigned)(x0 >> 70) || (unsigned)x0) & 3u] = 3u;
        }
        { unsigned t7; double z7; if (((unsigned)((unsigned)(w0 >> 29) < v0)) & 1u) { t7 = (unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)(x0 >> 70)); z7 = (double)(((unsigned)(x0 >> 70)) & 255u); } if (((unsigned)((unsigned)(w0 >> 29) < v0)) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
            if (((unsigned)c0 + (unsigned)d0)) continue;
        }
    }
    if (fuel < 8u) return (0x80000000u * (unsigned)(fuel || fuel));
    goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    w0 = w0 * 6364136223846793005ull + (((p1 ? m0 : 3u) ^ 2u) >> ((unsigned)(w0 >> 29) & 31u));
    s1 = (int)((unsigned)s1 + (0x55ea540u / (((r0.y % (0xa1be2652u | 1u)) >> (garr[i1 & 7u] & 31u)) | 1u)));
    r0.y ^= (unsigned)!(((g1 ? v0 : p1) % (u3 | 1u)) & 0xffffffffu);
    goto done;
    switch ((unsigned)((int)0x80000000u >= (int)i2) & 7u) {
        w0 = w0 * 6364136223846793005ull + 0xed191bb5u;
        do { if (--fuel == 0u) goto done;
            break; (void)((unsigned)(0x7fffffffu == (8u * (unsigned)s0)));
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((0x9172725au << (0x80000000u & 31u)));
                v0 = (unsigned)(u1 || (unsigned)(signed char)((unsigned)c1 * (0x6e2adf71u / ((unsigned)w0 | 1u))));
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)e0;
                }
                g1 += ((7u ^ p1) | garr[i1 & 7u]);
                if (budget != 0u) { budget -= 1u; u2 = fn0(((a0[i0 & 3u] & 0x7fffffffu) * 0x10000u), ((0x10000u << ((unsigned)b0 & 31u)) + 5u), (unsigned)!(p1 << (6u & 31u))); }
                s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((int)m0 < (int)(unsigned)((int)g0 >= (int)0xadd004dfu)) < (int)0xef69900au));
            }
            l0 = (long)((unsigned long)l0 + (unsigned)((r0.y ^ (unsigned)e0) && g1));
            q0 = &garr[((unsigned)((int)(unsigned)h1 < (int)3u) + (a0[u1 & 3u] << (g0 & 31u))) & 7u];
            r0.x = (unsigned)(short)(unsigned)((int)g0 >= (int)m0);
        } while (i0++ < 2u && i0);
        { unsigned t0; double z0; if (((unsigned)b0) & 1u) { t0 = (unsigned)((0x10000u + u0) && fuel); z0 = (double)((a0[u1 & 3u]) & 255u); } if (((unsigned)b0) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)0xffffffffu < (int)(unsigned)(unsigned char)(0xb9cd96e0u - (unsigned)l0)), g1, (unsigned)((int)(unsigned)((int)0xdeb4febau >= (int)(unsigned)h1) < (int)u3)); }
            u3 ^= (unsigned)((0x10000u | a0[u1 & 3u]) && 0x7f47e691u);
            s1 = (int)((unsigned)s1 + ((unsigned)(x0 >> 70) << (u3 & 31u)));
            if (budget != 0u) { budget -= 1u; u1 = fn0((i2 * u3), m0, (p1 / (((unsigned)l0 ^ (unsigned)(x0 >> 70)) | 1u))); }
        }
        w0 ^= (unsigned long long)(0x80000000u ^ a0[i0 & 3u]) << (r0.x & 63u);
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)x0) break;
        u2 += ((*mp | (unsigned)((unsigned)(w0 >> 29) < 0xadbbb8dfu)) | (unsigned)b0);
    }
    *mp = (unsigned)(i2 && (unsigned)(signed char)((5u ^ g0) * 0xcce68763u));
    *q0 += (unsigned)((unsigned)((unsigned)e0 < (unsigned)c0) && (unsigned)((int)0x16862ca9u < (int)(unsigned)c1));
    s0 = (int)(~((unsigned)f0 ^ 0x900b12abu) + (1u & p2));
    g1 += (unsigned)(u1 && 5u);
    if ((unsigned)b0) goto L2;
    do { if (--fuel == 0u) goto done;
        *q0 += (unsigned)(unsigned char)(v0 << ((unsigned)x0 & 31u));
        h1 = (unsigned short)(h1 + (3u << (m0 & 31u)));
        { unsigned t1; double z1; if (((unsigned)((short)2u > (signed char)i2)) & 1u) { t1 = i1; z1 = (double)(((unsigned)f0) & 255u); } if (((unsigned)((short)2u > (signed char)i2)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            continue; (void)((unsigned)(signed char)(unsigned)(i2 && (unsigned)(unsigned char)(unsigned)((int)garr[i1 & 7u] >= (int)p0)));
        }
    } while (i0++ < 3u && (unsigned)h1);
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)h0, v0, u1); }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(a0[u1 & 3u]);
        break; (void)(u3);
        v0 = (i1 << (u0 & 31u));
        v0 = ((0x735140f3u ^ 7u) % ((unsigned)c1 | 1u));
        switch ((unsigned)(4u == (unsigned)d0) & 7u) {
            w0 ^= (unsigned long long)(5u ^ (unsigned)d0) << (((0x62d2732bu + (unsigned)f0) / ((u3 >> (u2 & 31u)) | 1u)) & 63u);
            if (-((unsigned)((int)8u >= (int)r0.y) | 0xffffffffu)) continue;
        }
    }
    goto L2;
    d0 = d0 * 0.5 + (double)(((unsigned)(5u || a0[u1 & 3u]) ^ (unsigned)(unsigned char)(unsigned)(((unsigned)w0 | u3) && i0)) & 1023u);
    h0 = (short)(5u << ((i0 | (unsigned)(0x4d7fee79u || *q0)) & 31u));
    w0 ^= (unsigned long long)(unsigned)(a0[i0 & 3u] || 0xffffffffu) << (((i0 | (unsigned)c0) * (unsigned)l0) & 63u);
    d0 = d0 * 0.5 + (double)((((unsigned)((int)u2 >= (int)(g1 >> (0x45681906u & 31u))) / (a0[u1 & 3u] | 1u)) + 2u) & 1023u);
    b0 = (unsigned)w0 != 0u;
    if (budget != 0u) { budget -= 1u; u1 = fn0((0x80000000u >> (*mp & 31u)), (6u >> (0x7fffffffu & 31u)), ((unsigned)((int)v0 >= (int)i1) * 0x10000u)); }
    do { if (--fuel == 0u) goto done;
        continue; (void)((unsigned)w0);
        switch (-(i1 % (r0.x | 1u)) & 7u) {
            case 7u: ;
            q0 = &garr[9u & 7u];
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x10000u || ((unsigned)c0 >> (i2 & 31u))), ((unsigned)w0 % ((unsigned)s0 | 1u)), (garr[u2 & 7u] | g1)); }
        }
    } while (i0++ < 7u && (0xdd75b027u | 0x10000u));
    while ((0x1bfb958fu | 5u)) { if (--fuel == 0u) goto done;
        if (1u) {
            for (;;) { if (--fuel == 0u) goto done;
                if ((0x6795b5b8u ? u1 : v0)) break;
            }
            if (5u) break;
            s1 = (int)((unsigned)s1 + (unsigned)(short)(((unsigned)l0 | 3u) / (g0 | 1u)));
            L0: if (--fuel == 0u) goto done;
        }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + ((unsigned)w0 % (i0 | 1u));
            if ((unsigned)((int)(unsigned)(r0.y < i1) < (int)i2)) {
                if ((unsigned)(signed char)(unsigned)((int)(unsigned)c1 < (int)(r0.x + (unsigned)d0))) goto done;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(unsigned)(garr[u2 & 7u] < 0x80000000u) & 255u);
                }
            } else {
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (unsigned)(0x7fffffffu && (fuel / (0x7fffffffu | 1u))));
                    break; (void)((unsigned)(x0 >> 70));
                    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        u0 ^= (0x10000u ? ((unsigned)((unsigned)c1 == (unsigned)e0) + (unsigned)h1) : 1u);
                        q0 = &garr[(unsigned)(*mp < (unsigned)((int)0x7fffffffu < (int)(unsigned)(x0 >> 70))) & 7u];
                    }
                    u3 ^= (unsigned)(signed char)(unsigned)(fuel == 0x10e97183u);
                    { unsigned t2; double z2; if (((p2 ^ (unsigned)(0x80000000u || a0[u1 & 3u]))) & 1u) { t2 = -(~(unsigned)((short)(unsigned)c0 > (signed char)(unsigned)s0) % ((unsigned)x0 | 1u)); z2 = (double)(((0xffffffffu << ((unsigned)e0 & 31u))) & 255u); } if (((p2 ^ (unsigned)(0x80000000u || a0[u1 & 3u]))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                        u0 = u0 * 0x9e3779b1u + (unsigned)((int)(unsigned)c1 >= (int)(unsigned)(6u == ((unsigned)h0 << (v0 & 31u))));
                    }
                }
                while (i2++ < 7u && (4u + (a0[i0 & 3u] << (v0 & 31u)))) { if (--fuel == 0u) goto done;
                    { unsigned t3; double z3; if (((unsigned)((int)a0[u1 & 3u] < (int)r0.x)) & 1u) { t3 = ((i2 | 0x22736ac7u) % ((unsigned)f0 | 1u)); z3 = (double)(((unsigned)(signed char)((unsigned)c0 >> ((unsigned)x0 & 31u))) & 255u); } if (((unsigned)((int)a0[u1 & 3u] < (int)r0.x)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                        if (budget != 0u) { budget -= 1u; u2 = fn0(1u, (0x820dca3au / (v0 | 1u)), (unsigned)((unsigned)(2u && i0) < 0x7fffffffu)); }
                        h1 = (unsigned short)(h1 + ((unsigned)(signed char)((unsigned)((int)8u >= (int)i2) - g1) * (unsigned)(w0 >> 29)));
                        e0 = e0 * 0.5L + (long double)(((i0 ^ (unsigned)e0) + (unsigned)e0) & 1023u);
                        d0 = d0 * 0.5 + (double)((unsigned)((3u & p0) && (unsigned)((short)0u > (signed char)(r0.y & 2u))) & 1023u);
                        *q0 += garr[i1 & 7u];
                        s1 = (int)((unsigned)s1 + (unsigned)w0);
                    }
                    if (0xacb2c18fu) break;
                    if ((g1 ? garr[i1 & 7u] : u0)) {
                        c1 = (signed char)(unsigned)x0;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(i0 < (unsigned)((unsigned)l0 < g0)), (unsigned)((i1 + 0x2a05397eu) && (unsigned)s1), (unsigned)((unsigned)(0x6151a5eu == i2) || (unsigned)h1)); }
                    } else {
                        *mp = (unsigned)(7u && (unsigned)((short)7u > (signed char)((unsigned)d0 - garr[i1 & 7u])));
                        r0.x = (unsigned)s1;
                    }
                    i0 = (unsigned)((int)i2 < (int)((unsigned)l0 ? u3 : i0)) & 15u;
                }
            }
            *mp = i1;
            switch ((0xffffffffu - (i2 >> (4u & 31u))) & 7u) {
                *mp = (-(unsigned)(5u || i2) / (((unsigned)c1 ? i2 : 5u) | 1u));
                u1 = u1 * 0x9e3779b1u + (u2 * (0x80000000u >> ((unsigned)((int)(unsigned)((int)(unsigned)d0 >= (int)(unsigned)l0) < (int)u1) & 31u)));
                case 3u: ;
                if (budget != 0u) { budget -= 1u; u2 = fn0((0x7fffffffu & r0.x), garr[i1 & 7u], r0.y); }
                if ((*q0 * ((unsigned)c0 + p2))) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)0xac63c2b2u > (signed char)u2), *mp, (unsigned)((unsigned)((int)g1 < (int)0x10000u) == (unsigned)(w0 >> 29))); }
                    if (((unsigned)(w0 >> 29) & (unsigned)((unsigned)l0 || 7u))) {
                        u1 = u1 * 0x9e3779b1u + (unsigned)(garr[u2 & 7u] || (unsigned)((short)(i0 % (0xffffffffu | 1u)) > (signed char)0x10000u));
                        if (budget != 0u) { budget -= 1u; u3 = fn0(7u, (unsigned)((short)0x2ab38de1u > (signed char)(*q0 | u0)), u1); }
                        g1 += (unsigned)((unsigned)(x0 >> 70) < ((unsigned)h0 >> ((unsigned)f0 & 31u)));
                        f0 = f0 * 0.5f + (float)(((unsigned)s1 ^ 0xb164082bu) & 255u);
                        c0 = (unsigned char)(unsigned)!(u3 & (unsigned)!(unsigned)(u2 < (unsigned)(w0 >> 29)));
                        if (u0) goto L2;
                    } else {
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(signed char)(0x3ce986b4u ^ p0) & (unsigned)(w0 >> 29)), (p2 | (unsigned)((int)garr[u2 & 7u] < (int)4u)), -(garr[i1 & 7u] | (0xed779725u + u0))); }
                    }
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)((int)u0 < (int)(p1 & 3u)) && garr[u2 & 7u]));
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        c1 = (signed char)(unsigned)(short)(unsigned)((unsigned)((int)0xfe60c3fu < (int)2u) || (v0 ? 0xffffffffu : u3));
                        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                            q0 = &garr[-(0xffffffffu + (0x80000000u ^ i2)) & 7u];
                            default: ;
                            garr[*mp & 7u] = (unsigned)!((unsigned)s0 ^ u0);
                            case 7u: ;
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)f0, 8u, (0x7fffffffu & (unsigned)(short)(0xc097692au << (a0[u1 & 3u] & 31u)))); }
                        }
                        if ((unsigned)((short)u2 > (signed char)v0)) goto L4;
                        q0 = &garr[(a0[u1 & 3u] * (unsigned)(((unsigned)e0 ^ a0[u1 & 3u]) && (unsigned)h0)) & 7u];
                        if (budget != 0u) { budget -= 1u; u3 = fn0(0x80000000u, 2u, 4u); }
                        switch (((unsigned)s0 | (unsigned)c1) & 7u) {
                            h1 = (unsigned short)(h1 + (((unsigned)b0 & (unsigned)x0) - (unsigned)(((unsigned)f0 ^ i1) == u3)));
                            if (budget != 0u) { budget -= 1u; u3 = fn0((0xd5bc52abu * r0.x), (~(unsigned)((int)(unsigned)l0 >= (int)0x54a2bd7du) >> (9u & 31u)), (unsigned)((int)p1 < (int)p1)); }
                        }
                    }
                }
                if (fuel) break;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)p2 > (signed char)(u2 % (p1 | 1u))), (unsigned)(unsigned char)((unsigned)h1 | (a0[i0 & 3u] + (unsigned)c1)), ((unsigned)l0 << (((unsigned)x0 << (g0 & 31u)) & 31u))); }
            goto done;
        }
        break; (void)((unsigned)(x0 >> 70));
        u2 = u2 * 0x9e3779b1u + p0;
        if ((unsigned)((int)(unsigned)b0 >= (int)0xfbec5063u)) {
            L1: if (--fuel == 0u) goto done;
            h0 = (short)((p0 - (g1 + 0x80000000u)) / ((unsigned)f0 | 1u));
            r0.x = (((8u / (*mp | 1u)) / (fuel | 1u)) + (i1 ^ p2));
            u3 += -(unsigned)((int)0x80000000u >= (int)((i2 >> ((unsigned)h0 & 31u)) % (((unsigned)(w0 >> 29) / (0x1437019u | 1u)) | 1u)));
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((p1 % (u0 | 1u))) break;
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)l0 == (((unsigned)f0 % (g1 | 1u)) & m0)));
                if (g1) break;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((*mp + 0u), (0x5def0860u + p1), v0); }
        }
        *mp = (unsigned)((short)(unsigned)!(0xc3dee8e1u ? *mp : (unsigned)s1) > (signed char)garr[u2 & 7u]);
    }
    *q0 = ((unsigned)(0xb76f7329u || (unsigned)h1) << ((i2 << (0xcb8fa442u & 31u)) & 31u));
    switch ((i1 & 1u) & 7u) {
        if (budget != 0u) { budget -= 1u; u2 = fn0(p1, (unsigned)!(unsigned)(0u && ((unsigned)d0 ^ *mp)), (unsigned)((int)(unsigned)((int)garr[i1 & 7u] >= (int)a0[i0 & 3u]) >= (int)(unsigned)w0)); }
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            u1 += (unsigned)((unsigned)(g0 || 0x8d661e1du) || (unsigned)s0);
            if (budget != 0u) { budget -= 1u; u1 = fn0((p1 << ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)u0) & 31u)), g0, (unsigned)((short)v0 > (signed char)(0x1177298bu ^ (unsigned)(w0 >> 29)))); }
            if (garr[u2 & 7u]) {
                u2 += (unsigned)((int)(unsigned)!(0xffffffffu * r0.x) >= (int)(unsigned)(x0 >> 70));
                s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(unsigned)((short)i0 > (signed char)(unsigned)((short)p1 > (signed char)(unsigned)(x0 >> 70))));
                if ((i1 >> ((unsigned)c0 & 31u))) goto L0;
                garr[(garr[u2 & 7u] ^ (unsigned)h0) & 7u] = 0xd6845a8eu;
                L2: if (--fuel == 0u) goto done;
            }
            v0 = (((i1 % ((unsigned)s0 | 1u)) - (unsigned)c0) & (unsigned)f0);
        }
        garr[(unsigned)(r0.y || (unsigned)s0) & 7u] = (unsigned)((unsigned)((int)(unsigned)w0 < (int)(unsigned)b0) || (unsigned)d0);
        if ((unsigned)(*mp && (unsigned)((unsigned)b0 == 0x7fffffffu))) break;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)((unsigned)h1 && p1) >= (int)garr[i1 & 7u]), (g1 * i2), ~(((unsigned)w0 << (i2 & 31u)) * (unsigned)c0)); }
    while (i0++ < 2u && ~((unsigned)c0 % (((unsigned)h0 * 0x7fffffffu) | 1u))) { if (--fuel == 0u) goto done;
        u3 += ((fuel + v0) ? (0x73406e4fu + u1) : 6u);
        if (budget != 0u) { budget -= 1u; u2 = fn0((0xffffffffu / ((r0.y << ((unsigned)f0 & 31u)) | 1u)), (unsigned)(-(0xb0cff0e3u | 0x7fffffffu) < 0x4c81ddefu), ((unsigned)e0 * *mp)); }
        if (((unsigned)(p2 < 0x10000u) % (garr[i1 & 7u] | 1u))) break;
    }
    g0 = ((unsigned)(a0[i0 & 3u] || (unsigned)(0x10000u == 5u)) ^ ((unsigned)h1 & 0x7fffffffu));
L3: if (--fuel == 0u) goto done;
L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)!(p2 - (unsigned)((int)m0 < (int)garr[i1 & 7u]))) {
        u1 += ((0xb3e14128u / ((garr[u2 & 7u] / (v0 | 1u)) | 1u)) + 0xffffffffu);
        { unsigned t0; double z0; if (((garr[i1 & 7u] * (unsigned)(0x72bd9e69u && v0))) & 1u) { t0 = (0x5e5b51b8u * (unsigned)((int)g1 < (int)(unsigned)h1)); z0 = (double)(((unsigned)h0) & 255u); } if (((garr[i1 & 7u] * (unsigned)(0x72bd9e69u && v0))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            L0: if (--fuel == 0u) goto done;
        }
        if (fuel < 8u) return (unsigned)((int)(unsigned)x0 < (int)(unsigned)e0);
        if ((r0.y % (u0 | 1u))) {
            if (u3 == 7u) return (unsigned)c0;
            L1: if (--fuel == 0u) goto done;
            if ((unsigned)((short)(unsigned)((int)a0[u1 & 3u] < (int)fuel) > (signed char)(unsigned)(w0 >> 29))) goto L4;
            u1 = u1 * 0x9e3779b1u + u2;
            L2: if (--fuel == 0u) goto done;
        } else {
            d0 = d0 * 0.5 + (double)((((unsigned)(u2 == (unsigned)b0) * p2) >> ((unsigned)((short)a0[u1 & 3u] > (signed char)*mp) & 31u)) & 1023u);
            s1 = (int)((unsigned)s1 + (((unsigned)((int)6u >= (int)0x59d7240du) ? (unsigned)l0 : 0xffffffffu) / (0x26242384u | 1u)));
            b0 = (unsigned)(short)((unsigned)c0 + *mp) != 0u;
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                v0 = ((unsigned)(((unsigned)s0 * r0.x) && 0x6128ea6au) >> (*mp & 31u));
                L3: if (--fuel == 0u) goto done;
                r0.x = (((unsigned)x0 - (((unsigned)(x0 >> 70) & (unsigned)s0) - garr[u2 & 7u])) * g1);
            }
        }
    } else {
        g0 = ((unsigned)(short)(unsigned)((unsigned)h0 && ((unsigned)c1 * (0x7fffffffu ^ 6u))) | 0x7fffffffu);
        b0 = (p1 >> ((unsigned)l0 & 31u)) != 0u;
        { unsigned t1; double z1; if (((0x80000000u * (unsigned)f0)) & 1u) { t1 = (unsigned)(garr[i1 & 7u] < (unsigned)e0); z1 = (double)(((unsigned)((unsigned)c0 || ((unsigned)d0 % (0x80000000u | 1u)))) & 255u); } if (((0x80000000u * (unsigned)f0)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            L4: if (--fuel == 0u) goto done;
            garr[p2 & 7u] = 0x80000000u;
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)s1 + 9u), (p0 << (u2 & 31u)), (((unsigned)(x0 >> 70) % ((unsigned)c0 | 1u)) * 0u)); }
            g0 = (0xdb339106u << ((unsigned)(signed char)((unsigned)(u2 || *mp) % (fuel | 1u)) & 31u));
            u1 ^= (unsigned)(unsigned char)(unsigned)((short)(unsigned)!(unsigned)(i0 && (unsigned)e0) > (signed char)(unsigned)s0);
        }
        goto L3;
    }
    switch ((*mp + (unsigned)(a0[u1 & 3u] < u0)) & 7u) {
        while (i0++ < 5u && 0x6d2850d1u) { if (--fuel == 0u) goto done;
            case 3u: ;
            case 7u: ;
        }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((int)5u >= (int)(unsigned)(short)(unsigned)((int)(unsigned)l0 >= (int)*q0)) < (unsigned)b0));
        }
    }
    if ((unsigned)(r0.x || (unsigned)(short)(unsigned)((int)(unsigned)f0 < (int)0x80000000u))) goto done;
    a0[(unsigned)((unsigned)h0 == (unsigned)x0) & 3u] = (unsigned)((short)v0 > (signed char)(unsigned)((unsigned)(signed char)(v0 >> (9u & 31u)) < -(u0 + u1)));
    u2 += (unsigned)((unsigned)((int)(unsigned)((unsigned)w0 == g0) >= (int)0xd971d446u) && (unsigned)h0);
    do { if (--fuel == 0u) goto done;
        s0 = (int)((unsigned)s0 | u2);
        *q0 += (unsigned)((short)(unsigned)!(~(unsigned)((int)0xffffffffu >= (int)p2) << (garr[u2 & 7u] & 31u)) > (signed char)p2);
        if (0x80000000u) break;
        g1 += u0;
    } while (i0++ < 5u && (g0 << (1u & 31u)));
    garr[r0.y & 7u] = (unsigned)(unsigned char)((unsigned)((unsigned)(x0 >> 70) || p0) + (unsigned)((unsigned)e0 == (unsigned)((unsigned)h0 || p1)));
    if (u3 == 7u) return (unsigned)f0;
    r0.y ^= (unsigned)(((unsigned)x0 ? u1 : i2) == a0[i0 & 3u]);
    while ((2u / (p2 | 1u))) { if (--fuel == 0u) goto done;
        if (((unsigned)(garr[u2 & 7u] < 0x10000u) | *q0)) break;
        x0 = x0 * 0x100000001b3ull + (9u & ((unsigned)((int)0x56e393e9u >= (int)u2) / ((unsigned)((unsigned)h1 == (unsigned)h0) | 1u)));
        { unsigned t2; double z2; if (((0xba35d851u ^ (unsigned)f0)) & 1u) { t2 = (unsigned)(signed char)(unsigned)((int)0xffffffffu < (int)(*q0 & garr[u2 & 7u])); z2 = (double)(((v0 - u0)) & 255u); } if (((0xba35d851u ^ (unsigned)f0)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            while ((0x10000u << ((unsigned)c1 & 31u))) { if (--fuel == 0u) goto done;
                if (((fuel << ((unsigned)s1 & 31u)) * *q0)) break;
                a0[g1 & 3u] = (unsigned)((int)(unsigned)e0 < (int)(unsigned)s0);
            }
            switch ((unsigned)((int)(garr[u2 & 7u] | g1) >= (int)garr[i1 & 7u]) & 7u) {
                case 0u: ;
                default: ;
            }
            if (m0) {
                d0 = d0 * 0.5 + (double)((unsigned)((short)u0 > (signed char)(r0.x ^ 0xffffffffu)) & 1023u);
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(x0 >> 70), *q0, ((unsigned)(signed char)(unsigned)((int)(unsigned)x0 < (int)0xe4ee12bcu) & g1)); }
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)w0 == (unsigned)(v0 && (unsigned)d0)) & 255u);
                if ((v0 / (*q0 | 1u))) break;
                if (((unsigned)h1 >> (0xffffffffu & 31u))) break;
            }
        }
        v0 = ((unsigned)(unsigned char)(g1 >> (u2 & 31u)) ^ -(1u ^ (unsigned)((int)(unsigned)c1 < (int)0x834b2ce2u)));
        do { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)(unsigned char)((unsigned)!(fuel | 0xd881277fu) ^ fuel);
            if (((unsigned)(w0 >> 29) * 0x28b0cbb9u)) break;
            break; (void)((~((unsigned)w0 - 3u) ^ p1));
        } while (i1++ < 4u && a0[i0 & 3u]);
    }
    goto L0;
    for (;;) { if (--fuel == 0u) goto done;
        b0 = (unsigned)(signed char)(garr[u2 & 7u] * (0x80000000u ? garr[i1 & 7u] : r0.x)) != 0u;
        if (((g1 + (unsigned)d0) ^ 5u)) break;
        b0 = ((fuel / ((unsigned)(0x7fffffffu < (unsigned)d0) | 1u)) + a0[u1 & 3u]) != 0u;
        goto L3;
    }
    w0 ^= (unsigned long long)(unsigned)((int)0x108ff559u < (int)v0) << ((unsigned)e0 & 63u);
    if ((unsigned)(4u < (unsigned)((short)garr[u2 & 7u] > (signed char)0x80000000u))) {
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(signed char)(unsigned)((int)(unsigned)c1 < (int)fuel), (unsigned)h0, (r0.y ? m0 : r0.x)); }
    } else {
        if ((u2 % ((0xffffffffu << ((unsigned)(x0 >> 70) & 31u)) | 1u))) goto L2;
        if (-(0xffffffffu * 0xffffffffu)) goto L0;
        while (i0++ < 4u && (unsigned)d0) { if (--fuel == 0u) goto done;
            b0 = (unsigned)((int)a0[i0 & 3u] < (int)((unsigned)(unsigned char)((unsigned)(p0 < u2) - 0x7fffffffu) * (unsigned)b0)) != 0u;
            q0 = &garr[(unsigned)(a0[i0 & 3u] || (0x290230ebu % (*q0 | 1u))) & 7u];
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)((short)((unsigned)b0 | (u0 | fuel)) > (signed char)(4u >> (a0[i0 & 3u] & 31u))) & 1023u);
                if (budget != 0u) { budget -= 1u; u1 = fn0((u1 - (i1 - 0x10000u)), 8u, (unsigned)((unsigned)b0 < r0.y)); }
            }
            w0 ^= (unsigned long long)(unsigned)s1 << ((unsigned)(p1 || (unsigned)(short)(p0 - u2)) & 63u);
            if ((unsigned)((int)(unsigned)(w0 >> 29) < (int)(r0.x - (unsigned)f0))) break;
        }
        if (garr[u2 & 7u]) goto L3;
    }
    if (*q0) goto L3;
    if (budget != 0u) { budget -= 1u; u0 = fn1(~(unsigned)((unsigned)((unsigned)d0 && 0xd298c6f0u) || (unsigned)e0), -(0xe6c838e6u * 0u), (garr[i1 & 7u] | u2)); }
    x0 = x0 * 0x100000001b3ull + ~(6u + (unsigned)w0);
    s0 = (int)(unsigned)!((unsigned)(0xe4843d6eu < i1) / (*mp | 1u));
    while (p2) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)fuel > (signed char)(0xbeb775ceu % ((unsigned)w0 | 1u))), (unsigned)(*q0 && i0), ((unsigned)(0x555f46cdu || a0[u1 & 3u]) * g1)); }
        b0 = (unsigned)((int)(unsigned)c0 < (int)0xb1006e3cu) != 0u;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            q0 = &garr[(~(unsigned)(v0 || (garr[i1 & 7u] - a0[i0 & 3u])) << (*q0 & 31u)) & 7u];
            u3 ^= (i1 ? (unsigned)h0 : (unsigned)(short)(0x80000000u / (m0 | 1u)));
            v0 = (unsigned)(signed char)(unsigned)((unsigned)((unsigned)(0xad395e18u || 6u) < a0[u1 & 3u]) < 0x10000u);
            switch ((i0 ^ (unsigned)((int)(unsigned)d0 >= (int)g1)) & 7u) {
                if ((unsigned)s0) {
                    case 7u: ;
                    c1 = (signed char)(unsigned)(x0 >> 70);
                    case 0u: ;
                }
            }
        }
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch (p2 & 7u) {
                case 4u: ;
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t3; double z3; if (((unsigned)(0x10000u || a0[u1 & 3u])) & 1u) { t3 = (unsigned)h1; z3 = (double)((u1) & 255u); } if (((unsigned)(0x10000u || a0[u1 & 3u])) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                        *q0 += (unsigned)((short)fuel > (signed char)(((unsigned)x0 % (1u | 1u)) << (4u & 31u)));
                        u2 += (unsigned)w0;
                        do { if (--fuel == 0u) goto done;
                            case 6u: ;
                            b0 = 0x3be9ec99u != 0u;
                            garr[v0 & 7u] = u2;
                            continue; (void)((unsigned)(garr[u2 & 7u] < 0x70288d43u));
                            u2 ^= ((g1 * (unsigned)(short)(a0[u1 & 3u] ^ u2)) - (unsigned)(unsigned char)((unsigned)f0 >> (0x6ae7da19u & 31u)));
                        } while (i0++ < 2u && (r0.x + u0));
                        if (3u) break;
                        default: ;
                        c0 = (unsigned char)(garr[i1 & 7u] + (unsigned)!(unsigned)((int)(unsigned)f0 >= (int)((unsigned)(w0 >> 29) / (0x205194f6u | 1u))));
                    }
                    { unsigned t4; double z4; if (((unsigned)s1) & 1u) { t4 = r0.x; z4 = (double)(((7u | (unsigned)(short)(i2 >> (i1 & 31u)))) & 255u); } if (((unsigned)s1) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                        case 1u: ;
                        g1 += (unsigned)((unsigned)w0 < (3u ^ 0u));
                        case 3u: ;
                        v0 = (unsigned)((short)3u > (signed char)(unsigned)((short)fuel > (signed char)0x4df7f94bu));
                        v0 = (unsigned)((int)0x80000000u < (int)0xffffffffu);
                    }
                }
                c1 = (signed char)(0x7fffffffu - 7u);
                r0.x = (unsigned)(6u && u3);
                if (budget != 0u) { budget -= 1u; u1 = fn0((8u / (0x80000000u | 1u)), (4u - garr[i1 & 7u]), (unsigned)(0u == i0)); }
                if (budget != 0u) { budget -= 1u; u3 = fn1(~(unsigned)((int)r0.y < (int)0x10000u), (unsigned)!(unsigned)(p1 < (p0 ^ (unsigned)b0)), (unsigned)((unsigned)c1 < 0x7fffffffu)); }
            }
        }
        r0.x = ((unsigned)s1 % (i0 | 1u));
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0(0x80000000u, 0xffffffffu, (unsigned)e0); }
    goto L0;
    { unsigned t5; double z5; if ((*mp) & 1u) { t5 = (0xaa009168u | 5u); z5 = (double)((((unsigned)((int)(unsigned)f0 >= (int)(unsigned)x0) - (unsigned)(w0 >> 29))) & 255u); } if ((*mp) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)u1) ? 0x80000000u : 0xffffffffu);
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)b0, i2, (unsigned)s1); }
        }
        if (u1) goto L4;
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((u3 >> (g0 & 31u)));
            break; (void)((unsigned)x0);
            l0 = (long)((unsigned long)l0 + (5u ^ garr[u2 & 7u]));
        }
        garr[(unsigned)d0 & 7u] = (unsigned)((int)p1 < (int)(unsigned)h0);
        do { if (--fuel == 0u) goto done;
            h0 = (short)(((unsigned)(u1 && a0[i0 & 3u]) & u2) % (9u | 1u));
            u0 += fuel;
            e0 = e0 * 0.5L + (long double)((u2 / ((unsigned)((unsigned)f0 == 0x80000000u) | 1u)) & 1023u);
        } while (i0++ < 3u && 0x1a45e24fu);
        if ((unsigned)((unsigned)b0 && a0[i0 & 3u])) goto L3;
    }
    switch ((unsigned)((int)u0 >= (int)(unsigned)((int)u1 < (int)(unsigned)f0)) & 7u) {
        case 6u: ;
        { unsigned t6; double z6; if (((a0[u1 & 3u] << (0xb866986du & 31u))) & 1u) { t6 = ((unsigned)(w0 >> 29) % ((unsigned)e0 | 1u)); z6 = (double)(((unsigned)(fuel && 0x7fffffffu)) & 255u); } if (((a0[u1 & 3u] << (0xb866986du & 31u))) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            for (;;) { if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)(unsigned char)(0xffffffffu / (0xe8f1acb9u | 1u)) & 7u];
            }
            if (i2) {
                g0 = i2;
                case 5u: ;
            }
            *q0 += (unsigned)(short)(unsigned)((int)(unsigned)(p0 < (unsigned)c0) < (int)i2);
            r0.x = (unsigned)s1;
        }
        if (fuel < 8u) return (unsigned)s0;
        { unsigned t7; double z7; if ((((unsigned)h0 * fuel)) & 1u) { t7 = (p2 >> ((4u * u2) & 31u)); z7 = (double)(((unsigned)((int)0xff5daf55u < (int)((unsigned)(w0 >> 29) | 8u))) & 255u); } if ((((unsigned)h0 * fuel)) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
            if ((unsigned)e0) {
                case 0u: ;
            }
            switch (((unsigned)w0 * (unsigned)s0) & 7u) {
                if (~((p2 | p2) ^ m0)) {
                    if (fuel < 8u) return ((unsigned)h1 & (*mp / ((unsigned)((int)(a0[u1 & 3u] + (unsigned)c0) >= (int)4u) | 1u)));
                    i0 = (unsigned)d0 & 15u;
                    s0 = (int)a0[i0 & 3u];
                    if ((unsigned)!(unsigned)(p0 < 0xe5d394e5u)) goto L2;
                } else {
                    if ((unsigned)((int)0u >= (int)(0x10000u * (unsigned)e0))) goto L1;
                }
                case 2u: ;
                f0 = f0 * 0.5f + (float)(((p1 - ((unsigned)c1 ^ (unsigned)(unsigned char)(0xffffffffu + m0))) * (unsigned)s0) & 255u);
                d0 = d0 * 0.5 + (double)((unsigned)((short)(0x7fffffffu ? (unsigned)w0 : (unsigned)(x0 >> 70)) > (signed char)0x10000u) & 1023u);
            }
            if ((unsigned)((unsigned)l0 < (unsigned)((int)5u < (int)0x7ab0faceu))) {
                u0 = u0 * 0x9e3779b1u + (0x7fffffffu << ((unsigned)!(*q0 | (unsigned)f0) & 31u));
                if ((0xffffffffu % (i1 | 1u))) goto L4;
            } else {
                *mp = (r0.x >> (9u & 31u));
            }
            h0 = (short)(0xe1c7c2dau | (unsigned)h0);
            if (~((unsigned)s0 % (0x78fa70b9u | 1u))) goto L1;
            case 3u: ;
        }
    }
    h0 = (short)(*mp + ((unsigned)(((unsigned)h1 % (u1 | 1u)) == (unsigned)s1) >> ((unsigned)b0 & 31u)));
    garr[(unsigned)(fuel < (unsigned)(x0 >> 70)) & 7u] = 7u;
    if (budget != 0u) { budget -= 1u; u3 = fn0(0x80000000u, (unsigned)(unsigned char)(unsigned)(i0 == 0x10000u), 0u); }
    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)w0 / (*q0 | 1u)), (unsigned)l0, (unsigned)x0); }
    if ((unsigned)(garr[i1 & 7u] || g1)) goto done;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(~(0x1e477434u << (g0 & 31u)));
            }
            c0 = (unsigned char)(unsigned)!(unsigned)((short)0x10000u > (signed char)p2);
            q0 = &garr[(unsigned)((short)i2 > (signed char)0x80000000u) & 7u];
        } while (i1++ < 6u && ((unsigned)((int)(unsigned)w0 >= (int)p0) * r0.x));
    }
    garr[(0x7991bde8u | (unsigned)e0) & 7u] = (unsigned)((unsigned)f0 && ((0xf0930985u % (i0 | 1u)) << ((unsigned)h1 & 31u)));
    if ((unsigned)(g1 && r0.x)) {
        while (i0++ < 7u && ((unsigned)(w0 >> 29) / ((unsigned)d0 | 1u))) { if (--fuel == 0u) goto done;
            g0 = (m0 ^ (i1 % (6u | 1u)));
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)(g0 || 4u) ^ g0), (unsigned)((unsigned)c1 == (unsigned)((int)(unsigned)s1 < (int)g0)), r0.x); }
    }
    g0 = (unsigned)((unsigned)((int)(unsigned)h1 >= (int)(*mp % (a0[i0 & 3u] | 1u))) || 0x39ab53c0u);
    if (budget != 0u) { budget -= 1u; u2 = fn0((((unsigned)h1 >> (i1 & 31u)) / (a0[i0 & 3u] | 1u)), 0xc51a6dd0u, 6u); }
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(p0 || (0x4c0185f2u + (unsigned)l0)));
    } while (i0++ < 4u && (unsigned)((short)(unsigned)b0 > (signed char)(unsigned)h1));
    if ((unsigned)(0x5c82c173u == (unsigned)c1)) {
        q0 = &garr[(((garr[u2 & 7u] >> ((unsigned)h0 & 31u)) / (i2 | 1u)) * (unsigned)(x0 >> 70)) & 7u];
        u2 = 7u;
        if ((unsigned)(((unsigned)c1 & 0x48cbc1ecu) || 4u)) goto L3;
        g0 = (g1 + (a0[u1 & 3u] - -(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(i0 + *mp))));
    } else {
        h0 = (short)(unsigned)((int)0xffffffffu < (int)(m0 ? 2u : (unsigned)(0xffffffffu || 0xffffffffu)));
        v0 = (unsigned)(unsigned char)((unsigned)w0 << (u2 & 31u));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (0xe7ede3d3u) {
        if ((0x24636d48u * p2)) {
            if ((unsigned)(short)(u2 ? g0 : u2)) goto L3;
            switch ((unsigned)(unsigned char)(unsigned)(r0.y == *mp) & 7u) {
                u0 += (r0.y ? i1 : 0x7fffffffu);
                m0 ^= ((0xc1722c8au - ((unsigned)f0 / ((unsigned)f0 | 1u))) % (r0.y | 1u));
                i0 = (fuel % ((unsigned)((int)0x7fffffffu >= (int)r0.x) | 1u)) & 15u;
                if ((unsigned)((int)p1 < (int)p0)) {
                    L0: if (--fuel == 0u) goto done;
                    if (((unsigned)e0 + 0x224b0a33u)) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(w0 >> 29), (unsigned)(garr[u2 & 7u] || r0.x), (unsigned)(v0 < (unsigned)((short)u3 > (signed char)(unsigned)w0))); }
                    goto L2;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!(0u & u2), (unsigned)(0x10000u < ((unsigned)l0 | 3u)), (unsigned)d0); }
                } else {
                    m0 ^= (unsigned)((int)9u >= (int)6u);
                }
                L1: if (--fuel == 0u) goto done;
            }
        } else {
            r0.y ^= u3;
            *q0 = (v0 + m0);
            goto L4;
            if (((u3 & 0xb997120du) ^ r0.y)) goto L3;
        }
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + i2;
                s0 = (int)((unsigned)s1 * ((unsigned)(r0.y == u3) - (p0 | (unsigned)x0)));
                switch ((unsigned)(r0.x == 0xf624e784u) & 7u) {
                    if (0x7fffffffu) {
                        w0 ^= (unsigned long long)p1 << (((unsigned)s0 >> ((g1 ? a0[i0 & 3u] : (unsigned)d0) & 31u)) & 63u);
                        case 1u: ;
                        if (budget != 0u) { budget -= 1u; u3 = fn0((u1 | a0[i0 & 3u]), (unsigned)((0xea002a58u * m0) < 0x127d378au), (0u + (0xffffffffu - u3))); }
                        if (budget != 0u) { budget -= 1u; u3 = fn1(0x3a090fdu, ((unsigned)s1 << ((0xe3e120c9u | p0) & 31u)), (0x80000000u | (*q0 >> ((unsigned)w0 & 31u)))); }
                    } else {
                        L2: if (--fuel == 0u) goto done;
                    }
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((unsigned)(x0 >> 70) || r0.y) || ((a0[i0 & 3u] * (unsigned)(w0 >> 29)) + 0x36cbc549u)) & 255u);
                    if ((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)((int)0x2a17895fu >= (int)(unsigned)w0))) {
                        r0.y ^= (m0 << (-((0xde47d6bu ^ 0x65c18c24u) / (~(6u ^ (unsigned)(x0 >> 70)) | 1u)) & 31u));
                        *q0 = (unsigned)((int)(unsigned)c1 >= (int)(unsigned)(x0 >> 70));
                        r0.y ^= (unsigned)((short)(unsigned)c1 > (signed char)(i1 >> (3u & 31u)));
                        e0 = e0 * 0.5L + (long double)((unsigned)(7u == ((garr[i1 & 7u] * (unsigned)s1) / (g1 | 1u))) & 1023u);
                    }
                }
                h1 = (unsigned short)(h1 + garr[i1 & 7u]);
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)(0x3b63e4c4u - (unsigned)h1) < (int)garr[u2 & 7u]);
                if (fuel < 8u) return (unsigned)((unsigned)(x0 >> 70) == (((unsigned)w0 - *mp) | u0));
            } while (i1++ < 7u && (unsigned)(9u && (unsigned)((short)6u > (signed char)0x9c63c806u)));
            switch ((unsigned)((unsigned)(short)(0x15c403f6u - (unsigned)h1) && (unsigned)l0) & 7u) {
                g1 += (unsigned)((short)r0.x > (signed char)(1u / ((0xc518017u ^ 0x10000u) | 1u)));
                if (((0xffffffffu >> (g0 & 31u)) + 0xb51fd0a7u)) break;
                u2 = (((unsigned)((int)g1 >= (int)p2) & 0x10000u) * 5u);
                if ((p2 | 0x80000000u)) {
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(signed char)(p2 / (((unsigned)s1 | (unsigned)e0) | 1u)), 0x4c6fae00u, (unsigned)f0); }
                    v0 = 0x80000000u;
                }
                g1 += (unsigned)((int)(unsigned)(5u && (unsigned)b0) >= (int)(unsigned)c0);
                h0 = (short)(unsigned)(short)(garr[i1 & 7u] * (unsigned)(signed char)(unsigned)((int)(a0[u1 & 3u] / (r0.x | 1u)) >= (int)(0x10000u - 0xffffffffu)));
            }
            if ((g0 - (unsigned)((int)r0.y < (int)*mp))) goto L3;
            r0.x = g1;
        } while (i0++ < 4u && u1);
        L3: if (--fuel == 0u) goto done;
        *mp = -((unsigned)h1 | (unsigned)((int)0x446d3950u < (int)(unsigned)((unsigned)h0 == (unsigned)(w0 >> 29))));
        goto L1;
        if (u3 == 7u) return (m0 % (((m0 & 0xcbcdfb9bu) | garr[u2 & 7u]) | 1u));
    }
    while (i0++ < 4u && (0x7fffffffu << ((unsigned)f0 & 31u))) { if (--fuel == 0u) goto done;
        g0 = (v0 | 0xffffffffu);
        d0 = d0 * 0.5 + (double)((unsigned)((p0 - 0xc51308e9u) || (unsigned)s0) & 1023u);
    }
    if (fuel < 8u) return ((unsigned)(x0 >> 70) % (i0 | 1u));
    if (budget != 0u) { budget -= 1u; u3 = fn1(a0[i0 & 3u], m0, 7u); }
    g0 = (u2 << (((unsigned)c1 + 0x23cd991bu) & 31u));
    garr[(unsigned)d0 & 7u] = ((2u ? 0x80000000u : (v0 | i1)) % (i1 | 1u));
    { unsigned t0; double z0; if (((unsigned)c1) & 1u) { t0 = (unsigned)((int)i0 < (int)((unsigned)s1 + 7u)); z0 = (double)((-(unsigned)((unsigned)h0 < (unsigned)(x0 >> 70))) & 255u); } if (((unsigned)c1) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)((int)p0 < (int)garr[u2 & 7u]) == (unsigned)((short)0x80000000u > (signed char)i1)) | i0);
        }
        if (((unsigned)((short)0x10000u > (signed char)i1) / (u2 | 1u))) goto L3;
    }
    if (((0u | (unsigned)(x0 >> 70)) + a0[i0 & 3u])) goto done;
    if ((0xcdb777f7u >> ((unsigned)(0x10000u || u1) & 31u))) {
        v0 = ((unsigned)c0 - (unsigned)((int)(unsigned)((int)a0[u1 & 3u] >= (int)0xffffffffu) >= (int)0x10000u));
        d0 = d0 * 0.5 + (double)(g1 & 1023u);
        c1 = (signed char)(unsigned)(fuel == (u0 + u3));
        v0 = (unsigned)((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)s0) == 0x10000u);
        i1 = (unsigned)((int)(unsigned)h0 >= (int)0x5fd95eddu) & 15u;
        r0.x = (7u * m0);
    }
    { unsigned t1; double z1; if ((p2) & 1u) { t1 = (i0 ^ (unsigned)((short)*q0 > (signed char)0x10000u)); z1 = (double)(((unsigned)((int)(unsigned)c0 >= (int)0xffffffffu)) & 255u); } if ((p2) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        *mp = (((unsigned)((unsigned)!(0x7fffffffu * *mp) == 0xe6d4e6e1u) | a0[i0 & 3u]) / (i1 | 1u));
        if ((unsigned)((short)(fuel << ((unsigned)f0 & 31u)) > (signed char)a0[i0 & 3u])) goto L0;
        if ((unsigned)((int)9u >= (int)5u)) {
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t2; double z2; if (((unsigned)(0x10000u < 9u)) & 1u) { t2 = i1; z2 = (double)((*mp) & 255u); } if (((unsigned)(0x10000u < 9u)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    L4: if (--fuel == 0u) goto done;
                    for (;;) { if (--fuel == 0u) goto done;
                        if ((unsigned)(x0 >> 70)) break;
                        u0 += (unsigned)((unsigned)c1 < (unsigned)w0);
                        x0 = x0 * 0x100000001b3ull + ((a0[i0 & 3u] | (9u | 0x9e2cfa5au)) | u3);
                        u2 = (unsigned)((int)a0[i0 & 3u] >= (int)(i2 ? 7u : 0x7fffffffu));
                        g0 = (unsigned)((unsigned)(0x10000u < 5u) || (8u + (unsigned)x0));
                    }
                    continue; (void)((p1 ^ 7u));
                }
                if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)((int)fuel < (int)u0) >> (fuel & 31u)), g1, 0x7bcbaca8u); }
                w0 ^= (unsigned long long)p0 << (((unsigned)(short)(m0 | (unsigned)c0) & u3) & 63u);
            }
            if ((unsigned)(0xffffffffu < (r0.x ^ r0.y))) goto L2;
        }
    }
    while (i0++ < 7u && (unsigned)h1) { if (--fuel == 0u) goto done;
        u0 = u0 * 0x9e3779b1u + (unsigned)(u1 && (unsigned)((unsigned)s1 && (0xffffffffu % ((0x7adaad14u * (unsigned)c0) | 1u))));
        if (budget != 0u) { budget -= 1u; u2 = fn0(i2, (unsigned)((unsigned)((int)0x80000000u >= (int)u2) || 0x419caf1cu), (unsigned)((0x733449feu >> (i0 & 31u)) || (unsigned)f0)); }
        if ((unsigned)((short)u1 > (signed char)*mp)) {
            break; (void)((unsigned)((short)(unsigned)(i2 || u3) > (signed char)0x10000u));
            w0 = w0 * 6364136223846793005ull + (i2 & ((unsigned)((unsigned)b0 && (unsigned)f0) ^ (unsigned)((unsigned)s1 || u1)));
            u1 += ((garr[i1 & 7u] & 0xce4d9613u) & (unsigned)((short)9u > (signed char)(unsigned)d0));
            do { if (--fuel == 0u) goto done;
                break; (void)(((i0 | 0xffffffffu) | garr[i1 & 7u]));
                if ((2u | (unsigned)!(0x7fffffffu ^ g0))) continue;
                if ((*q0 / ((unsigned)s0 | 1u))) goto done;
                if (((unsigned)s0 * (a0[u1 & 3u] - a0[u1 & 3u]))) break;
                for (;;) { if (--fuel == 0u) goto done;
                    r0.x = 0x80000000u;
                    v0 = (((unsigned)((short)(unsigned)c1 > (signed char)(unsigned)w0) - (unsigned)h0) % (i0 | 1u));
                    if (((unsigned)l0 & 1u)) break;
                }
            } while (i1++ < 6u && r0.x);
        }
        break; (void)(p0);
    }
    q0 = &garr[(unsigned)(i2 == (unsigned)!(u2 ? (unsigned)((short)0x7fffffffu > (signed char)i2) : u3)) & 7u];
    e0 = e0 * 0.5L + (long double)(((unsigned)(signed char)((unsigned)c0 + (unsigned)e0) / (((unsigned)c0 | 1u) | 1u)) & 1023u);
    r0.x = (unsigned)(unsigned char)(unsigned)((short)p0 > (signed char)0x579e5d44u);
    x0 = x0 * 0x100000001b3ull + v0;
    switch (((unsigned)d0 - (unsigned)c0) & 7u) {
        switch (4u & 7u) {
            do { if (--fuel == 0u) goto done;
                case 2u: ;
            } while (i0++ < 6u && (0x80000000u * (unsigned)c1));
        }
    }
    a0[(i2 & 0x7fffffffu) & 3u] = *mp;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (i2) break;
        c0 = (unsigned char)(g0 << ((unsigned)b0 & 31u));
        x0 = x0 * 0x100000001b3ull + (r0.y ? ((garr[i1 & 7u] << ((unsigned)(w0 >> 29) & 31u)) * u0) : g1);
        u2 = u2 * 0x9e3779b1u + (g1 << ((unsigned)!((unsigned)x0 & i0) & 31u));
        g1 += (unsigned)((int)((unsigned)c1 ^ 0x185d23ceu) >= (int)p2);
    }
    do { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + p2);
    } while (i0++ < 5u && u2);
    if ((r0.y / (0xffffffffu | 1u))) {
        if (2u) {
            f0 = f0 * 0.5f + (float)(p0 & 255u);
            if ((unsigned)((short)(*q0 * 2u) > (signed char)u0)) {
                if ((unsigned)(signed char)(unsigned)(4u == a0[i0 & 3u])) goto L2;
                if (((unsigned)w0 | 4u)) goto L0;
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)((unsigned)s0 == (unsigned)(x0 >> 70)) && (unsigned)l0);
                w0 ^= (unsigned long long)u0 << (u1 & 63u);
                if ((-(unsigned)((short)0x10000u > (signed char)g0) >> ((unsigned)x0 & 31u))) goto L3;
            }
            goto L1;
            s1 = (int)((unsigned)s1 + (unsigned)(signed char)(unsigned)(i1 == (unsigned)((unsigned)(u1 == r0.x) == r0.y)));
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= ((unsigned)!(unsigned)(((unsigned)(x0 >> 70) / ((unsigned)c1 | 1u)) < *q0) ^ garr[i1 & 7u]);
                { unsigned t3; double z3; if (((0x419ac397u / ((unsigned)((unsigned)(x0 >> 70) || 0x737cb049u) | 1u))) & 1u) { t3 = (0x80000000u | (a0[u1 & 3u] + 0xcf4c0a44u)); z3 = (double)(((unsigned)((unsigned)e0 || (m0 & p0))) & 255u); } if (((0x419ac397u / ((unsigned)((unsigned)(x0 >> 70) || 0x737cb049u) | 1u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    if (u3 == 7u) return (unsigned)((int)4u < (int)(unsigned)w0);
                }
                switch ((u0 << (0x9398254u & 31u)) & 7u) {
                    *mp = ((unsigned)h1 + ((i2 * (unsigned)((short)(unsigned)h0 > (signed char)0x7fffffffu)) + 0x80000000u));
                    switch ((unsigned)((int)fuel >= (int)1u) & 7u) {
                        case 4u: ;
                        g0 = (i2 | (unsigned)((unsigned)c0 == (unsigned)s0));
                        if (6u) break;
                        b0 = ((0x10000u / ((p0 ^ 0x10000u) | 1u)) % ((unsigned)b0 | 1u)) != 0u;
                    }
                    if ((unsigned)((unsigned)((short)0x1f998ad5u > (signed char)(unsigned)s1) && (unsigned)s0)) {
                        case 3u: ;
                        u0 = u0 * 0x9e3779b1u + (unsigned)(-(((unsigned)d0 & 0x80000000u) << ((unsigned)(0x55f9d1d1u == (unsigned)h1) & 31u)) && (unsigned)s0);
                    } else {
                        c1 = (signed char)((u1 & p2) << (a0[u1 & 3u] & 31u));
                        a0[p2 & 3u] = (unsigned)c1;
                        goto L4;
                        w0 = w0 * 6364136223846793005ull + ~((unsigned)(*mp < 9u) ^ (unsigned)((short)(unsigned)c0 > (signed char)(p0 % (g0 | 1u))));
                    }
                    continue; (void)((unsigned)c0);
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(u0 && ((unsigned)f0 | 0xffffffffu)), ~(*mp + 0u), m0); }
                    case 5u: ;
                }
                f0 = f0 * 0.5f + (float)((unsigned)(signed char)(unsigned)((short)(unsigned)h1 > (signed char)(unsigned)e0) & 255u);
                garr[i0 & 7u] = ((unsigned)h0 / ((unsigned)x0 | 1u));
            }
        } else {
            if (((unsigned)(short)(0x51f3df0eu + 6u) + u0)) {
                *q0 = i2;
                s0 = (int)((v0 >> ((unsigned)((unsigned)s0 < (unsigned)c0) & 31u)) & (unsigned)(garr[i1 & 7u] < i0));
            }
            s0 = (int)(a0[i0 & 3u] * i1);
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((0x6a587cdfu << (i2 & 31u))) break;
            }
        }
        if ((3u + (unsigned)s1)) {
            goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1((v0 - r0.x), (unsigned)h0, 0xffffffffu); }
        }
        if ((u0 >> ((unsigned)!(unsigned)((int)i0 >= (int)u2) & 31u))) goto L3;
    }
    if (m0) goto L2;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        s0 = (int)(unsigned)w0;
        goto L4;
        q0 = &garr[(unsigned)(r0.y < (unsigned)(unsigned char)(g1 ? 0x7fffffffu : (0xf81c3b58u << (0xdbfdc74cu & 31u)))) & 7u];
        if (budget != 0u) { budget -= 1u; u1 = fn2(0x10000u, (garr[u2 & 7u] >> (i2 & 31u)), p1); }
        goto L3;
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)(((unsigned)((unsigned)x0 < (unsigned)w0) >> (0xffffffffu & 31u)) && r0.x);
    if (*mp) goto L3;
    c0 = (unsigned char)((i2 + 6u) - (unsigned)((unsigned)s0 < garr[u2 & 7u]));
    i2 = (((unsigned)s0 >> ((~(0x7fffffffu | 0xffffffffu) * (unsigned)(w0 >> 29)) & 31u)) | (unsigned)c1) & 15u;
    q0 = &garr[(unsigned)((unsigned)s1 < 0u) & 7u];
    if (p0) goto done;
    if (p1) {
        if ((unsigned)(r0.y && (unsigned)s1)) {
            v0 = (u2 << (garr[i1 & 7u] & 31u));
            a0[p1 & 3u] = (unsigned)(unsigned char)(unsigned)((int)0xffffffffu < (int)r0.y);
            w0 = w0 * 6364136223846793005ull + ((unsigned)!(unsigned)((int)0x7fffffffu < (int)r0.y) >> ((unsigned)((unsigned)c0 || 0x159c66b0u) & 31u));
            do { if (--fuel == 0u) goto done;
                r0.y ^= -(unsigned)((short)(unsigned)((unsigned)((short)9u > (signed char)(unsigned)((unsigned)c0 || i0)) == 0x10000u) > (signed char)0xae85a0edu);
                continue; (void)((unsigned)((int)(unsigned)h0 >= (int)(unsigned)((int)0x686d7395u >= (int)(unsigned)c1)));
            } while (i0++ < 6u && (unsigned)(~(unsigned)((int)i0 < (int)0x7ce7b95eu) || fuel));
            if (~((unsigned)l0 * 0xef67096u)) goto L4;
        } else {
            goto L0;
            if (budget != 0u) { budget -= 1u; u0 = fn2(r0.x, (0xb0758ba2u >> ((p0 - (unsigned)h1) & 31u)), ~(0x10000u * p0)); }
            v0 = ~(-((unsigned)f0 ^ 0xda08c9d5u) % (((unsigned)s1 << ((unsigned)e0 & 31u)) | 1u));
        }
        goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)e0 ? u2 : (unsigned)h1), (0x151ee186u - 0x1e817473u), u1); }
    } else {
        if ((unsigned)e0) goto L0;
        switch (~(p1 * (unsigned)((unsigned)h1 < 5u)) & 7u) {
            d0 = d0 * 0.5 + (double)((unsigned)s0 & 1023u);
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(p0 < (unsigned)c0), (7u ^ v0), i1); }
            r0.y ^= (r0.x / (v0 | 1u));
            *mp = i0;
            r0.x = 0x84d504c0u;
            a0[g1 & 3u] = (unsigned)(p2 == p0);
        }
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)0x10000u < (int)0x10000u)) break;
        if ((0xffffffffu + (unsigned)x0)) goto L4;
        w0 ^= (unsigned long long)u3 << (((unsigned)!(8u ? (unsigned)d0 : (unsigned)(w0 >> 29)) ^ 0xb5114ef9u) & 63u);
        c1 = (signed char)((unsigned)s0 >> ((unsigned)(unsigned char)(unsigned)((short)(unsigned)f0 > (signed char)(unsigned)((unsigned)((short)0u > (signed char)(unsigned)s0) || (unsigned)c0)) & 31u));
        if ((0xffffffffu >> ((unsigned)!(unsigned)(3u && (unsigned)w0) & 31u))) break;
        s0 = (int)(0x1330564cu ? (unsigned)(x0 >> 70) : 0x54530a22u);
    }
    if ((unsigned)((0xffffffffu >> (i1 & 31u)) || 0x80000000u)) {
        if ((4u + (unsigned)(a0[i0 & 3u] < garr[i1 & 7u]))) {
            e0 = e0 * 0.5L + (long double)((unsigned)(a0[u1 & 3u] && (unsigned)((int)g1 < (int)(unsigned)((short)(unsigned)s0 > (signed char)*q0))) & 1023u);
        }
        if ((unsigned)!(((unsigned)b0 + u2) + r0.y)) goto L2;
        if (((a0[i0 & 3u] * i1) & m0)) goto L2;
    }
    while (i0++ < 2u && (((unsigned)(w0 >> 29) ^ m0) >> (u0 & 31u))) { if (--fuel == 0u) goto done;
        g0 = (unsigned)(p1 == (0xffffffffu >> (((unsigned)(w0 >> 29) | 0x80000000u) & 31u)));
        u0 ^= (g0 ^ ((unsigned)h1 & ~(0xffffffffu ? 0xbffbbaa4u : 0x80000000u)));
        g0 = (unsigned)(u2 == 6u);
        g0 = (unsigned)s0;
        if ((0x80000000u & 5u)) break;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)s1 - m0), (7u - 0xffffffffu), (u3 + (unsigned)(u2 == *mp))); }
    c0 = (unsigned char)(unsigned)((unsigned)((unsigned)e0 && (unsigned)(signed char)(unsigned)((short)0xb124bbf5u > (signed char)g1)) && (unsigned)c0);
    if (u1) {
        u2 = (unsigned)(u2 || (unsigned)((short)5u > (signed char)1u));
        if (u3 == 7u) return (7u + fuel);
        { unsigned t4; double z4; if (((0x8e3aedcbu + 4u)) & 1u) { t4 = (unsigned)((unsigned)((int)r0.x >= (int)garr[u2 & 7u]) == 0xfe54a375u); z4 = (double)((0x6c25276cu) & 255u); } if (((0x8e3aedcbu + 4u)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
            if (r0.y) goto L4;
        }
        switch ((-(i2 * u2) * i1) & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)e0 / ((unsigned)c1 | 1u)), (unsigned)((unsigned)((unsigned)(x0 >> 70) == 0xffffffffu) < 2u), ((5u ^ m0) >> (8u & 31u))); }
        }
        while (i0++ < 7u && (unsigned)c1) { if (--fuel == 0u) goto done;
            u0 += (((unsigned)(x0 >> 70) / ((unsigned)(w0 >> 29) | 1u)) << (u0 & 31u));
            if (0x9452d191u) break;
            q0 = &garr[((unsigned)l0 & (p1 - ((unsigned)x0 % ((unsigned)(x0 >> 70) | 1u)))) & 7u];
            if (budget != 0u) { budget -= 1u; u1 = fn1(4u, 0xe7bbbe43u, 1u); }
        }
    } else {
        { unsigned t5; double z5; if (((unsigned)(unsigned char)(unsigned)((int)g0 < (int)(unsigned)(signed char)(i1 - 3u))) & 1u) { t5 = ((unsigned)((int)u1 >= (int)0xf00e814cu) % (0x91d03218u | 1u)); z5 = (double)(((unsigned)(unsigned char)((unsigned)d0 ^ garr[i1 & 7u])) & 255u); } if (((unsigned)(unsigned char)(unsigned)((int)g0 < (int)(unsigned)(signed char)(i1 - 3u))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            goto L3;
            f0 = f0 * 0.5f + (float)((unsigned)(i2 && (r0.y | (unsigned)(signed char)((unsigned)w0 / ((unsigned)d0 | 1u)))) & 255u);
        }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0(0x80000000u, (((unsigned)x0 - (unsigned)d0) & v0), (g0 << (*q0 & 31u))); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto done;
    while (i0++ < 4u && (unsigned)((int)(unsigned)(x0 >> 70) < (int)2u)) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)((int)v0 >= (int)(unsigned)(unsigned char)(unsigned)((short)*q0 > (signed char)(unsigned)b0)));
        x0 = x0 * 0x100000001b3ull + (u2 - i0);
        { unsigned t0; double z0; if (((0x8e645cf4u * (0u & p1))) & 1u) { t0 = (a0[i0 & 3u] / (a0[u1 & 3u] | 1u)); z0 = (double)(((unsigned)l0) & 255u); } if (((0x8e645cf4u * (0u & p1))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            { unsigned t1; double z1; if (((unsigned)w0) & 1u) { t1 = (unsigned)c1; z1 = (double)((u1) & 255u); } if (((unsigned)w0) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                if (0xffffffffu) goto done;
                if (((unsigned)(w0 >> 29) % ((0xffffffffu / ((unsigned)e0 | 1u)) | 1u))) {
                    e0 = e0 * 0.5L + (long double)(0x7fffffffu & 1023u);
                    h0 = (short)(unsigned)(unsigned char)((unsigned)b0 * (unsigned)(w0 >> 29));
                    a0[0xffffffffu & 3u] = (((unsigned)b0 >> ((unsigned)(0xffffffffu < m0) & 31u)) - (unsigned)(short)(unsigned)((short)fuel > (signed char)p0));
                    *q0 += ((i2 ^ 1u) - (unsigned)(x0 >> 70));
                    switch ((5u << (((unsigned)s0 | v0) & 31u)) & 7u) {
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)g1 >= (int)0x21a35438u), 0x40686f5au, 0xdea47d5fu); }
                        h0 = (short)6u;
                        s1 = (int)((unsigned)s1 + ((unsigned)(short)(unsigned)((short)p1 > (signed char)fuel) << (-((unsigned)w0 >> ((0x895322a0u * (unsigned)h0) & 31u)) & 31u)));
                        if ((7u + 0xffffffffu)) continue;
                    }
                    r0.y ^= 9u;
                } else {
                    switch ((m0 & (unsigned)(w0 >> 29)) & 7u) {
                        if (budget != 0u) { budget -= 1u; u0 = fn3((fuel ^ 0x600ffc7au), -(unsigned)(0x10000u && (unsigned)(i2 == 2u)), (unsigned)(p0 || (unsigned)l0)); }
                    }
                }
            }
            v0 = (unsigned)((short)m0 > (signed char)0x791856f4u);
            if ((unsigned)((int)(unsigned)h1 >= (int)(unsigned)(unsigned char)(r0.x / ((unsigned)s0 | 1u)))) {
                a0[0x7fffffffu & 3u] = a0[u1 & 3u];
                if ((unsigned)w0) break;
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)f0 - ((unsigned)c1 ^ garr[u2 & 7u])), 8u, (unsigned)(short)(unsigned)(0xffffffffu || u2)); }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((short)0x7adeac38u > (signed char)(unsigned)c0), ((unsigned)(0xffffffffu && *mp) * (unsigned)l0), ((unsigned)w0 * (unsigned)e0)); }
                break; (void)((7u & (0xa432d301u << (0x80000000u & 31u))));
            }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)(signed char)(unsigned)((short)u0 > (signed char)6u) & u0)) {
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((unsigned)((short)0u > (signed char)garr[u2 & 7u]) && i2)) break;
                        if ((unsigned)c1) {
                            w0 = w0 * 6364136223846793005ull + (((unsigned)w0 / ((p1 >> (5u & 31u)) | 1u)) + (garr[u2 & 7u] / (v0 | 1u)));
                            if ((0x80000000u * (unsigned)(u0 == (unsigned)l0))) continue;
                            s0 = (int)((unsigned)(short)(unsigned)((i2 % (u2 | 1u)) && (p2 ^ (unsigned)s0)) * (unsigned)c0);
                            u2 = (unsigned)((short)(unsigned)c0 > (signed char)0u);
                            if ((garr[u2 & 7u] << (garr[i1 & 7u] & 31u))) continue;
                        } else {
                            if (-(*mp - a0[i0 & 3u])) break;
                        }
                        s0 = (int)-(unsigned)((int)(unsigned)((unsigned)x0 < 0x10000u) >= (int)(6u ^ u3));
                    } while (i2++ < 5u && (unsigned)(0x7fffffffu == ((unsigned)x0 >> (u2 & 31u))));
                    c1 = (signed char)-(unsigned)(*q0 < (r0.x ? p1 : u3));
                } else {
                    r0.y ^= (unsigned)((short)(unsigned)c1 > (signed char)p0);
                    g0 = (unsigned)((short)fuel > (signed char)((unsigned)(0xb5a86b3au < (unsigned)d0) ^ (unsigned)((short)*mp > (signed char)(unsigned)h1)));
                    x0 = x0 * 0x100000001b3ull + ((unsigned)b0 * u3);
                }
                g0 = (unsigned)((r0.x - ((unsigned)(unsigned char)(3u << (r0.y & 31u)) + p0)) == (unsigned)x0);
                h1 = (unsigned short)(h1 + ((p0 & ((unsigned)(a0[i0 & 3u] && g1) + p1)) << (u3 & 31u)));
                if (u3 == 7u) return (u1 + i2);
                *q0 += 0x6dfcb0d0u;
                if (budget != 0u) { budget -= 1u; u2 = fn0((*mp ^ u1), ((unsigned)(w0 >> 29) % ((garr[u2 & 7u] % (*q0 | 1u)) | 1u)), (unsigned)((int)(unsigned)((int)fuel >= (int)(unsigned)w0) < (int)p1)); }
            }
            do { if (--fuel == 0u) goto done;
                if (garr[u2 & 7u]) break;
                garr[i1 & 7u] = u3;
                e0 = e0 * 0.5L + (long double)((p1 << ((8u / ((unsigned)h0 | 1u)) & 31u)) & 1023u);
                if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)e0 / ((unsigned)x0 | 1u)), (0x10000u & (unsigned)h1), (m0 << ((unsigned)h0 & 31u))); }
            } while (i1++ < 7u && (0x5318f16fu << (r0.x & 31u)));
            c1 = (signed char)p0;
        }
        if ((unsigned)((0x7fffffffu / (garr[u2 & 7u] | 1u)) < fuel)) continue;
    }
    goto L4;
    x0 = x0 * 0x100000001b3ull + (((unsigned)h1 | (unsigned)d0) | ((unsigned)((short)0x10000u > (signed char)(unsigned)(x0 >> 70)) - p2));
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((short)v0 > (signed char)(*q0 * (unsigned)s1)));
        break; (void)((unsigned)((unsigned)x0 && (unsigned)c0));
        if (budget != 0u) { budget -= 1u; u2 = fn2(0xcf9263acu, (*mp & (unsigned)d0), u3); }
        u1 = (unsigned)((unsigned)(signed char)(*q0 ? 0x7fffffffu : p0) || (unsigned)((int)u3 < (int)p1));
        w0 = w0 * 6364136223846793005ull + (unsigned)x0;
        if (budget != 0u) { budget -= 1u; u0 = fn0(0xcbbd2a5du, (unsigned)h1, (u1 >> (garr[u2 & 7u] & 31u))); }
    } while (i0++ < 4u && (5u / (fuel | 1u)));
    if (((unsigned)c0 << ((unsigned)((int)0x7fffffffu < (int)(unsigned)s0) & 31u))) {
        d0 = d0 * 0.5 + (double)(((unsigned)(unsigned char)(g0 << (0x80000000u & 31u)) / ((unsigned)(garr[i1 & 7u] || (unsigned)h1) | 1u)) & 1023u);
        *q0 += (unsigned)(garr[u2 & 7u] == (0x11bbc8bcu ? p1 : 0x161753b5u));
        L0: if (--fuel == 0u) goto done;
        { unsigned t2; double z2; if ((0x7fffffffu) & 1u) { t2 = (unsigned)((unsigned)((int)g1 < (int)m0) && 0x69709a35u); z2 = (double)((0x10000u) & 255u); } if ((0x7fffffffu) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)0x10000u > (signed char)(unsigned)((int)8u < (int)u2)), m0, (unsigned)d0); }
            a0[i1 & 3u] = ((unsigned)(unsigned char)(0u + *mp) - g1);
            if (((v0 % (3u | 1u)) << ((unsigned)e0 & 31u))) goto L2;
            c1 = (signed char)g1;
            if ((unsigned)(0x80000000u && (unsigned)c1)) {
                garr[g1 & 7u] = ((unsigned)((unsigned)((int)garr[i1 & 7u] >= (int)p0) && (unsigned)x0) | (unsigned)(u0 < g1));
                if ((unsigned)(short)(a0[i0 & 3u] ^ -(unsigned)((int)(unsigned)c0 >= (int)0x10000u))) goto L1;
            } else {
                f0 = f0 * 0.5f + (float)((unsigned)(p2 && (unsigned)!((unsigned)d0 + i2)) & 255u);
                x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)d0 < ((unsigned)l0 << (((unsigned)(r0.y == 0x10000u) % (*q0 | 1u)) & 31u)));
            }
        }
        l0 = (long)((unsigned long)l0 + (((unsigned)h0 ^ u1) + m0));
    } else {
        if ((unsigned)(short)(unsigned)((int)(unsigned)f0 < (int)u1)) goto L3;
        w0 ^= (unsigned long long)(unsigned)c1 << ((unsigned)((int)fuel < (int)(unsigned)((unsigned)d0 && (unsigned)e0)) & 63u);
        garr[((unsigned)f0 / ((unsigned)l0 | 1u)) & 7u] = ((unsigned)(0x846a8ec5u == (a0[u1 & 3u] % (garr[i1 & 7u] | 1u))) * 1u);
    }
    s1 = (int)((unsigned)s1 + ((unsigned)(w0 >> 29) - v0));
    u3 = u3 * 0x9e3779b1u + ((0x80000000u ^ (unsigned)f0) ^ (unsigned)e0);
    goto done;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)(signed char)((p0 | (unsigned)s0) % ((unsigned)(w0 >> 29) | 1u)) & 7u) {
            L1: if (--fuel == 0u) goto done;
            if (m0) {
                b0 = ((unsigned)l0 * 0x63db5b7cu) != 0u;
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(signed char)(unsigned)((unsigned)w0 || -(r0.y | (unsigned)c0)), ((unsigned)c1 >> ((unsigned)b0 & 31u)), 0x10000u); }
                if (0x3d78c2d8u) break;
                u3 = (garr[u2 & 7u] * (a0[u1 & 3u] ^ (unsigned)e0));
                s1 = (int)((unsigned)s1 + (((unsigned)c0 * i1) - ((unsigned)h0 ^ 0x80000000u)));
            }
            i0 = ((u3 >> (0x77525386u & 31u)) | (6u / (r0.x | 1u))) & 15u;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)(m0 & u3) > (signed char)garr[i1 & 7u]), 8u, *q0); }
            if (0xffffffffu) break;
            if (fuel < 8u) return (0xffffffffu ? garr[u2 & 7u] : (unsigned)((unsigned)e0 < (unsigned)b0));
        }
        s0 = (int)*mp;
        if ((0u % (garr[i1 & 7u] | 1u))) break;
        a0[0xdb21e164u & 3u] = (a0[i0 & 3u] / ((unsigned)(unsigned char)(unsigned)((int)(unsigned)x0 < (int)i2) | 1u));
        while (i1++ < 5u && ((unsigned)(fuel < (unsigned)h1) ^ (unsigned)s1)) { if (--fuel == 0u) goto done;
            switch (((unsigned)(x0 >> 70) - *mp) & 7u) {
                while (((unsigned)d0 | i0)) { if (--fuel == 0u) goto done;
                    if (((unsigned)e0 | a0[i0 & 3u])) goto L2;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((unsigned)c1 && r0.x) % (m0 | 1u)), ~((unsigned)c1 | m0), (0xa9a604e0u | *mp)); }
                    c0 = (unsigned char)((unsigned)(r0.y && (unsigned)(w0 >> 29)) << (((p1 + u3) * p2) & 31u));
                    f0 = f0 * 0.5f + (float)(3u & 255u);
                    L2: if (--fuel == 0u) goto done;
                }
                L3: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)(u1 << ((unsigned)h0 & 31u)) < (int)(unsigned)c1), (u2 | (unsigned)c1), u0); }
                L4: if (--fuel == 0u) goto done;
                if ((unsigned)(a0[u1 & 3u] && (unsigned)x0)) continue;
            }
        }
        m0 ^= (unsigned)(signed char)(unsigned)(0x7fffffffu && (unsigned)(w0 >> 29));
    }
    if ((p1 ^ i0)) goto L4;
    a0[*q0 & 3u] = (unsigned)((int)((garr[i1 & 7u] - m0) | (unsigned)f0) < (int)(unsigned)(0x9399f5a3u < 0x2403796cu));
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (unsigned)((int)(unsigned)h1 >= (int)p1);
        if ((m0 - a0[u1 & 3u])) break;
        break; (void)((garr[u2 & 7u] >> (r0.x & 31u)));
        a0[7u & 3u] = (unsigned)s1;
    }
    goto L4;
    while (i0++ < 2u && ((unsigned)f0 | 0u)) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)(0x7a21749du < fuel))) {
                if ((unsigned)(short)((unsigned)(fuel < 9u) | 0x7fffffffu)) break;
                if ((u3 - 0xffffffffu)) break;
                if (((0x10000u - p1) - 0x80000000u)) continue;
                *q0 += 0x7fffffffu;
                if (a0[i0 & 3u]) break;
                q0 = &garr[(unsigned)(w0 >> 29) & 7u];
            }
            if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((int)-(v0 + p0) < (int)p2), (unsigned)(signed char)(unsigned)(0xcfbd95f3u && (unsigned)c1), (unsigned)(0x3752a64au < (unsigned)((int)*mp < (int)g0))); }
            if ((0xe0a8564du ^ (unsigned)b0)) {
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)!((unsigned)s1 / (0x23de216au | 1u));
                    u3 = (unsigned)(unsigned char)(unsigned)((short)4u > (signed char)((unsigned)((int)(unsigned)c0 < (int)5u) ^ fuel));
                    u1 ^= (0x80000000u * (unsigned)(short)(unsigned)(fuel < g0));
                }
                continue; (void)((unsigned)((6u * 0xffffffffu) && u0));
            }
            continue; (void)(a0[i0 & 3u]);
        }
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((short)(unsigned)w0 > (signed char)(unsigned)c0));
            u1 += (unsigned)((unsigned)(m0 < (unsigned)d0) && u0);
            for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(unsigned char)((i1 % (0x7fffffffu | 1u)) + v0), (unsigned)((int)(unsigned)h0 >= (int)((unsigned)c1 - (unsigned)h0)), (r0.x & (unsigned)(w0 >> 29))); }
                if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)(0xffffffffu == 0x80000000u), i1, ((unsigned)e0 - (u0 / (garr[u2 & 7u] | 1u)))); }
                if (budget != 0u) { budget -= 1u; u1 = fn2(0u, (0x80000000u / ((v0 << (*q0 & 31u)) | 1u)), (unsigned)h0); }
                continue; (void)((v0 ^ 0u));
                h0 = (short)((garr[i1 & 7u] * (unsigned)f0) ^ (0x7fffffffu + p0));
                w0 ^= (unsigned long long)(unsigned)(x0 >> 70) << ((p1 & p0) & 63u);
            }
        }
        if (v0) break;
        *mp = (unsigned)(m0 && i2);
        if (p1) {
            continue; (void)((fuel * 9u));
            if ((unsigned)((short)(unsigned)s1 > (signed char)(u2 << (0x570ad445u & 31u)))) continue;
            l0 = (long)((unsigned long)l0 + (unsigned)((short)(unsigned)s0 > (signed char)*q0));
        } else {
            switch (3u & 7u) {
                v0 = p1;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(w0 >> 29), 2u, (unsigned)!((unsigned)h0 >> ((a0[i0 & 3u] ^ 0xaf090749u) & 31u))); }
                u1 = u1 * 0x9e3779b1u + ((unsigned)(9u == (r0.y + garr[i1 & 7u])) + (unsigned)((int)5u < (int)u1));
                m0 ^= (((unsigned)(unsigned char)(unsigned)((int)9u >= (int)(unsigned)x0) - g1) / (0x80000000u | 1u));
            }
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)((unsigned)(signed char)(0x13193f40u - v0) == (i2 >> ((unsigned)e0 & 31u)));
            }
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)c0) break;
                s0 = (int)((g1 - -(i0 << ((unsigned)e0 & 31u))) ^ (unsigned)s1);
            }
            g1 += (unsigned)((short)(unsigned)h1 > (signed char)(p2 >> ((*q0 - ((unsigned)h0 >> (0xefa7ac00u & 31u))) & 31u)));
        }
    }
    if (fuel < 8u) return (unsigned)h1;
    goto L1;
    f0 = f0 * 0.5f + (float)((unsigned)c0 & 255u);
    while (i0++ < 2u && ((unsigned)c1 >> ((unsigned)d0 & 31u))) { if (--fuel == 0u) goto done;
        g1 += (unsigned)((int)(p2 / (7u | 1u)) < (int)p2);
        s0 = (int)(0x99062fa6u << ((unsigned)(w0 >> 29) & 31u));
        m0 ^= 0x473b5516u;
        if (a0[i0 & 3u]) break;
    }
    goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 7u, 0xbe487df5u, 0xd3f2bf43u },
        { 12u, 0xd04dead0u, 0x6b807b89u },
        { 4u, 0x2eab5572u, 0x3ebdf714u },
        { 9u, 0xc0f8884du, 0xce584b8bu },
        { 6u, 0xbecf992u, 0x8b2fc021u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
