// test-ssa-source's program of seed 141000425 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x50c59bc5u, g1 = 0x486189bau;
static unsigned garr[8] = { 0xdd002b8cu, 0x6bfc7449u, 0x2334fb2bu, 0x465e103du, 0xf4561cb6u, 0x3f51383u, 0xb8b4e088u, 0x81bba871u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(unsigned)((u0 * (unsigned)f0) && (0x761b22f5u / (-(i0 % ((unsigned)b0 | 1u)) | 1u)));
    c1 = (signed char)i1;
    if ((unsigned)((int)(0u / (r0.x | 1u)) < (int)(unsigned)c0)) {
        L0: if (--fuel == 0u) goto done;
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 += ((unsigned)((unsigned)(unsigned char)(0xb4524d22u ? (unsigned)h0 : (unsigned)c0) && 0x3d7a3992u) - 2u);
            u1 += (unsigned)(garr[u2 & 7u] && ((unsigned)c0 & 0x920c0db4u));
            L1: if (--fuel == 0u) goto done;
            L2: if (--fuel == 0u) goto done;
            if (((u3 >> (0x89d82d6cu & 31u)) - 9u)) {
                L3: if (--fuel == 0u) goto done;
                m0 ^= (unsigned)h0;
                w0 ^= (unsigned long long)2u << (-(r0.y * (u0 * fuel)) & 63u);
            }
        }
        { unsigned t0; double z0; if ((u0) & 1u) { t0 = 0xffffffffu; z0 = (double)(((unsigned)(unsigned char)((unsigned)c1 << ((unsigned)w0 & 31u))) & 255u); } if ((u0) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            u2 += *q0;
        }
    }
    L4: if (--fuel == 0u) goto done;
    goto L4;
    u3 = (unsigned)(g0 && (unsigned)((int)((unsigned)d0 << (5u & 31u)) >= (int)(unsigned)c1));
    g1 += (unsigned)(0x7fffffffu || -(2u | 0x7a508bb5u));
    g0 = (unsigned)((short)~(*mp + (unsigned)s0) > (signed char)(unsigned)((i1 << (garr[u2 & 7u] & 31u)) < u2));
    m0 ^= (2u / (5u | 1u));
    u3 = u3 * 0x9e3779b1u + (unsigned)((int)(unsigned)(2u || garr[i1 & 7u]) >= (int)a0[u1 & 3u]);
    for (;;) { if (--fuel == 0u) goto done;
        g0 = (((unsigned)(a0[i0 & 3u] == (unsigned)(x0 >> 70)) - (unsigned)((int)g1 < (int)0x80000000u)) ^ 8u);
        if ((g1 - p2)) continue;
        d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)l0 >= (int)(unsigned)!((u2 ^ (i2 / (i0 | 1u))) - u3)) & 1023u);
        garr[(unsigned)((short)a0[u1 & 3u] > (signed char)p1) & 7u] = ((unsigned)w0 & p0);
        i0 = (r0.y ? (unsigned)h0 : g0) & 15u;
    }
    if (*mp) goto L3;
    h1 = (unsigned short)(h1 + ((unsigned)s0 & 0x7fffffffu));
    goto done;
    w0 ^= (unsigned long long)i2 << (((m0 ^ u1) >> ((unsigned)b0 & 31u)) & 63u);
    s0 = (int)-(unsigned)(0xffffffffu || m0);
    if ((unsigned)((int)(unsigned)s0 >= (int)*q0)) goto L1;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (-(unsigned)(r0.y || (i0 >> (0xffffffffu & 31u)))) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)(0x80000000u || ((unsigned)(signed char)(unsigned)(*mp < u2) / ((unsigned)(w0 >> 29) | 1u)));
            u2 = (0x5ba38a07u | (unsigned)e0);
            *q0 = (a0[u1 & 3u] * (r0.x >> (i2 & 31u)));
            h0 = (short)(unsigned)(signed char)((unsigned)l0 + (((unsigned)(x0 >> 70) & p1) * (unsigned)(x0 >> 70)));
            w0 ^= (unsigned long long)(r0.y % (p0 | 1u)) << ((8u / ((0x10000u + a0[u1 & 3u]) | 1u)) & 63u);
        }
    }
    a0[(0xffffffffu % ((unsigned)l0 | 1u)) & 3u] = (unsigned)(short)(unsigned)((unsigned)((int)u3 >= (int)0x5e3089beu) || m0);
    l0 = (long)((unsigned long)l0 + (unsigned)(short)(unsigned)((int)(unsigned)((unsigned)f0 == g0) < (int)(0x80000000u | fuel)));
    if (-(r0.y >> ((unsigned)c1 & 31u))) goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)((int)(unsigned)b0 >= (int)(2u >> (0xbb627a8bu & 31u)))) goto L2;
    u0 = ((unsigned)((int)i1 >= (int)i2) - i1);
    { unsigned t0; double z0; if (((unsigned)(*q0 || (p1 ^ 8u))) & 1u) { t0 = g1; z0 = (double)((((unsigned)(u2 < (unsigned)e0) + 0x10000u)) & 255u); } if (((unsigned)(*q0 || (p1 ^ 8u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        x0 = x0 * 0x100000001b3ull + (p1 ^ (unsigned)f0);
        b0 = (unsigned)(0x7fffffffu == 3u) != 0u;
    }
    goto L4;
    if ((unsigned)h1) {
        v0 = (unsigned)(unsigned char)(unsigned)(0x10000u && 0xffffffffu);
        L0: if (--fuel == 0u) goto done;
        if (((unsigned)h0 - (unsigned)((int)m0 < (int)i1))) {
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s1, (unsigned)((unsigned)s0 < (unsigned)((short)(unsigned)s0 > (signed char)(unsigned)l0)), (1u >> ((unsigned)(signed char)(unsigned)((short)2u > (signed char)u0) & 31u))); }
            i2 = ((unsigned)(w0 >> 29) / ((0xd201951fu ? (0x44b6741fu << (a0[i0 & 3u] & 31u)) : (unsigned)e0) | 1u)) & 15u;
            if (0u) {
                a0[(unsigned)d0 & 3u] = (i2 ? (1u ? u0 : 1u) : 0x1156aa40u);
                do { if (--fuel == 0u) goto done;
                    u0 += (((unsigned)f0 ^ a0[i0 & 3u]) ^ (unsigned)c1);
                    c0 = (unsigned char)0x10000u;
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(((unsigned)w0 + 2u) | fuel) < (int)(0x10000u - p2));
                    i0 = (unsigned)((*q0 ^ u1) < (unsigned)c1) & 15u;
                } while (i0++ < 5u && ((unsigned)(x0 >> 70) * r0.y));
                garr[3u & 7u] = (unsigned)((int)(unsigned)e0 >= (int)garr[i1 & 7u]);
                h0 = (short)(0xd6b4174u % ((unsigned)((int)0x80000000u < (int)(unsigned)(0x7fffffffu == 0xff877e5du)) | 1u));
                if ((unsigned)((short)v0 > (signed char)(unsigned)c1)) goto L1;
            }
            if ((unsigned)((unsigned)(x0 >> 70) || ~(0xe41b29edu << (0x7fffffffu & 31u)))) {
                v0 = garr[u2 & 7u];
                *mp = (unsigned)(signed char)((unsigned)w0 ^ (unsigned)h0);
                if (i2) goto L1;
                u0 += (unsigned)((int)0x10000u < (int)9u);
            } else {
                if ((unsigned)((int)(unsigned)w0 >= (int)r0.x)) goto L4;
                if (fuel < 8u) return (unsigned)(unsigned char)((6u + (unsigned)s0) << (0x100cddfu & 31u));
            }
            L1: if (--fuel == 0u) goto done;
        } else {
            x0 = x0 * 0x100000001b3ull + r0.x;
            m0 ^= m0;
            goto L4;
            if ((unsigned)(fuel || 0x7fffffffu)) goto L2;
        }
    }
    if (u1) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            r0.x = (unsigned)(x0 >> 70);
            m0 ^= ((unsigned)e0 % ((unsigned)(short)(*q0 ^ (unsigned)((unsigned)(x0 >> 70) < g0)) | 1u));
        }
        if ((0x80000000u ^ (unsigned)h1)) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0((((unsigned)x0 * (unsigned)l0) ^ garr[u2 & 7u]), 7u, (0x6e850eefu & ((unsigned)(x0 >> 70) >> (u0 & 31u)))); }
        goto L1;
    } else {
        s1 = (int)((unsigned)s1 + ((unsigned)((int)i2 >= (int)(g0 | m0)) | u3));
        if (budget != 0u) { budget -= 1u; u3 = fn0(*q0, garr[u2 & 7u], (unsigned)((unsigned)h1 == (unsigned)e0)); }
    }
    { unsigned t1; double z1; if ((((unsigned)s1 ^ 0x84331ca8u)) & 1u) { t1 = (fuel | 0x319a3baau); z1 = (double)((0x9615f9cdu) & 255u); } if ((((unsigned)s1 ^ 0x84331ca8u)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        { unsigned t2; double z2; if ((0x80000000u) & 1u) { t2 = (unsigned)((short)(unsigned)b0 > (signed char)p0); z2 = (double)((r0.x) & 255u); } if ((0x80000000u) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            if (0xffffffffu) goto L3;
            b0 = v0 != 0u;
            if ((unsigned)((short)((unsigned)c1 | (unsigned)h0) > (signed char)(unsigned)c1)) goto L1;
            *q0 = (u3 + (0x10000u >> (v0 & 31u)));
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            i2 = (0x83b7dcb2u / (0x10000u | 1u)) & 15u;
            if (budget != 0u) { budget -= 1u; u3 = fn0((fuel / ((unsigned)h1 | 1u)), (unsigned)((int)(u0 >> (*mp & 31u)) < (int)(unsigned)d0), i1); }
        }
        switch ((unsigned)h0 & 7u) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(u1 < (unsigned)((int)garr[i1 & 7u] < (int)0xffffffffu)), (unsigned)((short)(unsigned)((short)v0 > (signed char)p2) > (signed char)*q0), (unsigned)((short)v0 > (signed char)(0x10000u >> (0x1caa30d3u & 31u)))); }
            g0 = 0x34e099d6u;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(p1, (0x676e15e4u + i0), ((garr[i1 & 7u] / (p1 | 1u)) - (unsigned)l0)); }
        x0 = x0 * 0x100000001b3ull + (0x1d91669bu + ((unsigned)(0x1b75e6bcu && (unsigned)s1) << (i0 & 31u)));
    }
    while ((unsigned)(i0 < p2)) { if (--fuel == 0u) goto done;
        m0 ^= (unsigned)(unsigned char)(unsigned)(0x7fffffffu || (unsigned)s1);
        switch ((~(unsigned)((short)(unsigned)w0 > (signed char)v0) >> (p2 & 31u)) & 7u) {
            switch (((unsigned)s0 / (a0[i0 & 3u] | 1u)) & 7u) {
                q0 = &garr[p2 & 7u];
                q0 = &garr[(0x7fffffffu ? ((unsigned)l0 >> (0x7fffffffu & 31u)) : (unsigned)x0) & 7u];
                d0 = d0 * 0.5 + (double)((g0 ? p2 : ((unsigned)(0x50a4abcau < (unsigned)f0) & p2)) & 1023u);
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)((int)0x33cd2d28u < (int)(unsigned)h0) == (unsigned)f0), (unsigned)(3u && (unsigned)e0), (p2 + (unsigned)x0)); }
                v0 = (g0 % ((i1 * m0) | 1u));
            }
            switch ((unsigned)c0 & 7u) {
                u1 ^= (unsigned)((unsigned)l0 || (0x156157e3u ^ (unsigned)e0));
                c1 = (signed char)((0xce171778u ? garr[i1 & 7u] : (unsigned)c1) / ((unsigned)(w0 >> 29) | 1u));
                garr[(0x10000u >> (0x80000000u & 31u)) & 7u] = (unsigned)((unsigned)(x0 >> 70) == ((unsigned)x0 ? ((unsigned)x0 % ((unsigned)l0 | 1u)) : i1));
            }
            { unsigned t3; double z3; if (((unsigned)((short)(g1 >> (i2 & 31u)) > (signed char)0x80000000u)) & 1u) { t3 = (unsigned)f0; z3 = (double)(((-(unsigned)(r0.y || m0) >> (0x10000u & 31u))) & 255u); } if (((unsigned)((short)(g1 >> (i2 & 31u)) > (signed char)0x80000000u)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                case 5u: ;
                *mp = i0;
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 2u: ;
                    L2: if (--fuel == 0u) goto done;
                }
                goto done;
                u3 += (unsigned)w0;
                while (i1++ < 6u && i2) { if (--fuel == 0u) goto done;
                    if ((unsigned)(unsigned char)(unsigned)(v0 < (unsigned)(x0 >> 70))) break;
                    garr[(unsigned)(p2 < (unsigned)s0) & 7u] = fuel;
                    case 0u: ;
                    x0 = x0 * 0x100000001b3ull + 5u;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(p0 && 0x10000u), (unsigned)(r0.y < 0xffffffffu), i0); }
                }
            }
            *q0 = g0;
            c1 = (signed char)(unsigned)(p1 == (unsigned)(a0[i0 & 3u] && (unsigned)((int)(unsigned)e0 < (int)(unsigned)x0)));
            g1 += (unsigned)(unsigned char)((0xcf4cb272u ^ (unsigned)((int)u0 < (int)0x38341865u)) / (a0[u1 & 3u] | 1u));
        }
        h0 = (short)(unsigned)((v0 ^ 0xf49f0af3u) < (unsigned)x0);
        m0 ^= u2;
        switch ((unsigned)(short)(unsigned)(i2 || 0x80000000u) & 7u) {
            i2 = (unsigned)((unsigned)c0 && ((unsigned)l0 / (0x80000000u | 1u))) & 15u;
            if (u3 == 7u) return (0x6d498c1au - (unsigned)h1);
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)s1, (unsigned)(w0 >> 29), (unsigned)(signed char)(0x80000000u & (p2 + *q0))); }
    }
    b0 = (unsigned)((short)(unsigned)l0 > (signed char)0x7fffffffu) != 0u;
    if (g0) {
        u2 = u2 * 0x9e3779b1u + ((unsigned)((short)*mp > (signed char)0x1734c56fu) + ((unsigned)h1 >> (r0.x & 31u)));
        *mp = (unsigned)d0;
        if ((0x1b40ab23u / (i2 | 1u))) goto L3;
    } else {
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)(garr[i1 & 7u] && 0xd793d3a2u) < (int)(unsigned)x0), u1, (unsigned)(2u == (unsigned)(w0 >> 29))); }
        s0 = (int)(0x80000000u - -((unsigned)h1 + (unsigned)(*mp == fuel)));
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((8u - -((unsigned)c0 << (0u & 31u)))) continue;
            if (i2) break;
        }
        q0 = &garr[(v0 | i2) & 7u];
    }
    do { if (--fuel == 0u) goto done;
        garr[(unsigned)!(i1 % ((unsigned)d0 | 1u)) & 7u] = (g1 >> ((unsigned)(w0 >> 29) & 31u));
        u3 = u3 * 0x9e3779b1u + ((unsigned)h1 ? (unsigned)e0 : ((unsigned)d0 / (r0.x | 1u)));
        garr[(unsigned)(x0 >> 70) & 7u] = -((unsigned)((unsigned)f0 || (unsigned)s0) - (unsigned)(0x14a27092u || fuel));
        if (r0.y) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)g1 >= (int)((unsigned)w0 / (0xd208b4c3u | 1u))), p0, (unsigned)c1); }
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                v0 = (unsigned)(i1 && *mp);
                if ((unsigned)((unsigned)w0 < 5u)) {
                    r0.y ^= r0.x;
                    a0[(g0 & garr[i1 & 7u]) & 3u] = ~(((unsigned)x0 ? i0 : 4u) - m0);
                } else {
                    b0 = ((unsigned)((0x10000u | (r0.y / (0xb0487404u | 1u))) == u2) * 7u) != 0u;
                    a0[(unsigned)((short)0x80000000u > (signed char)8u) & 3u] = ((g0 - garr[i1 & 7u]) % ((unsigned)((int)*q0 >= (int)(unsigned)((int)0x5eb4d1bbu >= (int)(unsigned)f0)) | 1u));
                    if (4u) break;
                    break; (void)((unsigned)w0);
                }
                if (0u) continue;
                if (budget != 0u) { budget -= 1u; u1 = fn0((*mp << (0xffffffffu & 31u)), 0x80000000u, (unsigned)((unsigned)c0 == (v0 / (u0 | 1u)))); }
            }
            if ((unsigned)((short)(unsigned)!(unsigned)((unsigned)(w0 >> 29) || (unsigned)h1) > (signed char)(unsigned)h1)) {
                L3: if (--fuel == 0u) goto done;
                *q0 = ~((unsigned)h1 % ((unsigned)b0 | 1u));
                switch ((7u << (p1 & 31u)) & 7u) {
                    if ((unsigned)(g1 < 5u)) goto L0;
                }
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    L4: if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(i1 < ((unsigned)h0 >> (3u & 31u))), (g0 | r0.y), (m0 % ((unsigned)c0 | 1u))); }
                    c0 = (unsigned char)(p2 ^ ~(((unsigned)(w0 >> 29) + p1) + u1));
                }
            }
            if (fuel < 8u) return ((0x7c8c620cu * g1) ^ ~(unsigned)(p0 && (unsigned)(4u == a0[i0 & 3u])));
            { unsigned t4; double z4; if (((3u >> ((6u + a0[i0 & 3u]) & 31u))) & 1u) { t4 = (fuel * (unsigned)((int)r0.y >= (int)0x7fbceeau)); z4 = (double)((0x38bf1423u) & 255u); } if (((3u >> ((6u + a0[i0 & 3u]) & 31u))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                if ((0x9852c24du << ((0x80000000u >> ((unsigned)x0 & 31u)) & 31u))) goto L4;
                f0 = f0 * 0.5f + (float)(0x10000u & 255u);
            }
            break; (void)((unsigned)((i0 | *q0) || p2));
        } else {
            *q0 += (p0 % (0x5eb8ce34u | 1u));
            while (i1++ < 7u && 0x10000u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(garr[u2 & 7u], (unsigned)((int)(unsigned)((unsigned)(w0 >> 29) == (unsigned)(x0 >> 70)) >= (int)(unsigned)f0), (u0 >> (7u & 31u))); }
            }
            if (0xafceb0ebu) break;
        }
    } while (i0++ < 2u && a0[u1 & 3u]);
    goto done;
    if ((unsigned)c1) goto done;
    goto L3;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)c1, (unsigned)h1, ((unsigned)((int)i2 < (int)r0.y) % (0x10000u | 1u))); }
    if ((unsigned)((short)(unsigned)x0 > (signed char)0x10000u)) goto L0;
    q0 = &garr[8u & 7u];
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)(0u || m0) & 7u) {
            h1 = (unsigned short)(h1 + (0x370c6009u % ((9u / (i1 | 1u)) | 1u)));
            break; (void)(((unsigned)f0 << ((unsigned)c0 & 31u)));
            if (p0) break;
        }
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + p0);
            v0 = (((unsigned)s0 ? (unsigned)h1 : 0x3f35e3fau) & (unsigned)((int)u0 >= (int)a0[i0 & 3u]));
        }
        garr[r0.x & 7u] = (5u - i0);
        g0 = (unsigned)(w0 >> 29);
    }
    *q0 = (0x9795802u / (9u | 1u));
    switch (0x2cd5f641u & 7u) {
        if ((unsigned)(unsigned char)(unsigned)(0x5b5e32cdu == g0)) {
            g1 += ((unsigned)(u1 < (unsigned)((int)2u >= (int)(unsigned)c0)) % (g1 | 1u));
            b0 = (4u / (v0 | 1u)) != 0u;
            if ((unsigned)h0) goto L4;
            break; (void)((*q0 & (unsigned)(signed char)(unsigned)((unsigned)b0 < 0xcc0c5a30u)));
            g1 += ((unsigned)h0 + (((unsigned)(w0 >> 29) - p0) | m0));
        }
        w0 = w0 * 6364136223846793005ull + (p2 - p1);
        switch (v0 & 7u) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((p0 << (0xfb0dbb11u & 31u)), -(a0[i0 & 3u] - ((unsigned)x0 * 0xa6e36383u)), (unsigned)(-((unsigned)l0 & 0xffffffffu) == g1)); }
            q0 = &garr[(unsigned)(short)(0x7fffffffu >> ((unsigned)(5u || a0[u1 & 3u]) & 31u)) & 7u];
            switch (a0[i0 & 3u] & 7u) {
                m0 ^= r0.y;
                s1 = (int)((unsigned)s1 + ((unsigned)((short)((unsigned)((short)u1 > (signed char)0xd507e16eu) & i2) > (signed char)(unsigned)f0) / (u3 | 1u)));
                g1 += ((unsigned)d0 + (unsigned)((unsigned)c1 == (unsigned)f0));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)d0, u2, (unsigned)h0); }
            if (u1) goto L4;
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((unsigned)x0 >> (((unsigned)w0 / ((unsigned)(w0 >> 29) | 1u)) & 31u));
            h0 = (short)(unsigned)(signed char)(unsigned)(a0[u1 & 3u] && u2);
        }
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)0x6481a7u >= (int)0x80000000u), (g0 / ((unsigned)b0 | 1u)), ((unsigned)((int)7u < (int)6u) - u1)); }
        if ((unsigned)f0) {
            c0 = (unsigned char)(u1 & (unsigned)(u3 || (unsigned)h1));
            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)l0 ^ (v0 | v0)), (1u | garr[i1 & 7u]), (unsigned)(unsigned char)(unsigned)(0u < ((unsigned)h1 / (0x7031bb8au | 1u)))); }
        }
        u2 ^= (unsigned)(0x80000000u || (unsigned)d0);
    }
    { unsigned t5; double z5; if (((unsigned)d0) & 1u) { t5 = (unsigned)d0; z5 = (double)((0x7fffffffu) & 255u); } if (((unsigned)d0) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
        if ((0xffffffffu * (unsigned)h1)) goto L1;
        { unsigned t6; double z6; if (((unsigned)(*q0 == a0[i0 & 3u])) & 1u) { t6 = ((unsigned)b0 % ((unsigned)d0 | 1u)); z6 = (double)(((unsigned)(unsigned char)((unsigned)(x0 >> 70) + 8u)) & 255u); } if (((unsigned)(*q0 == a0[i0 & 3u])) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
            r0.x = (unsigned)((fuel >> (6u & 31u)) == p0);
            if (g1) goto done;
            if ((unsigned)!((unsigned)x0 + (unsigned)(garr[i1 & 7u] == 0xcb47fdb3u))) goto L0;
        }
        if ((unsigned)((i0 >> (i0 & 31u)) || 0xc8cba4dfu)) goto L1;
        if (~((unsigned)e0 % (9u | 1u))) goto L0;
        garr[(0x7ccad0aau ^ 5u) & 7u] = ((unsigned)(w0 >> 29) << ((unsigned)(x0 >> 70) & 31u));
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)h0 || 3u)) break;
        if (i2) continue;
        goto L0;
    }
    do { if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)w0;
        if (0x7fffffffu) break;
    } while (i0++ < 2u && garr[u2 & 7u]);
    while ((~(3u % (g0 | 1u)) >> ((unsigned)f0 & 31u))) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((u3 & r0.y), 0xc3eeafbdu, (fuel / (u3 | 1u))); }
        if (((unsigned)l0 ? 0xac96b18au : (unsigned)c0)) break;
        u0 = (unsigned)!(unsigned)((int)((unsigned)x0 | (unsigned)(r0.x == (a0[u1 & 3u] ^ u1))) < (int)9u);
        switch (((0xffffffffu >> ((unsigned)(w0 >> 29) & 31u)) % (0xf40a515bu | 1u)) & 7u) {
            if ((unsigned)b0) break;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)(0x7fffffffu && i2) < (int)(unsigned)h1), (u0 ? 0x80000000u : (unsigned)e0), ((unsigned)h0 >> (i0 & 31u))); }
            u1 = u1 * 0x9e3779b1u + (i0 ^ v0);
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch (((unsigned)s0 - 0x910128abu) & 7u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)u1 < (int)g0), ((unsigned)((short)*q0 > (signed char)p2) + garr[u2 & 7u]), 0xd982771eu); }
                }
                if (fuel) goto L2;
                u2 += (9u | (unsigned)(*q0 || (unsigned)l0));
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)(garr[u2 & 7u] && 0xce72d31eu) && 0xffffffffu), ((unsigned)(i0 < u0) << (v0 & 31u)), g1); }
                    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        u0 ^= (unsigned)((-(unsigned)(fuel || g1) / (i1 | 1u)) && fuel);
                    }
                } while (i2++ < 5u && (unsigned)(((unsigned)s1 % (g0 | 1u)) || a0[i0 & 3u]));
                x0 = x0 * 0x100000001b3ull + -((unsigned)c0 ? (unsigned)e0 : (v0 ^ 0xc7d6ef1fu));
                r0.y ^= ((r0.y - (*mp ^ (unsigned)((short)0x7fffffffu > (signed char)0xffffffffu))) / (7u | 1u));
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(a0[u1 & 3u] || 0x9ced460fu), (*q0 << ((unsigned)((short)p0 > (signed char)*q0) & 31u)), (unsigned)((short)3u > (signed char)(unsigned)((int)9u >= (int)u1))); }
    m0 ^= (unsigned)d0;
    goto L0;
    goto L3;
    while (i0++ < 6u && u1) { if (--fuel == 0u) goto done;
        h0 = (short)(0x50ae88b0u ^ (unsigned)s0);
        u2 += (unsigned)s1;
        break; (void)((unsigned)(a0[i0 & 3u] < u0));
    }
    u1 += m0;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)fuel;
        continue; (void)((r0.x ^ (unsigned)c1));
        if (budget != 0u) { budget -= 1u; u1 = fn0(a0[u1 & 3u], (unsigned)(0x6d697ed3u == (unsigned)c1), (unsigned)f0); }
        if (v0) break;
        c1 = (signed char)(unsigned)(unsigned char)(unsigned)((int)fuel >= (int)p1);
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)c0 && r0.y), (unsigned)((int)(unsigned)s1 >= (int)(unsigned)(u2 < 0x7fffffffu)), (g1 & (r0.y - p2))); }
    { unsigned t7; double z7; if (((0x78bd66fu ? 0xffffffffu : (unsigned)h1)) & 1u) { t7 = r0.x; z7 = (double)(((unsigned)((short)(unsigned)w0 > (signed char)u2)) & 255u); } if (((0x78bd66fu ? 0xffffffffu : (unsigned)h1)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(8u && (unsigned)((unsigned)f0 && 0x10000u)), (unsigned)((unsigned)((unsigned)s0 < (unsigned)e0) && (unsigned)w0), a0[u1 & 3u]); }
            c1 = (signed char)((0x10000u ^ 0x8a06131u) >> (0x9fadeaa8u & 31u));
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)(u1 && (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)e0))) break;
                } while (i2++ < 5u && v0);
            }
        }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                h0 = (short)u2;
                *mp = (p0 | g0);
                w0 = w0 * 6364136223846793005ull + (unsigned)(p0 == (unsigned)((int)i0 < (int)(unsigned)(fuel < (unsigned)h0)));
            } while (i1++ < 5u && (r0.x / (((unsigned)b0 / ((unsigned)w0 | 1u)) | 1u)));
            v0 = (unsigned)((int)(7u ^ 0xdef238eau) < (int)(unsigned)((int)(u2 / ((unsigned)c1 | 1u)) >= (int)u0));
            if (budget != 0u) { budget -= 1u; u1 = fn0((a0[i0 & 3u] % (i0 | 1u)), u3, (0xe4d42efbu - 0x80000000u)); }
            if (budget != 0u) { budget -= 1u; u1 = fn0(0xd3f99c75u, v0, ((unsigned)(x0 >> 70) - (unsigned)w0)); }
            c1 = (signed char)(unsigned)((short)r0.y > (signed char)garr[i1 & 7u]);
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)b0 * (unsigned)h1), ((7u * u3) % (p2 | 1u)), (unsigned)(short)(g0 ? p1 : 8u)); }
        }
        v0 = (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(p1 * (unsigned)((short)0x10000u > (signed char)0x4b8a3c15u)));
    }
    q0 = &garr[((unsigned)(w0 >> 29) | garr[i1 & 7u]) & 7u];
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while (i0++ < 6u && ((0x82627f26u | p2) << (0x80000000u & 31u))) { if (--fuel == 0u) goto done;
        v0 = 0xffffffffu;
        q0 = &garr[(u3 << ((u1 & u2) & 31u)) & 7u];
        if (v0) break;
        if ((u1 % (g1 | 1u))) continue;
        r0.y ^= (unsigned)((unsigned)((int)(unsigned)((int)i1 >= (int)0x7fffffffu) >= (int)(unsigned)((short)0x814b7203u > (signed char)9u)) == g0);
    }
    switch (i0 & 7u) {
        if ((7u >> (g1 & 31u))) {
            switch ((0x2bfe89b3u & (unsigned)s0) & 7u) {
                case 6u: ;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)f0 < *mp), (0x3ca8cdb4u % ((unsigned)l0 | 1u)), (unsigned)!(0x78a6ebbfu >> ((u1 << (8u & 31u)) & 31u))); }
                L0: if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
            }
        }
        if (u1) goto L2;
    }
    f0 = f0 * 0.5f + (float)(-(unsigned)((*q0 & (unsigned)l0) && (unsigned)(6u || *mp)) & 255u);
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(short)(unsigned)((int)r0.y < (int)(unsigned)b0)) break;
        *q0 = i1;
        if ((0x10000u & (0x80000000u % (i1 | 1u)))) {
            { unsigned t0; double z0; if (((unsigned)((unsigned)b0 && (unsigned)((short)*mp > (signed char)(unsigned)s1))) & 1u) { t0 = (unsigned)(signed char)(0x80000000u >> (2u & 31u)); z0 = (double)(((i2 ^ 0x7fffffffu)) & 255u); } if (((unsigned)((unsigned)b0 && (unsigned)((short)*mp > (signed char)(unsigned)s1))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)e0 - (0x69307861u & 2u)), (unsigned)(a0[u1 & 3u] == (0x7fffffffu / ((unsigned)c0 | 1u))), (u2 * (unsigned)h1)); }
                switch ((g1 ^ (unsigned)(*mp == 0x7fffffffu)) & 7u) {
                    if ((unsigned)(signed char)((unsigned)(unsigned char)(p1 & u2) % (0xffffffffu | 1u))) break;
                    w0 ^= (unsigned long long)(g0 / (0x10000u | 1u)) << (((u2 << ((unsigned)w0 & 31u)) + (0x3443da10u * 0x7fffffffu)) & 63u);
                    if (-(unsigned)((int)(unsigned)d0 >= (int)(unsigned)(w0 >> 29))) break;
                    L2: if (--fuel == 0u) goto done;
                    case 1u: ;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)(w0 >> 29) >= (int)((unsigned)f0 | 2u)), (unsigned)((int)0xb306d768u < (int)(unsigned)((unsigned)s1 && (unsigned)e0)), *mp); }
                L3: if (--fuel == 0u) goto done;
            }
            if ((unsigned)(u2 && (8u - (unsigned)s1))) {
                { unsigned t1; double z1; if ((-((unsigned)!(u1 / (0x10000u | 1u)) | a0[u1 & 3u])) & 1u) { t1 = (unsigned)(0x80000000u || (0xfeadc0bau + a0[u1 & 3u])); z1 = (double)(((unsigned)((int)0x7fffffffu >= (int)(*q0 & 0x8240e6e2u))) & 255u); } if ((-((unsigned)!(u1 / (0x10000u | 1u)) | a0[u1 & 3u])) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    L4: if (--fuel == 0u) goto done;
                    h0 = (short)(1u + (unsigned)((int)(unsigned)(x0 >> 70) >= (int)a0[u1 & 3u]));
                    *q0 += (0x80000000u >> ((unsigned)b0 & 31u));
                    u0 = u0 * 0x9e3779b1u + (4u & *q0);
                }
                *q0 = ((unsigned)c1 ^ (unsigned)((int)(unsigned)e0 < (int)(unsigned)((0xfad97a7eu + g0) || r0.x)));
                break; (void)(r0.y);
                if (u3 == 7u) return 9u;
                if ((unsigned)e0) goto L4;
            } else {
                if (u3) break;
                if ((0xaad913f5u ^ r0.y)) {
                    i0 = ~(((p1 / (p1 | 1u)) % (((unsigned)(x0 >> 70) >> (p0 & 31u)) | 1u)) & 2u) & 15u;
                    while (i1++ < 4u && 0x59e4b728u) { if (--fuel == 0u) goto done;
                        for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                            if ((-((unsigned)c1 / (fuel | 1u)) - 0xbebfbe90u)) break;
                            if ((unsigned)((unsigned)(fuel == 0x7fffffffu) < *mp)) break;
                            if ((unsigned)((0x85c6d176u ^ v0) && 0x59f21f57u)) break;
                            v0 = (5u >> (*q0 & 31u));
                            g0 = (unsigned)(unsigned char)(unsigned)(-(i0 >> (((unsigned)h0 - p2) & 31u)) || 0xfab211f9u);
                            if (budget != 0u) { budget -= 1u; u2 = fn0(0xffffffffu, m0, ((unsigned)l0 + (m0 << ((unsigned)s0 & 31u)))); }
                        }
                        q0 = &garr[(garr[i1 & 7u] * r0.y) & 7u];
                        do { if (--fuel == 0u) goto done;
                            if (a0[u1 & 3u]) break;
                            r0.y ^= (unsigned)(short)(v0 >> (((0x7fffffffu ^ (unsigned)c1) ^ -(unsigned)((int)*mp < (int)m0)) & 31u));
                            b0 = ((0x4651d42u << ((unsigned)(signed char)((unsigned)e0 + u3) & 31u)) << (garr[u2 & 7u] & 31u)) != 0u;
                            i0 = (unsigned)((int)0x1f3b4df3u >= (int)0xffffffffu) & 15u;
                            if (budget != 0u) { budget -= 1u; u3 = fn1(p1, -(unsigned)((unsigned)f0 < (unsigned)s1), (unsigned)((unsigned)s0 || (unsigned)x0)); }
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(w0 >> 29), v0, (*mp & ~((unsigned)b0 * 5u))); }
                        } while (i2++ < 5u && r0.x);
                    }
                    while (i1++ < 6u && u0) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + (p1 ? u1 : 0x7d4568b2u));
                        while (i2++ < 6u && fuel) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn1((9u / ((unsigned)s1 | 1u)), (0xe7f785fdu % (0x863d7766u | 1u)), (unsigned)((garr[u2 & 7u] ^ (unsigned)f0) || 0x7fffffffu)); }
                            g0 = (((0x10000u << (p0 & 31u)) ? (unsigned)f0 : (unsigned)x0) | (unsigned)s0);
                            b0 = ((unsigned)d0 % ((unsigned)((int)(unsigned)c1 >= (int)(unsigned)w0) | 1u)) != 0u;
                            s0 = (int)(unsigned)((unsigned)((unsigned)s1 && (unsigned)(x0 >> 70)) && (a0[i0 & 3u] * (unsigned)(x0 >> 70)));
                            if ((unsigned)(short)(0xe8aa3fc4u ^ 0x1311c876u)) break;
                            garr[(unsigned)c0 & 7u] = (((unsigned)b0 * (unsigned)w0) >> (3u & 31u));
                        }
                        if (budget != 0u) { budget -= 1u; u1 = fn1((0x7fffffffu ^ (unsigned)(u2 < (unsigned)h1)), ((unsigned)!(a0[i0 & 3u] << (0xab4dfdb7u & 31u)) << (u2 & 31u)), 0x7fffffffu); }
                        *q0 = ((unsigned)(short)((unsigned)s1 ^ i1) >> (garr[u2 & 7u] & 31u));
                    }
                    switch ((unsigned)((short)u0 > (signed char)(unsigned)h0) & 7u) {
                        c0 = (unsigned char)(0x15099a0cu << (g0 & 31u));
                        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(i2 && (unsigned)s0) | 0x674c8756u), (unsigned)(a0[i0 & 3u] == ((unsigned)h1 >> (v0 & 31u))), 0xffffffffu); }
                        *q0 = (((unsigned)((unsigned)c1 == (unsigned)h0) >> (m0 & 31u)) / ((unsigned)x0 | 1u));
                        v0 = ((p0 << (a0[i0 & 3u] & 31u)) - (((unsigned)d0 | 0x65b71934u) % ((unsigned)e0 | 1u)));
                        g0 = (1u ^ ~(unsigned)((int)7u < (int)(7u % (garr[i1 & 7u] | 1u))));
                    }
                    a0[(unsigned)(x0 >> 70) & 3u] = i1;
                } else {
                    f0 = f0 * 0.5f + (float)((unsigned)((0x7fffffffu >> (0x6692b5fau & 31u)) || (unsigned)(short)(garr[i1 & 7u] | (unsigned)s1)) & 255u);
                    g1 += ((unsigned)s0 - m0);
                    f0 = f0 * 0.5f + (float)((unsigned)(4u && (*q0 & (unsigned)(u3 == (unsigned)h0))) & 255u);
                    for (;;) { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(9u ^ ((unsigned)l0 | ((unsigned)e0 & fuel)));
                        if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, (u1 | (7u << (0x10000u & 31u))), (unsigned)(fuel == i0)); }
                        break; (void)((0x10000u ^ 0xffffffffu));
                    }
                }
            }
            break; (void)((garr[u2 & 7u] | i2));
            c1 = (signed char)~((i2 << (0x80000000u & 31u)) - (v0 - g0));
        } else {
            if (budget != 0u) { budget -= 1u; u2 = fn0((4u ^ r0.x), ((unsigned)((unsigned)e0 && (unsigned)(x0 >> 70)) & a0[i0 & 3u]), (0x10000u << ((unsigned)(x0 >> 70) & 31u))); }
            m0 ^= ((unsigned)((int)(unsigned)h0 < (int)(unsigned)c0) >> (((unsigned)(w0 >> 29) ^ p1) & 31u));
            if ((6u ^ ((unsigned)d0 - fuel))) {
                *q0 += p1;
                while (i1++ < 6u && (unsigned)((short)*q0 > (signed char)r0.x)) { if (--fuel == 0u) goto done;
                    if (r0.x) break;
                    if ((0x80000000u | (unsigned)(a0[i0 & 3u] < (unsigned)f0))) goto L0;
                }
                v0 = (*mp * (unsigned)h1);
                u3 = u3 * 0x9e3779b1u + ((unsigned)b0 % (*mp | 1u));
                *q0 = (unsigned)(signed char)((unsigned)(signed char)(fuel * 0x10000u) - (unsigned)((unsigned)e0 && (unsigned)(signed char)(unsigned)(garr[i1 & 7u] && (unsigned)(x0 >> 70))));
            } else {
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    g0 = (0x10000u ^ u1);
                    if (u3 == 7u) return (unsigned)((unsigned)((int)a0[i0 & 3u] >= (int)0x9de7207fu) || 0x8c29a2ecu);
                    if (p2) goto L4;
                    h1 = (unsigned short)(h1 + (unsigned)s0);
                }
                if ((((unsigned)h0 >> ((unsigned)(w0 >> 29) & 31u)) ^ g0)) break;
                *q0 = (unsigned)((int)(unsigned)b0 < (int)(0xe3f3a914u % ((unsigned)(0x50c606e7u || (i0 | 0x6dfb9f4au)) | 1u)));
            }
            if (u1) {
                e0 = e0 * 0.5L + (long double)(r0.y & 1023u);
                b0 = (unsigned)((short)((unsigned)c1 % (*mp | 1u)) > (signed char)(unsigned)((short)(unsigned)((int)p1 < (int)i1) > (signed char)i2)) != 0u;
                while ((unsigned)(short)((0x7fffffffu >> ((unsigned)s0 & 31u)) << (g0 & 31u))) { if (--fuel == 0u) goto done;
                    r0.x = (((unsigned)(w0 >> 29) | g0) + ((unsigned)(0x67097950u || 0u) % (garr[u2 & 7u] | 1u)));
                    i0 = (0x80000000u - (unsigned)h0) & 15u;
                    break; (void)(u0);
                    l0 = (long)((unsigned long)l0 + (unsigned)f0);
                    s0 = (int)(unsigned)(g0 == i1);
                }
            }
        }
        switch ((3u & (unsigned)(unsigned char)(unsigned)((unsigned)e0 || (unsigned)x0)) & 7u) {
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)1u >= (int)0x9e63033bu), (unsigned)(r0.y == (unsigned)!(unsigned)(0x8647ace7u == i1)), ~((unsigned)(w0 >> 29) & (unsigned)(0x10000u && r0.x))); }
            break; (void)((unsigned)(signed char)(unsigned)((int)*q0 >= (int)8u));
            case 0u: ;
        }
    } while (i0++ < 5u && (fuel ? 8u : (unsigned)l0));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (2u & 7u) {
            if (fuel < 8u) return (unsigned)((int)g1 >= (int)(0x7fffffffu | (unsigned)c0));
            if ((unsigned)(*mp && (u2 << (i2 & 31u)))) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((0x10000u / (*mp | 1u)), (unsigned)(0x8f5b16d5u && 1u), (u2 / (a0[i0 & 3u] | 1u))); }
            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)s1 == (unsigned)d0);
            switch ((0xf6cb160eu & (unsigned)((int)0x80000000u >= (int)(unsigned)l0)) & 7u) {
                case 1u: ;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)((unsigned)x0 / (p0 | 1u)), ((unsigned)(unsigned char)(a0[i0 & 3u] / (5u | 1u)) - 6u), garr[u2 & 7u]); }
                if (u3 == 7u) return ((i0 % (*mp | 1u)) >> (m0 & 31u));
                if (0x7e1234c0u) goto L2;
                g0 = 0x5b8490b0u;
                case 3u: ;
            }
            if (((unsigned)f0 % (u2 | 1u))) {
                u1 ^= (unsigned)((int)0x341e3e4eu >= (int)0x7fffffffu);
            } else {
                if (0x80000000u) {
                    while (i1++ < 4u && (unsigned)f0) { if (--fuel == 0u) goto done;
                        if ((g0 << ((unsigned)s0 & 31u))) {
                            if (((unsigned)d0 / ((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)c1) | 1u))) break;
                            f0 = f0 * 0.5f + (float)((unsigned)((u0 ^ ((unsigned)x0 & (unsigned)w0)) < (unsigned)((int)m0 >= (int)(unsigned)s0)) & 255u);
                            e0 = e0 * 0.5L + (long double)(((unsigned)s0 & a0[i0 & 3u]) & 1023u);
                            if (budget != 0u) { budget -= 1u; u1 = fn0((0xffffffffu << (0x22b1f67fu & 31u)), (0x80000000u >> (a0[i0 & 3u] & 31u)), (unsigned)((unsigned)!(unsigned)(*q0 == g1) < p1)); }
                        } else {
                            if (budget != 0u) { budget -= 1u; u0 = fn0((r0.y / (a0[i0 & 3u] | 1u)), (unsigned)(unsigned char)(g1 & u1), 2u); }
                            case 0u: ;
                            case 5u: ;
                        }
                        if (0u) goto done;
                        if (fuel < 8u) return (unsigned)((int)m0 < (int)0x80000000u);
                        u2 = u2 * 0x9e3779b1u + (garr[u2 & 7u] << (~((unsigned)(x0 >> 70) * (unsigned)(short)(0x10000u * i1)) & 31u));
                    }
                    e0 = e0 * 0.5L + (long double)(((unsigned)h1 ? 3u : (unsigned)s1) & 1023u);
                }
                if ((unsigned)(8u || (0xa4ac92bau / (4u | 1u)))) break;
                if (-((g0 + (unsigned)h0) << (0u & 31u))) break;
            }
        }
        if ((v0 * (r0.x << ((unsigned)d0 & 31u)))) continue;
    }
    if ((0u | (0xe3aec7f2u - u2))) goto L4;
    d0 = d0 * 0.5 + (double)((unsigned)(a0[i0 & 3u] && ((unsigned)((int)a0[u1 & 3u] < (int)p2) & ((unsigned)e0 / ((unsigned)h0 | 1u)))) & 1023u);
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(*mp || (unsigned)b0), ((unsigned)c1 & ((unsigned)(x0 >> 70) << (0xc5b27dddu & 31u))), (u3 * r0.x)); }
    v0 = -(i2 << (m0 & 31u));
    if (0x7cbc6cb6u) goto L1;
    while (i0++ < 6u && fuel) { if (--fuel == 0u) goto done;
        if ((unsigned)((0x3e166d14u | (unsigned)(x0 >> 70)) < (unsigned)s0)) goto L0;
        if (0xaffba1f3u) break;
        u2 ^= ((unsigned)b0 - (((unsigned)c1 ^ (unsigned)l0) | ((unsigned)h1 * p1)));
        if ((unsigned)(short)(unsigned)((unsigned)(i2 && 0x742ca5d8u) || p2)) break;
    }
    do { if (--fuel == 0u) goto done;
        u2 += (unsigned)b0;
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)s1 >= (int)((unsigned)((int)((unsigned)h1 >> (u3 & 31u)) >= (int)(unsigned)(w0 >> 29)) % (3u | 1u)));
        r0.x = ((unsigned)w0 * (unsigned)b0);
        g0 = (unsigned)((int)(unsigned)e0 >= (int)0x2d79d2cbu);
    } while (i0++ < 6u && (unsigned)(signed char)(unsigned)(8u && (unsigned)((unsigned)h1 == u1)));
    while (i0++ < 4u && 0x90aa1829u) { if (--fuel == 0u) goto done;
        if ((0xf9737636u >> (0x7bd1f0b3u & 31u))) break;
        goto L1;
        q0 = &garr[(((unsigned)x0 % (u3 | 1u)) / (((unsigned)(x0 >> 70) << ((unsigned)(r0.x == 0u) & 31u)) | 1u)) & 7u];
        break; (void)(((p1 & 1u) * 0xf01ac8b4u));
    }
    goto L2;
    v0 = (garr[i1 & 7u] * ((unsigned)((short)u3 > (signed char)u2) % (0x64e4d357u | 1u)));
    do { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)(((unsigned)h1 >> (0x82cafcd8u & 31u)) & 1023u);
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            garr[0x3f25103fu & 7u] = ((unsigned)((int)((unsigned)(x0 >> 70) / ((unsigned)h0 | 1u)) >= (int)(unsigned)((int)0x67f5d026u >= (int)(unsigned)(w0 >> 29))) ^ *mp);
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)c1, a0[i0 & 3u], (g1 + (unsigned)f0)); }
            *q0 += ((unsigned)c0 % (u0 | 1u));
            break; (void)((unsigned)!(unsigned)((int)5u >= (int)i1));
        }
        break; (void)(3u);
        l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)l0 < (unsigned)c1) ? (unsigned)(v0 == (unsigned)c0) : p0));
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)4u < (int)i1), (unsigned)(0xb6d99964u || g1), 0x7fffffffu); }
    } while (i0++ < 5u && (garr[i1 & 7u] >> (0x7fffffffu & 31u)));
    goto L1;
    { unsigned t2; double z2; if (((unsigned)(x0 >> 70)) & 1u) { t2 = 0x56b3f29u; z2 = (double)(((a0[i0 & 3u] & u0)) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        if (0x80000000u) goto L3;
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)(x0 >> 70) && (unsigned)s0), (unsigned)x0, (unsigned)((short)(unsigned)s0 > (signed char)(unsigned)f0)); }
    }
    f0 = f0 * 0.5f + (float)((((unsigned)((unsigned)((int)0x4c88b905u >= (int)0xe74c3ee4u) || i2) >> (i0 & 31u)) % (p0 | 1u)) & 255u);
    goto L3;
    if (budget != 0u) { budget -= 1u; u0 = fn0(garr[i1 & 7u], (unsigned)(0xe9da1ecbu == (unsigned)((int)(unsigned)l0 >= (int)g0)), *q0); }
    { unsigned t3; double z3; if ((2u) & 1u) { t3 = (unsigned)(0x80000000u || 0xdf2e4289u); z3 = (double)(((2u - p2)) & 255u); } if ((2u) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        if (u3) {
            if ((1u >> ((unsigned)(0x10000u < (unsigned)c0) & 31u))) goto L0;
            if (u1) goto L3;
        } else {
            if (((unsigned)d0 >> ((unsigned)((unsigned)f0 == v0) & 31u))) goto L1;
        }
        if (((unsigned)((unsigned)l0 == r0.y) / (0x10000u | 1u))) goto L1;
        r0.y ^= 0xffffffffu;
        if ((unsigned)((int)(unsigned)h0 < (int)0x6c1b5162u)) goto L2;
        x0 = x0 * 0x100000001b3ull + i2;
    }
    g0 = (unsigned)d0;
    v0 = ~((unsigned)(x0 >> 70) % (i1 | 1u));
    goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while (i0++ < 4u && i1) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)((1u ? 0u : garr[u2 & 7u]) ? 7u : (unsigned)s0) & 1023u);
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((0xe6ce4u ^ a0[u1 & 3u])) break;
            f0 = f0 * 0.5f + (float)(g1 & 255u);
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)s1 % ((0x80000000u << (0x80000000u & 31u)) | 1u)), ((unsigned)(x0 >> 70) + g1), (unsigned)(0x80000000u && 0x28598080u)); }
            f0 = f0 * 0.5f + (float)((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)!(unsigned)(u1 || (unsigned)c0)) & 255u);
            h1 = (unsigned short)(h1 + (unsigned)h0);
        }
        c1 = (signed char)((unsigned)c1 << ((unsigned)((short)i0 > (signed char)((unsigned)b0 ^ (0xecf26faau * (unsigned)s1))) & 31u));
        { unsigned t0; double z0; if ((a0[u1 & 3u]) & 1u) { t0 = (unsigned)((int)1u >= (int)(unsigned)(x0 >> 70)); z0 = (double)((0xe4175aa7u) & 255u); } if ((a0[u1 & 3u]) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            d0 = d0 * 0.5 + (double)((unsigned)((int)6u >= (int)(unsigned)(0x7fffffffu && u2)) & 1023u);
            s0 = (int)(unsigned)(x0 >> 70);
            if (((r0.x & u2) | 0xed54b994u)) continue;
            l0 = (long)((unsigned long)l0 + 3u);
            c0 = (unsigned char)i2;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)w0, (*mp - (unsigned)(3u == *mp)), ~((0x10000u + m0) + g0)); }
        }
    }
    h0 = (short)~(((unsigned)s0 - v0) - (7u - i0));
    if (u0) {
        w0 = w0 * 6364136223846793005ull + (unsigned)((short)p0 > (signed char)(unsigned)h0);
        do { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)(g1 == 0xffffffffu);
            c0 = (unsigned char)(0x9f0f65b7u ? (unsigned)h1 : (unsigned)(x0 >> 70));
            if (budget != 0u) { budget -= 1u; u3 = fn2(u3, p0, (unsigned)(0xe4f01f49u == (unsigned)f0)); }
            m0 ^= (unsigned)(signed char)(unsigned)(garr[u2 & 7u] && u0);
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (0x10000u) continue;
                if ((unsigned)!((unsigned)l0 / (p1 | 1u))) break;
                if (a0[u1 & 3u]) {
                    h1 = (unsigned short)(h1 + 0x7fffffffu);
                    if ((g1 / (1u | 1u))) continue;
                    g0 = (unsigned)c1;
                }
                *q0 += (((unsigned)c0 ? (unsigned)((unsigned)c1 && m0) : (unsigned)f0) << (0x86d4dba4u & 31u));
                break; (void)((unsigned)((int)4u >= (int)p2));
            }
            b0 = ((p0 % ((unsigned)(unsigned char)(unsigned)((int)a0[u1 & 3u] >= (int)r0.x) | 1u)) << ((0x6b8e0a92u * 0x80000000u) & 31u)) != 0u;
        } while (i0++ < 7u && r0.y);
        L0: if (--fuel == 0u) goto done;
        { unsigned t1; double z1; if (((i1 ^ (unsigned)h1)) & 1u) { t1 = (unsigned)(0x10000u == (unsigned)l0); z1 = (double)(((0xffffffffu - (unsigned)c0)) & 255u); } if (((i1 ^ (unsigned)h1)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            h1 = (unsigned short)(h1 + (unsigned)(0xedd028d7u < (unsigned)((a0[i0 & 3u] ^ (unsigned)s1) < a0[u1 & 3u])));
            u0 = p2;
            c1 = (signed char)(0x50fc08b9u * (fuel / ((v0 + (unsigned)s1) | 1u)));
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)c1 < (int)((0x80000000u << (0x1732bbecu & 31u)) & ~(unsigned)(i0 < 5u)));
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                *mp = (unsigned)((int)(unsigned)s1 < (int)(((unsigned)((int)0x5305db50u >= (int)p1) - (unsigned)c0) >> (fuel & 31u)));
                if (((unsigned)((int)(unsigned)h1 >= (int)a0[u1 & 3u]) * (unsigned)s1)) {
                    a0[u3 & 3u] = (unsigned)(short)(unsigned)(u0 || p1);
                    r0.x = ((unsigned)w0 / (~(((unsigned)w0 ^ p2) ^ (unsigned)d0) | 1u));
                    h1 = (unsigned short)(h1 + (unsigned)((int)(0x10000u ? 0x503f050cu : (unsigned)d0) < (int)(fuel / (a0[u1 & 3u] | 1u))));
                    g1 += 6u;
                }
                if ((unsigned)s1) goto L0;
                w0 = w0 * 6364136223846793005ull + (0x7fffffffu & (unsigned)((unsigned)h1 == ((p1 - 9u) ^ 0x10000u)));
            }
        }
        s0 = (int)(3u + (unsigned)(0x3a597a76u < 0x5bfff5e1u));
        w0 = w0 * 6364136223846793005ull + ((unsigned)((int)u3 < (int)(unsigned)l0) >> (u2 & 31u));
    }
    if ((unsigned)(7u == ((unsigned)d0 & 4u))) goto L0;
    { unsigned t2; double z2; if (((fuel ^ 0x27367289u)) & 1u) { t2 = (i1 + 9u); z2 = (double)((((unsigned)h1 & 0xffffffffu)) & 255u); } if (((fuel ^ 0x27367289u)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        w0 ^= (unsigned long long)(unsigned)x0 << (((unsigned)!(unsigned)((unsigned)f0 && g1) + (unsigned)((short)u2 > (signed char)(0x17ddd6a4u - (unsigned)(w0 >> 29)))) & 63u);
        garr[(unsigned)f0 & 7u] = (0x2f030480u % (r0.y | 1u));
        q0 = &garr[(r0.y >> ((unsigned)((unsigned)h0 < ((unsigned)(x0 >> 70) * (unsigned)((int)(unsigned)(x0 >> 70) >= (int)4u))) & 31u)) & 7u];
        q0 = &garr[((5u << ((unsigned)h1 & 31u)) / ((unsigned)((int)p2 < (int)0x66db740u) | 1u)) & 7u];
    }
    if (i0) goto L3;
    if (((a0[u1 & 3u] - g1) - p2)) {
        goto L1;
    } else {
        l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(unsigned)((unsigned)!(unsigned)(a0[u1 & 3u] && (unsigned)!(6u ^ (unsigned)s0)) < ((unsigned)h0 << (i2 & 31u))));
    }
    b0 = (unsigned)((short)(unsigned)(unsigned char)(p2 + 7u) > (signed char)6u) != 0u;
    do { if (--fuel == 0u) goto done;
        goto done;
        goto L0;
        do { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((unsigned)((int)(unsigned)l0 >= (int)-(unsigned)((short)0x81adeabu > (signed char)8u)) >> ((unsigned)((short)0xddd4f323u > (signed char)g0) & 31u)) & 1023u);
            *q0 += (u1 ? (unsigned)b0 : u3);
            if (budget != 0u) { budget -= 1u; u3 = fn1((garr[i1 & 7u] >> (0xeae5c812u & 31u)), ((garr[u2 & 7u] + 9u) / (u3 | 1u)), ((9u / (1u | 1u)) / ((unsigned)(x0 >> 70) | 1u))); }
            if ((a0[u1 & 3u] - a0[u1 & 3u])) goto done;
            L1: if (--fuel == 0u) goto done;
            *q0 = i2;
        } while (i1++ < 5u && 0xcf17d4b0u);
    } while (i0++ < 2u && (unsigned)((int)*q0 >= (int)m0));
    if ((unsigned)(signed char)((fuel / (0xffffffffu | 1u)) * 0x72556a10u)) goto done;
    L2: if (--fuel == 0u) goto done;
    c1 = (signed char)(unsigned)(signed char)((unsigned)w0 >> (2u & 31u));
    switch (0x10000u & 7u) {
        h0 = (short)((unsigned)l0 >> ((*mp | (v0 / ((u1 % (fuel | 1u)) | 1u))) & 31u));
    }
    do { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (unsigned)((short)(unsigned)!(unsigned)(r0.x || (unsigned)h0) > (signed char)(unsigned)((short)7u > (signed char)(unsigned)w0));
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)b0, (unsigned)h0, garr[i1 & 7u]); }
            h1 = (unsigned short)(h1 + (0xffffffffu - 9u));
            if (((unsigned)(short)(unsigned)((short)(unsigned)w0 > (signed char)0xad39497u) % (*mp | 1u))) break;
            if (fuel < 8u) return ((unsigned)b0 ? 1u : p1);
            x0 = x0 * 0x100000001b3ull + (fuel & (r0.x << (a0[u1 & 3u] & 31u)));
        }
        if ((0x11e44af2u >> (u0 & 31u))) continue;
        break; (void)((unsigned)f0);
        if (((unsigned)s0 << (*mp & 31u))) {
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t3; double z3; if ((5u) & 1u) { t3 = ((0x8799b4d4u >> (u2 & 31u)) | fuel); z3 = (double)((i1) & 255u); } if ((5u) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    break; (void)(3u);
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)(unsigned)h1 >= (int)(unsigned)w0), (unsigned)b0, (unsigned)h0); }
                    *q0 = (((unsigned)l0 >> ((unsigned)c1 & 31u)) << ((0u % (i2 | 1u)) & 31u));
                }
                L3: if (--fuel == 0u) goto done;
            }
            w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)(0x9ae3d080u << ((((unsigned)c0 | ((unsigned)e0 ^ (unsigned)e0)) * 4u) & 31u));
            if (((0xd9b640c4u & (unsigned)s1) & (unsigned)x0)) break;
            u2 = garr[i1 & 7u];
        }
        { unsigned t4; double z4; if (((unsigned)w0) & 1u) { t4 = (unsigned)x0; z4 = (double)(((unsigned)(unsigned char)(v0 << (((unsigned)c0 * v0) & 31u))) & 255u); } if (((unsigned)w0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            do { if (--fuel == 0u) goto done;
                switch (3u & 7u) {
                    if (((unsigned)x0 * 9u)) {
                        case 0u: ;
                        w0 = w0 * 6364136223846793005ull + (unsigned)((0x7fffffffu + r0.y) == 2u);
                        u3 ^= 0x66f04c95u;
                        if (u2) goto L4;
                        L4: if (--fuel == 0u) goto done;
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(p1, (0x10000u << (garr[i1 & 7u] & 31u)), (unsigned)(unsigned char)(unsigned)(0x80000000u && (0u >> (u1 & 31u)))); }
                    { unsigned t5; double z5; if (((0xe390e11u - (unsigned)(8u || (unsigned)h1))) & 1u) { t5 = (unsigned)b0; z5 = (double)((*mp) & 255u); } if (((0xe390e11u - (unsigned)(8u || (unsigned)h1))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                        for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                            u2 += (unsigned)((short)-(p1 ? g0 : 0x15afa818u) > (signed char)0xffffffffu);
                            r0.y ^= ((~(g0 / (g0 | 1u)) * (unsigned)b0) << (g0 & 31u));
                            q0 = &garr[(unsigned)((unsigned)s1 < 4u) & 7u];
                            if (budget != 0u) { budget -= 1u; u1 = fn0(0x79ff2eb8u, (0x88dc4a9au << (0x81eaee20u & 31u)), (unsigned)(*mp < 0xc5219e56u)); }
                            a0[(unsigned)e0 & 3u] = ((unsigned)(signed char)(((0x80000000u * p0) * r0.x) >> (0xce4021dau & 31u)) + 6u);
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(~(fuel >> ((unsigned)x0 & 31u)) && fuel), (unsigned)!(unsigned)(p2 < (unsigned)x0), (7u >> (a0[u1 & 3u] & 31u))); }
                        h0 = (short)(unsigned)b0;
                    }
                }
                if ((fuel | -(unsigned)((unsigned)c0 < 0x9f0746bbu))) {
                    g1 += (unsigned)(((unsigned)(short)((unsigned)c0 * (unsigned)l0) >> (m0 & 31u)) == 0x1aa27e28u);
                    e0 = e0 * 0.5L + (long double)((unsigned)((int)8u >= (int)*mp) & 1023u);
                    if (fuel < 8u) return (unsigned)((unsigned)((int)(unsigned)d0 < (int)(unsigned)(fuel == 0u)) && (unsigned)((short)(unsigned)e0 > (signed char)9u));
                    m0 ^= (unsigned)(i1 == (2u & (0x7351c029u - 0x80000000u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn2((i1 / ((unsigned)(short)(i0 / (g0 | 1u)) | 1u)), ((unsigned)d0 / ((unsigned)(i1 || 1u) | 1u)), (unsigned)((int)u3 >= (int)(unsigned)(unsigned char)(unsigned)(garr[u2 & 7u] == (unsigned)l0))); }
                    do { if (--fuel == 0u) goto done;
                        garr[((unsigned)w0 - (unsigned)f0) & 7u] = (unsigned)((unsigned)((short)u2 > (signed char)((unsigned)(4u < i1) % ((unsigned)b0 | 1u))) == (unsigned)e0);
                        a0[((unsigned)l0 + p1) & 3u] = ((unsigned)((unsigned)(p2 == u3) || (unsigned)h0) << ((unsigned)((short)p2 > (signed char)0x4a344246u) & 31u));
                        s0 = (int)(g1 << (r0.y & 31u));
                        f0 = f0 * 0.5f + (float)(((unsigned)((int)0x80000000u < (int)(unsigned)w0) % (*q0 | 1u)) & 255u);
                        *mp = (unsigned)((u2 << ((unsigned)h1 & 31u)) || (garr[i1 & 7u] | u2));
                    } while (i2++ < 6u && ((unsigned)s1 ^ (unsigned)x0));
                }
                g1 += (u2 | ((unsigned)h1 >> (garr[u2 & 7u] & 31u)));
                if (budget != 0u) { budget -= 1u; u2 = fn2(((i1 / (0xffffffffu | 1u)) >> (p0 & 31u)), g0, (garr[u2 & 7u] % (((unsigned)s0 % (p0 | 1u)) | 1u))); }
                s0 = (int)(unsigned)(0x9698d9c5u < (garr[i1 & 7u] & -(1u >> (8u & 31u))));
            } while (i1++ < 5u && ((unsigned)d0 + 0x10000u));
            u3 += garr[i1 & 7u];
            c1 = (signed char)(((unsigned)x0 / ((unsigned)c0 | 1u)) & 0xc9847f47u);
            while (i1++ < 6u && (0x10000u / ((unsigned)((short)0x10000u > (signed char)*mp) | 1u))) { if (--fuel == 0u) goto done;
                if (((unsigned)(short)(unsigned)(i0 && 0x10000u) ^ i2)) continue;
            }
            if (6u) break;
            if (r0.y) break;
        }
    } while (i0++ < 6u && (unsigned)(i2 < (unsigned)((short)u2 > (signed char)g1)));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((((unsigned)w0 | v0) | (unsigned)l0)) {
            c1 = (signed char)(unsigned)(0xffffffffu && (unsigned)((unsigned)(x0 >> 70) < (unsigned)h1));
            break; (void)((unsigned)f0);
            x0 = x0 * 0x100000001b3ull + ((unsigned)h1 | m0);
        }
        *q0 += (unsigned)(i0 && (unsigned)s1);
        if (budget != 0u) { budget -= 1u; u2 = fn0((r0.y / ((p1 ^ g0) | 1u)), *mp, (unsigned)h1); }
        if ((*mp - (unsigned)h0)) break;
        break; (void)((unsigned)(2u || (i0 >> ((unsigned)h1 & 31u))));
    }
    h1 = (unsigned short)(h1 + (unsigned)(i2 && u3));
    if ((unsigned)((m0 + 0x7fffffffu) < garr[u2 & 7u])) goto L4;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (fuel < 8u) return (((unsigned)b0 >> (8u & 31u)) & (p1 - r0.x));
            if (((unsigned)(short)(unsigned)((short)0x52cdd0d0u > (signed char)p0) << (8u & 31u))) break;
            if (garr[u2 & 7u]) goto L3;
        } while (i1++ < 7u && (unsigned)(*mp < (unsigned)s1));
        if (0xffffffffu) {
            u0 = u0 * 0x9e3779b1u + (unsigned)(-(unsigned)((int)(unsigned)(p0 || 0u) >= (int)u2) || p0);
            if ((unsigned)((int)(unsigned)h0 >= (int)p2)) break;
            if (u3 == 7u) return (unsigned)((unsigned)s0 || (m0 * u0));
            if ((a0[u1 & 3u] << (i2 & 31u))) break;
            g0 = 0x6506b9ceu;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)u2 >= (int)(unsigned)s0), ((unsigned)(unsigned char)(0xffffffffu % ((unsigned)h0 | 1u)) / ((unsigned)x0 | 1u)), (unsigned)(a0[u1 & 3u] && (unsigned)((unsigned)d0 == u3))); }
        } else {
            c0 = (unsigned char)(unsigned)(signed char)(unsigned)((int)p1 < (int)(unsigned)((int)garr[i1 & 7u] < (int)(unsigned)((short)0x80000000u > (signed char)0x4df96829u)));
            do { if (--fuel == 0u) goto done;
                break; (void)((u1 * (unsigned)c0));
                break; (void)(2u);
                if (i1) continue;
                *q0 += (unsigned)((unsigned)(9u == (unsigned)((int)(unsigned)d0 < (int)*q0)) || p2);
            } while (i1++ < 7u && ((unsigned)b0 | (unsigned)s1));
        }
    }
    q0 = &garr[0xb17064d3u & 7u];
    switch ((6u ^ ((unsigned)x0 << (garr[i1 & 7u] & 31u))) & 7u) {
        if ((r0.y >> (a0[u1 & 3u] & 31u))) goto L1;
        break; (void)((unsigned)c1);
        h0 = (short)(unsigned)((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)f0) == (0x151fd9bfu - a0[i0 & 3u]));
    }
    if ((unsigned)((unsigned)(i2 == 6u) && (unsigned)(w0 >> 29))) goto L2;
    q0 = &garr[(unsigned)(i0 && ((unsigned)c0 | (unsigned)(a0[i0 & 3u] == v0))) & 7u];
    h1 = (unsigned short)(h1 + (unsigned)(p2 && p1));
    goto L4;
    if ((unsigned)w0) {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)((unsigned)d0 - *q0) < (int)(unsigned)l0)) break;
            if ((unsigned)((int)(unsigned)c0 < (int)u1)) {
                if ((a0[i0 & 3u] | ((unsigned)d0 + 0x9959d673u))) goto L1;
                if ((unsigned)((int)(unsigned)w0 < (int)(unsigned)(x0 >> 70))) break;
                if ((unsigned)(u3 < (unsigned)((unsigned)c1 < 0x8ebed86bu))) break;
            }
            u2 += i2;
            e0 = e0 * 0.5L + (long double)((2u & (r0.y + (unsigned)(w0 >> 29))) & 1023u);
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (garr[u2 & 7u]) {
                if ((unsigned)(0x53083cf5u == 0x7fffffffu)) break;
                break; (void)((i2 >> ((unsigned)w0 & 31u)));
                if ((5u ^ (0xffffffffu % (6u | 1u)))) break;
                g1 += (unsigned)((short)8u > (signed char)(g1 - p1));
                switch ((unsigned)((unsigned)h0 < m0) & 7u) {
                    switch ((unsigned)(w0 >> 29) & 7u) {
                        e0 = e0 * 0.5L + (long double)((p1 >> ((unsigned)!((0x10000u | (unsigned)l0) << (-(garr[u2 & 7u] / (0xcd490288u | 1u)) & 31u)) & 31u)) & 1023u);
                        h0 = (short)4u;
                        case 4u: ;
                        g1 += (unsigned)((short)r0.y > (signed char)p1);
                    }
                    g1 += (unsigned)!((unsigned)x0 - 0xf91e8f11u);
                }
                break; (void)(i0);
            } else {
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (unsigned)(0xffffffffu == i2);
                    v0 = (unsigned)(signed char)((unsigned)(unsigned char)(fuel << (0u & 31u)) | (0xffffffffu * i0));
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1(0x80000000u, 0u, ((0xffffffffu << ((unsigned)h0 & 31u)) / (0x80000000u | 1u))); }
                b0 = (unsigned)(((unsigned)(0xc5ba2a92u == (unsigned)c0) & (a0[u1 & 3u] | 0x6a7b6adu)) && (unsigned)l0) != 0u;
                w0 = w0 * 6364136223846793005ull + (0x41363929u | (unsigned)(signed char)(unsigned)((short)0u > (signed char)0x7fffffffu));
            }
            break; (void)((unsigned)((unsigned)((int)0x7b3235d5u >= (int)(unsigned)h1) || (unsigned)h0));
            break; (void)(0u);
            if (budget != 0u) { budget -= 1u; u2 = fn0(~(unsigned)((p2 - 4u) || 0x80000000u), (0x7fffffffu ^ 7u), ((unsigned)(p2 == 0x4cd0a14u) ^ u3)); }
            i0 = (fuel | (unsigned)((short)g0 > (signed char)0x4682e0dau)) & 15u;
            *q0 += ((((unsigned)b0 + p2) & (unsigned)w0) >> ((unsigned)h1 & 31u));
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)h0, ~(g1 | garr[i1 & 7u]), 8u); }
        if ((unsigned)e0) {
            if (((0xbb620aa5u - (unsigned)(w0 >> 29)) + a0[u1 & 3u])) goto L2;
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)e0 * (1u & u2)), ((0x7fffffffu + (unsigned)h1) >> (*mp & 31u)), (unsigned)b0); }
        }
        if ((0x7fffffffu - -(0x10000u | 0xd4364c9u))) {
            i2 = 0xffffffffu & 15u;
            x0 = x0 * 0x100000001b3ull + (unsigned)((p2 & a0[u1 & 3u]) == 0xd219e97du);
            if (budget != 0u) { budget -= 1u; u1 = fn2(a0[u1 & 3u], (unsigned)(signed char)(unsigned)((short)i0 > (signed char)i1), ((unsigned)c0 % (0x2da290cau | 1u))); }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(signed char)((unsigned)c1 | (6u / ((unsigned)w0 | 1u))), ((unsigned)s1 - u0), (unsigned)(0x7fffffffu || u1)); }
            w0 = w0 * 6364136223846793005ull + (r0.y ^ (unsigned)s1);
        }
        { unsigned t6; double z6; if (((v0 + (unsigned)f0)) & 1u) { t6 = (unsigned)((short)r0.y > (signed char)u2); z6 = (double)(((unsigned)(a0[u1 & 3u] || 0x80000000u)) & 255u); } if (((v0 + (unsigned)f0)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            d0 = d0 * 0.5 + (double)(((unsigned)(0x7050dcbdu < 0xffffffffu) >> ((unsigned)c1 & 31u)) & 1023u);
            goto L1;
            a0[(0x80000000u / (p0 | 1u)) & 3u] = (unsigned)((short)0xffffffffu > (signed char)(unsigned)(p1 || p2));
        }
    }
    e0 = e0 * 0.5L + (long double)((unsigned)!(m0 / (u0 | 1u)) & 1023u);
    if ((v0 / ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)u0) | 1u))) {
        if ((2u % (0x51bda05bu | 1u))) {
            if ((unsigned)d0) goto L1;
            if (5u) {
                q0 = &garr[(a0[u1 & 3u] / (r0.y | 1u)) & 7u];
                m0 ^= (unsigned)((int)0xc79c4a6bu >= (int)(unsigned)c1);
                if (fuel < 8u) return (unsigned)((unsigned)(signed char)((unsigned)(m0 && (unsigned)(short)(0x13c41315u ^ 0x149d4e54u)) / (0u | 1u)) || *mp);
            } else {
                r0.y ^= (unsigned)((int)a0[i0 & 3u] < (int)0xffffffffu);
                *q0 += ((unsigned)((int)(unsigned)h0 >= (int)(unsigned)s0) >> ((unsigned)((short)(unsigned)((unsigned)l0 == 0x6e33046du) > (signed char)0u) & 31u));
            }
            *mp = (unsigned)((unsigned)s1 && (unsigned)(7u || *q0));
            if ((unsigned)!(unsigned)((int)(unsigned)((short)0x40b8729u > (signed char)u2) >= (int)fuel)) goto L2;
            if (budget != 0u) { budget -= 1u; u0 = fn0(a0[u1 & 3u], (0xe2c6a0adu << (i0 & 31u)), (5u + (unsigned)((int)(unsigned)h1 < (int)u1))); }
            goto L0;
        } else {
            *q0 += (unsigned)(signed char)(unsigned)((short)0x1d5332a0u > (signed char)-((u1 | 0xc1dce976u) * g0));
            if ((unsigned)s1) {
                v0 = -(unsigned)(i1 == (unsigned)(short)(u3 << (((unsigned)d0 >> (a0[i0 & 3u] & 31u)) & 31u)));
                u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)((int)(unsigned)(short)(unsigned)(2u || i1) < (int)g1) == 0x7fffffffu);
                goto L1;
                if ((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)(p0 == u1))) goto L1;
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    c1 = (signed char)(unsigned)((int)(unsigned)h0 >= (int)(unsigned)(*q0 < (unsigned)((unsigned)!(unsigned)((int)1u < (int)7u) && (unsigned)f0)));
                    s1 = (int)((unsigned)s1 + (fuel >> ((unsigned)((int)-(0x6efc147au % (u1 | 1u)) >= (int)p1) & 31u)));
                    b0 = i0 != 0u;
                    { unsigned t7; double z7; if (((p0 % ((unsigned)c0 | 1u))) & 1u) { t7 = (unsigned)((unsigned)(u1 == r0.x) || 2u); z7 = (double)(((unsigned)((unsigned)d0 < (unsigned)(signed char)(a0[u1 & 3u] ^ (unsigned)b0))) & 255u); } if (((p0 % ((unsigned)c0 | 1u))) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                        h1 = (unsigned short)(h1 + (i0 >> ((2u << (0x4ec8bd33u & 31u)) & 31u)));
                    }
                }
                e0 = e0 * 0.5L + (long double)(((unsigned)(6u && (unsigned)(8u || p2)) + 0x181a8606u) & 1023u);
            }
            *q0 = (unsigned)(u3 && 1u);
        }
        while (((unsigned)(garr[u2 & 7u] < (unsigned)(x0 >> 70)) / (p2 | 1u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(signed char)(0xadcde10fu * u2), (unsigned)((short)p2 > (signed char)p2), (0x9e94334fu & u1)); }
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)(unsigned)((unsigned)b0 || i0) > (signed char)garr[i1 & 7u]), (a0[u1 & 3u] ^ u1), ((unsigned)s1 / ((unsigned)(0u || (unsigned)(w0 >> 29)) | 1u))); }
            do { if (--fuel == 0u) goto done;
                if (0x7fffffffu) {
                    v0 = (unsigned)e0;
                    *q0 += ((unsigned)(w0 >> 29) / (g0 | 1u));
                    c1 = (signed char)(0x10000u << (a0[u1 & 3u] & 31u));
                    i0 = (unsigned)((int)(g1 & garr[i1 & 7u]) >= (int)(unsigned)f0) & 15u;
                } else {
                    *q0 = (r0.x / (~(0x10000u & (unsigned)f0) | 1u));
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(signed char)(unsigned)((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)x0) && v0), i0, (unsigned)(i0 && (*mp % (0x1bff3ca3u | 1u)))); }
                }
                if (0x10000u) continue;
            } while (i1++ < 4u && ((unsigned)(w0 >> 29) | (unsigned)(u2 || 2u)));
            i0 = (unsigned)((unsigned)(unsigned char)(unsigned)((int)0x901ad441u < (int)0u) && a0[i0 & 3u]) & 15u;
            c0 = (unsigned char)-(unsigned)((0x10000u * 0xffffffffu) < u2);
        }
    } else {
        c0 = (unsigned char)((unsigned)(0x7fffffffu && (a0[u1 & 3u] | 0xe6b7367du)) >> ((0x80000000u % (8u | 1u)) & 31u));
    }
    { unsigned t8; double z8; if (((unsigned)!(unsigned)((short)p2 > (signed char)u3)) & 1u) { t8 = ((unsigned)((int)0xffffffffu >= (int)0x7884458u) / ((unsigned)d0 | 1u)); z8 = (double)((9u) & 255u); } if (((unsigned)!(unsigned)((short)p2 > (signed char)u3)) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
        r0.y ^= ((unsigned)(w0 >> 29) & 0x10000u);
        *mp = (unsigned)((int)(unsigned)((unsigned)s1 == ((unsigned)x0 / ((unsigned)(garr[i1 & 7u] || 0x10000u) | 1u))) >= (int)i0);
        h0 = (short)g0;
        f0 = f0 * 0.5f + (float)(((g1 & 0x80000000u) | (unsigned)(short)(unsigned)((unsigned)((int)(unsigned)s1 < (int)v0) < 0xffffffffu)) & 255u);
        if ((0xffffffffu | (unsigned)f0)) {
            switch ((unsigned)l0 & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn1(0xfbbcda2au, (unsigned)((unsigned)((short)r0.x > (signed char)u3) && 0x51889eaeu), (unsigned)((int)p1 >= (int)0x10000u)); }
                if ((unsigned)((int)m0 >= (int)*mp)) goto L0;
                { unsigned t9; double z9; if (((2u + (a0[i0 & 3u] + 0x7fffffffu))) & 1u) { t9 = (~(g0 >> ((unsigned)x0 & 31u)) - 0u); z9 = (double)(((unsigned)(0xffffffffu && (0xa5b59987u * (unsigned)e0))) & 255u); } if (((2u + (a0[i0 & 3u] + 0x7fffffffu))) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
                    c1 = (signed char)(unsigned)(((unsigned)w0 << ((unsigned)b0 & 31u)) < (unsigned)f0);
                    if ((*mp ^ (unsigned)b0)) goto L3;
                    if ((unsigned)((int)*mp >= (int)(unsigned)h0)) {
                        e0 = e0 * 0.5L + (long double)((unsigned)(4u || m0) & 1023u);
                        case 1u: ;
                    } else {
                        case 4u: ;
                        default: ;
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn1(((m0 / (0xffffffffu | 1u)) / (u3 | 1u)), ((unsigned)w0 - g1), (unsigned)(signed char)((unsigned)(p0 < u2) + (unsigned)x0)); }
                }
                for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)((int)(unsigned)(x0 >> 70) < (int)(7u << ((unsigned)(7u == u1) & 31u)));
                    if (((2u & p1) | 0xf65475f7u)) goto L0;
                    u1 ^= (unsigned)!(unsigned)((unsigned)(u0 == (unsigned)(short)(unsigned)((short)0x9b9fc4beu > (signed char)(unsigned)s1)) || 8u);
                    if (((0x3166fde3u ^ 6u) + (unsigned)w0)) break;
                    g0 = (p2 - -(unsigned)((unsigned)h0 && (unsigned)w0));
                }
                if (m0) {
                    if (((unsigned)(m0 < v0) + u0)) goto done;
                    *mp = (unsigned)!(p2 | (unsigned)(((unsigned)h1 & v0) || p1));
                } else {
                    { unsigned t10; double z10; if ((0x7fffffffu) & 1u) { t10 = (u2 & (unsigned)(0x1596c3b0u == fuel)); z10 = (double)((((g0 / ((unsigned)f0 | 1u)) + *q0)) & 255u); } if ((0x7fffffffu) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                        case 0u: ;
                    }
                    break; (void)((unsigned)((unsigned)f0 == 0u));
                    b0 = (unsigned)((int)u1 < (int)(unsigned)((int)u2 >= (int)i2)) != 0u;
                    i0 = u1 & 15u;
                }
            }
            g0 = ((unsigned)(p0 || (unsigned)((int)(unsigned)s0 < (int)(unsigned)b0)) % ((0x7fffffffu - 0x7fffffffu) | 1u));
            if (budget != 0u) { budget -= 1u; u3 = fn1(fuel, (unsigned)(signed char)(unsigned)((int)p0 < (int)(unsigned)(w0 >> 29)), (p0 + ((unsigned)f0 ^ (unsigned)h0))); }
            s0 = (int)r0.x;
            goto L1;
        } else {
            s0 = (int)(a0[u1 & 3u] % ((((unsigned)e0 & 0x186e15beu) - (unsigned)c1) | 1u));
        }
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(p0 < p2) == (unsigned)f0), (a0[u1 & 3u] | 0xffffffffu), (unsigned)(unsigned char)(m0 & v0)); }
            v0 = (unsigned)(m0 < 8u);
        } while (i0++ < 5u && (unsigned)h1);
    }
    while ((*q0 >> (v0 & 31u))) { if (--fuel == 0u) goto done;
        switch ((0x7cf3b871u & (unsigned)((int)(unsigned)x0 < (int)9u)) & 7u) {
            if (~(unsigned)((2u * garr[u2 & 7u]) || (unsigned)h0)) {
                case 4u: ;
                l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)(x0 >> 70) * (unsigned)(short)(unsigned)(p0 && g1)) >= (int)(unsigned)b0));
                case 2u: ;
            } else {
                h0 = (short)(unsigned)s0;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)(garr[u2 & 7u] * i0), (unsigned)e0, (p2 | (unsigned)h1)); }
                if (((unsigned)!(0x80000000u | 0x7fffffffu) << ((unsigned)s0 & 31u))) {
                    if (budget != 0u) { budget -= 1u; u0 = fn2((g1 ^ i2), (0xbb58bacdu + a0[u1 & 3u]), ((unsigned)(short)(0x92928f11u * (unsigned)d0) + u2)); }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(unsigned char)(unsigned)((int)(fuel + 0xe0528b9bu) < (int)1u), ((unsigned)h1 | (unsigned)!(unsigned)(r0.x && p1)), (unsigned)d0); }
                    v0 = u2;
                    g1 += (p0 ^ ((unsigned)b0 ^ 0x80000000u));
                } else {
                    *q0 += (unsigned)c1;
                    l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(unsigned)((int)0xffffffffu >= (int)7u));
                }
            }
            case 1u: ;
            u1 ^= (7u / (g1 | 1u));
            if ((0xffffffffu - (unsigned)(w0 >> 29))) {
                v0 = ((unsigned)!(unsigned)((unsigned)c0 && u1) / ((unsigned)(0xacec52cu && (unsigned)x0) | 1u));
                switch (2u & 7u) {
                    u0 = u0 * 0x9e3779b1u + ((unsigned)((int)(unsigned)h1 < (int)(unsigned)((unsigned)((int)(unsigned)(x0 >> 70) < (int)0xb7b8b1c0u) == garr[i1 & 7u])) - r0.x);
                    r0.x = ((unsigned)h1 << (garr[i1 & 7u] & 31u));
                    if ((unsigned)b0) goto L3;
                    if ((p1 + 0x7fffffffu)) continue;
                }
                e0 = e0 * 0.5L + (long double)((unsigned)!(unsigned)(((unsigned)l0 ^ g0) && m0) & 1023u);
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (0x80000000u) break;
                    i1 = ((p2 - p0) - (8u / ((fuel & 5u) | 1u))) & 15u;
                }
                r0.y ^= ((unsigned)x0 | *q0);
                m0 ^= (a0[u1 & 3u] + i0);
            }
            g1 += (unsigned)((int)((unsigned)w0 ? *mp : (unsigned)s1) >= (int)p0);
        }
        do { if (--fuel == 0u) goto done;
            switch ((r0.x / ((i0 - (unsigned)b0) | 1u)) & 7u) {
                if (fuel < 8u) return (unsigned)(p0 || ((unsigned)(0x7fffffffu || 0x35bbf523u) * a0[u1 & 3u]));
                case 3u: ;
                s0 = (int)3u;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn1(0xe1de5f69u, (unsigned)((int)(unsigned)l0 < (int)(unsigned)c0), ~(u1 - ((unsigned)f0 << (garr[i1 & 7u] & 31u)))); }
            if (r0.x) break;
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                u3 = u3 * 0x9e3779b1u + ((fuel / ((unsigned)b0 | 1u)) % ((unsigned)l0 | 1u));
                if ((p0 + p2)) break;
                garr[(p2 % (fuel | 1u)) & 7u] = ((((unsigned)x0 / ((unsigned)c0 | 1u)) / ((0xb72fbef7u / (1u | 1u)) | 1u)) % (u3 | 1u));
                x0 = x0 * 0x100000001b3ull + ((-(unsigned)(0xff864f7du || 0x789bf118u) % (5u | 1u)) ^ (0x10000u & (unsigned)x0));
                if (budget != 0u) { budget -= 1u; u1 = fn1(m0, (unsigned)((unsigned)(x0 >> 70) < (unsigned)(x0 >> 70)), (0x188bc080u & (unsigned)h0)); }
            }
            if ((unsigned)((short)(g0 & (unsigned)s0) > (signed char)0xe7ed51u)) {
                w0 ^= (unsigned long long)(unsigned)((unsigned)h0 && garr[i1 & 7u]) << ((u0 & (garr[u2 & 7u] | (0x80000000u ^ 1u))) & 63u);
                h0 = (short)(0xf403bf00u + (p2 ^ u0));
                if ((unsigned)((int)(unsigned)l0 < (int)garr[i1 & 7u])) break;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)((unsigned)f0 >> (0xffffffffu & 31u)) >= (int)garr[u2 & 7u]), ((unsigned)l0 | (unsigned)c0), (r0.y << ((unsigned)w0 & 31u))); }
            } else {
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)(0x10000u & 1023u);
                }
                break; (void)((unsigned)((unsigned)((unsigned)x0 || (unsigned)f0) == garr[u2 & 7u]));
                f0 = f0 * 0.5f + (float)(((unsigned)(a0[u1 & 3u] == (unsigned)s0) | 0xbc7ade28u) & 255u);
            }
        } while (i1++ < 4u && (m0 + (*mp % ((unsigned)(x0 >> 70) | 1u))));
        g1 += p2;
        switch ((unsigned)h1 & 7u) {
            { unsigned t11; double z11; if ((((unsigned)c1 & i0)) & 1u) { t11 = (unsigned)((int)(unsigned)s1 < (int)9u); z11 = (double)(((unsigned)s0) & 255u); } if ((((unsigned)c1 & i0)) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
                m0 ^= (unsigned)((int)((unsigned)b0 | (unsigned)w0) >= (int)((6u ^ (unsigned)s1) + 0xd88bf0c3u));
                if ((i1 - (unsigned)l0)) goto L0;
                if (fuel < 8u) return (unsigned)(signed char)(unsigned)((short)(i1 & (unsigned)l0) > (signed char)((unsigned)x0 & (garr[u2 & 7u] % ((unsigned)w0 | 1u))));
                u2 += (p1 | (unsigned)w0);
                while (p1) { if (--fuel == 0u) goto done;
                    v0 = (0x80000000u >> (((u2 * u3) - (unsigned)s0) & 31u));
                    if (((unsigned)(u2 < *q0) | 1u)) {
                        if (u3 == 7u) return ((unsigned)(unsigned char)(unsigned)((unsigned)((unsigned)h1 < (unsigned)f0) && (unsigned)(signed char)(0xffffffffu * 0x5a4970f3u)) % (0xd3930bc3u | 1u));
                        if (budget != 0u) { budget -= 1u; u2 = fn2(0xffffffffu, (0x7fffffffu << (p2 & 31u)), (((unsigned)(w0 >> 29) + p0) ^ 0xffffffffu)); }
                        do { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)((short)p0 > (signed char)p1) % (u2 | 1u)), (unsigned)h0, (unsigned)(a0[u1 & 3u] && *q0)); }
                        } while (i2++ < 6u && (unsigned)(*q0 && r0.y));
                        do { if (--fuel == 0u) goto done;
                            d0 = d0 * 0.5 + (double)((i0 + ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)i0) << (v0 & 31u))) & 1023u);
                            if (budget != 0u) { budget -= 1u; u0 = fn1(-(unsigned)(-((unsigned)c1 >> (5u & 31u)) || 0x7fffffffu), ((unsigned)((int)0x6dcb2505u >= (int)(unsigned)c1) % ((unsigned)b0 | 1u)), a0[i0 & 3u]); }
                            r0.y ^= (unsigned)((short)(unsigned)((int)g1 >= (int)(7u / ((unsigned)c0 | 1u))) > (signed char)r0.x);
                        } while (i2++ < 5u && ((unsigned)((int)r0.y >= (int)(unsigned)c1) * 0x80000000u));
                        switch (garr[i1 & 7u] & 7u) {
                            break; (void)(((unsigned)w0 + 0x3eda3144u));
                            u2 = u2 * 0x9e3779b1u + (unsigned)(p1 < (g1 << (a0[i0 & 3u] & 31u)));
                            q0 = &garr[(unsigned)!((unsigned)(unsigned char)(p1 % (((unsigned)s0 >> (0xcfef1099u & 31u)) | 1u)) % (u1 | 1u)) & 7u];
                        }
                    }
                }
            }
            l0 = (long)((unsigned long)l0 + ~(unsigned)((unsigned)l0 < ((unsigned)((unsigned)s0 || i1) & (unsigned)(0xedb5c3fdu || g1))));
            case 6u: ;
        }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(r0.x || (u2 ^ 2u)), (unsigned)(unsigned char)(unsigned)((int)r0.y < (int)a0[u1 & 3u]), (unsigned)(signed char)(*mp / (g0 | 1u))); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L4;
    goto L0;
    u1 ^= (0xffffffffu << ((unsigned)(short)((unsigned)h0 * m0) & 31u));
    if ((0x80000000u << ((u3 / ((unsigned)f0 | 1u)) & 31u))) goto L2;
    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(u2 || 0x80000000u) && 0xffffffffu));
    if ((unsigned)((int)(unsigned)e0 >= (int)(p0 % (9u | 1u)))) goto L3;
    L0: if (--fuel == 0u) goto done;
    g0 = 0x68b06b3au;
    if ((unsigned)((unsigned)s0 || (unsigned)b0)) {
        g0 = (unsigned)((r0.y ^ ((unsigned)b0 / ((2u - 0x1338a101u) | 1u))) < g1);
    } else {
        f0 = f0 * 0.5f + (float)(((unsigned)(unsigned char)(unsigned)((unsigned)((unsigned)w0 || (unsigned)h0) && (unsigned)e0) + (unsigned)((int)g1 >= (int)(unsigned)c0)) & 255u);
        garr[((unsigned)(x0 >> 70) * 0xab656b5eu) & 7u] = -(unsigned)((unsigned)((unsigned)(0x7fffffffu == garr[i1 & 7u]) == 0xc0096ddu) && (unsigned)b0);
        d0 = d0 * 0.5 + (double)((((7u | 0xffffffffu) ? g1 : r0.y) | 2u) & 1023u);
        while (i0++ < 3u && ((unsigned)c1 >> (0u & 31u))) { if (--fuel == 0u) goto done;
            if ((unsigned)(r0.y == *mp)) break;
            u1 = (unsigned)((unsigned)x0 == 0x10000u);
        }
    }
    i2 = (((unsigned)(x0 >> 70) / (p2 | 1u)) << (0x4988ff9eu & 31u)) & 15u;
    switch ((unsigned)(v0 && 0x80000000u) & 7u) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
            if ((unsigned)(0x10000u == (i0 + (unsigned)f0))) {
                f0 = f0 * 0.5f + (float)((i0 >> ((unsigned)c0 & 31u)) & 255u);
                *q0 = (0x9fae91eeu | (unsigned)((int)*q0 >= (int)p2));
                case 5u: ;
            } else {
                g1 += (unsigned)c0;
                l0 = (long)((unsigned long)l0 + a0[u1 & 3u]);
                u0 = (unsigned)((int)(unsigned)(short)(i0 >> (garr[u2 & 7u] & 31u)) < (int)(unsigned)((unsigned)((int)r0.x < (int)0xffffffffu) == *q0));
            }
        }
        i0 = (0x845db4f6u % (((unsigned)c1 | 9u) | 1u)) & 15u;
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)a0[u1 & 3u];
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                L2: if (--fuel == 0u) goto done;
                u3 = u3 * 0x9e3779b1u + (0x80000000u ^ (unsigned)w0);
                if (fuel < 8u) return ((unsigned)((short)(unsigned)(short)(r0.y << (u1 & 31u)) > (signed char)(unsigned)((unsigned)c1 && (unsigned)(x0 >> 70))) << (*q0 & 31u));
                b0 = u1 != 0u;
            }
            if ((unsigned)((int)i0 < (int)(unsigned)(signed char)(unsigned)(i0 == i2))) {
                b0 = (unsigned)((unsigned)s0 < garr[i1 & 7u]) != 0u;
                if (u3 == 7u) return garr[u2 & 7u];
                L3: if (--fuel == 0u) goto done;
                if ((unsigned)((short)(v0 | g1) > (signed char)garr[u2 & 7u])) goto L2;
                break; (void)((garr[i1 & 7u] | g1));
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(0x40f2f513u == m0), 0x3957fd5eu, ((unsigned)s0 % (p2 | 1u))); }
            }
            if (i2) {
                if ((unsigned)(short)(i0 + p0)) {
                    h1 = (unsigned short)(h1 + (unsigned)(short)(unsigned)((0x80000000u << (u1 & 31u)) || g1));
                    *q0 = (unsigned)((int)0xbe31bd64u < (int)(unsigned)s0);
                    if ((unsigned)((int)u2 >= (int)(unsigned)c0)) goto L1;
                    if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)(i0 && r0.x) - i0), (unsigned)f0, ((unsigned)d0 & (unsigned)b0)); }
                    if ((unsigned)((unsigned)c0 || 0x88347fdau)) {
                        x0 = x0 * 0x100000001b3ull + -(*mp ^ 0xed61bbebu);
                        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                            L4: if (--fuel == 0u) goto done;
                            garr[(p2 | (unsigned)c0) & 7u] = ((unsigned)b0 - v0);
                            *q0 += (((unsigned)!(u1 * (unsigned)b0) << (0x80000000u & 31u)) / ((unsigned)(signed char)(unsigned)((short)(unsigned)c0 > (signed char)m0) | 1u));
                            l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)((int)*q0 >= (int)(unsigned)h1) == u3) ^ (a0[i0 & 3u] % (*q0 | 1u))));
                            case 7u: ;
                        }
                        case 2u: ;
                        if ((2u ? 0x8af7df47u : 7u)) break;
                        h1 = (unsigned short)(h1 + 0x122cc037u);
                        c1 = (signed char)(u3 - u3);
                    }
                    while (i1++ < 4u && ((unsigned)(i0 && 0x775e6872u) << (0x10000u & 31u))) { if (--fuel == 0u) goto done;
                        continue; (void)(((unsigned)(short)((unsigned)h1 ^ 0xa6d58d6au) + 0x7fffffffu));
                        g1 += ((unsigned)(0xafdc0bdbu == ((unsigned)h0 & *q0)) & *mp);
                        h0 = (short)((unsigned)((m0 >> ((unsigned)((int)r0.y < (int)7u) & 31u)) && p1) >> (0xffffffffu & 31u));
                        while (i2++ < 7u && 1u) { if (--fuel == 0u) goto done;
                            m0 ^= (a0[u1 & 3u] ^ ((u1 % (9u | 1u)) * 0xffffffffu));
                            h0 = (short)((unsigned)(short)(i2 + g0) * (unsigned)!(0xe2d80f00u + (3u & 8u)));
                            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(signed char)((unsigned)c0 << ((unsigned)(w0 >> 29) & 31u)) & 0x6c905093u), (unsigned)((unsigned)((short)(unsigned)l0 > (signed char)5u) || i1), -(unsigned)(m0 || *q0)); }
                            d0 = d0 * 0.5 + (double)(((unsigned)((int)(unsigned)(r0.x || (a0[u1 & 3u] | u0)) < (int)1u) - g1) & 1023u);
                            u2 += (unsigned)(unsigned char)(i2 % (0x240d33c7u | 1u));
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!((unsigned)h0 | (u0 | u3)), fuel, 0x7fffffffu); }
                        }
                        if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)(short)(*mp & garr[i1 & 7u]) - 0xcfcbfc96u), (unsigned)(i0 && g1), (unsigned)(0x243c3027u || 6u)); }
                        *mp = ((0x10000u & *q0) ? (0x10000u - p0) : 6u);
                    }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)((int)(unsigned)h1 < (int)(3u << (i0 & 31u))), 2u, 0xffffffffu); }
            } else {
                do { if (--fuel == 0u) goto done;
                    if (~(unsigned)((int)i2 < (int)(unsigned)f0)) {
                        while (i2++ < 5u && (unsigned)(3u < 0x10000u)) { if (--fuel == 0u) goto done;
                            v0 = ((unsigned)((int)(unsigned)(unsigned char)(unsigned)(u2 < (unsigned)d0) >= (int)(p2 % (*mp | 1u))) & garr[u2 & 7u]);
                            g1 += (unsigned)!(unsigned)((0xffffffffu ? u0 : 0xb96e0d17u) && i1);
                            default: ;
                            h1 = (unsigned short)(h1 + (r0.y >> ((3u - (unsigned)h1) & 31u)));
                            v0 = (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x5b5bf2ccu);
                        }
                        case 4u: ;
                        do { if (--fuel == 0u) goto done;
                            *mp = (unsigned)(g0 && 6u);
                            h1 = (unsigned short)(h1 + ((unsigned)(p1 && (unsigned)s1) << ((unsigned)(4u < g0) & 31u)));
                            break;
                        } while (i2++ < 6u && ((r0.y * 1u) >> (0x8b0df0d0u & 31u)));
                    }
                    h1 = (unsigned short)(h1 + (unsigned)(1u == r0.x));
                    u0 += ((fuel | p0) - p0);
                    break;
                } while (i1++ < 7u && fuel);
                if (p2) continue;
                if ((unsigned)(unsigned char)(8u << ((r0.x >> (0u & 31u)) & 31u))) goto L4;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)(unsigned)h0 >= (int)(unsigned)d0), (v0 + (unsigned)(g1 < (unsigned)c1)), (unsigned)(0x80000000u == m0)); }
            a0[~(r0.y * 8u) & 3u] = (unsigned)c1;
        }
        l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(unsigned)((short)0u > (signed char)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)((unsigned)h0 % (0xffffffffu | 1u)))));
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)m0 > (signed char)4u), -(unsigned)((unsigned)(8u == a0[i0 & 3u]) < 0u), u1); }
    }
    a0[(0xb4fcfa4fu ^ a0[u1 & 3u]) & 3u] = ((v0 >> (1u & 31u)) / ((unsigned)((short)(0x80000000u | i1) > (signed char)p0) | 1u));
    if ((unsigned)(signed char)(r0.y & 7u)) goto done;
    u1 += -(unsigned)(2u < (unsigned)((unsigned)c1 && (unsigned)w0));
    u2 += (2u & ((unsigned)(x0 >> 70) + i2));
    c0 = (unsigned char)((unsigned)((0xffffffffu ^ (unsigned)w0) == u0) ^ 9u);
    if (((unsigned)((int)g0 < (int)0x10000u) - a0[u1 & 3u])) {
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)d0 < u1), p0, (0xaae2c783u + 0x80000000u)); }
        if ((unsigned)((int)u2 < (int)fuel)) goto L1;
        goto L1;
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(signed char)(i1 & 0xdcc7f96eu)) break;
        if (5u) break;
        { unsigned t0; double z0; if (((unsigned)((int)(unsigned)((int)u3 < (int)8u) < (int)(unsigned)b0)) & 1u) { t0 = ((garr[i1 & 7u] + p1) % (i2 | 1u)); z0 = (double)(((unsigned)(u2 && 0x2dacbf7fu)) & 255u); } if (((unsigned)((int)(unsigned)((int)u3 < (int)8u) < (int)(unsigned)b0)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            { unsigned t1; double z1; if ((-(8u * (unsigned)((int)g0 < (int)0xffffffffu))) & 1u) { t1 = (garr[i1 & 7u] + *mp); z1 = (double)((g0) & 255u); } if ((-(8u * (unsigned)((int)g0 < (int)0xffffffffu))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                if (garr[i1 & 7u]) break;
                if ((unsigned)((short)(unsigned)(0xddd50541u == (unsigned)l0) > (signed char)a0[u1 & 3u])) goto L3;
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(short)(unsigned)((unsigned)((int)(unsigned)l0 >= (int)v0) && p2), (unsigned)((int)(*mp << (*mp & 31u)) >= (int)a0[u1 & 3u]), ~((unsigned)(short)(unsigned)(4u || 0x3f44d383u) >> (p1 & 31u))); }
                l0 = (long)((unsigned long)l0 + (unsigned)((a0[i0 & 3u] % (0xe0dda36cu | 1u)) == (u0 & (unsigned)w0)));
                do { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + garr[i1 & 7u];
                    u2 ^= ((unsigned)(g1 && 0x85437f17u) + (unsigned)(0x176aa52au && (g1 << ((unsigned)s1 & 31u))));
                    g0 = (unsigned)((p1 / (0x7fffffffu | 1u)) && (8u - (unsigned)b0));
                } while (i1++ < 6u && (unsigned)((short)0xffffffffu > (signed char)r0.y));
                if ((*mp + (unsigned)l0)) break;
            }
            if ((unsigned)(0x10000u == 1u)) break;
            if ((unsigned)h0) break;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(signed char)(0x10000u * (unsigned)((int)0x198df931u >= (int)p2)), fuel, a0[u1 & 3u]); }
            if (((unsigned)((int)*q0 < (int)a0[u1 & 3u]) - (unsigned)b0)) goto L2;
            garr[((unsigned)h0 / (0x80000000u | 1u)) & 7u] = (unsigned)((unsigned)((unsigned)(v0 < p0) && (unsigned)e0) && ~(i0 / (g0 | 1u)));
        }
        continue; (void)(0x55f50aedu);
        if ((unsigned)((int)(unsigned)s1 < (int)8u)) {
            { unsigned t2; double z2; if (((unsigned)((int)(unsigned)(6u && (unsigned)x0) >= (int)i0)) & 1u) { t2 = (0x80000000u >> (r0.y & 31u)); z2 = (double)(((((unsigned)(w0 >> 29) % (u0 | 1u)) & (unsigned)s0)) & 255u); } if (((unsigned)((int)(unsigned)(6u && (unsigned)x0) >= (int)i0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                v0 = (unsigned)((int)(unsigned)e0 >= (int)(unsigned)(0x7fffffffu || (unsigned)s0));
                if ((unsigned)!((unsigned)x0 / ((unsigned)b0 | 1u))) break;
                if (budget != 0u) { budget -= 1u; u2 = fn1(9u, (unsigned)(signed char)((unsigned)c1 >> (i0 & 31u)), (unsigned)d0); }
                u2 += (unsigned)((int)0xd1c8d3b7u < (int)(unsigned)(short)(unsigned)((int)(unsigned)((int)p2 >= (int)(unsigned)s0) < (int)(unsigned)(*mp < 9u)));
            }
            v0 = (unsigned)(p0 < (unsigned)(r0.x == (((unsigned)h0 * r0.y) / (garr[i1 & 7u] | 1u))));
            w0 ^= (unsigned long long)0x10000u << ((unsigned)(short)(unsigned)((short)(unsigned)s0 > (signed char)0x1e634242u) & 63u);
        } else {
            u2 ^= (unsigned)((((unsigned)e0 ? fuel : (unsigned)(w0 >> 29)) * (unsigned)b0) || garr[u2 & 7u]);
        }
    }
    u1 = ((unsigned)!((*mp ^ u1) & (unsigned)((int)0x7fffffffu < (int)fuel)) ^ (unsigned)d0);
    if ((unsigned)f0) goto L2;
    l0 = (long)((unsigned long)l0 + p0);
    b0 = (unsigned)((unsigned)s0 || r0.x) != 0u;
    goto L3;
    do { if (--fuel == 0u) goto done;
        *q0 = ((i2 - (i0 & 0xa76d6cc4u)) << ((unsigned)((short)0x1d3f4d07u > (signed char)4u) & 31u));
    } while (i0++ < 6u && (unsigned)((int)(unsigned)h0 < (int)g1));
    s0 = (int)(unsigned)((unsigned)f0 == 3u);
    if ((unsigned)((unsigned)(w0 >> 29) || 0xba5ad7f6u)) goto done;
    h1 = (unsigned short)(h1 + (unsigned)b0);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 2u, 0xc87c76f9u, 0xe0864f7fu },
        { 1u, 0x3f2a3478u, 0x4d41ac63u },
        { 1u, 0x200962d3u, 0xbc742cf6u },
        { 13u, 0x2e0af8afu, 0x3bac6249u },
        { 8u, 0xcdab5f0cu, 0xd64b42b7u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
