// test-ssa-source's program of seed 141000423 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x64e9f851u, g1 = 0x368b5699u;
static unsigned garr[8] = { 0x43cf5c5fu, 0xa6917280u, 0xce1087dbu, 0x21703dbcu, 0x2e3431dbu, 0xeb48d5e4u, 0xf1106e8au, 0xc23f1277u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    d0 = d0 * 0.5 + (double)(m0 & 1023u);
    b0 = (unsigned)((short)(unsigned)b0 > (signed char)((p1 | (unsigned)s1) << ((unsigned)((int)0x7fffffffu >= (int)(unsigned)s1) & 31u))) != 0u;
    goto L3;
    if (fuel) {
        { unsigned t0; double z0; if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(u2 % ((unsigned)h1 | 1u)))) & 1u) { t0 = (0xffffffffu + (unsigned)c0); z0 = (double)((p2) & 255u); } if (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(u2 % ((unsigned)h1 | 1u)))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                u0 += (unsigned)((unsigned)(signed char)(unsigned)((unsigned)f0 && garr[u2 & 7u]) == garr[u2 & 7u]);
                if (0x5165893bu) {
                    goto L4;
                    u3 ^= i1;
                    w0 = w0 * 6364136223846793005ull + (garr[i1 & 7u] + u3);
                }
                do { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)(short)(unsigned)((unsigned)(0x6a40b3d6u < 1u) < (r0.x & (unsigned)((unsigned)s0 == (unsigned)l0))));
                } while (i1++ < 2u && (unsigned)f0);
                *q0 = (garr[i1 & 7u] % (((a0[u1 & 3u] << ((unsigned)s1 & 31u)) - *q0) | 1u));
                do { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        L0: if (--fuel == 0u) goto done;
                    }
                    c1 = (signed char)((unsigned)h0 | (unsigned)h0);
                    u0 = u0 * 0x9e3779b1u + (-(unsigned)(u3 == (unsigned)b0) - 0x7fffffffu);
                    L1: if (--fuel == 0u) goto done;
                    L2: if (--fuel == 0u) goto done;
                } while (i1++ < 4u && ((unsigned)h1 % (0x80000000u | 1u)));
                *mp = (u3 ? -(unsigned)(u1 == v0) : 0x405df8c6u);
            }
        }
        c0 = (unsigned char)((unsigned)((int)(unsigned)h0 < (int)1u) ^ 0xeaa02fd5u);
        L3: if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((unsigned)(0x7fffffffu < u2) & 1023u);
        l0 = (long)((unsigned long)l0 + ((unsigned)!(a0[i0 & 3u] * 0x80000000u) ^ (unsigned)((int)0x10000u < (int)(unsigned)l0)));
        { unsigned t1; double z1; if (((0x985be1c2u - (unsigned)(w0 >> 29))) & 1u) { t1 = (unsigned)!(unsigned)((unsigned)l0 == (unsigned)((int)(unsigned)d0 < (int)r0.x)); z1 = (double)(((unsigned)w0) & 255u); } if (((0x985be1c2u - (unsigned)(w0 >> 29))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            g0 = ((unsigned)x0 + ((unsigned)x0 ^ (unsigned)l0));
            { unsigned t2; double z2; if ((0x10000u) & 1u) { t2 = u3; z2 = (double)(((g1 - (a0[u1 & 3u] ^ 0xffffffffu))) & 255u); } if ((0x10000u) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                f0 = f0 * 0.5f + (float)((6u - -(0u * (unsigned)((unsigned)d0 && *mp))) & 255u);
                goto L0;
                a0[(unsigned)((int)(unsigned)s1 >= (int)g1) & 3u] = (unsigned)((int)(unsigned)!(4u / (0x7fffffffu | 1u)) < (int)0xfcae915du);
                do { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)l0));
                    goto done;
                    if (~(unsigned)((int)(unsigned)((int)0xfaff99a1u >= (int)v0) < (int)0xe38bcabeu)) break;
                } while (i0++ < 6u && (0x10000u ? (unsigned)c0 : (unsigned)w0));
                switch ((3u % ((unsigned)f0 | 1u)) & 7u) {
                    L4: if (--fuel == 0u) goto done;
                }
            }
            if (~((unsigned)f0 % ((unsigned)(signed char)(u3 & garr[i1 & 7u]) | 1u))) goto L4;
        }
    }
    u0 = u0 * 0x9e3779b1u + ((unsigned)((short)(unsigned)d0 > (signed char)0x80000000u) ^ (unsigned)(signed char)(unsigned)(0x694564f7u < (unsigned)s1));
    if ((0x78322297u % (g0 | 1u))) goto L4;
    if ((u2 << (u2 & 31u))) {
        v0 = (p1 >> (g1 & 31u));
    }
    g1 += m0;
    switch ((0x5063eea4u * 0xf1861237u) & 7u) {
        if (i1) {
            case 3u: ;
        } else {
            switch ((unsigned)s0 & 7u) {
                s0 = (int)((unsigned)(2u || (0xffffffffu * i0)) % (u2 | 1u));
                case 1u: ;
                e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)((int)p0 < (int)((unsigned)b0 | (unsigned)s0)) >= (int)((unsigned)(w0 >> 29) * u1)) & 1023u);
                { unsigned t3; double z3; if (((v0 - 0x80000000u)) & 1u) { t3 = 0x10000u; z3 = (double)(((unsigned)(unsigned char)(unsigned)(9u || (unsigned)((short)(unsigned)h1 > (signed char)0x80000000u))) & 255u); } if (((v0 - 0x80000000u)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                    h0 = (short)(0u & (unsigned)x0);
                    while ((r0.y + ((unsigned)x0 - a0[u1 & 3u]))) { if (--fuel == 0u) goto done;
                        u2 = (unsigned)s1;
                        u0 ^= (0xbe9f0680u % ((p1 ? (unsigned)h1 : r0.x) | 1u));
                        if (fuel) continue;
                    }
                }
                case 3u: ;
            }
            if ((i1 & ((unsigned)s1 - v0))) {
                v0 = 0u;
                q0 = &garr[(~(unsigned)(0xffffffffu && (unsigned)h1) - (unsigned)!((unsigned)s1 & i1)) & 7u];
                u1 += (unsigned)((int)0x7fffffffu >= (int)p2);
                h1 = (unsigned short)(h1 + ((unsigned)((p1 + (unsigned)(0x7fffffffu == *mp)) && 0xc0ffa60cu) | 0x31604765u));
                u3 += (5u * (unsigned)((u3 % (*q0 | 1u)) || (unsigned)d0));
                do { if (--fuel == 0u) goto done;
                    if (8u) goto L1;
                    if (((unsigned)b0 & 3u)) continue;
                    if (i2) continue;
                    case 6u: ;
                } while (i0++ < 6u && 0x7e9195dau);
            } else {
                case 0u: ;
                w0 = w0 * 6364136223846793005ull + (unsigned)((*mp >> ((unsigned)s1 & 31u)) && r0.y);
            }
            case 4u: ;
            do { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 5u: ;
                    if ((unsigned)(i0 || 0xb8e4a65u)) continue;
                    if ((unsigned)w0) goto L1;
                    switch ((unsigned)(unsigned char)(r0.y ? (unsigned)s0 : 0x10000u) & 7u) {
                        do { if (--fuel == 0u) goto done;
                            c0 = (unsigned char)((unsigned)s1 * (unsigned)x0);
                        } while (i2++ < 5u && (0x4bd20c46u ^ a0[u1 & 3u]));
                        u0 = ((unsigned)(u1 && fuel) * -((unsigned)(9u < (unsigned)c0) & 7u));
                        q0 = &garr[(unsigned)((int)((unsigned)s0 + (unsigned)(w0 >> 29)) < (int)((unsigned)(0xffffffffu < a0[u1 & 3u]) / (r0.y | 1u))) & 7u];
                    }
                    x0 = x0 * 0x100000001b3ull + p1;
                }
                c0 = (unsigned char)(v0 / (0x23a7f45bu | 1u));
                while (i1++ < 3u && ((0x7fffffffu + 0xddcd9014u) ^ 6u)) { if (--fuel == 0u) goto done;
                    default: ;
                    break;
                    case 2u: ;
                    if ((unsigned)s1) break;
                }
            } while (i0++ < 6u && ((unsigned)l0 >> (((unsigned)e0 & (unsigned)b0) & 31u)));
        }
        case 7u: ;
        h1 = (unsigned short)(h1 + ~(i1 % (0xffffffffu | 1u)));
        q0 = &garr[(*mp | (a0[i0 & 3u] << ((unsigned)(garr[i1 & 7u] == p1) & 31u))) & 7u];
    }
    d0 = d0 * 0.5 + (double)((unsigned)(x0 >> 70) & 1023u);
    if ((g0 % ((unsigned)(p0 && 8u) | 1u))) goto done;
    garr[0x80000000u & 7u] = (unsigned)(9u || (i1 & 3u));
    q0 = &garr[(unsigned)((int)(unsigned)((short)u3 > (signed char)garr[u2 & 7u]) >= (int)v0) & 7u];
    goto L2;
    goto L1;
    while (i0++ < 5u && 0xffffffffu) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (7u) break;
        }
        break; (void)(0x7fffffffu);
    }
    goto L1;
    if (fuel < 8u) return (unsigned)((unsigned)c0 == (unsigned)(a0[u1 & 3u] || (unsigned)d0));
    *q0 += (unsigned)((int)(6u * u1) < (int)(unsigned)(0x80000000u || 0x80000000u));
    if (~(0x7fffffffu | u0)) goto done;
    if ((unsigned)(short)(unsigned)(((unsigned)b0 / (u3 | 1u)) < 0xea989099u)) goto L2;
    g1 += ((p1 / (u2 | 1u)) % (p0 | 1u));
    if (-((6u | i2) / ((unsigned)(x0 >> 70) | 1u))) goto L1;
    *q0 += (unsigned)(((unsigned)((unsigned)s0 == ((unsigned)f0 & g1)) & g0) == a0[i0 & 3u]);
    if ((unsigned)((unsigned)!(2u % ((unsigned)s0 | 1u)) || 0x981172ebu)) goto L0;
    a0[garr[i1 & 7u] & 3u] = (unsigned)((unsigned)(g1 < 0xffffffffu) < (unsigned)c1);
    if (((unsigned)(u2 < i2) % (0x48c76b52u | 1u))) goto L4;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)s1) break;
        if ((i0 << (fuel & 31u))) break;
    }
    { unsigned t4; double z4; if ((fuel) & 1u) { t4 = (unsigned)s0; z4 = (double)((((unsigned)c1 + u2)) & 255u); } if ((fuel) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        m0 ^= (unsigned)((fuel * (m0 | 0xed14dfceu)) && g0);
        g1 += ((unsigned)!(unsigned)(p2 < p1) ^ ((unsigned)s1 * (unsigned)((short)fuel > (signed char)u0)));
        if (((unsigned)c0 & (unsigned)((short)0x10000u > (signed char)a0[u1 & 3u]))) {
            for (;;) { if (--fuel == 0u) goto done;
                if ((1u >> (((unsigned)s0 % (p2 | 1u)) & 31u))) break;
                if ((unsigned)s0) break;
                break; (void)((3u << ((unsigned)((int)0x1ca6966cu < (int)*mp) & 31u)));
                m0 ^= ((p1 | 1u) / ((unsigned)d0 | 1u));
                f0 = f0 * 0.5f + (float)((unsigned)(0x5ebceffeu == (unsigned)((int)v0 >= (int)(0x10000u ? 0xb1688961u : fuel))) & 255u);
                *mp = 0xecbb3cb3u;
            }
            if (4u) goto done;
            s1 = (int)((unsigned)s1 + u3);
            m0 ^= ((~(6u ? 0xa4025618u : 5u) << (i1 & 31u)) << (g0 & 31u));
            { unsigned t5; double z5; if ((u2) & 1u) { t5 = p2; z5 = (double)(((unsigned)(i0 || (unsigned)h0)) & 255u); } if ((u2) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                if ((unsigned)((unsigned)(signed char)(p0 | p0) || p2)) goto L1;
                if (~((u2 * garr[i1 & 7u]) * m0)) goto L1;
                f0 = f0 * 0.5f + (float)((unsigned)(i1 < ((unsigned)s1 + (9u ? (unsigned)c0 : (unsigned)d0))) & 255u);
                u0 += (unsigned)((short)(0x7fffffffu | ((unsigned)f0 ^ v0)) > (signed char)0x10000u);
                *mp = ((unsigned)e0 * (0x8d3d4a3eu & (0x80000000u + 0x74bd086fu)));
            }
            *q0 = (unsigned)!(unsigned)((int)0x7fffffffu < (int)0xf3680670u);
        } else {
            v0 = ((0xffffffffu << ((unsigned)s1 & 31u)) + (unsigned)d0);
            h1 = (unsigned short)(h1 + (unsigned)(short)(0x10000u * (unsigned)((unsigned)(w0 >> 29) == (unsigned)h0)));
            goto L0;
        }
        u2 ^= (unsigned)((int)(garr[i1 & 7u] ^ ((unsigned)s1 * garr[i1 & 7u])) < (int)(unsigned)!(unsigned)((int)(unsigned)s1 >= (int)(unsigned)s0));
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        garr[*q0 & 7u] = (unsigned)b0;
        q0 = &garr[(unsigned)!((unsigned)((short)(unsigned)b0 > (signed char)(a0[i0 & 3u] & (unsigned)l0)) | ((unsigned)h1 + (unsigned)l0)) & 7u];
        switch ((unsigned)h1 & 7u) {
            garr[r0.y & 7u] = (unsigned)((unsigned)(i2 || ((unsigned)((short)u0 > (signed char)v0) * *mp)) == 4u);
            v0 = ((u2 ^ 2u) * u0);
            s1 = (int)((unsigned)s1 + ((unsigned)(short)(unsigned)((int)(unsigned)d0 < (int)0xc639f801u) & (unsigned)l0));
        }
    }
    c1 = (signed char)(unsigned)((unsigned)b0 < 4u);
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (((*q0 | (unsigned)h0) * 9u) & 7u) {
            q0 = &garr[(unsigned)!(unsigned)((int)0x95daa711u >= (int)(unsigned)h1) & 7u];
            do { if (--fuel == 0u) goto done;
                case 6u: ;
                if ((unsigned)((short)3u > (signed char)g1)) break;
                case 0u: ;
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(short)((g0 + a0[i0 & 3u]) ^ (unsigned)e0)) goto L1;
                }
            } while (i1++ < 3u && (8u ^ (unsigned)(w0 >> 29)));
            case 7u: ;
            goto L2;
            case 5u: ;
        }
        w0 = w0 * 6364136223846793005ull + -(unsigned)(p0 && (unsigned)f0);
        d0 = d0 * 0.5 + (double)((garr[u2 & 7u] | (unsigned)c0) & 1023u);
    }
    h1 = (unsigned short)(h1 + (unsigned)(signed char)((unsigned)((unsigned)x0 == 0xa69a4f21u) - 0xd8a88355u));
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t6; double z6; if (((unsigned)((unsigned)(u1 == m0) || u1)) & 1u) { t6 = 0x56c67057u; z6 = (double)(((unsigned)(short)(0xffffffffu | (*mp & 1u))) & 255u); } if (((unsigned)((unsigned)(u1 == m0) || u1)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
            if ((p0 | (*q0 >> (4u & 31u)))) {
                e0 = e0 * 0.5L + (long double)(garr[i1 & 7u] & 1023u);
                r0.x = (unsigned)h1;
                q0 = &garr[0x10000u & 7u];
                w0 ^= (unsigned long long)a0[i0 & 3u] << ((0xffffffffu * -(unsigned)((int)(p2 << ((unsigned)c1 & 31u)) < (int)(unsigned)x0)) & 63u);
                r0.x = ((unsigned)((short)garr[u2 & 7u] > (signed char)0x7fffffffu) & 0xd1d869bu);
            } else {
                if ((unsigned)(short)((*q0 - r0.x) | (unsigned)h1)) break;
            }
            garr[(unsigned)e0 & 7u] = (0x80000000u ? u2 : 0x10000u);
            w0 ^= (unsigned long long)0x80000000u << (((unsigned)!(0x34c2f6efu ? p0 : v0) - (v0 | 0xd37bc08eu)) & 63u);
            *mp = 8u;
            if (a0[u1 & 3u]) break;
            if ((unsigned)(~(garr[u2 & 7u] | (unsigned)b0) < 0x7fffffffu)) break;
        }
    }
    if (0u) goto L2;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + ((unsigned)h1 >> (7u & 31u)));
        garr[p0 & 7u] = 0x80000000u;
        v0 = (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)b0);
    }
    s1 = (int)((unsigned)s1 + 8u);
    if ((((unsigned)f0 >> (5u & 31u)) * 0xaaa21edeu)) goto L4;
    goto L4;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)(0x10000u ? (unsigned)x0 : (7u << ((unsigned)(w0 >> 29) & 31u)));
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            goto L1;
            w0 = w0 * 6364136223846793005ull + ((unsigned)x0 + 0x72516db6u);
            s0 = (int)((unsigned)e0 << (p2 & 31u));
        }
        while (i1++ < 3u && (unsigned)((unsigned)e0 < a0[i0 & 3u])) { if (--fuel == 0u) goto done;
            if (fuel) break;
            u2 = u2 * 0x9e3779b1u + r0.x;
        }
    }
    while (i0++ < 3u && (unsigned)((int)u3 < (int)0xffffffffu)) { if (--fuel == 0u) goto done;
        *q0 += ~(unsigned)((unsigned)h0 == (unsigned)(unsigned char)(0x48220feeu << (((unsigned)(x0 >> 70) + (unsigned)(x0 >> 70)) & 31u)));
        if ((v0 + 0xaed9b4cdu)) {
            break; (void)((i2 * i2));
            if (((unsigned)c1 << (u0 & 31u))) break;
            if ((unsigned)((unsigned)(short)(g0 & (unsigned)l0) && (unsigned)b0)) {
                v0 = 0x20d52e54u;
                if ((3u % (a0[u1 & 3u] | 1u))) break;
                r0.y ^= (unsigned)((int)(unsigned)s0 >= (int)((unsigned)(g1 < a0[u1 & 3u]) ^ 0xa3b5d6c4u));
                u1 += ((unsigned)((int)((unsigned)s0 / (p1 | 1u)) >= (int)u3) - (unsigned)(short)(unsigned)((int)*q0 < (int)(unsigned)h1));
                if ((unsigned)((short)9u > (signed char)(unsigned)((int)0x362f093fu >= (int)(unsigned)x0))) goto L0;
                f0 = f0 * 0.5f + (float)((((unsigned)c1 & (unsigned)d0) + (unsigned)((unsigned)!(unsigned)((int)8u < (int)4u) < 2u)) & 255u);
            }
            goto L4;
        }
        if (u3 == 7u) return (unsigned)((short)(garr[u2 & 7u] >> ((unsigned)((unsigned)c0 == g1) & 31u)) > (signed char)(unsigned)(r0.y == garr[i1 & 7u]));
        switch ((unsigned)w0 & 7u) {
            if (p2) {
                if (garr[u2 & 7u]) {
                    case 1u: ;
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)(4u == 0xdeb2d6f4u);
                if ((g1 | (p2 ^ (unsigned)b0))) {
                    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)x0 < (unsigned)h0);
                    s0 = (int)g1;
                    q0 = &garr[(3u & 3u) & 7u];
                    *q0 += (0x619dd3bau ? (r0.y | (unsigned)b0) : (unsigned)h1);
                } else {
                    if ((unsigned)((unsigned)e0 == ((unsigned)f0 | i1))) continue;
                }
                case 7u: ;
            } else {
                default: ;
                if (*q0) {
                    s0 = (int)(unsigned)((unsigned)f0 || (garr[u2 & 7u] << ((unsigned)s0 & 31u)));
                    continue; (void)((unsigned)((short)r0.x > (signed char)6u));
                    if (~(unsigned)((unsigned)(0x7fffffffu || i2) && 0x6759d0a0u)) break;
                    if ((0xd640432eu ? 0xffffffffu : 1u)) goto L2;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)(0x73dea0e4u < (unsigned)s1)) {
                            *mp = (unsigned)(0x12d9437u || ((unsigned)b0 >> (u0 & 31u)));
                            *mp = (unsigned)((short)0x7fffffffu > (signed char)(unsigned)s1);
                            h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)f0 > (signed char)(unsigned)x0));
                        } else {
                            u2 = u2 * 0x9e3779b1u + (0x9bda3fabu ? (0x8686e905u >> (u1 & 31u)) : 1u);
                            if (fuel < 8u) return ((unsigned)s1 * (unsigned)((int)(unsigned)((int)p0 < (int)(unsigned)(8u && 0x7fffffffu)) < (int)a0[i0 & 3u]));
                            s0 = (int)~(p0 ? (unsigned)((short)0x5e44790bu > (signed char)3u) : (garr[i1 & 7u] - m0));
                        }
                        u3 += (unsigned)h0;
                        s0 = (int)(unsigned)e0;
                        f0 = f0 * 0.5f + (float)(r0.y & 255u);
                        if ((unsigned)d0) continue;
                        s0 = (int)(unsigned)((short)((v0 % ((unsigned)((int)r0.y >= (int)(unsigned)d0) | 1u)) >> (p0 & 31u)) > (signed char)0xffffffffu);
                    } while (i1++ < 6u && (unsigned)(garr[i1 & 7u] && (0xbecd47eeu | 0xffffffffu)));
                } else {
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        h0 = (short)(unsigned)c1;
                        case 4u: ;
                        u1 = (unsigned)((unsigned)(x0 >> 70) == ~(unsigned)((int)v0 >= (int)0x80000000u));
                        break;
                    }
                    case 5u: ;
                    break;
                    f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)(u2 && u0) < (int)(unsigned)((short)u0 > (signed char)g0)) & 255u);
                }
                if (u3 == 7u) return (unsigned)!(((unsigned)((int)0x10b66aaeu >= (int)*mp) >> ((u0 - (unsigned)h1) & 31u)) ^ (unsigned)l0);
                *q0 += 0x99a3fa6eu;
            }
            goto L4;
            w0 ^= (unsigned long long)((unsigned)c1 >> (0xe1971d09u & 31u)) << (garr[i1 & 7u] & 63u);
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)s0) continue;
                if (v0) {
                    r0.y ^= ((unsigned)d0 % (1u | 1u));
                    e0 = e0 * 0.5L + (long double)(((unsigned)((short)g0 > (signed char)a0[u1 & 3u]) ^ (unsigned)(9u || i0)) & 1023u);
                    f0 = f0 * 0.5f + (float)(-(unsigned)(*mp == (unsigned)(short)(r0.x << (0x18f5bab1u & 31u))) & 255u);
                    if ((0xd1de148cu ? u3 : *mp)) continue;
                    if (p2) {
                        break;
                        break; (void)((unsigned)((int)(unsigned)f0 < (int)garr[u2 & 7u]));
                        g1 += (unsigned)(w0 >> 29);
                    } else {
                        s0 = (int)((unsigned)(w0 >> 29) & (unsigned)f0);
                        while (i2++ < 6u && (unsigned)((short)5u > (signed char)garr[u2 & 7u])) { if (--fuel == 0u) goto done;
                            case 6u: ;
                        }
                        *mp = (unsigned)((unsigned)s0 && 1u);
                    }
                    goto L4;
                } else {
                    e0 = e0 * 0.5L + (long double)((unsigned)(0x10000u < i1) & 1023u);
                    if ((unsigned)(w0 >> 29)) break;
                    c0 = (unsigned char)((unsigned)c0 * (unsigned)!(fuel | (unsigned)x0));
                }
                break;
            }
            m0 ^= (r0.x * ((a0[u1 & 3u] ^ 0x4c2d3c09u) & (unsigned)((unsigned)s0 && 0x80000000u)));
            *q0 = (unsigned)(short)(unsigned)(3u == 0x31b70d5bu);
        }
    }
    h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)(0x629b8d98u < 5u) > (signed char)(0xf03c77e1u / ((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)h0) | 1u))));
    { unsigned t7; double z7; if ((p0) & 1u) { t7 = (unsigned)d0; z7 = (double)((0x7e2d00fu) & 255u); } if ((p0) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
        if ((unsigned)((short)p0 > (signed char)(unsigned)((int)g0 < (int)p2))) goto L1;
        if ((unsigned)((0xffffffffu % ((unsigned)s0 | 1u)) == fuel)) goto L4;
        if ((i2 >> (0xffffffffu & 31u))) {
            g0 = (unsigned)((0u << (0x80000000u & 31u)) == 0x918ae769u);
            if (r0.x) goto L3;
            if (fuel < 8u) return (r0.y ? (unsigned)(short)(0xffffffffu ^ (unsigned)c1) : 0xe4b9fcd2u);
            w0 ^= (unsigned long long)i1 << ((unsigned)((int)0u >= (int)0x10000u) & 63u);
        } else {
            x0 = x0 * 0x100000001b3ull + (0x70463621u ^ (unsigned)d0);
            h0 = (short)(unsigned)((unsigned)((unsigned)s1 == ((unsigned)(w0 >> 29) - (unsigned)h0)) == i1);
        }
        if ((unsigned)((int)(unsigned)l0 < (int)(unsigned)(unsigned char)(unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)x0))) {
            switch (garr[i1 & 7u] & 7u) {
                { unsigned t8; double z8; if (((unsigned)((short)(unsigned)d0 > (signed char)(p0 ^ a0[i0 & 3u]))) & 1u) { t8 = (unsigned)(2u && (unsigned)((int)u2 < (int)m0)); z8 = (double)((0x10000u) & 255u); } if (((unsigned)((short)(unsigned)d0 > (signed char)(p0 ^ a0[i0 & 3u]))) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                    l0 = (long)((unsigned long)l0 + m0);
                    w0 ^= (unsigned long long)i0 << (((unsigned)l0 - ((unsigned)((int)0x379a8db2u < (int)(unsigned)((unsigned)(w0 >> 29) < (unsigned)f0)) & (unsigned)s1)) & 63u);
                    case 5u: ;
                    case 3u: ;
                    case 4u: ;
                    while (i0++ < 5u && ((unsigned)l0 + (unsigned)d0)) { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + (garr[i1 & 7u] * ((unsigned)((unsigned)h1 || u3) - (a0[u1 & 3u] - (unsigned)c0)));
                        w0 = w0 * 6364136223846793005ull + ~(i1 << ((0xffffffffu >> (((4u >> (v0 & 31u)) - r0.x) & 31u)) & 31u));
                    }
                }
            }
            if ((unsigned)h1) goto L4;
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)(u0 || 1u) ^ a0[u1 & 3u])) break;
            }
        }
    }
    f0 = f0 * 0.5f + (float)((0x410f995cu ^ (unsigned)(signed char)(unsigned)((short)(v0 * 0x10000u) > (signed char)0x80000000u)) & 255u);
    do { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)e0);
        c0 = (unsigned char)(unsigned)((unsigned)((short)m0 > (signed char)(unsigned)e0) && (8u >> ((unsigned)((unsigned)b0 || 0x41aa4cddu) & 31u)));
        l0 = (long)((unsigned long)l0 + (((unsigned)c0 % (0x8d51e40eu | 1u)) / (((unsigned)s0 << (0x4d5849d9u & 31u)) | 1u)));
        if (u1) break;
    } while (i0++ < 6u && (a0[u1 & 3u] % ((0x88e817abu * 0u) | 1u)));
    a0[(unsigned)s0 & 3u] = (((unsigned)e0 + 0x80000000u) ^ (unsigned)w0);
    g1 += 4u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while (i0++ < 2u && (garr[u2 & 7u] % ((unsigned)c0 | 1u))) { if (--fuel == 0u) goto done;
        if ((unsigned)(unsigned char)(0xffffffffu | 0xd91144b0u)) goto done;
    }
    g1 += (unsigned)((int)(unsigned)((int)((0x9f8e98eau ^ 5u) * 0u) >= (int)garr[u2 & 7u]) < (int)(unsigned)c0);
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)(x0 >> 70) >= (int)p2);
    if ((m0 | (unsigned)(0x7fffffffu && 0x80000000u))) {
        s1 = (int)((unsigned)s1 + (6u * (8u + ~(~(unsigned)((short)(unsigned)x0 > (signed char)r0.y) >> (0x407adaabu & 31u)))));
        a0[r0.y & 3u] = -((unsigned)(0xf4f6805fu && (0x65013764u + p0)) | v0);
        x0 = x0 * 0x100000001b3ull + 4u;
    } else {
        if ((unsigned)(signed char)(8u * m0)) goto L4;
        v0 = ((unsigned)h0 & -(((unsigned)e0 & u2) / (9u | 1u)));
        goto L1;
    }
    c1 = (signed char)(unsigned)((unsigned)(0xe0e3f274u || u1) || 0x58d31d7du);
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(signed char)(((unsigned)b0 ^ (unsigned)c0) >> (0x94e90827u & 31u)), -(a0[i0 & 3u] & i1), 3u); }
    if (r0.x) goto L1;
    goto L0;
    for (;;) { if (--fuel == 0u) goto done;
        g1 += (unsigned)((short)((unsigned)((short)g0 > (signed char)(unsigned)x0) % (i2 | 1u)) > (signed char)0xcfacafb7u);
        while (i1++ < 4u && ((unsigned)(x0 >> 70) % (0xefaa72eeu | 1u))) { if (--fuel == 0u) goto done;
            g0 = 7u;
            x0 = x0 * 0x100000001b3ull + (unsigned)(i1 == i0);
            if (budget != 0u) { budget -= 1u; u0 = fn0((a0[i0 & 3u] + garr[u2 & 7u]), (unsigned)!(unsigned)((short)0xfe2062fau > (signed char)(unsigned)((int)6u < (int)g0)), (0x7e774c77u | (unsigned)w0)); }
            if (((0x202fe844u & (unsigned)w0) / ((unsigned)h0 | 1u))) goto L0;
            switch ((unsigned)((int)0x9997e255u < (int)0x7fffffffu) & 7u) {
                v0 = (unsigned)((int)i0 < (int)(unsigned)((unsigned)(signed char)(unsigned)((unsigned)s1 || 1u) == i1));
                u0 ^= (unsigned)((int)i2 >= (int)(u2 & u2));
                if ((0x80000000u / (0x10000u | 1u))) goto L2;
                L0: if (--fuel == 0u) goto done;
                if (p1) break;
            }
            if ((g0 + 3u)) goto done;
        }
        u1 = u1 * 0x9e3779b1u + ((unsigned)l0 / ((unsigned)(signed char)(unsigned)(0x7fffffffu == (0xd283141eu / (0x80000000u | 1u))) | 1u));
        if ((unsigned)f0) break;
        do { if (--fuel == 0u) goto done;
            if (0x43a54524u) {
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(w0 >> 29) - (a0[u1 & 3u] >> ((unsigned)f0 & 31u))), (0x7fffffffu % (0xffffffffu | 1u)), (unsigned)(x0 >> 70)); }
                { unsigned t0; double z0; if ((u1) & 1u) { t0 = (~(p0 - 0x80000000u) | 0xe2f9fd36u); z0 = (double)(((unsigned)((short)g0 > (signed char)u2)) & 255u); } if ((u1) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                    u2 = ((unsigned)l0 * p1);
                    if (~((unsigned)h0 | (unsigned)b0)) break;
                    x0 = x0 * 0x100000001b3ull + 9u;
                }
                v0 = (unsigned)(i0 && ((unsigned)(p0 < p2) * 7u));
            } else {
                s0 = (int)*mp;
                if (budget != 0u) { budget -= 1u; u2 = fn0((i2 << (u0 & 31u)), ((unsigned)h0 ^ p1), (unsigned)((int)i1 >= (int)garr[i1 & 7u])); }
            }
            a0[((unsigned)(x0 >> 70) & (unsigned)w0) & 3u] = (unsigned)(0xffffffffu && (unsigned)((unsigned)((int)*mp >= (int)0x10000u) == (unsigned)(short)(p1 << (p1 & 31u))));
            L1: if (--fuel == 0u) goto done;
        } while (i1++ < 6u && (i1 + (unsigned)(*mp && (unsigned)e0)));
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)b0 >= (int)(unsigned)(w0 >> 29)), ((u3 ^ garr[i1 & 7u]) ^ 0xf872dd0cu), (unsigned)(unsigned char)((unsigned)w0 + g1)); }
    }
    if ((unsigned)((int)(unsigned)s0 < (int)p2)) goto done;
    switch ((unsigned)(fuel || 0xc277a033u) & 7u) {
        while (i0++ < 3u && (unsigned)!(unsigned)((int)(unsigned)e0 < (int)(0x10000u + garr[i1 & 7u]))) { if (--fuel == 0u) goto done;
            u1 ^= 3u;
            x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)((int)3u >= (int)a0[u1 & 3u]) > (signed char)(unsigned)((unsigned)(signed char)(garr[i1 & 7u] / ((unsigned)(x0 >> 70) | 1u)) == a0[i0 & 3u]));
            goto done;
            i0 = (unsigned)((5u * 0x7bd94188u) || (m0 | (unsigned)(signed char)(garr[u2 & 7u] % ((unsigned)(x0 >> 70) | 1u)))) & 15u;
            if (p0) goto L3;
            if (2u) goto L1;
        }
        case 0u: ;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)w0, (unsigned)((int)(unsigned)(signed char)(r0.y % ((unsigned)c0 | 1u)) >= (int)9u), (unsigned)(r0.x < a0[i0 & 3u])); }
    }
    if (*mp) goto done;
    if ((unsigned)s0) goto L4;
    g0 = (u3 ^ (unsigned)((0x80000000u << (u3 & 31u)) && r0.y));
    goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)0xffffffffu > (signed char)(unsigned)((int)0x7fffffffu < (int)(unsigned)c1)), (unsigned)h0, (unsigned)(signed char)(0xe2f5fcc8u - v0)); }
    s0 = (int)(unsigned)((unsigned)(garr[u2 & 7u] || i2) || (unsigned)l0);
    r0.x = (unsigned)((unsigned)x0 && (((unsigned)(w0 >> 29) << ((unsigned)s0 & 31u)) | a0[i0 & 3u]));
    h0 = (short)4u;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        L2: if (--fuel == 0u) goto done;
    }
    if ((unsigned)((unsigned)h1 || 3u)) goto L4;
    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)x0 * 8u), (unsigned)((short)-(u0 << (7u & 31u)) > (signed char)(unsigned)(x0 >> 70)), (0x7fffffffu / ((1u % ((unsigned)b0 | 1u)) | 1u))); }
    L3: if (--fuel == 0u) goto done;
    if ((unsigned)((unsigned)h1 || 0xffffffffu)) goto done;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0((i2 % (5u | 1u)), (unsigned)(x0 >> 70), (unsigned)((unsigned)s1 || u0)); }
        if ((unsigned)(m0 < 7u)) goto L1;
    } while (i0++ < 5u && (unsigned)(w0 >> 29));
    { unsigned t1; double z1; if ((((9u << ((unsigned)d0 & 31u)) % (5u | 1u))) & 1u) { t1 = (unsigned)(0xffffffffu < (unsigned)d0); z1 = (double)(((0x35c2ca68u & p1)) & 255u); } if ((((9u << ((unsigned)d0 & 31u)) % (5u | 1u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0(0xa7f152c5u, (unsigned)b0, 0x10000u); }
        }
        goto L0;
    }
L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)((int)0x7fffffffu < (int)p1)) goto L0;
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)s1 || p2), (0xc7e0403eu & (unsigned)((unsigned)h1 && (unsigned)s0)), 9u); }
    if ((g0 - (unsigned)!(fuel << (r0.x & 31u)))) {
        u1 = u1 * 0x9e3779b1u + 0x45a091fdu;
    } else {
        L0: if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(i0 + (unsigned)h0));
        { unsigned t0; double z0; if (((unsigned)w0) & 1u) { t0 = ((unsigned)(w0 >> 29) % ((unsigned)((int)0x80000000u < (int)(unsigned)f0) | 1u)); z0 = (double)((1u) & 255u); } if (((unsigned)w0) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            L1: if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)(unsigned char)(((unsigned)(short)(unsigned)(u1 && 0xffffffffu) / (v0 | 1u)) * (0u << (p2 & 31u)));
            while (i0++ < 5u && (fuel >> ((unsigned)(i1 == (unsigned)x0) & 31u))) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    u0 = u0 * 0x9e3779b1u + (unsigned)(((m0 % ((unsigned)s1 | 1u)) * (unsigned)f0) && i0);
                    m0 ^= (0x7fffffffu | ((0x7fffffffu / (0x7fffffffu | 1u)) - (unsigned)s0));
                    for (;;) { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)(((unsigned)((short)(1u ^ (unsigned)s0) > (signed char)(0x80000000u % ((unsigned)c0 | 1u))) | g0) & 255u);
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)e0, u2, (garr[i1 & 7u] ? (unsigned)l0 : (unsigned)h0)); }
                        goto L2;
                    }
                    *q0 += ((unsigned)((short)0xb5ffac31u > (signed char)0x10000u) % (a0[i0 & 3u] | 1u));
                    s0 = (int)(0u << (((unsigned)s0 - p2) & 31u));
                    while (i2++ < 5u && ((unsigned)(signed char)((unsigned)x0 | a0[i0 & 3u]) << ((unsigned)h1 & 31u))) { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)((unsigned)(short)(unsigned)(((unsigned)d0 >> (u0 & 31u)) && (a0[i0 & 3u] * (unsigned)s1)) & 1023u);
                        break; (void)(~(unsigned)((int)(unsigned)f0 >= (int)((unsigned)l0 >> (0x10000u & 31u))));
                    }
                }
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)x0) break;
                    b0 = (unsigned)!(((unsigned)f0 % (*mp | 1u)) | *mp) != 0u;
                    L2: if (--fuel == 0u) goto done;
                    if (0x99f722eu) break;
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)d0;
                L3: if (--fuel == 0u) goto done;
                garr[(unsigned)((unsigned)c1 == 0x7fffffffu) & 7u] = garr[u2 & 7u];
            }
        }
    }
    if ((unsigned)((i2 & 0u) == 4u)) {
        goto L1;
    }
    if (*q0) {
        { unsigned t1; double z1; if (((fuel + ((unsigned)h0 >> (a0[u1 & 3u] & 31u)))) & 1u) { t1 = (unsigned)h0; z1 = (double)(((unsigned)(((unsigned)f0 * (unsigned)d0) == fuel)) & 255u); } if (((fuel + ((unsigned)h0 >> (a0[u1 & 3u] & 31u)))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)(signed char)(i0 >> (r0.y & 31u)) && (unsigned)f0)) break;
            } while (i0++ < 6u && (-((unsigned)d0 * 0xffffffffu) << (u0 & 31u)));
        }
        w0 ^= (unsigned long long)(unsigned)(0x80000000u || i0) << (((0x10000u * (unsigned)l0) | r0.y) & 63u);
    } else {
        u0 ^= (0x7fffffffu / ((p1 / ((0x3e7db49au - i0) | 1u)) | 1u));
        if ((unsigned)((int)(unsigned)((unsigned)l0 < v0) >= (int)u1)) goto L0;
    }
    switch ((0x50966b9au >> ((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)(x0 >> 70)) & 31u)) & 7u) {
        m0 ^= r0.y;
        switch ((unsigned)((int)7u < (int)(unsigned)((unsigned)c0 && 0x87a8578eu)) & 7u) {
            x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)e0 < g0) & (unsigned)((short)*q0 > (signed char)(unsigned)(x0 >> 70)));
            if ((garr[i1 & 7u] | (unsigned)x0)) break;
        }
        case 3u: ;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)h0, (unsigned)e0, (unsigned)((unsigned)w0 && 0x7fffffffu)); }
            c1 = (signed char)(unsigned)((unsigned)!((u2 - *mp) - (unsigned)l0) < (unsigned)(signed char)(unsigned)((int)6u >= (int)(unsigned)b0));
            if ((unsigned)c1) goto L3;
        } while (i0++ < 4u && (unsigned)((int)6u < (int)(v0 << (u3 & 31u))));
    }
    do { if (--fuel == 0u) goto done;
        switch (((unsigned)!(u1 ^ 0x10000u) >> ((unsigned)b0 & 31u)) & 7u) {
            u0 += (unsigned)b0;
        }
        while (i1++ < 2u && ((unsigned)w0 | i1)) { if (--fuel == 0u) goto done;
            if ((i0 / ((g1 % ((unsigned)(w0 >> 29) | 1u)) | 1u))) {
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)f0, (unsigned)(0u && (unsigned)(4u == (unsigned)x0)), (0x53fdae79u | (v0 >> (0xffffffffu & 31u)))); }
                *mp = (unsigned)e0;
            } else {
                if (((unsigned)((int)i1 >= (int)a0[u1 & 3u]) >> (v0 & 31u))) break;
                b0 = (unsigned)((short)~((unsigned)(w0 >> 29) << (u0 & 31u)) > (signed char)(g0 / (9u | 1u))) != 0u;
                if ((unsigned)(0x53f06058u && (unsigned)s1)) continue;
                switch (*mp & 7u) {
                    h0 = (short)(unsigned)(1u && (r0.y - (unsigned)f0));
                    x0 = x0 * 0x100000001b3ull + ((0xffffffffu | (0x80000000u & (unsigned)(x0 >> 70))) ^ (0x3975dc6bu >> (1u & 31u)));
                }
            }
            while (i2++ < 2u && ((unsigned)e0 * (unsigned)d0)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0(((r0.y | (unsigned)s1) & g0), (*q0 & (unsigned)(a0[i0 & 3u] || (unsigned)h0)), (g1 ? fuel : (unsigned)h1)); }
                if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(i1 < (unsigned)w0) - 2u), (0xe3a4dffu - (unsigned)!(fuel * 0x7fffffffu)), (unsigned)((unsigned)e0 && p2)); }
            }
            if (((unsigned)b0 | 0xc4196c12u)) continue;
        }
    } while (i0++ < 5u && (unsigned)!(unsigned)(m0 || a0[i0 & 3u]));
    u0 = u0 * 0x9e3779b1u + ((unsigned)l0 / ((u0 / (0x80000000u | 1u)) | 1u));
    garr[((unsigned)b0 + 2u) & 7u] = (unsigned)(short)((unsigned)(0x9587ed44u && (unsigned)((short)(unsigned)b0 > (signed char)p1)) * (unsigned)((int)(unsigned)h0 >= (int)(unsigned)(x0 >> 70)));
    d0 = d0 * 0.5 + (double)((unsigned)((short)g1 > (signed char)(unsigned)h1) & 1023u);
    *q0 += (unsigned)((unsigned)((short)(p2 >> ((unsigned)s0 & 31u)) > (signed char)(0x7fffffffu % ((unsigned)d0 | 1u))) || 5u);
    if ((v0 ^ g0)) goto done;
    d0 = d0 * 0.5 + (double)(((unsigned)(unsigned char)(unsigned)((int)(unsigned)h0 < (int)*q0) + (unsigned)(short)(g0 >> (p0 & 31u))) & 1023u);
    u1 = u1 * 0x9e3779b1u + -((unsigned)h0 << (0x7fffffffu & 31u));
    if (budget != 0u) { budget -= 1u; u0 = fn1((7u << (0xffffffffu & 31u)), (unsigned)((int)(unsigned)((int)(unsigned)x0 >= (int)0x10000u) >= (int)(unsigned)l0), (unsigned)c0); }
    L4: if (--fuel == 0u) goto done;
    do { if (--fuel == 0u) goto done;
        g0 = ((unsigned)(((unsigned)(0x419385d5u < u1) / (*q0 | 1u)) && g0) >> (a0[u1 & 3u] & 31u));
        if ((u0 | (unsigned)(6u || (unsigned)w0))) {
            s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(*q0 || (unsigned)(x0 >> 70)) && (unsigned)((int)p0 >= (int)0x7fffffffu)));
            { unsigned t2; double z2; if ((3u) & 1u) { t2 = ((*q0 << ((unsigned)s0 & 31u)) / (garr[i1 & 7u] | 1u)); z2 = (double)((p0) & 255u); } if ((3u) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                { unsigned t3; double z3; if (((0x80000000u << (v0 & 31u))) & 1u) { t3 = (0xffffffffu ^ g1); z3 = (double)(((g1 & 4u)) & 255u); } if (((0x80000000u << (v0 & 31u))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    f0 = f0 * 0.5f + (float)((fuel << (0x258fab43u & 31u)) & 255u);
                }
                r0.x = r0.x;
                w0 ^= (unsigned long long)((unsigned)l0 * (unsigned)f0) << ((unsigned)(short)((unsigned)(signed char)((unsigned)x0 * (unsigned)(garr[u2 & 7u] && (unsigned)h0)) / (i0 | 1u)) & 63u);
            }
            break; (void)((unsigned)((int)((unsigned)h0 + 0x80000000u) >= (int)a0[u1 & 3u]));
            do { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + ((8u >> (4u & 31u)) << ((0x734a4119u + (unsigned)e0) & 31u)));
                l0 = (long)((unsigned long)l0 + (0x10000u / (0x10000u | 1u)));
                a0[(p0 - (unsigned)l0) & 3u] = v0;
                *mp = (a0[i0 & 3u] & a0[u1 & 3u]);
            } while (i1++ < 5u && p1);
            if ((unsigned)((short)garr[u2 & 7u] > (signed char)r0.x)) goto L0;
        }
        u0 = u0 * 0x9e3779b1u + (unsigned)c0;
        b0 = u2 != 0u;
        if ((unsigned)s1) {
            if ((unsigned)(m0 && r0.y)) break;
            if ((unsigned)((unsigned)c0 && u0)) break;
            *q0 = (unsigned)(garr[u2 & 7u] || 3u);
            u0 = ((unsigned)((unsigned)f0 || (unsigned)((short)5u > (signed char)g1)) << (7u & 31u));
        } else {
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u2) goto done;
                if (((unsigned)d0 % ((u2 + (unsigned)d0) | 1u))) {
                    break; (void)(0xce307385u);
                    u3 = u3 * 0x9e3779b1u + (0x7fffffffu >> (p2 & 31u));
                    if ((unsigned)l0) {
                        *q0 = (((unsigned)(0x10000u == u1) & u3) + (unsigned)(v0 < 0x10000u));
                        if (g0) break;
                        w0 ^= (unsigned long long)((unsigned)(x0 >> 70) / (a0[u1 & 3u] | 1u)) << (((unsigned)((int)0xffffffffu < (int)0x10000u) ^ (unsigned)(unsigned char)(unsigned)((unsigned)s0 < p1)) & 63u);
                    } else {
                        u2 = u2 * 0x9e3779b1u + (a0[u1 & 3u] - ~((unsigned)((short)v0 > (signed char)(unsigned)h1) >> ((unsigned)((unsigned)b0 && *q0) & 31u)));
                    }
                    h0 = (short)(unsigned)((short)(unsigned)x0 > (signed char)1u);
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(u1, (unsigned)(signed char)(unsigned)((unsigned)(garr[i1 & 7u] || (unsigned)l0) || (unsigned)w0), (*q0 * (unsigned)b0)); }
                while (i2++ < 2u && (unsigned)(short)(unsigned)((short)1u > (signed char)*mp)) { if (--fuel == 0u) goto done;
                    break; (void)((g1 & (unsigned)f0));
                    if (0xf4928778u) continue;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s1, (6u | (0x1160aaf5u - i1)), ((unsigned)s1 - 0x80000000u)); }
                    l0 = (long)((unsigned long)l0 + ((unsigned)s0 ? 0u : (unsigned)(w0 >> 29)));
                    break; (void)((unsigned)((int)(unsigned)x0 < (int)((unsigned)(w0 >> 29) >> (m0 & 31u))));
                }
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1((u0 - 0x80000000u), p0, (a0[i0 & 3u] << ((unsigned)c0 & 31u))); }
        }
    } while (i0++ < 7u && (0xb27d473cu - 0xffffffffu));
    if (((unsigned)(unsigned char)(4u % (p1 | 1u)) - 9u)) goto L3;
    if (u0) {
        if ((unsigned)x0) goto L3;
        if (~(unsigned)(g1 == (unsigned)x0)) goto L3;
    } else {
        c0 = (unsigned char)a0[i0 & 3u];
        switch ((unsigned)(0x163f9d92u < (unsigned)(u3 && (unsigned)b0)) & 7u) {
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return ((unsigned)((unsigned)(w0 >> 29) || ((unsigned)c0 - p1)) >> (((unsigned)(w0 >> 29) | (unsigned)(x0 >> 70)) & 31u));
                case 2u: ;
            }
            case 3u: ;
            x0 = x0 * 0x100000001b3ull + ((p2 ^ (unsigned)b0) / ((unsigned)(i2 == a0[u1 & 3u]) | 1u));
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0((garr[i1 & 7u] * 0x5fd4d751u), (unsigned)c1, (unsigned)(unsigned char)((unsigned)w0 - v0)); }
    }
    do { if (--fuel == 0u) goto done;
        garr[(unsigned)(short)(0x14390116u + 0x80000000u) & 7u] = garr[i1 & 7u];
        g1 += (unsigned)((unsigned)(signed char)((i0 ^ m0) & *mp) && 4u);
    } while (i0++ < 5u && (i1 * *mp));
    m0 ^= (unsigned)((int)(unsigned)c0 >= (int)(unsigned)(r0.y && (unsigned)(short)(0x962fd58bu + r0.y)));
    a0[(unsigned)c0 & 3u] = v0;
    if ((unsigned)((unsigned)h0 || (0xfec10036u ^ (unsigned)x0))) {
        if (((unsigned)b0 >> ((garr[i1 & 7u] / (0x10000u | 1u)) & 31u))) {
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(0x10000u & (unsigned)(i2 && (unsigned)((short)u2 > (signed char)0xb65afc86u))) < (int)0x9e9ca29du));
            f0 = f0 * 0.5f + (float)((unsigned)((int)(*q0 + (unsigned)((unsigned)w0 == 0x7fffffffu)) < (int)(i1 | 9u)) & 255u);
            if (budget != 0u) { budget -= 1u; u2 = fn0((u3 & (unsigned)w0), 5u, u3); }
            b0 = ((unsigned)b0 % (g0 | 1u)) != 0u;
        } else {
            if (((unsigned)f0 / (garr[i1 & 7u] | 1u))) {
                goto L1;
                if ((unsigned)b0) goto L0;
                s0 = (int)(unsigned)((unsigned)c1 && *q0);
            }
            h1 = (unsigned short)(h1 + (unsigned)e0);
            s1 = (int)((unsigned)s1 + ((unsigned)c1 ^ (unsigned)e0));
        }
        f0 = f0 * 0.5f + (float)(((8u ? (unsigned)f0 : 0x7fffffffu) * m0) & 255u);
        goto L3;
        m0 ^= (unsigned)c0;
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)x0 < (int)u1)) break;
        e0 = e0 * 0.5L + (long double)(((garr[u2 & 7u] / (g0 | 1u)) << (0xb9a807efu & 31u)) & 1023u);
        break; (void)((unsigned)((unsigned)((int)1u >= (int)0xffffffffu) < 1u));
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)m0 >= (int)*q0), (unsigned)((int)1u < (int)(unsigned)b0), (unsigned)((int)(unsigned)x0 >= (int)(unsigned)!(unsigned)(i2 == 0x7fffffffu))); }
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (g0 << (*mp & 31u)));
        }
        h1 = (unsigned short)(h1 + ((unsigned)s0 ^ 3u));
    }
    u0 ^= (unsigned)((short)u3 > (signed char)(unsigned)c1);
    goto L4;
    r0.y ^= (unsigned)(signed char)(0x526e1254u - (unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) && p1));
    a0[(g0 & u3) & 3u] = (unsigned)c0;
    garr[(unsigned)h1 & 7u] = (0xffffffffu ? (unsigned)(short)((unsigned)s1 / ((0xa5711107u + garr[u2 & 7u]) | 1u)) : 0x80000000u);
    h1 = (unsigned short)(h1 + (unsigned)((short)0x6b39c858u > (signed char)a0[u1 & 3u]));
    while (9u) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((short)9u > (signed char)u1));
    }
    *mp = (unsigned)((short)(unsigned)b0 > (signed char)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0x7eae7d91u));
    switch (0xffffffffu & 7u) {
        garr[(unsigned)c0 & 7u] = (unsigned)((i0 >> (p1 & 31u)) || ((unsigned)((int)i0 < (int)(unsigned)h0) % (r0.x | 1u)));
        c1 = (signed char)(r0.x / (0xb71812dbu | 1u));
        g0 = (0xffffffffu / (((p0 << (v0 & 31u)) + u3) | 1u));
        { unsigned t4; double z4; if (((unsigned)((unsigned)(v0 < u0) < 0xe5d6fcbu)) & 1u) { t4 = (unsigned)((unsigned)(unsigned char)(i2 % (r0.x | 1u)) < 9u); z4 = (double)(((unsigned)(0x80000000u == 4u)) & 255u); } if (((unsigned)((unsigned)(v0 < u0) < 0xe5d6fcbu)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            u2 += (unsigned)s0;
        }
        case 7u: ;
        u2 = u2 * 0x9e3779b1u + ((unsigned)(0x80000000u < u3) + ((unsigned)e0 | (unsigned)l0));
    }
    u1 += (unsigned)((short)(r0.x ^ 2u) > (signed char)(unsigned)!((unsigned)!((unsigned)s0 % ((unsigned)s0 | 1u)) & 0x80000000u));
    f0 = f0 * 0.5f + (float)((unsigned)c0 & 255u);
    l0 = (long)((unsigned long)l0 + ((unsigned)((short)0x7fffffffu > (signed char)(((unsigned)(w0 >> 29) + (unsigned)w0) << ((unsigned)h0 & 31u))) << ((unsigned)x0 & 31u)));
    f0 = f0 * 0.5f + (float)(((u2 / (u1 | 1u)) >> ((unsigned)((int)v0 >= (int)9u) & 31u)) & 255u);
    if (0xc25d906bu) goto L3;
    if (0xd8c825bcu) {
        if (p0) goto L3;
        if ((4u * (unsigned)((int)(unsigned)c0 >= (int)(unsigned)c1))) goto L0;
        while ((p0 ^ u0)) { if (--fuel == 0u) goto done;
            if (i0) break;
            w0 ^= (unsigned long long)(unsigned)(i1 == (unsigned)c0) << (((unsigned)b0 | (unsigned)s1) & 63u);
        }
        i1 = (unsigned)s1 & 15u;
        if ((unsigned)s0) goto L4;
        c0 = (unsigned char)((unsigned)(short)(garr[u2 & 7u] ? i2 : (unsigned)c0) % (0xfd293baeu | 1u));
    } else {
        r0.x = (unsigned)((int)(unsigned)d0 >= (int)(u2 | p2));
        a0[(unsigned)(short)(1u >> ((unsigned)d0 & 31u)) & 3u] = (unsigned)((unsigned)(u3 < 0x65c13377u) || g1);
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(v0 && r0.y), -(unsigned)((unsigned)b0 == (unsigned)h0), a0[i0 & 3u]); }
            a0[(unsigned)(0x10000u && 8u) & 3u] = 3u;
            u1 = 0u;
            if (r0.x) break;
            if ((unsigned)s0) goto L4;
        }
        switch ((garr[u2 & 7u] >> (i0 & 31u)) & 7u) {
            goto L4;
            u1 = u1 * 0x9e3779b1u + (unsigned)((g0 & 3u) == (0xeb505ddeu / (0xf178ff41u | 1u)));
        }
    }
    v0 = a0[u1 & 3u];
    *q0 = 0x80000000u;
    { unsigned t5; double z5; if (((1u ? 0x35e19a45u : u3)) & 1u) { t5 = (unsigned)((unsigned)c1 == (unsigned)s1); z5 = (double)(((((unsigned)d0 - m0) * p1)) & 255u); } if (((1u ? 0x35e19a45u : u3)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
        u0 += ((unsigned)b0 ? u0 : (unsigned)x0);
        if ((p0 << ((unsigned)((short)i0 > (signed char)(unsigned)c0) & 31u))) goto L1;
        while (i0++ < 2u && (8u * (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)((unsigned)e0 < 1u) && u0)) continue;
            u0 ^= (3u ^ (a0[u1 & 3u] * u1));
            if (i1) break;
        }
    }
    do { if (--fuel == 0u) goto done;
        q0 = &garr[(unsigned)((0xffffffffu << ((garr[u2 & 7u] + (unsigned)((int)0x9cd9e9c4u >= (int)v0)) & 31u)) || a0[u1 & 3u]) & 7u];
    } while (i0++ < 6u && (0x10000u * 0x68bf418du));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)((0x10000u * p0) == 0xb7234316u)) goto done;
    h0 = (short)(unsigned)(m0 < (a0[u1 & 3u] ? (v0 + (unsigned)c1) : (unsigned)s0));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)(short)(unsigned)(*q0 < (unsigned)((short)~(unsigned)((unsigned)x0 && u3) > (signed char)0x80000000u));
            s0 = (int)(unsigned)(0x304e8613u == (unsigned)((short)g1 > (signed char)(unsigned)((int)-(unsigned)(m0 && (unsigned)c1) < (int)7u)));
            c1 = (signed char)(unsigned)(short)(g0 / ((unsigned)c1 | 1u));
            a0[*q0 & 3u] = ~(a0[i0 & 3u] - ((unsigned)((int)(unsigned)d0 >= (int)0u) | (5u % ((unsigned)f0 | 1u))));
        }
        u1 += (unsigned)((int)p0 >= (int)(r0.x >> (u0 & 31u)));
        *mp = ((0x9a4b51d6u ^ a0[i0 & 3u]) - i0);
        switch (0x80000000u & 7u) {
            case 2u: ;
            if (0xffffffffu) {
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return 2u;
                    { unsigned t0; double z0; if (((unsigned)(short)((unsigned)l0 / ((p2 + p1) | 1u))) & 1u) { t0 = ((unsigned)h1 << ((unsigned)(i2 && 0x86e9d50eu) & 31u)); z0 = (double)(((u1 % (i0 | 1u))) & 255u); } if (((unsigned)(short)((unsigned)l0 / ((p2 + p1) | 1u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                        if ((unsigned)(short)(m0 - (unsigned)((int)(unsigned)(x0 >> 70) >= (int)u1))) goto L3;
                        if (((unsigned)s0 ? u1 : 3u)) break;
                        u2 ^= ((unsigned)(x0 >> 70) & (unsigned)((int)(unsigned)s0 < (int)((unsigned)c0 ? a0[u1 & 3u] : *mp)));
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn2((p1 / (u0 | 1u)), (u2 % ((unsigned)x0 | 1u)), ((0u ^ garr[u2 & 7u]) * p1)); }
                    r0.y ^= (unsigned)!(r0.y + (unsigned)(u2 || (unsigned)s0));
                    case 7u: ;
                }
            }
            u3 = u3 * 0x9e3779b1u + (unsigned)(garr[u2 & 7u] == (unsigned)((int)0x4f7c111eu < (int)r0.x));
            if (0x7fffffffu) {
                g1 += ((unsigned)!(unsigned)((int)0xffffffffu >= (int)(unsigned)f0) >> ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)a0[u1 & 3u]) & 31u));
                L0: if (--fuel == 0u) goto done;
                if ((unsigned)(signed char)((unsigned)(w0 >> 29) ^ (unsigned)x0)) goto done;
            } else {
                m0 ^= (p2 / (((unsigned)!((unsigned)e0 << ((unsigned)f0 & 31u)) >> (p0 & 31u)) | 1u));
            }
        }
        u2 ^= (unsigned)(*mp < (unsigned)(signed char)(unsigned)((short)0x10000u > (signed char)(unsigned)((unsigned)(w0 >> 29) == 5u)));
        w0 ^= (unsigned long long)(unsigned)(unsigned char)(1u * (unsigned)h1) << ((unsigned)((int)0x2fb909afu >= (int)0xffffffffu) & 63u);
    }
    switch (0xdd6130bu & 7u) {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)4u > (signed char)a0[i0 & 3u])) continue;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((r0.x * 0x10000u) % (0x899d6acu | 1u)), (unsigned)((int)0x1099dd80u < (int)(unsigned)w0), ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)f0) & (unsigned)(w0 >> 29))); }
            if (budget != 0u) { budget -= 1u; u1 = fn2((i2 + (0x7fffffffu * 3u)), a0[i0 & 3u], p2); }
            u0 = u0 * 0x9e3779b1u + (i1 * ((0x7fffffffu & 6u) * (fuel >> (4u & 31u))));
        }
        if (r0.y) goto L4;
        *mp = (~(unsigned)((short)1u > (signed char)0x80000000u) * i0);
    }
    u2 ^= (p2 << ((0x889c28b9u ? *mp : (7u ^ *q0)) & 31u));
    if ((0xffffffffu << ((unsigned)e0 & 31u))) {
        u2 += (unsigned)((unsigned)w0 == (unsigned)h1);
    }
    switch ((unsigned)(short)(unsigned)((u0 ^ 0x78aba195u) && 0xa42fa3cfu) & 7u) {
        w0 ^= (unsigned long long)u0 << ((unsigned)(unsigned char)(unsigned)((int)0x80000000u >= (int)5u) & 63u);
        r0.x = ((unsigned)(garr[u2 & 7u] && (unsigned)c0) >> ((unsigned)((unsigned)s1 || (r0.y >> ((unsigned)l0 & 31u))) & 31u));
        u0 = u0 * 0x9e3779b1u + (unsigned)!((*mp << ((unsigned)f0 & 31u)) + (1u | (garr[u2 & 7u] * garr[i1 & 7u])));
        if (u3 == 7u) return (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)(short)((unsigned)s1 % ((unsigned)d0 | 1u)));
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + ((unsigned)(*mp < (unsigned)w0) % ((9u + (unsigned)c1) | 1u));
            if (((unsigned)x0 ? (unsigned)w0 : (unsigned)h0)) {
                u1 += (unsigned)((int)a0[u1 & 3u] < (int)((unsigned)s1 | (unsigned)f0));
            } else {
                u1 ^= p2;
                u1 = u1 * 0x9e3779b1u + ((unsigned)((short)(unsigned)(*mp && (fuel / (9u | 1u))) > (signed char)0xa7fbd5fdu) >> (u2 & 31u));
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t1; double z1; if (((0x7fffffffu ^ 0xbdeb73e6u)) & 1u) { t1 = (*mp ^ 0xb6355c85u); z1 = (double)(((unsigned)((unsigned)s1 || (garr[u2 & 7u] - r0.x))) & 255u); } if (((0x7fffffffu ^ 0xbdeb73e6u)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                        case 3u: ;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)l0, (unsigned)s1, 0x10000u); }
                        if (budget != 0u) { budget -= 1u; u0 = fn0((0x80000000u | (unsigned)f0), 0xcf95de30u, ((unsigned)(short)(i0 & u0) * v0)); }
                        g0 = ((0xdbcd2fd5u ^ p1) >> ((0xffffffffu >> (6u & 31u)) & 31u));
                        u3 ^= (unsigned)((int)u0 >= (int)1u);
                        for (;;) { if (--fuel == 0u) goto done;
                            default: ;
                            d0 = d0 * 0.5 + (double)((unsigned)(0x93b6ca24u && (unsigned)(*mp || g0)) & 1023u);
                            if (budget != 0u) { budget -= 1u; u2 = fn1(i0, (unsigned)(unsigned char)(u2 % ((*mp * fuel) | 1u)), (unsigned)((short)r0.y > (signed char)((unsigned)h1 / (u0 | 1u)))); }
                            l0 = (long)((unsigned long)l0 + ((7u * (unsigned)c1) | m0));
                        }
                    }
                    u0 = u0 * 0x9e3779b1u + (g0 ^ (0xffffffffu ? (a0[u1 & 3u] ^ garr[i1 & 7u]) : v0));
                    u0 = u0 * 0x9e3779b1u + (*q0 ^ (unsigned)((short)(unsigned)h0 > (signed char)(unsigned)((short)u1 > (signed char)i2)));
                    if ((0x66599aa4u ? m0 : 0xa1c25da1u)) goto L3;
                    if ((unsigned)(short)(fuel | (i0 ^ (unsigned)s1))) goto L0;
                    g1 += (unsigned)(unsigned char)(unsigned)(((unsigned)l0 * i2) || a0[i0 & 3u]);
                }
            }
            break;
        }
        b0 = (i2 & (unsigned)d0) != 0u;
    }
    if ((0x7fffffffu >> (u2 & 31u))) goto L3;
    h1 = (unsigned short)(h1 + (unsigned)(a0[u1 & 3u] < (i0 >> ((unsigned)(short)(unsigned)(garr[u2 & 7u] < ((unsigned)e0 << (p2 & 31u))) & 31u))));
    d0 = d0 * 0.5 + (double)(a0[i0 & 3u] & 1023u);
    L1: if (--fuel == 0u) goto done;
    while (i0++ < 6u && ((unsigned)(u0 && u1) >> (g1 & 31u))) { if (--fuel == 0u) goto done;
        break; (void)((0xffffffffu | p1));
        if (-(((unsigned)e0 ^ u1) * (unsigned)x0)) break;
        *mp = (unsigned)d0;
    }
    q0 = &garr[u3 & 7u];
    if ((unsigned)((unsigned)((int)p1 >= (int)i0) < g1)) {
        r0.x = ((unsigned)b0 & (3u & p2));
    }
    switch (~(0x966111e7u ^ 0x10000u) & 7u) {
        h1 = (unsigned short)(h1 + (i2 << (i2 & 31u)));
        if ((0x10000u | (unsigned)(a0[i0 & 3u] == 8u))) goto L2;
        { unsigned t2; double z2; if (((0xb23a26e7u / ((unsigned)(i1 == 0x7fffffffu) | 1u))) & 1u) { t2 = a0[i0 & 3u]; z2 = (double)(((unsigned)(p1 == u3)) & 255u); } if (((0xb23a26e7u / ((unsigned)(i1 == 0x7fffffffu) | 1u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            case 5u: ;
            u0 += (unsigned)(short)((unsigned)(w0 >> 29) + p0);
            u0 = u0 * 0x9e3779b1u + (unsigned)((short)(unsigned)c0 > (signed char)p1);
            do { if (--fuel == 0u) goto done;
                r0.y ^= v0;
                h1 = (unsigned short)(h1 + ((unsigned)(x0 >> 70) ^ (unsigned)d0));
                u0 += ((6u ^ (0xffffffffu >> (garr[i1 & 7u] & 31u))) >> ((unsigned)(0x7a92594bu || (unsigned)x0) & 31u));
                if ((unsigned)((garr[u2 & 7u] & i0) && 0x7fffffffu)) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn2(0x14ba435fu, u1, 0u); }
                L2: if (--fuel == 0u) goto done;
            } while (i0++ < 3u && g0);
            goto L1;
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(((0x7fffffffu ^ (unsigned)(x0 >> 70)) | v0) & 1023u);
                L3: if (--fuel == 0u) goto done;
                { unsigned t3; double z3; if (((p2 ? a0[u1 & 3u] : 0u)) & 1u) { t3 = ((unsigned)(w0 >> 29) >> (*q0 & 31u)); z3 = (double)(((unsigned)(0xb078f95du == 0x80000000u)) & 255u); } if (((p2 ? a0[u1 & 3u] : 0u)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    if (fuel) {
                        v0 = (unsigned)(signed char)(unsigned)(0x268659f2u && (unsigned)(p2 == (unsigned)(i0 < u0)));
                    }
                    case 3u: ;
                }
                if (((unsigned)(unsigned char)(8u >> ((unsigned)s1 & 31u)) / (0xcded432eu | 1u))) break;
                m0 ^= ((unsigned)(0x97e226a9u && 0x23f54603u) ^ (unsigned)(*q0 || (fuel << (a0[i0 & 3u] & 31u))));
            }
        }
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + ((((unsigned)l0 + 0x7d2133ceu) ^ 1u) - (unsigned)(x0 >> 70));
            case 4u: ;
            case 1u: ;
        }
        if (((unsigned)((int)r0.x >= (int)p0) + (unsigned)h0)) {
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)c0, 0x7fffffffu, 3u); }
            if ((unsigned)(u1 < (unsigned)b0)) {
                u2 = (unsigned)(signed char)((4u / ((unsigned)((unsigned)d0 == (unsigned)s0) | 1u)) | (i1 ^ 0xf9f8fcbdu));
                f0 = f0 * 0.5f + (float)((i0 + (unsigned)((int)((unsigned)l0 - u2) < (int)(unsigned)c0)) & 255u);
                c0 = (unsigned char)(p1 & (unsigned)(((unsigned)d0 % (0x5bed7f72u | 1u)) || (unsigned)s0));
                for (;;) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)s1);
                }
                garr[i1 & 7u] = (unsigned)b0;
                goto done;
            } else {
                if (fuel < 8u) return p1;
            }
            g0 = -(unsigned)((unsigned)e0 < m0);
            b0 = a0[u1 & 3u] != 0u;
            L4: if (--fuel == 0u) goto done;
            if (u3 == 7u) return a0[i0 & 3u];
        } else {
            u2 += (unsigned)((unsigned)e0 < (unsigned)(w0 >> 29));
        }
        a0[(unsigned)s0 & 3u] = (i1 % (5u | 1u));
    }
    e0 = e0 * 0.5L + (long double)((unsigned)(3u < (unsigned)(signed char)(*mp / ((unsigned)((short)r0.y > (signed char)0xf64c0182u) | 1u))) & 1023u);
    while ((unsigned)(0x80000000u && 0x80000000u)) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            { unsigned t4; double z4; if ((g0) & 1u) { t4 = (unsigned)(4u && p0); z4 = (double)(((unsigned)((short)0xe10d0e86u > (signed char)(unsigned)(0x7fffffffu < garr[u2 & 7u]))) & 255u); } if ((g0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                u1 += (unsigned)c1;
                a0[r0.x & 3u] = ((unsigned)(signed char)(unsigned)(u1 == 0x10000u) ^ u1);
                l0 = (long)((unsigned long)l0 + (p1 + 7u));
            }
            a0[(unsigned)((short)0xffffffffu > (signed char)4u) & 3u] = 5u;
        } while (i1++ < 5u && (unsigned)l0);
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(unsigned char)(unsigned)((short)g1 > (signed char)u3), ((unsigned)s0 / ((unsigned)(short)(unsigned)(p2 == (unsigned)s0) | 1u)), (unsigned)(9u < (garr[u2 & 7u] + 0x56831e2u))); }
            e0 = e0 * 0.5L + (long double)((unsigned)(0xe008a980u || (unsigned)h0) & 1023u);
        }
        for (;;) { if (--fuel == 0u) goto done;
            continue; (void)((garr[u2 & 7u] / (0x7fffffffu | 1u)));
            h0 = (short)0xab88373bu;
            g0 = u0;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)x0, (5u & ((unsigned)s0 / ((unsigned)c1 | 1u))), (unsigned)(short)(unsigned)((unsigned)(i0 < u0) && 5u)); }
            continue; (void)(((unsigned)e0 | (unsigned)s1));
        }
        if ((unsigned)(u3 || (unsigned)((short)(unsigned)h1 > (signed char)0x7fffffffu))) {
            { unsigned t5; double z5; if (((unsigned)e0) & 1u) { t5 = *mp; z5 = (double)(((unsigned)(r0.x || 8u)) & 255u); } if (((unsigned)e0) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                break; (void)((unsigned)(signed char)(unsigned)((unsigned)(u1 && (unsigned)l0) < p0));
                u1 = garr[u2 & 7u];
                break; (void)(8u);
                u0 = u0 * 0x9e3779b1u + (unsigned)(*mp && (unsigned)(~((unsigned)b0 - 0x26f72136u) < (unsigned)f0));
            }
            if ((unsigned)(signed char)((a0[u1 & 3u] ^ i1) | u2)) {
                goto done;
                a0[(*mp % (4u | 1u)) & 3u] = -((unsigned)((int)g0 < (int)(unsigned)c0) - (unsigned)(7u < (unsigned)w0));
            } else {
                c1 = (signed char)(0x96e8ec50u << ((unsigned)((int)0xffffffffu < (int)g1) & 31u));
                if (0xffffffffu) break;
                f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((unsigned)(x0 >> 70) < 0xf07cd52du) || (unsigned)c1) & 255u);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(7u - 6u) > (signed char)fuel), 0xeaf81d5eu, *mp); }
            }
        } else {
            if (budget != 0u) { budget -= 1u; u2 = fn1(a0[u1 & 3u], ((unsigned)h1 | 0x7fffffffu), (m0 & 0x10000u)); }
            while ((unsigned)(((unsigned)s1 >> (0x80000000u & 31u)) && p0)) { if (--fuel == 0u) goto done;
                break; (void)(u1);
                if (-(a0[u1 & 3u] - a0[i0 & 3u])) goto L0;
                switch ((unsigned)(9u < u1) & 7u) {
                    d0 = d0 * 0.5 + (double)((unsigned)!(unsigned)((int)(p1 * 3u) < (int)u3) & 1023u);
                }
            }
        }
        c1 = (signed char)(u1 + (((unsigned)w0 / ((unsigned)(w0 >> 29) | 1u)) - a0[i0 & 3u]));
    }
    u2 ^= ((unsigned)(u3 || (0x10000u / (0x10000u | 1u))) * (garr[i1 & 7u] | (unsigned)(w0 >> 29)));
    *q0 += (unsigned)((int)0x72b96d85u >= (int)(unsigned)(signed char)((unsigned)(x0 >> 70) ? r0.x : r0.x));
    if ((0x7fffffffu * 0xffffffffu)) {
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((int)(unsigned)b0 < (int)a0[i0 & 3u]) * (unsigned)c1), (unsigned)s0, (unsigned)((int)r0.y >= (int)a0[u1 & 3u])); }
        switch ((unsigned)((unsigned)s1 == (unsigned)s0) & 7u) {
            { unsigned t6; double z6; if (((9u + (unsigned)x0)) & 1u) { t6 = (unsigned)(unsigned char)((unsigned)(short)(unsigned)((int)garr[i1 & 7u] < (int)(unsigned)x0) ^ 5u); z6 = (double)((((unsigned)(signed char)(unsigned)((int)0x80000000u >= (int)r0.y) ^ v0)) & 255u); } if (((9u + (unsigned)x0)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                if (budget != 0u) { budget -= 1u; u1 = fn1(r0.x, 0xaaa3f79eu, (unsigned)(garr[u2 & 7u] || -(unsigned)(g1 == (unsigned)f0))); }
                while (i0++ < 2u && (0xb717332cu % ((unsigned)f0 | 1u))) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((~(unsigned)((unsigned)f0 && 0x6e5bd6ffu) * ((p2 >> ((unsigned)e0 & 31u)) % (v0 | 1u))) & 255u);
                }
                if (m0) {
                    s0 = (int)(r0.y - 1u);
                    if ((unsigned)s0) goto L4;
                    if ((unsigned)(u1 && g1)) {
                        switch (garr[i1 & 7u] & 7u) {
                            if (budget != 0u) { budget -= 1u; u2 = fn2(m0, (unsigned)f0, (0x69f6a16fu | (unsigned)w0)); }
                            if (a0[u1 & 3u]) goto L0;
                            *mp = (unsigned)(((unsigned)(4u || 0x7fffffffu) / ((unsigned)(p0 || (unsigned)d0) | 1u)) && garr[u2 & 7u]);
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)!(fuel >> (garr[u2 & 7u] & 31u)) && v0), (unsigned)(5u && 3u), (unsigned)((int)-(p2 + (unsigned)h0) < (int)garr[u2 & 7u])); }
                            g0 = (unsigned)((short)((a0[u1 & 3u] >> (0x10000u & 31u)) ^ p2) > (signed char)6u);
                            d0 = d0 * 0.5 + (double)(0x80000000u & 1023u);
                        }
                        *mp = (0x72bba048u & (0x6a590d3fu + ((unsigned)f0 / (p1 | 1u))));
                        if (budget != 0u) { budget -= 1u; u0 = fn0(~(unsigned)(9u == (unsigned)(i1 && 5u)), (unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)e0), (garr[i1 & 7u] & (g0 >> (fuel & 31u)))); }
                    }
                    while (i0++ < 3u && (unsigned)c0) { if (--fuel == 0u) goto done;
                        continue; (void)((0xffffffffu - (*q0 - 0xbdbdf270u)));
                        w0 = w0 * 6364136223846793005ull + (unsigned)(short)((g1 ? 7u : (unsigned)(x0 >> 70)) | p2);
                    }
                    if (u3 == 7u) return ((unsigned)d0 & (u2 ? p1 : 0xffffffffu));
                } else {
                    d0 = d0 * 0.5 + (double)((unsigned)(w0 >> 29) & 1023u);
                    if (((unsigned)b0 - *mp)) goto L3;
                    if (u3 == 7u) return (unsigned)(signed char)(((6u ^ (unsigned)x0) * fuel) - fuel);
                }
            }
        }
        l0 = (long)((unsigned long)l0 + ((unsigned)d0 - (unsigned)d0));
        if (budget != 0u) { budget -= 1u; u3 = fn1((-(i2 - u1) % ((unsigned)x0 | 1u)), (unsigned)((unsigned)w0 && (0x80000000u & (unsigned)f0)), (unsigned)((unsigned)l0 < r0.y)); }
        { unsigned t7; double z7; if (((unsigned)((short)(0x45bcbb80u * (unsigned)h0) > (signed char)u2)) & 1u) { t7 = m0; z7 = (double)(((g1 & (unsigned)f0)) & 255u); } if (((unsigned)((short)(0x45bcbb80u * (unsigned)h0) > (signed char)u2)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
            goto L3;
            if ((unsigned)(short)(unsigned)((unsigned)x0 && (u1 * g1))) goto L3;
        }
    }
    g0 = (-((unsigned)((unsigned)l0 < u0) ^ (unsigned)w0) / (g0 | 1u));
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (v0) continue;
            c0 = (unsigned char)-(unsigned)(~(unsigned)(garr[u2 & 7u] == u3) < (p1 % (garr[i1 & 7u] | 1u)));
            switch (a0[u1 & 3u] & 7u) {
                case 6u: ;
                do { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)((unsigned)e0 || fuel) >= (int)(unsigned)((unsigned)h1 < (unsigned)(w0 >> 29))));
                    break; (void)(((unsigned)(signed char)(unsigned)(4u == *q0) | 0xea1a3a58u));
                    if ((unsigned)(u1 < (*mp << (4u & 31u)))) {
                        do { if (--fuel == 0u) goto done;
                            case 3u: ;
                            m0 ^= (((unsigned)c0 * 3u) & 0x10000u);
                            *q0 += ((0xa24974b9u * u3) - (unsigned)(0x7fffffffu < 0x265fddacu));
                            g0 = (0x56e28ef4u * (unsigned)(w0 >> 29));
                            u1 += (unsigned)(signed char)(0xf166ff6cu - (*q0 + 0x80000000u));
                        } while (i0++ < 4u && (unsigned)((unsigned)w0 < 0xd35aa27cu));
                        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                            goto L1;
                            default: ;
                        }
                        q0 = &garr[(unsigned)(signed char)(unsigned)((unsigned)(a0[u1 & 3u] == r0.x) == garr[i1 & 7u]) & 7u];
                    }
                    e0 = e0 * 0.5L + (long double)((unsigned)s0 & 1023u);
                    *q0 += ((*q0 / (fuel | 1u)) ^ (unsigned)(w0 >> 29));
                    i0 = ((unsigned)s0 - (unsigned)(x0 >> 70)) & 15u;
                } while (i2++ < 3u && (0x7fffffffu & 0x67035785u));
                u0 += a0[u1 & 3u];
            }
        } while (i1++ < 5u && *mp);
        do { if (--fuel == 0u) goto done;
            if ((*mp * ((unsigned)s1 % (u3 | 1u)))) goto L3;
        } while (i1++ < 4u && (unsigned)(i0 == (unsigned)(p2 == a0[u1 & 3u])));
        b0 = 0x10000u != 0u;
        if (0xffffffffu) break;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (a0[u1 & 3u]) break;
            d0 = d0 * 0.5 + (double)(m0 & 1023u);
            if (((unsigned)d0 / ((unsigned)h1 | 1u))) break;
            if (0x80000000u) continue;
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(a0[u1 & 3u]);
                if (0x10000u) {
                    h0 = (short)(unsigned)((int)0xe8ec50a6u < (int)((unsigned)d0 - (unsigned)(p1 < 0x80000000u)));
                    g1 += ((unsigned)c1 ^ -(unsigned)((int)6u < (int)(unsigned)l0));
                }
                w0 ^= (unsigned long long)(0xdf6e491du % (fuel | 1u)) << ((unsigned)((int)(unsigned)h1 < (int)0xd4e7d734u) & 63u);
            }
            u0 = (unsigned)((int)fuel < (int)((unsigned)x0 ? u2 : v0));
        }
        h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)s0 >= (int)0x5c24c0fcu));
    }
    if ((unsigned)!(((unsigned)(w0 >> 29) << (6u & 31u)) % ((unsigned)e0 | 1u))) {
        u2 += (0xffffffffu & (unsigned)(r0.y || (unsigned)((unsigned)s0 && 3u)));
        if (r0.y) goto done;
        i0 = ((i1 ^ i0) ^ ((p0 ^ i2) + u0)) & 15u;
        a0[(unsigned)s1 & 3u] = (garr[u2 & 7u] << (fuel & 31u));
        if (fuel < 8u) return (unsigned)((short)0xffffffffu > (signed char)(0xffffffffu ? (unsigned)l0 : 2u));
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (r0.y) break;
        break; (void)((unsigned)b0);
        if ((p0 + (p2 - (unsigned)b0))) goto L1;
        if ((unsigned)s0) {
            break; (void)((unsigned)!(u3 >> ((unsigned)(8u || 0xf85c82fbu) & 31u)));
        } else {
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(0x10000u && fuel), ((unsigned)h1 ^ -(0xffffffffu >> ((unsigned)s1 & 31u))), p0); }
                if ((unsigned)((unsigned)c0 < 0x10000u)) break;
                u0 = u0 * 0x9e3779b1u + ((0u + (unsigned)s1) | *q0);
                u0 = u0 * 0x9e3779b1u + 0x80000000u;
            }
            c1 = (signed char)((unsigned)(unsigned char)(*mp | (unsigned)h1) >> ((unsigned)((unsigned)l0 && p1) & 31u));
            if (~(unsigned)((int)g0 >= (int)i2)) break;
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)c1 < (int)a0[i0 & 3u]));
        }
        if (r0.y) goto L1;
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)s1 == (unsigned)((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)b0) < (unsigned)((int)(unsigned)s1 >= (int)p0))));
    }
    h1 = (unsigned short)(h1 + ((unsigned)((int)2u < (int)(unsigned)w0) + (unsigned)(unsigned char)((unsigned)s1 / (u2 | 1u))));
    u0 = (unsigned)!((unsigned)(9u < (unsigned)c0) << ((0x7f497e21u - ((unsigned)s0 << (m0 & 31u))) & 31u));
    l0 = (long)((unsigned long)l0 + (0x7fffffffu | (unsigned)(a0[i0 & 3u] < 0x10000u)));
    while (i0++ < 4u && (0u | (unsigned)((int)a0[i0 & 3u] < (int)p2))) { if (--fuel == 0u) goto done;
        u0 += (unsigned)(signed char)(((unsigned)x0 / ((i0 ^ u2) | 1u)) << ((5u * 0xffffffffu) & 31u));
    }
    if (((unsigned)w0 - (unsigned)c0)) goto L3;
    switch ((unsigned)((unsigned)(signed char)(unsigned)((short)0xffffffffu > (signed char)0x1c83e843u) && r0.y) & 7u) {
        h0 = (short)((unsigned)d0 * r0.y);
        r0.y ^= i0;
    }
    e0 = e0 * 0.5L + (long double)((((unsigned)s0 - 6u) | (7u - 6u)) & 1023u);
    goto L3;
    s1 = (int)((unsigned)s1 + (p0 / ((unsigned)e0 | 1u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    a0[1u & 3u] = ((unsigned)((unsigned)b0 && (0x28383138u & 0x8c3e2c5fu)) << (p2 & 31u));
    switch (3u & 7u) {
        do { if (--fuel == 0u) goto done;
            switch (u3 & 7u) {
                s1 = (int)((unsigned)s1 + (9u | (unsigned)(unsigned char)(0x10000u << (g0 & 31u))));
                do { if (--fuel == 0u) goto done;
                    c1 = (signed char)fuel;
                    if (0xb1d079eu) {
                        q0 = &garr[0x10000u & 7u];
                    } else {
                        L0: if (--fuel == 0u) goto done;
                        case 6u: ;
                        if ((unsigned)((int)0x10000u >= (int)r0.y)) goto L3;
                        if (0xeaa212d2u) {
                            case 5u: ;
                            if (((unsigned)(2u < p2) & i2)) continue;
                            if ((unsigned)((0x5b6bb424u & *mp) < (unsigned)e0)) goto done;
                            *q0 = (unsigned)(w0 >> 29);
                            L1: if (--fuel == 0u) goto done;
                        }
                    }
                    L2: if (--fuel == 0u) goto done;
                } while (i1++ < 4u && (unsigned)(a0[u1 & 3u] == (unsigned)(signed char)(0u << ((unsigned)c0 & 31u))));
                a0[(unsigned)((int)p1 < (int)(unsigned)c1) & 3u] = (unsigned)(v0 == (3u >> (*mp & 31u)));
                r0.y ^= (p2 | (unsigned)((short)(unsigned)((unsigned)h0 || 0x58829d2fu) > (signed char)(unsigned)(unsigned char)(0x7fffffffu | (unsigned)l0)));
                l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)w0 < p1));
                u1 = u1 * 0x9e3779b1u + ((unsigned)((unsigned)((short)0xaab0630au > (signed char)i2) || u2) >> (0xffffffffu & 31u));
            }
        } while (i0++ < 5u && (0xffffffffu - (unsigned)(signed char)(7u ^ 0x80000000u)));
    }
    { unsigned t0; double z0; if (((unsigned)(short)((unsigned)e0 | i2)) & 1u) { t0 = m0; z0 = (double)((((unsigned)((short)p0 > (signed char)(unsigned)w0) % ((unsigned)e0 | 1u))) & 255u); } if (((unsigned)(short)((unsigned)e0 | i2)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        switch ((unsigned)(signed char)(unsigned)((short)(unsigned)((int)(unsigned)x0 < (int)a0[u1 & 3u]) > (signed char)(unsigned)e0) & 7u) {
            if (0xffffffffu) goto L2;
            switch ((unsigned)w0 & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((p2 * garr[i1 & 7u]) < 6u), (p2 >> (0xd0eec036u & 31u)), (unsigned)((short)m0 > (signed char)(*q0 % ((unsigned)h1 | 1u)))); }
                u3 = u3 * 0x9e3779b1u + 0x80000000u;
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(short)(unsigned)((short)u2 > (signed char)0xe694e68du), (u3 ^ (p2 ^ *mp)), (~((unsigned)h0 - 9u) >> (a0[u1 & 3u] & 31u))); }
                u0 ^= (unsigned)s1;
            }
            if (u3 == 7u) return (unsigned)((int)(unsigned)((int)0xffffffffu >= (int)u1) < (int)(unsigned)(short)((0x39bd2386u % (0x10000u | 1u)) % (garr[u2 & 7u] | 1u)));
        }
        switch ((unsigned)(a0[u1 & 3u] || a0[u1 & 3u]) & 7u) {
            u2 = (unsigned)(short)(((p0 / (0xdc9d910eu | 1u)) | *mp) & ~(0u | u0));
            a0[8u & 3u] = ~(unsigned)((int)(unsigned)((int)0x10000u < (int)(unsigned)f0) >= (int)(unsigned)(short)(0x65ded9f5u ? 0xb1f29c49u : v0));
            e0 = e0 * 0.5L + (long double)((2u + (unsigned)l0) & 1023u);
        }
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)(*q0 - 0x7dc9d4e3u) < (int)(unsigned)d0), (unsigned)(6u && r0.x), u2); }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn3((garr[i1 & 7u] * 2u), (4u >> (0x10000u & 31u)), (unsigned)(short)(unsigned)(0xffffffffu && i1)); }
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)(u2 == v0) || i2), (0xda218884u ^ fuel), (g0 + (garr[i1 & 7u] - 0x10000u))); }
    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)c1 && 6u) & 255u);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)((int)u2 < (int)1u) < 0xa05eadc5u)) {
            if (garr[i1 & 7u]) break;
            if (0x10000u) {
                if ((unsigned)(p0 < (unsigned)(4u || (unsigned)h1))) continue;
                d0 = d0 * 0.5 + (double)((0u % ((unsigned)!(6u + (unsigned)d0) | 1u)) & 1023u);
                l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((int)p2 < (int)((unsigned)(p2 || i0) << (v0 & 31u))) < 0x2cf39ad7u));
                if (((unsigned)((short)2u > (signed char)0xd3fbfe31u) / (0x6ea4c667u | 1u))) {
                    w0 ^= (unsigned long long)(p2 | m0) << ((0x80000000u >> ((i2 / ((p0 / (0x80000000u | 1u)) | 1u)) & 31u)) & 63u);
                    u1 = (unsigned)((unsigned)((unsigned)((int)(unsigned)e0 < (int)u1) || 0xccf3cddbu) == ((unsigned)x0 ^ i2));
                    *q0 += (0x78618a10u * ~(unsigned)((int)(r0.y >> (r0.y & 31u)) >= (int)p0));
                    if ((p0 & m0)) break;
                    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)*mp > (signed char)(unsigned)c0), (5u >> ((0x10000u << ((unsigned)c0 & 31u)) & 31u)), garr[i1 & 7u]); }
                } else {
                    if (g0) {
                        if (((unsigned)(p2 && (unsigned)(w0 >> 29)) >> (i2 & 31u))) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(p0 * (unsigned)b0), 0xc5abbb3au, (unsigned)((short)0xffffffffu > (signed char)((unsigned)(w0 >> 29) * p2))); }
                    } else {
                        s1 = (int)((unsigned)s1 + ((unsigned)s1 / ((unsigned)((unsigned)(r0.x || a0[i0 & 3u]) == *mp) | 1u)));
                        if (fuel) continue;
                        if ((unsigned)((short)(unsigned)w0 > (signed char)(unsigned)(short)(unsigned)(6u == 0x80000000u))) break;
                        l0 = (long)((unsigned long)l0 + u2);
                    }
                    L3: if (--fuel == 0u) goto done;
                    c1 = (signed char)i1;
                }
                *q0 += ((unsigned)h0 ^ (unsigned)((int)(u1 >> (u1 & 31u)) < (int)(0xffffffffu | 0x87e6bfd8u)));
                if (fuel < 8u) return ((unsigned)((int)0u < (int)(unsigned)s1) % ((unsigned)((int)0xae3df3fu < (int)p0) | 1u));
            }
            h1 = (unsigned short)(h1 + (unsigned)((3u % ((unsigned)((short)u2 > (signed char)6u) | 1u)) == u1));
            if ((unsigned)(g1 < ~(0x6368ffd1u * (unsigned)d0))) break;
            if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, -(u0 * (unsigned)(u0 && garr[i1 & 7u])), ((unsigned)(x0 >> 70) >> ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x1c53512eu) & 31u))); }
            do { if (--fuel == 0u) goto done;
                break; (void)((0x3445f468u * (unsigned)(4u && p1)));
                L4: if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)(signed char)(6u ^ (unsigned)c1) & 7u];
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)i1 >= (int)r0.y)) goto L1;
                    c0 = (unsigned char)(unsigned)(0x10000u && (0xffffffffu - (i1 * (unsigned)(i1 && (unsigned)w0))));
                }
                while (i2++ < 2u && (unsigned)((int)(p0 % ((unsigned)d0 | 1u)) >= (int)*q0)) { if (--fuel == 0u) goto done;
                    if (a0[u1 & 3u]) break;
                    if ((8u >> (garr[i1 & 7u] & 31u))) break;
                    if (u3 == 7u) return 3u;
                    u2 = u1;
                }
                u3 = u3 * 0x9e3779b1u + (unsigned)((int)g0 < (int)(p0 + garr[i1 & 7u]));
            } while (i1++ < 2u && ((unsigned)f0 & u0));
        }
        c0 = (unsigned char)(unsigned)((int)1u < (int)(unsigned)(x0 >> 70));
        if (((unsigned)c1 ^ (0x80000000u - a0[i0 & 3u]))) {
            h1 = (unsigned short)(h1 + ((unsigned)d0 / ((unsigned)f0 | 1u)));
            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(p1 && (0x9b321da7u - 0xffffffffu)) == (unsigned)(0x449ad669u == a0[i0 & 3u]));
            break; (void)((unsigned)((int)u1 >= (int)(unsigned)h0));
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)(short)(garr[i1 & 7u] & (unsigned)(unsigned char)(unsigned)(*mp == (unsigned)f0)));
                if ((unsigned)((unsigned)((int)*mp >= (int)a0[i0 & 3u]) || u3)) break;
                s0 = (int)(u2 - (unsigned)b0);
                while (i2++ < 7u && v0) { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)(a0[i0 & 3u] && 0xb6e1f6b6u);
                    if ((unsigned)((int)r0.x >= (int)u0)) goto L4;
                    w0 = w0 * 6364136223846793005ull + ((((unsigned)h0 + i0) & (unsigned)(0xb292d1aeu < u0)) & r0.x);
                    s1 = (int)((unsigned)s1 + ((u2 ^ r0.x) % ((unsigned)((int)u3 >= (int)0xb7c8c48au) | 1u)));
                }
                do { if (--fuel == 0u) goto done;
                    goto done;
                    do { if (--fuel == 0u) goto done;
                        u3 = 0u;
                        do { if (--fuel == 0u) goto done;
                            if (~((unsigned)w0 ? 4u : 7u)) continue;
                        } while (i1++ < 2u && (unsigned)(signed char)(unsigned)((int)u3 < (int)(unsigned)b0));
                        continue; (void)((u3 * g0));
                        q0 = &garr[(unsigned)d0 & 7u];
                    } while (i0++ < 7u && (unsigned)((4u >> (1u & 31u)) == p1));
                    r0.x = g1;
                } while (i2++ < 4u && (0xf2a60b50u & ((unsigned)s0 + 0xffffffffu)));
            }
            if (fuel < 8u) return ((unsigned)c0 - *mp);
        }
    }
    if ((unsigned)((int)(unsigned)((int)0x1c5d8ff9u < (int)0xc3400256u) < (int)0x951c93a9u)) goto L3;
    goto L0;
    g0 = (unsigned)(short)(3u ? *q0 : (0x7fffffffu & 0x7fffffffu));
    goto L3;
    { unsigned t1; double z1; if (((unsigned)((int)0xcf86d441u < (int)(unsigned)w0)) & 1u) { t1 = (r0.x >> (u0 & 31u)); z1 = (double)(((unsigned)((short)0x58c890b0u > (signed char)(unsigned)(*q0 && v0))) & 255u); } if (((unsigned)((int)0xcf86d441u < (int)(unsigned)w0)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        if (budget != 0u) { budget -= 1u; u1 = fn3(g1, (m0 >> (p2 & 31u)), (unsigned)((int)0x71d06291u >= (int)(0xd6492ae9u ^ (unsigned)h1))); }
        if ((unsigned)((unsigned)((int)fuel < (int)(unsigned)c1) || 0x9c006115u)) {
            if (budget != 0u) { budget -= 1u; u2 = fn2((p2 ^ r0.y), (unsigned)d0, (garr[u2 & 7u] & (unsigned)(unsigned char)(unsigned)(p0 || u0))); }
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)b0, (unsigned)((short)0x10000u > (signed char)(*mp * 0xffffffffu)), ((unsigned)h0 * i2)); }
            *q0 += ((p0 | r0.x) - (unsigned)w0);
        } else {
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(x0 >> 70), (r0.x + u1), (unsigned)(x0 >> 70)); }
            u1 = u1 * 0x9e3779b1u + 0u;
        }
        if (fuel < 8u) return (unsigned)c0;
        v0 = (unsigned)!(unsigned)((unsigned)c0 == 0xb7ff6a82u);
        *mp = (unsigned)(x0 >> 70);
    }
    goto L3;
    r0.x = (unsigned)x0;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0(0x8d7ac763u, ((0x17acc216u / (7u | 1u)) - 0xbc9ab31bu), (unsigned)((int)(unsigned)h1 >= (int)v0)); }
        if ((unsigned)((int)(unsigned)(g1 == u3) >= (int)0x6b570ad7u)) {
            switch (p0 & 7u) {
                { unsigned t2; double z2; if (((0x3bbe918cu >> (p0 & 31u))) & 1u) { t2 = (v0 - garr[u2 & 7u]); z2 = (double)((r0.y) & 255u); } if (((0x3bbe918cu >> (p0 & 31u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    break; (void)((unsigned)(signed char)(r0.x % (g0 | 1u)));
                    case 6u: ;
                    if (budget != 0u) { budget -= 1u; u0 = fn2((garr[u2 & 7u] - (unsigned)x0), (g0 & (unsigned)c0), r0.x); }
                    if ((((unsigned)s1 * u3) + u3)) {
                        h1 = (unsigned short)(h1 + (unsigned)((unsigned)(i1 && (unsigned)w0) < (unsigned)w0));
                    } else {
                        r0.x = (unsigned)(short)((unsigned)(x0 >> 70) * u1);
                    }
                    h0 = (short)(unsigned)((short)(unsigned)(short)(0xe68fb6f7u * (unsigned)h1) > (signed char)*q0);
                }
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t3; double z3; if (((garr[i1 & 7u] / ((0x82af503eu ^ 0x6f2d8d41u) | 1u))) & 1u) { t3 = (unsigned)((int)(g1 << ((unsigned)b0 & 31u)) < (int)(unsigned)(w0 >> 29)); z3 = (double)(((unsigned)(short)(0x80000000u ^ (unsigned)(4u || g1))) & 255u); } if (((garr[i1 & 7u] / ((0x82af503eu ^ 0x6f2d8d41u) | 1u))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                        g1 += (unsigned)!((p1 % (((unsigned)(w0 >> 29) & (9u - *mp)) | 1u)) >> (a0[i0 & 3u] & 31u));
                        case 5u: ;
                        case 1u: ;
                        if (((unsigned)(w0 >> 29) & (unsigned)((int)(unsigned)(w0 >> 29) < (int)garr[u2 & 7u]))) {
                            c0 = (unsigned char)a0[i0 & 3u];
                            default: ;
                            if (0x10000u) goto L4;
                            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(unsigned char)((6u & 3u) >> ((unsigned)b0 & 31u)), (unsigned)((unsigned)w0 || p1), (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)l0)); }
                            case 4u: ;
                        }
                        b0 = ((a0[i0 & 3u] + (unsigned)s1) ? (unsigned)c1 : (unsigned)c0) != 0u;
                        w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)b0 < (int)(unsigned)s0);
                    }
                    c1 = (signed char)((g0 >> ((unsigned)((int)g0 < (int)a0[i0 & 3u]) & 31u)) | (i1 | 0x10000u));
                    if (budget != 0u) { budget -= 1u; u2 = fn0(0xffffffffu, (garr[u2 & 7u] * *q0), (unsigned)(garr[u2 & 7u] || (unsigned)((short)*q0 > (signed char)0x42c72b08u))); }
                    if (budget != 0u) { budget -= 1u; u0 = fn2((u0 % ((garr[i1 & 7u] + *mp) | 1u)), (0x28027d05u % ((u3 % (0x10000u | 1u)) | 1u)), 4u); }
                    if (((unsigned)(x0 >> 70) * ((unsigned)(x0 >> 70) | u3))) {
                        if ((unsigned)((short)m0 > (signed char)((unsigned)(x0 >> 70) % ((unsigned)e0 | 1u)))) break;
                        if ((g0 * (unsigned)b0)) goto L4;
                        for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                            h0 = (short)(unsigned)((int)*q0 >= (int)*mp);
                            if (budget != 0u) { budget -= 1u; u0 = fn3(i2, g0, p1); }
                            *q0 += (unsigned)f0;
                            u1 += ((unsigned)h0 % ((unsigned)((int)(0xeba3f5d0u >> (*q0 & 31u)) >= (int)0x10000u) | 1u));
                            break; (void)((unsigned)(short)(g1 % (0xcf46eda5u | 1u)));
                        }
                        if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((int)g1 >= (int)(*mp - (unsigned)s0)), (p2 / (((unsigned)c1 >> (i2 & 31u)) | 1u)), (2u << (((unsigned)h0 | 8u) & 31u))); }
                        h1 = (unsigned short)(h1 + (unsigned)((short)*mp > (signed char)(unsigned)(short)(unsigned)(u0 && (unsigned)(w0 >> 29))));
                        if ((4u + r0.y)) break;
                    } else {
                        s0 = (int)(unsigned)((int)(unsigned)((short)0xf4b55f2eu > (signed char)8u) >= (int)a0[u1 & 3u]);
                        case 3u: ;
                        w0 ^= (unsigned long long)(unsigned)f0 << ((0x10000u + 0x10000u) & 63u);
                    }
                }
                break;
                l0 = (long)((unsigned long)l0 + 0x7fffffffu);
                x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((short)(r0.y | u0) > (signed char)(unsigned)s0) < (u3 | i1));
                if (((unsigned)(w0 >> 29) / ((unsigned)w0 | 1u))) break;
            }
        } else {
            if ((unsigned)h0) {
                *mp = (unsigned)s1;
                if ((u3 + 0xffffffffu)) break;
                if (budget != 0u) { budget -= 1u; u1 = fn0((u2 * 0x7fffffffu), (r0.x % ((0xffffffffu + p0) | 1u)), ((unsigned)(*q0 == p1) - 0x65305363u)); }
                a0[(unsigned)(i2 < 0xc8d0d578u) & 3u] = (unsigned)!(0x62d0c4cbu + (unsigned)(short)((unsigned)(w0 >> 29) | 0u));
                m0 ^= (g0 << ((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)w0) & 31u));
            } else {
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    continue; (void)(4u);
                    if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)c1, 0x2622073au, (unsigned)d0); }
                    break; (void)(~(0x86cc873cu / ((0x7fffffffu >> (0xc05aadau & 31u)) | 1u)));
                    if ((6u ? (unsigned)d0 : v0)) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(p1 / (garr[u2 & 7u] | 1u)), a0[u1 & 3u], (u1 % ((unsigned)b0 | 1u))); }
                }
                v0 = (((unsigned)(g1 && 0x6e994518u) & r0.x) + (unsigned)((unsigned)h1 < 3u));
                *q0 = (unsigned)((int)(unsigned)(i0 == m0) >= (int)(0x7fffffffu - garr[i1 & 7u]));
                break; (void)((unsigned)(1u || (4u * 0xee04bfd2u)));
            }
            while (i1++ < 6u && (unsigned)(short)(p0 * (2u ^ (unsigned)h0))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1(u2, (unsigned)d0, i2); }
            }
            if ((unsigned)c1) continue;
            do { if (--fuel == 0u) goto done;
                c1 = (signed char)(-(unsigned)((unsigned)((int)7u >= (int)g0) < m0) ^ ((unsigned)(w0 >> 29) % (p1 | 1u)));
                u2 ^= ((unsigned)((int)v0 >= (int)0x99594c96u) / ((unsigned)(*q0 == 0x80000000u) | 1u));
                u1 = u1 * 0x9e3779b1u + ((unsigned)h0 * (u0 | garr[u2 & 7u]));
                if (0xf39f0e76u) {
                    if (((unsigned)c1 * (unsigned)s1)) continue;
                    break; (void)((unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)!(unsigned)((unsigned)w0 < (unsigned)w0)));
                    u3 += ((unsigned)((int)(0x80000000u | 4u) >= (int)3u) | i0);
                    x0 = x0 * 0x100000001b3ull + u3;
                    a0[u2 & 3u] = *q0;
                } else {
                    h0 = (short)((unsigned)((int)0u < (int)fuel) & 0x10000u);
                    for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        switch ((unsigned)b0 & 7u) {
                            case 5u: ;
                        }
                        u0 = u0 * 0x9e3779b1u + (unsigned)d0;
                        if ((9u + r0.y)) goto done;
                    }
                    if (v0) continue;
                }
                break; (void)((unsigned)((unsigned)e0 == i0));
            } while (i1++ < 4u && (unsigned)(signed char)((unsigned)(0x1e47582au || 0x10000u) * 0xcbe6f958u));
        }
        { unsigned t4; double z4; if ((((unsigned)s1 / ((unsigned)((short)0xa5433dc8u > (signed char)(unsigned)h1) | 1u))) & 1u) { t4 = 0x913ff51du; z4 = (double)((((unsigned)w0 | (unsigned)e0)) & 255u); } if ((((unsigned)s1 / ((unsigned)((short)0xa5433dc8u > (signed char)(unsigned)h1) | 1u))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
            if ((unsigned)((int)~(unsigned)((int)r0.x < (int)garr[i1 & 7u]) < (int)0x80000000u)) break;
            c0 = (unsigned char)(i2 & r0.y);
        }
        if (g1) break;
        g1 += i2;
    }
    switch ((unsigned)b0 & 7u) {
        case 6u: ;
    }
    if ((0x7fffffffu % (0x10000u | 1u))) goto L1;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + ((unsigned)(g1 || u0) << ((a0[u1 & 3u] ? garr[u2 & 7u] : 0xffffffffu) & 31u)));
        if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((int)g1 < (int)2u), (unsigned)w0, ((unsigned)s1 / ((unsigned)s1 | 1u))); }
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                *q0 += i2;
            } while (i2++ < 3u && (garr[i1 & 7u] ^ (unsigned)((int)(unsigned)f0 >= (int)v0)));
            u0 ^= (((unsigned)(x0 >> 70) % (p0 | 1u)) * 0x10000u);
            *q0 += ((0xffffffffu ? 0x10000u : 4u) & 0xe995c14eu);
        }
        do { if (--fuel == 0u) goto done;
            break; (void)((0x35f794f5u + (unsigned)c0));
            if ((unsigned)((unsigned)((int)i1 >= (int)0x3582f572u) && p2)) break;
            continue; (void)((unsigned)((unsigned)d0 && (unsigned)s1));
            if (2u) break;
            u0 = u0 * 0x9e3779b1u + (unsigned)((short)(garr[i1 & 7u] / ((unsigned)((unsigned)f0 == (unsigned)((unsigned)c0 || *q0)) | 1u)) > (signed char)(unsigned)f0);
        } while (i1++ < 4u && (i2 >> ((unsigned)c1 & 31u)));
        if (a0[u1 & 3u]) break;
    }
    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(9u || (unsigned)((unsigned)((int)fuel >= (int)u2) && (unsigned)f0)) || *mp) & 255u);
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)x0 / ((unsigned)((int)*mp >= (int)u1) | 1u)), ((unsigned)((int)r0.y < (int)3u) ^ 0x40fd8215u), (a0[u1 & 3u] - (i2 >> (0x10000u & 31u)))); }
        v0 = (v0 / (m0 | 1u));
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(short)(0x1c2aba87u - a0[i0 & 3u]) || u2), 0x10000u, (~(unsigned)(9u || 9u) / (0xffffffffu | 1u))); }
        h0 = (short)0x80000000u;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((int)a0[u1 & 3u] < (int)p1));
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + 0u);
                if ((unsigned)!(a0[i0 & 3u] >> (0xecdf7f2u & 31u))) break;
                goto L4;
                if (0xa6204df3u) {
                    if ((unsigned)((unsigned)h1 || (unsigned)h1)) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn3((m0 ^ 0x36aeb1fau), (((unsigned)l0 ^ (unsigned)x0) & 2u), ~(u2 + (4u % (0x80000000u | 1u)))); }
                    do { if (--fuel == 0u) goto done;
                        if (0x80000000u) continue;
                    } while (i0++ < 6u && (unsigned)(0xffffffffu || *q0));
                    if (u3 == 7u) return (unsigned)((unsigned)(p2 && 0x9d5dbeb9u) == ((unsigned)h0 >> (0xc3b5fa24u & 31u)));
                    c0 = (unsigned char)(unsigned)(i1 || 5u);
                }
                do { if (--fuel == 0u) goto done;
                    switch ((unsigned)((int)(unsigned)c0 >= (int)(unsigned)w0) & 7u) {
                        if (-(a0[i0 & 3u] ^ i0)) goto L4;
                        l0 = (long)((unsigned long)l0 + (unsigned)(i1 && (unsigned)w0));
                        r0.y ^= ((i1 >> ((unsigned)(x0 >> 70) & 31u)) >> ((garr[u2 & 7u] ? 0x7fffffffu : m0) & 31u));
                        u3 += g1;
                        *q0 += ((~(unsigned)(6u == (unsigned)(u2 && (unsigned)b0)) / ((unsigned)c1 | 1u)) - 0xadf9c008u);
                    }
                    g1 += (unsigned)((int)(unsigned)x0 < (int)u1);
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)e0, (unsigned)((u1 & u1) && a0[u1 & 3u]), (unsigned)((int)~((unsigned)e0 * (unsigned)l0) < (int)1u)); }
                    if (fuel < 8u) return ((garr[i1 & 7u] / ((unsigned)(i1 == g1) | 1u)) * 6u);
                    garr[(unsigned)((int)garr[i1 & 7u] < (int)(unsigned)w0) & 7u] = ((p1 % (garr[u2 & 7u] | 1u)) + 0x7fffffffu);
                    c0 = (unsigned char)(unsigned)(signed char)(unsigned)((int)fuel >= (int)(unsigned)w0);
                } while (i0++ < 2u && (unsigned)(p1 || (0x7fffffffu - 0xffffffffu)));
                v0 = ((1u / ((unsigned)(9u && (unsigned)d0) | 1u)) / ((unsigned)w0 | 1u));
            }
            if ((unsigned)((int)0x80000000u >= (int)(unsigned)((int)(unsigned)h1 < (int)u1))) break;
            if (-(5u ^ 5u)) break;
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                u0 += (i1 | ~((unsigned)f0 * 3u));
                g0 = (unsigned)(m0 || u2);
                for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + ((unsigned)e0 << (5u & 31u));
                    c1 = (signed char)(u2 | (unsigned)l0);
                    if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)b0 * (unsigned)h0), ((unsigned)(garr[u2 & 7u] < fuel) | 4u), ((g1 ^ (unsigned)f0) % (a0[u1 & 3u] | 1u))); }
                    if (fuel) break;
                    *mp = ((*mp % ((unsigned)((short)g1 > (signed char)u2) | 1u)) / (((unsigned)s0 | (unsigned)x0) | 1u));
                    a0[(unsigned)(u2 < g1) & 3u] = (u0 | ((unsigned)f0 % ((unsigned)h1 | 1u)));
                }
                { unsigned t5; double z5; if ((((unsigned)(2u == (unsigned)w0) * (unsigned)(x0 >> 70))) & 1u) { t5 = u1; z5 = (double)(((garr[i1 & 7u] ^ (unsigned)x0)) & 255u); } if ((((unsigned)(2u == (unsigned)w0) * (unsigned)(x0 >> 70))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    *q0 += ((unsigned)!(unsigned)((int)(unsigned)((short)0x7fffffffu > (signed char)g0) < (int)0xf3d6bfc3u) ^ (7u << ((unsigned)f0 & 31u)));
                    if (~(0xe5b3eceau | 4u)) break;
                    do { if (--fuel == 0u) goto done;
                        a0[1u & 3u] = (unsigned)((int)((unsigned)e0 | 0x80000000u) < (int)((i1 >> (r0.x & 31u)) ^ v0));
                        q0 = &garr[(u3 | r0.x) & 7u];
                        if (u3 == 7u) return (unsigned)!((unsigned)b0 ^ ((unsigned)w0 | p1));
                        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                            if ((unsigned)s0) continue;
                            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)h1, i2, (7u * i0)); }
                            if (budget != 0u) { budget -= 1u; u2 = fn1(0x10000u, ((u3 * (unsigned)(w0 >> 29)) ^ i2), (g1 - (unsigned)(w0 >> 29))); }
                        }
                        if ((0u ? 0xb9ae7c04u : 0xffffffffu)) goto L2;
                    } while (i0++ < 5u && (a0[u1 & 3u] ? 0x16867d97u : 8u));
                    u2 = (unsigned)(a0[i0 & 3u] || (*q0 - 0x80000000u));
                    switch (0x9954997au & 7u) {
                        if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)(x0 >> 70) / (u0 | 1u)), (g1 & m0), (unsigned)!(unsigned)(-(unsigned)((int)u1 < (int)i1) && *q0)); }
                        e0 = e0 * 0.5L + (long double)(~(unsigned)((short)fuel > (signed char)(unsigned)(-(g1 | (unsigned)s1) && p2)) & 1023u);
                        while (i0++ < 7u && 0x7fffffffu) { if (--fuel == 0u) goto done;
                            u1 += (unsigned)s1;
                            continue; (void)((3u >> ((unsigned)((short)0u > (signed char)i0) & 31u)));
                            if (budget != 0u) { budget -= 1u; u2 = fn0((g1 * (u1 ^ 0x8690a0deu)), ((unsigned)(w0 >> 29) * (a0[i0 & 3u] % (0x23904c57u | 1u))), ((unsigned)x0 << (g1 & 31u))); }
                        }
                    }
                    break; (void)((garr[u2 & 7u] - garr[u2 & 7u]));
                }
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((int)u3 >= (int)0x80000000u), (unsigned)((unsigned)f0 || (0x10000u - 0x7fffffffu)), (unsigned)((int)g1 >= (int)((unsigned)h0 & garr[u2 & 7u]))); }
                if (((a0[i0 & 3u] << ((unsigned)h1 & 31u)) % ((unsigned)c0 | 1u))) goto L0;
            }
            m0 ^= ((unsigned)((i1 - p0) < (unsigned)((int)(unsigned)l0 < (int)g1)) << (i0 & 31u));
        }
    } while (i0++ < 2u && (unsigned)s1);
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)s1 || (unsigned)b0), (unsigned)(*q0 < g1), (4u & 0x3f5b7c8fu)); }
        if (*q0) {
            { unsigned t6; double z6; if ((g1) & 1u) { t6 = (garr[i1 & 7u] | (unsigned)f0); z6 = (double)((0x18d6d64u) & 255u); } if ((g1) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)garr[u2 & 7u] < (int)fuel)) break;
                    break; (void)((unsigned)b0);
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)u2 >= (int)(unsigned)((short)(9u / ((u1 & 0x80000000u) | 1u)) > (signed char)(unsigned)(w0 >> 29)));
                    if ((5u % ((0xac8b64beu / ((unsigned)d0 | 1u)) | 1u))) break;
                } while (i1++ < 4u && ((unsigned)c1 | (unsigned)((unsigned)f0 || *mp)));
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (0xffffffffu << ((((unsigned)h1 >> (i1 & 31u)) / ((unsigned)l0 | 1u)) & 31u));
                    if ((unsigned)((int)2u >= (int)(unsigned)d0)) continue;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn2(*mp, garr[u2 & 7u], ((unsigned)c1 >> (0x80000000u & 31u))); }
                i1 = (*mp + ((unsigned)((unsigned)l0 && v0) + (unsigned)(0x7fffffffu || a0[u1 & 3u]))) & 15u;
                w0 ^= (unsigned long long)(unsigned)(u2 == (unsigned)e0) << (((0x7fffffffu + i1) % ((0x4eaa7cefu % (0xffffffffu | 1u)) | 1u)) & 63u);
            }
            break; (void)((2u + (0xffffffffu << (0x186837fau & 31u))));
            w0 = w0 * 6364136223846793005ull + (-(garr[i1 & 7u] * 2u) << ((unsigned)(signed char)(((unsigned)e0 * u1) >> (i1 & 31u)) & 31u));
            if ((r0.x ? garr[u2 & 7u] : (unsigned)s0)) goto L2;
        }
        r0.x = ((i1 + (unsigned)c1) % (garr[u2 & 7u] | 1u));
        b0 = (unsigned)(unsigned char)((unsigned)s0 & v0) != 0u;
    } while (i0++ < 2u && (unsigned)((short)garr[u2 & 7u] > (signed char)*mp));
    u1 = u1 * 0x9e3779b1u + (unsigned)l0;
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(2u == (unsigned)((short)(unsigned)x0 > (signed char)fuel)), ~(unsigned)((int)(unsigned)((unsigned)h0 == 2u) < (int)0xffffffffu), (unsigned)((int)((unsigned)b0 | g1) >= (int)garr[i1 & 7u])); }
    if (u3 == 7u) return (unsigned)l0;
    for (;;) { if (--fuel == 0u) goto done;
        while (i1++ < 4u && ((unsigned)(short)(unsigned)((int)0xffffffffu >= (int)garr[u2 & 7u]) >> (0x516cdc14u & 31u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn3(~((unsigned)e0 * (unsigned)e0), ((p0 | 0xba538ec6u) | u0), (unsigned)!(5u * (*mp + garr[u2 & 7u]))); }
            if (budget != 0u) { budget -= 1u; u2 = fn3(fuel, (unsigned)(0x2f101fd9u < ~((unsigned)e0 & garr[i1 & 7u])), a0[i0 & 3u]); }
            if (a0[i0 & 3u]) {
                garr[(unsigned)(unsigned char)((unsigned)l0 ^ 0x7fffffffu) & 7u] = (unsigned)(short)(g0 + (2u ^ 6u));
                u2 += (unsigned)!(unsigned)((fuel + *q0) || 5u);
                goto L1;
                switch ((unsigned)(x0 >> 70) & 7u) {
                    c0 = (unsigned char)(a0[u1 & 3u] ? *q0 : a0[i0 & 3u]);
                }
            } else {
                continue; (void)((unsigned)c0);
                if (((0xa21ae5a6u - 0x33dbad81u) * (unsigned)s1)) break;
                if ((unsigned)((unsigned)e0 == (0u << (a0[i0 & 3u] & 31u)))) goto L3;
                if ((unsigned)((short)(unsigned)((unsigned)h0 == 0x80000000u) > (signed char)u1)) break;
            }
            u0 ^= (unsigned)((int)u3 < (int)-(unsigned)((unsigned)h1 < fuel));
        }
        goto L0;
        if ((p0 / (0x870f6841u | 1u))) break;
        h0 = (short)(unsigned)(((unsigned)c0 + ((unsigned)d0 ^ g0)) < *mp);
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((u2 ^ 0x1a2631f8u)) {
                if (budget != 0u) { budget -= 1u; u3 = fn0(0x7fffffffu, ((unsigned)d0 + (unsigned)h1), (unsigned)!((unsigned)s1 + (unsigned)(x0 >> 70))); }
                u2 = (unsigned)((int)*mp >= (int)u0);
                u2 = u2 * 0x9e3779b1u + (a0[u1 & 3u] / (0xffffffffu | 1u));
                if (a0[u1 & 3u]) break;
                q0 = &garr[((*q0 ^ (unsigned)((short)0xc7d14491u > (signed char)(p1 % (*mp | 1u)))) << (garr[u2 & 7u] & 31u)) & 7u];
                if (budget != 0u) { budget -= 1u; u3 = fn3(7u, 0xa47f3347u, a0[i0 & 3u]); }
            }
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((u3 - *mp)) break;
                x0 = x0 * 0x100000001b3ull + ((unsigned)((int)(u3 / (0x1c432f2eu | 1u)) >= (int)(unsigned)s0) + (0x7fffffffu | r0.x));
                w0 ^= (unsigned long long)i1 << ((r0.y >> ((fuel << ((unsigned)((short)i2 > (signed char)(unsigned)w0) & 31u)) & 31u)) & 63u);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0xb8f963c9u || (unsigned)((int)garr[u2 & 7u] < (int)5u)), garr[i1 & 7u], (unsigned)c0); }
            }
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                u0 ^= ((unsigned)d0 >> ((unsigned)((int)-(p1 + u0) < (int)((unsigned)s1 >> (g0 & 31u))) & 31u));
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)c1, p2, 0x80000000u); }
                break; (void)((i1 * v0));
                u0 = u0 * 0x9e3779b1u + ((unsigned)(a0[i0 & 3u] < u2) | -(7u + r0.x));
                i0 = ((unsigned)!((unsigned)s0 & 2u) - (0x7fffffffu | (unsigned)((int)0xd858e194u < (int)0x10000u))) & 15u;
            }
            if ((((unsigned)h1 | (unsigned)d0) | (unsigned)d0)) continue;
            x0 = x0 * 0x100000001b3ull + (unsigned)((int)(u1 % ((*q0 * 0x10000u) | 1u)) < (int)((unsigned)l0 / (*mp | 1u)));
            break; (void)((unsigned)(signed char)(unsigned)(-(0x80000000u - 2u) < r0.y));
        }
        break; (void)((unsigned)(short)(unsigned)((short)(unsigned)(7u < 8u) > (signed char)0x33e50e4fu));
    }
    i2 = ((unsigned)(fuel && 0x74adf61u) - v0) & 15u;
    do { if (--fuel == 0u) goto done;
        continue; (void)((unsigned)!(i0 | (unsigned)((int)i0 < (int)g1)));
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            while (i2++ < 7u && 0u) { if (--fuel == 0u) goto done;
                break; (void)(0u);
                break; (void)((unsigned)(x0 >> 70));
            }
            while (i2++ < 7u && i2) { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (unsigned)(0x80000000u || (unsigned)s0) != 0u;
                    u2 ^= (i2 / (7u | 1u));
                    u3 = (unsigned)l0;
                    if (((unsigned)s1 - ((unsigned)(w0 >> 29) ^ u0))) break;
                    e0 = e0 * 0.5L + (long double)((unsigned)((m0 | 3u) && (unsigned)!(unsigned)(2u || (unsigned)(0xffffffffu == (unsigned)e0))) & 1023u);
                    d0 = d0 * 0.5 + (double)((i0 * (unsigned)x0) & 1023u);
                }
                *mp = (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)(*mp < (unsigned)x0));
            }
            r0.x = (unsigned)(unsigned char)((unsigned)(1u && (g0 ^ u3)) << (0x96716efcu & 31u));
        }
        if ((((unsigned)d0 % (r0.y | 1u)) & 0x10000u)) break;
        break; (void)((0x7fffffffu % (((unsigned)(w0 >> 29) / (6u | 1u)) | 1u)));
        h1 = (unsigned short)(h1 + i2);
    } while (i0++ < 2u && -((unsigned)s1 << (garr[u2 & 7u] & 31u)));
    if (((4u ^ p2) % (8u | 1u))) goto L2;
    f0 = f0 * 0.5f + (float)(((unsigned)h0 >> ((unsigned)h0 & 31u)) & 255u);
    g0 = ((1u & (a0[u1 & 3u] + 5u)) % (0xffffffffu | 1u));
    goto L0;
    goto L3;
    while ((unsigned)((unsigned)x0 && g0)) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)e0);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 4u, 0x38c6bf47u, 0x4b2be976u },
        { 5u, 0x198c461u, 0xb93f34f2u },
        { 3u, 0x7011d86cu, 0xdc130d28u },
        { 13u, 0x5a5b725du, 0x8716cd19u },
        { 14u, 0x59abe144u, 0x4074079u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
