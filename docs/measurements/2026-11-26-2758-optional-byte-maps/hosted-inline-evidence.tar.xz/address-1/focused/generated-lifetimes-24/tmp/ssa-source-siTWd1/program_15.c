// test-ssa-source's program of seed 141000438 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xbf12a0b6u, g1 = 0x5feb64efu;
static unsigned garr[8] = { 0x142aafccu, 0x2fed5d5cu, 0x1a5145f9u, 0xe76a5274u, 0x36562187u, 0x4679667u, 0x4e95407au, 0x4b0cc514u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)l0) goto L4;
    if ((unsigned)(w0 >> 29)) goto L4;
    d0 = d0 * 0.5 + (double)((unsigned)(signed char)(m0 << ((unsigned)(unsigned char)(unsigned)((short)(unsigned)(6u == (unsigned)l0) > (signed char)p0) & 31u)) & 1023u);
    do { if (--fuel == 0u) goto done;
        if (i1) {
            *q0 += (unsigned)((0x80000000u + (unsigned)((short)p0 > (signed char)0x10000u)) && 0x80000000u);
            do { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)(short)(u2 ? (unsigned)(4u < (unsigned)c0) : 1u) & 7u];
                switch (a0[i0 & 3u] & 7u) {
                    if (fuel < 8u) return (unsigned)((short)(unsigned)h0 > (signed char)r0.x);
                    case 6u: ;
                    L1: if (--fuel == 0u) goto done;
                    L2: if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)(((0x7fffffffu ^ i1) + (unsigned)(0u < 5u)) & 255u);
                    case 2u: ;
                }
                continue; (void)(0x7fffffffu);
                v0 = (garr[i1 & 7u] * (-(unsigned)((int)6u >= (int)(unsigned)e0) % ((unsigned)l0 | 1u)));
            } while (i1++ < 2u && (fuel & u0));
            if ((unsigned)((int)(unsigned)(short)(unsigned)((int)i0 >= (int)3u) < (int)(unsigned)b0)) break;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(0x4c593659u < (0x80000000u | 0x33bfb145u))) goto done;
                *mp = m0;
                L3: if (--fuel == 0u) goto done;
            }
            L4: if (--fuel == 0u) goto done;
            if ((unsigned)w0) break;
        } else {
            *q0 = (unsigned)(unsigned char)(0x10000u | u2);
            if (p1) goto L0;
            s1 = (int)((unsigned)s1 + ((0xb3263802u * ((unsigned)(x0 >> 70) ^ (unsigned)(w0 >> 29))) << (0x1351d551u & 31u)));
        }
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            b0 = (unsigned)(u3 < (-(unsigned)(0x80000000u && (unsigned)f0) * (unsigned)(w0 >> 29))) != 0u;
            break; (void)((0x4bff1fa4u << (p2 & 31u)));
        }
    } while (i0++ < 7u && ((unsigned)e0 << ((unsigned)(0x7fffffffu < 0x80000000u) & 31u)));
    r0.x = (unsigned)((unsigned)b0 == (unsigned)s1);
    if (p2) goto L2;
    if (-((unsigned)s1 << (0xa2d1c688u & 31u))) goto L0;
    while (i0++ < 5u && (unsigned)((int)i2 >= (int)p0)) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + ((unsigned)(7u == 9u) ^ g0));
        if ((unsigned)x0) {
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (unsigned)(~(0xe3677990u - 0x10000u) || (unsigned)(u3 < r0.y));
                    c1 = (signed char)(unsigned)c0;
                } while (i2++ < 4u && (p1 ^ (p1 - p1)));
            }
            break; (void)(0x9cdd9891u);
            if (((unsigned)x0 * 3u)) continue;
            h1 = (unsigned short)(h1 + ((unsigned)c0 >> (p2 & 31u)));
            break; (void)((unsigned)(garr[u2 & 7u] < u2));
        } else {
            h0 = (short)(unsigned)(garr[i1 & 7u] < ((unsigned)s0 + (unsigned)((int)(unsigned)d0 < (int)(unsigned)((short)p2 > (signed char)(unsigned)c1))));
            u2 ^= (unsigned)((int)u0 < (int)(unsigned)(garr[u2 & 7u] == ((unsigned)((int)u0 < (int)0xffffffffu) - i2)));
            if ((unsigned)c1) {
                u0 += (unsigned)((int)0x10000u < (int)(*q0 + i1));
                u0 += u1;
            }
            if (((0x7fffffffu << (p0 & 31u)) * garr[u2 & 7u])) {
                *q0 = ((*q0 * ((unsigned)d0 ? 2u : 3u)) + (unsigned)e0);
                switch (((unsigned)b0 % ((m0 | r0.y) | 1u)) & 7u) {
                    switch (p1 & 7u) {
                        case 1u: ;
                        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                            case 5u: ;
                            default: ;
                            case 0u: ;
                        }
                        w0 = w0 * 6364136223846793005ull + (unsigned)((short)((unsigned)(signed char)(u0 >> (0xe87b0ce7u & 31u)) * ((unsigned)f0 & 0u)) > (signed char)9u);
                    }
                    m0 ^= (unsigned)((int)(unsigned)(short)(g1 ^ (unsigned)(0u == u3)) >= (int)(r0.x + 0xc969b1f2u));
                    goto L2;
                    w0 ^= (unsigned long long)m0 << ((unsigned)((int)((unsigned)h1 << (0x6a1d06d3u & 31u)) >= (int)a0[u1 & 3u]) & 63u);
                    if ((*mp | (unsigned)!(unsigned)((int)0xd8143f3eu < (int)0x997572d8u))) {
                        do { if (--fuel == 0u) goto done;
                            case 5u: ;
                            q0 = &garr[(0x80000000u >> ((unsigned)(w0 >> 29) & 31u)) & 7u];
                            garr[(p0 & 9u) & 7u] = (unsigned)((short)0x331a3768u > (signed char)(unsigned)((short)(unsigned)((int)(unsigned)(w0 >> 29) < (int)m0) > (signed char)(unsigned)l0));
                            goto L2;
                            case 6u: ;
                            continue; (void)(p0);
                        } while (i1++ < 7u && (unsigned)(signed char)(i1 % (0xffffffffu | 1u)));
                        goto L2;
                    } else {
                        if ((unsigned)(signed char)(unsigned)((int)*mp >= (int)(unsigned)((short)u3 > (signed char)a0[i0 & 3u]))) {
                            case 2u: ;
                            q0 = &garr[((unsigned)!(unsigned)((short)0xdee77dfdu > (signed char)0x2667d02du) - (unsigned)(w0 >> 29)) & 7u];
                            case 7u: ;
                            if (-(unsigned)((unsigned)h0 && (unsigned)(garr[i1 & 7u] == a0[i0 & 3u]))) goto done;
                        } else {
                            l0 = (long)((unsigned long)l0 + (unsigned)(g0 == u1));
                        }
                    }
                    s0 = (int)(unsigned)(short)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)u3);
                }
                if (0x35ce5acfu) break;
            }
        }
        r0.x = ~(((unsigned)c0 * (unsigned)l0) & 0xe62b82ceu);
        if ((unsigned)h1) continue;
    }
    b0 = (unsigned)((unsigned)((unsigned)((int)0x58fef65bu >= (int)4u) == 0xe5483be5u) || 0x9b7aadd8u) != 0u;
    if ((unsigned)c0) goto L2;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)(((0x8267cf2fu >> (0u & 31u)) / (((unsigned)s1 ^ (unsigned)f0) | 1u)) & 255u);
    }
    { unsigned t0; double z0; if ((0x80000000u) & 1u) { t0 = (unsigned)(unsigned char)(0xee114fd6u ^ (unsigned)(6u && (unsigned)c0)); z0 = (double)(((unsigned)(unsigned char)((unsigned)c1 & ((unsigned)(x0 >> 70) / ((unsigned)f0 | 1u)))) & 255u); } if ((0x80000000u) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        goto done;
        v0 = fuel;
        s0 = (int)((unsigned)((int)u3 >= (int)0x5c066265u) >> (((unsigned)c0 & (unsigned)h0) & 31u));
        goto L2;
    }
    g1 += (unsigned)(short)(unsigned)(((0x34a5565cu ^ g0) + r0.y) && p1);
    e0 = e0 * 0.5L + (long double)(((unsigned)d0 / (i0 | 1u)) & 1023u);
    w0 ^= (unsigned long long)(unsigned)h1 << (-((unsigned)h0 + (fuel & g1)) & 63u);
    while (i0++ < 6u && (unsigned)((short)g0 > (signed char)garr[i1 & 7u])) { if (--fuel == 0u) goto done;
        s0 = (int)(fuel & (unsigned)c1);
        m0 ^= (unsigned)h1;
        *q0 += (i1 ? (unsigned)f0 : u2);
        if ((u3 / (((unsigned)c1 - (unsigned)d0) | 1u))) break;
        if ((unsigned)(v0 == p0)) break;
    }
    { unsigned t1; double z1; if (((unsigned)x0) & 1u) { t1 = -(unsigned)(0xd2b89076u == 9u); z1 = (double)(((unsigned)!(garr[u2 & 7u] ? 4u : 0x7fffffffu)) & 255u); } if (((unsigned)x0) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        i0 = (r0.y >> (0u & 31u)) & 15u;
        q0 = &garr[((7u | (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)p1)) / (a0[i0 & 3u] | 1u)) & 7u];
        if (u3) goto L1;
        if ((0x10000u * (unsigned)(w0 >> 29))) {
            goto L1;
            if (a0[u1 & 3u]) goto L3;
            if (((unsigned)(w0 >> 29) - g0)) goto L2;
            if ((u2 * 0x7fffffffu)) goto done;
        } else {
            if (0x431449du) goto L3;
            g1 += r0.x;
            a0[0u & 3u] = (u1 & (unsigned)((short)(i0 + garr[i1 & 7u]) > (signed char)(unsigned)(6u || (unsigned)(x0 >> 70))));
        }
        l0 = (long)((unsigned long)l0 + (1u / (r0.y | 1u)));
        i0 = -((i0 >> ((unsigned)h1 & 31u)) & (unsigned)e0) & 15u;
    }
    c0 = (unsigned char)((unsigned)c1 - ((unsigned)(x0 >> 70) - (unsigned)h0));
    if (((0xffffffffu >> ((unsigned)w0 & 31u)) >> (*mp & 31u))) {
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)f0 % (g0 | 1u))) break;
        }
        { unsigned t2; double z2; if (((unsigned)f0) & 1u) { t2 = (unsigned)l0; z2 = (double)((((unsigned)(x0 >> 70) << ((unsigned)!(unsigned)((int)0x80000000u >= (int)p1) & 31u))) & 255u); } if (((unsigned)f0) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            goto L2;
            e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)l0 == r0.x) & 1023u);
        }
    }
    s0 = (int)(unsigned)(signed char)(3u ? (unsigned)((unsigned)s1 || (unsigned)(x0 >> 70)) : (0xffffffffu * (unsigned)c1));
    if ((unsigned)((int)(unsigned)b0 < (int)u2)) goto L0;
    while (i0++ < 4u && *mp) { if (--fuel == 0u) goto done;
        if (((0x10000u ^ 0xf948bff7u) / (0xc5c530f6u | 1u))) {
            u0 = (6u + (unsigned)((unsigned)h0 < a0[i0 & 3u]));
            switch (((0xffffffffu ^ (unsigned)b0) % (p1 | 1u)) & 7u) {
                if (*q0) {
                    goto L0;
                } else {
                    case 0u: ;
                }
                m0 ^= (r0.x << ((unsigned)(x0 >> 70) & 31u));
                if (0xdf706b8fu) {
                    if (((unsigned)x0 ^ r0.x)) {
                        case 7u: ;
                        u1 += *q0;
                        case 5u: ;
                        if (fuel < 8u) return (unsigned)(0x10000u < garr[i1 & 7u]);
                    }
                } else {
                    case 4u: ;
                    while (v0) { if (--fuel == 0u) goto done;
                        if ((r0.x + 0x66718707u)) goto L3;
                        b0 = ((unsigned)f0 << ((unsigned)(signed char)(0xffffffffu - (i0 - a0[u1 & 3u])) & 31u)) != 0u;
                        do { if (--fuel == 0u) goto done;
                            i0 = (unsigned)((6u << (0xa98e5183u & 31u)) < ((unsigned)x0 / (*q0 | 1u))) & 15u;
                            if ((u1 - 4u)) continue;
                            h1 = (unsigned short)(h1 + (unsigned)((short)0x92dbd35eu > (signed char)(r0.y & (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)((int)0x80000000u >= (int)9u)))));
                            c1 = (signed char)((v0 / (((unsigned)f0 + (unsigned)e0) | 1u)) ? 0x10000u : 0x2f8eba07u);
                        } while (i2++ < 3u && -((unsigned)c1 % ((unsigned)((unsigned)b0 == 0x2cd50534u) | 1u)));
                        switch (0x7a46e6ffu & 7u) {
                            case 1u: ;
                            a0[(unsigned)l0 & 3u] = *mp;
                            a0[0x9776754fu & 3u] = (unsigned)(short)((unsigned)s0 & (unsigned)((int)g1 < (int)i2));
                            u2 ^= (unsigned)((int)u2 >= (int)((unsigned)c1 >> (0u & 31u)));
                        }
                        case 1u: ;
                    }
                    a0[(3u | 0u) & 3u] = ((unsigned)(short)(((unsigned)(x0 >> 70) << (i0 & 31u)) / ((0xffffffffu << (i0 & 31u)) | 1u)) / ((unsigned)e0 | 1u));
                    c1 = (signed char)(p1 ^ g0);
                }
                default: ;
            }
        }
        if ((unsigned)((int)u2 >= (int)(unsigned)(w0 >> 29))) break;
    }
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)(p0 < (unsigned)h1)) break;
    }
    while (i0++ < 2u && (unsigned)(((unsigned)b0 / (r0.x | 1u)) || m0)) { if (--fuel == 0u) goto done;
        break; (void)(0u);
        break; (void)(9u);
        switch ((unsigned)(3u && garr[u2 & 7u]) & 7u) {
            if ((*mp >> (0x355be4du & 31u))) goto L0;
        }
    }
    x0 = x0 * 0x100000001b3ull + ((unsigned)(short)(g0 + 0xf06d1900u) >> (0x80000000u & 31u));
    { unsigned t3; double z3; if ((0xffffffffu) & 1u) { t3 = (unsigned)l0; z3 = (double)(((unsigned)h1) & 255u); } if ((0xffffffffu) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        if ((p0 & (unsigned)(0x10000u && (unsigned)f0))) {
            switch ((unsigned)((int)(p0 + 3u) >= (int)0x10000u) & 7u) {
                a0[(g0 + fuel) & 3u] = ((*q0 - (unsigned)l0) | 0x80000000u);
                case 2u: ;
            }
            do { if (--fuel == 0u) goto done;
                break; (void)((unsigned)((unsigned)((short)(unsigned)l0 > (signed char)u3) < u1));
                if (((0x7fffffffu - (unsigned)d0) + *mp)) break;
                if ((unsigned)x0) goto L0;
                c0 = (unsigned char)(unsigned)((int)(unsigned)h0 >= (int)(unsigned)((short)r0.y > (signed char)(unsigned)(r0.x == 0x255b74eau)));
            } while (i0++ < 3u && (((unsigned)l0 + p1) * (unsigned)h1));
            if ((unsigned)(2u == (unsigned)(w0 >> 29))) {
                s0 = (int)(unsigned)((unsigned)(p2 || garr[u2 & 7u]) < 5u);
                goto L2;
                c1 = (signed char)(unsigned)(short)(unsigned)((unsigned)e0 == (6u | (*q0 - fuel)));
                s1 = (int)((unsigned)s1 + (unsigned)(p1 && (unsigned)((int)3u >= (int)(g1 & (unsigned)c1))));
                if ((unsigned)(unsigned char)(unsigned)((int)(i2 ^ i0) >= (int)(unsigned)h1)) goto L2;
                if ((p1 & (0xe156df91u - *mp))) {
                    goto L4;
                    if ((unsigned)((int)u2 < (int)5u)) goto L4;
                    while ((unsigned)(unsigned char)(0u - (0x10000u % (0x7fffffffu | 1u)))) { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((short)r0.x > (signed char)0x265d0566u));
                        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                            r0.y ^= 0x80000000u;
                        }
                        garr[(unsigned)c1 & 7u] = (u3 + (((unsigned)((int)g0 >= (int)(unsigned)c0) * (unsigned)d0) - garr[i1 & 7u]));
                        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                            break; (void)((u1 + 1u));
                            break; (void)((unsigned)x0);
                            if ((p1 & (unsigned)(v0 == 0x10000u))) break;
                            if ((unsigned)((int)(6u / (m0 | 1u)) >= (int)u2)) break;
                            g1 += 4u;
                        }
                    }
                    if (p1) goto L3;
                }
            }
            if ((unsigned)h1) goto L3;
            if ((unsigned)(unsigned char)(m0 - 0u)) goto L0;
            if (((unsigned)h0 >> (~(unsigned)(garr[i1 & 7u] && m0) & 31u))) goto L3;
        } else {
            g0 = (a0[i0 & 3u] ? 0x4c838535u : u1);
            if ((a0[u1 & 3u] / ((unsigned)s0 | 1u))) goto L0;
        }
        if ((unsigned)((short)0x67cb81bdu > (signed char)(unsigned)((unsigned)h1 && 0x7fffffffu))) {
            goto L0;
            if (-(r0.x ? fuel : fuel)) goto L0;
            goto done;
        } else {
            if (u3 == 7u) return (unsigned)(signed char)(unsigned)((int)(unsigned)c1 < (int)0x7fffffffu);
            garr[(unsigned)((unsigned)h0 < (unsigned)c1) & 7u] = (unsigned)((short)(unsigned)((int)(unsigned)(unsigned char)(unsigned)(~(0x80000000u | g0) < v0) < (int)p0) > (signed char)(unsigned)h0);
            if (((unsigned)((int)*mp < (int)0x10000u) & p2)) goto L2;
        }
    }
    if (0x7fffffffu) goto L4;
    if ((unsigned)s0) {
        w0 = w0 * 6364136223846793005ull + (unsigned)(0x6c6df6f3u && (g0 % ((unsigned)f0 | 1u)));
    }
    if (u3 == 7u) return (unsigned)((int)1u >= (int)(m0 & u2));
    r0.x = (unsigned)(0x80000000u || (unsigned)w0);
    if ((0u * (unsigned)((int)(unsigned)b0 < (int)(unsigned)h0))) goto L4;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)((0x10000u % ((unsigned)c1 | 1u)) == 0x8bb5ff79u);
        }
        if ((0u + (unsigned)s1)) goto L1;
    }
    do { if (--fuel == 0u) goto done;
        u2 ^= ((a0[u1 & 3u] | a0[i0 & 3u]) - 0x2db8f6a7u);
        i0 = (0x7fffffffu / (0xc80adc9cu | 1u)) & 15u;
        if (~(a0[u1 & 3u] << (a0[i0 & 3u] & 31u))) break;
        if ((0x80000000u + ((unsigned)c1 & fuel))) break;
        if ((fuel - 0x533ac789u)) break;
    } while (i0++ < 7u && ((0x3ae49165u ^ (unsigned)h0) ^ 0xae02448u));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)-(unsigned)((u1 >> (u2 & 31u)) && (unsigned)((unsigned)h0 || (unsigned)f0));
        break; (void)((unsigned)((short)0x3f5c5d92u > (signed char)p1));
        *mp = (0x7fffffffu >> ((0xffffffffu << (2u & 31u)) & 31u));
        u1 = u1 * 0x9e3779b1u + (unsigned)(short)(r0.x ? (0x5e58efabu % ((*q0 << ((unsigned)s0 & 31u)) | 1u)) : 8u);
        if (p0) {
            break; (void)((garr[u2 & 7u] / (0x10000u | 1u)));
            c1 = (signed char)((unsigned)((short)i2 > (signed char)garr[u2 & 7u]) | p2);
            w0 ^= (unsigned long long)-(0x7fffffffu ^ p1) << ((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)f0) & 63u);
            if ((unsigned)(0x80000000u || (unsigned)c1)) continue;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)((short)garr[i1 & 7u] > (signed char)0x80000000u) < (int)u2)) goto L4;
            }
        } else {
            if ((unsigned)((int)a0[i0 & 3u] >= (int)r0.x)) goto L3;
            s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)(0x5ef40175u == p1) >= (int)(unsigned)s1));
            break; (void)((unsigned)c0);
            switch ((0xb3da5d49u % (i0 | 1u)) & 7u) {
                { unsigned t4; double z4; if ((0x7fffffffu) & 1u) { t4 = (unsigned)((unsigned)e0 || (unsigned)c0); z4 = (double)(((m0 ^ 0x7fffffffu)) & 255u); } if ((0x7fffffffu) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                    for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        case 5u: ;
                        case 1u: ;
                        case 3u: ;
                        s0 = (int)(unsigned)((short)(0x434e0003u | (unsigned)((int)0x803b329au >= (int)0xffffffffu)) > (signed char)g1);
                        garr[(unsigned)d0 & 7u] = ((unsigned)((int)(unsigned)c0 < (int)(unsigned)b0) >> ((unsigned)(short)(unsigned)((unsigned)b0 == ((unsigned)e0 - (unsigned)f0)) & 31u));
                        g0 = ((unsigned)x0 % ((unsigned)((short)r0.x > (signed char)(unsigned)(g1 < 2u)) | 1u));
                    }
                    case 4u: ;
                }
                if (0xe2e4148u) continue;
                case 0u: ;
            }
        }
        if ((1u ? (unsigned)c0 : a0[u1 & 3u])) break;
    }
    u3 = u3 * 0x9e3779b1u + (g0 & (0x80000000u * 0xffffffffu));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    g1 += ((unsigned)(signed char)(unsigned)((unsigned)s0 == *q0) & ~(i2 & a0[u1 & 3u]));
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        goto L4;
        e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)e0 > (signed char)0xffffffffu) & 1023u);
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(((unsigned)d0 / (0x976e50ceu | 1u)) == (unsigned)(x0 >> 70)), ((unsigned)s1 ^ p2), (unsigned)((int)5u >= (int)~(unsigned)(0x7fffffffu < r0.y))); }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)0x2d8fc202u;
            L0: if (--fuel == 0u) goto done;
            h0 = (short)(0x67a0d5f1u ? (p1 % (garr[i1 & 7u] | 1u)) : u2);
        }
        L1: if (--fuel == 0u) goto done;
    }
    if (((unsigned)s1 >> (0xc264b48u & 31u))) goto L3;
    l0 = (long)((unsigned long)l0 + (0x80000000u % (0xffffffffu | 1u)));
    if ((v0 << ((unsigned)d0 & 31u))) goto L2;
    goto L1;
    w0 = w0 * 6364136223846793005ull + ((unsigned)(*q0 || (u1 - (unsigned)((int)*mp >= (int)i2))) % (8u | 1u));
    if ((unsigned)((int)0xff20a0ddu < (int)2u)) goto L2;
    if (u3 == 7u) return ((i1 * r0.x) ^ (unsigned)c1);
    if (i1) goto L1;
    if ((p0 >> (9u & 31u))) {
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (u3) {
                g1 += (unsigned)((int)r0.x < (int)i0);
                if (budget != 0u) { budget -= 1u; u2 = fn0((*mp - 0x80000000u), g0, ((unsigned)h1 ^ (0xeaf02b99u / ((unsigned)l0 | 1u)))); }
                *q0 = (unsigned)((int)0x10000u < (int)fuel);
                x0 = x0 * 0x100000001b3ull + (a0[i0 & 3u] - 4u);
            }
            if (fuel) goto L4;
            m0 ^= ((unsigned)f0 >> (((unsigned)s0 << (a0[u1 & 3u] & 31u)) & 31u));
            while (i1++ < 6u && g0) { if (--fuel == 0u) goto done;
                if (garr[i1 & 7u]) continue;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)c0, (p2 / (r0.x | 1u)), (fuel ^ 0x7fffffffu)); }
                a0[i2 & 3u] = -(((unsigned)(w0 >> 29) - 5u) / ((r0.x >> (i0 & 31u)) | 1u));
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((-(g0 + u1) - 0xf0d1dd17u));
                    if (budget != 0u) { budget -= 1u; u2 = fn0(i0, (unsigned)((int)*mp >= (int)0x53474349u), (unsigned)((int)(unsigned)(x0 >> 70) < (int)0xf8a2ceb2u)); }
                    L2: if (--fuel == 0u) goto done;
                }
                if ((8u % (0xeda5eac8u | 1u))) break;
            }
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            u2 ^= (unsigned)((unsigned)((int)v0 < (int)(unsigned)(x0 >> 70)) || 0xffffffffu);
            v0 = ((unsigned)x0 >> ((unsigned)!(unsigned)((unsigned)s1 && ((unsigned)x0 | (unsigned)((int)*q0 < (int)(unsigned)f0))) & 31u));
            h0 = (short)g1;
            u3 += a0[u1 & 3u];
            v0 = (unsigned)((short)0x10000u > (signed char)(unsigned)(((unsigned)(w0 >> 29) | (unsigned)s1) && -(unsigned)(u1 < *q0)));
        }
        { unsigned t0; double z0; if ((u0) & 1u) { t0 = (unsigned)b0; z0 = (double)((i1) & 255u); } if ((u0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            if (budget != 0u) { budget -= 1u; u1 = fn0((u0 >> (0x6c1c0484u & 31u)), (-(unsigned)((short)0x5d1aada0u > (signed char)(unsigned)w0) % ((unsigned)c0 | 1u)), 9u); }
            goto done;
        }
        switch (p0 & 7u) {
            *q0 = g0;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((unsigned)s0 || 0x1f86ee9u) ^ (unsigned)l0), (u1 / ((unsigned)h0 | 1u)), ~(g0 % (((unsigned)(w0 >> 29) * 7u) | 1u))); }
            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((unsigned)w0 < ((unsigned)f0 / (0x9811e84u | 1u))) && r0.y) & 1023u);
        }
    } else {
        if (fuel < 8u) return (unsigned)((unsigned)((int)a0[i0 & 3u] >= (int)*mp) && ~(u3 & (unsigned)s1));
        { unsigned t1; double z1; if ((0x7fffffffu) & 1u) { t1 = (u0 >> ((unsigned)((unsigned)h1 && u1) & 31u)); z1 = (double)(((unsigned)(i1 && 0u)) & 255u); } if ((0x7fffffffu) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            L3: if (--fuel == 0u) goto done;
            if ((unsigned)(((unsigned)(x0 >> 70) >> ((unsigned)(x0 >> 70) & 31u)) && 4u)) {
                goto L1;
                u2 = u2 * 0x9e3779b1u + ((unsigned)s0 >> (0x80000000u & 31u));
                if (budget != 0u) { budget -= 1u; u1 = fn0((g0 << (v0 & 31u)), (unsigned)c0, (0x10000u ^ 0xffffffffu)); }
                if (budget != 0u) { budget -= 1u; u1 = fn0((*mp & i2), -(unsigned)(0xd67b6d7au && (p2 - (unsigned)h0)), (v0 * (unsigned)s1)); }
            }
            v0 = ((unsigned)(signed char)(-(u2 + 6u) * (0u & u3)) - i2);
        }
    }
    if (u3 == 7u) return (unsigned)((u3 + 0x18692488u) < (unsigned)(signed char)(a0[u1 & 3u] >> ((0u / (*q0 | 1u)) & 31u)));
    while (i0++ < 5u && (garr[i1 & 7u] - 0x7fffffffu)) { if (--fuel == 0u) goto done;
        { unsigned t2; double z2; if ((~(u0 | garr[i1 & 7u])) & 1u) { t2 = (unsigned)(*mp == (0x7fffffffu << (r0.y & 31u))); z2 = (double)(((unsigned)(0x10000u && (unsigned)(a0[i0 & 3u] < u3))) & 255u); } if ((~(u0 | garr[i1 & 7u])) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            if ((unsigned)(0x80000000u || 0xc820159u)) goto L0;
            L4: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0(0x18fcdafu, (unsigned)(m0 && garr[i1 & 7u]), ~(unsigned)((int)0x34f0e618u < (int)r0.x)); }
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (0x80000000u) break;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(0xffffffffu ^ (unsigned)l0) > (signed char)0x2e69603cu), u0, (unsigned)(*mp || p2)); }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(g0 == (unsigned)c0), ((unsigned)(signed char)(unsigned)((short)garr[i1 & 7u] > (signed char)u2) - u0), (unsigned)((short)(unsigned)e0 > (signed char)(0x41a6e0d5u << (*q0 & 31u)))); }
        }
    }
    if ((unsigned)f0) {
        if (((unsigned)l0 & 9u)) {
            if ((unsigned)((int)(unsigned)c0 >= (int)0x10000u)) goto L4;
            if (a0[u1 & 3u]) goto L1;
            q0 = &garr[(1u << ((unsigned)((int)((unsigned)(short)(unsigned)((unsigned)c0 || (unsigned)c1) << (u2 & 31u)) >= (int)(unsigned)(x0 >> 70)) & 31u)) & 7u];
            goto done;
            goto L4;
        } else {
            if ((unsigned)(-(unsigned)((int)0x40115745u < (int)(unsigned)h0) || 0xf1374c71u)) goto L1;
            if (4u) goto L4;
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(3u && v0)) break;
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)f0)) {
                f0 = f0 * 0.5f + (float)(((unsigned)w0 & (*q0 >> (u0 & 31u))) & 255u);
                if ((unsigned)b0) break;
                if ((0x8a419d29u & (unsigned)l0)) {
                    { unsigned t3; double z3; if (((a0[u1 & 3u] >> ((unsigned)((int)(unsigned)c0 >= (int)i0) & 31u))) & 1u) { t3 = (unsigned)((int)a0[i0 & 3u] < (int)*mp); z3 = (double)((u0) & 255u); } if (((a0[u1 & 3u] >> ((unsigned)((int)(unsigned)c0 >= (int)i0) & 31u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        q0 = &garr[(garr[u2 & 7u] * (unsigned)(0x4409c2b7u < m0)) & 7u];
                        continue; (void)((((unsigned)b0 + 0x80000000u) % ((unsigned)h1 | 1u)));
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)g0 < (int)(u2 + 7u)), 9u, 9u); }
                        e0 = e0 * 0.5L + (long double)(((unsigned)((int)g0 >= (int)(unsigned)x0) | u0) & 1023u);
                        v0 = (unsigned)f0;
                        *q0 = u0;
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn0((0x9bf964c4u - (unsigned)(unsigned char)(m0 - p0)), (unsigned)(i0 && (unsigned)((int)9u >= (int)u1)), i1); }
                    h0 = (short)(unsigned)(((unsigned)((unsigned)w0 || (garr[u2 & 7u] << (u1 & 31u))) << (0x80000000u & 31u)) < (unsigned)s1);
                    if ((unsigned)(u3 == (unsigned)((int)(unsigned)h1 >= (int)(unsigned)c1))) {
                        break; (void)((0xffffffffu | i2));
                        break; (void)(0x80000000u);
                        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                            u0 = (unsigned)((int)m0 >= (int)(0xffffffffu ? a0[u1 & 3u] : (unsigned)h0));
                            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((short)i2 > (signed char)(unsigned)b0) / (7u | 1u)), (0xffffffffu % ((unsigned)s1 | 1u)), (unsigned)f0); }
                            if (fuel) break;
                            *q0 += p2;
                        }
                        if (budget != 0u) { budget -= 1u; u2 = fn0(u1, (unsigned)(short)(garr[u2 & 7u] % (0x10000u | 1u)), ((0x7ce509ecu * r0.y) - i2)); }
                        while (i1++ < 6u && (unsigned)(7u || (unsigned)h0)) { if (--fuel == 0u) goto done;
                            h1 = (unsigned short)(h1 + (0x322289abu >> ((unsigned)l0 & 31u)));
                            g0 = (r0.x >> (-(unsigned)((0x133dd4e8u - 9u) == g0) & 31u));
                            if (budget != 0u) { budget -= 1u; u3 = fn0((u1 | r0.x), 0xffffffffu, (unsigned)((unsigned)(w0 >> 29) || 8u)); }
                            u2 ^= (unsigned)((short)(i2 % (0x10000u | 1u)) > (signed char)(unsigned)(x0 >> 70));
                            if (0xffffffffu) break;
                            g1 += (unsigned)s1;
                        }
                    }
                    if (garr[u2 & 7u]) continue;
                }
                if (g0) goto L3;
                if (budget != 0u) { budget -= 1u; u0 = fn0((g0 / ((unsigned)(0xffffffffu == (unsigned)s0) | 1u)), ((unsigned)l0 - -((unsigned)l0 | (unsigned)h0)), (unsigned)((int)(unsigned)s0 < (int)p0)); }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((*q0 * (unsigned)(*q0 < i0)), (unsigned)((unsigned)w0 == p1), -(unsigned)((int)7u >= (int)garr[i1 & 7u])); }
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(signed char)(unsigned)(p0 && v0), (unsigned)(u0 && 0xd8dbef14u), (unsigned)((unsigned)x0 == garr[u2 & 7u])); }
        if ((unsigned)(short)(v0 / (r0.x | 1u))) goto done;
    } else {
        u0 = (unsigned)(unsigned char)(4u ? 0xa5982c30u : 0x7fffffffu);
    }
    switch (0x78662343u & 7u) {
        c1 = (signed char)(unsigned)((*q0 % (5u | 1u)) < (unsigned)h0);
        if ((unsigned)(m0 < 0x10000u)) {
            case 6u: ;
            if (budget != 0u) { budget -= 1u; u1 = fn0((2u % (p2 | 1u)), (unsigned)(signed char)(i1 % (u3 | 1u)), v0); }
        } else {
            switch ((unsigned)((unsigned)((int)(unsigned)d0 < (int)u2) || 0x150a3f8au) & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn0((((unsigned)h0 + r0.y) >> ((unsigned)h0 & 31u)), 0xffffffffu, (unsigned)((unsigned)h1 < (0x80000000u % ((unsigned)d0 | 1u)))); }
            }
            *q0 = (unsigned)((int)~((unsigned)((int)p0 < (int)0x80000000u) - 0x3ad24389u) < (int)(unsigned)(short)(1u * (unsigned)c0));
        }
        while (i0++ < 4u && (unsigned)(0xcddc77fcu && (unsigned)c0)) { if (--fuel == 0u) goto done;
            switch ((unsigned)((int)0x519c107fu < (int)(unsigned)(fuel < (unsigned)b0)) & 7u) {
                case 2u: ;
                u2 ^= ((v0 | u3) ^ ((unsigned)(x0 >> 70) % (garr[i1 & 7u] | 1u)));
                while (i1++ < 3u && (((unsigned)d0 | fuel) & (unsigned)d0)) { if (--fuel == 0u) goto done;
                    goto L4;
                    q0 = &garr[(((unsigned)f0 ^ garr[u2 & 7u]) ? (unsigned)d0 : r0.y) & 7u];
                    for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        h0 = (short)(unsigned)((int)r0.y >= (int)(((unsigned)f0 * i2) * u1));
                        if (budget != 0u) { budget -= 1u; u2 = fn0(0x2996d632u, (fuel * (unsigned)((unsigned)x0 < g1)), m0); }
                        switch (((p1 - 0x7fffffffu) * 7u) & 7u) {
                            case 1u: ;
                            if (budget != 0u) { budget -= 1u; u2 = fn0(a0[u1 & 3u], (unsigned)((int)*mp >= (int)(0x80000000u ^ 0xec1bdd03u)), (3u >> (m0 & 31u))); }
                            case 2u: ;
                            u2 ^= (g1 * (unsigned)((int)garr[i1 & 7u] >= (int)(0x7fffffffu / (p0 | 1u))));
                            v0 = v0;
                        }
                        g1 += (unsigned)((i2 * (unsigned)s0) < ((unsigned)(7u < i1) / (0x10000u | 1u)));
                        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                            h1 = (unsigned short)(h1 + (p0 % ((unsigned)c0 | 1u)));
                            c0 = (unsigned char)(unsigned)x0;
                            m0 ^= a0[i0 & 3u];
                        }
                        case 4u: ;
                    }
                    break; (void)((fuel % ((6u * a0[i0 & 3u]) | 1u)));
                    do { if (--fuel == 0u) goto done;
                        v0 = ~(unsigned)((int)p0 < (int)i0);
                        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                            u1 = ((4u ? 0x10000u : 0x6068cc18u) << ((unsigned)s1 & 31u));
                            u2 = u2 * 0x9e3779b1u + ((unsigned)s0 % ((unsigned)s1 | 1u));
                            l0 = (long)((unsigned long)l0 + ((unsigned)(x0 >> 70) ? *q0 : (unsigned)(5u && garr[u2 & 7u])));
                            if (fuel < 8u) return 0x7fffffffu;
                        }
                        case 1u: ;
                    } while (i2++ < 6u && (unsigned)(i2 || garr[i1 & 7u]));
                    c0 = (unsigned char)(unsigned)((int)(unsigned)l0 >= (int)garr[i1 & 7u]);
                }
                do { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)(0x80000000u || (unsigned)((int)(unsigned)(0x518ccd4u || 0x7fffffffu) < (int)(unsigned)c1));
                    if (((0x7fffffffu << (1u & 31u)) * 0x80000000u)) break;
                    if ((0xc34da71eu * 0xe68048feu)) goto L1;
                    goto L1;
                } while (i1++ < 4u && (unsigned)c0);
            }
        }
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((*q0 | i2)) goto L1;
            } while (i1++ < 3u && ((unsigned)w0 >> ((unsigned)!(unsigned)((int)u1 < (int)(unsigned)h1) & 31u)));
            x0 = x0 * 0x100000001b3ull + (4u & (unsigned)(((unsigned)e0 * (unsigned)e0) < (g1 ^ u0)));
            { unsigned t4; double z4; if (((unsigned)(u3 || (unsigned)f0)) & 1u) { t4 = ((unsigned)b0 & (unsigned)w0); z4 = (double)(((unsigned)!(r0.y + (unsigned)f0)) & 255u); } if (((unsigned)(u3 || (unsigned)f0)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                if ((unsigned)d0) goto L0;
                i0 = (unsigned)((unsigned)((int)g0 < (int)g0) == (7u % ((unsigned)w0 | 1u))) & 15u;
                if ((6u - (unsigned)l0)) break;
                continue; (void)((unsigned)!(garr[u2 & 7u] | 0x80000000u));
                h0 = (short)(unsigned)((short)(unsigned)(8u == 0x10000u) > (signed char)(m0 * (unsigned)d0));
            }
        }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (2u) goto L0;
            w0 ^= (unsigned long long)(unsigned)((short)p1 > (signed char)(unsigned)x0) << ((v0 + (unsigned)d0) & 63u);
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((fuel >> ((unsigned)!(u1 << (0xffffffffu & 31u)) & 31u)), ((unsigned)(0xffffffffu && (unsigned)s0) - (unsigned)(x0 >> 70)), ((unsigned)(unsigned char)(unsigned)((short)r0.y > (signed char)(unsigned)x0) + r0.x)); }
    if ((unsigned)(u0 == (unsigned)l0)) goto L2;
    w0 ^= (unsigned long long)(unsigned)x0 << ((unsigned)(garr[i1 & 7u] || g0) & 63u);
    if ((unsigned)(garr[u2 & 7u] < (unsigned)f0)) {
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)((0xf761774bu ^ (unsigned)x0) ? (unsigned)w0 : 0x45aa606du);
            if (budget != 0u) { budget -= 1u; u0 = fn0(~(u1 ? 3u : (unsigned)s0), (((unsigned)s1 + p2) >> (4u & 31u)), (unsigned)s1); }
            v0 = a0[u1 & 3u];
            *q0 += (unsigned)c1;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + ~(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)((int)(unsigned)(r0.x && 0xffffffffu) < (int)u3));
                    do { if (--fuel == 0u) goto done;
                        while ((unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
                            c0 = (unsigned char)((u2 << (m0 & 31u)) << ((3u * 0xddbb9d5cu) & 31u));
                            s1 = (int)((unsigned)s1 + ((unsigned)((unsigned)s0 < 0xffffffffu) | (unsigned)((3u >> ((unsigned)h1 & 31u)) || 6u)));
                        }
                    } while (i0++ < 4u && (unsigned)f0);
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)(short)(i2 % (p2 | 1u)));
                    if ((unsigned)((short)(g0 * 7u) > (signed char)(unsigned)(w0 >> 29))) break;
                }
                l0 = (long)((unsigned long)l0 + (((unsigned)w0 << (0u & 31u)) * (unsigned)e0));
                *q0 = (unsigned)!(unsigned)((short)u0 > (signed char)u1);
                if ((unsigned)h1) {
                    if ((g0 * u1)) break;
                }
            }
        }
        if (r0.x) goto L2;
        q0 = &garr[(((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)x0) << (m0 & 31u)) ^ (unsigned)c0) & 7u];
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(~(unsigned)(g1 && r0.y), (garr[u2 & 7u] ^ (garr[u2 & 7u] / (p0 | 1u))), (0u / (0xa267e74du | 1u))); }
    goto done;
    u0 = (unsigned)(0xffffffffu || 0x10000u);
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)c1, 0x2c842769u, 0x7fffffffu); }
    if ((unsigned)!((unsigned)h0 ? p1 : (unsigned)s0)) goto done;
    if ((*q0 ? u1 : 0u)) goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn0((8u % (r0.y | 1u)), (((unsigned)s0 / (5u | 1u)) & (unsigned)(x0 >> 70)), (unsigned)b0); }
    switch (((unsigned)s0 << ((m0 << (1u & 31u)) & 31u)) & 7u) {
        if (p1) {
            { unsigned t5; double z5; if (((unsigned)((int)0x7fffffffu >= (int)(unsigned)((int)(unsigned)b0 >= (int)0x8b4b44a5u))) & 1u) { t5 = 0x46e18927u; z5 = (double)(((unsigned)(g1 < 9u)) & 255u); } if (((unsigned)((int)0x7fffffffu >= (int)(unsigned)((int)(unsigned)b0 >= (int)0x8b4b44a5u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                *mp = (unsigned)l0;
                goto L1;
                if (*q0) goto L4;
                if (fuel < 8u) return ((r0.x % (a0[i0 & 3u] | 1u)) % (a0[u1 & 3u] | 1u));
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)c1 || r0.y), 0x7fffffffu, garr[u2 & 7u]); }
                    s1 = (int)((unsigned)s1 + (0xbac1fd1fu + (0x80000000u ? i0 : (unsigned)e0)));
                    break; (void)(a0[u1 & 3u]);
                    if (budget != 0u) { budget -= 1u; u1 = fn0(~(unsigned)(((unsigned)x0 - *q0) && 3u), u0, ((4u >> (u2 & 31u)) - g0)); }
                    i0 = (unsigned)((int)(unsigned)(a0[i0 & 3u] == 5u) < (int)(unsigned)(signed char)(unsigned)(u2 || (unsigned)h1)) & 15u;
                }
                do { if (--fuel == 0u) goto done;
                    while (i1++ < 7u && ((unsigned)(w0 >> 29) | u0)) { if (--fuel == 0u) goto done;
                        if ((unsigned)((unsigned)s0 || u2)) continue;
                        { unsigned t6; double z6; if ((~(unsigned)(0xa5d3f6abu == (*q0 * (unsigned)e0))) & 1u) { t6 = (unsigned)((short)(unsigned)e0 > (signed char)(0x10000u / (r0.y | 1u))); z6 = (double)((a0[i0 & 3u]) & 255u); } if ((~(unsigned)(0xa5d3f6abu == (*q0 * (unsigned)e0))) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                            b0 = (unsigned)((int)-(g0 | (unsigned)h0) < (int)(p0 - 0u)) != 0u;
                            g1 += (unsigned)(w0 >> 29);
                            v0 = (((unsigned)b0 >> ((unsigned)b0 & 31u)) ? (unsigned)((int)(unsigned)e0 >= (int)0x69a06299u) : 0x7fffffffu);
                        }
                    }
                    { unsigned t7; double z7; if ((((unsigned)!(unsigned)(u0 && 0xffffffffu) | 9u)) & 1u) { t7 = (unsigned)(unsigned char)(unsigned)((unsigned)s0 || (4u % ((unsigned)e0 | 1u))); z7 = (double)((i1) & 255u); } if ((((unsigned)!(unsigned)(u0 && 0xffffffffu) | 9u)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                        l0 = (long)((unsigned long)l0 + (((unsigned)c0 + (unsigned)((unsigned)(w0 >> 29) && 0xffffffffu)) | (p0 * (unsigned)b0)));
                        garr[((unsigned)h1 >> (*mp & 31u)) & 7u] = (1u << ((p0 + 0xef738c50u) & 31u));
                    }
                    if (u0) break;
                    b0 = (u3 >> ((garr[i1 & 7u] + fuel) & 31u)) != 0u;
                    if ((a0[i0 & 3u] << (i2 & 31u))) goto L4;
                    case 6u: ;
                } while (i0++ < 3u && ((unsigned)c0 << ((unsigned)(g1 < a0[u1 & 3u]) & 31u)));
            }
            f0 = f0 * 0.5f + (float)((unsigned)((int)r0.x >= (int)u0) & 255u);
            x0 = x0 * 0x100000001b3ull + (unsigned)!(((unsigned)(x0 >> 70) * (unsigned)b0) + g1);
            do { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 4u: ;
                }
                goto L4;
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 3u: ;
                    g1 += ((unsigned)!(garr[u2 & 7u] % ((unsigned)l0 | 1u)) ^ (unsigned)l0);
                }
            } while (i0++ < 6u && (u0 % ((unsigned)((short)0x3308b87u > (signed char)v0) | 1u)));
        } else {
            if (((unsigned)s0 ? 7u : (unsigned)h1)) break;
            *q0 += (0x7fffffffu ^ *mp);
        }
        default: ;
        if (u3 == 7u) return ((unsigned)(w0 >> 29) * (0x9b719661u - 8u));
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)f0 >> ((unsigned)e0 & 31u)), (unsigned)((unsigned)w0 || r0.x), (i1 | fuel)); }
    if (-(p1 % ((unsigned)f0 | 1u))) {
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0x2d8c8065u && 0x77fdd226u), (r0.x + 3u), (unsigned)((int)g1 >= (int)i1)); }
        if (v0) goto done;
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            u1 = (unsigned)h1;
        }
        goto L3;
    } else {
        do { if (--fuel == 0u) goto done;
            while (i1++ < 7u && (i0 ^ g0)) { if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)!(unsigned)((0x8998fb66u >> (r0.y & 31u)) == 0x49608254u) & 7u];
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)b0 >= (int)(i1 / (u3 | 1u)));
                a0[r0.x & 3u] = (unsigned)((a0[i0 & 3u] ? u1 : (unsigned)b0) < r0.y);
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0x10000u == 0x80000000u), ((unsigned)w0 * (unsigned)(0x685cc39eu < (unsigned)c1)), (unsigned)c0); }
            s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)*mp));
            if ((unsigned)((short)1u > (signed char)(u1 % (3u | 1u)))) break;
        } while (i0++ < 5u && (g0 * p2));
        if (u1) goto L1;
        h0 = (short)((unsigned)(unsigned char)(unsigned)((unsigned)s1 && (unsigned)w0) / ((unsigned)((int)a0[i0 & 3u] >= (int)0x5e3328ffu) | 1u));
        q0 = &garr[garr[i1 & 7u] & 7u];
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)f0 | (unsigned)(unsigned char)(unsigned)((short)6u > (signed char)0x10000u)), (unsigned)((short)0xffffffffu > (signed char)0xe3bb25bfu), (i0 / ((unsigned)!(unsigned)((int)(unsigned)b0 < (int)*mp) | 1u))); }
    u1 += (unsigned)(0x80000000u < u2);
    if (budget != 0u) { budget -= 1u; u1 = fn0(6u, (unsigned)l0, (unsigned)((int)p2 >= (int)0x10000u)); }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)l0 && (unsigned)(garr[i1 & 7u] < 3u)), 0x10000u, (g0 * 0x10000u)); }
            if ((r0.x << ((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)(x0 >> 70)) & 31u))) break;
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0(g1, 0x1aa56adfu, (unsigned)(garr[u2 & 7u] || u2)); }
                if ((unsigned)((int)r0.x >= (int)(0xc6b8adb1u & *q0))) continue;
                continue; (void)((unsigned)((unsigned)(4u == r0.y) < v0));
                break; (void)(8u);
                b0 = (unsigned)!(r0.y * -((unsigned)w0 & (unsigned)!(unsigned)((int)*mp >= (int)(unsigned)(i2 && 0x7fffffffu)))) != 0u;
                for (;;) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (unsigned)((int)0xc575b0d2u < (int)0xffffffffu);
                    if ((unsigned)(0x80000000u && (unsigned)((int)p2 >= (int)0xffffffffu))) {
                        u3 = u3 * 0x9e3779b1u + r0.x;
                        break; (void)(((0xc864138fu - *q0) ^ (unsigned)s1));
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(8u || (unsigned)e0), (unsigned)s1, i1); }
                        if ((unsigned)((unsigned)((int)5u >= (int)garr[u2 & 7u]) || g0)) continue;
                        *mp = (unsigned)h0;
                    }
                }
            }
        } while (i1++ < 6u && v0);
    }
    i2 = (unsigned)((int)u3 >= (int)(unsigned)(x0 >> 70)) & 15u;
    garr[0x87105986u & 7u] = 0x7fffffffu;
    { unsigned t8; double z8; if ((4u) & 1u) { t8 = (0x43fb260u ^ i0); z8 = (double)((g0) & 255u); } if ((4u) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
        goto L0;
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)e0);
            if (((unsigned)(3u < r0.x) & m0)) break;
            if (fuel < 8u) return (u0 - u3);
            { unsigned t9; double z9; if ((((unsigned)(unsigned char)((unsigned)d0 ^ (unsigned)s0) ^ (unsigned)s1)) & 1u) { t9 = 2u; z9 = (double)((((unsigned)h0 * 0x54d57c3cu)) & 255u); } if ((((unsigned)(unsigned char)((unsigned)d0 ^ (unsigned)s0) ^ (unsigned)s1)) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                while (i1++ < 4u && ((unsigned)((unsigned)x0 && u1) >> (7u & 31u))) { if (--fuel == 0u) goto done;
                    a0[(unsigned)(8u && r0.x) & 3u] = (unsigned)(signed char)(unsigned)((unsigned)b0 < (u0 ? m0 : (unsigned)((short)i2 > (signed char)*mp)));
                    { unsigned t10; double z10; if (((unsigned)(w0 >> 29)) & 1u) { t10 = (~(u1 % (5u | 1u)) % (0x7fffffffu | 1u)); z10 = (double)(((unsigned)((int)(unsigned)h1 < (int)0x5de2d16u)) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!((*q0 % ((unsigned)c0 | 1u)) | (unsigned)(w0 >> 29)), (unsigned)d0, 0x4143afdcu); }
                    }
                }
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    a0[(u3 >> (u3 & 31u)) & 3u] = (unsigned)(unsigned char)(g0 * (unsigned)(signed char)(unsigned)((unsigned)w0 && p1));
                    if (-(a0[u1 & 3u] ^ 0x774ac986u)) break;
                    x0 = x0 * 0x100000001b3ull + (unsigned)(0x7fffffffu < (a0[u1 & 3u] ? (unsigned)h0 : (unsigned)h0));
                    m0 ^= (*q0 | ~((unsigned)(m0 && *q0) << ((unsigned)((unsigned)s1 < (unsigned)s0) & 31u)));
                }
                h1 = (unsigned short)(h1 + ((unsigned)!(unsigned)((int)((unsigned)c1 >> (0xffffffffu & 31u)) < (int)r0.x) % (p0 | 1u)));
                s0 = (int)i1;
                s0 = (int)(0xa1ba3a8eu / (u3 | 1u));
            }
            while ((unsigned)(short)(u1 ? a0[u1 & 3u] : i1)) { if (--fuel == 0u) goto done;
                { unsigned t11; double z11; if ((m0) & 1u) { t11 = (unsigned)((*q0 - (unsigned)e0) == p1); z11 = (double)(((unsigned)(v0 || garr[u2 & 7u])) & 255u); } if ((m0) & 1u) { u3 += t11; d0 = d0 * 0.5 + z11; }
                    *mp = 0x10000u;
                    continue; (void)((unsigned)f0);
                    r0.x = (unsigned)!((unsigned)f0 - (0x526d12f6u % ((u1 * a0[u1 & 3u]) | 1u)));
                    w0 ^= (unsigned long long)(unsigned)(x0 >> 70) << (p2 & 63u);
                    if (~(unsigned)(((unsigned)d0 / (0x10000u | 1u)) || (unsigned)e0)) break;
                    while (i2++ < 4u && (unsigned)c1) { if (--fuel == 0u) goto done;
                        u3 += (unsigned)!(4u << (-(v0 & 0x4bf2861cu) & 31u));
                        garr[(unsigned)c1 & 7u] = ((unsigned)((unsigned)((unsigned)w0 && *mp) < g1) + (2u & a0[i0 & 3u]));
                        while (u1) { if (--fuel == 0u) goto done;
                            u1 = u1 * 0x9e3779b1u + (unsigned)((0xeeda0392u ^ (unsigned)(0u || (unsigned)(u2 && 0x99e4d0bfu))) || m0);
                            if (((u3 | (unsigned)d0) / (p1 | 1u))) continue;
                        }
                        *q0 += (a0[i0 & 3u] % (0x10000u | 1u));
                        g0 = (0u >> (i0 & 31u));
                        if (((a0[u1 & 3u] * r0.y) | 0x10000u)) break;
                    }
                }
                if (budget != 0u) { budget -= 1u; u3 = fn0(((0x7fffffffu ^ p0) >> (a0[i0 & 3u] & 31u)), (0x48fd41b0u / (0x3259f005u | 1u)), (unsigned)((int)(unsigned)h1 >= (int)(unsigned)(0x7fffffffu || 9u))); }
                if ((0x5d0cf801u ? (unsigned)e0 : (unsigned)l0)) break;
                if ((a0[u1 & 3u] ^ 4u)) break;
            }
            if (2u) break;
        }
        if ((5u & (unsigned)c0)) goto L2;
        if (*q0) goto done;
        h0 = (short)(unsigned)(short)(p1 | (unsigned)e0);
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0x771cbbd7u && -(unsigned)((int)0x6a65cd1eu >= (int)u1)), (unsigned)(u0 < r0.y), (0xffffffffu | 0x5c3565a3u)); }
    if (((unsigned)(x0 >> 70) / (fuel | 1u))) goto L2;
    if ((6u + ((unsigned)e0 - v0))) goto L3;
    while (i0++ < 2u && (unsigned)((short)2u > (signed char)(unsigned)(i1 == 0x6bbb0c95u))) { if (--fuel == 0u) goto done;
        if (((unsigned)((int)i2 < (int)(unsigned)l0) % (a0[u1 & 3u] | 1u))) break;
    }
    do { if (--fuel == 0u) goto done;
        goto L3;
        garr[0x10000u & 7u] = ((unsigned)(w0 >> 29) << ((unsigned)((0x80000000u - (unsigned)l0) || p0) & 31u));
        if ((((unsigned)(x0 >> 70) << (0x196f1f7eu & 31u)) * i2)) goto done;
        { unsigned t12; double z12; if ((~(0x19578c00u ^ 0x36455fbcu)) & 1u) { t12 = (unsigned)(r0.x == (unsigned)!(g0 & 0x67fc1075u)); z12 = (double)(((unsigned)((unsigned)c0 && i2)) & 255u); } if ((~(0x19578c00u ^ 0x36455fbcu)) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
            continue; (void)(((unsigned)!(4u - (unsigned)c0) % (0xaf404690u | 1u)));
            switch (v0 & 7u) {
                s1 = (int)((unsigned)s1 + (unsigned)(m0 && (unsigned)(unsigned char)(v0 << (g1 & 31u))));
            }
            *q0 = (unsigned)((int)(garr[u2 & 7u] | 7u) < (int)(unsigned)d0);
            break; (void)(*q0);
            s1 = (int)((unsigned)s1 + 0x3c2cf2f1u);
        }
    } while (i0++ < 5u && ((unsigned)c0 % (*q0 | 1u)));
    if (fuel < 8u) return (unsigned)(short)((unsigned)(*q0 < (unsigned)(w0 >> 29)) + (u2 >> ((unsigned)(signed char)(i0 >> (0xffffffffu & 31u)) & 31u)));
    switch (a0[i0 & 3u] & 7u) {
        w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(0x80000000u % (garr[u2 & 7u] | 1u));
        u3 += ((unsigned)x0 + (unsigned)s0);
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((0x10000u & (unsigned)c0), (unsigned)(unsigned char)(unsigned)((unsigned)l0 == *q0), ((unsigned)h1 - r0.y)); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn1(1u, (unsigned)h0, (unsigned)(*mp && (unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)c1))); }
    a0[(unsigned)((unsigned)d0 == 1u) & 3u] = (unsigned)!(unsigned)((unsigned)(0x80000000u || 0xffffffffu) < (unsigned)e0);
    switch ((unsigned)((unsigned)(w0 >> 29) == (unsigned)(x0 >> 70)) & 7u) {
        break; (void)((unsigned)((int)*mp >= (int)a0[i0 & 3u]));
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            case 4u: ;
        }
        case 1u: ;
        break; (void)((unsigned)x0);
        f0 = f0 * 0.5f + (float)((unsigned)h0 & 255u);
    }
    r0.y ^= ((garr[i1 & 7u] - ((unsigned)l0 - 0xb2aaf183u)) | (unsigned)(garr[i1 & 7u] == 4u));
    i0 = (unsigned)(short)(-((unsigned)c0 * (unsigned)c0) ^ (i0 | (4u + g1))) & 15u;
    g1 += ((unsigned)((short)i0 > (signed char)(a0[i0 & 3u] >> ((unsigned)f0 & 31u))) << ((unsigned)c0 & 31u));
    if (v0) {
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)!(0x10000u | 4u), 0x80000000u, ((unsigned)e0 ^ (p0 % (u1 | 1u)))); }
    }
    i0 = -(unsigned)(0x39f31199u || (unsigned)s1) & 15u;
    if (garr[u2 & 7u]) goto L4;
    r0.y ^= (garr[u2 & 7u] % ((unsigned)((unsigned)(i1 || 3u) && 0x1142cb56u) | 1u));
    if (u1) {
        g0 = (unsigned)(x0 >> 70);
        if (budget != 0u) { budget -= 1u; u3 = fn0(a0[i0 & 3u], (i1 ^ (unsigned)((int)u1 < (int)m0)), 0x10000u); }
        if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)h0 * (unsigned)((int)7u >= (int)(unsigned)c1)), (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)1u), (unsigned)(0x229e645du && (unsigned)(short)((unsigned)h0 * g1))); }
        m0 ^= (u3 % ((unsigned)((int)3u >= (int)i0) | 1u));
        if ((unsigned)((short)(m0 << (v0 & 31u)) > (signed char)(unsigned)h1)) goto L0;
    } else {
        if ((unsigned)(u3 == (unsigned)w0)) {
            goto L3;
            f0 = f0 * 0.5f + (float)((r0.x + ((garr[u2 & 7u] & (unsigned)b0) / (i1 | 1u))) & 255u);
            if (((unsigned)s0 | p0)) goto L0;
            *q0 += 0x80000000u;
            f0 = f0 * 0.5f + (float)((unsigned)(7u || 0x7fffffffu) & 255u);
            if (u3 == 7u) return (unsigned)((int)u1 < (int)(p1 >> ((unsigned)e0 & 31u)));
        } else {
            v0 = (i0 + (0x7fffffffu ? 0x7fffffffu : 0xffffffffu));
        }
        c1 = (signed char)(unsigned)(short)(unsigned)((int)((u2 << (u1 & 31u)) >> (i2 & 31u)) < (int)(unsigned)((int)garr[u2 & 7u] < (int)0xf8a61dddu));
        r0.y ^= (garr[i1 & 7u] & 1u);
    }
    u3 += (unsigned)((unsigned)b0 < g0);
    if ((unsigned)((int)i1 >= (int)fuel)) goto L1;
    switch (6u & 7u) {
        r0.y ^= (unsigned)((int)(((5u ^ (unsigned)c0) / (0xe70c2e8bu | 1u)) + 0x80000000u) >= (int)p0);
        x0 = x0 * 0x100000001b3ull + ((0x7fffffffu + 0x80000000u) & *q0);
        w0 ^= (unsigned long long)(fuel << (8u & 31u)) << (0xb6486482u & 63u);
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)(short)(7u % ((unsigned)((int)0xe3343adau < (int)0u) | 1u));
            h1 = (unsigned short)(h1 + ((a0[u1 & 3u] - i0) >> (((unsigned)d0 ? a0[u1 & 3u] : 0xf9992ed4u) & 31u)));
            if (fuel < 8u) return (unsigned)(u2 || ((unsigned)d0 >> (0xffffffffu & 31u)));
            a0[(unsigned)(0xc3c3a115u == u2) & 3u] = (0x40e5a655u - m0);
            g1 += (unsigned)(unsigned char)(unsigned)((unsigned)(0x87ed4ae5u < 0x7fffffffu) < (0x10000u * (0xffffffffu + (unsigned)c0)));
        }
        if ((unsigned)((unsigned)f0 && (unsigned)((int)0x10000u >= (int)*q0))) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((fuel >> ((unsigned)(x0 >> 70) & 31u)), (m0 | (unsigned)((int)u0 < (int)m0)), 0u); }
            switch (-(unsigned)((unsigned)h1 < (unsigned)w0) & 7u) {
                while (i0++ < 3u && *mp) { if (--fuel == 0u) goto done;
                    goto L4;
                }
                *q0 += 0xaca6fab5u;
                if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)(short)(p2 | u0) << (p2 & 31u)), garr[u2 & 7u], ((unsigned)x0 ^ (8u & a0[u1 & 3u]))); }
                b0 = 1u != 0u;
                if (0x10000u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0x10000u >> (i0 & 31u)), ((unsigned)b0 | (unsigned)s0), u3); }
                } else {
                    case 4u: ;
                    if ((unsigned)(unsigned char)((unsigned)e0 << ((unsigned)x0 & 31u))) goto L2;
                    while (i0++ < 5u && (u3 ? 0x6083ba5eu : 0x80000000u)) { if (--fuel == 0u) goto done;
                        L0: if (--fuel == 0u) goto done;
                        *q0 = ((unsigned)((int)u2 >= (int)7u) - (0x80000000u << ((8u + g0) & 31u)));
                        case 3u: ;
                        e0 = e0 * 0.5L + (long double)((((garr[u2 & 7u] & 0x7fffffffu) << (0x922505fcu & 31u)) - ((unsigned)(w0 >> 29) << (fuel & 31u))) & 1023u);
                    }
                    if (*mp) goto L1;
                }
            }
            L1: if (--fuel == 0u) goto done;
            q0 = &garr[(unsigned)(short)(u3 << ((*q0 >> (7u & 31u)) & 31u)) & 7u];
            m0 ^= ~(unsigned)(g1 == (unsigned)(5u == (unsigned)c0));
        } else {
            w0 = w0 * 6364136223846793005ull + (r0.y ^ (unsigned)l0);
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)0xb25d34e9u < (int)(unsigned)(short)(unsigned)(r0.y < (unsigned)d0)), (a0[i0 & 3u] % (0x15b71012u | 1u)), (0x10000u - ((unsigned)c0 % (4u | 1u)))); }
            goto L4;
            if ((((unsigned)b0 >> (0x7e137576u & 31u)) >> ((unsigned)(x0 >> 70) & 31u))) goto L1;
        }
        case 1u: ;
    }
    if ((unsigned)((short)0xa3c46032u > (signed char)i2)) goto L0;
    *mp = (unsigned)((((unsigned)h0 + r0.y) ? (unsigned)h1 : p0) || (unsigned)(x0 >> 70));
    if (garr[i1 & 7u]) goto L3;
    u1 = (((unsigned)s1 * 0x7fffffffu) ^ (4u | (a0[i0 & 3u] ^ 0u)));
    while (i0++ < 6u && garr[u2 & 7u]) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)w0 < (unsigned)b0));
        r0.x = (7u * (unsigned)!((unsigned)(0xda6810a4u && fuel) / ((unsigned)((int)p1 >= (int)(unsigned)s0) | 1u)));
        while ((unsigned)s1) { if (--fuel == 0u) goto done;
            if (((unsigned)(x0 >> 70) + (unsigned)!((unsigned)d0 - (unsigned)(x0 >> 70)))) break;
            if ((unsigned)e0) goto done;
            *q0 = (unsigned)((int)(unsigned)(w0 >> 29) >= (int)u1);
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)0x10000u << ((*mp >> (u3 & 31u)) & 63u);
                    if (u3 == 7u) return (unsigned)(0xffffffffu && (unsigned)((unsigned)c0 == r0.y));
                }
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)h1, ~((unsigned)(x0 >> 70) ? v0 : 0x7fffffffu), (a0[u1 & 3u] % ((v0 & (unsigned)(w0 >> 29)) | 1u))); }
        *q0 = 0xfb9c98f2u;
        v0 = r0.y;
    }
    if ((unsigned)((unsigned)h0 && (unsigned)!(0x10000u / (p1 | 1u)))) {
        if (garr[u2 & 7u]) goto L1;
        if (i2) {
            g0 = ((unsigned)(unsigned char)(0xffffffffu % (((unsigned)b0 / (p0 | 1u)) | 1u)) | 2u);
        } else {
            h0 = (short)0x10000u;
            if (budget != 0u) { budget -= 1u; u3 = fn1(g0, (unsigned)(short)(v0 << (7u & 31u)), (unsigned)(0xc39df709u || *mp)); }
        }
    } else {
        v0 = (0x7fffffffu % ((u1 ? 1u : 0x80000000u) | 1u));
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        c1 = (signed char)u2;
        u0 += (0x7fffffffu | (0xffffffffu ? (unsigned)s1 : *q0));
        switch ((~(unsigned)(r0.x || 0xd6280207u) << ((unsigned)s1 & 31u)) & 7u) {
            case 2u: ;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                goto L0;
                while (i2++ < 3u && (~(unsigned)((unsigned)h0 && 0xffffffffu) >> (7u & 31u))) { if (--fuel == 0u) goto done;
                    r0.x = ((0x80000000u % ((0x98025158u & garr[u2 & 7u]) | 1u)) / ((unsigned)(short)((unsigned)l0 ^ garr[u2 & 7u]) | 1u));
                    if (0x7fffffffu) break;
                }
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    case 7u: ;
                }
                L2: if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
            }
        }
        if (*mp) break;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 ^= u0;
        g1 += ((9u ^ (unsigned)b0) + fuel);
        h1 = (unsigned short)(h1 + ((unsigned)(0xfe58f34au == g0) ? (unsigned)(x0 >> 70) : 0x75cf775bu));
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)w0, (0x9cdd8ccfu / ((p0 ^ r0.y) | 1u)), p1); }
    }
    c0 = (unsigned char)((unsigned)(unsigned char)(u1 + 0x94852137u) * (unsigned)c0);
    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)(w0 >> 29) * 0x91c8033eu), (0x401d8ef4u & (unsigned)(short)(unsigned)(i2 < (unsigned)s0)), (6u & 0xd551e9bcu)); }
    for (;;) { if (--fuel == 0u) goto done;
        a0[(unsigned)(u1 < 0x82aa0ffcu) & 3u] = (unsigned)((int)(unsigned)c1 >= (int)((unsigned)f0 % ((unsigned)h1 | 1u)));
        break; (void)(((u2 >> ((unsigned)d0 & 31u)) & (unsigned)c1));
    }
L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)u2 >= (int)garr[u2 & 7u])) goto L0;
        *q0 = (0x10000u - (3u & (a0[i0 & 3u] >> (g1 & 31u))));
        { unsigned t0; double z0; if (((unsigned)x0) & 1u) { t0 = (8u | (unsigned)s1); z0 = (double)((((unsigned)h1 ^ g0)) & 255u); } if (((unsigned)x0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                r0.x = 0x10000u;
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    *q0 += ((unsigned)f0 + (*mp ? m0 : ((unsigned)h0 & *q0)));
                    if ((unsigned)!(unsigned)((int)(unsigned)e0 < (int)(unsigned)(short)((unsigned)l0 & a0[i0 & 3u]))) continue;
                    c0 = (unsigned char)(unsigned)((int)3u >= (int)(unsigned)((*mp | (unsigned)s1) || ((unsigned)x0 & (unsigned)d0)));
                }
                garr[*mp & 7u] = (((unsigned)w0 - 6u) % (((unsigned)l0 % (m0 | 1u)) | 1u));
                if (budget != 0u) { budget -= 1u; u1 = fn1((i2 - (unsigned)x0), (unsigned)((int)0x7fffffffu >= (int)p1), -(unsigned)((unsigned)s0 < (unsigned)(x0 >> 70))); }
                break; (void)((9u ? fuel : (unsigned)l0));
            }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((int)5u < (int)i0)) {
                    goto done;
                } else {
                    if ((i2 * (6u ^ u2))) {
                        i0 = (unsigned)c0 & 15u;
                        continue; (void)((unsigned)s1);
                        if (-((unsigned)h0 % ((unsigned)((int)(unsigned)h0 >= (int)(unsigned)(w0 >> 29)) | 1u))) break;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((u0 | garr[i1 & 7u]) >> ((unsigned)h0 & 31u)), (0xac25f1b3u & (unsigned)((unsigned)(x0 >> 70) || (unsigned)w0)), (r0.y / (9u | 1u))); }
                    }
                }
            } while (i1++ < 5u && (a0[u1 & 3u] % ((unsigned)(9u || g1) | 1u)));
            if (a0[i0 & 3u]) {
                goto L3;
                *mp = ((i2 / (*q0 | 1u)) ^ (unsigned)(u1 || a0[i0 & 3u]));
                i0 = 0x697bf811u & 15u;
                break; (void)((u1 >> (0x7fffffffu & 31u)));
                q0 = &garr[(unsigned)((unsigned)s0 || (unsigned)(u3 && 0xffffffffu)) & 7u];
            }
            s0 = (int)g1;
            { unsigned t1; double z1; if (((u3 - (unsigned)((unsigned)s1 || (unsigned)(x0 >> 70)))) & 1u) { t1 = 4u; z1 = (double)((u2) & 255u); } if (((u3 - (unsigned)((unsigned)s1 || (unsigned)(x0 >> 70)))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                { unsigned t2; double z2; if (((fuel & u3)) & 1u) { t2 = (unsigned)(unsigned char)(unsigned)(0xf574cfa7u == (unsigned)h1); z2 = (double)((((8u * 0x493af857u) + 5u)) & 255u); } if (((fuel & u3)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    s1 = (int)((unsigned)s1 + ((*q0 & u1) / ((unsigned)(signed char)(0xcdddc8dbu - (v0 % (0x10000u | 1u))) | 1u)));
                    d0 = d0 * 0.5 + (double)(((p0 / (u0 | 1u)) ^ 0x8fb3b184u) & 1023u);
                    if ((unsigned)(signed char)(0x49a40b2cu >> (((unsigned)c0 % (g0 | 1u)) & 31u))) break;
                    r0.y ^= ((unsigned)(a0[i0 & 3u] == u0) / ((unsigned)((unsigned)s1 || 7u) | 1u));
                    for (;;) { if (--fuel == 0u) goto done;
                        i0 = a0[u1 & 3u] & 15u;
                    }
                }
                u3 += (unsigned)((unsigned)s0 && ((r0.x >> (~((unsigned)l0 % (0x7fffffffu | 1u)) & 31u)) % (0x10000u | 1u)));
                w0 ^= (unsigned long long)(garr[i1 & 7u] ^ 0x7fffffffu) << ((0x8a5f5b27u * (unsigned)(*q0 == 0xda992cecu)) & 63u);
                if ((unsigned)((unsigned)(w0 >> 29) && garr[u2 & 7u])) continue;
                goto L2;
            }
            { unsigned t3; double z3; if (((0x654bb678u * (unsigned)(signed char)(0x5efa1a8bu >> (0x7fffffffu & 31u)))) & 1u) { t3 = (unsigned)w0; z3 = (double)(((u1 ^ i2)) & 255u); } if (((0x654bb678u * (unsigned)(signed char)(0x5efa1a8bu >> (0x7fffffffu & 31u)))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                m0 ^= (unsigned)(r0.y || 0x7fffffffu);
                if ((fuel % ((unsigned)e0 | 1u))) break;
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)(a0[u1 & 3u] - a0[i0 & 3u]) > (signed char)(g1 / (i1 | 1u)));
            }
        }
    }
    g0 = ((unsigned)((unsigned)e0 || (u0 / (a0[u1 & 3u] | 1u))) / (((unsigned)x0 % (g0 | 1u)) | 1u));
    s1 = (int)((unsigned)s1 + ((unsigned)s0 << (u1 & 31u)));
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)s1, (v0 - 0x10000u), (unsigned)(((unsigned)e0 * 2u) && 7u)); }
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)(x0 >> 70)), ((0x54d5013au / (m0 | 1u)) * i1), u1); }
    g0 = (unsigned)((unsigned)s1 == (unsigned)s1);
    u1 ^= (unsigned)((m0 / (u3 | 1u)) < ((u1 >> ((unsigned)w0 & 31u)) & *q0));
    if ((p0 + 0xa5ea05c9u)) {
        if ((unsigned)((unsigned)(x0 >> 70) || (unsigned)((int)(unsigned)c1 < (int)garr[i1 & 7u]))) goto L0;
    } else {
        while (i0++ < 4u && ~(g0 + u2)) { if (--fuel == 0u) goto done;
            a0[(unsigned)(x0 >> 70) & 3u] = (garr[u2 & 7u] - 0xab017cdcu);
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)((0x332d2d4bu - 0xffffffffu));
                *q0 = (v0 / (((unsigned)l0 / (~(i1 + (unsigned)e0) | 1u)) | 1u));
                s0 = (int)(unsigned)(w0 >> 29);
                if (budget != 0u) { budget -= 1u; u1 = fn0((*q0 | (unsigned)h1), (4u & (unsigned)s0), (unsigned)c0); }
            }
            L0: if (--fuel == 0u) goto done;
            u1 = (unsigned)(0xffffffffu < 0xffffffffu);
        }
    }
    s0 = (int)(unsigned)((garr[i1 & 7u] + *q0) && 0xffffffffu);
    if ((fuel - u1)) goto L0;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)!(u3 % ((unsigned)(0xf49e608au < r0.y) | 1u))) {
            break; (void)((unsigned)((i2 << (p2 & 31u)) < 0x4a5367a8u));
            if ((unsigned)(w0 >> 29)) break;
            do { if (--fuel == 0u) goto done;
                break; (void)(v0);
                *mp = (unsigned)(0u || *mp);
            } while (i1++ < 3u && (unsigned)!(unsigned)(i1 == u1));
            if (3u) break;
            i0 = -((unsigned)((int)1u >= (int)(unsigned)((unsigned)l0 < fuel)) - 0x348b8e60u) & 15u;
        } else {
            q0 = &garr[((fuel % (i1 | 1u)) << ((unsigned)(unsigned char)(unsigned)(r0.y && (unsigned)x0) & 31u)) & 7u];
            { unsigned t4; double z4; if (((((unsigned)h1 & (unsigned)h0) - (unsigned)c0)) & 1u) { t4 = (unsigned)((int)u3 < (int)(unsigned)(0x7fffffffu || m0)); z4 = (double)(((unsigned)h1) & 255u); } if (((((unsigned)h1 & (unsigned)h0) - (unsigned)c0)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                if (budget != 0u) { budget -= 1u; u2 = fn1(0x5881c1eeu, p2, (0x7fffffffu - (unsigned)(0x8cf39e16u < (unsigned)h0))); }
                g0 = ((unsigned)(unsigned char)(unsigned)(*mp && 0x10000u) >> ((unsigned)c1 & 31u));
                u0 ^= (unsigned)((short)(unsigned)h0 > (signed char)*mp);
                do { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return ((a0[i0 & 3u] % (((unsigned)w0 + 0xffffffffu) | 1u)) << ((unsigned)(x0 >> 70) & 31u));
                    u2 += a0[i0 & 3u];
                } while (i1++ < 2u && (unsigned)((unsigned)((int)3u < (int)*q0) < i1));
            }
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)p1 >= (int)i2), (unsigned)(m0 || 4u), ((unsigned)d0 ? i1 : p1)); }
                    { unsigned t5; double z5; if ((g0) & 1u) { t5 = (unsigned)(unsigned char)((unsigned)(w0 >> 29) >> (*q0 & 31u)); z5 = (double)((((unsigned)h1 ^ 0x80000000u)) & 255u); } if ((g0) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                        L1: if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)g1 << ((unsigned)((short)((unsigned)b0 | (0x53e41147u % ((0x10000u | a0[i0 & 3u]) | 1u))) > (signed char)m0) & 63u);
                    }
                    { unsigned t6; double z6; if (((v0 ? (unsigned)e0 : i0)) & 1u) { t6 = (~(p2 % (p2 | 1u)) << ((unsigned)s1 & 31u)); z6 = (double)(((*mp % ((u1 & 0xbe47493u) | 1u))) & 255u); } if (((v0 ? (unsigned)e0 : i0)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                        h1 = (unsigned short)(h1 + (unsigned)((unsigned)(x0 >> 70) || (unsigned)h1));
                        L2: if (--fuel == 0u) goto done;
                        s0 = (int)(unsigned)((int)7u >= (int)(1u | (unsigned)(p2 || (g1 % (u0 | 1u)))));
                        *q0 += (unsigned)((unsigned)f0 == u1);
                        if (((unsigned)(w0 >> 29) % ((unsigned)d0 | 1u))) goto L3;
                        L3: if (--fuel == 0u) goto done;
                    }
                    u3 += ((unsigned)s0 - (u3 - i2));
                    i1 = a0[i0 & 3u] & 15u;
                    L4: if (--fuel == 0u) goto done;
                }
                r0.y ^= ((0xffffffffu % (p2 | 1u)) << ((unsigned)c0 & 31u));
                if (8u) {
                    *q0 += (unsigned)((int)(unsigned)h0 >= (int)0x80000000u);
                    s1 = (int)((unsigned)s1 + ((unsigned)(short)((unsigned)x0 % ((unsigned)h1 | 1u)) - p1));
                    r0.x = (u2 - (p1 >> ((unsigned)(u1 || *mp) & 31u)));
                    if (u1) break;
                    w0 = w0 * 6364136223846793005ull + ((unsigned)s1 / ((unsigned)d0 | 1u));
                } else {
                    break; (void)(((unsigned)(signed char)(0u >> (u3 & 31u)) - (unsigned)c0));
                }
                if ((a0[u1 & 3u] / ((unsigned)c1 | 1u))) goto L2;
                u2 = (0x6bc14a7u >> ((unsigned)((int)u1 < (int)(unsigned)c1) & 31u));
                *q0 = g0;
            }
        }
        v0 = (unsigned)((unsigned)(w0 >> 29) && p2);
        u0 = u0 * 0x9e3779b1u + (u2 * (v0 * u0));
        if ((unsigned)(i1 < (unsigned)s1)) goto L1;
        h1 = (unsigned short)(h1 + garr[i1 & 7u]);
        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)!(unsigned)((unsigned)s0 && (unsigned)b0) == (unsigned)w0) & 1023u);
    } while (i0++ < 4u && i0);
    h1 = (unsigned short)(h1 + (u3 ^ 0x1d75ebddu));
    *q0 += ((2u + 0x60cde35au) * (r0.x << (r0.x & 31u)));
    i1 = (unsigned)((int)0xaf3fdba6u >= (int)(i0 ^ (unsigned)(short)(unsigned)(0x7fffffffu || ((unsigned)(x0 >> 70) << (0xffffffffu & 31u))))) & 15u;
    if (*mp) goto done;
    if ((unsigned)(0u || *q0)) goto L3;
    i1 = (unsigned)(u0 < (unsigned)(x0 >> 70)) & 15u;
    s0 = (int)(unsigned)h0;
    if (~(((unsigned)x0 ^ i0) | g1)) goto L4;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1((p1 >> ((0xffffffffu - 0x1f1c8ecfu) & 31u)), (i0 / ((unsigned)b0 | 1u)), -(unsigned)((int)(i1 % ((unsigned)b0 | 1u)) >= (int)*q0)); }
    }
    if ((unsigned)(short)(unsigned)((unsigned)((int)(unsigned)f0 >= (int)p0) || 0x6aa4e5ceu)) goto L0;
    { unsigned t7; double z7; if (((((unsigned)h1 & (unsigned)(w0 >> 29)) ^ 0xffffffffu)) & 1u) { t7 = (unsigned)((int)(unsigned)(1u == p0) >= (int)garr[u2 & 7u]); z7 = (double)(((g0 + (g1 / (u2 | 1u)))) & 255u); } if (((((unsigned)h1 & (unsigned)(w0 >> 29)) ^ 0xffffffffu)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
        { unsigned t8; double z8; if (((unsigned)(r0.x == *mp)) & 1u) { t8 = (unsigned)(0x9928969bu < 0x9356b350u); z8 = (double)((((unsigned)x0 | m0)) & 255u); } if (((unsigned)(r0.x == *mp)) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
            s0 = (int)((unsigned)((unsigned)s1 == (unsigned)e0) & 0xffffffffu);
            { unsigned t9; double z9; if (((unsigned)(short)((unsigned)x0 ? (unsigned)d0 : (unsigned)(x0 >> 70))) & 1u) { t9 = (0xaf3a49e0u - (unsigned)(g0 == r0.x)); z9 = (double)((v0) & 255u); } if (((unsigned)(short)((unsigned)x0 ? (unsigned)d0 : (unsigned)(x0 >> 70))) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                goto L1;
                if ((unsigned)e0) goto done;
            }
            if (i2) goto L3;
            u2 = (unsigned)b0;
            if ((p1 << (0xc23a2538u & 31u))) goto L4;
            if (budget != 0u) { budget -= 1u; u3 = fn1(p1, ((unsigned)(w0 >> 29) ? i2 : 0x8d86d5e9u), ((unsigned)((unsigned)s0 == 9u) - i1)); }
        }
        h1 = (unsigned short)(h1 + ~((unsigned)((short)u0 > (signed char)*mp) * (unsigned)(r0.x == 0x10000u)));
        s0 = (int)(((unsigned)(9u == (unsigned)d0) + u3) / (-(0x10000u | a0[u1 & 3u]) | 1u));
        *mp = (unsigned)((0x10000u >> ((unsigned)e0 & 31u)) < (unsigned)s1);
        while (i0++ < 2u && (unsigned)((unsigned)c1 || (0x80000000u << (p1 & 31u)))) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((2u << ((unsigned)(a0[i0 & 3u] || 0xfd1086b4u) & 31u))) goto L4;
                break; (void)((unsigned)((int)p1 >= (int)(unsigned)c1));
            } while (i1++ < 2u && (unsigned)(short)((unsigned)(unsigned char)(unsigned)((unsigned)c1 < i0) - g1));
            x0 = x0 * 0x100000001b3ull + (unsigned)((short)0xad7e083bu > (signed char)6u);
            if (0x8a3a3fa9u) goto L3;
        }
        goto L2;
    }
    d0 = d0 * 0.5 + (double)((6u ^ v0) & 1023u);
    h0 = (short)((unsigned)x0 & (unsigned)(fuel == 0x8b536e69u));
    do { if (--fuel == 0u) goto done;
        { unsigned t10; double z10; if ((((0xe478c380u - i1) | (unsigned)x0)) & 1u) { t10 = u1; z10 = (double)(((unsigned)(((unsigned)s0 & 4u) && g0)) & 255u); } if ((((0xe478c380u - i1) | (unsigned)x0)) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
            continue; (void)((unsigned)h1);
            if (a0[i0 & 3u]) continue;
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((9u / (((unsigned)s1 >> (9u & 31u)) | 1u)), ~(unsigned)((unsigned)((int)a0[u1 & 3u] < (int)0x10000u) == *mp), (unsigned)((p2 >> (0x7fffffffu & 31u)) && r0.y)); }
                while (i2++ < 7u && (unsigned)(unsigned char)(((unsigned)h0 / ((unsigned)c1 | 1u)) / (3u | 1u))) { if (--fuel == 0u) goto done;
                    *q0 += -(unsigned)(i2 == (unsigned)l0);
                    if (((unsigned)f0 - (unsigned)(0x363a3970u || 0xffffffffu))) break;
                    m0 ^= (unsigned)((int)*mp < (int)u1);
                }
                w0 ^= (unsigned long long)(unsigned)(x0 >> 70) << ((unsigned)((i2 ? r0.y : 0xfe9e39e1u) || m0) & 63u);
                if ((unsigned)(unsigned char)((*mp >> (2u & 31u)) + (unsigned)w0)) break;
            }
            if ((unsigned)((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)c0) && (unsigned)b0)) break;
            r0.x = (unsigned)((int)(~(u0 << (0x10000u & 31u)) << ((unsigned)((unsigned)h0 || i0) & 31u)) >= (int)garr[u2 & 7u]);
            do { if (--fuel == 0u) goto done;
                break; (void)((p0 << ((unsigned)d0 & 31u)));
                garr[((unsigned)c0 / (i2 | 1u)) & 7u] = ((6u + (unsigned)f0) & 0x87d66eabu);
                u3 ^= (0x9a5606e2u + 0x64d2911au);
                r0.y ^= (((u3 >> (g1 & 31u)) % ((a0[u1 & 3u] | (unsigned)l0) | 1u)) - p2);
                while ((unsigned)(short)(unsigned)((g0 >> (0x80000000u & 31u)) || p1)) { if (--fuel == 0u) goto done;
                    if ((m0 & fuel)) goto L1;
                    h0 = (short)(((0xffffffffu - 8u) >> ((unsigned)l0 & 31u)) * r0.x);
                    if ((unsigned)(signed char)((unsigned)(unsigned char)(r0.x / ((unsigned)h0 | 1u)) / (u3 | 1u))) {
                        break; (void)((unsigned)((int)garr[i1 & 7u] < (int)(unsigned)(0x10000u || garr[i1 & 7u])));
                        if (((unsigned)s1 ^ p2)) break;
                        continue; (void)(2u);
                        r0.x = (unsigned)((int)(unsigned)w0 >= (int)i1);
                        b0 = (unsigned)((int)((unsigned)c0 + (u1 - (unsigned)c1)) >= (int)1u) != 0u;
                        if ((unsigned)((p0 | p0) || 1u)) {
                            if ((i0 & (unsigned)((unsigned)h0 == (unsigned)e0))) break;
                            if ((unsigned)(signed char)(unsigned)(0xffffffffu < garr[u2 & 7u])) break;
                            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(signed char)(0x80000000u * (unsigned)!(unsigned)((unsigned)(x0 >> 70) && 9u)) < (p0 | 0xe6738489u)) & 255u);
                            if ((0x10000u + 8u)) break;
                            if (u3 == 7u) return (0xb6e7bdf2u - (((unsigned)s0 | a0[i0 & 3u]) | g1));
                            continue; (void)(0x778e96b6u);
                        }
                    }
                    { unsigned t11; double z11; if ((((unsigned)b0 | (unsigned)((int)(unsigned)h1 < (int)garr[u2 & 7u]))) & 1u) { t11 = (unsigned)(short)(unsigned)((int)0u >= (int)(unsigned)(r0.y || (unsigned)h0)); z11 = (double)((a0[i0 & 3u]) & 255u); } if ((((unsigned)b0 | (unsigned)((int)(unsigned)h1 < (int)garr[u2 & 7u]))) & 1u) { u3 += t11; d0 = d0 * 0.5 + z11; }
                        *q0 += (((unsigned)c1 ^ 0x80000000u) ^ (0xffffffffu | 0x7fffffffu));
                    }
                }
            } while (i1++ < 3u && (unsigned)l0);
        }
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (0x1456e0c4u << ((unsigned)((unsigned)(short)(2u | g1) || g1) & 31u)));
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (-(unsigned)((int)((unsigned)(x0 >> 70) * p0) < (int)(unsigned)s0)) break;
                if ((unsigned)h0) break;
            }
            h0 = (short)((0u >> (8u & 31u)) / ((unsigned)((unsigned)f0 || ((unsigned)e0 << (6u & 31u))) | 1u));
            while (garr[u2 & 7u]) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)(0x6a6af0d6u && 0x7fffffffu) << ((7u * (unsigned)(x0 >> 70)) & 63u);
                w0 = w0 * 6364136223846793005ull + ~(((unsigned)d0 / (g0 | 1u)) - (unsigned)c1);
            }
            break; (void)((unsigned)((short)(unsigned)((int)0xfa8592c0u < (int)(unsigned)(x0 >> 70)) > (signed char)p2));
        }
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)x0) {
                u1 = (unsigned)((unsigned)h1 || r0.x);
                g1 += (0xffffffffu ^ 0x10000u);
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)l0 >= (int)(unsigned)(2u || g1)), (unsigned)(u3 == garr[u2 & 7u]), ((unsigned)f0 / ((unsigned)(signed char)(r0.x >> ((unsigned)w0 & 31u)) | 1u))); }
                if ((unsigned)((short)a0[i0 & 3u] > (signed char)fuel)) continue;
            }
            s0 = (int)(unsigned)((int)garr[u2 & 7u] < (int)(0xa154bd61u & (unsigned)x0));
        }
        if ((*mp >> ((u0 << (0x7fffffffu & 31u)) & 31u))) break;
        break; (void)((unsigned)((unsigned)((int)g1 >= (int)u1) == r0.y));
    } while (i0++ < 7u && (u1 % (0x8ccd2c52u | 1u)));
    i0 = (((unsigned)w0 & 2u) & (unsigned)e0) & 15u;
    if ((unsigned)((int)m0 >= (int)g1)) goto L2;
    if ((unsigned)((unsigned)s1 == 6u)) goto L0;
    if (0x10000u) goto L2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)(i0 < (unsigned)h0) << (garr[i1 & 7u] & 31u)), (0x10000u - (unsigned)c0), (unsigned)(unsigned char)(garr[u2 & 7u] / ((unsigned)e0 | 1u))); }
    if ((unsigned)(x0 >> 70)) goto L1;
    r0.y ^= (unsigned)((int)(unsigned)((unsigned)((short)-(unsigned)((unsigned)s0 && u0) > (signed char)0xb463f32du) == (unsigned)f0) >= (int)(unsigned)w0);
    while (i0++ < 6u && (unsigned)!(unsigned)(1u < ((unsigned)c0 ^ (unsigned)(w0 >> 29)))) { if (--fuel == 0u) goto done;
        q0 = &garr[((v0 << (0u & 31u)) % (i0 | 1u)) & 7u];
        w0 ^= (unsigned long long)i1 << (-(unsigned)((int)0xffffffffu < (int)0u) & 63u);
        do { if (--fuel == 0u) goto done;
            if ((g1 | (unsigned)h1)) {
                r0.x = p1;
                L0: if (--fuel == 0u) goto done;
            } else {
                switch ((0x7fffffffu * (unsigned)b0) & 7u) {
                    c0 = (unsigned char)(unsigned)((int)((unsigned)d0 % (i0 | 1u)) >= (int)(u0 % (i1 | 1u)));
                    if ((unsigned)((short)0x603dd895u > (signed char)(unsigned)d0)) break;
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        b0 = ((m0 << (6u & 31u)) ^ ((g0 << (4u & 31u)) - (unsigned)d0)) != 0u;
                        r0.y ^= (unsigned)e0;
                    }
                    r0.y ^= (unsigned)((int)(unsigned)(signed char)(unsigned)((int)(unsigned)e0 < (int)(unsigned)h0) < (int)(unsigned)b0);
                    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(r0.y || (unsigned)h0), (unsigned)!(i0 | r0.y), (a0[u1 & 3u] & 0x80000000u)); }
                }
                L1: if (--fuel == 0u) goto done;
            }
            u2 += 0xba80faf9u;
            if (0x4b37eafau) break;
            s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((unsigned)(x0 >> 70) || *q0) >= (int)(0xffffffffu ^ (unsigned)(signed char)(unsigned)((short)(unsigned)d0 > (signed char)p1))));
            v0 = (unsigned)(((unsigned)c1 ^ fuel) == ((unsigned)c0 + a0[i0 & 3u]));
        } while (i1++ < 2u && *mp);
    }
    *mp = (unsigned)w0;
    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(i0 || 0x10000u) == (0x80000000u - a0[u1 & 3u]));
    u3 = u3 * 0x9e3779b1u + (i2 % (0xe9718e77u | 1u));
    if (*q0) goto done;
    g1 += (p2 << ((unsigned)!(unsigned)((unsigned)s0 < m0) & 31u));
    x0 = x0 * 0x100000001b3ull + (m0 * 0x5bf04c5du);
    s0 = (int)(unsigned)(unsigned char)(unsigned)((unsigned)c0 && (unsigned)((u3 * 0x80000000u) || 0x7fffffffu));
    L2: if (--fuel == 0u) goto done;
    a0[(unsigned)((unsigned)(w0 >> 29) && g1) & 3u] = p0;
    if ((unsigned)(*q0 < (unsigned)(short)(u0 * a0[i0 & 3u]))) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(u1 % ((unsigned)(((unsigned)s1 / (p2 | 1u)) < g0) | 1u));
        }
        q0 = &garr[((unsigned)h0 - (0xa686863bu >> (u1 & 31u))) & 7u];
        if (u3) goto done;
        g1 += ((((unsigned)f0 ? (unsigned)c0 : *q0) / ((unsigned)x0 | 1u)) ^ (unsigned)c1);
    } else {
        w0 = w0 * 6364136223846793005ull + (unsigned)!((unsigned)(short)(((unsigned)f0 / (4u | 1u)) - (unsigned)s1) << (r0.x & 31u));
        *q0 = p1;
    }
    if (p2) {
        h0 = (short)(i1 - (unsigned)(signed char)(unsigned)((0x6b396f6du >> ((unsigned)((unsigned)h1 == (unsigned)e0) & 31u)) < 0x4195cb44u));
    } else {
        if (budget != 0u) { budget -= 1u; u0 = fn3((p1 & m0), (unsigned)((unsigned)c0 == 0x355dbc61u), (0x10000u & g0)); }
    }
    if (((unsigned)s0 | (unsigned)((int)(unsigned)f0 >= (int)0x12e80f0eu))) {
        f0 = f0 * 0.5f + (float)(((unsigned)((int)r0.x >= (int)i0) % (u2 | 1u)) & 255u);
        u3 ^= ((m0 * r0.y) % (((unsigned)!(unsigned)(5u == a0[u1 & 3u]) / (*mp | 1u)) | 1u));
    }
    if ((0xffffffffu % (p1 | 1u))) {
        garr[(0x80000000u | v0) & 7u] = 2u;
    }
    if ((garr[u2 & 7u] << ((unsigned)!(0x8e576136u & p1) & 31u))) goto L0;
    w0 = w0 * 6364136223846793005ull + (unsigned)!((unsigned)(((unsigned)c0 | *q0) < ~(unsigned)(u1 < 3u)) % (0xffffffffu | 1u));
    if (2u) {
        h0 = (short)4u;
        if (~(0x5c5793eeu & (unsigned)e0)) goto L3;
        L3: if (--fuel == 0u) goto done;
    } else {
        if ((i0 / (0xb13b1a71u | 1u))) {
            if ((0x32443c65u ^ (p2 & i0))) goto L1;
        } else {
            h1 = (unsigned short)(h1 + (unsigned)((int)(u0 % (a0[i0 & 3u] | 1u)) >= (int)(unsigned)(w0 >> 29)));
        }
    }
    if ((unsigned)c0) {
        r0.x = (*q0 & ((unsigned)s0 | (fuel * u2)));
        c1 = (signed char)(r0.y << (0x14de6e05u & 31u));
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)(u3 < ((unsigned)((i0 >> (a0[i0 & 3u] & 31u)) && (unsigned)s0) - 4u));
        }
    } else {
        switch ((((unsigned)l0 % (i2 | 1u)) / (r0.x | 1u)) & 7u) {
            L4: if (--fuel == 0u) goto done;
            case 7u: ;
            l0 = (long)((unsigned long)l0 + (0x4e097e72u ? (unsigned)(0x7fffffffu == p2) : p0));
            b0 = ((u1 ^ (unsigned)b0) - ((unsigned)(unsigned char)(unsigned)(0xd00dc71fu == (unsigned)w0) | (unsigned)h1)) != 0u;
        }
        if ((unsigned)(i0 == garr[i1 & 7u])) {
            m0 ^= (unsigned)s0;
            if ((unsigned)(0x80000000u < (unsigned)(w0 >> 29))) goto L1;
            while (i0++ < 6u && (unsigned)(i2 && (unsigned)x0)) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + 2u);
                if (u3 == 7u) return (unsigned)(0x10000u < (a0[i0 & 3u] * ((unsigned)b0 << ((unsigned)((short)0x10000u > (signed char)g1) & 31u))));
                do { if (--fuel == 0u) goto done;
                    if ((garr[u2 & 7u] & (unsigned)c0)) break;
                    { unsigned t0; double z0; if (((garr[i1 & 7u] / ((unsigned)((int)r0.x < (int)0x7fffffffu) | 1u))) & 1u) { t0 = (2u + 0x48ed182du); z0 = (double)(((unsigned)(*q0 && 0xc1653559u)) & 255u); } if (((garr[i1 & 7u] / ((unsigned)((int)r0.x < (int)0x7fffffffu) | 1u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                        w0 ^= (unsigned long long)(unsigned)h0 << (0xffffffffu & 63u);
                        v0 = (unsigned)(short)(unsigned)((int)(unsigned)(((unsigned)c1 | (unsigned)x0) || (r0.x >> ((unsigned)w0 & 31u))) < (int)(unsigned)h0);
                    }
                    { unsigned t1; double z1; if (((unsigned)((short)u1 > (signed char)((unsigned)w0 >> (0x2ebf6000u & 31u)))) & 1u) { t1 = (v0 | 0x80000000u); z1 = (double)(((unsigned)((unsigned)c0 && (u2 + (unsigned)h1))) & 255u); } if (((unsigned)((short)u1 > (signed char)((unsigned)w0 >> (0x2ebf6000u & 31u)))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                        goto done;
                    }
                } while (i1++ < 5u && (i0 / ((unsigned)(v0 && a0[i0 & 3u]) | 1u)));
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)x0 ? a0[i0 & 3u] : *q0), (0u % (9u | 1u)), (unsigned)(fuel == (unsigned)(unsigned char)(i2 % ((unsigned)c0 | 1u)))); }
                }
                { unsigned t2; double z2; if (((unsigned)(m0 || (4u / (p1 | 1u)))) & 1u) { t2 = (unsigned)(p0 == (unsigned)e0); z2 = (double)(((unsigned)c0) & 255u); } if (((unsigned)(m0 || (4u / (p1 | 1u)))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    if (0x10000u) break;
                }
            }
            if ((unsigned)((unsigned)(x0 >> 70) < -(p1 - 1u))) goto L1;
        }
        if ((unsigned)b0) {
            c0 = (unsigned char)((unsigned)d0 - i0);
        } else {
            switch (0x7fffffffu & 7u) {
                u1 += (unsigned)s0;
            }
        }
        x0 = x0 * 0x100000001b3ull + (u1 % (u0 | 1u));
    }
    { unsigned t3; double z3; if (((unsigned)((int)0x10000u >= (int)(unsigned)(w0 >> 29))) & 1u) { t3 = 0xffffffffu; z3 = (double)(((unsigned)(short)(garr[i1 & 7u] ? (unsigned)x0 : (unsigned)h1)) & 255u); } if (((unsigned)((int)0x10000u >= (int)(unsigned)(w0 >> 29))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)((short)garr[i1 & 7u] > (signed char)*mp) & (unsigned)s1), (unsigned)(((unsigned)c1 | 0xffffffffu) || r0.x), (0x80000000u ^ (unsigned)e0)); }
        r0.x = (unsigned)((unsigned)(x0 >> 70) && (unsigned)c1);
        b0 = (unsigned)((0x75600d36u % (0x93ebe294u | 1u)) || 0x10000u) != 0u;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)(garr[u2 & 7u] == p0), (unsigned)h1, (unsigned)(4u == 5u)); }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!(unsigned)((unsigned)h0 && (0xd73c36e5u * garr[i1 & 7u])), (unsigned)(short)(unsigned)(~(2u * (unsigned)s0) == m0), (0x87f5a02au / (0x10000u | 1u))); }
    if (budget != 0u) { budget -= 1u; u0 = fn1(0x8aeb1525u, u3, (unsigned)(signed char)(0xe9b62326u * (unsigned)h1)); }
    u1 = (0x10000u ^ p2);
    *q0 = ((7u % (i0 | 1u)) & (unsigned)s1);
    if ((p0 << (p2 & 31u))) goto L3;
    if (~(p0 % (garr[i1 & 7u] | 1u))) goto L3;
    b0 = (unsigned)((unsigned)c1 < p2) != 0u;
    if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)!(p1 << (4u & 31u)), (a0[i0 & 3u] | p0), ((unsigned)(unsigned char)(a0[u1 & 3u] % (m0 | 1u)) >> ((unsigned)s0 & 31u))); }
    if (garr[i1 & 7u]) goto L0;
    *q0 = (u1 ^ (unsigned)s0);
    a0[g1 & 3u] = (unsigned)((short)(g1 >> (0xc5949e8eu & 31u)) > (signed char)(a0[i0 & 3u] >> ((unsigned)h0 & 31u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 4u, 0x76ff31c5u, 0x8486500bu },
        { 6u, 0x2e177a62u, 0xfcdd2f0du },
        { 7u, 0xa4206bbeu, 0x107dc883u },
        { 3u, 0x53c9226bu, 0x334594e5u },
        { 5u, 0xaabf6a13u, 0x30b3c69du },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
