// test-ssa-source's program of seed 141000436 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xc0d6079cu, g1 = 0x18738985u;
static unsigned garr[8] = { 0xbc1efb26u, 0x51b2c0c5u, 0x3bc75bdau, 0xddc2a9f4u, 0xe3901c1u, 0x4b988a12u, 0x47955834u, 0x9f0a3596u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    if ((p0 << ((unsigned)(x0 >> 70) & 31u))) {
        u2 = u2 * 0x9e3779b1u + (0x8d236b9u + (((unsigned)c0 + (unsigned)((unsigned)(x0 >> 70) || 0x10000u)) + (unsigned)h0));
        do { if (--fuel == 0u) goto done;
            if ((i1 + 0xffffffffu)) {
                L1: if (--fuel == 0u) goto done;
                if ((unsigned)(0x482fdaccu < a0[i0 & 3u])) {
                    w0 = w0 * 6364136223846793005ull + (unsigned)s0;
                } else {
                    L2: if (--fuel == 0u) goto done;
                    if ((unsigned)((short)i0 > (signed char)0xffffffffu)) {
                        L3: if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)(1u & 1023u);
                        L4: if (--fuel == 0u) goto done;
                        break; (void)((unsigned)(p1 || p2));
                    } else {
                        { unsigned t0; double z0; if ((p1) & 1u) { t0 = ((unsigned)c0 ? 0x7fffffffu : garr[i1 & 7u]); z0 = (double)(((g1 & (unsigned)((int)i0 < (int)*q0))) & 255u); } if ((p1) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                            continue; (void)((unsigned)((int)(unsigned)f0 >= (int)((unsigned)x0 << (2u & 31u))));
                            g1 += (unsigned)(*mp && *mp);
                            if (u3 == 7u) return ((g1 | 0x1c75e688u) + (unsigned)(w0 >> 29));
                            q0 = &garr[(garr[i1 & 7u] - 0xffffffffu) & 7u];
                        }
                        if (r0.y) break;
                        c0 = (unsigned char)((unsigned)((6u * (unsigned)b0) < (unsigned)c1) % ((unsigned)((unsigned)b0 < garr[u2 & 7u]) | 1u));
                        if ((unsigned)(short)((g0 + i2) & 8u)) {
                            f0 = f0 * 0.5f + (float)((unsigned)((int)g1 < (int)(unsigned)((int)0x7fffffffu >= (int)(unsigned)((int)(unsigned)c0 < (int)0xb6260ad6u))) & 255u);
                            break; (void)((0xe6d4516bu | (p2 / ((unsigned)e0 | 1u))));
                            x0 = x0 * 0x100000001b3ull + v0;
                        } else {
                            if ((unsigned)(0x7908975bu && (unsigned)((int)(unsigned)b0 >= (int)(unsigned)w0))) break;
                        }
                    }
                    g0 = ((unsigned)d0 ^ (unsigned)((0x80000000u - 4u) && (v0 + (unsigned)c1)));
                    s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)((unsigned)h1 < 0x80000000u) < (int)(unsigned)w0));
                }
                if (0xd1fdbf59u) break;
                switch ((unsigned)(((unsigned)l0 & 4u) && garr[i1 & 7u]) & 7u) {
                    l0 = (long)((unsigned long)l0 + ((unsigned)(short)(unsigned)(0x80000000u == fuel) | ((unsigned)c1 << ((unsigned)(0x4f8a2638u == u0) & 31u))));
                    case 0u: ;
                    c1 = (signed char)~(unsigned)(1u || 0xffffffffu);
                    if ((unsigned)c1) {
                        c1 = (signed char)(fuel % ((a0[i0 & 3u] ? (0x80000000u & *mp) : (unsigned)b0) | 1u));
                        i0 = (((unsigned)w0 * 0xffffffffu) * (unsigned)((short)i0 > (signed char)*q0)) & 15u;
                        g1 += (unsigned)(short)(unsigned)((int)p1 >= (int)i2);
                    } else {
                        f0 = f0 * 0.5f + (float)((3u + (unsigned)(7u || (a0[i0 & 3u] | 0x7fffffffu))) & 255u);
                    }
                    case 1u: ;
                }
                u2 += (unsigned)c1;
                if ((unsigned)((int)*mp < (int)0x10000u)) break;
            }
            e0 = e0 * 0.5L + (long double)(((7u >> (5u & 31u)) & (5u + (unsigned)(6u && 4u))) & 1023u);
            { unsigned t1; double z1; if ((((unsigned)w0 | (v0 * 9u))) & 1u) { t1 = (0x3f3dfb0bu / (0x7aa39d7au | 1u)); z1 = (double)(((unsigned)((short)(u3 / ((unsigned)h1 | 1u)) > (signed char)(unsigned)l0)) & 255u); } if ((((unsigned)w0 | (v0 * 9u))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                switch ((unsigned)!((unsigned)f0 + i2) & 7u) {
                    { unsigned t2; double z2; if (((unsigned)(short)(unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)e0 || (unsigned)w0) || 0xcf64a921u)) & 1u) { t2 = (unsigned)(unsigned char)(0xb735c32bu + (i0 << ((unsigned)w0 & 31u))); z2 = (double)(((unsigned)((unsigned)((short)(unsigned)h1 > (signed char)r0.y) == i2)) & 255u); } if (((unsigned)(short)(unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)e0 || (unsigned)w0) || 0xcf64a921u)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                        case 1u: ;
                    }
                    s0 = (int)(unsigned)((unsigned)(signed char)(unsigned)(0x80000000u || u1) || (unsigned)(*mp < garr[u2 & 7u]));
                    case 7u: ;
                }
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (~(p1 ? u3 : v0)) break;
                    u2 += (unsigned)(u2 < (unsigned)s1);
                    if ((unsigned)l0) break;
                    if (0xd0dfc749u) {
                        i1 = (unsigned)(i2 == (u3 - p2)) & 15u;
                    } else {
                        *mp = (unsigned)((short)0x80000000u > (signed char)g0);
                    }
                    u1 = ((a0[i0 & 3u] ^ 8u) ? (unsigned)h1 : ((unsigned)h1 & 0xffffffffu));
                    if (-(unsigned)((int)0x13f60be9u >= (int)garr[i1 & 7u])) break;
                }
                break; (void)((unsigned)(a0[u1 & 3u] || g1));
                goto L1;
                w0 ^= (unsigned long long)(garr[i1 & 7u] * u3) << (r0.x & 63u);
                if (((unsigned)((unsigned)h0 || a0[u1 & 3u]) & 0x9e608da6u)) break;
            }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((0x7fffffffu * u0)) break;
            }
            if ((unsigned)((unsigned)(w0 >> 29) || 5u)) {
                if ((*mp % ((unsigned)(short)(fuel | u0) | 1u))) {
                    { unsigned t3; double z3; if ((0x85527f94u) & 1u) { t3 = (*mp << (0x47af08b1u & 31u)); z3 = (double)((((unsigned)((int)(unsigned)(w0 >> 29) < (int)i2) / (p0 | 1u))) & 255u); } if ((0x85527f94u) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                        if ((0xb39d241eu % ((unsigned)c1 | 1u))) break;
                        if ((unsigned)c0) continue;
                        if (((p2 & (unsigned)(x0 >> 70)) - *mp)) break;
                        switch ((unsigned)(p0 < u0) & 7u) {
                            if (u3 == 7u) return (unsigned)h1;
                            case 6u: ;
                        }
                    }
                    if (0xffffffffu) goto done;
                    do { if (--fuel == 0u) goto done;
                        if (3u) break;
                        m0 ^= (((unsigned)((unsigned)f0 || u0) & (1u / (i1 | 1u))) * 0x10000u);
                        w0 ^= (unsigned long long)a0[u1 & 3u] << (((unsigned)(0x10000u || m0) ? (unsigned)c1 : 0x10000u) & 63u);
                        f0 = f0 * 0.5f + (float)((unsigned)((short)1u > (signed char)(unsigned)(short)(p0 - v0)) & 255u);
                        goto done;
                    } while (i1++ < 5u && (v0 / ((unsigned)x0 | 1u)));
                    if ((unsigned)((int)*mp < (int)0x3c590a7bu)) break;
                } else {
                    if (~(unsigned)(g1 || 1u)) continue;
                }
            } else {
                if ((unsigned)((v0 % (*mp | 1u)) < 0x51add0aau)) break;
                if (i1) break;
                if (((unsigned)c0 + (0x7fffffffu << (p1 & 31u)))) continue;
                b0 = (unsigned)d0 != 0u;
            }
            for (;;) { if (--fuel == 0u) goto done;
                g0 = (unsigned)((unsigned)(short)(r0.y + (unsigned)h0) && p1);
                do { if (--fuel == 0u) goto done;
                    if (((unsigned)c1 ? m0 : 0x88545463u)) break;
                    q0 = &garr[(unsigned)((short)(unsigned)((unsigned)c1 == m0) > (signed char)(unsigned)f0) & 7u];
                    if ((unsigned)(p1 || (*mp - g0))) break;
                    u1 += ((unsigned)(u0 < g1) * (unsigned)f0);
                    f0 = f0 * 0.5f + (float)((u3 << (((unsigned)(0xffffffffu && (unsigned)f0) / (r0.x | 1u)) & 31u)) & 255u);
                    switch ((unsigned)((int)(unsigned)w0 < (int)g1) & 7u) {
                        f0 = f0 * 0.5f + (float)((0x80000000u << ((unsigned)!((p2 * (unsigned)(u1 == (unsigned)(x0 >> 70))) >> ((unsigned)b0 & 31u)) & 31u)) & 255u);
                        case 6u: ;
                        default: ;
                    }
                } while (i2++ < 5u && (unsigned)((int)u0 >= (int)p2));
                if ((unsigned)(w0 >> 29)) goto L1;
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(u1 - 0x500b8c94u);
                }
                f0 = f0 * 0.5f + (float)(3u & 255u);
                break; (void)(r0.x);
            }
        } while (i0++ < 6u && (g1 * (unsigned)f0));
        if ((unsigned)(((unsigned)(x0 >> 70) & a0[i0 & 3u]) == (unsigned)x0)) goto L1;
    } else {
        goto L3;
        if ((0xffffffffu - (unsigned)((int)p1 >= (int)0xb7bd081u))) {
            goto L4;
        } else {
            q0 = &garr[(unsigned)((int)(*q0 ^ *mp) < (int)(unsigned)e0) & 7u];
            if (p2) goto L4;
            if ((i2 << (m0 & 31u))) {
                if ((unsigned)(u0 == (unsigned)(x0 >> 70))) goto L4;
                for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (garr[u2 & 7u]) break;
                    g0 = (unsigned)s1;
                    if ((unsigned)b0) {
                        continue; (void)((unsigned)(0x80000000u || (unsigned)((int)0x7fffffffu < (int)0u)));
                    } else {
                        u0 = u0 * 0x9e3779b1u + (i0 & ((unsigned)c0 * (6u >> (u2 & 31u))));
                        if (0x58763fcdu) break;
                    }
                    if (m0) break;
                    for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (garr[i1 & 7u]) break;
                        if (((unsigned)(i0 && garr[u2 & 7u]) % (i2 | 1u))) {
                            if ((unsigned)((a0[i0 & 3u] | (unsigned)s0) == 0x80000000u)) break;
                        }
                        r0.x = -(unsigned)((int)(garr[u2 & 7u] & (unsigned)(signed char)(unsigned)((unsigned)x0 == 0x919f95afu)) < (int)(unsigned)((short)3u > (signed char)0x6d711fcfu));
                        u1 += v0;
                        a0[0x5c751f1bu & 3u] = (unsigned)((int)(unsigned)(0x80000000u < ((unsigned)(garr[i1 & 7u] == 0x260925fbu) + 0x574d41c5u)) >= (int)(unsigned)(w0 >> 29));
                        a0[0x18b029dau & 3u] = (a0[i0 & 3u] >> (a0[i0 & 3u] & 31u));
                    }
                    do { if (--fuel == 0u) goto done;
                        u1 += (a0[u1 & 3u] | (unsigned)l0);
                    } while (i1++ < 3u && (v0 + 0xffffffffu));
                }
                h1 = (unsigned short)(h1 + 0x31dce753u);
            } else {
                u2 = (p1 / (garr[i1 & 7u] | 1u));
            }
        }
        b0 = (*mp >> (((unsigned)(unsigned char)(u2 / (i0 | 1u)) >> ((unsigned)e0 & 31u)) & 31u)) != 0u;
    }
    while ((0xe27e95bu & p1)) { if (--fuel == 0u) goto done;
        h0 = (short)(unsigned)((short)v0 > (signed char)(unsigned)f0);
        if ((0x40d1c40u + (a0[i0 & 3u] * *mp))) break;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((p0 ^ 0x9c5d0f7eu)) break;
                if ((unsigned)(signed char)(unsigned)(u1 && i0)) break;
                for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (0x10000u) break;
                    w0 ^= (unsigned long long)(unsigned)(signed char)(4u | 0x80000000u) << (p0 & 63u);
                    if ((unsigned)(i1 < 0x536b77e1u)) {
                        if (((unsigned)c1 ^ u3)) break;
                        switch ((unsigned)(unsigned char)(0x80000000u << ((unsigned)s1 & 31u)) & 7u) {
                            f0 = f0 * 0.5f + (float)((((unsigned)(x0 >> 70) & u1) * *mp) & 255u);
                            f0 = f0 * 0.5f + (float)((unsigned)(short)((unsigned)c0 << (u2 & 31u)) & 255u);
                            h0 = (short)((unsigned)h0 & (unsigned)c1);
                            s1 = (int)((unsigned)s1 + ((i1 >> (0xedd1986fu & 31u)) ^ ~(unsigned)(9u || a0[u1 & 3u])));
                            if ((p0 - (unsigned)c0)) break;
                        }
                        x0 = x0 * 0x100000001b3ull + ((r0.y - (unsigned)((short)(unsigned)d0 > (signed char)0x7fffffffu)) >> (u1 & 31u));
                        e0 = e0 * 0.5L + (long double)((0x2f7bb377u * (unsigned)(u2 == i1)) & 1023u);
                        if ((unsigned)((int)(unsigned)c0 >= (int)(unsigned)f0)) break;
                    }
                    if ((unsigned)((short)a0[u1 & 3u] > (signed char)5u)) break;
                }
            } while (i2++ < 2u && -(unsigned)(r0.y && (unsigned)e0));
            if (garr[u2 & 7u]) goto L3;
            if (4u) break;
            if (((unsigned)x0 % ((unsigned)d0 | 1u))) break;
            if (((0x7fffffffu * (unsigned)d0) | r0.y)) {
                switch ((unsigned)((unsigned)(w0 >> 29) < u3) & 7u) {
                    case 7u: ;
                    f0 = f0 * 0.5f + (float)((*mp + r0.y) & 255u);
                    case 6u: ;
                    goto done;
                }
                if ((unsigned)((unsigned)l0 == 0x45ec545fu)) break;
            }
            while (i2++ < 2u && ((unsigned)s1 & (m0 << (0xa7e55b52u & 31u)))) { if (--fuel == 0u) goto done;
                r0.x = (unsigned)e0;
                if (i2) break;
                *mp = (unsigned)((8u * 7u) || (unsigned)(p1 == p2));
            }
        }
    }
    goto L1;
    if ((a0[u1 & 3u] - a0[i0 & 3u])) {
        if ((unsigned)w0) goto L1;
        u0 ^= (unsigned)((unsigned)(0x85db5ffeu || (unsigned)(x0 >> 70)) == 8u);
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)!((0xffffffffu * (unsigned)(w0 >> 29)) % (0x9e24e343u | 1u))) break;
            s0 = (int)(i2 | (unsigned)(short)(p0 % (g0 | 1u)));
            if (-(*q0 % (fuel | 1u))) break;
            if (((unsigned)s0 << (0x7fffffffu & 31u))) break;
        }
    } else {
        if ((0x10000u / ((unsigned)d0 | 1u))) goto L4;
        w0 ^= (unsigned long long)(g0 << (p0 & 31u)) << ((unsigned)((int)(unsigned)(0xe9f18c14u && 0x80000000u) >= (int)-(unsigned)((short)(unsigned)(signed char)(unsigned)((unsigned)d0 && i2) > (signed char)0x7fffffffu)) & 63u);
    }
    goto done;
    do { if (--fuel == 0u) goto done;
        u3 = (unsigned)((unsigned)h1 || p0);
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            continue; (void)((u1 & 0x9eb63971u));
            if ((u0 / (g1 | 1u))) break;
        }
        if ((unsigned)((int)(unsigned)(r0.x || a0[i0 & 3u]) >= (int)p0)) break;
    } while (i0++ < 7u && (~(3u & 6u) >> (u2 & 31u)));
    c1 = (signed char)(unsigned)((int)3u >= (int)(unsigned)(6u == m0));
    while (i0++ < 5u && (unsigned)((int)u2 < (int)(unsigned)s1)) { if (--fuel == 0u) goto done;
        garr[(unsigned)b0 & 7u] = (unsigned)((unsigned)s0 < 3u);
        { unsigned t4; double z4; if ((0xe4210010u) & 1u) { t4 = (u2 % (u2 | 1u)); z4 = (double)((~(unsigned)((short)(unsigned)c0 > (signed char)(garr[u2 & 7u] * 3u))) & 255u); } if ((0xe4210010u) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            if ((unsigned)((int)~(0x7fffffffu ^ (unsigned)w0) >= (int)p2)) break;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                u2 = (0x10000u - a0[u1 & 3u]);
            }
        }
        q0 = &garr[(unsigned)(9u || 0xffffffffu) & 7u];
        if ((unsigned)((int)(unsigned)(short)(unsigned)((short)i2 > (signed char)0x10000u) >= (int)u1)) break;
        if (((unsigned)s0 << ((unsigned)(r0.x || 0u) & 31u))) break;
        if (a0[i0 & 3u]) break;
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((0xe31d1d0fu % ((unsigned)h1 | 1u))) break;
        if (u3) break;
        q0 = &garr[(i2 << ((unsigned)((int)(unsigned)((unsigned)s0 == (unsigned)((unsigned)b0 < (unsigned)h1)) >= (int)u3) & 31u)) & 7u];
    }
    if (fuel < 8u) return (unsigned)((int)g1 < (int)((0x7fffffffu & *q0) ^ 0x33472a49u));
    l0 = (long)((unsigned long)l0 + (unsigned)(i1 || (unsigned)e0));
    c1 = (signed char)((unsigned)(w0 >> 29) / ((unsigned)(short)((garr[i1 & 7u] | (unsigned)h0) >> ((unsigned)(x0 >> 70) & 31u)) | 1u));
    do { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (unsigned)(short)((unsigned)((int)*mp < (int)0x361d9a16u) / ((unsigned)e0 | 1u)));
        if ((9u % ((unsigned)s0 | 1u))) continue;
        { unsigned t5; double z5; if (((unsigned)b0) & 1u) { t5 = (unsigned)((short)((unsigned)e0 + (unsigned)h1) > (signed char)p0); z5 = (double)(((u3 ? u2 : 6u)) & 255u); } if (((unsigned)b0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            if ((unsigned)c1) break;
            do { if (--fuel == 0u) goto done;
                break; (void)((0x10000u * (unsigned)(x0 >> 70)));
                if ((u1 | (unsigned)((short)3u > (signed char)u3))) break;
                a0[(unsigned)(unsigned char)(0xaffa1af7u | 0u) & 3u] = ((unsigned)((unsigned)(0x71a2c756u == (unsigned)s0) || i1) * (unsigned)s0);
                *q0 = (unsigned)(unsigned char)(unsigned)((int)0x9bd7a094u < (int)(u3 << ((unsigned)h1 & 31u)));
                if ((unsigned)(signed char)(unsigned)(3u && i1)) {
                    c1 = (signed char)-(r0.y >> ((unsigned)(fuel && 0x11df1337u) & 31u));
                    h1 = (unsigned short)(h1 + (unsigned)((int)u0 < (int)((unsigned)c0 / ((unsigned)s0 | 1u))));
                    *mp = -(i0 / ((unsigned)b0 | 1u));
                    m0 ^= ((unsigned)f0 >> (u2 & 31u));
                    u0 = r0.x;
                } else {
                    break; (void)(0x24429101u);
                    m0 ^= p1;
                }
                if ((0xffffffffu + (unsigned)(x0 >> 70))) continue;
            } while (i1++ < 4u && p0);
            if (((unsigned)s1 ^ 0x7fffffffu)) continue;
            if ((unsigned)(w0 >> 29)) goto L3;
            if (-((unsigned)f0 + fuel)) break;
        }
        if ((unsigned)(short)(unsigned)((unsigned)x0 && (5u / (0x10000u | 1u)))) goto L0;
        break; (void)(0xffffffffu);
        break; (void)((unsigned)(unsigned char)((unsigned)h1 * garr[i1 & 7u]));
    } while (i0++ < 4u && (unsigned)((short)0x71545045u > (signed char)(unsigned)(i2 == a0[i0 & 3u])));
    e0 = e0 * 0.5L + (long double)((unsigned)d0 & 1023u);
    w0 ^= (unsigned long long)(unsigned)(p0 || 0xab58d1cdu) << ((unsigned)(9u == (unsigned)((int)(unsigned)((int)u3 >= (int)((unsigned)h1 >> (1u & 31u))) >= (int)0xa357fce4u)) & 63u);
    f0 = f0 * 0.5f + (float)(((0xffffffffu & (unsigned)((int)(unsigned)c1 >= (int)*mp)) / ((0xe71e5b2bu / (fuel | 1u)) | 1u)) & 255u);
    if ((garr[u2 & 7u] >> ((u3 % ((unsigned)(w0 >> 29) | 1u)) & 31u))) goto L0;
    h1 = (unsigned short)(h1 + ((unsigned)(u1 && garr[u2 & 7u]) * ((unsigned)e0 >> ((4u >> (u3 & 31u)) & 31u))));
    *q0 += (unsigned)!(u1 >> (((unsigned)((short)0xce03564au > (signed char)0x7fffffffu) % ((unsigned)h1 | 1u)) & 31u));
    d0 = d0 * 0.5 + (double)((0x80000000u % ((garr[u2 & 7u] << (-((unsigned)f0 << (3u & 31u)) & 31u)) | 1u)) & 1023u);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)(unsigned)(5u || (unsigned)w0) > (signed char)u1)) {
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)h1 == 9u) & 255u);
            u0 = u0 * 0x9e3779b1u + (0x7fffffffu | (unsigned)f0);
            s0 = (int)((unsigned)((u1 / (p2 | 1u)) < i0) & (unsigned)((int)i1 < (int)(unsigned)l0));
            u1 += (unsigned)((short)i2 > (signed char)(unsigned)((short)((unsigned)e0 % (garr[u2 & 7u] | 1u)) > (signed char)(unsigned)w0));
        } else {
            x0 = x0 * 0x100000001b3ull + (unsigned)((short)u3 > (signed char)(~(garr[u2 & 7u] + 3u) >> ((unsigned)w0 & 31u)));
            u1 ^= (0x7fffffffu % ((unsigned)(x0 >> 70) | 1u));
            if ((*q0 << ((unsigned)s0 & 31u))) break;
            if (((unsigned)l0 + (unsigned)(signed char)(unsigned)(u2 || (unsigned)s0))) break;
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)((int)i0 >= (int)(r0.x & 0x10000u));
        if ((unsigned)s1) continue;
        i0 = ~(fuel / ((0xffffffffu * garr[u2 & 7u]) | 1u)) & 15u;
        u3 ^= -(unsigned)((int)(8u >> (i0 & 31u)) < (int)garr[i1 & 7u]);
        if ((((unsigned)c1 << ((unsigned)w0 & 31u)) | garr[u2 & 7u])) break;
    }
    d0 = d0 * 0.5 + (double)((unsigned)h0 & 1023u);
    d0 = d0 * 0.5 + (double)((0x643ff0eu - ((unsigned)w0 - ((unsigned)x0 * (unsigned)((int)garr[i1 & 7u] < (int)0x7fffffffu)))) & 1023u);
    { unsigned t6; double z6; if (((unsigned)h0) & 1u) { t6 = m0; z6 = (double)(((unsigned)(0xffffffffu && 0u)) & 255u); } if (((unsigned)h0) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
        goto L0;
    }
    l0 = (long)((unsigned long)l0 + ((unsigned)(w0 >> 29) % (i0 | 1u)));
    if (((unsigned)w0 * (unsigned)((short)9u > (signed char)p0))) goto L1;
    e0 = e0 * 0.5L + (long double)((unsigned)((int)p2 < (int)v0) & 1023u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch ((unsigned)((unsigned)b0 < 0x16625afbu) & 7u) {
        if (budget != 0u) { budget -= 1u; u1 = fn0((0x896aee22u / (v0 | 1u)), *mp, 0xdc393aeau); }
        h1 = (unsigned short)(h1 + (unsigned)s1);
        g0 = ((unsigned)(0x907ab493u < r0.y) / (~(unsigned)((u3 % (0xc2e2094bu | 1u)) && 0x10000u) | 1u));
    }
    goto L0;
    while (i0++ < 2u && (unsigned)c1) { if (--fuel == 0u) goto done;
        if ((unsigned)(0x343de438u == (0xbcb9bf68u % ((unsigned)l0 | 1u)))) break;
    }
    s1 = (int)((unsigned)s1 + (unsigned)((short)0x5f579f46u > (signed char)2u));
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0(u3, (unsigned)d0, ((m0 % ((unsigned)c1 | 1u)) / ((unsigned)x0 | 1u))); }
        L0: if (--fuel == 0u) goto done;
    } while (i0++ < 3u && (unsigned)(i0 || (unsigned)c1));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)(0x5b0f9151u == (unsigned)h1);
        garr[(unsigned)c0 & 7u] = (unsigned)s0;
    }
    u2 = ((unsigned)((int)(unsigned)c1 < (int)u2) - ((unsigned)(i1 < 0x61543c2du) >> ((unsigned)l0 & 31u)));
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(garr[u2 & 7u] < 0xf84c335bu), ((unsigned)e0 ^ *mp), (unsigned)e0); }
    u0 = u0 * 0x9e3779b1u + (unsigned)((short)(unsigned)c0 > (signed char)2u);
    e0 = e0 * 0.5L + (long double)((unsigned)((p2 + 1u) && (unsigned)(9u == *mp)) & 1023u);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + ((9u | *q0) >> (9u & 31u));
        L1: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0(p2, ((unsigned)((int)0x10000u < (int)5u) ^ (unsigned)b0), (unsigned)((int)(unsigned)(w0 >> 29) >= (int)garr[i1 & 7u])); }
        m0 ^= 0x80000000u;
    }
    if ((p1 >> ((unsigned)(4u < (unsigned)s0) & 31u))) goto L2;
    if (u3 == 7u) return ((i1 >> (p2 & 31u)) | 6u);
    goto done;
    g0 = (((unsigned)(p1 == 0x10000u) << (m0 & 31u)) * (u3 ^ 0xffffffffu));
    if ((unsigned)b0) goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn0((0x35c187ceu | u1), (unsigned)h1, -(0xffffffffu >> ((unsigned)(w0 >> 29) & 31u))); }
    if ((*q0 / (4u | 1u))) goto L0;
    if (budget != 0u) { budget -= 1u; u0 = fn0((m0 | (unsigned)(short)(unsigned)((int)p2 < (int)p1)), (((unsigned)w0 << (0x80000000u & 31u)) ^ a0[i0 & 3u]), 0x29580de7u); }
    if (0x9a76814cu) goto L1;
    w0 = w0 * 6364136223846793005ull + 0x9ea35bb0u;
    for (;;) { if (--fuel == 0u) goto done;
        m0 ^= ((unsigned)l0 >> ((unsigned)(m0 == (unsigned)b0) & 31u));
    }
    if ((0x68b0bef3u / ((unsigned)(x0 >> 70) | 1u))) {
        v0 = ((i2 * 0x10000u) >> ((unsigned)((int)0x7fffffffu >= (int)r0.y) & 31u));
        q0 = &garr[u3 & 7u];
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((short)g0 > (signed char)u0) / (7u | 1u)), (*q0 >> ((*mp + (unsigned)d0) & 31u)), -(unsigned)((short)(unsigned)c1 > (signed char)(3u * 0x4f58634du))); }
    }
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)!(0x7fffffffu % ((unsigned)(0x404b98d7u && (unsigned)c1) | 1u))) {
            if (((0x10000u * (unsigned)e0) | 0x64172e72u)) continue;
            i0 = (p2 * (fuel ^ (unsigned)((short)r0.y > (signed char)*q0))) & 15u;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((*mp >> (0x80000000u & 31u))) {
                    b0 = (0x7fffffffu & (unsigned)((0x10000u ? (unsigned)h1 : i2) < 0x1ecb4069u)) != 0u;
                    if ((unsigned)h0) {
                        if (3u) break;
                        do { if (--fuel == 0u) goto done;
                            r0.y ^= ((unsigned)l0 % (a0[u1 & 3u] | 1u));
                        } while (i2++ < 6u && 0x45d70f84u);
                        c1 = (signed char)((unsigned)!(7u & u1) << ((p2 % (i2 | 1u)) & 31u));
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(((unsigned)d0 + 7u) && 0x5dee2b70u), (unsigned)((int)2u < (int)0x79f1f9cu), ((unsigned)((unsigned)d0 && (unsigned)c0) >> (u0 & 31u))); }
                    }
                    b0 = (unsigned)(short)(unsigned)((int)(unsigned)l0 < (int)(unsigned)s1) != 0u;
                    for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        r0.x = (((unsigned)((int)garr[i1 & 7u] < (int)(unsigned)h0) | (a0[u1 & 3u] | (unsigned)h0)) * (unsigned)s0);
                    }
                    g0 = 0x80000000u;
                } else {
                    if (budget != 0u) { budget -= 1u; u3 = fn0(0x7dbfcc48u, (9u ^ a0[i0 & 3u]), ((unsigned)(signed char)(unsigned)((unsigned)w0 == i2) ^ (unsigned)w0)); }
                }
                h1 = (unsigned short)(h1 + (unsigned)((garr[i1 & 7u] ? (unsigned)h0 : (unsigned)f0) && -(unsigned)(u2 && r0.y)));
                u1 ^= p1;
                if ((unsigned)((unsigned)(w0 >> 29) || (unsigned)d0)) break;
            }
            d0 = d0 * 0.5 + (double)(r0.y & 1023u);
            q0 = &garr[((unsigned)c0 >> ((unsigned)(w0 >> 29) & 31u)) & 7u];
        } else {
            l0 = (long)((unsigned long)l0 + a0[i0 & 3u]);
            i0 = ((unsigned)(a0[u1 & 3u] || a0[u1 & 3u]) % ((*mp ^ g1) | 1u)) & 15u;
            x0 = x0 * 0x100000001b3ull + ((unsigned)((int)(0x226c8a94u - 0x7fffffffu) >= (int)7u) + 0x80000000u);
            g1 += (unsigned)(signed char)((unsigned)((short)fuel > (signed char)(unsigned)x0) ^ i2);
        }
        a0[(unsigned)e0 & 3u] = *q0;
        do { if (--fuel == 0u) goto done;
            if (1u) goto done;
            u0 ^= ((unsigned)(((u2 ^ 0x1c88048cu) / (garr[u2 & 7u] | 1u)) && (unsigned)s0) >> (a0[u1 & 3u] & 31u));
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s1 | (unsigned)c0), (unsigned)((short)(4u * fuel) > (signed char)(unsigned)(w0 >> 29)), ((unsigned)f0 / (0x7fffffffu | 1u))); }
            if ((unsigned)((unsigned)w0 == 0xb522e091u)) continue;
            if ((unsigned)c1) {
                v0 = u2;
                if (u3 == 7u) return ((unsigned)(signed char)((unsigned)(signed char)(g0 - (unsigned)b0) << (m0 & 31u)) % ((0xfdcc6a35u << (i2 & 31u)) | 1u));
                g1 += (unsigned)(p1 < (unsigned)s1);
            } else {
                L2: if (--fuel == 0u) goto done;
                if ((unsigned)(short)((unsigned)e0 * p0)) {
                    break; (void)((unsigned)(u0 < (unsigned)(0x7fffffffu || u1)));
                } else {
                    b0 = -(i0 + ((unsigned)((unsigned)c1 == (p1 ^ m0)) / (p1 | 1u))) != 0u;
                    g0 = u0;
                    l0 = (long)((unsigned long)l0 + ((unsigned)(0xffffffffu < 0x78e1aac3u) ? (0xc6ca6e3fu * 0x27196d79u) : *mp));
                }
                { unsigned t0; double z0; if ((u2) & 1u) { t0 = (unsigned)w0; z0 = (double)((~((unsigned)e0 % (a0[i0 & 3u] | 1u))) & 255u); } if ((u2) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    h0 = (short)(u0 ^ (unsigned)(x0 >> 70));
                    if (((unsigned)s1 - i1)) break;
                    u2 = u2 * 0x9e3779b1u + (unsigned)(i2 && r0.y);
                    *q0 = g0;
                    if ((unsigned)d0) {
                        e0 = e0 * 0.5L + (long double)((fuel * (p2 << (*q0 & 31u))) & 1023u);
                        h0 = (short)(1u ? 0xfdbc8f37u : (unsigned)c1);
                    }
                }
            }
        } while (i1++ < 3u && ~(unsigned)(u2 && a0[u1 & 3u]));
    }
    if (((unsigned)e0 ^ 0xffffffffu)) goto L0;
    c1 = (signed char)(u2 % ((unsigned)(a0[i0 & 3u] && (0xea49a476u | (unsigned)c0)) | 1u));
    e0 = e0 * 0.5L + (long double)(0x10000u & 1023u);
    b0 = ((u0 ? u0 : 0u) << (i0 & 31u)) != 0u;
    goto done;
    e0 = e0 * 0.5L + (long double)(((unsigned)e0 % (p2 | 1u)) & 1023u);
    L3: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(short)(unsigned)((short)5u > (signed char)(i2 ^ garr[i1 & 7u])), -(unsigned)(~(unsigned)((int)v0 < (int)p1) < 0xbcb6eabau), (unsigned)w0); }
    *q0 += ((*q0 + (unsigned)x0) / (u2 | 1u));
    s0 = (int)((unsigned)w0 >> ((0x10000u + 0x10000u) & 31u));
    if (budget != 0u) { budget -= 1u; u0 = fn0(~(unsigned)((int)(unsigned)(p0 < m0) < (int)fuel), (unsigned)((unsigned)c1 && (unsigned)d0), (unsigned)f0); }
    while (i0++ < 6u && ~((unsigned)(w0 >> 29) / ((unsigned)c0 | 1u))) { if (--fuel == 0u) goto done;
        u3 = ((unsigned)b0 & 6u);
    }
    m0 ^= g1;
    if (budget != 0u) { budget -= 1u; u1 = fn0((1u & i1), (unsigned)((unsigned)f0 < (unsigned)(x0 >> 70)), u2); }
    x0 = x0 * 0x100000001b3ull + 8u;
    s1 = (int)((unsigned)s1 + ((unsigned)((short)(unsigned)s1 > (signed char)7u) * 0x7fffffffu));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)garr[u2 & 7u] > (signed char)u1), 0x7fffffffu, (unsigned)(0xe2d10d24u && (1u | 0xffffffffu))); }
    }
    v0 = (~(3u ? i2 : u2) + 0xf51e1d99u);
    x0 = x0 * 0x100000001b3ull + (unsigned)(u1 || ((unsigned)((unsigned)c0 || (unsigned)(unsigned char)((unsigned)h0 | a0[i0 & 3u])) << (0x10000u & 31u)));
    L4: if (--fuel == 0u) goto done;
    if ((unsigned)((short)p1 > (signed char)0x7fffffffu)) goto L0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while (i0++ < 2u && *q0) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((u2 % (*q0 | 1u)), 2u, (i0 << ((unsigned)(short)(unsigned)(9u || 0xffffffffu) & 31u))); }
            break; (void)((i0 + (0x10000u ^ (unsigned)l0)));
            if ((unsigned)(w0 >> 29)) break;
            garr[(unsigned)h1 & 7u] = (unsigned)(r0.y == (unsigned)(0x6d49f532u || 0xffffffffu));
        }
        l0 = (long)((unsigned long)l0 + (unsigned)c0);
        L0: if (--fuel == 0u) goto done;
        if (0x219f3bbau) continue;
    }
    if (0xa8872fc7u) {
        if (0x61786950u) goto L3;
        if (((unsigned)(short)(unsigned)(0x95be91deu < p2) | (unsigned)w0)) goto L2;
        if (*q0) goto L0;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)e0 && 9u), (5u + 0xcdf3bfe9u), (unsigned)((a0[u1 & 3u] % (0x7fffffffu | 1u)) < (unsigned)c1)); }
    if ((unsigned)((int)(unsigned)(u2 == u1) >= (int)(unsigned)d0)) {
        do { if (--fuel == 0u) goto done;
            r0.y ^= (((unsigned)(w0 >> 29) & 0xd87459b6u) | (unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)s0 && 0xffffffffu) == v0));
            { unsigned t0; double z0; if (((unsigned)(signed char)(-(8u + (unsigned)h1) ^ i1)) & 1u) { t0 = ~(unsigned)(p1 < *mp); z0 = (double)((((m0 >> (v0 & 31u)) >> (2u & 31u))) & 255u); } if (((unsigned)(signed char)(-(8u + (unsigned)h1) ^ i1)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                c1 = (signed char)(unsigned)((int)(unsigned)(7u && (unsigned)(x0 >> 70)) >= (int)(unsigned)d0);
                if ((unsigned)(0xffffffffu < 0x10000u)) break;
                { unsigned t1; double z1; if ((*mp) & 1u) { t1 = m0; z1 = (double)((u3) & 255u); } if ((*mp) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    s0 = (int)(r0.y % (m0 | 1u));
                    garr[(unsigned)((int)(unsigned)d0 >= (int)*mp) & 7u] = (*q0 << (0x13317b5eu & 31u));
                    if (2u) {
                        l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(fuel >> (m0 & 31u)));
                        *q0 += (unsigned)h0;
                        r0.x = (unsigned)(p2 || (unsigned)!(g1 % (r0.x | 1u)));
                        { unsigned t2; double z2; if (((r0.x - 0u)) & 1u) { t2 = (0xd850c7f0u ? (unsigned)s1 : 0x84299c14u); z2 = (double)((0x80000000u) & 255u); } if (((r0.x - 0u)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                            L1: if (--fuel == 0u) goto done;
                            if ((unsigned)(0x7fffffffu && (u1 << (a0[i0 & 3u] & 31u)))) break;
                            *mp = (unsigned)e0;
                            u0 += (unsigned)((short)u2 > (signed char)3u);
                            if (fuel < 8u) return (unsigned)(i1 < 0x6861e4bcu);
                            if ((unsigned)!(v0 + (g0 + 0x80000000u))) continue;
                        }
                        break; (void)(((unsigned)c0 | ((unsigned)h0 << (m0 & 31u))));
                        if (u2) break;
                    }
                    break; (void)(((unsigned)h1 >> (((unsigned)s1 % (p0 | 1u)) & 31u)));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((7u % ((unsigned)((int)garr[i1 & 7u] < (int)(unsigned)c1) | 1u)), (unsigned)(*q0 < (unsigned)w0), (*q0 * 0x10000u)); }
                    h0 = (short)9u;
                }
                c1 = (signed char)(-(0x11e0600fu << (0x66ee3fe5u & 31u)) | (unsigned)(signed char)((unsigned)((int)(unsigned)f0 >= (int)u0) >> (0x10000u & 31u)));
                *q0 += (unsigned)((int)(unsigned)e0 >= (int)u2);
            }
        } while (i0++ < 4u && (unsigned)(unsigned char)(unsigned)((unsigned)h1 && m0));
    }
    goto L2;
    if ((unsigned)h1) goto L0;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = (((unsigned)h0 << ((unsigned)(x0 >> 70) & 31u)) & 0xd8556f57u);
        L2: if (--fuel == 0u) goto done;
        if (u2) {
            c1 = (signed char)((r0.x ? (unsigned)h0 : (u0 + 0x5b1c6e00u)) & p0);
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)(x0 >> 70) / ((unsigned)(0x10000u == (unsigned)(x0 >> 70)) | 1u)), (unsigned)((int)(unsigned)h1 < (int)(v0 >> ((unsigned)d0 & 31u))), u3); }
            if ((0x632a8d16u % (garr[u2 & 7u] | 1u))) break;
            u3 += (unsigned)((int)fuel >= (int)(unsigned)(i2 == (p0 ? 0x8bac9417u : u2)));
        } else {
            while (i1++ < 4u && (unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
                g1 += -(((unsigned)(*q0 < u2) / (g1 | 1u)) ^ 0x844e676au);
                l0 = (long)((unsigned long)l0 + (6u >> ((unsigned)(unsigned char)((unsigned)w0 & (unsigned)(w0 >> 29)) & 31u)));
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (unsigned)((int)(a0[i0 & 3u] & a0[u1 & 3u]) >= (int)*q0) != 0u;
                    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        L3: if (--fuel == 0u) goto done;
                        if (fuel < 8u) return ((unsigned)(garr[i1 & 7u] == u1) ? p1 : (*mp << (p0 & 31u)));
                        u1 = u1 * 0x9e3779b1u + (5u & u3);
                    }
                    break; (void)((*mp & m0));
                    if (a0[u1 & 3u]) break;
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)x0 < a0[i0 & 3u]));
                    if ((((unsigned)s0 - i2) + 0x10000u)) continue;
                }
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((((unsigned)((int)(unsigned)c0 < (int)1u) % (garr[i1 & 7u] | 1u)) - -(fuel | 0x10000u)) & 1023u);
                    g0 = (unsigned)!(unsigned)((unsigned)(w0 >> 29) || ((unsigned)e0 * (unsigned)!(unsigned)((int)3u >= (int)g0)));
                    if (budget != 0u) { budget -= 1u; u0 = fn0(r0.y, (fuel ^ p0), ((0x7fffffffu | (unsigned)x0) - 0xb2bd686bu)); }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((v0 << (r0.x & 31u)), (0x10000u * garr[u2 & 7u]), (unsigned)(x0 >> 70)); }
                    g0 = ~((unsigned)e0 + ((unsigned)h0 + ~(0xb8640833u + 5u)));
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)(0x8e91230bu || *q0)) {
                            c1 = (signed char)(unsigned)(signed char)(unsigned)(i0 || (unsigned)s0);
                            if (((garr[i1 & 7u] >> (*mp & 31u)) % (r0.x | 1u))) break;
                        } else {
                            *q0 = (unsigned)((int)(unsigned)(*mp == 0x22f42c09u) >= (int)(unsigned)((unsigned)h0 < garr[i1 & 7u]));
                            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(a0[u1 & 3u] == 0u), (unsigned)((int)u0 < (int)(unsigned)c1), ((unsigned)((unsigned)l0 && r0.x) >> (p1 & 31u))); }
                            if ((unsigned)(w0 >> 29)) break;
                        }
                        s1 = (int)((unsigned)s1 + (p2 / (((unsigned)((unsigned)c1 && (unsigned)f0) ^ m0) | 1u)));
                    } while (i0++ < 7u && (unsigned)(short)(unsigned)(6u && (3u & 8u)));
                }
                if ((unsigned)!((unsigned)x0 & (unsigned)((int)p0 >= (int)8u))) break;
            }
            u3 = (unsigned)(p2 < (unsigned)(((unsigned)(signed char)((unsigned)h0 + fuel) << ((unsigned)w0 & 31u)) == 0x10000u));
            if (budget != 0u) { budget -= 1u; u1 = fn1((0x7fffffffu / ((unsigned)(w0 >> 29) | 1u)), (2u % (p0 | 1u)), ~(garr[u2 & 7u] * 0x7fffffffu)); }
            if ((unsigned)((short)(fuel ^ g0) > (signed char)(unsigned)c0)) {
                if (budget != 0u) { budget -= 1u; u3 = fn1(0x4f4b061bu, g0, 0u); }
                if ((u3 % (0u | 1u))) continue;
                s1 = (int)((unsigned)s1 + (a0[i0 & 3u] * (unsigned)(unsigned char)(unsigned)((short)(unsigned)c0 > (signed char)0x5fd0265bu)));
                h0 = (short)(unsigned)((int)-(unsigned)((int)(unsigned)s0 >= (int)p1) < (int)3u);
            } else {
                q0 = &garr[(((r0.x + i2) + r0.y) << ((unsigned)(u0 < 0u) & 31u)) & 7u];
            }
        }
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 = (unsigned)!(unsigned)(((unsigned)(w0 >> 29) ^ 9u) < (unsigned)x0);
        { unsigned t3; double z3; if (((0x7fffffffu ^ 7u)) & 1u) { t3 = (unsigned)c1; z3 = (double)(((unsigned)((int)(0x80000000u ^ p0) >= (int)(unsigned)f0)) & 255u); } if (((0x7fffffffu ^ 7u)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            { unsigned t4; double z4; if ((-(unsigned)((int)(unsigned)w0 >= (int)(unsigned)l0)) & 1u) { t4 = (unsigned)(0x7fffffffu && *q0); z4 = (double)((g1) & 255u); } if ((-(unsigned)((int)(unsigned)w0 >= (int)(unsigned)l0)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                c1 = (signed char)(unsigned)(unsigned char)((unsigned)c1 | (u2 + (unsigned)c0));
                *q0 += (unsigned)(fuel || (unsigned)((int)r0.x < (int)(unsigned)f0));
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(((unsigned)x0 | (unsigned)h0) || 0x10000u), -(0x5cdeb151u % (2u | 1u)), p2); }
                if (3u) break;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        u2 = (p0 - (unsigned)((int)5u >= (int)(unsigned)(w0 >> 29)));
                    }
                    for (;;) { if (--fuel == 0u) goto done;
                        u0 = u0 * 0x9e3779b1u + (unsigned)(0x3d0886deu < (unsigned)w0);
                        u1 = u1 * 0x9e3779b1u + g1;
                        if ((i0 * (0x783ae11eu / ((unsigned)s0 | 1u)))) goto L1;
                        do { if (--fuel == 0u) goto done;
                            b0 = (unsigned)((int)3u >= (int)(unsigned)b0) != 0u;
                            u2 += ((unsigned)((garr[u2 & 7u] >> (0xe77fb38bu & 31u)) < (unsigned)b0) | (unsigned)((unsigned)(x0 >> 70) < u1));
                            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)b0 || (unsigned)s0) && 0xffffffffu), (unsigned)(u2 || 0x241729e9u), (unsigned)d0); }
                            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(0x7fffffffu < (unsigned)s1) && 5u), a0[u1 & 3u], fuel); }
                            L4: if (--fuel == 0u) goto done;
                        } while (i0++ < 5u && (p2 >> (r0.x & 31u)));
                        u3 ^= ((unsigned)s0 % (0x80000000u | 1u));
                        l0 = (long)((unsigned long)l0 + ((unsigned)c1 + g1));
                    }
                    c0 = (unsigned char)0xb51f17bbu;
                    u1 ^= (((i2 / (0x3478279au | 1u)) - (unsigned)h0) + p0);
                }
            }
            while (i1++ < 2u && r0.y) { if (--fuel == 0u) goto done;
                if ((unsigned)(a0[u1 & 3u] < ((unsigned)h0 - 0x2048fef6u))) {
                    break; (void)((unsigned)((unsigned)c1 || u1));
                    if (g1) goto done;
                    if ((unsigned)((short)(0x7fffffffu & p0) > (signed char)0xcb37de6au)) goto L0;
                } else {
                    break; (void)((unsigned)((short)(p2 << (0xffffffffu & 31u)) > (signed char)(unsigned)s1));
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)f0 | (unsigned)x0), (unsigned)((0xbe89778cu * (unsigned)h1) < 9u), (unsigned)(a0[i0 & 3u] < 0xffffffffu)); }
                garr[(u0 - (unsigned)(x0 >> 70)) & 7u] = (unsigned)((unsigned)d0 < i2);
                if (0xe75a2f61u) break;
                b0 = (((unsigned)((int)(unsigned)b0 < (int)u0) % (7u | 1u)) | (unsigned)((unsigned)b0 < garr[u2 & 7u])) != 0u;
            }
            if ((0x7dbdad18u + *mp)) goto L1;
            switch (((unsigned)(x0 >> 70) ^ (i1 ^ garr[u2 & 7u])) & 7u) {
                goto L4;
                if ((unsigned)((unsigned)((unsigned)e0 == u3) && 0x65ba26b5u)) {
                    case 3u: ;
                }
                if ((unsigned)(short)(((unsigned)(x0 >> 70) - i0) ^ fuel)) {
                    case 2u: ;
                    c1 = (signed char)(u1 - i0);
                    m0 ^= (0x10000u / (0x10000u | 1u));
                    w0 ^= (unsigned long long)(unsigned)((unsigned)(w0 >> 29) == g1) << ((unsigned)((5u - 0xcdb2df1fu) < (unsigned)!(r0.y | 0xbbdc3d10u)) & 63u);
                }
                default: ;
            }
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            u3 = ((unsigned)x0 ? (unsigned)((int)1u < (int)0x80000000u) : u1);
            if (budget != 0u) { budget -= 1u; u1 = fn1(fuel, (5u >> (v0 & 31u)), (unsigned)((unsigned)x0 == 3u)); }
            *q0 += (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)((short)0xa3c2f30cu > (signed char)u2));
            if ((unsigned)((short)m0 > (signed char)(unsigned)c1)) goto L3;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)x0, (unsigned)((unsigned)s1 == (unsigned)((unsigned)s0 && g1)), ((unsigned)(unsigned char)(unsigned)((unsigned)c0 || a0[i0 & 3u]) + 0u)); }
        if (p0) break;
        q0 = &garr[(unsigned)((int)(-(unsigned)((short)(unsigned)h0 > (signed char)u2) * ((unsigned)h1 ^ r0.y)) >= (int)0x80000000u) & 7u];
    }
    e0 = e0 * 0.5L + (long double)(0x5515094fu & 1023u);
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(unsigned char)((unsigned)h1 & 5u), (unsigned)(signed char)(unsigned)((int)(0x7fffffffu | 0x7fffffffu) < (int)0x80000000u), (unsigned)s0); }
    r0.y ^= (unsigned)(unsigned char)(unsigned)(0x938a84a0u && (unsigned)l0);
    *mp = 0x10000u;
    i0 = (unsigned)((garr[u2 & 7u] << (8u & 31u)) && a0[i0 & 3u]) & 15u;
    if (budget != 0u) { budget -= 1u; u3 = fn1((garr[i1 & 7u] % (9u | 1u)), (unsigned)((unsigned)s1 && g1), i2); }
    i0 = 0x7fffffffu & 15u;
    while (i0++ < 7u && u3) { if (--fuel == 0u) goto done;
        if (fuel) break;
        break; (void)(0x80000000u);
        *q0 = 0x5259ec26u;
        do { if (--fuel == 0u) goto done;
            if (((unsigned)(x0 >> 70) + ((unsigned)w0 | r0.y))) break;
        } while (i1++ < 6u && ((unsigned)h1 * (unsigned)s1));
        if ((unsigned)f0) {
            u3 ^= 0x2d6d5cbbu;
        }
    }
    if ((unsigned)s1) goto L4;
    goto L0;
    c0 = (unsigned char)((unsigned)l0 * (unsigned)x0);
    do { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)(p2 || p2) > (signed char)(garr[u2 & 7u] ? i0 : a0[i0 & 3u]));
    } while (i0++ < 2u && 0x10000u);
    if ((9u % ((unsigned)((int)0x8c0fde67u < (int)(unsigned)s1) | 1u))) {
        switch ((unsigned)s1 & 7u) {
            { unsigned t5; double z5; if ((0x10000u) & 1u) { t5 = 0x80000000u; z5 = (double)(((unsigned)((int)0xb5c1bd7cu >= (int)a0[i0 & 3u])) & 255u); } if ((0x10000u) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                if (-(((unsigned)e0 / (2u | 1u)) / (0x218ec6f0u | 1u))) break;
                if (((unsigned)(0x7fffffffu || (unsigned)s1) + 5u)) {
                    case 0u: ;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((-(unsigned)(8u == 0xc0209dafu) ^ 0x80000000u), (0x80000000u - (unsigned)c0), u2); }
                    { unsigned t6; double z6; if ((((unsigned)(garr[i1 & 7u] && g0) * 3u)) & 1u) { t6 = ((unsigned)(7u && 0xef60ae02u) % ((unsigned)c0 | 1u)); z6 = (double)(((unsigned)(signed char)(r0.y - (unsigned)h1)) & 255u); } if ((((unsigned)(garr[i1 & 7u] && g0) * 3u)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                        case 3u: ;
                        r0.y ^= 0xffffffffu;
                        case 6u: ;
                        w0 = w0 * 6364136223846793005ull + (unsigned)c1;
                    }
                    if (0xa238f15cu) {
                        r0.y ^= ((unsigned)((unsigned)h1 && 0x5cf1a3ddu) ? (unsigned)c1 : u3);
                    } else {
                        l0 = (long)((unsigned long)l0 + (unsigned)c1);
                        if ((0x4002f794u | garr[u2 & 7u])) goto L4;
                    }
                } else {
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)c0, (unsigned)(i0 < g1), u2); }
                    if (p1) {
                        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)c1 || ((unsigned)(0x7fffffffu && garr[i1 & 7u]) / ((unsigned)s0 | 1u))) & 1023u);
                        if ((unsigned)s1) break;
                        case 5u: ;
                        f0 = f0 * 0.5f + (float)((((unsigned)((unsigned)e0 && (unsigned)c1) | (unsigned)l0) - (a0[i0 & 3u] / ((unsigned)h0 | 1u))) & 255u);
                        f0 = f0 * 0.5f + (float)(((unsigned)(0xd05f43b7u == (unsigned)f0) % ((unsigned)(u1 == r0.x) | 1u)) & 255u);
                        v0 = (unsigned)((short)(unsigned)(short)(0xa7475cbbu ? 0xffffffffu : 0x448e9c60u) > (signed char)(unsigned)x0);
                    } else {
                        if (fuel < 8u) return (6u * (g1 & g0));
                        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u3 = fn1((0x6aaa3fc6u << (r0.y & 31u)), (unsigned)(0x7fffffffu < 0x7fffffffu), ((unsigned)h1 | fuel)); }
                            *q0 += (0xffffffffu & ((fuel - (unsigned)e0) * 3u));
                            g0 = (unsigned)((short)0x5e77c5dfu > (signed char)(unsigned)(x0 >> 70));
                            u1 = u1 * 0x9e3779b1u + (8u & (a0[i0 & 3u] | garr[i1 & 7u]));
                            case 4u: ;
                            garr[((unsigned)s0 & a0[i0 & 3u]) & 7u] = (unsigned)(*mp || *mp);
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(w0 >> 29), (unsigned)(garr[i1 & 7u] || r0.x), (unsigned)(v0 || (i2 * (unsigned)e0))); }
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn0(garr[u2 & 7u], 7u, (((unsigned)f0 * r0.y) - u3)); }
                    if (budget != 0u) { budget -= 1u; u2 = fn1(5u, 0x80000000u, (unsigned)((int)(unsigned)s0 < (int)*mp)); }
                }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn1((0x46f71283u / ((unsigned)b0 | 1u)), g0, ~(unsigned)((unsigned)d0 < 0xa340e760u)); }
            if ((unsigned)(0x7fffffffu == (*q0 + 2u))) {
                { unsigned t7; double z7; if (((unsigned)!(u3 >> ((unsigned)((int)a0[u1 & 3u] >= (int)g1) & 31u))) & 1u) { t7 = (r0.y - *mp); z7 = (double)((i0) & 255u); } if (((unsigned)!(u3 >> ((unsigned)((int)a0[u1 & 3u] >= (int)g1) & 31u))) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                    if (((unsigned)(unsigned char)(unsigned)((unsigned)b0 && i1) + (unsigned)d0)) {
                        b0 = ((unsigned)(0xe51fb055u < (unsigned)s0) | (unsigned)d0) != 0u;
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)w0 >= (int)(unsigned)((int)p1 < (int)(3u + ((unsigned)s0 & 0xffffffffu)))));
                        garr[(unsigned)(short)(unsigned)((short)(unsigned)e0 > (signed char)p1) & 7u] = (unsigned)s1;
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn1((3u % (((unsigned)h1 >> (p1 & 31u)) | 1u)), (unsigned)((int)1u >= (int)(unsigned)h0), (0x10000u % (4u | 1u))); }
                    e0 = e0 * 0.5L + (long double)((unsigned)(u2 < (u2 | 0x4bc33562u)) & 1023u);
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((g1 & 0x7fffffffu), (unsigned)((int)-(p0 / ((unsigned)h1 | 1u)) >= (int)garr[i1 & 7u]), (unsigned)c0); }
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = (unsigned)((short)((unsigned)(a0[i0 & 3u] && 0x60a8dc63u) << ((unsigned)d0 & 31u)) > (signed char)(unsigned)((unsigned)h0 || i2));
                    q0 = &garr[0xcc148229u & 7u];
                }
                u0 ^= ((unsigned)(w0 >> 29) % ((unsigned)(unsigned char)(unsigned)((short)3u > (signed char)(unsigned)((int)i0 < (int)((unsigned)(x0 >> 70) << (u3 & 31u)))) | 1u));
                u0 = (unsigned)((short)(((unsigned)(x0 >> 70) / ((unsigned)((unsigned)(x0 >> 70) < (unsigned)h0) | 1u)) & 0x7fffffffu) > (signed char)(unsigned)l0);
                u0 += u1;
            } else {
                u1 = 3u;
                if (budget != 0u) { budget -= 1u; u0 = fn0(v0, ((unsigned)x0 - (unsigned)s1), ((unsigned)h0 ? a0[i0 & 3u] : i0)); }
                f0 = f0 * 0.5f + (float)(-(0x10000u & a0[u1 & 3u]) & 255u);
                case 7u: ;
            }
            while (i0++ < 7u && (0x86f0abadu ? a0[i0 & 3u] : (unsigned)e0)) { if (--fuel == 0u) goto done;
                r0.y ^= (p0 / ((unsigned)c1 | 1u));
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    a0[0xd5a34b80u & 3u] = (a0[i0 & 3u] ? 0x7fffffffu : i0);
                    switch (u2 & 7u) {
                        do { if (--fuel == 0u) goto done;
                            s1 = (int)((unsigned)s1 + (unsigned)((int)((i2 << ((unsigned)h0 & 31u)) & *mp) < (int)(unsigned)(w0 >> 29)));
                            case 4u: ;
                            v0 = ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)(unsigned char)(3u ^ fuel)) - (unsigned)(0x1eb8d73cu < 0x80000000u));
                            u3 = u3 * 0x9e3779b1u + (unsigned)((unsigned)((unsigned)(r0.y == (unsigned)e0) == a0[i0 & 3u]) && *mp);
                            if (budget != 0u) { budget -= 1u; u1 = fn0(a0[u1 & 3u], (unsigned)((unsigned)c0 == v0), ((unsigned)d0 % (i1 | 1u))); }
                            u2 ^= (((unsigned)s1 / ((unsigned)(x0 >> 70) | 1u)) - (0xbaf872a1u ? (unsigned)h1 : a0[i0 & 3u]));
                        } while (i2++ < 4u && (u0 >> ((unsigned)w0 & 31u)));
                        g0 = (unsigned)c0;
                        h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)((unsigned)s1 == (u1 / ((unsigned)e0 | 1u))) > (signed char)(0x10000u ^ (unsigned)x0)));
                        r0.x = ((0xa6f0bab2u / (a0[i0 & 3u] | 1u)) % (5u | 1u));
                        continue; (void)(g0);
                        *mp = (unsigned)d0;
                    }
                    if ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)((int)u1 < (int)m0))) goto done;
                    { unsigned t8; double z8; if ((((unsigned)e0 >> (~(v0 & i1) & 31u))) & 1u) { t8 = ((m0 >> (0x10000u & 31u)) ^ 9u); z8 = (double)(((unsigned)((short)(unsigned)w0 > (signed char)0x1e89897du)) & 255u); } if ((((unsigned)e0 >> (~(v0 & i1) & 31u))) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                        case 1u: ;
                        u1 ^= 0xffffffffu;
                        for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                            q0 = &garr[(p1 ^ 0x92acb061u) & 7u];
                            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(p1 < (unsigned)((unsigned)s0 == p1)), (unsigned)((int)(unsigned)s1 < (int)u3), ~(unsigned)((short)m0 > (signed char)u0)); }
                            default: ;
                            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)((int)(unsigned)c1 >= (int)u2)), r0.y, r0.x); }
                            e0 = e0 * 0.5L + (long double)((((*mp | u0) / ((unsigned)(w0 >> 29) | 1u)) + p1) & 1023u);
                        }
                    }
                }
            }
        }
        h0 = (short)(unsigned)(signed char)(unsigned)(((unsigned)s0 & (r0.y ? i1 : 4u)) == (unsigned)l0);
        *q0 = (unsigned)(a0[i0 & 3u] == 0u);
        if ((unsigned)(short)(unsigned)(u2 && -(0x2a3d9c44u + u3))) {
            g0 = (unsigned)((int)(unsigned)c1 < (int)7u);
            w0 ^= (unsigned long long)(unsigned)f0 << (((unsigned)(x0 >> 70) ? 0xc07a7f13u : 0u) & 63u);
            if (u0) goto L0;
            do { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(((unsigned)e0 * (unsigned)(x0 >> 70)) % (((unsigned)(w0 >> 29) & (m0 >> ((unsigned)(w0 >> 29) & 31u))) | 1u));
                    i1 = (unsigned)((unsigned)w0 == p1) & 15u;
                    x0 = x0 * 0x100000001b3ull + -(garr[i1 & 7u] ^ (unsigned)s1);
                    do { if (--fuel == 0u) goto done;
                        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                            s0 = (int)(~(v0 & 4u) / ((unsigned)d0 | 1u));
                            w0 = w0 * 6364136223846793005ull + (unsigned)((int)0xc03928f2u >= (int)(unsigned)(garr[u2 & 7u] || -(unsigned)((int)garr[i1 & 7u] < (int)(u0 - p2))));
                            break; (void)((unsigned)w0);
                            if ((unsigned)e0) break;
                        }
                        c0 = (unsigned char)((unsigned)e0 >> ((unsigned)((int)*q0 >= (int)p2) & 31u));
                        if ((unsigned)(0x83670b47u < (unsigned)(short)(0xffffffffu * (unsigned)s1))) goto done;
                        break; (void)(5u);
                    } while (i2++ < 4u && (garr[u2 & 7u] | (i1 / ((unsigned)f0 | 1u))));
                    u1 = (unsigned)w0;
                }
            } while (i0++ < 7u && ((p2 - i0) ^ garr[i1 & 7u]));
        } else {
            if ((0x10000u >> (p0 & 31u))) goto L0;
        }
    } else {
        e0 = e0 * 0.5L + (long double)((unsigned)((int)(~(0x60275dbfu | (unsigned)b0) & (unsigned)w0) < (int)(unsigned)h0) & 1023u);
        if (budget != 0u) { budget -= 1u; u2 = fn1(*mp, (*mp + p2), (unsigned)((garr[u2 & 7u] ^ m0) || 9u)); }
        *q0 += (unsigned)!((unsigned)((unsigned)((unsigned)((short)*mp > (signed char)u3) && 0x69480be1u) < u3) / (0x4057f520u | 1u));
    }
    if (4u) {
        if ((unsigned)f0) {
            if ((unsigned)e0) goto L0;
            if ((unsigned)((int)(unsigned)(5u == r0.x) < (int)r0.y)) goto done;
            if (fuel < 8u) return (-(p2 - u1) % ((unsigned)((short)garr[u2 & 7u] > (signed char)*mp) | 1u));
            if ((unsigned)c0) {
                if (*mp) goto L1;
                { unsigned t9; double z9; if ((*mp) & 1u) { t9 = (((unsigned)h0 * p0) - (unsigned)x0); z9 = (double)((((unsigned)(u3 < 8u) | *q0)) & 255u); } if ((*mp) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
                    s0 = (int)(unsigned)(0x80000000u && (unsigned)s0);
                }
                if ((unsigned)((int)(unsigned)c0 >= (int)(unsigned)b0)) {
                    if ((unsigned)s1) goto L1;
                    r0.y ^= (unsigned)(a0[i0 & 3u] == p0);
                    g1 += ((unsigned)e0 >> ((((unsigned)((int)p1 < (int)1u) << ((unsigned)c0 & 31u)) / (9u | 1u)) & 31u));
                    { unsigned t10; double z10; if ((((unsigned)b0 ? *mp : 4u)) & 1u) { t10 = (unsigned)e0; z10 = (double)((0x80000000u) & 255u); } if ((((unsigned)b0 ? *mp : 4u)) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
                        a0[(p2 / (a0[i0 & 3u] | 1u)) & 3u] = (u0 * 0x10000u);
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(8u < (unsigned)((short)(unsigned)d0 > (signed char)p1)), (unsigned)((short)v0 > (signed char)(8u % (u2 | 1u))), i2); }
                        h0 = (short)((unsigned)((unsigned)s0 || -((unsigned)((int)(unsigned)w0 >= (int)i1) >> (g0 & 31u))) / (*mp | 1u));
                    }
                    if ((8u / ((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)e0) | 1u))) {
                        if (5u) goto L2;
                        q0 = &garr[(~((unsigned)(x0 >> 70) + a0[i0 & 3u]) % ((unsigned)l0 | 1u)) & 7u];
                        while (i0++ < 2u && *q0) { if (--fuel == 0u) goto done;
                            if (-(a0[u1 & 3u] & ~(i0 << ((unsigned)f0 & 31u)))) goto done;
                        }
                    } else {
                        v0 = 5u;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((0xe1e29450u ^ (unsigned)(u2 || *mp)), (g1 | 0xabd20e99u), (4u % (v0 | 1u))); }
                        if ((unsigned)((unsigned)(signed char)(0u & (unsigned)c0) && 8u)) {
                            w0 ^= (unsigned long long)(unsigned)(v0 && (unsigned)s1) << ((unsigned)d0 & 63u);
                            b0 = (unsigned)b0 != 0u;
                            if ((unsigned)((int)(unsigned)!(unsigned)((short)0x1657ee33u > (signed char)r0.x) < (int)6u)) goto done;
                            u1 ^= ~((unsigned)((int)*mp >= (int)u1) ^ (unsigned)((int)m0 < (int)(0x10000u ^ 0x10000u)));
                        }
                        switch ((unsigned)c1 & 7u) {
                            g1 += 5u;
                            case 2u: ;
                            r0.x = (u2 | 0x10000u);
                            garr[((unsigned)c0 & p2) & 7u] = ((unsigned)w0 ? (unsigned)s0 : ((unsigned)s1 ^ (g0 - (unsigned)d0)));
                        }
                    }
                    d0 = d0 * 0.5 + (double)((unsigned)((((unsigned)f0 ^ (unsigned)h0) + p1) == p1) & 1023u);
                }
                r0.y ^= (unsigned)h0;
                q0 = &garr[0xf8e5e34bu & 7u];
            }
            goto L3;
        }
    }
    if ((unsigned)((int)i0 < (int)(unsigned)(i1 == (unsigned)s1))) {
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)(unsigned char)(unsigned)((int)0x80000000u >= (int)0xffffffffu) > (signed char)6u), (0x7fffffffu - (unsigned)h0), (unsigned)((a0[i0 & 3u] + (unsigned)c1) < 0xb6abdecu)); }
        q0 = &garr[(unsigned)(((unsigned)e0 - fuel) == (*q0 & (unsigned)c1)) & 7u];
        { unsigned t11; double z11; if (((unsigned)(i0 < (unsigned)(w0 >> 29))) & 1u) { t11 = ((u3 ^ r0.y) ^ m0); z11 = (double)(((unsigned)((unsigned)w0 < (i1 << (a0[u1 & 3u] & 31u)))) & 255u); } if (((unsigned)(i0 < (unsigned)(w0 >> 29))) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
            { unsigned t12; double z12; if (((unsigned)((unsigned)e0 && (unsigned)b0)) & 1u) { t12 = (i2 ^ garr[u2 & 7u]); z12 = (double)((6u) & 255u); } if (((unsigned)((unsigned)e0 && (unsigned)b0)) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
                if ((unsigned)((int)r0.y >= (int)(unsigned)f0)) goto L1;
                if ((((unsigned)f0 & (unsigned)s1) - 0xe415f515u)) goto L3;
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)(signed char)(unsigned)((int)u0 < (int)*mp));
                if ((unsigned)(0x75482225u == ~(i0 / (i2 | 1u)))) goto L2;
                if (7u) goto L3;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)8u < (int)(unsigned)x0), (unsigned)((unsigned)c1 < (unsigned)e0), (2u * u0)); }
            *mp = (0xffffffffu % ((unsigned)((int)0x77d9bb86u < (int)(unsigned)(0x80000000u == (unsigned)b0)) | 1u));
            r0.x = (i0 ? (0x80000000u + m0) : *q0);
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)h1) {
                    c1 = (signed char)((unsigned)h1 / ((a0[i0 & 3u] + u0) | 1u));
                    if (((unsigned)x0 >> (u1 & 31u))) continue;
                }
                m0 ^= (v0 * ((unsigned)x0 | g0));
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn1((0x7fffffffu % ((r0.x * i0) | 1u)), a0[u1 & 3u], ((unsigned)x0 - (unsigned)s0)); }
                    s1 = (int)((unsigned)s1 + 0xbe6044d9u);
                    u0 = garr[i1 & 7u];
                    while (i2++ < 6u && ((unsigned)(x0 >> 70) + (unsigned)c1)) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + u3);
                        goto L2;
                        h1 = (unsigned short)(h1 + ((unsigned)(w0 >> 29) ^ i0));
                    }
                    if ((unsigned)h1) break;
                }
            }
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + ((unsigned)e0 % (u0 | 1u)));
            break; (void)(3u);
            if (budget != 0u) { budget -= 1u; u0 = fn1(4u, ((unsigned)(i0 && u3) / (i2 | 1u)), 0xddff01b5u); }
            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)d0 || u1);
        }
        if (((unsigned)((int)i2 >= (int)u0) / ((unsigned)(x0 >> 70) | 1u))) goto L2;
        if ((g1 & (unsigned)(g1 == p1))) {
            i0 = ((unsigned)(unsigned char)(unsigned)(u1 || (unsigned)(signed char)(unsigned)(0x9e9dc119u < (unsigned)s0)) | (g0 | a0[i0 & 3u])) & 15u;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)d0) goto L0;
                if (8u) break;
                c1 = (signed char)(unsigned)((unsigned)s0 < ((3u >> (0xb0c06cafu & 31u)) * 0xb95b04eu));
                if (((unsigned)(r0.y || g0) << ((unsigned)h1 & 31u))) {
                    goto L3;
                    if (fuel < 8u) return 9u;
                } else {
                    if ((p2 >> (0x80000000u & 31u))) break;
                    goto L2;
                }
                h1 = (unsigned short)(h1 + ((unsigned)((short)p2 > (signed char)(unsigned)((unsigned)w0 && p1)) + (garr[u2 & 7u] - (unsigned)b0)));
            } while (i0++ < 3u && (8u % (u3 | 1u)));
            garr[(unsigned)c1 & 7u] = (unsigned)!(((unsigned)e0 * (unsigned)(u1 && i0)) % (3u | 1u));
        }
    } else {
        if (u3 == 7u) return (((7u & u3) | (unsigned)c0) & (0x6576f3f9u - 0x77ce1103u));
        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)c0 == (unsigned)h0));
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0xffffffffu && 0x10000u), a0[i0 & 3u], u1); }
            if ((0x10000u % ((unsigned)(x0 >> 70) | 1u))) continue;
        }
        { unsigned t13; double z13; if ((((unsigned)h0 * (unsigned)(w0 >> 29))) & 1u) { t13 = 2u; z13 = (double)(((unsigned)f0) & 255u); } if ((((unsigned)h0 * (unsigned)(w0 >> 29))) & 1u) { u0 += t13; d0 = d0 * 0.5 + z13; }
            if ((garr[u2 & 7u] * (unsigned)h1)) goto L0;
            switch (p2 & 7u) {
                case 6u: ;
                if ((p2 ^ u3)) goto L0;
                if ((unsigned)(short)(unsigned)((int)(7u | (unsigned)s1) >= (int)0x7fffffffu)) goto done;
                default: ;
                h0 = (short)(unsigned)(unsigned char)((0x10000u ^ p0) + i2);
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(*q0, (0x3cc7e09fu % (0x80000000u | 1u)), g1); }
    u3 ^= (unsigned)c0;
    b0 = (unsigned)((int)(unsigned)s1 < (int)(unsigned)((unsigned)(fuel == garr[i1 & 7u]) == (0x9e8c0bb2u + p2))) != 0u;
    { unsigned t14; double z14; if (((unsigned)!(unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)h1)) & 1u) { t14 = (unsigned)!(4u - (unsigned)!(fuel + 0x4a7be8a1u)); z14 = (double)((0x703f8ebcu) & 255u); } if (((unsigned)!(unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)h1)) & 1u) { u0 += t14; d0 = d0 * 0.5 + z14; }
        do { if (--fuel == 0u) goto done;
            goto L1;
            if ((unsigned)(a0[i0 & 3u] == (unsigned)(w0 >> 29))) continue;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                u1 = u1 * 0x9e3779b1u + ((unsigned)(a0[u1 & 3u] < g0) & (unsigned)(short)(p2 & (g0 - g1)));
                { unsigned t15; double z15; if (((unsigned)((9u ^ 0x10000u) < 0x7fffffffu)) & 1u) { t15 = u3; z15 = (double)(((unsigned)((int)0x5db5d6f5u >= (int)p2)) & 255u); } if (((unsigned)((9u ^ 0x10000u) < 0x7fffffffu)) & 1u) { u0 += t15; d0 = d0 * 0.5 + z15; }
                    u2 = (unsigned)(signed char)(unsigned)((int)fuel < (int)garr[i1 & 7u]);
                    h1 = (unsigned short)(h1 + (unsigned)((int)u0 < (int)(unsigned)((int)a0[u1 & 3u] >= (int)((unsigned)(0xeaf4b3ccu || (unsigned)(x0 >> 70)) * i1))));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((r0.y >> (p0 & 31u)), (unsigned)c0, u0); }
                { unsigned t16; double z16; if (((unsigned)(4u < p2)) & 1u) { t16 = (0xd55c0bbeu % ((u0 + 0xce05ac0u) | 1u)); z16 = (double)(((unsigned)f0) & 255u); } if (((unsigned)(4u < p2)) & 1u) { u3 += t16; d0 = d0 * 0.5 + z16; }
                    if ((unsigned)!(0x4e3e42cu << (((unsigned)(x0 >> 70) / (u1 | 1u)) & 31u))) continue;
                    r0.y ^= ((unsigned)h0 & 0x10000u);
                    if ((0xad87f79bu - m0)) {
                        g1 += (fuel + fuel);
                        if ((u3 ? 0x5be8e2b1u : 3u)) {
                            l0 = (long)((unsigned long)l0 + (unsigned)h0);
                            if ((unsigned)((int)(unsigned)h1 < (int)8u)) break;
                            if ((unsigned)e0) break;
                        } else {
                            if ((unsigned)((int)((unsigned)e0 / (7u | 1u)) >= (int)*q0)) continue;
                            s0 = (int)(a0[u1 & 3u] * garr[i1 & 7u]);
                            g1 += (((*mp | 0x7fffffffu) - 0x7fffffffu) ^ (a0[i0 & 3u] >> (p0 & 31u)));
                        }
                        g0 = ((unsigned)((short)(unsigned)s1 > (signed char)garr[u2 & 7u]) + (unsigned)((short)p0 > (signed char)(unsigned)e0));
                    }
                    d0 = d0 * 0.5 + (double)((a0[i0 & 3u] ^ (unsigned)(x0 >> 70)) & 1023u);
                    if ((unsigned)((int)(unsigned)(signed char)((unsigned)(w0 >> 29) >> (*q0 & 31u)) < (int)m0)) {
                        *q0 = (unsigned)((int)(i0 << (4u & 31u)) < (int)(unsigned)((int)(unsigned)(i1 || a0[u1 & 3u]) < (int)i0));
                    }
                }
                u2 = (unsigned)((unsigned)(u3 || (unsigned)h0) < (unsigned)f0);
                if (-((unsigned)s0 * (unsigned)e0)) break;
            }
            break; (void)((u1 * 0xffffffffu));
        } while (i0++ < 6u && (unsigned)!((unsigned)s1 | 0xcf26c07cu));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    if ((unsigned)(unsigned char)(unsigned)((unsigned)s0 == (unsigned)b0)) goto L0;
    r0.y ^= (unsigned)((int)(unsigned)(signed char)(unsigned)(6u == (u3 & (unsigned)f0)) < (int)(unsigned)(unsigned char)(0xd590f098u + g0));
    if ((unsigned)((unsigned)s1 && (0x4bd63688u % (g0 | 1u)))) {
        s0 = (int)(unsigned)(0x10000u == fuel);
        do { if (--fuel == 0u) goto done;
            if (((unsigned)x0 ? garr[i1 & 7u] : 0x7fffffffu)) {
                while (i1++ < 2u && (unsigned)((short)((unsigned)c1 / (0x80000000u | 1u)) > (signed char)a0[i0 & 3u])) { if (--fuel == 0u) goto done;
                    g1 += (unsigned)(*q0 && (unsigned)c1);
                    if ((unsigned)(((unsigned)s0 >> ((unsigned)e0 & 31u)) < 0x33c1948fu)) break;
                    L1: if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + 0xffffffffu;
                    if ((unsigned)((unsigned)x0 || u0)) break;
                }
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    goto L0;
                    if (((fuel - (unsigned)(w0 >> 29)) << (a0[i0 & 3u] & 31u))) {
                        b0 = ((((unsigned)l0 >> (r0.x & 31u)) % ((unsigned)c0 | 1u)) << ((p0 | i0) & 31u)) != 0u;
                        u2 ^= 0x80000000u;
                        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)h1 && garr[u2 & 7u]));
                    } else {
                        while (i2++ < 5u && (p0 & u1)) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)b0 < (unsigned)(a0[u1 & 3u] == 0x7fffffffu)), ((unsigned)b0 & (i2 - 1u)), fuel); }
                        }
                    }
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)w0 < r0.y));
                    f0 = f0 * 0.5f + (float)((a0[u1 & 3u] ? 0x10000u : p1) & 255u);
                }
                if (0x8d7b1391u) break;
                a0[(unsigned)w0 & 3u] = (0xc37a5390u / (8u | 1u));
                { unsigned t0; double z0; if ((~(8u * *mp)) & 1u) { t0 = ~(unsigned)((unsigned)!(unsigned)(7u < r0.x) && (unsigned)c0); z0 = (double)(((unsigned)(short)(g0 ^ (fuel ^ 8u))) & 255u); } if ((~(8u * *mp)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    switch ((unsigned)(i0 == (unsigned)((short)8u > (signed char)0x7fffffffu)) & 7u) {
                        if ((unsigned)(a0[u1 & 3u] == i0)) break;
                    }
                    u0 = (unsigned)((unsigned)((unsigned)b0 < i2) && (i0 | 0x7fffffffu));
                    if (u3 == 7u) return (unsigned)(9u < (unsigned)((unsigned)d0 && (unsigned)(((unsigned)c0 / (0xffffffffu | 1u)) || u0)));
                    h1 = (unsigned short)(h1 + 0x22c74f85u);
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)f0 > (signed char)(~(unsigned)((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)w0) < 0xffffffffu) * 0x80000000u));
            } else {
                r0.y ^= (unsigned)(i0 == ((unsigned)s0 | (garr[u2 & 7u] * (unsigned)f0)));
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)0x58b4b8u >= (int)(unsigned)(5u && (unsigned)c0)), (unsigned)((unsigned)h1 == (0xada2326u | (unsigned)c0)), (unsigned)h0); }
                    if ((0x10000u ^ 0xb70596du)) goto L4;
                } while (i1++ < 4u && (unsigned)f0);
                *mp = -((((unsigned)h0 & 0x9f80142eu) | m0) & ((unsigned)s0 % (p2 | 1u)));
            }
            u3 ^= g1;
            if (-(unsigned)((short)*q0 > (signed char)g0)) goto L4;
            m0 ^= (unsigned)((unsigned)l0 == -(unsigned)(0x513141fau && u3));
            l0 = (long)((unsigned long)l0 + (0x80000000u << ((((9u | a0[u1 & 3u]) * (unsigned)(x0 >> 70)) >> (p0 & 31u)) & 31u)));
        } while (i0++ < 4u && -(unsigned)((fuel * p0) || (unsigned)x0));
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            q0 = &garr[a0[i0 & 3u] & 7u];
        }
        if ((unsigned)(signed char)(0xd59a4bfdu | (0u / (0x5b4b755eu | 1u)))) goto L2;
        if ((unsigned)(short)(unsigned)((int)0x90570f30u >= (int)0x7fffffffu)) goto L4;
        if (2u) {
            r0.x = (unsigned)((int)i0 < (int)3u);
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)r0.y < (int)g1), ((unsigned)(w0 >> 29) * (a0[u1 & 3u] | (unsigned)s1)), (unsigned)(unsigned char)(unsigned)((int)1u < (int)(unsigned)l0)); }
            u0 += 5u;
            if (0x10000u) {
                d0 = d0 * 0.5 + (double)((unsigned)((0x80000000u * 0x80000000u) == (unsigned)((short)i2 > (signed char)r0.x)) & 1023u);
            } else {
                u3 += (garr[u2 & 7u] ? p2 : (unsigned)(1u && *q0));
                if ((u0 - (unsigned)h0)) {
                    a0[(1u / (a0[i0 & 3u] | 1u)) & 3u] = (i1 + (0xcad88838u / (((unsigned)(short)(unsigned)((unsigned)w0 == i1) - 0x7fffffffu) | 1u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn1(p0, -((unsigned)(u0 && g1) >> ((unsigned)s1 & 31u)), ((unsigned)((short)(unsigned)w0 > (signed char)0x8da64294u) + 0x3d977520u)); }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(w0 >> 29) | (unsigned)s1), u2, (0xb9947d29u ? 0x4c8ad2d6u : u3)); }
                    r0.y ^= ((garr[i1 & 7u] & 0u) ? *mp : ((unsigned)s0 >> (garr[i1 & 7u] & 31u)));
                    if (((unsigned)c1 ^ p2)) goto L1;
                } else {
                    x0 = x0 * 0x100000001b3ull + (unsigned)((int)((unsigned)s1 / ((unsigned)l0 | 1u)) < (int)((unsigned)(x0 >> 70) * 5u));
                    h1 = (unsigned short)(h1 + ~(unsigned)((int)i1 < (int)(unsigned)(0x10000u || (unsigned)h1)));
                    g1 += ((unsigned)(0x10000u && (unsigned)l0) % ((unsigned)(signed char)(unsigned)((int)9u < (int)garr[i1 & 7u]) | 1u));
                }
                if ((0x80000000u | *q0)) goto L0;
            }
            if ((unsigned)(short)(unsigned)((int)0x35ec9d04u < (int)0xe7597e0fu)) goto L2;
        }
    }
    switch ((p1 + (a0[u1 & 3u] * 8u)) & 7u) {
        u3 = u3 * 0x9e3779b1u + i1;
        do { if (--fuel == 0u) goto done;
            garr[-(m0 << ((unsigned)b0 & 31u)) & 7u] = (((unsigned)x0 | 6u) | (*mp ? v0 : u2));
            if ((i0 | 0x67d500ddu)) {
                if ((unsigned)w0) break;
            } else {
                a0[(unsigned)!(unsigned)((int)garr[u2 & 7u] < (int)(unsigned)(w0 >> 29)) & 3u] = ((unsigned)(0xe70497f0u < 0x7fffffffu) % (2u | 1u));
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    c1 = (signed char)((unsigned)b0 + ((unsigned)b0 >> (0xbb7fde61u & 31u)));
                    v0 = ((garr[i1 & 7u] >> (u2 & 31u)) >> (u3 & 31u));
                    if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)w0 - (u3 ^ (unsigned)d0)), (unsigned)((int)(unsigned)s0 < (int)(unsigned)x0), (unsigned)(0x80000000u < 5u)); }
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        r0.y ^= (unsigned)((unsigned)(x0 >> 70) == (unsigned)e0);
                        u1 ^= ((unsigned)((short)garr[u2 & 7u] > (signed char)*q0) & (unsigned)((unsigned)l0 || (unsigned)c0));
                    }
                    do { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + (unsigned)(a0[u1 & 3u] || (unsigned)((unsigned)c1 == (unsigned)w0));
                        while (i0++ < 4u && g1) { if (--fuel == 0u) goto done;
                            break; (void)((unsigned)((int)(unsigned)((short)m0 > (signed char)0xaf0c90eu) >= (int)9u));
                            r0.x = (unsigned)(0x1b9465bcu || (unsigned)d0);
                            x0 = x0 * 0x100000001b3ull + ((unsigned)f0 | (unsigned)((unsigned)(w0 >> 29) || (unsigned)((int)(0x59fd21b6u & i2) >= (int)0xc68dad9cu)));
                            b0 = (m0 + ((unsigned)((int)(unsigned)h1 < (int)0x10000u) ^ p1)) != 0u;
                            r0.x = ((unsigned)c0 | (unsigned)!((i1 >> ((unsigned)h1 & 31u)) / ((unsigned)s1 | 1u)));
                            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)c1, fuel, a0[i0 & 3u]); }
                        }
                        s1 = (int)((unsigned)s1 + (a0[u1 & 3u] - garr[u2 & 7u]));
                        switch ((unsigned)(signed char)(u2 ? p1 : p0) & 7u) {
                            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)b0, (unsigned)((int)(unsigned)(i2 < v0) < (int)(unsigned)c1), 0x7fffffffu); }
                            b0 = ((unsigned)c1 << ((unsigned)((unsigned)b0 < *mp) & 31u)) != 0u;
                            break; (void)(-((unsigned)(x0 >> 70) << (((unsigned)(x0 >> 70) % (u1 | 1u)) & 31u)));
                            case 1u: ;
                        }
                        u2 = u2 * 0x9e3779b1u + ((unsigned)(unsigned char)(unsigned)(0x10000u && 0xffffffffu) | (unsigned)f0);
                    } while (i2++ < 3u && (unsigned)((short)a0[i0 & 3u] > (signed char)(garr[u2 & 7u] * u3)));
                    case 4u: ;
                }
                switch ((((unsigned)w0 + 0x7fffffffu) * i2) & 7u) {
                    g0 = (unsigned)((int)(i0 ^ (unsigned)(0xad9feae5u == (unsigned)c0)) >= (int)(unsigned)((int)0x7fffffffu >= (int)(unsigned)b0));
                    case 4u: ;
                }
            }
        } while (i0++ < 2u && (unsigned)(short)((unsigned)((int)u0 < (int)i2) | i1));
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (fuel < 8u) return u2;
            if (budget != 0u) { budget -= 1u; u3 = fn0(0x80000000u, 0xd952856bu, ((unsigned)b0 / (8u | 1u))); }
            for (;;) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((garr[i1 & 7u] - r0.y) & 255u);
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)(unsigned)x0 < (int)(unsigned)!(unsigned)((short)0x6eba8ccu > (signed char)0x2650b740u)), (fuel + (unsigned)h0), ((unsigned)((int)0x18c5f9a3u < (int)0u) << (r0.x & 31u))); }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(signed char)(*mp + 0x8eeb0363u), (4u & (unsigned)((short)0x7fffffffu > (signed char)v0)), (unsigned)((int)(unsigned)s1 < (int)(unsigned)(w0 >> 29))); }
            L2: if (--fuel == 0u) goto done;
            if (~(unsigned)(7u == (unsigned)l0)) continue;
        }
        if ((0x823095d0u << (0x8061bdcbu & 31u))) {
            case 2u: ;
            c1 = (signed char)~(unsigned)(5u || (unsigned)((unsigned)h0 || 2u));
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                u3 = ((9u ^ (unsigned)((garr[u2 & 7u] ^ (unsigned)(x0 >> 70)) == m0)) % (0x10000u | 1u));
                g1 += (unsigned)(short)(unsigned)((unsigned)c0 == (unsigned)f0);
                if (((unsigned)s0 & -(unsigned)((int)0x80000000u >= (int)0x5122bcb0u))) break;
            }
        } else {
            v0 = 0x10000u;
        }
        goto done;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)(unsigned)((unsigned)x0 || ((unsigned)s1 * (unsigned)(w0 >> 29))), ((unsigned)((unsigned)d0 == (unsigned)x0) % (p0 | 1u)), ((6u - 6u) % ((unsigned)c0 | 1u))); }
    g1 += ~((unsigned)((int)r0.y < (int)i2) % ((0u & (unsigned)w0) | 1u));
    *q0 += garr[u2 & 7u];
    x0 = x0 * 0x100000001b3ull + g0;
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)!(0xffffffffu - 0u), (unsigned)!(unsigned)((int)(unsigned)(*mp && r0.x) < (int)r0.x), (unsigned)((unsigned)h0 == 0xffffffffu)); }
    f0 = f0 * 0.5f + (float)((*q0 >> (g1 & 31u)) & 255u);
    u0 = u0 * 0x9e3779b1u + *mp;
    L3: if (--fuel == 0u) goto done;
    if ((u0 / ((0xffffffffu ^ 0x80000000u) | 1u))) goto L2;
    if ((m0 - 0x294b1144u)) {
        if ((unsigned)((int)(unsigned)h1 >= (int)(0x7cb9c100u | i1))) goto L4;
        l0 = (long)((unsigned long)l0 + (((m0 | g1) - 0x10000u) - (unsigned)((unsigned)x0 == 3u)));
        h1 = (unsigned short)(h1 + (unsigned)(u3 < ((0x80000000u & 0xb3930667u) >> (*q0 & 31u))));
        c1 = (signed char)((unsigned)c0 - (unsigned)((unsigned)((int)g1 >= (int)(unsigned)(i1 && r0.x)) || 0x8de251a5u));
    } else {
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)x0 * (unsigned)h1), ((p1 - u0) ^ (unsigned)w0), (unsigned)(g1 == (unsigned)((int)fuel >= (int)0xafe52266u))); }
        if ((unsigned)b0) goto L3;
        goto L2;
        s1 = (int)((unsigned)s1 + (unsigned)(((unsigned)(w0 >> 29) & u3) && 0xf3b7109u));
    }
    { unsigned t1; double z1; if ((u0) & 1u) { t1 = (unsigned)((unsigned)(u3 && garr[i1 & 7u]) && p0); z1 = (double)(((unsigned)((int)(unsigned)!(unsigned)((short)0x9e67cf51u > (signed char)(unsigned)l0) < (int)v0)) & 255u); } if ((u0) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        goto L2;
    }
    c0 = (unsigned char)(unsigned)(x0 >> 70);
    w0 = w0 * 6364136223846793005ull + *mp;
    if (8u) goto L3;
    s0 = (int)(unsigned)(short)(unsigned)(0x7d50c621u == p1);
    for (;;) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((int)9u < (int)u1), (unsigned)((short)(unsigned)b0 > (signed char)(u2 - g0)), (unsigned)w0); }
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)0x241b0aa3u >= (int)(1u ^ *q0));
        u3 = (((unsigned)h0 ? (unsigned)d0 : (unsigned)(x0 >> 70)) % ((unsigned)w0 | 1u));
        i1 = ((unsigned)(w0 >> 29) ? i0 : (unsigned)e0) & 15u;
    }
    if (((unsigned)((int)(unsigned)(x0 >> 70) < (int)0x853c2047u) >> (4u & 31u))) {
        *q0 = (unsigned)((short)(unsigned)(garr[i1 & 7u] == i2) > (signed char)(unsigned)((short)r0.y > (signed char)(g1 / (0x7fffffffu | 1u))));
        goto L3;
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)!((unsigned)c1 + (unsigned)(((unsigned)(short)(0xd9acb13au << (p0 & 31u)) % (0xe447f61au | 1u)) < (unsigned)c0)));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1((m0 + 1u), 3u, (unsigned)(5u < a0[i0 & 3u])); }
        if ((unsigned)(i1 || 4u)) goto L1;
    }
    a0[((unsigned)x0 & a0[i0 & 3u]) & 3u] = *q0;
    goto done;
    h0 = (short)(unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)(v0 * 8u) >= (int)i1) >= (int)(u0 >> ((unsigned)w0 & 31u)));
    if (budget != 0u) { budget -= 1u; u3 = fn0(p2, ((i1 % ((unsigned)x0 | 1u)) >> (0u & 31u)), p2); }
    if ((i2 ? (unsigned)h0 : a0[u1 & 3u])) {
        u0 += g0;
        switch ((unsigned)((unsigned)d0 == 0x9feb39e7u) & 7u) {
            r0.x = (unsigned)((unsigned)h0 < ((unsigned)s0 - (unsigned)d0));
            L4: if (--fuel == 0u) goto done;
        }
        u1 ^= ~(unsigned)(garr[u2 & 7u] < (unsigned)(short)(unsigned)(*q0 < g0));
        h0 = (short)(5u * (unsigned)f0);
        c1 = (signed char)(u2 + (0x7fffffffu & (unsigned)(0x80000000u && u3)));
        goto L0;
    }
    if (0xd8338503u) goto L3;
    goto L0;
    m0 ^= (unsigned)(signed char)((unsigned)(x0 >> 70) % (3u | 1u));
    if ((unsigned)l0) {
        if (fuel < 8u) return (((u2 | 2u) % (6u | 1u)) ^ (i1 * 0xffffffffu));
        if (m0) goto done;
        x0 = x0 * 0x100000001b3ull + (unsigned)((int)(0x10000u >> (*q0 & 31u)) < (int)(unsigned)s1);
        u3 = ((unsigned)(x0 >> 70) % (p2 | 1u));
    } else {
        h1 = (unsigned short)(h1 + ((unsigned)((int)0x31df6bau >= (int)(unsigned)l0) ^ (unsigned)(unsigned char)((unsigned)s1 >> ((unsigned)h1 & 31u))));
        if ((0x1ec346d8u - (unsigned)((short)i1 > (signed char)(unsigned)(x0 >> 70)))) goto L4;
        while (i0++ < 2u && (unsigned)h0) { if (--fuel == 0u) goto done;
            if ((unsigned)(0x10000u < u2)) break;
            if ((0x7fffffffu + u1)) {
                if ((unsigned)(((unsigned)w0 | p0) || i2)) break;
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(u0 < v0)) break;
                    if (((unsigned)b0 - u2)) break;
                    f0 = f0 * 0.5f + (float)((unsigned)((short)(unsigned)x0 > (signed char)0x7fffffffu) & 255u);
                    m0 ^= (unsigned)(signed char)(unsigned)(1u && 0x6d75a348u);
                }
                s1 = (int)((unsigned)s1 + (unsigned)(0xffffffffu || (((g0 % (v0 | 1u)) | 0x80000000u) & *mp)));
                if (0x8824d302u) break;
                b0 = (i0 * i1) != 0u;
                g0 = (unsigned)h1;
            }
            i1 = (unsigned)((int)(unsigned)c0 >= (int)(*q0 - p2)) & 15u;
            if (budget != 0u) { budget -= 1u; u3 = fn2((g1 - 3u), (unsigned)(a0[i0 & 3u] || 0xffffffffu), (0xa6ae08ddu << (p2 & 31u))); }
        }
    }
    c0 = (unsigned char)r0.y;
    h1 = (unsigned short)(h1 + (0x80000000u ^ p0));
    if ((g1 % ((unsigned)!(g0 | 0x4bd3187du) | 1u))) goto L2;
    if (((0x3c33a69bu / (g1 | 1u)) % (u2 | 1u))) goto L4;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(0x10000u == i0)) goto L0;
    if ((unsigned)(0xffffffffu || 0xf43c27edu)) {
        x0 = x0 * 0x100000001b3ull + 1u;
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if (((unsigned)((int)p0 < (int)(*q0 % (u3 | 1u)))) & 1u) { t0 = (unsigned)(unsigned char)((unsigned)(0x80000000u || (unsigned)h0) - *q0); z0 = (double)((0x7fffffffu) & 255u); } if (((unsigned)((int)p0 < (int)(*q0 % (u3 | 1u)))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                L1: if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)(short)(unsigned)((0xe3186915u % (p1 | 1u)) && (((unsigned)f0 | i0) ^ 0x938190b7u));
                for (;;) { if (--fuel == 0u) goto done;
                    a0[0xd931a11du & 3u] = ((unsigned)((unsigned)(x0 >> 70) == (unsigned)h0) % ((unsigned)((int)0x25ea3fbeu < (int)(3u * r0.y)) | 1u));
                    u2 += ((unsigned)x0 & (unsigned)(w0 >> 29));
                    if (budget != 0u) { budget -= 1u; u0 = fn2((u3 / (0x7fffffffu | 1u)), v0, *q0); }
                }
                L2: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2(i1, ((unsigned)((unsigned)c0 && 0x5cd4021eu) / ((unsigned)h1 | 1u)), (unsigned)(x0 >> 70)); }
            }
            L3: if (--fuel == 0u) goto done;
        }
        do { if (--fuel == 0u) goto done;
            r0.y ^= (0x25120e2bu | *mp);
            l0 = (long)((unsigned long)l0 + (unsigned)((short)7u > (signed char)(unsigned)((int)(unsigned)((unsigned)((unsigned)x0 || u3) || 0x81340d4fu) >= (int)u0)));
            r0.y ^= (unsigned)e0;
            do { if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if (((i0 + (0x10000u + *q0))) & 1u) { t1 = (unsigned)(short)((unsigned)s1 - (unsigned)(0x2e2833b2u == (unsigned)s0)); z1 = (double)(((unsigned)!(unsigned)((unsigned)w0 || g0)) & 255u); } if (((i0 + (0x10000u + *q0))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    L4: if (--fuel == 0u) goto done;
                    if ((unsigned)(0x40876bbeu && (v0 / (g1 | 1u)))) goto done;
                    switch ((u2 * (unsigned)l0) & 7u) {
                        q0 = &garr[((0xf720a89du ? r0.x : (unsigned)h0) << (i0 & 31u)) & 7u];
                    }
                    if ((r0.x + (unsigned)((int)i1 >= (int)a0[i0 & 3u]))) goto L2;
                }
                if (0xbda5b752u) {
                    u1 += u3;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((0x7fffffffu - (unsigned)b0), (unsigned)((int)v0 < (int)(unsigned)c0), (u3 / (u3 | 1u))); }
                    { unsigned t2; double z2; if (((0x7fffffffu % (8u | 1u))) & 1u) { t2 = (0xa5f6c11eu & 0x10000u); z2 = (double)(((unsigned)(short)(m0 ^ (unsigned)!(unsigned)((int)i2 >= (int)p2))) & 255u); } if (((0x7fffffffu % (8u | 1u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                        u3 ^= (unsigned)l0;
                        s0 = (int)(unsigned)!(0x80000000u & r0.y);
                        w0 ^= (unsigned long long)5u << ((((unsigned)h1 & (unsigned)((int)(unsigned)s0 >= (int)(unsigned)(w0 >> 29))) + (unsigned)s0) & 63u);
                    }
                } else {
                    if ((unsigned)(w0 >> 29)) break;
                    break; (void)(m0);
                    u1 += -(unsigned)(6u && (unsigned)h1);
                    v0 = (unsigned)((short)u1 > (signed char)(v0 ? m0 : ((unsigned)e0 << (u3 & 31u))));
                }
            } while (i1++ < 2u && (m0 * (unsigned)c0));
            if ((0x7fffffffu / (0x213ca526u | 1u))) goto L0;
            if ((unsigned)((unsigned)(signed char)(r0.x >> ((unsigned)e0 & 31u)) < (unsigned)b0)) continue;
        } while (i0++ < 4u && (unsigned)(v0 == (unsigned)(x0 >> 70)));
    } else {
        goto L4;
        if ((fuel ? 0x10000u : v0)) goto L0;
    }
    s0 = (int)((unsigned)h1 / ((unsigned)((int)1u < (int)g0) | 1u));
    if ((unsigned)((unsigned)((unsigned)(w0 >> 29) < a0[u1 & 3u]) < (unsigned)h1)) goto L3;
    goto L1;
    goto L1;
    if ((unsigned)((short)p1 > (signed char)0x7fffffffu)) goto L2;
    w0 ^= (unsigned long long)(i1 / (g0 | 1u)) << ((unsigned)((a0[i0 & 3u] ^ garr[i1 & 7u]) || u3) & 63u);
    u0 ^= 2u;
    if ((i0 ^ (unsigned)s0)) goto L2;
    a0[(unsigned)(0xdeb75875u < u2) & 3u] = (u2 ^ (unsigned)b0);
    switch (i0 & 7u) {
        case 3u: ;
        if ((0x356f34fdu + r0.x)) {
            if (0x7fffffffu) {
                case 4u: ;
                break; (void)((i2 >> (2u & 31u)));
                x0 = x0 * 0x100000001b3ull + 0x10000u;
                case 5u: ;
            } else {
                garr[u0 & 7u] = ((p1 >> (8u & 31u)) >> ((fuel ^ 0x10000u) & 31u));
                w0 ^= (unsigned long long)(8u << ((unsigned)c1 & 31u)) << (((unsigned)(u1 && (unsigned)s0) % ((a0[i0 & 3u] << ((unsigned)(7u < 0x80000000u) & 31u)) | 1u)) & 63u);
                f0 = f0 * 0.5f + (float)(((0x80000000u | (a0[u1 & 3u] | u2)) % (((unsigned)h1 >> ((unsigned)s1 & 31u)) | 1u)) & 255u);
                case 7u: ;
            }
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + *q0);
                { unsigned t3; double z3; if ((u2) & 1u) { t3 = (unsigned)((int)((unsigned)w0 / (4u | 1u)) < (int)(unsigned)x0); z3 = (double)((((unsigned)d0 >> (0x7fffffffu & 31u))) & 255u); } if ((u2) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                    if (i1) {
                        c1 = (signed char)(unsigned)(u2 || 7u);
                        if ((unsigned)(signed char)((unsigned)((int)(unsigned)b0 < (int)(unsigned)h0) << (*q0 & 31u))) continue;
                        b0 = ((unsigned)h1 << (u2 & 31u)) != 0u;
                        h0 = (short)(unsigned)(signed char)(unsigned)((unsigned)((int)u0 < (int)(unsigned)((p2 ^ (unsigned)(w0 >> 29)) || 7u)) < fuel);
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn2((0x30d2ca3fu | p0), (u0 >> ((unsigned)b0 & 31u)), p1); }
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1((p1 + (u1 * 0xf279de25u)), (unsigned)((int)*mp >= (int)p0), (unsigned)(short)(unsigned)((unsigned)b0 < (unsigned)s0)); }
                v0 = (-(unsigned)((0x80000000u & (unsigned)l0) || (unsigned)h0) >> (a0[u1 & 3u] & 31u));
                goto done;
                if (((unsigned)((int)(unsigned)l0 < (int)0xc4fcf997u) % ((unsigned)h1 | 1u))) goto L2;
            }
            i2 = i1 & 15u;
            break; (void)((0x10000u | p1));
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)(u1 || (unsigned)h1) < 0u);
        } else {
            default: ;
        }
        i0 = (((unsigned)d0 % ((unsigned)f0 | 1u)) - -(unsigned)((0xe0d14bcu - r0.x) == (unsigned)e0)) & 15u;
        break;
        if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)(w0 >> 29), (unsigned)(((unsigned)h1 / ((unsigned)b0 | 1u)) == (unsigned)c0), (*mp / (garr[u2 & 7u] | 1u))); }
        r0.x = u3;
    }
    goto L2;
    if (budget != 0u) { budget -= 1u; u1 = fn1(u3, u1, (unsigned)((short)0x566cb314u > (signed char)(unsigned)(i1 < p1))); }
    while (r0.y) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)(signed char)(unsigned)(*q0 == a0[i0 & 3u]) & 1023u);
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(g0 - v0));
            d0 = d0 * 0.5 + (double)((*q0 + garr[i1 & 7u]) & 1023u);
            if ((unsigned)(signed char)(((unsigned)(x0 >> 70) ^ *q0) & (unsigned)l0)) {
                q0 = &garr[2u & 7u];
                u3 = u3 * 0x9e3779b1u + (0x7fffffffu & (unsigned)!(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)((short)(unsigned)c1 > (signed char)p2)));
                goto L0;
            }
        }
        if ((unsigned)(signed char)(fuel << ((unsigned)f0 & 31u))) {
            d0 = d0 * 0.5 + (double)(~((unsigned)c0 + r0.y) & 1023u);
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(signed char)(4u + 0x8aa10f9cu), (0x10000u >> (garr[i1 & 7u] & 31u)), (0x10000u ^ 0x7fffffffu)); }
            g1 += (0x80000000u % (garr[u2 & 7u] | 1u));
            v0 = (i1 * 0x10000u);
            if (fuel < 8u) return (unsigned)l0;
        }
    }
    a0[(unsigned)((unsigned)d0 < p0) & 3u] = (unsigned)(u3 || garr[u2 & 7u]);
    if (budget != 0u) { budget -= 1u; u1 = fn3((7u & 0x527c73ccu), i2, (unsigned)((0x80000000u - i1) && p2)); }
    goto done;
    h0 = (short)((unsigned)((u0 ? (unsigned)l0 : 0xcedf6970u) && (unsigned)(x0 >> 70)) - v0);
    if (budget != 0u) { budget -= 1u; u0 = fn3(((unsigned)w0 % ((unsigned)c0 | 1u)), (0x8a215aafu * (unsigned)(x0 >> 70)), (unsigned)(unsigned char)(0x80000000u >> ((unsigned)c1 & 31u))); }
    { unsigned t4; double z4; if (((p0 * (unsigned)((int)p2 < (int)(unsigned)s1))) & 1u) { t4 = ((unsigned)x0 / (p1 | 1u)); z4 = (double)(((unsigned)!(u3 ^ (unsigned)l0)) & 255u); } if (((p0 * (unsigned)((int)p2 < (int)(unsigned)s1))) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        do { if (--fuel == 0u) goto done;
            if ((0xbb8d7fd1u & garr[i1 & 7u])) break;
            *mp = 0x7b2e6dc3u;
            break; (void)((unsigned)(i0 || a0[i0 & 3u]));
            x0 = x0 * 0x100000001b3ull + ((unsigned)((short)(0x5611f9d5u & g1) > (signed char)0x375e86c8u) | (9u + p1));
            for (;;) { if (--fuel == 0u) goto done;
                goto L4;
                q0 = &garr[9u & 7u];
                m0 ^= p1;
                *mp = (0xb018cfa1u << ((unsigned)(((unsigned)h0 | (unsigned)w0) == (unsigned)w0) & 31u));
            }
        } while (i0++ < 7u && (unsigned)((int)0u >= (int)0x45fc4f99u));
        if ((unsigned)h0) {
            c0 = (unsigned char)(unsigned)((unsigned)f0 || -(-((unsigned)h0 * (unsigned)l0) - 2u));
            if ((unsigned)((r0.x - u3) || 0x10000u)) goto L1;
        } else {
            if (budget != 0u) { budget -= 1u; u3 = fn0(fuel, (0x80000000u >> (((unsigned)(x0 >> 70) - (unsigned)e0) & 31u)), (unsigned)(a0[u1 & 3u] == a0[u1 & 3u])); }
            if (((unsigned)(0x7e383f23u && 0xa532b129u) + a0[i0 & 3u])) goto L4;
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)*mp >= (int)(unsigned)h1)) continue;
                q0 = &garr[(unsigned)((int)(0xe82ec6a4u ^ (unsigned)f0) >= (int)((unsigned)c0 - 0x7fffffffu)) & 7u];
                do { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (unsigned)w0;
                    if (budget != 0u) { budget -= 1u; u0 = fn3(u2, (unsigned)((int)(unsigned)e0 >= (int)(unsigned)w0), p2); }
                    m0 ^= ((unsigned)(w0 >> 29) + p2);
                    break; (void)(*mp);
                } while (i1++ < 2u && ~(r0.y ? a0[i0 & 3u] : r0.y));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)h1, (unsigned)((short)0xfd1524a0u > (signed char)v0), (g1 / (g1 | 1u))); }
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn3((garr[i1 & 7u] ? (unsigned)e0 : 6u), g1, (0x7fffffffu + (*q0 % ((unsigned)s0 | 1u)))); }
                    s0 = (int)garr[i1 & 7u];
                } while (i1++ < 7u && ((unsigned)c0 - (*q0 / ((unsigned)l0 | 1u))));
                if ((u1 / ((unsigned)h1 | 1u))) continue;
            }
            if (fuel < 8u) return ((unsigned)x0 & garr[i1 & 7u]);
        }
    }
    if ((unsigned)((int)(unsigned)((int)(unsigned)x0 >= (int)(unsigned)(x0 >> 70)) < (int)0x7fffffffu)) {
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(unsigned char)((unsigned)(x0 >> 70) % (*mp | 1u)), (9u ^ (unsigned)h0), (*mp % ((unsigned)(unsigned char)(0x8c18ce89u ^ 2u) | 1u))); }
        if ((unsigned)((short)g1 > (signed char)6u)) goto L4;
        s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)d0 < (int)((unsigned)s0 << (0xc2deec11u & 31u))));
    }
    u3 = (unsigned)(*q0 && (unsigned)b0);
    u0 ^= (unsigned)(short)(unsigned)((unsigned)((short)0x7fffffffu > (signed char)m0) || 0xffffffffu);
    if (u1) goto done;
    while (i0++ < 4u && (0x61f72f15u + m0)) { if (--fuel == 0u) goto done;
        g1 += (unsigned)((unsigned)s1 == (unsigned)(i0 < (0x8423b1e6u - 0x10000u)));
        continue; (void)((unsigned)w0);
        if (u2) goto L2;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)(0x3f780e2u || *q0);
        }
        break; (void)(m0);
        switch ((unsigned)!(p0 << (*q0 & 31u)) & 7u) {
            do { if (--fuel == 0u) goto done;
                if (i2) continue;
            } while (i1++ < 2u && (-(0xd5a24a25u | 0x911fc48eu) ^ 3u));
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn3((0x81f7e5b7u ^ (unsigned)!(unsigned)((int)(unsigned)h1 >= (int)r0.x)), (i1 & 4u), (unsigned)((unsigned)c1 && (unsigned)f0)); }
    if ((unsigned)e0) goto L4;
    switch (-(8u - (unsigned)b0) & 7u) {
        if ((unsigned)((int)(unsigned)h1 < (int)a0[u1 & 3u])) goto L1;
        if (budget != 0u) { budget -= 1u; u1 = fn1(7u, 9u, (unsigned)d0); }
        *mp = (unsigned)((unsigned)(0x807facfu || (unsigned)!(6u >> ((unsigned)(w0 >> 29) & 31u))) && ((unsigned)s0 / ((unsigned)w0 | 1u)));
        case 3u: ;
        e0 = e0 * 0.5L + (long double)(((*mp ? a0[i0 & 3u] : 7u) >> (((unsigned)f0 * (unsigned)s1) & 31u)) & 1023u);
    }
    q0 = &garr[(unsigned)((short)(unsigned)h0 > (signed char)v0) & 7u];
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)c0 & 7u) {
            if (r0.x) {
                if (((unsigned)e0 + g0)) {
                    u0 += (unsigned)!(0x10000u | u0);
                }
            } else {
                case 4u: ;
                w0 = w0 * 6364136223846793005ull + (unsigned)d0;
            }
            x0 = x0 * 0x100000001b3ull + (unsigned)(-(unsigned)(1u || a0[u1 & 3u]) && (unsigned)(short)(7u << ((unsigned)f0 & 31u)));
            if (u3 == 7u) return i1;
            l0 = (long)((unsigned long)l0 + ((unsigned)(unsigned char)((fuel - p1) * (unsigned)s0) + -(unsigned)(0xffffffffu < garr[u2 & 7u])));
        }
        if (u0) {
            a0[r0.y & 3u] = (unsigned)((int)(unsigned)e0 >= (int)(unsigned)!(unsigned)((int)8u < (int)0x7fffffffu));
            i0 = (unsigned)c1 & 15u;
            c0 = (unsigned char)(u1 ? (unsigned)l0 : (unsigned)((int)p0 >= (int)~(fuel >> ((unsigned)w0 & 31u))));
        }
        if (((unsigned)x0 >> (i2 & 31u))) {
            c0 = (unsigned char)-(g1 * (unsigned)f0);
            *mp = (r0.x / ((unsigned)((short)*q0 > (signed char)a0[i0 & 3u]) | 1u));
            r0.y ^= i2;
            g1 += (unsigned)(short)(unsigned)((int)(unsigned)(signed char)(0xc28e2437u ? i1 : i2) >= (int)-(p0 ^ r0.y));
        }
    }
    if (v0) {
        if (budget != 0u) { budget -= 1u; u1 = fn0(u2, (unsigned)((int)u2 >= (int)(unsigned)e0), ((g0 * u3) >> ((unsigned)c1 & 31u))); }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 7u, 0xd549dd33u, 0xb2ff529u },
        { 3u, 0xcf8b1eu, 0xb305b36fu },
        { 14u, 0x717dccfau, 0xf73612dau },
        { 3u, 0xfd4f62fdu, 0x6fe604dau },
        { 8u, 0x5852edabu, 0x2c1001b2u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
