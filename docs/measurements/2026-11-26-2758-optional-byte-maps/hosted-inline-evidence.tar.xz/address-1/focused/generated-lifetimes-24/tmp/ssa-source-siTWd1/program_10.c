// test-ssa-source's program of seed 141000433 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x1d085fd3u, g1 = 0x793ed19au;
static unsigned garr[8] = { 0x8db531du, 0x89adaecau, 0x8d584312u, 0x7dfaf0b2u, 0x1b9f4cfau, 0xb21d85fbu, 0x7eaca231u, 0xa31004c0u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while (i0++ < 4u && ((unsigned)!(unsigned)(i1 && 0xb0bd9638u) * 0x10000u)) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (p2 / (((unsigned)(0x80000000u == a0[u1 & 3u]) << (6u & 31u)) | 1u)));
        u2 = u2 * 0x9e3779b1u + (((unsigned)!(p1 * (unsigned)(signed char)(unsigned)((unsigned)l0 == *q0)) / (g0 | 1u)) + (unsigned)c0);
        g0 = (unsigned)((int)~(*q0 >> (i1 & 31u)) < (int)(unsigned)f0);
        *q0 += (garr[i1 & 7u] - (unsigned)c1);
        break; (void)((unsigned)h1);
        { unsigned t0; double z0; if (((unsigned)b0) & 1u) { t0 = u1; z0 = (double)((((g1 << (u0 & 31u)) % (0xffffffffu | 1u))) & 255u); } if (((unsigned)b0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            L0: if (--fuel == 0u) goto done;
            i1 = (unsigned)((unsigned)(a0[i0 & 3u] < (unsigned)h1) < (unsigned)((int)g0 < (int)(unsigned)((int)0x95628906u >= (int)u3))) & 15u;
            q0 = &garr[(unsigned)((int)garr[i1 & 7u] >= (int)u0) & 7u];
            l0 = (long)((unsigned long)l0 + ((unsigned)(0x80000000u < 0u) - 0x1cfdc345u));
            while (i1++ < 2u && (unsigned)((u0 << (u0 & 31u)) && garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(-(fuel * ((p0 + 7u) << ((unsigned)((unsigned)s0 < (unsigned)h1) & 31u))) & 1023u);
                x0 = x0 * 0x100000001b3ull + (fuel << (i1 & 31u));
                i0 = (unsigned)((short)(unsigned)l0 > (signed char)(0x80000000u ? 8u : m0)) & 15u;
            }
            do { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                L2: if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (unsigned)d0);
                if ((unsigned)c1) break;
            } while (i1++ < 6u && (0x10000u - (unsigned)((short)(unsigned)c0 > (signed char)(unsigned)h1)));
        }
    }
    { unsigned t1; double z1; if ((*q0) & 1u) { t1 = ~(unsigned)(garr[i1 & 7u] == 5u); z1 = (double)(((unsigned)e0) & 255u); } if ((*q0) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(8u | a0[i0 & 3u]) & 1023u);
        d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)((unsigned)((int)p2 >= (int)v0) && *mp) < (int)((unsigned)b0 % (g0 | 1u))) & 1023u);
    }
    switch (~(4u % (garr[i1 & 7u] | 1u)) & 7u) {
        m0 ^= ((unsigned)(short)((unsigned)w0 + 0x7fffffffu) ^ (unsigned)((short)(unsigned)x0 > (signed char)5u));
    }
    do { if (--fuel == 0u) goto done;
        continue; (void)(((unsigned)(garr[u2 & 7u] == 0xffffffffu) | v0));
        h1 = (unsigned short)(h1 + (*q0 >> ((unsigned)b0 & 31u)));
        u2 = ((u1 & *mp) % ((garr[u2 & 7u] - m0) | 1u));
        s0 = (int)(unsigned)(x0 >> 70);
        s1 = (int)((unsigned)s1 + (unsigned)(u0 < (unsigned)(*mp == 0x153dcb8cu)));
    } while (i0++ < 2u && (unsigned)((int)v0 >= (int)1u));
    goto L0;
    goto done;
    d0 = d0 * 0.5 + (double)(((unsigned)((int)(unsigned)x0 < (int)(unsigned)((int)fuel < (int)4u)) / ((unsigned)s1 | 1u)) & 1023u);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        L3: if (--fuel == 0u) goto done;
        continue; (void)((0x96b81eafu - p0));
        { unsigned t2; double z2; if (((unsigned)(short)(6u / ((unsigned)e0 | 1u))) & 1u) { t2 = (unsigned)l0; z2 = (double)((u3) & 255u); } if (((unsigned)(short)(6u / ((unsigned)e0 | 1u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            if (((unsigned)(w0 >> 29) / ((unsigned)h0 | 1u))) {
                if ((unsigned)((int)p0 < (int)p2)) break;
                if (((unsigned)b0 >> ((unsigned)(short)(i1 ^ g1) & 31u))) {
                    L4: if (--fuel == 0u) goto done;
                }
                if ((unsigned)h1) break;
                goto L4;
                continue; (void)((unsigned)(r0.x || u3));
            }
            if (((unsigned)(x0 >> 70) / ((unsigned)s0 | 1u))) break;
            if ((unsigned)((int)(unsigned)c0 >= (int)v0)) break;
            u1 ^= ((p1 / (7u | 1u)) ^ ((unsigned)e0 ^ a0[i0 & 3u]));
            s1 = (int)((unsigned)s1 + (((unsigned)b0 ? (unsigned)s0 : (unsigned)(0xfff4b26u < (unsigned)d0)) % ((unsigned)x0 | 1u)));
            q0 = &garr[v0 & 7u];
        }
        i0 = (unsigned)((int)(0xba89b86bu ? g1 : 0xc30a3b8bu) < (int)(unsigned)(g0 || u1)) & 15u;
        if (((unsigned)(fuel < 0x43a00a82u) / (4u | 1u))) {
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((v0 * (a0[u1 & 3u] | u3))) break;
            }
            m0 ^= ((v0 & i1) | (unsigned)(*mp && i1));
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                v0 = (unsigned)((int)(u2 + u3) >= (int)0x80000000u);
            }
            b0 = (8u % ((r0.y << ((0x811b1376u | ((unsigned)h1 % (u2 | 1u))) & 31u)) | 1u)) != 0u;
            break; (void)(6u);
            if ((unsigned)((int)(unsigned)(signed char)((unsigned)d0 + 0xdebaedc9u) >= (int)u3)) break;
        } else {
            break; (void)(0u);
        }
    }
    if ((unsigned)(x0 >> 70)) goto done;
    s1 = (int)((unsigned)s1 + (((unsigned)!(fuel << ((unsigned)(0x7fffffffu || 0x7fffffffu) & 31u)) & v0) / (g1 | 1u)));
    goto done;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = ((v0 / (g0 | 1u)) - (unsigned)!(0xffffffffu * fuel));
    }
    if (i0) goto L1;
    s1 = (int)((unsigned)s1 + (unsigned)((short)~(u3 ? v0 : g0) > (signed char)(a0[u1 & 3u] % (0xffffffffu | 1u))));
    s0 = (int)((unsigned)(p2 < (unsigned)(i1 < (unsigned)(0x10000u || (unsigned)(w0 >> 29)))) << (0x10000u & 31u));
    r0.y ^= ((unsigned)(short)(0x8d4575e5u >> (0x7f3da7d8u & 31u)) * ((unsigned)b0 + 0xffffffffu));
    { unsigned t3; double z3; if ((((unsigned)(x0 >> 70) % (a0[u1 & 3u] | 1u))) & 1u) { t3 = (0x7fffffffu % ((unsigned)((unsigned)s1 == p0) | 1u)); z3 = (double)(((unsigned)((unsigned)c0 == 0xffffffffu)) & 255u); } if ((((unsigned)(x0 >> 70) % (a0[u1 & 3u] | 1u))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
        if ((unsigned)(short)((unsigned)l0 / (0x749f139cu | 1u))) {
            do { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(-((unsigned)((int)(unsigned)h1 < (int)(unsigned)d0) + (unsigned)w0) & 255u);
                c0 = (unsigned char)*mp;
                if ((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)c1)) {
                    goto done;
                    h0 = (short)(1u >> ((unsigned)((unsigned)c0 == (a0[u1 & 3u] % ((unsigned)f0 | 1u))) & 31u));
                    break; (void)(-(u0 & *mp));
                    if ((unsigned)(unsigned char)(unsigned)(p2 == (unsigned)w0)) break;
                    break; (void)((i1 & *mp));
                    if ((unsigned)(short)(8u - (unsigned)s1)) break;
                } else {
                    u0 = (unsigned)((unsigned)(unsigned char)(garr[i1 & 7u] % ((8u % (0x27382816u | 1u)) | 1u)) == ~(unsigned)(fuel < g0));
                    if ((unsigned)(signed char)(unsigned)(0x321c4395u < (unsigned)h0)) break;
                    if ((unsigned)((unsigned)(x0 >> 70) && a0[u1 & 3u])) break;
                    if ((unsigned)(signed char)((unsigned)((int)0x3e2bb0e9u < (int)fuel) << (a0[u1 & 3u] & 31u))) {
                        if (0xcb936be3u) break;
                    }
                }
                u2 ^= -((unsigned)((unsigned)((int)0x80000000u >= (int)0x30473385u) || 0xd2a38655u) << ((unsigned)x0 & 31u));
                if (((unsigned)((int)(unsigned)f0 < (int)0xbaa11b73u) | (unsigned)c1)) {
                    d0 = d0 * 0.5 + (double)((unsigned)l0 & 1023u);
                    b0 = 0x2b004151u != 0u;
                    *q0 = (unsigned)(u0 && -(unsigned)(p2 || 1u));
                }
            } while (i0++ < 4u && (unsigned)w0);
            w0 = w0 * 6364136223846793005ull + 5u;
            if (0x4bc8fbccu) goto L2;
        }
        h0 = (short)(unsigned)((short)((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)x0) - 0x7fffffffu) > (signed char)(a0[u1 & 3u] + 0x659a7193u));
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)c0 >= (int)v0);
    if ((unsigned)((int)(unsigned)h1 >= (int)p2)) {
        e0 = e0 * 0.5L + (long double)((*q0 / ((unsigned)(*mp && (unsigned)(w0 >> 29)) | 1u)) & 1023u);
    }
    { unsigned t4; double z4; if ((u3) & 1u) { t4 = -((unsigned)(0x80c4afbeu < (unsigned)c1) >> (r0.y & 31u)); z4 = (double)(((unsigned)((unsigned)h0 || g0)) & 255u); } if ((u3) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
        if ((0x8615dcb5u ^ (unsigned)(m0 && r0.y))) goto L2;
    }
    if ((p2 << (-(unsigned)(6u == r0.x) & 31u))) {
        goto L3;
        goto L1;
        f0 = f0 * 0.5f + (float)((unsigned)c0 & 255u);
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)b0 ? 0x64b3d3b6u : g0) || (unsigned)!(r0.y - 0x808384cu));
            if ((i1 - (*mp >> (a0[i0 & 3u] & 31u)))) goto L3;
            if ((unsigned)c0) {
                a0[(unsigned)!(unsigned)((int)(unsigned)s0 < (int)(unsigned)w0) & 3u] = (unsigned)((unsigned)((int)0x10000u < (int)(unsigned)x0) && ((p0 >> (u3 & 31u)) - 0x5b6a6813u));
                garr[0x10000u & 7u] = (g0 % (6u | 1u));
                h0 = (short)(unsigned)(((unsigned)(7u || *mp) ^ (unsigned)l0) && g0);
            } else {
                if ((unsigned)(7u == (unsigned)d0)) break;
                if (v0) {
                    m0 ^= (0x8a301377u | (unsigned)!(unsigned)((int)u3 < (int)(unsigned)c0));
                    if (v0) break;
                    break; (void)(0x151432c2u);
                    break; (void)(i2);
                } else {
                    if ((u2 << (0u & 31u))) break;
                    v0 = (unsigned)((unsigned)b0 == 0x8503842au);
                    e0 = e0 * 0.5L + (long double)(((p2 | 0xf5da5ebu) % (((unsigned)(x0 >> 70) ^ u0) | 1u)) & 1023u);
                    g1 += (unsigned)(signed char)(unsigned)((int)((unsigned)h1 ? 0x2f3e53b4u : g0) >= (int)(unsigned)((int)0xffffffffu >= (int)u0));
                }
                do { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + 1u);
                    break; (void)((fuel | i1));
                } while (i1++ < 6u && (v0 + (p0 >> (r0.x & 31u))));
            }
            u2 ^= (unsigned)((unsigned)h0 && (unsigned)c1);
            h0 = (short)(u3 << (((unsigned)h1 * (unsigned)((int)(u3 + i0) < (int)u3)) & 31u));
        }
        while ((r0.y ^ (unsigned)h0)) { if (--fuel == 0u) goto done;
            q0 = &garr[(-((fuel << ((unsigned)c0 & 31u)) ? 0x7fffffffu : 3u) >> (0x80000000u & 31u)) & 7u];
            if ((r0.x << ((unsigned)s0 & 31u))) {
                c1 = (signed char)(unsigned)(*q0 || ((0xffffffffu % (garr[u2 & 7u] | 1u)) / ((3u % (0x50003426u | 1u)) | 1u)));
            } else {
                g0 = (unsigned)h1;
                if ((0x80000000u - 0x47f2bb92u)) break;
                *mp = (unsigned)(r0.y || a0[i0 & 3u]);
            }
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((~(3u - 8u) << (8u & 31u)));
            }
            *mp = (unsigned)(0xb9f45eaau || (unsigned)(garr[u2 & 7u] < (unsigned)((short)(unsigned)b0 > (signed char)i1)));
            do { if (--fuel == 0u) goto done;
                g1 += (unsigned)((unsigned)!(3u * (5u / ((0x10000u | 0xffffffffu) | 1u))) == u0);
                do { if (--fuel == 0u) goto done;
                    g0 = ~(unsigned)((short)(v0 | u0) > (signed char)6u);
                } while (i2++ < 7u && (unsigned)(0x80000000u < *mp));
                if ((unsigned)(signed char)((unsigned)b0 - 0x35f90e8u)) break;
                *q0 += ((unsigned)d0 >> ((u1 ^ *q0) & 31u));
            } while (i1++ < 2u && 0x7fffffffu);
            if ((a0[i0 & 3u] >> (*mp & 31u))) break;
        }
        if ((u3 - ((unsigned)s0 * 0xffffffffu))) goto L1;
    } else {
        do { if (--fuel == 0u) goto done;
            v0 = (unsigned)(v0 < (p2 / ((v0 + garr[i1 & 7u]) | 1u)));
            if (0x7fffffffu) break;
            if (0x812c8e97u) break;
            *q0 = (unsigned)(((unsigned)((short)u3 > (signed char)p0) | u2) || (unsigned)((short)0xd799983eu > (signed char)(unsigned)l0));
            l0 = (long)((unsigned long)l0 + (unsigned)(fuel < 0x10000u));
        } while (i0++ < 7u && 0x5d8c69b9u);
        if ((unsigned)h1) goto L3;
        if (7u) {
            h0 = (short)(unsigned)((int)a0[u1 & 3u] >= (int)u1);
            *q0 = ((g0 % ((unsigned)((short)(unsigned)h0 > (signed char)(unsigned)c1) | 1u)) + a0[u1 & 3u]);
            i0 = u0 & 15u;
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(p2);
                while (i1++ < 6u && (unsigned)(p2 < a0[u1 & 3u])) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)s0 || (r0.y ^ a0[i0 & 3u])) & 1023u);
                }
                if ((((unsigned)c0 + 0xffffffffu) << (0xf48676dbu & 31u))) {
                    u2 ^= (unsigned)((int)(unsigned)c1 >= (int)7u);
                    if ((unsigned)((short)(unsigned)((int)0x7fffffffu < (int)5u) > (signed char)0x87fcf5ddu)) break;
                    if ((unsigned)s0) break;
                }
            }
        } else {
            c1 = (signed char)(unsigned)!((unsigned)f0 ? *mp : i2);
        }
        while (i0++ < 6u && (unsigned)(short)(unsigned)(a0[u1 & 3u] < r0.x)) { if (--fuel == 0u) goto done;
            g1 += (((unsigned)(0x4b7c2d42u && (u1 | (unsigned)w0)) / (0x80000000u | 1u)) ^ v0);
            c0 = (unsigned char)(unsigned)((short)(garr[u2 & 7u] - 0x4b537531u) > (signed char)((unsigned)e0 & i2));
        }
    }
    do { if (--fuel == 0u) goto done;
        break; (void)(0x80fff8d4u);
        if ((unsigned)((int)u0 < (int)(*mp >> (0x10000u & 31u)))) goto L0;
        if (p1) break;
    } while (i0++ < 5u && (unsigned)l0);
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        s0 = (int)(unsigned)(0x8bbdcf33u || (a0[u1 & 3u] - r0.x));
        u1 = (unsigned)(unsigned char)(unsigned)(garr[u2 & 7u] < (unsigned)((int)0x7fffffffu < (int)r0.x));
        if ((unsigned)(0x80000000u || (unsigned)((int)g0 < (int)0xab01ea1eu))) break;
    }
    for (;;) { if (--fuel == 0u) goto done;
        if ((2u << (0x8d652300u & 31u))) break;
    }
    goto L4;
    u2 += u3;
    if (((unsigned)d0 % ((0x804f6df7u ^ (unsigned)h1) | 1u))) goto done;
    goto L3;
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)(0x7134cb57u && 1u)) break;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)(x0 >> 70) == u3)) {
                g0 = (v0 >> (a0[u1 & 3u] & 31u));
                e0 = e0 * 0.5L + (long double)(v0 & 1023u);
            }
            h0 = (short)(unsigned)((int)(unsigned)(0x453797c6u < (unsigned)(signed char)(0xf0ff7c1du % (u1 | 1u))) < (int)0xffffffffu);
            while ((unsigned)s0) { if (--fuel == 0u) goto done;
                if (garr[i1 & 7u]) break;
                u1 = ((unsigned)w0 % (v0 | 1u));
                if ((unsigned)((int)fuel < (int)r0.y)) break;
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)8u < (int)(unsigned)s0) < (int)0x80000000u) != 0u;
                    *mp = ~((unsigned)(w0 >> 29) - (unsigned)(6u || 0x3341cc1fu));
                    h0 = (short)(unsigned)s1;
                    if ((0xee6c98a6u - (p1 - r0.y))) break;
                    r0.y ^= (unsigned)!((unsigned)(2u && (unsigned)h0) + u0);
                }
            }
            if (*q0) break;
            if ((unsigned)(short)(unsigned)((int)0x10000u >= (int)0xdd862278u)) break;
            if (i0) {
                if ((unsigned)((int)(unsigned)((int)i0 < (int)2u) < (int)*q0)) break;
                if ((unsigned)(r0.y && m0)) break;
                *mp = (u0 << (0x10000u & 31u));
            }
        }
    }
    if ((unsigned)(v0 && u3)) goto L4;
    if ((0x7fffffffu | 0x1381e5f7u)) goto L4;
    switch ((unsigned)((int)0x10000u >= (int)(unsigned)d0) & 7u) {
        if ((0x7fffffffu / (*mp | 1u))) goto L1;
        if ((unsigned)h1) goto L2;
        case 2u: ;
    }
    c0 = (unsigned char)-(unsigned)((((unsigned)(5u == (unsigned)w0) ^ (unsigned)(x0 >> 70)) / ((unsigned)(x0 >> 70) | 1u)) == (unsigned)w0);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    m0 ^= (g0 * (unsigned)w0);
    q0 = &garr[(unsigned)((3u ^ m0) && (0x80000000u & fuel)) & 7u];
    e0 = e0 * 0.5L + (long double)((3u / (-((unsigned)(w0 >> 29) << (i2 & 31u)) | 1u)) & 1023u);
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)0x5a7137c5u < (int)0x4152cf9du), i0, 0xc3589abbu); }
    if ((unsigned)(0x7e18c17eu && (unsigned)c1)) goto L3;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= ((unsigned)(7u == (unsigned)((unsigned)s0 || 0x286d0694u)) + (r0.x % ((unsigned)e0 | 1u)));
        g0 = (unsigned)(7u && ((unsigned)(x0 >> 70) * ((unsigned)h0 / (1u | 1u))));
        { unsigned t0; double z0; if (((i2 / (((unsigned)c1 >> (r0.x & 31u)) | 1u))) & 1u) { t0 = (i2 >> ((unsigned)s0 & 31u)); z0 = (double)(((u1 - g0)) & 255u); } if (((i2 / (((unsigned)c1 >> (r0.x & 31u)) | 1u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            if (budget != 0u) { budget -= 1u; u1 = fn0(*q0, (unsigned)b0, (5u * 8u)); }
            L0: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)s0 + (unsigned)(short)(unsigned)(0u == a0[i0 & 3u])), ((0xce56fb25u + fuel) / ((unsigned)s1 | 1u)), ((unsigned)((unsigned)s0 && i1) % (v0 | 1u))); }
        }
        if ((unsigned)((short)1u > (signed char)u2)) {
            u0 ^= (unsigned)((int)(p2 - 0x7abab2e6u) < (int)u3);
            g0 = (unsigned)((0x78867b95u % (i0 | 1u)) || (unsigned)l0);
        }
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = (unsigned)((unsigned)x0 < ((unsigned)(g0 < v0) % ((unsigned)(i0 == p1) | 1u)));
        if ((unsigned)((int)r0.x >= (int)u2)) break;
        s0 = (int)(((*mp % ((unsigned)c0 | 1u)) | (unsigned)((short)p2 > (signed char)u3)) << (p2 & 31u));
    }
    s1 = (int)((unsigned)s1 + 0xa72aea11u);
    if (0x7fffffffu) goto L3;
    f0 = f0 * 0.5f + (float)((0xe3619e9fu - (unsigned)((int)(0xffffffffu ^ (unsigned)l0) < (int)p1)) & 255u);
    e0 = e0 * 0.5L + (long double)(((unsigned)(w0 >> 29) | (unsigned)((int)(unsigned)h1 < (int)(unsigned)l0)) & 1023u);
    c0 = (unsigned char)0xffffffffu;
    s0 = (int)(0u << ((unsigned)b0 & 31u));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)(unsigned)((int)u1 >= (int)(unsigned)(x0 >> 70)) << (-(p2 >> ((unsigned)f0 & 31u)) & 63u);
        while (i1++ < 3u && (i0 >> ((i0 + g0) & 31u))) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if (0xffffffffu) goto L3;
                break; (void)(g1);
                l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)((unsigned)h0 < (unsigned)d0) < (int)(0x7fffffffu << ((0x998997adu + garr[i1 & 7u]) & 31u))));
            } while (i2++ < 5u && (unsigned)(signed char)(u2 / ((unsigned)(u0 < i2) | 1u)));
        }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            while (i2++ < 3u && 0xfc9d25cdu) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((garr[i1 & 7u] | (*mp % (*q0 | 1u))), a0[u1 & 3u], i2); }
                if (0x10000u) break;
                if ((unsigned)((unsigned)c1 && (v0 & v0))) continue;
            }
            for (;;) { if (--fuel == 0u) goto done;
                if ((0xa23ca9f1u << ((unsigned)e0 & 31u))) goto done;
            }
            if ((i0 / ((unsigned)(p0 < g1) | 1u))) goto L0;
            switch (((unsigned)c0 | 0xffffffffu) & 7u) {
                l0 = (long)((unsigned long)l0 + (0x7fffffffu << (u2 & 31u)));
                case 0u: ;
                case 5u: ;
                if ((unsigned)(0xffffffffu < i0)) goto L0;
                switch ((0x728b3023u & ((unsigned)(x0 >> 70) / ((unsigned)(w0 >> 29) | 1u))) & 7u) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)(7u - garr[i1 & 7u]), 3u, ((2u * u2) & r0.x)); }
                    if ((p0 ^ 0x9d96bae3u)) goto L0;
                }
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((a0[i0 & 3u] >> ((7u ^ i2) & 31u))) break;
                    h1 = (unsigned short)(h1 + ((unsigned)(0xed626406u < (7u & 0xc71010cu)) % (4u | 1u)));
                    if (0x5abcb920u) break;
                }
            }
            w0 ^= (unsigned long long)(unsigned)((unsigned)l0 || 0x80000000u) << (0u & 63u);
        }
        if ((unsigned)(short)((0xd731cb08u % (m0 | 1u)) << (u0 & 31u))) {
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= *q0;
                *mp = (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)h0);
            }
            L1: if (--fuel == 0u) goto done;
            r0.y ^= (((unsigned)s1 ^ ((unsigned)(x0 >> 70) * (unsigned)d0)) - (unsigned)s1);
            L2: if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                u1 = u1 * 0x9e3779b1u + ((((unsigned)e0 << (((unsigned)(w0 >> 29) ^ (unsigned)x0) & 31u)) ^ 0xffffffffu) * 0xd2841a1eu);
                w0 ^= (unsigned long long)0xb9d15773u << (0x6f007a38u & 63u);
                c1 = (signed char)(0x7fffffffu / ((0x7fffffffu & (unsigned)((int)(unsigned)s1 < (int)0xfaa8d01cu)) | 1u));
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(0xe9e865c2u < (0x4532f8b8u % ((unsigned)x0 | 1u))), u1, (unsigned)((short)(unsigned)c1 > (signed char)(unsigned)(w0 >> 29))); }
                        if (((1u * garr[i1 & 7u]) - u2)) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((0x6c600a01u | ((unsigned)(w0 >> 29) >> ((unsigned)f0 & 31u))), (0x83a62204u ^ (unsigned)((int)u1 >= (int)(unsigned)f0)), g1); }
                        L3: if (--fuel == 0u) goto done;
                    } while (i0++ < 6u && (unsigned)((int)7u < (int)0xbdaf0d2eu));
                    L4: if (--fuel == 0u) goto done;
                    if (0x7fffffffu) {
                        m0 ^= (unsigned)((int)(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)s0) >= (int)*mp);
                        break; (void)((unsigned)(0x3d23f258u || (0x9adb993eu & p1)));
                        g0 = (unsigned)c0;
                        v0 = g0;
                        i0 = -(unsigned)((short)(unsigned)e0 > (signed char)a0[i0 & 3u]) & 15u;
                        switch ((0x4794a081u - a0[u1 & 3u]) & 7u) {
                            s0 = (int)(unsigned)((int)0x4e916b10u < (int)(unsigned)(r0.y == 7u));
                            case 3u: ;
                            if (fuel < 8u) return -(8u * (unsigned)(unsigned char)(0x10000u ? (unsigned)(w0 >> 29) : 0x4d0b8e49u));
                            e0 = e0 * 0.5L + (long double)(0xbf83236bu & 1023u);
                        }
                    }
                    if (((unsigned)c1 << (2u & 31u))) goto L3;
                }
            } while (i1++ < 3u && (unsigned)(u3 || (unsigned)!(unsigned)(0xf8874659u == a0[u1 & 3u])));
        } else {
            i2 = 8u & 15u;
            switch ((unsigned)x0 & 7u) {
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)((unsigned)((unsigned)e0 || garr[i1 & 7u]) || (u2 ^ (unsigned)s0));
                    case 7u: ;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(r0.y, (unsigned)f0, (i0 << ((g1 ^ p2) & 31u))); }
                }
                r0.y ^= ((0x2d189bf3u ^ (unsigned)s1) * (unsigned)e0);
            }
            if (~(unsigned)(0xbffdeaf5u < g1)) break;
            if ((0x25e2581fu >> (p2 & 31u))) {
                if (i1) break;
                x0 = x0 * 0x100000001b3ull + (unsigned)(~(unsigned)((unsigned)!(unsigned)(0x7fffffffu == (unsigned)c0) == (unsigned)f0) && v0);
                a0[(unsigned)(w0 >> 29) & 3u] = (unsigned)(short)(unsigned)((unsigned)!(unsigned)((int)((unsigned)h0 % (0xffffffffu | 1u)) < (int)(unsigned)e0) == garr[u2 & 7u]);
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)((int)(4u & r0.y) >= (int)g1));
                    g0 = (unsigned)c0;
                    if ((unsigned)((short)(unsigned)c1 > (signed char)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0xf6492f70u))) {
                        s1 = (int)((unsigned)s1 + ((unsigned)s1 * -((unsigned)(x0 >> 70) * (unsigned)h0)));
                        if (fuel < 8u) return (unsigned)(0xffffffffu && 0x80000000u);
                    }
                    l0 = (long)((unsigned long)l0 + m0);
                    garr[(unsigned)(u0 || u2) & 7u] = ((unsigned)((unsigned)c1 < (unsigned)c0) << (a0[u1 & 3u] & 31u));
                    u0 ^= ((unsigned)((r0.y - (unsigned)e0) || (a0[u1 & 3u] * p1)) / (g0 | 1u));
                }
                q0 = &garr[((unsigned)w0 ^ (p1 + -(r0.x % ((unsigned)f0 | 1u)))) & 7u];
            }
        }
        h0 = (short)(r0.x + (unsigned)c0);
    }
    if ((i0 & g1)) goto done;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)((garr[i1 & 7u] << ((unsigned)(w0 >> 29) & 31u)) ? r0.x : (unsigned)l0);
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= 7u;
        }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            q0 = &garr[(((unsigned)(x0 >> 70) | garr[u2 & 7u]) / ((unsigned)(short)(unsigned)((int)i2 < (int)0x2de4a5eau) | 1u)) & 7u];
            i1 = u2 & 15u;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(p2, 0xffffffffu, ((unsigned)((int)v0 >= (int)0xf3283c19u) >> (a0[i0 & 3u] & 31u))); }
        u3 = u3 * 0x9e3779b1u + (unsigned)h1;
        if ((a0[u1 & 3u] % (((unsigned)b0 ^ 0xeb8acdd0u) | 1u))) goto done;
    }
    { unsigned t1; double z1; if (((unsigned)s0) & 1u) { t1 = (*q0 ^ (unsigned)w0); z1 = (double)(((unsigned)!(p0 ^ v0)) & 255u); } if (((unsigned)s0) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + ((unsigned)(w0 >> 29) >> (g0 & 31u)));
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((short)(unsigned)s0 > (signed char)3u)) goto L2;
                { unsigned t2; double z2; if (((unsigned)(v0 && i1)) & 1u) { t2 = (unsigned)((int)(unsigned)b0 >= (int)((unsigned)d0 | 0xffffffffu)); z2 = (double)(((unsigned)(0xad69eeefu && (unsigned)d0)) & 255u); } if (((unsigned)(v0 && i1)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    if ((unsigned)(unsigned char)((unsigned)h1 << (u2 & 31u))) break;
                    b0 = fuel != 0u;
                    if ((unsigned)h1) break;
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((garr[i1 & 7u] / ((unsigned)(signed char)((unsigned)l0 ^ 1u) | 1u))) break;
                        u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)((short)(unsigned)(signed char)(m0 % ((unsigned)c1 | 1u)) > (signed char)0x7fffffffu) == ((unsigned)e0 + g0));
                        s1 = (int)((unsigned)s1 + (p2 ^ r0.x));
                    }
                    switch (~(((unsigned)d0 * 0x7fffffffu) * (unsigned)f0) & 7u) {
                        b0 = (unsigned)w0 != 0u;
                        w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)b0 < (unsigned)(0x10000u == (unsigned)((g1 >> (u2 & 31u)) < (unsigned)(w0 >> 29))));
                    }
                }
                v0 = (p2 - p2);
                while (i2++ < 5u && (r0.y | (unsigned)(i0 == (unsigned)c0))) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + ((unsigned)c1 >> ((unsigned)l0 & 31u));
                    if (garr[u2 & 7u]) break;
                    *q0 = ((0xc426d5cu ? m0 : g1) / (0u | 1u));
                    h0 = (short)((unsigned)w0 << (v0 & 31u));
                    w0 ^= (unsigned long long)0xffffffffu << (-(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)b0) & 63u);
                    if ((unsigned)f0) {
                        g0 = u0;
                        if ((unsigned)(1u < (p2 ^ a0[i0 & 3u]))) continue;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((((unsigned)s1 | a0[i0 & 3u]) - 1u), (unsigned)c0, (unsigned)s0); }
                    }
                }
                if ((unsigned)f0) goto L1;
                if ((unsigned)e0) {
                    while (i2++ < 3u && (unsigned)((short)i2 > (signed char)(unsigned)(0xc4fcc87u || *q0))) { if (--fuel == 0u) goto done;
                        r0.x = (unsigned)b0;
                        if ((unsigned)c0) {
                            r0.x = (((0x80000000u - (unsigned)((unsigned)d0 == 0x10000u)) / (a0[i0 & 3u] | 1u)) % (0xa6180aa7u | 1u));
                            if (budget != 0u) { budget -= 1u; u0 = fn0(0x5a665949u, 8u, (unsigned)((unsigned)((int)0x906f6da7u >= (int)0xabfe2e7eu) < p0)); }
                            x0 = x0 * 0x100000001b3ull + (unsigned)c0;
                            q0 = &garr[(garr[u2 & 7u] >> (a0[u1 & 3u] & 31u)) & 7u];
                        } else {
                            e0 = e0 * 0.5L + (long double)((*mp % (0x815b0cb0u | 1u)) & 1023u);
                            if (budget != 0u) { budget -= 1u; u3 = fn0(0x80000000u, (unsigned)(unsigned char)(i1 | 3u), u3); }
                            r0.x = (unsigned)(a0[i0 & 3u] || (unsigned)d0);
                        }
                        s0 = (int)(m0 / (g0 | 1u));
                        m0 ^= ((unsigned)(u0 < (u2 * 9u)) ? *mp : (unsigned)c1);
                        if ((unsigned)((int)*q0 >= (int)(i1 ^ (unsigned)s1))) goto done;
                    }
                    if (3u) break;
                    x0 = x0 * 0x100000001b3ull + 0x7d64e6b5u;
                    if ((unsigned)e0) continue;
                    i0 = (((unsigned)e0 - 0x7fffffffu) - (1u / ((unsigned)((short)0x92be560u > (signed char)9u) | 1u))) & 15u;
                } else {
                    c0 = (unsigned char)(unsigned)((int)(p2 ? 3u : (unsigned)s0) < (int)(p2 << ((unsigned)c1 & 31u)));
                }
            } while (i1++ < 5u && u0);
        }
        if ((p2 % ((unsigned)(x0 >> 70) | 1u))) goto done;
        r0.x = ~(unsigned)(u3 || ((unsigned)f0 | (i0 / (*mp | 1u))));
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        continue; (void)((unsigned)!((unsigned)((int)u0 < (int)a0[i0 & 3u]) >> (0x7cd992f3u & 31u)));
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)i2 > (signed char)p2), (unsigned)s0, (unsigned)((int)*q0 >= (int)(unsigned)c1)); }
    }
    while (i0++ < 4u && ((unsigned)((short)0x44387258u > (signed char)(unsigned)h0) + u3)) { if (--fuel == 0u) goto done;
        if (p0) {
            if (((unsigned)(p2 < (unsigned)e0) * 0xb0054971u)) break;
            m0 ^= ((unsigned)((int)(unsigned)h1 >= (int)(unsigned)(0u || 0x7fffffffu)) << ((unsigned)f0 & 31u));
            if ((unsigned)((int)(unsigned)l0 >= (int)*q0)) continue;
            { unsigned t3; double z3; if ((((u0 << (fuel & 31u)) + (unsigned)s1)) & 1u) { t3 = ((a0[i0 & 3u] / (p0 | 1u)) & fuel); z3 = (double)(((unsigned)(0x80000000u || 0x80000000u)) & 255u); } if ((((u0 << (fuel & 31u)) + (unsigned)s1)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                *q0 += (unsigned)(0x10000u < (9u * (0xffffffffu % (0xad02fe9cu | 1u))));
            }
        }
        if ((unsigned)((int)garr[i1 & 7u] < (int)(9u << (p0 & 31u)))) break;
        u1 = u1 * 0x9e3779b1u + *mp;
    }
    goto L4;
    goto L0;
    g1 += ((unsigned)(signed char)(p1 / ((unsigned)s0 | 1u)) ? (unsigned)h1 : i1);
    w0 ^= (unsigned long long)(unsigned)((short)(unsigned)c0 > (signed char)r0.y) << ((unsigned)((unsigned)!((unsigned)(9u == u0) >> (*mp & 31u)) == ((unsigned)e0 >> (3u & 31u))) & 63u);
    while (i0++ < 4u && (unsigned)((short)v0 > (signed char)(unsigned)s1)) { if (--fuel == 0u) goto done;
        goto L2;
        garr[(unsigned)((short)9u > (signed char)(unsigned)l0) & 7u] = (unsigned)(short)((unsigned)b0 << ((g1 ^ p1) & 31u));
        if (r0.y) {
            if ((0xffffffffu * garr[u2 & 7u])) continue;
            if (-(u1 >> (-(unsigned)(*q0 && v0) & 31u))) break;
            if (((unsigned)w0 % (0x9d5a220au | 1u))) {
                r0.x = ((garr[u2 & 7u] ^ 0xffffffffu) >> ((unsigned)((short)i0 > (signed char)0x37c3b8dbu) & 31u));
                break; (void)((u2 % (2u | 1u)));
                r0.x = (8u ? 0x80000000u : (unsigned)f0);
            } else {
                for (;;) { if (--fuel == 0u) goto done;
                    if (((0x2910a5b5u - garr[u2 & 7u]) * (unsigned)(w0 >> 29))) break;
                    r0.y ^= ((5u ^ (unsigned)e0) ? garr[i1 & 7u] : p0);
                    h0 = (short)3u;
                    if ((unsigned)x0) break;
                    *q0 = ((unsigned)c1 | (0x15814fc0u | (unsigned)(x0 >> 70)));
                }
                *mp = u1;
                if ((unsigned)((int)fuel >= (int)i0)) {
                    m0 ^= (i0 ^ 8u);
                    if (((unsigned)(w0 >> 29) >> (a0[i0 & 3u] & 31u))) break;
                    if (i1) {
                        u1 += (unsigned)(short)(unsigned)((unsigned)e0 == garr[i1 & 7u]);
                        w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)((unsigned)e0 | (unsigned)w0);
                        goto L4;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(w0 >> 29) * (m0 * 0x80000000u)), garr[u2 & 7u], (unsigned)(p1 == r0.x)); }
                        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                            r0.x = ((unsigned)x0 - ((unsigned)((int)(unsigned)s1 >= (int)r0.y) & u0));
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)(*q0 < (unsigned)b0) < (int)(unsigned)c1), (*q0 / ((unsigned)(w0 >> 29) | 1u)), (fuel / (6u | 1u))); }
                        }
                    } else {
                        if (u3 == 7u) return (unsigned)(i0 < (unsigned)(signed char)(p1 ^ 0x5fcb7997u));
                    }
                    if ((u2 ? 0xffffffffu : 0xffffffffu)) break;
                } else {
                    if (8u) goto L0;
                    if (0x5949ce1cu) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)(unsigned)l0 > (signed char)0xfbe974adu), (unsigned)(garr[u2 & 7u] && 0xffffffffu), garr[u2 & 7u]); }
                }
            }
        }
        garr[*q0 & 7u] = ((u3 & 0u) & u2);
    }
    switch (u0 & 7u) {
        u0 += ((unsigned)l0 + (unsigned)((short)7u > (signed char)0xbeb2379au));
        do { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                b0 = ((p0 / (0u | 1u)) - u2) != 0u;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, (v0 - (unsigned)d0), (1u & ~((unsigned)c0 ^ (unsigned)(x0 >> 70)))); }
                    do { if (--fuel == 0u) goto done;
                        if ((r0.y * 0xfcfc40cfu)) continue;
                        case 7u: ;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((0x7fffffffu & v0), (r0.x % ((g0 % (i1 | 1u)) | 1u)), a0[i0 & 3u]); }
                    } while (i0++ < 6u && (unsigned)(signed char)(unsigned)((unsigned)e0 < (unsigned)((int)5u >= (int)v0)));
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((short)0x7fffffffu > (signed char)(unsigned)d0) || ((unsigned)l0 & (unsigned)h0)) & 255u);
                    if (budget != 0u) { budget -= 1u; u2 = fn0((r0.x >> (i0 & 31u)), (unsigned)((short)0u > (signed char)p2), (g0 | (unsigned)s0)); }
                    if ((unsigned)(p0 && i1)) break;
                    s0 = (int)0x7fffffffu;
                } while (i2++ < 6u && (u2 * (unsigned)c1));
            }
            u2 += (unsigned)((unsigned)e0 == (unsigned)s0);
            case 6u: ;
            switch (((unsigned)b0 ? (unsigned)f0 : 0x3a8f620u) & 7u) {
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)b0), (0x8b9c2fafu - g1), 0x2809479fu); }
                w0 = w0 * 6364136223846793005ull + (unsigned)(fuel < (unsigned)(p2 || (unsigned)((int)0xffffffffu < (int)(unsigned)s0)));
                if (((unsigned)((int)(unsigned)c1 >= (int)(unsigned)c1) / (a0[u1 & 3u] | 1u))) goto L2;
            }
            s0 = (int)((unsigned)(p2 || 9u) ^ (2u ^ 0x70324a5bu));
        } while (i0++ < 6u && *q0);
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((u0 & i1)) continue;
            while (i1++ < 6u && (unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(((unsigned)((unsigned)(w0 >> 29) == (unsigned)(i1 && p2)) ^ m0) & 255u);
                if (a0[i0 & 3u]) goto L4;
            }
            if (u0) {
                while (i1++ < 2u && (unsigned)(signed char)((unsigned)h0 << ((unsigned)c0 & 31u))) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)(unsigned)f0 < (int)(unsigned)b0)) continue;
                    if (((unsigned)f0 ^ (*q0 % (0xe9a750a2u | 1u)))) goto done;
                    case 4u: ;
                    g1 += ((m0 * 0x19c30c29u) ^ (unsigned)((int)((unsigned)e0 ^ (unsigned)e0) >= (int)i0));
                    u2 = u2 * 0x9e3779b1u + (garr[u2 & 7u] | (unsigned)l0);
                }
                switch (0x7780f4c9u & 7u) {
                    case 0u: ;
                    garr[((unsigned)b0 >> (7u & 31u)) & 7u] = p1;
                    e0 = e0 * 0.5L + (long double)((((garr[i1 & 7u] * (0xffffffffu + (unsigned)f0)) * 0x10000u) % (u3 | 1u)) & 1023u);
                    u1 ^= (4u | (unsigned)((int)a0[u1 & 3u] >= (int)(((unsigned)x0 & (unsigned)h1) | (unsigned)l0)));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(v0 << (a0[u1 & 3u] & 31u)), (garr[i1 & 7u] % (0xffffffffu | 1u)), (unsigned)c0); }
            } else {
                default: ;
                if ((0x7fffffffu ^ (unsigned)(x0 >> 70))) break;
            }
        }
        while ((m0 << (u1 & 31u))) { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)!((unsigned)d0 << ((unsigned)(short)(0x7fffffffu * (unsigned)d0) & 31u));
            break;
            s0 = (int)(6u / ((unsigned)h1 | 1u));
            if (((unsigned)s0 | (unsigned)((short)(unsigned)w0 > (signed char)0x8785293au))) continue;
            continue; (void)(r0.x);
            goto L1;
        }
        g1 += ((unsigned)((int)*q0 < (int)((unsigned)f0 >> (0xa778df3cu & 31u))) ? (unsigned)s1 : garr[i1 & 7u]);
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(i2, (unsigned)((unsigned)c0 == g1), -((unsigned)d0 << ((unsigned)(w0 >> 29) & 31u))); }
    u3 = ((unsigned)((int)m0 >= (int)((unsigned)c0 % (0x80000000u | 1u))) << ((5u - 0xdea36f1bu) & 31u));
    h1 = (unsigned short)(h1 + ((g0 % (u0 | 1u)) << ((0x80000000u | i1) & 31u)));
    if ((unsigned)((short)(unsigned)h1 > (signed char)((unsigned)h1 >> ((unsigned)d0 & 31u)))) {
        garr[(unsigned)((int)g1 < (int)0xf692e153u) & 7u] = fuel;
        { unsigned t4; double z4; if ((((0x80000000u >> (0xd055702au & 31u)) ^ g0)) & 1u) { t4 = 0x7fffffffu; z4 = (double)((((unsigned)((unsigned)l0 || u1) << (0xc4f8e96au & 31u))) & 255u); } if ((((0x80000000u >> (0xd055702au & 31u)) ^ g0)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
            switch (6u & 7u) {
                if (u3 == 7u) return (-(unsigned)(fuel == ((unsigned)((unsigned)(w0 >> 29) < (unsigned)(x0 >> 70)) | (unsigned)(x0 >> 70))) << (i2 & 31u));
                if (budget != 0u) { budget -= 1u; u2 = fn0(u2, (unsigned)(0x10000u < (unsigned)(unsigned char)(u3 << (*q0 & 31u))), (unsigned)((int)(unsigned)c0 < (int)(unsigned)(0xa23ec6e7u == p0))); }
                s0 = (int)((i0 - (unsigned)e0) ? i0 : 2u);
                c1 = (signed char)(*mp ^ i1);
            }
        }
        m0 ^= (i2 | ((unsigned)(short)(garr[u2 & 7u] >> (i1 & 31u)) >> ((unsigned)s1 & 31u)));
        if (0xca209691u) goto L1;
    } else {
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)(u0 < garr[i1 & 7u]);
        }
        if (((0x10000u + r0.x) % ((unsigned)h0 | 1u))) {
            if (budget != 0u) { budget -= 1u; u2 = fn0(((v0 >> (a0[i0 & 3u] & 31u)) & 8u), (unsigned)(signed char)(0x6179aaddu / (u2 | 1u)), (unsigned)(short)(unsigned)((int)8u < (int)a0[i0 & 3u])); }
            if (((unsigned)(3u && g0) << (8u & 31u))) {
                if (u2) goto L4;
                *mp = (0x3cf1050fu * (0x7fffffffu & (unsigned)s0));
                if ((unsigned)((short)p2 > (signed char)garr[i1 & 7u])) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(r0.x == (unsigned)b0), (i0 - r0.x), (unsigned)((short)((unsigned)s0 * 0xffffffffu) > (signed char)1u)); }
                    g1 += (unsigned)h0;
                    if ((unsigned)(g0 == 0x10000u)) {
                        r0.x = (unsigned)((int)i2 >= (int)0x61381da7u);
                        r0.y ^= (unsigned)((unsigned)((int)(unsigned)(short)(u0 | 0xffffffffu) < (int)4u) == ((unsigned)c1 ^ (unsigned)w0));
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)w0, (0xa0aff6c3u ? a0[i0 & 3u] : *mp), (u2 % ((unsigned)s0 | 1u))); }
                        g1 += ((unsigned)c1 % (garr[i1 & 7u] | 1u));
                        r0.y ^= (*q0 / ((unsigned)((fuel | (4u & (unsigned)d0)) && 0x7fffffffu) | 1u));
                    } else {
                        f0 = f0 * 0.5f + (float)((g1 << (fuel & 31u)) & 255u);
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)d0, garr[i1 & 7u], (0xcdf85ac8u - (0x7fffffffu - 0xfe88ce6au))); }
                    }
                    if ((unsigned)(unsigned char)(r0.y % (9u | 1u))) goto L3;
                    if (fuel < 8u) return (unsigned)((int)((unsigned)b0 % (u2 | 1u)) < (int)fuel);
                    if (u1) {
                        w0 ^= (unsigned long long)(unsigned)c0 << ((unsigned)((u3 * (unsigned)c1) && (r0.y - (unsigned)(4u == (unsigned)w0))) & 63u);
                        w0 ^= (unsigned long long)(4u % ((unsigned)s1 | 1u)) << ((*q0 - (unsigned)(w0 >> 29)) & 63u);
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(short)(p2 + 0x10000u) < (int)a0[u1 & 3u]));
                        while (i0++ < 3u && ((*q0 / (0u | 1u)) & m0)) { if (--fuel == 0u) goto done;
                            if (((unsigned)e0 & fuel)) break;
                            u3 = u3 * 0x9e3779b1u + (unsigned)(a0[i0 & 3u] || *q0);
                            *q0 += 8u;
                            r0.y ^= ((unsigned)((int)g0 < (int)(unsigned)d0) | p1);
                            c1 = (signed char)((unsigned)(u1 && (p1 / (p2 | 1u))) >> ((unsigned)((short)(unsigned)w0 > (signed char)9u) & 31u));
                        }
                    }
                } else {
                    if ((unsigned)(unsigned char)(m0 >> (0x80000000u & 31u))) goto L0;
                    if ((unsigned)((unsigned)((int)a0[u1 & 3u] >= (int)0x4ba0441u) < 4u)) {
                        v0 = (unsigned)(0x80000000u == 4u);
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(x0 >> 70), (unsigned)!((unsigned)h1 / (((unsigned)c0 - (unsigned)w0) | 1u)), (unsigned)!(unsigned)((int)5u < (int)v0)); }
                        switch ((unsigned)((int)a0[i0 & 3u] >= (int)(*q0 | 0x10000u)) & 7u) {
                            if (budget != 0u) { budget -= 1u; u2 = fn0(-(u3 / (u1 | 1u)), *q0, (unsigned)((g0 / ((unsigned)s0 | 1u)) < garr[u2 & 7u])); }
                            case 7u: ;
                            if (budget != 0u) { budget -= 1u; u0 = fn0(0xffffffffu, (unsigned)((int)(unsigned)(0xffffffffu < 0xffffffffu) >= (int)(unsigned)h0), r0.x); }
                            *q0 = (unsigned)((short)i2 > (signed char)0x80000000u);
                        }
                        r0.y ^= (i0 | (unsigned)((short)i0 > (signed char)((unsigned)c1 * (unsigned)(unsigned char)(a0[i0 & 3u] + p2))));
                        if (g1) goto L1;
                        g1 += (unsigned)((unsigned)((unsigned)(x0 >> 70) && 0xffffffffu) && (p2 * (unsigned)((int)(unsigned)h0 < (int)0u)));
                    } else {
                        if ((unsigned)((short)0xd64331f8u > (signed char)((unsigned)d0 * i1))) goto L3;
                        if (0x10000u) goto L4;
                        e0 = e0 * 0.5L + (long double)((unsigned)((short)(0u & a0[i0 & 3u]) > (signed char)(a0[u1 & 3u] - (unsigned)x0)) & 1023u);
                        u0 ^= (p0 << ((((unsigned)s0 + i0) >> (0x8b548aa4u & 31u)) & 31u));
                    }
                    while (i0++ < 3u && p2) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn0((i0 ? (unsigned)w0 : (unsigned)x0), (unsigned)((short)0xb7a650eeu > (signed char)0xffffffffu), a0[i0 & 3u]); }
                        h1 = (unsigned short)(h1 + (5u / ((unsigned)(v0 < 0xffffffffu) | 1u)));
                        w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)(a0[i0 & 3u] == ~(unsigned)(2u && 0x60b94b49u)) < (int)~(unsigned)(i1 && fuel));
                        f0 = f0 * 0.5f + (float)(((unsigned)(signed char)(unsigned)((int)((unsigned)((int)0x38219575u < (int)4u) % (*mp | 1u)) < (int)1u) << ((unsigned)s0 & 31u)) & 255u);
                        if ((unsigned)(short)(unsigned)(3u || (0x10000u << (g0 & 31u)))) continue;
                        while (i1++ < 2u && (unsigned)((int)(unsigned)f0 >= (int)((unsigned)s1 + 4u))) { if (--fuel == 0u) goto done;
                            if (2u) break;
                            w0 ^= (unsigned long long)0xffffffffu << ((g0 - (unsigned)((unsigned)((int)*mp >= (int)3u) < (unsigned)x0)) & 63u);
                            continue; (void)(((unsigned)h0 % ((unsigned)(u1 == u0) | 1u)));
                            w0 ^= (unsigned long long)((unsigned)l0 - a0[u1 & 3u]) << ((unsigned)(m0 == (unsigned)(unsigned char)(0xae426017u + a0[i0 & 3u])) & 63u);
                            *q0 += (((unsigned)s1 | (unsigned)((short)(unsigned)!(3u * (unsigned)l0) > (signed char)(unsigned)b0)) + (unsigned)w0);
                            if (budget != 0u) { budget -= 1u; u2 = fn0((0xd7dcc37cu ? 0x78db4996u : (unsigned)b0), 7u, u2); }
                        }
                    }
                }
            } else {
                switch ((unsigned)((int)0x7fffffffu >= (int)0x10000u) & 7u) {
                    if (9u) {
                        a0[0x10000u & 3u] = ((unsigned)(short)(unsigned)(p2 == (r0.y | ((unsigned)(x0 >> 70) >> (0x4d57667cu & 31u)))) << (p0 & 31u));
                    }
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((g1 ^ (unsigned)w0) && 0x4d23cc8du) && r0.x) & 255u);
                    { unsigned t5; double z5; if (((((unsigned)h0 << (g0 & 31u)) % (v0 | 1u))) & 1u) { t5 = (u2 ^ (unsigned)(w0 >> 29)); z5 = (double)(((unsigned)((int)(unsigned)c0 < (int)0xcb68fb58u)) & 255u); } if (((((unsigned)h0 << (g0 & 31u)) % (v0 | 1u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                        case 0u: ;
                        switch (i0 & 7u) {
                            x0 = x0 * 0x100000001b3ull + ((unsigned)b0 | (unsigned)((short)(0x83ca4e32u & i0) > (signed char)(unsigned)(u1 == (unsigned)w0)));
                            if (budget != 0u) { budget -= 1u; u1 = fn0((0xf1c6d9e6u * *q0), ~(((unsigned)l0 / ((unsigned)d0 | 1u)) & i2), (unsigned)(w0 >> 29)); }
                            if (budget != 0u) { budget -= 1u; u0 = fn0((garr[u2 & 7u] - -(unsigned)((int)(unsigned)c0 < (int)g0)), ~((unsigned)c0 % ((unsigned)((int)(unsigned)s0 < (int)p2) | 1u)), (unsigned)((int)m0 < (int)(unsigned)e0)); }
                            case 5u: ;
                            case 1u: ;
                            case 6u: ;
                        }
                        for (;;) { if (--fuel == 0u) goto done;
                            m0 ^= (garr[u2 & 7u] ^ p2);
                            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)c0 >= (int)a0[i0 & 3u]), (unsigned)(i0 || (unsigned)w0), (9u / ((unsigned)(u0 && 8u) | 1u))); }
                        }
                        *mp = ((g0 ? 0xffffffffu : (unsigned)((short)g0 > (signed char)u1)) / (g0 | 1u));
                        switch (2u & 7u) {
                            h1 = (unsigned short)(h1 + (((unsigned)l0 / ((unsigned)(x0 >> 70) | 1u)) | 0x7fffffffu));
                            h1 = (unsigned short)(h1 + (unsigned)((short)g0 > (signed char)((*q0 >> (0xffffffffu & 31u)) % (r0.x | 1u))));
                        }
                    }
                    d0 = d0 * 0.5 + (double)(((unsigned)e0 << (9u & 31u)) & 1023u);
                    w0 ^= (unsigned long long)~((unsigned)b0 + (unsigned)(x0 >> 70)) << ((unsigned)((int)((garr[i1 & 7u] | 1u) >> (a0[u1 & 3u] & 31u)) >= (int)(unsigned)l0) & 63u);
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(((g1 + r0.x) | (unsigned)b0), (unsigned)((unsigned)f0 < 0xf5ecb19u), 0u); }
                i2 = (unsigned)e0 & 15u;
            }
            if ((unsigned)(short)((unsigned)(*mp == a0[u1 & 3u]) ^ 0x10000u)) {
                u3 = (p0 + 0x64f576f3u);
            }
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)h1, (unsigned)(unsigned char)(unsigned)((short)(unsigned)s1 > (signed char)(unsigned)s1), fuel); }
                m0 ^= (unsigned)((int)(unsigned)!(unsigned)((unsigned)(x0 >> 70) && (unsigned)c0) < (int)(unsigned)((short)r0.y > (signed char)6u));
                if (((unsigned)e0 * (unsigned)b0)) goto L2;
            }
        }
    }
    d0 = d0 * 0.5 + (double)(((unsigned)h0 * (2u / (r0.y | 1u))) & 1023u);
    if ((unsigned)(((unsigned)e0 | (unsigned)c0) || 2u)) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)2u > (signed char)(unsigned)((int)g0 >= (int)0x836745f7u)), (unsigned)(9u == (unsigned)h1), (p2 ? (unsigned)e0 : 0x80000000u)); }
        switch (((unsigned)d0 * (fuel ^ r0.x)) & 7u) {
            goto L2;
            if ((unsigned)((int)a0[i0 & 3u] >= (int)(u3 & 0xe16ffd9eu))) goto L2;
            if (2u) {
                if (~(0x3a88fa89u / (fuel | 1u))) goto L4;
                while (i0++ < 4u && (unsigned)((int)(i2 / ((unsigned)(x0 >> 70) | 1u)) >= (int)u3)) { if (--fuel == 0u) goto done;
                    for (;;) { if (--fuel == 0u) goto done;
                        case 2u: ;
                        while (i2++ < 2u && 0x7fffffffu) { if (--fuel == 0u) goto done;
                            *mp = (p1 ^ (unsigned)((short)2u > (signed char)*mp));
                            case 6u: ;
                        }
                        v0 = 0xeb5e2c77u;
                        r0.x = ((unsigned)((short)(unsigned)w0 > (signed char)0x224d6969u) >> ((unsigned)!(0x80000000u << (u2 & 31u)) & 31u));
                        case 5u: ;
                        s0 = (int)((unsigned)d0 - (unsigned)((a0[i0 & 3u] << ((0u >> (0x7fffffffu & 31u)) & 31u)) || 0x7fffffffu));
                    }
                    u2 ^= (2u * (unsigned)f0);
                    if (u2) goto L1;
                    v0 = (unsigned)(g1 == (0x7fffffffu - u3));
                    *mp = ((unsigned)f0 >> (0xffffffffu & 31u));
                }
                for (;;) { if (--fuel == 0u) goto done;
                    if ((p1 >> (a0[u1 & 3u] & 31u))) goto L0;
                    while (i1++ < 3u && 0x10000u) { if (--fuel == 0u) goto done;
                        h0 = (short)(unsigned)b0;
                    }
                    if ((m0 << (9u & 31u))) {
                        u1 = u1 * 0x9e3779b1u + (0x123250e8u + (unsigned)(4u || 0xffffffffu));
                        garr[~(p1 - 9u) & 7u] = (((unsigned)(v0 == (unsigned)b0) % ((unsigned)b0 | 1u)) + (0xfe3f3fccu ^ g1));
                        h0 = (short)((unsigned)(0x7fffffffu && 0xffffffffu) << (((unsigned)(x0 >> 70) - garr[i1 & 7u]) & 31u));
                    }
                    if ((unsigned)(w0 >> 29)) goto L1;
                    g1 += (0x45380054u % ((unsigned)((int)garr[i1 & 7u] >= (int)0x80000000u) | 1u));
                }
            }
        }
        f0 = f0 * 0.5f + (float)(a0[u1 & 3u] & 255u);
    }
    h0 = (short)(unsigned)h1;
    if (budget != 0u) { budget -= 1u; u3 = fn0(g1, 1u, 0x8b4b96d4u); }
    if (i0) goto L0;
    *mp = fuel;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)(short)((unsigned)f0 >> ((unsigned)l0 & 31u)) >= (int)(unsigned)h0), (p1 | 2u), ((unsigned)l0 | p0)); }
    s0 = (int)(unsigned)(w0 >> 29);
    if (p1) goto L2;
    m0 ^= (*mp ? ((unsigned)!(unsigned)((int)(unsigned)e0 >= (int)(unsigned)e0) >> (a0[i0 & 3u] & 31u)) : 3u);
    goto L0;
    d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(0x5ee0f1b6u + g1) & 1023u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)f0 * ((unsigned)x0 % (a0[u1 & 3u] | 1u))), (unsigned)e0, (unsigned)((int)(unsigned)(0x332a0d39u == m0) >= (int)*mp)); }
    for (;;) { if (--fuel == 0u) goto done;
        if (m0) goto L0;
    }
    u2 = u2 * 0x9e3779b1u + (unsigned)b0;
    if (g1) goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)f0 == (0x80000000u >> ((unsigned)h1 & 31u))), (unsigned)f0, (unsigned)((int)(unsigned)(signed char)(unsigned)((unsigned)e0 || (unsigned)s0) >= (int)(unsigned)w0)); }
    if ((unsigned)!(unsigned)((unsigned)s1 && m0)) {
        c0 = (unsigned char)(unsigned)((short)((0x80000000u + u0) + v0) > (signed char)i1);
        if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)(x0 >> 70) % (((unsigned)d0 | (unsigned)d0) | 1u)), (unsigned)(short)((unsigned)w0 / (garr[u2 & 7u] | 1u)), p1); }
    } else {
        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)x0 || (r0.y * i0));
    }
    L0: if (--fuel == 0u) goto done;
    u1 += -(unsigned)((int)(unsigned)(5u && 9u) >= (int)(0xffffffffu % (u3 | 1u)));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            *q0 = (unsigned)((short)(unsigned)!(p2 * (unsigned)(w0 >> 29)) > (signed char)(unsigned)(unsigned char)(unsigned)((int)(unsigned)c1 >= (int)p2));
            L1: if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if (((u1 / (-(unsigned)(0x80000000u == 3u) | 1u))) & 1u) { t0 = i1; z0 = (double)(((unsigned)((unsigned)((unsigned)e0 && fuel) < u0)) & 255u); } if (((u1 / (-(unsigned)(0x80000000u == 3u) | 1u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                s1 = (int)((unsigned)s1 + i2);
                x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)(short)(0xffffffffu * (-(3u & (unsigned)s0) & m0)) && 0xffffffffu);
                if (((unsigned)((unsigned)h0 < u3) << (7u & 31u))) goto L1;
                d0 = d0 * 0.5 + (double)((unsigned)((unsigned)!(2u / (p0 | 1u)) < (unsigned)((unsigned)((unsigned)d0 && v0) || r0.y)) & 1023u);
            }
            x0 = x0 * 0x100000001b3ull + (unsigned)(garr[i1 & 7u] < ((unsigned)(w0 >> 29) << ((u3 & (garr[u2 & 7u] & (unsigned)f0)) & 31u)));
        }
        continue; (void)((5u >> (g0 & 31u)));
        break; (void)(((unsigned)(0x7cfe0ae7u < (unsigned)c1) / (*mp | 1u)));
        s1 = (int)((unsigned)s1 + ((unsigned)((short)(unsigned)f0 > (signed char)u0) + (unsigned)(8u && a0[i0 & 3u])));
        L2: if (--fuel == 0u) goto done;
        a0[(0x10000u ^ a0[i0 & 3u]) & 3u] = (unsigned)(i2 < (unsigned)(fuel && 0x8d8cd04du));
    }
    goto L4;
    r0.x = 0x52afb7f6u;
    L3: if (--fuel == 0u) goto done;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(v0 + (unsigned)s0), (unsigned)(unsigned char)(unsigned)((int)(unsigned)x0 >= (int)fuel), 0x94aa9c1fu); }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(unsigned char)(unsigned)((unsigned)((unsigned)s1 && (unsigned)s0) < 0xffffffffu), (unsigned)c0, (unsigned)(x0 >> 70)); }
    a0[r0.y & 3u] = (unsigned)((unsigned)!((unsigned)(signed char)((unsigned)(x0 >> 70) | 0xffffffffu) - (0x10000u + u0)) < (unsigned)f0);
    goto L3;
    r0.y ^= ~(unsigned)((int)p0 >= (int)(unsigned)c1);
    goto L0;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (fuel) goto L1;
        if ((0x25be8b4bu - i1)) break;
        switch (u2 & 7u) {
            c0 = (unsigned char)u1;
            f0 = f0 * 0.5f + (float)(((unsigned)((int)1u < (int)0x7fffffffu) + 5u) & 255u);
            u2 ^= (0xd0b434c1u / ((unsigned)h0 | 1u));
            if ((*q0 >> ((0x10000u & fuel) & 31u))) continue;
            goto L0;
            L4: if (--fuel == 0u) goto done;
        }
    }
    if ((u3 >> (((unsigned)s1 | garr[i1 & 7u]) & 31u))) {
        if ((u2 | (unsigned)((unsigned)l0 && (unsigned)c1))) goto L1;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)g1 > (signed char)(unsigned)(garr[i1 & 7u] && 0x7fffffffu)), (0x80000000u + (unsigned)(v0 < p1)), v0); }
            if ((u1 % (a0[u1 & 3u] | 1u))) break;
            if ((unsigned)(garr[u2 & 7u] || 0x7fffffffu)) break;
            c0 = (unsigned char)(unsigned)(unsigned char)((unsigned)e0 * -(u2 + 0x7fffffffu));
            l0 = (long)((unsigned long)l0 + (unsigned)(~(unsigned)((short)(unsigned)!(g0 << ((unsigned)l0 & 31u)) > (signed char)u0) == ((unsigned)c0 | fuel)));
        } while (i0++ < 5u && (unsigned)h0);
        goto L1;
        while (i0++ < 4u && (m0 - (unsigned)x0)) { if (--fuel == 0u) goto done;
            if ((unsigned)!(*mp >> (0xdf170c2u & 31u))) continue;
            if (~((unsigned)((short)(unsigned)h1 > (signed char)i1) >> (0x10000u & 31u))) break;
            f0 = f0 * 0.5f + (float)((a0[u1 & 3u] ? ((u2 | u3) - (unsigned)l0) : (unsigned)(w0 >> 29)) & 255u);
            i0 = 0x80000000u & 15u;
        }
        b0 = (unsigned)(garr[i1 & 7u] && a0[u1 & 3u]) != 0u;
        if ((unsigned)(0u == i2)) {
            goto L2;
            { unsigned t1; double z1; if ((~(0x8485124u * u2)) & 1u) { t1 = i0; z1 = (double)(((unsigned)((int)0x7fffffffu >= (int)(unsigned)h0)) & 255u); } if ((~(0x8485124u * u2)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(garr[u2 & 7u] && garr[u2 & 7u]), p2, -((unsigned)h0 ^ ((unsigned)s1 << (i2 & 31u)))); }
                e0 = e0 * 0.5L + (long double)(((unsigned)(signed char)(0x10000u | (unsigned)(unsigned char)(garr[i1 & 7u] - ((unsigned)x0 % (0x13973464u | 1u)))) + 0xffffffffu) & 1023u);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn1(r0.y, (unsigned)((short)fuel > (signed char)(unsigned)s1), ((unsigned)x0 % (1u | 1u))); }
            if ((unsigned)((short)(unsigned)c0 > (signed char)g1)) goto L4;
            if (fuel < 8u) return u0;
            if ((0xffffffffu & 5u)) goto L1;
        }
    }
    m0 ^= (unsigned)((int)u3 >= (int)6u);
    q0 = &garr[((fuel / ((unsigned)c0 | 1u)) ^ 0x7fffffffu) & 7u];
    if (budget != 0u) { budget -= 1u; u3 = fn0(p0, (unsigned)(short)(unsigned)(garr[i1 & 7u] == (unsigned)(w0 >> 29)), (garr[u2 & 7u] - (unsigned)s0)); }
    if (u3 == 7u) return (unsigned)(short)((g1 >> (p1 & 31u)) + 1u);
    goto L4;
    if ((unsigned)((unsigned)l0 || (unsigned)s0)) goto L2;
    q0 = &garr[v0 & 7u];
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(short)(unsigned)((int)1u < (int)((unsigned)h0 - (unsigned)s0))) break;
        if (v0) break;
        *mp = (~((unsigned)(x0 >> 70) + ((unsigned)h0 & 0x555a99eu)) & fuel);
    } while (i0++ < 4u && 1u);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (0x7fffffffu & 7u) {
            if (0xffffffffu) continue;
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(v0 | u2) << ((unsigned)!(((unsigned)c1 ^ ~(0x63948c4u & a0[u1 & 3u])) * a0[u1 & 3u]) & 63u);
                if ((0x33c1b4ceu >> (0x87135117u & 31u))) continue;
                *mp = ((unsigned)x0 & *q0);
            } while (i1++ < 2u && (unsigned)(7u || *q0));
            u3 = v0;
            c1 = (signed char)((unsigned)!(unsigned)((short)p2 > (signed char)g0) | u0);
        }
        i2 = (unsigned)((int)(unsigned)h0 >= (int)(unsigned)h0) & 15u;
        while (i1++ < 7u && (u2 * u2)) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)((unsigned)l0 >> (*q0 & 31u)) >= (int)(unsigned)x0)) continue;
            if (g1) continue;
        }
        u3 ^= (unsigned)((0xa2f619f2u | *q0) || ((unsigned)(i2 == 0x80000000u) >> (i2 & 31u)));
        if ((unsigned)l0) goto L2;
        if (((unsigned)((unsigned)b0 < r0.y) >> (p0 & 31u))) {
            for (;;) { if (--fuel == 0u) goto done;
                if ((((unsigned)h0 << (r0.x & 31u)) >> ((unsigned)(x0 >> 70) & 31u))) goto L2;
            }
            r0.x = (i0 - (unsigned)((int)0x782f748au < (int)(unsigned)s0));
            g0 = ((unsigned)f0 + ((unsigned)(x0 >> 70) ? i0 : 0x80000000u));
            if (u3) break;
        } else {
            s0 = (int)(unsigned)((short)(u1 ? (v0 | u3) : u1) > (signed char)garr[i1 & 7u]);
            s0 = (int)(unsigned)((unsigned)s1 < (unsigned)(0x534e7d4du && 0x50884a68u));
        }
    }
    { unsigned t0; double z0; if ((((unsigned)(w0 >> 29) - a0[u1 & 3u])) & 1u) { t0 = 0x9fee9a85u; z0 = (double)(((unsigned)((unsigned)(x0 >> 70) || -(i1 * 0x80000000u))) & 255u); } if ((((unsigned)(w0 >> 29) - a0[u1 & 3u])) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        r0.x = (garr[i1 & 7u] ^ (unsigned)s1);
        if (r0.y) goto L4;
        u3 ^= (0xa180480bu * (unsigned)(x0 >> 70));
        if ((i1 | (unsigned)(a0[u1 & 3u] || u3))) goto L0;
        c1 = (signed char)((unsigned)((unsigned)((int)(unsigned)(w0 >> 29) >= (int)p2) || 0xffffffffu) / ((unsigned)((int)0x74689bf6u < (int)g0) | 1u));
        i0 = (unsigned)((int)(unsigned)f0 < (int)0x7fffffffu) & 15u;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((3u - (unsigned)h0), ((unsigned)s1 / ((unsigned)((unsigned)s0 || (unsigned)c1) | 1u)), (u3 << (garr[u2 & 7u] & 31u))); }
    if (-(unsigned)((int)p1 < (int)(unsigned)e0)) goto L4;
    l0 = (long)((unsigned long)l0 + (unsigned)!(0xffffffffu | (unsigned)((unsigned)e0 == p1)));
    if ((unsigned)((int)0x10000u >= (int)(unsigned)b0)) goto L0;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn2(p1, ((i2 / (0xa163d8b9u | 1u)) << ((unsigned)d0 & 31u)), ((unsigned)((short)i2 > (signed char)i1) | 0x10000u)); }
        d0 = d0 * 0.5 + (double)((unsigned)(short)(0x80000000u - r0.y) & 1023u);
        u2 = (p0 ? (unsigned)w0 : 0x10000u);
        L0: if (--fuel == 0u) goto done;
        s0 = (int)((unsigned)((unsigned)h0 == 0xbc08ff7du) | 2u);
        s0 = (int)((unsigned)s1 ^ u1);
    } while (i0++ < 7u && (unsigned)(u0 && (unsigned)(x0 >> 70)));
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(short)(unsigned)((short)(unsigned)w0 > (signed char)(i2 ^ i1))) {
            if (((unsigned)h0 ? 0x2c3ee29du : (unsigned)c1)) goto L1;
            if (i2) break;
            *q0 = (unsigned)(((r0.y * 0x842dbe9du) << (fuel & 31u)) || garr[u2 & 7u]);
        }
    } while (i0++ < 7u && ((unsigned)d0 % (0xbfefc5b0u | 1u)));
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)s1 & 0x80000000u), m0, (0xa73a5cdfu ? i0 : (unsigned)(w0 >> 29))); }
    }
    switch (-(fuel ? (unsigned)(x0 >> 70) : (unsigned)d0) & 7u) {
        if ((i0 * fuel)) goto L2;
        e0 = e0 * 0.5L + (long double)(0x4bae07bau & 1023u);
        case 2u: ;
        s1 = (int)((unsigned)s1 + (unsigned)!(unsigned)((unsigned)x0 < *mp));
        h0 = (short)(unsigned)((unsigned)((int)(unsigned)s1 >= (int)r0.y) && ((unsigned)d0 / ((unsigned)b0 | 1u)));
        u0 += (unsigned)((unsigned)(0xffffffffu < -(*mp >> ((0xffffffffu | (unsigned)e0) & 31u))) == u3);
    }
    if (v0) goto done;
    if ((unsigned)d0) goto L4;
    if (budget != 0u) { budget -= 1u; u3 = fn0((0x6c2988f2u / (p2 | 1u)), (v0 & (*mp * 0x5d14a222u)), (unsigned)h1); }
    goto done;
    r0.x = (unsigned)e0;
    if (*mp) {
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)(unsigned)(a0[i0 & 3u] || *mp)) {
                if ((unsigned)b0) break;
                r0.y ^= u1;
                s0 = (int)(1u + (unsigned)((int)(*q0 - (unsigned)h1) < (int)(unsigned)x0));
                w0 = w0 * 6364136223846793005ull + ((garr[u2 & 7u] ? i1 : ((unsigned)d0 & a0[i0 & 3u])) | u3);
            } else {
                break; (void)((unsigned)(u3 && garr[u2 & 7u]));
                if (p1) {
                    switch (((m0 * 0xffffffffu) / (i0 | 1u)) & 7u) {
                        case 5u: ;
                        l0 = (long)((unsigned long)l0 + ((unsigned)w0 * (unsigned)d0));
                        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(p1 == -(0x75366740u ^ 0x10000u)), (unsigned)(0x10000u || 2u), 2u); }
                        default: ;
                    }
                    if (i1) break;
                    do { if (--fuel == 0u) goto done;
                        goto L2;
                        h0 = (short)(unsigned)(g1 || (4u % ((unsigned)(((unsigned)f0 >> (r0.y & 31u)) || (unsigned)c0) | 1u)));
                        { unsigned t1; double z1; if (((unsigned)(unsigned char)(u3 | ((unsigned)e0 | 0x80000000u))) & 1u) { t1 = (unsigned)((int)0x10000u < (int)(unsigned)(short)(7u | 0xc1f98aa1u)); z1 = (double)(((unsigned)((int)0x7fffffffu >= (int)(unsigned)((int)(unsigned)b0 >= (int)v0))) & 255u); } if (((unsigned)(unsigned char)(u3 | ((unsigned)e0 | 0x80000000u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                            if (0x80000000u) break;
                            if ((unsigned)((int)0xe506d709u < (int)(0x7fffffffu % (*mp | 1u)))) break;
                            u3 ^= (unsigned)h0;
                            L1: if (--fuel == 0u) goto done;
                        }
                    } while (i1++ < 3u && garr[i1 & 7u]);
                    q0 = &garr[(u0 >> (((unsigned)((int)m0 < (int)v0) | 0x7fffffffu) & 31u)) & 7u];
                    *mp = r0.x;
                    L2: if (--fuel == 0u) goto done;
                }
            }
            while (i1++ < 6u && ((unsigned)(0x1d88e8aeu < *q0) << ((unsigned)(w0 >> 29) & 31u))) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)d0 == i0)) continue;
                *q0 = (unsigned)(7u && ((u1 & (unsigned)h1) & garr[i1 & 7u]));
            }
        } while (i0++ < 7u && 0xe26b4d21u);
    }
    if (p0) goto L2;
    if ((unsigned)(u3 && (unsigned)(x0 >> 70))) {
        if (fuel) goto L0;
        L3: if (--fuel == 0u) goto done;
        u2 = 0x10000u;
        u2 = (unsigned)(0xffffffffu || r0.y);
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            c1 = (signed char)(((unsigned)((unsigned)c1 == 8u) & a0[u1 & 3u]) - i2);
            if (fuel < 8u) return (unsigned)((int)(unsigned)((int)((unsigned)s1 % ((unsigned)d0 | 1u)) >= (int)u3) < (int)(garr[i1 & 7u] % ((unsigned)e0 | 1u)));
            goto L2;
            r0.x = (0x9fdc0fd4u + 0x80000000u);
        } while (i1++ < 5u && fuel);
    }
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1(i1, (0x7fffffffu * (unsigned)e0), (unsigned)((u3 + 3u) < (unsigned)l0)); }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(short)(garr[u2 & 7u] >> ((2u * (unsigned)(w0 >> 29)) & 31u))) continue;
                c0 = (unsigned char)-(a0[u1 & 3u] % (0x7fffffffu | 1u));
            } while (i2++ < 6u && ((unsigned)h1 % (g1 | 1u)));
        } while (i1++ < 4u && ((unsigned)f0 % ((unsigned)((int)(unsigned)c1 < (int)(unsigned)(w0 >> 29)) | 1u)));
        u0 = ((unsigned)(u0 == (unsigned)l0) ^ (unsigned)(p0 == 0x854e157fu));
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= g0;
            a0[m0 & 3u] = i1;
        }
    } while (i0++ < 4u && g1);
    if (budget != 0u) { budget -= 1u; u2 = fn0(0xd099dc80u, (unsigned)c1, (0xffffffffu + u3)); }
    goto done;
    goto L2;
    a0[(unsigned)((int)g1 < (int)0x10000u) & 3u] = (unsigned)((4u / ((6u * (unsigned)w0) | 1u)) || ((unsigned)c0 >> (0u & 31u)));
    L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u3 = fn3(~(0x80000000u + (unsigned)(5u == 0x1f03f6ecu)), (p1 / ((unsigned)h1 | 1u)), (unsigned)!(v0 & (unsigned)(garr[u2 & 7u] || 5u))); }
    if (budget != 0u) { budget -= 1u; u0 = fn3((fuel * (unsigned)h0), (unsigned)(x0 >> 70), *q0); }
    d0 = d0 * 0.5 + (double)(a0[i0 & 3u] & 1023u);
    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)s0 || m0), (3u ^ 0x80000000u), (*mp & (unsigned)((unsigned)w0 < 6u))); }
    b0 = (unsigned)((int)(unsigned)((int)(unsigned)w0 < (int)u1) < (int)*mp) != 0u;
    if ((unsigned)!(u3 >> (a0[u1 & 3u] & 31u))) goto done;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            v0 = r0.x;
            L0: if (--fuel == 0u) goto done;
            a0[p2 & 3u] = a0[u1 & 3u];
            if ((unsigned)c0) break;
            a0[u0 & 3u] = (p2 ? 0x66ef60c5u : i0);
        }
        i1 = (unsigned)c0 & 15u;
        break; (void)((unsigned)((unsigned)(0x97eb1c98u == 0xa21693aau) && *q0));
    }
    while (i0++ < 7u && (unsigned)((unsigned)((short)(unsigned)h1 > (signed char)i1) || 7u)) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + fuel);
        if (budget != 0u) { budget -= 1u; u3 = fn1(a0[u1 & 3u], *q0, 0u); }
        { unsigned t0; double z0; if ((garr[i1 & 7u]) & 1u) { t0 = ~(6u >> ((garr[u2 & 7u] + a0[i0 & 3u]) & 31u)); z0 = (double)(((unsigned)s1) & 255u); } if ((garr[i1 & 7u]) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)h1 && (unsigned)(x0 >> 70))) break;
                *mp = (unsigned)(short)(unsigned)(((0x502b9070u & u2) / (i2 | 1u)) == r0.y);
            }
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((v0 / (a0[u1 & 3u] | 1u)) < 0xffffffffu)) break;
                e0 = e0 * 0.5L + (long double)((g0 ^ ((fuel ? r0.x : i0) << ((unsigned)d0 & 31u))) & 1023u);
                s0 = (int)((p1 + (unsigned)l0) * (g1 | 0xc155d4d0u));
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = p0;
                    if ((unsigned)f0) goto L4;
                    r0.y ^= (unsigned)((0x7fffffffu ? (unsigned)(w0 >> 29) : 6u) || (i1 - 5u));
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)d0, (v0 * a0[u1 & 3u]), (unsigned)x0); }
            }
            if ((unsigned)h0) {
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(x0 >> 70), ((unsigned)e0 - (9u / (0x1792c922u | 1u))), ((unsigned)l0 | m0)); }
            } else {
                goto done;
                goto L4;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)h1 >= (int)a0[i0 & 3u]), (unsigned)((int)(unsigned)s0 < (int)5u), p2); }
                if (budget != 0u) { budget -= 1u; u1 = fn1((m0 ? 0x80000000u : (unsigned)h1), g1, (unsigned)((int)0x7fffffffu < (int)(unsigned)b0)); }
            }
            s0 = (int)(unsigned)((int)fuel < (int)u0);
            if ((g0 | (unsigned)(u2 < u1))) {
                if ((unsigned)x0) break;
                u3 += ((unsigned)((short)((unsigned)b0 >> ((unsigned)l0 & 31u)) > (signed char)0xd3db1c3eu) % ((0x7fffffffu / (r0.x | 1u)) | 1u));
            } else {
                u0 += (unsigned)(u2 < (unsigned)(g0 == 0x7fffffffu));
                u1 = ((garr[u2 & 7u] ? 0xffffffffu : 0x3f73ef31u) ? (unsigned)h1 : fuel);
                *mp = (unsigned)(0x805a395cu == ((0u / (*mp | 1u)) & 4u));
                L1: if (--fuel == 0u) goto done;
            }
            m0 ^= (unsigned)(r0.x == (*q0 - r0.x));
        }
        switch (~(0x7fffffffu << ((unsigned)d0 & 31u)) & 7u) {
            if (u3 == 7u) return (unsigned)(unsigned char)((unsigned)(*mp && i1) | a0[u1 & 3u]);
            switch (u2 & 7u) {
                do { if (--fuel == 0u) goto done;
                    r0.x = ((unsigned)x0 ? fuel : u2);
                    while (i2++ < 5u && 1u) { if (--fuel == 0u) goto done;
                        L2: if (--fuel == 0u) goto done;
                        s0 = (int)(unsigned)((short)((0xffffffffu - 0x80000000u) * (unsigned)d0) > (signed char)u1);
                        L3: if (--fuel == 0u) goto done;
                        m0 ^= i2;
                    }
                    w0 = w0 * 6364136223846793005ull + (unsigned)s1;
                    if (u3 == 7u) return (p2 % ((unsigned)l0 | 1u));
                } while (i1++ < 4u && 7u);
            }
            if ((unsigned)((int)(unsigned)s0 < (int)(unsigned)((int)r0.y < (int)(unsigned)d0))) continue;
            r0.y ^= (p1 ^ (unsigned)((int)(unsigned)h1 < (int)0x6bfa85b2u));
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(5u == 0x10000u)) break;
                if (budget != 0u) { budget -= 1u; u1 = fn0(~(unsigned)((unsigned)(unsigned char)(i2 % (0x24974c0u | 1u)) || p0), a0[i0 & 3u], g0); }
                L4: if (--fuel == 0u) goto done;
                case 3u: ;
                if (budget != 0u) { budget -= 1u; u1 = fn2((i1 << ((unsigned)(unsigned char)((unsigned)c1 >> (0x7fffffffu & 31u)) & 31u)), (unsigned)((unsigned)(w0 >> 29) == *q0), (i2 >> ((0x5fc9f0dcu >> (i2 & 31u)) & 31u))); }
                do { if (--fuel == 0u) goto done;
                    r0.y ^= ((unsigned)(unsigned char)(0x90f67c74u % (p2 | 1u)) & (0xec0c2359u << (fuel & 31u)));
                    if (((unsigned)s0 * (unsigned)(garr[i1 & 7u] && fuel))) goto L4;
                    switch ((unsigned)((int)6u < (int)p1) & 7u) {
                        while ((unsigned)((int)0x7fffffffu >= (int)(unsigned)(0x795b24b9u < 2u))) { if (--fuel == 0u) goto done;
                            u2 = u2 * 0x9e3779b1u + (unsigned)(2u || ((7u * 0x4c162e61u) % ((r0.y ^ g1) | 1u)));
                            garr[g1 & 7u] = ((unsigned)((0xef72bd3bu + 0x53c0eaa1u) == (0x7fffffffu & u2)) ^ p1);
                            if ((unsigned)d0) continue;
                            s1 = (int)((unsigned)s1 + (unsigned)(0x7fffffffu == (unsigned)!(unsigned)((int)(~(i0 % (i1 | 1u)) / (fuel | 1u)) < (int)p1)));
                            v0 = ((0x14f4e6b7u * 8u) >> (((unsigned)((int)u1 < (int)g0) << (0x7fffffffu & 31u)) & 31u));
                        }
                        case 5u: ;
                    }
                    b0 = (i1 ^ p2) != 0u;
                    if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(0xffffffffu || g1), (unsigned)(0x328dfb96u < (unsigned)(x0 >> 70)), (garr[i1 & 7u] >> (0xe5147325u & 31u))); }
                } while (i2++ < 2u && (1u >> (r0.x & 31u)));
            } while (i1++ < 2u && (i1 * (unsigned)s1));
        }
        while (i1++ < 3u && (unsigned)((int)i2 >= (int)7u)) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)((short)5u > (signed char)a0[u1 & 3u]);
            if (m0) break;
        }
        if (((unsigned)((int)8u < (int)p1) & 0x3ca1c923u)) {
            { unsigned t1; double z1; if ((((unsigned)w0 + (unsigned)((int)0x80000000u >= (int)(unsigned)e0))) & 1u) { t1 = 0x4a8e2d53u; z1 = (double)((~(unsigned)(a0[i0 & 3u] < 0u)) & 255u); } if ((((unsigned)w0 + (unsigned)((int)0x80000000u >= (int)(unsigned)e0))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                if ((garr[u2 & 7u] / ((unsigned)w0 | 1u))) break;
                if (budget != 0u) { budget -= 1u; u1 = fn3(~(unsigned)(*mp < 0x10000u), (unsigned)(short)((unsigned)h0 ? 0xe513c0a5u : (unsigned)f0), ((g1 / (0x80000000u | 1u)) | 0xf2bff2c8u)); }
            }
            if (u1) break;
            m0 ^= (unsigned)((0x87de71bfu * 3u) < (unsigned)w0);
            b0 = (unsigned)(0xffffffffu || ((unsigned)!((unsigned)(w0 >> 29) / (g1 | 1u)) >> (garr[u2 & 7u] & 31u))) != 0u;
            f0 = f0 * 0.5f + (float)(((0x10000u | u2) + (unsigned)((unsigned)(x0 >> 70) == (unsigned)(m0 < (unsigned)f0))) & 255u);
            if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)f0, (unsigned)f0, (0x80000000u / (g1 | 1u))); }
        } else {
            if ((1u + 8u)) {
                s1 = (int)((unsigned)s1 + ((unsigned)(signed char)((unsigned)(w0 >> 29) * (unsigned)(*mp || i2)) - 0xf53073eau));
                q0 = &garr[(unsigned)((int)(*mp ? a0[i0 & 3u] : 0x43922299u) >= (int)((unsigned)c1 | (unsigned)l0)) & 7u];
                if (budget != 0u) { budget -= 1u; u0 = fn2((g0 << ((unsigned)(x0 >> 70) & 31u)), i2, u3); }
            }
            e0 = e0 * 0.5L + (long double)((i0 / (((unsigned)((int)garr[i1 & 7u] < (int)r0.x) % ((0x7b189961u >> ((unsigned)h0 & 31u)) | 1u)) | 1u)) & 1023u);
            break; (void)((unsigned)((short)(unsigned)((int)0x10000u >= (int)(unsigned)e0) > (signed char)g1));
            if ((unsigned)(0x80000000u || 0xce3c9a92u)) break;
        }
    }
    f0 = f0 * 0.5f + (float)(((p2 * ((unsigned)s0 * (g0 % (r0.y | 1u)))) << ((unsigned)b0 & 31u)) & 255u);
    c1 = (signed char)(unsigned)(x0 >> 70);
    if (budget != 0u) { budget -= 1u; u0 = fn0(m0, (0u ^ 0x80000000u), (0x5350b4e7u ? (unsigned)(x0 >> 70) : i0)); }
    l0 = (long)((unsigned long)l0 + (unsigned)(short)(unsigned)(0x80000000u || i2));
    do { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            s0 = (int)((unsigned)!((unsigned)(unsigned char)(unsigned)(0x7fffffffu == (unsigned)c0) | 0xba61ae1eu) & (g0 % (r0.x | 1u)));
            while (i2++ < 6u && -(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)c1)) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return (unsigned)(short)((unsigned)(w0 >> 29) / ((unsigned)(0x5c13eddau && *q0) | 1u));
                if ((unsigned)((unsigned)s1 < (u1 * (unsigned)w0))) break;
                if (0xffffffffu) break;
            }
            if (((unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)b0) * g1)) {
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    a0[(u3 >> (g1 & 31u)) & 3u] = ((0x80000000u % (u2 | 1u)) + u0);
                    c1 = (signed char)(unsigned)((g1 + m0) || (0xee61021u % (0x2e8f7eb6u | 1u)));
                    h1 = (unsigned short)(h1 + p2);
                }
                d0 = d0 * 0.5 + (double)(((unsigned)w0 ^ (unsigned)h1) & 1023u);
            }
        }
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(unsigned char)(unsigned)((int)(0x80000000u - (unsigned)c1) < (int)(unsigned)(x0 >> 70)), (unsigned)(unsigned char)(0x87f1c92u & 0x80000000u), (unsigned)b0); }
            f0 = f0 * 0.5f + (float)((unsigned)((short)u2 > (signed char)(unsigned)((short)a0[i0 & 3u] > (signed char)0u)) & 255u);
            g1 += fuel;
            x0 = x0 * 0x100000001b3ull + (unsigned)!(*q0 * 2u);
        }
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            u1 = u1 * 0x9e3779b1u + 0x1a442393u;
            break; (void)(4u);
        }
        break; (void)((i2 >> ((unsigned)(0x75e0f0b4u == 0x80000000u) & 31u)));
        v0 = u2;
        while ((i2 << ((unsigned)(signed char)(g0 & r0.y) & 31u))) { if (--fuel == 0u) goto done;
            while (i2++ < 6u && (unsigned)(short)(unsigned)(0x7fffffffu || (*q0 - a0[i0 & 3u]))) { if (--fuel == 0u) goto done;
                if ((m0 << ((unsigned)(unsigned char)(p0 - m0) & 31u))) break;
                g0 = 0x10000u;
                if (*mp) break;
                u1 = ((unsigned)h1 * (unsigned)((int)(unsigned)d0 >= (int)v0));
                l0 = (long)((unsigned long)l0 + (unsigned)(short)(unsigned)(6u || (unsigned)((short)0xa915cf06u > (signed char)fuel)));
            }
            if ((unsigned)(a0[u1 & 3u] && (unsigned)(w0 >> 29))) {
                *mp = (7u * (unsigned)(w0 >> 29));
            } else {
                switch ((unsigned)((unsigned)c0 == (unsigned)((int)u1 < (int)0x9fb14e4du)) & 7u) {
                    switch ((unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)s1 < (unsigned)d0) < i0) & 7u) {
                        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)1u > (signed char)(unsigned)l0), p2, (g0 | (unsigned)x0)); }
                        case 1u: ;
                        h0 = (short)((a0[i0 & 3u] % ((unsigned)w0 | 1u)) * fuel);
                        h0 = (short)((2u & (unsigned)b0) % ((unsigned)c1 | 1u));
                    }
                    case 2u: ;
                    if (0x10000u) {
                        goto L1;
                        if ((~(unsigned)((unsigned)s1 == p1) << (0x10000u & 31u))) goto L1;
                    } else {
                        v0 = (unsigned)((u3 | fuel) && (5u >> (1u & 31u)));
                        g1 += ((unsigned)f0 % (r0.y | 1u));
                        case 3u: ;
                    }
                    do { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((unsigned)h0 && (unsigned)(m0 < 0x261eb098u)) < (unsigned)(x0 >> 70)));
                        d0 = d0 * 0.5 + (double)((unsigned)(short)(i0 % ((unsigned)h1 | 1u)) & 1023u);
                        m0 ^= (unsigned)((int)(unsigned)((int)r0.x >= (int)p0) < (int)(unsigned)(garr[i1 & 7u] && i0));
                        l0 = (long)((unsigned long)l0 + (0xffffffffu >> (((unsigned)((int)a0[i0 & 3u] >= (int)0xf77a5c13u) - p1) & 31u)));
                    } while (i2++ < 6u && (unsigned)h1);
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)e0, v0, (unsigned)((short)(unsigned)c1 > (signed char)(unsigned)s1)); }
                    if ((v0 / ((unsigned)l0 | 1u))) break;
                }
            }
            while ((-(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)c0) ^ fuel)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((int)(unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)b0) >= (int)fuel), (unsigned)(signed char)(unsigned)(0x7fffffffu == (i2 - 0x10000u)), (unsigned)s1); }
                { unsigned t2; double z2; if (((unsigned)(short)(unsigned)((int)(garr[i1 & 7u] / (g0 | 1u)) < (int)(unsigned)b0)) & 1u) { t2 = (g1 ^ 0x59840444u); z2 = (double)(((unsigned)((unsigned)(garr[i1 & 7u] < (unsigned)(x0 >> 70)) || 0x3ea90ef1u)) & 255u); } if (((unsigned)(short)(unsigned)((int)(garr[i1 & 7u] / (g0 | 1u)) < (int)(unsigned)b0)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    if ((unsigned)f0) break;
                    f0 = f0 * 0.5f + (float)(((0x49f501beu ^ (unsigned)c1) * (unsigned)((int)p2 >= (int)i1)) & 255u);
                    if (budget != 0u) { budget -= 1u; u3 = fn1(p2, ((unsigned)((unsigned)s1 && garr[u2 & 7u]) << (g1 & 31u)), ((unsigned)((unsigned)w0 < (unsigned)b0) / (0xd77dd6b5u | 1u))); }
                    b0 = ~((unsigned)s1 & ((u3 ^ r0.y) >> ((unsigned)h0 & 31u))) != 0u;
                    u1 ^= ((unsigned)(signed char)(unsigned)(u3 && (0xdcd95b4fu - (unsigned)!(unsigned)((int)(unsigned)h0 >= (int)(unsigned)s0))) | (unsigned)d0);
                }
                w0 ^= (unsigned long long)(unsigned)(short)(unsigned)((short)*mp > (signed char)v0) << ((unsigned)(u1 == ~(~(1u ^ (unsigned)(g0 == 6u)) | (unsigned)(x0 >> 70))) & 63u);
                if (budget != 0u) { budget -= 1u; u0 = fn1(u2, 0xa6178694u, (unsigned)(short)((unsigned)d0 - garr[u2 & 7u])); }
            }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn3(((unsigned)s1 & 7u), (v0 / (*q0 | 1u)), fuel); }
                s0 = (int)((((unsigned)h1 << (a0[u1 & 3u] & 31u)) * 0xffffffffu) | (unsigned)h1);
                if ((unsigned)(short)(unsigned)((int)(i0 + (unsigned)b0) >= (int)a0[u1 & 3u])) break;
                if ((unsigned)(((unsigned)x0 >> (0x80000000u & 31u)) < (unsigned)s0)) break;
                u1 ^= (unsigned)((short)(r0.x * ((unsigned)l0 / (v0 | 1u))) > (signed char)((unsigned)d0 * m0));
            } while (i2++ < 2u && (unsigned)(signed char)((unsigned)(x0 >> 70) ^ 0x708c6911u));
            w0 ^= (unsigned long long)(unsigned)(g1 < 0u) << (((*q0 + (unsigned)((short)garr[i1 & 7u] > (signed char)p2)) + u1) & 63u);
            if ((5u - m0)) break;
        }
    } while (i0++ < 7u && (unsigned)(x0 >> 70));
    if ((unsigned)((0x7fffffffu % (g0 | 1u)) && garr[i1 & 7u])) goto L1;
    goto L4;
    if (u0) goto L4;
    switch (garr[i1 & 7u] & 7u) {
        g1 += ((unsigned)b0 / (p0 | 1u));
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            goto L3;
        }
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t3; double z3; if (((unsigned)(a0[i0 & 3u] == garr[u2 & 7u])) & 1u) { t3 = (g1 ? 0x10000u : 5u); z3 = (double)(((unsigned)((unsigned)(x0 >> 70) && a0[u1 & 3u])) & 255u); } if (((unsigned)(a0[i0 & 3u] == garr[u2 & 7u])) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                garr[(unsigned)(u3 || (unsigned)s0) & 7u] = (unsigned)(*q0 < (unsigned)((short)(unsigned)s1 > (signed char)*q0));
                q0 = &garr[(unsigned)(*mp || u0) & 7u];
                x0 = x0 * 0x100000001b3ull + (unsigned)(m0 || ((unsigned)((int)0x24ac4e68u >= (int)0xd5a440e5u) % ((unsigned)(i2 < (unsigned)s1) | 1u)));
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    garr[(unsigned)((short)(unsigned)s0 > (signed char)m0) & 7u] = (unsigned)((short)(unsigned)((short)(u3 | r0.x) > (signed char)m0) > (signed char)i1);
                    c0 = (unsigned char)(unsigned)((int)(u2 << (*q0 & 31u)) >= (int)(r0.x & (unsigned)b0));
                }
            }
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch (g1 & 7u) {
                    case 3u: ;
                    garr[(unsigned)(garr[i1 & 7u] < 0x4b4e3e1du) & 7u] = (unsigned)(short)(unsigned)((int)a0[i0 & 3u] < (int)u2);
                    break; (void)((unsigned)c1);
                }
                v0 = (unsigned)(((unsigned)s0 ? 4u : (unsigned)h0) < 3u);
                while (i2++ < 3u && (p2 % (p2 | 1u))) { if (--fuel == 0u) goto done;
                    u1 ^= 0x80000000u;
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)p1 > (signed char)garr[u2 & 7u]), ((unsigned)(w0 >> 29) % (~(6u * i2) | 1u)), u1); }
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)u2 < (int)r0.y), (unsigned)s0, (unsigned)((int)(0xb36b00aau | 7u) < (int)(unsigned)h1)); }
                if (budget != 0u) { budget -= 1u; u1 = fn3((0xf71fcd11u ^ (unsigned)(w0 >> 29)), (0xe5fa4c52u - (unsigned)(0xece9011bu == i2)), (unsigned)(0xc5b87cd0u == 0x10000u)); }
            }
            i2 = (unsigned)((int)0xb92f66e1u < (int)(unsigned)(0xffffffffu || (unsigned)c0)) & 15u;
        }
        h0 = (short)(unsigned)!((((unsigned)((int)p0 < (int)(unsigned)c1) ^ 0u) & 0x96bd7f1fu) | u1);
        do { if (--fuel == 0u) goto done;
            r0.x = (unsigned)((int)((unsigned)(0xcbae589bu == i2) << (((unsigned)(x0 >> 70) - 3u) & 31u)) < (int)u1);
            if (fuel < 8u) return (((unsigned)x0 / (m0 | 1u)) % ((unsigned)l0 | 1u));
            if (((unsigned)(w0 >> 29) >> (v0 & 31u))) break;
        } while (i0++ < 3u && ((g0 * (unsigned)(x0 >> 70)) | p0));
    }
    if (u3 == 7u) return (unsigned)h0;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)(g1 && (unsigned)w0) / ((unsigned)d0 | 1u))) {
            if ((0xffffffffu >> (1u & 31u))) {
                s0 = (int)(((unsigned)(g1 || g0) >> (u2 & 31u)) & a0[u1 & 3u]);
                break; (void)((unsigned)(0xffffffffu < a0[u1 & 3u]));
                if ((p2 - u1)) continue;
                { unsigned t4; double z4; if (((unsigned)s0) & 1u) { t4 = (unsigned)(signed char)(unsigned)((int)0x7fffffffu >= (int)(unsigned)((unsigned)w0 == 0x95a5c01cu)); z4 = (double)((garr[i1 & 7u]) & 255u); } if (((unsigned)s0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    u3 = ((0x80000000u % (u1 | 1u)) + u1);
                }
                h0 = (short)(p1 + (fuel & 0u));
            }
            s1 = (int)((unsigned)s1 + (unsigned)(a0[i0 & 3u] == (i0 >> (((unsigned)h0 * 1u) & 31u))));
        }
        *mp = (unsigned)((unsigned)x0 || (unsigned)c1);
        c0 = (unsigned char)8u;
    }
    g0 = (garr[u2 & 7u] % (1u | 1u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 15u, 0xf2204767u, 0x1d0602cau },
        { 4u, 0x78202687u, 0x5983c442u },
        { 9u, 0xb763d49u, 0x91ee0f9au },
        { 4u, 0x979af333u, 0x393c3da1u },
        { 2u, 0xff535ee7u, 0xe635f807u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
