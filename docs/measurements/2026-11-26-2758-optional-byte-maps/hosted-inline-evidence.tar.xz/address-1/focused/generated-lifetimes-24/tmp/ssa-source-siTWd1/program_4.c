// test-ssa-source's program of seed 141000427 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x4e35bfa9u, g1 = 0x516f3c3du;
static unsigned garr[8] = { 0xaaa0de5fu, 0xd3f91238u, 0x39b9635cu, 0x6f3b98ceu, 0x44f23924u, 0x60b0aad7u, 0xd131ab7eu, 0xaffc9e13u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (fuel < 8u) return (9u - 0x10000u);
    c0 = (unsigned char)((unsigned)(signed char)(unsigned)((int)(unsigned)b0 >= (int)0x80000000u) & 0x10000u);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)!(unsigned)((unsigned)x0 < (unsigned)(w0 >> 29))) {
            goto L3;
        }
        garr[((unsigned)(x0 >> 70) & (unsigned)h1) & 7u] = (unsigned)((int)*mp >= (int)0x7fffffffu);
    }
    L0: if (--fuel == 0u) goto done;
    u0 ^= (unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)s0);
    if ((unsigned)((unsigned)((int)(unsigned)c0 >= (int)0x7fffffffu) == g1)) goto L1;
    w0 = w0 * 6364136223846793005ull + (unsigned)f0;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + m0);
        if (i2) continue;
    }
    L1: if (--fuel == 0u) goto done;
    if ((unsigned)(signed char)((unsigned)(short)(p1 + (unsigned)d0) - 0xabbd2281u)) goto L4;
    if ((unsigned)((int)(0xb4895f1du ^ *mp) < (int)*q0)) goto L3;
    v0 = (unsigned)((int)((unsigned)e0 ^ 0x7fffffffu) >= (int)(unsigned)((int)(0xffffffffu + 0x7634f3b0u) < (int)6u));
    switch ((unsigned)((int)u3 < (int)g1) & 7u) {
        *mp = ((unsigned)((short)(unsigned)((short)(i1 | (unsigned)x0) > (signed char)2u) > (signed char)*q0) * (unsigned)x0);
        u2 = u2 * 0x9e3779b1u + (4u | (unsigned)c0);
    }
    { unsigned t0; double z0; if ((v0) & 1u) { t0 = 0x55875e09u; z0 = (double)((u2) & 255u); } if ((v0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        l0 = (long)((unsigned long)l0 + (unsigned)(p2 == p2));
        if ((unsigned)s0) {
            if (fuel < 8u) return (unsigned)(short)(unsigned)(((unsigned)x0 << ((unsigned)w0 & 31u)) || (g1 | (unsigned)(2u || p0)));
            if ((unsigned)(signed char)((unsigned)c1 % (p1 | 1u))) goto done;
            goto L2;
            r0.x = (unsigned)((int)a0[u1 & 3u] >= (int)((unsigned)s1 ^ u3));
        }
        if ((unsigned)!(unsigned)((int)((unsigned)c0 + u0) >= (int)u0)) goto L0;
    }
    switch ((unsigned)((short)i1 > (signed char)(unsigned)!(unsigned)((unsigned)w0 && (unsigned)s0)) & 7u) {
        L2: if (--fuel == 0u) goto done;
        b0 = i2 != 0u;
        s1 = (int)((unsigned)s1 + ((unsigned)(signed char)((unsigned)((int)p2 >= (int)*mp) >> (u0 & 31u)) - (unsigned)x0));
        h1 = (unsigned short)(h1 + (unsigned)(unsigned char)((unsigned)c1 ^ (0x666d5892u ? i0 : i2)));
    }
    if ((unsigned)((unsigned)(signed char)(7u / (i2 | 1u)) == 0u)) goto L0;
    s0 = (int)(unsigned)((int)p1 < (int)m0);
    h0 = (short)(unsigned)(~((v0 / (a0[u1 & 3u] | 1u)) | (unsigned)(x0 >> 70)) || ((unsigned)f0 * (unsigned)s1));
    c1 = (signed char)(*mp >> (0x7fffffffu & 31u));
    if ((unsigned)((int)(unsigned)((int)0xa3683956u >= (int)(unsigned)s1) < (int)i0)) {
        while (((unsigned)c0 ? i2 : (unsigned)s0)) { if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if (((0xe2e46156u + (0x7fffffffu << ((unsigned)x0 & 31u)))) & 1u) { t1 = (unsigned)w0; z1 = (double)(((*mp ^ (u1 >> (8u & 31u)))) & 255u); } if (((0xe2e46156u + (0x7fffffffu << ((unsigned)x0 & 31u)))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                if (((0x7fffffffu % (i2 | 1u)) | r0.y)) {
                    g1 += a0[i0 & 3u];
                    b0 = u3 != 0u;
                }
                L3: if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(((unsigned)!(unsigned)(fuel && u2) ^ g0) & 1023u);
                if ((r0.x - (unsigned)((unsigned)l0 < (unsigned)s1))) break;
            }
            L4: if (--fuel == 0u) goto done;
            *q0 = (fuel | (unsigned)(x0 >> 70));
            if ((2u | garr[u2 & 7u])) break;
        }
        { unsigned t2; double z2; if ((((unsigned)x0 / (p1 | 1u))) & 1u) { t2 = 0x41641966u; z2 = (double)(((7u ^ v0)) & 255u); } if ((((unsigned)x0 / (p1 | 1u))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            if ((((unsigned)h1 / ((unsigned)b0 | 1u)) + 0x80000000u)) goto L3;
            if (g1) goto L3;
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (0xffffffffu) continue;
            }
            do { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)(short)(0u >> (garr[u2 & 7u] & 31u)));
                if ((r0.y | 8u)) continue;
                c1 = (signed char)(unsigned)(0x80000000u || (6u + (unsigned)b0));
                while (i1++ < 2u && (unsigned)x0) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)(((p2 + u3) ^ r0.y) & 1023u);
                    r0.x = ((unsigned)((short)((unsigned)d0 % (0x80000000u | 1u)) > (signed char)(unsigned)s1) % (p1 | 1u));
                    if (0x80000000u) {
                        if ((unsigned)((unsigned)((unsigned)h0 < (unsigned)w0) || g1)) goto L0;
                        g1 += (unsigned)(*q0 == 4u);
                        u0 = (unsigned)(p0 && (unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)((int)0x10000u >= (int)garr[i1 & 7u])));
                        w0 ^= (unsigned long long)(0x10000u | 0u) << ((0x68ad64c3u ^ u1) & 63u);
                        if ((u3 & (0x7fffffffu - (unsigned)s1))) continue;
                        continue; (void)((*q0 % (-(unsigned)(garr[i1 & 7u] || 3u) | 1u)));
                    } else {
                        c0 = (unsigned char)(unsigned)((short)p1 > (signed char)(unsigned)b0);
                    }
                    continue; (void)(((unsigned)h0 / ((unsigned)h1 | 1u)));
                    if ((4u - (0x10000u - i2))) {
                        s1 = (int)((unsigned)s1 + (unsigned)(0xbc207edeu == 0x10000u));
                        if ((unsigned)((int)u3 < (int)(unsigned)((short)fuel > (signed char)v0))) continue;
                        continue; (void)((v0 * 5u));
                        break; (void)((unsigned)((unsigned)e0 || r0.y));
                    } else {
                        *mp = ((unsigned)(i1 < 0xffffffffu) + (unsigned)((int)(r0.x % (g1 | 1u)) >= (int)m0));
                    }
                }
            } while (i0++ < 2u && 0x7fffffffu);
            { unsigned t3; double z3; if (((u1 | p1)) & 1u) { t3 = (unsigned)x0; z3 = (double)(((unsigned)(7u < 0xfe2442a6u)) & 255u); } if (((u1 | p1)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                s1 = (int)((unsigned)s1 + (i1 << ((unsigned)((int)(5u % (m0 | 1u)) >= (int)(i2 >> (garr[u2 & 7u] & 31u))) & 31u)));
                u1 += ((0x6cf283fu * (unsigned)((short)(unsigned)s0 > (signed char)(0x572f1bcbu / (0x80000000u | 1u)))) ^ garr[i1 & 7u]);
                if (((unsigned)s0 * u0)) goto L3;
                r0.y ^= (unsigned)c0;
                for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        i2 = garr[i1 & 7u] & 15u;
                        if (((a0[u1 & 3u] - garr[i1 & 7u]) - p2)) break;
                        break; (void)(((unsigned)w0 % ((0x80000000u << (i2 & 31u)) | 1u)));
                        if ((unsigned)(signed char)(unsigned)((short)0x9385f0b9u > (signed char)(0xa602bbf2u | (unsigned)s0))) break;
                    }
                    g1 += 0x10000u;
                }
            }
            do { if (--fuel == 0u) goto done;
                u0 = ((unsigned)((unsigned)l0 || (unsigned)s1) & 0x3e27a7a4u);
                if (v0) continue;
                if (a0[u1 & 3u]) goto L0;
                if ((0xd4bcac48u * (unsigned)h0)) break;
                do { if (--fuel == 0u) goto done;
                    while (i2++ < 4u && (unsigned)((short)0x7fffffffu > (signed char)i2)) { if (--fuel == 0u) goto done;
                        u1 += 0x64b5deb2u;
                    }
                    q0 = &garr[9u & 7u];
                    r0.y ^= garr[i1 & 7u];
                    break; (void)((unsigned)(2u && ((unsigned)c1 >> (0x89bb7e57u & 31u))));
                } while (i1++ < 4u && (garr[u2 & 7u] / ((unsigned)(signed char)(r0.y - 0x438172a3u) | 1u)));
            } while (i0++ < 6u && ((unsigned)(4u || 0x80000000u) - (unsigned)l0));
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            u3 = u3 * 0x9e3779b1u + -((unsigned)h0 ^ (0x80000000u + (unsigned)e0));
            break; (void)(u1);
            if (a0[i0 & 3u]) break;
            g0 = (unsigned)((unsigned)h1 < 0xc51ba0feu);
            if ((0x10000u ^ u1)) goto L2;
        }
        a0[(unsigned)(unsigned char)(i1 * (unsigned)f0) & 3u] = ((unsigned)((int)fuel >= (int)g0) ^ (i0 / (fuel | 1u)));
        if ((unsigned)((unsigned)h1 && (unsigned)f0)) goto L2;
        d0 = d0 * 0.5 + (double)(((unsigned)w0 ^ ((unsigned)((int)r0.y < (int)m0) & (unsigned)((unsigned)x0 || 0xc3e830b0u))) & 1023u);
    } else {
        if (fuel < 8u) return (((unsigned)(x0 >> 70) & (unsigned)d0) ? i2 : (unsigned)((int)a0[u1 & 3u] >= (int)0x7fffffffu));
    }
    { unsigned t4; double z4; if (((unsigned)((int)r0.x < (int)(unsigned)s0)) & 1u) { t4 = ((unsigned)x0 - (0x10000u << (6u & 31u))); z4 = (double)(((g1 - (unsigned)x0)) & 255u); } if (((unsigned)((int)r0.x < (int)(unsigned)s0)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
        if ((unsigned)(x0 >> 70)) {
            c1 = (signed char)(unsigned)((int)(unsigned)(signed char)(unsigned)(a0[i0 & 3u] < (unsigned)w0) < (int)(unsigned)s0);
            goto L2;
            while (i0++ < 6u && (unsigned)d0) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(w0 >> 29) || (p0 * a0[u1 & 3u])) & 1023u);
                if (r0.x) break;
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    while (i2++ < 2u && garr[u2 & 7u]) { if (--fuel == 0u) goto done;
                        if ((unsigned)((unsigned)h0 && *q0)) break;
                        if (garr[u2 & 7u]) break;
                        f0 = f0 * 0.5f + (float)(((unsigned)(signed char)(-(unsigned)((int)*mp >= (int)0x10000u) + (unsigned)(w0 >> 29)) ^ (unsigned)w0) & 255u);
                    }
                }
            }
            g1 += ((unsigned)b0 << ((unsigned)((short)((unsigned)s0 - a0[u1 & 3u]) > (signed char)(5u | a0[u1 & 3u])) & 31u));
            goto L4;
        }
        goto L0;
        if ((unsigned)h1) goto L4;
    }
    while (i0++ < 2u && ((unsigned)(signed char)(unsigned)(u3 && (unsigned)(x0 >> 70)) << (u2 & 31u))) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((fuel - (unsigned)c0));
            w0 ^= (unsigned long long)(unsigned)((int)g1 >= (int)3u) << ((0xed9e31beu ^ u1) & 63u);
            if ((unsigned)(short)(7u << (6u & 31u))) break;
            do { if (--fuel == 0u) goto done;
                if ((0x94c5a1b2u << ((unsigned)(0xffffffffu == 8u) & 31u))) break;
                s1 = (int)((unsigned)s1 + *q0);
                break; (void)((unsigned)s1);
            } while (i2++ < 7u && (3u | (unsigned)h1));
            break; (void)((unsigned)(signed char)(u2 / (g0 | 1u)));
        }
        { unsigned t5; double z5; if (((unsigned)(unsigned char)(unsigned)(r0.y < i1)) & 1u) { t5 = (unsigned)(garr[i1 & 7u] || ((unsigned)c0 + u0)); z5 = (double)(((0x10000u | 0x41c122fau)) & 255u); } if (((unsigned)(unsigned char)(unsigned)(r0.y < i1)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            r0.y ^= (unsigned)h0;
            if (0xf9022380u) break;
            switch ((0x80000000u >> ((unsigned)((short)u1 > (signed char)3u) & 31u)) & 7u) {
                w0 ^= (unsigned long long)(unsigned)((unsigned)e0 < 0xa7f92020u) << (((unsigned)(short)((unsigned)(w0 >> 29) * (unsigned)s0) * m0) & 63u);
                h0 = (short)((unsigned)w0 / ((unsigned)(w0 >> 29) | 1u));
                case 0u: ;
            }
            *q0 = (0x7fffffffu / ((fuel / ((unsigned)((int)(unsigned)c1 >= (int)0x2257a431u) | 1u)) | 1u));
            if ((unsigned)(v0 < i1)) break;
        }
        if (((0x8e5fe472u % (a0[u1 & 3u] | 1u)) / ((unsigned)l0 | 1u))) continue;
        c0 = (unsigned char)(unsigned)(u3 || (unsigned)x0);
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)(*q0 < 6u) | *q0)) break;
    }
    if ((unsigned)((short)(unsigned)h0 > (signed char)p1)) {
        do { if (--fuel == 0u) goto done;
            c0 = (unsigned char)6u;
            if (-((unsigned)!((unsigned)x0 / (u2 | 1u)) & 0x592be260u)) continue;
            u0 += ((unsigned)b0 + ((unsigned)f0 - 2u));
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch ((unsigned)(unsigned char)((0x6d7e8c34u / (0x10000u | 1u)) - (unsigned)b0) & 7u) {
                    if ((unsigned)(short)(0x27aeb253u & (unsigned)l0)) {
                        case 1u: ;
                        w0 ^= (unsigned long long)((unsigned)(w0 >> 29) + g1) << ((unsigned)((unsigned)((short)(unsigned)s1 > (signed char)1u) < (unsigned)(0x80000000u || 0xffffffffu)) & 63u);
                        w0 ^= (unsigned long long)u3 << ((((unsigned)e0 << ((m0 | 0xe04b637eu) & 31u)) >> ((unsigned)l0 & 31u)) & 63u);
                        case 6u: ;
                    } else {
                        default: ;
                    }
                    w0 = w0 * 6364136223846793005ull + (v0 ? p0 : ((unsigned)(a0[i0 & 3u] || garr[i1 & 7u]) * p2));
                }
            }
            if ((p2 >> (((unsigned)e0 % (u3 | 1u)) & 31u))) break;
            b0 = (((a0[i0 & 3u] % (i1 | 1u)) + 0xffffffffu) % (i2 | 1u)) != 0u;
        } while (i0++ < 5u && ((unsigned)h1 << ((g1 | 0xccf00bf3u) & 31u)));
        if (((unsigned)((short)i1 > (signed char)0x10000u) | p0)) goto L0;
    } else {
        if (fuel < 8u) return ~((unsigned)((unsigned)((unsigned)w0 || (unsigned)c0) < (p2 - i1)) >> ((unsigned)d0 & 31u));
        l0 = (long)((unsigned long)l0 + (unsigned)h1);
        c1 = (signed char)i2;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    v0 = *q0;
    while ((unsigned)(short)(unsigned)(p2 < (unsigned)((int)i1 >= (int)i0))) { if (--fuel == 0u) goto done;
        switch ((unsigned)((int)g1 >= (int)(fuel % (u1 | 1u))) & 7u) {
            switch ((unsigned)d0 & 7u) {
                h1 = (unsigned short)(h1 + (unsigned)(unsigned char)((unsigned)(w0 >> 29) << ((unsigned)((int)0xc6d34c45u >= (int)(unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)((int)(unsigned)f0 < (int)a0[i0 & 3u]))) & 31u)));
                l0 = (long)((unsigned long)l0 + (unsigned)s0);
                if (~((i0 - u1) >> (0xf71924f3u & 31u))) goto done;
                if ((unsigned)(i2 && (unsigned)x0)) break;
                a0[(a0[u1 & 3u] << (0x839c4dcau & 31u)) & 3u] = 7u;
                if ((unsigned)((short)p1 > (signed char)(0x7fffffffu + p1))) goto done;
            }
        }
    }
    h0 = (short)((unsigned)((unsigned)b0 || i0) >> (0x1c61ed56u & 31u));
    L0: if (--fuel == 0u) goto done;
    goto L3;
    if (((g0 & p1) >> ((unsigned)d0 & 31u))) {
        if (g1) goto L4;
        if ((unsigned)(0xffffffffu || (a0[i0 & 3u] | garr[u2 & 7u]))) goto L1;
        l0 = (long)((unsigned long)l0 + (unsigned)w0);
    }
    if ((unsigned)(i2 == (p1 & 0xffffffffu))) {
        x0 = x0 * 0x100000001b3ull + (i2 + (unsigned)(0x3cb1e170u == (unsigned)l0));
        u1 ^= ((0x2a4dcc42u % ((unsigned)c0 | 1u)) + u2);
    } else {
        if ((unsigned)f0) goto L4;
        h0 = (short)((unsigned)b0 + (a0[u1 & 3u] * (u3 - i1)));
        for (;;) { if (--fuel == 0u) goto done;
            g0 = (0x80000000u / (0x80000000u | 1u));
        }
    }
    f0 = f0 * 0.5f + (float)(((r0.y ? (unsigned)c0 : u0) % ((9u * u3) | 1u)) & 255u);
    s0 = (int)(0x1dc00663u + r0.x);
    switch ((unsigned)((int)u2 < (int)0x9535a7du) & 7u) {
        if (((unsigned)(1u || i2) - p2)) {
            f0 = f0 * 0.5f + (float)(((r0.x / (i2 | 1u)) - i1) & 255u);
            w0 ^= (unsigned long long)(unsigned)(*q0 && v0) << (0x10000u & 63u);
            l0 = (long)((unsigned long)l0 + (unsigned)(short)(0xffffffffu - (unsigned)(short)((unsigned)s0 >> ((unsigned)(m0 && 0x10000u) & 31u))));
        } else {
            *q0 = ((unsigned)(x0 >> 70) ? i1 : (0xf247be20u - garr[i1 & 7u]));
        }
        do { if (--fuel == 0u) goto done;
            while (i1++ < 7u && (0x2a2cf83u | 7u)) { if (--fuel == 0u) goto done;
                garr[(unsigned)f0 & 7u] = ((unsigned)((int)0x10000u < (int)0u) / ((unsigned)h0 | 1u));
                switch (i2 & 7u) {
                    if (fuel < 8u) return 0xffffffffu;
                    if ((unsigned)((int)1u < (int)i0)) {
                        break; (void)(((unsigned)((short)u0 > (signed char)(unsigned)b0) >> (0xffffffffu & 31u)));
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(i0 || ((unsigned)c0 * i1)), (p1 & 0u), (unsigned)((unsigned)b0 < 8u)); }
                        if (i1) {
                            w0 ^= (unsigned long long)0x1c98e1b2u << (((unsigned)(0xb88be654u < (unsigned)s1) - p2) & 63u);
                        }
                    } else {
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)0x8e085cdau < (int)i1), (0x10000u & (*mp % (garr[u2 & 7u] | 1u))), (u0 & u3)); }
                        c1 = (signed char)(unsigned)(p2 && (unsigned)l0);
                        e0 = e0 * 0.5L + (long double)((garr[u2 & 7u] + 9u) & 1023u);
                        case 0u: ;
                    }
                    L1: if (--fuel == 0u) goto done;
                    case 4u: ;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)0xf4b40c0eu < (int)((unsigned)h1 * u2)), a0[u1 & 3u], (unsigned)(unsigned char)((unsigned)(w0 >> 29) + ((unsigned)h1 ^ a0[i0 & 3u]))); }
                    switch ((unsigned)c1 & 7u) {
                        do { if (--fuel == 0u) goto done;
                            f0 = f0 * 0.5f + (float)((p2 & fuel) & 255u);
                        } while (i2++ < 5u && 0x9c07cc93u);
                        for (;;) { if (--fuel == 0u) goto done;
                            if ((unsigned)!(v0 * (unsigned)d0)) continue;
                            u2 = u2 * 0x9e3779b1u + ((unsigned)((short)0xb5a28490u > (signed char)(unsigned)s0) % ((unsigned)((0x28902a58u >> (p1 & 31u)) < garr[i1 & 7u]) | 1u));
                            w0 = w0 * 6364136223846793005ull + (unsigned)((int)-(*q0 * (unsigned)x0) < (int)fuel);
                            *q0 = u2;
                            if (6u) continue;
                        }
                        if ((unsigned)e0) goto L4;
                        c0 = (unsigned char)((unsigned)f0 | (unsigned)(0xa4964af0u && 2u));
                        c0 = (unsigned char)(unsigned)((int)(p0 ? garr[i1 & 7u] : u0) < (int)(unsigned)((unsigned)x0 || u1));
                        for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u1 = fn0(u2, (v0 & u1), (p0 / ((unsigned)(a0[i0 & 3u] && 0xb2f4db87u) | 1u))); }
                            L2: if (--fuel == 0u) goto done;
                            continue; (void)((unsigned)((1u ^ 0x10000u) < u1));
                            u2 = (unsigned)((int)0x45493ef3u < (int)fuel);
                        }
                    }
                }
            }
        } while (i0++ < 3u && -(0x10000u / (p0 | 1u)));
        s0 = (int)(unsigned)(0x13d7075du && (unsigned)(((unsigned)w0 + (unsigned)c0) == (unsigned)h1));
    }
    while (i0++ < 7u && (unsigned)(w0 >> 29)) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(unsigned char)(u3 >> (u3 & 31u)));
        r0.x = ((unsigned)(i0 || (unsigned)(x0 >> 70)) | (unsigned)h0);
        break; (void)((unsigned)h1);
        if ((unsigned)(unsigned char)(unsigned)(a0[i0 & 3u] < (unsigned)!(0x7fffffffu | (unsigned)s0))) break;
        if ((0xffffffffu / (0u | 1u))) break;
    }
    while (i0++ < 2u && (unsigned)!((unsigned)((unsigned)w0 || garr[u2 & 7u]) >> (u0 & 31u))) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (0x96ef3b90u ? garr[i1 & 7u] : p1));
    }
    if ((unsigned)((unsigned)h0 && (u2 | 9u))) {
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)s1 + (i2 / (0x80000000u | 1u))), (garr[i1 & 7u] & (unsigned)(x0 >> 70)), (0x80000000u & r0.y)); }
        u3 ^= (unsigned)(0x60b95a0eu && 7u);
        if ((unsigned)(u1 == 0xb206816cu)) {
            do { if (--fuel == 0u) goto done;
                c1 = (signed char)(m0 + (unsigned)(short)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)(0x7fffffffu || 0x16d88f72u)));
                e0 = e0 * 0.5L + (long double)(((unsigned)(w0 >> 29) * (g0 & (garr[i1 & 7u] >> (i0 & 31u)))) & 1023u);
            } while (i0++ < 3u && (unsigned)(a0[i0 & 3u] == (unsigned)w0));
            *q0 = (unsigned)((int)~(unsigned)((unsigned)d0 && (unsigned)((int)((unsigned)e0 - (unsigned)f0) < (int)(unsigned)c1)) < (int)p2);
        }
        if (((unsigned)f0 * (unsigned)s1)) goto L2;
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        i1 = ((a0[i0 & 3u] ? r0.x : (unsigned)w0) - (unsigned)((int)4u >= (int)(unsigned)f0)) & 15u;
        if (a0[i0 & 3u]) break;
        c1 = (signed char)(unsigned)((short)((unsigned)l0 | (unsigned)(u0 || (unsigned)e0)) > (signed char)i0);
        if ((((unsigned)(w0 >> 29) % ((unsigned)c1 | 1u)) * u1)) goto L1;
    }
    v0 = (unsigned)(garr[i1 & 7u] && (unsigned)((unsigned)((int)(unsigned)s0 < (int)m0) == (unsigned)(unsigned char)((unsigned)s0 % (8u | 1u))));
    if (p1) goto L3;
    c1 = (signed char)((unsigned)((unsigned)e0 < 0xffffffffu) & (p2 | ((unsigned)(x0 >> 70) / ((unsigned)f0 | 1u))));
    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)d0 || p0);
    L3: if (--fuel == 0u) goto done;
    l0 = (long)((unsigned long)l0 + p2);
    if (((m0 + garr[i1 & 7u]) * u3)) goto done;
    d0 = d0 * 0.5 + (double)(((unsigned)x0 | (unsigned)(unsigned char)((p2 | (unsigned)(x0 >> 70)) + (unsigned)l0)) & 1023u);
    if (0x7fffffffu) goto L2;
    c1 = (signed char)(u1 - (unsigned)(0xd9c2d556u && (unsigned)b0));
    c1 = (signed char)(0x80000000u ^ 1u);
    r0.x = ((u2 - (unsigned)s0) ? p0 : (unsigned)b0);
    switch ((r0.x - g1) & 7u) {
        b0 = (unsigned)((short)p1 > (signed char)(((unsigned)((unsigned)f0 == i1) % (u0 | 1u)) << (fuel & 31u))) != 0u;
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
            if (((0x9b2843f7u & u1) << ((unsigned)(x0 >> 70) & 31u))) continue;
            d0 = d0 * 0.5 + (double)(i0 & 1023u);
            e0 = e0 * 0.5L + (long double)(((p1 * fuel) ^ (unsigned)x0) & 1023u);
        }
    }
    *q0 = (unsigned)(garr[u2 & 7u] < (unsigned)(0xbc42814u < (unsigned)d0));
    r0.y ^= (unsigned)((unsigned)h0 == ((unsigned)s0 ? 0xffffffffu : *mp));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    d0 = d0 * 0.5 + (double)(0x3fb0a5eau & 1023u);
    if (u0) goto L4;
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)x0);
        if (9u) goto L0;
        goto L2;
        v0 = (unsigned)b0;
    } while (i0++ < 7u && (9u ? (unsigned)(x0 >> 70) : 0xffffffffu));
    if (u3 == 7u) return ((unsigned)c0 * 5u);
    L0: if (--fuel == 0u) goto done;
    if (u0) {
        while (i0++ < 7u && (unsigned)c1) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)!(unsigned)(0xffffffffu && 0x10000u) & 1023u);
            c0 = (unsigned char)(unsigned)((m0 + p0) && u0);
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                a0[0x80000000u & 3u] = ((0x10000u | *q0) - (u0 ^ (unsigned)(signed char)(a0[i0 & 3u] | a0[i0 & 3u])));
                w0 = w0 * 6364136223846793005ull + ((9u ? (unsigned)b0 : 8u) & (unsigned)(x0 >> 70));
                if ((unsigned)((unsigned)w0 && p0)) break;
                if (~(0xddcc6a68u % (m0 | 1u))) break;
                L1: if (--fuel == 0u) goto done;
                r0.y ^= (unsigned)(signed char)((unsigned)(x0 >> 70) * (unsigned)w0);
            }
            while (i1++ < 3u && 2u) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (unsigned)(8u && u1));
                goto L2;
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    u1 += (r0.x % ((unsigned)h1 | 1u));
                    x0 = x0 * 0x100000001b3ull + (unsigned)f0;
                    f0 = f0 * 0.5f + (float)((unsigned)(1u && 9u) & 255u);
                    r0.y ^= ((unsigned)((unsigned)w0 == (unsigned)h1) ^ (unsigned)((unsigned)(w0 >> 29) && p1));
                    garr[(0x78d02148u >> (0x7fffffffu & 31u)) & 7u] = (m0 * (unsigned)(0xe50bf777u && 0x10000u));
                }
                v0 = (a0[i0 & 3u] * r0.x);
                break; (void)((unsigned)((unsigned)b0 && (unsigned)b0));
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)b0, (unsigned)(0x10000u || g0), ((unsigned)(x0 >> 70) - p1)); }
            }
            u1 = (unsigned)((int)(unsigned)(i1 < (unsigned)(-(garr[u2 & 7u] | r0.y) && 6u)) >= (int)garr[u2 & 7u]);
        }
    }
    u2 += 0x41459d73u;
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(short)(unsigned)((unsigned)c1 < g0), (i1 * ((unsigned)h1 + r0.y)), 0x10000u); }
    if ((0x7fffffffu % ((0xab89c0abu & i2) | 1u))) goto L3;
    if (fuel < 8u) return fuel;
    c0 = (unsigned char)(unsigned)((unsigned)e0 && (unsigned)s0);
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(short)(i2 % (0xffffffffu | 1u))) continue;
        if (budget != 0u) { budget -= 1u; u1 = fn0(-(g1 / ((i1 + 0x7fffffffu) | 1u)), (unsigned)((int)0x2bc5e2c6u < (int)0x922d70f4u), ~(0u + 0xbc1eade3u)); }
        if ((9u % (7u | 1u))) break;
        x0 = x0 * 0x100000001b3ull + ((unsigned)s0 / (((unsigned)l0 + (unsigned)h1) | 1u));
        while (i1++ < 7u && (unsigned)((int)(unsigned)(w0 >> 29) >= (int)0xdfd8c755u)) { if (--fuel == 0u) goto done;
            L2: if (--fuel == 0u) goto done;
            if ((unsigned)(p1 == (unsigned)((unsigned)l0 < v0))) continue;
            { unsigned t0; double z0; if ((*q0) & 1u) { t0 = (unsigned)((int)(unsigned)h0 < (int)(unsigned)((int)i1 >= (int)(unsigned)s0)); z0 = (double)((v0) & 255u); } if ((*q0) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                if (budget != 0u) { budget -= 1u; u3 = fn1((0x10000u % (0x4ffa71bu | 1u)), (unsigned)(0xffffffffu || (unsigned)(unsigned char)(5u ^ 6u)), (unsigned)f0); }
                h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(0x7fffffffu ? (i0 - u0) : fuel));
                L3: if (--fuel == 0u) goto done;
                continue; (void)(((2u | 2u) - (unsigned)(x0 >> 70)));
                u2 = u2 * 0x9e3779b1u + (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)2u);
            }
        }
        b0 = (unsigned)(short)(0u & ((m0 << (6u & 31u)) & i1)) != 0u;
    }
    i1 = (unsigned)!((unsigned)((unsigned)b0 == garr[u2 & 7u]) % ((0x9fc03354u + (garr[u2 & 7u] * u3)) | 1u)) & 15u;
    if (~(0x840e909du & (unsigned)w0)) goto L4;
    w0 = w0 * 6364136223846793005ull + (v0 ? (unsigned)b0 : i1);
    if (u3 == 7u) return (((unsigned)((int)*mp >= (int)(unsigned)(short)((unsigned)s1 >> ((unsigned)f0 & 31u))) & p2) ^ m0);
    h0 = (short)(unsigned)s1;
    u0 = u0 * 0x9e3779b1u + (*q0 ^ ~((unsigned)((int)(unsigned)f0 >= (int)0x10000u) ^ (unsigned)c1));
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        b0 = (unsigned)((short)i2 > (signed char)(unsigned)((unsigned)c1 == r0.y)) != 0u;
        if (budget != 0u) { budget -= 1u; u3 = fn1(i2, (unsigned)((int)a0[u1 & 3u] >= (int)a0[i0 & 3u]), garr[u2 & 7u]); }
        if ((unsigned)((int)(unsigned)(p0 == (unsigned)c0) >= (int)0x7fffffffu)) break;
        garr[(unsigned)((int)0xa1c02f85u < (int)p0) & 7u] = p1;
        if ((0x7fffffffu >> (((unsigned)w0 >> (m0 & 31u)) & 31u))) break;
    }
    if (a0[i0 & 3u]) {
        if ((0x10000u / ((unsigned)((unsigned)c1 && (unsigned)s1) | 1u))) goto L3;
        r0.x = (p0 - fuel);
        *q0 += (unsigned)d0;
        while ((unsigned)(signed char)((unsigned)(fuel < (unsigned)d0) | 0xffffffffu)) { if (--fuel == 0u) goto done;
            *mp = (garr[i1 & 7u] / ((0xffffffffu | (unsigned)(((unsigned)s0 >> (r0.y & 31u)) == 7u)) | 1u));
            if (garr[i1 & 7u]) continue;
            if (budget != 0u) { budget -= 1u; u0 = fn0((0x7fffffffu & (unsigned)((int)*mp >= (int)0xf57a3ca0u)), (unsigned)((int)u3 < (int)(unsigned)c1), (unsigned)d0); }
            if ((p2 & u0)) break;
            while (g1) { if (--fuel == 0u) goto done;
                goto L0;
                c1 = (signed char)(~(((unsigned)e0 & (unsigned)x0) & a0[u1 & 3u]) << (0x3d4d79c0u & 31u));
                b0 = (r0.x >> (((unsigned)x0 - (unsigned)!(1u & 4u)) & 31u)) != 0u;
                s0 = (int)(unsigned)((int)i2 >= (int)(unsigned)((int)(unsigned)(p2 || (unsigned)h1) < (int)(unsigned)h1));
                break; (void)(garr[u2 & 7u]);
            }
        }
    }
    i0 = (i1 * -(((unsigned)!(u3 << (0x77b8ea2cu & 31u)) / (u0 | 1u)) + g0)) & 15u;
    r0.y ^= -(unsigned)((int)0x7fffffffu >= (int)(p1 ? p1 : (unsigned)s1));
    m0 ^= (0xffffffffu / ((unsigned)c0 | 1u));
    L4: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u2 = fn0(0x9769ce83u, g1, ((unsigned)(a0[u1 & 3u] == 0x16dd72feu) << (0x6654722au & 31u))); }
    if (0x10000u) goto L0;
    if ((0xffffffffu - (unsigned)(x0 >> 70))) goto L3;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)!(u2 & (unsigned)c0)) break;
    } while (i0++ < 3u && (unsigned)((unsigned)x0 == m0));
    if (budget != 0u) { budget -= 1u; u3 = fn1((((unsigned)e0 % (5u | 1u)) ^ (unsigned)(w0 >> 29)), (r0.y | (unsigned)d0), 0xf122afecu); }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0xeba29fa2u) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)h0 < 0x830e2d0eu), (i1 % ((a0[i0 & 3u] ^ g0) | 1u)), (unsigned)e0); }
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn0(fuel, -((unsigned)h0 % (u1 | 1u)), (u3 & (unsigned)(m0 < g0))); }
            d0 = d0 * 0.5 + (double)(0x7fffffffu & 1023u);
            b0 = (0xef3586e8u | (unsigned)((int)(0x7fffffffu >> ((unsigned)(r0.y < u1) & 31u)) >= (int)i0)) != 0u;
        }
        b0 = -((unsigned)!(a0[u1 & 3u] >> ((unsigned)s0 & 31u)) & r0.x) != 0u;
        break; (void)(0xb45f5e45u);
        if ((unsigned)(0x9e2b9e4cu < 0xb69801f1u)) {
            r0.y ^= p0;
        } else {
            if (u3 == 7u) return (unsigned)(signed char)(unsigned)((0x7fffffffu ^ 0xffffffffu) == (unsigned)(unsigned char)(unsigned)(((unsigned)f0 & 6u) < (unsigned)x0));
            if (p0) continue;
            if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)w0 % (p0 | 1u)), (unsigned)(w0 >> 29), ((unsigned)d0 ^ u2)); }
            *mp = (u0 ? (unsigned)(w0 >> 29) : fuel);
        }
    }
    if (((unsigned)((int)(unsigned)l0 < (int)(unsigned)e0) & i2)) goto L2;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= -(unsigned)(r0.y && (unsigned)(garr[i1 & 7u] < -(unsigned)((int)r0.y < (int)0x7fffffffu)));
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(i1 < 0xd93fb84u), (g1 + (fuel + g0)), (unsigned)((int)0x7fffffffu < (int)(unsigned)e0)); }
        switch (((unsigned)((int)0xcaf1c6ccu < (int)8u) << (r0.x & 31u)) & 7u) {
            a0[0x88b05869u & 3u] = (g1 | m0);
            for (;;) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)(short)(unsigned)(0x80000000u || 9u) << ((((unsigned)(*mp < i2) << ((garr[u2 & 7u] % (fuel | 1u)) & 31u)) >> (*q0 & 31u)) & 63u);
                r0.x = (unsigned)((short)fuel > (signed char)(unsigned)((unsigned)(unsigned char)((unsigned)((unsigned)c0 || (unsigned)l0) - 5u) < (unsigned)c0));
                r0.x = (r0.y ^ ((*mp >> (0x80000000u & 31u)) - (4u >> (p1 & 31u))));
                case 6u: ;
                u1 = u1 * 0x9e3779b1u + ((v0 * 7u) / ((unsigned)((short)i2 > (signed char)(unsigned)((unsigned)h1 == (unsigned)d0)) | 1u));
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(x0 >> 70) - (a0[i0 & 3u] + 0x3c194942u)), p1, (unsigned)(u1 == v0)); }
            }
            u1 = u1 * 0x9e3779b1u + (i2 >> (a0[u1 & 3u] & 31u));
            if ((r0.x / (0xffffffffu | 1u))) continue;
            u2 += (0x75530f53u % (((unsigned)s0 ^ 0xa82d9cbdu) | 1u));
        }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((int)0xffffffffu < (int)i2)) break;
            break; (void)((unsigned)(signed char)(unsigned)((unsigned)(x0 >> 70) == a0[i0 & 3u]));
        } while (i1++ < 4u && (unsigned)c1);
        if (0x7fffffffu) {
            break; (void)((a0[u1 & 3u] ^ *mp));
            { unsigned t1; double z1; if (((i0 * 0x3712009fu)) & 1u) { t1 = (garr[u2 & 7u] << (g0 & 31u)); z1 = (double)((garr[u2 & 7u]) & 255u); } if (((i0 * 0x3712009fu)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                u1 = ((unsigned)f0 | a0[u1 & 3u]);
                v0 = (unsigned)(((unsigned)c0 % (0x8af1b63u | 1u)) == ((unsigned)(unsigned char)(unsigned)((unsigned)b0 || u3) << (*q0 & 31u)));
                if (budget != 0u) { budget -= 1u; u3 = fn1(0xd3fbfcedu, (7u >> ((unsigned)((unsigned)c1 && (unsigned)(x0 >> 70)) & 31u)), (unsigned)((int)0x80000000u < (int)i0)); }
                while ((u3 ^ (unsigned)h1)) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)((((unsigned)d0 ^ i2) | (unsigned)f0) & 255u);
                }
                { unsigned t2; double z2; if ((((2u & garr[i1 & 7u]) << (*q0 & 31u))) & 1u) { t2 = (unsigned)((int)0x3087e8f4u < (int)(unsigned)(0u && u1)); z2 = (double)(((unsigned)((short)(unsigned)(*mp || (unsigned)h0) > (signed char)0xb874f06bu)) & 255u); } if ((((2u & garr[i1 & 7u]) << (*q0 & 31u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    while (i1++ < 3u && (unsigned)(signed char)(unsigned)((int)g0 >= (int)p2)) { if (--fuel == 0u) goto done;
                        c1 = (signed char)((unsigned)(unsigned char)((unsigned)l0 * (g1 + i2)) - r0.x);
                        w0 ^= (unsigned long long)0x90b1212u << ((unsigned)e0 & 63u);
                    }
                    if ((unsigned)((unsigned)s1 || (unsigned)h0)) goto L1;
                }
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(x0 >> 70) == garr[i1 & 7u]), 0x7657a61du, (unsigned)((int)(unsigned)(p2 == garr[u2 & 7u]) < (int)0x10000u)); }
        } else {
            if (budget != 0u) { budget -= 1u; u2 = fn1((m0 / ((unsigned)((unsigned)(w0 >> 29) == p1) | 1u)), r0.y, ((unsigned)((unsigned)s0 == 0x10000u) & p2)); }
            do { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)c1 & 1023u);
                if ((unsigned)((int)u0 < (int)(unsigned)(0xfbb75cd4u && i1))) break;
                x0 = x0 * 0x100000001b3ull + ((unsigned)c0 - (unsigned)(unsigned char)(unsigned)(0x8fc278d2u && (unsigned)(v0 == (0xffffffffu % (u0 | 1u)))));
                if ((unsigned)(p2 || a0[u1 & 3u])) {
                    if (u3 == 7u) return (unsigned)(u0 == (unsigned)s0);
                    f0 = f0 * 0.5f + (float)((unsigned)((0x7fffffffu ? 3u : (unsigned)c1) == garr[i1 & 7u]) & 255u);
                    garr[(unsigned)((int)g0 < (int)2u) & 7u] = (i2 >> ((unsigned)h1 & 31u));
                    u3 = u3 * 0x9e3779b1u + (unsigned)(2u && p2);
                    if ((unsigned)(u1 < i2)) goto L0;
                    if ((unsigned)((int)(unsigned)x0 < (int)u3)) break;
                } else {
                    *q0 = ((unsigned)s1 % (i1 | 1u));
                    w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)((short)(5u - a0[u1 & 3u]) > (signed char)(unsigned)((int)0x1162360bu < (int)v0)) > (signed char)(unsigned)f0);
                }
                if ((unsigned)((int)0xc6411aaeu < (int)(unsigned)b0)) break;
                e0 = e0 * 0.5L + (long double)(*q0 & 1023u);
            } while (i1++ < 2u && (unsigned)(r0.x && r0.x));
            if ((0xffffffffu / (((unsigned)h0 << (p0 & 31u)) | 1u))) break;
            garr[(unsigned)(u3 || u2) & 7u] = (unsigned)((unsigned)c1 || garr[i1 & 7u]);
        }
    }
    a0[2u & 3u] = (0xeaf0d556u ? (unsigned)(x0 >> 70) : 0x80000000u);
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((short)(unsigned)c1 > (signed char)i0) << ((unsigned)s0 & 31u)), 7u, fuel); }
        f0 = f0 * 0.5f + (float)((unsigned)(signed char)(unsigned)((int)(unsigned)(u2 || (unsigned)((int)0x80000000u < (int)garr[u2 & 7u])) < (int)(unsigned)e0) & 255u);
        if (4u) break;
    }
    { unsigned t3; double z3; if ((((unsigned)(unsigned char)(unsigned)(u3 && p0) % (*mp | 1u))) & 1u) { t3 = (unsigned)b0; z3 = (double)(((unsigned)x0) & 255u); } if ((((unsigned)(unsigned char)(unsigned)(u3 && p0) % (*mp | 1u))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        switch (((unsigned)w0 | (garr[u2 & 7u] + 0x80000000u)) & 7u) {
            case 2u: ;
            if (0x7fffffffu) {
                s1 = (int)((unsigned)s1 + (i2 - i0));
                if ((u3 | a0[u1 & 3u])) break;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)*mp > (signed char)u1), ((unsigned)h0 - p2), v0); }
            } else {
                *q0 += (unsigned)(w0 >> 29);
                for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    case 7u: ;
                    s1 = (int)((unsigned)s1 + ((unsigned)(signed char)(8u >> ((unsigned)w0 & 31u)) << (3u & 31u)));
                }
            }
            while (i0++ < 5u && (0xffffffffu - (unsigned)s1)) { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    u1 += (unsigned)((int)1u < (int)(unsigned)d0);
                }
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    goto L3;
                }
                x0 = x0 * 0x100000001b3ull + (0x10000u - (unsigned)l0);
                case 3u: ;
                m0 ^= (unsigned)(unsigned char)(unsigned)(0x7fffffffu || (9u >> ((unsigned)s1 & 31u)));
                w0 = w0 * 6364136223846793005ull + (unsigned)((short)u2 > (signed char)(unsigned)((int)(unsigned)((int)u2 >= (int)(unsigned)(6u == 0xe1cd3b7du)) < (int)(unsigned)l0));
            }
            if ((unsigned)(unsigned char)(p2 / (m0 | 1u))) goto L4;
            if ((u3 & (unsigned)(unsigned char)(8u | v0))) {
                switch (((0x49eeb622u + (unsigned)c1) >> (u1 & 31u)) & 7u) {
                    *mp = p0;
                    r0.x = (r0.x | (unsigned)(r0.y < (unsigned)l0));
                    if (budget != 0u) { budget -= 1u; u1 = fn0(7u, garr[u2 & 7u], (0x7fffffffu & *mp)); }
                    { unsigned t4; double z4; if ((~((unsigned)(p0 < 0xfce9a5dcu) * p2)) & 1u) { t4 = (unsigned)((int)r0.x >= (int)fuel); z4 = (double)((u0) & 255u); } if ((~((unsigned)(p0 < 0xfce9a5dcu) * p2)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                        h0 = (short)(0xe61bd435u | (unsigned)(signed char)((unsigned)(signed char)(unsigned)(7u == u2) << ((unsigned)(p2 < g1) & 31u)));
                    }
                }
                case 4u: ;
                while (i0++ < 3u && 9u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + ((unsigned)(a0[i0 & 3u] == 0xffffffffu) % (0x8f488abbu | 1u)));
                    case 5u: ;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0(0x37d64283u, g1, ((unsigned)((int)0xd4ffdc3bu >= (int)p2) << (6u & 31u))); }
                if ((garr[i1 & 7u] - p1)) goto L0;
                default: ;
            } else {
                *q0 += (unsigned)(0xffffffffu && (unsigned)h1);
                v0 = (0x74981ffbu << ((unsigned)((int)0xea49734u < (int)(unsigned)s0) & 31u));
                break;
            }
        }
        goto L4;
        *mp = 0x8eea4d67u;
        while (i0++ < 6u && (*q0 >> (*q0 & 31u))) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((int)(unsigned)c1 >= (int)0u) && 5u);
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            g0 = ((unsigned)d0 >> (0xffffffffu & 31u));
            do { if (--fuel == 0u) goto done;
                goto L1;
                do { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + ((unsigned)h1 % (((unsigned)d0 - i2) | 1u)));
                } while (i2++ < 5u && u1);
                garr[u2 & 7u] = ((unsigned)!((m0 ^ u1) * (unsigned)s0) & 1u);
                if ((unsigned)c0) break;
            } while (i1++ < 2u && ((unsigned)((int)0x235479ecu >= (int)p2) % ((unsigned)s1 | 1u)));
        }
    }
    goto L1;
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((short)(unsigned)(unsigned char)(a0[i0 & 3u] + 0xd5eea049u) > (signed char)4u)) {
            goto done;
            if ((unsigned)((unsigned)(p2 || (unsigned)d0) || (unsigned)c1)) {
                break; (void)(4u);
                d0 = d0 * 0.5 + (double)(m0 & 1023u);
                r0.y ^= (garr[u2 & 7u] + (unsigned)((int)((unsigned)w0 >> (p0 & 31u)) < (int)0xca53c11cu));
            }
        }
        if (0x80000000u) {
            garr[-(0x36bf79eeu & (unsigned)x0) & 7u] = ((unsigned)x0 ^ 0xffffffffu);
            *mp = (unsigned)((unsigned)((int)(unsigned)!(unsigned)(p1 && 0x10000u) < (int)(0xffffffffu << ((unsigned)b0 & 31u))) < 3u);
        } else {
            u1 = (unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)r0.x >= (int)9u) >= (int)(unsigned)(garr[i1 & 7u] == 0xb3d37402u));
            h1 = (unsigned short)(h1 + p1);
            u1 += (unsigned)((int)(unsigned)!(unsigned)(p0 < r0.x) >= (int)(i0 * 0xf6461ecbu));
        }
        if ((unsigned)!(unsigned)((int)i2 >= (int)(*q0 * (unsigned)x0))) break;
        if ((unsigned)b0) break;
        if (3u) break;
        { unsigned t5; double z5; if ((p0) & 1u) { t5 = 0x580a7da2u; z5 = (double)(((0xffffffffu << (r0.y & 31u))) & 255u); } if ((p0) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            goto L3;
            if (((unsigned)x0 >> ((garr[u2 & 7u] * 0x10000u) & 31u))) break;
            *q0 += (unsigned)s0;
            while (i1++ < 5u && r0.y) { if (--fuel == 0u) goto done;
                r0.y ^= ((unsigned)x0 * (unsigned)(short)(garr[i1 & 7u] << ((unsigned)d0 & 31u)));
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)0xffffffffu >= (int)0xc93f112bu), (((unsigned)s0 % (0x80000000u | 1u)) / (0x10000u | 1u)), 1u); }
                for (;;) { if (--fuel == 0u) goto done;
                    if (((unsigned)s0 | (0x60768e81u / (3u | 1u)))) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)i2 < (int)i0), v0, r0.y); }
                }
                if ((u0 + m0)) {
                    *q0 = (7u + 2u);
                    break; (void)(garr[u2 & 7u]);
                    { unsigned t6; double z6; if ((fuel) & 1u) { t6 = (unsigned)(short)(unsigned)(6u || (unsigned)(w0 >> 29)); z6 = (double)(((unsigned)((unsigned)(i2 == (unsigned)l0) == garr[u2 & 7u])) & 255u); } if ((fuel) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                        s0 = (int)(unsigned)((*q0 / ((unsigned)x0 | 1u)) < -(r0.y * m0));
                        if (fuel < 8u) return v0;
                        *q0 += (a0[u1 & 3u] - (unsigned)(unsigned char)((unsigned)w0 | (unsigned)((int)g1 < (int)u2)));
                        if (4u) break;
                        break; (void)((unsigned)(((unsigned)e0 % (0x460dba4au | 1u)) == r0.x));
                        if (0x80000000u) continue;
                    }
                    if ((unsigned)(7u < (unsigned)(unsigned char)(unsigned)((short)(unsigned)f0 > (signed char)0xd1d85819u))) goto L0;
                    h1 = (unsigned short)(h1 + ((0x80000000u / (((unsigned)((int)0x4ad01279u >= (int)0u) * (unsigned)c0) | 1u)) - u3));
                } else {
                    if (3u) break;
                    h0 = (short)(unsigned)(short)((unsigned)s1 / (garr[i1 & 7u] | 1u));
                    if ((unsigned)(2u && (u0 * 0xdaf52f9fu))) {
                        if ((0x1ebe2019u * 9u)) {
                            if ((unsigned)(5u < 0xcee7e62u)) break;
                            if ((unsigned)(signed char)(unsigned)(a0[i0 & 3u] == (unsigned)(0x89e291e1u || i0))) goto L4;
                            if (garr[i1 & 7u]) break;
                        }
                        if ((unsigned)((unsigned)f0 && (p2 + (unsigned)x0))) break;
                        if ((unsigned)c1) break;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)(unsigned char)(garr[u2 & 7u] << (v0 & 31u)) && *mp), (u2 ^ (unsigned)(w0 >> 29)), *mp); }
                        d0 = d0 * 0.5 + (double)(((0xffffffffu ^ 0x78109b80u) ^ a0[u1 & 3u]) & 1023u);
                        if ((unsigned)((int)i2 < (int)v0)) break;
                    }
                }
                c0 = (unsigned char)((unsigned)h1 + p1);
                switch ((a0[i0 & 3u] >> ((garr[i1 & 7u] ^ a0[i0 & 3u]) & 31u)) & 7u) {
                    case 0u: ;
                    default: ;
                }
            }
            r0.x = ((unsigned)c1 - (unsigned)h1);
        }
    } while (i0++ < 4u && (unsigned)(0xd9396a0cu || (unsigned)(w0 >> 29)));
    c1 = (signed char)(unsigned)!(unsigned)(((unsigned)(unsigned char)(unsigned)(r0.x < (unsigned)c0) << (i1 & 31u)) == 5u);
    w0 ^= (unsigned long long)(*q0 ^ (unsigned)d0) << ((i2 % ((unsigned)((int)i1 >= (int)(unsigned)s1) | 1u)) & 63u);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        g1 += u1;
        if ((r0.x % (u0 | 1u))) {
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)((int)(unsigned)s1 < (int)(unsigned)w0) / (garr[i1 & 7u] | 1u))) break;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(u3 && (unsigned)x0), (unsigned)((unsigned)(m0 == (unsigned)c1) && (unsigned)(w0 >> 29)), (unsigned)((unsigned)e0 || (unsigned)((unsigned)f0 || p0))); }
            }
            { unsigned t7; double z7; if (((unsigned)!(p1 ^ (unsigned)b0)) & 1u) { t7 = fuel; z7 = (double)(((unsigned)((int)(unsigned)l0 < (int)(unsigned)w0)) & 255u); } if (((unsigned)!(p1 ^ (unsigned)b0)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                if ((unsigned)((unsigned)f0 && (unsigned)h0)) break;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)4u > (signed char)u1), (unsigned)((unsigned)c0 && r0.x), ~((unsigned)(5u && (unsigned)c0) / (*mp | 1u))); }
                break; (void)(((unsigned)x0 % ((unsigned)(x0 >> 70) | 1u)));
                switch ((unsigned)((unsigned)c1 == (unsigned)(x0 >> 70)) & 7u) {
                    *q0 += (0xffffffffu << (6u & 31u));
                }
            }
            w0 ^= (unsigned long long)u1 << ((unsigned)((unsigned)((int)(unsigned)x0 >= (int)(unsigned)s0) < (unsigned)((int)(unsigned)((short)(unsigned)x0 > (signed char)u2) < (int)p0)) & 63u);
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)b0 << ((*mp ^ fuel) & 31u))) {
                    if (budget != 0u) { budget -= 1u; u2 = fn1(0xd9b807cau, (unsigned)(short)(unsigned)((int)((unsigned)e0 & garr[i1 & 7u]) < (int)r0.y), (unsigned)((int)v0 >= (int)0x10000u)); }
                    continue; (void)(0x80000000u);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(p2, (*q0 | 0x80000000u), g1); }
                    if ((i0 * (unsigned)d0)) continue;
                    if (fuel) break;
                }
                { unsigned t8; double z8; if ((i2) & 1u) { t8 = u1; z8 = (double)(((unsigned)((short)(unsigned)(7u || (unsigned)h0) > (signed char)garr[i1 & 7u])) & 255u); } if ((i2) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        g0 = (((unsigned)(v0 == (unsigned)(x0 >> 70)) + (unsigned)f0) << ((unsigned)((unsigned)h1 == p2) & 31u));
                        v0 = ((u3 + (unsigned)b0) % ((u0 | u3) | 1u));
                        r0.x = (g0 % (garr[u2 & 7u] | 1u));
                        m0 ^= (0xecf350beu >> (~(0x23a25b2du >> ((unsigned)(0x54cb0a9u && 6u) & 31u)) & 31u));
                    }
                    i0 = *mp & 15u;
                    break; (void)(((u0 * (unsigned)(x0 >> 70)) | g0));
                    goto L3;
                    a0[(1u | 0xaa4f1b1fu) & 3u] = r0.x;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(w0 >> 29) ^ (unsigned)c0), (unsigned)s1, (unsigned)((int)(unsigned)(w0 >> 29) >= (int)p2)); }
                }
            }
        } else {
            if ((unsigned)((int)0x80000000u >= (int)((unsigned)e0 << (6u & 31u)))) break;
            if ((unsigned)((unsigned)e0 == m0)) break;
        }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            u2 = u2 * 0x9e3779b1u + (unsigned)(short)((garr[i1 & 7u] - g0) / (2u | 1u));
            switch ((unsigned)(short)(unsigned)(garr[i1 & 7u] || 0x67f5848bu) & 7u) {
                a0[a0[i0 & 3u] & 3u] = (p0 >> (((unsigned)((unsigned)e0 && *q0) + (unsigned)e0) & 31u));
                case 0u: ;
                for (;;) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (unsigned)(w0 >> 29);
                    case 3u: ;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)h1, (unsigned)(fuel < (unsigned)(w0 >> 29)), (0x610a3dc0u << (r0.x & 31u))); }
            }
            l0 = (long)((unsigned long)l0 + (u2 | (unsigned)(m0 < (fuel ^ 4u))));
            { unsigned t9; double z9; if (((g1 / (a0[u1 & 3u] | 1u))) & 1u) { t9 = (0x10000u * a0[i0 & 3u]); z9 = (double)((((unsigned)c0 ? 7u : 5u)) & 255u); } if (((g1 / (a0[u1 & 3u] | 1u))) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
                break; (void)(((0x6930cd1fu ^ 0u) ^ 0xb4c396c9u));
                break; (void)((u0 << ((unsigned)f0 & 31u)));
                goto L3;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)4u < (int)(0x452c5c78u ^ 9u)), (0x53f220d8u >> ((unsigned)(u2 == garr[u2 & 7u]) & 31u)), (unsigned)((int)*mp < (int)(unsigned)b0)); }
                if (budget != 0u) { budget -= 1u; u3 = fn0((0xf591cdb0u - g1), 8u, (unsigned)(m0 || 0x7fffffffu)); }
            }
            while (i2++ < 6u && (*mp | (unsigned)(i1 < 0xae5957e4u))) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)b0 > (signed char)r0.y));
                if (garr[i1 & 7u]) break;
                v0 = ((unsigned)((int)0xffffffffu >= (int)m0) - (garr[u2 & 7u] ^ 0x7af67278u));
                if ((((unsigned)c0 - a0[u1 & 3u]) >> ((unsigned)e0 & 31u))) break;
            }
            g1 += (0xffffffffu * u0);
        }
        g1 += ((1u | (unsigned)c0) / ((a0[u1 & 3u] & r0.y) | 1u));
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0(((0xb66f8977u - i0) % (a0[i0 & 3u] | 1u)), (0xacb008b3u & -(u1 / (v0 | 1u))), ((unsigned)s1 - *mp)); }
    } while (i0++ < 5u && (unsigned)((int)((unsigned)w0 << ((unsigned)x0 & 31u)) >= (int)r0.x));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)0xffffffffu >= (int)(unsigned)(a0[u1 & 3u] < i1)), (unsigned)e0, (unsigned)(u2 && (unsigned)(7u < (unsigned)x0))); }
        goto done;
        break; (void)(0u);
        g1 += (unsigned)s0;
        w0 = w0 * 6364136223846793005ull + (unsigned)((((unsigned)(x0 >> 70) - g1) ^ a0[i0 & 3u]) && 8u);
        if (budget != 0u) { budget -= 1u; u2 = fn0((u3 | (0u >> ((unsigned)b0 & 31u))), (((unsigned)(x0 >> 70) >> (g0 & 31u)) % (garr[i1 & 7u] | 1u)), (unsigned)x0); }
    }
    { unsigned t10; double z10; if ((garr[i1 & 7u]) & 1u) { t10 = m0; z10 = (double)(((0x3d1a530eu | (0x517de4f4u << ((unsigned)(x0 >> 70) & 31u)))) & 255u); } if ((garr[i1 & 7u]) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
        if (((unsigned)(w0 >> 29) & 0x9b17c592u)) goto L4;
        while (2u) { if (--fuel == 0u) goto done;
            *mp = (g1 + r0.x);
            q0 = &garr[((unsigned)c0 + -(0x7fffffffu & (unsigned)x0)) & 7u];
            if ((unsigned)c1) goto L4;
        }
        garr[*mp & 7u] = (unsigned)((short)(p0 & r0.y) > (signed char)(unsigned)((int)(a0[u1 & 3u] / (6u | 1u)) < (int)0u));
        do { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                if (((unsigned)b0 - (unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)c1))) break;
                w0 ^= (unsigned long long)u1 << ((0x4915582au + (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)(x0 >> 70))) & 63u);
            }
            w0 ^= (unsigned long long)i1 << (((0x2600b4ecu + (unsigned)f0) & (5u | v0)) & 63u);
            if ((unsigned)((short)(unsigned)s1 > (signed char)m0)) break;
            break; (void)(((unsigned)h0 >> ((unsigned)c1 & 31u)));
            i1 = 0xffffffffu & 15u;
            while (i1++ < 2u && (unsigned)(i2 == 0x58d17716u)) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)((int)g1 >= (int)2u) >= (int)0xe30093a4u)) {
                    if ((unsigned)s1) break;
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn1(garr[i1 & 7u], (r0.y | (unsigned)w0), (unsigned)((unsigned)(0x905bf94cu || i1) == g0)); }
                }
            }
        } while (i0++ < 3u && (unsigned)((int)~(unsigned)((int)g1 >= (int)garr[u2 & 7u]) >= (int)u2));
        do { if (--fuel == 0u) goto done;
            r0.x = ((unsigned)h1 - i0);
            if ((unsigned)f0) {
                a0[(unsigned)((int)g0 >= (int)(unsigned)b0) & 3u] = (unsigned)b0;
                do { if (--fuel == 0u) goto done;
                    if (((0x7fffffffu | (unsigned)h1) & p2)) continue;
                    r0.x = ((unsigned)(w0 >> 29) | i0);
                    w0 ^= (unsigned long long)v0 << (fuel & 63u);
                    do { if (--fuel == 0u) goto done;
                        g0 = ((unsigned)(p2 == p0) % (((unsigned)((short)g0 > (signed char)i1) * (unsigned)x0) | 1u));
                    } while (i2++ < 6u && (unsigned)h0);
                } while (i1++ < 5u && (unsigned)(u2 < 0x7fffffffu));
            }
            u3 = u3 * 0x9e3779b1u + (unsigned)((short)((0x7fffffffu | 8u) - (unsigned)x0) > (signed char)(unsigned)((unsigned)s1 < (unsigned)l0));
            if (((unsigned)((unsigned)s1 < (unsigned)c0) | 0x304f8cabu)) break;
            do { if (--fuel == 0u) goto done;
                *q0 = ((unsigned)(m0 == 0x41462553u) ^ (unsigned)(short)((unsigned)w0 | *mp));
                *mp = (*q0 * (a0[i0 & 3u] + (unsigned)s0));
                if (i2) break;
                if (r0.y) break;
                if (((0x10000u & 0x10000u) / (g0 | 1u))) break;
            } while (i1++ < 6u && ((unsigned)e0 - i2));
        } while (i0++ < 7u && ((u3 << (p0 & 31u)) / ((unsigned)d0 | 1u)));
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (0xfb3c3e25u) {
                if ((4u * (unsigned)d0)) break;
                if ((unsigned)(w0 >> 29)) break;
                c0 = (unsigned char)((unsigned)b0 * (unsigned)s1);
                s0 = (int)(unsigned)((short)(p2 / ((unsigned)((unsigned)(w0 >> 29) && (unsigned)l0) | 1u)) > (signed char)(unsigned)d0);
                if (budget != 0u) { budget -= 1u; u1 = fn1((((unsigned)x0 * a0[u1 & 3u]) & (unsigned)f0), ((unsigned)((unsigned)h1 || a0[i0 & 3u]) * 0xffffffffu), (unsigned)l0); }
            } else {
                w0 ^= (unsigned long long)u2 << ((unsigned)((short)6u > (signed char)((unsigned)h0 << ((unsigned)((int)i1 < (int)(g1 << (0xffffffffu & 31u))) & 31u))) & 63u);
            }
        }
    }
    do { if (--fuel == 0u) goto done;
        while (i1++ < 6u && (unsigned)(signed char)(6u % (i2 | 1u))) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (((unsigned)f0 * (unsigned)(0x10000u && (unsigned)l0)) / ((unsigned)((int)*q0 < (int)0x10000u) | 1u)));
            break; (void)((unsigned)(g1 < (unsigned)f0));
            m0 ^= (unsigned)((short)(unsigned)((int)0xffffffffu >= (int)*q0) > (signed char)(unsigned)(signed char)(u3 * 0x74f12e53u));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0(((g1 / (0x80000000u | 1u)) / (m0 | 1u)), (unsigned)(short)((unsigned)s1 / ((unsigned)(fuel || a0[u1 & 3u]) | 1u)), garr[u2 & 7u]); }
    } while (i0++ < 3u && (r0.y ^ (u0 - u0)));
    if ((r0.y / (0x80000000u | 1u))) {
        for (;;) { if (--fuel == 0u) goto done;
            m0 ^= (i0 / (u0 | 1u));
            if (a0[u1 & 3u]) goto L4;
            while (*mp) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + 6u);
                if ((unsigned)((int)(unsigned)(short)(unsigned)(8u < (unsigned)s1) >= (int)p0)) goto L4;
                if (budget != 0u) { budget -= 1u; u0 = fn0(3u, (unsigned)w0, (unsigned)(unsigned char)(unsigned)((short)(unsigned)((int)r0.y >= (int)*q0) > (signed char)p2)); }
                if (u1) break;
                c1 = (signed char)(((unsigned)c1 << (0x4cb7cbb7u & 31u)) * (unsigned)s1);
            }
            l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)f0 && u0) + 0x1152886au));
            *mp = ((unsigned)((int)(unsigned)c0 < (int)r0.x) ? i1 : -(unsigned)(9u == (unsigned)s1));
            w0 ^= (unsigned long long)0xf34681eu << ((g0 & ((unsigned)h0 % ((u2 | i2) | 1u))) & 63u);
        }
        if (u3 == 7u) return (unsigned)((unsigned)(5u && v0) == ((unsigned)f0 ^ 9u));
        if (i2) {
            goto done;
            goto done;
            if ((unsigned)((int)(unsigned)h0 >= (int)(unsigned)(x0 >> 70))) {
                c1 = (signed char)(unsigned)(w0 >> 29);
                s0 = (int)(unsigned)((short)*mp > (signed char)(unsigned)((unsigned)(x0 >> 70) < (unsigned)d0));
                while (((2u % ((unsigned)d0 | 1u)) + u0)) { if (--fuel == 0u) goto done;
                    if (((unsigned)b0 * (unsigned)w0)) continue;
                    continue; (void)((unsigned)(p1 < (unsigned)c0));
                    s0 = (int)(unsigned)((p2 & (unsigned)c0) < (unsigned)((int)(unsigned)e0 < (int)fuel));
                    if ((unsigned)(short)(a0[i0 & 3u] ^ 0x2869ad0cu)) break;
                    f0 = f0 * 0.5f + (float)(((3u * i0) % ((unsigned)(u2 < (unsigned)!(unsigned)((short)0xffffffffu > (signed char)0x80000000u)) | 1u)) & 255u);
                    break; (void)((unsigned)((short)(g0 ^ i2) > (signed char)garr[u2 & 7u]));
                }
                if ((0xffffffffu << ((unsigned)(signed char)(unsigned)((unsigned)(x0 >> 70) == a0[u1 & 3u]) & 31u))) goto L2;
                if (m0) goto L0;
                r0.y ^= 3u;
            }
            if (u3 == 7u) return (unsigned)(i1 < (m0 - ((unsigned)x0 % (u2 | 1u))));
            goto L4;
        } else {
            if (budget != 0u) { budget -= 1u; u3 = fn0((((unsigned)c0 / (0xb921ed86u | 1u)) % (0xae622699u | 1u)), (-(a0[i0 & 3u] / ((unsigned)c1 | 1u)) ^ (unsigned)e0), u3); }
            if (garr[u2 & 7u]) goto done;
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(i2);
                g0 = (unsigned)(short)(unsigned)((short)0x80000000u > (signed char)(unsigned)((short)0xc2471654u > (signed char)p1));
                r0.y ^= (0x46112e95u >> ((unsigned)((short)u1 > (signed char)(unsigned)c0) & 31u));
                x0 = x0 * 0x100000001b3ull + ((unsigned)b0 << ((unsigned)((int)*mp >= (int)a0[u1 & 3u]) & 31u));
                { unsigned t11; double z11; if (((((unsigned)h1 & 0xd5f1a92du) << (9u & 31u))) & 1u) { t11 = (a0[i0 & 3u] ^ (unsigned)f0); z11 = (double)(((unsigned)(x0 >> 70)) & 255u); } if (((((unsigned)h1 & 0xd5f1a92du) << (9u & 31u))) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
                    e0 = e0 * 0.5L + (long double)(((*q0 ? p0 : fuel) * (unsigned)((short)(unsigned)d0 > (signed char)fuel)) & 1023u);
                    x0 = x0 * 0x100000001b3ull + (u1 ^ (unsigned)c0);
                    f0 = f0 * 0.5f + (float)((0xffffffffu ^ ((unsigned)f0 ^ *mp)) & 255u);
                }
                continue; (void)(0xf02c9cf1u);
            }
            switch ((unsigned)((int)0xafa2417cu < (int)(unsigned)(short)((unsigned)d0 ^ 0xff826509u)) & 7u) {
                b0 = (0x3adeb628u + g0) != 0u;
                case 1u: ;
                goto done;
                w0 ^= (unsigned long long)-(unsigned)(0xffffffffu < (unsigned)h1) << (((a0[i0 & 3u] + (unsigned)(w0 >> 29)) % (0x7fffffffu | 1u)) & 63u);
                case 4u: ;
                if (g0) break;
            }
        }
    }
    c1 = (signed char)(0xbaa4c566u / ((unsigned)((int)u0 < (int)g0) | 1u));
    if (((unsigned)x0 / (0x4ceeda4bu | 1u))) goto L2;
    if ((unsigned)(0x349e854bu || (u1 + 0xb807d6b3u))) {
        if (budget != 0u) { budget -= 1u; u2 = fn1((0u & r0.x), (unsigned)(unsigned char)(r0.y / ((a0[u1 & 3u] % (0x10000u | 1u)) | 1u)), (unsigned)((short)(u3 | 0x8624d0c1u) > (signed char)(unsigned)w0)); }
        { unsigned t12; double z12; if ((-(unsigned)((int)(unsigned)h1 < (int)(unsigned)l0)) & 1u) { t12 = p0; z12 = (double)(((p1 & (unsigned)((unsigned)w0 < p2))) & 255u); } if ((-(unsigned)((int)(unsigned)h1 < (int)(unsigned)l0)) & 1u) { u3 += t12; d0 = d0 * 0.5 + z12; }
            if ((0x569c11d2u & u0)) goto L3;
            goto L0;
            do { if (--fuel == 0u) goto done;
                s0 = (int)(unsigned)((9u ? p2 : p2) && (3u | 0x10000u));
            } while (i0++ < 6u && (i2 ? p1 : *mp));
            u3 ^= (unsigned)(0x4fa3551au && a0[i0 & 3u]);
        }
        r0.y ^= (unsigned)((short)(unsigned)((int)(unsigned)h0 >= (int)1u) > (signed char)(1u & g1));
        i2 = (unsigned)((short)0x80000000u > (signed char)((unsigned)((int)(p2 >> ((unsigned)h0 & 31u)) >= (int)fuel) | p0)) & 15u;
    }
    goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)((int)r0.x >= (int)(unsigned)((int)garr[u2 & 7u] >= (int)0x7fffffffu))) {
        if (((unsigned)((unsigned)(x0 >> 70) || (unsigned)b0) / (u1 | 1u))) goto L1;
        if ((unsigned)((short)(0xca4c9038u + (unsigned)d0) > (signed char)m0)) {
            goto done;
            switch ((a0[i0 & 3u] << ((unsigned)c0 & 31u)) & 7u) {
                switch ((9u & m0) & 7u) {
                    case 1u: ;
                    if (((unsigned)(w0 >> 29) & (unsigned)s1)) {
                        case 5u: ;
                    } else {
                        w0 ^= (unsigned long long)((unsigned)f0 - (unsigned)d0) << ((unsigned)((4u << (a0[i0 & 3u] & 31u)) && ((m0 * (unsigned)(w0 >> 29)) | (unsigned)e0)) & 63u);
                        L0: if (--fuel == 0u) goto done;
                    }
                    *mp = (unsigned)((int)(unsigned)((short)0x10000u > (signed char)a0[i0 & 3u]) >= (int)u0);
                    h0 = (short)(unsigned)(short)((unsigned)((unsigned)((unsigned)((int)0x8d7734b7u < (int)g0) && (unsigned)x0) < (unsigned)b0) | p1);
                    default: ;
                    w0 ^= (unsigned long long)(m0 * (unsigned)d0) << ((unsigned)((int)m0 >= (int)(unsigned)((unsigned)b0 < p0)) & 63u);
                }
                case 3u: ;
                case 1u: ;
                if (i0) goto L2;
            }
            switch (((u0 | (unsigned)c0) * 1u) & 7u) {
                case 2u: ;
            }
            r0.y ^= ((i0 << (0x80000000u & 31u)) >> (*q0 & 31u));
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                *q0 = (((unsigned)!(0x10000u >> (g1 & 31u)) | g0) & ~((unsigned)w0 % (0xffffffffu | 1u)));
            }
            if (((unsigned)f0 << ((unsigned)e0 & 31u))) goto done;
        }
        L1: if (--fuel == 0u) goto done;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn2((5u << (fuel & 31u)), (0x5b1953cu * 0x9e1f0bdcu), ((unsigned)w0 ^ p2)); }
    goto L4;
    d0 = d0 * 0.5 + (double)((unsigned)((p0 | (unsigned)h0) && (unsigned)(signed char)((unsigned)s1 ? *mp : (unsigned)c0)) & 1023u);
    e0 = e0 * 0.5L + (long double)((unsigned)w0 & 1023u);
    while (((unsigned)w0 / ((p0 / (0x80000000u | 1u)) | 1u))) { if (--fuel == 0u) goto done;
        if ((v0 / (fuel | 1u))) goto done;
        if ((unsigned)((unsigned)w0 && (unsigned)(0x10000u < (unsigned)w0))) {
            b0 = (0x7fffffffu & 0xf9012052u) != 0u;
            v0 = (unsigned)((int)fuel < (int)(unsigned)(~(unsigned)(0x1e9fa402u == (unsigned)(x0 >> 70)) || -(unsigned)(u3 && (unsigned)w0)));
            while (~(0x4d88a772u ^ 0x80000000u)) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)(i2 || r0.x) << ((p1 ? 0x91274271u : 8u) & 63u);
                goto L4;
            }
        }
    }
    v0 = (unsigned)d0;
    L2: if (--fuel == 0u) goto done;
    switch (u3 & 7u) {
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)9u >= (int)0x80000000u), ((i0 & i2) >> (*mp & 31u)), *mp); }
        switch ((u1 | (unsigned)((unsigned)(w0 >> 29) == m0)) & 7u) {
            do { if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                { unsigned t0; double z0; if ((((unsigned)(short)(unsigned)((unsigned)f0 && (unsigned)(x0 >> 70)) >> ((unsigned)h0 & 31u))) & 1u) { t0 = (unsigned)(short)(v0 | (unsigned)d0); z0 = (double)((-((0x34668bd9u - i0) >> (p2 & 31u))) & 255u); } if ((((unsigned)(short)(unsigned)((unsigned)f0 && (unsigned)(x0 >> 70)) >> ((unsigned)h0 & 31u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                    u3 = (unsigned)((u2 & (unsigned)(x0 >> 70)) < (unsigned)b0);
                    u0 ^= (unsigned)(unsigned char)(unsigned)((unsigned)(g0 < (m0 & (unsigned)b0)) || u0);
                }
                break; (void)(((unsigned)d0 >> ((unsigned)h1 & 31u)));
                b0 = ((0xd0e4335au + ((unsigned)((int)i1 >= (int)r0.x) % (u3 | 1u))) & i2) != 0u;
            } while (i0++ < 4u && (((unsigned)e0 / (p2 | 1u)) + u3));
            *mp = ((unsigned)e0 - ((unsigned)!(8u & 0xffffffffu) & (0x10000u + p1)));
            while (i0++ < 4u && 0x80000000u) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)((int)0xc4aaf892u < (int)(unsigned)w0) && p1)) break;
                f0 = f0 * 0.5f + (float)(-(unsigned)((short)(unsigned)l0 > (signed char)((unsigned)((int)(unsigned)c0 < (int)0x80000000u) % (0x94d71418u | 1u))) & 255u);
                switch ((unsigned)((short)u2 > (signed char)0x80000000u) & 7u) {
                    *q0 += (unsigned)(0x10000u || ((unsigned)h0 - -(unsigned)((int)p0 < (int)(unsigned)s0)));
                    s0 = (int)(unsigned)((unsigned)s0 < (unsigned)d0);
                }
            }
            if ((m0 ^ *mp)) goto L4;
            case 1u: ;
            do { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)(8u < (unsigned)s1) || (unsigned)h1));
                if (fuel < 8u) return ((unsigned)(0x787453adu == (unsigned)c0) + ((unsigned)f0 >> (u1 & 31u)));
                if ((unsigned)(i0 == g1)) break;
            } while (i0++ < 5u && (unsigned)((unsigned)(w0 >> 29) < ((unsigned)c0 << (0x9eae65dcu & 31u))));
        }
    }
    if (((unsigned)c0 & garr[u2 & 7u])) {
        if ((8u - 0x12bf2102u)) goto L0;
        goto L4;
    } else {
        *mp = ((((unsigned)(x0 >> 70) << (a0[u1 & 3u] & 31u)) ^ 0u) >> (0xccf64e4eu & 31u));
    }
    goto done;
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)(i1 || (unsigned)l0), ((0x990c1cd7u << ((unsigned)h1 & 31u)) * (unsigned)h0), (unsigned)(signed char)(unsigned)((unsigned)f0 || 0x10000u)); }
    goto L1;
    if (0x7fffffffu) goto L4;
    for (;;) { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (0x7fffffffu ^ (0xadc0f0dcu - (unsigned)(0x45e2f651u == (unsigned)(fuel || (unsigned)s1))));
        g1 += (unsigned)((unsigned)d0 && 0x7fffffffu);
        continue; (void)((unsigned)s0);
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (0x4630e9bdu) {
                u2 ^= (7u * u3);
                while (i2++ < 7u && (unsigned)((unsigned)f0 && *q0)) { if (--fuel == 0u) goto done;
                    goto L3;
                    *mp = (unsigned)(signed char)(unsigned)((short)((unsigned)((int)r0.y < (int)r0.y) | (unsigned)h0) > (signed char)(unsigned)(i1 && (unsigned)f0));
                    u3 = u3 * 0x9e3779b1u + (unsigned)((int)2u < (int)(unsigned)((short)0x15070b8eu > (signed char)garr[u2 & 7u]));
                    if (~((unsigned)(w0 >> 29) & (unsigned)h1)) {
                        *mp = ((unsigned)h0 / ((unsigned)e0 | 1u));
                        b0 = ((unsigned)!((p2 | (unsigned)d0) ^ fuel) ? 0xacec484fu : a0[i0 & 3u]) != 0u;
                        l0 = (long)((unsigned long)l0 + (unsigned)h1);
                        break; (void)(*mp);
                    } else {
                        *mp = ((unsigned)b0 & ((unsigned)s1 ? 0x550f8f45u : *mp));
                        switch ((unsigned)d0 & 7u) {
                            case 3u: ;
                            i0 = (-(6u - (unsigned)(x0 >> 70)) % (a0[u1 & 3u] | 1u)) & 15u;
                            c1 = (signed char)3u;
                        }
                        if ((unsigned)((short)g0 > (signed char)0x80000000u)) {
                            if (0x35546714u) break;
                        } else {
                            h0 = (short)0x3804c675u;
                            *mp = (6u & r0.y);
                            d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)(0xffffffffu || i0) > (signed char)(r0.x / (i2 | 1u))) & 1023u);
                        }
                        *q0 = i2;
                    }
                    c1 = (signed char)((unsigned)s0 & (u1 & (unsigned)s0));
                }
            } else {
                m0 ^= u1;
                s0 = (int)((i2 >> (0x7fffffffu & 31u)) - (m0 + i2));
            }
            v0 = r0.y;
            while ((unsigned)((short)p2 > (signed char)(unsigned)b0)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)x0 || garr[u2 & 7u]), (r0.y ? 4u : 0x7fffffffu), 0x639fb73eu); }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(i1 == u0), (0x80000000u | ((unsigned)(x0 >> 70) / (a0[i0 & 3u] | 1u))), 0xaed2bd0cu); }
                if (0xb58b3985u) break;
                switch ((unsigned)((short)(unsigned)(signed char)(0x80000000u << ((unsigned)e0 & 31u)) > (signed char)(unsigned)c0) & 7u) {
                    c1 = (signed char)(v0 | m0);
                    case 3u: ;
                    i1 = ((unsigned)!((unsigned)(w0 >> 29) / (8u | 1u)) | ((unsigned)e0 / (1u | 1u))) & 15u;
                }
                i1 = (unsigned)((unsigned)((short)(unsigned)!(unsigned)((unsigned)(x0 >> 70) < 0x80000000u) > (signed char)g1) == (unsigned)!(0xffffffffu | 0x10000u)) & 15u;
                g1 += (((unsigned)(0x76310287u == u3) + 0x80000000u) << ((unsigned)c0 & 31u));
            }
            if ((i0 + (unsigned)s1)) {
                switch (u0 & 7u) {
                    if (0x409ee982u) break;
                    d0 = d0 * 0.5 + (double)((unsigned)h1 & 1023u);
                    do { if (--fuel == 0u) goto done;
                        u1 = (unsigned)(unsigned char)((0xffffffffu ^ 0xe795647au) % ((unsigned)b0 | 1u));
                        c1 = (signed char)((unsigned)((int)(unsigned)s1 < (int)(unsigned)w0) % ((unsigned)((int)2u >= (int)(u3 >> ((unsigned)s1 & 31u))) | 1u));
                        case 5u: ;
                        e0 = e0 * 0.5L + (long double)(g1 & 1023u);
                    } while (i2++ < 6u && (g1 + (0xf9af4f0cu << ((unsigned)x0 & 31u))));
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(9u < (unsigned)((unsigned)f0 == 0x10000u)), ((unsigned)b0 & 0x80000000u), 0x7fffffffu); }
                    do { if (--fuel == 0u) goto done;
                        h0 = (short)~(5u + ((unsigned)c0 * (unsigned)d0));
                        x0 = x0 * 0x100000001b3ull + (unsigned)h0;
                    } while (i2++ < 3u && 4u);
                    if (((unsigned)(0x10000u && *mp) >> (0x5cd5f283u & 31u))) continue;
                }
                if ((m0 * ((unsigned)h1 >> (i0 & 31u)))) break;
                d0 = d0 * 0.5 + (double)(((unsigned)c1 * (unsigned)(w0 >> 29)) & 1023u);
                if ((8u >> (7u & 31u))) {
                    d0 = d0 * 0.5 + (double)(((unsigned)l0 & ((unsigned)(x0 >> 70) << ((unsigned)c0 & 31u))) & 1023u);
                } else {
                    if ((unsigned)c1) continue;
                    break; (void)((unsigned)((int)(9u << (u2 & 31u)) >= (int)g0));
                    g1 += ((unsigned)x0 / (p2 | 1u));
                }
            } else {
                garr[(unsigned)(g1 || 0x922da24fu) & 7u] = (0x4b523503u % (i0 | 1u));
                c1 = (signed char)(((((unsigned)b0 & g0) - i2) / (u2 | 1u)) % (g1 | 1u));
                if (budget != 0u) { budget -= 1u; u3 = fn0(r0.x, (unsigned)((unsigned)w0 && (unsigned)l0), (unsigned)(signed char)(unsigned)(p0 < m0)); }
            }
            switch ((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)(v0 || 1u)) & 7u) {
                g1 += *mp;
                while (i2++ < 7u && (unsigned)d0) { if (--fuel == 0u) goto done;
                    m0 ^= (0x80000000u << ((unsigned)((short)*mp > (signed char)(0x7fffffffu | 0x80000000u)) & 31u));
                }
                case 7u: ;
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (0xc234645u) {
                        case 2u: ;
                        w0 = w0 * 6364136223846793005ull + *mp;
                        switch (m0 & 7u) {
                            if (u3 == 7u) return (unsigned)(u0 && 0xffffffffu);
                            e0 = e0 * 0.5L + (long double)(6u & 1023u);
                            w0 ^= (unsigned long long)(p2 * v0) << ((unsigned)(0x7fffffffu && (unsigned)c0) & 63u);
                            f0 = f0 * 0.5f + (float)((unsigned)((int)((0xc84011d6u - 0xadadced9u) | 0x7fffffffu) < (int)(unsigned)(short)(unsigned)((unsigned)w0 && p0)) & 255u);
                            b0 = (i1 % ((unsigned)(u2 == (unsigned)(w0 >> 29)) | 1u)) != 0u;
                            l0 = (long)((unsigned long)l0 + (((unsigned)h1 + 0x8eb30dc0u) | u0));
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn2((0x618bf966u + 0x5cbd08a9u), (unsigned)(v0 || *mp), (unsigned)(u0 || i0)); }
                    } else {
                        w0 ^= (unsigned long long)((unsigned)l0 - (unsigned)(x0 >> 70)) << ((unsigned)((int)(unsigned)s0 >= (int)(unsigned)x0) & 63u);
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)!(unsigned)((int)i2 >= (int)i2) && v0), (*mp >> ((unsigned)f0 & 31u)), (7u * 9u)); }
                        if (~(g0 + i1)) goto done;
                    }
                }
            }
        }
    }
    m0 ^= (unsigned)((unsigned)(short)(0x52fc67b2u | (unsigned)h1) < ((unsigned)!((unsigned)b0 + v0) / (0x10000u | 1u)));
    { unsigned t1; double z1; if ((((unsigned)(g1 && p2) >> ((unsigned)d0 & 31u))) & 1u) { t1 = ((a0[u1 & 3u] | u3) | (unsigned)h1); z1 = (double)(((m0 * garr[u2 & 7u])) & 255u); } if ((((unsigned)(g1 && p2) >> ((unsigned)d0 & 31u))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        if ((u0 * (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)garr[i1 & 7u]))) goto L2;
    }
    while (i0++ < 4u && ((unsigned)s0 + (unsigned)((short)u2 > (signed char)(unsigned)w0))) { if (--fuel == 0u) goto done;
        if ((unsigned)!(unsigned)(fuel || (unsigned)!(0xffffffffu << (i1 & 31u)))) {
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (i0) break;
                b0 = (unsigned)((unsigned)((int)8u < (int)0xffffffffu) == (unsigned)e0) != 0u;
                for (;;) { if (--fuel == 0u) goto done;
                    if (((unsigned)((short)(unsigned)x0 > (signed char)r0.x) << (v0 & 31u))) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(w0 >> 29) + (r0.x * 0xb385f523u)), ((unsigned)h0 >> (9u & 31u)), (unsigned)(0x7fffffffu || (unsigned)h0)); }
                }
                g1 += ((u3 ^ (unsigned)(0x80000000u == a0[u1 & 3u])) << (0x19f938f6u & 31u));
                s1 = (int)((unsigned)s1 + (unsigned)((short)2u > (signed char)i1));
                if (~((unsigned)(i1 < u2) | (unsigned)x0)) break;
            }
            do { if (--fuel == 0u) goto done;
                i0 = (r0.y + 6u) & 15u;
                g0 = (*q0 | 2u);
            } while (i1++ < 2u && (unsigned)((unsigned)x0 == (a0[u1 & 3u] << ((unsigned)x0 & 31u))));
            g1 += (unsigned)(0xffffffffu < (unsigned)f0);
        } else {
            if ((unsigned)h1) continue;
            u1 ^= (((i2 * -(u3 + (unsigned)s0)) * *q0) / (*mp | 1u));
            f0 = f0 * 0.5f + (float)(2u & 255u);
        }
        break; (void)((unsigned)((int)2u < (int)*q0));
        if (0x7fffffffu) break;
        switch ((unsigned)(0x31ade697u && (unsigned)x0) & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn1(i2, (unsigned)h1, p0); }
            if (7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)w0 / ((unsigned)((short)p0 > (signed char)0xffffffffu) | 1u)), (unsigned)((unsigned)l0 && (unsigned)((int)0xb3412e3fu >= (int)(unsigned)s0)), ((unsigned)(x0 >> 70) / (0x7fffffffu | 1u))); }
                garr[(unsigned)h1 & 7u] = (0x80000000u + (unsigned)w0);
                case 2u: ;
            } else {
                case 5u: ;
            }
            if ((unsigned)(unsigned char)(unsigned)((short)fuel > (signed char)5u)) break;
            if ((unsigned)((unsigned)(i2 == g1) && (unsigned)d0)) goto L0;
        }
        if ((unsigned)(x0 >> 70)) {
            garr[(unsigned)f0 & 7u] = 0x80000000u;
        }
        if (0xffffffffu) break;
    }
    e0 = e0 * 0.5L + (long double)((unsigned)(u2 < (unsigned)w0) & 1023u);
    if (budget != 0u) { budget -= 1u; u2 = fn1(fuel, 0x5bc78911u, (u1 / (0x31a4e74bu | 1u))); }
    u2 = ((unsigned)((int)7u >= (int)u2) + 0x80000000u);
    if (((garr[i1 & 7u] ^ garr[i1 & 7u]) | (unsigned)s0)) goto L3;
    if (budget != 0u) { budget -= 1u; u0 = fn2((u3 + 0xc9966b6u), (unsigned)(8u || 0x935a2d07u), p2); }
    if ((unsigned)((short)(8u & u2) > (signed char)(unsigned)c1)) {
        a0[(0xe77f34d9u - (unsigned)s1) & 3u] = (unsigned)(x0 >> 70);
        if (((r0.y >> ((unsigned)s1 & 31u)) << (0xaa521679u & 31u))) goto L3;
    } else {
        m0 ^= (unsigned)((int)(unsigned)c0 < (int)(unsigned)s1);
        { unsigned t2; double z2; if (((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)(signed char)((unsigned)w0 + *q0))) & 1u) { t2 = i0; z2 = (double)(((0xffffffffu | (unsigned)(w0 >> 29))) & 255u); } if (((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)(signed char)((unsigned)w0 + *q0))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            goto L4;
            goto L3;
            if (budget != 0u) { budget -= 1u; u0 = fn2((g1 + (unsigned)((short)0x7fffffffu > (signed char)p1)), (0x80000000u - (unsigned)l0), ((unsigned)c0 << (7u & 31u))); }
            b0 = (unsigned)(((unsigned)((unsigned)c1 || m0) % (1u | 1u)) == (unsigned)(signed char)(unsigned)(i1 < 0x215aec13u)) != 0u;
        }
        if ((unsigned)(unsigned char)(unsigned)((int)6u >= (int)u3)) goto L0;
        i1 = u0 & 15u;
    }
    r0.y ^= (6u / ((unsigned)(v0 < 0x80000000u) | 1u));
    v0 = (unsigned)((garr[i1 & 7u] * (unsigned)(x0 >> 70)) == (4u % ((0x7fffffffu & 1u) | 1u)));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)w0 & 7u) {
            if (((unsigned)f0 ^ u3)) continue;
            { unsigned t3; double z3; if (((unsigned)(unsigned char)(5u - (unsigned)(x0 >> 70))) & 1u) { t3 = (2u & r0.x); z3 = (double)(((unsigned)(short)(unsigned)((int)u3 < (int)garr[i1 & 7u])) & 255u); } if (((unsigned)(unsigned char)(5u - (unsigned)(x0 >> 70))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                if (budget != 0u) { budget -= 1u; u3 = fn2((((unsigned)c1 - garr[u2 & 7u]) << (7u & 31u)), (unsigned)(signed char)(unsigned)(0x8f696f4u < p2), *q0); }
                { unsigned t4; double z4; if (((unsigned)((int)i2 < (int)0xba055966u)) & 1u) { t4 = (g1 ^ v0); z4 = (double)(((garr[u2 & 7u] - 0xc42df642u)) & 255u); } if (((unsigned)((int)i2 < (int)0xba055966u)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    while ((unsigned)(garr[i1 & 7u] || u1)) { if (--fuel == 0u) goto done;
                        case 5u: ;
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn1((((unsigned)b0 * 0x7fffffffu) | p1), u2, *mp); }
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        goto L2;
                        if ((unsigned)((int)(g1 & 0x37dc3f10u) >= (int)u2)) continue;
                    }
                    default: ;
                    case 7u: ;
                    b0 = (unsigned)((i1 ^ ((unsigned)((unsigned)(w0 >> 29) < m0) >> (0xc0763e08u & 31u))) < (unsigned)c1) != 0u;
                }
                case 2u: ;
                break;
            }
            s1 = (int)((unsigned)s1 + (unsigned)((0x7fffffffu & (i0 - (unsigned)(x0 >> 70))) || (unsigned)(v0 < 0x2cf22041u)));
            switch (4u & 7u) {
                g1 += (p0 % ((unsigned)(0x80000000u && 0x40bb1c94u) | 1u));
            }
            if (budget != 0u) { budget -= 1u; u1 = fn1(u0, (*mp & -(unsigned)((int)0x80000000u < (int)r0.y)), (unsigned)(r0.x || u1)); }
        }
        if ((unsigned)(x0 >> 70)) continue;
        break; (void)((unsigned)(signed char)(unsigned)((int)1u < (int)(unsigned)(2u < (unsigned)s0)));
        if (budget != 0u) { budget -= 1u; u1 = fn1((a0[i0 & 3u] & (0x752e921bu | i2)), (unsigned)((unsigned)h0 < (unsigned)!(unsigned)((unsigned)s1 && u0)), (v0 | 0x7fffffffu)); }
        break; (void)(garr[i1 & 7u]);
        b0 = ((m0 ^ ~(garr[u2 & 7u] % (0x37176e6au | 1u))) | (unsigned)(w0 >> 29)) != 0u;
    }
    if ((unsigned)((0x80000000u + v0) == 4u)) goto done;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((0xffffffffu << (*mp & 31u)));
        while (i1++ < 4u && (unsigned)((short)u3 > (signed char)p0)) { if (--fuel == 0u) goto done;
            while (i2++ < 4u && (unsigned)(unsigned char)(i2 % (6u | 1u))) { if (--fuel == 0u) goto done;
                i1 = (fuel / ((unsigned)(v0 || i1) | 1u)) & 15u;
                r0.y ^= (3u / (0u | 1u));
                s0 = (int)(unsigned)((int)(unsigned)((int)((*mp & u0) << (i1 & 31u)) < (int)fuel) < (int)u3);
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(x0 >> 70), (0x7fffffffu ^ (g1 % ((unsigned)c1 | 1u))), (unsigned)(unsigned char)(0x8aa03fa9u ? 0x80000000u : 0x7fffffffu)); }
                u3 = (unsigned)(m0 < (unsigned)e0);
            }
            break; (void)((r0.y << (2u & 31u)));
            break; (void)(((unsigned)(x0 >> 70) << ((0x80000000u << ((unsigned)h1 & 31u)) & 31u)));
        }
    }
    u3 ^= (0x83915a75u - a0[i0 & 3u]);
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(0xf47020eeu ? 6u : (unsigned)s0) >= (int)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)0xbcaa19d2u));
    goto done;
    if ((unsigned)((int)g1 >= (int)6u)) goto L0;
    switch (((u2 * a0[u1 & 3u]) << (r0.x & 31u)) & 7u) {
        if ((unsigned)(a0[u1 & 3u] < p2)) goto L1;
        if (budget != 0u) { budget -= 1u; u0 = fn0(*q0, (unsigned)(short)((unsigned)((short)*q0 > (signed char)(unsigned)s0) | (unsigned)(w0 >> 29)), (0xdf4fbfcau ^ 0u)); }
        x0 = x0 * 0x100000001b3ull + ((unsigned)e0 | r0.x);
    }
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)e0, (unsigned)w0, ((unsigned)x0 % ((0x7fffffffu * a0[i0 & 3u]) | 1u))); }
    { unsigned t5; double z5; if (((0x7fffffffu + 2u)) & 1u) { t5 = (unsigned)c1; z5 = (double)((((unsigned)w0 / (-(unsigned)(p2 < i0) | 1u))) & 255u); } if (((0x7fffffffu + 2u)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
        if ((unsigned)(unsigned char)(((unsigned)l0 & p2) | 0x80000000u)) goto L3;
        if ((unsigned)(0x1a839f38u == i0)) {
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (*mp) break;
                h0 = (short)(unsigned)((int)(unsigned)b0 < (int)0xf09952acu);
                while (i1++ < 2u && (0xb4faac91u ^ 0x63802c75u)) { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)e0;
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(u1 == ((unsigned)f0 >> (u3 & 31u))), ((unsigned)d0 ? u0 : i2), (i1 % ((unsigned)((int)*mp >= (int)r0.y) | 1u))); }
                    if ((r0.x * garr[i1 & 7u])) break;
                    if (budget != 0u) { budget -= 1u; u1 = fn2((0xe1f2a168u >> (((unsigned)s1 - p2) & 31u)), (unsigned)w0, i2); }
                    d0 = d0 * 0.5 + (double)((unsigned)h0 & 1023u);
                }
                c1 = (signed char)(unsigned)((short)(unsigned)((short)0x10000u > (signed char)0x80000000u) > (signed char)(garr[i1 & 7u] << (0x5d0986bdu & 31u)));
                *mp = ((p2 & i0) / (p2 | 1u));
                if ((unsigned)(unsigned char)(unsigned)((int)i0 >= (int)(unsigned)e0)) continue;
            }
            f0 = f0 * 0.5f + (float)((((unsigned)b0 << ((8u >> (garr[i1 & 7u] & 31u)) & 31u)) - (4u << (r0.y & 31u))) & 255u);
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)h0, (unsigned)((int)(unsigned)(v0 && 0xfd06d6du) >= (int)m0), g1); }
            if (0x80000000u) {
                if (budget != 0u) { budget -= 1u; u2 = fn0(0x8c2de089u, ((r0.y % (7u | 1u)) * (unsigned)h1), (unsigned)l0); }
                s1 = (int)((unsigned)s1 + (u1 | ((unsigned)w0 * (unsigned)w0)));
                if ((((unsigned)f0 ^ (unsigned)w0) % (a0[u1 & 3u] | 1u))) {
                    if (v0) goto L0;
                }
                if (u0) {
                    *mp = (unsigned)((short)6u > (signed char)(a0[u1 & 3u] >> (~(0x14b6b232u % (6u | 1u)) & 31u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((unsigned)b0 || ((unsigned)l0 << ((unsigned)h0 & 31u))), (unsigned)(3u || (unsigned)(signed char)(unsigned)(u2 && (unsigned)b0)), a0[i0 & 3u]); }
                    if ((unsigned)((int)p0 >= (int)v0)) {
                        i0 = 0x2459a091u & 15u;
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(w0 >> 29) / (u2 | 1u)), (unsigned)l0, (unsigned)((int)(unsigned)(signed char)((unsigned)w0 & u3) < (int)p1)); }
                    if ((unsigned)(m0 && ~(i1 + m0))) goto L0;
                    goto L1;
                } else {
                    q0 = &garr[(unsigned)((int)(unsigned)(short)((unsigned)h0 - 0x80000000u) < (int)(unsigned)c1) & 7u];
                    for (;;) { if (--fuel == 0u) goto done;
                        break; (void)(garr[u2 & 7u]);
                        x0 = x0 * 0x100000001b3ull + 0x10000u;
                        if (a0[i0 & 3u]) continue;
                        e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)((unsigned)s1 / ((0x10000u - g0) | 1u)) & 1023u);
                        if ((unsigned)((unsigned)f0 < (0xffffffffu ^ 0x80000000u))) continue;
                    }
                }
                h0 = (short)(unsigned)s1;
                goto L1;
            } else {
                if ((unsigned)!(unsigned)((unsigned)(unsigned char)((unsigned)c1 | (unsigned)s0) == (unsigned)w0)) goto L0;
                s0 = (int)(unsigned)!((unsigned)(garr[i1 & 7u] || 0xffffffffu) << ((unsigned)((int)(unsigned)f0 >= (int)(unsigned)l0) & 31u));
                if (u3 == 7u) return ((unsigned)s0 * (unsigned)!(unsigned)((int)u3 < (int)i0));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn2(((p0 ^ 0u) / (a0[u1 & 3u] | 1u)), (unsigned)(x0 >> 70), (unsigned)h0); }
        }
    }
    g0 = (r0.x ? g1 : (unsigned)(9u == garr[i1 & 7u]));
    goto L1;
    u3 += (unsigned)((short)m0 > (signed char)u2);
    h1 = (unsigned short)(h1 + (0x80000000u >> ((unsigned)b0 & 31u)));
    goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *q0 += ((unsigned)w0 & (r0.y & 0x7fffffffu));
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            for (;;) { if (--fuel == 0u) goto done;
                *q0 += (r0.x % (i2 | 1u));
            }
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                *q0 += ((unsigned)s1 + (unsigned)((unsigned)(signed char)(unsigned)((unsigned)s0 < i0) == (r0.x & 0u)));
                d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)((short)u3 > (signed char)garr[i1 & 7u])) == (unsigned)h1) & 1023u);
                if (((unsigned)((short)v0 > (signed char)(unsigned)(x0 >> 70)) & i0)) break;
                goto L1;
                if (u3 == 7u) return (u0 << (0x5a5c643u & 31u));
            }
            w0 = w0 * 6364136223846793005ull + 0x7fffffffu;
        } while (i1++ < 5u && u3);
        switch (((unsigned)(unsigned char)(unsigned)((unsigned)c1 < a0[u1 & 3u]) + (unsigned)b0) & 7u) {
            L0: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((short)g1 > (signed char)(unsigned)s0), (unsigned)(unsigned char)(unsigned)(5u && garr[u2 & 7u]), ((unsigned)c1 - (unsigned)(u2 < 0xffffffffu))); }
            h0 = (short)~(unsigned)((unsigned)(unsigned char)(v0 << (garr[u2 & 7u] & 31u)) || (0x10000u + a0[i0 & 3u]));
            u1 = u1 * 0x9e3779b1u + ((0xf5262d21u - u2) + 0xc172f856u);
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 2u: ;
                if (a0[i0 & 3u]) {
                    s0 = (int)((u0 ^ i1) | i1);
                    case 3u: ;
                    c0 = (unsigned char)(a0[i0 & 3u] << ((0x18b94196u / ((unsigned)d0 | 1u)) & 31u));
                }
                switch ((unsigned)((int)u0 < (int)(0u & 0x558b2debu)) & 7u) {
                    g1 += (unsigned)(p1 && *q0);
                    l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)c0 ? g1 : (m0 ^ *q0)) < (unsigned)d0));
                    while (i2++ < 7u && g1) { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + (a0[i0 & 3u] / ((unsigned)((unsigned)d0 && (g0 | u3)) | 1u)));
                        u0 = (unsigned)((int)(m0 >> (0xffffffffu & 31u)) < (int)(unsigned)b0);
                        if (fuel < 8u) return (garr[i1 & 7u] / (u3 | 1u));
                        if (budget != 0u) { budget -= 1u; u0 = fn1((u3 & 0x80000000u), ((unsigned)d0 ^ p0), (unsigned)((int)fuel < (int)(unsigned)!(3u - u3))); }
                    }
                    *mp = (unsigned)((int)u1 < (int)(unsigned)((unsigned)c0 || g1));
                    case 0u: ;
                }
                if ((unsigned)((int)u2 >= (int)(unsigned)c0)) {
                    l0 = (long)((unsigned long)l0 + u1);
                }
                s1 = (int)((unsigned)s1 + ((unsigned)(g1 || (g1 / (m0 | 1u))) + 4u));
            }
        }
        *q0 = (unsigned)((unsigned)c1 == (unsigned)h1);
        break; (void)(((unsigned)b0 / ((unsigned)l0 | 1u)));
        if (0xffffffffu) {
            break; (void)((m0 ^ u2));
            L1: if (--fuel == 0u) goto done;
            q0 = &garr[(unsigned)((int)a0[i0 & 3u] >= (int)fuel) & 7u];
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    u0 ^= (*q0 + (unsigned)(m0 == 0xffffffffu));
                    c1 = (signed char)(unsigned)((short)(unsigned)h0 > (signed char)(unsigned)w0);
                    break; (void)((i2 | (unsigned)h1));
                    u3 = u3 * 0x9e3779b1u + (unsigned)(unsigned char)(p0 | (unsigned)((int)(unsigned)d0 < (int)((unsigned)c1 >> (m0 & 31u))));
                    h0 = (short)((0x7597bca4u ^ ((unsigned)b0 << ((unsigned)c1 & 31u))) / ((g0 % (u3 | 1u)) | 1u));
                    if (budget != 0u) { budget -= 1u; u2 = fn3(0xc191cea1u, 0x7fffffffu, (0x484d7c14u / ((unsigned)d0 | 1u))); }
                }
                if ((unsigned)(9u < (unsigned)((unsigned)c0 && (unsigned)w0))) goto L3;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((u3 >> (0x7fffffffu & 31u))) continue;
                    h1 = (unsigned short)(h1 + (((unsigned)s0 << (i0 & 31u)) * 0x7fffffffu));
                }
                if (((unsigned)h0 ? u2 : (unsigned)l0)) continue;
            }
            w0 ^= (unsigned long long)i1 << (~((unsigned)(5u || 0x80000000u) / (u3 | 1u)) & 63u);
            if (u3 == 7u) return (unsigned)(signed char)(g1 + garr[i1 & 7u]);
        } else {
            break; (void)(0x33e12697u);
        }
        if ((0x9871ec6au >> (0xa3e02047u & 31u))) goto L1;
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + ((unsigned)((int)v0 < (int)(unsigned)e0) + (garr[i1 & 7u] << ((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)b0) & 31u))));
        if (budget != 0u) { budget -= 1u; u1 = fn1((p0 ^ ((unsigned)w0 & 0x7fffffffu)), ((unsigned)w0 | ((unsigned)d0 % ((unsigned)s0 | 1u))), (unsigned)(-((unsigned)h0 / ((unsigned)(w0 >> 29) | 1u)) || 0xffffffffu)); }
        g0 = ((unsigned)(a0[i0 & 3u] < a0[i0 & 3u]) + (unsigned)((int)(unsigned)x0 < (int)a0[i0 & 3u]));
        switch ((unsigned)(0xffffffffu < ((unsigned)s1 << (3u & 31u))) & 7u) {
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)(unsigned)(p1 || (0xeac38ee4u + (unsigned)w0)), -(unsigned)((short)(unsigned)(p1 && u0) > (signed char)0xa752b697u), (unsigned)(((unsigned)l0 & 0xde9a2400u) < (unsigned)s0)); }
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)((short)4u > (signed char)*mp), ((unsigned)s0 + v0), (p0 << (p2 & 31u))); }
                switch ((~((unsigned)(x0 >> 70) % (r0.y | 1u)) | m0) & 7u) {
                    L2: if (--fuel == 0u) goto done;
                    if ((unsigned)(signed char)(u3 / ((unsigned)((int)(unsigned)b0 < (int)*q0) | 1u))) break;
                    v0 = (0u % (((unsigned)f0 >> ((unsigned)(u0 == garr[i1 & 7u]) & 31u)) | 1u));
                    if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((short)0x43072a09u > (signed char)(unsigned)(0xe4ccee27u || u0)), p1, (unsigned)((0x99d89e3eu - 4u) && (unsigned)b0)); }
                }
                u2 ^= (unsigned)!(unsigned)(u0 && ((unsigned)!(0xc309f6e7u + ~(garr[i1 & 7u] % ((unsigned)h0 | 1u))) << (r0.x & 31u)));
            } while (i1++ < 7u && (unsigned)(signed char)(unsigned)((5u - i2) && (unsigned)(w0 >> 29)));
            goto L1;
            if ((unsigned)(r0.y && (unsigned)s0)) {
                r0.x = -((unsigned)s0 - 0xe5968711u);
                case 5u: ;
                case 7u: ;
            }
        }
        L3: if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)((unsigned)(unsigned char)((unsigned)l0 - (unsigned)((short)(unsigned)b0 > (signed char)i1)) == ((unsigned)w0 * i2)));
    }
    L4: if (--fuel == 0u) goto done;
    if ((0x98ea9fd9u & (g1 - p2))) goto L3;
    u2 += (unsigned)(*mp < ((unsigned)(x0 >> 70) & (unsigned)(g0 < (unsigned)(fuel || 1u))));
    r0.x = ((unsigned)((short)(g0 + garr[u2 & 7u]) > (signed char)(unsigned)(i0 && u2)) * 0x7fffffffu);
    goto L2;
    if (a0[i0 & 3u]) goto done;
    r0.y ^= r0.y;
    if ((unsigned)(unsigned char)(0xe98a5d66u | r0.y)) {
        { unsigned t0; double z0; if ((0xf733643u) & 1u) { t0 = (((unsigned)c0 | fuel) >> ((unsigned)x0 & 31u)); z0 = (double)((((u1 / (0x80000000u | 1u)) >> ((unsigned)l0 & 31u))) & 255u); } if ((0xf733643u) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            while (i0++ < 6u && (garr[i1 & 7u] % ((unsigned)f0 | 1u))) { if (--fuel == 0u) goto done;
                i2 = ((7u - (unsigned)l0) ? 0u : 0x1b570aa4u) & 15u;
                while (i1++ < 7u && a0[i0 & 3u]) { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)p0 > (signed char)*mp)) break;
                    g0 = ((unsigned)((fuel % ((unsigned)h1 | 1u)) || 0x19e9625du) << ((u1 >> (i0 & 31u)) & 31u));
                    break; (void)((i1 << ((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)l0) & 31u)));
                    if ((unsigned)(a0[u1 & 3u] == a0[u1 & 3u])) goto done;
                }
                if ((9u >> ((0x7fffffffu >> ((unsigned)x0 & 31u)) & 31u))) break;
                v0 = (unsigned)!(0x10000u & (*mp * 0x1064af13u));
                g0 = (unsigned)(((unsigned)c1 ? (unsigned)c0 : a0[u1 & 3u]) == (a0[u1 & 3u] >> (0xca8891abu & 31u)));
                if (2u) continue;
            }
        }
        if ((unsigned)((v0 >> (u3 & 31u)) < (unsigned)(x0 >> 70))) {
            if (budget != 0u) { budget -= 1u; u0 = fn3(0xa1c5c67cu, ((unsigned)((int)*mp >= (int)g0) << ((unsigned)b0 & 31u)), ((unsigned)(w0 >> 29) % ((unsigned)(w0 >> 29) | 1u))); }
            if ((unsigned)(a0[u1 & 3u] && 4u)) goto L3;
            do { if (--fuel == 0u) goto done;
                i2 = u0 & 15u;
                if ((*q0 ? (unsigned)c0 : a0[i0 & 3u])) {
                    if (((fuel >> ((unsigned)(x0 >> 70) & 31u)) + 6u)) break;
                } else {
                    s0 = (int)((unsigned)((unsigned)(0xf2f610deu && g0) == g0) ^ (p1 % (0xcfbf47e6u | 1u)));
                    do { if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)(0xeec9d7bcu & 1023u);
                    } while (i1++ < 7u && (unsigned)((int)(unsigned)(u1 && 4u) < (int)8u));
                    u0 += (~(i2 ? (unsigned)h0 : (unsigned)f0) & (unsigned)(signed char)(unsigned)(i0 || 0x80000000u));
                    *q0 += ((unsigned)((short)(((unsigned)(x0 >> 70) / (9u | 1u)) / ((unsigned)h1 | 1u)) > (signed char)0x3ef0afa5u) * 0x641b8d35u);
                }
                *q0 = (i0 | (unsigned)(((unsigned)c0 / (i1 | 1u)) && garr[i1 & 7u]));
                a0[(unsigned)((int)a0[u1 & 3u] >= (int)i0) & 3u] = (fuel >> ((p0 * (unsigned)d0) & 31u));
            } while (i0++ < 4u && 0x80000000u);
        }
        if (u3) {
            if (((unsigned)l0 ^ ~(0x80000000u * 0xee2281f9u))) goto done;
            while ((unsigned)((short)((unsigned)l0 >> ((unsigned)w0 & 31u)) > (signed char)2u)) { if (--fuel == 0u) goto done;
                goto done;
                u2 ^= (unsigned)((0x8672cbb5u * u3) || (((unsigned)h1 * (unsigned)e0) & 0xf683fb92u));
                *q0 += (unsigned)((unsigned)s1 || v0);
                { unsigned t1; double z1; if (((i2 ^ (i0 & (unsigned)e0))) & 1u) { t1 = ((unsigned)h1 - (unsigned)b0); z1 = (double)((0x37c1eadeu) & 255u); } if (((i2 ^ (i0 & (unsigned)e0))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    if ((~(0x80000000u * g0) % ((unsigned)e0 | 1u))) goto L4;
                    w0 = w0 * 6364136223846793005ull + (unsigned)(x0 >> 70);
                    u0 = u0 * 0x9e3779b1u + (unsigned)(unsigned char)(0xfc7b8189u << (0x8f9eb20fu & 31u));
                    g0 = ((unsigned)((int)(unsigned)((unsigned)b0 && fuel) >= (int)0xf2d27311u) + (0x1bafb571u << (a0[u1 & 3u] & 31u)));
                    c0 = (unsigned char)(unsigned)(g0 < (unsigned)(short)(unsigned)(0xffffffffu || 0xffffffffu));
                }
                v0 = g1;
            }
            if (-((unsigned)((int)g1 >= (int)m0) - (unsigned)l0)) {
                if (fuel < 8u) return 0x7fffffffu;
                if (budget != 0u) { budget -= 1u; u1 = fn2(0x7c786bfu, (i2 ^ (unsigned)w0), (r0.y - (unsigned)(unsigned char)(0x10000u >> ((unsigned)l0 & 31u)))); }
                u2 += (unsigned)!(unsigned)((int)7u < (int)r0.x);
            } else {
                if (((unsigned)((int)m0 >= (int)u3) - r0.x)) goto L0;
                u0 = (unsigned)!(3u / (u1 | 1u));
                do { if (--fuel == 0u) goto done;
                    if (~(a0[i0 & 3u] % ((unsigned)w0 | 1u))) break;
                } while (i0++ < 5u && ((0x2dd34dbdu / ((unsigned)b0 | 1u)) & 6u));
            }
            e0 = e0 * 0.5L + (long double)(0x30bb87a8u & 1023u);
            if (((unsigned)(x0 >> 70) / ((unsigned)b0 | 1u))) {
                f0 = f0 * 0.5f + (float)((unsigned)((a0[u1 & 3u] ^ 0x7372e6dbu) || i2) & 255u);
                if ((unsigned)f0) goto L2;
                if (((unsigned)e0 - *q0)) goto done;
                u0 ^= (u3 | (unsigned)h0);
                for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (garr[u2 & 7u]) break;
                    m0 ^= ((unsigned)(*mp < (unsigned)(fuel && a0[u1 & 3u])) << (u3 & 31u));
                    s1 = (int)((unsigned)s1 + 0xb6057c5u);
                    i1 = (unsigned)(short)(unsigned)((int)((unsigned)f0 | 0xffffffffu) >= (int)p2) & 15u;
                    i2 = ((unsigned)(*mp == -((unsigned)x0 | (unsigned)c1)) & (unsigned)l0) & 15u;
                }
            } else {
                b0 = (((unsigned)b0 ^ u2) | 4u) != 0u;
                { unsigned t2; double z2; if ((u0) & 1u) { t2 = (unsigned)(signed char)(unsigned)(g0 == u2); z2 = (double)(((unsigned)((short)(unsigned)x0 > (signed char)-(unsigned)((short)(unsigned)h1 > (signed char)u1))) & 255u); } if ((u0) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    e0 = e0 * 0.5L + (long double)(((unsigned)(p2 && (unsigned)(x0 >> 70)) ? i0 : (unsigned)h0) & 1023u);
                    if ((fuel ^ r0.x)) goto L2;
                    if (budget != 0u) { budget -= 1u; u3 = fn2((garr[i1 & 7u] / (0x4a808951u | 1u)), (unsigned)(1u < (unsigned)h0), (u1 * (unsigned)h1)); }
                    do { if (--fuel == 0u) goto done;
                        if (fuel < 8u) return (((r0.y * 0xcdb1e251u) ^ (unsigned)c1) * ~(unsigned)(0xc1e8e8b2u || 0x7fffffffu));
                        if ((unsigned)h1) break;
                    } while (i0++ < 3u && (g1 << ((unsigned)d0 & 31u)));
                    { unsigned t3; double z3; if ((i1) & 1u) { t3 = garr[i1 & 7u]; z3 = (double)((i1) & 255u); } if ((i1) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        w0 ^= (unsigned long long)0x9e816653u << (0xffffffffu & 63u);
                        if ((unsigned)s1) goto L2;
                        { unsigned t4; double z4; if (((unsigned)(0x80000000u < (unsigned)f0)) & 1u) { t4 = (unsigned)(u3 && (unsigned)x0); z4 = (double)((0xd5e1c5bdu) & 255u); } if (((unsigned)(0x80000000u < (unsigned)f0)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                            if (0x10000u) goto L2;
                            q0 = &garr[(p1 % (i0 | 1u)) & 7u];
                        }
                        if ((unsigned)((int)r0.y < (int)((unsigned)h0 % ((unsigned)h0 | 1u)))) goto L3;
                        l0 = (long)((unsigned long)l0 + ((p1 + (unsigned)(signed char)(unsigned)(r0.x == i2)) << ((g0 * (unsigned)x0) & 31u)));
                    }
                    if ((unsigned)((unsigned)h1 == 0x8e3396aau)) goto L2;
                }
            }
        }
        if ((unsigned)((unsigned)((int)i2 >= (int)p0) && (unsigned)b0)) goto L0;
        r0.y ^= (0x5ee575b3u - fuel);
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(garr[i1 & 7u] == (i2 + 5u)), (0x8aa2a734u * p0), (v0 & v0)); }
    }
    garr[r0.y & 7u] = (unsigned)!(garr[i1 & 7u] % ((unsigned)((int)*q0 >= (int)(unsigned)b0) | 1u));
    if ((u2 & 0x7469893u)) goto L1;
    d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)(0x4fabe996u < i2) < (int)((unsigned)(x0 >> 70) + (unsigned)c0)) & 1023u);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(0x7fffffffu && (unsigned)e0)) {
            if (budget != 0u) { budget -= 1u; u2 = fn3(*mp, (r0.x - 0x7fffffffu), (unsigned)(0x10000u == 0x6245f20u)); }
            *q0 += (0u | r0.y);
            b0 = ((garr[u2 & 7u] << (u1 & 31u)) & 0u) != 0u;
            while (i1++ < 5u && (garr[i1 & 7u] >> ((unsigned)s1 & 31u))) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (~(garr[u2 & 7u] + (unsigned)((short)fuel > (signed char)*mp)) * u2));
                garr[((unsigned)h0 ^ 1u) & 7u] = (unsigned)((int)(0x7fffffffu << ((unsigned)c1 & 31u)) >= (int)(u1 / (0x8b75e2acu | 1u)));
            }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn2((m0 % ((unsigned)(u1 == m0) | 1u)), (unsigned)!(unsigned)((int)(unsigned)(0x10000u || fuel) >= (int)0x7fffffffu), (unsigned)((int)*mp >= (int)~(unsigned)((int)0x7fffffffu < (int)(unsigned)c0))); }
        u1 = (9u / (((0x10000u + -(unsigned)(0x10000u == garr[i1 & 7u])) / (p0 | 1u)) | 1u));
        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((int)(unsigned)h0 >= (int)0xffffffffu) && g0));
        if (p2) break;
        switch ((unsigned)((unsigned)h1 == r0.y) & 7u) {
            if (((unsigned)(i0 == i0) ^ (unsigned)c1)) continue;
            case 0u: ;
            u2 = ((unsigned)h1 & 0x87829d62u);
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn3(u2, ((unsigned)h1 ? (unsigned)s0 : (unsigned)c0), ((unsigned)(0x25ebcb2fu < 0x10000u) % (u1 | 1u))); }
    u2 = u2 * 0x9e3779b1u + ((1u | (unsigned)(*mp && v0)) + (unsigned)h0);
    if (u0) goto L1;
    if (u2) goto L3;
    *q0 = (i1 ? -(unsigned)(g0 || (a0[u1 & 3u] * p2)) : (unsigned)x0);
    if (((unsigned)(fuel == r0.y) | 0x4b61a179u)) {
        *mp = (unsigned)s1;
        if ((0xffffffffu * 9u)) goto L1;
        if (-(u3 / (0xb446d8fau | 1u))) goto L3;
        goto L1;
        u1 += ((g1 | (unsigned)w0) - (unsigned)e0);
        if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)l0, r0.x, 0xc0867a03u); }
    }
    { unsigned t5; double z5; if (((unsigned)(w0 >> 29)) & 1u) { t5 = 7u; z5 = (double)((((garr[i1 & 7u] >> (0x6cc1a7au & 31u)) & fuel)) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
        u2 += (0x7fffffffu / ((unsigned)(0x99209d02u < v0) | 1u));
    }
    while ((i1 << (u1 & 31u))) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0(garr[i1 & 7u], (unsigned)(unsigned char)((unsigned)x0 % (u3 | 1u)), (unsigned)(unsigned char)(unsigned)((int)u1 >= (int)0xbf294c67u)); }
        goto done;
        c1 = (signed char)~(0x10000u + (unsigned)w0);
        v0 = (0x59d91a05u ? (unsigned)c1 : 6u);
        c1 = (signed char)-(unsigned)((unsigned)(short)((unsigned)(v0 || u1) << (9u & 31u)) || 0xba104285u);
    }
    goto L0;
    if (u3 == 7u) return ((g0 & 0xffffffffu) ? -((unsigned)s0 | (unsigned)e0) : (unsigned)(x0 >> 70));
    if ((a0[u1 & 3u] % ((unsigned)((unsigned)c0 == u0) | 1u))) {
        if (budget != 0u) { budget -= 1u; u1 = fn3((5u << ((unsigned)s1 & 31u)), (i0 - (unsigned)c0), 9u); }
        for (;;) { if (--fuel == 0u) goto done;
            c1 = (signed char)0x10000u;
        }
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((fuel * i1) && (unsigned)(x0 >> 70)), ((unsigned)(w0 >> 29) - v0), (unsigned)((int)(r0.x << ((unsigned)x0 & 31u)) >= (int)p2)); }
            *mp = 0x7fffffffu;
            e0 = e0 * 0.5L + (long double)((0x4b9eb47fu ? 0xffffffffu : g0) & 1023u);
            h1 = (unsigned short)(h1 + (u3 ^ (unsigned)h1));
            if (r0.y) break;
        } while (i0++ < 5u && ((unsigned)f0 & 0x7fffffffu));
    }
    r0.x = ((unsigned)w0 / ((unsigned)((short)(unsigned)(9u < p1) > (signed char)((unsigned)l0 * i2)) | 1u));
    goto L3;
    if (budget != 0u) { budget -= 1u; u3 = fn3((((unsigned)h1 & garr[i1 & 7u]) / (v0 | 1u)), *q0, (4u + (unsigned)(unsigned char)(unsigned)((unsigned)l0 == 0x10000u))); }
    switch ((unsigned)(short)(unsigned)((int)1u < (int)(*q0 % (0x985fbb62u | 1u))) & 7u) {
        if ((*q0 << ((unsigned)(w0 >> 29) & 31u))) {
            *q0 += (p0 % (*q0 | 1u));
            if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)s0 & 6u), (unsigned)((0xffffffffu * (unsigned)d0) || (unsigned)s1), ((unsigned)(unsigned char)(9u & u2) - 0x7fffffffu)); }
            while (i0++ < 7u && ((unsigned)(signed char)(p1 - (unsigned)d0) << (u3 & 31u))) { if (--fuel == 0u) goto done;
                *mp = (unsigned)(unsigned char)((*mp ^ (unsigned)e0) & ~(0x9a9e2be9u % ((g1 >> (0x7fffffffu & 31u)) | 1u)));
                if (0xe2d8c248u) {
                    if ((u3 | garr[i1 & 7u])) goto L2;
                    { unsigned t6; double z6; if (((0x4c031d4fu % (a0[u1 & 3u] | 1u))) & 1u) { t6 = (unsigned)(unsigned char)(0x7fffffffu ? (unsigned)h1 : (unsigned)x0); z6 = (double)(((unsigned)((unsigned)e0 && 0xe198df6fu)) & 255u); } if (((0x4c031d4fu % (a0[u1 & 3u] | 1u))) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                        while ((0x80000000u >> (0x10000u & 31u))) { if (--fuel == 0u) goto done;
                            e0 = e0 * 0.5L + (long double)(((unsigned)((short)0xffffffffu > (signed char)u3) % ((i0 ^ (unsigned)w0) | 1u)) & 1023u);
                            s0 = (int)(unsigned)((int)(unsigned)c0 < (int)(g1 / (0xfd9b160cu | 1u)));
                            case 1u: ;
                            h1 = (unsigned short)(h1 + (2u / (p2 | 1u)));
                            case 3u: ;
                        }
                        *mp = (unsigned)(signed char)(unsigned)((unsigned)(unsigned char)((a0[i0 & 3u] >> (i2 & 31u)) % (u2 | 1u)) < garr[i1 & 7u]);
                    }
                    if (fuel < 8u) return (unsigned)((unsigned)(w0 >> 29) && (unsigned)((int)(unsigned)((unsigned)(5u && (unsigned)d0) == (unsigned)h0) >= (int)0x10000u));
                    a0[r0.x & 3u] = (unsigned)(unsigned char)(p0 + ((((unsigned)h0 + 0x1cb2f800u) << ((unsigned)b0 & 31u)) ^ 1u));
                    case 7u: ;
                    case 5u: ;
                }
            }
            u0 ^= (unsigned)w0;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn3(2u, (0x7fffffffu - a0[u1 & 3u]), ((u3 >> (3u & 31u)) | garr[i1 & 7u])); }
        l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)(unsigned char)(*mp * 0u) || (unsigned)x0) * u0));
        break; (void)(((unsigned)c1 >> (i1 & 31u)));
        m0 ^= ((unsigned)((unsigned)w0 && 5u) ^ (unsigned)(u1 < m0));
        c1 = (signed char)(unsigned)(short)(unsigned)((0xffffffffu & ((1u & v0) & garr[u2 & 7u])) && 2u);
    }
    if (0xf8a8a9cbu) {
        if (budget != 0u) { budget -= 1u; u1 = fn1((0xdd00f86cu << (0u & 31u)), (unsigned)((short)((unsigned)h1 << ((unsigned)h0 & 31u)) > (signed char)(unsigned)(x0 >> 70)), (unsigned)((8u * (unsigned)s1) && (unsigned)(w0 >> 29))); }
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)!(r0.y << (garr[i1 & 7u] & 31u)), (0x38d828cbu ? (unsigned)s0 : 0x29d33299u), 0x597475a3u); }
        w0 = w0 * 6364136223846793005ull + a0[i0 & 3u];
        if (budget != 0u) { budget -= 1u; u2 = fn0((9u ^ (unsigned)(3u && v0)), (unsigned)(short)(unsigned)(0xf1304d02u || p1), 5u); }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)0x157d5c66u > (signed char)(unsigned)((short)7u > (signed char)(unsigned)(w0 >> 29))), (u2 >> ((i2 * (unsigned)w0) & 31u)), (unsigned)((int)(unsigned)((int)0x7606bccdu < (int)i2) >= (int)(unsigned)s0)); }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((*mp * g1)) {
            u1 = u1 * 0x9e3779b1u + (unsigned)(garr[u2 & 7u] < 0xffffffffu);
            e0 = e0 * 0.5L + (long double)(((unsigned)s1 / (v0 | 1u)) & 1023u);
            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((0x45a7f99u - ((unsigned)b0 | 0x531e0588u)) && 7u) && (unsigned)(w0 >> 29)));
            if (i2) break;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(unsigned)((int)((unsigned)h1 << (u3 & 31u)) < (int)g1), ((unsigned)((unsigned)c1 == (unsigned)w0) & r0.x), (unsigned)!(4u & 0xb8ffa2f9u)); }
        q0 = &garr[(unsigned)((unsigned)(short)(g0 >> ((unsigned)w0 & 31u)) && (v0 & (0xffffffffu << ((unsigned)d0 & 31u)))) & 7u];
    }
    l0 = (long)((unsigned long)l0 + (unsigned)((int)0x37d4f089u >= (int)(p2 % (*mp | 1u))));
    switch ((9u * a0[i0 & 3u]) & 7u) {
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)h0) break;
            g1 += ((unsigned)((unsigned)f0 || v0) / (((unsigned)c1 << (m0 & 31u)) | 1u));
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                g0 = (((garr[u2 & 7u] | 0xffffffffu) / ((5u >> ((unsigned)l0 & 31u)) | 1u)) & v0);
            }
            garr[0x60916f67u & 7u] = (unsigned)((0x10000u >> (r0.x & 31u)) == v0);
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((((unsigned)w0 - 0u) << ((unsigned)b0 & 31u))) break;
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        u3 ^= i2;
                        r0.x = (v0 % ((((unsigned)c0 - (unsigned)((unsigned)e0 && i0)) - 0x10000u) | 1u));
                        case 2u: ;
                        m0 ^= *mp;
                        u3 += (unsigned)(signed char)(unsigned)((int)p2 < (int)0xa2ce9d86u);
                    } while (i0++ < 3u && (unsigned)l0);
                    default: ;
                    case 0u: ;
                }
                if (u3 == 7u) return (garr[u2 & 7u] - (unsigned)(unsigned char)((unsigned)s0 / (0x80000000u | 1u)));
                f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)l0 >= (int)-(9u / (*q0 | 1u))) & 255u);
                *mp = ((unsigned)f0 | 0x10000u);
            }
        }
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)b0 == ((unsigned)((short)(unsigned)h1 > (signed char)p1) << ((unsigned)w0 & 31u))) & 255u);
        case 1u: ;
        r0.x = ((unsigned)(~(u1 << ((unsigned)h0 & 31u)) || garr[u2 & 7u]) & (m0 >> (r0.y & 31u)));
    }
    if ((unsigned)((short)0xffffffffu > (signed char)u2)) goto L3;
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)r0.x >= (int)r0.x), a0[u1 & 3u], 0x1aa7503eu); }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 7u && i0) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                break; (void)(3u);
                while (i0++ < 3u && 0xefdab70du) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(unsigned)((int)5u >= (int)2u);
                    continue; (void)((unsigned)(r0.x && ((unsigned)w0 % (9u | 1u))));
                    if (budget != 0u) { budget -= 1u; u2 = fn2(*mp, 0x80000000u, (unsigned)(r0.y && (unsigned)(short)(unsigned)((int)g1 < (int)0xf0ee26abu))); }
                }
                break; (void)(((m0 >> (0x50eba016u & 31u)) ^ (unsigned)e0));
            } while (i2++ < 6u && (unsigned)(short)((unsigned)d0 % ((unsigned)(x0 >> 70) | 1u)));
            if ((unsigned)d0) continue;
            if (budget != 0u) { budget -= 1u; u2 = fn2(~(0x80000000u | 0xfb1fd398u), ~(unsigned)(r0.x == (unsigned)(r0.x == 0xf2c20171u)), ((u3 - (unsigned)l0) >> ((unsigned)d0 & 31u))); }
            if (5u) break;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)c0, (unsigned)(i2 == (unsigned)(w0 >> 29)), 0x7fffffffu); }
            if (i0) break;
        }
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(9u < (unsigned)(*mp || fuel))) break;
        i2 = (u0 / (((unsigned)(x0 >> 70) ? 6u : u0) | 1u)) & 15u;
        switch (((unsigned)(w0 >> 29) + (u3 | 0xffffffffu)) & 7u) {
            s1 = (int)((unsigned)s1 + (unsigned)(5u && (unsigned)w0));
            if ((unsigned)(a0[i0 & 3u] || ((unsigned)b0 >> (0x80000000u & 31u)))) break;
            case 0u: ;
            while (i1++ < 3u && 0x10000u) { if (--fuel == 0u) goto done;
                case 5u: ;
                { unsigned t7; double z7; if (((unsigned)c1) & 1u) { t7 = ((unsigned)s0 % (p2 | 1u)); z7 = (double)(((unsigned)((int)a0[u1 & 3u] < (int)(*mp << (0xffffffffu & 31u)))) & 255u); } if (((unsigned)c1) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                    if (budget != 0u) { budget -= 1u; u0 = fn3(*mp, (unsigned)(i1 && (unsigned)(signed char)(0xffffffffu >> ((unsigned)f0 & 31u))), (unsigned)((int)(unsigned)e0 >= (int)(unsigned)s0)); }
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(a0[i0 & 3u], (0xc0806c3cu << (m0 & 31u)), (unsigned)d0); }
            }
        }
    }
    if ((unsigned)((int)g0 < (int)(unsigned)(w0 >> 29))) {
        h1 = (unsigned short)(h1 + 0xdc17f039u);
        g1 += 0x7fffffffu;
        goto L2;
    } else {
        c0 = (unsigned char)((unsigned)h0 ^ p2);
        m0 ^= (unsigned)((short)(unsigned)b0 > (signed char)(unsigned)(short)(u3 ^ ((unsigned)w0 + 0x10000u)));
        d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)x0 >= (int)(unsigned)((short)(unsigned)b0 > (signed char)i1)) & 1023u);
    }
    if (((unsigned)((short)(unsigned)b0 > (signed char)8u) ^ u3)) goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 11u, 0xeceb5070u, 0xf72ab333u },
        { 9u, 0x86d62d4cu, 0xb4767ecu },
        { 10u, 0x2c161c78u, 0x2ddd5847u },
        { 12u, 0x3adc9d4fu, 0xcea2b597u },
        { 14u, 0x1123fcfdu, 0x4832af4bu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
