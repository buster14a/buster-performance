// test-ssa-source's program of seed 141000426 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x11c9b314u, g1 = 0x5fe27abcu;
static unsigned garr[8] = { 0x658361cbu, 0xe920b305u, 0x82ce6861u, 0xe6965b4cu, 0xfc999au, 0x8aeb4987u, 0x734bd9ccu, 0x7ee1594cu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    l0 = (long)((unsigned long)l0 + ((unsigned)((int)(unsigned)h0 < (int)((unsigned)!(unsigned)(5u && i0) << (p0 & 31u))) - 0x5b0b0f4eu));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)((0u / (garr[i1 & 7u] | 1u)) % (((unsigned)s1 | -(p1 >> (m0 & 31u))) | 1u));
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(5u / ((garr[u2 & 7u] * (9u ^ (unsigned)((int)(unsigned)h0 >= (int)0x7fffffffu))) | 1u));
        r0.x = ((unsigned)((unsigned)(unsigned char)(unsigned)((short)3u > (signed char)(unsigned)x0) == 0x10000u) >> ((4u + 0x7fffffffu) & 31u));
    }
    switch (0x80000000u & 7u) {
        L0: if (--fuel == 0u) goto done;
        switch (((unsigned)(g1 && *q0) & r0.y) & 7u) {
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                v0 = (0x80000000u ? (unsigned)h1 : (unsigned)((short)(v0 ^ i1) > (signed char)i0));
                { unsigned t0; double z0; if ((m0) & 1u) { t0 = (unsigned)((unsigned)c0 == m0); z0 = (double)(((unsigned)((int)(0xffffffffu << (*q0 & 31u)) >= (int)p0)) & 255u); } if ((m0) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                    case 3u: ;
                    L1: if (--fuel == 0u) goto done;
                    L2: if (--fuel == 0u) goto done;
                    goto L2;
                    if ((3u - -(*q0 - *mp))) break;
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)0xd52d82acu < (int)((g1 - u0) | (unsigned)((short)0u > (signed char)0x71c212a1u)));
                case 1u: ;
                if ((((unsigned)s0 % (2u | 1u)) % (0x10000u | 1u))) continue;
            }
            case 6u: ;
        }
    }
    if ((unsigned)w0) goto L1;
    if ((0u & (u1 ^ 8u))) {
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)fuel >= (int)(0xb849d4e4u & garr[u2 & 7u]));
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
                if (0xa4d25965u) {
                    L4: if (--fuel == 0u) goto done;
                    h0 = (short)(unsigned)((int)(unsigned)!((unsigned)(x0 >> 70) >> (*mp & 31u)) >= (int)((unsigned)(w0 >> 29) >> ((unsigned)s1 & 31u)));
                    u3 = u3 * 0x9e3779b1u + (unsigned)((int)i1 < (int)i1);
                }
                { unsigned t1; double z1; if ((((g0 | (unsigned)f0) * garr[u2 & 7u])) & 1u) { t1 = (unsigned)((unsigned)((int)(unsigned)(w0 >> 29) < (int)v0) || i2); z1 = (double)(((unsigned)!((unsigned)l0 + (unsigned)e0)) & 255u); } if ((((g0 | (unsigned)f0) * garr[u2 & 7u])) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    e0 = e0 * 0.5L + (long double)((unsigned)(((unsigned)x0 << (*mp & 31u)) == (a0[u1 & 3u] ? (unsigned)w0 : 7u)) & 1023u);
                    if ((a0[u1 & 3u] >> ((unsigned)e0 & 31u))) break;
                    if ((g1 + (unsigned)!(unsigned)((short)0xe98f6b6du > (signed char)r0.y))) break;
                    h1 = (unsigned short)(h1 + ((unsigned)(p0 < u3) * r0.x));
                }
                continue; (void)((unsigned)((short)0xf4d4a489u > (signed char)(0xffffffffu % (garr[u2 & 7u] | 1u))));
            }
        }
        if ((unsigned)!(r0.x >> (g1 & 31u))) {
            q0 = &garr[(unsigned)((int)p0 >= (int)(unsigned)d0) & 7u];
            h1 = (unsigned short)(h1 + (unsigned)(-(0x10000u + p2) && u2));
            v0 = (m0 ^ ((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)s0) + m0));
            *mp = ((unsigned)h1 << (*q0 & 31u));
            do { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(0x80000000u & 255u);
                if ((unsigned)(short)(g1 * 0xe0730af9u)) goto L2;
                u1 = (unsigned)h0;
                c1 = (signed char)(unsigned)(a0[i0 & 3u] && 0x80000000u);
                m0 ^= ((unsigned)(x0 >> 70) << (0xb3b91e4bu & 31u));
            } while (i0++ < 5u && u0);
            goto L1;
        }
        goto L4;
        if (~(unsigned)((short)0u > (signed char)u2)) goto L1;
    } else {
        goto L1;
        *q0 = ((unsigned)c0 >> ((0x7fffffffu - i1) & 31u));
        v0 = ((r0.y & 3u) ^ ((unsigned)((short)u2 > (signed char)u3) ^ (unsigned)f0));
    }
    v0 = fuel;
    goto L3;
    goto L2;
    goto L0;
    garr[(unsigned)x0 & 7u] = (garr[i1 & 7u] >> (0x10000u & 31u));
    if ((unsigned)(a0[i0 & 3u] < 3u)) goto L4;
    x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((unsigned)((short)(unsigned)((int)garr[u2 & 7u] < (int)0x7fffffffu) > (signed char)0x80000000u) / (garr[i1 & 7u] | 1u));
    h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)((short)(u2 % ((unsigned)((int)(unsigned)b0 >= (int)0xffffffffu) | 1u)) > (signed char)8u) >= (int)p1));
    if (*mp) goto L1;
    do { if (--fuel == 0u) goto done;
        r0.y ^= (*q0 >> (((unsigned)w0 / (m0 | 1u)) & 31u));
        u1 ^= (u3 & (unsigned)((int)(unsigned)((int)0xffffffffu < (int)0x2151ed2au) >= (int)(unsigned)l0));
        { unsigned t2; double z2; if ((((unsigned)(x0 >> 70) - a0[u1 & 3u])) & 1u) { t2 = 2u; z2 = (double)((((unsigned)(i1 < u3) | 4u)) & 255u); } if ((((unsigned)(x0 >> 70) - a0[u1 & 3u])) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            q0 = &garr[(unsigned)!(unsigned)((unsigned)((unsigned)c1 == m0) == ((unsigned)h1 * i1)) & 7u];
            if ((p0 >> ((unsigned)((unsigned)(w0 >> 29) && 0x87fecdb4u) & 31u))) break;
            u0 ^= (p1 * (unsigned)s0);
            if (*q0) break;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(*q0 == 0xffffffffu)) break;
                u1 = (unsigned)(8u || (unsigned)(unsigned char)(unsigned)((int)g0 < (int)(*q0 % ((unsigned)e0 | 1u))));
            } while (i1++ < 2u && a0[i0 & 3u]);
            { unsigned t3; double z3; if (((unsigned)(signed char)(garr[u2 & 7u] % (a0[i0 & 3u] | 1u))) & 1u) { t3 = ((r0.x & (unsigned)s1) & 3u); z3 = (double)(((0x81344ffbu - u0)) & 255u); } if (((unsigned)(signed char)(garr[u2 & 7u] % (a0[i0 & 3u] | 1u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                s0 = (int)((*mp - 0x10000u) << ((unsigned)e0 & 31u));
                u0 ^= (unsigned)(r0.x < i2);
                m0 ^= (((unsigned)c1 - (unsigned)f0) | (unsigned)(unsigned char)(u1 ? 0xffffffffu : u1));
                w0 ^= (unsigned long long)fuel << (((unsigned)(i0 || 0xb2d33871u) ^ (unsigned)(unsigned char)(g1 >> (r0.x & 31u))) & 63u);
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t4; double z4; if (((unsigned)s0) & 1u) { t4 = (unsigned)((unsigned)f0 < u2); z4 = (double)((r0.y) & 255u); } if (((unsigned)s0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                        v0 = (u2 % (v0 | 1u));
                        x0 = x0 * 0x100000001b3ull + 7u;
                        if (((unsigned)x0 << ((unsigned)((unsigned)s1 == (unsigned)d0) & 31u))) break;
                        if ((r0.y >> ((unsigned)f0 & 31u))) break;
                        do { if (--fuel == 0u) goto done;
                            if ((unsigned)(unsigned char)(p1 | (unsigned)(w0 >> 29))) break;
                            s1 = (int)((unsigned)s1 + (0x10000u << ((unsigned)((short)(unsigned)c1 > (signed char)0xffffffffu) & 31u)));
                            f0 = f0 * 0.5f + (float)(-(0xffffffffu / (-(unsigned)((int)-(unsigned)((int)-(unsigned)((short)7u > (signed char)garr[i1 & 7u]) < (int)p2) >= (int)a0[u1 & 3u]) | 1u)) & 255u);
                            if ((0x791ae0d8u * garr[i1 & 7u])) break;
                            l0 = (long)((unsigned long)l0 + r0.y);
                            g0 = ((0x10000u + (unsigned)((int)(unsigned)e0 < (int)(unsigned)((int)i2 < (int)i1))) + 5u);
                        } while (i2++ < 3u && (unsigned)(unsigned char)(0x850cb48cu | u0));
                        h0 = (short)((unsigned)((unsigned)s1 < (unsigned)h1) / ((unsigned)e0 | 1u));
                    }
                    if ((unsigned)(m0 == (p0 ^ *mp))) goto L0;
                    *q0 = (0x80000000u / (r0.y | 1u));
                    if ((unsigned)(g1 || ((unsigned)c1 >> (a0[i0 & 3u] & 31u)))) continue;
                    w0 = w0 * 6364136223846793005ull + (unsigned)(0xffffffffu && a0[i0 & 3u]);
                }
                if (*mp) goto L4;
            }
        }
        if ((unsigned)(garr[u2 & 7u] == *mp)) break;
    } while (i0++ < 6u && ((unsigned)l0 << (0x7fffffffu & 31u)));
    { unsigned t5; double z5; if ((((unsigned)(short)(unsigned)(0x8b1861b6u < 3u) | (unsigned)h1)) & 1u) { t5 = (unsigned)((short)(unsigned)((short)m0 > (signed char)u3) > (signed char)(unsigned)e0); z5 = (double)(((unsigned)!(unsigned)((int)i1 < (int)i1)) & 255u); } if ((((unsigned)(short)(unsigned)(0x8b1861b6u < 3u) | (unsigned)h1)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
        a0[(unsigned)!(a0[u1 & 3u] << ((unsigned)f0 & 31u)) & 3u] = (3u | p0);
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t6; double z6; if (((0xffffffffu / (r0.y | 1u))) & 1u) { t6 = 0x67fc145au; z6 = (double)(((unsigned)((unsigned)b0 == (unsigned)(w0 >> 29))) & 255u); } if (((0xffffffffu / (r0.y | 1u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                break; (void)((unsigned)(signed char)(unsigned)((unsigned)f0 && (0x7fffffffu ^ 2u)));
                v0 = v0;
                *q0 = (unsigned)(r0.y && ((m0 * *q0) * ((unsigned)h0 / (4u | 1u))));
                u3 = (unsigned)c0;
                if ((4u | (7u - p1))) break;
                w0 = w0 * 6364136223846793005ull + ((unsigned)f0 * 0xea184802u);
            }
            { unsigned t7; double z7; if ((((unsigned)(w0 >> 29) ? 9u : 0xf1c399c8u)) & 1u) { t7 = ~(3u * (unsigned)((int)0xc58ab253u < (int)(unsigned)d0)); z7 = (double)(((((unsigned)w0 / (i0 | 1u)) - (unsigned)f0)) & 255u); } if ((((unsigned)(w0 >> 29) ? 9u : 0xf1c399c8u)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                { unsigned t8; double z8; if (((unsigned)((int)fuel < (int)(unsigned)(p2 && p2))) & 1u) { t8 = (u1 << (0x90f358feu & 31u)); z8 = (double)((((unsigned)c1 + u1)) & 255u); } if (((unsigned)((int)fuel < (int)(unsigned)(p2 && p2))) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                    if ((unsigned)e0) break;
                    if (u2) goto L3;
                    if ((~((unsigned)(w0 >> 29) >> (p1 & 31u)) % (0x10000u | 1u))) break;
                    for (;;) { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)(*mp / (8u | 1u)) >= (int)0xdfda798du)) break;
                        break; (void)((0x2dc3c8b6u * (unsigned)h0));
                        l0 = (long)((unsigned long)l0 + p0);
                        r0.x = ((g0 ^ *mp) - (0x59dffa29u / (u0 | 1u)));
                        if ((0x2efcd575u << (7u & 31u))) break;
                    }
                    r0.x = ((unsigned)((int)fuel >= (int)(unsigned)((int)8u < (int)0xffffffffu)) + 0x89d0711du);
                }
                break; (void)((unsigned)e0);
                if (u3 == 7u) return (~((unsigned)s0 + g0) + g0);
                r0.x = ((unsigned)w0 * i2);
                if ((unsigned)(g0 == (0xffffffffu >> (8u & 31u)))) {
                    if (((unsigned)((int)(unsigned)s1 >= (int)(unsigned)(w0 >> 29)) << (0x28c36619u & 31u))) break;
                    for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + v0);
                        f0 = f0 * 0.5f + (float)((unsigned)(g0 && (unsigned)((int)(unsigned)((short)i2 > (signed char)r0.y) < (int)(unsigned)c0)) & 255u);
                        goto L4;
                        u0 += ((unsigned)((short)(garr[u2 & 7u] / (g1 | 1u)) > (signed char)(0xda8db54au >> (p0 & 31u))) + r0.x);
                        if ((unsigned)c1) break;
                        v0 = ((unsigned)((unsigned)h0 == 0x80000000u) - (g0 & 0x7fffffffu));
                    }
                    x0 = x0 * 0x100000001b3ull + (0xffffffffu ^ (unsigned)(w0 >> 29));
                    if ((unsigned)((unsigned)w0 < (unsigned)e0)) break;
                    if (((unsigned)(8u || (unsigned)c1) << (p2 & 31u))) break;
                    f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)s0 < (int)garr[i1 & 7u]) & 255u);
                } else {
                    w0 = w0 * 6364136223846793005ull + ((unsigned)d0 | u0);
                    b0 = (unsigned)h0 != 0u;
                    r0.x = -(unsigned)((unsigned)((unsigned)h0 && (unsigned)(unsigned char)(unsigned)((int)garr[i1 & 7u] >= (int)u3)) == 0x49ec58b4u);
                }
            }
            a0[(unsigned)c0 & 3u] = *mp;
            if (*q0) break;
        }
        c1 = (signed char)0x80000000u;
        if (u3 == 7u) return ((unsigned)!((unsigned)(0x21154340u == (unsigned)((int)(unsigned)h0 < (int)0x6f1fc9bdu)) >> (u1 & 31u)) - a0[i0 & 3u]);
        u1 = u1 * 0x9e3779b1u + (unsigned)((int)(unsigned)c1 < (int)(unsigned)!((unsigned)x0 << ((unsigned)((i1 & 8u) < p1) & 31u)));
        a0[(u0 >> (0x6d677dcu & 31u)) & 3u] = ~((unsigned)d0 << ((u2 | 0xb0221f11u) & 31u));
    }
    if ((unsigned)((int)0xffffffffu >= (int)(unsigned)h1)) {
        if ((v0 % ((unsigned)((unsigned)s1 == 0x80000000u) | 1u))) goto L2;
        if (((garr[u2 & 7u] % (0x7fffffffu | 1u)) << (i1 & 31u))) goto done;
        goto L4;
        *q0 += (unsigned)((unsigned)f0 || (unsigned)((int)fuel >= (int)u3));
        { unsigned t9; double z9; if (((unsigned)((unsigned)h1 < (unsigned)(0x789e5954u == u2))) & 1u) { t9 = garr[i1 & 7u]; z9 = (double)((*q0) & 255u); } if (((unsigned)((unsigned)h1 < (unsigned)(0x789e5954u == u2))) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((u2 ? (unsigned)b0 : r0.x));
                if ((garr[i1 & 7u] % (0xffffffffu | 1u))) break;
                break; (void)(a0[i0 & 3u]);
                if (-((unsigned)s1 / (p0 | 1u))) break;
                if ((unsigned)((short)(a0[i0 & 3u] & i0) > (signed char)i2)) {
                    g1 += ((unsigned)((short)(0x1e38dffdu ^ (0x80000000u % (9u | 1u))) > (signed char)r0.x) << (9u & 31u));
                    u0 = ((unsigned)c0 / (((unsigned)l0 << (p0 & 31u)) | 1u));
                    d0 = d0 * 0.5 + (double)(g0 & 1023u);
                    continue; (void)((unsigned)(garr[i1 & 7u] && garr[i1 & 7u]));
                }
                b0 = (unsigned)(signed char)((unsigned)b0 << (p0 & 31u)) != 0u;
            }
            do { if (--fuel == 0u) goto done;
                if ((-(unsigned)((short)(unsigned)l0 > (signed char)i2) >> (4u & 31u))) break;
                break; (void)(((unsigned)e0 >> (0x36f513edu & 31u)));
                switch ((unsigned)(x0 >> 70) & 7u) {
                    case 4u: ;
                    case 1u: ;
                    c1 = (signed char)(unsigned)(short)(unsigned)((int)(unsigned)w0 < (int)(0x10000u ^ u0));
                    if (0x10000u) continue;
                    *q0 += (0x9d8c3a4bu / (p2 | 1u));
                    f0 = f0 * 0.5f + (float)(0xe8493b83u & 255u);
                }
                e0 = e0 * 0.5L + (long double)((a0[u1 & 3u] ^ a0[i0 & 3u]) & 1023u);
                u0 = (unsigned)((int)0xec818505u < (int)(unsigned)(short)((unsigned)(x0 >> 70) & (unsigned)e0));
            } while (i0++ < 2u && 0xffffffffu);
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)((unsigned)(unsigned char)(unsigned)((int)0x10000u >= (int)(unsigned)f0) < (unsigned)!(0x8ff35bdu ? garr[u2 & 7u] : r0.y)));
                v0 = ((unsigned)((unsigned)s1 < (unsigned)d0) * ((a0[u1 & 3u] - u0) ^ i2));
            }
        }
    }
    *q0 += ((unsigned)h1 - 0xfd30a38cu);
    goto L0;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(unsigned)((int)(unsigned)l0 >= (int)(v0 >> (0x5cabec67u & 31u))));
        } while (i1++ < 3u && u3);
        if (0x80000000u) break;
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)0xb1f9144fu < (int)0u);
    switch ((0x605f56efu / (u2 | 1u)) & 7u) {
        v0 = (2u ^ 7u);
    }
    *mp = (unsigned)!(5u | ((unsigned)(p0 && (unsigned)h1) | (unsigned)s0));
    if ((0x5da7624fu << ((unsigned)(w0 >> 29) & 31u))) {
        l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)((int)2u < (int)(unsigned)d0));
        s0 = (int)(unsigned)((int)i1 >= (int)v0);
        u1 = u1 * 0x9e3779b1u + (unsigned)(*mp == (9u + (unsigned)(w0 >> 29)));
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)(x0 >> 70);
        b0 = (u3 % (~(p2 % ((unsigned)f0 | 1u)) | 1u)) != 0u;
        while (5u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if (((unsigned)((int)0xc7478b9cu >= (int)(unsigned)c0) + (unsigned)e0)) break;
                if (((i0 - 0x6727a560u) + (unsigned)f0)) break;
                if (~((unsigned)(x0 >> 70) ^ u2)) break;
                if ((g1 + r0.x)) break;
                if (((unsigned)l0 % ((unsigned)(unsigned char)(unsigned)((int)u2 >= (int)g0) | 1u))) break;
            } while (i2++ < 2u && 0x80000000u);
            *mp = ((unsigned)(0x92087a51u == (unsigned)d0) + (unsigned)(garr[i1 & 7u] < (unsigned)((short)u0 > (signed char)(unsigned)x0)));
            d0 = d0 * 0.5 + (double)((unsigned)((int)((unsigned)s0 & (*q0 * u2)) >= (int)fuel) & 1023u);
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(0xffffffffu == (unsigned)h1)) break;
                if (((unsigned)d0 | ((unsigned)f0 * g0))) break;
                a0[((unsigned)h0 >> (4u & 31u)) & 3u] = (unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)fuel >= (int)7u) >= (int)(7u * ((unsigned)h0 % (u0 | 1u))));
                switch ((unsigned)((int)(unsigned)b0 >= (int)u3) & 7u) {
                    u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)((int)0x9a193205u < (int)g0) == u1);
                }
                if ((unsigned)!((unsigned)(garr[i1 & 7u] == u1) << (0x2148531au & 31u))) goto L0;
            } while (i2++ < 5u && (unsigned)(unsigned char)((r0.x - 0xffffffffu) / (7u | 1u)));
        }
    }
    while (i0++ < 7u && 0xffffffffu) { if (--fuel == 0u) goto done;
        continue; (void)(((unsigned)((int)0u < (int)(unsigned)c1) * (unsigned)h1));
        { unsigned t10; double z10; if ((((unsigned)((short)(unsigned)h1 > (signed char)(unsigned)s0) * r0.y)) & 1u) { t10 = (unsigned)(0x8de6908du == a0[i0 & 3u]); z10 = (double)(((unsigned)h1) & 255u); } if ((((unsigned)((short)(unsigned)h1 > (signed char)(unsigned)s0) * r0.y)) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((0x80000000u * i1) & 1023u);
            }
            u0 = (unsigned)(x0 >> 70);
            l0 = (long)((unsigned long)l0 + (unsigned)((a0[i0 & 3u] + fuel) == g0));
        }
        do { if (--fuel == 0u) goto done;
            if (((unsigned)h1 * (unsigned)((int)0x1b8da037u < (int)*q0))) goto L2;
            do { if (--fuel == 0u) goto done;
                if ((u0 * (unsigned)f0)) {
                    i0 = (unsigned)!(0x80000000u + (unsigned)((unsigned)h0 && (unsigned)w0)) & 15u;
                } else {
                    if (((unsigned)s0 << (u3 & 31u))) break;
                    if ((unsigned)((short)(r0.x % (p2 | 1u)) > (signed char)0xffffffffu)) {
                        v0 = (unsigned)(0xa951075du || (u3 ^ (unsigned)s0));
                        u3 += (unsigned)(unsigned char)((r0.x - (unsigned)((short)r0.y > (signed char)0x9c125a82u)) / ((unsigned)!(unsigned)(0x80000000u == g0) | 1u));
                        u1 ^= ((unsigned)(0xd9a0b306u == 0x1bc4ae71u) * (0x80000000u >> ((unsigned)h1 & 31u)));
                    } else {
                        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                            h0 = (short)((unsigned)((unsigned)s0 || (unsigned)((int)u1 < (int)(v0 + g0))) * i2);
                        }
                    }
                    break; (void)(((unsigned)e0 % ((i2 << (p2 & 31u)) | 1u)));
                    c1 = (signed char)(unsigned)((int)(unsigned)w0 >= (int)(r0.x & (unsigned)h0));
                }
                if ((unsigned)(*mp || 1u)) goto L3;
                h1 = (unsigned short)(h1 + (1u ^ r0.x));
                r0.y ^= (unsigned)(w0 >> 29);
                f0 = f0 * 0.5f + (float)(u2 & 255u);
                { unsigned t11; double z11; if (((u1 + 2u)) & 1u) { t11 = (unsigned)(signed char)(v0 % ((unsigned)((unsigned)w0 == (unsigned)x0) | 1u)); z11 = (double)(((unsigned)(m0 || (unsigned)l0)) & 255u); } if (((u1 + 2u)) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
                    s0 = (int)(0x80000000u << ((unsigned)e0 & 31u));
                    if (7u) break;
                    if (((unsigned)(unsigned char)(i1 - (unsigned)x0) >> (*mp & 31u))) continue;
                    if ((u2 / ((unsigned)h1 | 1u))) break;
                    if ((unsigned)(v0 || (unsigned)((int)(unsigned)s1 < (int)0xf350e0a3u))) break;
                    if ((p2 << (a0[u1 & 3u] & 31u))) break;
                }
            } while (i2++ < 4u && (unsigned)((short)m0 > (signed char)(unsigned)((unsigned)(w0 >> 29) == 6u)));
        } while (i1++ < 7u && (unsigned)b0);
    }
    if (((unsigned)((unsigned)s1 && g0) << (u0 & 31u))) goto L1;
    if ((unsigned)(0xffffffffu && (unsigned)s0)) goto L4;
    garr[i2 & 7u] = (unsigned)(g1 || garr[i1 & 7u]);
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 6u && (0xffffffffu * a0[i0 & 3u])) { if (--fuel == 0u) goto done;
            g1 += (unsigned)((unsigned)(a0[u1 & 3u] && (unsigned)b0) || 9u);
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                u3 ^= (unsigned)(i2 || (unsigned)(0xf05ed385u && (unsigned)c0));
                v0 = p0;
                if (((unsigned)c0 ^ (unsigned)h0)) break;
                w0 = w0 * 6364136223846793005ull + ((unsigned)f0 << (a0[i0 & 3u] & 31u));
            }
        }
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            u0 = u0 * 0x9e3779b1u + ((unsigned)((int)u1 >= (int)(9u >> (0xb56f72dau & 31u))) | garr[u2 & 7u]);
            break; (void)(((p1 | *q0) << (u0 & 31u)));
            m0 ^= (unsigned)(short)(unsigned)((i1 ? 0x80000000u : (unsigned)l0) < (unsigned)l0);
            if (9u) continue;
        }
        r0.y ^= (unsigned)((short)0x691f7444u > (signed char)1u);
    }
    if (((unsigned)(0x10000u == a0[u1 & 3u]) | (unsigned)f0)) {
        f0 = f0 * 0.5f + (float)(u1 & 255u);
        if ((unsigned)(0x907fc75fu && (unsigned)x0)) goto L0;
        q0 = &garr[(unsigned)((int)p1 >= (int)(unsigned)c0) & 7u];
        a0[((unsigned)(x0 >> 70) | (unsigned)f0) & 3u] = (unsigned)((unsigned)((int)(unsigned)e0 >= (int)(unsigned)s1) || 0x89109d47u);
        f0 = f0 * 0.5f + (float)((unsigned)(short)(unsigned)((unsigned)c0 || (unsigned)w0) & 255u);
    } else {
        goto done;
        { unsigned t12; double z12; if ((((unsigned)c1 % ((unsigned)((int)(unsigned)c1 < (int)0xf800314du) | 1u))) & 1u) { t12 = 0x10000u; z12 = (double)(((p1 + ~(unsigned)(0x7fffffffu || a0[u1 & 3u]))) & 255u); } if ((((unsigned)c1 % ((unsigned)((int)(unsigned)c1 < (int)0xf800314du) | 1u))) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
            goto done;
        }
        if ((unsigned)((int)(unsigned)(r0.x || 0x10000u) >= (int)0x80000000u)) goto L0;
        h0 = (short)~((unsigned)(((unsigned)d0 ^ (unsigned)d0) == (unsigned)(x0 >> 70)) * g0);
    }
    w0 ^= (unsigned long long)(unsigned)h1 << (p1 & 63u);
    goto L4;
    do { if (--fuel == 0u) goto done;
        garr[(unsigned)b0 & 7u] = (unsigned)((unsigned)x0 && (a0[u1 & 3u] % (*q0 | 1u)));
        if ((unsigned)s1) break;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)!(unsigned)((i0 >> (fuel & 31u)) == fuel) & 1023u);
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)0x6d3fd467u >= (int)((unsigned)c0 << ((unsigned)h0 & 31u)));
            w0 = w0 * 6364136223846793005ull + m0;
            switch (0x6db85053u & 7u) {
                *q0 += (unsigned)d0;
                if (u1) break;
                w0 ^= (unsigned long long)((unsigned)l0 << (a0[u1 & 3u] & 31u)) << ((p2 + i1) & 63u);
                g0 = -(unsigned)((unsigned)b0 || i1);
                if ((unsigned)e0) {
                    case 0u: ;
                    case 1u: ;
                    if (fuel < 8u) return (unsigned)e0;
                } else {
                    d0 = d0 * 0.5 + (double)((unsigned)(p2 || (unsigned)((int)0x10000u < (int)u1)) & 1023u);
                }
            }
            u0 = 0x88ecddadu;
            r0.x = (unsigned)(*mp || (u3 << ((unsigned)h0 & 31u)));
        }
        if (u0) break;
        if ((unsigned)((short)((unsigned)e0 + 4u) > (signed char)a0[i0 & 3u])) break;
        c0 = (unsigned char)garr[i1 & 7u];
    } while (i0++ < 2u && (fuel & r0.x));
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)c0 < (int)((unsigned)b0 | (unsigned)((unsigned)e0 || a0[i0 & 3u])));
    if (((unsigned)f0 + (unsigned)s1)) goto L0;
    a0[(unsigned)!(0x84836f6fu - (unsigned)s0) & 3u] = (unsigned)(6u || (unsigned)w0);
    e0 = e0 * 0.5L + (long double)(0x80000000u & 1023u);
    if (g1) goto L2;
    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(signed char)(unsigned)(g1 || (unsigned)(x0 >> 70)) || (unsigned)s0);
    goto L4;
    f0 = f0 * 0.5f + (float)((4u << ((unsigned)h0 & 31u)) & 255u);
    if ((((unsigned)s1 >> (p1 & 31u)) & u2)) goto L4;
    goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    g1 += (unsigned)((((unsigned)((short)(unsigned)c0 > (signed char)8u) & (unsigned)s1) % (5u | 1u)) && 0xceb3881au);
    if ((i1 & (unsigned)f0)) goto L3;
    u0 = (g0 + (fuel >> (7u & 31u)));
    if ((unsigned)((int)0xffffffffu < (int)5u)) {
        d0 = d0 * 0.5 + (double)((unsigned)((g1 ? 0x9662f133u : (unsigned)w0) || 8u) & 1023u);
        l0 = (long)((unsigned long)l0 + (~(p0 % (r0.y | 1u)) ^ ((unsigned)f0 * (p1 & garr[i1 & 7u]))));
    }
    { unsigned t0; double z0; if ((p1) & 1u) { t0 = (0xfa942878u & *mp); z0 = (double)(((unsigned)((int)i2 < (int)u2)) & 255u); } if ((p1) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        switch ((0x637f2b1du / (p2 | 1u)) & 7u) {
            u1 = (unsigned)(u3 || (unsigned)((unsigned)(unsigned char)((unsigned)h1 % (2u | 1u)) < r0.y));
            h1 = (unsigned short)(h1 + (unsigned)!(unsigned)((unsigned)(5u == 0x245aa921u) < (unsigned)s1));
            if (-(unsigned)(0xffffffffu == (unsigned)(u2 < p2))) goto L3;
        }
        L0: if (--fuel == 0u) goto done;
    }
    while ((unsigned)(i2 && p2)) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + 0x7fffffffu;
        q0 = &garr[6u & 7u];
        continue; (void)(((unsigned)e0 + (unsigned)c0));
    }
    do { if (--fuel == 0u) goto done;
        r0.y ^= (u2 * (unsigned)h0);
        e0 = e0 * 0.5L + (long double)(u0 & 1023u);
        d0 = d0 * 0.5 + (double)(((unsigned)x0 & ((0xa7c6f94u << (i1 & 31u)) + ((unsigned)c1 % (i2 | 1u)))) & 1023u);
        if (p1) goto L1;
    } while (i0++ < 3u && (unsigned)(0x27e992bau && (unsigned)(0xfd7dd61eu && fuel)));
    if (((0x7a1bf36du ^ fuel) & (unsigned)l0)) goto done;
    c1 = (signed char)(3u - *mp);
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[(unsigned)(unsigned char)(0xffffffffu % ((unsigned)l0 | 1u)) & 3u] = (~(unsigned)((int)r0.x < (int)0x9fa00a4u) >> (u0 & 31u));
        *mp = ((p2 % (i2 | 1u)) | 0x7fffffffu);
        { unsigned t1; double z1; if ((u2) & 1u) { t1 = 5u; z1 = (double)((5u) & 255u); } if ((u2) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            *q0 += ~(0x6ce75338u >> ((r0.y | (unsigned)((int)u2 >= (int)(unsigned)b0)) & 31u));
            if ((unsigned)(p0 == (garr[u2 & 7u] * 0xb1da8f5cu))) break;
            { unsigned t2; double z2; if (((a0[u1 & 3u] - p1)) & 1u) { t2 = (unsigned)h0; z2 = (double)(((unsigned)!(unsigned)((int)(i2 / (0x10000u | 1u)) < (int)p1)) & 255u); } if (((a0[u1 & 3u] - p1)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                *q0 += (unsigned)(((unsigned)((unsigned)(x0 >> 70) < m0) | (unsigned)(u3 && 0xccfc6ef0u)) || (unsigned)(x0 >> 70));
                switch ((i0 >> (6u & 31u)) & 7u) {
                    *q0 = ((unsigned)h1 | ~(0xffffffffu - m0));
                    u0 ^= (unsigned)(signed char)(p2 + a0[u1 & 3u]);
                    q0 = &garr[(unsigned)(unsigned char)(unsigned)((int)(unsigned)(signed char)(unsigned)(a0[u1 & 3u] == 0x3d472767u) >= (int)(unsigned)(unsigned char)(unsigned)((short)(unsigned)x0 > (signed char)(unsigned)x0)) & 7u];
                    if ((unsigned)(a0[u1 & 3u] < 0x1ece149du)) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(((unsigned)s1 % (g0 | 1u)) < 0xd953d5c1u), i0, (0x9b3e6344u >> ((unsigned)((unsigned)h1 == g1) & 31u))); }
                }
            }
            switch (u3 & 7u) {
                case 2u: ;
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 7u: ;
                    q0 = &garr[((m0 >> ((8u >> ((unsigned)((short)p1 > (signed char)fuel) & 31u)) & 31u)) % (0x6e605998u | 1u)) & 7u];
                    *mp = (unsigned)((unsigned)b0 < ((unsigned)e0 << ((unsigned)((int)(unsigned)d0 >= (int)(m0 >> (1u & 31u))) & 31u)));
                    if ((unsigned)((int)(unsigned)(i0 || garr[i1 & 7u]) < (int)(unsigned)s1)) break;
                    if (0x7fffffffu) continue;
                    b0 = (-(0x658e1775u % ((unsigned)(w0 >> 29) | 1u)) + (unsigned)((short)4u > (signed char)(unsigned)((short)0x42277460u > (signed char)(unsigned)f0))) != 0u;
                }
                L1: if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (unsigned)!(0xef49af96u >> ((r0.y + p1) & 31u)));
                if (budget != 0u) { budget -= 1u; u1 = fn0(u3, ((unsigned)b0 & 0x80000000u), (unsigned)d0); }
                switch ((unsigned)((unsigned)d0 || (0x10000u ^ (unsigned)x0)) & 7u) {
                    m0 ^= (unsigned)((int)(unsigned)e0 < (int)(*q0 * ((unsigned)c0 | 0u)));
                    if ((5u - 4u)) break;
                    { unsigned t3; double z3; if (((unsigned)h1) & 1u) { t3 = (unsigned)(0x9d39760du == (unsigned)c0); z3 = (double)((0x7748fa73u) & 255u); } if (((unsigned)h1) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        switch ((unsigned)(unsigned char)((unsigned)(0x80000000u && (unsigned)s0) + 0xffffffffu) & 7u) {
                            goto done;
                            s1 = (int)((unsigned)s1 + (unsigned)((short)0x3b915385u > (signed char)garr[u2 & 7u]));
                            f0 = f0 * 0.5f + (float)(~(unsigned)((unsigned)((int)0x10000u < (int)(unsigned)((unsigned)l0 == (unsigned)h0)) == (u2 * 0x760d29c9u)) & 255u);
                            e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)b0 < (unsigned)((short)~(unsigned)((unsigned)f0 < 0x10000u) > (signed char)p2)) & 1023u);
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn0((u0 * u2), fuel, 0x7fffffffu); }
                        if (budget != 0u) { budget -= 1u; u2 = fn0((((unsigned)f0 + 0xffffffffu) ^ 0xbab1ccbbu), ((5u << (g0 & 31u)) % (0xf2d04c9du | 1u)), (unsigned)s1); }
                        if (((unsigned)b0 | (unsigned)(garr[i1 & 7u] && i2))) continue;
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(1u, (unsigned)(((unsigned)f0 * (unsigned)d0) < garr[i1 & 7u]), u0); }
                }
            }
            if ((g0 * (unsigned)x0)) {
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)0xb4a5f138u >= (int)(u3 % ((unsigned)h1 | 1u))), (u1 * (unsigned)((int)8u < (int)0x7fffffffu)), ((unsigned)x0 & 0x7fffffffu)); }
                w0 ^= (unsigned long long)(unsigned)((short)3u > (signed char)(unsigned)d0) << (((unsigned)(fuel && i0) | g0) & 63u);
                q0 = &garr[(unsigned)((short)3u > (signed char)(u0 | u0)) & 7u];
                if (i0) continue;
                l0 = (long)((unsigned long)l0 + (p2 + i2));
            } else {
                if ((0x296928b9u - (u3 - p2))) break;
                s0 = (int)(unsigned)(unsigned char)((unsigned)s1 ^ (-(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)i0) * i1));
            }
        }
        g1 += (r0.x / ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)6u) | 1u));
        for (;;) { if (--fuel == 0u) goto done;
            { unsigned t4; double z4; if ((((unsigned)(signed char)(garr[i1 & 7u] ^ (unsigned)b0) >> ((unsigned)x0 & 31u))) & 1u) { t4 = (unsigned)w0; z4 = (double)((-(unsigned)((unsigned)(*mp == (unsigned)l0) < p1)) & 255u); } if ((((unsigned)(signed char)(garr[i1 & 7u] ^ (unsigned)b0) >> ((unsigned)x0 & 31u))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                if (budget != 0u) { budget -= 1u; u1 = fn0((a0[i0 & 3u] << (((unsigned)w0 * (unsigned)c0) & 31u)), (garr[u2 & 7u] << ((unsigned)(0xd2964b6eu < u0) & 31u)), (unsigned)!(unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)e0)); }
                f0 = f0 * 0.5f + (float)(((0x630a791fu | (3u % (0x7fffffffu | 1u))) >> (((unsigned)e0 << (g1 & 31u)) & 31u)) & 255u);
                r0.y ^= (unsigned)((unsigned)((int)0xffffffffu >= (int)garr[i1 & 7u]) && (unsigned)(i1 == i1));
                if ((unsigned)((int)(unsigned)f0 >= (int)u3)) continue;
            }
            g1 += (unsigned)((short)(unsigned)((unsigned)s0 == (unsigned)e0) > (signed char)(a0[u1 & 3u] / ((unsigned)((int)0x7fffffffu >= (int)i0) | 1u)));
            L2: if (--fuel == 0u) goto done;
            if (fuel < 8u) return 5u;
        }
    }
    u2 = u2 * 0x9e3779b1u + 0x10000u;
    g1 += ((a0[u1 & 3u] << ((unsigned)((int)*q0 >= (int)(unsigned)l0) & 31u)) / ((unsigned)((short)0xc04ae55cu > (signed char)(unsigned)x0) | 1u));
    s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)(fuel == 7u) < (int)(u0 & (unsigned)b0)));
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(r0.y ^ 4u) >= (int)p0), (unsigned)((unsigned)(x0 >> 70) == m0), -((u3 - u3) << (0x301aa963u & 31u))); }
    goto L1;
    goto L0;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        u1 = ((unsigned)((unsigned)w0 == (unsigned)d0) | p2);
        s1 = (int)((unsigned)s1 + u2);
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((int)(unsigned)s1 >= (int)i2) - (unsigned)x0), ((0x80000000u * 0u) << (0x80000000u & 31u)), (unsigned)s1); }
        if (((unsigned)(w0 >> 29) * fuel)) {
            do { if (--fuel == 0u) goto done;
                g1 += -(0x7fffffffu - (((unsigned)((short)(unsigned)h1 > (signed char)p1) & *q0) | fuel));
                break; (void)((unsigned)s1);
                if (((unsigned)(unsigned char)(unsigned)(u0 < (unsigned)(x0 >> 70)) / ((unsigned)c0 | 1u))) {
                    e0 = e0 * 0.5L + (long double)(((a0[u1 & 3u] ^ 0x10000u) % (i1 | 1u)) & 1023u);
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)b0 && (1u | ((unsigned)h0 ? g1 : u3))) & 255u);
                }
            } while (i1++ < 7u && (unsigned)(4u && m0));
            v0 = (unsigned)((u1 << ((unsigned)f0 & 31u)) == (u3 | (unsigned)(i1 || (unsigned)x0)));
            if (((unsigned)x0 >> (g1 & 31u))) continue;
            do { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    g0 = (unsigned)((int)(unsigned)((int)(unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)s0) < (int)((unsigned)c0 & i2)) >= (int)p1);
                }
                h0 = (short)((unsigned)l0 >> (~(unsigned)((int)(unsigned)x0 < (int)(unsigned)!(0x7d7e7355u - 0xffffffffu)) & 31u));
                e0 = e0 * 0.5L + (long double)(g0 & 1023u);
                w0 ^= (unsigned long long)2u << ((unsigned)((short)(unsigned)(0x80000000u && (unsigned)!(unsigned)((int)0xe89b93fdu < (int)v0)) > (signed char)i0) & 63u);
            } while (i1++ < 5u && (unsigned)(p1 < (*mp | u2)));
            u3 = (unsigned)b0;
            L3: if (--fuel == 0u) goto done;
        }
        if (((unsigned)(0x80000000u < r0.y) << (*q0 & 31u))) {
            L4: if (--fuel == 0u) goto done;
            *q0 = (unsigned)((int)(unsigned)c1 >= (int)((unsigned)s1 ^ (unsigned)x0));
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (((unsigned)(x0 >> 70) / (a0[i0 & 3u] | 1u)) & (*q0 >> (a0[i0 & 3u] & 31u)));
                a0[p0 & 3u] = ((unsigned)d0 % ((unsigned)l0 | 1u));
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)(((unsigned)x0 ? (unsigned)c0 : *mp) < a0[u1 & 3u]) && *mp));
                g1 += u2;
            }
        }
    }
    if ((0x272591c7u << (p2 & 31u))) goto L0;
    if ((unsigned)((unsigned)((short)(unsigned)h0 > (signed char)*q0) == (unsigned)c0)) goto L2;
    if ((unsigned)!(0x10000u >> (0xffffffffu & 31u))) goto L1;
    if (budget != 0u) { budget -= 1u; u0 = fn0((0x7fffffffu | 0x10000u), (unsigned)(0xb0d97f71u || ((unsigned)(w0 >> 29) - m0)), (unsigned)(0x10000u && 9u)); }
    goto done;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        q0 = &garr[((unsigned)h0 - g0) & 7u];
        r0.x = (unsigned)((unsigned)h1 < (unsigned)((int)((i0 ^ *q0) ^ i2) >= (int)(unsigned)c0));
        if (*mp) continue;
        do { if (--fuel == 0u) goto done;
            if (u2) break;
            if ((unsigned)b0) break;
            { unsigned t5; double z5; if ((((unsigned)s0 << (u3 & 31u))) & 1u) { t5 = (unsigned)((unsigned)(unsigned char)((unsigned)c0 & v0) == (unsigned)b0); z5 = (double)(((*mp % ((unsigned)h0 | 1u))) & 255u); } if ((((unsigned)s0 << (u3 & 31u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                if (a0[i0 & 3u]) break;
                if (0x80000000u) break;
                u2 = u2 * 0x9e3779b1u + p0;
            }
        } while (i1++ < 4u && m0);
        if ((0x10000u << ((unsigned)(0xe93f2d52u < 0x7fffffffu) & 31u))) {
            w0 ^= (unsigned long long)0xc705b9f3u << ((unsigned)(0x64c53b8cu == 0xeb3def30u) & 63u);
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)c0 ^ u0)) break;
                u2 = (0xeec7aec4u | (unsigned)((short)0xc3737fb6u > (signed char)8u));
                if (g1) goto L4;
                if ((unsigned)((short)*q0 > (signed char)5u)) break;
                do { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)(((0xffffffffu / (garr[i1 & 7u] | 1u)) << (0xdaf5deabu & 31u)) & 1023u);
                    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)f0) break;
                        c1 = (signed char)(unsigned)((unsigned)((int)i0 < (int)(unsigned)b0) || (unsigned)((unsigned)c1 || (unsigned)c1));
                        if ((p1 - (unsigned)(short)(g0 & p0))) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(u0, (unsigned)s0, garr[i1 & 7u]); }
                        r0.y ^= ((v0 + p2) + (unsigned)((int)(3u - (unsigned)c1) < (int)0x10000u));
                        r0.x = *q0;
                    }
                    u0 ^= (garr[i1 & 7u] % ((unsigned)((unsigned)(x0 >> 70) == 0x82b9e2b9u) | 1u));
                    break; (void)(-(5u - garr[i1 & 7u]));
                    if ((unsigned)((int)(g0 % ((unsigned)c1 | 1u)) >= (int)(unsigned)s1)) continue;
                } while (i2++ < 6u && (unsigned)((int)0x10000u < (int)(unsigned)((int)(unsigned)e0 >= (int)0xffffffffu)));
                g0 = ((unsigned)((unsigned)h1 < (p2 ^ u3)) + (unsigned)h0);
            }
        }
    }
    v0 = ((unsigned)(0x10000u == (unsigned)s0) % (p1 | 1u));
    if (0u) {
        if ((unsigned)(*mp && (unsigned)(signed char)(a0[i0 & 3u] * (unsigned)(x0 >> 70)))) {
            *q0 += (((unsigned)s0 ? garr[u2 & 7u] : 0xb1b98d56u) & (unsigned)l0);
            if ((a0[i0 & 3u] * (unsigned)((short)*q0 > (signed char)7u))) {
                if ((unsigned)c1) goto L3;
                goto L1;
                g1 += (2u % ((unsigned)(i0 < ((unsigned)c1 ? g1 : (unsigned)d0)) | 1u));
                u3 = u3 * 0x9e3779b1u + *q0;
            } else {
                e0 = e0 * 0.5L + (long double)((unsigned)f0 & 1023u);
            }
            a0[7u & 3u] = (unsigned)!(unsigned)((short)(unsigned)(unsigned char)(unsigned)((int)0x7fffffffu >= (int)(unsigned)c0) > (signed char)(0x80000000u - (unsigned)s0));
        } else {
            if ((unsigned)((unsigned)(8u || (unsigned)(x0 >> 70)) && u0)) {
                goto L2;
                *q0 = (unsigned)((short)((p2 % (r0.x | 1u)) & i1) > (signed char)0x80000000u);
                u3 = u3 * 0x9e3779b1u + fuel;
                while ((u3 * (0x4325a97eu << ((unsigned)l0 & 31u)))) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)(x0 >> 70) && i0), (m0 + (unsigned)(p0 || (unsigned)w0)), (u3 + (0xffffffffu % (0x80000000u | 1u)))); }
                    v0 = garr[i1 & 7u];
                    e0 = e0 * 0.5L + (long double)(-(unsigned)((int)(unsigned)e0 >= (int)g1) & 1023u);
                    break; (void)((unsigned)x0);
                    a0[(unsigned)c1 & 3u] = u0;
                    u1 = (unsigned)(w0 >> 29);
                }
                s0 = (int)((unsigned)((short)(i2 ^ p0) > (signed char)p2) & (unsigned)((unsigned)c1 || 0u));
                q0 = &garr[(unsigned)((unsigned)((unsigned)b0 && u2) == (i0 * (unsigned)s1)) & 7u];
            }
            q0 = &garr[0xb932f584u & 7u];
            if ((unsigned)(r0.x < 0x7fffffffu)) goto done;
            if ((unsigned)x0) {
                goto L0;
                { unsigned t6; double z6; if (((p1 % (p2 | 1u))) & 1u) { t6 = (unsigned)(0xffffffffu || (unsigned)c1); z6 = (double)(((0xffffffffu >> ((unsigned)(x0 >> 70) & 31u))) & 255u); } if (((p1 % (p2 | 1u))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                    b0 = (unsigned)(((unsigned)s0 | 0xffffffffu) == ((unsigned)c0 >> (0x80000000u & 31u))) != 0u;
                    q0 = &garr[((unsigned)(unsigned char)(unsigned)((unsigned)x0 < a0[u1 & 3u]) ^ ((p1 * 0x10000u) ^ (unsigned)s0)) & 7u];
                }
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (6u) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)s0, (unsigned)x0, (unsigned)((int)9u < (int)0x3e575396u)); }
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((int)5u < (int)0x96ed1bebu) < v0) & 255u);
                    c1 = (signed char)((unsigned)(unsigned char)(0xffb12902u % ((unsigned)((int)7u >= (int)r0.x) | 1u)) / (fuel | 1u));
                }
                s1 = (int)((unsigned)s1 + ((unsigned)f0 - r0.x));
                goto done;
                goto done;
            }
        }
        if (0x61ab35ebu) goto L2;
        l0 = (long)((unsigned long)l0 + (unsigned)h1);
        if ((unsigned)(5u < 9u)) goto L1;
        while (i0++ < 2u && (unsigned)(signed char)(a0[i0 & 3u] + ((unsigned)w0 * u1))) { if (--fuel == 0u) goto done;
            u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)(unsigned char)((unsigned)f0 % (*mp | 1u)) < ((p0 * garr[i1 & 7u]) | (unsigned)h0));
            q0 = &garr[~(unsigned)((p0 + (*mp - g1)) == ((unsigned)c1 ^ (unsigned)f0)) & 7u];
            b0 = ((unsigned)w0 ? v0 : (g0 % (*q0 | 1u))) != 0u;
            if (budget != 0u) { budget -= 1u; u2 = fn0(0x7fffffffu, (unsigned)((unsigned)h1 && u1), -((unsigned)s1 ^ (unsigned)(u1 && 0x7fffffffu))); }
            b0 = (3u << (u0 & 31u)) != 0u;
            if (budget != 0u) { budget -= 1u; u0 = fn0((a0[u1 & 3u] * g0), 0x80000000u, (4u + a0[u1 & 3u])); }
        }
    } else {
        if ((unsigned)((short)fuel > (signed char)(unsigned)c1)) goto L1;
        if ((u2 >> (0xffffffffu & 31u))) goto L4;
    }
    h1 = (unsigned short)(h1 + (0x28041c0eu / (3u | 1u)));
    c1 = (signed char)(unsigned)((short)(unsigned)c0 > (signed char)fuel);
    x0 = x0 * 0x100000001b3ull + (i1 ? 0x8d3c310du : p2);
    if ((unsigned)c1) goto L4;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (r0.x) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((0x80000000u % (0xffffffffu | 1u)), g1, 0x10000u); }
        }
        if (g0) goto L4;
        f0 = f0 * 0.5f + (float)(((unsigned)(short)(unsigned)((short)0x33eab41u > (signed char)*mp) % (0xb45d5e65u | 1u)) & 255u);
        continue; (void)((unsigned)b0);
    }
    if ((unsigned)((unsigned)c0 < (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)(x0 >> 70)))) goto done;
    l0 = (long)((unsigned long)l0 + (unsigned)(*mp || 0xffffffffu));
    if ((unsigned)h0) goto L3;
    do { if (--fuel == 0u) goto done;
        if (m0) {
            break; (void)((0x827565fau * (unsigned)(unsigned char)(unsigned)((int)u0 >= (int)(unsigned)x0)));
            s0 = (int)i1;
            i1 = ((unsigned)((short)a0[u1 & 3u] > (signed char)garr[u2 & 7u]) / (((unsigned)d0 << ((0x10000u / (*mp | 1u)) & 31u)) | 1u)) & 15u;
            if ((unsigned)(signed char)(unsigned)(0x80000000u == (unsigned)c0)) break;
        }
        while (i1++ < 7u && (unsigned)((int)(unsigned)(w0 >> 29) < (int)r0.x)) { if (--fuel == 0u) goto done;
            q0 = &garr[(unsigned)((unsigned)((int)(u2 ^ (unsigned)!((unsigned)(x0 >> 70) << (0x10000u & 31u))) < (int)(unsigned)x0) == p2) & 7u];
            u3 ^= ((i0 << ((unsigned)((unsigned)c0 == garr[u2 & 7u]) & 31u)) * u1);
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0((p0 % (0xffffffffu | 1u)), ((unsigned)((unsigned)h0 && u2) + 1u), ((0x69a643bau | (unsigned)x0) & garr[i1 & 7u])); }
    } while (i0++ < 2u && (unsigned)((unsigned)s0 || (unsigned)(m0 || *mp)));
    if ((unsigned)(7u || (unsigned)((unsigned)h1 < 0x7fffffffu))) goto L3;
    c1 = (signed char)(unsigned)(short)(unsigned)((int)u0 < (int)0x10000u);
    q0 = &garr[(((fuel >> (i0 & 31u)) | u1) * *q0) & 7u];
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = -(unsigned)((unsigned)h0 || (unsigned)(r0.y || (unsigned)(w0 >> 29)));
        s1 = (int)((unsigned)s1 + garr[i1 & 7u]);
        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((short)(unsigned)h1 > (signed char)(unsigned)s0) || 0xe613af19u);
        if ((unsigned)((unsigned)x0 || 7u)) goto L1;
        continue; (void)((unsigned)b0);
    }
    { unsigned t7; double z7; if (((((unsigned)l0 - i2) * u3)) & 1u) { t7 = (unsigned)((int)garr[i1 & 7u] < (int)((unsigned)(w0 >> 29) - 0x80000000u)); z7 = (double)(((0xf7cb4491u ^ garr[u2 & 7u])) & 255u); } if (((((unsigned)l0 - i2) * u3)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)d0, (unsigned)l0, (unsigned)(signed char)(unsigned)(r0.y || 6u)); }
        w0 = w0 * 6364136223846793005ull + (a0[i0 & 3u] / ((unsigned)h0 | 1u));
        if ((unsigned)((int)(unsigned)h0 >= (int)0x80000000u)) goto L3;
        switch (((unsigned)(x0 >> 70) & (unsigned)(unsigned char)(unsigned)((int)v0 >= (int)1u)) & 7u) {
            case 5u: ;
            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(~(*mp >> (r0.x & 31u)) == i0) && i0);
        }
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(r0.x, -((unsigned)d0 & 0x7fa63b4cu), (((unsigned)(x0 >> 70) & (unsigned)s1) ^ (unsigned)h0)); }
            if ((unsigned)(w0 >> 29)) break;
        }
    }
    while (i0++ < 7u && ((unsigned)(short)((unsigned)f0 | r0.y) >> ((unsigned)s1 & 31u))) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (((unsigned)h1 >> ((unsigned)b0 & 31u)) & 0x7fffffffu);
        b0 = ((unsigned)(0xce7f45f2u < i0) * 0xffffffffu) != 0u;
        h0 = (short)(g0 + ((unsigned)b0 % (m0 | 1u)));
        r0.x = (unsigned)((int)(unsigned)l0 < (int)g1);
        if (budget != 0u) { budget -= 1u; u3 = fn0((0x10000u - (0x32369058u | fuel)), (unsigned)((int)v0 < (int)*mp), 0x859a6a05u); }
        break; (void)((unsigned)!(0x1516e599u - (unsigned)(signed char)(u0 - (unsigned)h1)));
    }
    v0 = (unsigned)(short)(unsigned)(r0.y || 4u);
    switch (fuel & 7u) {
        g1 += (unsigned)(a0[u1 & 3u] == (u1 << ((unsigned)x0 & 31u)));
        while (i0++ < 7u && (-(unsigned)((short)fuel > (signed char)u3) - (unsigned)c1)) { if (--fuel == 0u) goto done;
            while (i1++ < 3u && (unsigned)((unsigned)(x0 >> 70) || i0)) { if (--fuel == 0u) goto done;
                *q0 = (unsigned)(signed char)(unsigned)((int)(unsigned)f0 < (int)(unsigned)(g1 < (unsigned)d0));
                if (budget != 0u) { budget -= 1u; u3 = fn0((*mp ^ *mp), (u2 | 0x37a010cdu), ((fuel ^ (unsigned)s1) / (0xd868f13du | 1u))); }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)fuel < (int)(9u * (unsigned)s1)), (unsigned)((unsigned)(r0.x || 0x10000u) && u3), i1); }
            if (budget != 0u) { budget -= 1u; u2 = fn0(u3, (0x80000000u + ((unsigned)s1 >> (*mp & 31u))), (unsigned)((int)0x10000u < (int)(unsigned)b0)); }
            c0 = (unsigned char)(unsigned)(short)(unsigned)((int)u1 >= (int)(0x7fffffffu << ((0x75459206u - i0) & 31u)));
            h1 = (unsigned short)(h1 + (unsigned)((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)(r0.y && p1)) == (u2 + (unsigned)x0)));
            while (0xffffffffu) { if (--fuel == 0u) goto done;
                garr[(unsigned)d0 & 7u] = (p0 ? (unsigned)((unsigned)b0 == 0x4394dc6du) : (0x3410e2b1u - 0x80000000u));
                switch (-(0xe1158a1bu / (0x7fffffffu | 1u)) & 7u) {
                    for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)f0 + ((unsigned)w0 ^ 8u)), r0.y, (unsigned)(signed char)((unsigned)((int)1u >= (int)0x8bb20c74u) << (0x1ab0e35eu & 31u))); }
                    }
                }
                d0 = d0 * 0.5 + (double)((9u & fuel) & 1023u);
                r0.x = ((1u << (0x7f7b7dceu & 31u)) ^ (0x8d4b2564u - 5u));
                if (r0.x) continue;
                q0 = &garr[g1 & 7u];
            }
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)!(m0 << ((unsigned)w0 & 31u))) {
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(3u == v0) && 0u), ((i0 << ((unsigned)x0 & 31u)) * (unsigned)c1), (unsigned)((int)(0x22fc8aadu % ((unsigned)c1 | 1u)) >= (int)u2)); }
                u3 ^= r0.y;
            } else {
                if (budget != 0u) { budget -= 1u; u0 = fn0(u0, ((0xffffffffu >> (0x80000000u & 31u)) >> (r0.x & 31u)), 0x19baa197u); }
                l0 = (long)((unsigned long)l0 + 0x7aa29f40u);
            }
            if (0x80000000u) break;
            if ((unsigned)((unsigned)x0 || 2u)) break;
            if (-(unsigned)((unsigned)x0 || (unsigned)((short)u3 > (signed char)0x7fffffffu))) {
                s0 = (int)(unsigned)((int)(unsigned)(unsigned char)(0x9fe074fcu - (unsigned)d0) < (int)(unsigned)c0);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0x14a6ed78u < 0x10000u), a0[i0 & 3u], (unsigned)(signed char)((p2 * 0xa9c96503u) * u0)); }
                a0[~((unsigned)c1 ^ 0x10000u) & 3u] = (unsigned)(unsigned char)((unsigned)((unsigned)(w0 >> 29) || ((unsigned)(0x333439d8u < p1) ^ u1)) << ((unsigned)h0 & 31u));
                case 0u: ;
                while ((((unsigned)w0 & (unsigned)s1) & (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(unsigned)(4u && 0xfe29fa16u) << (((unsigned)w0 ^ (unsigned)(0x9d91bf66u == fuel)) & 63u);
                    a0[(p0 ^ a0[u1 & 3u]) & 3u] = (unsigned)(0xf92b7c1fu || (unsigned)(i2 || (unsigned)(0xffffffffu == u3)));
                    garr[a0[i0 & 3u] & 7u] = (a0[u1 & 3u] * (unsigned)((int)(unsigned)(0x4e969107u && 0x93bef661u) < (int)(unsigned)d0));
                }
                u3 = (((unsigned)((unsigned)h1 == p0) | garr[u2 & 7u]) * v0);
            }
            u1 += (unsigned)((int)r0.x < (int)(unsigned)(a0[i0 & 3u] && (0x10000u + (unsigned)x0)));
        }
        switch ((p2 ? u1 : 0xa1bf7806u) & 7u) {
            for (;;) { if (--fuel == 0u) goto done;
                g0 = (unsigned)(0x10000u < (unsigned)c1);
                case 0u: ;
                if (((unsigned)s1 % (i2 | 1u))) goto L0;
                d0 = d0 * 0.5 + (double)((unsigned)((int)(5u << ((fuel & *q0) & 31u)) >= (int)((unsigned)c0 << ((unsigned)(w0 >> 29) & 31u))) & 1023u);
                case 7u: ;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((0xffffffffu % (0x79d5edabu | 1u)), (unsigned)((short)-(0x80000000u % (i1 | 1u)) > (signed char)u0), ((unsigned)h1 * (unsigned)(x0 >> 70))); }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(fuel, garr[i1 & 7u], (unsigned)((int)(unsigned)((int)*q0 < (int)a0[u1 & 3u]) >= (int)(unsigned)c0)); }
        case 7u: ;
    }
    { unsigned t8; double z8; if (((unsigned)(*q0 || r0.x)) & 1u) { t8 = (unsigned)((short)0xffffffffu > (signed char)r0.y); z8 = (double)(((unsigned)!(0x10000u * (unsigned)c0)) & 255u); } if (((unsigned)(*q0 || r0.x)) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
        while ((unsigned)f0) { if (--fuel == 0u) goto done;
            if ((7u % (garr[u2 & 7u] | 1u))) break;
            h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)h1 > (signed char)(unsigned)c1));
            *q0 = (((6u % ((unsigned)s1 | 1u)) - 5u) * (unsigned)(u3 && *q0));
            while (i1++ < 5u && (unsigned)(((unsigned)b0 / ((unsigned)h1 | 1u)) || (unsigned)l0)) { if (--fuel == 0u) goto done;
                u1 += ((unsigned)((int)5u >= (int)(unsigned)((int)(unsigned)((short)i1 > (signed char)0x10000u) < (int)p0)) ^ u1);
                g0 = 0xe4afd89bu;
                *q0 += (g1 | (unsigned)(p2 < *mp));
            }
            a0[(unsigned)d0 & 3u] = (0xffffffffu + 3u);
        }
        f0 = f0 * 0.5f + (float)((p2 - r0.x) & 255u);
        if (((r0.y | 0x8b859b3fu) % ((unsigned)(x0 >> 70) | 1u))) goto L3;
    }
    if ((unsigned)f0) {
        if (((unsigned)w0 * r0.x)) {
            s1 = (int)((unsigned)s1 + i0);
        }
        g1 += (unsigned)((int)(0x6e2a7c64u % (0x7fffffffu | 1u)) < (int)(unsigned)f0);
        u2 = ((unsigned)b0 + (garr[u2 & 7u] / (r0.y | 1u)));
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((3u / ((unsigned)x0 | 1u)));
            garr[(g0 % (a0[u1 & 3u] | 1u)) & 7u] = (-(3u % (0x10000u | 1u)) / ((unsigned)(((unsigned)e0 + *q0) || (unsigned)d0) | 1u));
        }
        w0 = w0 * 6364136223846793005ull + ((u3 / (0x10000u | 1u)) | i2);
    }
    if (u3 == 7u) return a0[i0 & 3u];
    if (budget != 0u) { budget -= 1u; u0 = fn0(((0xa00a4925u - fuel) | i1), -(p0 & m0), (unsigned)((unsigned)w0 && garr[i1 & 7u])); }
    if ((unsigned)(signed char)(0x80000000u - (unsigned)b0)) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((0x10000u ? 3u : 0xc9b769e2u)) {
                g1 += (unsigned)(unsigned char)(unsigned)(r0.x < v0);
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)l0 % ((unsigned)s1 | 1u)), 0xee56d71bu, *q0); }
                v0 = ((unsigned)(signed char)(0x10000u + m0) - (unsigned)(0xaaa7bbe4u && -(u2 ^ 0x98b8d97fu)));
                if (((0x80000000u / (5u | 1u)) << ((unsigned)d0 & 31u))) break;
                if (0x568fae3cu) goto L0;
                if ((unsigned)((unsigned)w0 || r0.y)) continue;
            }
            if ((unsigned)e0) break;
            garr[(unsigned)h1 & 7u] = (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)((short)0x10000u > (signed char)(unsigned)e0));
        }
        while (i0++ < 5u && i1) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((0xbda72f23u / (garr[u2 & 7u] | 1u)) ^ r0.y), fuel, (unsigned)!((unsigned)f0 * (unsigned)c0)); }
            m0 ^= (unsigned)(i2 && r0.y);
            while (i1++ < 5u && (v0 & (unsigned)((short)*mp > (signed char)3u))) { if (--fuel == 0u) goto done;
                i2 = *q0 & 15u;
                v0 = (r0.x & (fuel ^ 0x8eec566cu));
            }
            break; (void)(((v0 * p1) % (garr[i1 & 7u] | 1u)));
            if (u3) goto L0;
        }
        goto L1;
        if ((g1 ^ (unsigned)d0)) goto L3;
        while ((unsigned)((int)i0 >= (int)0x7fffffffu)) { if (--fuel == 0u) goto done;
            a0[(0x10000u >> (5u & 31u)) & 3u] = (unsigned)b0;
            u3 += (unsigned)((unsigned)(9u == (unsigned)(short)((unsigned)b0 >> (0x80000000u & 31u))) == (unsigned)(x0 >> 70));
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)s0 >= (int)(0x646c48f8u * (unsigned)h0));
            while (i1++ < 3u && ((unsigned)(u1 || g1) % (p0 | 1u))) { if (--fuel == 0u) goto done;
                u0 += p1;
            }
            break; (void)((unsigned)((r0.y * 2u) == 0x7fffffffu));
            if (r0.y) {
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(7u, r0.y, 0x5d6fc353u); }
                    q0 = &garr[((unsigned)c1 ^ 0u) & 7u];
                    while (i2++ < 5u && (unsigned)((int)fuel < (int)(unsigned)f0)) { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)(((unsigned)c1 ? (unsigned)((int)u0 < (int)p0) : 1u) & 1023u);
                        c1 = (signed char)(unsigned)(short)((a0[i0 & 3u] / ((unsigned)s0 | 1u)) << ((0xbba477c2u / (*q0 | 1u)) & 31u));
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)0x2bb38afdu < (int)p0), -(unsigned)((int)(unsigned)s0 < (int)*mp), (*mp * (unsigned)((short)i1 > (signed char)p1))); }
                        *q0 = 1u;
                        a0[u0 & 3u] = (unsigned)b0;
                        garr[m0 & 7u] = ((p2 ^ m0) / (i1 | 1u));
                    }
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)d0 == *q0), garr[u2 & 7u], -(unsigned)((unsigned)l0 || 2u)); }
                        do { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u2 = fn0(0xffffffffu, v0, -(unsigned)(*mp && ((unsigned)f0 ^ p1))); }
                            break; (void)((unsigned)((unsigned)h1 || garr[i1 & 7u]));
                            q0 = &garr[(r0.x % (((unsigned)h0 + ((i0 << ((unsigned)b0 & 31u)) ^ 0x973ed384u)) | 1u)) & 7u];
                            w0 = w0 * 6364136223846793005ull + u0;
                            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)f0, ((unsigned)h0 << ((unsigned)(v0 < 0x7fffffffu) & 31u)), (unsigned)((unsigned)d0 || 4u)); }
                            e0 = e0 * 0.5L + (long double)(0xbe9f6280u & 1023u);
                        } while (i0++ < 5u && (unsigned)h1);
                    } while (i2++ < 4u && (unsigned)(3u && (unsigned)d0));
                    switch (-(unsigned)((short)(unsigned)b0 > (signed char)(unsigned)(signed char)((unsigned)s1 - 0x10000u)) & 7u) {
                        s1 = (int)((unsigned)s1 + garr[u2 & 7u]);
                        garr[(unsigned)(short)(8u - (unsigned)(w0 >> 29)) & 7u] = (0xc85aea0bu ? (unsigned)d0 : (unsigned)s1);
                        if (fuel < 8u) return (0x10000u % ((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)w0) | 1u));
                    }
                    u0 = (unsigned)((unsigned)((short)g0 > (signed char)m0) < (unsigned)b0);
                }
                goto L0;
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)(unsigned)w0 > (signed char)0xffffffffu)) continue;
                }
            } else {
                continue; (void)(((unsigned)s0 | m0));
                do { if (--fuel == 0u) goto done;
                    { unsigned t9; double z9; if (((unsigned)(u2 && p1)) & 1u) { t9 = (unsigned)f0; z9 = (double)(((unsigned)(0x10000u == fuel)) & 255u); } if (((unsigned)(u2 && p1)) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
                        if ((unsigned)((p1 * i0) == (unsigned)f0)) continue;
                        garr[((unsigned)s1 - *mp) & 7u] = (unsigned)((int)0x7fffffffu < (int)(unsigned)((g1 ? (unsigned)s0 : garr[i1 & 7u]) || p1));
                        switch (~(0x7fffffffu / (0x675b55b9u | 1u)) & 7u) {
                            if (budget != 0u) { budget -= 1u; u2 = fn0((8u * (unsigned)b0), (unsigned)l0, (unsigned)(u1 == (unsigned)!(a0[i0 & 3u] - 0x1b1b1b62u))); }
                            l0 = (long)((unsigned long)l0 + ((i0 * g0) % ((unsigned)d0 | 1u)));
                            break; (void)((0xd627b88u >> ((unsigned)(0x784dc4c2u == a0[i0 & 3u]) & 31u)));
                        }
                        break; (void)((u0 % ((unsigned)s1 | 1u)));
                        { unsigned t10; double z10; if (((unsigned)(short)(*mp ? (unsigned)e0 : p2)) & 1u) { t10 = (unsigned)((int)fuel >= (int)(unsigned)(r0.x || g0)); z10 = (double)((i1) & 255u); } if (((unsigned)(short)(*mp ? (unsigned)e0 : p2)) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
                            if (g1) goto L0;
                            *q0 = (unsigned)(unsigned char)((unsigned)s1 ^ 0x7fffffffu);
                            if ((0x3546d7a6u + ((unsigned)(w0 >> 29) ^ i2))) goto L1;
                            break; (void)((0xbd402adu ^ (unsigned)c0));
                            if ((0x80000000u + 0x10000u)) continue;
                        }
                        r0.x = 4u;
                    }
                } while (i1++ < 7u && m0);
            }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(*q0, ((unsigned)(short)(0x14a9cbecu & 0x80000000u) % ((unsigned)h1 | 1u)), (8u << ((unsigned)e0 & 31u))); }
    } else {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (i0) break;
            w0 ^= (unsigned long long)v0 << ((((m0 % (a0[u1 & 3u] | 1u)) % (garr[i1 & 7u] | 1u)) | 0x5175e226u) & 63u);
            if ((g0 >> ((unsigned)s1 & 31u))) goto L2;
            break; (void)(garr[u2 & 7u]);
        }
        h1 = (unsigned short)(h1 + (((unsigned)h1 % ((v0 - ((unsigned)s1 | 0x80000000u)) | 1u)) & 0x7fffffffu));
    }
    goto L2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (((unsigned)w0 - a0[u1 & 3u])) goto L3;
    w0 ^= (unsigned long long)*mp << ((unsigned)!(~(((unsigned)(x0 >> 70) * 0x56aac72fu) ^ ((unsigned)(w0 >> 29) ^ p0)) % (garr[u2 & 7u] | 1u)) & 63u);
    d0 = d0 * 0.5 + (double)((i0 ^ 8u) & 1023u);
    if (u3 == 7u) return (unsigned)x0;
    l0 = (long)((unsigned long)l0 + ~(0x61ff5affu & (6u & (unsigned)e0)));
    switch (((unsigned)((unsigned)e0 || 0x17ed151bu) + i2) & 7u) {
        { unsigned t0; double z0; if (((0x7fffffffu % (0x6471695bu | 1u))) & 1u) { t0 = 4u; z0 = (double)((0x80000000u) & 255u); } if (((0x7fffffffu % (0x6471695bu | 1u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                q0 = &garr[0xffffffffu & 7u];
                if (r0.x) {
                    case 1u: ;
                }
                continue; (void)(r0.y);
                u0 += -((a0[i0 & 3u] / (0x410ff4deu | 1u)) - i2);
            }
            if ((unsigned)(p0 == (unsigned)b0)) {
                c0 = (unsigned char)((unsigned)(*q0 < 0x7fffffffu) ? ((unsigned)l0 * fuel) : garr[u2 & 7u]);
                if (((unsigned)(0xf2184ee4u == u2) << ((unsigned)e0 & 31u))) goto done;
                i0 = (unsigned)(x0 >> 70) & 15u;
                L0: if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(m0 & 255u);
                if (2u) break;
            } else {
                case 4u: ;
            }
            e0 = e0 * 0.5L + (long double)((unsigned)(0x80000000u < g1) & 1023u);
            if (4u) {
                u2 ^= (unsigned)e0;
                L1: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)f0, 0xccbd421fu, 0x6635b76eu); }
            }
            if (1u) {
                while (i0++ < 3u && (unsigned)(0xde3e01du == (unsigned)(0x10000u || 0x9ce03d27u))) { if (--fuel == 0u) goto done;
                    q0 = &garr[((i0 ^ (unsigned)(signed char)(unsigned)(i1 || p2)) >> ((*mp - 0x3c6de4f8u) & 31u)) & 7u];
                    if ((0x1b96cd19u ^ (unsigned)((int)p0 >= (int)(unsigned)w0))) {
                        r0.x = (unsigned)((int)u2 >= (int)(unsigned)((unsigned)((unsigned)l0 == g1) && p0));
                        if (budget != 0u) { budget -= 1u; u1 = fn0(0xdf5d70beu, i1, r0.x); }
                        case 3u: ;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)1u >= (int)u0), p1, ((unsigned)e0 + u3)); }
                        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                            c0 = (unsigned char)(unsigned)((int)((unsigned)h0 ^ (unsigned)(short)(0x7dbe9c91u ? (unsigned)s0 : fuel)) >= (int)fuel);
                            m0 ^= (fuel - ((unsigned)(x0 >> 70) >> ((unsigned)h0 & 31u)));
                            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)b0 ^ v0), ((2u + m0) + (unsigned)s0), (i1 << (u3 & 31u))); }
                        }
                    }
                }
                break; (void)((unsigned)((short)g1 > (signed char)r0.y));
                h1 = (unsigned short)(h1 + (unsigned)l0);
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)x0 == 0x1408eb50u), (unsigned)((int)(unsigned)((int)(unsigned)e0 >= (int)(unsigned)(w0 >> 29)) < (int)u2), ((0x97fe5dd6u ^ (unsigned)l0) << ((unsigned)f0 & 31u))); }
                if (budget != 0u) { budget -= 1u; u3 = fn0((4u * (9u * (unsigned)f0)), 0xb70e4be6u, 0u); }
            }
            while ((unsigned)(signed char)(*mp ^ garr[u2 & 7u])) { if (--fuel == 0u) goto done;
                u1 = u1 * 0x9e3779b1u + ((p1 << ((unsigned)(u1 && (unsigned)c1) & 31u)) + (unsigned)((int)(unsigned)f0 >= (int)(unsigned)x0));
                if ((unsigned)(0x80000000u || (unsigned)s1)) {
                    u1 = (unsigned)(((unsigned)h0 & (r0.x & 0x215264cdu)) && -((unsigned)l0 >> (g1 & 31u)));
                } else {
                    for (;;) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + ((unsigned)s1 * (unsigned)(x0 >> 70)));
                        default: ;
                        if ((unsigned)((short)(unsigned)((short)u1 > (signed char)(unsigned)h1) > (signed char)m0)) goto L2;
                        *q0 += r0.y;
                    }
                    garr[(0x80000000u >> ((unsigned)d0 & 31u)) & 7u] = (unsigned)!(unsigned)(0xcbf38750u || ((unsigned)((unsigned)d0 == (i1 - (unsigned)e0)) >> ((unsigned)c1 & 31u)));
                }
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (a0[u1 & 3u]) goto L0;
                    if (u3 == 7u) return (unsigned)(unsigned char)((0x80000000u * a0[u1 & 3u]) ? r0.x : (unsigned)((int)(unsigned)h1 < (int)i1));
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) < u0), p2, ((unsigned)((short)(unsigned)c1 > (signed char)i2) >> ((unsigned)s0 & 31u))); }
                        if (budget != 0u) { budget -= 1u; u3 = fn0(5u, 7u, (7u << ((unsigned)(0x66b6eebbu || 2u) & 31u))); }
                        s1 = (int)((unsigned)s1 + (4u | (0x80000000u - r0.y)));
                        { unsigned t1; double z1; if ((((unsigned)((int)(unsigned)w0 < (int)0x29c2c158u) * 0x782cd720u)) & 1u) { t1 = fuel; z1 = (double)((garr[u2 & 7u]) & 255u); } if ((((unsigned)((int)(unsigned)w0 < (int)0x29c2c158u) * 0x782cd720u)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                            v0 = ((unsigned)b0 >> (((unsigned)((int)4u < (int)(*mp * (unsigned)f0)) >> ((unsigned)(w0 >> 29) & 31u)) & 31u));
                            w0 = w0 * 6364136223846793005ull + (1u & ((unsigned)l0 - *mp));
                            *q0 = p1;
                            L2: if (--fuel == 0u) goto done;
                            u0 ^= ((unsigned)h0 - (unsigned)((int)g1 >= (int)(unsigned)!((unsigned)c0 << (0u & 31u))));
                        }
                    } while (i2++ < 6u && 0x80000000u);
                    switch (0x82d6cdbfu & 7u) {
                        v0 = garr[i1 & 7u];
                        u1 ^= (unsigned)((int)(unsigned)(~(unsigned)((int)(unsigned)e0 < (int)0x80000000u) == (unsigned)s1) >= (int)p1);
                        r0.x = (unsigned)(short)(g0 & r0.x);
                        g0 = (p2 * i1);
                        m0 ^= ((unsigned)l0 ? 0xffffffffu : ((unsigned)h1 | (unsigned)((short)2u > (signed char)u3)));
                    }
                }
                g1 += ((0u >> ((unsigned)f0 & 31u)) - ((unsigned)h1 ? 0x22366cbu : i0));
                c1 = (signed char)0x3c6fef31u;
                *mp = (u3 + g0);
            }
        }
        g1 += (unsigned)(((unsigned)(unsigned char)(unsigned)(u2 == 0x606cd93fu) ^ (unsigned)(w0 >> 29)) < (unsigned)f0);
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(*mp < p2), 0x10000u, (unsigned)!(unsigned)((int)(unsigned)e0 < (int)0x80000000u)); }
        do { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)!(((unsigned)(x0 >> 70) & i2) | ((unsigned)(x0 >> 70) - garr[i1 & 7u]));
            if (1u) continue;
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                switch ((unsigned)(signed char)(unsigned)(0xb02c5fbeu == (unsigned)(a0[u1 & 3u] || (unsigned)x0)) & 7u) {
                    l0 = (long)((unsigned long)l0 + (unsigned)((0x849dfa3eu ^ (unsigned)x0) == (unsigned)l0));
                    *q0 += ((unsigned)(unsigned char)(*q0 >> (garr[i1 & 7u] & 31u)) % (((i0 | 0x33a97616u) << (7u & 31u)) | 1u));
                }
                v0 = (8u - (unsigned)h0);
                break;
                g1 += (unsigned)((int)(0xffffffffu ^ (p2 / (garr[u2 & 7u] | 1u))) < (int)(0u & (unsigned)x0));
                while (i2++ < 4u && ((unsigned)(w0 >> 29) % (0x14a5f7c4u | 1u))) { if (--fuel == 0u) goto done;
                    if (i1) break;
                    i2 = (unsigned)((int)(unsigned)h0 >= (int)r0.x) & 15u;
                }
                switch ((unsigned)((short)u2 > (signed char)0xffffffffu) & 7u) {
                    break; (void)(p0);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(i0, ((garr[u2 & 7u] % (*mp | 1u)) ^ 7u), (0x7fffffffu << ((r0.y * r0.x) & 31u))); }
                }
            }
            h1 = (unsigned short)(h1 + ((unsigned)e0 >> (i2 & 31u)));
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)garr[u2 & 7u] < (int)fuel), (4u / ((unsigned)(0x13b13653u == 0xb9480dau) | 1u)), (unsigned)((unsigned)(x0 >> 70) == (unsigned)(p1 && (unsigned)w0))); }
            q0 = &garr[(unsigned)((unsigned)((int)p2 < (int)4u) || (0x10f014e8u / (~(unsigned)((int)u2 < (int)1u) | 1u))) & 7u];
        } while (i0++ < 6u && ((unsigned)s0 % (0xe1e81c5fu | 1u)));
        garr[fuel & 7u] = (unsigned)((p1 % (4u | 1u)) || ((unsigned)h0 << (v0 & 31u)));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)*q0 < (int)p1), (unsigned)((int)(unsigned)((int)u3 < (int)(unsigned)(w0 >> 29)) < (int)u0), ((3u >> (u2 & 31u)) ^ 0u)); }
    if (((unsigned)h1 + (unsigned)(signed char)(1u + 2u))) goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)((unsigned)b0 >> (*mp & 31u)), (0u & (unsigned)(g0 && (unsigned)c0)), (u1 ? (unsigned)c1 : (unsigned)d0)); }
    switch (i1 & 7u) {
        a0[(unsigned)e0 & 3u] = (unsigned)(p1 || (4u << ((i0 - (unsigned)c1) & 31u)));
        L3: if (--fuel == 0u) goto done;
        while ((0xffffffffu | g0)) { if (--fuel == 0u) goto done;
            garr[p1 & 7u] = (unsigned)((short)(unsigned)((0xffffffffu ^ i0) == (unsigned)((int)fuel < (int)0xd6fda396u)) > (signed char)1u);
            u0 += (0xd5124501u / (a0[i0 & 3u] | 1u));
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                g1 += (unsigned)!(5u + 0xffffffffu);
                case 3u: ;
                q0 = &garr[(unsigned)((int)(unsigned)b0 >= (int)(unsigned)(-(unsigned)((unsigned)((int)*q0 < (int)0x10000u) < (unsigned)f0) && r0.y)) & 7u];
                if (((unsigned)h1 & ((unsigned)b0 % ((unsigned)w0 | 1u)))) break;
                if ((unsigned)s1) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(2u == m0), (0x10000u - (unsigned)(i0 || p1)), (unsigned)(garr[u2 & 7u] == (unsigned)w0)); }
            }
            h1 = (unsigned short)(h1 + (unsigned)(~(garr[u2 & 7u] ? i0 : 0x7fffffffu) == 0x147c3ef7u));
            l0 = (long)((unsigned long)l0 + (0xadb0b1adu % (((unsigned)(w0 >> 29) ^ ((unsigned)(a0[u1 & 3u] < (unsigned)l0) - 0x7fffffffu)) | 1u)));
        }
        s0 = (int)(6u % (((0x80000000u * 4u) + p1) | 1u));
        h1 = (unsigned short)(h1 + 6u);
    }
    r0.y ^= ((unsigned)w0 * ((i2 | (0xffffffffu >> (m0 & 31u))) >> (garr[u2 & 7u] & 31u)));
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(g0 || (unsigned)l0), 0x10000u, (r0.y << (r0.x & 31u))); }
    c0 = (unsigned char)u1;
    e0 = e0 * 0.5L + (long double)((unsigned)((short)9u > (signed char)((unsigned)(w0 >> 29) ? u2 : a0[i0 & 3u])) & 1023u);
    if (((unsigned)e0 * fuel)) goto done;
    switch ((unsigned)(i1 == (u3 * garr[u2 & 7u])) & 7u) {
        e0 = e0 * 0.5L + (long double)(-((0xffffffffu ^ 0xffffffffu) * p2) & 1023u);
        do { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((8u >> ((unsigned)h1 & 31u)), (0xfbf291a9u - 0xffffffffu), m0); }
                *q0 = ((unsigned)!(a0[i0 & 3u] | u1) | (unsigned)((int)(unsigned)c0 < (int)4u));
            }
            for (;;) { if (--fuel == 0u) goto done;
                { unsigned t2; double z2; if (((((unsigned)(w0 >> 29) % ((unsigned)(x0 >> 70) | 1u)) / (u1 | 1u))) & 1u) { t2 = (unsigned)(signed char)(7u - g0); z2 = (double)(((unsigned)((int)p1 < (int)0x8e9e086du)) & 255u); } if (((((unsigned)(w0 >> 29) % ((unsigned)(x0 >> 70) | 1u)) / (u1 | 1u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)((unsigned)d0 ? 0xc151f397u : p2), (unsigned)(short)((unsigned)s0 | u3), (garr[i1 & 7u] - g1)); }
                    b0 = (9u ? 0xd1be1eb1u : (garr[u2 & 7u] / (*q0 | 1u))) != 0u;
                    x0 = x0 * 0x100000001b3ull + (0xd03ca44u << (*mp & 31u));
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)(unsigned)b0 >= (int)v0)) {
                            if (0xb5d6355au) continue;
                            goto L3;
                            w0 = w0 * 6364136223846793005ull + (unsigned)((0u / ((0x7fffffffu << (0x10000u & 31u)) | 1u)) < 4u);
                            c1 = (signed char)(unsigned)((int)((a0[i0 & 3u] / (p1 | 1u)) | g1) >= (int)(u1 | u3));
                            s1 = (int)((unsigned)s1 + (unsigned)((int)0x10000u < (int)(i0 >> (*mp & 31u))));
                        }
                        case 5u: ;
                    } while (i2++ < 3u && (0x7fffffffu >> (v0 & 31u)));
                    switch ((0u ^ (unsigned)(2u || garr[u2 & 7u])) & 7u) {
                        u2 = u2 * 0x9e3779b1u + ((0x7fffffffu ? ((unsigned)(x0 >> 70) + i1) : (unsigned)(x0 >> 70)) * 0x80000000u);
                    }
                    L4: if (--fuel == 0u) goto done;
                }
            }
            c0 = (unsigned char)(u1 | (unsigned)((short)a0[i0 & 3u] > (signed char)a0[u1 & 3u]));
        } while (i0++ < 6u && (fuel + (g1 + i0)));
        w0 = w0 * 6364136223846793005ull + (0x2fe19101u >> ((unsigned)s0 & 31u));
        g1 += (unsigned)!((((unsigned)c0 & (unsigned)d0) & (unsigned)(8u && i2)) | (unsigned)s1);
        case 0u: ;
        b0 = (unsigned)(unsigned char)(r0.x | fuel) != 0u;
    }
    u2 = (((unsigned)(i2 || 6u) - (unsigned)(0xb31e8b5cu == 0x10000u)) * (unsigned)d0);
    v0 = (unsigned)!(((u1 & u3) ^ ((unsigned)f0 + 0x6a647298u)) % (0x5e956d66u | 1u));
    if ((unsigned)w0) {
        if (0x80000000u) goto L0;
        for (;;) { if (--fuel == 0u) goto done;
            { unsigned t3; double z3; if ((~(unsigned)((int)0xffffffffu < (int)(unsigned)f0)) & 1u) { t3 = (0xffa1820u >> ((unsigned)f0 & 31u)); z3 = (double)((v0) & 255u); } if ((~(unsigned)((int)0xffffffffu < (int)(unsigned)f0)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                while (i1++ < 3u && (unsigned)((int)(unsigned)c1 >= (int)i1)) { if (--fuel == 0u) goto done;
                    if ((p0 ^ (3u - 0x7fffffffu))) break;
                    e0 = e0 * 0.5L + (long double)((1u / (((unsigned)(i2 == u1) ^ (unsigned)((int)6u < (int)0x913c4bdau)) | 1u)) & 1023u);
                    while (i2++ < 3u && (unsigned)((int)(unsigned)(unsigned char)(u1 ^ (unsigned)b0) >= (int)garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(m0, (0xc76f39bu << (((unsigned)c0 % ((unsigned)w0 | 1u)) & 31u)), g0); }
                    }
                    w0 = w0 * 6364136223846793005ull + r0.y;
                    a0[(unsigned)(v0 == (unsigned)s0) & 3u] = (5u & garr[i1 & 7u]);
                    w0 = w0 * 6364136223846793005ull + (garr[u2 & 7u] << (r0.y & 31u));
                }
                garr[(unsigned)c0 & 7u] = (0x80000000u ^ 0xffffffffu);
                if ((unsigned)(r0.x == (unsigned)c0)) break;
                break; (void)((unsigned)((int)(unsigned)h0 < (int)p2));
                f0 = f0 * 0.5f + (float)((u3 & (unsigned)((garr[i1 & 7u] & 0xfc5111bfu) || (unsigned)b0)) & 255u);
                if (((unsigned)(0xf0b135dau == 0xe8dda32au) + u1)) {
                    if (g1) break;
                    if ((unsigned)((int)u2 < (int)0x7fffffffu)) goto L4;
                    if ((unsigned)((int)-((unsigned)h1 << (4u & 31u)) < (int)0x33ed8fcdu)) break;
                    g0 = (unsigned)d0;
                    g1 += (unsigned)((int)(unsigned)h1 < (int)(5u * 4u));
                    break; (void)(u1);
                } else {
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(0x3b2a35d0u == a0[i0 & 3u]), 0x10000u, g0); }
                }
            }
            if ((*q0 & (v0 ^ 0x2e28c71fu))) break;
            do { if (--fuel == 0u) goto done;
                switch (i1 & 7u) {
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((unsigned)(short)(i1 | 0x80000000u) || p0)) goto L1;
                        s0 = (int)~((unsigned)w0 | (unsigned)(x0 >> 70));
                        goto L0;
                        r0.y ^= ((unsigned)c1 * (0x80000000u << ((unsigned)l0 & 31u)));
                    } while (i2++ < 3u && 8u);
                    c0 = (unsigned char)(unsigned)((unsigned)x0 || m0);
                    case 1u: ;
                    { unsigned t4; double z4; if (((unsigned)(p0 || (unsigned)((short)p0 > (signed char)(unsigned)f0))) & 1u) { t4 = (unsigned)(i1 && 4u); z4 = (double)(((m0 | i0)) & 255u); } if (((unsigned)(p0 || (unsigned)((short)p0 > (signed char)(unsigned)f0))) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                        u0 ^= (unsigned)e0;
                        u1 ^= ((0x2188af51u & g0) * (unsigned)(unsigned char)(unsigned)((1u - 0u) == u3));
                        s0 = (int)5u;
                    }
                }
                if ((unsigned)(*q0 || (unsigned)(p0 || i1))) break;
                if ((unsigned)((unsigned)(u0 < 2u) || p0)) break;
                if (budget != 0u) { budget -= 1u; u2 = fn1((0xffffffffu << ((unsigned)(w0 >> 29) & 31u)), (u3 & i1), ((unsigned)(x0 >> 70) * r0.y)); }
                if ((unsigned)((short)g0 > (signed char)(unsigned)(short)((unsigned)f0 / (0x846ac2d1u | 1u)))) continue;
                if (((unsigned)c0 + (unsigned)x0)) continue;
            } while (i1++ < 7u && g0);
            if (a0[u1 & 3u]) {
                u3 = u3 * 0x9e3779b1u + -(unsigned)(g1 == (unsigned)((unsigned)(w0 >> 29) < 0x7fffffffu));
                switch ((m0 % ((unsigned)f0 | 1u)) & 7u) {
                    b0 = (unsigned)((i1 ^ a0[u1 & 3u]) == fuel) != 0u;
                    if (*mp) continue;
                    g0 = (unsigned)((garr[u2 & 7u] & *mp) == (u1 % (5u | 1u)));
                    s1 = (int)((unsigned)s1 + (unsigned)((int)*mp < (int)0x7fffffffu));
                    f0 = f0 * 0.5f + (float)(((unsigned)((unsigned)x0 == p1) ? 0x10000u : r0.y) & 255u);
                }
            } else {
                g1 += (0xffffffffu & *mp);
                if (budget != 0u) { budget -= 1u; u3 = fn0(u2, (unsigned)(signed char)(unsigned)((int)(unsigned)(w0 >> 29) < (int)0x2a81833fu), (unsigned)(short)((5u / (a0[u1 & 3u] | 1u)) % ((unsigned)c1 | 1u))); }
            }
            i2 = *q0 & 15u;
            if (fuel) break;
        }
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((p2 / (i0 | 1u)) & 1023u);
        }
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((~(unsigned)(0u < 8u) << (u2 & 31u)));
            *q0 += (unsigned)((int)u1 < (int)(unsigned)((int)((unsigned)h1 / (a0[u1 & 3u] | 1u)) < (int)(unsigned)s0));
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)(w0 >> 29) == a0[u1 & 3u]), 0x7fffffffu, (unsigned)(short)(m0 - (unsigned)(signed char)(unsigned)(r0.y < garr[u2 & 7u]))); }
        }
        switch (p0 & 7u) {
            if (budget != 0u) { budget -= 1u; u3 = fn1(u1, (g0 ^ ((unsigned)c1 * a0[u1 & 3u])), ((unsigned)s0 & 0u)); }
            if (fuel < 8u) return (unsigned)((int)r0.y >= (int)(unsigned)s1);
        }
    } else {
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((unsigned)(w0 >> 29) == g1), (unsigned)h1, (fuel + (unsigned)b0)); }
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)b0, (unsigned)(short)(garr[u2 & 7u] ? (unsigned)s0 : r0.x), (unsigned)((short)(unsigned)((short)(unsigned)c0 > (signed char)0xffffffffu) > (signed char)0xffffffffu)); }
        u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)l0 && u1);
    }
    w0 ^= (unsigned long long)(unsigned)w0 << ((unsigned)((int)(unsigned)((int)fuel < (int)(0x8c3b01e8u | (i1 % (u2 | 1u)))) < (int)g1) & 63u);
    if ((unsigned)(short)(u2 & v0)) {
        *q0 += ((unsigned)(0x80000000u || (0x80000000u ^ u2)) & (0xdc139322u | i1));
        if (((unsigned)((unsigned)d0 && p0) * (unsigned)l0)) goto done;
        goto L3;
        switch (a0[u1 & 3u] & 7u) {
            case 3u: ;
        }
    }
    g1 += (unsigned)(unsigned char)(*q0 ? (unsigned)((int)u2 < (int)(unsigned)f0) : (7u - 0x7fffffffu));
    u1 = (unsigned)(3u && (unsigned)d0);
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 += (unsigned)(x0 >> 70);
        w0 ^= (unsigned long long)((unsigned)(w0 >> 29) | u0) << (0x10000u & 63u);
        m0 ^= (unsigned)c1;
        if ((u2 << (i2 & 31u))) break;
        v0 = (unsigned)((int)i0 < (int)((unsigned)h1 - 2u));
    }
    goto L4;
    *q0 += (unsigned)((int)0x7fffffffu >= (int)(unsigned)l0);
    while (i0++ < 5u && ~((unsigned)e0 + a0[u1 & 3u])) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((unsigned)(2u == r0.y) & 255u);
            if (((unsigned)h0 + v0)) break;
            if ((unsigned)(x0 >> 70)) goto L4;
        } while (i1++ < 4u && 0xffffffffu);
        h1 = (unsigned short)(h1 + (unsigned)((unsigned)((short)g1 > (signed char)a0[u1 & 3u]) || 0x80000000u));
    }
    while (i0++ < 3u && r0.y) { if (--fuel == 0u) goto done;
        u1 = u0;
        u3 = r0.y;
    }
    switch (((p0 % (i1 | 1u)) % ((unsigned)f0 | 1u)) & 7u) {
        do { if (--fuel == 0u) goto done;
            *q0 = (unsigned)(g1 < ((unsigned)b0 + v0));
            w0 = w0 * 6364136223846793005ull + ~(unsigned)(((unsigned)((unsigned)(w0 >> 29) || 0x71424feu) % ((unsigned)e0 | 1u)) && garr[u2 & 7u]);
            case 3u: ;
            case 4u: ;
            i0 = (unsigned)((short)(unsigned)d0 > (signed char)((unsigned)d0 * (unsigned)w0)) & 15u;
        } while (i0++ < 3u && ((unsigned)e0 | 0x7fffffffu));
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)e0, 0x26160a35u, (unsigned)((short)4u > (signed char)u3)); }
        r0.y ^= ((g0 | 0u) << ((unsigned)((unsigned)h1 == 0x7fffffffu) & 31u));
        while (i1++ < 7u && ((unsigned)h1 << (v0 & 31u))) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(0x80000000u & 1023u);
            while (i2++ < 7u && 2u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(((unsigned)w0 * p2) & 255u);
            }
        }
        f0 = f0 * 0.5f + (float)((unsigned)((int)(u3 & (unsigned)s0) >= (int)(unsigned)((unsigned)w0 || v0)) & 255u);
        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)!((unsigned)b0 ^ 0xc6935274u) * (unsigned)f0), (unsigned)(i1 || (unsigned)(i1 && (unsigned)s0)), (unsigned)((int)(0x80000000u + 0x80000000u) < (int)0x7fffffffu)); }
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)g0 < (int)garr[u2 & 7u]);
    m0 ^= ((((unsigned)x0 & (unsigned)c1) ^ (unsigned)w0) << ((6u % (i1 | 1u)) & 31u));
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)((int)g0 >= (int)u1)), ((a0[u1 & 3u] >> (0x6ffdfd9fu & 31u)) | (unsigned)(w0 >> 29)), v0); }
    do { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (u3 << (0xffffffffu & 31u)));
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(0x80000000u, (u0 / ((unsigned)d0 | 1u)), 7u); }
        }
        if (u1) break;
        if ((*mp + (unsigned)((unsigned)h0 < 0xf3a6e84cu))) {
            if (g0) {
                r0.y ^= ((0x7fffffffu >> (r0.y & 31u)) + u1);
                s1 = (int)((unsigned)s1 + (7u / (((unsigned)(i0 == r0.y) + 0xffffffffu) | 1u)));
            }
            if (budget != 0u) { budget -= 1u; u3 = fn1(-(((unsigned)c1 % ((unsigned)f0 | 1u)) << (i1 & 31u)), (a0[u1 & 3u] >> (8u & 31u)), ((unsigned)f0 - (unsigned)((int)0xb69be11au >= (int)i0))); }
        }
    } while (i0++ < 4u && (unsigned)((unsigned)((unsigned)w0 == r0.x) == 7u));
    g0 = a0[u1 & 3u];
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    if ((unsigned)((int)u0 >= (int)(unsigned)((unsigned)s1 && 0x18808f6u))) {
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (p0) {
                switch (a0[i0 & 3u] & 7u) {
                    L1: if (--fuel == 0u) goto done;
                    b0 = (unsigned)!(unsigned)(((unsigned)h0 >> ((unsigned)((int)0x80000000u >= (int)(unsigned)(p0 < u0)) & 31u)) < (unsigned)h0) != 0u;
                }
                m0 ^= i2;
                m0 ^= 0x80000000u;
                { unsigned t0; double z0; if (((unsigned)((short)(i0 * 0x6b34aa96u) > (signed char)0x10000u)) & 1u) { t0 = ((unsigned)s0 / ((g1 & 0x80000000u) | 1u)); z0 = (double)(((unsigned)((int)fuel >= (int)r0.y)) & 255u); } if (((unsigned)((short)(i0 * 0x6b34aa96u) > (signed char)0x10000u)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                    if ((3u + (unsigned)l0)) break;
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((int)(a0[u1 & 3u] - 9u) >= (int)7u)) break;
                        for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                            c1 = (signed char)((p2 & a0[i0 & 3u]) << (p0 & 31u));
                            if (u3 == 7u) return (unsigned)((unsigned)((int)0x92561f00u >= (int)(unsigned)h0) && (unsigned)(0x7fffffffu && i2));
                            if (budget != 0u) { budget -= 1u; u2 = fn0((v0 + i0), (unsigned)w0, p2); }
                            if (budget != 0u) { budget -= 1u; u3 = fn1(0x80000000u, 0xffffffffu, (i0 / (((unsigned)(x0 >> 70) % ((unsigned)x0 | 1u)) | 1u))); }
                            w0 = w0 * 6364136223846793005ull + (i1 / (u1 | 1u));
                            w0 = w0 * 6364136223846793005ull + (unsigned)(p2 < (unsigned)x0);
                        }
                        garr[i1 & 7u] = ((unsigned)l0 + (unsigned)c0);
                        while (i2++ < 5u && (v0 ^ i0)) { if (--fuel == 0u) goto done;
                            if (((unsigned)((unsigned)c0 == 4u) >> (a0[u1 & 3u] & 31u))) goto L1;
                            f0 = f0 * 0.5f + (float)((p2 * (unsigned)((int)(unsigned)h1 >= (int)fuel)) & 255u);
                            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(u1 / (g0 | 1u)) < (int)0x7fffffffu), (p0 ? 7u : 0x10000u), (unsigned)d0); }
                            if ((g1 >> (p2 & 31u))) goto L2;
                        }
                        if (((unsigned)w0 << (m0 & 31u))) break;
                        h1 = (unsigned short)(h1 + 0xd1f7d0d5u);
                    }
                    if (9u) break;
                    if ((i0 & (unsigned)h1)) {
                        if ((0xffffffffu & ((unsigned)(w0 >> 29) & (unsigned)h0))) break;
                        if ((*mp / (3u | 1u))) goto L4;
                        L2: if (--fuel == 0u) goto done;
                        if ((unsigned)((unsigned)s0 && 0xae84fb6au)) {
                            if ((unsigned)(unsigned char)(p2 ^ (unsigned)((int)4u < (int)1u))) break;
                            u2 ^= ((unsigned)(w0 >> 29) ^ ~(a0[i0 & 3u] % ((unsigned)(u1 == (u0 & p1)) | 1u)));
                            if (budget != 0u) { budget -= 1u; u2 = fn0(p1, (u2 % ((unsigned)c0 | 1u)), (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)d0)); }
                        }
                    }
                    g0 = u3;
                }
            } else {
                c1 = (signed char)(0x41e61c69u ^ a0[u1 & 3u]);
                if (((unsigned)((unsigned)c1 || (unsigned)x0) / (*q0 | 1u))) {
                    break; (void)((unsigned)(0x80000000u && (unsigned)c0));
                } else {
                    while (i1++ < 2u && (unsigned)((int)r0.x >= (int)(unsigned)l0)) { if (--fuel == 0u) goto done;
                        u1 += (unsigned)s0;
                        *mp = (unsigned)((unsigned)x0 < (((unsigned)b0 & garr[u2 & 7u]) % (g0 | 1u)));
                        if ((unsigned)(unsigned char)(m0 + (unsigned)c0)) break;
                        L3: if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)s1 == 3u);
                        h0 = (short)-(unsigned)((int)(unsigned)(w0 >> 29) >= (int)m0);
                    }
                    L4: if (--fuel == 0u) goto done;
                }
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    garr[(unsigned)(a0[u1 & 3u] < a0[i0 & 3u]) & 7u] = (unsigned)(p0 == 0x16039500u);
                }
            }
            if ((unsigned)((int)0x31422ea5u < (int)(unsigned)((unsigned)d0 == 0x10000u))) continue;
            u0 = u0 * 0x9e3779b1u + ((unsigned)((short)(unsigned)(r0.x || (unsigned)h1) > (signed char)0x10000u) ^ g1);
            s1 = (int)((unsigned)s1 + ((unsigned)s1 + a0[u1 & 3u]));
            l0 = (long)((unsigned long)l0 + a0[i0 & 3u]);
            if ((unsigned)((short)r0.x > (signed char)(unsigned)s0)) break;
        }
        if ((unsigned)x0) {
            e0 = e0 * 0.5L + (long double)(0x1ed8da7fu & 1023u);
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)!(p1 ^ 0x80000000u), (unsigned)((unsigned)((unsigned)(x0 >> 70) || (unsigned)l0) == g1), ~((unsigned)((int)garr[i1 & 7u] < (int)(unsigned)c0) | 0x7fffffffu)); }
            l0 = (long)((unsigned long)l0 + (unsigned)(u1 == (unsigned)w0));
            if ((unsigned)(garr[u2 & 7u] == (*q0 | u1))) goto L4;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)w0 / ((unsigned)w0 | 1u)), (unsigned)(short)((unsigned)(signed char)(8u << (1u & 31u)) << (0x80000000u & 31u)), (unsigned)h1); }
        if (0x6c7360c7u) goto L3;
        if (budget != 0u) { budget -= 1u; u3 = fn1(g0, 2u, (0x80000000u / (3u | 1u))); }
        { unsigned t1; double z1; if ((v0) & 1u) { t1 = ((unsigned)(0xcf9d26f7u == u3) & a0[u1 & 3u]); z1 = (double)((0x10000u) & 255u); } if ((v0) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            while (i0++ < 7u && (unsigned)(r0.x || (unsigned)(unsigned char)(u2 % (0xb76c9e07u | 1u)))) { if (--fuel == 0u) goto done;
                if (((*mp + p2) % (p1 | 1u))) break;
                u1 = (m0 % ((unsigned)c1 | 1u));
                h0 = (short)(unsigned)(unsigned char)((unsigned)(x0 >> 70) ^ ((unsigned)(w0 >> 29) ^ ((unsigned)((int)5u >= (int)r0.x) >> (u0 & 31u))));
            }
        }
    } else {
        c1 = (signed char)((u1 * r0.y) >> (i1 & 31u));
    }
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((unsigned)x0 == (unsigned)l0), (unsigned)(p2 < 0x6b9272du), (u2 << ((unsigned)(w0 >> 29) & 31u))); }
    u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)((short)(unsigned)((short)fuel > (signed char)0x4db2656du) > (signed char)*mp) < (unsigned)(0x65585b27u || 4u));
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            u1 ^= (a0[i0 & 3u] ? 0x7fffffffu : u3);
            if (0x8f7e1adau) goto done;
            v0 = ((0x57f90cddu >> (0x2ca2bc75u & 31u)) / ((unsigned)(short)(unsigned)(0x80000000u || (unsigned)x0) | 1u));
            *q0 = ((unsigned)f0 / ((unsigned)((int)(unsigned)x0 < (int)(unsigned)((int)1u < (int)i2)) | 1u));
            if ((unsigned)d0) break;
        }
        r0.y ^= ((unsigned)(g0 || (7u * (unsigned)h0)) + (unsigned)h1);
        s0 = (int)(unsigned)((int)(unsigned)!(unsigned)((int)(a0[u1 & 3u] & 9u) < (int)0x80c95971u) >= (int)(unsigned)!((unsigned)h1 >> (9u & 31u)));
    } while (i0++ < 6u && (g1 >> (u2 & 31u)));
    { unsigned t2; double z2; if (((garr[u2 & 7u] % (0xa5e1c2c1u | 1u))) & 1u) { t2 = ((unsigned)e0 * (0x10000u << ((unsigned)w0 & 31u))); z2 = (double)((0xffffffffu) & 255u); } if (((garr[u2 & 7u] % (0xa5e1c2c1u | 1u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        if (((u0 % (0x10000u | 1u)) >> (m0 & 31u))) goto L3;
        *q0 += p0;
        if (budget != 0u) { budget -= 1u; u3 = fn0(garr[u2 & 7u], ((u1 % (0x8a0301bbu | 1u)) % (a0[i0 & 3u] | 1u)), (-(unsigned)((int)0x80000000u < (int)p1) >> (garr[u2 & 7u] & 31u))); }
    }
    u1 = (u0 >> ((unsigned)((int)(0x87c33710u % (u3 | 1u)) >= (int)a0[u1 & 3u]) & 31u));
    switch (0x69fc4631u & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)f0 | p1), (unsigned)(unsigned char)((unsigned)c0 * (u3 | 9u)), 0x53fdbcefu); }
        garr[(unsigned)s0 & 7u] = (~(u2 ? (unsigned)(0xd033071u && p2) : g0) << ((unsigned)h0 & 31u));
    }
    if (((unsigned)c1 + (i1 ^ 6u))) goto done;
    while (i0++ < 3u && ((unsigned)(short)(unsigned)(u0 < 4u) >> (0xa4d7791fu & 31u))) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)d0, ((0x80000000u ^ (unsigned)f0) >> (0xffffffffu & 31u)), ((unsigned)!((unsigned)h1 | r0.x) ^ 0x491417a2u)); }
            break; (void)((g1 >> (0x539949ebu & 31u)));
            v0 = 0x256cf177u;
        } while (i1++ < 6u && garr[i1 & 7u]);
        q0 = &garr[((unsigned)s0 & 0x676da9d7u) & 7u];
        *q0 += (((unsigned)h1 * ((unsigned)c0 / (a0[i0 & 3u] | 1u))) << (p1 & 31u));
        s0 = (int)((unsigned)h0 >> (8u & 31u));
    }
    if (u0) {
        if (((unsigned)s1 | 0x25bc2736u)) goto L1;
    }
    a0[(unsigned)(short)((unsigned)c0 ^ 2u) & 3u] = ((unsigned)((unsigned)(signed char)((0u ^ a0[i0 & 3u]) >> (p2 & 31u)) < (unsigned)f0) + (unsigned)x0);
    u3 = u3 * 0x9e3779b1u + (unsigned)s1;
    c1 = (signed char)((4u * 0x80000000u) - 0xe7db920eu);
    *q0 += (unsigned)((*q0 << (*q0 & 31u)) == 0x563a8c97u);
    if ((unsigned)(u1 < (unsigned)(u3 == m0))) {
        u1 = ((unsigned)h0 % ((unsigned)x0 | 1u));
    } else {
        g1 += 0xfcdf3c05u;
        if (0x92880502u) {
            goto L3;
            u2 = ((~(u1 * (unsigned)h0) ? *q0 : (unsigned)(x0 >> 70)) * p1);
            if ((unsigned)(7u && (unsigned)(a0[i0 & 3u] < *q0))) {
                goto L1;
                r0.x = (unsigned)s1;
                if ((unsigned)((int)*mp >= (int)(unsigned)c1)) goto L4;
            } else {
                q0 = &garr[(unsigned)((short)0x46b9fcb8u > (signed char)garr[i1 & 7u]) & 7u];
                u1 = u1 * 0x9e3779b1u + (unsigned)c1;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)0x80000000u < (int)0x9f677413u), (-(p2 ^ i2) + (unsigned)c1), 0x3e9035c4u); }
            }
        } else {
            if (((unsigned)s0 ^ ((unsigned)e0 % (r0.x | 1u)))) {
                i0 = (unsigned)(0xffffffffu && ((9u * 0xffffffffu) * (unsigned)c0)) & 15u;
                if ((unsigned)((int)9u >= (int)0x7fffffffu)) {
                    g1 += ((garr[u2 & 7u] >> (*mp & 31u)) % (((unsigned)b0 & 0x80000000u) | 1u));
                    if (u3 == 7u) return (unsigned)((p0 >> ((p0 * i1) & 31u)) == (i2 + 1u));
                    if ((unsigned)((int)0xffffffffu >= (int)(0u % (p2 | 1u)))) goto done;
                    switch ((unsigned)!(fuel & (garr[i1 & 7u] ^ (unsigned)l0)) & 7u) {
                        r0.y ^= (unsigned)(0x7fffffffu && (unsigned)(short)(garr[i1 & 7u] << ((8u | 0x50f15fabu) & 31u)));
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn1((*mp % (a0[u1 & 3u] | 1u)), 4u, (unsigned)(unsigned char)(unsigned)((unsigned)((short)garr[u2 & 7u] > (signed char)r0.x) == i2)); }
                    if (0x7fffffffu) goto L1;
                }
                s1 = (int)((unsigned)s1 + (unsigned)((short)(((g0 << (0u & 31u)) ^ 0x8389630bu) & 7u) > (signed char)9u));
                if (m0) goto L0;
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (unsigned)(i2 < (unsigned)c0));
                }
                *mp = (a0[u1 & 3u] / ((unsigned)(x0 >> 70) | 1u));
            }
            g1 += (unsigned)(m0 && 2u);
            goto L0;
            if (budget != 0u) { budget -= 1u; u1 = fn2(((0x10000u | 9u) / (a0[i0 & 3u] | 1u)), 0xeabd7539u, (unsigned)((int)(0xb2430545u ^ r0.y) < (int)garr[i1 & 7u])); }
        }
        if (0x6a993023u) goto L3;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((0x7f60af65u & (u3 * 0xffffffffu)), (unsigned)(unsigned char)(unsigned)((int)m0 >= (int)(0x10000u + 1u)), (0x80000000u & (unsigned)(unsigned char)(unsigned)((int)8u >= (int)(unsigned)l0))); }
    if (((unsigned)(x0 >> 70) << ((unsigned)(0x1f04236du < (unsigned)h1) & 31u))) goto L3;
    if (budget != 0u) { budget -= 1u; u1 = fn1((*q0 - fuel), (u3 << (i1 & 31u)), u0); }
    while (i0++ < 6u && (0x99f6655eu >> ((unsigned)s1 & 31u))) { if (--fuel == 0u) goto done;
        m0 ^= (unsigned)((int)((unsigned)(w0 >> 29) + 4u) >= (int)(((unsigned)b0 & 0xffffffffu) & garr[i1 & 7u]));
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)~(unsigned)((unsigned)((unsigned)b0 && (unsigned)c1) && 6u) < (int)7u);
    if (budget != 0u) { budget -= 1u; u0 = fn0((((unsigned)e0 * (unsigned)(x0 >> 70)) >> (garr[i1 & 7u] & 31u)), ((0x80000000u * fuel) - (unsigned)h1), a0[u1 & 3u]); }
    { unsigned t3; double z3; if ((v0) & 1u) { t3 = (0x80000000u >> (*mp & 31u)); z3 = (double)(((a0[i0 & 3u] | fuel)) & 255u); } if ((v0) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        a0[m0 & 3u] = (unsigned)(short)((unsigned)((int)p1 >= (int)(unsigned)x0) + 0x900e09aau);
    }
    do { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(unsigned char)(0x10000u + 2u) || (0xffffffffu << ((unsigned)h0 & 31u)));
        if ((unsigned)(a0[i0 & 3u] && ((unsigned)s0 * a0[u1 & 3u]))) break;
        if ((unsigned)(w0 >> 29)) break;
        if ((unsigned)!(unsigned)((unsigned)l0 || ((unsigned)(w0 >> 29) >> (i2 & 31u)))) continue;
    } while (i0++ < 6u && ((unsigned)s1 << ((unsigned)(signed char)(0xc772fc8fu % (i2 | 1u)) & 31u)));
    if ((unsigned)((int)1u >= (int)(unsigned)w0)) {
        if (-(*q0 | (u2 | (unsigned)c1))) goto L4;
        if ((unsigned)((short)0x32a81b8fu > (signed char)(unsigned)x0)) {
            if ((unsigned)((a0[u1 & 3u] % (v0 | 1u)) < (unsigned)c0)) goto done;
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + ((unsigned)(unsigned char)((unsigned)f0 ^ (unsigned)d0) - (unsigned)s0);
                w0 ^= (unsigned long long)7u << (((a0[u1 & 3u] + (unsigned)(-((unsigned)h1 & v0) || u0)) + (unsigned)s1) & 63u);
                u3 += -(unsigned)((unsigned)e0 || i1);
                g1 += ((unsigned)f0 + (unsigned)h1);
                g1 += ((unsigned)((int)(unsigned)((int)(unsigned)(w0 >> 29) < (int)0xffffffffu) >= (int)(unsigned)(w0 >> 29)) * (unsigned)c0);
            }
        }
        b0 = (unsigned)(unsigned char)(unsigned)(a0[u1 & 3u] && p0) != 0u;
    } else {
        l0 = (long)((unsigned long)l0 + ((unsigned)f0 % ((unsigned)((int)m0 >= (int)(unsigned)(i1 || (unsigned)d0)) | 1u)));
        if (((unsigned)c1 * (unsigned)c0)) goto L3;
        h1 = (unsigned short)(h1 + i0);
        m0 ^= (unsigned)((int)(unsigned)e0 >= (int)r0.x);
    }
    if (~(p2 + (unsigned)((short)0x10000u > (signed char)garr[u2 & 7u]))) goto L1;
    if (garr[i1 & 7u]) goto done;
    { unsigned t4; double z4; if (((r0.y & (0x715dde1eu % ((unsigned)s0 | 1u)))) & 1u) { t4 = (unsigned)b0; z4 = (double)(((unsigned)s1) & 255u); } if (((r0.y & (0x715dde1eu % ((unsigned)s0 | 1u)))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
        goto L2;
        if ((unsigned)(short)(((unsigned)e0 << (0x10000u & 31u)) & (unsigned)c1)) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            switch ((unsigned)((short)0xec37383cu > (signed char)p0) & 7u) {
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)u2 >= (int)(r0.y & r0.x));
                for (;;) { if (--fuel == 0u) goto done;
                    *q0 += p1;
                    if ((unsigned)((int)(a0[u1 & 3u] >> (p1 & 31u)) >= (int)i0)) {
                        case 7u: ;
                        g0 = (unsigned)(m0 == (0xc39164c3u ^ ((unsigned)((int)garr[u2 & 7u] < (int)6u) / ((unsigned)l0 | 1u))));
                        u1 += (p2 & (unsigned)(unsigned char)(unsigned)((short)u0 > (signed char)0x1efabf46u));
                        switch ((garr[i1 & 7u] + ~(0u | (unsigned)b0)) & 7u) {
                            if (i1) continue;
                            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)((int)(0xffffffffu & p2) < (int)*q0) < (int)0x7fffffffu));
                            if ((unsigned)(r0.x || 2u)) continue;
                            h1 = (unsigned short)(h1 + (unsigned)(i2 < (r0.x * (unsigned)(0x80000000u || 0x603fa982u))));
                        }
                        i0 = ((unsigned)(a0[i0 & 3u] == r0.x) + ((unsigned)(x0 >> 70) - r0.y)) & 15u;
                        s1 = (int)((unsigned)s1 + i0);
                    } else {
                        u1 = u1 * 0x9e3779b1u + (unsigned)((int)6u < (int)(unsigned)b0);
                        case 1u: ;
                        case 6u: ;
                    }
                }
                *q0 += ((unsigned)((short)(unsigned)(short)(*q0 << (u2 & 31u)) > (signed char)(unsigned)d0) | (unsigned)(unsigned char)(unsigned)((int)u3 >= (int)(unsigned)f0));
                u1 += (((0x80000000u & (unsigned)s0) ^ r0.x) / ((unsigned)s0 | 1u));
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(u1 == i1) >> (3u & 31u)), (unsigned)((unsigned)b0 == (unsigned)c0), (1u << (fuel & 31u))); }
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((u1 ^ p1), (unsigned)(w0 >> 29), ((unsigned)(r0.y < u3) * (unsigned)h1)); }
            while (i1++ < 2u && (unsigned)(a0[i0 & 3u] || (unsigned)((unsigned)h0 == fuel))) { if (--fuel == 0u) goto done;
                s0 = (int)garr[u2 & 7u];
                c1 = (signed char)-((unsigned)((unsigned)c0 == g0) * (unsigned)(p2 && (unsigned)x0));
                s1 = (int)((unsigned)s1 + g0);
                *q0 = (-(unsigned)(u1 == (unsigned)(w0 >> 29)) - 0x80000000u);
            }
            do { if (--fuel == 0u) goto done;
                if (p1) {
                    if (((unsigned)h1 & (g0 | 0xfeeab433u))) break;
                    if (((unsigned)!((unsigned)e0 ^ r0.x) - u2)) break;
                }
                if (p1) {
                    do { if (--fuel == 0u) goto done;
                        r0.x = (unsigned)((short)i1 > (signed char)(unsigned)(g0 || *q0));
                        switch (0x62f98010u & 7u) {
                            h0 = (short)((unsigned)d0 | (5u ? i0 : (unsigned)c0));
                            r0.x = *mp;
                            r0.y ^= a0[u1 & 3u];
                            case 2u: ;
                        }
                        r0.x = -((r0.x - p0) - 0x7fffffffu);
                    } while (i2++ < 7u && ((unsigned)x0 / ((unsigned)s0 | 1u)));
                    i0 = (((unsigned)e0 | (unsigned)h0) - (unsigned)(v0 == p1)) & 15u;
                    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)!(u2 | (unsigned)s0), (6u % (0x80000000u | 1u)), ((unsigned)((unsigned)c0 == u1) - 0x3cbddf03u)); }
                    w0 = w0 * 6364136223846793005ull + (unsigned)(x0 >> 70);
                } else {
                    u2 ^= (unsigned)e0;
                    x0 = x0 * 0x100000001b3ull + 0xe47bba5cu;
                }
                for (;;) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)(short)((unsigned)f0 - (unsigned)(0x80000000u == garr[u2 & 7u]));
                    *q0 = (unsigned)(signed char)(~(g0 & i1) & 0x3afaa610u);
                    r0.x = ((unsigned)(i2 && u0) % (-(0x2cd4ae2eu * 0xcc1bd4b1u) | 1u));
                }
            } while (i1++ < 7u && (unsigned)(p1 || 0x80000000u));
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)x0) break;
                if ((((unsigned)h0 >> (r0.y & 31u)) / (m0 | 1u))) break;
                u2 ^= (unsigned)(unsigned char)((unsigned)(unsigned char)((unsigned)(w0 >> 29) + m0) + (unsigned)h0);
                b0 = (unsigned)((int)(unsigned)(u0 && ((unsigned)((unsigned)c1 && i1) ^ 0x7fffffffu)) >= (int)1u) != 0u;
                g1 += (garr[u2 & 7u] * u0);
            }
        }
        r0.y ^= -(unsigned)(0x80000000u || (i2 >> ((unsigned)f0 & 31u)));
    }
    switch (0xffffffffu & 7u) {
        v0 = (unsigned)((int)(g0 / (garr[u2 & 7u] | 1u)) < (int)0xea816158u);
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((unsigned)(short)(unsigned)((unsigned)h0 == a0[u1 & 3u]) || (unsigned)s0), (unsigned)(0x10000u < (unsigned)(w0 >> 29)), (u3 * ((unsigned)f0 + p0))); }
        u3 = u3 * 0x9e3779b1u + (((unsigned)h0 >> (0x7fffffffu & 31u)) >> ((((unsigned)(w0 >> 29) << (a0[i0 & 3u] & 31u)) / (*q0 | 1u)) & 31u));
        case 4u: ;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto done;
    if ((unsigned)(short)(unsigned)((0x80000000u + 0x80000000u) == i1)) goto done;
    w0 ^= (unsigned long long)(0xfb5400fau >> ((unsigned)h1 & 31u)) << (((unsigned)s0 & 0xffffffffu) & 63u);
    d0 = d0 * 0.5 + (double)((unsigned)w0 & 1023u);
    garr[6u & 7u] = ((unsigned)s1 & i0);
    L0: if (--fuel == 0u) goto done;
    s1 = (int)((unsigned)s1 + *mp);
    L1: if (--fuel == 0u) goto done;
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if (((unsigned)(x0 >> 70)) & 1u) { t0 = ~(unsigned)((int)(unsigned)l0 >= (int)0x5923869eu); z0 = (double)((m0) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                u2 = u2 * 0x9e3779b1u + (unsigned)((0x7fffffffu * i2) || (unsigned)(((unsigned)x0 ^ u0) < 0xe9f8c140u));
                L2: if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    s0 = (int)((unsigned)c0 % ((unsigned)!((unsigned)e0 ^ (unsigned)(short)(unsigned)((a0[i0 & 3u] * u2) < a0[i0 & 3u])) | 1u));
                    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        L3: if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((short)0x816d4c77u > (signed char)2u));
                        c1 = (signed char)(unsigned)(w0 >> 29);
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn3((u1 & ((unsigned)h1 ^ (unsigned)h1)), (unsigned)c1, (unsigned)((int)(unsigned)h0 >= (int)p0)); }
                    for (;;) { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            if (((unsigned)h0 & p2)) break;
                            v0 = (unsigned)((int)(unsigned)((short)0x80000000u > (signed char)(unsigned)c1) < (int)~(6u << ((g1 | i0) & 31u)));
                            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)0x7ba3fd61u < (int)(unsigned)c1), (i1 & (unsigned)(i1 < (unsigned)h1)), (unsigned)((unsigned)((short)r0.x > (signed char)(unsigned)x0) && 0x7fffffffu)); }
                        } while (i1++ < 6u && ((unsigned)((unsigned)e0 && g0) * 0x80000000u));
                        break; (void)(((8u << (a0[u1 & 3u] & 31u)) % (fuel | 1u)));
                        c0 = (unsigned char)(unsigned)((int)(unsigned)c1 >= (int)(unsigned)((short)(unsigned)((int)(unsigned)w0 < (int)(unsigned)((int)(unsigned)s0 < (int)u2)) > (signed char)(unsigned)e0));
                        v0 = v0;
                        break; (void)(((2u & (unsigned)(x0 >> 70)) + *mp));
                        break; (void)((unsigned)((unsigned)h1 < (unsigned)c1));
                    }
                } while (i2++ < 5u && 0x6ffa4c93u);
                s0 = (int)(((unsigned)w0 + (unsigned)x0) >> ((unsigned)((garr[i1 & 7u] & 7u) && 0x7fffffffu) & 31u));
                r0.x = (*mp * (0x10000u | (unsigned)((unsigned)e0 == 0x9077e41fu)));
            }
            if ((g1 | p1)) break;
            *mp = (unsigned)((unsigned)(0xcb1c77eau && 0xffffffffu) && (unsigned)(short)(3u & r0.y));
            switch (-(unsigned)(*q0 || 5u) & 7u) {
                c1 = (signed char)(0x7fffffffu / ((unsigned)x0 | 1u));
                s0 = (int)p2;
                r0.x = u0;
            }
        }
        h1 = (unsigned short)(h1 + ((unsigned)h1 & (unsigned)h1));
        u3 ^= (unsigned)((unsigned)(x0 >> 70) || 0x43ac707au);
        while (i1++ < 2u && *q0) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + ((i0 ^ (unsigned)f0) << (0x10000u & 31u)));
            if (~(unsigned)((unsigned)w0 || garr[u2 & 7u])) break;
            if (budget != 0u) { budget -= 1u; u2 = fn1((0xffffffffu % ((unsigned)((unsigned)f0 && (unsigned)w0) | 1u)), (*q0 % (i1 | 1u)), ((unsigned)(a0[i0 & 3u] && p1) - 0x10e4d7a4u)); }
            do { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(4u & 255u);
                if (budget != 0u) { budget -= 1u; u3 = fn2(u2, (g0 * a0[i0 & 3u]), (0xffffffffu ? (unsigned)l0 : u0)); }
                L4: if (--fuel == 0u) goto done;
                if ((unsigned)((short)(unsigned)c0 > (signed char)*q0)) break;
                while (i0++ < 7u && ((p0 + 0x10000u) >> (m0 & 31u))) { if (--fuel == 0u) goto done;
                    while (i1++ < 5u && (unsigned)!(0x80000000u >> (u2 & 31u))) { if (--fuel == 0u) goto done;
                        if (0x7fffffffu) break;
                        if ((unsigned)((int)(a0[u1 & 3u] / ((unsigned)h0 | 1u)) < (int)(unsigned)x0)) break;
                        x0 = x0 * 0x100000001b3ull + 4u;
                    }
                    switch ((0x7fffffffu | (p1 ^ m0)) & 7u) {
                        if ((0x80000000u << ((unsigned)c0 & 31u))) {
                            break; (void)((unsigned)f0);
                            if ((unsigned)(signed char)(unsigned)((short)(unsigned)h1 > (signed char)0xffffffffu)) break;
                            continue; (void)((unsigned)(unsigned char)(v0 + ((unsigned)(w0 >> 29) / (u2 | 1u))));
                            if ((0xf4b594d2u ^ (unsigned)(x0 >> 70))) break;
                            case 2u: ;
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)(signed char)(unsigned)((int)0x7fffffffu >= (int)i0) || garr[i1 & 7u]), u3, ((unsigned)w0 / ((unsigned)h1 | 1u))); }
                        } else {
                            g1 += ((unsigned)((unsigned)b0 || u0) ? 2u : (unsigned)f0);
                            e0 = e0 * 0.5L + (long double)((unsigned)((g1 % (((unsigned)e0 / (p1 | 1u)) | 1u)) && (0x7fffffffu | r0.x)) & 1023u);
                            if (budget != 0u) { budget -= 1u; u3 = fn2((0x64c3d38du - 0x10000u), (p2 % (((unsigned)(x0 >> 70) + 4u) | 1u)), r0.y); }
                        }
                        case 1u: ;
                        case 5u: ;
                    }
                    if (((unsigned)(w0 >> 29) ^ u2)) goto done;
                    switch ((unsigned)d0 & 7u) {
                        i1 = (g1 >> (((unsigned)h0 ? u1 : 1u) & 31u)) & 15u;
                        case 0u: ;
                        if (p2) break;
                        if (budget != 0u) { budget -= 1u; u2 = fn3((g1 / (((unsigned)x0 * 0xffffffffu) | 1u)), i1, (fuel ? 0xffffffffu : u2)); }
                        default: ;
                        b0 = (3u & (unsigned)x0) != 0u;
                    }
                    if (((unsigned)h1 >> (p1 & 31u))) break;
                    c1 = (signed char)(unsigned)((short)*q0 > (signed char)(unsigned)(x0 >> 70));
                }
            } while (i2++ < 6u && (unsigned)f0);
        }
        if ((unsigned)c0) break;
        if (budget != 0u) { budget -= 1u; u3 = fn0(v0, p1, i2); }
    } while (i0++ < 3u && (unsigned)x0);
    if (budget != 0u) { budget -= 1u; u3 = fn0((i2 + (0x80000000u >> ((unsigned)w0 & 31u))), (unsigned)(signed char)(1u ^ (unsigned)h1), (unsigned)((int)(unsigned)b0 < (int)(unsigned)f0)); }
    if (4u) goto L0;
    while ((unsigned)((short)*q0 > (signed char)i2)) { if (--fuel == 0u) goto done;
        goto L4;
        if (((unsigned)d0 * 0u)) break;
        if (budget != 0u) { budget -= 1u; u2 = fn2(p2, (unsigned)x0, i1); }
        if ((g1 + (unsigned)((int)m0 >= (int)i2))) break;
        { unsigned t1; double z1; if ((i0) & 1u) { t1 = v0; z1 = (double)(((unsigned)((int)((unsigned)(w0 >> 29) / (0x7a8062aau | 1u)) < (int)i2)) & 255u); } if ((i0) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            if (((unsigned)(x0 >> 70) ^ garr[i1 & 7u])) {
                switch ((unsigned)((u1 % (0x7fffffffu | 1u)) < (unsigned)f0) & 7u) {
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((short)((unsigned)x0 << (m0 & 31u)) > (signed char)i1), (unsigned)((unsigned)h1 || fuel), g0); }
                }
                c1 = (signed char)0u;
            } else {
                *q0 = (u3 >> ((unsigned)((unsigned)(x0 >> 70) == 0xffc952au) & 31u));
            }
            d0 = d0 * 0.5 + (double)((unsigned)!((unsigned)((u1 % (i1 | 1u)) == 2u) & (u3 / (0x178488a1u | 1u))) & 1023u);
        }
        h0 = (short)((unsigned)h1 - (unsigned)(x0 >> 70));
    }
    *mp = -((unsigned)s1 ^ 0xab315defu);
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)((unsigned)x0 && 7u) && u0)) goto done;
    } while (i0++ < 4u && u3);
    if ((8u * 8u)) goto L2;
    g0 = -(0x80000000u & i2);
    h1 = (unsigned short)(h1 + (unsigned)(((unsigned)l0 % ((unsigned)((int)5u >= (int)r0.x) | 1u)) || a0[u1 & 3u]));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((p1 % (0x10000u | 1u)) & 7u) {
            if (((unsigned)e0 | (unsigned)(m0 && m0))) break;
            a0[i0 & 3u] = ((m0 & 0x8d8600a9u) - 9u);
            if (budget != 0u) { budget -= 1u; u0 = fn0(fuel, garr[u2 & 7u], ((u3 % ((unsigned)h1 | 1u)) * u3)); }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn2(g0, -(i2 - u3), (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)w0)); }
        if ((p2 | -(0x77c57f10u << ((unsigned)c0 & 31u)))) break;
        if ((unsigned)((unsigned)c0 && i2)) {
            i2 = ((unsigned)(i2 || v0) ? (unsigned)h0 : (unsigned)c1) & 15u;
            c0 = (unsigned char)0x80000000u;
        } else {
            *mp = (unsigned)((int)garr[i1 & 7u] < (int)0xe87f0ce5u);
            g0 = -(i0 | (unsigned)((short)0x80000000u > (signed char)(u3 ? u2 : (unsigned)l0)));
            if (((unsigned)(0x7fffffffu == i1) & 8u)) continue;
            { unsigned t2; double z2; if (((~(u2 ^ (unsigned)s1) | (unsigned)x0)) & 1u) { t2 = (unsigned)!(unsigned)((unsigned)b0 && (unsigned)((int)p0 >= (int)0x2322956cu)); z2 = (double)(((i1 / (0x67136e93u | 1u))) & 255u); } if (((~(u2 ^ (unsigned)s1) | (unsigned)x0)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                if ((i1 / ((unsigned)w0 | 1u))) break;
            }
        }
        if ((unsigned)(0u == (0xe7e31ae0u / ((unsigned)h1 | 1u)))) {
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(((unsigned)!(unsigned)((unsigned)l0 == ((unsigned)s0 % (m0 | 1u))) - (0x10000u >> (m0 & 31u))) & 1023u);
                b0 = ((unsigned)((int)0x80000000u >= (int)r0.y) % (r0.y | 1u)) != 0u;
                r0.y ^= (unsigned)((unsigned)(short)(unsigned)(0x80000000u == *q0) || 0x80000000u);
                b0 = (unsigned)(signed char)(0xddd2c6fau << ((p1 % ((0u - ((unsigned)d0 >> (u3 & 31u))) | 1u)) & 31u)) != 0u;
                f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)l0 + (0x80000000u ^ p2)) && (0u - u1)) & 255u);
                do { if (--fuel == 0u) goto done;
                    c1 = (signed char)(0x29887eb6u ? (a0[u1 & 3u] - 7u) : i2);
                } while (i2++ < 5u && (unsigned)(w0 >> 29));
            }
            while (i1++ < 2u && (unsigned)((short)u2 > (signed char)(unsigned)(short)(unsigned)(2u || 1u))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2((4u ^ a0[u1 & 3u]), (unsigned)((int)(p1 << (0xf4f83b21u & 31u)) < (int)u1), garr[u2 & 7u]); }
                if (r0.x) break;
                if (garr[i1 & 7u]) break;
                garr[0x24c7177eu & 7u] = 0xffffffffu;
            }
            goto L0;
        } else {
            h1 = (unsigned short)(h1 + (unsigned)l0);
        }
    }
    switch ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)2u) & 7u) {
        if ((p0 / (garr[u2 & 7u] | 1u))) break;
        while ((0xb27f2eedu - (g0 << (i0 & 31u)))) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)((unsigned)((unsigned)(w0 >> 29) || i1) || (unsigned)h0);
            *q0 += (unsigned)((short)(unsigned)s0 > (signed char)(u2 << ((4u ? (unsigned)d0 : g1) & 31u)));
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                garr[0u & 7u] = (unsigned)(((unsigned)s0 & u2) < (unsigned)((unsigned)c1 < r0.y));
            }
            case 2u: ;
            e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)(((unsigned)h0 << ((unsigned)l0 & 31u)) * (unsigned)(0xffffffffu < (unsigned)((unsigned)d0 < garr[i1 & 7u]))) & 1023u);
            f0 = f0 * 0.5f + (float)(((unsigned)l0 | (r0.x / ((unsigned)h0 | 1u))) & 255u);
        }
        while (i0++ < 3u && (3u ^ (unsigned)(u1 < r0.x))) { if (--fuel == 0u) goto done;
            i2 = (0x24a61a1bu - (unsigned)((int)(unsigned)(0x7fffffffu < (unsigned)(x0 >> 70)) >= (int)(unsigned)d0)) & 15u;
            i0 = ((unsigned)w0 + *q0) & 15u;
            if (-((i2 << (r0.x & 31u)) / (0xa6df1974u | 1u))) {
                h1 = (unsigned short)(h1 + garr[u2 & 7u]);
                for (;;) { if (--fuel == 0u) goto done;
                    m0 ^= (i0 - ((unsigned)((int)(r0.y % (*q0 | 1u)) < (int)*q0) | (unsigned)e0));
                    w0 ^= (unsigned long long)(*q0 / (3u | 1u)) << ((a0[u1 & 3u] << ((0x80000000u ? p0 : 0x889637e3u) & 31u)) & 63u);
                    garr[(unsigned)((int)(unsigned)e0 < (int)4u) & 7u] = i0;
                }
            }
            *mp = (4u / (g0 | 1u));
            if ((unsigned)w0) {
                default: ;
                h0 = (short)(unsigned)(((unsigned)e0 >> (i2 & 31u)) < (unsigned)(u0 == (unsigned)l0));
                if (budget != 0u) { budget -= 1u; u3 = fn2((0xd0b3c1afu << (((unsigned)f0 ^ a0[u1 & 3u]) & 31u)), (unsigned)e0, (i2 << (0x80000000u & 31u))); }
                case 1u: ;
            }
        }
        v0 = ((5u * garr[u2 & 7u]) / ((unsigned)((int)fuel < (int)0x80000000u) | 1u));
        do { if (--fuel == 0u) goto done;
            if ((0x3697a924u | (0x7fffffffu & (unsigned)d0))) goto L3;
            s0 = (int)((unsigned)e0 ^ (unsigned)((7u ^ r0.y) < v0));
            for (;;) { if (--fuel == 0u) goto done;
                case 6u: ;
            }
            h1 = (unsigned short)(h1 + (unsigned)((short)p1 > (signed char)(g0 % ((unsigned)((int)i2 >= (int)i0) | 1u))));
        } while (i0++ < 2u && (0x80000000u * i0));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn2(a0[u1 & 3u], (g0 ^ 0x9baf7effu), (0xbeaa40a2u << (0xcbc9658du & 31u))); }
    *q0 = ((unsigned)((unsigned)e0 && 1u) + (unsigned)(garr[i1 & 7u] && ((unsigned)s0 * 0xca61eed7u)));
    *q0 += (unsigned)((unsigned)(signed char)(unsigned)((0x7fffffffu | i2) && p2) == -((unsigned)c1 - (unsigned)e0));
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(m0 == (7u % (u1 | 1u))), ((unsigned)s0 * (unsigned)((unsigned)s1 < garr[u2 & 7u])), (0xffffffffu / (((unsigned)b0 << (0xa6d7ff33u & 31u)) | 1u))); }
    if ((u1 - g1)) {
        if ((((unsigned)s0 / (r0.x | 1u)) & *mp)) goto L0;
    } else {
        c0 = (unsigned char)(fuel % (((unsigned)((unsigned)w0 == 0x8e43a999u) & i1) | 1u));
        if (((unsigned)b0 & u2)) {
            i0 = (i2 * ((unsigned)c1 >> (0xfdb3426au & 31u))) & 15u;
            if (r0.y) goto L4;
            u2 = ~((u1 * (unsigned)(x0 >> 70)) | 0xd14a7717u);
            goto L2;
            if ((unsigned)s1) goto L2;
            while (i0++ < 6u && (unsigned)((unsigned)c0 == (unsigned)b0)) { if (--fuel == 0u) goto done;
                g1 += (unsigned)!(unsigned)((unsigned)h0 && (unsigned)!(unsigned)(((unsigned)d0 & 5u) || (unsigned)((int)garr[u2 & 7u] < (int)v0)));
                switch (((unsigned)(w0 >> 29) + (unsigned)c1) & 7u) {
                    break; (void)((m0 >> ((garr[u2 & 7u] & (unsigned)e0) & 31u)));
                }
                h1 = (unsigned short)(h1 + (m0 + 0x9942e37u));
            }
        } else {
            *mp = (unsigned)!((unsigned)h1 & (unsigned)((int)(garr[u2 & 7u] << (0xffffffffu & 31u)) < (int)u3));
            if (g1) goto done;
            if ((unsigned)((short)(unsigned)(fuel || u3) > (signed char)0x7fffffffu)) {
                garr[((unsigned)h1 ^ (unsigned)f0) & 7u] = (unsigned)((i2 & (0x80634d53u % (m0 | 1u))) || (u2 << (5u & 31u)));
                if ((7u % ((unsigned)l0 | 1u))) goto L2;
                r0.x = fuel;
                if ((unsigned)(short)(unsigned)(u3 || (unsigned)((int)(unsigned)b0 >= (int)garr[i1 & 7u]))) goto done;
                g0 = (unsigned)((short)(((unsigned)x0 / (4u | 1u)) << ((unsigned)h1 & 31u)) > (signed char)garr[i1 & 7u]);
            }
        }
    }
    if ((unsigned)((int)(fuel << (p2 & 31u)) >= (int)g1)) goto done;
    if (u3 == 7u) return ((unsigned)!((unsigned)d0 ^ (unsigned)l0) | i2);
    if (fuel) goto L3;
    if (((p1 - 4u) << (0x2266a952u & 31u))) {
        m0 ^= ((unsigned)l0 + 0x7fffffffu);
        w0 = w0 * 6364136223846793005ull + (p1 >> (u2 & 31u));
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)e0) {
                if ((7u & (unsigned)!((unsigned)s1 << (p1 & 31u)))) continue;
                if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)h1 / (~(unsigned)(i0 && 0x10000u) | 1u)), 5u, (6u << ((unsigned)c0 & 31u))); }
                if (~(unsigned)((int)(unsigned)x0 < (int)u3)) break;
                x0 = x0 * 0x100000001b3ull + 9u;
                if (0xab95cc53u) {
                    *q0 += (i1 & (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)((int)garr[i1 & 7u] < (int)garr[i1 & 7u])));
                    for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        c0 = (unsigned char)8u;
                        v0 = g0;
                        if (u3 == 7u) return (unsigned)(garr[i1 & 7u] && ((unsigned)b0 + -(unsigned)((int)u3 < (int)0x691a88beu)));
                    }
                    q0 = &garr[(unsigned)((unsigned)c0 && (unsigned)((int)5u < (int)u0)) & 7u];
                    h0 = (short)(1u ^ (unsigned)(i0 && a0[i0 & 3u]));
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)!(3u ^ (unsigned)e0) == r0.x), (unsigned)(a0[i0 & 3u] || 0x80000000u), (unsigned)(w0 >> 29)); }
                } else {
                    v0 = u1;
                    if ((0x4bef283au ? 0xdd029957u : (unsigned)x0)) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)c1, (unsigned)h1, (u2 ^ (unsigned)(w0 >> 29))); }
                }
            }
            s1 = (int)((unsigned)s1 + ((0x80000000u >> (0x5e660c4u & 31u)) % ((m0 % (((unsigned)s1 | i1) | 1u)) | 1u)));
            if ((unsigned)((unsigned)(0x44f88117u || p2) || g1)) break;
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)(8u || (unsigned)(0xfaaa9024u && 0x58addec8u)) < (int)(v0 / (u1 | 1u)));
            if (u3 == 7u) return ((i0 | (fuel ^ 6u)) + (unsigned)(signed char)((unsigned)e0 + g1));
            if (u3) {
                m0 ^= ~((0u & p2) & ((unsigned)(v0 == (unsigned)h1) << (u0 & 31u)));
                break; (void)((unsigned)((unsigned)f0 == 0xc5521c80u));
                break; (void)(m0);
                w0 ^= (unsigned long long)2u << ((unsigned)((r0.x | (unsigned)(w0 >> 29)) < (unsigned)(0x10000u && (p0 + m0))) & 63u);
            } else {
                continue; (void)(~(unsigned)((unsigned)(short)(unsigned)(0x1df31c3u && g1) == 4u));
                if ((i2 - 0x7fffffffu)) break;
                i0 = 0x80000000u & 15u;
                f0 = f0 * 0.5f + (float)(r0.y & 255u);
            }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)x0 * 8u), i0, (unsigned)!(unsigned)((short)(unsigned)h0 > (signed char)(unsigned)b0)); }
    }
    switch (*q0 & 7u) {
        case 4u: ;
        case 7u: ;
        if ((~(unsigned)(0xffffffffu || 8u) / (u2 | 1u))) {
            while (i0++ < 6u && 4u) { if (--fuel == 0u) goto done;
                q0 = &garr[(7u << (((unsigned)(signed char)(2u * 9u) % ((i0 << (garr[u2 & 7u] & 31u)) | 1u)) & 31u)) & 7u];
            }
            case 1u: ;
            switch ((unsigned)((int)0xdc3baf00u < (int)6u) & 7u) {
                u0 = u0 * 0x9e3779b1u + (garr[u2 & 7u] / ((unsigned)f0 | 1u));
                { unsigned t3; double z3; if ((i1) & 1u) { t3 = (garr[i1 & 7u] & u2); z3 = (double)((garr[u2 & 7u]) & 255u); } if ((i1) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    case 5u: ;
                    case 6u: ;
                    e0 = e0 * 0.5L + (long double)((unsigned)((int)0x10000u >= (int)(unsigned)c1) & 1023u);
                }
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)(unsigned)(signed char)((unsigned)d0 | (unsigned)s1) > (signed char)p0)) {
                        c0 = (unsigned char)(unsigned)(1u && (unsigned)(0x10000u || ((unsigned)!(unsigned)((int)garr[i1 & 7u] < (int)0x15af7acdu) - 9u)));
                        continue; (void)((unsigned)((int)v0 >= (int)(unsigned)l0));
                        h1 = (unsigned short)(h1 + 0x31bc1259u);
                        do { if (--fuel == 0u) goto done;
                            h0 = (short)(((unsigned)b0 << (*mp & 31u)) + (unsigned)((int)g0 < (int)8u));
                            w0 = w0 * 6364136223846793005ull + (1u & (unsigned)((int)(v0 >> (i1 & 31u)) < (int)(unsigned)!(i1 << (0xffffffffu & 31u))));
                            s0 = (int)(unsigned)(9u < (unsigned)(u1 < (unsigned)((unsigned)c0 == (unsigned)((unsigned)h0 < i1))));
                            w0 ^= (unsigned long long)u1 << ((unsigned)(p2 == ((unsigned)(u3 == r0.y) | (unsigned)((int)garr[i1 & 7u] < (int)u2))) & 63u);
                        } while (i1++ < 2u && (u2 / (*q0 | 1u)));
                    } else {
                        default: ;
                    }
                } while (i0++ < 6u && 6u);
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    case 2u: ;
                    r0.x = (g1 - 0xbd6a5110u);
                    if (0x9e429161u) continue;
                    *q0 += ((unsigned)b0 << (0x80000000u & 31u));
                    break;
                }
            }
        }
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (-(g1 << ((u3 - (unsigned)h1) & 31u))) {
                b0 = (((unsigned)s0 / ((unsigned)h0 | 1u)) | (unsigned)f0) != 0u;
            } else {
                if ((unsigned)((int)(8u & u1) < (int)(unsigned)h0)) goto done;
                *q0 += (unsigned)d0;
                f0 = f0 * 0.5f + (float)((unsigned)(*q0 || garr[i1 & 7u]) & 255u);
                l0 = (long)((unsigned long)l0 + *q0);
            }
            w0 = w0 * 6364136223846793005ull + ((unsigned)w0 & (((unsigned)f0 >> (v0 & 31u)) ? (unsigned)h1 : u3));
            default: ;
            i0 = ((unsigned)e0 >> (a0[u1 & 3u] & 31u)) & 15u;
            do { if (--fuel == 0u) goto done;
                if (((unsigned)((unsigned)l0 || (unsigned)h1) & u0)) continue;
            } while (i1++ < 4u && (unsigned)((short)7u > (signed char)(unsigned)((unsigned)c0 == 0x73ddf3ebu)));
            { unsigned t4; double z4; if ((((0x9e386396u & 0xbb09d7edu) * i0)) & 1u) { t4 = (unsigned)((int)0xc469e03du >= (int)*q0); z4 = (double)(((unsigned)(signed char)(0x7fffffffu ^ (0u - u1))) & 255u); } if ((((0x9e386396u & 0xbb09d7edu) * i0)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                if ((unsigned)b0) break;
                if (budget != 0u) { budget -= 1u; u3 = fn2(~((unsigned)h0 << (-(unsigned)(4u < (unsigned)s0) & 31u)), (6u << (p1 & 31u)), 0xc99456f5u); }
            }
        }
        while (i0++ < 7u && ((unsigned)((int)1u < (int)p2) ^ 8u)) { if (--fuel == 0u) goto done;
            s0 = (int)(unsigned)(-(unsigned)(p0 < 0x7fffffffu) && (unsigned)((int)g0 < (int)(v0 ^ fuel)));
            break; (void)(v0);
            v0 = *q0;
            { unsigned t5; double z5; if (((i0 >> (m0 & 31u))) & 1u) { t5 = (unsigned)!((1u << (m0 & 31u)) + (unsigned)c0); z5 = (double)(((unsigned)(((unsigned)(w0 >> 29) >> ((unsigned)h1 & 31u)) && r0.y)) & 255u); } if (((i0 >> (m0 & 31u))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                i0 = (((i2 / ((unsigned)e0 | 1u)) & 4u) & r0.x) & 15u;
                do { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (2u << (0xffffffffu & 31u));
                    break;
                    w0 ^= (unsigned long long)(unsigned)((int)garr[i1 & 7u] < (int)0xc977a1a8u) << ((unsigned)((int)(r0.x * i1) >= (int)(0xa100cf1au + 0xffffffffu)) & 63u);
                    continue; (void)(r0.x);
                    switch ((unsigned)(0x300cce5cu < (unsigned)f0) & 7u) {
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(signed char)((unsigned)w0 >> ((unsigned)(short)(unsigned)((unsigned)(x0 >> 70) && 0xd9a3bc78u) & 31u)), (unsigned)(p1 || (unsigned)w0), (unsigned)((int)*mp >= (int)(0x10000u + p1))); }
                        u2 ^= m0;
                        h1 = (unsigned short)(h1 + (unsigned)(((0x80000000u / ((unsigned)(x0 >> 70) | 1u)) + 3u) || (unsigned)(signed char)(unsigned)((short)0x31808800u > (signed char)(unsigned)(w0 >> 29))));
                        case 3u: ;
                        c0 = (unsigned char)(unsigned)((int)fuel < (int)((0x41ed85a7u ^ (unsigned)(x0 >> 70)) >> (r0.y & 31u)));
                        h1 = (unsigned short)(h1 + g1);
                    }
                    *q0 += ((unsigned)(w0 >> 29) - (unsigned)h0);
                } while (i1++ < 4u && u0);
                if (0x1ec48795u) goto L1;
                case 2u: ;
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (u2) continue;
                    m0 ^= (a0[i0 & 3u] & i0);
                    if ((0xd6549b16u / ((unsigned)s1 | 1u))) continue;
                    g1 += (unsigned)((unsigned)((unsigned)e0 || p1) < ((unsigned)c0 % (8u | 1u)));
                    u2 = (unsigned)(short)(garr[u2 & 7u] / (v0 | 1u));
                }
            }
        }
        if ((0xefe7706fu >> (0x10000u & 31u))) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)e0, p2, (unsigned)w0); }
            break;
            h0 = (short)(0x9b129bc3u / (((unsigned)h0 >> (*mp & 31u)) | 1u));
            case 3u: ;
            while ((unsigned)(0xffffffffu == ((unsigned)h0 - (unsigned)f0))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(a0[i0 & 3u] || ~(unsigned)((int)0xd418988u >= (int)0x1f3399e5u)), garr[i1 & 7u], (m0 | 2u)); }
            }
            w0 ^= (unsigned long long)(unsigned)(3u && 0x80000000u) << ((unsigned)(fuel || (unsigned)((unsigned)((int)5u >= (int)i0) < (unsigned)x0)) & 63u);
        } else {
            x0 = x0 * 0x100000001b3ull + ((4u * fuel) % (p1 | 1u));
            c1 = (signed char)(u1 / ((unsigned)!(u0 & (0xffffffffu * m0)) | 1u));
        }
    }
    u3 += ((unsigned)(short)(unsigned)((short)0x7fffffffu > (signed char)(unsigned)((int)a0[u1 & 3u] >= (int)g0)) * (0x4fe8eb15u | garr[u2 & 7u]));
    goto L1;
    goto L4;
    { unsigned t6; double z6; if (((unsigned)((int)(unsigned)s1 >= (int)(unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)h0))) & 1u) { t6 = (0xffffffffu % ((unsigned)w0 | 1u)); z6 = (double)(((unsigned)((int)(unsigned)s0 < (int)8u)) & 255u); } if (((unsigned)((int)(unsigned)s1 >= (int)(unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)h0))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
        do { if (--fuel == 0u) goto done;
            if (((i2 & *q0) | (unsigned)s1)) goto L4;
            if ((unsigned)(short)(unsigned)(0x99756de4u || (unsigned)(0x7fffffffu && g0))) {
                if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)b0 | (unsigned)(w0 >> 29)), a0[i0 & 3u], (0x1dddb50bu & p1)); }
            }
            if ((a0[u1 & 3u] >> ((unsigned)((unsigned)b0 && (unsigned)w0) & 31u))) {
                do { if (--fuel == 0u) goto done;
                    u1 = (0x7fffffffu ^ (unsigned)((short)(unsigned)((int)(unsigned)x0 >= (int)0x80000000u) > (signed char)(unsigned)e0));
                    if (budget != 0u) { budget -= 1u; u2 = fn3(~(unsigned)(0xd74752efu || -(unsigned)((unsigned)c0 || 7u)), (unsigned)(a0[i0 & 3u] || (unsigned)(w0 >> 29)), 0x7fffffffu); }
                    if ((unsigned)x0) break;
                    *q0 = ((unsigned)h1 & a0[u1 & 3u]);
                    goto L3;
                } while (i1++ < 3u && p1);
                f0 = f0 * 0.5f + (float)(0xffffffffu & 255u);
                if ((unsigned)(signed char)(unsigned)((int)(u1 / (0xe9e4e44au | 1u)) < (int)(unsigned)h1)) {
                    if ((fuel - (unsigned)((unsigned)d0 || i0))) break;
                    g0 = (unsigned)(0xc93e79aau == (0x6077f01au % ((unsigned)(0u || r0.x) | 1u)));
                    r0.x = (0x6afc5a2bu % (0x1bf2a182u | 1u));
                    goto done;
                    v0 = (unsigned)((unsigned)((int)(unsigned)l0 < (int)(r0.x + (unsigned)((int)m0 >= (int)(unsigned)h0))) < (unsigned)w0);
                    if ((a0[u1 & 3u] & u0)) break;
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn0(a0[u1 & 3u], (r0.y << ((unsigned)((unsigned)c0 || u2) & 31u)), ((unsigned)w0 & 0x83131aacu)); }
                    if ((unsigned)((short)i1 > (signed char)u2)) break;
                    r0.y ^= ((unsigned)((int)i2 < (int)(unsigned)b0) << ((unsigned)f0 & 31u));
                    u1 = (a0[u1 & 3u] % (2u | 1u));
                }
                break; (void)((unsigned)(1u == 0xf55d5da8u));
                if ((*mp ^ (unsigned)(r0.y < 0x10000u))) break;
            }
            if (u3 == 7u) return (unsigned)((int)(((unsigned)w0 ^ (0x7fffffffu % (0xffffffffu | 1u))) >> (p1 & 31u)) >= (int)0x7fffffffu);
            switch (((9u ^ (unsigned)e0) | 0xffffffffu) & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn1((a0[i0 & 3u] & (unsigned)(0x5d8e1e54u == 3u)), (unsigned)((short)i2 > (signed char)0x838f5ac0u), ((unsigned)s1 | 0x80000000u)); }
            }
        } while (i0++ < 3u && fuel);
        goto L2;
    }
    if ((a0[i0 & 3u] * 0x7fffffffu)) goto L0;
    switch ((unsigned)((int)garr[i1 & 7u] >= (int)u2) & 7u) {
        switch ((unsigned)(0xffffffffu == i2) & 7u) {
            u1 = (unsigned)((int)0x5b6b515eu >= (int)5u);
            switch ((3u >> (((unsigned)s0 | 0x7fffffffu) & 31u)) & 7u) {
                *q0 = (-(0xba6ff2f8u * a0[i0 & 3u]) | (unsigned)(short)(g1 << (0x10000u & 31u)));
                u0 ^= (((unsigned)e0 + (unsigned)c0) >> (((unsigned)f0 | (unsigned)d0) & 31u));
                if (budget != 0u) { budget -= 1u; u0 = fn0((0xfea6d073u & (unsigned)(0x9263b618u == (unsigned)d0)), (unsigned)l0, 0xf8ec38bu); }
                g1 += (0x7bf28436u + a0[i0 & 3u]);
                s0 = (int)(unsigned)(((unsigned)(*q0 && 8u) - (unsigned)((unsigned)s1 || u1)) || 0xd319dd47u);
                switch ((u3 - (unsigned)(signed char)(a0[i0 & 3u] ^ (unsigned)s0)) & 7u) {
                    u1 ^= (unsigned)((unsigned)((unsigned)(garr[u2 & 7u] < (6u / (garr[u2 & 7u] | 1u))) && (unsigned)l0) || r0.x);
                    if (budget != 0u) { budget -= 1u; u2 = fn0(a0[u1 & 3u], (garr[i1 & 7u] * 0x10000u), ((unsigned)(x0 >> 70) + (unsigned)((int)*mp < (int)8u))); }
                    i0 = 0x6c6f6741u & 15u;
                    if ((unsigned)d0) goto L3;
                    case 3u: ;
                }
            }
            a0[p2 & 3u] = ~(unsigned)((0x10000u % ((r0.x * garr[i1 & 7u]) | 1u)) || (unsigned)(w0 >> 29));
        }
        if ((m0 % (4u | 1u))) {
            for (;;) { if (--fuel == 0u) goto done;
                u2 = u2 * 0x9e3779b1u + (garr[i1 & 7u] << (g0 & 31u));
                if ((p2 + p1)) break;
                case 4u: ;
                if (budget != 0u) { budget -= 1u; u2 = fn2(0x9fd89251u, (r0.y | (unsigned)b0), (i0 | i2)); }
                r0.y ^= (unsigned)((int)u2 < (int)(unsigned)(p2 || p0));
                if (budget != 0u) { budget -= 1u; u2 = fn2((*q0 >> (garr[i1 & 7u] & 31u)), ~((a0[i0 & 3u] % ((unsigned)d0 | 1u)) << (0x80000000u & 31u)), (unsigned)((2u << ((unsigned)l0 & 31u)) && (unsigned)c1)); }
            }
            if (~((r0.y - u1) ^ p0)) {
                s0 = (int)(unsigned)(((unsigned)b0 + 9u) || ((unsigned)c1 + (unsigned)d0));
                if (budget != 0u) { budget -= 1u; u1 = fn3(((u1 | *mp) | u2), (unsigned)c0, 0x10000u); }
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((int)r0.x < (int)0xbc316c9bu) - 4u), (unsigned)((int)r0.x >= (int)(unsigned)h0), (unsigned)((unsigned)d0 && (fuel & 0x69b2726du))); }
                if ((unsigned)(0x10000u || -(u3 | 0x48b50950u))) {
                    garr[0x41a4ae05u & 7u] = (unsigned)((r0.x + (i0 / (0x80000000u | 1u))) || (r0.y + u1));
                    h1 = (unsigned short)(h1 + (unsigned)((short)0x10000u > (signed char)0u));
                    if ((unsigned)((int)u0 < (int)0x10000u)) break;
                    case 1u: ;
                    u0 += u1;
                    goto done;
                } else {
                    m0 ^= (unsigned)((unsigned)((unsigned)b0 || 0xb1c83dfau) < fuel);
                    i0 = (p2 / (6u | 1u)) & 15u;
                    r0.y ^= (unsigned)((int)i2 < (int)*q0);
                    switch ((unsigned)w0 & 7u) {
                        case 0u: ;
                    }
                }
                switch (m0 & 7u) {
                    m0 ^= ((unsigned)((unsigned)x0 < (unsigned)w0) & (u0 % (u2 | 1u)));
                    c0 = (unsigned char)(((unsigned)c1 >> ((unsigned)e0 & 31u)) << ((0x1c137dddu ? (unsigned)d0 : 0x988d20b2u) & 31u));
                    f0 = f0 * 0.5f + (float)((unsigned)((int)0xf236d0e8u >= (int)a0[u1 & 3u]) & 255u);
                }
                goto L1;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn2((a0[i0 & 3u] ^ (g0 | i2)), 0x61dc96e2u, (unsigned)((a0[i0 & 3u] >> (g1 & 31u)) < (unsigned)c0)); }
        }
        do { if (--fuel == 0u) goto done;
            break; (void)((unsigned)s0);
            l0 = (long)((unsigned long)l0 + (((unsigned)e0 % ((unsigned)e0 | 1u)) & (fuel ^ 0xa37ccc4u)));
            a0[garr[i1 & 7u] & 3u] = (9u >> ((0xc1bb2503u & m0) & 31u));
        } while (i0++ < 3u && 9u);
        case 2u: ;
        a0[g0 & 3u] = 3u;
        if (budget != 0u) { budget -= 1u; u2 = fn3((garr[i1 & 7u] << ((unsigned)d0 & 31u)), 4u, (unsigned)(i0 || 3u)); }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)!(*mp ^ (unsigned)s1), (0x7fffffffu & u2), (unsigned)((int)(unsigned)e0 < (int)0x8c0edc84u)); }
    u2 = m0;
    *q0 += (unsigned)f0;
    if (budget != 0u) { budget -= 1u; u2 = fn3(8u, g0, 0x8e3502d9u); }
    if (budget != 0u) { budget -= 1u; u2 = fn2((5u * ~(garr[u2 & 7u] % (*q0 | 1u))), (p1 & ((unsigned)(x0 >> 70) - *q0)), ((unsigned)((short)m0 > (signed char)r0.x) + 0x60d01a55u)); }
    goto L0;
    goto L3;
    if (u3 == 7u) return m0;
    if (0xffffffffu) goto L1;
    u3 = u3 * 0x9e3779b1u + (unsigned)(u3 || (unsigned)((int)0x80000000u >= (int)(unsigned)(unsigned char)(4u % (0x8ccfe7cfu | 1u))));
    if (((unsigned)(0xffffffffu && 0xffffffffu) & u3)) {
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (fuel < 8u) return ((unsigned)(m0 == u0) << ((unsigned)d0 & 31u));
            u2 = u2 * 0x9e3779b1u + i0;
        }
        if (v0) goto L3;
        do { if (--fuel == 0u) goto done;
            if ((0xcea2b39au % (((unsigned)s1 * v0) | 1u))) break;
            if (g1) break;
            if (a0[i0 & 3u]) break;
            if ((0x8345066fu / (g1 | 1u))) break;
        } while (i0++ < 3u && (u3 * (u1 ^ 0x28450c99u)));
        r0.x = (m0 >> (garr[u2 & 7u] & 31u));
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)s1 % (r0.x | 1u)));
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)h1 ? (unsigned)d0 : garr[u2 & 7u]), 0x720a06a0u, 7u); }
        if (g1) {
            w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)((unsigned)(signed char)(0x10000u - 0x8637f490u) / ((unsigned)((int)0xd9fe4a7u >= (int)(unsigned)(v0 && 0x89839a99u)) | 1u));
            { unsigned t7; double z7; if ((9u) & 1u) { t7 = p0; z7 = (double)((((p2 >> (0x10000u & 31u)) & (unsigned)c0)) & 255u); } if ((9u) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                c1 = (signed char)((unsigned)(w0 >> 29) % ((unsigned)!(r0.y ? a0[i0 & 3u] : 0xf6c73045u) | 1u));
                if ((unsigned)d0) break;
            }
            garr[(unsigned)(r0.x < 1u) & 7u] = 0x898da5b0u;
            if ((0x80000000u >> (0x10000u & 31u))) break;
            u3 = garr[i1 & 7u];
            if ((unsigned)!(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)-(0x10000u ^ garr[i1 & 7u]))) break;
        } else {
            if (fuel) break;
        }
        if ((((unsigned)b0 % (7u | 1u)) >> (7u & 31u))) {
            d0 = d0 * 0.5 + (double)((unsigned)(signed char)((unsigned)(a0[u1 & 3u] || 5u) << ((unsigned)((int)7u < (int)(unsigned)((short)m0 > (signed char)*mp)) & 31u)) & 1023u);
            if (budget != 0u) { budget -= 1u; u3 = fn0((u0 + u1), (unsigned)((unsigned)(0x794efec5u == p2) < 0x5ff66a98u), (unsigned)(w0 >> 29)); }
            goto L3;
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)w0 < (unsigned)e0)) break;
                q0 = &garr[(unsigned)(signed char)(unsigned)((int)(0xffffffffu << (r0.y & 31u)) < (int)(unsigned)((unsigned)h0 == ((unsigned)h1 + 1u))) & 7u];
                q0 = &garr[fuel & 7u];
            }
            c0 = (unsigned char)((0xffffffffu / (fuel | 1u)) ^ (unsigned)s1);
            if (((garr[i1 & 7u] % (u1 | 1u)) | *mp)) {
                if ((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)(p0 || 7u))) break;
                e0 = e0 * 0.5L + (long double)(((fuel >> (*mp & 31u)) << ((unsigned)w0 & 31u)) & 1023u);
                { unsigned t8; double z8; if (((((unsigned)h1 / ((unsigned)b0 | 1u)) + 5u)) & 1u) { t8 = v0; z8 = (double)((i2) & 255u); } if (((((unsigned)h1 / ((unsigned)b0 | 1u)) + 5u)) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                    break; (void)(8u);
                    if ((unsigned)((unsigned)x0 < g0)) break;
                    v0 = (unsigned)((unsigned)(w0 >> 29) < ~(unsigned)(8u < 0xe2362860u));
                }
                if ((unsigned)(short)(unsigned)((0x7fffffffu * fuel) && u1)) {
                    if (fuel < 8u) return (unsigned)((unsigned)(w0 >> 29) < ~((unsigned)f0 >> (r0.x & 31u)));
                    if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)((int)(unsigned)d0 >= (int)i1) << (u0 & 31u)), (v0 - (unsigned)(unsigned char)(r0.y | p1)), (unsigned)d0); }
                    if ((0xffffffffu / ((unsigned)((unsigned)(x0 >> 70) == 3u) | 1u))) break;
                } else {
                    if (budget != 0u) { budget -= 1u; u1 = fn2(7u, ((unsigned)(w0 >> 29) ^ (unsigned)(a0[u1 & 3u] && 1u)), u2); }
                    continue; (void)((unsigned)((short)(4u | fuel) > (signed char)v0));
                }
            }
        }
        if ((0x61836db1u + (unsigned)l0)) break;
    }
    e0 = e0 * 0.5L + (long double)(u0 & 1023u);
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            i2 = (0x68ea8b87u + (u0 / (((0xffffffffu + 7u) % (g0 | 1u)) | 1u))) & 15u;
        }
    } while (i0++ < 6u && (~(9u | 5u) >> ((unsigned)c1 & 31u)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 6u, 0x1eb4dc17u, 0x3f1d58f4u },
        { 11u, 0xb1726270u, 0xe3de3826u },
        { 8u, 0xbcecb125u, 0xe17f1802u },
        { 0u, 0xf4fa704cu, 0x62fd5d40u },
        { 6u, 0x4a64913du, 0xde03972eu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
