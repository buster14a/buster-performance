// test-ssa-source's program of seed 141000432 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x11a7dc00u, g1 = 0x9b3b69cfu;
static unsigned garr[8] = { 0x2029297eu, 0x697cfaeau, 0x671d09e3u, 0x2299599au, 0xc776787du, 0x70106796u, 0x1ed734d0u, 0xd01bf969u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= 0xffffffffu;
        m0 ^= 0xe509f805u;
        { unsigned t0; double z0; if ((((unsigned)l0 * 0x173602d7u)) & 1u) { t0 = a0[i0 & 3u]; z0 = (double)(((unsigned)(0x31aa8b44u < 9u)) & 255u); } if ((((unsigned)l0 * 0x173602d7u)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            h1 = (unsigned short)(h1 + (unsigned)(8u == (unsigned)((unsigned)((short)0x2854482u > (signed char)0x3babc67du) == a0[u1 & 3u])));
        }
    }
    if ((unsigned)((int)(unsigned)e0 >= (int)0x80000000u)) {
        g0 = 9u;
        if ((unsigned)(*q0 == (unsigned)(short)(unsigned)((int)0x8ad23b86u < (int)(unsigned)c0))) goto L2;
        l0 = (long)((unsigned long)l0 + (unsigned)(m0 < (5u | (garr[u2 & 7u] + *mp))));
        g0 = (unsigned)(((unsigned)h0 | 0xc0703493u) && 0xffffffffu);
        L0: if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            switch ((unsigned)((unsigned)c0 == (unsigned)(g0 == v0)) & 7u) {
                c1 = (signed char)(unsigned)(((unsigned)(u1 || (9u >> (6u & 31u))) % (6u | 1u)) && 4u);
                case 1u: ;
                default: ;
                break;
                L1: if (--fuel == 0u) goto done;
            }
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                while (i2++ < 2u && (unsigned)e0) { if (--fuel == 0u) goto done;
                    u1 ^= (unsigned)w0;
                    u1 += ((unsigned)((int)p1 < (int)i2) ^ v0);
                    L2: if (--fuel == 0u) goto done;
                    if (~(unsigned)((int)(unsigned)((short)v0 > (signed char)i1) >= (int)8u)) goto L0;
                    l0 = (long)((unsigned long)l0 + (u0 * -(*q0 / (((unsigned)(0x7fffffffu && (unsigned)w0) % (p1 | 1u)) | 1u))));
                }
            }
            if (-(5u / ((unsigned)c1 | 1u))) {
                i1 = ~(unsigned)(a0[i0 & 3u] || ((unsigned)l0 - i2)) & 15u;
                l0 = (long)((unsigned long)l0 + ((unsigned)((int)0xba71402fu >= (int)(unsigned)((unsigned)s0 && ((unsigned)w0 % (i2 | 1u)))) / (i0 | 1u)));
                q0 = &garr[(unsigned)((unsigned)d0 || (0x7fffffffu / ((unsigned)f0 | 1u))) & 7u];
                if (r0.y) break;
                L3: if (--fuel == 0u) goto done;
                goto L0;
            } else {
                h0 = (short)((i0 / ((unsigned)(u0 < r0.x) | 1u)) / ((unsigned)(signed char)((unsigned)h1 - g0) | 1u));
                L4: if (--fuel == 0u) goto done;
            }
            break; (void)((unsigned)(a0[u1 & 3u] < 3u));
            if ((unsigned)((short)(unsigned)(*mp == g0) > (signed char)i1)) break;
            goto L4;
        } while (i0++ < 3u && (unsigned)(0x941ed36u && 0xffffffffu));
    }
    goto L4;
    if ((u0 & v0)) {
        a0[((unsigned)x0 & 3u) & 3u] = (unsigned)(0x5ff571c9u == v0);
        v0 = ((7u % (0x80000000u | 1u)) ^ 0xdc793be8u);
    } else {
        if (m0) goto L1;
    }
    g1 += (unsigned)(0x10000u || (unsigned)((short)0u > (signed char)0xffffffffu));
    if (*q0) {
        do { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((unsigned)f0 * (unsigned)(garr[u2 & 7u] < garr[i1 & 7u])) & 1023u);
            break; (void)((unsigned)(0x80000000u && (unsigned)((short)a0[i0 & 3u] > (signed char)3u)));
            if (i0) break;
        } while (i0++ < 4u && (i1 | -(unsigned)(u3 || 9u)));
        if ((unsigned)(signed char)((unsigned)(i2 < 0x7fffffffu) * (unsigned)e0)) goto done;
        if (u3 == 7u) return (6u * 6u);
    } else {
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)(v0 == (unsigned)((unsigned)(x0 >> 70) || u3)));
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(0xffffffffu && (unsigned)l0)) break;
                if ((u1 ? 0x80000000u : 0xffffffffu)) break;
            } while (i1++ < 4u && 0x7fffffffu);
            c0 = (unsigned char)((unsigned)(signed char)(unsigned)(p1 == *q0) | (unsigned)((int)3u >= (int)p0));
            if ((*q0 * fuel)) continue;
        }
        while (i0++ < 3u && (unsigned)((short)0xc23d7ae6u > (signed char)i1)) { if (--fuel == 0u) goto done;
            if (0x49bfaff7u) {
                w0 ^= (unsigned long long)(4u - m0) << (((unsigned)x0 - (unsigned)b0) & 63u);
                *q0 += (g0 & 5u);
                u2 = (unsigned)((short)9u > (signed char)((unsigned)(fuel == (unsigned)(short)(unsigned)(0xa95f91d0u == (unsigned)c0)) << ((unsigned)b0 & 31u)));
            } else {
                e0 = e0 * 0.5L + (long double)(((i2 / (0x7fffffffu | 1u)) ^ (unsigned)(short)(a0[i0 & 3u] | *q0)) & 1023u);
                s1 = (int)((unsigned)s1 + m0);
                *q0 += ((garr[i1 & 7u] % (-((unsigned)s1 + (g1 % (0x1bdbede2u | 1u))) | 1u)) + (unsigned)x0);
                i2 = (unsigned)d0 & 15u;
            }
            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(*mp == 0x10000u) || (unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)h0)) & 1023u);
            if ((unsigned)(r0.x == (g1 >> ((unsigned)h1 & 31u)))) goto L4;
        }
        m0 ^= (unsigned)((int)(unsigned)s1 >= (int)i0);
    }
    q0 = &garr[(unsigned)((short)0x80000000u > (signed char)(unsigned)(0xe9a8b46cu == (unsigned)(0x80000000u || *mp))) & 7u];
    s1 = (int)((unsigned)s1 + (unsigned)d0);
    while (i0++ < 2u && 0xf3426588u) { if (--fuel == 0u) goto done;
        if ((unsigned)(p0 < (unsigned)w0)) break;
        break; (void)((unsigned)((int)0xffffffffu >= (int)a0[i0 & 3u]));
        h0 = (short)(unsigned)l0;
        if (0u) break;
    }
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)u0;
            while (i2++ < 2u && ~((unsigned)(0xda70ded9u || (unsigned)d0) >> (m0 & 31u))) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)g1 > (signed char)0x1e507768u)) break;
                s0 = (int)((0x63d0089cu % (0xffffffffu | 1u)) ^ ((unsigned)(w0 >> 29) >> (a0[u1 & 3u] & 31u)));
                if (((u1 / (1u | 1u)) ^ m0)) break;
            }
            switch (((u3 + 0xe60caa13u) & 0x10000u) & 7u) {
                case 1u: ;
                do { if (--fuel == 0u) goto done;
                    case 5u: ;
                } while (i2++ < 5u && (unsigned)((unsigned)h1 && r0.x));
            }
        }
        *mp = (((unsigned)c1 << ((unsigned)((int)9u >= (int)(unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)x0)) & 31u)) ^ 0x57a6b519u);
    }
    do { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((unsigned)(r0.y || 0x62fe0289u) & 1023u);
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((0x6ec52febu * ~(unsigned)((int)a0[u1 & 3u] < (int)g0)));
            r0.x = (0x635c9455u << (-((unsigned)d0 % ((unsigned)c1 | 1u)) & 31u));
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(fuel < (unsigned)(0x5af5f724u == (unsigned)s0))) break;
                f0 = f0 * 0.5f + (float)((unsigned)((int)(u3 | 0x80000000u) >= (int)(unsigned)((short)r0.x > (signed char)0xf3fcab0cu)) & 255u);
                if ((unsigned)((short)v0 > (signed char)a0[i0 & 3u])) goto L3;
                if ((unsigned)!((unsigned)(0x10000u && (unsigned)(w0 >> 29)) * r0.y)) break;
                if (((g0 | i1) / (p1 | 1u))) break;
            } while (i2++ < 5u && fuel);
            u3 += (unsigned)((int)0xf8a467f9u < (int)2u);
            break; (void)(0xffffffffu);
            if (((m0 % ((unsigned)c1 | 1u)) * 0x8db7377u)) break;
        }
        if (((unsigned)((int)u3 < (int)v0) & g1)) break;
        *q0 += ((6u << ((unsigned)(unsigned char)(unsigned)((int)0xffffffffu < (int)(unsigned)c0) & 31u)) & (g0 * (unsigned)s1));
        e0 = e0 * 0.5L + (long double)((p2 / (a0[u1 & 3u] | 1u)) & 1023u);
        if (((0x2771e216u | 0x1587ee62u) ^ (unsigned)(x0 >> 70))) break;
    } while (i0++ < 2u && (unsigned)b0);
    while (i0++ < 2u && g1) { if (--fuel == 0u) goto done;
        v0 = (r0.x % ((unsigned)c0 | 1u));
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            i0 = (unsigned)!(3u ^ 0x80000000u) & 15u;
            break; (void)(((unsigned)l0 % ((unsigned)h1 | 1u)));
            u3 += -(unsigned)((int)fuel >= (int)(((unsigned)c0 + (unsigned)c1) & 0x7fffffffu));
            d0 = d0 * 0.5 + (double)(0x7fffffffu & 1023u);
        }
        switch ((unsigned)h0 & 7u) {
            case 0u: ;
            { unsigned t1; double z1; if (((p0 * ((unsigned)h1 >> (*q0 & 31u)))) & 1u) { t1 = (4u - a0[u1 & 3u]); z1 = (double)((p1) & 255u); } if (((p0 * ((unsigned)h1 >> (*q0 & 31u)))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                case 3u: ;
                r0.y ^= 0xe2270641u;
            }
        }
        if ((0x815ba23au - (i2 - 4u))) goto done;
        { unsigned t2; double z2; if ((~(unsigned)((short)(unsigned)c0 > (signed char)-(fuel - m0))) & 1u) { t2 = (unsigned)((unsigned)d0 && (unsigned)c1); z2 = (double)((u3) & 255u); } if ((~(unsigned)((short)(unsigned)c0 > (signed char)-(fuel - m0))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            if (u1) break;
            if ((unsigned)(unsigned char)(((unsigned)f0 | 2u) * (unsigned)x0)) break;
            { unsigned t3; double z3; if (((unsigned)(p0 < ((unsigned)l0 & u3))) & 1u) { t3 = (u2 + 0x80000000u); z3 = (double)((v0) & 255u); } if (((unsigned)(p0 < ((unsigned)l0 & u3))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                break; (void)((0u + p2));
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(garr[i1 & 7u] / ((unsigned)(x0 >> 70) | 1u)) < (int)*q0);
                break; (void)(((unsigned)(x0 >> 70) * 4u));
                break; (void)((i2 >> ((unsigned)(v0 && p0) & 31u)));
                if ((unsigned)((p2 % (0x80000000u | 1u)) && m0)) break;
                if (i1) {
                    break; (void)((unsigned)((int)0xa1f46f7u < (int)(unsigned)(unsigned char)(unsigned)((unsigned)x0 < 0x941d2ed3u)));
                    if (-(unsigned)(*q0 == (p2 * 7u))) break;
                    x0 = x0 * 0x100000001b3ull + garr[i1 & 7u];
                }
            }
            if ((unsigned)((short)(0x10000u / (*mp | 1u)) > (signed char)4u)) break;
            if ((u0 % (fuel | 1u))) break;
        }
        d0 = d0 * 0.5 + (double)((0xffffffffu | 0x2f1b3f4u) & 1023u);
    }
    r0.x = 0x7fffffffu;
    e0 = e0 * 0.5L + (long double)((unsigned)(x0 >> 70) & 1023u);
    goto L0;
    goto L1;
    w0 = w0 * 6364136223846793005ull + (0xffffffffu * u3);
    if ((unsigned)(0u && u1)) {
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((int)u1 < (int)u0) < 0xffffffffu) & 255u);
        if (((unsigned)l0 / ((garr[u2 & 7u] % (a0[u1 & 3u] | 1u)) | 1u))) goto L1;
        if (i0) goto done;
        v0 = 0x10000u;
        r0.x = ((unsigned)d0 ^ garr[i1 & 7u]);
        if ((unsigned)((int)(unsigned)(w0 >> 29) < (int)0u)) {
            if (0u) goto L0;
            if (*q0) goto L0;
        }
    } else {
        g1 += ((unsigned)e0 * (unsigned)h0);
        f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)c1 < (int)6u) & 255u);
        u0 ^= (unsigned)((short)(6u ? 0xf8ca4a32u : fuel) > (signed char)(unsigned)((short)(unsigned)e0 > (signed char)0xd6de1478u));
        if (g0) goto done;
    }
    *mp = (unsigned)((int)(unsigned)c0 >= (int)(((unsigned)w0 << (*q0 & 31u)) % ((unsigned)(w0 >> 29) | 1u)));
    c1 = (signed char)0x7fffffffu;
    if ((unsigned)!(unsigned)(0x80000000u || (0xc0ce9753u ^ i2))) goto L3;
    if ((i1 << ((unsigned)(w0 >> 29) & 31u))) goto L3;
    e0 = e0 * 0.5L + (long double)((r0.y * (v0 | (5u ^ m0))) & 1023u);
    { unsigned t4; double z4; if (((unsigned)d0) & 1u) { t4 = (0x19f5f77du + 0x10000u); z4 = (double)(((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)d0)) & 255u); } if (((unsigned)d0) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        if ((unsigned)((unsigned)c0 == 0x7fffffffu)) goto done;
    }
    switch ((unsigned)(unsigned char)(unsigned)((int)(unsigned)c1 < (int)(fuel ^ (unsigned)w0)) & 7u) {
        if (((unsigned)h1 ^ fuel)) {
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                case 0u: ;
                i0 = i2 & 15u;
                if ((g1 | ((unsigned)w0 % (0x80000000u | 1u)))) {
                    g1 += (unsigned)(unsigned char)(0x10000u * (unsigned)(u1 < (g0 ^ p2)));
                } else {
                    i0 = (0x80000000u + 0x8fb2f579u) & 15u;
                    break; (void)((0x7fffffffu * (unsigned)f0));
                    e0 = e0 * 0.5L + (long double)((i0 << ((unsigned)((unsigned)c1 == (unsigned)w0) & 31u)) & 1023u);
                    x0 = x0 * 0x100000001b3ull + (unsigned)((short)(g1 << (0x10000u & 31u)) > (signed char)*mp);
                }
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    for (;;) { if (--fuel == 0u) goto done;
                        garr[(5u >> ((unsigned)x0 & 31u)) & 7u] = (-(5u * 0x8114442cu) | (unsigned)((i1 ^ g1) || (unsigned)c0));
                        u1 = i2;
                    }
                    s0 = (int)(unsigned)(0xffffffffu < i0);
                    goto L3;
                    s1 = (int)((unsigned)s1 + (unsigned)((short)0xa2588d74u > (signed char)(unsigned)((int)9u < (int)(9u - (fuel | (unsigned)f0)))));
                }
                case 6u: ;
            }
            goto L0;
            s0 = (int)(unsigned)((0xe8ae777fu ^ 0xffffffffu) && g1);
        }
        default: ;
        break;
        f0 = f0 * 0.5f + (float)((unsigned)(short)(unsigned)((short)0x10000u > (signed char)(unsigned)!((unsigned)((unsigned)h1 || r0.x) & 0x10000u)) & 255u);
    }
    h1 = (unsigned short)(h1 + (unsigned)((unsigned)l0 && ((unsigned)(a0[i0 & 3u] < a0[i0 & 3u]) ? 0xffffffffu : r0.y)));
    x0 = x0 * 0x100000001b3ull + (unsigned)(short)(unsigned)(((unsigned)(p1 < (unsigned)x0) | i2) || u2);
    goto L4;
    if (0x10000u) {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)(((unsigned)(u2 || -(unsigned)((short)0xf7a9df4cu > (signed char)0x3d82c310u)) << ((unsigned)l0 & 31u)) & 255u);
                c1 = (signed char)(0x2166ae59u ? u3 : p1);
                h0 = (short)(m0 ? 0x10000u : (unsigned)h0);
                if (fuel) break;
            } while (i1++ < 6u && ((unsigned)x0 + (r0.x / (0x80000000u | 1u))));
            if ((0x88717f3fu & (unsigned)((unsigned)c0 == 0xaf3365d2u))) {
                if (((unsigned)((int)*mp < (int)u2) * 0xff886d6du)) goto L2;
                { unsigned t5; double z5; if ((7u) & 1u) { t5 = ((0x57ffa05fu >> (fuel & 31u)) << (0u & 31u)); z5 = (double)(((unsigned)((unsigned)(x0 >> 70) == (fuel + 0xffffffffu))) & 255u); } if ((7u) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                    if (0xffffffffu) continue;
                    break; (void)((unsigned)(unsigned char)(g0 % ((unsigned)w0 | 1u)));
                    if (1u) break;
                    if (p0) break;
                }
                if ((unsigned)((int)i1 < (int)(unsigned)w0)) goto L3;
                if ((unsigned)h0) break;
                d0 = d0 * 0.5 + (double)((unsigned)(*q0 || (unsigned)c0) & 1023u);
                w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)!(unsigned)(g0 && m0) > (signed char)0x45844d4fu);
            }
            if ((unsigned)(4u == 4u)) {
                if (((unsigned)((int)a0[i0 & 3u] < (int)3u) & 0x75f58903u)) break;
                *q0 = ((0x10000u >> ((garr[u2 & 7u] + p1) & 31u)) ^ 0x10000u);
                goto L2;
                if ((unsigned)(((unsigned)d0 % (0x80000000u | 1u)) < 0xc5aeecd1u)) break;
                break; (void)((p1 - (unsigned)(i2 < 2u)));
            } else {
                if (0xab0be6feu) break;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    g0 = (unsigned)s0;
                    if (p2) break;
                }
                while (i1++ < 6u && (unsigned)(i2 && ((unsigned)h0 | u1))) { if (--fuel == 0u) goto done;
                    if ((m0 * 0x7fffffffu)) continue;
                    x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)((0x10000u / ((i0 / (u1 | 1u)) | 1u)) % ((9u * m0) | 1u));
                    u3 = u3 * 0x9e3779b1u + (unsigned)((int)0xb088b626u >= (int)r0.x);
                }
                u1 += ((unsigned)(w0 >> 29) / (g1 | 1u));
            }
            if ((u1 * fuel)) break;
            e0 = e0 * 0.5L + (long double)((unsigned)(a0[i0 & 3u] || (p1 % ((unsigned)x0 | 1u))) & 1023u);
            switch (-(unsigned)(v0 && r0.y) & 7u) {
                if ((unsigned)((int)0x33393514u < (int)u0)) {
                    case 2u: ;
                    f0 = f0 * 0.5f + (float)((0xffffffffu + (i1 / (g1 | 1u))) & 255u);
                } else {
                    if (g1) {
                        case 7u: ;
                        m0 ^= (5u | (v0 - p1));
                        if (0xffffffffu) goto L1;
                        case 0u: ;
                        if ((unsigned)w0) goto L0;
                        x0 = x0 * 0x100000001b3ull + ((unsigned)x0 << ((unsigned)((unsigned)(short)(g0 | i0) || m0) & 31u));
                    }
                }
            }
        }
    } else {
        u0 = (unsigned)(unsigned char)(unsigned)((int)(0x92eb239cu | 0x8c09bad9u) < (int)(0x7fffffffu - (unsigned)(x0 >> 70)));
        s0 = (int)(unsigned)b0;
    }
    if ((unsigned)c1) goto L2;
    if (((unsigned)(0x6faa556eu && (unsigned)s0) ^ *q0)) goto L3;
    if ((unsigned)(0xffffffffu && (0x10000u + (unsigned)f0))) goto L1;
    for (;;) { if (--fuel == 0u) goto done;
        if (r0.y) goto L4;
        if (0x80000000u) break;
        w0 = w0 * 6364136223846793005ull + g0;
    }
    u1 = (p2 * i0);
    h1 = (unsigned short)(h1 + (u3 / ((((unsigned)(garr[u2 & 7u] < i2) & 0xffffffffu) ^ (unsigned)c1) | 1u)));
    if ((0xffffffffu % (*mp | 1u))) {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((short)-((unsigned)l0 >> (i0 & 31u)) > (signed char)a0[u1 & 3u]));
            switch (g0 & 7u) {
                u0 = u0 * 0x9e3779b1u + ((unsigned)b0 / (0x1a28e166u | 1u));
                r0.x = 3u;
                while (i1++ < 4u && -(unsigned)((int)(p2 >> ((unsigned)(w0 >> 29) & 31u)) < (int)u2)) { if (--fuel == 0u) goto done;
                    garr[p2 & 7u] = (((unsigned)((int)(*q0 * a0[u1 & 3u]) < (int)0xffffffffu) | u3) * 0x80000000u);
                    b0 = (unsigned)((short)0x6fc73b61u > (signed char)(0u / ((unsigned)!(unsigned)((int)(unsigned)e0 >= (int)6u) | 1u))) != 0u;
                    s0 = (int)(unsigned)(1u == *q0);
                    case 1u: ;
                }
                x0 = x0 * 0x100000001b3ull + -(unsigned)((unsigned)!(unsigned)(u3 || (0x10000u >> ((unsigned)((short)3u > (signed char)garr[i1 & 7u]) & 31u))) || p1);
            }
            g0 = (unsigned)((int)*mp >= (int)(unsigned)((int)(u0 ^ 0xa0f4da4du) >= (int)(0x7fffffffu + i1)));
            *mp = (1u ? (i2 << (g1 & 31u)) : garr[i1 & 7u]);
            if (i2) break;
        }
        goto L3;
    } else {
        if ((unsigned)((g1 / (3u | 1u)) < u1)) goto L0;
    }
    { unsigned t6; double z6; if ((((unsigned)c1 << ((unsigned)!(unsigned)(r0.x == (unsigned)l0) & 31u))) & 1u) { t6 = a0[i0 & 3u]; z6 = (double)(((p0 | *q0)) & 255u); } if ((((unsigned)c1 << ((unsigned)!(unsigned)(r0.x == (unsigned)l0) & 31u))) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        f0 = f0 * 0.5f + (float)((unsigned)(r0.y || (0x6b32f50fu / (r0.y | 1u))) & 255u);
    }
    if (((7u << (*q0 & 31u)) << (u0 & 31u))) goto done;
    q0 = &garr[((unsigned)((short)(unsigned)c0 > (signed char)m0) ^ (unsigned)c0) & 7u];
    { unsigned t7; double z7; if (((p2 % (0x80000000u | 1u))) & 1u) { t7 = (((unsigned)b0 >> (0x7834064u & 31u)) << (u3 & 31u)); z7 = (double)((garr[i1 & 7u]) & 255u); } if (((p2 % (0x80000000u | 1u))) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
        while (i0++ < 3u && *q0) { if (--fuel == 0u) goto done;
            { unsigned t8; double z8; if (((r0.y & m0)) & 1u) { t8 = (unsigned)f0; z8 = (double)(((unsigned)(-(unsigned)((short)u1 > (signed char)m0) == i0)) & 255u); } if (((r0.y & m0)) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                if ((unsigned)((unsigned)((short)(unsigned)l0 > (signed char)0x48bc8e3du) && r0.y)) break;
                { unsigned t9; double z9; if (((0x10000u % ((unsigned)((short)0x80000000u > (signed char)r0.x) | 1u))) & 1u) { t9 = (~(0u | 0x7fffffffu) ^ i2); z9 = (double)(((unsigned)l0) & 255u); } if (((0x10000u % ((unsigned)((short)0x80000000u > (signed char)r0.x) | 1u))) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                    break; (void)(((unsigned)f0 & (unsigned)b0));
                    if (u3) break;
                    u3 += (unsigned)(((0x10000u - 0xbeb455acu) ^ (unsigned)h1) < (0x10000u % (u3 | 1u)));
                }
                if ((i0 + v0)) {
                    *q0 = (p2 >> ((unsigned)((short)0x10000u > (signed char)(unsigned)((unsigned)((int)i0 < (int)u2) < *q0)) & 31u));
                    while (((i2 >> ((unsigned)f0 & 31u)) | 0xfb2fc590u)) { if (--fuel == 0u) goto done;
                        if ((7u | (unsigned)(p2 == v0))) continue;
                        u0 ^= i1;
                        s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)c1 >= (int)(unsigned)h0));
                        break; (void)((i0 + p2));
                    }
                    for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        r0.x = ((u0 & (p2 ^ (unsigned)(w0 >> 29))) << ((unsigned)((int)(unsigned)e0 >= (int)r0.y) & 31u));
                        w0 = w0 * 6364136223846793005ull + ((unsigned)(x0 >> 70) - (unsigned)d0);
                        if (garr[i1 & 7u]) break;
                        m0 ^= (p2 | (unsigned)(w0 >> 29));
                        break; (void)((0x7fffffffu * (unsigned)((int)0x201f0dbcu < (int)*q0)));
                    }
                    if ((0x4217c08cu ^ (unsigned)f0)) break;
                } else {
                    u1 = (unsigned)((short)1u > (signed char)0x80000000u);
                }
                garr[(unsigned)l0 & 7u] = ((garr[i1 & 7u] ? (0x10000u * a0[i0 & 3u]) : i0) % (9u | 1u));
                a0[p0 & 3u] = (0x2bd25599u << (*q0 & 31u));
                if ((g1 * (unsigned)c1)) break;
            }
            if (0u) break;
            while (((unsigned)((short)0x80000000u > (signed char)0x7fffffffu) << (a0[u1 & 3u] & 31u))) { if (--fuel == 0u) goto done;
                if (a0[i0 & 3u]) break;
            }
            b0 = ((unsigned)((int)(unsigned)c0 < (int)u3) << (a0[u1 & 3u] & 31u)) != 0u;
            break; (void)(-(garr[i1 & 7u] | 0x10000u));
        }
        if ((unsigned)(signed char)(u2 & 0x418ccac9u)) goto L1;
        do { if (--fuel == 0u) goto done;
            *q0 += ((unsigned)((int)0x80000000u >= (int)(unsigned)((0x7fffffffu << (*mp & 31u)) || 6u)) + u0);
            if ((unsigned)c1) goto L2;
            i1 = g0 & 15u;
            if (((unsigned)(0x7fffffffu || (unsigned)e0) | garr[u2 & 7u])) break;
            do { if (--fuel == 0u) goto done;
                { unsigned t10; double z10; if (((unsigned)((short)3u > (signed char)garr[i1 & 7u])) & 1u) { t10 = (*q0 ^ garr[i1 & 7u]); z10 = (double)(((unsigned)((int)(unsigned)(r0.y && u1) < (int)i0)) & 255u); } if (((unsigned)((short)3u > (signed char)garr[i1 & 7u])) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
                    b0 = ((garr[u2 & 7u] << ((unsigned)s1 & 31u)) * garr[u2 & 7u]) != 0u;
                }
                if (((unsigned)d0 ? 0x7fffffffu : m0)) break;
                do { if (--fuel == 0u) goto done;
                    h0 = (short)(unsigned)!(unsigned)(0x80000000u || ((unsigned)(short)(unsigned)((int)0xbfe42531u < (int)((unsigned)(x0 >> 70) ^ 0x10000u)) & a0[i0 & 3u]));
                    if ((((unsigned)e0 + 0u) / ((unsigned)d0 | 1u))) break;
                    q0 = &garr[(((v0 + 5u) * (unsigned)s1) + (*mp - (unsigned)x0)) & 7u];
                    if ((g1 + (g0 >> (0x7fffffffu & 31u)))) break;
                    q0 = &garr[(((unsigned)d0 - (unsigned)!((unsigned)c1 << (4u & 31u))) / (u2 | 1u)) & 7u];
                } while (i2++ < 4u && garr[i1 & 7u]);
                u2 = u0;
                if ((unsigned)w0) {
                    if (fuel < 8u) return ((unsigned)(unsigned char)((unsigned)((int)(unsigned)x0 >= (int)(unsigned)(x0 >> 70)) + (unsigned)h1) & garr[u2 & 7u]);
                    break; (void)(5u);
                }
                if (r0.x) {
                    r0.x = ((unsigned)((int)garr[u2 & 7u] < (int)(0x80000000u & g0)) + 0x80000000u);
                }
            } while (i1++ < 6u && (a0[i0 & 3u] & p2));
        } while (i0++ < 4u && ((unsigned)((int)0x7fffffffu < (int)r0.y) & u1));
        if ((0x48d41639u / (0x10000u | 1u))) goto L1;
    }
    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(u0 % (0xda6de2cu | 1u)) & 1023u);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        v0 = (unsigned)((g1 % (m0 | 1u)) == p2);
        break; (void)((unsigned)c1);
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(0x9784bf9du < (unsigned)(p1 == 0x64bf7690u))) break;
            if (0x883f7cd9u) {
                if ((8u & (unsigned)s0)) break;
                if ((0x10000u / (u0 | 1u))) break;
                if ((unsigned)((int)((unsigned)c1 << ((unsigned)h0 & 31u)) >= (int)(unsigned)(x0 >> 70))) {
                    if ((fuel >> (0xa268df4du & 31u))) goto done;
                    if (0x10000u) break;
                    a0[(*mp << ((unsigned)x0 & 31u)) & 3u] = ~(unsigned)(i2 || (unsigned)f0);
                    break; (void)((unsigned)((unsigned)x0 || i0));
                    *q0 = ((unsigned)(x0 >> 70) % ((unsigned)(signed char)(0x7fffffffu / (0x7fffffffu | 1u)) | 1u));
                    if ((0x7fffffffu << ((unsigned)((int)(unsigned)s0 < (int)g1) & 31u))) break;
                } else {
                    while (8u) { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)r0.x << (((unsigned)!(unsigned)((unsigned)(short)(i0 ^ fuel) || p1) ^ (m0 / ((unsigned)(x0 >> 70) | 1u))) & 63u);
                        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                            *q0 += ((0xffffffffu / (2u | 1u)) | (0x43ac3978u / ((unsigned)((int)i2 >= (int)2u) | 1u)));
                            h0 = (short)u1;
                            break; (void)(~(unsigned)((int)r0.y < (int)((unsigned)s0 * 0xf7faed15u)));
                            if (p0) break;
                        }
                        if (*q0) break;
                        r0.y ^= ((g1 << (0u & 31u)) ? (0x10000u << (garr[u2 & 7u] & 31u)) : p1);
                        if ((unsigned)b0) break;
                        if ((u0 - (unsigned)((unsigned)(w0 >> 29) < m0))) continue;
                    }
                    if ((unsigned)((unsigned)w0 == (unsigned)((unsigned)d0 && r0.x))) break;
                    { unsigned t11; double z11; if (((unsigned)(short)(unsigned)((short)(0x19d271d7u * r0.x) > (signed char)(unsigned)c0)) & 1u) { t11 = 0x80000000u; z11 = (double)((u2) & 255u); } if (((unsigned)(short)(unsigned)((short)(0x19d271d7u * r0.x) > (signed char)(unsigned)c0)) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
                        *mp = (0xffffffffu / (p1 | 1u));
                        s0 = (int)(unsigned)(((unsigned)w0 << (0x3067062au & 31u)) == (unsigned)(u1 && (0x9b6b5d0bu ^ u0)));
                        u2 = ((unsigned)f0 << (g1 & 31u));
                        for (;;) { if (--fuel == 0u) goto done;
                            if ((unsigned)(i2 || (unsigned)(0x4d2c0b0eu && 6u))) break;
                            break; (void)((unsigned)((int)*q0 < (int)u0));
                        }
                        g1 += (unsigned)((short)((0x10000u >> ((unsigned)((unsigned)b0 || i1) & 31u)) | 0xffffffffu) > (signed char)4u);
                        a0[(unsigned)!(unsigned)((int)0x80000000u >= (int)5u) & 3u] = (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(u1 / (u3 | 1u)));
                    }
                    s0 = (int)((unsigned)w0 | p2);
                }
                *q0 += ((unsigned)f0 * ((unsigned)(6u == *mp) % (((unsigned)c0 * (unsigned)f0) | 1u)));
                h0 = (short)((unsigned)c1 * (unsigned)(v0 || *mp));
                if (((unsigned)s0 | 0xf34ead7eu)) break;
            }
            goto L0;
            while (i2++ < 5u && (unsigned)(short)(unsigned)(garr[i1 & 7u] && (unsigned)!(1u + r0.y))) { if (--fuel == 0u) goto done;
                *q0 += (unsigned)c1;
                if ((unsigned)(0x80000000u && (unsigned)((int)u3 >= (int)0x7fffffffu))) goto L4;
            }
            if ((unsigned)s1) break;
        }
        break; (void)((unsigned)((int)1u < (int)g0));
    }
    { unsigned t12; double z12; if (((g0 | u1)) & 1u) { t12 = (unsigned)c0; z12 = (double)(((unsigned)((int)u2 < (int)0x92a86e92u)) & 255u); } if (((g0 | u1)) & 1u) { u1 += t12; d0 = d0 * 0.5 + z12; }
        c1 = (signed char)(unsigned)(a0[i0 & 3u] || ((unsigned)c0 ^ ((unsigned)(w0 >> 29) << ((a0[i0 & 3u] + r0.y) & 31u))));
        if ((unsigned)((unsigned)h0 < g0)) goto L2;
        goto done;
        goto L0;
    }
    goto L0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (i1) {
        c1 = (signed char)(fuel % (((unsigned)s0 % ((unsigned)x0 | 1u)) | 1u));
        L0: if (--fuel == 0u) goto done;
        g0 = (0x103d0dd8u << (((unsigned)(0x7fffffffu < ((unsigned)d0 * 0x2d8b12ddu)) >> ((unsigned)(w0 >> 29) & 31u)) & 31u));
        if ((unsigned)((short)0xffffffffu > (signed char)0xc62599e0u)) {
            g0 = (8u ? (a0[i0 & 3u] % (0x7fffffffu | 1u)) : (unsigned)f0);
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!(unsigned)(-(unsigned)((short)0x6825ff42u > (signed char)p1) || u0), a0[u1 & 3u], (unsigned)((unsigned)d0 == 0x10000u)); }
            h0 = (short)((*mp & 0u) << (0xffffffffu & 31u));
        }
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)(p0 && (unsigned)w0) + i0)) {
                b0 = (i0 | ~(i0 << ((unsigned)((p1 + r0.x) || i2) & 31u))) != 0u;
                do { if (--fuel == 0u) goto done;
                    r0.x = ((6u / ((unsigned)f0 | 1u)) / (3u | 1u));
                } while (i1++ < 2u && (unsigned)(garr[i1 & 7u] < 3u));
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (4u | (unsigned)f0) != 0u;
                    c0 = (unsigned char)u1;
                }
                while (i1++ < 4u && (unsigned)f0) { if (--fuel == 0u) goto done;
                    if ((unsigned)(unsigned char)(unsigned)((short)u0 > (signed char)(p1 + 2u))) break;
                    if (0xba3e510fu) goto L0;
                    r0.y ^= (unsigned)s0;
                    goto L1;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)((unsigned)s0 < a0[u1 & 3u]) ^ (unsigned)f0), (unsigned)((r0.x << (p0 & 31u)) && p2), (unsigned)((int)9u >= (int)0x82cfaaa8u)); }
            }
            if (garr[i1 & 7u]) break;
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if (((i1 << ((unsigned)d0 & 31u))) & 1u) { t0 = 3u; z0 = (double)((((unsigned)c1 / ((8u << (0xae7c8990u & 31u)) | 1u))) & 255u); } if (((i1 << ((unsigned)d0 & 31u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        *mp = 0x10000u;
                        if ((unsigned)((int)2u < (int)u0)) break;
                        continue; (void)((u3 | (unsigned)l0));
                        if (fuel) break;
                        q0 = &garr[(~(0x80000000u + m0) & (unsigned)!(unsigned)((unsigned)(short)(unsigned)(1u == 9u) == 0xffffffffu)) & 7u];
                        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                            if ((unsigned)h1) break;
                            g0 = (u2 - 0x80000000u);
                            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)9u >= (int)i2), (0x80000000u ^ a0[i0 & 3u]), (9u << (((unsigned)x0 % (*q0 | 1u)) & 31u))); }
                            if (((unsigned)((int)p2 >= (int)5u) / (a0[i0 & 3u] | 1u))) break;
                            if (((4u % (u2 | 1u)) & 0xbe61d15cu)) goto L3;
                            s0 = (int)~(unsigned)((short)0x10000u > (signed char)(unsigned)(signed char)((unsigned)h1 ? 1u : 0x80000000u));
                        }
                    }
                    *q0 = (unsigned)((int)(unsigned)e0 >= (int)(0xc3d2c58cu / (0x7e830613u | 1u)));
                }
            }
            l0 = (long)((unsigned long)l0 + ((i1 | (unsigned)s0) << (0x7fffffffu & 31u)));
            *q0 += (unsigned)e0;
        }
    } else {
        if (u0) goto L0;
    }
    goto L4;
    while (i0++ < 6u && (0x10000u << ((unsigned)(2u || (unsigned)c0) & 31u))) { if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)(unsigned char)(u1 & (unsigned)((unsigned)c0 && u1))) break;
            *q0 += (0x1be6b1deu & (~(g0 + (unsigned)(a0[u1 & 3u] == 0x7fffffffu)) + 0x7fffffffu));
            { unsigned t1; double z1; if (((0x5684edcu % (0xffffffffu | 1u))) & 1u) { t1 = (unsigned)(m0 < (unsigned)f0); z1 = (double)(((unsigned)((short)(unsigned)b0 > (signed char)7u)) & 255u); } if (((0x5684edcu % (0xffffffffu | 1u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                L2: if (--fuel == 0u) goto done;
                if ((u3 & (0x80000000u & (unsigned)e0))) break;
                l0 = (long)((unsigned long)l0 + ((unsigned)((i2 % (u3 | 1u)) || v0) ^ (unsigned)d0));
            }
        }
        e0 = e0 * 0.5L + (long double)((fuel * (unsigned)(short)(unsigned)((int)u2 < (int)(p0 | (unsigned)(u2 == (unsigned)d0)))) & 1023u);
        if (0x80000000u) break;
    }
    u2 = u0;
    goto L4;
    s0 = (int)(unsigned)(short)(unsigned)(garr[u2 & 7u] && 0x7fffffffu);
    s0 = (int)(unsigned)x0;
    w0 = w0 * 6364136223846793005ull + ((unsigned)(0x9e8c40b5u || u2) & ((unsigned)s1 ? u2 : fuel));
    while ((unsigned)(i1 < 0x80000000u)) { if (--fuel == 0u) goto done;
        q0 = &garr[(unsigned)(0x53c966f0u == (unsigned)e0) & 7u];
        if (r0.y) goto L4;
        switch (((unsigned)f0 | p2) & 7u) {
            switch ((unsigned)(i0 && (unsigned)d0) & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn0((g1 * (unsigned)((short)*mp > (signed char)4u)), -(unsigned)((int)0x10000u >= (int)(unsigned)(w0 >> 29)), 2u); }
                if (u3 == 7u) return (unsigned)((short)1u > (signed char)m0);
                s0 = (int)(unsigned)!((unsigned)b0 - (0xffffffffu | (garr[i1 & 7u] | (unsigned)l0)));
                switch ((unsigned)(short)(unsigned)((unsigned)h0 == ((unsigned)s1 | 0x7fffffffu)) & 7u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)7u < (int)(8u * p2)), (unsigned)!((0x7fffffffu * 0x7d41f485u) + (unsigned)c0), i2); }
                    q0 = &garr[((unsigned)w0 | 0u) & 7u];
                    if ((unsigned)(p0 == (unsigned)(unsigned char)(0u ^ 0xaf0239b1u))) goto L0;
                    v0 = (unsigned)(0xffffffffu || (0x10000u + (0xf6c69a99u << ((unsigned)e0 & 31u))));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)*mp > (signed char)p0), 7u, (garr[i1 & 7u] * m0)); }
                }
                if ((unsigned)((short)(unsigned)f0 > (signed char)0xa43024e7u)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)garr[i1 & 7u] < (int)(unsigned)(w0 >> 29)), 0xade5f7b7u, 0x10000u); }
            }
            l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)f0 || a0[i0 & 3u]));
            u1 = (unsigned)(unsigned char)(unsigned)((short)(unsigned)c1 > (signed char)(unsigned)b0);
        }
        r0.x = (unsigned)((short)p2 > (signed char)u2);
    }
    a0[0xba2a5b71u & 3u] = (unsigned)((short)(0x10000u + i0) > (signed char)i0);
    if ((unsigned)((unsigned)e0 < (unsigned)e0)) goto L0;
    q0 = &garr[-(0xab61b648u % ((unsigned)((4u + g0) < 0x5dfe4a38u) | 1u)) & 7u];
    g0 = (unsigned)((int)(unsigned)((short)u1 > (signed char)(unsigned)h0) >= (int)(unsigned)(0x34bf1020u < 0x10dcf648u));
    h0 = (short)(unsigned)((int)((unsigned)f0 % ((unsigned)((int)(unsigned)!((unsigned)s1 | a0[u1 & 3u]) < (int)fuel) | 1u)) >= (int)(unsigned)l0);
    do { if (--fuel == 0u) goto done;
        c1 = (signed char)(unsigned)(0x38724e62u && ((unsigned)h0 * *mp));
        L3: if (--fuel == 0u) goto done;
        if (((unsigned)c0 - garr[u2 & 7u])) break;
        if ((((unsigned)s1 % (3u | 1u)) << ((unsigned)s1 & 31u))) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)((unsigned)(w0 >> 29) * (unsigned)(x0 >> 70)) < (int)u1), ((unsigned)((int)u3 >= (int)r0.y) ^ 0x10000u), (unsigned)(0xffffffffu || u3)); }
        }
        if ((i1 | 0x80000000u)) goto L4;
        if (budget != 0u) { budget -= 1u; u0 = fn0(0u, r0.x, (unsigned)((unsigned)(u2 == 0u) < (unsigned)h1)); }
    } while (i0++ < 7u && (unsigned)(x0 >> 70));
    if (budget != 0u) { budget -= 1u; u2 = fn0(0xffffffffu, ((unsigned)(fuel && (unsigned)(x0 >> 70)) % (v0 | 1u)), ((0x80000000u >> ((unsigned)c0 & 31u)) << (fuel & 31u))); }
    switch ((unsigned)(w0 >> 29) & 7u) {
        m0 ^= (unsigned)(w0 >> 29);
    }
    if ((unsigned)!(*mp << (0x10000u & 31u))) {
        goto L3;
        for (;;) { if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
            i2 = (unsigned)(i1 || v0) & 15u;
        }
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((int)0x5b519d71u < (int)m0) && (0x10000u ? (unsigned)(w0 >> 29) : u0)) & 255u);
        s0 = (int)(r0.y % (i1 | 1u));
        m0 ^= (i0 ^ (0xab97b065u + ((unsigned)h1 + (unsigned)w0)));
    } else {
        goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0(i2, (unsigned)(0xbedca58eu < (unsigned)c0), -(r0.x ^ a0[u1 & 3u])); }
        if (fuel) goto L1;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((((unsigned)f0 << (0x7fffffffu & 31u)) - r0.y), v0, (unsigned)(fuel == (unsigned)(*mp < i1))); }
    switch (0x7fffffffu & 7u) {
        if ((unsigned)((int)(unsigned)x0 < (int)i2)) {
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)c0 ? (unsigned)c1 : 0xcd1a87ecu), (unsigned)(x0 >> 70), (5u >> ((unsigned)((unsigned)c1 && (unsigned)h0) & 31u))); }
            if (budget != 0u) { budget -= 1u; u0 = fn0((v0 << (i2 & 31u)), 0x80000000u, ((unsigned)h1 - ((unsigned)e0 ^ i1))); }
            *q0 = 0x5fda119du;
            u3 = u3 * 0x9e3779b1u + ((r0.y + 0x4a780f1eu) + 8u);
            case 4u: ;
            if (((unsigned)b0 / ((0x80000000u ^ (unsigned)h0) | 1u))) break;
        } else {
            do { if (--fuel == 0u) goto done;
                if ((u2 & (unsigned)(0x7fffffffu && garr[u2 & 7u]))) continue;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(unsigned)((unsigned)(x0 >> 70) || (unsigned)((int)0xd55073bbu >= (int)g0)), ~(v0 - (unsigned)(short)(unsigned)(0x3897e0ebu || 1u)), (a0[i0 & 3u] ? 7u : garr[u2 & 7u])); }
                *mp = (unsigned)(short)(unsigned)((a0[i0 & 3u] - (unsigned)s0) && (unsigned)c1);
                q0 = &garr[(unsigned)((unsigned)w0 < ((6u & (unsigned)d0) * (unsigned)((unsigned)d0 && 0x65dca702u))) & 7u];
                if ((unsigned)(short)(5u / (9u | 1u))) goto L4;
            } while (i0++ < 3u && (unsigned)((int)(unsigned)s1 >= (int)(unsigned)b0));
            case 2u: ;
            f0 = f0 * 0.5f + (float)((0u * (unsigned)((unsigned)((unsigned)s1 || *q0) == 0x7fffffffu)) & 255u);
        }
        while (i0++ < 5u && (6u >> ((8u & a0[i0 & 3u]) & 31u))) { if (--fuel == 0u) goto done;
            if ((unsigned)(unsigned char)(9u | i1)) break;
        }
        if ((0xffffffffu + -((unsigned)(x0 >> 70) % (u1 | 1u)))) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((u3 | (unsigned)((int)p0 < (int)(unsigned)c0)), u2, (unsigned)(r0.x || (unsigned)h1)); }
            i0 = ((unsigned)x0 + ((r0.y ? (unsigned)(x0 >> 70) : (unsigned)h1) ^ *q0)) & 15u;
        } else {
            b0 = (0x364b7f7eu * (unsigned)s0) != 0u;
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                default: ;
                case 0u: ;
                while ((unsigned)(7u || (unsigned)(a0[u1 & 3u] == p1))) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(x0 >> 70) || fuel), (unsigned)!(unsigned)((int)p0 < (int)(unsigned)e0), v0); }
                }
                e0 = e0 * 0.5L + (long double)((((unsigned)b0 | (unsigned)((short)(unsigned)w0 > (signed char)0xf6ba7664u)) | (unsigned)(0x82255509u < 0x10000u)) & 1023u);
            }
            do { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)((unsigned)s0 & i0) >= (int)5u)) break;
                }
            } while (i0++ < 3u && (unsigned)x0);
        }
        if (((unsigned)(*mp && p2) - g1)) goto L4;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((2u ^ (unsigned)((unsigned)d0 == 0xffffffffu)), ((unsigned)(w0 >> 29) >> (1u & 31u)), (unsigned)((unsigned)h0 == 2u)); }
            if ((fuel >> ((0xffffffffu + a0[i0 & 3u]) & 31u))) {
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 1u: ;
                    case 3u: ;
                    if ((unsigned)((short)8u > (signed char)g1)) {
                        break;
                        c1 = (signed char)(unsigned)f0;
                        for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                            w0 = w0 * 6364136223846793005ull + (unsigned)(5u || (unsigned)c0);
                            break;
                            *q0 = (unsigned)((short)fuel > (signed char)p2);
                            g0 = (unsigned)(0u || u1);
                            if (budget != 0u) { budget -= 1u; u0 = fn0(0x9bdd72e1u, u1, (unsigned)(garr[u2 & 7u] == (unsigned)(short)(unsigned)((unsigned)h1 && p2))); }
                            s0 = (int)(unsigned)((short)9u > (signed char)(((unsigned)w0 << ((unsigned)!(8u ^ 0x7fffffffu) & 31u)) ^ 6u));
                        }
                    }
                }
                if ((unsigned)((int)a0[i0 & 3u] >= (int)i2)) continue;
            }
        } while (i0++ < 3u && ((unsigned)h1 & (unsigned)e0));
        c0 = (unsigned char)(0x80000000u ? (unsigned)(p0 == (unsigned)((short)u0 > (signed char)0x7fffffffu)) : 1u);
    }
    while (i0++ < 2u && (unsigned)!(-((unsigned)(x0 >> 70) % (fuel | 1u)) - 0x10000u)) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0((0x10000u | (unsigned)((int)0x10000u >= (int)0xffffffffu)), (0x7fffffffu % (p2 | 1u)), (unsigned)(r0.y == (2u | (unsigned)f0))); }
        switch ((unsigned)(0x13c5da9fu && 8u) & 7u) {
            h0 = (short)(unsigned)(short)(unsigned)((unsigned)s1 < 1u);
            case 2u: ;
            case 4u: ;
            *q0 += (0x80000000u / ((p0 * a0[i0 & 3u]) | 1u));
            if (((unsigned)s0 * (unsigned)(x0 >> 70))) {
                d0 = d0 * 0.5 + (double)((unsigned)(signed char)(i2 | (unsigned)(signed char)(unsigned)((short)(unsigned)s0 > (signed char)0x7fffffffu)) & 1023u);
            }
        }
    }
    switch ((unsigned)s1 & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)i2 < (int)m0), (a0[u1 & 3u] % (*mp | 1u)), (unsigned)(0x80000000u || (unsigned)(m0 && (unsigned)l0))); }
        g1 += u1;
    }
    if ((unsigned)(0x8565f639u < p1)) goto L2;
    if ((unsigned)((short)garr[i1 & 7u] > (signed char)garr[u2 & 7u])) {
        if (((unsigned)(i0 == 3u) & a0[i0 & 3u])) {
            if ((0xffffffffu << (m0 & 31u))) goto L0;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((0xffffffffu >> (0x80000000u & 31u)) && a0[u1 & 3u]), u1, (unsigned)!(4u >> (garr[u2 & 7u] & 31u))); }
        } else {
            do { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)d0 << ((5u * p1) & 31u)), (unsigned)(short)(((unsigned)h1 + i0) / ((unsigned)d0 | 1u)), (unsigned)(signed char)(unsigned)((unsigned)e0 < (unsigned)s0)); }
                    e0 = e0 * 0.5L + (long double)((0xffffffffu << ((unsigned)h0 & 31u)) & 1023u);
                }
                if ((unsigned)(u0 < g0)) {
                    s0 = (int)(unsigned)((1u % (i0 | 1u)) == (i0 >> ((unsigned)(0xc09e5203u == p2) & 31u)));
                    for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((short)(unsigned)(short)(g0 / (7u | 1u)) > (signed char)2u)) goto L0;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(x0 >> 70) | (unsigned)(x0 >> 70)), (unsigned)(7u || ((unsigned)h1 << (0x10000u & 31u))), (unsigned)(short)(p0 & (unsigned)!(unsigned)(garr[i1 & 7u] || r0.x))); }
                    }
                    if ((unsigned)(0xffffffffu < 4u)) break;
                    if ((unsigned)(p2 && 5u)) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x7fffffffu || ((unsigned)h1 << (2u & 31u))), (0x80000000u >> ((unsigned)h0 & 31u)), g1); }
                    if ((unsigned)w0) break;
                }
                for (;;) { if (--fuel == 0u) goto done;
                    c1 = (signed char)0x42da1e2fu;
                    u2 = (unsigned)((unsigned)((int)u0 >= (int)(unsigned)((int)a0[i0 & 3u] >= (int)0xffffffffu)) == fuel);
                    while (i2++ < 3u && (garr[u2 & 7u] - *q0)) { if (--fuel == 0u) goto done;
                        continue; (void)((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)f0));
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((*mp ^ r0.y), ((unsigned)w0 & 0x7fffffffu), (unsigned)e0); }
                    if (((unsigned)x0 & (0x1a9de5bfu & 0xffffffffu))) break;
                }
            } while (i0++ < 2u && m0);
            e0 = e0 * 0.5L + (long double)(g1 & 1023u);
            b0 = (unsigned)((unsigned)(u0 && g0) && fuel) != 0u;
        }
        garr[(unsigned)(signed char)((unsigned)x0 / (g1 | 1u)) & 7u] = (unsigned)(-(unsigned)(0xffffffffu < 0xb9b4a99du) < (unsigned)(garr[i1 & 7u] == m0));
        if (5u) goto L4;
    } else {
        if (*mp) {
            if ((unsigned)(*q0 || (unsigned)h1)) {
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = v0;
                    if ((0x1ef21094u ? u2 : 5u)) break;
                    c0 = (unsigned char)((unsigned)((int)p2 >= (int)u0) * r0.x);
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((0xffffffffu ^ fuel) < 7u), (unsigned)(unsigned char)(unsigned)((int)m0 >= (int)(unsigned)(0x54da4999u || i2)), (unsigned)(signed char)(unsigned)((int)(unsigned)s0 >= (int)(unsigned)(x0 >> 70))); }
                    w0 ^= (unsigned long long)(0x34daa1e5u / (u0 | 1u)) << ((((unsigned)(p2 < (unsigned)f0) ^ 0xfe5e0dd1u) >> ((unsigned)!(fuel % (m0 | 1u)) & 31u)) & 63u);
                    if ((unsigned)(unsigned char)(0xce440571u & u0)) break;
                }
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    u3 ^= (a0[i0 & 3u] % (p2 | 1u));
                    f0 = f0 * 0.5f + (float)(((p2 % (((unsigned)h1 | (unsigned)c1) | 1u)) & garr[i1 & 7u]) & 255u);
                    *mp = ((unsigned)((int)(unsigned)l0 >= (int)u1) * (p2 - 2u));
                    garr[u0 & 7u] = ((u3 << (((0x80000000u % (0x6ff574f3u | 1u)) / (0x2537c45du | 1u)) & 31u)) ^ g0);
                    s0 = (int)(unsigned)((unsigned)((short)(unsigned)l0 > (signed char)a0[u1 & 3u]) || ((unsigned)s1 - 0x7fffffffu));
                    if (budget != 0u) { budget -= 1u; u3 = fn0(r0.x, (unsigned)((int)(3u * g0) < (int)i2), ((unsigned)(w0 >> 29) % (0x563f02ffu | 1u))); }
                }
                a0[(unsigned)((int)(unsigned)s0 < (int)(unsigned)h0) & 3u] = (unsigned)(5u && (unsigned)(signed char)(i2 ? ((unsigned)l0 << (g0 & 31u)) : garr[i1 & 7u]));
                if ((unsigned)(w0 >> 29)) {
                    if ((0x80000000u | (unsigned)(signed char)(0x10000u & 0x4a903757u))) goto L3;
                    for (;;) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn0((0x2ee081cau | (unsigned)(signed char)((unsigned)l0 * fuel)), (unsigned)(w0 >> 29), u0); }
                        if ((*mp * (unsigned)(signed char)(0x7fc1df78u ^ 0xffffffffu))) {
                            g1 += garr[i1 & 7u];
                            if ((fuel & 3u)) break;
                            q0 = &garr[((unsigned)((unsigned)h1 < (unsigned)h1) << ((unsigned)((int)(unsigned)c0 < (int)*q0) & 31u)) & 7u];
                            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)l0 - (unsigned)d0), *mp, (0xe0f51455u ? 0x4dd9114du : 4u)); }
                            e0 = e0 * 0.5L + (long double)(-(p1 - (unsigned)!((unsigned)((unsigned)s1 < *q0) % (u3 | 1u))) & 1023u);
                            l0 = (long)((unsigned long)l0 + (unsigned)((short)(unsigned)e0 > (signed char)a0[i0 & 3u]));
                        } else {
                            *mp = (unsigned)!(unsigned)((int)a0[u1 & 3u] < (int)(unsigned)h0);
                        }
                        if ((unsigned)(0x7fffffffu == ((unsigned)w0 << (0x7fffffffu & 31u)))) break;
                        if ((unsigned)(short)(r0.y << ((unsigned)(r0.y && r0.x) & 31u))) break;
                    }
                    u0 += (unsigned)(u3 == p0);
                    switch ((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)e0) & 7u) {
                        g1 += ((unsigned)(0x7fffffffu || garr[u2 & 7u]) * g0);
                        do { if (--fuel == 0u) goto done;
                            x0 = x0 * 0x100000001b3ull + ((unsigned)e0 ? 8u : r0.x);
                        } while (i0++ < 2u && 0xf9aa2226u);
                        u3 = u3 * 0x9e3779b1u + (g1 * -(unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)(x0 >> 70)));
                    }
                    goto L0;
                }
            }
            if (fuel < 8u) return (unsigned)(signed char)((unsigned)((unsigned)(w0 >> 29) && 0x7e9c063au) + (unsigned)d0);
            u0 += (unsigned)((((unsigned)h0 - 6u) & (g1 << (a0[i0 & 3u] & 31u))) == 0xe765356eu);
            if (budget != 0u) { budget -= 1u; u1 = fn0((i0 + (unsigned)c1), 4u, (0x9adc6e93u & *mp)); }
            w0 ^= (unsigned long long)(i1 >> (r0.x & 31u)) << ((1u ^ i0) & 63u);
            if (budget != 0u) { budget -= 1u; u3 = fn0(u2, (unsigned)((unsigned)w0 || a0[u1 & 3u]), (((unsigned)s1 >> (i1 & 31u)) ^ i2)); }
        }
        goto L3;
        if ((unsigned)((u0 & (unsigned)w0) || i0)) goto done;
        *mp = (unsigned)(7u < u2);
    }
    if (5u) goto L3;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (~(unsigned)((int)(r0.y & (unsigned)l0) < (int)0x5679ad7cu)) break;
                h1 = (unsigned short)(h1 + ((9u & (unsigned)((short)0xffffffffu > (signed char)0x7fffffffu)) & 0x4bcef811u));
                g1 += ((unsigned)(3u == r0.y) | -(((unsigned)l0 ^ 0xffffffffu) | 0x78075751u));
                h1 = (unsigned short)(h1 + ((unsigned)((int)p2 < (int)a0[u1 & 3u]) | (unsigned)(x0 >> 70)));
            }
            r0.x = (unsigned)b0;
            *q0 = (unsigned)(short)(7u ? 0x24b6f94u : (5u ? 2u : p0));
            u1 += ~(unsigned)((short)u0 > (signed char)(u3 / (((unsigned)w0 % (garr[i1 & 7u] | 1u)) | 1u)));
        }
        e0 = e0 * 0.5L + (long double)((unsigned)(p1 < (r0.y ^ i0)) & 1023u);
        if ((unsigned)(a0[u1 & 3u] < (unsigned)(w0 >> 29))) continue;
        g1 += (0x84a4f449u | 0x80000000u);
    }
    l0 = (long)((unsigned long)l0 + (unsigned)s0);
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (u3 == 7u) return ((unsigned)h0 + m0);
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(short)(unsigned)((int)0x10000u >= (int)(r0.x * a0[i0 & 3u]))) continue;
                if (fuel < 8u) return ((unsigned)((int)garr[u2 & 7u] >= (int)i2) / (r0.x | 1u));
            } while (i2++ < 4u && (unsigned)s1);
            break; (void)(2u);
            if (0xdf0344f0u) break;
        } while (i1++ < 5u && 0x86f0e3du);
        if ((unsigned)((int)(unsigned)(x0 >> 70) < (int)6u)) {
            a0[0x10000u & 3u] = ((u1 >> (0x80000000u & 31u)) + (0xffffffffu | (unsigned)(garr[i1 & 7u] || p2)));
            if ((unsigned)((short)r0.y > (signed char)u0)) {
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(garr[i1 & 7u] ^ r0.x), garr[i1 & 7u], (g1 % ((unsigned)w0 | 1u))); }
                if (0xffffffffu) goto L1;
                if (budget != 0u) { budget -= 1u; u0 = fn0(((0xc0e95833u << (0x9d45871bu & 31u)) / (a0[i0 & 3u] | 1u)), (u2 & 0xffffffffu), (unsigned)!(unsigned)((int)0x7fffffffu >= (int)(unsigned)(0x920d4ce0u < garr[i1 & 7u]))); }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)0x98bc1e83u > (signed char)fuel), (unsigned)(4u || (unsigned)c1), (a0[i0 & 3u] >> ((unsigned)d0 & 31u))); }
                if (budget != 0u) { budget -= 1u; u0 = fn0(~((unsigned)!(0x10000u + u1) % (8u | 1u)), (unsigned)((short)u1 > (signed char)p0), (g0 >> ((unsigned)x0 & 31u))); }
            }
        }
        if (((p1 >> (*mp & 31u)) % (0xd9162138u | 1u))) break;
        if (u1) goto L2;
    } while (i0++ < 6u && (unsigned)(signed char)(0x80000000u << (i0 & 31u)));
    switch ((0x10000u | 8u) & 7u) {
        x0 = x0 * 0x100000001b3ull + ((1u / (a0[u1 & 3u] | 1u)) ^ (unsigned)(signed char)((unsigned)((int)(unsigned)(w0 >> 29) < (int)i0) | r0.x));
        u0 ^= 0x10000u;
        goto done;
        if ((u3 & *mp)) goto L3;
        garr[(u2 ^ p0) & 7u] = (unsigned)(((unsigned)b0 ? ((unsigned)l0 + (unsigned)e0) : 0x2271c5e9u) || 0x80000000u);
        break; (void)(i2);
    }
    do { if (--fuel == 0u) goto done;
        v0 = (unsigned)((short)(unsigned)(signed char)(unsigned)((int)(unsigned)(g1 < p1) < (int)((unsigned)s0 | (unsigned)c1)) > (signed char)a0[i0 & 3u]);
    } while (i0++ < 4u && (unsigned)((int)7u >= (int)u2));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    v0 = ((unsigned)w0 - (unsigned)(((unsigned)x0 ^ fuel) < 0x3a7d6b0au));
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)s1, 0x80000000u, 0x9c379469u); }
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)(r0.x | u0), r0.x, (unsigned)((short)8u > (signed char)r0.x)); }
    garr[((unsigned)s1 + (unsigned)x0) & 7u] = (unsigned)(7u || (unsigned)((int)0x80000000u >= (int)(unsigned)c1));
    g1 += ((unsigned)f0 / (((unsigned)(*mp < (unsigned)(short)(unsigned)(a0[i0 & 3u] && (unsigned)(x0 >> 70))) << (r0.y & 31u)) | 1u));
    if (r0.y) goto L2;
    goto L4;
    if ((0x8e624e81u >> ((unsigned)h0 & 31u))) goto L4;
    v0 = (0x1a28d5dbu | (((unsigned)((short)(unsigned)c1 > (signed char)i0) / (fuel | 1u)) / ((unsigned)b0 | 1u)));
    h0 = (short)(unsigned)((int)((p1 % (m0 | 1u)) >> (0x890eca7u & 31u)) >= (int)((unsigned)s0 & i2));
    goto L3;
    do { if (--fuel == 0u) goto done;
        u1 ^= (g1 - (unsigned)h1);
    } while (i0++ < 7u && *mp);
    u3 = (unsigned)h0;
    l0 = (long)((unsigned long)l0 + (v0 << (2u & 31u)));
    if (u1) goto L3;
    L0: if (--fuel == 0u) goto done;
    r0.x = 1u;
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)fuel >= (int)(unsigned)(0x80000000u == 0u)), ((unsigned)b0 ^ u0), (i2 / (5u | 1u))); }
    m0 ^= (r0.x % (r0.x | 1u));
    u3 ^= (unsigned)((unsigned)d0 && (0xf2baaf9eu + ((unsigned)b0 - (unsigned)b0)));
    switch ((0x7fffffffu ? (unsigned)(x0 >> 70) : u0) & 7u) {
        L1: if (--fuel == 0u) goto done;
        while (i0++ < 7u && i1) { if (--fuel == 0u) goto done;
            if (fuel < 8u) return (0xced01222u & (unsigned)((int)(unsigned)c0 < (int)(7u ^ 8u)));
            if ((unsigned)e0) goto L1;
            f0 = f0 * 0.5f + (float)((unsigned)(u3 == (a0[i0 & 3u] * garr[u2 & 7u])) & 255u);
        }
    }
    while (i0++ < 3u && (unsigned)x0) { if (--fuel == 0u) goto done;
        if (*mp) break;
        w0 ^= (unsigned long long)(unsigned)e0 << (((unsigned)e0 / ((unsigned)((short)(unsigned)w0 > (signed char)m0) | 1u)) & 63u);
        { unsigned t0; double z0; if ((8u) & 1u) { t0 = (unsigned)((short)u1 > (signed char)u1); z0 = (double)((0x4c8e476eu) & 255u); } if ((8u) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            q0 = &garr[(unsigned)(((0x7fffffffu ? i2 : i2) / (g0 | 1u)) || (unsigned)w0) & 7u];
        }
        while ((unsigned)c0) { if (--fuel == 0u) goto done;
            while (i2++ < 3u && (unsigned)(unsigned char)(unsigned)((short)4u > (signed char)u0)) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((((unsigned)h1 % ((unsigned)w0 | 1u)) & p0) & 255u);
                if (0x10000u) break;
                b0 = (u3 + (unsigned)((unsigned)s1 || (0x10000u - 9u))) != 0u;
            }
            if ((unsigned)(unsigned char)(unsigned)(8u < ((unsigned)h0 & u1))) goto done;
            m0 ^= (8u | (i1 & 0x7fffffffu));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1((v0 << ((unsigned)(0x7fffffffu == g0) & 31u)), (r0.y >> (g1 & 31u)), -(i1 / (0xddb64a85u | 1u))); }
    }
    u3 ^= (g0 / (g1 | 1u));
    if ((unsigned)(0xd6f6e80cu < (unsigned)f0)) goto L4;
    a0[0xffffffffu & 3u] = (unsigned)((unsigned)((short)0x5ba89d09u > (signed char)5u) == (unsigned)((unsigned)s0 < 0xe58befc9u));
    u3 ^= (0x7fffffffu * 0xffffffffu);
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(p1 >> ((unsigned)d0 & 31u)) >= (int)i2), (unsigned)f0, v0); }
    g1 += (unsigned)((int)(unsigned)((short)(unsigned)s0 > (signed char)u0) < (int)((unsigned)(4u && u0) & g1));
    *mp = (unsigned)((int)(unsigned)(a0[i0 & 3u] == (unsigned)c0) < (int)u1);
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)f0 >= (int)(3u | (unsigned)x0)), ~(i2 ^ r0.y), (g1 + 0xd10b84bdu)); }
    u0 ^= (unsigned)((unsigned)((unsigned)(a0[u1 & 3u] || (unsigned)d0) || g0) || (2u * 8u));
    do { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((((0x7fffffffu >> (a0[u1 & 3u] & 31u)) / ((unsigned)c0 | 1u)) % ((unsigned)((int)(unsigned)e0 >= (int)(unsigned)s1) | 1u)) & 1023u);
        f0 = f0 * 0.5f + (float)(*mp & 255u);
        u2 ^= ((unsigned)((short)(0x6424527eu | 0x7fffffffu) > (signed char)(unsigned)c0) / ((unsigned)d0 | 1u));
    } while (i0++ < 2u && (unsigned)((*q0 * i1) == 2u));
    do { if (--fuel == 0u) goto done;
        if ((0x7c9b731cu >> (a0[i0 & 3u] & 31u))) {
            while (i1++ < 5u && (*q0 ? u3 : u3)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)h0 << ((unsigned)w0 & 31u)), ((unsigned)(unsigned char)(0x9a525a34u / (garr[u2 & 7u] | 1u)) & (unsigned)w0), (0xffffffffu + 8u)); }
            }
            q0 = &garr[(unsigned)(m0 || (unsigned)h0) & 7u];
            r0.y ^= ((unsigned)h1 << (0xffffffffu & 31u));
            if (((unsigned)h0 | (2u | 0xf5868627u))) goto done;
        } else {
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)((short)7u > (signed char)u2) < (int)(unsigned)c1), (unsigned)((int)(unsigned)b0 < (int)(unsigned)!((unsigned)c0 * (unsigned)(w0 >> 29))), i0); }
            L2: if (--fuel == 0u) goto done;
            h0 = (short)(((unsigned)e0 % (0x10000u | 1u)) + (unsigned)(signed char)(u1 & 0xffffffffu));
            garr[((unsigned)s1 ^ (unsigned)l0) & 7u] = (u3 / (7u | 1u));
        }
        b0 = 0x80000000u != 0u;
    } while (i0++ < 5u && *mp);
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (u3 == 7u) return garr[i1 & 7u];
            if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)(0x4f5852bcu < *q0) & 9u), (0xe0aee505u & 0x80000000u), (unsigned)((int)8u >= (int)(unsigned)(x0 >> 70))); }
            i2 = ((garr[i1 & 7u] ^ 0x7fffffffu) / (((unsigned)s1 & (unsigned)((unsigned)(w0 >> 29) == (unsigned)f0)) | 1u)) & 15u;
            c0 = (unsigned char)(unsigned)(short)(unsigned)((short)0xc2784e6u > (signed char)r0.x);
            r0.y ^= (0x10000u + ((unsigned)s0 >> (0x7fffffffu & 31u)));
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)(v0 & 255u);
            continue; (void)(((unsigned)f0 & ((unsigned)l0 ^ 0x7fffffffu)));
            if (((0x1cf49f0du ^ 0x7fffffffu) ^ 0x509c7e89u)) break;
            if (budget != 0u) { budget -= 1u; u3 = fn1(0x80000000u, (((unsigned)x0 & 0x10000u) * (unsigned)(w0 >> 29)), (unsigned)((int)0x80000000u >= (int)(unsigned)x0)); }
            if (0x80000000u) {
                while (i2++ < 5u && p2) { if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                    *q0 = (unsigned)((int)((unsigned)((int)p2 >= (int)(unsigned)e0) & a0[u1 & 3u]) < (int)0x80000000u);
                    if ((unsigned)(r0.x < ((unsigned)s1 % (garr[u2 & 7u] | 1u)))) continue;
                    L4: if (--fuel == 0u) goto done;
                    if (u3 == 7u) return ((unsigned)(short)((unsigned)(w0 >> 29) * garr[u2 & 7u]) >> ((a0[u1 & 3u] * p0) & 31u));
                }
            }
            d0 = d0 * 0.5 + (double)((0x7fffffffu >> (0xffffffffu & 31u)) & 1023u);
        }
        v0 = ((unsigned)(unsigned char)((p2 & 0xcea3aea9u) * (unsigned)(x0 >> 70)) | (0x7fffffffu * i0));
        if (budget != 0u) { budget -= 1u; u3 = fn1(garr[i1 & 7u], (unsigned)((short)u1 > (signed char)0u), (unsigned)h0); }
        f0 = f0 * 0.5f + (float)((*q0 + 0x7fffffffu) & 255u);
    }
    s1 = (int)((unsigned)s1 + ((unsigned)l0 + (unsigned)x0));
    if (((unsigned)l0 / ((unsigned)(signed char)((unsigned)d0 >> ((unsigned)l0 & 31u)) | 1u))) goto L4;
    if ((unsigned)((unsigned)c1 && (0x3f6c5d67u & *mp))) goto L4;
    goto L2;
    if ((fuel % ((unsigned)(unsigned char)(a0[i0 & 3u] - (unsigned)(w0 >> 29)) | 1u))) {
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(*mp || (0xffffffffu % (r0.x | 1u))), (garr[i1 & 7u] / ((0x9b452392u / ((unsigned)s1 | 1u)) | 1u)), (unsigned)(signed char)(unsigned)((short)r0.y > (signed char)(u3 << (6u & 31u)))); }
        q0 = &garr[(unsigned)!(1u ? (unsigned)((int)7u < (int)u1) : (unsigned)s1) & 7u];
        g0 = -((r0.x - v0) & 6u);
        c1 = (signed char)(u2 & ((unsigned)((short)6u > (signed char)*mp) ? (unsigned)b0 : r0.y));
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(a0[u1 & 3u]);
            while ((unsigned)(g1 && i0)) { if (--fuel == 0u) goto done;
                if ((unsigned)x0) continue;
                f0 = f0 * 0.5f + (float)((p1 >> ((unsigned)(garr[i1 & 7u] || (unsigned)l0) & 31u)) & 255u);
                if ((i1 + u2)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn1((0x707f135fu ^ ((unsigned)s0 / ((unsigned)f0 | 1u))), ((unsigned)w0 & (unsigned)(w0 >> 29)), (unsigned)b0); }
                if (g0) {
                    b0 = (unsigned)(0xc470d761u == u0) != 0u;
                    h1 = (unsigned short)(h1 + (unsigned)!(unsigned)((int)r0.x < (int)(unsigned)((unsigned)(0x7fffffffu == 0x8c6888f3u) < 0x80000000u)));
                } else {
                    if (r0.x) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(*mp, (0xffffffffu % (r0.x | 1u)), (unsigned)(u1 && (unsigned)((int)0x7fffffffu < (int)u1))); }
                    a0[(unsigned)(i1 < (unsigned)s1) & 3u] = (u0 & 0xe889983u);
                    w0 = w0 * 6364136223846793005ull + r0.y;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)(x0 >> 70) + (unsigned)(w0 >> 29)), (unsigned)c0, (unsigned)(8u == (unsigned)s0)); }
            }
            r0.x = (unsigned)((int)(unsigned)e0 < (int)(unsigned)((6u + 8u) || (0x2f655c25u / (p1 | 1u))));
        }
        w0 = w0 * 6364136223846793005ull + garr[u2 & 7u];
    } else {
        switch (((unsigned)h0 / ((i1 & a0[i0 & 3u]) | 1u)) & 7u) {
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)0x9d77d6au;
            }
            for (;;) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + garr[i1 & 7u]);
                if (budget != 0u) { budget -= 1u; u3 = fn0(5u, garr[i1 & 7u], (unsigned)(*mp || g1)); }
                break; (void)((unsigned)((int)8u >= (int)((unsigned)s1 / ((unsigned)d0 | 1u))));
            }
            h0 = (short)(unsigned)(unsigned char)(3u % (g1 | 1u));
        }
    }
    goto L4;
    h0 = (short)((*q0 % (0x7fffffffu | 1u)) * u0);
    if ((i1 ^ u0)) goto L3;
    if (((unsigned)h0 << (-(0u + 0xffffffffu) & 31u))) goto L0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    b0 = ((unsigned)(r0.x < (unsigned)e0) * (unsigned)((unsigned)b0 < (u1 ^ (unsigned)b0))) != 0u;
    u2 ^= (unsigned)((int)(unsigned)(unsigned char)(unsigned)(0x7fffffffu == 0x10000u) >= (int)((unsigned)b0 + p1));
    do { if (--fuel == 0u) goto done;
        u2 = u2 * 0x9e3779b1u + (p0 % (0x5553db42u | 1u));
    } while (i0++ < 6u && (0x10000u & (unsigned)c0));
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)i1 >= (int)(unsigned)(3u < (unsigned)l0)), ((unsigned)e0 % ((unsigned)h1 | 1u)), i0); }
    L0: if (--fuel == 0u) goto done;
    r0.x = -(unsigned)((short)i2 > (signed char)(unsigned)((short)(unsigned)(signed char)(unsigned)((unsigned)c0 && garr[u2 & 7u]) > (signed char)(unsigned)c0));
    if (v0) goto L4;
    m0 ^= (u2 >> (0xa55aee23u & 31u));
    if ((unsigned)((int)u3 >= (int)a0[i0 & 3u])) {
        u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)l0 < p1);
        if ((unsigned)(signed char)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)*mp)) goto L3;
        if ((unsigned)((short)u1 > (signed char)i1)) goto L3;
    } else {
        e0 = e0 * 0.5L + (long double)(-(unsigned)((unsigned)s1 < (unsigned)((int)(unsigned)h1 >= (int)fuel)) & 1023u);
    }
    { unsigned t0; double z0; if ((9u) & 1u) { t0 = (m0 | u3); z0 = (double)((((i0 - 0xeff27095u) % (8u | 1u))) & 255u); } if ((9u) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        do { if (--fuel == 0u) goto done;
            if ((0x7fffffffu * r0.y)) goto L3;
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                garr[v0 & 7u] = (unsigned)((8u - m0) < (u3 >> (m0 & 31u)));
                if (fuel < 8u) return (unsigned)((int)~((unsigned)(a0[i0 & 3u] == (unsigned)w0) << (u1 & 31u)) >= (int)(unsigned)(short)((unsigned)s0 | (unsigned)s0));
            }
            if ((unsigned)((unsigned)((int)3u >= (int)(unsigned)(w0 >> 29)) && u1)) break;
            r0.x = (unsigned)!(unsigned)((5u | (unsigned)c0) && ~(unsigned)(u1 || (unsigned)h0));
            if (budget != 0u) { budget -= 1u; u0 = fn0(((9u << (*mp & 31u)) | r0.y), (a0[i0 & 3u] >> ((unsigned)((unsigned)e0 == (unsigned)h0) & 31u)), (unsigned)((unsigned)h0 && 3u)); }
        } while (i0++ < 6u && (0x5cdcde06u >> ((unsigned)((short)5u > (signed char)u1) & 31u)));
        { unsigned t1; double z1; if ((0x9b6acdb6u) & 1u) { t1 = v0; z1 = (double)((-(unsigned)(r0.x && u0)) & 255u); } if ((0x9b6acdb6u) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            d0 = d0 * 0.5 + (double)(garr[u2 & 7u] & 1023u);
            if (6u) goto L2;
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)8u > (signed char)0x658d7386u)) {
                    L1: if (--fuel == 0u) goto done;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn1(((0xffffffffu - r0.y) ^ 0xffffffffu), a0[u1 & 3u], (unsigned)h1); }
            }
            if (u3) goto L3;
        }
        d0 = d0 * 0.5 + (double)(3u & 1023u);
    }
    g0 = a0[i0 & 3u];
    u1 ^= (unsigned)((int)(p0 & (i2 | 0u)) < (int)(0x7fffffffu + (unsigned)x0));
    i2 = 4u & 15u;
    if (p0) {
        if (((unsigned)e0 * u2)) goto L0;
        c0 = (unsigned char)(unsigned)((int)r0.x >= (int)(((r0.x | (unsigned)h0) + u2) >> (v0 & 31u)));
        if (budget != 0u) { budget -= 1u; u0 = fn2(i2, (unsigned)(signed char)(0x4d819247u | (unsigned)(a0[u1 & 3u] && u2)), (unsigned)(a0[i0 & 3u] == (unsigned)c0)); }
    }
    switch (u2 & 7u) {
        goto L3;
        while (i0++ < 3u && ((unsigned)(8u || i1) | g1)) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)(m0 < (unsigned)((unsigned)d0 < u3)));
        }
        u0 = (unsigned)!(unsigned)((int)(unsigned)h1 < (int)(unsigned)(signed char)(0x80000000u ? p0 : (unsigned)s0));
        m0 ^= ((unsigned)(0xa18b801fu && 6u) / ((unsigned)h1 | 1u));
    }
    w0 = w0 * 6364136223846793005ull + (0x10000u ^ fuel);
    if ((unsigned)(unsigned char)(unsigned)((int)p0 >= (int)p2)) goto L2;
    m0 ^= (unsigned)(0x5b6fb96au && (unsigned)b0);
    L2: if (--fuel == 0u) goto done;
    { unsigned t2; double z2; if ((i1) & 1u) { t2 = (unsigned)((short)(unsigned)((int)6u < (int)0xba7b952eu) > (signed char)0x265bfddfu); z2 = (double)(((fuel % (0x75c8a5e1u | 1u))) & 255u); } if ((i1) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        while (i0++ < 7u && ((unsigned)((int)0xd3fe370au >= (int)garr[u2 & 7u]) * u2)) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(~((unsigned)s0 - ((unsigned)((unsigned)f0 && (*q0 % (4u | 1u))) >> (0x80000000u & 31u))) & 1023u);
            while (i1++ < 6u && m0) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (unsigned)((4u + r0.y) && (unsigned)((int)3u < (int)(i2 << (0x9cc441b9u & 31u))));
                }
                garr[u3 & 7u] = -(unsigned)((short)(unsigned)((int)0x80000000u >= (int)9u) > (signed char)(unsigned)(p2 == (unsigned)e0));
                if ((unsigned)((int)0x836a7d98u < (int)7u)) continue;
                L3: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn1(a0[u1 & 3u], (unsigned)((int)0x31d9ae9au >= (int)0u), (i2 << (v0 & 31u))); }
                if ((3u << ((unsigned)(w0 >> 29) & 31u))) break;
            }
            if (0x18631f95u) {
                switch ((unsigned)(signed char)(0x7fffffffu ^ p0) & 7u) {
                    w0 ^= (unsigned long long)0x85e475aeu << (((unsigned)b0 + (a0[i0 & 3u] << (i1 & 31u))) & 63u);
                    case 3u: ;
                    f0 = f0 * 0.5f + (float)((9u - (0x7fffffffu % ((unsigned)((int)(unsigned)((short)*q0 > (signed char)0xffffffffu) < (int)2u) | 1u))) & 255u);
                    if ((unsigned)(u1 && 0x2e6ad7a4u)) continue;
                    g0 = (unsigned)((int)(fuel / ((unsigned)s0 | 1u)) >= (int)(unsigned)((int)~(0x10000u << (r0.y & 31u)) >= (int)(unsigned)b0));
                }
                b0 = (unsigned)d0 != 0u;
                h1 = (unsigned short)(h1 + (unsigned)c0);
            } else {
                L4: if (--fuel == 0u) goto done;
            }
            i0 = (unsigned)(signed char)(unsigned)(v0 < (unsigned)(i2 && (unsigned)(i1 == (unsigned)((unsigned)b0 < v0)))) & 15u;
            while (0xc9ddf372u) { if (--fuel == 0u) goto done;
                if ((0xffffffffu * *mp)) continue;
                g0 = (*mp & ((unsigned)!(unsigned)((short)(unsigned)h1 > (signed char)i2) - (unsigned)c1));
                while (i2++ < 7u && (garr[i1 & 7u] | a0[u1 & 3u])) { if (--fuel == 0u) goto done;
                    switch ((i1 ^ (unsigned)(signed char)(a0[u1 & 3u] - 0x31655fffu)) & 7u) {
                        e0 = e0 * 0.5L + (long double)((unsigned)(u1 < 0x7fffffffu) & 1023u);
                        if (fuel < 8u) return (unsigned)(signed char)((unsigned)f0 >> ((9u >> (p2 & 31u)) & 31u));
                        case 3u: ;
                    }
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((unsigned)s1 & ((i2 ? u2 : (unsigned)(w0 >> 29)) + p2));
                v0 = (unsigned)(g1 || (garr[u2 & 7u] & 0x3c28955cu));
            }
            l0 = (long)((unsigned long)l0 + ((0xc739c407u * u1) / (fuel | 1u)));
        }
    }
    { unsigned t3; double z3; if (((unsigned)h1) & 1u) { t3 = (0xffffffffu << (0xdc51446au & 31u)); z3 = (double)(((unsigned)l0) & 255u); } if (((unsigned)h1) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        if ((u3 - (v0 - i1))) goto L4;
        u1 ^= (unsigned)((unsigned)(x0 >> 70) || (*mp & m0));
        g1 += (unsigned)((*q0 + r0.y) && (unsigned)((unsigned)b0 || (unsigned)s0));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    r0.y ^= ((unsigned)h0 | ((0xdabc6cb7u ? r0.y : (unsigned)f0) % ((unsigned)s1 | 1u)));
    goto L0;
    if ((unsigned)(3u < i1)) goto L2;
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x5263fae4u || u2), (p0 * 0x8d5d99ffu), (unsigned)((short)(unsigned)s0 > (signed char)(unsigned)!((unsigned)s0 & garr[u2 & 7u]))); }
    if (0x10000u) goto L3;
    u1 = ((unsigned)d0 << ((unsigned)s1 & 31u));
    if (0x10000u) {
        s0 = (int)(0xd3d6869bu / ((unsigned)s1 | 1u));
        if ((0x10000u ^ 0xffffffffu)) {
            r0.y ^= i1;
        }
    } else {
        if (budget != 0u) { budget -= 1u; u2 = fn2((m0 & *mp), (unsigned)e0, (unsigned)c0); }
    }
    goto done;
    if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)(x0 >> 70) >> (*mp & 31u)), ((unsigned)(signed char)(unsigned)((int)7u < (int)0xc592b450u) & v0), (unsigned)((int)(i1 ^ 0x980d8497u) < (int)u1)); }
    r0.y ^= (unsigned)c0;
    s1 = (int)((unsigned)s1 + (a0[i0 & 3u] % (0xffffffffu | 1u)));
    L0: if (--fuel == 0u) goto done;
    if ((unsigned)(9u || (unsigned)d0)) goto L2;
    if (6u) {
        if ((0x80000000u % ((unsigned)d0 | 1u))) goto L2;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn2(garr[u2 & 7u], (*mp - u1), ~((unsigned)f0 | (unsigned)h1)); }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)(0xf7f629fau || g0), u2, u0); }
        break; (void)(p1);
        r0.y ^= -(garr[i1 & 7u] * p2);
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)s0, (unsigned)(u3 < i2), (unsigned)((int)fuel < (int)(unsigned)(signed char)(5u + *q0))); }
    } while (i0++ < 3u && ((unsigned)c0 * (unsigned)(signed char)(u2 % (0x7fffffffu | 1u))));
    if ((unsigned)((int)0x5bacbf51u < (int)v0)) {
        do { if (--fuel == 0u) goto done;
            if ((garr[i1 & 7u] << (*q0 & 31u))) break;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    q0 = &garr[a0[i0 & 3u] & 7u];
                    if (-((unsigned)l0 / ((unsigned)e0 | 1u))) break;
                    u3 = ((unsigned)(g1 && (unsigned)((unsigned)d0 && r0.x)) % ((unsigned)c1 | 1u));
                    g1 += ((unsigned)(signed char)((unsigned)h0 / (p2 | 1u)) / ((unsigned)e0 | 1u));
                }
                if ((v0 * (unsigned)b0)) break;
                if (((unsigned)h0 & (unsigned)w0)) continue;
            }
            continue; (void)((unsigned)!(i2 + *mp));
        } while (i0++ < 4u && ((unsigned)b0 + (unsigned)(0xb2b84675u < 0x80000000u)));
        l0 = (long)((unsigned long)l0 + (unsigned)c0);
        garr[0x10000u & 7u] = (unsigned)!(unsigned)((u3 >> (0xe7571734u & 31u)) && 9u);
    } else {
        if (a0[i0 & 3u]) {
            if (g0) goto L1;
            if (~(unsigned)((int)0xeea1bccu >= (int)((unsigned)x0 ^ (unsigned)w0))) goto L2;
            i2 = (-((unsigned)f0 % (a0[i0 & 3u] | 1u)) & (unsigned)(short)(unsigned)(a0[u1 & 3u] == (p1 % (i2 | 1u)))) & 15u;
            if (fuel) {
                x0 = x0 * 0x100000001b3ull + (unsigned)d0;
                goto L1;
                a0[(unsigned)(v0 == 0x8464dd82u) & 3u] = (0xffffffffu + (a0[u1 & 3u] / ((unsigned)((int)((unsigned)c0 * 0x7638a17du) >= (int)0x10000u) | 1u)));
            }
            g0 = ((a0[u1 & 3u] - (unsigned)x0) | (4u ? 2u : 0x7fffffffu));
        }
        a0[g1 & 3u] = 4u;
        goto L1;
        goto done;
    }
    if ((unsigned)(0xcfd43581u && (unsigned)((int)(unsigned)x0 >= (int)a0[i0 & 3u]))) {
        { unsigned t0; double z0; if (((unsigned)((unsigned)c0 && p0)) & 1u) { t0 = (0x864e0777u >> (4u & 31u)); z0 = (double)(((unsigned)(g0 && (0x2a756c21u ^ (unsigned)d0))) & 255u); } if (((unsigned)((unsigned)c0 && p0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            b0 = (0x7fffffffu | v0) != 0u;
            s1 = (int)((unsigned)s1 + 0xffffffffu);
            d0 = d0 * 0.5 + (double)((0x10000u * (unsigned)f0) & 1023u);
        }
        if ((0x42002ef2u & (*q0 + 0x10000u))) goto L2;
    }
    if (0x7fffffffu) {
        *q0 += (unsigned)c0;
        if ((unsigned)(unsigned char)(0x16e4ec5du | (0x5b2f2cd2u + p0))) goto L0;
        do { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)(i2 || (unsigned)b0);
            u3 = (unsigned)((short)p0 > (signed char)(0x7fffffffu / (0x7fffffffu | 1u)));
        } while (i0++ < 2u && g0);
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)h0, (unsigned)s1, ((g1 % (0x7fffffffu | 1u)) + 9u)); }
    } else {
        if (p0) {
            { unsigned t1; double z1; if (((unsigned)(w0 >> 29)) & 1u) { t1 = ~(unsigned)((short)u2 > (signed char)0x4c7313b5u); z1 = (double)(((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)s0)) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                w0 ^= (unsigned long long)((unsigned)(w0 >> 29) ^ u3) << (p2 & 63u);
                s1 = (int)((unsigned)s1 + (unsigned)(-(fuel * 0x10000u) || ((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)e0) * i2)));
            }
            L1: if (--fuel == 0u) goto done;
            L2: if (--fuel == 0u) goto done;
            goto L0;
            while ((-(unsigned)((short)garr[i1 & 7u] > (signed char)u0) ^ (unsigned)w0)) { if (--fuel == 0u) goto done;
                { unsigned t2; double z2; if (((unsigned)((short)1u > (signed char)a0[i0 & 3u])) & 1u) { t2 = (i0 / (-(unsigned)(0x10000u || 0xffffffffu) | 1u)); z2 = (double)(((unsigned)(*q0 || (9u ^ p2))) & 255u); } if (((unsigned)((short)1u > (signed char)a0[i0 & 3u])) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                    s0 = (int)(unsigned)((int)0x7fffffffu >= (int)p0);
                }
                garr[(unsigned)(fuel == (unsigned)f0) & 7u] = p0;
            }
        } else {
            if (budget != 0u) { budget -= 1u; u0 = fn2((r0.y / ((unsigned)l0 | 1u)), 0x4bfd4e77u, v0); }
            L3: if (--fuel == 0u) goto done;
            switch (((unsigned)s0 >> ((unsigned)((int)(unsigned)x0 >= (int)(unsigned)d0) & 31u)) & 7u) {
                while (i0++ < 3u && (r0.y * 0x10000u)) { if (--fuel == 0u) goto done;
                    u3 = ((unsigned)((int)3u < (int)r0.x) / ((unsigned)h1 | 1u));
                    if (0xffffffffu) break;
                    case 3u: ;
                    do { if (--fuel == 0u) goto done;
                        goto done;
                    } while (i1++ < 2u && (unsigned)b0);
                    r0.y ^= (unsigned)(garr[i1 & 7u] && (unsigned)h1);
                }
                v0 = (u1 * g0);
                s1 = (int)((unsigned)s1 + (garr[i1 & 7u] + ((u2 - 5u) / (i1 | 1u))));
                while (i0++ < 3u && i1) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(0x340cc413u + 0xe7832b28u) << (((*q0 ^ (unsigned)(i1 < 9u)) & ((unsigned)w0 + a0[i0 & 3u])) & 63u);
                    for (;;) { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)b0 & 0x10000u) < (int)(0x9493868fu ^ 6u)));
                        continue; (void)((unsigned)c0);
                        if ((unsigned)((unsigned)l0 < (unsigned)((int)g1 < (int)u0))) continue;
                    }
                    *q0 = (unsigned)((short)i0 > (signed char)a0[u1 & 3u]);
                    if (((garr[u2 & 7u] % (v0 | 1u)) >> (i1 & 31u))) goto L1;
                    s0 = (int)(0xffffffffu ? 0x80000000u : 0xffffffffu);
                }
                if ((1u << (3u & 31u))) goto L1;
            }
        }
        if (((unsigned)(w0 >> 29) ^ (unsigned)((unsigned)h1 == 0x10000u))) goto L0;
        if (~(0x17612786u % ((unsigned)((unsigned)h0 < 0x736d7908u) | 1u))) {
            L4: if (--fuel == 0u) goto done;
            g0 = (unsigned)(short)(unsigned)((unsigned)((unsigned)(short)((unsigned)e0 | (unsigned)d0) < *q0) && (9u / ((unsigned)l0 | 1u)));
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(((0x17fae3bu * (8u % (3u | 1u))) * (0x10000u | i2)) & 1023u);
                l0 = (long)((unsigned long)l0 + 0x9d784805u);
                *mp = (9u >> (((unsigned)(a0[i0 & 3u] < fuel) / ((unsigned)s1 | 1u)) & 31u));
            }
            if (u1) {
                *q0 += ((garr[i1 & 7u] % ((unsigned)w0 | 1u)) & (r0.y << (u0 & 31u)));
                d0 = d0 * 0.5 + (double)((0x7fffffffu << ((p2 % ((0x284e55b8u >> ((0x80000000u - (unsigned)l0) & 31u)) | 1u)) & 31u)) & 1023u);
            }
        }
    }
    x0 = x0 * 0x100000001b3ull + -(unsigned)(u1 && (unsigned)(signed char)(0x3bffd6c3u | (unsigned)((int)(garr[i1 & 7u] & (unsigned)w0) >= (int)u1)));
    if ((unsigned)(m0 && (unsigned)w0)) {
        goto L0;
        u1 += (v0 % (0x700f20e8u | 1u));
    } else {
        for (;;) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    u0 = 9u;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(signed char)((unsigned)x0 & a0[u1 & 3u]), (unsigned)(unsigned char)(unsigned)(g1 == u1), (0xffffffffu % ((unsigned)(x0 >> 70) | 1u))); }
                if ((unsigned)!((unsigned)e0 ^ (unsigned)((short)3u > (signed char)(unsigned)b0))) break;
                if (budget != 0u) { budget -= 1u; u3 = fn3(u2, (unsigned)(v0 && (*mp * i0)), (g1 * (0x80000000u - (unsigned)s1))); }
            } while (i1++ < 7u && (a0[u1 & 3u] - a0[i0 & 3u]));
            for (;;) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return ((unsigned)d0 + ((unsigned)c0 ^ 0x7fffffffu));
                m0 ^= (unsigned)(p1 < -((unsigned)((unsigned)(x0 >> 70) && p0) ^ g1));
            }
            if (((unsigned)(*mp == 0xffffffffu) / (0x1d9adf03u | 1u))) {
                v0 = (unsigned)(r0.y || (~(i1 % (p1 | 1u)) ? i2 : (unsigned)h0));
                *q0 = 7u;
                if ((unsigned)((int)(unsigned)((unsigned)c0 == r0.y) < (int)(unsigned)d0)) {
                    r0.x = r0.x;
                    l0 = (long)((unsigned long)l0 + ((8u % ((unsigned)c0 | 1u)) + i0));
                    *q0 = (unsigned)(short)(unsigned)(r0.x && (unsigned)((short)(unsigned)!(g0 & u3) > (signed char)0x10000u));
                    r0.x = 0x27bdd1e1u;
                }
            } else {
                if (((unsigned)h1 >> ((unsigned)((int)3u < (int)r0.x) & 31u))) {
                    h1 = (unsigned short)(h1 + fuel);
                    if ((unsigned)(unsigned char)(0x7fffffffu - u2)) break;
                    break; (void)((unsigned)((unsigned)(0x81345718u == (unsigned)s1) == i1));
                    break; (void)((g0 ? r0.x : (unsigned)(x0 >> 70)));
                    break; (void)((unsigned)((unsigned)c1 == (unsigned)(0xf00dc401u < g1)));
                    if (budget != 0u) { budget -= 1u; u2 = fn3(0xc78aa399u, (0x66fbbf88u ^ (m0 << (p1 & 31u))), -(unsigned)((i1 & 9u) == a0[u1 & 3u])); }
                } else {
                    continue; (void)(0x10000u);
                }
            }
            switch ((unsigned)s1 & 7u) {
                break; (void)(0x10000u);
                case 1u: ;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(p2 == *mp), (unsigned)w0, fuel); }
                l0 = (long)((unsigned long)l0 + (0xada21fd6u % ((i1 ^ g1) | 1u)));
            }
            while (i1++ < 3u && (unsigned)(unsigned char)(unsigned)((int)0xd6d06534u < (int)(unsigned)((int)0x80000000u >= (int)u1))) { if (--fuel == 0u) goto done;
                if (((unsigned)h0 - 0x10000u)) goto L0;
                s1 = (int)((unsigned)s1 + (unsigned)((short)0x7fffffffu > (signed char)(unsigned)(short)((unsigned)((unsigned)c1 == m0) / ((unsigned)h1 | 1u))));
            }
            v0 = 0xffffffffu;
        }
        i0 = (((unsigned)(0xe8102776u || p2) * (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)(w0 >> 29))) / (p1 | 1u)) & 15u;
        i2 = (unsigned)((int)garr[i1 & 7u] < (int)-(unsigned)(0x10000u == ((a0[i0 & 3u] + (unsigned)e0) ^ a0[i0 & 3u]))) & 15u;
    }
    r0.y ^= 0x80000000u;
    garr[(unsigned)(signed char)(unsigned)(3u && 0xf8a0ccd9u) & 7u] = ((*q0 ? 3u : 0x80000000u) % ((unsigned)e0 | 1u));
    if (0x24cc4c31u) goto L1;
    switch ((m0 * u1) & 7u) {
        case 7u: ;
    }
    d0 = d0 * 0.5 + (double)((-(garr[i1 & 7u] ^ (unsigned)l0) | (unsigned)e0) & 1023u);
    g1 += (unsigned)((unsigned)((short)i1 > (signed char)(unsigned)d0) && (unsigned)((int)((unsigned)l0 % ((unsigned)w0 | 1u)) >= (int)0xe61bf342u));
    e0 = e0 * 0.5L + (long double)((unsigned)!((unsigned)(x0 >> 70) ? fuel : 0x10000u) & 1023u);
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)f0 < (int)(unsigned)(0x1ee33634u < a0[u1 & 3u]))) break;
        v0 = *mp;
        u1 += (unsigned)(short)(unsigned)((unsigned)(w0 >> 29) && (unsigned)(0x10000u || 0xd00c6d75u));
        if (u3 == 7u) return r0.y;
        while (i1++ < 3u && ((unsigned)h0 * 0x93576cb8u)) { if (--fuel == 0u) goto done;
            g1 += (unsigned)((short)2u > (signed char)(unsigned)c1);
            switch ((0xad2da79cu * (1u % (r0.x | 1u))) & 7u) {
                if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)w0, (unsigned)(signed char)(unsigned)((unsigned)(short)(unsigned)(0xffffffffu < 0xcd60b2bbu) < a0[u1 & 3u]), (unsigned)w0); }
                if (i1) {
                    case 2u: ;
                    q0 = &garr[garr[i1 & 7u] & 7u];
                } else {
                    if (fuel < 8u) return ~(unsigned)(~(garr[i1 & 7u] + (unsigned)(0x4b565b8au || i1)) < 0xffffffffu);
                    m0 ^= (unsigned)e0;
                }
                case 6u: ;
                u1 ^= ~(unsigned)(0x80000000u == ((unsigned)h0 | 5u));
            }
            w0 = w0 * 6364136223846793005ull + (unsigned)(g0 == (unsigned)(short)((v0 + i0) >> ((unsigned)((short)(unsigned)w0 > (signed char)8u) & 31u)));
            e0 = e0 * 0.5L + (long double)((g1 & (unsigned)((int)(unsigned)(short)(unsigned)((int)g1 < (int)(unsigned)(0xff35ed9u < m0)) < (int)fuel)) & 1023u);
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((a0[i0 & 3u] + (unsigned)(w0 >> 29))) break;
                f0 = f0 * 0.5f + (float)((1u | (unsigned)(unsigned char)(i0 * i1)) & 255u);
                if (budget != 0u) { budget -= 1u; u0 = fn1(u0, (p1 - (unsigned)((int)(unsigned)b0 < (int)0xb2c97c8du)), ((unsigned)((int)(unsigned)w0 < (int)(unsigned)f0) - u0)); }
                q0 = &garr[(unsigned)((short)((unsigned)e0 << ((unsigned)(w0 >> 29) & 31u)) > (signed char)(unsigned)(garr[u2 & 7u] == 0xd51cb3fbu)) & 7u];
                if (0xaa17bf10u) {
                    h1 = (unsigned short)(h1 + u1);
                    while (i0++ < 7u && (unsigned)(signed char)(unsigned)((int)p1 < (int)(u2 ^ 3u))) { if (--fuel == 0u) goto done;
                        u2 = (0xbe93620du | (unsigned)((short)i0 > (signed char)u2));
                        h1 = (unsigned short)(h1 + ((unsigned)(0x10000u && 0u) ^ (2u >> (1u & 31u))));
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)g0 > (signed char)0x80000000u), (unsigned)((unsigned)(unsigned char)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)i0) < a0[i0 & 3u]), (fuel >> ((unsigned)((int)(unsigned)h0 < (int)(unsigned)h0) & 31u))); }
                        if ((u0 / ((unsigned)((int)p1 < (int)m0) | 1u))) break;
                    }
                    if ((unsigned)(r0.x && 0x4854fb06u)) break;
                }
            }
            while (i2++ < 2u && (unsigned)c1) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)-(unsigned)((g1 & g1) || garr[u2 & 7u]);
                if ((unsigned)(0xb44df7e3u || (p0 + p2))) {
                    m0 ^= (((unsigned)((int)((unsigned)(w0 >> 29) >> (*mp & 31u)) < (int)(unsigned)x0) * 9u) ^ 4u);
                    if (((garr[i1 & 7u] - (unsigned)(w0 >> 29)) / (a0[i0 & 3u] | 1u))) continue;
                    a0[(garr[i1 & 7u] % (u1 | 1u)) & 3u] = ~((unsigned)(x0 >> 70) - (fuel ^ a0[i0 & 3u]));
                    if ((unsigned)(fuel || (unsigned)((int)(unsigned)x0 < (int)0x60be0364u))) continue;
                    if ((unsigned)(signed char)((unsigned)((int)(unsigned)s0 < (int)m0) / ((unsigned)(w0 >> 29) | 1u))) {
                        d0 = d0 * 0.5 + (double)((((a0[i0 & 3u] ^ garr[u2 & 7u]) | p1) * m0) & 1023u);
                        q0 = &garr[g1 & 7u];
                    } else {
                        e0 = e0 * 0.5L + (long double)(((0x80000000u / ((a0[i0 & 3u] | (unsigned)h0) | 1u)) & (a0[u1 & 3u] - (unsigned)c0)) & 1023u);
                        if (fuel < 8u) return (0x10000u / (0x79588e91u | 1u));
                        c1 = (signed char)(unsigned)(short)(unsigned)(0xffffffffu && (garr[u2 & 7u] * ((unsigned)b0 * (unsigned)h0)));
                    }
                    break; (void)((u0 * i0));
                } else {
                    if (budget != 0u) { budget -= 1u; u0 = fn1(9u, (unsigned)s1, ((unsigned)c1 & (unsigned)c0)); }
                    if (((unsigned)(0xffffffffu == (unsigned)(w0 >> 29)) - (unsigned)(x0 >> 70))) break;
                    if (budget != 0u) { budget -= 1u; u0 = fn3(g1, (u0 ^ g0), (unsigned)c0); }
                }
                b0 = (unsigned)((int)(unsigned)!(0x7fffffffu >> (u0 & 31u)) < (int)(i2 - 2u)) != 0u;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(0x42af877eu == garr[i1 & 7u]), (unsigned)(u0 || u0), (unsigned)(signed char)(u0 / (0x10000u | 1u))); }
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn2(((5u >> (5u & 31u)) * (unsigned)w0), (unsigned)(0x6fb0c488u || u2), ((unsigned)c0 >> (i2 & 31u))); }
    }
    goto L1;
    u0 = (unsigned)(signed char)((unsigned)(signed char)((unsigned)s0 * garr[i1 & 7u]) * 0x4d8d8250u);
    switch ((unsigned)s0 & 7u) {
        *q0 = (((unsigned)x0 ^ -(unsigned)((int)g1 >= (int)garr[i1 & 7u])) >> ((*mp % (i2 | 1u)) & 31u));
        switch ((0x80000000u & garr[u2 & 7u]) & 7u) {
            c0 = (unsigned char)(unsigned)((int)(unsigned)c1 < (int)(garr[i1 & 7u] - 0x7fffffffu));
        }
    }
    if (fuel < 8u) return (unsigned)((int)i1 < (int)(a0[u1 & 3u] << (u0 & 31u)));
    b0 = (r0.x % ((unsigned)!(((unsigned)d0 / (p1 | 1u)) + 7u) | 1u)) != 0u;
    i0 = (unsigned)((unsigned)f0 && ((unsigned)c1 & (unsigned)(5u && i2))) & 15u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 11u, 0x52d0cb90u, 0x2e06a672u },
        { 12u, 0xc78f2f2eu, 0x1fc1374fu },
        { 4u, 0x24d3b59fu, 0xea85ddbcu },
        { 0u, 0x6c95e12cu, 0xee387763u },
        { 2u, 0x9d952f2au, 0xa54eeb27u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
