// test-ssa-source's program of seed 141000431 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x6471c4f1u, g1 = 0xddeef870u;
static unsigned garr[8] = { 0x54aaab2bu, 0x147e0158u, 0x3dc52db2u, 0x3e0560c3u, 0xb61fce3cu, 0xc5886162u, 0x6ab9c373u, 0x317dd302u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L0;
    { unsigned t0; double z0; if ((p2) & 1u) { t0 = (unsigned)c1; z0 = (double)(((unsigned)((int)r0.y >= (int)(unsigned)(0x7fffffffu && (unsigned)(x0 >> 70)))) & 255u); } if ((p2) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        L0: if (--fuel == 0u) goto done;
    }
    L1: if (--fuel == 0u) goto done;
    while ((unsigned)s1) { if (--fuel == 0u) goto done;
        while (i1++ < 6u && (unsigned)(signed char)((unsigned)(p2 < p2) + 0xf19cf1a5u)) { if (--fuel == 0u) goto done;
            if (((unsigned)s0 & (unsigned)c1)) {
                L2: if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if (((unsigned)c0) & 1u) { t1 = (unsigned)(short)(u3 | ((unsigned)(x0 >> 70) * 0x80000000u)); z1 = (double)((i2) & 255u); } if (((unsigned)c0) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                    u1 = (unsigned)((g1 * (unsigned)(short)(0x7fffffffu + fuel)) || 0x7fffffffu);
                    b0 = 9u != 0u;
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        *q0 += p0;
                        r0.x = (unsigned)(0x10000u || r0.y);
                        c0 = (unsigned char)(unsigned)((int)m0 < (int)-(unsigned)((unsigned)(signed char)(unsigned)(*mp || u0) || (8u * garr[i1 & 7u])));
                    }
                    u0 += i1;
                    L3: if (--fuel == 0u) goto done;
                }
                break; (void)(5u);
            } else {
                switch ((unsigned)s0 & 7u) {
                    case 7u: ;
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        L4: if (--fuel == 0u) goto done;
                        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                            garr[u1 & 7u] = (unsigned)((int)(((a0[u1 & 3u] | g0) / ((unsigned)d0 | 1u)) / ((unsigned)w0 | 1u)) >= (int)(unsigned)x0);
                            if (fuel < 8u) return ((unsigned)d0 ^ (unsigned)c0);
                        }
                        c1 = (signed char)(5u ^ (unsigned)((int)g1 < (int)0x80000000u));
                        do { if (--fuel == 0u) goto done;
                            garr[(*q0 | u2) & 7u] = (unsigned)((int)*mp >= (int)(unsigned)b0);
                        } while (i0++ < 5u && a0[u1 & 3u]);
                    }
                }
                a0[(garr[u2 & 7u] | 0x7fffffffu) & 3u] = (0xffffffffu << ((unsigned)(0xc3c12ae8u == (garr[i1 & 7u] / ((unsigned)c1 | 1u))) & 31u));
            }
            { unsigned t2; double z2; if ((i0) & 1u) { t2 = (unsigned)(2u && (unsigned)c1); z2 = (double)(((unsigned)(w0 >> 29)) & 255u); } if ((i0) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                r0.y ^= (unsigned)(short)(((unsigned)c1 - g1) >> ((unsigned)(g1 == (unsigned)l0) & 31u));
                if ((0x80000000u ^ ((unsigned)(w0 >> 29) - i1))) break;
                if (p2) goto L2;
                *q0 += (unsigned)((int)((i1 ^ i1) / ((unsigned)b0 | 1u)) >= (int)((unsigned)c0 * fuel));
                if (i2) break;
                if (((unsigned)(x0 >> 70) % ((u1 << ((unsigned)s1 & 31u)) | 1u))) break;
            }
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(((*q0 - 4u) % ((garr[u2 & 7u] ^ (unsigned)f0) | 1u)) & 1023u);
                r0.y ^= (unsigned)(unsigned char)((unsigned)(i2 || (unsigned)s1) & p1);
                if ((unsigned)(short)(fuel << ((unsigned)b0 & 31u))) break;
                r0.y ^= ~(unsigned)((int)(unsigned)!(9u + 0xc53c0673u) < (int)(unsigned)((short)(unsigned)c1 > (signed char)i0));
                do { if (--fuel == 0u) goto done;
                    break; (void)((6u ^ (p2 / (0x7fffffffu | 1u))));
                    break; (void)((9u / ((u3 | a0[u1 & 3u]) | 1u)));
                    x0 = x0 * 0x100000001b3ull + (((unsigned)x0 << (0u & 31u)) & (unsigned)((int)(unsigned)(unsigned char)(unsigned)((int)(unsigned)s0 >= (int)(unsigned)h0) < (int)a0[i0 & 3u]));
                    if (1u) break;
                    l0 = (long)((unsigned long)l0 + ((unsigned)c1 ? (unsigned)s0 : 1u));
                    *mp = (unsigned)(short)((unsigned)((int)(unsigned)c1 < (int)(unsigned)(x0 >> 70)) & (unsigned)c1);
                } while (i0++ < 6u && (unsigned)(0x7fffffffu < (unsigned)(signed char)((unsigned)e0 * r0.x)));
                b0 = ~(a0[i0 & 3u] | (u3 + 9u)) != 0u;
            }
            { unsigned t3; double z3; if (((unsigned)((unsigned)h0 || (unsigned)((int)g1 < (int)(unsigned)c0))) & 1u) { t3 = (0x7fffffffu >> (0x858cc925u & 31u)); z3 = (double)(((unsigned)((short)(unsigned)d0 > (signed char)garr[i1 & 7u])) & 255u); } if (((unsigned)((unsigned)h0 || (unsigned)((int)g1 < (int)(unsigned)c0))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                *q0 += (unsigned)((unsigned)c0 < (unsigned)((unsigned)(x0 >> 70) < (unsigned)c0));
                b0 = 0xbf3ab948u != 0u;
                goto L2;
                continue; (void)((unsigned)((int)u1 >= (int)(unsigned)b0));
                { unsigned t4; double z4; if (((r0.y | ((unsigned)l0 % (i0 | 1u)))) & 1u) { t4 = ((unsigned)c1 & g1); z4 = (double)((((p0 - (unsigned)(w0 >> 29)) * (unsigned)(w0 >> 29))) & 255u); } if (((r0.y | ((unsigned)l0 % (i0 | 1u)))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    x0 = x0 * 0x100000001b3ull + ((unsigned)((int)i2 >= (int)(unsigned)(short)(8u + (unsigned)f0)) / ((unsigned)((short)0xffffffffu > (signed char)i0) | 1u));
                    break; (void)(0xffffffffu);
                    r0.y ^= ((unsigned)s0 % ((*mp | (unsigned)(w0 >> 29)) | 1u));
                }
                *mp = *mp;
            }
        }
        l0 = (long)((unsigned long)l0 + ((unsigned)(x0 >> 70) ^ (unsigned)h1));
        s0 = (int)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)1u);
        { unsigned t5; double z5; if (((unsigned)((int)i0 < (int)0xd00647bcu)) & 1u) { t5 = (0x7fffffffu % (u3 | 1u)); z5 = (double)((m0) & 255u); } if (((unsigned)((int)i0 < (int)0xd00647bcu)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            { unsigned t6; double z6; if ((((unsigned)(signed char)(unsigned)((int)u0 < (int)r0.x) * u3)) & 1u) { t6 = (g1 * ((unsigned)e0 + u0)); z6 = (double)((((1u >> ((unsigned)d0 & 31u)) + a0[u1 & 3u])) & 255u); } if ((((unsigned)(signed char)(unsigned)((int)u0 < (int)r0.x) * u3)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                c0 = (unsigned char)i2;
                if (u3 == 7u) return (9u ^ 0x730c0035u);
                w0 ^= (unsigned long long)(unsigned)(x0 >> 70) << (((0x80000000u * 0x10000u) / ((((unsigned)b0 ^ 0xf3891ba4u) & 0x80000000u) | 1u)) & 63u);
            }
            f0 = f0 * 0.5f + (float)((unsigned)(u3 && (unsigned)h1) & 255u);
            h1 = (unsigned short)(h1 + (unsigned)w0);
            i2 = (unsigned)(9u == (unsigned)((short)0xffffffffu > (signed char)0x7fffffffu)) & 15u;
            if (p0) continue;
            break; (void)((unsigned)l0);
        }
        if ((5u + a0[u1 & 3u])) continue;
    }
    garr[(unsigned)e0 & 7u] = ((unsigned)(unsigned char)(2u * (unsigned)((unsigned)c0 < ((unsigned)d0 >> (p2 & 31u)))) / (fuel | 1u));
    switch ((unsigned)((int)(v0 + 0xb309761cu) >= (int)(unsigned)b0) & 7u) {
        i0 = ((unsigned)s1 - (unsigned)((int)7u >= (int)(i2 + u0))) & 15u;
        r0.y ^= (u3 - (unsigned)((int)5u >= (int)(unsigned)b0));
        if ((unsigned)d0) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 7u: ;
                l0 = (long)((unsigned long)l0 + (0x7fffffffu - ((unsigned)h1 ? 0x80000000u : 3u)));
                l0 = (long)((unsigned long)l0 + (unsigned)(short)(unsigned)((int)(0u - (unsigned)s1) < (int)u0));
            }
            case 2u: ;
        }
        for (;;) { if (--fuel == 0u) goto done;
            if (((unsigned)c0 ? p1 : 0x43c7daa5u)) break;
            b0 = (~(unsigned)(a0[u1 & 3u] || (6u / (0x10000u | 1u))) | -(unsigned)((short)(unsigned)w0 > (signed char)r0.x)) != 0u;
            q0 = &garr[(unsigned)((int)(0x86d5ccc9u % ((unsigned)l0 | 1u)) < (int)(v0 + (g1 | 0xfa8d933bu))) & 7u];
            default: ;
            if (0xe858379du) {
                do { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (unsigned)((m0 + v0) || (p2 % (0x9bc9395u | 1u)));
                    if ((unsigned)((short)g0 > (signed char)i1)) break;
                    if ((unsigned)(unsigned char)(unsigned)((int)u3 >= (int)(g0 + 0x90d88053u))) continue;
                    if (fuel < 8u) return -(unsigned)((unsigned)h0 && fuel);
                } while (i1++ < 2u && (unsigned)(~(u3 * 0xd4af625bu) == (unsigned)h1));
                m0 ^= (m0 & (unsigned)((g1 - (unsigned)((short)(unsigned)h0 > (signed char)0x80000000u)) == p0));
                v0 = ((unsigned)(*mp && (unsigned)((int)u2 < (int)0x436329f1u)) >> ((unsigned)((short)g0 > (signed char)r0.y) & 31u));
            }
        }
        w0 = w0 * 6364136223846793005ull + (p2 | u2);
    }
    goto done;
    goto L0;
    if ((4u | g0)) goto done;
    r0.x = (0xffffffffu / ((unsigned)(short)(unsigned)(0xc90c031fu && u3) | 1u));
    if (((v0 + 0xfb14e53u) - 0xac3ec27du)) goto L1;
    a0[(garr[u2 & 7u] * m0) & 3u] = (unsigned)((unsigned)x0 && m0);
    garr[-(0x80000000u - a0[i0 & 3u]) & 7u] = ((unsigned)l0 / (-(unsigned)(g0 == r0.x) | 1u));
    c0 = (unsigned char)((0u * 1u) - ((garr[u2 & 7u] | p0) ^ (unsigned)f0));
    u3 = (unsigned)((6u ^ 0x85a76e97u) || (unsigned)!(unsigned)(0x80000000u < (6u % ((unsigned)h1 | 1u))));
    w0 ^= (unsigned long long)r0.x << ((((i2 % (0xffffffffu | 1u)) ? *q0 : (unsigned)f0) ^ v0) & 63u);
    v0 = (unsigned)((unsigned)f0 || p2);
    if (-(u3 & a0[u1 & 3u])) goto L1;
    if (((unsigned)b0 | (unsigned)(short)(4u % ((unsigned)c1 | 1u)))) goto L0;
    garr[(unsigned)(v0 == i2) & 7u] = ((i1 & (unsigned)h0) / (*q0 | 1u));
    if (u3) {
        while (i0++ < 6u && 0x34623dd5u) { if (--fuel == 0u) goto done;
            i0 = (unsigned)((int)v0 >= (int)g1) & 15u;
            garr[(unsigned)(m0 < r0.y) & 7u] = (unsigned)(unsigned char)((unsigned)(short)((i1 ? m0 : 0x7fffffffu) ^ i1) % (p0 | 1u));
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                goto L1;
                { unsigned t7; double z7; if (((unsigned)(short)((unsigned)(w0 >> 29) ^ ~(u1 - 0x17bfc5c2u))) & 1u) { t7 = (garr[u2 & 7u] << ((*q0 & p0) & 31u)); z7 = (double)(((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)l0)) & 255u); } if (((unsigned)(short)((unsigned)(w0 >> 29) ^ ~(u1 - 0x17bfc5c2u))) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                    if (0x8f62a4efu) break;
                    v0 = 6u;
                    continue; (void)(((unsigned)e0 % ((garr[u2 & 7u] >> (garr[u2 & 7u] & 31u)) | 1u)));
                    if ((unsigned)(x0 >> 70)) goto L3;
                    g1 += ((0xebc78a5au << (1u & 31u)) / (((unsigned)e0 & i1) | 1u));
                }
                do { if (--fuel == 0u) goto done;
                    if (p2) break;
                    v0 = (unsigned)((int)(unsigned)h0 < (int)(g1 >> ((r0.x & (unsigned)l0) & 31u)));
                    c0 = (unsigned char)(unsigned)((unsigned)(w0 >> 29) < (garr[u2 & 7u] << (((unsigned)s1 & m0) & 31u)));
                } while (i2++ < 5u && (garr[u2 & 7u] * (unsigned)(x0 >> 70)));
                if ((unsigned)((unsigned)(7u || 5u) && 0xf18acd6eu)) goto L1;
                goto L3;
                if (*q0) goto L3;
            }
            u2 = 0x80000000u;
            break; (void)(((unsigned)h1 + (0x10000u ^ p0)));
            if ((unsigned)((int)r0.x < (int)(g1 << (g0 & 31u)))) break;
        }
    }
    if ((0x7fffffffu ^ u1)) {
        g0 = (unsigned)f0;
        goto L1;
    } else {
        if (0xffffffffu) goto L3;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)((int)(unsigned)w0 >= (int)(u0 ^ 0xcde4c9c1u))) goto L0;
    if (p0) goto L4;
    if (((unsigned)c0 * (unsigned)((int)garr[i1 & 7u] < (int)0xfa278264u))) {
        if ((0x80000000u >> (0x80000000u & 31u))) goto L4;
        l0 = (long)((unsigned long)l0 + ((unsigned)((int)(((unsigned)h0 & r0.x) / (a0[i0 & 3u] | 1u)) >= (int)0x6e5a598au) | (unsigned)w0));
        u1 ^= g0;
    } else {
        q0 = &garr[(unsigned)(garr[i1 & 7u] && u2) & 7u];
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            goto L3;
            if ((0x7fffffffu % ((garr[i1 & 7u] % (v0 | 1u)) | 1u))) break;
            d0 = d0 * 0.5 + (double)((unsigned)s0 & 1023u);
        }
        while ((unsigned)!(unsigned)((short)0x7fffffffu > (signed char)((unsigned)h0 - p1))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((unsigned)c0 < ~(0x7fffffffu | u0)), (unsigned)l0, (garr[i1 & 7u] << (4u & 31u))); }
        }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            b0 = ~((unsigned)c0 << (((garr[i1 & 7u] ^ g0) >> (i0 & 31u)) & 31u)) != 0u;
        }
    }
    do { if (--fuel == 0u) goto done;
        h0 = (short)((unsigned)l0 | 0x8426b4ecu);
        c0 = (unsigned char)(unsigned)((unsigned)c0 < (unsigned)((unsigned)f0 && (unsigned)x0));
        q0 = &garr[(unsigned)((short)(unsigned)(short)(*mp & a0[i0 & 3u]) > (signed char)((unsigned)(w0 >> 29) ? 2u : (unsigned)x0)) & 7u];
    } while (i0++ < 6u && u0);
    switch (-(p0 + p1) & 7u) {
        q0 = &garr[(unsigned)!((0xa222a7ceu >> (1u & 31u)) | (0x80000000u << ((unsigned)((int)garr[u2 & 7u] >= (int)m0) & 31u))) & 7u];
        q0 = &garr[((unsigned)((short)(unsigned)x0 > (signed char)((unsigned)l0 * (unsigned)e0)) * (unsigned)((short)u2 > (signed char)(unsigned)w0)) & 7u];
        goto done;
        L0: if (--fuel == 0u) goto done;
        { unsigned t0; double z0; if (((u3 | i0)) & 1u) { t0 = (unsigned)(g0 == 0x7fffffffu); z0 = (double)(((garr[u2 & 7u] ^ garr[u2 & 7u])) & 255u); } if (((u3 | i0)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            L1: if (--fuel == 0u) goto done;
            if ((unsigned)c1) {
                break; (void)((unsigned)((short)i2 > (signed char)0x749e8a66u));
                if (budget != 0u) { budget -= 1u; u3 = fn0(6u, 0x80000000u, (r0.y + (unsigned)c0)); }
                if (0xffffffffu) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0((1u - 4u), (unsigned)w0, p2); }
            } else {
                garr[(unsigned)((int)0xffffffffu < (int)u2) & 7u] = (g0 - (unsigned)(r0.y == 0x855bf84eu));
            }
        }
    }
    L2: if (--fuel == 0u) goto done;
    if ((0x80000000u & (unsigned)x0)) goto L2;
    h0 = (short)6u;
    if ((a0[u1 & 3u] << ((0x362982a8u - a0[i0 & 3u]) & 31u))) {
        if ((u2 % ((unsigned)c0 | 1u))) {
            if (p0) goto L3;
        }
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(short)(a0[u1 & 3u] | v0) && garr[u2 & 7u]), (g1 % ((unsigned)w0 | 1u)), ((unsigned)((short)0x80000000u > (signed char)i0) | 0xefd64cf7u)); }
        }
        g0 = (unsigned)((int)(unsigned)d0 >= (int)(unsigned)e0);
        L3: if (--fuel == 0u) goto done;
        g1 += -(unsigned)((int)0x80000000u < (int)u1);
    }
    { unsigned t1; double z1; if ((p2) & 1u) { t1 = ((0xffffffffu - garr[i1 & 7u]) & v0); z1 = (double)(((u2 ^ r0.x)) & 255u); } if ((p2) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        while (i0++ < 7u && (unsigned)(0x7f2cc575u < (unsigned)x0)) { if (--fuel == 0u) goto done;
            if (((v0 | (unsigned)w0) - a0[u1 & 3u])) break;
        }
        if ((unsigned)(signed char)(unsigned)((unsigned)e0 == (unsigned)e0)) goto L2;
        { unsigned t2; double z2; if (((unsigned)(u3 == (*mp << (i1 & 31u)))) & 1u) { t2 = (r0.x ? (unsigned)f0 : fuel); z2 = (double)((0x7fffffffu) & 255u); } if (((unsigned)(u3 == (*mp << (i1 & 31u)))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            *mp = ((0x7fffffffu - 0x80000000u) >> ((0x2aad0846u & (unsigned)c1) & 31u));
            do { if (--fuel == 0u) goto done;
                q0 = &garr[r0.y & 7u];
            } while (i0++ < 3u && (0x686011c6u >> (1u & 31u)));
            { unsigned t3; double z3; if ((0xffffffffu) & 1u) { t3 = ((unsigned)w0 / (((unsigned)s1 | 0x4b0410a8u) | 1u)); z3 = (double)(((*q0 / ((unsigned)s1 | 1u))) & 255u); } if ((0xffffffffu) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                if (budget != 0u) { budget -= 1u; u3 = fn0((m0 / (i0 | 1u)), (unsigned)c1, (u2 - u3)); }
                goto L1;
                if ((p1 >> (3u & 31u))) goto L2;
                while (*q0) { if (--fuel == 0u) goto done;
                    v0 = ((unsigned)(x0 >> 70) << ((0xbf3b2163u / (*mp | 1u)) & 31u));
                    a0[(unsigned)((int)(unsigned)s1 < (int)0xffffffffu) & 3u] = (unsigned)(unsigned char)(9u ^ i0);
                    if (budget != 0u) { budget -= 1u; u1 = fn0(-(u1 | (r0.y * 0x4a42423u)), (-(unsigned)(0u < (unsigned)d0) >> (0x7fffffffu & 31u)), m0); }
                    while (i1++ < 5u && 0x7fffffffu) { if (--fuel == 0u) goto done;
                        break; (void)(6u);
                        u3 += (0u & (unsigned)((short)(unsigned)((int)*q0 >= (int)(unsigned)(w0 >> 29)) > (signed char)garr[i1 & 7u]));
                    }
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        u0 ^= (((unsigned)s1 - (((unsigned)s0 % (0x1a7157b0u | 1u)) | garr[i1 & 7u])) % ((unsigned)s0 | 1u));
                        if ((unsigned)(0x10000u || 0xffffffffu)) break;
                    }
                    u2 = (((u2 & r0.y) + (unsigned)s0) * garr[u2 & 7u]);
                }
                if ((unsigned)(i1 == u2)) goto L0;
                if ((unsigned)(p2 && (unsigned)w0)) {
                    if (budget != 0u) { budget -= 1u; u0 = fn0(a0[i0 & 3u], (unsigned)((unsigned)((int)(unsigned)x0 < (int)a0[i0 & 3u]) == (unsigned)(x0 >> 70)), (unsigned)((short)p0 > (signed char)(unsigned)x0)); }
                    u0 ^= (unsigned)(i1 || i2);
                    i0 = (unsigned)b0 & 15u;
                } else {
                    if ((-(0x24555b5bu - m0) >> (u2 & 31u))) goto L1;
                    switch ((unsigned)((unsigned)h1 && (unsigned)f0) & 7u) {
                        w0 ^= (unsigned long long)p2 << ((unsigned)((short)((unsigned)((int)0xffffffffu < (int)(unsigned)e0) * 7u) > (signed char)(fuel * u2)) & 63u);
                        if (budget != 0u) { budget -= 1u; u1 = fn0((g0 << (0x7fffffffu & 31u)), i0, (unsigned)h0); }
                        garr[0x23667f0bu & 7u] = ((u3 % (r0.y | 1u)) | r0.y);
                        w0 = w0 * 6364136223846793005ull + ((unsigned)c0 ? (unsigned)d0 : (unsigned)(w0 >> 29));
                        if (((unsigned)((unsigned)w0 == (unsigned)(x0 >> 70)) * 0x10000u)) break;
                        if (~((*mp ^ 0x7fffffffu) + 0x18b9285du)) break;
                    }
                }
            }
        }
        if ((unsigned)((unsigned)(w0 >> 29) < (u1 % (g1 | 1u)))) {
            if (budget != 0u) { budget -= 1u; u3 = fn0(r0.y, (unsigned)h0, *mp); }
            goto L1;
            if (u2) goto L0;
        }
        if (((unsigned)s0 << ((0x80000000u ^ garr[i1 & 7u]) & 31u))) goto L2;
    }
    goto L3;
    if (budget != 0u) { budget -= 1u; u3 = fn0((4u >> ((u1 >> (fuel & 31u)) & 31u)), (unsigned)((short)(unsigned)b0 > (signed char)m0), (unsigned)c0); }
    m0 ^= ((unsigned)(w0 >> 29) << ((unsigned)(0x2594a2d9u < 4u) & 31u));
    { unsigned t4; double z4; if ((garr[u2 & 7u]) & 1u) { t4 = (unsigned)c1; z4 = (double)((((unsigned)h0 * (unsigned)((int)i0 >= (int)0x191ce175u))) & 255u); } if ((garr[u2 & 7u]) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        { unsigned t5; double z5; if (((0xcc3c43dau * (unsigned)s1)) & 1u) { t5 = ((unsigned)b0 ^ 8u); z5 = (double)(((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)w0)) & 255u); } if (((0xcc3c43dau * (unsigned)s1)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            if ((unsigned)((int)~(unsigned)(g1 && 0x80000000u) >= (int)garr[i1 & 7u])) goto L3;
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                switch ((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)(x0 >> 70)) & 7u) {
                    { unsigned t6; double z6; if (((0xffffffffu * (unsigned)w0)) & 1u) { t6 = 0x10000u; z6 = (double)(((0xd468a994u >> (0x80000000u & 31u))) & 255u); } if (((0xffffffffu * (unsigned)w0)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                        case 7u: ;
                        L4: if (--fuel == 0u) goto done;
                        u3 ^= (unsigned)(u1 == (unsigned)x0);
                        if (budget != 0u) { budget -= 1u; u0 = fn0(p0, ((unsigned)c0 ? *q0 : *mp), ((unsigned)f0 ? u3 : g1)); }
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0xafd4a8dbu / (0x10000u | 1u)), (unsigned)(short)((unsigned)x0 | ((unsigned)l0 << (0xaf5ed72du & 31u))), (5u >> ((g1 / (3u | 1u)) & 31u))); }
                    h0 = (short)(unsigned)h0;
                    continue; (void)((unsigned)((unsigned)(signed char)(1u / (p0 | 1u)) < (unsigned)e0));
                    case 3u: ;
                }
                break; (void)((unsigned)(0x667d1f61u || (unsigned)b0));
                if ((unsigned)((unsigned)h1 && u3)) goto done;
                r0.x = ((unsigned)b0 ^ (unsigned)d0);
                r0.y ^= *mp;
            }
        }
        if ((unsigned)!(unsigned)((int)6u < (int)((unsigned)h0 | 6u))) goto L2;
        goto L2;
        switch ((r0.y / (4u | 1u)) & 7u) {
            *mp = (unsigned)((int)(unsigned)e0 < (int)(unsigned)((int)(unsigned)((short)6u > (signed char)p2) < (int)(unsigned)((unsigned)c1 < (unsigned)l0)));
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)d0 > (signed char)m0), (garr[i1 & 7u] & (unsigned)b0), 0xffffffffu); }
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)fuel < (int)(unsigned)((int)r0.y < (int)((unsigned)(5u && r0.x) ^ 7u)));
            h1 = (unsigned short)(h1 + (fuel | a0[u1 & 3u]));
            v0 = (i0 ^ (a0[i0 & 3u] & u3));
            h0 = (short)(unsigned)((unsigned)s0 && r0.x);
        }
        goto L2;
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)s1 ^ ((unsigned)w0 | 3u))) break;
        }
    }
    l0 = (long)((unsigned long)l0 + ((fuel / ((unsigned)((unsigned)(unsigned char)((unsigned)c1 - u0) == (unsigned)w0) | 1u)) & p1));
    if ((unsigned)(short)(unsigned)(0xf0280ed5u == (u2 & i0))) goto done;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)(9u ^ ((unsigned)(i2 || *q0) + 0x7fffffffu));
        switch ((*mp / ((unsigned)!(a0[u1 & 3u] << (0x80000000u & 31u)) | 1u)) & 7u) {
            if (-(p1 % (i1 | 1u))) {
                m0 ^= (unsigned)((int)(unsigned)((unsigned)s1 && 0x97a549eau) < (int)garr[i1 & 7u]);
                case 5u: ;
            }
            if ((unsigned)!(unsigned)((int)(unsigned)(unsigned char)(0x9e9511fu ^ garr[i1 & 7u]) < (int)9u)) goto L1;
        }
        m0 ^= u1;
        if (fuel) {
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)!(g1 ^ r0.y)) continue;
                switch ((unsigned)((int)u2 < (int)p0) & 7u) {
                    case 3u: ;
                }
                g0 = (r0.x | g0);
                switch (((unsigned)b0 << (0x10000u & 31u)) & 7u) {
                    break; (void)(((unsigned)((int)i2 >= (int)v0) & (unsigned)b0));
                    if ((unsigned)((int)0x10000u >= (int)(unsigned)((short)p2 > (signed char)0x67016a24u))) goto L1;
                    if (((unsigned)h1 - 0x80000000u)) continue;
                    r0.x = (unsigned)!((unsigned)(0xbcc88703u < 0x10000u) ^ ((unsigned)h1 >> (0x80000000u & 31u)));
                    r0.y ^= (unsigned)(short)(unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)((int)(unsigned)((unsigned)((int)0x7fffffffu >= (int)p2) || garr[u2 & 7u]) < (int)0x10000u));
                }
                h0 = (short)(unsigned)((g1 % ((fuel + 0x7fffffffu) | 1u)) || 3u);
                c0 = (unsigned char)(3u ^ v0);
            }
            g1 += (unsigned)(*mp && (0x110f8db4u >> (*mp & 31u)));
            if (g0) break;
            if ((unsigned)x0) continue;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)c0 >> ((unsigned)w0 & 31u)), (unsigned)b0, ((unsigned)x0 / (p1 | 1u))); }
        } else {
            switch (((unsigned)(0xffffffffu == u2) - 0x80000000u) & 7u) {
                { unsigned t7; double z7; if (((unsigned)(0x7fffffffu < ((unsigned)(x0 >> 70) + (unsigned)h0))) & 1u) { t7 = 0xf87eb6b6u; z7 = (double)((garr[i1 & 7u]) & 255u); } if (((unsigned)(0x7fffffffu < ((unsigned)(x0 >> 70) + (unsigned)h0))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                    if (0xb5c1075u) goto L0;
                    b0 = -(unsigned)((unsigned)(unsigned char)((unsigned)s0 ^ r0.x) && u3) != 0u;
                    c1 = (signed char)1u;
                    if (((unsigned)l0 & (unsigned)((short)(unsigned)c1 > (signed char)0x7fffffffu))) break;
                }
                u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)((int)6u >= (int)(0x7fffffffu << ((unsigned)d0 & 31u))) && (unsigned)h1);
                f0 = f0 * 0.5f + (float)((garr[u2 & 7u] >> ((*q0 ^ r0.y) & 31u)) & 255u);
                v0 = 0x10000u;
            }
            w0 ^= (unsigned long long)(unsigned)s1 << (4u & 63u);
            break; (void)((unsigned)(unsigned char)(unsigned)((short)garr[u2 & 7u] > (signed char)(0xfdabae55u ^ (unsigned)h1)));
        }
    }
    if ((unsigned)((int)(unsigned)(unsigned char)(unsigned)((int)i2 >= (int)(unsigned)h1) < (int)1u)) goto L2;
    r0.y ^= (u3 ? 0x80000000u : (0xffffffffu % (g0 | 1u)));
    if (v0) goto L2;
    r0.y ^= (unsigned)!((unsigned)(i0 < (unsigned)(w0 >> 29)) / (3u | 1u));
    if ((8u | (i0 + (unsigned)e0))) {
        if ((unsigned)!(u0 | 0x7fffffffu)) {
            g1 += ((unsigned)(garr[i1 & 7u] == u2) % ((a0[u1 & 3u] + (unsigned)(u1 || (unsigned)w0)) | 1u));
        }
        r0.y ^= (a0[i0 & 3u] | -(unsigned)((int)(unsigned)s1 >= (int)0x7fffffffu));
        goto done;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)((unsigned)(w0 >> 29) + (unsigned)c1) < (int)(unsigned)s0), (unsigned)f0, (i1 >> (0u & 31u))); }
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= ((unsigned)(m0 || 0xffffffffu) - 0xffffffffu);
            q0 = &garr[(v0 % ((v0 - p1) | 1u)) & 7u];
            if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)s1 & 0xe51d88b0u), (m0 << (g1 & 31u)), *mp); }
        }
        switch (*mp & 7u) {
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)h0, (unsigned)!(unsigned)((unsigned)b0 || (unsigned)s0), (unsigned)((short)0x8bc492a1u > (signed char)i0)); }
                break; (void)(((unsigned)x0 >> ((unsigned)b0 & 31u)));
                u1 = u1 * 0x9e3779b1u + (unsigned)((int)(unsigned)(g0 == ((0x5d496379u - a0[u1 & 3u]) + (unsigned)s0)) < (int)0u);
                s0 = (int)(unsigned)((unsigned)(x0 >> 70) && (garr[u2 & 7u] ? v0 : 0x5c2a43dbu));
            } while (i1++ < 6u && (unsigned)(*mp < (unsigned)(0x3a71f6a3u || 0x80000000u)));
            a0[r0.y & 3u] = ((unsigned)c1 ^ (unsigned)((~(p1 / (0x7fffffffu | 1u)) * i0) == i0));
            case 6u: ;
            if ((unsigned)((unsigned)f0 == i2)) continue;
            b0 = (unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)((int)u0 >= (int)0x10000u)) != 0u;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(garr[i1 & 7u] < (i0 & 3u)), (unsigned)(signed char)(unsigned)((short)(unsigned)e0 > (signed char)0x80000000u), 0xfb3d592eu); }
    } while (i0++ < 7u && (unsigned)l0);
    switch (((unsigned)x0 % (fuel | 1u)) & 7u) {
        if (m0) {
            if ((((unsigned)s0 | (unsigned)b0) >> (a0[u1 & 3u] & 31u))) goto L1;
            h0 = (short)(unsigned)(i2 < 2u);
            r0.y ^= (0x7fffffffu % (((unsigned)((unsigned)d0 || garr[u2 & 7u]) ^ (*q0 ^ 0x5e175b7du)) | 1u));
            goto L3;
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (0x7fffffffu) {
                    c0 = (unsigned char)0xb0933665u;
                    d0 = d0 * 0.5 + (double)(p0 & 1023u);
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)0xf04e8b84u > (signed char)(unsigned)(u0 && (unsigned)h0)), (unsigned)(i0 == (unsigned)((unsigned)h1 < m0)), ((unsigned)b0 << (r0.x & 31u))); }
                }
                L0: if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((g1 % ((m0 % (g0 | 1u)) | 1u)) & 1023u);
                while (i1++ < 5u && v0) { if (--fuel == 0u) goto done;
                    goto done;
                    if ((((unsigned)c0 / (r0.y | 1u)) % (m0 | 1u))) goto L1;
                    r0.y ^= u2;
                }
                s0 = (int)-((fuel >> (1u & 31u)) << ((unsigned)h0 & 31u));
                goto L0;
            }
            case 1u: ;
        } else {
            u1 ^= (1u >> (((unsigned)c1 ? a0[u1 & 3u] : r0.x) & 31u));
            w0 ^= (unsigned long long)r0.y << (((unsigned)b0 + u3) & 63u);
            if (((unsigned)(w0 >> 29) / (((unsigned)c0 | (unsigned)f0) | 1u))) goto L2;
            if ((0x4e6916d1u >> ((unsigned)(r0.x && g1) & 31u))) {
                goto done;
                default: ;
            }
        }
        switch (garr[i1 & 7u] & 7u) {
            v0 = (0x70d1a853u / ((unsigned)((short)garr[i1 & 7u] > (signed char)i0) | 1u));
            q0 = &garr[(unsigned)(w0 >> 29) & 7u];
            case 5u: ;
        }
        v0 = -((unsigned)(((unsigned)h0 * 2u) < 7u) << ((unsigned)(a0[i0 & 3u] < (unsigned)s0) & 31u));
    }
    L1: if (--fuel == 0u) goto done;
    switch (0x7fffffffu & 7u) {
        L2: if (--fuel == 0u) goto done;
        *q0 += (unsigned)!(i1 ? (unsigned)c1 : p2);
        L3: if (--fuel == 0u) goto done;
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(x0 >> 70) < -(unsigned)(0x42e93417u || (unsigned)!((unsigned)(*mp == (unsigned)c0) + fuel))) & 255u);
            if (((unsigned)((unsigned)d0 < 6u) - (unsigned)l0)) continue;
            m0 ^= ((p1 ^ *mp) ^ 0xffffffffu);
            break; (void)(((unsigned)l0 & 5u));
            if ((unsigned)(unsigned char)(unsigned)((unsigned)b0 || 5u)) break;
        }
    }
    r0.x = 4u;
    L4: if (--fuel == 0u) goto done;
    w0 = w0 * 6364136223846793005ull + ((unsigned)((short)(unsigned)h1 > (signed char)a0[i0 & 3u]) ^ (unsigned)e0);
    for (;;) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)((int)((unsigned)(w0 >> 29) << ((unsigned)s0 & 31u)) >= (int)(unsigned)c1);
            a0[(g0 & 9u) & 3u] = (1u - 0xcc6cf066u);
            if ((unsigned)((unsigned)s1 && (unsigned)l0)) break;
            d0 = d0 * 0.5 + (double)(((unsigned)((unsigned)((unsigned)(signed char)((unsigned)(w0 >> 29) & 1u) < u1) && i0) * u2) & 1023u);
            c0 = (unsigned char)(unsigned)((-((unsigned)c0 % (p0 | 1u)) / ((unsigned)x0 | 1u)) < (unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)c1));
            i1 = ((unsigned)((int)p0 < (int)(unsigned)w0) ^ (0x7fffffffu << ((unsigned)c0 & 31u))) & 15u;
        }
        r0.x = fuel;
        { unsigned t0; double z0; if (((*mp + (i1 | (unsigned)f0))) & 1u) { t0 = (unsigned)!(garr[i1 & 7u] + u1); z0 = (double)(((unsigned)((unsigned)c1 < r0.x)) & 255u); } if (((*mp + (i1 | (unsigned)f0))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            break; (void)((unsigned)(short)((r0.x | garr[u2 & 7u]) << (0x31b110e4u & 31u)));
            if ((unsigned)(unsigned char)(-(unsigned)((short)a0[u1 & 3u] > (signed char)p0) >> ((unsigned)l0 & 31u))) {
                if ((8u * (unsigned)d0)) {
                    if ((unsigned)(signed char)(6u - (unsigned)c0)) continue;
                    if (u3 == 7u) return ((unsigned)(0xdf08bcbeu || v0) + 0x7fffffffu);
                    if (-(unsigned)((int)p0 < (int)(unsigned)((short)r0.y > (signed char)u3))) break;
                    if (u2) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(garr[u2 & 7u], ((unsigned)l0 | 0x7fffffffu), (unsigned)(signed char)((unsigned)d0 ^ a0[i0 & 3u])); }
                }
                *q0 = ((unsigned)c0 - ((unsigned)h0 & i1));
            } else {
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + u2);
                }
                break; (void)(~(3u * (unsigned)((int)*q0 >= (int)u2)));
                u2 = u2 * 0x9e3779b1u + (unsigned)((int)g1 < (int)0x10000u);
            }
        }
        s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)c1 < (int)(unsigned)((int)9u < (int)(unsigned)s1)));
        if (((unsigned)w0 / (0xdf9963c3u | 1u))) continue;
        q0 = &garr[(unsigned)(signed char)((unsigned)((int)(unsigned)x0 >= (int)p1) | (unsigned)w0) & 7u];
    }
    goto L2;
    g0 = (p1 >> (p1 & 31u));
    q0 = &garr[g1 & 7u];
    if ((p0 << (((unsigned)h0 + 3u) & 31u))) goto L0;
    u1 ^= ((unsigned)!(a0[i0 & 3u] << ((unsigned)((int)5u < (int)u3) & 31u)) & (unsigned)((unsigned)w0 || (unsigned)l0));
    do { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)((short)(unsigned)c0 > (signed char)*mp) << (g0 & 31u)), (unsigned)((int)garr[i1 & 7u] < (int)u1), (unsigned)(u0 || (g0 ^ (unsigned)h1))); }
            if ((i0 / ((r0.y % (i1 | 1u)) | 1u))) {
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)d0 & (unsigned)w0), (i0 * garr[u2 & 7u]), *mp); }
                u1 += (unsigned)((int)2u >= (int)3u);
                f0 = f0 * 0.5f + (float)((unsigned)w0 & 255u);
                c1 = (signed char)(unsigned)(*q0 == 8u);
            }
            g1 += (0x80000000u * (unsigned)h1);
            m0 ^= 0xffffffffu;
            if ((unsigned)(short)(u0 ^ u3)) continue;
        } while (i1++ < 6u && (p0 ? (unsigned)(x0 >> 70) : g1));
        break; (void)(p1);
        while (i1++ < 5u && (unsigned)((int)(0xbd65a379u + (unsigned)w0) >= (int)fuel)) { if (--fuel == 0u) goto done;
            continue; (void)(((fuel * u3) ^ g0));
            if ((unsigned)((unsigned)(p0 < (unsigned)x0) || *mp)) goto L3;
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)(5u < (unsigned)(g1 && (unsigned)((short)(unsigned)s1 > (signed char)(unsigned)s1))) & 255u);
                w0 ^= (unsigned long long)(unsigned)((int)0xf58d5112u >= (int)0x8b2e605eu) << (((unsigned)(w0 >> 29) >> (((unsigned)((short)u0 > (signed char)(unsigned)h1) * p0) & 31u)) & 63u);
                if (0x10000u) goto L0;
                *q0 = (unsigned)((unsigned)f0 < i0);
                if (garr[u2 & 7u]) break;
            }
            c0 = (unsigned char)(g0 ? ((unsigned)s1 * garr[i1 & 7u]) : (u0 * g0));
            u2 = ((unsigned)s1 + ((unsigned)h0 * (7u + garr[i1 & 7u])));
        }
    } while (i0++ < 5u && (a0[i0 & 3u] + (0x80000000u / (0x82636fdfu | 1u))));
    do { if (--fuel == 0u) goto done;
        q0 = &garr[(garr[i1 & 7u] / (*mp | 1u)) & 7u];
        v0 = (unsigned)(unsigned char)(unsigned)(((unsigned)((int)r0.x >= (int)(unsigned)h1) / ((unsigned)e0 | 1u)) == (0x80000000u * 9u));
    } while (i0++ < 4u && (m0 + (unsigned)(w0 >> 29)));
    d0 = d0 * 0.5 + (double)(u0 & 1023u);
    switch ((unsigned)(v0 || g1) & 7u) {
        switch ((unsigned)c0 & 7u) {
            q0 = &garr[(unsigned)(((unsigned)s0 ? (unsigned)f0 : 0x7fffffffu) || ((unsigned)f0 << ((unsigned)l0 & 31u))) & 7u];
        }
        while (i0++ < 3u && ((unsigned)(0x9bea82d1u && 8u) / ((unsigned)h0 | 1u))) { if (--fuel == 0u) goto done;
            case 4u: ;
        }
        goto L3;
        s1 = (int)((unsigned)s1 + (0x31cc1221u | -(unsigned)((unsigned)s0 < i0)));
    }
    f0 = f0 * 0.5f + (float)((unsigned)(garr[i1 & 7u] && (v0 & 0x7fffffffu)) & 255u);
    garr[m0 & 7u] = (unsigned)((int)(a0[u1 & 3u] << ((unsigned)h1 & 31u)) >= (int)(unsigned)((int)0x80000000u < (int)(unsigned)((short)i0 > (signed char)(unsigned)d0)));
    if (0x27c527dbu) {
        b0 = (0x80000000u ^ -((unsigned)(unsigned char)(unsigned)((int)0xffffffffu >= (int)(unsigned)s0) << (~(unsigned)((unsigned)(w0 >> 29) < i2) & 31u))) != 0u;
        switch (((unsigned)(signed char)((unsigned)e0 ^ 3u) >> (p0 & 31u)) & 7u) {
            i0 = ((unsigned)h1 / ((unsigned)w0 | 1u)) & 15u;
            switch ((unsigned)(g0 || 0xff556871u) & 7u) {
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)(short)((unsigned)(x0 >> 70) - 2u)) goto L2;
                    case 4u: ;
                } while (i0++ < 7u && 0x7fffffffu);
                if (((r0.y + u1) % (0xcb9de2b1u | 1u))) goto L3;
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((0xffffffffu & (unsigned)h1), (unsigned)((unsigned)d0 < 0x6e1d6044u), (unsigned)((short)g1 > (signed char)i2)); }
                        u2 += (((unsigned)e0 + (0x6d64ce17u ^ (i2 + 0x80000000u))) ^ (unsigned)f0);
                        q0 = &garr[(unsigned)((i1 - i0) || (unsigned)((short)(0x10000u >> ((unsigned)l0 & 31u)) > (signed char)p1)) & 7u];
                    }
                    case 5u: ;
                    if ((unsigned)(unsigned char)(unsigned)((unsigned)c1 || (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)s1))) {
                        w0 ^= (unsigned long long)(0x10000u | (unsigned)l0) << ((i1 | m0) & 63u);
                        if (budget != 0u) { budget -= 1u; u3 = fn1(p2, (unsigned)((short)r0.x > (signed char)(unsigned)(short)((unsigned)w0 << (g0 & 31u))), p2); }
                        b0 = ((unsigned)((unsigned)h1 || 1u) | (u3 % ((g1 - 5u) | 1u))) != 0u;
                        w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)(i1 < 0x9ea2a77u) > (signed char)(garr[i1 & 7u] >> (((unsigned)h1 >> ((unsigned)l0 & 31u)) & 31u)));
                    }
                }
            }
            if (fuel < 8u) return (unsigned)(unsigned char)(unsigned)((unsigned)((unsigned)w0 || (unsigned)(7u || ~(0x80000000u >> ((unsigned)e0 & 31u)))) < garr[i1 & 7u]);
            g0 = g0;
        }
        if ((i2 << (0x10000u & 31u))) {
            f0 = f0 * 0.5f + (float)(~(unsigned)((unsigned)((short)*mp > (signed char)*q0) < (garr[i1 & 7u] & m0)) & 255u);
            if (budget != 0u) { budget -= 1u; u1 = fn0(m0, ((unsigned)e0 - a0[i0 & 3u]), (unsigned)b0); }
            goto done;
            u1 = (0xffffffffu % ((unsigned)(*q0 || *q0) | 1u));
            l0 = (long)((unsigned long)l0 + (unsigned)(g0 < (0xffffffffu & 9u)));
        } else {
            if ((unsigned)(m0 && 0x52388e3cu)) goto L2;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)s0, (unsigned)((int)(unsigned)(0x7fffffffu == fuel) >= (int)(unsigned)d0), (unsigned)(unsigned char)((unsigned)(short)(unsigned)(0x10000u < p0) % ((unsigned)(w0 >> 29) | 1u))); }
        }
        if (1u) goto L3;
        if ((m0 ^ (unsigned)(*mp < garr[i1 & 7u]))) {
            if ((unsigned)(unsigned char)(unsigned)((garr[u2 & 7u] / ((unsigned)s1 | 1u)) < p0)) goto L2;
        } else {
            do { if (--fuel == 0u) goto done;
                if (v0) break;
                if (budget != 0u) { budget -= 1u; u0 = fn1((0x192f875u * (0xa91b3435u ^ u1)), (unsigned)((short)(unsigned)e0 > (signed char)garr[u2 & 7u]), r0.x); }
                break; (void)(u0);
                f0 = f0 * 0.5f + (float)(-((unsigned)((int)(unsigned)((unsigned)(x0 >> 70) || 4u) < (int)(p2 | u1)) >> (0x390e4cebu & 31u)) & 255u);
                u2 = u2 * 0x9e3779b1u + (unsigned)(4u < (*q0 >> (p1 & 31u)));
            } while (i0++ < 4u && v0);
            a0[*q0 & 3u] = ((unsigned)(i2 < (unsigned)(signed char)(unsigned)((int)0x80000000u < (int)(unsigned)l0)) * (unsigned)b0);
            *mp = (unsigned)(signed char)((unsigned)((unsigned)x0 < m0) ^ (unsigned)((9u + (unsigned)w0) < (unsigned)(x0 >> 70)));
        }
        m0 ^= (unsigned)((int)(unsigned)((int)(unsigned)((int)(unsigned)s0 < (int)0x80000000u) >= (int)u2) < (int)u0);
    } else {
        h1 = (unsigned short)(h1 + ((unsigned)(unsigned char)(9u ? 0x628f4b4cu : i0) ^ ~(*q0 >> (0x7fffffffu & 31u))));
        g0 = (~(unsigned)((int)0x2b15d7e7u < (int)0x72bd042fu) * (0x7de48d7eu >> (garr[u2 & 7u] & 31u)));
        h1 = (unsigned short)(h1 + p2);
    }
    garr[g1 & 7u] = (unsigned)h1;
    h0 = (short)(unsigned)d0;
    goto L4;
    s1 = (int)((unsigned)s1 + p0);
    l0 = (long)((unsigned long)l0 + (unsigned)(r0.x == (unsigned)(signed char)(u2 / (0xd518e617u | 1u))));
    q0 = &garr[((unsigned)x0 ? (unsigned)s0 : u2) & 7u];
    if (u3 == 7u) return (unsigned)(signed char)(0x6c87e216u | 9u);
    while (i0++ < 2u && ((unsigned)f0 ^ 0x7fffffffu)) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + ((unsigned)(u1 == 0xd388e5dbu) >> (0xffffffffu & 31u)));
        if ((unsigned)(x0 >> 70)) {
            r0.x = p0;
            f0 = f0 * 0.5f + (float)(((unsigned)f0 | (0x357b141bu ^ (unsigned)d0)) & 255u);
            w0 = w0 * 6364136223846793005ull + ((p1 - 0xb9383aebu) * 0x80000000u);
            u0 ^= (unsigned)((short)((p0 - p0) % ((unsigned)s1 | 1u)) > (signed char)i1);
            u2 = u2 * 0x9e3779b1u + ((unsigned)!(unsigned)((int)a0[u1 & 3u] < (int)a0[i0 & 3u]) << (a0[u1 & 3u] & 31u));
            u1 = (unsigned)(unsigned char)(unsigned)((unsigned)s0 == p1);
        } else {
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u3) break;
                if (2u) break;
                d0 = d0 * 0.5 + (double)((unsigned)(fuel == (unsigned)(7u || u2)) & 1023u);
                while (i2++ < 5u && (unsigned)!(i0 + u3)) { if (--fuel == 0u) goto done;
                    q0 = &garr[(unsigned)((int)(unsigned)((short)(p1 ^ 0u) > (signed char)0x84e6bbadu) >= (int)((unsigned)b0 + (unsigned)(x0 >> 70))) & 7u];
                    if ((unsigned)((int)i2 >= (int)(unsigned)(x0 >> 70))) goto L4;
                    if ((fuel + -(unsigned)((int)0x5f89e45fu >= (int)0x2437e020u))) goto L0;
                    break; (void)((u3 >> (((unsigned)b0 >> (u2 & 31u)) & 31u)));
                }
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)((unsigned)c1 || (unsigned)(*mp || 0x7cccacu)) & 1023u);
                    f0 = f0 * 0.5f + (float)((0x831ceba8u % (((unsigned)(*mp == 0x10000u) / (0x1cbc86f2u | 1u)) | 1u)) & 255u);
                    g1 += ((unsigned)s1 * (unsigned)((int)(g0 ^ g1) < (int)(i1 % (u1 | 1u))));
                    if (r0.y) break;
                }
                g1 += ((unsigned)(a0[i0 & 3u] || (unsigned)c1) + (unsigned)((int)2u < (int)(5u / (0x80000000u | 1u))));
            }
        }
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            *q0 = 1u;
            c0 = (unsigned char)(unsigned)(signed char)(unsigned)(2u < 2u);
            if ((unsigned)((int)((unsigned)s0 | 0xcbd68da7u) < (int)g1)) continue;
            if ((unsigned)((int)g1 >= (int)0x9f547c6au)) goto done;
            if ((unsigned)w0) continue;
            h1 = (unsigned short)(h1 + (~(p2 << (0x53bb6643u & 31u)) / ((unsigned)(short)((unsigned)e0 / (0x10000u | 1u)) | 1u)));
        }
        u0 += i0;
        break; (void)((unsigned)!(unsigned)((int)*mp >= (int)0x3ec45bb6u));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (u3 == 7u) return (unsigned)(0x22983b2du == (a0[i0 & 3u] * 0xffffffffu));
    if (fuel < 8u) return ((unsigned)(short)(unsigned)((int)fuel >= (int)(unsigned)((short)(0xffffffffu * 1u) > (signed char)u0)) + 0x80000000u);
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((6u - 0x10000u)) break;
        do { if (--fuel == 0u) goto done;
            break; (void)((1u | (unsigned)(x0 >> 70)));
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn2((g0 - (unsigned)(9u == *mp)), (((unsigned)c1 & (unsigned)w0) << ((unsigned)h0 & 31u)), ((unsigned)h1 * 0x80464cbfu)); }
                u2 ^= (unsigned)((m0 >> (9u & 31u)) && (i2 | (0x8a2159a2u ^ 0x80000000u)));
                u0 ^= (unsigned)((short)(((unsigned)(w0 >> 29) & (unsigned)w0) ^ 2u) > (signed char)(unsigned)s1);
                if ((unsigned)(garr[i1 & 7u] < 0x33fd7040u)) break;
                v0 = (unsigned)(signed char)(unsigned)((7u & 0x96cbbed9u) < (g0 % (p2 | 1u)));
                l0 = (long)((unsigned long)l0 + g1);
            }
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (garr[i1 & 7u]) {
                    if (((unsigned)(short)(unsigned)(6u == 6u) * a0[u1 & 3u])) {
                        garr[(p2 | m0) & 7u] = 0x80000000u;
                    }
                    *mp = (0u * v0);
                    { unsigned t0; double z0; if (((unsigned)(unsigned char)((unsigned)h1 % ((p1 + *mp) | 1u))) & 1u) { t0 = (2u << (((unsigned)x0 ^ 3u) & 31u)); z0 = (double)((((unsigned)!(unsigned)((unsigned)b0 || 5u) ^ (unsigned)(x0 >> 70))) & 255u); } if (((unsigned)(unsigned char)((unsigned)h1 % ((p1 + *mp) | 1u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                        u2 = ((unsigned)s1 | (unsigned)(2u && (unsigned)s0));
                        if (budget != 0u) { budget -= 1u; u3 = fn2(0x10000u, (8u * 0x8be3fdfdu), garr[i1 & 7u]); }
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)h0 < *q0), ((u1 / (p0 | 1u)) + g0), ~(unsigned)((unsigned)c1 < (unsigned)w0)); }
                        break; (void)((unsigned)(0xffffffffu == garr[i1 & 7u]));
                        { unsigned t1; double z1; if (((unsigned)(0u || 0x2bd7346du)) & 1u) { t1 = (unsigned)w0; z1 = (double)((-(unsigned)((short)m0 > (signed char)(unsigned)(unsigned char)(p1 ^ g1))) & 255u); } if (((unsigned)(0u || 0x2bd7346du)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                            h1 = (unsigned short)(h1 + ((unsigned)((int)r0.x >= (int)*mp) << (v0 & 31u)));
                            goto L1;
                        }
                        q0 = &garr[(unsigned)((9u - p1) == (unsigned)f0) & 7u];
                    }
                    while (i0++ < 6u && garr[u2 & 7u]) { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)(g0 - 0x7fffffffu) << ((unsigned)((int)(unsigned)(0xffffffffu < (unsigned)s1) < (int)0x5f5bccc2u) & 63u);
                        goto L0;
                        if ((unsigned)(short)(((unsigned)h0 ^ i0) & (unsigned)h0)) break;
                        s1 = (int)((unsigned)s1 + (unsigned)((int)p2 >= (int)g1));
                        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)(*mp < i1) == 0x5aae238fu), (unsigned)((short)((unsigned)f0 ^ g0) > (signed char)(unsigned)b0), 8u); }
                    }
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((0x80000000u + (unsigned)((int)0x282801aeu < (int)(unsigned)h0)), (unsigned)((short)1u > (signed char)(unsigned)c0), (unsigned)l0); }
            }
            if (-(0x80000000u % (((unsigned)(x0 >> 70) % (garr[i1 & 7u] | 1u)) | 1u))) break;
            if ((0x3d28aae8u - p1)) break;
        } while (i1++ < 5u && (unsigned)((short)0x7fffffffu > (signed char)0x27778113u));
    }
    f0 = f0 * 0.5f + (float)((unsigned)d0 & 255u);
    if (0x80000000u) {
        d0 = d0 * 0.5 + (double)((unsigned)!(unsigned)(0xffffffffu == p2) & 1023u);
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(short)(unsigned)(u0 == (unsigned)(short)(unsigned)((unsigned)s0 && 1u))) break;
            h0 = (short)(unsigned)((a0[i0 & 3u] ^ i1) == ((unsigned)((int)(unsigned)c0 < (int)i1) / (g1 | 1u)));
            m0 ^= ((unsigned)s0 & (fuel | (unsigned)(short)((m0 + *q0) << ((unsigned)(w0 >> 29) & 31u))));
            L0: if (--fuel == 0u) goto done;
            if ((unsigned)(w0 >> 29)) break;
        }
        goto L2;
        goto L3;
        do { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)((short)((unsigned)(short)(m0 % ((unsigned)s0 | 1u)) - (unsigned)h0) > (signed char)(unsigned)s0));
            goto L4;
            L1: if (--fuel == 0u) goto done;
            continue; (void)(u2);
        } while (i0++ < 5u && ((3u / (8u | 1u)) % (0x80000000u | 1u)));
    }
    if (8u) goto L0;
    garr[garr[i1 & 7u] & 7u] = ((0xcf9854f5u - fuel) / ((unsigned)(0x7fffffffu == (unsigned)s0) | 1u));
    if (v0) {
        L2: if (--fuel == 0u) goto done;
        u2 += (unsigned)(unsigned char)(unsigned)(0xe7479b1cu < 0xc58f4ac1u);
    }
    u3 = g0;
    switch ((unsigned)l0 & 7u) {
        if ((u3 % ((unsigned)b0 | 1u))) {
            u3 = (unsigned)s1;
            { unsigned t2; double z2; if ((((unsigned)e0 ? i0 : (unsigned)l0)) & 1u) { t2 = (0x7fffffffu & (unsigned)c0); z2 = (double)((((unsigned)d0 ^ (u3 * 2u))) & 255u); } if ((((unsigned)e0 ? i0 : (unsigned)l0)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                *q0 += (unsigned)((int)u3 >= (int)(unsigned)(signed char)((unsigned)l0 - p0));
                h0 = (short)((unsigned)((int)(unsigned)(w0 >> 29) < (int)*mp) ^ ((unsigned)c0 / ((unsigned)h1 | 1u)));
                *q0 += (unsigned)((short)(unsigned)((unsigned)!(*q0 % (*mp | 1u)) == r0.y) > (signed char)*q0);
                while (i0++ < 7u && (unsigned)h0) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(0x3de8e27bu || (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)c1)), (0u % (((unsigned)w0 & 0x8ae4067eu) | 1u)), (unsigned)((short)5u > (signed char)*mp)); }
                    g1 += (unsigned)(((unsigned)s0 >> ((unsigned)(u2 == (unsigned)(signed char)(r0.x ^ (unsigned)c0)) & 31u)) == r0.y);
                    case 3u: ;
                    case 6u: ;
                    if ((unsigned)x0) goto L1;
                    if (budget != 0u) { budget -= 1u; u3 = fn2(7u, (unsigned)b0, (0x10000u * (unsigned)(g0 == a0[i0 & 3u]))); }
                }
            }
        } else {
            L3: if (--fuel == 0u) goto done;
            u3 = u3 * 0x9e3779b1u + (unsigned)(p0 || fuel);
        }
        if (a0[u1 & 3u]) {
            garr[(unsigned)f0 & 7u] = (p0 / (~(0x80000000u + 2u) | 1u));
            case 1u: ;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)s0 + i2), (fuel | fuel), ((unsigned)l0 * (unsigned)((short)0x80000000u > (signed char)u1))); }
                if ((unsigned)s1) {
                    v0 = ((unsigned)(0x3add90cau == 0xcaa86466u) & (unsigned)((int)i2 >= (int)garr[i1 & 7u]));
                    if (u3 == 7u) return (unsigned)(((~(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)h0) ^ (unsigned)c1) - g1) < 0x10000u);
                    c0 = (unsigned char)(unsigned)(signed char)((g0 & (unsigned)((int)(unsigned)x0 >= (int)i1)) / ((unsigned)f0 | 1u));
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        c1 = (signed char)u2;
                        h0 = (short)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)(((unsigned)(w0 >> 29) / (0x7fffffffu | 1u)) && (unsigned)(short)((unsigned)(x0 >> 70) / (2u | 1u))));
                        break; (void)((g1 / ((unsigned)h1 | 1u)));
                        q0 = &garr[(unsigned)(p2 || (unsigned)((unsigned)b0 < v0)) & 7u];
                        c0 = (unsigned char)(unsigned)((unsigned)h0 && (unsigned)!(unsigned)((unsigned)((short)(unsigned)l0 > (signed char)a0[u1 & 3u]) && (5u * (unsigned)c0)));
                        *mp = ((unsigned)(((unsigned)e0 << ((unsigned)c1 & 31u)) && (unsigned)s0) | i2);
                    }
                } else {
                    garr[(unsigned)d0 & 7u] = ((unsigned)f0 + 0xffffffffu);
                }
                L4: if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(((r0.y / (fuel | 1u)) ? a0[u1 & 3u] : (garr[u2 & 7u] * i0)) & 1023u);
                default: ;
            } while (i0++ < 4u && (unsigned)(signed char)(fuel / (-(g1 >> (m0 & 31u)) | 1u)));
            l0 = (long)((unsigned long)l0 + i1);
            garr[*mp & 7u] = u0;
            switch (i0 & 7u) {
                i2 = (unsigned)h1 & 15u;
            }
        } else {
            q0 = &garr[((unsigned)((int)a0[i0 & 3u] < (int)m0) - (6u & 0x264ed2c9u)) & 7u];
            if ((garr[i1 & 7u] - ((unsigned)c0 ^ p0))) {
                f0 = f0 * 0.5f + (float)((unsigned)((short)m0 > (signed char)0x1869e9f4u) & 255u);
                c0 = (unsigned char)(unsigned)((unsigned)(signed char)(m0 / (fuel | 1u)) && (unsigned)((unsigned)c1 && (unsigned)((short)7u > (signed char)u1)));
                *q0 += (p1 ^ *q0);
            }
        }
        u3 = ((unsigned)e0 + 6u);
    }
    while (i0++ < 3u && (0x10000u & r0.y)) { if (--fuel == 0u) goto done;
        i2 = 7u & 15u;
        if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)c1 - (i2 << (2u & 31u))), ((garr[i1 & 7u] ^ (unsigned)h0) ^ r0.x), (unsigned)(signed char)(unsigned)((int)(unsigned)l0 < (int)u2)); }
        if ((0u ? *q0 : *mp)) break;
    }
    if ((unsigned)(short)(unsigned)((int)(garr[u2 & 7u] / ((unsigned)x0 | 1u)) >= (int)7u)) goto L0;
    m0 ^= (unsigned)!(0x33eb42dfu ? (unsigned)(w0 >> 29) : p0);
    u3 = u3 * 0x9e3779b1u + ((0xffffffffu / (i1 | 1u)) ^ 0xf8f538d1u);
    if ((unsigned)((short)p1 > (signed char)(unsigned)((short)u3 > (signed char)(unsigned)h0))) goto L4;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = ((unsigned)x0 / ((unsigned)(((unsigned)h1 | 0x6a8d9fcbu) && (unsigned)(w0 >> 29)) | 1u));
        if (u3 == 7u) return v0;
        if ((unsigned)d0) break;
    }
    c1 = (signed char)(g0 ? ((unsigned)x0 ^ 8u) : (0xffffffffu - 0xc3c348c6u));
    if (0x40b25ae2u) {
        if (fuel < 8u) return (unsigned)(1u || 0x10000u);
        g1 += -(unsigned)((unsigned)l0 < 0x8edf6989u);
        b0 = (unsigned)((int)4u >= (int)i2) != 0u;
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((u3 ? (unsigned)h0 : (unsigned)h0) & 1023u);
            if ((i1 | (unsigned)x0)) break;
            w0 ^= (unsigned long long)(*mp - p2) << (((unsigned)s0 << ((0x10000u | *mp) & 31u)) & 63u);
            l0 = (long)((unsigned long)l0 + i2);
            continue; (void)((unsigned)(signed char)(unsigned)(g1 && p2));
            s0 = (int)~(g1 * u0);
        }
    } else {
        *q0 = (unsigned)((int)1u >= (int)((unsigned)((int)a0[i0 & 3u] >= (int)(0xe569dd44u - 0x7fffffffu)) * (unsigned)c1));
        w0 = w0 * 6364136223846793005ull + ~(g1 / ((unsigned)((0xe9ba4f22u / (u1 | 1u)) && (0x7fffffffu + (unsigned)h0)) | 1u));
        if ((unsigned)(-(r0.y << ((unsigned)h0 & 31u)) || 7u)) goto L1;
        v0 = r0.y;
    }
    if ((unsigned)(r0.y && 0x80000000u)) {
        c0 = (unsigned char)((u3 % (0x4e4a41ecu | 1u)) % ((g1 ^ (unsigned)(unsigned char)(0xf74a6828u * 0xffffffffu)) | 1u));
        if ((unsigned)((0x80000000u / (i2 | 1u)) && 0x7fffffffu)) {
            w0 ^= (unsigned long long)(unsigned)((int)p2 < (int)4u) << ((unsigned)(signed char)(unsigned)(((unsigned)w0 ^ p1) < -(0xe0232cc8u << ((unsigned)d0 & 31u))) & 63u);
            if (((unsigned)d0 ^ ((unsigned)h1 * u0))) {
                q0 = &garr[(unsigned)((int)(unsigned)f0 < (int)(unsigned)f0) & 7u];
                d0 = d0 * 0.5 + (double)((unsigned)h1 & 1023u);
                c1 = (signed char)5u;
            } else {
                h0 = (short)((unsigned)((short)r0.y > (signed char)(0x7fffffffu | u2)) % (-(unsigned)(0x10000u < i2) | 1u));
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)b0, (unsigned)(unsigned char)(unsigned)(9u || 0xbeb23f49u), (p1 | (unsigned)e0)); }
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((fuel & ((unsigned)f0 * ((unsigned)f0 >> (garr[i1 & 7u] & 31u)))) & 255u);
            }
            f0 = f0 * 0.5f + (float)(((~((unsigned)((short)g1 > (signed char)u3) >> (8u & 31u)) % ((unsigned)d0 | 1u)) ^ 3u) & 255u);
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                h0 = (short)a0[u1 & 3u];
                s0 = (int)(unsigned)(u2 || (unsigned)(unsigned char)(unsigned)((unsigned)(w0 >> 29) < 5u));
                if (u3 == 7u) return (p0 | (unsigned)((int)u1 < (int)u1));
            }
        } else {
            switch (((unsigned)s0 / ((*q0 & (unsigned)s1) | 1u)) & 7u) {
                if ((0x908a44a8u << (0x7fffffffu & 31u))) break;
                if ((unsigned)(((unsigned)s1 >> (u0 & 31u)) == u2)) goto L3;
            }
        }
    } else {
        if ((unsigned)l0) goto L3;
        s1 = (int)((unsigned)s1 + (unsigned)(a0[i0 & 3u] || (unsigned)h1));
        for (;;) { if (--fuel == 0u) goto done;
            { unsigned t3; double z3; if ((p0) & 1u) { t3 = (unsigned)((int)(unsigned)h0 >= (int)0xffffffffu); z3 = (double)((((unsigned)c0 ^ (unsigned)x0)) & 255u); } if ((p0) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                g1 += (unsigned)((unsigned)((int)(unsigned)b0 >= (int)(unsigned)b0) && i2);
            }
        }
    }
    if (((unsigned)c0 % (p1 | 1u))) {
        u0 += (unsigned)((int)0x10000u >= (int)(unsigned)(0x4b38b2f5u == (*mp / ((unsigned)(signed char)((unsigned)l0 ^ r0.y) | 1u))));
        { unsigned t4; double z4; if ((fuel) & 1u) { t4 = (unsigned)((unsigned)s0 || g1); z4 = (double)(((unsigned)((int)((unsigned)l0 >> (6u & 31u)) >= (int)3u)) & 255u); } if ((fuel) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            e0 = e0 * 0.5L + (long double)(((unsigned)b0 % (5u | 1u)) & 1023u);
            if ((garr[u2 & 7u] >> ((i2 / (a0[u1 & 3u] | 1u)) & 31u))) goto L4;
            s1 = (int)((unsigned)s1 + ((unsigned)(m0 && (g0 - p1)) * (unsigned)b0));
            goto L1;
        }
        l0 = (long)((unsigned long)l0 + (unsigned)(v0 && (1u & 0x10000u)));
    } else {
        switch ((-(0xaabfa493u % (u2 | 1u)) * 0u) & 7u) {
            if (((unsigned)h0 % (2u | 1u))) goto L0;
            if (0x9f7b5303u) goto L0;
            *q0 = (unsigned)(0x10000u && garr[i1 & 7u]);
            if (budget != 0u) { budget -= 1u; u0 = fn2((9u ? (unsigned)f0 : u0), (unsigned)h0, garr[i1 & 7u]); }
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)0x7fffffffu >= (int)(unsigned)c1), (unsigned)((short)((unsigned)f0 << (p1 & 31u)) > (signed char)0xd88155e8u), (p1 ? p0 : (unsigned)x0)); }
        }
        if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)s0 | (unsigned)h1), (unsigned)(w0 >> 29), (unsigned)((short)(unsigned)(v0 < v0) > (signed char)5u)); }
        if (g1) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(u3 < (unsigned)x0), (unsigned)(w0 >> 29), garr[u2 & 7u]); }
        } else {
            g1 += u0;
            do { if (--fuel == 0u) goto done;
                if (p0) {
                    c0 = (unsigned char)(unsigned)(signed char)(unsigned)((int)9u >= (int)(((unsigned)c0 << (0xffffffffu & 31u)) - v0));
                    while (i1++ < 4u && ((unsigned)!(*q0 - r0.y) >> ((unsigned)d0 & 31u))) { if (--fuel == 0u) goto done;
                        h0 = (short)-((v0 >> ((unsigned)l0 & 31u)) % (g1 | 1u));
                        x0 = x0 * 0x100000001b3ull + ((unsigned)(0xf54dd603u && u3) / (0x80000000u | 1u));
                        if ((u3 >> ((unsigned)((int)(unsigned)h0 < (int)r0.y) & 31u))) continue;
                        u0 = u0 * 0x9e3779b1u + i2;
                    }
                    if ((unsigned)((unsigned)(x0 >> 70) || 0xa0e4515bu)) goto L1;
                    e0 = e0 * 0.5L + (long double)((unsigned)(((unsigned)s0 | u1) < ~((unsigned)l0 >> (fuel & 31u))) & 1023u);
                } else {
                    while (i1++ < 2u && ((g0 | g1) * a0[u1 & 3u])) { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)c0 >= (int)((unsigned)h1 - ~(unsigned)(r0.y && (unsigned)w0))));
                        u3 ^= garr[i1 & 7u];
                        if (budget != 0u) { budget -= 1u; u0 = fn2((p2 ? 0x10000u : u1), (i0 * 0x7fffffffu), (a0[i0 & 3u] + 1u)); }
                        if (budget != 0u) { budget -= 1u; u1 = fn2((4u ^ (unsigned)((int)i0 >= (int)(unsigned)h1)), (unsigned)(2u || ((unsigned)c0 / (5u | 1u))), (unsigned)(short)(0xfc2e0ed9u >> ((unsigned)((int)(unsigned)s0 >= (int)(unsigned)d0) & 31u))); }
                        h0 = (short)(5u - (3u << ((unsigned)((short)g1 > (signed char)fuel) & 31u)));
                        u1 += (unsigned)((int)(unsigned)e0 < (int)((unsigned)s0 & fuel));
                    }
                    c0 = (unsigned char)a0[u1 & 3u];
                    if (budget != 0u) { budget -= 1u; u2 = fn2((7u << ((2u | 0xc394454au) & 31u)), (u2 & (unsigned)((short)fuel > (signed char)0xf518023cu)), (unsigned)((unsigned)s0 && 0x10000u)); }
                    i0 = (0x10000u >> (0x94661dd7u & 31u)) & 15u;
                }
                s0 = (int)(((unsigned)s1 & 0x10000u) ? (unsigned)c0 : 0x2e6a197cu);
                if (g0) continue;
            } while (i0++ < 4u && ((unsigned)s1 - (unsigned)c0));
            u1 = 0x210aa326u;
            if ((unsigned)(a0[i0 & 3u] == ((unsigned)l0 * (unsigned)s0))) goto done;
        }
        if ((unsigned)d0) goto L3;
    }
    if (p0) goto L4;
    i1 = (unsigned)(short)(*q0 | (unsigned)((int)(unsigned)(short)(0x80000000u ^ (unsigned)l0) >= (int)(garr[i1 & 7u] + 0u))) & 15u;
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)((unsigned)f0 + (unsigned)s0), (unsigned)(*mp < p0), ~(unsigned)((int)r0.y < (int)(unsigned)e0)); }
    if ((unsigned)((int)(unsigned)e0 >= (int)*q0)) {
        m0 ^= (unsigned)((int)(unsigned)h1 < (int)(((unsigned)d0 << ((unsigned)d0 & 31u)) ^ fuel));
        if (((a0[u1 & 3u] >> (g1 & 31u)) ^ 0x833677c9u)) goto done;
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                h0 = (short)(0x10000u - (0x2af45146u - g0));
            } while (i1++ < 4u && (0x7fffffffu & a0[u1 & 3u]));
        }
    } else {
        i0 = ((unsigned)w0 ^ 6u) & 15u;
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            b0 = (unsigned)(short)(unsigned)((int)(unsigned)(1u == (p1 << (a0[u1 & 3u] & 31u))) >= (int)(unsigned)f0) != 0u;
            e0 = e0 * 0.5L + (long double)(0x66fe957bu & 1023u);
            d0 = d0 * 0.5 + (double)((*q0 + 9u) & 1023u);
            m0 ^= (0x80000000u + (u0 << ((unsigned)((short)0x2497a2c6u > (signed char)r0.x) & 31u)));
        }
    }
    if ((u3 | *q0)) goto L1;
    switch (p2 & 7u) {
        case 6u: ;
        case 5u: ;
        w0 ^= (unsigned long long)(0x10000u * (unsigned)s1) << ((unsigned)((unsigned)b0 && (a0[u1 & 3u] % (r0.x | 1u))) & 63u);
        c0 = (unsigned char)((unsigned)c0 / (g1 | 1u));
    }
    if (budget != 0u) { budget -= 1u; u0 = fn2(0x7fffffffu, (unsigned)((unsigned)(0x7fffffffu == u2) || fuel), 0x2f1b6957u); }
    if ((v0 ^ (unsigned)x0)) goto L0;
    if ((-(unsigned)(9u == 0x10000u) * (unsigned)w0)) {
        l0 = (long)((unsigned long)l0 + u1);
        x0 = x0 * 0x100000001b3ull + (2u | (unsigned)((unsigned)s1 < (unsigned)(6u == r0.x)));
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)x0, ((unsigned)((int)i2 >= (int)0x7fffffffu) & (unsigned)x0), (unsigned)d0); }
        v0 = ((unsigned)((unsigned)((short)fuel > (signed char)fuel) && (unsigned)l0) ^ garr[u2 & 7u]);
    }
    *mp = (unsigned)(short)(g0 % ((unsigned)s0 | 1u));
    goto L3;
    c0 = (unsigned char)5u;
    switch ((unsigned)(3u && p1) & 7u) {
        r0.y ^= ((unsigned)(g1 == 0x80000000u) ? 0x10000u : i2);
        switch (g1 & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)(u3 < 0x1b29c781u) - p1), 0xad2c142eu, (g1 + (unsigned)((int)0x2f74ef06u < (int)(unsigned)c1))); }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)(3u == 7u) && u3), (unsigned)(u1 == (unsigned)((int)(unsigned)s1 >= (int)*mp)), (u3 % ((unsigned)((short)(unsigned)w0 > (signed char)garr[u2 & 7u]) | 1u))); }
            } while (i0++ < 6u && (unsigned)(r0.x < *mp));
            if ((unsigned)(signed char)(0xffffffffu - (unsigned)((short)2u > (signed char)u0))) goto L3;
        }
    }
    g1 += (5u ? (a0[i0 & 3u] % ((unsigned)(fuel || p1) | 1u)) : (unsigned)e0);
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((int)(unsigned)((int)3u >= (int)0xffffffffu) >= (int)0xb1b8f0cdu));
        v0 = (1u % (fuel | 1u));
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((int)r0.y >= (int)(0x10000u * 0xee537197u)), ((unsigned)w0 % (3u | 1u)), r0.x); }
        if (0xa424366eu) {
            if (i0) break;
            u2 = u2 * 0x9e3779b1u + (unsigned)(unsigned char)(0x10000u * (unsigned)(signed char)(p0 & (unsigned)e0));
            switch (i1 & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(x0 >> 70), ((unsigned)(u3 || (unsigned)s0) - u1), p2); }
                r0.y ^= (~(((unsigned)c1 % (-(a0[i0 & 3u] + (unsigned)c1) | 1u)) + (unsigned)e0) - i1);
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        c1 = (signed char)(unsigned)c1;
                    }
                    for (;;) { if (--fuel == 0u) goto done;
                        if (((unsigned)l0 + 1u)) {
                            case 4u: ;
                            v0 = (unsigned)((garr[u2 & 7u] ^ (unsigned)s1) || (6u >> (0x8aece428u & 31u)));
                            u1 = (unsigned)(0x6d935eaau == (0x2c2d1129u >> (0xffffffffu & 31u)));
                            r0.y ^= ((g0 & fuel) & (-(unsigned)((unsigned)h1 == a0[u1 & 3u]) % (i2 | 1u)));
                            default: ;
                        }
                        if (budget != 0u) { budget -= 1u; u2 = fn2((((unsigned)c1 << ((unsigned)c1 & 31u)) / (0x5e5c44cu | 1u)), (unsigned)((int)(unsigned)l0 < (int)(r0.x >> (3u & 31u))), ~(g0 + (fuel + m0))); }
                        r0.x = (unsigned)((short)u2 > (signed char)g1);
                        case 2u: ;
                        r0.y ^= (5u ^ (unsigned)!((unsigned)f0 % ((unsigned)(unsigned char)(0xcfc75160u >> (0x8f86991bu & 31u)) | 1u)));
                    }
                    r0.x = garr[u2 & 7u];
                    break; (void)(u2);
                    for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        continue; (void)(((0xad29ea9eu * (unsigned)b0) >> (0x4ff37a6au & 31u)));
                        v0 = (unsigned)((int)-(g0 % ((unsigned)((5u | (unsigned)x0) == 0x7fffffffu) | 1u)) >= (int)0x10000u);
                    }
                }
            }
        } else {
            g1 += (unsigned)((int)(unsigned)h0 >= (int)(unsigned)((m0 ^ p1) == (unsigned)c1));
            if ((unsigned)e0) {
                { unsigned t5; double z5; if (((unsigned)(short)(i2 & (unsigned)(x0 >> 70))) & 1u) { t5 = r0.x; z5 = (double)(((unsigned)((int)1u < (int)((unsigned)h1 | p0))) & 255u); } if (((unsigned)(short)(i2 & (unsigned)(x0 >> 70))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                    garr[(unsigned)(w0 >> 29) & 7u] = (0xa18875b1u << (a0[i0 & 3u] & 31u));
                    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((short)fuel > (signed char)i0), -(0x10000u >> (7u & 31u)), (0u | (unsigned)b0)); }
                    x0 = x0 * 0x100000001b3ull + ((unsigned)c0 ^ (0x2e75526cu & g1));
                    for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)e0, 1u, (unsigned)e0); }
                        goto L1;
                        if ((unsigned)((int)(unsigned)d0 >= (int)3u)) break;
                        if (g0) continue;
                        if (*q0) continue;
                        if (0x81ee333cu) break;
                    }
                    s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(unsigned)((int)8u >= (int)garr[u2 & 7u]));
                    if ((unsigned)((int)(5u + (unsigned)s1) < (int)(unsigned)s0)) break;
                }
                i0 = (garr[u2 & 7u] % (u0 | 1u)) & 15u;
                r0.y ^= (((unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)s0) >> (~(unsigned)(p2 || i0) & 31u)) << ((unsigned)w0 & 31u));
                break; (void)(4u);
                l0 = (long)((unsigned long)l0 + (unsigned)((short)(unsigned)(signed char)(unsigned)((int)(unsigned)x0 >= (int)(unsigned)((unsigned)((short)(unsigned)c0 > (signed char)u0) && i1)) > (signed char)0x80000000u));
                e0 = e0 * 0.5L + (long double)((unsigned)((0x2fdb898u % (m0 | 1u)) && ((unsigned)d0 | 0xb47231e7u)) & 1023u);
            } else {
                x0 = x0 * 0x100000001b3ull + 0x10000u;
            }
            b0 = (unsigned)(0xa4d26cf2u == (unsigned)h0) != 0u;
            break; (void)(m0);
        }
    } while (i0++ < 6u && (unsigned)(short)(unsigned)((r0.x << (0x7fffffffu & 31u)) || 0x9199c7du));
    { unsigned t6; double z6; if ((((unsigned)!(unsigned)((int)0x10000u >= (int)garr[i1 & 7u]) | 1u)) & 1u) { t6 = ((unsigned)((unsigned)s0 && p2) % ((unsigned)c1 | 1u)); z6 = (double)(((unsigned)(p2 && ((unsigned)(x0 >> 70) % (0x7fffffffu | 1u)))) & 255u); } if ((((unsigned)!(unsigned)((int)0x10000u >= (int)garr[i1 & 7u]) | 1u)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1(v0, (unsigned)((int)((unsigned)e0 + a0[u1 & 3u]) >= (int)(unsigned)b0), (unsigned)(0xffffffffu == p0)); }
        }
        goto L3;
    }
    if ((fuel | (i0 - (unsigned)w0))) goto L0;
    s0 = (int)((((unsigned)f0 - 0xe9ba74f9u) + (unsigned)(signed char)(a0[u1 & 3u] - 9u)) << (0x10000u & 31u));
    garr[(unsigned)e0 & 7u] = u3;
    goto L0;
    g0 = (unsigned)((int)(unsigned)h1 < (int)a0[i0 & 3u]);
    v0 = ((unsigned)s0 << ((unsigned)f0 & 31u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while (i0++ < 2u && ((unsigned)f0 % ((r0.y << (u2 & 31u)) | 1u))) { if (--fuel == 0u) goto done;
        r0.x = (((unsigned)w0 - (unsigned)(x0 >> 70)) << ((unsigned)(short)(0x7fffffffu ^ p2) & 31u));
        u0 ^= (unsigned)w0;
        for (;;) { if (--fuel == 0u) goto done;
            break; (void)((v0 << (fuel & 31u)));
        }
        do { if (--fuel == 0u) goto done;
            while (i2++ < 6u && (unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((unsigned)b0 < 0x7b7e9370u), (unsigned)(short)(0xffffffffu / (3u | 1u)), (unsigned)!(r0.y - m0)); }
                s0 = (int)(unsigned)((unsigned)(p2 || 0x4c12dd9bu) || a0[i0 & 3u]);
                m0 ^= (unsigned)!(p2 ^ (unsigned)((int)(unsigned)c0 >= (int)(0xffffffffu ? *mp : u2)));
            }
            r0.x = (unsigned)(garr[u2 & 7u] || 0x49c37240u);
            if ((a0[i0 & 3u] * 0x2c459198u)) {
                if (budget != 0u) { budget -= 1u; u1 = fn1((u2 / ((unsigned)(short)(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)x0) | 1u)), ((unsigned)((unsigned)w0 && garr[u2 & 7u]) >> (*mp & 31u)), (unsigned)(unsigned char)(i2 | p1)); }
                if (g1) break;
                w0 ^= (unsigned long long)a0[u1 & 3u] << ((0x10000u * (unsigned)s0) & 63u);
                L0: if (--fuel == 0u) goto done;
                u1 += (unsigned)((int)(fuel | 0x8d8609edu) >= (int)i0);
                for (;;) { if (--fuel == 0u) goto done;
                    L1: if (--fuel == 0u) goto done;
                    if (m0) goto L0;
                }
            }
            garr[(4u % (0xe9c4ffe5u | 1u)) & 7u] = (unsigned)(unsigned char)(u3 * (unsigned)w0);
        } while (i1++ < 7u && (unsigned)((short)0x10000u > (signed char)(unsigned)s1));
        h1 = (unsigned short)(h1 + (0x80000000u ^ (garr[u2 & 7u] + 0xffffffffu)));
    }
    v0 = ((unsigned)l0 - *q0);
    if (*mp) goto L0;
    while (i0++ < 2u && (unsigned)!(unsigned)((unsigned)c1 < garr[u2 & 7u])) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (u0) {
                u2 ^= (unsigned)(0xc41843f4u || (unsigned)((int)i1 >= (int)(unsigned)((int)a0[i0 & 3u] >= (int)p2)));
                h0 = (short)(0x80000000u << (u2 & 31u));
                L2: if (--fuel == 0u) goto done;
            }
            c0 = (unsigned char)(unsigned)((int)((p1 | *q0) >> (i1 & 31u)) < (int)(unsigned)s1);
            r0.x = (unsigned)x0;
        }
    }
    if (u2) goto L1;
    if ((unsigned)((int)(unsigned)(short)(unsigned)((int)0x10000u >= (int)v0) >= (int)a0[u1 & 3u])) goto L0;
    if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((int)v0 < (int)p1), 0x7fffffffu, (unsigned)(w0 >> 29)); }
    if ((unsigned)((u0 << (*mp & 31u)) || u2)) {
        *q0 += (unsigned)((unsigned)d0 || (unsigned)(3u < ~((garr[u2 & 7u] / (i1 | 1u)) % ((unsigned)s0 | 1u))));
        if ((((unsigned)(w0 >> 29) << (v0 & 31u)) | 5u)) goto L1;
        *q0 += (unsigned)((unsigned)((unsigned)((unsigned)h0 == (unsigned)((int)u0 < (int)garr[i1 & 7u])) < (unsigned)h1) < r0.x);
    }
    a0[(unsigned)(r0.x < (unsigned)l0) & 3u] = (unsigned)(signed char)(unsigned)((short)((0x80000000u - i2) << (5u & 31u)) > (signed char)(p0 & 0x17b11bc4u));
    h0 = (short)0x7fffffffu;
    goto L1;
    do { if (--fuel == 0u) goto done;
        while (i1++ < 5u && (unsigned)(signed char)((unsigned)h1 / (v0 | 1u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)((int)u3 < (int)1u), (unsigned)w0, 1u); }
            v0 = (unsigned)x0;
            if ((0xffffffffu | (unsigned)h0)) goto L2;
            l0 = (long)((unsigned long)l0 + (((unsigned)(u1 < a0[i0 & 3u]) * ((unsigned)h1 >> (i2 & 31u))) << (a0[u1 & 3u] & 31u)));
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(v0 == 0x10000u)) {
                    if (budget != 0u) { budget -= 1u; u0 = fn2(garr[i1 & 7u], 0xffffffffu, (unsigned)(short)(0xffffffffu - (unsigned)((int)a0[i0 & 3u] >= (int)a0[i0 & 3u]))); }
                    w0 = w0 * 6364136223846793005ull + (unsigned)(3u || (unsigned)(fuel || m0));
                } else {
                    w0 ^= (unsigned long long)-(u1 ^ i1) << ((((unsigned)w0 & 1u) << ((unsigned)(9u || ((unsigned)s0 ^ 0x10000u)) & 31u)) & 63u);
                    if ((unsigned)((int)(unsigned)b0 >= (int)(0xb4f589f1u % ((unsigned)c1 | 1u)))) {
                        if ((unsigned)!(unsigned)((unsigned)c0 < 7u)) continue;
                        break; (void)((unsigned)(0x10000u && 3u));
                        L3: if (--fuel == 0u) goto done;
                    }
                    if ((unsigned)(short)(0x521e585eu - 0xffffffffu)) goto L3;
                }
                L4: if (--fuel == 0u) goto done;
                i1 = (unsigned)((int)(unsigned)c0 < (int)(unsigned)((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)h0) || 4u)) & 15u;
                if (i2) break;
            }
        }
        if ((unsigned)c1) {
            a0[(0xffffffffu & 0xffffffffu) & 3u] = 0x10000u;
            if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)*mp < (int)*mp), ((unsigned)(r0.y < u0) & (unsigned)h0), (unsigned)(*mp < 2u)); }
            e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(short)(unsigned)((int)0x7fffffffu < (int)(unsigned)((int)(unsigned)s0 >= (int)0x80000000u)) && g0) & 1023u);
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)b0, g1, ((unsigned)((unsigned)s0 < r0.y) * fuel)); }
            break; (void)((unsigned)(signed char)(unsigned)(((unsigned)e0 | 0x7c459096u) == v0));
        }
    } while (i0++ < 3u && a0[i0 & 3u]);
    { unsigned t0; double z0; if (((unsigned)h1) & 1u) { t0 = (unsigned)((int)fuel >= (int)(unsigned)b0); z0 = (double)(((fuel | 0x7fffffffu)) & 255u); } if (((unsigned)h1) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        i0 = ((u1 ? (unsigned)c0 : (unsigned)w0) | (0x2f90d8e8u << (3u & 31u))) & 15u;
        u0 += 0x905d8c08u;
    }
    if (u3 == 7u) return (unsigned)((short)i0 > (signed char)0x7abeeec3u);
    goto L3;
    *q0 += (unsigned)w0;
    if (budget != 0u) { budget -= 1u; u3 = fn0(-(unsigned)((unsigned)(signed char)(0x7fffffffu ^ r0.y) < u1), (unsigned)((short)g1 > (signed char)0x7fffffffu), (unsigned)((int)0x2f0a959u < (int)(unsigned)l0)); }
    if (u3 == 7u) return ((unsigned)((g0 & (unsigned)s1) == (unsigned)w0) ^ (unsigned)c1);
    goto L2;
    if (u3 == 7u) return (unsigned)(((unsigned)e0 >> (*mp & 31u)) == (fuel / (9u | 1u)));
    if ((((unsigned)h1 - 6u) & *mp)) goto L1;
    goto L4;
    if ((unsigned)l0) {
        goto L0;
        if (budget != 0u) { budget -= 1u; u3 = fn1(0x6fd3727cu, (unsigned)((short)(0x76ef3753u ^ (unsigned)c1) > (signed char)0x7fffffffu), (unsigned)((unsigned)(x0 >> 70) && 0xd23e621fu)); }
        v0 = 7u;
        if ((0x80000000u % (p1 | 1u))) goto L3;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(*q0 < 0xffffffffu), (unsigned)((int)(g1 << ((unsigned)b0 & 31u)) < (int)8u), (0x86312ec0u & ((unsigned)(x0 >> 70) / (0x7fffffffu | 1u)))); }
            if ((unsigned)h0) {
                if ((unsigned)(short)(u1 << ((unsigned)((int)(unsigned)h1 >= (int)p2) & 31u))) {
                    w0 ^= (unsigned long long)(unsigned)x0 << (garr[u2 & 7u] & 63u);
                    if ((unsigned)(u1 && ((unsigned)(w0 >> 29) << (0xffffffffu & 31u)))) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn3(((6u - 0x7b845c01u) & (unsigned)b0), (unsigned)(short)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)((short)fuel > (signed char)u1)), (unsigned)((unsigned)b0 || g1)); }
                    h0 = (short)~((unsigned)((int)g1 >= (int)(unsigned)b0) >> ((unsigned)((unsigned)x0 == m0) & 31u));
                }
                while (i1++ < 5u && (0x5d005ee8u / (0x5244848fu | 1u))) { if (--fuel == 0u) goto done;
                    if ((unsigned)(short)(0x81d5deb7u & (unsigned)h0)) break;
                    *q0 += ((0xffffffffu + (unsigned)((unsigned)f0 < (unsigned)f0)) % ((garr[i1 & 7u] >> (3u & 31u)) | 1u));
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)h1, 2u, 0x80000000u); }
                *q0 = (unsigned)((short)fuel > (signed char)((unsigned)((short)(unsigned)h0 > (signed char)p2) * p1));
            }
            b0 = (unsigned)((short)(unsigned)((short)(unsigned)d0 > (signed char)((unsigned)f0 ? 0x5f1558d9u : 5u)) > (signed char)0x83e22244u) != 0u;
            if ((m0 * (unsigned)b0)) {
                c1 = (signed char)(unsigned)c0;
                if (((unsigned)(w0 >> 29) ? (unsigned)s0 : *mp)) break;
                if ((unsigned)(short)(unsigned)((int)u3 < (int)(u3 << (i1 & 31u)))) goto L1;
                do { if (--fuel == 0u) goto done;
                    if (~(unsigned)((short)v0 > (signed char)(unsigned)((int)u1 >= (int)0xda0573eu))) goto L4;
                    w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(unsigned)(r0.y < (unsigned)w0);
                } while (i1++ < 5u && (unsigned)((unsigned)(0x7fffffffu < 0xffffffffu) || *mp));
            }
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                s0 = (int)((unsigned)f0 & (unsigned)(0u < r0.x));
            }
            c1 = (signed char)(v0 + g0);
        } while (i0++ < 5u && ((unsigned)(a0[u1 & 3u] || i0) | garr[u2 & 7u]));
    }
    if (p0) goto L3;
    { unsigned t1; double z1; if ((0x57762e41u) & 1u) { t1 = (unsigned)l0; z1 = (double)(((unsigned)(short)(unsigned)((unsigned)(w0 >> 29) == (unsigned)c0)) & 255u); } if ((0x57762e41u) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        a0[(3u ^ i2) & 3u] = ((unsigned)(0x30786df3u < (unsigned)s1) * ((unsigned)s1 ? *mp : (unsigned)s1));
        if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)e0 ? u0 : (unsigned)b0), (((unsigned)l0 ^ (unsigned)c0) * 0x87dbc076u), (unsigned)c1); }
    }
    if ((unsigned)((unsigned)s0 < fuel)) {
        goto L4;
        w0 ^= (unsigned long long)(v0 ^ u3) << ((unsigned)(0x73e87325u < (unsigned)l0) & 63u);
        { unsigned t2; double z2; if ((7u) & 1u) { t2 = (unsigned)(p1 < (unsigned)((unsigned)s0 || u2)); z2 = (double)((((unsigned)c0 ? garr[i1 & 7u] : 0xffffffffu)) & 255u); } if ((7u) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                q0 = &garr[~(unsigned)((int)(unsigned)((int)i2 < (int)u0) < (int)0x7fffffffu) & 7u];
            }
            goto L2;
            while (i0++ < 4u && (unsigned)!(0x10000u * 0xb08b5629u)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)c0, ((unsigned)x0 << ((unsigned)d0 & 31u)), (0x80000000u + ((unsigned)w0 >> (fuel & 31u)))); }
                r0.x = (((unsigned)x0 << ((((unsigned)s0 * i1) % (g0 | 1u)) & 31u)) ^ (unsigned)h0);
                if (fuel < 8u) return ((unsigned)(p0 && (unsigned)(signed char)(unsigned)(5u || i1)) >> ((unsigned)e0 & 31u));
                goto L2;
                if ((unsigned)e0) {
                    h0 = (short)((unsigned)c0 * (unsigned)((unsigned)(signed char)(unsigned)(0u || (unsigned)c1) == ((unsigned)h0 * (unsigned)s1)));
                    d0 = d0 * 0.5 + (double)((unsigned)l0 & 1023u);
                    if (~(unsigned)(p0 || (unsigned)(1u && 0xc025fb08u))) break;
                    w0 ^= (unsigned long long)0x7fffffffu << (((0xb9422143u + (unsigned)(m0 && 0xb8d86f4fu)) / ((unsigned)d0 | 1u)) & 63u);
                    g1 += (unsigned)((short)fuel > (signed char)1u);
                } else {
                    c1 = (signed char)(unsigned)((i2 | 0xffffffffu) && ((unsigned)x0 ? u1 : 0xde314c6bu));
                    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)e0 * (unsigned)(short)((unsigned)b0 * (unsigned)h0)), (unsigned)(w0 >> 29), (unsigned)h0); }
                    u3 = u3 * 0x9e3779b1u + u1;
                    s0 = (int)((0xa1ee39ccu >> (r0.y & 31u)) ^ (unsigned)((int)fuel < (int)p1));
                }
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if (0x80000000u) break;
                    } while (i2++ < 6u && (a0[i0 & 3u] & (unsigned)x0));
                    if (-(0x359bf4f8u ^ (p2 << (r0.y & 31u)))) continue;
                    if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((unsigned)l0 == (unsigned)s0), (unsigned)((int)0x80000000u < (int)(u3 << (0x80000000u & 31u))), 0x7f526fb3u); }
                    if ((*q0 * (unsigned)(x0 >> 70))) break;
                    if ((unsigned)((short)(unsigned)d0 > (signed char)5u)) break;
                }
            }
        }
    } else {
        e0 = e0 * 0.5L + (long double)((((unsigned)d0 << (0u & 31u)) + p2) & 1023u);
        c0 = (unsigned char)(p1 ? (unsigned)((unsigned)(w0 >> 29) && u3) : v0);
    }
    if (-((unsigned)f0 ^ (unsigned)s0)) goto L3;
    if (p1) {
        g1 += 0x80000000u;
        if ((unsigned)e0) goto done;
        if (u3 == 7u) return (unsigned)((int)(unsigned)((short)i0 > (signed char)g1) >= (int)(i1 / (((unsigned)c0 ^ *mp) | 1u)));
    } else {
        l0 = (long)((unsigned long)l0 + ((garr[i1 & 7u] - r0.x) & 4u));
    }
    w0 ^= (unsigned long long)(unsigned)(unsigned char)((unsigned)x0 / (p0 | 1u)) << ((unsigned)l0 & 63u);
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)(unsigned)s1 < (int)(0xb1da7af0u >> ((unsigned)c1 & 31u))), (unsigned)((unsigned)!(unsigned)((unsigned)(x0 >> 70) && (unsigned)(x0 >> 70)) < *mp), (g0 & r0.y)); }
    if (u0) goto L4;
    u0 ^= ((unsigned)((int)0x5491dda0u < (int)*mp) + ((unsigned)c1 ^ r0.y));
    do { if (--fuel == 0u) goto done;
        b0 = (unsigned)!(0x5aa5810u * ((4u + r0.y) * ((unsigned)f0 | m0))) != 0u;
        if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)x0, (unsigned)w0, ~(unsigned)((unsigned)(w0 >> 29) || 0x80000000u)); }
        v0 = ((unsigned)c0 << (0xffffffffu & 31u));
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            garr[u0 & 7u] = ((unsigned)h1 / (((0x80000000u | 2u) * (unsigned)(short)(unsigned)((unsigned)x0 == (unsigned)w0)) | 1u));
        }
    } while (i0++ < 3u && (unsigned)((unsigned)(unsigned char)((unsigned)(x0 >> 70) ^ u1) < u0));
    if ((unsigned)((unsigned)s0 < (unsigned)(unsigned char)(unsigned)((short)g1 > (signed char)u3))) {
        b0 = (5u << ((v0 ^ ~(0x80000000u % (g1 | 1u))) & 31u)) != 0u;
        if ((u3 + fuel)) goto L0;
        { unsigned t3; double z3; if (((unsigned)(p1 == (unsigned)w0)) & 1u) { t3 = (((unsigned)f0 >> (garr[u2 & 7u] & 31u)) - i1); z3 = (double)(((unsigned)(0xfa5a60e0u == (unsigned)(short)(9u + 0x15f73c89u))) & 255u); } if (((unsigned)(p1 == (unsigned)w0)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            if ((garr[u2 & 7u] & p0)) goto L2;
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)(x0 >> 70) && 0x80000000u), (unsigned)((short)u1 > (signed char)(unsigned)c0), (unsigned)(-(p1 >> (garr[i1 & 7u] & 31u)) < 0x7fffffffu)); }
            u0 += (unsigned)((garr[u2 & 7u] - (0xa08edbe3u / ((unsigned)s1 | 1u))) < (i1 - *q0));
            if (budget != 0u) { budget -= 1u; u1 = fn1((fuel | (unsigned)(w0 >> 29)), 0xae656431u, (unsigned)(short)(unsigned)((short)(unsigned)!((unsigned)f0 % (g1 | 1u)) > (signed char)9u)); }
            u1 ^= (0x6abe85fbu + ((unsigned)(g1 < m0) & (unsigned)h0));
            { unsigned t4; double z4; if ((((unsigned)(w0 >> 29) & 0xbb3e4c84u)) & 1u) { t4 = ((unsigned)w0 | 0x7fffffffu); z4 = (double)(((unsigned)((int)0xcf8d8145u < (int)(unsigned)((unsigned)c0 || 2u))) & 255u); } if ((((unsigned)(w0 >> 29) & 0xbb3e4c84u)) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                if (-(3u / (v0 | 1u))) {
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)((unsigned)c1 == -(2u + a0[i0 & 3u]))) break;
                        if (i2) break;
                        h1 = (unsigned short)(h1 + (m0 - ((unsigned)s0 % (g0 | 1u))));
                        r0.y ^= ((unsigned)(a0[u1 & 3u] && (unsigned)l0) * (unsigned)(a0[u1 & 3u] && (unsigned)d0));
                        s0 = (int)(unsigned)((unsigned)f0 && i0);
                        break; (void)(0x10000u);
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(signed char)(unsigned)(5u == (0x80000000u << (0x80000000u & 31u))), (unsigned)((int)8u < (int)0xb7446928u), (unsigned)((int)a0[i0 & 3u] >= (int)p0)); }
                    f0 = f0 * 0.5f + (float)((unsigned)(garr[u2 & 7u] || (unsigned)((int)(3u / (i1 | 1u)) >= (int)0xc1cc72e5u)) & 255u);
                } else {
                    l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)(0xffffffffu < 0x7fffffffu) == 4u) % ((unsigned)((short)(unsigned)c0 > (signed char)m0) | 1u)));
                    q0 = &garr[*q0 & 7u];
                    g0 = ((r0.y * (unsigned)((int)8u < (int)2u)) + (unsigned)(w0 >> 29));
                    r0.y ^= (unsigned)(0x10000u || r0.y);
                }
                if (0x7fffffffu) goto L1;
                *q0 = (unsigned)((8u * ((unsigned)b0 / ((unsigned)(x0 >> 70) | 1u))) < (unsigned)l0);
                do { if (--fuel == 0u) goto done;
                    u0 = (unsigned)((int)(0x7fffffffu >> (p2 & 31u)) >= (int)(9u % (0x65e4b10u | 1u)));
                    *q0 = r0.y;
                } while (i0++ < 3u && (unsigned)((int)(unsigned)!(unsigned)((unsigned)(w0 >> 29) && (unsigned)c1) < (int)a0[u1 & 3u]));
                goto L3;
            }
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)(i0 - r0.x), (unsigned)((short)(unsigned)h1 > (signed char)i1), (0x1e995f0au - p2)); }
        if (((unsigned)l0 - 0x5c976fb1u)) goto L2;
        while (((unsigned)(r0.y < u2) >> (u1 & 31u))) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                continue; (void)((*q0 * (unsigned)x0));
                if (budget != 0u) { budget -= 1u; u1 = fn3((4u & (unsigned)l0), ((unsigned)h1 / (0x10000u | 1u)), (unsigned)((int)((unsigned)c0 << (*mp & 31u)) >= (int)a0[u1 & 3u])); }
                if (((unsigned)(w0 >> 29) << (p2 & 31u))) continue;
                g1 += ((i2 / (u0 | 1u)) ? (unsigned)d0 : (unsigned)c0);
                if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((short)5u > (signed char)0xffffffffu), (p0 & (unsigned)(a0[i0 & 3u] < 0x1231bed3u)), (unsigned)((int)0x80000000u < (int)(unsigned)h1)); }
            } while (i1++ < 4u && (unsigned)x0);
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(7u == ~(0x7fffffffu | (unsigned)e0)), (unsigned)((unsigned)b0 && ((unsigned)d0 + p0)), p2); }
            s0 = (int)(0xffffffffu ^ (unsigned)((short)0x7fffffffu > (signed char)(unsigned)s0));
            { unsigned t5; double z5; if ((((unsigned)w0 | 1u)) & 1u) { t5 = (0x249e4a1du % ((unsigned)c0 | 1u)); z5 = (double)(((unsigned)((unsigned)l0 && (m0 | (unsigned)h0))) & 255u); } if ((((unsigned)w0 | 1u)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                if ((unsigned)b0) {
                    u1 = u1 * 0x9e3779b1u + -(unsigned)(p2 < u0);
                    h0 = (short)(m0 << ((0x4d8cc65du ^ g1) & 31u));
                    q0 = &garr[m0 & 7u];
                    h0 = (short)((a0[i0 & 3u] ? (u1 % (0x80000000u | 1u)) : (unsigned)(w0 >> 29)) * (unsigned)s1);
                    goto L3;
                    d0 = d0 * 0.5 + (double)(((unsigned)((unsigned)(-((unsigned)c0 & 0x10000u) || r0.x) || 0xeb98a1aeu) + p0) & 1023u);
                } else {
                    if ((unsigned)((unsigned)(signed char)(unsigned)((int)u3 >= (int)fuel) && u0)) {
                        g1 += ((unsigned)((unsigned)b0 && u2) & garr[i1 & 7u]);
                        *q0 += (unsigned)!(((unsigned)c1 | ((unsigned)s0 ? (unsigned)x0 : p2)) - i0);
                        if ((unsigned)((short)*q0 > (signed char)(unsigned)(u1 || 0x10000u))) break;
                        if (fuel < 8u) return (m0 >> ((unsigned)(0xffffffffu < ~(g1 * 0x9785bc68u)) & 31u));
                    }
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((unsigned)s0 - 0x80000000u);
                f0 = f0 * 0.5f + (float)(-(unsigned)((short)(unsigned)(0xdca5b422u || (0x3671fe77u + u2)) > (signed char)0x6dd9bc87u) & 255u);
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((0x47b367bfu & r0.x)) {
                        x0 = x0 * 0x100000001b3ull + (unsigned)(r0.y < ((unsigned)c0 << (u3 & 31u)));
                        if (budget != 0u) { budget -= 1u; u3 = fn2((0xedb2963bu ? i0 : 0x10000u), ~((unsigned)((short)fuel > (signed char)(unsigned)(w0 >> 29)) + r0.y), 8u); }
                        u1 ^= -(unsigned)(5u || 0x10000u);
                    } else {
                        h0 = (short)(unsigned)(x0 >> 70);
                        if (budget != 0u) { budget -= 1u; u1 = fn2(i0, (((unsigned)(w0 >> 29) % (0xed8b9f6eu | 1u)) + i2), ((unsigned)c1 - (unsigned)f0)); }
                        *q0 = ((unsigned)((int)(v0 | (unsigned)s0) >= (int)(9u * (unsigned)f0)) % (v0 | 1u));
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0(0xb2372003u, g1, ((0x5284a038u * g1) | 0x7fffffffu)); }
                    if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)d0 / (8u | 1u)), (unsigned)w0, (unsigned)(g0 == v0)); }
                }
                if ((unsigned)(0xffffffffu == (unsigned)((unsigned)h1 == u3))) {
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(u1, u0, i0); }
                        if ((((unsigned)l0 / (v0 | 1u)) + 0xe07e890cu)) break;
                    } while (i1++ < 7u && (unsigned)f0);
                    if ((unsigned)(p2 || (unsigned)s1)) break;
                }
                if ((unsigned)((int)0xdb89e935u >= (int)0xe429197u)) goto done;
            }
            m0 ^= (unsigned)((int)(unsigned)l0 < (int)0xaeb009d3u);
            h1 = (unsigned short)(h1 + ((unsigned)d0 % ((unsigned)((int)((unsigned)x0 << (a0[u1 & 3u] & 31u)) < (int)(unsigned)l0) | 1u)));
        }
    }
    while (i0++ < 6u && r0.y) { if (--fuel == 0u) goto done;
        if ((unsigned)(signed char)(unsigned)((short)(unsigned)l0 > (signed char)p1)) break;
        { unsigned t6; double z6; if (((unsigned)((int)v0 >= (int)0xba5b61fdu)) & 1u) { t6 = (unsigned)((int)*q0 < (int)(unsigned)(r0.x || (unsigned)h0)); z6 = (double)(((unsigned)((unsigned)c0 || (unsigned)(x0 >> 70))) & 255u); } if (((unsigned)((int)v0 >= (int)0xba5b61fdu)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            a0[i0 & 3u] = (4u & 0xc0372082u);
        }
    }
    goto L2;
    if (budget != 0u) { budget -= 1u; u3 = fn2((u3 >> (r0.x & 31u)), ((unsigned)((short)9u > (signed char)4u) ^ 1u), -(r0.x >> (p1 & 31u))); }
    { unsigned t7; double z7; if (((p1 % (p2 | 1u))) & 1u) { t7 = fuel; z7 = (double)(((i2 / ((unsigned)w0 | 1u))) & 255u); } if (((p1 % (p2 | 1u))) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)-((i2 % (a0[u1 & 3u] | 1u)) >> ((unsigned)((unsigned)f0 && a0[i0 & 3u]) & 31u));
            if (-(garr[u2 & 7u] * i1)) {
                { unsigned t8; double z8; if (((u1 / (3u | 1u))) & 1u) { t8 = (unsigned)c1; z8 = (double)(((unsigned)(short)(0x80000000u + (unsigned)((unsigned)d0 < 4u))) & 255u); } if (((u1 / (3u | 1u))) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                    r0.y ^= (p2 ^ (0x10000u << (((unsigned)(short)((unsigned)h1 ^ garr[i1 & 7u]) % (0x92762bc4u | 1u)) & 31u)));
                    if (((unsigned)f0 ? r0.y : (unsigned)c1)) continue;
                    *q0 = (unsigned)(short)((unsigned)(5u && (unsigned)s1) / ((u0 + -(*mp << (u2 & 31u))) | 1u));
                }
                break; (void)((unsigned)(signed char)(unsigned)(6u && -((unsigned)f0 - (unsigned)c1)));
                if ((unsigned)((unsigned)(x0 >> 70) == (unsigned)h1)) break;
            } else {
                if ((unsigned)((unsigned)c0 && 0x6eff50f9u)) break;
                i1 = (unsigned)((int)(unsigned)!(unsigned)(0u || i2) >= (int)(unsigned)(0u < a0[u1 & 3u])) & 15u;
                switch (u2 & 7u) {
                    case 3u: ;
                    if (budget != 0u) { budget -= 1u; u1 = fn0(~(i1 | 3u), (p1 * 3u), (unsigned)((unsigned)c1 < (unsigned)(w0 >> 29))); }
                    w0 = w0 * 6364136223846793005ull + ((unsigned)((int)(unsigned)l0 < (int)0xffffffffu) & ((unsigned)((int)(unsigned)h1 < (int)i1) % (garr[i1 & 7u] | 1u)));
                    r0.y ^= (((unsigned)x0 + 0x10000u) & u2);
                    q0 = &garr[(((unsigned)b0 & p0) % (((unsigned)b0 << (fuel & 31u)) | 1u)) & 7u];
                    case 0u: ;
                }
            }
            w0 = w0 * 6364136223846793005ull + ((unsigned)((unsigned)c1 < 0x46fff4f7u) - ((unsigned)c1 * (fuel << (u1 & 31u))));
            d0 = d0 * 0.5 + (double)((unsigned)((int)u3 < (int)(unsigned)((unsigned)d0 && 0xd179354eu)) & 1023u);
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            u1 ^= -(unsigned)((unsigned)((int)v0 >= (int)fuel) && (((unsigned)w0 | (unsigned)e0) / (0xe849fad9u | 1u)));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)e0 | (unsigned)s0), (unsigned)(garr[u2 & 7u] < (unsigned)((unsigned)c1 || 4u)), r0.x); }
        do { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                v0 = (unsigned)s0;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((*q0 % (0xfd78f8f7u | 1u)));
                    if ((-(unsigned)((int)0x572e237eu < (int)a0[u1 & 3u]) + (unsigned)x0)) continue;
                    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(g1 && (unsigned)(x0 >> 70)) - fuel), i0, ((unsigned)x0 / ((0x10000u << (p1 & 31u)) | 1u))); }
                    if ((unsigned)((unsigned)(8u && 7u) == 0x80000000u)) break;
                    h1 = (unsigned short)(h1 + (u0 % (((v0 << (0xa40e8945u & 31u)) / (0xb02f2c6fu | 1u)) | 1u)));
                    g1 += ((unsigned)(short)(unsigned)(fuel < ((unsigned)!(r0.x + u0) / (0x7fffffffu | 1u))) & 0xffffffffu);
                }
                *q0 = (unsigned)((unsigned)((short)(unsigned)(5u && 0xfb934ea7u) > (signed char)u2) || (unsigned)((int)u3 < (int)p0));
                r0.y ^= (((unsigned)c0 + p1) & (m0 + 3u));
                if ((unsigned)c1) break;
            }
            q0 = &garr[(unsigned)(unsigned char)((unsigned)(w0 >> 29) - (unsigned)(0u < 6u)) & 7u];
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t9; double z9; if (((unsigned)(u2 == 1u)) & 1u) { t9 = (unsigned)(*mp && ~(p1 + a0[i0 & 3u])); z9 = (double)(((unsigned)((int)p0 >= (int)u3)) & 255u); } if (((unsigned)(u2 == 1u)) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                    *q0 += ((u2 << ((unsigned)((short)0x10000u > (signed char)0x810613ddu) & 31u)) | v0);
                    if (0x10000u) break;
                    *mp = (unsigned)((int)((unsigned)f0 ^ (unsigned)((int)p2 >= (int)(unsigned)x0)) >= (int)(unsigned)(u1 < (unsigned)(w0 >> 29)));
                    if (3u) goto done;
                }
            }
            if ((unsigned)((short)(unsigned)b0 > (signed char)i0)) break;
        } while (i0++ < 3u && (unsigned)!(unsigned)(u1 || 0xffffffffu));
        if ((unsigned)((unsigned)l0 < p0)) goto L2;
        v0 = ((unsigned)((short)(unsigned)s0 > (signed char)((unsigned)(w0 >> 29) >> (u0 & 31u))) / ((unsigned)f0 | 1u));
    }
    u0 = u0 * 0x9e3779b1u + ((i2 & 6u) % (((unsigned)e0 >> (g1 & 31u)) | 1u));
    if (0x91520d4fu) {
        if ((unsigned)w0) goto L2;
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)(unsigned)((unsigned)((unsigned)(w0 >> 29) < garr[u2 & 7u]) && 0x80000000u)) break;
            s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)s1 < (int)(unsigned)l0));
            if ((unsigned)w0) break;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(p1 || u0), a0[i0 & 3u], r0.x); }
    } else {
        while (i0++ < 5u && ((unsigned)s0 * u0)) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)-(unsigned)(g1 && *mp) << ((0x7fffffffu << (7u & 31u)) & 63u);
        }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            *mp = (unsigned)(-(0x7fffffffu * u3) && (unsigned)l0);
        }
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = i2;
        while (i1++ < 3u && (i2 << (((unsigned)b0 - a0[i0 & 3u]) & 31u))) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((int)0x10000u < (int)0x9a5ead03u));
            c0 = (unsigned char)((unsigned)(u1 < m0) & (unsigned)((int)(a0[u1 & 3u] + 0xaecf30deu) < (int)(unsigned)h1));
        }
    }
    do { if (--fuel == 0u) goto done;
        switch ((unsigned)((int)(unsigned)(0x2191b56fu == 0xffffffffu) < (int)0x80000000u) & 7u) {
            *q0 = (6u % (((unsigned)h0 | (6u - (unsigned)c0)) | 1u));
        }
        if ((0x7fffffffu % ((unsigned)h0 | 1u))) break;
        if ((i0 & (unsigned)(g0 || garr[u2 & 7u]))) goto L2;
        if ((unsigned)(r0.y || (unsigned)l0)) break;
        *q0 += (unsigned)x0;
        u3 ^= (unsigned)((short)(unsigned)(((unsigned)(x0 >> 70) + v0) && (unsigned)!(unsigned)(i0 == i2)) > (signed char)0x10000u);
    } while (i0++ < 6u && 0x7c247381u);
    if (0x57fac4a4u) goto done;
    if ((unsigned)(unsigned char)((unsigned)h0 << ((unsigned)((unsigned)s0 < (unsigned)s0) & 31u))) {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((i2 % (((unsigned)c0 ^ garr[i1 & 7u]) | 1u)));
        }
    }
    switch ((0x4042620au % ((u1 % ((unsigned)(x0 >> 70) | 1u)) | 1u)) & 7u) {
        { unsigned t10; double z10; if (((unsigned)h1) & 1u) { t10 = 0x38cef8e4u; z10 = (double)(((p2 - r0.x)) & 255u); } if (((unsigned)h1) & 1u) { u2 += t10; d0 = d0 * 0.5 + z10; }
            case 2u: ;
            u0 ^= (a0[i0 & 3u] >> ((unsigned)(*mp == garr[i1 & 7u]) & 31u));
        }
        *q0 += (unsigned)((unsigned)((unsigned)c1 < 0x80000000u) == (unsigned)h0);
        h0 = (short)0x7fffffffu;
        a0[(0x7fffffffu / (i1 | 1u)) & 3u] = (unsigned)c1;
    }
    while (i0++ < 6u && ((r0.y | 3u) * g0)) { if (--fuel == 0u) goto done;
        if ((u3 ? i0 : 0x1d09c03fu)) continue;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((unsigned)h1 & 255u);
            { unsigned t11; double z11; if ((u0) & 1u) { t11 = 0x97e0747u; z11 = (double)((p0) & 255u); } if ((u0) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
                a0[g0 & 3u] = (unsigned)((0x23e61e80u % ((unsigned)c0 | 1u)) || (unsigned)(short)(2u ? (unsigned)f0 : 0x54061e1fu));
                d0 = d0 * 0.5 + (double)((unsigned)(i2 < (unsigned)(i1 && p0)) & 1023u);
                garr[(r0.x + *q0) & 7u] = ((unsigned)((int)(unsigned)e0 >= (int)u1) - (unsigned)c0);
                if (~(unsigned)((short)~(a0[u1 & 3u] | 2u) > (signed char)p0)) goto L0;
                if ((unsigned)s0) break;
            }
            h0 = (short)(unsigned)((int)7u >= (int)r0.x);
            if ((*mp - 0x7fffffffu)) {
                if ((u0 << (r0.x & 31u))) break;
            } else {
                q0 = &garr[(((u2 % ((unsigned)(x0 >> 70) | 1u)) << (p0 & 31u)) << (0x407b2675u & 31u)) & 7u];
            }
        }
        v0 = garr[i1 & 7u];
        b0 = i1 != 0u;
        if (budget != 0u) { budget -= 1u; u1 = fn2(garr[u2 & 7u], (unsigned)(m0 || 0x76bce9a8u), ((a0[i0 & 3u] * p0) % ((unsigned)s1 | 1u))); }
    }
    *q0 += ((unsigned)((int)u1 < (int)garr[i1 & 7u]) / ((unsigned)f0 | 1u));
    if (0x675ab2ceu) goto L2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 14u, 0xedb898abu, 0x41478b09u },
        { 6u, 0xe54a9d31u, 0x13219309u },
        { 9u, 0x4766afb8u, 0x65596709u },
        { 15u, 0xf1f58915u, 0xf9989ce3u },
        { 7u, 0x11748d9u, 0x4733279au },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
