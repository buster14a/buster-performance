// test-ssa-source's program of seed 141000446 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x266c70f6u, g1 = 0xf15ff00cu;
static unsigned garr[8] = { 0x48ff3ad7u, 0x4a4c2fdbu, 0x92899580u, 0xff86f119u, 0x86259e79u, 0xbe0b5bf7u, 0x5e0118e9u, 0xc47fa91fu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    l0 = (long)((unsigned long)l0 + g1);
    { unsigned t0; double z0; if (((unsigned)c1) & 1u) { t0 = ((unsigned)(w0 >> 29) % ((i0 % (2u | 1u)) | 1u)); z0 = (double)((4u) & 255u); } if (((unsigned)c1) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        L0: if (--fuel == 0u) goto done;
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(*mp);
        if (((0xd2c41af9u | u0) / (p0 | 1u))) break;
        v0 = 4u;
        switch (((unsigned)d0 << ((m0 % ((unsigned)d0 | 1u)) & 31u)) & 7u) {
            L1: if (--fuel == 0u) goto done;
            *q0 = (v0 % (0x2e7b9095u | 1u));
            d0 = d0 * 0.5 + (double)((r0.x / ((i0 & 0x86f87015u) | 1u)) & 1023u);
            w0 = w0 * 6364136223846793005ull + ((unsigned)(0xa2007712u == (0xf188356u % (a0[i0 & 3u] | 1u))) & (unsigned)(w0 >> 29));
            L2: if (--fuel == 0u) goto done;
            case 3u: ;
        }
    }
    if (u3 == 7u) return ((0xfcf2e0d6u / (u2 | 1u)) / (p1 | 1u));
    do { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (unsigned)((int)(unsigned)(signed char)(6u ? (unsigned)s1 : (0x10000u % (7u | 1u))) < (int)(unsigned)h1);
        c0 = (unsigned char)(unsigned)(*mp || ((unsigned)((unsigned)c1 < 0xa5ff89d4u) % (0x1d800921u | 1u)));
        if ((unsigned)((unsigned)(6u && 2u) == *mp)) continue;
    } while (i0++ < 3u && (unsigned)(0x86b07d1bu || 5u));
    goto L0;
    if (0x10000u) goto L3;
    u0 = u0 * 0x9e3779b1u + (unsigned)((int)((unsigned)s0 >> (((unsigned)f0 & (unsigned)((short)0x80000000u > (signed char)2u)) & 31u)) >= (int)garr[i1 & 7u]);
    g0 = ((unsigned)((unsigned)(x0 >> 70) == 0x9e9c6e44u) & (unsigned)h0);
    if ((unsigned)(signed char)(garr[u2 & 7u] >> ((unsigned)s1 & 31u))) {
        u1 += ((unsigned)(unsigned char)(garr[u2 & 7u] + (unsigned)s1) | (unsigned)(0xffffffffu && r0.y));
        u2 += (r0.y % (*q0 | 1u));
    }
    l0 = (long)((unsigned long)l0 + (unsigned)((garr[i1 & 7u] >> ((unsigned)h0 & 31u)) == (unsigned)(p2 && 0x10000u)));
    if ((4u - (unsigned)((short)u3 > (signed char)0x7fffffffu))) {
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((int)0xffffffffu >= (int)(unsigned)s1) || g0));
        do { if (--fuel == 0u) goto done;
            g1 += (((unsigned)c1 & 0x21b74596u) ? 0x5e772c4bu : (unsigned)c1);
            if (u3 == 7u) return (unsigned)((short)(unsigned)((short)0x7fffffffu > (signed char)((unsigned)e0 * (unsigned)s1)) > (signed char)(unsigned)(unsigned char)(p0 >> (r0.x & 31u)));
            l0 = (long)((unsigned long)l0 + u2);
        } while (i0++ < 3u && (unsigned)((short)(unsigned)(short)(unsigned)((short)0x80000000u > (signed char)(unsigned)d0) > (signed char)u2));
        u1 += (r0.y >> ((g0 / ((unsigned)c1 | 1u)) & 31u));
    }
    *q0 += (unsigned)((short)garr[i1 & 7u] > (signed char)((unsigned)((unsigned)s0 == 0xffffffffu) + v0));
    switch ((unsigned)(u1 == (unsigned)((int)0x10000u < (int)*q0)) & 7u) {
        L3: if (--fuel == 0u) goto done;
        garr[i2 & 7u] = 0xffffffffu;
        w0 = w0 * 6364136223846793005ull + 0xffffffffu;
    }
    while ((g1 << (fuel & 31u))) { if (--fuel == 0u) goto done;
        if ((unsigned)((unsigned)l0 == 0x7fffffffu)) {
            r0.y ^= (unsigned)!(unsigned)((short)(unsigned)e0 > (signed char)0x353fe8a5u);
            switch (((unsigned)s0 & (unsigned)d0) & 7u) {
                w0 = w0 * 6364136223846793005ull + ((unsigned)(signed char)(0xffffffffu * i0) - (0x80000000u ^ (unsigned)((unsigned)h1 && 0x80000000u)));
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 3u: ;
                    L4: if (--fuel == 0u) goto done;
                    case 2u: ;
                    *mp = (unsigned)((unsigned)c1 == (unsigned)((short)i1 > (signed char)(unsigned)(*q0 || (unsigned)(unsigned char)(unsigned)((int)a0[i0 & 3u] >= (int)0x4509839fu))));
                    for (;;) { if (--fuel == 0u) goto done;
                        m0 ^= (unsigned)((unsigned)((unsigned)c0 || 0x97b83604u) < u3);
                        c1 = (signed char)(0xfc5c0c7eu << ((unsigned)(signed char)(unsigned)(u1 == u2) & 31u));
                        default: ;
                    }
                }
                c0 = (unsigned char)(4u % (fuel | 1u));
                if (((unsigned)(w0 >> 29) / ((u0 | g1) | 1u))) break;
                b0 = (unsigned)((garr[u2 & 7u] * u3) < (unsigned)(*mp || a0[i0 & 3u])) != 0u;
                garr[(unsigned)((unsigned)e0 < (unsigned)l0) & 7u] = (9u % ((unsigned)h1 | 1u));
            }
        }
        break; (void)((p1 / (0x7570c157u | 1u)));
        while (i1++ < 4u && 0x3abbaab0u) { if (--fuel == 0u) goto done;
            c1 = (signed char)0x991a5e28u;
        }
        if ((unsigned)(short)(unsigned)((int)(unsigned)c1 >= (int)v0)) break;
    }
    if (u3 == 7u) return (unsigned)(u0 < (unsigned)s1);
    if (m0) goto L1;
    *q0 += ((unsigned)(i1 || (unsigned)w0) + 0u);
    u1 = u1 * 0x9e3779b1u + ((u2 ? (unsigned)(x0 >> 70) : u2) * g0);
    h1 = (unsigned short)(h1 + -(unsigned)((short)(2u & (unsigned)w0) > (signed char)0x78dd3d7u));
    if ((r0.x * u0)) goto done;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)f0 - -(unsigned)((unsigned)h1 || 0x7f278f97u))) break;
    }
    switch (r0.y & 7u) {
        if ((unsigned)e0) {
            if (~(garr[u2 & 7u] + p0)) {
                do { if (--fuel == 0u) goto done;
                    case 1u: ;
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(short)((p2 / (m0 | 1u)) / (0x5f9cdf5au | 1u)) && 0x7fffffffu));
                } while (i0++ < 5u && (unsigned)!(*mp % (p2 | 1u)));
            } else {
                case 3u: ;
            }
            while (i0++ < 5u && (r0.x / (u2 | 1u))) { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    c1 = (signed char)(r0.x | (*mp / ((4u * *q0) | 1u)));
                    case 7u: ;
                    { unsigned t1; double z1; if (((unsigned)c1) & 1u) { t1 = ((unsigned)d0 - 0x9bf58e53u); z1 = (double)(((unsigned)((int)(0x42ee86dfu | 3u) >= (int)u2)) & 255u); } if (((unsigned)c1) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                        case 2u: ;
                        i0 = ((unsigned)b0 % ((unsigned)(short)(~(unsigned)(((unsigned)h1 << (0xffffffffu & 31u)) && 0xffffffffu) % (r0.y | 1u)) | 1u)) & 15u;
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)i0 >= (int)(unsigned)x0));
                        f0 = f0 * 0.5f + (float)((unsigned)(short)(g1 >> ((i0 >> ((8u & 0x36cc2360u) & 31u)) & 31u)) & 255u);
                        case 5u: ;
                    }
                }
                if ((unsigned)((unsigned)((int)(unsigned)c1 >= (int)m0) < (unsigned)(x0 >> 70))) {
                    case 6u: ;
                    case 0u: ;
                    i0 = 5u & 15u;
                    if ((4u * 4u)) break;
                    case 4u: ;
                } else {
                    r0.y ^= (unsigned)(short)((unsigned)(0x3ef83ca0u < (unsigned)b0) >> ((unsigned)((unsigned)s1 || (unsigned)(w0 >> 29)) & 31u));
                    default: ;
                    if ((unsigned)(0x1c4155e3u && (i2 | 1u))) break;
                    if (p0) continue;
                }
                do { if (--fuel == 0u) goto done;
                    break;
                    break;
                    break;
                    goto L1;
                    s0 = (int)((unsigned)(signed char)(unsigned)(0x7fffffffu || (unsigned)s1) * v0);
                } while (i1++ < 2u && (8u ^ i0));
                h1 = (unsigned short)(h1 + ~(r0.x - 4u));
                { unsigned t2; double z2; if (((unsigned)(w0 >> 29)) & 1u) { t2 = ((unsigned)(x0 >> 70) - 0xffffffffu); z2 = (double)((0x7fffffffu) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    s1 = (int)((unsigned)s1 + ~(unsigned)((int)6u < (int)0xfe2b2fd7u));
                    g1 += (unsigned)((unsigned)h0 < ((v0 - 9u) - (unsigned)(u2 && u3)));
                    r0.x = (unsigned)((int)0x10000u < (int)(unsigned)((int)((r0.y | p2) << (0x263e10dau & 31u)) >= (int)p1));
                    break;
                }
                w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)(unsigned char)(unsigned)((int)(0xa9b73327u - (unsigned)(w0 >> 29)) >= (int)g1) > (signed char)(unsigned)(w0 >> 29));
            }
            s0 = (int)~((3u + garr[u2 & 7u]) << ((unsigned)((short)(unsigned)l0 > (signed char)0u) & 31u));
        } else {
            break;
            g1 += (0x10000u * ~(g0 << (~(0x735fef53u | (unsigned)((int)u1 < (int)0x705e3ea4u)) & 31u)));
            if ((unsigned)w0) {
                do { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)((unsigned)!(-(unsigned)((short)i1 > (signed char)i0) - u0) && (unsigned)(v0 || g0)) & 1023u);
                    f0 = f0 * 0.5f + (float)((v0 + (unsigned)(g0 == fuel)) & 255u);
                    q0 = &garr[(unsigned)(p2 && 0x4a626c9u) & 7u];
                    if ((unsigned)(garr[i1 & 7u] < (unsigned)b0)) {
                        if ((0x7fffffffu ^ (0xffffffffu / (0x17a4b516u | 1u)))) break;
                        while (i1++ < 5u && ((unsigned)w0 | *mp)) { if (--fuel == 0u) goto done;
                            m0 ^= 0x17067433u;
                            break;
                        }
                        h1 = (unsigned short)(h1 + (p0 >> (a0[i0 & 3u] & 31u)));
                        if ((unsigned)(0x6b085487u || (unsigned)(0x10000u || (unsigned)e0))) break;
                        if ((u0 ? 3u : 0x80000000u)) goto L2;
                        break;
                    } else {
                        if ((unsigned)((int)i1 < (int)(unsigned)f0)) continue;
                    }
                } while (i0++ < 3u && (p2 >> (i0 & 31u)));
                break;
            }
        }
        goto L2;
    }
    c0 = (unsigned char)(unsigned)((unsigned)e0 && (unsigned)e0);
    if (~(p0 ^ (0x7fffffffu - r0.x))) goto L4;
    goto L2;
    while (i0++ < 6u && (u2 - p2)) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            b0 = (unsigned)(signed char)((unsigned)l0 & 0x3bc344abu) != 0u;
            { unsigned t3; double z3; if (((unsigned)((int)8u >= (int)(unsigned)l0)) & 1u) { t3 = (0xff265dceu << ((unsigned)((int)u1 < (int)a0[u1 & 3u]) & 31u)); z3 = (double)(((unsigned)(short)(unsigned)((int)0xab7d1981u >= (int)0x8a6c0756u)) & 255u); } if (((unsigned)((int)8u >= (int)(unsigned)l0)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                u3 += (unsigned)(unsigned char)((unsigned)s0 | (unsigned)((int)(unsigned)h0 < (int)(unsigned)w0));
                q0 = &garr[(unsigned)(unsigned char)(unsigned)((short)((unsigned)x0 * p0) > (signed char)(m0 - (unsigned)(*mp && (unsigned)b0))) & 7u];
                *mp = (unsigned)(signed char)(0x80000000u - (0x10000u ? i2 : 0x7fffffffu));
                *q0 += ((unsigned)h0 << (((i0 >> (garr[u2 & 7u] & 31u)) * 0x10000u) & 31u));
            }
        }
        if ((unsigned)!(unsigned)(0u == garr[u2 & 7u])) break;
        if (v0) break;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u2 = fn0(p2, (unsigned)x0, (unsigned)e0); }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(u2);
        switch (a0[u1 & 3u] & 7u) {
            c0 = (unsigned char)(fuel | (0x76c5347u & 2u));
            c1 = (signed char)(unsigned)((int)(unsigned)((int)(unsigned)x0 < (int)(unsigned)s1) >= (int)(unsigned)(0x80000000u == i0));
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((u0 * u2) || (unsigned)(x0 >> 70)), p2, ((unsigned)s0 ^ 1u)); }
        }
        h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)b0 < (int)((unsigned)(g0 == p2) | (unsigned)((short)0xa1738bcbu > (signed char)(unsigned)c0))));
        *q0 = (unsigned)f0;
        *q0 += (g1 | m0);
        { unsigned t0; double z0; if (((unsigned)(signed char)((u0 << (p0 & 31u)) - garr[u2 & 7u])) & 1u) { t0 = (unsigned)((short)g1 > (signed char)0x2dac6d6bu); z0 = (double)((*mp) & 255u); } if (((unsigned)(signed char)((u0 << (p0 & 31u)) - garr[u2 & 7u])) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            h1 = (unsigned short)(h1 + (unsigned)((short)i2 > (signed char)((unsigned)e0 & 5u)));
        }
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)(unsigned)(v0 == v0) >= (int)(unsigned)w0)) {
            *q0 += (unsigned)(9u < garr[i1 & 7u]);
            if ((unsigned)((p2 << ((unsigned)w0 & 31u)) || p0)) goto L1;
            break; (void)((unsigned)b0);
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(4u && v0), (m0 ^ (unsigned)l0), (garr[u2 & 7u] << (2u & 31u))); }
            if ((unsigned)((unsigned)c0 && r0.x)) goto L3;
            if (((unsigned)c0 << (0x119c57c4u & 31u))) {
                u3 = u3 * 0x9e3779b1u + (unsigned)c1;
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)s0 | (unsigned)s1), ((unsigned)((short)garr[i1 & 7u] > (signed char)p1) << (garr[u2 & 7u] & 31u)), (unsigned)((unsigned)c0 || 7u)); }
            }
        }
        if ((9u & (p2 + a0[u1 & 3u]))) {
            L0: if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if (((unsigned)((i2 + 0x10000u) || (unsigned)s0)) & 1u) { t1 = (unsigned)((int)(unsigned)(2u < u0) < (int)(unsigned)(x0 >> 70)); z1 = (double)(((unsigned)(0xffffffffu < (unsigned)(signed char)(i0 ^ i2))) & 255u); } if (((unsigned)((i2 + 0x10000u) || (unsigned)s0)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                s0 = (int)(unsigned)((short)(((unsigned)d0 + 0xdfb3fa9cu) ? *mp : g0) > (signed char)i1);
                if ((unsigned)(3u && (i0 - (unsigned)d0))) goto L2;
                h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(unsigned)((short)(i0 / (0xb2e1de36u | 1u)) > (signed char)(unsigned)w0));
                garr[(unsigned)(signed char)(g0 << (0xe9fd0216u & 31u)) & 7u] = (0x80000000u * 0x7fffffffu);
                if ((unsigned)h1) break;
                L2: if (--fuel == 0u) goto done;
            }
        }
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)4u > (signed char)u0), ((v0 + (unsigned)(w0 >> 29)) ^ a0[u1 & 3u]), (0x543fa8ebu % (v0 | 1u))); }
            while (i2++ < 3u && (unsigned)((int)(unsigned)b0 >= (int)(unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                if ((0x7fffffffu >> ((0x7fffffffu << ((unsigned)d0 & 31u)) & 31u))) break;
                x0 = x0 * 0x100000001b3ull + (((unsigned)w0 ^ (unsigned)x0) - (unsigned)(unsigned char)(unsigned)((int)(unsigned)((unsigned)d0 || (unsigned)c1) < (int)u1));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0x80000000u == (unsigned)d0), (unsigned)((u0 & (unsigned)h0) < 6u), p0); }
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(x0 >> 70), (unsigned)((int)(unsigned)w0 >= (int)1u), (unsigned)h1); }
                do { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(g0 % (8u | 1u));
                    s1 = (int)((unsigned)s1 + ~(v0 ? 0xe7dac081u : garr[i1 & 7u]));
                    c0 = (unsigned char)((unsigned)(u0 == ((unsigned)x0 << (p2 & 31u))) & (unsigned)f0);
                } while (i0++ < 7u && (unsigned)h0);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)h1 % ((unsigned)(x0 >> 70) | 1u)), ((unsigned)!((unsigned)c1 << (0x7fffffffu & 31u)) % (fuel | 1u)), 4u); }
        }
        u3 ^= i0;
        switch (0xffffffffu & 7u) {
            g0 = (*q0 - (0xffffffffu ^ 0x84feb401u));
        }
        v0 = (unsigned)((int)((0x4bf01826u - 0x10000u) % ((unsigned)c1 | 1u)) < (int)(1u & (unsigned)(x0 >> 70)));
    }
    if ((unsigned)((short)u1 > (signed char)(unsigned)e0)) {
        switch (a0[i0 & 3u] & 7u) {
            c0 = (unsigned char)(a0[u1 & 3u] >> (((unsigned)(garr[i1 & 7u] == *q0) - 0x6e98e1d7u) & 31u));
            if ((unsigned)((unsigned)c1 && (unsigned)(x0 >> 70))) {
                c1 = (signed char)(garr[i1 & 7u] * r0.x);
                if (4u) {
                    r0.x = (unsigned)((int)(unsigned)((unsigned)(p0 && u1) && (unsigned)f0) < (int)(unsigned)(r0.y || (unsigned)w0));
                    u3 += (unsigned)(signed char)((unsigned)(u2 == 0x10000u) ? 0x10000u : (unsigned)(i0 < a0[i0 & 3u]));
                    case 4u: ;
                    case 6u: ;
                    u3 ^= i2;
                } else {
                    i0 = (unsigned)(4u && -(2u % ((unsigned)((short)(unsigned)c0 > (signed char)u2) | 1u))) & 15u;
                    *mp = ((*q0 ^ 8u) * m0);
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(garr[i1 & 7u] == u2), i1, (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)((short)(unsigned)b0 > (signed char)0x17412acau))); }
                }
            }
            v0 = (unsigned)(7u == m0);
            case 1u: ;
        }
        if (((unsigned)(p0 || (unsigned)e0) - i0)) {
            if ((unsigned)((2u & (unsigned)e0) < 0x80000000u)) goto L1;
            c1 = (signed char)(a0[u1 & 3u] & (unsigned)x0);
            c1 = (signed char)(unsigned)((u3 % (p1 | 1u)) < i2);
        } else {
            L3: if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((u3 >> ((unsigned)((garr[u2 & 7u] & m0) == (unsigned)(x0 >> 70)) & 31u)) & 1023u);
        }
        *q0 = (0xd93b6bb9u - (unsigned)c1);
        L4: if (--fuel == 0u) goto done;
        if ((unsigned)((int)0xffffffffu < (int)m0)) goto L2;
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)f0 % (fuel | 1u)), (unsigned)((int)u2 < (int)i1), (u1 % ((unsigned)(*mp && 0x7fffffffu) | 1u))); }
    }
    switch (0x10000u & 7u) {
        switch ((unsigned)h0 & 7u) {
            if (fuel < 8u) return (((unsigned)(0xffffffffu == g1) >> (u0 & 31u)) / ((unsigned)h1 | 1u));
            break; (void)(i2);
        }
        if (0xffffffffu) goto L1;
    }
    *mp = (unsigned)((int)(unsigned)w0 >= (int)((unsigned)w0 << (g1 & 31u)));
    for (;;) { if (--fuel == 0u) goto done;
        c1 = (signed char)r0.x;
        if (budget != 0u) { budget -= 1u; u1 = fn0(i1, (unsigned)(0x8118e455u || (unsigned)f0), (a0[u1 & 3u] / ((unsigned)s1 | 1u))); }
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn0((0xffffffffu + (unsigned)s1), 0x10000u, ~((unsigned)h0 % (((unsigned)(w0 >> 29) % (i2 | 1u)) | 1u))); }
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (2u) {
                    if (p2) break;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)x0) break;
                        if (u3 == 7u) return (((unsigned)w0 / ((unsigned)s0 | 1u)) + (v0 & (unsigned)(unsigned char)(unsigned)(i2 && (unsigned)e0)));
                        if (budget != 0u) { budget -= 1u; u1 = fn0(p1, ~(*q0 << (0xf384e51eu & 31u)), (unsigned)s0); }
                        if (9u) break;
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)x0, ~(unsigned)((unsigned)f0 == (unsigned)((short)u1 > (signed char)garr[u2 & 7u])), (unsigned)(((unsigned)(w0 >> 29) & a0[u1 & 3u]) == 0x9289d137u)); }
                        goto done;
                    } while (i0++ < 6u && 6u);
                }
                if (0x80000000u) break;
                while (i0++ < 3u && (unsigned)((i0 - 0x80000000u) == 0xffffffffu)) { if (--fuel == 0u) goto done;
                    v0 = (unsigned)((short)0x7fffffffu > (signed char)u2);
                    if ((a0[i0 & 3u] - ((unsigned)s1 >> (0xee13f75fu & 31u)))) {
                        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                            c0 = (unsigned char)(unsigned)((short)(unsigned)((int)0x5ff35073u < (int)(unsigned)c1) > (signed char)(unsigned)!(p1 / (0xffffffffu | 1u)));
                            *mp = (unsigned)((unsigned)f0 && (0xffffffffu + (unsigned)(unsigned char)((unsigned)(i0 == m0) << (8u & 31u))));
                            if (3u) goto L0;
                        }
                        if ((0xc3136f45u / ((unsigned)((int)r0.x < (int)(unsigned)h0) | 1u))) break;
                        s1 = (int)((unsigned)s1 + (0u | u0));
                        if ((unsigned)(a0[i0 & 3u] < u2)) break;
                        u0 ^= (unsigned)(garr[i1 & 7u] && (unsigned)(x0 >> 70));
                    }
                    s0 = (int)u1;
                    if ((unsigned)d0) {
                        h0 = (short)(((1u % (0x80000000u | 1u)) ? 1u : 0x7fffffffu) << (0x10000u & 31u));
                        switch ((unsigned)(signed char)(v0 - (5u >> (0x3f2665bbu & 31u))) & 7u) {
                            r0.x = (unsigned)((unsigned)(w0 >> 29) && 1u);
                            if (u3 == 7u) return (garr[u2 & 7u] >> (9u & 31u));
                            case 5u: ;
                            continue; (void)((unsigned)(unsigned char)(unsigned)((unsigned)((int)0xbcbeb74du >= (int)0x6cea8f33u) < r0.x));
                            d0 = d0 * 0.5 + (double)((unsigned)(short)(0x8b2ec6d4u - 1u) & 1023u);
                            garr[v0 & 7u] = ((unsigned)h0 & (unsigned)(~(8u | garr[u2 & 7u]) == (unsigned)(short)(0xfcad936du & (unsigned)w0)));
                        }
                    }
                    if ((unsigned)(x0 >> 70)) break;
                    u0 = p0;
                }
                v0 = ((unsigned)(3u || (unsigned)x0) ? u2 : (unsigned)(fuel && 0xbe29b7d5u));
            }
            if (u3 == 7u) return (unsigned)((int)p2 < (int)0xffffffffu);
            if ((unsigned)!(9u | (unsigned)(signed char)(unsigned)((int)i0 >= (int)m0))) break;
        } while (i1++ < 7u && (0x7fffffffu << (i0 & 31u)));
        if (budget != 0u) { budget -= 1u; u1 = fn0(g1, (m0 ^ (unsigned)((int)i0 >= (int)9u)), g0); }
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t2; double z2; if (((unsigned)(m0 || *mp)) & 1u) { t2 = u1; z2 = (double)(((unsigned)(signed char)((unsigned)(2u || p1) ^ u1)) & 255u); } if (((unsigned)(m0 || *mp)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            x0 = x0 * 0x100000001b3ull + (unsigned)((int)g1 >= (int)fuel);
            s1 = (int)((unsigned)s1 + (unsigned)(((unsigned)b0 + (a0[i0 & 3u] / ((unsigned)(0x80000000u || 3u) | 1u))) < 7u));
            break; (void)((5u ^ (unsigned)((int)p1 >= (int)0x80000000u)));
            if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)m0 >= (int)i2) >= (int)a0[u1 & 3u])) break;
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(-((unsigned)b0 | ~(unsigned)((unsigned)w0 < 0x519cf8f2u)), (unsigned)h1, (unsigned)c1); }
            w0 ^= (unsigned long long)(unsigned)s0 << (m0 & 63u);
            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(signed char)(unsigned)((unsigned)((garr[i1 & 7u] >> (5u & 31u)) == (unsigned)l0) < a0[i0 & 3u]) && g0);
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)w0, (g1 & 0x10000u), (unsigned)c0); }
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)h0 & (unsigned)(signed char)(unsigned)(0xae673cf8u == 0xffffffffu)), (unsigned)d0, (unsigned)w0); }
        }
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)(short)((1u % ((unsigned)(0x80000000u < (unsigned)c1) | 1u)) | (unsigned)(0x5854a027u && 0u));
    e0 = e0 * 0.5L + (long double)((8u << (((unsigned)d0 / ((u2 ? 0xffffffffu : a0[i0 & 3u]) | 1u)) & 31u)) & 1023u);
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)*mp < (int)(unsigned)(x0 >> 70)), ((unsigned)c0 >> ((0xf50b45eeu ^ (unsigned)h1) & 31u)), (unsigned)(0x10000u == (unsigned)(u3 < (unsigned)(w0 >> 29)))); }
    do { if (--fuel == 0u) goto done;
        garr[(unsigned)c1 & 7u] = i0;
        e0 = e0 * 0.5L + (long double)((0xffffffffu * ((p0 + (unsigned)x0) % (v0 | 1u))) & 1023u);
    } while (i0++ < 2u && (unsigned)(0x7fffffffu < 3u));
    if (-((unsigned)(x0 >> 70) ? 0xc8bbf362u : (unsigned)(x0 >> 70))) goto L0;
    garr[(unsigned)(2u < 0x3b0097aau) & 7u] = ((unsigned)(8u && (unsigned)l0) & (7u % (0x10000u | 1u)));
    do { if (--fuel == 0u) goto done;
        while (i1++ < 4u && (unsigned)(signed char)((unsigned)c1 >> ((i2 >> (garr[i1 & 7u] & 31u)) & 31u))) { if (--fuel == 0u) goto done;
            b0 = (unsigned)((short)0xffffffffu > (signed char)(unsigned)((int)(unsigned)((int)(unsigned)e0 < (int)0x80000000u) >= (int)(unsigned)!(garr[i1 & 7u] | 0x7fffffffu))) != 0u;
            *q0 += (unsigned)(unsigned char)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)~((fuel | v0) + (unsigned)s1));
            if ((((unsigned)(w0 >> 29) ^ u2) << (fuel & 31u))) break;
        }
    } while (i0++ < 3u && ((unsigned)w0 & (g1 ^ g1)));
    while (i0++ < 3u && (0x5c6d2311u & (unsigned)c0)) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)0xffffffffu >= (int)(unsigned)((unsigned)c1 == (unsigned)c1))) break;
    }
    i1 = ((0x10000u + u3) - (unsigned)(garr[i1 & 7u] < (2u % (u2 | 1u)))) & 15u;
    if ((unsigned)(signed char)(p2 + (unsigned)e0)) goto L4;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(m0 == 0x80000000u), ((unsigned)h0 ? (unsigned)x0 : 0x2a4775ccu), fuel); }
    goto L1;
    if ((0u | (unsigned)x0)) {
        goto L1;
        while (i0++ < 5u && p0) { if (--fuel == 0u) goto done;
            *mp = ((unsigned)l0 * 0x626d9f47u);
            e0 = e0 * 0.5L + (long double)(i1 & 1023u);
            a0[(unsigned)d0 & 3u] = (*q0 << ((unsigned)((int)(unsigned)c1 < (int)(unsigned)(signed char)(unsigned)((short)0x80000000u > (signed char)0xb9dd81feu)) & 31u));
        }
        c0 = (unsigned char)((unsigned)((short)*q0 > (signed char)(p2 / (p2 | 1u))) - (unsigned)f0);
        goto L2;
        if (*mp) goto L2;
        goto L0;
    }
    u1 += (unsigned)!(((unsigned)b0 - (unsigned)x0) % (((unsigned)((int)g1 < (int)6u) + p0) | 1u));
    if ((3u ? i0 : (unsigned)c1)) goto L2;
    g0 = (unsigned)(signed char)((unsigned)((short)(0xeb678900u % ((unsigned)(x0 >> 70) | 1u)) > (signed char)u2) * (unsigned)s1);
    if ((u1 - (unsigned)(i0 && (unsigned)c1))) goto L0;
    if (budget != 0u) { budget -= 1u; u0 = fn0(*mp, (unsigned)(0x61f1687eu < g0), 1u); }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(v0 && (unsigned)c1), (((unsigned)c1 + 6u) << ((unsigned)h0 & 31u)), ((unsigned)s0 / ((unsigned)((unsigned)w0 || (unsigned)(x0 >> 70)) | 1u))); }
    a0[(unsigned)h1 & 3u] = (unsigned)((u1 & 0x7654ad0eu) && 3u);
    goto L1;
    u1 += (unsigned)(w0 >> 29);
    if (2u) {
        *q0 += (unsigned)((int)0xc259629au >= (int)((*q0 / ((unsigned)c0 | 1u)) ? p0 : 0x7fffffffu));
        switch ((unsigned)((int)(unsigned)(short)(unsigned)((int)r0.x >= (int)5u) < (int)0x82975d83u) & 7u) {
            case 4u: ;
            u3 = u3 * 0x9e3779b1u + ((unsigned)(short)(i2 - u2) % (((unsigned)f0 * i0) | 1u));
        }
        switch (0x80000000u & 7u) {
            if ((4u << (garr[u2 & 7u] & 31u))) goto L0;
            i2 = (unsigned)(unsigned char)((unsigned)(unsigned char)(unsigned)((unsigned)(r0.x == u2) || (unsigned)(4u == garr[i1 & 7u])) % (r0.x | 1u)) & 15u;
            break; (void)((2u ^ (7u + garr[u2 & 7u])));
        }
    }
    h0 = (short)(a0[u1 & 3u] / (i0 | 1u));
    if ((unsigned)b0) goto done;
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)x0, (garr[i1 & 7u] >> (0x80000000u & 31u)), ((unsigned)(u0 < p2) + 2u)); }
    if ((unsigned)(signed char)(p2 / ((unsigned)f0 | 1u))) {
        if (((unsigned)c1 >> (u3 & 31u))) goto L2;
        if (((unsigned)w0 / (p2 | 1u))) goto L4;
        i0 = ((unsigned)(unsigned char)(unsigned)((unsigned)s0 < 0xffffffffu) + ((unsigned)(0x67844599u && g1) << (0xa4190942u & 31u))) & 15u;
        if (0u) goto L1;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0(((u3 / ((unsigned)f0 | 1u)) + i2), 0xffffffffu, (r0.y - 0u)); }
    do { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (unsigned)((int)(((unsigned)w0 % (u2 | 1u)) * (i1 * (unsigned)s1)) < (int)(unsigned)e0);
        *q0 += (unsigned)((int)((8u & g0) - 0xffffffffu) < (int)(unsigned)(unsigned char)(unsigned)((short)(unsigned)f0 > (signed char)0x80000000u));
    } while (i0++ < 5u && (u2 ^ i1));
    e0 = e0 * 0.5L + (long double)(p2 & 1023u);
    if ((r0.x << ((8u >> (a0[u1 & 3u] & 31u)) & 31u))) goto L2;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(0x65e12360u < a0[i0 & 3u])) goto L1;
    c0 = (unsigned char)(unsigned)(x0 >> 70);
    do { if (--fuel == 0u) goto done;
        while (i1++ < 4u && (unsigned)((unsigned)b0 || r0.x)) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
            }
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((0x8e892ec4u ? (unsigned)c0 : (unsigned)s0)) break;
            }
            h0 = (short)(unsigned)(x0 >> 70);
        }
        if (~(unsigned)((i0 % ((unsigned)h1 | 1u)) && (unsigned)e0)) break;
        if ((unsigned)(p0 && ((unsigned)x0 | (unsigned)l0))) break;
        i1 = (unsigned)((unsigned)((int)v0 < (int)0x8da32201u) == 0x10000u) & 15u;
        while ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)3u)) { if (--fuel == 0u) goto done;
            a0[(p2 / ((unsigned)h1 | 1u)) & 3u] = 0x80000000u;
            break; (void)((unsigned)f0);
        }
    } while (i0++ < 3u && (0x194e27e8u | p0));
    if (p2) {
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1(((r0.y << (0xffffffffu & 31u)) & 0x10000u), (unsigned)((int)0x5d506a38u < (int)fuel), g1); }
        }
        switch ((g1 / ((unsigned)(r0.y < garr[i1 & 7u]) | 1u)) & 7u) {
            f0 = f0 * 0.5f + (float)((unsigned)h0 & 255u);
            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(short)(0x80000000u * 0x80000000u) == (unsigned)w0) & 1023u);
        }
        L1: if (--fuel == 0u) goto done;
        if (g0) goto L0;
        { unsigned t0; double z0; if (((u3 * (unsigned)((int)(unsigned)d0 >= (int)0xffffffffu))) & 1u) { t0 = 0xd7dfbe80u; z0 = (double)((0x80000000u) & 255u); } if (((u3 * (unsigned)((int)(unsigned)d0 >= (int)0xffffffffu))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            i0 = (unsigned)((unsigned)c0 < (unsigned)((int)4u >= (int)(unsigned)(0xa8f5b12au < (unsigned)h1))) & 15u;
        }
        L2: if (--fuel == 0u) goto done;
    }
    L3: if (--fuel == 0u) goto done;
    switch ((unsigned)x0 & 7u) {
        case 0u: ;
        case 4u: ;
        switch ((u0 % ((unsigned)c0 | 1u)) & 7u) {
            switch ((unsigned)(x0 >> 70) & 7u) {
                u3 = u3 * 0x9e3779b1u + (unsigned)(short)(unsigned)((int)(unsigned)!(0xd79ae2bfu & m0) < (int)0xa31be310u);
                if (budget != 0u) { budget -= 1u; u0 = fn0((a0[u1 & 3u] % ((unsigned)((unsigned)f0 < 7u) | 1u)), 0x75b715f5u, (unsigned)e0); }
                if (p2) goto L2;
                if ((unsigned)d0) break;
                b0 = ((unsigned)c0 % ((unsigned)h1 | 1u)) != 0u;
                if ((unsigned)(0x10000u < 9u)) goto L0;
            }
        }
        c1 = (signed char)(unsigned)((unsigned)((int)(unsigned)w0 < (int)(unsigned)c0) < u2);
        switch ((unsigned)(short)(a0[u1 & 3u] / (i2 | 1u)) & 7u) {
            goto L3;
            if (((unsigned)c1 / (i2 | 1u))) break;
            L4: if (--fuel == 0u) goto done;
            if ((unsigned)f0) goto done;
        }
        case 2u: ;
    }
    x0 = x0 * 0x100000001b3ull + 0xabfe22f5u;
    s1 = (int)((unsigned)s1 + (unsigned)((i2 - (unsigned)f0) && 0x10000u));
    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)w0, *q0, (unsigned)((short)i0 > (signed char)0x80000000u)); }
    r0.y ^= (unsigned)((int)(unsigned)(short)(g0 & (unsigned)(w0 >> 29)) < (int)(unsigned)((int)(unsigned)l0 < (int)(unsigned)!(unsigned)((int)0x7fffffffu < (int)u1)));
    a0[(unsigned)(p1 == 6u) & 3u] = p1;
    if ((unsigned)(garr[i1 & 7u] < u0)) goto L4;
    g0 = (unsigned)(signed char)(0xbe991abcu & fuel);
    r0.y ^= (unsigned)((int)(g1 / ((7u - 5u) | 1u)) < (int)0x3dfbbb3bu);
    if (*q0) {
        h1 = (unsigned short)(h1 + (unsigned)!((unsigned)l0 + (unsigned)d0));
        if (u2) {
            if ((unsigned)(6u < i1)) goto L1;
            a0[(0xffffffffu | 7u) & 3u] = a0[i0 & 3u];
            r0.x = ~(unsigned)((short)r0.x > (signed char)~(unsigned)((short)i1 > (signed char)(m0 ? g1 : 0x80000000u)));
            if ((unsigned)(((unsigned)w0 << (r0.y & 31u)) == u2)) {
                goto L0;
                if ((unsigned)((short)i1 > (signed char)(unsigned)w0)) goto L0;
                { unsigned t1; double z1; if (((((unsigned)l0 % ((unsigned)s0 | 1u)) * (unsigned)s0)) & 1u) { t1 = (unsigned)(signed char)(0u | 0x7160c09cu); z1 = (double)(((u3 ^ 6u)) & 255u); } if (((((unsigned)l0 % ((unsigned)s0 | 1u)) * (unsigned)s0)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    switch ((unsigned)f0 & 7u) {
                        case 5u: ;
                        if (budget != 0u) { budget -= 1u; u0 = fn1((((unsigned)(w0 >> 29) ^ (unsigned)e0) ^ i1), ((0x16ef2d80u + a0[u1 & 3u]) ^ u0), (unsigned)(signed char)(unsigned)((unsigned)w0 && 2u)); }
                        case 6u: ;
                    }
                    g1 += ~(4u ^ (unsigned)((int)(unsigned)(signed char)((unsigned)f0 * 0x7fffffffu) < (int)(g1 % ((unsigned)h0 | 1u))));
                    if ((8u >> ((unsigned)h1 & 31u))) goto L3;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)u2 >= (int)p1), (unsigned)(u3 < g0), ((unsigned)(0x10000u || fuel) | (unsigned)x0)); }
                    r0.y ^= (a0[i0 & 3u] + ((unsigned)(fuel < v0) >> (i1 & 31u)));
                    if ((unsigned)((int)0x80000000u >= (int)0x10000u)) {
                        goto L0;
                        h0 = (short)(unsigned)(0x80000000u && (unsigned)h1);
                        u2 += ((0u << ((unsigned)w0 & 31u)) + (unsigned)(u0 < (unsigned)(short)(fuel + i0)));
                    }
                }
            } else {
                if (((unsigned)f0 / ((unsigned)c0 | 1u))) goto done;
                if ((0xffffffffu | (unsigned)!((unsigned)(w0 >> 29) / (0x10000u | 1u)))) goto L1;
                r0.y ^= (0x10000u ? (unsigned)s1 : (unsigned)((unsigned)h1 && 0x1adb2edcu));
            }
            if (-(unsigned)((unsigned)w0 < p2)) goto L3;
            u2 ^= ~(unsigned)((int)(unsigned)h0 < (int)((unsigned)(short)(i2 >> ((unsigned)(x0 >> 70) & 31u)) ^ (unsigned)f0));
        } else {
            do { if (--fuel == 0u) goto done;
                if (((p0 * (unsigned)w0) ^ (unsigned)l0)) break;
                g1 += ((unsigned)(8u == m0) * (unsigned)((short)g0 > (signed char)u0));
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((u0 | u0)) {
                        break; (void)((unsigned)((int)(0x7fffffffu + fuel) < (int)m0));
                    }
                    break; (void)((unsigned)x0);
                    u1 ^= (i2 * (r0.x | 0x7fffffffu));
                    while (i2++ < 5u && (unsigned)(short)(p1 ? u0 : v0)) { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            if ((0x7fffffffu >> ((i1 * p0) & 31u))) break;
                            break; (void)(-((unsigned)((int)i2 < (int)(unsigned)h1) / ((unsigned)h0 | 1u)));
                        } while (i0++ < 5u && (unsigned)((int)4u < (int)((unsigned)w0 % ((unsigned)e0 | 1u))));
                        if (-(unsigned)((unsigned)(x0 >> 70) && 0x80000000u)) break;
                        if ((0x7279e2c9u ? 0x707d66c7u : 4u)) break;
                        if (0x7fffffffu) break;
                    }
                }
                i0 = (unsigned)((int)*q0 >= (int)(u2 * (4u / ((0xfa324039u | 0x10000u) | 1u)))) & 15u;
            } while (i0++ < 3u && (unsigned)!(unsigned)((unsigned)((short)7u > (signed char)(unsigned)(w0 >> 29)) || (unsigned)f0));
            s0 = (int)(unsigned)((short)(unsigned)((short)(unsigned)s0 > (signed char)(unsigned)l0) > (signed char)(unsigned)((int)(unsigned)f0 >= (int)*mp));
            s0 = (int)(unsigned)(((0x7fffffffu << (i1 & 31u)) << ((unsigned)d0 & 31u)) == ~(unsigned)(m0 < 2u));
            if (u2) goto L4;
        }
        if (((g1 ^ (unsigned)c1) | r0.y)) goto L1;
        if ((u2 ^ fuel)) goto L2;
        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)h1 & u0), (unsigned)((int)0xffffffffu < (int)5u), (unsigned)(unsigned char)(g0 - (unsigned)(short)(i2 ^ g1))); }
    }
    c1 = (signed char)(unsigned)((0x18a345f1u >> (((unsigned)s0 << (((unsigned)h0 ^ i1) & 31u)) & 31u)) && (unsigned)(x0 >> 70));
    { unsigned t2; double z2; if (((unsigned)f0) & 1u) { t2 = ((r0.y - 0x7fffffffu) + r0.y); z2 = (double)((r0.x) & 255u); } if (((unsigned)f0) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        if ((unsigned)c1) {
            if (u1) goto L2;
            if ((m0 % ((0x13ec7e36u << (a0[i0 & 3u] & 31u)) | 1u))) {
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (g0 - p0);
                    while (i1++ < 3u && (0x10000u + 0u)) { if (--fuel == 0u) goto done;
                        if (1u) break;
                        if ((unsigned)!(unsigned)(7u < (unsigned)((int)g1 >= (int)(unsigned)l0))) goto L1;
                        if ((unsigned)(i0 || g0)) {
                            if (u3 == 7u) return ((unsigned)e0 % (0xcf0da6cdu | 1u));
                            u2 += (unsigned)(m0 == m0);
                        }
                        *mp = (i0 + (m0 % (u2 | 1u)));
                        continue; (void)(0x7fffffffu);
                    }
                    s0 = (int)((unsigned)b0 * r0.x);
                    if (a0[u1 & 3u]) break;
                    *mp = 0x80000000u;
                    if ((unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) || (unsigned)(u1 == u0))) break;
                }
                s1 = (int)((unsigned)s1 + (unsigned)((short)i1 > (signed char)((u1 + 8u) >> ((unsigned)((unsigned)b0 && p2) & 31u))));
                if (1u) goto L1;
                e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)((int)0xffffffffu < (int)0x80000000u) < (int)(m0 ^ 0x74cbd1beu)) & 1023u);
                if ((0xa7d320fcu % ((unsigned)l0 | 1u))) goto L3;
            }
        } else {
            g1 += p0;
            g1 += (~(unsigned)((short)(unsigned)((short)(8u ^ 0xea73347fu) > (signed char)a0[i0 & 3u]) > (signed char)u2) << (2u & 31u));
        }
        u2 = (unsigned)(((0x7fffffffu ? g1 : (unsigned)c0) * u2) == v0);
        if (((unsigned)s0 - 1u)) {
            if ((unsigned)((0x6421ce01u >> (a0[u1 & 3u] & 31u)) || (unsigned)w0)) goto L3;
        }
        w0 = w0 * 6364136223846793005ull + (unsigned)(4u && (2u << (0x115c330u & 31u)));
        if ((unsigned)(0x10000u && (unsigned)((short)(unsigned)s0 > (signed char)(unsigned)d0))) {
            if ((unsigned)((0x80000000u / (0x10000u | 1u)) == u1)) goto done;
            if (g1) goto L3;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)l0 == (m0 << (9u & 31u))), (~((unsigned)l0 | 0x7fffffffu) | (unsigned)(x0 >> 70)), 7u); }
            do { if (--fuel == 0u) goto done;
                if (u3) {
                    break; (void)(-(0x80000000u / ((fuel | r0.y) | 1u)));
                    u2 = ((unsigned)!(unsigned)((int)0xffffffffu < (int)(unsigned)d0) >> (0x474372adu & 31u));
                    *q0 = fuel;
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)c0) break;
                        if (7u) break;
                        *mp = (unsigned)(-((u0 % (1u | 1u)) % (3u | 1u)) == (unsigned)(short)(unsigned)(0x10000u < 0x10000u));
                        if (fuel < 8u) return (garr[i1 & 7u] + v0);
                    } while (i1++ < 2u && (unsigned)(unsigned char)((unsigned)((unsigned)b0 < (unsigned)f0) << (0u & 31u)));
                    if (((unsigned)c1 | (unsigned)((short)(unsigned)s0 > (signed char)g1))) break;
                    { unsigned t3; double z3; if (((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)((unsigned)s1 || (unsigned)s1))) & 1u) { t3 = (unsigned)!((unsigned)s0 | m0); z3 = (double)(((unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) && 0u)) & 255u); } if (((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)((unsigned)s1 || (unsigned)s1))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        break; (void)(((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)u1) ^ a0[u1 & 3u]));
                        q0 = &garr[(5u >> ((unsigned)((int)0u < (int)(*q0 & 0x80000000u)) & 31u)) & 7u];
                        if (budget != 0u) { budget -= 1u; u2 = fn0(-(unsigned)((u1 % (m0 | 1u)) && (unsigned)e0), (unsigned)(u0 || (unsigned)(p0 && 0x7fffffffu)), ((unsigned)((int)0x80000000u < (int)1u) & 0xc0d0be0eu)); }
                    }
                }
                continue; (void)(u2);
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((u1 % ((unsigned)h1 | 1u)) < 0xf9e946f9u), (unsigned)((short)0xd23ff4bu > (signed char)(unsigned)((int)u3 < (int)i1)), (unsigned)!((unsigned)(x0 >> 70) << ((unsigned)((int)p0 >= (int)u2) & 31u))); }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)h0, (unsigned)s1, (unsigned)c0); }
                garr[(0x80000000u % ((unsigned)b0 | 1u)) & 7u] = ((unsigned)((unsigned)d0 < ~(unsigned)(0x80000000u < ((unsigned)e0 * 0xd35ccb48u))) - 0xffffffffu);
                u0 ^= (unsigned)((unsigned)((int)0x7fffffffu >= (int)(unsigned)x0) < (unsigned)((short)m0 > (signed char)(unsigned)f0));
            } while (i0++ < 6u && 0x29404fdu);
            if ((m0 & (g1 - i2))) {
                if (budget != 0u) { budget -= 1u; u3 = fn1(0u, (unsigned)h1, ~((unsigned)!(p0 % (0x80000000u | 1u)) + 0x7fffffffu)); }
                if (((unsigned)(8u == p1) + (unsigned)c1)) goto done;
            }
            s0 = (int)(unsigned)(~(-(0xb290d688u - (unsigned)c1) | (unsigned)((int)0x10000u < (int)r0.x)) < (unsigned)d0);
        } else {
            goto L4;
            { unsigned t4; double z4; if ((0x10000u) & 1u) { t4 = (unsigned)((int)(g1 ^ 0x10f5b89eu) >= (int)0x5464accbu); z4 = (double)(((0xdcc6aac0u * (unsigned)((unsigned)x0 == 5u))) & 255u); } if ((0x10000u) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                g0 = ((i0 % ((unsigned)h1 | 1u)) - i0);
                q0 = &garr[((m0 << ((unsigned)((int)(unsigned)l0 < (int)p0) & 31u)) % ((6u + r0.y) | 1u)) & 7u];
                a0[p2 & 3u] = (unsigned)b0;
                u3 ^= (unsigned)((int)((garr[u2 & 7u] - r0.x) & ((unsigned)w0 % ((unsigned)f0 | 1u))) < (int)(unsigned)e0);
                w0 = w0 * 6364136223846793005ull + ((unsigned)w0 - (u3 ^ *mp));
            }
            goto L2;
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)!(unsigned)((int)(unsigned)s1 < (int)((a0[u1 & 3u] * a0[u1 & 3u]) | 5u)) >= (int)0x80000000u));
        }
    }
    w0 ^= (unsigned long long)((unsigned)s1 * r0.x) << ((4u / (u2 | 1u)) & 63u);
    if (budget != 0u) { budget -= 1u; u2 = fn0(-(unsigned)((short)(unsigned)w0 > (signed char)(unsigned)(signed char)(0x80000000u / (i1 | 1u))), 3u, (unsigned)(g1 == (unsigned)(signed char)(unsigned)((int)(unsigned)h1 < (int)garr[u2 & 7u]))); }
    if ((2u + (p0 & 0xf9025edu))) {
        g1 += (unsigned)(w0 >> 29);
        if ((i2 | *q0)) goto L0;
        g1 += (unsigned)((int)(unsigned)((*q0 >> (0u & 31u)) || (unsigned)(x0 >> 70)) >= (int)u1);
        goto done;
    }
    if ((u2 + garr[u2 & 7u])) goto L3;
    if (((unsigned)l0 ^ 0xffffffffu)) goto done;
    switch ((unsigned)((short)4u > (signed char)3u) & 7u) {
        case 6u: ;
        if (budget != 0u) { budget -= 1u; u2 = fn0((fuel ? a0[i0 & 3u] : a0[u1 & 3u]), (unsigned)(r0.y && (p0 * (unsigned)x0)), (2u | (unsigned)((int)9u >= (int)(unsigned)d0))); }
        if (budget != 0u) { budget -= 1u; u0 = fn0(r0.x, u1, (0x909ca5f5u & (unsigned)((int)u3 >= (int)a0[u1 & 3u]))); }
    }
    while (i0++ < 6u && (unsigned)((int)0xffffffffu >= (int)0x1e05b558u)) { if (--fuel == 0u) goto done;
        u3 += m0;
        do { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                i1 = (8u % ((-(unsigned)((int)m0 >= (int)0xbba9ef00u) ^ (unsigned)c0) | 1u)) & 15u;
                w0 = w0 * 6364136223846793005ull + (0x1bf53141u >> ((unsigned)s0 & 31u));
                s0 = (int)(6u + (0x80000000u / ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)(short)(r0.y - (unsigned)x0)) | 1u)));
                if (0x80000000u) break;
                m0 ^= ((0xe7041968u << ((unsigned)((int)*q0 >= (int)(unsigned)((unsigned)h0 && (unsigned)x0)) & 31u)) | *mp);
            }
            do { if (--fuel == 0u) goto done;
                g1 += (unsigned)c1;
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)(9u == p0) || (unsigned)(short)(unsigned)(*mp < *mp)));
                if (budget != 0u) { budget -= 1u; u3 = fn0(2u, ((unsigned)c0 / (0x7fffffffu | 1u)), ((unsigned)w0 ^ (unsigned)f0)); }
                u2 = u2 * 0x9e3779b1u + (0x305b5a2du % (0x10000u | 1u));
                if (((unsigned)h1 ^ 0x6c9b631eu)) continue;
                switch ((0x101b15d5u & (0x2bab6a3bu | g1)) & 7u) {
                    if ((m0 | (unsigned)(p1 || *q0))) break;
                    v0 = (0x5388c19bu / ((unsigned)s0 | 1u));
                    if ((i0 ^ *q0)) {
                        e0 = e0 * 0.5L + (long double)(((unsigned)x0 + ((unsigned)(garr[u2 & 7u] < 0xe5c89bcbu) + p0)) & 1023u);
                        if (budget != 0u) { budget -= 1u; u1 = fn0(0x513e01a0u, ((unsigned)((short)p2 > (signed char)(unsigned)w0) % ((unsigned)c1 | 1u)), (i0 << (i0 & 31u))); }
                        case 1u: ;
                        w0 ^= (unsigned long long)i0 << ((unsigned)(p2 && (unsigned)((unsigned)(signed char)(u1 / ((unsigned)(0x7fffffffu == garr[u2 & 7u]) | 1u)) && u0)) & 63u);
                        *q0 = ((0x10000u - (0x704727f7u & (unsigned)(x0 >> 70))) * (unsigned)(short)(unsigned)(0x10000u && (unsigned)(x0 >> 70)));
                    }
                    h0 = (short)(unsigned)(7u < (6u & (unsigned)(w0 >> 29)));
                    if (u2) break;
                }
            } while (i2++ < 5u && (unsigned)c0);
            switch ((unsigned)(0x80000000u == 0xffffffffu) & 7u) {
                { unsigned t5; double z5; if (((u1 | (unsigned)((int)r0.y < (int)v0))) & 1u) { t5 = (0u * (unsigned)w0); z5 = (double)(((unsigned)((short)(unsigned)(m0 < *mp) > (signed char)*q0)) & 255u); } if (((u1 | (unsigned)((int)r0.y < (int)v0))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                    do { if (--fuel == 0u) goto done;
                        i0 = ((unsigned)b0 ? *q0 : (0xffffffffu - 0x8488850fu)) & 15u;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)e0 << (u3 & 31u)), 0x80000000u, 3u); }
                    } while (i2++ < 6u && (unsigned)b0);
                    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)!(8u >> (0xaa963d47u & 31u)) / ((unsigned)e0 | 1u)), (0xffffffffu * 0x45013a85u), (unsigned)((short)0xffffffffu > (signed char)a0[i0 & 3u])); }
                    b0 = 0u != 0u;
                }
                m0 ^= (unsigned)(0xaeff6941u < ((unsigned)c1 + (unsigned)(x0 >> 70)));
                s1 = (int)((unsigned)s1 + ((unsigned)((unsigned)(u2 < -(unsigned)(g0 < 0x80000000u)) == 3u) & a0[i0 & 3u]));
                a0[i2 & 3u] = ((unsigned)s0 / ((u1 << (garr[i1 & 7u] & 31u)) | 1u));
                break; (void)(0xfe2a9253u);
            }
            if ((unsigned)(p0 || 0xb325e9eu)) continue;
            m0 ^= (unsigned)b0;
            for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (0x10000u) continue;
                g1 += ((unsigned)s0 | (unsigned)!(unsigned)((short)0x7fffffffu > (signed char)(unsigned)h0));
                if (((unsigned)b0 >> (i0 & 31u))) break;
                if ((unsigned)((unsigned)((int)i1 < (int)(unsigned)f0) < u3)) break;
            }
        } while (i1++ < 5u && (unsigned)((0u & 0x7fffffffu) || u2));
        if (-(unsigned)(g1 || (unsigned)(0x7fffffffu < 2u))) goto L1;
        break; (void)((0xf169629du * 2u));
        *mp = (*mp << ((unsigned)w0 & 31u));
    }
    if (u3 == 7u) return (0xfaa6b28cu * (unsigned)((int)(unsigned)e0 < (int)u1));
    u0 = (unsigned)!(0x7fffffffu % ((unsigned)d0 | 1u));
    c1 = (signed char)(unsigned)((int)8u < (int)(u3 + (unsigned)(signed char)((a0[i0 & 3u] / (0xa3497624u | 1u)) ^ 0xffffffffu)));
    switch ((u1 / ((unsigned)((int)(unsigned)h0 >= (int)r0.x) | 1u)) & 7u) {
        x0 = x0 * 0x100000001b3ull + (a0[i0 & 3u] ^ (unsigned)((int)(((unsigned)h0 << (*mp & 31u)) * fuel) < (int)garr[i1 & 7u]));
        if ((unsigned)(((unsigned)h1 | (unsigned)x0) < p2)) {
            garr[u1 & 7u] = (unsigned)(3u || (unsigned)(short)((unsigned)c1 * u1));
            case 3u: ;
            switch ((unsigned)(short)(unsigned)(u0 && i1) & 7u) {
                m0 ^= i1;
                u3 = u3 * 0x9e3779b1u + v0;
                u3 = u3 * 0x9e3779b1u + (((unsigned)s1 - 0x7007fa0fu) << (a0[u1 & 3u] & 31u));
                case 4u: ;
                if (-((unsigned)f0 >> (p2 & 31u))) goto done;
            }
            u2 = u2 * 0x9e3779b1u + (~(0x2d9b511u ^ 0x7fffffffu) * (unsigned)s0);
            *q0 += ((u1 | i0) & g1);
        } else {
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(2u, (unsigned)((unsigned)s0 || 0xffffffffu), (unsigned)c0); }
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(unsigned char)(unsigned)(i0 == 3u), (v0 - 0xfa231f9au), (unsigned)d0); }
                    } while (i2++ < 2u && 3u);
                    if ((unsigned)(short)(unsigned)((int)(i1 | garr[i1 & 7u]) >= (int)7u)) {
                        d0 = d0 * 0.5 + (double)(garr[i1 & 7u] & 1023u);
                        u0 += ((unsigned)((int)(unsigned)(fuel && (unsigned)x0) < (int)((unsigned)h0 / (g1 | 1u))) | p0);
                        s0 = (int)((unsigned)h1 % (((unsigned)((unsigned)b0 == fuel) ^ v0) | 1u));
                        r0.x = (((unsigned)s0 % (0x10000u | 1u)) % ((unsigned)(0xbfeb7cedu || 0xa45f171cu) | 1u));
                        default: ;
                        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((int)(unsigned)(short)((unsigned)(w0 >> 29) % ((unsigned)(0x10000u || (unsigned)d0) | 1u)) < (int)0x22ca83e1u) == garr[i1 & 7u]);
                    } else {
                        u3 += -(((unsigned)w0 + (unsigned)h1) ^ *q0);
                        case 1u: ;
                        *q0 += ((unsigned)b0 ^ (unsigned)((int)(unsigned)(x0 >> 70) >= (int)r0.y));
                        h1 = (unsigned short)(h1 + (unsigned)(short)(*mp << (5u & 31u)));
                    }
                    if ((0x25209378u ? 0xddc686bcu : u3)) break;
                    if (i2) continue;
                }
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    goto L2;
                    if (r0.y) break;
                    if ((0x4831c184u | 0xf95c6442u)) break;
                    if (((unsigned)x0 << ((unsigned)(g1 == (unsigned)c0) & 31u))) break;
                    f0 = f0 * 0.5f + (float)((u0 - (unsigned)(r0.y || (unsigned)c0)) & 255u);
                    if ((unsigned)((int)(unsigned)w0 >= (int)v0)) {
                        u0 += g1;
                        break;
                    } else {
                        if (fuel < 8u) return (m0 & (unsigned)((unsigned)x0 < (unsigned)(unsigned char)(unsigned)((unsigned)f0 == v0)));
                    }
                }
                if ((unsigned)(unsigned char)((unsigned)l0 * (unsigned)(short)(v0 >> (0u & 31u)))) goto done;
                switch ((v0 + 0x7fffffffu) & 7u) {
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)(unsigned)f0 < (int)8u), ~(unsigned)(p1 == u0), (unsigned)(unsigned char)(unsigned)(p1 < (unsigned)((short)0u > (signed char)m0))); }
                    i1 = i0 & 15u;
                }
                s0 = (int)a0[i0 & 3u];
            }
            if ((unsigned)(w0 >> 29)) goto L4;
        }
        do { if (--fuel == 0u) goto done;
            case 2u: ;
            s0 = (int)(unsigned)((i1 - fuel) || (unsigned)s1);
            r0.y ^= ((unsigned)(i1 < (*q0 * (unsigned)h1)) - 9u);
            case 7u: ;
            *q0 = 0xb54d2b55u;
            if (3u) {
                if ((0x5e2783bcu / (-((unsigned)(w0 >> 29) & r0.y) | 1u))) {
                    *q0 = 0xa1e8c155u;
                    continue; (void)((8u << ((unsigned)l0 & 31u)));
                    c0 = (unsigned char)m0;
                    break;
                    break;
                }
                if (((unsigned)d0 + (unsigned)((int)0u >= (int)(unsigned)b0))) break;
                d0 = d0 * 0.5 + (double)((*q0 >> ((*mp ? 7u : (unsigned)((int)(unsigned)e0 >= (int)a0[u1 & 3u])) & 31u)) & 1023u);
                break;
                *q0 += u3;
            }
        } while (i0++ < 2u && 0x1d05b9ceu);
    }
    if (0x7fffffffu) {
        w0 ^= (unsigned long long)(unsigned)(signed char)(v0 & 5u) << ((0x80000000u << (0x39f153f3u & 31u)) & 63u);
    }
    while ((unsigned)((short)i1 > (signed char)9u)) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((unsigned)l0 & 255u);
    }
    c1 = (signed char)(unsigned)((int)g0 < (int)5u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)b0, (unsigned)((unsigned)h0 == (unsigned)b0), ((unsigned)d0 ^ (unsigned)s1)); }
    if ((unsigned)((unsigned)e0 || p0)) goto done;
    if ((unsigned)f0) goto L2;
    for (;;) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn2(0xa082b967u, ((unsigned)c0 + u2), (garr[i1 & 7u] / ((unsigned)c0 | 1u))); }
        b0 = (unsigned)(0x97d952u || fuel) != 0u;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u3 = fn1((0x10000u / ((p0 / (7u | 1u)) | 1u)), 0x9e18028du, *mp); }
            if (((unsigned)d0 ? 0x6ae01479u : (unsigned)(w0 >> 29))) {
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(((unsigned)w0 << ((unsigned)b0 & 31u)) == 5u), ((unsigned)c1 % (fuel | 1u)), 0x76a23512u); }
            }
            { unsigned t0; double z0; if ((0x10000u) & 1u) { t0 = (0x2e271c94u << (9u & 31u)); z0 = (double)(((unsigned)(signed char)(unsigned)((int)(a0[i0 & 3u] ^ garr[i1 & 7u]) < (int)u0)) & 255u); } if ((0x10000u) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                if ((unsigned)(i2 || 0x10000u)) {
                    if ((unsigned)((int)(unsigned)s1 >= (int)a0[i0 & 3u])) break;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((~(unsigned)((int)0xaa1ae8ceu >= (int)*mp) ^ i0), (unsigned)(*mp && (unsigned)c1), (unsigned)((short)0xffffffffu > (signed char)(unsigned)((int)(unsigned)f0 < (int)p1))); }
                r0.x = ((m0 | (unsigned)b0) >> ((fuel % (m0 | 1u)) & 31u));
                u2 = (0x3bd96830u + (unsigned)b0);
                m0 ^= -(unsigned)((int)(unsigned)w0 < (int)0x7c5d946cu);
            }
            if ((unsigned)(signed char)((unsigned)((int)u3 >= (int)garr[u2 & 7u]) / (4u | 1u))) {
                *q0 = (unsigned)(signed char)(0x10000u - p0);
                if (((unsigned)s1 % (0x7fffffffu | 1u))) continue;
            }
        }
        if ((unsigned)s0) break;
        break; (void)((*q0 / (v0 | 1u)));
    }
    if (*q0) goto L3;
    if ((unsigned)(0x6065bfd2u && (unsigned)f0)) goto L4;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(unsigned)((unsigned)(w0 >> 29) == (unsigned)(p1 && (g1 * i2))));
    }
    L1: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u2 = fn2((g1 ^ (unsigned)(0x5083ce0bu && (unsigned)h0)), (unsigned)((unsigned)s1 && -(v0 >> ((unsigned)e0 & 31u))), ((unsigned)c0 ^ u2)); }
    if ((unsigned)(~(unsigned)((unsigned)s0 && 0x10000u) < r0.y)) goto L0;
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)0xd38af0d4u >= (int)0x6c029575u);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = ((unsigned)((short)(g1 / (fuel | 1u)) > (signed char)(unsigned)b0) * ~(u2 ^ (unsigned)c1));
        do { if (--fuel == 0u) goto done;
            while (i2++ < 2u && (unsigned)h0) { if (--fuel == 0u) goto done;
                a0[i2 & 3u] = (unsigned)(short)(unsigned)((short)fuel > (signed char)(unsigned)((short)(unsigned)d0 > (signed char)(unsigned)(7u || (unsigned)s0)));
            }
            b0 = (unsigned)((unsigned)c0 == 0x8114c8e3u) != 0u;
            if (g0) {
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)l0 & 1023u);
                    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        L2: if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + (unsigned)((0x91699fb5u % (((unsigned)e0 / (g1 | 1u)) | 1u)) && (unsigned)c1));
                        m0 ^= (u0 >> (((0x80000000u & 8u) & 4u) & 31u));
                    }
                }
            }
            switch ((unsigned)(signed char)((unsigned)(a0[i0 & 3u] < 1u) % ((unsigned)c0 | 1u)) & 7u) {
                m0 ^= (fuel & (unsigned)((r0.x * 0xb718848du) && (0x1fd04878u / ((unsigned)h0 | 1u))));
                u2 ^= ((unsigned)c0 ? ((unsigned)s0 | i1) : 0xd26eacdeu);
                goto done;
            }
            h0 = (short)(unsigned)((short)(i2 | (unsigned)((int)(u2 | 2u) < (int)r0.y)) > (signed char)u2);
        } while (i1++ < 3u && (unsigned)(*q0 || 0x5e9574dau));
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(r0.y && i2), (unsigned)((unsigned)c0 < (unsigned)h1), (0xffffffffu / (0xfb20dbdbu | 1u))); }
        f0 = f0 * 0.5f + (float)(garr[i1 & 7u] & 255u);
        if ((0x7fffffffu - (unsigned)(unsigned char)(unsigned)(fuel && 0xffffffffu))) {
            switch (p0 & 7u) {
                s1 = (int)((unsigned)s1 + 9u);
                d0 = d0 * 0.5 + (double)((v0 & m0) & 1023u);
                x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)(1u == (unsigned)w0) && -((unsigned)s0 * 0x80314164u));
                case 6u: ;
                case 3u: ;
            }
            l0 = (long)((unsigned long)l0 + ~(unsigned)((unsigned)(unsigned char)(i2 / (garr[i1 & 7u] | 1u)) && 8u));
        }
        switch (((unsigned)((short)m0 > (signed char)(unsigned)l0) / (0xbfe6466fu | 1u)) & 7u) {
            if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)((int)(unsigned)h0 >= (int)r0.x) / (i2 | 1u)), ((unsigned)d0 << (((unsigned)(w0 >> 29) % (a0[i0 & 3u] | 1u)) & 31u)), ((unsigned)x0 << (a0[u1 & 3u] & 31u))); }
            g0 = (unsigned)((unsigned)h0 == 5u);
            if (fuel < 8u) return u3;
            h0 = (short)(unsigned)(signed char)((0x7fffffffu / ((unsigned)(a0[u1 & 3u] == u3) | 1u)) + (unsigned)((short)7u > (signed char)0u));
            L3: if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((unsigned)((int)fuel < (int)8u) | ((unsigned)(5u < 4u) & (unsigned)w0)) & 1023u);
        }
    } while (i0++ < 3u && (unsigned)(unsigned char)((unsigned)(w0 >> 29) >> ((0x7fffffffu << ((unsigned)h0 & 31u)) & 31u)));
    r0.x = 0xdf3a1dd1u;
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)(w0 >> 29) || (0xffffffffu ^ (unsigned)h0)), (0xd53df11eu ? m0 : (unsigned)h0), (unsigned)(m0 || 0xb104f57du)); }
    if ((unsigned)c0) goto done;
    do { if (--fuel == 0u) goto done;
        *mp = (unsigned)(i0 == (unsigned)(unsigned char)(unsigned)((0xffffffffu - a0[i0 & 3u]) && u0));
        m0 ^= 0x80000000u;
        if (-(unsigned)((short)(i1 % (g1 | 1u)) > (signed char)4u)) break;
        a0[(unsigned)(r0.x == i2) & 3u] = (p2 & 0x3a62a484u);
        r0.x = 0xb67f47d4u;
        if (fuel < 8u) return m0;
    } while (i0++ < 5u && garr[i1 & 7u]);
    switch ((g1 >> ((unsigned)s1 & 31u)) & 7u) {
        e0 = e0 * 0.5L + (long double)(((0x80000000u | 0x8f4e4d99u) & fuel) & 1023u);
        if (((unsigned)d0 * v0)) {
            c0 = (unsigned char)*q0;
            if (0x87acb974u) break;
        } else {
            *q0 = (0xfb91f984u ? g1 : (unsigned)f0);
            u0 += -(garr[i1 & 7u] << (((unsigned)b0 & (unsigned)(short)((unsigned)((unsigned)l0 == *mp) << (0x6ca60539u & 31u))) & 31u));
            L4: if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if ((p1) & 1u) { t1 = (1u % (0x453b8fe7u | 1u)); z1 = (double)(((unsigned)(0x7fffffffu && ((unsigned)d0 | (unsigned)c1))) & 255u); } if ((p1) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                if ((unsigned)(0x6764a8bdu || (g0 >> (2u & 31u)))) goto L2;
                break; (void)((unsigned)(signed char)((unsigned)c1 / (0x120d419eu | 1u)));
                case 1u: ;
            }
        }
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 += 0xc9701662u;
        if (((0x9b06d64cu + (unsigned)s0) % (i1 | 1u))) {
            if (u3 == 7u) return (unsigned)!(0x280867d9u >> ((unsigned)(u2 < r0.y) & 31u));
            if (budget != 0u) { budget -= 1u; u3 = fn2((0x8e07f2afu << (i0 & 31u)), (unsigned)((int)i0 >= (int)(unsigned)((int)0xffffffffu >= (int)garr[i1 & 7u])), ~(unsigned)(r0.y < (unsigned)f0)); }
            if ((i0 >> ((unsigned)s1 & 31u))) break;
            *q0 = (p0 << (5u & 31u));
            r0.y ^= -(unsigned)((unsigned)d0 == fuel);
            c0 = (unsigned char)(unsigned)((unsigned)((short)fuel > (signed char)u3) || (i0 % (a0[u1 & 3u] | 1u)));
        }
        w0 ^= (unsigned long long)(0x89f40ed7u ^ v0) << ((((unsigned)(unsigned char)(0x42db686fu & 4u) - 0xffffffffu) / ((0xb7a38975u + fuel) | 1u)) & 63u);
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(g1 == (unsigned)h1) && u1) & 255u);
        if ((unsigned)b0) break;
    }
    switch (7u & 7u) {
        goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn1(0x7fffffffu, (unsigned)s1, (unsigned)((int)r0.y >= (int)(*mp ^ (unsigned)c0))); }
        s0 = (int)(u2 * g1);
        while ((unsigned)(a0[u1 & 3u] == 0x795fb621u)) { if (--fuel == 0u) goto done;
            case 1u: ;
            q0 = &garr[(-((unsigned)(unsigned char)((unsigned)(x0 >> 70) ^ 1u) << ((garr[i1 & 7u] / ((unsigned)w0 | 1u)) & 31u)) + 8u) & 7u];
            if ((unsigned)(unsigned char)(unsigned)((unsigned)((int)8u < (int)(unsigned)s1) == u1)) {
                if (budget != 0u) { budget -= 1u; u3 = fn0(((0x7eb196a2u >> ((unsigned)d0 & 31u)) | 4u), *q0, fuel); }
            }
        }
    }
    w0 = w0 * 6364136223846793005ull + 0x8987c4b3u;
    g1 += (unsigned)s1;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)(0x7fffffffu / (0x7fffffffu | 1u))) {
                g0 = ((unsigned)(x0 >> 70) * 0x7fffffffu);
                break; (void)((unsigned)(0xfc3c644bu && (unsigned)(5u < (unsigned)h0)));
            } else {
                if (((unsigned)((int)0x80000000u >= (int)(unsigned)s1) - *q0)) break;
                d0 = d0 * 0.5 + (double)((unsigned)((short)((unsigned)w0 << (u0 & 31u)) > (signed char)(5u ? 0xa71564aau : (unsigned)x0)) & 1023u);
                d0 = d0 * 0.5 + (double)((unsigned)((int)garr[u2 & 7u] < (int)i2) & 1023u);
            }
        }
        c1 = (signed char)(unsigned)((short)(unsigned)!(0x82834b00u * (unsigned)d0) > (signed char)(unsigned)(0xd5091f5du == 0x4696848fu));
        if ((unsigned)(i0 && (unsigned)h0)) break;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)(signed char)(7u - ((unsigned)((int)u0 >= (int)(unsigned)e0) ^ i2)) & 1023u);
        if ((unsigned)((int)4u < (int)(unsigned)d0)) break;
        g0 = (1u * (~(unsigned)((int)(unsigned)s0 >= (int)(unsigned)w0) << ((unsigned)s0 & 31u)));
        if (garr[i1 & 7u]) break;
        w0 ^= (unsigned long long)(unsigned)(u2 == (unsigned)b0) << (((unsigned)(u3 && (unsigned)b0) + i1) & 63u);
    } while (i0++ < 6u && -(0x7fffffffu - ((unsigned)c0 | 0x7fffffffu)));
    do { if (--fuel == 0u) goto done;
        switch ((*mp ^ 0x80000000u) & 7u) {
            if ((~(r0.y << (*mp & 31u)) << (2u & 31u))) {
                if (0x7fffffffu) break;
                if ((unsigned)((short)(unsigned)((unsigned)h1 || (unsigned)l0) > (signed char)0xaa48dc0du)) continue;
                c1 = (signed char)(unsigned)(signed char)(unsigned)(i0 == (unsigned)x0);
                case 6u: ;
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (7u) goto L4;
                    *mp = ((0xffffffffu - (u3 << (*q0 & 31u))) % ((unsigned)s1 | 1u));
                    if ((unsigned)((short)u0 > (signed char)(fuel / ((unsigned)c1 | 1u)))) goto L1;
                    w0 = w0 * 6364136223846793005ull + p1;
                    c0 = (unsigned char)(((unsigned)h1 << (~(3u & 0xe763d840u) & 31u)) << ((unsigned)((int)u0 < (int)g1) & 31u));
                }
                if ((unsigned)((short)8u > (signed char)(i0 / (p2 | 1u)))) {
                    do { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)c1, (r0.y | r0.y), (((unsigned)c1 >> (i1 & 31u)) ^ i2)); }
                    } while (i1++ < 3u && ((unsigned)(x0 >> 70) << ((unsigned)(g0 || (unsigned)c0) & 31u)));
                }
            } else {
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)s0, (p0 - fuel), (unsigned)((int)0xadbe0c1au >= (int)0x10000u)); }
                if ((r0.x ^ (unsigned)((int)0xae1f118eu >= (int)0xd027f1b1u))) break;
                { unsigned t0; double z0; if (((0x71602c21u << (fuel & 31u))) & 1u) { t0 = (unsigned)((1u % (5u | 1u)) && 4u); z0 = (double)((i0) & 255u); } if (((0x71602c21u << (fuel & 31u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                    d0 = d0 * 0.5 + (double)((unsigned)(0xffffffffu || (6u + (unsigned)c0)) & 1023u);
                    d0 = d0 * 0.5 + (double)((unsigned)(g1 || u1) & 1023u);
                    c0 = (unsigned char)garr[u2 & 7u];
                    c0 = (unsigned char)0x135582cau;
                    if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((p1 >> (0xb3eb7c7du & 31u)) || 0xce6b7514u), g1, (unsigned)e0); }
                    continue; (void)(0xffffffffu);
                }
                r0.y ^= 5u;
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn2(a0[u1 & 3u], (unsigned)((m0 * 0xfb0abf59u) || r0.y), (unsigned)f0); }
    } while (i0++ < 5u && (unsigned)(9u == 0xdacdc82au));
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)b0, (a0[i0 & 3u] << ((unsigned)((int)u0 >= (int)(unsigned)h0) & 31u)), (unsigned)((int)u0 < (int)u3)); }
    m0 ^= (unsigned)((short)0xffffffffu > (signed char)(unsigned)((a0[u1 & 3u] * g0) && i1));
    if (((unsigned)(unsigned char)(unsigned)(i0 < 7u) / (fuel | 1u))) goto L3;
    s0 = (int)(unsigned)((int)*q0 < (int)(unsigned)(i2 < (unsigned)c1));
    { unsigned t1; double z1; if ((((unsigned)(r0.x || (unsigned)(w0 >> 29)) ^ 0xffffffffu)) & 1u) { t1 = (unsigned)b0; z1 = (double)(((unsigned)((unsigned)c0 || 5u)) & 255u); } if ((((unsigned)(r0.x || (unsigned)(w0 >> 29)) ^ 0xffffffffu)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        { unsigned t2; double z2; if ((((unsigned)c0 + (unsigned)x0)) & 1u) { t2 = (unsigned)((unsigned)e0 == 5u); z2 = (double)(((garr[u2 & 7u] >> ((unsigned)((int)1u < (int)2u) & 31u))) & 255u); } if ((((unsigned)c0 + (unsigned)x0)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            while (i0++ < 7u && (0x2b820678u - 4u)) { if (--fuel == 0u) goto done;
                L0: if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + 0xc7075c06u);
                m0 ^= (((p1 / ((unsigned)(x0 >> 70) | 1u)) & (unsigned)l0) >> ((unsigned)d0 & 31u));
                if ((unsigned)((int)a0[u1 & 3u] < (int)((unsigned)c0 >> (u0 & 31u)))) break;
                L1: if (--fuel == 0u) goto done;
                b0 = 5u != 0u;
            }
            if ((unsigned)!(i2 * (0xa1f758a5u & 3u))) goto L3;
            if (a0[u1 & 3u]) goto L4;
            switch ((((unsigned)s1 * p2) - v0) & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(2u < (*q0 % ((unsigned)l0 | 1u))), ~(7u % (r0.x | 1u)), (r0.x | (unsigned)c1)); }
            }
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                switch (((unsigned)c1 << (a0[u1 & 3u] & 31u)) & 7u) {
                    L2: if (--fuel == 0u) goto done;
                    { unsigned t3; double z3; if ((((unsigned)h0 << (((unsigned)(w0 >> 29) ^ (unsigned)c0) & 31u))) & 1u) { t3 = ((unsigned)(short)(unsigned)((unsigned)h0 && a0[i0 & 3u]) / (i1 | 1u)); z3 = (double)((0x7fffffffu) & 255u); } if ((((unsigned)h0 << (((unsigned)(w0 >> 29) ^ (unsigned)c0) & 31u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        if ((u2 | ((unsigned)w0 - (unsigned)b0))) {
                            b0 = (unsigned)(short)(fuel >> (a0[i0 & 3u] & 31u)) != 0u;
                        } else {
                            if (budget != 0u) { budget -= 1u; u1 = fn1((i0 >> (g1 & 31u)), (unsigned)((v0 / ((unsigned)c1 | 1u)) < (unsigned)b0), (unsigned)c0); }
                            c0 = (unsigned char)((unsigned)c1 & v0);
                        }
                        w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)((int)(unsigned)((short)v0 > (signed char)3u) >= (int)(unsigned)(short)(0x80000000u << (p0 & 31u))) < garr[u2 & 7u]);
                    }
                    for (;;) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((0x93294c8bu | (unsigned)c0), (0xf654d093u >> (fuel & 31u)), (unsigned)!(8u * (r0.x * garr[i1 & 7u]))); }
                        case 4u: ;
                        q0 = &garr[(p0 ^ (garr[u2 & 7u] | ((unsigned)l0 | (v0 | (unsigned)s0)))) & 7u];
                    }
                    if (budget != 0u) { budget -= 1u; u2 = fn1(5u, (unsigned)(w0 >> 29), (unsigned)((short)0xffffffffu > (signed char)(unsigned)(w0 >> 29))); }
                    c0 = (unsigned char)(unsigned)(unsigned char)((unsigned)c1 + ((0x96343cc0u & (unsigned)h0) & (unsigned)(w0 >> 29)));
                    case 3u: ;
                }
                { unsigned t4; double z4; if ((((unsigned)(unsigned char)(0xb2ff0217u ^ 0xffffffffu) + 5u)) & 1u) { t4 = (unsigned)(w0 >> 29); z4 = (double)(((8u % (8u | 1u))) & 255u); } if ((((unsigned)(unsigned char)(0xb2ff0217u ^ 0xffffffffu) + 5u)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    s1 = (int)((unsigned)s1 + ~(unsigned)((short)(unsigned)w0 > (signed char)0xe884a9du));
                    if ((unsigned)((int)((unsigned)h0 >> (0xb4293699u & 31u)) >= (int)p0)) break;
                    b0 = u0 != 0u;
                }
                L3: if (--fuel == 0u) goto done;
                if ((unsigned)(0x7fffffffu && (unsigned)h0)) continue;
            }
        }
        switch ((unsigned)((short)(0x10000u * r0.x) > (signed char)0xa51ee753u) & 7u) {
            while (i0++ < 4u && (unsigned)(u1 < (unsigned)(unsigned char)(unsigned)(g1 || i1))) { if (--fuel == 0u) goto done;
                r0.x = ((unsigned)b0 >> (((0u + i0) | (unsigned)(short)(unsigned)((unsigned)s0 < u1)) & 31u));
            }
            g1 += (unsigned)(x0 >> 70);
            { unsigned t5; double z5; if (((r0.y % ((i2 >> (0u & 31u)) | 1u))) & 1u) { t5 = ((unsigned)s1 >> ((unsigned)e0 & 31u)); z5 = (double)(((unsigned)(v0 < (r0.x ^ g0))) & 255u); } if (((r0.y % ((i2 >> (0u & 31u)) | 1u))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                r0.x = (g0 & -(unsigned)((unsigned)s1 == (r0.x + u3)));
                if (budget != 0u) { budget -= 1u; u1 = fn1(1u, ((garr[i1 & 7u] ^ 4u) >> (6u & 31u)), (garr[u2 & 7u] / (i0 | 1u))); }
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)(p2 & 255u);
                }
                q0 = &garr[(unsigned)((int)p1 < (int)(unsigned)((i2 + 9u) == a0[u1 & 3u])) & 7u];
                c1 = (signed char)(unsigned)((int)(unsigned)s1 < (int)(unsigned)l0);
            }
            for (;;) { if (--fuel == 0u) goto done;
                b0 = (unsigned)((int)(unsigned)(short)(unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)h1)) >= (int)(unsigned)c1) != 0u;
            }
        }
        goto L0;
        r0.y ^= ((unsigned)b0 ? 0x7fffffffu : 0x10000u);
        garr[(0x42f7cdcfu | 0xffffffffu) & 7u] = (unsigned)(0xfade640fu == (unsigned)(0x7fffffffu < p1));
        i1 = (i0 / ((0x569e4810u ^ (unsigned)((int)(unsigned)l0 < (int)(0xa8fbdda4u & (unsigned)c0))) | 1u)) & 15u;
    }
    a0[(0x10000u * 0x17eba54eu) & 3u] = (unsigned)(v0 && 0x7443e050u);
    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(((unsigned)h0 / (0x80000000u | 1u)) ^ (unsigned)e0) & 1023u);
    d0 = d0 * 0.5 + (double)((unsigned)((int)g0 >= (int)((unsigned)c1 & ((unsigned)b0 + (u0 << ((unsigned)w0 & 31u))))) & 1023u);
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)(u0 & m0) < (int)garr[u2 & 7u]), i0, 0x2c38ccceu); }
    if (((unsigned)((unsigned)f0 == (unsigned)w0) ^ 9u)) goto L1;
    garr[((unsigned)(w0 >> 29) + 0x5ff8bfau) & 7u] = 0x7fffffffu;
    if (p2) goto L2;
    if (a0[i0 & 3u]) {
        q0 = &garr[0x8dbae5b9u & 7u];
    } else {
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch (((6u - (unsigned)(x0 >> 70)) + 0x7cd5c45eu) & 7u) {
                b0 = (unsigned)(a0[i0 & 3u] || ((2u & 0x3f794fddu) % ((6u + 0x7fffffffu) | 1u))) != 0u;
                r0.x = ((unsigned)h1 * (unsigned)h1);
                *q0 += r0.y;
                do { if (--fuel == 0u) goto done;
                    a0[(unsigned)(p0 || a0[i0 & 3u]) & 3u] = -(a0[i0 & 3u] % ((unsigned)((short)((u0 % (p2 | 1u)) & (unsigned)c1) > (signed char)3u) | 1u));
                    c0 = (unsigned char)(0x7fffffffu | (0xffffffffu + v0));
                    u2 ^= (~(fuel >> (a0[i0 & 3u] & 31u)) | (unsigned)(v0 == i1));
                    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)0x7fffffffu >= (int)(unsigned)w0), (unsigned)(signed char)(unsigned)((int)(0x10000u - (unsigned)s0) < (int)u2), u3); }
                    if ((garr[u2 & 7u] ? (unsigned)x0 : garr[u2 & 7u])) {
                        for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                            u3 ^= (v0 % (u1 | 1u));
                            goto L1;
                            L4: if (--fuel == 0u) goto done;
                            *q0 += ((r0.x % (u1 | 1u)) / ((9u * 0x12a87c64u) | 1u));
                            u2 += (g0 - (0x5ef735f7u * (unsigned)((unsigned)w0 == g1)));
                            f0 = f0 * 0.5f + (float)(fuel & 255u);
                        }
                    } else {
                        if ((u2 >> (0xeab15b77u & 31u))) continue;
                        if ((unsigned)((unsigned)((int)(unsigned)(w0 >> 29) < (int)4u) == (unsigned)x0)) {
                            c0 = (unsigned char)0xa588435cu;
                            g0 = (unsigned)((unsigned)(unsigned char)(unsigned)((short)9u > (signed char)0x669762adu) == ((fuel ^ (unsigned)f0) * p0));
                            l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(0x5986dac4u + (unsigned)(p1 == (unsigned)l0)));
                            if (1u) continue;
                            w0 ^= (unsigned long long)7u << ((((unsigned)((int)7u < (int)(unsigned)h1) << (u1 & 31u)) << (*mp & 31u)) & 63u);
                        } else {
                            u2 ^= 8u;
                            a0[(unsigned)((unsigned)s1 && (unsigned)d0) & 3u] = (((unsigned)(a0[i0 & 3u] == i1) >> (0xe9b1f116u & 31u)) >> (0x10000u & 31u));
                            case 4u: ;
                        }
                    }
                } while (i1++ < 5u && ((unsigned)(0x10000u || 0xdcc01985u) ^ (unsigned)b0));
                { unsigned t6; double z6; if ((((unsigned)x0 * v0)) & 1u) { t6 = (unsigned)((int)5u >= (int)(unsigned)(u0 && (unsigned)e0)); z6 = (double)(((((unsigned)d0 % (0x7837b1fu | 1u)) * garr[i1 & 7u])) & 255u); } if ((((unsigned)x0 * v0)) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                    w0 = w0 * 6364136223846793005ull + ((g0 ^ (unsigned)(signed char)(unsigned)((int)r0.y >= (int)garr[i1 & 7u])) - p0);
                    case 3u: ;
                }
            }
            s0 = (int)(0xf24c8293u - (garr[u2 & 7u] - ((unsigned)((int)(unsigned)d0 >= (int)7u) / ((unsigned)x0 | 1u))));
            if ((*q0 | (unsigned)c0)) {
                continue; (void)((0u + m0));
                m0 ^= (unsigned)(short)(unsigned)(fuel && r0.y);
                w0 = w0 * 6364136223846793005ull + (unsigned)(m0 == (unsigned)c1);
                w0 ^= (unsigned long long)(unsigned)((short)fuel > (signed char)(unsigned)e0) << (((0x7fffffffu / (0x80000000u | 1u)) % (0xf3caea36u | 1u)) & 63u);
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(-((unsigned)b0 | p0) || (unsigned)d0), (u1 % ((unsigned)w0 | 1u)), ((unsigned)h0 / (v0 | 1u))); }
                    l0 = (long)((unsigned long)l0 + (unsigned)((i2 >> (0x80000000u & 31u)) || (unsigned)(signed char)(0x10000u << (((unsigned)d0 - (unsigned)x0) & 31u))));
                } while (i1++ < 5u && ((unsigned)x0 | v0));
                if (((unsigned)c1 / (p1 | 1u))) break;
            }
            v0 = (unsigned)(unsigned char)(((unsigned)h1 | r0.y) << ((0xa413264bu + 0x98482241u) & 31u));
            if ((0u + (7u ^ (unsigned)(w0 >> 29)))) break;
        }
        w0 = w0 * 6364136223846793005ull + 0xacb2cbc2u;
        if (4u) goto L2;
        if ((unsigned)!(0xffffffffu ? (unsigned)h1 : 0xffffffffu)) goto L4;
    }
    switch ((unsigned)((int)0xb4a75894u < (int)0x7fffffffu) & 7u) {
        h1 = (unsigned short)(h1 + (((unsigned)s1 + 0x241d1a43u) | (unsigned)s1));
        u2 ^= r0.y;
        switch (a0[i0 & 3u] & 7u) {
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)(0xffffffffu < g1)) {
                    while (i1++ < 6u && ((unsigned)e0 ^ p0)) { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)(unsigned)((int)0x420c99e2u < (int)fuel) << ((unsigned)!(unsigned)((int)(unsigned)(x0 >> 70) < (int)0xffffffffu) & 63u);
                        w0 ^= (unsigned long long)0xffffffffu << ((0x7fffffffu * (unsigned)((short)(unsigned)x0 > (signed char)(u3 * 0x80b1d0e9u))) & 63u);
                    }
                    r0.x = ((unsigned)c1 & v0);
                } else {
                    case 2u: ;
                    switch ((unsigned)(unsigned char)(0x15f4c2ecu + (unsigned)(r0.x < p2)) & 7u) {
                        case 1u: ;
                        r0.x = (unsigned)((((unsigned)(w0 >> 29) | a0[u1 & 3u]) << ((unsigned)(0x59163176u < g1) & 31u)) == g1);
                    }
                    u3 += 0x9f188f7au;
                    s1 = (int)((unsigned)s1 + (unsigned)(((7u >> ((unsigned)h1 & 31u)) - i0) == (g1 | 8u)));
                }
            }
        }
        u0 = (unsigned)((0xf8d60e72u | 0u) || (unsigned)(p0 == 3u));
    }
    for (;;) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((4u >> (((unsigned)(x0 >> 70) / (a0[u1 & 3u] | 1u)) & 31u))) break;
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                s0 = (int)((unsigned)((int)(unsigned)s1 < (int)i0) >> (7u & 31u));
                u2 = (unsigned)(m0 || (unsigned)((short)((unsigned)l0 - (unsigned)(0x7fffffffu || r0.y)) > (signed char)5u));
                g0 = ((*q0 ^ 0x1d60168u) >> ((p0 / ((unsigned)(signed char)(unsigned)(0xf4c86804u < r0.y) | 1u)) & 31u));
                if ((0xd897603eu ? 0x80000000u : *mp)) break;
            }
            if (v0) break;
            *q0 += fuel;
            s0 = (int)(unsigned)(signed char)((unsigned)h1 ? 0xffffffffu : m0);
            c1 = (signed char)(unsigned)(u0 < i1);
        }
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((*q0 + 0x7fffffffu) & 255u);
            h1 = (unsigned short)(h1 + (unsigned)(((unsigned)((int)u0 < (int)(unsigned)w0) ^ 4u) || i1));
            if (budget != 0u) { budget -= 1u; u0 = fn3((0x10000u - (unsigned)(x0 >> 70)), (unsigned)!(unsigned)((unsigned)(signed char)(0x7fffffffu - garr[u2 & 7u]) == r0.y), (unsigned)(signed char)(unsigned)((int)i1 < (int)(unsigned)(0xf141677bu && (unsigned)e0))); }
            if (budget != 0u) { budget -= 1u; u2 = fn2(0x455257c1u, (unsigned)e0, (u2 - (unsigned)(w0 >> 29))); }
            if ((u2 * (unsigned)w0)) break;
        }
        r0.x = m0;
        if ((unsigned)(8u < (unsigned)(unsigned char)(0x10000u + 0xd3362c33u))) {
            garr[(unsigned)w0 & 7u] = 0x9eb582deu;
            if ((unsigned)d0) break;
            if ((unsigned)(signed char)(i2 >> ((0xa67dd0e7u & u2) & 31u))) goto done;
            switch (garr[i1 & 7u] & 7u) {
                i1 = ((unsigned)(unsigned char)((a0[i0 & 3u] + (a0[i0 & 3u] & *mp)) % (p0 | 1u)) | (unsigned)l0) & 15u;
                case 7u: ;
            }
            r0.x = (unsigned)(0x7fffffffu || (unsigned)b0);
        }
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0(((g1 + garr[i1 & 7u]) ^ (unsigned)h1), ((2u * i2) << (p1 & 31u)), (unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)b0 && 0x80000000u) || u3)); }
        c1 = (signed char)((unsigned)f0 - (unsigned)l0);
        w0 = w0 * 6364136223846793005ull + ((unsigned)b0 >> ((2u / ((unsigned)s0 | 1u)) & 31u));
    }
    if ((unsigned)((int)((unsigned)h1 | i1) < (int)2u)) goto L3;
    if (0u) goto done;
    switch ((3u ? (unsigned)e0 : (unsigned)h0) & 7u) {
        g1 += (unsigned)(p0 || ~((unsigned)d0 ^ (unsigned)x0));
        while (i0++ < 6u && ((unsigned)s0 << (p1 & 31u))) { if (--fuel == 0u) goto done;
            case 6u: ;
            a0[(unsigned)!(unsigned)((short)0x80000000u > (signed char)*q0) & 3u] = i0;
            if ((garr[i1 & 7u] ? u3 : 4u)) {
                { unsigned t7; double z7; if (((unsigned)((int)(unsigned)e0 >= (int)u0)) & 1u) { t7 = (unsigned)h1; z7 = (double)(((unsigned)((0x5a00539fu << ((unsigned)(x0 >> 70) & 31u)) == u2)) & 255u); } if (((unsigned)((int)(unsigned)e0 >= (int)u0)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                    do { if (--fuel == 0u) goto done;
                        for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                            s0 = (int)(p1 * ((a0[u1 & 3u] - 2u) ^ (unsigned)s0));
                            case 5u: ;
                            w0 = w0 * 6364136223846793005ull + ((unsigned)((unsigned)c1 == (unsigned)l0) * (0xae6e12bau & m0));
                            d0 = d0 * 0.5 + (double)((unsigned)(1u < (9u + 0u)) & 1023u);
                            if (budget != 0u) { budget -= 1u; u3 = fn1(u2, (unsigned)b0, (r0.y & (unsigned)(x0 >> 70))); }
                        }
                    } while (i1++ < 3u && (unsigned)((unsigned)c0 == p0));
                    h0 = (short)(unsigned)(8u || (((unsigned)e0 % (0u | 1u)) | (unsigned)((int)i1 >= (int)r0.y)));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((*mp | (unsigned)(unsigned char)((unsigned)(w0 >> 29) & (unsigned)b0)), 0x43277559u, (p1 * 0xa226a1bcu)); }
                }
                default: ;
                { unsigned t8; double z8; if (((unsigned)(garr[i1 & 7u] && (unsigned)x0)) & 1u) { t8 = (p1 << (garr[i1 & 7u] & 31u)); z8 = (double)((0x80000000u) & 255u); } if (((unsigned)(garr[i1 & 7u] && (unsigned)x0)) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                    m0 ^= (unsigned)(short)(u1 / ((unsigned)((int)fuel < (int)(r0.y ^ r0.y)) | 1u));
                    if (i2) break;
                    case 3u: ;
                    *q0 += (unsigned)((int)(unsigned)(signed char)(i0 + garr[i1 & 7u]) >= (int)0x80000000u);
                    garr[(unsigned)((int)(unsigned)f0 >= (int)(unsigned)d0) & 7u] = (unsigned)(((unsigned)l0 ? (unsigned)h0 : ((unsigned)e0 % (0x34018eb1u | 1u))) < r0.x);
                    break;
                }
                u1 ^= ~((fuel ^ (unsigned)((short)0x7fffffffu > (signed char)(unsigned)c0)) << ((unsigned)(signed char)(unsigned)(0x473e4795u == (unsigned)h1) & 31u));
                if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)(r0.x == r0.x), ((unsigned)e0 / ((unsigned)(x0 >> 70) | 1u)), 0xc50f4045u); }
            } else {
                garr[(unsigned)(u0 < 0x7fffffffu) & 7u] = (unsigned)((int)(0xffffffffu - fuel) < (int)(unsigned)(*mp < ((unsigned)h1 << ((unsigned)h1 & 31u))));
                if (budget != 0u) { budget -= 1u; u3 = fn2(-((unsigned)l0 >> (p0 & 31u)), (1u + p2), (unsigned)((int)(g0 % (*q0 | 1u)) < (int)0xd7f2ea96u)); }
            }
            case 0u: ;
        }
        if ((7u | (unsigned)((int)(unsigned)d0 < (int)2u))) {
            w0 ^= (unsigned long long)i0 << ((2u ^ 0xffffffffu) & 63u);
            while (i0++ < 2u && a0[i0 & 3u]) { if (--fuel == 0u) goto done;
                if (0x22c366du) {
                    b0 = (unsigned)((unsigned)(unsigned char)(i0 - 0x7fffffffu) && (u1 << (0xffffffffu & 31u))) != 0u;
                    break;
                    e0 = e0 * 0.5L + (long double)((((a0[u1 & 3u] + (unsigned)(4u || p2)) - *q0) - (unsigned)b0) & 1023u);
                } else {
                    x0 = x0 * 0x100000001b3ull + ((unsigned)(unsigned char)((unsigned)(w0 >> 29) + (0x1772ea57u % ((unsigned)c0 | 1u))) % (p2 | 1u));
                    garr[(v0 | u1) & 7u] = (-(unsigned)((short)(unsigned)(unsigned char)(3u + 0xdc838e78u) > (signed char)(unsigned)d0) - (unsigned)(unsigned char)(r0.y | (unsigned)(w0 >> 29)));
                }
                if (budget != 0u) { budget -= 1u; u3 = fn1((u3 << ((unsigned)((unsigned)f0 && p2) & 31u)), (v0 % ((unsigned)f0 | 1u)), (p2 ^ 0x7fffffffu)); }
            }
            u1 = ((unsigned)d0 - (unsigned)(0x80000000u && 6u));
            while ((unsigned)(short)(0x2018a076u | 0x7fffffffu)) { if (--fuel == 0u) goto done;
                u1 += (0x4c4c62f7u + (unsigned)((short)1u > (signed char)~((unsigned)h1 >> (u3 & 31u))));
                case 2u: ;
                l0 = (long)((unsigned long)l0 + fuel);
                m0 ^= (0x10000u ^ 0xc1812ea0u);
                u0 += (unsigned)((int)(v0 << (7u & 31u)) >= (int)(unsigned)c1);
            }
        } else {
            q0 = &garr[(unsigned)((int)(unsigned)((short)g0 > (signed char)0x620474b5u) < (int)6u) & 7u];
            u3 = (unsigned)(~((unsigned)s1 & fuel) < (r0.y >> ((p0 | g1) & 31u)));
        }
        u0 ^= ((unsigned)((short)a0[u1 & 3u] > (signed char)u0) & ((unsigned)(x0 >> 70) / (7u | 1u)));
        r0.y ^= (4u >> ((unsigned)!(9u / (7u | 1u)) & 31u));
        s0 = (int)(6u << (p1 & 31u));
    }
    if ((unsigned)b0) goto L3;
    goto done;
    h0 = (short)(unsigned)(u2 && (u2 << ((unsigned)s1 & 31u)));
    switch ((a0[i0 & 3u] * (unsigned)((short)0xaecd8ab0u > (signed char)0xe92d1274u)) & 7u) {
        case 1u: ;
        case 3u: ;
        r0.y ^= (unsigned)!((0x10000u % (0u | 1u)) % (((unsigned)s0 ? (unsigned)s0 : 2u) | 1u));
        if (0xffffffffu) break;
    }
    if ((unsigned)h0) goto L4;
    { unsigned t9; double z9; if ((u2) & 1u) { t9 = p0; z9 = (double)(((*q0 | g0)) & 255u); } if ((u2) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
        c1 = (signed char)((unsigned)c0 ? 0x80000000u : (unsigned)s1);
    }
    goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 1u, 0x245ed100u, 0x47f0a5fu },
        { 14u, 0xc79d4edcu, 0x3a99c3e5u },
        { 10u, 0x6a44a4dcu, 0x60544733u },
        { 7u, 0xa6a098a8u, 0xa97d97bu },
        { 5u, 0x8d4b838du, 0x9eefda3au },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
