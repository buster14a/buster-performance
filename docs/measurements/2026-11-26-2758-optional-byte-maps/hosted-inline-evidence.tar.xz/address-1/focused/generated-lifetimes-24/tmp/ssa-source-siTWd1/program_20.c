// test-ssa-source's program of seed 141000443 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x88b1029fu, g1 = 0x6418644du;
static unsigned garr[8] = { 0xd484a593u, 0x4300522au, 0x4b63ff01u, 0x92598e00u, 0x4de0e54eu, 0xe0730953u, 0x9a94f7e9u, 0x166832u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while (i0++ < 4u && (unsigned)((int)r0.x >= (int)(5u >> (*mp & 31u)))) { if (--fuel == 0u) goto done;
        if (0x7fffffffu) break;
        L0: if (--fuel == 0u) goto done;
        r0.x = (g1 | 9u);
        u3 = u3 * 0x9e3779b1u + ((7u % ((unsigned)e0 | 1u)) % (0x7fffffffu | 1u));
    }
    u3 ^= (unsigned)((int)0x665338a3u < (int)0x4216babeu);
    goto L2;
    c1 = (signed char)(unsigned)((int)(unsigned)s0 >= (int)(unsigned)(0x6a0d72a3u == (unsigned)(7u || 1u)));
    if ((garr[i1 & 7u] - (unsigned)((int)(unsigned)e0 < (int)i0))) goto L1;
    if (((unsigned)f0 * *q0)) goto L1;
    *mp = (unsigned)(6u == (unsigned)(i0 < u1));
    if (fuel < 8u) return (unsigned)(5u < (unsigned)((int)((unsigned)w0 ^ 0xe5364a96u) >= (int)(unsigned)h1));
    a0[(unsigned)(0x7fffffffu && u1) & 3u] = p1;
    l0 = (long)((unsigned long)l0 + ((unsigned)((int)0x7fffffffu < (int)(unsigned)c1) >> ((unsigned)((g1 & *q0) == fuel) & 31u)));
    goto L0;
    while (i0++ < 5u && (v0 & fuel)) { if (--fuel == 0u) goto done;
        if ((unsigned)(a0[u1 & 3u] || ((unsigned)b0 ^ g1))) {
            { unsigned t0; double z0; if (((r0.x ^ (unsigned)s0)) & 1u) { t0 = u3; z0 = (double)(((unsigned)(0xed2584bau || (0x80000000u >> ((unsigned)w0 & 31u)))) & 255u); } if (((r0.x ^ (unsigned)s0)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                if (0xffffffffu) continue;
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    { unsigned t1; double z1; if ((0x8be36b4du) & 1u) { t1 = (unsigned)(unsigned char)((unsigned)l0 ? 0xffffffffu : (unsigned)b0); z1 = (double)(((0u + u0)) & 255u); } if ((0x8be36b4du) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                        if (*mp) goto L4;
                        r0.x = p0;
                    }
                    garr[0x68722d7fu & 7u] = ((unsigned)((int)0x7fffffffu < (int)4u) * ((unsigned)w0 >> ((unsigned)f0 & 31u)));
                    do { if (--fuel == 0u) goto done;
                        v0 = (unsigned)((short)(m0 << (m0 & 31u)) > (signed char)(unsigned)s1);
                        q0 = &garr[((unsigned)((unsigned)(u0 || 1u) || g0) >> (u1 & 31u)) & 7u];
                        if ((0xf629de25u | 0xffffffffu)) {
                            if (((unsigned)(g0 == a0[i0 & 3u]) >> (9u & 31u))) break;
                            if (0x7fffffffu) break;
                            h1 = (unsigned short)(h1 + (~(u0 >> (i0 & 31u)) >> ((g1 << ((unsigned)((int)g1 < (int)i0) & 31u)) & 31u)));
                        } else {
                            L1: if (--fuel == 0u) goto done;
                            L2: if (--fuel == 0u) goto done;
                        }
                        v0 = (unsigned)((int)((unsigned)((int)0xb9e3847u >= (int)garr[i1 & 7u]) % (u1 | 1u)) < (int)0xd979b15cu);
                        a0[(unsigned)x0 & 3u] = (3u ^ (unsigned)(unsigned char)((unsigned)f0 % (0xcef683acu | 1u)));
                        a0[(unsigned)((short)0xffffffffu > (signed char)(unsigned)l0) & 3u] = ((~(0x6f2803d4u >> ((unsigned)c1 & 31u)) + v0) + (unsigned)(w0 >> 29));
                    } while (i2++ < 5u && ((0x7e4d0a49u / (*q0 | 1u)) & 0xffffffffu));
                    do { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)((unsigned)((short)(v0 ^ m0) > (signed char)-(unsigned)((int)0x80000000u < (int)(unsigned)(x0 >> 70))) & 255u);
                        *q0 += (unsigned)((unsigned)c1 && (unsigned)(x0 >> 70));
                        q0 = &garr[((unsigned)l0 - ((fuel - garr[i1 & 7u]) & p2)) & 7u];
                        w0 ^= (unsigned long long)(unsigned)(*mp || p0) << (~(unsigned)(0x10000u || 0xb71d0f75u) & 63u);
                    } while (i2++ < 5u && (unsigned)(fuel && 5u));
                }
            }
            *mp = r0.x;
            if ((unsigned)d0) break;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                goto done;
                *mp = garr[u2 & 7u];
                break; (void)((unsigned)((int)0x3746821fu >= (int)(unsigned)(signed char)(*q0 + i2)));
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(i0 - garr[i1 & 7u]) >= (int)0x10000u);
            }
            if (((unsigned)(unsigned char)(unsigned)((int)(unsigned)h0 < (int)a0[u1 & 3u]) >> (garr[u2 & 7u] & 31u))) break;
        }
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        L3: if (--fuel == 0u) goto done;
        break; (void)(((1u * garr[u2 & 7u]) - 0x7fffffffu));
        while (((unsigned)((unsigned)h0 == *q0) >> (i1 & 31u))) { if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
            if (u3 == 7u) return (3u + (unsigned)(a0[i0 & 3u] < (unsigned)(short)(0xffffffffu ? (unsigned)s0 : 0xb39f54bfu)));
        }
        break; (void)((unsigned)((unsigned)b0 || (unsigned)l0));
    }
    r0.x = p1;
    if ((((unsigned)h0 << (0x907b30c7u & 31u)) ^ 1u)) goto L0;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        q0 = &garr[0x463748f6u & 7u];
        c1 = (signed char)(unsigned)(a0[i0 & 3u] && (m0 ^ (unsigned)(a0[u1 & 3u] < a0[i0 & 3u])));
        a0[p1 & 3u] = 5u;
        x0 = x0 * 0x100000001b3ull + u3;
        { unsigned t2; double z2; if (((0xffffffffu + (0x84629026u ^ (unsigned)b0))) & 1u) { t2 = (m0 - (unsigned)w0); z2 = (double)(((((unsigned)(x0 >> 70) ^ r0.x) % (0x7fffffffu | 1u))) & 255u); } if (((0xffffffffu + (0x84629026u ^ (unsigned)b0))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            while (i1++ < 6u && (unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
                goto L3;
                w0 ^= (unsigned long long)(0x10000u << (0x4d59c09cu & 31u)) << ((unsigned)(((unsigned)l0 ^ 0x80000000u) == (unsigned)s1) & 63u);
                v0 = (((unsigned)(w0 >> 29) | (unsigned)f0) ? 4u : u3);
                while (i2++ < 6u && 0x7fffffffu) { if (--fuel == 0u) goto done;
                    if (u2) break;
                    x0 = x0 * 0x100000001b3ull + ((unsigned)(i2 && (unsigned)((unsigned)s1 == 0x5c88da7cu)) | r0.x);
                    switch ((unsigned)((int)5u >= (int)r0.y) & 7u) {
                        d0 = d0 * 0.5 + (double)((unsigned)((short)(~(i2 ^ 0x6a145d66u) >> (0x10000u & 31u)) > (signed char)r0.x) & 1023u);
                        if (0x9fd373acu) continue;
                        case 7u: ;
                    }
                    i1 = ((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)(x0 >> 70)) % ((unsigned)((unsigned)f0 || 0x168fe0abu) | 1u)) & 15u;
                }
                break; (void)((r0.y ^ (unsigned)x0));
            }
            r0.x = ((unsigned)(m0 && (unsigned)c1) ? u2 : fuel);
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)w0) {
                    break; (void)((r0.y - (u2 & (unsigned)h0)));
                    u1 = u1 * 0x9e3779b1u + u2;
                }
                break; (void)((unsigned)c1);
                if ((u2 | v0)) goto L1;
                s1 = (int)((unsigned)s1 + (a0[u1 & 3u] + garr[i1 & 7u]));
                if ((unsigned)(w0 >> 29)) {
                    if (((unsigned)c0 ^ *mp)) goto L1;
                    w0 ^= (unsigned long long)(0x7fffffffu >> (p2 & 31u)) << ((unsigned)c0 & 63u);
                    if (a0[u1 & 3u]) break;
                    if (0x10000u) break;
                    *q0 = (unsigned)(u3 < 7u);
                }
                if ((r0.x * (unsigned)x0)) break;
            }
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)(u2 || (garr[i1 & 7u] / (v0 | 1u))) < (unsigned)c0);
        }
    }
    l0 = (long)((unsigned long)l0 + ((unsigned)!(unsigned)((unsigned)(short)(unsigned)(p2 < u1) || r0.x) * (garr[i1 & 7u] / (r0.y | 1u))));
    *q0 = (unsigned)((short)(p1 ? i2 : i1) > (signed char)i1);
    if ((unsigned)(0x80000000u == u0)) goto done;
    *q0 = (unsigned)((unsigned)(fuel == m0) && 0xf0043d08u);
    f0 = f0 * 0.5f + (float)((unsigned)(short)((unsigned)h1 | u1) & 255u);
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)b0);
        u0 ^= (unsigned)((unsigned)((int)(0xf5cee300u | (unsigned)x0) < (int)((unsigned)b0 * (unsigned)(x0 >> 70))) < i2);
        s1 = (int)((unsigned)s1 + (unsigned)s0);
        break; (void)(((unsigned)h1 + p0));
        if (~(unsigned)((unsigned)w0 && (unsigned)((unsigned)h1 || p2))) goto L0;
        if (i1) break;
    }
    switch (p1 & 7u) {
        { unsigned t3; double z3; if (((1u | (unsigned)((int)m0 >= (int)u3))) & 1u) { t3 = (a0[u1 & 3u] / (r0.x | 1u)); z3 = (double)((m0) & 255u); } if (((1u | (unsigned)((int)m0 >= (int)u3))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            if ((unsigned)(2u == (unsigned)((int)i0 >= (int)i2))) goto L0;
        }
    }
    u3 = (unsigned)((int)(unsigned)(unsigned char)(unsigned)((unsigned)s0 && 0x82cece9fu) >= (int)0x10000u);
    if ((a0[u1 & 3u] - (unsigned)b0)) {
        if ((unsigned)((i1 | v0) || i2)) goto L1;
        while (i0++ < 4u && (0x10000u << (m0 & 31u))) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)a0[u1 & 3u] > (signed char)2u)) break;
            break; (void)(((unsigned)((int)v0 < (int)(unsigned)h1) << (4u & 31u)));
        }
        e0 = e0 * 0.5L + (long double)(((unsigned)(*q0 && (unsigned)(unsigned char)(g0 >> (p1 & 31u))) >> (garr[u2 & 7u] & 31u)) & 1023u);
        if ((unsigned)(i2 < 0x84a25aacu)) goto L1;
        if ((unsigned)e0) goto L3;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L4;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        v0 = ((4u & ((0x80000000u - 0x7fffffffu) ^ g1)) ^ (unsigned)s0);
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)r0.y >= (int)(unsigned)e0), 0x355f3240u, i1); }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(i0 == (unsigned)s0), ((unsigned)e0 % ((p2 - 0xc6269a86u) | 1u)), 0x80000000u); }
        *mp = (*mp + (unsigned)f0);
    }
    i2 = (i2 * (0x217a4c46u ? (unsigned)l0 : v0)) & 15u;
    { unsigned t0; double z0; if (((unsigned)(m0 == g1)) & 1u) { t0 = (i1 % ((unsigned)(p1 == a0[i0 & 3u]) | 1u)); z0 = (double)((((unsigned)c0 * (unsigned)h0)) & 255u); } if (((unsigned)(m0 == g1)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        while (9u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)4u << ((unsigned)!(unsigned)((short)(unsigned)((short)u0 > (signed char)u1) > (signed char)(unsigned)l0) & 63u);
            h1 = (unsigned short)(h1 + (unsigned)((0x9e430de4u << (u1 & 31u)) || ((unsigned)s0 & 1u)));
            r0.x = (unsigned)(w0 >> 29);
            u1 = (4u % (u0 | 1u));
        }
        do { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)x0 == a0[i0 & 3u]) - (5u | 1u)));
        } while (i0++ < 2u && (unsigned)(unsigned char)(8u & i0));
        r0.y ^= ((unsigned)((int)p2 < (int)garr[i1 & 7u]) / ((unsigned)((short)(unsigned)(*mp < (unsigned)c1) > (signed char)(unsigned)e0) | 1u));
        d0 = d0 * 0.5 + (double)((unsigned)(0xffffffffu || (unsigned)((int)8u < (int)(unsigned)d0)) & 1023u);
        u1 ^= (unsigned)b0;
    }
    if ((0xffffffffu % ((unsigned)w0 | 1u))) goto L2;
    if ((3u >> (r0.y & 31u))) goto done;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)h1 ^ *q0), (0xffffffffu % (0x7fffffffu | 1u)), ((unsigned)((short)8u > (signed char)*q0) % (p2 | 1u))); }
        if (budget != 0u) { budget -= 1u; u2 = fn0(0x9fc92f29u, (7u ^ (unsigned)((unsigned)e0 && (unsigned)s0)), ((unsigned)!(unsigned)(i1 == u3) | 0xfe19fde4u)); }
        for (;;) { if (--fuel == 0u) goto done;
            u3 += (((unsigned)h1 >> (r0.x & 31u)) & ((unsigned)x0 << (r0.x & 31u)));
            if ((((unsigned)d0 * i2) + 6u)) {
                goto done;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (i0) break;
                    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                        u0 ^= -(unsigned)((unsigned)((int)(unsigned)w0 < (int)(unsigned)f0) && p1);
                        L1: if (--fuel == 0u) goto done;
                        break; (void)((unsigned)!((unsigned)b0 + 7u));
                        u1 = garr[i1 & 7u];
                    }
                    garr[(unsigned)(w0 >> 29) & 7u] = ((unsigned)((short)(unsigned)(short)((unsigned)h1 | p0) > (signed char)a0[i0 & 3u]) - (unsigned)h1);
                }
                if ((unsigned)s0) {
                    if (6u) break;
                    i0 = 7u & 15u;
                    L2: if (--fuel == 0u) goto done;
                    switch (((unsigned)f0 & 2u) & 7u) {
                        if ((unsigned)s0) continue;
                        i0 = 5u & 15u;
                        if (p2) continue;
                        r0.x = (unsigned)((int)(u3 * g1) < (int)((unsigned)s1 - (unsigned)(signed char)(unsigned)((int)1u >= (int)(unsigned)s1)));
                        break; (void)(((unsigned)c1 * i1));
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0x7fffffffu || (unsigned)((short)p1 > (signed char)0xffffffffu)), ((unsigned)c0 - ~(unsigned)((short)r0.x > (signed char)(unsigned)s0)), (unsigned)(*mp < u2)); }
                    do { if (--fuel == 0u) goto done;
                        u1 += (unsigned)(signed char)((unsigned)(x0 >> 70) ^ (unsigned)f0);
                        h1 = (unsigned short)(h1 + ((*mp % (p2 | 1u)) + 0xdf3f0629u));
                        if (6u) continue;
                        w0 = w0 * 6364136223846793005ull + *q0;
                        h0 = (short)(unsigned)((int)0xcb9fde89u >= (int)(r0.x ? (unsigned)w0 : garr[u2 & 7u]));
                    } while (i2++ < 6u && (g0 >> (0x80000000u & 31u)));
                }
                continue; (void)((unsigned)(0x96c17cd5u || (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)w0)));
                continue; (void)((unsigned)((unsigned)h1 && u2));
            } else {
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)(i1 == (unsigned)l0) * (unsigned)h0), ((unsigned)d0 + 0x80000000u), 5u); }
                g0 = (unsigned)((int)(0x7fffffffu % (u2 | 1u)) < (int)(0x73ec48d2u & a0[u1 & 3u]));
                u1 += (unsigned)((short)((unsigned)(garr[u2 & 7u] && 8u) << ((unsigned)(garr[u2 & 7u] && (unsigned)s1) & 31u)) > (signed char)(unsigned)c1);
            }
        }
    }
    if (garr[u2 & 7u]) goto L2;
    if (((unsigned)(7u < 0x4a27185cu) ^ 0x8c920fefu)) goto L1;
    { unsigned t1; double z1; if (((unsigned)((int)p0 < (int)2u)) & 1u) { t1 = (*mp % (9u | 1u)); z1 = (double)(((unsigned)((short)(unsigned)b0 > (signed char)p1)) & 255u); } if (((unsigned)((int)p0 < (int)2u)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        if ((((unsigned)c0 | (unsigned)w0) * (unsigned)(x0 >> 70))) {
            e0 = e0 * 0.5L + (long double)((~(v0 + (u0 & 6u)) ^ m0) & 1023u);
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)!(unsigned)((short)i2 > (signed char)4u), p1, 0xffffffffu); }
            }
        } else {
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(a0[u1 & 3u] && (unsigned)((short)0x3008d711u > (signed char)0xffffffffu)), ((p0 - *mp) * (unsigned)(x0 >> 70)), (unsigned)((int)a0[u1 & 3u] >= (int)0x2b46b857u)); }
            x0 = x0 * 0x100000001b3ull + -((unsigned)!(unsigned)((short)((unsigned)w0 / (p0 | 1u)) > (signed char)(unsigned)h1) & (unsigned)w0);
            if (v0) {
                if (budget != 0u) { budget -= 1u; u3 = fn0((0x115d2e01u & 0u), ((unsigned)c1 / (0xcd3f251u | 1u)), (((unsigned)(x0 >> 70) | (unsigned)f0) << (*q0 & 31u))); }
                L3: if (--fuel == 0u) goto done;
                i0 = (unsigned)l0 & 15u;
                if ((u2 * a0[u1 & 3u])) goto L0;
                switch ((unsigned)((int)0x7fffffffu < (int)(unsigned)!(v0 * i1)) & 7u) {
                    if ((unsigned)(signed char)(i2 >> ((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)c1) & 31u))) {
                        f0 = f0 * 0.5f + (float)(((*mp | (unsigned)l0) >> ((unsigned)((unsigned)c1 == (unsigned)(fuel || (unsigned)(w0 >> 29))) & 31u)) & 255u);
                        if (9u) goto L2;
                        e0 = e0 * 0.5L + (long double)(((unsigned)(i0 && (unsigned)(x0 >> 70)) | 0x44bf5665u) & 1023u);
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)(garr[i1 & 7u] >> ((unsigned)h0 & 31u)), -(unsigned)(p1 == (unsigned)((unsigned)x0 && *mp)), ((unsigned)b0 >> ((unsigned)w0 & 31u))); }
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!((unsigned)s0 | (unsigned)((unsigned)s0 || u3)), garr[u2 & 7u], 2u); }
                    }
                    w0 = w0 * 6364136223846793005ull + ((u3 & 0x496987beu) << ((*mp + p0) & 31u));
                    g1 += (0x80000000u >> ((unsigned)((unsigned)s0 || (unsigned)h1) & 31u));
                    L4: if (--fuel == 0u) goto done;
                    u2 += (((i0 >> (m0 & 31u)) ^ (unsigned)s1) | 0x80000000u);
                    e0 = e0 * 0.5L + (long double)((u1 >> ((unsigned)((unsigned)f0 || (unsigned)(0x1ac45c33u < (p2 - 0x9df28ebau))) & 31u)) & 1023u);
                }
                g1 += (unsigned)s0;
            }
            switch ((i0 % (0x80000000u | 1u)) & 7u) {
                u2 = (unsigned)(short)(unsigned)(6u && p1);
                if ((unsigned)(unsigned char)(unsigned)((int)g0 >= (int)(unsigned)c0)) goto L1;
                if (*q0) goto L0;
                switch ((unsigned)!(a0[u1 & 3u] % (m0 | 1u)) & 7u) {
                    d0 = d0 * 0.5 + (double)((i0 ^ (unsigned)c0) & 1023u);
                }
            }
        }
        while (i0++ < 6u && (unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)h1)) { if (--fuel == 0u) goto done;
            *q0 += 2u;
            if ((p2 ^ i2)) break;
            if (((unsigned)b0 + ~(p1 * r0.x))) break;
            m0 ^= (unsigned)(v0 < v0);
            for (;;) { if (--fuel == 0u) goto done;
                break; (void)(i1);
                u1 = ((unsigned)((unsigned)c1 && r0.y) % ((unsigned)!(*q0 ^ 0x7fffffffu) | 1u));
            }
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((u1 - v0), (unsigned)(x0 >> 70), (0x80000000u >> ((unsigned)(x0 >> 70) & 31u))); }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + ((unsigned)!(g0 ? g1 : 0x10000u) / ((unsigned)x0 | 1u));
        }
        if (p0) goto L3;
    }
    s0 = (int)(unsigned)((unsigned)((short)0x7fffffffu > (signed char)p1) || (unsigned)(signed char)(unsigned)(0x9ab7640u && (unsigned)(0xd9a4ea16u < (unsigned)c0)));
    v0 = (unsigned)l0;
    do { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)((unsigned)h1 < fuel));
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((u0 * (unsigned)x0)) break;
            while (i2++ < 7u && (fuel + (unsigned)(p0 == 3u))) { if (--fuel == 0u) goto done;
                { unsigned t2; double z2; if (((m0 >> (g1 & 31u))) & 1u) { t2 = (unsigned)((short)0x10000u > (signed char)0x4b5ac697u); z2 = (double)((((unsigned)c1 >> (r0.x & 31u))) & 255u); } if (((m0 >> (g1 & 31u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    break; (void)(9u);
                    q0 = &garr[((unsigned)(*q0 || (unsigned)s1) * ((unsigned)d0 * g0)) & 7u];
                    switch ((unsigned)((int)*mp < (int)i2) & 7u) {
                        case 0u: ;
                        h1 = (unsigned short)(h1 + (unsigned)(short)(u3 | ((unsigned)w0 << (fuel & 31u))));
                        default: ;
                        *mp = (unsigned)e0;
                        v0 = (unsigned)s1;
                        u1 = ((a0[u1 & 3u] / ((unsigned)d0 | 1u)) & i0);
                    }
                    if ((unsigned)(unsigned char)((unsigned)h0 | (unsigned)(r0.y || (unsigned)h0))) break;
                    m0 ^= (unsigned)(m0 < ~(unsigned)(v0 && (unsigned)((int)7u >= (int)(unsigned)s1)));
                }
                if ((unsigned)l0) goto done;
                c1 = (signed char)((6u / (g0 | 1u)) ^ (unsigned)(u1 == 0x80000000u));
                m0 ^= (m0 << ((unsigned)(u3 < (unsigned)(i1 || (unsigned)l0)) & 31u));
            }
            if (2u) break;
            if (budget != 0u) { budget -= 1u; u1 = fn0((r0.y - (unsigned)s0), u1, 0u); }
            g1 += (unsigned)!(unsigned)((short)p1 > (signed char)(u1 ^ fuel));
        }
        f0 = f0 * 0.5f + (float)(((unsigned)c1 ^ ((unsigned)w0 << (u1 & 31u))) & 255u);
    } while (i0++ < 4u && (unsigned)(a0[u1 & 3u] < (unsigned)((unsigned)f0 || 0x10000u)));
    goto done;
    if (0x61bd8b6bu) {
        goto L1;
        while (i0++ < 6u && (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)h0)) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)c0 & 1023u);
            if (budget != 0u) { budget -= 1u; u1 = fn0((a0[i0 & 3u] % (p2 | 1u)), ((0x949c8a5cu << (0x47b36f0bu & 31u)) | 0x7fffffffu), ((unsigned)(a0[u1 & 3u] == garr[i1 & 7u]) >> (p0 & 31u))); }
            if (~((unsigned)d0 ^ (unsigned)(x0 >> 70))) {
                garr[((unsigned)s0 & 0xcac1a351u) & 7u] = (unsigned)(p2 < (unsigned)((int)(unsigned)((short)0x7d63ba18u > (signed char)(unsigned)h0) >= (int)0xc8bb0780u));
            } else {
                goto done;
                c1 = (signed char)(unsigned)(0x814bfd75u && g1);
                if ((unsigned)(a0[u1 & 3u] && 4u)) {
                    garr[*mp & 7u] = (3u << (~((unsigned)(unsigned char)(unsigned)(i2 == 0xc7af582u) | (unsigned)c1) & 31u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0(i1, garr[i1 & 7u], (unsigned)(unsigned char)((9u + 3u) + 0x655a4544u)); }
                    s1 = (int)((unsigned)s1 + ((unsigned)((int)8u < (int)(unsigned)s0) ^ u0));
                }
            }
            switch ((unsigned)!(unsigned)((u2 ^ i1) && (unsigned)s0) & 7u) {
                *q0 += ~(0x10000u ^ (g1 | (u1 % (0x8dcf82ddu | 1u))));
                *q0 += ((unsigned)x0 >> (0x7fffffffu & 31u));
            }
        }
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)s1) continue;
    }
    goto L3;
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)c0, ((0x6dfbeebfu & 0x80000000u) - 0x10000u), (unsigned)((int)((unsigned)l0 % ((unsigned)f0 | 1u)) >= (int)0x10000u)); }
    if ((p0 / ((unsigned)f0 | 1u))) {
        u3 = u3 * 0x9e3779b1u + (unsigned)((int)u1 < (int)r0.x);
        if (*mp) goto L1;
    } else {
        do { if (--fuel == 0u) goto done;
            f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(5u ^ ((1u | p0) / (u0 | 1u))) & 255u);
            s0 = (int)(-(((unsigned)c1 / ((unsigned)c1 | 1u)) ^ 5u) * (unsigned)((short)i2 > (signed char)3u));
            u0 = 0x10000u;
            *q0 = (i0 | (unsigned)(((unsigned)l0 ^ r0.y) == garr[u2 & 7u]));
            u3 ^= ((unsigned)f0 - (r0.y & (unsigned)x0));
            if ((a0[i0 & 3u] / ((0xffffffffu & 0xffffffffu) | 1u))) continue;
        } while (i0++ < 7u && (unsigned)(signed char)((unsigned)e0 / (8u | 1u)));
    }
    if ((unsigned)(a0[i0 & 3u] || (unsigned)(w0 >> 29))) goto L0;
    c1 = (signed char)((unsigned)h1 / ((unsigned)(a0[i0 & 3u] == i0) | 1u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L4;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)f0 * 0x10000u), m0, (unsigned)c0); }
        L0: if (--fuel == 0u) goto done;
    } while (i0++ < 2u && (i2 * m0));
    goto L1;
    do { if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
        if ((p2 | (unsigned)x0)) {
            if ((unsigned)((short)*q0 > (signed char)i1)) continue;
        } else {
            if ((unsigned)((int)(unsigned)((int)7u >= (int)garr[i1 & 7u]) < (int)(unsigned)e0)) goto L1;
        }
        while (i1++ < 6u && ((unsigned)((unsigned)h0 == r0.y) * 0x10000u)) { if (--fuel == 0u) goto done;
            *q0 = (unsigned)(garr[u2 & 7u] == ((unsigned)((int)i0 >= (int)garr[u2 & 7u]) << (1u & 31u)));
            u3 = (0x10000u * ((unsigned)w0 >> ((unsigned)(x0 >> 70) & 31u)));
            for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t0; double z0; if ((u3) & 1u) { t0 = (p0 * 3u); z0 = (double)((m0) & 255u); } if ((u3) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                    l0 = (long)((unsigned long)l0 + ((*mp ^ (unsigned)(x0 >> 70)) >> ((*q0 >> ((unsigned)e0 & 31u)) & 31u)));
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((unsigned)b0 < garr[u2 & 7u]) + (unsigned)l0), (unsigned)(p2 && (unsigned)((int)g0 < (int)(unsigned)h0)), (unsigned)(p0 && 0x19c83418u)); }
                l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(short)(~((unsigned)((short)0x8f12bc3fu > (signed char)0xffffffffu) % (u1 | 1u)) | 0x7fffffffu) < (int)g1));
            }
            a0[garr[i1 & 7u] & 3u] = 4u;
        }
        v0 = (unsigned)(((unsigned)((unsigned)c0 || fuel) ^ p1) < 5u);
        s1 = (int)((unsigned)s1 + ~((2u - (0x10000u + (unsigned)b0)) << (5u & 31u)));
    } while (i0++ < 7u && (unsigned)((int)a0[i0 & 3u] >= (int)(a0[i0 & 3u] >> ((unsigned)f0 & 31u))));
    goto L1;
    if (u3 == 7u) return 1u;
    { unsigned t1; double z1; if (((unsigned)(0xa535a050u == (unsigned)x0)) & 1u) { t1 = (unsigned)h0; z1 = (double)(((garr[i1 & 7u] % ((4u + r0.y) | 1u))) & 255u); } if (((unsigned)(0xa535a050u == (unsigned)x0)) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        do { if (--fuel == 0u) goto done;
            break; (void)(5u);
            h1 = (unsigned short)(h1 + ((unsigned)f0 ^ m0));
            l0 = (long)((unsigned long)l0 + (4u << (0x80000000u & 31u)));
            c1 = (signed char)(0u + u3);
            L2: if (--fuel == 0u) goto done;
            g1 += (unsigned)((int)0xffffffffu < (int)(unsigned)((int)(unsigned)e0 < (int)(unsigned)((unsigned)(signed char)(0x80000000u % (0x80000000u | 1u)) && m0)));
        } while (i0++ < 5u && (unsigned)h0);
        e0 = e0 * 0.5L + (long double)(((unsigned)(w0 >> 29) & (unsigned)(short)(8u - a0[i0 & 3u])) & 1023u);
    }
    g0 = (unsigned)((r0.y * i0) < (unsigned)d0);
    h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(unsigned)((unsigned)c1 || (a0[i0 & 3u] >> (0x80000000u & 31u))));
    goto L4;
    h0 = (short)(0xffffffffu ^ fuel);
    goto done;
    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)e0 << ((unsigned)l0 & 31u)), (unsigned)(0x80000000u || i0), garr[u2 & 7u]); }
    if ((unsigned)l0) goto L3;
    i0 = (0x80000000u << ((unsigned)((unsigned)s1 && u3) & 31u)) & 15u;
    for (;;) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((int)(unsigned)h1 >= (int)(unsigned)(unsigned char)(v0 * p2)));
        do { if (--fuel == 0u) goto done;
            while (((unsigned)h0 & (unsigned)d0)) { if (--fuel == 0u) goto done;
                if ((i0 & (unsigned)((unsigned)s1 || (unsigned)l0))) break;
                r0.x = 0x25139aabu;
                break; (void)(((unsigned)(8u || garr[u2 & 7u]) - 0x33000c52u));
                if ((unsigned)((a0[i0 & 3u] * p0) && (unsigned)l0)) continue;
                if ((unsigned)(((unsigned)h1 * 0xffffffffu) == u0)) continue;
            }
            if ((unsigned)((int)6u < (int)i0)) break;
            u2 += a0[u1 & 3u];
            b0 = ((0x89b105beu + i2) - 0u) != 0u;
            w0 ^= (unsigned long long)g1 << (((unsigned)((unsigned)l0 && m0) + (unsigned)(x0 >> 70)) & 63u);
            *q0 = ((p1 - a0[u1 & 3u]) % ((unsigned)(p1 == (4u * *q0)) | 1u));
        } while (i1++ < 7u && (unsigned)((int)(unsigned)s0 >= (int)(unsigned)((int)i0 >= (int)i1)));
        c0 = (unsigned char)((unsigned)((unsigned)((int)0x80000000u < (int)g0) || (0x10000u - i2)) / (i1 | 1u));
        if (((unsigned)((unsigned)l0 < u0) << ((unsigned)h0 & 31u))) {
            if ((0xbd55f564u * (unsigned)(g0 < 0x7fffffffu))) break;
        }
        switch (0x799b4a3eu & 7u) {
            s0 = (int)((unsigned)(0x7fffffffu && (unsigned)s1) >> (0xb067d122u & 31u));
        }
        l0 = (long)((unsigned long)l0 + (unsigned)l0);
    }
    do { if (--fuel == 0u) goto done;
        L3: if (--fuel == 0u) goto done;
        if (0x8fd462efu) {
            r0.y ^= (unsigned)((int)(unsigned)l0 >= (int)(0x10000u * garr[i1 & 7u]));
            f0 = f0 * 0.5f + (float)((unsigned)((int)m0 < (int)((0xffffffffu >> ((unsigned)w0 & 31u)) ? 0x10000u : p1)) & 255u);
            u2 += (0x63b71ca5u ^ (unsigned)(garr[u2 & 7u] < (m0 ? 5u : garr[u2 & 7u])));
            switch ((p0 ? (unsigned)d0 : garr[i1 & 7u]) & 7u) {
                u1 ^= ((unsigned)(signed char)(unsigned)((int)0xcebfc73u >= (int)(0x80000000u % (0x10000u | 1u))) | 0x10000u);
            }
            u2 ^= (unsigned)((i1 % ((unsigned)d0 | 1u)) < 0x51a7f526u);
        }
        h0 = (short)(unsigned)(p0 || (r0.x ? 0u : ~(u0 - a0[i0 & 3u])));
        u0 = (unsigned)h0;
        if (0u) {
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)((r0.y ^ i2) && (7u | (unsigned)b0));
                if ((0x10000u ^ 0xf7e4a250u)) break;
            }
            s1 = (int)((unsigned)s1 + ((unsigned)e0 & i2));
        } else {
            i1 = ((unsigned)((unsigned)(i1 == *mp) < a0[i0 & 3u]) << ((unsigned)((int)(unsigned)h1 < (int)(unsigned)c1) & 31u)) & 15u;
            if (budget != 0u) { budget -= 1u; u2 = fn0((r0.y ^ (g0 << (u1 & 31u))), (unsigned)x0, (unsigned)(w0 >> 29)); }
        }
    } while (i0++ < 4u && (a0[i0 & 3u] >> (0x80000000u & 31u)));
    if (budget != 0u) { budget -= 1u; u3 = fn1((((unsigned)f0 * 6u) + (unsigned)c1), 5u, (unsigned)((int)((unsigned)h1 + 4u) < (int)p1)); }
    switch (((unsigned)h0 ? (unsigned)e0 : u0) & 7u) {
        u3 += ((p1 - (unsigned)x0) % (((unsigned)((int)v0 < (int)0xa72437e0u) * m0) | 1u));
        if (((unsigned)c0 ? (unsigned)(x0 >> 70) : *q0)) {
            if (budget != 0u) { budget -= 1u; u1 = fn0(0x55df437du, (*mp % (0x89fb57a4u | 1u)), (0xb9783ab3u << (1u & 31u))); }
            if (u2) break;
            L4: if (--fuel == 0u) goto done;
        }
    }
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)(a0[i0 & 3u] || (unsigned)(a0[i0 & 3u] && p2))) break;
        { unsigned t2; double z2; if (((unsigned)(0xffffffffu == 3u)) & 1u) { t2 = (unsigned)(unsigned char)(p0 << ((0u | (unsigned)c0) & 31u)); z2 = (double)((((unsigned)d0 % (i1 | 1u))) & 255u); } if (((unsigned)(0xffffffffu == 3u)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
            if (((unsigned)x0 ^ 9u)) break;
            goto done;
            break; (void)((0xffffffffu & (unsigned)((int)fuel >= (int)0x7fffffffu)));
            x0 = x0 * 0x100000001b3ull + ((unsigned)x0 / ((-(r0.y / (u3 | 1u)) % (r0.y | 1u)) | 1u));
        }
        break; (void)((unsigned)((int)2u < (int)(g0 << (0x2f89f12eu & 31u))));
        if (budget != 0u) { budget -= 1u; u0 = fn0(0xef4159fu, (unsigned)(signed char)((unsigned)b0 >> (garr[i1 & 7u] & 31u)), (9u - (unsigned)((int)u3 < (int)0x7fffffffu))); }
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            continue; (void)((u1 ^ 5u));
            while (i2++ < 2u && (unsigned)((unsigned)b0 && i1)) { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= ((unsigned)w0 >> ((unsigned)h1 & 31u));
                    if ((p1 / (0xffffffffu | 1u))) goto L0;
                }
                if (((unsigned)(signed char)(unsigned)(a0[i0 & 3u] || 0x8d3a440fu) % (*mp | 1u))) break;
                w0 = w0 * 6364136223846793005ull + (*mp ? a0[i0 & 3u] : *q0);
                break; (void)((unsigned)(p2 || 5u));
                e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)x0 >= (int)((unsigned)c1 ^ (unsigned)(0x10000u && (unsigned)d0))) & 1023u);
            }
        }
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((0xbdeda6b4u >> ((1u / (0xba699269u | 1u)) & 31u)), (unsigned)(0x45390febu < (g0 % (a0[u1 & 3u] | 1u))), (unsigned)s1); }
    l0 = (long)((unsigned long)l0 + ~((unsigned)d0 - (unsigned)h0));
    u3 += ((unsigned)h1 >> ((unsigned)b0 & 31u));
    u2 += (unsigned)((int)((unsigned)((int)0x97b0d55du < (int)0x949c99e8u) / ((a0[u1 & 3u] | 0xffffffffu) | 1u)) < (int)*mp);
    *q0 = (~(unsigned)(8u && (unsigned)e0) % ((unsigned)(short)(unsigned)((int)0x8ec87dafu < (int)p0) | 1u));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (0u ^ (unsigned)(((unsigned)e0 | 0x40840f5fu) == (6u - p2))));
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            *mp = (unsigned)((g0 % (m0 | 1u)) < (unsigned)h1);
            while (i2++ < 5u && (0xffffffffu + 7u)) { if (--fuel == 0u) goto done;
                c1 = (signed char)(unsigned)((int)(unsigned)((int)*mp < (int)(i1 % ((garr[u2 & 7u] & v0) | 1u))) >= (int)0x8c708585u);
            }
            r0.y ^= (unsigned)((int)(0x7fffffffu / (i2 | 1u)) >= (int)(unsigned)e0);
            g0 = ((*mp & 0xacb641ecu) << ((unsigned)(x0 >> 70) & 31u));
        }
        switch (m0 & 7u) {
            h0 = (short)(unsigned)(short)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)(signed char)((unsigned)b0 & p0));
            w0 ^= (unsigned long long)(unsigned)x0 << (~(0x868454abu % ((unsigned)((int)(unsigned)c0 >= (int)~((6u - 3u) + *q0)) | 1u)) & 63u);
            if ((0u + 0xeeb9140au)) {
                if ((unsigned)(0xa9542718u && g0)) goto L3;
                m0 ^= (unsigned)((7u % (m0 | 1u)) || p2);
                *mp = (g1 / (((unsigned)((int)(unsigned)w0 < (int)0x7fffffffu) - (unsigned)c0) | 1u));
            } else {
                c0 = (unsigned char)((unsigned)l0 & 0x7fffffffu);
            }
            c1 = (signed char)(r0.y >> ((unsigned)h1 & 31u));
        }
        r0.y ^= r0.y;
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)((unsigned)(*q0 && ((unsigned)((unsigned)(w0 >> 29) || *q0) / (0xdfa7bd4cu | 1u))) == i2);
        if ((((unsigned)x0 << ((unsigned)d0 & 31u)) - u2)) break;
        break; (void)((g0 >> ((unsigned)((int)0xffffffffu < (int)(unsigned)h0) & 31u)));
        m0 ^= (((unsigned)!((unsigned)s0 + u0) * garr[u2 & 7u]) ^ (unsigned)((short)u1 > (signed char)p0));
        q0 = &garr[0x656e5be9u & 7u];
        break; (void)((g0 & a0[u1 & 3u]));
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((int)u1 >= (int)(unsigned)b0) - m0), (unsigned)s0, (unsigned)((int)u1 >= (int)(unsigned)s0)); }
        u1 += ((a0[i0 & 3u] * ((unsigned)l0 / (g1 | 1u))) & (unsigned)s1);
        r0.y ^= (unsigned)(short)(unsigned)(~(0xffffffffu / (4u | 1u)) < r0.y);
        *q0 += ((p2 * (unsigned)f0) - (unsigned)((int)(unsigned)s1 >= (int)(unsigned)((int)u0 < (int)u3)));
        break; (void)(((unsigned)e0 | 0u));
    }
    while (i0++ < 6u && (unsigned)((int)a0[i0 & 3u] >= (int)garr[i1 & 7u])) { if (--fuel == 0u) goto done;
        r0.x = ((unsigned)((int)7u < (int)((unsigned)h0 ^ r0.y)) ? u2 : 0x7cb9da6cu);
        g1 += ((garr[i1 & 7u] / (u1 | 1u)) / (0x3138f168u | 1u));
        if (i0) {
            v0 = (unsigned)((int)0u < (int)*mp);
        }
    }
    if ((u1 - p2)) {
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)(signed char)(unsigned)((unsigned)s1 == *mp) << ((v0 ^ (unsigned)(u3 == -(unsigned)((int)u0 >= (int)r0.x))) & 63u);
            if ((p1 * i1)) {
                c1 = (signed char)(garr[i1 & 7u] + a0[u1 & 3u]);
                if (0x10000u) break;
                if (((r0.y | r0.y) | p2)) continue;
                s1 = (int)((unsigned)s1 + (unsigned)((0xffffffffu ^ (unsigned)e0) == 0x5258b40du));
                break; (void)((unsigned)(unsigned char)((unsigned)d0 - i0));
                b0 = ((unsigned)((unsigned)s1 || garr[i1 & 7u]) | ((unsigned)(r0.x < (unsigned)l0) + 0xddd285ceu)) != 0u;
            } else {
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (v0) break;
                    switch (((unsigned)(x0 >> 70) | (unsigned)(v0 < (unsigned)(w0 >> 29))) & 7u) {
                        for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                            u1 ^= (unsigned)((garr[i1 & 7u] ? 1u : (unsigned)((int)g1 >= (int)(unsigned)d0)) == i0);
                            case 2u: ;
                            if ((unsigned)(i1 == *mp)) break;
                        }
                        u2 = u2 * 0x9e3779b1u + i2;
                        e0 = e0 * 0.5L + (long double)(((a0[u1 & 3u] % (0x49bcbad2u | 1u)) ^ (unsigned)(signed char)(unsigned)(0x10000u == (unsigned)(w0 >> 29))) & 1023u);
                        garr[((unsigned)h1 << (fuel & 31u)) & 7u] = 1u;
                        s1 = (int)((unsigned)s1 + (3u >> (*q0 & 31u)));
                        *q0 = v0;
                    }
                    b0 = ((unsigned)b0 >> ((p1 % (u3 | 1u)) & 31u)) != 0u;
                    a0[~(unsigned)((unsigned)w0 < (unsigned)e0) & 3u] = (5u | 0x10000u);
                }
            }
            goto L0;
            if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s0 | (unsigned)((unsigned)h1 || (unsigned)h0)), u3, ~((unsigned)d0 << (0x80000000u & 31u))); }
            u1 = u2;
        }
        switch ((i1 % (v0 | 1u)) & 7u) {
            h0 = (short)(unsigned)!((unsigned)(0xffffffffu || v0) >> (r0.x & 31u));
            w0 ^= (unsigned long long)(unsigned)(x0 >> 70) << (0x7fffffffu & 63u);
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(*mp && (u1 - (unsigned)(x0 >> 70))), (unsigned)s1, (i2 ^ (unsigned)((int)1u >= (int)(unsigned)l0))); }
            while (i0++ < 3u && 5u) { if (--fuel == 0u) goto done;
                *mp = (fuel >> ((unsigned)((unsigned)l0 == p0) & 31u));
                c0 = (unsigned char)v0;
            }
            s1 = (int)((unsigned)s1 + (unsigned)(short)(v0 | 0xcc5db614u));
        }
        if ((p0 - 0x7fffffffu)) {
            s1 = (int)((unsigned)s1 + ((garr[u2 & 7u] - *q0) << (((unsigned)(4u == (unsigned)(w0 >> 29)) & u0) & 31u)));
            x0 = x0 * 0x100000001b3ull + (0x80000000u / ((unsigned)e0 | 1u));
        }
    }
    goto L3;
    a0[g0 & 3u] = 0x8f0cdfdbu;
    goto L1;
    goto L1;
    { unsigned t3; double z3; if ((0x10000u) & 1u) { t3 = (*mp + p1); z3 = (double)((garr[u2 & 7u]) & 255u); } if ((0x10000u) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        if (((unsigned)(8u < *q0) / (garr[i1 & 7u] | 1u))) goto L3;
        v0 = (unsigned)((short)i2 > (signed char)u1);
        *q0 += (p0 ? (unsigned)s0 : ((unsigned)c0 | (unsigned)c1));
        if (u1) goto L2;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    u0 = p2;
    if ((g0 >> (p1 & 31u))) goto done;
    if ((unsigned)c0) {
        L0: if (--fuel == 0u) goto done;
    } else {
        do { if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((9u & 0x7fffffffu)) {
                    w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)((unsigned)c0 * i1);
                    b0 = (unsigned)(0x80a5d73cu || (unsigned)f0) != 0u;
                    c0 = (unsigned char)((0x7fffffffu % (0xebe97b19u | 1u)) | (unsigned)((int)(unsigned)c1 >= (int)9u));
                    *mp = (u2 ? garr[u2 & 7u] : (unsigned)(5u || (0x80000000u + 0xffffffffu)));
                    goto L2;
                    i0 = (unsigned)(u1 || u2) & 15u;
                } else {
                    if (budget != 0u) { budget -= 1u; u1 = fn1((u0 / ((0xffffffffu * 0x80000000u) | 1u)), (i1 + (unsigned)l0), ((unsigned)x0 & p0)); }
                    u1 = u1 * 0x9e3779b1u + ((((unsigned)h0 >> (fuel & 31u)) & (unsigned)c1) / ((unsigned)d0 | 1u));
                }
                q0 = &garr[(0x80000000u * u3) & 7u];
                L2: if (--fuel == 0u) goto done;
                if (((unsigned)h1 * (unsigned)((unsigned)c1 || (unsigned)s1))) {
                    { unsigned t0; double z0; if (((u1 * (unsigned)((unsigned)h1 < 0xffffffffu))) & 1u) { t0 = (0xc9258d6cu / ((unsigned)s1 | 1u)); z0 = (double)(((unsigned)((int)0x862ee4eau < (int)*q0)) & 255u); } if (((u1 * (unsigned)((unsigned)h1 < 0xffffffffu))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                        *mp = (unsigned)((int)0x10000u >= (int)(u3 | 0x11cfd2adu));
                    }
                    r0.y ^= (~(unsigned)((short)0x10000u > (signed char)2u) >> (((unsigned)h0 * (unsigned)s1) & 31u));
                    if ((unsigned)(w0 >> 29)) continue;
                    if ((unsigned)(0x7f9078e7u == (unsigned)(short)(*mp % (*mp | 1u)))) break;
                    garr[-(unsigned)((unsigned)x0 < (unsigned)(x0 >> 70)) & 7u] = ((unsigned)(*mp || p0) / ((unsigned)h1 | 1u));
                }
            } while (i1++ < 7u && p1);
        } while (i0++ < 5u && ((unsigned)s1 - ((unsigned)s0 & 0u)));
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)fuel < (int)(i0 << (*q0 & 31u))), u1, ((unsigned)(fuel || r0.y) | 0xffffffffu)); }
    }
    switch ((0xffffffffu ^ (u1 & p1)) & 7u) {
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)!(p1 ? (unsigned)s1 : u1) || (unsigned)(x0 >> 70)) & 255u);
        if ((unsigned)!(unsigned)((int)garr[i1 & 7u] < (int)u3)) goto L1;
        for (;;) { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)((int)7u >= (int)((unsigned)(i2 || (unsigned)d0) >> ((unsigned)((unsigned)e0 < *mp) & 31u)));
            if (((unsigned)c0 * (unsigned)(w0 >> 29))) {
                if (budget != 0u) { budget -= 1u; u2 = fn2((5u * 0xcb72e73fu), (u2 & (unsigned)((int)4u >= (int)(unsigned)(x0 >> 70))), (unsigned)((int)(unsigned)x0 < (int)0xffffffffu)); }
                { unsigned t1; double z1; if ((((5u / (a0[i0 & 3u] | 1u)) | fuel)) & 1u) { t1 = 0x24b04b6fu; z1 = (double)((0xfd208ed8u) & 255u); } if ((((5u / (a0[i0 & 3u] | 1u)) | fuel)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    { unsigned t2; double z2; if (((unsigned)(signed char)(unsigned)((unsigned)(1u < g1) && 3u)) & 1u) { t2 = (unsigned)((unsigned)((int)(unsigned)b0 < (int)(unsigned)(x0 >> 70)) && garr[i1 & 7u]); z2 = (double)((r0.y) & 255u); } if (((unsigned)(signed char)(unsigned)((unsigned)(1u < g1) && 3u)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                        *q0 = (unsigned)((short)u2 > (signed char)(unsigned)!((unsigned)b0 & *q0));
                    }
                    *q0 = (2u & (unsigned)((int)(g0 * 0x80000000u) >= (int)(unsigned)((unsigned)(w0 >> 29) && garr[i1 & 7u])));
                    L3: if (--fuel == 0u) goto done;
                    L4: if (--fuel == 0u) goto done;
                }
                g1 += 0xffffffffu;
                break; (void)((7u / (*q0 | 1u)));
                if ((i1 & *q0)) continue;
            } else {
                if ((0xa41c0c52u >> (garr[i1 & 7u] & 31u))) goto L3;
            }
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    case 4u: ;
                    a0[(u2 << ((unsigned)b0 & 31u)) & 3u] = p2;
                    if ((unsigned)d0) break;
                    u1 += ((unsigned)(signed char)(i2 + 0x38e31966u) & 1u);
                    d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)(*mp && ((unsigned)(w0 >> 29) - (unsigned)x0)) < (int)0xe7a47ccbu) & 1023u);
                } while (i2++ < 3u && 0x85277b51u);
                r0.y ^= (unsigned)(fuel || (u2 * 3u));
                if (a0[i0 & 3u]) continue;
                i2 = (unsigned)(short)(unsigned)(r0.y && 0x81e76aaeu) & 15u;
                d0 = d0 * 0.5 + (double)(((unsigned)((short)(unsigned)s1 > (signed char)2u) & ~(unsigned)(4u < (a0[i0 & 3u] | a0[i0 & 3u]))) & 1023u);
                i2 = (((unsigned)(x0 >> 70) + (unsigned)b0) * (unsigned)((unsigned)s1 || 4u)) & 15u;
            }
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1(0x7fffffffu, 5u, (unsigned)(i2 == (unsigned)!(unsigned)(0x62e782bdu && *mp))); }
                h0 = (short)(unsigned)s0;
                v0 = ((unsigned)((int)(*mp ^ 0xffffffffu) >= (int)g1) ^ (unsigned)(v0 == (unsigned)c1));
                i0 = ~(*q0 - g0) & 15u;
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(unsigned)c1;
                    x0 = x0 * 0x100000001b3ull + 0x10000u;
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)!(0xa091a6d1u - (*mp * 0x83e83e89u)), ((unsigned)(w0 >> 29) * (2u >> (0x7fffffffu & 31u))), ((unsigned)(0u || r0.y) << (i1 & 31u))); }
                    case 0u: ;
                    q0 = &garr[(7u % ((r0.y % ((unsigned)((unsigned)c1 || 0x7fffffffu) | 1u)) | 1u)) & 7u];
                    if (budget != 0u) { budget -= 1u; u1 = fn1((0x80000000u ? 2u : (unsigned)w0), ((unsigned)h1 ? fuel : *q0), (unsigned)(unsigned char)((unsigned)(0xffffffffu && u2) / ((unsigned)b0 | 1u))); }
                }
            } while (i1++ < 2u && (unsigned)((int)0xffffffffu >= (int)(unsigned)f0));
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)s0 - (unsigned)(unsigned char)(0x51f6bdaeu * garr[i1 & 7u]))) goto L3;
            if (r0.x) goto L2;
            e0 = e0 * 0.5L + (long double)((unsigned)((int)(0xa7cc375bu ^ r0.y) >= (int)(unsigned)(short)(unsigned)((int)fuel < (int)i1)) & 1023u);
            switch ((unsigned)((int)(*mp >> (a0[i0 & 3u] & 31u)) >= (int)a0[i0 & 3u]) & 7u) {
                u1 = (unsigned)!(6u | ((unsigned)(x0 >> 70) - 0x34f5335au));
            }
        }
    }
    goto L2;
    if (((unsigned)w0 & (*q0 ^ 0xb88ee7cdu))) goto L3;
    if (p0) goto L3;
    w0 = w0 * 6364136223846793005ull + (((unsigned)s0 + (unsigned)w0) ^ (((unsigned)e0 & (unsigned)s1) ^ 0x771068e8u));
    goto L4;
    if (u3) {
        if (6u) {
            c0 = (unsigned char)i0;
            if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)(0x5f51a52au == i1) << (0xc9d79a73u & 31u)), (unsigned)d0, (r0.x | u2)); }
        } else {
            *q0 = (unsigned)(0x80000000u < (unsigned)((int)(unsigned)d0 < (int)(unsigned)x0));
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(unsigned char)(unsigned)((unsigned)(fuel || (unsigned)x0) && 0xc2cf42d7u), (unsigned)((int)a0[i0 & 3u] >= (int)i2), p1); }
        }
        r0.x = (~(unsigned)((int)r0.x >= (int)(fuel % (0u | 1u))) << (garr[i1 & 7u] & 31u));
        { unsigned t3; double z3; if (((p1 - m0)) & 1u) { t3 = ((0x78c894d4u + 0xf3fe2006u) - i2); z3 = (double)(((9u / ((unsigned)(x0 >> 70) | 1u))) & 255u); } if (((p1 - m0)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            if (u2) goto L0;
            *mp = 0x6cf751a1u;
            while (i0++ < 2u && (unsigned)((garr[u2 & 7u] % ((unsigned)h1 | 1u)) < 0x25aa2172u)) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return u2;
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)((unsigned)x0 | (5u / ((unsigned)h0 | 1u))) < (int)(7u >> (0xd09aac2eu & 31u)));
                a0[(0x806c827cu + (unsigned)h1) & 3u] = ((unsigned)((short)0xb6259acbu > (signed char)(unsigned)(w0 >> 29)) * (unsigned)((unsigned)((unsigned)f0 < garr[u2 & 7u]) < (unsigned)e0));
                if (budget != 0u) { budget -= 1u; u1 = fn0(((garr[i1 & 7u] ^ u3) + i2), (0xeaaeefe3u / (0x6b1bf51du | 1u)), 3u); }
            }
            goto L1;
        }
        { unsigned t4; double z4; if ((r0.x) & 1u) { t4 = (unsigned)(0xbe100248u < 0xffffffffu); z4 = (double)((0x503fccbeu) & 255u); } if ((r0.x) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            switch ((unsigned)((6u * 6u) && (unsigned)(x0 >> 70)) & 7u) {
                if (p2) goto L3;
                if (budget != 0u) { budget -= 1u; u1 = fn1((i1 ^ (unsigned)l0), (unsigned)((short)(unsigned)((short)(unsigned)c1 > (signed char)a0[i0 & 3u]) > (signed char)g0), a0[i0 & 3u]); }
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(0u + 0x80000000u) > (signed char)0x10000u), ((unsigned)s0 % (0xe2ae7d53u | 1u)), (unsigned)((unsigned)(w0 >> 29) < (unsigned)(w0 >> 29))); }
                while (i0++ < 7u && u2) { if (--fuel == 0u) goto done;
                    case 5u: ;
                    while (i1++ < 5u && (unsigned)(0xf1ea67aau == (unsigned)x0)) { if (--fuel == 0u) goto done;
                        default: ;
                        *q0 = (unsigned)((unsigned)(unsigned char)(unsigned)(0xffffffffu < 0x10000u) || 0x2d8c502u);
                        case 1u: ;
                        h1 = (unsigned short)(h1 + 0x10000u);
                        if (u3 == 7u) return ((unsigned)(unsigned char)(unsigned)((int)0x204e57fcu < (int)0x10000u) & g0);
                    }
                    goto L0;
                    do { if (--fuel == 0u) goto done;
                        u1 = u1 * 0x9e3779b1u + (((unsigned)w0 ^ ((unsigned)h1 + 4u)) >> ((0xffffffffu + a0[u1 & 3u]) & 31u));
                    } while (i1++ < 5u && (unsigned)((int)u0 < (int)0x10000u));
                }
                if (u2) goto done;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn1((*q0 % (a0[u1 & 3u] | 1u)), 0xffffffffu, (p2 | (unsigned)((unsigned)d0 < (unsigned)x0))); }
        }
        if ((unsigned)((int)garr[u2 & 7u] < (int)i2)) {
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)0x10000u > (signed char)0x7fffffffu), ~(unsigned)((short)0xffffffffu > (signed char)(*q0 << (3u & 31u))), ((0x7fffffffu << ((unsigned)s1 & 31u)) | 5u)); }
            s0 = (int)(unsigned)!(unsigned)((int)(unsigned)w0 < (int)9u);
            q0 = &garr[((unsigned)(0x351c7c8eu < i2) / (7u | 1u)) & 7u];
            q0 = &garr[((a0[i0 & 3u] >> ((unsigned)((int)(unsigned)x0 >= (int)(unsigned)c0) & 31u)) + r0.x) & 7u];
        } else {
            while (i0++ < 4u && ((u1 + (unsigned)l0) % ((unsigned)c0 | 1u))) { if (--fuel == 0u) goto done;
                b0 = (g1 & p2) != 0u;
            }
            if ((unsigned)f0) goto L1;
            if ((unsigned)(x0 >> 70)) goto done;
        }
    } else {
        if (((unsigned)d0 >> ((unsigned)x0 & 31u))) {
            if (*mp) goto done;
            if ((u0 % (5u | 1u))) goto done;
        } else {
            if (u2) goto L2;
        }
        if (((unsigned)c1 >> ((a0[i0 & 3u] >> (g1 & 31u)) & 31u))) goto L0;
    }
    if (a0[u1 & 3u]) goto L0;
    if (fuel < 8u) return ((a0[i0 & 3u] / (0x88b4fabeu | 1u)) ^ (0xffffffffu % (i1 | 1u)));
    s0 = (int)((unsigned)c0 | u2);
    if ((unsigned)!((0x7edb3865u * (unsigned)c0) - *mp)) goto L1;
    r0.y ^= (unsigned)(w0 >> 29);
    while (i0++ < 5u && 2u) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((((unsigned)((int)(unsigned)h0 < (int)(unsigned)b0) ^ *mp) >> ((i0 & 8u) & 31u)) & 1023u);
        do { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    q0 = &garr[(unsigned)((short)((unsigned)c0 - r0.x) > (signed char)0xfb711f66u) & 7u];
                    f0 = f0 * 0.5f + (float)((1u * garr[u2 & 7u]) & 255u);
                    v0 = (unsigned)(w0 >> 29);
                    u1 += (unsigned)((unsigned)((unsigned)((unsigned)s1 || p1) == 4u) && 0xcb826190u);
                } while (i0++ < 4u && (unsigned)b0);
                u3 ^= (unsigned)((short)(unsigned)((int)0x7fffffffu >= (int)u2) > (signed char)(unsigned)(i2 || ((unsigned)c0 - a0[u1 & 3u])));
                if ((unsigned)(x0 >> 70)) continue;
                if (u3 == 7u) return (unsigned)((int)(p2 % ((unsigned)(w0 >> 29) | 1u)) >= (int)(0xfb7b1b98u << ((unsigned)e0 & 31u)));
            }
            if (budget != 0u) { budget -= 1u; u0 = fn2(p1, (i1 & i0), (unsigned)!(unsigned)((unsigned)c1 || r0.x)); }
            continue; (void)((unsigned)(unsigned char)(u3 ? (unsigned)d0 : (unsigned)l0));
        } while (i1++ < 7u && (unsigned)(signed char)(7u % (-(m0 - p2) | 1u)));
        goto L3;
        q0 = &garr[(4u ^ r0.x) & 7u];
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1(7u, (unsigned)(unsigned char)(unsigned)((int)p2 < (int)0xffed75f4u), (unsigned)((short)(i0 - (unsigned)x0) > (signed char)0x80000000u)); }
        while (i1++ < 6u && *q0) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)2u;
            { unsigned t5; double z5; if ((0x1e9f8a99u) & 1u) { t5 = (unsigned)(unsigned char)(unsigned)((0x10000u * v0) || p0); z5 = (double)(((unsigned)(short)(-(unsigned)((short)a0[i0 & 3u] > (signed char)fuel) >> (0x1800c2b7u & 31u))) & 255u); } if ((0x1e9f8a99u) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(6u == 9u), i1, ((unsigned)s0 + garr[i1 & 7u])); }
                while (i2++ < 5u && (u1 / (u1 | 1u))) { if (--fuel == 0u) goto done;
                    break; (void)((g1 + i1));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(signed char)(unsigned)((short)v0 > (signed char)g0), (unsigned)((unsigned)((int)r0.x < (int)(unsigned)c0) || 2u), ((unsigned)h0 | (unsigned)b0)); }
                    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        u0 = u0 * 0x9e3779b1u + (unsigned)h0;
                        v0 = (unsigned)(fuel < (unsigned)(short)((unsigned)((unsigned)x0 == 6u) << ((u3 * r0.y) & 31u)));
                        continue; (void)((unsigned)((short)m0 > (signed char)((unsigned)h0 % ((unsigned)c0 | 1u))));
                    }
                    f0 = f0 * 0.5f + (float)(((0u | (unsigned)((int)(unsigned)((unsigned)(w0 >> 29) < 9u) < (int)0x27a239bu)) - p0) & 255u);
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(m0 && 0xe88b35d6u), ((unsigned)c1 / (g1 | 1u)), 5u); }
                }
                r0.y ^= (unsigned)((short)6u > (signed char)(m0 ? *mp : 0xcf6a2f7au));
            }
            if ((4u | (unsigned)x0)) break;
            *mp = ((unsigned)x0 % ((r0.y / (0x7fffffffu | 1u)) | 1u));
        }
        garr[(unsigned)w0 & 7u] = (unsigned)x0;
        h1 = (unsigned short)(h1 + ((unsigned)c1 / ((a0[i0 & 3u] ^ g0) | 1u)));
        break; (void)((fuel & (unsigned)s1));
        if (-(unsigned)((short)0xea5ddc8bu > (signed char)(p0 ^ garr[i1 & 7u]))) break;
    } while (i0++ < 6u && 0xffffffffu);
    e0 = e0 * 0.5L + (long double)((u0 / (u2 | 1u)) & 1023u);
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)0x80000000u >= (int)(unsigned)(0x7fffffffu || (unsigned)e0)), (u0 ? i2 : 0xb4f0bbbdu), (unsigned)((short)(unsigned)w0 > (signed char)m0)); }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        s0 = (int)(unsigned)((int)(unsigned)f0 < (int)(unsigned)((unsigned)c1 && (r0.y + (unsigned)b0)));
    }
    { unsigned t6; double z6; if (((i0 ^ i2)) & 1u) { t6 = ((unsigned)f0 % ((unsigned)w0 | 1u)); z6 = (double)(((unsigned)((fuel | u1) == (unsigned)x0)) & 255u); } if (((i0 ^ i2)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
        while (i0++ < 5u && (unsigned)((int)fuel >= (int)(unsigned)l0)) { if (--fuel == 0u) goto done;
            if (0u) break;
            r0.x = (((g1 ? p1 : 0x1161f0d5u) >> (fuel & 31u)) / (0xf156eb59u | 1u));
            u3 += (unsigned)((int)i1 < (int)garr[u2 & 7u]);
        }
        if ((unsigned)((int)(unsigned)!(unsigned)((int)(unsigned)w0 < (int)0x9ce848bu) >= (int)v0)) goto L1;
    }
    q0 = &garr[8u & 7u];
    { unsigned t7; double z7; if ((9u) & 1u) { t7 = 0xcfcec504u; z7 = (double)(((unsigned)((short)v0 > (signed char)*q0)) & 255u); } if ((9u) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
        if (2u) goto L0;
        while (i0++ < 3u && p0) { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)(0x186b0483u == (r0.x - (unsigned)c0));
            while (i1++ < 7u && (0xffffffffu + (unsigned)s1)) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)((u3 << (i2 & 31u)) == (unsigned)(((unsigned)x0 - m0) == 0x25febf7au)) & 1023u);
            }
            if ((unsigned)(short)(unsigned)((unsigned)e0 && 0xffffffffu)) break;
            switch (i2 & 7u) {
                case 2u: ;
                case 0u: ;
                if ((garr[i1 & 7u] >> (u0 & 31u))) goto L0;
                r0.y ^= ((unsigned)f0 + (unsigned)h0);
                switch ((0x78735f9bu - m0) & 7u) {
                    b0 = ~((unsigned)d0 * (g0 - (unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)(g0 || m0)))) != 0u;
                    garr[(unsigned)(fuel && (unsigned)d0) & 7u] = (unsigned)((unsigned)((int)u0 < (int)(unsigned)(unsigned char)(0x80000000u << ((unsigned)l0 & 31u))) == (0xffffffffu << (a0[i0 & 3u] & 31u)));
                    switch (i0 & 7u) {
                        c1 = (signed char)(u0 * (unsigned)((int)(fuel & (unsigned)h0) >= (int)i0));
                        c1 = (signed char)(unsigned)((short)(unsigned)f0 > (signed char)(unsigned)((unsigned)s0 == u0));
                        u0 += ((unsigned)(unsigned char)(unsigned)(~((unsigned)s1 ^ u3) && 3u) * (unsigned)(short)((unsigned)w0 << (0x80000000u & 31u)));
                        if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)((unsigned)h0 && i1) | p1), (unsigned)(i2 < (*mp + (unsigned)l0)), (garr[i1 & 7u] ^ (fuel >> ((unsigned)f0 & 31u)))); }
                    }
                    case 7u: ;
                    e0 = e0 * 0.5L + (long double)(((unsigned)e0 ? (r0.x % (0x8b811b69u | 1u)) : 0x10000u) & 1023u);
                }
            }
            break; (void)((unsigned)((short)(unsigned)f0 > (signed char)0x36a14023u));
        }
        if ((unsigned)((unsigned)b0 && r0.y)) {
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + ((unsigned)((short)r0.x > (signed char)0x9770f4c8u) + 3u));
                if ((unsigned)c0) break;
                e0 = e0 * 0.5L + (long double)((1u ^ r0.y) & 1023u);
                f0 = f0 * 0.5f + (float)((unsigned)(signed char)(unsigned)((unsigned)((int)*mp >= (int)(unsigned)(w0 >> 29)) == (unsigned)(u1 && g1)) & 255u);
                if ((unsigned)(v0 || (*q0 | 7u))) {
                    if ((((unsigned)(x0 >> 70) | u1) << (m0 & 31u))) {
                        m0 ^= (unsigned)((int)(unsigned)!(unsigned)(p2 || u1) >= (int)*q0);
                    } else {
                        if ((7u >> (g1 & 31u))) break;
                        if (a0[u1 & 3u]) break;
                        if ((unsigned)((short)*mp > (signed char)*q0)) break;
                        w0 ^= (unsigned long long)(unsigned)(0xd77f638au || v0) << (8u & 63u);
                    }
                    if ((unsigned)((short)a0[u1 & 3u] > (signed char)9u)) break;
                    i0 = (0xe41ec38bu >> ((unsigned)!(unsigned)((short)0xff38be14u > (signed char)(unsigned)h0) & 31u)) & 15u;
                    if ((unsigned)(short)((unsigned)b0 + (unsigned)(0xbd4bc8c6u == (unsigned)x0))) goto L3;
                } else {
                    if (budget != 0u) { budget -= 1u; u1 = fn2((2u | (unsigned)b0), u1, (*mp | (unsigned)((unsigned)c1 == garr[u2 & 7u]))); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)((unsigned)s0 == 0x7fffffffu)), (unsigned)w0, i0); }
                    for (;;) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)((unsigned)w0 >> ((unsigned)f0 & 31u)), (0x1226c86du << ((unsigned)!(0x31e888bbu % (u0 | 1u)) & 31u)), ((unsigned)((int)2u < (int)i0) * 9u)); }
                        if (0x12f05c1cu) break;
                        h0 = (short)(unsigned)((unsigned)((int)0x52c28185u >= (int)(unsigned)b0) < ~(i1 << (a0[i0 & 3u] & 31u)));
                    }
                    b0 = ((unsigned)((unsigned)(unsigned char)(unsigned)((int)r0.x < (int)u1) && 7u) >> ((unsigned)w0 & 31u)) != 0u;
                }
                break; (void)((unsigned)!((unsigned)((int)(unsigned)e0 >= (int)(unsigned)c0) - 1u));
            }
            m0 ^= u3;
            if ((unsigned)(unsigned char)((unsigned)f0 % (0x3577dfb7u | 1u))) goto L1;
        }
    }
    switch ((unsigned)(g1 == 0x80000000u) & 7u) {
        if ((3u & (unsigned)h0)) {
            while ((p2 - (unsigned)c1)) { if (--fuel == 0u) goto done;
                case 3u: ;
                case 5u: ;
                if (budget != 0u) { budget -= 1u; u1 = fn2(0x397014a1u, (garr[u2 & 7u] ^ (unsigned)(x0 >> 70)), u0); }
                b0 = (unsigned)(unsigned char)(u2 * garr[i1 & 7u]) != 0u;
                switch ((unsigned)(u0 < (unsigned)s1) & 7u) {
                    case 2u: ;
                }
                if ((1u ^ (p2 ^ 0xa0c7cbd8u))) goto L3;
            }
            *q0 = (unsigned)((unsigned)l0 || (0x7fffffffu << (v0 & 31u)));
            s0 = (int)(*mp - (unsigned)((7u + (unsigned)(garr[u2 & 7u] && (unsigned)h1)) && p0));
            c1 = (signed char)(unsigned)((int)(r0.y / (~(unsigned)((int)3u >= (int)v0) | 1u)) < (int)(unsigned)w0);
            if ((0xaf201a55u * (unsigned)(a0[u1 & 3u] == (unsigned)e0))) goto done;
        } else {
            e0 = e0 * 0.5L + (long double)((8u ? (unsigned)e0 : (unsigned)s1) & 1023u);
        }
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)(9u && (unsigned)(0x7a21bf95u == 0xa9eb2cfu)));
            i2 = ((unsigned)((unsigned)(w0 >> 29) || 0x10000u) % ((unsigned)x0 | 1u)) & 15u;
            *q0 += (unsigned)(w0 >> 29);
        }
        switch (0u & 7u) {
            goto L3;
        }
        goto L4;
        case 6u: ;
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (u3 == 7u) return (unsigned)(0x27e48700u || (unsigned)((int)(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(6u || (unsigned)x0)) < (int)a0[u1 & 3u]));
            break; (void)((a0[u1 & 3u] << ((unsigned)((int)0x7e4e1c30u >= (int)4u) & 31u)));
            if ((garr[i1 & 7u] * (unsigned)(x0 >> 70))) {
                x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)f0 + 0xffffffffu) && (unsigned)((unsigned)((short)u2 > (signed char)(unsigned)x0) == 0x10000u));
                if ((u2 * 0x80000000u)) break;
            }
            r0.x = (unsigned)((int)0xae45c2aau < (int)((unsigned)d0 & (unsigned)d0));
            s0 = (int)(unsigned)((int)(0x7fffffffu | u3) < (int)(unsigned)((int)(unsigned)c1 < (int)*mp));
        }
        g1 += m0;
        { unsigned t8; double z8; if ((i1) & 1u) { t8 = (m0 % ((unsigned)((unsigned)s1 && 2u) | 1u)); z8 = (double)((a0[u1 & 3u]) & 255u); } if ((i1) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
            e0 = e0 * 0.5L + (long double)((g1 + (unsigned)((v0 >> ((unsigned)c1 & 31u)) || g1)) & 1023u);
        }
        if ((0xbc838b62u ^ ((unsigned)s0 / (p0 | 1u)))) {
            break; (void)((unsigned)(0x2c3d882au && 0xffffffffu));
            if ((unsigned)((int)(unsigned)!(5u % (a0[i0 & 3u] | 1u)) >= (int)9u)) break;
            w0 = w0 * 6364136223846793005ull + 9u;
        } else {
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)0x5b8ff887u < (int)u0), (g0 % ((unsigned)c1 | 1u)), (unsigned)l0); }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(r0.x < (0u * g0)), (0x190a16feu << (g1 & 31u)), i2); }
            { unsigned t9; double z9; if ((~(unsigned)((short)(i2 - (unsigned)w0) > (signed char)(unsigned)l0)) & 1u) { t9 = (garr[i1 & 7u] - (unsigned)s1); z9 = (double)((7u) & 255u); } if ((~(unsigned)((short)(i2 - (unsigned)w0) > (signed char)(unsigned)l0)) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                *q0 += (unsigned)c1;
                if (budget != 0u) { budget -= 1u; u0 = fn1(garr[i1 & 7u], (unsigned)((unsigned)s0 < v0), (unsigned)(signed char)(unsigned)((unsigned)((short)(unsigned)c0 > (signed char)u3) && 0x7fffffffu)); }
                b0 = (0x3f37445u ? (unsigned)f0 : 0x6287656cu) != 0u;
                *q0 += ((unsigned)h0 / ((fuel ? 0x80000000u : v0) | 1u));
                if (u1) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)8u >= (int)(unsigned)((int)*mp < (int)r0.x)), (unsigned)!((unsigned)s0 ^ u3), ((unsigned)c0 >> (((unsigned)e0 / (0u | 1u)) & 31u))); }
                    break; (void)((unsigned)(unsigned char)(unsigned)((int)(7u - *mp) >= (int)4u));
                }
                while (i1++ < 2u && (unsigned)((int)4u < (int)0x80000000u)) { if (--fuel == 0u) goto done;
                    break; (void)((2u << (0xe4b4d163u & 31u)));
                }
            }
        }
        *q0 = 0x1b5fde9eu;
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1((6u >> ((unsigned)(x0 >> 70) & 31u)), 9u, i0); }
        { unsigned t10; double z10; if (((unsigned)((short)(unsigned)(0x7fffffffu && (unsigned)h1) > (signed char)*q0)) & 1u) { t10 = (unsigned)c1; z10 = (double)((((unsigned)d0 - 0xb38cef5fu)) & 255u); } if (((unsigned)((short)(unsigned)(0x7fffffffu && (unsigned)h1) > (signed char)*q0)) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
            a0[(garr[i1 & 7u] * garr[u2 & 7u]) & 3u] = (unsigned)((p1 - *q0) == 0x52eef72u);
            { unsigned t11; double z11; if ((((unsigned)w0 >> (u1 & 31u))) & 1u) { t11 = (unsigned)((int)r0.y < (int)*q0); z11 = (double)((u1) & 255u); } if ((((unsigned)w0 >> (u1 & 31u))) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
                *mp = (unsigned)((short)(unsigned)((int)garr[u2 & 7u] < (int)a0[u1 & 3u]) > (signed char)(unsigned)b0);
            }
        }
        if ((1u / ((0xeb65b6f2u & p1) | 1u))) {
            *q0 += ((p0 << (1u & 31u)) + 0x80000000u);
            u0 ^= (unsigned)((unsigned)(x0 >> 70) || (unsigned)!(unsigned)((int)((unsigned)w0 * (unsigned)s1) >= (int)garr[u2 & 7u]));
        }
    } while (i0++ < 4u && ((0xa41bfc39u >> (0x10000u & 31u)) % (u0 | 1u)));
    i2 = ((unsigned)((short)r0.y > (signed char)(*mp * 1u)) | 0x10000u) & 15u;
    r0.y ^= (unsigned)b0;
    b0 = 0x8413ceafu != 0u;
    goto L0;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((9u / ((unsigned)(signed char)(unsigned)(((unsigned)(u3 || 3u) | garr[i1 & 7u]) < m0) | 1u)) & 1023u);
        f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(unsigned)((u0 ^ (unsigned)((unsigned)h0 && (unsigned)s0)) || (unsigned)(unsigned char)(unsigned)(u2 < p0)) & 255u);
        r0.x = (((unsigned)(w0 >> 29) + (unsigned)(p2 < garr[i1 & 7u])) % (r0.y | 1u));
    }
    u3 += ((unsigned)(x0 >> 70) & (unsigned)(unsigned char)(unsigned)(u1 || r0.y));
    s0 = (int)(unsigned)((int)(3u / (u0 | 1u)) >= (int)(u3 * r0.x));
    if ((unsigned)((int)-(garr[i1 & 7u] * (unsigned)c0) < (int)u3)) goto L2;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t12; double z12; if ((0x10000u) & 1u) { t12 = ((unsigned)(w0 >> 29) / (7u | 1u)); z12 = (double)((((unsigned)(p0 || 0u) / (p0 | 1u))) & 255u); } if ((0x10000u) & 1u) { u1 += t12; d0 = d0 * 0.5 + z12; }
            continue; (void)((garr[u2 & 7u] % (8u | 1u)));
            if (budget != 0u) { budget -= 1u; u0 = fn2(7u, (unsigned)e0, r0.x); }
            *q0 = a0[i0 & 3u];
        }
        continue; (void)((unsigned)(2u && r0.y));
        u2 = u2 * 0x9e3779b1u + a0[i0 & 3u];
    }
    *q0 += p0;
    h1 = (unsigned short)(h1 + (unsigned)((short)v0 > (signed char)~((g0 >> (garr[u2 & 7u] & 31u)) % ((unsigned)((unsigned)x0 && 0x7ca01501u) | 1u))));
    if (((unsigned)b0 * a0[u1 & 3u])) goto L3;
    u2 = (unsigned)((unsigned)(8u || 0xdded490fu) && (unsigned)((unsigned)(x0 >> 70) == u0));
    w0 = w0 * 6364136223846793005ull + ((unsigned)(x0 >> 70) - ((r0.y * (unsigned)s1) * -(i2 - g0)));
    c1 = (signed char)((unsigned)(w0 >> 29) | v0);
    g0 = (u1 << ((((unsigned)(w0 >> 29) - u0) | (unsigned)e0) & 31u));
    *q0 += (unsigned)((short)(unsigned)((int)(1u | 0xffffffffu) >= (int)0xad4bf98eu) > (signed char)0x9aa04a2au);
    m0 ^= i1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    l0 = (long)((unsigned long)l0 + ((unsigned)s1 | (unsigned)c0));
    if ((unsigned)((unsigned)e0 < 9u)) goto L0;
    c0 = (unsigned char)~(unsigned)((a0[u1 & 3u] >> ((unsigned)e0 & 31u)) == (unsigned)((int)r0.y >= (int)(unsigned)(*q0 || 0x10000u)));
    { unsigned t0; double z0; if ((((unsigned)l0 + (unsigned)(unsigned char)(unsigned)((unsigned)x0 && m0))) & 1u) { t0 = (unsigned)(0x6f1708d9u == 0xfba80669u); z0 = (double)((-((unsigned)(x0 >> 70) + 0xafc56223u)) & 255u); } if ((((unsigned)l0 + (unsigned)(unsigned char)(unsigned)((unsigned)x0 && m0))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        c0 = (unsigned char)i1;
    }
    switch ((unsigned)((int)0x2a437982u < (int)(unsigned)l0) & 7u) {
        if ((unsigned)c1) goto L4;
        if ((unsigned)f0) {
            switch ((unsigned)((short)u1 > (signed char)(unsigned)(w0 >> 29)) & 7u) {
                f0 = f0 * 0.5f + (float)(garr[i1 & 7u] & 255u);
                c0 = (unsigned char)(unsigned)((short)(fuel / (0x4078624au | 1u)) > (signed char)(unsigned)((int)(unsigned)b0 < (int)(r0.y | (unsigned)b0)));
                L0: if (--fuel == 0u) goto done;
                *q0 = a0[u1 & 3u];
                case 7u: ;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(unsigned char)(fuel | (0x7fffffffu - v0)), 0x26a9fcc6u, (fuel - ((unsigned)c1 + p1))); }
            while (i0++ < 7u && (0xbf7cd763u & (unsigned)l0)) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(g0 ? 0x80000000u : (unsigned)((short)(unsigned)b0 > (signed char)(r0.x ^ 0xcf2c1cd0u)));
            }
            v0 = (((unsigned)(unsigned char)(i1 - (unsigned)(6u || (unsigned)w0)) >> (u3 & 31u)) % ((unsigned)l0 | 1u));
            m0 ^= ((unsigned)s1 + ((unsigned)(a0[u1 & 3u] && g0) % (i2 | 1u)));
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(g0, g1, *mp); }
        if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)w0, 4u, 0xffffffffu); }
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            *mp = ((unsigned)e0 - (unsigned)((int)(unsigned)s1 >= (int)0x10000u));
            if (0xffffffffu) {
                if (budget != 0u) { budget -= 1u; u0 = fn3(-(a0[i0 & 3u] % (0xf757e66du | 1u)), (unsigned)(0xc0154121u < (unsigned)f0), (unsigned)((short)(0x10000u * *mp) > (signed char)i2)); }
            } else {
                g1 += (unsigned)(0x40e63b62u || r0.x);
                if ((garr[u2 & 7u] << (((unsigned)h0 % (0xf2485fe8u | 1u)) & 31u))) {
                    while (i2++ < 3u && (unsigned)(0x8878de8du || (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                        u1 = u1 * 0x9e3779b1u + (unsigned)e0;
                        goto L0;
                        for (;;) { if (--fuel == 0u) goto done;
                            l0 = (long)((unsigned long)l0 + ((unsigned)((short)(unsigned)d0 > (signed char)6u) >> (i2 & 31u)));
                            v0 = ((0xe5b97701u / (garr[i1 & 7u] | 1u)) * u3);
                        }
                        if (budget != 0u) { budget -= 1u; u3 = fn3(~(i0 ^ p2), (unsigned)!(unsigned)((unsigned)w0 == (unsigned)(u3 == (unsigned)w0)), (7u - 7u)); }
                        h0 = (short)0x7fffffffu;
                    }
                    r0.y ^= (unsigned)!((unsigned)((short)(unsigned)(u0 && (unsigned)c1) > (signed char)fuel) ^ (unsigned)c1);
                    L1: if (--fuel == 0u) goto done;
                    if ((unsigned)(8u && (unsigned)((short)0x436ed36du > (signed char)(unsigned)(w0 >> 29)))) {
                        r0.x = ((unsigned)((int)(unsigned)e0 < (int)(r0.y % (p0 | 1u))) % ((unsigned)f0 | 1u));
                        if ((fuel / ((unsigned)(short)((unsigned)w0 | 0x33645d84u) | 1u))) break;
                        g0 = ((unsigned)l0 % (r0.x | 1u));
                    }
                    if (v0) break;
                } else {
                    L2: if (--fuel == 0u) goto done;
                }
                do { if (--fuel == 0u) goto done;
                    q0 = &garr[(0x7fffffffu * 0x7fffffffu) & 7u];
                    if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)(w0 >> 29) % ((unsigned)s0 | 1u)), (u0 >> (p1 & 31u)), (unsigned)(short)(unsigned)((int)(unsigned)e0 >= (int)2u)); }
                } while (i2++ < 5u && (unsigned)(short)(unsigned)((int)0xffffffffu >= (int)m0));
                u3 ^= (unsigned)(i0 || ((unsigned)d0 >> ((unsigned)(x0 >> 70) & 31u)));
            }
            w0 = w0 * 6364136223846793005ull + (u1 % ((unsigned)((int)8u < (int)(*q0 + 0xdbf4f9aeu)) | 1u));
        } while (i1++ < 7u && ((unsigned)(*mp == m0) >> ((unsigned)s0 & 31u)));
        c1 = (signed char)(unsigned)!(0x75b09b0u % (((i2 * m0) & 0xa15d39a3u) | 1u));
        { unsigned t1; double z1; if (((r0.x % ((m0 * garr[u2 & 7u]) | 1u))) & 1u) { t1 = (unsigned)((unsigned)((int)1u < (int)0x80000000u) == (unsigned)w0); z1 = (double)(((unsigned)((int)(unsigned)f0 >= (int)(unsigned)e0)) & 255u); } if (((r0.x % ((m0 * garr[u2 & 7u]) | 1u))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)(0xdeb0d18fu || 7u), ((unsigned)f0 / (9u | 1u)), (unsigned)((0xfba415aau % (a0[i0 & 3u] | 1u)) < (unsigned)h1)); }
            if (6u) continue;
        }
        continue; (void)((a0[i0 & 3u] ^ fuel));
        L3: if (--fuel == 0u) goto done;
    }
    { unsigned t2; double z2; if ((-(unsigned)((int)4u >= (int)~((unsigned)h1 >> ((unsigned)b0 & 31u)))) & 1u) { t2 = 0x7fffffffu; z2 = (double)((((unsigned)c0 ? (unsigned)(w0 >> 29) : 4u)) & 255u); } if ((-(unsigned)((int)4u >= (int)~((unsigned)h1 >> ((unsigned)b0 & 31u)))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        { unsigned t3; double z3; if ((0xb3908734u) & 1u) { t3 = (0x10000u % ((i0 << ((unsigned)h1 & 31u)) | 1u)); z3 = (double)(((unsigned)l0) & 255u); } if ((0xb3908734u) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            *mp = -(unsigned)((int)(unsigned)(signed char)(unsigned)((short)(0x3543e5a5u % ((unsigned)s1 | 1u)) > (signed char)i1) < (int)(v0 % (3u | 1u)));
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                g0 = (unsigned)((unsigned)d0 || (unsigned)l0);
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)(((unsigned)e0 << ((unsigned)c1 & 31u)));
                }
                if (((unsigned)((int)(unsigned)c0 >= (int)fuel) ^ (unsigned)(w0 >> 29))) break;
            }
        }
        switch ((unsigned)((short)u0 > (signed char)(a0[i0 & 3u] << (garr[u2 & 7u] & 31u))) & 7u) {
            case 0u: ;
            if (budget != 0u) { budget -= 1u; u3 = fn2(~(p0 ? (unsigned)h0 : (unsigned)l0), (unsigned)h1, (unsigned)((int)u1 >= (int)(unsigned)h1)); }
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)a0[i0 & 3u] < (int)0x943d23b9u);
            if (u1) break;
            *q0 = ((i0 & r0.x) - ((unsigned)(w0 >> 29) % (*q0 | 1u)));
            case 7u: ;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn3(((unsigned)b0 + m0), (unsigned)((unsigned)((unsigned)w0 || (unsigned)s1) || (unsigned)(x0 >> 70)), (unsigned)!(((unsigned)w0 & (unsigned)d0) - u1)); }
        if ((unsigned)((unsigned)((short)r0.y > (signed char)0xffffffffu) == garr[i1 & 7u])) {
            if (0x7fffffffu) goto L4;
            s0 = (int)((unsigned)(0xffffffffu == ((unsigned)d0 + (unsigned)c0)) ^ (unsigned)c0);
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)1u >= (int)((unsigned)((int)0xffffffffu < (int)(unsigned)w0) - (g0 + (unsigned)w0)));
            while (i0++ < 5u && (unsigned)(1u && 0xa3ba96deu)) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)c1 << ((unsigned)((unsigned)((int)(unsigned)((unsigned)s1 || u3) < (int)(unsigned)x0) && (unsigned)((unsigned)e0 < 0u)) & 63u);
                break; (void)((unsigned)((int)*q0 >= (int)(m0 - i0)));
            }
            if (u3 == 7u) return ((unsigned)e0 % ((0x3cd5a1f1u >> (0x20b430d8u & 31u)) | 1u));
            if (fuel < 8u) return (garr[u2 & 7u] | (unsigned)(u1 && 0x80000000u));
        } else {
            goto done;
            m0 ^= p2;
            s0 = (int)(*q0 ^ (unsigned)((int)*mp < (int)g0));
            *q0 = u2;
        }
    }
    goto L1;
    s1 = (int)((unsigned)s1 + garr[u2 & 7u]);
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((unsigned)b0 | (unsigned)x0) & 1023u);
            if ((unsigned)b0) break;
            r0.y ^= (unsigned)h1;
        }
        if (((4u - 7u) * (unsigned)c0)) break;
    } while (i0++ < 4u && (fuel >> (0x6624d669u & 31u)));
    u2 = (unsigned)(unsigned char)(~(unsigned)(5u < (unsigned)f0) - (unsigned)(2u || (0xb2dd8ee2u >> (0xd4edb82du & 31u))));
    if (budget != 0u) { budget -= 1u; u2 = fn0((0x60382774u | (unsigned)(w0 >> 29)), (*mp - (unsigned)(i1 == 0x2a410dafu)), 0xb7d44be9u); }
    if (fuel < 8u) return (((unsigned)(w0 >> 29) % (g0 | 1u)) / ((unsigned)((int)0x10000u < (int)0x3f59d82u) | 1u));
    i1 = (a0[i0 & 3u] >> ((unsigned)f0 & 31u)) & 15u;
    f0 = f0 * 0.5f + (float)((unsigned)((r0.x ^ (unsigned)(x0 >> 70)) || (0xffffffffu >> ((0x80000000u ^ 0x80000000u) & 31u))) & 255u);
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((i2 ? 7u : u2)) break;
            if ((unsigned)((int)5u >= (int)0x7fffffffu)) break;
        }
        l0 = (long)((unsigned long)l0 + (0u << ((unsigned)((int)(unsigned)((int)p2 >= (int)u3) >= (int)a0[i0 & 3u]) & 31u)));
        while (i1++ < 3u && (g1 % ((unsigned)l0 | 1u))) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)((unsigned)b0 % ((unsigned)b0 | 1u)) << ((garr[u2 & 7u] + p1) & 63u);
        }
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(v0 & 1023u);
            if ((unsigned)b0) {
                if (garr[u2 & 7u]) {
                    x0 = x0 * 0x100000001b3ull + (unsigned)s0;
                }
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)((unsigned)(p2 == (unsigned)h1) - (unsigned)s1);
                }
            } else {
                while (i2++ < 5u && p0) { if (--fuel == 0u) goto done;
                    if ((unsigned)((*mp | fuel) == v0)) break;
                    if (*q0) continue;
                    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        m0 ^= ((unsigned)w0 - (unsigned)x0);
                    }
                    if ((unsigned)((unsigned)l0 < (unsigned)l0)) continue;
                    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)h0 ^ (a0[u1 & 3u] >> (v0 & 31u))), 0x10000u, ((unsigned)s0 ? *q0 : *mp)); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(7u == 0x10000u), (unsigned)((unsigned)(unsigned char)(unsigned)(a0[i0 & 3u] || g0) || 4u), (0xffffffffu ^ 0xd17c0b0eu)); }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)((short)i1 > (signed char)r0.y) || (unsigned)s0), 0xc8e16c98u, (unsigned)(0xffffffffu || (unsigned)f0)); }
                garr[7u & 7u] = (3u % (((unsigned)((int)0x10000u < (int)5u) | (unsigned)c0) | 1u));
                e0 = e0 * 0.5L + (long double)(((unsigned)c1 + 6u) & 1023u);
            }
            { unsigned t4; double z4; if ((a0[i0 & 3u]) & 1u) { t4 = (unsigned)((short)(u3 ^ i0) > (signed char)(unsigned)s1); z4 = (double)((-(p0 >> (0x7fffffffu & 31u))) & 255u); } if ((a0[i0 & 3u]) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                if ((0x10000u % ((3u | v0) | 1u))) goto L3;
                s1 = (int)((unsigned)s1 + u3);
                while (i2++ < 3u && g1) { if (--fuel == 0u) goto done;
                    s0 = (int)((0x10000u % (v0 | 1u)) + i1);
                }
                do { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)(((p1 & (unsigned)s0) + (9u % (0x93b3a810u | 1u))) & 255u);
                } while (i2++ < 2u && (v0 << ((unsigned)s1 & 31u)));
                if (0u) break;
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)f0 >> (((unsigned)s1 & (unsigned)h0) & 31u)), (unsigned)((int)(v0 - i0) >= (int)*q0), (unsigned)((int)(unsigned)s0 < (int)(unsigned)d0)); }
                    r0.y ^= u0;
                }
            }
            x0 = x0 * 0x100000001b3ull + 3u;
            for (;;) { if (--fuel == 0u) goto done;
                c1 = (signed char)(u0 + (6u % ((unsigned)d0 | 1u)));
                switch (p1 & 7u) {
                    *mp = (unsigned)(r0.y == u3);
                }
                if ((unsigned)(a0[i0 & 3u] < u0)) break;
                if (fuel) break;
            }
            u1 = (unsigned)(u1 && (unsigned)((short)(unsigned)w0 > (signed char)0xb3711beeu));
        }
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)((i0 + u0) - 2u);
        x0 = x0 * 0x100000001b3ull + 4u;
        if ((r0.y * 0x8eadce7cu)) goto done;
        switch (((unsigned)s0 | -(0x80000000u ^ g0)) & 7u) {
            if ((((unsigned)h1 & fuel) + 0x10000u)) goto done;
        }
        r0.y ^= (p1 << ((unsigned)f0 & 31u));
    }
    { unsigned t5; double z5; if (((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)b0)) & 1u) { t5 = (unsigned)(((unsigned)f0 << ((unsigned)h0 & 31u)) && (unsigned)b0); z5 = (double)((0x7fffffffu) & 255u); } if (((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)b0)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        i0 = (0x8822c8a9u & (unsigned)((unsigned)b0 == (unsigned)(4u < p1))) & 15u;
        while ((unsigned)((int)(unsigned)h0 >= (int)4u)) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                u1 = u1 * 0x9e3779b1u + (((unsigned)w0 * 0xe5d94eabu) % (0x47cdd029u | 1u));
            }
            if ((unsigned)((i1 - (unsigned)d0) || *q0)) break;
            if ((unsigned)(r0.x || 0x80000000u)) {
                if ((unsigned)!((unsigned)h1 / (u1 | 1u))) break;
                g1 += ((unsigned)x0 | ((unsigned)(x0 >> 70) / (((unsigned)((int)(unsigned)w0 < (int)p0) >> (i2 & 31u)) | 1u)));
                if (*q0) break;
                if ((unsigned)((unsigned)x0 == 9u)) break;
                break; (void)((unsigned)((short)(unsigned)h1 > (signed char)p0));
            }
            break; (void)(garr[u2 & 7u]);
        }
        u1 ^= (unsigned)(unsigned char)((unsigned)s1 % (g1 | 1u));
        r0.y ^= u2;
        w0 = w0 * 6364136223846793005ull + (g0 / ((unsigned)l0 | 1u));
        r0.y ^= ((unsigned)(short)((p1 ^ 0x7fffffffu) | (i2 / (r0.y | 1u))) & 0x80000000u);
    }
    goto L0;
    u1 = -(p2 << (0x2a843a9u & 31u));
    if (budget != 0u) { budget -= 1u; u2 = fn0((garr[u2 & 7u] - ~((unsigned)(w0 >> 29) | 0x9cb9f883u)), (unsigned)e0, (u2 | i2)); }
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)l0, ((unsigned)b0 ? (unsigned)h1 : i2), (unsigned)((unsigned)b0 == (0x7fffffffu << (u2 & 31u)))); }
    garr[(unsigned)(x0 >> 70) & 7u] = (garr[u2 & 7u] ? p2 : (unsigned)h1);
    if (0x10000u) {
        goto L3;
        if (budget != 0u) { budget -= 1u; u2 = fn3(v0, (unsigned)(short)(unsigned)(i2 && -((unsigned)h0 & a0[u1 & 3u])), (0x4f6dcc0cu / ((unsigned)(signed char)(unsigned)((int)g1 < (int)g1) | 1u))); }
    } else {
        { unsigned t6; double z6; if (((unsigned)(signed char)(u2 ^ i2)) & 1u) { t6 = (unsigned)((unsigned)e0 && ((unsigned)d0 >> ((unsigned)h0 & 31u))); z6 = (double)(((v0 << ((unsigned)f0 & 31u))) & 255u); } if (((unsigned)(signed char)(u2 ^ i2)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            while (i0++ < 3u && (0x351ba185u & (g1 - (unsigned)s1))) { if (--fuel == 0u) goto done;
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((p1 * (unsigned)(x0 >> 70)));
                }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((g0 | (unsigned)c0), (unsigned)b0, (unsigned)((int)*q0 < (int)2u)); }
        }
        goto L0;
        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((int)4u >= (int)*q0), ((0x80000000u + p1) % ((unsigned)f0 | 1u)), 0x221b65aeu); }
        u0 ^= (p0 ? r0.x : (unsigned)(p0 == (unsigned)(x0 >> 70)));
    }
    while (i0++ < 4u && (unsigned)(short)((unsigned)(x0 >> 70) - (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((unsigned)((unsigned)((int)0x80000000u >= (int)~(v0 % (r0.y | 1u))) && 0x80000000u) & 255u);
        do { if (--fuel == 0u) goto done;
            if ((0x10000u >> ((p0 >> (r0.y & 31u)) & 31u))) break;
            f0 = f0 * 0.5f + (float)(((unsigned)!(i2 >> (g0 & 31u)) ^ (unsigned)((unsigned)e0 || garr[i1 & 7u])) & 255u);
            while (((2u / (0x7fffffffu | 1u)) % (6u | 1u))) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn1(r0.x, (unsigned)(signed char)(m0 ? a0[u1 & 3u] : 0x89df4081u), (0x3ed50555u ? *q0 : (unsigned)w0)); }
                s0 = (int)8u;
            }
            switch (((unsigned)(unsigned char)((unsigned)(x0 >> 70) * 0x80000000u) ^ (unsigned)(w0 >> 29)) & 7u) {
                h1 = (unsigned short)(h1 + (unsigned)w0);
                c1 = (signed char)(unsigned)(((unsigned)b0 >> ((unsigned)(short)((unsigned)w0 & *q0) & 31u)) || 0xffffffffu);
            }
            v0 = ((unsigned)e0 ? u3 : g1);
        } while (i1++ < 6u && (unsigned)((int)5u < (int)5u));
        switch ((0xffffffffu ? (unsigned)h0 : (unsigned)s1) & 7u) {
            case 7u: ;
            case 0u: ;
        }
        if ((unsigned)(unsigned char)((unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)(x0 >> 70)) / (8u | 1u))) goto done;
    }
    do { if (--fuel == 0u) goto done;
        switch ((unsigned)l0 & 7u) {
            g0 = ((unsigned)s1 & ((unsigned)((4u << (p2 & 31u)) == garr[u2 & 7u]) * p0));
            for (;;) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)((i2 ? (unsigned)l0 : ((unsigned)s1 / ((unsigned)d0 | 1u))) == (unsigned)(w0 >> 29)) & 1023u);
                    if (budget != 0u) { budget -= 1u; u3 = fn3((u2 - (0xffffffffu << (3u & 31u))), (unsigned)!(unsigned)((int)(unsigned)(short)(unsigned)((unsigned)c0 < v0) >= (int)0x9f71cd6au), (unsigned)l0); }
                    if ((unsigned)c0) break;
                    u2 ^= (unsigned)((i0 / (((u0 + (unsigned)d0) << ((unsigned)s0 & 31u)) | 1u)) < 0x7fffffffu);
                    h1 = (unsigned short)(h1 + ((unsigned)h1 | (0x7fffffffu ^ 0xffffffffu)));
                    break; (void)((0x7fffffffu * p0));
                }
            }
            if ((i1 + (unsigned)((int)(unsigned)e0 < (int)(unsigned)s0))) goto L0;
        }
        *q0 += ((unsigned)c1 * (unsigned)h1);
        w0 ^= (unsigned long long)-(unsigned)((int)(unsigned)f0 < (int)p2) << (((unsigned)((unsigned)(0xffffffffu && p0) && 0xe708a9c7u) << ((unsigned)((unsigned)x0 && 0x869809acu) & 31u)) & 63u);
        if (0x10000u) break;
        f0 = f0 * 0.5f + (float)((0x374ee550u ^ (unsigned)(i1 < (unsigned)(x0 >> 70))) & 255u);
    } while (i0++ < 2u && (unsigned)((int)0x80000000u >= (int)u1));
    goto L4;
    while (i0++ < 4u && *mp) { if (--fuel == 0u) goto done;
        { unsigned t7; double z7; if (((p1 & (garr[u2 & 7u] - 0x540d5e62u))) & 1u) { t7 = (unsigned)(short)(unsigned)((int)(unsigned)c1 >= (int)*q0); z7 = (double)(((unsigned)(((unsigned)c0 << (a0[i0 & 3u] & 31u)) || 0xe6779d3fu)) & 255u); } if (((p1 & (garr[u2 & 7u] - 0x540d5e62u))) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
            u1 = u1 * 0x9e3779b1u + ((i2 ^ (unsigned)c1) >> ((unsigned)((unsigned)s0 || u3) & 31u));
            *mp = (unsigned)(unsigned char)(0x10000u ? p0 : 0x7fffffffu);
        }
        w0 ^= (unsigned long long)(unsigned)((short)3u > (signed char)0xceafd185u) << (~((unsigned)((u2 - 7u) < (unsigned)b0) | 0x6c1a9ce3u) & 63u);
    }
    if ((unsigned)(*mp && 0x80000000u)) goto done;
    if (fuel < 8u) return (unsigned)(((unsigned)(x0 >> 70) / (0x80000000u | 1u)) || ~(unsigned)(v0 < v0));
    if (budget != 0u) { budget -= 1u; u0 = fn3(((unsigned)d0 | (unsigned)d0), (unsigned)(x0 >> 70), (0u - (unsigned)(w0 >> 29))); }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        a0[1u & 3u] = (unsigned)((int)(unsigned)((unsigned)l0 < m0) >= (int)((unsigned)(a0[u1 & 3u] < 0xffffffffu) & (unsigned)x0));
        switch ((unsigned)(unsigned char)(p1 + 0x7fffffffu) & 7u) {
            case 2u: ;
            case 3u: ;
            l0 = (long)((unsigned long)l0 + (unsigned)((short)0x10000u > (signed char)-((g0 - (unsigned)l0) + (unsigned)l0)));
        }
        *q0 = ~((unsigned)((int)fuel < (int)(unsigned)((int)(unsigned)h0 >= (int)(unsigned)((unsigned)x0 == 0x9c6d270eu))) % ((unsigned)x0 | 1u));
    }
    h0 = (short)(unsigned)((unsigned)((unsigned)w0 && u1) || 3u);
    if ((5u % ((0xe2da253cu & 6u) | 1u))) goto L0;
    w0 = w0 * 6364136223846793005ull + (i0 - garr[i1 & 7u]);
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (fuel < 8u) return ((unsigned)((int)0x53da8579u >= (int)(p1 * 0xffffffffu)) | (unsigned)b0);
        e0 = e0 * 0.5L + (long double)(((m0 / (fuel | 1u)) * 0xffffffffu) & 1023u);
        if ((unsigned)s0) continue;
        s1 = (int)((unsigned)s1 + p0);
        h0 = (short)(unsigned)(signed char)((unsigned)((unsigned)((int)9u < (int)u3) && 0x80000000u) | v0);
        switch ((unsigned)c1 & 7u) {
            case 0u: ;
            l0 = (long)((unsigned long)l0 + (p2 / ((unsigned)d0 | 1u)));
            *q0 += u2;
            goto L2;
            *mp = (0x23c83d59u % (((0xffffffffu >> ((unsigned)l0 & 31u)) << (0x3c2623e4u & 31u)) | 1u));
            b0 = ((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)c1) ? (unsigned)(a0[i0 & 3u] < a0[i0 & 3u]) : (unsigned)s1) != 0u;
        }
    }
    if ((p2 / ((0xffffffffu & 0x19743dbdu) | 1u))) goto L4;
    { unsigned t8; double z8; if ((~(unsigned)(r0.x == (unsigned)((short)p0 > (signed char)(unsigned)b0))) & 1u) { t8 = (g1 >> ((0x2373f646u ^ i0) & 31u)); z8 = (double)((6u) & 255u); } if ((~(unsigned)(r0.x == (unsigned)((short)p0 > (signed char)(unsigned)b0))) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
        goto L4;
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(unsigned char)(unsigned)((int)r0.y >= (int)(unsigned)(i0 && v0)), (unsigned)l0, -(unsigned)((short)0x7fffffffu > (signed char)0x10000u)); }
        if ((0x7fffffffu + 0x80000000u)) {
            if ((((unsigned)e0 - a0[i0 & 3u]) ^ 0x10000u)) goto L1;
        } else {
            garr[((unsigned)w0 << ((unsigned)d0 & 31u)) & 7u] = ((unsigned)((unsigned)w0 < 7u) * (unsigned)x0);
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)fuel >= (int)(unsigned)(0xdf6d3b02u < m0))) break;
                continue; (void)((unsigned)((int)(unsigned)c0 < (int)(unsigned)c0));
                switch (((unsigned)h1 / (r0.x | 1u)) & 7u) {
                    *q0 += (unsigned)f0;
                }
                if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((int)(i1 ^ fuel) >= (int)(unsigned)h0), (unsigned)(unsigned char)(unsigned)((int)0x7fffffffu < (int)0x6040ecb2u), -((unsigned)(short)((unsigned)l0 % (0xdb79b607u | 1u)) - 8u)); }
                if ((unsigned)c0) goto L4;
                if ((unsigned)((short)(unsigned)s1 > (signed char)(m0 << (i0 & 31u)))) break;
            }
        }
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if (((unsigned)x0 - u1)) {
                    q0 = &garr[(0xb902cf09u ^ ~(0xdd4a7884u >> (u2 & 31u))) & 7u];
                } else {
                    if (budget != 0u) { budget -= 1u; u1 = fn1((((unsigned)f0 + (unsigned)l0) - u1), (unsigned)((int)a0[i0 & 3u] < (int)(u3 & (unsigned)x0)), (0x152402cfu << (0x596107c4u & 31u))); }
                    if ((a0[i0 & 3u] + (unsigned)(w0 >> 29))) break;
                    if ((unsigned)(x0 >> 70)) break;
                }
                if (((unsigned)s0 * (unsigned)d0)) break;
                if ((i1 >> ((unsigned)((short)i2 > (signed char)m0) & 31u))) {
                    i1 = (unsigned)(short)(unsigned)(0u < (unsigned)e0) & 15u;
                    if ((p0 / (((unsigned)h1 << (g0 & 31u)) | 1u))) break;
                } else {
                    if (u3 == 7u) return u1;
                    goto done;
                }
            } while (i2++ < 6u && (9u * 0x606ce461u));
            do { if (--fuel == 0u) goto done;
                continue; (void)((unsigned)((int)(0x7fffffffu % (3u | 1u)) < (int)fuel));
                r0.x = ((((unsigned)(w0 >> 29) ^ (unsigned)x0) + (unsigned)l0) << (0x7fffffffu & 31u));
            } while (i2++ < 3u && (unsigned)e0);
            q0 = &garr[(unsigned)((int)(unsigned)d0 >= (int)0x80000000u) & 7u];
            break; (void)((0x9cbd5bb4u % (p1 | 1u)));
            if ((unsigned)(w0 >> 29)) {
                { unsigned t9; double z9; if (((unsigned)((int)(unsigned)f0 < (int)i0)) & 1u) { t9 = (unsigned)((2u - 0x10000u) || (unsigned)h1); z9 = (double)((p2) & 255u); } if (((unsigned)((int)(unsigned)f0 < (int)i0)) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                    while (i2++ < 7u && (unsigned)!(unsigned)(p1 < -(0xffffffffu / (i1 | 1u)))) { if (--fuel == 0u) goto done;
                        h0 = (short)(unsigned)x0;
                    }
                    u2 = u2 * 0x9e3779b1u + 3u;
                }
                d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)s0 >= (int)0x5d808904u) & 1023u);
            }
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)((short)0x841f3c5u > (signed char)fuel)), (unsigned)((int)u0 >= (int)u2), -(unsigned)((4u % ((unsigned)c1 | 1u)) && (unsigned)s0)); }
            }
        }
    }
    if (fuel < 8u) return ~(((unsigned)s1 ? 0x71aebdf5u : 9u) | fuel);
    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)(w0 >> 29) - (unsigned)(short)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)u1)), (0x80000000u + r0.y), (unsigned)f0); }
    switch ((unsigned)(x0 >> 70) & 7u) {
        w0 ^= (unsigned long long)(unsigned)((short)i0 > (signed char)u2) << (~((unsigned)c1 % ((7u ? (0xffffffffu << (p0 & 31u)) : (unsigned)f0) | 1u)) & 63u);
    }
    if (((unsigned)(0x80000000u < 0xba0eb610u) / (*q0 | 1u))) goto L1;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)(0xbad2ab74u && 0x80000000u);
        g1 += (unsigned)((short)0xffffffffu > (signed char)(unsigned)((short)(unsigned)b0 > (signed char)*mp));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 15u, 0x2d1e9797u, 0xedb33c97u },
        { 6u, 0x1754971cu, 0x561b86e0u },
        { 13u, 0x4eb5e2au, 0x5ea016d6u },
        { 6u, 0xdeb6f38bu, 0x8e7778eau },
        { 7u, 0x47e10047u, 0xd95e0988u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
