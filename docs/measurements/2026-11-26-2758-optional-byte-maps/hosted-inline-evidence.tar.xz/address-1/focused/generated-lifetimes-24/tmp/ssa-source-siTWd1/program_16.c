// test-ssa-source's program of seed 141000439 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x92ce3679u, g1 = 0xe9748ef6u;
static unsigned garr[8] = { 0xe8f2910cu, 0xea428a5fu, 0x2f7feb44u, 0x92c83478u, 0xe6a4c8ddu, 0x8469da6fu, 0xc0d943feu, 0x5c02d2b0u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L3;
    if ((g0 ^ u2)) goto L2;
    c0 = (unsigned char)fuel;
    { unsigned t0; double z0; if ((0u) & 1u) { t0 = (unsigned)(short)(((unsigned)e0 / (garr[u2 & 7u] | 1u)) * u1); z0 = (double)((((unsigned)((unsigned)c0 < *mp) >> (g1 & 31u))) & 255u); } if ((0u) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            v0 = (unsigned)((unsigned)(short)((unsigned)s0 & (unsigned)h1) == (unsigned)(r0.y < 0xb84b9f5au));
        }
        d0 = d0 * 0.5 + (double)((m0 % (0xffffffffu | 1u)) & 1023u);
    }
    goto done;
    L0: if (--fuel == 0u) goto done;
    if (fuel < 8u) return a0[u1 & 3u];
    *q0 = ~(u1 ? (i1 - i1) : 0x6f52b900u);
    if (((unsigned)c1 ? u2 : u3)) {
        if (((unsigned)h1 % (4u | 1u))) {
            s1 = (int)((unsigned)s1 + (((unsigned)(short)(0xffffffffu / (0xf678f980u | 1u)) * (0x53888c14u + (unsigned)h0)) * *mp));
            *mp = (unsigned)((unsigned)l0 < 0xd17759a8u);
            goto L3;
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)(w0 >> 29) && (unsigned)x0)) {
                    a0[(unsigned)(signed char)(g0 << ((unsigned)f0 & 31u)) & 3u] = ((unsigned)!(0x7fffffffu << (g0 & 31u)) >> (i2 & 31u));
                    L1: if (--fuel == 0u) goto done;
                } else {
                    a0[(unsigned)((int)fuel >= (int)3u) & 3u] = 0x7646235bu;
                    goto L1;
                    if ((unsigned)h0) break;
                    L2: if (--fuel == 0u) goto done;
                }
                u1 ^= (unsigned)(unsigned char)(0u + ((unsigned)f0 ^ 5u));
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)(r0.x << ((unsigned)s1 & 31u)) << (((unsigned)h1 << ((a0[u1 & 3u] ? 0xffffffffu : r0.y) & 31u)) & 63u);
                    { unsigned t1; double z1; if ((~(a0[i0 & 3u] << (7u & 31u))) & 1u) { t1 = (u3 ^ r0.x); z1 = (double)((-((unsigned)!(unsigned)((unsigned)s0 || (unsigned)h0) + 2u)) & 255u); } if ((~(a0[i0 & 3u] << (7u & 31u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                        if ((unsigned)((int)(unsigned)e0 < (int)a0[u1 & 3u])) break;
                        L3: if (--fuel == 0u) goto done;
                        if (fuel < 8u) return (unsigned)((int)(unsigned)((int)p2 < (int)i0) >= (int)(unsigned)w0);
                        u3 += (unsigned)(short)((unsigned)e0 * u3);
                    }
                }
                if (*q0) {
                    continue; (void)((unsigned)!(fuel - (unsigned)((int)m0 < (int)(unsigned)c1)));
                    L4: if (--fuel == 0u) goto done;
                    switch ((0xffffffffu ^ (unsigned)!(0x97bbaf49u * g0)) & 7u) {
                        case 5u: ;
                        case 2u: ;
                        continue; (void)(3u);
                        case 7u: ;
                        default: ;
                    }
                    if ((u3 + r0.y)) break;
                } else {
                    a0[(r0.x | a0[i0 & 3u]) & 3u] = (unsigned)e0;
                }
            }
            s0 = (int)((unsigned)((short)((unsigned)d0 / ((unsigned)d0 | 1u)) > (signed char)4u) - (unsigned)(p1 && p2));
            if ((unsigned)(x0 >> 70)) {
                g1 += (unsigned)((unsigned)(w0 >> 29) == (9u ? 0x80000000u : g1));
                u3 += (u1 << ((unsigned)w0 & 31u));
                if ((unsigned)c1) {
                    e0 = e0 * 0.5L + (long double)((unsigned)((int)3u >= (int)((unsigned)(((unsigned)s0 | 6u) < (unsigned)x0) & r0.y)) & 1023u);
                }
                r0.y ^= (unsigned)(short)(unsigned)(r0.y < (unsigned)c0);
                if (((unsigned)s0 + (unsigned)e0)) goto L1;
            }
        }
        goto done;
        goto done;
        if (0x7fffffffu) goto L4;
        goto done;
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)(((unsigned)e0 ^ p1) && (unsigned)((int)(i1 + u3) >= (int)a0[u1 & 3u]));
            d0 = d0 * 0.5 + (double)((0xb99662adu >> (0u & 31u)) & 1023u);
            if (i0) {
                if ((fuel / (((unsigned)x0 ^ (unsigned)s0) | 1u))) break;
                if (0x7fffffffu) break;
                u1 ^= (unsigned)e0;
            }
        }
    }
    if ((unsigned)(u1 || (i2 << (u2 & 31u)))) goto L1;
    if ((*mp + g1)) {
        i0 = 2u & 15u;
        while (i0++ < 3u && (r0.x / ((u0 * (unsigned)c0) | 1u))) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(short)(unsigned)((int)(unsigned)f0 < (int)i0));
                switch (p2 & 7u) {
                    l0 = (long)((unsigned long)l0 + (g1 - (unsigned)s0));
                    goto L0;
                    u3 = u3 * 0x9e3779b1u + -(0x11fa502bu ? 0x165dda76u : 7u);
                }
                switch (((unsigned)(x0 >> 70) % ((unsigned)(w0 >> 29) | 1u)) & 7u) {
                    b0 = (unsigned)((unsigned)h0 || ((unsigned)(0x7fffffffu < (unsigned)f0) ? 6u : 0x9d8d1880u)) != 0u;
                    case 0u: ;
                    u2 ^= 0x80000000u;
                    g0 = (unsigned)((p1 & (unsigned)((unsigned)h1 < 0xffffffffu)) || ~(unsigned)(*q0 || a0[u1 & 3u]));
                    case 2u: ;
                }
                if ((unsigned)((1u & (unsigned)w0) == v0)) break;
            }
        }
        v0 = ~(unsigned)((short)(unsigned)(p0 || 0x54ca0bedu) > (signed char)7u);
    } else {
        u0 = u2;
        goto L0;
        w0 ^= (unsigned long long)7u << (-((g0 << ((unsigned)(i2 && (unsigned)(5u || (unsigned)h1)) & 31u)) - 0x80000000u) & 63u);
        if (a0[u1 & 3u]) goto L1;
    }
    if (g1) goto done;
    if (0x233c023u) goto L0;
    a0[(a0[i0 & 3u] % (0x10000u | 1u)) & 3u] = (unsigned)((unsigned)((short)*mp > (signed char)v0) && (p1 * (unsigned)(w0 >> 29)));
    w0 ^= (unsigned long long)(unsigned)((short)a0[u1 & 3u] > (signed char)0x80000000u) << (*q0 & 63u);
    w0 ^= (unsigned long long)(unsigned)((unsigned)s0 || p1) << ((7u & (unsigned)x0) & 63u);
    switch ((unsigned)(unsigned char)(unsigned)((int)garr[i1 & 7u] >= (int)0xb504c57du) & 7u) {
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 = (unsigned)((short)*mp > (signed char)(unsigned)f0);
            case 1u: ;
            case 0u: ;
        }
        case 5u: ;
        default: ;
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((9u << (0x7fffffffu & 31u))) goto L2;
    }
    switch (((unsigned)(signed char)((unsigned)(x0 >> 70) ^ garr[u2 & 7u]) | v0) & 7u) {
        e0 = e0 * 0.5L + (long double)((garr[i1 & 7u] % ((i2 | (garr[i1 & 7u] << (u2 & 31u))) | 1u)) & 1023u);
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)((a0[i0 & 3u] | (unsigned)((short)r0.y > (signed char)v0)) & (0x7fffffffu - 0x4081d6cu));
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)p0 << ((unsigned)(signed char)(unsigned)((int)(unsigned)(i1 == 9u) >= (int)(p0 >> (*mp & 31u))) & 63u);
                *mp = (unsigned)((int)a0[u1 & 3u] < (int)(garr[i1 & 7u] & 8u));
            } while (i1++ < 5u && (*q0 - p2));
            d0 = d0 * 0.5 + (double)((i0 - ((unsigned)(i0 < m0) ^ (unsigned)c0)) & 1023u);
            if (fuel < 8u) return ((i1 >> ((garr[u2 & 7u] << (garr[u2 & 7u] & 31u)) & 31u)) - (unsigned)(0x593d7dd3u == p1));
        }
        case 1u: ;
    }
    if (i0) {
        g1 += (i0 ? (p2 ^ (unsigned)((int)(unsigned)x0 < (int)i0)) : p1);
        w0 = w0 * 6364136223846793005ull + r0.x;
        if (((unsigned)(0x80000000u < (unsigned)l0) << ((unsigned)c0 & 31u))) goto L0;
        if ((((unsigned)f0 | (unsigned)h1) | r0.y)) goto L4;
    }
    r0.y ^= ((unsigned)((unsigned)l0 == p1) ? 8u : (6u ^ p1));
    h0 = (short)(0x7fffffffu | (unsigned)(0xddcdffafu == (i1 ^ (unsigned)(x0 >> 70))));
    h0 = (short)(unsigned)((unsigned)((int)(unsigned)c0 < (int)u1) || a0[u1 & 3u]);
    { unsigned t2; double z2; if ((i0) & 1u) { t2 = (unsigned)(short)(i0 << ((unsigned)(v0 || (unsigned)x0) & 31u)); z2 = (double)(((~(unsigned)((int)(unsigned)l0 < (int)(unsigned)d0) / (0x4c59cda8u | 1u))) & 255u); } if ((i0) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        switch (0x10000u & 7u) {
            { unsigned t3; double z3; if ((-(unsigned)((unsigned)(u1 == (unsigned)h1) < *mp)) & 1u) { t3 = fuel; z3 = (double)((garr[u2 & 7u]) & 255u); } if ((-(unsigned)((unsigned)(u1 == (unsigned)h1) < *mp)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                case 1u: ;
                case 6u: ;
                w0 ^= (unsigned long long)(3u & 6u) << (*q0 & 63u);
            }
            if ((unsigned)c0) goto L1;
            case 3u: ;
            case 7u: ;
            e0 = e0 * 0.5L + (long double)((unsigned)(signed char)((unsigned)e0 * (0u - (unsigned)((unsigned)(0x80000000u < garr[u2 & 7u]) && 0xce423ab4u))) & 1023u);
        }
        r0.y ^= (g0 ^ (0x56cb4928u - *q0));
        u0 ^= (((unsigned)((int)(unsigned)c1 < (int)(unsigned)(9u || 8u)) ^ garr[i1 & 7u]) ^ fuel);
        w0 = w0 * 6364136223846793005ull + (((unsigned)s1 ^ i2) - (0xffffffffu ? (unsigned)h1 : 3u));
        switch (p0 & 7u) {
            if (((unsigned)(x0 >> 70) - i2)) break;
        }
        u1 ^= (unsigned)(fuel == (unsigned)(x0 >> 70));
    }
    u0 = (unsigned)((short)(unsigned)(signed char)(5u + 2u) > (signed char)g1);
    a0[garr[u2 & 7u] & 3u] = (unsigned)(signed char)(unsigned)((unsigned)(g1 == (unsigned)d0) && (unsigned)x0);
    q0 = &garr[(unsigned)((0x10000u | (unsigned)((int)(unsigned)h0 < (int)a0[i0 & 3u])) < 0xffffffffu) & 7u];
    l0 = (long)((unsigned long)l0 + 0xffffffffu);
    v0 = (unsigned)(0xffffffffu < -(unsigned)(g1 && a0[i0 & 3u]));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L1;
    goto L4;
    while (i0++ < 6u && 0x80000000u) { if (--fuel == 0u) goto done;
        b0 = (unsigned)(((unsigned)(9u == (unsigned)(x0 >> 70)) & (unsigned)s1) < 5u) != 0u;
        L0: if (--fuel == 0u) goto done;
        h0 = (short)i2;
        if ((unsigned)((int)i0 < (int)v0)) goto L1;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(p1 && 3u), ((unsigned)(8u || p0) << ((unsigned)x0 & 31u)), 3u); }
    if (budget != 0u) { budget -= 1u; u0 = fn0(0x10000u, 0x7fffffffu, ((unsigned)e0 | m0)); }
    if (budget != 0u) { budget -= 1u; u1 = fn0((0xb173b1d2u ^ ((unsigned)s1 / ((unsigned)h1 | 1u))), (unsigned)f0, (unsigned)(short)((unsigned)w0 >> (garr[i1 & 7u] & 31u))); }
    *mp = 0xffffffffu;
    u0 = (*mp + (unsigned)c0);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)l0) break;
        *q0 += ~(g0 % ((unsigned)((int)*q0 >= (int)((unsigned)(x0 >> 70) * (unsigned)e0)) | 1u));
    }
    goto done;
    L1: if (--fuel == 0u) goto done;
    if (r0.x) goto L2;
    goto L1;
    if ((unsigned)(short)(unsigned)((*mp << ((unsigned)x0 & 31u)) && u3)) {
        if ((unsigned)(u3 == m0)) goto L2;
        { unsigned t0; double z0; if (((0x10000u * (unsigned)h1)) & 1u) { t0 = (7u >> (6u & 31u)); z0 = (double)(((0x34063deau >> (g0 & 31u))) & 255u); } if (((0x10000u * (unsigned)h1)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            b0 = ((unsigned)((int)*mp < (int)p1) / (a0[u1 & 3u] | 1u)) != 0u;
            s1 = (int)((unsigned)s1 + 0x7fffffffu);
        }
        { unsigned t1; double z1; if ((i0) & 1u) { t1 = (u0 | 0x80000000u); z1 = (double)((-(unsigned)((int)(unsigned)(unsigned char)((unsigned)f0 + u2) >= (int)0x5a656238u)) & 255u); } if ((i0) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            v0 = ~((unsigned)d0 >> ((unsigned)(short)(unsigned)(3u < 0x8c4be6c1u) & 31u));
            *q0 = ((8u / ((unsigned)h0 | 1u)) + (unsigned)((unsigned)b0 || (unsigned)((int)3u >= (int)i0)));
        }
        u0 += (unsigned)((short)(g0 ^ ((unsigned)(signed char)(r0.x & m0) % (0x80000000u | 1u))) > (signed char)a0[u1 & 3u]);
        *mp = ((unsigned)(i1 < i2) - (unsigned)f0);
    }
    L2: if (--fuel == 0u) goto done;
    switch ((unsigned)!(6u ^ ((unsigned)c1 | v0)) & 7u) {
        f0 = f0 * 0.5f + (float)((u2 | (0xc65e7841u >> (garr[i1 & 7u] & 31u))) & 255u);
        u2 = ((unsigned)(6u == p1) & (unsigned)((int)(unsigned)((short)u3 > (signed char)(unsigned)d0) >= (int)2u));
        case 2u: ;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(((0xffffffffu >> (a0[i0 & 3u] & 31u)) * 1u), (unsigned)(signed char)(unsigned)((int)6u >= (int)5u), (unsigned)(unsigned char)(unsigned)((unsigned)w0 && (unsigned)((unsigned)s1 == u1))); }
    { unsigned t2; double z2; if ((i0) & 1u) { t2 = (unsigned)((int)p1 >= (int)(unsigned)s0); z2 = (double)(((0xdd29b7eau >> (p0 & 31u))) & 255u); } if ((i0) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        if (0xffffffffu) goto L1;
        r0.x = u3;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)g0 >= (int)(unsigned)h0), (r0.x | 0x80000000u), (unsigned)(p2 < p0)); }
    f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)e0 >> ((unsigned)(signed char)(0x7fffffffu ? 0x7fffffffu : (unsigned)e0) & 31u)) == 0xffffffffu) & 255u);
    while (i0++ < 7u && ((unsigned)s0 * ((unsigned)h1 / ((unsigned)h1 | 1u)))) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(a0[u1 & 3u] && r0.y));
        if (budget != 0u) { budget -= 1u; u0 = fn0((a0[u1 & 3u] << ((unsigned)d0 & 31u)), (0u * (unsigned)x0), (unsigned)h1); }
        w0 ^= (unsigned long long)u1 << ((g0 / ((unsigned)((short)(unsigned)(a0[i0 & 3u] < 0x5c435855u) > (signed char)i0) | 1u)) & 63u);
        L3: if (--fuel == 0u) goto done;
    }
    f0 = f0 * 0.5f + (float)(((u0 | (unsigned)(garr[i1 & 7u] == (*q0 * g0))) % (u0 | 1u)) & 255u);
    r0.y ^= (((unsigned)s1 + i1) / ((unsigned)h1 | 1u));
    do { if (--fuel == 0u) goto done;
        if (~(g1 - 0xc6aa40fbu)) break;
        if (fuel < 8u) return (unsigned)!(unsigned)(r0.y < (p0 & (0u >> (0x10000u & 31u))));
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((p1 << (v0 & 31u))) break;
            b0 = (1u & (0x2af7cb81u ^ 0x80000000u)) != 0u;
        }
    } while (i0++ < 5u && ((unsigned)w0 / (7u | 1u)));
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)f0, ((unsigned)(w0 >> 29) - (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)u3)), 1u); }
    if ((unsigned)!(unsigned)(0xffffffffu && (i0 - 0xffffffffu))) goto L3;
    switch (((unsigned)c1 * r0.x) & 7u) {
        if (i1) break;
    }
    d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(u3 || (unsigned)(u2 == 0x909d523du)) && ((unsigned)l0 * garr[i1 & 7u])) & 1023u);
    L4: if (--fuel == 0u) goto done;
    for (;;) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)i1 < (int)8u)) break;
                x0 = x0 * 0x100000001b3ull + 8u;
                i0 = (unsigned)(signed char)(u2 & ((unsigned)f0 | garr[u2 & 7u])) & 15u;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)w0, (unsigned)((int)(unsigned)h1 >= (int)a0[u1 & 3u]), (unsigned)w0); }
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(w0 >> 29), (garr[u2 & 7u] & (unsigned)(8u && (unsigned)s1)), (0x10000u << (2u & 31u))); }
            x0 = x0 * 0x100000001b3ull + (unsigned)!(((unsigned)h1 ? u1 : (unsigned)(signed char)(*q0 & u1)) * p0);
        } while (i1++ < 6u && (unsigned)s0);
        if ((9u * m0)) {
            c1 = (signed char)i2;
            if (((unsigned)c0 ^ 0x929355bau)) goto done;
            m0 ^= (unsigned)((short)0x54ae788eu > (signed char)(unsigned)((unsigned)(short)(unsigned)(i0 || a0[u1 & 3u]) < a0[i0 & 3u]));
            c0 = (unsigned char)(unsigned)((int)(unsigned)(short)(unsigned)((int)0xe671e206u >= (int)(unsigned)((short)0xffffffffu > (signed char)i0)) >= (int)(unsigned)((int)3u >= (int)(unsigned)s0));
            m0 ^= ((unsigned)h1 >> ((unsigned)b0 & 31u));
            if (u1) break;
        } else {
            if (budget != 0u) { budget -= 1u; u2 = fn0((i2 ^ (unsigned)(fuel && u2)), ((0x1c784a8u | (unsigned)w0) / ((unsigned)w0 | 1u)), ((unsigned)c0 + (unsigned)c0)); }
            u0 = (unsigned)(p0 < 0x10000u);
            s0 = (int)(p2 & (unsigned)(4u || (unsigned)h1));
        }
        u2 += (((unsigned)((short)m0 > (signed char)5u) | (r0.y ^ 0xea1a19f2u)) >> (r0.x & 31u));
        break; (void)(6u);
    }
    *mp = (0x10000u * (6u ? garr[u2 & 7u] : (unsigned)((int)0xba5b031au < (int)fuel)));
    if ((u2 * 0x68e245deu)) goto L3;
    switch ((r0.y % ((unsigned)(u3 && 4u) | 1u)) & 7u) {
        if (budget != 0u) { budget -= 1u; u1 = fn0(a0[i0 & 3u], (unsigned)((int)m0 < (int)(unsigned)((int)u2 < (int)0xc926a95u)), m0); }
        break; (void)(((unsigned)(*mp || garr[i1 & 7u]) << (0x7fffffffu & 31u)));
        case 5u: ;
        d0 = d0 * 0.5 + (double)(0xf4795a4au & 1023u);
    }
    if (a0[u1 & 3u]) goto L0;
    if (i0) goto L0;
    if (budget != 0u) { budget -= 1u; u3 = fn0((p1 % ((i2 & 0u) | 1u)), (unsigned)((int)0xd8ad49d3u >= (int)(unsigned)(0xffffffffu && i2)), 0xffffffffu); }
    while (i0++ < 4u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            garr[0x7fffffffu & 7u] = (unsigned)b0;
            *q0 += (unsigned)(signed char)(0x2d513b10u + (a0[u1 & 3u] & (v0 - 0xf5c6666au)));
            h1 = (unsigned short)(h1 + (unsigned)((int)(0xffffffffu ? *mp : (unsigned)(w0 >> 29)) < (int)(unsigned)(signed char)(0x10000u + m0)));
            u0 = (unsigned)(short)(((unsigned)x0 & (unsigned)c0) + (fuel - a0[u1 & 3u]));
            break; (void)((unsigned)((short)0x7fffffffu > (signed char)u3));
        }
    }
    if (0xd2143294u) {
        if ((unsigned)(v0 && (unsigned)l0)) {
            switch ((p1 / ((unsigned)(0xffffffffu < g0) | 1u)) & 7u) {
                if ((0xffffffffu % ((4u ^ i0) | 1u))) goto L0;
            }
        }
        do { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)4u << ((unsigned)((unsigned)l0 == (unsigned)(0x10000u == garr[i1 & 7u])) & 63u);
                if (a0[u1 & 3u]) break;
                if ((g1 - (unsigned)d0)) break;
                break; (void)((0xffffffffu % ((unsigned)((unsigned)c0 || (unsigned)h1) | 1u)));
                h0 = (short)(unsigned)((int)u2 >= (int)((unsigned)h0 << (((unsigned)h1 * 0x16470206u) & 31u)));
                if ((unsigned)s1) continue;
            }
            *mp = (unsigned)w0;
            v0 = v0;
            *q0 += (unsigned)l0;
        } while (i0++ < 4u && ((unsigned)(garr[u2 & 7u] < (unsigned)e0) ^ (unsigned)b0));
        m0 ^= (unsigned)s0;
        x0 = x0 * 0x100000001b3ull + (unsigned)(1u == (0u ^ fuel));
        if (u3 == 7u) return 0x80000000u;
        g1 += (unsigned)(signed char)(((unsigned)c1 ? a0[i0 & 3u] : a0[u1 & 3u]) + (unsigned)b0);
    }
    do { if (--fuel == 0u) goto done;
        { unsigned t3; double z3; if (((4u ^ 5u)) & 1u) { t3 = (0x10000u * (p2 * a0[i0 & 3u])); z3 = (double)(((g1 * (g1 / (m0 | 1u)))) & 255u); } if (((4u ^ 5u)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            x0 = x0 * 0x100000001b3ull + (unsigned)w0;
            while (i1++ < 4u && *mp) { if (--fuel == 0u) goto done;
                continue; (void)((unsigned)((0x65d023bfu - 0x110dab77u) && *mp));
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)(g0 * 0xffffffffu), (u1 + (0x912e4c04u + 0x80000000u)), ((6u << (0xa6d3592bu & 31u)) >> (u0 & 31u))); }
            u3 ^= (unsigned)!(0x44de2476u ? 0xa5b99190u : (unsigned)h1);
            s1 = (int)((unsigned)s1 + (((unsigned)(w0 >> 29) << ((unsigned)((unsigned)c1 < (unsigned)s0) & 31u)) + 0u));
        }
    } while (i0++ < 5u && (unsigned)(i1 || (unsigned)((short)3u > (signed char)i2)));
    r0.y ^= (-(i0 - 0x67233862u) / ((5u ^ (unsigned)f0) | 1u));
    { unsigned t4; double z4; if (((unsigned)(signed char)(unsigned)(((unsigned)(w0 >> 29) / (i2 | 1u)) && 4u)) & 1u) { t4 = (unsigned)((unsigned)((unsigned)c1 == (unsigned)c1) == r0.y); z4 = (double)(((0x7f1770e5u / (*q0 | 1u))) & 255u); } if (((unsigned)(signed char)(unsigned)(((unsigned)(w0 >> 29) / (i2 | 1u)) && 4u)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        if (budget != 0u) { budget -= 1u; u2 = fn0((p0 << (((unsigned)d0 - 0xda28d601u) & 31u)), ((unsigned)(x0 >> 70) + i2), (unsigned)(a0[i0 & 3u] < 0x82724bfbu)); }
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (i1 % ((unsigned)(signed char)(0x7fffffffu - ((unsigned)e0 & 0x43ae7d59u)) | 1u));
            u0 = (unsigned)((short)(unsigned)(short)(i2 * (unsigned)c1) > (signed char)(unsigned)((int)i2 >= (int)a0[u1 & 3u]));
            continue; (void)(~(unsigned)((short)i0 > (signed char)g1));
            c1 = (signed char)(unsigned)((unsigned)(x0 >> 70) || (unsigned)(signed char)(unsigned)(0x7fffffffu < (0u - i2)));
            if ((unsigned)(m0 < (*mp | p0))) break;
            for (;;) { if (--fuel == 0u) goto done;
                goto done;
                if (3u) continue;
                if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((short)0u > (signed char)(unsigned)c1) >> (u3 & 31u)), (unsigned)d0, (g1 ^ (unsigned)(unsigned char)(r0.y / (1u | 1u)))); }
                if (((unsigned)((short)0x77fc2717u > (signed char)*q0) >> ((unsigned)h1 & 31u))) break;
                while ((unsigned)((int)0xe26ef789u < (int)(unsigned)l0)) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)d0, u1, -((unsigned)((unsigned)x0 == u0) << (a0[u1 & 3u] & 31u))); }
                    u3 = ~(((unsigned)(w0 >> 29) | (unsigned)((unsigned)l0 && fuel)) + 0x2ab17c98u);
                }
                r0.x = ~(unsigned)((int)p0 >= (int)(unsigned)(signed char)(unsigned)((short)4u > (signed char)0xffffffffu));
            }
        }
        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(0x64adb6u || (unsigned)f0) || (unsigned)((int)0xffffffffu >= (int)(unsigned)b0)) & 1023u);
        if ((0x3064e3c0u - (u0 / (0xa2fae1dbu | 1u)))) goto done;
    }
    if (*mp) goto L1;
    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)((unsigned)x0 || a0[u1 & 3u]) / (0x80000000u | 1u)), (unsigned)s0, (unsigned)(0xffffffffu == a0[u1 & 3u])); }
    if (((unsigned)h1 + u0)) {
        goto L1;
        w0 ^= (unsigned long long)(unsigned)(unsigned char)(0x1a56e141u * u0) << (-(unsigned)((short)v0 > (signed char)u3) & 63u);
        while (-(i2 % (0xac237cd7u | 1u))) { if (--fuel == 0u) goto done;
            u3 ^= (unsigned)(short)(unsigned)((int)((unsigned)e0 << (a0[i0 & 3u] & 31u)) >= (int)0x80000000u);
        }
        do { if (--fuel == 0u) goto done;
            if ((fuel + u1)) break;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(unsigned)((int)(unsigned)w0 < (int)(unsigned)s0), (unsigned)d0, ((unsigned)b0 * 0x815973d5u)); }
            switch ((unsigned)(short)(0u * a0[u1 & 3u]) & 7u) {
                switch ((unsigned)(short)(((unsigned)s1 % ((unsigned)d0 | 1u)) % (m0 | 1u)) & 7u) {
                    { unsigned t5; double z5; if ((g1) & 1u) { t5 = 0x80000000u; z5 = (double)((((*q0 >> (*q0 & 31u)) / ((unsigned)f0 | 1u))) & 255u); } if ((g1) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                        if (fuel < 8u) return ~(m0 % (6u | 1u));
                        r0.y ^= (p1 * ~((unsigned)(u0 && 0x7fffffffu) ? garr[u2 & 7u] : v0));
                        goto L0;
                        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                            w0 ^= (unsigned long long)(unsigned)c1 << (((u0 & (unsigned)((int)0u >= (int)r0.y)) << (8u & 31u)) & 63u);
                            w0 ^= (unsigned long long)(8u - (unsigned)d0) << ((u2 - -(p2 << (i2 & 31u))) & 63u);
                            u2 += *mp;
                            case 0u: ;
                            if (budget != 0u) { budget -= 1u; u2 = fn0((*q0 + p2), 0u, u3); }
                            *q0 = i2;
                        }
                        case 3u: ;
                    }
                    case 6u: ;
                    if (((u2 | 0x7fffffffu) & i1)) break;
                    c0 = (unsigned char)(unsigned)((int)0x941c2806u >= (int)(i2 ^ (unsigned)f0));
                    *q0 = v0;
                    if (garr[u2 & 7u]) goto L3;
                }
                s1 = (int)((unsigned)s1 + fuel);
                if (fuel < 8u) return (0x80000000u << ((unsigned)((unsigned)(0x26233be3u == 1u) == 0x7fffffffu) & 31u));
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)(short)(unsigned)((unsigned)h0 && (unsigned)c1) < (int)(1u & a0[i0 & 3u]));
            }
            u2 = (p2 << ((unsigned)((short)(0x7fffffffu | (unsigned)b0) > (signed char)1u) & 31u));
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)0x3cc23e57u;
                break; (void)(-(unsigned)((0x10000u << (v0 & 31u)) && (unsigned)c1));
                h0 = (short)(unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)(w0 >> 29));
                b0 = (0x28d50310u << ((unsigned)(x0 >> 70) & 31u)) != 0u;
                if (u3 == 7u) return (p2 - (a0[u1 & 3u] % ((m0 ? (unsigned)w0 : *q0) | 1u)));
                u2 ^= (8u * (unsigned)(x0 >> 70));
            }
        } while (i0++ < 3u && (garr[i1 & 7u] % ((unsigned)w0 | 1u)));
        switch (((unsigned)(x0 >> 70) << (v0 & 31u)) & 7u) {
            do { if (--fuel == 0u) goto done;
                case 1u: ;
                case 6u: ;
                if (budget != 0u) { budget -= 1u; u0 = fn0(i1, 0x80000000u, (9u - (0xd2fd9b0eu + 0xffffffffu))); }
                if (fuel < 8u) return i2;
            } while (i0++ < 6u && ((unsigned)s0 * 1u));
            if (((unsigned)b0 & (0x293ec012u << ((unsigned)x0 & 31u)))) goto done;
        }
        if (u3 == 7u) return ((unsigned)b0 / ((unsigned)((0xffffffffu + (unsigned)c0) < (unsigned)(w0 >> 29)) | 1u));
    }
    q0 = &garr[((p2 / (6u | 1u)) ^ (0x9d889bdau * r0.x)) & 7u];
    if ((unsigned)b0) goto L4;
    i2 = (0x10000u & ((unsigned)(0x10000u || 0x80000000u) / (0x10000u | 1u))) & 15u;
    g1 += m0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if ((((unsigned)b0 ? p2 : 0u)) & 1u) { t0 = 5u; z0 = (double)(((unsigned)(garr[i1 & 7u] < (unsigned)(i0 < (unsigned)(x0 >> 70)))) & 255u); } if ((((unsigned)b0 ? p2 : 0u)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if ((u3 >> ((unsigned)(p1 && 0x10000u) & 31u))) goto L4;
        r0.y ^= 0x80000000u;
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)g1 >= (int)(unsigned)(signed char)((unsigned)(w0 >> 29) | (unsigned)w0)), g1, (unsigned)(i0 || (*q0 + u3))); }
        if ((unsigned)((short)(unsigned)f0 > (signed char)g0)) goto L0;
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(unsigned char)(unsigned)((int)(unsigned)s0 >= (int)0x10000u), (unsigned)(6u || u2), (unsigned)((garr[u2 & 7u] & a0[u1 & 3u]) < 0x7fffffffu)); }
        if (budget != 0u) { budget -= 1u; u0 = fn1(~(unsigned)((unsigned)w0 || (0x6b18642eu % ((unsigned)w0 | 1u))), (unsigned)(unsigned char)(0x80000000u >> ((garr[u2 & 7u] ^ 0xf94c92a7u) & 31u)), (unsigned)((int)(m0 | 0xd36cf0u) < (int)i1)); }
        if ((unsigned)(9u < (unsigned)(w0 >> 29))) break;
        if ((unsigned)((int)u1 < (int)(unsigned)h1)) {
            if (((unsigned)(0x578a1201u == i0) * (unsigned)e0)) {
                l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(unsigned)((*mp | 1u) || (unsigned)((unsigned)x0 || 0xffffffffu)));
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0(((garr[i1 & 7u] >> (0x54b43a6eu & 31u)) + (unsigned)h1), (u0 - 3u), (unsigned)((short)3u > (signed char)(unsigned)f0)); }
            { unsigned t1; double z1; if (((unsigned)((unsigned)!(i0 | u0) == (unsigned)f0)) & 1u) { t1 = ((unsigned)(w0 >> 29) ? 0x31703192u : r0.x); z1 = (double)(((unsigned)f0) & 255u); } if (((unsigned)((unsigned)!(i0 | u0) == (unsigned)f0)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    L0: if (--fuel == 0u) goto done;
                    if (u3) break;
                }
            }
        }
        f0 = f0 * 0.5f + (float)((unsigned)(short)(unsigned)(((unsigned)(unsigned char)(unsigned)(0u && u2) - (unsigned)(g1 == p2)) || (unsigned)e0) & 255u);
        garr[(u2 % (0x2e0c87f0u | 1u)) & 7u] = (unsigned)(0x80000000u == (unsigned)b0);
    }
    { unsigned t2; double z2; if (((unsigned)(0x5eb5070eu < (unsigned)e0)) & 1u) { t2 = (unsigned)(signed char)(unsigned)((short)r0.x > (signed char)i2); z2 = (double)((((unsigned)s1 & 5u)) & 255u); } if (((unsigned)(0x5eb5070eu < (unsigned)e0)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        if (g1) {
            if ((a0[u1 & 3u] % (m0 | 1u))) goto L3;
            if (a0[i0 & 3u]) goto L3;
            *mp = ((unsigned)!(*q0 ? (unsigned)x0 : i1) & i0);
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                if ((unsigned)(short)(unsigned)((unsigned)d0 || ((unsigned)b0 >> ((unsigned)c0 & 31u)))) goto L3;
                L2: if (--fuel == 0u) goto done;
                if (0u) goto done;
            }
            switch (((unsigned)w0 ? *q0 : i1) & 7u) {
                l0 = (long)((unsigned long)l0 + (((unsigned)(w0 >> 29) << (m0 & 31u)) + a0[u1 & 3u]));
            }
            r0.y ^= (unsigned)(short)((unsigned)((int)((unsigned)h1 & ((unsigned)h0 - (unsigned)c0)) >= (int)(unsigned)(w0 >> 29)) * u0);
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((0x10000u * (unsigned)(short)(p1 | g1)), r0.x, 6u); }
        m0 ^= (unsigned)s0;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)c1, ((unsigned)(x0 >> 70) >> (a0[u1 & 3u] & 31u)), (0x7fffffffu << ((unsigned)h0 & 31u))); }
    f0 = f0 * 0.5f + (float)(i0 & 255u);
    g0 = ((unsigned)(signed char)((unsigned)w0 + 0xffffffffu) - ((unsigned)e0 % ((u2 & (unsigned)f0) | 1u)));
    if (fuel < 8u) return ((unsigned)(signed char)((unsigned)h0 - (unsigned)b0) | (unsigned)((int)3u >= (int)*q0));
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((0x795c1574u * 0x4ec38efu) || g0), (garr[i1 & 7u] * garr[u2 & 7u]), 0x10000u); }
    while (i0++ < 6u && (unsigned)s1) { if (--fuel == 0u) goto done;
        { unsigned t3; double z3; if ((v0) & 1u) { t3 = g1; z3 = (double)((((unsigned)((int)0xf5dcfc89u < (int)(unsigned)(x0 >> 70)) ^ u0)) & 255u); } if ((v0) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            continue; (void)((unsigned)((unsigned)d0 == r0.x));
            g1 += (p0 >> (i0 & 31u));
            u3 += (unsigned)(garr[i1 & 7u] == (unsigned)h1);
        }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t4; double z4; if ((0xb0bd3463u) & 1u) { t4 = (unsigned)e0; z4 = (double)(((unsigned)h1) & 255u); } if ((0xb0bd3463u) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                if ((p2 >> (0xffffffffu & 31u))) break;
                h0 = (short)~(unsigned)((unsigned)e0 < (unsigned)(p2 || 0xffffffffu));
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)(unsigned)b0 < (int)(p0 % (garr[u2 & 7u] | 1u))), (0x5aa65419u - i0), (3u / (*mp | 1u))); }
                { unsigned t5; double z5; if ((((unsigned)h1 ^ 0x10000u)) & 1u) { t5 = (unsigned)((short)v0 > (signed char)garr[u2 & 7u]); z5 = (double)(((unsigned)x0) & 255u); } if ((((unsigned)h1 ^ 0x10000u)) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                    u0 = u0 * 0x9e3779b1u + (unsigned)(signed char)((unsigned)(w0 >> 29) & 0x10000u);
                    if ((garr[i1 & 7u] | 0x80000000u)) break;
                }
            }
            h1 = (unsigned short)(h1 + (p2 & 4u));
            if (-(unsigned)((int)(unsigned)!(a0[u1 & 3u] << (g0 & 31u)) < (int)0xffffffffu)) break;
            a0[(unsigned)d0 & 3u] = ((unsigned)((int)7u < (int)u3) + (unsigned)((int)*q0 >= (int)i1));
            if ((u0 & (unsigned)!(unsigned)(0x5be1cd00u == 0xbfdfddc9u))) continue;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(*q0 < 0x80000000u), (((unsigned)(w0 >> 29) & i2) % (i1 | 1u)), ((unsigned)l0 & (unsigned)s1)); }
        { unsigned t6; double z6; if (((unsigned)(signed char)(g1 >> ((unsigned)(short)(unsigned)((int)(unsigned)l0 < (int)4u) & 31u))) & 1u) { t6 = (5u ? (unsigned)(x0 >> 70) : p0); z6 = (double)(((unsigned)((int)(unsigned)((short)(unsigned)x0 > (signed char)(unsigned)(w0 >> 29)) >= (int)garr[u2 & 7u])) & 255u); } if (((unsigned)(signed char)(g1 >> ((unsigned)(short)(unsigned)((int)(unsigned)l0 < (int)4u) & 31u))) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
            if ((unsigned)((int)(unsigned)f0 < (int)*q0)) continue;
            L3: if (--fuel == 0u) goto done;
            *q0 += (u3 * ((unsigned)e0 / ((4u + i2) | 1u)));
            switch (r0.x & 7u) {
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    c1 = (signed char)(unsigned)(v0 && (p1 % ((unsigned)((short)p0 > (signed char)0x7fffffffu) | 1u)));
                    if ((g1 + (unsigned)(p0 && a0[u1 & 3u]))) break;
                    for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        c1 = (signed char)(unsigned)((short)2u > (signed char)0x8397d015u);
                    }
                    s0 = (int)(0x2d05774fu / (fuel | 1u));
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)w0, (0x8884286bu % ((p0 << (u2 & 31u)) | 1u)), ((0x10000u | (unsigned)c0) / (garr[u2 & 7u] | 1u))); }
                l0 = (long)((unsigned long)l0 + ((unsigned)s1 + (unsigned)((int)fuel < (int)((unsigned)w0 | u3))));
                d0 = d0 * 0.5 + (double)((unsigned)((short)a0[i0 & 3u] > (signed char)(a0[i0 & 3u] % ((unsigned)((unsigned)((int)g0 < (int)i0) == (unsigned)h0) | 1u))) & 1023u);
                if (((0u % (*mp | 1u)) & 3u)) {
                    v0 = ~(unsigned)(0x80000000u || (unsigned)((int)u1 < (int)(unsigned)f0));
                    if ((unsigned)((unsigned)(signed char)((unsigned)l0 / (0x20df028au | 1u)) && i2)) {
                        s1 = (int)((unsigned)s1 + (unsigned)((g0 | r0.y) == (u1 >> ((i2 & (unsigned)s1) & 31u))));
                        u0 = u0 * 0x9e3779b1u + (unsigned)((short)0xc48361c8u > (signed char)i0);
                        if ((*q0 % (u0 | 1u))) goto done;
                        w0 ^= (unsigned long long)((unsigned)b0 & garr[u2 & 7u]) << ((unsigned)((2u | (unsigned)(a0[u1 & 3u] == g1)) && 3u) & 63u);
                        v0 = 0xe9ec26acu;
                        if (budget != 0u) { budget -= 1u; u2 = fn0(0x7fffffffu, (0xffffffffu | (unsigned)(i0 && (unsigned)f0)), ((unsigned)e0 + i1)); }
                    }
                    if (p2) break;
                } else {
                    g1 += (0x9790c5e7u % ((unsigned)((a0[u1 & 3u] - p1) == a0[u1 & 3u]) | 1u));
                    case 0u: ;
                }
            }
        }
        if ((unsigned)(p0 == 1u)) goto L1;
    }
    goto L0;
    if ((unsigned)c1) goto L3;
    L4: if (--fuel == 0u) goto done;
    { unsigned t7; double z7; if ((i1) & 1u) { t7 = r0.y; z7 = (double)(((unsigned)(unsigned char)(4u - 0xa427c112u)) & 255u); } if ((i1) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
        if (m0) goto L2;
        garr[r0.y & 7u] = (unsigned)((int)u1 < (int)(5u & ((unsigned)f0 / (fuel | 1u))));
        goto L3;
        if (budget != 0u) { budget -= 1u; u1 = fn0(g1, (unsigned)(p1 && -(unsigned)((unsigned)s0 < (unsigned)h0)), (unsigned)((short)(unsigned)(signed char)(0xa3ce7053u << (5u & 31u)) > (signed char)0xdc1cbe1eu)); }
        m0 ^= (unsigned)(short)((unsigned)(w0 >> 29) << ((unsigned)(6u == 0xbd427717u) & 31u));
    }
    while (i0++ < 2u && (unsigned)c0) { if (--fuel == 0u) goto done;
        if (((unsigned)h0 - i0)) break;
        if (budget != 0u) { budget -= 1u; u3 = fn0(-(p0 << ((unsigned)h0 & 31u)), (unsigned)((unsigned)(i1 || 0x1a97372fu) == (unsigned)d0), ((unsigned)l0 + (unsigned)s1)); }
        u3 = 0u;
        q0 = &garr[(unsigned)((unsigned)c0 && i1) & 7u];
        break; (void)(((unsigned)s1 ? g1 : (unsigned)s1));
    }
    if (u3 == 7u) return (-((unsigned)d0 & (unsigned)((int)(r0.x & garr[i1 & 7u]) < (int)i1)) ^ u1);
    r0.y ^= u0;
    goto L1;
    if ((~(0x10000u | (unsigned)e0) - (unsigned)c1)) goto L0;
    switch (((unsigned)((unsigned)l0 < i0) / (v0 | 1u)) & 7u) {
        case 2u: ;
        if ((unsigned)(signed char)((u2 & 0xffffffffu) << (i1 & 31u))) {
            c1 = (signed char)(unsigned)((unsigned)!(unsigned)((unsigned)s0 == garr[u2 & 7u]) < (unsigned)c0);
            d0 = d0 * 0.5 + (double)((v0 / (garr[u2 & 7u] | 1u)) & 1023u);
            case 1u: ;
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)e0 || r0.x), (0xffffffffu - (unsigned)((unsigned)w0 || (unsigned)s0)), 4u); }
        }
        if ((((unsigned)x0 % (r0.y | 1u)) >> ((unsigned)(x0 >> 70) & 31u))) {
            g0 = ((unsigned)w0 & u2);
        } else {
            h0 = (short)(unsigned)(((unsigned)l0 | r0.y) || ((unsigned)w0 * g0));
            c1 = (signed char)-(unsigned)((short)r0.x > (signed char)(unsigned)b0);
        }
    }
    if (fuel < 8u) return (unsigned)((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)((short)(unsigned)(u1 < (unsigned)c0) > (signed char)*q0)) && (unsigned)c1);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(i1 || 4u)) continue;
        w0 = w0 * 6364136223846793005ull + ((unsigned)((unsigned)e0 < (0x88be3eb0u ^ (unsigned)(fuel || (unsigned)l0))) & 0x12f79d7eu);
        if (budget != 0u) { budget -= 1u; u1 = fn0(5u, -((unsigned)((int)(unsigned)h1 >= (int)(unsigned)c0) % (u3 | 1u)), (unsigned)(signed char)(6u % (0xec40e609u | 1u))); }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if ((fuel) & 1u) { t0 = (unsigned)h1; z0 = (double)((0xa0156d49u) & 255u); } if ((fuel) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        c0 = (unsigned char)(unsigned)(u0 < u2);
        g1 += (((unsigned)w0 | (unsigned)x0) >> ((unsigned)s0 & 31u));
        v0 = (unsigned)w0;
        l0 = (long)((unsigned long)l0 + (((unsigned)c1 + (unsigned)b0) * (0xffffffffu ^ i2)));
    }
    while (i0++ < 2u && (m0 >> (0xd36d0cc2u & 31u))) { if (--fuel == 0u) goto done;
        if (u3) {
            v0 = (unsigned)((int)(unsigned)((unsigned)(w0 >> 29) == v0) < (int)(p2 + (unsigned)h0));
            if (u0) break;
            L0: if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)((short)(unsigned)((short)(g0 * 2u) > (signed char)(unsigned)(w0 >> 29)) > (signed char)6u) < (int)(unsigned)f0));
        }
        c0 = (unsigned char)((unsigned)(x0 >> 70) ^ 0x7f6631d8u);
        L1: if (--fuel == 0u) goto done;
        *q0 = (*mp | p0);
        break; (void)((unsigned)((short)(unsigned)e0 > (signed char)u0));
    }
    s1 = (int)((unsigned)s1 + (unsigned)((int)g1 < (int)(unsigned)s1));
    q0 = &garr[((a0[i0 & 3u] >> ((u1 + (garr[i1 & 7u] | u3)) & 31u)) - u0) & 7u];
    s0 = (int)(unsigned)x0;
    L2: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u1 = fn2(~(a0[i0 & 3u] - g0), (u0 % (r0.x | 1u)), (unsigned)(short)(((unsigned)c1 >> (u0 & 31u)) | (unsigned)(w0 >> 29))); }
    for (;;) { if (--fuel == 0u) goto done;
        L3: if (--fuel == 0u) goto done;
    }
    if (((unsigned)((int)m0 < (int)0x7fffffffu) | 2u)) goto L1;
    if (budget != 0u) { budget -= 1u; u0 = fn2(0xa03fe1acu, p2, 0x7fffffffu); }
    if (budget != 0u) { budget -= 1u; u0 = fn1((i0 & (0x10000u / (u2 | 1u))), (unsigned)((short)(unsigned)(0x10000u < 0xb93a6646u) > (signed char)garr[u2 & 7u]), (unsigned)(r0.y == (unsigned)((short)0x4ebe11dcu > (signed char)0x81c6fdc2u))); }
    switch (fuel & 7u) {
        x0 = x0 * 0x100000001b3ull + (-(*mp + (0xb5091767u << (a0[i0 & 3u] & 31u))) * (unsigned)(v0 && a0[u1 & 3u]));
        *q0 = (unsigned)!(((unsigned)e0 % (p0 | 1u)) | 0x64db6068u);
        { unsigned t1; double z1; if ((7u) & 1u) { t1 = ((unsigned)c0 * 0x10000u); z1 = (double)((0u) & 255u); } if ((7u) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            v0 = (0xffffffffu << (0x12d4b856u & 31u));
            if (budget != 0u) { budget -= 1u; u3 = fn2(garr[u2 & 7u], -(5u * (unsigned)e0), (0xffffffffu << (garr[i1 & 7u] & 31u))); }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)0x54606e17u >= (int)0xffffffffu), (unsigned)((int)(unsigned)h1 >= (int)6u), (0xa85216cbu >> ((unsigned)(a0[u1 & 3u] < p1) & 31u))); }
        for (;;) { if (--fuel == 0u) goto done;
            u3 ^= p2;
            break; (void)((unsigned)((short)(unsigned)c1 > (signed char)(g0 * (unsigned)d0)));
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)(0x80000000u >> ((unsigned)h1 & 31u)), (unsigned)(p1 == r0.y), (unsigned)h0); }
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)u2 >= (int)(unsigned)s0)) {
                    continue; (void)(m0);
                    e0 = e0 * 0.5L + (long double)((0x80000000u << ((unsigned)e0 & 31u)) & 1023u);
                    x0 = x0 * 0x100000001b3ull + ((unsigned)((int)(unsigned)d0 >= (int)garr[i1 & 7u]) % (((garr[u2 & 7u] ^ a0[i0 & 3u]) >> ((unsigned)x0 & 31u)) | 1u));
                }
                if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)(0xb1c5bda5u || p1) + g0), (8u - (unsigned)((short)6u > (signed char)(unsigned)x0)), ~(0x80000000u | (unsigned)((unsigned)x0 || (unsigned)h0))); }
                case 3u: ;
                a0[(unsigned)s0 & 3u] = (unsigned)(~(5u ? (unsigned)h0 : (unsigned)l0) < 0x10000u);
                u0 ^= (unsigned)((short)(unsigned)(short)((0x3776bc81u ? 0x10000u : 0x7fffffffu) * fuel) > (signed char)0x4bff3573u);
                while ((unsigned)(unsigned char)((u0 | u1) | (unsigned)(x0 >> 70))) { if (--fuel == 0u) goto done;
                    case 6u: ;
                    e0 = e0 * 0.5L + (long double)((unsigned)(i2 || (0u % (i0 | 1u))) & 1023u);
                }
            }
            h1 = (unsigned short)(h1 + ((unsigned)((u3 / (p1 | 1u)) == (unsigned)(w0 >> 29)) >> ((unsigned)(g0 && p1) & 31u)));
            b0 = (unsigned)((0xcdf14417u | p1) < u0) != 0u;
        }
    }
    L4: if (--fuel == 0u) goto done;
    if (budget != 0u) { budget -= 1u; u1 = fn1(*mp, (0x7fffffffu ^ g1), (9u | (unsigned)l0)); }
    v0 = 0xb12effe4u;
    if (-((unsigned)d0 | (unsigned)x0)) goto done;
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)*q0 >= (int)(unsigned)((int)(0x80000000u & (unsigned)d0) < (int)0u));
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)l0, 0xd4baf923u, (1u % (0xfd966b27u | 1u))); }
    if (budget != 0u) { budget -= 1u; u2 = fn1((*mp >> ((i1 << (0x80000000u & 31u)) & 31u)), 0x956ab482u, (p0 << (garr[u2 & 7u] & 31u))); }
    goto done;
    if ((0xffffffffu >> (u3 & 31u))) {
        if (((unsigned)c0 + (unsigned)c1)) goto L2;
        c0 = (unsigned char)(unsigned)((unsigned)b0 < i0);
        if (*q0) {
            h1 = (unsigned short)(h1 + (unsigned)(short)(unsigned)((int)u1 < (int)p0));
            { unsigned t2; double z2; if ((garr[i1 & 7u]) & 1u) { t2 = ~(unsigned)((unsigned)e0 && 3u); z2 = (double)((g1) & 255u); } if ((garr[i1 & 7u]) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                if (u3) goto L3;
                f0 = f0 * 0.5f + (float)(9u & 255u);
                i0 = (unsigned)((int)(unsigned)!((unsigned)s0 / (*q0 | 1u)) >= (int)-(unsigned)((unsigned)d0 && ((unsigned)f0 % ((unsigned)l0 | 1u)))) & 15u;
                if (fuel < 8u) return (0x10000u / (g0 | 1u));
            }
            d0 = d0 * 0.5 + (double)(((0x9919ee64u - *q0) | 9u) & 1023u);
            u0 ^= -((unsigned)(0x7d320ea6u && (unsigned)b0) ? (unsigned)(6u && i2) : u3);
            w0 = w0 * 6364136223846793005ull + ((unsigned)((unsigned)f0 || i1) & (unsigned)(signed char)(unsigned)((unsigned)h1 == 1u));
            if (~(a0[u1 & 3u] % ((unsigned)d0 | 1u))) goto done;
        } else {
            if (u3 == 7u) return ((unsigned)((int)0x7c267841u >= (int)0xddecdba4u) / ((unsigned)h0 | 1u));
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1((((unsigned)w0 >> (a0[i0 & 3u] & 31u)) ^ u1), g0, (-(unsigned)((int)i0 >= (int)v0) ^ u0)); }
    } else {
        w0 ^= (unsigned long long)(0x3ddf2deeu * 8u) << ((unsigned)w0 & 63u);
    }
    *mp = (0x3367ecf2u + (unsigned)(0u && (unsigned)l0));
    w0 = w0 * 6364136223846793005ull + (*mp + (0x7fffffffu + (0xa99f4ad7u / (r0.x | 1u))));
    g1 += (p0 << ((unsigned)s1 & 31u));
    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((short)(unsigned)((unsigned)(unsigned char)(u0 >> (v0 & 31u)) == (unsigned)s0) > (signed char)(unsigned)(x0 >> 70)) && (unsigned)d0));
    v0 = (unsigned)!(unsigned)(0x99e3eb63u == (unsigned)((short)2u > (signed char)(unsigned)((short)m0 > (signed char)(u0 / (u2 | 1u)))));
    if ((1u * 0x10000u)) {
        if (a0[u1 & 3u]) goto L0;
    }
    for (;;) { if (--fuel == 0u) goto done;
        goto done;
    }
    u1 += (fuel * (unsigned)w0);
    m0 ^= (unsigned)((g0 | u2) < (0x8cd0a869u - r0.y));
    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)s0 == (unsigned)d0), (unsigned)w0, ~((unsigned)h0 | 0xaee917d6u)); }
    u3 = ((unsigned)(u1 < (unsigned)h0) ? 0x126fb5d6u : g1);
    if ((unsigned)((int)0xda1bf2cbu < (int)0x7fffffffu)) {
        if (u3 == 7u) return (unsigned)(((unsigned)d0 ? (unsigned)s1 : (unsigned)h1) < (unsigned)f0);
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            i0 = (m0 * (0x6d333d44u * p1)) & 15u;
            if ((unsigned)(x0 >> 70)) goto L1;
            w0 = w0 * 6364136223846793005ull + (p2 / ((unsigned)((int)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)r0.x) < (int)garr[u2 & 7u]) | 1u));
            goto L0;
            v0 = (unsigned)((i0 - 0x80000000u) == 7u);
        }
    }
    goto L4;
    s0 = (int)0xd12138cfu;
    w0 = w0 * 6364136223846793005ull + -((unsigned)((2u / (i1 | 1u)) || 0xffffffffu) / ((*q0 + 6u) | 1u));
    i2 = *mp & 15u;
    if ((unsigned)(unsigned char)(unsigned)(garr[i1 & 7u] == 8u)) {
        if ((unsigned)((short)g1 > (signed char)((unsigned)s1 | 0xaafb294au))) goto L3;
        e0 = e0 * 0.5L + (long double)(((unsigned)((int)0x974b1a8au < (int)0xffffffffu) | r0.y) & 1023u);
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        continue; (void)(((unsigned)(w0 >> 29) / (m0 | 1u)));
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.y ^= (-(unsigned)(0xb4e7d512u < (unsigned)(u0 == (unsigned)!((unsigned)h0 | 0xf27a25ccu))) / (p0 | 1u));
        }
        while (i1++ < 4u && (0xcd167739u & (unsigned)!((unsigned)f0 * (unsigned)c0))) { if (--fuel == 0u) goto done;
            if ((unsigned)e0) goto L4;
            c1 = (signed char)(unsigned)((int)(unsigned)((short)(p2 - m0) > (signed char)u1) < (int)((unsigned)h0 >> ((unsigned)(x0 >> 70) & 31u)));
            if (budget != 0u) { budget -= 1u; u0 = fn2(((r0.y | 0xdefe6ce8u) * 0xf305be5bu), (garr[i1 & 7u] * a0[u1 & 3u]), (g0 << ((unsigned)((unsigned)h0 || 0x89634bb1u) & 31u))); }
        }
        break; (void)((unsigned)(0x464987bcu || 0xffffffffu));
    }
    *q0 += (unsigned)(0x7fffffffu && g0);
    if ((p0 ^ (unsigned)w0)) goto done;
    if ((((unsigned)c1 * (unsigned)w0) | 0xef0aaf90u)) goto L4;
    r0.y ^= (unsigned)b0;
    if (u3) goto done;
    w0 = w0 * 6364136223846793005ull + ((unsigned)(2u && (unsigned)x0) % (0xffffffffu | 1u));
    if (r0.x) {
        w0 = w0 * 6364136223846793005ull + (unsigned)(short)(0x7fffffffu / ((0x35551bceu & (unsigned)h0) | 1u));
        if (((unsigned)s0 >> ((unsigned)c1 & 31u))) {
            goto L3;
            if ((unsigned)((int)p0 >= (int)0x7fffffffu)) goto L3;
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)((short)(unsigned)x0 > (signed char)r0.y) / (u2 | 1u))) break;
            }
        }
        w0 ^= (unsigned long long)(unsigned)e0 << ((unsigned)((short)9u > (signed char)((unsigned)(unsigned char)(0x91865b5bu >> ((unsigned)b0 & 31u)) % ((unsigned)(u3 < 0x80000000u) | 1u))) & 63u);
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)((int)0x8ff16634u < (int)(unsigned)((unsigned)b0 || (unsigned)((short)0x80000000u > (signed char)m0))));
            { unsigned t3; double z3; if (((unsigned)(short)(unsigned)((unsigned)!(unsigned)((int)(unsigned)e0 >= (int)(unsigned)x0) == (unsigned)l0)) & 1u) { t3 = p0; z3 = (double)((((p2 - (unsigned)e0) & (unsigned)e0)) & 255u); } if (((unsigned)(short)(unsigned)((unsigned)!(unsigned)((int)(unsigned)e0 >= (int)(unsigned)x0) == (unsigned)l0)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                r0.y ^= (unsigned)(unsigned char)(unsigned)(((unsigned)((unsigned)(x0 >> 70) < u1) & r0.y) || (0x518c573cu << ((unsigned)l0 & 31u)));
                if ((0x7fffffffu | 0xa8d36a90u)) continue;
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    m0 ^= ((unsigned)(signed char)(unsigned)(a0[u1 & 3u] || u2) + (5u / ((unsigned)c1 | 1u)));
                }
            }
            if ((0x7fffffffu << (u3 & 31u))) goto L0;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    h0 = (short)(unsigned)((unsigned)(signed char)((unsigned)h1 & 1u) || (unsigned)h0);
                    *q0 = (unsigned)((int)v0 >= (int)0xec9052b9u);
                    if (fuel < 8u) return (unsigned)((int)((unsigned)h0 / (0x80000000u | 1u)) < (int)((unsigned)l0 | a0[i0 & 3u]));
                    if ((unsigned)f0) break;
                    i0 = (unsigned)(unsigned char)((unsigned)!(unsigned)(((unsigned)d0 >> (v0 & 31u)) || u0) | (0x80000000u & (unsigned)h0)) & 15u;
                }
            }
        }
    }
    switch (0xffffffffu & 7u) {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            continue; (void)(7u);
            if (((0xffffffffu - u1) >> (garr[i1 & 7u] & 31u))) {
                *mp = fuel;
                i0 = (7u ? 0x10000u : ((unsigned)h1 % (0x7fffffffu | 1u))) & 15u;
            }
            case 7u: ;
            do { if (--fuel == 0u) goto done;
                break; (void)(0x2bb2cd78u);
                *q0 += 9u;
                if (fuel < 8u) return (unsigned)((unsigned)(signed char)(unsigned)((short)(unsigned)(unsigned char)(g1 * m0) > (signed char)garr[i1 & 7u]) < u3);
                case 2u: ;
            } while (i1++ < 6u && (unsigned)w0);
        }
        d0 = d0 * 0.5 + (double)((p2 + (unsigned)(unsigned char)(unsigned)((unsigned)(0xffffffffu || 7u) && (unsigned)l0)) & 1023u);
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            default: ;
        }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t4; double z4; if (((unsigned)(unsigned char)(v0 + (unsigned)x0)) & 1u) { t4 = ((unsigned)(unsigned char)(unsigned)((short)(unsigned)d0 > (signed char)i0) >> ((unsigned)l0 & 31u)); z4 = (double)(((unsigned)((short)0x80000000u > (signed char)(unsigned)(g1 && r0.y))) & 255u); } if (((unsigned)(unsigned char)(v0 + (unsigned)x0)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                case 1u: ;
                if (((unsigned)e0 >> ((0xffffffffu - g0) & 31u))) goto L4;
                u1 = u1 * 0x9e3779b1u + (0xd093e767u ? ((unsigned)(w0 >> 29) % (u3 | 1u)) : (unsigned)h0);
            }
            f0 = f0 * 0.5f + (float)((unsigned)c0 & 255u);
        }
    }
    f0 = f0 * 0.5f + (float)((unsigned)!((unsigned)((p2 - p1) < (unsigned)s1) + 0x7fffffffu) & 255u);
    r0.x = (unsigned)((unsigned)s0 && (unsigned)((unsigned)w0 == (0x80000000u >> ((unsigned)b0 & 31u))));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch ((2u / (garr[i1 & 7u] | 1u)) & 7u) {
        goto L3;
        if (0x7fffffffu) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((1u - (unsigned)(short)(u2 - g0)), (unsigned)!(unsigned)(0x10000u == r0.x), (unsigned)c1); }
            r0.y ^= (unsigned)((short)(unsigned)((short)7u > (signed char)(unsigned)h0) > (signed char)(unsigned)h0);
            garr[(a0[i0 & 3u] + u1) & 7u] = 1u;
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn3((v0 - (7u * (unsigned)h1)), ((p0 + r0.x) + 0x80000000u), ((unsigned)b0 >> (-(7u << ((unsigned)(x0 >> 70) & 31u)) & 31u))); }
            } while (i0++ < 4u && (unsigned)(r0.x == (0xaac722ccu / (9u | 1u))));
        } else {
            a0[(garr[u2 & 7u] ^ 0x2591d550u) & 3u] = (unsigned)(0x595e412u == (unsigned)(-(unsigned)((int)(unsigned)(w0 >> 29) < (int)2u) && (unsigned)h0));
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((short)i0 > (signed char)0u), (unsigned)((int)(unsigned)e0 >= (int)(unsigned)(x0 >> 70)), (unsigned)!(0x7fffffffu + m0)); }
        }
        { unsigned t0; double z0; if ((((unsigned)c1 & ((unsigned)h0 | 0x10000u))) & 1u) { t0 = ((unsigned)c1 & ((unsigned)(x0 >> 70) / (6u | 1u))); z0 = (double)(((unsigned)(u0 && ~(unsigned)((int)r0.y >= (int)0x1d70e022u))) & 255u); } if ((((unsigned)c1 & ((unsigned)h0 | 0x10000u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            while (i0++ < 3u && (i1 >> (((unsigned)s0 >> (i1 & 31u)) & 31u))) { if (--fuel == 0u) goto done;
                if ((unsigned)(u0 < (unsigned)e0)) break;
                while (i1++ < 6u && v0) { if (--fuel == 0u) goto done;
                    u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)((short)0xffffffffu > (signed char)0x10000u) < 0xa4f4f935u);
                }
                break; (void)(*q0);
                *q0 += 8u;
            }
            b0 = (unsigned)((unsigned)((int)(unsigned)(m0 || r0.y) >= (int)a0[i0 & 3u]) < 0x80000000u) != 0u;
        }
        case 2u: ;
        w0 = w0 * 6364136223846793005ull + ((unsigned)x0 % ((0x7023901cu | (2u * (9u / (p1 | 1u)))) | 1u));
    }
    if (((unsigned)f0 ? (unsigned)s0 : 0xc99d7a9au)) {
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)h0 || garr[i1 & 7u]);
            u2 = -((a0[u1 & 3u] * 1u) + (unsigned)(p2 == (unsigned)f0));
            if (u2) break;
            if ((m0 - v0)) break;
        }
    } else {
        r0.x = (0x10000u / ((unsigned)((unsigned)b0 && garr[u2 & 7u]) | 1u));
        do { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)(((((u2 % (0x1f823828u | 1u)) << (m0 & 31u)) / ((unsigned)x0 | 1u)) & i2) & 1023u);
                }
                L0: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn3(0u, (r0.x | 6u), (unsigned)f0); }
                c0 = (unsigned char)2u;
            }
            if (p0) {
                L1: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn3((((unsigned)l0 % ((unsigned)d0 | 1u)) * (unsigned)(x0 >> 70)), a0[i0 & 3u], (0x10000u * (unsigned)c1)); }
            }
            *q0 = 0x80000000u;
            if (budget != 0u) { budget -= 1u; u3 = fn3(p1, (unsigned)((short)(m0 | a0[u1 & 3u]) > (signed char)p1), 0x80000000u); }
            goto L0;
            if ((0xffffffffu << (0x87e2082eu & 31u))) break;
        } while (i0++ < 6u && (unsigned)c0);
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            u2 += (unsigned)((unsigned)((short)(unsigned)e0 > (signed char)u0) || ((unsigned)((short)(unsigned)s1 > (signed char)*q0) + (unsigned)(x0 >> 70)));
            v0 = (0xffffffffu % ((unsigned)(x0 >> 70) | 1u));
            goto L4;
        }
        while (i0++ < 5u && ((v0 + p2) << (2u & 31u))) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((r0.x + (unsigned)(unsigned char)(unsigned)(r0.y == (fuel * i0))) & 1023u);
            if (0x7fffffffu) {
                m0 ^= ((*q0 / (fuel | 1u)) << ((unsigned)f0 & 31u));
                while (i1++ < 2u && ((unsigned)(x0 >> 70) | p1)) { if (--fuel == 0u) goto done;
                    a0[p1 & 3u] = (unsigned)(unsigned char)(unsigned)((int)(unsigned)f0 < (int)(a0[i0 & 3u] | (unsigned)f0));
                    if ((0x90df8fe1u % ((unsigned)(0x3af1552au && 8u) | 1u))) continue;
                }
                c0 = (unsigned char)i2;
                if ((unsigned)!(unsigned)(p1 || v0)) continue;
            }
        }
    }
    s0 = (int)((unsigned)d0 - ((unsigned)h1 / (0xb27e6383u | 1u)));
    if (0x80000000u) {
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(p1 || 0x77e8f3d2u), ((unsigned)s1 - i2), r0.x); }
            do { if (--fuel == 0u) goto done;
                r0.x = 0xb606794au;
                if (0x7fffffffu) break;
                break; (void)((unsigned)((int)(unsigned)l0 < (int)fuel));
                g1 += 0x10000u;
                *q0 += -((u2 & *q0) - (unsigned)((unsigned)c1 == (unsigned)d0));
            } while (i1++ < 2u && 9u);
            if ((unsigned)(garr[u2 & 7u] == (unsigned)s0)) goto L1;
        } while (i0++ < 3u && (0xffffffffu * *mp));
    }
    c1 = (signed char)9u;
    u2 = ((unsigned)l0 / ((i2 / (i2 | 1u)) | 1u));
    if (budget != 0u) { budget -= 1u; u3 = fn1((0x10000u >> ((unsigned)f0 & 31u)), 0xffffffffu, ((unsigned)(0x7fffffffu < (unsigned)c1) & g1)); }
    w0 = w0 * 6364136223846793005ull + 0xc415cb38u;
    l0 = (long)((unsigned long)l0 + (unsigned)(short)(0x80000000u ? 0x7fffffffu : ((unsigned)c1 ? 0xa5b6375au : (unsigned)e0)));
    w0 = w0 * 6364136223846793005ull + (unsigned)((short)garr[i1 & 7u] > (signed char)i1);
    if ((unsigned)(g0 || (unsigned)c1)) {
        for (;;) { if (--fuel == 0u) goto done;
            v0 = (unsigned)((unsigned)!(unsigned)((short)r0.y > (signed char)(unsigned)s0) == -(0x10000u | *q0));
            L2: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn2(((0x10000u * p2) / (g1 | 1u)), ((i1 / ((unsigned)l0 | 1u)) - 4u), (((unsigned)h1 ^ (unsigned)d0) | (unsigned)h1)); }
            x0 = x0 * 0x100000001b3ull + (unsigned)(*q0 < (unsigned)(signed char)((a0[i0 & 3u] >> ((unsigned)((unsigned)w0 == 0xffffffffu) & 31u)) & (unsigned)b0));
            if (u3 == 7u) return (unsigned)((int)0u < (int)(unsigned)(w0 >> 29));
            continue; (void)(m0);
        }
        switch ((unsigned)(short)(unsigned)((unsigned)e0 < a0[u1 & 3u]) & 7u) {
            f0 = f0 * 0.5f + (float)((*q0 + ((unsigned)s1 ^ (unsigned)((int)(unsigned)(short)((unsigned)x0 & (unsigned)l0) >= (int)(unsigned)h1))) & 255u);
            if (budget != 0u) { budget -= 1u; u0 = fn1((fuel >> ((unsigned)((short)(unsigned)s1 > (signed char)0x7d8c7a8fu) & 31u)), ((unsigned)w0 << ((0x80000000u | garr[u2 & 7u]) & 31u)), (unsigned)(signed char)(u0 | (v0 & (unsigned)l0))); }
            if (((unsigned)((int)m0 >= (int)garr[u2 & 7u]) << (9u & 31u))) goto L1;
        }
    }
    if (0x539e1fecu) goto L3;
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)(unsigned)h0 < (int)v0), v0, (unsigned)(0xeed96cb0u == (unsigned)((short)0xf844d4dfu > (signed char)1u))); }
    r0.x = (u0 & (unsigned)(u2 && 0x80aff17cu));
    { unsigned t1; double z1; if (((unsigned)((short)0x85b5ba4au > (signed char)(unsigned)f0)) & 1u) { t1 = ((unsigned)b0 | 0xc56f5d6u); z1 = (double)(((unsigned)((int)m0 >= (int)a0[u1 & 3u])) & 255u); } if (((unsigned)((short)0x85b5ba4au > (signed char)(unsigned)f0)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)!(3u >> ((unsigned)h0 & 31u)), (unsigned)h0, (unsigned)((int)(unsigned)(0x7fffffffu || u1) >= (int)fuel)); }
    }
    s1 = (int)((unsigned)s1 + (unsigned)((unsigned)w0 == 8u));
    u2 = u2 * 0x9e3779b1u + 0xc3a8b14au;
    *q0 = ~((unsigned)(0x80000000u && i1) % (0x10000u | 1u));
    u2 ^= (unsigned)(short)(unsigned)(r0.y < (a0[i0 & 3u] - (p0 ? 0x930b5619u : fuel)));
    h1 = (unsigned short)(h1 + ((unsigned)(x0 >> 70) | -(unsigned)(0x7fffffffu && (3u / (u1 | 1u)))));
    switch (r0.y & 7u) {
        L3: if (--fuel == 0u) goto done;
        b0 = u3 != 0u;
        g1 += (((0x10000u % ((unsigned)c0 | 1u)) * (i1 | (unsigned)f0)) % ((unsigned)s0 | 1u));
        switch (i0 & 7u) {
            L4: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)0u < (int)(unsigned)l0), ((unsigned)h1 << (0x10000u & 31u)), (unsigned)((int)0x80000000u >= (int)(unsigned)h1)); }
            case 4u: ;
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 0u, 0xe340977bu, 0xbdff5dfeu },
        { 7u, 0xc36f8e2bu, 0x88e01137u },
        { 0u, 0xa3f71dfeu, 0xb69934b6u },
        { 12u, 0xe06daa7au, 0xe419a6b0u },
        { 15u, 0x63a47ef9u, 0xaa8eb1cfu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
