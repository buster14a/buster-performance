// test-ssa-source's program of seed 141000440 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x615e7a82u, g1 = 0x4340dbf4u;
static unsigned garr[8] = { 0xf4900da9u, 0x4e3474ebu, 0x86e7ed2au, 0x1d3a7923u, 0xa7e55db3u, 0x51885068u, 0xb46239e0u, 0x6abbebb1u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    r0.y ^= (((unsigned)(0x80000000u || p0) << (0xffffffffu & 31u)) >> (u0 & 31u));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0xffffffffu) goto L2;
        if ((unsigned)(u0 || (unsigned)(p0 == u0))) break;
        h0 = (short)-(r0.x ? u2 : (unsigned)(0x3b9857f7u < p1));
        L0: if (--fuel == 0u) goto done;
    }
    *q0 += 7u;
    u1 = u1 * 0x9e3779b1u + (((unsigned)(x0 >> 70) % (u3 | 1u)) & (unsigned)(short)(g1 % ((unsigned)(short)(unsigned)(i1 < (unsigned)c0) | 1u)));
    switch (0x10000u & 7u) {
        if (((unsigned)s0 >> (-(garr[u2 & 7u] ^ a0[u1 & 3u]) & 31u))) break;
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            *mp = (unsigned)((int)(6u ^ (r0.x | i2)) >= (int)(garr[u2 & 7u] % ((unsigned)d0 | 1u)));
            if (-(4u >> (p0 & 31u))) goto done;
            g1 += (unsigned)((unsigned)(0x7fffffffu < (unsigned)(w0 >> 29)) && ((unsigned)h0 ^ (unsigned)e0));
            a0[(unsigned)((int)(unsigned)w0 < (int)p0) & 3u] = (unsigned)h1;
            u2 = u2 * 0x9e3779b1u + (p2 / (0x10000u | 1u));
            b0 = (((u1 ? i1 : 0x7fffffffu) * m0) << (0x5236c9c8u & 31u)) != 0u;
        }
        if ((unsigned)h1) goto L4;
    }
    { unsigned t0; double z0; if (((r0.y % (i2 | 1u))) & 1u) { t0 = (unsigned)(5u && garr[i1 & 7u]); z0 = (double)(((u2 ^ (unsigned)((int)(unsigned)s0 >= (int)7u))) & 255u); } if (((r0.y % (i2 | 1u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        w0 ^= (unsigned long long)0xa4cc4422u << ((g0 | r0.x) & 63u);
        if ((i1 * 0x332685fu)) goto L3;
        L1: if (--fuel == 0u) goto done;
        garr[0x80000000u & 7u] = (unsigned)((short)i0 > (signed char)((unsigned)((short)garr[i1 & 7u] > (signed char)i0) % (3u | 1u)));
        if (u0) goto L3;
    }
    if ((unsigned)l0) {
        if ((unsigned)w0) {
            L2: if (--fuel == 0u) goto done;
            u1 = (unsigned)((unsigned)(v0 && (unsigned)c1) < ((unsigned)h0 * (unsigned)s0));
        } else {
            do { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (fuel * u2));
                m0 ^= (p1 * (u1 >> ((unsigned)((short)0x8804ea2bu > (signed char)0x80000000u) & 31u)));
            } while (i0++ < 5u && ~(unsigned)((int)0x306800ebu < (int)0x80000000u));
            while (*q0) { if (--fuel == 0u) goto done;
                u0 = ((unsigned)h0 ^ ((6u - 6u) | 0x7fffffffu));
                f0 = f0 * 0.5f + (float)((unsigned)(short)(i1 - 0x3f0878e8u) & 255u);
                u1 = (r0.x ^ (u0 ? (unsigned)c1 : 0x819d3fc3u));
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    v0 = (unsigned)((int)(unsigned)((fuel + *q0) == v0) < (int)*q0);
                    e0 = e0 * 0.5L + (long double)((unsigned)((0x10000u / ((unsigned)(x0 >> 70) | 1u)) == (unsigned)((short)(p0 ^ m0) > (signed char)p2)) & 1023u);
                    switch (8u & 7u) {
                        if ((0x80000000u / ((p1 - (unsigned)f0) | 1u))) break;
                        if ((unsigned)(signed char)(0u / ((unsigned)(w0 >> 29) | 1u))) break;
                        L3: if (--fuel == 0u) goto done;
                        case 7u: ;
                    }
                    u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)b0 < ((unsigned)!(0xa642a52u & 0xabeb2fc1u) / (0x75fd3705u | 1u)));
                    break; (void)((unsigned)((unsigned)f0 || r0.y));
                    h0 = (short)((unsigned)h0 << (((i1 ^ (unsigned)h1) | (unsigned)(*q0 < g0)) & 31u));
                }
                if ((unsigned)((int)(unsigned)h0 < (int)(p0 + p0))) {
                    do { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)2u >= (int)(unsigned)d0));
                        r0.x = ((unsigned)b0 + 3u);
                        if (((unsigned)(v0 < p0) & *mp)) break;
                        if ((unsigned)l0) break;
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)(i1 == *mp) | a0[u1 & 3u]) >= (int)*mp));
                        for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                            if (u3 == 7u) return ((u1 % ((unsigned)!((unsigned)((unsigned)x0 == (unsigned)(w0 >> 29)) >> (9u & 31u)) | 1u)) << ((unsigned)l0 & 31u));
                            if ((unsigned)!((unsigned)c1 & 0x10000u)) goto L3;
                            r0.x = (0x13911c27u + 0x10000u);
                            L4: if (--fuel == 0u) goto done;
                        }
                    } while (i1++ < 5u && (u2 >> (0xc03f0b4eu & 31u)));
                    break; (void)((unsigned)h0);
                }
            }
            if (5u) goto L4;
            goto L3;
        }
    } else {
        if ((unsigned)(5u < 9u)) goto L3;
        { unsigned t1; double z1; if ((((unsigned)d0 + 0x10000u)) & 1u) { t1 = (unsigned)((int)g0 < (int)a0[u1 & 3u]); z1 = (double)(((unsigned)(g1 < p2)) & 255u); } if ((((unsigned)d0 + 0x10000u)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            if ((0x87a1b305u - 0x7fffffffu)) {
                s0 = (int)((unsigned)(signed char)(((unsigned)h0 & 0x228105ccu) >> (((unsigned)e0 % ((unsigned)e0 | 1u)) & 31u)) | (unsigned)c1);
                u1 ^= a0[i0 & 3u];
                if ((((unsigned)c1 & 0x10000u) % (p0 | 1u))) goto done;
            } else {
                u1 = u1 * 0x9e3779b1u + (unsigned)((int)(unsigned)c1 >= (int)0x10000u);
                c0 = (unsigned char)(unsigned)f0;
            }
            goto L0;
        }
        switch (p2 & 7u) {
            s1 = (int)((unsigned)s1 + (p0 + (unsigned)c1));
        }
    }
    if ((unsigned)((int)(unsigned)(5u < 2u) >= (int)i2)) goto L0;
    if (0x80000000u) goto L3;
    if (((garr[i1 & 7u] + i1) ^ u2)) goto done;
    if (((unsigned)x0 - (m0 ^ (unsigned)e0))) goto L3;
    { unsigned t2; double z2; if ((p1) & 1u) { t2 = -(u0 | (unsigned)s0); z2 = (double)(((*q0 - ((unsigned)e0 * 0x64337905u))) & 255u); } if ((p1) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        { unsigned t3; double z3; if (((2u + (unsigned)s1)) & 1u) { t3 = (unsigned)(garr[i1 & 7u] < (unsigned)c1); z3 = (double)(((unsigned)(8u == p2)) & 255u); } if (((2u + (unsigned)s1)) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            d0 = d0 * 0.5 + (double)(6u & 1023u);
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)(w0 >> 29) && (unsigned)(signed char)((unsigned)l0 >> ((unsigned)f0 & 31u)))) break;
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (*q0) break;
                break; (void)(((unsigned)((unsigned)h1 || (unsigned)c1) + u1));
                if ((unsigned)f0) {
                    w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)((unsigned)((int)(0x3d7bcc98u % (p1 | 1u)) < (int)0xffffffffu) % (((unsigned)f0 * u3) | 1u));
                    u3 += (unsigned)(u1 && (unsigned)(0x7fffffffu < u3));
                    if (u1) break;
                    u1 = u1 * 0x9e3779b1u + (unsigned)x0;
                    if ((((unsigned)s1 & 0xffffffffu) / (2u | 1u))) break;
                }
            }
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (r0.y ? 0x721afbafu : (unsigned)(g1 || (unsigned)((int)(unsigned)h1 < (int)g0)));
            }
            x0 = x0 * 0x100000001b3ull + 0x80000000u;
            d0 = d0 * 0.5 + (double)((unsigned)((r0.y + (unsigned)(0x7fffffffu || m0)) && fuel) & 1023u);
        }
        *q0 = u0;
        v0 = (((0x80000000u ^ a0[u1 & 3u]) * i1) * u3);
    }
    goto L0;
    if ((unsigned)(0xffffffffu && a0[u1 & 3u])) {
        g0 = r0.x;
        goto L3;
        m0 ^= ((p2 << (u0 & 31u)) & p1);
        goto L0;
        if (garr[i1 & 7u]) goto L3;
    }
    *q0 += ((unsigned)(x0 >> 70) * (unsigned)l0);
    if (8u) goto L2;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = (unsigned)s1;
    }
    g0 = (0xffffffffu ? (unsigned)((unsigned)c1 && 0x10000u) : i1);
    if ((u0 << (fuel & 31u))) goto done;
    s0 = (int)(0x10000u >> ((unsigned)(short)(unsigned)((short)u2 > (signed char)(garr[u2 & 7u] << (0x3de1791u & 31u))) & 31u));
    while (i0++ < 2u && (5u >> (fuel & 31u))) { if (--fuel == 0u) goto done;
        if (((unsigned)w0 * 2u)) break;
        goto L0;
        break; (void)((a0[u1 & 3u] % (u1 | 1u)));
    }
    e0 = e0 * 0.5L + (long double)((((unsigned)((short)r0.x > (signed char)r0.x) ^ 6u) << (p0 & 31u)) & 1023u);
    x0 = x0 * 0x100000001b3ull + ((unsigned)(-(unsigned)((unsigned)s0 || p1) < garr[u2 & 7u]) - (0x80000000u / (0xffffffffu | 1u)));
    switch (p0 & 7u) {
        while (i0++ < 6u && (9u * 4u)) { if (--fuel == 0u) goto done;
            case 6u: ;
            { unsigned t4; double z4; if (((unsigned)((int)p0 >= (int)(unsigned)s0)) & 1u) { t4 = (unsigned)b0; z4 = (double)((u0) & 255u); } if (((unsigned)((int)p0 >= (int)(unsigned)s0)) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                g0 = (((unsigned)w0 * (unsigned)e0) + (unsigned)d0);
                case 7u: ;
                break; (void)(((unsigned)f0 + g0));
                h1 = (unsigned short)(h1 + ((unsigned)(x0 >> 70) * (fuel >> (g0 & 31u))));
                if ((unsigned)(unsigned char)((unsigned)(garr[i1 & 7u] || (unsigned)e0) - (unsigned)c0)) break;
                case 3u: ;
            }
            i0 = i2 & 15u;
        }
        f0 = f0 * 0.5f + (float)(8u & 255u);
        c0 = (unsigned char)((unsigned)f0 | m0);
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 7u && (unsigned)h1) { if (--fuel == 0u) goto done;
                case 2u: ;
                l0 = (long)((unsigned long)l0 + (unsigned)((int)(*q0 ^ (unsigned)b0) >= (int)(unsigned)(-(p0 | (unsigned)h0) == p1)));
                g1 += ((unsigned)((int)((unsigned)f0 * (unsigned)(x0 >> 70)) >= (int)6u) * p0);
                if ((unsigned)l0) break;
                u3 += ((p1 + (unsigned)d0) & (unsigned)(w0 >> 29));
                h1 = (unsigned short)(h1 + ((g0 - a0[u1 & 3u]) + 0u));
            }
            case 0u: ;
            while (i1++ < 5u && 0xffffffffu) { if (--fuel == 0u) goto done;
                q0 = &garr[((unsigned)(x0 >> 70) * (unsigned)l0) & 7u];
                case 5u: ;
                default: ;
            }
            { unsigned t5; double z5; if ((p0) & 1u) { t5 = -(0x10000u << (u1 & 31u)); z5 = (double)(((1u % (u1 | 1u))) & 255u); } if ((p0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)!(unsigned)(i0 && (unsigned)(0x67f2f68eu == (0xe0670d81u - 0xffffffffu)));
                    if (u3 == 7u) return (unsigned)l0;
                    if ((unsigned)(0x44acdb97u && (3u << ((unsigned)d0 & 31u)))) {
                        if (((unsigned)h1 << ((unsigned)b0 & 31u))) break;
                        if ((p2 ^ (unsigned)l0)) break;
                        break;
                        break;
                        if ((u1 & 0x8fd8ad96u)) goto L4;
                        do { if (--fuel == 0u) goto done;
                            b0 = (0x5b3609b1u >> ((0x7fffffffu * r0.y) & 31u)) != 0u;
                            if (((unsigned)(w0 >> 29) % (u3 | 1u))) continue;
                            break;
                        } while (i2++ < 7u && 2u);
                    }
                    break;
                    break;
                }
                { unsigned t6; double z6; if ((i0) & 1u) { t6 = ((unsigned)(u3 || (unsigned)c1) * garr[u2 & 7u]); z6 = (double)((3u) & 255u); } if ((i0) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                    break;
                    h0 = (short)(unsigned)((short)(unsigned)((int)((unsigned)s1 + v0) < (int)(0x190c0e85u ^ 5u)) > (signed char)1u);
                    x0 = x0 * 0x100000001b3ull + (unsigned)((i0 & 3u) || (0xffffffffu & (g1 / (*q0 | 1u))));
                    if (a0[i0 & 3u]) goto L3;
                    u2 = u2 * 0x9e3779b1u + u3;
                }
                c1 = (signed char)(*mp % (0xdbf11ebeu | 1u));
            }
            i0 = ((*mp & u2) & ((unsigned)((short)0x7fffffffu > (signed char)3u) / ((unsigned)c1 | 1u))) & 15u;
        }
    }
    if ((r0.x ^ (0x80000000u / ((unsigned)h1 | 1u)))) {
        if (~(fuel * (0x10000u % (u0 | 1u)))) goto L1;
        if ((unsigned)((unsigned)c1 < (unsigned)c0)) goto done;
        u2 = ((unsigned)h1 << ((unsigned)(0u && 7u) & 31u));
    }
    goto done;
    if (u3 == 7u) return ((unsigned)!(r0.y & *mp) ^ (unsigned)((int)(p2 << ((unsigned)c0 & 31u)) < (int)0x100fd881u));
    do { if (--fuel == 0u) goto done;
        if ((unsigned)c0) break;
        while (-((unsigned)e0 & ((unsigned)e0 / (p0 | 1u)))) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + ((unsigned)w0 ^ (unsigned)(w0 >> 29));
            if ((p1 | (*q0 - p1))) {
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)s0) {
                        if (fuel) break;
                        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                            i2 = ((unsigned)f0 - i0) & 15u;
                        }
                        c0 = (unsigned char)(unsigned)((int)0x34f90d6eu >= (int)p2);
                        break; (void)((unsigned)(signed char)(garr[i1 & 7u] - (unsigned)((short)(unsigned)d0 > (signed char)a0[i0 & 3u])));
                    }
                    if (1u) break;
                    switch ((unsigned)(unsigned char)(i2 | v0) & 7u) {
                        *q0 += (6u ? ((unsigned)h1 - (unsigned)e0) : i1);
                        s1 = (int)((unsigned)s1 + g0);
                    }
                    if ((unsigned)b0) break;
                    v0 = (unsigned)((0x49b6d1c8u ? (unsigned)(w0 >> 29) : 0x7fffffffu) && (u3 / ((unsigned)w0 | 1u)));
                } while (i2++ < 7u && (*q0 >> ((0xd96a4efau ^ i0) & 31u)));
                g1 += (9u - ((garr[i1 & 7u] ^ u3) - (unsigned)(w0 >> 29)));
            } else {
                switch (((unsigned)l0 + (unsigned)h0) & 7u) {
                    case 3u: ;
                    h1 = (unsigned short)(h1 + (i2 ? (unsigned)!(unsigned)(8u || 0x7fffffffu) : g0));
                    case 0u: ;
                    if ((unsigned)((unsigned)(*mp < u3) || (unsigned)d0)) {
                        case 4u: ;
                        h0 = (short)-(((((unsigned)b0 % (u2 | 1u)) >> (6u & 31u)) * a0[i0 & 3u]) % (0xffffffffu | 1u));
                        c1 = (signed char)((unsigned)(*mp || (unsigned)h1) | u2);
                        default: ;
                        do { if (--fuel == 0u) goto done;
                            l0 = (long)((unsigned long)l0 + (unsigned)((int)0x636408au >= (int)(p1 & ((unsigned)(x0 >> 70) | ((unsigned)d0 + u3)))));
                        } while (i2++ < 3u && (unsigned)(i0 == g1));
                    }
                    s0 = (int)(unsigned)(g1 && (unsigned)b0);
                }
                if (u2) break;
            }
            s0 = (int)((unsigned)(i0 || ((unsigned)c1 >> (8u & 31u))) << (2u & 31u));
        }
    } while (i0++ < 5u && (*q0 | p0));
    if ((unsigned)(2u && 0x47eefc4u)) goto L2;
    goto L0;
    if (p0) goto L3;
    if (u2) goto L0;
    if ((unsigned)(((unsigned)h1 + garr[i1 & 7u]) < 0xfa6cc3bu)) goto L4;
    b0 = ~((unsigned)l0 ^ (0xbbcbab88u ? (unsigned)w0 : a0[i0 & 3u])) != 0u;
    b0 = (unsigned)(2u && (unsigned)((unsigned)((short)(unsigned)c1 > (signed char)(unsigned)(x0 >> 70)) == (7u >> ((unsigned)d0 & 31u)))) != 0u;
    l0 = (long)((unsigned long)l0 + ((unsigned)(w0 >> 29) << (((unsigned)s1 << ((unsigned)((int)(unsigned)(0x80000000u || garr[i1 & 7u]) < (int)(unsigned)x0) & 31u)) & 31u)));
    { unsigned t7; double z7; if ((u3) & 1u) { t7 = 3u; z7 = (double)((((unsigned)(p1 && i1) - 0x8e74f9c9u)) & 255u); } if ((u3) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
        if ((0x8a25a302u >> ((unsigned)((short)(unsigned)x0 > (signed char)0x2437ee7fu) & 31u))) {
            { unsigned t8; double z8; if (((unsigned)((int)(unsigned)l0 >= (int)m0)) & 1u) { t8 = (unsigned)((int)0xffffffffu < (int)(unsigned)l0); z8 = (double)((i0) & 255u); } if (((unsigned)((int)(unsigned)l0 >= (int)m0)) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                if (((unsigned)b0 ^ (unsigned)(short)(unsigned)(a0[u1 & 3u] && (unsigned)d0))) goto L4;
                if (0xffffffffu) goto L1;
                goto done;
            }
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    if ((((unsigned)s0 >> (a0[u1 & 3u] & 31u)) ^ v0)) break;
                    if ((unsigned)b0) break;
                }
            }
            if ((unsigned)((int)garr[i1 & 7u] < (int)(unsigned)h0)) goto L1;
            r0.x = ((unsigned)((unsigned)x0 || 5u) - (unsigned)b0);
            { unsigned t9; double z9; if (((unsigned)b0) & 1u) { t9 = i2; z9 = (double)(((unsigned)((unsigned)c1 && (g0 & i2))) & 255u); } if (((unsigned)b0) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
                goto done;
                if (0xffffffffu) goto L3;
                r0.y ^= (*q0 % (u0 | 1u));
                { unsigned t10; double z10; if (((unsigned)(unsigned char)(unsigned)(0x7fffffffu == v0)) & 1u) { t10 = (0xffffffffu >> ((0x80000000u | 2u) & 31u)); z10 = (double)(((unsigned)((int)(unsigned)h1 < (int)0x1634ea1eu)) & 255u); } if (((unsigned)(unsigned char)(unsigned)(0x7fffffffu == v0)) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
                    if (fuel < 8u) return ((r0.y >> (g0 & 31u)) * (unsigned)((unsigned)s0 < (unsigned)e0));
                    w0 ^= (unsigned long long)(unsigned)b0 << (0xffffffffu & 63u);
                }
            }
            u1 = u1 * 0x9e3779b1u + (0x7fffffffu % (4u | 1u));
        }
        if ((unsigned)(0x7fffffffu || (unsigned)x0)) goto L0;
        *mp = (0x80000000u - i1);
        u0 ^= (unsigned)(short)((unsigned)x0 << ((unsigned)((unsigned)((short)r0.x > (signed char)p1) || u1) & 31u));
        l0 = (long)((unsigned long)l0 + (unsigned)(short)((9u << (i1 & 31u)) << (0x6d3ae937u & 31u)));
    }
    i0 = ((unsigned)b0 % ((0x37744904u * (unsigned)(0xffffffffu < 0xffffffffu)) | 1u)) & 15u;
    if (((unsigned)((int)i1 >= (int)0x10000u) ^ u2)) goto L4;
    w0 ^= (unsigned long long)0x10000u << ((m0 - (unsigned)(x0 >> 70)) & 63u);
    if ((unsigned)(0x80000000u || 0x80000000u)) goto L3;
    if (((unsigned)c0 / (p2 | 1u))) {
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (-(0x10000u ^ i1)) break;
        }
        a0[(unsigned)x0 & 3u] = ((unsigned)((int)(unsigned)e0 < (int)(g1 ^ u3)) << (r0.y & 31u));
        { unsigned t11; double z11; if ((p1) & 1u) { t11 = 0x10000u; z11 = (double)(((u1 >> (0x479fc45au & 31u))) & 255u); } if ((p1) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
            goto L0;
        }
        do { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)((int)~(u3 / ((unsigned)((unsigned)b0 == 0x80000000u) | 1u)) < (int)r0.x));
            if ((unsigned)((short)0x231d318fu > (signed char)(unsigned)((unsigned)s1 < a0[u1 & 3u]))) break;
            *q0 = (unsigned)(w0 >> 29);
            { unsigned t12; double z12; if (((unsigned)((unsigned)h1 && 0u)) & 1u) { t12 = ~(unsigned)((unsigned)((unsigned)f0 || v0) || (unsigned)x0); z12 = (double)(((~((unsigned)h1 + (unsigned)h1) & (unsigned)c0)) & 255u); } if (((unsigned)((unsigned)h1 && 0u)) & 1u) { u3 += t12; d0 = d0 * 0.5 + z12; }
                { unsigned t13; double z13; if ((~(p2 & r0.x)) & 1u) { t13 = (*q0 ? (unsigned)c0 : u1); z13 = (double)((0x7fffffffu) & 255u); } if ((~(p2 & r0.x)) & 1u) { u1 += t13; d0 = d0 * 0.5 + z13; }
                    while (i1++ < 4u && ((unsigned)d0 ^ a0[u1 & 3u])) { if (--fuel == 0u) goto done;
                        { unsigned t14; double z14; if (((3u & 0x7fffffffu)) & 1u) { t14 = (unsigned)c0; z14 = (double)(((0xffffffffu * m0)) & 255u); } if (((3u & 0x7fffffffu)) & 1u) { u3 += t14; d0 = d0 * 0.5 + z14; }
                            break; (void)((a0[u1 & 3u] / ((unsigned)e0 | 1u)));
                            if ((unsigned)h0) goto L4;
                            if ((0x7fffffffu % ((unsigned)((int)g0 >= (int)u0) | 1u))) break;
                        }
                    }
                    goto L1;
                }
                if ((unsigned)(7u && i1)) break;
                i0 = -(unsigned)(0x851a4912u || (unsigned)(0xc66c8c20u < (unsigned)s1)) & 15u;
                { unsigned t15; double z15; if ((((unsigned)f0 + (r0.y * (unsigned)e0))) & 1u) { t15 = r0.x; z15 = (double)((9u) & 255u); } if ((((unsigned)f0 + (r0.y * (unsigned)e0))) & 1u) { u1 += t15; d0 = d0 * 0.5 + z15; }
                    if (0x80000000u) continue;
                    if (fuel < 8u) return (unsigned)(0xa3fb90dfu == (unsigned)h1);
                }
                if (((unsigned)((int)0x7fffffffu < (int)0x1867c192u) & g1)) {
                    for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        u3 = ((unsigned)x0 << ((unsigned)((int)r0.x < (int)garr[i1 & 7u]) & 31u));
                    }
                    u1 = u1 * 0x9e3779b1u + (unsigned)(-(unsigned)(v0 || (unsigned)h1) == (4u | u0));
                } else {
                    if (0x5d621ee4u) break;
                }
            }
        } while (i0++ < 5u && 0u);
        if (((*q0 / (a0[u1 & 3u] | 1u)) & (unsigned)(w0 >> 29))) goto done;
    } else {
        if ((p2 * ((unsigned)f0 % (a0[u1 & 3u] | 1u)))) goto L2;
        e0 = e0 * 0.5L + (long double)((unsigned)(v0 && (unsigned)(-((unsigned)x0 >> ((u0 - 2u) & 31u)) == 0x10000u)) & 1023u);
        c1 = (signed char)((unsigned)((int)(g1 >> ((unsigned)(x0 >> 70) & 31u)) >= (int)5u) >> (((unsigned)b0 * i2) & 31u));
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)(u2 == (unsigned)b0) < (int)r0.y)) break;
            if (((unsigned)f0 - 1u)) break;
            w0 ^= (unsigned long long)-(unsigned)(m0 == 0x80000000u) << (~(0x3fd4ca19u % ((unsigned)e0 | 1u)) & 63u);
            d0 = d0 * 0.5 + (double)(g0 & 1023u);
            if (u3 == 7u) return (unsigned)(0xd4ef528bu || ((0x10000u | 0x465a7b87u) >> (((unsigned)w0 % ((unsigned)f0 | 1u)) & 31u)));
        } while (i0++ < 3u && (u0 % (i1 | 1u)));
    }
    if ((6u % ((unsigned)(i1 == (unsigned)s0) | 1u))) {
        d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)((int)u3 < (int)p0) < (int)(unsigned)((int)(unsigned)h1 < (int)(unsigned)(0u == (unsigned)(x0 >> 70)))) & 1023u);
        if (((unsigned)l0 - 4u)) goto L0;
        e0 = e0 * 0.5L + (long double)(((((unsigned)(x0 >> 70) - u3) >> ((unsigned)w0 & 31u)) | (unsigned)l0) & 1023u);
        goto L2;
        if (((unsigned)(w0 >> 29) << ((v0 ^ a0[u1 & 3u]) & 31u))) goto L3;
    } else {
        goto L3;
    }
    for (;;) { if (--fuel == 0u) goto done;
        u1 = u1 * 0x9e3779b1u + (unsigned)((2u - (i1 | (unsigned)(x0 >> 70))) || 0xffffffffu);
        if (3u) break;
        break; (void)((unsigned)d0);
        break; (void)((8u & (0x7fffffffu + 0xffffffffu)));
        if (((unsigned)(x0 >> 70) - 4u)) break;
        break; (void)((0x7fffffffu ^ 0x10000u));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *q0 += (unsigned)((short)i0 > (signed char)a0[u1 & 3u]);
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)w0 == (unsigned)x0), (unsigned)((int)i1 < (int)0x2d6fbde0u), garr[u2 & 7u]); }
    while (0x1de02df6u) { if (--fuel == 0u) goto done;
        if (0x10000u) {
            if (budget != 0u) { budget -= 1u; u1 = fn0(((i2 << (fuel & 31u)) & 0u), r0.y, (unsigned)((a0[i0 & 3u] + (unsigned)c0) == garr[u2 & 7u])); }
            *q0 += (unsigned)(unsigned char)(a0[i0 & 3u] & (7u ^ (0x10000u | a0[u1 & 3u])));
            if ((unsigned)(i2 || (unsigned)x0)) {
                { unsigned t0; double z0; if (((unsigned)(i1 && (unsigned)((int)garr[u2 & 7u] >= (int)0xca23b981u))) & 1u) { t0 = v0; z0 = (double)(((unsigned)((int)((unsigned)f0 % (0xed121d51u | 1u)) >= (int)9u)) & 255u); } if (((unsigned)(i1 && (unsigned)((int)garr[u2 & 7u] >= (int)0xca23b981u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                    do { if (--fuel == 0u) goto done;
                        u0 = u0 * 0x9e3779b1u + -((unsigned)((short)8u > (signed char)~(unsigned)((0x2a5084ecu % (0x4a1846e5u | 1u)) && 0x7fffffffu)) / ((unsigned)b0 | 1u));
                        L0: if (--fuel == 0u) goto done;
                        d0 = d0 * 0.5 + (double)(((unsigned)(-(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)w0) == (unsigned)((short)g1 > (signed char)(unsigned)e0)) & m0) & 1023u);
                        w0 ^= (unsigned long long)i0 << ((((unsigned)((short)(unsigned)h1 > (signed char)(unsigned)h0) + (unsigned)h1) | 9u) & 63u);
                    } while (i1++ < 7u && ((unsigned)w0 / (m0 | 1u)));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((7u % ((unsigned)c1 | 1u)), (unsigned)s1, ((unsigned)c1 ? u0 : *q0)); }
                }
                *mp = ((unsigned)s1 + g0);
                e0 = e0 * 0.5L + (long double)(((unsigned)s0 % (0xffffffffu | 1u)) & 1023u);
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)l0 > (signed char)0x10000u);
            }
        }
        if ((unsigned)((unsigned)(g1 == 0xeb4e80a9u) == 0x7fffffffu)) {
            if ((v0 * (unsigned)w0)) continue;
            if (0xbebfebf5u) {
                break; (void)((unsigned)(w0 >> 29));
                if ((unsigned)((int)(unsigned)(w0 >> 29) < (int)0x181e6869u)) {
                    g1 += (unsigned)((unsigned)(p1 < ~(r0.y << (a0[i0 & 3u] & 31u))) && (unsigned)d0);
                    if ((unsigned)l0) continue;
                    r0.y ^= (unsigned)((short)u3 > (signed char)(unsigned)((int)(unsigned)d0 < (int)(garr[i1 & 7u] + i0)));
                    l0 = (long)((unsigned long)l0 + ((unsigned)(unsigned char)((unsigned)s0 / (*mp | 1u)) - (unsigned)(unsigned char)(g0 & ((unsigned)c1 * 0x269ae839u))));
                } else {
                    u2 ^= (unsigned)((short)r0.x > (signed char)0x718272a7u);
                }
                L1: if (--fuel == 0u) goto done;
                continue; (void)((unsigned)(i1 == (u2 & 9u)));
                if ((0x50ece529u & (m0 & 0x63166cd0u))) {
                    r0.y ^= ((unsigned)s0 * (unsigned)(unsigned char)(5u ? (u3 << (0xaf6326c9u & 31u)) : 0xffffffffu));
                    L2: if (--fuel == 0u) goto done;
                }
            }
        } else {
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(((unsigned)((int)v0 >= (int)(unsigned)((short)g1 > (signed char)i0)) + (p2 * garr[i1 & 7u])) & 1023u);
                switch ((garr[i1 & 7u] + (unsigned)s1) & 7u) {
                    f0 = f0 * 0.5f + (float)((0xafc88389u % (8u | 1u)) & 255u);
                    e0 = e0 * 0.5L + (long double)(0u & 1023u);
                    if (0x80000000u) goto L2;
                }
            }
            goto L1;
            u3 = u3 * 0x9e3779b1u + ((unsigned)x0 << ((unsigned)x0 & 31u));
        }
        *mp = ((unsigned)((int)(unsigned)s1 >= (int)p1) & (unsigned)(x0 >> 70));
        if (fuel < 8u) return (g1 << (*mp & 31u));
    }
    if ((4u / ((m0 >> (0x20986addu & 31u)) | 1u))) goto L4;
    if ((unsigned)((unsigned)l0 || g1)) {
        q0 = &garr[((unsigned)h1 | ((g1 & (unsigned)w0) + garr[u2 & 7u])) & 7u];
        goto L2;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch (i2 & 7u) {
                *q0 = (unsigned)((int)0x7fffffffu >= (int)garr[i1 & 7u]);
                h1 = (unsigned short)(h1 + (0xffffffffu / (r0.y | 1u)));
            }
        }
        c0 = (unsigned char)(unsigned)((short)i0 > (signed char)(((unsigned)(w0 >> 29) & (unsigned)f0) % ((unsigned)w0 | 1u)));
    }
    w0 = w0 * 6364136223846793005ull + (unsigned)(((unsigned)(w0 >> 29) & 0xa0361348u) || (0x7fffffffu * (unsigned)h0));
    goto L2;
    for (;;) { if (--fuel == 0u) goto done;
        if ((((unsigned)c1 * r0.y) + (unsigned)f0)) {
            e0 = e0 * 0.5L + (long double)((unsigned)s0 & 1023u);
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(a0[i0 & 3u] && 0x80000000u), (unsigned)((*q0 - (unsigned)s1) == (unsigned)s1), (unsigned)((int)2u < (int)(unsigned)c1)); }
            L3: if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)((short)p1 > (signed char)5u);
        }
        switch ((unsigned)((unsigned)f0 || u3) & 7u) {
            do { if (--fuel == 0u) goto done;
                { unsigned t1; double z1; if ((((unsigned)f0 & ~(i1 - (unsigned)s1))) & 1u) { t1 = i0; z1 = (double)(((unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)((unsigned)c1 && garr[i1 & 7u]))) & 255u); } if ((((unsigned)f0 & ~(i1 - (unsigned)s1))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    switch (*mp & 7u) {
                        switch ((i0 & (unsigned)d0) & 7u) {
                            if (((0xffffffffu ^ (unsigned)(x0 >> 70)) - (unsigned)w0)) continue;
                            d0 = d0 * 0.5 + (double)((((0x2a20e2b5u ^ 8u) - 0x7fffffffu) & (unsigned)d0) & 1023u);
                            case 4u: ;
                            s1 = (int)((unsigned)s1 + ((unsigned)h0 % (3u | 1u)));
                        }
                        u2 += (unsigned)((short)(unsigned)(signed char)(unsigned)((int)(unsigned)((unsigned)h1 == 0x10000u) < (int)0x80000000u) > (signed char)(unsigned)s1);
                    }
                    u1 += ((unsigned)c0 & 7u);
                    if ((0x80000000u * 1u)) continue;
                    goto L4;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)c1 < (int)0xffffffffu), u2, 0x6f2ece6fu); }
                    if ((6u | u3)) {
                        if ((unsigned)(m0 || p1)) continue;
                        u2 = u2 * 0x9e3779b1u + (unsigned)(a0[i0 & 3u] || (unsigned)x0);
                    }
                }
                s1 = (int)((unsigned)s1 + (0x10000u * (unsigned)b0));
            } while (i1++ < 3u && u3);
            v0 = ((unsigned)!(unsigned)(u3 == (unsigned)c1) << (((unsigned)(unsigned char)((unsigned)h0 % (0x220848c8u | 1u)) >> ((unsigned)d0 & 31u)) & 31u));
        }
        *q0 = (unsigned)((int)((unsigned)s1 ? (unsigned)(8u && a0[u1 & 3u]) : 0x7fffffffu) >= (int)(unsigned)b0);
        if (u3 == 7u) return (i1 ? (unsigned)c1 : 0xffffffffu);
        u0 = ~(unsigned)(0x7fffffffu < (unsigned)e0);
    }
    goto L2;
    { unsigned t2; double z2; if ((((unsigned)x0 % (r0.x | 1u))) & 1u) { t2 = (unsigned)((int)(unsigned)(0x26e97f86u && 0x10000u) >= (int)0x10000u); z2 = (double)(((p2 % ((unsigned)((short)r0.x > (signed char)fuel) | 1u))) & 255u); } if ((((unsigned)x0 % (r0.x | 1u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        q0 = &garr[(unsigned)((int)(unsigned)((int)8u < (int)garr[i1 & 7u]) < (int)(((unsigned)(w0 >> 29) - 0xffffffffu) & fuel)) & 7u];
        do { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)((short)0x10000u > (signed char)i1);
            if (0xb09eb192u) break;
            if ((unsigned)((unsigned)s0 || *q0)) continue;
            c1 = (signed char)(unsigned)(unsigned char)(garr[u2 & 7u] ? (unsigned)((unsigned)b0 < u0) : 0x10000u);
            w0 ^= (unsigned long long)(0x28aa7e7cu ^ i2) << ((a0[u1 & 3u] + (0x7fffffffu % ((unsigned)(garr[u2 & 7u] && (unsigned)d0) | 1u))) & 63u);
        } while (i0++ < 3u && (unsigned)(i2 || ((unsigned)h1 % (v0 | 1u))));
        g1 += (unsigned)((unsigned)((unsigned)(x0 >> 70) && p2) == 0x2c16b254u);
    }
    r0.y ^= (unsigned)(signed char)((0x46d98365u << ((unsigned)(9u < u1) & 31u)) << ((unsigned)c1 & 31u));
    r0.y ^= (unsigned)(0x10000u < (unsigned)((short)r0.y > (signed char)u2));
    if (r0.y) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)((unsigned)((unsigned)s0 < m0) < (i2 / (i1 | 1u)));
        }
        if (v0) goto L4;
        if (~(unsigned)((short)p1 > (signed char)(u1 % (u3 | 1u)))) {
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)(0x40d12001u ^ p1) > (signed char)p1), 0xf972d1au, p1); }
            if (budget != 0u) { budget -= 1u; u3 = fn0(*q0, -((unsigned)d0 ^ p0), 6u); }
        }
    } else {
        i0 = -(unsigned)((short)g1 > (signed char)6u) & 15u;
    }
    u2 = ((unsigned)(0x94ce1ebu || 0xae85cb3fu) * (unsigned)((int)0xdb8e5320u < (int)0xdccb4120u));
    *mp = 0x163475ecu;
    goto L3;
    if (((unsigned)((unsigned)c0 == 0xf0ddc01cu) >> ((unsigned)x0 & 31u))) {
        if (budget != 0u) { budget -= 1u; u1 = fn0(0x10000u, g0, (unsigned)(signed char)(i1 % ((garr[i1 & 7u] & p0) | 1u))); }
        while (i0++ < 4u && *mp) { if (--fuel == 0u) goto done;
            if ((0xbd23cb61u & *mp)) break;
            if (-(unsigned)(g1 == i1)) {
                *q0 = (((4u / (7u | 1u)) * 0x7fffffffu) & (unsigned)(*mp < 0x7fffffffu));
                r0.x = 0x80000000u;
                r0.y ^= (unsigned)((short)u3 > (signed char)0u);
                *mp = ((fuel & p1) >> (u0 & 31u));
                q0 = &garr[(unsigned)h0 & 7u];
            }
            s0 = (int)(unsigned)((p0 ? -(9u >> (0x504d95d5u & 31u)) : (unsigned)s0) || i0);
        }
    } else {
        if ((unsigned)l0) goto L4;
        goto L0;
        if (((unsigned)c0 + (unsigned)!(unsigned)(u0 == 0xfc202f9u))) {
            switch (u2 & 7u) {
                c1 = (signed char)(unsigned)(p2 && garr[i1 & 7u]);
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(i0 || 0xaef30545u), -(unsigned)((int)g1 >= (int)((unsigned)l0 % (7u | 1u))), (unsigned)w0); }
                w0 ^= (unsigned long long)(0x7fffffffu | (unsigned)(x0 >> 70)) << (i2 & 63u);
                w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)(0x10000u * 0x7b02aa75u);
                for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    i1 = (0x10000u - (7u | (0x10000u % (garr[i1 & 7u] | 1u)))) & 15u;
                    *q0 += (p2 + (0x10000u | (unsigned)(i1 == 0xffffffffu)));
                    if ((unsigned)f0) continue;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((0xffffffffu / ((unsigned)((unsigned)(w0 >> 29) == (unsigned)s0) | 1u)), (unsigned)w0, (0xffffffffu + 0x80000000u)); }
                }
                m0 ^= (unsigned)((short)(unsigned)h1 > (signed char)((unsigned)f0 & p1));
            }
            i2 = (unsigned)(unsigned char)((unsigned)(short)((unsigned)((short)(unsigned)h1 > (signed char)(unsigned)h1) | (unsigned)(signed char)(u2 / (i2 | 1u))) / (6u | 1u)) & 15u;
            goto L2;
        }
    }
    b0 = (unsigned)(((unsigned)f0 >> (5u & 31u)) || ((unsigned)h0 << ((unsigned)x0 & 31u))) != 0u;
    e0 = e0 * 0.5L + (long double)((0x10000u - (0x10000u * g0)) & 1023u);
    s1 = (int)((unsigned)s1 + (unsigned)(g1 < (r0.y % ((unsigned)s1 | 1u))));
    if (fuel) goto L0;
    e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)!(unsigned)(u0 || 0x2b2e6646u) && (unsigned)(r0.x < (unsigned)l0)) & 1023u);
    u2 ^= (0x10000u + (unsigned)d0);
    s0 = (int)(unsigned)((int)(((unsigned)w0 & 5u) | (unsigned)(w0 >> 29)) >= (int)0x517d52ecu);
    c1 = (signed char)(unsigned)((short)u0 > (signed char)0x8f65dfc9u);
L4: if (--fuel == 0u) goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    c1 = (signed char)(unsigned)(((unsigned)(w0 >> 29) % ((unsigned)((0x55539027u / (0xffffffffu | 1u)) < 0xb46f1f9fu) | 1u)) == (unsigned)c1);
    while ((*q0 ^ v0)) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((unsigned)(m0 && v0) | a0[i0 & 3u]);
        } while (i1++ < 3u && (u1 ^ 9u));
    }
    h1 = (unsigned short)(h1 + ((unsigned)(w0 >> 29) / (7u | 1u)));
    goto L1;
    while (i0++ < 4u && p2) { if (--fuel == 0u) goto done;
        if (*mp) break;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (0x10000u) goto L1;
            switch ((*mp | garr[i1 & 7u]) & 7u) {
                while (i2++ < 5u && (unsigned)(i2 && -((unsigned)d0 << (i1 & 31u)))) { if (--fuel == 0u) goto done;
                    w0 ^= (unsigned long long)a0[i0 & 3u] << (0xe6e5bd22u & 63u);
                    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((0xc979dc5eu >> ((unsigned)b0 & 31u)), (unsigned)((unsigned)((int)g0 < (int)g0) || (unsigned)b0), ((unsigned)f0 | (unsigned)s1)); }
                        if (0x10000u) break;
                        if ((0x86d59b2bu / ((unsigned)e0 | 1u))) break;
                        case 1u: ;
                        if ((unsigned)!((unsigned)b0 ^ 0x10000u)) continue;
                    }
                    if ((unsigned)((int)(5u ^ r0.x) >= (int)garr[i1 & 7u])) {
                        v0 = (unsigned)((int)(unsigned)(a0[i0 & 3u] || (fuel ? (unsigned)h0 : (unsigned)e0)) < (int)(unsigned)f0);
                    } else {
                        d0 = d0 * 0.5 + (double)((0xe79dcea8u - (0x7fffffffu * i2)) & 1023u);
                        *mp = ((unsigned)(w0 >> 29) >> ((((unsigned)d0 + (unsigned)f0) * (unsigned)f0) & 31u));
                        s1 = (int)((unsigned)s1 + (r0.y << ((unsigned)((((unsigned)l0 | (unsigned)x0) * (unsigned)c1) == (unsigned)c1) & 31u)));
                        if ((g1 << ((unsigned)h1 & 31u))) break;
                    }
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0(v0, (unsigned)((int)0x80000000u >= (int)(unsigned)((int)0x10000u >= (int)m0)), (unsigned)((int)(*mp >> (6u & 31u)) < (int)p2)); }
                { unsigned t0; double z0; if ((((unsigned)(x0 >> 70) % (6u | 1u))) & 1u) { t0 = (unsigned)((int)i2 < (int)fuel); z0 = (double)((((unsigned)(0u < 0x80000000u) >> ((unsigned)h1 & 31u))) & 255u); } if ((((unsigned)(x0 >> 70) % (6u | 1u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                    if ((u2 + 5u)) {
                        do { if (--fuel == 0u) goto done;
                            r0.x = ((unsigned)((unsigned)((short)0xffffffffu > (signed char)fuel) == a0[u1 & 3u]) << (*mp & 31u));
                            if (budget != 0u) { budget -= 1u; u1 = fn1((0x80000000u ^ p1), ((unsigned)b0 >> ((unsigned)((short)0x10000u > (signed char)u1) & 31u)), (unsigned)(a0[u1 & 3u] == (u1 - r0.y))); }
                            u3 ^= -(0x7fffffffu + (unsigned)(garr[u2 & 7u] == (unsigned)(garr[u2 & 7u] || (unsigned)c1)));
                        } while (i2++ < 5u && (unsigned)(0xffffffffu == p2));
                    } else {
                        v0 = (((unsigned)c1 ? garr[i1 & 7u] : 0x80000000u) << (0x7fffffffu & 31u));
                        break; (void)(0x95d11a35u);
                        x0 = x0 * 0x100000001b3ull + 0xbdac15f9u;
                    }
                }
            }
            L0: if (--fuel == 0u) goto done;
        }
        s0 = (int)((unsigned)!((unsigned)(w0 >> 29) ^ 0x9f749eccu) / ((i1 & 0xb8fbe92cu) | 1u));
        *q0 += (unsigned)(0x3e419e11u < (p1 / (p0 | 1u)));
        if ((unsigned)((unsigned)((int)(unsigned)c1 >= (int)0xf5f6bb74u) && 0xffffffffu)) {
            switch ((unsigned)((unsigned)f0 || (unsigned)h0) & 7u) {
                *q0 = (unsigned)((unsigned)(0x10000u == p0) < (unsigned)(signed char)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)0xffffffffu));
            }
            d0 = d0 * 0.5 + (double)((unsigned)((0x45b0f00bu << ((a0[i0 & 3u] / (garr[u2 & 7u] | 1u)) & 31u)) || (unsigned)((short)0x10000u > (signed char)(unsigned)l0)) & 1023u);
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0((((unsigned)w0 << (u1 & 31u)) / (p2 | 1u)), ((unsigned)((int)u0 < (int)(unsigned)l0) / (1u | 1u)), (v0 >> ((unsigned)((unsigned)h0 < u2) & 31u))); }
    }
    if ((unsigned)(signed char)(0x3a3b1cdfu % ((3u >> (0x80000000u & 31u)) | 1u))) goto done;
    goto L4;
    switch ((unsigned)((int)a0[u1 & 3u] >= (int)0x9ebc0b60u) & 7u) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)m0 > (signed char)(unsigned)(signed char)((unsigned)f0 / (p1 | 1u))), i0, ((a0[i0 & 3u] % (2u | 1u)) >> (0xffffffffu & 31u))); }
    }
    { unsigned t1; double z1; if (((5u % (0x1246c79u | 1u))) & 1u) { t1 = p0; z1 = (double)(((unsigned)(w0 >> 29)) & 255u); } if (((5u % (0x1246c79u | 1u))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        c1 = (signed char)(unsigned)(signed char)(unsigned)((int)(unsigned)w0 >= (int)(unsigned)(i2 || fuel));
        d0 = d0 * 0.5 + (double)((unsigned)(g0 && (unsigned)((int)(unsigned)((short)(i2 + 1u) > (signed char)0x7fffffffu) < (int)(unsigned)b0)) & 1023u);
        e0 = e0 * 0.5L + (long double)((unsigned)b0 & 1023u);
    }
    h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)h0 > (signed char)(6u / ((unsigned)(x0 >> 70) | 1u))));
    goto done;
    g1 += (unsigned)d0;
    goto L4;
    for (;;) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + -((u1 * (unsigned)c0) ? (0x80000000u | (unsigned)c0) : p1));
        do { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((m0 ? -(6u / (*q0 | 1u)) : (i1 % (p0 | 1u))) & 1023u);
            goto L0;
            L1: if (--fuel == 0u) goto done;
        } while (i1++ < 5u && (g1 + a0[i0 & 3u]));
        g0 = (((unsigned)x0 + *q0) + (g0 & (0x10000u - 0x80000000u)));
        r0.x = (i0 | 0x6f340ab3u);
        u3 = u3 * 0x9e3779b1u + ((unsigned)(short)(unsigned)(p2 || (unsigned)w0) % (0x68c1b724u | 1u));
    }
    goto L3;
    g0 = ((r0.y & 0xffffffffu) << ((7u * (unsigned)!(unsigned)((short)p0 > (signed char)u0)) & 31u));
    x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)(x0 >> 70) == i0);
    if (budget != 0u) { budget -= 1u; u1 = fn0((i2 * a0[u1 & 3u]), (unsigned)!(unsigned)((unsigned)(w0 >> 29) || (unsigned)(x0 >> 70)), m0); }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        i1 = (unsigned)((int)(unsigned)x0 < (int)(garr[u2 & 7u] * (unsigned)((unsigned)h0 && 0x80000000u))) & 15u;
        if ((0xc2eaa73eu ^ p0)) {
            if ((unsigned)d0) {
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)e0, ((0x80000000u & 0xd86b7230u) % ((unsigned)w0 | 1u)), (a0[u1 & 3u] - p2)); }
                }
                while (i1++ < 5u && ((g1 % (5u | 1u)) % ((unsigned)f0 | 1u))) { if (--fuel == 0u) goto done;
                    break; (void)(0xaf700669u);
                    L2: if (--fuel == 0u) goto done;
                    { unsigned t2; double z2; if (((unsigned)((int)9u < (int)0xedfabb4fu)) & 1u) { t2 = ((u1 - 0xc7facfc7u) >> (u1 & 31u)); z2 = (double)((-(0x10000u | (p1 + u3))) & 255u); } if (((unsigned)((int)9u < (int)0xedfabb4fu)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                        *q0 = u1;
                        h1 = (unsigned short)(h1 + (unsigned)!(unsigned)((0x81e76712u | (unsigned)d0) == (unsigned)((int)g1 >= (int)(unsigned)f0)));
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)f0 << ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)d0) & 31u)), (unsigned)((int)(unsigned)(unsigned char)(0xd06e3003u ^ (unsigned)b0) >= (int)garr[u2 & 7u]), (unsigned)(6u || 0u)); }
                        d0 = d0 * 0.5 + (double)(((unsigned)h0 + (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(m0 == 0xa3aca8c3u))) & 1023u);
                        if (0xffffffffu) goto done;
                        L3: if (--fuel == 0u) goto done;
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn1(0x10000u, (unsigned)((short)fuel > (signed char)(unsigned)s0), (unsigned)(8u < garr[u2 & 7u])); }
                    u1 = (((unsigned)s0 ? m0 : -(r0.x >> ((unsigned)w0 & 31u))) ^ u2);
                    if (0x7fffffffu) break;
                }
                if (0x1a8cfe3eu) break;
                if ((0x5b12797u * (0x7fffffffu << (1u & 31u)))) break;
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (((unsigned)((short)fuel > (signed char)0x80000000u) | u1)) {
                        if ((g0 >> ((*q0 % (m0 | 1u)) & 31u))) goto L0;
                        if ((v0 >> (p0 & 31u))) break;
                    }
                    r0.y ^= (u1 / ((unsigned)s1 | 1u));
                    c1 = (signed char)(p1 * 0u);
                    r0.x = (0x535796eau % ((unsigned)h1 | 1u));
                    if (budget != 0u) { budget -= 1u; u0 = fn1(r0.x, ~((unsigned)d0 | (unsigned)(short)(0x7fffffffu | 0x80000000u)), 0x6df92277u); }
                }
                if (((unsigned)s0 + (i0 | (unsigned)c1))) break;
            }
        }
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0(((0x12c3b3d2u % (0u | 1u)) - 1u), (unsigned)(((unsigned)s1 - 9u) == 0x7fffffffu), ((unsigned)l0 ^ (unsigned)((int)(unsigned)d0 < (int)r0.x))); }
            switch (v0 & 7u) {
                w0 ^= (unsigned long long)(unsigned)l0 << (((unsigned)e0 >> (((unsigned)(garr[u2 & 7u] || (unsigned)l0) % ((unsigned)(r0.x && 0x457bc12du) | 1u)) & 31u)) & 63u);
                if ((unsigned)b0) goto L3;
                m0 ^= *mp;
                if (u3 == 7u) return ((unsigned)((unsigned)x0 == 0x5a68cbc8u) * 7u);
                *mp = (unsigned)((int)(unsigned)(signed char)(0u / (0x10000u | 1u)) >= (int)r0.x);
                case 5u: ;
            }
        }
    }
    switch ((unsigned)(unsigned char)(unsigned)((int)((unsigned)(x0 >> 70) + i2) >= (int)0xe8cf6f9eu) & 7u) {
        case 4u: ;
    }
    a0[(unsigned)w0 & 3u] = (unsigned)(p2 || 0xcbaed54fu);
    v0 = 0x10000u;
    s1 = (int)((unsigned)s1 + (a0[i0 & 3u] - (unsigned)(0x7929e4cfu || (unsigned)f0)));
    if (((unsigned)(w0 >> 29) ^ (unsigned)d0)) goto L4;
    if (((unsigned)((int)r0.y >= (int)garr[i1 & 7u]) - 3u)) goto L3;
    w0 = w0 * 6364136223846793005ull + (((unsigned)s0 ^ 0x7fffffffu) / (0x80000000u | 1u));
    u2 ^= (unsigned)((unsigned)x0 < ~(0x1850c1c8u - (unsigned)((int)(0x347d810cu - *mp) < (int)garr[i1 & 7u])));
    do { if (--fuel == 0u) goto done;
        continue; (void)((0x4c48bff1u * (unsigned)(w0 >> 29)));
        if (budget != 0u) { budget -= 1u; u2 = fn1(garr[u2 & 7u], (g1 << ((0x530fd814u / (g0 | 1u)) & 31u)), 1u); }
        q0 = &garr[(((9u - (unsigned)c1) >> (0xffffffffu & 31u)) % ((unsigned)(u0 || 0x82bb4f58u) | 1u)) & 7u];
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            u3 = (unsigned)((int)6u >= (int)~(p0 << (i1 & 31u)));
            l0 = (long)((unsigned long)l0 + (unsigned)((int)i0 >= (int)(unsigned)((int)u0 >= (int)(unsigned)x0)));
            while (i2++ < 4u && (0xc742ea74u - 0x80000000u)) { if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)(0x57e90b65u < 2u)) continue;
                    if (*mp) break;
                    u3 = u3 * 0x9e3779b1u + ~(unsigned)((short)((unsigned)s0 * 0x6b9252c7u) > (signed char)((unsigned)h1 >> ((fuel | garr[u2 & 7u]) & 31u)));
                }
                if ((unsigned)(0xffffffffu < 0x80000000u)) {
                    l0 = (long)((unsigned long)l0 + (unsigned)d0);
                    m0 ^= ((unsigned)d0 | ((0x9a642e12u & *q0) << (0x10000u & 31u)));
                    if (budget != 0u) { budget -= 1u; u0 = fn0(p0, (unsigned)(short)((1u - m0) & u1), 0x80000000u); }
                }
            }
            c0 = (unsigned char)(unsigned)l0;
        }
    } while (i0++ < 7u && (0x805ceb62u * 7u));
    if (budget != 0u) { budget -= 1u; u0 = fn1((0xffffffffu - r0.y), (garr[i1 & 7u] >> (a0[i0 & 3u] & 31u)), (u1 * (unsigned)e0)); }
    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)c0 * (unsigned)(0x7fffffffu && 0xbcc31ca2u)), 0xc85d86e9u, ((unsigned)s1 << (fuel & 31u))); }
    h0 = (short)(unsigned)((unsigned)d0 && m0);
    if (budget != 0u) { budget -= 1u; u2 = fn1(4u, g1, (unsigned)((int)fuel >= (int)6u)); }
    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(short)(unsigned)((int)2u >= (int)(u1 - r0.y)), (unsigned)h1, (unsigned)(garr[i1 & 7u] < (unsigned)s1)); }
    { unsigned t3; double z3; if (((7u | u0)) & 1u) { t3 = (unsigned)((int)(unsigned)c1 >= (int)((unsigned)s1 - i2)); z3 = (double)(((0x4627a62fu << (3u & 31u))) & 255u); } if (((7u | u0)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        if ((u2 + (unsigned)(0xc9f39bc3u < 7u))) goto L4;
        if ((unsigned)s1) {
            h1 = (unsigned short)(h1 + i1);
            *q0 = (unsigned)d0;
        } else {
            if ((unsigned)((int)0x5b6e09c4u >= (int)5u)) {
                goto L3;
                if (budget != 0u) { budget -= 1u; u0 = fn0((5u % (0x7fffffffu | 1u)), (unsigned)((int)(unsigned)s1 < (int)0xb1790a7eu), ~(unsigned)((int)(garr[u2 & 7u] % ((unsigned)d0 | 1u)) >= (int)0x3575f636u)); }
                u1 = (unsigned)(short)(unsigned)(0x10000u && (unsigned)h1);
                w0 = w0 * 6364136223846793005ull + (unsigned)(-(unsigned)((short)(0x80000000u % (r0.x | 1u)) > (signed char)1u) == 3u);
                u2 += (unsigned)(0x7fffffffu && *mp);
            } else {
                for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = *q0;
                    s0 = (int)(unsigned)(unsigned char)(unsigned)((int)(unsigned)((short)p0 > (signed char)p2) >= (int)(unsigned)(m0 || p0));
                    u3 += ((unsigned)e0 ? (0x80000000u & (unsigned)b0) : u2);
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(*mp < (garr[u2 & 7u] * 4u)), g1, ~(unsigned)((unsigned)h0 && (i2 * (unsigned)(w0 >> 29)))); }
                    u2 += ((p0 / (0x1b4a309du | 1u)) & garr[u2 & 7u]);
                    d0 = d0 * 0.5 + (double)(((0xe5df9476u >> (i2 & 31u)) ? (garr[u2 & 7u] << ((unsigned)(x0 >> 70) & 31u)) : 7u) & 1023u);
                }
                *q0 = (unsigned)(((unsigned)((int)0x52bd1360u >= (int)0xd560bfa4u) + g1) || (unsigned)(a0[u1 & 3u] == (unsigned)h0));
            }
            c1 = (signed char)(unsigned)((unsigned)e0 || (unsigned)x0);
        }
        if ((unsigned)(*mp == 0x10000u)) goto L3;
        v0 = (unsigned)(0x7fffffffu || (3u % (((unsigned)b0 - i2) | 1u)));
        { unsigned t4; double z4; if ((8u) & 1u) { t4 = (unsigned)!(unsigned)(*mp || a0[i0 & 3u]); z4 = (double)((((unsigned)s0 / ((unsigned)(garr[u2 & 7u] && m0) | 1u))) & 255u); } if ((8u) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)f0, (garr[u2 & 7u] / (u0 | 1u)), (unsigned)((unsigned)s1 < 0x80000000u)); }
            goto done;
            m0 ^= 0xa176b7dbu;
            if (0x13cd4817u) goto L4;
        }
    }
    w0 ^= (unsigned long long)(unsigned)e0 << (~(0x7fffffffu / ((unsigned)c1 | 1u)) & 63u);
    if (u2) {
        v0 = (unsigned)((short)m0 > (signed char)~(unsigned)((r0.y + u3) < (0x4397e021u & (unsigned)h1)));
        { unsigned t5; double z5; if ((m0) & 1u) { t5 = ((9u >> (0x412a7865u & 31u)) & (unsigned)(w0 >> 29)); z5 = (double)(((m0 << (~((unsigned)l0 & 5u) & 31u))) & 255u); } if ((m0) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            v0 = 1u;
            if ((unsigned)((unsigned)(g1 && garr[u2 & 7u]) == g0)) goto L4;
            if (0u) {
                *mp = ((garr[u2 & 7u] << ((unsigned)x0 & 31u)) << (0xffffffffu & 31u));
                u0 ^= (unsigned)((unsigned)(p0 || (r0.y - (unsigned)c1)) && -((unsigned)b0 << ((unsigned)l0 & 31u)));
                if (u3 == 7u) return (r0.x / ((unsigned)(signed char)((unsigned)c0 - p0) | 1u));
                x0 = x0 * 0x100000001b3ull + ((1u ? 0x7c07c178u : (unsigned)x0) | p2);
            } else {
                if ((unsigned)(*q0 < garr[i1 & 7u])) goto L4;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(a0[u1 & 3u] == (unsigned)f0), 8u, ((unsigned)((short)i2 > (signed char)garr[i1 & 7u]) | 0x4ac639f7u)); }
                do { if (--fuel == 0u) goto done;
                    i2 = fuel & 15u;
                } while (i0++ < 7u && (unsigned)(u2 || ((unsigned)(w0 >> 29) & r0.y)));
                if ((unsigned)((unsigned)s0 < (unsigned)f0)) {
                    if (((garr[i1 & 7u] / (i2 | 1u)) << ((unsigned)e0 & 31u))) goto L3;
                    if (budget != 0u) { budget -= 1u; u2 = fn1(((p1 << (u2 & 31u)) ^ (unsigned)f0), (0u << ((unsigned)e0 & 31u)), (i2 ^ ((unsigned)(w0 >> 29) ^ 5u))); }
                } else {
                    v0 = (i2 - (unsigned)e0);
                    if (((unsigned)h1 ^ u1)) goto L1;
                    *q0 = (a0[u1 & 3u] & 0x80000000u);
                    if ((u3 ? (unsigned)c0 : i1)) {
                        if ((unsigned)(5u && (unsigned)s0)) goto L0;
                        goto L2;
                        a0[0x40781608u & 3u] = ((p1 >> (u3 & 31u)) + 7u);
                    } else {
                        i2 = (unsigned)((unsigned)((unsigned)h1 || (unsigned)((int)r0.x >= (int)i0)) || (unsigned)(signed char)(i0 + (unsigned)h0)) & 15u;
                        if (((unsigned)((int)*q0 < (int)p0) ^ (unsigned)(w0 >> 29))) goto L4;
                        g1 += (unsigned)(((unsigned)x0 ? m0 : (unsigned)f0) < p1);
                    }
                }
            }
            if ((unsigned)!((unsigned)((int)0x7fffffffu < (int)g0) / (fuel | 1u))) goto L2;
        }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (u3) continue;
            u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)s0 < p2);
            c1 = (signed char)((unsigned)d0 >> ((unsigned)s1 & 31u));
            if ((unsigned)l0) break;
            q0 = &garr[-(-(unsigned)((int)i0 >= (int)i2) * garr[i1 & 7u]) & 7u];
            if ((unsigned)(0x681bfbc6u && (p1 >> (*mp & 31u)))) break;
        }
        q0 = &garr[fuel & 7u];
        v0 = (0x39a70ca6u >> (0x102b6109u & 31u));
    } else {
        if (((p2 ^ 0x80000000u) - 0x1e19cc33u)) goto done;
        c0 = (unsigned char)(((unsigned)h0 * (unsigned)(short)(unsigned)((unsigned)((short)fuel > (signed char)5u) && a0[u1 & 3u])) / (garr[u2 & 7u] | 1u));
    }
    if ((unsigned)(x0 >> 70)) goto done;
    if ((u1 & a0[i0 & 3u])) {
        u3 += (unsigned)((unsigned)(((unsigned)f0 ^ garr[i1 & 7u]) < (unsigned)c1) && ((unsigned)l0 - (unsigned)h0));
        if ((((unsigned)b0 | r0.y) & v0)) goto done;
        if ((a0[u1 & 3u] | v0)) goto L4;
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)l0, (unsigned)((int)r0.x >= (int)i1), ((unsigned)f0 | (unsigned)c1)); }
        for (;;) { if (--fuel == 0u) goto done;
            v0 = (unsigned)((0xf214bd76u << (0x80000000u & 31u)) < u3);
        }
        if (((0x252b832du ^ (unsigned)(x0 >> 70)) - (unsigned)e0)) {
            switch (((unsigned)f0 * 0u) & 7u) {
                case 1u: ;
                *q0 = (unsigned)((int)(unsigned)(0xffffffffu && u2) >= (int)(unsigned)(w0 >> 29));
                if (i0) break;
                if (9u) goto L1;
                g1 += ((((unsigned)(w0 >> 29) >> (1u & 31u)) % ((garr[i1 & 7u] - (unsigned)(x0 >> 70)) | 1u)) ^ 0x9641b695u);
            }
            c0 = (unsigned char)((unsigned)((int)g0 >= (int)garr[u2 & 7u]) & a0[i0 & 3u]);
            do { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (unsigned)s0);
                b0 = ((0x7fffffffu >> ((unsigned)(signed char)((unsigned)s1 - (unsigned)(signed char)(unsigned)((int)*mp >= (int)7u)) & 31u)) & a0[u1 & 3u]) != 0u;
                r0.y ^= (unsigned)((u2 ? 0x79c88099u : ((unsigned)l0 + 0xffffffffu)) || (unsigned)(x0 >> 70));
                *mp = p1;
                m0 ^= (unsigned)((fuel | i2) && p0);
                goto L4;
            } while (i0++ < 7u && 0x7fffffffu);
            x0 = x0 * 0x100000001b3ull + p1;
        }
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 += ((unsigned)((int)3u < (int)g0) + (0x10000u * (v0 * 0xa0b96b2au)));
        *q0 += (unsigned)(signed char)((unsigned)s0 << (0xa4758e15u & 31u));
        goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)(x0 >> 70) < 5u), (unsigned)(signed char)(unsigned)((unsigned)((unsigned)s0 == 0xffffffffu) || p2), m0); }
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)l0, -(unsigned)((int)v0 >= (int)v0), ((unsigned)b0 * (unsigned)((short)(unsigned)s1 > (signed char)p2))); }
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            g0 = 0x80000000u;
            break; (void)((unsigned)c0);
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        q0 = &garr[((p1 / (0xeddc3d1u | 1u)) >> ((unsigned)(short)(u0 | (unsigned)s0) & 31u)) & 7u];
        s1 = (int)((unsigned)s1 + (p0 - g0));
        *q0 += u2;
    } while (i0++ < 2u && 3u);
    { unsigned t0; double z0; if ((((unsigned)s1 & v0)) & 1u) { t0 = (unsigned)(short)(unsigned)((unsigned)(3u < 7u) == (unsigned)s0); z0 = (double)(((unsigned)(i0 && (unsigned)(garr[i1 & 7u] < 3u))) & 255u); } if ((((unsigned)s1 & v0)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        L0: if (--fuel == 0u) goto done;
    }
    b0 = -(0x7fffffffu >> (fuel & 31u)) != 0u;
    m0 ^= (*q0 % (v0 | 1u));
    if (((unsigned)h0 + (unsigned)s1)) goto L2;
    L1: if (--fuel == 0u) goto done;
    if ((unsigned)((int)0xb8a1815au < (int)(unsigned)c0)) goto L0;
    c1 = (signed char)g0;
    if ((unsigned)(((unsigned)c0 | 5u) || (unsigned)b0)) goto L3;
    if (budget != 0u) { budget -= 1u; u2 = fn1(0xd65bb89bu, (i0 + (u3 | (unsigned)e0)), (unsigned)(i2 < ((unsigned)x0 * r0.y))); }
    h0 = (short)(unsigned)(short)(0xffffffffu / (((unsigned)(short)(5u % (r0.x | 1u)) ^ a0[u1 & 3u]) | 1u));
    a0[(unsigned)((unsigned)(x0 >> 70) && a0[i0 & 3u]) & 3u] = -(unsigned)((unsigned)(p1 < 0x7fffffffu) == 0x7fffffffu);
    { unsigned t1; double z1; if (((v0 << ((unsigned)c1 & 31u))) & 1u) { t1 = (u2 ^ 0xa633b491u); z1 = (double)((-(unsigned)(g1 < 0x7fffffffu)) & 255u); } if (((v0 << ((unsigned)c1 & 31u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
        x0 = x0 * 0x100000001b3ull + ((unsigned)(r0.x || g1) << (((8u / (u2 | 1u)) << (4u & 31u)) & 31u));
        { unsigned t2; double z2; if (((unsigned)((int)m0 < (int)u0)) & 1u) { t2 = (unsigned)(0x7fffffffu < (unsigned)s0); z2 = (double)((((unsigned)((unsigned)c0 && i1) ^ 5u)) & 255u); } if (((unsigned)((int)m0 < (int)u0)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            L2: if (--fuel == 0u) goto done;
            if ((unsigned)(0xefd0cdefu && 0xcbf4cc8bu)) goto done;
            L3: if (--fuel == 0u) goto done;
            if ((0x7fffffffu ? 9u : p1)) {
                { unsigned t3; double z3; if ((((unsigned)c0 ? (unsigned)h0 : g1)) & 1u) { t3 = (unsigned)(0x80000000u || (unsigned)((short)0xed019936u > (signed char)m0)); z3 = (double)(((a0[i0 & 3u] << (((unsigned)e0 ^ u1) & 31u))) & 255u); } if ((((unsigned)c0 ? (unsigned)h0 : g1)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    goto done;
                }
                d0 = d0 * 0.5 + (double)((unsigned)(short)((1u & 0x65e46c28u) + v0) & 1023u);
                goto L3;
            }
            if (0xcd07ea7fu) goto L4;
        }
    }
    r0.y ^= (unsigned)((short)(((unsigned)(unsigned char)(unsigned)((short)(unsigned)e0 > (signed char)(unsigned)x0) ^ (unsigned)(x0 >> 70)) << (g0 & 31u)) > (signed char)u0);
    switch ((unsigned)(unsigned char)((unsigned)f0 / ((unsigned)s1 | 1u)) & 7u) {
        L4: if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            case 5u: ;
            a0[*mp & 3u] = (unsigned)(0x10000u < 0xfd44e445u);
        } while (i0++ < 7u && (0x80000000u << (r0.y & 31u)));
    }
    goto L2;
    if (0xeef1a126u) goto L2;
    if (budget != 0u) { budget -= 1u; u0 = fn1((garr[u2 & 7u] & (unsigned)(signed char)(unsigned)((int)0x7fffffffu < (int)garr[u2 & 7u])), (m0 / (2u | 1u)), (unsigned)((unsigned)((int)(unsigned)e0 < (int)0x1b285799u) || r0.y)); }
    if (budget != 0u) { budget -= 1u; u0 = fn2(0x9f9a52e4u, ((unsigned)l0 | (unsigned)f0), 0x42d0fc18u); }
    r0.x = ((fuel ? (unsigned)f0 : (unsigned)s0) | (i0 >> ((unsigned)f0 & 31u)));
    e0 = e0 * 0.5L + (long double)(i1 & 1023u);
    u1 ^= (unsigned)((short)((unsigned)l0 & r0.x) > (signed char)(unsigned)f0);
    goto done;
    if (((unsigned)d0 + (unsigned)((short)0x80000000u > (signed char)(unsigned)c0))) goto done;
    i0 = (unsigned)(unsigned char)(r0.x / (r0.x | 1u)) & 15u;
    if (budget != 0u) { budget -= 1u; u1 = fn2(0x80000000u, (garr[i1 & 7u] / ((unsigned)(short)(8u | (unsigned)c1) | 1u)), (0x80000000u & ((unsigned)l0 % (0xbf54b5f4u | 1u)))); }
    u0 += (unsigned)((1u ^ a0[u1 & 3u]) || ((unsigned)l0 ^ (unsigned)((unsigned)c1 || 0x7fffffffu)));
    w0 = w0 * 6364136223846793005ull + (3u & g0);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        u1 = -(unsigned)((int)(unsigned)((unsigned)((unsigned)x0 || a0[i0 & 3u]) || u3) >= (int)(unsigned)((int)*mp >= (int)*q0));
        s0 = (int)*q0;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(0x75815219u < (unsigned)((int)v0 < (int)i1)), ((unsigned)s1 / (0x98ac4312u | 1u)), (unsigned)((int)g0 >= (int)u3)); }
            *mp = (9u << ((unsigned)b0 & 31u));
            if (budget != 0u) { budget -= 1u; u2 = fn0(0x8f79ec26u, (0x80000000u / (r0.y | 1u)), (unsigned)((int)(unsigned)h1 >= (int)((unsigned)c0 / (0x80000000u | 1u)))); }
            if (7u) goto done;
            switch ((0x650a8d90u << (r0.y & 31u)) & 7u) {
                if (((unsigned)w0 % ((unsigned)c1 | 1u))) continue;
                if (budget != 0u) { budget -= 1u; u2 = fn1(((u1 / (6u | 1u)) / (1u | 1u)), (unsigned)h1, (unsigned)((u3 << (r0.x & 31u)) == 3u)); }
            }
        }
    }
    if (((a0[u1 & 3u] >> ((unsigned)h0 & 31u)) * 0x10000u)) goto L0;
    h0 = (short)-(unsigned)(((p0 - p1) - (0x640132d5u >> (g1 & 31u))) == (unsigned)b0);
    while (i0++ < 4u && (unsigned)(((unsigned)d0 * (unsigned)b0) || v0)) { if (--fuel == 0u) goto done;
        if ((unsigned)((short)fuel > (signed char)i0)) continue;
    }
    r0.y ^= (unsigned)(unsigned char)((0x250096eeu % ((unsigned)!(unsigned)(fuel && (unsigned)b0) | 1u)) * 9u);
    *q0 = (a0[i0 & 3u] / (r0.y | 1u));
    goto L3;
    if ((6u << ((unsigned)(garr[i1 & 7u] && u3) & 31u))) goto done;
    switch ((i1 % ((unsigned)h1 | 1u)) & 7u) {
        r0.x = (g1 | a0[i0 & 3u]);
        while (i0++ < 5u && (unsigned)(~(unsigned)((short)i0 > (signed char)*q0) == 0x10000u)) { if (--fuel == 0u) goto done;
            case 2u: ;
            u3 = 0x80000000u;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((u2 * (unsigned)((unsigned)h1 == m0)), (((unsigned)l0 | (unsigned)(w0 >> 29)) - (unsigned)s1), 0xc036fe64u); }
        c1 = (signed char)(unsigned)((unsigned)l0 && g1);
    }
    { unsigned t4; double z4; if (((unsigned)(0xffffffffu == (p0 / (*mp | 1u)))) & 1u) { t4 = 5u; z4 = (double)(((unsigned)!((unsigned)c0 - i0)) & 255u); } if (((unsigned)(0xffffffffu == (p0 / (*mp | 1u)))) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
        while (i0++ < 3u && ((unsigned)(x0 >> 70) >> ((unsigned)((short)(unsigned)b0 > (signed char)(unsigned)d0) & 31u))) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)h1 && (unsigned)c0) || p1)) {
                if (((unsigned)h1 - 0xefb64d38u)) goto done;
                h0 = (short)(0x10000u | (0x7fffffffu << (0x961b28d1u & 31u)));
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    a0[(garr[u2 & 7u] >> (g0 & 31u)) & 3u] = u1;
                }
                if ((0x2878f26fu ? (unsigned)b0 : g0)) goto L3;
            } else {
                if ((((unsigned)c1 & v0) / ((unsigned)s0 | 1u))) goto L3;
                if (v0) continue;
            }
            { unsigned t5; double z5; if (((unsigned)s0) & 1u) { t5 = (unsigned)((unsigned)s0 || 0x24b02fbfu); z5 = (double)((garr[u2 & 7u]) & 255u); } if (((unsigned)s0) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                break; (void)((0x80000000u & ((unsigned)c1 % (u0 | 1u))));
                c1 = (signed char)(unsigned)((unsigned)h0 && ((7u | (unsigned)s0) >> ((p1 / (p0 | 1u)) & 31u)));
                if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s0 << ((unsigned)f0 & 31u)), (unsigned)c1, (unsigned)((int)(unsigned)h1 >= (int)(unsigned)((unsigned)c0 || m0))); }
                break; (void)((unsigned)((int)(0x7fffffffu | (unsigned)h1) >= (int)*q0));
                r0.y ^= u1;
            }
            *mp = (unsigned)((unsigned)h1 == 0x80000000u);
            if (0xffffffffu) break;
        }
    }
    goto L2;
    switch (0xffffffffu & 7u) {
        break; (void)((m0 ^ (unsigned)s1));
        case 6u: ;
        u2 = -((unsigned)h0 * 0x27a57727u);
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                switch ((unsigned)((int)(unsigned)((short)garr[u2 & 7u] > (signed char)g1) >= (int)(unsigned)(w0 >> 29)) & 7u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)c0, ((unsigned)(0x7fffffffu < (unsigned)w0) & 7u), (unsigned)(a0[u1 & 3u] && u3)); }
                }
            } while (i1++ < 6u && (unsigned)((int)i1 >= (int)u0));
            if (a0[u1 & 3u]) goto L1;
            r0.x = ((unsigned)f0 * ((unsigned)h0 % (0x43846dc3u | 1u)));
        }
    }
    if ((unsigned)((int)(unsigned)x0 >= (int)fuel)) goto L3;
    for (;;) { if (--fuel == 0u) goto done;
        r0.y ^= ~(r0.y | (unsigned)h0);
        c1 = (signed char)(unsigned)((unsigned)w0 < ((unsigned)((p2 & 0x359f1c6au) == (unsigned)x0) & m0));
    }
    switch ((unsigned)((int)(0xf299e328u | v0) >= (int)0u) & 7u) {
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)(garr[u2 & 7u] || ((r0.y / (*mp | 1u)) % (((unsigned)f0 - 0x7fffffffu) | 1u))) & 1023u);
                g0 = -((unsigned)f0 & (unsigned)((int)0xc3c5a6d7u >= (int)garr[i1 & 7u]));
                l0 = (long)((unsigned long)l0 + (unsigned)(short)(((1u | 0x8520fc21u) + 0x3f33de39u) / ((unsigned)(a0[u1 & 3u] && p1) | 1u)));
                case 6u: ;
            }
            *q0 = (i0 + (unsigned)(*mp && u2));
            c1 = (signed char)i2;
            i1 = (unsigned)(((unsigned)((unsigned)((short)5u > (signed char)a0[i0 & 3u]) || (unsigned)(x0 >> 70)) | p1) == g0) & 15u;
            r0.x = (unsigned)(signed char)((unsigned)((int)0x2933f4afu < (int)u0) * (0x42704dfdu >> (6u & 31u)));
            if ((unsigned)((int)u2 < (int)u1)) {
                w0 ^= (unsigned long long)~(v0 << ((unsigned)s0 & 31u)) << ((p2 / ((unsigned)c1 | 1u)) & 63u);
            } else {
                case 1u: ;
                switch (r0.x & 7u) {
                    break; (void)(p2);
                    for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                        goto L1;
                    }
                    d0 = d0 * 0.5 + (double)(((unsigned)(short)(i0 ^ g1) << ((unsigned)((i1 >> ((unsigned)w0 & 31u)) < g1) & 31u)) & 1023u);
                    v0 = ((i2 - 0x1bcc5cfdu) % (u0 | 1u));
                    u2 ^= 0xffffffffu;
                }
                if ((unsigned)(signed char)(8u % ((0xffffffffu & r0.x) | 1u))) continue;
                case 2u: ;
            }
        }
        break; (void)((p0 << (0x74003601u & 31u)));
        switch (((unsigned)c1 ^ ((unsigned)c1 % ((unsigned)x0 | 1u))) & 7u) {
            case 4u: ;
            case 7u: ;
            r0.y ^= (unsigned)((unsigned)f0 == (unsigned)(((unsigned)f0 ? (unsigned)s1 : 3u) < garr[i1 & 7u]));
            case 2u: ;
            default: ;
            goto L1;
        }
        switch ((unsigned)!(u0 * ((unsigned)d0 & (unsigned)(w0 >> 29))) & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn0(0x58d1449bu, (unsigned)h0, -(0xff2e3017u + (0xe9d6107u & (unsigned)b0))); }
            while (i0++ < 4u && (u0 << ((unsigned)l0 & 31u))) { if (--fuel == 0u) goto done;
                if ((unsigned)(short)(0x7fffffffu << (a0[i0 & 3u] & 31u))) {
                    while (i1++ < 7u && (unsigned)((unsigned)h0 < ((unsigned)e0 % (a0[i0 & 3u] | 1u)))) { if (--fuel == 0u) goto done;
                        { unsigned t6; double z6; if ((~(0xffffffffu ? 4u : 0x80000000u)) & 1u) { t6 = ((4u / (5u | 1u)) + p1); z6 = (double)((m0) & 255u); } if ((~(0xffffffffu ? 4u : 0x80000000u)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                            if ((unsigned)(p2 && (unsigned)h0)) break;
                            *mp = 0x8aefa758u;
                            if (budget != 0u) { budget -= 1u; u0 = fn1((0x10000u + i1), (((unsigned)c1 - u3) ^ i0), (unsigned)((unsigned)e0 < (0xfd58197fu | (unsigned)h0))); }
                        }
                        h1 = (unsigned short)(h1 + ((unsigned)((int)(unsigned)c0 >= (int)(m0 + 0xd25fd242u)) * (unsigned)(unsigned char)(*q0 | (unsigned)b0)));
                        x0 = x0 * 0x100000001b3ull + (unsigned)(0x80000000u && (unsigned)d0);
                        x0 = x0 * 0x100000001b3ull + (unsigned)c0;
                        i2 = (unsigned)!((0x10000u << (0x10000u & 31u)) ^ (unsigned)((unsigned)h1 && (unsigned)(w0 >> 29))) & 15u;
                    }
                    r0.x = (unsigned)((fuel << (garr[i1 & 7u] & 31u)) < (unsigned)h1);
                }
            }
            case 3u: ;
            u1 = u1 * 0x9e3779b1u + ((unsigned)((unsigned)d0 < (unsigned)c1) << ((u1 >> (i0 & 31u)) & 31u));
        }
        s1 = (int)((unsigned)s1 + (unsigned)((int)(i1 >> ((unsigned)(short)(garr[u2 & 7u] ? (unsigned)s0 : g0) & 31u)) < (int)5u));
        while (i0++ < 5u && (unsigned)((unsigned)c1 < (unsigned)f0)) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)((u3 + 0x10000u) ^ (unsigned)x0) < (int)*mp);
            r0.x = ((unsigned)!(*q0 * v0) * u3);
            if ((unsigned)((unsigned)h0 < (unsigned)(unsigned char)(unsigned)((unsigned)c0 == (unsigned)(x0 >> 70)))) goto done;
            *mp = (unsigned)(4u < a0[i0 & 3u]);
            c1 = (signed char)((unsigned)((short)(unsigned)h0 > (signed char)(0x7fffffffu % (3u | 1u))) | 0u);
        }
    }
    h1 = (unsigned short)(h1 + ((unsigned)(x0 >> 70) | (unsigned)(x0 >> 70)));
    if ((unsigned)(unsigned char)((unsigned)c0 / ((9u % (0x7fffffffu | 1u)) | 1u))) goto L2;
    g1 += 0x39aae528u;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(signed char)(unsigned)(m0 < (unsigned)(0x104ad29fu < (unsigned)(x0 >> 70))));
        if (budget != 0u) { budget -= 1u; u1 = fn0((3u % (u2 | 1u)), (unsigned)((int)g0 >= (int)(0x7fffffffu ^ 8u)), (unsigned)((unsigned)l0 < (unsigned)l0)); }
        u3 ^= (i0 | (p1 % ((unsigned)(signed char)(unsigned)((short)(unsigned)c0 > (signed char)(unsigned)(w0 >> 29)) | 1u)));
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *q0 += -((unsigned)(0u < m0) | (unsigned)!(8u & ((unsigned)x0 & *q0)));
    if ((0x7fffffffu + (0x2238f3f0u | 9u))) goto L3;
    h1 = (unsigned short)(h1 + ((0x80000000u ^ (unsigned)(short)((unsigned)w0 | garr[u2 & 7u])) * (unsigned)c0));
    c0 = (unsigned char)(unsigned)((unsigned)((unsigned)x0 || (unsigned)h0) && (unsigned)(x0 >> 70));
    u2 += ((u0 ? 0xde831779u : 0x63dc0c38u) & (unsigned)h1);
    u2 ^= (unsigned)((unsigned)(signed char)(unsigned)((int)0xffffffffu >= (int)(unsigned)(w0 >> 29)) < g0);
    h0 = (short)(garr[i1 & 7u] & (0x5765e7ccu ? (i1 & i0) : (unsigned)c1));
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(0x7fffffffu == (g0 & 3u))) {
            if (0x80000000u) break;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((short)5u > (signed char)(unsigned)s0), i2, (unsigned)(short)(m0 - 8u)); }
            if (budget != 0u) { budget -= 1u; u0 = fn1((0xffffffffu ^ (unsigned)f0), garr[u2 & 7u], (unsigned)((unsigned)(p2 < (unsigned)(w0 >> 29)) < r0.x)); }
        }
        continue; (void)((garr[u2 & 7u] << ((unsigned)b0 & 31u)));
        u1 ^= ((unsigned)w0 ^ (0xaf8dadb1u & 0x1de667ccu));
        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(unsigned)((unsigned)((short)u3 > (signed char)0xffffffffu) == r0.y) & 1023u);
    } while (i0++ < 7u && (unsigned)c1);
    switch (((unsigned)(x0 >> 70) | 0x389ce667u) & 7u) {
        f0 = f0 * 0.5f + (float)((unsigned)h0 & 255u);
        u3 = u3 * 0x9e3779b1u + 2u;
        case 6u: ;
    }
    goto L3;
    do { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)(g0 / (((unsigned)c1 << (1u & 31u)) | 1u));
        u1 = (unsigned)(garr[u2 & 7u] < (unsigned)(unsigned char)((unsigned)(5u < a0[i0 & 3u]) - (0xb13aa911u % ((unsigned)s0 | 1u))));
        while (i1++ < 5u && 0x2b3ffb3du) { if (--fuel == 0u) goto done;
            c1 = (signed char)5u;
        }
        q0 = &garr[((unsigned)(short)(unsigned)(0u || p1) - (unsigned)(((unsigned)d0 % (5u | 1u)) < 8u)) & 7u];
        if (budget != 0u) { budget -= 1u; u1 = fn0(p0, 6u, (unsigned)((int)r0.y < (int)(unsigned)(3u || fuel))); }
        if (0xf610d754u) break;
    } while (i0++ < 6u && (((unsigned)c0 % (8u | 1u)) % (i2 | 1u)));
    L0: if (--fuel == 0u) goto done;
    e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)h1 < (int)((unsigned)b0 * (unsigned)h0)) & 1023u);
    if ((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)(w0 >> 29))) goto L1;
    switch ((unsigned)((short)m0 > (signed char)8u) & 7u) {
        case 3u: ;
        if ((u2 * (unsigned)h1)) goto L4;
        f0 = f0 * 0.5f + (float)((unsigned)((8u / (fuel | 1u)) && ((unsigned)f0 % ((fuel << ((unsigned)(w0 >> 29) & 31u)) | 1u))) & 255u);
    }
    c1 = (signed char)0x10000u;
    if ((m0 >> (u0 & 31u))) goto L0;
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)0x10000u > (signed char)(unsigned)((short)(unsigned)f0 > (signed char)(unsigned)d0)), 3u, (unsigned)((int)0xb7ef4ff7u >= (int)0x2e9ab243u)); }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)(v0 && (unsigned)((int)p1 >= (int)r0.x)) & 7u) {
            x0 = x0 * 0x100000001b3ull + (unsigned)((short)i1 > (signed char)p2);
        }
        L1: if (--fuel == 0u) goto done;
        r0.x = (0x90f2218u / (*q0 | 1u));
        s0 = (int)(unsigned)(u3 == r0.x);
        if (u3 == 7u) return ((unsigned)((int)(m0 - i2) >= (int)((unsigned)s0 % (a0[i0 & 3u] | 1u))) / (v0 | 1u));
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        L2: if (--fuel == 0u) goto done;
        if (i1) goto L0;
        a0[(unsigned)(m0 < 0xa9792749u) & 3u] = (0x61767ac2u + ((unsigned)w0 | (unsigned)d0));
        for (;;) { if (--fuel == 0u) goto done;
            if (((unsigned)s0 * (unsigned)((int)(unsigned)h0 < (int)p1))) {
                e0 = e0 * 0.5L + (long double)((unsigned)((0x6ca23511u | (0xffffffffu | 0x916fdc74u)) == (unsigned)((int)(unsigned)e0 >= (int)0xb03aedd5u)) & 1023u);
                break; (void)((garr[i1 & 7u] >> ((unsigned)f0 & 31u)));
            } else {
                s0 = (int)(unsigned)(r0.y || (unsigned)((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)w0) < a0[i0 & 3u]));
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)(unsigned char)(unsigned)((0x10000u + 4u) && (unsigned)l0), ((unsigned)e0 % (((unsigned)c1 * 0u) | 1u)), (p1 + (unsigned)c1)); }
                break; (void)((unsigned)(signed char)(u3 * r0.y));
                s0 = (int)(unsigned)((short)0xab1047c2u > (signed char)~(unsigned)((int)5u >= (int)(unsigned)(short)(unsigned)(0x61568024u || (unsigned)f0)));
            }
            if (u2) break;
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(p1 && (0x51daff79u * 0xa371e436u)), ((unsigned)(w0 >> 29) - p0), (unsigned)((int)(i0 * 0x80000000u) >= (int)0xe49b859u)); }
            break; (void)((*q0 | 0x6bba41b2u));
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((int)v0 >= (int)v0)) break;
                a0[garr[i1 & 7u] & 3u] = (r0.x << ((unsigned)h0 & 31u));
            } while (i2++ < 4u && (unsigned)(g0 == g0));
            v0 = ((0x75a9826du & (unsigned)((unsigned)h1 == 0x7fffffffu)) >> ((p1 + (unsigned)w0) & 31u));
        }
        if ((unsigned)c0) {
            if ((unsigned)((int)a0[i0 & 3u] >= (int)0xcad8bd05u)) break;
            if ((i2 % ((unsigned)h0 | 1u))) break;
            if (budget != 0u) { budget -= 1u; u1 = fn2(((0x7fffffffu + 8u) << (p0 & 31u)), (8u & 0xe8cd770du), (0x80000000u << (0x81594144u & 31u))); }
            u2 = u2 * 0x9e3779b1u + ((unsigned)w0 & g0);
            if (g0) goto L3;
            if (fuel < 8u) return r0.y;
        }
    }
    goto L4;
    *q0 += (unsigned)((int)(p0 + 0u) >= (int)(0x80000000u & 2u));
    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)e0, (unsigned)(1u || (unsigned)f0), (unsigned)f0); }
    if ((unsigned)((short)(unsigned)h1 > (signed char)(unsigned)(w0 >> 29))) {
        if (u3 == 7u) return (unsigned)((unsigned)((int)0x10000u >= (int)(unsigned)(w0 >> 29)) && (v0 * 0x6217979eu));
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 5u && -((g1 >> (u2 & 31u)) & 0x894ff954u)) { if (--fuel == 0u) goto done;
                u0 += (*q0 | 0x10000u);
            }
        }
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            u2 += ((unsigned)c0 ? (unsigned)(m0 < garr[i1 & 7u]) : (r0.x % (0x349fe09du | 1u)));
            f0 = f0 * 0.5f + (float)(((unsigned)w0 >> (0xb4d79f1du & 31u)) & 255u);
            L3: if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if (((unsigned)l0) & 1u) { t0 = (unsigned)(signed char)((unsigned)c0 & (unsigned)l0); z0 = (double)(((unsigned)((int)(unsigned)s0 >= (int)i1)) & 255u); } if (((unsigned)l0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                while ((unsigned)(garr[u2 & 7u] == (unsigned)s1)) { if (--fuel == 0u) goto done;
                    switch ((unsigned)((short)3u > (signed char)u3) & 7u) {
                        if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)!(unsigned)((short)(unsigned)x0 > (signed char)(*q0 * (unsigned)e0)), (unsigned)((int)(unsigned)((short)(unsigned)c0 > (signed char)p1) >= (int)(unsigned)s0), (unsigned)(u0 == 0x619c3179u)); }
                    }
                    if ((unsigned)x0) break;
                    d0 = d0 * 0.5 + (double)((p1 ^ (p2 & *mp)) & 1023u);
                    r0.x = (1u * r0.y);
                    s1 = (int)((unsigned)s1 + r0.y);
                }
            }
            switch ((6u / ((unsigned)((int)0x7fffffffu < (int)u0) | 1u)) & 7u) {
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)(signed char)(unsigned)((short)0xb5a93cb4u > (signed char)(unsigned)(x0 >> 70)) >= (int)a0[i0 & 3u]);
                garr[(0x7fffffffu + (unsigned)d0) & 7u] = 6u;
                if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)h0 << ((unsigned)((int)r0.x >= (int)p0) & 31u)), (unsigned)w0, 0xf22b4028u); }
            }
            if (u3) {
                r0.y ^= (u0 >> (((unsigned)((short)fuel > (signed char)p2) & (unsigned)f0) & 31u));
                w0 ^= (unsigned long long)(unsigned)(*mp == (unsigned)s1) << ((unsigned)((int)0xe7c8c54au < (int)(unsigned)s0) & 63u);
                w0 = w0 * 6364136223846793005ull + (-((unsigned)((int)(unsigned)x0 >= (int)garr[u2 & 7u]) / (i0 | 1u)) - (unsigned)((int)r0.y < (int)i0));
                if ((p1 ^ (unsigned)((short)a0[u1 & 3u] > (signed char)0xffffffffu))) {
                    g0 = 0u;
                    u1 += (unsigned)(0u == (unsigned)h0);
                    { unsigned t1; double z1; if ((0x10000u) & 1u) { t1 = (unsigned)c0; z1 = (double)((((unsigned)((int)p1 < (int)a0[u1 & 3u]) | 0xa87fef0eu)) & 255u); } if ((0x10000u) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                        if (u1) break;
                    }
                    f0 = f0 * 0.5f + (float)(u2 & 255u);
                } else {
                    s1 = (int)((unsigned)s1 + (unsigned)w0);
                    L4: if (--fuel == 0u) goto done;
                }
                *q0 += ((unsigned)(0xffffffffu == (unsigned)(0x8e04b96bu || 0x10000u)) << (p1 & 31u));
            } else {
                *q0 += (unsigned)((unsigned)b0 && (((p1 % ((unsigned)b0 | 1u)) - (unsigned)c1) << ((unsigned)e0 & 31u)));
            }
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)(0x16a6e910u == (unsigned)d0));
        }
        g1 += -(r0.x << (0x7fffffffu & 31u));
    } else {
        w0 ^= (unsigned long long)(unsigned)((int)(unsigned)x0 >= (int)p2) << ((unsigned)s0 & 63u);
        do { if (--fuel == 0u) goto done;
            { unsigned t2; double z2; if (((unsigned)c0) & 1u) { t2 = (unsigned)((int)(unsigned)h1 >= (int)(unsigned)s1); z2 = (double)(((unsigned)((int)*mp < (int)((unsigned)d0 * v0))) & 255u); } if (((unsigned)c0) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                if ((0x80000000u / (((unsigned)c0 >> ((unsigned)f0 & 31u)) | 1u))) break;
                *q0 += (unsigned)!((0xffffffffu << (i1 & 31u)) & r0.y);
                if (0xffffffffu) goto L4;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)garr[i1 & 7u] > (signed char)-(unsigned)((unsigned)d0 || fuel)), (4u >> ((unsigned)c0 & 31u)), *q0); }
            *q0 += (m0 >> (((unsigned)x0 + *mp) & 31u));
            i0 = (unsigned)((int)*q0 >= (int)(p0 % (garr[u2 & 7u] | 1u))) & 15u;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (unsigned)f0;
                b0 = (unsigned)(((unsigned)l0 & 5u) == m0) != 0u;
                goto L2;
                a0[(unsigned)(signed char)((unsigned)s1 >> ((unsigned)(x0 >> 70) & 31u)) & 3u] = (unsigned)((unsigned)((short)(unsigned)(garr[u2 & 7u] < g1) > (signed char)garr[i1 & 7u]) < (unsigned)((unsigned)h0 || (unsigned)x0));
                if ((unsigned)((unsigned)w0 == 0xab6d27b0u)) goto L2;
            }
            u2 += ((a0[i0 & 3u] | (unsigned)((int)(unsigned)w0 >= (int)m0)) + i1);
        } while (i0++ < 2u && (6u >> (((unsigned)h0 / (p0 | 1u)) & 31u)));
    }
    goto done;
    if ((unsigned)(unsigned char)(0x385fa1a6u % (r0.x | 1u))) {
        if (a0[i0 & 3u]) goto L0;
        do { if (--fuel == 0u) goto done;
            switch ((1u | 0xffffffffu) & 7u) {
                while (i1++ < 3u && ((unsigned)w0 - 0x80000000u)) { if (--fuel == 0u) goto done;
                    c1 = (signed char)(0xb2ddde3au ^ (unsigned)((int)(unsigned)((int)0x3dff1cabu < (int)5u) >= (int)-(0x7fffffffu ^ (unsigned)h1)));
                    { unsigned t3; double z3; if (((0x80000000u ^ i0)) & 1u) { t3 = ((unsigned)s0 | (unsigned)(signed char)(unsigned)((int)a0[u1 & 3u] < (int)garr[i1 & 7u])); z3 = (double)((0u) & 255u); } if (((0x80000000u ^ i0)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                        goto L4;
                    }
                }
            }
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(8u == (unsigned)l0)) break;
            }
            if ((unsigned)(0x7fffffffu == (unsigned)d0)) break;
            if ((unsigned)(unsigned char)(unsigned)((3u + fuel) == p2)) break;
            while ((unsigned)(short)(unsigned)((int)0x7d92349au < (int)0xd6871e1au)) { if (--fuel == 0u) goto done;
                goto L2;
                v0 = -((unsigned)((int)(unsigned)((int)p1 >= (int)(7u << ((unsigned)(x0 >> 70) & 31u))) >= (int)u0) / (*mp | 1u));
                if (0x71e60e78u) continue;
                if ((unsigned)(0x48c4e628u && garr[u2 & 7u])) {
                    do { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)(i0 & 255u);
                    } while (i2++ < 7u && 2u);
                    for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)(unsigned char)(unsigned)(0xeff6ddfdu || m0)) {
                            *q0 = -(1u + 9u);
                            u2 += ((0xa963d3a7u ^ 0x5240a4d7u) << ((0x5f145b73u >> (p1 & 31u)) & 31u));
                            if (-(0x10000u >> ((unsigned)((int)(unsigned)b0 < (int)0x86354085u) & 31u))) continue;
                            e0 = e0 * 0.5L + (long double)((unsigned)w0 & 1023u);
                            if ((0x91da2584u % ((i2 + p1) | 1u))) break;
                            if (u3 == 7u) return v0;
                        }
                        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                            a0[(unsigned)s0 & 3u] = (unsigned)((unsigned)s1 == u1);
                            a0[u3 & 3u] = r0.y;
                            break; (void)((p2 ? 2u : i0));
                        }
                    }
                } else {
                    if (budget != 0u) { budget -= 1u; u0 = fn2((0x59cd471fu - (4u % ((unsigned)c0 | 1u))), (unsigned)((short)(unsigned)e0 > (signed char)0xffffffffu), (unsigned)((unsigned)(garr[i1 & 7u] || (unsigned)(x0 >> 70)) || u3)); }
                    g1 += 0x241f37a3u;
                    break; (void)((0xdb85e4e0u % (0x10000u | 1u)));
                    if (budget != 0u) { budget -= 1u; u1 = fn0(u0, p1, ((p1 - a0[u1 & 3u]) + (unsigned)c1)); }
                }
                if ((unsigned)h1) {
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)b0, (unsigned)(p0 == (0xa2ea29b6u & u2)), ((unsigned)(0x10000u < garr[u2 & 7u]) | p1)); }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((0x10000u ^ (unsigned)((int)(unsigned)h1 < (int)u0)), ~(unsigned)(0x7fffffffu || (unsigned)!(unsigned)((unsigned)s0 < 8u)), (v0 >> (0x10000u & 31u))); }
                    v0 = (unsigned)!(unsigned)((int)(unsigned)l0 < (int)(unsigned)((int)0x1e0acef3u < (int)a0[u1 & 3u]));
                    w0 ^= (unsigned long long)0x8610104u << ((unsigned)(unsigned char)((unsigned)((unsigned)f0 && 0x4462fa57u) % ((m0 & 0x843dd665u) | 1u)) & 63u);
                    switch (~(((unsigned)(w0 >> 29) ^ g1) | (unsigned)c0) & 7u) {
                        l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(unsigned)((short)(r0.y ^ ((unsigned)s1 / ((unsigned)((int)v0 >= (int)p0) | 1u))) > (signed char)0x80000000u));
                        if (budget != 0u) { budget -= 1u; u0 = fn2((0xe32d85d7u << ((unsigned)(short)((unsigned)b0 >> ((unsigned)h0 & 31u)) & 31u)), ((unsigned)c1 % (garr[u2 & 7u] | 1u)), (unsigned)h1); }
                        m0 ^= (*q0 ^ (unsigned)(r0.x < garr[u2 & 7u]));
                    }
                }
            }
        } while (i0++ < 7u && (unsigned)h0);
        if (budget != 0u) { budget -= 1u; u0 = fn0(i2, (unsigned)(r0.x && (unsigned)(g1 < 0x10000u)), (unsigned)(unsigned char)(unsigned)((short)5u > (signed char)(unsigned)b0)); }
        h0 = (short)0x7fffffffu;
    }
    *q0 = (7u - 0x77ab4acfu);
    u0 += (unsigned)((unsigned)((int)(unsigned)((unsigned)h0 == *q0) < (int)fuel) && (g0 ^ (unsigned)c0));
    u2 += (unsigned)((int)(r0.x + u0) >= (int)(garr[i1 & 7u] * (unsigned)f0));
    if (m0) goto L0;
    do { if (--fuel == 0u) goto done;
        switch (0xe3314c7du & 7u) {
            g1 += (unsigned)((int)((unsigned)(p2 || 3u) | garr[i1 & 7u]) >= (int)(u2 << (0xce47c6a2u & 31u)));
            l0 = (long)((unsigned long)l0 + (unsigned)(a0[u1 & 3u] || (7u * p0)));
            case 6u: ;
        }
        if (((unsigned)b0 + 0x10000u)) {
            garr[((unsigned)(x0 >> 70) | i0) & 7u] = (unsigned)(u2 || r0.y);
            r0.x = (((unsigned)(w0 >> 29) & v0) & (unsigned)((int)(unsigned)x0 >= (int)a0[i0 & 3u]));
        }
        if (0x7924f1afu) goto L0;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (3u << (((0xba748au - p0) + (0x71014550u ^ a0[i0 & 3u])) & 31u)));
            goto L0;
            continue; (void)(0xffffffffu);
        }
    } while (i0++ < 5u && (unsigned)f0);
    if ((unsigned)((int)(unsigned)h1 < (int)r0.y)) goto L0;
    if ((0x10000u | 0x7fffffffu)) goto L3;
    c0 = (unsigned char)(((i0 >> (((unsigned)d0 & 0x6e0c6736u) & 31u)) ^ (unsigned)c0) + 0xffffffffu);
    goto L1;
    i0 = ((unsigned)((int)(unsigned)h0 < (int)v0) / (u1 | 1u)) & 15u;
    s0 = (int)(unsigned)(garr[i1 & 7u] < g0);
    i2 = p2 & 15u;
    { unsigned t4; double z4; if (((unsigned)s0) & 1u) { t4 = (p2 | i2); z4 = (double)((fuel) & 255u); } if (((unsigned)s0) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        { unsigned t5; double z5; if (((u3 / (a0[u1 & 3u] | 1u))) & 1u) { t5 = (unsigned)c1; z5 = (double)((7u) & 255u); } if (((u3 / (a0[u1 & 3u] | 1u))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
            q0 = &garr[(unsigned)(signed char)(p0 & (unsigned)((int)i0 >= (int)(unsigned)e0)) & 7u];
            if ((p1 ^ (unsigned)h0)) goto L2;
            if ((i1 >> (0xffffffffu & 31u))) goto done;
            if ((unsigned)(short)((unsigned)h1 / (0xffffffffu | 1u))) {
                g1 += u3;
                *q0 += 0x5318ae1du;
                l0 = (long)((unsigned long)l0 + ((unsigned)s1 ^ 0xb6d46578u));
                if ((p1 ^ 0xb8b0bc12u)) goto L1;
            }
        }
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)(u3 || -((unsigned)s0 - 0x1010f14eu)) & 255u);
                if (u3 == 7u) return 0x7fffffffu;
                *mp = (a0[i0 & 3u] ^ (unsigned)((int)(unsigned)c0 < (int)2u));
                if (budget != 0u) { budget -= 1u; u1 = fn2(-(unsigned)((unsigned)(p1 || 2u) || p2), ((p2 - 0x7fffffffu) / (u3 | 1u)), (unsigned)((short)(unsigned)h1 > (signed char)p2)); }
            }
        }
        g0 = (unsigned)(unsigned char)(0x80000000u | m0);
    }
    if ((0u >> (fuel & 31u))) goto L3;
    switch ((unsigned)((int)r0.x >= (int)u2) & 7u) {
        w0 ^= (unsigned long long)p2 << ((unsigned)(x0 >> 70) & 63u);
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = (0x948f9484u ^ 0x70a896ceu);
        if ((~((unsigned)x0 ^ (unsigned)h0) / (0xffffffffu | 1u))) continue;
    }
    x0 = x0 * 0x100000001b3ull + ((u3 * (unsigned)x0) / ((unsigned)(garr[i1 & 7u] && (unsigned)l0) | 1u));
    if ((unsigned)(u2 || garr[u2 & 7u])) goto L4;
    while (g1) { if (--fuel == 0u) goto done;
        if ((u0 * ((unsigned)w0 >> (*q0 & 31u)))) continue;
        { unsigned t6; double z6; if ((((unsigned)h1 / (0xc1c40159u | 1u))) & 1u) { t6 = (unsigned)(p2 < (unsigned)h1); z6 = (double)(((0xffffffffu ? *q0 : r0.y)) & 255u); } if ((((unsigned)h1 / (0xc1c40159u | 1u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            q0 = &garr[((unsigned)b0 * (m0 >> (v0 & 31u))) & 7u];
            if (1u) break;
            while (((unsigned)(w0 >> 29) * 0x80000000u)) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (m0 / ((unsigned)(short)(0x80000000u ? (unsigned)e0 : 0x80000000u) | 1u)) != 0u;
                    if ((unsigned)c1) continue;
                    goto L0;
                    u0 ^= (unsigned)(0x10000u < ~(unsigned)((unsigned)(i2 || 0xf8b9b0c3u) || i1));
                }
                do { if (--fuel == 0u) goto done;
                    if (((unsigned)d0 | 0x40caef67u)) goto L3;
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)7u >= (int)p1), ((unsigned)w0 - (unsigned)((int)5u >= (int)(unsigned)(w0 >> 29))), (unsigned)(signed char)(r0.x * 0x2d40dc13u)); }
                    u2 += ((unsigned)((p0 >> (0x752e1e24u & 31u)) == (unsigned)(x0 >> 70)) / (0x10000u | 1u));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(0x10000u * u2) >= (int)(unsigned)s1), ((7u + 8u) * v0), (p0 % (r0.x | 1u))); }
                    if (p1) continue;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)d0 < (int)a0[u1 & 3u]), (unsigned)c0, (*mp + (unsigned)d0)); }
                } while (i2++ < 4u && (unsigned)(short)((unsigned)((int)i2 < (int)0xecf26b16u) >> ((unsigned)s0 & 31u)));
            }
            if ((u0 & (unsigned)(signed char)(r0.x | *mp))) continue;
            m0 ^= ((i1 << (a0[u1 & 3u] & 31u)) % ((i1 | 0x7fffffffu) | 1u));
            if (((unsigned)s0 ^ (unsigned)h0)) break;
        }
        if ((0x10000u ? p0 : p1)) {
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn2(i1, (unsigned)(signed char)(0x80000000u | (unsigned)w0), 0xb5cc4628u); }
                do { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        r0.x = (unsigned)(((u0 + v0) % ((unsigned)b0 | 1u)) == (unsigned)s0);
                        break; (void)(((unsigned)h1 % ((unsigned)((unsigned)x0 == (unsigned)f0) | 1u)));
                        w0 = w0 * 6364136223846793005ull + (((unsigned)!(unsigned)((int)(unsigned)h1 < (int)(unsigned)c0) * i0) >> ((3u * (unsigned)c0) & 31u));
                        do { if (--fuel == 0u) goto done;
                            if (-(r0.y % (0u | 1u))) break;
                        } while (i1++ < 7u && v0);
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(unsigned char)(unsigned)(((unsigned)b0 + *q0) == r0.y), (unsigned)(((unsigned)c0 >> (g0 & 31u)) && 6u), (unsigned)(short)((unsigned)s0 * i0)); }
                    } while (i0++ < 2u && (unsigned)((unsigned)f0 && (unsigned)s1));
                    x0 = x0 * 0x100000001b3ull + (unsigned)((int)v0 >= (int)1u);
                    v0 = (unsigned)(((unsigned)((short)0x80000000u > (signed char)0xabf15912u) - (unsigned)(w0 >> 29)) < garr[u2 & 7u]);
                    if (r0.y) goto L0;
                } while (i2++ < 6u && ((unsigned)l0 % (i0 | 1u)));
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (0x7fffffffu) continue;
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)f0 == 9u);
            }
            if (r0.x) break;
            if (6u) goto L2;
            break; (void)(((unsigned)s1 - 0x8a913643u));
            goto L1;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)(((unsigned)w0 >> ((unsigned)h1 & 31u)) < (unsigned)e0), i0, u3); }
    }
    if ((unsigned)(((unsigned)s1 >> (0x5c55c7bu & 31u)) || (unsigned)b0)) goto L3;
    goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 9u, 0xab7fb995u, 0x127f7377u },
        { 9u, 0x70d93e1u, 0xc86daffu },
        { 3u, 0x78f39f74u, 0xb17a6f28u },
        { 1u, 0x926ae14bu, 0x5a0005f6u },
        { 4u, 0xed22daddu, 0x32eb10b6u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
