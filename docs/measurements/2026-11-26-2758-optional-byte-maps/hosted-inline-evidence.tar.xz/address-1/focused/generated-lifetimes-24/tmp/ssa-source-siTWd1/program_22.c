// test-ssa-source's program of seed 141000445 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xff4398b7u, g1 = 0x1b4e633au;
static unsigned garr[8] = { 0x35aa89e0u, 0x48d5c484u, 0xb0afb70fu, 0x756e8db7u, 0x2b832269u, 0x22a6ca21u, 0x540b4fd3u, 0x39e9ba43u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    while (i0++ < 5u && g1) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        u2 = u2 * 0x9e3779b1u + (unsigned)((short)(unsigned)e0 > (signed char)0x7fffffffu);
        if (g1) {
            switch (((unsigned)s0 - ((unsigned)s0 << (0x80000000u & 31u))) & 7u) {
                u2 = u2 * 0x9e3779b1u + ((unsigned)((int)(unsigned)w0 >= (int)(unsigned)((unsigned)x0 == u0)) | (unsigned)((int)(unsigned)l0 >= (int)garr[i1 & 7u]));
                if (0x7fffffffu) {
                    if ((0x7fffffffu - p0)) break;
                    L1: if (--fuel == 0u) goto done;
                    case 3u: ;
                    case 0u: ;
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + (((*q0 >> (u2 & 31u)) + (unsigned)c0) >> (((unsigned)h1 ^ (unsigned)l0) & 31u)));
                        w0 ^= (unsigned long long)i0 << ((unsigned)c1 & 63u);
                        if (0x1ba61d7bu) break;
                        s0 = (int)-((unsigned)((int)(unsigned)(i0 && u0) >= (int)0xd7d7c89du) % (0x4bea3c86u | 1u));
                        if ((unsigned)((int)(unsigned)x0 >= (int)i1)) goto L1;
                    }
                    a0[(garr[u2 & 7u] / ((unsigned)c1 | 1u)) & 3u] = (unsigned)w0;
                } else {
                    e0 = e0 * 0.5L + (long double)((unsigned)!(unsigned)((unsigned)(unsigned char)(unsigned)(0x98f9d506u == 0xbd45ef2eu) || u0) & 1023u);
                    for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        u2 ^= ~(((unsigned)c1 % (a0[i0 & 3u] | 1u)) | 3u);
                        L2: if (--fuel == 0u) goto done;
                        L3: if (--fuel == 0u) goto done;
                        if ((unsigned)(short)(0x37dbf11au + -(unsigned)(i0 < i0))) continue;
                        default: ;
                        if (fuel < 8u) return p1;
                    }
                    if ((unsigned)(short)(unsigned)((short)(a0[i0 & 3u] >> (9u & 31u)) > (signed char)u2)) {
                        if ((unsigned)(signed char)(a0[i0 & 3u] ^ (unsigned)((unsigned)l0 && 0x6a7859f0u))) goto L4;
                        break;
                        continue; (void)((2u | 0x81638ddau));
                        l0 = (long)((unsigned long)l0 + (5u ? (unsigned)((int)0x80000000u >= (int)0x7fffffffu) : (unsigned)l0));
                        v0 = (0x7fce216bu * (0xb6a69e99u / ((unsigned)d0 | 1u)));
                        if (fuel < 8u) return (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)(m0 == fuel));
                    } else {
                        h1 = (unsigned short)(h1 + (unsigned)(short)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)u0));
                    }
                    break;
                }
                d0 = d0 * 0.5 + (double)((unsigned)(9u == 0x617206e1u) & 1023u);
                { unsigned t0; double z0; if (((unsigned)((int)(unsigned)(w0 >> 29) >= (int)a0[i0 & 3u])) & 1u) { t0 = (*mp ? i1 : u3); z0 = (double)((((unsigned)x0 - (unsigned)((int)0xe0eded69u >= (int)(unsigned)s1))) & 255u); } if (((unsigned)((int)(unsigned)(w0 >> 29) >= (int)a0[i0 & 3u])) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                    w0 = w0 * 6364136223846793005ull + (((9u / (3u | 1u)) * (unsigned)s1) - (unsigned)((int)0x939783e5u >= (int)u0));
                    if (5u) break;
                    h1 = (unsigned short)(h1 + ((unsigned)f0 ? a0[i0 & 3u] : (p1 + 0x7fffffffu)));
                    garr[i1 & 7u] = ((0xfa9addb6u | 0u) / (r0.y | 1u));
                    switch ((unsigned)(unsigned char)(unsigned)((0x7fffffffu / (0x7fffffffu | 1u)) == a0[i0 & 3u]) & 7u) {
                        if ((unsigned)(short)((unsigned)((int)(unsigned)b0 >= (int)(unsigned)e0) ^ (unsigned)w0)) goto L4;
                    }
                }
                s0 = (int)(unsigned)((*mp + 0xbe55b91fu) && (unsigned)((unsigned)(w0 >> 29) < p0));
                u3 += (unsigned)((int)u1 >= (int)(0x10000u ? r0.y : (g1 * garr[u2 & 7u])));
            }
            { unsigned t1; double z1; if ((r0.x) & 1u) { t1 = (0xffffffffu % (u0 | 1u)); z1 = (double)(((unsigned)(0x69a80b14u == 0xa2f47f62u)) & 255u); } if ((r0.x) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                continue; (void)(3u);
                l0 = (long)((unsigned long)l0 + ((unsigned)((short)i2 > (signed char)(p2 % ((unsigned)(i1 == (unsigned)h0) | 1u))) >> (0x9074c1edu & 31u)));
                r0.x = (unsigned)(unsigned char)(unsigned)(i1 < p0);
                a0[garr[u2 & 7u] & 3u] = (8u % ((0xffffffffu + ((unsigned)w0 % (0xffffffffu | 1u))) | 1u));
                L4: if (--fuel == 0u) goto done;
                if (0xffffffffu) continue;
            }
            if ((unsigned)((unsigned)((int)(unsigned)f0 >= (int)m0) < u1)) break;
            u1 += ((unsigned)e0 << (0x7fffffffu & 31u));
        }
        m0 ^= (unsigned)((int)(((unsigned)(0x80000000u == 0x80000000u) / ((unsigned)w0 | 1u)) + (unsigned)d0) < (int)(unsigned)c0);
        if ((unsigned)((unsigned)(x0 >> 70) == u0)) break;
        garr[((unsigned)(w0 >> 29) ^ *mp) & 7u] = r0.x;
    }
    if (0xa30adfcbu) goto L1;
    if (((unsigned)((int)g1 >= (int)(unsigned)c0) * r0.x)) goto done;
    goto L2;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)((a0[u1 & 3u] + u3) < 9u)) {
            h1 = (unsigned short)(h1 + a0[i0 & 3u]);
            if ((unsigned)(4u < 0xffffffffu)) break;
            if ((0xbf1692c9u & (unsigned)d0)) break;
            if (u3 == 7u) return i0;
            if ((unsigned)w0) break;
        } else {
            d0 = d0 * 0.5 + (double)(((unsigned)d0 | (unsigned)(p2 || 7u)) & 1023u);
            x0 = x0 * 0x100000001b3ull + ((unsigned)(signed char)(unsigned)(0x5ab4480cu < i2) - ((unsigned)(w0 >> 29) << (((unsigned)h0 ^ (unsigned)c1) & 31u)));
            *q0 = (unsigned)(0x2482ab92u || (unsigned)(short)(((unsigned)s1 + 0xffffffffu) - (i2 - (unsigned)s1)));
            if (0x3d4f699eu) break;
        }
        if ((p0 << ((unsigned)!(0xfeb354bau | r0.y) & 31u))) {
            if ((unsigned)s0) break;
            break; (void)((unsigned)(unsigned char)(unsigned)((int)0xd904b1b7u < (int)(unsigned)x0));
            if (u3 == 7u) return ((0x7fffffffu ^ i0) >> ((fuel - (m0 - 0x80000000u)) & 31u));
            if (-(0x30fa235bu << ((unsigned)l0 & 31u))) continue;
            break; (void)((unsigned)(w0 >> 29));
        } else {
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)(r0.x + ((unsigned)b0 >> (((0x1883e726u | m0) ^ a0[i0 & 3u]) & 31u)));
                }
                if ((unsigned)c0) break;
                q0 = &garr[0xb8fcb8bdu & 7u];
                if (((unsigned)c0 + ((unsigned)c0 | u1))) break;
            }
        }
        w0 = w0 * 6364136223846793005ull + (unsigned)((int)(0xc29d0acbu / (i1 | 1u)) >= (int)(unsigned)(unsigned char)((*q0 | 0u) | v0));
        if (fuel < 8u) return (unsigned)((int)((unsigned)(fuel || u2) >> (m0 & 31u)) >= (int)(r0.y * (unsigned)(w0 >> 29)));
        switch (~(0x307716b6u & fuel) & 7u) {
            m0 ^= ~(0xc7fc35f0u ? a0[u1 & 3u] : 0x7fffffffu);
            case 0u: ;
            if (a0[u1 & 3u]) goto L3;
            do { if (--fuel == 0u) goto done;
                r0.y ^= (garr[i1 & 7u] + (unsigned)s0);
                c0 = (unsigned char)(unsigned)((short)p1 > (signed char)((0x7fffffffu ? p1 : (unsigned)(x0 >> 70)) - p2));
                if (((unsigned)d0 & (p2 << (v0 & 31u)))) break;
                if ((unsigned)!((2u | i2) / (0u | 1u))) break;
                if ((garr[u2 & 7u] - (unsigned)(signed char)(garr[u2 & 7u] & v0))) continue;
                e0 = e0 * 0.5L + (long double)(5u & 1023u);
            } while (i1++ < 4u && ((unsigned)((unsigned)s1 < 0x73e5c176u) - 0x64f5778cu));
        }
        break; (void)((unsigned)(*mp < 0x10000u));
    }
    u1 += ((unsigned)(g1 == (unsigned)((int)0u >= (int)i1)) + i2);
    goto L0;
    u0 ^= ((unsigned)b0 << ((unsigned)(0x536ee830u || 0x7fffffffu) & 31u));
    r0.x = 0xffffffffu;
    if ((unsigned)((short)(unsigned)((unsigned)x0 && p0) > (signed char)fuel)) goto done;
    garr[u2 & 7u] = ((u2 * (unsigned)h1) & u0);
    r0.y ^= ((unsigned)(u2 == fuel) / (i2 | 1u));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((0xf6762ca7u >> ((v0 >> (a0[i0 & 3u] & 31u)) & 31u))) continue;
    }
    if ((unsigned)((unsigned)x0 < m0)) goto L2;
    switch ((unsigned)(*mp == m0) & 7u) {
        g1 += (unsigned)(0xef85ec8u < ((unsigned)w0 | (unsigned)!(unsigned)(p2 && 0u)));
        case 1u: ;
        case 6u: ;
        if (0xffffffffu) break;
        case 7u: ;
        if ((r0.y - (m0 * m0))) {
            b0 = (unsigned)((int)p1 < (int)(i2 % (i1 | 1u))) != 0u;
            r0.x = (unsigned)(short)(1u >> ((unsigned)((int)p0 < (int)(unsigned)(p0 < m0)) & 31u));
            case 0u: ;
            case 3u: ;
            do { if (--fuel == 0u) goto done;
                r0.y ^= (unsigned)l0;
                d0 = d0 * 0.5 + (double)(0x1d0bc585u & 1023u);
            } while (i0++ < 5u && (0x39c2d2d3u ^ 0x4308dfd8u));
            case 4u: ;
        }
    }
    garr[(u1 * 7u) & 7u] = 0x347de58du;
    if (-(0xec6036c7u & 0x10000u)) goto L4;
    h0 = (short)((unsigned)((short)(unsigned)s1 > (signed char)0x8ccfab94u) & ((3u << ((unsigned)c0 & 31u)) / (g0 | 1u)));
    goto done;
    if (u0) goto L2;
    for (;;) { if (--fuel == 0u) goto done;
        g1 += a0[u1 & 3u];
        switch ((unsigned)((unsigned)((short)0u > (signed char)8u) < u2) & 7u) {
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 7u: ;
                default: ;
                case 0u: ;
                u1 = (unsigned)(signed char)((unsigned)(u3 < 6u) >> ((unsigned)((int)3u >= (int)u0) & 31u));
                case 5u: ;
            }
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    u0 ^= ((u3 + 0x2dee6fcdu) & g0);
                    case 2u: ;
                    case 3u: ;
                    d0 = d0 * 0.5 + (double)((unsigned)(a0[i0 & 3u] || (unsigned)((unsigned)(w0 >> 29) < (unsigned)s0)) & 1023u);
                }
                c1 = (signed char)-((unsigned)(w0 >> 29) >> ((unsigned)!(unsigned)((int)(unsigned)s1 >= (int)p0) & 31u));
                break;
            }
            r0.x = (unsigned)(((unsigned)c0 ? (unsigned)s1 : (unsigned)(x0 >> 70)) || 0xa37a21bdu);
            while (i1++ < 6u && (0xcd170937u - 4u)) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= r0.y;
                    c0 = (unsigned char)(((unsigned)c1 & 0xffffffffu) % ((unsigned)(0x80000000u || *q0) | 1u));
                    a0[(0xb2c5b29bu % ((unsigned)h0 | 1u)) & 3u] = (unsigned)((short)r0.x > (signed char)(4u | 0x2b8fb7bcu));
                    if ((unsigned)(w0 >> 29)) continue;
                    u1 = u1 * 0x9e3779b1u + ((*mp & (unsigned)c1) % ((unsigned)(0x7fffffffu == ~((unsigned)c1 & garr[i1 & 7u])) | 1u));
                    g1 += (unsigned)((unsigned)(0x10000u && 0x7fffffffu) < 0xce397f92u);
                }
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(u2 && (unsigned)x0) && 0xd7da6f58u) & 1023u);
                d0 = d0 * 0.5 + (double)((unsigned)l0 & 1023u);
                l0 = (long)((unsigned long)l0 + ((unsigned)h1 ? (unsigned)x0 : (unsigned)c0));
                break;
                garr[((unsigned)s0 >> (i2 & 31u)) & 7u] = p1;
            }
        }
        *q0 = (unsigned)((int)(g1 | ~(unsigned)((int)g1 < (int)r0.x)) >= (int)~((unsigned)h0 | v0));
        break; (void)(((unsigned)h0 % (u2 | 1u)));
    }
    if ((unsigned)(short)(v0 * u0)) goto L0;
    x0 = x0 * 0x100000001b3ull + (3u - 0x10000u);
    if ((unsigned)s1) {
        if (((unsigned)h1 % (r0.y | 1u))) goto L4;
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (a0[u1 & 3u]) goto done;
            goto L1;
        }
        s1 = (int)((unsigned)s1 + ((unsigned)c1 * g1));
        if (garr[u2 & 7u]) {
            h1 = (unsigned short)(h1 + (unsigned)(unsigned char)((unsigned)c1 << ((unsigned)((unsigned)f0 && (unsigned)e0) & 31u)));
            if (0xffffffffu) {
                if (0x3863c6fbu) goto done;
                s0 = (int)(unsigned)((int)(unsigned)((short)(p0 * 0x80000000u) > (signed char)u3) < (int)(*q0 & i0));
            } else {
                while (i0++ < 6u && p2) { if (--fuel == 0u) goto done;
                    if ((unsigned)(6u < (unsigned)f0)) break;
                    if (0xfdad6c8du) break;
                    break; (void)((unsigned)(a0[i0 & 3u] && (unsigned)(w0 >> 29)));
                }
                u0 = u0 * 0x9e3779b1u + ((unsigned)!(unsigned)((short)5u > (signed char)0x9c7071aau) - (0xf208facu ? 0x10000u : i2));
            }
            r0.y ^= (unsigned)((unsigned)((short)(unsigned)d0 > (signed char)0x9b676b36u) || (unsigned)(w0 >> 29));
            switch ((unsigned)c1 & 7u) {
                b0 = (unsigned)(6u && p2) != 0u;
                case 5u: ;
                while (i0++ < 6u && (unsigned)(4u == 0x10000u)) { if (--fuel == 0u) goto done;
                    b0 = ((((unsigned)s1 / (garr[u2 & 7u] | 1u)) ^ ((unsigned)x0 >> (7u & 31u))) % ((unsigned)s1 | 1u)) != 0u;
                    if ((unsigned)((unsigned)f0 && (unsigned)x0)) goto L0;
                    if (fuel < 8u) return u2;
                    c0 = (unsigned char)1u;
                }
                if ((unsigned)(short)(g1 * *mp)) break;
                case 7u: ;
            }
        } else {
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((0x4ca055d2u - u1)) break;
                goto L0;
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)w0) break;
                    if ((p2 | u3)) break;
                    switch ((unsigned)((short)0xffffffffu > (signed char)(unsigned)f0) & 7u) {
                        case 0u: ;
                        if ((unsigned)c1) continue;
                        case 5u: ;
                        if (fuel) {
                            if ((unsigned)(r0.y < a0[u1 & 3u])) break;
                            case 3u: ;
                            w0 ^= (unsigned long long)p2 << ((0x4539bd09u - (unsigned)(w0 >> 29)) & 63u);
                            *q0 = ((unsigned)(short)(unsigned)(u3 && 5u) + (-(i0 << (p0 & 31u)) | garr[u2 & 7u]));
                            q0 = &garr[(unsigned)(signed char)(r0.x - (unsigned)(short)(unsigned)(i2 || ((unsigned)x0 + 0x29548485u))) & 7u];
                        }
                    }
                }
                break; (void)((unsigned)(((unsigned)x0 % (u2 | 1u)) && (unsigned)w0));
            }
            { unsigned t2; double z2; if (((unsigned)((short)fuel > (signed char)(unsigned)l0)) & 1u) { t2 = 0xcd26b20du; z2 = (double)((p1) & 255u); } if (((unsigned)((short)fuel > (signed char)(unsigned)l0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                e0 = e0 * 0.5L + (long double)(r0.y & 1023u);
                m0 ^= p2;
                c0 = (unsigned char)(m0 * -(unsigned)(u0 < r0.y));
                do { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)(((unsigned)((int)~(m0 / (0x10000u | 1u)) >= (int)u2) % ((unsigned)(0u && u1) | 1u)) & 1023u);
                    break; (void)((v0 ^ (unsigned)((int)(unsigned)e0 >= (int)(unsigned)b0)));
                    u0 = u0 * 0x9e3779b1u + (unsigned)((a0[i0 & 3u] % (garr[u2 & 7u] | 1u)) < (unsigned)(short)(unsigned)(p1 || 0xee83db4fu));
                } while (i0++ < 5u && (unsigned)(3u && (unsigned)f0));
                do { if (--fuel == 0u) goto done;
                    *q0 = (((unsigned)e0 % (r0.x | 1u)) % ((0x19d27a6du ^ (unsigned)h1) | 1u));
                } while (i0++ < 7u && 9u);
                d0 = d0 * 0.5 + (double)(((g0 & u3) % (*mp | 1u)) & 1023u);
            }
        }
        if ((unsigned)((int)1u >= (int)i0)) goto L0;
    } else {
        goto done;
        if (((unsigned)(u1 == a0[u1 & 3u]) * 0xff5e8557u)) goto L1;
    }
    *mp = ((unsigned)(signed char)(6u - (unsigned)(v0 == p1)) - (unsigned)b0);
    d0 = d0 * 0.5 + (double)(((*mp >> (0xffffffffu & 31u)) % ((unsigned)w0 | 1u)) & 1023u);
    if (((unsigned)s1 & (0x10000u >> (0xb987b523u & 31u)))) {
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)e0 << (i0 & 31u))) break;
            if (~(unsigned)((short)5u > (signed char)0x7fffffffu)) {
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)(0x820fe074u / (g1 | 1u)) < (int)v0)) {
                        if ((unsigned)(((unsigned)s0 - 0x7fffffffu) < p2)) break;
                    } else {
                        if (p2) break;
                        break; (void)(u2);
                    }
                    if (garr[u2 & 7u]) break;
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        u2 = u2 * 0x9e3779b1u + a0[i0 & 3u];
                        break; (void)((r0.y % (*q0 | 1u)));
                    }
                    if (g0) {
                        v0 = (unsigned)(short)(r0.y * (0x4d9de342u % ((unsigned)((short)p2 > (signed char)fuel) | 1u)));
                        *q0 += ((i0 >> (6u & 31u)) | (unsigned)((0xffffffffu | *q0) < 0xa0b5ebe2u));
                        if ((unsigned)(garr[i1 & 7u] < u2)) break;
                        h1 = (unsigned short)(h1 + (unsigned)((short)u1 > (signed char)(unsigned)c0));
                    } else {
                        while ((unsigned)(unsigned char)(0xd455f0ebu << (*q0 & 31u))) { if (--fuel == 0u) goto done;
                            i0 = -(unsigned)((short)(unsigned)(signed char)(unsigned)(0x7fffffffu || i2) > (signed char)((unsigned)x0 * g0)) & 15u;
                            l0 = (long)((unsigned long)l0 + p2);
                            u3 = u3 * 0x9e3779b1u + u0;
                            s0 = (int)0x6d7a3e64u;
                            if (((unsigned)((int)0x4b82a344u >= (int)u3) + (unsigned)e0)) break;
                        }
                        x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)c0 && g1) * 0x10000u);
                    }
                    { unsigned t3; double z3; if (((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)b0)) & 1u) { t3 = (0x1d0427bfu | *q0); z3 = (double)((((unsigned)f0 | 0x80000000u)) & 255u); } if (((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)b0)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                        d0 = d0 * 0.5 + (double)(((unsigned)((int)a0[i0 & 3u] < (int)7u) ^ (p2 % ((unsigned)x0 | 1u))) & 1023u);
                        if (((g0 & (unsigned)c1) / (p0 | 1u))) {
                            q0 = &garr[(unsigned)l0 & 7u];
                            if ((unsigned)(0x1bd9699du && 0x7fffffffu)) goto L2;
                            u2 += (unsigned)((unsigned)!(unsigned)(0x7fffffffu == a0[i0 & 3u]) && p1);
                            if (((9u | 6u) + (unsigned)x0)) break;
                        } else {
                            b0 = ((((unsigned)h0 * i0) ^ 7u) - (unsigned)!(g1 + (unsigned)l0)) != 0u;
                            if (5u) continue;
                            h1 = (unsigned short)(h1 + (unsigned)!((unsigned)(6u && u3) * 0x80000000u));
                            q0 = &garr[0x7fffffffu & 7u];
                        }
                        break; (void)((i1 * ((unsigned)e0 ^ u0)));
                        break; (void)((0x2673f2b8u ? (unsigned)(x0 >> 70) : v0));
                        e0 = e0 * 0.5L + (long double)(i2 & 1023u);
                        l0 = (long)((unsigned long)l0 + p2);
                    }
                    l0 = (long)((unsigned long)l0 + (g1 ? (unsigned)f0 : (u0 - (unsigned)((unsigned)s0 < 9u))));
                }
                s0 = (int)(((unsigned)!((unsigned)h1 / ((unsigned)d0 | 1u)) ? p1 : (unsigned)s1) ^ 0xffffffffu);
                if ((unsigned)x0) break;
                break; (void)((p0 ? u3 : i1));
            } else {
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)((int)p0 < (int)(unsigned)(0xfefab435u == (unsigned)s1)));
                }
                switch ((unsigned)h1 & 7u) {
                    goto L1;
                    { unsigned t4; double z4; if ((0x10000u) & 1u) { t4 = (unsigned)e0; z4 = (double)((0xc7f0a3d3u) & 255u); } if ((0x10000u) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                        if ((i0 + (u0 - 0xb522ec0eu))) {
                            goto L0;
                            u2 = (unsigned)((unsigned)(0x1616a40fu && (unsigned)f0) && (unsigned)l0);
                            case 5u: ;
                            if ((unsigned)(unsigned char)((unsigned)((int)(unsigned)l0 >= (int)fuel) ^ r0.x)) break;
                            g0 = (garr[u2 & 7u] & ~(fuel + 5u));
                        } else {
                            h1 = (unsigned short)(h1 + (unsigned)((unsigned)((unsigned)(a0[u1 & 3u] == 0xe86b7aebu) < ((unsigned)h1 + g1)) == r0.y));
                            i2 = (((i2 - p2) + fuel) >> (a0[u1 & 3u] & 31u)) & 15u;
                            s1 = (int)((unsigned)s1 + ((unsigned)(0x36a86558u < (unsigned)((unsigned)w0 && (unsigned)w0)) ^ r0.x));
                            if ((unsigned)(u2 < (unsigned)l0)) break;
                        }
                        v0 = ~(unsigned)((int)0x10000u >= (int)5u);
                    }
                }
                w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)(signed char)(garr[u2 & 7u] >> (8u & 31u)) > (signed char)(unsigned)w0);
            }
            garr[((unsigned)l0 * garr[u2 & 7u]) & 7u] = (unsigned)((int)5u >= (int)0xfdbb018eu);
        }
        u0 = u0 * 0x9e3779b1u + (unsigned)(3u || 0x80000000u);
        if (0x4d396cadu) goto L3;
        u3 += (((unsigned)w0 * (unsigned)x0) * ((unsigned)(unsigned char)(unsigned)((short)p2 > (signed char)(unsigned)c1) >> ((unsigned)e0 & 31u)));
        if (((unsigned)h1 | garr[i1 & 7u])) goto done;
    } else {
        r0.x = (unsigned)e0;
        while (i0++ < 7u && ((unsigned)c1 | r0.x)) { if (--fuel == 0u) goto done;
            if (((g1 - (unsigned)(x0 >> 70)) % ((unsigned)e0 | 1u))) break;
        }
        switch ((garr[i1 & 7u] ? v0 : fuel) & 7u) {
            case 7u: ;
            m0 ^= (0x7fffffffu + u2);
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (((unsigned)(short)(2u + garr[u2 & 7u]) >> ((unsigned)c0 & 31u)) * garr[u2 & 7u]);
                case 4u: ;
                case 2u: ;
            }
            if (((u2 ^ (unsigned)(x0 >> 70)) % (5u | 1u))) break;
        }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)(unsigned)(p0 == (unsigned)!(0x7fffffffu * a0[u1 & 3u]))) break;
            l0 = (long)((unsigned long)l0 + (unsigned)(((9u << ((unsigned)d0 & 31u)) << (0x80000000u & 31u)) < (unsigned)(unsigned char)((unsigned)c1 << ((unsigned)c1 & 31u))));
        } while (i0++ < 6u && (unsigned)(short)(unsigned)((unsigned)(w0 >> 29) < 0x7fffffffu));
    }
    if ((unsigned)s1) goto L4;
    v0 = (unsigned)l0;
    goto L3;
    s1 = (int)((unsigned)s1 + (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)((unsigned)w0 < 5u)));
    if ((unsigned)(unsigned char)((unsigned)c1 ^ (1u | (unsigned)h0))) goto L4;
    if ((unsigned)(u1 == fuel)) goto L4;
    w0 ^= (unsigned long long)u0 << (((0xffffffffu / (u3 | 1u)) / (r0.x | 1u)) & 63u);
    while ((unsigned)(short)(0x80000000u >> (5u & 31u))) { if (--fuel == 0u) goto done;
        g0 = (u3 ^ ((unsigned)w0 ? 0x5ef36249u : (unsigned)((int)0xe825fc86u >= (int)0xffffffffu)));
        if (((unsigned)((int)7u >= (int)0xf1cc6cb5u) * garr[u2 & 7u])) break;
        *q0 += u1;
        if (garr[u2 & 7u]) break;
    }
    s0 = (int)(unsigned)((int)v0 >= (int)0x80000000u);
    goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch ((unsigned)((short)(unsigned)((short)garr[u2 & 7u] > (signed char)v0) > (signed char)(unsigned)s0) & 7u) {
        if ((unsigned)(((unsigned)h1 % ((unsigned)(x0 >> 70) | 1u)) && (unsigned)w0)) goto L4;
        u2 = u2 * 0x9e3779b1u + 0xf27d140du;
        if (budget != 0u) { budget -= 1u; u3 = fn0((garr[u2 & 7u] << (0xa855bd40u & 31u)), (unsigned)(garr[u2 & 7u] < 0x80000000u), (unsigned)(short)(unsigned)((int)(unsigned)s1 < (int)(unsigned)c1)); }
        case 3u: ;
        if (u3 == 7u) return (unsigned)((short)0xffffffffu > (signed char)(v0 & ((unsigned)((int)4u >= (int)4u) - 0x7fffffffu)));
        L0: if (--fuel == 0u) goto done;
    }
    goto L1;
    i0 = ((unsigned)l0 / ((unsigned)((short)0x555fa142u > (signed char)(unsigned)f0) | 1u)) & 15u;
    x0 = x0 * 0x100000001b3ull + (u1 - (unsigned)(~((unsigned)l0 | -((unsigned)h0 >> ((unsigned)e0 & 31u))) || u1));
    a0[p1 & 3u] = m0;
    while (i0++ < 3u && (unsigned)((int)(unsigned)(0x7fffffffu < 0x48101e7eu) < (int)g1)) { if (--fuel == 0u) goto done;
        if (i1) break;
    }
    for (;;) { if (--fuel == 0u) goto done;
        while (i1++ < 2u && (*q0 ^ p0)) { if (--fuel == 0u) goto done;
            if (g1) break;
            h0 = (short)(unsigned)(9u || i0);
            break; (void)(((unsigned)f0 | (*q0 | (unsigned)x0)));
        }
    }
    l0 = (long)((unsigned long)l0 + (unsigned)((2u - m0) == (unsigned)(0x7fffffffu == i0)));
    if ((unsigned)(v0 && (unsigned)x0)) goto L2;
    if (budget != 0u) { budget -= 1u; u2 = fn0(2u, (5u << ((unsigned)s1 & 31u)), 0x10000u); }
    l0 = (long)((unsigned long)l0 + (*mp * u2));
    { unsigned t0; double z0; if (((unsigned)((int)(unsigned)h1 >= (int)((unsigned)w0 << ((unsigned)b0 & 31u)))) & 1u) { t0 = (unsigned)((unsigned)d0 || a0[i0 & 3u]); z0 = (double)(((unsigned)((i1 % (*mp | 1u)) && (unsigned)d0)) & 255u); } if (((unsigned)((int)(unsigned)h1 >= (int)((unsigned)w0 << ((unsigned)b0 & 31u)))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        if ((0x51c590fdu & (unsigned)d0)) {
            goto L0;
            L1: if (--fuel == 0u) goto done;
        }
        switch ((unsigned)(a0[u1 & 3u] && 7u) & 7u) {
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(garr[i1 & 7u] && (unsigned)((unsigned)e0 == 0x93f8c3ddu)), u1, ((unsigned)w0 >> (8u & 31u))); }
                g1 += (unsigned)(unsigned char)(0x3036bd43u | i1);
            }
            q0 = &garr[(0x10000u * (g1 ? r0.y : 5u)) & 7u];
            if ((unsigned)(0x10000u && u3)) {
                if (a0[u1 & 3u]) break;
                do { if (--fuel == 0u) goto done;
                    for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                        m0 ^= u0;
                    }
                } while (i0++ < 6u && (unsigned)(short)((unsigned)s0 | (unsigned)(x0 >> 70)));
                case 4u: ;
                L2: if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)(((unsigned)h0 / ((unsigned)e0 | 1u)) == p0);
            } else {
                if ((unsigned)(unsigned char)(r0.x | garr[i1 & 7u])) goto L3;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0(-(unsigned)(0x3a138a7cu || u0), (a0[i0 & 3u] + u0), (unsigned)((short)(unsigned)((int)0x10000u < (int)0x7fffffffu) > (signed char)(unsigned)c1)); }
            break; (void)((unsigned)((int)p2 < (int)fuel));
            g0 = 0u;
        }
    }
    garr[m0 & 7u] = (unsigned)((unsigned)(w0 >> 29) == (unsigned)((0xffffffffu >> ((u1 + i1) & 31u)) < 0x7fffffffu));
    if ((unsigned)(short)((unsigned)x0 - 9u)) {
        m0 ^= 0x10000u;
        do { if (--fuel == 0u) goto done;
            goto L2;
            if (budget != 0u) { budget -= 1u; u0 = fn0((garr[i1 & 7u] - (0x1b452b53u << (0x7cd4204fu & 31u))), ((unsigned)w0 % (*q0 | 1u)), (unsigned)!(i0 & p2)); }
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(x0 >> 70) | garr[i1 & 7u]), ((unsigned)(0u && fuel) ^ (unsigned)c1), (unsigned)((unsigned)(0x10000u || m0) || 0x10594d3cu)); }
            if (u3 == 7u) return (unsigned)(((garr[u2 & 7u] >> (0xf16a7b55u & 31u)) | 0x776d4d92u) == (unsigned)(w0 >> 29));
            if (p0) {
                c0 = (unsigned char)(unsigned)!((unsigned)(0x24b08bdbu && (unsigned)s0) >> (g1 & 31u));
            }
        } while (i0++ < 7u && v0);
        s0 = (int)(unsigned)(short)(unsigned)((short)(unsigned)(1u == ~(u1 * (unsigned)l0)) > (signed char)g0);
        u1 ^= ((unsigned)(9u || 0u) - g0);
    }
    if (~((unsigned)f0 & (garr[i1 & 7u] % ((unsigned)s0 | 1u)))) goto L3;
    if (budget != 0u) { budget -= 1u; u1 = fn0(p0, (4u * 0x489aa9f6u), (unsigned)((int)(unsigned)d0 < (int)2u)); }
    goto L1;
    switch (m0 & 7u) {
        break; (void)((garr[u2 & 7u] & (unsigned)w0));
    }
    garr[(r0.y * g1) & 7u] = (i2 % (5u | 1u));
    if (a0[u1 & 3u]) goto done;
    if (0x611e3b8au) {
        switch ((a0[u1 & 3u] - 0x10000u) & 7u) {
            if ((i1 / (i1 | 1u))) goto L4;
            goto L4;
            if (-(0xf1fceaf4u ? garr[i1 & 7u] : i0)) break;
        }
    }
    garr[(unsigned)(g1 < (unsigned)w0) & 7u] = -(unsigned)((int)(unsigned)((short)p0 > (signed char)a0[i0 & 3u]) >= (int)(0x5cc2c401u & (unsigned)s1));
    f0 = f0 * 0.5f + (float)(*mp & 255u);
    e0 = e0 * 0.5L + (long double)(7u & 1023u);
    *q0 = g0;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)l0 + fuel), (unsigned)((short)(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)s0) > (signed char)(unsigned)(x0 >> 70)), ~((0x18399b23u + u2) * 8u)); }
        while ((unsigned)l0) { if (--fuel == 0u) goto done;
            if ((unsigned)l0) break;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(w0 >> 29), *mp, ((unsigned)s0 / ((unsigned)((int)*q0 < (int)(unsigned)f0) | 1u))); }
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                q0 = &garr[((unsigned)c1 / (((unsigned)((int)v0 < (int)0x7fffffffu) * a0[i0 & 3u]) | 1u)) & 7u];
                v0 = -(unsigned)(m0 < (v0 >> (a0[u1 & 3u] & 31u)));
                L3: if (--fuel == 0u) goto done;
                if ((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)(unsigned char)(unsigned)(garr[u2 & 7u] == (unsigned)d0))) {
                    u0 ^= (0x80000000u * 0xfd875ecau);
                    if ((r0.x + (unsigned)c0)) goto done;
                    L4: if (--fuel == 0u) goto done;
                    if ((0x739c9f2fu % ((unsigned)f0 | 1u))) break;
                    a0[((unsigned)f0 >> (a0[u1 & 3u] & 31u)) & 3u] = (unsigned)(short)(fuel | i1);
                }
            }
            garr[(unsigned)e0 & 7u] = a0[i0 & 3u];
            garr[(unsigned)(5u || (unsigned)c1) & 7u] = (6u >> ((unsigned)(signed char)((unsigned)l0 << (fuel & 31u)) & 31u));
        }
        switch ((unsigned)((int)garr[u2 & 7u] >= (int)i2) & 7u) {
            while (i1++ < 2u && (0xffffffffu >> (0x765062a3u & 31u))) { if (--fuel == 0u) goto done;
                u0 += (unsigned)((int)5u >= (int)((unsigned)(unsigned char)(m0 / ((unsigned)!((unsigned)(w0 >> 29) & 0x80000000u) | 1u)) & a0[u1 & 3u]));
                *mp = (0x80000000u >> (garr[u2 & 7u] & 31u));
                break; (void)(u2);
                s0 = (int)((unsigned)((int)(unsigned)((unsigned)d0 && 0xffffffffu) < (int)(unsigned)(w0 >> 29)) ^ (unsigned)h1);
            }
            continue; (void)((a0[i0 & 3u] ^ p2));
            { unsigned t1; double z1; if (((unsigned)((unsigned)(garr[i1 & 7u] == 0x10000u) || p2)) & 1u) { t1 = ((unsigned)b0 % (0xe10f18e1u | 1u)); z1 = (double)(((unsigned)(signed char)(unsigned)((unsigned)x0 && a0[u1 & 3u])) & 255u); } if (((unsigned)((unsigned)(garr[i1 & 7u] == 0x10000u) || p2)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                g1 += (((unsigned)d0 << ((unsigned)h0 & 31u)) + (unsigned)h0);
                c1 = (signed char)(0xffffffffu ^ (0x7fffffffu + p0));
                c1 = (signed char)(unsigned)(w0 >> 29);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((r0.x ^ 0x7f6c81fu), a0[u1 & 3u], ((unsigned)(u1 || v0) << (0x7fffffffu & 31u))); }
        }
        r0.y ^= (unsigned)((0xda867593u & (a0[u1 & 3u] << (u3 & 31u))) < p2);
        if (((unsigned)x0 & (unsigned)((int)9u < (int)i0))) break;
        if ((i1 | 0xaacce2e9u)) break;
    } while (i0++ < 3u && fuel);
    h1 = (unsigned short)(h1 + (unsigned)c0);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (m0) { if (--fuel == 0u) goto done;
            *q0 = ((unsigned)((unsigned)f0 == m0) - ((unsigned)s0 - 0u));
            if (((unsigned)!(0xedecbfc9u % ((unsigned)c1 | 1u)) << (0x7fffffffu & 31u))) goto done;
        }
    }
    *q0 = (unsigned)!(unsigned)((u1 ? (unsigned)(p2 && (unsigned)e0) : 0x7fffffffu) < i1);
    if (((u2 * 0xa08e06f1u) ^ u3)) goto L2;
    if ((unsigned)((int)(9u * p2) >= (int)*q0)) {
        goto L2;
    } else {
        if ((unsigned)(unsigned char)(u1 / (0xa2d48a0cu | 1u))) goto L1;
    }
    w0 = w0 * 6364136223846793005ull + a0[u1 & 3u];
    switch (((i2 | 0xa508a826u) ^ (unsigned)(w0 >> 29)) & 7u) {
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)s1, (0x8e30078bu + garr[i1 & 7u]), (((unsigned)s1 << (9u & 31u)) ^ 0x71d0365du)); }
    }
    *mp = (g1 & (unsigned)((int)u3 < (int)(unsigned)c1));
    while (i0++ < 7u && (unsigned)((unsigned)((int)i2 < (int)p1) < g0)) { if (--fuel == 0u) goto done;
        if (u3 == 7u) return i2;
    }
    if (0xcdabae20u) {
        if ((1u >> ((unsigned)l0 & 31u))) {
            *mp = (0xffffffffu << ((0xbd6fb757u % (*q0 | 1u)) & 31u));
            do { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)h1 / ((i1 << ((unsigned)h1 & 31u)) | 1u)));
                break; (void)((5u << ((unsigned)!(p2 ^ v0) & 31u)));
                b0 = (p1 >> ((garr[u2 & 7u] ? fuel : ~(unsigned)(garr[i1 & 7u] && m0)) & 31u)) != 0u;
                u0 ^= (g0 / (0xffffffffu | 1u));
                if (((unsigned)l0 << ((u0 >> (g1 & 31u)) & 31u))) break;
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + (unsigned)(signed char)((0xffffffffu >> (4u & 31u)) << ((garr[i1 & 7u] & u2) & 31u)));
                    { unsigned t2; double z2; if (((unsigned)((0xa11027c4u >> (0x7fffffffu & 31u)) && p0)) & 1u) { t2 = (unsigned)(i1 == (0x7fffffffu | i0)); z2 = (double)(((unsigned)(short)(unsigned)((int)0xdd7a5664u >= (int)6u)) & 255u); } if (((unsigned)((0xa11027c4u >> (0x7fffffffu & 31u)) && p0)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                        x0 = x0 * 0x100000001b3ull + (unsigned)x0;
                        if (r0.x) break;
                        i0 = (unsigned)((short)0x7fffffffu > (signed char)p0) & 15u;
                        do { if (--fuel == 0u) goto done;
                            h1 = (unsigned short)(h1 + ((~((unsigned)(0x7fffffffu < (unsigned)b0) - 0x4286a6e0u) & 0x7fffffffu) * 0x545957d1u));
                            if ((u0 & i0)) break;
                            h0 = (short)(unsigned)((int)(0xdc6c6d1fu << (u1 & 31u)) >= (int)(unsigned)f0);
                            if (fuel < 8u) return (u0 / ((i2 & (r0.y & (0xb8e6c380u - (unsigned)w0))) | 1u));
                            break; (void)((0x10000u - 0x10000u));
                        } while (i2++ < 2u && (u0 << ((unsigned)e0 & 31u)));
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)(unsigned)l0 > (signed char)0xc3b2fa60u), (unsigned)s0, (0x7c367e5du & (unsigned)((int)garr[i1 & 7u] >= (int)u0))); }
                        if (fuel < 8u) return (fuel & (unsigned)((short)0x7fffffffu > (signed char)(unsigned)l0));
                    }
                    v0 = ((unsigned)c0 >> ((unsigned)(r0.x && r0.x) & 31u));
                    { unsigned t3; double z3; if (((unsigned)(short)(garr[i1 & 7u] - m0)) & 1u) { t3 = (unsigned)(r0.y && (unsigned)h1); z3 = (double)(((unsigned)(unsigned char)(garr[i1 & 7u] ? u0 : v0)) & 255u); } if (((unsigned)(short)(garr[i1 & 7u] - m0)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                        g1 += (unsigned)((int)(unsigned)(((unsigned)(w0 >> 29) & (u2 % ((unsigned)c0 | 1u))) == 9u) >= (int)u2);
                    }
                    while (i2++ < 6u && 0x80000000u) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + ((u0 + 0x331df6d0u) ^ ((unsigned)h1 * u0)));
                        { unsigned t4; double z4; if ((((unsigned)(x0 >> 70) * (unsigned)s0)) & 1u) { t4 = (0x630f6083u & ((unsigned)w0 - i2)); z4 = (double)((((unsigned)l0 / (u0 | 1u))) & 255u); } if ((((unsigned)(x0 >> 70) * (unsigned)s0)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                            goto L2;
                            if (u3 == 7u) return i0;
                            b0 = fuel != 0u;
                            s0 = (int)(unsigned)((short)(unsigned)((unsigned)(signed char)(7u ? 0xee7bf475u : i1) == a0[u1 & 3u]) > (signed char)garr[i1 & 7u]);
                            break; (void)(garr[i1 & 7u]);
                            if (budget != 0u) { budget -= 1u; u0 = fn0(0xffffffffu, i0, p2); }
                        }
                        x0 = x0 * 0x100000001b3ull + ((i0 >> ((unsigned)(short)(unsigned)(i2 || (u3 - p1)) & 31u)) * 0xda3f2a9eu);
                        if (0x27f0c92cu) break;
                        i0 = (5u << ((2u + garr[u2 & 7u]) & 31u)) & 15u;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)!(i2 - 0xa41259efu) << (i1 & 31u)), (unsigned)((unsigned)(x0 >> 70) == 0u), (unsigned)(6u || (unsigned)(garr[i1 & 7u] == r0.x))); }
                    }
                    s1 = (int)((unsigned)s1 + (unsigned)(signed char)((*q0 - (unsigned)l0) * ((v0 % (*mp | 1u)) | *q0)));
                }
            } while (i0++ < 4u && 0xa7f6729au);
            goto L1;
        } else {
            s1 = (int)((unsigned)s1 + (((((unsigned)l0 ^ (unsigned)s0) >> (0x80000000u & 31u)) - u1) % ((unsigned)c0 | 1u)));
            if ((unsigned)!((unsigned)e0 % (g0 | 1u))) goto L1;
        }
    }
    u0 ^= (unsigned)!(unsigned)(0x80000000u < (a0[u1 & 3u] - 0x7fffffffu));
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((g1 & 8u) >> (i2 & 31u))) break;
        if (0xf6dbfcc2u) goto L3;
        q0 = &garr[((unsigned)c1 % (0x65fb3568u | 1u)) & 7u];
        r0.x = (p0 ^ (unsigned)(m0 || (8u ? u2 : a0[u1 & 3u])));
        { unsigned t5; double z5; if ((0xc112387du) & 1u) { t5 = (unsigned)((int)u2 >= (int)(unsigned)x0); z5 = (double)((u1) & 255u); } if ((0xc112387du) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            if (budget != 0u) { budget -= 1u; u0 = fn0((0x31b643b5u | (u0 * (unsigned)s1)), ((unsigned)h0 + 5u), ((unsigned)(w0 >> 29) + g0)); }
            do { if (--fuel == 0u) goto done;
                continue; (void)((unsigned)((int)(unsigned)((int)(unsigned)h0 >= (int)v0) >= (int)0x7fffffffu));
                break; (void)((unsigned)((int)(unsigned)l0 < (int)0x78960efbu));
                if ((unsigned)(signed char)(unsigned)(0xbcae67e6u == 0xd4f11921u)) goto L0;
                continue; (void)((unsigned)((int)0xfd0c6bd5u >= (int)p0));
                break; (void)(((0x7fffffffu + (unsigned)h0) & (unsigned)(w0 >> 29)));
            } while (i1++ < 5u && (garr[u2 & 7u] >> (5u & 31u)));
        }
        switch (((unsigned)((unsigned)b0 && 0x10000u) * p0) & 7u) {
            g0 = (p0 | 0x7fffffffu);
            case 5u: ;
            g0 = (unsigned)(short)(unsigned)((unsigned)(short)(fuel | (unsigned)w0) < ((unsigned)(w0 >> 29) & g0));
            i0 = (unsigned)(short)(v0 << (u3 & 31u)) & 15u;
            b0 = v0 != 0u;
            a0[0x80000000u & 3u] = (unsigned)((short)*q0 > (signed char)0x10000u);
        }
    }
    if (u3 == 7u) return (unsigned)!(g1 >> ((-(u3 / (garr[i1 & 7u] | 1u)) + garr[u2 & 7u]) & 31u));
    if ((unsigned)((unsigned)(x0 >> 70) < (*mp - r0.y))) goto L0;
    do { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            break; (void)((a0[i0 & 3u] * 0xffffffffu));
            break; (void)(((unsigned)w0 | 5u));
            { unsigned t6; double z6; if (((unsigned)x0) & 1u) { t6 = i1; z6 = (double)((garr[u2 & 7u]) & 255u); } if (((unsigned)x0) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                do { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)(((unsigned)((unsigned)((int)0xffffffffu >= (int)9u) || (unsigned)c0) * 0xb09306f0u) & 1023u);
                    u0 = u0 * 0x9e3779b1u + (unsigned)(((unsigned)x0 * r0.y) < (unsigned)(0xa30bc515u < (unsigned)w0));
                    v0 = ((unsigned)w0 % (fuel | 1u));
                    if ((0x80000000u * 0x10000u)) {
                        garr[g0 & 7u] = ((unsigned)l0 / ((4u + u1) | 1u));
                        if (a0[i0 & 3u]) goto L2;
                        if ((unsigned)((int)(unsigned)c0 >= (int)0x10000u)) break;
                        if ((unsigned)(r0.y == (unsigned)(w0 >> 29))) break;
                        i2 = ((i1 >> (garr[u2 & 7u] & 31u)) + ~(0x10000u >> (0xa5fa5a86u & 31u))) & 15u;
                        s1 = (int)((unsigned)s1 + 0x7fffffffu);
                    } else {
                        i1 = ((unsigned)((unsigned)((int)g0 < (int)garr[u2 & 7u]) || 0x10000u) + (unsigned)h1) & 15u;
                        h1 = (unsigned short)(h1 + (unsigned)((unsigned)s1 && (g1 >> (0xbd7c901u & 31u))));
                        v0 = (unsigned)((int)(unsigned)w0 < (int)(fuel | (unsigned)(0x8c5e908eu && 0x80000000u)));
                        if ((unsigned)(g1 == 0x80000000u)) {
                            garr[0x9c98ad07u & 7u] = (unsigned)((short)-(unsigned)(i1 == (v0 ^ u0)) > (signed char)(unsigned)h0);
                        } else {
                            if (*q0) break;
                            break; (void)((unsigned)!((unsigned)c1 << ((unsigned)l0 & 31u)));
                        }
                    }
                    g1 += (*q0 - (unsigned)((unsigned)c0 < -(unsigned)((int)m0 < (int)(unsigned)x0)));
                } while (i2++ < 6u && 8u);
                break; (void)((u0 >> (i1 & 31u)));
            }
        }
        if (fuel < 8u) return 3u;
    } while (i0++ < 2u && (unsigned)(short)((unsigned)b0 >> ((*mp ^ 0x5d151980u) & 31u)));
    { unsigned t7; double z7; if (((unsigned)e0) & 1u) { t7 = 0x80000000u; z7 = (double)((u2) & 255u); } if (((unsigned)e0) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t8; double z8; if (((unsigned)f0) & 1u) { t8 = (fuel ^ i1); z8 = (double)(((6u / ((unsigned)s1 | 1u))) & 255u); } if (((unsigned)f0) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                if (p1) break;
                if ((u3 / (0x27b37d20u | 1u))) {
                    c1 = (signed char)((unsigned)(0x619abba6u < 0x7fffffffu) * (unsigned)((unsigned)(w0 >> 29) && 0x7fffffffu));
                    m0 ^= (unsigned)((int)(((unsigned)s1 % (0x80000000u | 1u)) ^ 0x35594fa8u) < (int)(u2 << (g1 & 31u)));
                    v0 = (unsigned)(((unsigned)((unsigned)((int)(unsigned)e0 < (int)(unsigned)s0) && i2) & r0.x) < 8u);
                    if (((unsigned)c0 ^ 0xffffffffu)) goto L0;
                    f0 = f0 * 0.5f + (float)((unsigned)((int)((unsigned)b0 - 0x246cf44bu) < (int)((unsigned)s1 & (unsigned)(signed char)(0x10000u ^ (unsigned)b0))) & 255u);
                }
                w0 ^= (unsigned long long)(unsigned)((int)0xffffffffu >= (int)0x80000000u) << ((unsigned)((short)((unsigned)s0 - (unsigned)w0) > (signed char)2u) & 63u);
                r0.x = ((unsigned)((int)r0.x < (int)i1) + (unsigned)((unsigned)(unsigned char)((unsigned)e0 * (unsigned)f0) || (unsigned)x0));
                if (((p2 * 0xa96b1b92u) >> (i0 & 31u))) break;
            }
            if (0x5f3658ebu) goto L2;
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + ~(unsigned)((int)(i0 - 0x45e5fb76u) < (int)(unsigned)(w0 >> 29)));
                garr[r0.y & 7u] = (unsigned)(g1 && g1);
                u1 += *mp;
                f0 = f0 * 0.5f + (float)(0x80000000u & 255u);
                if (0x81313ee6u) break;
            }
            u2 = (unsigned)((int)m0 >= (int)(unsigned)((unsigned)(x0 >> 70) && ((unsigned)(unsigned char)(unsigned)(0x1ea3a13fu == 0x8b3a3756u) & i2)));
            if ((unsigned)((int)(0x4f20a148u << (r0.x & 31u)) >= (int)2u)) {
                if (a0[u1 & 3u]) continue;
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (0x11689263u) break;
                    c0 = (unsigned char)(unsigned)!(unsigned)((int)(unsigned)x0 >= (int)(unsigned)f0);
                    if ((i1 ? 0xd520ec8au : *mp)) break;
                    do { if (--fuel == 0u) goto done;
                        if (p2) break;
                        x0 = x0 * 0x100000001b3ull + (unsigned)((r0.x | 0x25844174u) || g0);
                        if ((0x7fffffffu / ((unsigned)h1 | 1u))) {
                            *q0 += (0x12ea44f2u - u1);
                            *q0 += (unsigned)(((unsigned)h1 / ((i1 * *q0) | 1u)) < (unsigned)h1);
                            b0 = ((unsigned)(w0 >> 29) ? (unsigned)w0 : 0xf138ed30u) != 0u;
                            d0 = d0 * 0.5 + (double)(((unsigned)((unsigned)d0 == (0xed864604u | i1)) * (unsigned)((short)(unsigned)s1 > (signed char)2u)) & 1023u);
                        }
                        g1 += (~(unsigned)((short)v0 > (signed char)(unsigned)s1) + (0xac62992cu * (unsigned)(0x7fffffffu && g0)));
                    } while (i2++ < 6u && (unsigned)(3u == 0x10000u));
                }
                continue; (void)(((unsigned)h0 % (5u | 1u)));
                a0[(unsigned)e0 & 3u] = (0xea6f8975u + u3);
            }
            e0 = e0 * 0.5L + (long double)((garr[i1 & 7u] / ((unsigned)w0 | 1u)) & 1023u);
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)s1) goto L3;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((i1 & *mp)) break;
    }
    w0 ^= (unsigned long long)(unsigned)(p2 && a0[i0 & 3u]) << ((unsigned)((int)((unsigned)e0 ^ u2) >= (int)(unsigned)(9u || 0x10000u)) & 63u);
    if ((unsigned)(w0 >> 29)) {
        if (g1) {
            *q0 += 0x80000000u;
            L0: if (--fuel == 0u) goto done;
            u3 += (0x436b8776u ? (unsigned)l0 : ~(unsigned)((unsigned)h1 == (0x812b61eeu % ((unsigned)d0 | 1u))));
            if ((unsigned)(unsigned char)(unsigned)((int)fuel >= (int)0x7fffffffu)) goto L2;
            do { if (--fuel == 0u) goto done;
                { unsigned t0; double z0; if (((0x80000000u & 0x7fffffffu)) & 1u) { t0 = (unsigned)(unsigned char)(unsigned)((int)fuel < (int)(p1 >> (a0[i0 & 3u] & 31u))); z0 = (double)((r0.y) & 255u); } if (((0x80000000u & 0x7fffffffu)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    if (i1) break;
                    w0 ^= (unsigned long long)(unsigned)!(unsigned)(a0[u1 & 3u] == (unsigned)(x0 >> 70)) << (g0 & 63u);
                    u1 += (((i0 * (unsigned)c0) & (unsigned)((int)i0 < (int)7u)) << (i1 & 31u));
                }
                if ((unsigned)((unsigned)(w0 >> 29) == a0[i0 & 3u])) break;
                if (budget != 0u) { budget -= 1u; u1 = fn1(~((unsigned)c0 - (unsigned)h1), ((unsigned)(x0 >> 70) / (garr[i1 & 7u] | 1u)), (0x7fffffffu ? 0xdb0cff04u : (unsigned)e0)); }
                f0 = f0 * 0.5f + (float)((0xffffffffu + 0x4be8febfu) & 255u);
                if ((garr[i1 & 7u] & m0)) continue;
                g0 = (((unsigned)l0 % (((unsigned)(w0 >> 29) >> (0x5890df3au & 31u)) | 1u)) * ((unsigned)e0 * 1u));
            } while (i0++ < 2u && ((unsigned)((int)0xce31dd92u >= (int)(unsigned)e0) - u2));
            if (budget != 0u) { budget -= 1u; u0 = fn0((u3 >> (v0 & 31u)), ((unsigned)(garr[u2 & 7u] < garr[i1 & 7u]) << (u3 & 31u)), 4u); }
        } else {
            e0 = e0 * 0.5L + (long double)((unsigned)(~((unsigned)(w0 >> 29) / (9u | 1u)) || (unsigned)!(unsigned)(0xffffffffu && (unsigned)((unsigned)x0 && (unsigned)(w0 >> 29)))) & 1023u);
            while (i0++ < 5u && (0x95f384f3u + (unsigned)s0)) { if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                g0 = ~(p2 ^ (unsigned)((unsigned)s1 || 0xffffffffu));
                *mp = (garr[u2 & 7u] & (unsigned)l0);
            }
        }
        goto L2;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)r0.x < (int)(unsigned)((int)g0 >= (int)0xe731ef90u)), (unsigned)(unsigned char)((unsigned)h1 - *mp), ((unsigned)!(g0 / (p0 | 1u)) - 0u)); }
    }
    r0.x = *q0;
    if (r0.y) {
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((unsigned)((garr[u2 & 7u] ^ 0x10000u) == u3) & 1023u);
            g1 += (unsigned)((*q0 % (0x971bf831u | 1u)) && (unsigned)l0);
        }
    } else {
        if ((unsigned)((int)((unsigned)f0 | p0) < (int)(unsigned)w0)) {
            if (fuel < 8u) return (((unsigned)s0 ? 0xffffffffu : 3u) - p1);
            goto L2;
        }
        if ((unsigned)(short)(0x79be87f2u ^ u1)) goto L0;
        do { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((i2 & (unsigned)s1), (unsigned)(fuel == (0x80000000u % ((unsigned)x0 | 1u))), -(unsigned)((unsigned)h0 < (unsigned)((int)(unsigned)d0 >= (int)u1))); }
                    u0 += (unsigned)((g1 / (a0[u1 & 3u] | 1u)) < (g0 ^ u0));
                }
            }
            switch ((unsigned)(signed char)(p0 % (0x80d5a48cu | 1u)) & 7u) {
                h0 = (short)(((unsigned)!(unsigned)((int)(unsigned)(0x6d17ae92u < (unsigned)h0) >= (int)r0.x) << ((unsigned)(w0 >> 29) & 31u)) >> (7u & 31u));
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    f0 = f0 * 0.5f + (float)(6u & 255u);
                }
                u1 = u1 * 0x9e3779b1u + ((a0[u1 & 3u] & r0.y) / (6u | 1u));
                if (0x7fffffffu) break;
            }
        } while (i0++ < 2u && (m0 % (~((unsigned)d0 + u0) | 1u)));
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(8u % (garr[u2 & 7u] | 1u)), (unsigned)f0, (r0.x / ((unsigned)f0 | 1u))); }
    c1 = (signed char)(garr[u2 & 7u] << ((0x10000u | ~((unsigned)s0 / ((unsigned)w0 | 1u))) & 31u));
    if (8u) goto L4;
    a0[(unsigned)h1 & 3u] = a0[i0 & 3u];
    r0.x = (unsigned)((int)*q0 < (int)(5u >> (0x350984f0u & 31u)));
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(((unsigned)((0x80000000u << (p1 & 31u)) == 0x3afe8190u) ? (unsigned)s1 : 0xa80d4dedu) & 1023u);
                a0[(u3 - r0.x) & 3u] = (unsigned)(short)((unsigned)(short)((i2 & (unsigned)d0) & (unsigned)e0) | (g1 | 0xf9e98a4eu));
                w0 = w0 * 6364136223846793005ull + ((unsigned)((int)u1 < (int)(1u << ((unsigned)f0 & 31u))) * (p1 + 0xf8b1e60eu));
                if ((unsigned)((unsigned)(x0 >> 70) == 0x7fffffffu)) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)(signed char)(((fuel ^ 0x80000000u) * 9u) / ((unsigned)(g1 || 0x3592d950u) | 1u)));
            }
            u3 ^= (unsigned)((8u + 1u) < u3);
            c1 = (signed char)(p1 << (0x892a3827u & 31u));
            d0 = d0 * 0.5 + (double)(((4u | (unsigned)((int)p1 >= (int)(unsigned)b0)) % ((unsigned)(8u && p0) | 1u)) & 1023u);
            q0 = &garr[(1u + ~(0x2eb98408u + 0x10000u)) & 7u];
            s0 = (int)((unsigned)b0 >> ((~(u0 % ((unsigned)((int)2u >= (int)(unsigned)x0) | 1u)) / ((unsigned)w0 | 1u)) & 31u));
        }
        *q0 = ~(unsigned)((int)(unsigned)(0x10000u == (unsigned)c0) < (int)0xffffffffu);
        if ((unsigned)(u2 < (unsigned)b0)) goto L2;
        m0 ^= p0;
    }
    if ((unsigned)((unsigned)x0 && g1)) {
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= i0;
            while (i1++ < 4u && (r0.x | r0.x)) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    i1 = (unsigned)((int)(p2 >> ((*q0 | (garr[i1 & 7u] >> (p0 & 31u))) & 31u)) < (int)0x10000u) & 15u;
                    x0 = x0 * 0x100000001b3ull + (unsigned)(-(u2 | (unsigned)d0) && ~(0x80000000u & (unsigned)(w0 >> 29)));
                } while (i2++ < 3u && 0x7fffffffu);
                L2: if (--fuel == 0u) goto done;
                if (0x4c784cc4u) continue;
                do { if (--fuel == 0u) goto done;
                    if (2u) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(-(unsigned)(u0 < a0[i0 & 3u]), (unsigned)(unsigned char)((unsigned)((int)g1 >= (int)i2) ^ v0), 0xffffffffu); }
                } while (i2++ < 7u && (u2 ^ -(unsigned)((short)(unsigned)h1 > (signed char)0x80000000u)));
                { unsigned t1; double z1; if (((u3 / ((unsigned)(r0.x < u3) | 1u))) & 1u) { t1 = 7u; z1 = (double)(((unsigned)((unsigned)c0 || (unsigned)((int)(unsigned)x0 >= (int)(unsigned)w0))) & 255u); } if (((u3 / ((unsigned)(r0.x < u3) | 1u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    h1 = (unsigned short)(h1 + (g1 ? 0x8bf5b976u : (unsigned)c1));
                    s1 = (int)((unsigned)s1 + -((unsigned)((u1 % (0x10000u | 1u)) && 0x44abae55u) ^ *q0));
                    if (budget != 0u) { budget -= 1u; u2 = fn0(0x80000000u, (unsigned)((unsigned)w0 && 1u), (v0 * (u3 >> ((unsigned)s0 & 31u)))); }
                    if (((unsigned)l0 * 0u)) {
                        L3: if (--fuel == 0u) goto done;
                        continue; (void)((unsigned)((unsigned)((unsigned)w0 && i1) < *mp));
                        { unsigned t2; double z2; if ((v0) & 1u) { t2 = (unsigned)c0; z2 = (double)(((u2 & garr[u2 & 7u])) & 255u); } if ((v0) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                            c0 = (unsigned char)(unsigned)((short)(a0[u1 & 3u] & fuel) > (signed char)(5u % (p2 | 1u)));
                            if (u3 == 7u) return (unsigned)((i1 >> ((g1 ^ u1) & 31u)) || (0x80000000u << (u3 & 31u)));
                            if (budget != 0u) { budget -= 1u; u2 = fn0(*mp, ((unsigned)s1 * (unsigned)f0), (unsigned)(0x10000u && (unsigned)c0)); }
                            *q0 = (unsigned)(short)(r0.y % ((unsigned)(unsigned char)(unsigned)(u1 || ((unsigned)h1 ^ *q0)) | 1u));
                            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)(short)(0x10000u - g1) * r0.y), (p2 & (unsigned)(signed char)((unsigned)c1 ^ (unsigned)x0)), (unsigned)h1); }
                        }
                        if ((unsigned)((unsigned)c1 < (unsigned)b0)) break;
                    }
                }
            }
            u2 ^= ((unsigned)(0xd7b78274u == 0x80000000u) / ((unsigned)(0x35458928u || ((unsigned)(x0 >> 70) | (unsigned)s1)) | 1u));
            switch (1u & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn0((6u % ((unsigned)e0 | 1u)), (unsigned)((g0 ^ 7u) == 0x7fffffffu), (unsigned)((int)u2 < (int)g0)); }
            }
            switch ((a0[u1 & 3u] / (v0 | 1u)) & 7u) {
                if (u1) goto L4;
                switch ((unsigned)h1 & 7u) {
                    case 1u: ;
                    a0[(unsigned)b0 & 3u] = (unsigned)(v0 && p1);
                }
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 1u: ;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(g1 + (unsigned)h1), ((0xce44a390u % (0x75f7e97fu | 1u)) ^ (unsigned)x0), (g1 | i1)); }
                    w0 ^= (unsigned long long)((unsigned)s1 & 0x64ffedd4u) << ((unsigned)e0 & 63u);
                    if (0xf3bbd388u) continue;
                    L4: if (--fuel == 0u) goto done;
                }
                case 6u: ;
                s0 = (int)((u3 & (unsigned)f0) % ((unsigned)((unsigned)c1 && p1) | 1u));
                *q0 = (unsigned)(short)(p0 + (unsigned)!(unsigned)((unsigned)s0 || 0xce9a1feeu));
            }
            switch ((0x7fffffffu / (3u | 1u)) & 7u) {
                *q0 = 0x80000000u;
            }
        }
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t3; double z3; if (((u0 / (0x3edb74bcu | 1u))) & 1u) { t3 = (unsigned)((int)0x10000u >= (int)(unsigned)!(u1 + 0xffffffffu)); z3 = (double)(((unsigned)d0) & 255u); } if (((u0 / (0x3edb74bcu | 1u))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                if (((unsigned)s0 >> ((unsigned)h0 & 31u))) continue;
                while (i1++ < 7u && (0x10000u >> ((unsigned)((unsigned)b0 == fuel) & 31u))) { if (--fuel == 0u) goto done;
                    s1 = (int)((unsigned)s1 + ((unsigned)c0 << (garr[u2 & 7u] & 31u)));
                    if ((unsigned)((p1 << ((unsigned)x0 & 31u)) || a0[u1 & 3u])) break;
                    s0 = (int)((garr[u2 & 7u] / ((unsigned)h1 | 1u)) * p2);
                    w0 ^= (unsigned long long)(0u + r0.y) << ((*q0 | ~((2u << (p2 & 31u)) % ((garr[u2 & 7u] - 0x80000000u) | 1u))) & 63u);
                }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(0x10000u < (unsigned)w0) / (0x7fffffffu | 1u)), p2, ((unsigned)(w0 >> 29) & (unsigned)(w0 >> 29))); }
            switch ((r0.y & 0x80000000u) & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)w0, (unsigned)w0, (unsigned)(i1 < (0x10000u << (8u & 31u)))); }
                r0.x = (unsigned)(i2 || a0[u1 & 3u]);
            }
        }
    }
    if ((unsigned)((short)0xffffffffu > (signed char)m0)) goto L4;
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)(signed char)((unsigned)d0 - 0x7fffffffu) >= (int)((unsigned)(short)(0xffb6f80bu | 1u) ^ 0xf362fd2bu));
    if ((0xb502b37u >> (m0 & 31u))) goto L3;
    s1 = (int)((unsigned)s1 + (i0 ^ a0[i0 & 3u]));
    q0 = &garr[((unsigned)((int)u2 < (int)(unsigned)s1) ^ a0[u1 & 3u]) & 7u];
    goto L3;
    v0 = ((unsigned)c1 & (r0.y << (p1 & 31u)));
    c0 = (unsigned char)(p0 | 0x80000000u);
    if ((unsigned)(short)(unsigned)(u3 == ((unsigned)(w0 >> 29) | p2))) goto L2;
    { unsigned t4; double z4; if ((g1) & 1u) { t4 = (unsigned)!((unsigned)w0 + (unsigned)s0); z4 = (double)((3u) & 255u); } if ((g1) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        d0 = d0 * 0.5 + (double)(((unsigned)h1 & (unsigned)(0x24344bdeu || u0)) & 1023u);
        if ((unsigned)((short)a0[u1 & 3u] > (signed char)u1)) goto L4;
        switch ((unsigned)l0 & 7u) {
            if (budget != 0u) { budget -= 1u; u1 = fn0(0x80000000u, p0, p1); }
            h0 = (short)0x80000000u;
        }
    }
    while (((unsigned)(w0 >> 29) << ((unsigned)s0 & 31u))) { if (--fuel == 0u) goto done;
        v0 = (unsigned)((unsigned)((unsigned)((unsigned)s0 && (v0 % ((unsigned)d0 | 1u))) || 0x87db15bu) < garr[i1 & 7u]);
    }
    do { if (--fuel == 0u) goto done;
        if ((0x7fffffffu ^ fuel)) break;
        if (g0) break;
        while ((unsigned)(*q0 < i1)) { if (--fuel == 0u) goto done;
            u1 += (r0.y * (unsigned)(signed char)(unsigned)(~(0x2261041bu % (u0 | 1u)) < 3u));
        }
    } while (i0++ < 2u && -(0xffffffffu | *q0));
    if ((unsigned)(9u < garr[u2 & 7u])) {
        h1 = (unsigned short)(h1 + -(unsigned)(i0 && (r0.x ^ (unsigned)c0)));
        a0[(unsigned)!(8u - r0.y) & 3u] = ((unsigned)(w0 >> 29) / ((unsigned)b0 | 1u));
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((0x80000000u / (garr[i1 & 7u] | 1u)) && 0xffffffffu), ((unsigned)l0 ^ 8u), 0x19bfd402u); }
        v0 = (u2 / ((unsigned)(g1 && (g0 >> (9u & 31u))) | 1u));
        if ((unsigned)((int)(unsigned)s1 < (int)-(u0 << (2u & 31u)))) goto L3;
    } else {
        m0 ^= (unsigned)!(unsigned)((unsigned)(m0 < 0x7fffffffu) < (unsigned)(fuel == (unsigned)((int)(unsigned)b0 < (int)0xa7551a0u)));
        h0 = (short)((0x10000u % (i0 | 1u)) ^ (unsigned)e0);
        l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)h0 < (int)(unsigned)(*q0 && v0)));
        if ((u1 + u3)) goto L4;
    }
    if ((g1 / ((0x80000000u % (m0 | 1u)) | 1u))) goto L4;
    u3 = (unsigned)(-(unsigned)((int)((unsigned)c0 >> (r0.y & 31u)) >= (int)u2) == -(unsigned)((int)p0 >= (int)0xeddfba6au));
    { unsigned t5; double z5; if ((u1) & 1u) { t5 = (0x49b69644u + garr[u2 & 7u]); z5 = (double)(((unsigned)(x0 >> 70)) & 255u); } if ((u1) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
        do { if (--fuel == 0u) goto done;
            if (u3 == 7u) return (unsigned)h0;
        } while (i0++ < 2u && (((unsigned)e0 * 4u) & (unsigned)l0));
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(g1 && 1u), 0x7fffffffu, (unsigned)(0x7fffffffu || (0x10000u >> (1u & 31u)))); }
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            u1 = u1 * 0x9e3779b1u + g0;
            { unsigned t6; double z6; if (((0x8030bb86u % ((unsigned)w0 | 1u))) & 1u) { t6 = (unsigned)(0x10000u || (unsigned)l0); z6 = (double)((~(unsigned)(0xffffffffu && p1)) & 255u); } if (((0x8030bb86u % ((unsigned)w0 | 1u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                do { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return ((unsigned)(u3 || 5u) >> ((u2 % ((unsigned)(u1 < (unsigned)(x0 >> 70)) | 1u)) & 31u));
                    b0 = (unsigned)((int)fuel >= (int)(unsigned)e0) != 0u;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(i2, 0x5d2d5cc7u, (unsigned)!(r0.x << ((unsigned)((int)(unsigned)h0 >= (int)v0) & 31u))); }
                    x0 = x0 * 0x100000001b3ull + (*q0 / ((unsigned)(signed char)(garr[i1 & 7u] % (-(0x422f79au >> (i2 & 31u)) | 1u)) | 1u));
                } while (i1++ < 7u && (0x7fffffffu << (6u & 31u)));
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)0x10000u > (signed char)u2);
            }
            if ((unsigned)(g1 == 8u)) break;
            if ((unsigned)(short)(0x10000u + (p2 ^ 5u))) {
                *q0 = i2;
            } else {
                if ((unsigned)f0) continue;
            }
            goto L2;
            if (u3 == 7u) return (unsigned)((int)7u >= (int)(unsigned)!((unsigned)(signed char)(0xa464e17bu << (fuel & 31u)) / (((unsigned)c0 + *q0) | 1u)));
        }
        goto L0;
        c0 = (unsigned char)(unsigned)(x0 >> 70);
        if (((unsigned)((int)9u >= (int)7u) - (unsigned)c0)) {
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(signed char)(m0 - ~(unsigned)((unsigned)x0 || (unsigned)h0)), (g1 >> (1u & 31u)), 0xcb1467feu); }
            c1 = (signed char)(unsigned)((int)u3 < (int)fuel);
            w0 ^= (unsigned long long)(garr[u2 & 7u] & 0x80000000u) << (u2 & 63u);
            u3 = (unsigned)(unsigned char)((i2 % (1u | 1u)) << ((i0 | (unsigned)c1) & 31u));
            u1 += 0x859545fdu;
        }
    }
    u3 = u3 * 0x9e3779b1u + 7u;
    w0 = w0 * 6364136223846793005ull + v0;
    switch ((0xbe585a40u ^ r0.y) & 7u) {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t7; double z7; if (((0x7fffffffu ? i1 : a0[u1 & 3u])) & 1u) { t7 = 6u; z7 = (double)((u1) & 255u); } if (((0x7fffffffu ? i1 : a0[u1 & 3u])) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                v0 = (unsigned)(1u && v0);
                while (p0) { if (--fuel == 0u) goto done;
                    case 7u: ;
                    case 1u: ;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(g1, (unsigned)(0x80000000u < garr[u2 & 7u]), (unsigned)!(garr[u2 & 7u] << (p2 & 31u))); }
                    a0[(unsigned)(i2 < (unsigned)x0) & 3u] = (unsigned)((short)3u > (signed char)((v0 | (unsigned)(0xffffffffu || a0[i0 & 3u])) << (u0 & 31u)));
                }
            }
            *q0 = ~(unsigned)(garr[i1 & 7u] < r0.x);
            do { if (--fuel == 0u) goto done;
                b0 = ((unsigned)((short)5u > (signed char)i0) - ((unsigned)((int)0x80000000u < (int)g0) / ((unsigned)h0 | 1u))) != 0u;
            } while (i1++ < 5u && (0x4354e755u + (a0[u1 & 3u] | 6u)));
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)((int)(unsigned)(unsigned char)(2u - (unsigned)s0) < (int)0xffffffffu);
                { unsigned t8; double z8; if ((((v0 % (i2 | 1u)) % ((unsigned)(w0 >> 29) | 1u))) & 1u) { t8 = (*mp ^ 0x10000u); z8 = (double)(((unsigned)((short)*q0 > (signed char)(unsigned)(i1 == a0[u1 & 3u]))) & 255u); } if ((((v0 % (i2 | 1u)) % ((unsigned)(w0 >> 29) | 1u))) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                    g0 = u1;
                    u3 ^= u2;
                    u2 = u2 * 0x9e3779b1u + (unsigned)!((unsigned)(signed char)(unsigned)((int)0x10000u >= (int)(unsigned)((short)1u > (signed char)u3)) >> ((unsigned)(signed char)(0xffffffffu >> (garr[u2 & 7u] & 31u)) & 31u));
                    { unsigned t9; double z9; if (((unsigned)x0) & 1u) { t9 = (unsigned)e0; z9 = (double)(((unsigned)s1) & 255u); } if (((unsigned)x0) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                        for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                            r0.x = -((unsigned)((int)(4u % (a0[u1 & 3u] | 1u)) < (int)(unsigned)(0xc93d9253u || 2u)) - 0x10000u);
                            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(m0 == g1), (unsigned)((short)g0 > (signed char)(unsigned)h0), 3u); }
                            d0 = d0 * 0.5 + (double)((unsigned)((int)0xbc337b5u >= (int)0xffffffffu) & 1023u);
                            c1 = (signed char)(unsigned)((short)-(unsigned)((unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)((short)p1 > (signed char)v0)) == 8u) > (signed char)u0);
                            if (budget != 0u) { budget -= 1u; u2 = fn0((((unsigned)x0 * i0) | 0xcc74c697u), (0x2a23da2u ^ i0), ((unsigned)c0 ^ (unsigned)c1)); }
                        }
                        for (;;) { if (--fuel == 0u) goto done;
                            u0 = (a0[u1 & 3u] | 0x7fffffffu);
                            if ((unsigned)((unsigned)b0 || (0x3e7a45e2u << ((unsigned)s1 & 31u)))) break;
                        }
                        u3 ^= ~(unsigned)(a0[i0 & 3u] == fuel);
                        if (budget != 0u) { budget -= 1u; u0 = fn1(*mp, 0x10000u, (unsigned)((0x80000000u % (u0 | 1u)) || fuel)); }
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!(unsigned)((unsigned)(signed char)(0xff48dc44u / (0xfb208c17u | 1u)) == 7u), (unsigned)(garr[i1 & 7u] || p2), 0x10000u); }
                    }
                    default: ;
                }
            }
        }
        case 6u: ;
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)c0;
    if (i2) goto L1;
    while ((unsigned)l0) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)((short)(0x7fffffffu << (0xf4040dd2u & 31u)) > (signed char)0u) & 7u) {
                w0 = w0 * 6364136223846793005ull + ((unsigned)((short)a0[u1 & 3u] > (signed char)r0.y) - (unsigned)f0);
            }
            e0 = e0 * 0.5L + (long double)((unsigned)!(0x10000u >> ((unsigned)(signed char)(2u ^ (unsigned)(p2 || (unsigned)((short)0x80000000u > (signed char)0x7fffffffu))) & 31u)) & 1023u);
            u3 = u3 * 0x9e3779b1u + (unsigned)(unsigned char)((unsigned)(0x7fc74671u || 1u) & 0xffffffffu);
            u3 ^= (unsigned)(g0 == (8u % ((unsigned)((short)v0 > (signed char)0x10000u) | 1u)));
        }
        goto L3;
        s0 = (int)(unsigned)(short)(unsigned)(i1 == (i0 + p0));
        d0 = d0 * 0.5 + (double)(a0[u1 & 3u] & 1023u);
        if (((unsigned)f0 % ((unsigned)(*mp && 9u) | 1u))) goto L2;
        *q0 = (unsigned)(0x3b1ef3d9u == v0);
    }
    f0 = f0 * 0.5f + (float)(i1 & 255u);
    do { if (--fuel == 0u) goto done;
        if ((((unsigned)f0 | r0.x) | 0x80000000u)) continue;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((0xffffffffu << ((unsigned)(i2 || 0xffffffffu) & 31u)), (unsigned)((int)(unsigned)h1 >= (int)i0), ((unsigned)(signed char)(garr[u2 & 7u] >> (a0[i0 & 3u] & 31u)) - u3)); }
            h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)(unsigned char)(0x1f7148bfu * 0xffffffffu) >= (int)(u0 + i1)));
            if (u3) goto L1;
        } while (i1++ < 6u && (unsigned)((garr[i1 & 7u] >> (a0[i0 & 3u] & 31u)) && r0.y));
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            s0 = (int)(i2 & ((unsigned)c0 ^ (unsigned)(fuel == 6u)));
            if (((unsigned)x0 / (v0 | 1u))) {
                if ((unsigned)((int)r0.x < (int)0x8d366f0du)) break;
                break; (void)(((unsigned)(w0 >> 29) | (unsigned)((int)(unsigned)s0 >= (int)(unsigned)c1)));
                g1 += i0;
                c0 = (unsigned char)(unsigned)(short)((unsigned)(w0 >> 29) & (unsigned)(short)(3u + (i1 & p2)));
            }
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((3u + -(p2 | i1))) break;
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (4u) {
                        if (u1) break;
                    }
                }
                d0 = d0 * 0.5 + (double)(m0 & 1023u);
                break; (void)((garr[i1 & 7u] | u3));
                break; (void)(((unsigned)((int)0x7fffffffu < (int)u2) + garr[u2 & 7u]));
                if ((8u ^ ((unsigned)h0 % (0x80000000u | 1u)))) break;
            }
            if (((unsigned)(x0 >> 70) << (g1 & 31u))) goto L1;
        }
        i1 = ((unsigned)(x0 >> 70) + (unsigned)((int)0xb67060a1u >= (int)garr[u2 & 7u])) & 15u;
        continue; (void)((*mp ^ 0x75a946dau));
        if ((unsigned)!(unsigned)((short)0xad1b1048u > (signed char)7u)) goto L3;
    } while (i0++ < 5u && (1u + (unsigned)l0));
    *q0 += fuel;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)((unsigned)(unsigned char)((unsigned)s1 - (unsigned)((unsigned)c0 || v0)) & 0xaf7853ecu);
    }
    switch (i2 & 7u) {
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)c1 && (unsigned)x0), ((unsigned)((unsigned)d0 < v0) | 0x80000000u), 8u); }
        u2 += (unsigned)(p1 && ((unsigned)(g1 == 0xc78c819u) - (unsigned)c1));
    }
    if ((unsigned)((short)((unsigned)h1 - (unsigned)h1) > (signed char)(unsigned)b0)) {
        if ((unsigned)!((unsigned)(w0 >> 29) << (u3 & 31u))) goto L4;
        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(r0.x * r0.x) & 1023u);
    } else {
        if ((unsigned)(unsigned char)((*q0 << (a0[u1 & 3u] & 31u)) - 6u)) {
            if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((int)6u < (int)fuel) / (0xd70be735u | 1u)), ((unsigned)c0 / (a0[u1 & 3u] | 1u)), (unsigned)(0x7fffffffu && (0x57fbf6f0u & 0x7fffffffu))); }
            *q0 = (0x6f73d963u | (r0.x + garr[u2 & 7u]));
            m0 ^= (unsigned)((int)(v0 - 0x5d831d30u) >= (int)g0);
            if ((unsigned)((int)(unsigned)h1 < (int)a0[i0 & 3u])) goto L4;
            goto done;
        } else {
            w0 ^= (unsigned long long)0x80000000u << ((unsigned)(signed char)(a0[i0 & 3u] ? (0x9e102185u % (r0.x | 1u)) : p2) & 63u);
            u1 = (0x80000000u << ((unsigned)(short)(unsigned)(9u < (u2 ? (unsigned)w0 : (unsigned)(w0 >> 29))) & 31u));
        }
        for (;;) { if (--fuel == 0u) goto done;
            i0 = 4u & 15u;
            u0 = u0 * 0x9e3779b1u + i1;
            break; (void)((i2 & u2));
            { unsigned t10; double z10; if ((0x80000000u) & 1u) { t10 = ((unsigned)e0 % (fuel | 1u)); z10 = (double)(((unsigned)f0) & 255u); } if ((0x80000000u) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                u2 ^= (unsigned)((int)p2 >= (int)v0);
                do { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (unsigned)d0;
                } while (i1++ < 4u && v0);
                garr[0x7fffffffu & 7u] = ((unsigned)(0x714e1f22u && r0.x) << (u3 & 31u));
            }
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(g1 == g1), ((unsigned)(w0 >> 29) >> (g1 & 31u)), (unsigned)w0); }
    { unsigned t0; double z0; if (((unsigned)e0) & 1u) { t0 = (unsigned)s1; z0 = (double)(((i0 ^ ((unsigned)e0 * 0xffffffffu))) & 255u); } if (((unsigned)e0) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        *q0 += ((unsigned)((int)(unsigned)e0 >= (int)5u) | ((unsigned)((short)p1 > (signed char)garr[i1 & 7u]) % (0xffffffffu | 1u)));
    }
    if (budget != 0u) { budget -= 1u; u0 = fn2((g0 << (0x8039205du & 31u)), (u2 % (g0 | 1u)), (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(0x550c4430u & 0x80000000u))); }
    r0.x = (p0 / ((unsigned)(signed char)(0x10000u - 0x4bf1a924u) | 1u));
    if (p0) goto L1;
    if (((unsigned)x0 % ((unsigned)(signed char)(p2 | u3) | 1u))) goto L0;
    v0 = (unsigned)((unsigned)(fuel < 5u) && (*q0 ^ 0x10000u));
    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)((unsigned)f0 || garr[i1 & 7u]) / (u3 | 1u)), (v0 + p2), ((unsigned)b0 >> ((7u - (unsigned)d0) & 31u))); }
    L0: if (--fuel == 0u) goto done;
    if ((unsigned)s1) {
        if ((m0 / (0x5ef4bc8bu | 1u))) {
            if ((unsigned)((int)(unsigned)s0 < (int)(unsigned)d0)) {
                if ((0xafff6u ^ *mp)) {
                    if (u3 == 7u) return (0xffffffffu ? g1 : *q0);
                }
                s1 = (int)((unsigned)s1 + (unsigned)(signed char)((unsigned)d0 % (r0.y | 1u)));
                L1: if (--fuel == 0u) goto done;
            }
        }
        goto L3;
    } else {
        if ((unsigned)(0x10000u < i2)) {
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (unsigned)s1;
                c0 = (unsigned char)((unsigned)(9u && fuel) % ((unsigned)((int)0x7fffffffu >= (int)p2) | 1u));
                f0 = f0 * 0.5f + (float)((g1 << ((unsigned)w0 & 31u)) & 255u);
                L2: if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)c1 && (0xaed62e9au - u1))) break;
                garr[m0 & 7u] = ((i0 - i0) % ((unsigned)(*mp == (unsigned)(2u && 0xc6f4f36du)) | 1u));
            }
            for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)((int)garr[i1 & 7u] < (int)(unsigned)((int)a0[u1 & 3u] < (int)p2)) & 7u];
                if (budget != 0u) { budget -= 1u; u3 = fn2((g0 >> ((0x7eec0fbbu & (unsigned)w0) & 31u)), p0, (0x80000000u / ((unsigned)(signed char)(unsigned)((int)8u < (int)g1) | 1u))); }
            }
            *q0 = ((g0 & (unsigned)x0) & i0);
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return (unsigned)!(unsigned)(i0 && (unsigned)h0);
                q0 = &garr[(*mp * ((unsigned)s1 ^ fuel)) & 7u];
                if ((unsigned)((int)(0x2627e846u >> (u0 & 31u)) < (int)i2)) break;
                goto done;
            }
            if (0x80000000u) {
                L3: if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)((unsigned)l0 >> (6u & 31u)) << ((unsigned)b0 & 63u);
                { unsigned t1; double z1; if ((p1) & 1u) { t1 = a0[i0 & 3u]; z1 = (double)(((unsigned)((short)p2 > (signed char)0x7fffffffu)) & 255u); } if ((p1) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)(unsigned char)(2u ^ 0xffffffffu)) break;
                        break; (void)(i1);
                        e0 = e0 * 0.5L + (long double)(((8u ^ (unsigned)s0) & p0) & 1023u);
                        f0 = f0 * 0.5f + (float)(((0x7fffffffu * (unsigned)h1) >> ((a0[u1 & 3u] % (((unsigned)f0 ^ *q0) | 1u)) & 31u)) & 255u);
                        L4: if (--fuel == 0u) goto done;
                    }
                }
                *mp = (~((unsigned)(u3 && 1u) | (unsigned)(x0 >> 70)) << (((unsigned)x0 << (*mp & 31u)) & 31u));
                goto L0;
                if (r0.x) goto L1;
            }
            if (((unsigned)f0 / (0x80000000u | 1u))) goto L2;
        }
    }
    switch ((unsigned)s1 & 7u) {
        if ((unsigned)((int)0x7fffffffu >= (int)(u3 | 0x9d271ae1u))) goto L0;
        { unsigned t2; double z2; if (((garr[i1 & 7u] + 6u)) & 1u) { t2 = 5u; z2 = (double)((i1) & 255u); } if (((garr[i1 & 7u] + 6u)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            h0 = (short)((unsigned)((0x10000u << (i2 & 31u)) < a0[i0 & 3u]) / ((unsigned)w0 | 1u));
            m0 ^= 0xf69dcc31u;
            if (r0.y) goto done;
            u3 ^= (unsigned)(u1 < (unsigned)(i2 || ~(unsigned)((unsigned)(w0 >> 29) || m0)));
            for (;;) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + ((i2 & (v0 * (unsigned)s0)) << ((unsigned)h1 & 31u)));
                g1 += (unsigned)(x0 >> 70);
                while (i1++ < 2u && ((unsigned)s0 << ((unsigned)(x0 >> 70) & 31u))) { if (--fuel == 0u) goto done;
                    if ((r0.x & 0x2eb61210u)) break;
                    *mp = (unsigned)((p1 + a0[u1 & 3u]) && fuel);
                    s0 = (int)((4u ^ u0) / (((unsigned)(garr[i1 & 7u] == 0xd489e907u) >> (*mp & 31u)) | 1u));
                }
                case 6u: ;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(unsigned)(p0 || 8u));
                    s1 = (int)((unsigned)s1 + (unsigned)(garr[i1 & 7u] && (0xee2db110u - a0[u1 & 3u])));
                    d0 = d0 * 0.5 + (double)((p2 & (0xad8a6d81u >> (u1 & 31u))) & 1023u);
                    if (4u) continue;
                }
                g0 = ((unsigned)((short)(unsigned)b0 > (signed char)i0) >> (u2 & 31u));
            }
            case 7u: ;
        }
        while ((unsigned)((int)r0.y < (int)0x8784b89au)) { if (--fuel == 0u) goto done;
            case 4u: ;
            c1 = (signed char)(unsigned)(((unsigned)f0 & ((unsigned)c0 - u2)) < (unsigned)((short)(unsigned)w0 > (signed char)7u));
            if (budget != 0u) { budget -= 1u; u0 = fn0(7u, (8u >> ((unsigned)(0xcec144d9u == *mp) & 31u)), (0xffffffffu >> ((unsigned)((int)i1 < (int)*mp) & 31u))); }
        }
    }
    while (i0++ < 6u && (unsigned)((r0.y ^ 3u) || *mp)) { if (--fuel == 0u) goto done;
        if (*q0) {
            a0[(unsigned)((short)7u > (signed char)(unsigned)b0) & 3u] = (m0 << (0x1c40bc07u & 31u));
            if (((unsigned)h1 & a0[u1 & 3u])) {
                if ((unsigned)(signed char)(unsigned)((1u + u1) || 0u)) break;
                h0 = (short)-(unsigned)((int)(unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)((int)0x80000000u < (int)0x2e9f9336u)) >= (int)a0[i0 & 3u]);
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)x0 & i1), (garr[i1 & 7u] * (unsigned)f0), 0x1f4a2e2u); }
                    if ((0x10000u << ((unsigned)((unsigned)(x0 >> 70) == (unsigned)f0) & 31u))) continue;
                    r0.y ^= (unsigned)(((u3 / (0xc105c225u | 1u)) - 0x80000000u) < -(garr[i1 & 7u] >> (p0 & 31u)));
                } while (i1++ < 3u && (unsigned)((int)m0 >= (int)0x10000u));
                if (u3 == 7u) return (unsigned)((unsigned)l0 || i1);
                if (0x7fffffffu) break;
            } else {
                l0 = (long)((unsigned long)l0 + ((unsigned)(x0 >> 70) & (unsigned)e0));
                r0.y ^= (unsigned)(x0 >> 70);
                garr[(unsigned)(p2 && 0x6805743eu) & 7u] = (((unsigned)x0 ^ (unsigned)((short)((unsigned)(w0 >> 29) | 0x7fffffffu) > (signed char)(unsigned)b0)) | (unsigned)c1);
            }
            w0 = w0 * 6364136223846793005ull + (garr[u2 & 7u] + (0x10000u ? ((unsigned)w0 - 7u) : 0x37236e76u));
        }
        if ((unsigned)(short)((unsigned)d0 << (0x245b3989u & 31u))) break;
        s0 = (int)(unsigned)c1;
        if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)x0 >= (int)((unsigned)s0 << (0xa43a4a68u & 31u)))) continue;
        e0 = e0 * 0.5L + (long double)((unsigned)c0 & 1023u);
        do { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + ((u3 | 8u) % (p1 | 1u));
            q0 = &garr[(unsigned)((g1 & (unsigned)c1) == 0x80000000u) & 7u];
            if ((unsigned)b0) {
                if (fuel < 8u) return u3;
                r0.y ^= (unsigned)(((unsigned)((int)(unsigned)d0 < (int)9u) % ((unsigned)e0 | 1u)) < (unsigned)((unsigned)(w0 >> 29) || v0));
            }
            w0 ^= (unsigned long long)(unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)f0) << ((unsigned)((int)(unsigned)((int)a0[i0 & 3u] >= (int)7u) >= (int)(unsigned)s1) & 63u);
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                a0[(unsigned)h0 & 3u] = *mp;
                if ((u2 * -(0xdf43d062u >> ((unsigned)d0 & 31u)))) {
                    *q0 += ((5u ? (unsigned)h1 : *mp) % ((i0 >> (0xd9c987a5u & 31u)) | 1u));
                    do { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((unsigned)w0 || (unsigned)(unsigned char)((unsigned)e0 * (unsigned)h0)));
                        switch (0x71196b20u & 7u) {
                            w0 ^= (unsigned long long)0xfe190d33u << (((u1 / (m0 | 1u)) >> (0xffffffffu & 31u)) & 63u);
                            case 2u: ;
                            case 5u: ;
                            u1 = ((unsigned)((int)(unsigned)((int)p1 >= (int)i2) >= (int)0xb38f3f23u) + 0x3b963a53u);
                            u1 = 0x4f7b4101u;
                            if (((unsigned)((int)p2 >= (int)0xf7ce90c6u) ^ (unsigned)h1)) goto L4;
                        }
                        break; (void)(((unsigned)c1 % ((unsigned)e0 | 1u)));
                        if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)!((unsigned)s0 | 0x4e6d2ce9u), (0x6e2a1de1u - (unsigned)((int)(unsigned)(w0 >> 29) < (int)g1)), ((a0[u1 & 3u] & p1) & 0xa2feda89u)); }
                        if (0x69d9864du) break;
                        if (v0) goto L1;
                    } while (i0++ < 5u && (unsigned)(u2 || (unsigned)(garr[u2 & 7u] || p0)));
                } else {
                    if (0xef024c04u) break;
                    i0 = (unsigned)(u0 || (3u - (*q0 >> (0x7fcbe58eu & 31u)))) & 15u;
                    g1 += (unsigned)((0x4deb50f2u % (i0 | 1u)) < u1);
                    i0 = (unsigned)((int)(unsigned)(w0 >> 29) >= (int)0x80000000u) & 15u;
                }
                switch (((unsigned)(r0.y == u2) - p0) & 7u) {
                    r0.x = (((unsigned)e0 | p0) << ((unsigned)((int)(unsigned)s1 >= (int)((unsigned)d0 & (unsigned)e0)) & 31u));
                    w0 = w0 * 6364136223846793005ull + (unsigned)((i2 << (a0[i0 & 3u] & 31u)) == i1);
                    f0 = f0 * 0.5f + (float)((unsigned)(*mp && (unsigned)((int)u3 >= (int)0x44539eb7u)) & 255u);
                }
                u3 ^= (unsigned)(i0 && garr[i1 & 7u]);
                r0.y ^= (unsigned)(short)(u0 * r0.x);
            }
            if ((unsigned)((int)p0 >= (int)a0[u1 & 3u])) break;
        } while (i1++ < 5u && 0xffffffffu);
    }
    switch (g1 & 7u) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                u0 = u0 * 0x9e3779b1u + (unsigned)((a0[i0 & 3u] * 0x10000u) || (unsigned)((int)g0 >= (int)(unsigned)(x0 >> 70)));
                case 1u: ;
                if ((unsigned)(4u == g1)) goto done;
                case 6u: ;
                u2 = u2 * 0x9e3779b1u + ((unsigned)(garr[u2 & 7u] < *mp) | i2);
                do { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + ((unsigned)((int)(1u >> (0x80000000u & 31u)) >= (int)((unsigned)(x0 >> 70) | (unsigned)d0)) | (unsigned)d0);
                    { unsigned t3; double z3; if ((garr[u2 & 7u]) & 1u) { t3 = (unsigned)b0; z3 = (double)((((unsigned)((unsigned)b0 < (unsigned)h1) | 3u)) & 255u); } if ((garr[u2 & 7u]) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                        r0.y ^= (p0 & a0[u1 & 3u]);
                        case 7u: ;
                        default: ;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)e0, ((unsigned)f0 & ((unsigned)h0 + u2)), (fuel & (unsigned)((short)3u > (signed char)i0))); }
                        if ((0x3b9489e8u >> ((unsigned)h0 & 31u))) break;
                        *q0 += ((unsigned)((0xffffffffu << (*q0 & 31u)) < (unsigned)l0) / (0x80000000u | 1u));
                    }
                    f0 = f0 * 0.5f + (float)(~(r0.y / ((unsigned)(signed char)((unsigned)((short)g0 > (signed char)r0.y) ? i0 : 2u) | 1u)) & 255u);
                } while (i2++ < 3u && (unsigned)l0);
            }
            break;
            if (u3) goto L2;
            break; (void)(0xffffffffu);
            v0 = (unsigned)(signed char)(unsigned)((int)0x10000u >= (int)(7u - (unsigned)f0));
        }
        if (0x515ab513u) {
            s0 = (int)a0[i0 & 3u];
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)h1 < (unsigned)(short)(garr[i1 & 7u] | *mp));
    }
    { unsigned t4; double z4; if (((unsigned)!((unsigned)c1 % ((unsigned)((int)r0.x >= (int)6u) | 1u))) & 1u) { t4 = 0xb3baa9dau; z4 = (double)(((garr[i1 & 7u] & *q0)) & 255u); } if (((unsigned)!((unsigned)c1 % ((unsigned)((int)r0.x >= (int)6u) | 1u))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
        if (((unsigned)h0 * (*q0 << ((unsigned)f0 & 31u)))) {
            if (budget != 0u) { budget -= 1u; u0 = fn2(0x80000000u, (unsigned)((int)(unsigned)x0 < (int)(unsigned)c1), (unsigned)(9u && (unsigned)((unsigned)f0 || i1))); }
            if ((unsigned)(unsigned char)(unsigned)((unsigned)d0 && 0x7fffffffu)) goto L0;
        }
        if ((unsigned)e0) {
            if (0x42ce647du) goto L3;
            if (((unsigned)h1 - (0x956a3dbdu / (u1 | 1u)))) {
                c0 = (unsigned char)-(0x58520e90u * r0.x);
                b0 = g1 != 0u;
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(r0.x || 0x80000000u)) break;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0(a0[i0 & 3u], (*q0 & p1), (unsigned)x0); }
                s1 = (int)((unsigned)s1 + 0x1500fcf6u);
                goto L2;
            }
            { unsigned t5; double z5; if (((unsigned)((int)(unsigned)((int)u2 >= (int)p2) >= (int)0x22fd9374u)) & 1u) { t5 = (unsigned)((unsigned)(8u || 4u) || *q0); z5 = (double)(((p1 ? (unsigned)b0 : i1)) & 255u); } if (((unsigned)((int)(unsigned)((int)u2 >= (int)p2) >= (int)0x22fd9374u)) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                goto L4;
                if ((0xffffffffu | 3u)) {
                    goto L0;
                    l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)(u2 || i2));
                    if ((0x197c5d97u * (unsigned)s1)) {
                        if (((0xffffffffu & (unsigned)h0) % ((unsigned)b0 | 1u))) goto L2;
                        u2 = u2 * 0x9e3779b1u + ~((unsigned)((int)0x4cc69cc0u >= (int)g1) ^ (unsigned)h1);
                        if ((unsigned)(7u == (unsigned)c1)) goto L1;
                    }
                    goto done;
                } else {
                    if (p2) goto L4;
                    e0 = e0 * 0.5L + (long double)(((unsigned)(~(unsigned)((int)(unsigned)h0 >= (int)fuel) < (unsigned)s0) % ((unsigned)(unsigned char)(unsigned)(0x875192b1u && (unsigned)c1) | 1u)) & 1023u);
                    x0 = x0 * 0x100000001b3ull + (((unsigned)h1 >> ((*q0 + fuel) & 31u)) + (unsigned)x0);
                }
                i0 = (unsigned)((short)(((unsigned)s0 * a0[i0 & 3u]) << ((unsigned)(unsigned char)(0xffffffffu << (u3 & 31u)) & 31u)) > (signed char)*q0) & 15u;
            }
            { unsigned t6; double z6; if (((unsigned)(u0 || u3)) & 1u) { t6 = (8u + r0.x); z6 = (double)((garr[i1 & 7u]) & 255u); } if (((unsigned)(u0 || u3)) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                u3 ^= ((unsigned)(signed char)(unsigned)(0x1a4d890du == g1) / (0xab3472c3u | 1u));
                g1 += (unsigned)((short)(unsigned)x0 > (signed char)0x7fffffffu);
                if (r0.y) goto L1;
                if ((garr[i1 & 7u] << (4u & 31u))) goto L4;
                if (0xb34b5867u) goto L1;
            }
            switch ((unsigned)e0 & 7u) {
                r0.x = 0x40a2305fu;
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(u1 && (0xe5200e1eu - 0x1b15f723u)), u0, (unsigned)((unsigned)b0 && (unsigned)e0)); }
                goto L4;
            }
        } else {
            if (fuel < 8u) return (unsigned)(((unsigned)c1 - (unsigned)c1) == (unsigned)c0);
            goto L2;
        }
    }
    *q0 = ((unsigned)c1 - (((unsigned)((short)(unsigned)x0 > (signed char)r0.y) / (garr[i1 & 7u] | 1u)) >> (0x10000u & 31u)));
    if ((unsigned)((short)g1 > (signed char)(unsigned)(w0 >> 29))) goto done;
    u0 = u0 * 0x9e3779b1u + (((u0 - fuel) ^ (unsigned)f0) & ~((unsigned)(x0 >> 70) - 0xa87fe1a1u));
    if (budget != 0u) { budget -= 1u; u1 = fn0(*mp, 0x37a4cf69u, (0xeb3e12e9u | (unsigned)x0)); }
    if (((unsigned)(p0 < r0.y) ^ garr[i1 & 7u])) {
        while (i0++ < 4u && (8u ^ m0)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)0u < (int)g1), (unsigned)s0, *mp); }
            { unsigned t7; double z7; if ((((unsigned)c0 % ((unsigned)(m0 < (unsigned)f0) | 1u))) & 1u) { t7 = (0xffffffffu % ((unsigned)c0 | 1u)); z7 = (double)(((unsigned)(unsigned char)(unsigned)((short)u2 > (signed char)(a0[u1 & 3u] + (unsigned)(x0 >> 70)))) & 255u); } if ((((unsigned)c0 % ((unsigned)(m0 < (unsigned)f0) | 1u))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                { unsigned t8; double z8; if (((unsigned)((unsigned)((int)0x9dc44ad0u < (int)u3) < 0xffffffffu)) & 1u) { t8 = r0.x; z8 = (double)((9u) & 255u); } if (((unsigned)((unsigned)((int)0x9dc44ad0u < (int)u3) < 0xffffffffu)) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                    break; (void)((i2 * v0));
                    e0 = e0 * 0.5L + (long double)(((unsigned)(0x1e4c0b74u == 0u) * (unsigned)((unsigned)x0 || 2u)) & 1023u);
                    if (i1) break;
                    *q0 = garr[u2 & 7u];
                    break; (void)((unsigned)!(unsigned)(fuel < 0x2c8379a4u));
                    r0.y ^= (*mp * (0x80000000u >> (0x9bb49c40u & 31u)));
                }
                { unsigned t9; double z9; if (((garr[u2 & 7u] - (p2 * (unsigned)x0))) & 1u) { t9 = ((unsigned)(signed char)(unsigned)((int)0x2ed9ac58u >= (int)u1) * 0xffffffffu); z9 = (double)((g0) & 255u); } if (((garr[u2 & 7u] - (p2 * (unsigned)x0))) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                    if ((unsigned)(short)((unsigned)c1 & r0.x)) goto done;
                    r0.y ^= (unsigned)(w0 >> 29);
                    while ((unsigned)x0) { if (--fuel == 0u) goto done;
                        a0[u2 & 3u] = (unsigned)((unsigned)(w0 >> 29) == (unsigned)((int)i2 < (int)((unsigned)e0 ? (unsigned)e0 : p1)));
                        b0 = (p1 ? p2 : (unsigned)((short)((unsigned)c0 * u0) > (signed char)garr[i1 & 7u])) != 0u;
                        u3 = (unsigned)((int)(unsigned)((int)0x33198f1fu < (int)*mp) >= (int)(unsigned)b0);
                    }
                }
                if ((unsigned)(((unsigned)c1 - r0.x) == (unsigned)(w0 >> 29))) break;
                break; (void)((9u * (unsigned)(short)((unsigned)(x0 >> 70) ^ 0x80000000u)));
                while (i1++ < 6u && (unsigned)(*q0 < fuel)) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)((i1 | 0x80000000u) < (unsigned)f0));
                }
            }
            l0 = (long)((unsigned long)l0 + ((unsigned)((int)(unsigned)f0 < (int)0x6cbc5bbcu) << ((((unsigned)e0 - 0xffffffffu) ^ (unsigned)e0) & 31u)));
            do { if (--fuel == 0u) goto done;
                b0 = (unsigned)((int)(0xe8689d36u ^ ((0x10000u / ((unsigned)c1 | 1u)) & (unsigned)f0)) < (int)(unsigned)h0) != 0u;
                if (u2) goto L4;
                q0 = &garr[(unsigned)((int)5u >= (int)0x54790baau) & 7u];
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((r0.x << (0x7fffffffu & 31u)) & 1023u);
                    if (fuel < 8u) return 7u;
                    w0 = w0 * 6364136223846793005ull + (unsigned)s1;
                    if (budget != 0u) { budget -= 1u; u0 = fn2((v0 & ((unsigned)b0 / (p1 | 1u))), i1, (unsigned)((int)4u < (int)(7u - 7u))); }
                    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)(~(unsigned)((int)i0 < (int)(unsigned)((short)(unsigned)h0 > (signed char)(unsigned)f0)));
                        g0 = (((unsigned)h1 / (u0 | 1u)) >> ((unsigned)((int)0x60ffa59au < (int)(unsigned)((int)(unsigned)f0 < (int)r0.y)) & 31u));
                        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(p1 && (unsigned)c0), *mp, (9u * (unsigned)c0)); }
                        continue; (void)((unsigned)((short)garr[u2 & 7u] > (signed char)(u2 >> (garr[i1 & 7u] & 31u))));
                        continue; (void)((unsigned)(3u == a0[u1 & 3u]));
                    }
                    *q0 += (unsigned)b0;
                }
                s1 = (int)((unsigned)s1 + (r0.x - r0.x));
                if (((unsigned)s0 / ((5u ^ (unsigned)e0) | 1u))) continue;
            } while (i1++ < 5u && 0x7fffffffu);
            for (;;) { if (--fuel == 0u) goto done;
                q0 = &garr[i1 & 7u];
                s0 = (int)(0xffffffffu << ((unsigned)((int)0x80000000u < (int)g1) & 31u));
                q0 = &garr[((unsigned)s0 | (unsigned)(unsigned char)((unsigned)d0 % ((unsigned)c1 | 1u))) & 7u];
                c1 = (signed char)0xb085ebc7u;
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((0xffffffffu >> (0x2053cbadu & 31u)) && (unsigned)c1), (unsigned)(short)(p0 * 0x7fffffffu), g1); }
            }
        }
        do { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t10; double z10; if (((0u << (m0 & 31u))) & 1u) { t10 = (unsigned)e0; z10 = (double)(((unsigned)(0x10000u && 4u)) & 255u); } if (((0u << (m0 & 31u))) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
                    if ((0x7fffffffu * g1)) break;
                    c0 = (unsigned char)(v0 | 0x7fffffffu);
                    c0 = (unsigned char)(unsigned)((int)garr[i1 & 7u] < (int)(unsigned)(0xffffffffu && 0x80000000u));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((v0 % ((*mp % (p2 | 1u)) | 1u)), (unsigned)b0, (unsigned)(signed char)(a0[i0 & 3u] << ((unsigned)f0 & 31u))); }
                    if (9u) {
                        if ((i2 & 8u)) break;
                        w0 ^= (unsigned long long)(4u - a0[u1 & 3u]) << ((unsigned)((int)(u3 ? p1 : 0x10000u) >= (int)(p1 | 8u)) & 63u);
                        if (budget != 0u) { budget -= 1u; u3 = fn0(0x7fffffffu, -(garr[u2 & 7u] + v0), u0); }
                        e0 = e0 * 0.5L + (long double)((a0[i0 & 3u] ? 0x10000u : fuel) & 1023u);
                    }
                }
                *mp = (u3 | (p0 % (3u | 1u)));
                v0 = (a0[u1 & 3u] * ((unsigned)h0 * a0[i0 & 3u]));
                break; (void)((unsigned)((short)(7u | (unsigned)f0) > (signed char)a0[u1 & 3u]));
            }
        } while (i0++ < 6u && (0x7fffffffu + a0[i0 & 3u]));
        if ((0x80000000u << ((unsigned)(0x80000000u && i1) & 31u))) goto L4;
    }
    do { if (--fuel == 0u) goto done;
        if (r0.x) break;
        if ((*mp * (unsigned)((unsigned)c1 == (unsigned)c1))) break;
        if ((unsigned)(i1 || (unsigned)l0)) break;
        do { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn2(*q0, (0x10000u / (i0 | 1u)), 0x59ab4e8fu); }
                if (((unsigned)(x0 >> 70) / ((unsigned)(0x5e7b906bu && 0xcd7d90d9u) | 1u))) goto L3;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)p0 >= (int)(0x1900a421u | 0u)), (5u >> (((unsigned)h0 + 0x4abde917u) & 31u)), (*q0 | 5u)); }
            }
            e0 = e0 * 0.5L + (long double)(g0 & 1023u);
            d0 = d0 * 0.5 + (double)((unsigned)!((unsigned)(0xffffffffu == (unsigned)c0) & 0xffffffffu) & 1023u);
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)((unsigned)c1 || (*mp & r0.x)));
                if (budget != 0u) { budget -= 1u; u2 = fn1((0xe503acbau << ((unsigned)b0 & 31u)), (unsigned)((unsigned)((unsigned)c0 || i2) && (unsigned)h0), (unsigned)((int)u1 >= (int)6u)); }
                for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (0x9f64723cu ? 0x1161f71u : (unsigned)((short)*mp > (signed char)i0));
                    continue; (void)((unsigned)((short)(u3 - 7u) > (signed char)(unsigned)w0));
                    w0 = w0 * 6364136223846793005ull + (i1 + (unsigned)b0);
                    for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((u0 << ((unsigned)c1 & 31u))) break;
                    }
                }
            }
        } while (i1++ < 3u && (unsigned)(unsigned char)(unsigned)((short)((unsigned)x0 & p1) > (signed char)(unsigned)w0));
    } while (i0++ < 2u && (unsigned)(x0 >> 70));
    g1 += garr[u2 & 7u];
    switch ((unsigned)e0 & 7u) {
        if ((unsigned)(signed char)((a0[u1 & 3u] - 0xd17237bdu) ^ r0.y)) {
            r0.x = (0xffffffffu * v0);
            case 3u: ;
        }
        c1 = (signed char)~(((unsigned)f0 + (unsigned)(8u || (unsigned)w0)) ? (unsigned)(x0 >> 70) : (unsigned)f0);
        if (budget != 0u) { budget -= 1u; u1 = fn2((8u + ~(u3 << (0x7fffffffu & 31u))), (6u - garr[i1 & 7u]), (unsigned)((short)*mp > (signed char)(unsigned)(w0 >> 29))); }
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)(unsigned)(((unsigned)d0 | i2) < (unsigned)s0), 0x80000000u, u2); }
        if ((garr[u2 & 7u] + (unsigned)(x0 >> 70))) continue;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((6u - (unsigned)(w0 >> 29)) & 1023u);
        continue; (void)((unsigned)x0);
        if (fuel < 8u) return i2;
        { unsigned t11; double z11; if (((0x948c2ecbu | *q0)) & 1u) { t11 = (unsigned)(unsigned char)(((unsigned)(x0 >> 70) - 0x9d7f5941u) >> (u2 & 31u)); z11 = (double)(((0xf756b993u << (0x80000000u & 31u))) & 255u); } if (((0x948c2ecbu | *q0)) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
            w0 ^= (unsigned long long)~(unsigned)(0x7fffffffu || v0) << ((unsigned)((0x56f160c4u * i1) && (unsigned)(garr[u2 & 7u] && (unsigned)(garr[u2 & 7u] == r0.y))) & 63u);
            u3 ^= (unsigned)(signed char)(unsigned)(r0.y == i0);
            g0 = (unsigned)(unsigned char)(unsigned)((short)(r0.y % (-(0u ^ 3u) | 1u)) > (signed char)(0xffffffffu + r0.y));
            if (garr[i1 & 7u]) break;
            if (*mp) break;
        }
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (unsigned)(short)(unsigned)((unsigned)(w0 >> 29) && (0x55322f93u >> (0x7fffffffu & 31u)));
        if ((unsigned)(0x10000u < u2)) goto L0;
        *q0 = (~(unsigned)(u3 && (unsigned)(x0 >> 70)) ? (unsigned)s1 : g1);
        u0 += (unsigned)(unsigned char)((unsigned)((int)8u >= (int)garr[i1 & 7u]) << ((unsigned)x0 & 31u));
    }
    if ((unsigned)(unsigned char)(unsigned)((int)v0 >= (int)(unsigned)(x0 >> 70))) goto L3;
    if ((unsigned)(9u < 2u)) goto L0;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        *q0 = ((i1 & (9u & 8u)) ^ (unsigned)e0);
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (u3) continue;
        }
    }
    *q0 = (unsigned)(0x10000u || ((~(9u / ((unsigned)w0 | 1u)) * 3u) * *mp));
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t12; double z12; if ((4u) & 1u) { t12 = (unsigned)((unsigned)d0 < (0x5c860022u + u2)); z12 = (double)(((unsigned)((unsigned)c1 || 0xbc747fabu)) & 255u); } if ((4u) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
            i0 = 7u & 15u;
            if (((unsigned)e0 % (garr[i1 & 7u] | 1u))) continue;
            { unsigned t13; double z13; if ((((unsigned)!((unsigned)c0 + i1) ^ 0x7fffffffu)) & 1u) { t13 = (u3 / (4u | 1u)); z13 = (double)(((unsigned)c0) & 255u); } if ((((unsigned)!((unsigned)c0 + i1) ^ 0x7fffffffu)) & 1u) { u0 += t13; d0 = d0 * 0.5 + z13; }
                if ((unsigned)(p1 || p1)) break;
                u1 = u1 * 0x9e3779b1u + ((p2 % (0x80000000u | 1u)) | *mp);
                continue; (void)((unsigned)(2u == fuel));
                garr[(unsigned)e0 & 7u] = ((u2 << (0x10000u & 31u)) >> ((0x257650f2u ^ (3u % (u0 | 1u))) & 31u));
                garr[(unsigned)!((unsigned)b0 - p1) & 7u] = (unsigned)((int)i2 < (int)((unsigned)((unsigned)e0 < u3) * (a0[u1 & 3u] >> (8u & 31u))));
            }
        }
        if (0x4c41cbbbu) break;
        for (;;) { if (--fuel == 0u) goto done;
            if (((unsigned)h0 >> (0x80000000u & 31u))) break;
            if (((g1 / (0x278cc200u | 1u)) & p2)) {
                r0.x = (unsigned)((unsigned)!((unsigned)(w0 >> 29) ^ (unsigned)x0) && 0x59c3164eu);
                if ((unsigned)((short)v0 > (signed char)0x7fffffffu)) continue;
                while (i2++ < 3u && (unsigned)((int)(unsigned)c0 < (int)garr[u2 & 7u])) { if (--fuel == 0u) goto done;
                    while (i0++ < 3u && v0) { if (--fuel == 0u) goto done;
                        if ((0x2c7004f6u / (p1 | 1u))) {
                            if (((g1 - (unsigned)h0) * v0)) break;
                            s0 = (int)((unsigned)(((unsigned)d0 & 0xce3e5243u) < (unsigned)((unsigned)l0 < (unsigned)s0)) ^ 0xf5fd5810u);
                            if ((1u << (g1 & 31u))) break;
                            g0 = (unsigned)h0;
                        } else {
                            e0 = e0 * 0.5L + (long double)(~(unsigned)((short)g1 > (signed char)g0) & 1023u);
                            c0 = (unsigned char)(unsigned)((0xffffffffu << (0x80000000u & 31u)) == (0x52508037u ? (unsigned)e0 : i1));
                            if ((unsigned)!((unsigned)(u3 == v0) % (2u | 1u))) break;
                            if ((4u >> ((unsigned)h0 & 31u))) continue;
                        }
                        if ((unsigned)c1) break;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)b0, i0, (unsigned)l0); }
                        d0 = d0 * 0.5 + (double)((unsigned)(((unsigned)x0 ? 0x3b1ef9ebu : (unsigned)d0) && 9u) & 1023u);
                        if ((unsigned)(0xffffffffu || r0.x)) break;
                    }
                    if (((*q0 & 0x94f1b4c4u) % ((unsigned)l0 | 1u))) continue;
                    if ((a0[i0 & 3u] + r0.x)) break;
                }
                switch (-(unsigned)((unsigned)(x0 >> 70) && 0xbaae3935u) & 7u) {
                    if (((u0 & r0.x) - r0.x)) goto L2;
                    case 6u: ;
                }
                c0 = (unsigned char)(unsigned)(signed char)(p1 | 0x76e28a61u);
                u2 = a0[i0 & 3u];
            }
            if (((unsigned)!(unsigned)(0x7fffffffu && 0x10000u) * (unsigned)f0)) continue;
            if (fuel < 8u) return (3u ^ (unsigned)((unsigned)b0 < 0x10000u));
            if (a0[u1 & 3u]) break;
        }
    }
    goto L4;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        u3 += (a0[u1 & 3u] | 0x560be091u);
        if (((unsigned)(signed char)(r0.x ^ 0x18945587u) ^ 9u)) break;
        if (((unsigned)((int)fuel < (int)3u) - (unsigned)e0)) break;
    }
    x0 = x0 * 0x100000001b3ull + ((unsigned)c0 - (0x7fffffffu ? (unsigned)b0 : 0x80000000u));
    d0 = d0 * 0.5 + (double)(((unsigned)b0 & (unsigned)((short)(unsigned)h1 > (signed char)(g1 | u2))) & 1023u);
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1(0xdb40af72u, ~((unsigned)!(unsigned)((short)u1 > (signed char)(unsigned)(x0 >> 70)) * r0.x), m0); }
        if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)((unsigned)(x0 >> 70) && 4u) << (0xc9476b10u & 31u)), (unsigned)(signed char)(0x10000u / (u0 | 1u)), ((unsigned)f0 * (unsigned)f0)); }
        v0 = ~(4u | (0xbf5e04du % (6u | 1u)));
        while (i1++ < 2u && 0xb181add1u) { if (--fuel == 0u) goto done;
            g1 += (p1 >> (((unsigned)((int)u2 >= (int)u0) & 0x7fffffffu) & 31u));
            switch ((unsigned)x0 & 7u) {
                g0 = ((unsigned)w0 - (unsigned)((int)(unsigned)(x0 >> 70) >= (int)-(unsigned)(i2 == a0[u1 & 3u])));
                h0 = (short)(~(0xa649e79u * (unsigned)l0) >> (p2 & 31u));
                q0 = &garr[(0x95b99becu << (*mp & 31u)) & 7u];
                continue; (void)(0xffffffffu);
            }
            do { if (--fuel == 0u) goto done;
                u2 = 7u;
                if (i2) {
                    u3 += (u3 % ((unsigned)l0 | 1u));
                    if (((unsigned)s0 % (r0.y | 1u))) break;
                    w0 ^= (unsigned long long)(unsigned)!((unsigned)c1 << (fuel & 31u)) << (0x7fffffffu & 63u);
                    *mp = (unsigned)(signed char)(u3 + m0);
                    if (budget != 0u) { budget -= 1u; u3 = fn0(m0, (*mp * u2), (unsigned)d0); }
                }
                q0 = &garr[(unsigned)(short)(unsigned)((int)((unsigned)((unsigned)(1u && p0) == 6u) - r0.y) >= (int)(unsigned)b0) & 7u];
                h0 = (short)(g0 ? m0 : 0x762f2215u);
                while (i0++ < 5u && garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)c1);
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)(((unsigned)x0 + 6u) && (8u / (6u | 1u))) < (int)fuel));
                        u0 = (unsigned)((int)0x190d846cu < (int)m0);
                    }
                    u0 ^= (8u ^ (unsigned)((int)(unsigned)w0 >= (int)a0[i0 & 3u]));
                }
            } while (i2++ < 4u && (unsigned)(signed char)(v0 >> (r0.y & 31u)));
            if (budget != 0u) { budget -= 1u; u0 = fn1((0xa11f65f7u ^ p2), (unsigned)((unsigned)(g1 < 0xffffffffu) && g0), (u1 & (garr[u2 & 7u] * (unsigned)s1))); }
            g0 = v0;
            h1 = (unsigned short)(h1 + 0x80000000u);
        }
    } while (i0++ < 3u && (p0 ? (unsigned)s0 : 0xe89e0257u));
    if (-(0x2c41e367u << ((unsigned)d0 & 31u))) goto L1;
    m0 ^= (unsigned)(signed char)(unsigned)(7u || 0x10000u);
    *q0 += (unsigned)((short)(u0 ? (unsigned)(x0 >> 70) : (unsigned)l0) > (signed char)(0xffffffffu & 0x58c65c4cu));
    if (u3 == 7u) return ((unsigned)(short)(0x1c3c8a2au / ((unsigned)c1 | 1u)) ^ a0[u1 & 3u]);
    if ((unsigned)!((unsigned)(w0 >> 29) % (r0.x | 1u))) {
        c0 = (unsigned char)((unsigned)((int)(unsigned)(unsigned char)(v0 << (garr[u2 & 7u] & 31u)) >= (int)(unsigned)w0) + i2);
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 3u && ((unsigned)((unsigned)e0 && (unsigned)s0) | *mp)) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (5u) {
                        if ((unsigned)(w0 >> 29)) break;
                        for (;;) { if (--fuel == 0u) goto done;
                            b0 = ((unsigned)((int)g1 >= (int)(((unsigned)f0 / ((unsigned)b0 | 1u)) / (9u | 1u))) - (unsigned)h0) != 0u;
                            if (fuel < 8u) return (unsigned)(signed char)(fuel ^ (unsigned)(w0 >> 29));
                            if ((unsigned)((unsigned)((int)g1 >= (int)i2) || (unsigned)(x0 >> 70))) break;
                        }
                        h1 = (unsigned short)(h1 + (v0 << ((*q0 ? a0[i0 & 3u] : p0) & 31u)));
                    } else {
                        garr[(unsigned)((int)1u >= (int)fuel) & 7u] = (unsigned)((unsigned)c0 < 5u);
                        if (((unsigned)h1 >> ((0xc1761628u << (2u & 31u)) & 31u))) break;
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn1(6u, (unsigned)(unsigned char)(unsigned)(0x10000u || fuel), (unsigned)((unsigned)s1 && p1)); }
                    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(0xffffffffu < p2), (p2 + 0xffffffffu), (unsigned)((int)r0.y >= (int)0xffffffffu)); }
                    *q0 = ((fuel & (0x80000000u << ((unsigned)b0 & 31u))) & ~(unsigned)((unsigned)s0 < 0x7fffffffu));
                    if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)w0 % (0x2fb490f1u | 1u)), 0x3bea29c3u, (unsigned)((int)a0[i0 & 3u] < (int)(*mp | (unsigned)s0))); }
                }
                if (((unsigned)(signed char)(unsigned)((int)0x3f2c0c44u < (int)0x82688d71u) | g1)) break;
                if ((u0 >> ((unsigned)((unsigned)d0 || (unsigned)h0) & 31u))) goto L3;
            }
            u0 ^= ~((unsigned)((unsigned)l0 && fuel) % ((unsigned)(short)(i2 ? 8u : (unsigned)(x0 >> 70)) | 1u));
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                u3 = (unsigned)h1;
                *q0 = (unsigned)((int)0x136a0cffu < (int)(unsigned)(signed char)((unsigned)((short)u1 > (signed char)0u) / ((unsigned)c1 | 1u)));
                for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)(0x744fc5beu < (unsigned)e0);
                    r0.x = (unsigned)(i0 || p1);
                    m0 ^= (unsigned)f0;
                    continue; (void)((u2 ^ (unsigned)d0));
                    break; (void)(((unsigned)x0 >> ((0x3ac0d651u + a0[u1 & 3u]) & 31u)));
                }
                r0.x = ((-(a0[u1 & 3u] - (unsigned)e0) << (0xa8a021e4u & 31u)) + (unsigned)((int)*q0 < (int)(unsigned)h1));
                *q0 = (((unsigned)b0 ^ u1) & (unsigned)(signed char)(unsigned)(a0[u1 & 3u] < a0[u1 & 3u]));
                break; (void)(-(unsigned)((unsigned)((int)(unsigned)x0 >= (int)0x7fffffffu) < 4u));
            }
        }
    }
    x0 = x0 * 0x100000001b3ull + ((unsigned)h0 << ((unsigned)(unsigned char)((unsigned)x0 ^ 0x9bd34916u) & 31u));
    v0 = (unsigned)(short)(((unsigned)h0 ^ 0x58f54a02u) & a0[i0 & 3u]);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (fuel < 8u) return (unsigned)((short)p2 > (signed char)0x80000000u);
    while (i0++ < 7u && ((unsigned)b0 + (unsigned)(4u == fuel))) { if (--fuel == 0u) goto done;
        g1 += ((unsigned)s0 * (0x10000u << ((unsigned)((int)(*q0 | 0x10000u) >= (int)(unsigned)b0) & 31u)));
    }
    while ((*q0 << (0xffffffffu & 31u))) { if (--fuel == 0u) goto done;
        r0.x = (unsigned)(short)((unsigned)((short)i1 > (signed char)*q0) * m0);
        l0 = (long)((unsigned long)l0 + (garr[i1 & 7u] / (a0[i0 & 3u] | 1u)));
        while (i1++ < 5u && 0x7dca6276u) { if (--fuel == 0u) goto done;
            switch ((unsigned)((unsigned)d0 == 0u) & 7u) {
                if (u3 == 7u) return (-((0xb55f5a91u << (8u & 31u)) >> ((p2 + u2) & 31u)) / (0x10000u | 1u));
                if (garr[i1 & 7u]) {
                    i1 = 8u & 15u;
                    if (fuel) goto L0;
                    if (u2) goto L2;
                }
                r0.y ^= (unsigned)(u3 < p0);
                r0.x = (-(unsigned)((m0 + (unsigned)x0) == 0x80000000u) + g1);
            }
            *q0 += (0xcaaf632eu ^ garr[i1 & 7u]);
        }
    }
    { unsigned t0; double z0; if (((unsigned)l0) & 1u) { t0 = 0x7fffffffu; z0 = (double)((6u) & 255u); } if (((unsigned)l0) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        if (fuel < 8u) return (unsigned)(0xbcb370e2u && (((u3 >> (g1 & 31u)) - g0) * 7u));
    }
    garr[r0.y & 7u] = (unsigned)(unsigned char)(r0.y + (unsigned)((int)a0[u1 & 3u] < (int)fuel));
    if ((unsigned)c1) {
        if ((unsigned)((unsigned)(x0 >> 70) && (unsigned)h1)) goto L0;
    }
    L0: if (--fuel == 0u) goto done;
    s0 = (int)(unsigned)(unsigned char)((unsigned)l0 + (unsigned)((int)(m0 ? u2 : 0xbd836176u) >= (int)0x39ef91fbu));
    u2 = (0x31bc100du - 9u);
    if (u3 == 7u) return ((unsigned)(0xcb5b31e4u == (unsigned)w0) - ~((unsigned)((unsigned)l0 && (unsigned)s0) | u0));
    do { if (--fuel == 0u) goto done;
        while ((unsigned)((unsigned)s1 && 0x10000u)) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((0x34e51577u * (unsigned)s0) / (((unsigned)c0 | (0x80000000u % (p0 | 1u))) | 1u)) & 1023u);
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(unsigned char)(0xd3c2c9a1u * u2), (unsigned)(r0.y == 0xd4d0760bu), (unsigned)(short)((unsigned)d0 ? garr[u2 & 7u] : (unsigned)x0)); }
                if ((unsigned)((int)0xffffffffu >= (int)((unsigned)s1 ^ 0xffffffffu))) break;
                if (0xadf8faa8u) break;
                q0 = &garr[(unsigned)((a0[i0 & 3u] ^ (unsigned)(x0 >> 70)) == p0) & 7u];
                if (((1u << (u1 & 31u)) << ((unsigned)h0 & 31u))) break;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)w0, (9u * 0x237b9409u), ((p0 + (unsigned)f0) & fuel)); }
            u3 += (unsigned)((unsigned)s1 < (unsigned)(((unsigned)h1 / (p1 | 1u)) || (unsigned)(w0 >> 29)));
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + u1);
            }
            do { if (--fuel == 0u) goto done;
                if (0xffffffffu) {
                    *q0 += (unsigned)((unsigned)(signed char)(unsigned)((int)(unsigned)f0 < (int)~(unsigned)((int)(unsigned)e0 >= (int)fuel)) < 8u);
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(signed char)((unsigned)c1 ^ u3), 0x10000u, ((unsigned)c1 ^ 7u)); }
                    if ((unsigned)x0) break;
                    u2 = (unsigned)(p1 < g1);
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)s0 || (unsigned)((unsigned)e0 || 0xffffffffu)), ((unsigned)b0 >> ((unsigned)h1 & 31u)), u0); }
                } else {
                    switch ((unsigned)((unsigned)((short)m0 > (signed char)fuel) < (unsigned)c1) & 7u) {
                        u3 ^= (unsigned)h0;
                        if (((unsigned)((int)u0 >= (int)i2) * 8u)) goto done;
                        l0 = (long)((unsigned long)l0 + (unsigned)b0);
                    }
                    if ((g0 / ((unsigned)e0 | 1u))) continue;
                    if ((unsigned)(0x7fffffffu == p0)) break;
                }
                w0 ^= (unsigned long long)((unsigned)f0 - (unsigned)s1) << (~(((unsigned)(x0 >> 70) - (unsigned)((int)(unsigned)(w0 >> 29) < (int)0x80000000u)) * i1) & 63u);
            } while (i2++ < 3u && (g1 ? 0x7321c4acu : v0));
        }
        x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)x0 == i2) % (p1 | 1u));
        i0 = (unsigned)((int)0xffffffffu >= (int)(unsigned)((unsigned)x0 < garr[i1 & 7u])) & 15u;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if ((*mp) & 1u) { t1 = ~(m0 ? u0 : g0); z1 = (double)(((0x10000u * g1)) & 255u); } if ((*mp) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (0xffffffffu) {
                        while (i0++ < 2u && p1) { if (--fuel == 0u) goto done;
                            c1 = (signed char)(unsigned)((short)((unsigned)w0 % ((unsigned)h1 | 1u)) > (signed char)r0.y);
                            s0 = (int)(unsigned)((unsigned)((int)i0 >= (int)8u) < 0x1690ca6u);
                            u0 += ((unsigned)h0 | 0x10000u);
                            goto done;
                        }
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)((unsigned)(x0 >> 70) | garr[u2 & 7u]), ((unsigned)(0x6c86d910u || a0[u1 & 3u]) | 0x7fffffffu), (unsigned)b0); }
                    w0 = w0 * 6364136223846793005ull + (unsigned)(((u2 ^ 0x10000u) - a0[u1 & 3u]) < -(unsigned)(0xffffffffu && (unsigned)c0));
                    L1: if (--fuel == 0u) goto done;
                }
            }
            w0 ^= (unsigned long long)0xfd4e9747u << ((unsigned)((unsigned)f0 < (unsigned)(0x7fffffffu && (p0 * (unsigned)(garr[i1 & 7u] < (unsigned)e0)))) & 63u);
            while (i2++ < 6u && (unsigned)((unsigned)s0 && a0[u1 & 3u])) { if (--fuel == 0u) goto done;
                a0[0x80000000u & 3u] = ((unsigned)(fuel < (4u ^ (0xffffffffu * (unsigned)h0))) >> (0xffffffffu & 31u));
            }
            break; (void)(p2);
            if (budget != 0u) { budget -= 1u; u2 = fn2(((0u + (unsigned)f0) / (i1 | 1u)), garr[u2 & 7u], ((unsigned)((int)(unsigned)w0 >= (int)4u) & i0)); }
            if ((7u + p2)) break;
        }
        switch ((u1 + g1) & 7u) {
            h0 = (short)(unsigned)f0;
            L2: if (--fuel == 0u) goto done;
            case 2u: ;
            L3: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn3((r0.y & u3), ((unsigned)h1 / ((unsigned)s0 | 1u)), (i1 - a0[u1 & 3u])); }
            if (budget != 0u) { budget -= 1u; u2 = fn1((1u ^ (unsigned)(short)(3u * (unsigned)l0)), ((unsigned)h1 / ((unsigned)b0 | 1u)), (0x10000u ? (unsigned)e0 : 0x4ad6dc5cu)); }
        }
    } while (i0++ < 6u && (unsigned)((int)(3u & 1u) >= (int)3u));
    q0 = &garr[u2 & 7u];
    e0 = e0 * 0.5L + (long double)((unsigned)(u2 || m0) & 1023u);
    *mp = (r0.x - (p2 & garr[u2 & 7u]));
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((0x80000000u + m0) >> (2u & 31u))) break;
        do { if (--fuel == 0u) goto done;
            while (i2++ < 6u && (unsigned)(0x1d17a1c2u < fuel)) { if (--fuel == 0u) goto done;
                v0 = ((unsigned)s1 - (0xdfa3b932u % ((garr[u2 & 7u] - *q0) | 1u)));
                *q0 += (*q0 >> (i0 & 31u));
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    r0.y ^= (unsigned)((int)garr[u2 & 7u] < (int)(6u | u2));
                    g0 = ((9u % (a0[i0 & 3u] | 1u)) >> ((unsigned)x0 & 31u));
                    f0 = f0 * 0.5f + (float)((unsigned)((unsigned)(x0 >> 70) == (unsigned)((0x29340b28u + (unsigned)(x0 >> 70)) || 0x10000u)) & 255u);
                }
                if (((3u + 0x10000u) * (unsigned)s1)) break;
            }
            do { if (--fuel == 0u) goto done;
                u1 ^= (unsigned)(u0 && ((unsigned)b0 & (unsigned)(w0 >> 29)));
                garr[(unsigned)f0 & 7u] = ~((unsigned)((int)i0 >= (int)7u) + r0.y);
                { unsigned t2; double z2; if (((unsigned)(a0[i0 & 3u] < (unsigned)l0)) & 1u) { t2 = (unsigned)((short)(unsigned)b0 > (signed char)garr[u2 & 7u]); z2 = (double)(((unsigned)e0) & 255u); } if (((unsigned)(a0[i0 & 3u] < (unsigned)l0)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    f0 = f0 * 0.5f + (float)(((u2 ^ (0xf52e8b05u + (unsigned)s1)) & 3u) & 255u);
                    if ((unsigned)x0) break;
                }
                if (((unsigned)(0x6bd4da21u && (unsigned)c1) >> (r0.x & 31u))) break;
            } while (i2++ < 3u && ((unsigned)(w0 >> 29) * (r0.y + a0[u1 & 3u])));
        } while (i1++ < 6u && (unsigned)(w0 >> 29));
    }
    h0 = (short)((unsigned)(fuel && (unsigned)b0) << ((unsigned)(i0 && u1) & 31u));
    goto L0;
    goto L1;
    if (~(unsigned)((unsigned)d0 == 0xffffffffu)) goto L2;
    { unsigned t3; double z3; if (((unsigned)x0) & 1u) { t3 = (unsigned)c1; z3 = (double)((((unsigned)f0 * 0x80000000u)) & 255u); } if (((unsigned)x0) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)h1, 9u, (unsigned)((unsigned)(0x488d7711u < 0x80000000u) && u1)); }
            if (fuel) break;
            if (4u) continue;
            if ((unsigned)(signed char)(unsigned)((short)(unsigned)h1 > (signed char)(unsigned)b0)) {
                h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)((int)(unsigned)(1u && (unsigned)f0) < (int)(unsigned)c1) < (int)(0x9d820b8bu ^ u0)));
                if (budget != 0u) { budget -= 1u; u1 = fn3((0xffffffffu & (unsigned)(x0 >> 70)), 0xffffffffu, ((i2 ^ (unsigned)f0) * p1)); }
                break; (void)(0x80000000u);
                if (((unsigned)c1 ^ r0.x)) {
                    m0 ^= p2;
                    if (fuel < 8u) return (((unsigned)b0 ? (unsigned)l0 : 9u) >> (6u & 31u));
                    if (3u) goto L0;
                    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)h0 & (unsigned)c1), (u0 & ~(0x10000u * 7u)), g0); }
                    if ((unsigned)((int)(unsigned)(0x1a3bb4d3u && *mp) >= (int)(unsigned)f0)) {
                        if ((unsigned)x0) goto done;
                        b0 = (unsigned)(0x28768813u == (unsigned)((unsigned)l0 || r0.x)) != 0u;
                    }
                } else {
                    continue; (void)(((unsigned)h1 ^ (unsigned)f0));
                    continue; (void)((m0 - ((unsigned)f0 / (u3 | 1u))));
                    if ((garr[i1 & 7u] << ((unsigned)((int)*mp < (int)(unsigned)h0) & 31u))) continue;
                    { unsigned t4; double z4; if ((((unsigned)((int)u1 >= (int)i0) - 0x7fffffffu)) & 1u) { t4 = (unsigned)f0; z4 = (double)(((unsigned)(u2 < 0x80000000u)) & 255u); } if ((((unsigned)((int)u1 >= (int)i0) - 0x7fffffffu)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                        if ((unsigned)!(2u >> (6u & 31u))) goto L3;
                        l0 = (long)((unsigned long)l0 + (unsigned)(0x10000u || 0x7fffffffu));
                        w0 = w0 * 6364136223846793005ull + (unsigned)(6u || ((unsigned)((int)0x10000u >= (int)m0) << ((unsigned)h1 & 31u)));
                    }
                }
                b0 = 0xffffffffu != 0u;
                s1 = (int)((unsigned)s1 + ((unsigned)w0 ? (a0[i0 & 3u] - (unsigned)h1) : (0xcef6c7e8u << (0x80000000u & 31u))));
            } else {
                if (fuel < 8u) return (unsigned)(p1 && (unsigned)((short)(g0 - u1) > (signed char)*q0));
                if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)d0 >> (((unsigned)(x0 >> 70) - (unsigned)b0) & 31u)), (a0[u1 & 3u] ? 0xef0d0e58u : (unsigned)(x0 >> 70)), 0x7fffffffu); }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn1((0x6762b103u - u2), (unsigned)((int)(8u ^ (unsigned)(w0 >> 29)) < (int)v0), (unsigned)(p0 || 0x53d708d8u)); }
        }
        goto L2;
        if ((unsigned)h0) goto L2;
        u3 = u3 * 0x9e3779b1u + (unsigned)(unsigned char)(fuel - (unsigned)(6u < 6u));
        if ((garr[u2 & 7u] & 0x7d3b2a63u)) goto L2;
    }
    for (;;) { if (--fuel == 0u) goto done;
        if ((0x9887c762u >> ((unsigned)((unsigned)h0 < 0x10000u) & 31u))) break;
        while (i1++ < 3u && (unsigned)(garr[i1 & 7u] < 2u)) { if (--fuel == 0u) goto done;
            s0 = (int)a0[u1 & 3u];
            break; (void)((unsigned)(9u || fuel));
        }
        w0 ^= (unsigned long long)(p0 ^ a0[u1 & 3u]) << (p0 & 63u);
        if ((0u % ((unsigned)c1 | 1u))) break;
        x0 = x0 * 0x100000001b3ull + 0x80000000u;
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        h0 = (short)(unsigned)x0;
        if (budget != 0u) { budget -= 1u; u2 = fn3(g0, (fuel ? garr[i1 & 7u] : a0[u1 & 3u]), (unsigned)(g0 || ((unsigned)x0 * 0xb0210ebfu))); }
    }
    while ((u0 / ((unsigned)(g0 || (unsigned)l0) | 1u))) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((unsigned)d0 || g1), (unsigned)(x0 >> 70), (*mp / ((unsigned)w0 | 1u))); }
        if ((0xa6a4418au & (unsigned)((int)0x7fffffffu >= (int)0x7fffffffu))) break;
        if ((unsigned)((unsigned)x0 || p0)) break;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((p0 % (0xbde8d821u | 1u))) continue;
            if ((unsigned)(0x80000000u == (unsigned)(w0 >> 29))) break;
            while (i2++ < 4u && (unsigned)!(u3 << (0x7fffffffu & 31u))) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(3u & 1023u);
                if (budget != 0u) { budget -= 1u; u3 = fn3((0x362b24adu | (0x5591159du << (i0 & 31u))), (unsigned)(r0.y < (unsigned)(1u || v0)), (unsigned)x0); }
            }
        }
        u0 ^= (unsigned)c1;
    }
    m0 ^= (0xffffffffu * 0x42f0f5bfu);
    r0.x = (unsigned)(r0.y == 1u);
    d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(i2 - (unsigned)((int)(3u ? *mp : (unsigned)b0) >= (int)1u)) & 1023u);
    if (*mp) goto L4;
    if ((unsigned)((int)*mp < (int)(unsigned)h0)) {
        if (budget != 0u) { budget -= 1u; u0 = fn2(4u, u1, (p0 % ((unsigned)l0 | 1u))); }
        c1 = (signed char)(unsigned)(signed char)(u0 & (0x27348046u % ((unsigned)(w0 >> 29) | 1u)));
    } else {
        if (budget != 0u) { budget -= 1u; u1 = fn3(u2, ((unsigned)w0 | (0x7fffffffu - 0x9cc1a9cau)), (unsigned)((int)m0 < (int)0x7fffffffu)); }
        if ((unsigned)(9u && 0u)) {
            { unsigned t5; double z5; if ((0x7fffffffu) & 1u) { t5 = (unsigned)x0; z5 = (double)(((1u ^ 0x5234af2du)) & 255u); } if ((0x7fffffffu) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                if (budget != 0u) { budget -= 1u; u0 = fn2((0x2a89bf9bu >> (((unsigned)s0 / (0xcccce629u | 1u)) & 31u)), -(unsigned)((int)(unsigned)((short)(unsigned)c1 > (signed char)0xf1b6de09u) < (int)2u), a0[i0 & 3u]); }
                if ((unsigned)s0) {
                    goto done;
                } else {
                    d0 = d0 * 0.5 + (double)((unsigned)((4u ? 0x10000u : 0xc517fe28u) == (unsigned)(x0 >> 70)) & 1023u);
                }
                if (budget != 0u) { budget -= 1u; u2 = fn3((unsigned)d0, 0x997ad5adu, p0); }
                while (i0++ < 3u && ((unsigned)(w0 >> 29) * garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                    u0 += (unsigned)((int)((unsigned)h1 + (unsigned)b0) < (int)~(r0.x & (unsigned)s1));
                    if (u3 == 7u) return a0[u1 & 3u];
                    b0 = (0x80000000u + (7u ^ 0xffffffffu)) != 0u;
                    if (3u) break;
                    while (i1++ < 7u && u1) { if (--fuel == 0u) goto done;
                        break; (void)(0xd3bb5da5u);
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((7u | *q0) % (0x413163f8u | 1u)), g1, 8u); }
                }
            }
            if (0xa6039542u) {
                r0.y ^= (0u / ((unsigned)(u0 && r0.x) | 1u));
            } else {
                if ((unsigned)(8u < ((unsigned)(w0 >> 29) | 0x80000000u))) goto L3;
                if (r0.y) {
                    if ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)p1)) goto L0;
                    c0 = (unsigned char)(unsigned)((short)(r0.y ? garr[i1 & 7u] : (unsigned)(a0[u1 & 3u] < p2)) > (signed char)6u);
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)w0, (unsigned)e0, (unsigned)(i0 == (unsigned)f0)); }
                    if ((unsigned)((int)p1 >= (int)(v0 / ((unsigned)c0 | 1u)))) goto L0;
                    if ((6u % ((unsigned)s0 | 1u))) goto L1;
                    e0 = e0 * 0.5L + (long double)(-(unsigned)((short)((unsigned)d0 ? 0xfa0a692fu : (unsigned)((int)p2 >= (int)(unsigned)(x0 >> 70))) > (signed char)(unsigned)c0) & 1023u);
                }
            }
            switch (m0 & 7u) {
                c0 = (unsigned char)((unsigned)f0 ^ ((g0 - 0x470dd772u) + p2));
            }
            r0.y ^= (unsigned)((unsigned)l0 < ((unsigned)e0 >> ((unsigned)(x0 >> 70) & 31u)));
            if (u3 == 7u) return ((2u * ((unsigned)b0 | (0x6333f6dbu - g0))) & 0x9eed3734u);
            b0 = ((unsigned)f0 + (unsigned)c0) != 0u;
        }
        s0 = (int)(garr[u2 & 7u] % ((7u >> (u2 & 31u)) | 1u));
        c1 = (signed char)(unsigned)(((unsigned)l0 ? *mp : (g0 * (unsigned)c1)) && 0x7fffffffu);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 10u, 0xb2794b0eu, 0x1ee4fc5fu },
        { 15u, 0x11f52700u, 0xefbed14au },
        { 15u, 0xaac82b7bu, 0x3b182d43u },
        { 2u, 0x367c79a6u, 0xf364fbcau },
        { 7u, 0xa0ab6e83u, 0x8c141cf9u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
