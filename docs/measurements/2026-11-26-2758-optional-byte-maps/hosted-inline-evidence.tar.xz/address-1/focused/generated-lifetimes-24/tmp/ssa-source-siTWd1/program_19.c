// test-ssa-source's program of seed 141000442 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x259eac80u, g1 = 0xc1935a3fu;
static unsigned garr[8] = { 0xcf7d80d2u, 0xa17cd14bu, 0x4bc078b5u, 0xda092719u, 0x4f432807u, 0xdaa81e30u, 0xbdc1fde0u, 0x7dbe378du };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    x0 = x0 * 0x100000001b3ull + ~((0xf6afcaabu << (p1 & 31u)) >> ((unsigned)(unsigned char)((unsigned)(signed char)(unsigned)(u2 < i1) & (unsigned)c0) & 31u));
    L0: if (--fuel == 0u) goto done;
    if (g0) goto L2;
    do { if (--fuel == 0u) goto done;
        r0.x = ((garr[i1 & 7u] & u3) ^ 8u);
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if ((i2) & 1u) { t0 = r0.x; z0 = (double)((-(unsigned)((int)((unsigned)s1 & *q0) >= (int)(unsigned)b0)) & 255u); } if ((i2) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                L1: if (--fuel == 0u) goto done;
                if ((unsigned)(p1 == (unsigned)h0)) goto L1;
                f0 = f0 * 0.5f + (float)((unsigned)(0x28dd69cbu == (0x7cf85738u ? (unsigned)(x0 >> 70) : i2)) & 255u);
                if ((unsigned)((int)*mp < (int)(0x7fffffffu >> (6u & 31u)))) continue;
                u3 = u3 * 0x9e3779b1u + (r0.y * (u0 + -(*mp ? (unsigned)b0 : u1)));
            }
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)(g1 < ((unsigned)w0 & p0));
        if (i0) break;
        switch ((unsigned)((int)(unsigned)e0 < (int)u1) & 7u) {
            continue; (void)((0x80000000u ? u2 : 0x8f77270cu));
            L2: if (--fuel == 0u) goto done;
            m0 ^= ((3u << (a0[i0 & 3u] & 31u)) & (unsigned)c0);
            q0 = &garr[(i1 << (0x80000000u & 31u)) & 7u];
        }
        continue; (void)(u2);
    } while (i0++ < 2u && ((unsigned)((int)(unsigned)l0 >= (int)u3) | i2));
    q0 = &garr[(unsigned)(((unsigned)(short)(u0 % (0x1ece3e80u | 1u)) << (i1 & 31u)) < (unsigned)((unsigned)e0 < i1)) & 7u];
    s0 = (int)(unsigned)((unsigned)(short)((0x10000u & (unsigned)c0) ^ 0x10000u) && i0);
    u0 += (((unsigned)(unsigned char)(unsigned)(0x10000u || (unsigned)((unsigned)c0 && 6u)) + g0) * u2);
    s0 = (int)((unsigned)((short)0u > (signed char)p2) / (r0.x | 1u));
    while (i0++ < 2u && (unsigned)((int)0x7fffffffu < (int)(unsigned)(u0 || (unsigned)w0))) { if (--fuel == 0u) goto done;
        { unsigned t1; double z1; if ((((unsigned)(g0 == (unsigned)f0) / (i1 | 1u))) & 1u) { t1 = 0xffffffffu; z1 = (double)(((unsigned)(unsigned char)(garr[i1 & 7u] / ((unsigned)(unsigned char)((unsigned)c0 >> (p1 & 31u)) | 1u))) & 255u); } if ((((unsigned)(g0 == (unsigned)f0) / (i1 | 1u))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (unsigned)((int)0xe66c333u >= (int)u3));
                m0 ^= (*mp | 0u);
                s1 = (int)((unsigned)s1 + (unsigned)((unsigned)((short)(unsigned)d0 > (signed char)4u) || 0xffffffffu));
                if ((unsigned)(signed char)(unsigned)((short)((unsigned)h0 << ((unsigned)e0 & 31u)) > (signed char)0u)) break;
            }
            L3: if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                r0.x = garr[i1 & 7u];
            } while (i1++ < 7u && (unsigned)((unsigned)(w0 >> 29) < (unsigned)(w0 >> 29)));
            if ((unsigned)((short)(unsigned)h1 > (signed char)(*mp << (garr[u2 & 7u] & 31u)))) {
                L4: if (--fuel == 0u) goto done;
                *q0 += (unsigned)(*mp < ((unsigned)h1 >> (r0.y & 31u)));
                { unsigned t2; double z2; if (((*mp | 0x7975385au)) & 1u) { t2 = (unsigned)w0; z2 = (double)(((unsigned)(0x5c4b25f2u == (unsigned)c0)) & 255u); } if (((*mp | 0x7975385au)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    if ((unsigned)((unsigned)(w0 >> 29) || (unsigned)d0)) break;
                }
            }
            break; (void)(~(unsigned)(*mp && i1));
            garr[0x80000000u & 7u] = (((unsigned)x0 - 7u) | (unsigned)(x0 >> 70));
        }
        break; (void)(((unsigned)s0 & i2));
        *q0 = (unsigned)((unsigned)((u3 * 0x10000u) < (unsigned)((unsigned)s1 == 0x7a191ed7u)) || 0xffffffffu);
        v0 = (p2 << (2u & 31u));
    }
    q0 = &garr[(unsigned)c0 & 7u];
    u3 = u3 * 0x9e3779b1u + ((p0 - (garr[u2 & 7u] % ((unsigned)s0 | 1u))) | *q0);
    switch ((unsigned)((int)0xe98fe1b7u >= (int)(unsigned)(g1 || i0)) & 7u) {
        switch ((p2 | (i0 * (unsigned)(w0 >> 29))) & 7u) {
            f0 = f0 * 0.5f + (float)((unsigned)((int)i0 < (int)(0x8939825du | (unsigned)((int)i0 < (int)(unsigned)h1))) & 255u);
            if ((unsigned)(a0[i0 & 3u] < (unsigned)l0)) goto L2;
            if ((unsigned)(signed char)(unsigned)((short)0x22ddf4f5u > (signed char)i2)) {
                if ((i0 & (unsigned)(1u || 0xffffffffu))) {
                    if ((unsigned)((int)0x5b2943f1u >= (int)(unsigned)(0x4608ba68u < (unsigned)f0))) {
                        c1 = (signed char)(unsigned)s0;
                        case 6u: ;
                        m0 ^= ((unsigned)((unsigned)s1 || 0xfa4d58c8u) >> ((unsigned)(unsigned char)(a0[u1 & 3u] | (unsigned)d0) & 31u));
                        i1 = ((u2 ? (unsigned)s1 : u1) + (unsigned)x0) & 15u;
                    } else {
                        default: ;
                        m0 ^= (unsigned)e0;
                        i0 = ((unsigned)(r0.x || u0) + 0xffffffffu) & 15u;
                    }
                } else {
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((unsigned)e0 == (unsigned)(9u || 0x2f83b0e7u))) goto L1;
                        r0.x = 0x80000000u;
                        if ((0x5fef4f14u & (unsigned)(x0 >> 70))) break;
                        case 7u: ;
                        u1 += (p1 & (unsigned)((((unsigned)f0 % (u0 | 1u)) % ((unsigned)h0 | 1u)) || p2));
                        for (;;) { if (--fuel == 0u) goto done;
                            if (((unsigned)s0 / ((0x10000u ^ 5u) | 1u))) break;
                            i0 = (unsigned)c1 & 15u;
                        }
                    } while (i0++ < 7u && (unsigned)(short)(*mp / (r0.y | 1u)));
                }
                a0[(unsigned)b0 & 3u] = ((unsigned)(w0 >> 29) | p0);
                w0 ^= (unsigned long long)(unsigned)(8u == 4u) << ((0x78e0566bu % ((~(unsigned)(u2 == (unsigned)x0) % (garr[u2 & 7u] | 1u)) | 1u)) & 63u);
                u3 ^= (unsigned)!((unsigned)((int)(9u ? garr[i1 & 7u] : g0) < (int)6u) % (g0 | 1u));
                r0.y ^= (g0 + (0x268588e7u | 2u));
                g0 = (fuel ? 0x80000000u : 0x7fffffffu);
            } else {
                u3 ^= (0xf91b2dfu ? v0 : 0xadb87e56u);
                { unsigned t3; double z3; if ((7u) & 1u) { t3 = ((unsigned)f0 << ((unsigned)l0 & 31u)); z3 = (double)(((unsigned)f0) & 255u); } if ((7u) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    while (i0++ < 6u && ((unsigned)(w0 >> 29) - (a0[i0 & 3u] ^ m0))) { if (--fuel == 0u) goto done;
                        continue; (void)((unsigned)c0);
                        if (g0) goto L0;
                        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                            break;
                            case 2u: ;
                            garr[g0 & 7u] = (((unsigned)b0 / (((unsigned)(x0 >> 70) * (unsigned)c0) | 1u)) << (u1 & 31u));
                            s0 = (int)((unsigned)(unsigned char)(*q0 ^ a0[i0 & 3u]) | (9u & i1));
                        }
                        if ((0xffffffffu ? *q0 : u1)) goto L1;
                        u1 ^= (unsigned)(signed char)(unsigned)((int)(unsigned)((int)5u >= (int)(unsigned)f0) >= (int)(fuel >> (garr[u2 & 7u] & 31u)));
                        e0 = e0 * 0.5L + (long double)(2u & 1023u);
                    }
                }
            }
        }
        *mp = (0x818e9f06u / ((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)!(p2 + fuel)) | 1u));
        case 7u: ;
        if (~(garr[i1 & 7u] << ((v0 / (0x10000u | 1u)) & 31u))) goto L0;
        if (u3 == 7u) return ~(unsigned)((unsigned)(unsigned char)((unsigned)x0 * ((unsigned)(short)(unsigned)(p0 == r0.y) ^ 7u)) && i2);
        s0 = (int)-((((g1 - g0) << (u3 & 31u)) << (*q0 & 31u)) * (unsigned)s1);
    }
    g1 += ((unsigned)c1 | (unsigned)c1);
    h0 = (short)(5u >> (3u & 31u));
    switch (((unsigned)c0 & v0) & 7u) {
        case 1u: ;
        do { if (--fuel == 0u) goto done;
            case 2u: ;
            case 4u: ;
            continue; (void)((unsigned)e0);
        } while (i0++ < 7u && (unsigned)h0);
    }
    r0.y ^= (unsigned)(((0xffffffffu / ((unsigned)x0 | 1u)) % (u0 | 1u)) == (unsigned)h1);
    switch (*mp & 7u) {
        case 2u: ;
    }
    g1 += (unsigned)((int)i1 < (int)0u);
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        garr[garr[i1 & 7u] & 7u] = (unsigned)((short)(p0 + 0x80000000u) > (signed char)((unsigned)e0 << (i2 & 31u)));
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)(m0 >> ((unsigned)(*mp < 0x10000u) & 31u))) break;
            *mp = 0x7fffffffu;
            if ((garr[u2 & 7u] + p2)) break;
            if ((garr[i1 & 7u] << (3u & 31u))) break;
            h0 = (short)((unsigned)((short)(unsigned)!((unsigned)!(unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)x0) % ((unsigned)h1 | 1u)) > (signed char)p2) * g0);
        }
        for (;;) { if (--fuel == 0u) goto done;
            if (fuel < 8u) return ((unsigned)((unsigned)(i2 && (unsigned)x0) == (unsigned)h0) - (unsigned)((short)i1 > (signed char)r0.y));
        }
        f0 = f0 * 0.5f + (float)(((unsigned)((unsigned)(0x8bda0bc9u < i1) || (unsigned)w0) % ((unsigned)f0 | 1u)) & 255u);
        a0[(unsigned)h1 & 3u] = g0;
    }
    goto L2;
    q0 = &garr[(*mp * *q0) & 7u];
    while (i0++ < 5u && ~((unsigned)(short)(0u * a0[u1 & 3u]) % (u1 | 1u))) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            g1 += (unsigned)((i1 % ((unsigned)c1 | 1u)) || (unsigned)(i0 < -(unsigned)(a0[i0 & 3u] || 0x2be13baeu)));
        } while (i1++ < 4u && (unsigned)(0xdae190d9u == (unsigned)((int)0xf097ef1eu < (int)7u)));
    }
    goto L3;
    h1 = (unsigned short)(h1 + (unsigned)(a0[u1 & 3u] == (unsigned)f0));
    { unsigned t4; double z4; if ((p0) & 1u) { t4 = (g1 | (*mp << (g0 & 31u))); z4 = (double)(((garr[u2 & 7u] + 0xffffffffu)) & 255u); } if ((p0) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        h1 = (unsigned short)(h1 + (unsigned)(6u || (unsigned)(0xffffffffu < (unsigned)l0)));
        *q0 += (unsigned)(unsigned char)(unsigned)(p1 == 0u);
    }
    goto done;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)d0) continue;
                    u2 += 0x5af419a8u;
                    l0 = (long)((unsigned long)l0 + (unsigned)((3u + i0) < 4u));
                    for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if ((unsigned)(0x10000u && (unsigned)((int)garr[i1 & 7u] >= (int)garr[u2 & 7u]))) break;
                        for (;;) { if (--fuel == 0u) goto done;
                            if ((0x80000000u << ((2u ^ (unsigned)c1) & 31u))) goto done;
                            g1 += (unsigned)(garr[i1 & 7u] || m0);
                            if ((6u & (u0 | garr[u2 & 7u]))) break;
                            *q0 = (m0 - (unsigned)f0);
                        }
                        if ((unsigned)c0) {
                            if ((((unsigned)w0 * (unsigned)c1) - g0)) continue;
                            m0 ^= (unsigned)(signed char)(unsigned)((unsigned)((short)r0.x > (signed char)(unsigned)f0) < (9u >> (p2 & 31u)));
                            if ((0xffffffffu ? (unsigned)l0 : 0x7fffffffu)) break;
                            q0 = &garr[0xf85a6fccu & 7u];
                            if ((unsigned)(signed char)((unsigned)(i1 < (unsigned)b0) + 0x80000000u)) goto done;
                        } else {
                            if ((unsigned)!((0xffffffffu ^ a0[u1 & 3u]) >> ((unsigned)e0 & 31u))) break;
                            g1 += (unsigned)((short)(r0.y + 0x37282678u) > (signed char)0x80000000u);
                        }
                        if ((unsigned)(7u || (unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)h1))) goto L2;
                        if (-((unsigned)(0x10000u && 0x4fdc905eu) - 0xc0dfae70u)) break;
                    }
                    if (g0) break;
                    u2 += fuel;
                } while (i0++ < 3u && 0u);
                i0 = ((unsigned)c1 * (i0 ^ (unsigned)b0)) & 15u;
            }
            do { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((u3 << ((0xffffffffu & (unsigned)d0) & 31u)));
                    m0 ^= ((0xaa662387u >> (r0.y & 31u)) << ((unsigned)(*mp == *q0) & 31u));
                    q0 = &garr[(v0 + r0.x) & 7u];
                    h0 = (short)((unsigned)(0x1b83030bu && (unsigned)((unsigned)s0 || u2)) * 0xffffffffu);
                    if ((unsigned)((int)0x3a140efeu >= (int)(unsigned)h1)) break;
                    u0 ^= (unsigned)((unsigned)(signed char)(-(m0 + 0xc6d8e8d5u) << ((unsigned)(2u == 0xdb7f7ee5u) & 31u)) < i1);
                }
                if ((unsigned)w0) goto L4;
            } while (i2++ < 5u && (0xb41c7705u & (0x10000u * (unsigned)h0)));
            if (0x80000000u) break;
            u0 = (unsigned)c0;
            while (p1) { if (--fuel == 0u) goto done;
                m0 ^= ((unsigned)((int)r0.x < (int)(unsigned)(x0 >> 70)) * 0xeb08c96bu);
                break; (void)((unsigned)((unsigned)b0 == 0x7fffffffu));
                h1 = (unsigned short)(h1 + ((unsigned)(r0.x && (unsigned)(r0.y == 0x80000000u)) >> ((0x7fffffffu << (5u & 31u)) & 31u)));
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)((int)0xe0ebd29u >= (int)m0) < (int)((unsigned)(garr[i1 & 7u] && a0[i0 & 3u]) % ((unsigned)c1 | 1u)));
                c0 = (unsigned char)(unsigned)((int)m0 >= (int)(unsigned)(signed char)(0x92b5f871u * (i2 | i1)));
            }
            break; (void)((unsigned)!((unsigned)((short)i0 > (signed char)0x10000u) / (*mp | 1u)));
        } while (i1++ < 4u && (3u + (unsigned)(unsigned char)(unsigned)((short)i0 > (signed char)a0[i0 & 3u])));
        q0 = &garr[(unsigned)((unsigned)(a0[i0 & 3u] < fuel) || (u1 - (fuel & (unsigned)e0))) & 7u];
    }
    for (;;) { if (--fuel == 0u) goto done;
        switch ((g0 - (unsigned)(signed char)(unsigned)((int)0xffffffffu < (int)p2)) & 7u) {
            *q0 = *q0;
            case 7u: ;
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    default: ;
                    b0 = (unsigned)((short)(unsigned)((int)(unsigned)s0 < (int)(unsigned)c1) > (signed char)garr[i1 & 7u]) != 0u;
                    if ((unsigned)(signed char)(((unsigned)(w0 >> 29) * 8u) ^ 0x80000000u)) break;
                } while (i2++ < 3u && (unsigned)(0x411da2a4u && 0x7fffffffu));
                c1 = (signed char)(u1 | u2);
                { unsigned t5; double z5; if (((unsigned)((short)(unsigned)b0 > (signed char)((unsigned)f0 - u2))) & 1u) { t5 = (unsigned)(u3 < fuel); z5 = (double)(((unsigned)(signed char)(unsigned)((unsigned)(w0 >> 29) && (unsigned)b0)) & 255u); } if (((unsigned)((short)(unsigned)b0 > (signed char)((unsigned)f0 - u2))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                    l0 = (long)((unsigned long)l0 + (unsigned)f0);
                }
            }
            switch ((*mp + v0) & 7u) {
                { unsigned t6; double z6; if (((unsigned)(i1 == *mp)) & 1u) { t6 = (garr[i1 & 7u] - 0xf53bf465u); z6 = (double)(((unsigned)((int)(unsigned)(unsigned char)(9u & fuel) < (int)(unsigned)c0)) & 255u); } if (((unsigned)(i1 == *mp)) & 1u) { u3 += t6; d0 = d0 * 0.5 + z6; }
                    while (i1++ < 3u && (unsigned)c0) { if (--fuel == 0u) goto done;
                        for (;;) { if (--fuel == 0u) goto done;
                            case 7u: ;
                            case 3u: ;
                        }
                        h1 = (unsigned short)(h1 + (unsigned)w0);
                        r0.x = (unsigned)((int)(unsigned)(1u || 0xffffffffu) < (int)(unsigned)s0);
                    }
                    default: ;
                    case 4u: ;
                    g0 = (unsigned)((unsigned)(unsigned char)(8u | 0x53273c52u) < p2);
                    *q0 = fuel;
                }
                break; (void)((0x10000u % ((unsigned)(garr[i1 & 7u] || 0x9f2d65e4u) | 1u)));
                g1 += -(unsigned)((short)(unsigned)s1 > (signed char)garr[u2 & 7u]);
                w0 = w0 * 6364136223846793005ull + (unsigned)(i1 < (r0.y / (u1 | 1u)));
                break;
            }
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)h0) {
                    case 1u: ;
                    c0 = (unsigned char)(r0.y << ((unsigned)(p2 || ((unsigned)!(0x80000000u & g1) >> (8u & 31u))) & 31u));
                    if ((p2 % ((u2 % (0xffffffffu | 1u)) | 1u))) goto done;
                }
                if (p1) {
                    i1 = ((u3 | 8u) ? (unsigned)c0 : (unsigned)h0) & 15u;
                    h1 = (unsigned short)(h1 + (unsigned)((u2 - 0u) || *q0));
                    if (0x90b04727u) continue;
                    c0 = (unsigned char)(unsigned)(0xffffffffu < (unsigned)s0);
                    case 4u: ;
                    s1 = (int)((unsigned)s1 + (unsigned)((int)((unsigned)((unsigned)l0 && (unsigned)(x0 >> 70)) + (unsigned)f0) >= (int)(unsigned)((int)0xea8aaeaeu < (int)(unsigned)e0)));
                }
                { unsigned t7; double z7; if ((((unsigned)h1 | r0.x)) & 1u) { t7 = ((unsigned)h1 | (unsigned)d0); z7 = (double)((((unsigned)h0 >> (g1 & 31u))) & 255u); } if ((((unsigned)h1 | r0.x)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
                    case 2u: ;
                    case 5u: ;
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + 2u);
                        m0 ^= (unsigned)(((unsigned)(w0 >> 29) | p1) < (unsigned)s0);
                        g1 += (i2 / (0x72eda95bu | 1u));
                        *q0 += (unsigned)((unsigned)x0 && (((unsigned)c1 << (0xffffffffu & 31u)) >> ((unsigned)(signed char)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0x178ff169u) & 31u)));
                        break;
                    }
                }
            }
            s1 = (int)((unsigned)s1 + (unsigned)(v0 || (p1 - g0)));
        }
        if ((unsigned)(unsigned char)(unsigned)((unsigned)x0 == 0x2569b60au)) break;
        r0.y ^= (0x80000000u << ((4u * 6u) & 31u));
        u3 += (unsigned)((int)(0x7fffffffu << (u0 & 31u)) >= (int)0xffffffffu);
        i0 = (0x80000000u >> ((unsigned)!(*q0 & 0x518bf746u) & 31u)) & 15u;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(unsigned char)((i1 ^ (unsigned)w0) / (*q0 | 1u))) break;
        } while (i1++ < 2u && 5u);
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t8; double z8; if (((unsigned)((int)i2 >= (int)(unsigned)s0)) & 1u) { t8 = ((unsigned)(0x80000000u || g0) / (0u | 1u)); z8 = (double)(((unsigned)((int)(unsigned)!(unsigned)((int)0x80000000u < (int)fuel) >= (int)(unsigned)(w0 >> 29))) & 255u); } if (((unsigned)((int)i2 >= (int)(unsigned)s0)) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
            continue; (void)((unsigned)c0);
            u1 += (i2 * p2);
            if ((0xe670a28du * (0x2ae587edu >> ((unsigned)(w0 >> 29) & 31u)))) {
                if ((unsigned)((unsigned)c0 || (unsigned)((int)(unsigned)l0 < (int)5u))) break;
            } else {
                d0 = d0 * 0.5 + (double)((0x80000000u * (((unsigned)(w0 >> 29) << (6u & 31u)) & u0)) & 1023u);
            }
            if ((unsigned)((unsigned)s1 || g0)) {
                break; (void)(0xffffffffu);
                if ((unsigned)((unsigned)(0x7fffffffu && (unsigned)c1) || 0x7fffffffu)) break;
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (*mp) break;
                    a0[(i1 ^ (unsigned)h1) & 3u] = (unsigned)((short)0xda96328cu > (signed char)((unsigned)x0 * 6u));
                }
                goto L1;
                { unsigned t9; double z9; if ((0x7fffffffu) & 1u) { t9 = ((0xb6d86380u & v0) * 5u); z9 = (double)(((0xffffffffu << ((unsigned)(garr[u2 & 7u] == m0) & 31u))) & 255u); } if ((0x7fffffffu) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
                    u1 ^= ((unsigned)(w0 >> 29) / (0x45164c9du | 1u));
                    break; (void)((unsigned)((unsigned)(unsigned char)(4u / (g1 | 1u)) < (unsigned)c1));
                    q0 = &garr[(unsigned)h1 & 7u];
                    if ((unsigned)(g1 < u1)) continue;
                }
            }
            *mp = (a0[i0 & 3u] % ((unsigned)h0 | 1u));
            g0 = (unsigned)((int)0x80000000u < (int)(unsigned)((unsigned)(6u < (unsigned)c1) || u1));
        }
        while (i1++ < 6u && (unsigned)((short)0x1834b131u > (signed char)i1)) { if (--fuel == 0u) goto done;
            if ((unsigned)((g0 % ((unsigned)h0 | 1u)) == p1)) {
                u3 = (unsigned)(i0 && (garr[u2 & 7u] % (((i0 - (unsigned)h0) >> (0xc1268461u & 31u)) | 1u)));
                if ((u3 + 0x7fffffffu)) break;
                while (i2++ < 7u && (-(0x3f01c701u + (unsigned)c0) / (m0 | 1u))) { if (--fuel == 0u) goto done;
                    u1 = (0x62d668d1u / (garr[i1 & 7u] | 1u));
                    w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)(garr[u2 & 7u] < (unsigned)(w0 >> 29)) > (signed char)(unsigned)((short)5u > (signed char)6u));
                }
            }
        }
        s1 = (int)((unsigned)s1 + (u0 - (unsigned)(0xa78f60f1u < 0xffffffffu)));
        h0 = (short)(unsigned)((int)4u >= (int)(unsigned)(9u || (i2 ^ u0)));
        if (((p2 >> (0x10162a86u & 31u)) ^ (unsigned)c1)) {
            if (u0) break;
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                r0.y ^= p0;
                *q0 = ((unsigned)l0 + (((unsigned)(x0 >> 70) - *mp) >> (0xffffffffu & 31u)));
                u3 = (unsigned)(((unsigned)((int)(unsigned)e0 < (int)0xffffffffu) << (0x80000000u & 31u)) || 0x4cb594bu);
                if ((unsigned)((int)(a0[i0 & 3u] / ((unsigned)l0 | 1u)) >= (int)0xb5e2ed03u)) break;
                a0[(a0[u1 & 3u] - 4u) & 3u] = p0;
            }
            { unsigned t10; double z10; if (((unsigned)((int)0x1203d97du < (int)((unsigned)l0 + garr[u2 & 7u]))) & 1u) { t10 = ~(unsigned)((int)(unsigned)(r0.x && u1) >= (int)(unsigned)c1); z10 = (double)((0xbd88a06eu) & 255u); } if (((unsigned)((int)0x1203d97du < (int)((unsigned)l0 + garr[u2 & 7u]))) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
                w0 ^= (unsigned long long)g1 << (((unsigned)((int)g1 >= (int)(unsigned)d0) & (unsigned)((unsigned)w0 && 0u)) & 63u);
                continue; (void)((unsigned)(short)(unsigned)((unsigned)h0 && u2));
                if ((unsigned)c1) break;
                break; (void)(3u);
            }
            break; (void)((unsigned)((i2 >> (0x7fffffffu & 31u)) && i1));
        } else {
            x0 = x0 * 0x100000001b3ull + ((unsigned)((int)1u >= (int)0x10000u) << (garr[u2 & 7u] & 31u));
            garr[(p0 + (unsigned)h0) & 7u] = (0xa3cc5b71u - garr[i1 & 7u]);
            b0 = (unsigned)w0 != 0u;
            h0 = (short)((unsigned)((unsigned)(w0 >> 29) < (0xd1397763u ^ (i0 << (r0.x & 31u)))) % (g1 | 1u));
        }
    }
    { unsigned t11; double z11; if ((((unsigned)e0 / (4u | 1u))) & 1u) { t11 = (unsigned)b0; z11 = (double)(((((unsigned)f0 * 5u) >> (g1 & 31u))) & 255u); } if ((((unsigned)e0 / (4u | 1u))) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
        b0 = (0x7fffffffu - (unsigned)(8u || a0[i0 & 3u])) != 0u;
    }
    w0 ^= (unsigned long long)(unsigned)((int)a0[i0 & 3u] < (int)(unsigned)(x0 >> 70)) << (((unsigned)e0 ^ (unsigned)h0) & 63u);
    c1 = (signed char)(~(0x79b8e1fu * *mp) % ((unsigned)((5u | u0) == v0) | 1u));
    while (i0++ < 6u && (unsigned)((int)(unsigned)c0 < (int)(3u % (3u | 1u)))) { if (--fuel == 0u) goto done;
        if ((unsigned)(x0 >> 70)) {
            if ((a0[u1 & 3u] | i2)) break;
            a0[0x523df679u & 3u] = ((unsigned)((int)p0 >= (int)(unsigned)f0) ^ *q0);
            break; (void)((garr[u2 & 7u] ? i0 : g0));
        }
    }
    f0 = f0 * 0.5f + (float)(~(a0[u1 & 3u] ^ (-(a0[u1 & 3u] >> (u2 & 31u)) | u3)) & 255u);
    goto done;
    if (((*mp % (0xb79511d5u | 1u)) % (g0 | 1u))) goto done;
    { unsigned t12; double z12; if (((0xcbbf1f7eu + g0)) & 1u) { t12 = 0xa31a009au; z12 = (double)((0xa35ee9b0u) & 255u); } if (((0xcbbf1f7eu + g0)) & 1u) { u3 += t12; d0 = d0 * 0.5 + z12; }
        r0.y ^= ~(unsigned)((((unsigned)(w0 >> 29) >> ((i0 - p0) & 31u)) - (unsigned)(x0 >> 70)) || 5u);
        if (fuel < 8u) return (((unsigned)(w0 >> 29) | fuel) / ((unsigned)h0 | 1u));
        switch ((unsigned)(unsigned char)((unsigned)w0 - r0.y) & 7u) {
            case 7u: ;
            if (*q0) break;
            goto done;
            s1 = (int)((unsigned)s1 + (((unsigned)(r0.x < 5u) / (0x80000000u | 1u)) * 0xab44c39u));
        }
        while ((unsigned)s1) { if (--fuel == 0u) goto done;
            if ((0x7fffffffu ? (unsigned)e0 : a0[u1 & 3u])) break;
            break; (void)(p0);
            if ((unsigned)(((unsigned)(w0 >> 29) + (unsigned)s1) < m0)) {
                if (~(0xffffffffu + v0)) break;
                break; (void)((p0 | (0x7fffffffu / ((unsigned)(x0 >> 70) | 1u))));
                g0 = (2u ? 0u : g1);
                u3 += garr[u2 & 7u];
                if (i1) break;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    c1 = (signed char)(0xffffffffu >> ((unsigned)((unsigned)((9u & a0[i0 & 3u]) < (unsigned)f0) < r0.y) & 31u));
                    v0 = (((v0 + 1u) >> ((unsigned)(r0.y < 0x189228c7u) & 31u)) * g1);
                }
            }
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                while (i2++ < 6u && (1u ^ m0)) { if (--fuel == 0u) goto done;
                    if (~(unsigned)(i1 < r0.x)) break;
                    *q0 += (((unsigned)((int)u2 >= (int)(unsigned)s0) ^ (unsigned)c0) - (unsigned)((unsigned)s0 && (unsigned)(w0 >> 29)));
                    u1 = 0xe31e5787u;
                    if ((unsigned)l0) break;
                }
                m0 ^= (i2 & (u3 & a0[i0 & 3u]));
                while (i2++ < 6u && r0.x) { if (--fuel == 0u) goto done;
                    if ((unsigned)(i1 && (fuel % ((unsigned)c0 | 1u)))) continue;
                }
                x0 = x0 * 0x100000001b3ull + garr[u2 & 7u];
            }
        }
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(short)((unsigned)x0 ^ u2)) continue;
        garr[(r0.x + (unsigned)(w0 >> 29)) & 7u] = u0;
        m0 ^= (unsigned)((int)(unsigned)s1 >= (int)((unsigned)(x0 >> 70) >> ((((unsigned)c0 / (garr[u2 & 7u] | 1u)) % (m0 | 1u)) & 31u)));
    }
    a0[(unsigned)(w0 >> 29) & 3u] = (unsigned)((unsigned)l0 && (unsigned)((v0 - (unsigned)(w0 >> 29)) < 3u));
    m0 ^= (unsigned)(unsigned char)(((unsigned)((short)0x80000000u > (signed char)v0) << ((unsigned)c1 & 31u)) / (0x80000000u | 1u));
    if ((unsigned)w0) goto L4;
    l0 = (long)((unsigned long)l0 + (~(unsigned)((unsigned)w0 < i2) | (unsigned)((int)(unsigned)((unsigned)s1 < 0xffffffffu) >= (int)garr[i1 & 7u])));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    d0 = d0 * 0.5 + (double)(i0 & 1023u);
    f0 = f0 * 0.5f + (float)((unsigned)!(unsigned)(3u == (0x80000000u / ((unsigned)(0xecb263b3u < (unsigned)(x0 >> 70)) | 1u))) & 255u);
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((p1 >> (0x10000u & 31u)) % (0x80000000u | 1u))) {
            b0 = (-(unsigned)(*q0 || g0) ^ ((unsigned)(w0 >> 29) >> (a0[u1 & 3u] & 31u))) != 0u;
            *q0 += ~(0x7fffffffu ? (unsigned)(w0 >> 29) : r0.y);
            w0 = w0 * 6364136223846793005ull + 0x80000000u;
            L0: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)h0 < -(unsigned)((int)garr[u2 & 7u] < (int)0xf8b04ba6u)), p1, g1); }
        }
        if ((unsigned)h0) break;
    }
    if (u3 == 7u) return (unsigned)(0x10000u < (0x7ca491fu / ((u2 << (r0.y & 31u)) | 1u)));
    switch (-((unsigned)(garr[u2 & 7u] && (unsigned)h0) | g0) & 7u) {
        c1 = (signed char)(unsigned)(signed char)(((unsigned)((short)1u > (signed char)0x80000000u) >> ((unsigned)c0 & 31u)) % (((unsigned)d0 - 0x7fa8ed33u) | 1u));
        if ((unsigned)c0) {
            if (p1) {
                if (budget != 0u) { budget -= 1u; u1 = fn0((1u * 0x46701131u), (unsigned)((short)0xcd4cb7cfu > (signed char)(unsigned)x0), (unsigned)((int)(unsigned)c1 >= (int)0xf2af1006u)); }
                e0 = e0 * 0.5L + (long double)(0xffffffffu & 1023u);
                { unsigned t0; double z0; if (((fuel << (i2 & 31u))) & 1u) { t0 = (unsigned)c1; z0 = (double)(((unsigned)!(unsigned)((int)0x10000u < (int)(m0 | g1))) & 255u); } if (((fuel << (i2 & 31u))) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                    if ((unsigned)(signed char)(unsigned)((int)garr[i1 & 7u] >= (int)i2)) {
                        l0 = (long)((unsigned long)l0 + (unsigned)d0);
                        case 1u: ;
                    } else {
                        if ((unsigned)(short)(g0 % ((i2 | u3) | 1u))) break;
                        if (fuel < 8u) return (((unsigned)(x0 >> 70) + (unsigned)(w0 >> 29)) >> ((unsigned)(0x10000u || g1) & 31u));
                        L1: if (--fuel == 0u) goto done;
                    }
                    L2: if (--fuel == 0u) goto done;
                    case 2u: ;
                    { unsigned t1; double z1; if (((unsigned)!(unsigned)(v0 || 0x9eafbce0u)) & 1u) { t1 = (unsigned)(0xf92ce0d5u == u1); z1 = (double)((((unsigned)x0 % (~(unsigned)((short)i0 > (signed char)(unsigned)h1) | 1u))) & 255u); } if (((unsigned)!(unsigned)(v0 || 0x9eafbce0u)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                        *mp = (garr[u2 & 7u] * 0x7700f9bau);
                    }
                    switch ((0x10000u - (unsigned)w0) & 7u) {
                        r0.x = (unsigned)(signed char)((unsigned)(w0 >> 29) * (unsigned)((int)(unsigned)(x0 >> 70) >= (int)((unsigned)(short)(m0 | g0) * p2)));
                        case 5u: ;
                        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0x5c8665f6u && 3u), (p1 & (unsigned)!((unsigned)e0 | (unsigned)b0)), ((u3 % (8u | 1u)) << ((unsigned)h0 & 31u))); }
                        case 1u: ;
                    }
                }
                s0 = (int)(unsigned)!((unsigned)((int)(unsigned)(x0 >> 70) < (int)(i2 << ((unsigned)h1 & 31u))) - a0[i0 & 3u]);
                l0 = (long)((unsigned long)l0 + (unsigned)s0);
                if (fuel) {
                    e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)((short)((u3 + 0x80000000u) | (unsigned)h0) > (signed char)(unsigned)h1) && r0.y) & 1023u);
                }
            }
        }
        u2 = u2 * 0x9e3779b1u + ~(unsigned)((int)(2u - r0.y) < (int)(0x10000u + p0));
        if ((unsigned)(6u && (0x8a102113u - (unsigned)h1))) goto L3;
        g0 = (p2 + p1);
    }
    while (i0++ < 3u && 0xc93571adu) { if (--fuel == 0u) goto done;
        h0 = (short)((0u ^ garr[i1 & 7u]) ^ 0x5f39b49cu);
        L3: if (--fuel == 0u) goto done;
    }
    r0.x = (0x80000000u * 0u);
    do { if (--fuel == 0u) goto done;
        v0 = (unsigned)((int)*mp < (int)(unsigned)b0);
        q0 = &garr[(unsigned)d0 & 7u];
        if (u3 == 7u) return (unsigned)((u0 | (0xffffffffu - (unsigned)(x0 >> 70))) && 0x80000000u);
        switch (garr[i1 & 7u] & 7u) {
            continue; (void)(((unsigned)((int)v0 >= (int)fuel) & p1));
            if (u3 == 7u) return ((unsigned)(signed char)(unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)c0) ^ (unsigned)s0);
            case 3u: ;
            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)c1 < (0xfccdb646u + p2));
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!(p0 + 0xa88ffc5u), (((unsigned)l0 + (unsigned)(w0 >> 29)) | 6u), ((unsigned)(x0 >> 70) * i0)); }
            while ((0x8e2afe10u * (fuel | *mp))) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)((short)g1 > (signed char)u1) & 1023u);
            }
        }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)d0) break;
        }
    } while (i0++ < 3u && i1);
    garr[(unsigned)((short)m0 > (signed char)i0) & 7u] = ~(unsigned)((int)((unsigned)c0 - 0u) >= (int)((unsigned)((unsigned)h1 < 0x10000u) << (u3 & 31u)));
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 4u && ~(p0 + p1)) { if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
        }
        *q0 = (unsigned)((int)*mp < (int)(((unsigned)((int)0x95e54edeu < (int)0xffffffffu) ^ (unsigned)c0) % (garr[u2 & 7u] | 1u)));
        *q0 += (v0 ? 0xef1e7e75u : 0x80000000u);
        if ((0x10000u * g1)) break;
        if (budget != 0u) { budget -= 1u; u2 = fn0(~(unsigned)((unsigned)b0 < ((unsigned)s1 | (unsigned)h1)), u2, 0x2f9600e2u); }
        switch (~(0xc3f585afu ? (unsigned)d0 : g1) & 7u) {
            goto L4;
            u1 = (unsigned)!(unsigned)((short)((unsigned)s0 * (unsigned)(signed char)(0x47089a3u / (0x80000000u | 1u))) > (signed char)(0x80000000u ^ (unsigned)h0));
            break; (void)(p0);
            *mp = (unsigned)((int)((unsigned)h0 + 0xea2282acu) >= (int)u3);
            m0 ^= (((unsigned)c1 % ((unsigned)((unsigned)w0 < g1) | 1u)) / ((0xffffffffu << ((unsigned)f0 & 31u)) | 1u));
        }
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((short)r0.y > (signed char)v0) + (unsigned)s1), (0x283878adu ^ (unsigned)w0), ((unsigned)c0 | ((unsigned)h0 | (unsigned)b0))); }
    for (;;) { if (--fuel == 0u) goto done;
        g1 += (0x236b1dc3u | (unsigned)c1);
    }
    garr[i2 & 7u] = (unsigned)((unsigned)s1 < (unsigned)b0);
    goto L3;
    if (budget != 0u) { budget -= 1u; u3 = fn0((0xcaad80bau % (i0 | 1u)), ((unsigned)(short)(unsigned)(0xea6b4c0bu < u2) | 0u), (unsigned)(x0 >> 70)); }
    if (garr[u2 & 7u]) goto L4;
    if ((unsigned)((unsigned)d0 == *mp)) {
        u2 = u2 * 0x9e3779b1u + (unsigned)(signed char)(~((unsigned)(((unsigned)s1 >> (0xc7e60331u & 31u)) && (unsigned)l0) ^ *mp) | u1);
        c0 = (unsigned char)a0[i0 & 3u];
        if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)c1 | (unsigned)s1), (unsigned)(u1 == *mp), i1); }
    }
    { unsigned t2; double z2; if (((r0.y - u0)) & 1u) { t2 = (unsigned)(short)(0xffffffffu & 0x7fffffffu); z2 = (double)(((p1 >> ((unsigned)s0 & 31u))) & 255u); } if (((r0.y - u0)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        if ((i0 / ((unsigned)s1 | 1u))) goto L1;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!((unsigned)l0 << ((r0.y | (unsigned)s1) & 31u)), (unsigned)!(unsigned)(u0 < 9u), (unsigned)(short)(unsigned)(u0 || p1)); }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)e0, (p0 % (-(0x7fffffffu >> (9u & 31u)) | 1u)), (unsigned)(0x10c03f85u < (4u << ((unsigned)h1 & 31u)))); }
        do { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)c1;
            if ((0x62c18512u << (u2 & 31u))) continue;
            d0 = d0 * 0.5 + (double)(((unsigned)(x0 >> 70) | (unsigned)((*mp >> (garr[i1 & 7u] & 31u)) && 9u)) & 1023u);
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)(unsigned)h1 > (signed char)p2)) break;
                q0 = &garr[(unsigned)((unsigned)((int)0u < (int)0x7f235b60u) || (unsigned)h0) & 7u];
                if (a0[u1 & 3u]) goto L4;
                *mp = (i1 - (unsigned)(i0 || (unsigned)(signed char)(a0[i0 & 3u] >> ((unsigned)x0 & 31u))));
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    u3 ^= ((unsigned)(w0 >> 29) >> (((unsigned)b0 - 0xffffffffu) & 31u));
                    s0 = (int)(((unsigned)((unsigned)f0 && a0[u1 & 3u]) ^ *q0) + a0[u1 & 3u]);
                    w0 ^= (unsigned long long)(unsigned)(6u || u2) << ((unsigned)((p0 | (i2 >> (0x10000u & 31u))) == (unsigned)s1) & 63u);
                    if ((v0 ^ u0)) continue;
                    garr[0u & 7u] = (unsigned)(0x10000u == 0xdf2fbf6bu);
                }
            }
        } while (i0++ < 3u && (-(0x10000u % (r0.x | 1u)) % (0x8dd02104u | 1u)));
        if (u3 == 7u) return (unsigned)((unsigned)((short)p0 > (signed char)(unsigned)((short)p1 > (signed char)p0)) < (unsigned)s1);
        if ((unsigned)c1) goto L3;
    }
    if (0x80000000u) {
        while (i0++ < 4u && (p1 >> (i0 & 31u))) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)(unsigned)(0xac14541u || (unsigned)e0) > (signed char)(unsigned)d0)) {
                if (0x215142e2u) continue;
                f0 = f0 * 0.5f + (float)((unsigned)(w0 >> 29) & 255u);
                continue; (void)((unsigned)(7u && u3));
                g1 += -((unsigned)w0 / ((unsigned)(0x10000u < garr[u2 & 7u]) | 1u));
                break; (void)(((garr[u2 & 7u] << ((unsigned)s1 & 31u)) % (p2 | 1u)));
            }
            r0.y ^= ((unsigned)c1 ^ (unsigned)((int)6u >= (int)(unsigned)((int)i0 < (int)p2)));
        }
    } else {
        w0 ^= (unsigned long long)(unsigned)h0 << ((unsigned)(signed char)(*mp + 5u) & 63u);
        { unsigned t3; double z3; if ((i2) & 1u) { t3 = (a0[i0 & 3u] % ((unsigned)(x0 >> 70) | 1u)); z3 = (double)(((unsigned)((int)3u >= (int)0x7b57df5bu)) & 255u); } if ((i2) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            *q0 += ~((unsigned)((unsigned)(g0 || (0x10000u << ((unsigned)h0 & 31u))) < r0.x) / (g1 | 1u));
            w0 = w0 * 6364136223846793005ull + (unsigned)!(unsigned)((int)0xd2ad57beu < (int)(0xc9562e14u ^ a0[i0 & 3u]));
            e0 = e0 * 0.5L + (long double)(i2 & 1023u);
            do { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + 0xab22a777u);
                if ((unsigned)((int)a0[i0 & 3u] < (int)0xffffffffu)) {
                    h0 = (short)((unsigned)h1 ? (0x488dc624u | 5u) : 0x70de0c8fu);
                    for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                        while (i2++ < 4u && (i0 ? 0x10000u : 0x2e4ad596u)) { if (--fuel == 0u) goto done;
                            break; (void)((unsigned)x0);
                            s0 = (int)(a0[i0 & 3u] ? (unsigned)((unsigned)(unsigned char)((unsigned)w0 - 9u) && (unsigned)(x0 >> 70)) : (unsigned)h1);
                            w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)(unsigned)(5u && ((p0 * fuel) >> ((g1 + (unsigned)f0) & 31u)));
                            continue; (void)(garr[i1 & 7u]);
                            i0 = 0x10000u & 15u;
                            r0.y ^= (unsigned)(((garr[i1 & 7u] & 0xffffffffu) + g1) < g1);
                        }
                        if ((0xd7b398f0u % ((unsigned)h1 | 1u))) break;
                        e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)e0 < (unsigned)(w0 >> 29)) & 1023u);
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)c0, 0x7c182c77u, ((unsigned)l0 / (a0[i0 & 3u] | 1u))); }
                        g0 = (-((unsigned)c1 ^ garr[u2 & 7u]) / (0x1bd40b8fu | 1u));
                        w0 ^= (unsigned long long)(unsigned)(short)(0x7fffffffu + 0x80000000u) << ((unsigned)s0 & 63u);
                    }
                    a0[p2 & 3u] = (unsigned)(unsigned char)(0xef05360du & ((unsigned)(u1 || 0x8fd2e763u) - (0xcf24eb98u - (unsigned)s0)));
                    d0 = d0 * 0.5 + (double)(((unsigned)((unsigned)e0 || (unsigned)s0) | (unsigned)x0) & 1023u);
                }
            } while (i0++ < 5u && (unsigned)((int)(0xffffffffu ^ i1) < (int)(unsigned)c0));
            m0 ^= (unsigned)h1;
        }
        goto L2;
        *q0 += (unsigned)((short)(unsigned)((unsigned)(signed char)(unsigned)((int)(unsigned)h1 < (int)8u) && (unsigned)(w0 >> 29)) > (signed char)(unsigned)w0);
    }
    for (;;) { if (--fuel == 0u) goto done;
        q0 = &garr[((p0 / (p2 | 1u)) - (unsigned)(unsigned char)(unsigned)((unsigned)e0 && (unsigned)(7u == 1u))) & 7u];
        break; (void)(u3);
        break; (void)((unsigned)((int)(unsigned)s1 < (int)0xffffffffu));
    }
    { unsigned t4; double z4; if ((((unsigned)(g1 || m0) + u1)) & 1u) { t4 = v0; z4 = (double)(((unsigned)c0) & 255u); } if ((((unsigned)(g1 || m0) + u1)) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        switch ((unsigned)((unsigned)((unsigned)c1 || (unsigned)h0) || 6u) & 7u) {
            if (u3 == 7u) return (unsigned)((int)r0.y < (int)0xd5b615b3u);
            if (budget != 0u) { budget -= 1u; u1 = fn0((v0 | (0x10000u - i2)), ((unsigned)(w0 >> 29) % (u0 | 1u)), ((unsigned)c1 ? u2 : (unsigned)c0)); }
            switch (v0 & 7u) {
                b0 = (r0.x & ((unsigned)((int)(unsigned)s1 >= (int)g0) ^ g0)) != 0u;
            }
            if (5u) {
                if (budget != 0u) { budget -= 1u; u0 = fn0(r0.x, (unsigned)(fuel < r0.y), (unsigned)s1); }
                if (r0.y) goto L2;
            }
            while (i0++ < 5u && (((unsigned)s1 - g0) * (unsigned)s0)) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    b0 = (i2 | 0x6f756f60u) != 0u;
                    d0 = d0 * 0.5 + (double)((unsigned)s0 & 1023u);
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(i0 * 0x16bff0cdu) < (int)8u), (~(garr[u2 & 7u] | 0x80000000u) + (unsigned)h1), ((unsigned)s0 & (unsigned)((unsigned)f0 || i2))); }
                    case 0u: ;
                    if (0x10000u) continue;
                } while (i1++ < 5u && ((garr[u2 & 7u] % (0x6cc80781u | 1u)) / (u2 | 1u)));
            }
        }
        do { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                u3 = (unsigned)(((g1 >> ((unsigned)(0x91f52489u == (unsigned)f0) & 31u)) | i1) == v0);
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)~((unsigned)(w0 >> 29) & (unsigned)f0) < (int)r0.y), (unsigned)(*mp == (g1 % (u1 | 1u))), (unsigned)((unsigned)e0 || -(unsigned)((short)(unsigned)h1 > (signed char)(unsigned)(x0 >> 70)))); }
                break; (void)(7u);
                f0 = f0 * 0.5f + (float)((fuel + (unsigned)s0) & 255u);
                if ((unsigned)s1) goto L4;
            }
        } while (i0++ < 6u && (unsigned)((unsigned)f0 < (7u % (r0.x | 1u))));
    }
    while (i0++ < 6u && (0xffffffffu ? v0 : 5u)) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)(unsigned char)(unsigned)((unsigned)(x0 >> 70) || (unsigned)h1) << (u1 & 31u)));
        if (8u) break;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(0x76f2aee2u || 0x82ec9613u)) goto L0;
            *q0 = ((unsigned)((int)(6u - garr[i1 & 7u]) >= (int)0xd828d6e3u) % (0x80000000u | 1u));
            f0 = f0 * 0.5f + (float)(((unsigned)((int)0x10000u < (int)i1) ^ ~(g0 << (((unsigned)(w0 >> 29) / (*q0 | 1u)) & 31u))) & 255u);
        }
        if ((unsigned)((short)(a0[i0 & 3u] ^ 1u) > (signed char)i0)) goto L1;
        if ((m0 + u2)) continue;
        w0 ^= (unsigned long long)(0x80000000u >> (1u & 31u)) << ((u2 >> (*q0 & 31u)) & 63u);
    }
    if (2u) {
        f0 = f0 * 0.5f + (float)((u0 | i1) & 255u);
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 = ((unsigned)(short)(*q0 + (unsigned)f0) << ((u0 ^ (unsigned)(fuel && 0xffffffffu)) & 31u));
            *mp = ((unsigned)h1 - (unsigned)(i2 == *mp));
            goto L3;
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                g0 = ((unsigned)(1u && (unsigned)x0) ^ (i1 << ((unsigned)(x0 >> 70) & 31u)));
                goto L4;
                w0 = w0 * 6364136223846793005ull + ~(p1 >> ((unsigned)e0 & 31u));
                *mp = (((unsigned)e0 | (unsigned)b0) | (r0.x >> ((unsigned)l0 & 31u)));
                if (((p1 % (garr[i1 & 7u] | 1u)) & u2)) break;
            }
            if ((0x75bac8b0u ^ 6u)) break;
            i1 = (unsigned)((4u | 0x9b6f0dbcu) < 0x80000000u) & 15u;
        }
        if ((unsigned)(unsigned char)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)b0)) goto L1;
        *mp = (unsigned)((unsigned)(short)((u0 / (p2 | 1u)) | (a0[i0 & 3u] % (u3 | 1u))) && p2);
        if ((unsigned)(p2 || (unsigned)(p1 < g0))) goto L4;
    }
    if ((unsigned)((short)7u > (signed char)fuel)) {
        switch ((unsigned)((int)7u >= (int)(unsigned)d0) & 7u) {
            b0 = fuel != 0u;
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                *mp = 0x7fffffffu;
                i0 = (unsigned)(((unsigned)(w0 >> 29) + (unsigned)s0) < (unsigned)c1) & 15u;
                w0 = w0 * 6364136223846793005ull + (unsigned)((0xa0fdae7u | (unsigned)s1) < (unsigned)((unsigned)(w0 >> 29) && (0x7fffffffu - 0xba7be496u)));
                case 2u: ;
                s0 = (int)(unsigned)((int)~(unsigned)((short)(p1 % (u1 | 1u)) > (signed char)garr[i1 & 7u]) < (int)*q0);
            }
            w0 ^= (unsigned long long)(m0 / ((unsigned)h0 | 1u)) << (v0 & 63u);
            g0 = (unsigned)s0;
            case 7u: ;
            m0 ^= ((unsigned)(x0 >> 70) % (((unsigned)c1 ^ (unsigned)((unsigned)l0 < (unsigned)s1)) | 1u));
        }
        if ((unsigned)((0x4f182e7fu - garr[u2 & 7u]) || (unsigned)h1)) goto L1;
        switch (fuel & 7u) {
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)c1 - 5u), (unsigned)(short)(unsigned)((short)7u > (signed char)r0.x), (unsigned)((short)(v0 - p1) > (signed char)i1)); }
            case 0u: ;
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)w0 & 255u);
                if (g1) {
                    w0 = w0 * 6364136223846793005ull + (u1 - (0x44a251f8u ^ (unsigned)l0));
                    m0 ^= (i2 * (unsigned)((int)0x13fb6a8fu < (int)(0x10000u >> ((unsigned)w0 & 31u))));
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)g0 < (int)(unsigned)b0), (unsigned)(signed char)(unsigned)((short)(unsigned)s1 > (signed char)0x93ef505bu), (unsigned)d0); }
                    b0 = ((unsigned)x0 >> ((unsigned)!(7u * r0.y) & 31u)) != 0u;
                    default: ;
                    e0 = e0 * 0.5L + (long double)((unsigned)((int)((r0.x << (2u & 31u)) * (unsigned)((short)(unsigned)s0 > (signed char)(unsigned)w0)) < (int)i2) & 1023u);
                } else {
                    case 5u: ;
                    r0.x = ((unsigned)((unsigned)(0xffffffffu < p2) == 0xd35eb144u) >> (~(unsigned)((int)0xc4030fbcu < (int)u3) & 31u));
                    i0 = (unsigned)((*mp | (garr[i1 & 7u] ^ (unsigned)(x0 >> 70))) && 8u) & 15u;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(0x34e9221u, (unsigned)((short)garr[u2 & 7u] > (signed char)*mp), 9u); }
                }
                c1 = (signed char)((unsigned)((u2 ^ 0xffffffffu) < 0x7fffffffu) % (2u | 1u));
                if (budget != 0u) { budget -= 1u; u1 = fn0((0xffffffffu ? m0 : 0xffffffffu), (unsigned)((int)3u >= (int)(unsigned)((int)u2 >= (int)r0.x)), ((p2 >> ((unsigned)c0 & 31u)) - (unsigned)h1)); }
            }
        }
    } else {
        if ((unsigned)(p2 == m0)) goto L4;
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.x = ((unsigned)((int)(unsigned)c1 >= (int)(unsigned)l0) * (unsigned)((int)garr[u2 & 7u] >= (int)v0));
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)h0 | 0xffffffffu)) goto L2;
        if ((unsigned)((unsigned)(x0 >> 70) == (unsigned)(short)((unsigned)h0 & *mp))) break;
    }
    switch ((unsigned)((int)0xffffffffu < (int)(unsigned)l0) & 7u) {
        *q0 += ~(unsigned)((int)((unsigned)x0 ? (unsigned)((short)5u > (signed char)a0[u1 & 3u]) : garr[i1 & 7u]) < (int)0x10000u);
        x0 = x0 * 0x100000001b3ull + (i0 + ((p2 % ((unsigned)h0 | 1u)) >> (m0 & 31u)));
        c0 = (unsigned char)(unsigned)((int)0u < (int)(unsigned)d0);
        if ((unsigned)((g0 / (a0[u1 & 3u] | 1u)) || (unsigned)s1)) {
            if ((unsigned)!(8u * (unsigned)(x0 >> 70))) {
                i1 = (unsigned)((((unsigned)f0 ^ 0x8a72e8d0u) >> (i0 & 31u)) == (unsigned)((short)u2 > (signed char)0x64562d56u)) & 15u;
                w0 = w0 * 6364136223846793005ull + garr[i1 & 7u];
            }
            s0 = (int)(unsigned)((unsigned)f0 && u1);
        } else {
            q0 = &garr[(unsigned)(p0 == i2) & 7u];
            if ((unsigned)h1) {
                break; (void)(i0);
                r0.x = (garr[i1 & 7u] >> (i0 & 31u));
                g0 = ((unsigned)((int)*mp >= (int)p1) ? (i1 >> (*mp & 31u)) : v0);
                if (budget != 0u) { budget -= 1u; u2 = fn0((garr[i1 & 7u] << (*mp & 31u)), *mp, ((unsigned)x0 % (p2 | 1u))); }
                if (0x2d73764u) break;
            }
            i0 = ((unsigned)(short)(unsigned)((short)0x7fffffffu > (signed char)(unsigned)x0) / (m0 | 1u)) & 15u;
        }
        if ((unsigned)w0) break;
    }
    g0 = (unsigned)((int)((unsigned)e0 << ((unsigned)b0 & 31u)) >= (int)(unsigned)!(0x80000000u & 7u));
    if ((garr[i1 & 7u] / ((unsigned)w0 | 1u))) goto L0;
    s1 = (int)((unsigned)s1 + ((unsigned)s1 ^ *mp));
    if ((unsigned)((int)(unsigned)f0 < (int)a0[i0 & 3u])) {
        *q0 = (unsigned)!(0x90d1b003u / (p2 | 1u));
        u3 = u3 * 0x9e3779b1u + (((unsigned)(~(0x8b96c0d8u | p1) && r0.y) % (u0 | 1u)) >> (m0 & 31u));
        r0.x = (0x7fffffffu / ((unsigned)d0 | 1u));
        if (((unsigned)w0 / ((unsigned)s0 | 1u))) goto L3;
    }
    l0 = (long)((unsigned long)l0 + ((unsigned)e0 / (a0[i0 & 3u] | 1u)));
    goto L0;
    goto L0;
    while (i0++ < 2u && ((unsigned)(w0 >> 29) >> ((unsigned)c0 & 31u))) { if (--fuel == 0u) goto done;
        m0 ^= (unsigned)((unsigned)((int)v0 >= (int)g1) || 0x240a4a7du);
        s1 = (int)((unsigned)s1 + ((u0 + (unsigned)s1) * (unsigned)(unsigned char)((unsigned)(x0 >> 70) / (-(unsigned)((int)(unsigned)c0 < (int)(unsigned)h0) | 1u))));
        x0 = x0 * 0x100000001b3ull + (-(unsigned)((int)4u >= (int)g0) * (3u & u2));
        if (((unsigned)h0 >> (0xd7dd8d7u & 31u))) break;
        if ((unsigned)((unsigned)(4u || *mp) && (unsigned)s1)) break;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)(a0[u1 & 3u] >> (0x15a72ec9u & 31u)), (unsigned)s0, 0xb36d7990u); }
    }
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)(unsigned)s1 > (signed char)p0)) break;
        }
    } while (i0++ < 4u && fuel);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        *mp = u0;
        if ((unsigned)h1) goto L2;
        break; (void)(((unsigned)((int)p2 < (int)m0) / (g0 | 1u)));
    }
    if ((((unsigned)h0 >> ((unsigned)b0 & 31u)) ^ (unsigned)c0)) goto L2;
    a0[0xb5fc8131u & 3u] = (u3 ? i2 : 1u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)c1 == 0xca40634au);
    if ((unsigned)((unsigned)h1 == (unsigned)(i2 < (unsigned)d0))) {
        if (*q0) {
            do { if (--fuel == 0u) goto done;
                switch ((0x80000000u + (unsigned)x0) & 7u) {
                    if ((unsigned)((int)p2 >= (int)(unsigned)b0)) continue;
                }
                if (-(unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)c1 == u3) && u0)) {
                    r0.y ^= ((unsigned)d0 + v0);
                    while (i1++ < 4u && (g0 + (unsigned)((short)0x75cacb4du > (signed char)p1))) { if (--fuel == 0u) goto done;
                        if (9u) continue;
                        for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                            if ((0xe615e31u >> (0x242602beu & 31u))) break;
                            L0: if (--fuel == 0u) goto done;
                            break; (void)(((unsigned)h0 << ((unsigned)d0 & 31u)));
                        }
                    }
                    c0 = (unsigned char)(unsigned)(*q0 && (unsigned)(r0.x < r0.x));
                } else {
                    break; (void)(((unsigned)h1 - (0x7fffffffu / (0xf4d79260u | 1u))));
                    *mp = (unsigned)(unsigned char)(unsigned)((short)0xdc76c740u > (signed char)(unsigned)(w0 >> 29));
                    if (budget != 0u) { budget -= 1u; u2 = fn1((0u % (4u | 1u)), g0, 0x4fd946f9u); }
                    goto L4;
                }
                if ((unsigned)l0) continue;
                a0[0x345c7d5eu & 3u] = ((unsigned)d0 >> (1u & 31u));
            } while (i0++ < 5u && a0[i0 & 3u]);
        } else {
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                *mp = ((unsigned)((unsigned)f0 == (unsigned)!((unsigned)s0 << ((unsigned)w0 & 31u))) * (0xbe57fa23u | 0xe7610cfdu));
                break; (void)((0x80000000u / (0x80000000u | 1u)));
                b0 = (unsigned)((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)((int)(unsigned)x0 < (int)u2)) < *q0) != 0u;
            }
        }
    }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (garr[u2 & 7u]) {
            L1: if (--fuel == 0u) goto done;
        }
        l0 = (long)((unsigned long)l0 + (unsigned)(2u && (unsigned)((short)i2 > (signed char)u2)));
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)(unsigned)((int)i2 < (int)(unsigned)x0)) break;
            switch ((m0 << (0xffffffffu & 31u)) & 7u) {
                case 4u: ;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)b0, p0, (unsigned)((short)0x80000000u > (signed char)((unsigned)l0 % ((unsigned)s0 | 1u)))); }
                r0.y ^= ((0x3396ec2u >> (((unsigned)x0 ^ (unsigned)c1) & 31u)) | (unsigned)((int)(unsigned)f0 < (int)0x7a7e9ab4u));
                *q0 += ((unsigned)((int)((unsigned)l0 / (u2 | 1u)) < (int)(unsigned)(w0 >> 29)) ^ *q0);
                d0 = d0 * 0.5 + (double)((unsigned)((0x10000u ? p2 : 6u) < (unsigned)(w0 >> 29)) & 1023u);
                if ((unsigned)(short)(*mp % ((unsigned)e0 | 1u))) {
                    { unsigned t0; double z0; if (((unsigned)(x0 >> 70)) & 1u) { t0 = (unsigned)((int)u3 >= (int)(unsigned)c1); z0 = (double)((p1) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                        if (budget != 0u) { budget -= 1u; u3 = fn1(((0x709fe0f2u ^ (unsigned)f0) << (0x7fffffffu & 31u)), (unsigned)((unsigned)(w0 >> 29) < u1), (unsigned)((int)u1 < (int)9u)); }
                        break; (void)((unsigned)(short)(unsigned)(0xeef06a67u == ((unsigned)(w0 >> 29) ^ 0x80000000u)));
                        s0 = (int)(unsigned)(1u || ~(unsigned)((6u >> (0x4a15287au & 31u)) == r0.x));
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((short)u3 > (signed char)(unsigned)((unsigned)(x0 >> 70) && (unsigned)f0)), (0x64857244u ^ (unsigned)s0), u2); }
                        u0 = (unsigned)e0;
                        q0 = &garr[(((unsigned)b0 & (unsigned)e0) * 4u) & 7u];
                    }
                    if ((unsigned)(signed char)(unsigned)((unsigned)(signed char)(unsigned)(*q0 < 1u) && garr[i1 & 7u])) break;
                    h1 = (unsigned short)(h1 + (unsigned)((0x67dfed19u << ((unsigned)f0 & 31u)) < (garr[i1 & 7u] ? g0 : u3)));
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)(a0[u1 & 3u] < (unsigned)(unsigned char)(a0[i0 & 3u] << (0x450f2b09u & 31u))) < 0x744868u));
                }
            }
        }
        do { if (--fuel == 0u) goto done;
            break; (void)((0xffffffffu * i2));
            if (0x4c79677bu) continue;
            if ((unsigned)(signed char)(4u * u0)) continue;
            if ((unsigned)b0) break;
            garr[(fuel * (unsigned)e0) & 7u] = ((unsigned)(garr[i1 & 7u] || ((unsigned)h1 >> (0xffffffffu & 31u))) + 2u);
        } while (i1++ < 6u && (unsigned)l0);
        v0 = (~(garr[i1 & 7u] + u1) + p0);
    }
    f0 = f0 * 0.5f + (float)(((unsigned)s0 / (g1 | 1u)) & 255u);
    goto L0;
    u0 += (0x6e23d389u ? 0xffffffffu : (unsigned)((v0 + (unsigned)e0) == g0));
    if (~((0x80000000u << (0x893e2ce5u & 31u)) / (u3 | 1u))) {
        if ((unsigned)((short)(unsigned)x0 > (signed char)~(unsigned)(p0 < a0[i0 & 3u]))) {
            if (-(unsigned)(v0 && 6u)) {
                if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)l0 | p0), (unsigned)((unsigned)((unsigned)(w0 >> 29) < 0xa6f8fea9u) == 0x80000000u), (unsigned)((int)0x3eabf2cu < (int)~(garr[u2 & 7u] * (unsigned)s0))); }
                q0 = &garr[u1 & 7u];
                g1 += (unsigned)(unsigned char)((unsigned)c0 ^ r0.y);
                q0 = &garr[(unsigned)((int)0x10000u >= (int)(0x14ebb8f3u / (0x80000000u | 1u))) & 7u];
            } else {
                d0 = d0 * 0.5 + (double)((unsigned)!(r0.y ? (unsigned)s1 : (1u ? r0.y : a0[u1 & 3u])) & 1023u);
                i2 = ((unsigned)(short)(0x80000000u >> (r0.y & 31u)) ? garr[i1 & 7u] : (unsigned)e0) & 15u;
                garr[(unsigned)!(8u % (0x7fffffffu | 1u)) & 7u] = (i2 >> (m0 & 31u));
            }
            if (u3 == 7u) return ((g1 % ((unsigned)(w0 >> 29) | 1u)) % (((unsigned)(short)((unsigned)(w0 >> 29) | fuel) * 0x10000u) | 1u));
            if ((unsigned)c1) {
                L2: if (--fuel == 0u) goto done;
            }
            goto L4;
            goto L4;
            if (u3 == 7u) return (((unsigned)s1 + (unsigned)c1) % ((unsigned)(*mp < (unsigned)l0) | 1u));
        } else {
            if ((0xd5b3ed33u + 0xffffffffu)) goto done;
        }
        c1 = (signed char)~(unsigned)((short)(unsigned)((int)0x7fffffffu < (int)g0) > (signed char)(0x10a73762u * (unsigned)((short)0xf220e73eu > (signed char)(unsigned)s1)));
    } else {
        if (6u) goto L1;
        s1 = (int)((unsigned)s1 + u2);
        L3: if (--fuel == 0u) goto done;
    }
    if (0x10000u) goto L0;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + ((unsigned)((r0.x ? (unsigned)x0 : g1) && r0.x) - p1));
        do { if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if (((g1 + (unsigned)h0)) & 1u) { t1 = ((unsigned)s0 ^ 0xfef7931au); z1 = (double)((((unsigned)l0 & (unsigned)h1)) & 255u); } if (((g1 + (unsigned)h0)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                if (budget != 0u) { budget -= 1u; u2 = fn0(9u, (unsigned)(u3 || (unsigned)d0), 3u); }
                L4: if (--fuel == 0u) goto done;
                m0 ^= (((unsigned)((int)(0xffffffffu / (u3 | 1u)) < (int)(unsigned)w0) % (i1 | 1u)) >> (0x80000000u & 31u));
                break; (void)((fuel / ((m0 + u0) | 1u)));
                if ((unsigned)((int)a0[u1 & 3u] >= (int)*mp)) continue;
            }
            f0 = f0 * 0.5f + (float)(((unsigned)(garr[i1 & 7u] < a0[i0 & 3u]) % (0xffffffffu | 1u)) & 255u);
            h1 = (unsigned short)(h1 + (unsigned)(short)(unsigned)((unsigned)(8u < (unsigned)c0) == (unsigned)((short)(unsigned)e0 > (signed char)0x10047cc0u)));
            f0 = f0 * 0.5f + (float)((unsigned)((int)*q0 >= (int)(unsigned)h1) & 255u);
            l0 = (long)((unsigned long)l0 + (unsigned)((int)(unsigned)((u3 ^ p2) && u1) >= (int)(unsigned)(short)(unsigned)(6u && g1)));
            if (((a0[u1 & 3u] % ((unsigned)h0 | 1u)) >> (0x10000u & 31u))) break;
        } while (i1++ < 6u && (0x10000u % ((unsigned)x0 | 1u)));
        q0 = &garr[(unsigned)((short)0xaf367211u > (signed char)(unsigned)(i1 < 8u)) & 7u];
        switch ((unsigned)f0 & 7u) {
            goto done;
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t2; double z2; if ((u3) & 1u) { t2 = (unsigned)!(unsigned)((unsigned)s1 < (u0 >> (garr[i1 & 7u] & 31u))); z2 = (double)(((unsigned)((int)r0.y >= (int)g0)) & 255u); } if ((u3) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    case 7u: ;
                    default: ;
                    d0 = d0 * 0.5 + (double)((((0xdb1ef5d5u << ((unsigned)((short)0x757f5712u > (signed char)(unsigned)d0) & 31u)) / (r0.y | 1u)) / (r0.x | 1u)) & 1023u);
                    do { if (--fuel == 0u) goto done;
                        break;
                        e0 = e0 * 0.5L + (long double)(((unsigned)((unsigned)(x0 >> 70) && u3) / (6u | 1u)) & 1023u);
                        r0.y ^= (unsigned)(short)(((unsigned)c1 << (r0.y & 31u)) ^ (unsigned)(a0[i0 & 3u] == (unsigned)(signed char)(unsigned)(u2 && u0)));
                        g0 = (unsigned)(((unsigned)c0 / ((a0[u1 & 3u] / ((unsigned)h0 | 1u)) | 1u)) == 5u);
                        while (i0++ < 6u && (unsigned)(short)((unsigned)d0 / ((unsigned)s1 | 1u))) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn1((g1 - 0x7fffffffu), (unsigned)((0x80000000u ^ u3) && g0), 0u); }
                            if (budget != 0u) { budget -= 1u; u2 = fn1(((r0.x << (a0[u1 & 3u] & 31u)) << (p1 & 31u)), (unsigned)((int)0x80000000u >= (int)(unsigned)(x0 >> 70)), (unsigned)s0); }
                            case 4u: ;
                        }
                    } while (i2++ < 5u && (unsigned)((unsigned)(x0 >> 70) || (unsigned)(unsigned char)(unsigned)((int)r0.y >= (int)g1)));
                    l0 = (long)((unsigned long)l0 + ((unsigned)(m0 || (unsigned)((0xc6842c04u >> (garr[i1 & 7u] & 31u)) || 0x5b5f92e2u)) * g1));
                    s0 = (int)(i2 + (unsigned)s0);
                }
                case 1u: ;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(signed char)(unsigned)((short)fuel > (signed char)(unsigned)w0), (unsigned)d0, (0x5d4c1c26u - p1)); }
        }
        i1 = p0 & 15u;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(x0 >> 70), (unsigned)(signed char)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)fuel), (unsigned)((r0.y >> (m0 & 31u)) == 0x10000u)); }
    }
    u0 += (unsigned)s0;
    i0 = ((unsigned)(signed char)(0xffffffffu << ((garr[i1 & 7u] % ((unsigned)s0 | 1u)) & 31u)) << (a0[i0 & 3u] & 31u)) & 15u;
    garr[(unsigned)((int)2u < (int)0xffffffffu) & 7u] = (unsigned)(unsigned char)(unsigned)((int)((unsigned)e0 + p2) >= (int)(unsigned)e0);
    while (i0++ < 4u && (unsigned)(6u == u0)) { if (--fuel == 0u) goto done;
        h0 = (short)0xf6f83a23u;
        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)((unsigned)c1 ? (unsigned)f0 : r0.x) & 1023u);
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.x = (unsigned)!(0xd4c5bebeu + p0);
            if (budget != 0u) { budget -= 1u; u0 = fn0((u3 & *q0), 0x6213594au, (unsigned)(a0[i0 & 3u] < 0x7fffffffu)); }
            if ((unsigned)(0x4acf8105u < (unsigned)((int)(unsigned)h1 < (int)u1))) {
                w0 ^= (unsigned long long)(unsigned)(unsigned char)(unsigned)((short)(unsigned)h0 > (signed char)*q0) << ((unsigned)(w0 >> 29) & 63u);
                c0 = (unsigned char)(unsigned)((short)i0 > (signed char)6u);
                goto L3;
                { unsigned t3; double z3; if (((garr[u2 & 7u] << (i2 & 31u))) & 1u) { t3 = (unsigned)((0x43175e42u - 0xdfb16a10u) && r0.x); z3 = (double)(((unsigned)(garr[i1 & 7u] || (unsigned)h0)) & 255u); } if (((garr[u2 & 7u] << (i2 & 31u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                    u2 = u2 * 0x9e3779b1u + p0;
                    r0.y ^= i2;
                    for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(garr[u2 & 7u], (unsigned)((int)(unsigned)e0 >= (int)(unsigned)(u1 && u0)), 0xd5b558a9u); }
                        b0 = ((unsigned)f0 * 0x10000u) != 0u;
                        switch ((unsigned)((0xffffffffu / (u3 | 1u)) < 6u) & 7u) {
                            a0[(unsigned)(i1 < p0) & 3u] = ((unsigned)((int)((unsigned)e0 << (a0[u1 & 3u] & 31u)) >= (int)i2) << ((unsigned)((int)*mp < (int)(unsigned)e0) & 31u));
                            s0 = (int)(0x80000000u ^ (i2 << ((unsigned)w0 & 31u)));
                            r0.y ^= (unsigned)((int)(unsigned)w0 >= (int)a0[i0 & 3u]);
                            f0 = f0 * 0.5f + (float)((unsigned)(a0[u1 & 3u] || m0) & 255u);
                        }
                        if ((unsigned)((int)((unsigned)b0 << (u1 & 31u)) < (int)6u)) break;
                        if ((r0.x & (unsigned)x0)) continue;
                    }
                    if ((unsigned)(p2 < g0)) break;
                    if ((m0 ^ 0x10000u)) break;
                    g1 += 0x10000u;
                }
                if ((unsigned)((int)(unsigned)h1 < (int)0xffffffffu)) {
                    f0 = f0 * 0.5f + (float)((unsigned)(i0 && (unsigned)(fuel && 0x3414dfa0u)) & 255u);
                } else {
                    i1 = ((unsigned)b0 | (fuel | u0)) & 15u;
                    if (0xa37d0e84u) goto done;
                    q0 = &garr[((unsigned)((unsigned)b0 < u0) + (r0.x << (6u & 31u))) & 7u];
                    if (budget != 0u) { budget -= 1u; u0 = fn0(-(unsigned)(r0.x || i1), (unsigned)((unsigned)s1 && (unsigned)(r0.y || (unsigned)h1)), (unsigned)((short)(a0[u1 & 3u] + (unsigned)s1) > (signed char)r0.x)); }
                }
            } else {
                if ((0xc1d0541au + p0)) break;
            }
        }
        if ((unsigned)(u2 == (unsigned)f0)) break;
        s1 = (int)((unsigned)s1 + 0x80000000u);
    }
    goto done;
    goto L0;
    w0 ^= (unsigned long long)u2 << ((unsigned)((int)((v0 >> (i2 & 31u)) >> (p0 & 31u)) < (int)fuel) & 63u);
    g0 = ((unsigned)(signed char)(unsigned)(garr[i1 & 7u] || (unsigned)(x0 >> 70)) * ((unsigned)c1 >> (i2 & 31u)));
    r0.x = -(garr[i1 & 7u] - *q0);
    c0 = (unsigned char)((unsigned)(0x8f1818b6u == 0x10000u) * (i0 >> (0x7fffffffu & 31u)));
    switch ((8u >> (8u & 31u)) & 7u) {
        switch ((unsigned)(w0 >> 29) & 7u) {
            if (budget != 0u) { budget -= 1u; u2 = fn0((0x6a740f3cu & 0x10000u), (unsigned)!((unsigned)e0 * (unsigned)w0), i0); }
            w0 ^= (unsigned long long)(unsigned)(0xffffffffu < (unsigned)h0) << ((unsigned)((int)(unsigned)((short)(unsigned)(r0.y == (unsigned)d0) > (signed char)(unsigned)w0) >= (int)(unsigned)(0xd3425851u && fuel)) & 63u);
            case 5u: ;
            e0 = e0 * 0.5L + (long double)((-(*mp | 0xc2b2b9b1u) >> ((unsigned)b0 & 31u)) & 1023u);
            if (fuel < 8u) return -(((unsigned)c1 & (unsigned)(0xd92c33d4u == (unsigned)((int)i2 < (int)(unsigned)f0))) + (unsigned)s1);
        }
        do { if (--fuel == 0u) goto done;
            v0 = -((unsigned)h0 ? (unsigned)c1 : (unsigned)((int)p0 >= (int)u2));
        } while (i0++ < 2u && (*mp << ((0xffffffffu << (0xffffffffu & 31u)) & 31u)));
        switch (8u & 7u) {
            garr[(unsigned)(*mp == 3u) & 7u] = (unsigned)(unsigned char)(p2 % (0xe58c87a0u | 1u));
            case 3u: ;
            default: ;
        }
        i0 = (unsigned)((short)(i0 | (unsigned)(u1 && g1)) > (signed char)g0) & 15u;
        b0 = (unsigned)s1 != 0u;
        if (u3 == 7u) return (unsigned)((int)((u3 % (8u | 1u)) >> ((unsigned)d0 & 31u)) < (int)((unsigned)(x0 >> 70) + (unsigned)h0));
    }
    q0 = &garr[(((unsigned)b0 << ((unsigned)h1 & 31u)) - ((unsigned)b0 ^ 0xe680a0a3u)) & 7u];
    q0 = &garr[(unsigned)((short)(unsigned)f0 > (signed char)(unsigned)(1u < 7u)) & 7u];
    if (((a0[u1 & 3u] / (u1 | 1u)) << ((unsigned)h0 & 31u))) goto L3;
    goto L3;
    { unsigned t4; double z4; if ((((unsigned)(0x7fffffffu || u3) * 0xc1c114u)) & 1u) { t4 = (p0 + 0xec277f9du); z4 = (double)(((-(1u + a0[i0 & 3u]) - 0x25714eu)) & 255u); } if ((((unsigned)(0x7fffffffu || u3) * 0xc1c114u)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)h1, (unsigned)x0, (unsigned)(unsigned char)(unsigned)(r0.x == u2)); }
    }
    { unsigned t5; double z5; if (((0x10000u % ((0xffffffffu | 6u) | 1u))) & 1u) { t5 = ((unsigned)h0 / (garr[i1 & 7u] | 1u)); z5 = (double)((((unsigned)((int)m0 >= (int)0x76172023u) & m0)) & 255u); } if (((0x10000u % ((0xffffffffu | 6u) | 1u))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
        *q0 = (unsigned)(short)((unsigned)((int)0xffffffffu < (int)0x508009edu) << ((unsigned)(unsigned char)(unsigned)((short)fuel > (signed char)((unsigned)c1 << (5u & 31u))) & 31u));
        if ((unsigned)((int)i1 >= (int)(2u % (u3 | 1u)))) {
            if (fuel < 8u) return ((((unsigned)c1 | v0) * u2) >> ((unsigned)((int)9u >= (int)(unsigned)w0) & 31u));
            if (fuel < 8u) return (unsigned)s1;
            x0 = x0 * 0x100000001b3ull + ((unsigned)e0 << ((unsigned)(x0 >> 70) & 31u));
            if ((unsigned)(6u < (garr[i1 & 7u] % ((unsigned)l0 | 1u)))) goto L2;
        } else {
            goto L0;
            switch ((unsigned)!(unsigned)((int)(unsigned)(g0 || 0xffffffffu) >= (int)0x293d9726u) & 7u) {
                if ((unsigned)(v0 == 0xa32bbc3cu)) {
                    s1 = (int)((unsigned)s1 + (8u / (-(unsigned)((int)r0.x >= (int)g0) | 1u)));
                    h0 = (short)(unsigned)b0;
                    u3 += (0xe910f860u >> (-(unsigned)((short)i2 > (signed char)u2) & 31u));
                    x0 = x0 * 0x100000001b3ull + (unsigned)((short)(i0 % ((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)d0) | 1u)) > (signed char)~(u0 * 0u));
                    i1 = (p2 | ((unsigned)b0 / (u1 | 1u))) & 15u;
                    c0 = (unsigned char)0u;
                }
                case 5u: ;
            }
        }
        if ((0xffffffffu % (0x10000u | 1u))) goto L1;
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(i0 & 1023u);
        }
        if (budget != 0u) { budget -= 1u; u0 = fn1(((0x10ef16e7u ^ (unsigned)s0) >> (p0 & 31u)), ((unsigned)(a0[u1 & 3u] == i2) | (unsigned)h0), -(0x80000000u / ((9u / (garr[u2 & 7u] | 1u)) | 1u))); }
        q0 = &garr[-(1u ? (unsigned)h1 : (unsigned)(i1 < (unsigned)(unsigned char)(unsigned)((short)(unsigned)x0 > (signed char)u0))) & 7u];
    }
    while (i0++ < 7u && u0) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1(0xffffffffu, (~(garr[i1 & 7u] - 1u) >> (r0.x & 31u)), (unsigned)((unsigned)b0 && 6u)); }
        w0 ^= (unsigned long long)(unsigned)(g0 < (unsigned)f0) << (((unsigned)(0xa383925eu || (unsigned)s1) - i1) & 63u);
        { unsigned t6; double z6; if (((garr[i1 & 7u] << (r0.x & 31u))) & 1u) { t6 = (unsigned)((int)u3 >= (int)(2u / ((unsigned)h1 | 1u))); z6 = (double)(((0x21830b9du >> ((unsigned)(w0 >> 29) & 31u))) & 255u); } if (((garr[i1 & 7u] << (r0.x & 31u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            if (budget != 0u) { budget -= 1u; u3 = fn1(p1, ((unsigned)((int)(unsigned)h0 < (int)(unsigned)b0) | (unsigned)e0), (unsigned)((short)u1 > (signed char)(unsigned)e0)); }
            *q0 = (unsigned)!(unsigned)(p2 == (0x50b0b695u ^ g1));
            u2 = u2 * 0x9e3779b1u + (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x10000u);
        }
    }
    goto L4;
    if (0x10000u) goto L4;
    c0 = (unsigned char)(i1 % ((unsigned)l0 | 1u));
    if ((unsigned)h1) goto done;
    goto done;
    u0 ^= (unsigned)b0;
    u3 = u3 * 0x9e3779b1u + ((v0 - 0x211faf53u) + a0[u1 & 3u]);
    if (((unsigned)(x0 >> 70) ^ 0x9ad66952u)) goto done;
    if ((unsigned)f0) goto L3;
    while (i0++ < 4u && (0x8014c629u * (unsigned)((unsigned)s1 && u1))) { if (--fuel == 0u) goto done;
        if ((0x10000u + m0)) {
            s0 = (int)-(unsigned)((int)u0 < (int)(unsigned)h1);
            l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)(unsigned)((int)0x7fffffffu < (int)i0));
            w0 = w0 * 6364136223846793005ull + (u2 >> (garr[i1 & 7u] & 31u));
        } else {
            d0 = d0 * 0.5 + (double)((m0 >> ((unsigned)(v0 < garr[i1 & 7u]) & 31u)) & 1023u);
            d0 = d0 * 0.5 + (double)(((unsigned)d0 ? p0 : ((unsigned)b0 * p2)) & 1023u);
            break; (void)((unsigned)((int)(unsigned)(i2 == r0.y) < (int)(unsigned)x0));
        }
        if (((unsigned)(short)(0x80774a0cu % ((unsigned)c1 | 1u)) >> ((unsigned)d0 & 31u))) goto L2;
        if (((unsigned)w0 << (0xfe65adfeu & 31u))) break;
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((int)p0 < (int)~(unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x7b6c0406u))) break;
            if (((unsigned)(x0 >> 70) >> ((unsigned)s0 & 31u))) break;
            if ((unsigned)((unsigned)d0 || (*mp % (7u | 1u)))) break;
        } while (i1++ < 7u && g1);
        if (garr[u2 & 7u]) break;
        while (i1++ < 4u && v0) { if (--fuel == 0u) goto done;
            r0.y ^= ((unsigned)s0 % (4u | 1u));
            *mp = (unsigned)((unsigned)(signed char)((unsigned)x0 / (1u | 1u)) && i0);
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)(9u * 0xe78efce5u), (unsigned)((int)0x7fbd1c42u >= (int)(0xd29c8101u + *q0)), a0[i0 & 3u]); }
            q0 = &garr[(unsigned)(w0 >> 29) & 7u];
        }
    }
    if ((unsigned)((int)(unsigned)x0 >= (int)(unsigned)(short)((unsigned)(x0 >> 70) % (u1 | 1u)))) {
        if (fuel < 8u) return ((unsigned)c1 & (unsigned)(unsigned char)((unsigned)e0 % (0xc9bcbe9cu | 1u)));
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                i1 = g1 & 15u;
                *q0 += (i2 * u0);
                if ((unsigned)(signed char)(unsigned)(5u && r0.y)) break;
                if (((unsigned)(x0 >> 70) + (unsigned)((int)u3 < (int)(unsigned)s1))) {
                    r0.y ^= (unsigned)c0;
                    *q0 += -(unsigned)((unsigned)b0 < (unsigned)b0);
                    d0 = d0 * 0.5 + (double)((unsigned)(w0 >> 29) & 1023u);
                    if (budget != 0u) { budget -= 1u; u1 = fn0(m0, a0[u1 & 3u], ((unsigned)c0 ^ p2)); }
                    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)c1 & r0.y), (unsigned)(v0 < (unsigned)(x0 >> 70)), (unsigned)(i1 == (unsigned)x0)); }
                    if ((u2 ? a0[u1 & 3u] : 6u)) goto L4;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)i2 >= (int)(unsigned)x0), ((unsigned)d0 ^ (unsigned)(i2 || 0xf9d859cfu)), (unsigned)(signed char)(unsigned)(a0[i0 & 3u] && 0x30aa30b8u)); }
            }
        }
        w0 ^= (unsigned long long)(0xf708d002u & 0x75488387u) << ((fuel | ((0x7fffffffu ? g0 : 0x575f241eu) / (*mp | 1u))) & 63u);
    }
    u2 = u0;
    goto L2;
    { unsigned t7; double z7; if (((9u * 4u)) & 1u) { t7 = ((unsigned)w0 ^ (unsigned)((unsigned)x0 || m0)); z7 = (double)(((*mp / ((unsigned)h1 | 1u))) & 255u); } if (((9u * 4u)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
        if ((unsigned)((short)(unsigned)h0 > (signed char)7u)) {
            goto L2;
            goto L1;
            if (fuel) goto L1;
            u2 += -(garr[i1 & 7u] & (unsigned)(unsigned char)(0x7fffffffu * (unsigned)((unsigned)(w0 >> 29) < (unsigned)c1)));
        }
        m0 ^= (unsigned)((garr[i1 & 7u] - 0x8cbbb12eu) || r0.x);
        do { if (--fuel == 0u) goto done;
            break; (void)((unsigned)(r0.y < (unsigned)f0));
        } while (i0++ < 2u && ((a0[i0 & 3u] << (0x7fffffffu & 31u)) ^ a0[u1 & 3u]));
        if ((0x80000000u + (unsigned)((short)0x10000u > (signed char)0x1aaddae7u))) goto L4;
        do { if (--fuel == 0u) goto done;
            if (~(a0[i0 & 3u] << ((unsigned)l0 & 31u))) goto L1;
            g1 += ((garr[u2 & 7u] >> ((unsigned)x0 & 31u)) - ((unsigned)f0 << ((unsigned)l0 & 31u)));
            i2 = (unsigned)((short)i1 > (signed char)(unsigned)f0) & 15u;
            u3 = u3 * 0x9e3779b1u + (unsigned)(r0.x == 0x72960e2eu);
            if ((unsigned)(signed char)((0x123a0013u & p2) & garr[u2 & 7u])) goto L0;
        } while (i0++ < 3u && (0x80000000u ^ i2));
        if ((unsigned)((int)((unsigned)(x0 >> 70) - p0) < (int)1u)) goto L4;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(0x338fe1d7u >> ((u2 * 9u) & 31u)), (-((unsigned)f0 ^ 9u) >> (u2 & 31u)), garr[i1 & 7u]); }
    if (budget != 0u) { budget -= 1u; u1 = fn1(p0, ~(unsigned)((i2 & a0[u1 & 3u]) && 0xf5d91931u), (unsigned)(short)(unsigned)(u0 == (unsigned)(w0 >> 29))); }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(p1 && 9u), 0x3ada998eu, ((0xeeb2cc97u % (p0 | 1u)) ^ (unsigned)w0)); }
    e0 = e0 * 0.5L + (long double)((unsigned)(x0 >> 70) & 1023u);
    if ((unsigned)((short)0xffffffffu > (signed char)(v0 + (unsigned)f0))) goto L1;
    q0 = &garr[(unsigned)!(unsigned)((int)(unsigned)(~(0x80000000u ^ 0xa9c1e461u) || (unsigned)(short)(a0[u1 & 3u] % (0x4b4395f3u | 1u))) >= (int)u3) & 7u];
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (~(unsigned)((int)(unsigned)f0 < (int)(unsigned)e0)) goto L4;
    }
    c0 = (unsigned char)(unsigned)(4u < 0xffffffffu);
    w0 = w0 * 6364136223846793005ull + ((0xffffffffu & (unsigned)e0) ? p2 : (unsigned)f0);
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!((unsigned)((int)1u >= (int)g1) & r0.y), (u2 * (unsigned)(u0 || 0xffffffffu)), ((unsigned)s0 - p0)); }
    while (((unsigned)d0 ^ (unsigned)((int)u2 < (int)m0))) { if (--fuel == 0u) goto done;
        if (g1) {
            c0 = (unsigned char)((unsigned)h1 | ((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)b0) >> ((unsigned)(x0 >> 70) & 31u)));
            s0 = (int)0x10000u;
            g1 += ((unsigned)((int)5u < (int)0x216a7490u) * (unsigned)(0xbc5046eeu || (u3 - i0)));
        } else {
            a0[a0[i0 & 3u] & 3u] = (unsigned)(short)(0x10000u - (unsigned)((short)(unsigned)((unsigned)(x0 >> 70) == v0) > (signed char)g1));
            if ((unsigned)((short)(unsigned)((int)u2 >= (int)fuel) > (signed char)8u)) continue;
            do { if (--fuel == 0u) goto done;
                b0 = (m0 >> ((unsigned)l0 & 31u)) != 0u;
                do { if (--fuel == 0u) goto done;
                    goto L3;
                    if ((0xdf1010u & (unsigned)(5u < (unsigned)w0))) goto L0;
                    if ((unsigned)(unsigned char)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)g0)) break;
                } while (i2++ < 5u && 0x80000000u);
                if (((unsigned)c0 >> (0xeb958046u & 31u))) {
                    q0 = &garr[m0 & 7u];
                    while (i2++ < 2u && (unsigned)((int)(unsigned)d0 < (int)0x10000u)) { if (--fuel == 0u) goto done;
                        b0 = ((unsigned)(0x10000u || 0xffffffffu) ^ (unsigned)(signed char)(unsigned)((int)(fuel | 0xe20973abu) >= (int)8u)) != 0u;
                        d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)w0 > (signed char)((unsigned)((int)0xdcc75deu >= (int)r0.x) | (unsigned)d0)) & 1023u);
                        s0 = (int)((unsigned)(0xa76e4f06u && p0) | i0);
                        break; (void)(((unsigned)((int)p2 < (int)(unsigned)d0) ^ i2));
                    }
                    L0: if (--fuel == 0u) goto done;
                    h0 = (short)(unsigned)b0;
                    a0[~(r0.y >> (r0.x & 31u)) & 3u] = (3u % ((unsigned)((*q0 ? i2 : 0u) < (unsigned)h0) | 1u));
                } else {
                    goto L2;
                }
                a0[~(6u << ((unsigned)s1 & 31u)) & 3u] = a0[i0 & 3u];
                L1: if (--fuel == 0u) goto done;
            } while (i1++ < 3u && p2);
        }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            b0 = (u1 | (unsigned)(m0 && 0x80000000u)) != 0u;
        }
        switch ((unsigned)x0 & 7u) {
            g0 = (unsigned)(0x39c80adbu == (unsigned)(m0 < (((unsigned)s1 - 0u) - v0)));
            L2: if (--fuel == 0u) goto done;
            case 4u: ;
            u3 += u1;
            for (;;) { if (--fuel == 0u) goto done;
                v0 = (unsigned)(unsigned char)((unsigned)((int)*mp < (int)0x80000000u) ^ (unsigned)((int)a0[u1 & 3u] >= (int)a0[u1 & 3u]));
                c0 = (unsigned char)(unsigned)!(unsigned)((short)(unsigned)c1 > (signed char)(unsigned)(x0 >> 70));
                h1 = (unsigned short)(h1 + 9u);
                if (i1) continue;
            }
        }
        L3: if (--fuel == 0u) goto done;
        if (p2) break;
    }
    goto L2;
    if ((unsigned)((int)(unsigned)(*mp == 0x299137d9u) < (int)garr[i1 & 7u])) goto L2;
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 ^= p2;
    }
    u3 = i1;
    L4: if (--fuel == 0u) goto done;
    u0 = i1;
    if ((unsigned)(((unsigned)(w0 >> 29) / ((unsigned)h0 | 1u)) || 5u)) {
        r0.x = ((unsigned)((unsigned)(short)(unsigned)((short)*q0 > (signed char)(unsigned)((short)m0 > (signed char)0x10000u)) && 9u) % (0x3f68a6cdu | 1u));
        e0 = e0 * 0.5L + (long double)(0x10000u & 1023u);
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)(unsigned char)(((unsigned)x0 * (unsigned)(x0 >> 70)) ^ g0) >= (int)0x8f3c4d04u) & 1023u);
        if (((0x5b0cba81u + i1) | 0x8e3f89afu)) continue;
        r0.x = (unsigned)(-(9u - *q0) < -((unsigned)s0 | 0x10000u));
        garr[a0[u1 & 3u] & 7u] = (unsigned)((int)((unsigned)s1 << ((unsigned)x0 & 31u)) < (int)(8u ? r0.x : 0x8c9ec44fu));
    }
    while (i0++ < 5u && (unsigned)((int)(i1 << (fuel & 31u)) < (int)p0)) { if (--fuel == 0u) goto done;
        if ((unsigned)s0) {
            *q0 = (9u << (g1 & 31u));
            w0 ^= (unsigned long long)(unsigned)(0u < (unsigned)x0) << (((unsigned)s1 * 2u) & 63u);
            w0 ^= (unsigned long long)9u << (g1 & 63u);
            if ((unsigned)(signed char)((unsigned)(r0.x || 0xae759974u) >> ((unsigned)h1 & 31u))) break;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(signed char)(unsigned)((*mp >> (m0 & 31u)) < g1), (unsigned)((short)(unsigned)(0x10000u && i1) > (signed char)p0), (unsigned)(unsigned char)(p2 - 6u)); }
            if ((unsigned)(~(unsigned)((int)(unsigned)d0 < (int)(unsigned)c0) || (unsigned)b0)) goto L2;
        } else {
            d0 = d0 * 0.5 + (double)((unsigned)(2u || (u3 & (unsigned)s1)) & 1023u);
        }
        { unsigned t0; double z0; if ((p0) & 1u) { t0 = (unsigned)(u1 < 2u); z0 = (double)((((unsigned)(signed char)(v0 / (0x10000u | 1u)) - i2)) & 255u); } if ((p0) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            *q0 += (unsigned)s1;
            do { if (--fuel == 0u) goto done;
                b0 = (unsigned)w0 != 0u;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)((int)m0 >= (int)m0) >= (int)u2), (unsigned)!(unsigned)(0x861e4669u == (unsigned)x0), (9u ? 6u : 0xd7be6cf9u)); }
                break; (void)(i2);
                q0 = &garr[(u2 << ((r0.x * 3u) & 31u)) & 7u];
                c1 = (signed char)0xd2ff689du;
            } while (i1++ < 3u && (unsigned)((unsigned)b0 < (unsigned)e0));
            switch ((i0 / ((unsigned)((unsigned)x0 && 0xc8d530d4u) | 1u)) & 7u) {
                x0 = x0 * 0x100000001b3ull + (unsigned)f0;
                g0 = (*q0 ? (unsigned)x0 : garr[i1 & 7u]);
            }
        }
        f0 = f0 * 0.5f + (float)((unsigned)((int)a0[i0 & 3u] >= (int)v0) & 255u);
    }
    do { if (--fuel == 0u) goto done;
        if ((unsigned)d0) continue;
        w0 = w0 * 6364136223846793005ull + (unsigned)!(unsigned)((int)((unsigned)(x0 >> 70) | garr[u2 & 7u]) < (int)(unsigned)(g0 == ((unsigned)d0 + (unsigned)e0)));
        if (u3 == 7u) return (unsigned)(signed char)((unsigned)b0 & 0x10000u);
        break; (void)((0x79bf57c3u ? 1u : (unsigned)(w0 >> 29)));
        if (budget != 0u) { budget -= 1u; u2 = fn0(p1, (u3 ^ g1), 0xd0dd9375u); }
    } while (i0++ < 4u && (unsigned)(unsigned char)(unsigned)((unsigned)((int)(unsigned)e0 < (int)(unsigned)d0) || p1));
    do { if (--fuel == 0u) goto done;
        u3 += (((0xe7929a85u ^ 0x80000000u) | (fuel | 0x7fffffffu)) * (unsigned)l0);
        for (;;) { if (--fuel == 0u) goto done;
            for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                *mp = ((u0 >> (a0[u1 & 3u] & 31u)) << ((unsigned)(unsigned char)((unsigned)f0 / (m0 | 1u)) & 31u));
            }
            *q0 += (unsigned)((unsigned)e0 || i1);
            break; (void)((unsigned)((8u >> ((unsigned)b0 & 31u)) || 0xffffffffu));
            h0 = (short)-(unsigned)(r0.y && (garr[u2 & 7u] / ((unsigned)(unsigned char)((unsigned)((int)0x7fffffffu >= (int)p2) & p1) | 1u)));
        }
        r0.y ^= ((unsigned)(signed char)(unsigned)(*mp < 7u) % ((m0 << (u0 & 31u)) | 1u));
        u0 = u0 * 0x9e3779b1u + (unsigned)(short)((unsigned)(short)(unsigned)((int)a0[i0 & 3u] >= (int)0x80000000u) << ((unsigned)(r0.y && 0xb6446dc4u) & 31u));
    } while (i0++ < 4u && 3u);
    h0 = (short)garr[i1 & 7u];
    r0.x = (0x37ad4458u & (unsigned)(p2 || m0));
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(0xd4c7847fu && (unsigned)w0), (unsigned)((short)*q0 > (signed char)(unsigned)h0), (unsigned)h1); }
    while ((unsigned)(0x98d5b232u && (u0 - u3))) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)((int)0xb14d29dau < (int)-(p2 - p2)));
        q0 = &garr[(0x7fffffffu * a0[i0 & 3u]) & 7u];
        break; (void)(4u);
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)c0, (unsigned)s0, (unsigned)((int)(unsigned)((int)0xffffffffu >= (int)0u) < (int)(unsigned)h0)); }
        *q0 += (unsigned)x0;
        if (u3 == 7u) return ((r0.y ^ a0[u1 & 3u]) >> (r0.x & 31u));
    }
    if ((unsigned)!((unsigned)h0 + (garr[i1 & 7u] ^ 4u))) goto L1;
    i0 = (u0 >> (((3u - 8u) ^ g0) & 31u)) & 15u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u0 = fn3(0xffffffffu, 0x80000000u, (unsigned)((short)(0x7fffffffu * u0) > (signed char)(unsigned)(w0 >> 29))); }
    goto done;
    if ((g0 - 0u)) {
        switch (i0 & 7u) {
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)c1) break;
                L0: if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                *q0 += ((8u + (unsigned)((int)g0 >= (int)p1)) + r0.x);
            }
            if ((u3 * 0xffffffffu)) {
                b0 = ((unsigned)x0 % (p2 | 1u)) != 0u;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)f0 ? (unsigned)(x0 >> 70) : r0.y), u1, (unsigned)!(unsigned)(u3 < p0)); }
            if (budget != 0u) { budget -= 1u; u0 = fn2(p0, (unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)0xffffffffu >= (int)(unsigned)f0) >= (int)0x80000000u), (unsigned)b0); }
            L2: if (--fuel == 0u) goto done;
        }
        do { if (--fuel == 0u) goto done;
            h0 = (short)(~((v0 << (0x171ed46u & 31u)) << (3u & 31u)) * u3);
        } while (i0++ < 3u && 2u);
    } else {
        L3: if (--fuel == 0u) goto done;
    }
    { unsigned t0; double z0; if (((unsigned)(p2 < (unsigned)(x0 >> 70))) & 1u) { t0 = (0x4b79cec8u >> (1u & 31u)); z0 = (double)(((unsigned)((int)(unsigned)c0 >= (int)-(unsigned)((int)5u >= (int)u0))) & 255u); } if (((unsigned)(p2 < (unsigned)(x0 >> 70))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        r0.x = ((unsigned)(u0 || *mp) ? (unsigned)l0 : 5u);
        if (budget != 0u) { budget -= 1u; u0 = fn2(g0, (unsigned)(unsigned char)((5u | (unsigned)l0) >> ((unsigned)s1 & 31u)), (9u >> (0x87a7e033u & 31u))); }
        switch ((r0.y >> (7u & 31u)) & 7u) {
            for (;;) { if (--fuel == 0u) goto done;
                for (;;) { if (--fuel == 0u) goto done;
                    q0 = &garr[(unsigned)(unsigned char)(8u * (unsigned)c0) & 7u];
                    *q0 = ((v0 ^ (1u * 0xc5e1491u)) % (((unsigned)h1 ^ a0[i0 & 3u]) | 1u));
                    if (u3 == 7u) return ((unsigned)(unsigned char)((8u + 0x98f6acd9u) | (r0.x * 0x10000u)) + u1);
                }
            }
        }
    }
    g0 = (~(a0[u1 & 3u] & p2) >> ((unsigned)b0 & 31u));
    l0 = (long)((unsigned long)l0 + (unsigned)l0);
    for (;;) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)(w0 >> 29) >> (0x10000u & 31u)));
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((unsigned)w0 & 1023u);
            if (0x1e428d28u) break;
            if (g1) break;
            *q0 += (unsigned)((short)p2 > (signed char)(g1 ^ p0));
            goto L3;
            break; (void)((unsigned)(0xffffffffu == ((unsigned)(w0 >> 29) >> (p2 & 31u))));
        }
        u3 = (u3 * i1);
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if (((-((unsigned)c1 >> (p0 & 31u)) & 0x10000u)) & 1u) { t1 = (unsigned)w0; z1 = (double)(((unsigned)(x0 >> 70)) & 255u); } if (((-((unsigned)c1 >> (p0 & 31u)) & 0x10000u)) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                h0 = (short)(unsigned)s1;
                if ((0u & (unsigned)(w0 >> 29))) goto L3;
                while ((unsigned)(r0.x || u1)) { if (--fuel == 0u) goto done;
                    L4: if (--fuel == 0u) goto done;
                    q0 = &garr[u1 & 7u];
                }
                w0 ^= (unsigned long long)0xe9f56310u << (m0 & 63u);
                if (4u) continue;
            }
        }
    }
    while (i0++ < 4u && ((unsigned)(short)(6u & (unsigned)(w0 >> 29)) / ((unsigned)e0 | 1u))) { if (--fuel == 0u) goto done;
        h0 = (short)((unsigned)d0 >> (i1 & 31u));
        if ((unsigned)((int)fuel < (int)p2)) break;
    }
    r0.y ^= (unsigned)(((unsigned)(0x80000000u && (unsigned)w0) & 8u) == p0);
    if ((0xffffffffu << ((unsigned)((int)v0 >= (int)0xce63c18cu) & 31u))) goto L2;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        while ((unsigned)(0xf758340au || (r0.y >> (u3 & 31u)))) { if (--fuel == 0u) goto done;
            *q0 += m0;
            if (u0) {
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)b0 < (int)(unsigned)l0), *mp, i0); }
                w0 = w0 * 6364136223846793005ull + (unsigned)((short)(unsigned)f0 > (signed char)(i1 ^ m0));
                if ((unsigned)!((0x10000u >> (0x65a1dc37u & 31u)) & (unsigned)b0)) break;
            } else {
                if ((unsigned)(unsigned char)(p1 & 0x7fffffffu)) goto L2;
            }
            break; (void)((g0 >> (0x2cbe0260u & 31u)));
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)c1, (r0.x + (unsigned)f0), (unsigned)((unsigned)(w0 >> 29) && (unsigned)e0)); }
            if ((unsigned)((int)(unsigned)f0 >= (int)(unsigned)((unsigned)f0 < (unsigned)b0))) break;
            if ((unsigned)h1) break;
        }
    }
    if ((r0.x >> (0x8a2e4c24u & 31u))) goto L2;
    if (((p1 << (6u & 31u)) % ((unsigned)h1 | 1u))) {
        garr[(0x80000000u >> (0x10000u & 31u)) & 7u] = (unsigned)d0;
        if ((unsigned)((int)i0 < (int)(unsigned)s1)) goto L0;
        g1 += ((unsigned)((int)(unsigned)((short)(unsigned)d0 > (signed char)0xffffffffu) >= (int)0x80000000u) * v0);
    }
    goto L2;
    *mp = r0.y;
    if ((g1 / ((unsigned)(2u || (unsigned)h1) | 1u))) goto L3;
    goto L3;
    s1 = (int)((unsigned)s1 + ((unsigned)((unsigned)f0 < a0[i0 & 3u]) % (garr[u2 & 7u] | 1u)));
    u3 = u3 * 0x9e3779b1u + ((unsigned)(unsigned char)((unsigned)s1 | 0x969072e0u) << ((a0[u1 & 3u] % ((unsigned)c0 | 1u)) & 31u));
    l0 = (long)((unsigned long)l0 + ((6u & 0x8cab0672u) | (unsigned)s0));
    s1 = (int)((unsigned)s1 + ((unsigned)(i2 || 0x380bff1cu) * (unsigned)x0));
    do { if (--fuel == 0u) goto done;
        b0 = (unsigned)(unsigned char)(unsigned)((int)g0 < (int)((unsigned)!(u1 & (unsigned)l0) / ((unsigned)(signed char)(0xd858883cu >> (g0 & 31u)) | 1u))) != 0u;
        if (budget != 0u) { budget -= 1u; u0 = fn3((i0 << ((unsigned)((short)0x5fad011cu > (signed char)(unsigned)b0) & 31u)), (((unsigned)(x0 >> 70) & 0x881c58d9u) * (unsigned)c1), (unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)s1)); }
    } while (i0++ < 5u && (unsigned)((short)garr[u2 & 7u] > (signed char)0x6ea1d27bu));
    switch ((unsigned)(v0 || (unsigned)(8u < (unsigned)x0)) & 7u) {
        if ((unsigned)((int)i0 >= (int)(unsigned)((unsigned)d0 < (unsigned)h1))) goto L4;
        break; (void)((unsigned)((int)(unsigned)((short)u1 > (signed char)i1) >= (int)i2));
        l0 = (long)((unsigned long)l0 + (unsigned)((int)(0xa15ad05au ^ *mp) < (int)(unsigned)l0));
        u2 = ((unsigned)e0 ^ (unsigned)((unsigned)(0xd41b382u || (unsigned)(x0 >> 70)) || p0));
    }
    if ((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)(u2 == *q0))) {
        if ((unsigned)(short)(unsigned)(u0 || 0x10000u)) goto L3;
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(6u & 1023u);
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)(unsigned)(0xffffffffu || 0xd41845du), (i0 - 2u), (v0 | (unsigned)((unsigned)b0 == 0x187ac878u))); }
            if ((r0.y - g1)) break;
        }
        switch (0x7fffffffu & 7u) {
            f0 = f0 * 0.5f + (float)((unsigned)c0 & 255u);
            u0 ^= 0x43561979u;
        }
        if ((unsigned)f0) {
            goto L0;
            e0 = e0 * 0.5L + (long double)((unsigned)s1 & 1023u);
            if ((unsigned)!(5u / ((0x2dc6fa09u % (p1 | 1u)) | 1u))) goto L0;
            s0 = (int)(0xb9eec292u & u1);
            g1 += (unsigned)b0;
            if ((unsigned)((int)(unsigned)x0 < (int)a0[u1 & 3u])) {
                if ((0x88c527feu ^ 6u)) goto L0;
                if (0x7fffffffu) goto done;
                g0 = (unsigned)(((unsigned)((int)0x80000000u < (int)p1) & g0) == (p0 << (r0.x & 31u)));
                i1 = ((unsigned)!(u0 ^ (unsigned)s0) ^ (a0[u1 & 3u] ? u1 : (unsigned)h1)) & 15u;
            }
        } else {
            c1 = (signed char)(0xffffffffu * (0x6ed1cb40u << (((unsigned)(0x1b5be14fu && 0xb167712au) ^ 0x10000u) & 31u)));
            if (v0) {
                { unsigned t2; double z2; if ((((unsigned)w0 << ((unsigned)((int)0u < (int)u1) & 31u))) & 1u) { t2 = (unsigned)s1; z2 = (double)((0x91c73463u) & 255u); } if ((((unsigned)w0 << ((unsigned)((int)0u < (int)u1) & 31u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    goto L2;
                    if (budget != 0u) { budget -= 1u; u1 = fn3(*q0, 0x7fffffffu, ((unsigned)!((unsigned)c1 % (i0 | 1u)) & (unsigned)(w0 >> 29))); }
                    if (i0) goto L2;
                    d0 = d0 * 0.5 + (double)((0xffffffffu ? (-(unsigned)((short)u0 > (signed char)i2) / (p1 | 1u)) : 0xffffffffu) & 1023u);
                    *q0 += (unsigned)(0x10000u == fuel);
                }
                u2 = ((unsigned)(unsigned char)(g1 >> (p0 & 31u)) % (p2 | 1u));
                while (i0++ < 7u && 6u) { if (--fuel == 0u) goto done;
                    if (((i2 | (unsigned)s0) * p2)) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)((p0 << (6u & 31u)) >> (0x3e9abad1u & 31u)), (unsigned)(signed char)((unsigned)x0 + (unsigned)c1), v0); }
                    u0 ^= v0;
                    if ((unsigned)((0x7fffffffu - (unsigned)c0) || 0xffffffffu)) continue;
                    { unsigned t3; double z3; if (((7u * a0[i0 & 3u])) & 1u) { t3 = (unsigned)((unsigned)s0 || i1); z3 = (double)(((unsigned)(short)((unsigned)((int)p1 < (int)(unsigned)e0) ^ (unsigned)c1)) & 255u); } if (((7u * a0[i0 & 3u])) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                        if ((3u ^ garr[i1 & 7u])) goto done;
                        break; (void)((0x109a46acu / ((unsigned)h1 | 1u)));
                        v0 = (unsigned)((int)(unsigned)(((unsigned)x0 / (2u | 1u)) < (unsigned)c1) < (int)p0);
                        garr[-(unsigned)((unsigned)s1 == u3) & 7u] = (unsigned)(-(0u & i2) || ((unsigned)(x0 >> 70) >> (((unsigned)c0 & g1) & 31u)));
                        f0 = f0 * 0.5f + (float)(((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)x0) << (g0 & 31u)) & 255u);
                        do { if (--fuel == 0u) goto done;
                            if (i2) break;
                            b0 = ((unsigned)l0 * g1) != 0u;
                            *mp = (unsigned)(((unsigned)((int)0x8c74408du >= (int)a0[u1 & 3u]) + 0x16d51c77u) == (unsigned)(9u < 0xd9387c1au));
                        } while (i1++ < 2u && (unsigned)l0);
                    }
                }
                while (i0++ < 5u && (unsigned)(fuel < u0)) { if (--fuel == 0u) goto done;
                    if (6u) break;
                    u3 += (unsigned)(3u && (unsigned)f0);
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)(*q0 | 0x80000000u), (unsigned)!((unsigned)b0 - a0[i0 & 3u]), i0); }
                    break; (void)((unsigned)((unsigned)s0 == (unsigned)x0));
                    garr[(unsigned)c1 & 7u] = ((unsigned)l0 + (unsigned)((unsigned)(x0 >> 70) == garr[i1 & 7u]));
                }
                goto L1;
            }
            if ((p1 / (*q0 | 1u))) goto L4;
            if (((unsigned)(w0 >> 29) + (unsigned)(signed char)(unsigned)((int)m0 >= (int)i1))) goto L0;
        }
        if ((((unsigned)l0 ^ (unsigned)c0) * p1)) {
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(short)(((unsigned)w0 & 0xdf67d672u) - 0u)) break;
                if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)b0 << ((unsigned)((unsigned)w0 < 6u) & 31u)), 0x28338118u, (unsigned)((short)0x10000u > (signed char)0x38dd9d25u)); }
                s0 = (int)(unsigned)(0x7fffffffu && *q0);
            } while (i0++ < 5u && (0xca959443u / (v0 | 1u)));
            if (0x80000000u) {
                if ((8u ? 7u : 0u)) goto L4;
                if ((unsigned)(g1 || 0u)) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn3(p1, (unsigned)((short)((unsigned)f0 - (unsigned)s0) > (signed char)r0.y), ((unsigned)d0 % (g1 | 1u))); }
                if ((unsigned)(p1 == 5u)) goto done;
            }
        }
        u0 = ((unsigned)!(unsigned)((short)0x6b21a16u > (signed char)u3) & (unsigned)(w0 >> 29));
    }
    goto L1;
    if (((unsigned)(w0 >> 29) + (unsigned)((unsigned)x0 || 0x2df3ba1au))) {
        while (i0++ < 2u && (0x1cd1ae2eu ^ (unsigned)(u0 < a0[u1 & 3u]))) { if (--fuel == 0u) goto done;
            if ((garr[u2 & 7u] >> (0x80000000u & 31u))) continue;
            s1 = (int)((unsigned)s1 + g0);
            if ((6u << (((unsigned)(x0 >> 70) + (unsigned)d0) & 31u))) goto L0;
        }
        if (u3 == 7u) return (unsigned)((int)(unsigned)h0 >= (int)((unsigned)b0 % ((r0.x % (*q0 | 1u)) | 1u)));
        s1 = (int)((unsigned)s1 + ((unsigned)h1 ^ garr[i1 & 7u]));
        d0 = d0 * 0.5 + (double)((unsigned)((short)u1 > (signed char)(unsigned)((unsigned)w0 == 8u)) & 1023u);
        a0[(unsigned)(i1 || u2) & 3u] = 0xe0a5f879u;
        f0 = f0 * 0.5f + (float)((unsigned)((int)u3 < (int)*q0) & 255u);
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)((int)(unsigned)((short)a0[i0 & 3u] > (signed char)g1) < (int)(unsigned)d0) & 7u) {
            h0 = (short)i2;
            h0 = (short)(garr[i1 & 7u] - (0xe9dbf2feu ^ (unsigned)(r0.x < (unsigned)!(unsigned)(0x13d5f521u == *q0))));
        }
        x0 = x0 * 0x100000001b3ull + (g0 ^ (unsigned)((unsigned)!(8u << ((unsigned)s0 & 31u)) && (unsigned)(8u < p0)));
    }
    i1 = (unsigned)f0 & 15u;
    if (budget != 0u) { budget -= 1u; u0 = fn3((0xffffffffu + 0x1ff7bb69u), *mp, (p1 & a0[u1 & 3u])); }
    a0[0xffffffffu & 3u] = 4u;
    if ((unsigned)d0) {
        if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)s0, (unsigned)(r0.y || a0[u1 & 3u]), (unsigned)(short)(5u >> (a0[u1 & 3u] & 31u))); }
        garr[(0xffffffffu * 2u) & 7u] = (unsigned)((short)((unsigned)(short)(2u * r0.y) * i1) > (signed char)p2);
        b0 = (u0 & (v0 ? (unsigned)s1 : 5u)) != 0u;
        goto L1;
        if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)(signed char)(unsigned)((unsigned)l0 || g1) * (unsigned)(w0 >> 29)), ~(unsigned)((int)p1 < (int)((unsigned)e0 + 6u)), (unsigned)(m0 == (unsigned)(x0 >> 70))); }
        if ((0xc1bdabd9u ^ a0[u1 & 3u])) goto L2;
    }
    s1 = (int)((unsigned)s1 + ((unsigned)((int)(unsigned)f0 >= (int)0xc571d15fu) >> (((unsigned)c0 & g0) & 31u)));
    h1 = (unsigned short)(h1 + (v0 & (unsigned)(i2 == p2)));
    if ((unsigned)(short)(p1 ^ (unsigned)s1)) {
        c0 = (unsigned char)((unsigned)((int)0x80000000u >= (int)-(unsigned)(9u && a0[u1 & 3u])) & (0x80000000u - u2));
        if (~(unsigned)(r0.x < (unsigned)h1)) goto L2;
        { unsigned t4; double z4; if ((7u) & 1u) { t4 = ((unsigned)(w0 >> 29) >> (((unsigned)e0 + 0x752dcdacu) & 31u)); z4 = (double)(((unsigned)((short)(unsigned)c0 > (signed char)a0[u1 & 3u])) & 255u); } if ((7u) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
            *q0 += ((unsigned)(0xc9beeb0du || (unsigned)(w0 >> 29)) - (unsigned)!(unsigned)(p2 || a0[u1 & 3u]));
            goto L3;
        }
        l0 = (long)((unsigned long)l0 + v0);
        if ((unsigned)(fuel == (unsigned)(garr[i1 & 7u] || garr[u2 & 7u]))) goto L3;
        if (budget != 0u) { budget -= 1u; u1 = fn3(i2, (unsigned)(unsigned char)(unsigned)((int)(unsigned)s0 >= (int)(unsigned)(*q0 && 0x4fb7a527u)), (unsigned)(short)((unsigned)s0 << (0x738153c8u & 31u))); }
    }
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn2(*q0, (unsigned)((short)(unsigned)l0 > (signed char)(0x1e0b9ff4u << (2u & 31u))), (unsigned)((i0 >> (0x80000000u & 31u)) && 0xffffffffu)); }
        while (i1++ < 3u && (unsigned)(3u < (unsigned)((int)a0[u1 & 3u] < (int)0xe0c34969u))) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn1(i2, ((u3 % (4u | 1u)) % (i0 | 1u)), (unsigned)((int)m0 < (int)(0x10000u & (unsigned)(w0 >> 29)))); }
            d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)((0x66e11dfcu ^ i2) && u3) > (signed char)5u) & 1023u);
        }
        w0 ^= (unsigned long long)fuel << ((unsigned)(r0.x && (v0 ? (g0 + i1) : r0.y)) & 63u);
    } while (i0++ < 5u && (garr[u2 & 7u] >> ((unsigned)c1 & 31u)));
    while (i0++ < 2u && ((unsigned)d0 + 8u)) { if (--fuel == 0u) goto done;
        continue; (void)((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)((unsigned)c1 == 7u)));
        do { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if (((unsigned)(garr[u2 & 7u] < (unsigned)e0) >> ((unsigned)b0 & 31u))) break;
                r0.x = ((unsigned)((int)u1 < (int)9u) & (0x602b8e2u % (m0 | 1u)));
                u0 += ((unsigned)w0 - (unsigned)(short)(unsigned)(*q0 || m0));
                continue; (void)(*mp);
                if (budget != 0u) { budget -= 1u; u2 = fn0(i2, 0x768ee361u, (unsigned)((int)p0 >= (int)fuel)); }
            } while (i2++ < 6u && (i0 / (0xf45e3318u | 1u)));
            i1 = ((unsigned)(short)(i1 >> ((unsigned)e0 & 31u)) % ((unsigned)f0 | 1u)) & 15u;
        } while (i1++ < 3u && ((r0.y * 0x640789d6u) % (p1 | 1u)));
        if ((0x7fffffffu ^ r0.y)) {
            if ((unsigned)h1) goto L1;
            if ((unsigned)e0) break;
        } else {
            garr[p2 & 7u] = (unsigned)((unsigned)s1 < ~(unsigned)((unsigned)(r0.x || (unsigned)h0) == ((unsigned)(w0 >> 29) * *q0)));
            if (((unsigned)e0 * (unsigned)f0)) break;
            *q0 += (unsigned)(((u2 * (unsigned)l0) ? 4u : 0xb13b7f2fu) < 0x7fffffffu);
            if ((0x3707b441u | 0x2d607a92u)) break;
        }
        if ((p1 >> (m0 & 31u))) continue;
        if (budget != 0u) { budget -= 1u; u0 = fn0((u3 | u3), (9u / ((unsigned)c0 | 1u)), garr[i1 & 7u]); }
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(unsigned)(-(3u / (0xb602eda1u | 1u)) == (unsigned)s1), (i1 ? p2 : (unsigned)c0), (unsigned)(0x3975ff1eu && i0)); }
    while (i0++ < 7u && (unsigned)(0xffffffffu < (unsigned)(g1 == (unsigned)d0))) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)((unsigned)(((unsigned)h1 << (0xd06dc557u & 31u)) || (0x7b3111d7u ? fuel : 0xd459129bu)) & 1023u);
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0((u3 - 4u), (0xc9433642u + (unsigned)c0), (unsigned)((short)0u > (signed char)a0[u1 & 3u])); }
    if (((unsigned)d0 << (7u & 31u))) {
        u0 ^= (unsigned)(short)(unsigned)(((u2 ^ (unsigned)h1) | g1) && u2);
        h0 = (short)(3u ^ ((unsigned)d0 + (*q0 / ((unsigned)s0 | 1u))));
        s1 = (int)((unsigned)s1 + ((0x7cd0af36u >> (i2 & 31u)) | (unsigned)h0));
        h1 = (unsigned short)(h1 + (unsigned)(~(unsigned)((short)i1 > (signed char)((unsigned)s1 >> (m0 & 31u))) < (0xa0222d12u % (0xb3d715b8u | 1u))));
    } else {
        if ((unsigned)!((unsigned)((unsigned)f0 == (unsigned)h0) & (unsigned)c1)) {
            do { if (--fuel == 0u) goto done;
                u2 += 0u;
                if (budget != 0u) { budget -= 1u; u2 = fn1(0xffffffffu, ((r0.y | (unsigned)c1) % (0xdb26807fu | 1u)), (unsigned)l0); }
                c0 = (unsigned char)(unsigned)((int)(v0 & (unsigned)s0) >= (int)(unsigned)(signed char)(r0.x ^ (unsigned)c0));
                if (0x283c7b10u) break;
            } while (i0++ < 4u && ((unsigned)w0 * (unsigned)!(u1 >> (garr[i1 & 7u] & 31u))));
            switch ((unsigned)!(unsigned)(u1 || *mp) & 7u) {
                q0 = &garr[(unsigned)(signed char)(unsigned)((unsigned)(x0 >> 70) && ((unsigned)s0 >> (m0 & 31u))) & 7u];
                m0 ^= ((unsigned)((int)(unsigned)c1 >= (int)a0[u1 & 3u]) / ((unsigned)((int)0x45d5ee04u < (int)0x80000000u) | 1u));
                case 2u: ;
                *q0 += ((p1 * ((unsigned)h1 | (unsigned)e0)) | m0);
            }
            f0 = f0 * 0.5f + (float)(((u1 & u1) ? r0.y : (garr[i1 & 7u] | fuel)) & 255u);
        } else {
            w0 ^= (unsigned long long)p0 << ((unsigned)(0xffffffffu < (unsigned)x0) & 63u);
            { unsigned t5; double z5; if ((0x62dd59fbu) & 1u) { t5 = (unsigned)c0; z5 = (double)((u0) & 255u); } if ((0x62dd59fbu) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                switch (5u & 7u) {
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)(x0 >> 70) || (unsigned)((int)((unsigned)x0 >> (u2 & 31u)) >= (int)(unsigned)e0)));
                }
                r0.x = (unsigned)(7u && 0x10000u);
                if (fuel) {
                    if ((unsigned)((int)(unsigned)(w0 >> 29) < (int)m0)) goto done;
                    if ((*mp / (0x80000000u | 1u))) goto L3;
                }
            }
            *q0 = (unsigned)(short)(((unsigned)l0 + 0x10000u) ? (6u % (0x10000u | 1u)) : (unsigned)(x0 >> 70));
        }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((0xffffffffu * p2), (unsigned)((int)(unsigned)x0 < (int)(g0 + (unsigned)(x0 >> 70))), (((unsigned)l0 ^ 3u) / (r0.y | 1u))); }
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)e0 < (int)(unsigned)(0xcb9048dbu || 0x7fffffffu));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 6u, 0x7397aa71u, 0x4d33bd52u },
        { 0u, 0x37f2d4d2u, 0xc9bc6d8eu },
        { 14u, 0xc8bd3b6au, 0x6fee8b27u },
        { 8u, 0x31255731u, 0xede90e99u },
        { 9u, 0x283853cu, 0xad2a16b6u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
