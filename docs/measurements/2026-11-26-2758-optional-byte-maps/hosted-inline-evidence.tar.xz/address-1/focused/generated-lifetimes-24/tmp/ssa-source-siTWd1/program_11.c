// test-ssa-source's program of seed 141000434 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x8a1e9ea7u, g1 = 0x69702823u;
static unsigned garr[8] = { 0x1a5c36a9u, 0xd4131e4u, 0x5f5b27b6u, 0x492b97e7u, 0x6adc493cu, 0xe86b7b2cu, 0xb51e289eu, 0x85067f62u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((0xffffffffu ? garr[u2 & 7u] : (unsigned)f0)) goto L4;
    f0 = f0 * 0.5f + (float)(((unsigned)c0 * ((unsigned)s0 - m0)) & 255u);
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        garr[(unsigned)h0 & 7u] = (0xa2aaffc7u & (unsigned)((int)(unsigned)e0 >= (int)p0));
        c1 = (signed char)(9u - p1);
        m0 ^= ((*mp - fuel) << ((unsigned)h0 & 31u));
        *q0 += (unsigned)(short)((0x7307178du | ~((unsigned)h1 * (unsigned)w0)) / (i2 | 1u));
    }
    { unsigned t0; double z0; if (((0xe5b9d19u + 0xbd52612cu)) & 1u) { t0 = (r0.x / (0x7fffffffu | 1u)); z0 = (double)(((u0 - (unsigned)(g1 < 0x10000u))) & 255u); } if (((0xe5b9d19u + 0xbd52612cu)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        do { if (--fuel == 0u) goto done;
            L0: if (--fuel == 0u) goto done;
            if (*q0) goto L1;
            if (((unsigned)c1 + (unsigned)((short)6u > (signed char)u2))) {
                if (((unsigned)f0 - (unsigned)s1)) {
                    if (((unsigned)b0 - (unsigned)w0)) continue;
                    m0 ^= ((0x6389c7f1u % ((unsigned)x0 | 1u)) * (unsigned)((int)(unsigned)((int)(unsigned)w0 >= (int)(unsigned)(x0 >> 70)) < (int)0x80000000u));
                    if ((a0[u1 & 3u] % ((unsigned)c0 | 1u))) break;
                    *mp = (g1 % ((unsigned)h0 | 1u));
                    w0 = w0 * 6364136223846793005ull + (unsigned)l0;
                    w0 = w0 * 6364136223846793005ull + (~((unsigned)h1 >> (0x7701e2cdu & 31u)) + 0x7fffffffu);
                }
            } else {
                if (0xffffffffu) {
                    for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (i1) goto L1;
                        break; (void)(-((unsigned)(*q0 || 0x80000000u) % (g0 | 1u)));
                        L1: if (--fuel == 0u) goto done;
                        goto L2;
                        { unsigned t1; double z1; if ((p2) & 1u) { t1 = (unsigned)s1; z1 = (double)(((m0 + (unsigned)((unsigned)(w0 >> 29) && i2))) & 255u); } if ((p2) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                            g1 += ((0x9e0a3e87u << (r0.y & 31u)) & a0[u1 & 3u]);
                            if ((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)s0)) break;
                            *q0 = (0xffffffffu * (7u % (0x8cd5712du | 1u)));
                            if ((unsigned)((unsigned)h1 == u3)) break;
                        }
                    }
                }
                { unsigned t2; double z2; if (((unsigned)(signed char)(unsigned)((unsigned)b0 < 0xafa9a835u)) & 1u) { t2 = u1; z2 = (double)(((unsigned)((unsigned)(w0 >> 29) == (unsigned)s0)) & 255u); } if (((unsigned)(signed char)(unsigned)((unsigned)b0 < 0xafa9a835u)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    i1 = v0 & 15u;
                    if (((unsigned)((unsigned)c1 == (unsigned)f0) << (garr[i1 & 7u] & 31u))) continue;
                    L2: if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                    if (((3u - 1u) << (u1 & 31u))) goto L2;
                    if ((unsigned)((unsigned)c0 == u3)) break;
                }
                L4: if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)(0x1a134cc2u == (unsigned)w0) == a0[i0 & 3u])) goto L1;
            }
            w0 ^= (unsigned long long)((unsigned)c1 / (0x10000u | 1u)) << ((unsigned)x0 & 63u);
        } while (i0++ < 6u && (unsigned)((p2 ^ 0x7fffffffu) < 6u));
        f0 = f0 * 0.5f + (float)((unsigned)(short)((0x80000000u ? (unsigned)s1 : 0u) * g0) & 255u);
    }
    while (((u3 ^ 0x80000000u) * i2)) { if (--fuel == 0u) goto done;
        if (((unsigned)l0 & p1)) break;
        switch ((0x7fffffffu % (r0.x | 1u)) & 7u) {
            while (i1++ < 7u && (garr[i1 & 7u] * 0xffffffffu)) { if (--fuel == 0u) goto done;
                case 4u: ;
                m0 ^= (unsigned)((unsigned)((int)(unsigned)((short)(unsigned)l0 > (signed char)i1) < (int)p1) == 0x2d60f9dcu);
                *q0 += 0x80000000u;
                g1 += (unsigned)((unsigned)d0 && (unsigned)h1);
                do { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)((int)0xae91ce9du < (int)i0));
                    w0 = w0 * 6364136223846793005ull + 4u;
                } while (i2++ < 6u && (3u % (0xce20937au | 1u)));
            }
            { unsigned t3; double z3; if (((0xba295a67u << ((2u - 0xe3da5767u) & 31u))) & 1u) { t3 = (unsigned)d0; z3 = (double)((((8u ^ p1) * 0x80000000u)) & 255u); } if (((0xba295a67u << ((2u - 0xe3da5767u) & 31u))) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                break; (void)(0x77fee63bu);
                if (((unsigned)e0 / (0x10000u | 1u))) {
                    u3 = u1;
                    b0 = 0x8eb7280u != 0u;
                    do { if (--fuel == 0u) goto done;
                        break; (void)((0xffffffffu + 6u));
                    } while (i1++ < 3u && (0x96e81c2au ^ p0));
                    garr[(unsigned)((short)6u > (signed char)i0) & 7u] = (unsigned)((int)g0 < (int)(unsigned)((unsigned)(short)(0x7fffffffu | 0x3ec962deu) || 8u));
                    if ((0x10000u + (p0 | (unsigned)c1))) continue;
                    w0 = w0 * 6364136223846793005ull + (2u & 0x55bf59afu);
                }
                goto L3;
                case 2u: ;
            }
            d0 = d0 * 0.5 + (double)((unsigned)(short)((unsigned)((unsigned)c0 || (unsigned)c1) % ((0xffffffffu * (unsigned)l0) | 1u)) & 1023u);
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (u3 ^ p0));
                switch ((unsigned)!((unsigned)(*mp < a0[u1 & 3u]) & (unsigned)d0) & 7u) {
                    { unsigned t4; double z4; if (((unsigned)(*mp == (0x36dcd22eu | (unsigned)s1))) & 1u) { t4 = r0.y; z4 = (double)((0xf52398b3u) & 255u); } if (((unsigned)(*mp == (0x36dcd22eu | (unsigned)s1))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                        u1 = u1 * 0x9e3779b1u + (i2 % (u3 | 1u));
                        case 1u: ;
                        for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                            *q0 = 0x10000u;
                            if ((u1 - (0xf3f6a6u + 0x7fffffffu))) continue;
                            h0 = (short)(0x5c1ae815u ^ u2);
                            case 2u: ;
                            g1 += (u0 | a0[i0 & 3u]);
                            v0 = (a0[u1 & 3u] % (((unsigned)w0 >> ((unsigned)c1 & 31u)) | 1u));
                        }
                        case 3u: ;
                    }
                    for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                        continue; (void)((unsigned)(w0 >> 29));
                    }
                    continue; (void)((g1 + r0.x));
                    { unsigned t5; double z5; if (((unsigned)(unsigned char)(i1 << (i0 & 31u))) & 1u) { t5 = (unsigned)(short)(unsigned)((int)(unsigned)h0 >= (int)0xffffffffu); z5 = (double)((((unsigned)((unsigned)e0 < a0[i0 & 3u]) & 0xfcc94254u)) & 255u); } if (((unsigned)(unsigned char)(i1 << (i0 & 31u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                        if ((unsigned)((int)5u < (int)(i0 ^ (unsigned)w0))) continue;
                        if ((unsigned)((unsigned)h0 || (i0 + u1))) break;
                        u1 ^= (unsigned)((unsigned)b0 || 0xffffffffu);
                        m0 ^= ((unsigned)!((unsigned)d0 << (a0[i0 & 3u] & 31u)) & (unsigned)((int)0x10000u < (int)(unsigned)x0));
                    }
                    case 4u: ;
                }
                u2 ^= (((p0 % ((unsigned)f0 | 1u)) % (0x10000u | 1u)) % ((unsigned)((int)(unsigned)e0 < (int)p1) | 1u));
                if (fuel < 8u) return (unsigned)((int)(unsigned)(x0 >> 70) >= (int)(u3 / ((unsigned)(u2 < 4u) | 1u)));
                s0 = (int)~(unsigned)(a0[u1 & 3u] == (unsigned)d0);
                if ((unsigned)((unsigned)(0x7a7283f4u < (unsigned)h1) || 8u)) goto L4;
            }
            c1 = (signed char)4u;
        }
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch (6u & 7u) {
                case 5u: ;
                l0 = (long)((unsigned long)l0 + ((unsigned)((int)(8u << (a0[u1 & 3u] & 31u)) < (int)(unsigned)c1) + ((unsigned)e0 * r0.x)));
                h1 = (unsigned short)(h1 + (unsigned)(0xe0a3e899u || i1));
            }
            do { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((fuel >> ((unsigned)(unsigned char)((unsigned)(unsigned char)((unsigned)c1 << (5u & 31u)) | (unsigned)s1) & 31u)) & 1023u);
                if (0x468129f7u) break;
                i0 = (unsigned)(5u && (a0[u1 & 3u] % (0xb0c67d9cu | 1u))) & 15u;
            } while (i2++ < 5u && (1u | (unsigned)s1));
            g1 += (unsigned)(short)(unsigned)((short)(unsigned)(*q0 || p2) > (signed char)a0[u1 & 3u]);
            break; (void)((unsigned)(r0.y == *q0));
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(0xf6b41bc6u < (unsigned)(p0 == p1))) goto L2;
                e0 = e0 * 0.5L + (long double)(garr[i1 & 7u] & 1023u);
                garr[(unsigned)s0 & 7u] = ((unsigned)((int)(unsigned)f0 >= (int)0x80000000u) - (unsigned)((int)r0.y < (int)(unsigned)(0x3873ba9du && 0xf43776f5u)));
                if ((unsigned)(i2 || garr[u2 & 7u])) {
                    break; (void)((p0 >> ((unsigned)f0 & 31u)));
                    goto L2;
                }
            }
            while (i2++ < 3u && (0x80000000u + garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                if (((unsigned)s1 >> (0u & 31u))) {
                    break; (void)((unsigned)c0);
                    r0.x = (unsigned)((0u % ((unsigned)w0 | 1u)) && (unsigned)(short)(unsigned)((unsigned)c0 < (unsigned)(short)(0xc46af3bfu | (unsigned)(x0 >> 70))));
                    b0 = (unsigned)c0 != 0u;
                    r0.x = ((unsigned)((int)(0xffffffffu | garr[i1 & 7u]) < (int)i1) + 2u);
                    c1 = (signed char)(unsigned)(signed char)(u2 | i0);
                }
            }
        }
    }
    if (~(unsigned)(0xffffffffu == (unsigned)(0x2033125u == p1))) goto L4;
    if ((g0 % ((unsigned)(0xffffffffu < a0[u1 & 3u]) | 1u))) {
        if ((unsigned)((int)(unsigned)f0 < (int)(unsigned)x0)) {
            if ((unsigned)((unsigned)s0 < (unsigned)h0)) goto done;
            r0.x = (unsigned)(0xbca35293u == (a0[u1 & 3u] + u0));
            g1 += (unsigned)((short)(i2 * (unsigned)(w0 >> 29)) > (signed char)((unsigned)h0 ^ u1));
            e0 = e0 * 0.5L + (long double)((unsigned)((v0 << (u2 & 31u)) || g0) & 1023u);
            if ((unsigned)(0x7fffffffu == (unsigned)e0)) {
                d0 = d0 * 0.5 + (double)((unsigned)(garr[i1 & 7u] == ((p2 - (unsigned)(g0 < 0x10000u)) / (garr[u2 & 7u] | 1u))) & 1023u);
                l0 = (long)((unsigned long)l0 + (g0 >> ((unsigned)(unsigned char)(i2 << ((unsigned)l0 & 31u)) & 31u)));
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)p2 > (signed char)(unsigned)s0)) break;
                    if (((unsigned)b0 ^ 0x7fffffffu)) break;
                    l0 = (long)((unsigned long)l0 + (*q0 % (garr[i1 & 7u] | 1u)));
                    if (0x2181d83u) continue;
                    while (i1++ < 6u && (0x10000u | a0[u1 & 3u])) { if (--fuel == 0u) goto done;
                        if (g0) break;
                        l0 = (long)((unsigned long)l0 + (unsigned)(a0[u1 & 3u] || fuel));
                        u2 = u2 * 0x9e3779b1u + (unsigned)h1;
                        goto L0;
                        break; (void)(8u);
                    }
                    h1 = (unsigned short)(h1 + (unsigned)(v0 < ~(unsigned)(0x80000000u < i2)));
                } while (i0++ < 7u && (unsigned)!(unsigned)((short)(unsigned)((unsigned)b0 < (unsigned)(w0 >> 29)) > (signed char)garr[u2 & 7u]));
                if ((unsigned)((int)(unsigned)((unsigned)s0 && (unsigned)h1) >= (int)0xf4cabc3du)) goto L3;
                g1 += ((unsigned)(i0 < 7u) / (~(unsigned)((short)(unsigned)c1 > (signed char)1u) | 1u));
                goto L3;
            } else {
                goto L3;
                f0 = f0 * 0.5f + (float)((((unsigned)f0 * (0x385682dfu | 3u)) & (unsigned)((int)0x10000u >= (int)i1)) & 255u);
                if (u3 == 7u) return (unsigned)s1;
                s1 = (int)((unsigned)s1 + (unsigned)((int)0xe84b3167u < (int)p1));
            }
            do { if (--fuel == 0u) goto done;
                u1 = (unsigned)!((9u / ((unsigned)c0 | 1u)) % ((*mp << (((unsigned)(x0 >> 70) ^ (unsigned)s0) & 31u)) | 1u));
                break; (void)(*mp);
            } while (i0++ < 2u && ((unsigned)e0 + (unsigned)c0));
        }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(*q0);
            s1 = (int)((unsigned)s1 + (0xffffffffu | u3));
            if ((garr[u2 & 7u] << (0x425d5084u & 31u))) goto L0;
            if ((u1 % (m0 | 1u))) break;
            if ((1u % ((g1 & 7u) | 1u))) break;
            while (i1++ < 7u && 0xc343bb9eu) { if (--fuel == 0u) goto done;
                if (fuel) continue;
                if (p0) continue;
            }
        }
        if ((4u & (unsigned)((int)(unsigned)h1 < (int)(unsigned)h0))) {
            if ((0x7fffffffu + (unsigned)(i2 || (unsigned)d0))) goto L4;
            m0 ^= (u0 | u0);
            if (((unsigned)(0x14e61426u == (unsigned)s0) >> (r0.x & 31u))) goto L3;
            goto L1;
        } else {
            if ((unsigned)f0) goto L2;
            goto done;
            switch (*mp & 7u) {
                for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    c1 = (signed char)r0.y;
                    d0 = d0 * 0.5 + (double)(((unsigned)((int)-(unsigned)((int)6u >= (int)0xffffffffu) < (int)~(unsigned)((unsigned)w0 == (unsigned)d0)) - p1) & 1023u);
                }
                h1 = (unsigned short)(h1 + (unsigned)((int)0x80000000u >= (int)g1));
                if (u3 == 7u) return (i1 / (6u | 1u));
                if (fuel < 8u) return (unsigned)((((5u & 9u) - 0x80000000u) << ((unsigned)c1 & 31u)) || (unsigned)f0);
            }
        }
    }
    if (0x10000u) goto done;
    if ((unsigned)l0) goto L3;
    do { if (--fuel == 0u) goto done;
        *q0 = (unsigned)((int)(((unsigned)s1 - g0) << (p0 & 31u)) >= (int)(unsigned)((short)0xc46b9962u > (signed char)p1));
        while ((0x89e5e392u * 0x10000u)) { if (--fuel == 0u) goto done;
            c1 = (signed char)~(0xedb49d12u | (unsigned)((7u ^ g1) && i1));
        }
        if ((unsigned)((int)0xddb466fu < (int)5u)) break;
        s1 = (int)((unsigned)s1 + (((unsigned)b0 & p1) * (unsigned)(0x5d4637fdu < u1)));
        { unsigned t6; double z6; if (((0x10000u / ((unsigned)f0 | 1u))) & 1u) { t6 = *mp; z6 = (double)((0xac0acca9u) & 255u); } if (((0x10000u / ((unsigned)f0 | 1u))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
            u1 = (unsigned)!(((unsigned)c1 & 0x84a48222u) & 0xffffffffu);
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(0xffffffffu);
            }
        }
    } while (i0++ < 5u && 0xa98f9d56u);
    goto done;
    u0 = u0 * 0x9e3779b1u + -(0x10000u & (8u * (unsigned)h0));
    do { if (--fuel == 0u) goto done;
        if (g0) break;
        m0 ^= (unsigned)(short)(unsigned)(9u < (g1 >> ((unsigned)((int)garr[i1 & 7u] < (int)g0) & 31u)));
    } while (i0++ < 3u && (unsigned)((short)g1 > (signed char)~(unsigned)(garr[i1 & 7u] || 0x10000u)));
    garr[p1 & 7u] = (unsigned)h1;
    if (0x13f9dc0cu) goto L4;
    u2 += (unsigned)!(a0[i0 & 3u] / (p0 | 1u));
    while (i0++ < 3u && ((unsigned)x0 ^ ((unsigned)s1 + (unsigned)x0))) { if (--fuel == 0u) goto done;
        continue; (void)(((unsigned)b0 | (unsigned)s1));
        switch ((unsigned)((int)*q0 >= (int)1u) & 7u) {
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                goto L0;
                garr[2u & 7u] = (unsigned)((6u ? (unsigned)s0 : m0) || (unsigned)(w0 >> 29));
                if ((unsigned)(0x7fffffffu == (unsigned)(garr[i1 & 7u] && (unsigned)b0))) break;
                i0 = (unsigned)((short)(unsigned)(0x80000000u == a0[u1 & 3u]) > (signed char)(9u << (4u & 31u))) & 15u;
            }
            if (((unsigned)x0 * garr[u2 & 7u])) {
                case 5u: ;
                b0 = (0x10000u | (garr[u2 & 7u] / (9u | 1u))) != 0u;
                g0 = 0xce660da6u;
                case 2u: ;
                goto L3;
                case 0u: ;
            }
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                u0 ^= ((unsigned)(short)(unsigned)((short)(unsigned)w0 > (signed char)(unsigned)((int)u3 < (int)g1)) * 0x10000u);
                if (0x80000000u) {
                    switch (r0.y & 7u) {
                        case 6u: ;
                        case 7u: ;
                        *mp = (unsigned)((short)(unsigned)((short)(unsigned)(0xffffffffu && r0.x) > (signed char)(unsigned)((unsigned)c0 && 0x6dbb6b66u)) > (signed char)p1);
                        u2 = u2 * 0x9e3779b1u + 0xd1d20569u;
                        case 0u: ;
                        break; (void)(r0.y);
                    }
                    *mp = (unsigned)((unsigned)s0 || (0x7fffffffu & r0.y));
                    h0 = (short)u0;
                    if ((unsigned)!(unsigned)(a0[u1 & 3u] || (unsigned)h0)) goto done;
                    w0 ^= (unsigned long long)0x32d725ffu << ((unsigned)((short)r0.x > (signed char)(unsigned)(short)(0x7fffffffu * ((unsigned)(i2 == a0[i0 & 3u]) << (0x75dced54u & 31u)))) & 63u);
                } else {
                    if (((unsigned)b0 >> (u2 & 31u))) break;
                    e0 = e0 * 0.5L + (long double)((garr[u2 & 7u] << (((unsigned)((int)(unsigned)c0 < (int)i2) | 0x467463feu) & 31u)) & 1023u);
                    r0.y ^= (*mp & (unsigned)(*q0 == 0x80000000u));
                }
                default: ;
                q0 = &garr[(0x7fffffffu >> (0x352bbbb0u & 31u)) & 7u];
            }
            break;
        }
        switch ((0x10000u >> ((m0 / ((unsigned)e0 | 1u)) & 31u)) & 7u) {
            while (i1++ < 6u && ((unsigned)d0 - 0xb9b660e3u)) { if (--fuel == 0u) goto done;
                case 3u: ;
                continue; (void)((unsigned)(short)((unsigned)h1 ^ (0x10000u - 0x7854ae5cu)));
                if ((unsigned)c0) goto L2;
                q0 = &garr[(~(unsigned)((int)(unsigned)l0 >= (int)(unsigned)!(unsigned)((int)0x5b74f3bfu >= (int)(unsigned)c0)) % (((unsigned)f0 ^ u0) | 1u)) & 7u];
                m0 ^= (~(unsigned)(0x10000u == (i2 >> ((unsigned)l0 & 31u))) << (0x8deacbacu & 31u));
                g0 = (g0 & (unsigned)((int)(unsigned)b0 >= (int)0x91a04505u));
            }
            u3 += (((unsigned)((int)i0 >= (int)p1) | a0[i0 & 3u]) - (unsigned)(w0 >> 29));
            if ((unsigned)((unsigned)(unsigned char)(r0.y % ((unsigned)s0 | 1u)) < 0x79409bdbu)) break;
            case 1u: ;
            u2 = (unsigned)h1;
        }
        while (i1++ < 7u && (u2 << (0x77abed3eu & 31u))) { if (--fuel == 0u) goto done;
            h0 = (short)0x7ce6c44eu;
            if (r0.y) break;
            if (u3 == 7u) return -(unsigned)(((unsigned)((short)0x1bc7890cu > (signed char)0xc3d4e334u) & i0) && (unsigned)(w0 >> 29));
            if (4u) {
                u3 = u3 * 0x9e3779b1u + ((0x4bf0336bu - a0[u1 & 3u]) >> ((u0 - (i0 | (unsigned)d0)) & 31u));
                *q0 = 1u;
                if ((unsigned)h1) break;
            } else {
                r0.x = ((unsigned)!(unsigned)(g0 && (p1 & (unsigned)h1)) << (g1 & 31u));
                s1 = (int)((unsigned)s1 + ((0x10000u * (unsigned)(0x66b519c8u && (i1 + (unsigned)h1))) / (u1 | 1u)));
                d0 = d0 * 0.5 + (double)((((unsigned)((int)(unsigned)s1 < (int)p2) & (unsigned)(*mp && 0xe86cc18u)) | 0x80000000u) & 1023u);
            }
            w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)c0 < (int)(unsigned)x0);
            break; (void)((unsigned)((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)f0) && a0[u1 & 3u]));
        }
        switch ((unsigned)((unsigned)e0 || 0x7fffffffu) & 7u) {
            g0 = (((unsigned)e0 % ((0x7fffffffu % (*q0 | 1u)) | 1u)) + (unsigned)(i1 < u0));
            case 2u: ;
            v0 = (unsigned)!(unsigned)((short)p0 > (signed char)0x80000000u);
            if ((i0 | garr[u2 & 7u])) goto L2;
            switch ((p0 ^ a0[u1 & 3u]) & 7u) {
                s0 = (int)~(((unsigned)((int)u3 < (int)a0[i0 & 3u]) - (unsigned)x0) + (unsigned)e0);
                case 6u: ;
                if ((unsigned)(g0 || (unsigned)(0x7fffffffu && 3u))) break;
                u3 = u1;
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)s1) && g0);
                case 2u: ;
            }
            v0 = (3u >> (a0[i0 & 3u] & 31u));
        }
        if (((unsigned)((int)6u < (int)0x242088cdu) ^ garr[i1 & 7u])) goto done;
    }
    if ((unsigned)(w0 >> 29)) goto L1;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((7u & ((unsigned)h0 / (r0.x | 1u)))) break;
        if ((unsigned)h1) break;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((0x6ddb539du * ((unsigned)x0 / (i1 | 1u)))) break;
            r0.x = (unsigned)(r0.y || 9u);
            if ((unsigned)(short)((unsigned)h1 % (9u | 1u))) break;
            switch (((unsigned)x0 & (u3 >> (r0.y & 31u))) & 7u) {
                m0 ^= (((unsigned)b0 >> (*mp & 31u)) * 0xffffffffu);
                q0 = &garr[(unsigned)((g1 ^ *mp) && 0xb7fae394u) & 7u];
                if (((unsigned)h0 >> (p0 & 31u))) {
                    case 2u: ;
                    garr[(4u & 0x3fbab719u) & 7u] = (unsigned)(unsigned char)(0x7fffffffu / ((unsigned)(short)(unsigned)((int)u1 < (int)g0) | 1u));
                    s0 = (int)(unsigned)(signed char)(0xf5515531u ^ (unsigned)h0);
                    switch ((0x4a4e9605u >> ((unsigned)c0 & 31u)) & 7u) {
                        f0 = f0 * 0.5f + (float)((garr[u2 & 7u] - (0x7fffffffu << (0x10000u & 31u))) & 255u);
                        w0 = w0 * 6364136223846793005ull + u0;
                        h1 = (unsigned short)(h1 + ((garr[u2 & 7u] * ((r0.y >> ((unsigned)h0 & 31u)) ^ 0x7fffffffu)) % (0x7fffffffu | 1u)));
                        m0 ^= (unsigned)(garr[i1 & 7u] || u3);
                        case 6u: ;
                        case 4u: ;
                    }
                    continue; (void)(((unsigned)c0 ^ ((unsigned)(w0 >> 29) | v0)));
                    if (((unsigned)b0 % ((unsigned)((int)u2 < (int)(unsigned)e0) | 1u))) break;
                }
                goto L3;
                case 4u: ;
            }
            break; (void)(0xc5b8387du);
            if (((g0 << (0x10000u & 31u)) | a0[i0 & 3u])) break;
        }
    }
    if ((unsigned)(signed char)(u3 >> (u3 & 31u))) {
        if (p1) goto done;
        if (((0xac0afa0au + (unsigned)c1) - 0x7fffffffu)) {
            if ((0xcfdd5368u >> (*mp & 31u))) {
                q0 = &garr[(unsigned)((p0 % ((unsigned)e0 | 1u)) && (unsigned)((unsigned)(unsigned char)(unsigned)((short)*q0 > (signed char)(unsigned)c0) || a0[i0 & 3u])) & 7u];
                a0[(unsigned)(short)(unsigned)((unsigned)s1 || 1u) & 3u] = (unsigned)((unsigned)((garr[i1 & 7u] - (unsigned)e0) && (unsigned)(x0 >> 70)) < u3);
                if (fuel < 8u) return (unsigned)((unsigned)f0 && (u0 + 3u));
                goto L0;
            }
            if (fuel < 8u) return ~(unsigned)((int)0xc766b4fcu >= (int)(unsigned)(0xc562dcd7u == (unsigned)(w0 >> 29)));
            goto L4;
        } else {
            if ((0x9a9905acu | (unsigned)((short)u2 > (signed char)0xffffffffu))) {
                c1 = (signed char)(unsigned)h0;
                u3 ^= ((unsigned)h0 | (unsigned)f0);
                g0 = (unsigned)(signed char)(g1 ^ (unsigned)x0);
                d0 = d0 * 0.5 + (double)((unsigned)(3u || (7u >> (9u & 31u))) & 1023u);
                if ((a0[u1 & 3u] * 0xe8f35426u)) goto L3;
            } else {
                { unsigned t7; double z7; if (((unsigned)d0) & 1u) { t7 = r0.x; z7 = (double)(((((unsigned)c1 % (0x80000000u | 1u)) ^ p1)) & 255u); } if (((unsigned)d0) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                    goto L1;
                    u3 = u3 * 0x9e3779b1u + ((p1 / (i0 | 1u)) | (unsigned)!((unsigned)h1 * (0x38b8e694u - (unsigned)h0)));
                    switch (r0.x & 7u) {
                        i0 = (unsigned)(short)(6u >> ((unsigned)l0 & 31u)) & 15u;
                        if (((unsigned)l0 * i0)) goto L1;
                        r0.x = a0[i0 & 3u];
                        case 5u: ;
                    }
                    s0 = (int)((unsigned)((int)p2 < (int)(unsigned)h1) ^ 0x8bc64409u);
                    g1 += (unsigned)!(unsigned)(0xed79cacu && ((a0[u1 & 3u] | (unsigned)x0) / ((unsigned)h1 | 1u)));
                }
                g0 = (m0 * (9u << (((unsigned)l0 * (unsigned)s0) & 31u)));
                { unsigned t8; double z8; if ((m0) & 1u) { t8 = (unsigned)((int)r0.x >= (int)r0.x); z8 = (double)(((unsigned)(3u < (unsigned)x0)) & 255u); } if ((m0) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                    if (0x80000000u) {
                        if ((i2 * ((unsigned)l0 / (0xa7b56618u | 1u)))) goto L4;
                        while (i0++ < 4u && (unsigned)d0) { if (--fuel == 0u) goto done;
                            if ((unsigned)f0) break;
                            b0 = (u2 % (0x80000000u | 1u)) != 0u;
                        }
                        v0 = (unsigned)((r0.x << (g0 & 31u)) && (unsigned)((short)u0 > (signed char)(unsigned)(unsigned char)(unsigned)((int)0x80000000u < (int)0x15caf07cu)));
                        d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)((short)(unsigned)w0 > (signed char)u0) < (int)u0) & 1023u);
                        if ((a0[u1 & 3u] % (v0 | 1u))) goto L0;
                        goto L1;
                    } else {
                        if (((7u | a0[i0 & 3u]) & (unsigned)c1)) goto done;
                        *q0 = (unsigned)((short)(0x10000u | 1u) > (signed char)0xc3a7a6a9u);
                        if (((unsigned)x0 ? (unsigned)f0 : (unsigned)(w0 >> 29))) goto L0;
                    }
                    g1 += ((unsigned)((int)fuel >= (int)(u2 - 3u)) | (unsigned)h0);
                    s1 = (int)((unsigned)s1 + 0xffffffffu);
                }
            }
            *q0 = (garr[i1 & 7u] ^ i0);
            for (;;) { if (--fuel == 0u) goto done;
                u3 += (unsigned)((0x10000u >> ((unsigned)h0 & 31u)) && (m0 ^ (unsigned)(g1 == p2)));
            }
            { unsigned t9; double z9; if ((u2) & 1u) { t9 = (unsigned)(unsigned char)(0x80000000u / (r0.y | 1u)); z9 = (double)((((unsigned)(x0 >> 70) - (unsigned)(x0 >> 70))) & 255u); } if ((u2) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
                c0 = (unsigned char)(unsigned)((short)(2u % (i1 | 1u)) > (signed char)*mp);
                if (((unsigned)(x0 >> 70) - (unsigned)e0)) goto L0;
                w0 = w0 * 6364136223846793005ull + (((unsigned)s1 ^ ((unsigned)((unsigned)f0 || garr[i1 & 7u]) - (unsigned)c0)) >> (6u & 31u));
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)(0x7fffffffu < 4u)) goto L2;
                }
            }
        }
    }
    d0 = d0 * 0.5 + (double)((((unsigned)((short)((unsigned)h1 + v0) > (signed char)(unsigned)w0) ^ fuel) >> ((unsigned)f0 & 31u)) & 1023u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)!((unsigned)c0 ^ (unsigned)e0)) goto L4;
    r0.x = g1;
    f0 = f0 * 0.5f + (float)((unsigned)e0 & 255u);
    *q0 = m0;
    u2 += (unsigned)((i1 + ((unsigned)e0 ? (unsigned)f0 : (unsigned)e0)) || (unsigned)x0);
    if (budget != 0u) { budget -= 1u; u2 = fn0((((unsigned)l0 * 5u) << ((unsigned)s0 & 31u)), (r0.y - (unsigned)s1), ~((garr[i1 & 7u] * garr[u2 & 7u]) - garr[i1 & 7u])); }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)c0) break;
        d0 = d0 * 0.5 + (double)((unsigned)((short)(unsigned)((int)(unsigned)((short)0x2d06b038u > (signed char)(unsigned)e0) >= (int)(unsigned)((int)3u >= (int)(unsigned)e0)) > (signed char)*q0) & 1023u);
        do { if (--fuel == 0u) goto done;
            s0 = (int)(0x10000u - (0u ? *mp : v0));
        } while (i1++ < 3u && p0);
        do { if (--fuel == 0u) goto done;
            if (v0) continue;
            if (*mp) break;
            if (budget != 0u) { budget -= 1u; u3 = fn0(((*mp >> ((unsigned)d0 & 31u)) ^ (unsigned)s1), ((unsigned)(x0 >> 70) * *q0), (unsigned)(((unsigned)h1 * 0x63cddd0cu) < 2u)); }
            u3 += ((0xa8b05cf3u << (g0 & 31u)) >> ((p1 & m0) & 31u));
            r0.x = (garr[u2 & 7u] ? r0.x : (unsigned)(u0 < *mp));
        } while (i1++ < 3u && (p0 << ((unsigned)c1 & 31u)));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)c1, (unsigned)((unsigned)c1 == i0), (unsigned)w0); }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t0; double z0; if (((unsigned)x0) & 1u) { t0 = 3u; z0 = (double)((r0.x) & 255u); } if (((unsigned)x0) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            v0 = (p2 & (unsigned)c0);
            do { if (--fuel == 0u) goto done;
                if ((p0 | (unsigned)f0)) {
                    m0 ^= ((unsigned)(fuel == (unsigned)l0) * 0x80000000u);
                    L0: if (--fuel == 0u) goto done;
                    *q0 += (unsigned)((int)r0.y < (int)(unsigned)((int)0xffffffffu < (int)(unsigned)((unsigned)s0 && i0)));
                    e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)w0 < (unsigned)x0) & 1023u);
                }
                if ((unsigned)(signed char)(0xffffffffu << (0x7fffffffu & 31u))) continue;
                continue; (void)((unsigned)l0);
            } while (i1++ < 2u && 0xc0860176u);
            *q0 = ((unsigned)((short)~(p2 << (i0 & 31u)) > (signed char)5u) << ((unsigned)d0 & 31u));
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((0x7343db7du % (p2 | 1u)) == (unsigned)s1), (unsigned)(unsigned char)(unsigned)((int)0x80000000u >= (int)2u), (unsigned)((unsigned)(unsigned char)((unsigned)d0 / ((unsigned)e0 | 1u)) == u1)); }
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                u1 = (unsigned)(short)(~(unsigned)((int)(unsigned)(1u || 3u) >= (int)0xa194ae17u) % (g1 | 1u));
            }
            if (0x74b0d81du) break;
        }
        do { if (--fuel == 0u) goto done;
            garr[(unsigned)w0 & 7u] = p1;
            if ((unsigned)(0xfa19bbdau && 0x80000000u)) continue;
        } while (i1++ < 6u && (unsigned)h1);
        if ((unsigned)(((unsigned)(x0 >> 70) >> (u0 & 31u)) || (unsigned)c0)) goto done;
    }
    if (p2) goto L3;
    while (i0++ < 7u && 8u) { if (--fuel == 0u) goto done;
        if (0x10000u) break;
        { unsigned t1; double z1; if ((*q0) & 1u) { t1 = (unsigned)(w0 >> 29); z1 = (double)(((0x80000000u ? (unsigned)c0 : *mp)) & 255u); } if ((*q0) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            continue; (void)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)((unsigned)d0 * (unsigned)b0)));
            if ((unsigned)((unsigned)e0 < (unsigned)b0)) {
                garr[((unsigned)b0 * (unsigned)s1) & 7u] = (((unsigned)d0 - p2) & (unsigned)(short)(8u | (unsigned)(r0.x && u3)));
                if (((unsigned)((short)(unsigned)s0 > (signed char)fuel) ^ (unsigned)(x0 >> 70))) goto L3;
                continue; (void)((unsigned)(short)(fuel * (unsigned)(x0 >> 70)));
                v0 = (u1 + a0[u1 & 3u]);
                if (6u) break;
            } else {
                h1 = (unsigned short)(h1 + (r0.y + (unsigned)(*q0 < 1u)));
                s1 = (int)((unsigned)s1 + (0x7fffffffu | (*q0 * p2)));
                L1: if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + ((unsigned)h0 * (unsigned)((short)0xb5cc3d76u > (signed char)4u));
            }
            L2: if (--fuel == 0u) goto done;
            u0 ^= ((0x6db5f459u | 2u) % ((4u - u3) | 1u));
        }
        continue; (void)((unsigned)(9u || garr[i1 & 7u]));
        break; (void)((unsigned)!(a0[i0 & 3u] - (unsigned)!(0x75237723u & (unsigned)c1)));
        if ((unsigned)(u0 || *mp)) {
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (a0[u1 & 3u]) goto L4;
                r0.x = (unsigned)(((unsigned)w0 / (*q0 | 1u)) < r0.y);
                if ((unsigned)((0x96bc76f7u / (garr[u2 & 7u] | 1u)) < (unsigned)x0)) goto L3;
                c1 = (signed char)(garr[i1 & 7u] % (i2 | 1u));
                a0[((unsigned)h0 / (7u | 1u)) & 3u] = (unsigned)(unsigned char)(a0[u1 & 3u] ^ (unsigned)!(unsigned)(0x80000000u < ((unsigned)h0 ^ (0x7fffffffu + i0))));
                if ((g1 + g1)) break;
            }
            if ((unsigned)(-(0x80000000u / ((unsigned)d0 | 1u)) && 0x609887bcu)) {
                do { if (--fuel == 0u) goto done;
                    *mp = (unsigned)(0x10000u < (unsigned)((int)g1 < (int)0x10000u));
                    h1 = (unsigned short)(h1 + (unsigned)(x0 >> 70));
                    u1 += *q0;
                } while (i1++ < 2u && (unsigned)c1);
            } else {
                if ((garr[u2 & 7u] | ~(unsigned)((unsigned)e0 && (unsigned)x0))) break;
                s0 = (int)(unsigned)(((unsigned)e0 - (i1 ^ (unsigned)h1)) || p1);
            }
            if ((unsigned)!(unsigned)((unsigned)(r0.y && 3u) || p1)) {
                q0 = &garr[(unsigned)((short)a0[u1 & 3u] > (signed char)(unsigned)s0) & 7u];
                L3: if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + -(unsigned)(0x78d4a3c5u && (0x474c76dcu - (unsigned)b0)));
                L4: if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0u && u1), (unsigned)l0, ((0x7fffffffu ^ (unsigned)l0) << ((unsigned)s0 & 31u))); }
                    if (~((unsigned)l0 / (a0[u1 & 3u] | 1u))) break;
                    break; (void)((unsigned)c1);
                } while (i1++ < 3u && (unsigned)w0);
                h0 = (short)(unsigned)((int)r0.x >= (int)(unsigned)((int)*q0 >= (int)p1));
            }
            u3 += -(unsigned)((int)((unsigned)s1 | ((unsigned)b0 * (unsigned)x0)) >= (int)p2);
            v0 = (unsigned)((unsigned)(unsigned char)(0x80000000u / (0x10000u | 1u)) && r0.y);
        } else {
            if (u1) break;
            break; (void)((unsigned)(signed char)(unsigned)(-(unsigned)(1u < 0xde112ec1u) || (unsigned)w0));
            continue; (void)((i0 - (m0 >> (p2 & 31u))));
        }
    }
    if ((0x80000000u << ((unsigned)f0 & 31u))) goto L0;
    h1 = (unsigned short)(h1 + (i0 ? (unsigned)(short)((unsigned)h0 / ((r0.y >> (7u & 31u)) | 1u)) : 0u));
    if ((0xad414c60u >> (u1 & 31u))) goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)((int)0xcfb2ee2bu < (int)i1) ^ 0x9ecd256u), m0, (unsigned)(g0 < 0xf74a42e8u)); }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        continue; (void)((i0 ? 6u : (unsigned)c1));
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            u2 ^= ((0x6472c08bu / (0x7fffffffu | 1u)) + p2);
            i2 = (*q0 ? (unsigned)((short)7u > (signed char)0xffffffffu) : (unsigned)h0) & 15u;
            { unsigned t2; double z2; if ((r0.x) & 1u) { t2 = ((unsigned)!(fuel | 0x392f9eeeu) >> (4u & 31u)); z2 = (double)((((unsigned)(g0 == p0) | *q0)) & 255u); } if ((r0.x) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                s0 = (int)(unsigned)((int)((0x5160907bu + (unsigned)d0) - 0x7a723912u) >= (int)(unsigned)c1);
            }
            if (a0[u1 & 3u]) goto L1;
            r0.x = ((unsigned)(short)(unsigned)((unsigned)f0 < v0) >> ((unsigned)(w0 >> 29) & 31u));
        }
    }
    garr[(unsigned)(x0 >> 70) & 7u] = (unsigned)((int)(unsigned)(0x7fffffffu == i0) < (int)(r0.y - (0x10000u >> (0x80000000u & 31u))));
    do { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)l0 >> ((0u + (unsigned)e0) & 31u)));
        m0 ^= i0;
    } while (i0++ < 3u && u1);
    if ((unsigned)((int)(unsigned)s1 >= (int)((unsigned)h1 | a0[u1 & 3u]))) {
        e0 = e0 * 0.5L + (long double)((unsigned)((a0[u1 & 3u] ? r0.y : (unsigned)(w0 >> 29)) == (unsigned)((int)0x10000u >= (int)(unsigned)c1)) & 1023u);
        while (~(p1 >> ((unsigned)((short)u2 > (signed char)0xffffffffu) & 31u))) { if (--fuel == 0u) goto done;
            if ((r0.x / (((unsigned)s1 % (p1 | 1u)) | 1u))) goto L2;
        }
    }
    { unsigned t3; double z3; if ((((u3 * garr[i1 & 7u]) % (0x8fa71a00u | 1u))) & 1u) { t3 = (unsigned)((int)(unsigned)(0x10000u == *q0) < (int)(unsigned)f0); z3 = (double)(((a0[i0 & 3u] & 0x7fffffffu)) & 255u); } if ((((u3 * garr[i1 & 7u]) % (0x8fa71a00u | 1u))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        while (i0++ < 3u && (unsigned)((int)(0xeb2c15f9u >> (v0 & 31u)) >= (int)g0)) { if (--fuel == 0u) goto done;
            if (((0x23de0bf0u >> (u2 & 31u)) + 0x86182d65u)) break;
            b0 = 0x10000u != 0u;
            if ((g1 + *mp)) continue;
            if (((unsigned)(u3 || i0) & (unsigned)c1)) {
                { unsigned t4; double z4; if ((((unsigned)(short)((unsigned)(w0 >> 29) >> (a0[u1 & 3u] & 31u)) ^ (unsigned)(w0 >> 29))) & 1u) { t4 = (unsigned)(4u && 0xd567050du); z4 = (double)((((p2 | v0) * 2u)) & 255u); } if ((((unsigned)(short)((unsigned)(w0 >> 29) >> (a0[u1 & 3u] & 31u)) ^ (unsigned)(w0 >> 29))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                    w0 = w0 * 6364136223846793005ull + (unsigned)(short)((unsigned)f0 - u1);
                    m0 ^= (((unsigned)h1 ^ i1) & i0);
                }
                do { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (0x316663f9u / (((0x221655c2u % ((unsigned)h1 | 1u)) / ((unsigned)d0 | 1u)) | 1u));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((0x23cdb8d3u * (u2 & (unsigned)x0)), (unsigned)c1, ((unsigned)h0 ^ (unsigned)e0)); }
                    d0 = d0 * 0.5 + (double)(v0 & 1023u);
                } while (i1++ < 6u && (unsigned)((int)(unsigned)(w0 >> 29) < (int)9u));
                if ((v0 | (unsigned)(i1 && r0.y))) {
                    continue; (void)(0xffffffffu);
                }
                if ((unsigned)(0x5a0f6a2cu || a0[i0 & 3u])) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)d0, 0x752fd4d7u, (unsigned)(u3 == -(5u % (0x80000000u | 1u)))); }
                    u3 ^= (u2 / ((unsigned)((int)(unsigned)x0 >= (int)(*q0 - 0x10000u)) | 1u));
                    c0 = (unsigned char)r0.x;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(unsigned)c1 > (signed char)r0.x), (unsigned)((int)(unsigned)c0 >= (int)0x7fffffffu), (unsigned)((int)(unsigned)h0 >= (int)0xf96aec02u)); }
                    if ((unsigned)x0) {
                        if ((unsigned)((int)*q0 < (int)*q0)) continue;
                    }
                    b0 = 9u != 0u;
                }
                h1 = (unsigned short)(h1 + (((unsigned)w0 ^ *q0) << ((v0 ? *q0 : p2) & 31u)));
            } else {
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(p1 || (unsigned)d0), i0, (garr[u2 & 7u] | 0x7fffffffu)); }
                if (((r0.x >> (2u & 31u)) * (unsigned)b0)) break;
                c0 = (unsigned char)(((unsigned)h0 / (0x7fffffffu | 1u)) / (0x4e75db16u | 1u));
            }
        }
        if (r0.y) goto L3;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(garr[i1 & 7u] == 0x80000000u), p0, 3u); }
        *q0 += (0x10000u + (~(unsigned)(g1 && ((unsigned)c1 | 4u)) - (unsigned)b0));
    }
    c1 = (signed char)((unsigned)(fuel == 0x97ff47fbu) | (unsigned)((short)0xffffffffu > (signed char)(unsigned)(i0 < (unsigned)(w0 >> 29))));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 3u && (unsigned)!(garr[i1 & 7u] >> (i0 & 31u))) { if (--fuel == 0u) goto done;
            while (i2++ < 6u && ((v0 | (unsigned)c1) << ((unsigned)(x0 >> 70) & 31u))) { if (--fuel == 0u) goto done;
                break; (void)(0x300e7b20u);
                w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)((unsigned)(unsigned char)((unsigned)h0 * 2u) - ((unsigned)b0 << (0xcd49d39cu & 31u)));
                *q0 = ((unsigned)f0 ^ g0);
                if ((v0 ? *q0 : 0xf1d2fc80u)) break;
                *mp = (((unsigned)(x0 >> 70) | (0xfb57f454u << (p0 & 31u))) / ((unsigned)(x0 >> 70) | 1u));
                if ((a0[i0 & 3u] & (unsigned)c1)) break;
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((r0.x >> ((unsigned)(i0 < 0xffffffffu) & 31u)), ((unsigned)(g1 && 2u) >> ((unsigned)l0 & 31u)), 0xffffffffu); }
        }
        switch (garr[u2 & 7u] & 7u) {
            u0 ^= r0.y;
            case 7u: ;
            if ((2u ? 1u : u0)) goto done;
            case 5u: ;
            if ((unsigned)(4u == a0[i0 & 3u])) continue;
            do { if (--fuel == 0u) goto done;
                u3 = (p2 ? u0 : (unsigned)x0);
                case 3u: ;
                default: ;
                if ((((unsigned)e0 << (garr[i1 & 7u] & 31u)) - *q0)) goto done;
                garr[(unsigned)(v0 || p1) & 7u] = 2u;
            } while (i1++ < 6u && a0[i0 & 3u]);
        }
        if ((unsigned)b0) break;
        break; (void)((unsigned)(short)((unsigned)(r0.x < g0) >> (0x35c2fb14u & 31u)));
    }
    e0 = e0 * 0.5L + (long double)((unsigned)((0xdced214u << ((unsigned)s1 & 31u)) < (unsigned)((int)(unsigned)(x0 >> 70) < (int)v0)) & 1023u);
    { unsigned t5; double z5; if (((((unsigned)e0 << (*mp & 31u)) << (i2 & 31u))) & 1u) { t5 = (unsigned)(g0 < (unsigned)(0x7fffffffu < a0[u1 & 3u])); z5 = (double)((2u) & 255u); } if (((((unsigned)e0 << (*mp & 31u)) << (i2 & 31u))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        v0 = (unsigned)(w0 >> 29);
        while (i0++ < 2u && (unsigned)w0) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((i0 << (p1 & 31u)) & 1023u);
            g0 = (unsigned)(0x72f0cb92u || (0xffffffffu - (unsigned)(((unsigned)s1 * p1) || r0.x)));
            g0 = 0xffffffffu;
        }
        if ((unsigned)((short)0xd929f036u > (signed char)(unsigned)l0)) goto L0;
    }
    if (-(unsigned)(0x10000u < (unsigned)((unsigned)x0 < 0x8ca64845u))) goto L1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((*mp - (unsigned)(w0 >> 29))) break;
            if (budget != 0u) { budget -= 1u; u1 = fn1(0x7fffffffu, 8u, garr[i1 & 7u]); }
            while (i2++ < 2u && ((unsigned)w0 >> (((unsigned)c0 << (v0 & 31u)) & 31u))) { if (--fuel == 0u) goto done;
                for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(short)((unsigned)(6u < (unsigned)c1) >> ((unsigned)h0 & 31u)), 0u, (unsigned)(signed char)(r0.y >> ((unsigned)c1 & 31u))); }
                    s1 = (int)((unsigned)s1 + (r0.x + (i2 + v0)));
                    e0 = e0 * 0.5L + (long double)(m0 & 1023u);
                    v0 = a0[i0 & 3u];
                    if ((unsigned)(5u == (unsigned)h0)) goto L1;
                    L0: if (--fuel == 0u) goto done;
                }
            }
        }
    } while (i0++ < 2u && 0xffffffffu);
    if ((unsigned)((unsigned)h1 || fuel)) goto done;
    while (i0++ < 6u && u3) { if (--fuel == 0u) goto done;
        if ((unsigned)(unsigned char)(g1 - (r0.y / ((unsigned)h0 | 1u)))) {
            goto L2;
            d0 = d0 * 0.5 + (double)((unsigned)(short)(0x7e0e7bafu >> (u0 & 31u)) & 1023u);
            if ((unsigned)((short)2u > (signed char)r0.x)) {
                garr[(unsigned)(unsigned char)(i1 ^ 5u) & 7u] = ((g1 + (unsigned)s1) ^ g0);
            } else {
                x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)(((unsigned)s0 ^ 0xb776143u) ^ (0x10000u | (unsigned)e0));
                if ((unsigned)h0) continue;
            }
            u2 = u3;
            if (budget != 0u) { budget -= 1u; u3 = fn1(((0x7fffffffu * i0) | 1u), (unsigned)(v0 == (0x7fffffffu % ((unsigned)s0 | 1u))), i0); }
            c1 = (signed char)p0;
        } else {
            do { if (--fuel == 0u) goto done;
                switch ((unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)d0) & 7u) {
                    m0 ^= (((unsigned)b0 % ((unsigned)(signed char)((unsigned)f0 * a0[i0 & 3u]) | 1u)) * (unsigned)c1);
                    r0.y ^= (unsigned)(signed char)(p2 >> (u0 & 31u));
                    case 6u: ;
                    r0.x = (((unsigned)s0 ? (unsigned)f0 : *mp) ? 0x1d133017u : u1);
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(0x20924f16u && (unsigned)d0), ((0xdea3eaacu + 0x2565827du) | p1), (a0[i0 & 3u] | (unsigned)x0)); }
                    c1 = (signed char)garr[i1 & 7u];
                }
            } while (i1++ < 3u && u1);
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(x0 >> 70), (unsigned)e0, 3u); }
            if ((unsigned)(p2 < (unsigned)s0)) {
                L1: if (--fuel == 0u) goto done;
                if ((unsigned)(garr[u2 & 7u] && 8u)) break;
            } else {
                break; (void)(((unsigned)(w0 >> 29) >> ((unsigned)(0x4fda9984u && 0u) & 31u)));
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)l0 && (unsigned)(short)((unsigned)(u0 < r0.y) + (unsigned)(w0 >> 29))) & 1023u);
            }
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                *q0 = ((unsigned)(signed char)(unsigned)((int)(unsigned)(5u < (unsigned)b0) < (int)9u) | (unsigned)((int)(unsigned)(w0 >> 29) < (int)p1));
                if (budget != 0u) { budget -= 1u; u2 = fn0(p1, (unsigned)((short)p0 > (signed char)((unsigned)c0 << ((unsigned)e0 & 31u))), (unsigned)w0); }
                i1 = ((unsigned)((p2 % (0xbbd218bbu | 1u)) < fuel) / ((*mp << (9u & 31u)) | 1u)) & 15u;
                g0 = (unsigned)(g1 < (unsigned)c1);
            }
        }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            *q0 += (unsigned)((unsigned)(x0 >> 70) && ((unsigned)b0 & u2));
            L2: if (--fuel == 0u) goto done;
            *q0 += (u3 ^ u0);
            if (((unsigned)(u0 == g0) << (2u & 31u))) goto done;
            l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(((unsigned)((int)0x10000u < (int)garr[u2 & 7u]) | (unsigned)w0) * (unsigned)(m0 && u1)));
        }
        { unsigned t0; double z0; if (((unsigned)s0) & 1u) { t0 = (unsigned)((short)(unsigned)s0 > (signed char)9u); z0 = (double)((6u) & 255u); } if (((unsigned)s0) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
            if (budget != 0u) { budget -= 1u; u0 = fn1(0xbde6271u, 7u, ~(i0 ^ r0.y)); }
            switch ((unsigned)(5u == u3) & 7u) {
                d0 = d0 * 0.5 + (double)((((unsigned)((int)*mp >= (int)g1) << ((unsigned)((int)0xffffffffu < (int)0x7fffffffu) & 31u)) ^ (unsigned)d0) & 1023u);
                case 0u: ;
                for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)(unsigned)h1 >= (int)p2)) goto L0;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(u2, ~(u2 / (i1 | 1u)), (0xd70fe9adu - (0u % (1u | 1u)))); }
                    case 6u: ;
                }
                g0 = (7u | (unsigned)(w0 >> 29));
                c0 = (unsigned char)(unsigned)c1;
            }
        }
    }
    if ((unsigned)((unsigned)s1 == (unsigned)c0)) {
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)c1, (unsigned)(i0 && (unsigned)((int)fuel < (int)(unsigned)b0)), ((unsigned)h0 / (g0 | 1u))); }
        switch (0xd661429au & 7u) {
            if (((0x7fffffffu << ((unsigned)x0 & 31u)) << ((unsigned)x0 & 31u))) {
                if (budget != 0u) { budget -= 1u; u2 = fn1(0xffffffffu, garr[u2 & 7u], fuel); }
                v0 = 0xabbed21du;
                u0 += (unsigned)b0;
            }
            if ((1u / ((unsigned)((int)a0[u1 & 3u] >= (int)garr[i1 & 7u]) | 1u))) {
                if (fuel < 8u) return fuel;
                *q0 += (unsigned)((u3 + ~(u1 * p2)) || a0[u1 & 3u]);
                r0.y ^= (unsigned)(garr[i1 & 7u] || ((unsigned)d0 - (unsigned)(0x62b72df5u && (unsigned)(signed char)(0x10000u >> (r0.x & 31u)))));
                if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)l0 - *q0), (g1 & v0), ((unsigned)!(2u ^ g0) + m0)); }
                L3: if (--fuel == 0u) goto done;
            }
            if ((unsigned)(9u == 0x75e1087bu)) goto L4;
            if (budget != 0u) { budget -= 1u; u0 = fn0((0x10000u * (fuel % (v0 | 1u))), 0x7fffffffu, (unsigned)s0); }
        }
        v0 = (0x35144504u / ((unsigned)((short)(unsigned)w0 > (signed char)g1) | 1u));
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((m0 % (0x80000000u | 1u)), (unsigned)((short)(unsigned)((unsigned)s0 && garr[u2 & 7u]) > (signed char)3u), (0x17255b9eu * m0)); }
    goto L1;
    switch ((unsigned)((int)p0 < (int)(unsigned)s0) & 7u) {
        L4: if (--fuel == 0u) goto done;
        b0 = (unsigned)(u1 < 0xb4270a3eu) != 0u;
    }
    if (~(r0.x | 0x1d0cb8c8u)) goto L2;
    *q0 = (unsigned)l0;
    while ((unsigned)(signed char)(unsigned)((int)u0 >= (int)(unsigned)h0)) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0((a0[i0 & 3u] << (((unsigned)f0 ^ (unsigned)w0) & 31u)), (0x80000000u ? g0 : p2), (unsigned)s1); }
        if (0x11714a02u) break;
    }
    f0 = f0 * 0.5f + (float)((unsigned)(9u && i0) & 255u);
    { unsigned t1; double z1; if ((0x10000u) & 1u) { t1 = (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)c1); z1 = (double)((i1) & 255u); } if ((0x10000u) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        i0 = (((unsigned)c0 * (unsigned)s1) % (((0x80000000u % ((unsigned)h0 | 1u)) + p0) | 1u)) & 15u;
        if ((unsigned)((unsigned)(u1 == 1u) == (unsigned)e0)) goto L2;
        u1 = (unsigned)((short)r0.y > (signed char)*q0);
    }
    if ((unsigned)((int)u2 >= (int)(unsigned)(1u == 0x80000000u))) {
        *q0 += (u2 * (unsigned)h0);
        r0.x = (unsigned)(signed char)(unsigned)(a0[u1 & 3u] == (unsigned)(0x13e0b27du == (unsigned)((int)(unsigned)x0 >= (int)(unsigned)b0)));
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                b0 = (((unsigned)h0 << ((unsigned)x0 & 31u)) | (unsigned)d0) != 0u;
                r0.y ^= (unsigned)((unsigned)(signed char)(garr[i1 & 7u] << ((unsigned)(w0 >> 29) & 31u)) == garr[i1 & 7u]);
                l0 = (long)((unsigned long)l0 + r0.y);
                e0 = e0 * 0.5L + (long double)((unsigned)(garr[i1 & 7u] || (unsigned)(unsigned char)(5u ? u3 : 1u)) & 1023u);
                if ((unsigned)((int)(unsigned)c0 < (int)5u)) break;
            }
        }
        if (u3 == 7u) return (u2 ^ ((garr[i1 & 7u] / (u2 | 1u)) / (i2 | 1u)));
        v0 = (*mp ? (a0[i0 & 3u] >> ((unsigned)s1 & 31u)) : (unsigned)h1);
    } else {
        goto L0;
        if ((unsigned)f0) goto L0;
        while ((unsigned)s0) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)!(4u * (unsigned)e0), (0x10000u / (m0 | 1u)), (u3 << (p1 & 31u))); }
            if ((0xffffffffu ? 0x80000000u : (unsigned)s0)) break;
            break; (void)((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)s1));
            g0 = (unsigned)((int)0xffffffffu < (int)p1);
            while (i1++ < 2u && (unsigned)((short)(unsigned)s0 > (signed char)u3)) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + ((unsigned)h1 >> (~(g1 % (((unsigned)w0 << (*q0 & 31u)) | 1u)) & 31u));
                if (((unsigned)c0 ^ (0x42cfa10u / ((unsigned)d0 | 1u)))) break;
                break; (void)((unsigned)(6u || (unsigned)h1));
                r0.x = (unsigned)(unsigned char)(0x7fffffffu | m0);
                if ((g0 ^ (unsigned)w0)) break;
            }
        }
        if (((unsigned)s0 << ((0x80000000u / ((unsigned)d0 | 1u)) & 31u))) goto L3;
    }
    r0.x = (-(unsigned)((u2 + u1) == *q0) << (i0 & 31u));
    { unsigned t2; double z2; if ((((unsigned)((int)m0 < (int)g0) >> ((unsigned)h1 & 31u))) & 1u) { t2 = ((unsigned)d0 / ((unsigned)x0 | 1u)); z2 = (double)(((0x7fffffffu % (((unsigned)(w0 >> 29) % ((unsigned)f0 | 1u)) | 1u))) & 255u); } if ((((unsigned)((int)m0 < (int)g0) >> ((unsigned)h1 & 31u))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        r0.y ^= (unsigned)((int)(v0 + (unsigned)((unsigned)c0 && (unsigned)(w0 >> 29))) < (int)v0);
        do { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)c1 && (0x3c31a463u % (7u | 1u)));
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)((unsigned)(-(0xf320c675u << (m0 & 31u)) && (unsigned)b0));
                x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)((int)(unsigned)h1 >= (int)(unsigned)s1) << (g0 & 31u)) < 0xffffffffu);
                goto L4;
                if ((unsigned)((short)(unsigned)e0 > (signed char)fuel)) goto L3;
                c1 = (signed char)((unsigned)(w0 >> 29) | (unsigned)((short)m0 > (signed char)u0));
            }
            r0.x = (unsigned)(signed char)((unsigned)h1 | (unsigned)(unsigned char)(i0 | p0));
            c1 = (signed char)(unsigned)h1;
            *mp = (*q0 % ((unsigned)c1 | 1u));
        } while (i0++ < 5u && (unsigned)f0);
        if ((0x60b3afe1u * (unsigned)(x0 >> 70))) {
            if ((unsigned)f0) goto L2;
            if ((unsigned)f0) {
                goto L3;
                *mp = (unsigned)((int)(unsigned)((int)(unsigned)((int)(unsigned)h1 < (int)(unsigned)f0) < (int)0xffffffffu) < (int)(unsigned)(r0.y || i1));
                goto L1;
                u1 = u1 * 0x9e3779b1u + ((unsigned)(u3 < p0) & 7u);
                if ((unsigned)(unsigned char)((i2 % (g1 | 1u)) % (1u | 1u))) goto L4;
                m0 ^= ((unsigned)((int)0xffffffffu >= (int)v0) * (unsigned)((int)fuel >= (int)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0x80000000u)));
            } else {
                b0 = 8u != 0u;
                goto L0;
                v0 = (unsigned)((short)(unsigned)!(unsigned)((int)u1 < (int)(unsigned)l0) > (signed char)(unsigned)s0);
                w0 = w0 * 6364136223846793005ull + (((unsigned)(signed char)(2u & (unsigned)l0) & (unsigned)w0) + 0x7fffffffu);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn1((0x10000u - 0x23a5029du), (unsigned)((short)3u > (signed char)r0.x), ((unsigned)c0 * (unsigned)b0)); }
            g1 += (unsigned)(signed char)((0xb37fc97eu | (a0[i0 & 3u] - *mp)) * v0);
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)(fuel & 1023u);
                break; (void)((unsigned)((unsigned)h0 || 8u));
                x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)(unsigned char)(u0 | garr[u2 & 7u]) | 8u) == (0x10000u / ((unsigned)b0 | 1u)));
            }
        }
        goto L4;
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(0x80000000u < i0), (unsigned)(signed char)(u0 * garr[i1 & 7u]), (fuel / (0x80000000u | 1u))); }
    }
    if (9u) goto L2;
    if (((unsigned)((int)0xc1f867d2u < (int)0x80000000u) << (u2 & 31u))) goto L3;
    h0 = (short)(unsigned)f0;
    u0 ^= (unsigned)(0x64479dc4u && (0x8bc6105bu | ((r0.x ^ (unsigned)f0) % (0xe8fabde4u | 1u))));
    goto done;
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(signed char)(0xf3923e19u ? (unsigned)e0 : u3), (unsigned)((short)i2 > (signed char)garr[u2 & 7u]), (unsigned)(short)(unsigned)((int)0x9c297909u >= (int)(unsigned)c0)); }
    goto L2;
    l0 = (long)((unsigned long)l0 + i2);
    if ((a0[u1 & 3u] ^ garr[u2 & 7u])) goto L0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    h1 = (unsigned short)(h1 + (a0[i0 & 3u] / ((0xd4b9872bu - 6u) | 1u)));
    f0 = f0 * 0.5f + (float)(((unsigned)w0 << ((unsigned)((0x2da7173u & p2) && fuel) & 31u)) & 255u);
    switch (i2 & 7u) {
        if (a0[u1 & 3u]) break;
        case 6u: ;
        i1 = (unsigned)(signed char)(unsigned)((unsigned)h0 == (unsigned)x0) & 15u;
    }
    while (i0++ < 4u && (unsigned)((unsigned)(4u || 0x80000000u) == 0x80000000u)) { if (--fuel == 0u) goto done;
        continue; (void)(r0.x);
        if ((unsigned)((int)(unsigned)w0 < (int)0x728a3c73u)) {
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                s0 = (int)(unsigned)(i0 || 8u);
                if (i0) break;
                f0 = f0 * 0.5f + (float)((unsigned)!(unsigned)(m0 == (*q0 & (unsigned)!(0x7fffffffu ? 0xa0ee6d92u : (unsigned)l0))) & 255u);
            }
        }
        c0 = (unsigned char)(v0 - (a0[u1 & 3u] / ((unsigned)((unsigned)s1 < (unsigned)x0) | 1u)));
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        g1 += ((p2 | 0x10000u) >> ((unsigned)h0 & 31u));
        l0 = (long)((unsigned long)l0 + (unsigned)(unsigned char)((unsigned)(signed char)(p0 << ((unsigned)((unsigned)b0 == 0x34fc384fu) & 31u)) ^ p1));
        if ((5u - -(0x28d013d8u + (unsigned)h1))) {
            r0.x = (p0 << ((unsigned)s0 & 31u));
            L1: if (--fuel == 0u) goto done;
        }
        switch ((a0[i0 & 3u] << ((garr[u2 & 7u] | 0xffffffffu) & 31u)) & 7u) {
            garr[u3 & 7u] = (unsigned)((short)((unsigned)((int)6u < (int)*mp) - (m0 >> (i2 & 31u))) > (signed char)0x40bd62bdu);
            e0 = e0 * 0.5L + (long double)(8u & 1023u);
        }
        d0 = d0 * 0.5 + (double)((0x5d41a296u / (((unsigned)(w0 >> 29) & ((unsigned)b0 ^ (unsigned)l0)) | 1u)) & 1023u);
    }
    if (((0xffffffffu << (fuel & 31u)) & i1)) goto L1;
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 = u0 * 0x9e3779b1u + (unsigned)(short)(unsigned)((int)(g0 >> (1u & 31u)) < (int)(u1 / (0xb17b52u | 1u)));
        L2: if (--fuel == 0u) goto done;
    }
    switch ((unsigned)((int)(unsigned)h1 >= (int)(unsigned)!(5u >> (3u & 31u))) & 7u) {
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            v0 = ((unsigned)f0 * (u3 + ((unsigned)(w0 >> 29) | 0x10000u)));
            if (-(1u + (unsigned)((int)p2 >= (int)g0))) continue;
            if (budget != 0u) { budget -= 1u; u3 = fn2(i2, 8u, (unsigned)((int)(unsigned)((int)(unsigned)w0 < (int)garr[i1 & 7u]) >= (int)m0)); }
            L3: if (--fuel == 0u) goto done;
            q0 = &garr[(0xbc01fa67u / ((unsigned)w0 | 1u)) & 7u];
            { unsigned t0; double z0; if (((unsigned)(w0 >> 29)) & 1u) { t0 = (u3 ? 0xffffffffu : 8u); z0 = (double)((*q0) & 255u); } if (((unsigned)(w0 >> 29)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                if (fuel < 8u) return ((unsigned)s0 * 0x80000000u);
            }
        }
        { unsigned t1; double z1; if ((((unsigned)s0 - 5u)) & 1u) { t1 = (unsigned)(unsigned char)(0u % (a0[u1 & 3u] | 1u)); z1 = (double)(((unsigned)((int)(unsigned)(garr[u2 & 7u] && 0x46cc3650u) < (int)0x699acca1u)) & 255u); } if ((((unsigned)s0 - 5u)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            b0 = m0 != 0u;
            case 1u: ;
            s1 = (int)((unsigned)s1 + u0);
            u3 += (unsigned)((int)u0 < (int)u3);
        }
        L4: if (--fuel == 0u) goto done;
        case 3u: ;
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            i0 = ~((unsigned)((int)0xffffffffu >= (int)garr[i1 & 7u]) & (unsigned)((int)r0.x >= (int)*mp)) & 15u;
            if (garr[i1 & 7u]) {
                f0 = f0 * 0.5f + (float)((1u ? 0xa6b36511u : (unsigned)(u2 && (0xee6c97e9u >> (0x3cb4498au & 31u)))) & 255u);
                if ((unsigned)c0) break;
                if ((unsigned)((int)0x10000u >= (int)i2)) goto done;
                *q0 = (0x10000u / (garr[i1 & 7u] | 1u));
            }
        }
        g0 = (g1 % ((i2 & (unsigned)f0) | 1u));
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)s0) break;
        if (budget != 0u) { budget -= 1u; u0 = fn0(((0x38c24c54u & 0xffffffffu) + 3u), (unsigned)(g0 < p1), a0[u1 & 3u]); }
        break; (void)((i2 ^ (unsigned)f0));
    }
    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(0x1508c535u && p1), (unsigned)((int)0x52c806acu >= (int)4u), (0x6c0317dcu / (u1 | 1u))); }
    if (a0[u1 & 3u]) {
        s0 = (int)(7u ? (3u << ((unsigned)l0 & 31u)) : (unsigned)l0);
        if ((8u + (unsigned)(x0 >> 70))) {
            u0 = (unsigned)(signed char)(unsigned)(4u && (0x80000000u >> (0x14608c63u & 31u)));
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(~(p0 << (*q0 & 31u)) || 5u), i1, ((unsigned)b0 + 8u)); }
            if ((unsigned)((unsigned)((short)i2 > (signed char)a0[u1 & 3u]) < 0x67459212u)) {
                r0.x = (0x10000u << ((unsigned)(0x7fffffffu == u1) & 31u));
                m0 ^= (i0 - (u3 & i1));
            } else {
                m0 ^= (unsigned)((short)u1 > (signed char)(unsigned)((int)(unsigned)b0 < (int)~(unsigned)((unsigned)(x0 >> 70) == (unsigned)(w0 >> 29))));
                goto L0;
                switch (u0 & 7u) {
                    h1 = (unsigned short)(h1 + 0x10000u);
                    *mp = (unsigned)((int)m0 >= (int)((unsigned)b0 - u1));
                    x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)s1 + ~(0xf3ede4fu / (9u | 1u))) && (a0[u1 & 3u] - g0));
                    garr[(unsigned)((int)0x10000u < (int)*mp) & 7u] = ((unsigned)(0x7fffffffu == (unsigned)((int)u1 < (int)u1)) >> ((0x7fffffffu << (u1 & 31u)) & 31u));
                    if ((i1 | 0xfcd850c4u)) break;
                    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + ((unsigned)(u0 == 0x31e7ec6cu) % ((unsigned)!(u1 / ((p1 - 0x80000000u) | 1u)) | 1u)));
                        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)(0x80000000u | 0u) < (int)garr[u2 & 7u]), (unsigned)(signed char)((unsigned)h0 & -(0x80000000u - garr[i1 & 7u])), (unsigned)f0); }
                            continue; (void)((u3 % (0x10000u | 1u)));
                        }
                        s0 = (int)(m0 + (unsigned)x0);
                    }
                }
                if (budget != 0u) { budget -= 1u; u0 = fn2(0xffffffffu, (unsigned)c1, ((unsigned)x0 / (6u | 1u))); }
            }
            if ((2u & (unsigned)((int)(unsigned)b0 >= (int)(unsigned)b0))) goto L2;
            a0[m0 & 3u] = (-(*q0 / (garr[i1 & 7u] | 1u)) + ((unsigned)(x0 >> 70) >> (p1 & 31u)));
        }
        w0 = w0 * 6364136223846793005ull + ((unsigned)((int)fuel < (int)(v0 << ((unsigned)x0 & 31u))) * (unsigned)(p2 || 0x651ba176u));
        if ((unsigned)(0u < 0xfa3aae74u)) goto L1;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn1(v0, (m0 >> (p1 & 31u)), fuel); }
    while (i0++ < 6u && (unsigned)(short)(unsigned)((unsigned)s1 < (unsigned)w0)) { if (--fuel == 0u) goto done;
        if (g1) {
            goto L3;
            if (budget != 0u) { budget -= 1u; u1 = fn2((i0 + (unsigned)(0x10000u || g0)), (unsigned)e0, ((r0.x & m0) - (unsigned)f0)); }
        } else {
            goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1(0x10000u, p0, (unsigned)(short)(unsigned)((int)2u < (int)(unsigned)(unsigned char)(u2 + 0x28257848u))); }
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)((int)0x73973f4eu >= (int)(unsigned)(u1 < r0.y));
        if ((garr[i1 & 7u] | -(r0.x - (unsigned)c1))) break;
        if (((unsigned)h0 / (p1 | 1u))) break;
    }
    u3 += (unsigned)b0;
    if (*q0) goto L4;
    if (budget != 0u) { budget -= 1u; u3 = fn0((0x10000u ? garr[i1 & 7u] : 0x10000u), (unsigned)(signed char)(u2 & garr[u2 & 7u]), (unsigned)((short)(unsigned)!(unsigned)(garr[i1 & 7u] < *q0) > (signed char)(unsigned)c0)); }
    if ((unsigned)!((unsigned)b0 / ((unsigned)(garr[i1 & 7u] && 9u) | 1u))) goto L2;
    if (0x46822020u) {
        b0 = (unsigned)((int)7u < (int)(((unsigned)h0 & 0xbdb97fb4u) ^ (unsigned)d0)) != 0u;
        u2 = u2 * 0x9e3779b1u + ((unsigned)c0 << (((unsigned)!(unsigned)((int)0x10000u < (int)(unsigned)(4u && u1)) >> (g1 & 31u)) & 31u));
        if (budget != 0u) { budget -= 1u; u0 = fn1((8u * (unsigned)c0), (0u + ((unsigned)l0 * p0)), (1u + (unsigned)((int)i0 < (int)(unsigned)h0))); }
    } else {
        r0.y ^= ((unsigned)(0x7fffffffu == (unsigned)(7u || 0x80000000u)) * (unsigned)(x0 >> 70));
    }
    m0 ^= (unsigned)((0x10000u - (unsigned)c0) == (unsigned)e0);
    goto L0;
    if ((unsigned)(v0 && ((unsigned)s1 >> (u2 & 31u)))) {
        if ((unsigned)(0xffffffffu || (0x80000000u / (g0 | 1u)))) {
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0(u3, ((unsigned)(u0 == 0x7fffffffu) % ((unsigned)(x0 >> 70) | 1u)), ~(unsigned)((int)(0x2802b88u - p1) < (int)(unsigned)s1)); }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)c0 / (3u | 1u)), (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)h0), ((unsigned)h1 & u1)); }
        }
        g0 = i2;
        i2 = ((m0 % ((unsigned)((short)(unsigned)h0 > (signed char)*mp) | 1u)) - (unsigned)(p2 == (unsigned)f0)) & 15u;
        f0 = f0 * 0.5f + (float)(((unsigned)h1 % (0x80000000u | 1u)) & 255u);
        if (u3 == 7u) return (unsigned)(7u < 0xe3e7586au);
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)(unsigned)c1 >= (int)(a0[i0 & 3u] & u1)), (unsigned)((int)*q0 >= (int)0x80000000u), fuel); }
    }
    *q0 = ((unsigned)h0 * (unsigned)(0xffffffffu || (p1 / (0x80000000u | 1u))));
    w0 ^= (unsigned long long)~(unsigned)((int)i1 < (int)(unsigned)x0) << (((0x84048d60u ? 0x2e2c45e6u : garr[i1 & 7u]) + (unsigned)(unsigned char)(0x80000000u >> (u1 & 31u))) & 63u);
    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(p2 || u2), (unsigned)((unsigned)((short)r0.x > (signed char)8u) < garr[u2 & 7u]), 0x7fffffffu); }
    f0 = f0 * 0.5f + (float)((~(unsigned)(fuel == g0) ? p0 : (p1 * (unsigned)c1)) & 255u);
    u0 ^= (*q0 % ((unsigned)(w0 >> 29) | 1u));
    { unsigned t2; double z2; if (((unsigned)((int)p1 >= (int)p1)) & 1u) { t2 = 0x1ae4d6e2u; z2 = (double)(((unsigned)(0x80000000u && 0x7fffffffu)) & 255u); } if (((unsigned)((int)p1 >= (int)p1)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        b0 = (p0 + ((0u ^ 0x53c01d11u) * (unsigned)c1)) != 0u;
    }
    goto done;
    if ((unsigned)(~(unsigned)((int)p0 < (int)0x80000000u) || garr[i1 & 7u])) {
        if ((unsigned)d0) {
            if ((0x80000000u & (u3 * (unsigned)s0))) goto done;
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                goto L2;
                c0 = (unsigned char)((unsigned)(r0.x || 0xba774191u) | v0);
                if (*mp) break;
            }
            if (garr[u2 & 7u]) goto L2;
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn0(garr[i1 & 7u], (unsigned)((unsigned)w0 < (v0 >> (fuel & 31u))), (unsigned)(unsigned char)(unsigned)((int)(unsigned)h1 >= (int)(r0.y & (unsigned)s0))); }
            for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0((a0[u1 & 3u] & 0xca42cf20u), (unsigned)!(unsigned)((int)0xffffffffu >= (int)(unsigned)x0), 0xaf9ddf7au); }
                f0 = f0 * 0.5f + (float)(((unsigned)(0u || (unsigned)e0) | *q0) & 255u);
                g1 += (u1 / ((unsigned)(x0 >> 70) | 1u));
                break; (void)((unsigned)((int)((unsigned)l0 | 0xc0d7dc56u) < (int)(unsigned)(w0 >> 29)));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(unsigned char)(g1 ? g1 : u0), ~((unsigned)(*q0 == 0x80000000u) << (*mp & 31u)), ((unsigned)(w0 >> 29) / ((unsigned)((int)u2 < (int)0u) | 1u))); }
            }
            w0 ^= (unsigned long long)(unsigned)e0 << ((r0.y << (0xd7158a5u & 31u)) & 63u);
        }
    }
    while ((unsigned)(u1 || r0.y)) { if (--fuel == 0u) goto done;
        *q0 += (u2 & 2u);
        if ((0x16746a81u | (unsigned)e0)) break;
        goto L4;
        if (budget != 0u) { budget -= 1u; u2 = fn0(u2, (unsigned)c0, (0x10000u / (0x80000000u | 1u))); }
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + g0;
        switch ((unsigned)(garr[u2 & 7u] || g0) & 7u) {
            l0 = (long)((unsigned long)l0 + (unsigned)((0x6235c1b0u % ((unsigned)(x0 >> 70) | 1u)) == (unsigned)(unsigned char)(g0 + (unsigned)(x0 >> 70))));
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(p2 < (unsigned)((unsigned)w0 && p2)), (g1 << ((unsigned)(0x80000000u < (unsigned)h1) & 31u)), (unsigned)((int)(unsigned)(w0 >> 29) >= (int)u0)); }
            c1 = (signed char)0x7fffffffu;
            h0 = (short)(unsigned)((unsigned)e0 || (unsigned)(signed char)(0xcb177da4u & *q0));
        }
    }
    do { if (--fuel == 0u) goto done;
        if (*q0) break;
        u2 += (unsigned)((int)((unsigned)c0 << ((u2 ^ 6u) & 31u)) >= (int)garr[u2 & 7u]);
        switch ((unsigned)((int)(unsigned)(0xa0cbbfccu < 0xffffffffu) >= (int)0x10000u) & 7u) {
            do { if (--fuel == 0u) goto done;
                case 3u: ;
            } while (i1++ < 5u && (unsigned)(g0 == i0));
            u0 ^= (unsigned)(x0 >> 70);
            case 6u: ;
            g1 += (unsigned)((short)9u > (signed char)i0);
            if (u2) {
                case 1u: ;
                *mp = (unsigned)((int)(unsigned)((short)6u > (signed char)(unsigned)c1) < (int)(a0[u1 & 3u] << (0x98739c2eu & 31u)));
                while (i1++ < 3u && (unsigned)l0) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((0x5c137607u << ((unsigned)(x0 >> 70) & 31u)), garr[i1 & 7u], (1u ^ 0x80000000u)); }
                }
                if (u3 == 7u) return p0;
                if (((unsigned)(w0 >> 29) ^ (unsigned)(unsigned char)(u2 - 0x80000000u))) goto done;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (unsigned)((short)(unsigned)((unsigned)((short)r0.y > (signed char)i2) || i2) > (signed char)garr[i1 & 7u]) != 0u;
                    if ((unsigned)c1) {
                        while (i2++ < 6u && 0x13e75bbcu) { if (--fuel == 0u) goto done;
                            w0 ^= (unsigned long long)a0[u1 & 3u] << (-((unsigned)((unsigned)x0 < (unsigned)(signed char)(unsigned)((int)(unsigned)d0 < (int)u1)) ^ (0x945abb59u * (unsigned)x0)) & 63u);
                            h0 = (short)(unsigned)((u3 & i1) == (1u + (unsigned)((short)g0 > (signed char)(unsigned)f0)));
                            if (budget != 0u) { budget -= 1u; u3 = fn0(a0[u1 & 3u], (u0 + v0), (0xffffffffu ^ (0xffffffffu | u0))); }
                        }
                        g1 += -(unsigned)(0x33273c81u < (unsigned)((unsigned)(0xffffffffu && 0x409acda7u) < garr[u2 & 7u]));
                        if (budget != 0u) { budget -= 1u; u3 = fn0(0x80000000u, (garr[i1 & 7u] / (0x2f91cb18u | 1u)), (unsigned)(unsigned char)(u0 * (unsigned)f0)); }
                    }
                    u2 = (unsigned)(signed char)((unsigned)((int)(unsigned)(unsigned char)(unsigned)((unsigned)d0 < p1) < (int)(v0 % (0x80000000u | 1u))) % (garr[u2 & 7u] | 1u));
                    e0 = e0 * 0.5L + (long double)((unsigned)((*mp & (0x80000000u * 8u)) || (unsigned)(8u && u1)) & 1023u);
                }
            } else {
                e0 = e0 * 0.5L + (long double)((0x5951f166u + u1) & 1023u);
                if (g0) {
                    case 4u: ;
                    for (;;) { if (--fuel == 0u) goto done;
                        m0 ^= (unsigned)(5u < p1);
                        c1 = (signed char)((0u ? 0x1c9459b4u : u1) >> ((unsigned)(0x10000u == u0) & 31u));
                        d0 = d0 * 0.5 + (double)(-(unsigned)(u1 || (unsigned)c1) & 1023u);
                        e0 = e0 * 0.5L + (long double)((unsigned)((2u * (unsigned)c1) < ((unsigned)(fuel || m0) + (unsigned)w0)) & 1023u);
                    }
                    if (u3) break;
                    c0 = (unsigned char)~(unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)l0);
                    case 2u: ;
                    m0 ^= (unsigned)((int)(unsigned)((i2 & (unsigned)s0) < 0x5603dc89u) >= (int)p2);
                } else {
                    goto L0;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)c1, ((unsigned)((int)4u >= (int)6u) - (unsigned)w0), g1); }
                }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)(unsigned)(0x80075523u < 0x7fffffffu), (unsigned)e0, (unsigned)((int)0xedeeb60u < (int)(unsigned)!(a0[i0 & 3u] << ((unsigned)w0 & 31u)))); }
            }
            case 5u: ;
        }
        u2 ^= garr[i1 & 7u];
        break; (void)((0x5e44dadfu | u3));
    } while (i0++ < 3u && (g0 - (0x7fffffffu & (unsigned)h0)));
    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)l0 << (~((unsigned)f0 / ((unsigned)c0 | 1u)) & 31u)), 8u, (r0.x / ((p1 - 0x80000000u) | 1u))); }
    goto L0;
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (a0[i0 & 3u]) break;
    }
    goto L1;
    *mp = (unsigned)((0x80000000u & a0[u1 & 3u]) || (unsigned)!((unsigned)l0 << ((unsigned)l0 & 31u)));
    if ((garr[i1 & 7u] - 4u)) goto L1;
    do { if (--fuel == 0u) goto done;
        garr[(unsigned)((short)a0[i0 & 3u] > (signed char)u1) & 7u] = ((unsigned)(w0 >> 29) & ((g1 & garr[i1 & 7u]) + garr[i1 & 7u]));
        switch ((unsigned)((int)(0x9c1c32c1u + (unsigned)s0) < (int)*q0) & 7u) {
            l0 = (long)((unsigned long)l0 + ((unsigned)((int)u3 >= (int)(unsigned)s0) + (unsigned)x0));
        }
        if (p0) break;
        if (-((unsigned)c0 << ((i1 >> (0x10000u & 31u)) & 31u))) break;
    } while (i0++ < 6u && 0x63931243u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(0x10000u || (unsigned)d0)) goto done;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(unsigned char)(garr[u2 & 7u] + 6u)) {
            while (i1++ < 2u && (unsigned)(0x147ea78bu || 9u)) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(((unsigned)((int)(unsigned)(0xe400ab59u < u1) < (int)(unsigned)x0) ^ ~((unsigned)f0 & m0)) & 1023u);
                { unsigned t0; double z0; if (((unsigned)(garr[u2 & 7u] < p2)) & 1u) { t0 = p1; z0 = (double)(((unsigned)((unsigned)d0 || *q0)) & 255u); } if (((unsigned)(garr[u2 & 7u] < p2)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)h0) break;
                        l0 = (long)((unsigned long)l0 + ((unsigned)(*mp || 0x21870ebeu) % (0x80000000u | 1u)));
                    } while (i2++ < 2u && 0xffffffffu);
                    if ((r0.x >> ((unsigned)(unsigned char)((unsigned)d0 / (r0.y | 1u)) & 31u))) break;
                    for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        *q0 = ((unsigned)(-(unsigned)((int)u2 >= (int)p2) || 0x1c638a0bu) % (r0.y | 1u));
                        if (budget != 0u) { budget -= 1u; u3 = fn2((0x36ee9e18u ^ u2), (unsigned)((int)(unsigned)s1 >= (int)((unsigned)x0 + 4u)), (unsigned)((int)0x80000000u < (int)0x86476dc4u)); }
                        m0 ^= (0x10000u | ((*mp >> ((unsigned)c1 & 31u)) >> ((unsigned)(x0 >> 70) & 31u)));
                        w0 = w0 * 6364136223846793005ull + (unsigned)((0xffffffffu / (4u | 1u)) == 0x80000000u);
                        break; (void)((unsigned)!((unsigned)x0 * *mp));
                        c0 = (unsigned char)(unsigned)c0;
                    }
                    for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0(v0, (unsigned)((unsigned)f0 || (5u * g1)), (g1 ^ i0)); }
                        x0 = x0 * 0x100000001b3ull + ((unsigned)(unsigned char)((unsigned)(unsigned char)(unsigned)((unsigned)c1 == (unsigned)(garr[i1 & 7u] && garr[u2 & 7u])) % (garr[u2 & 7u] | 1u)) / ((unsigned)h0 | 1u));
                        if ((((unsigned)h0 >> (0xffffffffu & 31u)) & 0x80000000u)) {
                            *q0 = ((unsigned)(w0 >> 29) >> (g1 & 31u));
                            if (budget != 0u) { budget -= 1u; u3 = fn3(g1, ((unsigned)(x0 >> 70) * (unsigned)x0), (p0 - (g1 * u2))); }
                            continue; (void)((unsigned)((short)(unsigned)h1 > (signed char)((unsigned)d0 >> (m0 & 31u))));
                        } else {
                            L0: if (--fuel == 0u) goto done;
                            if ((unsigned)(u2 && i2)) goto L4;
                        }
                    }
                    r0.x = (unsigned)(p1 < m0);
                }
                if ((u3 << ((unsigned)(unsigned char)(unsigned)((int)0x80000000u >= (int)(unsigned)w0) & 31u))) continue;
                if ((unsigned)((int)r0.x < (int)(0x5c9a71d7u | u1))) {
                    if (budget != 0u) { budget -= 1u; u2 = fn0((0x7fffffffu * (unsigned)(m0 < u2)), (2u + (unsigned)l0), r0.x); }
                    e0 = e0 * 0.5L + (long double)((v0 >> (((g0 * (unsigned)c1) << (0x7fffffffu & 31u)) & 31u)) & 1023u);
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((unsigned)d0 == (unsigned)(unsigned char)(u1 >> ((unsigned)h0 & 31u))), (unsigned)((r0.y | 0x7fffffffu) && *mp), (unsigned)((int)(unsigned)h1 >= (int)0x7fffffffu)); }
                    w0 = w0 * 6364136223846793005ull + (unsigned)d0;
                    u3 = ((unsigned)((int)r0.y >= (int)(unsigned)c1) | u3);
                    break; (void)(a0[u1 & 3u]);
                }
                if ((*mp | (unsigned)((int)p2 >= (int)p1))) break;
                if (i1) {
                    x0 = x0 * 0x100000001b3ull + (u2 & *q0);
                    L1: if (--fuel == 0u) goto done;
                } else {
                    break; (void)(-(((unsigned)h1 % ((unsigned)d0 | 1u)) - fuel));
                }
            }
            l0 = (long)((unsigned long)l0 + *q0);
            { unsigned t1; double z1; if ((((unsigned)w0 | (unsigned)(w0 >> 29))) & 1u) { t1 = g0; z1 = (double)((i2) & 255u); } if ((((unsigned)w0 | (unsigned)(w0 >> 29))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                if ((unsigned)(short)(unsigned)((unsigned)l0 < u2)) {
                    h0 = (short)(unsigned)c1;
                    m0 ^= (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)s1);
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(signed char)(u2 >> (0x10000u & 31u)), (unsigned)(0xffffffffu || p0), (unsigned)(((unsigned)(x0 >> 70) & u0) || m0)); }
                    if (((unsigned)b0 & garr[u2 & 7u])) break;
                    b0 = 0x2a740dc7u != 0u;
                    s1 = (int)((unsigned)s1 + (u2 & (unsigned)(0x80000000u < a0[u1 & 3u])));
                }
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)((unsigned)d0 >> (0x8c06c300u & 31u));
                    i1 = (unsigned)((0x10000u & (unsigned)h1) == (u3 | g0)) & 15u;
                    garr[i0 & 7u] = (((unsigned)((short)*mp > (signed char)0x10000u) << (fuel & 31u)) | (unsigned)b0);
                    if (*mp) goto L3;
                    *q0 = ((unsigned)(a0[u1 & 3u] || ~(unsigned)((int)*mp >= (int)g0)) << (1u & 31u));
                }
                e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(g1 / ((unsigned)(0xa8fa549bu || (0xcd3fab34u >> (0x80000000u & 31u))) | 1u)) & 1023u);
            }
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t2; double z2; if ((((unsigned)!((unsigned)(x0 >> 70) % (0x7fffffffu | 1u)) % ((unsigned)s1 | 1u))) & 1u) { t2 = i1; z2 = (double)(((unsigned)((int)m0 >= (int)i2)) & 255u); } if ((((unsigned)!((unsigned)(x0 >> 70) % (0x7fffffffu | 1u)) % ((unsigned)s1 | 1u))) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    while (i2++ < 6u && -(unsigned)((int)m0 >= (int)9u)) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u3 = fn3(p2, (unsigned)h0, fuel); }
                    }
                    if (((garr[i1 & 7u] + 2u) + 0x86d9bdebu)) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(signed char)(unsigned)((unsigned)(0xbe08cadeu == m0) == 0xa84414b0u), (unsigned)!(unsigned)(8u < i0), ((unsigned)h1 | (unsigned)x0)); }
                    switch ((unsigned)((int)fuel >= (int)(unsigned)(i0 && (unsigned)h0)) & 7u) {
                        for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                            case 6u: ;
                            u3 = *mp;
                            f0 = f0 * 0.5f + (float)((((unsigned)((int)*mp < (int)(unsigned)x0) / (g0 | 1u)) & (unsigned)(short)(0xffffffffu + 0x4bbb0fdu)) & 255u);
                            case 0u: ;
                            i1 = (unsigned)((int)(0xffffffffu % (p0 | 1u)) >= (int)(unsigned)w0) & 15u;
                        }
                        f0 = f0 * 0.5f + (float)((unsigned)(-(0x7fffffffu ? p2 : (unsigned)((int)garr[i1 & 7u] >= (int)0x21adee8eu)) || fuel) & 255u);
                        if (fuel < 8u) return (unsigned)f0;
                    }
                    h0 = (short)(unsigned)s1;
                    if (budget != 0u) { budget -= 1u; u1 = fn1(i2, ((u2 & u0) ^ (unsigned)s0), (unsigned)(r0.x && (unsigned)((unsigned)e0 == (unsigned)(w0 >> 29)))); }
                }
                *q0 += ((unsigned)(short)((unsigned)c1 + ((unsigned)d0 + v0)) ^ (fuel >> (0x10000u & 31u)));
                L2: if (--fuel == 0u) goto done;
                if (u3 == 7u) return (unsigned)(((unsigned)!(r0.y % (*mp | 1u)) % (0x80000000u | 1u)) == 0xffffffffu);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)((unsigned)w0 ^ (unsigned)c1) >= (int)a0[u1 & 3u]), (u0 << (p0 & 31u)), fuel); }
            { unsigned t3; double z3; if ((0xd60fb4d7u) & 1u) { t3 = (unsigned)(short)(i0 * u0); z3 = (double)(((unsigned)(u2 && u1)) & 255u); } if ((0xd60fb4d7u) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                { unsigned t4; double z4; if ((i0) & 1u) { t4 = (unsigned)((unsigned)(0x7fffffffu || *q0) == (unsigned)(w0 >> 29)); z4 = (double)((((unsigned)s0 << ((unsigned)!(unsigned)((unsigned)e0 == i0) & 31u))) & 255u); } if ((i0) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((0xffffffffu << ((unsigned)b0 & 31u)) && *mp), 0x7fffffffu, (unsigned)((unsigned)w0 || 0x1ca8de9cu)); }
                    L3: if (--fuel == 0u) goto done;
                    c1 = (signed char)(unsigned)(garr[i1 & 7u] || 0xffffffffu);
                    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)h0, (unsigned)!(unsigned)((0x3996b73bu << (p2 & 31u)) < (unsigned)s1), a0[u1 & 3u]); }
                }
                while (i1++ < 4u && p0) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)(signed char)((unsigned)c1 - (unsigned)((int)2u < (int)0x25de9c9fu)) || 0x7fffffffu) & 1023u);
                }
                r0.x = (v0 ^ ((garr[i1 & 7u] ^ fuel) % (0x80000000u | 1u)));
                if (budget != 0u) { budget -= 1u; u3 = fn2((0x2e1ffab4u | (fuel ^ 2u)), p0, g1); }
            }
        } else {
            switch (i1 & 7u) {
                if (u2) break;
                g1 += (unsigned)c0;
                if (budget != 0u) { budget -= 1u; u0 = fn0((i0 * (unsigned)((short)i1 > (signed char)(unsigned)e0)), (unsigned)(short)(u1 >> (*q0 & 31u)), (unsigned)(unsigned char)((unsigned)((int)g0 < (int)(unsigned)c1) / (g0 | 1u))); }
                L4: if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + 1u);
            }
            i2 = (r0.x ^ (unsigned)x0) & 15u;
        }
        { unsigned t5; double z5; if ((((unsigned)l0 % ((unsigned)(x0 >> 70) | 1u))) & 1u) { t5 = (unsigned)(garr[u2 & 7u] || a0[i0 & 3u]); z5 = (double)((((unsigned)b0 >> ((unsigned)(0x16ed25au || *q0) & 31u))) & 255u); } if ((((unsigned)l0 % ((unsigned)(x0 >> 70) | 1u))) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            if (((unsigned)h0 - ((unsigned)(x0 >> 70) << (garr[u2 & 7u] & 31u)))) goto L2;
            g1 += (((unsigned)s1 >> ((unsigned)c0 & 31u)) % ((unsigned)((short)(unsigned)d0 > (signed char)0xffffffffu) | 1u));
            while (i1++ < 7u && (r0.y + (unsigned)(i0 && 1u))) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (unsigned)(i1 || ((unsigned)(0x82083f4u < a0[i0 & 3u]) ^ r0.y));
                if ((unsigned)((int)(unsigned)((short)p1 > (signed char)p2) >= (int)*mp)) goto L2;
                garr[(0xc33601fcu ^ 0x7fffffffu) & 7u] = (u0 * *q0);
            }
        }
        break; (void)((unsigned)(w0 >> 29));
        if (fuel < 8u) return (unsigned)((unsigned)(0x10b9257du && garr[u2 & 7u]) || (a0[u1 & 3u] >> ((4u ^ garr[i1 & 7u]) & 31u)));
        w0 = w0 * 6364136223846793005ull + (p0 - 0x10000u);
    }
    if (m0) {
        do { if (--fuel == 0u) goto done;
            { unsigned t6; double z6; if (((unsigned)(0x7fffffffu && (unsigned)(u2 || 0x10000u))) & 1u) { t6 = 0x7fffffffu; z6 = (double)(((-(garr[i1 & 7u] + garr[u2 & 7u]) - u1)) & 255u); } if (((unsigned)(0x7fffffffu && (unsigned)(u2 || 0x10000u))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                while (i1++ < 7u && ~(unsigned)(p1 && 6u)) { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)(((unsigned)s0 + (unsigned)(p0 == 0x10000u)) & 1023u);
                    break; (void)((a0[u1 & 3u] % (u1 | 1u)));
                    q0 = &garr[0xbe90ffcdu & 7u];
                    g0 = (0x10000u ^ (r0.x & (unsigned)l0));
                }
                u3 ^= (unsigned)(0x80000000u < (unsigned)(short)(unsigned)((int)0x4c9c0eb9u >= (int)(unsigned)((unsigned)(x0 >> 70) < (0x18d1887eu & 0x396881e9u))));
                v0 = (unsigned)((short)fuel > (signed char)(unsigned)(x0 >> 70));
                u1 ^= (unsigned)((i0 >> (0x80000000u & 31u)) < 4u);
                if (((unsigned)d0 - g1)) continue;
                if (0x10000u) break;
            }
            while (i1++ < 6u && (unsigned)((unsigned)x0 == (unsigned)c1)) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)((int)0x80000000u >= (int)0x7f89f2f7u));
                switch (garr[u2 & 7u] & 7u) {
                    b0 = ((unsigned)((short)r0.y > (signed char)(unsigned)s1) + ((unsigned)!(unsigned)(u1 || garr[u2 & 7u]) ^ *q0)) != 0u;
                    *q0 += (g0 % ((unsigned)f0 | 1u));
                }
                m0 ^= (unsigned)((int)(unsigned)s1 < (int)u2);
            }
            while (i1++ < 5u && (unsigned)((int)(unsigned)s1 < (int)0xd6c54d51u)) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (unsigned)(r0.y || (m0 / ((0x843732edu ? 0x7b853556u : i2) | 1u))));
                    if (((unsigned)d0 ? 6u : 0x7fffffffu)) break;
                    switch ((unsigned)((int)0xffffffffu >= (int)(unsigned)((short)0xce7fd275u > (signed char)0u)) & 7u) {
                        u3 = u3 * 0x9e3779b1u + (0x3fbd3cdbu / ((unsigned)((short)(0x7f1c4f4du % ((unsigned)s1 | 1u)) > (signed char)v0) | 1u));
                        if (((unsigned)((unsigned)s0 < 9u) * g0)) continue;
                        w0 = w0 * 6364136223846793005ull + 0xdd1a3d19u;
                        *q0 = (unsigned)((short)((unsigned)f0 | u1) > (signed char)p2);
                    }
                    *q0 = i0;
                }
            }
            if ((unsigned)((int)p1 >= (int)(unsigned)l0)) break;
            u1 = ((unsigned)((int)0x7fffffffu < (int)(unsigned)h1) & (unsigned)!(u0 & ((unsigned)f0 & (unsigned)s0)));
            u1 += (unsigned)(garr[i1 & 7u] || *mp);
        } while (i0++ < 5u && garr[u2 & 7u]);
        goto L1;
        if (a0[u1 & 3u]) {
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t7; double z7; if ((0x10000u) & 1u) { t7 = *q0; z7 = (double)((((unsigned)x0 >> (garr[i1 & 7u] & 31u))) & 255u); } if ((0x10000u) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                    break; (void)((unsigned)(short)(9u ^ a0[u1 & 3u]));
                    if ((unsigned)((int)(unsigned)l0 >= (int)(unsigned)!(r0.y >> ((unsigned)f0 & 31u)))) continue;
                }
                if (0x59a6e0afu) break;
                break; (void)((unsigned)((short)(unsigned)(short)(u3 << (0x157aac8eu & 31u)) > (signed char)a0[i0 & 3u]));
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn3(0x7fffffffu, ((unsigned)d0 ^ 5u), (unsigned)(fuel || (unsigned)e0)); }
                    continue; (void)(((unsigned)c1 % ((unsigned)(r0.y && *mp) | 1u)));
                    a0[(unsigned)((int)r0.y < (int)(unsigned)(w0 >> 29)) & 3u] = 0x7ed89ba3u;
                }
            }
            if ((unsigned)(signed char)((0xf0f5eec0u + (unsigned)w0) << (1u & 31u))) goto L1;
            q0 = &garr[(unsigned)(*mp && ((unsigned)(m0 || p0) % ((unsigned)(short)((unsigned)w0 << (u0 & 31u)) | 1u))) & 7u];
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(r0.y && 0u)) {
                    garr[p1 & 7u] = (unsigned)(short)(unsigned)((int)(unsigned)s0 < (int)2u);
                    if ((0x17ef01b8u * a0[u1 & 3u])) continue;
                } else {
                    break; (void)((unsigned)!(-(u1 & g1) + (unsigned)s1));
                    *q0 += 8u;
                    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((int)9u >= (int)(unsigned)(x0 >> 70)), (unsigned)(0xffffffffu && (unsigned)((int)0x7fffffffu >= (int)(unsigned)h1)), (unsigned)(((unsigned)w0 ^ garr[u2 & 7u]) == u0)); }
                }
                if (((unsigned)!(garr[u2 & 7u] >> (u3 & 31u)) % (p1 | 1u))) break;
                h0 = (short)(garr[i1 & 7u] | 1u);
                { unsigned t8; double z8; if (((unsigned)(signed char)(unsigned)((int)(unsigned)(0x10000u || (unsigned)f0) < (int)(unsigned)c1)) & 1u) { t8 = (((unsigned)d0 ^ (unsigned)e0) | (unsigned)x0); z8 = (double)(((unsigned)(garr[i1 & 7u] || 0x7fffffffu)) & 255u); } if (((unsigned)(signed char)(unsigned)((int)(unsigned)(0x10000u || (unsigned)f0) < (int)(unsigned)c1)) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
                    w0 ^= (unsigned long long)r0.x << ((unsigned)(w0 >> 29) & 63u);
                    if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(fuel || m0), ((9u | (unsigned)c1) / ((unsigned)b0 | 1u)), (*mp | 0x2eaba53fu)); }
                }
            } while (i0++ < 2u && (unsigned)(short)(unsigned)(0x9d0f431eu || 0x7fffffffu));
            v0 = (unsigned)(~(((unsigned)e0 % (p2 | 1u)) ^ 0x14482213u) && (unsigned)(0x4b2e0ecau == (unsigned)s1));
        }
        l0 = (long)((unsigned long)l0 + (unsigned)(~((unsigned)x0 << ((unsigned)(i1 < (unsigned)e0) & 31u)) && g1));
        if ((0x8994e30cu + (unsigned)f0)) goto L3;
    } else {
        h0 = (short)(unsigned)(unsigned char)(((unsigned)(1u || 0x21e7eb32u) & p2) / ((unsigned)(x0 >> 70) | 1u));
        if ((unsigned)((unsigned)s0 && garr[u2 & 7u])) goto L1;
        if (garr[u2 & 7u]) {
            switch (3u & 7u) {
                *q0 = 0x80000000u;
                if (((unsigned)c0 | m0)) goto L1;
                for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    while (i1++ < 2u && (unsigned)(8u && *mp)) { if (--fuel == 0u) goto done;
                        break; (void)(((unsigned)h1 % ((unsigned)(0x9ff6efbbu < (unsigned)w0) | 1u)));
                    }
                    do { if (--fuel == 0u) goto done;
                        a0[(unsigned)h0 & 3u] = ((unsigned)((int)(unsigned)l0 < (int)(u0 << ((unsigned)s0 & 31u))) & 7u);
                        i0 = ((unsigned)c0 % (u3 | 1u)) & 15u;
                        v0 = (unsigned)(short)(unsigned)((int)0x322ea7e0u < (int)-((unsigned)(w0 >> 29) / (i2 | 1u)));
                        s0 = (int)(unsigned)(((unsigned)c0 & 2u) && 0x86b77274u);
                        v0 = ((unsigned)(signed char)((unsigned)w0 * (garr[i1 & 7u] & u2)) ^ (0x59a7d1f5u << (4u & 31u)));
                        if (budget != 0u) { budget -= 1u; u1 = fn2(-(0xdfb04974u | p2), (unsigned)((unsigned)w0 < u1), ((unsigned)(x0 >> 70) - (unsigned)(1u || 0x10000u))); }
                    } while (i1++ < 4u && (unsigned)(signed char)(fuel / (*q0 | 1u)));
                }
                if (u3 == 7u) return (((unsigned)s0 << ((3u - (r0.x << ((unsigned)x0 & 31u))) & 31u)) >> (4u & 31u));
            }
            if (((unsigned)h0 ? (unsigned)s0 : (unsigned)x0)) goto L3;
            r0.x = (((unsigned)w0 | (g1 % ((unsigned)d0 | 1u))) - g0);
            r0.y ^= ((unsigned)s1 ? g1 : 0x80000000u);
        }
    }
    if ((unsigned)(fuel == p1)) {
        if ((unsigned)((short)(unsigned)b0 > (signed char)4u)) goto L1;
        if (0x28bdf390u) goto L2;
        if (budget != 0u) { budget -= 1u; u2 = fn3(g1, (unsigned)(u0 || 0x84a4ceeau), (unsigned)((int)g1 >= (int)5u)); }
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 += (unsigned)((p2 + (unsigned)((int)(unsigned)b0 < (int)garr[u2 & 7u])) < p0);
        if ((*mp % ((0x7fffffffu * (unsigned)d0) | 1u))) goto L1;
        while (i1++ < 6u && (unsigned)(signed char)(unsigned)((int)6u < (int)(unsigned)((short)7u > (signed char)a0[u1 & 3u]))) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)(unsigned char)(r0.x & u1) << (u1 & 63u);
            if (((unsigned)((short)(unsigned)c0 > (signed char)(unsigned)(x0 >> 70)) + u2)) goto L2;
            if ((unsigned)c1) break;
        }
        w0 = w0 * 6364136223846793005ull + (0x9e6532b7u << (*mp & 31u));
        { unsigned t9; double z9; if ((m0) & 1u) { t9 = (0x3a43b8beu * *mp); z9 = (double)((~(p2 % (u1 | 1u))) & 255u); } if ((m0) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
            if (budget != 0u) { budget -= 1u; u0 = fn3(-(unsigned)(r0.y && u2), (unsigned)((unsigned)((short)*mp > (signed char)(unsigned)c0) && p1), ((unsigned)((short)(unsigned)d0 > (signed char)fuel) | (unsigned)e0)); }
            while (i1++ < 2u && g1) { if (--fuel == 0u) goto done;
                garr[(0x3be51797u * 0x80000000u) & 7u] = (0xffffffffu << ((unsigned)x0 & 31u));
                if (0xffffffffu) {
                    u3 = u3 * 0x9e3779b1u + (unsigned)s1;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((a0[u1 & 3u] << (garr[u2 & 7u] & 31u)) < 0xe95a8f3du), (-(3u & 0x10000u) & (unsigned)(x0 >> 70)), 0x80000000u); }
                }
                if ((unsigned)((int)p2 >= (int)(0xffffffffu * (unsigned)x0))) {
                    if (((unsigned)e0 / (2u | 1u))) break;
                    if (~(unsigned)(4u < (6u % ((unsigned)(w0 >> 29) | 1u)))) {
                        break; (void)((a0[u1 & 3u] * v0));
                    } else {
                        l0 = (long)((unsigned long)l0 + (*mp ^ (g1 ^ p0)));
                        if ((unsigned)((short)1u > (signed char)u3)) break;
                        s1 = (int)((unsigned)s1 + ~(g1 + g1));
                        if ((i2 / ((unsigned)((short)(unsigned)f0 > (signed char)0xaff41021u) | 1u))) break;
                    }
                } else {
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)f0) break;
                        for (;;) { if (--fuel == 0u) goto done;
                            if ((unsigned)l0) goto L2;
                        }
                    } while (i2++ < 6u && (unsigned)(0x349092cau < 0xab41e0a2u));
                }
                if (0xffffffffu) break;
                u0 += (unsigned)((0x80000000u | a0[u1 & 3u]) && 0u);
                break; (void)((unsigned)d0);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((*mp % (p0 | 1u)), (unsigned)((int)g0 >= (int)(p2 - (unsigned)l0)), p1); }
        }
    }
    if (((unsigned)(r0.x < (unsigned)(w0 >> 29)) + (unsigned)e0)) goto L0;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            if (-(unsigned)(8u && 4u)) {
                do { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)(u3 || m0);
                    h1 = (unsigned short)(h1 + ((0xa10223b5u | (unsigned)f0) * ~(2u << ((unsigned)l0 & 31u))));
                    if (budget != 0u) { budget -= 1u; u0 = fn3(a0[i0 & 3u], a0[u1 & 3u], (unsigned)b0); }
                    if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)((short)*mp > (signed char)(unsigned)x0), (unsigned)!(unsigned)((int)(unsigned)l0 < (int)a0[u1 & 3u]), i2); }
                } while (i2++ < 4u && (unsigned)((int)(unsigned)!(p0 * garr[u2 & 7u]) >= (int)garr[i1 & 7u]));
                if (0xffffffffu) goto L0;
            } else {
                { unsigned t10; double z10; if (((unsigned)((unsigned)c1 && u3)) & 1u) { t10 = (unsigned)w0; z10 = (double)((((unsigned)((unsigned)h1 && (unsigned)h1) * 0x865b52bbu)) & 255u); } if (((unsigned)((unsigned)c1 && u3)) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                    *q0 = (unsigned)(signed char)(a0[i0 & 3u] % ((unsigned)(((unsigned)b0 << (p0 & 31u)) || ~(0xc154eb44u ^ (unsigned)e0)) | 1u));
                    e0 = e0 * 0.5L + (long double)(1u & 1023u);
                    break; (void)(((unsigned)d0 ^ a0[i0 & 3u]));
                    { unsigned t11; double z11; if ((-(unsigned)((short)r0.x > (signed char)u3)) & 1u) { t11 = (unsigned)!(unsigned)(0xc144d851u && (unsigned)(w0 >> 29)); z11 = (double)((a0[i0 & 3u]) & 255u); } if ((-(unsigned)((short)r0.x > (signed char)u3)) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
                        *q0 = ((3u << (u2 & 31u)) >> ((unsigned)((fuel ^ 0x10000u) || i2) & 31u));
                        while (i2++ < 3u && i2) { if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn1(0xffffffffu, (unsigned)f0, (unsigned)((unsigned)(0x7fffffffu == (unsigned)c0) || *q0)); }
                            b0 = 0xe8d45e74u != 0u;
                            if (~(r0.y >> (garr[i1 & 7u] & 31u))) break;
                            e0 = e0 * 0.5L + (long double)(u1 & 1023u);
                        }
                        if (0x80000000u) goto L1;
                        break; (void)(0x10000u);
                        *q0 = (0x8bda1b2au | (unsigned)l0);
                        do { if (--fuel == 0u) goto done;
                            c0 = (unsigned char)(unsigned)(signed char)(v0 >> ((9u - g1) & 31u));
                        } while (i2++ < 4u && (unsigned)((short)u2 > (signed char)u0));
                    }
                    if (u0) goto L0;
                }
                c1 = (signed char)(0x7fffffffu - (unsigned)((int)1u < (int)9u));
            }
            *mp = 0xffffffffu;
            d0 = d0 * 0.5 + (double)(((0x8262182cu * u1) ? (unsigned)e0 : (unsigned)c1) & 1023u);
        }
        if (fuel < 8u) return (5u / (((unsigned)h1 + *mp) | 1u));
    }
    { unsigned t12; double z12; if (((unsigned)((int)(0x80000000u - u0) < (int)(unsigned)c0)) & 1u) { t12 = 6u; z12 = (double)((((unsigned)c0 * 0x41f303d7u)) & 255u); } if (((unsigned)((int)(0x80000000u - u0) < (int)(unsigned)c0)) & 1u) { u3 += t12; d0 = d0 * 0.5 + z12; }
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((short)(unsigned)e0 > (signed char)0x10000u));
            c1 = (signed char)((unsigned)!((9u << (r0.y & 31u)) % ((unsigned)w0 | 1u)) << (1u & 31u));
            if (budget != 0u) { budget -= 1u; u3 = fn1((r0.x % ((unsigned)f0 | 1u)), (v0 / (r0.y | 1u)), (r0.x ^ r0.y)); }
        }
        w0 ^= (unsigned long long)0x5dd6fe78u << ((unsigned)(~(unsigned)(a0[u1 & 3u] || a0[i0 & 3u]) == p2) & 63u);
        f0 = f0 * 0.5f + (float)((unsigned)(p2 < (a0[u1 & 3u] & (unsigned)s1)) & 255u);
        x0 = x0 * 0x100000001b3ull + garr[i1 & 7u];
        if (((unsigned)(signed char)(*mp ^ u0) + u1)) goto L1;
        while (i0++ < 2u && (unsigned)((int)0x80000000u < (int)m0)) { if (--fuel == 0u) goto done;
            break; (void)(0x80000000u);
            continue; (void)((r0.x >> (u2 & 31u)));
        }
    }
    q0 = &garr[(p1 + g1) & 7u];
    while (i0++ < 5u && (unsigned)(6u && 6u)) { if (--fuel == 0u) goto done;
        if (((unsigned)s0 % (0xff0d32ffu | 1u))) break;
        c1 = (signed char)((unsigned)((int)(unsigned)(garr[i1 & 7u] < a0[u1 & 3u]) >= (int)(unsigned)d0) % ((unsigned)((unsigned)e0 || *q0) | 1u));
        m0 ^= ((0x5bfa25cdu / ((unsigned)(i2 || 0x10000u) | 1u)) * (*mp ^ fuel));
        u1 = (unsigned)(unsigned char)(0xb93f15e2u + 0xd15b63f5u);
        d0 = d0 * 0.5 + (double)((unsigned)((0x2b2d9a7cu * g1) == (unsigned)x0) & 1023u);
    }
    u2 = u2 * 0x9e3779b1u + (unsigned)!(unsigned)(0x4f1bbc5u && 7u);
    r0.x = (0xba1a9961u | 0x81d75ca2u);
    goto L0;
    if ((unsigned)(2u < 8u)) goto L0;
    if (p2) {
        if (((unsigned)(p2 || v0) * (unsigned)s1)) {
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)l0 && (unsigned)(unsigned char)(u1 >> (0xe7ac148au & 31u))), (unsigned)(r0.x == (unsigned)(a0[u1 & 3u] < (unsigned)l0)), (0x35dae354u | (unsigned)e0)); }
            goto L0;
        }
    }
    { unsigned t13; double z13; if ((u1) & 1u) { t13 = (unsigned)((int)(unsigned)(0x808f089u && i0) >= (int)a0[i0 & 3u]); z13 = (double)((((0xb65e5dbdu ^ p2) * (unsigned)h1)) & 255u); } if ((u1) & 1u) { u1 += t13; d0 = d0 * 0.5 + z13; }
        if (u1) {
            h1 = (unsigned short)(h1 + (0x80000000u >> ((unsigned)((int)~(m0 - (unsigned)s0) >= (int)(unsigned)(p0 && (unsigned)l0)) & 31u)));
            if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(w0 >> 29) | p0), (unsigned)((short)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)0xffffffffu) > (signed char)(unsigned)w0), g1); }
            s0 = (int)(unsigned)((int)0u < (int)(unsigned)c0);
        } else {
            s1 = (int)((unsigned)s1 + (unsigned)((int)m0 < (int)0x61d0c79au));
        }
        garr[(unsigned)!(0xffffffffu * (unsigned)b0) & 7u] = (v0 | 0xb896082bu);
    }
    if ((p1 - ((unsigned)(x0 >> 70) >> ((unsigned)s0 & 31u)))) goto L2;
    goto done;
    g0 = (unsigned)!(i1 & ((unsigned)s0 - garr[u2 & 7u]));
    while (i0++ < 3u && (unsigned)((int)(unsigned)f0 >= (int)r0.y)) { if (--fuel == 0u) goto done;
        u1 = i0;
        if (((unsigned)((unsigned)s0 == r0.y) & 0xffffffffu)) goto done;
        break; (void)(0u);
        if (u3 == 7u) return (unsigned)x0;
        r0.x = (unsigned)((int)(v0 >> ((unsigned)h0 & 31u)) >= (int)-(unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)e0));
        continue; (void)((unsigned)((short)p1 > (signed char)(unsigned)(0x33f6b048u == (unsigned)w0)));
    }
    garr[garr[u2 & 7u] & 7u] = (((unsigned)s0 + ((unsigned)w0 ? (unsigned)s1 : (unsigned)b0)) + i0);
    c1 = (signed char)p2;
    { unsigned t14; double z14; if (((unsigned)((int)0x3fbde02du < (int)2u)) & 1u) { t14 = ((unsigned)(x0 >> 70) << ((unsigned)c1 & 31u)); z14 = (double)(((5u ^ u3)) & 255u); } if (((unsigned)((int)0x3fbde02du < (int)2u)) & 1u) { u2 += t14; d0 = d0 * 0.5 + z14; }
        if ((r0.y % ((unsigned)h0 | 1u))) goto L4;
        g1 += ((unsigned)s0 ? garr[i1 & 7u] : *mp);
    }
    if (((unsigned)h1 - (garr[u2 & 7u] & p2))) goto L3;
    if ((unsigned)(0xffffffffu || (unsigned)(3u && 8u))) goto done;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2(4u, -(unsigned)((short)0x15e7b23bu > (signed char)8u), (i2 % (0xb62e8dc9u | 1u))); }
        do { if (--fuel == 0u) goto done;
            while (i2++ < 4u && 0xdbd33de7u) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)s1);
                break; (void)((unsigned)(u2 && r0.x));
                c0 = (unsigned char)((3u + (unsigned)((int)2u < (int)0u)) ^ 0x46b92558u);
                h1 = (unsigned short)(h1 + ((unsigned)f0 / (((unsigned)h1 | g1) | 1u)));
                for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)f0 & a0[u1 & 3u]), ((unsigned)h0 + (0xc4f75da2u - 0xffffffffu)), 0x85109485u); }
                    if ((0xf5692f24u / (0xe7eff7bcu | 1u))) break;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn3(((unsigned)((unsigned)(x0 >> 70) == (unsigned)f0) % (0xdab781au | 1u)), (0x80000000u % (0x6f3a4806u | 1u)), (unsigned)(i1 && p2)); }
            }
        } while (i1++ < 2u && (unsigned)(signed char)(r0.y >> (garr[u2 & 7u] & 31u)));
        goto L1;
        if ((0x8b7ef995u >> ((unsigned)(signed char)(unsigned)(0x1579e532u || 0x80000000u) & 31u))) break;
        if (u3 == 7u) return (5u ^ (unsigned)(signed char)((unsigned)((short)u0 > (signed char)garr[u2 & 7u]) >> (p1 & 31u)));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0(u1, (~(unsigned)(a0[i0 & 3u] == (unsigned)s0) | 0xde2c0162u), *q0); }
    g1 += (0xa85b3ed0u ? (unsigned)w0 : 0x75e956edu);
    h1 = (unsigned short)(h1 + (unsigned)((short)u3 > (signed char)*mp));
    goto L3;
    h0 = (short)(m0 ^ 1u);
    goto L0;
    r0.x = (unsigned)(6u && (6u % (0xbbbda9adu | 1u)));
    switch (~(p1 & ((unsigned)f0 ^ 6u)) & 7u) {
        s0 = (int)fuel;
        if (budget != 0u) { budget -= 1u; u2 = fn3(0xb75e8c94u, garr[i1 & 7u], (unsigned)!(0x407a6140u >> ((0x80000000u * (unsigned)(w0 >> 29)) & 31u))); }
        if (budget != 0u) { budget -= 1u; u3 = fn3((unsigned)((int)(unsigned)s1 < (int)(p0 & 0xf2524758u)), a0[i0 & 3u], (unsigned)(x0 >> 70)); }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 10u, 0xfe9db2e3u, 0x594824dbu },
        { 0u, 0x62b77e0cu, 0x7e4e6542u },
        { 15u, 0x77713152u, 0x851651eau },
        { 15u, 0x3afd90d3u, 0xfbbc1eaeu },
        { 12u, 0x4dd8fb04u, 0x4fbf0cd8u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
