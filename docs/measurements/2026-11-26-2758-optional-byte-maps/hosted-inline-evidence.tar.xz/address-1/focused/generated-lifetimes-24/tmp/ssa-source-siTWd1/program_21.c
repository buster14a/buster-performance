// test-ssa-source's program of seed 141000444 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x6ad53cdeu, g1 = 0x692a8139u;
static unsigned garr[8] = { 0x5db1e8du, 0xe06c23fbu, 0xf22e5569u, 0xfd19a7d8u, 0xcb446dccu, 0x5e3d8645u, 0xd89f3766u, 0xa51a5638u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    m0 ^= (unsigned)((unsigned)h0 && 0xfaa605e0u);
    f0 = f0 * 0.5f + (float)((unsigned)(0x7fffffffu == (r0.y << (i0 & 31u))) & 255u);
    u2 ^= 0x36f558c9u;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        s0 = (int)(unsigned)((short)(unsigned)((int)0x10000u >= (int)p0) > (signed char)(unsigned)((int)((unsigned)s0 >> (u2 & 31u)) >= (int)(unsigned)f0));
        c1 = (signed char)(8u / ((unsigned)((int)g1 < (int)garr[u2 & 7u]) | 1u));
        x0 = x0 * 0x100000001b3ull + ((p1 - (unsigned)c1) >> (a0[u1 & 3u] & 31u));
    }
    L1: if (--fuel == 0u) goto done;
    if (fuel < 8u) return ((unsigned)(0xffffffffu < ((unsigned)(w0 >> 29) ? g0 : i0)) << (0u & 31u));
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(r0.x && (unsigned)c1)) break;
            u0 += (((p1 | (unsigned)((unsigned)w0 < (unsigned)f0)) << ((unsigned)h1 & 31u)) >> (0x19a14c32u & 31u));
            L2: if (--fuel == 0u) goto done;
        }
    } while (i0++ < 2u && ((unsigned)(v0 && (unsigned)w0) - (unsigned)(w0 >> 29)));
    c0 = (unsigned char)(unsigned)((int)((a0[i0 & 3u] << (6u & 31u)) + *q0) < (int)(unsigned)((unsigned)c1 && (unsigned)s1));
    L3: if (--fuel == 0u) goto done;
    while (i0++ < 4u && (unsigned)h1) { if (--fuel == 0u) goto done;
        i0 = (0x7fffffffu - ((unsigned)(0x80000000u && p1) + r0.x)) & 15u;
        while (i1++ < 2u && (unsigned)(((unsigned)h1 | u1) && 0u)) { if (--fuel == 0u) goto done;
            h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(0xd6afe564u / ((unsigned)((unsigned)(g1 == u1) < a0[i0 & 3u]) | 1u)));
        }
        L4: if (--fuel == 0u) goto done;
    }
    switch ((unsigned)(5u && garr[i1 & 7u]) & 7u) {
        case 1u: ;
        case 6u: ;
        switch ((g0 << (u2 & 31u)) & 7u) {
            if ((0x8c5d65acu / (0xc01e2a69u | 1u))) break;
            case 3u: ;
            case 0u: ;
            a0[(unsigned)(w0 >> 29) & 3u] = ((unsigned)x0 >> (0x10000u & 31u));
            while (i0++ < 7u && (0x10c58181u - u1)) { if (--fuel == 0u) goto done;
                *q0 = (r0.y ^ (unsigned)w0);
                m0 ^= (0xffffffffu & ((unsigned)(g0 || (unsigned)h1) << (u3 & 31u)));
            }
            b0 = (((8u / (i1 | 1u)) - 0x10000u) * r0.x) != 0u;
        }
        *q0 = (m0 / ((6u << ((unsigned)l0 & 31u)) | 1u));
        default: ;
    }
    do { if (--fuel == 0u) goto done;
        u3 = u3 * 0x9e3779b1u + ((a0[u1 & 3u] >> (v0 & 31u)) + ((unsigned)(0x10000u || *mp) / (0x517c294bu | 1u)));
        if (a0[i0 & 3u]) break;
    } while (i0++ < 5u && u2);
    if (((6u % (1u | 1u)) & 0xffffffffu)) goto L1;
    if (a0[u1 & 3u]) goto done;
    if (((unsigned)w0 & (g1 | r0.x))) goto L2;
    if ((unsigned)((int)((unsigned)w0 >> (1u & 31u)) >= (int)3u)) goto L4;
    u2 = u2 * 0x9e3779b1u + m0;
    if ((unsigned)(r0.x || 0x46d4c8e3u)) {
        goto L3;
        if ((unsigned)(unsigned char)(unsigned)((unsigned)b0 || (unsigned)(2u && p0))) goto done;
        g1 += garr[i1 & 7u];
        if (-(unsigned)(v0 < (unsigned)(unsigned char)(*q0 | 0xfc6ba50du))) goto L2;
        *q0 += (unsigned)((int)(5u ^ (unsigned)(x0 >> 70)) < (int)i2);
        c0 = (unsigned char)(unsigned)((int)((unsigned)e0 * m0) >= (int)i0);
    } else {
        if (~(p0 << ((i0 / ((unsigned)(x0 >> 70) | 1u)) & 31u))) goto L0;
        if ((p0 + 8u)) goto L3;
        if (fuel) goto L3;
        goto L0;
    }
    u2 += (unsigned)((u3 & u3) == u2);
    if ((unsigned)(3u && (unsigned)(short)(u3 % (i2 | 1u)))) goto L2;
    u1 = u1 * 0x9e3779b1u + ((a0[u1 & 3u] << (r0.x & 31u)) ^ 1u);
    q0 = &garr[(unsigned)w0 & 7u];
    h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(unsigned)((int)(unsigned)((short)u3 > (signed char)(p1 + r0.x)) < (int)(unsigned)((int)m0 >= (int)p2)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *q0 += m0;
    if (u3 == 7u) return (unsigned)((unsigned)((int)2u < (int)0x7fffffffu) || 0x7fffffffu);
    b0 = u0 != 0u;
    *mp = (unsigned)((0xffffffffu - (unsigned)(u0 == u0)) && (0xa52b53efu >> ((unsigned)d0 & 31u)));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)((4u & (unsigned)s0) == (unsigned)(x0 >> 70)) & 7u) {
            do { if (--fuel == 0u) goto done;
                switch ((unsigned)x0 & 7u) {
                    q0 = &garr[-(0xaac3ac4du ^ (unsigned)d0) & 7u];
                    w0 = w0 * 6364136223846793005ull + (unsigned)b0;
                }
            } while (i1++ < 6u && (unsigned)(signed char)(unsigned)((unsigned)e0 == (unsigned)((int)0x9a97e80bu >= (int)1u)));
            *q0 += (unsigned)((short)(r0.y ^ (unsigned)l0) > (signed char)(unsigned)(i0 < (unsigned)(unsigned char)(unsigned)((int)i0 < (int)i0)));
        }
        l0 = (long)((unsigned long)l0 + (garr[i1 & 7u] % ((m0 & (unsigned)((int)((unsigned)b0 / ((unsigned)(x0 >> 70) | 1u)) >= (int)0xbdfb4c0eu)) | 1u)));
        if (r0.y) goto L3;
        goto L2;
    }
    L0: if (--fuel == 0u) goto done;
    *q0 = (unsigned)s1;
    for (;;) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + ((unsigned)l0 ^ (unsigned)((int)(unsigned)f0 < (int)5u)));
        b0 = (unsigned)((unsigned)(((unsigned)((int)0x5f29ed6du >= (int)0x98c73a0du) | i1) && 0x10000u) || i0) != 0u;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch (0xffffffffu & 7u) {
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    L1: if (--fuel == 0u) goto done;
                    if (fuel < 8u) return 0x2cf80b91u;
                }
                h1 = (unsigned short)(h1 + (u0 ^ (unsigned)(unsigned char)(unsigned)(7u == (unsigned)((unsigned)e0 || *q0))));
                l0 = (long)((unsigned long)l0 + (r0.y ^ (unsigned)e0));
            }
        }
        if (((0x914c57feu % (0x7fffffffu | 1u)) ^ garr[i1 & 7u])) continue;
        if ((unsigned)((short)5u > (signed char)(unsigned)(a0[u1 & 3u] == 0x7fffffffu))) {
            f0 = f0 * 0.5f + (float)((unsigned)h0 & 255u);
            { unsigned t0; double z0; if (((unsigned)(signed char)(unsigned)(0x80000000u && u2)) & 1u) { t0 = (unsigned)((int)0xffffffffu < (int)0xb38f1b6bu); z0 = (double)((((unsigned)f0 >> ((unsigned)(signed char)(unsigned)(fuel && 0x7e9a0426u) & 31u))) & 255u); } if (((unsigned)(signed char)(unsigned)(0x80000000u && u2)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                c1 = (signed char)~(i1 / ((unsigned)((unsigned)c1 == (unsigned)w0) | 1u));
                l0 = (long)((unsigned long)l0 + ~(unsigned)(i0 && (unsigned)(fuel || *mp)));
                u2 ^= (unsigned)e0;
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    L2: if (--fuel == 0u) goto done;
                    if (0x10000u) goto L1;
                    L3: if (--fuel == 0u) goto done;
                    garr[i2 & 7u] = (0xd9a8d244u * p0);
                }
            }
            if ((garr[i1 & 7u] >> ((a0[i0 & 3u] >> (p2 & 31u)) & 31u))) continue;
            h0 = (short)2u;
            if ((garr[i1 & 7u] ? fuel : p0)) break;
            h0 = (short)(unsigned)(i0 < (unsigned)(g1 == a0[u1 & 3u]));
        } else {
            switch ((unsigned)(0xde491227u < 8u) & 7u) {
                if ((0u * u2)) break;
                h0 = (short)(unsigned)((int)(unsigned)w0 >= (int)((unsigned)d0 - garr[u2 & 7u]));
                while (i1++ < 7u && (7u / (7u | 1u))) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (r0.y >> ((g1 / ((0xc79cb99fu + 0x7fffffffu) | 1u)) & 31u));
                }
                while (i1++ < 7u && i0) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return ((v0 - 0u) * (m0 ^ (unsigned)(short)(unsigned)(fuel == 0xc765f1d0u)));
                    r0.y ^= (unsigned)(short)(u0 % ((unsigned)(m0 < (((unsigned)s1 + (unsigned)l0) / ((unsigned)s1 | 1u))) | 1u));
                    l0 = (long)((unsigned long)l0 + ((u3 - r0.x) >> (4u & 31u)));
                    h0 = (short)a0[u1 & 3u];
                    goto L4;
                }
            }
            m0 ^= 0x4e736478u;
            switch ((unsigned)!(i1 / ((unsigned)((short)(unsigned)w0 > (signed char)v0) | 1u)) & 7u) {
                L4: if (--fuel == 0u) goto done;
            }
            r0.x = ((unsigned)(((unsigned)f0 % (-(m0 << (4u & 31u)) | 1u)) < 1u) & 0u);
        }
        u1 = u1 * 0x9e3779b1u + u3;
    }
    { unsigned t1; double z1; if ((0xb4d2b31bu) & 1u) { t1 = 7u; z1 = (double)((u0) & 255u); } if ((0xb4d2b31bu) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((7u & (unsigned)b0) == r0.x), (unsigned)x0, (0xffffffffu + (unsigned)(short)((unsigned)s0 ^ 0x12754383u))); }
        if (i1) {
            if (((unsigned)w0 / (u2 | 1u))) goto L1;
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)w0, g0, ((unsigned)s0 | (unsigned)((int)(unsigned)h0 < (int)1u))); }
    }
    goto L0;
    do { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((int)u2 < (int)a0[i0 & 3u]));
        if (((unsigned)(g1 < r0.x) >> (0xf6ab2e45u & 31u))) {
            d0 = d0 * 0.5 + (double)((0x523bfcbcu << ((unsigned)d0 & 31u)) & 1023u);
            if (budget != 0u) { budget -= 1u; u2 = fn0(0x3f6bc139u, (unsigned)((int)4u >= (int)i1), (unsigned)(((unsigned)x0 - (unsigned)s0) == p0)); }
            { unsigned t2; double z2; if ((((unsigned)l0 % (u1 | 1u))) & 1u) { t2 = (unsigned)(signed char)(r0.y ^ (unsigned)(5u == 0x80000000u)); z2 = (double)(((u1 << (*q0 & 31u))) & 255u); } if ((((unsigned)l0 % (u1 | 1u))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                while (i1++ < 4u && garr[u2 & 7u]) { if (--fuel == 0u) goto done;
                    b0 = (i0 >> ((unsigned)c1 & 31u)) != 0u;
                }
                *q0 = (unsigned)((int)(unsigned)(x0 >> 70) < (int)((unsigned)c1 ? (unsigned)w0 : a0[u1 & 3u]));
            }
            if ((unsigned)(5u && v0)) break;
            w0 = w0 * 6364136223846793005ull + (unsigned)b0;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= 0xff59eb4au;
            }
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn0((0x80000000u & i1), ((unsigned)e0 & 0x10000u), (unsigned)((int)a0[i0 & 3u] < (int)fuel)); }
            if ((unsigned)s1) break;
            f0 = f0 * 0.5f + (float)((unsigned)(v0 && (unsigned)!(unsigned)((i1 >> ((0xeb6ca86fu | 0xf20bf854u) & 31u)) && (unsigned)c1)) & 255u);
        }
        g1 += r0.x;
        if (~((r0.x >> (u0 & 31u)) << (p2 & 31u))) {
            if (u0) break;
            m0 ^= (*q0 / ((unsigned)h0 | 1u));
        }
        v0 = ((*mp - 0xffffffffu) & (g0 / (0u | 1u)));
    } while (i0++ < 2u && 0x10000u);
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((a0[u1 & 3u] - g0) == (unsigned)c0), (r0.y + fuel), (unsigned)(unsigned char)(unsigned)((int)v0 >= (int)0u)); }
    c1 = (signed char)(unsigned)e0;
    if (u2) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)(unsigned)(((unsigned)(0x10000u == 3u) % ((8u << (0x68d1ecb2u & 31u)) | 1u)) < 5u);
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)0x10000u >= (int)g1), (unsigned)((unsigned)b0 && *mp), (0x7fffffffu ^ (unsigned)w0)); }
        }
        if ((unsigned)(w0 >> 29)) {
            if ((unsigned)f0) goto L0;
            h1 = (unsigned short)(h1 + (unsigned)((*q0 >> ((unsigned)(i1 < (unsigned)s1) & 31u)) || (unsigned)(0xa98500c1u && (unsigned)d0)));
            if ((unsigned)(short)(unsigned)(0xa9915e3bu && a0[u1 & 3u])) goto L4;
        } else {
            s1 = (int)((unsigned)s1 + (0x80000000u & (unsigned)!(0x10000u / (u3 | 1u))));
        }
        goto L0;
    }
    if ((unsigned)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)a0[i0 & 3u]) || 0xffffffffu)) goto L2;
    w0 ^= (unsigned long long)fuel << (v0 & 63u);
    w0 ^= (unsigned long long)(unsigned)((short)(unsigned)l0 > (signed char)a0[u1 & 3u]) << (g1 & 63u);
    if (budget != 0u) { budget -= 1u; u1 = fn0((0x7fffffffu | i0), ((unsigned)(u1 == 0x10000u) << (u2 & 31u)), (u2 / ((i2 + 0x10000u) | 1u))); }
    u3 += (((i0 ^ 4u) << (((unsigned)h0 + a0[u1 & 3u]) & 31u)) & (unsigned)e0);
    g1 += 0u;
    m0 ^= (unsigned)h1;
    if ((0x80000000u | 0x7fffffffu)) goto done;
    if (budget != 0u) { budget -= 1u; u1 = fn0((r0.x + (unsigned)(short)(*q0 >> (u1 & 31u))), (unsigned)!(unsigned)((unsigned)((int)u3 >= (int)(unsigned)x0) && (unsigned)c0), (6u * (unsigned)s0)); }
    while (i0++ < 4u && (unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
        if (u3) break;
        b0 = (unsigned)!((unsigned)(6u || ((unsigned)f0 ^ 0x80000000u)) % (0x8ab6071cu | 1u)) != 0u;
        a0[0xcbec3769u & 3u] = (unsigned)c1;
        goto L0;
        a0[0xf41a568au & 3u] = (unsigned)((short)(garr[i1 & 7u] & 1u) > (signed char)(unsigned)((int)(unsigned)(short)(p1 & g0) >= (int)0xffffffffu));
        { unsigned t3; double z3; if ((0x80000000u) & 1u) { t3 = (unsigned)((i1 >> (1u & 31u)) || (unsigned)(x0 >> 70)); z3 = (double)(((p2 + a0[u1 & 3u])) & 255u); } if ((0x80000000u) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
            goto L4;
            if (r0.y) break;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (u3 == 7u) return ((fuel << (9u & 31u)) - (u0 + p0));
                { unsigned t4; double z4; if ((((unsigned)w0 >> ((unsigned)c0 & 31u))) & 1u) { t4 = (0x10000u ^ 7u); z4 = (double)((((garr[i1 & 7u] * *mp) / (p1 | 1u))) & 255u); } if ((((unsigned)w0 >> ((unsigned)c0 & 31u))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    r0.x = i1;
                    u0 = u0 * 0x9e3779b1u + (((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)e0) >> (a0[u1 & 3u] & 31u)) * (unsigned)(short)(unsigned)((short)p1 > (signed char)1u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0(0xffffffffu, (unsigned)((short)((unsigned)c1 - (unsigned)c0) > (signed char)u2), ((p1 - i1) & (unsigned)(x0 >> 70))); }
                }
                break; (void)((unsigned)f0);
                s0 = (int)u2;
            }
            if (budget != 0u) { budget -= 1u; u3 = fn0(0x9a813f96u, (unsigned)((int)u2 >= (int)(unsigned)!((unsigned)d0 * p0)), (unsigned)l0); }
            q0 = &garr[0x22799a8au & 7u];
            u0 = u0 * 0x9e3779b1u + (((unsigned)f0 * (unsigned)h1) % ((unsigned)d0 | 1u));
        }
    }
    u1 += i0;
    u2 = (unsigned)((short)0x9bf341b3u > (signed char)fuel);
    while (i0++ < 2u && ((unsigned)w0 & (unsigned)((unsigned)s0 == garr[i1 & 7u]))) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((int)0xebef7f8fu >= (int)(unsigned)f0));
        if (((unsigned)((short)i1 > (signed char)g1) + a0[u1 & 3u])) break;
        while (i1++ < 3u && (unsigned)s1) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)s1, r0.x, (unsigned)((short)5u > (signed char)0x939ce1d4u)); }
            if ((unsigned)b0) break;
            if ((unsigned)((int)m0 >= (int)m0)) continue;
            for (i2 = 0u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)(w0 >> 29) || i0)) {
                    h0 = (short)((unsigned)x0 + (unsigned)c1);
                    continue; (void)((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)((int)garr[u2 & 7u] >= (int)garr[i1 & 7u])));
                    c1 = (signed char)m0;
                } else {
                    if ((u0 | -(unsigned)(0x80000000u == r0.y))) goto L3;
                    r0.y ^= ((i1 % ((0xffffffffu * u3) | 1u)) >> ((g0 - 0xffffffffu) & 31u));
                    if ((unsigned)(u2 < u2)) break;
                    i1 = ((unsigned)w0 >> (5u & 31u)) & 15u;
                }
                m0 ^= (unsigned)x0;
                u1 += (unsigned)(0x8a19cb04u || ((p2 - 0x10000u) / ((unsigned)(0x7fffffffu && (unsigned)w0) | 1u)));
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    v0 = (unsigned)(u3 < *q0);
                }
            }
        }
    }
    u0 = (r0.x | (unsigned)((unsigned)!(unsigned)(((unsigned)b0 >> ((unsigned)w0 & 31u)) < (unsigned)c0) || p2));
    while (i0++ < 5u && (unsigned)c0) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)(unsigned)((short)(unsigned)((short)2u > (signed char)p1) > (signed char)((unsigned)d0 << (garr[i1 & 7u] & 31u)));
        g0 = 0xffffffffu;
        switch (-(unsigned)((unsigned)c0 < a0[u1 & 3u]) & 7u) {
            g1 += (6u >> (3u & 31u));
            if (a0[i0 & 3u]) {
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(garr[u2 & 7u] < u1), (unsigned)(5u == 0x7fffffffu), (r0.y / (a0[i0 & 3u] | 1u))); }
                if ((0x79446c49u | r0.x)) {
                    x0 = x0 * 0x100000001b3ull + (8u - a0[u1 & 3u]);
                    if (((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)r0.y) ^ i2)) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn0(8u, 0xf7c844d2u, 0xd4afb842u); }
                }
                case 5u: ;
                if (0xcfaa840du) break;
            } else {
                g1 += (unsigned)((unsigned)((unsigned)w0 == u3) < ~(0x77e7fba2u - *mp));
                case 1u: ;
            }
        }
        for (;;) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)(i0 == garr[u2 & 7u]));
            do { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)(((p0 ^ 0x2b91a761u) + (unsigned)w0) || (unsigned)(a0[i0 & 3u] && a0[i0 & 3u])) & 1023u);
            } while (i2++ < 6u && (v0 / (i1 | 1u)));
            if (fuel < 8u) return (0x2028cee0u % (i0 | 1u));
            while (i2++ < 3u && ((*q0 + p0) & (unsigned)c1)) { if (--fuel == 0u) goto done;
                if (((unsigned)((short)g1 > (signed char)0x703f57e5u) / (0x8d42aa20u | 1u))) break;
                if ((unsigned)l0) continue;
                s1 = (int)((unsigned)s1 + ((unsigned)x0 / (i0 | 1u)));
            }
            switch (((unsigned)((short)0x7fffffffu > (signed char)p0) & (unsigned)c0) & 7u) {
                g1 += (0x654396cdu * (((unsigned)e0 ? v0 : p0) * p0));
                h0 = (short)(*mp ? (unsigned)b0 : (unsigned)(x0 >> 70));
                l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)(unsigned char)(unsigned)((int)*mp < (int)g1) + v0) && (unsigned)c1));
                break; (void)((0xee4a32c9u >> (((unsigned)c1 >> (g1 & 31u)) & 31u)));
            }
            r0.y ^= 0x1d85b823u;
        }
        if (((unsigned)(signed char)(unsigned)((unsigned)f0 == *q0) * u0)) break;
        if ((unsigned)x0) break;
    }
    { unsigned t5; double z5; if (((r0.y / ((u2 % (i2 | 1u)) | 1u))) & 1u) { t5 = (unsigned)(1u && 0xb1461e61u); z5 = (double)(((1u * (unsigned)(m0 == p2))) & 255u); } if (((r0.y / ((u2 % (i2 | 1u)) | 1u))) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
        u3 ^= ((a0[u1 & 3u] ^ u1) / (u2 | 1u));
        goto L4;
        do { if (--fuel == 0u) goto done;
            h0 = (short)(unsigned)e0;
            d0 = d0 * 0.5 + (double)((unsigned)((short)((u3 / ((unsigned)(x0 >> 70) | 1u)) ^ (unsigned)x0) > (signed char)(0x10000u * 0x7fffffffu)) & 1023u);
        } while (i0++ < 6u && *mp);
        h1 = (unsigned short)(h1 + (unsigned)((unsigned)((short)(unsigned)x0 > (signed char)u2) || (unsigned)((int)u0 < (int)(unsigned)(fuel || 0x855e4590u))));
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)(*q0);
                if (((unsigned)c0 ^ (unsigned)((int)0x80000000u < (int)(unsigned)h0))) break;
                if ((6u << ((unsigned)l0 & 31u))) break;
            }
            *q0 += (unsigned)(unsigned char)((((0x40317318u - 0x7fffffffu) & (unsigned)(x0 >> 70)) - (unsigned)b0) >> (a0[u1 & 3u] & 31u));
            u1 = (unsigned)(signed char)(unsigned)(g0 || (unsigned)x0);
            break; (void)((unsigned)!(5u - a0[i0 & 3u]));
            g1 += ((unsigned)(unsigned char)(9u ? (unsigned)!(unsigned)((unsigned)s0 || fuel) : *q0) | (unsigned)h1);
            w0 = w0 * 6364136223846793005ull + (unsigned)(i2 == (*q0 | (unsigned)(garr[i1 & 7u] && 0x82194ebfu)));
        }
    }
    while (i0++ < 3u && g1) { if (--fuel == 0u) goto done;
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)(x0 >> 70)) break;
            v0 = r0.x;
            if (budget != 0u) { budget -= 1u; u1 = fn0(u2, (unsigned)f0, (unsigned)!(unsigned)((unsigned)(r0.y < r0.y) || 6u)); }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0x10000u && g0), (0x80000000u >> ((9u & (unsigned)s0) & 31u)), (*q0 ^ ((unsigned)d0 & 6u))); }
            *q0 = 0x10000u;
        }
        q0 = &garr[((unsigned)h1 >> (3u & 31u)) & 7u];
        u0 = (unsigned)(((unsigned)w0 % (7u | 1u)) || (unsigned)(m0 && (unsigned)((short)u1 > (signed char)2u)));
        q0 = &garr[-((((6u & p2) * i0) | (unsigned)(w0 >> 29)) * p1) & 7u];
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(unsigned char)(2u * (unsigned)(i2 || fuel)), (unsigned)((unsigned)(9u || *mp) < 0xb23313cbu), ((unsigned)d0 ^ a0[u1 & 3u])); }
        if ((r0.x | g0)) {
            garr[0xc2a366f2u & 7u] = (g1 - (unsigned)((int)8u >= (int)(unsigned)((0xffffffffu << (g1 & 31u)) && 9u)));
            break; (void)((unsigned)((short)p2 > (signed char)garr[u2 & 7u]));
        }
    }
    v0 = (unsigned)((int)7u >= (int)((*q0 & (unsigned)d0) - (unsigned)((unsigned)f0 && p0)));
    w0 = w0 * 6364136223846793005ull + (0x10000u >> (fuel & 31u));
    c0 = (unsigned char)0x80d49cf4u;
    if (-(unsigned)(a0[u1 & 3u] && (r0.x << ((unsigned)f0 & 31u)))) {
        if ((unsigned)!(unsigned)(p2 || (unsigned)h1)) goto L3;
        q0 = &garr[((unsigned)((short)u0 > (signed char)0x80000000u) * (unsigned)(m0 < (unsigned)b0)) & 7u];
        if ((unsigned)((unsigned)s1 || ((unsigned)c1 | *mp))) goto L2;
        goto L1;
        c0 = (unsigned char)(unsigned)x0;
    } else {
        goto L2;
        u0 = (garr[i1 & 7u] ^ p0);
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)((int)(unsigned)d0 >= (int)(r0.y >> (i1 & 31u)));
    u2 ^= r0.x;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (fuel < 8u) return (unsigned)(short)(unsigned)((unsigned)h1 || (a0[i0 & 3u] - 2u));
    a0[((unsigned)d0 / (0x10000u | 1u)) & 3u] = (unsigned)((int)0xffffffffu < (int)(unsigned)((int)r0.y >= (int)(unsigned)(u2 < (unsigned)((int)(unsigned)b0 >= (int)(unsigned)(x0 >> 70)))));
    if (fuel < 8u) return (unsigned)((short)(5u - 4u) > (signed char)r0.x);
    L0: if (--fuel == 0u) goto done;
    d0 = d0 * 0.5 + (double)(((unsigned)h0 * (unsigned)((short)u2 > (signed char)0x80000000u)) & 1023u);
    L1: if (--fuel == 0u) goto done;
    x0 = x0 * 0x100000001b3ull + ((unsigned)s0 | (unsigned)(garr[i1 & 7u] && (unsigned)(garr[i1 & 7u] == 0x5d114bb2u)));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if (((unsigned)((u3 >> (0xffffffffu & 31u)) || g0)) & 1u) { t0 = (unsigned)(7u < v0); z0 = (double)((9u) & 255u); } if (((unsigned)((u3 >> (0xffffffffu & 31u)) || g0)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                if (((unsigned)((int)0x80000000u < (int)(unsigned)x0) + 6u)) goto L2;
                *q0 = 7u;
                w0 = w0 * 6364136223846793005ull + (unsigned)(0x10000u < (unsigned)((int)(unsigned)((unsigned)h0 < 0xcbabc5e3u) >= (int)(unsigned)e0));
                if ((unsigned)(p1 < u2)) break;
                if ((unsigned)(signed char)((unsigned)f0 ^ (6u << (0x80000000u & 31u)))) continue;
            }
            while (-(unsigned)((int)0x10000u >= (int)a0[i0 & 3u])) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)s0 < 0x4e7c3ef8u)) break;
            }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)(signed char)((unsigned)((short)r0.x > (signed char)u0) ^ 0x10000u)) continue;
                d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(((unsigned)l0 * (unsigned)x0) + (unsigned)(*q0 && 0x80000000u)) & 1023u);
            } while (i2++ < 7u && r0.y);
            if ((unsigned)((int)(g0 - 0xf5451f77u) >= (int)(unsigned)s1)) {
                r0.x = 6u;
                if ((unsigned)(garr[i1 & 7u] == (unsigned)l0)) break;
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(r0.x == 0x78a6c7e4u) + a0[u1 & 3u]), 0x5bb02e04u, 0x806e6f52u); }
                    continue; (void)((0x940a6abfu / ((u3 / (u2 | 1u)) | 1u)));
                }
            }
            c1 = (signed char)(((unsigned)x0 * m0) - (unsigned)((unsigned)(8u || 0x3206cfdu) == a0[u1 & 3u]));
        } while (i1++ < 5u && (unsigned)s1);
        if (((unsigned)(short)(unsigned)(i0 && m0) + (unsigned)s0)) break;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)w0 * ~(unsigned)((int)0x7fffffffu < (int)m0)), (a0[i0 & 3u] ^ 0xda4891beu), (unsigned)l0); }
    r0.y ^= (p2 ^ (unsigned)!((m0 & i1) ^ 0x9937dfd2u));
    if (((g1 % (u2 | 1u)) + 7u)) goto L0;
    goto L3;
    g0 = (unsigned)d0;
    g0 = ((unsigned)b0 / (v0 | 1u));
    q0 = &garr[m0 & 7u];
    i0 = ((unsigned)((0x7fffffffu % ((unsigned)s1 | 1u)) < (r0.y & fuel)) * u1) & 15u;
    *q0 += (garr[u2 & 7u] & (unsigned)!(unsigned)((int)1u < (int)fuel));
    garr[-(unsigned)((short)i2 > (signed char)m0) & 7u] = ((unsigned)f0 % (p0 | 1u));
    b0 = (unsigned)((unsigned)c1 || (unsigned)((int)((unsigned)e0 + 5u) >= (int)garr[i1 & 7u])) != 0u;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch (0x7fffffffu & 7u) {
            if (m0) {
                case 3u: ;
                if (u3) {
                    u0 = ((unsigned)((int)((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)l0) & 3u) < (int)(unsigned)h0) / ((unsigned)s1 | 1u));
                    i0 = (0x192da7dau ? 0x10000u : (unsigned)e0) & 15u;
                    case 1u: ;
                    if (*q0) break;
                    u0 ^= (0xffffffffu >> (2u & 31u));
                    *q0 += ((u1 + v0) | 0x7fffffffu);
                } else {
                    u0 = (unsigned)!(r0.y << ((unsigned)(signed char)(3u % (i0 | 1u)) & 31u));
                }
                default: ;
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(8u < (unsigned)(0x3de215a3u == m0)), (unsigned)(short)((unsigned)b0 + 0x69870687u), v0); }
                    case 6u: ;
                }
            }
            e0 = e0 * 0.5L + (long double)((unsigned)(signed char)(unsigned)((g0 >> (~(unsigned)(0x48a80c7du < 8u) & 31u)) || (unsigned)(*mp && u1)) & 1023u);
            L2: if (--fuel == 0u) goto done;
            switch ((unsigned)(0x7fffffffu && g0) & 7u) {
                garr[((unsigned)s0 ^ g1) & 7u] = ((unsigned)(unsigned char)(unsigned)((unsigned)w0 || (unsigned)h1) * i0);
                w0 ^= (unsigned long long)p0 << ((unsigned)(v0 || (unsigned)((int)(unsigned)((unsigned)((int)v0 >= (int)(unsigned)h1) && m0) >= (int)a0[u1 & 3u])) & 63u);
                if (u0) goto L0;
                { unsigned t1; double z1; if (((unsigned)((int)9u < (int)(garr[u2 & 7u] / (0x3d60aebau | 1u)))) & 1u) { t1 = (unsigned)((unsigned)((int)(unsigned)e0 < (int)0x13dd207u) < (unsigned)w0); z1 = (double)((((unsigned)(a0[u1 & 3u] && g1) - r0.x)) & 255u); } if (((unsigned)((int)9u < (int)(garr[u2 & 7u] / (0x3d60aebau | 1u)))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                    i0 = ((unsigned)f0 & (unsigned)!(unsigned)((short)(unsigned)(0x80000000u && 0x7fffffffu) > (signed char)0x7fffffffu)) & 15u;
                    *mp = p2;
                    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)c1 / ((unsigned)c0 | 1u)), 0x7de5868cu, ((unsigned)s1 % (r0.x | 1u))); }
                }
                goto L4;
            }
            c0 = (unsigned char)((unsigned)((unsigned)((short)u0 > (signed char)3u) < m0) % ((unsigned)(p0 && 5u) | 1u));
            g1 += (unsigned)(signed char)(u2 | (unsigned)((int)((unsigned)c1 - (unsigned)(signed char)(4u >> ((unsigned)d0 & 31u))) < (int)0x4ad8e705u));
        }
        s0 = (int)((unsigned)(signed char)(unsigned)((short)(unsigned)f0 > (signed char)((0x10000u / (u3 | 1u)) / (r0.x | 1u))) % (a0[i0 & 3u] | 1u));
        if (budget != 0u) { budget -= 1u; u3 = fn1(r0.y, ((unsigned)s0 & v0), ~((unsigned)(u1 && garr[u2 & 7u]) * a0[i0 & 3u])); }
        if (budget != 0u) { budget -= 1u; u0 = fn1(g0, a0[i0 & 3u], (unsigned)((short)*mp > (signed char)v0)); }
        switch ((m0 ^ (unsigned)!((unsigned)(w0 >> 29) >> ((unsigned)b0 & 31u))) & 7u) {
            b0 = (unsigned)((0x10000u >> (a0[u1 & 3u] & 31u)) == u3) != 0u;
            a0[r0.x & 3u] = i1;
            if ((unsigned)((int)0xffffffffu < (int)0u)) {
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)(0x511cb6c2u || u3)) < (p1 / ((unsigned)h0 | 1u))) & 1023u);
                if ((unsigned)x0) {
                    c1 = (signed char)(0xc88f58eu << ((unsigned)(p1 == (unsigned)d0) & 31u));
                    l0 = (long)((unsigned long)l0 + *mp);
                    if ((unsigned)(0xffffffffu < (unsigned)f0)) break;
                    u0 = u0 * 0x9e3779b1u + ((((unsigned)(x0 >> 70) ^ 9u) + (unsigned)d0) * 0x3113897bu);
                } else {
                    l0 = (long)((unsigned long)l0 + (unsigned)(r0.x == i0));
                    { unsigned t2; double z2; if ((((unsigned)(7u < g0) * (unsigned)h1)) & 1u) { t2 = (m0 % ((unsigned)e0 | 1u)); z2 = (double)((3u) & 255u); } if ((((unsigned)(7u < g0) * (unsigned)h1)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                        goto done;
                        { unsigned t3; double z3; if ((m0) & 1u) { t3 = ((unsigned)c0 + a0[i0 & 3u]); z3 = (double)(((0x9fd682fcu << ((unsigned)(x0 >> 70) & 31u))) & 255u); } if ((m0) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                            L3: if (--fuel == 0u) goto done;
                            g1 += (unsigned)((0xffffffffu << (3u & 31u)) == *q0);
                            a0[*mp & 3u] = ~((unsigned)b0 / (((g1 + 0x80000000u) + (unsigned)c1) | 1u));
                        }
                        L4: if (--fuel == 0u) goto done;
                        b0 = (garr[i1 & 7u] | (unsigned)((int)p1 >= (int)r0.x)) != 0u;
                    }
                    g0 = 0x80000000u;
                }
                garr[(unsigned)((short)(unsigned)e0 > (signed char)(unsigned)s0) & 7u] = (unsigned)(((unsigned)s0 >> (p2 & 31u)) || 0xffffffffu);
                if (garr[u2 & 7u]) {
                    for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        g0 = (unsigned)c0;
                        while (i2++ < 7u && (unsigned)s1) { if (--fuel == 0u) goto done;
                            break; (void)((unsigned)((short)((unsigned)h1 % (garr[i1 & 7u] | 1u)) > (signed char)(unsigned)(w0 >> 29)));
                            u2 = u2 * 0x9e3779b1u + 8u;
                            b0 = (unsigned)((unsigned)((g1 % (0x4bdfa8ccu | 1u)) || 0xa339120fu) < -(v0 * (unsigned)s0)) != 0u;
                            s1 = (int)((unsigned)s1 + ((unsigned)d0 ^ (unsigned)l0));
                            s1 = (int)((unsigned)s1 + (unsigned)!(((unsigned)d0 << (3u & 31u)) ^ (unsigned)x0));
                            h0 = (short)0x7fffffffu;
                        }
                        case 4u: ;
                        if ((unsigned)((i1 | (unsigned)s0) || 2u)) goto L0;
                    }
                    { unsigned t4; double z4; if ((fuel) & 1u) { t4 = (0x7fffffffu >> (0x2f10719bu & 31u)); z4 = (double)((((unsigned)h1 >> (0x10000u & 31u))) & 255u); } if ((fuel) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                        a0[0x80000000u & 3u] = (unsigned)((int)-((unsigned)h1 - m0) < (int)((unsigned)l0 - (unsigned)!(0x7fffffffu / (r0.y | 1u))));
                    }
                }
            }
            u3 = u3 * 0x9e3779b1u + 0xffffffffu;
            switch ((unsigned)((unsigned)(x0 >> 70) && garr[i1 & 7u]) & 7u) {
                x0 = x0 * 0x100000001b3ull + ((unsigned)w0 | (unsigned)((int)(unsigned)((int)(0x70f9d66u | 1u) < (int)garr[u2 & 7u]) >= (int)v0));
                if ((unsigned)d0) goto L1;
            }
            { unsigned t5; double z5; if (((unsigned)x0) & 1u) { t5 = (unsigned)(0u < i0); z5 = (double)(((unsigned)!((unsigned)w0 - a0[u1 & 3u])) & 255u); } if (((unsigned)x0) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                r0.y ^= (unsigned)((unsigned)((unsigned)h0 < ((unsigned)((short)m0 > (signed char)u0) / ((unsigned)f0 | 1u))) == fuel);
                while (i1++ < 4u && (unsigned)((unsigned)x0 && r0.x)) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(w0 >> 29), (u0 + (unsigned)((int)(unsigned)e0 < (int)6u)), (unsigned)(p0 < (unsigned)(garr[u2 & 7u] && u1))); }
                    g1 += (unsigned)((short)((unsigned)h0 | (unsigned)(0x7fffffffu < a0[u1 & 3u])) > (signed char)(unsigned)((unsigned)x0 == u0));
                }
            }
        }
    }
    u0 ^= (5u | ((unsigned)((short)garr[i1 & 7u] > (signed char)garr[i1 & 7u]) / ((unsigned)(signed char)(a0[u1 & 3u] ^ (unsigned)s1) | 1u)));
    if (p0) goto L0;
    f0 = f0 * 0.5f + (float)((unsigned)(r0.x < u1) & 255u);
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t6; double z6; if ((u1) & 1u) { t6 = (unsigned)(unsigned char)(7u + (fuel + v0)); z6 = (double)((garr[u2 & 7u]) & 255u); } if ((u1) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((3u & (*mp + (unsigned)(x0 >> 70)))) break;
                break; (void)((m0 << ((unsigned)(x0 >> 70) & 31u)));
                if (budget != 0u) { budget -= 1u; u1 = fn1(fuel, (unsigned)!(p2 << (u2 & 31u)), (2u % (0xffffffffu | 1u))); }
            }
            if ((unsigned)l0) {
                s0 = (int)(fuel % (-(unsigned)((int)((unsigned)((int)5u < (int)3u) + 1u) < (int)(unsigned)w0) | 1u));
                if (budget != 0u) { budget -= 1u; u0 = fn0((0x7e476cf4u ^ u1), -(unsigned)(i0 < (unsigned)x0), i1); }
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    h0 = (short)(*mp << (v0 & 31u));
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(signed char)((p2 << ((unsigned)s1 & 31u)) * 0x7fffffffu), (unsigned)((unsigned)h1 < (3u ^ 0xab5c7fbau)), (unsigned)(x0 >> 70)); }
                    do { if (--fuel == 0u) goto done;
                        g0 = ((unsigned)f0 + r0.y);
                        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                            if ((unsigned)(signed char)(unsigned)((int)g1 >= (int)(unsigned)(4u == g0))) continue;
                        }
                        if ((unsigned)l0) break;
                    } while (i2++ < 4u && i2);
                    if (u3 == 7u) return (3u ^ (unsigned)((int)(unsigned)x0 >= (int)0xffffffffu));
                    if ((u3 * (0x4533c1a8u >> (0x80000000u & 31u)))) break;
                    if ((unsigned)(x0 >> 70)) break;
                }
            }
            do { if (--fuel == 0u) goto done;
                v0 = (((unsigned)(0x10000u == ((unsigned)x0 % (0xdbcd2c32u | 1u))) & u3) / (2u | 1u));
                break; (void)(((unsigned)(w0 >> 29) + 0xffffffffu));
                break; (void)(0x202e1216u);
                if ((unsigned)((int)(unsigned)!(p0 % ((unsigned)(w0 >> 29) | 1u)) < (int)0xa849780cu)) break;
                a0[m0 & 3u] = (-((unsigned)s0 << ((r0.y | 0xfb767027u) & 31u)) & (i1 - i0));
            } while (i1++ < 5u && ((unsigned)s1 ^ 0x75a1acf7u));
            garr[g1 & 7u] = (unsigned)((g1 / (((u0 - u0) + r0.y) | 1u)) < fuel);
        }
        while (i1++ < 4u && v0) { if (--fuel == 0u) goto done;
            i2 = ((unsigned)((unsigned)l0 && 7u) * 8u) & 15u;
            if (((unsigned)e0 - m0)) {
                w0 ^= (unsigned long long)u1 << (((9u % (((unsigned)(x0 >> 70) & (unsigned)s1) | 1u)) & 9u) & 63u);
                break; (void)((a0[i0 & 3u] / ((unsigned)x0 | 1u)));
                u3 = u3 * 0x9e3779b1u + (unsigned)(short)(~(u3 & (unsigned)((unsigned)h1 && (unsigned)h0)) >> ((u1 * r0.x) & 31u));
                if ((unsigned)h0) break;
                e0 = e0 * 0.5L + (long double)(p0 & 1023u);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)x0, (m0 ^ a0[u1 & 3u]), i2); }
            switch ((unsigned)(signed char)(unsigned)(-(0x458abe20u | (unsigned)s0) || 7u) & 7u) {
                case 0u: ;
                h0 = (short)(0xb5a66be8u * ((unsigned)e0 / (-(unsigned)((int)u1 >= (int)(unsigned)c1) | 1u)));
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)!(unsigned)((unsigned)l0 && 0xa9ea88deu)) goto L4;
                    if ((unsigned)((int)8u >= (int)(unsigned)s0)) goto L2;
                } while (i2++ < 7u && (8u << (g1 & 31u)));
            }
            h1 = (unsigned short)(h1 + (u3 * ((unsigned)(*q0 < m0) % ((unsigned)((unsigned)c0 < i1) | 1u))));
            for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (unsigned)((short)garr[u2 & 7u] > (signed char)-(0x7fffffffu << ((unsigned)w0 & 31u))));
                s1 = (int)((unsigned)s1 + (unsigned)(signed char)((unsigned)(unsigned char)(g0 | u2) ? (v0 | 0x80000000u) : 0x9fdd9b4au));
                if ((unsigned)((unsigned)w0 || (unsigned)c0)) goto L2;
                if (budget != 0u) { budget -= 1u; u2 = fn0((u3 ^ v0), (a0[u1 & 3u] - (unsigned)(x0 >> 70)), i0); }
                e0 = e0 * 0.5L + (long double)((((r0.y & (unsigned)s1) ? 0x10000u : 0x7fffffffu) * u1) & 1023u);
            }
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)f0, (unsigned)f0, (0x352dce62u & (unsigned)s1)); }
        if ((unsigned)e0) {
            do { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + 0x115e8bdbu);
                s0 = (int)0x3d3ba1bfu;
                if ((unsigned)((short)0x9c5a45a0u > (signed char)(unsigned)(x0 >> 70))) break;
                l0 = (long)((unsigned long)l0 + (unsigned)(short)(6u | ((unsigned)(signed char)((unsigned)c1 & (unsigned)b0) / (0x7fffffffu | 1u))));
                break; (void)((unsigned)((short)i2 > (signed char)(unsigned)(0x10000u < 0u)));
            } while (i1++ < 3u && (0u * u0));
            for (;;) { if (--fuel == 0u) goto done;
                *mp = (0xa8df5c6du << ((unsigned)((p2 >> (0xffffffffu & 31u)) == 5u) & 31u));
                if ((p0 << (8u & 31u))) break;
                u2 = (unsigned)((unsigned)c0 && (unsigned)((int)p1 < (int)*q0));
            }
            if ((unsigned)(unsigned char)((unsigned)h1 / (((unsigned)(x0 >> 70) - u1) | 1u))) continue;
        } else {
            if (0xfefa52bdu) break;
            *q0 = (unsigned)e0;
            u0 ^= -(unsigned)(p1 && 0xa1c061f1u);
            while ((unsigned)c1) { if (--fuel == 0u) goto done;
                b0 = (0x80000000u % (v0 | 1u)) != 0u;
                x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)b0 == v0);
                w0 = w0 * 6364136223846793005ull + (unsigned)(0x14db8b3bu < ((p2 & (unsigned)e0) ^ i2));
                s0 = (int)(0x135ba43u / ((p0 - (unsigned)s0) | 1u));
            }
        }
    }
    if (i1) {
        if ((unsigned)x0) goto L2;
        garr[(u3 << (i0 & 31u)) & 7u] = (unsigned)((unsigned)(signed char)(unsigned)((short)(unsigned)e0 > (signed char)7u) == (unsigned)(a0[u1 & 3u] && m0));
        u1 ^= (unsigned)!(u3 % (((1u | *q0) % ((unsigned)(0x80000000u && p2) | 1u)) | 1u));
        m0 ^= ((unsigned)((unsigned)c1 && 9u) | (u3 & i0));
    } else {
        if ((u3 | 8u)) goto L2;
        h1 = (unsigned short)(h1 + (unsigned)((unsigned)(unsigned char)(p2 | i1) || (unsigned)(w0 >> 29)));
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1(4u, ((unsigned)s1 + 0x80000000u), g1); }
    if (g1) goto L1;
    { unsigned t7; double z7; if (((unsigned)((int)6u < (int)0x363d2297u)) & 1u) { t7 = ((unsigned)((int)7u >= (int)0xbd15b454u) << (u0 & 31u)); z7 = (double)(((i0 >> ((unsigned)((unsigned)c1 || 0xb06999u) & 31u))) & 255u); } if (((unsigned)((int)6u < (int)0x363d2297u)) & 1u) { u0 += t7; d0 = d0 * 0.5 + z7; }
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(garr[i1 & 7u] == u1), (unsigned)!(unsigned)(6u == (1u ^ 0x10000u)), ~(0x10000u % ((unsigned)((int)(unsigned)x0 < (int)v0) | 1u))); }
    }
    goto L3;
    goto L0;
    i2 = ((unsigned)c0 ^ (~((unsigned)h1 << (m0 & 31u)) - (u0 % (0xffffffffu | 1u)))) & 15u;
    f0 = f0 * 0.5f + (float)(((unsigned)d0 - a0[i0 & 3u]) & 255u);
    do { if (--fuel == 0u) goto done;
        u2 = v0;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t8; double z8; if (((unsigned)w0) & 1u) { t8 = (r0.y - (garr[u2 & 7u] * g0)); z8 = (double)(((unsigned)l0) & 255u); } if (((unsigned)w0) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                garr[i0 & 7u] = (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)((unsigned)e0 && (unsigned)s1));
                q0 = &garr[((unsigned)c1 * (unsigned)s1) & 7u];
                while (i2++ < 2u && (0u | (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                    while ((unsigned)(((unsigned)h0 | g1) || garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                        s0 = (int)(unsigned)(0x80000000u == ((unsigned)l0 - ((unsigned)l0 * 0u)));
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)(w0 >> 29) && a0[i0 & 3u]) && 8u), (i0 - v0), 8u); }
                        break; (void)((((unsigned)e0 / (0u | 1u)) % (p1 | 1u)));
                    }
                    u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)c1 || 6u);
                    if (budget != 0u) { budget -= 1u; u1 = fn1((0x7322af6eu - r0.y), (unsigned)((int)(unsigned)l0 < (int)(unsigned)e0), ((unsigned)e0 >> ((unsigned)h0 & 31u))); }
                    m0 ^= ((unsigned)s0 ? ((unsigned)w0 ? *mp : *q0) : 0xffffffffu);
                    garr[u3 & 7u] = (unsigned)((short)0u > (signed char)a0[u1 & 3u]);
                    while (i0++ < 4u && ((unsigned)c1 ^ i0)) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)h0, (*mp ^ 0x91830d5au), (unsigned)!((unsigned)f0 % ((g1 >> (g0 & 31u)) | 1u))); }
                        if (budget != 0u) { budget -= 1u; u2 = fn0((a0[i0 & 3u] | 0xa847039u), (unsigned)((short)(unsigned)h0 > (signed char)~(unsigned)((unsigned)h1 < (unsigned)e0)), u1); }
                        if ((0x51b66585u + 0u)) break;
                        if (((unsigned)h0 << (0x10000u & 31u))) break;
                    }
                }
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)e0) continue;
                    while (i0++ < 7u && ((g0 - 2u) >> ((unsigned)d0 & 31u))) { if (--fuel == 0u) goto done;
                        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                            l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)(unsigned char)(unsigned)((int)(unsigned)h1 >= (int)(unsigned)w0) | 3u) && (unsigned)h1));
                            if (a0[i0 & 3u]) break;
                        }
                        f0 = f0 * 0.5f + (float)(((unsigned)w0 >> ((unsigned)s0 & 31u)) & 255u);
                        if (0xffffffffu) continue;
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)s0 ^ i2), (unsigned)h0, (0x4054bffcu | (p1 + 0xa911af1du))); }
                    w0 ^= (unsigned long long)-(unsigned)((unsigned)(x0 >> 70) && fuel) << (g1 & 63u);
                }
            }
            u3 = (unsigned)((short)(unsigned)c0 > (signed char)(g0 | (unsigned)(0x80000000u < 0x7fffffffu)));
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(short)(u1 / (*mp | 1u)), ((unsigned)s1 & 0xffffffffu), (unsigned)(unsigned char)(0x80000000u % (u2 | 1u))); }
            garr[(3u / (0u | 1u)) & 7u] = (r0.y - (p1 << ((i1 - (6u >> (u1 & 31u))) & 31u)));
            r0.x = ((unsigned)((unsigned)x0 || p2) / ((0xf892cf1au - 0x7fffffffu) | 1u));
            goto done;
        }
        if (((unsigned)((int)(unsigned)f0 >= (int)7u) * (unsigned)f0)) {
            u2 = u2 * 0x9e3779b1u + (unsigned)!(((0xec4cb6a2u * p0) % (0x10000u | 1u)) >> (0xffffffffu & 31u));
            if (budget != 0u) { budget -= 1u; u0 = fn0(0x10000u, ((u0 / (u1 | 1u)) & i2), -(unsigned)((short)(unsigned)((int)(unsigned)c0 < (int)7u) > (signed char)0x80000000u)); }
        }
        q0 = &garr[(unsigned)((int)i1 >= (int)(i1 ? (unsigned)(short)(unsigned)((short)(unsigned)b0 > (signed char)u1) : 2u)) & 7u];
        break; (void)(p2);
        i2 = (unsigned)(signed char)(unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)((unsigned)h1 < fuel)) & 15u;
    } while (i0++ < 7u && ((garr[i1 & 7u] / (u2 | 1u)) % (garr[i1 & 7u] | 1u)));
    if (budget != 0u) { budget -= 1u; u0 = fn1(2u, ((v0 & (unsigned)w0) - p0), ((unsigned)((short)i2 > (signed char)v0) << ((unsigned)f0 & 31u))); }
    i2 = ((unsigned)c0 << (p2 & 31u)) & 15u;
    v0 = (0xffffffffu >> (*q0 & 31u));
    a0[r0.y & 3u] = i2;
    if (budget != 0u) { budget -= 1u; u2 = fn0((0x90acdd98u * ((unsigned)(x0 >> 70) >> ((unsigned)c0 & 31u))), 0x78f6f8a3u, 0x1d678913u); }
    do { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (unsigned)(g0 && 0x7fffffffu);
    } while (i0++ < 7u && (u2 ^ (unsigned)h0));
    if (i1) goto L4;
    switch ((unsigned)(v0 && (unsigned)(0xa2bca90cu < 4u)) & 7u) {
        u2 ^= (unsigned)((int)(unsigned)(u1 || (unsigned)f0) >= (int)(garr[u2 & 7u] & 5u));
        e0 = e0 * 0.5L + (long double)((p2 % ((unsigned)l0 | 1u)) & 1023u);
        u0 = u0 * 0x9e3779b1u + (unsigned)((int)g0 >= (int)(unsigned)l0);
        a0[(8u + 0x707a74c6u) & 3u] = (unsigned)(r0.y || (unsigned)((unsigned)c1 && (unsigned)h1));
        g0 = i0;
        case 2u: ;
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        u2 = u2 * 0x9e3779b1u + (unsigned)((int)garr[i1 & 7u] >= (int)(unsigned)x0);
        h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(((unsigned)e0 & g0) + (unsigned)(signed char)(unsigned)(0u == (unsigned)x0)));
        u0 = u0 * 0x9e3779b1u + (p0 - 0u);
        if ((*mp ? *q0 : u0)) goto done;
        break; (void)((unsigned)((int)p0 < (int)a0[u1 & 3u]));
    }
    goto L0;
    c0 = (unsigned char)((unsigned)((short)(unsigned)(3u || ((unsigned)(x0 >> 70) | (unsigned)s1)) > (signed char)garr[i1 & 7u]) >> ((unsigned)h0 & 31u));
    if (((unsigned)b0 | *mp)) goto done;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && u1) { if (--fuel == 0u) goto done;
            if ((a0[u1 & 3u] >> (0x7a708bc8u & 31u))) break;
        }
        if ((u3 * u2)) break;
        if ((unsigned)(signed char)(unsigned)(0xffffffffu == *mp)) {
            for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)(unsigned)c1 > (signed char)p0)) break;
                m0 ^= (unsigned)((unsigned)d0 || (unsigned)(3u == 3u));
                a0[g1 & 3u] = 0xd8c00423u;
                continue; (void)((unsigned)(((unsigned)d0 - 5u) < 0x10000u));
            }
            w0 = w0 * 6364136223846793005ull + (0x10000u | ((0xc8d5743cu & u2) >> (0x10000u & 31u)));
            do { if (--fuel == 0u) goto done;
                r0.y ^= (unsigned)w0;
                g0 = (unsigned)l0;
            } while (i1++ < 2u && 8u);
            l0 = (long)((unsigned long)l0 + fuel);
            if (8u) {
                u1 = u1 * 0x9e3779b1u + ((unsigned)!((unsigned)s1 * 0u) << (0x10000u & 31u));
                s0 = (int)~(i2 & (unsigned)l0);
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = (unsigned)((int)(u2 ? a0[u1 & 3u] : 0xffffffffu) >= (int)(unsigned)((int)u1 >= (int)4u));
                    s0 = (int)(((0xe6992cc6u * 0x7fffffffu) >> (a0[u1 & 3u] & 31u)) + 0x7fffffffu);
                    if (((unsigned)c0 / ((*mp * 0x10000u) | 1u))) break;
                }
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)d0 == (unsigned)((int)0u < (int)(unsigned)b0)) & 1023u);
                b0 = (unsigned)s0 != 0u;
                break; (void)((5u << ((unsigned)(*mp && (unsigned)e0) & 31u)));
            } else {
                u2 ^= (unsigned)s0;
                h1 = (unsigned short)(h1 + v0);
            }
        }
    }
    while (i0++ < 7u && (unsigned)(short)(unsigned)(5u && (unsigned)(8u < garr[i1 & 7u]))) { if (--fuel == 0u) goto done;
        if (i0) break;
        if ((unsigned)s0) goto L3;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (*q0) break;
            b0 = (unsigned)(unsigned char)(unsigned)((int)0x69c0f891u >= (int)(0x92227a7fu * (unsigned)((garr[i1 & 7u] & 0x3cc6af9u) || u1))) != 0u;
            v0 = (p1 & -((0x1571fde0u ^ u2) << ((unsigned)c0 & 31u)));
            u2 = (unsigned)((int)0xdee0ba52u < (int)u2);
            if ((unsigned)(unsigned char)((0xffffffffu % ((unsigned)(x0 >> 70) | 1u)) / (u1 | 1u))) break;
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    switch (0x7fffffffu & 7u) {
        if (budget != 0u) { budget -= 1u; u3 = fn0(~(u2 >> (0xfcd35cb4u & 31u)), (unsigned)(unsigned char)(unsigned)((int)(unsigned)s0 < (int)garr[i1 & 7u]), (unsigned)((int)*mp < (int)(unsigned)((short)0x80000000u > (signed char)i0))); }
        { unsigned t0; double z0; if ((garr[i1 & 7u]) & 1u) { t0 = (unsigned)((int)(unsigned)s1 < (int)0x6d631ccu); z0 = (double)(((0xffffffffu ? u3 : (unsigned)s1)) & 255u); } if ((garr[i1 & 7u]) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
            if (g0) {
                if (((unsigned)(i0 && p0) >> (0x1f34450eu & 31u))) {
                    if (v0) break;
                    b0 = (unsigned)!(unsigned)((short)*q0 > (signed char)r0.y) != 0u;
                }
                if ((unsigned)l0) {
                    l0 = (long)((unsigned long)l0 + (unsigned)(short)((a0[u1 & 3u] << (i2 & 31u)) / ((0x7fffffffu ? 3u : 0xffffffffu) | 1u)));
                    do { if (--fuel == 0u) goto done;
                        switch (((unsigned)((unsigned)d0 == 0x80000000u) % (garr[i1 & 7u] | 1u)) & 7u) {
                            u0 ^= (unsigned)!(m0 | (0x7fffffffu | (unsigned)h1));
                            L0: if (--fuel == 0u) goto done;
                            s0 = (int)(r0.x - u2);
                            q0 = &garr[(0x80000000u << ((0x9c8ecaf2u ^ (unsigned)((unsigned)((int)(unsigned)l0 >= (int)0xffffffffu) && r0.y)) & 31u)) & 7u];
                        }
                        if (u3 == 7u) return ((unsigned)((int)(unsigned)x0 < (int)((unsigned)x0 << ((unsigned)h1 & 31u))) * ((unsigned)h0 | p2));
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)s1 * (unsigned)b0), (unsigned)(short)((unsigned)e0 | (unsigned)x0), (unsigned)(m0 || (unsigned)w0)); }
                        if ((0x7fffffffu & 5u)) break;
                        r0.x = (r0.x * ((unsigned)(2u && (unsigned)w0) | (unsigned)c1));
                        u3 += (((unsigned)((int)(unsigned)h1 < (int)(unsigned)s1) >> ((unsigned)c1 & 31u)) | 0x9fe190a6u);
                    } while (i0++ < 7u && (unsigned)(signed char)(unsigned)(p2 < (unsigned)s1));
                    if (budget != 0u) { budget -= 1u; u2 = fn1((0xa51ee95fu >> ((3u >> (i1 & 31u)) & 31u)), (0x10000u & p2), 0xf836d65eu); }
                    w0 ^= (unsigned long long)(p1 | v0) << ((unsigned)(short)(unsigned)((int)(((unsigned)b0 << (u3 & 31u)) * garr[i1 & 7u]) >= (int)0x4872d78fu) & 63u);
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(0x49ece225u || (v0 % (g0 | 1u))), (unsigned)((int)(0x45065293u << (0xffffffffu & 31u)) < (int)*mp), (unsigned)x0); }
                } else {
                    if (p2) goto L1;
                    garr[(unsigned)l0 & 7u] = (unsigned)(unsigned char)(0x201671fdu / (a0[u1 & 3u] | 1u));
                }
                w0 = w0 * 6364136223846793005ull + (fuel + (unsigned)((int)(unsigned)(x0 >> 70) < (int)(i1 ^ (unsigned)!(unsigned)((unsigned)x0 == u2))));
                *mp = (a0[u1 & 3u] ? u0 : (unsigned)h0);
                c0 = (unsigned char)(unsigned)((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)f0) < (unsigned)!(unsigned)(4u || 0x10000u));
            } else {
                case 1u: ;
                if (budget != 0u) { budget -= 1u; u2 = fn1((u1 ^ (unsigned)(short)(0x80000000u % (a0[i0 & 3u] | 1u))), m0, (unsigned)(u2 && 0xa722e823u)); }
                switch (~(unsigned)(r0.x == (unsigned)(signed char)(unsigned)((unsigned)s1 < (unsigned)f0)) & 7u) {
                    h0 = (short)g0;
                    b0 = garr[u2 & 7u] != 0u;
                    if (budget != 0u) { budget -= 1u; u3 = fn2(0xdb13c4c9u, 0x169df028u, ((unsigned)((int)*q0 < (int)8u) * (unsigned)s0)); }
                    if ((a0[u1 & 3u] % (0xffffffffu | 1u))) goto L3;
                    garr[(unsigned)(w0 >> 29) & 7u] = (0x57242985u >> ((unsigned)(0x10000u || 0x6951ee72u) & 31u));
                }
                if ((0x10000u / ((unsigned)(*q0 < g1) | 1u))) goto done;
            }
            g0 = ((unsigned)c1 ? (unsigned)((int)p2 >= (int)0xc043329au) : (0x7fffffffu << (8u & 31u)));
            r0.y ^= (unsigned)!(unsigned)((int)0x80000000u < (int)(unsigned)((int)i0 < (int)0xffffffffu));
            switch ((unsigned)(short)(unsigned)((unsigned)(w0 >> 29) || p0) & 7u) {
                x0 = x0 * 0x100000001b3ull + (unsigned)(0x7fffffffu && 8u);
                i0 = ((unsigned)!(unsigned)((short)garr[i1 & 7u] > (signed char)u2) + (unsigned)(x0 >> 70)) & 15u;
            }
            if (p0) {
                r0.x = ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)x0) | (unsigned)l0);
                goto L2;
                L1: if (--fuel == 0u) goto done;
            }
        }
        if (u3 == 7u) return (unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)(unsigned char)((unsigned)s1 % (garr[u2 & 7u] | 1u)));
    }
    { unsigned t1; double z1; if (((unsigned)(0x1088036au || fuel)) & 1u) { t1 = ((0xd9fa71e0u << (u2 & 31u)) & 0u); z1 = (double)(((unsigned)(unsigned char)((unsigned)f0 << (v0 & 31u))) & 255u); } if (((unsigned)(0x1088036au || fuel)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
        L2: if (--fuel == 0u) goto done;
        if (fuel < 8u) return (unsigned)s0;
        if (a0[u1 & 3u]) goto L2;
        if (p0) goto L0;
        s1 = (int)((unsigned)s1 + -(0x5ec6619cu >> ((unsigned)(3u == (unsigned)(unsigned char)(unsigned)((int)i0 < (int)(unsigned)x0)) & 31u)));
    }
    goto L4;
    e0 = e0 * 0.5L + (long double)(((5u << ((unsigned)(signed char)(0xd3cf2f15u << ((unsigned)b0 & 31u)) & 31u)) & r0.y) & 1023u);
    l0 = (long)((unsigned long)l0 + (unsigned)(i2 == ((unsigned)h0 & (unsigned)h0)));
    if ((unsigned)((short)(unsigned)(g0 == 0x7fffffffu) > (signed char)0x10000u)) {
        if (-(unsigned)((short)(unsigned)c0 > (signed char)(unsigned)s1)) goto done;
        if (((unsigned)(g0 < 8u) * i1)) goto L0;
        m0 ^= (unsigned)(garr[i1 & 7u] == (unsigned)l0);
        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((unsigned)c0 || (0xe2ddedeau << (8u & 31u))), (i0 % (p2 | 1u)), (u1 | (unsigned)!(unsigned)((int)(unsigned)w0 < (int)0x7fffffffu))); }
    } else {
        if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)!(i1 + p1) % (u3 | 1u)), (unsigned)((int)2u < (int)~(unsigned)(p2 == 7u)), (0xdc6067a1u - (unsigned)!(unsigned)((short)0xcb6e0352u > (signed char)8u))); }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t2; double z2; if ((((0x7fffffffu << (v0 & 31u)) - 0x80000000u)) & 1u) { t2 = (unsigned)(0xffffffffu == (a0[u1 & 3u] + 0x10000u)); z2 = (double)((0x7df00901u) & 255u); } if ((((0x7fffffffu << (v0 & 31u)) - 0x80000000u)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                if ((u0 * 1u)) break;
                for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    L3: if (--fuel == 0u) goto done;
                    break; (void)(5u);
                    if ((unsigned)((unsigned)((unsigned)l0 || v0) == *q0)) break;
                    w0 ^= (unsigned long long)(unsigned)h1 << ((unsigned)((int)((unsigned)l0 | (unsigned)h0) < (int)(unsigned)h0) & 63u);
                }
                q0 = &garr[(unsigned)!(unsigned)((short)p1 > (signed char)(~(garr[u2 & 7u] + (unsigned)!(garr[u2 & 7u] * 2u)) | v0)) & 7u];
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)u1 > (signed char)(unsigned)((short)7u > (signed char)(v0 ^ 6u)));
            }
            g1 += (g1 / ((unsigned)(0x8685bb5au && 2u) | 1u));
            if ((unsigned)(a0[i0 & 3u] < (unsigned)s0)) {
                if ((unsigned)(signed char)(0xffffffffu / (g1 | 1u))) break;
                *mp = 0x14cef298u;
                w0 = w0 * 6364136223846793005ull + ((unsigned)c0 - (8u - 9u));
                m0 ^= (0x10000u >> (((unsigned)(x0 >> 70) - ((0x62ac275bu ^ 0x10000u) - (unsigned)f0)) & 31u));
                r0.x = ~((0x7fffffffu / (0x80000000u | 1u)) % (((unsigned)d0 | (a0[u1 & 3u] + (unsigned)l0)) | 1u));
            }
        }
        garr[(9u - (unsigned)c0) & 7u] = (unsigned)(fuel < ((unsigned)c0 * ((unsigned)s0 ? 0xbe12de8au : (unsigned)x0)));
    }
    x0 = x0 * 0x100000001b3ull + (unsigned)(2u || (u0 / ((0xffffffffu + (unsigned)s0) | 1u)));
    if ((a0[u1 & 3u] + garr[u2 & 7u])) {
        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)((fuel & (unsigned)s0) == (unsigned)(0x54b9b522u && 0x6bc22985u));
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(u2);
                { unsigned t3; double z3; if ((-(unsigned)(g1 || i2)) & 1u) { t3 = (r0.x << ((unsigned)b0 & 31u)); z3 = (double)(((unsigned)x0) & 255u); } if ((-(unsigned)(g1 || i2)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    *q0 = (unsigned)((unsigned)w0 == ~((unsigned)h0 & (0x10000u & (unsigned)s1)));
                    break; (void)((unsigned)(0xfbb21a3eu || 0x10000u));
                    if (budget != 0u) { budget -= 1u; u2 = fn1(a0[u1 & 3u], (unsigned)((short)8u > (signed char)0x2c5bc12u), (r0.x >> ((unsigned)((unsigned)d0 < p1) & 31u))); }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)((unsigned)e0 && garr[u2 & 7u])), u2, p1); }
                }
            }
            w0 ^= (unsigned long long)(unsigned)((unsigned)d0 < (unsigned)x0) << ((unsigned)(0x8189d260u == (unsigned)((unsigned)(i2 == (unsigned)b0) < garr[i1 & 7u])) & 63u);
            if (-(unsigned)((unsigned)(0xefd11d7eu < 0x17cf79cau) == (unsigned)(w0 >> 29))) continue;
            f0 = f0 * 0.5f + (float)((unsigned)((int)8u >= (int)garr[i1 & 7u]) & 255u);
        }
        switch ((garr[i1 & 7u] ? i1 : 0x6bb5c428u) & 7u) {
            if (~((unsigned)l0 + (unsigned)((int)*q0 >= (int)0xffffffffu))) {
                w0 = w0 * 6364136223846793005ull + ((a0[i0 & 3u] | (unsigned)((unsigned)s1 && (unsigned)d0)) | g1);
                if (v0) {
                    if ((unsigned)(a0[i0 & 3u] < (unsigned)d0)) break;
                    w0 ^= (unsigned long long)-(4u << (r0.x & 31u)) << ((unsigned)(short)((unsigned)(signed char)(p1 >> ((unsigned)s1 & 31u)) * a0[u1 & 3u]) & 63u);
                }
            }
            if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(i0 == u0) + i0), (unsigned)(garr[i1 & 7u] && a0[i0 & 3u]), (i2 & i2)); }
            goto L0;
            case 4u: ;
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t4; double z4; if ((a0[u1 & 3u]) & 1u) { t4 = (unsigned)w0; z4 = (double)(((unsigned)(short)(unsigned)(garr[u2 & 7u] || i0)) & 255u); } if ((a0[u1 & 3u]) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                    if (1u) continue;
                }
                case 3u: ;
                if ((p2 ^ g0)) continue;
                break; (void)(((unsigned)w0 & (r0.x * 4u)));
                case 5u: ;
            }
            d0 = d0 * 0.5 + (double)(((garr[i1 & 7u] ? (unsigned)s0 : p0) >> (garr[u2 & 7u] & 31u)) & 1023u);
        }
        if (u3 == 7u) return (unsigned)((unsigned)f0 || fuel);
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            *q0 += (unsigned)((short)(unsigned)(unsigned char)(0x58b80ef3u + (unsigned)(p1 || (unsigned)s0)) > (signed char)0x3e56624bu);
            c1 = (signed char)(r0.x * (unsigned)((int)(unsigned)s1 < (int)(unsigned)f0));
            goto L0;
            g1 += (unsigned)((int)6u >= (int)0x2ee9f905u);
        }
        r0.y ^= (i2 >> ((a0[i0 & 3u] >> ((unsigned)(w0 >> 29) & 31u)) & 31u));
        if ((garr[u2 & 7u] | r0.x)) goto L2;
    }
    goto L0;
    b0 = 0xffffffffu != 0u;
    if (((0x915e9f60u | (unsigned)x0) << (8u & 31u))) {
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)((unsigned)e0 | i0)) break;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)l0), ((0x7fffffffu - (unsigned)c0) | p1), ((unsigned)h0 & i1)); }
        }
        garr[(unsigned)(0x70947bafu || p0) & 7u] = ((v0 & 0x7fffffffu) & 0x80000000u);
        if (m0) goto L3;
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(0xfc9d7a38u);
    }
    g1 += 9u;
    switch ((2u + (unsigned)(g0 < 0xc9bec448u)) & 7u) {
        if (budget != 0u) { budget -= 1u; u2 = fn0(g0, (unsigned)((unsigned)c1 && (unsigned)s0), 0x10000u); }
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + ((unsigned)s1 << ((unsigned)(short)(unsigned)((int)u1 < (int)1u) & 31u));
            case 0u: ;
            w0 ^= (unsigned long long)(i1 & a0[i0 & 3u]) << ((unsigned)((unsigned)(unsigned char)(i2 + garr[u2 & 7u]) < ((unsigned)(0xffffffffu || i1) | *q0)) & 63u);
            if (0x80000000u) continue;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn2(0x7fffffffu, (g0 / ((u3 % (u1 | 1u)) | 1u)), ((unsigned)w0 * 0x10000u)); }
    }
    if ((0u + r0.x)) goto L0;
    if ((g0 ^ (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)l0))) {
        do { if (--fuel == 0u) goto done;
            i2 = (unsigned)((7u * garr[u2 & 7u]) && u3) & 15u;
            if (u0) {
                L4: if (--fuel == 0u) goto done;
                goto L1;
            } else {
                break; (void)(((p1 | 0xdbb0e94du) % (p1 | 1u)));
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(0x7fffffffu < i0), (0x6eec3b98u << ((unsigned)c0 & 31u)), ((unsigned)((short)garr[i1 & 7u] > (signed char)0x10000u) + (unsigned)h1)); }
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)b0, fuel, (unsigned)((short)(0xf9b2277eu - (unsigned)c0) > (signed char)(unsigned)c0)); }
            }
            l0 = (long)((unsigned long)l0 + ((p0 & (fuel * u0)) >> ((unsigned)((unsigned)x0 < 0x10000u) & 31u)));
        } while (i0++ < 7u && ((unsigned)s0 | a0[i0 & 3u]));
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            g0 = (-(unsigned)((unsigned)(x0 >> 70) || 0x80000000u) ^ (3u >> ((unsigned)(short)(0x7fffffffu % (a0[i0 & 3u] | 1u)) & 31u)));
            if (((unsigned)d0 % ((unsigned)s0 | 1u))) goto L4;
            for (;;) { if (--fuel == 0u) goto done;
                r0.y ^= (unsigned)((int)i2 < (int)(unsigned)c1);
                if ((unsigned)(unsigned char)(unsigned)(0xffffffffu == 0x4fe03c4au)) break;
                l0 = (long)((unsigned long)l0 + garr[u2 & 7u]);
                if ((0xeab1d2f3u | 0x7fffffffu)) break;
                m0 ^= (unsigned)(((unsigned)x0 & u2) && (u3 >> ((1u - 0x720bdd47u) & 31u)));
                g0 = ((0x10000u ? g1 : i0) >> ((u0 | 0xffffffffu) & 31u));
            }
            g0 = g0;
        }
    }
    g0 = ((0x1f195cbu ? fuel : 0xffffffffu) | (unsigned)(short)(unsigned)((int)fuel < (int)p0));
    if ((p0 & ((unsigned)l0 ^ u3))) goto L2;
    i1 = 0xe90d74b6u & 15u;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)b0 & 7u) {
            while (i1++ < 7u && (unsigned)(v0 && (unsigned)l0)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)c0, -((u1 * p0) + 0xf74f306cu), (i0 - v0)); }
                case 6u: ;
                f0 = f0 * 0.5f + (float)((unsigned)(0x4954762cu == ((unsigned)d0 ^ 0xa0074857u)) & 255u);
                if ((p1 >> ((unsigned)e0 & 31u))) break;
            }
        }
        { unsigned t5; double z5; if ((~(unsigned)((int)p1 < (int)(unsigned)b0)) & 1u) { t5 = ((unsigned)f0 - r0.y); z5 = (double)((a0[u1 & 3u]) & 255u); } if ((~(unsigned)((int)p1 < (int)(unsigned)b0)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
            u0 ^= a0[u1 & 3u];
            if ((unsigned)d0) break;
            if ((unsigned)((int)garr[i1 & 7u] < (int)0x10000u)) break;
        }
    }
    if ((unsigned)(v0 && (0x80000000u + r0.x))) goto L1;
    if ((unsigned)(unsigned char)(unsigned)((int)(i0 - (unsigned)(x0 >> 70)) < (int)(unsigned)f0)) {
        goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn1(0x7fffffffu, (i2 >> (0x80000000u & 31u)), (unsigned)((int)(unsigned)(signed char)(*q0 >> (*q0 & 31u)) >= (int)r0.x)); }
        goto L0;
        a0[0xeec64ddeu & 3u] = ~(unsigned)((int)i1 < (int)(i0 << ((unsigned)(x0 >> 70) & 31u)));
    }
    goto L1;
    switch (((unsigned)(a0[i0 & 3u] && (unsigned)(x0 >> 70)) | 5u) & 7u) {
        u2 = u2 * 0x9e3779b1u + (unsigned)((short)p0 > (signed char)(fuel + p1));
        w0 ^= (unsigned long long)((unsigned)h0 + g0) << ((unsigned)((int)(unsigned)((unsigned)w0 == p1) >= (int)(unsigned)((u1 % (0x52032403u | 1u)) || i0)) & 63u);
        w0 ^= (unsigned long long)(unsigned)(8u == 5u) << ((unsigned)((unsigned)((unsigned)((0xffffffffu / (a0[i0 & 3u] | 1u)) < u2) || (unsigned)(x0 >> 70)) && a0[i0 & 3u]) & 63u);
        if ((garr[i1 & 7u] ? g1 : (unsigned)s0)) {
            if ((0xcab6ed76u & (unsigned)s0)) goto L2;
            if (p0) {
                if ((((unsigned)(x0 >> 70) ^ 6u) << ((unsigned)s0 & 31u))) {
                    d0 = d0 * 0.5 + (double)((unsigned)((*q0 | (unsigned)((short)0x80000000u > (signed char)a0[u1 & 3u])) == (unsigned)f0) & 1023u);
                    if (budget != 0u) { budget -= 1u; u0 = fn2((0x10000u ? (unsigned)s0 : r0.x), (unsigned)((unsigned)(x0 >> 70) && (unsigned)(u0 == 0x10000u)), i1); }
                }
                d0 = d0 * 0.5 + (double)((unsigned)s1 & 1023u);
                case 3u: ;
            }
            u3 = u3 * 0x9e3779b1u + p2;
            f0 = f0 * 0.5f + (float)(((((i1 - u3) & (unsigned)(x0 >> 70)) >> (g0 & 31u)) & r0.x) & 255u);
        }
        if ((unsigned)((unsigned)d0 < (u3 * (unsigned)h0))) {
            if (budget != 0u) { budget -= 1u; u2 = fn1(p2, ((unsigned)(garr[u2 & 7u] < i2) * i1), (unsigned)(i1 == (unsigned)(short)(p2 & (unsigned)x0))); }
            if (budget != 0u) { budget -= 1u; u1 = fn2(garr[i1 & 7u], (unsigned)((unsigned)(0xf4e6475cu < 0x10000u) || u3), 0u); }
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(short)(unsigned)((unsigned)(0x2344a9bbu < 0xf9096e8bu) < 0x4722a80eu), m0, 9u); }
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                b0 = (unsigned)((int)u1 >= (int)0x690cc2cau) != 0u;
                if (budget != 0u) { budget -= 1u; u1 = fn2((u2 / ((unsigned)(p1 || (unsigned)c1) | 1u)), (unsigned)(unsigned char)(0x10000u & (unsigned)((int)(unsigned)e0 >= (int)*mp)), (-(r0.y + a0[i0 & 3u]) ^ 1u)); }
                u0 += (unsigned)(0x8694c8cfu || 0x1f09d202u);
                if (i2) {
                    g0 = (unsigned)s0;
                    c0 = (unsigned char)(unsigned)l0;
                    *mp = (unsigned)(p2 < u0);
                    s1 = (int)((unsigned)s1 + (((unsigned)e0 / ((unsigned)e0 | 1u)) << (i1 & 31u)));
                    if ((unsigned)(0x80000000u == (i1 % (v0 | 1u)))) continue;
                }
                u3 = (unsigned)(x0 >> 70);
            }
        }
    }
    if ((unsigned)h0) goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    L0: if (--fuel == 0u) goto done;
    h0 = (short)(unsigned)(i2 || g1);
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        c0 = (unsigned char)((unsigned)c1 + (((unsigned)s1 | (unsigned)(x0 >> 70)) & r0.x));
        if (u3 == 7u) return 0x80000000u;
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            i2 = 0u & 15u;
        }
        do { if (--fuel == 0u) goto done;
            L1: if (--fuel == 0u) goto done;
        } while (i1++ < 6u && (unsigned)((int)(unsigned)((unsigned)b0 && *q0) >= (int)0x26b83383u));
        u1 = u1 * 0x9e3779b1u + r0.x;
        e0 = e0 * 0.5L + (long double)(((unsigned)(w0 >> 29) | ((unsigned)!(0x10000u ^ (unsigned)(x0 >> 70)) >> ((unsigned)((unsigned)w0 < 5u) & 31u))) & 1023u);
    }
    u1 = (unsigned)((short)(unsigned)b0 > (signed char)(unsigned)(0x80000000u || 0xffffffffu));
    r0.x = (r0.y + (unsigned)(short)(2u - 0u));
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)w0 / ((2u + (unsigned)c1) | 1u)));
        { unsigned t0; double z0; if (((-(3u - 0x9c6df9eau) << (0x10000u & 31u))) & 1u) { t0 = *mp; z0 = (double)((((unsigned)((int)(unsigned)f0 >= (int)3u) | (unsigned)e0)) & 255u); } if (((-(3u - 0x9c6df9eau) << (0x10000u & 31u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            b0 = ~((unsigned)(0x7fffffffu == 0x7fffffffu) >> (*mp & 31u)) != 0u;
            if ((0x31bbb0b5u >> (fuel & 31u))) {
                if ((unsigned)((int)((unsigned)e0 - 0x7fffffffu) >= (int)(unsigned)f0)) {
                    m0 ^= (unsigned)(u1 || (0xffffffffu - (unsigned)((0x7fffffffu % (0x7750ff7bu | 1u)) == (unsigned)s0)));
                    if (budget != 0u) { budget -= 1u; u3 = fn2((0u & a0[i0 & 3u]), 0xffffffffu, (unsigned)(0xd6d44fc2u && (unsigned)c1)); }
                    x0 = x0 * 0x100000001b3ull + u1;
                }
                u1 ^= (unsigned)(0x80000000u == (0x80000000u << ((unsigned)c1 & 31u)));
            }
            w0 = w0 * 6364136223846793005ull + ((unsigned)l0 % ((u1 ^ g0) | 1u));
            *q0 = (unsigned)l0;
            r0.y ^= (unsigned)(unsigned char)(unsigned)(0xffffffffu && 0x80000000u);
        }
        g0 = (g1 % ((unsigned)l0 | 1u));
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            b0 = ((unsigned)((int)0x80000000u >= (int)((unsigned)e0 >> (*q0 & 31u))) ^ (unsigned)(short)((unsigned)l0 * fuel)) != 0u;
            if (((unsigned)e0 - (unsigned)((int)*mp < (int)9u))) continue;
            break; (void)((unsigned)(-(unsigned)(v0 < u0) < (unsigned)(w0 >> 29)));
            if ((((unsigned)d0 & *q0) / (g1 | 1u))) break;
        }
    }
    if (0x80000000u) goto L0;
    do { if (--fuel == 0u) goto done;
        if (((unsigned)l0 ^ 7u)) break;
        L2: if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                if ((unsigned)c1) goto L0;
            } while (i2++ < 4u && (i0 * (unsigned)s1));
        }
        if ((unsigned)((unsigned)f0 == *mp)) break;
    } while (i0++ < 2u && ((u0 / ((unsigned)s0 | 1u)) ^ u0));
    while (i0++ < 5u && (unsigned)s0) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (garr[u2 & 7u] ? i1 : p0);
        w0 = w0 * 6364136223846793005ull + (0xc74ce9fbu * (a0[u1 & 3u] >> ((unsigned)(-(unsigned)((int)garr[u2 & 7u] < (int)v0) && r0.x) & 31u)));
        r0.y ^= (fuel | (unsigned)h1);
        break; (void)(((unsigned)d0 / (p0 | 1u)));
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)((int)garr[i1 & 7u] >= (int)fuel) < (unsigned)s1), (garr[i1 & 7u] * (3u >> (u2 & 31u))), (unsigned)((int)(unsigned)h0 < (int)(a0[u1 & 3u] % (0x8e343b8du | 1u)))); }
    }
    if (budget != 0u) { budget -= 1u; u3 = fn0((0x7fffffffu << (p0 & 31u)), ((unsigned)s1 & (unsigned)c1), a0[u1 & 3u]); }
    if ((unsigned)(short)(0xd6a02c13u - (0xe55cf01fu % ((unsigned)h0 | 1u)))) goto L0;
    if ((unsigned)(i1 || (unsigned)s0)) {
        { unsigned t1; double z1; if ((u2) & 1u) { t1 = ~(unsigned)((int)6u < (int)u3); z1 = (double)((m0) & 255u); } if ((u2) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
            L3: if (--fuel == 0u) goto done;
        }
        goto L3;
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)(u3 / ((p0 - i1) | 1u))) continue;
            v0 = (unsigned)((*mp >> ((unsigned)x0 & 31u)) && 9u);
            if (budget != 0u) { budget -= 1u; u2 = fn3((r0.y << ((unsigned)((short)(unsigned)c0 > (signed char)6u) & 31u)), (unsigned)(unsigned char)(unsigned)((short)(0x80000000u / (a0[i0 & 3u] | 1u)) > (signed char)(unsigned)l0), (7u << ((unsigned)c0 & 31u))); }
        }
    }
    r0.x = v0;
    do { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u1 = fn0(0xa06217aeu, ((4u ^ 4u) / ((unsigned)w0 | 1u)), (unsigned)l0); }
        h1 = (unsigned short)(h1 + r0.x);
        g0 = p0;
        if (u3) {
            b0 = (unsigned)h0 != 0u;
            if (((unsigned)x0 - (unsigned)w0)) goto done;
            v0 = ((-(unsigned)((0x10000u ^ 7u) == 0x7fffffffu) + u1) | *q0);
        } else {
            v0 = ~(unsigned)((i0 ? (0x80000000u + garr[u2 & 7u]) : (unsigned)w0) && (unsigned)s1);
            if ((i1 % ((unsigned)c1 | 1u))) continue;
        }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((unsigned)h1 & 1023u);
            if (budget != 0u) { budget -= 1u; u1 = fn3((((unsigned)x0 % (u0 | 1u)) + 0xffffffffu), (unsigned)(signed char)((v0 - 0xd8ade226u) & 0x7fffffffu), (unsigned)((int)0xe988cf32u < (int)(unsigned)f0)); }
            u3 += (unsigned)((unsigned)e0 || (unsigned)h0);
            switch (((unsigned)((int)u2 < (int)5u) + 0x95c06076u) & 7u) {
                i0 = ~(0x80000000u >> ((unsigned)!(0xa562d3e7u ^ a0[u1 & 3u]) & 31u)) & 15u;
                u2 += (unsigned)((int)(((unsigned)c1 << (p2 & 31u)) << (((unsigned)f0 << (u2 & 31u)) & 31u)) >= (int)0u);
                { unsigned t2; double z2; if (((0xffffffffu * *q0)) & 1u) { t2 = (unsigned)((short)i0 > (signed char)~(0x7fffffffu & u0)); z2 = (double)(((unsigned)((int)g0 >= (int)*mp)) & 255u); } if (((0xffffffffu * *q0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    case 3u: ;
                    if ((unsigned)((short)(unsigned)((short)1u > (signed char)(unsigned)s1) > (signed char)(unsigned)l0)) goto L2;
                    if (budget != 0u) { budget -= 1u; u0 = fn3(i0, 4u, ~(unsigned)((u0 << (0x9ffa4aaeu & 31u)) && (unsigned)s1)); }
                    g1 += i0;
                    b0 = (unsigned)((short)(unsigned)c1 > (signed char)(garr[i1 & 7u] ? (unsigned)(short)(g1 / (6u | 1u)) : 0u)) != 0u;
                }
                r0.y ^= (unsigned)(0x906e5a4eu < ((0x5d503b80u + (unsigned)c0) & (unsigned)d0));
                L4: if (--fuel == 0u) goto done;
                h0 = (short)a0[u1 & 3u];
            }
            v0 = ((r0.y + (unsigned)(0x7fffffffu && (unsigned)l0)) - i2);
            if (*q0) break;
        }
    } while (i0++ < 7u && (unsigned)((p2 | 0x80000000u) == u0));
    do { if (--fuel == 0u) goto done;
        { unsigned t3; double z3; if (((unsigned)((0x7fffffffu + *q0) && garr[i1 & 7u])) & 1u) { t3 = 0x7fffffffu; z3 = (double)(((0x80000000u >> ((m0 & garr[u2 & 7u]) & 31u))) & 255u); } if (((unsigned)((0x7fffffffu + *q0) && garr[i1 & 7u])) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
            if (i1) break;
            f0 = f0 * 0.5f + (float)((unsigned)(6u == 0xc7d52516u) & 255u);
            if (u3 == 7u) return (unsigned)(r0.x && (0xf1f1f1ebu >> ((u2 & 3u) & 31u)));
            while (i1++ < 5u && (0x7fffffffu ^ i1)) { if (--fuel == 0u) goto done;
                b0 = ((unsigned)((int)0x7fffffffu >= (int)0xf136b519u) / ((p0 % ((unsigned)h1 | 1u)) | 1u)) != 0u;
                goto L3;
                c1 = (signed char)(unsigned)((unsigned)((unsigned)h0 < 0x80000000u) == (v0 >> (0x10000u & 31u)));
                if ((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)h0)) continue;
            }
            s1 = (int)((unsigned)s1 + (u1 + (unsigned)((short)(unsigned)e0 > (signed char)i1)));
            i0 = (unsigned)(unsigned char)((unsigned)(w0 >> 29) - 0x10000u) & 15u;
        }
        if (0x573829aau) {
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((0u / (0x6376e33du | 1u))) break;
                s1 = (int)((unsigned)s1 + p2);
                if (i1) break;
                continue; (void)((unsigned)!(((unsigned)x0 | 6u) - g1));
                b0 = -((*q0 | g1) << (0xf30b5e47u & 31u)) != 0u;
                r0.y ^= 9u;
            }
            h1 = (unsigned short)(h1 + (unsigned)((int)(unsigned)!(unsigned)((unsigned)(unsigned char)(garr[i1 & 7u] << ((unsigned)((int)p0 >= (int)(unsigned)(w0 >> 29)) & 31u)) < 5u) >= (int)1u));
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)!(i2 - ((unsigned)c1 * fuel)), u0, (unsigned)((int)0xda8edc7eu >= (int)(unsigned)c0)); }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)e0 && r0.y), (v0 ^ (unsigned)((short)0x80000000u > (signed char)(unsigned)h1)), (*q0 | a0[i0 & 3u])); }
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            *q0 += ((unsigned)w0 * garr[i1 & 7u]);
            if ((0xffffffffu >> (garr[u2 & 7u] & 31u))) continue;
            s1 = (int)((unsigned)s1 + (unsigned)h1);
            if ((garr[u2 & 7u] * p2)) break;
            b0 = (0xfd2d1d49u ^ (unsigned)(i2 && (unsigned)((int)garr[i1 & 7u] < (int)(g0 % (m0 | 1u))))) != 0u;
        }
        e0 = e0 * 0.5L + (long double)((unsigned)((short)0x1acb2e07u > (signed char)((unsigned)(w0 >> 29) >> ((unsigned)(g0 || *mp) & 31u))) & 1023u);
    } while (i0++ < 4u && (unsigned)((unsigned)(unsigned char)(6u & fuel) && (unsigned)l0));
    if (budget != 0u) { budget -= 1u; u0 = fn0((i2 / (0x80000000u | 1u)), garr[i1 & 7u], (0xf8e07105u % (g1 | 1u))); }
    q0 = &garr[((2u + (unsigned)(w0 >> 29)) ^ (unsigned)(signed char)(unsigned)((short)(unsigned)s1 > (signed char)g0)) & 7u];
    if ((0xffffffffu << ((unsigned)b0 & 31u))) goto L2;
    do { if (--fuel == 0u) goto done;
        *mp = (unsigned)((short)*mp > (signed char)(3u + g1));
        g1 += (unsigned)!(unsigned)(m0 || -(unsigned)(m0 < p0));
        u2 = i2;
        if ((unsigned)!(unsigned)(*mp == (*q0 % (0xe2dec69au | 1u)))) break;
    } while (i0++ < 6u && (unsigned)((unsigned)(x0 >> 70) == (fuel << (0x7fffffffu & 31u))));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 10u, 0xdaa9d2e0u, 0xbff29457u },
        { 10u, 0x469c7819u, 0xdb6beaa1u },
        { 4u, 0x44306ebbu, 0x23870f4bu },
        { 11u, 0xeb00cb83u, 0x4be3a1e4u },
        { 5u, 0x40e2e8e5u, 0x36ac6e35u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
