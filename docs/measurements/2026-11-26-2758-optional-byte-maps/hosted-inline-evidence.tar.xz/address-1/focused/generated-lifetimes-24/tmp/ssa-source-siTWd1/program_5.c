// test-ssa-source's program of seed 141000428 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xcc3dd50eu, g1 = 0xc783b46cu;
static unsigned garr[8] = { 0x9be54e78u, 0x872feac5u, 0xec9c6c2fu, 0xda6b2c70u, 0x14066356u, 0xe167cfe6u, 0x877a2c69u, 0x8205b9ddu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    d0 = d0 * 0.5 + (double)(((*q0 * a0[i0 & 3u]) << (((unsigned)(p2 || (unsigned)h0) >> ((unsigned)(w0 >> 29) & 31u)) & 31u)) & 1023u);
    u0 ^= (g0 << (((p2 ^ 0x1ab5d126u) >> (*mp & 31u)) & 31u));
    do { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)((0x10000u / ((unsigned)s0 | 1u)) & 255u);
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t0; double z0; if ((g1) & 1u) { t0 = (unsigned)(unsigned char)(9u + (unsigned)((int)(unsigned)c1 >= (int)(unsigned)c0)); z0 = (double)((v0) & 255u); } if ((g1) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                s0 = (int)(g1 % (u3 | 1u));
            }
            L0: if (--fuel == 0u) goto done;
            while (a0[i0 & 3u]) { if (--fuel == 0u) goto done;
                u1 ^= (a0[i0 & 3u] / ((unsigned)(unsigned char)(u0 - m0) | 1u));
            }
            if (u2) goto L0;
        }
        { unsigned t1; double z1; if (((unsigned)((int)u0 < (int)(unsigned)(unsigned char)(unsigned)((short)u3 > (signed char)(unsigned)l0))) & 1u) { t1 = (unsigned)(unsigned char)(0x80000000u | (unsigned)((unsigned)w0 && a0[u1 & 3u])); z1 = (double)(((unsigned)(unsigned char)((0u / (0x80000000u | 1u)) ^ a0[u1 & 3u])) & 255u); } if (((unsigned)((int)u0 < (int)(unsigned)(unsigned char)(unsigned)((short)u3 > (signed char)(unsigned)l0))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            do { if (--fuel == 0u) goto done;
                while (i2++ < 3u && u2) { if (--fuel == 0u) goto done;
                    L1: if (--fuel == 0u) goto done;
                    if ((u0 % (0u | 1u))) break;
                    s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)((unsigned)s0 == 0xaf9d610bu) > (signed char)0x15fe781u));
                    switch ((unsigned)e0 & 7u) {
                        r0.y ^= (p1 >> (0xf9a4daf4u & 31u));
                        if ((*mp | (p0 + u2))) goto done;
                        q0 = &garr[(m0 + g0) & 7u];
                        if ((unsigned)((int)(unsigned)x0 >= (int)p0)) continue;
                        if (0x10000u) continue;
                    }
                }
                L2: if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
                b0 = (garr[u2 & 7u] & 0x4f0298d1u) != 0u;
                d0 = d0 * 0.5 + (double)((unsigned)!((0x7615f277u >> (p2 & 31u)) ^ 0x10000u) & 1023u);
                s0 = (int)(unsigned)((int)(7u >> (r0.x & 31u)) < (int)((2u / ((unsigned)b0 | 1u)) | 0x78d9b94cu));
            } while (i1++ < 3u && u3);
            if ((unsigned)((short)i2 > (signed char)(9u >> (p2 & 31u)))) {
                break; (void)(-(unsigned)((int)0xffffffffu >= (int)i2));
            }
            continue; (void)((p0 ^ i1));
        }
    } while (i0++ < 2u && (0x5050f78fu | (unsigned)s0));
    goto done;
    h1 = (unsigned short)(h1 + ((unsigned)(signed char)(unsigned)((short)*mp > (signed char)(unsigned)c0) - (unsigned)((unsigned)e0 == (unsigned)e0)));
    if (u2) goto L1;
    garr[(unsigned)(*q0 && m0) & 7u] = *mp;
    d0 = d0 * 0.5 + (double)(((unsigned)h0 << ((((unsigned)s1 / ((unsigned)l0 | 1u)) << (a0[i0 & 3u] & 31u)) & 31u)) & 1023u);
    { unsigned t2; double z2; if (((fuel | (u3 + 0xe6ec35fcu))) & 1u) { t2 = (((unsigned)h1 * u0) * 8u); z2 = (double)((p0) & 255u); } if (((fuel | (u3 + 0xe6ec35fcu))) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
        if ((unsigned)(w0 >> 29)) {
            e0 = e0 * 0.5L + (long double)((unsigned)(1u == (0x10000u | (0xe3283fbfu + 0u))) & 1023u);
            if (r0.y) {
                garr[0x347b7c26u & 7u] = (unsigned)(p2 && 0xdbf2d8cdu);
                g0 = (unsigned)(signed char)(unsigned)((unsigned)((short)(unsigned)s0 > (signed char)p0) < (unsigned)(*q0 && garr[u2 & 7u]));
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if ((0xaa632d66u - 0x80000000u)) break;
                    if ((unsigned)(unsigned char)(unsigned)((unsigned)c1 < 0xa6041a8fu)) break;
                }
                if (((unsigned)((int)0u >= (int)(unsigned)l0) - i2)) {
                    b0 = (unsigned)((short)i2 > (signed char)(unsigned)f0) != 0u;
                    switch ((garr[i1 & 7u] | (unsigned)!(unsigned)(0xfcafd5a2u == garr[i1 & 7u])) & 7u) {
                        if (((0xffffffffu * i0) - garr[i1 & 7u])) break;
                        r0.y ^= -(unsigned)((int)(unsigned)c1 < (int)(unsigned)((i1 << ((unsigned)d0 & 31u)) || a0[u1 & 3u]));
                        L4: if (--fuel == 0u) goto done;
                        v0 = ((unsigned)(*mp == (unsigned)x0) ^ (i2 | (u0 << (i0 & 31u))));
                    }
                    if (p2) goto L3;
                }
                if (((i0 % (p2 | 1u)) << (m0 & 31u))) {
                    *q0 += ((g0 & 0xffffffffu) & (*mp | 0x7fffffffu));
                    h1 = (unsigned short)(h1 + (((unsigned)(u1 && 0x80000000u) ^ i2) - (unsigned)((unsigned)e0 || 0xffffffffu)));
                    if (((unsigned)h1 / (0x80000000u | 1u))) goto done;
                    if (((unsigned)c0 | (unsigned)((int)u1 < (int)r0.x))) goto L3;
                    if ((unsigned)((short)(unsigned)(signed char)(unsigned)((unsigned)x0 || i0) > (signed char)(unsigned)(x0 >> 70))) goto L2;
                }
            }
            m0 ^= ((p1 % ((unsigned)w0 | 1u)) % ((unsigned)(short)(0x80000000u << (0x7fffffffu & 31u)) | 1u));
        } else {
            for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                while (i1++ < 4u && ((unsigned)l0 % (((unsigned)x0 % ((unsigned)h1 | 1u)) | 1u))) { if (--fuel == 0u) goto done;
                    u1 = u1 * 0x9e3779b1u + ((unsigned)((unsigned)(w0 >> 29) == (unsigned)((int)0xe960a899u < (int)(unsigned)e0)) | r0.x);
                    *q0 = -((unsigned)(p1 < (unsigned)(0xcd9f6a3u < garr[u2 & 7u])) ^ (0x10000u << (i2 & 31u)));
                    r0.y ^= (unsigned)(0x80000000u < m0);
                    d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((unsigned)b0 && (unsigned)d0) < 0x10000u) & 1023u);
                    if ((unsigned)w0) continue;
                }
                if ((unsigned)(fuel && (unsigned)(x0 >> 70))) break;
            }
            if ((unsigned)((unsigned)c1 || i0)) goto L1;
            goto L0;
            if (0x80000000u) goto L3;
        }
        if (u1) goto L2;
        x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)((unsigned)c0 * ((unsigned)(0x10000u || fuel) - u2));
        if ((((unsigned)s0 / (p1 | 1u)) << (3u & 31u))) {
            s0 = (int)u0;
        }
    }
    u2 += (unsigned)((u1 % ((unsigned)l0 | 1u)) && 0x7b909d60u);
    while (i0++ < 6u && (2u / ((unsigned)(unsigned char)(unsigned)((int)0xffffffffu >= (int)u2) | 1u))) { if (--fuel == 0u) goto done;
        switch (((unsigned)((unsigned)h1 == (unsigned)c1) * 0x36404db1u) & 7u) {
            u0 = u0 * 0x9e3779b1u + ((unsigned)((unsigned)((int)(unsigned)(u0 && (unsigned)h0) >= (int)*mp) == 0xe15fa866u) | 0x10000u);
            if ((0xce12317bu * g0)) {
                a0[(unsigned)((unsigned)h1 == garr[i1 & 7u]) & 3u] = (0x7fffffffu & (u1 ? u1 : p0));
                s0 = (int)(unsigned)((short)i2 > (signed char)i2);
            }
            g1 += (6u >> ((unsigned)((int)(unsigned)d0 >= (int)1u) & 31u));
            do { if (--fuel == 0u) goto done;
                if ((unsigned)d0) {
                    case 7u: ;
                    v0 = (((unsigned)(g0 == (unsigned)x0) / ((unsigned)f0 | 1u)) - (unsigned)((int)m0 >= (int)fuel));
                }
            } while (i1++ < 6u && (0xbbd6b690u + garr[u2 & 7u]));
        }
        break; (void)((9u / ((unsigned)b0 | 1u)));
        switch ((fuel ^ (fuel % (*q0 | 1u))) & 7u) {
            if (((unsigned)s0 - (unsigned)f0)) {
                if (fuel < 8u) return (garr[i1 & 7u] / ((unsigned)(signed char)(i0 >> (((unsigned)d0 ? (unsigned)e0 : 0x10000u) & 31u)) | 1u));
            } else {
                if (u2) goto done;
                if (u1) continue;
                c1 = (signed char)((unsigned)((int)0x8864f8du < (int)0xdfa7a8deu) | (*q0 | 0x7fffffffu));
                f0 = f0 * 0.5f + (float)(-(unsigned)((int)0x10000u < (int)(unsigned)c1) & 255u);
            }
            case 7u: ;
            r0.x = (unsigned)!(unsigned)((u0 | m0) == garr[u2 & 7u]);
            case 6u: ;
            if (i1) continue;
            continue; (void)(5u);
        }
    }
    h1 = (unsigned short)(h1 + (unsigned)((unsigned)((short)(unsigned)x0 > (signed char)(unsigned)((unsigned)c0 < r0.y)) < 0x2f5f8cu));
    while (i0++ < 4u && p2) { if (--fuel == 0u) goto done;
        u1 = u1 * 0x9e3779b1u + ((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)c0) ^ (i1 ? fuel : u3));
        if ((p0 ? v0 : 0x10000u)) {
            a0[4u & 3u] = (unsigned)(unsigned char)((unsigned)(p1 < (unsigned)(unsigned char)(v0 - *mp)) >> ((g1 + 0x3725ff86u) & 31u));
            m0 ^= (unsigned)(short)(0x80000000u >> ((unsigned)!(garr[i1 & 7u] & ((unsigned)((unsigned)x0 < 0x8918f861u) >> (*q0 & 31u))) & 31u));
            r0.y ^= (unsigned)(-(unsigned)((unsigned)x0 || u1) == (unsigned)(u0 < 9u));
            if ((unsigned)e0) break;
        }
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t3; double z3; if (((u1 & (unsigned)f0)) & 1u) { t3 = 7u; z3 = (double)(((garr[i1 & 7u] ^ 7u)) & 255u); } if (((u1 & (unsigned)f0)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                break; (void)((unsigned)(p2 && (unsigned)s0));
                l0 = (long)((unsigned long)l0 + -(unsigned)(garr[u2 & 7u] == ((m0 * (unsigned)(x0 >> 70)) ^ (unsigned)c0)));
                do { if (--fuel == 0u) goto done;
                    switch ((unsigned)(2u == (garr[u2 & 7u] + 5u)) & 7u) {
                        m0 ^= garr[i1 & 7u];
                        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                            *mp = (((unsigned)x0 + ((unsigned)f0 & v0)) & 0x407bc1bfu);
                            q0 = &garr[i2 & 7u];
                            h1 = (unsigned short)(h1 + ((unsigned)c0 ^ (unsigned)((p1 - u3) || *q0)));
                            u2 += 7u;
                            case 7u: ;
                        }
                        m0 ^= 3u;
                    }
                    if (((unsigned)(fuel && a0[i0 & 3u]) ^ 0xffffffffu)) goto L4;
                } while (i2++ < 2u && (unsigned)s1);
                if ((1u | a0[u1 & 3u])) break;
            }
            if ((unsigned)d0) break;
        }
        *mp = (unsigned)(*q0 == (u2 << ((r0.y - 0x80000000u) & 31u)));
        if (((unsigned)(x0 >> 70) % ((u3 | g0) | 1u))) {
            { unsigned t4; double z4; if (((unsigned)(i1 || (unsigned)((int)(unsigned)s0 < (int)g1))) & 1u) { t4 = (unsigned)!(unsigned)((int)r0.x >= (int)u3); z4 = (double)(((4u | (unsigned)((int)0xffffffffu >= (int)(unsigned)h1))) & 255u); } if (((unsigned)(i1 || (unsigned)((int)(unsigned)s0 < (int)g1))) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                break; (void)((((unsigned)c1 / (g0 | 1u)) >> (u3 & 31u)));
                if ((unsigned)(0x7fffffffu == (0xc7ce89deu * v0))) break;
                u0 = u0 * 0x9e3779b1u + ((unsigned)(i1 && (unsigned)((int)g0 >= (int)*mp)) % ((unsigned)((int)(unsigned)h1 >= (int)u0) | 1u));
                e0 = e0 * 0.5L + (long double)((((0x84939205u - (unsigned)b0) >> (8u & 31u)) << (fuel & 31u)) & 1023u);
            }
        }
        if ((p0 << ((unsigned)e0 & 31u))) break;
    }
    if (u0) {
        if ((unsigned)(a0[u1 & 3u] == (m0 ^ i2))) goto L1;
        goto L2;
        if (u3 == 7u) return ((unsigned)((unsigned)b0 < 0x80000000u) + (r0.x - ((unsigned)f0 << (2u & 31u))));
    }
    r0.y ^= (unsigned)(0xd7806153u || (4u / ((unsigned)d0 | 1u)));
    if ((unsigned)((unsigned)((unsigned)h0 || 5u) < (unsigned)w0)) goto L1;
    if ((a0[i0 & 3u] >> (0x10000u & 31u))) goto L3;
    if (8u) goto L2;
    u3 += fuel;
    if ((unsigned)(i1 || (unsigned)e0)) {
        if ((unsigned)d0) goto L4;
        if (0xc0e2aeb6u) goto L4;
        e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)(signed char)(v0 >> (1u & 31u)) > (signed char)(fuel | (unsigned)(0xffffffffu == (unsigned)x0))) & 1023u);
        x0 = x0 * 0x100000001b3ull + (((unsigned)((int)(unsigned)d0 < (int)(unsigned)s0) - r0.x) | (i2 << (p0 & 31u)));
    }
    r0.y ^= (unsigned)(unsigned char)((unsigned)(garr[u2 & 7u] < 0u) ^ ((unsigned)(0x10000u < 0x7fffffffu) - u2));
    { unsigned t5; double z5; if ((0x80000000u) & 1u) { t5 = (a0[u1 & 3u] << (u0 & 31u)); z5 = (double)((i1) & 255u); } if ((0x80000000u) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
        while (i0++ < 7u && (r0.y >> (*q0 & 31u))) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((1u % (0xffffffffu | 1u))) continue;
                    h0 = (short)((unsigned)c1 % ((8u ^ u3) | 1u));
                }
                do { if (--fuel == 0u) goto done;
                    if (0xffffffffu) continue;
                    h1 = (unsigned short)(h1 + (unsigned)(((unsigned)c0 >> ((unsigned)w0 & 31u)) && (a0[i0 & 3u] % (i2 | 1u))));
                    if (((unsigned)x0 + (unsigned)(0x10000u && (unsigned)x0))) break;
                } while (i2++ < 6u && 0u);
                g1 += (unsigned)((i2 * 0xffffffffu) && 4u);
                *q0 = p1;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)(i0 % (0x7fffffffu | 1u)) < (int)2u)) break;
                    c0 = (unsigned char)0xa22a2c88u;
                }
                if (((unsigned)(signed char)(unsigned)(i1 && (unsigned)f0) & (unsigned)s0)) continue;
            }
            if (((unsigned)b0 / ((u1 & (unsigned)c0) | 1u))) break;
        }
        if ((unsigned)d0) goto L0;
        if (u3 == 7u) return (unsigned)(signed char)(unsigned)((int)*mp < (int)(unsigned)(unsigned char)(unsigned)((short)(unsigned)h0 > (signed char)7u));
        w0 ^= (unsigned long long)(unsigned)((int)(unsigned)s0 >= (int)garr[i1 & 7u]) << ((unsigned)((unsigned)(w0 >> 29) < *q0) & 63u);
        c0 = (unsigned char)((unsigned)((short)(unsigned)((unsigned)h1 == r0.x) > (signed char)g0) + u1);
    }
    if ((unsigned)(0x3a7f836au || (unsigned)b0)) {
        if (((unsigned)e0 * ((unsigned)s0 << (5u & 31u)))) goto L1;
        i1 = (unsigned)(short)((unsigned)(fuel == i1) << (0x10000u & 31u)) & 15u;
        { unsigned t6; double z6; if ((g1) & 1u) { t6 = (unsigned)((int)u1 < (int)(0x80000000u - 0x80000000u)); z6 = (double)(((((unsigned)h1 - *mp) % (r0.y | 1u))) & 255u); } if ((g1) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            if (fuel < 8u) return (garr[u2 & 7u] >> ((unsigned)((int)(unsigned)h1 >= (int)(unsigned)(g1 || (unsigned)(short)(unsigned)((int)0x259ae4a2u < (int)2u))) & 31u));
            if (0u) goto L2;
            s1 = (int)((unsigned)s1 + 0x7fffffffu);
        }
        { unsigned t7; double z7; if ((u0) & 1u) { t7 = 0x80000000u; z7 = (double)(((0x7792f1f8u & r0.y)) & 255u); } if ((u0) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
            g1 += ((0x5ea60eddu / (0x1158a5c3u | 1u)) ^ (unsigned)(x0 >> 70));
            while (i0++ < 2u && (unsigned)!(i1 ? (unsigned)h1 : (unsigned)h0)) { if (--fuel == 0u) goto done;
                s0 = (int)-((p0 >> ((unsigned)c1 & 31u)) % (u0 | 1u));
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)!(a0[i0 & 3u] / ((unsigned)b0 | 1u)));
                    if ((unsigned)(unsigned char)(garr[i1 & 7u] >> ((unsigned)l0 & 31u))) {
                        if (~((unsigned)l0 | 0x7fffffffu)) break;
                        if ((unsigned)(unsigned char)(unsigned)((int)0xffffffffu >= (int)(unsigned)((unsigned)f0 < (unsigned)(x0 >> 70)))) {
                            a0[(unsigned)(signed char)(0xffffffffu >> ((unsigned)d0 & 31u)) & 3u] = (unsigned)!((i1 * (unsigned)(signed char)(unsigned)(i0 || 4u)) * (unsigned)!(unsigned)((unsigned)h1 == r0.y));
                            *q0 = (unsigned)(p0 || u2);
                            if ((unsigned)((short)(unsigned)w0 > (signed char)0x10000u)) goto L2;
                        }
                        if (u1) break;
                        if ((unsigned)((int)(unsigned)c1 >= (int)(unsigned)(9u < 2u))) break;
                        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)(*mp == p0) == i1) & 1023u);
                        d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(unsigned)((int)(unsigned)(p0 || (unsigned)d0) >= (int)0xeb5dc425u) & 1023u);
                    } else {
                        break; (void)(v0);
                        continue; (void)((garr[i1 & 7u] % (0x99a816f6u | 1u)));
                        if ((unsigned)(6u || (unsigned)(0xb67c3d5eu < (unsigned)(x0 >> 70)))) break;
                    }
                    f0 = f0 * 0.5f + (float)(((0xffffffffu * 0xb347e338u) / ((unsigned)w0 | 1u)) & 255u);
                }
                w0 = w0 * 6364136223846793005ull + (u0 + (unsigned)l0);
                x0 = x0 * 0x100000001b3ull + (unsigned)!(unsigned)((unsigned)(w0 >> 29) && ((unsigned)d0 | (unsigned)((short)(unsigned)h0 > (signed char)(r0.y + 0x80000000u))));
            }
            if ((unsigned)x0) goto done;
        }
        if ((0x53e625a4u + u2)) {
            if (((unsigned)w0 % ((p2 | 0xffffffffu) | 1u))) {
                goto done;
                m0 ^= (unsigned)(signed char)((unsigned)(a0[i0 & 3u] == 0x1e8f6d25u) >> (p1 & 31u));
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    q0 = &garr[((unsigned)(0x10000u || 0x57653513u) >> (i0 & 31u)) & 7u];
                }
                goto L3;
                s1 = (int)((unsigned)s1 + ((unsigned)(0x53aec72du < 3u) ^ ((unsigned)s1 % ((fuel - 4u) | 1u))));
            }
            if (u0) goto L1;
            while (0x77a50b0au) { if (--fuel == 0u) goto done;
                goto L3;
            }
        } else {
            if ((u2 / ((unsigned)f0 | 1u))) goto L3;
        }
    } else {
        goto L0;
    }
    { unsigned t8; double z8; if ((((a0[u1 & 3u] % (garr[i1 & 7u] | 1u)) << (0x10000u & 31u))) & 1u) { t8 = -(unsigned)(u2 < 0x80000000u); z8 = (double)((((unsigned)h1 ? garr[i1 & 7u] : 0u)) & 255u); } if ((((a0[u1 & 3u] % (garr[i1 & 7u] | 1u)) << (0x10000u & 31u))) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
        if (((unsigned)s1 & u0)) goto L4;
        if (1u) goto L1;
    }
    if (((unsigned)(x0 >> 70) % (u1 | 1u))) {
        goto L2;
        g0 = (unsigned)(short)(unsigned)(p1 == 0xdfa977f0u);
    }
    while (i0++ < 5u && (unsigned)s1) { if (--fuel == 0u) goto done;
        if ((u3 & (i0 / ((unsigned)h1 | 1u)))) break;
        g0 = (r0.y >> (u0 & 31u));
        s0 = (int)((unsigned)(unsigned char)(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)~(i2 - 7u)) << ((unsigned)(i0 || r0.y) & 31u));
        if ((unsigned)h0) {
            break; (void)(-(unsigned)((a0[u1 & 3u] - r0.x) < (unsigned)h1));
            l0 = (long)((unsigned long)l0 + (unsigned)((int)((unsigned)d0 - 5u) >= (int)(unsigned)((short)0x7a9660ecu > (signed char)(i2 % (0x575ead81u | 1u)))));
        }
    }
    u1 += (unsigned)(x0 >> 70);
    if ((unsigned)((int)p0 < (int)0x27687898u)) {
        l0 = (long)((unsigned long)l0 + i2);
        garr[-(unsigned)((int)r0.x >= (int)garr[i1 & 7u]) & 7u] = (unsigned)(p2 < (unsigned)(signed char)((unsigned)(w0 >> 29) ^ (unsigned)(w0 >> 29)));
        if ((unsigned)(0x44d562e8u && 8u)) goto L4;
        if (((unsigned)s0 ^ (unsigned)(x0 >> 70))) goto L0;
        q0 = &garr[(unsigned)((unsigned)s0 && (0xffffffffu & 1u)) & 7u];
        h0 = (short)(unsigned)((unsigned)(0x7fffffffu && u3) < ((unsigned)((int)0x7fffffffu >= (int)garr[i1 & 7u]) ^ v0));
    } else {
        *q0 = ((u1 + g1) % (fuel | 1u));
    }
    if ((i1 << (fuel & 31u))) {
        g0 = (unsigned)((unsigned)((unsigned)(short)(u2 / (r0.y | 1u)) == 0x10000u) || 0xffffffffu);
        if (0x825d8a6bu) goto done;
    }
    { unsigned t9; double z9; if ((((unsigned)e0 / ((unsigned)w0 | 1u))) & 1u) { t9 = (r0.y & (unsigned)((int)4u >= (int)(unsigned)b0)); z9 = (double)((g1) & 255u); } if ((((unsigned)e0 / ((unsigned)w0 | 1u))) & 1u) { u2 += t9; d0 = d0 * 0.5 + z9; }
        if ((p1 * u0)) goto L3;
        if ((unsigned)h1) goto L2;
        if ((unsigned)(signed char)(p0 % ((unsigned)((short)0xd89a393eu > (signed char)a0[i0 & 3u]) | 1u))) {
            h0 = (short)(m0 % ((unsigned)(a0[i0 & 3u] == 0x7fffffffu) | 1u));
            u2 = v0;
            r0.x = (unsigned)((int)((p2 + u3) >> (4u & 31u)) < (int)(u0 / ((unsigned)f0 | 1u)));
            *mp = (unsigned)((unsigned)((short)(unsigned)(0x80000000u || 0x7fffffffu) > (signed char)r0.x) || (0x3ad7f861u >> (*q0 & 31u)));
            if (r0.y) goto L1;
            d0 = d0 * 0.5 + (double)(((unsigned)(w0 >> 29) >> ((unsigned)(x0 >> 70) & 31u)) & 1023u);
        } else {
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (u3) break;
                goto L2;
                continue; (void)((unsigned)((int)(unsigned)((int)0x7fffffffu >= (int)i2) < (int)0x43f6779au));
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        e0 = e0 * 0.5L + (long double)(((unsigned)f0 - 0x15791bf6u) & 1023u);
                    } while (i2++ < 6u && (unsigned)!(unsigned)((int)8u >= (int)(p1 & (unsigned)c0)));
                    if ((unsigned)((int)(unsigned)c0 >= (int)(unsigned)(x0 >> 70))) break;
                }
                break; (void)((unsigned)((unsigned)d0 || 0x7629bb23u));
            }
            do { if (--fuel == 0u) goto done;
                u0 ^= ~((unsigned)(2u && (unsigned)((int)(unsigned)x0 < (int)0x80000000u)) >> ((unsigned)((int)6u >= (int)(unsigned)c0) & 31u));
            } while (i0++ < 5u && 5u);
            w0 = w0 * 6364136223846793005ull + ((0xc2069a28u ^ (unsigned)h1) * u0);
            if ((unsigned)(0x6e9814c5u || fuel)) {
                switch (0x80000000u & 7u) {
                    while (i0++ < 3u && (unsigned)(p2 == -(0x80000000u >> (u3 & 31u)))) { if (--fuel == 0u) goto done;
                        u1 ^= (unsigned)((int)(unsigned)h0 < (int)0x10000u);
                        if ((unsigned)((int)(unsigned)s1 < (int)0xd7911478u)) break;
                        case 7u: ;
                    }
                }
            }
        }
        do { if (--fuel == 0u) goto done;
            u1 += (unsigned)((int)garr[i1 & 7u] < (int)(unsigned)h0);
            if ((unsigned)((unsigned)c0 == 2u)) {
                if ((unsigned)w0) {
                    if (p1) goto L2;
                    if ((u2 + (unsigned)b0)) break;
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((unsigned)(unsigned char)(unsigned)((int)g1 >= (int)(unsigned)x0) | ((p2 | 0xaff05c36u) * a0[u1 & 3u]));
                        switch ((unsigned)(u2 == 6u) & 7u) {
                            case 3u: ;
                            case 1u: ;
                            if (0x2b4a8592u) goto L3;
                            *mp = 0xeddb12f4u;
                        }
                        x0 = x0 * 0x100000001b3ull + ((unsigned)!(unsigned)(a0[u1 & 3u] && (unsigned)((short)i1 > (signed char)garr[u2 & 7u])) | p2);
                    }
                    s1 = (int)((unsigned)s1 + (unsigned)((int)p1 < (int)(unsigned)((unsigned)s1 || (unsigned)s1)));
                    c1 = (signed char)v0;
                } else {
                    if ((unsigned)(i0 == 0x7fffffffu)) break;
                    s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(unsigned)((int)(fuel ^ u1) >= (int)(unsigned)((unsigned)l0 && (unsigned)h0)));
                }
                continue; (void)((unsigned)s1);
                v0 = ~(unsigned)(u1 && (i1 >> (0u & 31u)));
                c0 = (unsigned char)(p0 / (~(u0 << ((unsigned)((unsigned)w0 < 0x87530c54u) & 31u)) | 1u));
                u0 += (unsigned)((int)0x7fffffffu < (int)(unsigned)(u3 == ((unsigned)e0 ^ 0x80000000u)));
            } else {
                if ((u3 * u1)) break;
                if (a0[i0 & 3u]) {
                    switch (fuel & 7u) {
                        w0 ^= (unsigned long long)(unsigned)s0 << ((unsigned)((int)(v0 - 0xfe397a42u) >= (int)0x8a4ca870u) & 63u);
                    }
                    if ((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)(u2 && (unsigned)b0))) break;
                    x0 = x0 * 0x100000001b3ull + (~((unsigned)(short)((unsigned)d0 % ((unsigned)s0 | 1u)) * *q0) ^ (unsigned)((int)u3 < (int)(unsigned)b0));
                }
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)p1 < (int)(unsigned)!((unsigned)d0 ? u3 : (unsigned)(garr[u2 & 7u] && (unsigned)l0)));
            }
            garr[(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)b0) & 7u] = ((unsigned)b0 | a0[u1 & 3u]);
            break; (void)(0x2e11f71bu);
            { unsigned t10; double z10; if ((((unsigned)x0 / (0x7fffffffu | 1u))) & 1u) { t10 = ((unsigned)f0 | 0xe21e9982u); z10 = (double)(((unsigned)l0) & 255u); } if ((((unsigned)x0 / (0x7fffffffu | 1u))) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                break; (void)((unsigned)((short)0xa94bdb4eu > (signed char)0x1c47b854u));
                if (fuel < 8u) return ~(p0 - p0);
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    h0 = (short)(unsigned)((short)(unsigned)b0 > (signed char)(unsigned)((unsigned)(x0 >> 70) < (p0 ? 0xffffffffu : g1)));
                    for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + 8u);
                        if ((unsigned)(signed char)((p1 / (0x7fffffffu | 1u)) * 0x8a1fa0c1u)) continue;
                        if ((0x7fffffffu & i1)) goto done;
                        q0 = &garr[((9u - ((unsigned)f0 ? (unsigned)s0 : 1u)) & (unsigned)c0) & 7u];
                        q0 = &garr[(unsigned)(signed char)(v0 + 7u) & 7u];
                        *q0 += 0xbc7f9e03u;
                    }
                    h1 = (unsigned short)(h1 + (unsigned)(unsigned char)(((unsigned)!((unsigned)h1 & a0[i0 & 3u]) << (garr[i1 & 7u] & 31u)) << (v0 & 31u)));
                    do { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((int)(unsigned)(w0 >> 29) < (int)garr[u2 & 7u]));
                        if (((unsigned)b0 - u2)) break;
                        *mp = (*q0 / ((unsigned)(signed char)(((unsigned)f0 + 0x10000u) << ((*q0 << (r0.x & 31u)) & 31u)) | 1u));
                    } while (i2++ < 2u && (unsigned)((unsigned)b0 < (r0.x + (unsigned)b0)));
                }
                c1 = (signed char)(unsigned)((int)8u >= (int)v0);
                break; (void)(p0);
            }
            for (;;) { if (--fuel == 0u) goto done;
                h0 = (short)(((unsigned)((int)(unsigned)s1 >= (int)a0[u1 & 3u]) & (unsigned)l0) | 0x9c12134eu);
                g0 = ((g0 << (a0[i0 & 3u] & 31u)) / ((unsigned)d0 | 1u));
                q0 = &garr[u0 & 7u];
            }
        } while (i0++ < 2u && (a0[u1 & 3u] * 8u));
        if ((i1 - (unsigned)l0)) goto done;
        goto done;
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if (((0x10000u % (9u | 1u))) & 1u) { t0 = (0xffffffffu << ((unsigned)d0 & 31u)); z0 = (double)(((r0.y % (0x4ccfac12u | 1u))) & 255u); } if (((0x10000u % (9u | 1u))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        if ((unsigned)h0) goto L0;
        x0 = x0 * 0x100000001b3ull + 0u;
        g0 = ~(unsigned)((short)garr[u2 & 7u] > (signed char)~(p0 ? 0x80000000u : p2));
        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((int)0xdff07043u < (int)9u) < (u0 % ((0u ^ u1) | 1u)));
        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)s1 == (unsigned)(0xfd6b2b75u && (unsigned)(garr[i1 & 7u] == 4u))) & 1023u);
        if (u1) {
            L0: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(u3 & 0x74b0c90au) < (int)garr[i1 & 7u]), (i0 & (a0[u1 & 3u] & 0x7fffffffu)), (unsigned)((int)0xffffffffu < (int)(p2 & v0))); }
            if (*mp) {
                while (i0++ < 7u && (unsigned)e0) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(p0 & u1) > (signed char)(unsigned)e0), r0.x, (garr[i1 & 7u] | (0xffffffffu * 0u))); }
                    L1: if (--fuel == 0u) goto done;
                    L2: if (--fuel == 0u) goto done;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)e0 | (*mp - (unsigned)(w0 >> 29))), ((unsigned)((short)(unsigned)e0 > (signed char)garr[u2 & 7u]) << (m0 & 31u)), (unsigned)((unsigned)s1 || i0)); }
                if (i1) goto L2;
                h1 = (unsigned short)(h1 + (unsigned)(signed char)(p2 % ((unsigned)s0 | 1u)));
                goto done;
            } else {
                *q0 = (unsigned)(u1 && (unsigned)((unsigned)d0 < (unsigned)f0));
                d0 = d0 * 0.5 + (double)(((p2 & i0) ^ (unsigned)(short)(unsigned)((unsigned)(i1 == a0[i0 & 3u]) || m0)) & 1023u);
                g1 += (unsigned)(0x15545e4au == (unsigned)d0);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s0, p2, p1); }
        } else {
            goto L3;
            u1 = u1 * 0x9e3779b1u + (unsigned)(signed char)(0x80000000u % ((a0[i0 & 3u] / ((unsigned)w0 | 1u)) | 1u));
        }
    }
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)((int)g1 >= (int)((unsigned)(w0 >> 29) >> (fuel & 31u)))) break;
        goto L3;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(signed char)(0x2d43e37du % ((m0 + 0x7fffffffu) | 1u)), a0[u1 & 3u], ((unsigned)b0 % (((unsigned)f0 >> (garr[u2 & 7u] & 31u)) | 1u))); }
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(i1 & 1023u);
            u1 = ((u1 & (unsigned)c0) % (0xe3ef3addu | 1u));
            e0 = e0 * 0.5L + (long double)((unsigned)(i2 == ((unsigned)((int)garr[i1 & 7u] < (int)g1) ^ 0x32f956a5u)) & 1023u);
            if ((unsigned)(garr[u2 & 7u] < (9u ^ 0x38794bc5u))) break;
            r0.x = (unsigned)((int)u0 >= (int)0x80000000u);
            c1 = (signed char)((p1 - (unsigned)(*mp && 0xec2c6918u)) % (((unsigned)s1 & u2) | 1u));
        }
    }
    if (i1) goto L1;
    do { if (--fuel == 0u) goto done;
        if (u1) continue;
        c1 = (signed char)(0x7fffffffu & (unsigned)(signed char)(garr[i1 & 7u] ? 3u : fuel));
        for (;;) { if (--fuel == 0u) goto done;
            L3: if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + ((2u & (unsigned)((short)p2 > (signed char)0xfe9f1dceu)) % ((unsigned)(p2 < g0) | 1u));
            s1 = (int)((unsigned)s1 + v0);
            v0 = (unsigned)(signed char)(8u * (unsigned)(p0 && ((unsigned)s0 * garr[i1 & 7u])));
        }
        *mp = (0xffffffffu / (0xffffffffu | 1u));
    } while (i0++ < 6u && (p0 ^ (unsigned)l0));
    if (((0x7fffffffu ^ p1) + p1)) goto L1;
    g0 = (((r0.x >> ((unsigned)e0 & 31u)) << (a0[i0 & 3u] & 31u)) | (g0 ^ 0x80000000u));
    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)l0 * 0xa23050f5u), (unsigned)(r0.y < (0x7fffffffu | 0x9cef39f0u)), 6u); }
    do { if (--fuel == 0u) goto done;
        if (g1) break;
        if (p1) break;
        if (0x10000u) {
            s1 = (int)((unsigned)s1 + p1);
        }
        x0 = x0 * 0x100000001b3ull + (unsigned)w0;
    } while (i0++ < 2u && (unsigned)((int)(*mp + (unsigned)f0) >= (int)0x5cb17f19u));
    u3 += 9u;
    while ((a0[u1 & 3u] & (unsigned)h0)) { if (--fuel == 0u) goto done;
        q0 = &garr[((unsigned)((unsigned)(x0 >> 70) == (unsigned)l0) >> (garr[i1 & 7u] & 31u)) & 7u];
        i0 = *q0 & 15u;
        *q0 += (unsigned)((int)(unsigned)c0 >= (int)(unsigned)h0);
        break; (void)((unsigned)!(unsigned)((unsigned)((int)v0 < (int)(unsigned)e0) || 0x46cb5c58u));
        if (~((unsigned)(short)((unsigned)b0 + (unsigned)b0) & 0x10000u)) break;
    }
    if (0x7fffffffu) goto L2;
    switch (a0[i0 & 3u] & 7u) {
        s0 = (int)((unsigned)((int)0x80000000u >= (int)garr[i1 & 7u]) ^ *q0);
        *mp = (unsigned)!(unsigned)((unsigned)((short)(unsigned)(i2 && (0x10000u ^ m0)) > (signed char)(unsigned)c1) && *q0);
        if ((unsigned)!((unsigned)(g1 < i2) + (unsigned)w0)) {
            u0 ^= (((unsigned)h0 + *mp) / ((unsigned)((unsigned)d0 && 0x80000000u) | 1u));
            L4: if (--fuel == 0u) goto done;
            b0 = ((unsigned)d0 * (unsigned)b0) != 0u;
        } else {
            d0 = d0 * 0.5 + (double)((garr[i1 & 7u] % ((unsigned)!(unsigned)((unsigned)f0 || a0[u1 & 3u]) | 1u)) & 1023u);
            u3 ^= (p0 << ((((unsigned)l0 / ((a0[u1 & 3u] & 0x7fffffffu) | 1u)) - (unsigned)d0) & 31u));
            g0 = (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)((int)garr[i1 & 7u] >= (int)(i0 ^ 0x80000000u)));
            c1 = (signed char)(unsigned)((unsigned)((short)0x10000u > (signed char)0xffffffffu) == (0x80000000u << (garr[u2 & 7u] & 31u)));
        }
        if (-((unsigned)e0 * -((unsigned)x0 & p0))) break;
        switch (0x7eff2b40u & 7u) {
            g1 += 0x18b7cfeau;
            if ((unsigned)(u0 && u3)) break;
            case 1u: ;
        }
        r0.x = (unsigned)((int)u0 >= (int)(unsigned)((short)(unsigned)((int)(unsigned)l0 >= (int)r0.x) > (signed char)0x80000000u));
    }
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + (unsigned)(~(unsigned)(0x10000u && (unsigned)d0) == ((unsigned)((int)fuel >= (int)(unsigned)f0) >> (0x80000000u & 31u))));
        if (0x80000000u) {
            u0 = p2;
            break; (void)((unsigned)((fuel + *mp) == p2));
            i0 = (unsigned)(w0 >> 29) & 15u;
            f0 = f0 * 0.5f + (float)(fuel & 255u);
            switch ((0x7fffffffu * (unsigned)s0) & 7u) {
                w0 = w0 * 6364136223846793005ull + ((0x7fffffffu ^ (unsigned)h0) - *mp);
                if ((unsigned)(u3 && ((unsigned)e0 & 8u))) continue;
                case 3u: ;
                d0 = d0 * 0.5 + (double)(~(g0 | ((unsigned)(x0 >> 70) ? 0x7fffffffu : (unsigned)((short)fuel > (signed char)r0.x))) & 1023u);
                s1 = (int)((unsigned)s1 + (unsigned)(((unsigned)x0 ^ 0x2c270defu) < (r0.y + (i1 | p2))));
                case 2u: ;
            }
        }
        if (((8u * 0x26aa6253u) % ((unsigned)(w0 >> 29) | 1u))) goto L0;
    }
    do { if (--fuel == 0u) goto done;
        s0 = (int)p0;
        switch ((unsigned)((unsigned)((unsigned)l0 || (unsigned)b0) == (unsigned)s1) & 7u) {
            break; (void)(u1);
            switch (8u & 7u) {
                c1 = (signed char)(0x80000000u * r0.x);
                if (~(g0 - (unsigned)((int)0xed27fd32u < (int)6u))) goto L3;
                u0 += u3;
                a0[(unsigned)((unsigned)(x0 >> 70) == i2) & 3u] = (unsigned)(signed char)(((unsigned)c0 / ((unsigned)((short)a0[i0 & 3u] > (signed char)g0) | 1u)) ^ (5u >> ((unsigned)l0 & 31u)));
                r0.x = v0;
                case 6u: ;
            }
            garr[(unsigned)c1 & 7u] = -((i0 + ((unsigned)s1 % (r0.x | 1u))) >> (i1 & 31u));
        }
        if ((0xffffffffu | fuel)) break;
        continue; (void)(0x7fffffffu);
        if ((0u + (unsigned)h1)) continue;
        if (budget != 0u) { budget -= 1u; u1 = fn0(~(unsigned)((int)0xab0a629u < (int)(0xaeb1b03fu >> (0x80000000u & 31u))), (((unsigned)x0 ^ 0x951d6ddeu) / (g0 | 1u)), (0x684c6511u * ((unsigned)h0 * 0x5a57a57u))); }
    } while (i0++ < 4u && ((unsigned)l0 / ((unsigned)(i2 == (unsigned)x0) | 1u)));
    c0 = (unsigned char)(p2 ? (unsigned)x0 : u2);
    switch ((unsigned)((short)(unsigned)f0 > (signed char)(unsigned)h0) & 7u) {
        b0 = ((unsigned)(unsigned char)((unsigned)e0 + 1u) >> (((u1 | (unsigned)d0) | 0x10000u) & 31u)) != 0u;
        h0 = (short)((unsigned)((unsigned)s1 == 0x5047805eu) << (u2 & 31u));
        break; (void)(r0.x);
        d0 = d0 * 0.5 + (double)(((unsigned)f0 ^ (0xd5aa8287u % (i2 | 1u))) & 1023u);
    }
    x0 = x0 * 0x100000001b3ull + (0x7fffffffu << ((unsigned)((int)1u >= (int)p2) & 31u));
    do { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)-((unsigned)h1 + u2) << ((g0 + i0) & 63u);
        h0 = (short)(unsigned)(unsigned char)((v0 % (v0 | 1u)) + p0);
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)w0 < (int)(unsigned)f0), (unsigned)(w0 >> 29), u1); }
        m0 ^= (unsigned)((int)(4u | m0) >= (int)5u);
        if (((unsigned)e0 / ((r0.y | r0.x) | 1u))) {
            *q0 += ((unsigned)((int)(unsigned)((short)2u > (signed char)0x10000u) < (int)(unsigned)d0) << (u2 & 31u));
            v0 = 0x4278f8f8u;
            if (((unsigned)s0 * 5u)) continue;
            h1 = (unsigned short)(h1 + i1);
        }
    } while (i0++ < 4u && (unsigned)((unsigned)c0 < (unsigned)((int)r0.x >= (int)(unsigned)e0)));
    l0 = (long)((unsigned long)l0 + ((unsigned)(signed char)((unsigned)(fuel && (unsigned)s1) >> (0u & 31u)) % (0x52ed89du | 1u)));
    l0 = (long)((unsigned long)l0 + 0x87dc41a5u);
    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)!(9u / ((unsigned)b0 | 1u)), (unsigned)!(p1 >> (0xffffffffu & 31u)), (g1 % ((unsigned)((int)(unsigned)c0 >= (int)5u) | 1u))); }
    w0 ^= (unsigned long long)(unsigned)((int)(unsigned)f0 < (int)(unsigned)(x0 >> 70)) << (g1 & 63u);
    c0 = (unsigned char)((unsigned)(unsigned char)(1u | (unsigned)e0) - (unsigned)(0x910217u && (unsigned)(unsigned char)(i0 * (unsigned)s0)));
    *mp = ((0x80000000u * i1) * 0x10000u);
    g0 = (1u << ((unsigned)((unsigned)(short)(m0 & 0x80000000u) && (unsigned)(i1 < a0[i0 & 3u])) & 31u));
    while (i0++ < 7u && (i0 >> (v0 & 31u))) { if (--fuel == 0u) goto done;
        if (0x7440ed59u) break;
        do { if (--fuel == 0u) goto done;
            *q0 = ((unsigned)(1u || 0x8b42b1c3u) & u0);
        } while (i1++ < 7u && ((unsigned)l0 & (unsigned)(x0 >> 70)));
        if (i2) break;
        g1 += ((0x12de3cdbu * (unsigned)((int)0x10000u >= (int)garr[u2 & 7u])) * (unsigned)h0);
        r0.x = (garr[i1 & 7u] / (((0xffffffffu ^ (0u | 0xffffffffu)) & r0.y) | 1u));
        if (u3 == 7u) return (unsigned)((short)(unsigned)x0 > (signed char)(unsigned)(0x10000u || (unsigned)l0));
    }
    if (0xffffffffu) {
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)s1, (m0 * 0xd905aa26u), ((unsigned)h0 / ((unsigned)h0 | 1u))); }
        while (((unsigned)x0 / ((unsigned)f0 | 1u))) { if (--fuel == 0u) goto done;
            if (u2) {
                if (u3 == 7u) return ((unsigned)((int)0x10000u >= (int)((unsigned)d0 + fuel)) / (-(u1 * i2) | 1u));
            }
            while (((0x10000u >> ((unsigned)x0 & 31u)) * r0.y)) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (unsigned)(g1 < 0x9feb4665u);
                if (budget != 0u) { budget -= 1u; u0 = fn0((((unsigned)(x0 >> 70) << (u1 & 31u)) ^ fuel), (unsigned)b0, ((unsigned)(x0 >> 70) - (unsigned)e0)); }
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)(1u && (unsigned)s1) > (signed char)(unsigned)(p0 < 0x80000000u));
            }
            g0 = ((unsigned)(0xe40725c6u < 5u) >> ((unsigned)((0x4015ffd4u * (unsigned)l0) == 0x7fffffffu) & 31u));
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                while (i2++ < 4u && (unsigned)((int)6u >= (int)garr[u2 & 7u])) { if (--fuel == 0u) goto done;
                    i2 = ((unsigned)h1 % (1u | 1u)) & 15u;
                    if (0xffffffffu) break;
                }
                r0.y ^= i1;
                u3 = (garr[i1 & 7u] % (garr[u2 & 7u] | 1u));
                m0 ^= (unsigned)((int)(0x80000000u + r0.x) < (int)(unsigned)f0);
            }
            if ((i0 << (garr[u2 & 7u] & 31u))) break;
            switch ((g1 & u3) & 7u) {
                u0 = u0 * 0x9e3779b1u + ((((0x80000000u * *mp) & (unsigned)s1) / ((unsigned)l0 | 1u)) - (unsigned)e0);
            }
        }
        goto L3;
    }
    l0 = (long)((unsigned long)l0 + (((unsigned)(*q0 == (u2 + 0xffffffffu)) % ((unsigned)x0 | 1u)) ^ 0x9a5cd52du));
    g0 = (unsigned)((short)(unsigned)f0 > (signed char)0xc294163u);
    for (;;) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((short)g0 > (signed char)(unsigned)((short)(unsigned)c0 > (signed char)0xffffffffu)));
        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s1 * r0.y), (unsigned)(p1 == (unsigned)!(unsigned)((int)0xffffffffu < (int)(unsigned)(w0 >> 29))), (unsigned)l0); }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)f0, (((unsigned)c1 % ((unsigned)s1 | 1u)) + u1), (5u ^ (unsigned)e0)); }
            while (i2++ < 4u && (unsigned)l0) { if (--fuel == 0u) goto done;
                r0.x = i0;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn0((a0[i0 & 3u] & a0[i0 & 3u]), (*q0 << (m0 & 31u)), g0); }
            l0 = (long)((unsigned long)l0 + (((unsigned)c0 ? p2 : g1) ^ 8u));
            break; (void)(~(unsigned)((unsigned)((unsigned)h0 || m0) || (unsigned)b0));
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)p1;
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    m0 ^= ((r0.x | (unsigned)e0) - m0);
                    garr[-(a0[u1 & 3u] ^ (unsigned)d0) & 7u] = 0x10000u;
                    l0 = (long)((unsigned long)l0 + ((unsigned)((unsigned)c0 && 0x9d48e589u) ^ (p2 >> (0x80000000u & 31u))));
                    { unsigned t1; double z1; if (((unsigned)((0xec2fb819u >> (0x80000000u & 31u)) < p2)) & 1u) { t1 = 0x80000000u; z1 = (double)((a0[u1 & 3u]) & 255u); } if (((unsigned)((0xec2fb819u >> (0x80000000u & 31u)) < p2)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                        if (-(0x62cc28ffu >> (0xc7680e1au & 31u))) break;
                    }
                    if ((u3 - u3)) break;
                    *q0 += (2u / ((0x7586a880u & 0x10000u) | 1u));
                }
                if ((unsigned)f0) goto L3;
                u0 = ((unsigned)h1 >> (((unsigned)((int)(unsigned)h0 >= (int)(unsigned)(x0 >> 70)) | 0xffffffffu) & 31u));
                if ((*q0 >> (2u & 31u))) break;
            }
        }
        { unsigned t2; double z2; if (((unsigned)f0) & 1u) { t2 = (-(unsigned)(p2 == i2) & (unsigned)h0); z2 = (double)((((unsigned)x0 ^ (unsigned)c1)) & 255u); } if (((unsigned)f0) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            s1 = (int)((unsigned)s1 + 0xc0e46735u);
            g0 = (p1 << (i0 & 31u));
            if ((unsigned)c1) continue;
            v0 = (unsigned)((int)0x80000000u >= (int)u2);
            f0 = f0 * 0.5f + (float)((unsigned)b0 & 255u);
            *mp = ((unsigned)((int)a0[i0 & 3u] < (int)(unsigned)f0) ^ 1u);
        }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            q0 = &garr[-(a0[i0 & 3u] - *mp) & 7u];
            u0 ^= 0xffffffffu;
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                u1 ^= (unsigned)((unsigned)(signed char)((unsigned)((unsigned)f0 == 8u) << ((unsigned)(signed char)(unsigned)((int)u0 >= (int)(unsigned)h1) & 31u)) || 9u);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)d0, (unsigned)(u1 || (fuel << (a0[i0 & 3u] & 31u))), 0x6fe60685u); }
            }
        }
        if ((0x7fffffffu << (a0[u1 & 3u] & 31u))) break;
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0(8u, (unsigned)((int)(r0.x & v0) >= (int)0xffffffffu), 9u); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((0xffffffffu * (unsigned)b0)) goto L3;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)i1 << (((unsigned)((int)~(fuel ? u1 : a0[i0 & 3u]) >= (int)*mp) - u1) & 63u);
        if (garr[i1 & 7u]) {
            q0 = &garr[((0xac07b2e2u ? i1 : (unsigned)(w0 >> 29)) * (unsigned)((short)fuel > (signed char)0x5b58a626u)) & 7u];
            c1 = (signed char)-(unsigned)((u1 ^ 0x486535ebu) || (v0 + 5u));
            continue; (void)((unsigned)d0);
            if (g1) {
                s0 = (int)((unsigned)e0 % ((m0 ^ p1) | 1u));
                switch ((unsigned)h0 & 7u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)w0 % (u1 | 1u)), (u0 & 9u), fuel); }
                    h0 = (short)((unsigned)((a0[u1 & 3u] - 6u) || (unsigned)s0) + (unsigned)b0);
                    h0 = (short)(unsigned)((short)(unsigned)((int)(unsigned)h0 >= (int)m0) > (signed char)0x10000u);
                    L0: if (--fuel == 0u) goto done;
                    if (2u) break;
                }
                c0 = (unsigned char)((g1 % (4u | 1u)) + (a0[i0 & 3u] >> ((unsigned)(0x7fffffffu && 0x324bdc39u) & 31u)));
            } else {
                *mp = (~(*q0 ^ i2) & (p1 * 5u));
                switch (0x92e3cfe8u & 7u) {
                    r0.y ^= (r0.x << ((7u % (0x80000000u | 1u)) & 31u));
                    if ((unsigned)((g0 / (0xffffffffu | 1u)) == (unsigned)x0)) break;
                    h0 = (short)(unsigned)s0;
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)p2 >= (int)0x2109346eu), (unsigned)(*q0 < fuel), 0x26bd9709u); }
                    l0 = (long)((unsigned long)l0 + (unsigned)(r0.x < ((unsigned)c1 * (unsigned)f0)));
                    r0.y ^= (unsigned)f0;
                }
                u3 = (unsigned)(short)(0x80000000u / (((unsigned)l0 >> (v0 & 31u)) | 1u));
                if (((unsigned)(0xffffffffu == (unsigned)h0) % (p0 | 1u))) break;
            }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(p0, (unsigned)(signed char)((unsigned)d0 & (unsigned)c1), ((unsigned)(*q0 == g1) + 5u)); }
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)h0 % ((unsigned)((int)(unsigned)c1 >= (int)a0[i0 & 3u]) | 1u)), *q0, (garr[i1 & 7u] + (unsigned)(0x80000000u == p2))); }
            if (budget != 0u) { budget -= 1u; u1 = fn1(0u, ((unsigned)l0 + (unsigned)f0), r0.y); }
            do { if (--fuel == 0u) goto done;
                goto L3;
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    L1: if (--fuel == 0u) goto done;
                    g0 = ((unsigned)f0 ? (unsigned)(p1 < 0x7fffffffu) : (4u / (3u | 1u)));
                }
                u2 ^= (unsigned)((int)p2 < (int)i0);
                *q0 = (((unsigned)(x0 >> 70) & (unsigned)((unsigned)c0 || 0x80000000u)) | (v0 % (a0[u1 & 3u] | 1u)));
                r0.y ^= (unsigned)((u0 & (unsigned)h1) < ((unsigned)c0 - (unsigned)(unsigned char)((unsigned)l0 & u0)));
                do { if (--fuel == 0u) goto done;
                    c1 = (signed char)(((unsigned)f0 | (0xd752fa41u << (0x2f4297ceu & 31u))) / ((unsigned)s1 | 1u));
                    goto L1;
                    if ((unsigned)(signed char)(unsigned)((short)garr[i1 & 7u] > (signed char)(unsigned)l0)) break;
                    if ((0x10000u * ((unsigned)b0 - (unsigned)(x0 >> 70)))) {
                        if ((unsigned)(signed char)((unsigned)h0 ^ 0x6334dfc1u)) break;
                        garr[(unsigned)((short)(unsigned)l0 > (signed char)0x10000u) & 7u] = (unsigned)c0;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((0x10000u << (0xdd54f789u & 31u)), ((unsigned)((int)(unsigned)d0 < (int)(unsigned)f0) * 3u), *q0); }
                        do { if (--fuel == 0u) goto done;
                            break; (void)((unsigned)((short)1u > (signed char)(unsigned)s1));
                            break; (void)((unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)(0x7fffffffu || r0.y)));
                            if (u3 == 7u) return 0x8638e770u;
                            g0 = ((unsigned)w0 - u2);
                            c0 = (unsigned char)((unsigned)(w0 >> 29) | 5u);
                        } while (i1++ < 5u && (0x7fffffffu + 0x10000u));
                    }
                } while (i0++ < 2u && (8u | (unsigned)(unsigned char)(unsigned)((int)(unsigned)s1 >= (int)(unsigned)s0)));
            } while (i2++ < 6u && (0xf8174910u + (unsigned)s0));
        }
        if ((g1 + *mp)) goto L0;
        break; (void)((unsigned)((int)u0 >= (int)3u));
    }
    c1 = (signed char)0x8921a4d7u;
    { unsigned t0; double z0; if (((unsigned)((m0 >> (g0 & 31u)) || 6u)) & 1u) { t0 = (unsigned)!(0x80000000u % (0x10000u | 1u)); z0 = (double)(((unsigned)((unsigned)((short)0x82918e5bu > (signed char)0x7fffffffu) == (unsigned)s0)) & 255u); } if (((unsigned)((m0 >> (g0 & 31u)) || 6u)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)(w0 >> 29)), (unsigned)!(unsigned)((int)(unsigned)h0 < (int)i0), garr[u2 & 7u]); }
        s0 = (int)(unsigned)((((unsigned)c0 / (0xffffffffu | 1u)) >> (garr[i1 & 7u] & 31u)) == (r0.y ^ (unsigned)d0));
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)w0 == (unsigned)(8u == (unsigned)e0))) goto done;
            l0 = (long)((unsigned long)l0 + 0x6513ca44u);
            g1 += (m0 * (unsigned)((unsigned)l0 || (p1 & 7u)));
        }
        s1 = (int)((unsigned)s1 + p0);
        if (~(unsigned)((int)r0.x < (int)(unsigned)l0)) goto L4;
    }
    if (((unsigned)x0 >> (u0 & 31u))) {
        if (budget != 0u) { budget -= 1u; u2 = fn1(p2, (garr[i1 & 7u] >> (*q0 & 31u)), 0xffffffffu); }
        u3 = u3 * 0x9e3779b1u + (unsigned)s0;
    } else {
        { unsigned t1; double z1; if (((0xaced9089u - (unsigned)(unsigned char)(0x10000u * g0))) & 1u) { t1 = (unsigned)(garr[i1 & 7u] == (unsigned)s0); z1 = (double)((8u) & 255u); } if (((0xaced9089u - (unsigned)(unsigned char)(0x10000u * g0))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            if (fuel < 8u) return (unsigned)((unsigned)!(0u + 5u) == 0xd50db1fau);
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)w0, ((unsigned)s1 * ((unsigned)b0 >> (u0 & 31u))), ((unsigned)(9u == 0x7fffffffu) ^ (unsigned)e0)); }
        garr[(unsigned)f0 & 7u] = i1;
        r0.x = (unsigned)((unsigned)((unsigned)x0 && p1) == (unsigned)(u2 || g0));
    }
    if (((unsigned)s1 << ((m0 / (r0.x | 1u)) & 31u))) goto L2;
    if (((unsigned)(u1 && p0) % (i2 | 1u))) goto L2;
    *mp = (unsigned)((short)(unsigned)e0 > (signed char)(unsigned)c0);
    if ((unsigned)(0x10000u < 7u)) {
        d0 = d0 * 0.5 + (double)(((u0 - ((unsigned)l0 + (0x6f176576u ^ p1))) << ((unsigned)w0 & 31u)) & 1023u);
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            L2: if (--fuel == 0u) goto done;
            r0.y ^= (unsigned)((int)-(unsigned)(0xd7c56d1u == i1) < (int)((unsigned)e0 ? p0 : 0xffffffffu));
            h1 = (unsigned short)(h1 + 3u);
            while (i1++ < 4u && ~(unsigned)((int)0x2c1f9ff6u >= (int)(unsigned)((unsigned)(x0 >> 70) < g0))) { if (--fuel == 0u) goto done;
                if ((unsigned)((0x790078c3u | garr[i1 & 7u]) == (unsigned)c0)) break;
            }
        }
        { unsigned t2; double z2; if (((0x10000u * (unsigned)(0x80000000u || 0x80000000u))) & 1u) { t2 = (unsigned)((int)0x7fffffffu < (int)(unsigned)l0); z2 = (double)(((unsigned)(0xa76c46eu < (unsigned)x0)) & 255u); } if (((0x10000u * (unsigned)(0x80000000u || 0x80000000u))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                u1 = g1;
            }
            if (((unsigned)((unsigned)h1 || 0x10000u) + a0[u1 & 3u])) goto L4;
            if ((a0[u1 & 3u] ^ 0x80000000u)) {
                a0[v0 & 3u] = garr[u2 & 7u];
                if (fuel < 8u) return (unsigned)(0u || 8u);
                if (0x80000000u) goto done;
            } else {
                goto done;
            }
            *q0 = (p0 & (unsigned)((short)0x6b81d430u > (signed char)(unsigned)((unsigned)b0 == (fuel << (0x7fffffffu & 31u)))));
            goto L0;
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((int)i2 >= (int)((unsigned)c0 << ((unsigned)s1 & 31u))));
                        h1 = (unsigned short)(h1 + (a0[i0 & 3u] ^ ~(4u - (unsigned)f0)));
                        q0 = &garr[(unsigned)(0x7ba4b7f8u && (unsigned)(unsigned char)(2u & 0x59ad6418u)) & 7u];
                    } while (i2++ < 7u && ~((unsigned)c0 * (r0.x + 5u)));
                }
                c0 = (unsigned char)(v0 ^ (r0.y ? 0xffffffffu : 0x69aa790bu));
                h1 = (unsigned short)(h1 + (p1 / (((unsigned)x0 & (3u | g1)) | 1u)));
                switch (((unsigned)(u2 || 0xffffffffu) | (unsigned)s0) & 7u) {
                    goto L2;
                    do { if (--fuel == 0u) goto done;
                        b0 = (unsigned)(~(unsigned)((int)(unsigned)h0 >= (int)(unsigned)(x0 >> 70)) && -(r0.x + 0x10000u)) != 0u;
                        L3: if (--fuel == 0u) goto done;
                        L4: if (--fuel == 0u) goto done;
                        { unsigned t3; double z3; if (((unsigned)!(unsigned)(a0[i0 & 3u] || p1)) & 1u) { t3 = (unsigned)(x0 >> 70); z3 = (double)(((unsigned)((int)(unsigned)!(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)0xffffffffu) < (int)0x5ce9c1d6u)) & 255u); } if (((unsigned)!(unsigned)(a0[i0 & 3u] || p1)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                            if ((unsigned)(0x3b441e9fu || 0xf7ba76f0u)) break;
                            e0 = e0 * 0.5L + (long double)((unsigned)((short)((unsigned)d0 * m0) > (signed char)(unsigned)f0) & 1023u);
                            h0 = (short)i0;
                            continue; (void)(i1);
                            d0 = d0 * 0.5 + (double)((unsigned)(signed char)(garr[u2 & 7u] & (unsigned)(((unsigned)w0 * p2) || (unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)l0))) & 1023u);
                        }
                        r0.x = (0x44bf718eu & (((unsigned)(unsigned char)(unsigned)(*q0 == (unsigned)f0) & 0x1012140cu) + 0x9ac7f2d7u));
                        *q0 = (((unsigned)x0 / ((unsigned)c1 | 1u)) + (p0 >> (4u & 31u)));
                    } while (i1++ < 2u && (u3 >> (4u & 31u)));
                    *q0 = (r0.y % ((unsigned)(3u == u3) | 1u));
                    a0[0x80000000u & 3u] = -((unsigned)((short)2u > (signed char)((unsigned)((unsigned)h1 == (unsigned)w0) + 0x80000000u)) / (0x9e79ff53u | 1u));
                }
                if (((7u & p0) | g0)) break;
                if (budget != 0u) { budget -= 1u; u0 = fn0(g1, 3u, ((unsigned)d0 >> (a0[i0 & 3u] & 31u))); }
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)(unsigned)x0 >= (int)0x80000000u), (unsigned)((unsigned)x0 == ((unsigned)s1 - 6u)), (unsigned)((int)r0.x >= (int)v0)); }
        if (*q0) goto L4;
    } else {
        *q0 = ((unsigned)((unsigned)((int)(unsigned)d0 < (int)p2) || (unsigned)(unsigned char)((unsigned)h1 + u2)) >> (u2 & 31u));
        switch ((unsigned)(u0 && r0.x) & 7u) {
            c1 = (signed char)(unsigned)e0;
        }
        if (budget != 0u) { budget -= 1u; u2 = fn0(g1, v0, 0u); }
    }
    do { if (--fuel == 0u) goto done;
        if (5u) break;
        if ((garr[u2 & 7u] % (v0 | 1u))) {
            switch (((unsigned)f0 ^ (unsigned)s1) & 7u) {
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)w0 || g0), *mp, (unsigned)(v0 && r0.y)); }
                v0 = ((unsigned)((int)fuel < (int)a0[i0 & 3u]) | (u2 + (unsigned)s0));
                if (budget != 0u) { budget -= 1u; u0 = fn0(0x7fffffffu, ((5u | a0[u1 & 3u]) + a0[i0 & 3u]), (((unsigned)h1 - i2) / (m0 | 1u))); }
                case 7u: ;
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (-((unsigned)(x0 >> 70) >> (g0 & 31u))) continue;
                }
            }
            w0 = w0 * 6364136223846793005ull + (g0 ? (0x53111093u & (unsigned)c0) : g1);
            if ((unsigned)h1) break;
        } else {
            h0 = (short)(unsigned)(signed char)(garr[u2 & 7u] ^ -((unsigned)h0 * u3));
        }
        s1 = (int)((unsigned)s1 + 0x13e148bbu);
        if ((unsigned)(r0.x == ((unsigned)(w0 >> 29) & u0))) break;
        while ((p1 + i1)) { if (--fuel == 0u) goto done;
            v0 = p2;
            *q0 = ((unsigned)(unsigned char)((unsigned)w0 >> (garr[i1 & 7u] & 31u)) ? 0xffffffffu : (unsigned)((unsigned)d0 || i0));
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if ((0xffffffffu | 0x7fffffffu)) {
                    if (budget != 0u) { budget -= 1u; u3 = fn0((1u ^ (unsigned)!(unsigned)((int)0x7fffffffu < (int)0x10000u)), (unsigned)((unsigned)(unsigned char)(unsigned)(*mp < 0x10000u) && g1), fuel); }
                    do { if (--fuel == 0u) goto done;
                        if ((unsigned)((short)fuel > (signed char)p1)) break;
                        break; (void)(((unsigned)((int)*q0 < (int)m0) | r0.y));
                    } while (i0++ < 2u && ((unsigned)b0 % (garr[u2 & 7u] | 1u)));
                } else {
                    u1 = u1 * 0x9e3779b1u + (unsigned)(r0.y && (garr[u2 & 7u] | (unsigned)(signed char)(unsigned)(0xffffffffu < (unsigned)h0)));
                }
            }
            if ((unsigned)((int)0xa973f308u < (int)(unsigned)(signed char)(unsigned)(0xbee9156fu == 0x9c3c2f4du))) break;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(short)(unsigned)(0x10000u || (unsigned)(0x10000u && g1)), (g0 & *q0), (unsigned)((short)(unsigned)s0 > (signed char)3u)); }
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                u1 = u1 * 0x9e3779b1u + (v0 + ((unsigned)(x0 >> 70) & (unsigned)h0));
                d0 = d0 * 0.5 + (double)((unsigned)((p2 + 0xd6d80a57u) < u1) & 1023u);
                if (u3) break;
                w0 = w0 * 6364136223846793005ull + (unsigned)((((p0 ^ (unsigned)l0) % (m0 | 1u)) | i0) && (unsigned)b0);
                if (((unsigned)h1 + (unsigned)f0)) break;
                if (0xa6fc39d4u) goto L2;
            }
        }
        if ((((unsigned)l0 - u3) & *q0)) break;
    } while (i0++ < 7u && u0);
    switch (~(p1 % (u0 | 1u)) & 7u) {
        case 5u: ;
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            *mp = (i0 ^ (unsigned)((short)p1 > (signed char)(unsigned)x0));
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)s0 << ((unsigned)b0 & 31u)), (unsigned)!((unsigned)f0 ^ a0[u1 & 3u]), (unsigned)((int)i1 < (int)(unsigned)h0)); }
                u3 = u3 * 0x9e3779b1u + (unsigned)(unsigned char)(unsigned)(((unsigned)l0 >> (((unsigned)c1 >> (m0 & 31u)) & 31u)) || m0);
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)d0, (((unsigned)c1 ^ 6u) ^ 0x43589b87u), v0); }
                case 7u: ;
            }
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)b0 < (int)(unsigned)(0xf57adf53u || u0));
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)w0 < g0), (i2 | (unsigned)(w0 >> 29)), (unsigned)(signed char)(0x19529958u % ((1u * 5u) | 1u))); }
                { unsigned t4; double z4; if ((0u) & 1u) { t4 = (unsigned)((short)*mp > (signed char)g1); z4 = (double)((((4u + a0[i0 & 3u]) + 0x7fffffffu)) & 255u); } if ((0u) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                    l0 = (long)((unsigned long)l0 + 0x7ee0ffb7u);
                }
                w0 = w0 * 6364136223846793005ull + (((unsigned)(i1 && (unsigned)w0) << (i0 & 31u)) << (i2 & 31u));
            }
            if ((unsigned)((int)(unsigned)c1 >= (int)(unsigned)((unsigned)h0 || u2))) goto L4;
            if (u3 == 7u) return (unsigned)((int)a0[i0 & 3u] >= (int)u0);
        }
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            garr[(unsigned)((unsigned)h0 == p1) & 7u] = ((0xe14b624u << (fuel & 31u)) * 0x6070f0d8u);
            garr[0xfdc6e85bu & 7u] = ((unsigned)d0 + (5u << (((unsigned)l0 | 0x80000000u) & 31u)));
            r0.x = ((unsigned)((short)g1 > (signed char)(unsigned)((unsigned)l0 < (unsigned)(i0 && 0x20a0db81u))) ^ 5u);
        }
    }
    { unsigned t5; double z5; if ((0x6657d045u) & 1u) { t5 = (unsigned)c0; z5 = (double)(((unsigned)((int)0x10000u >= (int)(a0[i0 & 3u] - p1))) & 255u); } if ((0x6657d045u) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            u0 += a0[u1 & 3u];
        }
        w0 ^= (unsigned long long)((unsigned)d0 * u3) << ((unsigned)(unsigned char)((unsigned)h0 * (unsigned)(u1 == r0.x)) & 63u);
        *q0 = (4u >> ((unsigned)(unsigned char)(unsigned)((short)0x7fffffffu > (signed char)(unsigned)((int)0x7fffffffu >= (int)7u)) & 31u));
        *q0 += ((u1 << ((0x271afccfu ^ (unsigned)(x0 >> 70)) & 31u)) & (0xda3f6edau + (unsigned)x0));
        s0 = (int)(p0 - (0x10000u / ((0xffffffffu ? (unsigned)(w0 >> 29) : (unsigned)(w0 >> 29)) | 1u)));
    }
    g0 = (unsigned)((int)g1 < (int)0xe0ef3b44u);
    if (r0.x) goto L4;
    *q0 = a0[u1 & 3u];
    switch (~(i1 << ((unsigned)l0 & 31u)) & 7u) {
        if (~(0x7fbcc1ceu / ((unsigned)c0 | 1u))) {
            while (i0++ < 3u && (unsigned)((unsigned)((unsigned)e0 || u2) && (unsigned)h0)) { if (--fuel == 0u) goto done;
                switch ((0x8787baf3u >> ((garr[u2 & 7u] / (garr[u2 & 7u] | 1u)) & 31u)) & 7u) {
                    g1 += (g1 + 4u);
                }
                case 4u: ;
                w0 ^= (unsigned long long)0x10000u << ((unsigned)(v0 && (fuel + ~(p0 ? r0.x : 0x350e2926u))) & 63u);
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)((unsigned)l0 << (*mp & 31u)) >= (int)((0xffffffffu * v0) % (0xffffffffu | 1u)));
            }
            c0 = (unsigned char)((unsigned)e0 * a0[u1 & 3u]);
            *q0 = (9u - (unsigned)b0);
            f0 = f0 * 0.5f + (float)(~((unsigned)e0 >> ((((unsigned)b0 % (u2 | 1u)) * i1) & 31u)) & 255u);
            w0 ^= (unsigned long long)(unsigned)((int)p1 < (int)(unsigned)e0) << (0x9d15c1d0u & 63u);
        }
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(unsigned char)(unsigned)((int)i0 < (int)3u), (i2 - u2), (unsigned)((int)(0xdcb43858u & (unsigned)h1) >= (int)(unsigned)e0)); }
            if ((m0 % (3u | 1u))) break;
        } while (i0++ < 3u && ((fuel & 3u) & fuel));
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            w0 = w0 * 6364136223846793005ull + (unsigned)(short)((unsigned)((short)~(i1 >> ((unsigned)(x0 >> 70) & 31u)) > (signed char)i1) << (i1 & 31u));
            w0 ^= (unsigned long long)(g1 | g0) << ((unsigned)(~((unsigned)l0 + (unsigned)((int)0x9c0bed9u >= (int)0x4c8e47f7u)) || (u3 << (u0 & 31u))) & 63u);
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)(unsigned)((unsigned)h1 && (i2 / ((unsigned)x0 | 1u))), (unsigned)((int)(unsigned)e0 < (int)((unsigned)h1 & u3)), p2); }
            while (i1++ < 7u && (unsigned)h0) { if (--fuel == 0u) goto done;
                if ((unsigned)((int)p0 >= (int)(2u / (5u | 1u)))) break;
                switch (((unsigned)d0 + v0) & 7u) {
                    if (u3 == 7u) return a0[u1 & 3u];
                    case 1u: ;
                    if (((unsigned)s0 % ((unsigned)(0x4a31a368u || 0xffffffffu) | 1u))) continue;
                    case 6u: ;
                    b0 = (unsigned)((int)3u < (int)garr[u2 & 7u]) != 0u;
                }
                x0 = x0 * 0x100000001b3ull + (p2 ^ ((unsigned)b0 ^ (0xfa4f670fu / ((unsigned)s1 | 1u))));
                if (fuel < 8u) return (unsigned)((short)i1 > (signed char)(0x7fffffffu / ((unsigned)h1 | 1u)));
                if ((unsigned)x0) break;
            }
            if ((unsigned)(u0 && (unsigned)((int)(unsigned)b0 >= (int)(unsigned)w0))) continue;
            if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)l0 / ((unsigned)(0xf7a93340u == (unsigned)h1) | 1u)), ((unsigned)b0 * (unsigned)((int)(unsigned)(w0 >> 29) < (int)0xf9cfb755u)), (unsigned)(u2 == (unsigned)e0)); }
        }
        if (fuel < 8u) return (i1 ^ u0);
    }
    *q0 += ((unsigned)(signed char)(unsigned)((short)(unsigned)h0 > (signed char)a0[i0 & 3u]) * (unsigned)d0);
    if (0x993f32a8u) {
        { unsigned t6; double z6; if (((unsigned)((int)p2 < (int)~(unsigned)(r0.y && 5u))) & 1u) { t6 = (unsigned)((unsigned)(unsigned char)(unsigned)(0x80000000u < p1) && 0xcb11a964u); z6 = (double)((((m0 << ((unsigned)h1 & 31u)) ^ (unsigned)c0)) & 255u); } if (((unsigned)((int)p2 < (int)~(unsigned)(r0.y && 5u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
            { unsigned t7; double z7; if (((g0 | 0xffffffffu)) & 1u) { t7 = (unsigned)w0; z7 = (double)(((unsigned)((int)(u3 << ((unsigned)(x0 >> 70) & 31u)) < (int)7u)) & 255u); } if (((g0 | 0xffffffffu)) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
                x0 = x0 * 0x100000001b3ull + m0;
                i2 = (u2 % ((unsigned)f0 | 1u)) & 15u;
                if (budget != 0u) { budget -= 1u; u0 = fn1((0xd707f3f9u | (unsigned)(w0 >> 29)), (unsigned)b0, (unsigned)(m0 < m0)); }
                do { if (--fuel == 0u) goto done;
                    if ((v0 % (u3 | 1u))) {
                        g1 += (unsigned)((short)(unsigned)h1 > (signed char)(((unsigned)x0 ^ (unsigned)h1) ^ r0.y));
                        if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)s1 << (0x994d1006u & 31u)), 0x80000000u, (unsigned)(r0.y == 0u)); }
                        if ((p0 + (unsigned)((int)p0 < (int)u0))) break;
                        g1 += (unsigned)(fuel || (g0 & u3));
                    }
                } while (i0++ < 6u && (u2 % (u2 | 1u)));
            }
            if (5u) goto L2;
            if ((0x10000u >> ((unsigned)(1u || u0) & 31u))) {
                w0 = w0 * 6364136223846793005ull + u0;
                { unsigned t8; double z8; if (((u0 % (a0[u1 & 3u] | 1u))) & 1u) { t8 = 7u; z8 = (double)(((unsigned)d0) & 255u); } if (((u0 % (a0[u1 & 3u] | 1u))) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                    if ((unsigned)((unsigned)(w0 >> 29) < (m0 + 0xffffffffu))) goto L2;
                    if (0x473720b8u) goto L0;
                    { unsigned t9; double z9; if (((unsigned)(4u || 0u)) & 1u) { t9 = (unsigned)((int)(unsigned)s0 >= (int)p0); z9 = (double)(((0x80000000u / ((unsigned)(w0 >> 29) | 1u))) & 255u); } if (((unsigned)(4u || 0u)) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                        if (fuel < 8u) return ((unsigned)(w0 >> 29) ^ 0x210add10u);
                        r0.y ^= -((unsigned)w0 ? (unsigned)((short)garr[i1 & 7u] > (signed char)u1) : 0x80000000u);
                        for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                            i2 = (unsigned)((int)u0 >= (int)0x9a7040f6u) & 15u;
                            b0 = (0u >> (((unsigned)((unsigned)s1 && g0) * i1) & 31u)) != 0u;
                            x0 = x0 * 0x100000001b3ull + (fuel + (unsigned)w0);
                            d0 = d0 * 0.5 + (double)(v0 & 1023u);
                            l0 = (long)((unsigned long)l0 + (unsigned)(a0[u1 & 3u] == ((unsigned)((unsigned)l0 && (unsigned)(w0 >> 29)) << (m0 & 31u))));
                        }
                        e0 = e0 * 0.5L + (long double)(~(m0 / (((unsigned)(p2 && (unsigned)f0) >> (4u & 31u)) | 1u)) & 1023u);
                    }
                    *mp = (unsigned)!(unsigned)((unsigned)((short)fuel > (signed char)(unsigned)e0) == u1);
                    d0 = d0 * 0.5 + (double)((v0 % (0xffffffffu | 1u)) & 1023u);
                    if ((unsigned)(garr[i1 & 7u] && 0xffffffffu)) goto L3;
                }
                { unsigned t10; double z10; if (((unsigned)((int)(u0 << (i2 & 31u)) < (int)(unsigned)e0)) & 1u) { t10 = (unsigned)((unsigned)h1 == u2); z10 = (double)((m0) & 255u); } if (((unsigned)((int)(u0 << (i2 & 31u)) < (int)(unsigned)e0)) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                    *mp = (0x7fffffffu << (0u & 31u));
                    if ((0x1a76d8a3u % (0xfaa8a1ffu | 1u))) goto done;
                    goto done;
                    m0 ^= (g1 - (unsigned)((4u | 0x22a89788u) < u0));
                    if (budget != 0u) { budget -= 1u; u1 = fn1(0xe047b8afu, ((unsigned)e0 ^ (unsigned)f0), (unsigned)((int)u1 >= (int)8u)); }
                }
                goto done;
            } else {
                while (i0++ < 6u && (unsigned)((unsigned)c1 && (unsigned)w0)) { if (--fuel == 0u) goto done;
                    continue; (void)((unsigned)((unsigned)x0 == p2));
                    a0[(unsigned)(0x80000000u == 1u) & 3u] = -(unsigned)(i0 == 0xec01e081u);
                }
                i1 = (p0 / (((unsigned)(x0 >> 70) + (v0 % ((unsigned)l0 | 1u))) | 1u)) & 15u;
                r0.x = (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)b0);
            }
        }
        b0 = (p1 & p0) != 0u;
        if ((0x80000000u / ((unsigned)e0 | 1u))) {
            { unsigned t11; double z11; if (((unsigned)(((unsigned)(x0 >> 70) & (unsigned)l0) < fuel)) & 1u) { t11 = garr[i1 & 7u]; z11 = (double)(((i0 / (u3 | 1u))) & 255u); } if (((unsigned)(((unsigned)(x0 >> 70) & (unsigned)l0) < fuel)) & 1u) { u0 += t11; d0 = d0 * 0.5 + z11; }
                *q0 = (unsigned)((0xdcd5a9aeu / (0x60289ed7u | 1u)) || 0x10000u);
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)9u < (int)(unsigned)!((unsigned)c1 % (5u | 1u))), ((u1 & a0[i0 & 3u]) & a0[u1 & 3u]), (u2 % (u2 | 1u))); }
                goto L0;
                c1 = (signed char)(unsigned)((unsigned)(m0 && g0) || (unsigned)(unsigned char)(0x80000000u << (0x80000000u & 31u)));
            }
            if (~((unsigned)s1 ^ (9u + (unsigned)h1))) {
                if (0u) goto done;
                u0 ^= (g1 << (g1 & 31u));
                garr[((unsigned)s1 * (unsigned)c1) & 7u] = (4u * garr[i1 & 7u]);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)0x80000000u > (signed char)(unsigned)s0), (unsigned)((int)(unsigned)s0 >= (int)(u2 / (0x9220390cu | 1u))), (unsigned)((short)(u0 | u3) > (signed char)(unsigned)h1)); }
                w0 ^= (unsigned long long)((unsigned)c1 | p0) << ((unsigned)(unsigned char)(((unsigned)c0 & 0u) / ((unsigned)((unsigned)b0 < (unsigned)s1) | 1u)) & 63u);
            } else {
                s1 = (int)((unsigned)s1 + 0x10000u);
            }
        }
        r0.y ^= 0x7fffffffu;
        g0 = ((unsigned)(short)(unsigned)((int)p2 < (int)0x4132e549u) * g1);
    }
    while ((m0 | (unsigned)b0)) { if (--fuel == 0u) goto done;
        if ((-(0x10000u / (0x10000u | 1u)) + r0.y)) {
            garr[u0 & 7u] = (unsigned)(u1 == (unsigned)c1);
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0xffffffffu == 0x59c8aaedu), 7u, (unsigned)(r0.y == 0x10000u)); }
            while ((unsigned)((unsigned)(x0 >> 70) && *mp)) { if (--fuel == 0u) goto done;
                if ((unsigned)((short)p0 > (signed char)(unsigned)(6u && g1))) {
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)d0 == 0x712ca96du), *q0, (2u - (garr[i1 & 7u] ^ r0.y))); }
                    switch ((unsigned)((short)(0x46700d13u ^ 0xa63d54e9u) > (signed char)garr[i1 & 7u]) & 7u) {
                        *mp = (unsigned)!(((unsigned)x0 % ((unsigned)(x0 >> 70) | 1u)) % (0x7fffffffu | 1u));
                        w0 = w0 * 6364136223846793005ull + (unsigned)(((unsigned)d0 ? (fuel % (i2 | 1u)) : *q0) && g1);
                        if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)((unsigned)c0 < 0x7fffffffu) ^ 0x3ebd400au), (0x80000000u & i1), ((0xe40bd98bu / (0x7fffffffu | 1u)) & 2u)); }
                    }
                }
                d0 = d0 * 0.5 + (double)((~(unsigned)(((unsigned)(w0 >> 29) - 0x80000000u) && (unsigned)x0) ^ (unsigned)f0) & 1023u);
                f0 = f0 * 0.5f + (float)((unsigned)((u3 + ((unsigned)d0 * (unsigned)f0)) && m0) & 255u);
                switch ((unsigned)(w0 >> 29) & 7u) {
                    g1 += (unsigned)(((p0 & 0xf8ac3c61u) | (unsigned)d0) < (unsigned)(a0[u1 & 3u] < (unsigned)(w0 >> 29)));
                }
                if ((unsigned)w0) break;
            }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)((int)(unsigned)l0 < (int)p2)) break;
                while (i2++ < 4u && (unsigned)d0) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)((int)2u < (int)p2));
                        l0 = (long)((unsigned long)l0 + ((unsigned)(2u && *q0) & p1));
                        while (i1++ < 5u && (unsigned)d0) { if (--fuel == 0u) goto done;
                            x0 = x0 * 0x100000001b3ull + (4u - 0u);
                            goto done;
                        }
                        break; (void)((unsigned)(0x80000000u < (unsigned)(w0 >> 29)));
                    } while (i0++ < 3u && (unsigned)s1);
                    if ((garr[i1 & 7u] - 0xccbdc722u)) goto L0;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)u1 < (int)((unsigned)e0 * g1)), (3u / (a0[i0 & 3u] | 1u)), ~(unsigned)(a0[u1 & 3u] < u3)); }
                    if ((i0 ? (unsigned)c0 : (unsigned)d0)) continue;
                    u2 += (unsigned)((unsigned)(2u < (u3 % (i2 | 1u))) || (unsigned)(8u == 0x7353f6c7u));
                    w0 = w0 * 6364136223846793005ull + ((u2 ^ (m0 - garr[u2 & 7u])) ^ (unsigned)d0);
                }
            } while (i1++ < 4u && (unsigned)((int)(unsigned)(a0[i0 & 3u] || fuel) < (int)(unsigned)h0));
            switch ((unsigned)h0 & 7u) {
                w0 = w0 * 6364136223846793005ull + u1;
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)e0, fuel, (unsigned)(x0 >> 70)); }
        l0 = (long)((unsigned long)l0 + 9u);
        if ((r0.x & ((unsigned)w0 / (0x83982b74u | 1u)))) break;
        v0 = (unsigned)c1;
        g0 = 0x70ac0355u;
    }
    if ((unsigned)((int)0x7fffffffu < (int)(unsigned)(w0 >> 29))) {
        for (;;) { if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)(((unsigned)(w0 >> 29) ? *mp : a0[u1 & 3u]) & 1023u);
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)(x0 >> 70)) continue;
                l0 = (long)((unsigned long)l0 + (unsigned)!(0x7fffffffu + (unsigned)b0));
                if (v0) break;
            }
            g1 += (unsigned)((int)(unsigned)((p1 | (unsigned)s1) && 0x3fdadd9bu) < (int)(garr[i1 & 7u] ^ (unsigned)h1));
            if (-((unsigned)x0 * v0)) {
                if ((u0 >> ((unsigned)((int)2u < (int)i1) & 31u))) break;
                g1 += (unsigned)(unsigned char)(a0[u1 & 3u] / ((unsigned)((int)0x10000u < (int)(unsigned)((int)7u < (int)(8u % (v0 | 1u)))) | 1u));
            }
            if ((unsigned)((int)1u >= (int)6u)) {
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(p1 < v0), (unsigned)(garr[i1 & 7u] || (unsigned)e0), ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)p0) / (0xc0c3da2u | 1u))); }
                w0 = w0 * 6364136223846793005ull + u2;
                u0 ^= ((0xb7ac4e97u % (0xada9b683u | 1u)) ? u0 : a0[u1 & 3u]);
                *q0 += (0xffffffffu / (-(unsigned)((short)(0xffffffffu % ((unsigned)b0 | 1u)) > (signed char)g1) | 1u));
                l0 = (long)((unsigned long)l0 + (unsigned)((int)(r0.x - g1) >= (int)(u3 ^ 0xffffffffu)));
                { unsigned t12; double z12; if (((i0 ^ ~((unsigned)s0 + p1))) & 1u) { t12 = ((unsigned)(4u || p0) / (r0.y | 1u)); z12 = (double)((r0.x) & 255u); } if (((i0 ^ ~((unsigned)s0 + p1))) & 1u) { u3 += t12; d0 = d0 * 0.5 + z12; }
                    if ((unsigned)((unsigned)w0 || ((unsigned)h0 << ((unsigned)c0 & 31u)))) break;
                    u1 = ((unsigned)(short)(unsigned)((short)(unsigned)((unsigned)(r0.y || 0x10000u) || 0x7fffffffu) > (signed char)0xe30bf6e0u) + (unsigned)w0);
                    garr[(unsigned)((unsigned)f0 == 0x587d7207u) & 7u] = ((unsigned)((int)(unsigned)(short)(fuel >> ((unsigned)w0 & 31u)) >= (int)(unsigned)(unsigned char)(unsigned)(m0 == (unsigned)(w0 >> 29))) << (r0.x & 31u));
                }
            }
            break; (void)((unsigned)((int)(0xa385b113u - a0[u1 & 3u]) >= (int)r0.x));
        }
        if (((0x80000000u / ((unsigned)c1 | 1u)) - *mp)) goto L3;
        do { if (--fuel == 0u) goto done;
            a0[(6u ^ u1) & 3u] = (g1 ? 4u : ~(4u + p1));
            if ((unsigned)e0) break;
            { unsigned t13; double z13; if (((i0 ? (unsigned)l0 : 0x52682f7au)) & 1u) { t13 = (unsigned)(short)(unsigned)(1u == a0[i0 & 3u]); z13 = (double)(((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)!(unsigned)(0xffffffffu || a0[u1 & 3u]))) & 255u); } if (((i0 ? (unsigned)l0 : 0x52682f7au)) & 1u) { u3 += t13; d0 = d0 * 0.5 + z13; }
                if (((unsigned)l0 << (m0 & 31u))) continue;
                r0.x = (unsigned)(((unsigned)f0 >> (0x850f275eu & 31u)) || (u3 + ((unsigned)s0 ^ 7u)));
                if (budget != 0u) { budget -= 1u; u2 = fn0((0x96a5fa7bu | (*q0 >> ((unsigned)c0 & 31u))), (unsigned)(0x5e32c30eu || r0.x), 0x3763cd45u); }
                if ((unsigned)e0) {
                    if (((unsigned)c0 >> ((unsigned)(v0 == u3) & 31u))) break;
                    e0 = e0 * 0.5L + (long double)((4u | (unsigned)(signed char)(unsigned)(garr[i1 & 7u] < p1)) & 1023u);
                    r0.y ^= 6u;
                    v0 = -(0x80000000u / ((unsigned)(4u < g0) | 1u));
                    a0[(unsigned)((int)0x10000u < (int)g0) & 3u] = (unsigned)((int)(unsigned)((int)(unsigned)e0 >= (int)(unsigned)(x0 >> 70)) >= (int)1u);
                    break; (void)((unsigned)((int)i0 >= (int)r0.y));
                } else {
                    if ((unsigned)((unsigned)((unsigned)w0 || *q0) || (unsigned)d0)) break;
                    if (fuel < 8u) return ((unsigned)c1 | (0u & (unsigned)((int)((unsigned)s0 + 0x4b5f0326u) < (int)u3)));
                }
                switch ((7u / ((a0[i0 & 3u] >> ((unsigned)(x0 >> 70) & 31u)) | 1u)) & 7u) {
                    c1 = (signed char)1u;
                    goto L0;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(short)(i2 + r0.y), (unsigned)((int)((unsigned)d0 << (i1 & 31u)) >= (int)6u), *mp); }
            }
            e0 = e0 * 0.5L + (long double)((unsigned)((int)((0xffffffffu * 0x508515a6u) >> (g1 & 31u)) < (int)0xd04a6628u) & 1023u);
            while (i1++ < 6u && (((unsigned)c0 | garr[i1 & 7u]) | (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                garr[(unsigned)(v0 || r0.y) & 7u] = (unsigned)(unsigned char)((unsigned)h0 << ((unsigned)(w0 >> 29) & 31u));
                switch ((unsigned)s0 & 7u) {
                    case 6u: ;
                    case 1u: ;
                    if (u3 == 7u) return (unsigned)((short)m0 > (signed char)(0x7fe9f64u % (0x7fffffffu | 1u)));
                    s1 = (int)((unsigned)s1 + (1u << (((unsigned)s1 % ((unsigned)s1 | 1u)) & 31u)));
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        break; (void)(((unsigned)x0 % (8u | 1u)));
                        q0 = &garr[((unsigned)((int)a0[u1 & 3u] >= (int)0xffffffffu) % ((unsigned)((unsigned)s0 < 9u) | 1u)) & 7u];
                        w0 = w0 * 6364136223846793005ull + (*q0 - u2);
                        d0 = d0 * 0.5 + (double)(((unsigned)h0 & ((unsigned)f0 & (2u - a0[i0 & 3u]))) & 1023u);
                        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)d0 & (unsigned)h1), r0.x, (((unsigned)s0 - a0[u1 & 3u]) + 0x320449e3u)); }
                    }
                }
                if ((unsigned)w0) goto L4;
            }
        } while (i0++ < 7u && (3u >> ((unsigned)c0 & 31u)));
        do { if (--fuel == 0u) goto done;
            s1 = (int)((unsigned)s1 + (unsigned)((*mp * u1) < ~(((unsigned)(w0 >> 29) * a0[i0 & 3u]) * *mp)));
            i0 = (m0 ? 4u : u1) & 15u;
            break; (void)((0xffffffffu / ((unsigned)d0 | 1u)));
            { unsigned t14; double z14; if (((unsigned)(0x1059f000u && (u0 + u0))) & 1u) { t14 = (unsigned)d0; z14 = (double)((0xffffffffu) & 255u); } if (((unsigned)(0x1059f000u && (u0 + u0))) & 1u) { u2 += t14; d0 = d0 * 0.5 + z14; }
                if (0x7fffffffu) {
                    if (((unsigned)((short)(unsigned)e0 > (signed char)0x97c0a5cau) * (unsigned)h1)) goto L3;
                } else {
                    u2 = (((unsigned)s0 ? (unsigned)s1 : (unsigned)(p1 || u2)) | (unsigned)c1);
                    r0.x = (unsigned)(garr[i1 & 7u] && (u3 << ((unsigned)w0 & 31u)));
                }
                w0 = w0 * 6364136223846793005ull + g1;
                if (((0x830f482du >> ((unsigned)h0 & 31u)) | p1)) {
                    v0 = ((unsigned)((short)g1 > (signed char)p1) >> (6u & 31u));
                } else {
                    u2 = u2 * 0x9e3779b1u + (unsigned)((int)garr[u2 & 7u] < (int)((unsigned)(signed char)(u2 >> ((unsigned)h0 & 31u)) / (0x465cb874u | 1u)));
                    break; (void)((unsigned)((int)((unsigned)w0 ^ garr[u2 & 7u]) >= (int)(unsigned)(x0 >> 70)));
                    g0 = ((unsigned)x0 | a0[i0 & 3u]);
                }
            }
            b0 = (unsigned)((p1 >> (*mp & 31u)) == (unsigned)(unsigned char)(unsigned)(0x10000u == (unsigned)w0)) != 0u;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(g1 || 0u)) break;
                if (r0.x) break;
                if (*mp) break;
                if (((unsigned)x0 << ((p0 % ((unsigned)w0 | 1u)) & 31u))) break;
                i0 = ((i1 & (u3 | 0x294f0e97u)) * garr[i1 & 7u]) & 15u;
            }
        } while (i0++ < 6u && (((unsigned)f0 + r0.x) + m0));
        i2 = ((fuel % (g0 | 1u)) / (9u | 1u)) & 15u;
        f0 = f0 * 0.5f + (float)((unsigned)(short)(unsigned)((unsigned)((int)garr[i1 & 7u] < (int)(unsigned)(u2 == (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)c0))) < (unsigned)(x0 >> 70)) & 255u);
    } else {
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((2u / ((unsigned)((unsigned)d0 < p0) | 1u)) & 7u) {
                *q0 = (unsigned)((u2 & (unsigned)e0) || ((unsigned)(signed char)(9u * u2) & 0x10000u));
                if (0x80000000u) goto L1;
                while (i1++ < 6u && ((m0 - (unsigned)(x0 >> 70)) - 0x7fffffffu)) { if (--fuel == 0u) goto done;
                    u3 = p0;
                }
            }
            while (i1++ < 7u && 8u) { if (--fuel == 0u) goto done;
                if ((unsigned)!(unsigned)((short)a0[i0 & 3u] > (signed char)5u)) break;
                garr[(8u & 3u) & 7u] = ((unsigned)x0 << (1u & 31u));
                *q0 += (unsigned)((unsigned)!(unsigned)((int)0x7fffffffu >= (int)r0.x) == u1);
                w0 ^= (unsigned long long)3u << ((unsigned)(unsigned char)(*q0 >> (i1 & 31u)) & 63u);
                c0 = (unsigned char)p1;
            }
        }
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        while ((0x657db2e9u % (g0 | 1u))) { if (--fuel == 0u) goto done;
            while (i2++ < 4u && ((0xf706e36au << (6u & 31u)) - 0x8839a8d2u)) { if (--fuel == 0u) goto done;
                u0 ^= (unsigned)b0;
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1((g0 % (*mp | 1u)), (unsigned)((int)0xffffffffu < (int)0x10000u), (unsigned)!((unsigned)(x0 >> 70) << ((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)d0) & 31u))); }
                    u1 = ((0xe794ad19u + (unsigned)h0) % (-(p0 ^ (unsigned)(i1 || 0xc1f52054u)) | 1u));
                    r0.y ^= ~(~(unsigned)(2u == (unsigned)((int)garr[i1 & 7u] >= (int)0xac711f7cu)) / ((0x10000u % (garr[i1 & 7u] | 1u)) | 1u));
                    c0 = (unsigned char)(0xe52b63d7u ? (p1 / ((unsigned)w0 | 1u)) : (unsigned)l0);
                    if (-((unsigned)c0 / (u0 | 1u))) break;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)d0 && 0x7fffffffu), (unsigned)((0x7450eff5u | 0x65a554ceu) || v0), *q0); }
                }
            }
            x0 = x0 * 0x100000001b3ull + (p0 - (unsigned)(signed char)((r0.y | 7u) + (unsigned)((int)3u < (int)fuel)));
            switch ((0x80000000u >> ((p0 * 0xffffffffu) & 31u)) & 7u) {
                if (budget != 0u) { budget -= 1u; u3 = fn1(0xffffffffu, ~(((unsigned)b0 >> (0xaec24732u & 31u)) ^ p0), (unsigned)d0); }
                case 6u: ;
                x0 = x0 * 0x100000001b3ull + ((unsigned)!(u1 ? (unsigned)s1 : 0x3ac69766u) ^ (unsigned)w0);
            }
            do { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)(~((unsigned)(x0 >> 70) + (unsigned)c1) == (-(0xae1bd073u + r0.y) % (0u | 1u))) & 1023u);
                do { if (--fuel == 0u) goto done;
                    h0 = (short)garr[u2 & 7u];
                    u2 = u2 * 0x9e3779b1u + ((unsigned)x0 - ((unsigned)(unsigned char)(a0[i0 & 3u] % (u3 | 1u)) + 0x80000000u));
                    for (;;) { if (--fuel == 0u) goto done;
                        *q0 += (r0.y ^ (unsigned)((unsigned)e0 && (unsigned)b0));
                        if (budget != 0u) { budget -= 1u; u2 = fn1(0xffffffffu, 0x80000000u, (unsigned)((int)4u < (int)(unsigned)c0)); }
                    }
                } while (i0++ < 2u && (unsigned)l0);
                u0 = u0 * 0x9e3779b1u + (unsigned)((int)(u3 % (0xffffffffu | 1u)) < (int)i1);
                if ((unsigned)(9u && 0x80000000u)) continue;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((short)(unsigned)(fuel == u1) > (signed char)g0), (unsigned)!(6u >> (garr[u2 & 7u] & 31u)), (unsigned)(unsigned char)(i2 * (unsigned)((int)(unsigned)s1 >= (int)(unsigned)h1))); }
            } while (i2++ < 2u && i1);
            f0 = f0 * 0.5f + (float)((unsigned)((int)(g1 / ((unsigned)s0 | 1u)) >= (int)(((unsigned)c1 / (u2 | 1u)) - 0x30f04221u)) & 255u);
            while (i2++ < 2u && (unsigned)((unsigned)c1 || (unsigned)((int)0x7fffffffu < (int)v0))) { if (--fuel == 0u) goto done;
                if (((unsigned)s0 >> ((unsigned)(g0 || (unsigned)b0) & 31u))) break;
                h1 = (unsigned short)(h1 + -((unsigned)c0 | (7u >> (0x7fffffffu & 31u))));
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn1(-(unsigned)((unsigned)e0 < (m0 - p1)), (unsigned)((unsigned)((int)0x7564b6d2u < (int)0x480b8244u) || 4u), ((u0 / (a0[u1 & 3u] | 1u)) - 7u)); }
        if (u3 == 7u) return (unsigned)((i1 & (g0 % ((p0 >> (p2 & 31u)) | 1u))) && 0x40f5cb88u);
        c0 = (unsigned char)(0x10000u | 0x7fffffffu);
    }
    do { if (--fuel == 0u) goto done;
        b0 = (g1 + (unsigned)(x0 >> 70)) != 0u;
        for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((unsigned)c0 == garr[i1 & 7u]));
            break; (void)(1u);
            e0 = e0 * 0.5L + (long double)((unsigned)(0x80000000u && ((unsigned)x0 ^ 0x10000u)) & 1023u);
            e0 = e0 * 0.5L + (long double)(((unsigned)(short)(unsigned)(garr[i1 & 7u] || u3) + (p1 ? (unsigned)l0 : (unsigned)s1)) & 1023u);
        }
        if (((unsigned)b0 + i0)) break;
        for (;;) { if (--fuel == 0u) goto done;
            g1 += ((2u ^ i1) % (6u | 1u));
            if ((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)((int)2u >= (int)0xb2535e98u))) break;
            if ((unsigned)(p0 || (unsigned)c1)) break;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1((0x80000000u ^ (unsigned)s1), *q0, (unsigned)((int)3u >= (int)g0)); }
        if ((p1 & garr[u2 & 7u])) {
            if (0x5755e18au) break;
            c0 = (unsigned char)(unsigned)((short)g0 > (signed char)(unsigned)(garr[u2 & 7u] && ((unsigned)(p2 && (unsigned)(x0 >> 70)) / ((unsigned)f0 | 1u))));
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)(i0 * 9u);
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (u1) break;
                    s1 = (int)((unsigned)s1 + (unsigned)(signed char)((unsigned)((short)v0 > (signed char)u2) ^ i1));
                    *q0 += (((unsigned)c1 - (unsigned)(w0 >> 29)) + (g0 + 0x543668d2u));
                }
            }
            do { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)(~(unsigned)(p2 == (unsigned)e0) & 1023u);
                v0 = p1;
            } while (i1++ < 2u && (unsigned)w0);
        } else {
            { unsigned t15; double z15; if (((0x10000u & (unsigned)(r0.y && i0))) & 1u) { t15 = a0[u1 & 3u]; z15 = (double)(((unsigned)((int)i1 < (int)(8u / ((unsigned)c1 | 1u)))) & 255u); } if (((0x10000u & (unsigned)(r0.y && i0))) & 1u) { u3 += t15; d0 = d0 * 0.5 + z15; }
                w0 = w0 * 6364136223846793005ull + (unsigned)!(unsigned)(v0 == a0[u1 & 3u]);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(p2 == (garr[i1 & 7u] % (v0 | 1u))), (unsigned)((int)0x6e9061c4u < (int)(unsigned)(u3 && 0x34b23becu)), (unsigned)(signed char)(unsigned)((short)(unsigned)x0 > (signed char)(g0 % ((unsigned)(x0 >> 70) | 1u)))); }
                if ((unsigned)s0) break;
            }
            continue; (void)((unsigned)(short)(0xd0e8366fu + 7u));
            break; (void)((0x10000u - u3));
            r0.x = ((g0 | -(r0.y << (0u & 31u))) + 0xac981afdu);
        }
    } while (i0++ < 4u && *q0);
    goto L2;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + ((unsigned)d0 >> (garr[i1 & 7u] & 31u)));
        { unsigned t16; double z16; if ((v0) & 1u) { t16 = (unsigned)((int)(unsigned)s0 >= (int)3u); z16 = (double)((v0) & 255u); } if ((v0) & 1u) { u0 += t16; d0 = d0 * 0.5 + z16; }
            *q0 = (unsigned)!((unsigned)(unsigned char)(unsigned)((((unsigned)h1 >> (0x10000u & 31u)) | (unsigned)h1) && garr[u2 & 7u]) >> (*q0 & 31u));
            b0 = ((unsigned)(w0 >> 29) / ((unsigned)f0 | 1u)) != 0u;
        }
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            u2 = (unsigned)((short)(unsigned)(0xffffffffu < i2) > (signed char)0x5381fb01u);
            m0 ^= garr[i1 & 7u];
        }
        *q0 = (unsigned)(unsigned char)((unsigned)(g1 == a0[i0 & 3u]) / ((unsigned)(w0 >> 29) | 1u));
        while (i1++ < 7u && (unsigned)(unsigned char)(u2 / (m0 | 1u))) { if (--fuel == 0u) goto done;
            i2 = (i1 ? (unsigned)x0 : (unsigned)s1) & 15u;
            if (((0xfb8363f3u >> ((unsigned)w0 & 31u)) >> (i1 & 31u))) {
                if ((unsigned)((u3 >> (i2 & 31u)) || *q0)) break;
                *mp = ((0x7fffffffu + 0xffffffffu) + 0xbd46461eu);
            } else {
                if ((unsigned)(0x56edcf66u < (0x8e94ef5eu + 0x10000u))) {
                    u1 ^= (0x80000000u + 0x10000u);
                    s1 = (int)((unsigned)s1 + (u1 ^ (unsigned)c0));
                }
                break; (void)((unsigned)h0);
            }
            if (((i1 | u0) / ((unsigned)(x0 >> 70) | 1u))) {
                *q0 = (unsigned)((short)i1 > (signed char)i1);
                do { if (--fuel == 0u) goto done;
                    u2 += 0xcedef9beu;
                    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if ((p1 >> ((unsigned)l0 & 31u))) goto L2;
                        if ((unsigned)(u3 < i1)) break;
                    }
                    c1 = (signed char)(*q0 | ((unsigned)w0 / ((unsigned)((int)(unsigned)e0 < (int)0x80000000u) | 1u)));
                    { unsigned t17; double z17; if (((unsigned)(signed char)((a0[i0 & 3u] + (unsigned)w0) + (unsigned)w0)) & 1u) { t17 = (unsigned)(fuel < (0x10000u * (unsigned)(w0 >> 29))); z17 = (double)((((u2 >> (g1 & 31u)) % ((unsigned)x0 | 1u))) & 255u); } if (((unsigned)(signed char)((a0[i0 & 3u] + (unsigned)w0) + (unsigned)w0)) & 1u) { u3 += t17; d0 = d0 * 0.5 + z17; }
                        switch (p0 & 7u) {
                            case 1u: ;
                            goto done;
                            d0 = d0 * 0.5 + (double)((unsigned)(short)(u2 + u0) & 1023u);
                            c1 = (signed char)(unsigned)((int)(unsigned)(signed char)(unsigned)(0xffffffffu == (unsigned)h1) < (int)v0);
                            u2 = (unsigned)((int)(4u << (u2 & 31u)) < (int)(unsigned)(u0 == (unsigned)x0));
                        }
                        u1 = u1 * 0x9e3779b1u + ((unsigned)((unsigned)((int)0x80000000u >= (int)0x80000000u) < (unsigned)c1) >> (-(unsigned)(g1 == p0) & 31u));
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)((unsigned)x0 * (unsigned)h1) >= (int)7u), (u0 & v0), 0x80000000u); }
                        garr[(unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)(w0 >> 29)) & 7u] = (unsigned)((int)0xaeb1983cu >= (int)p1);
                    }
                } while (i2++ < 2u && (unsigned)l0);
                if (budget != 0u) { budget -= 1u; u1 = fn1(((unsigned)h0 / (u0 | 1u)), (unsigned)(0x20864c50u == garr[i1 & 7u]), (unsigned)((unsigned)((int)0xf04288a9u >= (int)(unsigned)h0) < r0.x)); }
                switch ((unsigned)((unsigned)((int)i2 < (int)0x1d83cec5u) == 6u) & 7u) {
                    case 7u: ;
                }
                g1 += (i2 | (unsigned)c0);
                s1 = (int)((unsigned)s1 + u1);
            } else {
                g1 += (unsigned)((int)i0 < (int)~((unsigned)f0 % (0x5718848fu | 1u)));
                u3 = (5u / ((unsigned)((short)r0.y > (signed char)(((unsigned)w0 + 2u) + 0xffffffffu)) | 1u));
            }
        }
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            switch ((0x7fffffffu ^ ((unsigned)(w0 >> 29) % (u1 | 1u))) & 7u) {
                case 2u: ;
                { unsigned t18; double z18; if ((((unsigned)c0 + (unsigned)s1)) & 1u) { t18 = (unsigned)(0xffffffffu == r0.x); z18 = (double)(((unsigned)(unsigned char)((unsigned)l0 * garr[u2 & 7u])) & 255u); } if ((((unsigned)c0 + (unsigned)s1)) & 1u) { u1 += t18; d0 = d0 * 0.5 + z18; }
                    while (i2++ < 2u && (unsigned)(0xa22e1cccu == (unsigned)l0)) { if (--fuel == 0u) goto done;
                        if ((unsigned)f0) goto L0;
                    }
                }
            }
            if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(unsigned char)(unsigned)((0x36c9f24u / (i0 | 1u)) && u3), (unsigned)((short)i1 > (signed char)m0), (unsigned)(a0[i0 & 3u] < (unsigned)l0)); }
            s1 = (int)((unsigned)s1 + (8u - 7u));
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (u0) break;
                m0 ^= (~(p2 / (0xffffffffu | 1u)) ^ (unsigned)((unsigned)(w0 >> 29) < (unsigned)b0));
                if (budget != 0u) { budget -= 1u; u0 = fn0(a0[u1 & 3u], a0[i0 & 3u], (unsigned)f0); }
                w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)(0xa8023594u || (unsigned)x0) < (int)(unsigned)h1);
                if (fuel < 8u) return ((unsigned)e0 >> (r0.x & 31u));
                goto L0;
            }
            { unsigned t19; double z19; if (((unsigned)h0) & 1u) { t19 = (unsigned)(i1 && 0xffffffffu); z19 = (double)(((unsigned)(r0.x || 8u)) & 255u); } if (((unsigned)h0) & 1u) { u2 += t19; d0 = d0 * 0.5 + z19; }
                if ((a0[u1 & 3u] * (unsigned)f0)) continue;
            }
        }
    }
    if ((a0[u1 & 3u] << (*q0 & 31u))) {
        if ((unsigned)c0) goto done;
        switch ((unsigned)((int)(i2 ^ garr[i1 & 7u]) < (int)0x5aa84805u) & 7u) {
            if (garr[i1 & 7u]) goto L3;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(g0 < 0x7fffffffu), (unsigned)((short)(unsigned)(0xbe52c74u < r0.y) > (signed char)(unsigned)w0), (unsigned)((int)4u >= (int)(unsigned)w0)); }
            switch ((unsigned)(unsigned char)(i2 & (unsigned)((int)g1 < (int)0xffffffffu)) & 7u) {
                case 5u: ;
                if ((unsigned)d0) goto L0;
                m0 ^= 0xbfd25a15u;
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)(0x10000u == 0x80000000u)) break;
                    for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)d0 / (9u | 1u)) == ((0x2cde8a59u + p2) / ((unsigned)d0 | 1u))) & 255u);
                        case 0u: ;
                        u2 = u2 * 0x9e3779b1u + p2;
                        g0 = ((unsigned)h1 % (0xa99ae56cu | 1u));
                        g1 += (unsigned)((unsigned)c1 == (unsigned)h0);
                        while (i2++ < 7u && 0x10000u) { if (--fuel == 0u) goto done;
                            b0 = (unsigned)e0 != 0u;
                            case 6u: ;
                        }
                    }
                } while (i0++ < 6u && (unsigned)(short)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)garr[i1 & 7u]));
                if ((0xf80bcf1u & (1u % (0x3ff9b3d3u | 1u)))) goto L3;
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u2 = fn1(-((unsigned)((int)0x9fa27259u < (int)0x7fffffffu) ^ m0), 0xffffffffu, (unsigned)((unsigned)((int)6u < (int)(unsigned)(x0 >> 70)) || i1)); }
                    w0 = w0 * 6364136223846793005ull + u3;
                }
            }
            { unsigned t20; double z20; if (((unsigned)((unsigned)(x0 >> 70) || ~(0x5798dee0u / (0x80000000u | 1u)))) & 1u) { t20 = ((unsigned)(w0 >> 29) - 0xffffffffu); z20 = (double)(((0x80000000u ? 0x7fffffffu : u3)) & 255u); } if (((unsigned)((unsigned)(x0 >> 70) || ~(0x5798dee0u / (0x80000000u | 1u)))) & 1u) { u3 += t20; d0 = d0 * 0.5 + z20; }
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (fuel < 8u) return (unsigned)((unsigned)x0 < u0);
                    for (;;) { if (--fuel == 0u) goto done;
                        goto L2;
                        q0 = &garr[i1 & 7u];
                        if ((unsigned)(0x81f952b2u && (unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)h0))) continue;
                        r0.x = i2;
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)e0, (i0 + 0x80000000u), (unsigned)((int)p1 < (int)(garr[i1 & 7u] & v0))); }
                    }
                    if ((unsigned)(u1 < p1)) {
                        if (budget != 0u) { budget -= 1u; u1 = fn0(4u, (unsigned)l0, 8u); }
                    } else {
                        v0 = garr[i1 & 7u];
                        do { if (--fuel == 0u) goto done;
                            i0 = ((unsigned)d0 << ((unsigned)((short)3u > (signed char)p2) & 31u)) & 15u;
                            g0 = ((unsigned)f0 ^ u0);
                            case 3u: ;
                            g1 += (r0.y / ((unsigned)e0 | 1u));
                        } while (i1++ < 2u && ~(unsigned)((unsigned)s1 && r0.y));
                    }
                    if (((r0.x << (0x80000000u & 31u)) % ((unsigned)(w0 >> 29) | 1u))) break;
                    f0 = f0 * 0.5f + (float)((unsigned)(signed char)(*q0 ? (unsigned)x0 : (garr[u2 & 7u] * r0.x)) & 255u);
                }
                case 1u: ;
                *q0 += ((unsigned)!(unsigned)(0x10000u && i1) & (unsigned)(2u == (unsigned)l0));
                case 7u: ;
                u3 += 5u;
                if ((0x6585ebcau / (a0[u1 & 3u] | 1u))) goto L4;
            }
            if (2u) {
                for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    *mp = ((fuel ^ 9u) ^ (unsigned)h0);
                }
                do { if (--fuel == 0u) goto done;
                    garr[(a0[u1 & 3u] >> ((unsigned)s1 & 31u)) & 7u] = ((unsigned)((int)p2 >= (int)(i2 + *mp)) / ((unsigned)((unsigned)e0 || 8u) | 1u));
                    w0 ^= (unsigned long long)(unsigned)(short)(garr[i1 & 7u] >> (u1 & 31u)) << (((a0[i0 & 3u] ? u3 : a0[u1 & 3u]) >> (0x7fffffffu & 31u)) & 63u);
                    c1 = (signed char)((((unsigned)s0 - i0) ^ 0x7fffffffu) >> ((unsigned)((short)0x7fffffffu > (signed char)0xc53e8802u) & 31u));
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)h0, 0x2308db62u, ((unsigned)l0 ? i2 : v0)); }
                    if (0xe4abc5a6u) goto L3;
                    g0 = (unsigned)((unsigned)c1 || (unsigned)((unsigned)((int)(unsigned)x0 >= (int)i1) && (unsigned)s1));
                } while (i0++ < 5u && ~((unsigned)d0 & r0.x));
                if (0x80000000u) goto L1;
                l0 = (long)((unsigned long)l0 + g1);
                s1 = (int)((unsigned)s1 + ((unsigned)((int)0x10000u < (int)0x4a5ba35eu) + (unsigned)((unsigned)(x0 >> 70) == (unsigned)d0)));
                if (((0u % (0u | 1u)) << (0x80000000u & 31u))) break;
            } else {
                r0.x = (unsigned)!((unsigned)h0 >> (*mp & 31u));
            }
        }
        if ((unsigned)(g1 < r0.y)) goto L4;
    }
    if ((unsigned)(u1 && -((unsigned)e0 & 7u))) goto L0;
    v0 = (unsigned)((unsigned)h1 == (unsigned)((m0 % ((unsigned)w0 | 1u)) == p0));
    u3 ^= (unsigned)(short)(unsigned)((fuel ^ 0x10000u) && (unsigned)((unsigned)(w0 >> 29) == (unsigned)s0));
    for (;;) { if (--fuel == 0u) goto done;
        q0 = &garr[7u & 7u];
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)0u >= (int)0x80000000u), (unsigned)w0, (g1 >> (u3 & 31u))); }
    }
    goto L1;
    if (((unsigned)(w0 >> 29) / ((unsigned)((short)g1 > (signed char)1u) | 1u))) goto L4;
    do { if (--fuel == 0u) goto done;
        continue; (void)(r0.y);
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(i1);
        }
        if ((unsigned)(0xffffffffu == (unsigned)(x0 >> 70))) {
            g0 = ((unsigned)((int)(unsigned)l0 >= (int)a0[i0 & 3u]) & (unsigned)((short)a0[u1 & 3u] > (signed char)1u));
            if ((unsigned)(7u && 0xbdae7918u)) {
                h0 = (short)((unsigned)d0 | (~(garr[i1 & 7u] & u3) * (unsigned)((int)1u < (int)(unsigned)c0)));
                if ((unsigned)((int)0x80000000u < (int)4u)) break;
            }
        }
        *mp = (unsigned)(1u && (1u << (0x8daf1986u & 31u)));
    } while (i0++ < 2u && (unsigned)(short)(unsigned)((unsigned)b0 == 3u));
    if (((unsigned)x0 >> ((unsigned)((int)(unsigned)f0 >= (int)0xf4ea212fu) & 31u))) goto L1;
    if ((0x80000000u % (g0 | 1u))) {
        if ((unsigned)((short)0x7fffffffu > (signed char)(unsigned)h0)) goto L3;
        u2 += (unsigned)!((unsigned)((int)*mp >= (int)r0.x) << (6u & 31u));
        s0 = (int)(unsigned)((short)3u > (signed char)((0x80000000u * u1) - (unsigned)((int)(unsigned)(w0 >> 29) < (int)u2)));
        if (budget != 0u) { budget -= 1u; u3 = fn0((0x80000000u % (r0.y | 1u)), (unsigned)((unsigned)l0 < (unsigned)b0), (0x10000u & (unsigned)h0)); }
    } else {
        { unsigned t21; double z21; if ((((unsigned)(u2 < (unsigned)w0) + (unsigned)s1)) & 1u) { t21 = (((unsigned)c0 - m0) * i0); z21 = (double)((v0) & 255u); } if ((((unsigned)(u2 < (unsigned)w0) + (unsigned)s1)) & 1u) { u2 += t21; d0 = d0 * 0.5 + z21; }
            goto done;
            m0 ^= (0x80000000u & (*mp - a0[i0 & 3u]));
            if ((0xf6028a5u >> ((unsigned)h1 & 31u))) {
                if (0x10000u) goto L3;
                r0.x = (unsigned)((short)u2 > (signed char)(unsigned)(r0.x == v0));
                s1 = (int)((unsigned)s1 + (fuel * ((unsigned)(m0 && 0xe58d6946u) << ((unsigned)h1 & 31u))));
                if (-(0xf9d8f945u << (r0.x & 31u))) goto L0;
                while (i0++ < 5u && (unsigned)((short)(unsigned)h0 > (signed char)*q0)) { if (--fuel == 0u) goto done;
                    if ((unsigned)(unsigned char)((unsigned)e0 ^ (0x3a9364au << ((unsigned)(w0 >> 29) & 31u)))) break;
                }
            } else {
                do { if (--fuel == 0u) goto done;
                    if (4u) continue;
                    h1 = (unsigned short)(h1 + 0x50339983u);
                    for (;;) { if (--fuel == 0u) goto done;
                        f0 = f0 * 0.5f + (float)(-(a0[i0 & 3u] - -(0x2df6bf73u % (4u | 1u))) & 255u);
                        c0 = (unsigned char)((unsigned)s0 | (unsigned)((0x82d1ac6cu % ((v0 << (8u & 31u)) | 1u)) < (unsigned)h1));
                        h1 = (unsigned short)(h1 + i0);
                        q0 = &garr[(unsigned)((short)((unsigned)d0 * (unsigned)(u0 && (unsigned)l0)) > (signed char)u3) & 7u];
                    }
                    d0 = d0 * 0.5 + (double)((unsigned)(u2 < (unsigned)((m0 ^ i0) && 0xc2791ea8u)) & 1023u);
                } while (i0++ < 2u && (unsigned)((int)(unsigned)(v0 < g1) >= (int)(unsigned)w0));
            }
            if ((0x80000000u / (((unsigned)c0 % (v0 | 1u)) | 1u))) goto L1;
            goto L1;
            c0 = (unsigned char)(7u | p0);
        }
        switch (-(unsigned)((int)0x90164ec0u < (int)8u) & 7u) {
            *q0 += (unsigned)c0;
            *q0 = (unsigned)((int)((unsigned)((int)(unsigned)e0 >= (int)i0) - (0xffffffffu + 0x80000000u)) < (int)p2);
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)(a0[u1 & 3u] << (garr[i1 & 7u] & 31u)) < (int)*mp), (unsigned)(3u < (unsigned)(0x69b07463u < 0x128e904u)), ((unsigned)s1 % ((unsigned)((int)6u < (int)fuel) | 1u))); }
            for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                continue; (void)(3u);
                case 2u: ;
                *mp = ((unsigned)(unsigned char)(a0[i0 & 3u] >> ((unsigned)((short)*mp > (signed char)0xffffffffu) & 31u)) ^ (0xffffffffu - 0x50dfcc1fu));
            }
        }
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (garr[i1 & 7u]) {
                break; (void)((fuel & (unsigned)c1));
                s0 = (int)(a0[i0 & 3u] | (unsigned)((int)(unsigned)f0 < (int)fuel));
                b0 = (unsigned)((int)(unsigned)h1 >= (int)(garr[u2 & 7u] >> ((unsigned)h1 & 31u))) != 0u;
            }
            if ((9u >> (((unsigned)b0 ^ (unsigned)c0) & 31u))) {
                *q0 += ((1u | (unsigned)(signed char)(unsigned)((int)m0 < (int)(*mp << (p2 & 31u)))) * 0xffffffffu);
                if (p1) {
                    s0 = (int)(unsigned)((unsigned)(a0[i0 & 3u] < 2u) == ((unsigned)d0 >> (0x1711f1adu & 31u)));
                }
            }
            if (((p2 / (i2 | 1u)) >> (g0 & 31u))) break;
            l0 = (long)((unsigned long)l0 + ((unsigned)((int)(unsigned)x0 < (int)(unsigned)c0) + p0));
            if (u3 == 7u) return p2;
            if ((unsigned)(u0 < ((unsigned)e0 << (v0 & 31u)))) break;
        }
        u0 ^= 8u;
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)h0 - (0x2826d637u | i2)), (unsigned)((short)v0 > (signed char)(u2 / (0x7fffffffu | 1u))), ((unsigned)((unsigned)w0 && u1) << (8u & 31u))); }
    *q0 = ((unsigned)b0 * 7u);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    u3 ^= (u3 * (((unsigned)w0 | p2) % ((unsigned)l0 | 1u)));
    if (budget != 0u) { budget -= 1u; u3 = fn0((0xc82f12cu & u3), (i2 + i2), (0x7fffffffu | garr[i1 & 7u])); }
    if ((unsigned)((unsigned)e0 || (unsigned)(i0 == i2))) goto L4;
    m0 ^= (unsigned)((int)(i2 % ((unsigned)b0 | 1u)) >= (int)(unsigned)((int)(unsigned)d0 >= (int)(8u << (u3 & 31u))));
    do { if (--fuel == 0u) goto done;
        if ((unsigned)(2u < p0)) {
            b0 = (unsigned)((int)0u < (int)a0[i0 & 3u]) != 0u;
            L0: if (--fuel == 0u) goto done;
            c1 = (signed char)(unsigned)(a0[i0 & 3u] || 0x6c467d61u);
            L1: if (--fuel == 0u) goto done;
            if (((unsigned)(x0 >> 70) % (garr[u2 & 7u] | 1u))) break;
            if ((fuel % (u1 | 1u))) {
                if ((unsigned)((short)((unsigned)s1 & a0[u1 & 3u]) > (signed char)g0)) {
                    a0[i0 & 3u] = (p2 % ((unsigned)(p2 == (r0.x / ((unsigned)h1 | 1u))) | 1u));
                    if (fuel < 8u) return (i1 >> (u3 & 31u));
                    a0[i2 & 3u] = u0;
                    u2 = u2 * 0x9e3779b1u + (unsigned)((unsigned)b0 < (unsigned)(unsigned char)((unsigned)!(*mp >> (0x18a95c84u & 31u)) + u1));
                }
                x0 = x0 * 0x100000001b3ull + (i0 << (0xdd1def15u & 31u));
            }
        }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            goto L1;
            while (i2++ < 3u && (unsigned)((unsigned)b0 < u2)) { if (--fuel == 0u) goto done;
                if ((*q0 | 0xffffffffu)) break;
                if ((4u % ((unsigned)(short)(i1 << (2u & 31u)) | 1u))) break;
                l0 = (long)((unsigned long)l0 + 0x10000u);
            }
            L2: if (--fuel == 0u) goto done;
            e0 = e0 * 0.5L + (long double)((0x7fffffffu % ((unsigned)(w0 >> 29) | 1u)) & 1023u);
        }
        w0 ^= (unsigned long long)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)(x0 >> 70)) << (p0 & 63u);
        switch ((unsigned)((int)(0xffffffffu / (i2 | 1u)) < (int)v0) & 7u) {
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)(signed char)(unsigned)(0u || g1), ((unsigned)h1 - (unsigned)((int)garr[i1 & 7u] < (int)g1)), ((unsigned)(x0 >> 70) >> ((unsigned)((int)(unsigned)h1 < (int)p2) & 31u))); }
            do { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)!((g0 * (unsigned)c1) - (unsigned)((unsigned)e0 == m0)) & 255u);
            } while (i1++ < 4u && garr[i1 & 7u]);
            u2 ^= (unsigned)((unsigned)(8u && 0x80000000u) == a0[u1 & 3u]);
            c0 = (unsigned char)p1;
            u2 = u2 * 0x9e3779b1u + (-(0x45810e9bu ? g0 : r0.x) / (((unsigned)c0 / (p0 | 1u)) | 1u));
        }
        h0 = (short)(unsigned)(unsigned char)((m0 | 0x8855217du) << (((unsigned)h1 ? (unsigned)l0 : garr[i1 & 7u]) & 31u));
        if ((unsigned)((unsigned)(w0 >> 29) == (unsigned)((unsigned)h0 && p0))) continue;
    } while (i0++ < 6u && (unsigned)((unsigned)((int)0x80000000u >= (int)garr[u2 & 7u]) == p0));
    f0 = f0 * 0.5f + (float)(-(unsigned)((int)4u < (int)(unsigned)(short)(p0 - (0xc0fb992fu ? 7u : garr[u2 & 7u]))) & 255u);
    c0 = (unsigned char)i1;
    if (u3 == 7u) return ((unsigned)f0 % ((unsigned)(u3 || ((unsigned)b0 & (fuel / (p2 | 1u)))) | 1u));
    goto done;
    u3 = (garr[i1 & 7u] | (((unsigned)c0 * 0x7f2082beu) / ((unsigned)s1 | 1u)));
    m0 ^= (u1 | (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)((short)0x7fffffffu > (signed char)(unsigned)((int)0x5d107da7u < (int)0xcbdacea7u))));
    h0 = (short)((unsigned)(w0 >> 29) >> (p0 & 31u));
    if (budget != 0u) { budget -= 1u; u0 = fn2((garr[u2 & 7u] ^ 0x80000000u), 8u, (unsigned)((unsigned)b0 || p0)); }
    garr[(unsigned)((int)r0.y < (int)(unsigned)c1) & 7u] = ((unsigned)((unsigned)c1 || 0xffffffffu) | (*mp % ((unsigned)(w0 >> 29) | 1u)));
    do { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (r0.y ? (unsigned)l0 : 0u));
        if (budget != 0u) { budget -= 1u; u1 = fn2(0x80000000u, 0x7fffffffu, ((unsigned)h0 - (unsigned)(short)(unsigned)((unsigned)f0 || garr[i1 & 7u]))); }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(*mp && (unsigned)l0)) goto L2;
        } while (i1++ < 2u && (unsigned)(p1 < (unsigned)e0));
        if ((unsigned)((unsigned)(x0 >> 70) && (unsigned)(short)(unsigned)(i2 == u3))) break;
        f0 = f0 * 0.5f + (float)(((unsigned)e0 >> ((unsigned)((int)(g0 ? (unsigned)c1 : 0x10000u) < (int)(unsigned)(w0 >> 29)) & 31u)) & 255u);
        continue; (void)(((unsigned)((short)0xb9905716u > (signed char)u0) & u0));
    } while (i0++ < 4u && (i1 % (0x553ae923u | 1u)));
    { unsigned t0; double z0; if (((0x5a9b83d5u - m0)) & 1u) { t0 = (unsigned)(unsigned char)(unsigned)(0x2bc32838u < i0); z0 = (double)((m0) & 255u); } if (((0x5a9b83d5u - m0)) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        { unsigned t1; double z1; if ((7u) & 1u) { t1 = (r0.y / (p2 | 1u)); z1 = (double)(((unsigned)((unsigned)d0 < 9u)) & 255u); } if ((7u) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            if ((0x94f76e7eu + (r0.x >> (g1 & 31u)))) goto L4;
            r0.x = (unsigned)((int)(unsigned)b0 >= (int)((unsigned)c0 ^ (unsigned)((int)r0.x < (int)(5u & 0x965b07c0u))));
            *q0 = ((unsigned)e0 & (unsigned)w0);
            L3: if (--fuel == 0u) goto done;
            goto L1;
            L4: if (--fuel == 0u) goto done;
        }
    }
    q0 = &garr[(unsigned)(signed char)(unsigned)((int)((unsigned)x0 << (u3 & 31u)) < (int)(9u + ((unsigned)c0 >> ((unsigned)h0 & 31u)))) & 7u];
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        g1 += (unsigned)((int)((unsigned)((int)*q0 >= (int)(unsigned)(9u || g0)) - i2) < (int)i2);
        switch (garr[i1 & 7u] & 7u) {
            case 6u: ;
            v0 = ~((unsigned)((unsigned)h0 == (unsigned)s1) - (unsigned)(g0 || (unsigned)h0));
        }
        a0[(unsigned)(unsigned char)((unsigned)d0 + (unsigned)b0) & 3u] = ((unsigned)((0u << ((unsigned)f0 & 31u)) && 0x10000u) | (3u | u2));
        garr[(unsigned)(9u < (unsigned)x0) & 7u] = 0x765f710fu;
    }
    if ((0xffffffffu % (g0 | 1u))) goto L1;
    goto L3;
    u1 += (0x7fffffffu / (a0[i0 & 3u] | 1u));
    r0.y ^= ((unsigned)((unsigned)(signed char)((unsigned)(x0 >> 70) | (unsigned)h0) || (unsigned)c1) >> (-((unsigned)h0 % ((unsigned)w0 | 1u)) & 31u));
    c1 = (signed char)r0.x;
    if ((0xf9b3bb2bu & garr[i1 & 7u])) {
        goto L4;
        goto L1;
        do { if (--fuel == 0u) goto done;
            u1 = (unsigned)((unsigned)(x0 >> 70) == (unsigned)((short)u3 > (signed char)a0[i0 & 3u]));
            x0 = x0 * 0x100000001b3ull + (0x7fffffffu | (unsigned)b0);
            if ((unsigned)((short)(unsigned)w0 > (signed char)(unsigned)((short)r0.y > (signed char)garr[i1 & 7u]))) break;
            q0 = &garr[~(unsigned)((unsigned)(g0 || 0xffffffffu) && ~(unsigned)(0xffffffffu < (unsigned)(0x10000u && 0x7fffffffu))) & 7u];
            { unsigned t2; double z2; if (((unsigned)((unsigned)(v0 == garr[i1 & 7u]) < i0)) & 1u) { t2 = (unsigned)((unsigned)c0 || 0xacddba78u); z2 = (double)(((1u >> (0xffffffffu & 31u))) & 255u); } if (((unsigned)((unsigned)(v0 == garr[i1 & 7u]) < i0)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                c0 = (unsigned char)(unsigned)((unsigned)(signed char)(a0[i0 & 3u] | (unsigned)(7u && 0xb55dc678u)) && (0x899373c9u + 0x2709678fu));
                if ((*mp % ((unsigned)((unsigned)h0 == p2) | 1u))) break;
                a0[(unsigned)!(unsigned)((unsigned)l0 == 0x7a851c3bu) & 3u] = (unsigned)((short)p1 > (signed char)1u);
                *q0 += (unsigned)(p0 && fuel);
                u3 ^= ((i2 * i2) ^ (0xffffffffu << ((unsigned)s0 & 31u)));
            }
        } while (i0++ < 5u && 0xa51fa557u);
        g0 = ((g1 + *mp) >> (u2 & 31u));
    }
    s0 = (int)2u;
    i0 = (unsigned)(signed char)(unsigned)((short)u3 > (signed char)(unsigned)(short)(5u | p1)) & 15u;
    if ((p0 & ((unsigned)x0 - (unsigned)b0))) {
        if ((unsigned)x0) {
            d0 = d0 * 0.5 + (double)((unsigned)(garr[u2 & 7u] || (unsigned)!(0x7fffffffu - (unsigned)(i2 || *q0))) & 1023u);
        } else {
            u0 ^= (unsigned)(0xff5cc052u || ~(u3 * fuel));
            if ((unsigned)(i1 == (i2 << (r0.x & 31u)))) goto L3;
            s0 = (int)((unsigned)s0 % ((unsigned)((short)(unsigned)e0 > (signed char)(unsigned)(*mp < (i2 + u0))) | 1u));
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((4u & (unsigned)l0) && (unsigned)e0), (unsigned)(0u && g1), (unsigned)(signed char)(5u % (i0 | 1u))); }
        }
        { unsigned t3; double z3; if ((g0) & 1u) { t3 = (unsigned)!(unsigned)(g1 || 1u); z3 = (double)((((unsigned)((int)(unsigned)h0 >= (int)6u) / (0xd1c00de3u | 1u))) & 255u); } if ((g0) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            h0 = (short)(unsigned)((int)((unsigned)((unsigned)h0 == garr[i1 & 7u]) / (u0 | 1u)) < (int)u1);
        }
        while (i0++ < 2u && (0xfb0abdb3u * 0x7fffffffu)) { if (--fuel == 0u) goto done;
            u1 ^= u1;
            if (budget != 0u) { budget -= 1u; u1 = fn2(*q0, (0xb6730b15u ^ (unsigned)(w0 >> 29)), 0x80000000u); }
            if (fuel) break;
            if (budget != 0u) { budget -= 1u; u3 = fn0((p2 ^ 4u), 0x80000000u, (unsigned)h1); }
        }
        if ((0xd8ea1af1u % (i2 | 1u))) goto L2;
        if (0x17fccdffu) goto L3;
    }
    { unsigned t4; double z4; if (((m0 << (6u & 31u))) & 1u) { t4 = 1u; z4 = (double)((~(unsigned)((short)g0 > (signed char)a0[u1 & 3u])) & 255u); } if (((m0 << (6u & 31u))) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
        goto L2;
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(x0 >> 70)) goto L2;
            { unsigned t5; double z5; if (((0x7201e41bu << ((unsigned)x0 & 31u))) & 1u) { t5 = (unsigned)((int)(0x7fffffffu | 8u) < (int)(unsigned)w0); z5 = (double)(((unsigned)e0) & 255u); } if (((0x7201e41bu << ((unsigned)x0 & 31u))) & 1u) { u2 += t5; d0 = d0 * 0.5 + z5; }
                e0 = e0 * 0.5L + (long double)((unsigned)((int)g0 < (int)(unsigned)((unsigned)(garr[i1 & 7u] == a0[i0 & 3u]) == (unsigned)((int)(unsigned)s0 >= (int)0x58c9c4c6u))) & 1023u);
                u2 = u2 * 0x9e3779b1u + (unsigned)!(unsigned)(((unsigned)b0 * (unsigned)(signed char)((unsigned)e0 << (0xffffffffu & 31u))) || (0x1e5ed212u & 0x80000000u));
                w0 = w0 * 6364136223846793005ull + (unsigned)(short)(garr[i1 & 7u] << (0x7930ed4fu & 31u));
                if ((0x9e6f2a0fu + (unsigned)(w0 >> 29))) break;
                if (budget != 0u) { budget -= 1u; u1 = fn2(fuel, (unsigned)((short)0x7fffffffu > (signed char)i1), i0); }
                while (i1++ < 5u && p2) { if (--fuel == 0u) goto done;
                    q0 = &garr[(unsigned)((unsigned)h1 && 0x7fffffffu) & 7u];
                    g1 += (unsigned)(w0 >> 29);
                    do { if (--fuel == 0u) goto done;
                        c1 = (signed char)(unsigned)((int)((unsigned)((short)(unsigned)h0 > (signed char)0x10000u) - (unsigned)s0) < (int)((unsigned)l0 << (garr[i1 & 7u] & 31u)));
                        if ((unsigned)l0) {
                            e0 = e0 * 0.5L + (long double)((unsigned)((short)0xffffffffu > (signed char)(unsigned)b0) & 1023u);
                            r0.x = a0[u1 & 3u];
                            a0[(unsigned)f0 & 3u] = (unsigned)s1;
                        }
                        c1 = (signed char)(3u - r0.x);
                        w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)((unsigned)(w0 >> 29) * (unsigned)s0);
                    } while (i2++ < 5u && (unsigned)((unsigned)((unsigned)(w0 >> 29) && *mp) && 0x80000000u));
                    if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)d0 & (unsigned)h1), (unsigned)(0x10000u || (unsigned)((int)0x92e6c197u >= (int)p1)), (unsigned)((int)(unsigned)f0 >= (int)(unsigned)c1)); }
                    w0 = w0 * 6364136223846793005ull + ~((unsigned)f0 % ((unsigned)e0 | 1u));
                }
            }
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(unsigned char)(a0[u1 & 3u] & 0x7fffffffu), ((unsigned)((int)0xffffffffu < (int)(unsigned)b0) - (unsigned)s0), (unsigned)(signed char)(unsigned)((unsigned)h0 == i1)); }
            switch ((unsigned)e0 & 7u) {
                do { if (--fuel == 0u) goto done;
                    switch ((u2 / (g0 | 1u)) & 7u) {
                        if (((unsigned)(p0 == 0x7cfc6404u) * garr[i1 & 7u])) goto L4;
                        for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                            g0 = (0x10000u | garr[u2 & 7u]);
                            if (u3 == 7u) return (unsigned)((int)g0 < (int)(unsigned)(i2 == a0[i0 & 3u]));
                            c0 = (unsigned char)(unsigned)!(u3 + ((0x9426f8a7u >> ((unsigned)c0 & 31u)) + 0xd882083au));
                            if ((unsigned)x0) goto done;
                            if (((unsigned)c0 << ((unsigned)(signed char)(unsigned)(*mp < i2) & 31u))) continue;
                        }
                        if (u3 == 7u) return (unsigned)((int)i1 < (int)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)((unsigned)l0 << (0xffffffffu & 31u))));
                    }
                    { unsigned t6; double z6; if ((((unsigned)l0 % ((0x80000000u / (6u | 1u)) | 1u))) & 1u) { t6 = i2; z6 = (double)(((unsigned)((int)(0xffffffffu | p2) >= (int)0x10000u)) & 255u); } if ((((unsigned)l0 % ((0x80000000u / (6u | 1u)) | 1u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                        case 6u: ;
                        switch ((i2 * a0[i0 & 3u]) & 7u) {
                            case 1u: ;
                            q0 = &garr[(unsigned)((int)i1 < (int)((0u | fuel) * a0[i0 & 3u])) & 7u];
                            c0 = (unsigned char)p0;
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn2(*mp, garr[i1 & 7u], ((unsigned)(unsigned char)(unsigned)((int)0x2d7349d4u >= (int)(unsigned)d0) & 0x4e7b4924u)); }
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)l0 << (0xa5aa7b77u & 31u)), (unsigned)(signed char)(((unsigned)f0 + *mp) | 5u), (3u % (0xffffffffu | 1u))); }
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)f0 >> (0x80000000u & 31u)), 0x7fffffffu, (m0 & (unsigned)(unsigned char)(u2 ^ p2))); }
                    case 1u: ;
                    do { if (--fuel == 0u) goto done;
                        w0 = w0 * 6364136223846793005ull + (unsigned)(unsigned char)((unsigned)(x0 >> 70) / (((unsigned)((short)(i2 ^ (unsigned)c1) > (signed char)0x7fffffffu) + 0x4d220760u) | 1u));
                        if (u3) {
                            if (fuel < 8u) return ((u2 ? a0[i0 & 3u] : 0x96a4a4ffu) & (unsigned)((unsigned)e0 == 0x10000u));
                            goto L1;
                            g0 = i1;
                            *q0 = (7u + (fuel % ((a0[i0 & 3u] | u1) | 1u)));
                        }
                    } while (i2++ < 7u && ((unsigned)(u3 == 0xffffffffu) << (i2 & 31u)));
                    u0 = (u1 + 0x10000u);
                } while (i1++ < 2u && (unsigned)(1u && p1));
                continue; (void)(0xf2be759au);
                if ((unsigned)((u3 / ((unsigned)b0 | 1u)) || 0x7fffffffu)) goto L3;
                if (((unsigned)((short)0x7fffffffu > (signed char)(unsigned)(x0 >> 70)) << ((unsigned)c0 & 31u))) goto done;
                while (0x80000000u) { if (--fuel == 0u) goto done;
                    case 3u: ;
                    case 2u: ;
                    x0 = x0 * 0x100000001b3ull + ((unsigned)f0 % (0u | 1u));
                }
            }
            if (budget != 0u) { budget -= 1u; u1 = fn2((u1 ^ (unsigned)b0), (p2 + (unsigned)c0), (p0 + ((unsigned)b0 << ((unsigned)b0 & 31u)))); }
            if (0xcf2798eeu) break;
        }
        w0 = w0 * 6364136223846793005ull + (0x80000000u & (unsigned)(signed char)(unsigned)((int)(fuel >> (u3 & 31u)) >= (int)(unsigned)e0));
        if (0x25ffe5f4u) goto L4;
        goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((short)u0 > (signed char)~(garr[i1 & 7u] << (u0 & 31u))), ~(0x10000u ^ 0x10000u), (unsigned)((int)8u < (int)(unsigned)((unsigned)w0 < *q0))); }
    }
    { unsigned t7; double z7; if (((unsigned)((unsigned)h0 || ((unsigned)h1 / (r0.y | 1u)))) & 1u) { t7 = ((unsigned)f0 * 0xffffffffu); z7 = (double)((((unsigned)x0 << (0x10eaa34fu & 31u))) & 255u); } if (((unsigned)((unsigned)h0 || ((unsigned)h1 / (r0.y | 1u)))) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
        if (budget != 0u) { budget -= 1u; u0 = fn0((m0 << (0x594c0986u & 31u)), (unsigned)((int)(unsigned)(x0 >> 70) < (int)0xaf26c171u), ((unsigned)l0 / (r0.y | 1u))); }
    }
    { unsigned t8; double z8; if (((unsigned)e0) & 1u) { t8 = (unsigned)((int)0xdadf7c21u < (int)fuel); z8 = (double)((5u) & 255u); } if (((unsigned)e0) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
        if ((m0 * (unsigned)s1)) {
            if ((unsigned)((unsigned)!(unsigned)((unsigned)b0 && 0x10000u) == (unsigned)(x0 >> 70))) goto L2;
        }
        for (;;) { if (--fuel == 0u) goto done;
            switch (((0x80000000u / (u2 | 1u)) << (r0.y & 31u)) & 7u) {
                if ((unsigned)s0) break;
                if (budget != 0u) { budget -= 1u; u2 = fn1(0x7fffffffu, ((unsigned)s1 ? *q0 : *mp), (unsigned)b0); }
            }
            s1 = (int)((unsigned)s1 + (unsigned)(g0 == u0));
            switch ((unsigned)(w0 >> 29) & 7u) {
                w0 ^= (unsigned long long)0x7fffffffu << (((unsigned)f0 - u3) & 63u);
            }
            break; (void)((unsigned)l0);
        }
        { unsigned t9; double z9; if (((0x5888361du ^ (0xfda81eb9u << (a0[u1 & 3u] & 31u)))) & 1u) { t9 = (unsigned)((int)((unsigned)h0 + (unsigned)(w0 >> 29)) < (int)r0.x); z9 = (double)(((0x7fffffffu ^ p1)) & 255u); } if (((0x5888361du ^ (0xfda81eb9u << (a0[u1 & 3u] & 31u)))) & 1u) { u1 += t9; d0 = d0 * 0.5 + z9; }
            *q0 = (unsigned)(w0 >> 29);
            i2 = p2 & 15u;
            g1 += a0[u1 & 3u];
        }
    }
    l0 = (long)((unsigned long)l0 + ((unsigned)(0x982d6697u < (unsigned)(w0 >> 29)) / (*mp | 1u)));
    if (budget != 0u) { budget -= 1u; u2 = fn0((0x10000u ^ (unsigned)(m0 || r0.x)), 2u, (~((unsigned)s0 << (0x9c29eeu & 31u)) - 0x10000u)); }
    for (;;) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((((unsigned)((unsigned)d0 && 0x33dfcec1u) - p1) % ((unsigned)((unsigned)w0 && r0.x) | 1u)) & 1023u);
        break; (void)((unsigned)c0);
        u3 += (unsigned)(p1 < (unsigned)(short)(unsigned)(r0.x < (unsigned)((int)m0 >= (int)g0)));
        if (u1) break;
    }
    if ((unsigned)(u2 || u1)) goto L2;
    if ((unsigned)((int)i1 >= (int)(unsigned)w0)) goto L4;
    goto done;
    b0 = (0x80000000u << ((g1 & 0x80000000u) & 31u)) != 0u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    s1 = (int)((unsigned)s1 + ((unsigned)c0 % (0x10000u | 1u)));
    garr[((unsigned)d0 / ((unsigned)s0 | 1u)) & 7u] = ((i1 / (r0.x | 1u)) * (unsigned)((int)0x10000u >= (int)u1));
    h1 = (unsigned short)(h1 + (unsigned)f0);
    h0 = (short)(unsigned)c0;
    L0: if (--fuel == 0u) goto done;
    if (a0[i0 & 3u]) goto done;
    goto L4;
    L1: if (--fuel == 0u) goto done;
    switch ((unsigned)(r0.y && (unsigned)c0) & 7u) {
        switch (u0 & 7u) {
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                u0 = 0x99bce31au;
                case 6u: ;
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)b0, (g1 ^ (a0[u1 & 3u] * (unsigned)l0)), (unsigned)((short)(unsigned)(short)(garr[u2 & 7u] + 0x2a5b745fu) > (signed char)0x10000u)); }
            }
            r0.x = (r0.y + (unsigned)((int)i0 >= (int)(unsigned)((int)a0[i0 & 3u] >= (int)3u)));
            u1 += (unsigned)(signed char)((0x7fffffffu % ((unsigned)h0 | 1u)) | (unsigned)(w0 >> 29));
            x0 = x0 * 0x100000001b3ull + ((unsigned)w0 ^ (unsigned)x0);
            for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.x = (i2 / ((unsigned)(w0 >> 29) | 1u));
                l0 = (long)((unsigned long)l0 + (a0[i0 & 3u] ^ 0xaf875b88u));
                g0 = ((unsigned)((int)0x7fffffffu >= (int)(0x10000u + p2)) * p1);
                h0 = (short)(0xd516c0a8u | ((unsigned)((int)0xcb274b1bu >= (int)(unsigned)h0) % (5u | 1u)));
                L2: if (--fuel == 0u) goto done;
                b0 = ((unsigned)(short)(unsigned)((int)0x1d101004u < (int)(unsigned)d0) & g1) != 0u;
            }
            do { if (--fuel == 0u) goto done;
                u3 = u3 * 0x9e3779b1u + 0x7fffffffu;
                if (((g1 + g1) / (p2 | 1u))) {
                    switch (((0x61337119u << (0xffffffffu & 31u)) / (r0.x | 1u)) & 7u) {
                        d0 = d0 * 0.5 + (double)((unsigned)(short)((unsigned)((int)(unsigned)((unsigned)e0 && 0xd8e8572eu) >= (int)(unsigned)(signed char)(unsigned)((int)p0 >= (int)u3)) + u3) & 1023u);
                        a0[(unsigned)d0 & 3u] = (unsigned)((int)4u < (int)u0);
                        switch ((0x80000000u * (0x7321dfau | 0x656c909cu)) & 7u) {
                            l0 = (long)((unsigned long)l0 + (unsigned)((p0 ? ((unsigned)s1 - i0) : (unsigned)d0) < 0xffffffffu));
                            x0 = x0 * 0x100000001b3ull + ((garr[u2 & 7u] & 0u) | (unsigned)c0);
                            q0 = &garr[4u & 7u];
                            case 7u: ;
                            u3 += g1;
                            c0 = (unsigned char)fuel;
                        }
                        L3: if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + ((unsigned)e0 / (m0 | 1u));
                    }
                    if ((unsigned)((unsigned)(w0 >> 29) == 4u)) break;
                    c0 = (unsigned char)(9u * 0x6c821de9u);
                } else {
                    case 3u: ;
                    if ((u0 % ((unsigned)(0xda5904f4u || (unsigned)b0) | 1u))) continue;
                }
            } while (i0++ < 5u && (((unsigned)b0 - 0xffffffffu) << ((unsigned)h0 & 31u)));
        }
        g1 += (unsigned)((unsigned)(v0 && g1) == 0x80000000u);
        goto L0;
        l0 = (long)((unsigned long)l0 + ~(unsigned)((unsigned)s1 == (unsigned)e0));
        L4: if (--fuel == 0u) goto done;
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        c1 = (signed char)0x10000u;
        if (i1) goto L2;
        *q0 = (unsigned)s1;
        if (budget != 0u) { budget -= 1u; u3 = fn3(u0, 0xffffffffu, 0xd90adacau); }
        if (u3 == 7u) return (0xffffffffu / ((m0 % (p0 | 1u)) | 1u));
        for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            i1 = *q0 & 15u;
            if ((garr[u2 & 7u] - 0xffffffffu)) break;
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + ((unsigned)b0 * i0);
                w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)c1 < i0);
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (unsigned)((int)(unsigned)((int)v0 < (int)u0) < (int)(unsigned)(~((unsigned)e0 & (unsigned)s0) < 0x10000u));
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)(unsigned)(0xff24f1bau && garr[u2 & 7u]) >= (int)(unsigned)c1), (unsigned)(signed char)(unsigned)((short)p2 > (signed char)2u), (unsigned)((short)(unsigned)w0 > (signed char)0x10000u)); }
                    garr[(unsigned)((int)a0[u1 & 3u] < (int)a0[i0 & 3u]) & 7u] = (unsigned)((int)(unsigned)((unsigned)h0 < i2) < (int)(((unsigned)f0 ^ fuel) ^ fuel));
                }
                break; (void)((unsigned)(*q0 && 1u));
            }
            i0 = (unsigned)(signed char)(0x52f39695u | (0x827fdafu ? i1 : (unsigned)f0)) & 15u;
            if (budget != 0u) { budget -= 1u; u3 = fn0(3u, i0, (unsigned)(x0 >> 70)); }
        }
    }
    switch ((unsigned)(a0[i0 & 3u] < (unsigned)l0) & 7u) {
        if (garr[u2 & 7u]) {
            for (;;) { if (--fuel == 0u) goto done;
                break; (void)(((unsigned)c1 & fuel));
                v0 = 0x7e71f201u;
            }
            m0 ^= (0xc28a9997u << ((unsigned)(unsigned char)(0xee71f2aeu % (0x87958571u | 1u)) & 31u));
            a0[(unsigned)((unsigned)(x0 >> 70) && (unsigned)c1) & 3u] = ~(0x80000000u << ((unsigned)s0 & 31u));
            h1 = (unsigned short)(h1 + ((unsigned)f0 >> (1u & 31u)));
            goto L0;
        } else {
            *q0 += (unsigned)((short)(2u >> ((unsigned)((int)5u < (int)(unsigned)c1) & 31u)) > (signed char)fuel);
            e0 = e0 * 0.5L + (long double)(((r0.x ? ((unsigned)h1 << (i1 & 31u)) : a0[u1 & 3u]) ^ (unsigned)d0) & 1023u);
        }
        case 6u: ;
        case 0u: ;
        break; (void)(((unsigned)s1 + m0));
        default: ;
    }
    u0 += 0x90434fd6u;
    if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)((int)(unsigned)b0 < (int)(unsigned)w0), (unsigned)(v0 && (*mp & u2)), (unsigned)f0); }
    c1 = (signed char)i1;
    r0.y ^= (p1 >> (0x10000u & 31u));
    goto L4;
    if (~((unsigned)((unsigned)(w0 >> 29) || r0.x) | 0x91dff994u)) goto L4;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)(((unsigned)b0 + *q0) & 1023u);
        r0.y ^= (unsigned)(0x6c55b57au && ((unsigned)f0 | ((unsigned)c0 - (unsigned)s0)));
        if ((unsigned)(6u || r0.x)) continue;
        goto L2;
        if ((0xffffffffu * a0[i0 & 3u])) break;
    }
    *q0 = *q0;
    if ((unsigned)((unsigned)s0 < garr[u2 & 7u])) goto L1;
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)g0 << ((u2 & (m0 - 0xce550f77u)) & 63u);
            w0 ^= (unsigned long long)(unsigned)(a0[i0 & 3u] && u1) << ((unsigned)h0 & 63u);
            m0 ^= (unsigned)((int)(unsigned)h0 >= (int)(unsigned)((unsigned)x0 || (5u << (*mp & 31u))));
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)((unsigned)b0 < 0x10000u) == (unsigned)d0), (unsigned)l0, (((unsigned)h1 | 0x10000u) & u0)); }
            *mp = (r0.y + p2);
            c1 = (signed char)(unsigned)(w0 >> 29);
        }
        *q0 = (unsigned)(short)(unsigned)(i1 == (unsigned)(w0 >> 29));
        if (u3 == 7u) return i0;
        *q0 += (unsigned)((int)((g1 * 9u) | ((unsigned)d0 | u2)) >= (int)(unsigned)(w0 >> 29));
        do { if (--fuel == 0u) goto done;
            u0 = u0 * 0x9e3779b1u + ((((unsigned)(w0 >> 29) & garr[i1 & 7u]) ? 0x10000u : 0x9142ae1du) ^ 7u);
        } while (i1++ < 4u && (unsigned)(x0 >> 70));
    }
    { unsigned t0; double z0; if (((((unsigned)h0 & (unsigned)c0) ^ 0xbbc38599u)) & 1u) { t0 = ((unsigned)s0 ^ i1); z0 = (double)(((unsigned)((int)garr[i1 & 7u] >= (int)*q0)) & 255u); } if (((((unsigned)h0 & (unsigned)c0) ^ 0xbbc38599u)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        if (6u) goto L2;
    }
    *q0 += ((unsigned)e0 + (unsigned)(short)(unsigned)((int)i1 < (int)r0.x));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 8u, 0x90acf092u, 0x67004e0bu },
        { 0u, 0x4d267fe8u, 0xcf59d850u },
        { 0u, 0xdb7c7c41u, 0x4a392b56u },
        { 10u, 0xab509831u, 0xde129dfau },
        { 9u, 0x4345d30au, 0xbd1d8c36u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
