// test-ssa-source's program of seed 141000430 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x9692dc7eu, g1 = 0xd05083abu;
static unsigned garr[8] = { 0xe400bb02u, 0x6f7ae926u, 0xe8c7204cu, 0xfaea74c2u, 0x85b93530u, 0xb1ef3e73u, 0x371a4b63u, 0xcab9a829u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        g1 += ((unsigned)((int)((unsigned)x0 % (p2 | 1u)) >= (int)i0) | (unsigned)(0x80000000u && 8u));
        l0 = (long)((unsigned long)l0 + (unsigned)s0);
        break; (void)((unsigned)((int)(unsigned)((int)u3 >= (int)a0[i0 & 3u]) < (int)(unsigned)c1));
        L0: if (--fuel == 0u) goto done;
        g1 += (unsigned)((short)3u > (signed char)(unsigned)((unsigned)b0 < (((unsigned)s1 ^ 0xc31d1c89u) << ((unsigned)h0 & 31u))));
    }
    switch (p2 & 7u) {
        L1: if (--fuel == 0u) goto done;
        if ((unsigned)c1) goto L3;
        while (p0) { if (--fuel == 0u) goto done;
            if (garr[u2 & 7u]) {
                switch (0xb2a6d441u & 7u) {
                    for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                        g0 = ((unsigned)h0 & (unsigned)(6u && 1u));
                        *mp = (0xfe9c8febu % ((0xf0a747d7u / (garr[u2 & 7u] | 1u)) | 1u));
                        q0 = &garr[(unsigned)((unsigned)x0 < (((unsigned)h0 >> ((unsigned)s1 & 31u)) ^ (unsigned)(u0 || r0.x))) & 7u];
                        d0 = d0 * 0.5 + (double)((unsigned)(u1 < m0) & 1023u);
                        r0.y ^= ((unsigned)(unsigned char)(0x80000000u << (4u & 31u)) >> ((2u >> (0xffffffffu & 31u)) & 31u));
                        while (i2++ < 7u && (0x7fffffffu & u3)) { if (--fuel == 0u) goto done;
                            r0.x = (p1 | (unsigned)((short)garr[i1 & 7u] > (signed char)(i1 << (p1 & 31u))));
                        }
                    }
                    f0 = f0 * 0.5f + (float)((unsigned)f0 & 255u);
                    case 4u: ;
                    if (((unsigned)(w0 >> 29) + 5u)) break;
                    L2: if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + (u3 & 0x58d3ffc6u);
                }
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)c1)) break;
                    g1 += (unsigned)((int)(g1 / (((unsigned)((unsigned)h0 < u1) + i1) | 1u)) < (int)u0);
                }
                case 6u: ;
                L3: if (--fuel == 0u) goto done;
                c0 = (unsigned char)i1;
                *mp = 5u;
            } else {
                m0 ^= (~(unsigned)((int)p1 >= (int)(unsigned)(0x7fffffffu || 8u)) >> ((garr[i1 & 7u] << (1u & 31u)) & 31u));
                case 3u: ;
                h0 = (short)(unsigned)(unsigned char)(unsigned)((unsigned)(signed char)(unsigned)(a0[u1 & 3u] == (garr[u2 & 7u] << (u1 & 31u))) == (unsigned)((short)(unsigned)s1 > (signed char)(unsigned)d0));
            }
            if ((r0.x + 0xffffffffu)) {
                if ((unsigned)!(unsigned)((int)(unsigned)l0 < (int)(unsigned)((int)1u < (int)8u))) goto L0;
                s1 = (int)((unsigned)s1 + ((9u % (((unsigned)w0 / (0x7fffffffu | 1u)) | 1u)) << ((unsigned)x0 & 31u)));
                c1 = (signed char)(((unsigned)(w0 >> 29) + a0[i0 & 3u]) & ((unsigned)s1 / (0x59cfab8fu | 1u)));
            }
            if ((6u & u1)) {
                if (u1) goto L3;
                L4: if (--fuel == 0u) goto done;
                if (-(unsigned)(3u || (unsigned)c1)) continue;
                case 1u: ;
                w0 = w0 * 6364136223846793005ull + ((unsigned)(u0 == i2) ? (unsigned)e0 : (unsigned)((unsigned)f0 == 0xf436c9d0u));
                u2 = u2 * 0x9e3779b1u + 0x4d73512u;
            }
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                *mp = (8u / ((i2 & (unsigned)(short)(unsigned)((short)0xc2947508u > (signed char)~(a0[i0 & 3u] >> ((unsigned)d0 & 31u)))) | 1u));
                garr[(*mp & (unsigned)c0) & 7u] = (m0 + r0.y);
                case 2u: ;
                default: ;
                l0 = (long)((unsigned long)l0 + (unsigned)(signed char)(unsigned)((0x80000000u % (*mp | 1u)) || (unsigned)(signed char)(8u & 4u)));
                { unsigned t0; double z0; if ((r0.x) & 1u) { t0 = (unsigned)((int)r0.x >= (int)(2u << (a0[u1 & 3u] & 31u))); z0 = (double)(((i1 - 0xffffffffu)) & 255u); } if ((r0.x) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
                    switch ((m0 & (*q0 - (unsigned)f0)) & 7u) {
                        goto L0;
                        if ((5u % ((i2 ^ r0.x) | 1u))) break;
                        q0 = &garr[(3u << (i2 & 31u)) & 7u];
                        case 4u: ;
                        if ((fuel * (unsigned)((short)(unsigned)s0 > (signed char)(unsigned)c1))) break;
                        c0 = (unsigned char)(unsigned)((int)((unsigned)c0 - (u3 >> ((p2 | (unsigned)f0) & 31u))) < (int)0x10000u);
                    }
                }
            }
            case 4u: ;
        }
        f0 = f0 * 0.5f + (float)((unsigned)h1 & 255u);
        while (i0++ < 2u && (unsigned)((unsigned)s1 < 0xf2fc5ea4u)) { if (--fuel == 0u) goto done;
            x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)c0 || (unsigned)(w0 >> 29));
            while (i1++ < 2u && (unsigned)((int)garr[i1 & 7u] < (int)u3)) { if (--fuel == 0u) goto done;
                u1 = u1 * 0x9e3779b1u + ((unsigned)w0 ? -(unsigned)(0xce7e1b6fu || (a0[i0 & 3u] / (fuel | 1u))) : u1);
                w0 ^= (unsigned long long)0x80000000u << (u2 & 63u);
            }
            if (0x9d5c0cafu) {
                break;
                q0 = &garr[(garr[u2 & 7u] << (((unsigned)h1 << (r0.y & 31u)) & 31u)) & 7u];
                break; (void)(0u);
                *q0 += ((*q0 * fuel) % ((unsigned)((unsigned)(0x10000u || (unsigned)h0) && g0) | 1u));
                if (m0) goto L3;
                do { if (--fuel == 0u) goto done;
                    break;
                    if (i0) break;
                    case 0u: ;
                } while (i1++ < 4u && a0[u1 & 3u]);
            }
            u0 += (*mp * (5u & (((unsigned)l0 * (unsigned)d0) * i0)));
            *mp = (unsigned)((short)(garr[u2 & 7u] << ((unsigned)c1 & 31u)) > (signed char)0xffffffffu);
        }
        u0 = (v0 ^ (unsigned)c1);
    }
    c0 = (unsigned char)(unsigned)(unsigned char)(unsigned)((int)r0.x < (int)(i0 & 0x7fffffffu));
    if ((u2 % (4u | 1u))) goto done;
    do { if (--fuel == 0u) goto done;
        if (2u) goto L4;
        for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((*q0 << ((unsigned)!(unsigned)(0x3352568bu == 0x80000000u) & 31u))) break;
            if (u2) {
                c0 = (unsigned char)(unsigned)x0;
                break; (void)((unsigned)(short)((garr[i1 & 7u] / (r0.x | 1u)) | u3));
                if (((unsigned)x0 << ((0x10000u >> ((unsigned)s0 & 31u)) & 31u))) break;
            } else {
                while ((unsigned)((unsigned)l0 || (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                    break; (void)(((unsigned)l0 + (unsigned)(a0[u1 & 3u] == (unsigned)(w0 >> 29))));
                    if ((a0[u1 & 3u] * (unsigned)c0)) {
                        if (6u) break;
                        r0.y ^= ((0x7fffffffu >> ((unsigned)(w0 >> 29) & 31u)) ^ (unsigned)(x0 >> 70));
                        if ((g0 | (g0 - i1))) goto done;
                        continue; (void)((garr[u2 & 7u] ^ 0x80000000u));
                    } else {
                        e0 = e0 * 0.5L + (long double)(a0[u1 & 3u] & 1023u);
                        w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)!(unsigned)((fuel << (0x896d4a21u & 31u)) == (unsigned)(unsigned char)(unsigned)((int)1u < (int)a0[u1 & 3u])) == 3u);
                        garr[(unsigned)x0 & 7u] = (~((unsigned)((int)p2 >= (int)u3) * g0) + (g0 / (*q0 | 1u)));
                        r0.y ^= 6u;
                    }
                    break; (void)((unsigned)(2u && u0));
                    c1 = (signed char)(unsigned)((int)(unsigned)l0 < (int)0x80000000u);
                    if ((unsigned)(garr[u2 & 7u] && u1)) {
                        q0 = &garr[(unsigned)e0 & 7u];
                        if (6u) break;
                    }
                }
                break; (void)(u1);
                s0 = (int)i0;
                if (((unsigned)c1 << (r0.y & 31u))) continue;
            }
            do { if (--fuel == 0u) goto done;
                u0 = u0 * 0x9e3779b1u + (unsigned)((int)u0 < (int)(unsigned)(0x48e5e774u && 8u));
                if (-((p2 % (0xffffffffu | 1u)) + 7u)) break;
            } while (i2++ < 5u && (r0.x >> (r0.x & 31u)));
            m0 ^= ((unsigned)h1 << (5u & 31u));
            { unsigned t1; double z1; if ((0x10000u) & 1u) { t1 = ((u0 ^ u3) >> ((unsigned)c0 & 31u)); z1 = (double)(((u0 + *mp)) & 255u); } if ((0x10000u) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
                c0 = (unsigned char)(unsigned)((short)~((unsigned)(r0.y == p1) - 0x10000u) > (signed char)(unsigned)f0);
                u3 = u3 * 0x9e3779b1u + (unsigned)((int)garr[u2 & 7u] < (int)((5u - (unsigned)(p2 == g0)) / (*mp | 1u)));
            }
        }
        if (0x47a9652fu) break;
    } while (i0++ < 7u && 0xd0e169b0u);
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= u1;
        *mp = *mp;
        w0 = w0 * 6364136223846793005ull + -(0xffffffffu * (unsigned)l0);
        garr[a0[i0 & 3u] & 7u] = i1;
    }
    u2 = (0xde1b42au << (((unsigned)c1 - *q0) & 31u));
    while (i0++ < 6u && (unsigned)h0) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(0x1230f459u && 0x80000000u));
        break; (void)((unsigned)!(unsigned)((short)g0 > (signed char)u1));
        if ((unsigned)((int)r0.y >= (int)0x7e360121u)) break;
    }
    goto L2;
    g1 += (unsigned)(0x80000000u == (unsigned)e0);
    q0 = &garr[(unsigned)((int)((unsigned)e0 % (v0 | 1u)) < (int)(unsigned)b0) & 7u];
    r0.x = (3u ? (unsigned)f0 : r0.y);
    do { if (--fuel == 0u) goto done;
        if ((unsigned)((short)0xf8ce7c7du > (signed char)(unsigned)w0)) {
            break; (void)((unsigned)(((unsigned)d0 & (unsigned)h1) == (unsigned)c1));
            f0 = f0 * 0.5f + (float)((unsigned)((short)~(0u ? a0[i0 & 3u] : (unsigned)(x0 >> 70)) > (signed char)0xffffffffu) & 255u);
            while ((unsigned)(short)(unsigned)((int)a0[u1 & 3u] < (int)(0x7fffffffu << (5u & 31u)))) { if (--fuel == 0u) goto done;
                if (u0) continue;
                if ((unsigned)(w0 >> 29)) {
                    if ((unsigned)((int)(unsigned)e0 < (int)garr[i1 & 7u])) break;
                    if ((unsigned)c1) break;
                    break; (void)((unsigned)((short)m0 > (signed char)(unsigned)((int)i0 >= (int)i1)));
                    m0 ^= ((unsigned)s0 % (0x10000u | 1u));
                    if ((u0 * (g0 - 0xd1b99ef8u))) break;
                } else {
                    if (0x12d02a10u) break;
                    break; (void)((1u * (0x80000000u + (unsigned)w0)));
                }
                if ((unsigned)(0x11a95322u == (unsigned)(unsigned char)((unsigned)f0 << (p2 & 31u)))) goto L2;
                if (-(~(garr[i1 & 7u] ^ 9u) ^ a0[u1 & 3u])) break;
                if ((unsigned)(signed char)(unsigned)((int)(0x29dc3297u / (r0.x | 1u)) >= (int)6u)) {
                    w0 = w0 * 6364136223846793005ull + (unsigned)c1;
                    if ((unsigned)(((unsigned)h1 & 0x9f1edbbu) && *mp)) break;
                    if ((unsigned)((int)i2 < (int)a0[u1 & 3u])) break;
                    u0 ^= (unsigned)(unsigned char)(unsigned)(0xc9fc77c1u == (u1 & 6u));
                }
            }
            if ((unsigned)(((unsigned)s1 + 0x950149b9u) == fuel)) break;
        } else {
            x0 = x0 * 0x100000001b3ull + ((unsigned)h0 | ((unsigned)((unsigned)s1 == a0[i0 & 3u]) * (unsigned)((int)(unsigned)b0 >= (int)i1)));
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                while ((unsigned)((unsigned)!(*mp + (unsigned)d0) < (unsigned)f0)) { if (--fuel == 0u) goto done;
                    break; (void)(((unsigned)((int)(unsigned)s0 >= (int)0x80000000u) << ((unsigned)e0 & 31u)));
                    break; (void)((unsigned)((unsigned)c1 < p1));
                    u2 = u2 * 0x9e3779b1u + 0x80000000u;
                }
                s1 = (int)((unsigned)s1 + ((unsigned)(v0 && (unsigned)x0) - (garr[u2 & 7u] % ((unsigned)c0 | 1u))));
                c1 = (signed char)(*mp * (fuel - 0x10000u));
                break; (void)((unsigned)(w0 >> 29));
                do { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + 1u);
                    w0 ^= (unsigned long long)(0u + i0) << (((unsigned)((short)(unsigned)b0 > (signed char)a0[u1 & 3u]) % ((((unsigned)s1 >> (9u & 31u)) << ((unsigned)e0 & 31u)) | 1u)) & 63u);
                    if ((unsigned)b0) break;
                    continue; (void)((unsigned)((int)0xa0f8bff1u >= (int)(unsigned)h0));
                    do { if (--fuel == 0u) goto done;
                        r0.y ^= ((m0 / ((unsigned)((unsigned)b0 && (unsigned)(x0 >> 70)) | 1u)) + (0x80000000u << ((unsigned)(x0 >> 70) & 31u)));
                    } while (i0++ < 6u && (i0 << (0xb0d2c512u & 31u)));
                    u3 = (unsigned)e0;
                } while (i2++ < 5u && (unsigned)(0x869ea1a6u || (unsigned)((int)0x15222fd8u >= (int)0xffffffffu)));
            }
            if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)(unsigned char)(i1 * (unsigned)f0))) goto L1;
        }
        continue; (void)(~(0x7fffffffu % (p0 | 1u)));
        c1 = (signed char)garr[i1 & 7u];
        u1 += (i1 | (i2 ^ (0xafb3850u >> (0xe7f59ad3u & 31u))));
    } while (i0++ < 6u && (r0.x % (u3 | 1u)));
    if (g0) goto done;
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= (unsigned)(short)(((unsigned)(x0 >> 70) + 0x10000u) ^ (unsigned)h1);
        w0 ^= (unsigned long long)u1 << (((unsigned)(signed char)(8u - ((unsigned)f0 << ((unsigned)(x0 >> 70) & 31u))) % (m0 | 1u)) & 63u);
        *q0 = (unsigned)(short)(unsigned)((int)3u < (int)(unsigned)(garr[u2 & 7u] < (unsigned)s1));
        w0 ^= (unsigned long long)0x13dc4b69u << (((unsigned)(signed char)((unsigned)c0 + (4u << (garr[u2 & 7u] & 31u))) & (0x7fffffffu & 9u)) & 63u);
    }
    i1 = (unsigned)(signed char)((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)s0) | 0x80000000u) & 15u;
    if ((u3 | (a0[i0 & 3u] | (unsigned)h1))) goto L3;
    if (i1) goto L0;
    goto L4;
    a0[(unsigned)((int)0x80000000u < (int)0xffffffffu) & 3u] = (unsigned)(unsigned char)(u3 << ((0x80000000u >> (0x80000000u & 31u)) & 31u));
    switch ((unsigned)((int)m0 < (int)fuel) & 7u) {
        if (0xffffffffu) break;
        while (i0++ < 2u && (unsigned)((short)(unsigned)e0 > (signed char)u2)) { if (--fuel == 0u) goto done;
            if (fuel < 8u) return (unsigned)((int)a0[u1 & 3u] < (int)0xffffffffu);
            while ((unsigned)s1) { if (--fuel == 0u) goto done;
                g0 = (((u0 >> ((unsigned)(x0 >> 70) & 31u)) >> (g0 & 31u)) % ((unsigned)((short)u2 > (signed char)0x3dab2359u) | 1u));
                r0.y ^= -(unsigned)(u2 == (unsigned)s1);
                case 7u: ;
                v0 = (garr[u2 & 7u] | g1);
                if (a0[u1 & 3u]) break;
                if ((u3 + 0x10000u)) break;
            }
        }
        i1 = (unsigned)(p2 == ~((unsigned)e0 / ((unsigned)s1 | 1u))) & 15u;
        case 5u: ;
        default: ;
    }
    { unsigned t2; double z2; if (((0xffffffffu - (unsigned)(a0[u1 & 3u] && *q0))) & 1u) { t2 = (unsigned)(4u || (unsigned)(short)(v0 | p1)); z2 = (double)(((unsigned)(u1 && *mp)) & 255u); } if (((0xffffffffu - (unsigned)(a0[u1 & 3u] && *q0))) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
        u1 += (unsigned)((int)~((8u % ((0x7fffffffu + 0x10000u) | 1u)) ^ (unsigned)h0) < (int)fuel);
        if ((unsigned)((unsigned)d0 < g0)) goto L3;
        if (i2) {
            goto L3;
        }
        { unsigned t3; double z3; if ((((unsigned)c0 | (garr[i1 & 7u] / (i2 | 1u)))) & 1u) { t3 = (unsigned)(p0 || r0.x); z3 = (double)((-((unsigned)e0 | (*mp - 0xab38d78cu))) & 255u); } if ((((unsigned)c0 | (garr[i1 & 7u] / (i2 | 1u)))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
            u0 = (unsigned)(w0 >> 29);
            while ((0x7fffffffu >> (((unsigned)l0 >> ((unsigned)s1 & 31u)) & 31u))) { if (--fuel == 0u) goto done;
                if ((0x10000u & (u1 | (unsigned)f0))) break;
            }
            if ((unsigned)(0x1e25959bu && fuel)) goto L4;
        }
        switch (3u & 7u) {
            case 2u: ;
            s0 = (int)-(0xffffffffu / (g0 | 1u));
            if (((unsigned)h1 * u3)) {
                default: ;
                if (((unsigned)(0xffffffffu || (unsigned)h1) + 0xf18ef1e6u)) {
                    garr[(unsigned)(garr[u2 & 7u] == p2) & 7u] = (unsigned)(0x80000000u < (a0[i0 & 3u] - u1));
                    break; (void)((a0[i0 & 3u] >> ((3u - p2) & 31u)));
                } else {
                    case 6u: ;
                    for (;;) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (unsigned)((unsigned)((int)g0 >= (int)a0[u1 & 3u]) == 0xffffffffu));
                        l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)d0 < p0));
                    }
                    h0 = (short)((i1 ? u0 : (unsigned)f0) & (unsigned)l0);
                }
                case 1u: ;
                case 3u: ;
                l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)(((u1 & 4u) - (unsigned)c0) < (unsigned)c0));
            } else {
                e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)e0 < (*q0 * (r0.x ? 0x9bb07be2u : p0))) & 1023u);
            }
        }
        u1 += 0xffffffffu;
    }
    goto L3;
    if ((u0 * (unsigned)((short)(unsigned)f0 > (signed char)p0))) goto done;
    e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)((unsigned)(4u || p1) && (unsigned)((short)garr[i1 & 7u] > (signed char)5u)) > (signed char)(unsigned)(w0 >> 29)) & 1023u);
    c1 = (signed char)((unsigned)(w0 >> 29) ? (unsigned)l0 : i1);
    if ((m0 & (garr[u2 & 7u] * (unsigned)e0))) {
        s1 = (int)((unsigned)s1 + ((unsigned)e0 - (unsigned)((i1 % (v0 | 1u)) < (unsigned)((int)u0 < (int)3u))));
        if ((unsigned)(0x8cd119dcu || (unsigned)s0)) goto L4;
        *q0 += ((unsigned)((int)p1 < (int)(unsigned)e0) ^ (((unsigned)c1 + (unsigned)d0) % (garr[u2 & 7u] | 1u)));
        g0 = p0;
    }
    *q0 = p2;
    if (((unsigned)(w0 >> 29) >> (u1 & 31u))) goto L4;
    { unsigned t4; double z4; if (((unsigned)(a0[i0 & 3u] == (unsigned)f0)) & 1u) { t4 = (unsigned)!(unsigned)((int)(unsigned)(0x56079bc8u == u0) >= (int)(unsigned)w0); z4 = (double)((((unsigned)(0x80000000u < *q0) >> (0x1a699075u & 31u))) & 255u); } if (((unsigned)(a0[i0 & 3u] == (unsigned)f0)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
        if ((u0 ? (unsigned)f0 : 5u)) goto L0;
    }
    s0 = (int)((unsigned)f0 + 0xe21d0c66u);
    goto done;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        g0 = (unsigned)(p1 == 5u);
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)!(u0 & (i2 / (0xffffffffu | 1u)));
            if ((unsigned)((unsigned)s1 && p1)) {
                L0: if (--fuel == 0u) goto done;
                L1: if (--fuel == 0u) goto done;
                if ((unsigned)((int)(r0.x - r0.x) >= (int)(unsigned)(w0 >> 29))) break;
                L2: if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
            } else {
                v0 = (unsigned)(0x10000u && (unsigned)d0);
                L4: if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(unsigned)((int)(unsigned)(fuel < (unsigned)((unsigned)(0x7f141639u || (unsigned)s1) < (unsigned)(x0 >> 70))) < (int)i0);
                    if (p0) break;
                } while (i2++ < 6u && (unsigned)(unsigned char)((i2 + 0xf952aa1fu) | g0));
            }
            m0 ^= p0;
            switch (r0.y & 7u) {
                case 3u: ;
                if ((*mp | (0x7fffffffu * 0xca4d08a1u))) continue;
                *mp = 0x80000000u;
            }
            if (((unsigned)w0 << ((a0[u1 & 3u] / (*mp | 1u)) & 31u))) break;
        }
        if (r0.y) break;
        h1 = (unsigned short)(h1 + (-(unsigned)(i1 < 3u) ^ ~(r0.x / ((unsigned)d0 | 1u))));
    }
    *q0 += (unsigned)(((unsigned)s1 << ((unsigned)c0 & 31u)) && u1);
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        i0 = (unsigned)((0x3ff17405u * 0x7fffffffu) == i0) & 15u;
        s0 = (int)((unsigned)w0 / (g0 | 1u));
        h0 = (short)((0x7fffffffu ^ (unsigned)c1) ? (unsigned)(w0 >> 29) : v0);
        if (g0) {
            if (0x789218bfu) break;
            if ((unsigned)c0) {
                if (((unsigned)(w0 >> 29) / (i1 | 1u))) {
                    c1 = (signed char)(unsigned)((int)(unsigned)c1 < (int)(unsigned)(signed char)(unsigned)((int)*mp >= (int)p2));
                    h0 = (short)(unsigned)(a0[i0 & 3u] == (i2 - (garr[u2 & 7u] >> (1u & 31u))));
                    *q0 = ((unsigned)((short)(unsigned)c1 > (signed char)u2) - ((u0 / ((unsigned)c1 | 1u)) | (unsigned)l0));
                    r0.y ^= (unsigned)((short)i2 > (signed char)(unsigned)(g1 < 0x1cd6804au));
                    q0 = &garr[(unsigned)(((unsigned)((int)(v0 << (u3 & 31u)) < (int)0xffffffffu) - i2) == 0x22b8c248u) & 7u];
                    garr[(g1 * u3) & 7u] = ((((unsigned)h1 & 0x7fffffffu) << (0xe3ec1c03u & 31u)) - (unsigned)(w0 >> 29));
                } else {
                    g0 = (unsigned)w0;
                    if ((unsigned)!(unsigned)(*mp || garr[i1 & 7u])) break;
                }
                if (budget != 0u) { budget -= 1u; u2 = fn0((0xffffffffu ^ (unsigned)e0), ((unsigned)w0 / (0xffffffffu | 1u)), (unsigned)(short)(unsigned)((unsigned)(0xffffffffu || 0xffffffffu) || p0)); }
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    i0 = (unsigned)e0 & 15u;
                }
                while (i1++ < 2u && 0xf54ad334u) { if (--fuel == 0u) goto done;
                    u3 = (unsigned)((int)7u >= (int)(unsigned)w0);
                    if (r0.y) break;
                    break; (void)(v0);
                }
                r0.x = ((unsigned)h0 * g1);
                { unsigned t0; double z0; if ((((unsigned)(w0 >> 29) ^ ((unsigned)c1 % (i0 | 1u)))) & 1u) { t0 = (0xdb8bda21u * (unsigned)d0); z0 = (double)(((((unsigned)l0 << ((unsigned)d0 & 31u)) % (4u | 1u))) & 255u); } if ((((unsigned)(w0 >> 29) ^ ((unsigned)c1 % (i0 | 1u)))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    u0 = (unsigned)((int)(unsigned)(short)(8u / ((p0 % (0x7ef6577bu | 1u)) | 1u)) < (int)(unsigned)(p2 < fuel));
                    *q0 = (unsigned)((int)(unsigned)f0 >= (int)(unsigned)((unsigned)((0x5b1326bbu | i0) < (unsigned)(w0 >> 29)) == (unsigned)w0));
                    if (~(unsigned)(*mp == ~(4u >> (0x7fffffffu & 31u)))) {
                        w0 = w0 * 6364136223846793005ull + (0x7fffffffu * 0x5ff79f53u);
                    } else {
                        s0 = (int)(*mp >> ((unsigned)s1 & 31u));
                        w0 ^= (unsigned long long)(unsigned)!(unsigned)((short)0u > (signed char)garr[u2 & 7u]) << (((unsigned)((unsigned)x0 == 0x10000u) + (unsigned)s1) & 63u);
                    }
                    h0 = (short)((p1 % (p2 | 1u)) >> (a0[u1 & 3u] & 31u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)d0 & 0x3007cdb3u), (p2 % (g0 | 1u)), (0xbc0ccacbu & (unsigned)f0)); }
                }
            }
            break; (void)((fuel ^ 0xcfefe6cdu));
            r0.y ^= 0x9eb57f15u;
        } else {
            h1 = (unsigned short)(h1 + (unsigned)(0xd1c6d4c6u && i0));
            if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)(i0 || (unsigned)c0) ^ i0), (unsigned)(i2 && (unsigned)s0), (unsigned)!(unsigned)((unsigned)s0 == 0u)); }
            h1 = (unsigned short)(h1 + 7u);
            continue; (void)(((unsigned)b0 >> ((u0 * 0x60d894a4u) & 31u)));
        }
    }
    { unsigned t1; double z1; if ((g1) & 1u) { t1 = u3; z1 = (double)(((p0 ? (unsigned)(x0 >> 70) : 0u)) & 255u); } if ((g1) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        u1 ^= (((unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)s1) * 0x80000000u) * 0x10000u);
        do { if (--fuel == 0u) goto done;
            if ((u2 - (unsigned)e0)) {
                if (r0.y) continue;
                while (i1++ < 7u && (garr[u2 & 7u] | ((unsigned)(w0 >> 29) + 0x7d93cb15u))) { if (--fuel == 0u) goto done;
                    for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                        q0 = &garr[(r0.x | (u3 & (g0 + r0.y))) & 7u];
                        g1 += ((unsigned)((int)9u >= (int)u3) * (unsigned)(g1 && (unsigned)s0));
                        x0 = x0 * 0x100000001b3ull + ((0x80000000u % ((unsigned)(x0 >> 70) | 1u)) + g0);
                        continue; (void)((unsigned)(signed char)(unsigned)((int)r0.y >= (int)p2));
                    }
                    a0[a0[u1 & 3u] & 3u] = ((unsigned)((unsigned)((unsigned)((int)(unsigned)x0 < (int)garr[u2 & 7u]) || 0x7fffffffu) < u3) / (i0 | 1u));
                    break; (void)((unsigned)h0);
                }
                *mp = (unsigned)e0;
                b0 = 0xa9cd4fadu != 0u;
            }
        } while (i0++ < 2u && (*mp << ((unsigned)d0 & 31u)));
        c1 = (signed char)r0.y;
    }
    if ((1u % (r0.x | 1u))) {
        if (fuel < 8u) return *q0;
        x0 = x0 * 0x100000001b3ull + ((unsigned)(0x32a5cf17u || (unsigned)((short)0x10000u > (signed char)0x10000u)) << ((unsigned)c1 & 31u));
    }
    v0 = 0x80000000u;
    if ((unsigned)h1) goto L1;
    if (garr[i1 & 7u]) {
        while ((garr[u2 & 7u] % ((unsigned)h0 | 1u))) { if (--fuel == 0u) goto done;
            if (0xebc7da7au) break;
            if ((((unsigned)e0 >> (*q0 & 31u)) | (unsigned)s0)) break;
            if (((*q0 * 0x7fffffffu) & 0xdb47128u)) {
                *mp = 0xc5a49523u;
                if ((unsigned)(signed char)(u0 >> ((unsigned)c1 & 31u))) break;
                h1 = (unsigned short)(h1 + ((unsigned)e0 - (unsigned)(unsigned char)(r0.x ? (unsigned)f0 : (unsigned)(w0 >> 29))));
            } else {
                garr[p1 & 7u] = r0.x;
                while ((unsigned)(signed char)(u3 - 0x80000000u)) { if (--fuel == 0u) goto done;
                    r0.x = ((unsigned)((int)1u < (int)-(unsigned)(~(unsigned)(9u || p1) < i2)) + (unsigned)x0);
                }
                if ((g0 + 0xfd658cc5u)) break;
            }
            garr[a0[u1 & 3u] & 7u] = a0[u1 & 3u];
        }
        while (i0++ < 7u && (0xf6ffb205u / ((unsigned)l0 | 1u))) { if (--fuel == 0u) goto done;
            a0[5u & 3u] = (unsigned)(((unsigned)((int)(fuel % (7u | 1u)) < (int)g0) + (unsigned)d0) || m0);
            r0.y ^= (unsigned)((int)0x45f5c3ecu < (int)(unsigned)((unsigned)(0x80000000u < (unsigned)h1) || (unsigned)e0));
            goto L4;
        }
        *q0 += (unsigned)((int)garr[i1 & 7u] >= (int)g0);
    } else {
        switch (0u & 7u) {
            switch (u2 & 7u) {
                while ((unsigned)(0x24a5fecbu < p0)) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            i2 = (unsigned)(((unsigned)e0 ^ 0x6e23c4b8u) < 4u) & 15u;
                            b0 = (unsigned)((0x7ade34c9u | (unsigned)h1) < (unsigned)(u2 == (unsigned)s1)) != 0u;
                            if ((unsigned)(x0 >> 70)) break;
                            case 0u: ;
                            case 7u: ;
                        } while (i2++ < 5u && (unsigned)(0xd8a5beeeu == p2));
                        m0 ^= (unsigned)((short)((unsigned)b0 % ((unsigned)(i0 || ~(unsigned)(p2 || 0xa12308c8u)) | 1u)) > (signed char)0x9e48ae2fu);
                        e0 = e0 * 0.5L + (long double)(p1 & 1023u);
                    } while (i1++ < 6u && (unsigned)(w0 >> 29));
                    u0 = u0 * 0x9e3779b1u + *q0;
                    case 6u: ;
                    h0 = (short)(*q0 >> (((unsigned)((int)(unsigned)((int)(unsigned)(w0 >> 29) < (int)(unsigned)h0) >= (int)*q0) + g1) & 31u));
                }
                if (0xdbe0ef1u) goto L3;
                case 1u: ;
                if ((u3 ? (unsigned)(x0 >> 70) : (unsigned)s1)) goto L0;
                if (budget != 0u) { budget -= 1u; u0 = fn0(r0.x, (0x80000000u - 1u), (unsigned)(w0 >> 29)); }
            }
            for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                r0.x = (p1 ? (0x10000u - -(unsigned)((short)3u > (signed char)a0[i0 & 3u])) : a0[u1 & 3u]);
            }
            if ((garr[u2 & 7u] + 2u)) goto L2;
            case 7u: ;
        }
        switch (0x80000000u & 7u) {
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                u2 = (r0.x % (0xf5df908eu | 1u));
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)0xf4a89ae0u < (int)a0[i0 & 3u]), (i2 - p1), (unsigned)s1); }
                v0 = ((unsigned)b0 + ((garr[u2 & 7u] << ((unsigned)c1 & 31u)) ^ fuel));
            }
            if ((6u >> ((a0[u1 & 3u] | v0) & 31u))) goto L3;
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)-(unsigned)((unsigned)l0 == (unsigned)(w0 >> 29)) << (u3 & 63u);
                u3 += (0x7fffffffu % ((unsigned)l0 | 1u));
                goto done;
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + ~((unsigned)h0 ^ (garr[i1 & 7u] + (unsigned)((int)0x29c08315u >= (int)u3))));
                    if (-((unsigned)f0 / (-(0xe1081bafu * 1u) | 1u))) goto done;
                }
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 4u: ;
                    case 3u: ;
                    v0 = (((*mp | 1u) ^ (unsigned)l0) + (unsigned)c1);
                }
                if ((unsigned)h0) continue;
            } while (i0++ < 4u && (unsigned)(p2 == 7u));
            *q0 = ((g1 >> ((unsigned)d0 & 31u)) >> ((unsigned)(short)((4u >> (i0 & 31u)) >> ((unsigned)(w0 >> 29) & 31u)) & 31u));
            h0 = (short)(unsigned)((int)g1 >= (int)(unsigned)(((unsigned)((int)g0 < (int)5u) % (0x3ef8e8b6u | 1u)) < garr[i1 & 7u]));
            *q0 = ((unsigned)f0 | 5u);
        }
        i0 = (unsigned)s1 & 15u;
    }
    c0 = (unsigned char)(unsigned)s1;
    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)(0x6fb04e99u && *q0) << (0xac46863au & 31u)), r0.x, (unsigned)c0); }
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)(signed char)(i0 & (unsigned)l0));
        e0 = e0 * 0.5L + (long double)(-(0x9e0aeacdu | -(unsigned)((int)0xf0648a8bu >= (int)(0x46f5b66au / ((unsigned)h0 | 1u)))) & 1023u);
        if ((unsigned)((unsigned)b0 || p2)) {
            if (budget != 0u) { budget -= 1u; u1 = fn0((6u + (unsigned)(x0 >> 70)), (unsigned)(x0 >> 70), ((0x8af9f2eeu | 5u) - r0.x)); }
            break; (void)(((unsigned)c1 * 9u));
            c1 = (signed char)(((0xb5559b4bu % (0x7fffffffu | 1u)) << (u0 & 31u)) >> (((unsigned)d0 & *mp) & 31u));
        }
        if ((0x6efae64du >> ((unsigned)((short)(unsigned)c1 > (signed char)(unsigned)d0) & 31u))) {
            if (*mp) {
                break; (void)(0x7fffffffu);
            }
        }
        c1 = (signed char)(unsigned)(garr[u2 & 7u] && 0xe9ba90b6u);
    }
    garr[0x48332c68u & 7u] = 0x4a54aa0bu;
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)w0);
        do { if (--fuel == 0u) goto done;
            { unsigned t2; double z2; if (((unsigned)((unsigned)(w0 >> 29) || 6u)) & 1u) { t2 = (unsigned)((2u ^ 0x3eeec52u) == (unsigned)h1); z2 = (double)((0xffffffffu) & 255u); } if (((unsigned)((unsigned)(w0 >> 29) || 6u)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                if ((unsigned)((int)(unsigned)c1 >= (int)i2)) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)e0, -(unsigned)(p0 && u3), (unsigned)(short)(1u & (unsigned)!((unsigned)h0 | (unsigned)(w0 >> 29)))); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((4u ^ (unsigned)x0), ((unsigned)l0 & ((unsigned)(w0 >> 29) | 6u)), (unsigned)(signed char)(unsigned)((int)i2 < (int)(unsigned)l0)); }
                    if ((unsigned)((u3 & u3) && i0)) break;
                    continue; (void)(2u);
                    l0 = (long)((unsigned long)l0 + ((unsigned)h0 + ((unsigned)(x0 >> 70) / ((unsigned)e0 | 1u))));
                } else {
                    *q0 += ((unsigned)h0 << ((a0[u1 & 3u] + 0x80000000u) & 31u));
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        w0 ^= (unsigned long long)(unsigned)c1 << ((0xa5b2d412u / ((unsigned)(x0 >> 70) | 1u)) & 63u);
                        u2 += ((unsigned)h1 >> ((((p1 / ((unsigned)(x0 >> 70) | 1u)) | fuel) / ((unsigned)d0 | 1u)) & 31u));
                    }
                }
                if (budget != 0u) { budget -= 1u; u1 = fn0((0x21bb8f09u * ((unsigned)w0 & 0x80000000u)), (unsigned)((short)u1 > (signed char)(0x10000u + 0u)), (unsigned)(unsigned char)(unsigned)(garr[u2 & 7u] || p2)); }
                switch (((unsigned)((unsigned)w0 && u2) << (5u & 31u)) & 7u) {
                    *mp = ((unsigned)c0 << (garr[i1 & 7u] & 31u));
                    case 6u: ;
                    if (budget != 0u) { budget -= 1u; u0 = fn0(((a0[i0 & 3u] >> (a0[i0 & 3u] & 31u)) << (garr[i1 & 7u] & 31u)), (0x79160c1bu / (u3 | 1u)), 0xdff28ce1u); }
                    if ((unsigned)l0) break;
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)((int)garr[u2 & 7u] >= (int)u0) > (signed char)-((unsigned)((short)0x80000000u > (signed char)a0[i0 & 3u]) | garr[i1 & 7u]));
                { unsigned t3; double z3; if (((g1 >> (0x7c62e2b4u & 31u))) & 1u) { t3 = (unsigned)!(0x74ffa4c9u / (0xcc8b4b35u | 1u)); z3 = (double)(((unsigned)((unsigned)l0 && (unsigned)w0)) & 255u); } if (((g1 >> (0x7c62e2b4u & 31u))) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)(0x37c1f0bau == u0) < (int)i2), (unsigned)((unsigned)f0 && (i1 & (unsigned)x0)), (unsigned)s1); }
                    if (garr[i1 & 7u]) break;
                    c0 = (unsigned char)(unsigned)l0;
                    if ((unsigned)((int)m0 >= (int)u0)) break;
                    if (((unsigned)((short)1u > (signed char)(unsigned)w0) / ((unsigned)l0 | 1u))) break;
                    if ((unsigned)h1) continue;
                }
                h0 = (short)((unsigned)h0 ? (unsigned)s1 : g1);
            }
            if ((*q0 - m0)) {
                if ((unsigned)((int)p1 >= (int)((unsigned)s0 >> ((unsigned)d0 & 31u)))) continue;
                { unsigned t4; double z4; if ((((unsigned)d0 ^ (unsigned)(w0 >> 29))) & 1u) { t4 = (unsigned)s0; z4 = (double)(((unsigned)(g0 == 0xbd089d39u)) & 255u); } if ((((unsigned)d0 ^ (unsigned)(w0 >> 29))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                    for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (((0x10000u / ((unsigned)e0 | 1u)) & v0)) {
                            g1 += (5u * 0xffffffffu);
                            if (budget != 0u) { budget -= 1u; u3 = fn0(2u, ((unsigned)(short)(unsigned)((unsigned)(w0 >> 29) && (unsigned)c1) * (unsigned)w0), (unsigned)(signed char)(unsigned)(p1 || (unsigned)((unsigned)e0 || (unsigned)h0))); }
                        }
                        { unsigned t5; double z5; if (((unsigned)((u0 + g0) && 0xa70b718au)) & 1u) { t5 = garr[u2 & 7u]; z5 = (double)((r0.x) & 255u); } if (((unsigned)((u0 + g0) && 0xa70b718au)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                            if ((unsigned)(p2 && (a0[u1 & 3u] << ((unsigned)h1 & 31u)))) break;
                            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)((9u ^ garr[u2 & 7u]) + (unsigned)e0);
                            e0 = e0 * 0.5L + (long double)((-(unsigned)((int)(unsigned)f0 < (int)(unsigned)c1) & (p2 + 0x7fffffffu)) & 1023u);
                            break; (void)((-(unsigned)((int)(unsigned)(x0 >> 70) >= (int)(unsigned)c0) << ((unsigned)s1 & 31u)));
                            break; (void)(garr[u2 & 7u]);
                            r0.y ^= (6u % (p0 | 1u));
                        }
                        if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)c0 << ((unsigned)b0 & 31u)), (unsigned)l0, -((u0 << (0x82928f04u & 31u)) % (g0 | 1u))); }
                        u1 = 0x362c40au;
                        switch ((unsigned)((short)(unsigned)(w0 >> 29) > (signed char)a0[i0 & 3u]) & 7u) {
                            u0 += (0x80000000u % ((unsigned)(unsigned char)(0x10000u % (((unsigned)(3u < 0xffffffffu) ^ (unsigned)x0) | 1u)) | 1u));
                        }
                    }
                    break; (void)(garr[u2 & 7u]);
                    g1 += (unsigned)((int)0x7fffffffu < (int)(g0 ? (unsigned)x0 : (u3 - 0x55f75416u)));
                    c1 = (signed char)(unsigned)(i1 < (p0 << (p0 & 31u)));
                    r0.y ^= 0x80000000u;
                }
            }
            g0 = g1;
            if ((unsigned)(fuel == (unsigned)(0x1f54f3f5u == (unsigned)c0))) break;
            if ((v0 | (r0.x >> (g1 & 31u)))) {
                u3 ^= (0x10000u << ((unsigned)(signed char)(0x495142c4u << ((unsigned)h0 & 31u)) & 31u));
                if (fuel < 8u) return 0xffffffffu;
                if ((unsigned)((unsigned)h0 < p2)) goto L0;
                h1 = (unsigned short)(h1 + ((unsigned)((int)u2 >= (int)0x89874d4cu) / (~(unsigned)(((unsigned)c1 + 0xe3263e75u) && (unsigned)w0) | 1u)));
                { unsigned t6; double z6; if ((garr[i1 & 7u]) & 1u) { t6 = (2u << (g1 & 31u)); z6 = (double)((((unsigned)(short)(unsigned)(a0[u1 & 3u] < (unsigned)h1) - *q0)) & 255u); } if ((garr[i1 & 7u]) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                    if ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)u3)) continue;
                    l0 = (long)((unsigned long)l0 + (unsigned)((int)0x216ead9cu >= (int)(unsigned)h1));
                    a0[a0[u1 & 3u] & 3u] = (unsigned)(((unsigned)c0 | 4u) && ((unsigned)(unsigned char)(unsigned)(0x2943b4c2u < *mp) / (garr[u2 & 7u] | 1u)));
                    c0 = (unsigned char)(*mp ^ p2);
                    b0 = ((unsigned)l0 * (unsigned)c1) != 0u;
                }
                v0 = (unsigned)(w0 >> 29);
            }
            c0 = (unsigned char)(unsigned)(g1 || (r0.y / (i1 | 1u)));
        } while (i1++ < 7u && 0x5e0987bau);
    }
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (p1) break;
        b0 = (m0 ^ r0.y) != 0u;
        break; (void)((unsigned)((unsigned)(w0 >> 29) < u1));
    }
    if ((unsigned)(u3 == 6u)) {
        if ((unsigned)(garr[u2 & 7u] == i2)) goto done;
        if ((unsigned)(short)(0x7fffffffu & i1)) goto L4;
    } else {
        r0.x = (unsigned)((unsigned)c1 < (unsigned)!(((unsigned)h0 << (6u & 31u)) | 4u));
    }
    if ((unsigned)((int)6u >= (int)a0[i0 & 3u])) goto L0;
    s0 = (int)(((unsigned)h0 % (0x1af507b3u | 1u)) + (u2 + (unsigned)((short)0xe0df4938u > (signed char)(unsigned)s1)));
    do { if (--fuel == 0u) goto done;
        break; (void)(garr[u2 & 7u]);
        b0 = (unsigned)(0xffffffffu == i0) != 0u;
        i0 = r0.y & 15u;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)((garr[u2 & 7u] >> (i1 & 31u)) + 0x10000u), g0, (unsigned)((unsigned)w0 < 9u)); }
        { unsigned t7; double z7; if (((a0[i0 & 3u] & 0x7fffffffu)) & 1u) { t7 = (unsigned)x0; z7 = (double)(((unsigned)f0) & 255u); } if (((a0[i0 & 3u] & 0x7fffffffu)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
            if (budget != 0u) { budget -= 1u; u3 = fn0((p0 * p1), ((unsigned)c0 & g1), (0x10000u & (unsigned)(0xd2458ce8u == p1))); }
            do { if (--fuel == 0u) goto done;
                x0 = x0 * 0x100000001b3ull + (unsigned)(short)((unsigned)((int)(unsigned)(fuel && (unsigned)h0) >= (int)8u) << ((r0.x >> ((unsigned)h0 & 31u)) & 31u));
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (-((g1 ^ a0[i0 & 3u]) * (unsigned)h0)) break;
                    if (r0.x) {
                        m0 ^= (unsigned)(short)(unsigned)((unsigned)(w0 >> 29) == (unsigned)(unsigned char)(unsigned)(0xffffffffu && (unsigned)c0));
                    } else {
                        c0 = (unsigned char)(unsigned)(signed char)(unsigned)((short)(unsigned)((unsigned)h0 == r0.y) > (signed char)(unsigned)e0);
                    }
                }
                { unsigned t8; double z8; if (((unsigned)d0) & 1u) { t8 = (unsigned)((int)r0.x < (int)(0xba7d2077u * m0)); z8 = (double)((0xc4496333u) & 255u); } if (((unsigned)d0) & 1u) { u3 += t8; d0 = d0 * 0.5 + z8; }
                    for (;;) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)(unsigned)((short)0x55fdc15du > (signed char)(*mp >> (r0.x & 31u))), (1u + (u1 << (i2 & 31u))), (i2 + (unsigned)((short)(unsigned)x0 > (signed char)u1))); }
                    }
                    if ((unsigned)(unsigned char)(a0[i0 & 3u] | (unsigned)w0)) continue;
                    if (p1) goto L0;
                    if ((unsigned)((unsigned)h0 && 0xffffffffu)) continue;
                    u0 = (unsigned)(short)(unsigned)((int)(unsigned)((int)(unsigned)w0 >= (int)g1) >= (int)(unsigned)d0);
                }
            } while (i1++ < 5u && (unsigned)(short)((unsigned)w0 + (unsigned)((int)i0 < (int)(unsigned)s1)));
            break; (void)(g1);
        }
    } while (i0++ < 5u && (unsigned)(signed char)(0xffffffffu | u1));
    e0 = e0 * 0.5L + (long double)(((unsigned)(short)(0x80000000u + 9u) << ((unsigned)!(unsigned)((short)0xaf2d6073u > (signed char)0xd089c6afu) & 31u)) & 1023u);
    c0 = (unsigned char)(unsigned)(0xc40930bu == (unsigned)(u1 && ((unsigned)d0 >> (v0 & 31u))));
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)4u < (int)(unsigned)s0), (v0 / ((unsigned)x0 | 1u)), (unsigned)c1); }
    s0 = (int)(unsigned)(short)((unsigned)(signed char)((unsigned)d0 * 0xe0492c4eu) ^ (u1 << (0x6533d4bfu & 31u)));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        m0 ^= (unsigned)(short)(-(unsigned)(u2 < ((unsigned)l0 - 0x80000000u)) % (r0.x | 1u));
        if ((g0 | i0)) break;
        continue; (void)((unsigned)x0);
        b0 = (unsigned)(r0.y < *q0) != 0u;
        s1 = (int)((unsigned)s1 + (unsigned)((int)(3u + *mp) < (int)(*q0 | (unsigned)(u2 && (unsigned)s0))));
    }
    w0 ^= (unsigned long long)8u << (a0[i0 & 3u] & 63u);
    if (budget != 0u) { budget -= 1u; u2 = fn0((i2 & (u3 & p2)), ((unsigned)c0 / (((unsigned)h0 ^ p2) | 1u)), (unsigned)((fuel / (fuel | 1u)) || 0xb467a81bu)); }
    { unsigned t9; double z9; if (((unsigned)((short)(unsigned)(short)(unsigned)(6u == (unsigned)(x0 >> 70)) > (signed char)i1)) & 1u) { t9 = ((g1 << ((unsigned)l0 & 31u)) << ((unsigned)x0 & 31u)); z9 = (double)(((u2 * p0)) & 255u); } if (((unsigned)((short)(unsigned)(short)(unsigned)(6u == (unsigned)(x0 >> 70)) > (signed char)i1)) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
        g0 = (m0 ^ ((unsigned)(x0 >> 70) * 0xffffffffu));
        if (0x544b18c3u) {
            if (-(garr[u2 & 7u] / ((fuel - *q0) | 1u))) goto L4;
            if (budget != 0u) { budget -= 1u; u3 = fn0(r0.x, 0xacd36156u, (unsigned)s1); }
            goto L4;
            u3 ^= (unsigned)((short)(unsigned)h0 > (signed char)garr[u2 & 7u]);
        }
        { unsigned t10; double z10; if (((0x80000000u % (0xffffffffu | 1u))) & 1u) { t10 = (v0 & ((unsigned)(x0 >> 70) % (garr[u2 & 7u] | 1u))); z10 = (double)(((unsigned)((int)(unsigned)h0 >= (int)(unsigned)!(fuel | g1))) & 255u); } if (((0x80000000u % (0xffffffffu | 1u))) & 1u) { u1 += t10; d0 = d0 * 0.5 + z10; }
            w0 = w0 * 6364136223846793005ull + (((unsigned)(p1 || (fuel >> (g0 & 31u))) & u1) | (unsigned)l0);
        }
    }
    u0 += (unsigned)((unsigned)w0 == (0xffffffffu + (unsigned)h0));
    if (budget != 0u) { budget -= 1u; u1 = fn0(*q0, 0u, ((unsigned)c0 | (unsigned)c1)); }
    r0.y ^= 0x7fffffffu;
    *q0 = (unsigned)((int)(unsigned)!(i0 - garr[i1 & 7u]) < (int)i2);
    while (i0++ < 5u && (((unsigned)d0 << (8u & 31u)) << (0xf6f15006u & 31u))) { if (--fuel == 0u) goto done;
        if (fuel < 8u) return (*q0 / ((fuel / ((unsigned)((int)u2 < (int)(unsigned)l0) | 1u)) | 1u));
        goto L1;
        break; (void)((garr[i1 & 7u] & (unsigned)((short)0x10000u > (signed char)garr[u2 & 7u])));
        w0 = w0 * 6364136223846793005ull + ((u2 % (0x772954dfu | 1u)) / (2u | 1u));
        switch ((r0.x % (0x10000u | 1u)) & 7u) {
            while (i1++ < 7u && ((unsigned)d0 ? p1 : (unsigned)h1)) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(short)(unsigned)((int)((unsigned)w0 % (u1 | 1u)) < (int)g0), 3u, a0[i0 & 3u]); }
                h1 = (unsigned short)(h1 + 9u);
                { unsigned t11; double z11; if (((unsigned)((unsigned)(unsigned char)(garr[i1 & 7u] - 0xffffffffu) || 0u)) & 1u) { t11 = m0; z11 = (double)((((unsigned)(0xffffffffu == 8u) * (unsigned)h0)) & 255u); } if (((unsigned)((unsigned)(unsigned char)(garr[i1 & 7u] - 0xffffffffu) || 0u)) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
                    w0 ^= (unsigned long long)(unsigned)e0 << ((0x7fffffffu >> ((garr[i1 & 7u] ^ (unsigned)(unsigned char)(unsigned)(fuel < (unsigned)e0)) & 31u)) & 63u);
                    case 5u: ;
                    if (u3 == 7u) return (unsigned)((unsigned)c1 < (unsigned)((short)0x7fffffffu > (signed char)u3));
                    u0 = (v0 << ((unsigned)(x0 >> 70) & 31u));
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        switch ((unsigned)((unsigned)!(r0.x * (unsigned)h0) && 0xbbe9ef3u) & 7u) {
                            continue; (void)((p1 / (garr[i1 & 7u] | 1u)));
                        }
                        if (budget != 0u) { budget -= 1u; u0 = fn0((0x15e5bd98u + i0), ((unsigned)((unsigned)x0 == 9u) & r0.x), (unsigned)(v0 < (unsigned)((int)u1 < (int)0u))); }
                        g0 = ~(unsigned)(((unsigned)f0 - 3u) && 1u);
                        l0 = (long)((unsigned long)l0 + i1);
                        f0 = f0 * 0.5f + (float)(((unsigned)c0 * garr[u2 & 7u]) & 255u);
                    }
                }
            }
            h1 = (unsigned short)(h1 + (unsigned)(((unsigned)s1 % ((p2 - 6u) | 1u)) < (u3 % (0x7fffffffu | 1u))));
            u3 += (unsigned)l0;
            case 6u: ;
        }
    }
    do { if (--fuel == 0u) goto done;
        break; (void)(p0);
        if ((0x80000000u ? 0x35c1ded6u : 3u)) break;
        if ((*mp - 0x2edc261u)) break;
        break; (void)((unsigned)!((unsigned)s0 >> ((unsigned)c1 & 31u)));
    } while (i0++ < 6u && ((unsigned)s0 | u3));
    goto L4;
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)((unsigned)e0 % (*mp | 1u)) >= (int)a0[i0 & 3u]), u3, (unsigned)c0); }
    if ((unsigned)(u3 < (0x7ef71447u >> (u3 & 31u)))) goto L0;
    while (i0++ < 4u && a0[u1 & 3u]) { if (--fuel == 0u) goto done;
        if ((a0[u1 & 3u] & (p1 | 4u))) break;
        if (budget != 0u) { budget -= 1u; u2 = fn0((0x83c78b36u << (0x80000000u & 31u)), (unsigned)((unsigned)(i0 < (unsigned)l0) && g1), (unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)(unsigned char)(u1 + a0[u1 & 3u]))); }
        if ((a0[i0 & 3u] << (r0.y & 31u))) {
            if ((u0 * (g1 - fuel))) {
                if (budget != 0u) { budget -= 1u; u1 = fn0((0x47b2f2edu >> ((unsigned)h0 & 31u)), ((unsigned)h0 ^ (garr[u2 & 7u] - (unsigned)w0)), (unsigned)((unsigned)(short)(2u / (4u | 1u)) || 0x6c50116eu)); }
                *mp = ((unsigned)((int)0x2d12cdu >= (int)5u) >> ((unsigned)h0 & 31u));
                m0 ^= (unsigned)(unsigned char)(unsigned)((*q0 | (unsigned)s1) && (v0 ^ r0.y));
                { unsigned t12; double z12; if ((((unsigned)(unsigned char)(unsigned)(u0 == garr[u2 & 7u]) % (0x10000u | 1u))) & 1u) { t12 = (garr[u2 & 7u] >> (((unsigned)h1 % (i2 | 1u)) & 31u)); z12 = (double)(((0x4b71b504u - (unsigned)(short)(i0 >> (r0.y & 31u)))) & 255u); } if ((((unsigned)(unsigned char)(unsigned)(u0 == garr[u2 & 7u]) % (0x10000u | 1u))) & 1u) { u0 += t12; d0 = d0 * 0.5 + z12; }
                    m0 ^= 5u;
                    i1 = (0x6b7c202fu / (9u | 1u)) & 15u;
                }
                if ((unsigned)((unsigned)(x0 >> 70) && (unsigned)s0)) break;
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(m0 && (unsigned)e0), (u0 / ((unsigned)(0x10000u == u0) | 1u)), ((unsigned)e0 << (p0 & 31u))); }
            } else {
                goto L0;
            }
        } else {
            if (fuel < 8u) return (0xfe81a012u / ((unsigned)h1 | 1u));
            do { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (0x7fffffffu * (1u << ((a0[i0 & 3u] - 0x10000u) & 31u))));
                *mp = u3;
                q0 = &garr[(*q0 % ((unsigned)f0 | 1u)) & 7u];
                s0 = (int)~((unsigned)d0 << (0u & 31u));
                r0.y ^= (unsigned)(0x10000u == ((unsigned)((unsigned)s0 == p1) / (garr[u2 & 7u] | 1u)));
                i0 = (unsigned)(unsigned char)((a0[u1 & 3u] % (g0 | 1u)) >> ((unsigned)((int)0x804710afu < (int)(unsigned)b0) & 31u)) & 15u;
            } while (i1++ < 3u && (r0.y + (8u / (p0 | 1u))));
            if ((unsigned)((0x65945648u >> ((unsigned)(x0 >> 70) & 31u)) < i1)) break;
            u0 = (unsigned)((int)((unsigned)d0 - garr[u2 & 7u]) >= (int)(unsigned)!(unsigned)((int)garr[i1 & 7u] < (int)1u));
        }
        if (g1) {
            s1 = (int)((unsigned)s1 + (unsigned)w0);
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((int)0x7fffffffu >= (int)i0)) break;
                    u1 ^= 0x7fffffffu;
                    if ((p0 & (unsigned)((short)(unsigned)c0 > (signed char)(unsigned)e0))) goto L3;
                    g1 += (unsigned)c1;
                } while (i2++ < 5u && (unsigned)w0);
                continue; (void)(((unsigned)(g1 || fuel) >> ((unsigned)d0 & 31u)));
                if (budget != 0u) { budget -= 1u; u0 = fn0(r0.x, (0x10000u % (0x4d1ee732u | 1u)), (*q0 + (garr[u2 & 7u] | (unsigned)l0))); }
                if (budget != 0u) { budget -= 1u; u1 = fn0((*mp - ((unsigned)s1 / (0x80000000u | 1u))), ((unsigned)((int)0xffffffffu < (int)(unsigned)(w0 >> 29)) - u3), (0xffffffffu | (g0 % ((unsigned)b0 | 1u)))); }
                if ((unsigned)(short)((unsigned)((short)r0.x > (signed char)9u) * 0u)) break;
            }
            if ((unsigned)s1) continue;
            i0 = ((unsigned)(g1 && 1u) + ((unsigned)(unsigned char)(p1 & garr[i1 & 7u]) - v0)) & 15u;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(7u < i0), ((0xc3458c3du ^ p1) % (i2 | 1u)), (*mp & (unsigned)((int)0x3e29658eu >= (int)*mp))); }
        if (budget != 0u) { budget -= 1u; u0 = fn0(((i2 << ((unsigned)s0 & 31u)) | m0), (unsigned)((short)0x1a4d40deu > (signed char)0xffffffffu), ~(2u & 0xffffffffu)); }
    }
    a0[i2 & 3u] = (unsigned)((unsigned)c1 && *q0);
    h1 = (unsigned short)(h1 + (9u | (unsigned)s0));
    w0 = w0 * 6364136223846793005ull + (unsigned)((int)0xffffffffu >= (int)(*mp >> ((unsigned)b0 & 31u)));
    if (fuel < 8u) return (unsigned)(p0 == (unsigned)((short)~(unsigned)(garr[u2 & 7u] && (unsigned)l0) > (signed char)(unsigned)c1));
    { unsigned t13; double z13; if (((unsigned)!((unsigned)b0 - r0.x)) & 1u) { t13 = 4u; z13 = (double)(((unsigned)l0) & 255u); } if (((unsigned)!((unsigned)b0 - r0.x)) & 1u) { u2 += t13; d0 = d0 * 0.5 + z13; }
        garr[(a0[i0 & 3u] ^ (unsigned)b0) & 7u] = ((7u << (g1 & 31u)) << ((unsigned)x0 & 31u));
        q0 = &garr[-(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)e0) & 7u];
        v0 = (unsigned)((int)(fuel >> (0x80000000u & 31u)) >= (int)(i0 % (p2 | 1u)));
    }
    if (budget != 0u) { budget -= 1u; u0 = fn0((a0[u1 & 3u] ? (unsigned)w0 : g0), ~(unsigned)((int)0x53e8e336u < (int)((unsigned)b0 + 0xf2c773d8u)), u0); }
    while ((unsigned)b0) { if (--fuel == 0u) goto done;
        l0 = (long)((unsigned long)l0 + (((unsigned)e0 * (unsigned)c1) >> (0x10000u & 31u)));
        c0 = (unsigned char)((unsigned)((unsigned)(x0 >> 70) || garr[u2 & 7u]) * 0xffffffffu);
        i0 = 0x62851433u & 15u;
        e0 = e0 * 0.5L + (long double)(i0 & 1023u);
        if ((0x80000000u / (0x4a8c9ec5u | 1u))) break;
        v0 = (5u + ((unsigned)h1 >> (u2 & 31u)));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)0x10000u >= (int)p2), ~(unsigned)((short)u2 > (signed char)(unsigned)(short)(*mp / (garr[u2 & 7u] | 1u))), (unsigned)(short)((i0 * (unsigned)(x0 >> 70)) | (unsigned)h1)); }
    if ((i0 - (m0 * a0[i0 & 3u]))) {
        if ((unsigned)(g0 || (unsigned)f0)) goto L1;
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)!(5u - (i2 ^ (unsigned)(w0 >> 29)))) break;
            q0 = &garr[(unsigned)(r0.x || (((unsigned)s1 ? 6u : 0xf296fff4u) * (unsigned)c0)) & 7u];
            break; (void)((unsigned)(unsigned char)((unsigned)c0 << (p0 & 31u)));
        }
        *mp = ((unsigned)((int)0x80000000u < (int)(unsigned)l0) % (((unsigned)((short)(unsigned)s0 > (signed char)(unsigned)c0) / ((unsigned)c1 | 1u)) | 1u));
        do { if (--fuel == 0u) goto done;
            switch ((unsigned)h1 & 7u) {
                w0 = w0 * 6364136223846793005ull + (i1 | (0x20fe6363u ^ (unsigned)w0));
                while (i1++ < 7u && (unsigned)(g1 == (unsigned)c0)) { if (--fuel == 0u) goto done;
                    b0 = ((unsigned)(unsigned char)(0x10000u - (unsigned)(g0 && (unsigned)c1)) ^ i2) != 0u;
                    x0 = x0 * 0x100000001b3ull + 9u;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)!(1u + fuel) * i0), (unsigned)!(i1 / (0xffffffffu | 1u)), (u3 << (u0 & 31u))); }
                    { unsigned t14; double z14; if ((m0) & 1u) { t14 = ((unsigned)(w0 >> 29) + 1u); z14 = (double)((((unsigned)d0 << (0xc90cee37u & 31u))) & 255u); } if ((m0) & 1u) { u2 += t14; d0 = d0 * 0.5 + z14; }
                        u1 += ((unsigned)(signed char)((unsigned)b0 ^ (unsigned)l0) % ((unsigned)((short)(0x80000000u - *q0) > (signed char)p2) | 1u));
                        s1 = (int)((unsigned)s1 + (*q0 ^ (garr[i1 & 7u] ? (unsigned)(x0 >> 70) : (unsigned)w0)));
                        x0 = x0 * 0x100000001b3ull + (1u % ((unsigned)((int)(unsigned)(0x8a6fe38eu == 0x84d1cb2au) < (int)(unsigned)l0) | 1u));
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((short)a0[u1 & 3u] > (signed char)0xaef20fc8u), (unsigned)(signed char)((unsigned)(*mp || i1) << ((unsigned)d0 & 31u)), ((unsigned)w0 / ((unsigned)e0 | 1u))); }
                        s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)(short)(unsigned)((int)(unsigned)(0x80000000u < (unsigned)c0) < (int)a0[u1 & 3u]) < (int)(unsigned)(u1 < g0)));
                    }
                }
                *mp = ((unsigned)(0xffffffffu < 0x7a777d5eu) ? u3 : (unsigned)d0);
                if ((unsigned)((unsigned)c0 == (unsigned)((int)(unsigned)w0 < (int)m0))) break;
                u0 = u0 * 0x9e3779b1u + fuel;
            }
        } while (i0++ < 2u && (unsigned)((unsigned)e0 < (unsigned)x0));
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((4u ^ (unsigned)h1) & 7u) {
                case 1u: ;
            }
            *q0 = ~(unsigned)((int)(unsigned)c1 >= (int)(unsigned)((int)(unsigned)((int)u0 < (int)-(v0 % ((unsigned)(x0 >> 70) | 1u))) >= (int)u2));
            if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)h0 % (a0[u1 & 3u] | 1u)), (unsigned)((unsigned)f0 || 1u), ((unsigned)(signed char)(unsigned)(p2 == p0) & (unsigned)f0)); }
            if ((-((unsigned)x0 ^ i2) | g1)) break;
            if ((0x80000000u >> (u2 & 31u))) break;
        }
    }
    g0 = (unsigned)s1;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    r0.y ^= g1;
    { unsigned t0; double z0; if (((((unsigned)s1 + 0xd8db4e5cu) / (u2 | 1u))) & 1u) { t0 = (unsigned)(u3 < 0x80000000u); z0 = (double)((p1) & 255u); } if (((((unsigned)s1 + 0xd8db4e5cu) / (u2 | 1u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        { unsigned t1; double z1; if (((unsigned)(signed char)(u1 & (unsigned)d0)) & 1u) { t1 = (p1 ^ (unsigned)(a0[i0 & 3u] == u2)); z1 = (double)(((unsigned)((short)0x801d17dbu > (signed char)(unsigned)(w0 >> 29))) & 255u); } if (((unsigned)(signed char)(u1 & (unsigned)d0)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
            L0: if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)h0 >= (int)(p1 >> (u1 & 31u)))) goto done;
            L1: if (--fuel == 0u) goto done;
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0(0u, fuel, ((unsigned)(v0 < (unsigned)h1) ^ u1)); }
        while ((r0.x / (m0 | 1u))) { if (--fuel == 0u) goto done;
            u0 = r0.x;
            while (i1++ < 2u && ((unsigned)s0 & g0)) { if (--fuel == 0u) goto done;
                i0 = 0x10000u & 15u;
                if ((unsigned)((short)0xffffffffu > (signed char)(unsigned)l0)) break;
                L2: if (--fuel == 0u) goto done;
            }
            *mp = (unsigned)(v0 == 8u);
            g0 = -((fuel << (v0 & 31u)) + a0[i0 & 3u]);
        }
        f0 = f0 * 0.5f + (float)((0x78a047d7u ^ (0x5cd528bcu + (6u << (0xc144d986u & 31u)))) & 255u);
        h0 = (short)-(unsigned)((unsigned)((int)m0 >= (int)(unsigned)l0) == ((unsigned)d0 / ((9u - (unsigned)h0) | 1u)));
    }
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0x7fffffffu) break;
        { unsigned t2; double z2; if ((4u) & 1u) { t2 = 0xef7bbf22u; z2 = (double)((0u) & 255u); } if ((4u) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
            if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)(5u && 2u) & (unsigned)l0), (unsigned)((unsigned)s1 < (0u / ((unsigned)d0 | 1u))), 0x7fffffffu); }
            e0 = e0 * 0.5L + (long double)(0x526926a5u & 1023u);
            e0 = e0 * 0.5L + (long double)(a0[u1 & 3u] & 1023u);
        }
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0(g1, ((unsigned)d0 & g1), ((unsigned)s0 | 0x33b0277eu)); }
            L3: if (--fuel == 0u) goto done;
            for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t3; double z3; if ((m0) & 1u) { t3 = (a0[i0 & 3u] * -(unsigned)(v0 && m0)); z3 = (double)(((unsigned)(signed char)((unsigned)h0 ^ g1)) & 255u); } if ((m0) & 1u) { u0 += t3; d0 = d0 * 0.5 + z3; }
                    goto L2;
                    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(w0 >> 29), ((i1 - i2) ^ (unsigned)s1), (unsigned)(signed char)(unsigned)(0x10000u < i2)); }
                    }
                    r0.x = (a0[i0 & 3u] << ((unsigned)(0x7fffffffu || u0) & 31u));
                    x0 = x0 * 0x100000001b3ull + (((unsigned)h1 ^ (unsigned)f0) & (unsigned)(unsigned char)(unsigned)((short)(unsigned)d0 > (signed char)(5u / (p1 | 1u))));
                    d0 = d0 * 0.5 + (double)((2u - ((unsigned)((int)(unsigned)h1 < (int)(unsigned)(x0 >> 70)) ^ 0xe3571859u)) & 1023u);
                    if (((0xffffffffu % (*q0 | 1u)) + 0xc990ac0cu)) goto L1;
                }
                c0 = (unsigned char)(((unsigned)(8u < (unsigned)b0) / (0x972739b7u | 1u)) + (unsigned)h1);
                l0 = (long)((unsigned long)l0 + ((unsigned)(x0 >> 70) / ((8u * 9u) | 1u)));
                if ((0x7fffffffu ^ 0x2eac5e97u)) break;
                h1 = (unsigned short)(h1 + (unsigned)(0xffffffffu == (unsigned)((short)(p2 >> (u3 & 31u)) > (signed char)0x4f5d3d19u)));
            }
        }
    }
    c1 = (signed char)(unsigned)(g0 < (3u & i1));
    L4: if (--fuel == 0u) goto done;
    if (u3) goto L3;
    if ((r0.y >> ((unsigned)(u0 < 0x10000u) & 31u))) goto L1;
    *mp = (unsigned)(signed char)(((unsigned)s0 << (((unsigned)b0 % (garr[i1 & 7u] | 1u)) & 31u)) / ((unsigned)((int)8u < (int)i1) | 1u));
    w0 ^= (unsigned long long)0x1ae21537u << (garr[u2 & 7u] & 63u);
    *q0 += (3u << ((unsigned)(x0 >> 70) & 31u));
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((a0[u1 & 3u] * garr[i1 & 7u]) ^ p2)) break;
        s0 = (int)(unsigned)(((unsigned)(w0 >> 29) + garr[i1 & 7u]) == p0);
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(unsigned char)((unsigned)((int)(unsigned)l0 >= (int)(unsigned)l0) / ((unsigned)x0 | 1u)), (unsigned)e0, -((unsigned)!(unsigned)((short)(unsigned)b0 > (signed char)i1) / (0x80000000u | 1u))); }
        if ((g0 >> (0x93c0fb55u & 31u))) goto L4;
    }
    if (9u) goto L0;
    u2 += (unsigned)(((unsigned)(p2 || (unsigned)(w0 >> 29)) * 0x24a88654u) && (unsigned)((int)i1 < (int)u2));
    if (((unsigned)((short)u2 > (signed char)g1) * i2)) goto L0;
    while (i0++ < 5u && (a0[i0 & 3u] >> ((unsigned)x0 & 31u))) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && v0) { if (--fuel == 0u) goto done;
            b0 = (unsigned)((int)~(*q0 | u2) < (int)(unsigned)s0) != 0u;
            if ((unsigned)(short)(r0.y % ((a0[i0 & 3u] << (g1 & 31u)) | 1u))) break;
            do { if (--fuel == 0u) goto done;
                if ((5u >> ((u0 | *q0) & 31u))) {
                    *q0 = (0x6175cab6u >> (0xfc0637eeu & 31u));
                    if ((unsigned)(signed char)((unsigned)h0 >> (*q0 & 31u))) {
                        if ((unsigned)x0) {
                            e0 = e0 * 0.5L + (long double)((garr[u2 & 7u] + (0xd27cd25au ^ (unsigned)((int)u1 >= (int)0x6d08a169u))) & 1023u);
                        }
                        if (i1) goto L2;
                        u3 += ((unsigned)((int)5u >= (int)(unsigned)l0) >> ((unsigned)(w0 >> 29) & 31u));
                    } else {
                        h1 = (unsigned short)(h1 + (0xffffffffu ^ (unsigned)f0));
                        if ((u2 & i1)) {
                            if ((unsigned)((unsigned)((int)u0 >= (int)0x98dcb484u) && u2)) break;
                            goto L2;
                            break; (void)((6u << (u2 & 31u)));
                            if ((unsigned)((unsigned)(short)((unsigned)d0 - 2u) && 0x7fffffffu)) break;
                            *q0 = ((unsigned)((int)(unsigned)s1 < (int)(unsigned)s0) >> ((unsigned)!((unsigned)((unsigned)f0 || p0) / ((unsigned)h1 | 1u)) & 31u));
                            d0 = d0 * 0.5 + (double)((((unsigned)s1 & garr[u2 & 7u]) - 6u) & 1023u);
                        } else {
                            if ((unsigned)x0) break;
                            if ((unsigned)((unsigned)(x0 >> 70) || (unsigned)s1)) break;
                            *q0 += ((unsigned)((u3 + r0.x) || 0x80000000u) & 0x35a0a22eu);
                        }
                        s0 = (int)((unsigned)(w0 >> 29) ^ (unsigned)(unsigned char)(0x8bebdc6au / ((fuel ^ *q0) | 1u)));
                    }
                    { unsigned t4; double z4; if ((r0.y) & 1u) { t4 = (unsigned)((int)i0 >= (int)0x9a49f938u); z4 = (double)(((unsigned)((unsigned)c1 == i1)) & 255u); } if ((r0.y) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                        q0 = &garr[((5u >> ((unsigned)c0 & 31u)) << ((5u ? 7u : g1) & 31u)) & 7u];
                    }
                    q0 = &garr[(~((unsigned)w0 + (unsigned)f0) * 4u) & 7u];
                } else {
                    x0 = x0 * 0x100000001b3ull + ((garr[i1 & 7u] ^ r0.y) ^ (unsigned)h1);
                    break; (void)((unsigned)((int)3u >= (int)(r0.y << (garr[u2 & 7u] & 31u))));
                }
            } while (i2++ < 2u && (unsigned)((int)4u >= (int)(unsigned)(x0 >> 70)));
            break; (void)((0x821b22cbu << (v0 & 31u)));
        }
        u0 ^= ((0x33236918u << (*mp & 31u)) >> ((unsigned)l0 & 31u));
        i2 = 1u & 15u;
        g0 = (unsigned)s1;
    }
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)(unsigned)((unsigned)d0 == 0x4e13f399u) < (int)0xa586b6b8u), ((0x4b45f0fau ^ u2) | i1), ((unsigned)(w0 >> 29) | (unsigned)b0)); }
    if ((0x10000u ? 0xa5945cc7u : garr[i1 & 7u])) goto L0;
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        u1 += (unsigned)((short)i1 > (signed char)0x10000u);
        if ((unsigned)(signed char)((unsigned)h1 - (unsigned)((unsigned)(w0 >> 29) || g0))) continue;
        do { if (--fuel == 0u) goto done;
            *q0 += (((unsigned)h1 * (unsigned)(garr[u2 & 7u] && *q0)) ^ 4u);
            break; (void)(((3u << ((unsigned)w0 & 31u)) ^ garr[u2 & 7u]));
            b0 = (unsigned)((short)0xd80c90d5u > (signed char)(unsigned)((unsigned)(x0 >> 70) || (9u + m0))) != 0u;
            e0 = e0 * 0.5L + (long double)(8u & 1023u);
            break; (void)((unsigned)(short)(unsigned)((int)(unsigned)((short)(unsigned)s0 > (signed char)m0) >= (int)u0));
            u1 += ((unsigned)(u0 && (unsigned)((int)0xffffffffu >= (int)(unsigned)h0)) & 0u);
        } while (i1++ < 7u && (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(fuel && (unsigned)c0)));
    }
    i0 = ((unsigned)((short)(r0.y >> (0xffffffffu & 31u)) > (signed char)(unsigned)w0) - -(1u << (r0.y & 31u))) & 15u;
    do { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (-(u2 ? 5u : (7u * *q0)) + (unsigned)(w0 >> 29));
        continue; (void)((*q0 ? g1 : 0xffffffffu));
        break; (void)((unsigned)(short)(unsigned)((unsigned)c0 && (unsigned)(x0 >> 70)));
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)(i0 * (unsigned)((short)i0 > (signed char)~((0x10000u >> ((unsigned)h1 & 31u)) | i0)));
            if (m0) break;
            while (((*q0 >> (*q0 & 31u)) - (unsigned)f0)) { if (--fuel == 0u) goto done;
                g1 += (unsigned)((short)(0xadbe7878u ? u3 : (unsigned)((short)garr[u2 & 7u] > (signed char)(unsigned)s0)) > (signed char)0x80000000u);
                a0[(a0[i0 & 3u] / ((unsigned)h1 | 1u)) & 3u] = -((g1 / (u0 | 1u)) | 0x581312c4u);
            }
            garr[0xf7d0e5b4u & 7u] = ((unsigned)((int)p2 < (int)garr[u2 & 7u]) << (*mp & 31u));
            if ((unsigned)((u0 - a0[i0 & 3u]) == 0x4cbee248u)) break;
        }
    } while (i0++ < 3u && (0xd74cea25u ^ *mp));
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 ^= (unsigned long long)(9u | u1) << ((unsigned)(-(((unsigned)c1 - 0xffffffffu) / (0xfb5ff706u | 1u)) || 0x9d61fc97u) & 63u);
        break; (void)(0x10000u);
    }
    u2 += (0u ^ ((unsigned)w0 ? 9u : 0xffffffffu));
    garr[0x94668557u & 7u] = (unsigned)((unsigned)h1 && i0);
    w0 ^= (unsigned long long)r0.y << (((g0 ^ (a0[u1 & 3u] + 0u)) ? 8u : 0x7fffffffu) & 63u);
    e0 = e0 * 0.5L + (long double)((i1 | (unsigned)h0) & 1023u);
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(a0[i0 & 3u] < 6u), (u0 % (3u | 1u)), 2u); }
    goto L2;
    if (budget != 0u) { budget -= 1u; u2 = fn1(((g0 << (p0 & 31u)) * g0), ((v0 + r0.y) >> (u1 & 31u)), (unsigned)(p2 < (unsigned)(unsigned char)(a0[i0 & 3u] + 0x37ddeaf6u))); }
    goto L1;
    w0 = w0 * 6364136223846793005ull + ((unsigned)!(0x10000u % ((unsigned)f0 | 1u)) % ((v0 & (unsigned)f0) | 1u));
    g0 = ((unsigned)(short)(0x7fffffffu * (p0 / (0xb4cd3bd1u | 1u))) + 0u);
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        s0 = (int)((unsigned)((unsigned)f0 < ((unsigned)l0 / (u1 | 1u))) >> ((r0.y - i1) & 31u));
        *q0 = (unsigned)((int)0u < (int)(r0.x >> (a0[i0 & 3u] & 31u)));
        if ((unsigned)s1) break;
        if ((unsigned)(3u < a0[i0 & 3u])) {
            b0 = (unsigned)((int)*q0 < (int)(unsigned)((unsigned)h1 || garr[i1 & 7u])) != 0u;
            c0 = (unsigned char)(g0 ? (unsigned)((int)v0 < (int)0u) : 8u);
            b0 = -(unsigned)(0u < a0[i0 & 3u]) != 0u;
        } else {
            d0 = d0 * 0.5 + (double)(((unsigned)h1 % ((unsigned)l0 | 1u)) & 1023u);
            for (;;) { if (--fuel == 0u) goto done;
                if ((unsigned)(r0.y && *mp)) goto L0;
            }
        }
        v0 = 0x10000u;
        h0 = (short)((*mp - 0x97fee681u) | u0);
    }
    e0 = e0 * 0.5L + (long double)((garr[i1 & 7u] | 1u) & 1023u);
    goto L2;
    if (budget != 0u) { budget -= 1u; u2 = fn0(p2, (garr[i1 & 7u] ^ (unsigned)((int)(unsigned)x0 >= (int)a0[u1 & 3u])), p2); }
    switch (i1 & 7u) {
        case 5u: ;
        if (~(unsigned)((int)a0[u1 & 3u] >= (int)0x3420966fu)) {
            if (a0[i0 & 3u]) {
                w0 = w0 * 6364136223846793005ull + (unsigned)((5u * (unsigned)h1) || u1);
                if (budget != 0u) { budget -= 1u; u3 = fn1(*q0, (unsigned)x0, i1); }
                do { if (--fuel == 0u) goto done;
                    if (((1u << (g0 & 31u)) % (0x29b82d6u | 1u))) break;
                    if (budget != 0u) { budget -= 1u; u2 = fn0(v0, (m0 >> ((unsigned)(signed char)(unsigned)((int)(unsigned)x0 >= (int)i0) & 31u)), ~(0x10000u / (3u | 1u))); }
                    case 4u: ;
                    c1 = (signed char)(unsigned)s0;
                    if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)f0 * 0x7deb6db9u), (unsigned)(((unsigned)e0 % (0x55ed4a9eu | 1u)) < fuel), ((unsigned)e0 & (unsigned)e0)); }
                    case 0u: ;
                } while (i0++ < 5u && ((9u >> (p0 & 31u)) << (g0 & 31u)));
                d0 = d0 * 0.5 + (double)((unsigned)(unsigned char)(unsigned)(r0.x && ((u2 % (g0 | 1u)) & g1)) & 1023u);
                if (((unsigned)f0 | 0xffffffffu)) goto L2;
                u2 = u2 * 0x9e3779b1u + (u3 % ((unsigned)(short)(0x7fffffffu * 4u) | 1u));
            }
            garr[0x67b04521u & 7u] = (i0 >> ((unsigned)h0 & 31u));
            case 2u: ;
            goto L1;
        }
        for (;;) { if (--fuel == 0u) goto done;
            while (*q0) { if (--fuel == 0u) goto done;
                h0 = (short)((unsigned)(*q0 < (unsigned)(x0 >> 70)) << ((unsigned)((int)(unsigned)(unsigned char)(unsigned)((int)u2 < (int)v0) >= (int)i1) & 31u));
            }
            b0 = ((7u % ((p0 ? (unsigned)c0 : 0xb8b832a3u) | 1u)) + i0) != 0u;
            i0 = 5u & 15u;
            u0 += -((unsigned)f0 | 8u);
        }
        if ((unsigned)c1) {
            r0.y ^= (r0.x / (0x7fffffffu | 1u));
            switch (*q0 & 7u) {
                if (budget != 0u) { budget -= 1u; u2 = fn1(0x10000u, (0x10000u / (0x8d1e6426u | 1u)), (unsigned)(*q0 && (*mp / ((unsigned)d0 | 1u)))); }
                goto L0;
                i0 = p0 & 15u;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn1(*mp, (unsigned)h0, 6u); }
        } else {
            do { if (--fuel == 0u) goto done;
                goto L3;
                if (i2) {
                    *mp = (3u << (u2 & 31u));
                    l0 = (long)((unsigned long)l0 + p0);
                    default: ;
                } else {
                    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)b0, 9u, (unsigned)(u3 < (unsigned)((short)(unsigned)b0 > (signed char)(unsigned)d0))); }
                    for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (unsigned)((int)((unsigned)e0 * 0xffffffffu) < (int)(0x10000u - r0.y)));
                        if ((unsigned)(short)(unsigned)((unsigned)s0 && 5u)) continue;
                        u3 ^= ~(a0[u1 & 3u] << (i0 & 31u));
                        while ((0xe423b1b7u ^ (g0 ^ m0))) { if (--fuel == 0u) goto done;
                            u0 ^= ((*q0 / ((u1 + u3) | 1u)) << (0x8e17fc8du & 31u));
                            w0 ^= (unsigned long long)(unsigned)(signed char)(g1 % (0x80000000u | 1u)) << (p0 & 63u);
                            u3 = u3 * 0x9e3779b1u + r0.x;
                            r0.x = (unsigned)(u1 || (unsigned)c1);
                            l0 = (long)((unsigned long)l0 + ((((unsigned)h0 >> (((unsigned)l0 | g1) & 31u)) | (unsigned)h1) % ((unsigned)s1 | 1u)));
                        }
                        goto L1;
                    }
                    while (i1++ < 6u && (unsigned)(unsigned char)((g0 % (garr[u2 & 7u] | 1u)) & (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                        b0 = ((unsigned)(w0 >> 29) / ((unsigned)b0 | 1u)) != 0u;
                        case 1u: ;
                        continue; (void)((2u << ((unsigned)f0 & 31u)));
                        f0 = f0 * 0.5f + (float)((((unsigned)((short)u0 > (signed char)g0) & *mp) << ((unsigned)(short)(u0 ^ m0) & 31u)) & 255u);
                        if (fuel < 8u) return (0xcb96a4f7u >> ((unsigned)(1u && (unsigned)x0) & 31u));
                        m0 ^= ((unsigned)(p1 && (unsigned)(0xffffffffu || p0)) << ((unsigned)(x0 >> 70) & 31u));
                    }
                    case 7u: ;
                }
                u3 ^= (r0.y << ((unsigned)(short)((unsigned)f0 >> ((unsigned)l0 & 31u)) & 31u));
                if (((unsigned)l0 + (0x7fffffffu / ((unsigned)b0 | 1u)))) {
                    if (r0.y) {
                        if (budget != 0u) { budget -= 1u; u1 = fn0((i1 - g0), (0x7fffffffu % (u2 | 1u)), (unsigned)f0); }
                        break; (void)((unsigned)((short)0xb12dd38fu > (signed char)(r0.x ^ p0)));
                        a0[(u3 ^ (unsigned)h1) & 3u] = g1;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(r0.y, (unsigned)(r0.y || (i0 * 0xc0fd4a7bu)), ((unsigned)((int)u1 < (int)(unsigned)d0) % (0x7fffffffu | 1u))); }
                        break;
                    }
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)!((unsigned)(signed char)(unsigned)((short)(unsigned)h0 > (signed char)fuel) + (unsigned)(w0 >> 29)), ((unsigned)c0 << ((unsigned)(8u && 0x4c349b10u) & 31u)), (unsigned)(short)(unsigned)((unsigned)c0 == (unsigned)((unsigned)c1 && i1))); }
                }
                s0 = (int)(((unsigned)l0 % ((unsigned)x0 | 1u)) >> (3u & 31u));
            } while (i0++ < 3u && garr[i1 & 7u]);
        }
    }
    do { if (--fuel == 0u) goto done;
        while (i1++ < 2u && (r0.x + 0xffffffffu)) { if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + ((unsigned)h1 | (r0.y - a0[u1 & 3u])));
            if ((unsigned)(short)(4u - 0x5414f25u)) break;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)(i1 < g0), ((unsigned)d0 & p2), ((unsigned)((int)g0 < (int)a0[u1 & 3u]) + 0xffffffffu)); }
        }
        do { if (--fuel == 0u) goto done;
            c1 = (signed char)i1;
        } while (i1++ < 2u && (unsigned)b0);
        if ((unsigned)((int)0xd8a79dcu < (int)(unsigned)c0)) {
            if ((unsigned)((int)(unsigned)(w0 >> 29) >= (int)6u)) break;
            if ((a0[u1 & 3u] - (unsigned)e0)) goto L3;
            if (2u) break;
            do { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((u3 % ((unsigned)(*q0 < (unsigned)b0) | 1u)) & 1023u);
                if (budget != 0u) { budget -= 1u; u3 = fn1((0xac57ba92u | r0.x), (r0.x ? 0xffffffffu : (unsigned)s0), (garr[i1 & 7u] * fuel)); }
                if ((0x2ba0744fu - 0x1c0aca60u)) break;
                r0.y ^= (unsigned)(1u < (p0 >> ((unsigned)x0 & 31u)));
                s0 = (int)(unsigned)(0x3c7e80a5u < ~(unsigned)(a0[i0 & 3u] || (unsigned)((int)fuel < (int)r0.y)));
                break; (void)((unsigned)(fuel && p1));
            } while (i1++ < 4u && (fuel / ((unsigned)s1 | 1u)));
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)e0, (unsigned)(2u < g1), r0.x); }
        }
        break; (void)((0x1c6ba964u ^ *mp));
        goto L1;
    } while (i0++ < 4u && (u3 << (i1 & 31u)));
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)((int)(unsigned)d0 < (int)0x80000000u) == u0), (unsigned)(g0 < garr[i1 & 7u]), (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)9u)); }
    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)c0 ^ 0x80000000u), (unsigned)(short)((unsigned)c1 / (g1 | 1u)), i2); }
    while (i0++ < 2u && 0x2a08cccau) { if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)(((0x2e7e8b18u % (v0 | 1u)) % ((unsigned)(i1 < *mp) | 1u)) & 255u);
        { unsigned t5; double z5; if ((0x3a51f003u) & 1u) { t5 = (unsigned)((int)(unsigned)(unsigned char)(unsigned)(0x80000000u || (unsigned)s0) >= (int)(unsigned)l0); z5 = (double)((((i2 + r0.x) ^ 0x6cfd6557u)) & 255u); } if ((0x3a51f003u) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
            if (((unsigned)(i0 == (unsigned)l0) << ((unsigned)c1 & 31u))) break;
            i1 = ((unsigned)x0 ? (8u * p0) : (unsigned)h1) & 15u;
        }
    }
    e0 = e0 * 0.5L + (long double)((unsigned)(0x7a942ceu || 0xd2375e46u) & 1023u);
    do { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((short)(garr[i1 & 7u] | u1) > (signed char)0xa9824cb3u)) {
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((short)u0 > (signed char)3u), a0[u1 & 3u], (((unsigned)d0 | m0) % (0xbf76d323u | 1u))); }
                while (i2++ < 5u && 0xcc3493c1u) { if (--fuel == 0u) goto done;
                    i2 = (((unsigned)(unsigned char)(unsigned)(p0 < (unsigned)b0) & p2) % ((0x7fffffffu * a0[i0 & 3u]) | 1u)) & 15u;
                }
                l0 = (long)((unsigned long)l0 + ((unsigned)(signed char)(unsigned)((int)0x457bde9u < (int)g1) ? (unsigned)c1 : 9u));
                if ((unsigned)(a0[u1 & 3u] == (unsigned)w0)) break;
                s1 = (int)((unsigned)s1 + (unsigned)(1u == g0));
            }
            if ((a0[u1 & 3u] | (0x8de678a2u - 0x92303724u))) break;
        }
        f0 = f0 * 0.5f + (float)((((unsigned)s0 ? r0.y : (p1 << (r0.x & 31u))) * (unsigned)h0) & 255u);
    } while (i0++ < 6u && (u1 >> (8u & 31u)));
    { unsigned t6; double z6; if (((i1 << (4u & 31u))) & 1u) { t6 = -(unsigned)(((unsigned)c0 - 0x7fffffffu) || 2u); z6 = (double)(((unsigned)(i1 == (garr[u2 & 7u] >> (a0[i0 & 3u] & 31u)))) & 255u); } if (((i1 << (4u & 31u))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
        if (((unsigned)c0 & (unsigned)!(i2 / (fuel | 1u)))) goto L3;
        if ((unsigned)(i0 || r0.y)) {
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)x0, ((unsigned)s0 | (0xa42d1d62u % ((unsigned)w0 | 1u))), ((unsigned)c0 * fuel)); }
                *mp = (((((unsigned)c1 % ((unsigned)(w0 >> 29) | 1u)) % ((unsigned)s1 | 1u)) >> (0x7fffffffu & 31u)) >> (u0 & 31u));
            }
            goto L3;
            c0 = (unsigned char)(unsigned)!((p0 & (unsigned)((int)0x80000000u < (int)(unsigned)l0)) * ((unsigned)(x0 >> 70) / (v0 | 1u)));
        } else {
            { unsigned t7; double z7; if ((p2) & 1u) { t7 = 0x7fffffffu; z7 = (double)((r0.x) & 255u); } if ((p2) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
                h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)x0 > (signed char)3u));
                u1 ^= (unsigned)l0;
                g1 += 0xd42c41feu;
                if ((unsigned)((int)u1 >= (int)(unsigned)(x0 >> 70))) goto done;
                if (u0) goto L4;
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    u3 += (unsigned)(unsigned char)(a0[i0 & 3u] + 9u);
                    f0 = f0 * 0.5f + (float)((0x80000000u << (0xf67b3466u & 31u)) & 255u);
                    for (;;) { if (--fuel == 0u) goto done;
                        if ((1u ? g0 : m0)) break;
                        garr[(unsigned)(p1 == 2u) & 7u] = (unsigned)(r0.y || a0[i0 & 3u]);
                        break; (void)((unsigned)(2u && (unsigned)h0));
                    }
                    *mp = ~(((unsigned)h0 << (u2 & 31u)) & (0xbafc17afu | i2));
                    for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn1(*q0, ((unsigned)f0 >> ((unsigned)((int)7u < (int)m0) & 31u)), (unsigned)w0); }
                        u0 = 0x4d43a7c8u;
                        if ((unsigned)(((unsigned)c1 ^ garr[i1 & 7u]) && 1u)) break;
                        h1 = (unsigned short)(h1 + 0x5095803fu);
                    }
                    g1 += (unsigned)((2u | r0.x) == ((unsigned)c0 ^ r0.x));
                }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)p0 >= (int)1u), (m0 & (0xffffffffu - (unsigned)h1)), ((unsigned)h0 | g0)); }
            goto L2;
            goto L2;
        }
        if ((unsigned)((short)(unsigned)(0x7fffffffu < u0) > (signed char)0xd0229a33u)) goto L0;
        f0 = f0 * 0.5f + (float)(0x10000u & 255u);
    }
    h0 = (short)((unsigned)((short)8u > (signed char)p2) ? (unsigned)(i0 == v0) : (unsigned)l0);
    goto L2;
    if ((unsigned)(short)((unsigned)(x0 >> 70) * u0)) goto L0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    goto L2;
    switch ((unsigned)(*mp == 9u) & 7u) {
        while (2u) { if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((unsigned)((int)1u < (int)garr[i1 & 7u]) & 1023u);
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)e0, (unsigned)((int)a0[u1 & 3u] < (int)(unsigned)(p0 || v0)), (7u - -(u3 / (0u | 1u)))); }
                if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(signed char)(a0[i0 & 3u] / (0x3ba7013u | 1u)), (((unsigned)w0 << ((unsigned)h0 & 31u)) - a0[i0 & 3u]), u0); }
            }
            r0.y ^= fuel;
            if (((unsigned)(p2 && 0xffffffffu) - (unsigned)h0)) {
                *mp = ((unsigned)(short)(0x80000000u | 0x107f6a45u) % ((unsigned)x0 | 1u));
                w0 = w0 * 6364136223846793005ull + p0;
                f0 = f0 * 0.5f + (float)((0x7fffffffu >> ((0x10000u ? p2 : 9u) & 31u)) & 255u);
                u2 = u2 * 0x9e3779b1u + ((0x4b38cbdu << ((unsigned)w0 & 31u)) % (0x7fffffffu | 1u));
                do { if (--fuel == 0u) goto done;
                    e0 = e0 * 0.5L + (long double)((((unsigned)s0 * 0xccf2ad31u) | u1) & 1023u);
                    w0 = w0 * 6364136223846793005ull + (unsigned)(4u == (unsigned)((int)(0x80000000u / (u1 | 1u)) >= (int)(unsigned)(0x10000u || 1u)));
                } while (i1++ < 4u && ~(fuel * a0[u1 & 3u]));
            } else {
                { unsigned t0; double z0; if ((i2) & 1u) { t0 = 0xbc3c0221u; z0 = (double)(((unsigned)c1) & 255u); } if ((i2) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    w0 = w0 * 6364136223846793005ull + (0x67f8b972u % ((u2 / ((unsigned)h0 | 1u)) | 1u));
                    switch (((unsigned)(unsigned char)(0x80000000u & u3) % (a0[i0 & 3u] | 1u)) & 7u) {
                        L0: if (--fuel == 0u) goto done;
                        h1 = (unsigned short)(h1 + (~(unsigned)((short)8u > (signed char)(unsigned)!(i0 % (*q0 | 1u))) % ((i2 + v0) | 1u)));
                        c0 = (unsigned char)(v0 << ((unsigned)s1 & 31u));
                        if ((unsigned)s1) break;
                    }
                    q0 = &garr[i1 & 7u];
                    if (u3 == 7u) return ((unsigned)(unsigned char)(0xd094f081u | (unsigned)l0) ^ p1);
                    do { if (--fuel == 0u) goto done;
                        if (g1) break;
                        v0 = (unsigned)(i0 == (garr[u2 & 7u] << (a0[u1 & 3u] & 31u)));
                        L1: if (--fuel == 0u) goto done;
                        switch (((p2 << ((unsigned)x0 & 31u)) * (unsigned)(w0 >> 29)) & 7u) {
                            if (u3 == 7u) return (unsigned)((int)((unsigned)s0 - (*mp * 0x35679eb7u)) < (int)8u);
                            e0 = e0 * 0.5L + (long double)((unsigned)(((unsigned)c0 + 0x439bf86eu) || (unsigned)((int)(unsigned)s1 < (int)g0)) & 1023u);
                            u3 = (unsigned)((short)(unsigned)(unsigned char)(unsigned)((int)(fuel ^ a0[u1 & 3u]) >= (int)u2) > (signed char)u3);
                            u0 ^= (p0 - (garr[i1 & 7u] / ((unsigned)h0 | 1u)));
                            continue; (void)((unsigned)(signed char)((p2 >> (r0.x & 31u)) / (0xb06ab6b7u | 1u)));
                        }
                    } while (i1++ < 5u && (a0[u1 & 3u] ? (unsigned)e0 : (unsigned)l0));
                }
            }
            d0 = d0 * 0.5 + (double)((u2 | (unsigned)(signed char)(unsigned)((int)(i0 % ((unsigned)e0 | 1u)) >= (int)(a0[u1 & 3u] / (m0 | 1u)))) & 1023u);
            do { if (--fuel == 0u) goto done;
                case 5u: ;
            } while (i1++ < 5u && ((unsigned)(w0 >> 29) % ((m0 - garr[i1 & 7u]) | 1u)));
            r0.y ^= ((0x10000u - (unsigned)((short)a0[u1 & 3u] > (signed char)m0)) + (7u % (9u | 1u)));
        }
        default: ;
    }
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2(((unsigned)b0 & 0x80000000u), ((unsigned)(9u < p0) % (0u | 1u)), (*q0 >> (fuel & 31u))); }
        garr[i2 & 7u] = (unsigned)((int)7u >= (int)0x9b029309u);
        r0.y ^= (unsigned)(*mp < p2);
        s1 = (int)((unsigned)s1 + ((*mp / (((unsigned)(0xb8fa815du == i1) - 0xc5515e68u) | 1u)) >> (u1 & 31u)));
    }
    switch ((m0 << (garr[i1 & 7u] & 31u)) & 7u) {
        { unsigned t1; double z1; if ((garr[u2 & 7u]) & 1u) { t1 = (unsigned)f0; z1 = (double)((0x80000000u) & 255u); } if ((garr[u2 & 7u]) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
            c1 = (signed char)(p1 / (((unsigned)x0 >> ((unsigned)(a0[i0 & 3u] == r0.y) & 31u)) | 1u));
            u2 ^= (((unsigned)b0 | (unsigned)h1) % ((unsigned)h0 | 1u));
            L2: if (--fuel == 0u) goto done;
            if (p1) {
                h0 = (short)((unsigned)h0 * (unsigned)(x0 >> 70));
            } else {
                if (((unsigned)w0 % ((unsigned)h1 | 1u))) goto done;
            }
        }
        case 2u: ;
        r0.x = ((unsigned)c0 % ((((unsigned)w0 ? 0x80000000u : (unsigned)w0) + (unsigned)c1) | 1u));
    }
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            c1 = (signed char)~(unsigned)(i2 < u0);
            if (-(0x7fffffffu * p2)) {
                b0 = (unsigned)!(unsigned)(garr[i1 & 7u] || (unsigned)s0) != 0u;
                if (a0[i0 & 3u]) break;
                u1 += u1;
                { unsigned t2; double z2; if (((unsigned)((int)(0xffffffffu << ((unsigned)l0 & 31u)) >= (int)u0)) & 1u) { t2 = (unsigned)(0u || (unsigned)(short)(unsigned)(fuel < garr[u2 & 7u])); z2 = (double)(((0x80000000u - r0.x)) & 255u); } if (((unsigned)((int)(0xffffffffu << ((unsigned)l0 & 31u)) >= (int)u0)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
                    x0 = x0 * 0x100000001b3ull + 0xb9664b3fu;
                    if ((unsigned)((int)(r0.y & r0.y) < (int)a0[i0 & 3u])) break;
                    v0 = ((unsigned)((int)(unsigned)f0 >= (int)(unsigned)((unsigned)f0 < (unsigned)(x0 >> 70))) - g0);
                }
                r0.x = ((unsigned)(short)((unsigned)((short)0x10000u > (signed char)g1) & (unsigned)(a0[u1 & 3u] && r0.x)) & i2);
            } else {
                if (budget != 0u) { budget -= 1u; u1 = fn0((0xffffffffu << (g0 & 31u)), ((unsigned)w0 << (9u & 31u)), (unsigned)((unsigned)l0 && a0[i0 & 3u])); }
                if ((unsigned)l0) break;
            }
            for (i2 = 0u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)s1 | ((*mp % ((unsigned)w0 | 1u)) >> (0x376247bcu & 31u))) || 0xdd06ed26u));
                L3: if (--fuel == 0u) goto done;
                L4: if (--fuel == 0u) goto done;
                s0 = (int)(unsigned)((int)0x10000u >= (int)(unsigned)((unsigned)(x0 >> 70) || 0x7fffffffu));
            }
        }
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn2(i0, -(g1 + (garr[u2 & 7u] / (g0 | 1u))), (unsigned)b0); }
            { unsigned t3; double z3; if ((0u) & 1u) { t3 = i2; z3 = (double)(((unsigned)(signed char)((unsigned)h1 >> (u3 & 31u))) & 255u); } if ((0u) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
                garr[(unsigned)c0 & 7u] = (u2 + g0);
                if ((unsigned)s0) break;
                { unsigned t4; double z4; if ((i1) & 1u) { t4 = 0x862ee22eu; z4 = (double)((0xf2591adbu) & 255u); } if ((i1) & 1u) { u2 += t4; d0 = d0 * 0.5 + z4; }
                    r0.y ^= (unsigned)((g1 + 0x871607cau) == (unsigned)h1);
                }
                break; (void)(((unsigned)((unsigned)c1 == p1) << ((unsigned)f0 & 31u)));
            }
            if (*mp) break;
            if ((unsigned)((unsigned)h1 == (unsigned)((int)v0 < (int)u2))) break;
            if (0x1636ffceu) break;
            if (0x3747119cu) break;
        } while (i1++ < 7u && (unsigned)(((unsigned)c1 << ((unsigned)d0 & 31u)) < 6u));
        c0 = (unsigned char)((unsigned)b0 + g1);
        *mp = (unsigned)(short)(unsigned)((short)(unsigned)!(u3 ^ u0) > (signed char)(8u / ((unsigned)d0 | 1u)));
        *q0 = ((unsigned)!(unsigned)((unsigned)d0 && -(a0[i0 & 3u] + p1)) >> ((p0 - (unsigned)e0) & 31u));
        if ((a0[i0 & 3u] ^ 0xbbc3f975u)) {
            u3 = (unsigned)((unsigned)((int)(r0.y % (i0 | 1u)) >= (int)u0) == (unsigned)l0);
            { unsigned t5; double z5; if (((unsigned)(fuel && 5u)) & 1u) { t5 = (unsigned)x0; z5 = (double)((~(u0 | (unsigned)x0)) & 255u); } if (((unsigned)(fuel && 5u)) & 1u) { u0 += t5; d0 = d0 * 0.5 + z5; }
                s0 = (int)((unsigned)(unsigned char)((unsigned)d0 / ((unsigned)(0x7fffffffu && i0) | 1u)) - (unsigned)b0);
            }
            switch (i2 & 7u) {
                u3 = (unsigned)(garr[i1 & 7u] || u0);
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)c0, (fuel / (garr[i1 & 7u] | 1u)), (r0.y - 0u)); }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(w0 >> 29), ~((unsigned)(x0 >> 70) & ((unsigned)s1 << (u0 & 31u))), p0); }
        }
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((0xffffffffu ^ (unsigned)(x0 >> 70)) && (unsigned)s1), a0[i0 & 3u], r0.y); }
        do { if (--fuel == 0u) goto done;
            if (0x80000000u) {
                u0 = u0 * 0x9e3779b1u + 0x41176317u;
                if (fuel < 8u) return (((unsigned)!(0u % ((unsigned)(w0 >> 29) | 1u)) + 0xffffffffu) ^ (unsigned)h1);
            }
            if ((unsigned)((int)(unsigned)(7u || a0[u1 & 3u]) >= (int)i2)) break;
            break; (void)((unsigned)(p0 < (unsigned)(a0[u1 & 3u] && 0xffffffffu)));
        } while (i1++ < 7u && (unsigned)(unsigned char)(r0.x | 0u));
    }
    s1 = (int)((unsigned)s1 + 3u);
    u1 = u1 * 0x9e3779b1u + (6u * (unsigned)(w0 >> 29));
    for (;;) { if (--fuel == 0u) goto done;
        if ((unsigned)(p1 == (unsigned)(signed char)(0xd63397a2u - u3))) {
            if (budget != 0u) { budget -= 1u; u1 = fn1(*q0, *q0, i2); }
            break; (void)((5u >> (8u & 31u)));
        } else {
            if (p0) break;
            if (((unsigned)c0 + r0.x)) break;
            if (0x10000u) goto L4;
        }
        break; (void)(-(unsigned)(fuel && i2));
        h1 = (unsigned short)(h1 + 0x7fffffffu);
    }
    for (;;) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)f0, (u0 | 0xa9102022u), 0x2a6793ddu); }
        q0 = &garr[2u & 7u];
    }
    i0 = (unsigned)((int)0xffffffffu >= (int)((garr[i1 & 7u] >> ((unsigned)e0 & 31u)) >> (-(unsigned)((int)garr[i1 & 7u] < (int)(unsigned)d0) & 31u))) & 15u;
    if ((unsigned)h1) goto L3;
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(p1 < u1), (unsigned)((unsigned)b0 && (unsigned)((int)g0 < (int)fuel)), (0x10000u & *mp)); }
    if ((unsigned)w0) {
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch (*q0 & 7u) {
                case 2u: ;
                if (budget != 0u) { budget -= 1u; u3 = fn1(((0x17c9f6b5u >> (6u & 31u)) ^ 0x63a35ce1u), (p1 ? v0 : (unsigned)e0), (unsigned)c1); }
            }
            goto L3;
            *mp = u3;
            u3 ^= ((unsigned)b0 ^ 0x7fffffffu);
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)(p1 == 6u);
                c0 = (unsigned char)(unsigned)((int)(0xf98e3690u / (a0[i0 & 3u] | 1u)) < (int)0x7fffffffu);
                for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)(((unsigned)((int)(unsigned)((int)g0 >= (int)(unsigned)b0) < (int)p0) ^ 0x10000u) & 1023u);
                    r0.x = (unsigned)h1;
                }
            }
            { unsigned t6; double z6; if (((unsigned)((unsigned)h0 == ((unsigned)h0 ^ (unsigned)h1))) & 1u) { t6 = (0xffffffffu << (0x7fffffffu & 31u)); z6 = (double)((0x8f6b3a72u) & 255u); } if (((unsigned)((unsigned)h0 == ((unsigned)h0 ^ (unsigned)h1))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                x0 = x0 * 0x100000001b3ull + ((unsigned)((unsigned)b0 == (unsigned)x0) << ((unsigned)(short)(g0 * garr[u2 & 7u]) & 31u));
                if (budget != 0u) { budget -= 1u; u2 = fn2((r0.x << ((0x7fffffffu * 0x5cd66f9bu) & 31u)), (unsigned)((short)r0.y > (signed char)(unsigned)(signed char)(p1 - g1)), (0x80000000u / (v0 | 1u))); }
                e0 = e0 * 0.5L + (long double)(0x145eb93u & 1023u);
                l0 = (long)((unsigned long)l0 + ~(unsigned)(*q0 < (unsigned)(unsigned char)(p2 % (i1 | 1u))));
                e0 = e0 * 0.5L + (long double)((unsigned)!((unsigned)!((unsigned)c0 << (9u & 31u)) % (((unsigned)(w0 >> 29) >> ((unsigned)b0 & 31u)) | 1u)) & 1023u);
            }
        }
        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((unsigned)l0 < (unsigned)s1), (unsigned)((int)6u >= (int)6u), (*q0 ? u0 : 0x80000000u)); }
        f0 = f0 * 0.5f + (float)((unsigned)((short)(unsigned)!(((unsigned)b0 / (u2 | 1u)) + ((unsigned)x0 / ((unsigned)(w0 >> 29) | 1u))) > (signed char)(unsigned)s1) & 255u);
    }
    f0 = f0 * 0.5f + (float)((unsigned)((int)((0x7fffffffu * 0x10000u) | (unsigned)(w0 >> 29)) >= (int)v0) & 255u);
    if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)!(0x7fffffffu ^ 0xffffffffu), u2, 5u); }
    *q0 = (u3 & (unsigned)((int)0x80000000u >= (int)(unsigned)s0));
    if ((unsigned)!(unsigned)((short)6u > (signed char)(unsigned)s0)) goto L0;
    switch ((unsigned)!(i0 / ((unsigned)x0 | 1u)) & 7u) {
        r0.x = (u2 - (unsigned)((int)*q0 < (int)(0xcdaa0f26u ? 5u : (unsigned)s1)));
    }
    { unsigned t7; double z7; if (((unsigned)((int)0x7fffffffu < (int)-((unsigned)e0 / (v0 | 1u)))) & 1u) { t7 = (unsigned)(p0 && 3u); z7 = (double)(((r0.y ^ (unsigned)!((unsigned)s0 * 6u))) & 255u); } if (((unsigned)((int)0x7fffffffu < (int)-((unsigned)e0 / (v0 | 1u)))) & 1u) { u1 += t7; d0 = d0 * 0.5 + z7; }
        goto L2;
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)s0 < (unsigned)(a0[i0 & 3u] == (unsigned)(x0 >> 70))), ((unsigned)(signed char)(u2 / ((unsigned)b0 | 1u)) >> (r0.y & 31u)), (unsigned)((g1 / ((unsigned)h0 | 1u)) || (unsigned)l0)); }
        switch (0x10000u & 7u) {
            { unsigned t8; double z8; if ((0u) & 1u) { t8 = (unsigned)(i0 == 0xb5856c0au); z8 = (double)(((unsigned)d0) & 255u); } if ((0u) & 1u) { u0 += t8; d0 = d0 * 0.5 + z8; }
                if (((unsigned)(w0 >> 29) ? u3 : (unsigned)h0)) {
                    case 7u: ;
                    u1 ^= 0xf339ead3u;
                    case 0u: ;
                } else {
                    b0 = (i1 + ((unsigned)e0 | ((unsigned)d0 + 0xffffffffu))) != 0u;
                    if (((unsigned)(signed char)(unsigned)((unsigned)f0 || i0) % (*mp | 1u))) goto done;
                }
                if (budget != 0u) { budget -= 1u; u0 = fn0((u2 | p0), *mp, (unsigned)(u3 && (unsigned)(0x10000u || 1u))); }
                { unsigned t9; double z9; if ((((unsigned)h0 - u1)) & 1u) { t9 = (unsigned)l0; z9 = (double)(((unsigned)((int)2u >= (int)(unsigned)s0)) & 255u); } if ((((unsigned)h0 - u1)) & 1u) { u3 += t9; d0 = d0 * 0.5 + z9; }
                    if (u3 == 7u) return (unsigned)(0xf212d49du < (i0 | (u2 >> (u0 & 31u))));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)(0x235d768bu * 0x80000000u) > (signed char)0x7fffffffu), (v0 % ((unsigned)x0 | 1u)), 0x1e09abbau); }
                }
                default: ;
                if ((unsigned)((int)~(a0[i0 & 3u] / (2u | 1u)) < (int)(unsigned)(x0 >> 70))) goto L0;
                s1 = (int)((unsigned)s1 + a0[u1 & 3u]);
            }
            f0 = f0 * 0.5f + (float)(((unsigned)(0x3fa43383u || fuel) * 0x7fffffffu) & 255u);
            case 4u: ;
            *q0 += (unsigned)((unsigned)(u1 && *mp) && (unsigned)((unsigned)((short)(unsigned)h1 > (signed char)0xffffffffu) && (unsigned)l0));
            i2 = ((0x7fffffffu % ((unsigned)b0 | 1u)) & 0x7c65d5bau) & 15u;
            break;
        }
    }
    if ((unsigned)s0) {
        if (budget != 0u) { budget -= 1u; u2 = fn1((1u + (unsigned)l0), garr[i1 & 7u], (0x7fffffffu % (u3 | 1u))); }
        if ((unsigned)(signed char)(0u / ((m0 >> ((unsigned)h0 & 31u)) | 1u))) goto L2;
        garr[0x80000000u & 7u] = ((unsigned)c1 + u1);
        { unsigned t10; double z10; if (((0xa18e9386u & (unsigned)b0)) & 1u) { t10 = (unsigned)((unsigned)f0 < u2); z10 = (double)((((unsigned)x0 - i2)) & 255u); } if (((0xa18e9386u & (unsigned)b0)) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
            if (((0xf0f23ecdu % ((unsigned)b0 | 1u)) + u3)) {
                l0 = (long)((unsigned long)l0 + (unsigned)(garr[i1 & 7u] == (unsigned)((int)0u < (int)(unsigned)f0)));
                u2 ^= (i1 ? 8u : m0);
                if (u3 == 7u) return (6u | (unsigned)((unsigned)((unsigned)s1 < i0) == (u0 % (0xc8e8f38au | 1u))));
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    goto L2;
                }
                g0 = (unsigned)((int)u1 >= (int)(0x10000u ? (unsigned)s1 : (unsigned)c0));
                { unsigned t11; double z11; if (((unsigned)(signed char)(r0.x & *mp)) & 1u) { t11 = ((unsigned)l0 & (*q0 + u0)); z11 = (double)(((unsigned)((unsigned)b0 || p0)) & 255u); } if (((unsigned)(signed char)(r0.x & *mp)) & 1u) { u3 += t11; d0 = d0 * 0.5 + z11; }
                    { unsigned t12; double z12; if (((3u - 9u)) & 1u) { t12 = (0x7fffffffu | p2); z12 = (double)(((unsigned)((unsigned)((unsigned)(w0 >> 29) == 0xffffffffu) && 0xa9545fd5u)) & 255u); } if (((3u - 9u)) & 1u) { u2 += t12; d0 = d0 * 0.5 + z12; }
                        h1 = (unsigned short)(h1 + (((unsigned)(x0 >> 70) ? i1 : (unsigned)s1) - m0));
                        a0[i2 & 3u] = ((unsigned)(signed char)(unsigned)((unsigned)h0 && m0) | (unsigned)!(m0 + u3));
                        *mp = *q0;
                        if ((unsigned)((unsigned)((int)0xcd8c1b6u >= (int)0x80000000u) == (unsigned)c0)) goto done;
                        w0 ^= (unsigned long long)g0 << ((unsigned)(unsigned char)(unsigned)(*q0 || (unsigned)((int)(unsigned)((short)i0 > (signed char)0x80000000u) < (int)u1)) & 63u);
                        if ((unsigned)b0) goto L1;
                    }
                    if ((unsigned)(short)(((unsigned)(x0 >> 70) << (8u & 31u)) / ((unsigned)b0 | 1u))) goto done;
                    { unsigned t13; double z13; if (((((unsigned)x0 * 0u) * (unsigned)w0)) & 1u) { t13 = (2u / (fuel | 1u)); z13 = (double)(((0x7736bedfu & p2)) & 255u); } if (((((unsigned)x0 * 0u) * (unsigned)w0)) & 1u) { u1 += t13; d0 = d0 * 0.5 + z13; }
                        w0 ^= (unsigned long long)(garr[i1 & 7u] | 0x10000u) << ((unsigned)((short)(unsigned)(unsigned char)((unsigned)h0 | (unsigned)b0) > (signed char)(g0 % ((unsigned)s0 | 1u))) & 63u);
                        x0 = x0 * 0x100000001b3ull + ((unsigned)((short)(unsigned)e0 > (signed char)g1) * 0xd0c6c99cu);
                        q0 = &garr[(unsigned)((short)0x10000u > (signed char)((unsigned)((int)(unsigned)s0 >= (int)0x6f957129u) & p0)) & 7u];
                        goto L1;
                        if ((g0 >> (2u & 31u))) goto L1;
                    }
                    h0 = (short)(a0[u1 & 3u] + (unsigned)d0);
                }
            } else {
                u0 = u0 * 0x9e3779b1u + 0u;
                while (i0++ < 2u && 0xd214d101u) { if (--fuel == 0u) goto done;
                    a0[~(g0 * a0[i0 & 3u]) & 3u] = (unsigned)((short)(0x10000u * fuel) > (signed char)(unsigned)h0);
                }
                w0 ^= (unsigned long long)(g0 & *mp) << (((unsigned)(u1 == (unsigned)((int)9u < (int)(unsigned)w0)) ^ (unsigned)h1) & 63u);
            }
            i0 = (unsigned)h0 & 15u;
            u3 += 0x953e4ac8u;
            q0 = &garr[((a0[i0 & 3u] ? v0 : (5u + (unsigned)e0)) * (unsigned)c0) & 7u];
        }
        if ((unsigned)(unsigned char)(0x4d9ee192u & r0.y)) goto L0;
        switch ((5u ? 0xe17fecdu : 0x6717e91eu) & 7u) {
            if (((unsigned)x0 | r0.x)) {
                if ((unsigned)b0) break;
                b0 = i2 != 0u;
                h0 = (short)(unsigned)((int)0xe14ca0dbu >= (int)(unsigned)(short)(unsigned)(9u == u1));
                case 1u: ;
                u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)((unsigned)s1 || (unsigned)((int)(unsigned)s1 < (int)p0)) < (unsigned)l0);
            }
            g0 = (((unsigned)s1 * 8u) << (7u & 31u));
        }
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)((unsigned)((int)0x80000000u < (int)-(u3 << (r0.y & 31u))));
    }
    switch (0xf70fc308u & 7u) {
        garr[(unsigned)(g0 < a0[u1 & 3u]) & 7u] = (unsigned)e0;
        g1 += (unsigned)(-(unsigned)((unsigned)l0 && u2) < ~(i2 - (unsigned)f0));
        if ((unsigned)(g1 < 9u)) goto L4;
        if ((unsigned)((unsigned)c1 || (i1 & 5u))) {
            if (budget != 0u) { budget -= 1u; u1 = fn1(0xffffffffu, p0, (unsigned)(g1 && (a0[i0 & 3u] | g0))); }
            for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                while (i1++ < 6u && (unsigned)f0) { if (--fuel == 0u) goto done;
                    u0 += (unsigned)((int)(0x3c7536au ? 0xffffffffu : (unsigned)(x0 >> 70)) < (int)0x28f5425bu);
                    while (i2++ < 6u && (fuel / ((unsigned)((int)(unsigned)d0 >= (int)u2) | 1u))) { if (--fuel == 0u) goto done;
                        s0 = (int)(unsigned)(-(1u / (u3 | 1u)) || *mp);
                        case 6u: ;
                        a0[*mp & 3u] = (*q0 ? (i0 >> ((unsigned)l0 & 31u)) : u3);
                        if (budget != 0u) { budget -= 1u; u2 = fn1((*mp | 8u), (unsigned)((unsigned)b0 == (unsigned)((int)garr[u2 & 7u] >= (int)g0)), ((unsigned)h1 * u2)); }
                        *q0 = r0.y;
                        break; (void)(5u);
                    }
                    case 0u: ;
                    case 3u: ;
                    h1 = (unsigned short)(h1 + r0.x);
                    { unsigned t14; double z14; if (((garr[u2 & 7u] << ((p0 - i1) & 31u))) & 1u) { t14 = (r0.y ^ (unsigned)((short)r0.y > (signed char)9u)); z14 = (double)(((unsigned)((unsigned)h0 || u1)) & 255u); } if (((garr[u2 & 7u] << ((p0 - i1) & 31u))) & 1u) { u1 += t14; d0 = d0 * 0.5 + z14; }
                        if (budget != 0u) { budget -= 1u; u0 = fn2((*mp | (unsigned)b0), (((unsigned)(w0 >> 29) | (unsigned)(x0 >> 70)) - garr[i1 & 7u]), (p1 - (unsigned)s1)); }
                        if ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)(short)(unsigned)((int)*mp >= (int)(unsigned)h1))) break;
                        case 1u: ;
                        do { if (--fuel == 0u) goto done;
                            h1 = (unsigned short)(h1 + p1);
                            continue; (void)(0xf72d2db1u);
                        } while (i2++ < 2u && ((unsigned)!(unsigned)(0xffffffffu && 0x510c6329u) ^ (unsigned)c0));
                        if (budget != 0u) { budget -= 1u; u0 = fn1((0x863eb3fdu / ((unsigned)s1 | 1u)), (unsigned)d0, -((m0 | *q0) | a0[u1 & 3u])); }
                    }
                }
                i1 = (unsigned)(short)((unsigned)b0 ^ (((unsigned)h1 / (fuel | 1u)) ^ (unsigned)(1u == (unsigned)s1))) & 15u;
                u1 += ((unsigned)(w0 >> 29) + (unsigned)((unsigned)b0 == 0xffffffffu));
            }
        } else {
            r0.x = (unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)s1);
            u0 = -(unsigned)(((unsigned)(w0 >> 29) ^ (unsigned)(p2 && (unsigned)(x0 >> 70))) && (unsigned)(short)((unsigned)f0 << ((unsigned)s1 & 31u)));
            v0 = 0x80000000u;
        }
        s0 = (int)(((unsigned)((short)(8u - u3) > (signed char)0x6566e097u) * 7u) * 0xffffffffu);
    }
    if ((a0[i0 & 3u] - (unsigned)h0)) goto done;
    f0 = f0 * 0.5f + (float)(((unsigned)(garr[u2 & 7u] == (unsigned)f0) << (p2 & 31u)) & 255u);
    s1 = (int)((unsigned)s1 + (unsigned)s1);
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(short)(r0.x / ((i2 & 0x7fffffffu) | 1u)), 0xaa5e2840u, ((unsigned)b0 << (i2 & 31u))); }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if (budget != 0u) { budget -= 1u; u3 = fn1((p1 % ((a0[u1 & 3u] + (unsigned)x0) | 1u)), 0x7fffffffu, (r0.y << ((m0 ^ v0) & 31u))); }
    u3 ^= (unsigned)((short)(unsigned)(signed char)(0x7fffffffu << ((((unsigned)b0 * u0) - 0x7fffffffu) & 31u)) > (signed char)g0);
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        s1 = (int)((unsigned)s1 + ~((unsigned)(4u || (0u >> (r0.y & 31u))) & i2));
        break; (void)((unsigned)((int)(unsigned)((int)u2 < (int)2u) >= (int)p2));
    }
    if ((unsigned)((unsigned)((unsigned)d0 || p0) == i2)) goto L3;
    s1 = (int)((unsigned)s1 + ((unsigned)d0 - 8u));
    u3 ^= (unsigned)((int)(unsigned)((g1 - r0.y) == (unsigned)c0) >= (int)i0);
    if ((unsigned)((r0.y - (unsigned)h0) && *mp)) {
        x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)((unsigned)w0 && (unsigned)(0x7fffffffu < 0xf5a58478u)) || p2);
        if (((*mp - (unsigned)e0) | r0.x)) goto L4;
    }
    if (budget != 0u) { budget -= 1u; u2 = fn0(g0, 0xcc6e6530u, ((unsigned)c1 << ((unsigned)(unsigned char)(unsigned)((short)p0 > (signed char)g1) & 31u))); }
    l0 = (long)((unsigned long)l0 + (unsigned)((0x80000000u ? *q0 : (unsigned)(unsigned char)(unsigned)((int)a0[u1 & 3u] < (int)i2)) || (unsigned)x0));
    if ((unsigned)f0) {
        switch (m0 & 7u) {
            f0 = f0 * 0.5f + (float)(((unsigned)((int)(unsigned)s0 >= (int)r0.y) % (0x7fffffffu | 1u)) & 255u);
            goto L4;
            v0 = ((u1 << (g1 & 31u)) | ((unsigned)s0 / ((unsigned)f0 | 1u)));
        }
        if (budget != 0u) { budget -= 1u; u2 = fn3((4u & (u3 >> (0u & 31u))), 3u, (unsigned)((unsigned)(1u == i0) < (unsigned)b0)); }
        switch ((unsigned)(short)(unsigned)((short)v0 > (signed char)(unsigned)(signed char)(unsigned)(g0 < (unsigned)l0)) & 7u) {
            g1 += (unsigned)(((r0.y << (9u & 31u)) << ((unsigned)((int)g1 < (int)0x5824e2c8u) & 31u)) < p0);
            if (budget != 0u) { budget -= 1u; u3 = fn2(((p2 ^ p1) % (u0 | 1u)), (unsigned)d0, g1); }
            u1 = (i2 ^ (unsigned)((int)2u < (int)0xf467c2fbu));
        }
        e0 = e0 * 0.5L + (long double)((unsigned)((short)(unsigned)((unsigned)x0 == 0xd1610789u) > (signed char)(unsigned)((int)(unsigned)e0 < (int)0x7fffffffu)) & 1023u);
        *q0 = (unsigned)(signed char)(*mp * (unsigned)((int)(((unsigned)h1 + u1) >> (0x7d841334u & 31u)) < (int)u0));
    } else {
        q0 = &garr[(4u | (unsigned)(unsigned char)(unsigned)((int)a0[u1 & 3u] >= (int)6u)) & 7u];
        d0 = d0 * 0.5 + (double)(0xcdf762cbu & 1023u);
    }
    if (~(unsigned)(fuel && fuel)) {
        while ((unsigned)(0xffffffffu < fuel)) { if (--fuel == 0u) goto done;
            if (p0) break;
            f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)s1 < (int)0x80000000u) & 255u);
            if (((u0 * 2u) - i0)) break;
            switch ((unsigned)b0 & 7u) {
                do { if (--fuel == 0u) goto done;
                    h0 = (short)(unsigned)((int)(unsigned)e0 >= (int)7u);
                    *q0 += (unsigned)s0;
                    if (0x7fffffffu) break;
                    h0 = (short)(8u & (unsigned)(-(unsigned)((int)garr[i1 & 7u] >= (int)0x7fffffffu) || (p1 * m0)));
                    a0[(unsigned)b0 & 3u] = (unsigned)((unsigned)(0x7fffffffu == i1) == 0x2e16bb38u);
                } while (i1++ < 4u && (r0.y | (r0.x >> (0x7fffffffu & 31u))));
                for (;;) { if (--fuel == 0u) goto done;
                    if ((0x7fffffffu * 0xb96e55d8u)) {
                        for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                            *q0 += (unsigned)d0;
                            if ((0x3155e0a3u ^ (unsigned)(x0 >> 70))) goto L1;
                            if (u3 == 7u) return ((unsigned)f0 & (unsigned)c1);
                            if ((unsigned)c1) continue;
                            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)(unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)s0) < (int)(unsigned)s1), (unsigned)((unsigned)b0 && g1), (unsigned)!(0x7fffffffu << ((unsigned)e0 & 31u))); }
                            c0 = (unsigned char)(unsigned)(a0[i0 & 3u] && (1u % ((unsigned)c0 | 1u)));
                        }
                        switch ((unsigned)w0 & 7u) {
                            if (~(unsigned)(9u && (unsigned)h1)) break;
                            x0 = x0 * 0x100000001b3ull + ((unsigned)d0 >> ((0x7fffffffu << (0x7691c033u & 31u)) & 31u));
                            case 0u: ;
                            c0 = (unsigned char)*mp;
                            q0 = &garr[-(unsigned)(0x57b68284u && m0) & 7u];
                        }
                        r0.x = (unsigned)((short)(garr[u2 & 7u] / (r0.x | 1u)) > (signed char)(0x10000u % (5u | 1u)));
                        g1 += (((unsigned)h0 / (p1 | 1u)) * (unsigned)(p1 || u0));
                        m0 ^= 0x80000000u;
                    } else {
                        a0[((unsigned)s1 >> (5u & 31u)) & 3u] = (unsigned)((int)(garr[u2 & 7u] | i1) < (int)v0);
                        h1 = (unsigned short)(h1 + (((unsigned)!((unsigned)c0 & garr[i1 & 7u]) ^ (unsigned)e0) >> (g0 & 31u)));
                    }
                    u2 += ~(0x7fffffffu * (unsigned)c1);
                }
                break; (void)((u0 << ((unsigned)w0 & 31u)));
                e0 = e0 * 0.5L + (long double)(((unsigned)(r0.x || garr[u2 & 7u]) >> (p1 & 31u)) & 1023u);
                u0 += p1;
            }
            if ((unsigned)(x0 >> 70)) {
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn2((0xa88aeb09u & u3), (unsigned)!((unsigned)d0 % ((unsigned)h1 | 1u)), (unsigned)(g0 < g1)); }
                    s1 = (int)((unsigned)s1 + (unsigned)!(((unsigned)d0 & ~(5u % (fuel | 1u))) * (unsigned)s0));
                    x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)(unsigned)c1 < (int)u0) >= (int)(unsigned)((0xc861b0a6u / (*mp | 1u)) && (unsigned)(x0 >> 70)));
                } while (i1++ < 5u && 0x7fffffffu);
                if (((unsigned)h1 / (garr[u2 & 7u] | 1u))) continue;
                L0: if (--fuel == 0u) goto done;
                { unsigned t0; double z0; if (((0xec60f8c9u | 5u)) & 1u) { t0 = (unsigned)((unsigned)(u0 && g0) && v0); z0 = (double)(((unsigned)c1) & 255u); } if (((0xec60f8c9u | 5u)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(8u < (unsigned)h0), u1, i2); }
                    if ((r0.y / ((unsigned)((int)(unsigned)h1 >= (int)(unsigned)f0) | 1u))) {
                        u0 ^= (unsigned)(i2 == u3);
                        if (budget != 0u) { budget -= 1u; u1 = fn2((a0[u1 & 3u] * garr[u2 & 7u]), (u3 - 0xffffffffu), u3); }
                        L1: if (--fuel == 0u) goto done;
                        do { if (--fuel == 0u) goto done;
                            L2: if (--fuel == 0u) goto done;
                            if (-(0xf2d45809u + *q0)) break;
                        } while (i1++ < 2u && u3);
                        w0 = w0 * 6364136223846793005ull + ((unsigned)(unsigned char)(*q0 * (unsigned)c1) + (unsigned)(u3 && i1));
                    } else {
                        { unsigned t1; double z1; if (((unsigned)(i1 == garr[u2 & 7u])) & 1u) { t1 = 0x80000000u; z1 = (double)(((unsigned)h0) & 255u); } if (((unsigned)(i1 == garr[u2 & 7u])) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
                            if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)h1 + ((unsigned)l0 ^ 0x10000u)), ((unsigned)(x0 >> 70) + (unsigned)(p2 || 2u)), (unsigned)w0); }
                            if ((unsigned)((int)0x7fffffffu >= (int)m0)) break;
                            continue; (void)(u1);
                            *mp = (unsigned)(0x1bdf1caau == ((unsigned)x0 % (g1 | 1u)));
                        }
                    }
                    m0 ^= 0xbb2e2f72u;
                    break; (void)((a0[i0 & 3u] - 0xffffffffu));
                }
            }
            if ((u0 / ((0u % ((unsigned)(x0 >> 70) | 1u)) | 1u))) break;
        }
        while (i0++ < 3u && p2) { if (--fuel == 0u) goto done;
            break; (void)(i2);
            if ((unsigned)((short)(unsigned)((unsigned)h0 && (unsigned)w0) > (signed char)0x8d9b4d88u)) break;
            do { if (--fuel == 0u) goto done;
                L3: if (--fuel == 0u) goto done;
                if ((p0 << (r0.y & 31u))) break;
                if (budget != 0u) { budget -= 1u; u0 = fn1((v0 << ((unsigned)b0 & 31u)), (unsigned)((int)0x7fffffffu >= (int)0x69b23bc2u), -(u2 * ((unsigned)h1 ^ (unsigned)l0))); }
                if ((unsigned)(garr[u2 & 7u] && (unsigned)(g0 && 0xffffffffu))) break;
            } while (i1++ < 6u && (unsigned)e0);
        }
        if (budget != 0u) { budget -= 1u; u3 = fn3(0x467b8d75u, 0xada8728du, m0); }
        m0 ^= i0;
        if ((*q0 - (unsigned)c1)) goto L1;
    }
    goto L2;
    i0 = r0.y & 15u;
    w0 ^= (unsigned long long)(unsigned)((unsigned)b0 < v0) << (((unsigned)c1 * (unsigned)x0) & 63u);
    u3 ^= (9u & (unsigned)h0);
    u1 = ((unsigned)((int)0xffffffffu >= (int)p2) << (0xb2461f73u & 31u));
    goto L0;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((7u * (a0[u1 & 3u] ^ (unsigned)c1))) {
            v0 = p1;
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)x0);
                    d0 = d0 * 0.5 + (double)(g1 & 1023u);
                    L4: if (--fuel == 0u) goto done;
                } while (i2++ < 3u && ((unsigned)c0 >> (*mp & 31u)));
                u3 = u3 * 0x9e3779b1u + (unsigned)((int)0x80000000u >= (int)(garr[u2 & 7u] >> ((m0 >> (g0 & 31u)) & 31u)));
                { unsigned t2; double z2; if (((unsigned)(signed char)(unsigned)((unsigned)((short)r0.x > (signed char)*mp) == fuel)) & 1u) { t2 = (unsigned)((int)garr[u2 & 7u] < (int)(unsigned)s0); z2 = (double)((((unsigned)c1 | 5u)) & 255u); } if (((unsigned)(signed char)(unsigned)((unsigned)((short)r0.x > (signed char)*mp) == fuel)) & 1u) { u1 += t2; d0 = d0 * 0.5 + z2; }
                    if (budget != 0u) { budget -= 1u; u3 = fn3(0xcef5d0c6u, (unsigned)e0, (unsigned)d0); }
                    break; (void)((unsigned)(w0 >> 29));
                    if ((unsigned)(garr[i1 & 7u] < (a0[u1 & 3u] ^ r0.y))) {
                        g1 += (unsigned)((int)-(unsigned)(((0x10000u * 7u) | p1) || r0.x) < (int)(unsigned)l0);
                        if (((unsigned)((int)0x48a98a2cu >= (int)v0) / (p2 | 1u))) break;
                        f0 = f0 * 0.5f + (float)((0xffffffffu + 0x80000000u) & 255u);
                        while ((unsigned)(unsigned char)((unsigned)(0xf57f7b80u < (unsigned)s1) - u1)) { if (--fuel == 0u) goto done;
                            g0 = (unsigned)((4u % (5u | 1u)) < r0.y);
                            goto L3;
                            g1 += i2;
                            garr[(unsigned)(unsigned char)(unsigned)((int)g1 >= (int)(unsigned)s0) & 7u] = (unsigned)((short)(unsigned)c0 > (signed char)(unsigned)(i0 == 9u));
                            v0 = v0;
                            if (garr[i1 & 7u]) break;
                        }
                    }
                    if (((unsigned)(6u || i1) | p0)) break;
                    if (0x80000000u) goto L1;
                }
                goto L1;
                if ((~(v0 >> (0u & 31u)) | a0[u1 & 3u])) break;
            }
            if (budget != 0u) { budget -= 1u; u1 = fn3(((0x7fffffffu + garr[u2 & 7u]) * a0[i0 & 3u]), (((unsigned)(x0 >> 70) * (unsigned)s0) & (unsigned)e0), 0x7fffffffu); }
            s0 = (int)(u0 / ((unsigned)h1 | 1u));
            g0 = (g0 ? (unsigned)b0 : (unsigned)(x0 >> 70));
            *q0 = (unsigned)(short)(unsigned)(u3 < (unsigned)(unsigned char)(unsigned)(-(garr[u2 & 7u] << (((unsigned)w0 | (unsigned)c0) & 31u)) == 7u));
        }
        r0.x = (((0x336770fdu ^ 0x80000000u) + (0xd0765ec6u % (1u | 1u))) * 0x833e1471u);
        if (fuel < 8u) return (((i0 + (unsigned)h1) & ((unsigned)c1 << (p1 & 31u))) / ((unsigned)(x0 >> 70) | 1u));
        for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)2u << ((unsigned)((unsigned)((int)(unsigned)((short)a0[u1 & 3u] > (signed char)0xffffffffu) >= (int)(0xf86c2ae9u << ((unsigned)s1 & 31u))) || 1u) & 63u);
            if (0x80000000u) break;
            if ((unsigned)(x0 >> 70)) {
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)0xffffffffu >= (int)(0x10000u % ((unsigned)e0 | 1u))), (unsigned)(signed char)(unsigned)((int)0xffffffffu < (int)(unsigned)b0), (((unsigned)c1 / ((unsigned)c0 | 1u)) ^ (unsigned)h1)); }
                if (budget != 0u) { budget -= 1u; u3 = fn3(u1, (unsigned)((int)0x10000u < (int)(unsigned)s0), ((unsigned)f0 ^ (a0[u1 & 3u] << ((unsigned)h0 & 31u)))); }
            } else {
                if (budget != 0u) { budget -= 1u; u1 = fn0((2u + p0), ((unsigned)e0 - 0x91c4305cu), (unsigned)(signed char)(unsigned)((int)0x80000000u >= (int)(u1 | u0))); }
                { unsigned t3; double z3; if (((unsigned)f0) & 1u) { t3 = (0x10000u >> ((unsigned)(x0 >> 70) & 31u)); z3 = (double)((u0) & 255u); } if (((unsigned)f0) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)x0 - p0), (unsigned)e0, ((unsigned)h1 << ((unsigned)(w0 >> 29) & 31u))); }
                }
            }
            u0 += ((unsigned)(x0 >> 70) / ((unsigned)(short)(9u >> (i1 & 31u)) | 1u));
            do { if (--fuel == 0u) goto done;
                continue; (void)(~(((unsigned)l0 % (i1 | 1u)) * 0x7fffffffu));
                break; (void)((-(0x7fffffffu + 0x7fffffffu) + 4u));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(0x7fffffffu < ~(unsigned)((int)(unsigned)(w0 >> 29) < (int)r0.y)), 0x7fffffffu, (unsigned)(r0.x < (7u - garr[u2 & 7u]))); }
                for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)((unsigned)((int)u0 >= (int)(unsigned)x0) ? (unsigned)(short)(unsigned)(a0[u1 & 3u] < 0x9fcde64cu) : 4u);
                    u0 = ((unsigned)d0 << ((unsigned)(0x80000000u < (unsigned)(x0 >> 70)) & 31u));
                    if ((unsigned)(u0 && i0)) break;
                    c1 = (signed char)(((unsigned)h1 ^ fuel) ? (p2 * 0xef52ef2cu) : (unsigned)s0);
                    if (0x80000000u) break;
                }
                break; (void)(r0.x);
                if ((unsigned)c1) break;
            } while (i2++ < 6u && (unsigned)((unsigned)h1 == (unsigned)(signed char)(unsigned)(0x10000u == (unsigned)c0)));
            if (budget != 0u) { budget -= 1u; u1 = fn0((*q0 | v0), (unsigned)(signed char)(0x81ce3a76u + (p2 % ((unsigned)s1 | 1u))), (0x80000000u + 0u)); }
        }
    }
    if (u3 == 7u) return -(unsigned)((int)(unsigned)((short)u1 > (signed char)(garr[u2 & 7u] << ((i0 / (*q0 | 1u)) & 31u))) < (int)0xa728c5d9u);
    if ((u2 % ((0x10000u >> (3u & 31u)) | 1u))) {
        l0 = (long)((unsigned long)l0 + ((u2 / (1u | 1u)) - (unsigned)!(unsigned)((short)(unsigned)l0 > (signed char)(unsigned)s1)));
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)(garr[i1 & 7u]);
        }
        f0 = f0 * 0.5f + (float)(u3 & 255u);
        if (((unsigned)w0 % ((unsigned)((unsigned)f0 || 0x10000u) | 1u))) goto done;
        if (-(i2 >> ((unsigned)s1 & 31u))) goto L2;
        d0 = d0 * 0.5 + (double)(((unsigned)e0 - (garr[u2 & 7u] << (0xc97cd619u & 31u))) & 1023u);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 12u, 0xb696327u, 0x7de84c6bu },
        { 15u, 0x2334e9dfu, 0x53da0314u },
        { 5u, 0x8099a089u, 0x83190ecfu },
        { 3u, 0xef1c95a5u, 0x10fe21fcu },
        { 5u, 0xf02b328cu, 0x319d5c67u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
