// test-ssa-source's program of seed 141000424 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0x2d47ecdfu, g1 = 0x6d6512bcu;
static unsigned garr[8] = { 0xa69cbcc3u, 0x4d617cf9u, 0x4f5e8f47u, 0x55a12db2u, 0xb6ee3bc6u, 0x9206ddbu, 0x2d826133u, 0x5b084466u };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    i0 = (0x10000u ? u0 : (unsigned)s0) & 15u;
    e0 = e0 * 0.5L + (long double)(u0 & 1023u);
    b0 = (fuel & ((unsigned)(u0 == *mp) % ((unsigned)x0 | 1u))) != 0u;
    do { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (g1 & 0x9e8c1253u);
        if (u3) break;
        s0 = (int)(u2 & (unsigned)((int)p1 < (int)(unsigned)((unsigned)x0 || 0xffffffffu)));
        if (i2) goto L1;
        if (fuel < 8u) return (unsigned)!((unsigned)s1 >> ((unsigned)c1 & 31u));
    } while (i0++ < 7u && u2);
    do { if (--fuel == 0u) goto done;
        g0 = (unsigned)c0;
        *q0 += *mp;
        L0: if (--fuel == 0u) goto done;
        continue; (void)(~(unsigned)((int)u2 >= (int)(unsigned)!(3u << (g1 & 31u))));
    } while (i0++ < 7u && 8u);
    while (i0++ < 7u && garr[u2 & 7u]) { if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
        if ((0x10000u | 0xffffffffu)) break;
        if (((unsigned)(x0 >> 70) - (unsigned)(m0 && (unsigned)s1))) {
            L2: if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)(unsigned)x0 << ((unsigned)(short)(0x7fffffffu & 0xeb0d31e9u) & 63u);
            L3: if (--fuel == 0u) goto done;
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)((unsigned)(fuel || p1) < p0)) continue;
                switch (((unsigned)(x0 >> 70) | fuel) & 7u) {
                    c0 = (unsigned char)(((a0[i0 & 3u] % ((unsigned)(v0 < (unsigned)s1) | 1u)) << (0x80000000u & 31u)) ^ a0[i0 & 3u]);
                    g1 += (unsigned)((int)~(0xffffffffu ? *q0 : i0) < (int)(unsigned)((int)fuel >= (int)g1));
                    h1 = (unsigned short)(h1 + ((1u & (i0 % (r0.y | 1u))) ^ p2));
                    d0 = d0 * 0.5 + (double)(0x7fffffffu & 1023u);
                    L4: if (--fuel == 0u) goto done;
                    q0 = &garr[((u1 - (unsigned)((int)p0 < (int)(unsigned)s1)) << (0xce66ab94u & 31u)) & 7u];
                }
                break; (void)((0xb5b3b137u / (a0[i0 & 3u] | 1u)));
                s1 = (int)((unsigned)s1 + (unsigned)f0);
                if ((unsigned)(u3 || (unsigned)(w0 >> 29))) break;
            }
        } else {
            if ((unsigned)((unsigned)(w0 >> 29) == (g0 - a0[u1 & 3u]))) {
                do { if (--fuel == 0u) goto done;
                    if (0x8a045026u) goto L2;
                } while (i1++ < 2u && 0x78c9ab13u);
            } else {
                c1 = (signed char)(unsigned)(signed char)((unsigned)(x0 >> 70) / ((unsigned)((short)(unsigned)s1 > (signed char)garr[u2 & 7u]) | 1u));
                break; (void)((unsigned)((int)(u2 % (r0.x | 1u)) < (int)p1));
                do { if (--fuel == 0u) goto done;
                    switch (0x2698f9fau & 7u) {
                        e0 = e0 * 0.5L + (long double)(0x38e26f64u & 1023u);
                        for (;;) { if (--fuel == 0u) goto done;
                            case 0u: ;
                            *q0 = *q0;
                            case 7u: ;
                            case 4u: ;
                        }
                        d0 = d0 * 0.5 + (double)((i1 >> ((unsigned)((unsigned)h1 && (p1 - i2)) & 31u)) & 1023u);
                        break; (void)(i2);
                        u2 += (unsigned)((unsigned)((int)(unsigned)(i2 || 0xffffffffu) >= (int)(unsigned)f0) || (unsigned)b0);
                    }
                    g1 += (((unsigned)(g0 && 0x7fffffffu) - (unsigned)h0) << ((unsigned)c0 & 31u));
                } while (i1++ < 6u && (unsigned)(signed char)((unsigned)b0 + (unsigned)(unsigned char)(unsigned)((short)0xcf8e3984u > (signed char)0x27f0ae4eu)));
                r0.x = (unsigned)(signed char)(u3 - p0);
            }
            c0 = (unsigned char)(unsigned)(short)(((unsigned)h0 | (unsigned)e0) / (0x1ab9d260u | 1u));
            d0 = d0 * 0.5 + (double)((unsigned)((short)u1 > (signed char)(7u | g1)) & 1023u);
        }
        u2 += (r0.y | (r0.x / (0xbe242554u | 1u)));
        q0 = &garr[(((v0 ? u2 : 0xb3871087u) - v0) ^ (unsigned)(w0 >> 29)) & 7u];
    }
    b0 = (0x80000000u | ((unsigned)((short)(i2 / ((unsigned)d0 | 1u)) > (signed char)garr[i1 & 7u]) % (i1 | 1u))) != 0u;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + (unsigned)!((unsigned)((unsigned)((int)0x19de70e6u < (int)r0.x) == (unsigned)c0) / ((*q0 * r0.y) | 1u));
        if ((unsigned)((short)r0.x > (signed char)i1)) {
            g0 = (0x10000u * ((unsigned)!((unsigned)e0 - r0.y) & (unsigned)h0));
        }
        *q0 = (m0 & (unsigned)(w0 >> 29));
        switch ((unsigned)(short)((unsigned)((int)0xffffffffu < (int)i1) / (u3 | 1u)) & 7u) {
            e0 = e0 * 0.5L + (long double)((i1 >> (((unsigned)((unsigned)c0 || m0) & (unsigned)((int)fuel < (int)(unsigned)x0)) & 31u)) & 1023u);
            w0 = w0 * 6364136223846793005ull + (((unsigned)b0 ^ fuel) / (v0 | 1u));
            u0 = 0u;
            f0 = f0 * 0.5f + (float)(((i2 ^ (unsigned)((int)0xcacf6b19u < (int)garr[i1 & 7u])) * (unsigned)(0xa2ebe158u && (unsigned)l0)) & 255u);
            *mp = (p2 - a0[u1 & 3u]);
        }
        break; (void)((0x20f70151u * (r0.x - (unsigned)w0)));
        m0 ^= 0x80000000u;
    }
    if ((unsigned)((int)p1 < (int)(unsigned)((int)0x80000000u < (int)0x80000000u))) goto L3;
    if (fuel < 8u) return g1;
    r0.x = (unsigned)(unsigned char)((unsigned)(x0 >> 70) % ((((unsigned)l0 >> (0x781e6765u & 31u)) ^ (unsigned)(w0 >> 29)) | 1u));
    if (garr[i1 & 7u]) {
        if ((*mp | 2u)) goto done;
        goto L2;
        g0 = ((unsigned)s1 ^ (i2 >> (7u & 31u)));
        if ((unsigned)(~(unsigned)((unsigned)x0 == i2) == 0x10000u)) goto L3;
        do { if (--fuel == 0u) goto done;
            v0 = (unsigned)(u1 < (r0.y | ((unsigned)!(a0[i0 & 3u] / (r0.x | 1u)) << ((unsigned)(w0 >> 29) & 31u))));
            do { if (--fuel == 0u) goto done;
                a0[((unsigned)c1 >> ((unsigned)c0 & 31u)) & 3u] = *mp;
                u2 ^= (((unsigned)b0 | 0x80000000u) * 0x59dc9d27u);
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    break; (void)((unsigned)((int)i0 >= (int)v0));
                    if (((2u >> (*q0 & 31u)) / (*q0 | 1u))) continue;
                    if ((unsigned)(garr[u2 & 7u] || *mp)) break;
                    u2 ^= (unsigned)(7u && (i0 | (unsigned)(9u || 0x80000000u)));
                    if (((unsigned)c0 + (unsigned)((int)g0 < (int)i2))) break;
                    continue; (void)((unsigned)d0);
                }
            } while (i1++ < 3u && (unsigned)((int)(unsigned)(u3 < a0[i0 & 3u]) < (int)(unsigned)c0));
            if ((i1 ^ i0)) goto L0;
            if (a0[u1 & 3u]) break;
        } while (i0++ < 7u && (unsigned)(short)(unsigned)((short)0x80000000u > (signed char)(unsigned)b0));
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        switch ((unsigned)h0 & 7u) {
            case 4u: ;
            default: ;
        }
        i1 = (unsigned)(i0 && 0x84a12be5u) & 15u;
        *mp = (unsigned)((int)p1 < (int)(unsigned)x0);
        break; (void)(((unsigned)d0 + (unsigned)b0));
        if (((unsigned)h1 + *q0)) break;
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)((unsigned)e0 == (unsigned)c0) == (unsigned)w0)) break;
            *q0 += (unsigned)((int)p1 < (int)0x326e5110u);
            break; (void)(p2);
            g1 += (((unsigned)(garr[u2 & 7u] < 0x461551acu) >> (garr[u2 & 7u] & 31u)) % ((unsigned)(0x66fd225fu || 0x2514161u) | 1u));
            w0 ^= (unsigned long long)(p1 + i0) << ((*mp << ((unsigned)(0xef4bd211u && (unsigned)l0) & 31u)) & 63u);
        }
    }
    w0 ^= (unsigned long long)(0u | i1) << ((unsigned)(v0 < i2) & 63u);
    garr[((unsigned)h1 ^ (unsigned)b0) & 7u] = (unsigned)(0x7fffffffu == fuel);
    *q0 += (0x7fffffffu / (0x10000u | 1u));
    goto L0;
    switch (((unsigned)w0 << (0x43e064e9u & 31u)) & 7u) {
        case 0u: ;
        if (((unsigned)e0 << ((unsigned)c1 & 31u))) break;
        if ((unsigned)(unsigned char)((*q0 - 7u) - p2)) goto done;
        v0 = ((g0 * 4u) ? (unsigned)(0x84c955d1u < 0x97a3c14du) : 0x8b2996a9u);
        s0 = (int)(unsigned)(((unsigned)e0 + (unsigned)(unsigned char)(*q0 * garr[i1 & 7u])) && (unsigned)!(u2 * g0));
        if ((unsigned)(w0 >> 29)) goto L2;
    }
    *q0 += (0x7fffffffu ^ (unsigned)d0);
    h0 = (short)(p1 / ((unsigned)((unsigned)!(7u >> (v0 & 31u)) || r0.x) | 1u));
    { unsigned t0; double z0; if ((0xffffffffu) & 1u) { t0 = (unsigned)(((unsigned)e0 >> ((unsigned)s1 & 31u)) == (unsigned)d0); z0 = (double)((0x37d54ebeu) & 255u); } if ((0xffffffffu) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        u0 ^= (v0 / (((unsigned)((int)r0.y >= (int)(unsigned)h1) + ((unsigned)s1 + r0.x)) | 1u));
        for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (4u) {
                if ((3u / (g1 | 1u))) break;
                s0 = (int)(unsigned)((unsigned)((unsigned)(r0.y == g1) == (v0 | i2)) == (unsigned)(w0 >> 29));
                if (fuel < 8u) return (unsigned)(r0.y == (unsigned)(9u < ((u0 + r0.x) | 0x10000u)));
            }
            if (0xf520c713u) continue;
            m0 ^= 6u;
            switch (((unsigned)(u3 || 0x10000u) % (4u | 1u)) & 7u) {
                l0 = (long)((unsigned long)l0 + (u3 - (unsigned)((unsigned)(u0 || (unsigned)((short)a0[i0 & 3u] > (signed char)0x4997bb5au)) && (unsigned)s1)));
                r0.x = (unsigned)(g0 < g0);
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        r0.y ^= ((unsigned)(signed char)(unsigned)((int)((unsigned)w0 % (p0 | 1u)) >= (int)0xf75ec3d2u) & i2);
                        case 1u: ;
                        m0 ^= (unsigned)((unsigned)x0 < (unsigned)((int)i2 >= (int)0x80000000u));
                    } while (i2++ < 7u && 9u);
                    switch ((unsigned)((short)(unsigned)d0 > (signed char)m0) & 7u) {
                        d0 = d0 * 0.5 + (double)((v0 % (9u | 1u)) & 1023u);
                        if ((1u * (unsigned)h1)) goto L1;
                        h1 = (unsigned short)(h1 + (i1 ^ m0));
                    }
                }
                case 4u: ;
                case 3u: ;
            }
            if ((unsigned)!(unsigned)((short)0xf687c110u > (signed char)m0)) break;
        }
        *q0 += (unsigned)((unsigned)((int)*q0 >= (int)(unsigned)l0) || (unsigned)e0);
        if (0x80000000u) {
            c1 = (signed char)(unsigned)(0x40fa693fu && v0);
            { unsigned t1; double z1; if (((unsigned)(signed char)((unsigned)(p2 == 0x80000000u) - r0.y)) & 1u) { t1 = ((unsigned)((short)0x10000u > (signed char)garr[u2 & 7u]) ^ (unsigned)d0); z1 = (double)((((unsigned)s0 | (unsigned)(x0 >> 70))) & 255u); } if (((unsigned)(signed char)((unsigned)(p2 == 0x80000000u) - r0.y)) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                garr[(v0 >> (fuel & 31u)) & 7u] = (4u ^ (unsigned)x0);
                if ((unsigned)((unsigned)((int)0x2f47770u < (int)0x80000000u) || (unsigned)f0)) goto L0;
                w0 = w0 * 6364136223846793005ull + a0[i0 & 3u];
            }
            for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (i2 * m0));
            }
            u1 = (unsigned)((int)u1 >= (int)u1);
            while (-(unsigned)((unsigned)e0 && (0x7fffffffu ^ r0.y))) { if (--fuel == 0u) goto done;
                break; (void)(8u);
                for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)(2u && 0x7fffffffu)) break;
                    if ((a0[u1 & 3u] + ((unsigned)l0 / ((unsigned)s0 | 1u)))) continue;
                    if (((unsigned)c1 & r0.x)) {
                        if ((unsigned)(short)((unsigned)(x0 >> 70) >> (0xf00d6a1du & 31u))) break;
                    } else {
                        e0 = e0 * 0.5L + (long double)((unsigned)b0 & 1023u);
                        l0 = (long)((unsigned long)l0 + ((unsigned)(short)(unsigned)(r0.y < (1u % ((unsigned)w0 | 1u))) << (0x7dd7c23du & 31u)));
                        h1 = (unsigned short)(h1 + (unsigned)((short)(unsigned)e0 > (signed char)((u3 ^ (0x7fffffffu + r0.y)) + u2)));
                    }
                    if (*mp) {
                        s0 = (int)u1;
                        if ((p2 ^ 0xb9b70d17u)) break;
                        g1 += (unsigned)((unsigned)s1 && (r0.y & (unsigned)((unsigned)c0 == i1)));
                        if ((unsigned)((int)fuel < (int)a0[u1 & 3u])) break;
                        s0 = (int)(unsigned)(0x42066745u < r0.x);
                        if (garr[i1 & 7u]) break;
                    } else {
                        s1 = (int)((unsigned)s1 + ~(unsigned)(p2 && (unsigned)(unsigned char)(unsigned)((short)0x80000000u > (signed char)(unsigned)((int)(unsigned)((int)m0 >= (int)r0.y) < (int)garr[i1 & 7u]))));
                        do { if (--fuel == 0u) goto done;
                            goto L4;
                            f0 = f0 * 0.5f + (float)(((unsigned)((int)(unsigned)b0 < (int)(unsigned)((int)r0.x < (int)(unsigned)((short)u1 > (signed char)4u))) / (m0 | 1u)) & 255u);
                        } while (i2++ < 5u && (unsigned)((int)(unsigned)(short)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)g1) < (int)(unsigned)d0));
                        if (-((unsigned)w0 & (unsigned)l0)) break;
                        break; (void)((unsigned)(9u || *mp));
                    }
                }
                b0 = (unsigned)((short)i2 > (signed char)(unsigned)((unsigned)(signed char)(7u & ((unsigned)b0 / (u1 | 1u))) && u0)) != 0u;
            }
        }
        u0 = u0 * 0x9e3779b1u + (*mp & (u1 | (unsigned)((short)0x8e37c9c8u > (signed char)(unsigned)(0xa2dbcd1eu == garr[u2 & 7u]))));
    }
    if (r0.x) goto L3;
    h0 = (short)(unsigned)(*q0 < a0[u1 & 3u]);
    x0 = x0 * 0x100000001b3ull + u1;
    while (i0++ < 5u && (unsigned)((unsigned)c1 || (unsigned)((int)1u >= (int)*q0))) { if (--fuel == 0u) goto done;
        if ((fuel - *q0)) break;
        if (((unsigned)h1 % ((unsigned)((int)(unsigned)d0 >= (int)0xe5834f00u) | 1u))) {
            if ((p0 << ((unsigned)c1 & 31u))) goto L4;
            while ((i0 | garr[u2 & 7u])) { if (--fuel == 0u) goto done;
                if ((garr[i1 & 7u] ? 0u : p0)) break;
                switch ((unsigned)((0xffffffffu - (unsigned)e0) == u0) & 7u) {
                    case 0u: ;
                }
                w0 = w0 * 6364136223846793005ull + ((0xf270564cu * ((9u ^ (unsigned)c1) >> (0x7fffffffu & 31u))) + 0xffffffffu);
                if ((7u + ((unsigned)(x0 >> 70) + (unsigned)f0))) break;
                u1 += ((unsigned)s1 ^ 0x7fffffffu);
                h1 = (unsigned short)(h1 + (((unsigned)w0 >> ((unsigned)l0 & 31u)) * (unsigned)(unsigned char)(a0[u1 & 3u] - (unsigned)(i0 == (unsigned)(x0 >> 70)))));
            }
            *mp = (unsigned)(signed char)((unsigned)(signed char)(unsigned)((unsigned)d0 == (unsigned)c0) >> (0xdc4eba95u & 31u));
            *mp = (unsigned)((int)r0.x >= (int)(unsigned)(w0 >> 29));
            if ((*q0 & garr[i1 & 7u])) goto L0;
        }
        if (0x62f81153u) goto L3;
    }
    for (;;) { if (--fuel == 0u) goto done;
        if (0xc845ae2cu) break;
        if (-(unsigned)((unsigned)((unsigned)(x0 >> 70) && garr[i1 & 7u]) < 0x7fffffffu)) {
            if ((unsigned)((int)r0.x >= (int)(0x10000u + fuel))) break;
            if (g1) break;
            r0.y ^= *q0;
        }
        while (i1++ < 3u && 0xc02ad37u) { if (--fuel == 0u) goto done;
            g1 += ~((unsigned)(0xffffffffu || 0xffffffffu) / (((unsigned)h0 ^ (0xffffffffu | garr[u2 & 7u])) | 1u));
            s1 = (int)((unsigned)s1 + (unsigned)!(unsigned)(p2 && ((0x80000000u ? (unsigned)c0 : a0[u1 & 3u]) << ((unsigned)(w0 >> 29) & 31u))));
            for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(signed char)(unsigned)((int)garr[i1 & 7u] >= (int)0x10000u));
                if (fuel < 8u) return (unsigned)((int)i2 < (int)(unsigned)((int)(unsigned)c0 < (int)(u3 | (a0[i0 & 3u] ^ 0x10000u))));
                g1 += (unsigned)(short)(unsigned)((int)(5u & (unsigned)c1) >= (int)(unsigned)x0);
                if ((p1 + 0x10000u)) break;
            }
            if (fuel < 8u) return (unsigned)((int)(unsigned)w0 < (int)u0);
            break; (void)((unsigned)(unsigned char)(unsigned)((short)p0 > (signed char)(unsigned)(unsigned char)((unsigned)s0 / (p0 | 1u))));
        }
        { unsigned t2; double z2; if ((((unsigned)h1 - p1)) & 1u) { t2 = r0.y; z2 = (double)(((unsigned)((int)(unsigned)s1 < (int)(*mp % (r0.y | 1u)))) & 255u); } if ((((unsigned)h1 - p1)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            u0 = u0 * 0x9e3779b1u + (0x80000000u + (0xffffffffu >> (~(unsigned)((unsigned)s0 || (unsigned)((int)3u < (int)0xcf82f2fcu)) & 31u)));
            v0 = (unsigned)((short)((unsigned)f0 * *mp) > (signed char)(unsigned)((unsigned)s1 && (6u % ((unsigned)d0 | 1u))));
        }
        if (u2) continue;
    }
    if ((unsigned)((int)(unsigned)d0 >= (int)(unsigned)(u3 == (unsigned)c0))) {
        goto L2;
        if (((g0 | *mp) | fuel)) goto L1;
    } else {
        if (((unsigned)((int)0x7fffffffu < (int)(unsigned)h1) * p0)) goto L2;
        for (;;) { if (--fuel == 0u) goto done;
            u0 = u0 * 0x9e3779b1u + 0xa60ebc6eu;
        }
        if (p2) goto L3;
    }
    a0[9u & 3u] = (((unsigned)b0 - (9u ? u1 : u3)) % ((unsigned)f0 | 1u));
    goto done;
    u3 = u3 * 0x9e3779b1u + (garr[i1 & 7u] % (u0 | 1u));
    if ((9u * (unsigned)x0)) goto L0;
    if (~(unsigned)((short)a0[i0 & 3u] > (signed char)(unsigned)h1)) goto L2;
    if ((unsigned)((unsigned)(short)(u1 ^ 0x80000000u) < *mp)) {
        if (p2) goto L3;
        for (;;) { if (--fuel == 0u) goto done;
            switch (0xc16968a0u & 7u) {
                r0.x = (0x10000u % (0x6c8f2d1cu | 1u));
                g0 = (unsigned)((int)(*q0 >> (0x6fa73619u & 31u)) >= (int)(u2 >> ((unsigned)e0 & 31u)));
                switch ((0x7fffffffu % (*mp | 1u)) & 7u) {
                    s1 = (int)((unsigned)s1 + (8u & (unsigned)(short)(r0.x ? (unsigned)w0 : (unsigned)s0)));
                    b0 = ((unsigned)w0 ^ ((unsigned)((int)0xa62deabeu >= (int)(unsigned)f0) | (*q0 / (u1 | 1u)))) != 0u;
                }
                do { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)((int)(9u | (unsigned)(0xffffffffu && (unsigned)s1)) >= (int)u0);
                    break; (void)((((unsigned)l0 - 0x700512bu) | (unsigned)d0));
                    v0 = (unsigned)(0x10000u == 7u);
                    case 1u: ;
                    w0 = w0 * 6364136223846793005ull + (unsigned)((short)((unsigned)f0 << (2u & 31u)) > (signed char)(g0 << (u0 & 31u)));
                } while (i1++ < 2u && (v0 * 8u));
            }
            if (((unsigned)f0 ^ 0x80000000u)) break;
            h1 = (unsigned short)(h1 + (((unsigned)((int)2u < (int)(unsigned)c1) ? a0[i0 & 3u] : 0x10000u) >> (p2 & 31u)));
            g1 += ((0x7fffffffu / (0xf6c26fe4u | 1u)) ^ (unsigned)((unsigned)c0 && (unsigned)h1));
        }
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((0x4e9747b4u - 0x10000u));
            *mp = ((unsigned)(x0 >> 70) << ((p0 & (unsigned)((short)p0 > (signed char)(unsigned)((int)(unsigned)s1 < (int)i1))) & 31u));
            if ((unsigned)!(garr[u2 & 7u] * (*mp << (a0[i0 & 3u] & 31u)))) break;
            do { if (--fuel == 0u) goto done;
                *q0 += ((garr[u2 & 7u] << ((unsigned)(0x7fffffffu < ((unsigned)(w0 >> 29) ^ fuel)) & 31u)) ^ a0[i0 & 3u]);
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    switch (a0[i0 & 3u] & 7u) {
                        s0 = (int)(unsigned)((int)0xb987d2cbu < (int)(r0.y >> (0xc9ed7ab9u & 31u)));
                        u2 += ((0xe29b777u ^ (unsigned)w0) & (unsigned)((unsigned)s1 || (unsigned)h1));
                        goto done;
                        if (3u) break;
                        b0 = g0 != 0u;
                    }
                    break; (void)((unsigned)(0x9c6116c9u && (unsigned)f0));
                    break; (void)(u2);
                    if (fuel < 8u) return r0.y;
                    if (*q0) break;
                }
            } while (i1++ < 3u && (unsigned)(~(5u & (unsigned)e0) && 0x10000u));
        }
        if (((unsigned)(r0.x || p0) * 0xbb38c90du)) goto L1;
        if ((unsigned)b0) {
            if (((r0.x / (garr[i1 & 7u] | 1u)) & *q0)) goto done;
            *q0 += (unsigned)((unsigned)((short)i0 > (signed char)u1) == (unsigned)(r0.y == *mp));
            goto done;
            if ((unsigned)(0x10000u || a0[i0 & 3u])) goto L0;
            g1 += (5u - 1u);
        } else {
            g0 = (unsigned)((0x7fffffffu - 0x10000u) == 0x80000000u);
            if ((0x10000u ^ (unsigned)s0)) goto L2;
            if ((8u - g0)) goto L3;
            if ((unsigned)((int)0x3d433336u < (int)g0)) {
                h0 = (short)(unsigned)(unsigned char)((unsigned)(short)((unsigned)(signed char)((unsigned)c1 << ((unsigned)d0 & 31u)) >> ((i0 | p1) & 31u)) % ((unsigned)(w0 >> 29) | 1u));
                if (u2) goto done;
                if (1u) goto L3;
                q0 = &garr[(unsigned)((int)0xe23ee684u >= (int)(((unsigned)c1 - (unsigned)(w0 >> 29)) % (u1 | 1u))) & 7u];
                *mp = (unsigned)((unsigned)((unsigned)s0 < ((unsigned)((int)(unsigned)x0 >= (int)0x7fffffffu) << (0u & 31u))) == 0x7fffffffu);
                r0.x = ((g0 | (garr[u2 & 7u] & (unsigned)c1)) & -(i2 % ((unsigned)c1 | 1u)));
            } else {
                f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)(r0.y == u0) - (0xcfbdcef9u / (0x4e9207b1u | 1u))) < 9u) & 255u);
                if ((unsigned)((int)(0xb061c38cu >> ((unsigned)e0 & 31u)) < (int)garr[u2 & 7u])) goto L3;
                if ((unsigned)((int)g0 >= (int)g1)) goto L1;
            }
        }
        do { if (--fuel == 0u) goto done;
            switch ((0xe5059a21u / ((unsigned)(x0 >> 70) | 1u)) & 7u) {
                f0 = f0 * 0.5f + (float)((unsigned)((short)(unsigned)(0xf8157f7au && 8u) > (signed char)(unsigned)s1) & 255u);
                case 1u: ;
                if (u3 == 7u) return (unsigned)((short)(unsigned)(((unsigned)h1 & r0.x) && m0) > (signed char)i1);
                w0 ^= (unsigned long long)p1 << ((unsigned)(((r0.y % (g1 | 1u)) % ((unsigned)(8u < p1) | 1u)) == 0x10000u) & 63u);
                l0 = (long)((unsigned long)l0 + ((unsigned)(fuel == u3) | (unsigned)(x0 >> 70)));
                garr[(unsigned)(short)(0x2b34d5d1u + fuel) & 7u] = (unsigned)(signed char)(i0 * p0);
            }
        } while (i0++ < 5u && (unsigned)(0xc5221c10u || 0xf443a4b0u));
    }
    c0 = (unsigned char)(unsigned)((unsigned)d0 < *mp);
    i2 = ((unsigned)l0 / (9u | 1u)) & 15u;
    c0 = (unsigned char)(unsigned)((unsigned)((unsigned)(short)(m0 ^ (unsigned)f0) && v0) || (9u * 0xffffffffu));
    if (((unsigned)b0 / ((a0[i0 & 3u] >> (0xffffffffu & 31u)) | 1u))) goto L0;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (0xffffffffu) {
            if ((unsigned)!((unsigned)(i1 < 8u) & (unsigned)(x0 >> 70))) break;
            break; (void)(-((0x7fffffffu + (unsigned)(x0 >> 70)) % ((unsigned)h0 | 1u)));
            break; (void)((unsigned)s1);
            goto L3;
            garr[p1 & 7u] = (((unsigned)l0 * (unsigned)e0) & garr[i1 & 7u]);
        }
        w0 = w0 * 6364136223846793005ull + ((unsigned)l0 ^ m0);
        w0 = w0 * 6364136223846793005ull + ((unsigned)((short)(unsigned)(signed char)(0x80629458u & (unsigned)c0) > (signed char)0x2d20d3aau) << ((unsigned)c1 & 31u));
    }
    for (;;) { if (--fuel == 0u) goto done;
        a0[2u & 3u] = ((p2 * (unsigned)h0) * (unsigned)(r0.y && 9u));
    }
    switch ((unsigned)((int)(unsigned)((short)v0 > (signed char)*mp) >= (int)(unsigned)w0) & 7u) {
        if (((unsigned)h1 & 9u)) break;
    }
    c1 = (signed char)(((unsigned)((int)r0.x >= (int)u1) ^ 0x53ff0306u) * 0x7fffffffu);
    if (p0) {
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            u2 = (unsigned)((int)g0 >= (int)fuel);
            for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (*mp) break;
            }
            do { if (--fuel == 0u) goto done;
                if ((unsigned)!(unsigned)((short)(unsigned)l0 > (signed char)i2)) break;
                v0 = ((unsigned)d0 + (unsigned)b0);
            } while (i1++ < 5u && r0.x);
            g1 += (unsigned)((unsigned)((int)*q0 < (int)0x10000u) < (unsigned)((short)0xffffffffu > (signed char)u1));
            if ((r0.y & 0x7fffffffu)) break;
            if ((p2 * 0x10000u)) break;
        }
        r0.y ^= (unsigned)((unsigned)c0 < (unsigned)!((unsigned)((unsigned)c1 == (unsigned)(x0 >> 70)) % (((unsigned)s1 << (1u & 31u)) | 1u)));
        if (fuel < 8u) return (0x735f0a4cu / (0xffffffffu | 1u));
        a0[*q0 & 3u] = ((unsigned)(m0 == (unsigned)(0xffffffffu && u3)) | garr[u2 & 7u]);
        if (2u) {
            if ((0x425790c3u - r0.y)) goto L2;
            u1 = (unsigned)(0x7fffffffu < (unsigned)(3u < u0));
            if ((unsigned)((int)2u >= (int)m0)) {
                u0 ^= a0[i0 & 3u];
                if ((fuel * (unsigned)((short)4u > (signed char)i0))) goto L2;
            }
            if (1u) {
                for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)p2;
                }
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)(((unsigned)!(unsigned)((int)((unsigned)e0 + (unsigned)f0) < (int)(unsigned)((int)0xd20b47c9u >= (int)0xffffffffu)) ^ g1) & 1023u);
                    break; (void)(v0);
                }
                r0.x = (unsigned)((int)g1 < (int)((unsigned)((short)garr[i1 & 7u] > (signed char)v0) | (unsigned)s1));
                goto L4;
            }
            { unsigned t3; double z3; if ((((unsigned)b0 | (unsigned)((int)p0 < (int)0x631dff64u))) & 1u) { t3 = (0xbc1b73dbu ? 0xffffffffu : (unsigned)f0); z3 = (double)((((unsigned)((unsigned)(w0 >> 29) < (unsigned)c1) & i2)) & 255u); } if ((((unsigned)b0 | (unsigned)((int)p0 < (int)0x631dff64u))) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                goto L4;
                if ((0xe67d11bu - (unsigned)s0)) {
                    goto L4;
                    if ((unsigned)(unsigned char)((unsigned)e0 + (2u & u3))) goto done;
                } else {
                    r0.x = ((unsigned)((int)(unsigned)x0 < (int)0x315fb507u) | 0x88389376u);
                }
                if ((v0 * (garr[i1 & 7u] & p1))) goto L0;
                d0 = d0 * 0.5 + (double)(2u & 1023u);
                if (0x8d1b5ef1u) {
                    { unsigned t4; double z4; if (((unsigned)((unsigned)!(unsigned)((short)(unsigned)x0 > (signed char)v0) || (unsigned)d0)) & 1u) { t4 = (unsigned)((short)4u > (signed char)fuel); z4 = (double)(((unsigned)((int)(unsigned)((unsigned)l0 < (unsigned)e0) < (int)0xcadf6fcau)) & 255u); } if (((unsigned)((unsigned)!(unsigned)((short)(unsigned)x0 > (signed char)v0) || (unsigned)d0)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                        goto L3;
                        if ((u2 >> (fuel & 31u))) goto L2;
                    }
                }
                if (((unsigned)w0 ? 0x9c05806u : r0.x)) goto L0;
            }
        } else {
            u3 = (unsigned)(unsigned char)(unsigned)(8u == (unsigned)((unsigned)c0 == (unsigned)x0));
            goto L3;
        }
        if ((unsigned)((0xfd4931dau >> (i0 & 31u)) || (unsigned)s1)) goto L1;
    }
    if (1u) {
        c0 = (unsigned char)(unsigned)((short)(unsigned)((short)(unsigned)h0 > (signed char)i1) > (signed char)(0x7e4be9ccu * a0[i0 & 3u]));
        switch ((r0.y - r0.y) & 7u) {
            d0 = d0 * 0.5 + (double)(((unsigned)x0 + (unsigned)((-(unsigned)(0x80000000u && (unsigned)s1) - (unsigned)x0) && 0x1851135u)) & 1023u);
            *q0 = (unsigned)((int)(unsigned)h1 >= (int)i0);
            s1 = (int)((unsigned)s1 + (unsigned)(0xee197292u && r0.y));
            while (u0) { if (--fuel == 0u) goto done;
                i2 = (unsigned)((u0 >> ((unsigned)h0 & 31u)) && (unsigned)e0) & 15u;
                f0 = f0 * 0.5f + (float)((0x8fc4662du ^ ((unsigned)!(unsigned)((short)i0 > (signed char)0x10000u) / (0x80000000u | 1u))) & 255u);
                a0[0x80000000u & 3u] = ((unsigned)(0x9df0defau < a0[u1 & 3u]) << ((unsigned)((int)(unsigned)x0 >= (int)0xff833b19u) & 31u));
                case 5u: ;
                while (i1++ < 2u && (g1 ? i1 : i1)) { if (--fuel == 0u) goto done;
                    case 2u: ;
                    garr[p1 & 7u] = (i1 << (p0 & 31u));
                    if (u3 == 7u) return ((unsigned)(signed char)(i0 * garr[i1 & 7u]) + (unsigned)((unsigned)s0 == u0));
                    h1 = (unsigned short)(h1 + (unsigned)((short)(0x342f979u ^ (unsigned)w0) > (signed char)(1u | 4u)));
                    case 6u: ;
                }
                do { if (--fuel == 0u) goto done;
                    while (((unsigned)c0 << (p0 & 31u))) { if (--fuel == 0u) goto done;
                        default: ;
                        if (-(0xcc811133u & 1u)) continue;
                        *mp = ((unsigned)f0 % (u2 | 1u));
                        case 3u: ;
                    }
                    *q0 += (unsigned)(signed char)(unsigned)(r0.y && (0x142ca9bdu - (unsigned)(g1 < 0x80000000u)));
                } while (i1++ < 2u && ((unsigned)d0 ? 0x10000u : 0x382f55beu));
            }
            if ((unsigned)(signed char)(0x88a227adu << (~((unsigned)f0 << ((unsigned)x0 & 31u)) & 31u))) goto done;
        }
        if ((unsigned)((unsigned)((int)u2 >= (int)a0[u1 & 3u]) == (unsigned)(x0 >> 70))) goto L2;
        g0 = ((unsigned)x0 / ((unsigned)((int)(unsigned)c0 < (int)6u) | 1u));
        if (0xffffffffu) goto L0;
        q0 = &garr[1u & 7u];
    } else {
        v0 = ((unsigned)(w0 >> 29) + m0);
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(unsigned char)(a0[i0 & 3u] - a0[u1 & 3u])) goto L2;
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((unsigned)!(0x7fffffffu * 9u) ^ 0x10000u)) break;
                h0 = (short)(unsigned)((int)(unsigned)((unsigned)c0 == (unsigned)s1) >= (int)(m0 >> (*mp & 31u)));
                r0.y ^= (((unsigned)h0 + u0) - (unsigned)((int)p0 < (int)(unsigned)(short)(garr[u2 & 7u] * 6u)));
            }
            w0 ^= (unsigned long long)0x10000u << ((g0 % (0x10000u | 1u)) & 63u);
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (((0x80000000u - u1) >> (i1 & 31u))) continue;
                u1 = u1 * 0x9e3779b1u + a0[u1 & 3u];
                *mp = (unsigned)d0;
            }
            m0 ^= (unsigned)(unsigned char)((0x80000000u + 2u) | (unsigned)d0);
            if ((unsigned)w0) break;
        }
        if ((unsigned)!((unsigned)((unsigned)h1 && (unsigned)w0) * (unsigned)d0)) goto L1;
        if ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)4u)) {
            if ((unsigned)(p1 < 0x10000u)) goto L2;
            switch (5u & 7u) {
                if ((fuel << ((unsigned)(a0[i0 & 3u] || fuel) & 31u))) goto L3;
                case 5u: ;
                if ((7u * r0.x)) {
                    if (0x80000000u) goto L2;
                    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        if (u3 == 7u) return ((unsigned)(x0 >> 70) | (unsigned)((unsigned)c0 == ~(unsigned)((int)a0[i0 & 3u] >= (int)*q0)));
                        switch (9u & 7u) {
                            g1 += ((unsigned)(x0 >> 70) * (unsigned)((int)(unsigned)c1 < (int)(u0 << (0x7fffffffu & 31u))));
                            goto L3;
                            a0[0x796e4e4du & 3u] = (((unsigned)c1 / (0x5389a31du | 1u)) | 0xd87cad7eu);
                        }
                        if (*q0) break;
                        l0 = (long)((unsigned long)l0 + (unsigned)(a0[i0 & 3u] == i1));
                        s0 = (int)((((unsigned)f0 % ((unsigned)l0 | 1u)) / (i0 | 1u)) & ((unsigned)w0 + 6u));
                        goto L4;
                    }
                }
                default: ;
            }
        }
    }
    do { if (--fuel == 0u) goto done;
        u1 = (p0 ? (unsigned)(fuel < i2) : a0[i0 & 3u]);
    } while (i0++ < 5u && (u3 & 0x9262eba5u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    w0 = w0 * 6364136223846793005ull + ((i1 / ((unsigned)((int)9u >= (int)i0) | 1u)) & ((unsigned)c0 - i1));
    h1 = (unsigned short)(h1 + ((unsigned)((int)(0xf4114a2du / (u3 | 1u)) < (int)garr[i1 & 7u]) * p0));
    *mp = (unsigned)(((unsigned)s1 << (0x10000u & 31u)) < ((a0[i0 & 3u] * (unsigned)l0) << (8u & 31u)));
    { unsigned t0; double z0; if ((((unsigned)s0 ? (unsigned)w0 : (unsigned)f0)) & 1u) { t0 = (fuel >> ((unsigned)w0 & 31u)); z0 = (double)(((unsigned)((int)(unsigned)b0 < (int)r0.y)) & 255u); } if ((((unsigned)s0 ? (unsigned)w0 : (unsigned)f0)) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
        if ((1u % ((8u - r0.y) | 1u))) {
            g0 = 0xee481a2du;
            L0: if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(a0[i0 & 3u] < u2), ((unsigned)e0 / (i0 | 1u)), (0u & (unsigned)l0)); }
            g0 = ~((unsigned)w0 ? (unsigned)b0 : (unsigned)((int)p0 < (int)0x51a8c579u));
            while (i0++ < 2u && (unsigned)!(unsigned)((int)(p1 + *q0) >= (int)0x943c4e14u)) { if (--fuel == 0u) goto done;
                if (0x4e5dafe2u) continue;
                L1: if (--fuel == 0u) goto done;
                if (m0) continue;
                for (;;) { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)(w0 >> 29) || 0x80000000u)) break;
                    w0 = w0 * 6364136223846793005ull + -(((unsigned)(x0 >> 70) + (unsigned)(u0 && u2)) * (u1 << ((unsigned)h1 & 31u)));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)b0, (p2 | (unsigned)((int)8u < (int)5u)), ((unsigned)(x0 >> 70) ^ (r0.x + (unsigned)f0))); }
                    for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                        h0 = (short)(unsigned)(short)(unsigned)((int)((unsigned)w0 - a0[u1 & 3u]) < (int)(unsigned)(signed char)(3u / (p0 | 1u)));
                        w0 = w0 * 6364136223846793005ull + (unsigned)((unsigned)(signed char)(fuel / (0x80000000u | 1u)) || ((unsigned)f0 * v0));
                        w0 = w0 * 6364136223846793005ull + *q0;
                    }
                    do { if (--fuel == 0u) goto done;
                        { unsigned t1; double z1; if ((0xfe460890u) & 1u) { t1 = (unsigned)(*mp || (unsigned)((unsigned)d0 < 0x5cf92272u)); z1 = (double)((((unsigned)c1 >> ((i0 | *q0) & 31u))) & 255u); } if ((0xfe460890u) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                            v0 = (unsigned)!((unsigned)c0 / ((unsigned)(9u == (unsigned)x0) | 1u));
                        }
                        u3 = u3 * 0x9e3779b1u + 6u;
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(w0 >> 29), (unsigned)(i1 == (0x601c403cu * 0xffffffffu)), 0x7fffffffu); }
                        L2: if (--fuel == 0u) goto done;
                        v0 = (unsigned)(i2 || r0.x);
                        if ((unsigned)(0x7fffffffu || p1)) break;
                    } while (i2++ < 3u && ((unsigned)(x0 >> 70) - ((unsigned)s1 % (garr[u2 & 7u] | 1u))));
                }
                L3: if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)c1, (7u & u1), (unsigned)!(g0 | (unsigned)b0)); }
            }
            switch ((unsigned)l0 & 7u) {
                L4: if (--fuel == 0u) goto done;
                c0 = (unsigned char)(unsigned)(a0[u1 & 3u] == (unsigned)(unsigned char)(unsigned)(i2 == (unsigned)b0));
                if ((unsigned)s0) break;
                q0 = &garr[((unsigned)(garr[u2 & 7u] == (0xffffffffu & i1)) << ((unsigned)(short)(unsigned)((short)p0 > (signed char)(unsigned)(x0 >> 70)) & 31u)) & 7u];
                s1 = (int)((unsigned)s1 + (unsigned)(0x80000000u || (unsigned)((unsigned)(w0 >> 29) || 6u)));
            }
        }
        { unsigned t2; double z2; if (((unsigned)h0) & 1u) { t2 = u0; z2 = (double)(((unsigned)(unsigned char)((p0 ^ (unsigned)s0) * u1)) & 255u); } if (((unsigned)h0) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            if ((unsigned)(short)(unsigned)((int)0xe5081a84u < (int)r0.x)) goto done;
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(w0 >> 29), (0x10000u + (unsigned)(0x80000000u < 0xf2444803u)), (unsigned)c1); }
        }
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            i0 = (u2 - 0xb89fd84fu) & 15u;
            if ((a0[u1 & 3u] ^ ((unsigned)w0 + 0xffffffffu))) break;
        }
        l0 = (long)((unsigned long)l0 + i2);
    }
    if ((unsigned)((int)g1 < (int)0x7fffffffu)) goto L1;
    if (u3 == 7u) return (unsigned)((short)(unsigned)(w0 >> 29) > (signed char)(unsigned)((int)0x10000u < (int)(unsigned)(signed char)(unsigned)((int)(unsigned)h0 < (int)0xe2b93cd3u)));
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(g1 || (3u << ((unsigned)h1 & 31u))), p0, (unsigned)((int)(unsigned)(x0 >> 70) >= (int)0x88245610u)); }
    { unsigned t3; double z3; if ((0x7fffffffu) & 1u) { t3 = fuel; z3 = (double)(((0xffffffffu ? g1 : *mp)) & 255u); } if ((0x7fffffffu) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
        do { if (--fuel == 0u) goto done;
            if ((p0 & (m0 >> (p1 & 31u)))) break;
            break; (void)(6u);
            c1 = (signed char)u0;
        } while (i0++ < 3u && (unsigned)(short)(unsigned)((int)(unsigned)((short)g1 > (signed char)9u) >= (int)fuel));
        g0 = (unsigned)w0;
        c1 = (signed char)i2;
        if ((0x80000000u * (unsigned)h1)) goto L4;
        goto L0;
        m0 ^= (u0 ? g1 : p2);
    }
    l0 = (long)((unsigned long)l0 + (3u / (((unsigned)h1 / ((r0.y * u3) | 1u)) | 1u)));
    if (((unsigned)l0 << (((unsigned)e0 | (unsigned)b0) & 31u))) goto done;
    if (budget != 0u) { budget -= 1u; u0 = fn0(4u, (4u - (unsigned)!(unsigned)((int)*mp >= (int)garr[u2 & 7u])), (unsigned)((unsigned)((int)(unsigned)x0 < (int)8u) && 0x8c55fcc3u)); }
    u2 ^= (a0[u1 & 3u] + (unsigned)((int)g1 < (int)(unsigned)!((unsigned)(x0 >> 70) ? i2 : fuel)));
    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)s1 < (int)(unsigned)(v0 || g0))) {
            switch ((p0 | g0) & 7u) {
                l0 = (long)((unsigned long)l0 + ((p0 - u2) >> ((unsigned)b0 & 31u)));
                u2 = u2 * 0x9e3779b1u + -((unsigned)(unsigned char)(((unsigned)c1 * garr[i1 & 7u]) ^ (unsigned)e0) * garr[u2 & 7u]);
            }
            if ((0xa8a5ac01u ^ fuel)) break;
            r0.x = (0x10000u >> ((unsigned)c0 & 31u));
        } else {
            if (((unsigned)s0 << (garr[u2 & 7u] & 31u))) {
                g0 = (unsigned)((unsigned)e0 < (unsigned)c1);
                h1 = (unsigned short)(h1 + (unsigned)((short)((unsigned)x0 / (a0[u1 & 3u] | 1u)) > (signed char)0x5aa0cca2u));
                if ((unsigned)((int)0x10000u >= (int)(unsigned)((short)0xffffffffu > (signed char)i1))) goto L0;
                if (u0) {
                    if (0x10000u) break;
                    if (((unsigned)s1 + (unsigned)((unsigned)c1 < garr[u2 & 7u]))) goto L1;
                    switch (r0.y & 7u) {
                        c1 = (signed char)(u1 & p0);
                        r0.y ^= (unsigned)((short)u3 > (signed char)(unsigned)x0);
                        if ((i1 ? (unsigned)(x0 >> 70) : (unsigned)d0)) continue;
                        q0 = &garr[(unsigned)b0 & 7u];
                    }
                    while (m0) { if (--fuel == 0u) goto done;
                        *q0 += u3;
                        if ((unsigned)((int)(g1 % (p0 | 1u)) < (int)0x7bb48b32u)) continue;
                        i2 = (unsigned)((int)p1 < (int)0x10000u) & 15u;
                    }
                    h0 = (short)~(a0[i0 & 3u] << ((unsigned)(x0 >> 70) & 31u));
                    b0 = ((unsigned)(unsigned char)((unsigned)h1 - (unsigned)(x0 >> 70)) & (unsigned)b0) != 0u;
                } else {
                    garr[(unsigned)(0xffffffffu == (unsigned)c0) & 7u] = (unsigned)((int)(0x6fcf9334u - 0x7fffffffu) >= (int)(unsigned)((short)(unsigned)h1 > (signed char)(unsigned)(u2 < (unsigned)w0)));
                }
                f0 = f0 * 0.5f + (float)(i0 & 255u);
                w0 = w0 * 6364136223846793005ull + ((unsigned)(signed char)((unsigned)c1 >> (g1 & 31u)) / ((unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)!(u0 >> (5u & 31u))) | 1u));
            }
            for (i1 = 1u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                g1 += p1;
                l0 = (long)((unsigned long)l0 + ~(p2 & ((0x41145129u - ((unsigned)l0 << (garr[i1 & 7u] & 31u))) * i1)));
                if ((unsigned)((int)g1 >= (int)(9u << (0x7fffffffu & 31u)))) {
                    garr[(4u % ((unsigned)(w0 >> 29) | 1u)) & 7u] = (unsigned)h0;
                    e0 = e0 * 0.5L + (long double)((unsigned)((unsigned)d0 == (unsigned)s0) & 1023u);
                    break; (void)(((0xd138d893u * garr[u2 & 7u]) & 3u));
                    if ((unsigned)(signed char)(6u << (0x10000u & 31u))) {
                        w0 = w0 * 6364136223846793005ull + (unsigned)(u2 && ((unsigned)!(unsigned)((int)(unsigned)w0 < (int)5u) ^ (0x1ebb5be2u | r0.y)));
                        if ((*q0 / ((unsigned)h1 | 1u))) goto L2;
                        d0 = d0 * 0.5 + (double)((unsigned)((unsigned)c1 == (unsigned)c1) & 1023u);
                        if (r0.y) break;
                        c0 = (unsigned char)((unsigned)(w0 >> 29) & (-(u0 & u1) * (unsigned)s1));
                        if ((unsigned)(*mp || a0[u1 & 3u])) break;
                    }
                    if (r0.x) {
                        switch ((unsigned)(i1 && (unsigned)s1) & 7u) {
                            garr[u2 & 7u] = u0;
                            h0 = (short)(a0[i0 & 3u] % (u3 | 1u));
                        }
                        a0[u2 & 3u] = (unsigned)(0xb09e2168u || (unsigned)(0xa34e66beu == 0xe5ad11e3u));
                        m0 ^= ((unsigned)(w0 >> 29) * u1);
                        while ((r0.x % (2u | 1u))) { if (--fuel == 0u) goto done;
                            e0 = e0 * 0.5L + (long double)(~(unsigned)(garr[u2 & 7u] && r0.y) & 1023u);
                            if (u3 == 7u) return (i1 - ((unsigned)f0 * (garr[u2 & 7u] * g0)));
                        }
                    }
                    if (fuel) break;
                } else {
                    garr[m0 & 7u] = ((unsigned)((int)(unsigned)b0 >= (int)(unsigned)f0) << (((i2 | 0x80000000u) ^ 0xc4922564u) & 31u));
                }
            }
            g1 += (unsigned)((unsigned)c0 && garr[i1 & 7u]);
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)!(0x10000u ^ (unsigned)(p0 < (unsigned)b0))) break;
                if (budget != 0u) { budget -= 1u; u0 = fn0(5u, (unsigned)(short)(unsigned)((unsigned)(w0 >> 29) == (p0 + 5u)), (r0.y + (unsigned)l0)); }
                c0 = (unsigned char)0x7fffffffu;
                if (budget != 0u) { budget -= 1u; u0 = fn0((2u << ((0xffffffffu << (p2 & 31u)) & 31u)), (unsigned)h1, (unsigned)f0); }
            }
        }
        { unsigned t4; double z4; if ((((unsigned)l0 ^ (unsigned)((unsigned)(w0 >> 29) == (unsigned)w0))) & 1u) { t4 = (0x815c7e30u * g0); z4 = (double)(((u2 / ((unsigned)s1 | 1u))) & 255u); } if ((((unsigned)l0 ^ (unsigned)((unsigned)(w0 >> 29) == (unsigned)w0))) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
            do { if (--fuel == 0u) goto done;
                r0.x = (unsigned)((unsigned)((int)(unsigned)h1 < (int)garr[i1 & 7u]) && (0xd4fa0808u % (u3 | 1u)));
                for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (0u | (unsigned)(0x10000u < i1)));
                    do { if (--fuel == 0u) goto done;
                        if (((unsigned)x0 / (garr[u2 & 7u] | 1u))) goto L3;
                        x0 = x0 * 0x100000001b3ull + 0xd5b6d073u;
                        if (budget != 0u) { budget -= 1u; u3 = fn0(0x10000u, m0, 0x9312609fu); }
                        r0.x = (1u % (0xdf76d069u | 1u));
                        if ((unsigned)(short)((unsigned)x0 / (1u | 1u))) break;
                    } while (i0++ < 7u && (unsigned)(signed char)(unsigned)((short)(unsigned)w0 > (signed char)u0));
                }
                *q0 += 5u;
                if ((0x963971feu ^ (garr[u2 & 7u] % (0x80000000u | 1u)))) break;
            } while (i1++ < 7u && ((unsigned)(w0 >> 29) % (((unsigned)b0 + r0.y) | 1u)));
            r0.y ^= (unsigned)((unsigned)b0 || v0);
            while (i1++ < 5u && (unsigned)((unsigned)f0 || (0x607218c8u << (u1 & 31u)))) { if (--fuel == 0u) goto done;
                if (-(unsigned)(g1 && (0xd9c3d0d3u * p1))) break;
                do { if (--fuel == 0u) goto done;
                    if ((a0[i0 & 3u] + (4u % (a0[u1 & 3u] | 1u)))) break;
                    d0 = d0 * 0.5 + (double)((unsigned)h1 & 1023u);
                    if ((unsigned)((unsigned)x0 || 0x6ee8c9e3u)) break;
                } while (i2++ < 5u && ((unsigned)w0 << ((a0[u1 & 3u] ^ 0xffffffffu) & 31u)));
            }
        }
        { unsigned t5; double z5; if (((unsigned)!(0x7fffffffu >> ((unsigned)(unsigned char)((unsigned)c0 & garr[i1 & 7u]) & 31u))) & 1u) { t5 = fuel; z5 = (double)((0x7fffffffu) & 255u); } if (((unsigned)!(0x7fffffffu >> ((unsigned)(unsigned char)((unsigned)c0 & garr[i1 & 7u]) & 31u))) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)(unsigned char)(unsigned)(i1 || i0));
                if ((3u / (i2 | 1u))) break;
                if (((unsigned)s1 / ((unsigned)((unsigned)h0 < 0xcb001577u) | 1u))) break;
            }
            d0 = d0 * 0.5 + (double)((unsigned)((unsigned)((int)(unsigned)c1 >= (int)((unsigned)s0 % (0x4a189fd8u | 1u))) || a0[u1 & 3u]) & 1023u);
            h0 = (short)(unsigned)(0xfd7fbdffu || (unsigned)f0);
            d0 = d0 * 0.5 + (double)(((unsigned)(short)(0x80000000u + (unsigned)s1) >> ((0x923a08u ? (unsigned)e0 : i2) & 31u)) & 1023u);
        }
        switch (u2 & 7u) {
            while (i1++ < 4u && (unsigned)c0) { if (--fuel == 0u) goto done;
                r0.x = (u3 >> ((unsigned)(signed char)(r0.x ^ (*q0 | i2)) & 31u));
                if (fuel < 8u) return ((v0 & (unsigned)((unsigned)(0xc9547345u && a0[u1 & 3u]) && (unsigned)(w0 >> 29))) / (0x5ac5a3e7u | 1u));
            }
            break; (void)((0xe84ec606u | (u2 | garr[u2 & 7u])));
        }
    }
    *q0 += (unsigned)b0;
    *mp = ((unsigned)b0 ^ (unsigned)(a0[u1 & 3u] == 0xf2bf7534u));
    while (i0++ < 3u && (fuel << ((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)c1) & 31u))) { if (--fuel == 0u) goto done;
        e0 = e0 * 0.5L + (long double)(-((unsigned)s0 / (p0 | 1u)) & 1023u);
        h0 = (short)((unsigned)(x0 >> 70) ^ 0x80000000u);
        for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
            g0 = (~(((i1 / ((unsigned)h1 | 1u)) ^ a0[u1 & 3u]) << (0x5aab9a58u & 31u)) / (u2 | 1u));
            s1 = (int)((unsigned)s1 + ((unsigned)((int)(4u ^ u2) >= (int)0xbc85cb07u) | i0));
        }
    }
    c1 = (signed char)(i0 | 0xffffffffu);
    if ((unsigned)s0) {
        goto done;
        if (budget != 0u) { budget -= 1u; u2 = fn0(p0, i2, r0.y); }
        *q0 = (unsigned)b0;
        if (budget != 0u) { budget -= 1u; u1 = fn0((g0 >> (0x10000u & 31u)), 6u, ((i0 % (r0.x | 1u)) ^ (unsigned)l0)); }
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)s0) break;
        }
        c0 = (unsigned char)((unsigned)((unsigned)x0 && (0x5f704fcdu ? r0.y : (unsigned)s1)) >> (0xde94c7b5u & 31u));
    }
    *q0 = (fuel >> (u3 & 31u));
    while (i0++ < 4u && (v0 >> ((unsigned)e0 & 31u))) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + ((unsigned)h0 % ((unsigned)(unsigned char)(unsigned)((short)u2 > (signed char)(unsigned)h0) | 1u));
        if ((*q0 >> (p2 & 31u))) continue;
        d0 = d0 * 0.5 + (double)((unsigned)(short)((unsigned)h0 / ((unsigned)h1 | 1u)) & 1023u);
        f0 = f0 * 0.5f + (float)(~(unsigned)((unsigned)x0 < (0xb49e9fc5u & (unsigned)h0)) & 255u);
        continue; (void)((unsigned)!(unsigned)(fuel && v0));
        break; (void)((fuel - g1));
    }
    s0 = (int)((unsigned)c0 * 0x886c003cu);
    do { if (--fuel == 0u) goto done;
        if ((unsigned)b0) {
            s1 = (int)((unsigned)s1 + ((unsigned)x0 ^ (unsigned)((int)i0 >= (int)v0)));
            continue; (void)(0xfbf6c66cu);
        }
        switch ((u0 ^ fuel) & 7u) {
            case 4u: ;
            i1 = 0u & 15u;
        }
        break; (void)((u3 / ((u1 >> ((unsigned)h1 & 31u)) | 1u)));
    } while (i0++ < 7u && ((unsigned)((int)r0.x < (int)0x6098ce7eu) - u3));
    if (budget != 0u) { budget -= 1u; u3 = fn0(-(9u | 0x8da8ad87u), *q0, p2); }
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)(unsigned)c1 < (int)0xff57744cu), r0.y, (unsigned)(unsigned char)((unsigned)s1 % ((unsigned)((unsigned)w0 && m0) | 1u))); }
    if (budget != 0u) { budget -= 1u; u0 = fn0(((unsigned)c1 ^ r0.y), (*q0 + 0u), (unsigned)l0); }
    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)(unsigned)c0 < (int)(unsigned)w0), ((unsigned)(w0 >> 29) - (unsigned)b0), ((unsigned)(short)(0xffffffffu ^ m0) >> (0xb84fc222u & 31u))); }
    if ((unsigned)((unsigned)((int)0x10000u >= (int)0x50fd824du) < (unsigned)h1)) {
        if ((0x6ebe60d8u - (unsigned)((int)0x10000u < (int)v0))) goto L1;
        goto done;
        b0 = (unsigned)((u0 << ((unsigned)d0 & 31u)) && (r0.x << ((unsigned)w0 & 31u))) != 0u;
        if (budget != 0u) { budget -= 1u; u2 = fn0((6u & (v0 ^ 0xf124c45fu)), (unsigned)(p1 && 0x6663cf46u), (unsigned)((unsigned)(w0 >> 29) == 0xf07afb53u)); }
        if (budget != 0u) { budget -= 1u; u2 = fn0((r0.x << ((0x10000u + r0.x) & 31u)), (unsigned)((unsigned)e0 == (unsigned)s1), 1u); }
        goto L4;
    }
    if (i2) goto L0;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (((unsigned)c0 - (unsigned)(x0 >> 70))) break;
    }
    d0 = d0 * 0.5 + (double)(0x10000u & 1023u);
    *mp = ((unsigned)(signed char)(unsigned)((int)i1 >= (int)u3) * 7u);
    s0 = (int)a0[i0 & 3u];
    q0 = &garr[g1 & 7u];
    if ((unsigned)c1) goto L2;
    if ((i0 + (0x89eca79du * garr[i1 & 7u]))) {
        a0[u1 & 3u] = ((0u ^ (unsigned)s1) >> (garr[i1 & 7u] & 31u));
        goto done;
        do { if (--fuel == 0u) goto done;
            u1 = u1 * 0x9e3779b1u + ((unsigned)h0 - (unsigned)f0);
            for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((unsigned)(p2 < garr[i1 & 7u])) break;
                b0 = ((u2 % (g1 | 1u)) >> (garr[u2 & 7u] & 31u)) != 0u;
                goto done;
                switch ((0x10000u - (unsigned)h1) & 7u) {
                    a0[(unsigned)((int)p1 < (int)u2) & 3u] = m0;
                    m0 ^= (unsigned)((short)(unsigned)l0 > (signed char)(unsigned)(i0 || (unsigned)(w0 >> 29)));
                }
                while ((unsigned)((unsigned)b0 && a0[i0 & 3u])) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)l0;
                    if ((unsigned)((int)u2 >= (int)0xe3630566u)) break;
                    while (i0++ < 7u && ((m0 / ((unsigned)b0 | 1u)) * m0)) { if (--fuel == 0u) goto done;
                        x0 = x0 * 0x100000001b3ull + (unsigned)((*mp << (fuel & 31u)) && (a0[i0 & 3u] ^ (unsigned)f0));
                        a0[(unsigned)l0 & 3u] = (unsigned)(m0 == g0);
                        u1 += (unsigned)(short)(unsigned)((short)8u > (signed char)(0x3f2afafdu | (m0 - (a0[i0 & 3u] - p0))));
                        break; (void)((unsigned)(0x80000000u || u2));
                        if (fuel < 8u) return ((unsigned)(r0.x && (unsigned)(w0 >> 29)) / ((0x10000u & -(0xffffffffu * (unsigned)d0)) | 1u));
                        d0 = d0 * 0.5 + (double)(0x10000u & 1023u);
                    }
                    g1 += ((unsigned)(x0 >> 70) ^ garr[u2 & 7u]);
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)x0, (unsigned)((u0 << ((unsigned)d0 & 31u)) && p0), (unsigned)((int)(unsigned)l0 < (int)i0)); }
                }
            }
            if ((0xdcf67267u & (unsigned)((unsigned)l0 == v0))) {
                d0 = d0 * 0.5 + (double)(-((unsigned)(x0 >> 70) | (unsigned)s1) & 1023u);
                if (garr[i1 & 7u]) continue;
                g1 += garr[i1 & 7u];
                if ((8u * 0x10000u)) {
                    m0 ^= (0x10000u + (u1 ^ fuel));
                }
                r0.x = (~(unsigned)((int)fuel < (int)0xda0ce9a6u) & (0xd0178762u % ((unsigned)(w0 >> 29) | 1u)));
                { unsigned t6; double z6; if (((i1 << ((unsigned)s1 & 31u))) & 1u) { t6 = ((0x78dad2a8u / (garr[i1 & 7u] | 1u)) << (0x7fffffffu & 31u)); z6 = (double)(((unsigned)!(unsigned)((int)(unsigned)e0 < (int)i1)) & 255u); } if (((i1 << ((unsigned)s1 & 31u))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                    continue; (void)(p0);
                    u2 = u2 * 0x9e3779b1u + ((unsigned)c0 + 3u);
                    i2 = ((a0[i0 & 3u] | (unsigned)((int)5u < (int)3u)) % (fuel | 1u)) & 15u;
                    if (~((0x907a1308u | 3u) | p1)) break;
                    if (0x80000000u) break;
                }
            } else {
                if ((i1 << (*q0 & 31u))) goto L3;
                u3 = (unsigned)d0;
            }
            garr[((unsigned)f0 << ((unsigned)h1 & 31u)) & 7u] = (unsigned)(w0 >> 29);
            w0 ^= (unsigned long long)(unsigned)(0xffffffffu || 3u) << ((unsigned)s1 & 63u);
            if (((unsigned)s0 - (unsigned)(unsigned char)(0xfd10aeb2u / (0xf27db07u | 1u)))) {
                if (budget != 0u) { budget -= 1u; u0 = fn0(u1, p2, (unsigned)b0); }
                if ((unsigned)!(i2 << ((unsigned)(x0 >> 70) & 31u))) {
                    for (;;) { if (--fuel == 0u) goto done;
                        while (i2++ < 5u && (unsigned)((int)(unsigned)(i0 && 1u) < (int)i2)) { if (--fuel == 0u) goto done;
                            if (i2) break;
                            q0 = &garr[(unsigned)(short)((unsigned)(w0 >> 29) / (6u | 1u)) & 7u];
                            h0 = (short)(unsigned)(short)((unsigned)((short)(unsigned)s1 > (signed char)(unsigned)s0) >> (g0 & 31u));
                            goto done;
                            if (m0) break;
                            e0 = e0 * 0.5L + (long double)((unsigned)((int)u3 >= (int)(unsigned)(signed char)((unsigned)f0 + i1)) & 1023u);
                        }
                    }
                    if (0x7fffffffu) goto L1;
                    *mp = *mp;
                    if ((unsigned)b0) break;
                    if ((unsigned)w0) goto L3;
                    garr[(unsigned)((int)(unsigned)d0 < (int)4u) & 7u] = (unsigned)((unsigned)!(0x80000000u >> (i2 & 31u)) && 0x80000000u);
                }
            }
        } while (i0++ < 4u && (unsigned)((int)(0x7fffffffu / ((unsigned)h0 | 1u)) >= (int)0x80000000u));
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + (unsigned)((short)r0.x > (signed char)((p1 << (g1 & 31u)) ^ ((unsigned)x0 & 2u))));
                u3 += ((unsigned)c0 & ((unsigned)x0 / (g0 | 1u)));
            } while (i1++ < 3u && (unsigned)!(g0 + i1));
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)x0 && (5u - p1)), g0, 0x1276dfe1u); }
                if (0x80000000u) break;
                for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (6u) {
                        l0 = (long)((unsigned long)l0 + (unsigned)(short)(unsigned)((int)(unsigned)b0 >= (int)garr[i1 & 7u]));
                    } else {
                        *q0 = ((unsigned)(p1 == (u3 ? 7u : (unsigned)f0)) + 0x7174a2e7u);
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(garr[i1 & 7u] < ~(unsigned)((int)p2 >= (int)0xff804a86u)), u1, (unsigned)(g0 || 0x7fffffffu)); }
                    if (budget != 0u) { budget -= 1u; u3 = fn0(u2, 0x5960bb5fu, (i1 % (u2 | 1u))); }
                    l0 = (long)((unsigned long)l0 + (unsigned)h0);
                    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        v0 = 0x80000000u;
                        garr[(garr[u2 & 7u] + 0x9ef125a0u) & 7u] = (a0[i0 & 3u] >> (0x7fffffffu & 31u));
                        h1 = (unsigned short)(h1 + ((unsigned)((unsigned)((short)r0.y > (signed char)2u) && (unsigned)f0) - (unsigned)(x0 >> 70)));
                        w0 ^= (unsigned long long)p1 << ((unsigned)((short)0x10000u > (signed char)u0) & 63u);
                        x0 = x0 * 0x100000001b3ull + (i0 / ((unsigned)(0x80000000u < a0[i0 & 3u]) | 1u));
                    }
                }
            }
            switch ((unsigned)((short)u3 > (signed char)0x74751864u) & 7u) {
                *q0 = (unsigned)(unsigned char)((u0 | (unsigned)(0x4872fe7u || garr[u2 & 7u])) + 0x10000u);
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    *q0 = ((garr[i1 & 7u] - g1) * (unsigned)((int)((unsigned)b0 >> (garr[i1 & 7u] & 31u)) < (int)fuel));
                    if (((unsigned)((short)0x8c375224u > (signed char)(unsigned)b0) % (i0 | 1u))) goto L1;
                    w0 = w0 * 6364136223846793005ull + *q0;
                }
            }
            if ((unsigned)(*q0 == a0[i0 & 3u])) break;
        }
        if (u3) goto L3;
    } else {
        if ((unsigned)(a0[i0 & 3u] == (a0[i0 & 3u] * 0u))) goto L0;
        if ((unsigned)((int)(unsigned)b0 >= (int)(unsigned)((int)(unsigned)c0 >= (int)0x1137baaeu))) goto L4;
        v0 = (unsigned)((int)(unsigned)d0 >= (int)0x80000000u);
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    do { if (--fuel == 0u) goto done;
        if (((unsigned)d0 ? g1 : (unsigned)h0)) continue;
        g0 = garr[u2 & 7u];
    } while (i0++ < 3u && *q0);
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (r0.y) {
            h0 = (short)((unsigned)c0 | 9u);
            while (i1++ < 5u && (0x5e504f08u | *mp)) { if (--fuel == 0u) goto done;
                switch (((unsigned)(w0 >> 29) ? *q0 : i2) & 7u) {
                    case 1u: ;
                    default: ;
                }
                l0 = (long)((unsigned long)l0 + ((unsigned)(((unsigned)d0 ^ (unsigned)(x0 >> 70)) == g0) + 0xffffffffu));
                *q0 += (u3 & g1);
                w0 ^= (unsigned long long)(unsigned)(0xa73947d6u && 0xc6bdcb26u) << ((((unsigned)(x0 >> 70) / ((unsigned)e0 | 1u)) << ((u1 / ((unsigned)e0 | 1u)) & 31u)) & 63u);
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)f0 < u0), (unsigned)((int)g1 >= (int)0xffffffffu), (unsigned)((garr[i1 & 7u] * (unsigned)d0) < a0[u1 & 3u])); }
                v0 = (i1 & (unsigned)((short)4u > (signed char)4u));
            }
            e0 = e0 * 0.5L + (long double)(0x7fffffffu & 1023u);
            w0 = w0 * 6364136223846793005ull + (garr[i1 & 7u] ? i2 : 0x327b7b62u);
        } else {
            h0 = (short)(unsigned)(unsigned char)(unsigned)((int)(unsigned)e0 < (int)(unsigned)b0);
        }
        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)c0, (unsigned)((unsigned)((unsigned)d0 || (unsigned)h0) == r0.y), (unsigned)s0); }
        e0 = e0 * 0.5L + (long double)((unsigned)c0 & 1023u);
        do { if (--fuel == 0u) goto done;
            if ((u0 << ((unsigned)!(r0.x ^ (unsigned)f0) & 31u))) break;
        } while (i1++ < 4u && (unsigned)((short)((unsigned)f0 % (0x4d305c37u | 1u)) > (signed char)p1));
        if ((unsigned)((short)(unsigned)l0 > (signed char)(unsigned)h0)) break;
    }
    switch (u1 & 7u) {
        if (budget != 0u) { budget -= 1u; u2 = fn1((*mp * 3u), -(0u - (unsigned)f0), p1); }
    }
    b0 = (unsigned)(((unsigned)((int)m0 >= (int)(1u << ((unsigned)s1 & 31u))) >> (0x17706dadu & 31u)) && u1) != 0u;
    do { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (unsigned)(signed char)(unsigned)((short)(unsigned)!((unsigned)h0 << (fuel & 31u)) > (signed char)(0x10000u << (r0.y & 31u)));
        if (budget != 0u) { budget -= 1u; u3 = fn1(0x4cb2e8dbu, ~((unsigned)((short)u3 > (signed char)r0.y) + u3), (unsigned)((int)g1 >= (int)7u)); }
        break; (void)(((0x80000000u | (unsigned)l0) / (0xffffffffu | 1u)));
    } while (i0++ < 5u && (unsigned)((fuel + 0x80000000u) && i0));
    goto L1;
    goto done;
    { unsigned t0; double z0; if (((unsigned)h1) & 1u) { t0 = i2; z0 = (double)((((unsigned)b0 * p0)) & 255u); } if (((unsigned)h1) & 1u) { u2 += t0; d0 = d0 * 0.5 + z0; }
        r0.y ^= (0x8451175fu / ((unsigned)((int)r0.x < (int)g1) | 1u));
        a0[p1 & 3u] = -((unsigned)(i2 || (unsigned)c0) ^ 0x50edaebfu);
    }
    if (fuel < 8u) return (unsigned)((int)p2 >= (int)(unsigned)((int)a0[u1 & 3u] >= (int)8u));
    while (i0++ < 3u && i1) { if (--fuel == 0u) goto done;
        L0: if (--fuel == 0u) goto done;
        while (i1++ < 5u && (unsigned)(3u || (unsigned)((int)(unsigned)c0 < (int)p2))) { if (--fuel == 0u) goto done;
            if ((unsigned)x0) break;
            r0.x = (i1 ^ (*mp << (g0 & 31u)));
            for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                e0 = e0 * 0.5L + (long double)((unsigned)h1 & 1023u);
                if (budget != 0u) { budget -= 1u; u3 = fn1(r0.y, 0xffffffffu, ((unsigned)h1 | (unsigned)(0x10000u || i0))); }
            }
        }
        *q0 += (0xffffffffu / ((g1 * (unsigned)e0) | 1u));
    }
    *mp = (unsigned)(((unsigned)b0 >> (g0 & 31u)) < (unsigned)((unsigned)s1 < (i1 >> (i0 & 31u))));
    do { if (--fuel == 0u) goto done;
        L1: if (--fuel == 0u) goto done;
        while (i1++ < 5u && -((0x1ee2f9cau ^ 3u) / (0x10000u | 1u))) { if (--fuel == 0u) goto done;
            u3 ^= ((unsigned)(0xce0efc20u < (unsigned)(9u || garr[i1 & 7u])) & u3);
        }
        r0.x = ((0x10000u * -((unsigned)h1 + ((unsigned)b0 * u3))) >> (4u & 31u));
        { unsigned t1; double z1; if (((unsigned)!(7u % ((unsigned)(p2 || (unsigned)(x0 >> 70)) | 1u))) & 1u) { t1 = (unsigned)((short)u3 > (signed char)0x5235e09cu); z1 = (double)((0xffffffffu) & 255u); } if (((unsigned)!(7u % ((unsigned)(p2 || (unsigned)(x0 >> 70)) | 1u))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            l0 = (long)((unsigned long)l0 + (*mp | (unsigned)(u3 || 0xd0555cffu)));
        }
        c0 = (unsigned char)(unsigned)l0;
    } while (i0++ < 4u && *q0);
    i1 = (unsigned)(unsigned char)(0xde10cbau ? (unsigned)((int)0xd900edfbu < (int)(unsigned)h0) : u3) & 15u;
    L2: if (--fuel == 0u) goto done;
    u1 = u1 * 0x9e3779b1u + ((unsigned)s1 / ((unsigned)((unsigned)f0 < (unsigned)e0) | 1u));
    if ((unsigned)(unsigned char)(unsigned)((int)a0[u1 & 3u] < (int)0x80c018a7u)) {
        c0 = (unsigned char)(unsigned)((int)-((unsigned)(w0 >> 29) ? u3 : r0.x) >= (int)(unsigned)((int)i1 < (int)garr[u2 & 7u]));
        while (i0++ < 2u && (unsigned)((int)p1 >= (int)(unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + g0;
                    if ((unsigned)((unsigned)e0 || (unsigned)f0)) break;
                    continue; (void)((unsigned)(7u == i1));
                    while (i0++ < 3u && (unsigned)((int)0x50424d18u < (int)(unsigned)((int)u2 >= (int)(unsigned)x0))) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u1 = fn0(-(5u ^ ((unsigned)f0 % ((unsigned)(w0 >> 29) | 1u))), (a0[u1 & 3u] / (u3 | 1u)), ((garr[i1 & 7u] / (fuel | 1u)) % ((unsigned)d0 | 1u))); }
                        if (fuel) {
                            if (budget != 0u) { budget -= 1u; u3 = fn1((g0 * 0xdd016731u), i2, (0x7fffffffu ^ (unsigned)(0xc66aed09u < 0xe0199b50u))); }
                            L3: if (--fuel == 0u) goto done;
                            if (budget != 0u) { budget -= 1u; u0 = fn1(((1u & (unsigned)w0) << (a0[u1 & 3u] & 31u)), garr[u2 & 7u], (unsigned)((short)a0[u1 & 3u] > (signed char)3u)); }
                            if ((unsigned)((int)(unsigned)l0 < (int)((unsigned)h1 - 9u))) break;
                            x0 = x0 * 0x100000001b3ull + (unsigned)((i0 - a0[i0 & 3u]) && (i1 - a0[i0 & 3u]));
                        }
                        r0.x = ((p0 ^ (unsigned)(w0 >> 29)) + (unsigned)l0);
                        switch ((unsigned)(g1 < p2) & 7u) {
                            g0 = ~((unsigned)s0 ^ 0xffffffffu);
                            h1 = (unsigned short)(h1 + (unsigned)(g1 == 0x80000000u));
                            g1 += ((unsigned)((short)0x10000u > (signed char)(r0.y & v0)) / (((unsigned)e0 / (i2 | 1u)) | 1u));
                            goto L1;
                        }
                        a0[(unsigned)(short)(unsigned)(2u < *mp) & 3u] = (unsigned)((int)(unsigned)(short)(unsigned)(0x10000u == 4u) >= (int)(unsigned)c0);
                        u2 = u2 * 0x9e3779b1u + (unsigned)(0x10000u && (unsigned)h0);
                    }
                }
            } while (i1++ < 7u && garr[i1 & 7u]);
        }
        while (i0++ < 6u && r0.x) { if (--fuel == 0u) goto done;
            break; (void)((unsigned)h1);
            if ((*mp ^ 2u)) break;
            d0 = d0 * 0.5 + (double)((unsigned)(short)(unsigned)(0x68b49f0bu && 3u) & 1023u);
            L4: if (--fuel == 0u) goto done;
            break; (void)((unsigned)c0);
        }
        r0.x = ((unsigned)c1 + (unsigned)((int)u0 >= (int)0x2202b753u));
        if ((unsigned)((int)(unsigned)(signed char)(0xcb03f3eau * r0.y) < (int)8u)) goto L0;
    }
    *q0 += (0x7fffffffu % ((unsigned)(unsigned char)(u3 >> ((unsigned)(r0.y == (unsigned)s1) & 31u)) | 1u));
    c0 = (unsigned char)(((unsigned)h1 >> ((0x80000000u / (p2 | 1u)) & 31u)) >> ((unsigned)e0 & 31u));
    c0 = (unsigned char)u1;
    { unsigned t2; double z2; if ((~(unsigned)((int)u0 >= (int)i1)) & 1u) { t2 = (unsigned)h1; z2 = (double)(((unsigned)((unsigned)b0 == 1u)) & 255u); } if ((~(unsigned)((int)u0 >= (int)i1)) & 1u) { u0 += t2; d0 = d0 * 0.5 + z2; }
        do { if (--fuel == 0u) goto done;
            break; (void)((unsigned)((unsigned)x0 < 4u));
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)6u >= (int)(unsigned)c0), ((unsigned)f0 >> ((unsigned)(unsigned char)(unsigned)(5u && u3) & 31u)), (unsigned)((int)(0x1abc4fbu & (unsigned)f0) >= (int)i0)); }
            w0 ^= (unsigned long long)(unsigned)((int)r0.x < (int)(unsigned)h0) << ((unsigned)(unsigned char)(0x1b967814u + (unsigned)((unsigned)c0 || 8u)) & 63u);
            if (0x80000000u) {
                if ((unsigned)((int)g0 < (int)(0xb6005fadu << (fuel & 31u)))) break;
            } else {
                d0 = d0 * 0.5 + (double)(-(unsigned)(fuel < (unsigned)s1) & 1023u);
                while (i1++ < 2u && (*q0 ^ a0[u1 & 3u])) { if (--fuel == 0u) goto done;
                    break; (void)(((unsigned)!(unsigned)(u0 == i2) ^ a0[i0 & 3u]));
                    if ((u3 >> (0x10000u & 31u))) break;
                    if (((unsigned)h0 << ((unsigned)((short)i1 > (signed char)u3) & 31u))) continue;
                    g0 = *mp;
                    u2 = u2 * 0x9e3779b1u + 0xcf08fbe2u;
                }
            }
            if (u3 == 7u) return ~((unsigned)((int)(unsigned)((int)((unsigned)h1 ^ (unsigned)(x0 >> 70)) >= (int)0x80000000u) < (int)u2) ^ 0x4be5b9ccu);
            for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                s1 = (int)((unsigned)s1 + p1);
                w0 ^= (unsigned long long)(unsigned)(w0 >> 29) << ((unsigned)(short)(unsigned)((int)(5u / (0xdba62e91u | 1u)) < (int)(unsigned)((int)0x7fffffffu >= (int)(unsigned)((int)v0 >= (int)m0))) & 63u);
            }
        } while (i0++ < 7u && *mp);
        while (i0++ < 7u && (garr[i1 & 7u] & 0x10000u)) { if (--fuel == 0u) goto done;
            break; (void)(0x10000u);
            *mp = (unsigned)(0x10000u < (unsigned)((((unsigned)d0 >> (4u & 31u)) - 0x10000u) && (unsigned)h0));
            if ((unsigned)f0) continue;
        }
        for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 7u && (unsigned)(unsigned char)(*q0 + garr[i1 & 7u])) { if (--fuel == 0u) goto done;
                d0 = d0 * 0.5 + (double)((0x10000u & (unsigned)(i1 && (unsigned)((int)0x10000u >= (int)(unsigned)((unsigned)f0 && a0[u1 & 3u])))) & 1023u);
                if (budget != 0u) { budget -= 1u; u0 = fn1(i1, (fuel + (unsigned)(9u < (unsigned)h0)), (i2 & (unsigned)c0)); }
                if (budget != 0u) { budget -= 1u; u2 = fn0(i0, (unsigned)(a0[u1 & 3u] < 0x80000000u), (unsigned)(r0.y || (r0.x ^ 0x5ab1aaa9u))); }
                x0 = x0 * 0x100000001b3ull + (((unsigned)f0 ^ 0x8ee719cfu) >> (*mp & 31u));
                u0 = garr[i1 & 7u];
            }
        }
        *q0 += (unsigned)((unsigned)(a0[u1 & 3u] == r0.y) < (g1 & 0x7fffffffu));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn0(u3, (unsigned)((short)6u > (signed char)r0.x), u0); }
    l0 = (long)((unsigned long)l0 + ((unsigned)(w0 >> 29) >> ((5u + ((unsigned)l0 % ((unsigned)!(0u + fuel) | 1u))) & 31u)));
    if ((unsigned)((int)m0 >= (int)(unsigned)(w0 >> 29))) goto L0;
    { unsigned t3; double z3; if (((unsigned)((int)7u >= (int)(unsigned)(w0 >> 29))) & 1u) { t3 = fuel; z3 = (double)((u1) & 255u); } if (((unsigned)((int)7u >= (int)(unsigned)(w0 >> 29))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            goto L4;
            w0 ^= (unsigned long long)(unsigned)(*mp && 1u) << ((garr[u2 & 7u] / ((r0.x + (unsigned)f0) | 1u)) & 63u);
            u0 += -((unsigned)(3u || 0x80000000u) >> (0xd1bb2eb2u & 31u));
        }
        if ((unsigned)((int)i1 >= (int)fuel)) goto L4;
        f0 = f0 * 0.5f + (float)(~(unsigned)(((unsigned)((unsigned)d0 && 0x7fffffffu) << (a0[i0 & 3u] & 31u)) < (0x7fffffffu << (u2 & 31u))) & 255u);
        goto L4;
        i1 = ((unsigned)(((0x80000000u + (unsigned)e0) ^ 6u) && (unsigned)x0) >> ((unsigned)h0 & 31u)) & 15u;
    }
    if (-(unsigned)((unsigned)l0 < ((unsigned)x0 | r0.x))) {
        x0 = x0 * 0x100000001b3ull + (a0[i0 & 3u] & 0x80000000u);
        if ((unsigned)((short)5u > (signed char)(unsigned)f0)) goto L3;
        u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)((unsigned)(g1 && u1) && i1) == (unsigned)((short)g0 > (signed char)i0));
        if (0xffffffffu) {
            m0 ^= 0x10000u;
            s1 = (int)((unsigned)s1 + (unsigned)((int)(unsigned)s0 >= (int)0xffffffffu));
            if ((unsigned)h0) goto L3;
            a0[(unsigned)(short)((unsigned)c1 >> (v0 & 31u)) & 3u] = 0xc757cf46u;
        }
        do { if (--fuel == 0u) goto done;
            if ((unsigned)(short)((unsigned)((int)(unsigned)(x0 >> 70) < (int)0x7fffffffu) << (fuel & 31u))) break;
            x0 = x0 * 0x100000001b3ull + (unsigned)(unsigned char)(i2 + ((unsigned)f0 | (unsigned)(2u || 0xea7365d8u)));
            continue; (void)(p0);
            goto L2;
        } while (i0++ < 6u && i0);
    } else {
        s0 = (int)~(unsigned)((int)((g0 ^ (unsigned)d0) ? 1u : (unsigned)w0) >= (int)v0);
        switch (((unsigned)((int)0x10000u < (int)(unsigned)w0) ^ i2) & 7u) {
            for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t4; double z4; if ((0xffffffffu) & 1u) { t4 = garr[u2 & 7u]; z4 = (double)(((unsigned)((u0 | 0xca533fd7u) || *q0)) & 255u); } if ((0xffffffffu) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                    m0 ^= (unsigned)h0;
                }
                f0 = f0 * 0.5f + (float)((unsigned)w0 & 255u);
                continue; (void)(0xffffffffu);
                case 1u: ;
                i1 = (unsigned)(0x10000u && r0.y) & 15u;
                case 7u: ;
            }
            e0 = e0 * 0.5L + (long double)((unsigned)(((unsigned)w0 % (9u | 1u)) || (p2 + (unsigned)s1)) & 1023u);
            if ((unsigned)(garr[u2 & 7u] && (unsigned)c0)) goto L1;
            v0 = (0x17c212f4u - p1);
        }
        b0 = g0 != 0u;
    }
    if (((unsigned)c0 & (0x77f3b30bu & u0))) {
        if (0xa0226b43u) goto done;
        do { if (--fuel == 0u) goto done;
            if (u3 == 7u) return ~((unsigned)(signed char)(p2 | p0) | ((unsigned)((unsigned)s1 < *q0) << (g0 & 31u)));
            do { if (--fuel == 0u) goto done;
                *mp = (((v0 % (a0[u1 & 3u] | 1u)) / (4u | 1u)) >> ((unsigned)((int)0x6130c87bu < (int)u3) & 31u));
                { unsigned t5; double z5; if ((1u) & 1u) { t5 = ((unsigned)((short)i0 > (signed char)a0[u1 & 3u]) - r0.x); z5 = (double)((p2) & 255u); } if ((1u) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
                    if (budget != 0u) { budget -= 1u; u0 = fn0(u2, (u2 ? r0.y : g0), (unsigned)((unsigned)((unsigned)f0 == i2) < m0)); }
                }
                u2 = u2 * 0x9e3779b1u + (unsigned)((unsigned)c1 < u0);
            } while (i1++ < 2u && 6u);
            if ((6u ? u1 : m0)) break;
            if ((unsigned)(signed char)(*q0 ^ 1u)) {
                if (budget != 0u) { budget -= 1u; u2 = fn0(~((unsigned)(x0 >> 70) >> ((unsigned)((short)(unsigned)x0 > (signed char)p1) & 31u)), 0x7fffffffu, g0); }
            } else {
                u2 = ~(p1 | ((0x80000000u + r0.y) ^ (unsigned)c0));
                u3 ^= (0xeababc4eu << ((unsigned)d0 & 31u));
                q0 = &garr[4u & 7u];
            }
            if ((unsigned)(unsigned char)(unsigned)((int)(unsigned)e0 >= (int)(0xffffffffu + r0.x))) break;
        } while (i0++ < 7u && (unsigned)c0);
        if ((unsigned)((fuel * 0x7fffffffu) || 0xffffffffu)) {
            garr[(garr[i1 & 7u] - garr[u2 & 7u]) & 7u] = (garr[u2 & 7u] - 9u);
            h0 = (short)((unsigned)(w0 >> 29) | g1);
            goto L3;
            if (p0) {
                for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    v0 = (garr[i1 & 7u] + (unsigned)(garr[i1 & 7u] < (2u << ((i0 & i0) & 31u))));
                }
            }
        } else {
            u3 = u3 * 0x9e3779b1u + 0x10000u;
            d0 = d0 * 0.5 + (double)((unsigned)(0x10000u || v0) & 1023u);
        }
        if (0x80000000u) goto L1;
        g1 += ((unsigned)l0 ^ (unsigned)((short)*q0 > (signed char)(3u | r0.x)));
    } else {
        h1 = (unsigned short)(h1 + ((unsigned)c0 & (unsigned)(u0 < u1)));
        a0[1u & 3u] = r0.x;
        w0 = w0 * 6364136223846793005ull + (0xb837174fu ? garr[u2 & 7u] : (*mp % (((unsigned)w0 | u2) | 1u)));
    }
    if (budget != 0u) { budget -= 1u; u2 = fn1(0x10000u, ((unsigned)c0 << (0xffffffffu & 31u)), (unsigned)(i0 && *q0)); }
    m0 ^= (unsigned)(signed char)(8u / ((unsigned)(short)(unsigned)((unsigned)(w0 >> 29) || (unsigned)h0) | 1u));
    while (i0++ < 3u && *q0) { if (--fuel == 0u) goto done;
        if ((unsigned)!((a0[u1 & 3u] / (0x61d58707u | 1u)) ^ (unsigned)s1)) {
            if ((unsigned)(0x10000u || ((unsigned)d0 & 0xcb7f77bcu))) continue;
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)b0, ((unsigned)(x0 >> 70) * garr[u2 & 7u]), (unsigned)(short)(0xffffffffu >> (*q0 & 31u))); }
        } else {
            c0 = (unsigned char)(unsigned)((int)p1 < (int)0xfbf30f76u);
            g1 += (unsigned)(signed char)(unsigned)((int)0x80000000u >= (int)(unsigned)s1);
            do { if (--fuel == 0u) goto done;
                continue; (void)((unsigned)((int)(p1 + g0) >= (int)p1));
                r0.x = 0xffffffffu;
            } while (i1++ < 2u && ((unsigned)h1 % (fuel | 1u)));
        }
    }
    if ((unsigned)((int)(unsigned)l0 < (int)(unsigned)(w0 >> 29))) goto L0;
    while (i0++ < 3u && (((unsigned)x0 ^ v0) >> (7u & 31u))) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            do { if (--fuel == 0u) goto done;
                f0 = f0 * 0.5f + (float)((unsigned)(((unsigned)!(0x7c00977bu - 5u) + m0) || (unsigned)s1) & 255u);
            } while (i2++ < 6u && (unsigned)((short)-(0x51c1418bu - i2) > (signed char)a0[i0 & 3u]));
            garr[i1 & 7u] = (unsigned)((short)u0 > (signed char)(unsigned)((short)(unsigned)((int)(unsigned)l0 >= (int)a0[u1 & 3u]) > (signed char)0xffffffffu));
            { unsigned t6; double z6; if (((unsigned)((int)2u < (int)(unsigned)!(unsigned)(0u && u3))) & 1u) { t6 = (0x4bd4c725u & (unsigned)d0); z6 = (double)(((0x80000000u | (unsigned)(w0 >> 29))) & 255u); } if (((unsigned)((int)2u < (int)(unsigned)!(unsigned)(0u && u3))) & 1u) { u1 += t6; d0 = d0 * 0.5 + z6; }
                for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)c0) continue;
                    g0 = (unsigned)((int)(unsigned)(unsigned char)((unsigned)c0 % (garr[i1 & 7u] | 1u)) >= (int)(unsigned)((short)(0x7b1a175eu + (unsigned)s1) > (signed char)0x7fffffffu));
                }
                switch (~(unsigned)((short)u1 > (signed char)a0[u1 & 3u]) & 7u) {
                    u2 = a0[i0 & 3u];
                    goto L0;
                    *mp = ((unsigned)(0u || 0x10000u) ^ g0);
                }
                garr[(*q0 >> (g1 & 31u)) & 7u] = (0x3e1b6d8eu | (unsigned)((short)a0[u1 & 3u] > (signed char)garr[i1 & 7u]));
                break; (void)(((unsigned)s0 % (fuel | 1u)));
                if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)l0 && p0), ((unsigned)w0 * (unsigned)(garr[u2 & 7u] && 0x10000u)), 0x7fffffffu); }
                v0 = (unsigned)(0xffffffffu < (unsigned)(u1 && (unsigned)s1));
            }
        }
    }
    if (((0xb4121be7u | 2u) | i1)) goto L0;
    { unsigned t7; double z7; if (((unsigned)f0) & 1u) { t7 = (0x5f5c0433u ^ 0x9a45904du); z7 = (double)(((unsigned)(i0 < (unsigned)h0)) & 255u); } if (((unsigned)f0) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
        r0.x = (5u | (unsigned)e0);
        if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)s0 & u3), (8u >> ((0x7fffffffu >> (0x7fffffffu & 31u)) & 31u)), i0); }
        if (budget != 0u) { budget -= 1u; u2 = fn1((9u % (3u | 1u)), (unsigned)(0x92ffb5aeu && p0), (unsigned)(unsigned char)(0x80000000u % (0xffffffffu | 1u))); }
        goto L3;
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            break; (void)((0x7fffffffu * (p2 << (a0[i0 & 3u] & 31u))));
            continue; (void)((unsigned)(a0[i0 & 3u] < 0x10000u));
            if ((p2 % ((unsigned)h1 | 1u))) break;
            { unsigned t8; double z8; if ((((unsigned)e0 + u1)) & 1u) { t8 = (unsigned)(signed char)(unsigned)(garr[u2 & 7u] == 0xffffffffu); z8 = (double)((((u3 % (u0 | 1u)) ^ (unsigned)h0)) & 255u); } if ((((unsigned)e0 + u1)) & 1u) { u1 += t8; d0 = d0 * 0.5 + z8; }
                break; (void)((unsigned)s0);
            }
            if ((fuel * 6u)) break;
            if (0xc419dfecu) {
                do { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (unsigned)(~(m0 | (unsigned)(x0 >> 70)) && i2));
                } while (i1++ < 4u && ~(u2 + ((unsigned)h0 + *mp)));
                if ((unsigned)((short)p0 > (signed char)0x6429a42fu)) goto L4;
                h0 = (short)((unsigned)s0 * (unsigned)w0);
                h0 = (short)((g0 ^ r0.y) << ((0x10000u - (unsigned)((int)(unsigned)w0 < (int)i1)) & 31u));
                f0 = f0 * 0.5f + (float)(8u & 255u);
                q0 = &garr[(0x10000u << ((p1 ^ (unsigned)((unsigned)e0 && (unsigned)((int)0x668de29au >= (int)fuel))) & 31u)) & 7u];
            } else {
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)garr[i1 & 7u] >= (int)(9u / (a0[i0 & 3u] | 1u))), ((unsigned)s0 + 0x7fffffffu), (unsigned)f0); }
                if ((unsigned)e0) goto done;
                if (i1) goto L1;
            }
        }
    }
    goto L4;
    if (~(a0[i0 & 3u] & garr[u2 & 7u])) goto L3;
    d0 = d0 * 0.5 + (double)((unsigned)((int)a0[i0 & 3u] >= (int)(0x7b9ae488u * 0x80000000u)) & 1023u);
    u0 = u0 * 0x9e3779b1u + 0xffffffffu;
    if ((g1 / ((unsigned)(x0 >> 70) | 1u))) {
        r0.y ^= ((u2 << ((unsigned)l0 & 31u)) * (unsigned)(v0 && 0x9d3b855bu));
        garr[(unsigned)l0 & 7u] = p2;
    } else {
        c0 = (unsigned char)(unsigned)((short)(i0 & 0xc59c5fa4u) > (signed char)(unsigned)(signed char)(p2 ^ (unsigned)(unsigned char)(p1 ^ (unsigned)(w0 >> 29))));
        if (fuel < 8u) return (((unsigned)(x0 >> 70) << (*mp & 31u)) | 7u);
    }
    goto L0;
    { unsigned t9; double z9; if (((0x10000u | (1u * (unsigned)b0))) & 1u) { t9 = (5u - 6u); z9 = (double)(((unsigned)((short)0xb0dca104u > (signed char)v0)) & 255u); } if (((0x10000u | (1u * (unsigned)b0))) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
        v0 = (g0 ^ (unsigned)((unsigned)h0 == ((unsigned)(g1 && (unsigned)s1) & (unsigned)d0)));
        w0 ^= (unsigned long long)(i1 + 4u) << ((unsigned)((int)(unsigned)(a0[i0 & 3u] == (0xffffffffu + (7u ^ 4u))) >= (int)p0) & 63u);
        c1 = (signed char)(unsigned)(x0 >> 70);
        if ((unsigned)d0) goto L2;
    }
    switch (((unsigned)x0 - (unsigned)l0) & 7u) {
        if ((unsigned)((unsigned)s0 < 0xffffffffu)) goto L0;
        d0 = d0 * 0.5 + (double)(u0 & 1023u);
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                { unsigned t10; double z10; if (((unsigned)(garr[i1 & 7u] < 0x324c21au)) & 1u) { t10 = 8u; z10 = (double)((((u2 % (0xb69559a6u | 1u)) & a0[u1 & 3u])) & 255u); } if (((unsigned)(garr[i1 & 7u] < 0x324c21au)) & 1u) { u3 += t10; d0 = d0 * 0.5 + z10; }
                    case 2u: ;
                    garr[9u & 7u] = (garr[u2 & 7u] + (9u ? (unsigned)((short)i1 > (signed char)r0.x) : 0xadcebd5fu));
                    case 4u: ;
                    r0.y ^= (unsigned)(p1 == (unsigned)h1);
                    if (budget != 0u) { budget -= 1u; u0 = fn1((0xffffffffu / (0x80000000u | 1u)), (unsigned)((int)0x80000000u >= (int)(unsigned)(u0 && 9u)), (unsigned)(a0[i0 & 3u] < 0xa4c2f62fu)); }
                    goto done;
                }
                if ((garr[i1 & 7u] + 5u)) continue;
                e0 = e0 * 0.5L + (long double)(0x7fffffffu & 1023u);
            }
            { unsigned t11; double z11; if (((0x10000u - (0xffffffffu + 0u))) & 1u) { t11 = (unsigned)(0x80000000u == (unsigned)d0); z11 = (double)((8u) & 255u); } if (((0x10000u - (0xffffffffu + 0u))) & 1u) { u1 += t11; d0 = d0 * 0.5 + z11; }
                if (p1) goto L4;
                { unsigned t12; double z12; if ((((unsigned)h1 ^ ~(unsigned)((int)1u < (int)0xffffffffu))) & 1u) { t12 = ((u1 & 1u) / (0u | 1u)); z12 = (double)((a0[i0 & 3u]) & 255u); } if ((((unsigned)h1 ^ ~(unsigned)((int)1u < (int)0xffffffffu))) & 1u) { u0 += t12; d0 = d0 * 0.5 + z12; }
                    g0 = (a0[u1 & 3u] / ((6u ^ ~((unsigned)w0 / ((unsigned)s0 | 1u))) | 1u));
                    if (((unsigned)((short)(unsigned)w0 > (signed char)p0) + 7u)) goto L4;
                    if ((unsigned)((int)0x5fb15aedu >= (int)v0)) goto done;
                    if ((unsigned)((int)(unsigned)(garr[u2 & 7u] < fuel) >= (int)m0)) break;
                }
            }
            w0 = w0 * 6364136223846793005ull + u0;
            g1 += ((0x612fef3fu + 0xffffffffu) % ((unsigned)((unsigned)l0 < fuel) | 1u));
            g0 = (unsigned)(unsigned char)((unsigned)((int)p0 >= (int)r0.x) | (0x7fffffffu * (unsigned)s0));
            u1 = u1 * 0x9e3779b1u + ((0xffffffffu - -(unsigned)((int)g0 >= (int)i1)) + ((unsigned)d0 / (3u | 1u)));
        }
    }
    x0 = x0 * 0x100000001b3ull + (a0[i0 & 3u] >> ((unsigned)((int)(0x5405679cu ? u3 : 0xd2ede289u) >= (int)4u) & 31u));
    if ((unsigned)(0x10000u < a0[i0 & 3u])) goto L4;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    a0[(unsigned)(0x10000u && (unsigned)e0) & 3u] = (*mp & (a0[u1 & 3u] - p1));
    if (budget != 0u) { budget -= 1u; u2 = fn1(((unsigned)f0 * (unsigned)((unsigned)c0 && i0)), (unsigned)((short)a0[i0 & 3u] > (signed char)g1), *q0); }
    if ((unsigned)(u0 && (unsigned)((short)i2 > (signed char)i0))) goto L4;
    l0 = (long)((unsigned long)l0 + (unsigned)(((unsigned)c1 << ((unsigned)(i2 == ((unsigned)c1 % (0xffffffffu | 1u))) & 31u)) || 0xe9d024ceu));
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        while (i1++ < 5u && ((unsigned)b0 >> (0x7fffffffu & 31u))) { if (--fuel == 0u) goto done;
            g0 = (unsigned)(short)(unsigned)((short)(unsigned)d0 > (signed char)0x2ca6876au);
            goto L2;
            i2 = (unsigned)(signed char)(unsigned)((unsigned)((int)u0 < (int)0xffffffffu) && m0) & 15u;
            x0 = x0 * 0x100000001b3ull + garr[u2 & 7u];
            for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)(0xffffffffu == u3) && (unsigned)x0), (unsigned)((int)(unsigned)d0 >= (int)u0), p1); }
                do { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)(0x80000000u & 1023u);
                    garr[(unsigned)h1 & 7u] = (unsigned)(0x7a6997b4u || (unsigned)b0);
                    break; (void)((unsigned)e0);
                    g1 += (unsigned)((unsigned)(unsigned char)(unsigned)((short)(unsigned)b0 > (signed char)((unsigned)l0 << ((unsigned)(short)(6u >> (0x4e7d2a3eu & 31u)) & 31u))) || a0[u1 & 3u]);
                } while (i0++ < 6u && (unsigned)c1);
                *q0 = (*q0 ^ ((unsigned)(7u && i1) ^ (unsigned)(short)(0xb5326e2au | 0xfe5d01e1u)));
            }
            if (((unsigned)c0 & r0.y)) {
                *q0 = (unsigned)(signed char)(unsigned)((int)0x59d0d297u >= (int)(unsigned)((unsigned)c1 == g1));
            }
        }
        if (budget != 0u) { budget -= 1u; u0 = fn0((0x74194b6eu + (unsigned)f0), ((unsigned)s1 % ((unsigned)(0xc09d46ebu && v0) | 1u)), u2); }
        c1 = (signed char)(unsigned)(p2 < 0x10000u);
        L0: if (--fuel == 0u) goto done;
    }
    w0 = w0 * 6364136223846793005ull + ((i1 / ((unsigned)e0 | 1u)) / ((unsigned)(unsigned char)((unsigned)x0 - (unsigned)(w0 >> 29)) | 1u));
    c1 = (signed char)(6u >> (a0[u1 & 3u] & 31u));
    if (r0.x) goto L2;
    for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)(a0[u1 & 3u] < (unsigned)(w0 >> 29)) % (*mp | 1u)));
        c1 = (signed char)(r0.y & (unsigned)((unsigned)((unsigned)h1 || g0) == (unsigned)(x0 >> 70)));
    }
    *q0 = (fuel ? 3u : ((unsigned)b0 & (unsigned)h1));
    c0 = (unsigned char)0x35aae053u;
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (unsigned)(((unsigned)(u2 && (unsigned)(signed char)(unsigned)(0x10000u && p2)) << ((unsigned)c1 & 31u)) && 0x10000u);
        b0 = (2u - (unsigned)(v0 == 0x10000u)) != 0u;
        if ((unsigned)((int)*q0 >= (int)m0)) break;
        h0 = (short)-(unsigned)((int)(unsigned)((short)7u > (signed char)(unsigned)f0) < (int)(unsigned)((int)(unsigned)w0 >= (int)(u2 >> (r0.y & 31u))));
    }
    if (((unsigned)(x0 >> 70) % (0x80000000u | 1u))) goto L2;
    do { if (--fuel == 0u) goto done;
        { unsigned t0; double z0; if (((u2 / ((unsigned)!((unsigned)(x0 >> 70) ^ (unsigned)b0) | 1u))) & 1u) { t0 = (unsigned)((unsigned)s1 < (p0 / (fuel | 1u))); z0 = (double)(((unsigned)(unsigned char)(unsigned)((unsigned)x0 == g1)) & 255u); } if (((u2 / ((unsigned)!((unsigned)(x0 >> 70) ^ (unsigned)b0) | 1u))) & 1u) { u1 += t0; d0 = d0 * 0.5 + z0; }
            i1 = (unsigned)!(3u >> (0x10000u & 31u)) & 15u;
            h1 = (unsigned short)(h1 + (unsigned)(u2 || 0x4b6e3813u));
        }
        L1: if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn2(((unsigned)b0 << (0x7fffffffu & 31u)), 0xffffffffu, (garr[u2 & 7u] - 0xd6191e0eu)); }
        switch (*mp & 7u) {
            if ((unsigned)(a0[u1 & 3u] || -(p2 + a0[i0 & 3u]))) break;
            w0 ^= (unsigned long long)a0[i0 & 3u] << ((unsigned)(0xef61df32u == (unsigned)(v0 == ~((unsigned)d0 ? u0 : (unsigned)h1))) & 63u);
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(signed char)(u3 | p2), 0x7fffffffu, (unsigned)s0); }
            a0[(8u ^ i1) & 3u] = (0xfa9ab898u / (((unsigned)s1 - (unsigned)(*q0 || 8u)) | 1u));
            do { if (--fuel == 0u) goto done;
                if ((u0 ^ u0)) goto L4;
            } while (i1++ < 4u && (unsigned)f0);
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                r0.x = ((u1 / ((unsigned)(i0 && (unsigned)d0) | 1u)) * (unsigned)((int)u0 < (int)*q0));
                if (fuel < 8u) return (unsigned)(unsigned char)((unsigned)!(unsigned)((unsigned)f0 < 1u) - a0[i0 & 3u]);
            }
        }
        u0 ^= (unsigned)((int)0x3a71a2e2u < (int)(unsigned)((int)0xc8dab89du < (int)(unsigned)(signed char)(unsigned)((unsigned)s0 && fuel)));
    } while (i0++ < 6u && (-(unsigned)(8u < 0x10000u) + 7u));
    if (budget != 0u) { budget -= 1u; u3 = fn2(7u, -(unsigned)(0xcef86c43u == (unsigned)(r0.y < 0xdeb1024au)), ((r0.x ^ (unsigned)d0) << (0x82fae063u & 31u))); }
    if ((i2 * garr[i1 & 7u])) goto L4;
    w0 ^= (unsigned long long)(unsigned)(u2 && 0x7fffffffu) << ((0x10000u & (fuel * (unsigned)c1)) & 63u);
    l0 = (long)((unsigned long)l0 + (unsigned)!(0x6ecd8e4cu % (r0.y | 1u)));
    if ((p2 * u3)) {
        switch (((unsigned)c0 | r0.y) & 7u) {
            { unsigned t1; double z1; if (((unsigned)((short)(unsigned)c1 > (signed char)(unsigned)((int)(unsigned)h0 >= (int)u2))) & 1u) { t1 = (unsigned)((unsigned)d0 < (unsigned)((short)0x9ef4cfbcu > (signed char)(unsigned)e0)); z1 = (double)(((unsigned)(signed char)(unsigned)((i2 | (unsigned)s1) || 0xc26413dbu)) & 255u); } if (((unsigned)((short)(unsigned)c1 > (signed char)(unsigned)((int)(unsigned)h0 >= (int)u2))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                do { if (--fuel == 0u) goto done;
                    if ((unsigned)((unsigned)h0 == (unsigned)h0)) continue;
                    q0 = &garr[(unsigned)b0 & 7u];
                    g0 = (((unsigned)c1 * (unsigned)c1) & (unsigned)d0);
                    case 3u: ;
                } while (i0++ < 3u && (unsigned)(short)(fuel / ((unsigned)x0 | 1u)));
                *mp = (unsigned)((unsigned)((unsigned)d0 || (unsigned)((int)g0 < (int)u0)) || (0x69f5335bu >> (p2 & 31u)));
                f0 = f0 * 0.5f + (float)(*mp & 255u);
                L2: if (--fuel == 0u) goto done;
                q0 = &garr[((unsigned)(unsigned char)((unsigned)w0 / (p1 | 1u)) * i1) & 7u];
                *q0 += ((unsigned)(((unsigned)h0 ^ 0x7fffffffu) < (unsigned)e0) + (unsigned)e0);
            }
            case 1u: ;
            if ((unsigned)((unsigned)w0 < ((unsigned)d0 | a0[i0 & 3u]))) {
                switch (((unsigned)c0 * 8u) & 7u) {
                    u2 = (g1 * (unsigned)((short)(5u + *mp) > (signed char)(unsigned)(8u || 0x7fffffffu)));
                    goto L2;
                    L3: if (--fuel == 0u) goto done;
                    while (i0++ < 6u && (unsigned)((unsigned)(a0[u1 & 3u] == v0) && fuel)) { if (--fuel == 0u) goto done;
                        if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(((unsigned)(x0 >> 70) + i2) || (unsigned)(x0 >> 70)), (unsigned)(unsigned char)(unsigned)(r0.x == a0[u1 & 3u]), (unsigned)((short)m0 > (signed char)((unsigned)e0 >> (p0 & 31u)))); }
                        break; (void)((unsigned)((short)0xba535b92u > (signed char)(unsigned)e0));
                        if (budget != 0u) { budget -= 1u; u1 = fn2(0xffffffffu, ((0u >> (0x6aff5330u & 31u)) % (0x7fffffffu | 1u)), p1); }
                        if ((unsigned)((int)(unsigned)(0x91db03aau == 0x2c5b29cau) < (int)0xbab2a628u)) break;
                        c0 = (unsigned char)(unsigned)((u3 / (g1 | 1u)) || (p1 - a0[i0 & 3u]));
                        b0 = ~(3u ^ 0x7f518e54u) != 0u;
                    }
                    if (v0) {
                        g1 += (0x80000000u * (unsigned)l0);
                        if (a0[i0 & 3u]) goto L1;
                        if ((unsigned)((unsigned)(unsigned char)(unsigned)((unsigned)b0 && 0x2e356d06u) == 8u)) goto done;
                        e0 = e0 * 0.5L + (long double)(((unsigned)(((unsigned)x0 / (a0[u1 & 3u] | 1u)) < (unsigned)h0) ^ u2) & 1023u);
                        w0 = w0 * 6364136223846793005ull + ((0x87b494a2u >> (v0 & 31u)) | (unsigned)(6u && (unsigned)(signed char)((unsigned)w0 ^ 0xd689f690u)));
                        case 2u: ;
                    }
                    if (((unsigned)((int)i0 >= (int)0xffffffffu) & (unsigned)s0)) {
                        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)*mp < (int)(unsigned)(0xfe00e951u || (unsigned)b0)), ((unsigned)h1 / (2u | 1u)), (unsigned)(garr[u2 & 7u] || (unsigned)l0)); }
                        if (budget != 0u) { budget -= 1u; u2 = fn0(0x80000000u, (g1 - (5u << (u2 & 31u))), (u3 + u3)); }
                        garr[u0 & 7u] = ((unsigned)(8u < p0) * m0);
                        if ((unsigned)((unsigned)((int)a0[u1 & 3u] < (int)(unsigned)d0) && (unsigned)x0)) {
                            b0 = (unsigned)((unsigned)w0 || 0x7fffffffu) != 0u;
                            if (budget != 0u) { budget -= 1u; u1 = fn0(0xd0cbe5e5u, i0, p1); }
                        }
                        g0 = (((unsigned)e0 + ((unsigned)s0 >> (0x996b7059u & 31u))) & (unsigned)((unsigned)d0 || garr[i1 & 7u]));
                    } else {
                        if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((int)u0 < (int)(unsigned)(p1 || (unsigned)h0)), 7u, (garr[u2 & 7u] / (((unsigned)x0 - m0) | 1u))); }
                    }
                }
                for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                    case 7u: ;
                    if (((unsigned)((int)garr[i1 & 7u] < (int)i2) / (i2 | 1u))) break;
                    c1 = (signed char)(unsigned)((unsigned)((int)((i1 ^ 0x80000000u) - i0) < (int)0x80000000u) && 0x40ef8bc8u);
                    r0.x = (unsigned)(signed char)((0xffffffffu & (unsigned)d0) >> ((unsigned)(*mp && 0x7fffffffu) & 31u));
                    f0 = f0 * 0.5f + (float)(*mp & 255u);
                    switch (0xffffffffu & 7u) {
                        case 1u: ;
                        if (((unsigned)c1 | (unsigned)(short)((unsigned)d0 | (unsigned)d0))) break;
                        r0.x = (unsigned)(signed char)(unsigned)((v0 | i1) && i2);
                        if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)((int)(unsigned)w0 >= (int)(unsigned)(signed char)(m0 & p0)), (unsigned)((int)(0x80000000u ^ (unsigned)f0) >= (int)u1), 0xcdcb3da7u); }
                        h0 = (short)(v0 + i1);
                        e0 = e0 * 0.5L + (long double)((p0 >> ((((unsigned)w0 >> (0xaf77f33fu & 31u)) | (0x10000u / (r0.y | 1u))) & 31u)) & 1023u);
                    }
                }
                break; (void)((unsigned)(short)(0x10000u + (unsigned)w0));
                default: ;
                h1 = (unsigned short)(h1 + ((unsigned)((int)g0 < (int)0xed893579u) - u3));
                if ((unsigned)s0) goto L4;
            }
            a0[(a0[u1 & 3u] - 0x4e1639e1u) & 3u] = *q0;
            f0 = f0 * 0.5f + (float)((0u + ((unsigned)h0 << ((unsigned)(g1 && 0xc9140f5du) & 31u))) & 255u);
        }
        switch (p2 & 7u) {
            r0.y ^= (unsigned)((*q0 ? 2u : g1) || (0x7fffffffu << ((unsigned)b0 & 31u)));
            if (budget != 0u) { budget -= 1u; u1 = fn1((1u + *q0), (g0 + (unsigned)(a0[i0 & 3u] && (unsigned)s0)), (unsigned)(unsigned char)(garr[i1 & 7u] % ((unsigned)(g0 < 0x545fb872u) | 1u))); }
            d0 = d0 * 0.5 + (double)((5u * 0x7fffffffu) & 1023u);
            *mp = (unsigned)((0xc5f60d73u << ((0xa0e627bcu ? *q0 : garr[i1 & 7u]) & 31u)) || v0);
        }
    } else {
        L4: if (--fuel == 0u) goto done;
        f0 = f0 * 0.5f + (float)(((unsigned)(signed char)(unsigned)((int)(unsigned)l0 < (int)(unsigned)((short)7u > (signed char)(unsigned)s1)) / ((r0.x << (a0[i0 & 3u] & 31u)) | 1u)) & 255u);
        if ((unsigned)((int)p2 < (int)*q0)) {
            if ((unsigned)(*mp && (unsigned)(short)(unsigned)((short)0xffffffffu > (signed char)(unsigned)s1))) goto L2;
            if ((0x10000u >> ((unsigned)((int)i0 >= (int)8u) & 31u))) {
                c1 = (signed char)5u;
                h1 = (unsigned short)(h1 + u0);
                q0 = &garr[(unsigned)((int)i0 < (int)0xfc7050f7u) & 7u];
            }
        } else {
            m0 ^= (unsigned)(signed char)(unsigned)((int)(unsigned)((((unsigned)b0 + r0.y) + (unsigned)(x0 >> 70)) && (unsigned)l0) >= (int)(unsigned)s0);
            if (budget != 0u) { budget -= 1u; u0 = fn2((unsigned)(short)(g1 % ((unsigned)(x0 >> 70) | 1u)), (4u + (unsigned)d0), (unsigned)((short)p2 > (signed char)(unsigned)h1)); }
            if (fuel < 8u) return v0;
            l0 = (long)((unsigned long)l0 + (u3 * ((unsigned)((short)(unsigned)s1 > (signed char)0x10000u) << ((unsigned)(unsigned char)(unsigned)((int)(unsigned)e0 < (int)(unsigned)l0) & 31u))));
        }
    }
    while (1u) { if (--fuel == 0u) goto done;
        while (i1++ < 4u && (p0 ? 0xffffffffu : 0x25dcfbfeu)) { if (--fuel == 0u) goto done;
            if (i0) goto done;
            u2 = (p0 & ((unsigned)((int)(unsigned)w0 < (int)1u) ? r0.y : 0xf0bea4b6u));
            continue; (void)(-(unsigned)((unsigned)l0 && 0x10000u));
            s0 = (int)((unsigned)(signed char)(unsigned)((int)fuel < (int)(unsigned)s0) ? 0x7fffffffu : a0[u1 & 3u]);
        }
        for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)x0) {
                l0 = (long)((unsigned long)l0 + (((unsigned)e0 >> (*q0 & 31u)) % ((unsigned)(0xbfed34a7u && garr[i1 & 7u]) | 1u)));
                h1 = (unsigned short)(h1 + (unsigned)((int)0x10000u < (int)(m0 % (garr[i1 & 7u] | 1u))));
                h1 = (unsigned short)(h1 + ((unsigned)((short)(unsigned)((unsigned)s0 < p2) > (signed char)u1) % (r0.y | 1u)));
                c1 = (signed char)(unsigned)(r0.x && ~(*mp ? (unsigned)((int)g0 >= (int)*q0) : g1));
                while (i2++ < 6u && v0) { if (--fuel == 0u) goto done;
                    do { if (--fuel == 0u) goto done;
                        if (u3 == 7u) return (unsigned)((int)(unsigned)s0 < (int)((u3 % (0x50fc44f2u | 1u)) | r0.x));
                        s0 = (int)(0x9a5060dau & garr[u2 & 7u]);
                    } while (i0++ < 3u && (g1 | r0.x));
                    if (0x91cbc5b8u) goto L3;
                    *mp = (unsigned)(r0.x || ~(unsigned)(((unsigned)e0 ? garr[u2 & 7u] : (unsigned)w0) || (unsigned)s1));
                }
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((p1 | (*mp - (unsigned)h0)), (a0[i0 & 3u] - *q0), ((unsigned)(1u < p2) * 0x4645a732u)); }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((0x22866ff9u % (garr[i1 & 7u] | 1u)) == u0), r0.x, ((3u % (*q0 | 1u)) % (p1 | 1u))); }
            if ((unsigned)((int)(unsigned)s0 < (int)((unsigned)c1 * 0xffffffffu))) break;
            for (i2 = 1u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)(unsigned char)(u3 << ((unsigned)((int)i2 < (int)0u) & 31u));
                v0 = (unsigned)((int)m0 >= (int)(0x80000000u | 0x7f543582u));
                do { if (--fuel == 0u) goto done;
                    break; (void)(0xf679e978u);
                    e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)(5u - (unsigned)(fuel && 0x80000000u)) & 1023u);
                    if ((i0 & (unsigned)s1)) break;
                    c1 = (signed char)i2;
                } while (i0++ < 5u && 0x10000u);
                if ((unsigned)((int)a0[i0 & 3u] < (int)6u)) break;
                if ((i2 >> ((unsigned)((int)*mp < (int)fuel) & 31u))) goto L4;
                switch ((((unsigned)h0 >> (0x7fffffffu & 31u)) / (m0 | 1u)) & 7u) {
                    if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((int)(unsigned)d0 >= (int)fuel), r0.x, (~(unsigned)((unsigned)x0 && (unsigned)e0) & p1)); }
                    v0 = ((unsigned)(w0 >> 29) * ((unsigned)x0 - 0x74dab66du));
                }
            }
            if (fuel) {
                break; (void)(((unsigned)w0 << (a0[i0 & 3u] & 31u)));
                c1 = (signed char)-(8u & ((r0.x / (0x7fffffffu | 1u)) | a0[u1 & 3u]));
                if ((unsigned)s0) break;
                if (i0) {
                    if (((unsigned)(short)(unsigned)((int)fuel < (int)p2) | 0x10000u)) break;
                    if ((unsigned)(0xccc25df0u && (unsigned)(r0.y || 0x10000u))) break;
                    i1 = (unsigned)(short)((garr[i1 & 7u] / ((unsigned)((int)(unsigned)l0 >= (int)*q0) | 1u)) >> ((unsigned)((int)g0 < (int)a0[u1 & 3u]) & 31u)) & 15u;
                    if ((unsigned)((int)(u1 - (unsigned)c0) < (int)9u)) goto L3;
                } else {
                    if (i2) {
                        *mp = (unsigned)((int)(unsigned)f0 >= (int)u0);
                        if (budget != 0u) { budget -= 1u; u2 = fn2(0xffffffffu, (u3 << ((unsigned)f0 & 31u)), g0); }
                        if ((0x88ff5aedu >> (9u & 31u))) goto L0;
                    } else {
                        if ((*q0 % (4u | 1u))) break;
                        break; (void)((unsigned)((int)~(garr[i1 & 7u] % (garr[i1 & 7u] | 1u)) >= (int)m0));
                    }
                    continue; (void)((u2 * 9u));
                    if (budget != 0u) { budget -= 1u; u0 = fn0((*q0 % ((0x10000u ^ (unsigned)(x0 >> 70)) | 1u)), 0xf073354bu, (*q0 * -(garr[i1 & 7u] / (garr[u2 & 7u] | 1u)))); }
                    if (g0) break;
                }
                i1 = (unsigned)(p1 && (unsigned)(u3 || ((unsigned)d0 >> (0x7fffffffu & 31u)))) & 15u;
                r0.x = (0x7fffffffu & (r0.y / (6u | 1u)));
            }
        }
    }
    if (a0[i0 & 3u]) goto L3;
    if (u1) goto L1;
    g1 += (unsigned)c0;
    goto L0;
    if ((unsigned)((unsigned)h1 || r0.x)) goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn2((a0[u1 & 3u] << (m0 & 31u)), (unsigned)((int)(unsigned)(fuel && (unsigned)(w0 >> 29)) >= (int)(unsigned)d0), (6u | g1)); }
    goto L2;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        garr[(i2 * 0xc36c40edu) & 7u] = ((unsigned)(p2 && ((unsigned)b0 ? 0xffffffffu : 0x7fffffffu)) + (unsigned)e0);
        continue; (void)(((u3 % (0x360c2933u | 1u)) | 6u));
        { unsigned t2; double z2; if ((((unsigned)s0 ? garr[u2 & 7u] : 0xffffffffu)) & 1u) { t2 = (i2 & (unsigned)(x0 >> 70)); z2 = (double)(((unsigned)((int)(*mp | r0.y) >= (int)v0)) & 255u); } if ((((unsigned)s0 ? garr[u2 & 7u] : 0xffffffffu)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
            if (g0) goto L4;
            if ((unsigned)((int)*mp >= (int)(unsigned)(w0 >> 29))) break;
            if ((0xe6bcbd7cu * p2)) {
                f0 = f0 * 0.5f + (float)((7u % ((unsigned)((short)((unsigned)b0 | (unsigned)b0) > (signed char)9u) | 1u)) & 255u);
                u0 ^= (unsigned)w0;
            }
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2(3u, 0x80000000u, (u2 << ((unsigned)(short)(fuel * 0x80000000u) & 31u))); }
                w0 = w0 * 6364136223846793005ull + a0[u1 & 3u];
                goto L3;
                u0 ^= (7u / ((unsigned)((unsigned)e0 == 0xffffffffu) | 1u));
                if ((unsigned)(v0 < 8u)) break;
            }
            garr[(unsigned)(0x10000u && (unsigned)(x0 >> 70)) & 7u] = (*q0 | m0);
            if (m0) break;
        }
    }
    a0[(unsigned)((int)(unsigned)e0 < (int)0xce0e0f20u) & 3u] = ((p2 - (unsigned)(x0 >> 70)) ? 7u : i0);
    if ((((unsigned)x0 >> ((unsigned)x0 & 31u)) & garr[i1 & 7u])) goto L1;
    u1 ^= (unsigned)((short)3u > (signed char)(unsigned)!(unsigned)((unsigned)((int)0u >= (int)a0[i0 & 3u]) == (unsigned)x0));
    while (i0++ < 4u && (g1 * (unsigned)w0)) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (0x233663beu ^ (unsigned)(-(unsigned)((int)(unsigned)(w0 >> 29) >= (int)(unsigned)f0) < 1u)));
    }
    if (p2) {
        *q0 = (unsigned)(unsigned char)(((unsigned)(a0[u1 & 3u] == fuel) / ((unsigned)c1 | 1u)) + 0u);
        x0 = x0 * 0x100000001b3ull + 0x7fffffffu;
        if ((unsigned)(w0 >> 29)) {
            { unsigned t3; double z3; if (((unsigned)(x0 >> 70)) & 1u) { t3 = (0x7fffffffu % (p0 | 1u)); z3 = (double)(((unsigned)((unsigned)e0 == 0x10000u)) & 255u); } if (((unsigned)(x0 >> 70)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    b0 = (unsigned)((int)8u < (int)-(unsigned)((int)(unsigned)x0 < (int)i1)) != 0u;
                    if (v0) continue;
                    s0 = (int)((0x683c72bau + (unsigned)d0) << ((unsigned)(0xea4dde60u || u3) & 31u));
                    if (budget != 0u) { budget -= 1u; u2 = fn0((0xf72440eeu >> ((unsigned)(short)(unsigned)((unsigned)c1 || r0.x) & 31u)), (fuel * (fuel >> ((unsigned)c1 & 31u))), ((unsigned)f0 ^ 1u)); }
                    if (((u1 / (6u | 1u)) ^ i1)) {
                        u0 ^= (a0[u1 & 3u] & (*q0 + 0x80000000u));
                        i2 = (unsigned)!(4u % ((unsigned)(((unsigned)((int)0x10000u >= (int)g0) & p2) < 0xa9dc7654u) | 1u)) & 15u;
                        v0 = (unsigned)((8u - 0x58a139e9u) < g1);
                        while (i1++ < 5u && (unsigned)!(unsigned)((int)(unsigned)(unsigned char)(0x80000000u * garr[i1 & 7u]) >= (int)0x7fcc4eecu)) { if (--fuel == 0u) goto done;
                            v0 = (*mp % ((unsigned)((p2 >> (p2 & 31u)) && (r0.x ^ (unsigned)s1)) | 1u));
                        }
                    } else {
                        l0 = (long)((unsigned long)l0 + (g1 * (-(unsigned)(0x56277a44u && u0) - ((unsigned)h1 & i2))));
                        if (budget != 0u) { budget -= 1u; u2 = fn0((0x10000u ^ (unsigned)s1), 0xa178e8bu, -(unsigned)((unsigned)(0xcd1ecb91u && 0x5a2ed8f5u) == 0x5a28a3eu)); }
                        if (u3 == 7u) return ((0xa94a037fu >> ((unsigned)(u2 == p1) & 31u)) << (0x23b3d265u & 31u));
                    }
                    if (5u) goto L2;
                }
            }
            if (u1) goto L3;
            do { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    g0 = (0x4f8db947u | (i2 >> (r0.x & 31u)));
                    for (;;) { if (--fuel == 0u) goto done;
                        if (m0) goto L4;
                        if (fuel < 8u) return (unsigned)(short)((unsigned)h1 + garr[i1 & 7u]);
                        u0 += ((unsigned)f0 << ((p1 << ((garr[u2 & 7u] | *mp) & 31u)) & 31u));
                    }
                    *mp = (((unsigned)l0 >> (((unsigned)b0 << (-(g0 / ((unsigned)x0 | 1u)) & 31u)) & 31u)) * (unsigned)h1);
                    switch ((unsigned)((short)u1 > (signed char)0xe078727cu) & 7u) {
                        m0 ^= 0x7fffffffu;
                        continue; (void)((((unsigned)c1 + (unsigned)s0) % ((unsigned)(x0 >> 70) | 1u)));
                        if ((unsigned)((int)0x61615598u >= (int)r0.x)) break;
                        case 3u: ;
                        c1 = (signed char)(unsigned)c1;
                        continue; (void)((3u / (u3 | 1u)));
                    }
                    d0 = d0 * 0.5 + (double)(((unsigned)x0 % (p2 | 1u)) & 1023u);
                    { unsigned t4; double z4; if (((unsigned)(0xda77653cu < 0x7fffffffu)) & 1u) { t4 = (a0[u1 & 3u] | (r0.x - 0u)); z4 = (double)((garr[u2 & 7u]) & 255u); } if (((unsigned)(0xda77653cu < 0x7fffffffu)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                        u2 += (unsigned)e0;
                        garr[(unsigned)((int)(unsigned)(w0 >> 29) < (int)fuel) & 7u] = (unsigned)((unsigned)w0 == (unsigned)((int)u2 >= (int)0xe4b44cdeu));
                    }
                } while (i1++ < 3u && 0x7fffffffu);
                g1 += (unsigned)((int)(unsigned)((short)(unsigned)h1 > (signed char)0x7fffffffu) >= (int)0x10000u);
            } while (i0++ < 7u && (unsigned)((short)(unsigned)(unsigned char)(unsigned)(0x8a0874a6u < p1) > (signed char)(unsigned)s1));
            if ((7u | 9u)) goto L0;
            s0 = (int)(7u | garr[i1 & 7u]);
        } else {
            for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                if (garr[i1 & 7u]) break;
                a0[0x80000000u & 3u] = (unsigned)((int)(unsigned)c1 < (int)((6u & garr[u2 & 7u]) - (unsigned)(5u == (unsigned)(w0 >> 29))));
                if (-((unsigned)e0 ? (unsigned)(x0 >> 70) : 0u)) break;
            }
        }
    } else {
        if (a0[u1 & 3u]) {
            do { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u3 = fn2(0x7fffffffu, (unsigned)(a0[i0 & 3u] && u1), -((unsigned)(p2 && i1) + (unsigned)d0)); }
                break; (void)(p1);
                if (u0) {
                    switch (r0.x & 7u) {
                        case 0u: ;
                        f0 = f0 * 0.5f + (float)((a0[u1 & 3u] * (unsigned)((short)(unsigned)(0x9642478au || p0) > (signed char)(unsigned)(v0 || (unsigned)c1))) & 255u);
                        w0 = w0 * 6364136223846793005ull + a0[i0 & 3u];
                        if ((unsigned)(0x7fffffffu == 1u)) break;
                        r0.x = r0.x;
                    }
                    if (~(unsigned)((3u * 0x80000000u) || p1)) break;
                    do { if (--fuel == 0u) goto done;
                        break; (void)((unsigned)b0);
                    } while (i1++ < 5u && *mp);
                    b0 = ((unsigned)d0 & (unsigned)(g0 || 0x65d5ba26u)) != 0u;
                }
            } while (i0++ < 4u && (u3 ^ (unsigned)(w0 >> 29)));
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)((unsigned)b0 / ((unsigned)d0 | 1u));
                break; (void)((unsigned)((unsigned)((int)u1 < (int)(unsigned)c1) < garr[u2 & 7u]));
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(x0 >> 70), (unsigned)s0, (unsigned)((int)(unsigned)s0 < (int)(unsigned)(unsigned char)(2u / ((unsigned)(x0 >> 70) | 1u)))); }
                for (;;) { if (--fuel == 0u) goto done;
                    h1 = (unsigned short)(h1 + (unsigned)(((unsigned)((unsigned)c1 < 0x9779de19u) ^ (0x925ccb8u & (unsigned)b0)) < 0xffffffffu));
                    if (budget != 0u) { budget -= 1u; u0 = fn2(0xda7339d3u, (unsigned)((unsigned)(unsigned char)(unsigned)(g0 && (unsigned)e0) && (unsigned)x0), (garr[i1 & 7u] / (r0.x | 1u))); }
                    d0 = d0 * 0.5 + (double)(0x80000000u & 1023u);
                    break; (void)(9u);
                }
                if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)!(unsigned)((short)0x80000000u > (signed char)p2), 2u, (unsigned)(u3 || (unsigned)c1)); }
            }
        } else {
            s0 = (int)(*q0 ^ (0x6f675345u % (0xb8935143u | 1u)));
        }
        s0 = (int)(i1 / ((a0[i0 & 3u] - 0xffffffffu) | 1u));
        r0.x = (2u >> (((unsigned)(w0 >> 29) | (unsigned)h0) & 31u));
        if (budget != 0u) { budget -= 1u; u2 = fn2((0x91cf3894u % (r0.x | 1u)), r0.y, r0.x); }
    }
    m0 ^= (unsigned)!(0x10000u * (unsigned)((short)(8u % (6u | 1u)) > (signed char)(p0 >> (u3 & 31u))));
    s0 = (int)i1;
    garr[(unsigned)x0 & 7u] = ((unsigned)l0 - (unsigned)x0);
    b0 = (unsigned)((int)(unsigned)((int)(unsigned)x0 < (int)g0) < (int)5u) != 0u;
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        w0 = w0 * 6364136223846793005ull + ((unsigned)(x0 >> 70) & (unsigned)(p1 || (unsigned)(u1 && 0x950fc2eeu)));
        e0 = e0 * 0.5L + (long double)((0x251d327cu & (unsigned)(w0 >> 29)) & 1023u);
        while (i1++ < 3u && ((unsigned)w0 | (unsigned)((int)7u < (int)1u))) { if (--fuel == 0u) goto done;
            g1 += (unsigned)((unsigned)((unsigned)x0 < u2) == ((unsigned)b0 / ((unsigned)h0 | 1u)));
            b0 = (((0x16297823u + 0x94522453u) - (unsigned)w0) ^ (a0[i0 & 3u] << (v0 & 31u))) != 0u;
        }
        if ((unsigned)!(p0 & 0xffffffffu)) break;
    }
    if (*q0) goto done;
    r0.x = g0;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn3(1u, garr[u2 & 7u], r0.x); }
        if (fuel < 8u) return ((unsigned)f0 + (0xffffffffu / ((unsigned)c0 | 1u)));
    }
    b0 = (unsigned)(i0 || (unsigned)((0x43bb9d18u ^ *q0) == (unsigned)(unsigned char)((unsigned)h1 + r0.y))) != 0u;
    { unsigned t0; double z0; if (((r0.x + (unsigned)c1)) & 1u) { t0 = ((u0 / (p2 | 1u)) / ((unsigned)l0 | 1u)); z0 = (double)(((garr[i1 & 7u] + i2)) & 255u); } if (((r0.x + (unsigned)c1)) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
        v0 = (unsigned)(fuel < (unsigned)((unsigned)((short)0x10000u > (signed char)*mp) && r0.x));
        if (budget != 0u) { budget -= 1u; u3 = fn3(a0[u1 & 3u], p1, (unsigned)(0x7d8ddc5u || 6u)); }
    }
    if (r0.y) goto L2;
    L0: if (--fuel == 0u) goto done;
    if ((2u - r0.x)) goto L4;
    while ((unsigned)((int)(unsigned)(short)(unsigned)((int)(unsigned)h1 < (int)a0[u1 & 3u]) < (int)(unsigned)w0)) { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            { unsigned t1; double z1; if ((0x10000u) & 1u) { t1 = p0; z1 = (double)(((unsigned)((int)(unsigned)((unsigned)s0 && 4u) >= (int)(unsigned)s0)) & 255u); } if ((0x10000u) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                f0 = f0 * 0.5f + (float)((unsigned)s0 & 255u);
                if ((p2 >> (9u & 31u))) break;
                m0 ^= ((unsigned)(0x9eac8293u || 0x7fffffffu) >> ((unsigned)w0 & 31u));
                { unsigned t2; double z2; if (((unsigned)(3u || (garr[u2 & 7u] ^ garr[u2 & 7u]))) & 1u) { t2 = (unsigned)((short)(unsigned)(short)(0xd5698ab7u + (unsigned)(x0 >> 70)) > (signed char)i2); z2 = (double)(((unsigned)((unsigned)(signed char)(unsigned)((int)m0 < (int)(unsigned)h1) || 0x254faf90u)) & 255u); } if (((unsigned)(3u || (garr[u2 & 7u] ^ garr[u2 & 7u]))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    b0 = u1 != 0u;
                    if (((unsigned)w0 ^ -(p2 | (unsigned)w0))) continue;
                    L1: if (--fuel == 0u) goto done;
                    u3 = (unsigned)((int)(unsigned)h1 >= (int)(unsigned)w0);
                }
            }
        }
        a0[-(a0[u1 & 3u] | (unsigned)(w0 >> 29)) & 3u] = ((unsigned)h1 % ((m0 * (unsigned)(m0 == (unsigned)e0)) | 1u));
        h1 = (unsigned short)(h1 + (unsigned)((((unsigned)x0 + a0[u1 & 3u]) / ((unsigned)h1 | 1u)) == ~(unsigned)((unsigned)f0 || a0[i0 & 3u])));
    }
    do { if (--fuel == 0u) goto done;
        while (i1++ < 2u && ((unsigned)e0 << (i1 & 31u))) { if (--fuel == 0u) goto done;
            switch ((unsigned)((int)0x83c89491u >= (int)m0) & 7u) {
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(0xd91fa938u == (unsigned)((int)*q0 >= (int)(unsigned)(w0 >> 29))), (unsigned)(unsigned char)((unsigned)s0 + 0x8decfe53u), (i1 % ((unsigned)(short)(unsigned)((int)i0 >= (int)6u) | 1u))); }
                g0 = (unsigned)(unsigned char)(9u * (unsigned)(2u < (((unsigned)w0 + (unsigned)h1) | i2)));
                while (i2++ < 4u && (unsigned)((int)r0.y < (int)(unsigned)(0xffffffffu && 0x10000u))) { if (--fuel == 0u) goto done;
                    continue; (void)(6u);
                    a0[0x80000000u & 3u] = (unsigned)(0x651cf71au < ~((unsigned)(w0 >> 29) - (garr[u2 & 7u] % ((unsigned)h1 | 1u))));
                    r0.y ^= (0x3bf4d50du * ((0x48c80f6cu + u2) * (unsigned)f0));
                    if (budget != 0u) { budget -= 1u; u2 = fn3((0x80000000u / ((unsigned)d0 | 1u)), ((unsigned)h0 - u3), *q0); }
                    while (i0++ < 4u && v0) { if (--fuel == 0u) goto done;
                        l0 = (long)((unsigned long)l0 + ((0xffffffffu % ((unsigned)!((unsigned)(w0 >> 29) | *q0) | 1u)) / (0x68eb2068u | 1u)));
                        u0 = ((unsigned)w0 * 0xf7eb00e6u);
                        w0 = w0 * 6364136223846793005ull + i2;
                        continue; (void)(0x8e1d2822u);
                        if (budget != 0u) { budget -= 1u; u1 = fn3(0xc62d24f3u, (unsigned)(g0 || (unsigned)(short)(unsigned)(u0 || a0[i0 & 3u])), (unsigned)(2u == 9u)); }
                    }
                    r0.x = (unsigned)w0;
                }
                v0 = ((0x80000000u >> (garr[i1 & 7u] & 31u)) ? *mp : 0x850e4ccbu);
            }
        }
        if ((unsigned)((short)(unsigned)(garr[i1 & 7u] == i0) > (signed char)(unsigned)c0)) {
            u1 = u1 * 0x9e3779b1u + ((~(unsigned)((int)i1 < (int)3u) | (unsigned)(x0 >> 70)) | g0);
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)(((unsigned)b0 / (0x80000000u | 1u)) % (u3 | 1u)), (unsigned)((int)0x89ee1885u >= (int)(unsigned)((short)(unsigned)h1 > (signed char)(unsigned)l0)), (unsigned)!(unsigned)((int)p0 < (int)u2)); }
            w0 = w0 * 6364136223846793005ull + (unsigned)(2u == 0x80000000u);
        } else {
            u2 = u2 * 0x9e3779b1u + (p2 - (((unsigned)f0 * (unsigned)e0) | (0x7fffffffu << ((unsigned)h1 & 31u))));
            { unsigned t3; double z3; if (((0x80000000u * 5u)) & 1u) { t3 = (unsigned)e0; z3 = (double)(((unsigned)f0) & 255u); } if (((0x80000000u * 5u)) & 1u) { u2 += t3; d0 = d0 * 0.5 + z3; }
                if ((unsigned)(r0.y < (unsigned)((int)(unsigned)e0 < (int)u0))) break;
                v0 = (unsigned)(((unsigned)e0 / (r0.y | 1u)) == (unsigned)h1);
                L2: if (--fuel == 0u) goto done;
                i0 = r0.y & 15u;
            }
        }
    } while (i0++ < 4u && (unsigned)f0);
    if (budget != 0u) { budget -= 1u; u1 = fn1((g1 + ((unsigned)s0 | (unsigned)(x0 >> 70))), (unsigned)(short)((unsigned)f0 << (((unsigned)l0 | p2) & 31u)), (unsigned)(short)(unsigned)((short)-(unsigned)(garr[i1 & 7u] < 0x10000u) > (signed char)g1)); }
    h0 = (short)(unsigned)((unsigned)((short)m0 > (signed char)u1) || ((0x10000u - (unsigned)s0) << (v0 & 31u)));
    if ((unsigned)(garr[i1 & 7u] == (*q0 | (unsigned)e0))) {
        *mp = (unsigned)(((unsigned)x0 * v0) && (unsigned)((int)0x80000000u >= (int)i2));
        q0 = &garr[(i0 & garr[u2 & 7u]) & 7u];
        switch ((unsigned)((unsigned)l0 && ~((unsigned)b0 | a0[i0 & 3u])) & 7u) {
            for (;;) { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 2u: ;
                    if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)f0 / (g0 | 1u)), r0.y, 0x9e2054eu); }
                }
                if (-(0xce1bc8c8u >> ((unsigned)h0 & 31u))) goto L2;
                case 7u: ;
            }
            if (((unsigned)d0 / ((unsigned)(x0 >> 70) | 1u))) goto L1;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((short)v0 > (signed char)((unsigned)e0 | i0)), (a0[u1 & 3u] | g1), 7u); }
            b0 = 0xf99be0cbu != 0u;
        }
        c0 = (unsigned char)(i0 >> (garr[u2 & 7u] & 31u));
        while (i0++ < 5u && (unsigned)(3u == 0xffffffffu)) { if (--fuel == 0u) goto done;
            b0 = 0x22b2cea6u != 0u;
            r0.y ^= ((unsigned)s1 * (i2 * r0.x));
        }
    } else {
        d0 = d0 * 0.5 + (double)((unsigned)((int)(unsigned)(fuel == 0x7fffffffu) >= (int)1u) & 1023u);
        if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)(unsigned char)(unsigned)((int)(unsigned)(w0 >> 29) >= (int)0x7fffffffu) & (unsigned)h0), (unsigned)(unsigned char)(m0 - 2u), (p2 & ((unsigned)(x0 >> 70) & (unsigned)x0))); }
        do { if (--fuel == 0u) goto done;
            { unsigned t4; double z4; if ((7u) & 1u) { t4 = u2; z4 = (double)(((unsigned)(p0 || (unsigned)b0)) & 255u); } if ((7u) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                r0.x = 0x9071fb2du;
                u1 += (0x5e0e1b16u / (((unsigned)(short)(0x7fffffffu % ((unsigned)b0 | 1u)) / ((unsigned)f0 | 1u)) | 1u));
            }
            if ((u0 - 0xffffffffu)) break;
            break; (void)((0x10000u & (unsigned)((int)v0 < (int)v0)));
            h0 = (short)(unsigned)(-((unsigned)(unsigned char)(unsigned)(garr[u2 & 7u] < 0xcfac739fu) - 0x7fffffffu) || *q0);
            L3: if (--fuel == 0u) goto done;
            i0 = (unsigned)(signed char)(unsigned)(u3 && 0xdcac98e6u) & 15u;
        } while (i0++ < 5u && (unsigned)(3u || (unsigned)(i1 < a0[u1 & 3u])));
        do { if (--fuel == 0u) goto done;
            if ((unsigned)((unsigned)(short)(unsigned)((short)0x7fffffffu > (signed char)a0[i0 & 3u]) < (unsigned)h0)) {
                break; (void)(((0x10000u | g0) >> (r0.y & 31u)));
            }
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(u3 == 5u), 0xafaf277bu, (unsigned)((int)(unsigned)s0 >= (int)(unsigned)(short)(unsigned)((int)garr[u2 & 7u] >= (int)1u))); }
            u1 = u1 * 0x9e3779b1u + (unsigned)(0x7fffffffu < 0x7fffffffu);
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)(6u == 9u) && u3), (unsigned)(garr[u2 & 7u] < (unsigned)(w0 >> 29)), (unsigned)d0); }
            r0.y ^= (unsigned)((int)garr[i1 & 7u] >= (int)((i0 / ((unsigned)b0 | 1u)) % (i2 | 1u)));
        } while (i0++ < 4u && ((i2 ^ g1) % (0u | 1u)));
    }
    m0 ^= (unsigned)((int)(unsigned)h1 >= (int)(0x65994e4u % ((unsigned)((short)garr[u2 & 7u] > (signed char)g0) | 1u)));
    if ((unsigned)((int)((unsigned)d0 & 6u) >= (int)(unsigned)s0)) goto L3;
    h0 = (short)(unsigned)((unsigned)w0 == a0[u1 & 3u]);
    w0 ^= (unsigned long long)garr[i1 & 7u] << ((unsigned)(0x58865780u || ((0x10000u ? i0 : (unsigned)c0) / (0x8883f89eu | 1u))) & 63u);
    if ((0xd6a07314u % ((unsigned)w0 | 1u))) {
        { unsigned t5; double z5; if (((i2 - (unsigned)d0)) & 1u) { t5 = (unsigned)(i0 < ((unsigned)h0 | (unsigned)h1)); z5 = (double)((((unsigned)w0 >> (i0 & 31u))) & 255u); } if (((i2 - (unsigned)d0)) & 1u) { u1 += t5; d0 = d0 * 0.5 + z5; }
            if (*q0) {
                if ((unsigned)d0) {
                    { unsigned t6; double z6; if (((0x10000u | g1)) & 1u) { t6 = (unsigned)f0; z6 = (double)(((g0 * (unsigned)(w0 >> 29))) & 255u); } if (((0x10000u | g1)) & 1u) { u2 += t6; d0 = d0 * 0.5 + z6; }
                        if (u0) goto L3;
                        while (i0++ < 6u && (unsigned)!(0x2be855d5u & (g1 >> (0x9118065du & 31u)))) { if (--fuel == 0u) goto done;
                            w0 = w0 * 6364136223846793005ull + u3;
                            h0 = (short)1u;
                            q0 = &garr[((i0 | (v0 + a0[i0 & 3u])) | (unsigned)x0) & 7u];
                        }
                    }
                    L4: if (--fuel == 0u) goto done;
                } else {
                    q0 = &garr[(((unsigned)d0 | (i1 % (r0.x | 1u))) & (unsigned)((short)(unsigned)f0 > (signed char)v0)) & 7u];
                    goto L4;
                    if ((unsigned)(0x78fc0560u == p2)) goto L3;
                }
                r0.y ^= ((unsigned)((unsigned)((int)u1 >= (int)0xf749dbd0u) && 0x10000u) * 6u);
                u1 = u1 * 0x9e3779b1u + ((0x10000u / ((unsigned)w0 | 1u)) & r0.y);
            }
            e0 = e0 * 0.5L + (long double)(5u & 1023u);
            goto L1;
            m0 ^= (unsigned)!((unsigned)(signed char)((r0.y & (unsigned)(w0 >> 29)) | (unsigned)x0) ^ (fuel - u1));
            if (0x80000000u) goto L4;
            goto L3;
        }
        u2 = (garr[u2 & 7u] >> (0x18ee34e8u & 31u));
        if (budget != 0u) { budget -= 1u; u3 = fn1((0xffffffffu ^ a0[i0 & 3u]), ((g1 + (unsigned)b0) ^ garr[u2 & 7u]), -(0x10000u << (0x7fffffffu & 31u))); }
    }
    { unsigned t7; double z7; if (((unsigned)f0) & 1u) { t7 = (unsigned)((int)i1 < (int)g1); z7 = (double)(((unsigned)((short)(unsigned)c0 > (signed char)0xffffffffu)) & 255u); } if (((unsigned)f0) & 1u) { u3 += t7; d0 = d0 * 0.5 + z7; }
        goto L4;
    }
    if (((unsigned)(0x613b0ac5u || p2) * (unsigned)c1)) {
        s0 = (int)p2;
        if (((0x6816cda5u / (2u | 1u)) + (unsigned)(w0 >> 29))) {
            g1 += (unsigned)h1;
            while (i0++ < 4u && (unsigned)(-(unsigned)((short)(unsigned)e0 > (signed char)(unsigned)(w0 >> 29)) && 0xffffffffu)) { if (--fuel == 0u) goto done;
                break; (void)((unsigned)(x0 >> 70));
                if (budget != 0u) { budget -= 1u; u2 = fn3((m0 ^ (unsigned)((short)a0[u1 & 3u] > (signed char)6u)), (u0 * (unsigned)(a0[u1 & 3u] || 0x10000u)), (unsigned)(0xffffffffu < (unsigned)(i2 || (unsigned)d0))); }
                break; (void)((v0 & (unsigned)(r0.x && (unsigned)(w0 >> 29))));
                if ((a0[i0 & 3u] % ((unsigned)(p2 == fuel) | 1u))) {
                    break; (void)((unsigned)((unsigned)w0 < (p1 - p1)));
                    h0 = (short)((unsigned)((unsigned)d0 < (p2 | r0.x)) & 0x80000000u);
                    break; (void)(p1);
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)((int)-(unsigned)((short)((unsigned)l0 & (unsigned)h1) > (signed char)(unsigned)((int)p2 >= (int)g0)) >= (int)u1);
            }
            g0 = ((unsigned)c1 % ((unsigned)((int)r0.y < (int)(unsigned)((int)0xdc6b8b04u < (int)u2)) | 1u));
            u2 = (unsigned)(r0.y && (unsigned)e0);
        }
        e0 = e0 * 0.5L + (long double)((unsigned)((int)(unsigned)((int)garr[u2 & 7u] < (int)garr[i1 & 7u]) < (int)g1) & 1023u);
    } else {
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)w0 && (5u | *q0)), garr[i1 & 7u], 2u); }
        if (fuel < 8u) return ((unsigned)(0u < (unsigned)((short)m0 > (signed char)(2u & 0x80000000u))) % ((unsigned)c1 | 1u));
    }
    u3 += (unsigned)(signed char)((u0 + i0) % (0x49160b9eu | 1u));
    g1 += (0x277cb122u - (unsigned)e0);
    goto L2;
    goto L2;
    *q0 += (unsigned)c0;
    c1 = (signed char)(unsigned)l0;
    if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)h1, i0, (unsigned)((int)0x80000000u < (int)u0)); }
    b0 = (unsigned)l0 != 0u;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 15u, 0x5212fce7u, 0x9df076c7u },
        { 11u, 0xe1f5da9cu, 0x85f6c28du },
        { 4u, 0x63274169u, 0x5f59b2d2u },
        { 15u, 0x99ee9525u, 0xf447a443u },
        { 8u, 0xabc82348u, 0x2a2d211fu },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
