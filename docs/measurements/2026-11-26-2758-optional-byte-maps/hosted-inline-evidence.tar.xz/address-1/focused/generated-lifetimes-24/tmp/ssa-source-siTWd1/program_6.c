// test-ssa-source's program of seed 141000429 (ssa_source_generate.c).
int printf(const char*, ...);

struct ssa_pair { unsigned x; unsigned y; };

static unsigned budget;
static unsigned g0 = 0xfb96341au, g1 = 0x8f975fceu;
static unsigned garr[8] = { 0x5a044066u, 0xb29a2b4fu, 0x3eb33de5u, 0x60ea706fu, 0xb74c1bf6u, 0xe1ce1402u, 0xc4fe2ecau, 0x7dc1cccdu };

static unsigned fn0(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    { unsigned t0; double z0; if ((((unsigned)x0 % (*mp | 1u))) & 1u) { t0 = (unsigned)((int)(unsigned)(w0 >> 29) < (int)((unsigned)h1 ^ u3)); z0 = (double)((p2) & 255u); } if ((((unsigned)x0 % (*mp | 1u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
        L0: if (--fuel == 0u) goto done;
        u3 = (unsigned)((0x80000000u << (7u & 31u)) || r0.y);
        if (u3 == 7u) return (unsigned)((unsigned)(g1 || i0) < (0xffffffffu | a0[u1 & 3u]));
        c1 = (signed char)(p2 >> (((unsigned)(unsigned char)(unsigned)((u1 % (i0 | 1u)) < (unsigned)s0) - i1) & 31u));
    }
    *mp = (unsigned)x0;
    switch ((unsigned)(0x8a11565cu || (unsigned)h0) & 7u) {
        case 0u: ;
        if (-(unsigned)((unsigned)c1 && (0x58c719deu / (u3 | 1u)))) {
            if (garr[i1 & 7u]) goto L1;
            m0 ^= (unsigned)(x0 >> 70);
            e0 = e0 * 0.5L + (long double)(((unsigned)x0 + (unsigned)((int)p0 < (int)a0[u1 & 3u])) & 1023u);
            L1: if (--fuel == 0u) goto done;
            l0 = (long)((unsigned long)l0 + ((unsigned)!(g0 ^ u0) / ((unsigned)((int)7u >= (int)(unsigned)(0x7fffffffu == r0.x)) | 1u)));
        } else {
            u2 ^= 0x7fffffffu;
            L2: if (--fuel == 0u) goto done;
            u0 ^= (unsigned)((unsigned)((unsigned)((int)(unsigned)h0 < (int)(unsigned)(w0 >> 29)) == (unsigned)f0) == -((unsigned)w0 >> (9u & 31u)));
        }
    }
    while (i0++ < 2u && (unsigned)(v0 < 0xffffffffu)) { if (--fuel == 0u) goto done;
        g0 = (i0 ^ p0);
    }
    *q0 += (unsigned)((0x7fffffffu + (unsigned)((int)p0 >= (int)8u)) < (u3 - 0u));
    L3: if (--fuel == 0u) goto done;
    *q0 = (fuel | 0x80000000u);
    if (u0) {
        do { if (--fuel == 0u) goto done;
            L4: if (--fuel == 0u) goto done;
            u1 += u2;
            g1 += p1;
            w0 ^= (unsigned long long)0xf11f9de3u << ((unsigned)(*mp && (unsigned)(1u < (unsigned)(v0 < *mp))) & 63u);
            if ((unsigned)((short)0x80000000u > (signed char)(unsigned)l0)) break;
            if ((unsigned)((short)u3 > (signed char)i1)) break;
        } while (i0++ < 2u && (3u << ((unsigned)((int)a0[u1 & 3u] < (int)*q0) & 31u)));
    }
    v0 = i0;
    { unsigned t1; double z1; if (((unsigned)((unsigned)h0 && (0x3aea7acdu + (unsigned)(x0 >> 70)))) & 1u) { t1 = (fuel << ((0xc9ec80c4u / (garr[u2 & 7u] | 1u)) & 31u)); z1 = (double)((a0[i0 & 3u]) & 255u); } if (((unsigned)((unsigned)h0 && (0x3aea7acdu + (unsigned)(x0 >> 70)))) & 1u) { u1 += t1; d0 = d0 * 0.5 + z1; }
        if ((unsigned)((short)(unsigned)((int)g1 >= (int)(unsigned)c0) > (signed char)(unsigned)c1)) {
            s1 = (int)((unsigned)s1 + 0xfb6337c6u);
            do { if (--fuel == 0u) goto done;
                if ((0xffffffffu << (v0 & 31u))) break;
                goto L0;
                f0 = f0 * 0.5f + (float)(((unsigned)((unsigned)(u0 && (unsigned)e0) < i1) << (0x11ad0870u & 31u)) & 255u);
            } while (i0++ < 3u && (unsigned)(0x6ec58961u && (unsigned)h1));
            c1 = (signed char)((unsigned)(*mp == (0u | r0.y)) * fuel);
            if (m0) {
                i1 = (unsigned)((unsigned)((short)(m0 + (unsigned)h1) > (signed char)0x80000000u) < 6u) & 15u;
                *q0 += ((unsigned)((int)(unsigned)((int)(unsigned)h0 < (int)(unsigned)l0) < (int)i2) / (fuel | 1u));
                f0 = f0 * 0.5f + (float)(~(unsigned)((int)8u >= (int)9u) & 255u);
                if ((7u & 0xffffffffu)) goto L0;
            }
        }
        goto done;
    }
    if (u3 == 7u) return (0x7fffffffu << (i2 & 31u));
    u1 += (i0 % ((unsigned)x0 | 1u));
    i0 = (unsigned)((int)*q0 >= (int)(unsigned)b0) & 15u;
    l0 = (long)((unsigned long)l0 + 0xf0a56feu);
    if ((unsigned)((int)(p1 ^ r0.x) >= (int)i2)) goto L2;
    w0 = w0 * 6364136223846793005ull + ((unsigned)((0x7fffffffu & 0x10000u) < garr[i1 & 7u]) >> ((unsigned)(unsigned char)((unsigned)f0 * (unsigned)h0) & 31u));
    u1 = u1 * 0x9e3779b1u + (unsigned)((unsigned)((int)((unsigned)(w0 >> 29) * 3u) < (int)0x7fffffffu) < 4u);
    a0[(unsigned)w0 & 3u] = (unsigned)h0;
    if ((unsigned)(0x10000u < (unsigned)(short)(8u >> (g0 & 31u)))) goto L1;
    if ((unsigned)(short)((unsigned)(short)(0x10000u % ((unsigned)(x0 >> 70) | 1u)) << (u0 & 31u))) {
        v0 = 0x7fffffffu;
        a0[~(0x5e02d01du % ((unsigned)c0 | 1u)) & 3u] = p2;
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((int)(unsigned)s0 >= (int)0x39f62859u)) break;
        }
        while (i0++ < 2u && (p2 ^ ((unsigned)c0 & (unsigned)e0))) { if (--fuel == 0u) goto done;
            u3 = u3 * 0x9e3779b1u + (((unsigned)s1 % (3u | 1u)) & (unsigned)((int)(unsigned)l0 >= (int)(unsigned)h0));
            if (u2) break;
            break; (void)((a0[i0 & 3u] ? i1 : 8u));
        }
    }
    h1 = (unsigned short)(h1 + ((unsigned)((int)(unsigned)((unsigned)x0 || (u3 + (unsigned)x0)) >= (int)0x80000000u) >> (0x2e5443b9u & 31u)));
    goto L4;
    if ((a0[u1 & 3u] & g1)) goto L1;
    s1 = (int)((unsigned)s1 + (unsigned)((short)(unsigned)c1 > (signed char)(unsigned)((short)(unsigned)d0 > (signed char)p1)));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn1(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    x0 = x0 * 0x100000001b3ull + ((unsigned)((a0[i0 & 3u] | i0) == v0) ^ (unsigned)(0x6d631c2u == 0x8819876au));
    h1 = (unsigned short)(h1 + (0x7fffffffu * (unsigned)s0));
    switch ((v0 - p1) & 7u) {
        if ((unsigned)((unsigned)s1 < (0x10000u >> (g0 & 31u)))) {
            case 6u: ;
            a0[(unsigned)(u1 < a0[u1 & 3u]) & 3u] = (unsigned)((short)*mp > (signed char)r0.y);
        }
        switch ((unsigned)(u3 && (unsigned)((int)g1 >= (int)0x80000000u)) & 7u) {
            *mp = (((unsigned)((int)(unsigned)(x0 >> 70) < (int)(unsigned)(x0 >> 70)) & v0) * ((unsigned)l0 ^ r0.x));
            m0 ^= (r0.y / ((unsigned)h1 | 1u));
        }
        m0 ^= (unsigned)(((unsigned)c0 | g1) < (g1 % ((unsigned)(a0[i0 & 3u] && g0) | 1u)));
    }
    if (r0.x) goto L1;
    c1 = (signed char)(unsigned)!((unsigned)(short)(unsigned)(0x548c1995u < (unsigned)x0) >> ((unsigned)b0 & 31u));
    if ((unsigned)(signed char)(9u ? 0xecf33b06u : v0)) goto L4;
    do { if (--fuel == 0u) goto done;
        *mp = v0;
        switch (((unsigned)d0 >> (r0.x & 31u)) & 7u) {
            case 0u: ;
            i1 = *q0 & 15u;
            g1 += (unsigned)((unsigned)((u0 << ((unsigned)h0 & 31u)) && r0.x) < -((unsigned)s0 >> (g1 & 31u)));
            a0[(p0 - a0[u1 & 3u]) & 3u] = ((v0 - (unsigned)f0) >> ((unsigned)l0 & 31u));
            for (;;) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    w0 = w0 * 6364136223846793005ull + (((unsigned)f0 - m0) % ((unsigned)c1 | 1u));
                    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
                        case 5u: ;
                    }
                    *q0 = (unsigned)((short)(unsigned)(0xf2109bb1u < 6u) > (signed char)(0x13d07e59u & (v0 ^ i1)));
                } while (i2++ < 6u && ~(unsigned)(0x80000000u && (unsigned)((int)a0[i0 & 3u] < (int)(unsigned)c1)));
            }
        }
        w0 = w0 * 6364136223846793005ull + (unsigned)((*mp << (8u & 31u)) < 0xa083fb1du);
        switch ((g1 % (g0 | 1u)) & 7u) {
            continue; (void)((unsigned)(i2 == a0[u1 & 3u]));
            u2 = ((unsigned)b0 ? m0 : (0x80000000u >> ((unsigned)(5u && v0) & 31u)));
            L0: if (--fuel == 0u) goto done;
            switch (((unsigned)s1 << ((unsigned)(short)(unsigned)((short)(unsigned)h1 > (signed char)1u) & 31u)) & 7u) {
                s0 = (int)(((unsigned)e0 ? u3 : 8u) % (((unsigned)x0 % (p1 | 1u)) | 1u));
            }
            { unsigned t0; double z0; if ((((unsigned)((short)a0[u1 & 3u] > (signed char)*mp) / (p0 | 1u))) & 1u) { t0 = (p1 ? 0xf28613c2u : a0[u1 & 3u]); z0 = (double)(((unsigned)b0) & 255u); } if ((((unsigned)((short)a0[u1 & 3u] > (signed char)*mp) / (p0 | 1u))) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
                case 4u: ;
                s1 = (int)((unsigned)s1 + (m0 ^ g1));
            }
        }
        { unsigned t1; double z1; if (((unsigned)((unsigned)c0 == (0xb221cafau / (m0 | 1u)))) & 1u) { t1 = (5u / ((unsigned)(short)((unsigned)c0 << (0x7fffffffu & 31u)) | 1u)); z1 = (double)(((unsigned)(g0 && garr[i1 & 7u])) & 255u); } if (((unsigned)((unsigned)c0 == (0xb221cafau / (m0 | 1u)))) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
            break; (void)(0x80000000u);
            if ((unsigned)(((unsigned)d0 & a0[u1 & 3u]) && r0.x)) break;
            while (v0) { if (--fuel == 0u) goto done;
                switch ((a0[u1 & 3u] ? g0 : 9u) & 7u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0(((unsigned)s0 & i2), (unsigned)s1, (unsigned)(*mp || u0)); }
                }
                if (-(unsigned)(p1 && g0)) continue;
                if (*q0) break;
                do { if (--fuel == 0u) goto done;
                    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        L1: if (--fuel == 0u) goto done;
                        L2: if (--fuel == 0u) goto done;
                        { unsigned t2; double z2; if (((unsigned)((int)(unsigned)(3u || 0x9bf790ccu) < (int)0x71caaa19u)) & 1u) { t2 = i0; z2 = (double)((((unsigned)(x0 >> 70) + (unsigned)(*q0 < *q0))) & 255u); } if (((unsigned)((int)(unsigned)(3u || 0x9bf790ccu) < (int)0x71caaa19u)) & 1u) { u2 += t2; d0 = d0 * 0.5 + z2; }
                            w0 = w0 * 6364136223846793005ull + (unsigned)(signed char)((unsigned)f0 + (m0 - p2));
                            if (~((unsigned)((int)i1 < (int)(unsigned)d0) << (r0.x & 31u))) break;
                            if (((unsigned)w0 >> (((unsigned)(w0 >> 29) / ((unsigned)(x0 >> 70) | 1u)) & 31u))) goto L2;
                            q0 = &garr[0x7fffffffu & 7u];
                            r0.y ^= (unsigned)((short)u2 > (signed char)(*mp & ((unsigned)c1 << (p2 & 31u))));
                            u3 += (0x80000000u | ~(unsigned)(garr[i1 & 7u] || (unsigned)s1));
                        }
                        d0 = d0 * 0.5 + (double)(0x7fffffffu & 1023u);
                        if ((a0[u1 & 3u] ^ m0)) goto L1;
                    }
                    if (budget != 0u) { budget -= 1u; u1 = fn0((a0[i0 & 3u] | 8u), (unsigned)c0, (unsigned)s1); }
                    if ((unsigned)(6u == u3)) {
                        if (budget != 0u) { budget -= 1u; u2 = fn0(1u, ((a0[i0 & 3u] ^ fuel) ^ (unsigned)w0), (0x35e2b79du | (unsigned)(x0 >> 70))); }
                        if ((((unsigned)w0 * (unsigned)d0) % (u1 | 1u))) break;
                        if (0u) goto done;
                        L3: if (--fuel == 0u) goto done;
                        m0 ^= ((0x2f02d51fu ^ r0.x) + *q0);
                    } else {
                        s0 = (int)(0x80000000u & (a0[u1 & 3u] << (5u & 31u)));
                        *q0 = (unsigned)(garr[u2 & 7u] || ((unsigned)b0 ? u1 : p0));
                        e0 = e0 * 0.5L + (long double)(((unsigned)h1 ^ (unsigned)h1) & 1023u);
                    }
                    q0 = &garr[((unsigned)((unsigned)(w0 >> 29) || 6u) / ((unsigned)((int)2u < (int)(unsigned)h1) | 1u)) & 7u];
                } while (i2++ < 7u && (unsigned)((unsigned)s1 && (unsigned)((short)(unsigned)w0 > (signed char)r0.y)));
            }
            break; (void)(((unsigned)((unsigned)(w0 >> 29) == 0x10000u) % (0x80000000u | 1u)));
        }
    } while (i0++ < 5u && 0x1708d13fu);
    switch ((unsigned)h1 & 7u) {
        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(short)(unsigned)((m0 % (i0 | 1u)) < 0xffffffffu), (unsigned)!((unsigned)(w0 >> 29) << ((unsigned)(x0 >> 70) & 31u)), (unsigned)((unsigned)(x0 >> 70) || (unsigned)((int)g0 >= (int)(unsigned)d0))); }
        f0 = f0 * 0.5f + (float)((unsigned)!(unsigned)((5u + ((unsigned)b0 & garr[i1 & 7u])) == u3) & 255u);
        v0 = (unsigned)f0;
        *q0 = (u0 & *mp);
        case 0u: ;
    }
    u2 = i0;
    if ((unsigned)((short)8u > (signed char)(unsigned)(0u && i1))) goto L0;
    if (0x547393d2u) {
        u0 = u0 * 0x9e3779b1u + (unsigned)((unsigned)(garr[u2 & 7u] < (unsigned)(x0 >> 70)) < (unsigned)(p2 || -(4u + a0[u1 & 3u])));
        if (fuel < 8u) return (0u / ((unsigned)(unsigned char)(p2 ^ g0) | 1u));
        if ((v0 / ((unsigned)((short)0x80000000u > (signed char)(unsigned)l0) | 1u))) goto L2;
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (unsigned)((short)((unsigned)((short)p0 > (signed char)0x19c9f382u) % ((unsigned)c1 | 1u)) > (signed char)u2);
            u0 = u0 * 0x9e3779b1u + ((unsigned)(x0 >> 70) / (r0.y | 1u));
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)((int)garr[u2 & 7u] < (int)(unsigned)(x0 >> 70)), (unsigned)h0, v0); }
            goto L3;
            s0 = (int)(unsigned)((int)(unsigned)(x0 >> 70) >= (int)(((unsigned)h1 ? *mp : i1) ^ u0));
        }
        if ((i2 / ((unsigned)(8u && (unsigned)b0) | 1u))) goto done;
    }
    g0 = ((p1 ? i1 : 9u) ^ (unsigned)c0);
    garr[u1 & 7u] = (unsigned)(short)(unsigned)((0xb1f9b37au * ((unsigned)s1 % (9u | 1u))) && (unsigned)e0);
    if ((unsigned)(*q0 == (2u + (unsigned)l0))) {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)((5u << (0x2af5c314u & 31u)) && m0)) break;
            u3 = (unsigned)((unsigned)((int)0xe472da3bu >= (int)i2) < ((unsigned)(signed char)(unsigned)((int)m0 < (int)(unsigned)(w0 >> 29)) ^ (unsigned)b0));
            if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)(5u || (unsigned)d0) < (int)(unsigned)c1), (unsigned)!(unsigned)(0x10000u && (p0 - i1)), (u3 & 0x80000000u)); }
            l0 = (long)((unsigned long)l0 + (unsigned)(0xca5b809du < (~(0x685683b6u << (0u & 31u)) ^ (a0[i0 & 3u] | (unsigned)s0))));
        }
        switch ((unsigned)(u2 < 1u) & 7u) {
            s1 = (int)((unsigned)s1 + (unsigned)(0xe852821du || (unsigned)h1));
            if (-(i2 + *q0)) goto L2;
            if ((unsigned)(i1 || (unsigned)((int)0x10000u < (int)7u))) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(short)(unsigned)(i0 < 0xdd8e15f9u), ((unsigned)e0 | (0x10000u >> (a0[u1 & 3u] & 31u))), 3u); }
            if (~((*mp / (0x10000u | 1u)) / (8u | 1u))) goto L3;
            goto L0;
        }
    }
    g0 = (a0[u1 & 3u] >> (((unsigned)s1 ^ i0) & 31u));
    goto L0;
    switch ((unsigned)((unsigned)c0 < garr[i1 & 7u]) & 7u) {
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)l0, (unsigned)((unsigned)d0 == (unsigned)h0), (unsigned)w0); }
        g1 += ((unsigned)s1 - (r0.y * (unsigned)d0));
        if (garr[u2 & 7u]) break;
        { unsigned t3; double z3; if (((unsigned)c1) & 1u) { t3 = fuel; z3 = (double)(((unsigned)(unsigned char)(unsigned)((unsigned)h0 < m0)) & 255u); } if (((unsigned)c1) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
            w0 = w0 * 6364136223846793005ull + ((unsigned)((int)(~(0x4c0f2045u | u2) >> (i1 & 31u)) < (int)(unsigned)h0) << (4u & 31u));
            v0 = ((unsigned)x0 * fuel);
        }
        do { if (--fuel == 0u) goto done;
            continue; (void)(0u);
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)f0;
                c0 = (unsigned char)r0.y;
                b0 = (0x86ae1b68u & 0x10000u) != 0u;
            }
        } while (i0++ < 6u && ((garr[i1 & 7u] ^ i0) | (unsigned)(x0 >> 70)));
    }
    f0 = f0 * 0.5f + (float)((unsigned)(short)(-(g1 / (0x80000000u | 1u)) + u3) & 255u);
    i0 = fuel & 15u;
    for (;;) { if (--fuel == 0u) goto done;
        if (i1) {
            s0 = (int)(7u ? (unsigned)d0 : (unsigned)x0);
            break; (void)(0x7ca018c9u);
            if ((a0[u1 & 3u] & 0xa66d4457u)) {
                for (i1 = 0u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)w0, (2u % (7u | 1u)), (unsigned)w0); }
                    if ((unsigned)((int)(unsigned)c1 >= (int)0x38c43532u)) break;
                    w0 ^= (unsigned long long)(unsigned)(0x10000u < u0) << (v0 & 63u);
                    w0 ^= (unsigned long long)(unsigned)((short)9u > (signed char)(unsigned)l0) << (6u & 63u);
                    s0 = (int)(unsigned)((int)(unsigned)(signed char)((unsigned)x0 - (unsigned)h1) >= (int)((p2 * (unsigned)(x0 >> 70)) % (u0 | 1u)));
                }
            }
            break; (void)((5u * (3u * 3u)));
        }
        if (u3) goto L4;
    }
    if ((unsigned)(0xffffffffu && (unsigned)e0)) {
        if ((unsigned)!(unsigned)(u0 < 0u)) goto L2;
        if (u0) goto L1;
        w0 ^= (unsigned long long)(unsigned)(0xa4ca657cu || m0) << ((unsigned)(m0 < (unsigned)l0) & 63u);
    }
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        garr[garr[i1 & 7u] & 7u] = (unsigned)((short)m0 > (signed char)(unsigned)h1);
        goto L0;
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)0xb8ab08d3u < (int)*q0), (unsigned)((int)(unsigned)d0 < (int)g1), ((unsigned)(m0 && u2) >> ((unsigned)s1 & 31u))); }
        if (i0) {
            if ((0xecc9f796u + r0.y)) continue;
        }
    }
    L4: if (--fuel == 0u) goto done;
    switch (r0.x & 7u) {
        case 5u: ;
        case 0u: ;
        garr[(unsigned)l0 & 7u] = (unsigned)(signed char)((unsigned)(signed char)(((unsigned)(w0 >> 29) * u3) - a0[i0 & 3u]) | (unsigned)(short)((unsigned)(w0 >> 29) % (0xa4e6fd61u | 1u)));
        case 2u: ;
        default: ;
    }
    if (((unsigned)e0 + fuel)) {
        for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (i1++ < 6u && (0x10000u & ((unsigned)d0 * (unsigned)h1))) { if (--fuel == 0u) goto done;
                do { if (--fuel == 0u) goto done;
                    c0 = (unsigned char)(unsigned)((int)0xffffffffu >= (int)0x28ce4cf3u);
                } while (i2++ < 7u && 0x80000000u);
                a0[(8u % (0xc2a35552u | 1u)) & 3u] = (i2 + (0x80000000u ^ ((unsigned)x0 << ((i1 & garr[u2 & 7u]) & 31u))));
                if ((unsigned)((int)(unsigned)h1 >= (int)r0.y)) break;
            }
            q0 = &garr[(unsigned)(unsigned char)((unsigned)f0 + (unsigned)h0) & 7u];
            if (((unsigned)(0x9b2890bau || 0x80000000u) - 0x534fdf5cu)) break;
        }
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            u2 = u2 * 0x9e3779b1u + ((unsigned)((0x4748454au >> (p1 & 31u)) == 0x1f21877eu) + (unsigned)f0);
            break; (void)((0u + (unsigned)(x0 >> 70)));
            *mp = ((unsigned)s0 << ((unsigned)c0 & 31u));
            f0 = f0 * 0.5f + (float)((unsigned)(unsigned char)(unsigned)(((unsigned)(w0 >> 29) - (unsigned)c1) < (unsigned)(short)((unsigned)x0 + 0x80000000u)) & 255u);
            while (((unsigned)c0 << ((unsigned)(short)(unsigned)(g1 == u3) & 31u))) { if (--fuel == 0u) goto done;
                c1 = (signed char)((unsigned)((int)(unsigned)b0 >= (int)i2) * 0xfab93fd0u);
                c1 = (signed char)(0x9168cda3u + *mp);
                break; (void)((0x7a4208au + i1));
            }
            if ((unsigned)(v0 < (unsigned)((unsigned)w0 < (unsigned)f0))) goto L2;
        }
    }
    if ((unsigned)(0x4c048f0bu && i1)) goto L1;
    { unsigned t4; double z4; if (((g1 + i1)) & 1u) { t4 = ((unsigned)s1 % (8u | 1u)); z4 = (double)((((unsigned)c1 >> ((unsigned)((short)0x80000000u > (signed char)p0) & 31u))) & 255u); } if (((g1 + i1)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
        f0 = f0 * 0.5f + (float)((0x352b57a0u & (*mp ? (unsigned)s1 : r0.y)) & 255u);
        switch ((r0.y / (9u | 1u)) & 7u) {
            switch ((-(unsigned)((short)garr[u2 & 7u] > (signed char)fuel) / ((unsigned)s1 | 1u)) & 7u) {
                u1 += (unsigned)(signed char)(7u % ((unsigned)(0x870b1e9bu == (unsigned)s1) | 1u));
                *q0 += ((unsigned)((int)(a0[i0 & 3u] << (fuel & 31u)) < (int)(unsigned)d0) ^ (m0 >> (p0 & 31u)));
                w0 = w0 * 6364136223846793005ull + 4u;
                if (u2) {
                    v0 = (unsigned)((int)i0 < (int)(unsigned)((short)i2 > (signed char)u1));
                    if (budget != 0u) { budget -= 1u; u1 = fn0(~(unsigned)((short)(r0.x ^ r0.x) > (signed char)(unsigned)(x0 >> 70)), -(unsigned)(garr[i1 & 7u] && (0u >> (g1 & 31u))), ~(unsigned)((unsigned)(1u || (unsigned)c0) == i1)); }
                    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                        case 7u: ;
                        case 6u: ;
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0((i1 - *mp), (0xcd7f4fedu ^ (unsigned)((short)(unsigned)w0 > (signed char)r0.y)), ((unsigned)s1 * i0)); }
                    switch (((u3 * (unsigned)e0) % (0x284889d0u | 1u)) & 7u) {
                        case 4u: ;
                        goto L3;
                    }
                }
                q0 = &garr[i1 & 7u];
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)!((g0 >> (i2 & 31u)) | 0x7fffffffu), (((unsigned)b0 << (u1 & 31u)) * (unsigned)(x0 >> 70)), (0x7fffffffu << ((unsigned)(2u < r0.x) & 31u))); }
        switch (((u1 << (m0 & 31u)) | *q0) & 7u) {
            for (;;) { if (--fuel == 0u) goto done;
                if ((p1 * 3u)) continue;
                m0 ^= (unsigned)((p2 << ((unsigned)s1 & 31u)) || (unsigned)c0);
                u1 = u1 * 0x9e3779b1u + (unsigned)((int)a0[u1 & 3u] >= (int)p1);
                case 3u: ;
                garr[7u & 7u] = (unsigned)((short)(unsigned)(short)((unsigned)c0 - (unsigned)h0) > (signed char)9u);
                do { if (--fuel == 0u) goto done;
                    q0 = &garr[*q0 & 7u];
                } while (i1++ < 3u && (unsigned)((unsigned)s0 < p0));
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)d0, (a0[i0 & 3u] & (unsigned)h0), garr[u2 & 7u]); }
            if (~((p2 - (unsigned)s0) >> (u3 & 31u))) goto L1;
            if ((unsigned)(7u < u3)) goto L0;
            garr[(unsigned)(i1 || 0xffffffffu) & 7u] = (unsigned)e0;
            *mp = (unsigned)((unsigned)((int)2u < (int)r0.y) == (unsigned)(0x10000u || (0x80000000u % (0x80000000u | 1u))));
        }
    }
    i0 = (0x82237d4cu ? ((unsigned)(x0 >> 70) * u0) : p1) & 15u;
    if (((unsigned)(unsigned char)(g0 - (unsigned)w0) + fuel)) goto L3;
    if (fuel < 8u) return (unsigned)((int)(r0.x % (r0.x | 1u)) < (int)0x95ae8ce9u);
    for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((unsigned)(signed char)((unsigned)h0 >> (a0[u1 & 3u] & 31u))) {
            a0[(m0 % (fuel | 1u)) & 3u] = ((unsigned)(3u || 1u) << ((unsigned)((short)(unsigned)b0 > (signed char)0x80942514u) & 31u));
        }
        break; (void)((unsigned)(w0 >> 29));
    }
    *mp = (unsigned)((unsigned)(x0 >> 70) && ((unsigned)((short)v0 > (signed char)(unsigned)b0) / (i2 | 1u)));
    if ((i2 << (fuel & 31u))) goto L2;
    c0 = (unsigned char)(unsigned)((int)((garr[u2 & 7u] ? (unsigned)s1 : (unsigned)(w0 >> 29)) | 0x7fffffffu) >= (int)(unsigned)c0);
    if (budget != 0u) { budget -= 1u; u2 = fn0((-((unsigned)b0 % (g0 | 1u)) + *q0), (unsigned)((unsigned)h1 < (unsigned)((int)(unsigned)x0 < (int)u3)), (unsigned)((int)p1 >= (int)(u2 + a0[u1 & 3u]))); }
    if ((0x80000000u + (unsigned)(m0 < 0x8a965f6fu))) {
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            if (9u) break;
            if (((unsigned)s1 >> (0x143d1cacu & 31u))) {
                a0[0x683eda2u & 3u] = (unsigned)(0x10000u || ((unsigned)(x0 >> 70) >> (0x7fffffffu & 31u)));
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0xd56a9819u || v0), (unsigned)s0, p1); }
                    d0 = d0 * 0.5 + (double)((8u % ((unsigned)((unsigned)(x0 >> 70) < (fuel ^ i2)) | 1u)) & 1023u);
                    c0 = (unsigned char)2u;
                    break; (void)(1u);
                    break; (void)((unsigned)(5u == (unsigned)(x0 >> 70)));
                }
                if (i1) break;
                e0 = e0 * 0.5L + (long double)(((unsigned)((int)(unsigned)s0 >= (int)((unsigned)(r0.y || p2) + 0xf0ffb1e8u)) | (unsigned)f0) & 1023u);
                if ((unsigned)(signed char)((unsigned)w0 & p2)) continue;
                if (v0) {
                    switch (((unsigned)c1 ? 0x80000000u : 3u) & 7u) {
                        c1 = (signed char)*q0;
                    }
                    r0.x = (unsigned)((int)u3 >= (int)(unsigned)((int)g1 < (int)(6u % (m0 | 1u))));
                    if ((m0 / (i0 | 1u))) break;
                }
            }
        }
        e0 = e0 * 0.5L + (long double)(((unsigned)((short)u0 > (signed char)*mp) ^ (unsigned)((unsigned)s0 == garr[u2 & 7u])) & 1023u);
        if ((unsigned)((int)(0xe6d2eb65u - i1) >= (int)garr[i1 & 7u])) goto L2;
    }
    r0.y ^= ((unsigned)c1 << (a0[i0 & 3u] & 31u));
    do { if (--fuel == 0u) goto done;
        break; (void)((((unsigned)e0 ^ 0x929824f8u) * (unsigned)x0));
        f0 = f0 * 0.5f + (float)((unsigned)((short)(unsigned)f0 > (signed char)p2) & 255u);
        c1 = (signed char)(unsigned)(signed char)(g1 ? (unsigned)s1 : ((unsigned)((int)0x9e4f2496u < (int)m0) << (4u & 31u)));
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            if ((r0.y - ((unsigned)h0 - 6u))) break;
            x0 = x0 * 0x100000001b3ull + (unsigned)((short)(unsigned)((int)r0.y < (int)0xffffffffu) > (signed char)(8u | p2));
            if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((g0 & 0x10000u) || m0), (unsigned)d0, (unsigned)h1); }
            if (r0.y) break;
        }
    } while (i0++ < 4u && (unsigned)d0);
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn2(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    if ((unsigned)(0x7fffffffu && (*q0 + garr[i1 & 7u]))) goto done;
    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)((unsigned)(p2 < (unsigned)s0) == 0x421f04a3u), -(unsigned)(8u < 5u), ((unsigned)h1 - *mp)); }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        r0.y ^= (unsigned)(0x6665210u == *q0);
        { unsigned t0; double z0; if ((~(0x10a3a0c3u | g1)) & 1u) { t0 = (unsigned)(0x35883780u && ~(unsigned)((int)*mp < (int)0xffffffffu)); z0 = (double)(((g0 & 0x10000u)) & 255u); } if ((~(0x10a3a0c3u | g1)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            u1 = (unsigned)((int)garr[i1 & 7u] >= (int)*mp);
            *mp = (unsigned)((short)5u > (signed char)(unsigned)((unsigned)w0 < 0x10000u));
            if ((unsigned)((short)(garr[i1 & 7u] - *q0) > (signed char)fuel)) break;
            e0 = e0 * 0.5L + (long double)((unsigned)(p1 || (0x37a7a837u % ((unsigned)d0 | 1u))) & 1023u);
            if ((unsigned)((unsigned)(i0 && 0x7fffffffu) == 0xa717fe15u)) goto done;
            b0 = 0u != 0u;
        }
        if ((unsigned)((unsigned)b0 && p1)) {
            a0[7u & 3u] = (unsigned)(short)((unsigned)e0 * ((unsigned)((short)0x6e3793deu > (signed char)5u) * g0));
            while ((unsigned)e0) { if (--fuel == 0u) goto done;
                break; (void)(8u);
                w0 ^= (unsigned long long)(unsigned)l0 << ((unsigned)(signed char)(unsigned)((unsigned)b0 == m0) & 63u);
                if (budget != 0u) { budget -= 1u; u0 = fn1(6u, ((unsigned)h0 / (r0.y | 1u)), 0x80000000u); }
                if (((unsigned)c1 | i2)) continue;
                h0 = (short)(unsigned)((unsigned)c1 < ~(unsigned)((int)p2 >= (int)((unsigned)(0x54694dfeu < i0) % (*mp | 1u))));
            }
            g1 += ~(unsigned)((short)(unsigned)d0 > (signed char)(((0x80000000u % ((unsigned)d0 | 1u)) / (i1 | 1u)) & garr[i1 & 7u]));
            goto L2;
            while (i1++ < 6u && 0x1c73adf5u) { if (--fuel == 0u) goto done;
                goto L2;
                if (0x80000000u) goto done;
                u3 ^= ((unsigned)((int)*q0 >= (int)(unsigned)b0) & (unsigned)w0);
                u2 ^= (unsigned)((unsigned)w0 && (u1 / (((unsigned)h1 - 0x80000000u) | 1u)));
                if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(short)(9u ? (unsigned)b0 : 0xba22427eu), 7u, (4u + (unsigned)(x0 >> 70))); }
            }
        } else {
            if ((7u << (u3 & 31u))) break;
            garr[(unsigned)((unsigned)d0 < 0xffffffffu) & 7u] = ((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)(*q0 && (unsigned)l0)) & (unsigned)((short)0x80000000u > (signed char)(unsigned)f0));
        }
    }
    { unsigned t1; double z1; if (((unsigned)((short)6u > (signed char)r0.y)) & 1u) { t1 = (unsigned)(((unsigned)h0 >> ((unsigned)c1 & 31u)) < v0); z1 = (double)(((unsigned)((unsigned)h0 && (unsigned)(x0 >> 70))) & 255u); } if (((unsigned)((short)6u > (signed char)r0.y)) & 1u) { u3 += t1; d0 = d0 * 0.5 + z1; }
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            v0 = ((a0[u1 & 3u] << (g1 & 31u)) / (u2 | 1u));
            l0 = (long)((unsigned long)l0 + (unsigned)(p1 < (u3 & (unsigned)(signed char)((unsigned)f0 | fuel))));
            if ((u3 + 0xb4153bf3u)) {
                continue; (void)(((unsigned)h1 & (p0 / ((unsigned)w0 | 1u))));
                u0 = u0 * 0x9e3779b1u + ((unsigned)(*q0 == i0) ^ (unsigned)(unsigned char)(r0.x + m0));
                break; (void)((unsigned)!(0xb5ed15d6u * ((unsigned)e0 / (0x1764884au | 1u))));
                d0 = d0 * 0.5 + (double)((unsigned)w0 & 1023u);
                do { if (--fuel == 0u) goto done;
                    L0: if (--fuel == 0u) goto done;
                    L1: if (--fuel == 0u) goto done;
                } while (i1++ < 2u && (0x10000u ^ ((unsigned)d0 | r0.x)));
            } else {
                do { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)(i1 < (unsigned)(5u < i1)), 0x80000000u, (unsigned)x0); }
                    if (p0) continue;
                    g0 = (unsigned)((short)((unsigned)b0 ? (unsigned)h0 : (unsigned)h0) > (signed char)u3);
                    L2: if (--fuel == 0u) goto done;
                    a0[(unsigned)((int)r0.x >= (int)0x7fffffffu) & 3u] = (unsigned)(signed char)((unsigned)((unsigned)h0 && a0[u1 & 3u]) << (m0 & 31u));
                } while (i1++ < 3u && 4u);
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0(((unsigned)((short)r0.y > (signed char)0x10000u) * *q0), (0x28bbb9b4u % (0xb026989fu | 1u)), 4u); }
            a0[0x7fffffffu & 3u] = (unsigned)((short)0x836e40aeu > (signed char)(unsigned)(0x10000u || (p2 << (p2 & 31u))));
            for (i1 = 1u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)garr[u2 & 7u] << ((unsigned)(garr[i1 & 7u] && 0x9f072a0fu) & 63u);
            }
        }
        c1 = (signed char)u0;
    }
    g1 += (unsigned)(unsigned char)(unsigned)((short)3u > (signed char)((unsigned)(p2 && i1) ? 0xceee8a70u : u3));
    do { if (--fuel == 0u) goto done;
        if (u3 == 7u) return (1u - ((unsigned)c1 >> ((unsigned)!(unsigned)((int)0x996039b0u < (int)p0) & 31u)));
        u2 ^= (u3 & ((unsigned)((short)(unsigned)s1 > (signed char)0x10000u) % (*q0 | 1u)));
    } while (i0++ < 2u && (unsigned)((int)(unsigned)h0 < (int)(r0.x | g0)));
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            r0.x = 7u;
        }
        L3: if (--fuel == 0u) goto done;
        b0 = (a0[u1 & 3u] - v0) != 0u;
        c1 = (signed char)((unsigned)((int)(p0 * fuel) < (int)garr[u2 & 7u]) << (-(p1 - (unsigned)e0) & 31u));
    }
    h1 = (unsigned short)(h1 + 9u);
    L4: if (--fuel == 0u) goto done;
    if (r0.x) goto L0;
    if ((a0[i0 & 3u] - (unsigned)s0)) goto done;
    if (0xdef57cc9u) {
        if ((r0.y / (0xd2519f24u | 1u))) goto L3;
        if (((unsigned)(short)((unsigned)l0 + (unsigned)e0) ^ a0[i0 & 3u])) goto L3;
        if ((unsigned)!(2u >> ((unsigned)(short)(unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)b0) & 31u))) {
            r0.x = ((garr[u2 & 7u] | ((unsigned)c1 | p2)) + (unsigned)(0x7fffffffu && (unsigned)l0));
            w0 = w0 * 6364136223846793005ull + ((unsigned)x0 % ((unsigned)e0 | 1u));
            d0 = d0 * 0.5 + (double)((unsigned)(i0 || (0x10000u ^ ~(unsigned)((unsigned)h1 || (unsigned)w0))) & 1023u);
            for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                c1 = (signed char)((0x10000u << (0x80000000u & 31u)) & *q0);
                if ((unsigned)f0) continue;
                if (((*q0 & 4u) % (0x7fffffffu | 1u))) {
                    h1 = (unsigned short)(h1 + ((unsigned)h0 >> ((u3 ? (unsigned)s1 : (unsigned)d0) & 31u)));
                }
            }
        }
    }
    do { if (--fuel == 0u) goto done;
        d0 = d0 * 0.5 + (double)((unsigned)l0 & 1023u);
        while (i1++ < 7u && (7u + p1)) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(p1 && 0x9f0fc65eu), (r0.y | ~(garr[u2 & 7u] - 7u)), ((u2 | m0) >> ((unsigned)l0 & 31u))); }
            h0 = (short)(u2 << (fuel & 31u));
        }
        do { if (--fuel == 0u) goto done;
            b0 = (unsigned)((unsigned)(a0[i0 & 3u] < p1) && (unsigned)!(unsigned)(0x7fffffffu && (unsigned)(w0 >> 29))) != 0u;
        } while (i1++ < 5u && (0x47e106f1u & (0x80000000u / (*q0 | 1u))));
        break; (void)((*mp | (unsigned)(2u < (unsigned)w0)));
    } while (i0++ < 6u && (unsigned)(((unsigned)s0 ^ (unsigned)w0) || (unsigned)e0));
    for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        h1 = (unsigned short)(h1 + (unsigned)((int)garr[i1 & 7u] < (int)(unsigned)f0));
        switch (((1u % (p0 | 1u)) / (*q0 | 1u)) & 7u) {
            if ((r0.y % (((unsigned)(x0 >> 70) - (unsigned)(w0 >> 29)) | 1u))) continue;
        }
        c0 = (unsigned char)(unsigned)((int)0xc24d9a9bu < (int)(unsigned)(w0 >> 29));
        m0 ^= (0xc12a15e4u + i2);
    }
    b0 = (unsigned)x0 != 0u;
    for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        do { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn0((garr[u2 & 7u] >> (r0.x & 31u)), (unsigned)d0, (v0 % ((unsigned)c1 | 1u))); }
            for (i2 = 0u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (fuel < 8u) return ((unsigned)d0 | 5u);
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((short)(unsigned)d0 > (signed char)(unsigned)((int)0u >= (int)0x10000u)), (unsigned)(p2 && (unsigned)h0), (unsigned)c1); }
                if (0x716cd849u) continue;
            }
            s0 = (int)(unsigned)((short)(unsigned)x0 > (signed char)(unsigned)((int)(3u ^ 0xffffffffu) >= (int)(unsigned)(x0 >> 70)));
            c0 = (unsigned char)(unsigned)(0x80000000u && r0.y);
            *q0 = (unsigned)((int)(0u - i0) < (int)(unsigned)b0);
            q0 = &garr[g1 & 7u];
        } while (i1++ < 3u && 6u);
        { unsigned t2; double z2; if ((((unsigned)c0 << ((unsigned)(signed char)(0xa9b90403u & a0[u1 & 3u]) & 31u))) & 1u) { t2 = 0x4a2e31d3u; z2 = (double)(((unsigned)((int)(unsigned)f0 < (int)0xbd297a2au)) & 255u); } if ((((unsigned)c0 << ((unsigned)(signed char)(0xa9b90403u & a0[u1 & 3u]) & 31u))) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
            b0 = (unsigned)(signed char)(unsigned)(r0.y == (unsigned)(0xffffffffu == (unsigned)b0)) != 0u;
            a0[4u & 3u] = (unsigned)((int)m0 >= (int)(unsigned)(x0 >> 70));
        }
    }
    c1 = (signed char)((g0 ^ p2) / ((unsigned)d0 | 1u));
    for (;;) { if (--fuel == 0u) goto done;
        *mp = ((unsigned)!((unsigned)x0 << (((unsigned)s0 - 0x80000000u) & 31u)) + (unsigned)w0);
    }
    g1 += ((*q0 * i1) << ((unsigned)w0 & 31u));
    goto L4;
    i1 = 0x10000u & 15u;
    if (i2) goto L3;
    s0 = (int)(unsigned)((unsigned)((short)0x7fffffffu > (signed char)garr[u2 & 7u]) || (unsigned)(0x599bb539u && (unsigned)(w0 >> 29)));
    goto done;
    { unsigned t3; double z3; if (((0x7fffffffu * (unsigned)d0)) & 1u) { t3 = (0x8482a48fu ? (unsigned)b0 : (unsigned)s0); z3 = (double)((((unsigned)s0 >> (r0.x & 31u))) & 255u); } if (((0x7fffffffu * (unsigned)d0)) & 1u) { u1 += t3; d0 = d0 * 0.5 + z3; }
        s0 = (int)(((unsigned)c0 + i2) | *q0);
        if ((unsigned)(fuel == (9u | 8u))) goto L4;
        goto L4;
        q0 = &garr[((u1 >> (0x5a4e2141u & 31u)) >> (r0.y & 31u)) & 7u];
        a0[i1 & 3u] = -(3u << ((unsigned)((unsigned)(short)(0x24580a43u & 0xc7025420u) == (unsigned)((int)4u >= (int)0xec19025eu)) & 31u));
    }
    while (i0++ < 7u && ((i1 / (0x10000u | 1u)) << (7u & 31u))) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((unsigned)(signed char)(unsigned)(garr[i1 & 7u] == (unsigned)s1) == 0x80000000u), -(0x8608df90u | 0x7df1b4u), (*q0 * g1)); }
        for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (((unsigned)((unsigned)h1 && *mp) + i1)) break;
            { unsigned t4; double z4; if (((unsigned)(0x10000u < (unsigned)(unsigned char)(5u / (9u | 1u)))) & 1u) { t4 = ~((unsigned)l0 | 0x6fd750c5u); z4 = (double)(((unsigned)((0x10000u >> (garr[u2 & 7u] & 31u)) == 0x80000000u)) & 255u); } if (((unsigned)(0x10000u < (unsigned)(unsigned char)(5u / (9u | 1u)))) & 1u) { u3 += t4; d0 = d0 * 0.5 + z4; }
                if ((unsigned)((int)i1 < (int)a0[u1 & 3u])) break;
                { unsigned t5; double z5; if ((((unsigned)d0 & u3)) & 1u) { t5 = a0[u1 & 3u]; z5 = (double)(((0x4f465f8eu & ((unsigned)e0 & (unsigned)s0))) & 255u); } if ((((unsigned)d0 & u3)) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((unsigned)d0 && g0), (u1 >> (0xffffffffu & 31u)), r0.y); }
                }
                if (((unsigned)h1 ? *q0 : g0)) break;
                if (((unsigned)c1 + p2)) {
                    break; (void)(((0x80000000u & 0u) * 0x7ed91ed6u));
                    if (0x229b752eu) break;
                }
            }
            if (0xedabd60du) break;
            garr[(unsigned)(0u < (unsigned)h0) & 7u] = a0[i0 & 3u];
        }
        w0 ^= (unsigned long long)1u << ((((unsigned)d0 & (0xf291ba14u % (((unsigned)h0 + u2) | 1u))) / ((unsigned)l0 | 1u)) & 63u);
        if ((((unsigned)h1 + p0) * i2)) {
            if ((unsigned)((*mp % ((unsigned)e0 | 1u)) && 0xffffffffu)) continue;
            continue; (void)((unsigned)!(~(unsigned)((unsigned)h1 && i0) >> (r0.y & 31u)));
            for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                if ((g1 - g0)) {
                    if ((unsigned)(signed char)((unsigned)c1 & garr[i1 & 7u])) continue;
                } else {
                    x0 = x0 * 0x100000001b3ull + (unsigned)(0x7fffffffu && (unsigned)x0);
                    if (0xc68a64a6u) continue;
                    if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)(i2 < (u1 & garr[u2 & 7u])), ((unsigned)((int)(unsigned)x0 < (int)(unsigned)l0) - (unsigned)s1), (unsigned)(i0 || (unsigned)b0)); }
                    if (0x80000000u) {
                        if (budget != 0u) { budget -= 1u; u3 = fn0((0x94311d72u * p2), i1, ((unsigned)(g1 < 5u) & u1)); }
                    } else {
                        l0 = (long)((unsigned long)l0 + (unsigned)(0x502a6434u < (unsigned)(0xbdafccecu || (unsigned)h1)));
                    }
                }
                if ((unsigned)(6u == m0)) continue;
                if (budget != 0u) { budget -= 1u; u3 = fn1((p0 | u3), (unsigned)((int)r0.y >= (int)a0[i0 & 3u]), (0x10000u | (garr[i1 & 7u] - (unsigned)e0))); }
                h1 = (unsigned short)(h1 + ((u3 >> (i2 & 31u)) | ~(unsigned)(-(0x10dce30bu - (unsigned)h1) || p0)));
                if (6u) break;
            }
        } else {
            do { if (--fuel == 0u) goto done;
                if (((unsigned)s1 | (unsigned)((int)(unsigned)w0 >= (int)0x10000u))) break;
                if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)(signed char)(8u ^ (unsigned)d0), (unsigned)((int)i1 < (int)garr[u2 & 7u]), ((unsigned)w0 % ((i0 | (unsigned)x0) | 1u))); }
                continue; (void)(((unsigned)h1 & (unsigned)(unsigned char)(i0 / (0x62fb922cu | 1u))));
                break; (void)((unsigned)(unsigned char)(unsigned)(g1 == (unsigned)c1));
            } while (i1++ < 4u && (unsigned)((int)a0[i0 & 3u] >= (int)0xffffffffu));
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                while (i2++ < 7u && (fuel + (unsigned)s1)) { if (--fuel == 0u) goto done;
                    x0 = x0 * 0x100000001b3ull + ((unsigned)((short)g0 > (signed char)fuel) ^ u1);
                    g0 = ((unsigned)c1 % ((((unsigned)w0 ^ *q0) * (unsigned)(0xffffffffu || garr[u2 & 7u])) | 1u));
                    i1 = (unsigned)((short)7u > (signed char)(a0[u1 & 3u] >> (0x80e24e7bu & 31u))) & 15u;
                    garr[(*mp << (0xbbe27865u & 31u)) & 7u] = (unsigned)s1;
                }
            }
            *mp = ((unsigned)d0 ^ (unsigned)((int)(unsigned)(w0 >> 29) < (int)(((unsigned)s1 | (unsigned)h1) >> ((unsigned)(w0 >> 29) & 31u))));
        }
        w0 ^= (unsigned long long)(p0 * (unsigned)s0) << (((g1 + (unsigned)(w0 >> 29)) * (unsigned)((0x10000u % (0xffffffffu | 1u)) || 0xa3fd26c5u)) & 63u);
        x0 = x0 * 0x100000001b3ull + (unsigned)(1u && p2);
    }
    goto L1;
    b0 = (unsigned)(p1 < (unsigned)f0) != 0u;
    m0 ^= (unsigned)(0x414a6022u < ((unsigned)(w0 >> 29) * 0x959cfedcu));
    goto done;
    switch ((garr[i1 & 7u] * garr[u2 & 7u]) & 7u) {
        h1 = (unsigned short)(h1 + (fuel ? 0xbc1585d3u : 9u));
        w0 ^= (unsigned long long)u1 << (((unsigned)s1 / ((unsigned)(0x80000000u && (unsigned)((int)(unsigned)l0 >= (int)(i0 * (unsigned)e0))) | 1u)) & 63u);
        for (i0 = 1u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= ((unsigned)((int)p0 >= (int)(unsigned)w0) ^ ((0u / (0xffffffffu | 1u)) << (fuel & 31u)));
            case 5u: ;
            for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 0u; i2 < 4u; i2 += 1u) { if (--fuel == 0u) goto done;
                    l0 = (long)((unsigned long)l0 + (unsigned)(7u && i2));
                }
                e0 = e0 * 0.5L + (long double)(0x10000u & 1023u);
            }
            for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                case 2u: ;
                default: ;
                case 6u: ;
            }
            *q0 = 0xed6c6c58u;
        }
    }
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn3(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    for (i0 = 1u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (budget != 0u) { budget -= 1u; u0 = fn2(r0.x, (unsigned)((int)(unsigned)(w0 >> 29) >= (int)0x7fffffffu), (unsigned)l0); }
        for (;;) { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)(((unsigned)c1 >> ((unsigned)h0 & 31u)) << (i0 & 31u))) break;
            q0 = &garr[(unsigned)(u3 == 6u) & 7u];
            s1 = (int)((unsigned)s1 + (u2 - -(garr[u2 & 7u] % ((unsigned)(w0 >> 29) | 1u))));
            { unsigned t0; double z0; if (((unsigned)(g1 || ((unsigned)h0 + (unsigned)h0))) & 1u) { t0 = ((unsigned)(x0 >> 70) % (0xacfc2734u | 1u)); z0 = (double)(((unsigned)((int)0xbbb40f02u >= (int)(unsigned)l0)) & 255u); } if (((unsigned)(g1 || ((unsigned)h0 + (unsigned)h0))) & 1u) { u0 += t0; d0 = d0 * 0.5 + z0; }
                { unsigned t1; double z1; if (((unsigned)((int)0xffffffffu >= (int)(a0[u1 & 3u] - *q0))) & 1u) { t1 = (unsigned)c1; z1 = (double)((m0) & 255u); } if (((unsigned)((int)0xffffffffu >= (int)(a0[u1 & 3u] - *q0))) & 1u) { u0 += t1; d0 = d0 * 0.5 + z1; }
                    c0 = (unsigned char)(0x7315982u ^ ((unsigned)l0 / ((unsigned)w0 | 1u)));
                    i0 = ((fuel + (a0[u1 & 3u] - *q0)) >> (u2 & 31u)) & 15u;
                }
                g1 += (unsigned)((unsigned)h1 || (unsigned)((unsigned)e0 || 0xffffffffu));
                m0 ^= (unsigned)((unsigned)e0 < ((unsigned)w0 * u3));
                L0: if (--fuel == 0u) goto done;
                q0 = &garr[(unsigned)w0 & 7u];
                break; (void)((0xa6cd29edu << (u3 & 31u)));
            }
            if (budget != 0u) { budget -= 1u; u2 = fn0(fuel, ~(unsigned)((unsigned)h0 && (unsigned)(u0 && 0xf05c0f4eu)), 0xc9f46378u); }
        }
        for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)(~((unsigned)((short)(unsigned)(x0 >> 70) > (signed char)p0) >> ((unsigned)!(unsigned)((int)0x7fffffffu < (int)(p2 - 2u)) & 31u)) & 1023u);
        }
        if ((unsigned)d0) break;
        m0 ^= 0xc115c12fu;
    }
    for (;;) { if (--fuel == 0u) goto done;
        i2 = (unsigned)((int)(g1 >> (v0 & 31u)) >= (int)((unsigned)b0 | (unsigned)s0)) & 15u;
        if ((unsigned)((r0.x | a0[i0 & 3u]) && a0[i0 & 3u])) break;
        if ((unsigned)((short)0x780097cbu > (signed char)(p1 & m0))) continue;
        goto L4;
        if (((unsigned)(w0 >> 29) | 0xfcfc2a94u)) break;
    }
    if ((((unsigned)s1 & 0x94b3e2a0u) + *q0)) {
        if (budget != 0u) { budget -= 1u; u2 = fn0(i2, u0, ((unsigned)((unsigned)h1 && *q0) - (unsigned)s1)); }
        goto done;
        goto L4;
        q0 = &garr[(0x10000u % (0x71ee2328u | 1u)) & 7u];
    } else {
        for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            c0 = (unsigned char)((unsigned)(r0.x && 0x10000u) ^ p0);
            if ((4u % (((unsigned)c0 / ((unsigned)h1 | 1u)) | 1u))) {
                e0 = e0 * 0.5L + (long double)((unsigned)((short)i2 > (signed char)0xfda81c0bu) & 1023u);
                while (i1++ < 5u && (4u & u2)) { if (--fuel == 0u) goto done;
                    u3 ^= u1;
                    b0 = ((unsigned)((int)0x7fffffffu >= (int)7u) >> ((0x916fe461u & (unsigned)((short)0x7fffffffu > (signed char)r0.y)) & 31u)) != 0u;
                }
                do { if (--fuel == 0u) goto done;
                    r0.x = (-(a0[u1 & 3u] << ((unsigned)c0 & 31u)) + (unsigned)(i0 || (unsigned)(w0 >> 29)));
                    m0 ^= (unsigned)!(unsigned)((unsigned)((unsigned)((int)p0 >= (int)(unsigned)f0) || 0x7fffffffu) && (unsigned)(u3 || 9u));
                } while (i1++ < 7u && ((7u & r0.y) << (0x7fffffffu & 31u)));
                if (budget != 0u) { budget -= 1u; u3 = fn1((unsigned)f0, (unsigned)(x0 >> 70), (i2 << ((unsigned)(unsigned char)(*q0 ^ 3u) & 31u))); }
            } else {
                if ((unsigned)(signed char)((a0[i0 & 3u] & a0[u1 & 3u]) * (unsigned)s0)) goto done;
                r0.y ^= (unsigned)(((unsigned)h1 >> (u3 & 31u)) < (u0 - i0));
                if (budget != 0u) { budget -= 1u; u1 = fn2((unsigned)((unsigned)w0 || u2), 0x10000u, (unsigned)(p2 || 0x7fffffffu)); }
                *q0 += 0x4371f1d0u;
            }
            *q0 = ~(6u ^ 0x7fffffffu);
        }
        s1 = (int)((unsigned)s1 + (unsigned)(a0[i0 & 3u] == ((unsigned)d0 / (0x80000000u | 1u))));
        w0 = w0 * 6364136223846793005ull + 0x7fffffffu;
    }
    if (1u) goto L0;
    v0 = (unsigned)((int)(unsigned)(g0 || (unsigned)((int)u3 >= (int)(unsigned)c0)) >= (int)(unsigned)((short)(unsigned)b0 > (signed char)(unsigned)h1));
    u1 = *q0;
    goto L0;
    if (budget != 0u) { budget -= 1u; u1 = fn0(0x473e0f53u, u3, ((unsigned)c1 * (unsigned)(0xad48780u < (unsigned)c1))); }
    switch (*mp & 7u) {
        *q0 = (unsigned)c1;
        if (u1) {
            if (0x7fffffffu) goto L1;
            v0 = (unsigned)b0;
            if ((u2 & 5u)) {
                for (;;) { if (--fuel == 0u) goto done;
                    *q0 += (unsigned)(0x89443354u && ((0x36558216u & u1) ^ ~((unsigned)l0 << (0xffffffffu & 31u))));
                    if ((unsigned)(p1 || (unsigned)(unsigned char)(unsigned)((short)p0 > (signed char)p2))) goto L2;
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)f0, 0x7fffffffu, (unsigned)(short)(((unsigned)c1 + u0) ^ 0x80000000u)); }
                }
                s1 = (int)((unsigned)s1 + ((u0 >> (*mp & 31u)) % ((unsigned)f0 | 1u)));
                switch (((unsigned)e0 | (unsigned)(w0 >> 29)) & 7u) {
                    L1: if (--fuel == 0u) goto done;
                    c1 = (signed char)(*mp >> ((r0.y - 0xe4ff76f4u) & 31u));
                    u1 += (unsigned)((int)(u3 ^ 7u) < (int)((unsigned)(signed char)(unsigned)((unsigned)l0 == 4u) - 0xc82a138bu));
                    *mp = (0x10000u >> (r0.x & 31u));
                    if (budget != 0u) { budget -= 1u; u3 = fn1((3u >> (0x27c28628u & 31u)), (unsigned)(0x8b2c1f39u < i2), (u3 << (0x80000000u & 31u))); }
                    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
                        r0.x = (((unsigned)x0 ^ r0.x) << (m0 & 31u));
                        L2: if (--fuel == 0u) goto done;
                        case 2u: ;
                        if (budget != 0u) { budget -= 1u; u0 = fn1(((unsigned)((unsigned)h0 < 0u) % (i1 | 1u)), 0xc03532bfu, r0.x); }
                    }
                }
                u1 = u1 * 0x9e3779b1u + (g1 ^ (unsigned)((int)5u >= (int)(unsigned)s0));
                if (budget != 0u) { budget -= 1u; u2 = fn0(*q0, -(p2 ^ i0), -(((unsigned)d0 * r0.x) >> (0xa4d6471du & 31u))); }
                { unsigned t2; double z2; if ((garr[u2 & 7u]) & 1u) { t2 = 7u; z2 = (double)(((unsigned)(2u && 0x1f6e3445u)) & 255u); } if ((garr[u2 & 7u]) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
                    q0 = &garr[((unsigned)d0 * 0x8fcabeb0u) & 7u];
                    l0 = (long)((unsigned long)l0 + (unsigned)((r0.y + (unsigned)f0) < 0x10000u));
                }
            }
            garr[u0 & 7u] = (unsigned)((i0 >> (0x10000u & 31u)) == (unsigned)h1);
            c1 = (signed char)((unsigned)!((unsigned)l0 - ((unsigned)h1 ? (unsigned)c1 : (unsigned)c1)) ^ p2);
            L3: if (--fuel == 0u) goto done;
        } else {
            d0 = d0 * 0.5 + (double)((9u / (g0 | 1u)) & 1023u);
            case 3u: ;
            L4: if (--fuel == 0u) goto done;
        }
        c1 = (signed char)((unsigned)w0 - u3);
        for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            switch ((unsigned)((unsigned)(unsigned char)(a0[u1 & 3u] + (unsigned)b0) && u1) & 7u) {
                a0[v0 & 3u] = ((unsigned)(unsigned char)(unsigned)((unsigned)((int)0xffffffffu < (int)0x7fffffffu) && i2) | fuel);
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(x0 >> 70), (unsigned)((short)(unsigned)w0 > (signed char)(unsigned)((int)u0 >= (int)garr[u2 & 7u])), (unsigned)((u0 << (0u & 31u)) < 7u)); }
                case 0u: ;
            }
        }
    }
    garr[g1 & 7u] = ~(((unsigned)f0 % (p2 | 1u)) - (u3 ? u2 : garr[u2 & 7u]));
    g1 += (unsigned)((short)g1 > (signed char)(*q0 / ((unsigned)(garr[i1 & 7u] == (u1 ^ *mp)) | 1u)));
    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)7u < (int)8u), (unsigned)(*mp && (unsigned)c0), ((a0[u1 & 3u] + (unsigned)l0) / (fuel | 1u))); }
    do { if (--fuel == 0u) goto done;
        for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)((int)g1 < (int)(0x80000000u % ((unsigned)h1 | 1u))), (unsigned)((int)(p2 * a0[u1 & 3u]) >= (int)*mp), i1); }
            if ((0x3fcf4edcu / (i0 | 1u))) {
                u1 = r0.x;
                if (u3 == 7u) return i1;
            } else {
                { unsigned t3; double z3; if (((i1 + (p0 | 5u))) & 1u) { t3 = ((unsigned)((int)p0 < (int)3u) & 0x10000u); z3 = (double)((((unsigned)x0 >> ((unsigned)((short)p0 > (signed char)6u) & 31u))) & 255u); } if (((i1 + (p0 | 5u))) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                    if (m0) break;
                    while (i2++ < 2u && ((m0 % (0xce751731u | 1u)) + (unsigned)h1)) { if (--fuel == 0u) goto done;
                        s1 = (int)((unsigned)s1 + (8u | 0x7fffffffu));
                        g1 += (unsigned)(short)(unsigned)(~(unsigned)((unsigned)d0 || u1) == (unsigned)!(*q0 % (*q0 | 1u)));
                        if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)((int)(unsigned)h1 < (int)p0), garr[i1 & 7u], (unsigned)(short)(unsigned)(0xffffffffu < (unsigned)(0x7fffffffu || i1))); }
                        g0 = (unsigned)(short)(unsigned)(7u == 0x4a591430u);
                        if (budget != 0u) { budget -= 1u; u3 = fn2(((u2 - p1) >> (a0[i0 & 3u] & 31u)), 7u, (unsigned)(short)(unsigned)((int)0x7fffffffu >= (int)5u)); }
                        r0.y ^= (unsigned)((unsigned)((unsigned)(r0.x && i1) && 0x163c0ce4u) || (unsigned)!(unsigned)(0x87434a16u && (unsigned)b0));
                    }
                }
            }
        }
        c1 = (signed char)(i1 % ((m0 % ((unsigned)((short)0x1be05205u > (signed char)p0) | 1u)) | 1u));
        if (budget != 0u) { budget -= 1u; u1 = fn2(0x7fffffffu, (4u % (*q0 | 1u)), (unsigned)(0x50d2c972u || (0xad1bf069u - r0.x))); }
        if ((0x4e0beb87u * (unsigned)((int)g0 < (int)u2))) {
            { unsigned t4; double z4; if ((r0.y) & 1u) { t4 = (unsigned)l0; z4 = (double)((~(*q0 / ((unsigned)((int)0x7fffffffu >= (int)i0) | 1u))) & 255u); } if ((r0.y) & 1u) { u1 += t4; d0 = d0 * 0.5 + z4; }
                if (((0x1af6d073u & *q0) * (unsigned)(w0 >> 29))) break;
                switch (((0x494a75f1u & g0) - (unsigned)c1) & 7u) {
                    case 7u: ;
                    if ((i0 << (~(3u ^ garr[i1 & 7u]) & 31u))) {
                        h1 = (unsigned short)(h1 + (unsigned)((int)g0 < (int)(unsigned)c0));
                        case 1u: ;
                        if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(p1 < (unsigned)(short)(unsigned)(a0[i0 & 3u] == a0[u1 & 3u])), (unsigned)c0, ((unsigned)b0 >> (0xb4ee9bdbu & 31u))); }
                    }
                    if ((unsigned)e0) goto L2;
                    break; (void)((unsigned)(4u < p2));
                }
                g0 = (u1 << ((unsigned)b0 & 31u));
                w0 ^= (unsigned long long)8u << (p2 & 63u);
                for (i1 = 1u; i1 < 4u; i1 += 1u) { if (--fuel == 0u) goto done;
                    d0 = d0 * 0.5 + (double)((fuel << (((unsigned)(3u < 0x40200593u) ^ (unsigned)x0) & 31u)) & 1023u);
                    *q0 = ((unsigned)((int)(((unsigned)(x0 >> 70) % (*q0 | 1u)) - (unsigned)f0) < (int)0xc8aa639u) + 0x53f80fdcu);
                    if ((p0 % ((unsigned)x0 | 1u))) goto L4;
                    c1 = (signed char)(unsigned)((short)g0 > (signed char)i2);
                    a0[g1 & 3u] = ((*q0 + u1) / (0x80000000u | 1u));
                }
                if ((g0 % (9u | 1u))) {
                    break; (void)(-(2u + (a0[u1 & 3u] + 6u)));
                    if (1u) {
                        s0 = (int)(unsigned)((int)(unsigned)((unsigned)(w0 >> 29) && g1) >= (int)(unsigned)(garr[i1 & 7u] || 0x10000u));
                        if (u3) break;
                        if (u3 == 7u) return 0x80000000u;
                        u1 ^= -(4u * g1);
                        if (((p1 << (0x7fffffffu & 31u)) & (unsigned)e0)) goto L2;
                    } else {
                        b0 = 8u != 0u;
                        *mp = i1;
                        f0 = f0 * 0.5f + (float)((unsigned)((int)(unsigned)f0 >= (int)(unsigned)((unsigned)h1 || m0)) & 255u);
                    }
                    h1 = (unsigned short)(h1 + (unsigned)(((unsigned)f0 - (unsigned)w0) || (unsigned)(p0 && r0.y)));
                }
            }
            a0[p2 & 3u] = ((unsigned)(signed char)(unsigned)((short)(unsigned)s0 > (signed char)(unsigned)s1) * g0);
            goto L4;
        } else {
            u3 = (g0 / (u2 | 1u));
        }
    } while (i0++ < 3u && (unsigned)(unsigned char)(unsigned)((a0[u1 & 3u] & 0x7fffffffu) < 8u));
    goto L3;
    a0[(unsigned)(signed char)(0x2d9954feu / (p1 | 1u)) & 3u] = (unsigned)((unsigned)((int)3u < (int)(unsigned)f0) < 0xffffffffu);
    w0 ^= (unsigned long long)0x7fffffffu << (p1 & 63u);
    if (g1) {
        w0 = w0 * 6364136223846793005ull + (-(g0 << (u3 & 31u)) % ((unsigned)(w0 >> 29) | 1u));
        for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
            while (garr[i1 & 7u]) { if (--fuel == 0u) goto done;
                h1 = (unsigned short)(h1 + (0x5c047129u & 0x10000u));
                if (((unsigned)w0 ^ 0xffffffffu)) break;
                g0 = (unsigned)x0;
            }
            s1 = (int)((unsigned)s1 + ((unsigned)s1 & (unsigned)l0));
            do { if (--fuel == 0u) goto done;
                g0 = ((unsigned)(w0 >> 29) ^ (unsigned)(w0 >> 29));
                for (;;) { if (--fuel == 0u) goto done;
                    if (0x5be4b3deu) break;
                    if ((unsigned)((int)r0.x < (int)u1)) break;
                    d0 = d0 * 0.5 + (double)(((7u * (unsigned)!(0u ? (unsigned)b0 : u0)) << ((unsigned)f0 & 31u)) & 1023u);
                }
            } while (i1++ < 4u && (unsigned)b0);
            if ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)4u)) {
                if ((u1 % (a0[u1 & 3u] | 1u))) break;
                if (budget != 0u) { budget -= 1u; u3 = fn1(garr[u2 & 7u], 6u, ~((unsigned)e0 % ((unsigned)((unsigned)w0 == *mp) | 1u))); }
                u2 = u2 * 0x9e3779b1u + (unsigned)((int)a0[i0 & 3u] >= (int)0xd71e8c89u);
                if ((*mp | (unsigned)c1)) continue;
            } else {
                v0 = (((unsigned)b0 % ((unsigned)(m0 < (unsigned)h0) | 1u)) % (-(unsigned)(u0 == 0x10000u) | 1u));
                while (i1++ < 2u && (u3 ^ (unsigned)(w0 >> 29))) { if (--fuel == 0u) goto done;
                    garr[(p0 | *mp) & 7u] = (unsigned)((int)(unsigned)(w0 >> 29) >= (int)p1);
                    if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((unsigned)c0 == 9u), -((unsigned)c1 << ((unsigned)(6u < i0) & 31u)), ((unsigned)h1 / (0x10000u | 1u))); }
                    s1 = (int)((unsigned)s1 + a0[i0 & 3u]);
                    c1 = (signed char)((unsigned)f0 - (unsigned)((int)a0[i0 & 3u] >= (int)i2));
                    if ((g1 | 0x7fffffffu)) break;
                    for (i2 = 1u; i2 < 2u; i2 += 1u) { if (--fuel == 0u) goto done;
                        s0 = (int)(fuel & (unsigned)e0);
                        if (((unsigned)s0 | 0x76192a78u)) break;
                        if (-(0x10000u + (unsigned)(0x80000000u && (unsigned)f0))) break;
                    }
                }
                u1 = u1 * 0x9e3779b1u + (((5u << ((unsigned)s0 & 31u)) ? (unsigned)w0 : a0[i0 & 3u]) / (garr[i1 & 7u] | 1u));
                if ((unsigned)b0) continue;
            }
        }
        r0.y ^= (unsigned)((short)r0.x > (signed char)(unsigned)((int)fuel >= (int)(unsigned)((int)0xa0e52817u < (int)0x7fffffffu)));
        if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((unsigned)s0 < a0[i0 & 3u]), (unsigned)((unsigned)h1 == (unsigned)d0), (unsigned)(0x7fffffffu && (unsigned)b0)); }
        if ((0u ? p1 : u0)) goto L1;
    }
    do { if (--fuel == 0u) goto done;
        c0 = (unsigned char)(unsigned)((short)(i2 << (i2 & 31u)) > (signed char)g0);
        switch ((unsigned)h1 & 7u) {
            case 3u: ;
        }
        v0 = (unsigned)(0x2681e88u == (unsigned)((int)fuel < (int)0x4e677dcau));
        if ((unsigned)((g1 / (r0.y | 1u)) == u0)) {
            u3 ^= (unsigned)(*mp == 0x10000u);
            e0 = e0 * 0.5L + (long double)((0x10000u * 3u) & 1023u);
            w0 = w0 * 6364136223846793005ull + (unsigned)(0xffffffffu == (0x10000u * ((unsigned)e0 >> ((unsigned)((int)8u < (int)u0) & 31u))));
        } else {
            continue; (void)((garr[u2 & 7u] % (~((unsigned)(w0 >> 29) / (p0 | 1u)) | 1u)));
            { unsigned t5; double z5; if ((u2) & 1u) { t5 = (i1 - *q0); z5 = (double)(((0x10000u % (g0 | 1u))) & 255u); } if ((u2) & 1u) { u3 += t5; d0 = d0 * 0.5 + z5; }
                if ((unsigned)((unsigned)x0 || (unsigned)c0)) {
                    l0 = (long)((unsigned long)l0 + r0.x);
                    b0 = ((g0 + u3) - (i1 ^ (unsigned)f0)) != 0u;
                    if ((unsigned)((int)(unsigned)s0 < (int)0xffffffffu)) break;
                    for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                        r0.x = (((unsigned)(0xd6f8cb80u == 1u) & (unsigned)((unsigned)s1 || u2)) / (1u | 1u));
                        if (budget != 0u) { budget -= 1u; u2 = fn0(0x80000000u, (9u % (a0[u1 & 3u] | 1u)), (a0[i0 & 3u] | fuel)); }
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)c0, (unsigned)((0xffffffffu * fuel) || u2), a0[u1 & 3u]); }
                        goto L1;
                        garr[garr[u2 & 7u] & 7u] = ((unsigned)b0 ^ ((a0[i0 & 3u] / (0x7fffffffu | 1u)) - r0.y));
                    }
                }
            }
            if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((int)0u < (int)(g0 | 0x11cc5ff2u)), (unsigned)(unsigned char)(unsigned)(g0 && ((unsigned)h1 - 0xffffffffu)), (unsigned)!(0x31b29462u >> (m0 & 31u))); }
        }
        if (0x10000u) continue;
        if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)x0 & 0xffffffffu), (unsigned)((short)(unsigned)(3u < g0) > (signed char)garr[u2 & 7u]), u0); }
    } while (i0++ < 2u && g1);
    if (3u) goto L2;
    if ((unsigned)h0) {
        if ((unsigned)((int)(unsigned)b0 >= (int)9u)) goto L1;
        c0 = (unsigned char)(unsigned)(short)(unsigned)((g0 << (((unsigned)((unsigned)(x0 >> 70) && 0x14b57df3u) >> (1u & 31u)) & 31u)) && *mp);
        for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((9u * 6u)) continue;
        }
        if (u3 == 7u) return ((unsigned)(short)(0xdba2362bu ? (unsigned)l0 : p2) ^ i1);
        if ((5u | 0x80000000u)) {
            while (i0++ < 3u && i0) { if (--fuel == 0u) goto done;
                u3 = u3 * 0x9e3779b1u + (unsigned)(0x80000000u < (unsigned)((unsigned)(a0[i0 & 3u] < p2) && g0));
                v0 = (unsigned)(p2 < ((unsigned)(0xa0ea62cbu || u2) >> ((unsigned)h1 & 31u)));
                if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)d0, (0x711a8f7du + garr[u2 & 7u]), (0xb732a295u % (g1 | 1u))); }
                { unsigned t6; double z6; if (((a0[i0 & 3u] & (p1 ^ i0))) & 1u) { t6 = (0u / (((unsigned)d0 & u2) | 1u)); z6 = (double)(((p1 >> (((unsigned)d0 & 0x791c8cb3u) & 31u))) & 255u); } if (((a0[i0 & 3u] & (p1 ^ i0))) & 1u) { u0 += t6; d0 = d0 * 0.5 + z6; }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((int)(unsigned)d0 < (int)(0x10000u << ((unsigned)s1 & 31u))), (0x852915feu ? 3u : (unsigned)h1), (2u >> (garr[u2 & 7u] & 31u))); }
                    u3 ^= (unsigned)(signed char)(5u + (unsigned)(signed char)(unsigned)((unsigned)((unsigned)(x0 >> 70) && (unsigned)c0) == (u0 >> (1u & 31u))));
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)((short)(unsigned)c1 > (signed char)p2) == (unsigned)((3u % ((unsigned)c1 | 1u)) == 0xffffffffu)));
                    if (budget != 0u) { budget -= 1u; u2 = fn2(((unsigned)l0 << (4u & 31u)), 0xffffffffu, (unsigned)(*q0 < (unsigned)(0x6296db49u || 0x664e762eu))); }
                    if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(((unsigned)b0 | 0u) == u2), (a0[i0 & 3u] % (0x80000000u | 1u)), u0); }
                    if ((u2 << (a0[i0 & 3u] & 31u))) goto L3;
                }
                m0 ^= (((unsigned)w0 % ((unsigned)d0 | 1u)) / ((u0 - -(6u >> (r0.y & 31u))) | 1u));
                switch (u0 & 7u) {
                    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)h1, ((unsigned)h0 / ((unsigned)((int)i0 >= (int)0x2b22cc53u) | 1u)), (unsigned)((short)a0[i0 & 3u] > (signed char)0x80000000u)); }
                    h1 = (unsigned short)(h1 + (unsigned)((i1 / ((unsigned)((short)8u > (signed char)i2) | 1u)) < r0.y));
                    s1 = (int)((unsigned)s1 + (unsigned)(p0 || (unsigned)(((unsigned)x0 * p1) || (unsigned)s1)));
                    c0 = (unsigned char)(unsigned)!(unsigned)((int)(u3 ? (unsigned)s1 : 0xbfa02debu) >= (int)*mp);
                }
            }
            if ((unsigned)((unsigned)s0 && p0)) goto L4;
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((int)p0 < (int)(unsigned)s1), v0, (r0.x + u0)); }
            if (((unsigned)e0 >> (p0 & 31u))) goto L0;
        } else {
            garr[(u0 & v0) & 7u] = ((unsigned)((1u ^ p1) || (p0 & (unsigned)c0)) - i1);
            e0 = e0 * 0.5L + (long double)((((unsigned)h1 & a0[u1 & 3u]) * ((unsigned)((short)0x7fffffffu > (signed char)r0.x) % (g1 | 1u))) & 1023u);
            { unsigned t7; double z7; if (((unsigned)((unsigned)w0 < (unsigned)h1)) & 1u) { t7 = ((unsigned)b0 + i2); z7 = (double)(((0x3a9ccffu - (unsigned)(short)(unsigned)((short)(unsigned)d0 > (signed char)p2))) & 255u); } if (((unsigned)((unsigned)w0 < (unsigned)h1)) & 1u) { u2 += t7; d0 = d0 * 0.5 + z7; }
                if ((garr[i1 & 7u] ^ (3u & i1))) goto L1;
            }
        }
    }
    l0 = (long)((unsigned long)l0 + (a0[i0 & 3u] | r0.y));
    if (budget != 0u) { budget -= 1u; u1 = fn0(*q0, (unsigned)((short)(unsigned)d0 > (signed char)a0[u1 & 3u]), ((unsigned)!(garr[i1 & 7u] ^ 0x43c25c95u) & g0)); }
    if ((unsigned)(3u < u1)) goto L1;
    goto done;
    goto L2;
    { unsigned t8; double z8; if (((unsigned)f0) & 1u) { t8 = p1; z8 = (double)((i1) & 255u); } if (((unsigned)f0) & 1u) { u2 += t8; d0 = d0 * 0.5 + z8; }
        h1 = (unsigned short)(h1 + (a0[i0 & 3u] / ((i1 ? i1 : 0xecbfee37u) | 1u)));
        v0 = (((unsigned)l0 / (4u | 1u)) * (unsigned)(8u == i2));
        if (0x80000000u) {
            d0 = d0 * 0.5 + (double)((unsigned)(fuel == 3u) & 1023u);
            goto L1;
            if (budget != 0u) { budget -= 1u; u2 = fn1((unsigned)((int)(0x7fffffffu >> ((unsigned)d0 & 31u)) >= (int)u3), (unsigned)(g1 == 9u), (unsigned)d0); }
            i0 = ((unsigned)(w0 >> 29) ? a0[u1 & 3u] : (unsigned)(signed char)((unsigned)d0 - (g1 & (unsigned)w0))) & 15u;
            u3 = 0u;
            u3 += (0x80000000u - u3);
        }
        switch (((unsigned)b0 >> (*q0 & 31u)) & 7u) {
            for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
                break; (void)(r0.x);
            }
            r0.x = u2;
            w0 = w0 * 6364136223846793005ull + (unsigned)((u2 >> (0x3ca21e0fu & 31u)) || (unsigned)w0);
            h1 = (unsigned short)(h1 + ((p2 ^ (garr[i1 & 7u] << ((unsigned)l0 & 31u))) ^ r0.y));
        }
    }
    while (0x59657ed7u) { if (--fuel == 0u) goto done;
        u1 = u1 * 0x9e3779b1u + g0;
        q0 = &garr[(unsigned)((int)(unsigned)w0 >= (int)((unsigned)l0 << (3u & 31u))) & 7u];
        if ((unsigned)((short)(unsigned)((int)(unsigned)x0 < (int)0x869c3390u) > (signed char)(unsigned)e0)) continue;
        if ((unsigned)(signed char)((u3 | *mp) >> ((unsigned)c1 & 31u))) goto L3;
        for (;;) { if (--fuel == 0u) goto done;
            if ((0u + (unsigned)e0)) break;
            f0 = f0 * 0.5f + (float)((0x8b3462d0u / (r0.x | 1u)) & 255u);
            if (budget != 0u) { budget -= 1u; u2 = fn0((0x80000000u | 2u), ~(unsigned)((unsigned)l0 == (0xffffffffu + u2)), ((unsigned)(g1 || 0x7fffffffu) / (u2 | 1u))); }
            if (g0) break;
            if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)h0 % (u3 | 1u)), p1, ((*mp >> (u1 & 31u)) ^ u3)); }
            if (0x60428f8cu) break;
        }
        if (r0.x) break;
    }
    for (i0 = 0u; i0 < 6u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (p0) break;
        if (budget != 0u) { budget -= 1u; u1 = fn2(((unsigned)(unsigned char)((unsigned)f0 | p2) ^ (unsigned)w0), ((unsigned)c0 & (unsigned)h0), (unsigned)w0); }
        while (i1++ < 4u && (unsigned)e0) { if (--fuel == 0u) goto done;
            if ((*q0 % ((unsigned)((int)(unsigned)(x0 >> 70) >= (int)r0.y) | 1u))) break;
        }
        break; (void)((unsigned)(a0[u1 & 3u] || (unsigned)(unsigned char)(unsigned)(g0 || u2)));
        b0 = ((unsigned)s0 - (unsigned)f0) != 0u;
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        if (m0) {
            g1 += (8u | (unsigned)(5u || 0x7fffffffu));
            break; (void)((unsigned)h1);
            switch ((unsigned)(unsigned char)(fuel | 0xbab6219du) & 7u) {
                *mp = ((unsigned)d0 / ((unsigned)(short)(((unsigned)(x0 >> 70) << (m0 & 31u)) - fuel) | 1u));
                g1 += (unsigned)((short)(unsigned)((short)9u > (signed char)1u) > (signed char)0x10000u);
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 6u: ;
                    switch (m0 & 7u) {
                        x0 = x0 * 0x100000001b3ull + (unsigned)w0;
                    }
                    l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((1u / (0x562c342bu | 1u)) || u1) < 0xffffffffu));
                }
                for (i1 = 0u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    a0[(unsigned)c0 & 3u] = ((((unsigned)((int)(unsigned)b0 >= (int)0x4832d6c2u) >> ((unsigned)s0 & 31u)) ^ r0.x) + a0[u1 & 3u]);
                    case 0u: ;
                }
                for (i1 = 1u; i1 < 7u; i1 += 1u) { if (--fuel == 0u) goto done;
                    if ((unsigned)c1) continue;
                    u1 += (unsigned)(unsigned char)(0x7fffffffu + fuel);
                }
            }
            s0 = (int)((unsigned)((unsigned)x0 == (unsigned)x0) | 0x7fffffffu);
            do { if (--fuel == 0u) goto done;
                if ((unsigned)e0) break;
                u3 = u3 * 0x9e3779b1u + ((unsigned)((unsigned)e0 == (unsigned)e0) & *mp);
                c0 = (unsigned char)(u0 & v0);
            } while (i1++ < 5u && 0x10000u);
        }
        if (0x7fffffffu) {
            if ((0x80000000u ^ (0u / ((unsigned)f0 | 1u)))) break;
        }
        { unsigned t9; double z9; if (((5u & (a0[i0 & 3u] | (unsigned)l0))) & 1u) { t9 = (unsigned)(5u < (unsigned)((int)i1 < (int)g0)); z9 = (double)((((unsigned)((int)(unsigned)c1 >= (int)a0[u1 & 3u]) >> (0xc27d1b8eu & 31u))) & 255u); } if (((5u & (a0[i0 & 3u] | (unsigned)l0))) & 1u) { u0 += t9; d0 = d0 * 0.5 + z9; }
            a0[9u & 3u] = (unsigned)(unsigned char)(unsigned)((p1 >> (0x9f709bb4u & 31u)) || -(a0[u1 & 3u] & (unsigned)(*mp && (unsigned)e0)));
            while ((unsigned)(x0 >> 70)) { if (--fuel == 0u) goto done;
                if (garr[u2 & 7u]) break;
                x0 = x0 * 0x100000001b3ull + (0xffffffffu | g0);
                s1 = (int)((unsigned)s1 + (unsigned)(g0 && g0));
                e0 = e0 * 0.5L + (long double)(((r0.x >> ((unsigned)d0 & 31u)) / (0x5cb6f9f6u | 1u)) & 1023u);
                if ((unsigned)(short)(unsigned)(~(u3 & i0) && r0.y)) goto done;
                if ((unsigned)(unsigned char)(unsigned)((int)1u >= (int)(unsigned)((int)0x809c4768u >= (int)g1))) continue;
            }
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)(short)(0x7fffffffu * *q0), (g1 | fuel), (unsigned)(0x31c968a6u && a0[i0 & 3u])); }
            if (0x80000000u) break;
            while (i1++ < 5u && *mp) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 5u; i2 += 1u) { if (--fuel == 0u) goto done;
                    goto L4;
                    m0 ^= (unsigned)((unsigned)(0xffffffffu && (unsigned)h0) && ((unsigned)(w0 >> 29) | (unsigned)c0));
                    if (((unsigned)f0 - (unsigned)((short)(unsigned)e0 > (signed char)0xee9494f7u))) break;
                }
                g0 = 0x80000000u;
                e0 = e0 * 0.5L + (long double)((u2 | (unsigned)((int)(unsigned)x0 < (int)a0[i0 & 3u])) & 1023u);
            }
        }
        if (budget != 0u) { budget -= 1u; u3 = fn2((unsigned)((unsigned)(short)(p0 ^ 0x80000000u) && (unsigned)c0), (unsigned)c0, ((unsigned)e0 * (unsigned)((int)a0[u1 & 3u] >= (int)(unsigned)f0))); }
        r0.x = 0x15ec45cfu;
        b0 = (((unsigned)l0 >> (g0 & 31u)) % ((unsigned)(v0 == (unsigned)((int)(unsigned)e0 >= (int)(unsigned)e0)) | 1u)) != 0u;
    }
    while (i0++ < 6u && p2) { if (--fuel == 0u) goto done;
        if (-(unsigned)((unsigned)w0 || (unsigned)c1)) continue;
        c0 = (unsigned char)(0x7fffffffu ^ garr[u2 & 7u]);
        if ((0x80000000u - ((unsigned)f0 - (unsigned)h1))) {
            if ((unsigned)((int)(i1 | u0) >= (int)u3)) {
                s0 = (int)(unsigned)(9u && p1);
                if ((unsigned)((int)0x80000000u < (int)(8u * i2))) goto L3;
                do { if (--fuel == 0u) goto done;
                    u2 = v0;
                    c0 = (unsigned char)(unsigned)s0;
                    { unsigned t10; double z10; if (((unsigned)!(unsigned)(0x10000u == (0x80000000u ^ (unsigned)c0))) & 1u) { t10 = (0x10000u >> (a0[u1 & 3u] & 31u)); z10 = (double)((1u) & 255u); } if (((unsigned)!(unsigned)(0x10000u == (0x80000000u ^ (unsigned)c0))) & 1u) { u0 += t10; d0 = d0 * 0.5 + z10; }
                        if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(p1 || 0x1cd9b514u), (unsigned)((short)(unsigned)((short)p2 > (signed char)0xffffffffu) > (signed char)*mp), (unsigned)c0); }
                        garr[((unsigned)f0 | 0x10000u) & 7u] = (-(0x5bf4ae68u * m0) ? 5u : ~(0x3500e186u ^ (unsigned)l0));
                        u3 = g0;
                    }
                } while (i1++ < 4u && u1);
                garr[p0 & 7u] = ((unsigned)h1 % ((unsigned)((int)(unsigned)((int)0x7fffffffu < (int)((unsigned)f0 ^ i0)) >= (int)a0[u1 & 3u]) | 1u));
            }
            u2 = u2 * 0x9e3779b1u + p2;
        } else {
            do { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(unsigned)h0 << (0x10000u & 63u);
                w0 = w0 * 6364136223846793005ull + (i1 % (~(unsigned)((unsigned)((int)0x80000000u < (int)a0[i0 & 3u]) == 0x34e68003u) | 1u));
                switch (((0u - g0) & 0x80000000u) & 7u) {
                    case 1u: ;
                    if (~(0x10000u >> (i0 & 31u))) {
                        h0 = (short)(unsigned)(short)(unsigned)(garr[u2 & 7u] < (unsigned)l0);
                        *q0 = 1u;
                        case 5u: ;
                        if ((r0.y ? a0[u1 & 3u] : 0x80000000u)) goto done;
                        case 6u: ;
                        *q0 += (m0 >> ((unsigned)s1 & 31u));
                    }
                    u1 = (unsigned)((short)(unsigned)((short)(u2 << ((unsigned)((int)0x1c4dbd30u < (int)(unsigned)l0) & 31u)) > (signed char)5u) > (signed char)0x80000000u);
                    if (budget != 0u) { budget -= 1u; u1 = fn0((*q0 ? (unsigned)w0 : (unsigned)c0), (i2 / (r0.y | 1u)), (*q0 & (r0.y % (a0[u1 & 3u] | 1u)))); }
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)f0, r0.x, (unsigned)l0); }
                }
                h0 = (short)(unsigned)((short)(*q0 % (*q0 | 1u)) > (signed char)(unsigned)((unsigned)c0 == (unsigned)!(0xb4ae96b4u & 0x10000u)));
                c0 = (unsigned char)((4u - (unsigned)h0) | (0x80000000u & (unsigned)b0));
            } while (i1++ < 4u && (unsigned)e0);
        }
        while (i1++ < 3u && (unsigned)((unsigned)h0 && m0)) { if (--fuel == 0u) goto done;
            if (fuel < 8u) return (unsigned)(signed char)(unsigned)((int)garr[u2 & 7u] >= (int)p2);
            h1 = (unsigned short)(h1 + u2);
            r0.x = (a0[i0 & 3u] * u3);
            x0 = x0 * 0x100000001b3ull + ((unsigned)((int)(unsigned)(*q0 && i0) < (int)0x80000000u) + (unsigned)((short)(unsigned)b0 > (signed char)(unsigned)d0));
        }
    }
    s1 = (int)((unsigned)s1 + (unsigned)((int)-(r0.x ^ (0x80000000u / (i2 | 1u))) >= (int)(0x8ff99870u ^ 8u)));
    if ((unsigned)(x0 >> 70)) {
        if ((u1 & 0x15b660f5u)) {
            u3 ^= (p1 / ((unsigned)c1 | 1u));
            w0 = w0 * 6364136223846793005ull + ((a0[u1 & 3u] % ((unsigned)b0 | 1u)) ? (p1 - 0xc5ca2369u) : 0x80000000u);
            g1 += (unsigned)((int)((unsigned)c0 / (0x34e721dcu | 1u)) >= (int)(7u ^ 0x80000000u));
            i0 = ((unsigned)((short)g0 > (signed char)(0x37915052u * (unsigned)s1)) & (unsigned)d0) & 15u;
            if (budget != 0u) { budget -= 1u; u3 = fn2(r0.x, 0x10000u, (unsigned)(unsigned char)(unsigned)((short)(unsigned)(signed char)(0x10000u / (i0 | 1u)) > (signed char)(unsigned)(x0 >> 70))); }
        } else {
            d0 = d0 * 0.5 + (double)((unsigned)c1 & 1023u);
        }
        r0.x = (unsigned)(signed char)((unsigned)(g1 || 0xffffffffu) / (fuel | 1u));
        r0.y ^= ((unsigned)((unsigned)f0 && (unsigned)e0) * ((unsigned)(0x7fffffffu && 0u) | 0x10000u));
        for (i0 = 0u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
            if ((unsigned)(signed char)(unsigned)(i2 < (m0 >> (i2 & 31u)))) break;
        }
        if (((u2 * r0.y) & garr[i1 & 7u])) {
            if ((unsigned)!(unsigned)((int)0x8f7cf7b8u >= (int)(unsigned)x0)) {
                u0 = (unsigned)(((unsigned)((unsigned)x0 && u0) >> (u0 & 31u)) == 9u);
                c0 = (unsigned char)(unsigned)(fuel && m0);
                u2 ^= g1;
                a0[(unsigned)(w0 >> 29) & 3u] = (garr[u2 & 7u] << (((unsigned)(0x10000u < (unsigned)h1) | 0xc914cbbdu) & 31u));
                goto L1;
            }
            { unsigned t11; double z11; if ((((unsigned)l0 + (unsigned)(unsigned char)((unsigned)s0 << ((unsigned)h0 & 31u)))) & 1u) { t11 = (unsigned)!((unsigned)(7u < r0.y) >> (a0[u1 & 3u] & 31u)); z11 = (double)((u3) & 255u); } if ((((unsigned)l0 + (unsigned)(unsigned char)((unsigned)s0 << ((unsigned)h0 & 31u)))) & 1u) { u2 += t11; d0 = d0 * 0.5 + z11; }
                c1 = (signed char)((unsigned)((unsigned)c0 || garr[i1 & 7u]) | fuel);
                for (i0 = 0u; i0 < 7u; i0 += 1u) { if (--fuel == 0u) goto done;
                    u2 = u2 * 0x9e3779b1u + ((4u >> ((unsigned)s1 & 31u)) ^ u3);
                    w0 = w0 * 6364136223846793005ull + ~(unsigned)(*q0 == ((unsigned)(w0 >> 29) ^ (unsigned)d0));
                    a0[p2 & 3u] = (m0 + (unsigned)c0);
                    if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)w0, ((i1 * (unsigned)h0) | (unsigned)l0), (unsigned)(0x80000000u && 0xd4aea7a1u)); }
                    if (-((unsigned)c1 & (r0.y + 1u))) goto L1;
                    if (((unsigned)f0 - 2u)) break;
                }
                b0 = -(unsigned)(*mp || (u3 * 0x21ff205cu)) != 0u;
            }
            h0 = (short)(0x80000000u & (unsigned)(garr[u2 & 7u] && r0.x));
            *q0 = (unsigned)((int)(unsigned)((int)i1 < (int)g1) >= (int)(g0 ? 0x7fffffffu : 1u));
            while (i0++ < 3u && 0x80000000u) { if (--fuel == 0u) goto done;
                *q0 += (3u << (*q0 & 31u));
                if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)((unsigned)s0 && 0x80000000u), 0x80000000u, (a0[u1 & 3u] << ((unsigned)((short)v0 > (signed char)0xef754065u) & 31u))); }
                for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                    r0.x = (unsigned)(0xa57d3b17u < 0x7cdb457u);
                }
                h1 = (unsigned short)(h1 + (unsigned)((unsigned)((int)(i2 + 0x80000000u) < (int)(unsigned)(garr[u2 & 7u] < *mp)) == u3));
                *mp = (unsigned)(signed char)((0xcb4271cbu % (u0 | 1u)) ^ (unsigned)(garr[u2 & 7u] || (u3 >> ((unsigned)s0 & 31u))));
                if (budget != 0u) { budget -= 1u; u2 = fn0(4u, (0x7fffffffu & (8u + (unsigned)l0)), (unsigned)(short)((unsigned)h0 / ((u2 >> (0x7fffffffu & 31u)) | 1u))); }
            }
        } else {
            *q0 = (unsigned)h0;
            u3 = (0x38e23682u % (((unsigned)b0 % (i1 | 1u)) | 1u));
            g0 = (((unsigned)(signed char)(unsigned)((unsigned)s1 || 1u) + (unsigned)e0) * (unsigned)b0);
        }
    } else {
        r0.y ^= ((unsigned)f0 >> ((unsigned)(0x10000u == (p0 - (unsigned)x0)) & 31u));
        switch (((unsigned)l0 ^ (7u ^ (unsigned)e0)) & 7u) {
            while ((unsigned)!(4u | (unsigned)((int)0x55365db1u >= (int)(unsigned)l0))) { if (--fuel == 0u) goto done;
                for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
                    case 3u: ;
                    s0 = (int)(unsigned)((short)*q0 > (signed char)(unsigned)!(unsigned)(0x7fffffffu && r0.y));
                    u1 = (unsigned)(short)(unsigned)((unsigned)x0 && (unsigned)(0xffffffffu && 0xffffffffu));
                }
                case 1u: ;
                for (i1 = 1u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    for (i2 = 0u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                        if (fuel < 8u) return (-(0x3ba7cb57u * (unsigned)d0) >> (garr[u2 & 7u] & 31u));
                    }
                    if (budget != 0u) { budget -= 1u; u3 = fn0(((unsigned)x0 & p2), p1, (unsigned)((short)~(i1 << (g1 & 31u)) > (signed char)p1)); }
                    case 2u: ;
                }
                x0 = x0 * 0x100000001b3ull + (garr[i1 & 7u] % ((unsigned)(unsigned char)(fuel - garr[i1 & 7u]) | 1u));
                if ((unsigned)((int)0x10000u >= (int)0xffffffffu)) goto done;
            }
        }
    }
    if (-((unsigned)h0 >> (~(0u << (0xe9007504u & 31u)) & 31u))) {
        if (budget != 0u) { budget -= 1u; u0 = fn0((unsigned)(0x6d644a3eu < *mp), 0x6fc70704u, 1u); }
        switch ((unsigned)((unsigned)s0 && (unsigned)w0) & 7u) {
            b0 = (unsigned)(u0 == ((unsigned)e0 & (unsigned)(m0 == (u2 % (0x80000000u | 1u))))) != 0u;
            switch ((unsigned)(unsigned char)(0x669f8938u ^ (unsigned)d0) & 7u) {
                for (i0 = 0u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((int)*mp >= (int)(unsigned)b0), (unsigned)(9u < p1), (-(unsigned)(0xbd9e30aau || 0u) >> (0x23c1acf4u & 31u))); }
                    case 4u: ;
                    b0 = ((unsigned)((int)i1 >= (int)0xdd990186u) << ((unsigned)(0xc7cb97c6u == (unsigned)((unsigned)d0 == (unsigned)c0)) & 31u)) != 0u;
                    if (0xb88f93dbu) goto L1;
                    do { if (--fuel == 0u) goto done;
                        continue; (void)(((0xffffffffu | 0x80000000u) % ((unsigned)(x0 >> 70) | 1u)));
                        garr[(unsigned)(m0 < 0x10000u) & 7u] = (p2 - (unsigned)((int)0xe0cf9197u >= (int)(unsigned)!(unsigned)(u0 < 0x50da24bbu)));
                        u1 = ((unsigned)((int)a0[u1 & 3u] >= (int)r0.x) - (unsigned)b0);
                        r0.x = 0x59a5f730u;
                        r0.x = (((unsigned)h0 % (0x406ca851u | 1u)) << (0x7fffffffu & 31u));
                        if (budget != 0u) { budget -= 1u; u2 = fn0((unsigned)((int)0x10000u < (int)p2), (m0 - ((unsigned)h0 ^ (unsigned)s0)), (0x10000u | garr[i1 & 7u])); }
                    } while (i1++ < 5u && ((unsigned)l0 * 0x11f0451u));
                }
            }
            s1 = (int)((unsigned)s1 + 5u);
        }
        q0 = &garr[(unsigned)((unsigned)((int)a0[i0 & 3u] >= (int)(unsigned)h1) == (unsigned)((unsigned)(u1 < u2) == u2)) & 7u];
    } else {
        for (;;) { if (--fuel == 0u) goto done;
            if (budget != 0u) { budget -= 1u; u0 = fn1((unsigned)((short)0x32b217c5u > (signed char)(unsigned)(short)(unsigned)((unsigned)(w0 >> 29) < 5u)), 0x3284f70bu, i0); }
            if ((unsigned)(8u || (unsigned)b0)) break;
            continue; (void)((0x7fffffffu << ((unsigned)(x0 >> 70) & 31u)));
            if ((garr[i1 & 7u] - ((unsigned)h0 >> (garr[u2 & 7u] & 31u)))) break;
        }
        if (budget != 0u) { budget -= 1u; u1 = fn0(0x73ae9b1au, garr[u2 & 7u], (unsigned)((unsigned)w0 || p0)); }
        u3 ^= ((unsigned)((short)9u > (signed char)(unsigned)w0) * (unsigned)(signed char)(unsigned)(v0 == (unsigned)(x0 >> 70)));
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            u3 = ((unsigned)f0 ^ (unsigned)l0);
            if (m0) break;
            break; (void)(3u);
        }
    }
    goto L1;
    if ((unsigned)((0u + u2) < m0)) goto done;
    goto done;
    if (0xb0ed2448u) goto L1;
    if (budget != 0u) { budget -= 1u; u3 = fn1(*q0, (unsigned)b0, v0); }
    a0[(i0 & (unsigned)w0) & 3u] = (unsigned)((int)(unsigned)(u3 || v0) < (int)(unsigned)((int)r0.x >= (int)garr[i1 & 7u]));
    if ((unsigned)s0) goto L1;
    if (budget != 0u) { budget -= 1u; u1 = fn0((0x80000000u * p2), (unsigned)h1, ((unsigned)f0 / (u1 | 1u))); }
    switch ((r0.y % ((unsigned)(short)(g1 % ((unsigned)c1 | 1u)) | 1u)) & 7u) {
        *mp = r0.x;
    }
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        { unsigned t12; double z12; if ((-((unsigned)(u2 || 6u) * (unsigned)c1)) & 1u) { t12 = a0[i0 & 3u]; z12 = (double)((u2) & 255u); } if ((-((unsigned)(u2 || 6u) * (unsigned)c1)) & 1u) { u0 += t12; d0 = d0 * 0.5 + z12; }
            if (0x9fd15670u) break;
            break; (void)((unsigned)((int)(0x7fffffffu - 6u) < (int)(unsigned)b0));
            b0 = u0 != 0u;
        }
        h0 = (short)((garr[i1 & 7u] << (5u & 31u)) & a0[i0 & 3u]);
        { unsigned t13; double z13; if (((unsigned)((unsigned)c1 || (unsigned)x0)) & 1u) { t13 = (((unsigned)c1 & g0) | (unsigned)f0); z13 = (double)(((unsigned)((5u | u3) < garr[i1 & 7u])) & 255u); } if (((unsigned)((unsigned)c1 || (unsigned)x0)) & 1u) { u2 += t13; d0 = d0 * 0.5 + z13; }
            i0 = a0[u1 & 3u] & 15u;
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                for (i2 = 1u; i2 < 7u; i2 += 1u) { if (--fuel == 0u) goto done;
                    if (u3 == 7u) return (*q0 << (0x7fffffffu & 31u));
                }
                if ((p0 << ((unsigned)w0 & 31u))) break;
                u0 = u0 * 0x9e3779b1u + ~(((v0 * 0x7fffffffu) ? u1 : a0[u1 & 3u]) | (unsigned)s0);
                e0 = e0 * 0.5L + (long double)((unsigned)d0 & 1023u);
                if (u3 == 7u) return (unsigned)((short)((0xffffffffu & (unsigned)(x0 >> 70)) * (unsigned)s0) > (signed char)0xffffffffu);
            }
            break; (void)((u3 & i0));
        }
        goto L2;
    }
    b0 = (unsigned)h0 != 0u;
    if (-(unsigned)(6u && 0x2dd56147u)) {
        for (i0 = 1u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
            v0 = ((unsigned)((short)0xffffffffu > (signed char)((p2 >> (v0 & 31u)) + r0.y)) << (6u & 31u));
            switch (((unsigned)s0 + ((unsigned)s0 << (r0.y & 31u))) & 7u) {
                break; (void)(0x8a02a473u);
                q0 = &garr[((unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)0x7fffffffu >= (int)(unsigned)c1) >= (int)(unsigned)(short)(9u ^ (unsigned)s0)) ^ garr[i1 & 7u]) & 7u];
                u0 = ((i2 >> (r0.y & 31u)) ^ -((unsigned)(w0 >> 29) << ((unsigned)((int)i1 < (int)u0) & 31u)));
                if (budget != 0u) { budget -= 1u; u3 = fn1((v0 >> ((g0 ^ *q0) & 31u)), (unsigned)b0, 4u); }
                for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                    s0 = (int)(unsigned)((int)0x10000u >= (int)0u);
                }
            }
            s0 = (int)p1;
        }
    } else {
        x0 = x0 * 0x100000001b3ull + (unsigned)(~(unsigned)((unsigned)((int)(unsigned)s1 < (int)0x80000000u) || 2u) && g1);
        i2 = (g0 - p0) & 15u;
        *mp = ((unsigned)(((unsigned)d0 & (9u - u2)) < 0xffffffffu) * (unsigned)f0);
    }
    s1 = (int)((unsigned)s1 + (unsigned)(p0 || *mp));
    goto L3;
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

static unsigned fn4(unsigned p0, unsigned p1, unsigned p2)
{
    unsigned fuel = 40u + (p0 & 15u);
    unsigned u0 = p0, u1 = p1 ^ 0x9e3779b9u, u2 = p2, u3 = 0u;
    unsigned i0 = 0u, i1 = 0u, i2 = 0u;
    int s0 = (int)p2, s1 = -7;
    unsigned char c0 = (unsigned char)p0;
    signed char c1 = (signed char)p1;
    short h0 = (short)p1;
    unsigned short h1 = (unsigned short)p2;
    unsigned long long w0 = ((unsigned long long)p0 << 32) | p1;
    long l0 = -1;
    _Bool b0 = p0 > p1;
    unsigned __int128 x0 = ((unsigned __int128)p2 << 64) | p0;
    double d0 = 0.5;
    float f0 = 2.0f;
    long double e0 = 0.25L;
    unsigned* q0 = &garr[p0 & 7u];
    unsigned m0 = p1;
    unsigned* mp = &m0;
    volatile unsigned v0 = p2;
    unsigned a0[4] = { p0, p1, p2, 3u };
    struct ssa_pair r0 = { p0, p2 };
    *mp = (0xaa03decbu ^ (unsigned)l0);
    for (i0 = 0u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
        break; (void)(((unsigned)c1 << (0x1158b48u & 31u)));
        break; (void)((((unsigned)x0 | u0) + p1));
    }
    if (budget != 0u) { budget -= 1u; u1 = fn2((9u & (unsigned)d0), (unsigned)(w0 >> 29), ((unsigned)h1 + p1)); }
    switch (~(p2 + (unsigned)s1) & 7u) {
        if (-(unsigned)((unsigned)!(i0 + a0[i0 & 3u]) < 9u)) {
            case 0u: ;
            case 1u: ;
        }
        L0: if (--fuel == 0u) goto done;
        default: ;
        { unsigned t0; double z0; if (((i1 & r0.y)) & 1u) { t0 = ((unsigned)x0 ? u2 : 8u); z0 = (double)((((unsigned)c1 * i0)) & 255u); } if (((i1 & r0.y)) & 1u) { u3 += t0; d0 = d0 * 0.5 + z0; }
            goto L3;
            case 4u: ;
            if ((g1 & (r0.y * v0))) {
                if ((r0.y << ((unsigned)s0 & 31u))) {
                    L1: if (--fuel == 0u) goto done;
                    while (i0++ < 4u && (-((unsigned)x0 << (1u & 31u)) / ((unsigned)h1 | 1u))) { if (--fuel == 0u) goto done;
                        case 3u: ;
                        i2 = u2 & 15u;
                        break;
                        e0 = e0 * 0.5L + (long double)(((garr[i1 & 7u] ? (unsigned)c0 : (unsigned)d0) & (unsigned)x0) & 1023u);
                        switch ((unsigned)((int)0x80000000u < (int)4u) & 7u) {
                            r0.x = (unsigned)(w0 >> 29);
                            if (budget != 0u) { budget -= 1u; u1 = fn1(m0, (unsigned)((unsigned)f0 < m0), 3u); }
                            case 7u: ;
                            L2: if (--fuel == 0u) goto done;
                            q0 = &garr[((unsigned)((unsigned)l0 && garr[i1 & 7u]) >> ((i2 >> (u1 & 31u)) & 31u)) & 7u];
                        }
                    }
                    e0 = e0 * 0.5L + (long double)((unsigned)(unsigned char)(0x80000000u >> (garr[u2 & 7u] & 31u)) & 1023u);
                    q0 = &garr[(unsigned)(unsigned char)(0x47b571d9u + (unsigned)w0) & 7u];
                    s1 = (int)((unsigned)s1 + (((unsigned)x0 % (*q0 | 1u)) * u3));
                    for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
                        L3: if (--fuel == 0u) goto done;
                        if (((unsigned)((int)i1 >= (int)g1) << (0x7fffffffu & 31u))) continue;
                        if ((u3 | (unsigned)d0)) continue;
                    }
                }
                x0 = x0 * 0x100000001b3ull + (unsigned)((unsigned)f0 && ((unsigned)l0 ^ (garr[i1 & 7u] + 0x9af5b644u)));
                switch ((((unsigned)l0 << (garr[i1 & 7u] & 31u)) ^ (unsigned)b0) & 7u) {
                    if ((unsigned)((0x1b2cdc5u - (unsigned)s1) == (unsigned)l0)) {
                        w0 ^= (unsigned long long)garr[u2 & 7u] << ((unsigned)((int)(unsigned)b0 >= (int)(unsigned)h0) & 63u);
                        u2 += (unsigned)!(r0.x * 0x7fffffffu);
                        break; (void)((((unsigned)x0 - p1) << (7u & 31u)));
                        L4: if (--fuel == 0u) goto done;
                        *mp = (unsigned)((int)((0xf7e8e77du + 0x7fffffffu) - g0) >= (int)(p1 | 0x56ddd43u));
                        if (budget != 0u) { budget -= 1u; u1 = fn3((unsigned)(0x230ec769u && (unsigned)(r0.x < garr[i1 & 7u])), 2u, (garr[u2 & 7u] % (9u | 1u))); }
                    }
                    do { if (--fuel == 0u) goto done;
                        goto L0;
                        case 6u: ;
                        if (budget != 0u) { budget -= 1u; u0 = fn3(0x10000u, (unsigned)((unsigned)b0 < 0xffffffffu), g1); }
                        case 5u: ;
                    } while (i0++ < 5u && (m0 | 0x7fffffffu));
                    m0 ^= ((1u ^ (unsigned)h1) | (unsigned)e0);
                    w0 = w0 * 6364136223846793005ull + (unsigned)!(unsigned)((int)(unsigned)c0 >= (int)(unsigned)f0);
                    s0 = (int)((0xa201e677u >> (0xcf6e5e09u & 31u)) - ~(unsigned)((short)g0 > (signed char)(unsigned)f0));
                    r0.x = 1u;
                }
                if (fuel < 8u) return (((unsigned)b0 & (unsigned)x0) % (fuel | 1u));
            }
            if (budget != 0u) { budget -= 1u; u2 = fn2((unsigned)((short)(unsigned)l0 > (signed char)(9u & *mp)), ((unsigned)w0 * (unsigned)c1), (unsigned)((unsigned)b0 < r0.y)); }
        }
    }
    if (((unsigned)f0 % ((unsigned)d0 | 1u))) goto L0;
    goto L2;
    for (i0 = 0u; i0 < 5u; i0 += 1u) { if (--fuel == 0u) goto done;
        u0 = u0 * 0x9e3779b1u + (a0[i0 & 3u] << (((unsigned)f0 << (v0 & 31u)) & 31u));
        if (1u) break;
        if (budget != 0u) { budget -= 1u; u3 = fn2((i1 & (unsigned)h0), 0x7fffffffu, 0x9df12281u); }
        do { if (--fuel == 0u) goto done;
            r0.x = (unsigned)((unsigned)(short)(unsigned)((short)((unsigned)s1 * (0u >> (0x10000u & 31u))) > (signed char)fuel) && (unsigned)e0);
            for (;;) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u0 = fn0(0x63701611u, m0, (unsigned)(*mp && 0xffffffffu)); }
                if ((unsigned)(unsigned char)((unsigned)f0 | 8u)) break;
            }
            { unsigned t1; double z1; if ((((unsigned)(g0 && u1) / (r0.y | 1u))) & 1u) { t1 = (((unsigned)s0 % (9u | 1u)) ^ (unsigned)s0); z1 = (double)((0x10000u) & 255u); } if ((((unsigned)(g0 && u1) / (r0.y | 1u))) & 1u) { u2 += t1; d0 = d0 * 0.5 + z1; }
                for (i2 = 1u; i2 < 6u; i2 += 1u) { if (--fuel == 0u) goto done;
                    *mp = (garr[u2 & 7u] - (unsigned)((short)(unsigned)h0 > (signed char)(unsigned)(fuel || (unsigned)((unsigned)l0 < (unsigned)d0))));
                    g1 += (unsigned)(short)((-(0x10000u & 9u) ? 6u : 0xf688f817u) & i2);
                    if ((fuel ^ 0x10000u)) continue;
                    if ((unsigned)h1) goto L4;
                    r0.x = (0xfc93be60u << ((0x7fffffffu << ((unsigned)(unsigned char)(unsigned)(0u < (unsigned)((int)7u < (int)(unsigned)(x0 >> 70))) & 31u)) & 31u));
                    if ((unsigned)w0) {
                        w0 = w0 * 6364136223846793005ull + (((unsigned)x0 << ((unsigned)((unsigned)(w0 >> 29) < p2) & 31u)) | (unsigned)((short)(unsigned)(x0 >> 70) > (signed char)p1));
                    }
                }
                a0[(m0 * (unsigned)d0) & 3u] = ((unsigned)((int)7u < (int)3u) ? (a0[i0 & 3u] % (u0 | 1u)) : (unsigned)w0);
                if (budget != 0u) { budget -= 1u; u1 = fn2((u2 >> (0x10000u & 31u)), (unsigned)c1, (unsigned)(*mp < (0x7fffffffu * (unsigned)c0))); }
                if (budget != 0u) { budget -= 1u; u2 = fn2((a0[i0 & 3u] >> (6u & 31u)), (unsigned)((unsigned)((int)a0[u1 & 3u] >= (int)garr[i1 & 7u]) == 0xb900bac2u), ((1u & (unsigned)e0) % ((unsigned)s1 | 1u))); }
                if (budget != 0u) { budget -= 1u; u3 = fn0((unsigned)(4u || 0x804f811du), (u0 & 0x80000000u), p1); }
            }
            i1 = (unsigned)(unsigned char)(garr[u2 & 7u] & (unsigned)s0) & 15u;
            switch ((p1 * i2) & 7u) {
                case 4u: ;
                *q0 += (0x4bdd3e5bu << (r0.y & 31u));
                r0.y ^= garr[u2 & 7u];
                for (;;) { if (--fuel == 0u) goto done;
                    if (budget != 0u) { budget -= 1u; u3 = fn0((u0 ^ 0xfdf7ac2cu), (unsigned)((int)(unsigned)h1 >= (int)0xffffffffu), (u2 ^ ((unsigned)d0 & a0[u1 & 3u]))); }
                    l0 = (long)((unsigned long)l0 + (unsigned)!(unsigned)((int)garr[u2 & 7u] >= (int)(unsigned)l0));
                    h1 = (unsigned short)(h1 + (unsigned)((unsigned)(a0[u1 & 3u] || (unsigned)s1) && 0xffffffffu));
                    if (fuel < 8u) return (unsigned)!(unsigned)(0x80000000u < (unsigned)!((unsigned)((2u ^ (unsigned)f0) || 0x7fffffffu) | 0xed782e37u));
                }
                e0 = e0 * 0.5L + (long double)(((8u % ((i0 + p1) | 1u)) - ~(0x80000000u % (i1 | 1u))) & 1023u);
                v0 = (unsigned)((short)((unsigned)w0 ? (unsigned)w0 : (unsigned)c0) > (signed char)r0.x);
            }
        } while (i1++ < 4u && (unsigned)(u1 || (unsigned)(1u == garr[i1 & 7u])));
        do { if (--fuel == 0u) goto done;
            goto L1;
        } while (i1++ < 3u && ~(v0 + (unsigned)((short)0xa8d8f102u > (signed char)u0)));
        if (budget != 0u) { budget -= 1u; u0 = fn2(a0[i0 & 3u], garr[i1 & 7u], (u0 / ((unsigned)f0 | 1u))); }
    }
    m0 ^= ((unsigned)((int)(unsigned)h1 < (int)(u1 - 0xffffffffu)) | r0.y);
    if (0x182f4569u) goto done;
    if (a0[u1 & 3u]) {
        goto L4;
        g0 = (unsigned)((g1 - (u0 ? (unsigned)h0 : u2)) < 0xffffffffu);
        switch ((unsigned)b0 & 7u) {
            w0 ^= (unsigned long long)(unsigned)((int)*mp < (int)(unsigned)x0) << ((0xa2034e7u * ((unsigned)s1 / ((fuel ? m0 : p0) | 1u))) & 63u);
        }
        if ((unsigned)((int)((unsigned)s0 % (p1 | 1u)) < (int)0x19c26e92u)) goto L3;
        goto L4;
    }
    while (i0++ < 3u && m0) { if (--fuel == 0u) goto done;
        *q0 = (unsigned)(-(unsigned)(0x1723c6d5u == (unsigned)d0) < 0xffffffffu);
    }
    while (i0++ < 5u && 7u) { if (--fuel == 0u) goto done;
        for (i1 = 0u; i1 < 3u; i1 += 1u) { if (--fuel == 0u) goto done;
            m0 ^= (~(0xb9863f3fu << (p1 & 31u)) & garr[i1 & 7u]);
            if (0x1fe96318u) break;
            do { if (--fuel == 0u) goto done;
                m0 ^= (unsigned)((int)m0 < (int)((unsigned)h0 - 0xfc908034u));
                g1 += (((unsigned)s0 ? (p1 - 7u) : p2) ^ u1);
                x0 = x0 * 0x100000001b3ull + (unsigned)d0;
            } while (i2++ < 4u && (unsigned)w0);
            if (0xbdcd78e6u) continue;
        }
        q0 = &garr[(i2 ^ a0[i0 & 3u]) & 7u];
        while (i1++ < 4u && (unsigned)(i2 == (unsigned)((int)(unsigned)x0 < (int)i0))) { if (--fuel == 0u) goto done;
            d0 = d0 * 0.5 + (double)((*mp << (0x80000000u & 31u)) & 1023u);
            h0 = (short)(unsigned)(short)((unsigned)(u3 && (unsigned)s0) - ((unsigned)s0 + (unsigned)s1));
            if ((unsigned)(i2 || 0x140f4bc5u)) continue;
            for (i2 = 1u; i2 < 3u; i2 += 1u) { if (--fuel == 0u) goto done;
                if (budget != 0u) { budget -= 1u; u2 = fn0((0xffffffffu & 0xd73150f4u), (*q0 * g0), 0x80000000u); }
            }
        }
    }
    if (a0[u1 & 3u]) goto L3;
    if (budget != 0u) { budget -= 1u; u1 = fn0((unsigned)(p0 < 0x10000u), 0x80000000u, (r0.y >> ((unsigned)c1 & 31u))); }
    if (0x80000000u) goto L0;
    { unsigned t2; double z2; if (((fuel | 0x66835522u)) & 1u) { t2 = (unsigned)(unsigned char)(unsigned)(u2 || 0xceb698d4u); z2 = (double)(((unsigned)((int)(unsigned)h0 >= (int)(a0[i0 & 3u] & (unsigned)l0))) & 255u); } if (((fuel | 0x66835522u)) & 1u) { u3 += t2; d0 = d0 * 0.5 + z2; }
        if (budget != 0u) { budget -= 1u; u0 = fn3(v0, r0.x, g1); }
        if (u3 == 7u) return (unsigned)((unsigned)((unsigned)c0 == (unsigned)e0) && ((unsigned)h0 / (i1 | 1u)));
        if ((a0[u1 & 3u] & i0)) {
            if ((unsigned)(signed char)(unsigned)((int)*mp >= (int)(fuel >> (u0 & 31u)))) goto L3;
        } else {
            r0.y ^= (unsigned)((g0 & (unsigned)h0) && p0);
        }
    }
    m0 ^= ((unsigned)s0 % (0x9d807a7du | 1u));
    c0 = (unsigned char)(unsigned)s1;
    goto L3;
    if ((unsigned)((int)*q0 >= (int)4u)) {
        h0 = (short)(unsigned)(0xc4c647f4u < (unsigned)s0);
    }
    u0 = u0 * 0x9e3779b1u + 0xffffffffu;
    c1 = (signed char)(g1 % (~((unsigned)(p0 || (unsigned)h1) ^ (unsigned)((int)(unsigned)(w0 >> 29) >= (int)p1)) | 1u));
    if ((unsigned)(0x3d6d3fbfu == 0xcf8975adu)) {
        if (((unsigned)(i0 == r0.x) ^ (unsigned)(w0 >> 29))) goto L3;
        for (i0 = 1u; i0 < 4u; i0 += 1u) { if (--fuel == 0u) goto done;
            b0 = (unsigned)s1 != 0u;
            *q0 = ~((unsigned)x0 * (unsigned)c0);
            u3 += (unsigned)(unsigned char)(unsigned)((int)(unsigned)((int)(*q0 % (*mp | 1u)) < (int)(unsigned)s1) >= (int)r0.y);
            for (i1 = 0u; i1 < 5u; i1 += 1u) { if (--fuel == 0u) goto done;
                b0 = (*mp % ((0x1654ccc9u + garr[i1 & 7u]) | 1u)) != 0u;
                l0 = (long)((unsigned long)l0 + (unsigned)((unsigned)((int)(unsigned)d0 >= (int)fuel) && ((garr[u2 & 7u] - 0x10000u) << (8u & 31u))));
            }
            switch (0x10000u & 7u) {
                h0 = (short)(unsigned)(short)(unsigned)((short)*q0 > (signed char)(unsigned)((int)0u < (int)(unsigned)(w0 >> 29)));
                if (budget != 0u) { budget -= 1u; u3 = fn3(((unsigned)(signed char)(unsigned)((int)p0 >= (int)(unsigned)(x0 >> 70)) ^ (unsigned)c0), r0.y, (5u >> ((1u + r0.x) & 31u))); }
                u1 ^= u1;
            }
            u2 = p2;
        }
    } else {
        while (i0++ < 7u && (unsigned)((short)0x22d6aec1u > (signed char)i1)) { if (--fuel == 0u) goto done;
            { unsigned t3; double z3; if (((unsigned)(((unsigned)s1 - (unsigned)h0) == p1)) & 1u) { t3 = *mp; z3 = (double)(((unsigned)c0) & 255u); } if (((unsigned)(((unsigned)s1 - (unsigned)h0) == p1)) & 1u) { u3 += t3; d0 = d0 * 0.5 + z3; }
                continue; (void)((0x42821040u % ((g0 + 0x10000u) | 1u)));
                continue; (void)((r0.y + (m0 + 6u)));
                *q0 = ((unsigned)(x0 >> 70) ? (unsigned)(w0 >> 29) : (unsigned)((short)p2 > (signed char)(unsigned)s0));
            }
            if ((unsigned)((int)u3 < (int)(unsigned)d0)) break;
        }
        if (((unsigned)(unsigned char)(m0 / ((unsigned)x0 | 1u)) + (unsigned)x0)) {
            l0 = (long)((unsigned long)l0 + (unsigned)((int)m0 < (int)(0x80000000u + fuel)));
            if (((unsigned)h0 - *mp)) goto L0;
        } else {
            if (budget != 0u) { budget -= 1u; u1 = fn1((unsigned)(unsigned char)((v0 * (unsigned)s0) % (*q0 | 1u)), (unsigned)((short)0x80000000u > (signed char)7u), (unsigned)((short)(unsigned)((short)(unsigned)(x0 >> 70) > (signed char)(unsigned)l0) > (signed char)*mp)); }
            i0 = (unsigned)((int)(unsigned)(*mp && 3u) < (int)(unsigned)s1) & 15u;
            if (0x80000000u) goto L4;
            if (budget != 0u) { budget -= 1u; u3 = fn1((a0[i0 & 3u] + (unsigned)s1), (unsigned)(unsigned char)(unsigned)((int)0xffffffffu >= (int)((unsigned)h0 | *mp)), (unsigned)(8u || u2)); }
        }
    }
    for (i0 = 1u; i0 < 3u; i0 += 1u) { if (--fuel == 0u) goto done;
        if ((3u & (unsigned)b0)) break;
        if ((0x10000u / ((unsigned)((unsigned)w0 == 1u) | 1u))) break;
        if (budget != 0u) { budget -= 1u; u1 = fn2(~(6u | (unsigned)(r0.y == (unsigned)c0)), (unsigned)((unsigned)e0 || (unsigned)(0x5fbb72fu == garr[u2 & 7u])), garr[u2 & 7u]); }
        while (i1++ < 6u && (unsigned)x0) { if (--fuel == 0u) goto done;
            w0 ^= (unsigned long long)g1 << ((unsigned)d0 & 63u);
            if (0u) break;
        }
        break; (void)(g1);
        if (g0) {
            garr[garr[u2 & 7u] & 7u] = (((unsigned)c1 + (unsigned)(a0[u1 & 3u] || (unsigned)(signed char)(unsigned)((int)p0 >= (int)r0.y))) * 0x7fffffffu);
            s0 = (int)(unsigned)((int)((unsigned)((int)0x80000000u >= (int)(unsigned)(x0 >> 70)) >> ((unsigned)e0 & 31u)) >= (int)(unsigned)(5u < 0xffffffffu));
            { unsigned t4; double z4; if (((unsigned)(signed char)(((unsigned)d0 & i2) - (unsigned)s1)) & 1u) { t4 = (p1 & (unsigned)d0); z4 = (double)(((garr[i1 & 7u] << (7u & 31u))) & 255u); } if (((unsigned)(signed char)(((unsigned)d0 & i2) - (unsigned)s1)) & 1u) { u0 += t4; d0 = d0 * 0.5 + z4; }
                if (budget != 0u) { budget -= 1u; u0 = fn3((unsigned)(*q0 && (unsigned)((short)0xd2b64fbeu > (signed char)(unsigned)h1)), ((unsigned)b0 * (unsigned)((unsigned)h1 && 6u)), (0x73cc91du >> ((unsigned)c1 & 31u))); }
                if ((unsigned)(signed char)((unsigned)s1 ^ (unsigned)f0)) break;
                if (budget != 0u) { budget -= 1u; u3 = fn1(((unsigned)s0 | (unsigned)c0), i1, (unsigned)((int)(unsigned)h0 < (int)g0)); }
            }
            if ((p2 % ((4u - (unsigned)c0) | 1u))) break;
            for (i1 = 1u; i1 < 2u; i1 += 1u) { if (--fuel == 0u) goto done;
                b0 = (unsigned)((short)(unsigned)(0x10000u == garr[u2 & 7u]) > (signed char)(0xc6512e0au % ((unsigned)c1 | 1u))) != 0u;
            }
            for (i1 = 0u; i1 < 6u; i1 += 1u) { if (--fuel == 0u) goto done;
                w0 ^= (unsigned long long)(0xffffffffu + 0x7fffffffu) << ((unsigned)(short)((unsigned)(w0 >> 29) ? 3u : (unsigned)s1) & 63u);
                r0.y ^= (unsigned)((int)(unsigned)(signed char)(0xfb3eb92au | (unsigned)(signed char)(unsigned)((int)3u >= (int)(unsigned)b0)) >= (int)(unsigned)c0);
                c0 = (unsigned char)(unsigned)((((unsigned)((unsigned)b0 == u0) | (unsigned)e0) & r0.x) == u1);
                h1 = (unsigned short)(h1 + 8u);
                switch (((r0.y & (unsigned)d0) & m0) & 7u) {
                    if (0x2a10e3a4u) goto L4;
                }
            }
        }
    }
    if ((unsigned)(5u == 0xffffffffu)) {
        if (fuel < 8u) return (m0 - (unsigned)(0u && 4u));
    }
    for (i0 = 1u; i0 < 2u; i0 += 1u) { if (--fuel == 0u) goto done;
        x0 = x0 * 0x100000001b3ull + (unsigned)(0x7fffffffu && (p2 >> (0x17097522u & 31u)));
    }
    a0[(unsigned)(0xa9b188a0u == (unsigned)c1) & 3u] = (((unsigned)w0 * p1) % ((unsigned)f0 | 1u));
done:
    return u0 ^ u1 ^ u2 ^ u3 ^ i0 ^ i1 ^ i2 ^ fuel ^ (unsigned)s0 ^ (unsigned)s1 ^ (unsigned)c0 ^ (unsigned)c1 ^ (unsigned)h0 ^
           (unsigned)h1 ^ (unsigned)w0 ^ (unsigned)(w0 >> 32) ^ (unsigned)l0 ^ (unsigned)b0 ^ (unsigned)x0 ^ (unsigned)(x0 >> 96) ^
           (unsigned)d0 ^ (unsigned)f0 ^ (unsigned)e0 ^ *q0 ^ m0 ^ v0 ^ a0[0] ^ a0[1] ^ a0[2] ^ a0[3] ^ r0.x ^ r0.y;
}

int main(void)
{
    static const unsigned inputs[5][3] = {
        { 14u, 0x6a9dc1bdu, 0x9988d11cu },
        { 15u, 0xc9ba9ff8u, 0x3497744fu },
        { 8u, 0x586f53e2u, 0x2f5ba6aeu },
        { 6u, 0x5905ca39u, 0x5a1b90f0u },
        { 5u, 0xee405c37u, 0xbdbe3337u },
    };
    unsigned h = 2166136261u;
    for (unsigned i = 0u; i < 5u; i += 1u)
    {
        budget = 24u;
        h = (h ^ fn0(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn1(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn2(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn3(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        budget = 24u;
        h = (h ^ fn4(inputs[i][0], inputs[i][1], inputs[i][2])) * 16777619u;
        printf("%u: %u %u %u %u %u\n", i, h, g0, g1, garr[i & 7u], garr[(i + 3u) & 7u]);
    }
    return 0;
}
