int f(void){ if (0) return 9; else return 7; }
