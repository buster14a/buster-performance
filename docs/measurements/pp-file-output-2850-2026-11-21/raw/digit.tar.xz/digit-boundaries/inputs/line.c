#line 90 "digits.c"
int f(void){return __LINE__ + 5;}
