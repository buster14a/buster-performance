int x = 2\
5 + 4;
int f(void){return 1 + 3;}
