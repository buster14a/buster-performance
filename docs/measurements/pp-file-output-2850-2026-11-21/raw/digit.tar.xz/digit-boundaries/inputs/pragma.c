#pragma message("digits 4 and 5")
int f(void){return 6;}
