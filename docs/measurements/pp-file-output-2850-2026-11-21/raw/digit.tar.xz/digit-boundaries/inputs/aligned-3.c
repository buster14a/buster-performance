;;;
#define ONE 1
#define BOTH(a,b) ((a)+(b))
#define TWO 2
#define PLAIN(x) x
#define GLUE(a,b) a ## b
enum { V = 8 };
int f(int a)
{
  int x = -1 + (2 + 3) - 4 + 5 + a;
  int y = 07 + 010 + 0x1 + 2U + 3L + (int)(4e0) + 100 + 001;
  return PLAIN(1) + BOTH(2,3) + ONE + TWO + GLUE(1,0) + x + y + V + 0;
}
#if 0
int near(void){return 7;}
#endif
