int f(int x) { int q = x + 5; return q * 2 - x; }
int main(void) { return f(1) - 11; }
