static inline __m256i check_input_decimal_eight(__m512i addresses, __m256i lengths32, __mmask8 active, __mmask8* accepted)
{
    const __m512i zero = _mm512_setzero_si512();
    const __m512i one = _mm512_set1_epi64(1), eight = _mm512_set1_epi64(8);
    const __m512i offsets = _mm512_and_si512(addresses,_mm512_set1_epi64(7));
    const __m512i lengths = _mm512_cvtepu32_epi64(lengths32);
    const __m512i aligned = _mm512_andnot_si512(_mm512_set1_epi64(7),addresses);
    const __m512i first = _mm512_mask_i64gather_epi64(zero,active,aligned,(const void*)0,1);
    const __mmask8 crosses = _mm512_mask_cmpgt_epu64_mask(active,_mm512_add_epi64(offsets,lengths),eight);
    const __m512i second = _mm512_mask_i64gather_epi64(zero,crosses,_mm512_add_epi64(aligned,eight),(const void*)0,1);
    const __m512i shift = _mm512_slli_epi64(offsets,3);
    const __m512i chars = _mm512_or_si512(_mm512_srlv_epi64(first,shift),
                                         _mm512_sllv_epi64(second,_mm512_sub_epi64(_mm512_set1_epi64(64),shift)));
    const __m512i bits = _mm512_slli_epi64(_mm512_min_epu64(lengths,eight),3);
    const __m512i live = _mm512_sub_epi64(_mm512_sllv_epi64(one,bits),one);
    const __m512i digits = _mm512_sub_epi8(chars,_mm512_set1_epi8('0'));
    const __m512i bad = _mm512_movm_epi8(_mm512_cmpgt_epu8_mask(digits,_mm512_set1_epi8(9)));
    __mmask8 valid = _mm512_mask_testn_epi64_mask(active,live,bad);
    const __mmask8 multiple = _mm512_mask_cmpgt_epu64_mask(valid,lengths,one);
    valid &= ~_mm512_mask_testn_epi64_mask(multiple,digits,_mm512_set1_epi64(255));
    // Zero-pad on the left to exactly eight digits, then reduce pairs and groups of four.
    const __m512i padded = _mm512_sllv_epi64(_mm512_and_si512(digits,live),_mm512_sub_epi64(_mm512_set1_epi64(64),bits));
    const __m512i pairs = _mm512_maddubs_epi16(padded,_mm512_set1_epi16(0x010a));
    const __m512i fours = _mm512_madd_epi16(pairs,_mm512_set1_epi32(0x00010064));
    const __m512i reduced = _mm512_add_epi32(_mm512_mullo_epi32(fours,_mm512_set1_epi32(10000)),_mm512_srli_epi64(fours,32));
    __m256i result = _mm512_cvtepi64_epi32(reduced);
    const __mmask8 ninth = _mm512_mask_cmpeq_epu64_mask(valid,lengths,_mm512_set1_epi64(9));
    if (ninth != 0)
    {
        const __m512i last = _mm512_sub_epi64(_mm512_and_si512(_mm512_srlv_epi64(second,shift),_mm512_set1_epi64(255)),_mm512_set1_epi64('0'));
        valid &= ~_mm512_mask_cmpgt_epu64_mask(ninth,last,_mm512_set1_epi64(9));
        result = _mm256_mask_add_epi32(result,ninth,_mm256_mullo_epi32(result,_mm256_set1_epi32(10)),_mm512_cvtepi64_epi32(last));
    }
    *accepted = valid;
    return result;
}
