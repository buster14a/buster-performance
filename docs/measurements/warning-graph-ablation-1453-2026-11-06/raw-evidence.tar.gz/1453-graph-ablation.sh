#!/usr/bin/env bash
set -euo pipefail
workdir="$HOME/buster-fast-bench/1453-codex-20261106-perf"
sqlite="$HOME/buster-fast-bench/1296-codex-20261105/corpus/sqlite"
export EXCLUSIVE_OWNER=codex-1453 EXCLUSIVE_LINK=https://github.com/buster14a/buster/pull/1453 LC_ALL=C
cd "$workdir/repo"
for version in ablate-base ablate-head; do
  git fetch "$workdir/$version.bundle" HEAD
  git worktree add --detach "$workdir/$version" FETCH_HEAD
  export EXCLUSIVE_TITLE="PR 1453 $version diagnostic ablation build"
  "$HOME/buster-fast-bench/exclusive.sh" bash -c '
    set -euo pipefail
    test "${BUSTER_9700X_HELD:-}" = 1
    workdir="$1"; version="$2"
    { printf "held=%s\n" "$BUSTER_9700X_HELD"; cat /var/lib/buster-9700x/owner; } > "$workdir/$version-build.receipt"
    env BUSTER_HOST_ARCH=znver5 BUSTER_DEBUG_INFO=0 "$workdir/$version/build.sh" --jobs 4 > "$workdir/$version-build.log" 2>&1
    { printf "status=0\n"; cat /var/lib/buster-9700x/owner; sha256sum "$workdir/$version/build/compiler"; } >> "$workdir/$version-build.receipt"
  ' -- "$workdir" "$version"
done
for round in 1 2; do
  if [[ "$round" == 1 ]]; then order=(base-on head-on head-off base-off); else order=(base-off head-off head-on base-on); fi
  for item in "${order[@]}"; do
    version="${item%%-*}"; mode="${item#*-}"
    export EXCLUSIVE_TITLE="PR 1453 $version graph $mode diagnostic sample $round"
    "$HOME/buster-fast-bench/exclusive.sh" bash -c '
      set -euo pipefail
      version="$1"; mode="$2"; round="$3"; workdir="$4"; sqlite="$5"
      test "${BUSTER_9700X_HELD:-}" = 1
      cp "$workdir/ablate-$version/build/compiler" "$workdir/compiler"
      prefix="$workdir/ablate-$version-$mode-$round"
      { printf "held=%s\n" "$BUSTER_9700X_HELD"; cat /var/lib/buster-9700x/owner; sha256sum "$workdir/compiler"; } > "$prefix.receipt"
      if [[ "$mode" == off ]]; then export BUSTER_1453_ABLATE_GRAPH=1; else unset BUSTER_1453_ABLATE_GRAPH; fi
      taskset -c 2 perf stat -x, -e instructions:u,cycles:u -o "$prefix.perf" -- "$workdir/compiler" -fsyntax-only -DSQLITE_OMIT_LOAD_EXTENSION -DSQLITE_THREADSAFE=0 -DSQLITE_ENABLE_MEMSYS5 -DSQLITE_ENABLE_RTREE "-I$sqlite" "$sqlite/sqlite3.c" > "$prefix.out" 2> "$prefix.err"
      { printf "status=0\n"; cat /var/lib/buster-9700x/owner; sha256sum "$prefix.out" "$prefix.err"; } >> "$prefix.receipt"
    ' -- "$version" "$mode" "$round" "$workdir" "$sqlite"
  done
done
