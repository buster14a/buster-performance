
/home/david/Documents/Codex/2026-11-19/profile-and-improve-buster-compilation-speed/work/width-evidence/vm/sorter.o:     file format elf64-x86-64


Disassembly of section .text:

000000000004f4a0 <sqlite3VdbeExec>:
   4f4a0:	push   rbx
   4f4a1:	push   rbp
   4f4a2:	push   r12
   4f4a4:	push   r13
   4f4a6:	push   r14
   4f4a8:	push   r15
   4f4aa:	sub    rsp,0x458
   4f4b1:	lea    rbp,[rsp+0x2f8]
   4f4b9:	mov    r13,QWORD PTR [rdi+0x88]
   4f4c0:	mov    r14,QWORD PTR [rdi]
   4f4c3:	movzx  r15d,BYTE PTR [r14+0x64]
   4f4c8:	mov    r12,QWORD PTR [rdi+0x68]
   4f4cc:	xor    ebx,ebx
   4f4ce:	cmp    DWORD PTR [rdi+0xd0],0x0
   4f4d5:	je     4f531 <sqlite3VdbeExec+0x91>
   4f4d7:	cmp    DWORD PTR [rdi+0xd0],0x0
   4f4de:	je     4f531 <sqlite3VdbeExec+0x91>
   4f4e0:	mov    rax,QWORD PTR [rdi]
   4f4e3:	mov    rdx,QWORD PTR [rax+0x20]
   4f4e7:	mov    eax,DWORD PTR [rax+0x28]
   4f4ea:	xor    ecx,ecx
   4f4ec:	jmp    4f52d <sqlite3VdbeExec+0x8d>
   4f4ee:	cmp    ecx,0x1
   4f4f1:	je     4f52a <sqlite3VdbeExec+0x8a>
   4f4f3:	mov    esi,0x1
   4f4f8:	shl    esi,cl
   4f4fa:	and    esi,DWORD PTR [rdi+0xd0]
   4f500:	test   esi,esi
   4f502:	je     4f52a <sqlite3VdbeExec+0x8a>
   4f504:	mov    rsi,rcx
   4f507:	shl    rsi,0x5
   4f50b:	cmp    QWORD PTR [rdx+rsi*1+0x8],0x0
   4f511:	je     4f52a <sqlite3VdbeExec+0x8a>
   4f513:	mov    rsi,rcx
   4f516:	shl    rsi,0x5
   4f51a:	mov    rsi,QWORD PTR [rdx+rsi*1+0x8]
   4f51f:	mov    r8,QWORD PTR [rsi+0x8]
   4f523:	mov    rsi,QWORD PTR [rsi]
   4f526:	mov    QWORD PTR [r8+0x8],rsi
   4f52a:	add    ecx,0x1
   4f52d:	cmp    ecx,eax
   4f52f:	jl     4f4ee <sqlite3VdbeExec+0x4e>
   4f531:	cmp    QWORD PTR [r14+0x208],0x0
   4f539:	je     4f55c <sqlite3VdbeExec+0xbc>
   4f53b:	mov    eax,DWORD PTR [rdi+0xe4]
   4f541:	mov    ecx,DWORD PTR [r14+0x218]
   4f548:	mov    esi,DWORD PTR [r14+0x218]
   4f54f:	xor    edx,edx
   4f551:	div    esi
   4f553:	mov    eax,edx
   4f555:	sub    ecx,eax
   4f557:	mov    rbp,rcx
   4f55a:	jmp    4f563 <sqlite3VdbeExec+0xc3>
   4f55c:	mov    rbp,0xffffffffffffffff
   4f563:	cmp    DWORD PTR [rdi+0x34],0x7
   4f567:	jne    4f5dc <sqlite3VdbeExec+0x13c>
   4f569:	mov    rbx,r13
   4f56c:	xor    r11d,r11d
   4f56f:	mov    DWORD PTR [rsp+0x400],r11d
   4f577:	xor    r11d,r11d
   4f57a:	mov    QWORD PTR [rsp+0x1b0],r11
   4f582:	mov    QWORD PTR [rsp+0x190],rdi
   4f58a:	mov    rdi,r14
   4f58d:	call   4f592 <sqlite3VdbeExec+0xf2>
   4f592:	lea    rax,[rip+0x0]        # 4f599 <sqlite3VdbeExec+0xf9>
   4f599:	mov    rdi,QWORD PTR [rsp+0x190]
   4f5a1:	mov    rsi,rax
   4f5a4:	xor    eax,eax
   4f5a6:	call   4f5ab <sqlite3VdbeExec+0x10b>
   4f5ab:	mov    r12d,0x7
   4f5b1:	mov    rdi,QWORD PTR [rsp+0x190]
   4f5b9:	mov    QWORD PTR [rsp+0x1d0],r13
   4f5c1:	mov    QWORD PTR [rsp+0x1c8],rbx
   4f5c9:	mov    r13,QWORD PTR [rsp+0x1b0]
   4f5d1:	mov    rbx,rbp
   4f5d4:	mov    rbp,r12
   4f5d7:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   4f5dc:	mov    DWORD PTR [rdi+0x34],0x0
   4f5e3:	mov    QWORD PTR [rdi+0x48],0x0
   4f5eb:	mov    DWORD PTR [r14+0x290],0x0
   4f5f6:	mov    eax,DWORD PTR [r14+0x190]
   4f5fd:	test   eax,eax
   4f5ff:	je     4f643 <sqlite3VdbeExec+0x1a3>
   4f601:	mov    rbx,r13
   4f604:	xor    r11d,r11d
   4f607:	mov    DWORD PTR [rsp+0x400],r11d
   4f60f:	xor    r11d,r11d
   4f612:	mov    QWORD PTR [rsp+0x1b0],r11
   4f61a:	mov    r12d,0x9
   4f620:	mov    QWORD PTR [rsp+0x1d0],r13
   4f628:	mov    QWORD PTR [rsp+0x1c8],rbx
   4f630:	mov    r13,QWORD PTR [rsp+0x1b0]
   4f638:	mov    rbx,rbp
   4f63b:	mov    rbp,r12
   4f63e:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   4f643:	movsxd rax,DWORD PTR [rdi+0x30]
   4f647:	imul   rax,rax,0x18
   4f64b:	lea    rbx,[r13+rax*1+0x0]
   4f650:	mov    r11d,0x10
   4f656:	vpbroadcastd zmm0,r11d
   4f65c:	mov    r11d,0x1
   4f662:	vpbroadcastd zmm1,r11d
   4f668:	mov    DWORD PTR [rsp+0x3fc],r15d
   4f670:	mov    QWORD PTR [rsp+0x1d0],r13
   4f678:	mov    QWORD PTR [rsp+0x1d8],rbp
   4f680:	mov    rbp,rbx
   4f683:	mov    rbx,r12
   4f686:	xor    r11d,r11d
   4f689:	mov    DWORD PTR [rsp+0x40c],r11d
   4f691:	xor    r11d,r11d
   4f694:	mov    DWORD PTR [rsp+0x400],r11d
   4f69c:	xor    r11d,r11d
   4f69f:	mov    DWORD PTR [rsp+0x410],r11d
   4f6a7:	xor    r12d,r12d
   4f6aa:	xor    r11d,r11d
   4f6ad:	mov    DWORD PTR [rsp+0x414],r11d
   4f6b5:	jmp    6c081 <sqlite3VdbeExec+0x1cbe1>
   4f6ba:	mov    QWORD PTR [rsp+0x1b0],r13
   4f6c2:	mov    r13,QWORD PTR [rsp+0x1d0]
   4f6ca:	mov    QWORD PTR [rsp+0x1d0],r13
   4f6d2:	mov    r13,QWORD PTR [rsp+0x1b0]
   4f6da:	cmp    r13,rbp
   4f6dd:	jb     4f777 <sqlite3VdbeExec+0x2d7>
   4f6e3:	cmp    QWORD PTR [r14+0x208],0x0
   4f6eb:	je     4f777 <sqlite3VdbeExec+0x2d7>
   4f6f1:	mov    eax,DWORD PTR [r14+0x218]
   4f6f8:	add    rbp,rax
   4f6fb:	mov    rax,QWORD PTR [r14+0x208]
   4f702:	mov    rcx,QWORD PTR [r14+0x210]
   4f709:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   4f714:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   4f71f:	mov    QWORD PTR [rsp+0x190],rdi
   4f727:	mov    rdi,rcx
   4f72a:	mov    r10,rax
   4f72d:	call   r10
   4f730:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   4f73b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   4f746:	mov    rdi,QWORD PTR [rsp+0x190]
   4f74e:	test   eax,eax
   4f750:	je     4f6ba <sqlite3VdbeExec+0x21a>
   4f756:	mov    rbx,0xffffffffffffffff
   4f75d:	mov    ebp,0x9
   4f762:	cmp    BYTE PTR [r14+0x67],0x0
   4f767:	je     6c1a5 <sqlite3VdbeExec+0x1cd05>
   4f76d:	mov    ebp,0x7
   4f772:	jmp    6c1db <sqlite3VdbeExec+0x1cd3b>
   4f777:	mov    DWORD PTR [rsp+0x3fc],r15d
   4f77f:	mov    QWORD PTR [rsp+0x1b0],r13
   4f787:	mov    DWORD PTR [rsp+0x410],ebx
   4f78e:	mov    QWORD PTR [rsp+0x1d8],rbp
   4f796:	mov    rbp,QWORD PTR [rsp+0x1c8]
   4f79e:	mov    rbx,QWORD PTR [rsp+0x1e0]
   4f7a6:	mov    DWORD PTR [rsp+0x414],r12d
   4f7ae:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   4f7b3:	mov    r15d,DWORD PTR [rsp+0x3fc]
   4f7bb:	mov    r13,QWORD PTR [rsp+0x1d0]
   4f7c3:	mov    QWORD PTR [rsp+0x1b0],r12
   4f7cb:	mov    r12d,DWORD PTR [rsp+0x414]
   4f7d3:	movsxd rax,DWORD PTR [rbp+0x4]
   4f7d7:	imul   rcx,rax,0x38
   4f7db:	mov    WORD PTR [rbx+rcx*1+0x14],0x4
   4f7e2:	mov    rax,rbp
   4f7e5:	sub    rax,r13
   4f7e8:	movabs rdx,0x2aaaaaaaaaaaaaab
   4f7f2:	imul   rdx
   4f7f5:	sar    rdx,0x2
   4f7f9:	mov    rax,rdx
   4f7fc:	shr    rax,0x3f
   4f800:	add    rdx,rax
   4f803:	mov    rax,rdx
   4f806:	movsxd rax,eax
   4f809:	mov    QWORD PTR [rbx+rcx*1],rax
   4f80d:	mov    eax,DWORD PTR [rbp+0x8]
   4f810:	sub    eax,0x1
   4f813:	movsxd rax,eax
   4f816:	imul   rax,rax,0x18
   4f81a:	lea    rbp,[r13+rax*1+0x0]
   4f81f:	mov    QWORD PTR [rsp+0x1c8],rbp
   4f827:	mov    QWORD PTR [rsp+0x1e0],rbx
   4f82f:	mov    ebx,DWORD PTR [rsp+0x410]
   4f836:	mov    eax,DWORD PTR [r14+0x190]
   4f83d:	test   eax,eax
   4f83f:	jne    4f84e <sqlite3VdbeExec+0x3ae>
   4f841:	mov    rbp,QWORD PTR [rsp+0x1d8]
   4f849:	jmp    4f6ca <sqlite3VdbeExec+0x22a>
   4f84e:	mov    rbx,QWORD PTR [rsp+0x1c8]
   4f856:	mov    rbp,QWORD PTR [rsp+0x1d8]
   4f85e:	jmp    4f61a <sqlite3VdbeExec+0x17a>
   4f863:	mov    r15d,DWORD PTR [rsp+0x3fc]
   4f86b:	mov    r13,QWORD PTR [rsp+0x1d0]
   4f873:	mov    QWORD PTR [rsp+0x1b0],r12
   4f87b:	mov    r12d,DWORD PTR [rsp+0x414]
   4f883:	movsxd rax,DWORD PTR [rbp+0x4]
   4f887:	imul   rax,rax,0x38
   4f88b:	movzx  ecx,WORD PTR [rbx+rax*1+0x14]
   4f890:	and    ecx,0x4
   4f893:	test   ecx,ecx
   4f895:	je     4f8a9 <sqlite3VdbeExec+0x409>
   4f897:	mov    ecx,DWORD PTR [rbp+0xc]
   4f89a:	mov    rax,QWORD PTR [rbx+rax*1]
   4f89e:	imul   rax,rax,0x18
   4f8a2:	lea    rbp,[r13+rax*1+0x0]
   4f8a7:	jmp    4f8ac <sqlite3VdbeExec+0x40c>
   4f8a9:	mov    eax,DWORD PTR [rbp+0xc]
   4f8ac:	mov    DWORD PTR [rsp+0x3fc],r15d
   4f8b4:	mov    QWORD PTR [rsp+0x1d0],r13
   4f8bc:	mov    DWORD PTR [rsp+0x414],r12d
   4f8c4:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   4f8c9:	mov    r15d,DWORD PTR [rsp+0x3fc]
   4f8d1:	mov    r13,QWORD PTR [rsp+0x1d0]
   4f8d9:	mov    QWORD PTR [rsp+0x1b0],r12
   4f8e1:	mov    r12d,DWORD PTR [rsp+0x414]
   4f8e9:	movsxd rax,DWORD PTR [rbp+0x4]
   4f8ed:	imul   rax,rax,0x38
   4f8f1:	mov    ecx,DWORD PTR [rbp+0xc]
   4f8f4:	sub    ecx,0x1
   4f8f7:	movsxd rcx,ecx
   4f8fa:	mov    QWORD PTR [rbx+rax*1],rcx
   4f8fe:	mov    WORD PTR [rbx+rax*1+0x14],0x4
   4f905:	cmp    DWORD PTR [rbp+0x8],0x0
   4f909:	je     4f923 <sqlite3VdbeExec+0x483>
   4f90b:	mov    QWORD PTR [rsp+0x1d0],r13
   4f913:	mov    DWORD PTR [rsp+0x414],r12d
   4f91b:	mov    r12,r14
   4f91e:	jmp    52730 <sqlite3VdbeExec+0x3290>
   4f923:	mov    DWORD PTR [rsp+0x3fc],r15d
   4f92b:	mov    QWORD PTR [rsp+0x1d0],r13
   4f933:	mov    DWORD PTR [rsp+0x414],r12d
   4f93b:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   4f940:	mov    r15d,DWORD PTR [rsp+0x3fc]
   4f948:	mov    r13,QWORD PTR [rsp+0x1d0]
   4f950:	mov    QWORD PTR [rsp+0x1b0],r12
   4f958:	mov    r12d,DWORD PTR [rsp+0x414]
   4f960:	movsxd rax,DWORD PTR [rbp+0x4]
   4f964:	imul   rcx,rax,0x38
   4f968:	mov    rax,QWORD PTR [rbx+rcx*1]
   4f96c:	imul   rsi,rax,0x18
   4f970:	mov    rax,rbp
   4f973:	sub    rax,QWORD PTR [rdi+0x88]
   4f97a:	movabs rdx,0x2aaaaaaaaaaaaaab
   4f984:	imul   rdx
   4f987:	sar    rdx,0x2
   4f98b:	mov    rax,rdx
   4f98e:	shr    rax,0x3f
   4f992:	add    rdx,rax
   4f995:	mov    rax,rdx
   4f998:	sub    eax,0x1
   4f99b:	movsxd rax,eax
   4f99e:	mov    QWORD PTR [rbx+rcx*1],rax
   4f9a2:	mov    eax,DWORD PTR [r13+rsi*1+0x8]
   4f9a7:	sub    eax,0x1
   4f9aa:	movsxd rax,eax
   4f9ad:	imul   rax,rax,0x18
   4f9b1:	lea    rbp,[r13+rax*1+0x0]
   4f9b6:	mov    DWORD PTR [rsp+0x3fc],r15d
   4f9be:	mov    QWORD PTR [rsp+0x1d0],r13
   4f9c6:	mov    DWORD PTR [rsp+0x414],r12d
   4f9ce:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   4f9d3:	mov    r15d,DWORD PTR [rsp+0x3fc]
   4f9db:	mov    r13,QWORD PTR [rsp+0x1d0]
   4f9e3:	mov    QWORD PTR [rsp+0x1b0],r12
   4f9eb:	mov    r12d,DWORD PTR [rsp+0x414]
   4f9f3:	movsxd rax,DWORD PTR [rbp+0x4]
   4f9f7:	imul   rcx,rax,0x38
   4f9fb:	mov    WORD PTR [rbx+rcx*1+0x14],0x4
   4fa02:	mov    rsi,QWORD PTR [rbx+rcx*1]
   4fa06:	mov    rax,rbp
   4fa09:	sub    rax,r13
   4fa0c:	movabs rdx,0x2aaaaaaaaaaaaaab
   4fa16:	imul   rdx
   4fa19:	sar    rdx,0x2
   4fa1d:	mov    rax,rdx
   4fa20:	shr    rax,0x3f
   4fa24:	add    rdx,rax
   4fa27:	mov    rax,rdx
   4fa2a:	movsxd rax,eax
   4fa2d:	mov    QWORD PTR [rbx+rcx*1],rax
   4fa31:	movsxd rax,esi
   4fa34:	imul   rax,rax,0x18
   4fa38:	lea    rbp,[r13+rax*1+0x0]
   4fa3d:	mov    DWORD PTR [rsp+0x3fc],r15d
   4fa45:	mov    QWORD PTR [rsp+0x1d0],r13
   4fa4d:	mov    DWORD PTR [rsp+0x414],r12d
   4fa55:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   4fa5a:	mov    r15d,DWORD PTR [rsp+0x3fc]
   4fa62:	mov    r13,QWORD PTR [rsp+0x1d0]
   4fa6a:	mov    QWORD PTR [rsp+0x1b0],r12
   4fa72:	mov    r12d,DWORD PTR [rsp+0x414]
   4fa7a:	movsxd rax,DWORD PTR [rbp+0xc]
   4fa7e:	imul   rax,rax,0x38
   4fa82:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   4fa87:	and    eax,0x1
   4fa8a:	test   eax,eax
   4fa8c:	jne    4faab <sqlite3VdbeExec+0x60b>
   4fa8e:	mov    DWORD PTR [rsp+0x3fc],r15d
   4fa96:	mov    QWORD PTR [rsp+0x1d0],r13
   4fa9e:	mov    DWORD PTR [rsp+0x414],r12d
   4faa6:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   4faab:	cmp    QWORD PTR [rdi+0x108],0x0
   4fab3:	je     4fb90 <sqlite3VdbeExec+0x6f0>
   4fab9:	cmp    DWORD PTR [rbp+0x4],0x0
   4fabd:	jne    4fb90 <sqlite3VdbeExec+0x6f0>
   4fac3:	mov    rax,QWORD PTR [rdi+0x108]
   4faca:	mov    rcx,QWORD PTR [rax+0x8]
   4face:	mov    QWORD PTR [rdi+0x108],rcx
   4fad5:	mov    ecx,DWORD PTR [rdi+0x118]
   4fadb:	sub    ecx,0x1
   4fade:	mov    DWORD PTR [rdi+0x118],ecx
   4fae4:	mov    rcx,QWORD PTR [rdi+0x38]
   4fae8:	mov    QWORD PTR [r14+0x78],rcx
   4faec:	mov    rdx,QWORD PTR [r14+0x80]
   4faf3:	add    rcx,rdx
   4faf6:	mov    QWORD PTR [r14+0x80],rcx
   4fafd:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   4fb08:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   4fb13:	mov    QWORD PTR [rsp+0x190],rdi
   4fb1b:	mov    rdi,rax
   4fb1e:	call   4fb23 <sqlite3VdbeExec+0x683>
   4fb23:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   4fb2e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   4fb39:	mov    rdi,QWORD PTR [rsp+0x190]
   4fb41:	cmp    DWORD PTR [rbp+0x8],0x4
   4fb45:	jne    4fb5c <sqlite3VdbeExec+0x6bc>
   4fb47:	mov    rcx,QWORD PTR [rdi+0x88]
   4fb4e:	movsxd rax,eax
   4fb51:	imul   rax,rax,0x18
   4fb55:	mov    eax,DWORD PTR [rcx+rax*1+0x8]
   4fb59:	sub    eax,0x1
   4fb5c:	mov    r13,QWORD PTR [rdi+0x88]
   4fb63:	mov    rbx,QWORD PTR [rdi+0x68]
   4fb67:	movsxd rax,eax
   4fb6a:	imul   rax,rax,0x18
   4fb6e:	lea    rbp,[r13+rax*1+0x0]
   4fb73:	mov    DWORD PTR [rsp+0x3fc],r15d
   4fb7b:	mov    QWORD PTR [rsp+0x1d0],r13
   4fb83:	mov    DWORD PTR [rsp+0x414],r12d
   4fb8b:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   4fb90:	mov    eax,DWORD PTR [rbp+0x4]
   4fb93:	mov    DWORD PTR [rdi+0x34],eax
   4fb96:	mov    eax,DWORD PTR [rbp+0x8]
   4fb99:	mov    BYTE PTR [rdi+0xc4],al
   4fb9f:	cmp    DWORD PTR [rdi+0x34],0x0
   4fba3:	je     4fd0e <sqlite3VdbeExec+0x86e>
   4fba9:	cmp    DWORD PTR [rbp+0xc],0x0
   4fbad:	jle    4fc47 <sqlite3VdbeExec+0x7a7>
   4fbb3:	cmp    BYTE PTR [rbp+0x1],0x0
   4fbb7:	jne    4fc47 <sqlite3VdbeExec+0x7a7>
   4fbbd:	movsxd rax,DWORD PTR [rbp+0xc]
   4fbc1:	imul   rax,rax,0x38
   4fbc5:	add    rax,rbx
   4fbc8:	test   rax,rax
   4fbcb:	jne    4fbd1 <sqlite3VdbeExec+0x731>
   4fbcd:	xor    eax,eax
   4fbcf:	jmp    4fc1e <sqlite3VdbeExec+0x77e>
   4fbd1:	movzx  ecx,WORD PTR [rax+0x14]
   4fbd5:	and    ecx,0x202
   4fbdb:	cmp    ecx,0x202
   4fbe1:	jne    4fbef <sqlite3VdbeExec+0x74f>
   4fbe3:	cmp    BYTE PTR [rax+0x16],0x1
   4fbe7:	jne    4fbef <sqlite3VdbeExec+0x74f>
   4fbe9:	mov    rax,QWORD PTR [rax+0x8]
   4fbed:	jmp    4fc1e <sqlite3VdbeExec+0x77e>
   4fbef:	movzx  ecx,WORD PTR [rax+0x14]
   4fbf3:	and    ecx,0x1
   4fbf6:	test   ecx,ecx
   4fbf8:	je     4fbfe <sqlite3VdbeExec+0x75e>
   4fbfa:	xor    eax,eax
   4fbfc:	jmp    4fc1e <sqlite3VdbeExec+0x77e>
   4fbfe:	mov    ecx,0x1
   4fc03:	mov    QWORD PTR [rsp+0x190],rdi
   4fc0b:	mov    rdi,rax
   4fc0e:	mov    rsi,rcx
   4fc11:	call   4fc16 <sqlite3VdbeExec+0x776>
   4fc16:	mov    rdi,QWORD PTR [rsp+0x190]
   4fc1e:	lea    rcx,[rip+0x0]        # 4fc25 <sqlite3VdbeExec+0x785>
   4fc25:	mov    QWORD PTR [rsp+0x190],rdi
   4fc2d:	mov    rsi,rcx
   4fc30:	mov    rdx,rax
   4fc33:	xor    eax,eax
   4fc35:	call   4fc3a <sqlite3VdbeExec+0x79a>
   4fc3a:	mov    rdi,QWORD PTR [rsp+0x190]
   4fc42:	jmp    4fced <sqlite3VdbeExec+0x84d>
   4fc47:	cmp    WORD PTR [rbp+0x2],0x0
   4fc4c:	je     4fcc5 <sqlite3VdbeExec+0x825>
   4fc4e:	lea    rax,[rip+0x0]        # 4fc55 <sqlite3VdbeExec+0x7b5>
   4fc55:	lea    rcx,[rip+0x0]        # 4fc5c <sqlite3VdbeExec+0x7bc>
   4fc5c:	movzx  edx,WORD PTR [rbp+0x2]
   4fc60:	add    rdx,0xffffffffffffffff
   4fc64:	mov    rcx,QWORD PTR [rcx+rdx*8]
   4fc68:	mov    QWORD PTR [rsp+0x190],rdi
   4fc70:	mov    rsi,rax
   4fc73:	mov    rdx,rcx
   4fc76:	xor    eax,eax
   4fc78:	call   4fc7d <sqlite3VdbeExec+0x7dd>
   4fc7d:	mov    rdi,QWORD PTR [rsp+0x190]
   4fc85:	cmp    QWORD PTR [rbp+0x10],0x0
   4fc8a:	je     4fced <sqlite3VdbeExec+0x84d>
   4fc8c:	lea    rax,[rip+0x0]        # 4fc93 <sqlite3VdbeExec+0x7f3>
   4fc93:	mov    rcx,QWORD PTR [rdi+0xa8]
   4fc9a:	mov    rdx,QWORD PTR [rbp+0x10]
   4fc9e:	mov    rdi,r14
   4fca1:	mov    rsi,rax
   4fca4:	mov    r11,rdx
   4fca7:	mov    rdx,rcx
   4fcaa:	mov    rcx,r11
   4fcad:	xor    eax,eax
   4fcaf:	call   4fcb4 <sqlite3VdbeExec+0x814>
   4fcb4:	mov    rdi,QWORD PTR [rsp+0x190]
   4fcbc:	mov    QWORD PTR [rdi+0xa8],rax
   4fcc3:	jmp    4fced <sqlite3VdbeExec+0x84d>
   4fcc5:	lea    rax,[rip+0x0]        # 4fccc <sqlite3VdbeExec+0x82c>
   4fccc:	mov    rcx,QWORD PTR [rbp+0x10]
   4fcd0:	mov    QWORD PTR [rsp+0x190],rdi
   4fcd8:	mov    rsi,rax
   4fcdb:	mov    rdx,rcx
   4fcde:	xor    eax,eax
   4fce0:	call   4fce5 <sqlite3VdbeExec+0x845>
   4fce5:	mov    rdi,QWORD PTR [rsp+0x190]
   4fced:	mov    eax,DWORD PTR [rbp+0x4]
   4fcf0:	mov    QWORD PTR [rsp+0x190],rdi
   4fcf8:	mov    rsi,rax
   4fcfb:	mov    rdx,rbp
   4fcfe:	mov    rcx,r13
   4fd01:	call   4fd06 <sqlite3VdbeExec+0x866>
   4fd06:	mov    rdi,QWORD PTR [rsp+0x190]
   4fd0e:	mov    QWORD PTR [rsp+0x190],rdi
   4fd16:	call   4fd1b <sqlite3VdbeExec+0x87b>
   4fd1b:	mov    ebx,eax
   4fd1d:	mov    rdi,QWORD PTR [rsp+0x190]
   4fd25:	cmp    ebx,0x5
   4fd28:	jne    4fd33 <sqlite3VdbeExec+0x893>
   4fd2a:	mov    DWORD PTR [rdi+0x34],0x5
   4fd31:	jmp    4fd45 <sqlite3VdbeExec+0x8a5>
   4fd33:	cmp    DWORD PTR [rdi+0x34],0x0
   4fd37:	je     4fd40 <sqlite3VdbeExec+0x8a0>
   4fd39:	mov    ebx,0x1
   4fd3e:	jmp    4fd45 <sqlite3VdbeExec+0x8a5>
   4fd40:	mov    ebx,0x65
   4fd45:	mov    QWORD PTR [rsp+0x1d0],r13
   4fd4d:	mov    r12,rbx
   4fd50:	mov    r13d,DWORD PTR [rsp+0x400]
   4fd58:	mov    r15,QWORD PTR [rsp+0x1b0]
   4fd60:	mov    rbx,QWORD PTR [rsp+0x1d8]
   4fd68:	jmp    6c449 <sqlite3VdbeExec+0x1cfa9>
   4fd6d:	mov    r15d,DWORD PTR [rsp+0x3fc]
   4fd75:	mov    r13,QWORD PTR [rsp+0x1d0]
   4fd7d:	mov    QWORD PTR [rsp+0x1b0],r12
   4fd85:	mov    r12d,DWORD PTR [rsp+0x414]
   4fd8d:	mov    rax,QWORD PTR [rdi+0x68]
   4fd91:	movsxd rcx,DWORD PTR [rbp+0x8]
   4fd95:	imul   rcx,rcx,0x38
   4fd99:	lea    rdx,[rax+rcx*1]
   4fd9d:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   4fda2:	and    eax,0x9000
   4fda7:	test   eax,eax
   4fda9:	je     4fdf4 <sqlite3VdbeExec+0x954>
   4fdab:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   4fdb6:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   4fdc1:	mov    QWORD PTR [rsp+0x190],rdi
   4fdc9:	mov    rdi,rdx
   4fdcc:	call   4fdd1 <sqlite3VdbeExec+0x931>
   4fdd1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   4fddc:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   4fde7:	mov    rdi,QWORD PTR [rsp+0x190]
   4fdef:	mov    rdx,rax
   4fdf2:	jmp    4fdfa <sqlite3VdbeExec+0x95a>
   4fdf4:	mov    WORD PTR [rdx+0x14],0x4
   4fdfa:	movsxd rax,DWORD PTR [rbp+0x4]
   4fdfe:	mov    QWORD PTR [rdx],rax
   4fe01:	mov    DWORD PTR [rsp+0x3fc],r15d
   4fe09:	mov    QWORD PTR [rsp+0x1d0],r13
   4fe11:	mov    DWORD PTR [rsp+0x414],r12d
   4fe19:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   4fe1e:	mov    r15d,DWORD PTR [rsp+0x3fc]
   4fe26:	mov    r13,QWORD PTR [rsp+0x1d0]
   4fe2e:	mov    QWORD PTR [rsp+0x1b0],r12
   4fe36:	mov    r12d,DWORD PTR [rsp+0x414]
   4fe3e:	mov    rax,QWORD PTR [rdi+0x68]
   4fe42:	movsxd rcx,DWORD PTR [rbp+0x8]
   4fe46:	imul   rcx,rcx,0x38
   4fe4a:	lea    rdx,[rax+rcx*1]
   4fe4e:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   4fe53:	and    eax,0x9000
   4fe58:	test   eax,eax
   4fe5a:	je     4fea5 <sqlite3VdbeExec+0xa05>
   4fe5c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   4fe67:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   4fe72:	mov    QWORD PTR [rsp+0x190],rdi
   4fe7a:	mov    rdi,rdx
   4fe7d:	call   4fe82 <sqlite3VdbeExec+0x9e2>
   4fe82:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   4fe8d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   4fe98:	mov    rdi,QWORD PTR [rsp+0x190]
   4fea0:	mov    rdx,rax
   4fea3:	jmp    4feab <sqlite3VdbeExec+0xa0b>
   4fea5:	mov    WORD PTR [rdx+0x14],0x4
   4feab:	mov    rax,QWORD PTR [rbp+0x10]
   4feaf:	mov    rax,QWORD PTR [rax]
   4feb2:	mov    QWORD PTR [rdx],rax
   4feb5:	mov    DWORD PTR [rsp+0x3fc],r15d
   4febd:	mov    QWORD PTR [rsp+0x1d0],r13
   4fec5:	mov    DWORD PTR [rsp+0x414],r12d
   4fecd:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   4fed2:	mov    r15d,DWORD PTR [rsp+0x3fc]
   4feda:	mov    r13,QWORD PTR [rsp+0x1d0]
   4fee2:	mov    QWORD PTR [rsp+0x1b0],r12
   4feea:	mov    r12d,DWORD PTR [rsp+0x414]
   4fef2:	mov    rax,QWORD PTR [rdi+0x68]
   4fef6:	movsxd rcx,DWORD PTR [rbp+0x8]
   4fefa:	imul   rcx,rcx,0x38
   4fefe:	lea    rdx,[rax+rcx*1]
   4ff02:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   4ff07:	and    eax,0x9000
   4ff0c:	test   eax,eax
   4ff0e:	je     4ff59 <sqlite3VdbeExec+0xab9>
   4ff10:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   4ff1b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   4ff26:	mov    QWORD PTR [rsp+0x190],rdi
   4ff2e:	mov    rdi,rdx
   4ff31:	call   4ff36 <sqlite3VdbeExec+0xa96>
   4ff36:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   4ff41:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   4ff4c:	mov    rdi,QWORD PTR [rsp+0x190]
   4ff54:	mov    rdx,rax
   4ff57:	jmp    4ff5f <sqlite3VdbeExec+0xabf>
   4ff59:	mov    WORD PTR [rdx+0x14],0x4
   4ff5f:	mov    WORD PTR [rdx+0x14],0x8
   4ff65:	mov    rax,QWORD PTR [rbp+0x10]
   4ff69:	movsd  xmm2,QWORD PTR [rax]
   4ff6d:	movsd  QWORD PTR [rdx],xmm2
   4ff71:	mov    DWORD PTR [rsp+0x3fc],r15d
   4ff79:	mov    QWORD PTR [rsp+0x1d0],r13
   4ff81:	mov    DWORD PTR [rsp+0x414],r12d
   4ff89:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   4ff8e:	mov    r15d,DWORD PTR [rsp+0x3fc]
   4ff96:	mov    r13,QWORD PTR [rsp+0x1d0]
   4ff9e:	mov    QWORD PTR [rsp+0x1b0],r12
   4ffa6:	mov    r12d,DWORD PTR [rsp+0x414]
   4ffae:	mov    rax,QWORD PTR [rdi+0x68]
   4ffb2:	movsxd rcx,DWORD PTR [rbp+0x8]
   4ffb6:	imul   rcx,rcx,0x38
   4ffba:	mov    DWORD PTR [rsp+0x414],r12d
   4ffc2:	lea    r12,[rax+rcx*1]
   4ffc6:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   4ffcb:	and    eax,0x9000
   4ffd0:	test   eax,eax
   4ffd2:	je     5001d <sqlite3VdbeExec+0xb7d>
   4ffd4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   4ffdf:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   4ffea:	mov    QWORD PTR [rsp+0x190],rdi
   4fff2:	mov    rdi,r12
   4fff5:	call   4fffa <sqlite3VdbeExec+0xb5a>
   4fffa:	mov    r12,rax
   4fffd:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50008:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50013:	mov    rdi,QWORD PTR [rsp+0x190]
   5001b:	jmp    50025 <sqlite3VdbeExec+0xb85>
   5001d:	mov    WORD PTR [r12+0x14],0x4
   50025:	mov    rax,QWORD PTR [rbp+0x10]
   50029:	test   rax,rax
   5002c:	jne    50032 <sqlite3VdbeExec+0xb92>
   5002e:	xor    eax,eax
   50030:	jmp    5007b <sqlite3VdbeExec+0xbdb>
   50032:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5003d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50048:	mov    QWORD PTR [rsp+0x190],rdi
   50050:	mov    rdi,rax
   50053:	call   50058 <sqlite3VdbeExec+0xbb8>
   50058:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50063:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5006e:	and    eax,0x3fffffff
   50073:	mov    rdi,QWORD PTR [rsp+0x190]
   5007b:	mov    DWORD PTR [rbp+0x4],eax
   5007e:	mov    eax,r15d
   50081:	cmp    eax,0x1
   50084:	jne    50093 <sqlite3VdbeExec+0xbf3>
   50086:	mov    QWORD PTR [rsp+0x1d0],r13
   5008e:	jmp    501bb <sqlite3VdbeExec+0xd1b>
   50093:	mov    rax,QWORD PTR [rbp+0x10]
   50097:	mov    rcx,0xffffffffffffffff
   5009e:	xor    edx,edx
   500a0:	mov    esi,0x1
   500a5:	mov    QWORD PTR [rsp+0x1d0],r13
   500ad:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   500b8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   500c3:	mov    QWORD PTR [rsp+0x190],rdi
   500cb:	mov    rdi,r12
   500ce:	mov    r8,rdx
   500d1:	mov    rdx,rcx
   500d4:	mov    rcx,rsi
   500d7:	mov    rsi,rax
   500da:	call   500df <sqlite3VdbeExec+0xc3f>
   500df:	mov    r13d,eax
   500e2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   500ed:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   500f8:	mov    rdi,QWORD PTR [rsp+0x190]
   50100:	test   r13d,r13d
   50103:	je     50115 <sqlite3VdbeExec+0xc75>
   50105:	mov    QWORD PTR [rsp+0x1c8],rbp
   5010d:	mov    rbp,r14
   50110:	jmp    54d59 <sqlite3VdbeExec+0x58b9>
   50115:	mov    eax,r15d
   50118:	movzx  ecx,WORD PTR [r12+0x14]
   5011e:	and    ecx,0x2
   50121:	test   ecx,ecx
   50123:	jne    50249 <sqlite3VdbeExec+0xda9>
   50129:	mov    BYTE PTR [r12+0x16],al
   5012e:	mov    DWORD PTR [r12+0x20],0x0
   50137:	movzx  eax,WORD PTR [r12+0x14]
   5013d:	or     eax,0x2000
   50142:	mov    WORD PTR [r12+0x14],ax
   50148:	cmp    BYTE PTR [rbp+0x1],0xf9
   5014c:	jne    5019e <sqlite3VdbeExec+0xcfe>
   5014e:	mov    rax,QWORD PTR [rbp+0x10]
   50152:	test   rax,rax
   50155:	je     5019e <sqlite3VdbeExec+0xcfe>
   50157:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50162:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5016d:	mov    QWORD PTR [rsp+0x190],rdi
   50175:	mov    rdi,r14
   50178:	mov    rsi,rax
   5017b:	call   50180 <sqlite3VdbeExec+0xce0>
   50180:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5018b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50196:	mov    rdi,QWORD PTR [rsp+0x190]
   5019e:	mov    BYTE PTR [rbp+0x1],0xf9
   501a2:	mov    rax,QWORD PTR [r12+0x8]
   501a7:	mov    QWORD PTR [rbp+0x10],rax
   501ab:	mov    eax,DWORD PTR [r12+0x10]
   501b0:	mov    DWORD PTR [rbp+0x4],eax
   501b3:	mov    DWORD PTR [rsp+0x40c],r13d
   501bb:	mov    eax,DWORD PTR [rbp+0x4]
   501be:	cmp    eax,DWORD PTR [r14+0x88]
   501c5:	jle    501d7 <sqlite3VdbeExec+0xd37>
   501c7:	mov    QWORD PTR [rsp+0x1c8],rbp
   501cf:	mov    rbp,r14
   501d2:	jmp    54d59 <sqlite3VdbeExec+0x58b9>
   501d7:	mov    BYTE PTR [rbp+0x0],0x4b
   501db:	mov    rax,QWORD PTR [rdi+0x68]
   501df:	movsxd rcx,DWORD PTR [rbp+0x8]
   501e3:	imul   rcx,rcx,0x38
   501e7:	lea    rdx,[rax+rcx*1]
   501eb:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   501f0:	and    eax,0x9000
   501f5:	test   eax,eax
   501f7:	je     502d3 <sqlite3VdbeExec+0xe33>
   501fd:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50208:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50213:	mov    QWORD PTR [rsp+0x190],rdi
   5021b:	mov    rdi,rdx
   5021e:	call   50223 <sqlite3VdbeExec+0xd83>
   50223:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5022e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50239:	mov    rdi,QWORD PTR [rsp+0x190]
   50241:	mov    rdx,rax
   50244:	jmp    502d9 <sqlite3VdbeExec+0xe39>
   50249:	movzx  ecx,BYTE PTR [r12+0x16]
   5024f:	cmp    ecx,eax
   50251:	je     5012e <sqlite3VdbeExec+0xc8e>
   50257:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50262:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5026d:	mov    rdi,r12
   50270:	mov    rsi,rax
   50273:	call   50278 <sqlite3VdbeExec+0xdd8>
   50278:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50283:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5028e:	mov    rdi,QWORD PTR [rsp+0x190]
   50296:	mov    QWORD PTR [rsp+0x1a8],r14
   5029e:	xor    r14d,r14d
   502a1:	cmp    r14d,eax
   502a4:	jne    502b3 <sqlite3VdbeExec+0xe13>
   502a6:	mov    r14,QWORD PTR [rsp+0x1a8]
   502ae:	jmp    5012e <sqlite3VdbeExec+0xc8e>
   502b3:	mov    r14,QWORD PTR [rsp+0x1a8]
   502bb:	mov    r13,QWORD PTR [rsp+0x1d0]
   502c3:	mov    rbx,rbp
   502c6:	mov    rbp,QWORD PTR [rsp+0x1d8]
   502ce:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   502d3:	mov    WORD PTR [rdx+0x14],0x4
   502d9:	mov    WORD PTR [rdx+0x14],0x2202
   502df:	mov    rax,QWORD PTR [rbp+0x10]
   502e3:	mov    QWORD PTR [rdx+0x8],rax
   502e7:	mov    eax,DWORD PTR [rbp+0x4]
   502ea:	mov    DWORD PTR [rdx+0x10],eax
   502ed:	mov    BYTE PTR [rdx+0x16],r15b
   502f1:	cmp    DWORD PTR [rbp+0xc],0x0
   502f5:	jle    50312 <sqlite3VdbeExec+0xe72>
   502f7:	movsxd rax,DWORD PTR [rbp+0xc]
   502fb:	imul   rax,rax,0x38
   502ff:	mov    rax,QWORD PTR [rbx+rax*1]
   50303:	movzx  ecx,WORD PTR [rbp+0x2]
   50307:	cmp    rax,rcx
   5030a:	jne    50312 <sqlite3VdbeExec+0xe72>
   5030c:	mov    WORD PTR [rdx+0x14],0x2210
   50312:	mov    DWORD PTR [rsp+0x3fc],r15d
   5031a:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5031f:	mov    r15d,DWORD PTR [rsp+0x3fc]
   50327:	mov    r13,QWORD PTR [rsp+0x1d0]
   5032f:	mov    QWORD PTR [rsp+0x1b0],r12
   50337:	mov    r12d,DWORD PTR [rsp+0x414]
   5033f:	mov    rax,QWORD PTR [rdi+0x68]
   50343:	movsxd rcx,DWORD PTR [rbp+0x8]
   50347:	imul   rcx,rcx,0x38
   5034b:	mov    DWORD PTR [rsp+0x414],r12d
   50353:	lea    r12,[rax+rcx*1]
   50357:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5035c:	and    eax,0x9000
   50361:	test   eax,eax
   50363:	je     503ae <sqlite3VdbeExec+0xf0e>
   50365:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50370:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5037b:	mov    QWORD PTR [rsp+0x190],rdi
   50383:	mov    rdi,r12
   50386:	call   5038b <sqlite3VdbeExec+0xeeb>
   5038b:	mov    r12,rax
   5038e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50399:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   503a4:	mov    rdi,QWORD PTR [rsp+0x190]
   503ac:	jmp    503b6 <sqlite3VdbeExec+0xf16>
   503ae:	mov    WORD PTR [r12+0x14],0x4
   503b6:	mov    eax,DWORD PTR [rbp+0xc]
   503b9:	mov    QWORD PTR [rsp+0x1e8],r12
   503c1:	mov    r12d,eax
   503c4:	sub    r12d,DWORD PTR [rbp+0x8]
   503c8:	cmp    DWORD PTR [rbp+0x4],0x0
   503cc:	je     503de <sqlite3VdbeExec+0xf3e>
   503ce:	mov    DWORD PTR [rsp+0x418],r12d
   503d6:	mov    r12d,0x101
   503dc:	jmp    503ec <sqlite3VdbeExec+0xf4c>
   503de:	mov    DWORD PTR [rsp+0x418],r12d
   503e6:	mov    r12d,0x1
   503ec:	mov    QWORD PTR [rsp+0x1d0],r13
   503f4:	mov    r13,QWORD PTR [rsp+0x1e8]
   503fc:	mov    WORD PTR [r13+0x14],r12w
   50401:	mov    DWORD PTR [r13+0x10],0x0
   50409:	mov    DWORD PTR [rsp+0x3fc],r15d
   50411:	mov    r15,r13
   50414:	mov    r13d,DWORD PTR [rsp+0x418]
   5041c:	jmp    50441 <sqlite3VdbeExec+0xfa1>
   5041e:	mov    r15,r14
   50421:	mov    r14,QWORD PTR [rsp+0x1a8]
   50429:	mov    WORD PTR [r15+0x14],0x1
   50430:	mov    WORD PTR [r15+0x14],r12w
   50435:	mov    DWORD PTR [r15+0x10],0x0
   5043d:	sub    r13d,0x1
   50441:	test   r13d,r13d
   50444:	jle    504b4 <sqlite3VdbeExec+0x1014>
   50446:	mov    QWORD PTR [rsp+0x1a8],r14
   5044e:	lea    r14,[r15+0x38]
   50452:	movzx  eax,WORD PTR [r15+0x4c]
   50457:	and    eax,0x9000
   5045c:	test   eax,eax
   5045e:	je     5041e <sqlite3VdbeExec+0xf7e>
   50460:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5046b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50476:	mov    QWORD PTR [rsp+0x190],rdi
   5047e:	mov    rdi,r14
   50481:	call   50486 <sqlite3VdbeExec+0xfe6>
   50486:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50491:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5049c:	mov    rdi,QWORD PTR [rsp+0x190]
   504a4:	mov    r15,r14
   504a7:	mov    r14,QWORD PTR [rsp+0x1a8]
   504af:	jmp    50430 <sqlite3VdbeExec+0xf90>
   504b4:	mov    QWORD PTR [rsp+0x1a8],r14
   504bc:	mov    r14,QWORD PTR [rsp+0x1a8]
   504c4:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   504c9:	mov    QWORD PTR [rsp+0x1a8],r14
   504d1:	mov    QWORD PTR [rsp+0x1b0],r12
   504d9:	movsxd rax,DWORD PTR [rbp+0x4]
   504dd:	imul   rax,rax,0x38
   504e1:	movzx  ecx,WORD PTR [rbx+rax*1+0x14]
   504e6:	and    ecx,0xffffffc0
   504e9:	or     ecx,0x1
   504ec:	mov    WORD PTR [rbx+rax*1+0x14],cx
   504f1:	mov    r14,QWORD PTR [rsp+0x1a8]
   504f9:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   504fe:	mov    QWORD PTR [rsp+0x1a8],r14
   50506:	mov    QWORD PTR [rsp+0x1b0],r12
   5050e:	mov    rax,QWORD PTR [rdi+0x68]
   50512:	movsxd rcx,DWORD PTR [rbp+0x8]
   50516:	imul   rcx,rcx,0x38
   5051a:	lea    r12,[rax+rcx*1]
   5051e:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   50523:	and    eax,0x9000
   50528:	test   eax,eax
   5052a:	je     50575 <sqlite3VdbeExec+0x10d5>
   5052c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50537:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50542:	mov    QWORD PTR [rsp+0x190],rdi
   5054a:	mov    rdi,r12
   5054d:	call   50552 <sqlite3VdbeExec+0x10b2>
   50552:	mov    r12,rax
   50555:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50560:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5056b:	mov    rdi,QWORD PTR [rsp+0x190]
   50573:	jmp    5057d <sqlite3VdbeExec+0x10dd>
   50575:	mov    WORD PTR [r12+0x14],0x4
   5057d:	cmp    QWORD PTR [rbp+0x10],0x0
   50582:	jne    50731 <sqlite3VdbeExec+0x1291>
   50588:	mov    r13d,DWORD PTR [rbp+0x4]
   5058c:	movzx  eax,WORD PTR [r12+0x14]
   50592:	and    eax,0x9000
   50597:	test   eax,eax
   50599:	jne    505a3 <sqlite3VdbeExec+0x1103>
   5059b:	cmp    DWORD PTR [r12+0x20],0x0
   505a1:	je     505e7 <sqlite3VdbeExec+0x1147>
   505a3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   505ae:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   505b9:	mov    QWORD PTR [rsp+0x190],rdi
   505c1:	mov    rdi,r12
   505c4:	call   505c9 <sqlite3VdbeExec+0x1129>
   505c9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   505d4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   505df:	mov    rdi,QWORD PTR [rsp+0x190]
   505e7:	mov    WORD PTR [r12+0x14],0x410
   505ef:	mov    DWORD PTR [r12+0x10],0x0
   505f8:	xor    eax,eax
   505fa:	test   r13d,r13d
   505fd:	cmovge eax,r13d
   50601:	mov    DWORD PTR [r12],eax
   50605:	mov    BYTE PTR [r12+0x16],0x1
   5060b:	mov    QWORD PTR [r12+0x8],0x0
   50614:	mov    eax,DWORD PTR [r12+0x10]
   50619:	add    eax,DWORD PTR [r12]
   5061d:	test   eax,eax
   5061f:	jg     50640 <sqlite3VdbeExec+0x11a0>
   50621:	movzx  eax,WORD PTR [r12+0x14]
   50627:	and    eax,0x10
   5062a:	test   eax,eax
   5062c:	jne    5063b <sqlite3VdbeExec+0x119b>
   5062e:	mov    r15d,DWORD PTR [rsp+0x3fc]
   50636:	jmp    50795 <sqlite3VdbeExec+0x12f5>
   5063b:	mov    eax,0x1
   50640:	mov    ecx,0x1
   50645:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50650:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5065b:	mov    QWORD PTR [rsp+0x190],rdi
   50663:	mov    rdi,r12
   50666:	mov    rsi,rax
   50669:	mov    rdx,rcx
   5066c:	call   50671 <sqlite3VdbeExec+0x11d1>
   50671:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5067c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50687:	mov    rdi,QWORD PTR [rsp+0x190]
   5068f:	test   eax,eax
   50691:	jne    50711 <sqlite3VdbeExec+0x1271>
   50693:	mov    rax,QWORD PTR [r12+0x8]
   50698:	movsxd rcx,DWORD PTR [r12+0x10]
   5069d:	add    rax,rcx
   506a0:	xor    ecx,ecx
   506a2:	movsxd rdx,DWORD PTR [r12]
   506a6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   506b1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   506bc:	mov    rdi,rax
   506bf:	mov    rsi,rcx
   506c2:	call   506c7 <sqlite3VdbeExec+0x1227>
   506c7:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   506d2:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   506dd:	mov    eax,DWORD PTR [r12+0x10]
   506e2:	add    eax,DWORD PTR [r12]
   506e6:	mov    DWORD PTR [r12+0x10],eax
   506eb:	movzx  eax,WORD PTR [r12+0x14]
   506f1:	and    eax,0xfffff9ff
   506f6:	mov    WORD PTR [r12+0x14],ax
   506fc:	mov    rdi,QWORD PTR [rsp+0x190]
   50704:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5070c:	jmp    50795 <sqlite3VdbeExec+0x12f5>
   50711:	mov    r14,QWORD PTR [rsp+0x1a8]
   50719:	mov    r13,QWORD PTR [rsp+0x1d0]
   50721:	mov    rbx,rbp
   50724:	mov    rbp,QWORD PTR [rsp+0x1d8]
   5072c:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50731:	mov    r15d,DWORD PTR [rsp+0x3fc]
   50739:	mov    rax,QWORD PTR [rbp+0x10]
   5073d:	movsxd rcx,DWORD PTR [rbp+0x4]
   50741:	xor    edx,edx
   50743:	xor    esi,esi
   50745:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50750:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5075b:	mov    QWORD PTR [rsp+0x190],rdi
   50763:	mov    rdi,r12
   50766:	mov    r8,rdx
   50769:	mov    rdx,rcx
   5076c:	mov    rcx,rsi
   5076f:	mov    rsi,rax
   50772:	call   50777 <sqlite3VdbeExec+0x12d7>
   50777:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50782:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5078d:	mov    rdi,QWORD PTR [rsp+0x190]
   50795:	mov    BYTE PTR [r12+0x16],r15b
   5079a:	mov    r14,QWORD PTR [rsp+0x1a8]
   507a2:	mov    DWORD PTR [rsp+0x3fc],r15d
   507aa:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   507af:	mov    QWORD PTR [rsp+0x1a8],r14
   507b7:	mov    r15d,DWORD PTR [rsp+0x3fc]
   507bf:	mov    QWORD PTR [rsp+0x1b0],r12
   507c7:	mov    r12,QWORD PTR [rdi+0x80]
   507ce:	mov    eax,DWORD PTR [rbp+0x4]
   507d1:	sub    eax,0x1
   507d4:	movsxd rax,eax
   507d7:	imul   r13,rax,0x38
   507db:	movzx  eax,WORD PTR [r12+r13*1+0x14]
   507e1:	and    eax,0x12
   507e4:	test   eax,eax
   507e6:	je     50823 <sqlite3VdbeExec+0x1383>
   507e8:	mov    eax,DWORD PTR [r12+r13*1+0x10]
   507ed:	movzx  ecx,WORD PTR [r12+r13*1+0x14]
   507f3:	and    ecx,0x400
   507f9:	test   ecx,ecx
   507fb:	je     50801 <sqlite3VdbeExec+0x1361>
   507fd:	add    eax,DWORD PTR [r12+r13*1]
   50801:	mov    rcx,QWORD PTR [r12+r13*1+0x18]
   50806:	cmp    eax,DWORD PTR [rcx+0x88]
   5080c:	jle    50823 <sqlite3VdbeExec+0x1383>
   5080e:	mov    QWORD PTR [rsp+0x1c8],rbp
   50816:	mov    rbp,QWORD PTR [rsp+0x1a8]
   5081e:	jmp    54d59 <sqlite3VdbeExec+0x58b9>
   50823:	movsxd rax,DWORD PTR [rbp+0x8]
   50827:	imul   rax,rax,0x38
   5082b:	lea    r14,[rbx+rax*1]
   5082f:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   50834:	and    eax,0x9000
   50839:	test   eax,eax
   5083b:	je     50898 <sqlite3VdbeExec+0x13f8>
   5083d:	movzx  eax,WORD PTR [r14+0x14]
   50842:	and    eax,0x9000
   50847:	test   eax,eax
   50849:	je     50891 <sqlite3VdbeExec+0x13f1>
   5084b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50856:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50861:	mov    QWORD PTR [rsp+0x190],rdi
   50869:	mov    rdi,r14
   5086c:	call   50871 <sqlite3VdbeExec+0x13d1>
   50871:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5087c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50887:	mov    rdi,QWORD PTR [rsp+0x190]
   5088f:	jmp    50898 <sqlite3VdbeExec+0x13f8>
   50891:	mov    WORD PTR [r14+0x14],0x1
   50898:	mov    rax,QWORD PTR [r12+r13*1]
   5089c:	mov    QWORD PTR [r14],rax
   5089f:	mov    rax,QWORD PTR [r12+r13*1+0x8]
   508a4:	mov    QWORD PTR [r14+0x8],rax
   508a8:	mov    rax,QWORD PTR [r12+r13*1+0x10]
   508ad:	mov    QWORD PTR [r14+0x10],rax
   508b1:	movzx  eax,WORD PTR [r14+0x14]
   508b6:	and    eax,0xffffafff
   508bb:	mov    WORD PTR [r14+0x14],ax
   508c0:	movzx  eax,WORD PTR [r14+0x14]
   508c5:	or     eax,0x2040
   508ca:	mov    WORD PTR [r14+0x14],ax
   508cf:	mov    r14,QWORD PTR [rsp+0x1a8]
   508d7:	mov    DWORD PTR [rsp+0x3fc],r15d
   508df:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   508e4:	mov    QWORD PTR [rsp+0x1a8],r14
   508ec:	mov    r15d,DWORD PTR [rsp+0x3fc]
   508f4:	mov    QWORD PTR [rsp+0x1b0],r12
   508fc:	mov    r12d,DWORD PTR [rbp+0xc]
   50900:	movsxd rax,DWORD PTR [rbp+0x4]
   50904:	imul   rax,rax,0x38
   50908:	lea    r13,[rbx+rax*1]
   5090c:	movsxd rax,DWORD PTR [rbp+0x8]
   50910:	imul   rax,rax,0x38
   50914:	lea    r14,[rbx+rax*1]
   50918:	movzx  eax,WORD PTR [r14+0x14]
   5091d:	and    eax,0x9000
   50922:	test   eax,eax
   50924:	jne    5092d <sqlite3VdbeExec+0x148d>
   50926:	cmp    DWORD PTR [r14+0x20],0x0
   5092b:	je     50971 <sqlite3VdbeExec+0x14d1>
   5092d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50938:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50943:	mov    QWORD PTR [rsp+0x190],rdi
   5094b:	mov    rdi,r14
   5094e:	call   50953 <sqlite3VdbeExec+0x14b3>
   50953:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5095e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50969:	mov    rdi,QWORD PTR [rsp+0x190]
   50971:	mov    eax,0x38
   50976:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50981:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5098c:	mov    QWORD PTR [rsp+0x190],rdi
   50994:	mov    rdi,r14
   50997:	mov    rsi,r13
   5099a:	mov    rdx,rax
   5099d:	call   509a2 <sqlite3VdbeExec+0x1502>
   509a2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   509ad:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   509b8:	mov    WORD PTR [r13+0x14],0x1
   509bf:	mov    DWORD PTR [r13+0x20],0x0
   509c7:	movzx  eax,WORD PTR [r14+0x14]
   509cc:	and    eax,0x4000
   509d1:	mov    rdi,QWORD PTR [rsp+0x190]
   509d9:	test   eax,eax
   509db:	je     50b6f <sqlite3VdbeExec+0x16cf>
   509e1:	movzx  eax,WORD PTR [r14+0x14]
   509e6:	and    eax,0x12
   509e9:	test   eax,eax
   509eb:	je     50b60 <sqlite3VdbeExec+0x16c0>
   509f1:	movzx  eax,WORD PTR [r14+0x14]
   509f6:	and    eax,0x400
   509fb:	test   eax,eax
   509fd:	je     50ae3 <sqlite3VdbeExec+0x1643>
   50a03:	mov    eax,DWORD PTR [r14+0x10]
   50a07:	add    eax,DWORD PTR [r14]
   50a0a:	test   eax,eax
   50a0c:	jg     50a23 <sqlite3VdbeExec+0x1583>
   50a0e:	movzx  eax,WORD PTR [r14+0x14]
   50a13:	and    eax,0x10
   50a16:	test   eax,eax
   50a18:	je     50ae3 <sqlite3VdbeExec+0x1643>
   50a1e:	mov    eax,0x1
   50a23:	mov    ecx,0x1
   50a28:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50a33:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50a3e:	mov    QWORD PTR [rsp+0x190],rdi
   50a46:	mov    rdi,r14
   50a49:	mov    rsi,rax
   50a4c:	mov    rdx,rcx
   50a4f:	call   50a54 <sqlite3VdbeExec+0x15b4>
   50a54:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50a5f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50a6a:	mov    rdi,QWORD PTR [rsp+0x190]
   50a72:	test   eax,eax
   50a74:	jne    50b40 <sqlite3VdbeExec+0x16a0>
   50a7a:	mov    rax,QWORD PTR [r14+0x8]
   50a7e:	movsxd rcx,DWORD PTR [r14+0x10]
   50a82:	add    rax,rcx
   50a85:	xor    ecx,ecx
   50a87:	movsxd rdx,DWORD PTR [r14]
   50a8a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50a95:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50aa0:	mov    rdi,rax
   50aa3:	mov    rsi,rcx
   50aa6:	call   50aab <sqlite3VdbeExec+0x160b>
   50aab:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50ab6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50ac1:	mov    eax,DWORD PTR [r14+0x10]
   50ac5:	add    eax,DWORD PTR [r14]
   50ac8:	mov    DWORD PTR [r14+0x10],eax
   50acc:	movzx  eax,WORD PTR [r14+0x14]
   50ad1:	and    eax,0xfffff9ff
   50ad6:	mov    WORD PTR [r14+0x14],ax
   50adb:	mov    rdi,QWORD PTR [rsp+0x190]
   50ae3:	cmp    DWORD PTR [r14+0x20],0x0
   50ae8:	je     50af4 <sqlite3VdbeExec+0x1654>
   50aea:	mov    rax,QWORD PTR [r14+0x8]
   50aee:	cmp    rax,QWORD PTR [r14+0x28]
   50af2:	je     50b60 <sqlite3VdbeExec+0x16c0>
   50af4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50aff:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50b0a:	mov    QWORD PTR [rsp+0x190],rdi
   50b12:	mov    rdi,r14
   50b15:	call   50b1a <sqlite3VdbeExec+0x167a>
   50b1a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50b25:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50b30:	mov    rdi,QWORD PTR [rsp+0x190]
   50b38:	test   eax,eax
   50b3a:	je     50b60 <sqlite3VdbeExec+0x16c0>
   50b3c:	test   eax,eax
   50b3e:	je     50b6f <sqlite3VdbeExec+0x16cf>
   50b40:	mov    r14,QWORD PTR [rsp+0x1a8]
   50b48:	mov    r13,QWORD PTR [rsp+0x1d0]
   50b50:	mov    rbx,rbp
   50b53:	mov    rbp,QWORD PTR [rsp+0x1d8]
   50b5b:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50b60:	movzx  eax,WORD PTR [r14+0x14]
   50b65:	and    eax,0xffffbfff
   50b6a:	mov    WORD PTR [r14+0x14],ax
   50b6f:	add    r13,0x38
   50b73:	add    r14,0x38
   50b77:	sub    r12d,0x1
   50b7b:	test   r12d,r12d
   50b7e:	jne    50918 <sqlite3VdbeExec+0x1478>
   50b84:	mov    r14,QWORD PTR [rsp+0x1a8]
   50b8c:	mov    DWORD PTR [rsp+0x3fc],r15d
   50b94:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   50b99:	mov    QWORD PTR [rsp+0x1a8],r14
   50ba1:	mov    r15d,DWORD PTR [rsp+0x3fc]
   50ba9:	mov    QWORD PTR [rsp+0x1b0],r12
   50bb1:	mov    r12d,DWORD PTR [rbp+0xc]
   50bb5:	movsxd rax,DWORD PTR [rbp+0x4]
   50bb9:	imul   rax,rax,0x38
   50bbd:	lea    r13,[rbx+rax*1]
   50bc1:	movsxd rax,DWORD PTR [rbp+0x8]
   50bc5:	imul   rax,rax,0x38
   50bc9:	lea    r14,[rbx+rax*1]
   50bcd:	mov    r11,r12
   50bd0:	mov    r12,r13
   50bd3:	mov    r13,r11
   50bd6:	jmp    50e0f <sqlite3VdbeExec+0x196f>
   50bdb:	mov    rcx,QWORD PTR [r12]
   50bdf:	mov    QWORD PTR [r14],rcx
   50be2:	mov    rcx,QWORD PTR [r12+0x8]
   50be7:	mov    QWORD PTR [r14+0x8],rcx
   50beb:	mov    rcx,QWORD PTR [r12+0x10]
   50bf0:	mov    QWORD PTR [r14+0x10],rcx
   50bf4:	movzx  ecx,WORD PTR [r12+0x14]
   50bfa:	and    ecx,0x2000
   50c00:	test   ecx,ecx
   50c02:	jne    50c20 <sqlite3VdbeExec+0x1780>
   50c04:	movzx  ecx,WORD PTR [r14+0x14]
   50c09:	and    ecx,0xffff8fff
   50c0f:	mov    WORD PTR [r14+0x14],cx
   50c14:	movzx  ecx,WORD PTR [r14+0x14]
   50c19:	or     ecx,eax
   50c1b:	mov    WORD PTR [r14+0x14],cx
   50c20:	movzx  eax,WORD PTR [r14+0x14]
   50c25:	and    eax,0x4000
   50c2a:	test   eax,eax
   50c2c:	je     50dc0 <sqlite3VdbeExec+0x1920>
   50c32:	movzx  eax,WORD PTR [r14+0x14]
   50c37:	and    eax,0x12
   50c3a:	test   eax,eax
   50c3c:	je     50db1 <sqlite3VdbeExec+0x1911>
   50c42:	movzx  eax,WORD PTR [r14+0x14]
   50c47:	and    eax,0x400
   50c4c:	test   eax,eax
   50c4e:	je     50d34 <sqlite3VdbeExec+0x1894>
   50c54:	mov    eax,DWORD PTR [r14+0x10]
   50c58:	add    eax,DWORD PTR [r14]
   50c5b:	test   eax,eax
   50c5d:	jg     50c74 <sqlite3VdbeExec+0x17d4>
   50c5f:	movzx  eax,WORD PTR [r14+0x14]
   50c64:	and    eax,0x10
   50c67:	test   eax,eax
   50c69:	je     50d34 <sqlite3VdbeExec+0x1894>
   50c6f:	mov    eax,0x1
   50c74:	mov    ecx,0x1
   50c79:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50c84:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50c8f:	mov    QWORD PTR [rsp+0x190],rdi
   50c97:	mov    rdi,r14
   50c9a:	mov    rsi,rax
   50c9d:	mov    rdx,rcx
   50ca0:	call   50ca5 <sqlite3VdbeExec+0x1805>
   50ca5:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50cb0:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50cbb:	mov    rdi,QWORD PTR [rsp+0x190]
   50cc3:	test   eax,eax
   50cc5:	jne    50d91 <sqlite3VdbeExec+0x18f1>
   50ccb:	mov    rax,QWORD PTR [r14+0x8]
   50ccf:	movsxd rcx,DWORD PTR [r14+0x10]
   50cd3:	add    rax,rcx
   50cd6:	xor    ecx,ecx
   50cd8:	movsxd rdx,DWORD PTR [r14]
   50cdb:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50ce6:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50cf1:	mov    rdi,rax
   50cf4:	mov    rsi,rcx
   50cf7:	call   50cfc <sqlite3VdbeExec+0x185c>
   50cfc:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50d07:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50d12:	mov    eax,DWORD PTR [r14+0x10]
   50d16:	add    eax,DWORD PTR [r14]
   50d19:	mov    DWORD PTR [r14+0x10],eax
   50d1d:	movzx  eax,WORD PTR [r14+0x14]
   50d22:	and    eax,0xfffff9ff
   50d27:	mov    WORD PTR [r14+0x14],ax
   50d2c:	mov    rdi,QWORD PTR [rsp+0x190]
   50d34:	cmp    DWORD PTR [r14+0x20],0x0
   50d39:	je     50d45 <sqlite3VdbeExec+0x18a5>
   50d3b:	mov    rax,QWORD PTR [r14+0x8]
   50d3f:	cmp    rax,QWORD PTR [r14+0x28]
   50d43:	je     50db1 <sqlite3VdbeExec+0x1911>
   50d45:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50d50:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50d5b:	mov    QWORD PTR [rsp+0x190],rdi
   50d63:	mov    rdi,r14
   50d66:	call   50d6b <sqlite3VdbeExec+0x18cb>
   50d6b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50d76:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50d81:	mov    rdi,QWORD PTR [rsp+0x190]
   50d89:	test   eax,eax
   50d8b:	je     50db1 <sqlite3VdbeExec+0x1911>
   50d8d:	test   eax,eax
   50d8f:	je     50dc0 <sqlite3VdbeExec+0x1920>
   50d91:	mov    r14,QWORD PTR [rsp+0x1a8]
   50d99:	mov    r13,QWORD PTR [rsp+0x1d0]
   50da1:	mov    rbx,rbp
   50da4:	mov    rbp,QWORD PTR [rsp+0x1d8]
   50dac:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   50db1:	movzx  eax,WORD PTR [r14+0x14]
   50db6:	and    eax,0xffffbfff
   50dbb:	mov    WORD PTR [r14+0x14],ax
   50dc0:	movzx  eax,WORD PTR [r14+0x14]
   50dc5:	and    eax,0x800
   50dca:	test   eax,eax
   50dcc:	je     50de8 <sqlite3VdbeExec+0x1948>
   50dce:	movzx  eax,WORD PTR [rbp+0x2]
   50dd2:	and    eax,0x2
   50dd5:	test   eax,eax
   50dd7:	je     50de8 <sqlite3VdbeExec+0x1948>
   50dd9:	movzx  eax,WORD PTR [r14+0x14]
   50dde:	and    eax,0xfffff7ff
   50de3:	mov    WORD PTR [r14+0x14],ax
   50de8:	mov    DWORD PTR [rsp+0x3fc],r15d
   50df0:	mov    r15d,r13d
   50df3:	sub    r15d,0x1
   50df7:	test   r13d,r13d
   50dfa:	je     50e76 <sqlite3VdbeExec+0x19d6>
   50dfc:	add    r14,0x38
   50e00:	add    r12,0x38
   50e04:	mov    r13,r15
   50e07:	mov    r15d,DWORD PTR [rsp+0x3fc]
   50e0f:	mov    eax,0x4000
   50e14:	movzx  ecx,WORD PTR [r14+0x14]
   50e19:	and    ecx,0x9000
   50e1f:	test   ecx,ecx
   50e21:	je     50bdb <sqlite3VdbeExec+0x173b>
   50e27:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50e32:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50e3d:	mov    QWORD PTR [rsp+0x190],rdi
   50e45:	mov    rdi,r14
   50e48:	mov    rsi,r12
   50e4b:	mov    rdx,rax
   50e4e:	call   50e53 <sqlite3VdbeExec+0x19b3>
   50e53:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50e5e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50e69:	mov    rdi,QWORD PTR [rsp+0x190]
   50e71:	jmp    50c20 <sqlite3VdbeExec+0x1780>
   50e76:	mov    r15d,DWORD PTR [rsp+0x3fc]
   50e7e:	mov    r14,QWORD PTR [rsp+0x1a8]
   50e86:	mov    DWORD PTR [rsp+0x3fc],r15d
   50e8e:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   50e93:	mov    QWORD PTR [rsp+0x1a8],r14
   50e9b:	mov    r15d,DWORD PTR [rsp+0x3fc]
   50ea3:	mov    QWORD PTR [rsp+0x1b0],r12
   50eab:	movsxd rax,DWORD PTR [rbp+0x4]
   50eaf:	imul   rax,rax,0x38
   50eb3:	add    rax,rbx
   50eb6:	movsxd rcx,DWORD PTR [rbp+0x8]
   50eba:	imul   rcx,rcx,0x38
   50ebe:	lea    rdx,[rbx+rcx*1]
   50ec2:	mov    esi,0x4000
   50ec7:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   50ecc:	and    ecx,0x9000
   50ed2:	test   ecx,ecx
   50ed4:	je     50f22 <sqlite3VdbeExec+0x1a82>
   50ed6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50ee1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50eec:	mov    QWORD PTR [rsp+0x190],rdi
   50ef4:	mov    rdi,rdx
   50ef7:	mov    rdx,rsi
   50efa:	mov    rsi,rax
   50efd:	call   50f02 <sqlite3VdbeExec+0x1a62>
   50f02:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50f0d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50f18:	mov    rdi,QWORD PTR [rsp+0x190]
   50f20:	jmp    50f5f <sqlite3VdbeExec+0x1abf>
   50f22:	mov    rcx,QWORD PTR [rax]
   50f25:	mov    QWORD PTR [rdx],rcx
   50f28:	mov    rcx,QWORD PTR [rax+0x8]
   50f2c:	mov    QWORD PTR [rdx+0x8],rcx
   50f30:	mov    rcx,QWORD PTR [rax+0x10]
   50f34:	mov    QWORD PTR [rdx+0x10],rcx
   50f38:	movzx  eax,WORD PTR [rax+0x14]
   50f3c:	and    eax,0x2000
   50f41:	test   eax,eax
   50f43:	jne    50f5f <sqlite3VdbeExec+0x1abf>
   50f45:	movzx  eax,WORD PTR [rdx+0x14]
   50f49:	and    eax,0xffff8fff
   50f4e:	mov    WORD PTR [rdx+0x14],ax
   50f52:	movzx  eax,WORD PTR [rdx+0x14]
   50f56:	or     eax,0x4000
   50f5b:	mov    WORD PTR [rdx+0x14],ax
   50f5f:	mov    r14,QWORD PTR [rsp+0x1a8]
   50f67:	mov    DWORD PTR [rsp+0x3fc],r15d
   50f6f:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   50f74:	mov    QWORD PTR [rsp+0x1a8],r14
   50f7c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   50f84:	mov    QWORD PTR [rsp+0x1b0],r12
   50f8c:	movsxd rax,DWORD PTR [rbp+0x4]
   50f90:	imul   rax,rax,0x38
   50f94:	movsxd rcx,DWORD PTR [rbp+0x8]
   50f98:	imul   rcx,rcx,0x38
   50f9c:	lea    rdx,[rbx+rcx*1]
   50fa0:	mov    rax,QWORD PTR [rbx+rax*1]
   50fa4:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   50fa9:	and    ecx,0x9000
   50faf:	test   ecx,ecx
   50fb1:	je     50ffc <sqlite3VdbeExec+0x1b5c>
   50fb3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   50fbe:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   50fc9:	mov    QWORD PTR [rsp+0x190],rdi
   50fd1:	mov    rdi,rdx
   50fd4:	mov    rsi,rax
   50fd7:	call   50fdc <sqlite3VdbeExec+0x1b3c>
   50fdc:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   50fe7:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   50ff2:	mov    rdi,QWORD PTR [rsp+0x190]
   50ffa:	jmp    51005 <sqlite3VdbeExec+0x1b65>
   50ffc:	mov    QWORD PTR [rdx],rax
   50fff:	mov    WORD PTR [rdx+0x14],0x4
   51005:	mov    r14,QWORD PTR [rsp+0x1a8]
   5100d:	mov    DWORD PTR [rsp+0x3fc],r15d
   51015:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5101a:	mov    QWORD PTR [rsp+0x1a8],r14
   51022:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5102a:	mov    QWORD PTR [rsp+0x1b0],r12
   51032:	cmp    QWORD PTR [rdi+0x50],0x0
   51037:	jne    5103e <sqlite3VdbeExec+0x1b9e>
   51039:	xor    r12d,r12d
   5103c:	jmp    51082 <sqlite3VdbeExec+0x1be2>
   5103e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   51049:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   51054:	mov    QWORD PTR [rsp+0x190],rdi
   5105c:	call   51061 <sqlite3VdbeExec+0x1bc1>
   51061:	mov    r12d,eax
   51064:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5106f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5107a:	mov    rdi,QWORD PTR [rsp+0x190]
   51082:	test   r12d,r12d
   51085:	je     510af <sqlite3VdbeExec+0x1c0f>
   51087:	mov    r14,QWORD PTR [rsp+0x1a8]
   5108f:	mov    QWORD PTR [rsp+0x1c8],rbp
   51097:	mov    rbp,r12
   5109a:	mov    r13,QWORD PTR [rsp+0x1b0]
   510a2:	mov    rbx,QWORD PTR [rsp+0x1d8]
   510aa:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   510af:	mov    r14,QWORD PTR [rsp+0x1a8]
   510b7:	mov    r13,QWORD PTR [rsp+0x1d0]
   510bf:	mov    DWORD PTR [rsp+0x3fc],r15d
   510c7:	mov    QWORD PTR [rsp+0x1d0],r13
   510cf:	mov    DWORD PTR [rsp+0x40c],r12d
   510d7:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   510dc:	mov    r13,QWORD PTR [rsp+0x1d0]
   510e4:	mov    QWORD PTR [rsp+0x1b0],r12
   510ec:	mov    eax,DWORD PTR [rdi+0x2c]
   510ef:	add    eax,0x2
   510f2:	or     eax,0x1
   510f5:	mov    DWORD PTR [rdi+0x2c],eax
   510f8:	movsxd rax,DWORD PTR [rbp+0x4]
   510fc:	imul   rax,rax,0x38
   51100:	add    rax,rbx
   51103:	mov    QWORD PTR [rdi+0xa0],rax
   5110a:	cmp    BYTE PTR [r14+0x67],0x0
   5110f:	je     51121 <sqlite3VdbeExec+0x1c81>
   51111:	mov    rbx,rbp
   51114:	mov    rbp,QWORD PTR [rsp+0x1d8]
   5111c:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   51121:	movzx  eax,BYTE PTR [r14+0x6e]
   51126:	and    eax,0x4
   51129:	test   eax,eax
   5112b:	je     51167 <sqlite3VdbeExec+0x1cc7>
   5112d:	mov    rax,QWORD PTR [r14+0xf0]
   51134:	mov    ecx,0x4
   51139:	mov    rdx,QWORD PTR [r14+0xf8]
   51140:	xor    esi,esi
   51142:	mov    QWORD PTR [rsp+0x190],rdi
   5114a:	mov    r10,rax
   5114d:	mov    r11,rdi
   51150:	mov    rdi,rcx
   51153:	mov    rcx,rsi
   51156:	mov    rsi,rdx
   51159:	mov    rdx,r11
   5115c:	call   r10
   5115f:	mov    rdi,QWORD PTR [rsp+0x190]
   51167:	mov    rax,rbp
   5116a:	sub    rax,r13
   5116d:	movabs rdx,0x2aaaaaaaaaaaaaab
   51177:	imul   rdx
   5117a:	sar    rdx,0x2
   5117e:	mov    rax,rdx
   51181:	shr    rax,0x3f
   51185:	add    rdx,rax
   51188:	mov    rax,rdx
   5118b:	add    eax,0x1
   5118e:	mov    DWORD PTR [rdi+0x30],eax
   51191:	mov    ebx,0x64
   51196:	mov    QWORD PTR [rsp+0x1d0],r13
   5119e:	mov    r12,rbx
   511a1:	mov    r13d,DWORD PTR [rsp+0x400]
   511a9:	mov    r15,QWORD PTR [rsp+0x1b0]
   511b1:	mov    rbx,QWORD PTR [rsp+0x1d8]
   511b9:	jmp    6c449 <sqlite3VdbeExec+0x1cfa9>
   511be:	mov    r15d,DWORD PTR [rsp+0x3fc]
   511c6:	mov    r13,QWORD PTR [rsp+0x1d0]
   511ce:	mov    QWORD PTR [rsp+0x1b0],r12
   511d6:	mov    r12d,DWORD PTR [rsp+0x414]
   511de:	movsxd rax,DWORD PTR [rbp+0x4]
   511e2:	imul   rax,rax,0x38
   511e6:	mov    DWORD PTR [rsp+0x414],r12d
   511ee:	lea    r12,[rbx+rax*1]
   511f2:	movsxd rcx,DWORD PTR [rbp+0x8]
   511f6:	imul   rcx,rcx,0x38
   511fa:	mov    QWORD PTR [rsp+0x1d0],r13
   51202:	lea    r13,[rbx+rcx*1]
   51206:	movsxd rdx,DWORD PTR [rbp+0xc]
   5120a:	imul   rdx,rdx,0x38
   5120e:	mov    DWORD PTR [rsp+0x3fc],r15d
   51216:	lea    r15,[rbx+rdx*1]
   5121a:	mov    QWORD PTR [rsp+0x1a8],r14
   51222:	movzx  r14d,WORD PTR [rbx+rax*1+0x14]
   51228:	mov    eax,r14d
   5122b:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   51230:	or     eax,ecx
   51232:	and    eax,0x1
   51235:	test   eax,eax
   51237:	je     512a1 <sqlite3VdbeExec+0x1e01>
   51239:	movzx  eax,WORD PTR [r15+0x14]
   5123e:	and    eax,0x9000
   51243:	test   eax,eax
   51245:	je     5128d <sqlite3VdbeExec+0x1ded>
   51247:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   51252:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5125d:	mov    QWORD PTR [rsp+0x190],rdi
   51265:	mov    rdi,r15
   51268:	call   5126d <sqlite3VdbeExec+0x1dcd>
   5126d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   51278:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   51283:	mov    rdi,QWORD PTR [rsp+0x190]
   5128b:	jmp    51294 <sqlite3VdbeExec+0x1df4>
   5128d:	mov    WORD PTR [r15+0x14],0x1
   51294:	mov    r14,QWORD PTR [rsp+0x1a8]
   5129c:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   512a1:	mov    eax,r14d
   512a4:	and    eax,0x12
   512a7:	test   eax,eax
   512a9:	jne    51359 <sqlite3VdbeExec+0x1eb9>
   512af:	mov    r14d,DWORD PTR [rsp+0x3fc]
   512b7:	mov    eax,r14d
   512ba:	xor    ecx,ecx
   512bc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   512c7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   512d2:	mov    QWORD PTR [rsp+0x190],rdi
   512da:	mov    rdi,r12
   512dd:	mov    rsi,rax
   512e0:	mov    rdx,rcx
   512e3:	call   512e8 <sqlite3VdbeExec+0x1e48>
   512e8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   512f3:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   512fe:	mov    rdi,QWORD PTR [rsp+0x190]
   51306:	test   eax,eax
   51308:	je     5132a <sqlite3VdbeExec+0x1e8a>
   5130a:	mov    r14,QWORD PTR [rsp+0x1a8]
   51312:	mov    r13,QWORD PTR [rsp+0x1d0]
   5131a:	mov    rbx,rbp
   5131d:	mov    rbp,QWORD PTR [rsp+0x1d8]
   51325:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5132a:	movzx  eax,WORD PTR [r12+0x14]
   51330:	and    eax,0xfffffffd
   51333:	mov    QWORD PTR [rsp+0x1f0],r15
   5133b:	mov    r15d,eax
   5133e:	mov    QWORD PTR [rsp+0x1c8],rbp
   51346:	mov    rbp,rbx
   51349:	mov    rbx,r15
   5134c:	mov    r15,QWORD PTR [rsp+0x1f0]
   51354:	jmp    5149b <sqlite3VdbeExec+0x1ffb>
   51359:	mov    QWORD PTR [rsp+0x1f0],r15
   51361:	mov    r15,rbx
   51364:	mov    rbx,r14
   51367:	mov    r14d,DWORD PTR [rsp+0x3fc]
   5136f:	mov    eax,ebx
   51371:	and    eax,0x400
   51376:	test   eax,eax
   51378:	jne    51392 <sqlite3VdbeExec+0x1ef2>
   5137a:	mov    QWORD PTR [rsp+0x1c8],rbp
   51382:	mov    rbp,r15
   51385:	mov    r15,QWORD PTR [rsp+0x1f0]
   5138d:	jmp    5149b <sqlite3VdbeExec+0x1ffb>
   51392:	mov    eax,DWORD PTR [r12+0x10]
   51397:	add    eax,DWORD PTR [r12]
   5139b:	test   eax,eax
   5139d:	jg     513b5 <sqlite3VdbeExec+0x1f15>
   5139f:	movzx  eax,WORD PTR [r12+0x14]
   513a5:	and    eax,0x10
   513a8:	test   eax,eax
   513aa:	je     5147d <sqlite3VdbeExec+0x1fdd>
   513b0:	mov    eax,0x1
   513b5:	mov    ecx,0x1
   513ba:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   513c5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   513d0:	mov    QWORD PTR [rsp+0x190],rdi
   513d8:	mov    rdi,r12
   513db:	mov    rsi,rax
   513de:	mov    rdx,rcx
   513e1:	call   513e6 <sqlite3VdbeExec+0x1f46>
   513e6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   513f1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   513fc:	mov    rdi,QWORD PTR [rsp+0x190]
   51404:	test   eax,eax
   51406:	jne    5152c <sqlite3VdbeExec+0x208c>
   5140c:	mov    rax,QWORD PTR [r12+0x8]
   51411:	movsxd rcx,DWORD PTR [r12+0x10]
   51416:	add    rax,rcx
   51419:	xor    ecx,ecx
   5141b:	movsxd rdx,DWORD PTR [r12]
   5141f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5142a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   51435:	mov    rdi,rax
   51438:	mov    rsi,rcx
   5143b:	call   51440 <sqlite3VdbeExec+0x1fa0>
   51440:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5144b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   51456:	mov    eax,DWORD PTR [r12+0x10]
   5145b:	add    eax,DWORD PTR [r12]
   5145f:	mov    DWORD PTR [r12+0x10],eax
   51464:	movzx  eax,WORD PTR [r12+0x14]
   5146a:	and    eax,0xfffff9ff
   5146f:	mov    WORD PTR [r12+0x14],ax
   51475:	mov    rdi,QWORD PTR [rsp+0x190]
   5147d:	movzx  eax,WORD PTR [r12+0x14]
   51483:	and    eax,0xfffffffd
   51486:	mov    ebx,eax
   51488:	mov    QWORD PTR [rsp+0x1c8],rbp
   51490:	mov    rbp,r15
   51493:	mov    r15,QWORD PTR [rsp+0x1f0]
   5149b:	mov    DWORD PTR [rsp+0x418],ebx
   514a2:	movzx  ebx,WORD PTR [r13+0x14]
   514a7:	mov    eax,ebx
   514a9:	and    eax,0x12
   514ac:	test   eax,eax
   514ae:	jne    51568 <sqlite3VdbeExec+0x20c8>
   514b4:	mov    eax,r14d
   514b7:	xor    ecx,ecx
   514b9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   514c4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   514cf:	mov    QWORD PTR [rsp+0x190],rdi
   514d7:	mov    rdi,r13
   514da:	mov    rsi,rax
   514dd:	mov    rdx,rcx
   514e0:	call   514e5 <sqlite3VdbeExec+0x2045>
   514e5:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   514f0:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   514fb:	mov    rdi,QWORD PTR [rsp+0x190]
   51503:	test   eax,eax
   51505:	je     51559 <sqlite3VdbeExec+0x20b9>
   51507:	mov    r14,QWORD PTR [rsp+0x1a8]
   5150f:	mov    r13,QWORD PTR [rsp+0x1d0]
   51517:	mov    rbx,QWORD PTR [rsp+0x1c8]
   5151f:	mov    rbp,QWORD PTR [rsp+0x1d8]
   51527:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5152c:	mov    QWORD PTR [rsp+0x1c8],rbp
   51534:	mov    r14,QWORD PTR [rsp+0x1a8]
   5153c:	mov    r13,QWORD PTR [rsp+0x1d0]
   51544:	mov    rbx,QWORD PTR [rsp+0x1c8]
   5154c:	mov    rbp,QWORD PTR [rsp+0x1d8]
   51554:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   51559:	movzx  eax,WORD PTR [r13+0x14]
   5155e:	and    eax,0xfffffffd
   51561:	mov    ebx,eax
   51563:	jmp    51664 <sqlite3VdbeExec+0x21c4>
   51568:	mov    eax,ebx
   5156a:	and    eax,0x400
   5156f:	test   eax,eax
   51571:	je     51664 <sqlite3VdbeExec+0x21c4>
   51577:	mov    eax,DWORD PTR [r13+0x10]
   5157b:	add    eax,DWORD PTR [r13+0x0]
   5157f:	test   eax,eax
   51581:	jg     51598 <sqlite3VdbeExec+0x20f8>
   51583:	movzx  eax,WORD PTR [r13+0x14]
   51588:	and    eax,0x10
   5158b:	test   eax,eax
   5158d:	je     5165a <sqlite3VdbeExec+0x21ba>
   51593:	mov    eax,0x1
   51598:	mov    ecx,0x1
   5159d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   515a8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   515b3:	mov    QWORD PTR [rsp+0x190],rdi
   515bb:	mov    rdi,r13
   515be:	mov    rsi,rax
   515c1:	mov    rdx,rcx
   515c4:	call   515c9 <sqlite3VdbeExec+0x2129>
   515c9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   515d4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   515df:	mov    rdi,QWORD PTR [rsp+0x190]
   515e7:	test   eax,eax
   515e9:	jne    51718 <sqlite3VdbeExec+0x2278>
   515ef:	mov    rax,QWORD PTR [r13+0x8]
   515f3:	movsxd rcx,DWORD PTR [r13+0x10]
   515f7:	add    rax,rcx
   515fa:	xor    ecx,ecx
   515fc:	movsxd rdx,DWORD PTR [r13+0x0]
   51600:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5160b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   51616:	mov    rdi,rax
   51619:	mov    rsi,rcx
   5161c:	call   51621 <sqlite3VdbeExec+0x2181>
   51621:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5162c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   51637:	mov    eax,DWORD PTR [r13+0x10]
   5163b:	add    eax,DWORD PTR [r13+0x0]
   5163f:	mov    DWORD PTR [r13+0x10],eax
   51643:	movzx  eax,WORD PTR [r13+0x14]
   51648:	and    eax,0xfffff9ff
   5164d:	mov    WORD PTR [r13+0x14],ax
   51652:	mov    rdi,QWORD PTR [rsp+0x190]
   5165a:	movzx  eax,WORD PTR [r13+0x14]
   5165f:	and    eax,0xfffffffd
   51662:	mov    ebx,eax
   51664:	movsxd rax,DWORD PTR [r12+0x10]
   51669:	movsxd rcx,DWORD PTR [r13+0x10]
   5166d:	mov    DWORD PTR [rsp+0x41c],ebx
   51674:	lea    rbx,[rax+rcx*1]
   51678:	mov    QWORD PTR [rsp+0x1e8],r12
   51680:	mov    r12,QWORD PTR [rsp+0x1a8]
   51688:	movsxd rax,DWORD PTR [r12+0x88]
   51690:	cmp    rbx,rax
   51693:	jle    5169d <sqlite3VdbeExec+0x21fd>
   51695:	mov    rbp,r12
   51698:	jmp    54d59 <sqlite3VdbeExec+0x58b9>
   5169d:	mov    eax,ebx
   5169f:	add    eax,0x2
   516a2:	xor    ecx,ecx
   516a4:	cmp    r15,r13
   516a7:	sete   cl
   516aa:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   516b5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   516c0:	mov    QWORD PTR [rsp+0x190],rdi
   516c8:	mov    rdi,r15
   516cb:	mov    rsi,rax
   516ce:	mov    rdx,rcx
   516d1:	call   516d6 <sqlite3VdbeExec+0x2236>
   516d6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   516e1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   516ec:	mov    rdi,QWORD PTR [rsp+0x190]
   516f4:	test   eax,eax
   516f6:	je     51740 <sqlite3VdbeExec+0x22a0>
   516f8:	mov    r14,r12
   516fb:	mov    r13,QWORD PTR [rsp+0x1d0]
   51703:	mov    rbx,QWORD PTR [rsp+0x1c8]
   5170b:	mov    rbp,QWORD PTR [rsp+0x1d8]
   51713:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   51718:	mov    r12,QWORD PTR [rsp+0x1a8]
   51720:	mov    r14,r12
   51723:	mov    r13,QWORD PTR [rsp+0x1d0]
   5172b:	mov    rbx,QWORD PTR [rsp+0x1c8]
   51733:	mov    rbp,QWORD PTR [rsp+0x1d8]
   5173b:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   51740:	movzx  eax,WORD PTR [r15+0x14]
   51745:	and    eax,0xfffff240
   5174a:	or     eax,0x2
   5174d:	mov    WORD PTR [r15+0x14],ax
   51752:	cmp    r15,r13
   51755:	jne    51761 <sqlite3VdbeExec+0x22c1>
   51757:	mov    QWORD PTR [rsp+0x1e0],rbp
   5175f:	jmp    517c0 <sqlite3VdbeExec+0x2320>
   51761:	mov    rax,QWORD PTR [r15+0x8]
   51765:	mov    rcx,QWORD PTR [r13+0x8]
   51769:	movsxd rdx,DWORD PTR [r13+0x10]
   5176d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   51778:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   51783:	mov    rdi,rax
   51786:	mov    rsi,rcx
   51789:	call   5178e <sqlite3VdbeExec+0x22ee>
   5178e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   51799:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   517a4:	mov    QWORD PTR [rsp+0x1e0],rbp
   517ac:	mov    ebp,DWORD PTR [rsp+0x41c]
   517b3:	mov    WORD PTR [r13+0x14],bp
   517b8:	mov    rdi,QWORD PTR [rsp+0x190]
   517c0:	mov    rax,QWORD PTR [r15+0x8]
   517c4:	movsxd rcx,DWORD PTR [r13+0x10]
   517c8:	add    rax,rcx
   517cb:	mov    rbp,QWORD PTR [rsp+0x1e8]
   517d3:	mov    rcx,QWORD PTR [rbp+0x8]
   517d7:	movsxd rdx,DWORD PTR [rbp+0x10]
   517db:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   517e6:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   517f1:	mov    QWORD PTR [rsp+0x190],rdi
   517f9:	mov    rdi,rax
   517fc:	mov    rsi,rcx
   517ff:	call   51804 <sqlite3VdbeExec+0x2364>
   51804:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5180f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5181a:	mov    r13d,DWORD PTR [rsp+0x418]
   51822:	mov    WORD PTR [rbp+0x14],r13w
   51827:	mov    eax,r14d
   5182a:	mov    rdi,QWORD PTR [rsp+0x190]
   51832:	cmp    eax,0x1
   51835:	jg     51841 <sqlite3VdbeExec+0x23a1>
   51837:	mov    rbp,QWORD PTR [rsp+0x1c8]
   5183f:	jmp    5184d <sqlite3VdbeExec+0x23ad>
   51841:	and    rbx,0xfffffffffffffffe
   51845:	mov    rbp,QWORD PTR [rsp+0x1c8]
   5184d:	mov    rax,QWORD PTR [r15+0x8]
   51851:	mov    BYTE PTR [rax+rbx*1],0x0
   51855:	mov    rax,QWORD PTR [r15+0x8]
   51859:	mov    BYTE PTR [rax+rbx*1+0x1],0x0
   5185e:	movzx  eax,WORD PTR [r15+0x14]
   51863:	or     eax,0x200
   51868:	mov    WORD PTR [r15+0x14],ax
   5186d:	mov    DWORD PTR [r15+0x10],ebx
   51871:	mov    BYTE PTR [r15+0x16],r14b
   51875:	mov    DWORD PTR [rsp+0x3fc],r14d
   5187d:	mov    r14,r12
   51880:	mov    rbx,QWORD PTR [rsp+0x1e0]
   51888:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5188d:	mov    QWORD PTR [rsp+0x1e0],rbx
   51895:	mov    QWORD PTR [rsp+0x1b0],r12
   5189d:	mov    r12,r14
   518a0:	mov    r14d,DWORD PTR [rsp+0x3fc]
   518a8:	movsxd rax,DWORD PTR [rbp+0x4]
   518ac:	imul   rax,rax,0x38
   518b0:	mov    rbx,QWORD PTR [rsp+0x1e0]
   518b8:	lea    r13,[rbx+rax*1]
   518bc:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   518c1:	movsxd rcx,DWORD PTR [rbp+0x8]
   518c5:	imul   rcx,rcx,0x38
   518c9:	lea    r15,[rbx+rcx*1]
   518cd:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   518d2:	movsxd rdx,DWORD PTR [rbp+0xc]
   518d6:	imul   rdx,rdx,0x38
   518da:	mov    DWORD PTR [rsp+0x3fc],r14d
   518e2:	lea    r14,[rbx+rdx*1]
   518e6:	mov    edx,eax
   518e8:	mov    esi,ecx
   518ea:	and    edx,esi
   518ec:	and    edx,0x4
   518ef:	test   edx,edx
   518f1:	je     51ba2 <sqlite3VdbeExec+0x2702>
   518f7:	mov    rcx,QWORD PTR [r13+0x0]
   518fb:	mov    rax,QWORD PTR [r15]
   518fe:	mov    QWORD PTR [rsp+0x1f0],rax
   51906:	movzx  eax,BYTE PTR [rbp+0x0]
   5190a:	mov    edx,eax
   5190c:	sub    edx,0x6b
   5190f:	cmp    edx,0x3
   51912:	jbe    51921 <sqlite3VdbeExec+0x2481>
   51914:	mov    QWORD PTR [rsp+0x1e8],r14
   5191c:	jmp    51b4b <sqlite3VdbeExec+0x26ab>
   51921:	sub    eax,0x6b
   51924:	mov    QWORD PTR [rsp+0x1e8],r14
   5192c:	lea    r14,[rip+0x0]        # 51933 <sqlite3VdbeExec+0x2493>
   51933:	movsxd rax,DWORD PTR [r14+rax*4]
   51937:	add    rax,r14
   5193a:	jmp    rax
   5193c:	mov    rax,QWORD PTR [rsp+0x1f0]
   51944:	test   rcx,rcx
   51947:	jl     5197b <sqlite3VdbeExec+0x24db>
   51949:	test   rax,rax
   5194c:	jle    51999 <sqlite3VdbeExec+0x24f9>
   5194e:	movabs rdx,0x7fffffffffffffff
   51958:	sub    rdx,rax
   5195b:	cmp    rdx,rcx
   5195e:	jge    51999 <sqlite3VdbeExec+0x24f9>
   51960:	movzx  eax,WORD PTR [r13+0x14]
   51965:	and    eax,0x8
   51968:	test   eax,eax
   5196a:	je     51cdf <sqlite3VdbeExec+0x283f>
   51970:	movsd  xmm2,QWORD PTR [r13+0x0]
   51976:	jmp    51d91 <sqlite3VdbeExec+0x28f1>
   5197b:	test   rax,rax
   5197e:	jge    51999 <sqlite3VdbeExec+0x24f9>
   51980:	movabs rdx,0x7fffffffffffffff
   5198a:	add    rax,rdx
   5198d:	neg    rax
   51990:	lea    rdx,[rcx+0x1]
   51994:	cmp    rax,rdx
   51997:	jg     51960 <sqlite3VdbeExec+0x24c0>
   51999:	mov    rax,QWORD PTR [rsp+0x1f0]
   519a1:	add    rax,rcx
   519a4:	mov    QWORD PTR [rsp+0x1f0],rax
   519ac:	jmp    51b77 <sqlite3VdbeExec+0x26d7>
   519b1:	movabs rax,0x8000000000000000
   519bb:	cmp    rcx,rax
   519be:	jne    519e3 <sqlite3VdbeExec+0x2543>
   519c0:	cmp    QWORD PTR [rsp+0x1f0],0x0
   519c9:	jge    51960 <sqlite3VdbeExec+0x24c0>
   519cb:	mov    rax,QWORD PTR [rsp+0x1f0]
   519d3:	sub    rax,rcx
   519d6:	mov    QWORD PTR [rsp+0x1f0],rax
   519de:	jmp    51b77 <sqlite3VdbeExec+0x26d7>
   519e3:	neg    rcx
   519e6:	mov    rax,QWORD PTR [rsp+0x1f0]
   519ee:	test   rcx,rcx
   519f1:	jl     51a23 <sqlite3VdbeExec+0x2583>
   519f3:	test   rax,rax
   519f6:	jle    51a0e <sqlite3VdbeExec+0x256e>
   519f8:	movabs rdx,0x7fffffffffffffff
   51a02:	sub    rdx,rax
   51a05:	cmp    rdx,rcx
   51a08:	jl     51960 <sqlite3VdbeExec+0x24c0>
   51a0e:	add    rcx,QWORD PTR [rsp+0x1f0]
   51a16:	mov    QWORD PTR [rsp+0x1f0],rcx
   51a1e:	jmp    51b77 <sqlite3VdbeExec+0x26d7>
   51a23:	test   rax,rax
   51a26:	jge    51a0e <sqlite3VdbeExec+0x256e>
   51a28:	movabs rdx,0x7fffffffffffffff
   51a32:	add    rax,rdx
   51a35:	neg    rax
   51a38:	lea    rdx,[rcx+0x1]
   51a3c:	cmp    rax,rdx
   51a3f:	jg     51960 <sqlite3VdbeExec+0x24c0>
   51a45:	jmp    51a0e <sqlite3VdbeExec+0x256e>
   51a47:	mov    rsi,QWORD PTR [rsp+0x1f0]
   51a4f:	test   rcx,rcx
   51a52:	jle    51a95 <sqlite3VdbeExec+0x25f5>
   51a54:	movabs rax,0x7fffffffffffffff
   51a5e:	cqo
   51a60:	idiv   rcx
   51a63:	cmp    rsi,rax
   51a66:	jg     51960 <sqlite3VdbeExec+0x24c0>
   51a6c:	movabs rax,0x8000000000000000
   51a76:	cqo
   51a78:	idiv   rcx
   51a7b:	cmp    rsi,rax
   51a7e:	jl     51960 <sqlite3VdbeExec+0x24c0>
   51a84:	imul   rsi,rcx
   51a88:	mov    QWORD PTR [rsp+0x1f0],rsi
   51a90:	jmp    51b77 <sqlite3VdbeExec+0x26d7>
   51a95:	test   rcx,rcx
   51a98:	jge    51a84 <sqlite3VdbeExec+0x25e4>
   51a9a:	test   rsi,rsi
   51a9d:	jle    51ab9 <sqlite3VdbeExec+0x2619>
   51a9f:	movabs rax,0x8000000000000000
   51aa9:	cqo
   51aab:	idiv   rsi
   51aae:	cmp    rcx,rax
   51ab1:	jl     51960 <sqlite3VdbeExec+0x24c0>
   51ab7:	jmp    51a84 <sqlite3VdbeExec+0x25e4>
   51ab9:	test   rsi,rsi
   51abc:	jge    51a84 <sqlite3VdbeExec+0x25e4>
   51abe:	movabs rax,0x8000000000000000
   51ac8:	cmp    rcx,rax
   51acb:	je     51960 <sqlite3VdbeExec+0x24c0>
   51ad1:	movabs rax,0x8000000000000000
   51adb:	cmp    rsi,rax
   51ade:	je     51960 <sqlite3VdbeExec+0x24c0>
   51ae4:	mov    r8,rsi
   51ae7:	neg    r8
   51aea:	movabs rax,0x7fffffffffffffff
   51af4:	mov    r9,rcx
   51af7:	neg    r9
   51afa:	cqo
   51afc:	idiv   r9
   51aff:	cmp    r8,rax
   51b02:	jg     51960 <sqlite3VdbeExec+0x24c0>
   51b08:	jmp    51a84 <sqlite3VdbeExec+0x25e4>
   51b0d:	test   rcx,rcx
   51b10:	je     520dd <sqlite3VdbeExec+0x2c3d>
   51b16:	cmp    rcx,0xffffffffffffffff
   51b1a:	jne    51b34 <sqlite3VdbeExec+0x2694>
   51b1c:	movabs rax,0x8000000000000000
   51b26:	cmp    rax,QWORD PTR [rsp+0x1f0]
   51b2e:	je     51960 <sqlite3VdbeExec+0x24c0>
   51b34:	mov    rax,QWORD PTR [rsp+0x1f0]
   51b3c:	cqo
   51b3e:	idiv   rcx
   51b41:	mov    QWORD PTR [rsp+0x1f0],rax
   51b49:	jmp    51b77 <sqlite3VdbeExec+0x26d7>
   51b4b:	test   rcx,rcx
   51b4e:	je     520dd <sqlite3VdbeExec+0x2c3d>
   51b54:	cmp    rcx,0xffffffffffffffff
   51b58:	jne    51b5f <sqlite3VdbeExec+0x26bf>
   51b5a:	mov    ecx,0x1
   51b5f:	mov    rax,QWORD PTR [rsp+0x1f0]
   51b67:	cqo
   51b69:	idiv   rcx
   51b6c:	mov    rax,rdx
   51b6f:	mov    QWORD PTR [rsp+0x1f0],rax
   51b77:	mov    rax,QWORD PTR [rsp+0x1f0]
   51b7f:	mov    r13,QWORD PTR [rsp+0x1e8]
   51b87:	mov    QWORD PTR [r13+0x0],rax
   51b8b:	movzx  eax,WORD PTR [r13+0x14]
   51b90:	and    eax,0xfffff240
   51b95:	or     eax,0x4
   51b98:	mov    WORD PTR [r13+0x14],ax
   51b9d:	jmp    520d5 <sqlite3VdbeExec+0x2c35>
   51ba2:	mov    QWORD PTR [rsp+0x1e8],r14
   51baa:	or     eax,ecx
   51bac:	and    eax,0x1
   51baf:	test   eax,eax
   51bb1:	jne    520dd <sqlite3VdbeExec+0x2c3d>
   51bb7:	movzx  eax,WORD PTR [r13+0x14]
   51bbc:	and    eax,0x2d
   51bbf:	test   eax,eax
   51bc1:	je     51bd0 <sqlite3VdbeExec+0x2730>
   51bc3:	movzx  eax,WORD PTR [r13+0x14]
   51bc8:	and    eax,0x2d
   51bcb:	mov    r14d,eax
   51bce:	jmp    51c18 <sqlite3VdbeExec+0x2778>
   51bd0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   51bdb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   51be6:	mov    QWORD PTR [rsp+0x190],rdi
   51bee:	mov    rdi,r13
   51bf1:	call   51bf6 <sqlite3VdbeExec+0x2756>
   51bf6:	movzx  r14d,ax
   51bfa:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   51c05:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   51c10:	mov    rdi,QWORD PTR [rsp+0x190]
   51c18:	movzx  eax,WORD PTR [r15+0x14]
   51c1d:	and    eax,0x2d
   51c20:	test   eax,eax
   51c22:	je     51c41 <sqlite3VdbeExec+0x27a1>
   51c24:	movzx  eax,WORD PTR [r15+0x14]
   51c29:	and    eax,0x2d
   51c2c:	mov    QWORD PTR [rsp+0x1e0],rbx
   51c34:	mov    rbx,r14
   51c37:	mov    r14d,DWORD PTR [rsp+0x3fc]
   51c3f:	jmp    51c9b <sqlite3VdbeExec+0x27fb>
   51c41:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   51c4c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   51c57:	mov    QWORD PTR [rsp+0x190],rdi
   51c5f:	mov    rdi,r15
   51c62:	call   51c67 <sqlite3VdbeExec+0x27c7>
   51c67:	movzx  eax,ax
   51c6a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   51c75:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   51c80:	mov    rdi,QWORD PTR [rsp+0x190]
   51c88:	mov    QWORD PTR [rsp+0x1e0],rbx
   51c90:	mov    rbx,r14
   51c93:	mov    r14d,DWORD PTR [rsp+0x3fc]
   51c9b:	mov    ecx,ebx
   51c9d:	and    ecx,eax
   51c9f:	and    ecx,0x4
   51ca2:	test   ecx,ecx
   51ca4:	jne    51cc2 <sqlite3VdbeExec+0x2822>
   51ca6:	mov    DWORD PTR [rsp+0x3fc],r14d
   51cae:	mov    rbx,QWORD PTR [rsp+0x1e0]
   51cb6:	lea    r14,[rip+0x0]        # 51cbd <sqlite3VdbeExec+0x281d>
   51cbd:	jmp    51960 <sqlite3VdbeExec+0x24c0>
   51cc2:	mov    DWORD PTR [rsp+0x3fc],r14d
   51cca:	mov    r14,QWORD PTR [rsp+0x1e8]
   51cd2:	mov    rbx,QWORD PTR [rsp+0x1e0]
   51cda:	jmp    518f7 <sqlite3VdbeExec+0x2457>
   51cdf:	mov    r14d,DWORD PTR [rsp+0x3fc]
   51ce7:	mov    QWORD PTR [rsp+0x1e0],rbx
   51cef:	movzx  eax,WORD PTR [r13+0x14]
   51cf4:	and    eax,0x24
   51cf7:	test   eax,eax
   51cf9:	je     51d19 <sqlite3VdbeExec+0x2879>
   51cfb:	mov    rax,QWORD PTR [r13+0x0]
   51cff:	xorps  xmm2,xmm2
   51d02:	cvtsi2sd xmm2,rax
   51d07:	mov    DWORD PTR [rsp+0x3fc],r14d
   51d0f:	mov    rbx,QWORD PTR [rsp+0x1e0]
   51d17:	jmp    51d91 <sqlite3VdbeExec+0x28f1>
   51d19:	movzx  eax,WORD PTR [r13+0x14]
   51d1e:	and    eax,0x12
   51d21:	test   eax,eax
   51d23:	je     51d7e <sqlite3VdbeExec+0x28de>
   51d25:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   51d30:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   51d3b:	mov    QWORD PTR [rsp+0x190],rdi
   51d43:	mov    rdi,r13
   51d46:	call   51d4b <sqlite3VdbeExec+0x28ab>
   51d4b:	movaps xmm2,xmm0
   51d4e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   51d59:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   51d64:	mov    rdi,QWORD PTR [rsp+0x190]
   51d6c:	mov    DWORD PTR [rsp+0x3fc],r14d
   51d74:	mov    rbx,QWORD PTR [rsp+0x1e0]
   51d7c:	jmp    51d91 <sqlite3VdbeExec+0x28f1>
   51d7e:	xorps  xmm2,xmm2
   51d81:	mov    DWORD PTR [rsp+0x3fc],r14d
   51d89:	mov    rbx,QWORD PTR [rsp+0x1e0]
   51d91:	movzx  eax,WORD PTR [r15+0x14]
   51d96:	and    eax,0x8
   51d99:	test   eax,eax
   51d9b:	je     51da7 <sqlite3VdbeExec+0x2907>
   51d9d:	movsd  xmm3,QWORD PTR [r15]
   51da2:	jmp    51e2e <sqlite3VdbeExec+0x298e>
   51da7:	movzx  eax,WORD PTR [r15+0x14]
   51dac:	and    eax,0x24
   51daf:	test   eax,eax
   51db1:	je     51dc0 <sqlite3VdbeExec+0x2920>
   51db3:	mov    rax,QWORD PTR [r15]
   51db6:	xorps  xmm3,xmm3
   51db9:	cvtsi2sd xmm3,rax
   51dbe:	jmp    51e2e <sqlite3VdbeExec+0x298e>
   51dc0:	movzx  eax,WORD PTR [r15+0x14]
   51dc5:	and    eax,0x12
   51dc8:	test   eax,eax
   51dca:	je     51e2b <sqlite3VdbeExec+0x298b>
   51dcc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   51dd7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   51de2:	vmovdqu32 ZMMWORD PTR [rsp+0x90],zmm2
   51ded:	mov    QWORD PTR [rsp+0x190],rdi
   51df5:	mov    rdi,r15
   51df8:	call   51dfd <sqlite3VdbeExec+0x295d>
   51dfd:	movaps xmm3,xmm0
   51e00:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   51e0b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   51e16:	vmovdqu32 zmm2,ZMMWORD PTR [rsp+0x90]
   51e21:	mov    rdi,QWORD PTR [rsp+0x190]
   51e29:	jmp    51e2e <sqlite3VdbeExec+0x298e>
   51e2b:	xorps  xmm3,xmm3
   51e2e:	movzx  eax,BYTE PTR [rbp+0x0]
   51e32:	mov    ecx,eax
   51e34:	sub    ecx,0x6b
   51e37:	cmp    ecx,0x3
   51e3a:	ja     51e98 <sqlite3VdbeExec+0x29f8>
   51e3c:	sub    eax,0x6b
   51e3f:	lea    r14,[rip+0x0]        # 51e46 <sqlite3VdbeExec+0x29a6>
   51e46:	movsxd rax,DWORD PTR [r14+rax*4]
   51e4a:	add    rax,r14
   51e4d:	jmp    rax
   51e4f:	addsd  xmm3,xmm2
   51e53:	jmp    52059 <sqlite3VdbeExec+0x2bb9>
   51e58:	subsd  xmm3,xmm2
   51e5c:	jmp    52059 <sqlite3VdbeExec+0x2bb9>
   51e61:	mulsd  xmm3,xmm2
   51e65:	jmp    52059 <sqlite3VdbeExec+0x2bb9>
   51e6a:	xorps  xmm4,xmm4
   51e6d:	xor    eax,eax
   51e6f:	ucomisd xmm2,xmm4
   51e73:	sete   al
   51e76:	setnp  r11b
   51e7a:	and    al,r11b
   51e7d:	test   eax,eax
   51e7f:	mov    eax,0x0
   51e84:	setne  al
   51e87:	test   eax,eax
   51e89:	jne    520dd <sqlite3VdbeExec+0x2c3d>
   51e8f:	divsd  xmm3,xmm2
   51e93:	jmp    52059 <sqlite3VdbeExec+0x2bb9>
   51e98:	movzx  eax,WORD PTR [r13+0x14]
   51e9d:	mov    ecx,eax
   51e9f:	and    ecx,0x24
   51ea2:	test   ecx,ecx
   51ea4:	je     51eaf <sqlite3VdbeExec+0x2a0f>
   51ea6:	mov    r13,QWORD PTR [r13+0x0]
   51eaa:	jmp    51f61 <sqlite3VdbeExec+0x2ac1>
   51eaf:	mov    ecx,eax
   51eb1:	and    ecx,0x8
   51eb4:	test   ecx,ecx
   51eb6:	je     51f07 <sqlite3VdbeExec+0x2a67>
   51eb8:	movsd  xmm3,QWORD PTR [r13+0x0]
   51ebe:	movabs r11,0xc3dfffffffffffff
   51ec8:	movq   xmm2,r11
   51ecd:	ucomisd xmm2,xmm3
   51ed1:	jbe    51edf <sqlite3VdbeExec+0x2a3f>
   51ed3:	movabs r13,0x8000000000000000
   51edd:	jmp    51f05 <sqlite3VdbeExec+0x2a65>
   51edf:	movabs r11,0x43dfffffffffffff
   51ee9:	movq   xmm2,r11
   51eee:	ucomisd xmm3,xmm2
   51ef2:	jbe    51f00 <sqlite3VdbeExec+0x2a60>
   51ef4:	movabs r13,0x7fffffffffffffff
   51efe:	jmp    51f05 <sqlite3VdbeExec+0x2a65>
   51f00:	cvttsd2si r13,xmm3
   51f05:	jmp    51f61 <sqlite3VdbeExec+0x2ac1>
   51f07:	and    eax,0x12
   51f0a:	test   eax,eax
   51f0c:	je     51f5e <sqlite3VdbeExec+0x2abe>
   51f0e:	cmp    QWORD PTR [r13+0x8],0x0
   51f13:	je     51f5e <sqlite3VdbeExec+0x2abe>
   51f15:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   51f20:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   51f2b:	mov    QWORD PTR [rsp+0x190],rdi
   51f33:	mov    rdi,r13
   51f36:	call   51f3b <sqlite3VdbeExec+0x2a9b>
   51f3b:	mov    r13,rax
   51f3e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   51f49:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   51f54:	mov    rdi,QWORD PTR [rsp+0x190]
   51f5c:	jmp    51f61 <sqlite3VdbeExec+0x2ac1>
   51f5e:	xor    r13d,r13d
   51f61:	movzx  eax,WORD PTR [r15+0x14]
   51f66:	mov    ecx,eax
   51f68:	and    ecx,0x24
   51f6b:	test   ecx,ecx
   51f6d:	je     51f77 <sqlite3VdbeExec+0x2ad7>
   51f6f:	mov    rax,QWORD PTR [r15]
   51f72:	jmp    52024 <sqlite3VdbeExec+0x2b84>
   51f77:	mov    ecx,eax
   51f79:	and    ecx,0x8
   51f7c:	test   ecx,ecx
   51f7e:	je     51fce <sqlite3VdbeExec+0x2b2e>
   51f80:	movsd  xmm3,QWORD PTR [r15]
   51f85:	movabs r11,0xc3dfffffffffffff
   51f8f:	movq   xmm2,r11
   51f94:	ucomisd xmm2,xmm3
   51f98:	jbe    51fa6 <sqlite3VdbeExec+0x2b06>
   51f9a:	movabs rax,0x8000000000000000
   51fa4:	jmp    51fcc <sqlite3VdbeExec+0x2b2c>
   51fa6:	movabs r11,0x43dfffffffffffff
   51fb0:	movq   xmm2,r11
   51fb5:	ucomisd xmm3,xmm2
   51fb9:	jbe    51fc7 <sqlite3VdbeExec+0x2b27>
   51fbb:	movabs rax,0x7fffffffffffffff
   51fc5:	jmp    51fcc <sqlite3VdbeExec+0x2b2c>
   51fc7:	cvttsd2si rax,xmm3
   51fcc:	jmp    52024 <sqlite3VdbeExec+0x2b84>
   51fce:	and    eax,0x12
   51fd1:	test   eax,eax
   51fd3:	je     52022 <sqlite3VdbeExec+0x2b82>
   51fd5:	cmp    QWORD PTR [r15+0x8],0x0
   51fda:	je     52022 <sqlite3VdbeExec+0x2b82>
   51fdc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   51fe7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   51ff2:	mov    QWORD PTR [rsp+0x190],rdi
   51ffa:	mov    rdi,r15
   51ffd:	call   52002 <sqlite3VdbeExec+0x2b62>
   52002:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5200d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   52018:	mov    rdi,QWORD PTR [rsp+0x190]
   52020:	jmp    52024 <sqlite3VdbeExec+0x2b84>
   52022:	xor    eax,eax
   52024:	mov    QWORD PTR [rsp+0x1f0],rax
   5202c:	test   r13,r13
   5202f:	je     520dd <sqlite3VdbeExec+0x2c3d>
   52035:	cmp    r13,0xffffffffffffffff
   52039:	jne    52041 <sqlite3VdbeExec+0x2ba1>
   5203b:	mov    r13d,0x1
   52041:	mov    rax,QWORD PTR [rsp+0x1f0]
   52049:	cqo
   5204b:	idiv   r13
   5204e:	mov    rax,rdx
   52051:	xorps  xmm3,xmm3
   52054:	cvtsi2sd xmm3,rax
   52059:	movsd  QWORD PTR [rsp+0x198],xmm3
   52062:	mov    rax,QWORD PTR [rsp+0x198]
   5206a:	mov    QWORD PTR [rsp+0x1a0],rax
   52072:	mov    rax,QWORD PTR [rsp+0x1a0]
   5207a:	movabs rcx,0x7ff0000000000000
   52084:	and    rcx,rax
   52087:	movabs rdx,0x7ff0000000000000
   52091:	movabs rsi,0xfffffffffffff
   5209b:	and    rax,rsi
   5209e:	test   rax,rax
   520a1:	mov    eax,0x0
   520a6:	setne  al
   520a9:	xor    esi,esi
   520ab:	cmp    rcx,rdx
   520ae:	cmove  esi,eax
   520b1:	test   esi,esi
   520b3:	jne    520dd <sqlite3VdbeExec+0x2c3d>
   520b5:	mov    r13,QWORD PTR [rsp+0x1e8]
   520bd:	movsd  QWORD PTR [r13+0x0],xmm3
   520c3:	movzx  eax,WORD PTR [r13+0x14]
   520c8:	and    eax,0xfffff240
   520cd:	or     eax,0x8
   520d0:	mov    WORD PTR [r13+0x14],ax
   520d5:	mov    r14,r12
   520d8:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   520dd:	mov    r13,QWORD PTR [rsp+0x1e8]
   520e5:	movzx  eax,WORD PTR [r13+0x14]
   520ea:	and    eax,0x9000
   520ef:	test   eax,eax
   520f1:	je     52139 <sqlite3VdbeExec+0x2c99>
   520f3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   520fe:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   52109:	mov    QWORD PTR [rsp+0x190],rdi
   52111:	mov    rdi,r13
   52114:	call   52119 <sqlite3VdbeExec+0x2c79>
   52119:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   52124:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5212f:	mov    rdi,QWORD PTR [rsp+0x190]
   52137:	jmp    52140 <sqlite3VdbeExec+0x2ca0>
   52139:	mov    WORD PTR [r13+0x14],0x1
   52140:	mov    r14,r12
   52143:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   52148:	mov    QWORD PTR [rsp+0x1b0],r12
   52150:	mov    r12,r14
   52153:	cmp    DWORD PTR [rbp+0x4],0x0
   52157:	je     521cb <sqlite3VdbeExec+0x2d2b>
   52159:	movsxd rax,DWORD PTR [rbp+0x4]
   5215d:	imul   rax,rax,0x38
   52161:	lea    rcx,[rbx+rax*1]
   52165:	xor    edx,edx
   52167:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   5216c:	and    eax,0x9000
   52171:	test   eax,eax
   52173:	je     521be <sqlite3VdbeExec+0x2d1e>
   52175:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   52180:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5218b:	mov    QWORD PTR [rsp+0x190],rdi
   52193:	mov    rdi,rcx
   52196:	mov    rsi,rdx
   52199:	call   5219e <sqlite3VdbeExec+0x2cfe>
   5219e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   521a9:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   521b4:	mov    rdi,QWORD PTR [rsp+0x190]
   521bc:	jmp    521cb <sqlite3VdbeExec+0x2d2b>
   521be:	mov    QWORD PTR [rcx],0x0
   521c5:	mov    WORD PTR [rcx+0x14],0x4
   521cb:	mov    r14,r12
   521ce:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   521d3:	mov    QWORD PTR [rsp+0x1b0],r12
   521db:	mov    r12,r14
   521de:	movsxd rax,DWORD PTR [rbp+0x4]
   521e2:	imul   rax,rax,0x38
   521e6:	lea    r13,[rbx+rax*1]
   521ea:	movsxd rcx,DWORD PTR [rbp+0x8]
   521ee:	imul   rcx,rcx,0x38
   521f2:	lea    rdx,[rbx+rcx*1]
   521f6:	movsxd rsi,DWORD PTR [rbp+0xc]
   521fa:	imul   rsi,rsi,0x38
   521fe:	lea    r15,[rbx+rsi*1]
   52202:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52207:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   5220c:	or     eax,ecx
   5220e:	and    eax,0x1
   52211:	test   eax,eax
   52213:	je     52278 <sqlite3VdbeExec+0x2dd8>
   52215:	movzx  eax,WORD PTR [r15+0x14]
   5221a:	and    eax,0x9000
   5221f:	test   eax,eax
   52221:	je     52269 <sqlite3VdbeExec+0x2dc9>
   52223:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5222e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   52239:	mov    QWORD PTR [rsp+0x190],rdi
   52241:	mov    rdi,r15
   52244:	call   52249 <sqlite3VdbeExec+0x2da9>
   52249:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   52254:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5225f:	mov    rdi,QWORD PTR [rsp+0x190]
   52267:	jmp    52270 <sqlite3VdbeExec+0x2dd0>
   52269:	mov    WORD PTR [r15+0x14],0x1
   52270:	mov    r14,r12
   52273:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   52278:	movzx  eax,WORD PTR [rdx+0x14]
   5227c:	mov    ecx,eax
   5227e:	and    ecx,0x24
   52281:	test   ecx,ecx
   52283:	je     5228d <sqlite3VdbeExec+0x2ded>
   52285:	mov    rax,QWORD PTR [rdx]
   52288:	jmp    52339 <sqlite3VdbeExec+0x2e99>
   5228d:	mov    ecx,eax
   5228f:	and    ecx,0x8
   52292:	test   ecx,ecx
   52294:	je     522e3 <sqlite3VdbeExec+0x2e43>
   52296:	movsd  xmm3,QWORD PTR [rdx]
   5229a:	movabs r11,0xc3dfffffffffffff
   522a4:	movq   xmm2,r11
   522a9:	ucomisd xmm2,xmm3
   522ad:	jbe    522bb <sqlite3VdbeExec+0x2e1b>
   522af:	movabs rax,0x8000000000000000
   522b9:	jmp    522e1 <sqlite3VdbeExec+0x2e41>
   522bb:	movabs r11,0x43dfffffffffffff
   522c5:	movq   xmm2,r11
   522ca:	ucomisd xmm3,xmm2
   522ce:	jbe    522dc <sqlite3VdbeExec+0x2e3c>
   522d0:	movabs rax,0x7fffffffffffffff
   522da:	jmp    522e1 <sqlite3VdbeExec+0x2e41>
   522dc:	cvttsd2si rax,xmm3
   522e1:	jmp    52339 <sqlite3VdbeExec+0x2e99>
   522e3:	and    eax,0x12
   522e6:	test   eax,eax
   522e8:	je     52337 <sqlite3VdbeExec+0x2e97>
   522ea:	cmp    QWORD PTR [rdx+0x8],0x0
   522ef:	je     52337 <sqlite3VdbeExec+0x2e97>
   522f1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   522fc:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   52307:	mov    QWORD PTR [rsp+0x190],rdi
   5230f:	mov    rdi,rdx
   52312:	call   52317 <sqlite3VdbeExec+0x2e77>
   52317:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   52322:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5232d:	mov    rdi,QWORD PTR [rsp+0x190]
   52335:	jmp    52339 <sqlite3VdbeExec+0x2e99>
   52337:	xor    eax,eax
   52339:	mov    QWORD PTR [rsp+0x1f0],rax
   52341:	movzx  eax,WORD PTR [r13+0x14]
   52346:	mov    ecx,eax
   52348:	and    ecx,0x24
   5234b:	test   ecx,ecx
   5234d:	je     52358 <sqlite3VdbeExec+0x2eb8>
   5234f:	mov    rax,QWORD PTR [r13+0x0]
   52353:	jmp    52406 <sqlite3VdbeExec+0x2f66>
   52358:	mov    ecx,eax
   5235a:	and    ecx,0x8
   5235d:	test   ecx,ecx
   5235f:	je     523b0 <sqlite3VdbeExec+0x2f10>
   52361:	movsd  xmm3,QWORD PTR [r13+0x0]
   52367:	movabs r11,0xc3dfffffffffffff
   52371:	movq   xmm2,r11
   52376:	ucomisd xmm2,xmm3
   5237a:	jbe    52388 <sqlite3VdbeExec+0x2ee8>
   5237c:	movabs rax,0x8000000000000000
   52386:	jmp    523ae <sqlite3VdbeExec+0x2f0e>
   52388:	movabs r11,0x43dfffffffffffff
   52392:	movq   xmm2,r11
   52397:	ucomisd xmm3,xmm2
   5239b:	jbe    523a9 <sqlite3VdbeExec+0x2f09>
   5239d:	movabs rax,0x7fffffffffffffff
   523a7:	jmp    523ae <sqlite3VdbeExec+0x2f0e>
   523a9:	cvttsd2si rax,xmm3
   523ae:	jmp    52406 <sqlite3VdbeExec+0x2f66>
   523b0:	and    eax,0x12
   523b3:	test   eax,eax
   523b5:	je     52404 <sqlite3VdbeExec+0x2f64>
   523b7:	cmp    QWORD PTR [r13+0x8],0x0
   523bc:	je     52404 <sqlite3VdbeExec+0x2f64>
   523be:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   523c9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   523d4:	mov    QWORD PTR [rsp+0x190],rdi
   523dc:	mov    rdi,r13
   523df:	call   523e4 <sqlite3VdbeExec+0x2f44>
   523e4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   523ef:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   523fa:	mov    rdi,QWORD PTR [rsp+0x190]
   52402:	jmp    52406 <sqlite3VdbeExec+0x2f66>
   52404:	xor    eax,eax
   52406:	movzx  ecx,BYTE PTR [rbp+0x0]
   5240a:	mov    edx,ecx
   5240c:	cmp    edx,0x67
   5240f:	jne    52426 <sqlite3VdbeExec+0x2f86>
   52411:	and    rax,QWORD PTR [rsp+0x1f0]
   52419:	mov    QWORD PTR [rsp+0x1f0],rax
   52421:	jmp    5251f <sqlite3VdbeExec+0x307f>
   52426:	mov    edx,ecx
   52428:	cmp    edx,0x68
   5242b:	jne    52442 <sqlite3VdbeExec+0x2fa2>
   5242d:	or     rax,QWORD PTR [rsp+0x1f0]
   52435:	mov    QWORD PTR [rsp+0x1f0],rax
   5243d:	jmp    5251f <sqlite3VdbeExec+0x307f>
   52442:	test   rax,rax
   52445:	je     5251f <sqlite3VdbeExec+0x307f>
   5244b:	test   rax,rax
   5244e:	jge    5246d <sqlite3VdbeExec+0x2fcd>
   52450:	mov    edx,0xd3
   52455:	mov    r11d,ecx
   52458:	mov    ecx,edx
   5245a:	sub    cl,r11b
   5245d:	cmp    rax,0xffffffffffffffc0
   52461:	jle    52468 <sqlite3VdbeExec+0x2fc8>
   52463:	neg    rax
   52466:	jmp    5246d <sqlite3VdbeExec+0x2fcd>
   52468:	mov    eax,0x40
   5246d:	cmp    rax,0x40
   52471:	jl     5249b <sqlite3VdbeExec+0x2ffb>
   52473:	cmp    QWORD PTR [rsp+0x1f0],0x0
   5247c:	jge    52483 <sqlite3VdbeExec+0x2fe3>
   5247e:	cmp    ecx,0x69
   52481:	jne    52487 <sqlite3VdbeExec+0x2fe7>
   52483:	xor    eax,eax
   52485:	jmp    5248e <sqlite3VdbeExec+0x2fee>
   52487:	mov    rax,0xffffffffffffffff
   5248e:	mov    QWORD PTR [rsp+0x1f0],rax
   52496:	jmp    5251f <sqlite3VdbeExec+0x307f>
   5249b:	mov    rdx,QWORD PTR [rsp+0x1f0]
   524a3:	mov    QWORD PTR [rsp+0x1e8],rdx
   524ab:	cmp    ecx,0x69
   524ae:	jne    524ca <sqlite3VdbeExec+0x302a>
   524b0:	mov    rdx,QWORD PTR [rsp+0x1e8]
   524b8:	mov    ecx,eax
   524ba:	mov    rax,rdx
   524bd:	shl    rax,cl
   524c0:	mov    QWORD PTR [rsp+0x1e8],rax
   524c8:	jmp    5250f <sqlite3VdbeExec+0x306f>
   524ca:	mov    rdx,QWORD PTR [rsp+0x1e8]
   524d2:	mov    ecx,eax
   524d4:	shr    rdx,cl
   524d7:	mov    QWORD PTR [rsp+0x1e8],rdx
   524df:	cmp    QWORD PTR [rsp+0x1f0],0x0
   524e8:	jge    5250f <sqlite3VdbeExec+0x306f>
   524ea:	mov    rdx,0xffffffffffffffff
   524f1:	mov    ecx,0x40
   524f6:	sub    rcx,rax
   524f9:	mov    rax,rdx
   524fc:	shl    rax,cl
   524ff:	or     rax,QWORD PTR [rsp+0x1e8]
   52507:	mov    QWORD PTR [rsp+0x1e8],rax
   5250f:	mov    rax,QWORD PTR [rsp+0x1e8]
   52517:	mov    QWORD PTR [rsp+0x1f0],rax
   5251f:	mov    rax,QWORD PTR [rsp+0x1f0]
   52527:	mov    QWORD PTR [r15],rax
   5252a:	movzx  eax,WORD PTR [r15+0x14]
   5252f:	and    eax,0xfffff240
   52534:	or     eax,0x4
   52537:	mov    WORD PTR [r15+0x14],ax
   5253c:	mov    r14,r12
   5253f:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   52544:	mov    QWORD PTR [rsp+0x1b0],r12
   5254c:	mov    r12,r14
   5254f:	movsxd rax,DWORD PTR [rbp+0x4]
   52553:	imul   rax,rax,0x38
   52557:	lea    r13,[rbx+rax*1]
   5255b:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52560:	mov    ecx,eax
   52562:	and    ecx,0x24
   52565:	test   ecx,ecx
   52567:	je     5257a <sqlite3VdbeExec+0x30da>
   52569:	mov    rax,QWORD PTR [r13+0x0]
   5256d:	mov    r15d,DWORD PTR [rsp+0x3fc]
   52575:	jmp    52640 <sqlite3VdbeExec+0x31a0>
   5257a:	mov    ecx,eax
   5257c:	and    ecx,0x8
   5257f:	test   ecx,ecx
   52581:	je     525da <sqlite3VdbeExec+0x313a>
   52583:	movsd  xmm3,QWORD PTR [r13+0x0]
   52589:	movabs r11,0xc3dfffffffffffff
   52593:	movq   xmm2,r11
   52598:	ucomisd xmm2,xmm3
   5259c:	jbe    525aa <sqlite3VdbeExec+0x310a>
   5259e:	movabs rax,0x8000000000000000
   525a8:	jmp    525d0 <sqlite3VdbeExec+0x3130>
   525aa:	movabs r11,0x43dfffffffffffff
   525b4:	movq   xmm2,r11
   525b9:	ucomisd xmm3,xmm2
   525bd:	jbe    525cb <sqlite3VdbeExec+0x312b>
   525bf:	movabs rax,0x7fffffffffffffff
   525c9:	jmp    525d0 <sqlite3VdbeExec+0x3130>
   525cb:	cvttsd2si rax,xmm3
   525d0:	mov    r15d,DWORD PTR [rsp+0x3fc]
   525d8:	jmp    52640 <sqlite3VdbeExec+0x31a0>
   525da:	and    eax,0x12
   525dd:	test   eax,eax
   525df:	je     52636 <sqlite3VdbeExec+0x3196>
   525e1:	cmp    QWORD PTR [r13+0x8],0x0
   525e6:	je     52636 <sqlite3VdbeExec+0x3196>
   525e8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   525f3:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   525fe:	mov    QWORD PTR [rsp+0x190],rdi
   52606:	mov    rdi,r13
   52609:	call   5260e <sqlite3VdbeExec+0x316e>
   5260e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   52619:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   52624:	mov    rdi,QWORD PTR [rsp+0x190]
   5262c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   52634:	jmp    52640 <sqlite3VdbeExec+0x31a0>
   52636:	xor    eax,eax
   52638:	mov    r15d,DWORD PTR [rsp+0x3fc]
   52640:	mov    QWORD PTR [r13+0x0],rax
   52644:	movzx  eax,WORD PTR [r13+0x14]
   52649:	and    eax,0xfffff240
   5264e:	or     eax,0x4
   52651:	mov    WORD PTR [r13+0x14],ax
   52656:	mov    rax,QWORD PTR [r13+0x0]
   5265a:	movsxd rcx,DWORD PTR [rbp+0x8]
   5265e:	add    rax,rcx
   52661:	mov    QWORD PTR [r13+0x0],rax
   52665:	mov    r14,r12
   52668:	mov    DWORD PTR [rsp+0x3fc],r15d
   52670:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   52675:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5267d:	mov    QWORD PTR [rsp+0x1b0],r12
   52685:	mov    r12,r14
   52688:	movsxd rax,DWORD PTR [rbp+0x4]
   5268c:	imul   rax,rax,0x38
   52690:	lea    r13,[rbx+rax*1]
   52694:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52699:	and    eax,0x4
   5269c:	test   eax,eax
   5269e:	jne    52765 <sqlite3VdbeExec+0x32c5>
   526a4:	mov    eax,0x43
   526a9:	mov    ecx,r15d
   526ac:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   526b7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   526c2:	mov    QWORD PTR [rsp+0x190],rdi
   526ca:	mov    rdi,r13
   526cd:	mov    rsi,rax
   526d0:	mov    rdx,rcx
   526d3:	call   526d8 <sqlite3VdbeExec+0x3238>
   526d8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   526e3:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   526ee:	movzx  eax,WORD PTR [r13+0x14]
   526f3:	and    eax,0x4
   526f6:	mov    rdi,QWORD PTR [rsp+0x190]
   526fe:	test   eax,eax
   52700:	jne    52765 <sqlite3VdbeExec+0x32c5>
   52702:	cmp    DWORD PTR [rbp+0x8],0x0
   52706:	jne    52730 <sqlite3VdbeExec+0x3290>
   52708:	mov    ebx,0x14
   5270d:	mov    r14,r12
   52710:	mov    QWORD PTR [rsp+0x1c8],rbp
   52718:	mov    rbp,rbx
   5271b:	mov    r13,QWORD PTR [rsp+0x1b0]
   52723:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5272b:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   52730:	mov    eax,DWORD PTR [rbp+0x8]
   52733:	sub    eax,0x1
   52736:	movsxd rax,eax
   52739:	imul   rax,rax,0x18
   5273d:	mov    rbp,QWORD PTR [rsp+0x1d0]
   52745:	lea    r14,[rbp+rax*1+0x0]
   5274a:	mov    DWORD PTR [rsp+0x3fc],r15d
   52752:	mov    QWORD PTR [rsp+0x1d0],rbp
   5275a:	mov    rbp,r14
   5275d:	mov    r14,r12
   52760:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   52765:	movzx  eax,WORD PTR [r13+0x14]
   5276a:	and    eax,0xfffff240
   5276f:	or     eax,0x4
   52772:	mov    WORD PTR [r13+0x14],ax
   52777:	mov    r14,r12
   5277a:	mov    DWORD PTR [rsp+0x3fc],r15d
   52782:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   52787:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5278f:	mov    QWORD PTR [rsp+0x1b0],r12
   52797:	mov    r12,r14
   5279a:	movsxd rax,DWORD PTR [rbp+0x4]
   5279e:	imul   rax,rax,0x38
   527a2:	lea    r13,[rbx+rax*1]
   527a6:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   527ab:	and    eax,0x24
   527ae:	test   eax,eax
   527b0:	je     52854 <sqlite3VdbeExec+0x33b4>
   527b6:	movzx  eax,WORD PTR [r13+0x14]
   527bb:	and    eax,0x8
   527be:	test   eax,eax
   527c0:	je     527ca <sqlite3VdbeExec+0x332a>
   527c2:	movsd  xmm3,QWORD PTR [r13+0x0]
   527c8:	jmp    5283c <sqlite3VdbeExec+0x339c>
   527ca:	movzx  eax,WORD PTR [r13+0x14]
   527cf:	and    eax,0x24
   527d2:	test   eax,eax
   527d4:	je     527e4 <sqlite3VdbeExec+0x3344>
   527d6:	mov    rax,QWORD PTR [r13+0x0]
   527da:	xorps  xmm3,xmm3
   527dd:	cvtsi2sd xmm3,rax
   527e2:	jmp    5283c <sqlite3VdbeExec+0x339c>
   527e4:	movzx  eax,WORD PTR [r13+0x14]
   527e9:	and    eax,0x12
   527ec:	test   eax,eax
   527ee:	je     52839 <sqlite3VdbeExec+0x3399>
   527f0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   527fb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   52806:	mov    QWORD PTR [rsp+0x190],rdi
   5280e:	mov    rdi,r13
   52811:	call   52816 <sqlite3VdbeExec+0x3376>
   52816:	movaps xmm3,xmm0
   52819:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   52824:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5282f:	mov    rdi,QWORD PTR [rsp+0x190]
   52837:	jmp    5283c <sqlite3VdbeExec+0x339c>
   52839:	xorps  xmm3,xmm3
   5283c:	movsd  QWORD PTR [r13+0x0],xmm3
   52842:	movzx  eax,WORD PTR [r13+0x14]
   52847:	and    eax,0xfffff240
   5284c:	or     eax,0x8
   5284f:	mov    WORD PTR [r13+0x14],ax
   52854:	mov    r14,r12
   52857:	mov    DWORD PTR [rsp+0x3fc],r15d
   5285f:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   52864:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5286c:	mov    QWORD PTR [rsp+0x1b0],r12
   52874:	mov    r12,r14
   52877:	movsxd rax,DWORD PTR [rbp+0x4]
   5287b:	imul   rax,rax,0x38
   5287f:	lea    r13,[rbx+rax*1]
   52883:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   52888:	and    eax,0x400
   5288d:	test   eax,eax
   5288f:	je     52985 <sqlite3VdbeExec+0x34e5>
   52895:	mov    eax,DWORD PTR [r13+0x10]
   52899:	add    eax,DWORD PTR [r13+0x0]
   5289d:	test   eax,eax
   5289f:	jg     528ba <sqlite3VdbeExec+0x341a>
   528a1:	movzx  eax,WORD PTR [r13+0x14]
   528a6:	and    eax,0x10
   528a9:	test   eax,eax
   528ab:	jne    528b5 <sqlite3VdbeExec+0x3415>
   528ad:	xor    r14d,r14d
   528b0:	jmp    52983 <sqlite3VdbeExec+0x34e3>
   528b5:	mov    eax,0x1
   528ba:	mov    ecx,0x1
   528bf:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   528ca:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   528d5:	mov    QWORD PTR [rsp+0x190],rdi
   528dd:	mov    rdi,r13
   528e0:	mov    rsi,rax
   528e3:	mov    rdx,rcx
   528e6:	call   528eb <sqlite3VdbeExec+0x344b>
   528eb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   528f6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   52901:	mov    rdi,QWORD PTR [rsp+0x190]
   52909:	test   eax,eax
   5290b:	je     52915 <sqlite3VdbeExec+0x3475>
   5290d:	mov    r14d,0x7
   52913:	jmp    52983 <sqlite3VdbeExec+0x34e3>
   52915:	mov    rax,QWORD PTR [r13+0x8]
   52919:	movsxd rcx,DWORD PTR [r13+0x10]
   5291d:	add    rax,rcx
   52920:	xor    ecx,ecx
   52922:	movsxd rdx,DWORD PTR [r13+0x0]
   52926:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   52931:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5293c:	mov    rdi,rax
   5293f:	mov    rsi,rcx
   52942:	call   52947 <sqlite3VdbeExec+0x34a7>
   52947:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   52952:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5295d:	mov    eax,DWORD PTR [r13+0x10]
   52961:	add    eax,DWORD PTR [r13+0x0]
   52965:	mov    DWORD PTR [r13+0x10],eax
   52969:	movzx  eax,WORD PTR [r13+0x14]
   5296e:	and    eax,0xfffff9ff
   52973:	mov    WORD PTR [r13+0x14],ax
   52978:	xor    r14d,r14d
   5297b:	mov    rdi,QWORD PTR [rsp+0x190]
   52983:	jmp    52988 <sqlite3VdbeExec+0x34e8>
   52985:	xor    r14d,r14d
   52988:	test   r14d,r14d
   5298b:	je     529b0 <sqlite3VdbeExec+0x3510>
   5298d:	mov    QWORD PTR [rsp+0x1c8],rbp
   52995:	mov    rbp,r14
   52998:	mov    r14,r12
   5299b:	mov    r13,QWORD PTR [rsp+0x1b0]
   529a3:	mov    rbx,QWORD PTR [rsp+0x1d8]
   529ab:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   529b0:	mov    eax,DWORD PTR [rbp+0x8]
   529b3:	movzx  eax,al
   529b6:	mov    ecx,r15d
   529b9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   529c4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   529cf:	mov    QWORD PTR [rsp+0x190],rdi
   529d7:	mov    rdi,r13
   529da:	mov    rsi,rax
   529dd:	mov    rdx,rcx
   529e0:	call   529e5 <sqlite3VdbeExec+0x3545>
   529e5:	mov    r13d,eax
   529e8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   529f3:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   529fe:	mov    rdi,QWORD PTR [rsp+0x190]
   52a06:	test   r13d,r13d
   52a09:	je     52a2e <sqlite3VdbeExec+0x358e>
   52a0b:	mov    r14,r12
   52a0e:	mov    QWORD PTR [rsp+0x1c8],rbp
   52a16:	mov    rbp,r13
   52a19:	mov    r13,QWORD PTR [rsp+0x1b0]
   52a21:	mov    rbx,QWORD PTR [rsp+0x1d8]
   52a29:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   52a2e:	mov    r14,r12
   52a31:	mov    DWORD PTR [rsp+0x3fc],r15d
   52a39:	mov    DWORD PTR [rsp+0x40c],r13d
   52a41:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   52a46:	mov    r15d,DWORD PTR [rsp+0x3fc]
   52a4e:	mov    r13,QWORD PTR [rsp+0x1d0]
   52a56:	mov    QWORD PTR [rsp+0x1b0],r12
   52a5e:	mov    r12d,DWORD PTR [rsp+0x414]
   52a66:	movsxd rax,DWORD PTR [rbp+0x4]
   52a6a:	imul   rax,rax,0x38
   52a6e:	mov    DWORD PTR [rsp+0x414],r12d
   52a76:	lea    r12,[rbx+rax*1]
   52a7a:	movsxd rcx,DWORD PTR [rbp+0xc]
   52a7e:	imul   rcx,rcx,0x38
   52a82:	mov    QWORD PTR [rsp+0x1d0],r13
   52a8a:	lea    r13,[rbx+rcx*1]
   52a8e:	mov    DWORD PTR [rsp+0x3fc],r15d
   52a96:	movzx  r15d,WORD PTR [rbx+rax*1+0x14]
   52a9c:	mov    QWORD PTR [rsp+0x1e0],rbx
   52aa4:	movzx  ebx,WORD PTR [rbx+rcx*1+0x14]
   52aa9:	mov    eax,r15d
   52aac:	mov    ecx,ebx
   52aae:	and    eax,ecx
   52ab0:	and    eax,0x4
   52ab3:	test   eax,eax
   52ab5:	je     52b6e <sqlite3VdbeExec+0x36ce>
   52abb:	mov    rax,QWORD PTR [r13+0x0]
   52abf:	cmp    rax,QWORD PTR [r12]
   52ac3:	jle    52af5 <sqlite3VdbeExec+0x3655>
   52ac5:	mov    rax,QWORD PTR [rip+0x0]        # 52acc <sqlite3VdbeExec+0x362c>
   52acc:	movzx  ecx,BYTE PTR [rbp+0x0]
   52ad0:	cmp    BYTE PTR [rax+rcx*1],0x0
   52ad4:	je     52aee <sqlite3VdbeExec+0x364e>
   52ad6:	mov    r12,r14
   52ad9:	mov    r15d,DWORD PTR [rsp+0x3fc]
   52ae1:	mov    rbx,QWORD PTR [rsp+0x1e0]
   52ae9:	jmp    52730 <sqlite3VdbeExec+0x3290>
   52aee:	mov    ebx,0x1
   52af3:	jmp    52b5a <sqlite3VdbeExec+0x36ba>
   52af5:	mov    rax,QWORD PTR [r13+0x0]
   52af9:	cmp    rax,QWORD PTR [r12]
   52afd:	jge    52b2f <sqlite3VdbeExec+0x368f>
   52aff:	mov    rax,QWORD PTR [rip+0x0]        # 52b06 <sqlite3VdbeExec+0x3666>
   52b06:	movzx  ecx,BYTE PTR [rbp+0x0]
   52b0a:	cmp    BYTE PTR [rax+rcx*1],0x0
   52b0e:	je     52b28 <sqlite3VdbeExec+0x3688>
   52b10:	mov    r12,r14
   52b13:	mov    r15d,DWORD PTR [rsp+0x3fc]
   52b1b:	mov    rbx,QWORD PTR [rsp+0x1e0]
   52b23:	jmp    52730 <sqlite3VdbeExec+0x3290>
   52b28:	mov    ebx,0xffffffff
   52b2d:	jmp    52b5a <sqlite3VdbeExec+0x36ba>
   52b2f:	mov    rax,QWORD PTR [rip+0x0]        # 52b36 <sqlite3VdbeExec+0x3696>
   52b36:	movzx  ecx,BYTE PTR [rbp+0x0]
   52b3a:	cmp    BYTE PTR [rax+rcx*1],0x0
   52b3e:	je     52b58 <sqlite3VdbeExec+0x36b8>
   52b40:	mov    r12,r14
   52b43:	mov    r15d,DWORD PTR [rsp+0x3fc]
   52b4b:	mov    rbx,QWORD PTR [rsp+0x1e0]
   52b53:	jmp    52730 <sqlite3VdbeExec+0x3290>
   52b58:	xor    ebx,ebx
   52b5a:	mov    DWORD PTR [rsp+0x410],ebx
   52b61:	mov    rbx,QWORD PTR [rsp+0x1e0]
   52b69:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   52b6e:	mov    eax,r15d
   52b71:	mov    ecx,ebx
   52b73:	or     eax,ecx
   52b75:	and    eax,0x1
   52b78:	test   eax,eax
   52b7a:	je     52c29 <sqlite3VdbeExec+0x3789>
   52b80:	movzx  eax,WORD PTR [rbp+0x2]
   52b84:	and    eax,0x80
   52b89:	test   eax,eax
   52b8b:	je     52bed <sqlite3VdbeExec+0x374d>
   52b8d:	mov    eax,r15d
   52b90:	mov    ecx,ebx
   52b92:	and    eax,ecx
   52b94:	and    eax,0x1
   52b97:	test   eax,eax
   52b99:	je     52bb3 <sqlite3VdbeExec+0x3713>
   52b9b:	mov    eax,ebx
   52b9d:	and    eax,0x100
   52ba2:	test   eax,eax
   52ba4:	jne    52bb3 <sqlite3VdbeExec+0x3713>
   52ba6:	xor    r11d,r11d
   52ba9:	mov    DWORD PTR [rsp+0x410],r11d
   52bb1:	jmp    52bda <sqlite3VdbeExec+0x373a>
   52bb3:	mov    eax,ebx
   52bb5:	and    eax,0x1
   52bb8:	test   eax,eax
   52bba:	je     52bcc <sqlite3VdbeExec+0x372c>
   52bbc:	mov    r11d,0xffffffff
   52bc2:	mov    DWORD PTR [rsp+0x410],r11d
   52bca:	jmp    52bda <sqlite3VdbeExec+0x373a>
   52bcc:	mov    r11d,0x1
   52bd2:	mov    DWORD PTR [rsp+0x410],r11d
   52bda:	mov    DWORD PTR [rsp+0x418],ebx
   52be1:	mov    ebx,DWORD PTR [rsp+0x410]
   52be8:	jmp    52f03 <sqlite3VdbeExec+0x3a63>
   52bed:	movzx  eax,WORD PTR [rbp+0x2]
   52bf1:	and    eax,0x10
   52bf4:	test   eax,eax
   52bf6:	je     52c10 <sqlite3VdbeExec+0x3770>
   52bf8:	mov    r12,r14
   52bfb:	mov    r15d,DWORD PTR [rsp+0x3fc]
   52c03:	mov    rbx,QWORD PTR [rsp+0x1e0]
   52c0b:	jmp    52730 <sqlite3VdbeExec+0x3290>
   52c10:	mov    ebx,0x1
   52c15:	mov    DWORD PTR [rsp+0x410],ebx
   52c1c:	mov    rbx,QWORD PTR [rsp+0x1e0]
   52c24:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   52c29:	movzx  eax,WORD PTR [rbp+0x2]
   52c2d:	and    eax,0x47
   52c30:	mov    ecx,eax
   52c32:	cmp    ecx,0x43
   52c35:	jl     52cfe <sqlite3VdbeExec+0x385e>
   52c3b:	mov    eax,r15d
   52c3e:	mov    ecx,ebx
   52c40:	or     eax,ecx
   52c42:	and    eax,0x2
   52c45:	test   eax,eax
   52c47:	je     52cf9 <sqlite3VdbeExec+0x3859>
   52c4d:	mov    eax,r15d
   52c50:	and    eax,0x2e
   52c53:	cmp    eax,0x2
   52c56:	jne    52ca6 <sqlite3VdbeExec+0x3806>
   52c58:	xor    eax,eax
   52c5a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   52c65:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   52c70:	mov    QWORD PTR [rsp+0x190],rdi
   52c78:	mov    rdi,r12
   52c7b:	mov    rsi,rax
   52c7e:	call   52c83 <sqlite3VdbeExec+0x37e3>
   52c83:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   52c8e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   52c99:	movzx  ebx,WORD PTR [r13+0x14]
   52c9e:	mov    rdi,QWORD PTR [rsp+0x190]
   52ca6:	mov    eax,ebx
   52ca8:	and    eax,0x2e
   52cab:	cmp    eax,0x2
   52cae:	jne    52cf9 <sqlite3VdbeExec+0x3859>
   52cb0:	xor    eax,eax
   52cb2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   52cbd:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   52cc8:	mov    QWORD PTR [rsp+0x190],rdi
   52cd0:	mov    rdi,r13
   52cd3:	mov    rsi,rax
   52cd6:	call   52cdb <sqlite3VdbeExec+0x383b>
   52cdb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   52ce6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   52cf1:	mov    rdi,QWORD PTR [rsp+0x190]
   52cf9:	jmp    52eac <sqlite3VdbeExec+0x3a0c>
   52cfe:	cmp    eax,0x42
   52d01:	jne    52eac <sqlite3VdbeExec+0x3a0c>
   52d07:	mov    eax,r15d
   52d0a:	mov    ecx,ebx
   52d0c:	or     eax,ecx
   52d0e:	and    eax,0x2
   52d11:	test   eax,eax
   52d13:	je     52eac <sqlite3VdbeExec+0x3a0c>
   52d19:	mov    eax,r15d
   52d1c:	and    eax,0x2
   52d1f:	test   eax,eax
   52d21:	je     52d47 <sqlite3VdbeExec+0x38a7>
   52d23:	movzx  eax,WORD PTR [r12+0x14]
   52d29:	and    eax,0xffffffd3
   52d2c:	mov    WORD PTR [r12+0x14],ax
   52d32:	mov    QWORD PTR [rsp+0x1a8],r14
   52d3a:	mov    r14d,DWORD PTR [rsp+0x3fc]
   52d42:	jmp    52dee <sqlite3VdbeExec+0x394e>
   52d47:	mov    eax,r15d
   52d4a:	and    eax,0x2c
   52d4d:	test   eax,eax
   52d4f:	jne    52d66 <sqlite3VdbeExec+0x38c6>
   52d51:	mov    QWORD PTR [rsp+0x1a8],r14
   52d59:	mov    r14d,DWORD PTR [rsp+0x3fc]
   52d61:	jmp    52dee <sqlite3VdbeExec+0x394e>
   52d66:	mov    QWORD PTR [rsp+0x1a8],r14
   52d6e:	mov    r14d,DWORD PTR [rsp+0x3fc]
   52d76:	mov    eax,r14d
   52d79:	mov    ecx,0x1
   52d7e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   52d89:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   52d94:	mov    QWORD PTR [rsp+0x190],rdi
   52d9c:	mov    rdi,r12
   52d9f:	mov    rsi,rax
   52da2:	mov    rdx,rcx
   52da5:	call   52daa <sqlite3VdbeExec+0x390a>
   52daa:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   52db5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   52dc0:	movzx  eax,WORD PTR [r12+0x14]
   52dc6:	and    eax,0xfffff240
   52dcb:	mov    ecx,r15d
   52dce:	and    ecx,0xdbf
   52dd4:	or     eax,ecx
   52dd6:	mov    r15d,eax
   52dd9:	mov    rdi,QWORD PTR [rsp+0x190]
   52de1:	cmp    r12,r13
   52de4:	jne    52dee <sqlite3VdbeExec+0x394e>
   52de6:	mov    eax,r15d
   52de9:	or     eax,0x2
   52dec:	mov    ebx,eax
   52dee:	mov    eax,ebx
   52df0:	and    eax,0x2
   52df3:	test   eax,eax
   52df5:	je     52e19 <sqlite3VdbeExec+0x3979>
   52df7:	movzx  eax,WORD PTR [r13+0x14]
   52dfc:	and    eax,0xffffffd3
   52dff:	mov    WORD PTR [r13+0x14],ax
   52e04:	mov    DWORD PTR [rsp+0x3fc],r14d
   52e0c:	mov    r14,QWORD PTR [rsp+0x1a8]
   52e14:	jmp    52eac <sqlite3VdbeExec+0x3a0c>
   52e19:	mov    eax,ebx
   52e1b:	and    eax,0x2c
   52e1e:	test   eax,eax
   52e20:	jne    52e34 <sqlite3VdbeExec+0x3994>
   52e22:	mov    DWORD PTR [rsp+0x3fc],r14d
   52e2a:	mov    r14,QWORD PTR [rsp+0x1a8]
   52e32:	jmp    52eac <sqlite3VdbeExec+0x3a0c>
   52e34:	mov    eax,r14d
   52e37:	mov    ecx,0x1
   52e3c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   52e47:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   52e52:	mov    QWORD PTR [rsp+0x190],rdi
   52e5a:	mov    rdi,r13
   52e5d:	mov    rsi,rax
   52e60:	mov    rdx,rcx
   52e63:	call   52e68 <sqlite3VdbeExec+0x39c8>
   52e68:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   52e73:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   52e7e:	movzx  eax,WORD PTR [r13+0x14]
   52e83:	and    eax,0xfffff240
   52e88:	mov    ecx,ebx
   52e8a:	and    ecx,0xdbf
   52e90:	or     eax,ecx
   52e92:	mov    ebx,eax
   52e94:	mov    rdi,QWORD PTR [rsp+0x190]
   52e9c:	mov    DWORD PTR [rsp+0x3fc],r14d
   52ea4:	mov    r14,QWORD PTR [rsp+0x1a8]
   52eac:	mov    rax,QWORD PTR [rbp+0x10]
   52eb0:	mov    DWORD PTR [rsp+0x418],ebx
   52eb7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   52ec2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   52ecd:	mov    QWORD PTR [rsp+0x190],rdi
   52ed5:	mov    rdi,r13
   52ed8:	mov    rsi,r12
   52edb:	mov    rdx,rax
   52ede:	call   52ee3 <sqlite3VdbeExec+0x3a43>
   52ee3:	mov    ebx,eax
   52ee5:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   52ef0:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   52efb:	mov    rdi,QWORD PTR [rsp+0x190]
   52f03:	test   ebx,ebx
   52f05:	jge    52f18 <sqlite3VdbeExec+0x3a78>
   52f07:	mov    rax,QWORD PTR [rip+0x0]        # 52f0e <sqlite3VdbeExec+0x3a6e>
   52f0e:	movzx  ecx,BYTE PTR [rbp+0x0]
   52f12:	movzx  eax,BYTE PTR [rax+rcx*1]
   52f16:	jmp    52f3c <sqlite3VdbeExec+0x3a9c>
   52f18:	test   ebx,ebx
   52f1a:	jne    52f2d <sqlite3VdbeExec+0x3a8d>
   52f1c:	mov    rax,QWORD PTR [rip+0x0]        # 52f23 <sqlite3VdbeExec+0x3a83>
   52f23:	movzx  ecx,BYTE PTR [rbp+0x0]
   52f27:	movzx  eax,BYTE PTR [rax+rcx*1]
   52f2b:	jmp    52f3c <sqlite3VdbeExec+0x3a9c>
   52f2d:	mov    rax,QWORD PTR [rip+0x0]        # 52f34 <sqlite3VdbeExec+0x3a94>
   52f34:	movzx  ecx,BYTE PTR [rbp+0x0]
   52f38:	movzx  eax,BYTE PTR [rax+rcx*1]
   52f3c:	mov    DWORD PTR [rsp+0x410],ebx
   52f43:	mov    ebx,DWORD PTR [rsp+0x418]
   52f4a:	mov    WORD PTR [r13+0x14],bx
   52f4f:	mov    WORD PTR [r12+0x14],r15w
   52f55:	test   eax,eax
   52f57:	je     52f71 <sqlite3VdbeExec+0x3ad1>
   52f59:	mov    r12,r14
   52f5c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   52f64:	mov    rbx,QWORD PTR [rsp+0x1e0]
   52f6c:	jmp    52730 <sqlite3VdbeExec+0x3290>
   52f71:	mov    rbx,QWORD PTR [rsp+0x1e0]
   52f79:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   52f7e:	mov    r15d,DWORD PTR [rsp+0x3fc]
   52f86:	mov    r13,QWORD PTR [rsp+0x1d0]
   52f8e:	mov    QWORD PTR [rsp+0x1b0],r12
   52f96:	mov    r12d,DWORD PTR [rsp+0x414]
   52f9e:	mov    DWORD PTR [rsp+0x414],r12d
   52fa6:	mov    r12d,DWORD PTR [rsp+0x410]
   52fae:	test   r12d,r12d
   52fb1:	jne    52fcb <sqlite3VdbeExec+0x3b2b>
   52fb3:	mov    QWORD PTR [rsp+0x1d0],r13
   52fbb:	mov    DWORD PTR [rsp+0x410],r12d
   52fc3:	mov    r12,r14
   52fc6:	jmp    52730 <sqlite3VdbeExec+0x3290>
   52fcb:	mov    DWORD PTR [rsp+0x3fc],r15d
   52fd3:	mov    QWORD PTR [rsp+0x1d0],r13
   52fdb:	mov    DWORD PTR [rsp+0x410],r12d
   52fe3:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   52fe8:	mov    r15d,DWORD PTR [rsp+0x3fc]
   52ff0:	mov    r13,QWORD PTR [rsp+0x1d0]
   52ff8:	mov    QWORD PTR [rsp+0x1b0],r12
   53000:	mov    r12d,DWORD PTR [rsp+0x410]
   53008:	mov    DWORD PTR [rsp+0x3fc],r15d
   53010:	mov    QWORD PTR [rsp+0x1d0],r13
   53018:	mov    DWORD PTR [rsp+0x410],r12d
   53020:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   53025:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5302d:	mov    r13,QWORD PTR [rsp+0x1d0]
   53035:	mov    QWORD PTR [rsp+0x1b0],r12
   5303d:	mov    r12d,DWORD PTR [rsp+0x410]
   53045:	movzx  eax,WORD PTR [rbp+0x2]
   53049:	and    eax,0x1
   5304c:	test   eax,eax
   5304e:	jne    5305d <sqlite3VdbeExec+0x3bbd>
   53050:	mov    QWORD PTR [rsp+0x1d0],r13
   53058:	xor    r13d,r13d
   5305b:	jmp    5306d <sqlite3VdbeExec+0x3bcd>
   5305d:	mov    QWORD PTR [rsp+0x1d0],r13
   53065:	mov    rax,QWORD PTR [rbp-0x8]
   53069:	lea    r13,[rax+0x4]
   5306d:	mov    QWORD PTR [rsp+0x1e8],r13
   53075:	mov    r13d,DWORD PTR [rbp+0xc]
   53079:	mov    DWORD PTR [rsp+0x418],r13d
   53081:	mov    r13,QWORD PTR [rbp+0x10]
   53085:	mov    DWORD PTR [rsp+0x410],r12d
   5308d:	mov    r12d,DWORD PTR [rbp+0x4]
   53091:	mov    DWORD PTR [rsp+0x41c],r12d
   53099:	mov    r12d,DWORD PTR [rbp+0x8]
   5309d:	mov    QWORD PTR [rsp+0x1a8],r14
   530a5:	mov    DWORD PTR [rsp+0x3fc],r15d
   530ad:	mov    r14d,DWORD PTR [rsp+0x41c]
   530b5:	mov    QWORD PTR [rsp+0x1c8],rbp
   530bd:	mov    ebp,DWORD PTR [rsp+0x410]
   530c4:	xor    r15d,r15d
   530c7:	jmp    5323b <sqlite3VdbeExec+0x3d9b>
   530cc:	mov    DWORD PTR [rsp+0x418],r12d
   530d4:	mov    DWORD PTR [rsp+0x41c],r14d
   530dc:	mov    r14,QWORD PTR [rsp+0x1a8]
   530e4:	mov    r12,r15
   530e7:	mov    r15d,DWORD PTR [rsp+0x3fc]
   530ef:	mov    rbp,QWORD PTR [rsp+0x1c8]
   530f7:	mov    DWORD PTR [rsp+0x3fc],r15d
   530ff:	mov    r15,r12
   53102:	mov    rax,r15
   53105:	mov    rcx,QWORD PTR [r13+rax*8+0x20]
   5310a:	mov    rdx,QWORD PTR [r13+0x18]
   5310e:	movzx  eax,BYTE PTR [rdx+rax*1]
   53112:	mov    QWORD PTR [rsp+0x1a8],r14
   5311a:	mov    r14d,eax
   5311d:	and    r14d,0x1
   53121:	mov    DWORD PTR [rsp+0x424],r14d
   53129:	mov    r14d,DWORD PTR [rsp+0x41c]
   53131:	lea    eax,[r14+r12*1]
   53135:	imul   rax,rax,0x38
   53139:	add    rax,rbx
   5313c:	mov    QWORD PTR [rsp+0x1c8],rbp
   53144:	mov    ebp,DWORD PTR [rsp+0x420]
   5314b:	lea    edx,[rbp+r12*1+0x0]
   53150:	imul   rdx,rdx,0x38
   53154:	add    rdx,rbx
   53157:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   53162:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5316d:	mov    QWORD PTR [rsp+0x190],rdi
   53175:	mov    rdi,rax
   53178:	mov    rsi,rdx
   5317b:	mov    rdx,rcx
   5317e:	call   53183 <sqlite3VdbeExec+0x3ce3>
   53183:	mov    ebp,eax
   53185:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   53190:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5319b:	mov    rdi,QWORD PTR [rsp+0x190]
   531a3:	test   ebp,ebp
   531a5:	je     5322f <sqlite3VdbeExec+0x3d8f>
   531ab:	mov    rax,QWORD PTR [r13+0x18]
   531af:	mov    rcx,r15
   531b2:	movzx  eax,BYTE PTR [rax+rcx*1]
   531b6:	and    eax,0x2
   531b9:	test   eax,eax
   531bb:	jne    531c7 <sqlite3VdbeExec+0x3d27>
   531bd:	mov    r14d,DWORD PTR [rsp+0x424]
   531c5:	jmp    5320c <sqlite3VdbeExec+0x3d6c>
   531c7:	lea    eax,[r14+r12*1]
   531cb:	imul   rax,rax,0x38
   531cf:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   531d4:	and    eax,0x1
   531d7:	test   eax,eax
   531d9:	jne    53202 <sqlite3VdbeExec+0x3d62>
   531db:	mov    r13d,DWORD PTR [rsp+0x420]
   531e3:	lea    eax,[r13+r12*1+0x0]
   531e8:	imul   rax,rax,0x38
   531ec:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   531f1:	and    eax,0x1
   531f4:	test   eax,eax
   531f6:	jne    53202 <sqlite3VdbeExec+0x3d62>
   531f8:	mov    r14d,DWORD PTR [rsp+0x424]
   53200:	jmp    5320c <sqlite3VdbeExec+0x3d6c>
   53202:	neg    ebp
   53204:	mov    r14d,DWORD PTR [rsp+0x424]
   5320c:	test   r14d,r14d
   5320f:	je     53213 <sqlite3VdbeExec+0x3d73>
   53211:	neg    ebp
   53213:	mov    r14,QWORD PTR [rsp+0x1a8]
   5321b:	mov    DWORD PTR [rsp+0x410],ebp
   53222:	mov    rbp,QWORD PTR [rsp+0x1c8]
   5322a:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5322f:	mov    r12d,DWORD PTR [rsp+0x420]
   53237:	add    r15d,0x1
   5323b:	mov    DWORD PTR [rsp+0x420],r12d
   53243:	mov    r12d,DWORD PTR [rsp+0x418]
   5324b:	cmp    r15d,r12d
   5324e:	jge    53213 <sqlite3VdbeExec+0x3d73>
   53250:	mov    rbp,QWORD PTR [rsp+0x1e8]
   53258:	test   rbp,rbp
   5325b:	je     530cc <sqlite3VdbeExec+0x3c2c>
   53261:	mov    rax,r15
   53264:	mov    ebp,DWORD PTR [rbp+rax*4+0x0]
   53268:	mov    DWORD PTR [rsp+0x418],r12d
   53270:	mov    DWORD PTR [rsp+0x41c],r14d
   53278:	mov    r14,QWORD PTR [rsp+0x1a8]
   53280:	mov    r12,rbp
   53283:	mov    rbp,QWORD PTR [rsp+0x1c8]
   5328b:	jmp    53102 <sqlite3VdbeExec+0x3c62>
   53290:	mov    r15d,DWORD PTR [rsp+0x3fc]
   53298:	mov    r13,QWORD PTR [rsp+0x1d0]
   532a0:	mov    QWORD PTR [rsp+0x1b0],r12
   532a8:	mov    r12d,DWORD PTR [rsp+0x414]
   532b0:	mov    DWORD PTR [rsp+0x414],r12d
   532b8:	mov    r12d,DWORD PTR [rsp+0x410]
   532c0:	test   r12d,r12d
   532c3:	jge    532d9 <sqlite3VdbeExec+0x3e39>
   532c5:	mov    eax,DWORD PTR [rbp+0x4]
   532c8:	sub    eax,0x1
   532cb:	movsxd rax,eax
   532ce:	imul   rax,rax,0x18
   532d2:	lea    rbp,[r13+rax*1+0x0]
   532d7:	jmp    53304 <sqlite3VdbeExec+0x3e64>
   532d9:	test   r12d,r12d
   532dc:	jne    532f2 <sqlite3VdbeExec+0x3e52>
   532de:	mov    eax,DWORD PTR [rbp+0x8]
   532e1:	sub    eax,0x1
   532e4:	movsxd rax,eax
   532e7:	imul   rax,rax,0x18
   532eb:	lea    rbp,[r13+rax*1+0x0]
   532f0:	jmp    53304 <sqlite3VdbeExec+0x3e64>
   532f2:	mov    eax,DWORD PTR [rbp+0xc]
   532f5:	sub    eax,0x1
   532f8:	movsxd rax,eax
   532fb:	imul   rax,rax,0x18
   532ff:	lea    rbp,[r13+rax*1+0x0]
   53304:	mov    DWORD PTR [rsp+0x3fc],r15d
   5330c:	mov    QWORD PTR [rsp+0x1d0],r13
   53314:	mov    DWORD PTR [rsp+0x410],r12d
   5331c:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   53321:	mov    r15d,DWORD PTR [rsp+0x3fc]
   53329:	mov    r13,QWORD PTR [rsp+0x1d0]
   53331:	mov    QWORD PTR [rsp+0x1b0],r12
   53339:	mov    r12d,DWORD PTR [rsp+0x414]
   53341:	movsxd rax,DWORD PTR [rbp+0x4]
   53345:	imul   rax,rax,0x38
   53349:	lea    rcx,[rbx+rax*1]
   5334d:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53352:	and    eax,0x24
   53355:	test   eax,eax
   53357:	je     53371 <sqlite3VdbeExec+0x3ed1>
   53359:	mov    DWORD PTR [rsp+0x414],r12d
   53361:	xor    r12d,r12d
   53364:	cmp    QWORD PTR [rcx],0x0
   53368:	setne  r12b
   5336c:	jmp    53425 <sqlite3VdbeExec+0x3f85>
   53371:	mov    DWORD PTR [rsp+0x414],r12d
   53379:	movzx  eax,WORD PTR [rcx+0x14]
   5337d:	and    eax,0x1
   53380:	test   eax,eax
   53382:	je     5338f <sqlite3VdbeExec+0x3eef>
   53384:	mov    r12d,0x2
   5338a:	jmp    53425 <sqlite3VdbeExec+0x3f85>
   5338f:	movzx  eax,WORD PTR [rcx+0x14]
   53393:	and    eax,0x8
   53396:	test   eax,eax
   53398:	je     533a0 <sqlite3VdbeExec+0x3f00>
   5339a:	movsd  xmm3,QWORD PTR [rcx]
   5339e:	jmp    5340f <sqlite3VdbeExec+0x3f6f>
   533a0:	movzx  eax,WORD PTR [rcx+0x14]
   533a4:	and    eax,0x24
   533a7:	test   eax,eax
   533a9:	je     533b8 <sqlite3VdbeExec+0x3f18>
   533ab:	mov    rax,QWORD PTR [rcx]
   533ae:	xorps  xmm3,xmm3
   533b1:	cvtsi2sd xmm3,rax
   533b6:	jmp    5340f <sqlite3VdbeExec+0x3f6f>
   533b8:	movzx  eax,WORD PTR [rcx+0x14]
   533bc:	and    eax,0x12
   533bf:	test   eax,eax
   533c1:	je     5340c <sqlite3VdbeExec+0x3f6c>
   533c3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   533ce:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   533d9:	mov    QWORD PTR [rsp+0x190],rdi
   533e1:	mov    rdi,rcx
   533e4:	call   533e9 <sqlite3VdbeExec+0x3f49>
   533e9:	movaps xmm3,xmm0
   533ec:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   533f7:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   53402:	mov    rdi,QWORD PTR [rsp+0x190]
   5340a:	jmp    5340f <sqlite3VdbeExec+0x3f6f>
   5340c:	xorps  xmm3,xmm3
   5340f:	xorps  xmm2,xmm2
   53412:	xor    eax,eax
   53414:	ucomisd xmm3,xmm2
   53418:	setne  al
   5341b:	setp   r11b
   5341f:	or     al,r11b
   53422:	mov    r12d,eax
   53425:	movsxd rax,DWORD PTR [rbp+0x8]
   53429:	imul   rax,rax,0x38
   5342d:	lea    rcx,[rbx+rax*1]
   53431:	mov    edx,0x2
   53436:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   5343b:	and    eax,0x24
   5343e:	test   eax,eax
   53440:	je     53450 <sqlite3VdbeExec+0x3fb0>
   53442:	xor    eax,eax
   53444:	cmp    QWORD PTR [rcx],0x0
   53448:	setne  al
   5344b:	jmp    534f6 <sqlite3VdbeExec+0x4056>
   53450:	movzx  eax,WORD PTR [rcx+0x14]
   53454:	and    eax,0x1
   53457:	test   eax,eax
   53459:	je     53463 <sqlite3VdbeExec+0x3fc3>
   5345b:	mov    rax,rdx
   5345e:	jmp    534f6 <sqlite3VdbeExec+0x4056>
   53463:	movzx  eax,WORD PTR [rcx+0x14]
   53467:	and    eax,0x8
   5346a:	test   eax,eax
   5346c:	je     53474 <sqlite3VdbeExec+0x3fd4>
   5346e:	movsd  xmm2,QWORD PTR [rcx]
   53472:	jmp    534e3 <sqlite3VdbeExec+0x4043>
   53474:	movzx  eax,WORD PTR [rcx+0x14]
   53478:	and    eax,0x24
   5347b:	test   eax,eax
   5347d:	je     5348c <sqlite3VdbeExec+0x3fec>
   5347f:	mov    rax,QWORD PTR [rcx]
   53482:	xorps  xmm2,xmm2
   53485:	cvtsi2sd xmm2,rax
   5348a:	jmp    534e3 <sqlite3VdbeExec+0x4043>
   5348c:	movzx  eax,WORD PTR [rcx+0x14]
   53490:	and    eax,0x12
   53493:	test   eax,eax
   53495:	je     534e0 <sqlite3VdbeExec+0x4040>
   53497:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   534a2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   534ad:	mov    QWORD PTR [rsp+0x190],rdi
   534b5:	mov    rdi,rcx
   534b8:	call   534bd <sqlite3VdbeExec+0x401d>
   534bd:	movaps xmm2,xmm0
   534c0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   534cb:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   534d6:	mov    rdi,QWORD PTR [rsp+0x190]
   534de:	jmp    534e3 <sqlite3VdbeExec+0x4043>
   534e0:	xorps  xmm2,xmm2
   534e3:	xorps  xmm3,xmm3
   534e6:	xor    eax,eax
   534e8:	ucomisd xmm2,xmm3
   534ec:	setne  al
   534ef:	setp   r11b
   534f3:	or     al,r11b
   534f6:	cmp    BYTE PTR [rbp+0x0],0x2c
   534fa:	jne    5350f <sqlite3VdbeExec+0x406f>
   534fc:	lea    rcx,[rip+0x0]        # 53503 <sqlite3VdbeExec+0x4063>
   53503:	lea    edx,[r12+r12*2]
   53507:	add    eax,edx
   53509:	movzx  eax,BYTE PTR [rcx+rax*1]
   5350d:	jmp    53520 <sqlite3VdbeExec+0x4080>
   5350f:	lea    rcx,[rip+0x0]        # 53516 <sqlite3VdbeExec+0x4076>
   53516:	lea    edx,[r12+r12*2]
   5351a:	add    eax,edx
   5351c:	movzx  eax,BYTE PTR [rcx+rax*1]
   53520:	movsxd rcx,DWORD PTR [rbp+0xc]
   53524:	imul   rcx,rcx,0x38
   53528:	cmp    eax,0x2
   5352b:	jne    53541 <sqlite3VdbeExec+0x40a1>
   5352d:	movzx  eax,WORD PTR [rbx+rcx*1+0x14]
   53532:	and    eax,0xfffff240
   53537:	or     eax,0x1
   5353a:	mov    WORD PTR [rbx+rcx*1+0x14],ax
   5353f:	jmp    53557 <sqlite3VdbeExec+0x40b7>
   53541:	mov    QWORD PTR [rbx+rcx*1],rax
   53545:	movzx  eax,WORD PTR [rbx+rcx*1+0x14]
   5354a:	and    eax,0xfffff240
   5354f:	or     eax,0x4
   53552:	mov    WORD PTR [rbx+rcx*1+0x14],ax
   53557:	mov    DWORD PTR [rsp+0x3fc],r15d
   5355f:	mov    QWORD PTR [rsp+0x1d0],r13
   53567:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5356c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   53574:	mov    r13,QWORD PTR [rsp+0x1d0]
   5357c:	mov    QWORD PTR [rsp+0x1b0],r12
   53584:	movsxd rax,DWORD PTR [rbp+0x8]
   53588:	imul   rax,rax,0x38
   5358c:	lea    r12,[rbx+rax*1]
   53590:	movsxd rax,DWORD PTR [rbp+0x4]
   53594:	imul   rax,rax,0x38
   53598:	lea    rcx,[rbx+rax*1]
   5359c:	movsxd rdx,DWORD PTR [rbp+0xc]
   535a0:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   535a5:	and    eax,0x24
   535a8:	test   eax,eax
   535aa:	je     535ba <sqlite3VdbeExec+0x411a>
   535ac:	xor    eax,eax
   535ae:	cmp    QWORD PTR [rcx],0x0
   535b2:	setne  al
   535b5:	jmp    53660 <sqlite3VdbeExec+0x41c0>
   535ba:	movzx  eax,WORD PTR [rcx+0x14]
   535be:	and    eax,0x1
   535c1:	test   eax,eax
   535c3:	je     535cd <sqlite3VdbeExec+0x412d>
   535c5:	mov    rax,rdx
   535c8:	jmp    53660 <sqlite3VdbeExec+0x41c0>
   535cd:	movzx  eax,WORD PTR [rcx+0x14]
   535d1:	and    eax,0x8
   535d4:	test   eax,eax
   535d6:	je     535de <sqlite3VdbeExec+0x413e>
   535d8:	movsd  xmm3,QWORD PTR [rcx]
   535dc:	jmp    5364d <sqlite3VdbeExec+0x41ad>
   535de:	movzx  eax,WORD PTR [rcx+0x14]
   535e2:	and    eax,0x24
   535e5:	test   eax,eax
   535e7:	je     535f6 <sqlite3VdbeExec+0x4156>
   535e9:	mov    rax,QWORD PTR [rcx]
   535ec:	xorps  xmm3,xmm3
   535ef:	cvtsi2sd xmm3,rax
   535f4:	jmp    5364d <sqlite3VdbeExec+0x41ad>
   535f6:	movzx  eax,WORD PTR [rcx+0x14]
   535fa:	and    eax,0x12
   535fd:	test   eax,eax
   535ff:	je     5364a <sqlite3VdbeExec+0x41aa>
   53601:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5360c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   53617:	mov    QWORD PTR [rsp+0x190],rdi
   5361f:	mov    rdi,rcx
   53622:	call   53627 <sqlite3VdbeExec+0x4187>
   53627:	movaps xmm3,xmm0
   5362a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   53635:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   53640:	mov    rdi,QWORD PTR [rsp+0x190]
   53648:	jmp    5364d <sqlite3VdbeExec+0x41ad>
   5364a:	xorps  xmm3,xmm3
   5364d:	xorps  xmm2,xmm2
   53650:	xor    eax,eax
   53652:	ucomisd xmm3,xmm2
   53656:	setne  al
   53659:	setp   r11b
   5365d:	or     al,r11b
   53660:	movsxd rcx,DWORD PTR [rbp+0x10]
   53664:	xor    rax,rcx
   53667:	movzx  ecx,WORD PTR [r12+0x14]
   5366d:	and    ecx,0x9000
   53673:	test   ecx,ecx
   53675:	je     536c0 <sqlite3VdbeExec+0x4220>
   53677:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   53682:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5368d:	mov    QWORD PTR [rsp+0x190],rdi
   53695:	mov    rdi,r12
   53698:	mov    rsi,rax
   5369b:	call   536a0 <sqlite3VdbeExec+0x4200>
   536a0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   536ab:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   536b6:	mov    rdi,QWORD PTR [rsp+0x190]
   536be:	jmp    536cc <sqlite3VdbeExec+0x422c>
   536c0:	mov    QWORD PTR [r12],rax
   536c4:	mov    WORD PTR [r12+0x14],0x4
   536cc:	mov    DWORD PTR [rsp+0x3fc],r15d
   536d4:	mov    QWORD PTR [rsp+0x1d0],r13
   536dc:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   536e1:	mov    r15d,DWORD PTR [rsp+0x3fc]
   536e9:	mov    r13,QWORD PTR [rsp+0x1d0]
   536f1:	mov    QWORD PTR [rsp+0x1b0],r12
   536f9:	movsxd rax,DWORD PTR [rbp+0x4]
   536fd:	imul   rax,rax,0x38
   53701:	lea    rcx,[rbx+rax*1]
   53705:	movsxd rdx,DWORD PTR [rbp+0x8]
   53709:	imul   rdx,rdx,0x38
   5370d:	lea    r12,[rbx+rdx*1]
   53711:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53716:	and    eax,0x1
   53719:	test   eax,eax
   5371b:	jne    53850 <sqlite3VdbeExec+0x43b0>
   53721:	xor    eax,eax
   53723:	movzx  edx,WORD PTR [rcx+0x14]
   53727:	and    edx,0x24
   5372a:	test   edx,edx
   5372c:	je     5373c <sqlite3VdbeExec+0x429c>
   5372e:	xor    eax,eax
   53730:	cmp    QWORD PTR [rcx],0x0
   53734:	setne  al
   53737:	jmp    537df <sqlite3VdbeExec+0x433f>
   5373c:	movzx  edx,WORD PTR [rcx+0x14]
   53740:	and    edx,0x1
   53743:	test   edx,edx
   53745:	je     5374c <sqlite3VdbeExec+0x42ac>
   53747:	jmp    537df <sqlite3VdbeExec+0x433f>
   5374c:	movzx  eax,WORD PTR [rcx+0x14]
   53750:	and    eax,0x8
   53753:	test   eax,eax
   53755:	je     5375d <sqlite3VdbeExec+0x42bd>
   53757:	movsd  xmm2,QWORD PTR [rcx]
   5375b:	jmp    537cc <sqlite3VdbeExec+0x432c>
   5375d:	movzx  eax,WORD PTR [rcx+0x14]
   53761:	and    eax,0x24
   53764:	test   eax,eax
   53766:	je     53775 <sqlite3VdbeExec+0x42d5>
   53768:	mov    rax,QWORD PTR [rcx]
   5376b:	xorps  xmm2,xmm2
   5376e:	cvtsi2sd xmm2,rax
   53773:	jmp    537cc <sqlite3VdbeExec+0x432c>
   53775:	movzx  eax,WORD PTR [rcx+0x14]
   53779:	and    eax,0x12
   5377c:	test   eax,eax
   5377e:	je     537c9 <sqlite3VdbeExec+0x4329>
   53780:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5378b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   53796:	mov    QWORD PTR [rsp+0x190],rdi
   5379e:	mov    rdi,rcx
   537a1:	call   537a6 <sqlite3VdbeExec+0x4306>
   537a6:	movaps xmm2,xmm0
   537a9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   537b4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   537bf:	mov    rdi,QWORD PTR [rsp+0x190]
   537c7:	jmp    537cc <sqlite3VdbeExec+0x432c>
   537c9:	xorps  xmm2,xmm2
   537cc:	xorps  xmm3,xmm3
   537cf:	xor    eax,eax
   537d1:	ucomisd xmm2,xmm3
   537d5:	setne  al
   537d8:	setp   r11b
   537dc:	or     al,r11b
   537df:	test   eax,eax
   537e1:	mov    eax,0x0
   537e6:	sete   al
   537e9:	movzx  ecx,WORD PTR [r12+0x14]
   537ef:	and    ecx,0x9000
   537f5:	test   ecx,ecx
   537f7:	je     53842 <sqlite3VdbeExec+0x43a2>
   537f9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   53804:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5380f:	mov    QWORD PTR [rsp+0x190],rdi
   53817:	mov    rdi,r12
   5381a:	mov    rsi,rax
   5381d:	call   53822 <sqlite3VdbeExec+0x4382>
   53822:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5382d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   53838:	mov    rdi,QWORD PTR [rsp+0x190]
   53840:	jmp    538ad <sqlite3VdbeExec+0x440d>
   53842:	mov    QWORD PTR [r12],rax
   53846:	mov    WORD PTR [r12+0x14],0x4
   5384e:	jmp    538ad <sqlite3VdbeExec+0x440d>
   53850:	movzx  eax,WORD PTR [r12+0x14]
   53856:	and    eax,0x9000
   5385b:	test   eax,eax
   5385d:	je     538a5 <sqlite3VdbeExec+0x4405>
   5385f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5386a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   53875:	mov    QWORD PTR [rsp+0x190],rdi
   5387d:	mov    rdi,r12
   53880:	call   53885 <sqlite3VdbeExec+0x43e5>
   53885:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   53890:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5389b:	mov    rdi,QWORD PTR [rsp+0x190]
   538a3:	jmp    538ad <sqlite3VdbeExec+0x440d>
   538a5:	mov    WORD PTR [r12+0x14],0x1
   538ad:	mov    DWORD PTR [rsp+0x3fc],r15d
   538b5:	mov    QWORD PTR [rsp+0x1d0],r13
   538bd:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   538c2:	mov    r15d,DWORD PTR [rsp+0x3fc]
   538ca:	mov    r13,QWORD PTR [rsp+0x1d0]
   538d2:	mov    QWORD PTR [rsp+0x1b0],r12
   538da:	movsxd rax,DWORD PTR [rbp+0x4]
   538de:	imul   rax,rax,0x38
   538e2:	lea    r12,[rbx+rax*1]
   538e6:	movsxd rax,DWORD PTR [rbp+0x8]
   538ea:	imul   rax,rax,0x38
   538ee:	mov    QWORD PTR [rsp+0x1d0],r13
   538f6:	lea    r13,[rbx+rax*1]
   538fa:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   538ff:	and    eax,0x9000
   53904:	test   eax,eax
   53906:	je     5394e <sqlite3VdbeExec+0x44ae>
   53908:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   53913:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5391e:	mov    QWORD PTR [rsp+0x190],rdi
   53926:	mov    rdi,r13
   53929:	call   5392e <sqlite3VdbeExec+0x448e>
   5392e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   53939:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   53944:	mov    rdi,QWORD PTR [rsp+0x190]
   5394c:	jmp    53955 <sqlite3VdbeExec+0x44b5>
   5394e:	mov    WORD PTR [r13+0x14],0x1
   53955:	movzx  eax,WORD PTR [r12+0x14]
   5395b:	and    eax,0x1
   5395e:	test   eax,eax
   53960:	jne    53a3b <sqlite3VdbeExec+0x459b>
   53966:	mov    WORD PTR [r13+0x14],0x4
   5396d:	movzx  eax,WORD PTR [r12+0x14]
   53973:	mov    ecx,eax
   53975:	and    ecx,0x24
   53978:	test   ecx,ecx
   5397a:	je     53985 <sqlite3VdbeExec+0x44e5>
   5397c:	mov    rax,QWORD PTR [r12]
   53980:	jmp    53a34 <sqlite3VdbeExec+0x4594>
   53985:	mov    ecx,eax
   53987:	and    ecx,0x8
   5398a:	test   ecx,ecx
   5398c:	je     539dd <sqlite3VdbeExec+0x453d>
   5398e:	movsd  xmm3,QWORD PTR [r12]
   53994:	movabs r11,0xc3dfffffffffffff
   5399e:	movq   xmm2,r11
   539a3:	ucomisd xmm2,xmm3
   539a7:	jbe    539b5 <sqlite3VdbeExec+0x4515>
   539a9:	movabs rax,0x8000000000000000
   539b3:	jmp    539db <sqlite3VdbeExec+0x453b>
   539b5:	movabs r11,0x43dfffffffffffff
   539bf:	movq   xmm2,r11
   539c4:	ucomisd xmm3,xmm2
   539c8:	jbe    539d6 <sqlite3VdbeExec+0x4536>
   539ca:	movabs rax,0x7fffffffffffffff
   539d4:	jmp    539db <sqlite3VdbeExec+0x453b>
   539d6:	cvttsd2si rax,xmm3
   539db:	jmp    53a34 <sqlite3VdbeExec+0x4594>
   539dd:	and    eax,0x12
   539e0:	test   eax,eax
   539e2:	je     53a32 <sqlite3VdbeExec+0x4592>
   539e4:	cmp    QWORD PTR [r12+0x8],0x0
   539ea:	je     53a32 <sqlite3VdbeExec+0x4592>
   539ec:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   539f7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   53a02:	mov    QWORD PTR [rsp+0x190],rdi
   53a0a:	mov    rdi,r12
   53a0d:	call   53a12 <sqlite3VdbeExec+0x4572>
   53a12:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   53a1d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   53a28:	mov    rdi,QWORD PTR [rsp+0x190]
   53a30:	jmp    53a34 <sqlite3VdbeExec+0x4594>
   53a32:	xor    eax,eax
   53a34:	not    rax
   53a37:	mov    QWORD PTR [r13+0x0],rax
   53a3b:	mov    DWORD PTR [rsp+0x3fc],r15d
   53a43:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   53a48:	mov    r15d,DWORD PTR [rsp+0x3fc]
   53a50:	mov    QWORD PTR [rsp+0x1b0],r12
   53a58:	cmp    QWORD PTR [rdi+0x108],0x0
   53a60:	je     53b09 <sqlite3VdbeExec+0x4669>
   53a66:	mov    rax,rbp
   53a69:	sub    rax,QWORD PTR [rdi+0x88]
   53a70:	movabs rdx,0x2aaaaaaaaaaaaaab
   53a7a:	imul   rdx
   53a7d:	sar    rdx,0x2
   53a81:	mov    rax,rdx
   53a84:	shr    rax,0x3f
   53a88:	add    rdx,rax
   53a8b:	mov    rax,rdx
   53a8e:	mov    rcx,QWORD PTR [rdi+0x108]
   53a95:	mov    rcx,QWORD PTR [rcx+0x28]
   53a99:	mov    edx,eax
   53a9b:	shr    edx,0x3
   53a9e:	movzx  ecx,BYTE PTR [rcx+rdx*1]
   53aa2:	mov    edx,ecx
   53aa4:	mov    esi,0x1
   53aa9:	mov    ecx,eax
   53aab:	and    ecx,0x7
   53aae:	shl    esi,cl
   53ab0:	and    edx,esi
   53ab2:	test   edx,edx
   53ab4:	je     53abe <sqlite3VdbeExec+0x461e>
   53ab6:	mov    r12,r14
   53ab9:	jmp    52730 <sqlite3VdbeExec+0x3290>
   53abe:	mov    rcx,QWORD PTR [rdi+0x108]
   53ac5:	mov    rdx,QWORD PTR [rcx+0x28]
   53ac9:	mov    ecx,eax
   53acb:	shr    ecx,0x3
   53ace:	mov    rsi,rcx
   53ad1:	movzx  ecx,BYTE PTR [rdx+rsi*1]
   53ad5:	mov    r8d,ecx
   53ad8:	mov    r9d,0x1
   53ade:	and    eax,0x7
   53ae1:	mov    ecx,eax
   53ae3:	mov    rax,r9
   53ae6:	shl    eax,cl
   53ae8:	or     r8d,eax
   53aeb:	mov    BYTE PTR [rdx+rsi*1],r8b
   53aef:	mov    rax,QWORD PTR [rdi+0x88]
   53af6:	mov    eax,DWORD PTR [rax+0x4]
   53af9:	mov    DWORD PTR [rbp+0x4],eax
   53afc:	mov    DWORD PTR [rsp+0x3fc],r15d
   53b04:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   53b09:	mov    rax,QWORD PTR [rdi+0x88]
   53b10:	mov    eax,DWORD PTR [rax+0x4]
   53b13:	cmp    eax,DWORD PTR [rbp+0x4]
   53b16:	jne    53aef <sqlite3VdbeExec+0x464f>
   53b18:	mov    r12,r14
   53b1b:	jmp    52730 <sqlite3VdbeExec+0x3290>
   53b20:	mov    r15d,DWORD PTR [rsp+0x3fc]
   53b28:	mov    QWORD PTR [rsp+0x1b0],r12
   53b30:	movsxd rax,DWORD PTR [rbp+0x4]
   53b34:	imul   rax,rax,0x38
   53b38:	lea    rcx,[rbx+rax*1]
   53b3c:	mov    edx,DWORD PTR [rbp+0xc]
   53b3f:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53b44:	and    eax,0x24
   53b47:	test   eax,eax
   53b49:	je     53b59 <sqlite3VdbeExec+0x46b9>
   53b4b:	cmp    QWORD PTR [rcx],0x0
   53b4f:	je     53b68 <sqlite3VdbeExec+0x46c8>
   53b51:	mov    r12,r14
   53b54:	jmp    52730 <sqlite3VdbeExec+0x3290>
   53b59:	movzx  eax,WORD PTR [rcx+0x14]
   53b5d:	and    eax,0x1
   53b60:	test   eax,eax
   53b62:	je     53b75 <sqlite3VdbeExec+0x46d5>
   53b64:	test   edx,edx
   53b66:	jne    53b51 <sqlite3VdbeExec+0x46b1>
   53b68:	mov    DWORD PTR [rsp+0x3fc],r15d
   53b70:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   53b75:	movzx  eax,WORD PTR [rcx+0x14]
   53b79:	and    eax,0x8
   53b7c:	test   eax,eax
   53b7e:	je     53b86 <sqlite3VdbeExec+0x46e6>
   53b80:	movsd  xmm3,QWORD PTR [rcx]
   53b84:	jmp    53bf5 <sqlite3VdbeExec+0x4755>
   53b86:	movzx  eax,WORD PTR [rcx+0x14]
   53b8a:	and    eax,0x24
   53b8d:	test   eax,eax
   53b8f:	je     53b9e <sqlite3VdbeExec+0x46fe>
   53b91:	mov    rax,QWORD PTR [rcx]
   53b94:	xorps  xmm3,xmm3
   53b97:	cvtsi2sd xmm3,rax
   53b9c:	jmp    53bf5 <sqlite3VdbeExec+0x4755>
   53b9e:	movzx  eax,WORD PTR [rcx+0x14]
   53ba2:	and    eax,0x12
   53ba5:	test   eax,eax
   53ba7:	je     53bf2 <sqlite3VdbeExec+0x4752>
   53ba9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   53bb4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   53bbf:	mov    QWORD PTR [rsp+0x190],rdi
   53bc7:	mov    rdi,rcx
   53bca:	call   53bcf <sqlite3VdbeExec+0x472f>
   53bcf:	movaps xmm3,xmm0
   53bd2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   53bdd:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   53be8:	mov    rdi,QWORD PTR [rsp+0x190]
   53bf0:	jmp    53bf5 <sqlite3VdbeExec+0x4755>
   53bf2:	xorps  xmm3,xmm3
   53bf5:	xorps  xmm2,xmm2
   53bf8:	xor    eax,eax
   53bfa:	ucomisd xmm3,xmm2
   53bfe:	setne  al
   53c01:	setp   r11b
   53c05:	or     al,r11b
   53c08:	test   eax,eax
   53c0a:	mov    eax,0x0
   53c0f:	setne  al
   53c12:	test   eax,eax
   53c14:	jne    53b51 <sqlite3VdbeExec+0x46b1>
   53c1a:	jmp    53b68 <sqlite3VdbeExec+0x46c8>
   53c1f:	mov    r15d,DWORD PTR [rsp+0x3fc]
   53c27:	mov    QWORD PTR [rsp+0x1b0],r12
   53c2f:	movsxd rax,DWORD PTR [rbp+0x4]
   53c33:	imul   rax,rax,0x38
   53c37:	lea    rcx,[rbx+rax*1]
   53c3b:	mov    edx,DWORD PTR [rbp+0xc]
   53c3e:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53c43:	and    eax,0x24
   53c46:	test   eax,eax
   53c48:	je     53c58 <sqlite3VdbeExec+0x47b8>
   53c4a:	cmp    QWORD PTR [rcx],0x0
   53c4e:	jne    53c67 <sqlite3VdbeExec+0x47c7>
   53c50:	mov    r12,r14
   53c53:	jmp    52730 <sqlite3VdbeExec+0x3290>
   53c58:	movzx  eax,WORD PTR [rcx+0x14]
   53c5c:	and    eax,0x1
   53c5f:	test   eax,eax
   53c61:	je     53c74 <sqlite3VdbeExec+0x47d4>
   53c63:	test   edx,edx
   53c65:	jne    53c50 <sqlite3VdbeExec+0x47b0>
   53c67:	mov    DWORD PTR [rsp+0x3fc],r15d
   53c6f:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   53c74:	movzx  eax,WORD PTR [rcx+0x14]
   53c78:	and    eax,0x8
   53c7b:	test   eax,eax
   53c7d:	je     53c85 <sqlite3VdbeExec+0x47e5>
   53c7f:	movsd  xmm2,QWORD PTR [rcx]
   53c83:	jmp    53cf4 <sqlite3VdbeExec+0x4854>
   53c85:	movzx  eax,WORD PTR [rcx+0x14]
   53c89:	and    eax,0x24
   53c8c:	test   eax,eax
   53c8e:	je     53c9d <sqlite3VdbeExec+0x47fd>
   53c90:	mov    rax,QWORD PTR [rcx]
   53c93:	xorps  xmm2,xmm2
   53c96:	cvtsi2sd xmm2,rax
   53c9b:	jmp    53cf4 <sqlite3VdbeExec+0x4854>
   53c9d:	movzx  eax,WORD PTR [rcx+0x14]
   53ca1:	and    eax,0x12
   53ca4:	test   eax,eax
   53ca6:	je     53cf1 <sqlite3VdbeExec+0x4851>
   53ca8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   53cb3:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   53cbe:	mov    QWORD PTR [rsp+0x190],rdi
   53cc6:	mov    rdi,rcx
   53cc9:	call   53cce <sqlite3VdbeExec+0x482e>
   53cce:	movaps xmm2,xmm0
   53cd1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   53cdc:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   53ce7:	mov    rdi,QWORD PTR [rsp+0x190]
   53cef:	jmp    53cf4 <sqlite3VdbeExec+0x4854>
   53cf1:	xorps  xmm2,xmm2
   53cf4:	xorps  xmm3,xmm3
   53cf7:	xor    eax,eax
   53cf9:	ucomisd xmm2,xmm3
   53cfd:	setne  al
   53d00:	setp   r11b
   53d04:	or     al,r11b
   53d07:	test   eax,eax
   53d09:	mov    eax,0x0
   53d0e:	sete   al
   53d11:	test   eax,eax
   53d13:	jne    53c50 <sqlite3VdbeExec+0x47b0>
   53d19:	jmp    53c67 <sqlite3VdbeExec+0x47c7>
   53d1e:	mov    r15d,DWORD PTR [rsp+0x3fc]
   53d26:	mov    QWORD PTR [rsp+0x1b0],r12
   53d2e:	movsxd rax,DWORD PTR [rbp+0x4]
   53d32:	imul   rax,rax,0x38
   53d36:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53d3b:	and    eax,0x1
   53d3e:	test   eax,eax
   53d40:	je     53d4a <sqlite3VdbeExec+0x48aa>
   53d42:	mov    r12,r14
   53d45:	jmp    52730 <sqlite3VdbeExec+0x3290>
   53d4a:	mov    DWORD PTR [rsp+0x3fc],r15d
   53d52:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   53d57:	mov    r15d,DWORD PTR [rsp+0x3fc]
   53d5f:	mov    QWORD PTR [rsp+0x1b0],r12
   53d67:	cmp    DWORD PTR [rbp+0x4],0x0
   53d6b:	jl     53dc5 <sqlite3VdbeExec+0x4925>
   53d6d:	mov    rax,QWORD PTR [rdi+0x78]
   53d71:	movsxd rcx,DWORD PTR [rbp+0x4]
   53d75:	mov    rax,QWORD PTR [rax+rcx*8]
   53d79:	mov    ecx,DWORD PTR [rbp+0xc]
   53d7c:	movzx  edx,WORD PTR [rax+0x42]
   53d80:	cmp    ecx,edx
   53d82:	jge    53db3 <sqlite3VdbeExec+0x4913>
   53d84:	movsxd rcx,DWORD PTR [rbp+0xc]
   53d88:	mov    eax,DWORD PTR [rax+rcx*4+0x70]
   53d8c:	cmp    eax,0xc
   53d8f:	jb     53da6 <sqlite3VdbeExec+0x4906>
   53d91:	and    eax,0x1
   53d94:	test   eax,eax
   53d96:	je     53d9f <sqlite3VdbeExec+0x48ff>
   53d98:	mov    eax,0x4
   53d9d:	jmp    53da4 <sqlite3VdbeExec+0x4904>
   53d9f:	mov    eax,0x8
   53da4:	jmp    53db1 <sqlite3VdbeExec+0x4911>
   53da6:	lea    rcx,[rip+0x0]        # 53dad <sqlite3VdbeExec+0x490d>
   53dad:	movzx  eax,BYTE PTR [rcx+rax*1]
   53db1:	jmp    53dc3 <sqlite3VdbeExec+0x4923>
   53db3:	mov    eax,0x1
   53db8:	mov    ecx,DWORD PTR [rbp+0x10]
   53dbb:	sub    ecx,0x1
   53dbe:	shl    eax,cl
   53dc0:	movzx  eax,ax
   53dc3:	jmp    53ded <sqlite3VdbeExec+0x494d>
   53dc5:	mov    eax,0x1
   53dca:	movsxd rcx,DWORD PTR [rbp+0xc]
   53dce:	imul   rcx,rcx,0x38
   53dd2:	lea    rdx,[rip+0x0]        # 53dd9 <sqlite3VdbeExec+0x4939>
   53dd9:	movzx  ecx,WORD PTR [rbx+rcx*1+0x14]
   53dde:	and    ecx,0x3f
   53de1:	movzx  ecx,BYTE PTR [rdx+rcx*1]
   53de5:	sub    ecx,0x1
   53de8:	shl    eax,cl
   53dea:	movzx  eax,ax
   53ded:	movzx  ecx,WORD PTR [rbp+0x2]
   53df1:	and    eax,ecx
   53df3:	test   eax,eax
   53df5:	je     53dff <sqlite3VdbeExec+0x495f>
   53df7:	mov    r12,r14
   53dfa:	jmp    52730 <sqlite3VdbeExec+0x3290>
   53dff:	mov    DWORD PTR [rsp+0x3fc],r15d
   53e07:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   53e0c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   53e14:	mov    QWORD PTR [rsp+0x1b0],r12
   53e1c:	movsxd rax,DWORD PTR [rbp+0x4]
   53e20:	imul   rax,rax,0x38
   53e24:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53e29:	and    eax,0x1
   53e2c:	test   eax,eax
   53e2e:	jne    53e44 <sqlite3VdbeExec+0x49a4>
   53e30:	movsxd rax,DWORD PTR [rbp+0xc]
   53e34:	imul   rax,rax,0x38
   53e38:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53e3d:	and    eax,0x1
   53e40:	test   eax,eax
   53e42:	je     53eac <sqlite3VdbeExec+0x4a0c>
   53e44:	movsxd rax,DWORD PTR [rbp+0x8]
   53e48:	imul   rax,rax,0x38
   53e4c:	lea    rcx,[rbx+rax*1]
   53e50:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53e55:	and    eax,0x9000
   53e5a:	test   eax,eax
   53e5c:	je     53ea4 <sqlite3VdbeExec+0x4a04>
   53e5e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   53e69:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   53e74:	mov    QWORD PTR [rsp+0x190],rdi
   53e7c:	mov    rdi,rcx
   53e7f:	call   53e84 <sqlite3VdbeExec+0x49e4>
   53e84:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   53e8f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   53e9a:	mov    rdi,QWORD PTR [rsp+0x190]
   53ea2:	jmp    53f1e <sqlite3VdbeExec+0x4a7e>
   53ea4:	mov    WORD PTR [rcx+0x14],0x1
   53eaa:	jmp    53f1e <sqlite3VdbeExec+0x4a7e>
   53eac:	movsxd rax,DWORD PTR [rbp+0x8]
   53eb0:	imul   rax,rax,0x38
   53eb4:	lea    rcx,[rbx+rax*1]
   53eb8:	xor    edx,edx
   53eba:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53ebf:	and    eax,0x9000
   53ec4:	test   eax,eax
   53ec6:	je     53f11 <sqlite3VdbeExec+0x4a71>
   53ec8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   53ed3:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   53ede:	mov    QWORD PTR [rsp+0x190],rdi
   53ee6:	mov    rdi,rcx
   53ee9:	mov    rsi,rdx
   53eec:	call   53ef1 <sqlite3VdbeExec+0x4a51>
   53ef1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   53efc:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   53f07:	mov    rdi,QWORD PTR [rsp+0x190]
   53f0f:	jmp    53f1e <sqlite3VdbeExec+0x4a7e>
   53f11:	mov    QWORD PTR [rcx],0x0
   53f18:	mov    WORD PTR [rcx+0x14],0x4
   53f1e:	mov    DWORD PTR [rsp+0x3fc],r15d
   53f26:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   53f2b:	mov    r15d,DWORD PTR [rsp+0x3fc]
   53f33:	mov    QWORD PTR [rsp+0x1b0],r12
   53f3b:	movsxd rax,DWORD PTR [rbp+0x4]
   53f3f:	imul   rax,rax,0x38
   53f43:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53f48:	and    eax,0x1
   53f4b:	test   eax,eax
   53f4d:	jne    53f57 <sqlite3VdbeExec+0x4ab7>
   53f4f:	mov    r12,r14
   53f52:	jmp    52730 <sqlite3VdbeExec+0x3290>
   53f57:	mov    DWORD PTR [rsp+0x3fc],r15d
   53f5f:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   53f64:	mov    r15d,DWORD PTR [rsp+0x3fc]
   53f6c:	mov    QWORD PTR [rsp+0x1b0],r12
   53f74:	mov    rax,QWORD PTR [rdi+0x78]
   53f78:	movsxd rcx,DWORD PTR [rbp+0x4]
   53f7c:	mov    rax,QWORD PTR [rax+rcx*8]
   53f80:	test   rax,rax
   53f83:	je     53ff9 <sqlite3VdbeExec+0x4b59>
   53f85:	cmp    BYTE PTR [rax+0x2],0x0
   53f89:	je     53ff9 <sqlite3VdbeExec+0x4b59>
   53f8b:	movsxd rax,DWORD PTR [rbp+0xc]
   53f8f:	imul   rax,rax,0x38
   53f93:	lea    rcx,[rbx+rax*1]
   53f97:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   53f9c:	and    eax,0x9000
   53fa1:	test   eax,eax
   53fa3:	je     53feb <sqlite3VdbeExec+0x4b4b>
   53fa5:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   53fb0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   53fbb:	mov    QWORD PTR [rsp+0x190],rdi
   53fc3:	mov    rdi,rcx
   53fc6:	call   53fcb <sqlite3VdbeExec+0x4b2b>
   53fcb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   53fd6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   53fe1:	mov    rdi,QWORD PTR [rsp+0x190]
   53fe9:	jmp    53ff1 <sqlite3VdbeExec+0x4b51>
   53feb:	mov    WORD PTR [rcx+0x14],0x1
   53ff1:	mov    r12,r14
   53ff4:	jmp    52730 <sqlite3VdbeExec+0x3290>
   53ff9:	mov    DWORD PTR [rsp+0x3fc],r15d
   54001:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   54006:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5400e:	mov    QWORD PTR [rsp+0x1b0],r12
   54016:	mov    rax,QWORD PTR [rdi+0x78]
   5401a:	movsxd rcx,DWORD PTR [rbp+0x4]
   5401e:	mov    r12,QWORD PTR [rax+rcx*8]
   54022:	mov    r13d,DWORD PTR [rbp+0x8]
   54026:	mov    DWORD PTR [rsp+0x3fc],r15d
   5402e:	jmp    540fb <sqlite3VdbeExec+0x4c5b>
   54033:	movsxd rax,DWORD PTR [rbp+0xc]
   54037:	imul   rax,rax,0x38
   5403b:	lea    rcx,[rbx+rax*1]
   5403f:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   54044:	and    eax,0x9000
   54049:	test   eax,eax
   5404b:	je     54093 <sqlite3VdbeExec+0x4bf3>
   5404d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   54058:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54063:	mov    QWORD PTR [rsp+0x190],rdi
   5406b:	mov    rdi,rcx
   5406e:	call   54073 <sqlite3VdbeExec+0x4bd3>
   54073:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5407e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   54089:	mov    rdi,QWORD PTR [rsp+0x190]
   54091:	jmp    54099 <sqlite3VdbeExec+0x4bf9>
   54093:	mov    WORD PTR [rcx+0x14],0x1
   54099:	mov    DWORD PTR [rsp+0x3fc],r15d
   540a1:	mov    DWORD PTR [rsp+0x40c],r12d
   540a9:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   540ae:	mov    QWORD PTR [rsp+0x1e0],rbx
   540b6:	mov    rbx,QWORD PTR [r12+0x28]
   540bb:	cmp    BYTE PTR [r12+0x3],0x0
   540c1:	je     54288 <sqlite3VdbeExec+0x4de8>
   540c7:	cmp    QWORD PTR [r12+0x8],0x0
   540cd:	je     54175 <sqlite3VdbeExec+0x4cd5>
   540d3:	mov    rax,QWORD PTR [r12+0x8]
   540d8:	lea    ecx,[r13+0x1]
   540dc:	mov    eax,DWORD PTR [rax+rcx*4]
   540df:	test   eax,eax
   540e1:	jbe    54175 <sqlite3VdbeExec+0x4cd5>
   540e7:	mov    r12,QWORD PTR [r12+0x20]
   540ec:	mov    r13d,eax
   540ef:	sub    r13d,0x1
   540f3:	mov    rbx,QWORD PTR [rsp+0x1e0]
   540fb:	mov    r15,QWORD PTR [r12+0x50]
   54100:	mov    eax,DWORD PTR [r12+0x18]
   54105:	cmp    eax,DWORD PTR [rdi+0x2c]
   54108:	je     545e0 <sqlite3VdbeExec+0x5140>
   5410e:	cmp    BYTE PTR [r12+0x2],0x0
   54114:	je     540ae <sqlite3VdbeExec+0x4c0e>
   54116:	cmp    BYTE PTR [r12],0x3
   5411b:	je     54132 <sqlite3VdbeExec+0x4c92>
   5411d:	mov    r15d,DWORD PTR [rsp+0x3fc]
   54125:	mov    r12d,DWORD PTR [rsp+0x40c]
   5412d:	jmp    54033 <sqlite3VdbeExec+0x4b93>
   54132:	cmp    DWORD PTR [r12+0x1c],0x0
   54138:	jg     5414f <sqlite3VdbeExec+0x4caf>
   5413a:	mov    r15d,DWORD PTR [rsp+0x3fc]
   54142:	mov    r12d,DWORD PTR [rsp+0x40c]
   5414a:	jmp    54033 <sqlite3VdbeExec+0x4b93>
   5414f:	movsxd rax,DWORD PTR [r12+0x1c]
   54154:	imul   rax,rax,0x38
   54158:	mov    ecx,DWORD PTR [rbx+rax*1+0x10]
   5415c:	mov    DWORD PTR [r12+0x64],ecx
   54161:	mov    DWORD PTR [r12+0x60],ecx
   54166:	mov    rax,QWORD PTR [rbx+rax*1+0x8]
   5416b:	mov    QWORD PTR [r12+0x58],rax
   54170:	jmp    5433b <sqlite3VdbeExec+0x4e9b>
   54175:	mov    QWORD PTR [rsp+0x1a8],r14
   5417d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   54188:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54193:	mov    QWORD PTR [rsp+0x190],rdi
   5419b:	mov    rdi,r12
   5419e:	call   541a3 <sqlite3VdbeExec+0x4d03>
   541a3:	mov    r14d,eax
   541a6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   541b1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   541bc:	mov    rdi,QWORD PTR [rsp+0x190]
   541c4:	test   r14d,r14d
   541c7:	je     541f1 <sqlite3VdbeExec+0x4d51>
   541c9:	mov    QWORD PTR [rsp+0x1c8],rbp
   541d1:	mov    rbp,r14
   541d4:	mov    r14,QWORD PTR [rsp+0x1a8]
   541dc:	mov    r13,QWORD PTR [rsp+0x1b0]
   541e4:	mov    rbx,QWORD PTR [rsp+0x1d8]
   541ec:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   541f1:	mov    DWORD PTR [rsp+0x40c],r14d
   541f9:	mov    r14,QWORD PTR [rsp+0x1a8]
   54201:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5420c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54217:	mov    QWORD PTR [rsp+0x190],rdi
   5421f:	mov    rdi,rbx
   54222:	call   54227 <sqlite3VdbeExec+0x4d87>
   54227:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54232:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5423d:	mov    eax,DWORD PTR [rbx+0x40]
   54240:	mov    DWORD PTR [r12+0x60],eax
   54245:	movzx  eax,WORD PTR [rbx+0x44]
   54249:	mov    rcx,QWORD PTR [rbx+0x88]
   54250:	mov    rcx,QWORD PTR [rcx+0x58]
   54254:	sub    rcx,QWORD PTR [rbx+0x38]
   54258:	mov    rdi,QWORD PTR [rsp+0x190]
   54260:	cmp    eax,ecx
   54262:	jle    54325 <sqlite3VdbeExec+0x4e85>
   54268:	xor    eax,eax
   5426a:	mov    rcx,QWORD PTR [rbx+0x88]
   54271:	mov    rcx,QWORD PTR [rcx+0x58]
   54275:	sub    rcx,QWORD PTR [rbx+0x38]
   54279:	cmp    eax,ecx
   5427b:	jle    54316 <sqlite3VdbeExec+0x4e76>
   54281:	xor    eax,eax
   54283:	jmp    54325 <sqlite3VdbeExec+0x4e85>
   54288:	xor    eax,eax
   5428a:	movzx  ecx,BYTE PTR [rbx]
   5428d:	cmp    eax,ecx
   5428f:	je     54201 <sqlite3VdbeExec+0x4d61>
   54295:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   542a0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   542ab:	mov    QWORD PTR [rsp+0x190],rdi
   542b3:	mov    rdi,r12
   542b6:	call   542bb <sqlite3VdbeExec+0x4e1b>
   542bb:	mov    ebx,eax
   542bd:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   542c8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   542d3:	mov    rdi,QWORD PTR [rsp+0x190]
   542db:	test   ebx,ebx
   542dd:	je     542ff <sqlite3VdbeExec+0x4e5f>
   542df:	mov    QWORD PTR [rsp+0x1c8],rbp
   542e7:	mov    rbp,rbx
   542ea:	mov    r13,QWORD PTR [rsp+0x1b0]
   542f2:	mov    rbx,QWORD PTR [rsp+0x1d8]
   542fa:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   542ff:	mov    r15,QWORD PTR [rsp+0x1e0]
   54307:	mov    DWORD PTR [rsp+0x40c],ebx
   5430e:	mov    rbx,r15
   54311:	jmp    540fb <sqlite3VdbeExec+0x4c5b>
   54316:	mov    rax,QWORD PTR [rbx+0x88]
   5431d:	mov    rax,QWORD PTR [rax+0x58]
   54321:	sub    rax,QWORD PTR [rbx+0x38]
   54325:	mov    DWORD PTR [r12+0x64],eax
   5432a:	mov    rax,QWORD PTR [rbx+0x38]
   5432e:	mov    QWORD PTR [r12+0x58],rax
   54333:	mov    rbx,QWORD PTR [rsp+0x1e0]
   5433b:	mov    eax,DWORD PTR [rdi+0x2c]
   5433e:	mov    DWORD PTR [r12+0x18],eax
   54343:	mov    rax,QWORD PTR [r12+0x58]
   54348:	movzx  eax,BYTE PTR [rax]
   5434b:	mov    DWORD PTR [r15],eax
   5434e:	cmp    eax,0x80
   54353:	jae    54363 <sqlite3VdbeExec+0x4ec3>
   54355:	mov    DWORD PTR [r12+0x38],0x1
   5435e:	jmp    54454 <sqlite3VdbeExec+0x4fb4>
   54363:	mov    rax,QWORD PTR [r12+0x58]
   54368:	movzx  ecx,BYTE PTR [rax+0x1]
   5436c:	and    ecx,0x80
   54372:	test   ecx,ecx
   54374:	jne    54392 <sqlite3VdbeExec+0x4ef2>
   54376:	movzx  ecx,BYTE PTR [rax]
   54379:	and    ecx,0x7f
   5437c:	shl    ecx,0x7
   5437f:	movzx  eax,BYTE PTR [rax+0x1]
   54383:	or     ecx,eax
   54385:	mov    DWORD PTR [r15],ecx
   54388:	mov    eax,0x2
   5438d:	jmp    5444f <sqlite3VdbeExec+0x4faf>
   54392:	movzx  ecx,BYTE PTR [rax+0x2]
   54396:	and    ecx,0x80
   5439c:	test   ecx,ecx
   5439e:	jne    543c8 <sqlite3VdbeExec+0x4f28>
   543a0:	movzx  ecx,BYTE PTR [rax]
   543a3:	and    ecx,0x7f
   543a6:	shl    ecx,0xe
   543a9:	movzx  edx,BYTE PTR [rax+0x1]
   543ad:	and    edx,0x7f
   543b0:	shl    edx,0x7
   543b3:	or     ecx,edx
   543b5:	movzx  eax,BYTE PTR [rax+0x2]
   543b9:	or     ecx,eax
   543bb:	mov    DWORD PTR [r15],ecx
   543be:	mov    eax,0x3
   543c3:	jmp    5444f <sqlite3VdbeExec+0x4faf>
   543c8:	mov    DWORD PTR [rsp+0x41c],r13d
   543d0:	mov    r13,rbx
   543d3:	lea    rbx,[rsp+0x1f0]
   543db:	mov    rcx,rbx
   543de:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   543e9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   543f4:	mov    QWORD PTR [rsp+0x190],rdi
   543fc:	mov    rdi,rax
   543ff:	mov    rsi,rcx
   54402:	call   54407 <sqlite3VdbeExec+0x4f67>
   54407:	movzx  eax,al
   5440a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54415:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   54420:	mov    ecx,0xffffffff
   54425:	and    rcx,QWORD PTR [rbx]
   54428:	mov    rdi,QWORD PTR [rsp+0x190]
   54430:	cmp    rcx,QWORD PTR [rbx]
   54433:	je     5443e <sqlite3VdbeExec+0x4f9e>
   54435:	mov    DWORD PTR [r15],0xffffffff
   5443c:	jmp    54444 <sqlite3VdbeExec+0x4fa4>
   5443e:	mov    rcx,QWORD PTR [rbx]
   54441:	mov    DWORD PTR [r15],ecx
   54444:	mov    rbx,r13
   54447:	mov    r13d,DWORD PTR [rsp+0x41c]
   5444f:	mov    DWORD PTR [r12+0x38],eax
   54454:	mov    WORD PTR [r12+0x42],0x0
   5445c:	mov    eax,DWORD PTR [r12+0x64]
   54461:	cmp    eax,DWORD PTR [r15]
   54464:	jae    544be <sqlite3VdbeExec+0x501e>
   54466:	mov    QWORD PTR [r12+0x58],0x0
   5446f:	mov    DWORD PTR [r12+0x64],0x0
   54478:	cmp    DWORD PTR [r15],0x18003
   5447f:	ja     5448b <sqlite3VdbeExec+0x4feb>
   54481:	mov    eax,DWORD PTR [r15]
   54484:	cmp    eax,DWORD PTR [r12+0x60]
   54489:	jbe    544d0 <sqlite3VdbeExec+0x5030>
   5448b:	mov    r13,QWORD PTR [rsp+0x1d0]
   54493:	cmp    DWORD PTR [r13+0xc],0x0
   54498:	jle    550ed <sqlite3VdbeExec+0x5c4d>
   5449e:	mov    eax,DWORD PTR [r13+0xc]
   544a2:	sub    eax,0x1
   544a5:	movsxd rax,eax
   544a8:	imul   rax,rax,0x18
   544ac:	lea    rbp,[r13+rax*1+0x0]
   544b1:	mov    QWORD PTR [rsp+0x1d0],r13
   544b9:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   544be:	mov    DWORD PTR [rsp+0x41c],r13d
   544c6:	mov    r13,QWORD PTR [r12+0x58]
   544cb:	jmp    546c0 <sqlite3VdbeExec+0x5220>
   544d0:	mov    DWORD PTR [rsp+0x41c],r13d
   544d8:	mov    r13d,DWORD PTR [rsp+0x41c]
   544e0:	movzx  eax,WORD PTR [r12+0x42]
   544e6:	cmp    eax,r13d
   544e9:	ja     54be3 <sqlite3VdbeExec+0x5743>
   544ef:	mov    eax,DWORD PTR [r12+0x38]
   544f4:	cmp    eax,DWORD PTR [r15]
   544f7:	jae    54a8e <sqlite3VdbeExec+0x55ee>
   544fd:	cmp    QWORD PTR [r12+0x58],0x0
   54503:	jne    546a0 <sqlite3VdbeExec+0x5200>
   54509:	mov    QWORD PTR [rsp+0x1a8],r14
   54511:	lea    r14,[rsp+0x2c0]
   54519:	mov    rax,r14
   5451c:	xor    ecx,ecx
   5451e:	mov    edx,0x38
   54523:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5452e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54539:	mov    QWORD PTR [rsp+0x190],rdi
   54541:	mov    rdi,rax
   54544:	mov    rsi,rcx
   54547:	call   5454c <sqlite3VdbeExec+0x50ac>
   5454c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54557:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   54562:	mov    rax,QWORD PTR [r12+0x28]
   54567:	mov    ecx,DWORD PTR [r15]
   5456a:	mov    rdx,r14
   5456d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   54578:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54583:	mov    rdi,rax
   54586:	mov    rsi,rcx
   54589:	call   5458e <sqlite3VdbeExec+0x50ee>
   5458e:	mov    r14d,eax
   54591:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5459c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   545a7:	mov    rdi,QWORD PTR [rsp+0x190]
   545af:	test   r14d,r14d
   545b2:	je     5466b <sqlite3VdbeExec+0x51cb>
   545b8:	mov    QWORD PTR [rsp+0x1c8],rbp
   545c0:	mov    rbp,r14
   545c3:	mov    r14,QWORD PTR [rsp+0x1a8]
   545cb:	mov    r13,QWORD PTR [rsp+0x1b0]
   545d3:	mov    rbx,QWORD PTR [rsp+0x1d8]
   545db:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   545e0:	mov    rax,QWORD PTR [r12+0x28]
   545e5:	xor    ecx,ecx
   545e7:	movzx  eax,BYTE PTR [rax]
   545ea:	cmp    ecx,eax
   545ec:	je     544e0 <sqlite3VdbeExec+0x5040>
   545f2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   545fd:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54608:	mov    QWORD PTR [rsp+0x190],rdi
   54610:	mov    rdi,r12
   54613:	call   54618 <sqlite3VdbeExec+0x5178>
   54618:	mov    r15d,eax
   5461b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54626:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   54631:	mov    rdi,QWORD PTR [rsp+0x190]
   54639:	test   r15d,r15d
   5463c:	je     5465e <sqlite3VdbeExec+0x51be>
   5463e:	mov    QWORD PTR [rsp+0x1c8],rbp
   54646:	mov    rbp,r15
   54649:	mov    r13,QWORD PTR [rsp+0x1b0]
   54651:	mov    rbx,QWORD PTR [rsp+0x1d8]
   54659:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5465e:	mov    DWORD PTR [rsp+0x40c],r15d
   54666:	jmp    540fb <sqlite3VdbeExec+0x4c5b>
   5466b:	mov    DWORD PTR [rsp+0x418],r14d
   54673:	mov    r14,QWORD PTR [rsp+0x2c8]
   5467b:	mov    DWORD PTR [rsp+0x41c],r13d
   54683:	mov    r11d,DWORD PTR [rsp+0x418]
   5468b:	mov    DWORD PTR [rsp+0x40c],r11d
   54693:	mov    r13,r14
   54696:	mov    r14,QWORD PTR [rsp+0x1a8]
   5469e:	jmp    546c0 <sqlite3VdbeExec+0x5220>
   546a0:	mov    QWORD PTR [rsp+0x1a8],r14
   546a8:	mov    r14,QWORD PTR [r12+0x58]
   546ad:	mov    DWORD PTR [rsp+0x41c],r13d
   546b5:	mov    r13,r14
   546b8:	mov    r14,QWORD PTR [rsp+0x1a8]
   546c0:	movzx  eax,WORD PTR [r12+0x42]
   546c6:	mov    QWORD PTR [rsp+0x1e0],rbx
   546ce:	mov    ebx,eax
   546d0:	mov    rax,rbx
   546d3:	mov    eax,DWORD PTR [r15+rax*4]
   546d7:	mov    DWORD PTR [rsp+0x418],ebx
   546de:	mov    rbx,rax
   546e1:	mov    eax,DWORD PTR [r12+0x38]
   546e6:	mov    QWORD PTR [rsp+0x1f8],rbx
   546ee:	lea    rbx,[r13+rax*1+0x0]
   546f3:	mov    eax,DWORD PTR [r15]
   546f6:	mov    QWORD PTR [rsp+0x200],rbx
   546fe:	lea    rbx,[r13+rax*1+0x0]
   54703:	mov    QWORD PTR [rsp+0x1e8],r15
   5470b:	mov    QWORD PTR [rsp+0x1f0],r13
   54713:	mov    QWORD PTR [rsp+0x208],rbx
   5471b:	mov    r13d,DWORD PTR [rsp+0x418]
   54723:	mov    rbx,QWORD PTR [rsp+0x200]
   5472b:	mov    r15,QWORD PTR [rsp+0x1f8]
   54733:	movsxd rax,r13d
   54736:	movzx  ecx,BYTE PTR [rbx]
   54739:	mov    DWORD PTR [rsp+0x420],ecx
   54740:	mov    DWORD PTR [r12+rax*4+0x70],ecx
   54745:	cmp    ecx,0x80
   5474b:	jae    5476e <sqlite3VdbeExec+0x52ce>
   5474d:	add    rbx,0x1
   54751:	mov    eax,DWORD PTR [rsp+0x420]
   54758:	movzx  eax,al
   5475b:	lea    rcx,[rip+0x0]        # 54762 <sqlite3VdbeExec+0x52c2>
   54762:	movzx  eax,BYTE PTR [rcx+rax*1]
   54766:	add    r15,rax
   54769:	jmp    5489b <sqlite3VdbeExec+0x53fb>
   5476e:	movzx  eax,BYTE PTR [rbx+0x1]
   54772:	and    eax,0x80
   54777:	test   eax,eax
   54779:	jne    5479b <sqlite3VdbeExec+0x52fb>
   5477b:	movzx  eax,BYTE PTR [rbx]
   5477e:	and    eax,0x7f
   54781:	shl    eax,0x7
   54784:	movzx  ecx,BYTE PTR [rbx+0x1]
   54788:	or     eax,ecx
   5478a:	mov    DWORD PTR [rsp+0x420],eax
   54791:	mov    eax,0x2
   54796:	jmp    54866 <sqlite3VdbeExec+0x53c6>
   5479b:	movzx  eax,BYTE PTR [rbx+0x2]
   5479f:	and    eax,0x80
   547a4:	test   eax,eax
   547a6:	jne    547d4 <sqlite3VdbeExec+0x5334>
   547a8:	movzx  eax,BYTE PTR [rbx]
   547ab:	and    eax,0x7f
   547ae:	shl    eax,0xe
   547b1:	movzx  ecx,BYTE PTR [rbx+0x1]
   547b5:	and    ecx,0x7f
   547b8:	shl    ecx,0x7
   547bb:	or     eax,ecx
   547bd:	movzx  ecx,BYTE PTR [rbx+0x2]
   547c1:	or     eax,ecx
   547c3:	mov    DWORD PTR [rsp+0x420],eax
   547ca:	mov    eax,0x3
   547cf:	jmp    54866 <sqlite3VdbeExec+0x53c6>
   547d4:	mov    QWORD PTR [rsp+0x1f8],r15
   547dc:	mov    r15,rbp
   547df:	lea    rbp,[rsp+0x200]
   547e7:	mov    rax,rbp
   547ea:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   547f5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54800:	mov    QWORD PTR [rsp+0x190],rdi
   54808:	mov    rdi,rbx
   5480b:	mov    rsi,rax
   5480e:	call   54813 <sqlite3VdbeExec+0x5373>
   54813:	movzx  eax,al
   54816:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54821:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5482c:	mov    ecx,0xffffffff
   54831:	and    rcx,QWORD PTR [rbp+0x0]
   54835:	mov    rdi,QWORD PTR [rsp+0x190]
   5483d:	cmp    rcx,QWORD PTR [rbp+0x0]
   54841:	je     54850 <sqlite3VdbeExec+0x53b0>
   54843:	mov    DWORD PTR [rsp+0x420],0xffffffff
   5484e:	jmp    5485b <sqlite3VdbeExec+0x53bb>
   54850:	mov    rcx,QWORD PTR [rbp+0x0]
   54854:	mov    DWORD PTR [rsp+0x420],ecx
   5485b:	mov    rbp,r15
   5485e:	mov    r15,QWORD PTR [rsp+0x1f8]
   54866:	add    rbx,rax
   54869:	movsxd rax,r13d
   5486c:	mov    ecx,DWORD PTR [rsp+0x420]
   54873:	mov    DWORD PTR [r12+rax*4+0x70],ecx
   54878:	mov    eax,DWORD PTR [rsp+0x420]
   5487f:	cmp    eax,0x80
   54884:	jb     5488d <sqlite3VdbeExec+0x53ed>
   54886:	sub    eax,0xc
   54889:	shr    eax,1
   5488b:	jmp    54898 <sqlite3VdbeExec+0x53f8>
   5488d:	lea    rcx,[rip+0x0]        # 54894 <sqlite3VdbeExec+0x53f4>
   54894:	movzx  eax,BYTE PTR [rcx+rax*1]
   54898:	add    r15,rax
   5489b:	add    r13d,0x1
   5489f:	movsxd rax,r13d
   548a2:	mov    ecx,0xffffffff
   548a7:	and    rcx,r15
   548aa:	mov    QWORD PTR [rsp+0x1a8],r14
   548b2:	mov    r14,QWORD PTR [rsp+0x1e8]
   548ba:	mov    DWORD PTR [r14+rax*4],ecx
   548be:	mov    QWORD PTR [rsp+0x1c8],rbp
   548c6:	mov    ebp,DWORD PTR [rsp+0x41c]
   548cd:	cmp    r13d,ebp
   548d0:	jbe    548dc <sqlite3VdbeExec+0x543c>
   548d2:	mov    rbp,QWORD PTR [rsp+0x208]
   548da:	jmp    54906 <sqlite3VdbeExec+0x5466>
   548dc:	mov    rbp,QWORD PTR [rsp+0x208]
   548e4:	cmp    rbx,rbp
   548e7:	jae    54906 <sqlite3VdbeExec+0x5466>
   548e9:	mov    QWORD PTR [rsp+0x1e8],r14
   548f1:	mov    r14,QWORD PTR [rsp+0x1a8]
   548f9:	mov    rbp,QWORD PTR [rsp+0x1c8]
   54901:	jmp    54733 <sqlite3VdbeExec+0x5293>
   54906:	cmp    rbx,rbp
   54909:	jb     5491a <sqlite3VdbeExec+0x547a>
   5490b:	cmp    rbx,rbp
   5490e:	ja     54934 <sqlite3VdbeExec+0x5494>
   54910:	mov    eax,DWORD PTR [r12+0x60]
   54915:	cmp    r15,rax
   54918:	jne    54934 <sqlite3VdbeExec+0x5494>
   5491a:	mov    eax,DWORD PTR [r12+0x60]
   5491f:	cmp    r15,rax
   54922:	ja     54934 <sqlite3VdbeExec+0x5494>
   54924:	mov    rbp,rbx
   54927:	mov    rbx,r13
   5492a:	mov    r13,QWORD PTR [rsp+0x1f0]
   54932:	jmp    54948 <sqlite3VdbeExec+0x54a8>
   54934:	cmp    DWORD PTR [r14],0x0
   54938:	jne    549fa <sqlite3VdbeExec+0x555a>
   5493e:	xor    ebx,ebx
   54940:	mov    r13,QWORD PTR [rsp+0x1f0]
   54948:	mov    WORD PTR [r12+0x42],bx
   5494e:	mov    rax,rbp
   54951:	sub    rax,r13
   54954:	mov    DWORD PTR [r12+0x38],eax
   54959:	cmp    QWORD PTR [r12+0x58],0x0
   5495f:	je     5496b <sqlite3VdbeExec+0x54cb>
   54961:	lea    rbx,[rsp+0x2c0]
   54969:	jmp    549d2 <sqlite3VdbeExec+0x5532>
   5496b:	lea    rbx,[rsp+0x2c0]
   54973:	mov    rax,rbx
   54976:	movzx  ecx,WORD PTR [rsp+0x2d4]
   5497e:	and    ecx,0x9000
   54984:	test   ecx,ecx
   54986:	jne    5498e <sqlite3VdbeExec+0x54ee>
   54988:	cmp    DWORD PTR [rax+0x20],0x0
   5498c:	je     549d2 <sqlite3VdbeExec+0x5532>
   5498e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   54999:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   549a4:	mov    QWORD PTR [rsp+0x190],rdi
   549ac:	mov    rdi,rax
   549af:	call   549b4 <sqlite3VdbeExec+0x5514>
   549b4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   549bf:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   549ca:	mov    rdi,QWORD PTR [rsp+0x190]
   549d2:	mov    r13d,DWORD PTR [rsp+0x41c]
   549da:	mov    r15,r14
   549dd:	mov    r14,QWORD PTR [rsp+0x1a8]
   549e5:	mov    rbp,QWORD PTR [rsp+0x1c8]
   549ed:	mov    rbx,QWORD PTR [rsp+0x1e0]
   549f5:	jmp    54aa9 <sqlite3VdbeExec+0x5609>
   549fa:	lea    rbx,[rsp+0x2c0]
   54a02:	cmp    QWORD PTR [r12+0x58],0x0
   54a08:	jne    54a69 <sqlite3VdbeExec+0x55c9>
   54a0a:	mov    rax,rbx
   54a0d:	movzx  ecx,WORD PTR [rsp+0x2d4]
   54a15:	and    ecx,0x9000
   54a1b:	test   ecx,ecx
   54a1d:	jne    54a25 <sqlite3VdbeExec+0x5585>
   54a1f:	cmp    DWORD PTR [rax+0x20],0x0
   54a23:	je     54a69 <sqlite3VdbeExec+0x55c9>
   54a25:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   54a30:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54a3b:	mov    QWORD PTR [rsp+0x190],rdi
   54a43:	mov    rdi,rax
   54a46:	call   54a4b <sqlite3VdbeExec+0x55ab>
   54a4b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54a56:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   54a61:	mov    rdi,QWORD PTR [rsp+0x190]
   54a69:	mov    r14,QWORD PTR [rsp+0x1a8]
   54a71:	mov    r13,QWORD PTR [rsp+0x1d0]
   54a79:	mov    rbp,QWORD PTR [rsp+0x1c8]
   54a81:	mov    rbx,QWORD PTR [rsp+0x1e0]
   54a89:	jmp    54493 <sqlite3VdbeExec+0x4ff3>
   54a8e:	mov    QWORD PTR [rsp+0x1a8],r14
   54a96:	mov    DWORD PTR [rsp+0x420],0x0
   54aa1:	mov    r14,QWORD PTR [rsp+0x1a8]
   54aa9:	movzx  eax,WORD PTR [r12+0x42]
   54aaf:	cmp    eax,r13d
   54ab2:	ja     54be1 <sqlite3VdbeExec+0x5741>
   54ab8:	movsxd rax,DWORD PTR [rbp+0xc]
   54abc:	imul   rax,rax,0x38
   54ac0:	add    rax,rbx
   54ac3:	cmp    BYTE PTR [rbp+0x1],0xf5
   54ac7:	jne    54b72 <sqlite3VdbeExec+0x56d2>
   54acd:	mov    rcx,QWORD PTR [rbp+0x10]
   54ad1:	mov    edx,0x2000
   54ad6:	movzx  esi,WORD PTR [rax+0x14]
   54ada:	and    esi,0x9000
   54ae0:	test   esi,esi
   54ae2:	je     54b30 <sqlite3VdbeExec+0x5690>
   54ae4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   54aef:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54afa:	mov    QWORD PTR [rsp+0x190],rdi
   54b02:	mov    rdi,rax
   54b05:	mov    rsi,rcx
   54b08:	call   54b0d <sqlite3VdbeExec+0x566d>
   54b0d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54b18:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   54b23:	mov    rdi,QWORD PTR [rsp+0x190]
   54b2b:	jmp    54bcc <sqlite3VdbeExec+0x572c>
   54b30:	mov    rdx,QWORD PTR [rcx]
   54b33:	mov    QWORD PTR [rax],rdx
   54b36:	mov    rdx,QWORD PTR [rcx+0x8]
   54b3a:	mov    QWORD PTR [rax+0x8],rdx
   54b3e:	mov    rdx,QWORD PTR [rcx+0x10]
   54b42:	mov    QWORD PTR [rax+0x10],rdx
   54b46:	movzx  ecx,WORD PTR [rcx+0x14]
   54b4a:	and    ecx,0x2000
   54b50:	test   ecx,ecx
   54b52:	jne    54bcc <sqlite3VdbeExec+0x572c>
   54b54:	movzx  ecx,WORD PTR [rax+0x14]
   54b58:	and    ecx,0xffff8fff
   54b5e:	mov    WORD PTR [rax+0x14],cx
   54b62:	movzx  ecx,WORD PTR [rax+0x14]
   54b66:	or     ecx,0x2000
   54b6c:	mov    WORD PTR [rax+0x14],cx
   54b70:	jmp    54bcc <sqlite3VdbeExec+0x572c>
   54b72:	movzx  ecx,WORD PTR [rax+0x14]
   54b76:	and    ecx,0x9000
   54b7c:	test   ecx,ecx
   54b7e:	je     54bc6 <sqlite3VdbeExec+0x5726>
   54b80:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   54b8b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54b96:	mov    QWORD PTR [rsp+0x190],rdi
   54b9e:	mov    rdi,rax
   54ba1:	call   54ba6 <sqlite3VdbeExec+0x5706>
   54ba6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54bb1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   54bbc:	mov    rdi,QWORD PTR [rsp+0x190]
   54bc4:	jmp    54bcc <sqlite3VdbeExec+0x572c>
   54bc6:	mov    WORD PTR [rax+0x14],0x1
   54bcc:	mov    r15d,DWORD PTR [rsp+0x3fc]
   54bd4:	mov    r12d,DWORD PTR [rsp+0x40c]
   54bdc:	jmp    54099 <sqlite3VdbeExec+0x4bf9>
   54be1:	jmp    54c02 <sqlite3VdbeExec+0x5762>
   54be3:	mov    QWORD PTR [rsp+0x1a8],r14
   54beb:	mov    eax,r13d
   54bee:	mov    eax,DWORD PTR [r12+rax*4+0x70]
   54bf3:	mov    DWORD PTR [rsp+0x420],eax
   54bfa:	mov    r14,QWORD PTR [rsp+0x1a8]
   54c02:	movsxd rax,DWORD PTR [rbp+0xc]
   54c06:	imul   rax,rax,0x38
   54c0a:	mov    QWORD PTR [rsp+0x1a8],r14
   54c12:	lea    r14,[rbx+rax*1]
   54c16:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   54c1b:	and    eax,0x9000
   54c20:	test   eax,eax
   54c22:	je     54c7f <sqlite3VdbeExec+0x57df>
   54c24:	movzx  eax,WORD PTR [r14+0x14]
   54c29:	and    eax,0x9000
   54c2e:	test   eax,eax
   54c30:	je     54c78 <sqlite3VdbeExec+0x57d8>
   54c32:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   54c3d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54c48:	mov    QWORD PTR [rsp+0x190],rdi
   54c50:	mov    rdi,r14
   54c53:	call   54c58 <sqlite3VdbeExec+0x57b8>
   54c58:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54c63:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   54c6e:	mov    rdi,QWORD PTR [rsp+0x190]
   54c76:	jmp    54c7f <sqlite3VdbeExec+0x57df>
   54c78:	mov    WORD PTR [r14+0x14],0x1
   54c7f:	mov    eax,DWORD PTR [r12+0x64]
   54c84:	lea    ecx,[r13+0x1]
   54c88:	cmp    eax,DWORD PTR [r15+rcx*4]
   54c8c:	jb     54ed8 <sqlite3VdbeExec+0x5a38>
   54c92:	mov    rax,QWORD PTR [r12+0x58]
   54c97:	mov    ecx,r13d
   54c9a:	mov    ecx,DWORD PTR [r15+rcx*4]
   54c9e:	lea    r12,[rax+rcx*1]
   54ca2:	cmp    DWORD PTR [rsp+0x420],0xc
   54caa:	jae    54d12 <sqlite3VdbeExec+0x5872>
   54cac:	mov    eax,DWORD PTR [rsp+0x420]
   54cb3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   54cbe:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54cc9:	mov    QWORD PTR [rsp+0x190],rdi
   54cd1:	mov    rdi,r12
   54cd4:	mov    rsi,rax
   54cd7:	mov    rdx,r14
   54cda:	call   54cdf <sqlite3VdbeExec+0x583f>
   54cdf:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54cea:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   54cf5:	mov    rdi,QWORD PTR [rsp+0x190]
   54cfd:	mov    QWORD PTR [rsp+0x1c8],rbp
   54d05:	mov    rbp,QWORD PTR [rsp+0x1a8]
   54d0d:	jmp    54eb8 <sqlite3VdbeExec+0x5a18>
   54d12:	mov    r15d,DWORD PTR [rsp+0x3fc]
   54d1a:	mov    eax,DWORD PTR [rsp+0x420]
   54d21:	sub    eax,0xc
   54d24:	mov    r13d,eax
   54d27:	shr    r13d,1
   54d2a:	mov    DWORD PTR [r14+0x10],r13d
   54d2e:	mov    BYTE PTR [r14+0x16],r15b
   54d32:	lea    eax,[r13+0x2]
   54d36:	cmp    eax,DWORD PTR [r14+0x20]
   54d3a:	jle    54e15 <sqlite3VdbeExec+0x5975>
   54d40:	mov    QWORD PTR [rsp+0x1c8],rbp
   54d48:	mov    rbp,QWORD PTR [rsp+0x1a8]
   54d50:	cmp    r13d,DWORD PTR [rbp+0x88]
   54d57:	jle    54d9a <sqlite3VdbeExec+0x58fa>
   54d59:	lea    rax,[rip+0x0]        # 54d60 <sqlite3VdbeExec+0x58c0>
   54d60:	mov    QWORD PTR [rsp+0x190],rdi
   54d68:	mov    rsi,rax
   54d6b:	xor    eax,eax
   54d6d:	call   54d72 <sqlite3VdbeExec+0x58d2>
   54d72:	mov    ebx,0x12
   54d77:	mov    rdi,QWORD PTR [rsp+0x190]
   54d7f:	mov    r14,rbp
   54d82:	mov    rbp,rbx
   54d85:	mov    r13,QWORD PTR [rsp+0x1b0]
   54d8d:	mov    rbx,QWORD PTR [rsp+0x1d8]
   54d95:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   54d9a:	mov    WORD PTR [r14+0x14],0x1
   54da1:	lea    eax,[r13+0x2]
   54da5:	xor    ecx,ecx
   54da7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   54db2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54dbd:	mov    QWORD PTR [rsp+0x190],rdi
   54dc5:	mov    rdi,r14
   54dc8:	mov    rsi,rax
   54dcb:	mov    rdx,rcx
   54dce:	call   54dd3 <sqlite3VdbeExec+0x5933>
   54dd3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54dde:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   54de9:	mov    rdi,QWORD PTR [rsp+0x190]
   54df1:	test   eax,eax
   54df3:	je     54e2d <sqlite3VdbeExec+0x598d>
   54df5:	mov    r14,rbp
   54df8:	mov    r13,QWORD PTR [rsp+0x1d0]
   54e00:	mov    rbx,QWORD PTR [rsp+0x1c8]
   54e08:	mov    rbp,QWORD PTR [rsp+0x1d8]
   54e10:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   54e15:	mov    QWORD PTR [rsp+0x1c8],rbp
   54e1d:	mov    rbp,QWORD PTR [rsp+0x1a8]
   54e25:	mov    rax,QWORD PTR [r14+0x28]
   54e29:	mov    QWORD PTR [r14+0x8],rax
   54e2d:	mov    rax,QWORD PTR [r14+0x8]
   54e31:	mov    DWORD PTR [rsp+0x3fc],r15d
   54e39:	mov    r15,r13
   54e3c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   54e47:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54e52:	mov    QWORD PTR [rsp+0x190],rdi
   54e5a:	mov    rdi,rax
   54e5d:	mov    rsi,r12
   54e60:	mov    rdx,r15
   54e63:	call   54e68 <sqlite3VdbeExec+0x59c8>
   54e68:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54e73:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   54e7e:	mov    rax,QWORD PTR [r14+0x8]
   54e82:	mov    BYTE PTR [rax+r15*1],0x0
   54e87:	mov    rax,QWORD PTR [r14+0x8]
   54e8b:	lea    ecx,[r13+0x1]
   54e8f:	movsxd rcx,ecx
   54e92:	mov    BYTE PTR [rax+rcx*1],0x0
   54e96:	lea    rax,[rip+0x0]        # 54e9d <sqlite3VdbeExec+0x59fd>
   54e9d:	mov    ecx,DWORD PTR [rsp+0x420]
   54ea4:	and    ecx,0x1
   54ea7:	movzx  eax,WORD PTR [rax+rcx*2]
   54eab:	mov    WORD PTR [r14+0x14],ax
   54eb0:	mov    rdi,QWORD PTR [rsp+0x190]
   54eb8:	mov    r14,rbp
   54ebb:	mov    r15d,DWORD PTR [rsp+0x3fc]
   54ec3:	mov    rbp,QWORD PTR [rsp+0x1c8]
   54ecb:	mov    r12d,DWORD PTR [rsp+0x40c]
   54ed3:	jmp    54099 <sqlite3VdbeExec+0x4bf9>
   54ed8:	mov    QWORD PTR [rsp+0x1e0],rbx
   54ee0:	mov    ebx,DWORD PTR [rsp+0x3fc]
   54ee7:	mov    BYTE PTR [r14+0x16],bl
   54eeb:	movzx  eax,WORD PTR [rbp+0x2]
   54eef:	and    eax,0xc0
   54ef4:	mov    ecx,eax
   54ef6:	test   ecx,ecx
   54ef8:	je     54f23 <sqlite3VdbeExec+0x5a83>
   54efa:	mov    ecx,eax
   54efc:	cmp    ecx,0x80
   54f02:	je     54f52 <sqlite3VdbeExec+0x5ab2>
   54f04:	cmp    DWORD PTR [rsp+0x420],0xc
   54f0c:	jb     54f23 <sqlite3VdbeExec+0x5a83>
   54f0e:	mov    ecx,DWORD PTR [rsp+0x420]
   54f15:	and    ecx,0x1
   54f18:	test   ecx,ecx
   54f1a:	je     54f52 <sqlite3VdbeExec+0x5ab2>
   54f1c:	cmp    eax,0xc0
   54f21:	je     54f52 <sqlite3VdbeExec+0x5ab2>
   54f23:	mov    eax,DWORD PTR [rsp+0x420]
   54f2a:	cmp    eax,0x80
   54f2f:	jb     54fca <sqlite3VdbeExec+0x5b2a>
   54f35:	sub    eax,0xc
   54f38:	shr    eax,1
   54f3a:	test   eax,eax
   54f3c:	je     54f52 <sqlite3VdbeExec+0x5ab2>
   54f3e:	mov    DWORD PTR [rsp+0x3fc],ebx
   54f45:	mov    rbx,QWORD PTR [rsp+0x1e0]
   54f4d:	jmp    54ffa <sqlite3VdbeExec+0x5b5a>
   54f52:	lea    rax,[rip+0x0]        # 54f59 <sqlite3VdbeExec+0x5ab9>
   54f59:	mov    ecx,DWORD PTR [rsp+0x420]
   54f60:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   54f6b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   54f76:	mov    QWORD PTR [rsp+0x190],rdi
   54f7e:	mov    rdi,rax
   54f81:	mov    rsi,rcx
   54f84:	mov    rdx,r14
   54f87:	call   54f8c <sqlite3VdbeExec+0x5aec>
   54f8c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   54f97:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   54fa2:	mov    rdi,QWORD PTR [rsp+0x190]
   54faa:	mov    r14,QWORD PTR [rsp+0x1a8]
   54fb2:	mov    r15,rbx
   54fb5:	mov    rbx,QWORD PTR [rsp+0x1e0]
   54fbd:	mov    r12d,DWORD PTR [rsp+0x40c]
   54fc5:	jmp    54099 <sqlite3VdbeExec+0x4bf9>
   54fca:	mov    DWORD PTR [rsp+0x3fc],ebx
   54fd1:	mov    rbx,QWORD PTR [rsp+0x1e0]
   54fd9:	lea    rcx,[rip+0x0]        # 54fe0 <sqlite3VdbeExec+0x5b40>
   54fe0:	cmp    BYTE PTR [rcx+rax*1],0x0
   54fe4:	jne    54ffa <sqlite3VdbeExec+0x5b5a>
   54fe6:	mov    QWORD PTR [rsp+0x1e0],rbx
   54fee:	mov    ebx,DWORD PTR [rsp+0x3fc]
   54ff5:	jmp    54f52 <sqlite3VdbeExec+0x5ab2>
   54ffa:	mov    eax,DWORD PTR [rsp+0x420]
   55001:	mov    ecx,r13d
   55004:	mov    ecx,DWORD PTR [r15+rcx*4]
   55008:	mov    edx,DWORD PTR [rdi+0x2c]
   5500b:	mov    r15d,DWORD PTR [rsp+0x414]
   55013:	mov    QWORD PTR [rsp],r14
   55017:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   55022:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5502d:	mov    QWORD PTR [rsp+0x190],rdi
   55035:	mov    rdi,r12
   55038:	mov    rsi,r13
   5503b:	mov    r8,rdx
   5503e:	mov    rdx,rax
   55041:	mov    r9,r15
   55044:	call   55049 <sqlite3VdbeExec+0x5ba9>
   55049:	mov    r12d,eax
   5504c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   55057:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   55062:	mov    rdi,QWORD PTR [rsp+0x190]
   5506a:	test   r12d,r12d
   5506d:	jne    55084 <sqlite3VdbeExec+0x5be4>
   5506f:	mov    r14,QWORD PTR [rsp+0x1a8]
   55077:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5507f:	jmp    54099 <sqlite3VdbeExec+0x4bf9>
   55084:	cmp    r12d,0x7
   55088:	jne    550aa <sqlite3VdbeExec+0x5c0a>
   5508a:	mov    r14,QWORD PTR [rsp+0x1a8]
   55092:	mov    r13,QWORD PTR [rsp+0x1d0]
   5509a:	mov    rbx,rbp
   5509d:	mov    rbp,QWORD PTR [rsp+0x1d8]
   550a5:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   550aa:	cmp    r12d,0x12
   550ae:	jne    550c5 <sqlite3VdbeExec+0x5c25>
   550b0:	mov    QWORD PTR [rsp+0x1c8],rbp
   550b8:	mov    rbp,QWORD PTR [rsp+0x1a8]
   550c0:	jmp    54d59 <sqlite3VdbeExec+0x58b9>
   550c5:	mov    r14,QWORD PTR [rsp+0x1a8]
   550cd:	mov    QWORD PTR [rsp+0x1c8],rbp
   550d5:	mov    rbp,r12
   550d8:	mov    r13,QWORD PTR [rsp+0x1b0]
   550e0:	mov    rbx,QWORD PTR [rsp+0x1d8]
   550e8:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   550ed:	mov    QWORD PTR [rsp+0x1d0],r13
   550f5:	mov    eax,0x1859c
   550fa:	mov    ecx,0xb
   550ff:	lea    rdx,[rip+0x0]        # 55106 <sqlite3VdbeExec+0x5c66>
   55106:	mov    QWORD PTR [rsp+0x190],rdi
   5510e:	mov    rdi,rcx
   55111:	mov    rsi,rax
   55114:	call   55119 <sqlite3VdbeExec+0x5c79>
   55119:	mov    ebx,eax
   5511b:	mov    rdi,QWORD PTR [rsp+0x190]
   55123:	mov    QWORD PTR [rsp+0x1c8],rbp
   5512b:	mov    rbp,rbx
   5512e:	mov    r13,QWORD PTR [rsp+0x1b0]
   55136:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5513e:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   55143:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5514b:	mov    r13,QWORD PTR [rsp+0x1d0]
   55153:	mov    QWORD PTR [rsp+0x1b0],r12
   5515b:	mov    r12d,DWORD PTR [rsp+0x414]
   55163:	mov    DWORD PTR [rsp+0x414],r12d
   5516b:	mov    r12,QWORD PTR [rbp+0x10]
   5516f:	mov    QWORD PTR [rsp+0x1d0],r13
   55177:	mov    r13,QWORD PTR [r12+0x8]
   5517c:	movsxd rax,DWORD PTR [rbp+0x4]
   55180:	imul   rax,rax,0x38
   55184:	mov    QWORD PTR [rsp+0x1f0],r13
   5518c:	lea    r13,[rbx+rax*1]
   55190:	cmp    DWORD PTR [rbp+0xc],0x2
   55194:	jge    551c4 <sqlite3VdbeExec+0x5d24>
   55196:	mov    QWORD PTR [rsp+0x208],r13
   5519e:	movsx  r13d,WORD PTR [r12+0x36]
   551a4:	mov    QWORD PTR [rsp+0x1e8],r12
   551ac:	mov    DWORD PTR [rsp+0x420],r13d
   551b4:	mov    r13,QWORD PTR [rsp+0x208]
   551bc:	xor    r12d,r12d
   551bf:	jmp    55509 <sqlite3VdbeExec+0x6069>
   551c4:	mov    QWORD PTR [rsp+0x208],r13
   551cc:	mov    eax,DWORD PTR [rbp+0xc]
   551cf:	mov    r13d,eax
   551d2:	sub    r13d,0x2
   551d6:	mov    DWORD PTR [rsp+0x41c],r13d
   551de:	add    r13d,0x1
   551e2:	mov    QWORD PTR [rsp+0x1e8],r12
   551ea:	mov    r12d,DWORD PTR [rsp+0x41c]
   551f2:	mov    DWORD PTR [rsp+0x420],r13d
   551fa:	mov    r13,QWORD PTR [rsp+0x208]
   55202:	jmp    55509 <sqlite3VdbeExec+0x6069>
   55207:	mov    QWORD PTR [rsp+0x1f0],r15
   5520f:	mov    r15d,DWORD PTR [rsp+0x3fc]
   55217:	cmp    DWORD PTR [rbp+0xc],0x0
   5521b:	je     55226 <sqlite3VdbeExec+0x5d86>
   5521d:	add    r13,0x38
   55221:	jmp    55505 <sqlite3VdbeExec+0x6065>
   55226:	movsxd rax,r12d
   55229:	shl    rax,0x4
   5522d:	mov    QWORD PTR [rsp+0x1a8],r14
   55235:	mov    r14,QWORD PTR [rsp+0x1f0]
   5523d:	movsx  eax,BYTE PTR [r14+rax*1+0x9]
   55243:	mov    ecx,r15d
   55246:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   55251:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5525c:	mov    QWORD PTR [rsp+0x190],rdi
   55264:	mov    rdi,r13
   55267:	mov    rsi,rax
   5526a:	mov    rdx,rcx
   5526d:	call   55272 <sqlite3VdbeExec+0x5dd2>
   55272:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5527d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   55288:	movzx  eax,WORD PTR [r13+0x14]
   5528d:	and    eax,0x1
   55290:	mov    rdi,QWORD PTR [rsp+0x190]
   55298:	test   eax,eax
   5529a:	je     552a9 <sqlite3VdbeExec+0x5e09>
   5529c:	mov    r14,QWORD PTR [rsp+0x1a8]
   552a4:	jmp    55501 <sqlite3VdbeExec+0x6061>
   552a9:	movsxd rax,r12d
   552ac:	shl    rax,0x4
   552b0:	movzx  eax,BYTE PTR [r14+rax*1+0x8]
   552b6:	shl    rax,0x38
   552ba:	shr    rax,0x3c
   552be:	mov    ecx,eax
   552c0:	sub    ecx,0x2
   552c3:	cmp    ecx,0x4
   552c6:	jbe    552dd <sqlite3VdbeExec+0x5e3d>
   552c8:	mov    QWORD PTR [rsp+0x1f0],r14
   552d0:	mov    r14,QWORD PTR [rsp+0x1a8]
   552d8:	jmp    55501 <sqlite3VdbeExec+0x6061>
   552dd:	sub    eax,0x2
   552e0:	mov    QWORD PTR [rsp+0x1c8],rbp
   552e8:	lea    rbp,[rip+0x0]        # 552ef <sqlite3VdbeExec+0x5e4f>
   552ef:	movsxd rax,DWORD PTR [rbp+rax*4+0x0]
   552f4:	add    rax,rbp
   552f7:	jmp    rax
   552f9:	mov    QWORD PTR [rsp+0x1f0],r14
   55301:	mov    r14,QWORD PTR [rsp+0x1a8]
   55309:	mov    rbp,QWORD PTR [rsp+0x1c8]
   55311:	jmp    55501 <sqlite3VdbeExec+0x6061>
   55316:	movzx  eax,WORD PTR [r13+0x14]
   5531b:	and    eax,0x10
   5531e:	test   eax,eax
   55320:	je     5533f <sqlite3VdbeExec+0x5e9f>
   55322:	mov    QWORD PTR [rsp+0x1f0],r14
   5532a:	mov    r14,QWORD PTR [rsp+0x1a8]
   55332:	mov    rbp,QWORD PTR [rsp+0x1c8]
   5533a:	jmp    55501 <sqlite3VdbeExec+0x6061>
   5533f:	lea    rax,[rip+0x0]        # 55346 <sqlite3VdbeExec+0x5ea6>
   55346:	lea    rcx,[rip+0x0]        # 5534d <sqlite3VdbeExec+0x5ead>
   5534d:	lea    rdx,[rip+0x0]        # 55354 <sqlite3VdbeExec+0x5eb4>
   55354:	movzx  esi,WORD PTR [r13+0x14]
   55359:	and    esi,0x3f
   5535c:	movzx  edx,BYTE PTR [rdx+rsi*1]
   55360:	add    rdx,0xffffffffffffffff
   55364:	mov    rcx,QWORD PTR [rcx+rdx*8]
   55368:	lea    rdx,[rip+0x0]        # 5536f <sqlite3VdbeExec+0x5ecf>
   5536f:	movsxd rsi,r12d
   55372:	mov    r8,rsi
   55375:	shl    r8,0x4
   55379:	movzx  r8d,BYTE PTR [r14+r8*1+0x8]
   5537f:	shl    r8,0x38
   55383:	shr    r8,0x3c
   55387:	add    r8,0xffffffffffffffff
   5538b:	mov    rdx,QWORD PTR [rdx+r8*8]
   5538f:	mov    r12,QWORD PTR [rsp+0x1e8]
   55397:	mov    r8,QWORD PTR [r12]
   5539b:	shl    rsi,0x4
   5539f:	mov    rsi,QWORD PTR [r14+rsi*1]
   553a3:	mov    QWORD PTR [rsp+0x190],rdi
   553ab:	mov    r9,rsi
   553ae:	mov    rsi,rax
   553b1:	mov    r11,rdx
   553b4:	mov    rdx,rcx
   553b7:	mov    rcx,r11
   553ba:	xor    eax,eax
   553bc:	call   553c1 <sqlite3VdbeExec+0x5f21>
   553c1:	mov    ebp,0xc13
   553c6:	mov    rdi,QWORD PTR [rsp+0x190]
   553ce:	mov    r14,QWORD PTR [rsp+0x1a8]
   553d6:	mov    r13,QWORD PTR [rsp+0x1b0]
   553de:	mov    rbx,QWORD PTR [rsp+0x1d8]
   553e6:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   553eb:	mov    QWORD PTR [rsp+0x1f0],r14
   553f3:	mov    r14,QWORD PTR [rsp+0x1a8]
   553fb:	mov    rbp,QWORD PTR [rsp+0x1c8]
   55403:	movzx  eax,WORD PTR [r13+0x14]
   55408:	and    eax,0x4
   5540b:	test   eax,eax
   5540d:	jne    55501 <sqlite3VdbeExec+0x6061>
   55413:	mov    QWORD PTR [rsp+0x1a8],r14
   5541b:	mov    r14,QWORD PTR [rsp+0x1f0]
   55423:	mov    QWORD PTR [rsp+0x1c8],rbp
   5542b:	jmp    5533f <sqlite3VdbeExec+0x5e9f>
   55430:	mov    QWORD PTR [rsp+0x1f0],r14
   55438:	mov    r14,QWORD PTR [rsp+0x1a8]
   55440:	mov    rbp,QWORD PTR [rsp+0x1c8]
   55448:	movzx  eax,WORD PTR [r13+0x14]
   5544d:	and    eax,0x2
   55450:	test   eax,eax
   55452:	jne    55501 <sqlite3VdbeExec+0x6061>
   55458:	mov    QWORD PTR [rsp+0x1a8],r14
   55460:	mov    r14,QWORD PTR [rsp+0x1f0]
   55468:	mov    QWORD PTR [rsp+0x1c8],rbp
   55470:	jmp    5533f <sqlite3VdbeExec+0x5e9f>
   55475:	mov    QWORD PTR [rsp+0x1f0],r14
   5547d:	mov    r14,QWORD PTR [rsp+0x1a8]
   55485:	mov    rbp,QWORD PTR [rsp+0x1c8]
   5548d:	movzx  eax,WORD PTR [r13+0x14]
   55492:	and    eax,0x4
   55495:	test   eax,eax
   55497:	je     555d4 <sqlite3VdbeExec+0x6134>
   5549d:	movabs rax,0x7fffffffffff
   554a7:	cmp    rax,QWORD PTR [r13+0x0]
   554ab:	jge    554c2 <sqlite3VdbeExec+0x6022>
   554ad:	mov    DWORD PTR [rsp+0x3fc],r15d
   554b5:	mov    r15,QWORD PTR [rsp+0x1f0]
   554bd:	jmp    55593 <sqlite3VdbeExec+0x60f3>
   554c2:	movabs rax,0xffff800000000000
   554cc:	cmp    rax,QWORD PTR [r13+0x0]
   554d0:	jle    554e7 <sqlite3VdbeExec+0x6047>
   554d2:	mov    DWORD PTR [rsp+0x3fc],r15d
   554da:	mov    r15,QWORD PTR [rsp+0x1f0]
   554e2:	jmp    55593 <sqlite3VdbeExec+0x60f3>
   554e7:	movzx  eax,WORD PTR [r13+0x14]
   554ec:	or     eax,0x20
   554ef:	mov    WORD PTR [r13+0x14],ax
   554f4:	movzx  eax,WORD PTR [r13+0x14]
   554f9:	and    eax,0xfffffffb
   554fc:	mov    WORD PTR [r13+0x14],ax
   55501:	add    r13,0x38
   55505:	add    r12d,0x1
   55509:	mov    DWORD PTR [rsp+0x3fc],r15d
   55511:	mov    r15d,DWORD PTR [rsp+0x420]
   55519:	cmp    r12d,r15d
   5551c:	jge    5561d <sqlite3VdbeExec+0x617d>
   55522:	movsxd rax,r12d
   55525:	shl    rax,0x4
   55529:	mov    r15,QWORD PTR [rsp+0x1f0]
   55531:	movzx  eax,WORD PTR [r15+rax*1+0xe]
   55537:	and    eax,0x60
   5553a:	test   eax,eax
   5553c:	jne    5554b <sqlite3VdbeExec+0x60ab>
   5553e:	mov    r15d,DWORD PTR [rsp+0x3fc]
   55546:	jmp    55226 <sqlite3VdbeExec+0x5d86>
   5554b:	cmp    DWORD PTR [rbp+0xc],0x2
   5554f:	jl     55566 <sqlite3VdbeExec+0x60c6>
   55551:	mov    QWORD PTR [rsp+0x1f0],r15
   55559:	mov    r15d,DWORD PTR [rsp+0x3fc]
   55561:	jmp    55226 <sqlite3VdbeExec+0x5d86>
   55566:	movsxd rax,r12d
   55569:	shl    rax,0x4
   5556d:	movzx  eax,WORD PTR [r15+rax*1+0xe]
   55573:	and    eax,0x20
   55576:	test   eax,eax
   55578:	je     55207 <sqlite3VdbeExec+0x5d67>
   5557e:	mov    QWORD PTR [rsp+0x1f0],r15
   55586:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5558e:	jmp    55505 <sqlite3VdbeExec+0x6065>
   55593:	mov    rax,QWORD PTR [r13+0x0]
   55597:	xorps  xmm3,xmm3
   5559a:	cvtsi2sd xmm3,rax
   5559f:	movsd  QWORD PTR [r13+0x0],xmm3
   555a5:	movzx  eax,WORD PTR [r13+0x14]
   555aa:	or     eax,0x8
   555ad:	mov    WORD PTR [r13+0x14],ax
   555b2:	movzx  eax,WORD PTR [r13+0x14]
   555b7:	and    eax,0xfffffffb
   555ba:	mov    WORD PTR [r13+0x14],ax
   555bf:	mov    QWORD PTR [rsp+0x1f0],r15
   555c7:	mov    r15d,DWORD PTR [rsp+0x3fc]
   555cf:	jmp    55501 <sqlite3VdbeExec+0x6061>
   555d4:	mov    DWORD PTR [rsp+0x3fc],r15d
   555dc:	mov    r15,QWORD PTR [rsp+0x1f0]
   555e4:	movzx  eax,WORD PTR [r13+0x14]
   555e9:	and    eax,0x28
   555ec:	test   eax,eax
   555ee:	je     55605 <sqlite3VdbeExec+0x6165>
   555f0:	mov    QWORD PTR [rsp+0x1f0],r15
   555f8:	mov    r15d,DWORD PTR [rsp+0x3fc]
   55600:	jmp    55501 <sqlite3VdbeExec+0x6061>
   55605:	mov    QWORD PTR [rsp+0x1a8],r14
   5560d:	mov    r14,r15
   55610:	mov    QWORD PTR [rsp+0x1c8],rbp
   55618:	jmp    5533f <sqlite3VdbeExec+0x5e9f>
   5561d:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   55622:	mov    QWORD PTR [rsp+0x1b0],r12
   5562a:	mov    r12,QWORD PTR [rbp+0x10]
   5562e:	movsxd rax,DWORD PTR [rbp+0x4]
   55632:	imul   rax,rax,0x38
   55636:	lea    r13,[rbx+rax*1]
   5563a:	mov    r15,r12
   5563d:	mov    r12,r13
   55640:	jmp    55688 <sqlite3VdbeExec+0x61e8>
   55642:	mov    rax,QWORD PTR [r12]
   55646:	xorps  xmm3,xmm3
   55649:	cvtsi2sd xmm3,rax
   5564e:	movsd  QWORD PTR [r12],xmm3
   55654:	movzx  eax,WORD PTR [r12+0x14]
   5565a:	or     eax,0x8
   5565d:	mov    WORD PTR [r12+0x14],ax
   55663:	movzx  eax,WORD PTR [r12+0x14]
   55669:	and    eax,0xfffffff9
   5566c:	mov    WORD PTR [r12+0x14],ax
   55672:	lea    r13,[r15+0x1]
   55676:	cmp    BYTE PTR [r15+0x1],0x0
   5567b:	je     55766 <sqlite3VdbeExec+0x62c6>
   55681:	add    r12,0x38
   55685:	mov    r15,r13
   55688:	movsx  eax,BYTE PTR [r15]
   5568c:	mov    r13d,DWORD PTR [rsp+0x3fc]
   55694:	mov    ecx,r13d
   55697:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   556a2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   556ad:	mov    QWORD PTR [rsp+0x190],rdi
   556b5:	mov    rdi,r12
   556b8:	mov    rsi,rax
   556bb:	mov    rdx,rcx
   556be:	call   556c3 <sqlite3VdbeExec+0x6223>
   556c3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   556ce:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   556d9:	mov    rdi,QWORD PTR [rsp+0x190]
   556e1:	cmp    BYTE PTR [r15],0x45
   556e5:	jne    55672 <sqlite3VdbeExec+0x61d2>
   556e7:	movzx  eax,WORD PTR [r12+0x14]
   556ed:	and    eax,0x4
   556f0:	test   eax,eax
   556f2:	jne    55701 <sqlite3VdbeExec+0x6261>
   556f4:	mov    DWORD PTR [rsp+0x3fc],r13d
   556fc:	jmp    55672 <sqlite3VdbeExec+0x61d2>
   55701:	movabs rax,0x7fffffffffff
   5570b:	cmp    rax,QWORD PTR [r12]
   5570f:	jge    5571e <sqlite3VdbeExec+0x627e>
   55711:	mov    DWORD PTR [rsp+0x3fc],r13d
   55719:	jmp    55642 <sqlite3VdbeExec+0x61a2>
   5571e:	movabs rax,0xffff800000000000
   55728:	cmp    rax,QWORD PTR [r12]
   5572c:	jle    5573b <sqlite3VdbeExec+0x629b>
   5572e:	mov    DWORD PTR [rsp+0x3fc],r13d
   55736:	jmp    55642 <sqlite3VdbeExec+0x61a2>
   5573b:	movzx  eax,WORD PTR [r12+0x14]
   55741:	or     eax,0x20
   55744:	mov    WORD PTR [r12+0x14],ax
   5574a:	movzx  eax,WORD PTR [r12+0x14]
   55750:	and    eax,0xfffffffb
   55753:	mov    WORD PTR [r12+0x14],ax
   55759:	mov    DWORD PTR [rsp+0x3fc],r13d
   55761:	jmp    55672 <sqlite3VdbeExec+0x61d2>
   55766:	mov    r13d,DWORD PTR [rsp+0x3fc]
   5576e:	mov    DWORD PTR [rsp+0x3fc],r13d
   55776:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5577b:	mov    r13d,DWORD PTR [rsp+0x3fc]
   55783:	mov    QWORD PTR [rsp+0x1b0],r12
   5578b:	mov    DWORD PTR [rsp+0x3fc],r13d
   55793:	movsxd rax,DWORD PTR [rbp+0x4]
   55797:	mov    r12,QWORD PTR [rbp+0x10]
   5579b:	imul   rax,rax,0x38
   5579f:	lea    r13,[rbx+rax*1]
   557a3:	mov    eax,DWORD PTR [rbp+0x8]
   557a6:	sub    eax,0x1
   557a9:	movsxd rax,eax
   557ac:	imul   rax,rax,0x38
   557b0:	lea    r15,[r13+rax*1+0x0]
   557b5:	movsxd rax,DWORD PTR [rbp+0xc]
   557b9:	imul   rax,rax,0x38
   557bd:	mov    QWORD PTR [rsp+0x1e8],r15
   557c5:	lea    r15,[rbx+rax*1]
   557c9:	test   r12,r12
   557cc:	jne    557e3 <sqlite3VdbeExec+0x6343>
   557ce:	mov    QWORD PTR [rsp+0x1f0],r13
   557d6:	mov    QWORD PTR [rsp+0x208],r15
   557de:	jmp    558a3 <sqlite3VdbeExec+0x6403>
   557e3:	mov    QWORD PTR [rsp+0x1f0],r13
   557eb:	movsx  eax,BYTE PTR [r12]
   557f0:	mov    QWORD PTR [rsp+0x208],r15
   557f8:	mov    r15d,DWORD PTR [rsp+0x3fc]
   55800:	mov    ecx,r15d
   55803:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5580e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   55819:	mov    QWORD PTR [rsp+0x190],rdi
   55821:	mov    rdi,r13
   55824:	mov    rsi,rax
   55827:	mov    rdx,rcx
   5582a:	call   5582f <sqlite3VdbeExec+0x638f>
   5582f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5583a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   55845:	mov    rdi,QWORD PTR [rsp+0x190]
   5584d:	cmp    BYTE PTR [r12],0x45
   55852:	jne    5587a <sqlite3VdbeExec+0x63da>
   55854:	movzx  eax,WORD PTR [r13+0x14]
   55859:	and    eax,0x4
   5585c:	test   eax,eax
   5585e:	je     5587a <sqlite3VdbeExec+0x63da>
   55860:	movzx  eax,WORD PTR [r13+0x14]
   55865:	or     eax,0x20
   55868:	mov    WORD PTR [r13+0x14],ax
   5586d:	movzx  eax,WORD PTR [r13+0x14]
   55872:	and    eax,0xfffffffb
   55875:	mov    WORD PTR [r13+0x14],ax
   5587a:	mov    DWORD PTR [rsp+0x3fc],r15d
   55882:	lea    r15,[r12+0x1]
   55887:	add    r13,0x38
   5588b:	cmp    BYTE PTR [r12+0x1],0x0
   55891:	je     558a3 <sqlite3VdbeExec+0x6403>
   55893:	mov    r12,r15
   55896:	mov    r15,QWORD PTR [rsp+0x208]
   5589e:	jmp    557eb <sqlite3VdbeExec+0x634b>
   558a3:	mov    r12,QWORD PTR [rsp+0x1e8]
   558ab:	xor    r15d,r15d
   558ae:	xor    r13d,r13d
   558b1:	xor    r11d,r11d
   558b4:	mov    QWORD PTR [rsp+0x1f8],r11
   558bc:	jmp    55c60 <sqlite3VdbeExec+0x67c0>
   558c1:	mov    DWORD PTR [r12+0x24],0x0
   558ca:	add    r13d,0x1
   558ce:	mov    QWORD PTR [rsp+0x1a8],r14
   558d6:	mov    r14,r13
   558d9:	jmp    55c3c <sqlite3VdbeExec+0x679c>
   558de:	movzx  eax,WORD PTR [r12+0x14]
   558e4:	and    eax,0x24
   558e7:	test   eax,eax
   558e9:	je     55a0f <sqlite3VdbeExec+0x656f>
   558ef:	mov    rax,QWORD PTR [r12]
   558f3:	test   rax,rax
   558f6:	jge    55900 <sqlite3VdbeExec+0x6460>
   558f8:	mov    rcx,rax
   558fb:	not    rcx
   558fe:	jmp    55903 <sqlite3VdbeExec+0x6463>
   55900:	mov    rcx,rax
   55903:	add    r13d,0x1
   55907:	cmp    rcx,0x7f
   5590b:	ja     5593e <sqlite3VdbeExec+0x649e>
   5590d:	mov    rdx,rax
   55910:	and    rdx,0x1
   55914:	cmp    rdx,rax
   55917:	jne    5592c <sqlite3VdbeExec+0x648c>
   55919:	cmp    BYTE PTR [rdi+0xc5],0x4
   55920:	jb     5592c <sqlite3VdbeExec+0x648c>
   55922:	lea    eax,[rcx+0x8]
   55925:	mov    DWORD PTR [r12+0x24],eax
   5592a:	jmp    55939 <sqlite3VdbeExec+0x6499>
   5592c:	add    r15,0x1
   55930:	mov    DWORD PTR [r12+0x24],0x1
   55939:	jmp    559ff <sqlite3VdbeExec+0x655f>
   5593e:	cmp    rcx,0x7fff
   55945:	ja     55959 <sqlite3VdbeExec+0x64b9>
   55947:	add    r15,0x2
   5594b:	mov    DWORD PTR [r12+0x24],0x2
   55954:	jmp    559ff <sqlite3VdbeExec+0x655f>
   55959:	cmp    rcx,0x7fffff
   55960:	ja     55974 <sqlite3VdbeExec+0x64d4>
   55962:	add    r15,0x3
   55966:	mov    DWORD PTR [r12+0x24],0x3
   5596f:	jmp    559ff <sqlite3VdbeExec+0x655f>
   55974:	cmp    rcx,0x7fffffff
   5597b:	ja     5598c <sqlite3VdbeExec+0x64ec>
   5597d:	add    r15,0x4
   55981:	mov    DWORD PTR [r12+0x24],0x4
   5598a:	jmp    559ff <sqlite3VdbeExec+0x655f>
   5598c:	movabs rax,0x7fffffffffff
   55996:	cmp    rcx,rax
   55999:	ja     559aa <sqlite3VdbeExec+0x650a>
   5599b:	add    r15,0x6
   5599f:	mov    DWORD PTR [r12+0x24],0x5
   559a8:	jmp    559ff <sqlite3VdbeExec+0x655f>
   559aa:	add    r15,0x8
   559ae:	movzx  eax,WORD PTR [r12+0x14]
   559b4:	and    eax,0x20
   559b7:	test   eax,eax
   559b9:	je     559f6 <sqlite3VdbeExec+0x6556>
   559bb:	mov    rax,QWORD PTR [r12]
   559bf:	xorps  xmm3,xmm3
   559c2:	cvtsi2sd xmm3,rax
   559c7:	movsd  QWORD PTR [r12],xmm3
   559cd:	movzx  eax,WORD PTR [r12+0x14]
   559d3:	and    eax,0xffffffdf
   559d6:	mov    WORD PTR [r12+0x14],ax
   559dc:	movzx  eax,WORD PTR [r12+0x14]
   559e2:	or     eax,0x8
   559e5:	mov    WORD PTR [r12+0x14],ax
   559eb:	mov    DWORD PTR [r12+0x24],0x7
   559f4:	jmp    559ff <sqlite3VdbeExec+0x655f>
   559f6:	mov    DWORD PTR [r12+0x24],0x6
   559ff:	mov    QWORD PTR [rsp+0x1a8],r14
   55a07:	mov    r14,r13
   55a0a:	jmp    55c3c <sqlite3VdbeExec+0x679c>
   55a0f:	movzx  eax,WORD PTR [r12+0x14]
   55a15:	and    eax,0x8
   55a18:	test   eax,eax
   55a1a:	je     55a3d <sqlite3VdbeExec+0x659d>
   55a1c:	add    r13d,0x1
   55a20:	add    r15,0x8
   55a24:	mov    DWORD PTR [r12+0x24],0x7
   55a2d:	mov    QWORD PTR [rsp+0x1a8],r14
   55a35:	mov    r14,r13
   55a38:	jmp    55c3c <sqlite3VdbeExec+0x679c>
   55a3d:	mov    DWORD PTR [rsp+0x420],r13d
   55a45:	mov    r13d,DWORD PTR [r12+0x10]
   55a4a:	mov    eax,r13d
   55a4d:	shl    eax,1
   55a4f:	add    eax,0xc
   55a52:	movzx  ecx,WORD PTR [r12+0x14]
   55a58:	and    ecx,0x2
   55a5b:	test   ecx,ecx
   55a5d:	mov    ecx,0x0
   55a62:	setne  cl
   55a65:	mov    DWORD PTR [rsp+0x41c],r13d
   55a6d:	lea    r13d,[rax+rcx*1]
   55a71:	movzx  eax,WORD PTR [r12+0x14]
   55a77:	and    eax,0x400
   55a7c:	test   eax,eax
   55a7e:	jne    55a95 <sqlite3VdbeExec+0x65f5>
   55a80:	mov    QWORD PTR [rsp+0x1a8],r14
   55a88:	mov    r14d,DWORD PTR [rsp+0x41c]
   55a90:	jmp    55c07 <sqlite3VdbeExec+0x6767>
   55a95:	mov    eax,DWORD PTR [r12]
   55a99:	shl    eax,1
   55a9b:	add    r13d,eax
   55a9e:	test   r15,r15
   55aa1:	je     55bd0 <sqlite3VdbeExec+0x6730>
   55aa7:	mov    eax,DWORD PTR [r12+0x10]
   55aac:	add    eax,DWORD PTR [r12]
   55ab0:	test   eax,eax
   55ab2:	jg     55aca <sqlite3VdbeExec+0x662a>
   55ab4:	movzx  eax,WORD PTR [r12+0x14]
   55aba:	and    eax,0x10
   55abd:	test   eax,eax
   55abf:	je     55b92 <sqlite3VdbeExec+0x66f2>
   55ac5:	mov    eax,0x1
   55aca:	mov    ecx,0x1
   55acf:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   55ada:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   55ae5:	mov    QWORD PTR [rsp+0x190],rdi
   55aed:	mov    rdi,r12
   55af0:	mov    rsi,rax
   55af3:	mov    rdx,rcx
   55af6:	call   55afb <sqlite3VdbeExec+0x665b>
   55afb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   55b06:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   55b11:	mov    rdi,QWORD PTR [rsp+0x190]
   55b19:	test   eax,eax
   55b1b:	jne    55ba8 <sqlite3VdbeExec+0x6708>
   55b21:	mov    rax,QWORD PTR [r12+0x8]
   55b26:	movsxd rcx,DWORD PTR [r12+0x10]
   55b2b:	add    rax,rcx
   55b2e:	xor    ecx,ecx
   55b30:	movsxd rdx,DWORD PTR [r12]
   55b34:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   55b3f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   55b4a:	mov    rdi,rax
   55b4d:	mov    rsi,rcx
   55b50:	call   55b55 <sqlite3VdbeExec+0x66b5>
   55b55:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   55b60:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   55b6b:	mov    eax,DWORD PTR [r12+0x10]
   55b70:	add    eax,DWORD PTR [r12]
   55b74:	mov    DWORD PTR [r12+0x10],eax
   55b79:	movzx  eax,WORD PTR [r12+0x14]
   55b7f:	and    eax,0xfffff9ff
   55b84:	mov    WORD PTR [r12+0x14],ax
   55b8a:	mov    rdi,QWORD PTR [rsp+0x190]
   55b92:	mov    QWORD PTR [rsp+0x1a8],r14
   55b9a:	mov    r14d,DWORD PTR [rsp+0x41c]
   55ba2:	add    r14d,DWORD PTR [r12]
   55ba6:	jmp    55c07 <sqlite3VdbeExec+0x6767>
   55ba8:	mov    QWORD PTR [rsp+0x1a8],r14
   55bb0:	mov    r14,QWORD PTR [rsp+0x1a8]
   55bb8:	mov    r13,QWORD PTR [rsp+0x1d0]
   55bc0:	mov    rbx,rbp
   55bc3:	mov    rbp,QWORD PTR [rsp+0x1d8]
   55bcb:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   55bd0:	movsxd rax,DWORD PTR [r12]
   55bd4:	mov    DWORD PTR [rsp+0x418],r13d
   55bdc:	mov    r13,QWORD PTR [rsp+0x1f8]
   55be4:	add    r13,rax
   55be7:	mov    QWORD PTR [rsp+0x1a8],r14
   55bef:	mov    QWORD PTR [rsp+0x1f8],r13
   55bf7:	mov    r13d,DWORD PTR [rsp+0x418]
   55bff:	mov    r14d,DWORD PTR [rsp+0x41c]
   55c07:	mov    rax,r14
   55c0a:	add    r15,rax
   55c0d:	mov    rax,r13
   55c10:	mov    ecx,0x1
   55c15:	mov    r11,rcx
   55c18:	mov    rcx,rax
   55c1b:	mov    rax,r11
   55c1e:	jmp    55c23 <sqlite3VdbeExec+0x6783>
   55c20:	add    eax,0x1
   55c23:	shr    rcx,0x7
   55c27:	test   rcx,rcx
   55c2a:	jne    55c20 <sqlite3VdbeExec+0x6780>
   55c2c:	mov    r14d,DWORD PTR [rsp+0x420]
   55c34:	add    r14d,eax
   55c37:	mov    DWORD PTR [r12+0x24],r13d
   55c3c:	mov    r13,QWORD PTR [rsp+0x1f0]
   55c44:	cmp    r12,r13
   55c47:	je     55c92 <sqlite3VdbeExec+0x67f2>
   55c49:	add    r12,0xffffffffffffffc8
   55c4d:	mov    QWORD PTR [rsp+0x1f0],r13
   55c55:	mov    r13,r14
   55c58:	mov    r14,QWORD PTR [rsp+0x1a8]
   55c60:	movzx  eax,WORD PTR [r12+0x14]
   55c66:	and    eax,0x1
   55c69:	test   eax,eax
   55c6b:	je     558de <sqlite3VdbeExec+0x643e>
   55c71:	movzx  eax,WORD PTR [r12+0x14]
   55c77:	and    eax,0x400
   55c7c:	test   eax,eax
   55c7e:	je     558c1 <sqlite3VdbeExec+0x6421>
   55c84:	mov    DWORD PTR [r12+0x24],0xa
   55c8d:	jmp    558ca <sqlite3VdbeExec+0x642a>
   55c92:	cmp    r14d,0x7e
   55c96:	jg     55ca1 <sqlite3VdbeExec+0x6801>
   55c98:	lea    r12d,[r14+0x1]
   55c9c:	mov    r14,r12
   55c9f:	jmp    55cea <sqlite3VdbeExec+0x684a>
   55ca1:	mov    rax,r14
   55ca4:	mov    ecx,0x1
   55ca9:	mov    r11,rcx
   55cac:	mov    rcx,rax
   55caf:	mov    rax,r11
   55cb2:	jmp    55cb7 <sqlite3VdbeExec+0x6817>
   55cb4:	add    eax,0x1
   55cb7:	shr    rcx,0x7
   55cbb:	test   rcx,rcx
   55cbe:	jne    55cb4 <sqlite3VdbeExec+0x6814>
   55cc0:	add    r14d,eax
   55cc3:	movsxd rcx,r14d
   55cc6:	mov    edx,0x1
   55ccb:	mov    r11,rdx
   55cce:	mov    rdx,rcx
   55cd1:	mov    rcx,r11
   55cd4:	jmp    55cd9 <sqlite3VdbeExec+0x6839>
   55cd6:	add    ecx,0x1
   55cd9:	shr    rdx,0x7
   55cdd:	test   rdx,rdx
   55ce0:	jne    55cd6 <sqlite3VdbeExec+0x6836>
   55ce2:	cmp    eax,ecx
   55ce4:	jge    55cea <sqlite3VdbeExec+0x684a>
   55ce6:	add    r14d,0x1
   55cea:	movsxd rax,r14d
   55ced:	lea    r12,[rax+r15*1]
   55cf1:	mov    r15,QWORD PTR [rsp+0x1f8]
   55cf9:	lea    rax,[r12+r15*1]
   55cfd:	mov    QWORD PTR [rsp+0x1f0],r13
   55d05:	mov    r13,QWORD PTR [rsp+0x208]
   55d0d:	movsxd rcx,DWORD PTR [r13+0x20]
   55d11:	cmp    rax,rcx
   55d14:	jg     55d6a <sqlite3VdbeExec+0x68ca>
   55d16:	mov    rax,QWORD PTR [r13+0x28]
   55d1a:	mov    QWORD PTR [r13+0x8],rax
   55d1e:	mov    DWORD PTR [r13+0x10],r12d
   55d22:	mov    WORD PTR [r13+0x14],0x10
   55d29:	test   r15,r15
   55d2c:	je     55d41 <sqlite3VdbeExec+0x68a1>
   55d2e:	mov    DWORD PTR [r13+0x0],r15d
   55d32:	movzx  eax,WORD PTR [r13+0x14]
   55d37:	or     eax,0x400
   55d3c:	mov    WORD PTR [r13+0x14],ax
   55d41:	mov    r12,QWORD PTR [r13+0x8]
   55d45:	movsxd rax,r14d
   55d48:	lea    r13,[r12+rax*1]
   55d4c:	cmp    r14d,0x80
   55d53:	jge    55e70 <sqlite3VdbeExec+0x69d0>
   55d59:	lea    r15,[r12+0x1]
   55d5e:	mov    BYTE PTR [r12],r14b
   55d62:	mov    r12,r15
   55d65:	jmp    55f03 <sqlite3VdbeExec+0x6a63>
   55d6a:	lea    rax,[r12+r15*1]
   55d6e:	mov    QWORD PTR [rsp+0x1c8],rbp
   55d76:	mov    rbp,QWORD PTR [rsp+0x1a8]
   55d7e:	movsxd rcx,DWORD PTR [rbp+0x88]
   55d85:	cmp    rax,rcx
   55d88:	jg     54d59 <sqlite3VdbeExec+0x58b9>
   55d8e:	mov    eax,r12d
   55d91:	cmp    eax,DWORD PTR [r13+0x20]
   55d95:	jle    55e20 <sqlite3VdbeExec+0x6980>
   55d9b:	xor    ecx,ecx
   55d9d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   55da8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   55db3:	mov    QWORD PTR [rsp+0x190],rdi
   55dbb:	mov    rdi,r13
   55dbe:	mov    rsi,rax
   55dc1:	mov    rdx,rcx
   55dc4:	call   55dc9 <sqlite3VdbeExec+0x6929>
   55dc9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   55dd4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   55ddf:	mov    rdi,QWORD PTR [rsp+0x190]
   55de7:	test   eax,eax
   55de9:	jne    55e00 <sqlite3VdbeExec+0x6960>
   55deb:	mov    QWORD PTR [rsp+0x1a8],rbp
   55df3:	mov    rbp,QWORD PTR [rsp+0x1c8]
   55dfb:	jmp    55d1e <sqlite3VdbeExec+0x687e>
   55e00:	mov    r14,rbp
   55e03:	mov    r13,QWORD PTR [rsp+0x1d0]
   55e0b:	mov    rbx,QWORD PTR [rsp+0x1c8]
   55e13:	mov    rbp,QWORD PTR [rsp+0x1d8]
   55e1b:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   55e20:	mov    QWORD PTR [rsp+0x1a8],rbp
   55e28:	mov    QWORD PTR [rsp+0x1f8],r15
   55e30:	mov    r15,r13
   55e33:	mov    r13,QWORD PTR [rsp+0x1f0]
   55e3b:	mov    rbp,QWORD PTR [rsp+0x1c8]
   55e43:	mov    rax,QWORD PTR [r15+0x28]
   55e47:	mov    QWORD PTR [r15+0x8],rax
   55e4b:	movzx  eax,WORD PTR [r15+0x14]
   55e50:	and    eax,0x2d
   55e53:	mov    WORD PTR [r15+0x14],ax
   55e58:	mov    QWORD PTR [rsp+0x1f0],r13
   55e60:	mov    r13,r15
   55e63:	mov    r15,QWORD PTR [rsp+0x1f8]
   55e6b:	jmp    55d1e <sqlite3VdbeExec+0x687e>
   55e70:	mov    rax,r14
   55e73:	cmp    rax,0x7f
   55e77:	ja     55e88 <sqlite3VdbeExec+0x69e8>
   55e79:	and    rax,0x7f
   55e7d:	mov    BYTE PTR [r12],al
   55e81:	mov    eax,0x1
   55e86:	jmp    55efd <sqlite3VdbeExec+0x6a5d>
   55e88:	cmp    rax,0x3fff
   55e8e:	ja     55eb6 <sqlite3VdbeExec+0x6a16>
   55e90:	mov    rcx,rax
   55e93:	shr    rcx,0x7
   55e97:	and    rcx,0x7f
   55e9b:	or     rcx,0x80
   55ea2:	mov    BYTE PTR [r12],cl
   55ea6:	and    rax,0x7f
   55eaa:	mov    BYTE PTR [r12+0x1],al
   55eaf:	mov    eax,0x2
   55eb4:	jmp    55efd <sqlite3VdbeExec+0x6a5d>
   55eb6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   55ec1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   55ecc:	mov    QWORD PTR [rsp+0x190],rdi
   55ed4:	mov    rdi,r12
   55ed7:	mov    rsi,rax
   55eda:	call   55edf <sqlite3VdbeExec+0x6a3f>
   55edf:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   55eea:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   55ef5:	mov    rdi,QWORD PTR [rsp+0x190]
   55efd:	movsxd rax,eax
   55f00:	add    r12,rax
   55f03:	mov    r14,QWORD PTR [rsp+0x1f0]
   55f0b:	mov    r15,r13
   55f0e:	jmp    56208 <sqlite3VdbeExec+0x6d68>
   55f13:	lea    r13,[rip+0x0]        # 55f1a <sqlite3VdbeExec+0x6a7a>
   55f1a:	cmp    eax,0x7
   55f1d:	jne    55f2c <sqlite3VdbeExec+0x6a8c>
   55f1f:	mov    rcx,QWORD PTR [r14]
   55f22:	mov    QWORD PTR [rsp+0x1f0],rcx
   55f2a:	jmp    55f37 <sqlite3VdbeExec+0x6a97>
   55f2c:	mov    rcx,QWORD PTR [r14]
   55f2f:	mov    QWORD PTR [rsp+0x1f0],rcx
   55f37:	lea    rcx,[rip+0x0]        # 55f3e <sqlite3VdbeExec+0x6a9e>
   55f3e:	movzx  eax,BYTE PTR [rcx+rax*1]
   55f42:	mov    ecx,eax
   55f44:	sub    ecx,0x1
   55f47:	cmp    ecx,0x5
   55f4a:	ja     55f5b <sqlite3VdbeExec+0x6abb>
   55f4c:	mov    ecx,eax
   55f4e:	sub    ecx,0x1
   55f51:	movsxd rcx,DWORD PTR [r13+rcx*4+0x0]
   55f56:	add    rcx,r13
   55f59:	jmp    rcx
   55f5b:	mov    rcx,QWORD PTR [rsp+0x1f0]
   55f63:	and    rcx,0xff
   55f6a:	mov    BYTE PTR [r15+0x7],cl
   55f6e:	mov    rcx,QWORD PTR [rsp+0x1f0]
   55f76:	shr    rcx,0x8
   55f7a:	mov    QWORD PTR [rsp+0x1f0],rcx
   55f82:	mov    rcx,QWORD PTR [rsp+0x1f0]
   55f8a:	and    rcx,0xff
   55f91:	mov    BYTE PTR [r15+0x6],cl
   55f95:	mov    rcx,QWORD PTR [rsp+0x1f0]
   55f9d:	shr    rcx,0x8
   55fa1:	mov    QWORD PTR [rsp+0x1f0],rcx
   55fa9:	mov    rcx,QWORD PTR [rsp+0x1f0]
   55fb1:	and    rcx,0xff
   55fb8:	mov    BYTE PTR [r15+0x5],cl
   55fbc:	mov    rcx,QWORD PTR [rsp+0x1f0]
   55fc4:	shr    rcx,0x8
   55fc8:	mov    QWORD PTR [rsp+0x1f0],rcx
   55fd0:	mov    rcx,QWORD PTR [rsp+0x1f0]
   55fd8:	and    rcx,0xff
   55fdf:	mov    BYTE PTR [r15+0x4],cl
   55fe3:	mov    rcx,QWORD PTR [rsp+0x1f0]
   55feb:	shr    rcx,0x8
   55fef:	mov    QWORD PTR [rsp+0x1f0],rcx
   55ff7:	mov    rcx,QWORD PTR [rsp+0x1f0]
   55fff:	and    rcx,0xff
   56006:	mov    BYTE PTR [r15+0x3],cl
   5600a:	mov    rcx,QWORD PTR [rsp+0x1f0]
   56012:	shr    rcx,0x8
   56016:	mov    QWORD PTR [rsp+0x1f0],rcx
   5601e:	mov    rcx,QWORD PTR [rsp+0x1f0]
   56026:	and    rcx,0xff
   5602d:	mov    BYTE PTR [r15+0x2],cl
   56031:	mov    rcx,QWORD PTR [rsp+0x1f0]
   56039:	shr    rcx,0x8
   5603d:	mov    QWORD PTR [rsp+0x1f0],rcx
   56045:	mov    rcx,QWORD PTR [rsp+0x1f0]
   5604d:	and    rcx,0xff
   56054:	mov    BYTE PTR [r15+0x1],cl
   56058:	mov    rcx,QWORD PTR [rsp+0x1f0]
   56060:	shr    rcx,0x8
   56064:	mov    QWORD PTR [rsp+0x1f0],rcx
   5606c:	mov    rcx,QWORD PTR [rsp+0x1f0]
   56074:	and    rcx,0xff
   5607b:	mov    BYTE PTR [r15],cl
   5607e:	add    r15,rax
   56081:	jmp    561ef <sqlite3VdbeExec+0x6d4f>
   56086:	cmp    eax,0x80
   5608b:	jae    560ff <sqlite3VdbeExec+0x6c5f>
   5608d:	mov    BYTE PTR [r12],al
   56091:	add    r12,0x1
   56095:	cmp    eax,0xe
   56098:	jb     560fa <sqlite3VdbeExec+0x6c5a>
   5609a:	cmp    DWORD PTR [r14+0x10],0x0
   5609f:	jle    560fa <sqlite3VdbeExec+0x6c5a>
   560a1:	mov    rax,QWORD PTR [r14+0x8]
   560a5:	movsxd rcx,DWORD PTR [r14+0x10]
   560a9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   560b4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   560bf:	mov    QWORD PTR [rsp+0x190],rdi
   560c7:	mov    rdi,r15
   560ca:	mov    rsi,rax
   560cd:	mov    rdx,rcx
   560d0:	call   560d5 <sqlite3VdbeExec+0x6c35>
   560d5:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   560e0:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   560eb:	movsxd rax,DWORD PTR [r14+0x10]
   560ef:	add    r15,rax
   560f2:	mov    rdi,QWORD PTR [rsp+0x190]
   560fa:	jmp    561ef <sqlite3VdbeExec+0x6d4f>
   560ff:	cmp    rax,0x7f
   56103:	ja     56114 <sqlite3VdbeExec+0x6c74>
   56105:	and    rax,0x7f
   56109:	mov    BYTE PTR [r12],al
   5610d:	mov    eax,0x1
   56112:	jmp    56189 <sqlite3VdbeExec+0x6ce9>
   56114:	cmp    rax,0x3fff
   5611a:	ja     56142 <sqlite3VdbeExec+0x6ca2>
   5611c:	mov    rcx,rax
   5611f:	shr    rcx,0x7
   56123:	and    rcx,0x7f
   56127:	or     rcx,0x80
   5612e:	mov    BYTE PTR [r12],cl
   56132:	and    rax,0x7f
   56136:	mov    BYTE PTR [r12+0x1],al
   5613b:	mov    eax,0x2
   56140:	jmp    56189 <sqlite3VdbeExec+0x6ce9>
   56142:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5614d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   56158:	mov    QWORD PTR [rsp+0x190],rdi
   56160:	mov    rdi,r12
   56163:	mov    rsi,rax
   56166:	call   5616b <sqlite3VdbeExec+0x6ccb>
   5616b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56176:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   56181:	mov    rdi,QWORD PTR [rsp+0x190]
   56189:	movsxd rax,eax
   5618c:	add    r12,rax
   5618f:	cmp    DWORD PTR [r14+0x10],0x0
   56194:	je     561ef <sqlite3VdbeExec+0x6d4f>
   56196:	mov    rax,QWORD PTR [r14+0x8]
   5619a:	movsxd rcx,DWORD PTR [r14+0x10]
   5619e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   561a9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   561b4:	mov    QWORD PTR [rsp+0x190],rdi
   561bc:	mov    rdi,r15
   561bf:	mov    rsi,rax
   561c2:	mov    rdx,rcx
   561c5:	call   561ca <sqlite3VdbeExec+0x6d2a>
   561ca:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   561d5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   561e0:	movsxd rax,DWORD PTR [r14+0x10]
   561e4:	add    r15,rax
   561e7:	mov    rdi,QWORD PTR [rsp+0x190]
   561ef:	mov    r13,QWORD PTR [rsp+0x1e8]
   561f7:	cmp    r14,r13
   561fa:	je     5622a <sqlite3VdbeExec+0x6d8a>
   561fc:	add    r14,0x38
   56200:	mov    QWORD PTR [rsp+0x1e8],r13
   56208:	mov    eax,DWORD PTR [r14+0x24]
   5620c:	cmp    eax,0x7
   5620f:	ja     56086 <sqlite3VdbeExec+0x6be6>
   56215:	mov    BYTE PTR [r12],al
   56219:	add    r12,0x1
   5621d:	test   eax,eax
   5621f:	jne    55f13 <sqlite3VdbeExec+0x6a73>
   56225:	jmp    56081 <sqlite3VdbeExec+0x6be1>
   5622a:	mov    r14,QWORD PTR [rsp+0x1a8]
   56232:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   56237:	mov    QWORD PTR [rsp+0x1a8],r14
   5623f:	mov    QWORD PTR [rsp+0x1b0],r12
   56247:	mov    rax,QWORD PTR [rdi+0x78]
   5624b:	movsxd rcx,DWORD PTR [rbp+0x4]
   5624f:	mov    rax,QWORD PTR [rax+rcx*8]
   56253:	mov    r12,QWORD PTR [rax+0x28]
   56257:	cmp    DWORD PTR [rbp+0xc],0x0
   5625b:	je     56354 <sqlite3VdbeExec+0x6eb4>
   56261:	cmp    BYTE PTR [r12],0x0
   56266:	je     5626c <sqlite3VdbeExec+0x6dcc>
   56268:	xor    eax,eax
   5626a:	jmp    562bc <sqlite3VdbeExec+0x6e1c>
   5626c:	mov    rax,QWORD PTR [r12+0x88]
   56274:	cmp    BYTE PTR [rax+0x8],0x0
   56278:	jne    56283 <sqlite3VdbeExec+0x6de3>
   5627a:	mov    rax,0xffffffffffffffff
   56281:	jmp    562bc <sqlite3VdbeExec+0x6e1c>
   56283:	mov    rax,QWORD PTR [r12+0x88]
   5628b:	movzx  eax,WORD PTR [rax+0x18]
   5628f:	xor    ecx,ecx
   56291:	jmp    562b0 <sqlite3VdbeExec+0x6e10>
   56293:	mov    rdx,rcx
   56296:	mov    rdx,QWORD PTR [r12+rdx*8+0x90]
   5629e:	movzx  edx,WORD PTR [rdx+0x18]
   562a2:	add    edx,0x1
   562a5:	imul   rax,rdx
   562a9:	mov    edx,0x1
   562ae:	add    cl,dl
   562b0:	mov    edx,ecx
   562b2:	movsx  esi,BYTE PTR [r12+0x54]
   562b8:	cmp    edx,esi
   562ba:	jl     56293 <sqlite3VdbeExec+0x6df3>
   562bc:	mov    QWORD PTR [rsp+0x1e8],rax
   562c4:	mov    rax,QWORD PTR [rdi+0x68]
   562c8:	movsxd rcx,DWORD PTR [rbp+0x8]
   562cc:	imul   rcx,rcx,0x38
   562d0:	lea    rdx,[rax+rcx*1]
   562d4:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   562d9:	and    eax,0x9000
   562de:	test   eax,eax
   562e0:	je     5675f <sqlite3VdbeExec+0x72bf>
   562e6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   562f1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   562fc:	mov    QWORD PTR [rsp+0x190],rdi
   56304:	mov    rdi,rdx
   56307:	call   5630c <sqlite3VdbeExec+0x6e6c>
   5630c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56317:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   56322:	mov    rdi,QWORD PTR [rsp+0x190]
   5632a:	mov    r14,QWORD PTR [rsp+0x1a8]
   56332:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5633a:	mov    r13,rbx
   5633d:	mov    ebx,DWORD PTR [rsp+0x410]
   56344:	mov    r12d,DWORD PTR [rsp+0x414]
   5634c:	mov    rdx,rax
   5634f:	jmp    56787 <sqlite3VdbeExec+0x72e7>
   56354:	mov    QWORD PTR [rsp+0x1e8],0x0
   56360:	xor    r14d,r14d
   56363:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5636e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   56379:	mov    QWORD PTR [rsp+0x190],rdi
   56381:	mov    rdi,r12
   56384:	call   56389 <sqlite3VdbeExec+0x6ee9>
   56389:	mov    r15d,eax
   5638c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56397:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   563a2:	mov    rdi,QWORD PTR [rsp+0x190]
   563aa:	cmp    r15d,0x10
   563ae:	jne    5665d <sqlite3VdbeExec+0x71bd>
   563b4:	mov    QWORD PTR [rsp+0x1e8],0x0
   563c0:	xor    r12d,r12d
   563c3:	mov    r15,r12
   563c6:	jmp    56725 <sqlite3VdbeExec+0x7285>
   563cb:	mov    WORD PTR [r12+0x46],0x0
   563d3:	movzx  eax,BYTE PTR [r12+0x1]
   563d9:	and    eax,0xfffffff9
   563dc:	mov    BYTE PTR [r12+0x1],al
   563e1:	movsx  rax,BYTE PTR [r12+0x54]
   563e7:	add    rax,0xffffffffffffffff
   563eb:	movzx  eax,WORD PTR [r12+rax*2+0x58]
   563f1:	mov    WORD PTR [r12+0x56],ax
   563f7:	mov    rax,QWORD PTR [r12+0x88]
   563ff:	movsx  ecx,BYTE PTR [r12+0x54]
   56405:	sub    ecx,0x1
   56408:	movzx  ecx,cl
   5640b:	mov    BYTE PTR [r12+0x54],cl
   56410:	movsx  rcx,cl
   56414:	mov    rcx,QWORD PTR [r12+rcx*8+0x90]
   5641c:	mov    QWORD PTR [r12+0x88],rcx
   56424:	mov    rax,QWORD PTR [rax+0x70]
   56428:	movzx  ecx,WORD PTR [rax+0x34]
   5642c:	and    ecx,0x20
   5642f:	test   ecx,ecx
   56431:	je     564c6 <sqlite3VdbeExec+0x7026>
   56437:	mov    rcx,QWORD PTR [rax+0x28]
   5643b:	mov    edx,DWORD PTR [rcx+0x98]
   56441:	sub    edx,0x1
   56444:	mov    DWORD PTR [rcx+0x98],edx
   5644a:	mov    rdx,QWORD PTR [rcx+0xa8]
   56451:	mov    QWORD PTR [rax+0x20],rdx
   56455:	mov    QWORD PTR [rcx+0xa8],rax
   5645c:	mov    rdx,QWORD PTR [rcx+0x48]
   56460:	mov    esi,DWORD PTR [rax+0x30]
   56463:	sub    esi,0x1
   56466:	imul   rsi,QWORD PTR [rcx+0xc8]
   5646e:	mov    rax,QWORD PTR [rax+0x8]
   56472:	mov    rcx,QWORD PTR [rdx]
   56475:	mov    rcx,QWORD PTR [rcx+0x90]
   5647c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   56487:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   56492:	mov    QWORD PTR [rsp+0x190],rdi
   5649a:	mov    rdi,rdx
   5649d:	mov    rdx,rax
   564a0:	mov    r10,rcx
   564a3:	call   r10
   564a6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   564b1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   564bc:	mov    rdi,QWORD PTR [rsp+0x190]
   564c4:	jmp    5650a <sqlite3VdbeExec+0x706a>
   564c6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   564d1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   564dc:	mov    QWORD PTR [rsp+0x190],rdi
   564e4:	mov    rdi,rax
   564e7:	call   564ec <sqlite3VdbeExec+0x704c>
   564ec:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   564f7:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   56502:	mov    rdi,QWORD PTR [rsp+0x190]
   5650a:	movzx  eax,WORD PTR [r12+0x56]
   56510:	mov    rcx,QWORD PTR [r12+0x88]
   56518:	movzx  ecx,WORD PTR [rcx+0x18]
   5651c:	cmp    eax,ecx
   5651e:	jge    566bd <sqlite3VdbeExec+0x721d>
   56524:	movzx  eax,WORD PTR [r12+0x56]
   5652a:	add    eax,0x1
   5652d:	mov    WORD PTR [r12+0x56],ax
   56533:	mov    rax,QWORD PTR [r12+0x88]
   5653b:	movzx  ecx,WORD PTR [r12+0x56]
   56541:	movzx  edx,WORD PTR [rax+0x18]
   56545:	cmp    ecx,edx
   56547:	jne    565c5 <sqlite3VdbeExec+0x7125>
   56549:	mov    rcx,QWORD PTR [rax+0x50]
   5654d:	movzx  eax,BYTE PTR [rax+0x9]
   56551:	add    eax,0x8
   56554:	movzx  edx,BYTE PTR [rcx+rax*1]
   56558:	shl    edx,0x18
   5655b:	movzx  esi,BYTE PTR [rcx+rax*1+0x1]
   56560:	shl    esi,0x10
   56563:	or     edx,esi
   56565:	movzx  esi,BYTE PTR [rcx+rax*1+0x2]
   5656a:	shl    esi,0x8
   5656d:	or     edx,esi
   5656f:	movzx  eax,BYTE PTR [rcx+rax*1+0x3]
   56574:	or     edx,eax
   56576:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   56581:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5658c:	mov    QWORD PTR [rsp+0x190],rdi
   56594:	mov    rdi,r12
   56597:	mov    rsi,rdx
   5659a:	call   5659f <sqlite3VdbeExec+0x70ff>
   5659f:	mov    r15d,eax
   565a2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   565ad:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   565b8:	mov    rdi,QWORD PTR [rsp+0x190]
   565c0:	jmp    5665d <sqlite3VdbeExec+0x71bd>
   565c5:	mov    rdx,QWORD PTR [rax+0x50]
   565c9:	movzx  esi,WORD PTR [rax+0x1a]
   565cd:	mov    r8,QWORD PTR [rax+0x60]
   565d1:	mov    r9d,ecx
   565d4:	shl    r9d,1
   565d7:	movzx  r8d,BYTE PTR [r8+r9*1]
   565dc:	shl    r8d,0x8
   565e0:	mov    rax,QWORD PTR [rax+0x60]
   565e4:	shl    ecx,1
   565e6:	movzx  eax,BYTE PTR [rax+rcx*1+0x1]
   565eb:	or     r8d,eax
   565ee:	and    esi,r8d
   565f1:	movzx  eax,BYTE PTR [rdx+rsi*1]
   565f5:	shl    eax,0x18
   565f8:	movzx  ecx,BYTE PTR [rdx+rsi*1+0x1]
   565fd:	shl    ecx,0x10
   56600:	or     eax,ecx
   56602:	movzx  ecx,BYTE PTR [rdx+rsi*1+0x2]
   56607:	shl    ecx,0x8
   5660a:	or     eax,ecx
   5660c:	movzx  ecx,BYTE PTR [rdx+rsi*1+0x3]
   56611:	or     eax,ecx
   56613:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5661e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   56629:	mov    QWORD PTR [rsp+0x190],rdi
   56631:	mov    rdi,r12
   56634:	mov    rsi,rax
   56637:	call   5663c <sqlite3VdbeExec+0x719c>
   5663c:	mov    r15d,eax
   5663f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5664a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   56655:	mov    rdi,QWORD PTR [rsp+0x190]
   5665d:	test   r15d,r15d
   56660:	je     5666f <sqlite3VdbeExec+0x71cf>
   56662:	mov    r13,QWORD PTR [rsp+0x1a8]
   5666a:	jmp    5671d <sqlite3VdbeExec+0x727d>
   5666f:	mov    r13,QWORD PTR [rsp+0x1a8]
   56677:	mov    eax,DWORD PTR [r13+0x190]
   5667e:	test   eax,eax
   56680:	jne    5671d <sqlite3VdbeExec+0x727d>
   56686:	mov    rax,QWORD PTR [r12+0x88]
   5668e:	cmp    BYTE PTR [rax+0x8],0x0
   56692:	jne    566a4 <sqlite3VdbeExec+0x7204>
   56694:	cmp    BYTE PTR [rax+0x1],0x0
   56698:	je     566a4 <sqlite3VdbeExec+0x7204>
   5669a:	mov    QWORD PTR [rsp+0x1a8],r13
   566a2:	jmp    566b3 <sqlite3VdbeExec+0x7213>
   566a4:	movzx  ecx,WORD PTR [rax+0x18]
   566a8:	add    r14,rcx
   566ab:	mov    QWORD PTR [rsp+0x1a8],r13
   566b3:	cmp    BYTE PTR [rax+0x8],0x0
   566b7:	je     5653b <sqlite3VdbeExec+0x709b>
   566bd:	cmp    BYTE PTR [r12+0x54],0x0
   566c3:	jne    563cb <sqlite3VdbeExec+0x6f2b>
   566c9:	mov    QWORD PTR [rsp+0x1e8],r14
   566d1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   566dc:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   566e7:	mov    QWORD PTR [rsp+0x190],rdi
   566ef:	mov    rdi,r12
   566f2:	call   566f7 <sqlite3VdbeExec+0x7257>
   566f7:	mov    r12d,eax
   566fa:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56705:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   56710:	mov    rdi,QWORD PTR [rsp+0x190]
   56718:	mov    r15,r12
   5671b:	jmp    56725 <sqlite3VdbeExec+0x7285>
   5671d:	mov    QWORD PTR [rsp+0x1a8],r13
   56725:	test   r15d,r15d
   56728:	jne    56737 <sqlite3VdbeExec+0x7297>
   5672a:	mov    DWORD PTR [rsp+0x40c],r15d
   56732:	jmp    562c4 <sqlite3VdbeExec+0x6e24>
   56737:	mov    r14,QWORD PTR [rsp+0x1a8]
   5673f:	mov    QWORD PTR [rsp+0x1c8],rbp
   56747:	mov    rbp,r15
   5674a:	mov    r13,QWORD PTR [rsp+0x1b0]
   56752:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5675a:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5675f:	mov    WORD PTR [rdx+0x14],0x4
   56765:	mov    r14,QWORD PTR [rsp+0x1a8]
   5676d:	mov    r15d,DWORD PTR [rsp+0x3fc]
   56775:	mov    r13,rbx
   56778:	mov    ebx,DWORD PTR [rsp+0x410]
   5677f:	mov    r12d,DWORD PTR [rsp+0x414]
   56787:	mov    rax,QWORD PTR [rsp+0x1e8]
   5678f:	mov    QWORD PTR [rdx],rax
   56792:	mov    QWORD PTR [rsp+0x1c8],rbp
   5679a:	mov    QWORD PTR [rsp+0x1e0],r13
   567a2:	mov    r13,QWORD PTR [rsp+0x1d0]
   567aa:	jmp    4f836 <sqlite3VdbeExec+0x396>
   567af:	mov    r15d,DWORD PTR [rsp+0x3fc]
   567b7:	mov    r13,QWORD PTR [rsp+0x1d0]
   567bf:	mov    QWORD PTR [rsp+0x1b0],r12
   567c7:	mov    r12d,DWORD PTR [rsp+0x414]
   567cf:	mov    DWORD PTR [rsp+0x414],r12d
   567d7:	mov    r12d,DWORD PTR [rbp+0x4]
   567db:	mov    QWORD PTR [rsp+0x1d0],r13
   567e3:	mov    r13,QWORD PTR [rbp+0x10]
   567e7:	test   r12d,r12d
   567ea:	jne    56a85 <sqlite3VdbeExec+0x75e5>
   567f0:	cmp    DWORD PTR [r14+0xd8],0x0
   567f8:	jle    5685a <sqlite3VdbeExec+0x73ba>
   567fa:	lea    rax,[rip+0x0]        # 56801 <sqlite3VdbeExec+0x7361>
   56801:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5680c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   56817:	mov    QWORD PTR [rsp+0x190],rdi
   5681f:	mov    rsi,rax
   56822:	xor    eax,eax
   56824:	call   56829 <sqlite3VdbeExec+0x7389>
   56829:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56834:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5683f:	mov    r12d,0x5
   56845:	mov    rdi,QWORD PTR [rsp+0x190]
   5684d:	mov    DWORD PTR [rsp+0x418],r12d
   56855:	jmp    56a54 <sqlite3VdbeExec+0x75b4>
   5685a:	test   r13,r13
   5685d:	jne    56864 <sqlite3VdbeExec+0x73c4>
   5685f:	xor    r12d,r12d
   56862:	jmp    568b2 <sqlite3VdbeExec+0x7412>
   56864:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5686f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5687a:	mov    QWORD PTR [rsp+0x190],rdi
   56882:	mov    rdi,r13
   56885:	call   5688a <sqlite3VdbeExec+0x73ea>
   5688a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56895:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   568a0:	mov    r12d,eax
   568a3:	and    r12d,0x3fffffff
   568aa:	mov    rdi,QWORD PTR [rsp+0x190]
   568b2:	xor    eax,eax
   568b4:	mov    ecx,DWORD PTR [r14+0x2ec]
   568bb:	add    ecx,DWORD PTR [r14+0x2e8]
   568c2:	mov    QWORD PTR [rsp+0x1a8],r14
   568ca:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   568d5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   568e0:	mov    QWORD PTR [rsp+0x190],rdi
   568e8:	mov    rdi,r14
   568eb:	mov    rsi,rax
   568ee:	mov    rdx,rcx
   568f1:	call   568f6 <sqlite3VdbeExec+0x7456>
   568f6:	mov    r14d,eax
   568f9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56904:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5690f:	mov    rdi,QWORD PTR [rsp+0x190]
   56917:	test   r14d,r14d
   5691a:	je     56944 <sqlite3VdbeExec+0x74a4>
   5691c:	mov    QWORD PTR [rsp+0x1c8],rbp
   56924:	mov    rbp,r14
   56927:	mov    r14,QWORD PTR [rsp+0x1a8]
   5692f:	mov    r13,QWORD PTR [rsp+0x1b0]
   56937:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5693f:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   56944:	mov    rax,r12
   56947:	add    rax,0x20
   5694b:	add    rax,0x1
   5694f:	mov    DWORD PTR [rsp+0x418],r14d
   56957:	mov    r14,QWORD PTR [rsp+0x1a8]
   5695f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5696a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   56975:	mov    rdi,r14
   56978:	mov    rsi,rax
   5697b:	call   56980 <sqlite3VdbeExec+0x74e0>
   56980:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5698b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   56996:	mov    rdi,QWORD PTR [rsp+0x190]
   5699e:	test   rax,rax
   569a1:	je     56a54 <sqlite3VdbeExec+0x75b4>
   569a7:	lea    rcx,[rax+0x20]
   569ab:	mov    QWORD PTR [rax],rcx
   569ae:	mov    rcx,QWORD PTR [rax]
   569b1:	lea    edx,[r12+0x1]
   569b6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   569c1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   569cc:	mov    QWORD PTR [rsp+0x188],rax
   569d4:	mov    rdi,rcx
   569d7:	mov    rsi,r13
   569da:	call   569df <sqlite3VdbeExec+0x753f>
   569df:	mov    rcx,rax
   569e2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   569ed:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   569f8:	mov    rax,QWORD PTR [rsp+0x188]
   56a00:	mov    rdi,QWORD PTR [rsp+0x190]
   56a08:	cmp    BYTE PTR [r14+0x65],0x0
   56a0d:	je     56a1b <sqlite3VdbeExec+0x757b>
   56a0f:	mov    BYTE PTR [r14+0x65],0x0
   56a14:	mov    BYTE PTR [r14+0x6d],0x1
   56a19:	jmp    56a2c <sqlite3VdbeExec+0x758c>
   56a1b:	mov    ecx,DWORD PTR [r14+0x2e8]
   56a22:	add    ecx,0x1
   56a25:	mov    DWORD PTR [r14+0x2e8],ecx
   56a2c:	mov    rcx,QWORD PTR [r14+0x2d8]
   56a33:	mov    QWORD PTR [rax+0x18],rcx
   56a37:	mov    QWORD PTR [r14+0x2d8],rax
   56a3e:	mov    rcx,QWORD PTR [r14+0x2f0]
   56a45:	mov    QWORD PTR [rax+0x8],rcx
   56a49:	mov    rcx,QWORD PTR [r14+0x2f8]
   56a50:	mov    QWORD PTR [rax+0x10],rcx
   56a54:	mov    r12d,DWORD PTR [rsp+0x418]
   56a5c:	test   r12d,r12d
   56a5f:	je     572af <sqlite3VdbeExec+0x7e0f>
   56a65:	mov    QWORD PTR [rsp+0x1c8],rbp
   56a6d:	mov    rbp,r12
   56a70:	mov    r13,QWORD PTR [rsp+0x1b0]
   56a78:	mov    rbx,QWORD PTR [rsp+0x1d8]
   56a80:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   56a85:	mov    QWORD PTR [rsp+0x1e8],r13
   56a8d:	mov    r13,QWORD PTR [r14+0x2d8]
   56a94:	mov    DWORD PTR [rsp+0x420],r12d
   56a9c:	mov    r12,r13
   56a9f:	xor    r13d,r13d
   56aa2:	jmp    56af2 <sqlite3VdbeExec+0x7652>
   56aa4:	lea    rsi,[rip+0x0]        # 56aab <sqlite3VdbeExec+0x760b>
   56aab:	movzx  ecx,BYTE PTR [rsi+rcx*1]
   56aaf:	movzx  edx,BYTE PTR [rsi+rdx*1]
   56ab3:	sub    ecx,edx
   56ab5:	test   ecx,ecx
   56ab7:	je     56abb <sqlite3VdbeExec+0x761b>
   56ab9:	jmp    56ad3 <sqlite3VdbeExec+0x7633>
   56abb:	add    rax,0x1
   56abf:	add    r13,0x1
   56ac3:	movzx  ecx,BYTE PTR [rax]
   56ac6:	movzx  edx,BYTE PTR [r13+0x0]
   56acb:	cmp    ecx,edx
   56acd:	jne    56aa4 <sqlite3VdbeExec+0x7604>
   56acf:	test   ecx,ecx
   56ad1:	jne    56abb <sqlite3VdbeExec+0x761b>
   56ad3:	test   ecx,ecx
   56ad5:	jne    56ae1 <sqlite3VdbeExec+0x7641>
   56ad7:	mov    r13d,DWORD PTR [rsp+0x418]
   56adf:	jmp    56b0d <sqlite3VdbeExec+0x766d>
   56ae1:	mov    r13d,DWORD PTR [rsp+0x418]
   56ae9:	add    r13d,0x1
   56aed:	mov    r12,QWORD PTR [r12+0x18]
   56af2:	test   r12,r12
   56af5:	je     56b0d <sqlite3VdbeExec+0x766d>
   56af7:	mov    rax,QWORD PTR [r12]
   56afb:	mov    DWORD PTR [rsp+0x418],r13d
   56b03:	mov    r13,QWORD PTR [rsp+0x1e8]
   56b0b:	jmp    56ac3 <sqlite3VdbeExec+0x7623>
   56b0d:	test   r12,r12
   56b10:	jne    56b75 <sqlite3VdbeExec+0x76d5>
   56b12:	lea    rax,[rip+0x0]        # 56b19 <sqlite3VdbeExec+0x7679>
   56b19:	mov    r13,QWORD PTR [rsp+0x1e8]
   56b21:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   56b2c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   56b37:	mov    QWORD PTR [rsp+0x190],rdi
   56b3f:	mov    rsi,rax
   56b42:	mov    rdx,r13
   56b45:	xor    eax,eax
   56b47:	call   56b4c <sqlite3VdbeExec+0x76ac>
   56b4c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56b57:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   56b62:	mov    r12d,0x1
   56b68:	mov    rdi,QWORD PTR [rsp+0x190]
   56b70:	jmp    56a5c <sqlite3VdbeExec+0x75bc>
   56b75:	cmp    DWORD PTR [r14+0xd8],0x0
   56b7d:	jg     56b91 <sqlite3VdbeExec+0x76f1>
   56b7f:	mov    DWORD PTR [rsp+0x3fc],r15d
   56b87:	mov    r15d,DWORD PTR [rsp+0x420]
   56b8f:	jmp    56c07 <sqlite3VdbeExec+0x7767>
   56b91:	mov    DWORD PTR [rsp+0x3fc],r15d
   56b99:	mov    r15d,DWORD PTR [rsp+0x420]
   56ba1:	cmp    r15d,0x1
   56ba5:	jne    56c07 <sqlite3VdbeExec+0x7767>
   56ba7:	lea    rax,[rip+0x0]        # 56bae <sqlite3VdbeExec+0x770e>
   56bae:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   56bb9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   56bc4:	mov    QWORD PTR [rsp+0x190],rdi
   56bcc:	mov    rsi,rax
   56bcf:	xor    eax,eax
   56bd1:	call   56bd6 <sqlite3VdbeExec+0x7736>
   56bd6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56be1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   56bec:	mov    r12d,0x5
   56bf2:	mov    rdi,QWORD PTR [rsp+0x190]
   56bfa:	mov    r15d,DWORD PTR [rsp+0x3fc]
   56c02:	jmp    56a5c <sqlite3VdbeExec+0x75bc>
   56c07:	cmp    QWORD PTR [r12+0x18],0x0
   56c0d:	jne    56c25 <sqlite3VdbeExec+0x7785>
   56c0f:	mov    DWORD PTR [rsp+0x418],r13d
   56c17:	xor    r13d,r13d
   56c1a:	cmp    BYTE PTR [r14+0x6d],0x0
   56c1f:	setne  r13b
   56c23:	jmp    56c30 <sqlite3VdbeExec+0x7790>
   56c25:	mov    DWORD PTR [rsp+0x418],r13d
   56c2d:	xor    r13d,r13d
   56c30:	test   r13d,r13d
   56c33:	jne    56c4a <sqlite3VdbeExec+0x77aa>
   56c35:	mov    DWORD PTR [rsp+0x41c],r13d
   56c3d:	mov    r13d,DWORD PTR [rsp+0x418]
   56c45:	jmp    56de1 <sqlite3VdbeExec+0x7941>
   56c4a:	cmp    r15d,0x1
   56c4e:	je     56c65 <sqlite3VdbeExec+0x77c5>
   56c50:	mov    DWORD PTR [rsp+0x41c],r13d
   56c58:	mov    r13d,DWORD PTR [rsp+0x418]
   56c60:	jmp    56de1 <sqlite3VdbeExec+0x7941>
   56c65:	mov    rax,QWORD PTR [rdi]
   56c68:	mov    rcx,QWORD PTR [rax+0x2f0]
   56c6f:	add    rcx,QWORD PTR [rax+0x2f8]
   56c76:	test   rcx,rcx
   56c79:	jne    56c88 <sqlite3VdbeExec+0x77e8>
   56c7b:	mov    DWORD PTR [rsp+0x41c],r13d
   56c83:	xor    r13d,r13d
   56c86:	jmp    56cd4 <sqlite3VdbeExec+0x7834>
   56c88:	mov    DWORD PTR [rsp+0x41c],r13d
   56c90:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   56c9b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   56ca6:	mov    QWORD PTR [rsp+0x190],rdi
   56cae:	call   56cb3 <sqlite3VdbeExec+0x7813>
   56cb3:	mov    r13d,eax
   56cb6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56cc1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   56ccc:	mov    rdi,QWORD PTR [rsp+0x190]
   56cd4:	test   r13d,r13d
   56cd7:	je     56cf9 <sqlite3VdbeExec+0x7859>
   56cd9:	mov    r12,r13
   56cdc:	mov    r13d,DWORD PTR [rsp+0x400]
   56ce4:	mov    r15,QWORD PTR [rsp+0x1b0]
   56cec:	mov    rbx,QWORD PTR [rsp+0x1d8]
   56cf4:	jmp    6c449 <sqlite3VdbeExec+0x1cfa9>
   56cf9:	mov    r13,QWORD PTR [rsp+0x1d0]
   56d01:	mov    BYTE PTR [r14+0x65],0x1
   56d06:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   56d11:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   56d1c:	mov    QWORD PTR [rsp+0x190],rdi
   56d24:	call   56d29 <sqlite3VdbeExec+0x7889>
   56d29:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56d34:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   56d3f:	mov    rdi,QWORD PTR [rsp+0x190]
   56d47:	cmp    eax,0x5
   56d4a:	jne    56dac <sqlite3VdbeExec+0x790c>
   56d4c:	mov    rax,rbp
   56d4f:	sub    rax,r13
   56d52:	movabs rdx,0x2aaaaaaaaaaaaaab
   56d5c:	imul   rdx
   56d5f:	sar    rdx,0x2
   56d63:	mov    rax,rdx
   56d66:	shr    rax,0x3f
   56d6a:	add    rdx,rax
   56d6d:	mov    rax,rdx
   56d70:	mov    DWORD PTR [rdi+0x30],eax
   56d73:	mov    BYTE PTR [r14+0x65],0x0
   56d78:	mov    ebx,0x5
   56d7d:	mov    DWORD PTR [rdi+0x34],0x5
   56d84:	mov    QWORD PTR [rsp+0x1d0],r13
   56d8c:	mov    r12,rbx
   56d8f:	mov    r13d,DWORD PTR [rsp+0x400]
   56d97:	mov    r15,QWORD PTR [rsp+0x1b0]
   56d9f:	mov    rbx,QWORD PTR [rsp+0x1d8]
   56da7:	jmp    6c449 <sqlite3VdbeExec+0x1cfa9>
   56dac:	mov    DWORD PTR [rsp+0x420],r15d
   56db4:	mov    r15d,DWORD PTR [rdi+0x34]
   56db8:	test   r15d,r15d
   56dbb:	je     56dc4 <sqlite3VdbeExec+0x7924>
   56dbd:	mov    BYTE PTR [r14+0x65],0x0
   56dc2:	jmp    56dc9 <sqlite3VdbeExec+0x7929>
   56dc4:	mov    BYTE PTR [r14+0x6d],0x0
   56dc9:	mov    QWORD PTR [rsp+0x1d0],r13
   56dd1:	mov    r13,r15
   56dd4:	mov    r15d,DWORD PTR [rsp+0x420]
   56ddc:	jmp    57098 <sqlite3VdbeExec+0x7bf8>
   56de1:	mov    eax,DWORD PTR [r14+0x2e8]
   56de8:	sub    eax,r13d
   56deb:	mov    r13d,eax
   56dee:	sub    r13d,0x1
   56df2:	cmp    r15d,0x2
   56df6:	jne    56f21 <sqlite3VdbeExec+0x7a81>
   56dfc:	mov    eax,DWORD PTR [r14+0x2c]
   56e00:	mov    DWORD PTR [rsp+0x418],r13d
   56e08:	mov    r13d,eax
   56e0b:	and    r13d,0x1
   56e0f:	mov    DWORD PTR [rsp+0x424],r13d
   56e17:	test   r13d,r13d
   56e1a:	mov    r13d,0x0
   56e20:	setne  r13b
   56e24:	mov    DWORD PTR [rsp+0x428],r13d
   56e2c:	xor    r13d,r13d
   56e2f:	jmp    56e55 <sqlite3VdbeExec+0x79b5>
   56e31:	mov    DWORD PTR [rsp+0x42c],r14d
   56e39:	mov    r14,QWORD PTR [rsp+0x1a8]
   56e41:	add    r13d,0x1
   56e45:	mov    r11d,DWORD PTR [rsp+0x42c]
   56e4d:	mov    DWORD PTR [rsp+0x40c],r11d
   56e55:	cmp    r13d,DWORD PTR [r14+0x28]
   56e59:	jge    56f07 <sqlite3VdbeExec+0x7a67>
   56e5f:	mov    rax,QWORD PTR [r14+0x20]
   56e63:	mov    rcx,r13
   56e66:	shl    rcx,0x5
   56e6a:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   56e6f:	mov    ecx,0x204
   56e74:	mov    QWORD PTR [rsp+0x1a8],r14
   56e7c:	mov    r14d,DWORD PTR [rsp+0x424]
   56e84:	xor    edx,edx
   56e86:	test   r14d,r14d
   56e89:	sete   dl
   56e8c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   56e97:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   56ea2:	mov    QWORD PTR [rsp+0x190],rdi
   56eaa:	mov    rdi,rax
   56ead:	mov    rsi,rcx
   56eb0:	call   56eb5 <sqlite3VdbeExec+0x7a15>
   56eb5:	mov    r14d,eax
   56eb8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56ec3:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   56ece:	mov    rdi,QWORD PTR [rsp+0x190]
   56ed6:	test   r14d,r14d
   56ed9:	je     56e31 <sqlite3VdbeExec+0x7991>
   56edf:	mov    QWORD PTR [rsp+0x1c8],rbp
   56ee7:	mov    rbp,r14
   56eea:	mov    r14,QWORD PTR [rsp+0x1a8]
   56ef2:	mov    r13,QWORD PTR [rsp+0x1b0]
   56efa:	mov    rbx,QWORD PTR [rsp+0x1d8]
   56f02:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   56f07:	mov    QWORD PTR [rsp+0x1a8],r14
   56f0f:	mov    r14,QWORD PTR [rsp+0x1a8]
   56f17:	mov    r13d,DWORD PTR [rsp+0x428]
   56f1f:	jmp    56f2c <sqlite3VdbeExec+0x7a8c>
   56f21:	mov    DWORD PTR [rsp+0x418],r13d
   56f29:	xor    r13d,r13d
   56f2c:	mov    DWORD PTR [rsp+0x428],r13d
   56f34:	xor    r13d,r13d
   56f37:	jmp    56f5d <sqlite3VdbeExec+0x7abd>
   56f39:	mov    DWORD PTR [rsp+0x42c],r14d
   56f41:	mov    r14,QWORD PTR [rsp+0x1a8]
   56f49:	add    r13d,0x1
   56f4d:	mov    r11d,DWORD PTR [rsp+0x42c]
   56f55:	mov    DWORD PTR [rsp+0x40c],r11d
   56f5d:	cmp    r13d,DWORD PTR [r14+0x28]
   56f61:	jge    57005 <sqlite3VdbeExec+0x7b65>
   56f67:	mov    rax,QWORD PTR [r14+0x20]
   56f6b:	mov    rcx,r13
   56f6e:	shl    rcx,0x5
   56f72:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   56f77:	mov    QWORD PTR [rsp+0x1a8],r14
   56f7f:	mov    r14d,DWORD PTR [rsp+0x418]
   56f87:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   56f92:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   56f9d:	mov    QWORD PTR [rsp+0x190],rdi
   56fa5:	mov    rdi,rax
   56fa8:	mov    rsi,r15
   56fab:	mov    rdx,r14
   56fae:	call   56fb3 <sqlite3VdbeExec+0x7b13>
   56fb3:	mov    r14d,eax
   56fb6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   56fc1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   56fcc:	mov    rdi,QWORD PTR [rsp+0x190]
   56fd4:	test   r14d,r14d
   56fd7:	je     56f39 <sqlite3VdbeExec+0x7a99>
   56fdd:	mov    QWORD PTR [rsp+0x1c8],rbp
   56fe5:	mov    rbp,r14
   56fe8:	mov    r14,QWORD PTR [rsp+0x1a8]
   56ff0:	mov    r13,QWORD PTR [rsp+0x1b0]
   56ff8:	mov    rbx,QWORD PTR [rsp+0x1d8]
   57000:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   57005:	mov    r13d,DWORD PTR [rsp+0x428]
   5700d:	test   r13d,r13d
   57010:	jne    5701c <sqlite3VdbeExec+0x7b7c>
   57012:	mov    r13d,DWORD PTR [rsp+0x40c]
   5701a:	jmp    57098 <sqlite3VdbeExec+0x7bf8>
   5701c:	mov    rax,QWORD PTR [r14+0x8]
   57020:	jmp    5703c <sqlite3VdbeExec+0x7b9c>
   57022:	movzx  ecx,WORD PTR [rax+0xc8]
   57029:	and    rcx,0xfffffffffffffffc
   5702d:	or     rcx,0x1
   57031:	mov    WORD PTR [rax+0xc8],cx
   57038:	mov    rax,QWORD PTR [rax+0x10]
   5703c:	test   rax,rax
   5703f:	jne    57022 <sqlite3VdbeExec+0x7b82>
   57041:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5704c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57057:	mov    QWORD PTR [rsp+0x190],rdi
   5705f:	mov    rdi,r14
   57062:	call   57067 <sqlite3VdbeExec+0x7bc7>
   57067:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57072:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5707d:	mov    eax,DWORD PTR [r14+0x2c]
   57081:	or     eax,0x1
   57084:	mov    DWORD PTR [r14+0x2c],eax
   57088:	mov    rdi,QWORD PTR [rsp+0x190]
   57090:	mov    r13d,DWORD PTR [rsp+0x40c]
   57098:	test   r13d,r13d
   5709b:	je     57130 <sqlite3VdbeExec+0x7c90>
   570a1:	mov    QWORD PTR [rsp+0x1c8],rbp
   570a9:	mov    rbp,r13
   570ac:	mov    r13,QWORD PTR [rsp+0x1b0]
   570b4:	mov    rbx,QWORD PTR [rsp+0x1d8]
   570bc:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   570c1:	mov    rax,QWORD PTR [r14+0x2d8]
   570c8:	mov    rcx,QWORD PTR [rax+0x18]
   570cc:	mov    QWORD PTR [r14+0x2d8],rcx
   570d3:	test   rax,rax
   570d6:	je     5711f <sqlite3VdbeExec+0x7c7f>
   570d8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   570e3:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   570ee:	mov    QWORD PTR [rsp+0x190],rdi
   570f6:	mov    rdi,r14
   570f9:	mov    rsi,rax
   570fc:	call   57101 <sqlite3VdbeExec+0x7c61>
   57101:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5710c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57117:	mov    rdi,QWORD PTR [rsp+0x190]
   5711f:	mov    eax,DWORD PTR [r14+0x2e8]
   57126:	sub    eax,0x1
   57129:	mov    DWORD PTR [r14+0x2e8],eax
   57130:	cmp    r12,QWORD PTR [r14+0x2d8]
   57137:	jne    570c1 <sqlite3VdbeExec+0x7c21>
   57139:	cmp    r15d,0x1
   5713d:	jne    571d3 <sqlite3VdbeExec+0x7d33>
   57143:	mov    rax,QWORD PTR [r12+0x18]
   57148:	mov    QWORD PTR [r14+0x2d8],rax
   5714f:	test   r12,r12
   57152:	je     5719b <sqlite3VdbeExec+0x7cfb>
   57154:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5715f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5716a:	mov    QWORD PTR [rsp+0x190],rdi
   57172:	mov    rdi,r14
   57175:	mov    rsi,r12
   57178:	call   5717d <sqlite3VdbeExec+0x7cdd>
   5717d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57188:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57193:	mov    rdi,QWORD PTR [rsp+0x190]
   5719b:	mov    r12d,DWORD PTR [rsp+0x41c]
   571a3:	test   r12d,r12d
   571a6:	je     571b5 <sqlite3VdbeExec+0x7d15>
   571a8:	mov    DWORD PTR [rsp+0x420],r15d
   571b0:	mov    r15,r12
   571b3:	jmp    571fb <sqlite3VdbeExec+0x7d5b>
   571b5:	mov    eax,DWORD PTR [r14+0x2e8]
   571bc:	sub    eax,0x1
   571bf:	mov    DWORD PTR [r14+0x2e8],eax
   571c6:	mov    DWORD PTR [rsp+0x420],r15d
   571ce:	mov    r15,r12
   571d1:	jmp    571fb <sqlite3VdbeExec+0x7d5b>
   571d3:	mov    DWORD PTR [rsp+0x420],r15d
   571db:	mov    r15d,DWORD PTR [rsp+0x41c]
   571e3:	mov    rax,QWORD PTR [r12+0x8]
   571e8:	mov    QWORD PTR [r14+0x2f0],rax
   571ef:	mov    rax,QWORD PTR [r12+0x10]
   571f4:	mov    QWORD PTR [r14+0x2f8],rax
   571fb:	test   r15d,r15d
   571fe:	jne    5720a <sqlite3VdbeExec+0x7d6a>
   57200:	mov    r15d,DWORD PTR [rsp+0x420]
   57208:	jmp    57228 <sqlite3VdbeExec+0x7d88>
   5720a:	mov    r15d,DWORD PTR [rsp+0x420]
   57212:	cmp    r15d,0x2
   57216:	je     57228 <sqlite3VdbeExec+0x7d88>
   57218:	mov    r15d,DWORD PTR [rsp+0x3fc]
   57220:	mov    r12,r13
   57223:	jmp    56a5c <sqlite3VdbeExec+0x75bc>
   57228:	mov    r12d,DWORD PTR [rsp+0x418]
   57230:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5723b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57246:	mov    QWORD PTR [rsp+0x190],rdi
   5724e:	mov    rdi,r14
   57251:	mov    rsi,r15
   57254:	mov    rdx,r12
   57257:	call   5725c <sqlite3VdbeExec+0x7dbc>
   5725c:	mov    r12d,eax
   5725f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5726a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57275:	mov    rdi,QWORD PTR [rsp+0x190]
   5727d:	test   r12d,r12d
   57280:	jne    5728f <sqlite3VdbeExec+0x7def>
   57282:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5728a:	jmp    56a5c <sqlite3VdbeExec+0x75bc>
   5728f:	mov    QWORD PTR [rsp+0x1c8],rbp
   57297:	mov    rbp,r12
   5729a:	mov    r13,QWORD PTR [rsp+0x1b0]
   572a2:	mov    rbx,QWORD PTR [rsp+0x1d8]
   572aa:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   572af:	cmp    BYTE PTR [rdi+0xc7],0x3
   572b6:	jne    572dd <sqlite3VdbeExec+0x7e3d>
   572b8:	mov    ebx,0x65
   572bd:	mov    r12,rbx
   572c0:	mov    r13d,DWORD PTR [rsp+0x400]
   572c8:	mov    r15,QWORD PTR [rsp+0x1b0]
   572d0:	mov    rbx,QWORD PTR [rsp+0x1d8]
   572d8:	jmp    6c449 <sqlite3VdbeExec+0x1cfa9>
   572dd:	mov    DWORD PTR [rsp+0x3fc],r15d
   572e5:	mov    DWORD PTR [rsp+0x40c],r12d
   572ed:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   572f2:	mov    QWORD PTR [rsp+0x1b0],r12
   572fa:	mov    ebx,DWORD PTR [rbp+0x4]
   572fd:	mov    eax,DWORD PTR [rbp+0x8]
   57300:	movzx  ecx,BYTE PTR [r14+0x65]
   57305:	cmp    ebx,ecx
   57307:	je     5750d <sqlite3VdbeExec+0x806d>
   5730d:	test   eax,eax
   5730f:	je     57343 <sqlite3VdbeExec+0x7ea3>
   57311:	mov    eax,0x204
   57316:	mov    QWORD PTR [rsp+0x190],rdi
   5731e:	mov    rdi,r14
   57321:	mov    rsi,rax
   57324:	call   57329 <sqlite3VdbeExec+0x7e89>
   57329:	mov    BYTE PTR [r14+0x65],0x1
   5732e:	mov    rdi,QWORD PTR [rsp+0x190]
   57336:	mov    r13,QWORD PTR [rsp+0x1d0]
   5733e:	jmp    573f8 <sqlite3VdbeExec+0x7f58>
   57343:	test   ebx,ebx
   57345:	je     57397 <sqlite3VdbeExec+0x7ef7>
   57347:	cmp    DWORD PTR [r14+0xd8],0x0
   5734f:	jle    57397 <sqlite3VdbeExec+0x7ef7>
   57351:	lea    rax,[rip+0x0]        # 57358 <sqlite3VdbeExec+0x7eb8>
   57358:	mov    QWORD PTR [rsp+0x190],rdi
   57360:	mov    rsi,rax
   57363:	xor    eax,eax
   57365:	call   5736a <sqlite3VdbeExec+0x7eca>
   5736a:	mov    ebx,0x5
   5736f:	mov    rdi,QWORD PTR [rsp+0x190]
   57377:	mov    QWORD PTR [rsp+0x1c8],rbp
   5737f:	mov    rbp,rbx
   57382:	mov    r13,QWORD PTR [rsp+0x1b0]
   5738a:	mov    rbx,QWORD PTR [rsp+0x1d8]
   57392:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   57397:	mov    rax,QWORD PTR [rdi]
   5739a:	mov    rcx,QWORD PTR [rax+0x2f0]
   573a1:	add    rcx,QWORD PTR [rax+0x2f8]
   573a8:	test   rcx,rcx
   573ab:	jne    573b2 <sqlite3VdbeExec+0x7f12>
   573ad:	xor    r12d,r12d
   573b0:	jmp    573ca <sqlite3VdbeExec+0x7f2a>
   573b2:	mov    QWORD PTR [rsp+0x190],rdi
   573ba:	call   573bf <sqlite3VdbeExec+0x7f1f>
   573bf:	mov    r12d,eax
   573c2:	mov    rdi,QWORD PTR [rsp+0x190]
   573ca:	test   r12d,r12d
   573cd:	je     573ec <sqlite3VdbeExec+0x7f4c>
   573cf:	mov    r13d,DWORD PTR [rsp+0x400]
   573d7:	mov    r15,QWORD PTR [rsp+0x1b0]
   573df:	mov    rbx,QWORD PTR [rsp+0x1d8]
   573e7:	jmp    6c449 <sqlite3VdbeExec+0x1cfa9>
   573ec:	mov    r13,QWORD PTR [rsp+0x1d0]
   573f4:	mov    BYTE PTR [r14+0x65],bl
   573f8:	mov    QWORD PTR [rsp+0x190],rdi
   57400:	call   57405 <sqlite3VdbeExec+0x7f65>
   57405:	mov    rdi,QWORD PTR [rsp+0x190]
   5740d:	cmp    eax,0x5
   57410:	jne    574ae <sqlite3VdbeExec+0x800e>
   57416:	mov    rax,rbp
   57419:	sub    rax,r13
   5741c:	movabs rdx,0x2aaaaaaaaaaaaaab
   57426:	imul   rdx
   57429:	sar    rdx,0x2
   5742d:	mov    rax,rdx
   57430:	shr    rax,0x3f
   57434:	add    rdx,rax
   57437:	mov    rax,rdx
   5743a:	mov    DWORD PTR [rdi+0x30],eax
   5743d:	mov    eax,0x1
   57442:	sub    eax,ebx
   57444:	mov    BYTE PTR [r14+0x65],al
   57448:	mov    ebx,0x5
   5744d:	mov    DWORD PTR [rdi+0x34],0x5
   57454:	mov    QWORD PTR [rsp+0x1d0],r13
   5745c:	mov    r12,rbx
   5745f:	mov    r13d,DWORD PTR [rsp+0x400]
   57467:	mov    r15,QWORD PTR [rsp+0x1b0]
   5746f:	mov    rbx,QWORD PTR [rsp+0x1d8]
   57477:	jmp    6c449 <sqlite3VdbeExec+0x1cfa9>
   5747c:	mov    rax,QWORD PTR [r14+0x2d8]
   57483:	mov    rcx,QWORD PTR [rax+0x18]
   57487:	mov    QWORD PTR [r14+0x2d8],rcx
   5748e:	test   rax,rax
   57491:	je     574ae <sqlite3VdbeExec+0x800e>
   57493:	mov    QWORD PTR [rsp+0x190],rdi
   5749b:	mov    rdi,r14
   5749e:	mov    rsi,rax
   574a1:	call   574a6 <sqlite3VdbeExec+0x8006>
   574a6:	mov    rdi,QWORD PTR [rsp+0x190]
   574ae:	cmp    QWORD PTR [r14+0x2d8],0x0
   574b6:	jne    5747c <sqlite3VdbeExec+0x7fdc>
   574b8:	mov    DWORD PTR [r14+0x2e8],0x0
   574c3:	mov    DWORD PTR [r14+0x2ec],0x0
   574ce:	mov    BYTE PTR [r14+0x6d],0x0
   574d3:	cmp    DWORD PTR [rdi+0x34],0x0
   574d7:	jne    574e0 <sqlite3VdbeExec+0x8040>
   574d9:	mov    ebx,0x65
   574de:	jmp    574e5 <sqlite3VdbeExec+0x8045>
   574e0:	mov    ebx,0x1
   574e5:	mov    QWORD PTR [rsp+0x1d0],r13
   574ed:	mov    r12,rbx
   574f0:	mov    r13d,DWORD PTR [rsp+0x400]
   574f8:	mov    r15,QWORD PTR [rsp+0x1b0]
   57500:	mov    rbx,QWORD PTR [rsp+0x1d8]
   57508:	jmp    6c449 <sqlite3VdbeExec+0x1cfa9>
   5750d:	test   ebx,ebx
   5750f:	jne    5751a <sqlite3VdbeExec+0x807a>
   57511:	lea    rax,[rip+0x0]        # 57518 <sqlite3VdbeExec+0x8078>
   57518:	jmp    5752e <sqlite3VdbeExec+0x808e>
   5751a:	test   eax,eax
   5751c:	je     57527 <sqlite3VdbeExec+0x8087>
   5751e:	lea    rax,[rip+0x0]        # 57525 <sqlite3VdbeExec+0x8085>
   57525:	jmp    5752e <sqlite3VdbeExec+0x808e>
   57527:	lea    rax,[rip+0x0]        # 5752e <sqlite3VdbeExec+0x808e>
   5752e:	mov    QWORD PTR [rsp+0x190],rdi
   57536:	mov    rsi,rax
   57539:	xor    eax,eax
   5753b:	call   57540 <sqlite3VdbeExec+0x80a0>
   57540:	mov    ebx,0x1
   57545:	mov    rdi,QWORD PTR [rsp+0x190]
   5754d:	mov    QWORD PTR [rsp+0x1c8],rbp
   57555:	mov    rbp,rbx
   57558:	mov    r13,QWORD PTR [rsp+0x1b0]
   57560:	mov    rbx,QWORD PTR [rsp+0x1d8]
   57568:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5756d:	mov    r15d,DWORD PTR [rsp+0x3fc]
   57575:	mov    r13,QWORD PTR [rsp+0x1d0]
   5757d:	mov    QWORD PTR [rsp+0x1b0],r12
   57585:	mov    r12d,DWORD PTR [rsp+0x414]
   5758d:	mov    DWORD PTR [rsp+0x418],0x0
   57598:	cmp    DWORD PTR [rbp+0x8],0x0
   5759c:	je     57603 <sqlite3VdbeExec+0x8163>
   5759e:	movabs rax,0x200100000
   575a8:	and    rax,QWORD PTR [r14+0x30]
   575ac:	test   rax,rax
   575af:	je     57603 <sqlite3VdbeExec+0x8163>
   575b1:	mov    rax,QWORD PTR [r14+0x30]
   575b5:	and    rax,0x100000
   575bb:	test   rax,rax
   575be:	je     575d0 <sqlite3VdbeExec+0x8130>
   575c0:	mov    ebx,0x8
   575c5:	mov    r11,rbx
   575c8:	mov    rbx,rbp
   575cb:	mov    rbp,r11
   575ce:	jmp    575de <sqlite3VdbeExec+0x813e>
   575d0:	mov    ebx,0xb
   575d5:	mov    r11,rbx
   575d8:	mov    rbx,rbp
   575db:	mov    rbp,r11
   575de:	mov    QWORD PTR [rsp+0x1d0],r13
   575e6:	mov    QWORD PTR [rsp+0x1c8],rbx
   575ee:	mov    r13,QWORD PTR [rsp+0x1b0]
   575f6:	mov    rbx,QWORD PTR [rsp+0x1d8]
   575fe:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   57603:	mov    DWORD PTR [rsp+0x414],r12d
   5760b:	mov    r12,QWORD PTR [r14+0x20]
   5760f:	movsxd rax,DWORD PTR [rbp+0x4]
   57613:	mov    QWORD PTR [rsp+0x1d0],r13
   5761b:	mov    r13,rax
   5761e:	shl    r13,0x5
   57622:	mov    QWORD PTR [rsp+0x1e8],r12
   5762a:	mov    r12,QWORD PTR [r12+r13*1+0x8]
   5762f:	test   r12,r12
   57632:	jne    57651 <sqlite3VdbeExec+0x81b1>
   57634:	mov    DWORD PTR [rsp+0x3fc],r15d
   5763c:	mov    r12,QWORD PTR [rsp+0x1e8]
   57644:	mov    r15d,DWORD PTR [rsp+0x40c]
   5764c:	jmp    579d2 <sqlite3VdbeExec+0x8532>
   57651:	mov    eax,DWORD PTR [rbp+0x8]
   57654:	mov    QWORD PTR [rsp+0x1f0],r13
   5765c:	lea    r13,[rsp+0x418]
   57664:	mov    rcx,r13
   57667:	cmp    BYTE PTR [r12+0x11],0x0
   5766d:	jne    57683 <sqlite3VdbeExec+0x81e3>
   5766f:	cmp    BYTE PTR [r12+0x10],0x0
   57675:	je     57683 <sqlite3VdbeExec+0x81e3>
   57677:	cmp    BYTE PTR [r12+0x10],0x1
   5767d:	jne    576d5 <sqlite3VdbeExec+0x8235>
   5767f:	test   eax,eax
   57681:	je     576d5 <sqlite3VdbeExec+0x8235>
   57683:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5768e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57699:	mov    QWORD PTR [rsp+0x190],rdi
   576a1:	mov    rdi,r12
   576a4:	mov    rsi,rax
   576a7:	mov    rdx,rcx
   576aa:	call   576af <sqlite3VdbeExec+0x820f>
   576af:	mov    r13d,eax
   576b2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   576bd:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   576c8:	mov    rdi,QWORD PTR [rsp+0x190]
   576d0:	jmp    57785 <sqlite3VdbeExec+0x82e5>
   576d5:	mov    rdx,QWORD PTR [r12+0x8]
   576da:	test   rcx,rcx
   576dd:	je     57712 <sqlite3VdbeExec+0x8272>
   576df:	mov    rsi,QWORD PTR [rdx+0x18]
   576e3:	mov    rsi,QWORD PTR [rsi+0x50]
   576e7:	movzx  r8d,BYTE PTR [rsi+0x28]
   576ec:	shl    r8d,0x18
   576f0:	movzx  r9d,BYTE PTR [rsi+0x29]
   576f5:	shl    r9d,0x10
   576f9:	or     r8d,r9d
   576fc:	movzx  r9d,BYTE PTR [rsi+0x2a]
   57701:	shl    r9d,0x8
   57705:	or     r8d,r9d
   57708:	movzx  esi,BYTE PTR [rsi+0x2b]
   5770c:	or     r8d,esi
   5770f:	mov    DWORD PTR [rcx],r8d
   57712:	test   eax,eax
   57714:	je     57782 <sqlite3VdbeExec+0x82e2>
   57716:	mov    rax,QWORD PTR [rdx]
   57719:	mov    rcx,QWORD PTR [r12]
   5771d:	mov    ecx,DWORD PTR [rcx+0x2e8]
   57723:	cmp    ecx,DWORD PTR [rax+0x80]
   57729:	jle    5777d <sqlite3VdbeExec+0x82dd>
   5772b:	cmp    BYTE PTR [rax+0xa],0x0
   5772f:	je     5777d <sqlite3VdbeExec+0x82dd>
   57731:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5773c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57747:	mov    QWORD PTR [rsp+0x190],rdi
   5774f:	mov    rdi,rax
   57752:	mov    rsi,rcx
   57755:	call   5775a <sqlite3VdbeExec+0x82ba>
   5775a:	mov    r13d,eax
   5775d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57768:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57773:	mov    rdi,QWORD PTR [rsp+0x190]
   5777b:	jmp    57780 <sqlite3VdbeExec+0x82e0>
   5777d:	xor    r13d,r13d
   57780:	jmp    57785 <sqlite3VdbeExec+0x82e5>
   57782:	xor    r13d,r13d
   57785:	test   r13d,r13d
   57788:	je     57826 <sqlite3VdbeExec+0x8386>
   5778e:	mov    eax,r13d
   57791:	and    eax,0xff
   57796:	cmp    eax,0x5
   57799:	jne    577f6 <sqlite3VdbeExec+0x8356>
   5779b:	mov    rbx,QWORD PTR [rsp+0x1d0]
   577a3:	mov    rax,rbp
   577a6:	sub    rax,rbx
   577a9:	movabs rdx,0x2aaaaaaaaaaaaaab
   577b3:	imul   rdx
   577b6:	sar    rdx,0x2
   577ba:	mov    rax,rdx
   577bd:	shr    rax,0x3f
   577c1:	add    rdx,rax
   577c4:	mov    rax,rdx
   577c7:	mov    DWORD PTR [rdi+0x30],eax
   577ca:	mov    DWORD PTR [rdi+0x34],r13d
   577ce:	mov    QWORD PTR [rsp+0x1d0],rbx
   577d6:	mov    r12,r13
   577d9:	mov    r13d,DWORD PTR [rsp+0x400]
   577e1:	mov    r15,QWORD PTR [rsp+0x1b0]
   577e9:	mov    rbx,QWORD PTR [rsp+0x1d8]
   577f1:	jmp    6c449 <sqlite3VdbeExec+0x1cfa9>
   577f6:	mov    rbx,QWORD PTR [rsp+0x1d0]
   577fe:	mov    QWORD PTR [rsp+0x1d0],rbx
   57806:	mov    QWORD PTR [rsp+0x1c8],rbp
   5780e:	mov    rbp,r13
   57811:	mov    r13,QWORD PTR [rsp+0x1b0]
   57819:	mov    rbx,QWORD PTR [rsp+0x1d8]
   57821:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   57826:	movzx  eax,WORD PTR [rdi+0xc8]
   5782d:	shl    rax,0x3a
   57831:	shr    rax,0x3f
   57835:	test   eax,eax
   57837:	jne    57859 <sqlite3VdbeExec+0x83b9>
   57839:	mov    DWORD PTR [rsp+0x3fc],r15d
   57841:	mov    r12,QWORD PTR [rsp+0x1e8]
   57849:	mov    r15,r13
   5784c:	mov    r13,QWORD PTR [rsp+0x1f0]
   57854:	jmp    579d2 <sqlite3VdbeExec+0x8532>
   57859:	cmp    DWORD PTR [rbp+0x8],0x0
   5785d:	jne    5787f <sqlite3VdbeExec+0x83df>
   5785f:	mov    DWORD PTR [rsp+0x3fc],r15d
   57867:	mov    r12,QWORD PTR [rsp+0x1e8]
   5786f:	mov    r15,r13
   57872:	mov    r13,QWORD PTR [rsp+0x1f0]
   5787a:	jmp    579d2 <sqlite3VdbeExec+0x8532>
   5787f:	cmp    BYTE PTR [r14+0x65],0x0
   57884:	je     578b0 <sqlite3VdbeExec+0x8410>
   57886:	cmp    DWORD PTR [r14+0xd4],0x1
   5788e:	jg     578b0 <sqlite3VdbeExec+0x8410>
   57890:	mov    DWORD PTR [rsp+0x3fc],r15d
   57898:	mov    r12,QWORD PTR [rsp+0x1e8]
   578a0:	mov    r15,r13
   578a3:	mov    r13,QWORD PTR [rsp+0x1f0]
   578ab:	jmp    579d2 <sqlite3VdbeExec+0x8532>
   578b0:	cmp    DWORD PTR [rdi+0x40],0x0
   578b4:	jne    578d8 <sqlite3VdbeExec+0x8438>
   578b6:	mov    eax,DWORD PTR [r14+0x2ec]
   578bd:	add    eax,0x1
   578c0:	mov    DWORD PTR [r14+0x2ec],eax
   578c7:	mov    eax,DWORD PTR [r14+0x2e8]
   578ce:	add    eax,DWORD PTR [r14+0x2ec]
   578d5:	mov    DWORD PTR [rdi+0x40],eax
   578d8:	xor    eax,eax
   578da:	mov    ecx,DWORD PTR [rdi+0x40]
   578dd:	sub    ecx,0x1
   578e0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   578eb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   578f6:	mov    QWORD PTR [rsp+0x190],rdi
   578fe:	mov    rdi,r14
   57901:	mov    rsi,rax
   57904:	mov    rdx,rcx
   57907:	call   5790c <sqlite3VdbeExec+0x846c>
   5790c:	mov    r13d,eax
   5790f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5791a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57925:	mov    rdi,QWORD PTR [rsp+0x190]
   5792d:	test   r13d,r13d
   57930:	jne    579a1 <sqlite3VdbeExec+0x8501>
   57932:	mov    eax,DWORD PTR [rdi+0x40]
   57935:	mov    rcx,QWORD PTR [r12+0x8]
   5793a:	mov    rdx,QWORD PTR [r12+0x8]
   5793f:	mov    rsi,QWORD PTR [r12]
   57943:	mov    QWORD PTR [rdx+0x8],rsi
   57947:	mov    rcx,QWORD PTR [rcx]
   5794a:	cmp    eax,DWORD PTR [rcx+0x80]
   57950:	jle    57999 <sqlite3VdbeExec+0x84f9>
   57952:	cmp    BYTE PTR [rcx+0xa],0x0
   57956:	je     57999 <sqlite3VdbeExec+0x84f9>
   57958:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   57963:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5796e:	mov    rdi,rcx
   57971:	mov    rsi,rax
   57974:	call   57979 <sqlite3VdbeExec+0x84d9>
   57979:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57984:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5798f:	mov    rdi,QWORD PTR [rsp+0x190]
   57997:	jmp    5799b <sqlite3VdbeExec+0x84fb>
   57999:	xor    eax,eax
   5799b:	mov    r12d,eax
   5799e:	mov    r13,r12
   579a1:	mov    rax,QWORD PTR [r14+0x2f0]
   579a8:	mov    QWORD PTR [rdi+0x58],rax
   579ac:	mov    rax,QWORD PTR [r14+0x2f8]
   579b3:	mov    QWORD PTR [rdi+0x60],rax
   579b7:	mov    DWORD PTR [rsp+0x3fc],r15d
   579bf:	mov    r12,QWORD PTR [rsp+0x1e8]
   579c7:	mov    r15,r13
   579ca:	mov    r13,QWORD PTR [rsp+0x1f0]
   579d2:	test   r15d,r15d
   579d5:	jne    57ca8 <sqlite3VdbeExec+0x8808>
   579db:	cmp    WORD PTR [rbp+0x2],0x0
   579e0:	je     57ca8 <sqlite3VdbeExec+0x8808>
   579e6:	mov    eax,DWORD PTR [rsp+0x418]
   579ed:	cmp    eax,DWORD PTR [rbp+0xc]
   579f0:	jne    57a03 <sqlite3VdbeExec+0x8563>
   579f2:	mov    rax,QWORD PTR [r12+r13*1+0x18]
   579f7:	mov    eax,DWORD PTR [rax+0x4]
   579fa:	cmp    eax,DWORD PTR [rbp+0x10]
   579fd:	je     57ca8 <sqlite3VdbeExec+0x8808>
   57a03:	mov    rax,QWORD PTR [rdi+0xa8]
   57a0a:	test   rax,rax
   57a0d:	je     57a56 <sqlite3VdbeExec+0x85b6>
   57a0f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   57a1a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57a25:	mov    QWORD PTR [rsp+0x190],rdi
   57a2d:	mov    rdi,r14
   57a30:	mov    rsi,rax
   57a33:	call   57a38 <sqlite3VdbeExec+0x8598>
   57a38:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57a43:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57a4e:	mov    rdi,QWORD PTR [rsp+0x190]
   57a56:	lea    r12,[rip+0x0]        # 57a5d <sqlite3VdbeExec+0x85bd>
   57a5d:	test   r12,r12
   57a60:	jne    57a6d <sqlite3VdbeExec+0x85cd>
   57a62:	xor    r12d,r12d
   57a65:	mov    r15,r12
   57a68:	jmp    57b8c <sqlite3VdbeExec+0x86ec>
   57a6d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   57a78:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57a83:	mov    QWORD PTR [rsp+0x190],rdi
   57a8b:	mov    rdi,r12
   57a8e:	call   57a93 <sqlite3VdbeExec+0x85f3>
   57a93:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57a9e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57aa9:	lea    r13,[rax+0x1]
   57aad:	mov    rdi,QWORD PTR [rsp+0x190]
   57ab5:	test   r14,r14
   57ab8:	je     57afe <sqlite3VdbeExec+0x865e>
   57aba:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   57ac5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57ad0:	mov    rdi,r14
   57ad3:	mov    rsi,r13
   57ad6:	call   57adb <sqlite3VdbeExec+0x863b>
   57adb:	mov    r15,rax
   57ade:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57ae9:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57af4:	mov    rdi,QWORD PTR [rsp+0x190]
   57afc:	jmp    57b3d <sqlite3VdbeExec+0x869d>
   57afe:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   57b09:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57b14:	mov    rdi,r13
   57b17:	call   57b1c <sqlite3VdbeExec+0x867c>
   57b1c:	mov    r15,rax
   57b1f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57b2a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57b35:	mov    rdi,QWORD PTR [rsp+0x190]
   57b3d:	test   r15,r15
   57b40:	je     57b8c <sqlite3VdbeExec+0x86ec>
   57b42:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   57b4d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57b58:	mov    QWORD PTR [rsp+0x190],rdi
   57b60:	mov    rdi,r15
   57b63:	mov    rsi,r12
   57b66:	mov    rdx,r13
   57b69:	call   57b6e <sqlite3VdbeExec+0x86ce>
   57b6e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57b79:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57b84:	mov    rdi,QWORD PTR [rsp+0x190]
   57b8c:	mov    QWORD PTR [rdi+0xa8],r15
   57b93:	mov    rax,QWORD PTR [r14+0x20]
   57b97:	movsxd rcx,DWORD PTR [rbp+0x4]
   57b9b:	shl    rcx,0x5
   57b9f:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   57ba4:	mov    eax,DWORD PTR [rax]
   57ba6:	cmp    eax,DWORD PTR [rsp+0x418]
   57bad:	je     57c77 <sqlite3VdbeExec+0x87d7>
   57bb3:	movsxd rax,DWORD PTR [rbp+0x4]
   57bb7:	test   eax,eax
   57bb9:	jl     57bf1 <sqlite3VdbeExec+0x8751>
   57bbb:	mov    rcx,QWORD PTR [r14+0x20]
   57bbf:	shl    rax,0x5
   57bc3:	mov    rax,QWORD PTR [rcx+rax*1+0x18]
   57bc8:	movzx  ecx,WORD PTR [rax+0x72]
   57bcc:	or     ecx,0x8
   57bcf:	mov    WORD PTR [rax+0x72],cx
   57bd3:	mov    rax,QWORD PTR [r14+0x20]
   57bd7:	mov    rax,QWORD PTR [rax+0x38]
   57bdb:	movzx  ecx,WORD PTR [rax+0x72]
   57bdf:	or     ecx,0x8
   57be2:	mov    WORD PTR [rax+0x72],cx
   57be6:	mov    eax,DWORD PTR [r14+0x2c]
   57bea:	and    eax,0xffffffef
   57bed:	mov    DWORD PTR [r14+0x2c],eax
   57bf1:	cmp    DWORD PTR [r14+0x48],0x0
   57bf6:	jne    57c77 <sqlite3VdbeExec+0x87d7>
   57bf8:	xor    r12d,r12d
   57bfb:	jmp    57c71 <sqlite3VdbeExec+0x87d1>
   57bfd:	mov    rax,QWORD PTR [r14+0x20]
   57c01:	mov    rcx,r12
   57c04:	shl    rcx,0x5
   57c08:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   57c0d:	movzx  eax,WORD PTR [rax+0x72]
   57c11:	and    eax,0x8
   57c14:	cmp    eax,0x8
   57c17:	jne    57c6d <sqlite3VdbeExec+0x87cd>
   57c19:	mov    rax,QWORD PTR [r14+0x20]
   57c1d:	mov    rcx,r12
   57c20:	shl    rcx,0x5
   57c24:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   57c29:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   57c34:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57c3f:	mov    QWORD PTR [rsp+0x190],rdi
   57c47:	mov    rdi,rax
   57c4a:	call   57c4f <sqlite3VdbeExec+0x87af>
   57c4f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57c5a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57c65:	mov    rdi,QWORD PTR [rsp+0x190]
   57c6d:	add    r12d,0x1
   57c71:	cmp    r12d,DWORD PTR [r14+0x28]
   57c75:	jl     57bfd <sqlite3VdbeExec+0x875d>
   57c77:	movzx  eax,WORD PTR [rdi+0xc8]
   57c7e:	and    rax,0xfffffffffffffffc
   57c82:	or     rax,0x1
   57c86:	mov    WORD PTR [rdi+0xc8],ax
   57c8d:	mov    r12d,0x11
   57c93:	movzx  eax,WORD PTR [rdi+0xc8]
   57c9a:	and    rax,0xffffffffffffffef
   57c9e:	mov    WORD PTR [rdi+0xc8],ax
   57ca5:	mov    r15,r12
   57ca8:	test   r15d,r15d
   57cab:	je     57ccd <sqlite3VdbeExec+0x882d>
   57cad:	mov    QWORD PTR [rsp+0x1c8],rbp
   57cb5:	mov    rbp,r15
   57cb8:	mov    r13,QWORD PTR [rsp+0x1b0]
   57cc0:	mov    rbx,QWORD PTR [rsp+0x1d8]
   57cc8:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   57ccd:	mov    DWORD PTR [rsp+0x40c],r15d
   57cd5:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   57cda:	mov    r15d,DWORD PTR [rsp+0x3fc]
   57ce2:	mov    r13,QWORD PTR [rsp+0x1d0]
   57cea:	mov    QWORD PTR [rsp+0x1b0],r12
   57cf2:	mov    r12d,DWORD PTR [rsp+0x414]
   57cfa:	movsxd rax,DWORD PTR [rbp+0x4]
   57cfe:	mov    ecx,DWORD PTR [rbp+0xc]
   57d01:	mov    rdx,QWORD PTR [r14+0x20]
   57d05:	shl    rax,0x5
   57d09:	mov    rax,QWORD PTR [rdx+rax*1+0x8]
   57d0e:	mov    rdx,QWORD PTR [rax+0x8]
   57d12:	mov    rsi,QWORD PTR [rax+0x8]
   57d16:	mov    r8,QWORD PTR [rax]
   57d19:	mov    QWORD PTR [rsi+0x8],r8
   57d1d:	cmp    ecx,0xf
   57d20:	jne    57d37 <sqlite3VdbeExec+0x8897>
   57d22:	mov    rcx,QWORD PTR [rdx]
   57d25:	mov    ecx,DWORD PTR [rcx+0x84]
   57d2b:	add    ecx,DWORD PTR [rax+0x1c]
   57d2e:	mov    DWORD PTR [rsp+0x418],ecx
   57d35:	jmp    57d71 <sqlite3VdbeExec+0x88d1>
   57d37:	mov    rax,QWORD PTR [rdx+0x18]
   57d3b:	mov    rax,QWORD PTR [rax+0x50]
   57d3f:	shl    ecx,0x2
   57d42:	add    ecx,0x24
   57d45:	movsxd rcx,ecx
   57d48:	movzx  edx,BYTE PTR [rax+rcx*1]
   57d4c:	shl    edx,0x18
   57d4f:	movzx  esi,BYTE PTR [rax+rcx*1+0x1]
   57d54:	shl    esi,0x10
   57d57:	or     edx,esi
   57d59:	movzx  esi,BYTE PTR [rax+rcx*1+0x2]
   57d5e:	shl    esi,0x8
   57d61:	or     edx,esi
   57d63:	movzx  eax,BYTE PTR [rax+rcx*1+0x3]
   57d68:	or     edx,eax
   57d6a:	mov    DWORD PTR [rsp+0x418],edx
   57d71:	mov    rax,QWORD PTR [rdi+0x68]
   57d75:	movsxd rcx,DWORD PTR [rbp+0x8]
   57d79:	imul   rcx,rcx,0x38
   57d7d:	lea    rdx,[rax+rcx*1]
   57d81:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   57d86:	and    eax,0x9000
   57d8b:	test   eax,eax
   57d8d:	je     57dd8 <sqlite3VdbeExec+0x8938>
   57d8f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   57d9a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57da5:	mov    QWORD PTR [rsp+0x190],rdi
   57dad:	mov    rdi,rdx
   57db0:	call   57db5 <sqlite3VdbeExec+0x8915>
   57db5:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57dc0:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57dcb:	mov    rdi,QWORD PTR [rsp+0x190]
   57dd3:	mov    rdx,rax
   57dd6:	jmp    57dde <sqlite3VdbeExec+0x893e>
   57dd8:	mov    WORD PTR [rdx+0x14],0x4
   57dde:	movsxd rax,DWORD PTR [rsp+0x418]
   57de6:	mov    QWORD PTR [rdx],rax
   57de9:	mov    DWORD PTR [rsp+0x3fc],r15d
   57df1:	mov    QWORD PTR [rsp+0x1d0],r13
   57df9:	mov    DWORD PTR [rsp+0x414],r12d
   57e01:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   57e06:	mov    r15d,DWORD PTR [rsp+0x3fc]
   57e0e:	mov    r13,QWORD PTR [rsp+0x1d0]
   57e16:	mov    QWORD PTR [rsp+0x1b0],r12
   57e1e:	mov    r12d,DWORD PTR [rsp+0x414]
   57e26:	mov    DWORD PTR [rsp+0x414],r12d
   57e2e:	mov    r12,QWORD PTR [r14+0x20]
   57e32:	movsxd rax,DWORD PTR [rbp+0x4]
   57e36:	mov    QWORD PTR [rsp+0x1d0],r13
   57e3e:	mov    r13,rax
   57e41:	shl    r13,0x5
   57e45:	mov    rax,QWORD PTR [r12+r13*1+0x8]
   57e4a:	mov    ecx,DWORD PTR [rbp+0x8]
   57e4d:	mov    edx,DWORD PTR [rbp+0xc]
   57e50:	mov    DWORD PTR [rsp+0x3fc],r15d
   57e58:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   57e63:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57e6e:	mov    QWORD PTR [rsp+0x190],rdi
   57e76:	mov    rdi,rax
   57e79:	mov    rsi,rcx
   57e7c:	call   57e81 <sqlite3VdbeExec+0x89e1>
   57e81:	mov    r15d,eax
   57e84:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57e8f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57e9a:	mov    rdi,QWORD PTR [rsp+0x190]
   57ea2:	cmp    DWORD PTR [rbp+0x8],0x1
   57ea6:	jne    582ee <sqlite3VdbeExec+0x8e4e>
   57eac:	mov    rax,QWORD PTR [r12+r13*1+0x18]
   57eb1:	mov    ecx,DWORD PTR [rbp+0xc]
   57eb4:	movzx  edx,WORD PTR [rbp+0x2]
   57eb8:	sub    ecx,edx
   57eba:	mov    DWORD PTR [rax],ecx
   57ebc:	mov    eax,DWORD PTR [r14+0x2c]
   57ec0:	or     eax,0x1
   57ec3:	mov    DWORD PTR [r14+0x2c],eax
   57ec7:	movsxd rax,DWORD PTR [rbp+0x4]
   57ecb:	mov    rcx,QWORD PTR [r14+0x20]
   57ecf:	shl    rax,0x5
   57ed3:	mov    rax,QWORD PTR [rcx+rax*1+0x18]
   57ed8:	mov    r12,QWORD PTR [rax+0x10]
   57edc:	mov    r13,r12
   57edf:	jmp    582d9 <sqlite3VdbeExec+0x8e39>
   57ee4:	mov    DWORD PTR [rsp+0x418],r15d
   57eec:	mov    r15,QWORD PTR [r12+0x30]
   57ef1:	test   r15,r15
   57ef4:	jne    57f03 <sqlite3VdbeExec+0x8a63>
   57ef6:	mov    QWORD PTR [rsp+0x1f0],r13
   57efe:	jmp    580d1 <sqlite3VdbeExec+0x8c31>
   57f03:	mov    QWORD PTR [rsp+0x1f0],r13
   57f0b:	mov    r13,QWORD PTR [r15+0x38]
   57f0f:	mov    rax,QWORD PTR [r13+0x18]
   57f13:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   57f1e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57f29:	mov    QWORD PTR [rsp+0x190],rdi
   57f31:	mov    rdi,r14
   57f34:	mov    rsi,rax
   57f37:	call   57f3c <sqlite3VdbeExec+0x8a9c>
   57f3c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57f47:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57f52:	mov    rax,QWORD PTR [r13+0x20]
   57f56:	mov    rdi,QWORD PTR [rsp+0x190]
   57f5e:	test   rax,rax
   57f61:	je     57fa2 <sqlite3VdbeExec+0x8b02>
   57f63:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   57f6e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57f79:	mov    rdi,r14
   57f7c:	mov    rsi,rax
   57f7f:	call   57f84 <sqlite3VdbeExec+0x8ae4>
   57f84:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57f8f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57f9a:	mov    rdi,QWORD PTR [rsp+0x190]
   57fa2:	mov    rax,QWORD PTR [r13+0x28]
   57fa6:	test   rax,rax
   57fa9:	je     57ff2 <sqlite3VdbeExec+0x8b52>
   57fab:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   57fb6:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   57fc1:	mov    QWORD PTR [rsp+0x190],rdi
   57fc9:	mov    rdi,r14
   57fcc:	mov    rsi,rax
   57fcf:	call   57fd4 <sqlite3VdbeExec+0x8b34>
   57fd4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   57fdf:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   57fea:	mov    rdi,QWORD PTR [rsp+0x190]
   57ff2:	mov    rax,QWORD PTR [r13+0x10]
   57ff6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58001:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5800c:	mov    QWORD PTR [rsp+0x190],rdi
   58014:	mov    rdi,r14
   58017:	mov    rsi,rax
   5801a:	call   5801f <sqlite3VdbeExec+0x8b7f>
   5801f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5802a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58035:	mov    rax,QWORD PTR [r15+0x18]
   58039:	mov    rdi,QWORD PTR [rsp+0x190]
   58041:	test   rax,rax
   58044:	je     58085 <sqlite3VdbeExec+0x8be5>
   58046:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58051:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5805c:	mov    rdi,r14
   5805f:	mov    rsi,rax
   58062:	call   58067 <sqlite3VdbeExec+0x8bc7>
   58067:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58072:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5807d:	mov    rdi,QWORD PTR [rsp+0x190]
   58085:	test   r15,r15
   58088:	je     580d1 <sqlite3VdbeExec+0x8c31>
   5808a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58095:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   580a0:	mov    QWORD PTR [rsp+0x190],rdi
   580a8:	mov    rdi,r14
   580ab:	mov    rsi,r15
   580ae:	call   580b3 <sqlite3VdbeExec+0x8c13>
   580b3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   580be:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   580c9:	mov    rdi,QWORD PTR [rsp+0x190]
   580d1:	mov    QWORD PTR [r12+0x30],0x0
   580da:	mov    r13,QWORD PTR [r12+0x38]
   580df:	test   r13,r13
   580e2:	je     582ae <sqlite3VdbeExec+0x8e0e>
   580e8:	mov    r15,QWORD PTR [r13+0x38]
   580ec:	mov    rax,QWORD PTR [r15+0x18]
   580f0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   580fb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58106:	mov    QWORD PTR [rsp+0x190],rdi
   5810e:	mov    rdi,r14
   58111:	mov    rsi,rax
   58114:	call   58119 <sqlite3VdbeExec+0x8c79>
   58119:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58124:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5812f:	mov    rax,QWORD PTR [r15+0x20]
   58133:	mov    rdi,QWORD PTR [rsp+0x190]
   5813b:	test   rax,rax
   5813e:	je     5817f <sqlite3VdbeExec+0x8cdf>
   58140:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5814b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58156:	mov    rdi,r14
   58159:	mov    rsi,rax
   5815c:	call   58161 <sqlite3VdbeExec+0x8cc1>
   58161:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5816c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58177:	mov    rdi,QWORD PTR [rsp+0x190]
   5817f:	mov    rax,QWORD PTR [r15+0x28]
   58183:	test   rax,rax
   58186:	je     581cf <sqlite3VdbeExec+0x8d2f>
   58188:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58193:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5819e:	mov    QWORD PTR [rsp+0x190],rdi
   581a6:	mov    rdi,r14
   581a9:	mov    rsi,rax
   581ac:	call   581b1 <sqlite3VdbeExec+0x8d11>
   581b1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   581bc:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   581c7:	mov    rdi,QWORD PTR [rsp+0x190]
   581cf:	mov    rax,QWORD PTR [r15+0x10]
   581d3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   581de:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   581e9:	mov    QWORD PTR [rsp+0x190],rdi
   581f1:	mov    rdi,r14
   581f4:	mov    rsi,rax
   581f7:	call   581fc <sqlite3VdbeExec+0x8d5c>
   581fc:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58207:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58212:	mov    rax,QWORD PTR [r13+0x18]
   58216:	mov    rdi,QWORD PTR [rsp+0x190]
   5821e:	test   rax,rax
   58221:	je     58262 <sqlite3VdbeExec+0x8dc2>
   58223:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5822e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58239:	mov    rdi,r14
   5823c:	mov    rsi,rax
   5823f:	call   58244 <sqlite3VdbeExec+0x8da4>
   58244:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5824f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5825a:	mov    rdi,QWORD PTR [rsp+0x190]
   58262:	test   r13,r13
   58265:	je     582ae <sqlite3VdbeExec+0x8e0e>
   58267:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58272:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5827d:	mov    QWORD PTR [rsp+0x190],rdi
   58285:	mov    rdi,r14
   58288:	mov    rsi,r13
   5828b:	call   58290 <sqlite3VdbeExec+0x8df0>
   58290:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5829b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   582a6:	mov    rdi,QWORD PTR [rsp+0x190]
   582ae:	mov    QWORD PTR [r12+0x38],0x0
   582b7:	mov    r12,QWORD PTR [r12+0x8]
   582bc:	mov    r15d,DWORD PTR [rsp+0x418]
   582c4:	mov    r13,QWORD PTR [rsp+0x1f0]
   582cc:	test   r12,r12
   582cf:	jne    57ee4 <sqlite3VdbeExec+0x8a44>
   582d5:	mov    r13,QWORD PTR [r13+0x0]
   582d9:	test   r13,r13
   582dc:	je     582ff <sqlite3VdbeExec+0x8e5f>
   582de:	mov    rax,QWORD PTR [r13+0x10]
   582e2:	cmp    BYTE PTR [rax+0x3f],0x0
   582e6:	jne    582d5 <sqlite3VdbeExec+0x8e35>
   582e8:	mov    r12,QWORD PTR [rax+0x48]
   582ec:	jmp    582cc <sqlite3VdbeExec+0x8e2c>
   582ee:	cmp    DWORD PTR [rbp+0x8],0x2
   582f2:	jne    582ff <sqlite3VdbeExec+0x8e5f>
   582f4:	mov    rax,QWORD PTR [r12+r13*1+0x18]
   582f9:	mov    ecx,DWORD PTR [rbp+0xc]
   582fc:	mov    BYTE PTR [rax+0x70],cl
   582ff:	cmp    DWORD PTR [rbp+0x4],0x1
   58303:	jne    5833c <sqlite3VdbeExec+0x8e9c>
   58305:	mov    rax,QWORD PTR [r14+0x8]
   58309:	jmp    58325 <sqlite3VdbeExec+0x8e85>
   5830b:	movzx  ecx,WORD PTR [rax+0xc8]
   58312:	and    rcx,0xfffffffffffffffc
   58316:	or     rcx,0x1
   5831a:	mov    WORD PTR [rax+0xc8],cx
   58321:	mov    rax,QWORD PTR [rax+0x10]
   58325:	test   rax,rax
   58328:	jne    5830b <sqlite3VdbeExec+0x8e6b>
   5832a:	movzx  eax,WORD PTR [rdi+0xc8]
   58331:	and    rax,0xfffffffffffffffc
   58335:	mov    WORD PTR [rdi+0xc8],ax
   5833c:	test   r15d,r15d
   5833f:	je     58361 <sqlite3VdbeExec+0x8ec1>
   58341:	mov    QWORD PTR [rsp+0x1c8],rbp
   58349:	mov    rbp,r15
   5834c:	mov    r13,QWORD PTR [rsp+0x1b0]
   58354:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5835c:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   58361:	mov    DWORD PTR [rsp+0x40c],r15d
   58369:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5836e:	mov    r15d,DWORD PTR [rsp+0x3fc]
   58376:	mov    r13,QWORD PTR [rsp+0x1d0]
   5837e:	mov    QWORD PTR [rsp+0x1b0],r12
   58386:	mov    r12d,DWORD PTR [rsp+0x414]
   5838e:	mov    rax,QWORD PTR [rdi+0x78]
   58392:	movsxd rcx,DWORD PTR [rbp+0x4]
   58396:	mov    DWORD PTR [rsp+0x414],r12d
   5839e:	mov    r12,QWORD PTR [rax+rcx*8]
   583a2:	test   r12,r12
   583a5:	je     58528 <sqlite3VdbeExec+0x9088>
   583ab:	mov    eax,DWORD PTR [r12+0x3c]
   583b0:	cmp    eax,DWORD PTR [rbp+0x8]
   583b3:	jne    58528 <sqlite3VdbeExec+0x9088>
   583b9:	mov    QWORD PTR [rsp+0x1f0],r12
   583c1:	mov    r12,QWORD PTR [r12+0x28]
   583c6:	mov    QWORD PTR [rsp+0x1e8],r12
   583ce:	mov    r12,QWORD PTR [r12+0x18]
   583d3:	test   r12,r12
   583d6:	je     584e5 <sqlite3VdbeExec+0x9045>
   583dc:	cmp    DWORD PTR [rip+0x0],0x0        # 583e3 <sqlite3VdbeExec+0x8f43>
   583e3:	je     58499 <sqlite3VdbeExec+0x8ff9>
   583e9:	mov    rax,QWORD PTR [rip+0x0]        # 583f0 <sqlite3VdbeExec+0x8f50>
   583f0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   583fb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58406:	mov    QWORD PTR [rsp+0x190],rdi
   5840e:	mov    rdi,r12
   58411:	mov    r10,rax
   58414:	call   r10
   58417:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58422:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5842d:	mov    rcx,QWORD PTR [rip+0x0]        # 58434 <sqlite3VdbeExec+0x8f94>
   58434:	movsxd rax,eax
   58437:	sub    rcx,rax
   5843a:	mov    QWORD PTR [rip+0x0],rcx        # 58441 <sqlite3VdbeExec+0x8fa1>
   58441:	mov    rax,QWORD PTR [rip+0x0]        # 58448 <sqlite3VdbeExec+0x8fa8>
   58448:	sub    rax,0x1
   5844c:	mov    QWORD PTR [rip+0x0],rax        # 58453 <sqlite3VdbeExec+0x8fb3>
   58453:	mov    rax,QWORD PTR [rip+0x0]        # 5845a <sqlite3VdbeExec+0x8fba>
   5845a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58465:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58470:	mov    rdi,r12
   58473:	mov    r10,rax
   58476:	call   r10
   58479:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58484:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5848f:	mov    rdi,QWORD PTR [rsp+0x190]
   58497:	jmp    584e5 <sqlite3VdbeExec+0x9045>
   58499:	mov    rax,QWORD PTR [rip+0x0]        # 584a0 <sqlite3VdbeExec+0x9000>
   584a0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   584ab:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   584b6:	mov    QWORD PTR [rsp+0x190],rdi
   584be:	mov    rdi,r12
   584c1:	mov    r10,rax
   584c4:	call   r10
   584c7:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   584d2:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   584dd:	mov    rdi,QWORD PTR [rsp+0x190]
   584e5:	mov    r12,QWORD PTR [rsp+0x1e8]
   584ed:	mov    QWORD PTR [r12+0x18],0x0
   584f6:	mov    BYTE PTR [r12],0x1
   584fb:	mov    DWORD PTR [rsp+0x3fc],r15d
   58503:	mov    QWORD PTR [rsp+0x1d0],r13
   5850b:	mov    QWORD PTR [rsp+0x1e0],rbx
   58513:	mov    r12d,DWORD PTR [rsp+0x40c]
   5851b:	mov    r13,QWORD PTR [rsp+0x1f0]
   58523:	jmp    588e6 <sqlite3VdbeExec+0x9446>
   58528:	movzx  eax,WORD PTR [rdi+0xc8]
   5852f:	shl    rax,0x3e
   58533:	shr    rax,0x3e
   58537:	cmp    eax,0x1
   5853a:	jne    58569 <sqlite3VdbeExec+0x90c9>
   5853c:	mov    ebx,0x204
   58541:	mov    QWORD PTR [rsp+0x1d0],r13
   58549:	mov    QWORD PTR [rsp+0x1c8],rbp
   58551:	mov    rbp,rbx
   58554:	mov    r13,QWORD PTR [rsp+0x1b0]
   5855c:	mov    rbx,QWORD PTR [rsp+0x1d8]
   58564:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   58569:	mov    r12d,DWORD PTR [rbp+0x8]
   5856d:	mov    QWORD PTR [rsp+0x1d0],r13
   58575:	movsxd r13,DWORD PTR [rbp+0xc]
   58579:	mov    rax,QWORD PTR [r14+0x20]
   5857d:	mov    rcx,r13
   58580:	shl    rcx,0x5
   58584:	mov    QWORD PTR [rsp+0x1f0],r13
   5858c:	mov    r13,QWORD PTR [rax+rcx*1+0x8]
   58591:	cmp    BYTE PTR [rbp+0x0],0x74
   58595:	jne    586d5 <sqlite3VdbeExec+0x9235>
   5859b:	movzx  edx,WORD PTR [rbp+0x2]
   5859f:	and    edx,0x8
   585a2:	mov    QWORD PTR [rsp+0x1e8],r13
   585aa:	mov    r13d,edx
   585ad:	or     r13d,0x4
   585b1:	mov    rdx,QWORD PTR [rax+rcx*1+0x18]
   585b6:	movzx  edx,BYTE PTR [rdx+0x70]
   585ba:	movzx  esi,BYTE PTR [rdi+0xc5]
   585c1:	cmp    edx,esi
   585c3:	jge    585d4 <sqlite3VdbeExec+0x9134>
   585c5:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   585ca:	movzx  eax,BYTE PTR [rax+0x70]
   585ce:	mov    BYTE PTR [rdi+0xc5],al
   585d4:	movzx  eax,WORD PTR [rbp+0x2]
   585d8:	and    eax,0x10
   585db:	test   eax,eax
   585dd:	je     586d3 <sqlite3VdbeExec+0x9233>
   585e3:	mov    rax,r12
   585e6:	imul   rax,rax,0x38
   585ea:	lea    r12,[rbx+rax*1]
   585ee:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   585f3:	mov    ecx,eax
   585f5:	and    ecx,0x24
   585f8:	test   ecx,ecx
   585fa:	je     58605 <sqlite3VdbeExec+0x9165>
   585fc:	mov    rax,QWORD PTR [r12]
   58600:	jmp    586b4 <sqlite3VdbeExec+0x9214>
   58605:	mov    ecx,eax
   58607:	and    ecx,0x8
   5860a:	test   ecx,ecx
   5860c:	je     5865d <sqlite3VdbeExec+0x91bd>
   5860e:	movsd  xmm3,QWORD PTR [r12]
   58614:	movabs r11,0xc3dfffffffffffff
   5861e:	movq   xmm2,r11
   58623:	ucomisd xmm2,xmm3
   58627:	jbe    58635 <sqlite3VdbeExec+0x9195>
   58629:	movabs rax,0x8000000000000000
   58633:	jmp    5865b <sqlite3VdbeExec+0x91bb>
   58635:	movabs r11,0x43dfffffffffffff
   5863f:	movq   xmm2,r11
   58644:	ucomisd xmm3,xmm2
   58648:	jbe    58656 <sqlite3VdbeExec+0x91b6>
   5864a:	movabs rax,0x7fffffffffffffff
   58654:	jmp    5865b <sqlite3VdbeExec+0x91bb>
   58656:	cvttsd2si rax,xmm3
   5865b:	jmp    586b4 <sqlite3VdbeExec+0x9214>
   5865d:	and    eax,0x12
   58660:	test   eax,eax
   58662:	je     586b2 <sqlite3VdbeExec+0x9212>
   58664:	cmp    QWORD PTR [r12+0x8],0x0
   5866a:	je     586b2 <sqlite3VdbeExec+0x9212>
   5866c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58677:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58682:	mov    QWORD PTR [rsp+0x190],rdi
   5868a:	mov    rdi,r12
   5868d:	call   58692 <sqlite3VdbeExec+0x91f2>
   58692:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5869d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   586a8:	mov    rdi,QWORD PTR [rsp+0x190]
   586b0:	jmp    586b4 <sqlite3VdbeExec+0x9214>
   586b2:	xor    eax,eax
   586b4:	mov    QWORD PTR [r12],rax
   586b8:	movzx  eax,WORD PTR [r12+0x14]
   586be:	and    eax,0xfffff240
   586c3:	or     eax,0x4
   586c6:	mov    WORD PTR [r12+0x14],ax
   586cc:	mov    rax,QWORD PTR [r12]
   586d0:	mov    r12d,eax
   586d3:	jmp    586e0 <sqlite3VdbeExec+0x9240>
   586d5:	mov    QWORD PTR [rsp+0x1e8],r13
   586dd:	xor    r13d,r13d
   586e0:	cmp    BYTE PTR [rbp+0x1],0xf7
   586e4:	jne    58704 <sqlite3VdbeExec+0x9264>
   586e6:	mov    DWORD PTR [rsp+0x418],r13d
   586ee:	mov    r13,QWORD PTR [rbp+0x10]
   586f2:	movzx  eax,WORD PTR [r13+0x8]
   586f7:	mov    QWORD PTR [rsp+0x1f8],r13
   586ff:	mov    r13d,eax
   58702:	jmp    58731 <sqlite3VdbeExec+0x9291>
   58704:	mov    DWORD PTR [rsp+0x418],r13d
   5870c:	cmp    BYTE PTR [rbp+0x1],0xfd
   58710:	je     58722 <sqlite3VdbeExec+0x9282>
   58712:	xor    r13d,r13d
   58715:	xor    r11d,r11d
   58718:	mov    QWORD PTR [rsp+0x1f8],r11
   58720:	jmp    58731 <sqlite3VdbeExec+0x9291>
   58722:	mov    r13d,DWORD PTR [rbp+0x10]
   58726:	xor    r11d,r11d
   58729:	mov    QWORD PTR [rsp+0x1f8],r11
   58731:	mov    eax,DWORD PTR [rbp+0x4]
   58734:	xor    ecx,ecx
   58736:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58741:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5874c:	mov    QWORD PTR [rsp+0x190],rdi
   58754:	mov    rsi,rax
   58757:	mov    rdx,r13
   5875a:	call   5875f <sqlite3VdbeExec+0x92bf>
   5875f:	mov    r13,rax
   58762:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5876d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58778:	mov    rdi,QWORD PTR [rsp+0x190]
   58780:	test   r13,r13
   58783:	jne    5879d <sqlite3VdbeExec+0x92fd>
   58785:	mov    r13,QWORD PTR [rsp+0x1d0]
   5878d:	mov    rbx,rbp
   58790:	mov    rbp,QWORD PTR [rsp+0x1d8]
   58798:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5879d:	mov    DWORD PTR [rsp+0x3fc],r15d
   587a5:	mov    r15,QWORD PTR [rsp+0x1f0]
   587ad:	mov    BYTE PTR [r13+0x1],r15b
   587b1:	mov    BYTE PTR [r13+0x2],0x1
   587b6:	movzx  eax,BYTE PTR [r13+0x5]
   587bb:	and    rax,0xfffffffffffffffb
   587bf:	or     rax,0x4
   587c3:	mov    BYTE PTR [r13+0x5],al
   587c7:	mov    DWORD PTR [r13+0x3c],r12d
   587cb:	mov    rax,QWORD PTR [r13+0x28]
   587cf:	mov    r15,QWORD PTR [rsp+0x1e8]
   587d7:	cmp    BYTE PTR [r15+0x11],0x0
   587dc:	je     58862 <sqlite3VdbeExec+0x93c2>
   587e2:	mov    rcx,QWORD PTR [r15+0x8]
   587e6:	mov    rdx,QWORD PTR [r15]
   587e9:	mov    QWORD PTR [rcx+0x8],rdx
   587ed:	mov    QWORD PTR [rsp+0x208],r13
   587f5:	mov    QWORD PTR [rsp+0x1e0],rbx
   587fd:	mov    r13d,DWORD PTR [rsp+0x418]
   58805:	mov    rbx,QWORD PTR [rsp+0x1f8]
   5880d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58818:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58823:	mov    rdi,r15
   58826:	mov    rsi,r12
   58829:	mov    rdx,r13
   5882c:	mov    rcx,rbx
   5882f:	mov    r8,rax
   58832:	call   58837 <sqlite3VdbeExec+0x9397>
   58837:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58842:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5884d:	mov    r12d,eax
   58850:	mov    rdi,QWORD PTR [rsp+0x190]
   58858:	mov    r13,QWORD PTR [rsp+0x208]
   58860:	jmp    588d5 <sqlite3VdbeExec+0x9435>
   58862:	mov    QWORD PTR [rsp+0x208],r13
   5886a:	mov    r13d,DWORD PTR [rsp+0x418]
   58872:	mov    QWORD PTR [rsp+0x1e0],rbx
   5887a:	mov    rbx,QWORD PTR [rsp+0x1f8]
   58882:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5888d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58898:	mov    rdi,r15
   5889b:	mov    rsi,r12
   5889e:	mov    rdx,r13
   588a1:	mov    rcx,rbx
   588a4:	mov    r8,rax
   588a7:	call   588ac <sqlite3VdbeExec+0x940c>
   588ac:	mov    r12d,eax
   588af:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   588ba:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   588c5:	mov    rdi,QWORD PTR [rsp+0x190]
   588cd:	mov    r13,QWORD PTR [rsp+0x208]
   588d5:	mov    QWORD PTR [r13+0x30],rbx
   588d9:	xor    eax,eax
   588db:	cmp    BYTE PTR [rbp+0x1],0xf7
   588df:	setne  al
   588e2:	mov    BYTE PTR [r13+0x4],al
   588e6:	mov    rax,QWORD PTR [r13+0x28]
   588ea:	movzx  ecx,WORD PTR [rbp+0x2]
   588ee:	and    ecx,0x3
   588f1:	mov    BYTE PTR [rax+0x3],cl
   588f4:	test   r12d,r12d
   588f7:	je     58919 <sqlite3VdbeExec+0x9479>
   588f9:	mov    QWORD PTR [rsp+0x1c8],rbp
   58901:	mov    rbp,r12
   58904:	mov    r13,QWORD PTR [rsp+0x1b0]
   5890c:	mov    rbx,QWORD PTR [rsp+0x1d8]
   58914:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   58919:	mov    DWORD PTR [rsp+0x40c],r12d
   58921:	mov    rbx,QWORD PTR [rsp+0x1e0]
   58929:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5892e:	mov    QWORD PTR [rsp+0x1e0],rbx
   58936:	mov    QWORD PTR [rsp+0x1b0],r12
   5893e:	mov    rax,QWORD PTR [rdi+0x78]
   58942:	movsxd rcx,DWORD PTR [rbp+0x8]
   58946:	mov    r12,QWORD PTR [rax+rcx*8]
   5894a:	mov    eax,DWORD PTR [rbp+0x4]
   5894d:	movsx  ecx,WORD PTR [r12+0x40]
   58953:	xor    edx,edx
   58955:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58960:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5896b:	mov    QWORD PTR [rsp+0x190],rdi
   58973:	mov    rsi,rax
   58976:	mov    r11,rdx
   58979:	mov    rdx,rcx
   5897c:	mov    rcx,r11
   5897f:	call   58984 <sqlite3VdbeExec+0x94e4>
   58984:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5898f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5899a:	mov    rdi,QWORD PTR [rsp+0x190]
   589a2:	test   rax,rax
   589a5:	jne    589bf <sqlite3VdbeExec+0x951f>
   589a7:	mov    r13,QWORD PTR [rsp+0x1d0]
   589af:	mov    rbx,rbp
   589b2:	mov    rbp,QWORD PTR [rsp+0x1d8]
   589ba:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   589bf:	mov    BYTE PTR [rax+0x2],0x1
   589c3:	movzx  ecx,BYTE PTR [rax+0x5]
   589c7:	and    rcx,0xfffffffffffffffe
   589cb:	or     rcx,0x1
   589cf:	mov    BYTE PTR [rax+0x5],cl
   589d2:	mov    rcx,QWORD PTR [r12+0x30]
   589d7:	mov    QWORD PTR [rax+0x30],rcx
   589db:	movzx  ecx,BYTE PTR [r12+0x4]
   589e1:	mov    BYTE PTR [rax+0x4],cl
   589e4:	mov    ecx,DWORD PTR [r12+0x3c]
   589e9:	mov    DWORD PTR [rax+0x3c],ecx
   589ec:	movzx  ecx,BYTE PTR [r12+0x5]
   589f2:	shl    rcx,0x3d
   589f6:	shr    rcx,0x3f
   589fa:	and    rcx,0x1
   589fe:	movzx  edx,BYTE PTR [rax+0x5]
   58a02:	and    rdx,0xfffffffffffffffb
   58a06:	shl    rcx,0x2
   58a0a:	or     rdx,rcx
   58a0d:	mov    BYTE PTR [rax+0x5],dl
   58a10:	mov    rcx,QWORD PTR [r12+0x8]
   58a15:	mov    QWORD PTR [rax+0x8],rcx
   58a19:	movzx  ecx,BYTE PTR [rax+0x5]
   58a1d:	and    rcx,0xfffffffffffffff7
   58a21:	or     rcx,0x8
   58a25:	mov    BYTE PTR [rax+0x5],cl
   58a28:	movzx  ecx,BYTE PTR [r12+0x5]
   58a2e:	and    rcx,0xfffffffffffffff7
   58a32:	or     rcx,0x8
   58a36:	mov    BYTE PTR [r12+0x5],cl
   58a3b:	mov    rcx,QWORD PTR [rax+0x8]
   58a3f:	mov    edx,DWORD PTR [rax+0x3c]
   58a42:	mov    esi,0x4
   58a47:	mov    r8,QWORD PTR [rax+0x30]
   58a4b:	mov    rax,QWORD PTR [rax+0x28]
   58a4f:	cmp    BYTE PTR [rcx+0x11],0x0
   58a53:	je     58ab0 <sqlite3VdbeExec+0x9610>
   58a55:	mov    r9,QWORD PTR [rcx+0x8]
   58a59:	mov    r10,QWORD PTR [rcx]
   58a5c:	mov    QWORD PTR [r9+0x8],r10
   58a60:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58a6b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58a76:	mov    rdi,rcx
   58a79:	mov    rcx,r8
   58a7c:	mov    r8,rax
   58a7f:	mov    r11,rsi
   58a82:	mov    rsi,rdx
   58a85:	mov    rdx,r11
   58a88:	call   58a8d <sqlite3VdbeExec+0x95ed>
   58a8d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58a98:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58aa3:	mov    r12d,eax
   58aa6:	mov    rdi,QWORD PTR [rsp+0x190]
   58aae:	jmp    58afe <sqlite3VdbeExec+0x965e>
   58ab0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58abb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58ac6:	mov    rdi,rcx
   58ac9:	mov    rcx,r8
   58acc:	mov    r8,rax
   58acf:	mov    r11,rsi
   58ad2:	mov    rsi,rdx
   58ad5:	mov    rdx,r11
   58ad8:	call   58add <sqlite3VdbeExec+0x963d>
   58add:	mov    r12d,eax
   58ae0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58aeb:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58af6:	mov    rdi,QWORD PTR [rsp+0x190]
   58afe:	mov    DWORD PTR [rsp+0x40c],r12d
   58b06:	mov    rbx,QWORD PTR [rsp+0x1e0]
   58b0e:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   58b13:	mov    QWORD PTR [rsp+0x1e0],rbx
   58b1b:	mov    QWORD PTR [rsp+0x1b0],r12
   58b23:	cmp    DWORD PTR [rbp+0xc],0x0
   58b27:	jg     58b33 <sqlite3VdbeExec+0x9693>
   58b29:	mov    r12,QWORD PTR [rsp+0x1e0]
   58b31:	jmp    58b60 <sqlite3VdbeExec+0x96c0>
   58b33:	movsxd rax,DWORD PTR [rbp+0xc]
   58b37:	imul   rax,rax,0x38
   58b3b:	mov    r12,QWORD PTR [rsp+0x1e0]
   58b43:	mov    DWORD PTR [r12+rax*1+0x10],0x0
   58b4c:	movsxd rax,DWORD PTR [rbp+0xc]
   58b50:	imul   rax,rax,0x38
   58b54:	lea    rcx,[rip+0x0]        # 58b5b <sqlite3VdbeExec+0x96bb>
   58b5b:	mov    QWORD PTR [r12+rax*1+0x8],rcx
   58b60:	mov    rax,QWORD PTR [rdi+0x78]
   58b64:	movsxd rcx,DWORD PTR [rbp+0x4]
   58b68:	mov    r13,QWORD PTR [rax+rcx*8]
   58b6c:	test   r13,r13
   58b6f:	je     58d5d <sqlite3VdbeExec+0x98bd>
   58b75:	movzx  eax,BYTE PTR [r13+0x5]
   58b7a:	shl    rax,0x3c
   58b7e:	shr    rax,0x3f
   58b82:	test   eax,eax
   58b84:	jne    58d5d <sqlite3VdbeExec+0x98bd>
   58b8a:	mov    eax,DWORD PTR [rbp+0x8]
   58b8d:	movsx  ecx,WORD PTR [r13+0x40]
   58b92:	cmp    eax,ecx
   58b94:	jg     58d5d <sqlite3VdbeExec+0x98bd>
   58b9a:	mov    QWORD PTR [r13+0x10],0x0
   58ba2:	mov    DWORD PTR [r13+0x18],0x0
   58baa:	mov    r15,QWORD PTR [r13+0x8]
   58bae:	mov    ebx,DWORD PTR [r13+0x3c]
   58bb2:	mov    DWORD PTR [rsp+0x418],ebx
   58bb9:	mov    rbx,QWORD PTR [r15+0x8]
   58bbd:	mov    rax,QWORD PTR [r15+0x8]
   58bc1:	mov    rcx,QWORD PTR [r15]
   58bc4:	mov    QWORD PTR [rax+0x8],rcx
   58bc8:	xor    eax,eax
   58bca:	mov    rcx,QWORD PTR [rbx+0x10]
   58bce:	jmp    58c2e <sqlite3VdbeExec+0x978e>
   58bd0:	test   rcx,rcx
   58bd3:	jne    58be6 <sqlite3VdbeExec+0x9746>
   58bd5:	mov    QWORD PTR [rsp+0x1f8],rbx
   58bdd:	mov    ebx,DWORD PTR [rsp+0x418]
   58be4:	jmp    58c1b <sqlite3VdbeExec+0x977b>
   58be6:	xor    edx,edx
   58be8:	mov    QWORD PTR [rsp+0x1f8],rbx
   58bf0:	mov    ebx,DWORD PTR [rsp+0x418]
   58bf7:	cmp    edx,ebx
   58bf9:	jne    58c05 <sqlite3VdbeExec+0x9765>
   58bfb:	mov    rbx,QWORD PTR [rsp+0x1f8]
   58c03:	jmp    58c33 <sqlite3VdbeExec+0x9793>
   58c05:	cmp    ebx,DWORD PTR [rcx+0x50]
   58c08:	jne    58c1b <sqlite3VdbeExec+0x977b>
   58c0a:	mov    DWORD PTR [rsp+0x418],ebx
   58c11:	mov    rbx,QWORD PTR [rsp+0x1f8]
   58c19:	jmp    58c33 <sqlite3VdbeExec+0x9793>
   58c1b:	mov    rcx,QWORD PTR [rcx+0x28]
   58c1f:	mov    DWORD PTR [rsp+0x418],ebx
   58c26:	mov    rbx,QWORD PTR [rsp+0x1f8]
   58c2e:	test   rcx,rcx
   58c31:	jne    58bd0 <sqlite3VdbeExec+0x9730>
   58c33:	test   rcx,rcx
   58c36:	jne    58c49 <sqlite3VdbeExec+0x97a9>
   58c38:	mov    QWORD PTR [rsp+0x1f8],rbx
   58c40:	mov    ebx,DWORD PTR [rsp+0x418]
   58c47:	jmp    58cac <sqlite3VdbeExec+0x980c>
   58c49:	mov    QWORD PTR [rsp+0x1f8],rbx
   58c51:	mov    ebx,DWORD PTR [rsp+0x418]
   58c58:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58c63:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58c6e:	mov    QWORD PTR [rsp+0x190],rdi
   58c76:	mov    rdi,rcx
   58c79:	mov    rsi,rbx
   58c7c:	mov    rdx,rax
   58c7f:	call   58c84 <sqlite3VdbeExec+0x97e4>
   58c84:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58c8f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58c9a:	xor    ecx,ecx
   58c9c:	mov    rdi,QWORD PTR [rsp+0x190]
   58ca4:	cmp    ecx,eax
   58ca6:	jne    58d4d <sqlite3VdbeExec+0x98ad>
   58cac:	cmp    BYTE PTR [r15+0x13],0x0
   58cb1:	je     58ce3 <sqlite3VdbeExec+0x9843>
   58cb3:	mov    BYTE PTR [r15+0x13],0x0
   58cb8:	mov    rax,QWORD PTR [r15+0x8]
   58cbc:	mov    rax,QWORD PTR [rax+0x10]
   58cc0:	jmp    58cde <sqlite3VdbeExec+0x983e>
   58cc2:	movzx  ecx,BYTE PTR [rax+0x1]
   58cc6:	and    ecx,0x10
   58cc9:	test   ecx,ecx
   58ccb:	je     58cda <sqlite3VdbeExec+0x983a>
   58ccd:	mov    BYTE PTR [r15+0x13],0x1
   58cd2:	cmp    ebx,DWORD PTR [rax+0x50]
   58cd5:	jne    58cda <sqlite3VdbeExec+0x983a>
   58cd7:	mov    BYTE PTR [rax],0x1
   58cda:	mov    rax,QWORD PTR [rax+0x28]
   58cde:	test   rax,rax
   58ce1:	jne    58cc2 <sqlite3VdbeExec+0x9822>
   58ce3:	xor    eax,eax
   58ce5:	mov    QWORD PTR [rsp+0x208],r13
   58ced:	xor    r15d,r15d
   58cf0:	mov    r13,QWORD PTR [rsp+0x1f8]
   58cf8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58d03:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58d0e:	mov    QWORD PTR [rsp+0x190],rdi
   58d16:	mov    rdi,r13
   58d19:	mov    rsi,rbx
   58d1c:	mov    rdx,rax
   58d1f:	mov    rcx,r15
   58d22:	call   58d27 <sqlite3VdbeExec+0x9887>
   58d27:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58d32:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58d3d:	mov    rdi,QWORD PTR [rsp+0x190]
   58d45:	mov    r13,QWORD PTR [rsp+0x208]
   58d4d:	mov    ebx,eax
   58d4f:	mov    r11,r13
   58d52:	mov    r13,rbx
   58d55:	mov    rbx,r11
   58d58:	jmp    591c6 <sqlite3VdbeExec+0x9d26>
   58d5d:	mov    eax,DWORD PTR [rbp+0x4]
   58d60:	mov    ecx,DWORD PTR [rbp+0x8]
   58d63:	xor    edx,edx
   58d65:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58d70:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58d7b:	mov    QWORD PTR [rsp+0x190],rdi
   58d83:	mov    rsi,rax
   58d86:	mov    r11,rdx
   58d89:	mov    rdx,rcx
   58d8c:	mov    rcx,r11
   58d8f:	call   58d94 <sqlite3VdbeExec+0x98f4>
   58d94:	mov    rbx,rax
   58d97:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58da2:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58dad:	mov    rdi,QWORD PTR [rsp+0x190]
   58db5:	test   rbx,rbx
   58db8:	jne    58dd2 <sqlite3VdbeExec+0x9932>
   58dba:	mov    r13,QWORD PTR [rsp+0x1d0]
   58dc2:	mov    rbx,rbp
   58dc5:	mov    rbp,QWORD PTR [rsp+0x1d8]
   58dcd:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   58dd2:	movzx  eax,BYTE PTR [rbx+0x5]
   58dd6:	and    rax,0xfffffffffffffffe
   58dda:	or     rax,0x1
   58dde:	mov    BYTE PTR [rbx+0x5],al
   58de1:	mov    rax,QWORD PTR [r14]
   58de4:	xor    ecx,ecx
   58de6:	lea    rdx,[rbx+0x8]
   58dea:	movzx  esi,WORD PTR [rbp+0x2]
   58dee:	or     esi,0x5
   58df1:	mov    r8d,DWORD PTR [rip+0x0]        # 58df8 <sqlite3VdbeExec+0x9958>
   58df8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58e03:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58e0e:	mov    rdi,rax
   58e11:	mov    r9,r8
   58e14:	mov    r8,rsi
   58e17:	mov    rsi,rcx
   58e1a:	mov    rcx,rdx
   58e1d:	mov    rdx,r14
   58e20:	call   58e25 <sqlite3VdbeExec+0x9985>
   58e25:	mov    r13d,eax
   58e28:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58e33:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58e3e:	mov    rdi,QWORD PTR [rsp+0x190]
   58e46:	test   r13d,r13d
   58e49:	jne    591c6 <sqlite3VdbeExec+0x9d26>
   58e4f:	mov    rax,QWORD PTR [rbx+0x8]
   58e53:	mov    ecx,0x1
   58e58:	xor    edx,edx
   58e5a:	cmp    BYTE PTR [rax+0x11],0x0
   58e5e:	jne    58e70 <sqlite3VdbeExec+0x99d0>
   58e60:	cmp    BYTE PTR [rax+0x10],0x0
   58e64:	je     58e70 <sqlite3VdbeExec+0x99d0>
   58e66:	cmp    BYTE PTR [rax+0x10],0x1
   58e6a:	jne    58fa8 <sqlite3VdbeExec+0x9b08>
   58e70:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58e7b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58e86:	mov    QWORD PTR [rsp+0x190],rdi
   58e8e:	mov    rdi,rax
   58e91:	mov    rsi,rcx
   58e94:	call   58e99 <sqlite3VdbeExec+0x99f9>
   58e99:	mov    r13d,eax
   58e9c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58ea7:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58eb2:	mov    rdi,QWORD PTR [rsp+0x190]
   58eba:	test   r13d,r13d
   58ebd:	jne    59147 <sqlite3VdbeExec+0x9ca7>
   58ec3:	mov    r13,QWORD PTR [rbp+0x10]
   58ec7:	mov    QWORD PTR [rbx+0x30],r13
   58ecb:	test   r13,r13
   58ece:	je     59075 <sqlite3VdbeExec+0x9bd5>
   58ed4:	mov    rax,QWORD PTR [rbx+0x8]
   58ed8:	lea    rcx,[rbx+0x3c]
   58edc:	movzx  edx,WORD PTR [rbp+0x2]
   58ee0:	or     edx,0x2
   58ee3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58eee:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58ef9:	mov    QWORD PTR [rsp+0x190],rdi
   58f01:	mov    rdi,rax
   58f04:	mov    rsi,rcx
   58f07:	call   58f0c <sqlite3VdbeExec+0x9a6c>
   58f0c:	mov    r15d,eax
   58f0f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58f1a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58f25:	mov    rdi,QWORD PTR [rsp+0x190]
   58f2d:	test   r15d,r15d
   58f30:	jne    59069 <sqlite3VdbeExec+0x9bc9>
   58f36:	mov    rax,QWORD PTR [rbx+0x8]
   58f3a:	mov    ecx,DWORD PTR [rbx+0x3c]
   58f3d:	mov    edx,0x4
   58f42:	mov    rsi,QWORD PTR [rbx+0x28]
   58f46:	cmp    BYTE PTR [rax+0x11],0x0
   58f4a:	je     5901e <sqlite3VdbeExec+0x9b7e>
   58f50:	mov    r8,QWORD PTR [rax+0x8]
   58f54:	mov    r9,QWORD PTR [rax]
   58f57:	mov    QWORD PTR [r8+0x8],r9
   58f5b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58f66:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58f71:	mov    rdi,rax
   58f74:	mov    r8,rsi
   58f77:	mov    rsi,rcx
   58f7a:	mov    rcx,r13
   58f7d:	call   58f82 <sqlite3VdbeExec+0x9ae2>
   58f82:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58f8d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   58f98:	mov    r13d,eax
   58f9b:	mov    rdi,QWORD PTR [rsp+0x190]
   58fa3:	jmp    59066 <sqlite3VdbeExec+0x9bc6>
   58fa8:	mov    rcx,QWORD PTR [rax+0x8]
   58fac:	mov    rcx,QWORD PTR [rcx]
   58faf:	mov    rax,QWORD PTR [rax]
   58fb2:	mov    eax,DWORD PTR [rax+0x2e8]
   58fb8:	cmp    eax,DWORD PTR [rcx+0x80]
   58fbe:	jle    58ec3 <sqlite3VdbeExec+0x9a23>
   58fc4:	cmp    BYTE PTR [rcx+0xa],0x0
   58fc8:	je     58ec3 <sqlite3VdbeExec+0x9a23>
   58fce:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   58fd9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   58fe4:	mov    rdi,rcx
   58fe7:	mov    rsi,rax
   58fea:	call   58fef <sqlite3VdbeExec+0x9b4f>
   58fef:	mov    r13d,eax
   58ff2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   58ffd:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   59008:	mov    rdi,QWORD PTR [rsp+0x190]
   59010:	test   r13d,r13d
   59013:	je     58ec3 <sqlite3VdbeExec+0x9a23>
   59019:	jmp    59147 <sqlite3VdbeExec+0x9ca7>
   5901e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   59029:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   59034:	mov    rdi,rax
   59037:	mov    r8,rsi
   5903a:	mov    rsi,rcx
   5903d:	mov    rcx,r13
   59040:	call   59045 <sqlite3VdbeExec+0x9ba5>
   59045:	mov    r13d,eax
   59048:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   59053:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5905e:	mov    rdi,QWORD PTR [rsp+0x190]
   59066:	mov    r15,r13
   59069:	mov    BYTE PTR [rbx+0x4],0x0
   5906d:	mov    r13,r15
   59070:	jmp    59147 <sqlite3VdbeExec+0x9ca7>
   59075:	mov    DWORD PTR [rbx+0x3c],0x1
   5907c:	mov    rax,QWORD PTR [rbx+0x8]
   59080:	mov    ecx,0x1
   59085:	mov    edx,0x4
   5908a:	xor    esi,esi
   5908c:	mov    r8,QWORD PTR [rbx+0x28]
   59090:	cmp    BYTE PTR [rax+0x11],0x0
   59094:	je     590f3 <sqlite3VdbeExec+0x9c53>
   59096:	mov    r9,QWORD PTR [rax+0x8]
   5909a:	mov    r10,QWORD PTR [rax]
   5909d:	mov    QWORD PTR [r9+0x8],r10
   590a1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   590ac:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   590b7:	mov    QWORD PTR [rsp+0x190],rdi
   590bf:	mov    rdi,rax
   590c2:	mov    r11,rsi
   590c5:	mov    rsi,rcx
   590c8:	mov    rcx,r11
   590cb:	call   590d0 <sqlite3VdbeExec+0x9c30>
   590d0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   590db:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   590e6:	mov    r13d,eax
   590e9:	mov    rdi,QWORD PTR [rsp+0x190]
   590f1:	jmp    59143 <sqlite3VdbeExec+0x9ca3>
   590f3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   590fe:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   59109:	mov    QWORD PTR [rsp+0x190],rdi
   59111:	mov    rdi,rax
   59114:	mov    r11,rsi
   59117:	mov    rsi,rcx
   5911a:	mov    rcx,r11
   5911d:	call   59122 <sqlite3VdbeExec+0x9c82>
   59122:	mov    r13d,eax
   59125:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   59130:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5913b:	mov    rdi,QWORD PTR [rsp+0x190]
   59143:	mov    BYTE PTR [rbx+0x4],0x1
   59147:	xor    eax,eax
   59149:	cmp    WORD PTR [rbp+0x2],0x8
   5914e:	setne  al
   59151:	and    rax,0x1
   59155:	movzx  ecx,BYTE PTR [rbx+0x5]
   59159:	and    rcx,0xfffffffffffffffb
   5915d:	shl    rax,0x2
   59161:	or     rcx,rax
   59164:	mov    BYTE PTR [rbx+0x5],cl
   59167:	test   r13d,r13d
   5916a:	je     591c6 <sqlite3VdbeExec+0x9d26>
   5916c:	mov    rax,QWORD PTR [rbx+0x8]
   59170:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5917b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   59186:	mov    QWORD PTR [rsp+0x190],rdi
   5918e:	mov    rdi,rax
   59191:	call   59196 <sqlite3VdbeExec+0x9cf6>
   59196:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   591a1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   591ac:	mov    rdi,QWORD PTR [rsp+0x190]
   591b4:	mov    rax,QWORD PTR [rdi+0x78]
   591b8:	movsxd rcx,DWORD PTR [rbp+0x4]
   591bc:	mov    QWORD PTR [rax+rcx*8],0x0
   591c4:	jmp    591c6 <sqlite3VdbeExec+0x9d26>
   591c6:	test   r13d,r13d
   591c9:	je     591eb <sqlite3VdbeExec+0x9d4b>
   591cb:	mov    QWORD PTR [rsp+0x1c8],rbp
   591d3:	mov    rbp,r13
   591d6:	mov    r13,QWORD PTR [rsp+0x1b0]
   591de:	mov    rbx,QWORD PTR [rsp+0x1d8]
   591e6:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   591eb:	mov    BYTE PTR [rbx+0x2],0x1
   591ef:	mov    DWORD PTR [rsp+0x40c],r13d
   591f7:	mov    rbx,r12
   591fa:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   591ff:	mov    QWORD PTR [rsp+0x1b0],r12
   59207:	mov    r12,rbx
   5920a:	mov    eax,DWORD PTR [rbp+0x4]
   5920d:	mov    ecx,DWORD PTR [rbp+0x8]
   59210:	mov    edx,0x1
   59215:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   59220:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5922b:	mov    QWORD PTR [rsp+0x190],rdi
   59233:	mov    rsi,rax
   59236:	mov    r11,rdx
   59239:	mov    rdx,rcx
   5923c:	mov    rcx,r11
   5923f:	call   59244 <sqlite3VdbeExec+0x9da4>
   59244:	mov    rbx,rax
   59247:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   59252:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5925d:	mov    rdi,QWORD PTR [rsp+0x190]
   59265:	test   rbx,rbx
   59268:	jne    59282 <sqlite3VdbeExec+0x9de2>
   5926a:	mov    r13,QWORD PTR [rsp+0x1d0]
   59272:	mov    rbx,rbp
   59275:	mov    rbp,QWORD PTR [rsp+0x1d8]
   5927d:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   59282:	mov    rax,QWORD PTR [rbp+0x10]
   59286:	mov    QWORD PTR [rbx+0x30],rax
   5928a:	mov    r13d,DWORD PTR [rbp+0xc]
   5928e:	mov    rax,QWORD PTR [rbx+0x30]
   59292:	movzx  eax,WORD PTR [rax+0x8]
   59296:	shl    rax,0x3
   5929a:	add    rax,0x20
   5929e:	mov    r15d,eax
   592a1:	mov    rax,r15
   592a4:	mov    DWORD PTR [rsp+0x418],r13d
   592ac:	lea    r13,[rax+0xc8]
   592b3:	test   r14,r14
   592b6:	je     59304 <sqlite3VdbeExec+0x9e64>
   592b8:	mov    DWORD PTR [rsp+0x420],r15d
   592c0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   592cb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   592d6:	mov    rdi,r14
   592d9:	mov    rsi,r13
   592dc:	call   592e1 <sqlite3VdbeExec+0x9e41>
   592e1:	mov    r15,rax
   592e4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   592ef:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   592fa:	mov    rdi,QWORD PTR [rsp+0x190]
   59302:	jmp    5934b <sqlite3VdbeExec+0x9eab>
   59304:	mov    DWORD PTR [rsp+0x420],r15d
   5930c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   59317:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   59322:	mov    rdi,r13
   59325:	call   5932a <sqlite3VdbeExec+0x9e8a>
   5932a:	mov    r15,rax
   5932d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   59338:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   59343:	mov    rdi,QWORD PTR [rsp+0x190]
   5934b:	test   r15,r15
   5934e:	je     5939c <sqlite3VdbeExec+0x9efc>
   59350:	xor    eax,eax
   59352:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5935d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   59368:	mov    QWORD PTR [rsp+0x190],rdi
   59370:	mov    rdi,r15
   59373:	mov    rsi,rax
   59376:	mov    rdx,r13
   59379:	call   5937e <sqlite3VdbeExec+0x9ede>
   5937e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   59389:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   59394:	mov    rdi,QWORD PTR [rsp+0x190]
   5939c:	mov    QWORD PTR [rbx+0x28],r15
   593a0:	test   r15,r15
   593a3:	jne    593af <sqlite3VdbeExec+0x9f0f>
   593a5:	mov    ebx,0x7
   593aa:	jmp    59605 <sqlite3VdbeExec+0xa165>
   593af:	mov    r13d,DWORD PTR [rsp+0x418]
   593b7:	mov    rax,QWORD PTR [r14+0x20]
   593bb:	mov    QWORD PTR [rsp+0x1e0],r12
   593c3:	mov    r12,QWORD PTR [rax+0x8]
   593c7:	mov    QWORD PTR [rsp+0x1c8],rbp
   593cf:	lea    rbp,[r15+0xc8]
   593d6:	mov    QWORD PTR [r15+0x28],rbp
   593da:	mov    rax,QWORD PTR [rbx+0x30]
   593de:	mov    ebx,DWORD PTR [rsp+0x420]
   593e5:	mov    rcx,rbx
   593e8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   593f3:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   593fe:	mov    QWORD PTR [rsp+0x190],rdi
   59406:	mov    rdi,rbp
   59409:	mov    rsi,rax
   5940c:	mov    rdx,rcx
   5940f:	call   59414 <sqlite3VdbeExec+0x9f74>
   59414:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5941f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5942a:	mov    QWORD PTR [r15+0xd8],0x0
   59435:	mov    rdi,QWORD PTR [rsp+0x190]
   5943d:	test   r13d,r13d
   59440:	je     59447 <sqlite3VdbeExec+0x9fa7>
   59442:	mov    WORD PTR [rbp+0x6],r13w
   59447:	mov    rax,QWORD PTR [r12+0x8]
   5944c:	mov    rcx,QWORD PTR [r12]
   59450:	mov    QWORD PTR [rax+0x8],rcx
   59454:	mov    rax,QWORD PTR [r12+0x8]
   59459:	movsxd rax,DWORD PTR [rax+0x34]
   5945d:	mov    DWORD PTR [r15+0xc],eax
   59461:	mov    BYTE PTR [r15+0x5b],0x1
   59466:	mov    BYTE PTR [r15+0x5a],0xff
   5946b:	xor    ecx,ecx
   5946d:	cmp    BYTE PTR [r15+0x5b],0x1
   59472:	seta   cl
   59475:	mov    BYTE PTR [r15+0x59],cl
   59479:	mov    QWORD PTR [r15+0x20],r14
   5947d:	xor    ecx,ecx
   5947f:	jmp    59494 <sqlite3VdbeExec+0x9ff4>
   59481:	lea    rdx,[r15+0x60]
   59485:	mov    rsi,rcx
   59488:	imul   rsi,rsi,0x68
   5948c:	mov    QWORD PTR [rdx+rsi*1+0x10],r15
   59491:	add    ecx,0x1
   59494:	movzx  edx,BYTE PTR [r15+0x5b]
   59499:	cmp    ecx,edx
   5949b:	jl     59481 <sqlite3VdbeExec+0x9fe1>
   5949d:	cmp    BYTE PTR [r14+0x66],0x2
   594a2:	jne    594b4 <sqlite3VdbeExec+0xa014>
   594a4:	xor    r11d,r11d
   594a7:	mov    DWORD PTR [rsp+0x418],r11d
   594af:	jmp    59578 <sqlite3VdbeExec+0xa0d8>
   594b4:	mov    ecx,eax
   594b6:	imul   ecx,DWORD PTR [rip+0x0]        # 594bd <sqlite3VdbeExec+0xa01d>
   594bd:	mov    DWORD PTR [r15],ecx
   594c0:	mov    rcx,QWORD PTR [r14+0x20]
   594c4:	mov    rcx,QWORD PTR [rcx+0x18]
   594c8:	movsxd rcx,DWORD PTR [rcx+0x74]
   594cc:	test   rcx,rcx
   594cf:	jge    594da <sqlite3VdbeExec+0xa03a>
   594d1:	imul   rcx,rcx,0xfffffffffffffc00
   594d8:	jmp    594e1 <sqlite3VdbeExec+0xa041>
   594da:	mov    rdx,rax
   594dd:	imul   rcx,rdx
   594e1:	mov    edx,0x20000000
   594e6:	cmp    rcx,0x20000000
   594ed:	cmovl  rdx,rcx
   594f1:	mov    ecx,DWORD PTR [r15]
   594f4:	cmp    ecx,edx
   594f6:	cmovg  edx,ecx
   594f9:	mov    DWORD PTR [r15+0x4],edx
   594fd:	cmp    BYTE PTR [rip+0x0],0x0        # 59504 <sqlite3VdbeExec+0xa064>
   59504:	je     59513 <sqlite3VdbeExec+0xa073>
   59506:	xor    r11d,r11d
   59509:	mov    DWORD PTR [rsp+0x418],r11d
   59511:	jmp    59578 <sqlite3VdbeExec+0xa0d8>
   59513:	mov    DWORD PTR [r15+0x54],eax
   59517:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   59522:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5952d:	mov    QWORD PTR [rsp+0x190],rdi
   59535:	mov    rdi,rax
   59538:	call   5953d <sqlite3VdbeExec+0xa09d>
   5953d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   59548:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   59553:	mov    QWORD PTR [r15+0x40],rax
   59557:	mov    eax,0x7
   5955c:	xor    r12d,r12d
   5955f:	cmp    QWORD PTR [r15+0x40],0x0
   59564:	cmove  r12d,eax
   59568:	mov    rdi,QWORD PTR [rsp+0x190]
   59570:	mov    DWORD PTR [rsp+0x418],r12d
   59578:	cmp    WORD PTR [rbp+0x8],0xd
   5957d:	jb     59598 <sqlite3VdbeExec+0xa0f8>
   5957f:	mov    rbp,QWORD PTR [rsp+0x1c8]
   59587:	mov    r12,QWORD PTR [rsp+0x1e0]
   5958f:	mov    ebx,DWORD PTR [rsp+0x418]
   59596:	jmp    59605 <sqlite3VdbeExec+0xa165>
   59598:	cmp    QWORD PTR [rbp+0x20],0x0
   5959d:	je     595c2 <sqlite3VdbeExec+0xa122>
   5959f:	mov    rax,QWORD PTR [rbp+0x20]
   595a3:	cmp    rax,QWORD PTR [r14+0x10]
   595a7:	je     595c2 <sqlite3VdbeExec+0xa122>
   595a9:	mov    rbp,QWORD PTR [rsp+0x1c8]
   595b1:	mov    r12,QWORD PTR [rsp+0x1e0]
   595b9:	mov    ebx,DWORD PTR [rsp+0x418]
   595c0:	jmp    59605 <sqlite3VdbeExec+0xa165>
   595c2:	mov    rax,QWORD PTR [rbp+0x18]
   595c6:	movzx  eax,BYTE PTR [rax]
   595c9:	and    eax,0x2
   595cc:	test   eax,eax
   595ce:	je     595e9 <sqlite3VdbeExec+0xa149>
   595d0:	mov    rbp,QWORD PTR [rsp+0x1c8]
   595d8:	mov    r12,QWORD PTR [rsp+0x1e0]
   595e0:	mov    ebx,DWORD PTR [rsp+0x418]
   595e7:	jmp    59605 <sqlite3VdbeExec+0xa165>
   595e9:	mov    BYTE PTR [r15+0x5c],0x3
   595ee:	mov    rbp,QWORD PTR [rsp+0x1c8]
   595f6:	mov    r12,QWORD PTR [rsp+0x1e0]
   595fe:	mov    ebx,DWORD PTR [rsp+0x418]
   59605:	test   ebx,ebx
   59607:	je     59629 <sqlite3VdbeExec+0xa189>
   59609:	mov    QWORD PTR [rsp+0x1c8],rbp
   59611:	mov    rbp,rbx
   59614:	mov    r13,QWORD PTR [rsp+0x1b0]
   5961c:	mov    rbx,QWORD PTR [rsp+0x1d8]
   59624:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   59629:	mov    DWORD PTR [rsp+0x40c],ebx
   59630:	mov    rbx,r12
   59633:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   59638:	mov    r15d,DWORD PTR [rsp+0x3fc]
   59640:	mov    r13,QWORD PTR [rsp+0x1d0]
   59648:	mov    QWORD PTR [rsp+0x1b0],r12
   59650:	mov    r12d,DWORD PTR [rsp+0x414]
   59658:	mov    rax,QWORD PTR [rdi+0x78]
   5965c:	movsxd rcx,DWORD PTR [rbp+0x4]
   59660:	mov    rax,QWORD PTR [rax+rcx*8]
   59664:	mov    rcx,QWORD PTR [rax+0x10]
   59668:	lea    rdx,[rcx+0x1]
   5966c:	mov    QWORD PTR [rax+0x10],rdx
   59670:	test   rcx,rcx
   59673:	jne    5968d <sqlite3VdbeExec+0xa1ed>
   59675:	mov    QWORD PTR [rsp+0x1d0],r13
   5967d:	mov    DWORD PTR [rsp+0x414],r12d
   59685:	mov    r12,r14
   59688:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5968d:	mov    DWORD PTR [rsp+0x3fc],r15d
   59695:	mov    QWORD PTR [rsp+0x1d0],r13
   5969d:	mov    DWORD PTR [rsp+0x414],r12d
   596a5:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   596aa:	mov    r15d,DWORD PTR [rsp+0x3fc]
   596b2:	mov    r13,QWORD PTR [rsp+0x1d0]
   596ba:	mov    QWORD PTR [rsp+0x1b0],r12
   596c2:	mov    r12d,DWORD PTR [rsp+0x414]
   596ca:	mov    eax,DWORD PTR [rbp+0x4]
   596cd:	mov    ecx,DWORD PTR [rbp+0xc]
   596d0:	mov    edx,0x3
   596d5:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   596e0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   596eb:	mov    QWORD PTR [rsp+0x190],rdi
   596f3:	mov    rsi,rax
   596f6:	mov    r11,rdx
   596f9:	mov    rdx,rcx
   596fc:	mov    rcx,r11
   596ff:	call   59704 <sqlite3VdbeExec+0xa264>
   59704:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5970f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5971a:	mov    rdi,QWORD PTR [rsp+0x190]
   59722:	test   rax,rax
   59725:	jne    59737 <sqlite3VdbeExec+0xa297>
   59727:	mov    rbx,rbp
   5972a:	mov    rbp,QWORD PTR [rsp+0x1d8]
   59732:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   59737:	mov    BYTE PTR [rax+0x2],0x1
   5973b:	mov    ecx,DWORD PTR [rbp+0x8]
   5973e:	mov    DWORD PTR [rax+0x1c],ecx
   59741:	mov    BYTE PTR [rax+0x4],0x1
   59745:	lea    rcx,[rip+0x0]        # 5974c <sqlite3VdbeExec+0xa2ac>
   5974c:	mov    QWORD PTR [rax+0x28],rcx
   59750:	mov    DWORD PTR [rsp+0x3fc],r15d
   59758:	mov    QWORD PTR [rsp+0x1d0],r13
   59760:	mov    DWORD PTR [rsp+0x414],r12d
   59768:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5976d:	mov    r15d,DWORD PTR [rsp+0x3fc]
   59775:	mov    r13,QWORD PTR [rsp+0x1d0]
   5977d:	mov    QWORD PTR [rsp+0x1b0],r12
   59785:	mov    r12d,DWORD PTR [rsp+0x414]
   5978d:	mov    rax,QWORD PTR [rdi+0x78]
   59791:	movsxd rcx,DWORD PTR [rbp+0x4]
   59795:	mov    rax,QWORD PTR [rax+rcx*8]
   59799:	test   rax,rax
   5979c:	je     597e2 <sqlite3VdbeExec+0xa342>
   5979e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   597a9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   597b4:	mov    QWORD PTR [rsp+0x190],rdi
   597bc:	mov    rsi,rax
   597bf:	call   597c4 <sqlite3VdbeExec+0xa324>
   597c4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   597cf:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   597da:	mov    rdi,QWORD PTR [rsp+0x190]
   597e2:	mov    rax,QWORD PTR [rdi+0x78]
   597e6:	movsxd rcx,DWORD PTR [rbp+0x4]
   597ea:	mov    QWORD PTR [rax+rcx*8],0x0
   597f2:	mov    DWORD PTR [rsp+0x3fc],r15d
   597fa:	mov    QWORD PTR [rsp+0x1d0],r13
   59802:	mov    DWORD PTR [rsp+0x414],r12d
   5980a:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5980f:	mov    r15d,DWORD PTR [rsp+0x3fc]
   59817:	mov    r13,QWORD PTR [rsp+0x1d0]
   5981f:	mov    QWORD PTR [rsp+0x1b0],r12
   59827:	mov    r12d,DWORD PTR [rsp+0x414]
   5982f:	mov    rax,QWORD PTR [rdi+0x78]
   59833:	movsxd rcx,DWORD PTR [rbp+0x4]
   59837:	mov    DWORD PTR [rsp+0x414],r12d
   5983f:	mov    r12,QWORD PTR [rax+rcx*8]
   59843:	movzx  eax,BYTE PTR [rbp+0x0]
   59847:	mov    QWORD PTR [rsp+0x1d0],r13
   5984f:	mov    r13d,eax
   59852:	mov    BYTE PTR [r12+0x2],0x0
   59858:	mov    BYTE PTR [r12+0x3],0x0
   5985e:	mov    DWORD PTR [r12+0x18],0x0
   59867:	cmp    BYTE PTR [r12+0x4],0x0
   5986d:	je     59d65 <sqlite3VdbeExec+0xa8c5>
   59873:	movsxd rax,DWORD PTR [rbp+0xc]
   59877:	imul   rax,rax,0x38
   5987b:	mov    DWORD PTR [rsp+0x420],r13d
   59883:	lea    r13,[rbx+rax*1]
   59887:	mov    QWORD PTR [rsp+0x208],r12
   5988f:	movzx  r12d,WORD PTR [rbx+rax*1+0x14]
   59895:	mov    eax,r12d
   59898:	and    eax,0x2e
   5989b:	cmp    eax,0x2
   5989e:	jne    598e9 <sqlite3VdbeExec+0xa449>
   598a0:	xor    eax,eax
   598a2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   598ad:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   598b8:	mov    QWORD PTR [rsp+0x190],rdi
   598c0:	mov    rdi,r13
   598c3:	mov    rsi,rax
   598c6:	call   598cb <sqlite3VdbeExec+0xa42b>
   598cb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   598d6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   598e1:	mov    rdi,QWORD PTR [rsp+0x190]
   598e9:	movzx  eax,WORD PTR [r13+0x14]
   598ee:	mov    ecx,eax
   598f0:	and    ecx,0x24
   598f3:	test   ecx,ecx
   598f5:	je     59908 <sqlite3VdbeExec+0xa468>
   598f7:	mov    DWORD PTR [rsp+0x41c],r12d
   598ff:	mov    r12,QWORD PTR [r13+0x0]
   59903:	jmp    599c2 <sqlite3VdbeExec+0xa522>
   59908:	mov    DWORD PTR [rsp+0x41c],r12d
   59910:	mov    ecx,eax
   59912:	and    ecx,0x8
   59915:	test   ecx,ecx
   59917:	je     59968 <sqlite3VdbeExec+0xa4c8>
   59919:	movsd  xmm3,QWORD PTR [r13+0x0]
   5991f:	movabs r11,0xc3dfffffffffffff
   59929:	movq   xmm2,r11
   5992e:	ucomisd xmm2,xmm3
   59932:	jbe    59940 <sqlite3VdbeExec+0xa4a0>
   59934:	movabs r12,0x8000000000000000
   5993e:	jmp    59966 <sqlite3VdbeExec+0xa4c6>
   59940:	movabs r11,0x43dfffffffffffff
   5994a:	movq   xmm2,r11
   5994f:	ucomisd xmm3,xmm2
   59953:	jbe    59961 <sqlite3VdbeExec+0xa4c1>
   59955:	movabs r12,0x7fffffffffffffff
   5995f:	jmp    59966 <sqlite3VdbeExec+0xa4c6>
   59961:	cvttsd2si r12,xmm3
   59966:	jmp    599c2 <sqlite3VdbeExec+0xa522>
   59968:	and    eax,0x12
   5996b:	test   eax,eax
   5996d:	je     599bf <sqlite3VdbeExec+0xa51f>
   5996f:	cmp    QWORD PTR [r13+0x8],0x0
   59974:	je     599bf <sqlite3VdbeExec+0xa51f>
   59976:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   59981:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5998c:	mov    QWORD PTR [rsp+0x190],rdi
   59994:	mov    rdi,r13
   59997:	call   5999c <sqlite3VdbeExec+0xa4fc>
   5999c:	mov    r12,rax
   5999f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   599aa:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   599b5:	mov    rdi,QWORD PTR [rsp+0x190]
   599bd:	jmp    599c2 <sqlite3VdbeExec+0xa522>
   599bf:	xor    r12d,r12d
   599c2:	movzx  eax,WORD PTR [r13+0x14]
   599c7:	mov    DWORD PTR [rsp+0x3fc],r15d
   599cf:	mov    r15d,DWORD PTR [rsp+0x41c]
   599d7:	mov    WORD PTR [r13+0x14],r15w
   599dc:	mov    ecx,eax
   599de:	and    ecx,0x24
   599e1:	test   ecx,ecx
   599e3:	je     599f2 <sqlite3VdbeExec+0xa552>
   599e5:	mov    r13d,DWORD PTR [rsp+0x420]
   599ed:	jmp    59bfa <sqlite3VdbeExec+0xa75a>
   599f2:	mov    ecx,eax
   599f4:	and    ecx,0x8
   599f7:	test   ecx,ecx
   599f9:	jne    59ae5 <sqlite3VdbeExec+0xa645>
   599ff:	and    eax,0x1
   59a02:	test   eax,eax
   59a04:	jne    59a14 <sqlite3VdbeExec+0xa574>
   59a06:	mov    r13d,DWORD PTR [rsp+0x420]
   59a0e:	cmp    r13d,0x17
   59a12:	jl     59a24 <sqlite3VdbeExec+0xa584>
   59a14:	mov    r12,r14
   59a17:	mov    r15d,DWORD PTR [rsp+0x3fc]
   59a1f:	jmp    52730 <sqlite3VdbeExec+0x3290>
   59a24:	mov    r12,QWORD PTR [rsp+0x208]
   59a2c:	mov    rax,QWORD PTR [r12+0x28]
   59a31:	lea    r12,[rsp+0x418]
   59a39:	mov    rcx,r12
   59a3c:	xor    edx,edx
   59a3e:	movzx  esi,BYTE PTR [rax]
   59a41:	cmp    edx,esi
   59a43:	jne    59a5b <sqlite3VdbeExec+0xa5bb>
   59a45:	movzx  edx,BYTE PTR [rax+0x1]
   59a49:	and    edx,0x8
   59a4c:	test   edx,edx
   59a4e:	je     59a5b <sqlite3VdbeExec+0xa5bb>
   59a50:	mov    DWORD PTR [rcx],0x0
   59a56:	xor    r13d,r13d
   59a59:	jmp    59aa5 <sqlite3VdbeExec+0xa605>
   59a5b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   59a66:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   59a71:	mov    QWORD PTR [rsp+0x190],rdi
   59a79:	mov    rdi,rax
   59a7c:	mov    rsi,rcx
   59a7f:	call   59a84 <sqlite3VdbeExec+0xa5e4>
   59a84:	mov    r13d,eax
   59a87:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   59a92:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   59a9d:	mov    rdi,QWORD PTR [rsp+0x190]
   59aa5:	test   r13d,r13d
   59aa8:	je     59aca <sqlite3VdbeExec+0xa62a>
   59aaa:	mov    QWORD PTR [rsp+0x1c8],rbp
   59ab2:	mov    rbp,r13
   59ab5:	mov    r13,QWORD PTR [rsp+0x1b0]
   59abd:	mov    rbx,QWORD PTR [rsp+0x1d8]
   59ac5:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   59aca:	mov    r15d,DWORD PTR [rsp+0x3fc]
   59ad2:	mov    r12,r13
   59ad5:	xor    r11d,r11d
   59ad8:	mov    DWORD PTR [rsp+0x41c],r11d
   59ae0:	jmp    5a064 <sqlite3VdbeExec+0xabc4>
   59ae5:	mov    r15,r13
   59ae8:	mov    r13d,DWORD PTR [rsp+0x420]
   59af0:	movsd  xmm3,QWORD PTR [r15]
   59af5:	movsd  QWORD PTR [rsp+0x1f8],xmm3
   59afe:	mov    rax,QWORD PTR [rsp+0x1f8]
   59b06:	mov    QWORD PTR [rsp+0x1e8],rax
   59b0e:	mov    rax,QWORD PTR [rsp+0x1e8]
   59b16:	movabs rcx,0x7ff0000000000000
   59b20:	and    rcx,rax
   59b23:	movabs rdx,0x7ff0000000000000
   59b2d:	movabs rsi,0xfffffffffffff
   59b37:	and    rax,rsi
   59b3a:	test   rax,rax
   59b3d:	mov    eax,0x0
   59b42:	setne  al
   59b45:	xor    esi,esi
   59b47:	cmp    rcx,rdx
   59b4a:	cmove  esi,eax
   59b4d:	test   esi,esi
   59b4f:	je     59b58 <sqlite3VdbeExec+0xa6b8>
   59b51:	mov    eax,0x1
   59b56:	jmp    59bd3 <sqlite3VdbeExec+0xa733>
   59b58:	movabs r11,0xc3e0000000000000
   59b62:	movq   xmm2,r11
   59b67:	ucomisd xmm2,xmm3
   59b6b:	jbe    59b74 <sqlite3VdbeExec+0xa6d4>
   59b6d:	mov    eax,0x1
   59b72:	jmp    59bd3 <sqlite3VdbeExec+0xa733>
   59b74:	movabs r11,0x43e0000000000000
   59b7e:	movq   xmm2,r11
   59b83:	ucomisd xmm3,xmm2
   59b87:	jb     59b90 <sqlite3VdbeExec+0xa6f0>
   59b89:	mov    eax,0xffffffff
   59b8e:	jmp    59bd3 <sqlite3VdbeExec+0xa733>
   59b90:	cvttsd2si rax,xmm3
   59b95:	cmp    r12,rax
   59b98:	jge    59ba1 <sqlite3VdbeExec+0xa701>
   59b9a:	mov    eax,0xffffffff
   59b9f:	jmp    59bd3 <sqlite3VdbeExec+0xa733>
   59ba1:	cmp    r12,rax
   59ba4:	jle    59bad <sqlite3VdbeExec+0xa70d>
   59ba6:	mov    eax,0x1
   59bab:	jmp    59bd3 <sqlite3VdbeExec+0xa733>
   59bad:	xorps  xmm2,xmm2
   59bb0:	cvtsi2sd xmm2,r12
   59bb5:	ucomisd xmm3,xmm2
   59bb9:	jbe    59bc2 <sqlite3VdbeExec+0xa722>
   59bbb:	mov    eax,0xffffffff
   59bc0:	jmp    59bd3 <sqlite3VdbeExec+0xa733>
   59bc2:	xorps  xmm2,xmm2
   59bc5:	cvtsi2sd xmm2,r12
   59bca:	xor    eax,eax
   59bcc:	ucomisd xmm2,xmm3
   59bd0:	seta   al
   59bd3:	test   eax,eax
   59bd5:	jle    59be7 <sqlite3VdbeExec+0xa747>
   59bd7:	mov    eax,r13d
   59bda:	and    eax,0x1
   59bdd:	test   eax,eax
   59bdf:	jne    59be5 <sqlite3VdbeExec+0xa745>
   59be1:	sub    r13d,0x1
   59be5:	jmp    59bfa <sqlite3VdbeExec+0xa75a>
   59be7:	test   eax,eax
   59be9:	jge    59bfa <sqlite3VdbeExec+0xa75a>
   59beb:	mov    eax,r13d
   59bee:	and    eax,0x1
   59bf1:	cmp    eax,0x1
   59bf4:	jne    59bfa <sqlite3VdbeExec+0xa75a>
   59bf6:	add    r13d,0x1
   59bfa:	mov    r15,QWORD PTR [rsp+0x208]
   59c02:	mov    rax,QWORD PTR [r15+0x28]
   59c06:	xor    ecx,ecx
   59c08:	mov    QWORD PTR [rsp+0x1a8],r14
   59c10:	lea    r14,[rsp+0x418]
   59c18:	mov    rdx,r14
   59c1b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   59c26:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   59c31:	mov    QWORD PTR [rsp+0x190],rdi
   59c39:	mov    rdi,rax
   59c3c:	mov    rsi,r12
   59c3f:	mov    r11,rdx
   59c42:	mov    rdx,rcx
   59c45:	mov    rcx,r11
   59c48:	call   59c4d <sqlite3VdbeExec+0xa7ad>
   59c4d:	mov    r14d,eax
   59c50:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   59c5b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   59c66:	mov    QWORD PTR [r15+0x48],r12
   59c6a:	mov    rdi,QWORD PTR [rsp+0x190]
   59c72:	test   r14d,r14d
   59c75:	je     59c9f <sqlite3VdbeExec+0xa7ff>
   59c77:	mov    QWORD PTR [rsp+0x1c8],rbp
   59c7f:	mov    rbp,r14
   59c82:	mov    r14,QWORD PTR [rsp+0x1a8]
   59c8a:	mov    r13,QWORD PTR [rsp+0x1b0]
   59c92:	mov    rbx,QWORD PTR [rsp+0x1d8]
   59c9a:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   59c9f:	mov    r12,r15
   59ca2:	mov    r15,r14
   59ca5:	mov    r14,QWORD PTR [rsp+0x1a8]
   59cad:	xor    r11d,r11d
   59cb0:	mov    DWORD PTR [rsp+0x41c],r11d
   59cb8:	cmp    r13d,0x17
   59cbc:	jl     59f49 <sqlite3VdbeExec+0xaaa9>
   59cc2:	cmp    DWORD PTR [rsp+0x418],0x0
   59cca:	jl     59ce4 <sqlite3VdbeExec+0xa844>
   59ccc:	cmp    DWORD PTR [rsp+0x418],0x0
   59cd4:	jne    59f2e <sqlite3VdbeExec+0xaa8e>
   59cda:	cmp    r13d,0x18
   59cde:	jne    59f2e <sqlite3VdbeExec+0xaa8e>
   59ce4:	mov    DWORD PTR [rsp+0x418],0x0
   59cef:	mov    rax,QWORD PTR [r12+0x28]
   59cf4:	xor    ecx,ecx
   59cf6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   59d01:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   59d0c:	mov    QWORD PTR [rsp+0x190],rdi
   59d14:	mov    rdi,rax
   59d17:	mov    rsi,rcx
   59d1a:	call   59d1f <sqlite3VdbeExec+0xa87f>
   59d1f:	mov    r12d,eax
   59d22:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   59d2d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   59d38:	mov    rdi,QWORD PTR [rsp+0x190]
   59d40:	test   r12d,r12d
   59d43:	je     59d5d <sqlite3VdbeExec+0xa8bd>
   59d45:	cmp    r12d,0x65
   59d49:	jne    59f0e <sqlite3VdbeExec+0xaa6e>
   59d4f:	mov    DWORD PTR [rsp+0x418],0x1
   59d5a:	xor    r12d,r12d
   59d5d:	mov    r15,r12
   59d60:	jmp    59f39 <sqlite3VdbeExec+0xaa99>
   59d65:	mov    DWORD PTR [rsp+0x420],r13d
   59d6d:	mov    rax,QWORD PTR [r12+0x28]
   59d72:	movzx  eax,BYTE PTR [rax+0x3]
   59d76:	and    eax,0x2
   59d79:	test   eax,eax
   59d7b:	jne    59d92 <sqlite3VdbeExec+0xa8f2>
   59d7d:	mov    r13d,DWORD PTR [rsp+0x420]
   59d85:	xor    r11d,r11d
   59d88:	mov    DWORD PTR [rsp+0x41c],r11d
   59d90:	jmp    59da8 <sqlite3VdbeExec+0xa908>
   59d92:	mov    r13d,DWORD PTR [rsp+0x420]
   59d9a:	mov    r11d,0x1
   59da0:	mov    DWORD PTR [rsp+0x41c],r11d
   59da8:	mov    eax,DWORD PTR [rbp+0x10]
   59dab:	mov    rcx,QWORD PTR [r12+0x30]
   59db0:	mov    QWORD PTR [rsp+0x268],rcx
   59db8:	mov    WORD PTR [rsp+0x284],ax
   59dc0:	mov    eax,r13d
   59dc3:	sub    eax,0x15
   59dc6:	and    eax,0x1
   59dc9:	test   eax,eax
   59dcb:	je     59dd4 <sqlite3VdbeExec+0xa934>
   59dcd:	mov    eax,0xff
   59dd2:	jmp    59dd9 <sqlite3VdbeExec+0xa939>
   59dd4:	mov    eax,0x1
   59dd9:	mov    BYTE PTR [rsp+0x286],al
   59de0:	movsxd rax,DWORD PTR [rbp+0xc]
   59de4:	imul   rax,rax,0x38
   59de8:	add    rax,rbx
   59deb:	mov    QWORD PTR [rsp+0x270],rax
   59df3:	mov    BYTE PTR [rsp+0x28a],0x0
   59dfb:	mov    rax,QWORD PTR [r12+0x28]
   59e00:	mov    QWORD PTR [rsp+0x1a8],r14
   59e08:	lea    r14,[rsp+0x268]
   59e10:	mov    rcx,r14
   59e13:	lea    r14,[rsp+0x418]
   59e1b:	mov    rdx,r14
   59e1e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   59e29:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   59e34:	mov    QWORD PTR [rsp+0x190],rdi
   59e3c:	mov    rdi,rax
   59e3f:	mov    rsi,rcx
   59e42:	call   59e47 <sqlite3VdbeExec+0xa9a7>
   59e47:	mov    r14d,eax
   59e4a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   59e55:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   59e60:	mov    rdi,QWORD PTR [rsp+0x190]
   59e68:	test   r14d,r14d
   59e6b:	je     59e95 <sqlite3VdbeExec+0xa9f5>
   59e6d:	mov    QWORD PTR [rsp+0x1c8],rbp
   59e75:	mov    rbp,r14
   59e78:	mov    r14,QWORD PTR [rsp+0x1a8]
   59e80:	mov    r13,QWORD PTR [rsp+0x1b0]
   59e88:	mov    rbx,QWORD PTR [rsp+0x1d8]
   59e90:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   59e95:	mov    DWORD PTR [rsp+0x3fc],r15d
   59e9d:	mov    r15,r14
   59ea0:	mov    r14,QWORD PTR [rsp+0x1a8]
   59ea8:	mov    DWORD PTR [rsp+0x428],r15d
   59eb0:	mov    r15d,DWORD PTR [rsp+0x41c]
   59eb8:	test   r15d,r15d
   59ebb:	jne    59ed2 <sqlite3VdbeExec+0xaa32>
   59ebd:	mov    DWORD PTR [rsp+0x41c],r15d
   59ec5:	mov    r15d,DWORD PTR [rsp+0x428]
   59ecd:	jmp    59cb8 <sqlite3VdbeExec+0xa818>
   59ed2:	cmp    BYTE PTR [rsp+0x28a],0x0
   59eda:	je     59ef1 <sqlite3VdbeExec+0xaa51>
   59edc:	mov    DWORD PTR [rsp+0x41c],r15d
   59ee4:	mov    r15d,DWORD PTR [rsp+0x428]
   59eec:	jmp    59cb8 <sqlite3VdbeExec+0xa818>
   59ef1:	mov    r12d,DWORD PTR [rsp+0x428]
   59ef9:	mov    DWORD PTR [rsp+0x41c],r15d
   59f01:	mov    r15d,DWORD PTR [rsp+0x3fc]
   59f09:	jmp    5a064 <sqlite3VdbeExec+0xabc4>
   59f0e:	mov    QWORD PTR [rsp+0x1c8],rbp
   59f16:	mov    rbp,r12
   59f19:	mov    r13,QWORD PTR [rsp+0x1b0]
   59f21:	mov    rbx,QWORD PTR [rsp+0x1d8]
   59f29:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   59f2e:	mov    DWORD PTR [rsp+0x418],0x0
   59f39:	mov    r12,r15
   59f3c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   59f44:	jmp    5a064 <sqlite3VdbeExec+0xabc4>
   59f49:	cmp    DWORD PTR [rsp+0x418],0x0
   59f51:	jg     59f6b <sqlite3VdbeExec+0xaacb>
   59f53:	cmp    DWORD PTR [rsp+0x418],0x0
   59f5b:	jne    5a03e <sqlite3VdbeExec+0xab9e>
   59f61:	cmp    r13d,0x15
   59f65:	jne    5a03e <sqlite3VdbeExec+0xab9e>
   59f6b:	mov    DWORD PTR [rsp+0x418],0x0
   59f76:	mov    rax,QWORD PTR [r12+0x28]
   59f7b:	movzx  ecx,BYTE PTR [rax+0x1]
   59f7f:	and    ecx,0xfffffff1
   59f82:	mov    BYTE PTR [rax+0x1],cl
   59f85:	mov    WORD PTR [rax+0x46],0x0
   59f8b:	cmp    BYTE PTR [rax],0x0
   59f8e:	jne    59fa4 <sqlite3VdbeExec+0xab04>
   59f90:	cmp    WORD PTR [rax+0x56],0x0
   59f95:	je     59fa4 <sqlite3VdbeExec+0xab04>
   59f97:	mov    rcx,QWORD PTR [rax+0x88]
   59f9e:	cmp    BYTE PTR [rcx+0x8],0x0
   59fa2:	jne    59fed <sqlite3VdbeExec+0xab4d>
   59fa4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   59faf:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   59fba:	mov    QWORD PTR [rsp+0x190],rdi
   59fc2:	mov    rdi,rax
   59fc5:	call   59fca <sqlite3VdbeExec+0xab2a>
   59fca:	mov    r12d,eax
   59fcd:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   59fd8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   59fe3:	mov    rdi,QWORD PTR [rsp+0x190]
   59feb:	jmp    59ffb <sqlite3VdbeExec+0xab5b>
   59fed:	movzx  ecx,WORD PTR [rax+0x56]
   59ff1:	sub    ecx,0x1
   59ff4:	mov    WORD PTR [rax+0x56],cx
   59ff8:	xor    r12d,r12d
   59ffb:	test   r12d,r12d
   59ffe:	je     5a014 <sqlite3VdbeExec+0xab74>
   5a000:	cmp    r12d,0x65
   5a004:	jne    5a01e <sqlite3VdbeExec+0xab7e>
   5a006:	mov    DWORD PTR [rsp+0x418],0x1
   5a011:	xor    r12d,r12d
   5a014:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5a01c:	jmp    5a064 <sqlite3VdbeExec+0xabc4>
   5a01e:	mov    QWORD PTR [rsp+0x1c8],rbp
   5a026:	mov    rbp,r12
   5a029:	mov    r13,QWORD PTR [rsp+0x1b0]
   5a031:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5a039:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5a03e:	mov    rax,QWORD PTR [r12+0x28]
   5a043:	xor    ecx,ecx
   5a045:	movzx  eax,BYTE PTR [rax]
   5a048:	cmp    ecx,eax
   5a04a:	mov    eax,0x0
   5a04f:	setne  al
   5a052:	mov    DWORD PTR [rsp+0x418],eax
   5a059:	mov    r12,r15
   5a05c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5a064:	cmp    DWORD PTR [rsp+0x418],0x0
   5a06c:	je     5a07e <sqlite3VdbeExec+0xabde>
   5a06e:	mov    DWORD PTR [rsp+0x40c],r12d
   5a076:	mov    r12,r14
   5a079:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5a07e:	mov    r13d,DWORD PTR [rsp+0x41c]
   5a086:	test   r13d,r13d
   5a089:	je     5a08f <sqlite3VdbeExec+0xabef>
   5a08b:	add    rbp,0x18
   5a08f:	mov    DWORD PTR [rsp+0x3fc],r15d
   5a097:	mov    DWORD PTR [rsp+0x40c],r12d
   5a09f:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5a0a4:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5a0ac:	mov    r13,QWORD PTR [rsp+0x1d0]
   5a0b4:	mov    QWORD PTR [rsp+0x1b0],r12
   5a0bc:	mov    r12d,DWORD PTR [rsp+0x414]
   5a0c4:	mov    rax,QWORD PTR [rdi+0x78]
   5a0c8:	movsxd rcx,DWORD PTR [rbp+0x1c]
   5a0cc:	mov    DWORD PTR [rsp+0x414],r12d
   5a0d4:	mov    r12,QWORD PTR [rax+rcx*8]
   5a0d8:	mov    rax,QWORD PTR [r12+0x28]
   5a0dd:	cmp    BYTE PTR [rax],0x0
   5a0e0:	je     5a0f7 <sqlite3VdbeExec+0xac57>
   5a0e2:	mov    DWORD PTR [rsp+0x3fc],r15d
   5a0ea:	mov    QWORD PTR [rsp+0x1d0],r13
   5a0f2:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5a0f7:	mov    QWORD PTR [rsp+0x1d0],r13
   5a0ff:	mov    r13d,DWORD PTR [rbp+0x4]
   5a103:	mov    rax,QWORD PTR [r12+0x30]
   5a108:	mov    QWORD PTR [rsp+0x268],rax
   5a110:	mov    eax,DWORD PTR [rbp+0x28]
   5a113:	mov    WORD PTR [rsp+0x284],ax
   5a11b:	mov    BYTE PTR [rsp+0x286],0x0
   5a123:	movsxd rax,DWORD PTR [rbp+0x24]
   5a127:	imul   rax,rax,0x38
   5a12b:	add    rax,rbx
   5a12e:	mov    QWORD PTR [rsp+0x270],rax
   5a136:	mov    DWORD PTR [rsp+0x418],0x0
   5a141:	mov    DWORD PTR [rsp+0x3fc],r15d
   5a149:	jmp    5a3cd <sqlite3VdbeExec+0xaf2d>
   5a14e:	mov    DWORD PTR [rsp+0x41c],r13d
   5a156:	mov    r13,r15
   5a159:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5a161:	mov    QWORD PTR [rsp+0x208],r12
   5a169:	lea    r12,[rsp+0x2c0]
   5a171:	mov    WORD PTR [r12+0x14],0x0
   5a179:	mov    QWORD PTR [r12+0x18],r14
   5a17e:	mov    DWORD PTR [r12+0x20],0x0
   5a187:	mov    rcx,r12
   5a18a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a195:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a1a0:	mov    QWORD PTR [rsp+0x190],rdi
   5a1a8:	mov    rdi,r13
   5a1ab:	mov    rsi,rax
   5a1ae:	mov    rdx,rcx
   5a1b1:	call   5a1b6 <sqlite3VdbeExec+0xad16>
   5a1b6:	mov    r13d,eax
   5a1b9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a1c4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a1cf:	mov    rdi,QWORD PTR [rsp+0x190]
   5a1d7:	test   r13d,r13d
   5a1da:	je     5a1e4 <sqlite3VdbeExec+0xad44>
   5a1dc:	mov    r12,r13
   5a1df:	jmp    5a293 <sqlite3VdbeExec+0xadf3>
   5a1e4:	mov    eax,DWORD PTR [r12+0x10]
   5a1e9:	mov    rcx,QWORD PTR [r12+0x8]
   5a1ee:	xor    edx,edx
   5a1f0:	lea    r13,[rsp+0x268]
   5a1f8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a203:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a20e:	mov    rdi,rax
   5a211:	mov    rsi,rcx
   5a214:	mov    rcx,rdx
   5a217:	mov    rdx,r13
   5a21a:	call   5a21f <sqlite3VdbeExec+0xad7f>
   5a21f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a22a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a235:	lea    r13,[rsp+0x418]
   5a23d:	mov    DWORD PTR [r13+0x0],eax
   5a241:	mov    rax,r12
   5a244:	mov    rdi,QWORD PTR [rsp+0x190]
   5a24c:	cmp    DWORD PTR [r12+0x20],0x0
   5a252:	je     5a290 <sqlite3VdbeExec+0xadf0>
   5a254:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a25f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a26a:	mov    rdi,rax
   5a26d:	call   5a272 <sqlite3VdbeExec+0xadd2>
   5a272:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a27d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a288:	mov    rdi,QWORD PTR [rsp+0x190]
   5a290:	xor    r12d,r12d
   5a293:	test   r12d,r12d
   5a296:	je     5a2b8 <sqlite3VdbeExec+0xae18>
   5a298:	mov    QWORD PTR [rsp+0x1c8],rbp
   5a2a0:	mov    rbp,r12
   5a2a3:	mov    r13,QWORD PTR [rsp+0x1b0]
   5a2ab:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5a2b3:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5a2b8:	cmp    DWORD PTR [rsp+0x418],0x0
   5a2c0:	jle    5a2d9 <sqlite3VdbeExec+0xae39>
   5a2c2:	cmp    WORD PTR [rbp+0x2],0x0
   5a2c7:	jne    5a2d9 <sqlite3VdbeExec+0xae39>
   5a2c9:	mov    DWORD PTR [rsp+0x40c],r12d
   5a2d1:	mov    r12,r14
   5a2d4:	jmp    5a3a4 <sqlite3VdbeExec+0xaf04>
   5a2d9:	cmp    DWORD PTR [rsp+0x418],0x0
   5a2e1:	jl     5a2f3 <sqlite3VdbeExec+0xae53>
   5a2e3:	mov    DWORD PTR [rsp+0x40c],r12d
   5a2eb:	mov    r12,r14
   5a2ee:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5a2f3:	mov    r13d,DWORD PTR [rsp+0x41c]
   5a2fb:	test   r13d,r13d
   5a2fe:	jg     5a315 <sqlite3VdbeExec+0xae75>
   5a300:	mov    DWORD PTR [rsp+0x3fc],r15d
   5a308:	mov    DWORD PTR [rsp+0x40c],r12d
   5a310:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5a315:	mov    r12,QWORD PTR [rsp+0x208]
   5a31d:	sub    r13d,0x1
   5a321:	mov    DWORD PTR [r12+0x18],0x0
   5a32a:	mov    rax,QWORD PTR [r12+0x28]
   5a32f:	xor    ecx,ecx
   5a331:	mov    DWORD PTR [rsp+0x3fc],r15d
   5a339:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a344:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a34f:	mov    QWORD PTR [rsp+0x190],rdi
   5a357:	mov    rdi,rax
   5a35a:	mov    rsi,rcx
   5a35d:	call   5a362 <sqlite3VdbeExec+0xaec2>
   5a362:	mov    r15d,eax
   5a365:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a370:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a37b:	mov    rdi,QWORD PTR [rsp+0x190]
   5a383:	test   r15d,r15d
   5a386:	je     5a3cd <sqlite3VdbeExec+0xaf2d>
   5a388:	cmp    r15d,0x65
   5a38c:	jne    5a3ad <sqlite3VdbeExec+0xaf0d>
   5a38e:	mov    r12,r14
   5a391:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5a399:	xor    r11d,r11d
   5a39c:	mov    DWORD PTR [rsp+0x40c],r11d
   5a3a4:	add    rbp,0x18
   5a3a8:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5a3ad:	mov    QWORD PTR [rsp+0x1c8],rbp
   5a3b5:	mov    rbp,r15
   5a3b8:	mov    r13,QWORD PTR [rsp+0x1b0]
   5a3c0:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5a3c8:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5a3cd:	lea    r15,[rsp+0x268]
   5a3d5:	lea    r15,[rsp+0x418]
   5a3dd:	mov    r15,QWORD PTR [r12+0x28]
   5a3e2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a3ed:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a3f8:	mov    QWORD PTR [rsp+0x190],rdi
   5a400:	mov    rdi,r15
   5a403:	call   5a408 <sqlite3VdbeExec+0xaf68>
   5a408:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a413:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a41e:	mov    eax,DWORD PTR [r15+0x40]
   5a422:	mov    rdi,QWORD PTR [rsp+0x190]
   5a42a:	test   rax,rax
   5a42d:	jle    5a43b <sqlite3VdbeExec+0xaf9b>
   5a42f:	cmp    rax,0x7fffffff
   5a435:	jle    5a14e <sqlite3VdbeExec+0xacae>
   5a43b:	mov    DWORD PTR [rsp+0x418],0x0
   5a446:	mov    eax,0x16b6e
   5a44b:	mov    ecx,0xb
   5a450:	lea    rdx,[rip+0x0]        # 5a457 <sqlite3VdbeExec+0xafb7>
   5a457:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a462:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a46d:	mov    QWORD PTR [rsp+0x190],rdi
   5a475:	mov    rdi,rcx
   5a478:	mov    rsi,rax
   5a47b:	call   5a480 <sqlite3VdbeExec+0xafe0>
   5a480:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a48b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a496:	mov    r15d,eax
   5a499:	mov    rdi,QWORD PTR [rsp+0x190]
   5a4a1:	mov    QWORD PTR [rsp+0x208],r12
   5a4a9:	mov    DWORD PTR [rsp+0x41c],r13d
   5a4b1:	mov    r12,r15
   5a4b4:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5a4bc:	jmp    5a293 <sqlite3VdbeExec+0xadf3>
   5a4c1:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5a4c9:	mov    r13,QWORD PTR [rsp+0x1d0]
   5a4d1:	mov    QWORD PTR [rsp+0x1b0],r12
   5a4d9:	mov    r12d,DWORD PTR [rsp+0x414]
   5a4e1:	mov    rax,QWORD PTR [rdi+0x78]
   5a4e5:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a4e9:	mov    rax,QWORD PTR [rax+rcx*8]
   5a4ed:	movzx  ecx,WORD PTR [rax+0x6]
   5a4f1:	cmp    ecx,DWORD PTR [rbp+0x8]
   5a4f4:	jge    5a4ff <sqlite3VdbeExec+0xb05f>
   5a4f6:	mov    ecx,DWORD PTR [rbp+0x8]
   5a4f9:	mov    WORD PTR [rax+0x6],cx
   5a4fd:	jmp    5a50f <sqlite3VdbeExec+0xb06f>
   5a4ff:	movzx  ecx,WORD PTR [rax+0x6]
   5a503:	cmp    ecx,DWORD PTR [rbp+0xc]
   5a506:	jle    5a50f <sqlite3VdbeExec+0xb06f>
   5a508:	mov    ecx,DWORD PTR [rbp+0xc]
   5a50b:	mov    WORD PTR [rax+0x6],cx
   5a50f:	mov    DWORD PTR [rsp+0x3fc],r15d
   5a517:	mov    QWORD PTR [rsp+0x1d0],r13
   5a51f:	mov    DWORD PTR [rsp+0x414],r12d
   5a527:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5a52c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5a534:	mov    r13,QWORD PTR [rsp+0x1d0]
   5a53c:	mov    QWORD PTR [rsp+0x1b0],r12
   5a544:	mov    r12d,DWORD PTR [rsp+0x414]
   5a54c:	mov    rax,QWORD PTR [rdi+0x78]
   5a550:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a554:	mov    rax,QWORD PTR [rax+rcx*8]
   5a558:	test   rax,rax
   5a55b:	je     5a563 <sqlite3VdbeExec+0xb0c3>
   5a55d:	cmp    BYTE PTR [rax+0x2],0x0
   5a561:	je     5a568 <sqlite3VdbeExec+0xb0c8>
   5a563:	jmp    4f80d <sqlite3VdbeExec+0x36d>
   5a568:	mov    DWORD PTR [rsp+0x3fc],r15d
   5a570:	mov    QWORD PTR [rsp+0x1d0],r13
   5a578:	mov    DWORD PTR [rsp+0x414],r12d
   5a580:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5a585:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5a58d:	mov    r13,QWORD PTR [rsp+0x1d0]
   5a595:	mov    QWORD PTR [rsp+0x1b0],r12
   5a59d:	mov    r12d,DWORD PTR [rsp+0x414]
   5a5a5:	mov    rax,QWORD PTR [rdi+0x78]
   5a5a9:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a5ad:	mov    rax,QWORD PTR [rax+rcx*8]
   5a5b1:	movzx  eax,WORD PTR [rax+0x6]
   5a5b5:	cmp    eax,DWORD PTR [rbp+0x10]
   5a5b8:	jl     5a5d7 <sqlite3VdbeExec+0xb137>
   5a5ba:	mov    DWORD PTR [rsp+0x3fc],r15d
   5a5c2:	mov    QWORD PTR [rsp+0x1d0],r13
   5a5ca:	mov    DWORD PTR [rsp+0x414],r12d
   5a5d2:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5a5d7:	mov    rax,QWORD PTR [rdi+0x78]
   5a5db:	movsxd rcx,DWORD PTR [rbp+0x4]
   5a5df:	mov    DWORD PTR [rsp+0x414],r12d
   5a5e7:	mov    r12,QWORD PTR [rax+rcx*8]
   5a5eb:	movsxd rax,DWORD PTR [rbp+0xc]
   5a5ef:	imul   rax,rax,0x38
   5a5f3:	add    rax,rbx
   5a5f6:	mov    QWORD PTR [rsp+0x270],rax
   5a5fe:	mov    eax,DWORD PTR [rbp+0x10]
   5a601:	mov    WORD PTR [rsp+0x284],ax
   5a609:	cmp    WORD PTR [rsp+0x284],0x0
   5a612:	jbe    5a699 <sqlite3VdbeExec+0xb1f9>
   5a618:	mov    rax,QWORD PTR [r12+0x30]
   5a61d:	mov    QWORD PTR [rsp+0x268],rax
   5a625:	mov    BYTE PTR [rsp+0x286],0x0
   5a62d:	mov    rax,QWORD PTR [r12+0x28]
   5a632:	mov    QWORD PTR [rsp+0x1d0],r13
   5a63a:	lea    r13,[rsp+0x268]
   5a642:	mov    rcx,r13
   5a645:	lea    rdx,[r12+0x1c]
   5a64a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a655:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a660:	mov    QWORD PTR [rsp+0x190],rdi
   5a668:	mov    rdi,rax
   5a66b:	mov    rsi,rcx
   5a66e:	call   5a673 <sqlite3VdbeExec+0xb1d3>
   5a673:	mov    r13d,eax
   5a676:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a681:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a68c:	mov    rdi,QWORD PTR [rsp+0x190]
   5a694:	jmp    5a9d7 <sqlite3VdbeExec+0xb537>
   5a699:	mov    QWORD PTR [rsp+0x1d0],r13
   5a6a1:	mov    rax,QWORD PTR [rsp+0x270]
   5a6a9:	movzx  eax,WORD PTR [rax+0x14]
   5a6ad:	and    eax,0x400
   5a6b2:	test   eax,eax
   5a6b4:	je     5a7a5 <sqlite3VdbeExec+0xb305>
   5a6ba:	mov    r13,QWORD PTR [rsp+0x270]
   5a6c2:	mov    eax,DWORD PTR [r13+0x10]
   5a6c6:	add    eax,DWORD PTR [r13+0x0]
   5a6ca:	test   eax,eax
   5a6cc:	jg     5a6e3 <sqlite3VdbeExec+0xb243>
   5a6ce:	movzx  eax,WORD PTR [r13+0x14]
   5a6d3:	and    eax,0x10
   5a6d6:	test   eax,eax
   5a6d8:	je     5a7a5 <sqlite3VdbeExec+0xb305>
   5a6de:	mov    eax,0x1
   5a6e3:	mov    ecx,0x1
   5a6e8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a6f3:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a6fe:	mov    QWORD PTR [rsp+0x190],rdi
   5a706:	mov    rdi,r13
   5a709:	mov    rsi,rax
   5a70c:	mov    rdx,rcx
   5a70f:	call   5a714 <sqlite3VdbeExec+0xb274>
   5a714:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a71f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a72a:	mov    rdi,QWORD PTR [rsp+0x190]
   5a732:	test   eax,eax
   5a734:	jne    5a817 <sqlite3VdbeExec+0xb377>
   5a73a:	mov    rax,QWORD PTR [r13+0x8]
   5a73e:	movsxd rcx,DWORD PTR [r13+0x10]
   5a742:	add    rax,rcx
   5a745:	xor    ecx,ecx
   5a747:	movsxd rdx,DWORD PTR [r13+0x0]
   5a74b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a756:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a761:	mov    rdi,rax
   5a764:	mov    rsi,rcx
   5a767:	call   5a76c <sqlite3VdbeExec+0xb2cc>
   5a76c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a777:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a782:	mov    eax,DWORD PTR [r13+0x10]
   5a786:	add    eax,DWORD PTR [r13+0x0]
   5a78a:	mov    DWORD PTR [r13+0x10],eax
   5a78e:	movzx  eax,WORD PTR [r13+0x14]
   5a793:	and    eax,0xfffff9ff
   5a798:	mov    WORD PTR [r13+0x14],ax
   5a79d:	mov    rdi,QWORD PTR [rsp+0x190]
   5a7a5:	mov    r13,QWORD PTR [r12+0x30]
   5a7aa:	movzx  eax,WORD PTR [r13+0x6]
   5a7af:	add    eax,0x1
   5a7b2:	imul   rax,rax,0x38
   5a7b6:	add    rax,0x28
   5a7ba:	mov    rcx,QWORD PTR [r13+0x10]
   5a7be:	test   rcx,rcx
   5a7c1:	je     5a83f <sqlite3VdbeExec+0xb39f>
   5a7c3:	mov    QWORD PTR [rsp+0x1a8],r14
   5a7cb:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a7d6:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a7e1:	mov    QWORD PTR [rsp+0x190],rdi
   5a7e9:	mov    rdi,rcx
   5a7ec:	mov    rsi,rax
   5a7ef:	call   5a7f4 <sqlite3VdbeExec+0xb354>
   5a7f4:	mov    r14,rax
   5a7f7:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a802:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a80d:	mov    rdi,QWORD PTR [rsp+0x190]
   5a815:	jmp    5a88e <sqlite3VdbeExec+0xb3ee>
   5a817:	mov    QWORD PTR [rsp+0x1a8],r14
   5a81f:	mov    r14,QWORD PTR [rsp+0x1a8]
   5a827:	mov    r13,QWORD PTR [rsp+0x1d0]
   5a82f:	mov    rbx,rbp
   5a832:	mov    rbp,QWORD PTR [rsp+0x1d8]
   5a83a:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5a83f:	mov    QWORD PTR [rsp+0x1a8],r14
   5a847:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a852:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a85d:	mov    QWORD PTR [rsp+0x190],rdi
   5a865:	mov    rdi,rax
   5a868:	call   5a86d <sqlite3VdbeExec+0xb3cd>
   5a86d:	mov    r14,rax
   5a870:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a87b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a886:	mov    rdi,QWORD PTR [rsp+0x190]
   5a88e:	test   r14,r14
   5a891:	jne    5a89b <sqlite3VdbeExec+0xb3fb>
   5a893:	xor    r13d,r13d
   5a896:	mov    r14,r13
   5a899:	jmp    5a8b3 <sqlite3VdbeExec+0xb413>
   5a89b:	lea    rax,[r14+0x28]
   5a89f:	mov    QWORD PTR [r14+0x8],rax
   5a8a3:	mov    QWORD PTR [r14],r13
   5a8a6:	movzx  eax,WORD PTR [r13+0x6]
   5a8ab:	add    eax,0x1
   5a8ae:	mov    WORD PTR [r14+0x1c],ax
   5a8b3:	test   r14,r14
   5a8b6:	jne    5a8d8 <sqlite3VdbeExec+0xb438>
   5a8b8:	mov    r14,QWORD PTR [rsp+0x1a8]
   5a8c0:	mov    r13,QWORD PTR [rsp+0x1d0]
   5a8c8:	mov    rbx,rbp
   5a8cb:	mov    rbp,QWORD PTR [rsp+0x1d8]
   5a8d3:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5a8d8:	mov    rax,QWORD PTR [rsp+0x270]
   5a8e0:	mov    eax,DWORD PTR [rax+0x10]
   5a8e3:	mov    rcx,QWORD PTR [rsp+0x270]
   5a8eb:	mov    rcx,QWORD PTR [rcx+0x8]
   5a8ef:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a8fa:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a905:	mov    QWORD PTR [rsp+0x190],rdi
   5a90d:	mov    rdi,rax
   5a910:	mov    rsi,rcx
   5a913:	mov    rdx,r14
   5a916:	call   5a91b <sqlite3VdbeExec+0xb47b>
   5a91b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a926:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a931:	mov    BYTE PTR [r14+0x1e],0x0
   5a936:	mov    rax,QWORD PTR [r12+0x28]
   5a93b:	lea    rcx,[r12+0x1c]
   5a940:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a94b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a956:	mov    rdi,rax
   5a959:	mov    rsi,r14
   5a95c:	mov    rdx,rcx
   5a95f:	call   5a964 <sqlite3VdbeExec+0xb4c4>
   5a964:	mov    r13d,eax
   5a967:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a972:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a97d:	mov    DWORD PTR [rsp+0x418],r13d
   5a985:	mov    r13,QWORD PTR [rsp+0x1a8]
   5a98d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5a998:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5a9a3:	mov    rdi,r13
   5a9a6:	mov    rsi,r14
   5a9a9:	call   5a9ae <sqlite3VdbeExec+0xb50e>
   5a9ae:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5a9b9:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5a9c4:	mov    rdi,QWORD PTR [rsp+0x190]
   5a9cc:	mov    r14,r13
   5a9cf:	mov    r13d,DWORD PTR [rsp+0x418]
   5a9d7:	test   r13d,r13d
   5a9da:	je     5a9fc <sqlite3VdbeExec+0xb55c>
   5a9dc:	mov    QWORD PTR [rsp+0x1c8],rbp
   5a9e4:	mov    rbp,r13
   5a9e7:	mov    r13,QWORD PTR [rsp+0x1b0]
   5a9ef:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5a9f7:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5a9fc:	mov    eax,DWORD PTR [r12+0x1c]
   5aa01:	xor    ecx,ecx
   5aa03:	test   eax,eax
   5aa05:	sete   cl
   5aa08:	mov    edx,0x1
   5aa0d:	sub    edx,ecx
   5aa0f:	mov    BYTE PTR [r12+0x2],dl
   5aa14:	mov    BYTE PTR [r12+0x3],0x0
   5aa1a:	mov    DWORD PTR [r12+0x18],0x0
   5aa23:	cmp    BYTE PTR [rbp+0x0],0x1d
   5aa27:	jne    5aa3d <sqlite3VdbeExec+0xb59d>
   5aa29:	test   eax,eax
   5aa2b:	jne    5aaa4 <sqlite3VdbeExec+0xb604>
   5aa2d:	mov    r12,r14
   5aa30:	mov    DWORD PTR [rsp+0x40c],r13d
   5aa38:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5aa3d:	test   eax,eax
   5aa3f:	je     5aa51 <sqlite3VdbeExec+0xb5b1>
   5aa41:	mov    r12,r14
   5aa44:	mov    DWORD PTR [rsp+0x40c],r13d
   5aa4c:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5aa51:	cmp    BYTE PTR [rbp+0x0],0x1b
   5aa55:	jne    5aa95 <sqlite3VdbeExec+0xb5f5>
   5aa57:	xor    eax,eax
   5aa59:	jmp    5aa5e <sqlite3VdbeExec+0xb5be>
   5aa5b:	add    eax,0x1
   5aa5e:	movzx  ecx,WORD PTR [rsp+0x284]
   5aa66:	cmp    eax,ecx
   5aa68:	jge    5aa95 <sqlite3VdbeExec+0xb5f5>
   5aa6a:	mov    rcx,QWORD PTR [rsp+0x270]
   5aa72:	mov    rdx,rax
   5aa75:	imul   rdx,rdx,0x38
   5aa79:	movzx  ecx,WORD PTR [rcx+rdx*1+0x14]
   5aa7e:	and    ecx,0x1
   5aa81:	test   ecx,ecx
   5aa83:	je     5aa5b <sqlite3VdbeExec+0xb5bb>
   5aa85:	mov    r12,r14
   5aa88:	mov    DWORD PTR [rsp+0x40c],r13d
   5aa90:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5aa95:	cmp    BYTE PTR [rbp+0x0],0x1a
   5aa99:	jne    5aaa4 <sqlite3VdbeExec+0xb604>
   5aa9b:	mov    eax,DWORD PTR [rbp+0x10]
   5aa9e:	mov    WORD PTR [r12+0x6],ax
   5aaa4:	mov    DWORD PTR [rsp+0x3fc],r15d
   5aaac:	mov    DWORD PTR [rsp+0x40c],r13d
   5aab4:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5aab9:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5aac1:	mov    r13,QWORD PTR [rsp+0x1d0]
   5aac9:	mov    QWORD PTR [rsp+0x1b0],r12
   5aad1:	mov    r12d,DWORD PTR [rsp+0x414]
   5aad9:	movsxd rax,DWORD PTR [rbp+0xc]
   5aadd:	imul   rax,rax,0x38
   5aae1:	movzx  ecx,WORD PTR [rbx+rax*1+0x14]
   5aae6:	and    ecx,0x24
   5aae9:	test   ecx,ecx
   5aaeb:	je     5aafa <sqlite3VdbeExec+0xb65a>
   5aaed:	mov    DWORD PTR [rsp+0x414],r12d
   5aaf5:	jmp    5abca <sqlite3VdbeExec+0xb72a>
   5aafa:	vmovdqu32 xmm2,XMMWORD PTR [rbx+rax*1]
   5ab01:	vmovdqu32 XMMWORD PTR [rsp+0x2c0],xmm2
   5ab09:	vmovdqu32 xmm2,XMMWORD PTR [rbx+rax*1+0x10]
   5ab11:	vmovdqu32 XMMWORD PTR [rsp+0x2d0],xmm2
   5ab19:	vmovdqu32 xmm2,XMMWORD PTR [rbx+rax*1+0x20]
   5ab21:	vmovdqu32 XMMWORD PTR [rsp+0x2e0],xmm2
   5ab29:	vmovdqu32 xmm2,XMMWORD PTR [rbx+rax*1+0x28]
   5ab34:	vmovdqu32 XMMWORD PTR [rsp+0x2e8],xmm2
   5ab3f:	mov    DWORD PTR [rsp+0x414],r12d
   5ab47:	lea    r12,[rsp+0x2c0]
   5ab4f:	mov    rax,r12
   5ab52:	mov    ecx,0x43
   5ab57:	mov    edx,r15d
   5ab5a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ab65:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ab70:	mov    QWORD PTR [rsp+0x190],rdi
   5ab78:	mov    rdi,rax
   5ab7b:	mov    rsi,rcx
   5ab7e:	call   5ab83 <sqlite3VdbeExec+0xb6e3>
   5ab83:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ab8e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ab99:	movzx  eax,WORD PTR [rsp+0x2d4]
   5aba1:	and    eax,0x4
   5aba4:	mov    rdi,QWORD PTR [rsp+0x190]
   5abac:	test   eax,eax
   5abae:	jne    5abc0 <sqlite3VdbeExec+0xb720>
   5abb0:	mov    r12,r14
   5abb3:	mov    QWORD PTR [rsp+0x1d0],r13
   5abbb:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5abc0:	mov    r12,QWORD PTR [rsp+0x2c0]
   5abc8:	jmp    5abd6 <sqlite3VdbeExec+0xb736>
   5abca:	movsxd rax,DWORD PTR [rbp+0xc]
   5abce:	imul   rax,rax,0x38
   5abd2:	mov    r12,QWORD PTR [rbx+rax*1]
   5abd6:	mov    rax,QWORD PTR [rdi+0x78]
   5abda:	movsxd rcx,DWORD PTR [rbp+0x4]
   5abde:	mov    QWORD PTR [rsp+0x1d0],r13
   5abe6:	mov    r13,QWORD PTR [rax+rcx*8]
   5abea:	mov    rax,QWORD PTR [r13+0x28]
   5abee:	mov    DWORD PTR [rsp+0x3f8],0x0
   5abf9:	xor    ecx,ecx
   5abfb:	mov    DWORD PTR [rsp+0x3fc],r15d
   5ac03:	lea    r15,[rsp+0x3f8]
   5ac0b:	mov    rdx,r15
   5ac0e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ac19:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ac24:	mov    QWORD PTR [rsp+0x190],rdi
   5ac2c:	mov    rdi,rax
   5ac2f:	mov    rsi,r12
   5ac32:	mov    r11,rdx
   5ac35:	mov    rdx,rcx
   5ac38:	mov    rcx,r11
   5ac3b:	call   5ac40 <sqlite3VdbeExec+0xb7a0>
   5ac40:	mov    r15d,eax
   5ac43:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ac4e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ac59:	mov    QWORD PTR [r13+0x48],r12
   5ac5d:	mov    BYTE PTR [r13+0x2],0x0
   5ac62:	mov    DWORD PTR [r13+0x18],0x0
   5ac6a:	mov    BYTE PTR [r13+0x3],0x0
   5ac6f:	mov    eax,DWORD PTR [rsp+0x3f8]
   5ac76:	mov    DWORD PTR [r13+0x1c],eax
   5ac7a:	mov    rdi,QWORD PTR [rsp+0x190]
   5ac82:	cmp    DWORD PTR [rsp+0x3f8],0x0
   5ac8a:	je     5ace8 <sqlite3VdbeExec+0xb848>
   5ac8c:	cmp    DWORD PTR [rbp+0x8],0x0
   5ac90:	jne    5ad0d <sqlite3VdbeExec+0xb86d>
   5ac92:	mov    eax,0x18e86
   5ac97:	mov    ecx,0xb
   5ac9c:	lea    rdx,[rip+0x0]        # 5aca3 <sqlite3VdbeExec+0xb803>
   5aca3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5acae:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5acb9:	mov    rdi,rcx
   5acbc:	mov    rsi,rax
   5acbf:	call   5acc4 <sqlite3VdbeExec+0xb824>
   5acc4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5accf:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5acda:	mov    r12d,eax
   5acdd:	mov    rdi,QWORD PTR [rsp+0x190]
   5ace5:	mov    r15,r12
   5ace8:	test   r15d,r15d
   5aceb:	je     5ad28 <sqlite3VdbeExec+0xb888>
   5aced:	mov    QWORD PTR [rsp+0x1c8],rbp
   5acf5:	mov    rbp,r15
   5acf8:	mov    r13,QWORD PTR [rsp+0x1b0]
   5ad00:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5ad08:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5ad0d:	mov    r12,r14
   5ad10:	mov    r14,r15
   5ad13:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5ad1b:	mov    DWORD PTR [rsp+0x40c],r14d
   5ad23:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5ad28:	mov    DWORD PTR [rsp+0x40c],r15d
   5ad30:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5ad35:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5ad3d:	mov    r13,QWORD PTR [rsp+0x1d0]
   5ad45:	mov    QWORD PTR [rsp+0x1b0],r12
   5ad4d:	mov    r12d,DWORD PTR [rsp+0x414]
   5ad55:	mov    rax,QWORD PTR [rdi+0x68]
   5ad59:	movsxd rcx,DWORD PTR [rbp+0x8]
   5ad5d:	imul   rcx,rcx,0x38
   5ad61:	lea    rdx,[rax+rcx*1]
   5ad65:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5ad6a:	and    eax,0x9000
   5ad6f:	test   eax,eax
   5ad71:	je     5adbc <sqlite3VdbeExec+0xb91c>
   5ad73:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ad7e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ad89:	mov    QWORD PTR [rsp+0x190],rdi
   5ad91:	mov    rdi,rdx
   5ad94:	call   5ad99 <sqlite3VdbeExec+0xb8f9>
   5ad99:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ada4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5adaf:	mov    rdi,QWORD PTR [rsp+0x190]
   5adb7:	mov    rdx,rax
   5adba:	jmp    5adc2 <sqlite3VdbeExec+0xb922>
   5adbc:	mov    WORD PTR [rdx+0x14],0x4
   5adc2:	mov    rax,QWORD PTR [rdi+0x78]
   5adc6:	movsxd rcx,DWORD PTR [rbp+0x4]
   5adca:	mov    rax,QWORD PTR [rax+rcx*8]
   5adce:	mov    rcx,QWORD PTR [rax+0x10]
   5add2:	lea    rsi,[rcx+0x1]
   5add6:	mov    QWORD PTR [rax+0x10],rsi
   5adda:	mov    QWORD PTR [rdx],rcx
   5addd:	mov    DWORD PTR [rsp+0x3fc],r15d
   5ade5:	mov    QWORD PTR [rsp+0x1d0],r13
   5aded:	mov    DWORD PTR [rsp+0x414],r12d
   5adf5:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5adfa:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5ae02:	mov    r13,QWORD PTR [rsp+0x1d0]
   5ae0a:	mov    QWORD PTR [rsp+0x1b0],r12
   5ae12:	mov    r12d,DWORD PTR [rsp+0x414]
   5ae1a:	mov    QWORD PTR [rsp+0x208],0x0
   5ae26:	mov    DWORD PTR [rsp+0x418],0x0
   5ae31:	mov    rax,QWORD PTR [rdi+0x68]
   5ae35:	movsxd rcx,DWORD PTR [rbp+0x8]
   5ae39:	imul   rcx,rcx,0x38
   5ae3d:	mov    DWORD PTR [rsp+0x414],r12d
   5ae45:	lea    r12,[rax+rcx*1]
   5ae49:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5ae4e:	and    eax,0x9000
   5ae53:	test   eax,eax
   5ae55:	je     5aea0 <sqlite3VdbeExec+0xba00>
   5ae57:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ae62:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ae6d:	mov    QWORD PTR [rsp+0x190],rdi
   5ae75:	mov    rdi,r12
   5ae78:	call   5ae7d <sqlite3VdbeExec+0xb9dd>
   5ae7d:	mov    r12,rax
   5ae80:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ae8b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ae96:	mov    rdi,QWORD PTR [rsp+0x190]
   5ae9e:	jmp    5aea8 <sqlite3VdbeExec+0xba08>
   5aea0:	mov    WORD PTR [r12+0x14],0x4
   5aea8:	mov    rax,QWORD PTR [rdi+0x78]
   5aeac:	movsxd rcx,DWORD PTR [rbp+0x4]
   5aeb0:	mov    QWORD PTR [rsp+0x1e8],r12
   5aeb8:	mov    r12,QWORD PTR [rax+rcx*8]
   5aebc:	movzx  eax,BYTE PTR [r12+0x5]
   5aec2:	shl    rax,0x3e
   5aec6:	shr    rax,0x3f
   5aeca:	test   eax,eax
   5aecc:	je     5aedb <sqlite3VdbeExec+0xba3b>
   5aece:	mov    QWORD PTR [rsp+0x1f8],r12
   5aed6:	jmp    5b076 <sqlite3VdbeExec+0xbbd6>
   5aedb:	mov    rax,QWORD PTR [r12+0x28]
   5aee0:	mov    QWORD PTR [rsp+0x1f8],r12
   5aee8:	lea    r12,[rsp+0x418]
   5aef0:	mov    rcx,r12
   5aef3:	xor    edx,edx
   5aef5:	movzx  esi,BYTE PTR [rax]
   5aef8:	cmp    edx,esi
   5aefa:	jne    5af12 <sqlite3VdbeExec+0xba72>
   5aefc:	movzx  edx,BYTE PTR [rax+0x1]
   5af00:	and    edx,0x8
   5af03:	test   edx,edx
   5af05:	je     5af12 <sqlite3VdbeExec+0xba72>
   5af07:	mov    DWORD PTR [rcx],0x0
   5af0d:	xor    r12d,r12d
   5af10:	jmp    5af5c <sqlite3VdbeExec+0xbabc>
   5af12:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5af1d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5af28:	mov    QWORD PTR [rsp+0x190],rdi
   5af30:	mov    rdi,rax
   5af33:	mov    rsi,rcx
   5af36:	call   5af3b <sqlite3VdbeExec+0xba9b>
   5af3b:	mov    r12d,eax
   5af3e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5af49:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5af54:	mov    rdi,QWORD PTR [rsp+0x190]
   5af5c:	test   r12d,r12d
   5af5f:	je     5af89 <sqlite3VdbeExec+0xbae9>
   5af61:	mov    QWORD PTR [rsp+0x1d0],r13
   5af69:	mov    QWORD PTR [rsp+0x1c8],rbp
   5af71:	mov    rbp,r12
   5af74:	mov    r13,QWORD PTR [rsp+0x1b0]
   5af7c:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5af84:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5af89:	cmp    DWORD PTR [rsp+0x418],0x0
   5af91:	je     5afac <sqlite3VdbeExec+0xbb0c>
   5af93:	mov    QWORD PTR [rsp+0x208],0x1
   5af9f:	mov    DWORD PTR [rsp+0x40c],r12d
   5afa7:	jmp    5b076 <sqlite3VdbeExec+0xbbd6>
   5afac:	mov    DWORD PTR [rsp+0x40c],r12d
   5afb4:	mov    r12,QWORD PTR [rsp+0x1f8]
   5afbc:	mov    QWORD PTR [rsp+0x1d0],r13
   5afc4:	mov    r13,QWORD PTR [r12+0x28]
   5afc9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5afd4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5afdf:	mov    QWORD PTR [rsp+0x190],rdi
   5afe7:	mov    rdi,r13
   5afea:	call   5afef <sqlite3VdbeExec+0xbb4f>
   5afef:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5affa:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b005:	mov    rax,QWORD PTR [r13+0x30]
   5b009:	mov    QWORD PTR [rsp+0x208],rax
   5b011:	movabs rax,0x7fffffffffffffff
   5b01b:	mov    rdi,QWORD PTR [rsp+0x190]
   5b023:	cmp    rax,QWORD PTR [rsp+0x208]
   5b02b:	jg     5b052 <sqlite3VdbeExec+0xbbb2>
   5b02d:	movzx  eax,BYTE PTR [r12+0x5]
   5b033:	and    rax,0xfffffffffffffffd
   5b037:	or     rax,0x2
   5b03b:	mov    BYTE PTR [r12+0x5],al
   5b040:	mov    QWORD PTR [rsp+0x1f8],r12
   5b048:	mov    r13,QWORD PTR [rsp+0x1d0]
   5b050:	jmp    5b076 <sqlite3VdbeExec+0xbbd6>
   5b052:	mov    rax,QWORD PTR [rsp+0x208]
   5b05a:	add    rax,0x1
   5b05e:	mov    QWORD PTR [rsp+0x208],rax
   5b066:	mov    QWORD PTR [rsp+0x1f8],r12
   5b06e:	mov    r13,QWORD PTR [rsp+0x1d0]
   5b076:	cmp    DWORD PTR [rbp+0xc],0x0
   5b07a:	jne    5b091 <sqlite3VdbeExec+0xbbf1>
   5b07c:	mov    QWORD PTR [rsp+0x1d0],r13
   5b084:	mov    r13,QWORD PTR [rsp+0x1f8]
   5b08c:	jmp    5b23d <sqlite3VdbeExec+0xbd9d>
   5b091:	cmp    QWORD PTR [rdi+0x108],0x0
   5b099:	je     5b0c1 <sqlite3VdbeExec+0xbc21>
   5b09b:	mov    rax,QWORD PTR [rdi+0x108]
   5b0a2:	jmp    5b0a8 <sqlite3VdbeExec+0xbc08>
   5b0a4:	mov    rax,QWORD PTR [rax+0x8]
   5b0a8:	cmp    QWORD PTR [rax+0x8],0x0
   5b0ad:	jne    5b0a4 <sqlite3VdbeExec+0xbc04>
   5b0af:	mov    rax,QWORD PTR [rax+0x18]
   5b0b3:	movsxd rcx,DWORD PTR [rbp+0xc]
   5b0b7:	imul   rcx,rcx,0x38
   5b0bb:	lea    r12,[rax+rcx*1]
   5b0bf:	jmp    5b0cd <sqlite3VdbeExec+0xbc2d>
   5b0c1:	movsxd rax,DWORD PTR [rbp+0xc]
   5b0c5:	imul   rax,rax,0x38
   5b0c9:	lea    r12,[rbx+rax*1]
   5b0cd:	movzx  eax,WORD PTR [r12+0x14]
   5b0d3:	mov    ecx,eax
   5b0d5:	and    ecx,0x24
   5b0d8:	test   ecx,ecx
   5b0da:	je     5b0e5 <sqlite3VdbeExec+0xbc45>
   5b0dc:	mov    rax,QWORD PTR [r12]
   5b0e0:	jmp    5b194 <sqlite3VdbeExec+0xbcf4>
   5b0e5:	mov    ecx,eax
   5b0e7:	and    ecx,0x8
   5b0ea:	test   ecx,ecx
   5b0ec:	je     5b13d <sqlite3VdbeExec+0xbc9d>
   5b0ee:	movsd  xmm2,QWORD PTR [r12]
   5b0f4:	movabs r11,0xc3dfffffffffffff
   5b0fe:	movq   xmm3,r11
   5b103:	ucomisd xmm3,xmm2
   5b107:	jbe    5b115 <sqlite3VdbeExec+0xbc75>
   5b109:	movabs rax,0x8000000000000000
   5b113:	jmp    5b13b <sqlite3VdbeExec+0xbc9b>
   5b115:	movabs r11,0x43dfffffffffffff
   5b11f:	movq   xmm3,r11
   5b124:	ucomisd xmm2,xmm3
   5b128:	jbe    5b136 <sqlite3VdbeExec+0xbc96>
   5b12a:	movabs rax,0x7fffffffffffffff
   5b134:	jmp    5b13b <sqlite3VdbeExec+0xbc9b>
   5b136:	cvttsd2si rax,xmm2
   5b13b:	jmp    5b194 <sqlite3VdbeExec+0xbcf4>
   5b13d:	and    eax,0x12
   5b140:	test   eax,eax
   5b142:	je     5b192 <sqlite3VdbeExec+0xbcf2>
   5b144:	cmp    QWORD PTR [r12+0x8],0x0
   5b14a:	je     5b192 <sqlite3VdbeExec+0xbcf2>
   5b14c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b157:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b162:	mov    QWORD PTR [rsp+0x190],rdi
   5b16a:	mov    rdi,r12
   5b16d:	call   5b172 <sqlite3VdbeExec+0xbcd2>
   5b172:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b17d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b188:	mov    rdi,QWORD PTR [rsp+0x190]
   5b190:	jmp    5b194 <sqlite3VdbeExec+0xbcf4>
   5b192:	xor    eax,eax
   5b194:	mov    QWORD PTR [r12],rax
   5b198:	movzx  eax,WORD PTR [r12+0x14]
   5b19e:	and    eax,0xfffff240
   5b1a3:	or     eax,0x4
   5b1a6:	mov    WORD PTR [r12+0x14],ax
   5b1ac:	movabs rax,0x7fffffffffffffff
   5b1b6:	cmp    rax,QWORD PTR [r12]
   5b1ba:	jne    5b1c6 <sqlite3VdbeExec+0xbd26>
   5b1bc:	mov    QWORD PTR [rsp+0x1d0],r13
   5b1c4:	jmp    5b1e7 <sqlite3VdbeExec+0xbd47>
   5b1c6:	mov    QWORD PTR [rsp+0x1d0],r13
   5b1ce:	mov    r13,QWORD PTR [rsp+0x1f8]
   5b1d6:	movzx  eax,BYTE PTR [r13+0x5]
   5b1db:	shl    rax,0x3e
   5b1df:	shr    rax,0x3f
   5b1e3:	test   eax,eax
   5b1e5:	je     5b20c <sqlite3VdbeExec+0xbd6c>
   5b1e7:	mov    ebx,0xd
   5b1ec:	mov    QWORD PTR [rsp+0x1c8],rbp
   5b1f4:	mov    rbp,rbx
   5b1f7:	mov    r13,QWORD PTR [rsp+0x1b0]
   5b1ff:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5b207:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5b20c:	mov    rax,QWORD PTR [rsp+0x208]
   5b214:	mov    rcx,QWORD PTR [r12]
   5b218:	add    rcx,0x1
   5b21c:	cmp    rax,rcx
   5b21f:	jge    5b231 <sqlite3VdbeExec+0xbd91>
   5b221:	mov    rax,QWORD PTR [r12]
   5b225:	add    rax,0x1
   5b229:	mov    QWORD PTR [rsp+0x208],rax
   5b231:	mov    rax,QWORD PTR [rsp+0x208]
   5b239:	mov    QWORD PTR [r12],rax
   5b23d:	movzx  eax,BYTE PTR [r13+0x5]
   5b242:	shl    rax,0x3e
   5b246:	shr    rax,0x3f
   5b24a:	test   eax,eax
   5b24c:	jne    5b25b <sqlite3VdbeExec+0xbdbb>
   5b24e:	mov    r12,QWORD PTR [rsp+0x1e8]
   5b256:	jmp    5b3e6 <sqlite3VdbeExec+0xbf46>
   5b25b:	xor    r12d,r12d
   5b25e:	mov    eax,0x8
   5b263:	mov    QWORD PTR [rsp+0x1a8],r14
   5b26b:	lea    r14,[rsp+0x208]
   5b273:	mov    rcx,r14
   5b276:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b281:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b28c:	mov    QWORD PTR [rsp+0x190],rdi
   5b294:	mov    rdi,rax
   5b297:	mov    rsi,rcx
   5b29a:	call   5b29f <sqlite3VdbeExec+0xbdff>
   5b29f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b2aa:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b2b5:	movabs rax,0x3fffffffffffffff
   5b2bf:	and    rax,QWORD PTR [rsp+0x208]
   5b2c7:	mov    QWORD PTR [rsp+0x208],rax
   5b2cf:	mov    rax,QWORD PTR [rsp+0x208]
   5b2d7:	add    rax,0x1
   5b2db:	mov    QWORD PTR [rsp+0x208],rax
   5b2e3:	mov    rax,QWORD PTR [r13+0x28]
   5b2e7:	mov    rcx,QWORD PTR [rsp+0x208]
   5b2ef:	xor    edx,edx
   5b2f1:	lea    r14,[rsp+0x418]
   5b2f9:	mov    rsi,r14
   5b2fc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b307:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b312:	mov    rdi,rax
   5b315:	mov    r11,rsi
   5b318:	mov    rsi,rcx
   5b31b:	mov    rcx,r11
   5b31e:	call   5b323 <sqlite3VdbeExec+0xbe83>
   5b323:	mov    r14d,eax
   5b326:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b331:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b33c:	mov    rdi,QWORD PTR [rsp+0x190]
   5b344:	test   r14d,r14d
   5b347:	jne    5b36a <sqlite3VdbeExec+0xbeca>
   5b349:	cmp    DWORD PTR [rsp+0x418],0x0
   5b351:	jne    5b36a <sqlite3VdbeExec+0xbeca>
   5b353:	add    r12d,0x1
   5b357:	cmp    r12d,0x64
   5b35b:	jge    5b36a <sqlite3VdbeExec+0xbeca>
   5b35d:	mov    r14,QWORD PTR [rsp+0x1a8]
   5b365:	jmp    5b25e <sqlite3VdbeExec+0xbdbe>
   5b36a:	test   r14d,r14d
   5b36d:	je     5b397 <sqlite3VdbeExec+0xbef7>
   5b36f:	mov    QWORD PTR [rsp+0x1c8],rbp
   5b377:	mov    rbp,r14
   5b37a:	mov    r14,QWORD PTR [rsp+0x1a8]
   5b382:	mov    r13,QWORD PTR [rsp+0x1b0]
   5b38a:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5b392:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5b397:	cmp    DWORD PTR [rsp+0x418],0x0
   5b39f:	jne    5b3ce <sqlite3VdbeExec+0xbf2e>
   5b3a1:	mov    ebx,0xd
   5b3a6:	mov    r14,QWORD PTR [rsp+0x1a8]
   5b3ae:	mov    QWORD PTR [rsp+0x1c8],rbp
   5b3b6:	mov    rbp,rbx
   5b3b9:	mov    r13,QWORD PTR [rsp+0x1b0]
   5b3c1:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5b3c9:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5b3ce:	mov    r12,QWORD PTR [rsp+0x1e8]
   5b3d6:	mov    DWORD PTR [rsp+0x40c],r14d
   5b3de:	mov    r14,QWORD PTR [rsp+0x1a8]
   5b3e6:	mov    BYTE PTR [r13+0x3],0x0
   5b3eb:	mov    DWORD PTR [r13+0x18],0x0
   5b3f3:	mov    rax,QWORD PTR [rsp+0x208]
   5b3fb:	mov    QWORD PTR [r12],rax
   5b3ff:	mov    DWORD PTR [rsp+0x3fc],r15d
   5b407:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5b40c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5b414:	mov    QWORD PTR [rsp+0x1b0],r12
   5b41c:	movsxd rax,DWORD PTR [rbp+0x8]
   5b420:	imul   rax,rax,0x38
   5b424:	mov    rcx,QWORD PTR [rdi+0x78]
   5b428:	movsxd rdx,DWORD PTR [rbp+0x4]
   5b42c:	mov    r12,QWORD PTR [rcx+rdx*8]
   5b430:	movsxd rcx,DWORD PTR [rbp+0xc]
   5b434:	imul   rcx,rcx,0x38
   5b438:	mov    rcx,QWORD PTR [rbx+rcx*1]
   5b43c:	mov    QWORD PTR [rsp+0x298],rcx
   5b444:	cmp    BYTE PTR [rbp+0x1],0xfb
   5b448:	je     5b454 <sqlite3VdbeExec+0xbfb4>
   5b44a:	mov    QWORD PTR [rsp+0x208],r12
   5b452:	jmp    5b488 <sqlite3VdbeExec+0xbfe8>
   5b454:	cmp    QWORD PTR [r14+0x138],0x0
   5b45c:	jne    5b468 <sqlite3VdbeExec+0xbfc8>
   5b45e:	mov    QWORD PTR [rsp+0x208],r12
   5b466:	jmp    5b488 <sqlite3VdbeExec+0xbfe8>
   5b468:	mov    rcx,QWORD PTR [r14+0x20]
   5b46c:	movsx  rdx,BYTE PTR [r12+0x1]
   5b472:	shl    rdx,0x5
   5b476:	mov    r13,QWORD PTR [rcx+rdx*1]
   5b47a:	mov    QWORD PTR [rsp+0x208],r12
   5b482:	mov    r12,QWORD PTR [rbp+0x10]
   5b486:	jmp    5b48e <sqlite3VdbeExec+0xbfee>
   5b488:	xor    r12d,r12d
   5b48b:	xor    r13d,r13d
   5b48e:	movzx  ecx,WORD PTR [rbp+0x2]
   5b492:	and    ecx,0x1
   5b495:	test   ecx,ecx
   5b497:	je     5b4bc <sqlite3VdbeExec+0xc01c>
   5b499:	mov    rcx,QWORD PTR [rdi+0x38]
   5b49d:	add    rcx,0x1
   5b4a1:	mov    QWORD PTR [rdi+0x38],rcx
   5b4a5:	movzx  ecx,WORD PTR [rbp+0x2]
   5b4a9:	and    ecx,0x20
   5b4ac:	test   ecx,ecx
   5b4ae:	je     5b4bc <sqlite3VdbeExec+0xc01c>
   5b4b0:	mov    rcx,QWORD PTR [rsp+0x298]
   5b4b8:	mov    QWORD PTR [r14+0x38],rcx
   5b4bc:	mov    rcx,QWORD PTR [rbx+rax*1+0x8]
   5b4c1:	mov    QWORD PTR [rsp+0x2a0],rcx
   5b4c9:	mov    ecx,DWORD PTR [rbx+rax*1+0x10]
   5b4cd:	mov    DWORD PTR [rsp+0x2b4],ecx
   5b4d4:	movzx  ecx,WORD PTR [rbp+0x2]
   5b4d8:	and    ecx,0x10
   5b4db:	test   ecx,ecx
   5b4dd:	je     5b4f5 <sqlite3VdbeExec+0xc055>
   5b4df:	mov    QWORD PTR [rsp+0x1e8],r13
   5b4e7:	mov    r13,QWORD PTR [rsp+0x208]
   5b4ef:	mov    ecx,DWORD PTR [r13+0x1c]
   5b4f3:	jmp    5b507 <sqlite3VdbeExec+0xc067>
   5b4f5:	mov    QWORD PTR [rsp+0x1e8],r13
   5b4fd:	mov    r13,QWORD PTR [rsp+0x208]
   5b505:	xor    ecx,ecx
   5b507:	movzx  edx,WORD PTR [rbx+rax*1+0x14]
   5b50c:	and    edx,0x400
   5b512:	test   edx,edx
   5b514:	je     5b522 <sqlite3VdbeExec+0xc082>
   5b516:	mov    eax,DWORD PTR [rbx+rax*1]
   5b519:	mov    DWORD PTR [rsp+0x2b8],eax
   5b520:	jmp    5b52d <sqlite3VdbeExec+0xc08d>
   5b522:	mov    DWORD PTR [rsp+0x2b8],0x0
   5b52d:	mov    QWORD PTR [rsp+0x290],0x0
   5b539:	mov    rax,QWORD PTR [r13+0x28]
   5b53d:	mov    QWORD PTR [rsp+0x1a8],r14
   5b545:	lea    r14,[rsp+0x290]
   5b54d:	mov    rdx,r14
   5b550:	movzx  esi,WORD PTR [rbp+0x2]
   5b554:	and    esi,0x8a
   5b55a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b565:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b570:	mov    QWORD PTR [rsp+0x190],rdi
   5b578:	mov    rdi,rax
   5b57b:	mov    r11,rsi
   5b57e:	mov    rsi,rdx
   5b581:	mov    rdx,r11
   5b584:	call   5b589 <sqlite3VdbeExec+0xc0e9>
   5b589:	mov    r14d,eax
   5b58c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b597:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b5a2:	mov    BYTE PTR [r13+0x3],0x0
   5b5a7:	mov    DWORD PTR [r13+0x18],0x0
   5b5af:	mov    r13d,DWORD PTR [rsp+0x414]
   5b5b7:	add    r13d,0x1
   5b5bb:	mov    rdi,QWORD PTR [rsp+0x190]
   5b5c3:	test   r14d,r14d
   5b5c6:	je     5b5f0 <sqlite3VdbeExec+0xc150>
   5b5c8:	mov    QWORD PTR [rsp+0x1c8],rbp
   5b5d0:	mov    rbp,r14
   5b5d3:	mov    r14,QWORD PTR [rsp+0x1a8]
   5b5db:	mov    r13,QWORD PTR [rsp+0x1b0]
   5b5e3:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5b5eb:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5b5f0:	test   r12,r12
   5b5f3:	jne    5b60a <sqlite3VdbeExec+0xc16a>
   5b5f5:	mov    DWORD PTR [rsp+0x414],r13d
   5b5fd:	mov    r13,QWORD PTR [rsp+0x1a8]
   5b605:	jmp    5b6a1 <sqlite3VdbeExec+0xc201>
   5b60a:	mov    DWORD PTR [rsp+0x414],r13d
   5b612:	mov    r13,QWORD PTR [rsp+0x1a8]
   5b61a:	mov    rax,QWORD PTR [r13+0x138]
   5b621:	mov    rcx,QWORD PTR [r13+0x130]
   5b628:	movzx  edx,WORD PTR [rbp+0x2]
   5b62c:	and    edx,0x4
   5b62f:	test   edx,edx
   5b631:	je     5b63a <sqlite3VdbeExec+0xc19a>
   5b633:	mov    edx,0x17
   5b638:	jmp    5b63f <sqlite3VdbeExec+0xc19f>
   5b63a:	mov    edx,0x12
   5b63f:	mov    rsi,QWORD PTR [r12]
   5b643:	mov    r8,QWORD PTR [rsp+0x298]
   5b64b:	mov    r12,QWORD PTR [rsp+0x1e8]
   5b653:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b65e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b669:	mov    QWORD PTR [rsp+0x190],rdi
   5b671:	mov    rdi,rcx
   5b674:	mov    rcx,rsi
   5b677:	mov    rsi,rdx
   5b67a:	mov    rdx,r12
   5b67d:	mov    r10,rax
   5b680:	call   r10
   5b683:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b68e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b699:	mov    rdi,QWORD PTR [rsp+0x190]
   5b6a1:	mov    DWORD PTR [rsp+0x3fc],r15d
   5b6a9:	mov    DWORD PTR [rsp+0x40c],r14d
   5b6b1:	mov    r14,r13
   5b6b4:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5b6b9:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5b6c1:	mov    r13,QWORD PTR [rsp+0x1d0]
   5b6c9:	mov    QWORD PTR [rsp+0x1b0],r12
   5b6d1:	mov    r12d,DWORD PTR [rsp+0x414]
   5b6d9:	mov    rax,QWORD PTR [rdi+0x78]
   5b6dd:	movsxd rcx,DWORD PTR [rbp+0x4]
   5b6e1:	mov    rax,QWORD PTR [rax+rcx*8]
   5b6e5:	mov    rcx,QWORD PTR [rdi+0x78]
   5b6e9:	movsxd rdx,DWORD PTR [rbp+0x8]
   5b6ed:	mov    rcx,QWORD PTR [rcx+rdx*8]
   5b6f1:	cmp    DWORD PTR [rbp+0xc],0x0
   5b6f5:	je     5b70d <sqlite3VdbeExec+0xc26d>
   5b6f7:	movsxd rdx,DWORD PTR [rbp+0xc]
   5b6fb:	imul   rdx,rdx,0x38
   5b6ff:	mov    DWORD PTR [rsp+0x414],r12d
   5b707:	mov    r12,QWORD PTR [rbx+rdx*1]
   5b70b:	jmp    5b718 <sqlite3VdbeExec+0xc278>
   5b70d:	mov    DWORD PTR [rsp+0x414],r12d
   5b715:	xor    r12d,r12d
   5b718:	mov    QWORD PTR [rsp+0x1e8],r12
   5b720:	mov    r12,QWORD PTR [rax+0x28]
   5b724:	mov    QWORD PTR [rsp+0x1d0],r13
   5b72c:	mov    r13,QWORD PTR [rcx+0x28]
   5b730:	mov    QWORD PTR [rsp+0x208],r12
   5b738:	mov    r12,QWORD PTR [r12+0x20]
   5b73d:	mov    QWORD PTR [rsp+0x1f0],r12
   5b745:	mov    r12,QWORD PTR [r12+0x88]
   5b74d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b758:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b763:	mov    QWORD PTR [rsp+0x190],rdi
   5b76b:	mov    rdi,r13
   5b76e:	call   5b773 <sqlite3VdbeExec+0xc2d3>
   5b773:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b77e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b789:	mov    rdi,QWORD PTR [rsp+0x190]
   5b791:	cmp    DWORD PTR [r13+0x40],0x80
   5b799:	jae    5b7c0 <sqlite3VdbeExec+0xc320>
   5b79b:	mov    DWORD PTR [rsp+0x3fc],r15d
   5b7a3:	lea    r15,[r12+0x1]
   5b7a8:	mov    eax,DWORD PTR [r13+0x40]
   5b7ac:	mov    BYTE PTR [r12],al
   5b7b0:	mov    r12,r15
   5b7b3:	lea    r8,[rsp+0x404]
   5b7bb:	jmp    5b864 <sqlite3VdbeExec+0xc3c4>
   5b7c0:	mov    DWORD PTR [rsp+0x3fc],r15d
   5b7c8:	lea    r8,[rsp+0x404]
   5b7d0:	mov    eax,DWORD PTR [r13+0x40]
   5b7d4:	cmp    rax,0x7f
   5b7d8:	ja     5b7e9 <sqlite3VdbeExec+0xc349>
   5b7da:	and    rax,0x7f
   5b7de:	mov    BYTE PTR [r12],al
   5b7e2:	mov    eax,0x1
   5b7e7:	jmp    5b85e <sqlite3VdbeExec+0xc3be>
   5b7e9:	cmp    rax,0x3fff
   5b7ef:	ja     5b817 <sqlite3VdbeExec+0xc377>
   5b7f1:	mov    rcx,rax
   5b7f4:	shr    rcx,0x7
   5b7f8:	and    rcx,0x7f
   5b7fc:	or     rcx,0x80
   5b803:	mov    BYTE PTR [r12],cl
   5b807:	and    rax,0x7f
   5b80b:	mov    BYTE PTR [r12+0x1],al
   5b810:	mov    eax,0x2
   5b815:	jmp    5b85e <sqlite3VdbeExec+0xc3be>
   5b817:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b822:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b82d:	mov    rdi,r12
   5b830:	mov    rsi,rax
   5b833:	call   5b838 <sqlite3VdbeExec+0xc398>
   5b838:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b843:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b84e:	mov    rdi,QWORD PTR [rsp+0x190]
   5b856:	lea    r8,[rsp+0x404]
   5b85e:	movsxd rax,eax
   5b861:	add    r12,rax
   5b864:	mov    r15,QWORD PTR [rsp+0x208]
   5b86c:	cmp    QWORD PTR [r15+0x80],0x0
   5b874:	jne    5b923 <sqlite3VdbeExec+0xc483>
   5b87a:	mov    r15,QWORD PTR [rsp+0x1e8]
   5b882:	cmp    r15,0x7f
   5b886:	ja     5b89d <sqlite3VdbeExec+0xc3fd>
   5b888:	mov    rax,r15
   5b88b:	and    rax,0x7f
   5b88f:	mov    BYTE PTR [r12],al
   5b893:	mov    eax,0x1
   5b898:	jmp    5b91d <sqlite3VdbeExec+0xc47d>
   5b89d:	cmp    r15,0x3fff
   5b8a4:	ja     5b8ce <sqlite3VdbeExec+0xc42e>
   5b8a6:	mov    rax,r15
   5b8a9:	shr    rax,0x7
   5b8ad:	and    rax,0x7f
   5b8b1:	or     rax,0x80
   5b8b7:	mov    BYTE PTR [r12],al
   5b8bb:	mov    rax,r15
   5b8be:	and    rax,0x7f
   5b8c2:	mov    BYTE PTR [r12+0x1],al
   5b8c7:	mov    eax,0x2
   5b8cc:	jmp    5b91d <sqlite3VdbeExec+0xc47d>
   5b8ce:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b8d9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b8e4:	mov    QWORD PTR [rsp+0x190],rdi
   5b8ec:	mov    rdi,r12
   5b8ef:	mov    rsi,r15
   5b8f2:	call   5b8f7 <sqlite3VdbeExec+0xc457>
   5b8f7:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b902:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b90d:	mov    rdi,QWORD PTR [rsp+0x190]
   5b915:	lea    r8,[rsp+0x404]
   5b91d:	movsxd rax,eax
   5b920:	add    r12,rax
   5b923:	movzx  eax,WORD PTR [r13+0x44]
   5b928:	mov    r15d,eax
   5b92b:	mov    QWORD PTR [rsp+0x1e0],rbx
   5b933:	mov    rbx,QWORD PTR [r13+0x38]
   5b937:	mov    rax,r15
   5b93a:	add    rax,rbx
   5b93d:	mov    rcx,QWORD PTR [r13+0x88]
   5b944:	cmp    rax,QWORD PTR [rcx+0x58]
   5b948:	jbe    5b9b2 <sqlite3VdbeExec+0xc512>
   5b94a:	mov    eax,0x143bd
   5b94f:	mov    ecx,0xb
   5b954:	lea    rdx,[rip+0x0]        # 5b95b <sqlite3VdbeExec+0xc4bb>
   5b95b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5b966:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5b971:	mov    QWORD PTR [rsp+0x190],rdi
   5b979:	mov    rdi,rcx
   5b97c:	mov    rsi,rax
   5b97f:	call   5b984 <sqlite3VdbeExec+0xc4e4>
   5b984:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5b98f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5b99a:	mov    ebx,eax
   5b99c:	mov    rdi,QWORD PTR [rsp+0x190]
   5b9a4:	mov    r11,rbx
   5b9a7:	mov    rbx,rbp
   5b9aa:	mov    rbp,r11
   5b9ad:	jmp    5c500 <sqlite3VdbeExec+0xd060>
   5b9b2:	mov    QWORD PTR [rsp+0x1a8],r14
   5b9ba:	mov    r14d,DWORD PTR [r13+0x40]
   5b9be:	cmp    r15d,r14d
   5b9c1:	je     5b9e8 <sqlite3VdbeExec+0xc548>
   5b9c3:	mov    QWORD PTR [rsp+0x1e8],rbx
   5b9cb:	mov    rbx,QWORD PTR [rsp+0x1f0]
   5b9d3:	mov    QWORD PTR [rsp+0x1c8],rbp
   5b9db:	mov    rbp,QWORD PTR [rsp+0x208]
   5b9e3:	jmp    5ba99 <sqlite3VdbeExec+0xc5f9>
   5b9e8:	mov    QWORD PTR [rsp+0x1c8],rbp
   5b9f0:	mov    rbp,QWORD PTR [rsp+0x208]
   5b9f8:	mov    rax,QWORD PTR [rbp+0x88]
   5b9ff:	movzx  eax,WORD PTR [rax+0xe]
   5ba03:	cmp    r15d,eax
   5ba06:	jb     5ba1a <sqlite3VdbeExec+0xc57a>
   5ba08:	mov    QWORD PTR [rsp+0x1e8],rbx
   5ba10:	mov    rbx,QWORD PTR [rsp+0x1f0]
   5ba18:	jmp    5ba99 <sqlite3VdbeExec+0xc5f9>
   5ba1a:	mov    rax,r15
   5ba1d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ba28:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ba33:	mov    QWORD PTR [rsp+0x190],rdi
   5ba3b:	mov    rdi,r12
   5ba3e:	mov    rsi,rbx
   5ba41:	mov    rdx,rax
   5ba44:	call   5ba49 <sqlite3VdbeExec+0xc5a9>
   5ba49:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ba54:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ba5f:	mov    rbx,QWORD PTR [rsp+0x1f0]
   5ba67:	mov    rax,r12
   5ba6a:	sub    rax,QWORD PTR [rbx+0x88]
   5ba71:	add    eax,r15d
   5ba74:	mov    DWORD PTR [rbx+0x90],eax
   5ba7a:	xor    ebp,ebp
   5ba7c:	mov    rdi,QWORD PTR [rsp+0x190]
   5ba84:	mov    r14,QWORD PTR [rsp+0x1a8]
   5ba8c:	mov    rbx,QWORD PTR [rsp+0x1c8]
   5ba94:	jmp    5c500 <sqlite3VdbeExec+0xd060>
   5ba99:	mov    DWORD PTR [r8],0x0
   5baa0:	mov    rax,QWORD PTR [r13+0x20]
   5baa4:	mov    DWORD PTR [rsp+0x418],r14d
   5baac:	mov    r14,QWORD PTR [rax]
   5baaf:	mov    QWORD PTR [rsp+0x200],r14
   5bab7:	lea    r14,[rsp+0x1b8]
   5babf:	mov    QWORD PTR [r14],0x0
   5bac6:	xor    r14d,r14d
   5bac9:	mov    rax,QWORD PTR [rbp+0x88]
   5bad0:	mov    ecx,DWORD PTR [r13+0x40]
   5bad4:	mov    rdx,rcx
   5bad7:	movzx  esi,WORD PTR [rax+0xe]
   5badb:	mov    r9,rsi
   5bade:	cmp    rdx,r9
   5bae1:	jg     5bae7 <sqlite3VdbeExec+0xc647>
   5bae3:	mov    ebp,ecx
   5bae5:	jmp    5bb13 <sqlite3VdbeExec+0xc673>
   5bae7:	movzx  ecx,WORD PTR [rax+0x10]
   5baeb:	mov    r9,rcx
   5baee:	sub    rdx,r9
   5baf1:	mov    rax,QWORD PTR [rax+0x48]
   5baf5:	mov    eax,DWORD PTR [rax+0x38]
   5baf8:	sub    eax,0x4
   5bafb:	mov    r10,rax
   5bafe:	mov    rax,rdx
   5bb01:	cqo
   5bb03:	idiv   r10
   5bb06:	mov    rax,rdx
   5bb09:	add    rax,r9
   5bb0c:	cmp    eax,esi
   5bb0e:	mov    ebp,ecx
   5bb10:	cmovle ebp,eax
   5bb13:	mov    rax,r12
   5bb16:	sub    rax,QWORD PTR [rbx+0x88]
   5bb1d:	add    eax,ebp
   5bb1f:	mov    DWORD PTR [rbx+0x90],eax
   5bb25:	cmp    ebp,DWORD PTR [r13+0x40]
   5bb29:	jb     5bb40 <sqlite3VdbeExec+0xc6a0>
   5bb2b:	mov    r14d,DWORD PTR [rsp+0x418]
   5bb33:	xor    r11d,r11d
   5bb36:	mov    QWORD PTR [rsp+0x208],r11
   5bb3e:	jmp    5bb65 <sqlite3VdbeExec+0xc6c5>
   5bb40:	mov    eax,ebp
   5bb42:	lea    r14,[r12+rax*1]
   5bb46:	mov    eax,DWORD PTR [rbx+0x90]
   5bb4c:	add    eax,0x4
   5bb4f:	mov    DWORD PTR [rbx+0x90],eax
   5bb55:	mov    QWORD PTR [rsp+0x208],r14
   5bb5d:	mov    r14d,DWORD PTR [rsp+0x418]
   5bb65:	cmp    r14d,r15d
   5bb68:	ja     5bb85 <sqlite3VdbeExec+0xc6e5>
   5bb6a:	xor    r11d,r11d
   5bb6d:	mov    DWORD PTR [rsp+0x428],r11d
   5bb75:	xor    r11d,r11d
   5bb78:	mov    QWORD PTR [rsp+0x210],r11
   5bb80:	jmp    5bc76 <sqlite3VdbeExec+0xc7d6>
   5bb85:	mov    rax,r15
   5bb88:	mov    DWORD PTR [rsp+0x41c],ebp
   5bb8f:	mov    rbp,QWORD PTR [rsp+0x1e8]
   5bb97:	lea    rax,[rbp+rax*1+0x4]
   5bb9c:	mov    rcx,QWORD PTR [r13+0x88]
   5bba3:	cmp    rax,QWORD PTR [rcx+0x58]
   5bba7:	jbe    5bc18 <sqlite3VdbeExec+0xc778>
   5bba9:	mov    eax,0x143d6
   5bbae:	mov    ecx,0xb
   5bbb3:	lea    rdx,[rip+0x0]        # 5bbba <sqlite3VdbeExec+0xc71a>
   5bbba:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5bbc5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5bbd0:	mov    QWORD PTR [rsp+0x190],rdi
   5bbd8:	mov    rdi,rcx
   5bbdb:	mov    rsi,rax
   5bbde:	call   5bbe3 <sqlite3VdbeExec+0xc743>
   5bbe3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5bbee:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5bbf9:	mov    ebp,eax
   5bbfb:	mov    rdi,QWORD PTR [rsp+0x190]
   5bc03:	mov    r14,QWORD PTR [rsp+0x1a8]
   5bc0b:	mov    rbx,QWORD PTR [rsp+0x1c8]
   5bc13:	jmp    5c500 <sqlite3VdbeExec+0xd060>
   5bc18:	mov    rax,QWORD PTR [r13+0x38]
   5bc1c:	mov    rcx,r15
   5bc1f:	movzx  edx,BYTE PTR [rax+rcx*1]
   5bc23:	shl    edx,0x18
   5bc26:	movzx  esi,BYTE PTR [rax+rcx*1+0x1]
   5bc2b:	shl    esi,0x10
   5bc2e:	or     edx,esi
   5bc30:	movzx  esi,BYTE PTR [rax+rcx*1+0x2]
   5bc35:	shl    esi,0x8
   5bc38:	or     edx,esi
   5bc3a:	movzx  eax,BYTE PTR [rax+rcx*1+0x3]
   5bc3f:	or     edx,eax
   5bc41:	mov    DWORD PTR [rsp+0x418],r14d
   5bc49:	mov    r14d,edx
   5bc4c:	mov    QWORD PTR [rsp+0x1e8],rbp
   5bc54:	mov    DWORD PTR [rsp+0x428],r14d
   5bc5c:	mov    r14d,DWORD PTR [rsp+0x418]
   5bc64:	mov    ebp,DWORD PTR [rsp+0x41c]
   5bc6b:	xor    r11d,r11d
   5bc6e:	mov    QWORD PTR [rsp+0x210],r11
   5bc76:	sub    r14d,ebp
   5bc79:	mov    DWORD PTR [rsp+0x41c],r14d
   5bc81:	mov    r14,QWORD PTR [rsp+0x1e8]
   5bc89:	test   r15d,r15d
   5bc8c:	ja     5bca0 <sqlite3VdbeExec+0xc800>
   5bc8e:	mov    QWORD PTR [rsp+0x1f8],r13
   5bc96:	mov    QWORD PTR [rsp+0x1f0],rbx
   5bc9e:	jmp    5bd1d <sqlite3VdbeExec+0xc87d>
   5bca0:	mov    QWORD PTR [rsp+0x1f0],rbx
   5bca8:	cmp    ebp,r15d
   5bcab:	mov    ebx,r15d
   5bcae:	cmovb  ebx,ebp
   5bcb1:	mov    QWORD PTR [rsp+0x1f8],r13
   5bcb9:	movsxd r13,ebx
   5bcbc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5bcc7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5bcd2:	mov    QWORD PTR [rsp+0x190],rdi
   5bcda:	mov    rdi,r12
   5bcdd:	mov    rsi,r14
   5bce0:	mov    rdx,r13
   5bce3:	call   5bce8 <sqlite3VdbeExec+0xc848>
   5bce8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5bcf3:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5bcfe:	sub    ebp,ebx
   5bd00:	sub    r15d,ebx
   5bd03:	add    r12,r13
   5bd06:	lea    rbx,[r14+r13*1]
   5bd0a:	mov    rdi,QWORD PTR [rsp+0x190]
   5bd12:	mov    r14,rbx
   5bd15:	lea    r8,[rsp+0x404]
   5bd1d:	test   ebp,ebp
   5bd1f:	jbe    5bf41 <sqlite3VdbeExec+0xcaa1>
   5bd25:	lea    rbx,[rsp+0x1b8]
   5bd2d:	mov    rax,QWORD PTR [rbx]
   5bd30:	test   rax,rax
   5bd33:	jne    5bd42 <sqlite3VdbeExec+0xc8a2>
   5bd35:	mov    r13,QWORD PTR [rsp+0x1f8]
   5bd3d:	jmp    5be34 <sqlite3VdbeExec+0xc994>
   5bd42:	movzx  ecx,WORD PTR [rax+0x34]
   5bd46:	and    ecx,0x20
   5bd49:	test   ecx,ecx
   5bd4b:	je     5bde8 <sqlite3VdbeExec+0xc948>
   5bd51:	mov    rcx,QWORD PTR [rax+0x28]
   5bd55:	mov    edx,DWORD PTR [rcx+0x98]
   5bd5b:	sub    edx,0x1
   5bd5e:	mov    DWORD PTR [rcx+0x98],edx
   5bd64:	mov    rdx,QWORD PTR [rcx+0xa8]
   5bd6b:	mov    QWORD PTR [rax+0x20],rdx
   5bd6f:	mov    QWORD PTR [rcx+0xa8],rax
   5bd76:	mov    rdx,QWORD PTR [rcx+0x48]
   5bd7a:	mov    esi,DWORD PTR [rax+0x30]
   5bd7d:	sub    esi,0x1
   5bd80:	imul   rsi,QWORD PTR [rcx+0xc8]
   5bd88:	mov    rax,QWORD PTR [rax+0x8]
   5bd8c:	mov    rcx,QWORD PTR [rdx]
   5bd8f:	mov    rcx,QWORD PTR [rcx+0x90]
   5bd96:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5bda1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5bdac:	mov    QWORD PTR [rsp+0x190],rdi
   5bdb4:	mov    rdi,rdx
   5bdb7:	mov    rdx,rax
   5bdba:	mov    r10,rcx
   5bdbd:	call   r10
   5bdc0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5bdcb:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5bdd6:	mov    rdi,QWORD PTR [rsp+0x190]
   5bdde:	mov    r13,QWORD PTR [rsp+0x1f8]
   5bde6:	jmp    5be34 <sqlite3VdbeExec+0xc994>
   5bde8:	mov    r13,QWORD PTR [rsp+0x1f8]
   5bdf0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5bdfb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5be06:	mov    QWORD PTR [rsp+0x190],rdi
   5be0e:	mov    rdi,rax
   5be11:	call   5be16 <sqlite3VdbeExec+0xc976>
   5be16:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5be21:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5be2c:	mov    rdi,QWORD PTR [rsp+0x190]
   5be34:	mov    QWORD PTR [rbx],0x0
   5be3b:	mov    rax,rbx
   5be3e:	mov    ecx,0x2
   5be43:	mov    rbx,QWORD PTR [rsp+0x200]
   5be4b:	mov    rdx,QWORD PTR [rbx+0x110]
   5be52:	mov    QWORD PTR [rsp+0x218],r12
   5be5a:	mov    r12d,DWORD PTR [rsp+0x428]
   5be62:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5be6d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5be78:	mov    QWORD PTR [rsp+0x190],rdi
   5be80:	mov    rdi,rbx
   5be83:	mov    rsi,r12
   5be86:	mov    r10,rdx
   5be89:	mov    rdx,rax
   5be8c:	call   r10
   5be8f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5be9a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5bea5:	lea    r8,[rsp+0x404]
   5bead:	mov    DWORD PTR [r8],eax
   5beb0:	mov    rdi,QWORD PTR [rsp+0x190]
   5beb8:	cmp    DWORD PTR [r8],0x0
   5bebc:	je     5bed8 <sqlite3VdbeExec+0xca38>
   5bebe:	mov    QWORD PTR [rsp+0x1f8],r13
   5bec6:	mov    DWORD PTR [rsp+0x428],r12d
   5bece:	mov    r12,QWORD PTR [rsp+0x218]
   5bed6:	jmp    5bf41 <sqlite3VdbeExec+0xcaa1>
   5bed8:	lea    r12,[rsp+0x1b8]
   5bee0:	mov    rax,QWORD PTR [r12]
   5bee4:	mov    rax,QWORD PTR [rax+0x8]
   5bee8:	movzx  ecx,BYTE PTR [rax]
   5beeb:	shl    ecx,0x18
   5beee:	movzx  edx,BYTE PTR [rax+0x1]
   5bef2:	shl    edx,0x10
   5bef5:	or     ecx,edx
   5bef7:	movzx  edx,BYTE PTR [rax+0x2]
   5befb:	shl    edx,0x8
   5befe:	or     ecx,edx
   5bf00:	movzx  edx,BYTE PTR [rax+0x3]
   5bf04:	or     ecx,edx
   5bf06:	mov    r14d,ecx
   5bf09:	lea    r15,[rax+0x4]
   5bf0d:	mov    rax,QWORD PTR [r13+0x20]
   5bf11:	mov    eax,DWORD PTR [rax+0x38]
   5bf14:	mov    r12d,eax
   5bf17:	sub    r12d,0x4
   5bf1b:	mov    QWORD PTR [rsp+0x1f8],r13
   5bf23:	mov    QWORD PTR [rsp+0x200],rbx
   5bf2b:	mov    DWORD PTR [rsp+0x428],r14d
   5bf33:	mov    r14,r15
   5bf36:	mov    r15,r12
   5bf39:	mov    r12,QWORD PTR [rsp+0x218]
   5bf41:	cmp    DWORD PTR [r8],0x0
   5bf45:	jne    5bf60 <sqlite3VdbeExec+0xcac0>
   5bf47:	test   ebp,ebp
   5bf49:	jbe    5bf60 <sqlite3VdbeExec+0xcac0>
   5bf4b:	mov    r13,QWORD PTR [rsp+0x1f8]
   5bf53:	mov    rbx,QWORD PTR [rsp+0x1f0]
   5bf5b:	jmp    5bc89 <sqlite3VdbeExec+0xc7e9>
   5bf60:	cmp    DWORD PTR [r8],0x0
   5bf64:	je     5bf83 <sqlite3VdbeExec+0xcae3>
   5bf66:	mov    r13,QWORD PTR [rsp+0x1f0]
   5bf6e:	mov    QWORD PTR [rsp+0x218],r12
   5bf76:	mov    rbx,QWORD PTR [rsp+0x210]
   5bf7e:	jmp    5c2c2 <sqlite3VdbeExec+0xce22>
   5bf83:	mov    r13d,DWORD PTR [rsp+0x41c]
   5bf8b:	test   r13d,r13d
   5bf8e:	ja     5bfad <sqlite3VdbeExec+0xcb0d>
   5bf90:	mov    r13,QWORD PTR [rsp+0x1f0]
   5bf98:	mov    QWORD PTR [rsp+0x218],r12
   5bfa0:	mov    rbx,QWORD PTR [rsp+0x210]
   5bfa8:	jmp    5c2c2 <sqlite3VdbeExec+0xce22>
   5bfad:	mov    rbx,QWORD PTR [rsp+0x208]
   5bfb5:	test   rbx,rbx
   5bfb8:	jne    5bfe7 <sqlite3VdbeExec+0xcb47>
   5bfba:	mov    DWORD PTR [rsp+0x41c],r13d
   5bfc2:	mov    r13,QWORD PTR [rsp+0x1f0]
   5bfca:	mov    QWORD PTR [rsp+0x218],r12
   5bfd2:	mov    QWORD PTR [rsp+0x208],rbx
   5bfda:	mov    rbx,QWORD PTR [rsp+0x210]
   5bfe2:	jmp    5c2c2 <sqlite3VdbeExec+0xce22>
   5bfe7:	lea    r13,[rsp+0x420]
   5bfef:	mov    DWORD PTR [r13+0x0],0x0
   5bff7:	lea    r13,[rsp+0x220]
   5bfff:	mov    QWORD PTR [r13+0x0],0x0
   5c007:	mov    rax,r13
   5c00a:	lea    r13,[rsp+0x420]
   5c012:	mov    rcx,r13
   5c015:	xor    edx,edx
   5c017:	xor    esi,esi
   5c019:	mov    r13,QWORD PTR [rsp+0x1f0]
   5c021:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c02c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c037:	mov    QWORD PTR [rsp+0x190],rdi
   5c03f:	mov    rdi,r13
   5c042:	mov    r8,rsi
   5c045:	mov    rsi,rax
   5c048:	mov    r11,rdx
   5c04b:	mov    rdx,rcx
   5c04e:	mov    rcx,r11
   5c051:	call   5c056 <sqlite3VdbeExec+0xcbb6>
   5c056:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c061:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c06c:	lea    r8,[rsp+0x404]
   5c074:	mov    DWORD PTR [r8],eax
   5c077:	mov    QWORD PTR [rsp+0x218],r12
   5c07f:	lea    r12,[rsp+0x420]
   5c087:	mov    eax,DWORD PTR [r12]
   5c08b:	mov    ecx,eax
   5c08d:	shr    ecx,0x18
   5c090:	mov    BYTE PTR [rbx],cl
   5c092:	mov    ecx,eax
   5c094:	shr    ecx,0x10
   5c097:	mov    BYTE PTR [rbx+0x1],cl
   5c09a:	mov    ecx,eax
   5c09c:	shr    ecx,0x8
   5c09f:	mov    BYTE PTR [rbx+0x2],cl
   5c0a2:	mov    BYTE PTR [rbx+0x3],al
   5c0a5:	mov    rdi,QWORD PTR [rsp+0x190]
   5c0ad:	cmp    BYTE PTR [r13+0x21],0x0
   5c0b2:	jne    5c0c6 <sqlite3VdbeExec+0xcc26>
   5c0b4:	mov    QWORD PTR [rsp+0x208],rbx
   5c0bc:	mov    rbx,QWORD PTR [rsp+0x210]
   5c0c4:	jmp    5c127 <sqlite3VdbeExec+0xcc87>
   5c0c6:	mov    rbx,QWORD PTR [rsp+0x210]
   5c0ce:	test   rbx,rbx
   5c0d1:	je     5c127 <sqlite3VdbeExec+0xcc87>
   5c0d3:	mov    eax,DWORD PTR [r12]
   5c0d7:	mov    ecx,DWORD PTR [rbx+0x4]
   5c0da:	mov    rdx,r8
   5c0dd:	mov    esi,0x4
   5c0e2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c0ed:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c0f8:	mov    rdi,r13
   5c0fb:	mov    r8,rdx
   5c0fe:	mov    rdx,rsi
   5c101:	mov    rsi,rax
   5c104:	call   5c109 <sqlite3VdbeExec+0xcc69>
   5c109:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c114:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c11f:	mov    rdi,QWORD PTR [rsp+0x190]
   5c127:	test   rbx,rbx
   5c12a:	je     5c216 <sqlite3VdbeExec+0xcd76>
   5c130:	mov    rax,QWORD PTR [rbx+0x70]
   5c134:	movzx  ecx,WORD PTR [rax+0x34]
   5c138:	and    ecx,0x20
   5c13b:	test   ecx,ecx
   5c13d:	je     5c1d2 <sqlite3VdbeExec+0xcd32>
   5c143:	mov    rcx,QWORD PTR [rax+0x28]
   5c147:	mov    edx,DWORD PTR [rcx+0x98]
   5c14d:	sub    edx,0x1
   5c150:	mov    DWORD PTR [rcx+0x98],edx
   5c156:	mov    rdx,QWORD PTR [rcx+0xa8]
   5c15d:	mov    QWORD PTR [rax+0x20],rdx
   5c161:	mov    QWORD PTR [rcx+0xa8],rax
   5c168:	mov    rdx,QWORD PTR [rcx+0x48]
   5c16c:	mov    esi,DWORD PTR [rax+0x30]
   5c16f:	sub    esi,0x1
   5c172:	imul   rsi,QWORD PTR [rcx+0xc8]
   5c17a:	mov    rax,QWORD PTR [rax+0x8]
   5c17e:	mov    rcx,QWORD PTR [rdx]
   5c181:	mov    rcx,QWORD PTR [rcx+0x90]
   5c188:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c193:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c19e:	mov    QWORD PTR [rsp+0x190],rdi
   5c1a6:	mov    rdi,rdx
   5c1a9:	mov    rdx,rax
   5c1ac:	mov    r10,rcx
   5c1af:	call   r10
   5c1b2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c1bd:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c1c8:	mov    rdi,QWORD PTR [rsp+0x190]
   5c1d0:	jmp    5c216 <sqlite3VdbeExec+0xcd76>
   5c1d2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c1dd:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c1e8:	mov    QWORD PTR [rsp+0x190],rdi
   5c1f0:	mov    rdi,rax
   5c1f3:	call   5c1f8 <sqlite3VdbeExec+0xcd58>
   5c1f8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c203:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c20e:	mov    rdi,QWORD PTR [rsp+0x190]
   5c216:	lea    rbx,[rsp+0x220]
   5c21e:	mov    rbx,QWORD PTR [rbx]
   5c221:	test   rbx,rbx
   5c224:	jne    5c233 <sqlite3VdbeExec+0xcd93>
   5c226:	lea    r8,[rsp+0x404]
   5c22e:	jmp    5c2c2 <sqlite3VdbeExec+0xce22>
   5c233:	mov    rbp,QWORD PTR [rbx+0x50]
   5c237:	mov    BYTE PTR [rbp+0x0],0x0
   5c23b:	mov    BYTE PTR [rbp+0x1],0x0
   5c23f:	mov    BYTE PTR [rbp+0x2],0x0
   5c243:	mov    BYTE PTR [rbp+0x3],0x0
   5c247:	lea    r12,[rbp+0x4]
   5c24b:	mov    eax,DWORD PTR [r13+0x38]
   5c24f:	sub    eax,0x4
   5c252:	mov    QWORD PTR [rsp+0x1e8],r14
   5c25a:	mov    r14d,DWORD PTR [rsp+0x41c]
   5c262:	cmp    eax,r14d
   5c265:	jae    5c284 <sqlite3VdbeExec+0xcde4>
   5c267:	mov    eax,DWORD PTR [r13+0x38]
   5c26b:	mov    DWORD PTR [rsp+0x418],r15d
   5c273:	mov    r15d,eax
   5c276:	sub    r15d,0x4
   5c27a:	lea    r8,[rsp+0x404]
   5c282:	jmp    5c297 <sqlite3VdbeExec+0xcdf7>
   5c284:	mov    DWORD PTR [rsp+0x418],r15d
   5c28c:	mov    r15,r14
   5c28f:	lea    r8,[rsp+0x404]
   5c297:	mov    DWORD PTR [rsp+0x41c],r14d
   5c29f:	mov    r14,QWORD PTR [rsp+0x1e8]
   5c2a7:	mov    QWORD PTR [rsp+0x218],r12
   5c2af:	mov    QWORD PTR [rsp+0x208],rbp
   5c2b7:	mov    rbp,r15
   5c2ba:	mov    r15d,DWORD PTR [rsp+0x418]
   5c2c2:	mov    r12d,DWORD PTR [rsp+0x41c]
   5c2ca:	test   r12d,r12d
   5c2cd:	jbe    5c300 <sqlite3VdbeExec+0xce60>
   5c2cf:	cmp    DWORD PTR [r8],0x0
   5c2d3:	jne    5c300 <sqlite3VdbeExec+0xce60>
   5c2d5:	mov    QWORD PTR [rsp+0x1e8],r14
   5c2dd:	mov    r14,r12
   5c2e0:	mov    r12,QWORD PTR [rsp+0x218]
   5c2e8:	mov    QWORD PTR [rsp+0x210],rbx
   5c2f0:	mov    rbx,r13
   5c2f3:	mov    r13,QWORD PTR [rsp+0x1f8]
   5c2fb:	jmp    5bc76 <sqlite3VdbeExec+0xc7d6>
   5c300:	test   rbx,rbx
   5c303:	je     5c3ef <sqlite3VdbeExec+0xcf4f>
   5c309:	mov    rax,QWORD PTR [rbx+0x70]
   5c30d:	movzx  ecx,WORD PTR [rax+0x34]
   5c311:	and    ecx,0x20
   5c314:	test   ecx,ecx
   5c316:	je     5c3ab <sqlite3VdbeExec+0xcf0b>
   5c31c:	mov    rcx,QWORD PTR [rax+0x28]
   5c320:	mov    edx,DWORD PTR [rcx+0x98]
   5c326:	sub    edx,0x1
   5c329:	mov    DWORD PTR [rcx+0x98],edx
   5c32f:	mov    rdx,QWORD PTR [rcx+0xa8]
   5c336:	mov    QWORD PTR [rax+0x20],rdx
   5c33a:	mov    QWORD PTR [rcx+0xa8],rax
   5c341:	mov    rdx,QWORD PTR [rcx+0x48]
   5c345:	mov    esi,DWORD PTR [rax+0x30]
   5c348:	sub    esi,0x1
   5c34b:	imul   rsi,QWORD PTR [rcx+0xc8]
   5c353:	mov    rax,QWORD PTR [rax+0x8]
   5c357:	mov    rcx,QWORD PTR [rdx]
   5c35a:	mov    rcx,QWORD PTR [rcx+0x90]
   5c361:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c36c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c377:	mov    QWORD PTR [rsp+0x190],rdi
   5c37f:	mov    rdi,rdx
   5c382:	mov    rdx,rax
   5c385:	mov    r10,rcx
   5c388:	call   r10
   5c38b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c396:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c3a1:	mov    rdi,QWORD PTR [rsp+0x190]
   5c3a9:	jmp    5c3ef <sqlite3VdbeExec+0xcf4f>
   5c3ab:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c3b6:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c3c1:	mov    QWORD PTR [rsp+0x190],rdi
   5c3c9:	mov    rdi,rax
   5c3cc:	call   5c3d1 <sqlite3VdbeExec+0xcf31>
   5c3d1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c3dc:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c3e7:	mov    rdi,QWORD PTR [rsp+0x190]
   5c3ef:	lea    r14,[rsp+0x1b8]
   5c3f7:	mov    rax,QWORD PTR [r14]
   5c3fa:	test   rax,rax
   5c3fd:	je     5c4e5 <sqlite3VdbeExec+0xd045>
   5c403:	movzx  ecx,WORD PTR [rax+0x34]
   5c407:	and    ecx,0x20
   5c40a:	test   ecx,ecx
   5c40c:	je     5c4a1 <sqlite3VdbeExec+0xd001>
   5c412:	mov    rcx,QWORD PTR [rax+0x28]
   5c416:	mov    edx,DWORD PTR [rcx+0x98]
   5c41c:	sub    edx,0x1
   5c41f:	mov    DWORD PTR [rcx+0x98],edx
   5c425:	mov    rdx,QWORD PTR [rcx+0xa8]
   5c42c:	mov    QWORD PTR [rax+0x20],rdx
   5c430:	mov    QWORD PTR [rcx+0xa8],rax
   5c437:	mov    rdx,QWORD PTR [rcx+0x48]
   5c43b:	mov    esi,DWORD PTR [rax+0x30]
   5c43e:	sub    esi,0x1
   5c441:	imul   rsi,QWORD PTR [rcx+0xc8]
   5c449:	mov    rax,QWORD PTR [rax+0x8]
   5c44d:	mov    rcx,QWORD PTR [rdx]
   5c450:	mov    rcx,QWORD PTR [rcx+0x90]
   5c457:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c462:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c46d:	mov    QWORD PTR [rsp+0x190],rdi
   5c475:	mov    rdi,rdx
   5c478:	mov    rdx,rax
   5c47b:	mov    r10,rcx
   5c47e:	call   r10
   5c481:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c48c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c497:	mov    rdi,QWORD PTR [rsp+0x190]
   5c49f:	jmp    5c4e5 <sqlite3VdbeExec+0xd045>
   5c4a1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c4ac:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c4b7:	mov    QWORD PTR [rsp+0x190],rdi
   5c4bf:	mov    rdi,rax
   5c4c2:	call   5c4c7 <sqlite3VdbeExec+0xd027>
   5c4c7:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c4d2:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c4dd:	mov    rdi,QWORD PTR [rsp+0x190]
   5c4e5:	lea    r8,[rsp+0x404]
   5c4ed:	mov    ebp,DWORD PTR [r8]
   5c4f0:	mov    r14,QWORD PTR [rsp+0x1a8]
   5c4f8:	mov    rbx,QWORD PTR [rsp+0x1c8]
   5c500:	test   ebp,ebp
   5c502:	je     5c521 <sqlite3VdbeExec+0xd081>
   5c504:	mov    QWORD PTR [rsp+0x1c8],rbx
   5c50c:	mov    r13,QWORD PTR [rsp+0x1b0]
   5c514:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5c51c:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5c521:	mov    DWORD PTR [rsp+0x40c],ebp
   5c528:	mov    rbp,rbx
   5c52b:	mov    rbx,QWORD PTR [rsp+0x1e0]
   5c533:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5c538:	mov    QWORD PTR [rsp+0x1e0],rbx
   5c540:	mov    rbx,rbp
   5c543:	mov    QWORD PTR [rsp+0x1b0],r12
   5c54b:	mov    ebp,DWORD PTR [rbx+0x8]
   5c54e:	mov    rax,QWORD PTR [rdi+0x78]
   5c552:	movsxd rcx,DWORD PTR [rbx+0x4]
   5c556:	mov    r12,QWORD PTR [rax+rcx*8]
   5c55a:	cmp    BYTE PTR [rbx+0x1],0xfb
   5c55e:	je     5c56c <sqlite3VdbeExec+0xd0cc>
   5c560:	mov    DWORD PTR [rsp+0x418],ebp
   5c567:	jmp    5c61e <sqlite3VdbeExec+0xd17e>
   5c56c:	cmp    QWORD PTR [r14+0x138],0x0
   5c574:	jne    5c582 <sqlite3VdbeExec+0xd0e2>
   5c576:	mov    DWORD PTR [rsp+0x418],ebp
   5c57d:	jmp    5c61e <sqlite3VdbeExec+0xd17e>
   5c582:	mov    rax,QWORD PTR [r14+0x20]
   5c586:	movsx  rcx,BYTE PTR [r12+0x1]
   5c58c:	shl    rcx,0x5
   5c590:	mov    r13,QWORD PTR [rax+rcx*1]
   5c594:	mov    r15,QWORD PTR [rbx+0x10]
   5c598:	movzx  eax,WORD PTR [rbx+0x2]
   5c59c:	and    eax,0x2
   5c59f:	test   eax,eax
   5c5a1:	jne    5c5ac <sqlite3VdbeExec+0xd10c>
   5c5a3:	mov    DWORD PTR [rsp+0x418],ebp
   5c5aa:	jmp    5c616 <sqlite3VdbeExec+0xd176>
   5c5ac:	cmp    BYTE PTR [r12+0x4],0x0
   5c5b2:	jne    5c5bd <sqlite3VdbeExec+0xd11d>
   5c5b4:	mov    DWORD PTR [rsp+0x418],ebp
   5c5bb:	jmp    5c616 <sqlite3VdbeExec+0xd176>
   5c5bd:	mov    DWORD PTR [rsp+0x418],ebp
   5c5c4:	mov    rbp,QWORD PTR [r12+0x28]
   5c5c9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c5d4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c5df:	mov    QWORD PTR [rsp+0x190],rdi
   5c5e7:	mov    rdi,rbp
   5c5ea:	call   5c5ef <sqlite3VdbeExec+0xd14f>
   5c5ef:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c5fa:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c605:	mov    rax,QWORD PTR [rbp+0x30]
   5c609:	mov    QWORD PTR [r12+0x48],rax
   5c60e:	mov    rdi,QWORD PTR [rsp+0x190]
   5c616:	mov    rbp,r13
   5c619:	mov    r13,r15
   5c61c:	jmp    5c623 <sqlite3VdbeExec+0xd183>
   5c61e:	xor    ebp,ebp
   5c620:	xor    r13d,r13d
   5c623:	mov    rax,QWORD PTR [r12+0x28]
   5c628:	movzx  ecx,WORD PTR [rbx+0x2]
   5c62c:	movzx  ecx,cl
   5c62f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c63a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c645:	mov    QWORD PTR [rsp+0x190],rdi
   5c64d:	mov    rdi,rax
   5c650:	mov    rsi,rcx
   5c653:	call   5c658 <sqlite3VdbeExec+0xd1b8>
   5c658:	mov    r15d,eax
   5c65b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c666:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c671:	mov    DWORD PTR [r12+0x18],0x0
   5c67a:	mov    QWORD PTR [rsp+0x1a8],r14
   5c682:	mov    r14d,DWORD PTR [rsp+0x414]
   5c68a:	add    r14d,0x1
   5c68e:	mov    DWORD PTR [r12+0x1c],0x0
   5c697:	mov    rdi,QWORD PTR [rsp+0x190]
   5c69f:	test   r15d,r15d
   5c6a2:	je     5c6cc <sqlite3VdbeExec+0xd22c>
   5c6a4:	mov    r14,QWORD PTR [rsp+0x1a8]
   5c6ac:	mov    QWORD PTR [rsp+0x1c8],rbx
   5c6b4:	mov    rbp,r15
   5c6b7:	mov    r13,QWORD PTR [rsp+0x1b0]
   5c6bf:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5c6c7:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5c6cc:	mov    DWORD PTR [rsp+0x414],r14d
   5c6d4:	mov    r14d,DWORD PTR [rsp+0x418]
   5c6dc:	mov    eax,r14d
   5c6df:	and    eax,0x1
   5c6e2:	test   eax,eax
   5c6e4:	jne    5c6f3 <sqlite3VdbeExec+0xd253>
   5c6e6:	mov    r14,QWORD PTR [rsp+0x1a8]
   5c6ee:	jmp    5c785 <sqlite3VdbeExec+0xd2e5>
   5c6f3:	mov    rax,QWORD PTR [rdi+0x38]
   5c6f7:	add    rax,0x1
   5c6fb:	mov    QWORD PTR [rdi+0x38],rax
   5c6ff:	mov    r14,QWORD PTR [rsp+0x1a8]
   5c707:	cmp    QWORD PTR [r14+0x138],0x0
   5c70f:	je     5c785 <sqlite3VdbeExec+0xd2e5>
   5c711:	test   r13,r13
   5c714:	je     5c785 <sqlite3VdbeExec+0xd2e5>
   5c716:	mov    eax,DWORD PTR [r13+0x30]
   5c71a:	and    eax,0x80
   5c71f:	test   eax,eax
   5c721:	jne    5c785 <sqlite3VdbeExec+0xd2e5>
   5c723:	mov    rax,QWORD PTR [r14+0x138]
   5c72a:	mov    rcx,QWORD PTR [r14+0x130]
   5c731:	mov    edx,0x9
   5c736:	mov    rsi,QWORD PTR [r13+0x0]
   5c73a:	mov    r8,QWORD PTR [r12+0x48]
   5c73f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c74a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c755:	mov    rdi,rcx
   5c758:	mov    rcx,rsi
   5c75b:	mov    rsi,rdx
   5c75e:	mov    rdx,rbp
   5c761:	mov    r10,rax
   5c764:	call   r10
   5c767:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c772:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c77d:	mov    rdi,QWORD PTR [rsp+0x190]
   5c785:	mov    rbp,rbx
   5c788:	mov    DWORD PTR [rsp+0x40c],r15d
   5c790:	mov    rbx,QWORD PTR [rsp+0x1e0]
   5c798:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5c79d:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5c7a5:	mov    r13,QWORD PTR [rsp+0x1d0]
   5c7ad:	mov    QWORD PTR [rsp+0x1b0],r12
   5c7b5:	mov    r12d,DWORD PTR [rsp+0x414]
   5c7bd:	mov    rax,QWORD PTR [rdi+0x38]
   5c7c1:	mov    QWORD PTR [r14+0x78],rax
   5c7c5:	mov    rcx,QWORD PTR [r14+0x80]
   5c7cc:	add    rax,rcx
   5c7cf:	mov    QWORD PTR [r14+0x80],rax
   5c7d6:	mov    QWORD PTR [rdi+0x38],0x0
   5c7de:	mov    DWORD PTR [rsp+0x3fc],r15d
   5c7e6:	mov    QWORD PTR [rsp+0x1d0],r13
   5c7ee:	mov    DWORD PTR [rsp+0x414],r12d
   5c7f6:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5c7fb:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5c803:	mov    r13,QWORD PTR [rsp+0x1d0]
   5c80b:	mov    QWORD PTR [rsp+0x1b0],r12
   5c813:	mov    r12d,DWORD PTR [rsp+0x414]
   5c81b:	mov    rax,QWORD PTR [rdi+0x78]
   5c81f:	movsxd rcx,DWORD PTR [rbp+0x4]
   5c823:	mov    rax,QWORD PTR [rax+rcx*8]
   5c827:	movsxd rcx,DWORD PTR [rbp+0xc]
   5c82b:	mov    DWORD PTR [rsp+0x414],r12d
   5c833:	imul   r12,rcx,0x38
   5c837:	mov    QWORD PTR [rsp+0x218],r12
   5c83f:	mov    r12d,DWORD PTR [rbp+0x10]
   5c843:	mov    DWORD PTR [rsp+0x418],0x0
   5c84e:	mov    DWORD PTR [rsp+0x428],r12d
   5c856:	mov    r12,QWORD PTR [rax+0x28]
   5c85a:	mov    QWORD PTR [rsp+0x210],r12
   5c862:	mov    r12,QWORD PTR [r12+0x30]
   5c867:	mov    QWORD PTR [rsp+0x1d0],r13
   5c86f:	mov    r13,QWORD PTR [rax+0x30]
   5c873:	test   r12,r12
   5c876:	jne    5c980 <sqlite3VdbeExec+0xd4e0>
   5c87c:	movzx  eax,WORD PTR [r13+0x6]
   5c881:	add    eax,0x1
   5c884:	imul   rax,rax,0x38
   5c888:	add    rax,0x28
   5c88c:	mov    rcx,QWORD PTR [r13+0x10]
   5c890:	test   rcx,rcx
   5c893:	je     5c8e1 <sqlite3VdbeExec+0xd441>
   5c895:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c8a0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c8ab:	mov    QWORD PTR [rsp+0x190],rdi
   5c8b3:	mov    rdi,rcx
   5c8b6:	mov    rsi,rax
   5c8b9:	call   5c8be <sqlite3VdbeExec+0xd41e>
   5c8be:	mov    r12,rax
   5c8c1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c8cc:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c8d7:	mov    rdi,QWORD PTR [rsp+0x190]
   5c8df:	jmp    5c928 <sqlite3VdbeExec+0xd488>
   5c8e1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c8ec:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5c8f7:	mov    QWORD PTR [rsp+0x190],rdi
   5c8ff:	mov    rdi,rax
   5c902:	call   5c907 <sqlite3VdbeExec+0xd467>
   5c907:	mov    r12,rax
   5c90a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5c915:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5c920:	mov    rdi,QWORD PTR [rsp+0x190]
   5c928:	test   r12,r12
   5c92b:	jne    5c932 <sqlite3VdbeExec+0xd492>
   5c92d:	xor    r12d,r12d
   5c930:	jmp    5c94e <sqlite3VdbeExec+0xd4ae>
   5c932:	lea    rax,[r12+0x28]
   5c937:	mov    QWORD PTR [r12+0x8],rax
   5c93c:	mov    QWORD PTR [r12],r13
   5c940:	movzx  eax,WORD PTR [r13+0x6]
   5c945:	add    eax,0x1
   5c948:	mov    WORD PTR [r12+0x1c],ax
   5c94e:	mov    r13,QWORD PTR [rsp+0x210]
   5c956:	mov    QWORD PTR [r13+0x30],r12
   5c95a:	test   r12,r12
   5c95d:	jne    5c96a <sqlite3VdbeExec+0xd4ca>
   5c95f:	mov    r12d,0x7
   5c965:	jmp    5cae8 <sqlite3VdbeExec+0xd648>
   5c96a:	mov    QWORD PTR [rsp+0x210],r13
   5c972:	mov    r13d,DWORD PTR [rsp+0x428]
   5c97a:	mov    WORD PTR [r12+0x1c],r13w
   5c980:	mov    r13,QWORD PTR [rsp+0x210]
   5c988:	cmp    BYTE PTR [r13+0x58],0x0
   5c98d:	je     5c9be <sqlite3VdbeExec+0xd51e>
   5c98f:	mov    rax,QWORD PTR [r13+0x18]
   5c993:	mov    rax,QWORD PTR [rax+0x18]
   5c997:	mov    rcx,QWORD PTR [r13+0x18]
   5c99b:	mov    rcx,QWORD PTR [rcx+0x10]
   5c99f:	movsxd rcx,DWORD PTR [rcx+0x4]
   5c9a3:	imul   rcx,rcx,0x50
   5c9a7:	mov    edx,DWORD PTR [rax+rcx*1+0x14]
   5c9ab:	lea    r13,[rsp+0x41c]
   5c9b3:	mov    DWORD PTR [r13+0x0],edx
   5c9b7:	mov    rax,QWORD PTR [rax+rcx*1+0x28]
   5c9bc:	jmp    5c9eb <sqlite3VdbeExec+0xd54b>
   5c9be:	mov    rax,QWORD PTR [r13+0x38]
   5c9c2:	mov    eax,DWORD PTR [rax]
   5c9c4:	mov    QWORD PTR [rsp+0x208],r12
   5c9cc:	lea    r12,[rsp+0x41c]
   5c9d4:	mov    DWORD PTR [r12],eax
   5c9d8:	mov    rax,QWORD PTR [r13+0x38]
   5c9dc:	add    rax,0x10
   5c9e0:	mov    r13,r12
   5c9e3:	mov    r12,QWORD PTR [rsp+0x208]
   5c9eb:	mov    ecx,DWORD PTR [r13+0x0]
   5c9ef:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5c9fa:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ca05:	mov    QWORD PTR [rsp+0x190],rdi
   5ca0d:	mov    rdi,rcx
   5ca10:	mov    rsi,rax
   5ca13:	mov    rdx,r12
   5ca16:	call   5ca1b <sqlite3VdbeExec+0xd57b>
   5ca1b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ca26:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ca31:	xor    eax,eax
   5ca33:	mov    rdi,QWORD PTR [rsp+0x190]
   5ca3b:	jmp    5ca48 <sqlite3VdbeExec+0xd5a8>
   5ca3d:	mov    DWORD PTR [rsp+0x428],r13d
   5ca45:	add    eax,0x1
   5ca48:	mov    r13d,DWORD PTR [rsp+0x428]
   5ca50:	cmp    eax,r13d
   5ca53:	jge    5ca7d <sqlite3VdbeExec+0xd5dd>
   5ca55:	mov    rcx,QWORD PTR [r12+0x8]
   5ca5a:	mov    rdx,rax
   5ca5d:	imul   rdx,rdx,0x38
   5ca61:	movzx  ecx,WORD PTR [rcx+rdx*1+0x14]
   5ca66:	and    ecx,0x1
   5ca69:	test   ecx,ecx
   5ca6b:	je     5ca3d <sqlite3VdbeExec+0xd59d>
   5ca6d:	mov    DWORD PTR [rsp+0x418],0xffffffff
   5ca78:	xor    r12d,r12d
   5ca7b:	jmp    5cae8 <sqlite3VdbeExec+0xd648>
   5ca7d:	mov    r13,QWORD PTR [rsp+0x218]
   5ca85:	mov    eax,DWORD PTR [rbx+r13*1+0x10]
   5ca8a:	mov    rcx,QWORD PTR [rbx+r13*1+0x8]
   5ca8f:	xor    edx,edx
   5ca91:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ca9c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5caa7:	mov    QWORD PTR [rsp+0x190],rdi
   5caaf:	mov    rdi,rax
   5cab2:	mov    rsi,rcx
   5cab5:	mov    rcx,rdx
   5cab8:	mov    rdx,r12
   5cabb:	call   5cac0 <sqlite3VdbeExec+0xd620>
   5cac0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5cacb:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5cad6:	mov    DWORD PTR [rsp+0x418],eax
   5cadd:	xor    r12d,r12d
   5cae0:	mov    rdi,QWORD PTR [rsp+0x190]
   5cae8:	test   r12d,r12d
   5caeb:	je     5cb0d <sqlite3VdbeExec+0xd66d>
   5caed:	mov    QWORD PTR [rsp+0x1c8],rbp
   5caf5:	mov    rbp,r12
   5caf8:	mov    r13,QWORD PTR [rsp+0x1b0]
   5cb00:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5cb08:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5cb0d:	cmp    DWORD PTR [rsp+0x418],0x0
   5cb15:	je     5cb27 <sqlite3VdbeExec+0xd687>
   5cb17:	mov    DWORD PTR [rsp+0x40c],r12d
   5cb1f:	mov    r12,r14
   5cb22:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5cb27:	mov    DWORD PTR [rsp+0x3fc],r15d
   5cb2f:	mov    DWORD PTR [rsp+0x40c],r12d
   5cb37:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5cb3c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5cb44:	mov    QWORD PTR [rsp+0x1b0],r12
   5cb4c:	movsxd rax,DWORD PTR [rbp+0x8]
   5cb50:	imul   rax,rax,0x38
   5cb54:	lea    r12,[rbx+rax*1]
   5cb58:	mov    rax,QWORD PTR [rdi+0x78]
   5cb5c:	movsxd rcx,DWORD PTR [rbp+0x4]
   5cb60:	mov    rax,QWORD PTR [rax+rcx*8]
   5cb64:	lea    r13,[rsp+0x418]
   5cb6c:	mov    rax,QWORD PTR [rax+0x28]
   5cb70:	cmp    BYTE PTR [rax+0x58],0x0
   5cb74:	je     5cb9d <sqlite3VdbeExec+0xd6fd>
   5cb76:	mov    rcx,QWORD PTR [rax+0x18]
   5cb7a:	mov    rcx,QWORD PTR [rcx+0x18]
   5cb7e:	mov    rax,QWORD PTR [rax+0x18]
   5cb82:	mov    rax,QWORD PTR [rax+0x10]
   5cb86:	movsxd rax,DWORD PTR [rax+0x4]
   5cb8a:	imul   rax,rax,0x50
   5cb8e:	mov    edx,DWORD PTR [rcx+rax*1+0x14]
   5cb92:	mov    DWORD PTR [r13+0x0],edx
   5cb96:	mov    rax,QWORD PTR [rcx+rax*1+0x28]
   5cb9b:	jmp    5cbaf <sqlite3VdbeExec+0xd70f>
   5cb9d:	mov    rcx,QWORD PTR [rax+0x38]
   5cba1:	mov    ecx,DWORD PTR [rcx]
   5cba3:	mov    DWORD PTR [r13+0x0],ecx
   5cba7:	mov    rax,QWORD PTR [rax+0x38]
   5cbab:	add    rax,0x10
   5cbaf:	mov    r13,rax
   5cbb2:	mov    DWORD PTR [rsp+0x3fc],r15d
   5cbba:	lea    r15,[rsp+0x418]
   5cbc2:	mov    eax,DWORD PTR [r15]
   5cbc5:	cmp    eax,DWORD PTR [r12+0x20]
   5cbca:	jle    5cc27 <sqlite3VdbeExec+0xd787>
   5cbcc:	xor    ecx,ecx
   5cbce:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5cbd9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5cbe4:	mov    QWORD PTR [rsp+0x190],rdi
   5cbec:	mov    rdi,r12
   5cbef:	mov    rsi,rax
   5cbf2:	mov    rdx,rcx
   5cbf5:	call   5cbfa <sqlite3VdbeExec+0xd75a>
   5cbfa:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5cc05:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5cc10:	mov    rdi,QWORD PTR [rsp+0x190]
   5cc18:	test   eax,eax
   5cc1a:	je     5cc40 <sqlite3VdbeExec+0xd7a0>
   5cc1c:	mov    r12d,0x7
   5cc22:	jmp    5ccb1 <sqlite3VdbeExec+0xd811>
   5cc27:	mov    rax,QWORD PTR [r12+0x28]
   5cc2c:	mov    QWORD PTR [r12+0x8],rax
   5cc31:	movzx  eax,WORD PTR [r12+0x14]
   5cc37:	and    eax,0x2d
   5cc3a:	mov    WORD PTR [r12+0x14],ax
   5cc40:	mov    eax,DWORD PTR [r15]
   5cc43:	mov    DWORD PTR [r12+0x10],eax
   5cc48:	movzx  eax,WORD PTR [r12+0x14]
   5cc4e:	and    eax,0xfffff240
   5cc53:	or     eax,0x10
   5cc56:	mov    WORD PTR [r12+0x14],ax
   5cc5c:	mov    rax,QWORD PTR [r12+0x8]
   5cc61:	movsxd rcx,DWORD PTR [r15]
   5cc64:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5cc6f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5cc7a:	mov    QWORD PTR [rsp+0x190],rdi
   5cc82:	mov    rdi,rax
   5cc85:	mov    rsi,r13
   5cc88:	mov    rdx,rcx
   5cc8b:	call   5cc90 <sqlite3VdbeExec+0xd7f0>
   5cc90:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5cc9b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5cca6:	xor    r12d,r12d
   5cca9:	mov    rdi,QWORD PTR [rsp+0x190]
   5ccb1:	test   r12d,r12d
   5ccb4:	je     5ccd6 <sqlite3VdbeExec+0xd836>
   5ccb6:	mov    QWORD PTR [rsp+0x1c8],rbp
   5ccbe:	mov    rbp,r12
   5ccc1:	mov    r13,QWORD PTR [rsp+0x1b0]
   5ccc9:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5ccd1:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5ccd6:	mov    rax,QWORD PTR [rdi+0x78]
   5ccda:	movsxd rcx,DWORD PTR [rbp+0xc]
   5ccde:	mov    rax,QWORD PTR [rax+rcx*8]
   5cce2:	mov    DWORD PTR [rax+0x18],0x0
   5cce9:	mov    DWORD PTR [rsp+0x40c],r12d
   5ccf1:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5ccf6:	mov    QWORD PTR [rsp+0x1b0],r12
   5ccfe:	mov    rax,QWORD PTR [rdi+0x68]
   5cd02:	movsxd rcx,DWORD PTR [rbp+0x8]
   5cd06:	imul   rcx,rcx,0x38
   5cd0a:	lea    r12,[rax+rcx*1]
   5cd0e:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5cd13:	and    eax,0x9000
   5cd18:	test   eax,eax
   5cd1a:	je     5cd65 <sqlite3VdbeExec+0xd8c5>
   5cd1c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5cd27:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5cd32:	mov    QWORD PTR [rsp+0x190],rdi
   5cd3a:	mov    rdi,r12
   5cd3d:	call   5cd42 <sqlite3VdbeExec+0xd8a2>
   5cd42:	mov    r12,rax
   5cd45:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5cd50:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5cd5b:	mov    rdi,QWORD PTR [rsp+0x190]
   5cd63:	jmp    5cd6d <sqlite3VdbeExec+0xd8cd>
   5cd65:	mov    WORD PTR [r12+0x14],0x4
   5cd6d:	mov    rax,QWORD PTR [rdi+0x78]
   5cd71:	movsxd rcx,DWORD PTR [rbp+0x4]
   5cd75:	mov    rax,QWORD PTR [rax+rcx*8]
   5cd79:	mov    r13,QWORD PTR [rax+0x28]
   5cd7d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5cd88:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5cd93:	mov    QWORD PTR [rsp+0x190],rdi
   5cd9b:	mov    rdi,r13
   5cd9e:	call   5cda3 <sqlite3VdbeExec+0xd903>
   5cda3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5cdae:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5cdb9:	mov    eax,DWORD PTR [r13+0x40]
   5cdbd:	mov    rdi,QWORD PTR [rsp+0x190]
   5cdc5:	cmp    eax,DWORD PTR [r14+0x88]
   5cdcc:	jbe    5cdde <sqlite3VdbeExec+0xd93e>
   5cdce:	mov    QWORD PTR [rsp+0x1c8],rbp
   5cdd6:	mov    rbp,r14
   5cdd9:	jmp    54d59 <sqlite3VdbeExec+0x58b9>
   5cdde:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5cde9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5cdf4:	mov    rdi,r13
   5cdf7:	mov    rsi,rax
   5cdfa:	mov    rdx,r12
   5cdfd:	call   5ce02 <sqlite3VdbeExec+0xd962>
   5ce02:	mov    r13d,eax
   5ce05:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ce10:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ce1b:	mov    rdi,QWORD PTR [rsp+0x190]
   5ce23:	test   r13d,r13d
   5ce26:	je     5ce48 <sqlite3VdbeExec+0xd9a8>
   5ce28:	mov    QWORD PTR [rsp+0x1c8],rbp
   5ce30:	mov    rbp,r13
   5ce33:	mov    r13,QWORD PTR [rsp+0x1b0]
   5ce3b:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5ce43:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5ce48:	cmp    DWORD PTR [rbp+0xc],0x0
   5ce4c:	jne    5cffd <sqlite3VdbeExec+0xdb5d>
   5ce52:	movzx  eax,WORD PTR [r12+0x14]
   5ce58:	and    eax,0x4000
   5ce5d:	test   eax,eax
   5ce5f:	je     5cffd <sqlite3VdbeExec+0xdb5d>
   5ce65:	movzx  eax,WORD PTR [r12+0x14]
   5ce6b:	and    eax,0x12
   5ce6e:	test   eax,eax
   5ce70:	je     5cfec <sqlite3VdbeExec+0xdb4c>
   5ce76:	movzx  eax,WORD PTR [r12+0x14]
   5ce7c:	and    eax,0x400
   5ce81:	test   eax,eax
   5ce83:	je     5cf74 <sqlite3VdbeExec+0xdad4>
   5ce89:	mov    eax,DWORD PTR [r12+0x10]
   5ce8e:	add    eax,DWORD PTR [r12]
   5ce92:	test   eax,eax
   5ce94:	jg     5ceac <sqlite3VdbeExec+0xda0c>
   5ce96:	movzx  eax,WORD PTR [r12+0x14]
   5ce9c:	and    eax,0x10
   5ce9f:	test   eax,eax
   5cea1:	je     5cf74 <sqlite3VdbeExec+0xdad4>
   5cea7:	mov    eax,0x1
   5ceac:	mov    ecx,0x1
   5ceb1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5cebc:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5cec7:	mov    QWORD PTR [rsp+0x190],rdi
   5cecf:	mov    rdi,r12
   5ced2:	mov    rsi,rax
   5ced5:	mov    rdx,rcx
   5ced8:	call   5cedd <sqlite3VdbeExec+0xda3d>
   5cedd:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5cee8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5cef3:	mov    rdi,QWORD PTR [rsp+0x190]
   5cefb:	test   eax,eax
   5cefd:	jne    5cfd4 <sqlite3VdbeExec+0xdb34>
   5cf03:	mov    rax,QWORD PTR [r12+0x8]
   5cf08:	movsxd rcx,DWORD PTR [r12+0x10]
   5cf0d:	add    rax,rcx
   5cf10:	xor    ecx,ecx
   5cf12:	movsxd rdx,DWORD PTR [r12]
   5cf16:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5cf21:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5cf2c:	mov    rdi,rax
   5cf2f:	mov    rsi,rcx
   5cf32:	call   5cf37 <sqlite3VdbeExec+0xda97>
   5cf37:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5cf42:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5cf4d:	mov    eax,DWORD PTR [r12+0x10]
   5cf52:	add    eax,DWORD PTR [r12]
   5cf56:	mov    DWORD PTR [r12+0x10],eax
   5cf5b:	movzx  eax,WORD PTR [r12+0x14]
   5cf61:	and    eax,0xfffff9ff
   5cf66:	mov    WORD PTR [r12+0x14],ax
   5cf6c:	mov    rdi,QWORD PTR [rsp+0x190]
   5cf74:	cmp    DWORD PTR [r12+0x20],0x0
   5cf7a:	je     5cf88 <sqlite3VdbeExec+0xdae8>
   5cf7c:	mov    rax,QWORD PTR [r12+0x8]
   5cf81:	cmp    rax,QWORD PTR [r12+0x28]
   5cf86:	je     5cfec <sqlite3VdbeExec+0xdb4c>
   5cf88:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5cf93:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5cf9e:	mov    QWORD PTR [rsp+0x190],rdi
   5cfa6:	mov    rdi,r12
   5cfa9:	call   5cfae <sqlite3VdbeExec+0xdb0e>
   5cfae:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5cfb9:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5cfc4:	mov    rdi,QWORD PTR [rsp+0x190]
   5cfcc:	test   eax,eax
   5cfce:	je     5cfec <sqlite3VdbeExec+0xdb4c>
   5cfd0:	test   eax,eax
   5cfd2:	je     5cffd <sqlite3VdbeExec+0xdb5d>
   5cfd4:	mov    r13,QWORD PTR [rsp+0x1d0]
   5cfdc:	mov    rbx,rbp
   5cfdf:	mov    rbp,QWORD PTR [rsp+0x1d8]
   5cfe7:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5cfec:	movzx  eax,WORD PTR [r12+0x14]
   5cff2:	and    eax,0xffffbfff
   5cff7:	mov    WORD PTR [r12+0x14],ax
   5cffd:	mov    DWORD PTR [rsp+0x40c],r13d
   5d005:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5d00a:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5d012:	mov    r13,QWORD PTR [rsp+0x1d0]
   5d01a:	mov    QWORD PTR [rsp+0x1b0],r12
   5d022:	mov    r12d,DWORD PTR [rsp+0x414]
   5d02a:	mov    rax,QWORD PTR [rdi+0x68]
   5d02e:	movsxd rcx,DWORD PTR [rbp+0x8]
   5d032:	imul   rcx,rcx,0x38
   5d036:	mov    DWORD PTR [rsp+0x414],r12d
   5d03e:	lea    r12,[rax+rcx*1]
   5d042:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   5d047:	and    eax,0x9000
   5d04c:	test   eax,eax
   5d04e:	je     5d099 <sqlite3VdbeExec+0xdbf9>
   5d050:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d05b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d066:	mov    QWORD PTR [rsp+0x190],rdi
   5d06e:	mov    rdi,r12
   5d071:	call   5d076 <sqlite3VdbeExec+0xdbd6>
   5d076:	mov    r12,rax
   5d079:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d084:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d08f:	mov    rdi,QWORD PTR [rsp+0x190]
   5d097:	jmp    5d0a1 <sqlite3VdbeExec+0xdc01>
   5d099:	mov    WORD PTR [r12+0x14],0x4
   5d0a1:	mov    rax,QWORD PTR [rdi+0x78]
   5d0a5:	movsxd rcx,DWORD PTR [rbp+0x4]
   5d0a9:	mov    QWORD PTR [rsp+0x1d0],r13
   5d0b1:	mov    r13,QWORD PTR [rax+rcx*8]
   5d0b5:	cmp    BYTE PTR [r13+0x2],0x0
   5d0ba:	je     5d0d1 <sqlite3VdbeExec+0xdc31>
   5d0bc:	mov    WORD PTR [r12+0x14],0x1
   5d0c4:	mov    DWORD PTR [rsp+0x3fc],r15d
   5d0cc:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5d0d1:	cmp    BYTE PTR [r13+0x3],0x0
   5d0d6:	je     5d0f1 <sqlite3VdbeExec+0xdc51>
   5d0d8:	mov    rax,QWORD PTR [r13+0x48]
   5d0dc:	mov    QWORD PTR [rsp+0x208],rax
   5d0e4:	mov    r13d,DWORD PTR [rsp+0x40c]
   5d0ec:	jmp    5d5bf <sqlite3VdbeExec+0xe11f>
   5d0f1:	cmp    BYTE PTR [r13+0x0],0x2
   5d0f6:	jne    5d4af <sqlite3VdbeExec+0xe00f>
   5d0fc:	mov    rax,QWORD PTR [r13+0x28]
   5d100:	mov    QWORD PTR [rsp+0x218],r12
   5d108:	mov    r12,QWORD PTR [rax]
   5d10b:	mov    rax,QWORD PTR [r12]
   5d10f:	mov    rax,QWORD PTR [rax+0x60]
   5d113:	mov    rcx,QWORD PTR [r13+0x28]
   5d117:	lea    r13,[rsp+0x208]
   5d11f:	mov    rdx,r13
   5d122:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d12d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d138:	mov    QWORD PTR [rsp+0x190],rdi
   5d140:	mov    rdi,rcx
   5d143:	mov    rsi,rdx
   5d146:	mov    r10,rax
   5d149:	call   r10
   5d14c:	mov    r13d,eax
   5d14f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d15a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d165:	mov    rdi,QWORD PTR [rsp+0x190]
   5d16d:	cmp    QWORD PTR [r12+0x10],0x0
   5d173:	jne    5d182 <sqlite3VdbeExec+0xdce2>
   5d175:	mov    DWORD PTR [rsp+0x418],r13d
   5d17d:	jmp    5d475 <sqlite3VdbeExec+0xdfd5>
   5d182:	mov    DWORD PTR [rsp+0x418],r13d
   5d18a:	mov    r13,QWORD PTR [rdi]
   5d18d:	mov    rax,QWORD PTR [rdi+0xa8]
   5d194:	test   rax,rax
   5d197:	je     5d1d8 <sqlite3VdbeExec+0xdd38>
   5d199:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d1a4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d1af:	mov    rdi,r13
   5d1b2:	mov    rsi,rax
   5d1b5:	call   5d1ba <sqlite3VdbeExec+0xdd1a>
   5d1ba:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d1c5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d1d0:	mov    rdi,QWORD PTR [rsp+0x190]
   5d1d8:	mov    QWORD PTR [rsp+0x210],r12
   5d1e0:	mov    r12,QWORD PTR [r12+0x10]
   5d1e5:	test   r12,r12
   5d1e8:	jne    5d1fd <sqlite3VdbeExec+0xdd5d>
   5d1ea:	xor    r12d,r12d
   5d1ed:	mov    r13,r12
   5d1f0:	mov    r12,QWORD PTR [rsp+0x210]
   5d1f8:	jmp    5d34e <sqlite3VdbeExec+0xdeae>
   5d1fd:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d208:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d213:	mov    QWORD PTR [rsp+0x190],rdi
   5d21b:	mov    rdi,r12
   5d21e:	call   5d223 <sqlite3VdbeExec+0xdd83>
   5d223:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d22e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d239:	mov    QWORD PTR [rsp+0x1e8],r12
   5d241:	lea    r12,[rax+0x1]
   5d245:	mov    rdi,QWORD PTR [rsp+0x190]
   5d24d:	test   r13,r13
   5d250:	je     5d296 <sqlite3VdbeExec+0xddf6>
   5d252:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d25d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d268:	mov    rdi,r13
   5d26b:	mov    rsi,r12
   5d26e:	call   5d273 <sqlite3VdbeExec+0xddd3>
   5d273:	mov    r13,rax
   5d276:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d281:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d28c:	mov    rdi,QWORD PTR [rsp+0x190]
   5d294:	jmp    5d2d5 <sqlite3VdbeExec+0xde35>
   5d296:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d2a1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d2ac:	mov    rdi,r12
   5d2af:	call   5d2b4 <sqlite3VdbeExec+0xde14>
   5d2b4:	mov    r13,rax
   5d2b7:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d2c2:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d2cd:	mov    rdi,QWORD PTR [rsp+0x190]
   5d2d5:	test   r13,r13
   5d2d8:	jne    5d2e4 <sqlite3VdbeExec+0xde44>
   5d2da:	mov    DWORD PTR [rsp+0x3fc],r15d
   5d2e2:	jmp    5d33e <sqlite3VdbeExec+0xde9e>
   5d2e4:	mov    DWORD PTR [rsp+0x3fc],r15d
   5d2ec:	mov    r15,QWORD PTR [rsp+0x1e8]
   5d2f4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d2ff:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d30a:	mov    QWORD PTR [rsp+0x190],rdi
   5d312:	mov    rdi,r13
   5d315:	mov    rsi,r15
   5d318:	mov    rdx,r12
   5d31b:	call   5d320 <sqlite3VdbeExec+0xde80>
   5d320:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d32b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d336:	mov    rdi,QWORD PTR [rsp+0x190]
   5d33e:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5d346:	mov    r12,QWORD PTR [rsp+0x210]
   5d34e:	mov    QWORD PTR [rdi+0xa8],r13
   5d355:	mov    r13,QWORD PTR [r12+0x10]
   5d35a:	test   r13,r13
   5d35d:	je     5d46c <sqlite3VdbeExec+0xdfcc>
   5d363:	cmp    DWORD PTR [rip+0x0],0x0        # 5d36a <sqlite3VdbeExec+0xdeca>
   5d36a:	je     5d420 <sqlite3VdbeExec+0xdf80>
   5d370:	mov    rax,QWORD PTR [rip+0x0]        # 5d377 <sqlite3VdbeExec+0xded7>
   5d377:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d382:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d38d:	mov    QWORD PTR [rsp+0x190],rdi
   5d395:	mov    rdi,r13
   5d398:	mov    r10,rax
   5d39b:	call   r10
   5d39e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d3a9:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d3b4:	mov    rcx,QWORD PTR [rip+0x0]        # 5d3bb <sqlite3VdbeExec+0xdf1b>
   5d3bb:	movsxd rax,eax
   5d3be:	sub    rcx,rax
   5d3c1:	mov    QWORD PTR [rip+0x0],rcx        # 5d3c8 <sqlite3VdbeExec+0xdf28>
   5d3c8:	mov    rax,QWORD PTR [rip+0x0]        # 5d3cf <sqlite3VdbeExec+0xdf2f>
   5d3cf:	sub    rax,0x1
   5d3d3:	mov    QWORD PTR [rip+0x0],rax        # 5d3da <sqlite3VdbeExec+0xdf3a>
   5d3da:	mov    rax,QWORD PTR [rip+0x0]        # 5d3e1 <sqlite3VdbeExec+0xdf41>
   5d3e1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d3ec:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d3f7:	mov    rdi,r13
   5d3fa:	mov    r10,rax
   5d3fd:	call   r10
   5d400:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d40b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d416:	mov    rdi,QWORD PTR [rsp+0x190]
   5d41e:	jmp    5d46c <sqlite3VdbeExec+0xdfcc>
   5d420:	mov    rax,QWORD PTR [rip+0x0]        # 5d427 <sqlite3VdbeExec+0xdf87>
   5d427:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d432:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d43d:	mov    QWORD PTR [rsp+0x190],rdi
   5d445:	mov    rdi,r13
   5d448:	mov    r10,rax
   5d44b:	call   r10
   5d44e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d459:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d464:	mov    rdi,QWORD PTR [rsp+0x190]
   5d46c:	mov    QWORD PTR [r12+0x10],0x0
   5d475:	mov    r13d,DWORD PTR [rsp+0x418]
   5d47d:	test   r13d,r13d
   5d480:	je     5d4a2 <sqlite3VdbeExec+0xe002>
   5d482:	mov    QWORD PTR [rsp+0x1c8],rbp
   5d48a:	mov    rbp,r13
   5d48d:	mov    r13,QWORD PTR [rsp+0x1b0]
   5d495:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5d49d:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5d4a2:	mov    r12,QWORD PTR [rsp+0x218]
   5d4aa:	jmp    5d5bf <sqlite3VdbeExec+0xe11f>
   5d4af:	mov    QWORD PTR [rsp+0x218],r12
   5d4b7:	mov    rax,QWORD PTR [r13+0x28]
   5d4bb:	xor    ecx,ecx
   5d4bd:	movzx  eax,BYTE PTR [rax]
   5d4c0:	cmp    ecx,eax
   5d4c2:	je     5d50d <sqlite3VdbeExec+0xe06d>
   5d4c4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d4cf:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d4da:	mov    QWORD PTR [rsp+0x190],rdi
   5d4e2:	mov    rdi,r13
   5d4e5:	call   5d4ea <sqlite3VdbeExec+0xe04a>
   5d4ea:	mov    r12d,eax
   5d4ed:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d4f8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d503:	mov    rdi,QWORD PTR [rsp+0x190]
   5d50b:	jmp    5d510 <sqlite3VdbeExec+0xe070>
   5d50d:	xor    r12d,r12d
   5d510:	test   r12d,r12d
   5d513:	je     5d535 <sqlite3VdbeExec+0xe095>
   5d515:	mov    QWORD PTR [rsp+0x1c8],rbp
   5d51d:	mov    rbp,r12
   5d520:	mov    r13,QWORD PTR [rsp+0x1b0]
   5d528:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5d530:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5d535:	cmp    BYTE PTR [r13+0x2],0x0
   5d53a:	je     5d560 <sqlite3VdbeExec+0xe0c0>
   5d53c:	mov    r13,QWORD PTR [rsp+0x218]
   5d544:	mov    WORD PTR [r13+0x14],0x1
   5d54b:	mov    DWORD PTR [rsp+0x3fc],r15d
   5d553:	mov    DWORD PTR [rsp+0x40c],r12d
   5d55b:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5d560:	mov    r13,QWORD PTR [r13+0x28]
   5d564:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d56f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d57a:	mov    QWORD PTR [rsp+0x190],rdi
   5d582:	mov    rdi,r13
   5d585:	call   5d58a <sqlite3VdbeExec+0xe0ea>
   5d58a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d595:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d5a0:	mov    rax,QWORD PTR [r13+0x30]
   5d5a4:	mov    QWORD PTR [rsp+0x208],rax
   5d5ac:	mov    rdi,QWORD PTR [rsp+0x190]
   5d5b4:	mov    r13,r12
   5d5b7:	mov    r12,QWORD PTR [rsp+0x218]
   5d5bf:	mov    rax,QWORD PTR [rsp+0x208]
   5d5c7:	mov    QWORD PTR [r12],rax
   5d5cb:	mov    DWORD PTR [rsp+0x3fc],r15d
   5d5d3:	mov    DWORD PTR [rsp+0x40c],r13d
   5d5db:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5d5e0:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5d5e8:	mov    r13,QWORD PTR [rsp+0x1d0]
   5d5f0:	mov    QWORD PTR [rsp+0x1b0],r12
   5d5f8:	mov    r12d,DWORD PTR [rsp+0x414]
   5d600:	mov    rax,QWORD PTR [rdi+0x78]
   5d604:	movsxd rcx,DWORD PTR [rbp+0x4]
   5d608:	mov    rax,QWORD PTR [rax+rcx*8]
   5d60c:	test   rax,rax
   5d60f:	jne    5d6a9 <sqlite3VdbeExec+0xe209>
   5d615:	mov    eax,DWORD PTR [rbp+0x4]
   5d618:	mov    ecx,0x1
   5d61d:	mov    edx,0x3
   5d622:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d62d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d638:	mov    QWORD PTR [rsp+0x190],rdi
   5d640:	mov    rsi,rax
   5d643:	mov    r11,rdx
   5d646:	mov    rdx,rcx
   5d649:	mov    rcx,r11
   5d64c:	call   5d651 <sqlite3VdbeExec+0xe1b1>
   5d651:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d65c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d667:	mov    rdi,QWORD PTR [rsp+0x190]
   5d66f:	test   rax,rax
   5d672:	jne    5d684 <sqlite3VdbeExec+0xe1e4>
   5d674:	mov    rbx,rbp
   5d677:	mov    rbp,QWORD PTR [rsp+0x1d8]
   5d67f:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   5d684:	mov    DWORD PTR [rax+0x1c],0x0
   5d68b:	mov    BYTE PTR [rax+0x4],0x1
   5d68f:	movzx  ecx,BYTE PTR [rax+0x5]
   5d693:	and    rcx,0xfffffffffffffff7
   5d697:	or     rcx,0x8
   5d69b:	mov    BYTE PTR [rax+0x5],cl
   5d69e:	lea    rcx,[rip+0x0]        # 5d6a5 <sqlite3VdbeExec+0xe205>
   5d6a5:	mov    QWORD PTR [rax+0x28],rcx
   5d6a9:	mov    BYTE PTR [rax+0x2],0x1
   5d6ad:	mov    DWORD PTR [rax+0x18],0x0
   5d6b4:	cmp    BYTE PTR [rax],0x0
   5d6b7:	je     5d6c6 <sqlite3VdbeExec+0xe226>
   5d6b9:	mov    DWORD PTR [rsp+0x414],r12d
   5d6c1:	jmp    5d807 <sqlite3VdbeExec+0xe367>
   5d6c6:	mov    DWORD PTR [rsp+0x414],r12d
   5d6ce:	mov    r12,QWORD PTR [rax+0x28]
   5d6d2:	mov    QWORD PTR [rsp+0x208],r12
   5d6da:	mov    r12,QWORD PTR [r12+0x18]
   5d6df:	test   r12,r12
   5d6e2:	je     5d7f1 <sqlite3VdbeExec+0xe351>
   5d6e8:	cmp    DWORD PTR [rip+0x0],0x0        # 5d6ef <sqlite3VdbeExec+0xe24f>
   5d6ef:	je     5d7a5 <sqlite3VdbeExec+0xe305>
   5d6f5:	mov    rax,QWORD PTR [rip+0x0]        # 5d6fc <sqlite3VdbeExec+0xe25c>
   5d6fc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d707:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d712:	mov    QWORD PTR [rsp+0x190],rdi
   5d71a:	mov    rdi,r12
   5d71d:	mov    r10,rax
   5d720:	call   r10
   5d723:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d72e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d739:	mov    rcx,QWORD PTR [rip+0x0]        # 5d740 <sqlite3VdbeExec+0xe2a0>
   5d740:	movsxd rax,eax
   5d743:	sub    rcx,rax
   5d746:	mov    QWORD PTR [rip+0x0],rcx        # 5d74d <sqlite3VdbeExec+0xe2ad>
   5d74d:	mov    rax,QWORD PTR [rip+0x0]        # 5d754 <sqlite3VdbeExec+0xe2b4>
   5d754:	sub    rax,0x1
   5d758:	mov    QWORD PTR [rip+0x0],rax        # 5d75f <sqlite3VdbeExec+0xe2bf>
   5d75f:	mov    rax,QWORD PTR [rip+0x0]        # 5d766 <sqlite3VdbeExec+0xe2c6>
   5d766:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d771:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d77c:	mov    rdi,r12
   5d77f:	mov    r10,rax
   5d782:	call   r10
   5d785:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d790:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d79b:	mov    rdi,QWORD PTR [rsp+0x190]
   5d7a3:	jmp    5d7f1 <sqlite3VdbeExec+0xe351>
   5d7a5:	mov    rax,QWORD PTR [rip+0x0]        # 5d7ac <sqlite3VdbeExec+0xe30c>
   5d7ac:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d7b7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d7c2:	mov    QWORD PTR [rsp+0x190],rdi
   5d7ca:	mov    rdi,r12
   5d7cd:	mov    r10,rax
   5d7d0:	call   r10
   5d7d3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d7de:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d7e9:	mov    rdi,QWORD PTR [rsp+0x190]
   5d7f1:	mov    r12,QWORD PTR [rsp+0x208]
   5d7f9:	mov    QWORD PTR [r12+0x18],0x0
   5d802:	mov    BYTE PTR [r12],0x1
   5d807:	mov    DWORD PTR [rsp+0x3fc],r15d
   5d80f:	mov    QWORD PTR [rsp+0x1d0],r13
   5d817:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5d81c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5d824:	mov    r13,QWORD PTR [rsp+0x1d0]
   5d82c:	mov    QWORD PTR [rsp+0x1b0],r12
   5d834:	mov    rax,QWORD PTR [rdi+0x78]
   5d838:	movsxd rcx,DWORD PTR [rbp+0x4]
   5d83c:	mov    r12,QWORD PTR [rax+rcx*8]
   5d840:	mov    rax,QWORD PTR [r12+0x28]
   5d845:	mov    DWORD PTR [rsp+0x418],0x0
   5d850:	cmp    BYTE PTR [rbp+0x0],0x8b
   5d854:	je     5d86b <sqlite3VdbeExec+0xe3cb>
   5d856:	mov    QWORD PTR [rsp+0x208],r12
   5d85e:	mov    r12,r13
   5d861:	lea    r13,[rsp+0x418]
   5d869:	jmp    5d8a3 <sqlite3VdbeExec+0xe403>
   5d86b:	mov    DWORD PTR [r12+0x1c],0xffffffff
   5d874:	cmp    BYTE PTR [rax],0x0
   5d877:	je     5d88e <sqlite3VdbeExec+0xe3ee>
   5d879:	mov    QWORD PTR [rsp+0x208],r12
   5d881:	mov    r12,r13
   5d884:	lea    r13,[rsp+0x418]
   5d88c:	jmp    5d8a3 <sqlite3VdbeExec+0xe403>
   5d88e:	mov    DWORD PTR [rsp+0x3fc],r15d
   5d896:	mov    QWORD PTR [rsp+0x1d0],r13
   5d89e:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5d8a3:	mov    rcx,r13
   5d8a6:	xor    edx,edx
   5d8a8:	movzx  esi,BYTE PTR [rax]
   5d8ab:	cmp    edx,esi
   5d8ad:	jne    5d8c5 <sqlite3VdbeExec+0xe425>
   5d8af:	movzx  edx,BYTE PTR [rax+0x1]
   5d8b3:	and    edx,0x8
   5d8b6:	test   edx,edx
   5d8b8:	je     5d8c5 <sqlite3VdbeExec+0xe425>
   5d8ba:	mov    DWORD PTR [rcx],0x0
   5d8c0:	xor    r13d,r13d
   5d8c3:	jmp    5d90f <sqlite3VdbeExec+0xe46f>
   5d8c5:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d8d0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d8db:	mov    QWORD PTR [rsp+0x190],rdi
   5d8e3:	mov    rdi,rax
   5d8e6:	mov    rsi,rcx
   5d8e9:	call   5d8ee <sqlite3VdbeExec+0xe44e>
   5d8ee:	mov    r13d,eax
   5d8f1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d8fc:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d907:	mov    rdi,QWORD PTR [rsp+0x190]
   5d90f:	mov    eax,DWORD PTR [rsp+0x418]
   5d916:	mov    QWORD PTR [rsp+0x1d0],r12
   5d91e:	mov    r12,QWORD PTR [rsp+0x208]
   5d926:	mov    BYTE PTR [r12+0x2],al
   5d92b:	mov    BYTE PTR [r12+0x3],0x0
   5d931:	mov    DWORD PTR [r12+0x18],0x0
   5d93a:	test   r13d,r13d
   5d93d:	je     5d95f <sqlite3VdbeExec+0xe4bf>
   5d93f:	mov    QWORD PTR [rsp+0x1c8],rbp
   5d947:	mov    rbp,r13
   5d94a:	mov    r13,QWORD PTR [rsp+0x1b0]
   5d952:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5d95a:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5d95f:	cmp    DWORD PTR [rbp+0x8],0x0
   5d963:	jle    5d97f <sqlite3VdbeExec+0xe4df>
   5d965:	cmp    DWORD PTR [rsp+0x418],0x0
   5d96d:	je     5d97f <sqlite3VdbeExec+0xe4df>
   5d96f:	mov    r12,r14
   5d972:	mov    DWORD PTR [rsp+0x40c],r13d
   5d97a:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5d97f:	mov    DWORD PTR [rsp+0x3fc],r15d
   5d987:	mov    DWORD PTR [rsp+0x40c],r13d
   5d98f:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5d994:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5d99c:	mov    QWORD PTR [rsp+0x1b0],r12
   5d9a4:	mov    rax,QWORD PTR [rdi+0x78]
   5d9a8:	movsxd rcx,DWORD PTR [rbp+0x4]
   5d9ac:	mov    rax,QWORD PTR [rax+rcx*8]
   5d9b0:	mov    r12,QWORD PTR [rax+0x28]
   5d9b4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5d9bf:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5d9ca:	mov    QWORD PTR [rsp+0x190],rdi
   5d9d2:	mov    rdi,r12
   5d9d5:	call   5d9da <sqlite3VdbeExec+0xe53a>
   5d9da:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5d9e5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5d9f0:	mov    rdi,QWORD PTR [rsp+0x190]
   5d9f8:	test   eax,eax
   5d9fa:	jne    5dacb <sqlite3VdbeExec+0xe62b>
   5da00:	mov    DWORD PTR [rsp+0x418],0x0
   5da0b:	xor    eax,eax
   5da0d:	jmp    5dac1 <sqlite3VdbeExec+0xe621>
   5da12:	mov    rcx,QWORD PTR [r12+0x88]
   5da1a:	cmp    BYTE PTR [rcx+0x8],0x0
   5da1e:	jne    5dac9 <sqlite3VdbeExec+0xe629>
   5da24:	mov    rax,QWORD PTR [rcx+0x50]
   5da28:	movzx  edx,WORD PTR [rcx+0x1a]
   5da2c:	mov    rsi,QWORD PTR [rcx+0x60]
   5da30:	movzx  r8d,WORD PTR [r12+0x56]
   5da36:	shl    r8d,1
   5da39:	movzx  esi,BYTE PTR [rsi+r8*1]
   5da3e:	shl    esi,0x8
   5da41:	mov    rcx,QWORD PTR [rcx+0x60]
   5da45:	movzx  r8d,WORD PTR [r12+0x56]
   5da4b:	shl    r8d,1
   5da4e:	movzx  ecx,BYTE PTR [rcx+r8*1+0x1]
   5da54:	or     esi,ecx
   5da56:	and    edx,esi
   5da58:	movzx  ecx,BYTE PTR [rax+rdx*1]
   5da5c:	shl    ecx,0x18
   5da5f:	movzx  esi,BYTE PTR [rax+rdx*1+0x1]
   5da64:	shl    esi,0x10
   5da67:	or     ecx,esi
   5da69:	movzx  esi,BYTE PTR [rax+rdx*1+0x2]
   5da6e:	shl    esi,0x8
   5da71:	or     ecx,esi
   5da73:	movzx  eax,BYTE PTR [rax+rdx*1+0x3]
   5da78:	or     ecx,eax
   5da7a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5da85:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5da90:	mov    QWORD PTR [rsp+0x190],rdi
   5da98:	mov    rdi,r12
   5da9b:	mov    rsi,rcx
   5da9e:	call   5daa3 <sqlite3VdbeExec+0xe603>
   5daa3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5daae:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5dab9:	mov    rdi,QWORD PTR [rsp+0x190]
   5dac1:	test   eax,eax
   5dac3:	je     5da12 <sqlite3VdbeExec+0xe572>
   5dac9:	jmp    5dadd <sqlite3VdbeExec+0xe63d>
   5dacb:	cmp    eax,0x10
   5dace:	jne    5dadd <sqlite3VdbeExec+0xe63d>
   5dad0:	mov    DWORD PTR [rsp+0x418],0x1
   5dadb:	xor    eax,eax
   5dadd:	mov    r13d,eax
   5dae0:	test   r13d,r13d
   5dae3:	je     5db05 <sqlite3VdbeExec+0xe665>
   5dae5:	mov    QWORD PTR [rsp+0x1c8],rbp
   5daed:	mov    rbp,r13
   5daf0:	mov    r13,QWORD PTR [rsp+0x1b0]
   5daf8:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5db00:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5db05:	cmp    DWORD PTR [rsp+0x418],0x0
   5db0d:	je     5db18 <sqlite3VdbeExec+0xe678>
   5db0f:	mov    rax,0xffffffffffffffff
   5db16:	jmp    5db8a <sqlite3VdbeExec+0xe6ea>
   5db18:	cmp    BYTE PTR [r12],0x0
   5db1d:	je     5db23 <sqlite3VdbeExec+0xe683>
   5db1f:	xor    eax,eax
   5db21:	jmp    5db73 <sqlite3VdbeExec+0xe6d3>
   5db23:	mov    rax,QWORD PTR [r12+0x88]
   5db2b:	cmp    BYTE PTR [rax+0x8],0x0
   5db2f:	jne    5db3a <sqlite3VdbeExec+0xe69a>
   5db31:	mov    rax,0xffffffffffffffff
   5db38:	jmp    5db73 <sqlite3VdbeExec+0xe6d3>
   5db3a:	mov    rax,QWORD PTR [r12+0x88]
   5db42:	movzx  eax,WORD PTR [rax+0x18]
   5db46:	xor    ecx,ecx
   5db48:	jmp    5db67 <sqlite3VdbeExec+0xe6c7>
   5db4a:	mov    rdx,rcx
   5db4d:	mov    rdx,QWORD PTR [r12+rdx*8+0x90]
   5db55:	movzx  edx,WORD PTR [rdx+0x18]
   5db59:	add    edx,0x1
   5db5c:	imul   rax,rdx
   5db60:	mov    edx,0x1
   5db65:	add    cl,dl
   5db67:	mov    edx,ecx
   5db69:	movsx  esi,BYTE PTR [r12+0x54]
   5db6f:	cmp    edx,esi
   5db71:	jl     5db4a <sqlite3VdbeExec+0xe6aa>
   5db73:	mov    ecx,0x28
   5db78:	cmp    rax,0x8
   5db7c:	jae    5dbdf <sqlite3VdbeExec+0xe73f>
   5db7e:	cmp    rax,0x2
   5db82:	jae    5dbb0 <sqlite3VdbeExec+0xe710>
   5db84:	xor    eax,eax
   5db86:	movsx  rax,ax
   5db8a:	movsxd rcx,DWORD PTR [rbp+0xc]
   5db8e:	cmp    rax,rcx
   5db91:	jl     5dbfd <sqlite3VdbeExec+0xe75d>
   5db93:	movsxd rcx,DWORD PTR [rbp+0x10]
   5db97:	cmp    rax,rcx
   5db9a:	mov    eax,0x0
   5db9f:	setle  al
   5dba2:	jmp    5dbff <sqlite3VdbeExec+0xe75f>
   5dba4:	movsx  ecx,cx
   5dba7:	sub    ecx,0xa
   5dbaa:	movzx  ecx,cx
   5dbad:	shl    rax,1
   5dbb0:	cmp    rax,0x8
   5dbb4:	jb     5dba4 <sqlite3VdbeExec+0xe704>
   5dbb6:	lea    rdx,[rip+0x0]        # 5dbbd <sqlite3VdbeExec+0xe71d>
   5dbbd:	and    rax,0x7
   5dbc1:	movsx  eax,WORD PTR [rdx+rax*2]
   5dbc5:	movsx  ecx,cx
   5dbc8:	add    eax,ecx
   5dbca:	sub    eax,0xa
   5dbcd:	movzx  eax,ax
   5dbd0:	jmp    5db86 <sqlite3VdbeExec+0xe6e6>
   5dbd2:	movsx  ecx,cx
   5dbd5:	add    ecx,0x28
   5dbd8:	movzx  ecx,cx
   5dbdb:	shr    rax,0x4
   5dbdf:	cmp    rax,0xff
   5dbe5:	ja     5dbd2 <sqlite3VdbeExec+0xe732>
   5dbe7:	jmp    5dbf5 <sqlite3VdbeExec+0xe755>
   5dbe9:	movsx  ecx,cx
   5dbec:	add    ecx,0xa
   5dbef:	movzx  ecx,cx
   5dbf2:	shr    rax,1
   5dbf5:	cmp    rax,0xf
   5dbf9:	ja     5dbe9 <sqlite3VdbeExec+0xe749>
   5dbfb:	jmp    5dbb6 <sqlite3VdbeExec+0xe716>
   5dbfd:	xor    eax,eax
   5dbff:	mov    DWORD PTR [rsp+0x418],eax
   5dc06:	cmp    DWORD PTR [rsp+0x418],0x0
   5dc0e:	je     5dc20 <sqlite3VdbeExec+0xe780>
   5dc10:	mov    r12,r14
   5dc13:	mov    DWORD PTR [rsp+0x40c],r13d
   5dc1b:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5dc20:	mov    DWORD PTR [rsp+0x3fc],r15d
   5dc28:	mov    DWORD PTR [rsp+0x40c],r13d
   5dc30:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5dc35:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5dc3d:	mov    QWORD PTR [rsp+0x1b0],r12
   5dc45:	mov    eax,DWORD PTR [rdi+0xdc]
   5dc4b:	add    eax,0x1
   5dc4e:	mov    DWORD PTR [rdi+0xdc],eax
   5dc54:	mov    rax,QWORD PTR [rdi+0x78]
   5dc58:	movsxd rcx,DWORD PTR [rbp+0x4]
   5dc5c:	mov    r12,QWORD PTR [rax+rcx*8]
   5dc60:	mov    DWORD PTR [rsp+0x418],0x1
   5dc6b:	cmp    BYTE PTR [r12],0x1
   5dc70:	jne    5ebff <sqlite3VdbeExec+0xf75f>
   5dc76:	mov    r13,QWORD PTR [r12+0x28]
   5dc7b:	cmp    BYTE PTR [r13+0x58],0x0
   5dc80:	jne    5dd17 <sqlite3VdbeExec+0xe877>
   5dc86:	cmp    QWORD PTR [r13+0x38],0x0
   5dc8b:	je     5dcf4 <sqlite3VdbeExec+0xe854>
   5dc8d:	mov    DWORD PTR [rsp+0x418],0x0
   5dc98:	lea    rax,[r13+0x60]
   5dc9c:	lea    rcx,[r13+0x38]
   5dca0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5dcab:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5dcb6:	mov    QWORD PTR [rsp+0x190],rdi
   5dcbe:	mov    rdi,rax
   5dcc1:	mov    rsi,rcx
   5dcc4:	call   5dcc9 <sqlite3VdbeExec+0xe829>
   5dcc9:	mov    r13d,eax
   5dccc:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5dcd7:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5dce2:	mov    rdi,QWORD PTR [rsp+0x190]
   5dcea:	mov    DWORD PTR [rsp+0x41c],r13d
   5dcf2:	jmp    5dd0a <sqlite3VdbeExec+0xe86a>
   5dcf4:	mov    DWORD PTR [rsp+0x418],0x1
   5dcff:	xor    r11d,r11d
   5dd02:	mov    DWORD PTR [rsp+0x41c],r11d
   5dd0a:	mov    r13d,DWORD PTR [rsp+0x41c]
   5dd12:	jmp    5ebfa <sqlite3VdbeExec+0xf75a>
   5dd17:	mov    QWORD PTR [rsp+0x208],r12
   5dd1f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5dd2a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5dd35:	mov    QWORD PTR [rsp+0x190],rdi
   5dd3d:	mov    rdi,r13
   5dd40:	call   5dd45 <sqlite3VdbeExec+0xe8a5>
   5dd45:	mov    r12d,eax
   5dd48:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5dd53:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5dd5e:	mov    rdi,QWORD PTR [rsp+0x190]
   5dd66:	test   r12d,r12d
   5dd69:	jne    5ebef <sqlite3VdbeExec+0xf74f>
   5dd6f:	lea    r12,[r13+0x60]
   5dd73:	mov    QWORD PTR [rsp+0x210],0x0
   5dd7f:	lea    r8,[rsp+0x1f8]
   5dd87:	lea    r9,[rsp+0x220]
   5dd8f:	mov    DWORD PTR [rsp+0x3fc],r15d
   5dd97:	mov    QWORD PTR [rsp+0x218],r13
   5dd9f:	mov    QWORD PTR [rsp+0x1e8],r12
   5dda7:	xor    r15d,r15d
   5ddaa:	xor    r12d,r12d
   5ddad:	xor    r13d,r13d
   5ddb0:	jmp    5ea24 <sqlite3VdbeExec+0xf584>
   5ddb5:	shl    rcx,0x4
   5ddb9:	add    eax,0x1
   5ddbc:	mov    rsi,rdx
   5ddbf:	cmp    rcx,rsi
   5ddc2:	jl     5ddb5 <sqlite3VdbeExec+0xe915>
   5ddc4:	mov    QWORD PTR [rsp+0x218],r13
   5ddcc:	mov    r13d,eax
   5ddcf:	mov    QWORD PTR [r9],0x0
   5ddd6:	cmp    DWORD PTR [r12+0xc],0x10
   5dddc:	jg     5de69 <sqlite3VdbeExec+0xe9c9>
   5dde2:	mov    eax,DWORD PTR [r12+0xc]
   5dde7:	mov    rcx,r9
   5ddea:	mov    rdx,r8
   5dded:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ddf8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5de03:	mov    QWORD PTR [rsp+0x190],rdi
   5de0b:	mov    rdi,r12
   5de0e:	mov    rsi,rax
   5de11:	mov    r11,rdx
   5de14:	mov    rdx,rcx
   5de17:	mov    rcx,r11
   5de1a:	call   5de1f <sqlite3VdbeExec+0xe97f>
   5de1f:	mov    r12d,eax
   5de22:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5de2d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5de38:	mov    rdi,QWORD PTR [rsp+0x190]
   5de40:	lea    r8,[rsp+0x1f8]
   5de48:	lea    r9,[rsp+0x220]
   5de50:	test   r12d,r12d
   5de53:	jne    5e9b1 <sqlite3VdbeExec+0xf511>
   5de59:	mov    r13,QWORD PTR [r8]
   5de5c:	mov    QWORD PTR [rsp+0x200],r13
   5de64:	jmp    5ea08 <sqlite3VdbeExec+0xf568>
   5de69:	mov    DWORD PTR [rsp+0x420],r13d
   5de71:	mov    r13,rbx
   5de74:	mov    ebx,0x2
   5de79:	jmp    5de7d <sqlite3VdbeExec+0xe9dd>
   5de7b:	add    ebx,ebx
   5de7d:	cmp    ebx,0x10
   5de80:	jl     5de7b <sqlite3VdbeExec+0xe9db>
   5de82:	mov    rax,rbx
   5de85:	imul   rax,rax,0x54
   5de89:	mov    DWORD PTR [rsp+0x42c],ebx
   5de90:	lea    rbx,[rax+0x20]
   5de94:	mov    eax,0x64
   5de99:	mov    rcx,QWORD PTR [rip+0x0]        # 5dea0 <sqlite3VdbeExec+0xea00>
   5dea0:	test   rcx,rcx
   5dea3:	je     5df0c <sqlite3VdbeExec+0xea6c>
   5dea5:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5deb0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5debb:	mov    QWORD PTR [rsp+0x190],rdi
   5dec3:	mov    rdi,rax
   5dec6:	mov    r10,rcx
   5dec9:	call   r10
   5decc:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ded7:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5dee2:	mov    rdi,QWORD PTR [rsp+0x190]
   5deea:	test   eax,eax
   5deec:	je     5df0c <sqlite3VdbeExec+0xea6c>
   5deee:	xor    eax,eax
   5def0:	mov    ebx,DWORD PTR [rsp+0x42c]
   5def7:	lea    r8,[rsp+0x1f8]
   5deff:	lea    r9,[rsp+0x220]
   5df07:	jmp    5dfc3 <sqlite3VdbeExec+0xeb23>
   5df0c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5df17:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5df22:	mov    QWORD PTR [rsp+0x190],rdi
   5df2a:	mov    rdi,rbx
   5df2d:	call   5df32 <sqlite3VdbeExec+0xea92>
   5df32:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5df3d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5df48:	mov    rdi,QWORD PTR [rsp+0x190]
   5df50:	test   rax,rax
   5df53:	je     5dfac <sqlite3VdbeExec+0xeb0c>
   5df55:	xor    ecx,ecx
   5df57:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5df62:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5df6d:	mov    QWORD PTR [rsp+0x188],rax
   5df75:	mov    rdi,rax
   5df78:	mov    rsi,rcx
   5df7b:	mov    rdx,rbx
   5df7e:	call   5df83 <sqlite3VdbeExec+0xeae3>
   5df83:	mov    rcx,rax
   5df86:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5df91:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5df9c:	mov    rax,QWORD PTR [rsp+0x188]
   5dfa4:	mov    rdi,QWORD PTR [rsp+0x190]
   5dfac:	mov    ebx,DWORD PTR [rsp+0x42c]
   5dfb3:	lea    r8,[rsp+0x1f8]
   5dfbb:	lea    r9,[rsp+0x220]
   5dfc3:	test   rax,rax
   5dfc6:	je     5dfec <sqlite3VdbeExec+0xeb4c>
   5dfc8:	mov    DWORD PTR [rax],ebx
   5dfca:	mov    QWORD PTR [rax+0x8],0x0
   5dfd2:	lea    rcx,[rax+0x20]
   5dfd6:	mov    QWORD PTR [rax+0x18],rcx
   5dfda:	mov    rcx,QWORD PTR [rax+0x18]
   5dfde:	mov    rdx,rbx
   5dfe1:	imul   rdx,rdx,0x50
   5dfe5:	add    rcx,rdx
   5dfe8:	mov    QWORD PTR [rax+0x10],rcx
   5dfec:	mov    QWORD PTR [r8],rax
   5dfef:	mov    eax,0x7
   5dff4:	mov    ebx,DWORD PTR [rsp+0x41c]
   5dffb:	cmp    QWORD PTR [r8],0x0
   5dfff:	cmove  ebx,eax
   5e002:	mov    DWORD PTR [rsp+0x3fc],r15d
   5e00a:	mov    r15,r13
   5e00d:	mov    r13,rbx
   5e010:	xor    ebx,ebx
   5e012:	xor    r11d,r11d
   5e015:	mov    DWORD PTR [rsp+0x42c],r11d
   5e01d:	jmp    5e93a <sqlite3VdbeExec+0xf49a>
   5e022:	mov    DWORD PTR [rsp+0x424],ebx
   5e029:	mov    ebx,DWORD PTR [rsp+0x42c]
   5e030:	mov    r13,r15
   5e033:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5e03b:	mov    eax,0x10
   5e040:	mov    rcx,r9
   5e043:	mov    DWORD PTR [rsp+0x3fc],r15d
   5e04b:	lea    r15,[rsp+0x228]
   5e053:	mov    rdx,r15
   5e056:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e061:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e06c:	mov    QWORD PTR [rsp+0x190],rdi
   5e074:	mov    rdi,r12
   5e077:	mov    rsi,rax
   5e07a:	mov    r11,rdx
   5e07d:	mov    rdx,rcx
   5e080:	mov    rcx,r11
   5e083:	call   5e088 <sqlite3VdbeExec+0xebe8>
   5e088:	mov    r15d,eax
   5e08b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e096:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e0a1:	mov    rdi,QWORD PTR [rsp+0x190]
   5e0a9:	test   r15d,r15d
   5e0ac:	je     5e0c3 <sqlite3VdbeExec+0xec23>
   5e0ae:	lea    r8,[rsp+0x1f8]
   5e0b6:	lea    r9,[rsp+0x220]
   5e0be:	jmp    5e920 <sqlite3VdbeExec+0xf480>
   5e0c3:	lea    r15d,[rbx+0x1]
   5e0c7:	lea    r8,[rsp+0x1f8]
   5e0cf:	mov    DWORD PTR [rsp+0x430],r15d
   5e0d7:	mov    r15,QWORD PTR [r8]
   5e0da:	mov    QWORD PTR [rsp+0x230],r15
   5e0e2:	lea    r15,[rsp+0x228]
   5e0ea:	mov    r15,QWORD PTR [r15]
   5e0ed:	mov    eax,0x64
   5e0f2:	mov    rcx,QWORD PTR [rip+0x0]        # 5e0f9 <sqlite3VdbeExec+0xec59>
   5e0f9:	test   rcx,rcx
   5e0fc:	je     5e156 <sqlite3VdbeExec+0xecb6>
   5e0fe:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e109:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e114:	mov    rdi,rax
   5e117:	mov    r10,rcx
   5e11a:	call   r10
   5e11d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e128:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e133:	mov    rdi,QWORD PTR [rsp+0x190]
   5e13b:	test   eax,eax
   5e13d:	je     5e156 <sqlite3VdbeExec+0xecb6>
   5e13f:	xor    eax,eax
   5e141:	lea    r8,[rsp+0x1f8]
   5e149:	lea    r9,[rsp+0x220]
   5e151:	jmp    5e21c <sqlite3VdbeExec+0xed7c>
   5e156:	mov    QWORD PTR [rsp+0x238],r15
   5e15e:	mov    r15d,0x48
   5e164:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e16f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e17a:	mov    QWORD PTR [rsp+0x190],rdi
   5e182:	mov    rdi,r15
   5e185:	call   5e18a <sqlite3VdbeExec+0xecea>
   5e18a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e195:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e1a0:	mov    rdi,QWORD PTR [rsp+0x190]
   5e1a8:	test   rax,rax
   5e1ab:	je     5e204 <sqlite3VdbeExec+0xed64>
   5e1ad:	xor    ecx,ecx
   5e1af:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e1ba:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e1c5:	mov    QWORD PTR [rsp+0x188],rax
   5e1cd:	mov    rdi,rax
   5e1d0:	mov    rsi,rcx
   5e1d3:	mov    rdx,r15
   5e1d6:	call   5e1db <sqlite3VdbeExec+0xed3b>
   5e1db:	mov    rcx,rax
   5e1de:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e1e9:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e1f4:	mov    rax,QWORD PTR [rsp+0x188]
   5e1fc:	mov    rdi,QWORD PTR [rsp+0x190]
   5e204:	mov    r15,QWORD PTR [rsp+0x238]
   5e20c:	lea    r8,[rsp+0x1f8]
   5e214:	lea    r9,[rsp+0x220]
   5e21c:	mov    DWORD PTR [rsp+0x42c],ebx
   5e223:	lea    rbx,[rsp+0x240]
   5e22b:	mov    QWORD PTR [rbx],rax
   5e22e:	test   rax,rax
   5e231:	je     5e297 <sqlite3VdbeExec+0xedf7>
   5e233:	mov    QWORD PTR [rax+0x8],r15
   5e237:	mov    QWORD PTR [rax],r12
   5e23a:	mov    rcx,QWORD PTR [r12+0x10]
   5e23f:	mov    ecx,DWORD PTR [rcx+0x8]
   5e242:	add    ecx,0x9
   5e245:	mov    rdx,QWORD PTR [r12+0x10]
   5e24a:	mov    edx,DWORD PTR [rdx+0x4]
   5e24d:	mov    esi,edx
   5e24f:	sar    esi,0x1f
   5e252:	and    esi,0x1
   5e255:	add    edx,esi
   5e257:	sar    edx,1
   5e259:	cmp    ecx,edx
   5e25b:	jle    5e26a <sqlite3VdbeExec+0xedca>
   5e25d:	mov    rcx,QWORD PTR [r12+0x10]
   5e262:	mov    ecx,DWORD PTR [rcx+0x8]
   5e265:	add    ecx,0x9
   5e268:	jmp    5e27e <sqlite3VdbeExec+0xedde>
   5e26a:	mov    rcx,QWORD PTR [r12+0x10]
   5e26f:	mov    ecx,DWORD PTR [rcx+0x4]
   5e272:	mov    edx,ecx
   5e274:	sar    edx,0x1f
   5e277:	and    edx,0x1
   5e27a:	add    ecx,edx
   5e27c:	sar    ecx,1
   5e27e:	mov    DWORD PTR [rax+0x18],ecx
   5e281:	mov    rcx,QWORD PTR [r12+0x58]
   5e286:	movsxd rax,DWORD PTR [rax+0x18]
   5e28a:	add    rax,rcx
   5e28d:	mov    QWORD PTR [r12+0x58],rax
   5e292:	xor    r15d,r15d
   5e295:	jmp    5e2f1 <sqlite3VdbeExec+0xee51>
   5e297:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e2a2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e2ad:	mov    QWORD PTR [rsp+0x190],rdi
   5e2b5:	mov    rdi,r15
   5e2b8:	call   5e2bd <sqlite3VdbeExec+0xee1d>
   5e2bd:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e2c8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e2d3:	mov    r15d,0x7
   5e2d9:	mov    rdi,QWORD PTR [rsp+0x190]
   5e2e1:	lea    r8,[rsp+0x1f8]
   5e2e9:	lea    r9,[rsp+0x220]
   5e2f1:	mov    eax,0x1
   5e2f6:	xor    ecx,ecx
   5e2f8:	mov    ebx,DWORD PTR [rsp+0x420]
   5e2ff:	movsxd rdx,ebx
   5e302:	sub    rdx,0x1
   5e306:	cmp    ebx,0x1
   5e309:	cmovg  rcx,rdx
   5e30d:	and    rcx,0xfffffffffffffff0
   5e311:	mov    edx,ecx
   5e313:	add    edx,0x1
   5e316:	test   rcx,rcx
   5e319:	jne    5e32b <sqlite3VdbeExec+0xee8b>
   5e31b:	mov    DWORD PTR [rsp+0x434],r15d
   5e323:	mov    r15d,0x1
   5e329:	jmp    5e38c <sqlite3VdbeExec+0xeeec>
   5e32b:	vmovdqa64 zmm2,zmm1
   5e331:	vpmulld zmm2,zmm2,zmm0
   5e337:	add    eax,0x10
   5e33a:	cmp    eax,edx
   5e33c:	jl     5e331 <sqlite3VdbeExec+0xee91>
   5e33e:	vextracti64x4 ymm15,zmm2,0x1
   5e345:	{evex} vpmulld ymm2,ymm2,ymm15
   5e34b:	vextracti32x4 xmm15,ymm2,0x1
   5e352:	{evex} vpmulld xmm2,xmm2,xmm15
   5e358:	{evex} vpshufd xmm15,xmm2,0x4e
   5e35f:	{evex} vpmulld xmm2,xmm2,xmm15
   5e365:	{evex} vpshufd xmm15,xmm2,0xb1
   5e36c:	{evex} vpmulld xmm2,xmm2,xmm15
   5e372:	mov    DWORD PTR [rsp+0x434],r15d
   5e37a:	{evex} vmovd r15d,xmm2
   5e380:	mov    rax,rdx
   5e383:	jmp    5e38c <sqlite3VdbeExec+0xeeec>
   5e385:	shl    r15d,0x4
   5e389:	add    eax,0x1
   5e38c:	cmp    eax,ebx
   5e38e:	jl     5e385 <sqlite3VdbeExec+0xeee5>
   5e390:	mov    QWORD PTR [rsp+0x1a8],r14
   5e398:	mov    DWORD PTR [rsp+0x420],ebx
   5e39f:	mov    r14d,DWORD PTR [rsp+0x434]
   5e3a7:	mov    rbx,r15
   5e3aa:	mov    r15,rbp
   5e3ad:	mov    ebp,0x1
   5e3b2:	jmp    5e784 <sqlite3VdbeExec+0xf2e4>
   5e3b7:	add    ebp,ebp
   5e3b9:	cmp    ebp,0x10
   5e3bc:	jl     5e3b7 <sqlite3VdbeExec+0xef17>
   5e3be:	mov    rax,rbp
   5e3c1:	imul   rax,rax,0x54
   5e3c5:	mov    DWORD PTR [rsp+0x420],ebx
   5e3cc:	lea    rbx,[rax+0x20]
   5e3d0:	mov    eax,0x64
   5e3d5:	mov    rcx,QWORD PTR [rip+0x0]        # 5e3dc <sqlite3VdbeExec+0xef3c>
   5e3dc:	test   rcx,rcx
   5e3df:	je     5e441 <sqlite3VdbeExec+0xefa1>
   5e3e1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e3ec:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e3f7:	mov    QWORD PTR [rsp+0x190],rdi
   5e3ff:	mov    rdi,rax
   5e402:	mov    r10,rcx
   5e405:	call   r10
   5e408:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e413:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e41e:	mov    rdi,QWORD PTR [rsp+0x190]
   5e426:	test   eax,eax
   5e428:	je     5e441 <sqlite3VdbeExec+0xefa1>
   5e42a:	xor    eax,eax
   5e42c:	lea    r8,[rsp+0x1f8]
   5e434:	lea    r9,[rsp+0x220]
   5e43c:	jmp    5e4f1 <sqlite3VdbeExec+0xf051>
   5e441:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e44c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e457:	mov    QWORD PTR [rsp+0x190],rdi
   5e45f:	mov    rdi,rbx
   5e462:	call   5e467 <sqlite3VdbeExec+0xefc7>
   5e467:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e472:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e47d:	mov    rdi,QWORD PTR [rsp+0x190]
   5e485:	test   rax,rax
   5e488:	je     5e4e1 <sqlite3VdbeExec+0xf041>
   5e48a:	xor    ecx,ecx
   5e48c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e497:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e4a2:	mov    QWORD PTR [rsp+0x188],rax
   5e4aa:	mov    rdi,rax
   5e4ad:	mov    rsi,rcx
   5e4b0:	mov    rdx,rbx
   5e4b3:	call   5e4b8 <sqlite3VdbeExec+0xf018>
   5e4b8:	mov    rcx,rax
   5e4bb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e4c6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e4d1:	mov    rax,QWORD PTR [rsp+0x188]
   5e4d9:	mov    rdi,QWORD PTR [rsp+0x190]
   5e4e1:	lea    r8,[rsp+0x1f8]
   5e4e9:	lea    r9,[rsp+0x220]
   5e4f1:	test   rax,rax
   5e4f4:	je     5e51a <sqlite3VdbeExec+0xf07a>
   5e4f6:	mov    DWORD PTR [rax],ebp
   5e4f8:	mov    QWORD PTR [rax+0x8],0x0
   5e500:	lea    rcx,[rax+0x20]
   5e504:	mov    QWORD PTR [rax+0x18],rcx
   5e508:	mov    rcx,QWORD PTR [rax+0x18]
   5e50c:	mov    rdx,rbp
   5e50f:	imul   rdx,rdx,0x50
   5e513:	add    rcx,rdx
   5e516:	mov    QWORD PTR [rax+0x10],rcx
   5e51a:	mov    rbx,rax
   5e51d:	test   rbx,rbx
   5e520:	jne    5e534 <sqlite3VdbeExec+0xf094>
   5e522:	mov    ebx,0x7
   5e527:	mov    rbp,QWORD PTR [rsp+0x238]
   5e52f:	jmp    5e729 <sqlite3VdbeExec+0xf289>
   5e534:	xor    ebp,ebp
   5e536:	mov    eax,0x64
   5e53b:	mov    rcx,QWORD PTR [rip+0x0]        # 5e542 <sqlite3VdbeExec+0xf0a2>
   5e542:	test   rcx,rcx
   5e545:	je     5e5a7 <sqlite3VdbeExec+0xf107>
   5e547:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e552:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e55d:	mov    QWORD PTR [rsp+0x190],rdi
   5e565:	mov    rdi,rax
   5e568:	mov    r10,rcx
   5e56b:	call   r10
   5e56e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e579:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e584:	mov    rdi,QWORD PTR [rsp+0x190]
   5e58c:	test   eax,eax
   5e58e:	je     5e5a7 <sqlite3VdbeExec+0xf107>
   5e590:	xor    eax,eax
   5e592:	lea    r8,[rsp+0x1f8]
   5e59a:	lea    r9,[rsp+0x220]
   5e5a2:	jmp    5e65c <sqlite3VdbeExec+0xf1bc>
   5e5a7:	mov    ebp,0x48
   5e5ac:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e5b7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e5c2:	mov    QWORD PTR [rsp+0x190],rdi
   5e5ca:	mov    rdi,rbp
   5e5cd:	call   5e5d2 <sqlite3VdbeExec+0xf132>
   5e5d2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e5dd:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e5e8:	mov    rdi,QWORD PTR [rsp+0x190]
   5e5f0:	test   rax,rax
   5e5f3:	je     5e64c <sqlite3VdbeExec+0xf1ac>
   5e5f5:	xor    ecx,ecx
   5e5f7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e602:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e60d:	mov    QWORD PTR [rsp+0x188],rax
   5e615:	mov    rdi,rax
   5e618:	mov    rsi,rcx
   5e61b:	mov    rdx,rbp
   5e61e:	call   5e623 <sqlite3VdbeExec+0xf183>
   5e623:	mov    rcx,rax
   5e626:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e631:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e63c:	mov    rax,QWORD PTR [rsp+0x188]
   5e644:	mov    rdi,QWORD PTR [rsp+0x190]
   5e64c:	lea    r8,[rsp+0x1f8]
   5e654:	lea    r9,[rsp+0x220]
   5e65c:	mov    rbp,QWORD PTR [rsp+0x238]
   5e664:	mov    QWORD PTR [rbp+0x48],rax
   5e668:	test   rax,rax
   5e66b:	je     5e6d0 <sqlite3VdbeExec+0xf230>
   5e66d:	mov    QWORD PTR [rax+0x8],rbx
   5e671:	mov    QWORD PTR [rax],r12
   5e674:	mov    rcx,QWORD PTR [r12+0x10]
   5e679:	mov    ecx,DWORD PTR [rcx+0x8]
   5e67c:	add    ecx,0x9
   5e67f:	mov    rdx,QWORD PTR [r12+0x10]
   5e684:	mov    edx,DWORD PTR [rdx+0x4]
   5e687:	mov    esi,edx
   5e689:	sar    esi,0x1f
   5e68c:	and    esi,0x1
   5e68f:	add    edx,esi
   5e691:	sar    edx,1
   5e693:	cmp    ecx,edx
   5e695:	jle    5e6a4 <sqlite3VdbeExec+0xf204>
   5e697:	mov    rcx,QWORD PTR [r12+0x10]
   5e69c:	mov    ecx,DWORD PTR [rcx+0x8]
   5e69f:	add    ecx,0x9
   5e6a2:	jmp    5e6b8 <sqlite3VdbeExec+0xf218>
   5e6a4:	mov    rcx,QWORD PTR [r12+0x10]
   5e6a9:	mov    ecx,DWORD PTR [rcx+0x4]
   5e6ac:	mov    edx,ecx
   5e6ae:	sar    edx,0x1f
   5e6b1:	and    edx,0x1
   5e6b4:	add    ecx,edx
   5e6b6:	sar    ecx,1
   5e6b8:	mov    DWORD PTR [rax+0x18],ecx
   5e6bb:	mov    rcx,QWORD PTR [r12+0x58]
   5e6c0:	movsxd rax,DWORD PTR [rax+0x18]
   5e6c4:	add    rax,rcx
   5e6c7:	mov    QWORD PTR [r12+0x58],rax
   5e6cc:	xor    ebx,ebx
   5e6ce:	jmp    5e729 <sqlite3VdbeExec+0xf289>
   5e6d0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e6db:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e6e6:	mov    QWORD PTR [rsp+0x190],rdi
   5e6ee:	mov    rdi,rbx
   5e6f1:	call   5e6f6 <sqlite3VdbeExec+0xf256>
   5e6f6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e701:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e70c:	mov    ebx,0x7
   5e711:	mov    rdi,QWORD PTR [rsp+0x190]
   5e719:	lea    r8,[rsp+0x1f8]
   5e721:	lea    r9,[rsp+0x220]
   5e729:	test   ebx,ebx
   5e72b:	je     5e73d <sqlite3VdbeExec+0xf29d>
   5e72d:	mov    DWORD PTR [rsp+0x434],ebx
   5e734:	mov    ebx,DWORD PTR [rsp+0x438]
   5e73b:	jmp    5e76a <sqlite3VdbeExec+0xf2ca>
   5e73d:	mov    rax,QWORD PTR [rbp+0x48]
   5e741:	mov    rbp,QWORD PTR [rax+0x8]
   5e745:	mov    DWORD PTR [rsp+0x434],ebx
   5e74c:	mov    ebx,DWORD PTR [rsp+0x438]
   5e753:	mov    eax,ebx
   5e755:	sar    eax,0x1f
   5e758:	and    eax,0xf
   5e75b:	add    eax,ebx
   5e75d:	mov    ebx,eax
   5e75f:	sar    ebx,0x4
   5e762:	mov    QWORD PTR [rsp+0x230],rbp
   5e76a:	mov    ebp,DWORD PTR [rsp+0x43c]
   5e771:	add    ebp,0x1
   5e774:	mov    QWORD PTR [rsp+0x1a8],r14
   5e77c:	mov    r14d,DWORD PTR [rsp+0x434]
   5e784:	mov    QWORD PTR [rsp+0x1f0],r12
   5e78c:	mov    r12d,DWORD PTR [rsp+0x420]
   5e794:	cmp    ebp,r12d
   5e797:	jl     5e7ad <sqlite3VdbeExec+0xf30d>
   5e799:	mov    rbx,QWORD PTR [rsp+0x230]
   5e7a1:	mov    ebp,DWORD PTR [rsp+0x42c]
   5e7a8:	jmp    5e862 <sqlite3VdbeExec+0xf3c2>
   5e7ad:	test   r14d,r14d
   5e7b0:	je     5e7c6 <sqlite3VdbeExec+0xf326>
   5e7b2:	mov    rbx,QWORD PTR [rsp+0x230]
   5e7ba:	mov    ebp,DWORD PTR [rsp+0x42c]
   5e7c1:	jmp    5e862 <sqlite3VdbeExec+0xf3c2>
   5e7c6:	mov    DWORD PTR [rsp+0x43c],ebp
   5e7cd:	mov    ebp,DWORD PTR [rsp+0x42c]
   5e7d4:	mov    rax,rbp
   5e7d7:	cdq
   5e7d8:	idiv   ebx
   5e7da:	mov    ecx,eax
   5e7dc:	sar    ecx,0x1f
   5e7df:	and    ecx,0xf
   5e7e2:	add    ecx,eax
   5e7e4:	and    ecx,0xfffffff0
   5e7e7:	sub    eax,ecx
   5e7e9:	mov    DWORD PTR [rsp+0x438],ebx
   5e7f0:	mov    rbx,QWORD PTR [rsp+0x230]
   5e7f8:	mov    rcx,QWORD PTR [rbx+0x18]
   5e7fc:	movsxd rax,eax
   5e7ff:	imul   rax,rax,0x50
   5e803:	lea    rbx,[rcx+rax*1]
   5e807:	cmp    QWORD PTR [rcx+rax*1+0x48],0x0
   5e80d:	je     5e832 <sqlite3VdbeExec+0xf392>
   5e80f:	mov    DWORD PTR [rsp+0x420],r12d
   5e817:	mov    rbp,rbx
   5e81a:	mov    r12,QWORD PTR [rsp+0x1f0]
   5e822:	mov    rbx,r14
   5e825:	mov    r14,QWORD PTR [rsp+0x1a8]
   5e82d:	jmp    5e729 <sqlite3VdbeExec+0xf289>
   5e832:	mov    r14d,0x2
   5e838:	mov    QWORD PTR [rsp+0x238],rbx
   5e840:	mov    rbx,r12
   5e843:	mov    DWORD PTR [rsp+0x42c],ebp
   5e84a:	mov    r12,QWORD PTR [rsp+0x1f0]
   5e852:	mov    rbp,r14
   5e855:	mov    r14,QWORD PTR [rsp+0x1a8]
   5e85d:	jmp    5e3b9 <sqlite3VdbeExec+0xef19>
   5e862:	test   r14d,r14d
   5e865:	jne    5e899 <sqlite3VdbeExec+0xf3f9>
   5e867:	mov    rax,QWORD PTR [rbx+0x18]
   5e86b:	mov    ecx,ebp
   5e86d:	sar    ecx,0x1f
   5e870:	and    ecx,0xf
   5e873:	add    ecx,ebp
   5e875:	and    ecx,0xfffffff0
   5e878:	mov    r11d,ecx
   5e87b:	mov    ecx,ebp
   5e87d:	sub    ecx,r11d
   5e880:	movsxd rcx,ecx
   5e883:	imul   rcx,rcx,0x50
   5e887:	lea    rbx,[rsp+0x240]
   5e88f:	mov    rdx,QWORD PTR [rbx]
   5e892:	mov    QWORD PTR [rax+rcx*1+0x48],rdx
   5e897:	jmp    5e8e8 <sqlite3VdbeExec+0xf448>
   5e899:	lea    rbx,[rsp+0x240]
   5e8a1:	mov    rax,QWORD PTR [rbx]
   5e8a4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e8af:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e8ba:	mov    QWORD PTR [rsp+0x190],rdi
   5e8c2:	mov    rdi,rax
   5e8c5:	call   5e8ca <sqlite3VdbeExec+0xf42a>
   5e8ca:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e8d5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e8e0:	mov    rdi,QWORD PTR [rsp+0x190]
   5e8e8:	mov    ebx,r14d
   5e8eb:	mov    r14,QWORD PTR [rsp+0x1a8]
   5e8f3:	mov    DWORD PTR [rsp+0x420],r12d
   5e8fb:	mov    r12,QWORD PTR [rsp+0x1f0]
   5e903:	mov    rbp,r15
   5e906:	mov    r15,rbx
   5e909:	mov    ebx,DWORD PTR [rsp+0x430]
   5e910:	lea    r8,[rsp+0x1f8]
   5e918:	lea    r9,[rsp+0x220]
   5e920:	mov    DWORD PTR [rsp+0x42c],ebx
   5e927:	mov    ebx,DWORD PTR [rsp+0x424]
   5e92e:	add    ebx,0x10
   5e931:	mov    r11,r15
   5e934:	mov    r15,r13
   5e937:	mov    r13,r11
   5e93a:	cmp    ebx,DWORD PTR [r12+0xc]
   5e93f:	jl     5e954 <sqlite3VdbeExec+0xf4b4>
   5e941:	mov    rbx,r15
   5e944:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5e94c:	mov    r12,r13
   5e94f:	jmp    5de50 <sqlite3VdbeExec+0xe9b0>
   5e954:	test   r13d,r13d
   5e957:	je     5e96c <sqlite3VdbeExec+0xf4cc>
   5e959:	mov    rbx,r15
   5e95c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5e964:	mov    r12,r13
   5e967:	jmp    5de50 <sqlite3VdbeExec+0xe9b0>
   5e96c:	lea    r13,[rsp+0x228]
   5e974:	mov    QWORD PTR [r13+0x0],0x0
   5e97c:	mov    eax,DWORD PTR [r12+0xc]
   5e981:	sub    eax,ebx
   5e983:	cmp    eax,0x10
   5e986:	jge    5e022 <sqlite3VdbeExec+0xeb82>
   5e98c:	mov    eax,DWORD PTR [r12+0xc]
   5e991:	sub    eax,ebx
   5e993:	mov    DWORD PTR [rsp+0x424],ebx
   5e99a:	mov    ebx,DWORD PTR [rsp+0x42c]
   5e9a1:	mov    r13,r15
   5e9a4:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5e9ac:	jmp    5e040 <sqlite3VdbeExec+0xeba0>
   5e9b1:	mov    rax,QWORD PTR [r8]
   5e9b4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5e9bf:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5e9ca:	mov    QWORD PTR [rsp+0x190],rdi
   5e9d2:	mov    rdi,rax
   5e9d5:	call   5e9da <sqlite3VdbeExec+0xf53a>
   5e9da:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5e9e5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5e9f0:	mov    rdi,QWORD PTR [rsp+0x190]
   5e9f8:	lea    r8,[rsp+0x1f8]
   5ea00:	lea    r9,[rsp+0x220]
   5ea08:	mov    r13d,DWORD PTR [rsp+0x428]
   5ea10:	add    r13d,0x1
   5ea14:	mov    DWORD PTR [rsp+0x3fc],r15d
   5ea1c:	mov    r15,QWORD PTR [rsp+0x200]
   5ea24:	test   r12d,r12d
   5ea27:	je     5ea3b <sqlite3VdbeExec+0xf59b>
   5ea29:	mov    QWORD PTR [rsp+0x1e0],rbx
   5ea31:	mov    rbx,QWORD PTR [rsp+0x218]
   5ea39:	jmp    5eab6 <sqlite3VdbeExec+0xf616>
   5ea3b:	mov    QWORD PTR [rsp+0x1e0],rbx
   5ea43:	mov    rbx,QWORD PTR [rsp+0x218]
   5ea4b:	movzx  eax,BYTE PTR [rbx+0x5b]
   5ea4f:	cmp    r13d,eax
   5ea52:	jge    5eab6 <sqlite3VdbeExec+0xf616>
   5ea54:	lea    rax,[rbx+0x60]
   5ea58:	movsxd rcx,r13d
   5ea5b:	imul   rcx,rcx,0x68
   5ea5f:	mov    DWORD PTR [rsp+0x428],r13d
   5ea67:	lea    r13,[rbx+rcx*1+0x60]
   5ea6c:	mov    QWORD PTR [r8],0x0
   5ea73:	movsxd rax,DWORD PTR [rax+rcx*1+0xc]
   5ea78:	xor    ecx,ecx
   5ea7a:	mov    edx,0x10
   5ea7f:	mov    QWORD PTR [rsp+0x200],r15
   5ea87:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5ea8f:	mov    DWORD PTR [rsp+0x41c],r12d
   5ea97:	mov    r12,r13
   5ea9a:	mov    r13,rbx
   5ea9d:	mov    rbx,QWORD PTR [rsp+0x1e0]
   5eaa5:	mov    r11,rdx
   5eaa8:	mov    rdx,rax
   5eaab:	mov    rax,rcx
   5eaae:	mov    rcx,r11
   5eab1:	jmp    5ddbc <sqlite3VdbeExec+0xe91c>
   5eab6:	test   r12d,r12d
   5eab9:	je     5eb05 <sqlite3VdbeExec+0xf665>
   5eabb:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5eac6:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ead1:	mov    QWORD PTR [rsp+0x190],rdi
   5ead9:	mov    rdi,r15
   5eadc:	call   5eae1 <sqlite3VdbeExec+0xf641>
   5eae1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5eaec:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5eaf7:	xor    r13d,r13d
   5eafa:	mov    rdi,QWORD PTR [rsp+0x190]
   5eb02:	mov    r15,r13
   5eb05:	lea    r13,[rsp+0x210]
   5eb0d:	mov    QWORD PTR [r13+0x0],r15
   5eb11:	test   r12d,r12d
   5eb14:	jne    5eb81 <sqlite3VdbeExec+0xf6e1>
   5eb16:	mov    rax,QWORD PTR [r13+0x0]
   5eb1a:	xor    ecx,ecx
   5eb1c:	mov    r12,QWORD PTR [rsp+0x1e8]
   5eb24:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5eb2f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5eb3a:	mov    QWORD PTR [rsp+0x190],rdi
   5eb42:	mov    rdi,r12
   5eb45:	mov    rsi,rax
   5eb48:	mov    rdx,rcx
   5eb4b:	call   5eb50 <sqlite3VdbeExec+0xf6b0>
   5eb50:	mov    r12d,eax
   5eb53:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5eb5e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5eb69:	mov    rax,QWORD PTR [r13+0x0]
   5eb6d:	mov    QWORD PTR [rbx+0x18],rax
   5eb71:	mov    QWORD PTR [r13+0x0],0x0
   5eb79:	mov    rdi,QWORD PTR [rsp+0x190]
   5eb81:	test   r12d,r12d
   5eb84:	je     5ebce <sqlite3VdbeExec+0xf72e>
   5eb86:	mov    rax,QWORD PTR [r13+0x0]
   5eb8a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5eb95:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5eba0:	mov    QWORD PTR [rsp+0x190],rdi
   5eba8:	mov    rdi,rax
   5ebab:	call   5ebb0 <sqlite3VdbeExec+0xf710>
   5ebb0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ebbb:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ebc6:	mov    rdi,QWORD PTR [rsp+0x190]
   5ebce:	mov    ebx,r12d
   5ebd1:	mov    DWORD PTR [rsp+0x418],0x0
   5ebdc:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5ebe4:	mov    r12,rbx
   5ebe7:	mov    rbx,QWORD PTR [rsp+0x1e0]
   5ebef:	mov    r13,r12
   5ebf2:	mov    r12,QWORD PTR [rsp+0x208]
   5ebfa:	jmp    5ed3c <sqlite3VdbeExec+0xf89c>
   5ebff:	mov    r13,QWORD PTR [r12+0x28]
   5ec04:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ec0f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ec1a:	mov    QWORD PTR [rsp+0x190],rdi
   5ec22:	mov    rdi,r13
   5ec25:	call   5ec2a <sqlite3VdbeExec+0xf78a>
   5ec2a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ec35:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ec40:	mov    rdi,QWORD PTR [rsp+0x190]
   5ec48:	test   eax,eax
   5ec4a:	jne    5ed18 <sqlite3VdbeExec+0xf878>
   5ec50:	mov    DWORD PTR [rsp+0x418],0x0
   5ec5b:	xor    eax,eax
   5ec5d:	jmp    5ed0e <sqlite3VdbeExec+0xf86e>
   5ec62:	mov    rcx,QWORD PTR [r13+0x88]
   5ec69:	cmp    BYTE PTR [rcx+0x8],0x0
   5ec6d:	jne    5ed16 <sqlite3VdbeExec+0xf876>
   5ec73:	mov    rax,QWORD PTR [rcx+0x50]
   5ec77:	movzx  edx,WORD PTR [rcx+0x1a]
   5ec7b:	mov    rsi,QWORD PTR [rcx+0x60]
   5ec7f:	movzx  r8d,WORD PTR [r13+0x56]
   5ec84:	shl    r8d,1
   5ec87:	movzx  esi,BYTE PTR [rsi+r8*1]
   5ec8c:	shl    esi,0x8
   5ec8f:	mov    rcx,QWORD PTR [rcx+0x60]
   5ec93:	movzx  r8d,WORD PTR [r13+0x56]
   5ec98:	shl    r8d,1
   5ec9b:	movzx  ecx,BYTE PTR [rcx+r8*1+0x1]
   5eca1:	or     esi,ecx
   5eca3:	and    edx,esi
   5eca5:	movzx  ecx,BYTE PTR [rax+rdx*1]
   5eca9:	shl    ecx,0x18
   5ecac:	movzx  esi,BYTE PTR [rax+rdx*1+0x1]
   5ecb1:	shl    esi,0x10
   5ecb4:	or     ecx,esi
   5ecb6:	movzx  esi,BYTE PTR [rax+rdx*1+0x2]
   5ecbb:	shl    esi,0x8
   5ecbe:	or     ecx,esi
   5ecc0:	movzx  eax,BYTE PTR [rax+rdx*1+0x3]
   5ecc5:	or     ecx,eax
   5ecc7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ecd2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ecdd:	mov    QWORD PTR [rsp+0x190],rdi
   5ece5:	mov    rdi,r13
   5ece8:	mov    rsi,rcx
   5eceb:	call   5ecf0 <sqlite3VdbeExec+0xf850>
   5ecf0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ecfb:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ed06:	mov    rdi,QWORD PTR [rsp+0x190]
   5ed0e:	test   eax,eax
   5ed10:	je     5ec62 <sqlite3VdbeExec+0xf7c2>
   5ed16:	jmp    5ed2a <sqlite3VdbeExec+0xf88a>
   5ed18:	cmp    eax,0x10
   5ed1b:	jne    5ed2a <sqlite3VdbeExec+0xf88a>
   5ed1d:	mov    DWORD PTR [rsp+0x418],0x1
   5ed28:	xor    eax,eax
   5ed2a:	mov    r13d,eax
   5ed2d:	mov    BYTE PTR [r12+0x3],0x0
   5ed33:	mov    DWORD PTR [r12+0x18],0x0
   5ed3c:	test   r13d,r13d
   5ed3f:	je     5ed61 <sqlite3VdbeExec+0xf8c1>
   5ed41:	mov    QWORD PTR [rsp+0x1c8],rbp
   5ed49:	mov    rbp,r13
   5ed4c:	mov    r13,QWORD PTR [rsp+0x1b0]
   5ed54:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5ed5c:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5ed61:	mov    eax,DWORD PTR [rsp+0x418]
   5ed68:	mov    BYTE PTR [r12+0x2],al
   5ed6d:	cmp    DWORD PTR [rbp+0x8],0x0
   5ed71:	jle    5ed8d <sqlite3VdbeExec+0xf8ed>
   5ed73:	cmp    DWORD PTR [rsp+0x418],0x0
   5ed7b:	je     5ed8d <sqlite3VdbeExec+0xf8ed>
   5ed7d:	mov    r12,r14
   5ed80:	mov    DWORD PTR [rsp+0x40c],r13d
   5ed88:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5ed8d:	mov    DWORD PTR [rsp+0x3fc],r15d
   5ed95:	mov    DWORD PTR [rsp+0x40c],r13d
   5ed9d:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5eda2:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5edaa:	mov    QWORD PTR [rsp+0x1b0],r12
   5edb2:	mov    rax,QWORD PTR [rdi+0x78]
   5edb6:	movsxd rcx,DWORD PTR [rbp+0x4]
   5edba:	mov    rax,QWORD PTR [rax+rcx*8]
   5edbe:	mov    rax,QWORD PTR [rax+0x28]
   5edc2:	cmp    BYTE PTR [rax],0x0
   5edc5:	jne    5edd7 <sqlite3VdbeExec+0xf937>
   5edc7:	mov    DWORD PTR [rsp+0x418],0x0
   5edd2:	xor    r12d,r12d
   5edd5:	jmp    5ee3f <sqlite3VdbeExec+0xf99f>
   5edd7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ede2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5eded:	mov    QWORD PTR [rsp+0x190],rdi
   5edf5:	mov    rdi,rax
   5edf8:	call   5edfd <sqlite3VdbeExec+0xf95d>
   5edfd:	mov    r12d,eax
   5ee00:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ee0b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ee16:	mov    rdi,QWORD PTR [rsp+0x190]
   5ee1e:	cmp    r12d,0x10
   5ee22:	jne    5ee34 <sqlite3VdbeExec+0xf994>
   5ee24:	mov    DWORD PTR [rsp+0x418],0x1
   5ee2f:	xor    r12d,r12d
   5ee32:	jmp    5ee3f <sqlite3VdbeExec+0xf99f>
   5ee34:	mov    DWORD PTR [rsp+0x418],0x0
   5ee3f:	test   r12d,r12d
   5ee42:	je     5ee64 <sqlite3VdbeExec+0xf9c4>
   5ee44:	mov    QWORD PTR [rsp+0x1c8],rbp
   5ee4c:	mov    rbp,r12
   5ee4f:	mov    r13,QWORD PTR [rsp+0x1b0]
   5ee57:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5ee5f:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5ee64:	cmp    DWORD PTR [rsp+0x418],0x0
   5ee6c:	je     5ee7e <sqlite3VdbeExec+0xf9de>
   5ee6e:	mov    DWORD PTR [rsp+0x40c],r12d
   5ee76:	mov    r12,r14
   5ee79:	jmp    52730 <sqlite3VdbeExec+0x3290>
   5ee7e:	mov    DWORD PTR [rsp+0x3fc],r15d
   5ee86:	mov    DWORD PTR [rsp+0x40c],r12d
   5ee8e:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5ee93:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5ee9b:	mov    QWORD PTR [rsp+0x1b0],r12
   5eea3:	mov    rax,QWORD PTR [rdi+0x78]
   5eea7:	movsxd rcx,DWORD PTR [rbp+0x4]
   5eeab:	mov    r12,QWORD PTR [rax+rcx*8]
   5eeaf:	mov    r13,QWORD PTR [r12+0x28]
   5eeb4:	cmp    BYTE PTR [r13+0x58],0x0
   5eeb9:	je     5ef37 <sqlite3VdbeExec+0xfa97>
   5eebb:	mov    QWORD PTR [rsp+0x208],r12
   5eec3:	lea    r12,[rsp+0x418]
   5eecb:	mov    DWORD PTR [r12],0x0
   5eed3:	mov    rax,QWORD PTR [r13+0x18]
   5eed7:	mov    rcx,r12
   5eeda:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5eee5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5eef0:	mov    QWORD PTR [rsp+0x190],rdi
   5eef8:	mov    rdi,rax
   5eefb:	mov    rsi,rcx
   5eefe:	call   5ef03 <sqlite3VdbeExec+0xfa63>
   5ef03:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ef0e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ef19:	mov    rdi,QWORD PTR [rsp+0x190]
   5ef21:	test   eax,eax
   5ef23:	jne    5ef32 <sqlite3VdbeExec+0xfa92>
   5ef25:	mov    ecx,0x65
   5ef2a:	cmp    DWORD PTR [r12],0x0
   5ef2f:	cmovne eax,ecx
   5ef32:	jmp    5efd6 <sqlite3VdbeExec+0xfb36>
   5ef37:	mov    QWORD PTR [rsp+0x208],r12
   5ef3f:	mov    r12,QWORD PTR [r13+0x38]
   5ef43:	mov    rax,QWORD PTR [r12+0x8]
   5ef48:	mov    QWORD PTR [r13+0x38],rax
   5ef4c:	mov    QWORD PTR [r12+0x8],0x0
   5ef55:	cmp    QWORD PTR [r13+0x40],0x0
   5ef5a:	jne    5efc7 <sqlite3VdbeExec+0xfb27>
   5ef5c:	jmp    5efc2 <sqlite3VdbeExec+0xfb22>
   5ef5e:	mov    QWORD PTR [rsp+0x210],r13
   5ef66:	mov    r13,QWORD PTR [r12+0x8]
   5ef6b:	test   r12,r12
   5ef6e:	je     5efb7 <sqlite3VdbeExec+0xfb17>
   5ef70:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ef7b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ef86:	mov    QWORD PTR [rsp+0x190],rdi
   5ef8e:	mov    rdi,r14
   5ef91:	mov    rsi,r12
   5ef94:	call   5ef99 <sqlite3VdbeExec+0xfaf9>
   5ef99:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5efa4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5efaf:	mov    rdi,QWORD PTR [rsp+0x190]
   5efb7:	mov    r12,r13
   5efba:	mov    r13,QWORD PTR [rsp+0x210]
   5efc2:	test   r12,r12
   5efc5:	jne    5ef5e <sqlite3VdbeExec+0xfabe>
   5efc7:	xor    eax,eax
   5efc9:	mov    ecx,0x65
   5efce:	cmp    QWORD PTR [r13+0x38],0x0
   5efd3:	cmove  eax,ecx
   5efd6:	mov    r12d,eax
   5efd9:	mov    r13,r12
   5efdc:	mov    r12,QWORD PTR [rsp+0x208]
   5efe4:	jmp    5f0fd <sqlite3VdbeExec+0xfc5d>
   5efe9:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5eff1:	mov    QWORD PTR [rsp+0x1b0],r12
   5eff9:	mov    rax,QWORD PTR [rdi+0x78]
   5effd:	movsxd rcx,DWORD PTR [rbp+0x4]
   5f001:	mov    r12,QWORD PTR [rax+rcx*8]
   5f005:	mov    rax,QWORD PTR [r12+0x28]
   5f00a:	mov    ecx,DWORD PTR [rbp+0xc]
   5f00d:	movzx  ecx,BYTE PTR [rax+0x1]
   5f011:	and    ecx,0xfffffff1
   5f014:	mov    BYTE PTR [rax+0x1],cl
   5f017:	mov    WORD PTR [rax+0x46],0x0
   5f01d:	cmp    BYTE PTR [rax],0x0
   5f020:	jne    5f036 <sqlite3VdbeExec+0xfb96>
   5f022:	cmp    WORD PTR [rax+0x56],0x0
   5f027:	je     5f036 <sqlite3VdbeExec+0xfb96>
   5f029:	mov    rcx,QWORD PTR [rax+0x88]
   5f030:	cmp    BYTE PTR [rcx+0x8],0x0
   5f034:	jne    5f07f <sqlite3VdbeExec+0xfbdf>
   5f036:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5f041:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5f04c:	mov    QWORD PTR [rsp+0x190],rdi
   5f054:	mov    rdi,rax
   5f057:	call   5f05c <sqlite3VdbeExec+0xfbbc>
   5f05c:	mov    r13d,eax
   5f05f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5f06a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5f075:	mov    rdi,QWORD PTR [rsp+0x190]
   5f07d:	jmp    5f08d <sqlite3VdbeExec+0xfbed>
   5f07f:	movzx  ecx,WORD PTR [rax+0x56]
   5f083:	sub    ecx,0x1
   5f086:	mov    WORD PTR [rax+0x56],cx
   5f08a:	xor    r13d,r13d
   5f08d:	jmp    5f0fd <sqlite3VdbeExec+0xfc5d>
   5f08f:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5f097:	mov    QWORD PTR [rsp+0x1b0],r12
   5f09f:	mov    rax,QWORD PTR [rdi+0x78]
   5f0a3:	movsxd rcx,DWORD PTR [rbp+0x4]
   5f0a7:	mov    r12,QWORD PTR [rax+rcx*8]
   5f0ab:	mov    rax,QWORD PTR [r12+0x28]
   5f0b0:	mov    ecx,DWORD PTR [rbp+0xc]
   5f0b3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5f0be:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5f0c9:	mov    QWORD PTR [rsp+0x190],rdi
   5f0d1:	mov    rdi,rax
   5f0d4:	mov    rsi,rcx
   5f0d7:	call   5f0dc <sqlite3VdbeExec+0xfc3c>
   5f0dc:	mov    r13d,eax
   5f0df:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5f0ea:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5f0f5:	mov    rdi,QWORD PTR [rsp+0x190]
   5f0fd:	mov    DWORD PTR [r12+0x18],0x0
   5f106:	test   r13d,r13d
   5f109:	jne    5f143 <sqlite3VdbeExec+0xfca3>
   5f10b:	mov    BYTE PTR [r12+0x2],0x0
   5f111:	movzx  eax,WORD PTR [rbp+0x2]
   5f115:	mov    ecx,DWORD PTR [rdi+rax*4+0xd4]
   5f11c:	add    ecx,0x1
   5f11f:	mov    DWORD PTR [rdi+rax*4+0xd4],ecx
   5f126:	mov    r12d,DWORD PTR [rsp+0x414]
   5f12e:	mov    DWORD PTR [rsp+0x40c],r13d
   5f136:	mov    r13,QWORD PTR [rsp+0x1d0]
   5f13e:	jmp    4f80d <sqlite3VdbeExec+0x36d>
   5f143:	cmp    r13d,0x65
   5f147:	je     5f169 <sqlite3VdbeExec+0xfcc9>
   5f149:	mov    QWORD PTR [rsp+0x1c8],rbp
   5f151:	mov    rbp,r13
   5f154:	mov    r13,QWORD PTR [rsp+0x1b0]
   5f15c:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5f164:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5f169:	mov    r13,rbx
   5f16c:	mov    ebx,DWORD PTR [rsp+0x410]
   5f173:	mov    BYTE PTR [r12+0x2],0x1
   5f179:	mov    r12d,DWORD PTR [rsp+0x414]
   5f181:	mov    QWORD PTR [rsp+0x1c8],rbp
   5f189:	mov    QWORD PTR [rsp+0x1e0],r13
   5f191:	mov    r13,QWORD PTR [rsp+0x1d0]
   5f199:	xor    r11d,r11d
   5f19c:	mov    DWORD PTR [rsp+0x40c],r11d
   5f1a4:	jmp    4f836 <sqlite3VdbeExec+0x396>
   5f1a9:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5f1b1:	mov    r13,rbx
   5f1b4:	mov    ebx,DWORD PTR [rsp+0x410]
   5f1bb:	mov    QWORD PTR [rsp+0x1b0],r12
   5f1c3:	mov    rax,QWORD PTR [rdi+0x78]
   5f1c7:	movsxd rcx,DWORD PTR [rbp+0x4]
   5f1cb:	mov    r12,QWORD PTR [rax+rcx*8]
   5f1cf:	movsxd rax,DWORD PTR [rbp+0x8]
   5f1d3:	imul   rax,rax,0x38
   5f1d7:	mov    DWORD PTR [rsp+0x410],ebx
   5f1de:	lea    rbx,[r13+rax*1+0x0]
   5f1e3:	movzx  eax,WORD PTR [rbp+0x2]
   5f1e7:	and    eax,0x1
   5f1ea:	test   eax,eax
   5f1ec:	je     5f1fa <sqlite3VdbeExec+0xfd5a>
   5f1ee:	mov    rax,QWORD PTR [rdi+0x38]
   5f1f2:	add    rax,0x1
   5f1f6:	mov    QWORD PTR [rdi+0x38],rax
   5f1fa:	movzx  eax,WORD PTR [rbx+0x14]
   5f1fe:	and    eax,0x400
   5f203:	test   eax,eax
   5f205:	je     5f318 <sqlite3VdbeExec+0xfe78>
   5f20b:	mov    eax,DWORD PTR [rbx+0x10]
   5f20e:	add    eax,DWORD PTR [rbx]
   5f210:	test   eax,eax
   5f212:	jg     5f234 <sqlite3VdbeExec+0xfd94>
   5f214:	movzx  eax,WORD PTR [rbx+0x14]
   5f218:	and    eax,0x10
   5f21b:	test   eax,eax
   5f21d:	jne    5f22f <sqlite3VdbeExec+0xfd8f>
   5f21f:	xor    r11d,r11d
   5f222:	mov    DWORD PTR [rsp+0x418],r11d
   5f22a:	jmp    5f306 <sqlite3VdbeExec+0xfe66>
   5f22f:	mov    eax,0x1
   5f234:	mov    ecx,0x1
   5f239:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5f244:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5f24f:	mov    QWORD PTR [rsp+0x190],rdi
   5f257:	mov    rdi,rbx
   5f25a:	mov    rsi,rax
   5f25d:	mov    rdx,rcx
   5f260:	call   5f265 <sqlite3VdbeExec+0xfdc5>
   5f265:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5f270:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5f27b:	mov    rdi,QWORD PTR [rsp+0x190]
   5f283:	test   eax,eax
   5f285:	je     5f297 <sqlite3VdbeExec+0xfdf7>
   5f287:	mov    r11d,0x7
   5f28d:	mov    DWORD PTR [rsp+0x418],r11d
   5f295:	jmp    5f306 <sqlite3VdbeExec+0xfe66>
   5f297:	mov    rax,QWORD PTR [rbx+0x8]
   5f29b:	movsxd rcx,DWORD PTR [rbx+0x10]
   5f29f:	add    rax,rcx
   5f2a2:	xor    ecx,ecx
   5f2a4:	movsxd rdx,DWORD PTR [rbx]
   5f2a7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5f2b2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5f2bd:	mov    rdi,rax
   5f2c0:	mov    rsi,rcx
   5f2c3:	call   5f2c8 <sqlite3VdbeExec+0xfe28>
   5f2c8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5f2d3:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5f2de:	mov    eax,DWORD PTR [rbx+0x10]
   5f2e1:	add    eax,DWORD PTR [rbx]
   5f2e3:	mov    DWORD PTR [rbx+0x10],eax
   5f2e6:	movzx  eax,WORD PTR [rbx+0x14]
   5f2ea:	and    eax,0xfffff9ff
   5f2ef:	mov    WORD PTR [rbx+0x14],ax
   5f2f3:	mov    rdi,QWORD PTR [rsp+0x190]
   5f2fb:	xor    r11d,r11d
   5f2fe:	mov    DWORD PTR [rsp+0x418],r11d
   5f306:	mov    QWORD PTR [rsp+0x1a8],r14
   5f30e:	mov    r14d,DWORD PTR [rsp+0x418]
   5f316:	jmp    5f323 <sqlite3VdbeExec+0xfe83>
   5f318:	mov    QWORD PTR [rsp+0x1a8],r14
   5f320:	xor    r14d,r14d
   5f323:	test   r14d,r14d
   5f326:	je     5f350 <sqlite3VdbeExec+0xfeb0>
   5f328:	mov    QWORD PTR [rsp+0x1c8],rbp
   5f330:	mov    rbp,r14
   5f333:	mov    r14,QWORD PTR [rsp+0x1a8]
   5f33b:	mov    r13,QWORD PTR [rsp+0x1b0]
   5f343:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5f34b:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5f350:	movsxd rax,DWORD PTR [rbx+0x10]
   5f354:	mov    QWORD PTR [rsp+0x298],rax
   5f35c:	mov    rax,QWORD PTR [rbx+0x8]
   5f360:	mov    QWORD PTR [rsp+0x290],rax
   5f368:	movsxd rax,DWORD PTR [rbp+0xc]
   5f36c:	imul   rax,rax,0x38
   5f370:	add    rax,r13
   5f373:	mov    QWORD PTR [rsp+0x2a8],rax
   5f37b:	mov    eax,DWORD PTR [rbp+0x10]
   5f37e:	mov    WORD PTR [rsp+0x2b0],ax
   5f386:	mov    rax,QWORD PTR [r12+0x28]
   5f38b:	lea    rbx,[rsp+0x290]
   5f393:	mov    rcx,rbx
   5f396:	movzx  edx,WORD PTR [rbp+0x2]
   5f39a:	and    edx,0x8a
   5f3a0:	movzx  esi,WORD PTR [rbp+0x2]
   5f3a4:	and    esi,0x10
   5f3a7:	test   esi,esi
   5f3a9:	je     5f3b2 <sqlite3VdbeExec+0xff12>
   5f3ab:	mov    esi,DWORD PTR [r12+0x1c]
   5f3b0:	jmp    5f3b4 <sqlite3VdbeExec+0xff14>
   5f3b2:	xor    esi,esi
   5f3b4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5f3bf:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5f3ca:	mov    QWORD PTR [rsp+0x190],rdi
   5f3d2:	mov    rdi,rax
   5f3d5:	mov    r11,rsi
   5f3d8:	mov    rsi,rcx
   5f3db:	mov    rcx,r11
   5f3de:	call   5f3e3 <sqlite3VdbeExec+0xff43>
   5f3e3:	mov    r14d,eax
   5f3e6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5f3f1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5f3fc:	mov    DWORD PTR [r12+0x18],0x0
   5f405:	mov    rdi,QWORD PTR [rsp+0x190]
   5f40d:	test   r14d,r14d
   5f410:	je     5f43a <sqlite3VdbeExec+0xff9a>
   5f412:	mov    QWORD PTR [rsp+0x1c8],rbp
   5f41a:	mov    rbp,r14
   5f41d:	mov    r14,QWORD PTR [rsp+0x1a8]
   5f425:	mov    r13,QWORD PTR [rsp+0x1b0]
   5f42d:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5f435:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5f43a:	mov    DWORD PTR [rsp+0x3fc],r15d
   5f442:	mov    DWORD PTR [rsp+0x40c],r14d
   5f44a:	mov    r14,QWORD PTR [rsp+0x1a8]
   5f452:	mov    rbx,r13
   5f455:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5f45a:	mov    QWORD PTR [rsp+0x1a8],r14
   5f462:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5f46a:	mov    r13,rbx
   5f46d:	mov    QWORD PTR [rsp+0x1b0],r12
   5f475:	mov    rax,QWORD PTR [rdi+0x78]
   5f479:	movsxd rcx,DWORD PTR [rbp+0x4]
   5f47d:	mov    r12,QWORD PTR [rax+rcx*8]
   5f481:	movsxd rax,DWORD PTR [rbp+0x8]
   5f485:	imul   rax,rax,0x38
   5f489:	lea    r14,[r13+rax*1+0x0]
   5f48e:	movzx  eax,WORD PTR [r13+rax*1+0x14]
   5f494:	and    eax,0x400
   5f499:	test   eax,eax
   5f49b:	je     5f58b <sqlite3VdbeExec+0x100eb>
   5f4a1:	mov    eax,DWORD PTR [r14+0x10]
   5f4a5:	add    eax,DWORD PTR [r14]
   5f4a8:	test   eax,eax
   5f4aa:	jg     5f4c4 <sqlite3VdbeExec+0x10024>
   5f4ac:	movzx  eax,WORD PTR [r14+0x14]
   5f4b1:	and    eax,0x10
   5f4b4:	test   eax,eax
   5f4b6:	jne    5f4bf <sqlite3VdbeExec+0x1001f>
   5f4b8:	xor    ebx,ebx
   5f4ba:	jmp    5f589 <sqlite3VdbeExec+0x100e9>
   5f4bf:	mov    eax,0x1
   5f4c4:	mov    ecx,0x1
   5f4c9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5f4d4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5f4df:	mov    QWORD PTR [rsp+0x190],rdi
   5f4e7:	mov    rdi,r14
   5f4ea:	mov    rsi,rax
   5f4ed:	mov    rdx,rcx
   5f4f0:	call   5f4f5 <sqlite3VdbeExec+0x10055>
   5f4f5:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5f500:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5f50b:	mov    rdi,QWORD PTR [rsp+0x190]
   5f513:	test   eax,eax
   5f515:	je     5f51e <sqlite3VdbeExec+0x1007e>
   5f517:	mov    ebx,0x7
   5f51c:	jmp    5f589 <sqlite3VdbeExec+0x100e9>
   5f51e:	mov    rax,QWORD PTR [r14+0x8]
   5f522:	movsxd rcx,DWORD PTR [r14+0x10]
   5f526:	add    rax,rcx
   5f529:	xor    ecx,ecx
   5f52b:	movsxd rdx,DWORD PTR [r14]
   5f52e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5f539:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5f544:	mov    rdi,rax
   5f547:	mov    rsi,rcx
   5f54a:	call   5f54f <sqlite3VdbeExec+0x100af>
   5f54f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5f55a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5f565:	mov    eax,DWORD PTR [r14+0x10]
   5f569:	add    eax,DWORD PTR [r14]
   5f56c:	mov    DWORD PTR [r14+0x10],eax
   5f570:	movzx  eax,WORD PTR [r14+0x14]
   5f575:	and    eax,0xfffff9ff
   5f57a:	mov    WORD PTR [r14+0x14],ax
   5f57f:	xor    ebx,ebx
   5f581:	mov    rdi,QWORD PTR [rsp+0x190]
   5f589:	jmp    5f58d <sqlite3VdbeExec+0x100ed>
   5f58b:	xor    ebx,ebx
   5f58d:	test   ebx,ebx
   5f58f:	je     5f5b9 <sqlite3VdbeExec+0x10119>
   5f591:	mov    r14,QWORD PTR [rsp+0x1a8]
   5f599:	mov    QWORD PTR [rsp+0x1c8],rbp
   5f5a1:	mov    rbp,rbx
   5f5a4:	mov    r13,QWORD PTR [rsp+0x1b0]
   5f5ac:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5f5b4:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5f5b9:	xor    ebx,ebx
   5f5bb:	mov    r12,QWORD PTR [r12+0x28]
   5f5c0:	mov    rax,QWORD PTR [r14+0x8]
   5f5c4:	movzx  eax,BYTE PTR [rax+0x1]
   5f5c8:	mov    DWORD PTR [rsp+0x418],eax
   5f5cf:	cmp    DWORD PTR [rsp+0x418],0x80
   5f5da:	jge    5f5e9 <sqlite3VdbeExec+0x10149>
   5f5dc:	lea    rbx,[rsp+0x418]
   5f5e4:	jmp    5f6ea <sqlite3VdbeExec+0x1024a>
   5f5e9:	mov    rax,QWORD PTR [r14+0x8]
   5f5ed:	lea    rcx,[rax+0x1]
   5f5f1:	movzx  eax,BYTE PTR [rax+0x2]
   5f5f5:	and    eax,0x80
   5f5fa:	test   eax,eax
   5f5fc:	jne    5f61c <sqlite3VdbeExec+0x1017c>
   5f5fe:	movzx  eax,BYTE PTR [rcx]
   5f601:	and    eax,0x7f
   5f604:	shl    eax,0x7
   5f607:	movzx  ecx,BYTE PTR [rcx+0x1]
   5f60b:	or     eax,ecx
   5f60d:	lea    rbx,[rsp+0x418]
   5f615:	mov    DWORD PTR [rbx],eax
   5f617:	jmp    5f6ea <sqlite3VdbeExec+0x1024a>
   5f61c:	lea    rbx,[rsp+0x418]
   5f624:	movzx  eax,BYTE PTR [rcx+0x2]
   5f628:	and    eax,0x80
   5f62d:	test   eax,eax
   5f62f:	jne    5f653 <sqlite3VdbeExec+0x101b3>
   5f631:	movzx  eax,BYTE PTR [rcx]
   5f634:	and    eax,0x7f
   5f637:	shl    eax,0xe
   5f63a:	movzx  edx,BYTE PTR [rcx+0x1]
   5f63e:	and    edx,0x7f
   5f641:	shl    edx,0x7
   5f644:	or     eax,edx
   5f646:	movzx  ecx,BYTE PTR [rcx+0x2]
   5f64a:	or     eax,ecx
   5f64c:	mov    DWORD PTR [rbx],eax
   5f64e:	jmp    5f6ea <sqlite3VdbeExec+0x1024a>
   5f653:	mov    rbx,rbp
   5f656:	lea    rbp,[rsp+0x210]
   5f65e:	mov    rax,rbp
   5f661:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5f66c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5f677:	mov    QWORD PTR [rsp+0x190],rdi
   5f67f:	mov    rdi,rcx
   5f682:	mov    rsi,rax
   5f685:	call   5f68a <sqlite3VdbeExec+0x101ea>
   5f68a:	movzx  eax,al
   5f68d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5f698:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5f6a3:	mov    eax,0xffffffff
   5f6a8:	and    rax,QWORD PTR [rbp+0x0]
   5f6ac:	mov    rdi,QWORD PTR [rsp+0x190]
   5f6b4:	cmp    rax,QWORD PTR [rbp+0x0]
   5f6b8:	je     5f6d4 <sqlite3VdbeExec+0x10234>
   5f6ba:	lea    rbp,[rsp+0x418]
   5f6c2:	mov    DWORD PTR [rbp+0x0],0xffffffff
   5f6c9:	mov    r11,rbx
   5f6cc:	mov    rbx,rbp
   5f6cf:	mov    rbp,r11
   5f6d2:	jmp    5f6ea <sqlite3VdbeExec+0x1024a>
   5f6d4:	mov    r11,rbx
   5f6d7:	mov    rbx,rbp
   5f6da:	mov    rbp,r11
   5f6dd:	mov    rax,QWORD PTR [rbx]
   5f6e0:	lea    rbx,[rsp+0x418]
   5f6e8:	mov    DWORD PTR [rbx],eax
   5f6ea:	cmp    DWORD PTR [rbx],0x0
   5f6ed:	jle    5f709 <sqlite3VdbeExec+0x10269>
   5f6ef:	cmp    DWORD PTR [rbx],0xa
   5f6f2:	jge    5f709 <sqlite3VdbeExec+0x10269>
   5f6f4:	cmp    DWORD PTR [rbx],0x7
   5f6f7:	je     5f709 <sqlite3VdbeExec+0x10269>
   5f6f9:	movzx  eax,BYTE PTR [r12+0x5c]
   5f6ff:	and    eax,0x1
   5f702:	mov    BYTE PTR [r12+0x5c],al
   5f707:	jmp    5f72d <sqlite3VdbeExec+0x1028d>
   5f709:	cmp    DWORD PTR [rbx],0xa
   5f70c:	jle    5f727 <sqlite3VdbeExec+0x10287>
   5f70e:	mov    eax,DWORD PTR [rbx]
   5f710:	and    eax,0x1
   5f713:	test   eax,eax
   5f715:	je     5f727 <sqlite3VdbeExec+0x10287>
   5f717:	movzx  eax,BYTE PTR [r12+0x5c]
   5f71d:	and    eax,0x2
   5f720:	mov    BYTE PTR [r12+0x5c],al
   5f725:	jmp    5f72d <sqlite3VdbeExec+0x1028d>
   5f727:	mov    BYTE PTR [r12+0x5c],0x0
   5f72d:	movsxd rax,DWORD PTR [r14+0x10]
   5f731:	lea    rbx,[rax+0x10]
   5f735:	mov    eax,DWORD PTR [r14+0x10]
   5f739:	movsxd rcx,DWORD PTR [r14+0x10]
   5f73d:	mov    edx,0x1
   5f742:	mov    r11,rdx
   5f745:	mov    rdx,rcx
   5f748:	mov    rcx,r11
   5f74b:	jmp    5f750 <sqlite3VdbeExec+0x102b0>
   5f74d:	add    ecx,0x1
   5f750:	shr    rdx,0x7
   5f754:	test   rdx,rdx
   5f757:	jne    5f74d <sqlite3VdbeExec+0x102ad>
   5f759:	add    eax,ecx
   5f75b:	mov    QWORD PTR [rsp+0x208],r14
   5f763:	movsxd r14,eax
   5f766:	cmp    DWORD PTR [r12+0x4],0x0
   5f76c:	jne    5f77e <sqlite3VdbeExec+0x102de>
   5f76e:	xor    r11d,r11d
   5f771:	mov    DWORD PTR [rsp+0x41c],r11d
   5f779:	jmp    5f826 <sqlite3VdbeExec+0x10386>
   5f77e:	cmp    QWORD PTR [r12+0x40],0x0
   5f784:	je     5f8ed <sqlite3VdbeExec+0x1044d>
   5f78a:	cmp    DWORD PTR [r12+0x50],0x0
   5f790:	je     5f8dd <sqlite3VdbeExec+0x1043d>
   5f796:	movsxd rax,DWORD PTR [r12+0x50]
   5f79b:	add    rax,rbx
   5f79e:	movsxd rcx,DWORD PTR [r12+0x4]
   5f7a3:	cmp    rax,rcx
   5f7a6:	jg     5f7b5 <sqlite3VdbeExec+0x10315>
   5f7a8:	xor    r11d,r11d
   5f7ab:	mov    DWORD PTR [rsp+0x41c],r11d
   5f7b3:	jmp    5f826 <sqlite3VdbeExec+0x10386>
   5f7b5:	mov    QWORD PTR [rsp+0x218],r14
   5f7bd:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5f7c8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5f7d3:	mov    QWORD PTR [rsp+0x190],rdi
   5f7db:	mov    rdi,r12
   5f7de:	call   5f7e3 <sqlite3VdbeExec+0x10343>
   5f7e3:	mov    r14d,eax
   5f7e6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5f7f1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5f7fc:	mov    QWORD PTR [r12+0x48],0x0
   5f805:	mov    DWORD PTR [r12+0x50],0x0
   5f80e:	mov    rdi,QWORD PTR [rsp+0x190]
   5f816:	mov    DWORD PTR [rsp+0x41c],r14d
   5f81e:	mov    r14,QWORD PTR [rsp+0x218]
   5f826:	mov    rax,r14
   5f829:	add    rax,QWORD PTR [r12+0x48]
   5f82e:	mov    QWORD PTR [r12+0x48],rax
   5f833:	movsxd rax,DWORD PTR [r12+0x8]
   5f838:	cmp    r14,rax
   5f83b:	jle    5f842 <sqlite3VdbeExec+0x103a2>
   5f83d:	mov    DWORD PTR [r12+0x8],r14d
   5f842:	cmp    QWORD PTR [r12+0x40],0x0
   5f848:	je     5fa79 <sqlite3VdbeExec+0x105d9>
   5f84e:	movsxd rax,DWORD PTR [r12+0x50]
   5f853:	add    rax,rbx
   5f856:	cmp    eax,DWORD PTR [r12+0x54]
   5f85b:	jg     5f86a <sqlite3VdbeExec+0x103ca>
   5f85d:	mov    QWORD PTR [rsp+0x210],rbx
   5f865:	jmp    5fa2f <sqlite3VdbeExec+0x1058f>
   5f86a:	movsxd rcx,DWORD PTR [r12+0x54]
   5f86f:	mov    r14,rcx
   5f872:	shl    r14,1
   5f875:	cmp    QWORD PTR [r12+0x38],0x0
   5f87b:	jne    5f8a3 <sqlite3VdbeExec+0x10403>
   5f87d:	mov    QWORD PTR [rsp+0x210],rbx
   5f885:	mov    rbx,r14
   5f888:	mov    r14,QWORD PTR [rsp+0x208]
   5f890:	mov    r11d,0xffffffff
   5f896:	mov    DWORD PTR [rsp+0x428],r11d
   5f89e:	jmp    5f97e <sqlite3VdbeExec+0x104de>
   5f8a3:	mov    rcx,QWORD PTR [r12+0x38]
   5f8a8:	sub    rcx,QWORD PTR [r12+0x40]
   5f8ad:	mov    QWORD PTR [rsp+0x1e8],r14
   5f8b5:	mov    r14d,ecx
   5f8b8:	mov    QWORD PTR [rsp+0x210],rbx
   5f8c0:	mov    rbx,QWORD PTR [rsp+0x1e8]
   5f8c8:	mov    DWORD PTR [rsp+0x428],r14d
   5f8d0:	mov    r14,QWORD PTR [rsp+0x208]
   5f8d8:	jmp    5f97e <sqlite3VdbeExec+0x104de>
   5f8dd:	xor    r11d,r11d
   5f8e0:	mov    DWORD PTR [rsp+0x41c],r11d
   5f8e8:	jmp    5f826 <sqlite3VdbeExec+0x10386>
   5f8ed:	mov    rax,QWORD PTR [r12+0x48]
   5f8f2:	movsxd rcx,DWORD PTR [r12+0x4]
   5f8f7:	cmp    rax,rcx
   5f8fa:	jg     5f7b5 <sqlite3VdbeExec+0x10315>
   5f900:	mov    rax,QWORD PTR [r12+0x48]
   5f905:	movsxd rcx,DWORD PTR [r12]
   5f909:	cmp    rax,rcx
   5f90c:	jle    5f930 <sqlite3VdbeExec+0x10490>
   5f90e:	mov    eax,DWORD PTR [rip+0x0]        # 5f914 <sqlite3VdbeExec+0x10474>
   5f914:	test   eax,eax
   5f916:	mov    eax,0x0
   5f91b:	setne  al
   5f91e:	mov    QWORD PTR [rsp+0x218],r14
   5f926:	mov    r14,QWORD PTR [rsp+0x208]
   5f92e:	jmp    5f942 <sqlite3VdbeExec+0x104a2>
   5f930:	xor    eax,eax
   5f932:	mov    QWORD PTR [rsp+0x218],r14
   5f93a:	mov    r14,QWORD PTR [rsp+0x208]
   5f942:	test   eax,eax
   5f944:	jne    5f966 <sqlite3VdbeExec+0x104c6>
   5f946:	mov    QWORD PTR [rsp+0x208],r14
   5f94e:	mov    r14,QWORD PTR [rsp+0x218]
   5f956:	xor    r11d,r11d
   5f959:	mov    DWORD PTR [rsp+0x41c],r11d
   5f961:	jmp    5f826 <sqlite3VdbeExec+0x10386>
   5f966:	mov    QWORD PTR [rsp+0x208],r14
   5f96e:	mov    r14,QWORD PTR [rsp+0x218]
   5f976:	jmp    5f7b5 <sqlite3VdbeExec+0x10315>
   5f97b:	shl    rbx,1
   5f97e:	movsxd rcx,eax
   5f981:	cmp    rbx,rcx
   5f984:	jl     5f97b <sqlite3VdbeExec+0x104db>
   5f986:	movsxd rcx,DWORD PTR [r12+0x4]
   5f98b:	cmp    rbx,rcx
   5f98e:	jle    5f9fb <sqlite3VdbeExec+0x1055b>
   5f990:	movsxd rbx,DWORD PTR [r12+0x4]
   5f995:	movsxd rcx,eax
   5f998:	cmp    rbx,rcx
   5f99b:	jge    5f9a0 <sqlite3VdbeExec+0x10500>
   5f99d:	movsxd rbx,eax
   5f9a0:	mov    rax,QWORD PTR [r12+0x40]
   5f9a5:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5f9b0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5f9bb:	mov    QWORD PTR [rsp+0x190],rdi
   5f9c3:	mov    rdi,rax
   5f9c6:	mov    rsi,rbx
   5f9c9:	call   5f9ce <sqlite3VdbeExec+0x1052e>
   5f9ce:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5f9d9:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5f9e4:	mov    rdi,QWORD PTR [rsp+0x190]
   5f9ec:	test   rax,rax
   5f9ef:	jne    5fa05 <sqlite3VdbeExec+0x10565>
   5f9f1:	mov    ebx,0x7
   5f9f6:	jmp    5fb42 <sqlite3VdbeExec+0x106a2>
   5f9fb:	movsxd rcx,eax
   5f9fe:	cmp    rbx,rcx
   5fa01:	jl     5f99d <sqlite3VdbeExec+0x104fd>
   5fa03:	jmp    5f9a0 <sqlite3VdbeExec+0x10500>
   5fa05:	mov    QWORD PTR [rsp+0x208],r14
   5fa0d:	mov    r14d,DWORD PTR [rsp+0x428]
   5fa15:	test   r14d,r14d
   5fa18:	jl     5fa25 <sqlite3VdbeExec+0x10585>
   5fa1a:	movsxd rcx,r14d
   5fa1d:	add    rcx,rax
   5fa20:	mov    QWORD PTR [r12+0x38],rcx
   5fa25:	mov    QWORD PTR [r12+0x40],rax
   5fa2a:	mov    DWORD PTR [r12+0x54],ebx
   5fa2f:	mov    rax,QWORD PTR [r12+0x40]
   5fa34:	movsxd rcx,DWORD PTR [r12+0x50]
   5fa39:	lea    rbx,[rax+rcx*1]
   5fa3d:	movsxd rax,DWORD PTR [r12+0x50]
   5fa42:	mov    r14,QWORD PTR [rsp+0x210]
   5fa4a:	lea    rcx,[r14+0x7]
   5fa4e:	and    rcx,0xfffffffffffffff8
   5fa52:	add    rax,rcx
   5fa55:	mov    DWORD PTR [r12+0x50],eax
   5fa5a:	cmp    QWORD PTR [r12+0x38],0x0
   5fa60:	je     5fa6f <sqlite3VdbeExec+0x105cf>
   5fa62:	mov    rax,QWORD PTR [r12+0x38]
   5fa67:	sub    rax,QWORD PTR [r12+0x40]
   5fa6c:	mov    DWORD PTR [rbx+0x8],eax
   5fa6f:	mov    r14,QWORD PTR [rsp+0x208]
   5fa77:	jmp    5fadd <sqlite3VdbeExec+0x1063d>
   5fa79:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5fa84:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5fa8f:	mov    QWORD PTR [rsp+0x190],rdi
   5fa97:	mov    rdi,rbx
   5fa9a:	call   5fa9f <sqlite3VdbeExec+0x105ff>
   5fa9f:	mov    rbx,rax
   5faa2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5faad:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5fab8:	mov    rdi,QWORD PTR [rsp+0x190]
   5fac0:	test   rbx,rbx
   5fac3:	jne    5facc <sqlite3VdbeExec+0x1062c>
   5fac5:	mov    ebx,0x7
   5faca:	jmp    5fb42 <sqlite3VdbeExec+0x106a2>
   5facc:	mov    rax,QWORD PTR [r12+0x38]
   5fad1:	mov    QWORD PTR [rbx+0x8],rax
   5fad5:	mov    r14,QWORD PTR [rsp+0x208]
   5fadd:	lea    rax,[rbx+0x10]
   5fae1:	mov    rcx,QWORD PTR [r14+0x8]
   5fae5:	movsxd rdx,DWORD PTR [r14+0x10]
   5fae9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5faf4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5faff:	mov    QWORD PTR [rsp+0x190],rdi
   5fb07:	mov    rdi,rax
   5fb0a:	mov    rsi,rcx
   5fb0d:	call   5fb12 <sqlite3VdbeExec+0x10672>
   5fb12:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5fb1d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5fb28:	mov    eax,DWORD PTR [r14+0x10]
   5fb2c:	mov    DWORD PTR [rbx],eax
   5fb2e:	mov    QWORD PTR [r12+0x38],rbx
   5fb33:	mov    rdi,QWORD PTR [rsp+0x190]
   5fb3b:	mov    ebx,DWORD PTR [rsp+0x41c]
   5fb42:	test   ebx,ebx
   5fb44:	je     5fb6e <sqlite3VdbeExec+0x106ce>
   5fb46:	mov    r14,QWORD PTR [rsp+0x1a8]
   5fb4e:	mov    QWORD PTR [rsp+0x1c8],rbp
   5fb56:	mov    rbp,rbx
   5fb59:	mov    r13,QWORD PTR [rsp+0x1b0]
   5fb61:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5fb69:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5fb6e:	mov    r14,QWORD PTR [rsp+0x1a8]
   5fb76:	mov    DWORD PTR [rsp+0x3fc],r15d
   5fb7e:	mov    DWORD PTR [rsp+0x40c],ebx
   5fb85:	mov    rbx,r13
   5fb88:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5fb8d:	mov    QWORD PTR [rsp+0x1a8],r14
   5fb95:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5fb9d:	mov    r13,rbx
   5fba0:	mov    QWORD PTR [rsp+0x1b0],r12
   5fba8:	mov    rax,QWORD PTR [rdi+0x78]
   5fbac:	movsxd rcx,DWORD PTR [rbp+0x4]
   5fbb0:	mov    rbx,QWORD PTR [rax+rcx*8]
   5fbb4:	mov    r12,QWORD PTR [rbx+0x28]
   5fbb8:	mov    rax,QWORD PTR [rbx+0x30]
   5fbbc:	mov    QWORD PTR [rsp+0x268],rax
   5fbc4:	mov    eax,DWORD PTR [rbp+0xc]
   5fbc7:	mov    WORD PTR [rsp+0x284],ax
   5fbcf:	mov    BYTE PTR [rsp+0x286],0x0
   5fbd7:	movsxd rax,DWORD PTR [rbp+0x8]
   5fbdb:	imul   rax,rax,0x38
   5fbdf:	add    rax,r13
   5fbe2:	mov    QWORD PTR [rsp+0x270],rax
   5fbea:	lea    r14,[rsp+0x268]
   5fbf2:	mov    rax,r14
   5fbf5:	lea    r14,[rsp+0x418]
   5fbfd:	mov    rcx,r14
   5fc00:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5fc0b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5fc16:	mov    QWORD PTR [rsp+0x190],rdi
   5fc1e:	mov    rdi,r12
   5fc21:	mov    rsi,rax
   5fc24:	mov    rdx,rcx
   5fc27:	call   5fc2c <sqlite3VdbeExec+0x1078c>
   5fc2c:	mov    r14d,eax
   5fc2f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5fc3a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5fc45:	mov    rdi,QWORD PTR [rsp+0x190]
   5fc4d:	test   r14d,r14d
   5fc50:	je     5fc7a <sqlite3VdbeExec+0x107da>
   5fc52:	mov    QWORD PTR [rsp+0x1c8],rbp
   5fc5a:	mov    rbp,r14
   5fc5d:	mov    r14,QWORD PTR [rsp+0x1a8]
   5fc65:	mov    r13,QWORD PTR [rsp+0x1b0]
   5fc6d:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5fc75:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5fc7a:	cmp    DWORD PTR [rsp+0x418],0x0
   5fc82:	je     5fdb8 <sqlite3VdbeExec+0x10918>
   5fc88:	mov    rax,QWORD PTR [rbp+0x10]
   5fc8c:	lea    r14,[rsp+0x268]
   5fc94:	mov    rcx,r14
   5fc97:	lea    r14,[rsp+0x418]
   5fc9f:	mov    rdx,r14
   5fca2:	xor    esi,esi
   5fca4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5fcaf:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5fcba:	mov    rdi,r12
   5fcbd:	mov    r8,rsi
   5fcc0:	mov    rsi,rax
   5fcc3:	mov    r11,rdx
   5fcc6:	mov    rdx,rcx
   5fcc9:	mov    rcx,r11
   5fccc:	call   5fcd1 <sqlite3VdbeExec+0x10831>
   5fcd1:	mov    r14d,eax
   5fcd4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5fcdf:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5fcea:	mov    rdi,QWORD PTR [rsp+0x190]
   5fcf2:	test   r14d,r14d
   5fcf5:	je     5fd1f <sqlite3VdbeExec+0x1087f>
   5fcf7:	mov    QWORD PTR [rsp+0x1c8],rbp
   5fcff:	mov    rbp,r14
   5fd02:	mov    r14,QWORD PTR [rsp+0x1a8]
   5fd0a:	mov    r13,QWORD PTR [rsp+0x1b0]
   5fd12:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5fd1a:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5fd1f:	cmp    DWORD PTR [rsp+0x418],0x0
   5fd27:	je     5fdb8 <sqlite3VdbeExec+0x10918>
   5fd2d:	mov    r12,QWORD PTR [rsp+0x1a8]
   5fd35:	mov    rax,QWORD PTR [r12+0x30]
   5fd3a:	and    rax,0x10000001
   5fd40:	cmp    rax,0x1
   5fd44:	je     5fd8f <sqlite3VdbeExec+0x108ef>
   5fd46:	mov    eax,0x30b
   5fd4b:	mov    ecx,0x192e3
   5fd50:	lea    rdx,[rip+0x0]        # 5fd57 <sqlite3VdbeExec+0x108b7>
   5fd57:	mov    rdi,rax
   5fd5a:	mov    rsi,rcx
   5fd5d:	call   5fd62 <sqlite3VdbeExec+0x108c2>
   5fd62:	mov    ebx,eax
   5fd64:	mov    rdi,QWORD PTR [rsp+0x190]
   5fd6c:	mov    r14,r12
   5fd6f:	mov    QWORD PTR [rsp+0x1c8],rbp
   5fd77:	mov    rbp,rbx
   5fd7a:	mov    r13,QWORD PTR [rsp+0x1b0]
   5fd82:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5fd8a:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5fd8f:	mov    DWORD PTR [rbx+0x18],0x0
   5fd96:	mov    DWORD PTR [rbx+0x1c],0x0
   5fd9d:	mov    DWORD PTR [rsp+0x3fc],r15d
   5fda5:	mov    DWORD PTR [rsp+0x40c],r14d
   5fdad:	mov    r14,r12
   5fdb0:	mov    rbx,r13
   5fdb3:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5fdb8:	mov    eax,0x4
   5fdbd:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5fdc8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5fdd3:	mov    QWORD PTR [rsp+0x190],rdi
   5fddb:	mov    rdi,r12
   5fdde:	mov    rsi,rax
   5fde1:	call   5fde6 <sqlite3VdbeExec+0x10946>
   5fde6:	mov    r12d,eax
   5fde9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5fdf4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5fdff:	mov    rdi,QWORD PTR [rsp+0x190]
   5fe07:	test   r12d,r12d
   5fe0a:	je     5fe34 <sqlite3VdbeExec+0x10994>
   5fe0c:	mov    r14,QWORD PTR [rsp+0x1a8]
   5fe14:	mov    QWORD PTR [rsp+0x1c8],rbp
   5fe1c:	mov    rbp,r12
   5fe1f:	mov    r13,QWORD PTR [rsp+0x1b0]
   5fe27:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5fe2f:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5fe34:	mov    DWORD PTR [rbx+0x18],0x0
   5fe3b:	mov    DWORD PTR [rbx+0x1c],0x0
   5fe42:	mov    r14,QWORD PTR [rsp+0x1a8]
   5fe4a:	mov    DWORD PTR [rsp+0x3fc],r15d
   5fe52:	mov    DWORD PTR [rsp+0x40c],r12d
   5fe5a:	mov    rbx,r13
   5fe5d:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   5fe62:	mov    QWORD PTR [rsp+0x1a8],r14
   5fe6a:	mov    r15d,DWORD PTR [rsp+0x3fc]
   5fe72:	mov    r13,rbx
   5fe75:	mov    QWORD PTR [rsp+0x1b0],r12
   5fe7d:	mov    rax,QWORD PTR [rdi+0x78]
   5fe81:	movsxd rcx,DWORD PTR [rbp+0x4]
   5fe85:	mov    rbx,QWORD PTR [rax+rcx*8]
   5fe89:	mov    rax,QWORD PTR [rbx+0x28]
   5fe8d:	xor    ecx,ecx
   5fe8f:	movzx  eax,BYTE PTR [rax]
   5fe92:	cmp    ecx,eax
   5fe94:	je     5fedf <sqlite3VdbeExec+0x10a3f>
   5fe96:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5fea1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5feac:	mov    QWORD PTR [rsp+0x190],rdi
   5feb4:	mov    rdi,rbx
   5feb7:	call   5febc <sqlite3VdbeExec+0x10a1c>
   5febc:	mov    r12d,eax
   5febf:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5feca:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5fed5:	mov    rdi,QWORD PTR [rsp+0x190]
   5fedd:	jmp    5fee2 <sqlite3VdbeExec+0x10a42>
   5fedf:	xor    r12d,r12d
   5fee2:	test   r12d,r12d
   5fee5:	je     5ff0f <sqlite3VdbeExec+0x10a6f>
   5fee7:	mov    r14,QWORD PTR [rsp+0x1a8]
   5feef:	mov    QWORD PTR [rsp+0x1c8],rbp
   5fef7:	mov    rbp,r12
   5fefa:	mov    r13,QWORD PTR [rsp+0x1b0]
   5ff02:	mov    rbx,QWORD PTR [rsp+0x1d8]
   5ff0a:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   5ff0f:	mov    r14,QWORD PTR [rsp+0x1a8]
   5ff17:	cmp    BYTE PTR [rbx+0x2],0x0
   5ff1b:	jne    604c0 <sqlite3VdbeExec+0x11020>
   5ff21:	mov    QWORD PTR [rsp+0x208],0x0
   5ff2d:	mov    r12,QWORD PTR [rbx+0x28]
   5ff31:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ff3c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ff47:	mov    QWORD PTR [rsp+0x190],rdi
   5ff4f:	mov    rdi,r12
   5ff52:	call   5ff57 <sqlite3VdbeExec+0x10ab7>
   5ff57:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ff62:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ff6d:	mov    eax,DWORD PTR [r12+0x40]
   5ff72:	mov    WORD PTR [rsp+0x2d4],0x0
   5ff7c:	mov    QWORD PTR [rsp+0x2d8],r14
   5ff84:	mov    DWORD PTR [rsp+0x2e0],0x0
   5ff8f:	mov    QWORD PTR [rsp+0x210],rbx
   5ff97:	lea    rbx,[rsp+0x2c0]
   5ff9f:	mov    rcx,rbx
   5ffa2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   5ffad:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   5ffb8:	mov    rdi,r12
   5ffbb:	mov    rsi,rax
   5ffbe:	mov    rdx,rcx
   5ffc1:	call   5ffc6 <sqlite3VdbeExec+0x10b26>
   5ffc6:	mov    r12d,eax
   5ffc9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   5ffd4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   5ffdf:	mov    rdi,QWORD PTR [rsp+0x190]
   5ffe7:	test   r12d,r12d
   5ffea:	je     5fff4 <sqlite3VdbeExec+0x10b54>
   5ffec:	mov    rbx,r12
   5ffef:	jmp    603dc <sqlite3VdbeExec+0x10f3c>
   5fff4:	mov    rax,QWORD PTR [rbx+0x8]
   5fff8:	movzx  eax,BYTE PTR [rax]
   5fffb:	lea    r12,[rsp+0x418]
   60003:	mov    DWORD PTR [r12],eax
   60007:	cmp    DWORD PTR [r12],0x80
   6000f:	jb     600d9 <sqlite3VdbeExec+0x10c39>
   60015:	mov    rax,QWORD PTR [rbx+0x8]
   60019:	lea    rbx,[rsp+0x218]
   60021:	movzx  ecx,BYTE PTR [rax+0x1]
   60025:	and    ecx,0x80
   6002b:	test   ecx,ecx
   6002d:	jne    60047 <sqlite3VdbeExec+0x10ba7>
   6002f:	movzx  ecx,BYTE PTR [rax]
   60032:	and    ecx,0x7f
   60035:	shl    ecx,0x7
   60038:	movzx  eax,BYTE PTR [rax+0x1]
   6003c:	or     ecx,eax
   6003e:	mov    DWORD PTR [r12],ecx
   60042:	jmp    600d9 <sqlite3VdbeExec+0x10c39>
   60047:	movzx  ecx,BYTE PTR [rax+0x2]
   6004b:	and    ecx,0x80
   60051:	test   ecx,ecx
   60053:	jne    60076 <sqlite3VdbeExec+0x10bd6>
   60055:	movzx  ecx,BYTE PTR [rax]
   60058:	and    ecx,0x7f
   6005b:	shl    ecx,0xe
   6005e:	movzx  edx,BYTE PTR [rax+0x1]
   60062:	and    edx,0x7f
   60065:	shl    edx,0x7
   60068:	or     ecx,edx
   6006a:	movzx  eax,BYTE PTR [rax+0x2]
   6006e:	or     ecx,eax
   60070:	mov    DWORD PTR [r12],ecx
   60074:	jmp    600d9 <sqlite3VdbeExec+0x10c39>
   60076:	mov    rcx,rbx
   60079:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60084:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6008f:	mov    rdi,rax
   60092:	mov    rsi,rcx
   60095:	call   6009a <sqlite3VdbeExec+0x10bfa>
   6009a:	movzx  eax,al
   6009d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   600a8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   600b3:	mov    eax,0xffffffff
   600b8:	and    rax,QWORD PTR [rbx]
   600bb:	mov    rdi,QWORD PTR [rsp+0x190]
   600c3:	cmp    rax,QWORD PTR [rbx]
   600c6:	je     600d2 <sqlite3VdbeExec+0x10c32>
   600c8:	mov    DWORD PTR [r12],0xffffffff
   600d0:	jmp    600d9 <sqlite3VdbeExec+0x10c39>
   600d2:	mov    rax,QWORD PTR [rbx]
   600d5:	mov    DWORD PTR [r12],eax
   600d9:	cmp    DWORD PTR [r12],0x3
   600de:	jae    600ed <sqlite3VdbeExec+0x10c4d>
   600e0:	lea    rbx,[rsp+0x2c0]
   600e8:	jmp    60335 <sqlite3VdbeExec+0x10e95>
   600ed:	mov    eax,DWORD PTR [r12]
   600f1:	lea    rbx,[rsp+0x2c0]
   600f9:	cmp    eax,DWORD PTR [rbx+0x10]
   600fc:	ja     60335 <sqlite3VdbeExec+0x10e95>
   60102:	mov    rax,QWORD PTR [rbx+0x8]
   60106:	mov    ecx,DWORD PTR [r12]
   6010a:	sub    ecx,0x1
   6010d:	movzx  eax,BYTE PTR [rax+rcx*1]
   60111:	lea    r12,[rsp+0x41c]
   60119:	mov    DWORD PTR [r12],eax
   6011d:	cmp    DWORD PTR [r12],0x80
   60125:	jb     60207 <sqlite3VdbeExec+0x10d67>
   6012b:	mov    rax,QWORD PTR [rbx+0x8]
   6012f:	lea    rbx,[rsp+0x418]
   60137:	mov    ecx,DWORD PTR [rbx]
   60139:	sub    ecx,0x1
   6013c:	lea    rdx,[rax+rcx*1]
   60140:	lea    rbx,[rsp+0x218]
   60148:	movzx  eax,BYTE PTR [rax+rcx*1+0x1]
   6014d:	and    eax,0x80
   60152:	test   eax,eax
   60154:	jne    6016e <sqlite3VdbeExec+0x10cce>
   60156:	movzx  eax,BYTE PTR [rdx]
   60159:	and    eax,0x7f
   6015c:	shl    eax,0x7
   6015f:	movzx  ecx,BYTE PTR [rdx+0x1]
   60163:	or     eax,ecx
   60165:	mov    DWORD PTR [r12],eax
   60169:	jmp    60207 <sqlite3VdbeExec+0x10d67>
   6016e:	movzx  eax,BYTE PTR [rdx+0x2]
   60172:	and    eax,0x80
   60177:	test   eax,eax
   60179:	jne    6019c <sqlite3VdbeExec+0x10cfc>
   6017b:	movzx  eax,BYTE PTR [rdx]
   6017e:	and    eax,0x7f
   60181:	shl    eax,0xe
   60184:	movzx  ecx,BYTE PTR [rdx+0x1]
   60188:	and    ecx,0x7f
   6018b:	shl    ecx,0x7
   6018e:	or     eax,ecx
   60190:	movzx  ecx,BYTE PTR [rdx+0x2]
   60194:	or     eax,ecx
   60196:	mov    DWORD PTR [r12],eax
   6019a:	jmp    60207 <sqlite3VdbeExec+0x10d67>
   6019c:	mov    rax,rbx
   6019f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   601aa:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   601b5:	mov    QWORD PTR [rsp+0x190],rdi
   601bd:	mov    rdi,rdx
   601c0:	mov    rsi,rax
   601c3:	call   601c8 <sqlite3VdbeExec+0x10d28>
   601c8:	movzx  eax,al
   601cb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   601d6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   601e1:	mov    eax,0xffffffff
   601e6:	and    rax,QWORD PTR [rbx]
   601e9:	mov    rdi,QWORD PTR [rsp+0x190]
   601f1:	cmp    rax,QWORD PTR [rbx]
   601f4:	je     60200 <sqlite3VdbeExec+0x10d60>
   601f6:	mov    DWORD PTR [r12],0xffffffff
   601fe:	jmp    60207 <sqlite3VdbeExec+0x10d67>
   60200:	mov    rax,QWORD PTR [rbx]
   60203:	mov    DWORD PTR [r12],eax
   60207:	cmp    DWORD PTR [r12],0x1
   6020c:	jae    6021b <sqlite3VdbeExec+0x10d7b>
   6020e:	lea    rbx,[rsp+0x2c0]
   60216:	jmp    60335 <sqlite3VdbeExec+0x10e95>
   6021b:	cmp    DWORD PTR [r12],0x9
   60220:	jbe    6022f <sqlite3VdbeExec+0x10d8f>
   60222:	lea    rbx,[rsp+0x2c0]
   6022a:	jmp    60335 <sqlite3VdbeExec+0x10e95>
   6022f:	cmp    DWORD PTR [r12],0x7
   60234:	jne    60243 <sqlite3VdbeExec+0x10da3>
   60236:	lea    rbx,[rsp+0x2c0]
   6023e:	jmp    60335 <sqlite3VdbeExec+0x10e95>
   60243:	lea    rax,[rip+0x0]        # 6024a <sqlite3VdbeExec+0x10daa>
   6024a:	mov    ecx,DWORD PTR [r12]
   6024e:	movzx  eax,BYTE PTR [rax+rcx*1]
   60252:	lea    rbx,[rsp+0x2c0]
   6025a:	mov    ecx,DWORD PTR [rbx+0x10]
   6025d:	lea    r12,[rsp+0x418]
   60265:	mov    edx,eax
   60267:	add    edx,DWORD PTR [r12]
   6026b:	cmp    ecx,edx
   6026d:	jb     60335 <sqlite3VdbeExec+0x10e95>
   60273:	mov    rcx,QWORD PTR [rbx+0x8]
   60277:	mov    edx,DWORD PTR [rbx+0x10]
   6027a:	sub    edx,eax
   6027c:	add    rcx,rdx
   6027f:	lea    r12,[rsp+0x41c]
   60287:	mov    eax,DWORD PTR [r12]
   6028b:	lea    r12,[rsp+0x2f8]
   60293:	mov    rdx,r12
   60296:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   602a1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   602ac:	mov    QWORD PTR [rsp+0x190],rdi
   602b4:	mov    rdi,rcx
   602b7:	mov    rsi,rax
   602ba:	call   602bf <sqlite3VdbeExec+0x10e1f>
   602bf:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   602ca:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   602d5:	mov    rax,QWORD PTR [r12]
   602d9:	mov    QWORD PTR [rsp+0x208],rax
   602e1:	mov    rax,rbx
   602e4:	mov    rdi,QWORD PTR [rsp+0x190]
   602ec:	cmp    DWORD PTR [rbx+0x20],0x0
   602f0:	je     6032e <sqlite3VdbeExec+0x10e8e>
   602f2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   602fd:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60308:	mov    rdi,rax
   6030b:	call   60310 <sqlite3VdbeExec+0x10e70>
   60310:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6031b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   60326:	mov    rdi,QWORD PTR [rsp+0x190]
   6032e:	xor    ebx,ebx
   60330:	jmp    603dc <sqlite3VdbeExec+0x10f3c>
   60335:	mov    rax,rbx
   60338:	cmp    DWORD PTR [rbx+0x20],0x0
   6033c:	je     60382 <sqlite3VdbeExec+0x10ee2>
   6033e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60349:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60354:	mov    QWORD PTR [rsp+0x190],rdi
   6035c:	mov    rdi,rax
   6035f:	call   60364 <sqlite3VdbeExec+0x10ec4>
   60364:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6036f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6037a:	mov    rdi,QWORD PTR [rsp+0x190]
   60382:	mov    eax,0x16b4d
   60387:	mov    ecx,0xb
   6038c:	lea    rdx,[rip+0x0]        # 60393 <sqlite3VdbeExec+0x10ef3>
   60393:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6039e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   603a9:	mov    QWORD PTR [rsp+0x190],rdi
   603b1:	mov    rdi,rcx
   603b4:	mov    rsi,rax
   603b7:	call   603bc <sqlite3VdbeExec+0x10f1c>
   603bc:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   603c7:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   603d2:	mov    ebx,eax
   603d4:	mov    rdi,QWORD PTR [rsp+0x190]
   603dc:	test   ebx,ebx
   603de:	je     60400 <sqlite3VdbeExec+0x10f60>
   603e0:	mov    QWORD PTR [rsp+0x1c8],rbp
   603e8:	mov    rbp,rbx
   603eb:	mov    r13,QWORD PTR [rsp+0x1b0]
   603f3:	mov    rbx,QWORD PTR [rsp+0x1d8]
   603fb:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   60400:	cmp    BYTE PTR [rbp+0x0],0x8f
   60404:	jne    60443 <sqlite3VdbeExec+0x10fa3>
   60406:	mov    rax,QWORD PTR [rdi+0x78]
   6040a:	movsxd rcx,DWORD PTR [rbp+0xc]
   6040e:	mov    rax,QWORD PTR [rax+rcx*8]
   60412:	mov    BYTE PTR [rax+0x2],0x0
   60416:	mov    rcx,QWORD PTR [rsp+0x208]
   6041e:	mov    QWORD PTR [rax+0x48],rcx
   60422:	mov    BYTE PTR [rax+0x3],0x1
   60426:	mov    DWORD PTR [rax+0x18],0x0
   6042d:	mov    rcx,QWORD PTR [rbp+0x10]
   60431:	mov    QWORD PTR [rax+0x8],rcx
   60435:	mov    r12,QWORD PTR [rsp+0x210]
   6043d:	mov    QWORD PTR [rax+0x20],r12
   60441:	jmp    604bb <sqlite3VdbeExec+0x1101b>
   60443:	mov    rax,QWORD PTR [rdi+0x68]
   60447:	movsxd rcx,DWORD PTR [rbp+0x8]
   6044b:	imul   rcx,rcx,0x38
   6044f:	lea    rdx,[rax+rcx*1]
   60453:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   60458:	and    eax,0x9000
   6045d:	test   eax,eax
   6045f:	je     604aa <sqlite3VdbeExec+0x1100a>
   60461:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6046c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60477:	mov    QWORD PTR [rsp+0x190],rdi
   6047f:	mov    rdi,rdx
   60482:	call   60487 <sqlite3VdbeExec+0x10fe7>
   60487:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   60492:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6049d:	mov    rdi,QWORD PTR [rsp+0x190]
   604a5:	mov    rdx,rax
   604a8:	jmp    604b0 <sqlite3VdbeExec+0x11010>
   604aa:	mov    WORD PTR [rdx+0x14],0x4
   604b0:	mov    rax,QWORD PTR [rsp+0x208]
   604b8:	mov    QWORD PTR [rdx],rax
   604bb:	mov    r12,rbx
   604be:	jmp    60528 <sqlite3VdbeExec+0x11088>
   604c0:	movsxd rax,DWORD PTR [rbp+0x8]
   604c4:	imul   rax,rax,0x38
   604c8:	lea    rcx,[r13+rax*1+0x0]
   604cd:	movzx  eax,WORD PTR [r13+rax*1+0x14]
   604d3:	and    eax,0x9000
   604d8:	test   eax,eax
   604da:	je     60522 <sqlite3VdbeExec+0x11082>
   604dc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   604e7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   604f2:	mov    QWORD PTR [rsp+0x190],rdi
   604fa:	mov    rdi,rcx
   604fd:	call   60502 <sqlite3VdbeExec+0x11062>
   60502:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6050d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   60518:	mov    rdi,QWORD PTR [rsp+0x190]
   60520:	jmp    60528 <sqlite3VdbeExec+0x11088>
   60522:	mov    WORD PTR [rcx+0x14],0x1
   60528:	mov    DWORD PTR [rsp+0x3fc],r15d
   60530:	mov    DWORD PTR [rsp+0x40c],r12d
   60538:	mov    rbx,r13
   6053b:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   60540:	mov    r15d,DWORD PTR [rsp+0x3fc]
   60548:	mov    r13,QWORD PTR [rsp+0x1d0]
   60550:	mov    QWORD PTR [rsp+0x1b0],r12
   60558:	mov    r12d,DWORD PTR [rsp+0x414]
   60560:	mov    rax,QWORD PTR [rdi+0x78]
   60564:	movsxd rcx,DWORD PTR [rbp+0x4]
   60568:	mov    rax,QWORD PTR [rax+rcx*8]
   6056c:	cmp    BYTE PTR [rax+0x3],0x0
   60570:	jne    6057c <sqlite3VdbeExec+0x110dc>
   60572:	mov    QWORD PTR [rsp+0x1d0],r13
   6057a:	jmp    605fa <sqlite3VdbeExec+0x1115a>
   6057c:	mov    QWORD PTR [rsp+0x1d0],r13
   60584:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6058f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6059a:	mov    QWORD PTR [rsp+0x190],rdi
   605a2:	mov    rdi,rax
   605a5:	call   605aa <sqlite3VdbeExec+0x1110a>
   605aa:	mov    r13d,eax
   605ad:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   605b8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   605c3:	mov    rdi,QWORD PTR [rsp+0x190]
   605cb:	test   r13d,r13d
   605ce:	jne    605da <sqlite3VdbeExec+0x1113a>
   605d0:	mov    DWORD PTR [rsp+0x40c],r13d
   605d8:	jmp    605fa <sqlite3VdbeExec+0x1115a>
   605da:	mov    QWORD PTR [rsp+0x1c8],rbp
   605e2:	mov    rbp,r13
   605e5:	mov    r13,QWORD PTR [rsp+0x1b0]
   605ed:	mov    rbx,QWORD PTR [rsp+0x1d8]
   605f5:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   605fa:	mov    DWORD PTR [rsp+0x3fc],r15d
   60602:	mov    DWORD PTR [rsp+0x414],r12d
   6060a:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6060f:	mov    r15d,DWORD PTR [rsp+0x3fc]
   60617:	mov    QWORD PTR [rsp+0x1b0],r12
   6061f:	mov    r12d,DWORD PTR [rsp+0x414]
   60627:	mov    rax,QWORD PTR [rdi+0x78]
   6062b:	movsxd rcx,DWORD PTR [rbp+0x4]
   6062f:	mov    rax,QWORD PTR [rax+rcx*8]
   60633:	mov    rcx,QWORD PTR [rax+0x30]
   60637:	mov    QWORD PTR [rsp+0x268],rcx
   6063f:	mov    ecx,DWORD PTR [rbp+0x10]
   60642:	mov    WORD PTR [rsp+0x284],cx
   6064a:	cmp    BYTE PTR [rbp+0x0],0x2d
   6064e:	jae    6065a <sqlite3VdbeExec+0x111ba>
   60650:	mov    BYTE PTR [rsp+0x286],0xff
   60658:	jmp    60662 <sqlite3VdbeExec+0x111c2>
   6065a:	mov    BYTE PTR [rsp+0x286],0x0
   60662:	movsxd rcx,DWORD PTR [rbp+0xc]
   60666:	imul   rcx,rcx,0x38
   6066a:	add    rcx,rbx
   6066d:	mov    QWORD PTR [rsp+0x270],rcx
   60675:	mov    r13,QWORD PTR [rax+0x28]
   60679:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60684:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6068f:	mov    QWORD PTR [rsp+0x190],rdi
   60697:	mov    rdi,r13
   6069a:	call   6069f <sqlite3VdbeExec+0x111ff>
   6069f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   606aa:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   606b5:	mov    eax,DWORD PTR [r13+0x40]
   606b9:	mov    rdi,QWORD PTR [rsp+0x190]
   606c1:	test   rax,rax
   606c4:	jle    606ce <sqlite3VdbeExec+0x1122e>
   606c6:	cmp    rax,0x7fffffff
   606cc:	jle    6071c <sqlite3VdbeExec+0x1127c>
   606ce:	mov    eax,0x193b7
   606d3:	mov    ecx,0xb
   606d8:	lea    rdx,[rip+0x0]        # 606df <sqlite3VdbeExec+0x1123f>
   606df:	mov    QWORD PTR [rsp+0x190],rdi
   606e7:	mov    rdi,rcx
   606ea:	mov    rsi,rax
   606ed:	call   606f2 <sqlite3VdbeExec+0x11252>
   606f2:	mov    ebx,eax
   606f4:	mov    rdi,QWORD PTR [rsp+0x190]
   606fc:	mov    QWORD PTR [rsp+0x1c8],rbp
   60704:	mov    rbp,rbx
   60707:	mov    r13,QWORD PTR [rsp+0x1b0]
   6070f:	mov    rbx,QWORD PTR [rsp+0x1d8]
   60717:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   6071c:	mov    WORD PTR [rsp+0x30c],0x0
   60726:	mov    QWORD PTR [rsp+0x310],r14
   6072e:	mov    DWORD PTR [rsp+0x318],0x0
   60739:	mov    QWORD PTR [rsp+0x1a8],r14
   60741:	lea    r14,[rsp+0x2f8]
   60749:	mov    rcx,r14
   6074c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60757:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60762:	mov    rdi,r13
   60765:	mov    rsi,rax
   60768:	mov    rdx,rcx
   6076b:	call   60770 <sqlite3VdbeExec+0x112d0>
   60770:	mov    r13d,eax
   60773:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6077e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   60789:	mov    rdi,QWORD PTR [rsp+0x190]
   60791:	test   r13d,r13d
   60794:	je     607be <sqlite3VdbeExec+0x1131e>
   60796:	mov    r14,QWORD PTR [rsp+0x1a8]
   6079e:	mov    QWORD PTR [rsp+0x1c8],rbp
   607a6:	mov    rbp,r13
   607a9:	mov    r13,QWORD PTR [rsp+0x1b0]
   607b1:	mov    rbx,QWORD PTR [rsp+0x1d8]
   607b9:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   607be:	mov    eax,DWORD PTR [rsp+0x308]
   607c5:	mov    rcx,QWORD PTR [rsp+0x300]
   607cd:	mov    DWORD PTR [rsp+0x414],r12d
   607d5:	lea    r12,[rsp+0x268]
   607dd:	mov    rdx,r12
   607e0:	xor    esi,esi
   607e2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   607ed:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   607f8:	mov    rdi,rax
   607fb:	mov    r11,rsi
   607fe:	mov    rsi,rcx
   60801:	mov    rcx,r11
   60804:	call   60809 <sqlite3VdbeExec+0x11369>
   60809:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   60814:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6081f:	mov    rcx,r14
   60822:	mov    rdi,QWORD PTR [rsp+0x190]
   6082a:	cmp    DWORD PTR [rsp+0x318],0x0
   60832:	je     60880 <sqlite3VdbeExec+0x113e0>
   60834:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6083f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6084a:	mov    QWORD PTR [rsp+0x188],rax
   60852:	mov    rdi,rcx
   60855:	call   6085a <sqlite3VdbeExec+0x113ba>
   6085a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   60865:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   60870:	mov    rax,QWORD PTR [rsp+0x188]
   60878:	mov    rdi,QWORD PTR [rsp+0x190]
   60880:	movzx  ecx,BYTE PTR [rbp+0x0]
   60884:	and    ecx,0x1
   60887:	cmp    ecx,0x1
   6088a:	jne    608b1 <sqlite3VdbeExec+0x11411>
   6088c:	neg    eax
   6088e:	test   eax,eax
   60890:	jg     6089c <sqlite3VdbeExec+0x113fc>
   60892:	mov    r12d,DWORD PTR [rsp+0x414]
   6089a:	jmp    608d2 <sqlite3VdbeExec+0x11432>
   6089c:	mov    r12,QWORD PTR [rsp+0x1a8]
   608a4:	mov    DWORD PTR [rsp+0x40c],r13d
   608ac:	jmp    52730 <sqlite3VdbeExec+0x3290>
   608b1:	mov    r12d,DWORD PTR [rsp+0x414]
   608b9:	add    eax,0x1
   608bc:	test   eax,eax
   608be:	jle    608d2 <sqlite3VdbeExec+0x11432>
   608c0:	mov    DWORD PTR [rsp+0x414],r12d
   608c8:	lea    r12,[rsp+0x268]
   608d0:	jmp    6089c <sqlite3VdbeExec+0x113fc>
   608d2:	mov    r14,QWORD PTR [rsp+0x1a8]
   608da:	mov    DWORD PTR [rsp+0x3fc],r15d
   608e2:	mov    DWORD PTR [rsp+0x40c],r13d
   608ea:	mov    DWORD PTR [rsp+0x414],r12d
   608f2:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   608f7:	mov    QWORD PTR [rsp+0x1a8],r14
   608ff:	mov    r15d,DWORD PTR [rsp+0x3fc]
   60907:	mov    QWORD PTR [rsp+0x1b0],r12
   6090f:	mov    r12d,DWORD PTR [rsp+0x414]
   60917:	lea    r14,[rsp+0x2f8]
   6091f:	mov    rax,QWORD PTR [rdi+0x68]
   60923:	movsxd rcx,DWORD PTR [rbp+0x8]
   60927:	imul   rcx,rcx,0x38
   6092b:	lea    r13,[rax+rcx*1]
   6092f:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   60934:	and    eax,0x9000
   60939:	test   eax,eax
   6093b:	je     60986 <sqlite3VdbeExec+0x114e6>
   6093d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60948:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60953:	mov    QWORD PTR [rsp+0x190],rdi
   6095b:	mov    rdi,r13
   6095e:	call   60963 <sqlite3VdbeExec+0x114c3>
   60963:	mov    r13,rax
   60966:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   60971:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6097c:	mov    rdi,QWORD PTR [rsp+0x190]
   60984:	jmp    6098d <sqlite3VdbeExec+0x114ed>
   60986:	mov    WORD PTR [r13+0x14],0x4
   6098d:	mov    WORD PTR [r13+0x14],0x1
   60994:	mov    r14,QWORD PTR [rsp+0x1a8]
   6099c:	mov    eax,DWORD PTR [r14+0xd4]
   609a3:	mov    ecx,DWORD PTR [r14+0xe0]
   609aa:	add    ecx,0x1
   609ad:	cmp    eax,ecx
   609af:	jle    609dd <sqlite3VdbeExec+0x1153d>
   609b1:	mov    ebx,0x6
   609b6:	mov    BYTE PTR [rdi+0xc4],0x2
   609bd:	mov    QWORD PTR [rsp+0x1c8],rbp
   609c5:	mov    rbp,rbx
   609c8:	mov    r13,QWORD PTR [rsp+0x1b0]
   609d0:	mov    rbx,QWORD PTR [rsp+0x1d8]
   609d8:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   609dd:	mov    DWORD PTR [rsp+0x414],r12d
   609e5:	movsxd r12,DWORD PTR [rbp+0xc]
   609e9:	mov    DWORD PTR [rsp+0x41c],0x0
   609f4:	mov    rax,QWORD PTR [r14+0x20]
   609f8:	mov    rcx,r12
   609fb:	shl    rcx,0x5
   609ff:	mov    QWORD PTR [rsp+0x208],r13
   60a07:	mov    r13,QWORD PTR [rax+rcx*1+0x8]
   60a0c:	mov    QWORD PTR [rsp+0x210],r12
   60a14:	mov    r12d,DWORD PTR [rbp+0x4]
   60a18:	mov    rax,QWORD PTR [r13+0x8]
   60a1c:	mov    rcx,QWORD PTR [r13+0x0]
   60a20:	mov    QWORD PTR [rax+0x8],rcx
   60a24:	mov    QWORD PTR [rsp+0x1e8],0x0
   60a30:	mov    DWORD PTR [rsp+0x3fc],r15d
   60a38:	mov    r15,QWORD PTR [r13+0x8]
   60a3c:	mov    eax,DWORD PTR [r15+0x40]
   60a40:	cmp    r12d,eax
   60a43:	jbe    60aaa <sqlite3VdbeExec+0x1160a>
   60a45:	mov    eax,0x1460e
   60a4a:	mov    ecx,0xb
   60a4f:	lea    rdx,[rip+0x0]        # 60a56 <sqlite3VdbeExec+0x115b6>
   60a56:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60a61:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60a6c:	mov    QWORD PTR [rsp+0x190],rdi
   60a74:	mov    rdi,rcx
   60a77:	mov    rsi,rax
   60a7a:	call   60a7f <sqlite3VdbeExec+0x115df>
   60a7f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   60a8a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   60a95:	mov    rdi,QWORD PTR [rsp+0x190]
   60a9d:	mov    r13,QWORD PTR [rsp+0x208]
   60aa5:	jmp    6185d <sqlite3VdbeExec+0x123bd>
   60aaa:	mov    DWORD PTR [rsp+0x418],r12d
   60ab2:	mov    r12,QWORD PTR [r13+0x8]
   60ab6:	mov    rax,QWORD PTR [r13+0x8]
   60aba:	mov    rcx,QWORD PTR [r13+0x0]
   60abe:	mov    QWORD PTR [rax+0x8],rcx
   60ac2:	xor    eax,eax
   60ac4:	mov    rcx,QWORD PTR [r12+0x10]
   60ac9:	jmp    60b2f <sqlite3VdbeExec+0x1168f>
   60acb:	test   rcx,rcx
   60ace:	jne    60ae2 <sqlite3VdbeExec+0x11642>
   60ad0:	mov    QWORD PTR [rsp+0x220],r12
   60ad8:	mov    r12d,DWORD PTR [rsp+0x418]
   60ae0:	jmp    60b1b <sqlite3VdbeExec+0x1167b>
   60ae2:	xor    edx,edx
   60ae4:	mov    QWORD PTR [rsp+0x220],r12
   60aec:	mov    r12d,DWORD PTR [rsp+0x418]
   60af4:	cmp    edx,r12d
   60af7:	jne    60b03 <sqlite3VdbeExec+0x11663>
   60af9:	mov    r12,QWORD PTR [rsp+0x220]
   60b01:	jmp    60b34 <sqlite3VdbeExec+0x11694>
   60b03:	cmp    r12d,DWORD PTR [rcx+0x50]
   60b07:	jne    60b1b <sqlite3VdbeExec+0x1167b>
   60b09:	mov    DWORD PTR [rsp+0x418],r12d
   60b11:	mov    r12,QWORD PTR [rsp+0x220]
   60b19:	jmp    60b34 <sqlite3VdbeExec+0x11694>
   60b1b:	mov    rcx,QWORD PTR [rcx+0x28]
   60b1f:	mov    DWORD PTR [rsp+0x418],r12d
   60b27:	mov    r12,QWORD PTR [rsp+0x220]
   60b2f:	test   rcx,rcx
   60b32:	jne    60acb <sqlite3VdbeExec+0x1162b>
   60b34:	test   rcx,rcx
   60b37:	jne    60b4b <sqlite3VdbeExec+0x116ab>
   60b39:	mov    QWORD PTR [rsp+0x220],r12
   60b41:	mov    r12d,DWORD PTR [rsp+0x418]
   60b49:	jmp    60baf <sqlite3VdbeExec+0x1170f>
   60b4b:	mov    QWORD PTR [rsp+0x220],r12
   60b53:	mov    r12d,DWORD PTR [rsp+0x418]
   60b5b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60b66:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60b71:	mov    QWORD PTR [rsp+0x190],rdi
   60b79:	mov    rdi,rcx
   60b7c:	mov    rsi,r12
   60b7f:	mov    rdx,rax
   60b82:	call   60b87 <sqlite3VdbeExec+0x116e7>
   60b87:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   60b92:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   60b9d:	xor    ecx,ecx
   60b9f:	mov    rdi,QWORD PTR [rsp+0x190]
   60ba7:	cmp    ecx,eax
   60ba9:	jne    60c61 <sqlite3VdbeExec+0x117c1>
   60baf:	cmp    BYTE PTR [r13+0x13],0x0
   60bb4:	je     60be7 <sqlite3VdbeExec+0x11747>
   60bb6:	mov    BYTE PTR [r13+0x13],0x0
   60bbb:	mov    rax,QWORD PTR [r13+0x8]
   60bbf:	mov    rax,QWORD PTR [rax+0x10]
   60bc3:	jmp    60be2 <sqlite3VdbeExec+0x11742>
   60bc5:	movzx  ecx,BYTE PTR [rax+0x1]
   60bc9:	and    ecx,0x10
   60bcc:	test   ecx,ecx
   60bce:	je     60bde <sqlite3VdbeExec+0x1173e>
   60bd0:	mov    BYTE PTR [r13+0x13],0x1
   60bd5:	cmp    r12d,DWORD PTR [rax+0x50]
   60bd9:	jne    60bde <sqlite3VdbeExec+0x1173e>
   60bdb:	mov    BYTE PTR [rax],0x1
   60bde:	mov    rax,QWORD PTR [rax+0x28]
   60be2:	test   rax,rax
   60be5:	jne    60bc5 <sqlite3VdbeExec+0x11725>
   60be7:	xor    eax,eax
   60be9:	mov    QWORD PTR [rsp+0x218],r13
   60bf1:	mov    QWORD PTR [rsp+0x200],r15
   60bf9:	xor    r15d,r15d
   60bfc:	mov    r13,QWORD PTR [rsp+0x220]
   60c04:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60c0f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60c1a:	mov    QWORD PTR [rsp+0x190],rdi
   60c22:	mov    rdi,r13
   60c25:	mov    rsi,r12
   60c28:	mov    rdx,rax
   60c2b:	mov    rcx,r15
   60c2e:	call   60c33 <sqlite3VdbeExec+0x11793>
   60c33:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   60c3e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   60c49:	mov    rdi,QWORD PTR [rsp+0x190]
   60c51:	mov    r13,QWORD PTR [rsp+0x218]
   60c59:	mov    r15,QWORD PTR [rsp+0x200]
   60c61:	mov    QWORD PTR [rsp+0x1e0],rbx
   60c69:	lea    rbx,[rsp+0x428]
   60c71:	mov    DWORD PTR [rbx],eax
   60c73:	cmp    DWORD PTR [rbx],0x0
   60c76:	je     60c8f <sqlite3VdbeExec+0x117ef>
   60c78:	mov    eax,DWORD PTR [rbx]
   60c7a:	mov    r13,QWORD PTR [rsp+0x208]
   60c82:	mov    rbx,QWORD PTR [rsp+0x1e0]
   60c8a:	jmp    6185d <sqlite3VdbeExec+0x123bd>
   60c8f:	xor    eax,eax
   60c91:	lea    rbx,[rsp+0x220]
   60c99:	mov    rcx,QWORD PTR [r15]
   60c9c:	mov    rdx,rbx
   60c9f:	mov    rsi,QWORD PTR [rcx+0x110]
   60ca6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60cb1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60cbc:	mov    QWORD PTR [rsp+0x190],rdi
   60cc4:	mov    rdi,rcx
   60cc7:	mov    rcx,rax
   60cca:	mov    r10,rsi
   60ccd:	mov    rsi,r12
   60cd0:	call   r10
   60cd3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   60cde:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   60ce9:	mov    rdi,QWORD PTR [rsp+0x190]
   60cf1:	test   eax,eax
   60cf3:	je     60cf7 <sqlite3VdbeExec+0x11857>
   60cf5:	jmp    60d36 <sqlite3VdbeExec+0x11896>
   60cf7:	mov    rax,QWORD PTR [rbx]
   60cfa:	mov    rcx,QWORD PTR [rax+0x10]
   60cfe:	cmp    r12d,DWORD PTR [rcx+0x4]
   60d02:	je     60d29 <sqlite3VdbeExec+0x11889>
   60d04:	mov    rdx,QWORD PTR [rax+0x8]
   60d08:	mov    QWORD PTR [rcx+0x50],rdx
   60d0c:	mov    QWORD PTR [rcx+0x70],rax
   60d10:	mov    QWORD PTR [rcx+0x48],r15
   60d14:	mov    DWORD PTR [rcx+0x4],r12d
   60d18:	mov    eax,0x64
   60d1d:	xor    edx,edx
   60d1f:	cmp    r12d,0x1
   60d23:	cmove  edx,eax
   60d26:	mov    BYTE PTR [rcx+0x9],dl
   60d29:	lea    rbx,[rsp+0x1e8]
   60d31:	mov    QWORD PTR [rbx],rcx
   60d34:	xor    eax,eax
   60d36:	lea    rbx,[rsp+0x428]
   60d3e:	mov    DWORD PTR [rbx],eax
   60d40:	cmp    DWORD PTR [rbx],0x0
   60d43:	je     60e5b <sqlite3VdbeExec+0x119bb>
   60d49:	lea    r12,[rsp+0x1e8]
   60d51:	mov    rax,QWORD PTR [r12]
   60d55:	test   rax,rax
   60d58:	je     60e44 <sqlite3VdbeExec+0x119a4>
   60d5e:	mov    rax,QWORD PTR [rax+0x70]
   60d62:	movzx  ecx,WORD PTR [rax+0x34]
   60d66:	and    ecx,0x20
   60d69:	test   ecx,ecx
   60d6b:	je     60e00 <sqlite3VdbeExec+0x11960>
   60d71:	mov    rcx,QWORD PTR [rax+0x28]
   60d75:	mov    edx,DWORD PTR [rcx+0x98]
   60d7b:	sub    edx,0x1
   60d7e:	mov    DWORD PTR [rcx+0x98],edx
   60d84:	mov    rdx,QWORD PTR [rcx+0xa8]
   60d8b:	mov    QWORD PTR [rax+0x20],rdx
   60d8f:	mov    QWORD PTR [rcx+0xa8],rax
   60d96:	mov    rdx,QWORD PTR [rcx+0x48]
   60d9a:	mov    esi,DWORD PTR [rax+0x30]
   60d9d:	sub    esi,0x1
   60da0:	imul   rsi,QWORD PTR [rcx+0xc8]
   60da8:	mov    rax,QWORD PTR [rax+0x8]
   60dac:	mov    rcx,QWORD PTR [rdx]
   60daf:	mov    rcx,QWORD PTR [rcx+0x90]
   60db6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60dc1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60dcc:	mov    QWORD PTR [rsp+0x190],rdi
   60dd4:	mov    rdi,rdx
   60dd7:	mov    rdx,rax
   60dda:	mov    r10,rcx
   60ddd:	call   r10
   60de0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   60deb:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   60df6:	mov    rdi,QWORD PTR [rsp+0x190]
   60dfe:	jmp    60e44 <sqlite3VdbeExec+0x119a4>
   60e00:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60e0b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60e16:	mov    QWORD PTR [rsp+0x190],rdi
   60e1e:	mov    rdi,rax
   60e21:	call   60e26 <sqlite3VdbeExec+0x11986>
   60e26:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   60e31:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   60e3c:	mov    rdi,QWORD PTR [rsp+0x190]
   60e44:	mov    eax,DWORD PTR [rbx]
   60e46:	mov    r13,QWORD PTR [rsp+0x208]
   60e4e:	mov    rbx,QWORD PTR [rsp+0x1e0]
   60e56:	jmp    6185d <sqlite3VdbeExec+0x123bd>
   60e5b:	mov    DWORD PTR [rsp+0x41c],0x0
   60e66:	cmp    BYTE PTR [r15+0x21],0x0
   60e6b:	je     616ef <sqlite3VdbeExec+0x1224f>
   60e71:	mov    rax,QWORD PTR [r13+0x8]
   60e75:	mov    rcx,QWORD PTR [r13+0x8]
   60e79:	mov    rdx,QWORD PTR [r13+0x0]
   60e7d:	mov    QWORD PTR [rcx+0x8],rdx
   60e81:	mov    rax,QWORD PTR [rax+0x18]
   60e85:	mov    rax,QWORD PTR [rax+0x50]
   60e89:	movzx  ecx,BYTE PTR [rax+0x34]
   60e8d:	shl    ecx,0x18
   60e90:	movzx  edx,BYTE PTR [rax+0x35]
   60e94:	shl    edx,0x10
   60e97:	or     ecx,edx
   60e99:	movzx  edx,BYTE PTR [rax+0x36]
   60e9d:	shl    edx,0x8
   60ea0:	or     ecx,edx
   60ea2:	movzx  eax,BYTE PTR [rax+0x37]
   60ea6:	or     ecx,eax
   60ea8:	lea    rbx,[rsp+0x408]
   60eb0:	mov    DWORD PTR [rbx],ecx
   60eb2:	cmp    r12d,DWORD PTR [rbx]
   60eb5:	jne    61049 <sqlite3VdbeExec+0x11ba9>
   60ebb:	lea    r12,[rsp+0x1e8]
   60ec3:	mov    rax,QWORD PTR [r12]
   60ec7:	lea    rbx,[rsp+0x428]
   60ecf:	cmp    DWORD PTR [rbx],0x0
   60ed2:	jne    60f24 <sqlite3VdbeExec+0x11a84>
   60ed4:	mov    rcx,QWORD PTR [rax+0x48]
   60ed8:	mov    edx,DWORD PTR [rax+0x4]
   60edb:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60ee6:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60ef1:	mov    QWORD PTR [rsp+0x190],rdi
   60ef9:	mov    rdi,rcx
   60efc:	mov    rsi,rax
   60eff:	call   60f04 <sqlite3VdbeExec+0x11a64>
   60f04:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   60f0f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   60f1a:	mov    DWORD PTR [rbx],eax
   60f1c:	mov    rdi,QWORD PTR [rsp+0x190]
   60f24:	mov    rax,QWORD PTR [r12]
   60f28:	test   rax,rax
   60f2b:	je     61017 <sqlite3VdbeExec+0x11b77>
   60f31:	mov    rax,QWORD PTR [rax+0x70]
   60f35:	movzx  ecx,WORD PTR [rax+0x34]
   60f39:	and    ecx,0x20
   60f3c:	test   ecx,ecx
   60f3e:	je     60fd3 <sqlite3VdbeExec+0x11b33>
   60f44:	mov    rcx,QWORD PTR [rax+0x28]
   60f48:	mov    edx,DWORD PTR [rcx+0x98]
   60f4e:	sub    edx,0x1
   60f51:	mov    DWORD PTR [rcx+0x98],edx
   60f57:	mov    rdx,QWORD PTR [rcx+0xa8]
   60f5e:	mov    QWORD PTR [rax+0x20],rdx
   60f62:	mov    QWORD PTR [rcx+0xa8],rax
   60f69:	mov    rdx,QWORD PTR [rcx+0x48]
   60f6d:	mov    esi,DWORD PTR [rax+0x30]
   60f70:	sub    esi,0x1
   60f73:	imul   rsi,QWORD PTR [rcx+0xc8]
   60f7b:	mov    rax,QWORD PTR [rax+0x8]
   60f7f:	mov    rcx,QWORD PTR [rdx]
   60f82:	mov    rcx,QWORD PTR [rcx+0x90]
   60f89:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60f94:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60f9f:	mov    QWORD PTR [rsp+0x190],rdi
   60fa7:	mov    rdi,rdx
   60faa:	mov    rdx,rax
   60fad:	mov    r10,rcx
   60fb0:	call   r10
   60fb3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   60fbe:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   60fc9:	mov    rdi,QWORD PTR [rsp+0x190]
   60fd1:	jmp    61017 <sqlite3VdbeExec+0x11b77>
   60fd3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   60fde:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   60fe9:	mov    QWORD PTR [rsp+0x190],rdi
   60ff1:	mov    rdi,rax
   60ff4:	call   60ff9 <sqlite3VdbeExec+0x11b59>
   60ff9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61004:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6100f:	mov    rdi,QWORD PTR [rsp+0x190]
   61017:	cmp    DWORD PTR [rbx],0x0
   6101a:	jne    61032 <sqlite3VdbeExec+0x11b92>
   6101c:	mov    r11,rbp
   6101f:	mov    rbp,rbx
   61022:	mov    rbx,r11
   61025:	lea    r12,[rsp+0x408]
   6102d:	jmp    615f0 <sqlite3VdbeExec+0x12150>
   61032:	mov    eax,DWORD PTR [rbx]
   61034:	mov    r13,QWORD PTR [rsp+0x208]
   6103c:	mov    rbx,QWORD PTR [rsp+0x1e0]
   61044:	jmp    6185d <sqlite3VdbeExec+0x123bd>
   61049:	lea    rbx,[rsp+0x1e8]
   61051:	mov    rax,QWORD PTR [rbx]
   61054:	test   rax,rax
   61057:	je     61143 <sqlite3VdbeExec+0x11ca3>
   6105d:	mov    rax,QWORD PTR [rax+0x70]
   61061:	movzx  ecx,WORD PTR [rax+0x34]
   61065:	and    ecx,0x20
   61068:	test   ecx,ecx
   6106a:	je     610ff <sqlite3VdbeExec+0x11c5f>
   61070:	mov    rcx,QWORD PTR [rax+0x28]
   61074:	mov    edx,DWORD PTR [rcx+0x98]
   6107a:	sub    edx,0x1
   6107d:	mov    DWORD PTR [rcx+0x98],edx
   61083:	mov    rdx,QWORD PTR [rcx+0xa8]
   6108a:	mov    QWORD PTR [rax+0x20],rdx
   6108e:	mov    QWORD PTR [rcx+0xa8],rax
   61095:	mov    rdx,QWORD PTR [rcx+0x48]
   61099:	mov    esi,DWORD PTR [rax+0x30]
   6109c:	sub    esi,0x1
   6109f:	imul   rsi,QWORD PTR [rcx+0xc8]
   610a7:	mov    rax,QWORD PTR [rax+0x8]
   610ab:	mov    rcx,QWORD PTR [rdx]
   610ae:	mov    rcx,QWORD PTR [rcx+0x90]
   610b5:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   610c0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   610cb:	mov    QWORD PTR [rsp+0x190],rdi
   610d3:	mov    rdi,rdx
   610d6:	mov    rdx,rax
   610d9:	mov    r10,rcx
   610dc:	call   r10
   610df:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   610ea:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   610f5:	mov    rdi,QWORD PTR [rsp+0x190]
   610fd:	jmp    61143 <sqlite3VdbeExec+0x11ca3>
   610ff:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6110a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61115:	mov    QWORD PTR [rsp+0x190],rdi
   6111d:	mov    rdi,rax
   61120:	call   61125 <sqlite3VdbeExec+0x11c85>
   61125:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61130:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6113b:	mov    rdi,QWORD PTR [rsp+0x190]
   61143:	lea    rbx,[rsp+0x408]
   6114b:	mov    ebx,DWORD PTR [rbx]
   6114d:	xor    eax,eax
   6114f:	mov    rcx,QWORD PTR [r15]
   61152:	mov    DWORD PTR [rsp+0x418],r12d
   6115a:	lea    r12,[rsp+0x220]
   61162:	mov    rdx,r12
   61165:	mov    rsi,QWORD PTR [rcx+0x110]
   6116c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   61177:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61182:	mov    QWORD PTR [rsp+0x190],rdi
   6118a:	mov    rdi,rcx
   6118d:	mov    rcx,rax
   61190:	mov    r10,rsi
   61193:	mov    rsi,rbx
   61196:	call   r10
   61199:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   611a4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   611af:	mov    rdi,QWORD PTR [rsp+0x190]
   611b7:	test   eax,eax
   611b9:	je     611bd <sqlite3VdbeExec+0x11d1d>
   611bb:	jmp    611fa <sqlite3VdbeExec+0x11d5a>
   611bd:	mov    rax,QWORD PTR [r12]
   611c1:	mov    rcx,QWORD PTR [rax+0x10]
   611c5:	cmp    ebx,DWORD PTR [rcx+0x4]
   611c8:	je     611ed <sqlite3VdbeExec+0x11d4d>
   611ca:	mov    rdx,QWORD PTR [rax+0x8]
   611ce:	mov    QWORD PTR [rcx+0x50],rdx
   611d2:	mov    QWORD PTR [rcx+0x70],rax
   611d6:	mov    QWORD PTR [rcx+0x48],r15
   611da:	mov    DWORD PTR [rcx+0x4],ebx
   611dd:	mov    eax,0x64
   611e2:	xor    edx,edx
   611e4:	cmp    ebx,0x1
   611e7:	cmove  edx,eax
   611ea:	mov    BYTE PTR [rcx+0x9],dl
   611ed:	lea    rbx,[rsp+0x1c0]
   611f5:	mov    QWORD PTR [rbx],rcx
   611f8:	xor    eax,eax
   611fa:	lea    rbx,[rsp+0x428]
   61202:	mov    DWORD PTR [rbx],eax
   61204:	cmp    DWORD PTR [rbx],0x0
   61207:	je     61220 <sqlite3VdbeExec+0x11d80>
   61209:	mov    eax,DWORD PTR [rbx]
   6120b:	mov    r13,QWORD PTR [rsp+0x208]
   61213:	mov    rbx,QWORD PTR [rsp+0x1e0]
   6121b:	jmp    6185d <sqlite3VdbeExec+0x123bd>
   61220:	mov    r12d,DWORD PTR [rsp+0x418]
   61228:	mov    rbx,rbp
   6122b:	lea    rbp,[rsp+0x1c0]
   61233:	mov    rax,QWORD PTR [rbp+0x0]
   61237:	xor    ecx,ecx
   61239:	xor    edx,edx
   6123b:	mov    esi,0x1
   61240:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6124b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61256:	mov    QWORD PTR [rsp+0x190],rdi
   6125e:	mov    rdi,r15
   61261:	mov    r8,r12
   61264:	mov    r9,rdx
   61267:	mov    rdx,rsi
   6126a:	mov    rsi,rax
   6126d:	call   61272 <sqlite3VdbeExec+0x11dd2>
   61272:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6127d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   61288:	lea    r12,[rsp+0x428]
   61290:	mov    DWORD PTR [r12],eax
   61294:	mov    rax,QWORD PTR [rbp+0x0]
   61298:	mov    rdi,QWORD PTR [rsp+0x190]
   612a0:	test   rax,rax
   612a3:	je     6137f <sqlite3VdbeExec+0x11edf>
   612a9:	mov    rax,QWORD PTR [rax+0x70]
   612ad:	movzx  ecx,WORD PTR [rax+0x34]
   612b1:	and    ecx,0x20
   612b4:	test   ecx,ecx
   612b6:	je     61343 <sqlite3VdbeExec+0x11ea3>
   612bc:	mov    rcx,QWORD PTR [rax+0x28]
   612c0:	mov    edx,DWORD PTR [rcx+0x98]
   612c6:	sub    edx,0x1
   612c9:	mov    DWORD PTR [rcx+0x98],edx
   612cf:	mov    rdx,QWORD PTR [rcx+0xa8]
   612d6:	mov    QWORD PTR [rax+0x20],rdx
   612da:	mov    QWORD PTR [rcx+0xa8],rax
   612e1:	mov    rdx,QWORD PTR [rcx+0x48]
   612e5:	mov    esi,DWORD PTR [rax+0x30]
   612e8:	sub    esi,0x1
   612eb:	imul   rsi,QWORD PTR [rcx+0xc8]
   612f3:	mov    rax,QWORD PTR [rax+0x8]
   612f7:	mov    rcx,QWORD PTR [rdx]
   612fa:	mov    rcx,QWORD PTR [rcx+0x90]
   61301:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6130c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61317:	mov    rdi,rdx
   6131a:	mov    rdx,rax
   6131d:	mov    r10,rcx
   61320:	call   r10
   61323:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6132e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   61339:	mov    rdi,QWORD PTR [rsp+0x190]
   61341:	jmp    6137f <sqlite3VdbeExec+0x11edf>
   61343:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6134e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61359:	mov    rdi,rax
   6135c:	call   61361 <sqlite3VdbeExec+0x11ec1>
   61361:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6136c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   61377:	mov    rdi,QWORD PTR [rsp+0x190]
   6137f:	cmp    DWORD PTR [r12],0x0
   61384:	je     613a2 <sqlite3VdbeExec+0x11f02>
   61386:	mov    eax,DWORD PTR [r12]
   6138a:	mov    r13,QWORD PTR [rsp+0x208]
   61392:	mov    rbp,rbx
   61395:	mov    rbx,QWORD PTR [rsp+0x1e0]
   6139d:	jmp    6185d <sqlite3VdbeExec+0x123bd>
   613a2:	mov    QWORD PTR [rbp+0x0],0x0
   613aa:	lea    rbp,[rsp+0x408]
   613b2:	mov    ebp,DWORD PTR [rbp+0x0]
   613b5:	xor    eax,eax
   613b7:	lea    r12,[rsp+0x220]
   613bf:	mov    rcx,QWORD PTR [r15]
   613c2:	mov    rdx,r12
   613c5:	mov    rsi,QWORD PTR [rcx+0x110]
   613cc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   613d7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   613e2:	mov    QWORD PTR [rsp+0x190],rdi
   613ea:	mov    rdi,rcx
   613ed:	mov    rcx,rax
   613f0:	mov    r10,rsi
   613f3:	mov    rsi,rbp
   613f6:	call   r10
   613f9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61404:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6140f:	mov    rdi,QWORD PTR [rsp+0x190]
   61417:	test   eax,eax
   61419:	je     6141d <sqlite3VdbeExec+0x11f7d>
   6141b:	jmp    6145b <sqlite3VdbeExec+0x11fbb>
   6141d:	mov    rax,QWORD PTR [r12]
   61421:	mov    rcx,QWORD PTR [rax+0x10]
   61425:	cmp    ebp,DWORD PTR [rcx+0x4]
   61428:	je     6144d <sqlite3VdbeExec+0x11fad>
   6142a:	mov    rdx,QWORD PTR [rax+0x8]
   6142e:	mov    QWORD PTR [rcx+0x50],rdx
   61432:	mov    QWORD PTR [rcx+0x70],rax
   61436:	mov    QWORD PTR [rcx+0x48],r15
   6143a:	mov    DWORD PTR [rcx+0x4],ebp
   6143d:	mov    eax,0x64
   61442:	xor    edx,edx
   61444:	cmp    ebp,0x1
   61447:	cmove  edx,eax
   6144a:	mov    BYTE PTR [rcx+0x9],dl
   6144d:	lea    rbp,[rsp+0x1c0]
   61455:	mov    QWORD PTR [rbp+0x0],rcx
   61459:	xor    eax,eax
   6145b:	lea    rbp,[rsp+0x428]
   61463:	mov    DWORD PTR [rbp+0x0],eax
   61466:	lea    r12,[rsp+0x1c0]
   6146e:	mov    rax,QWORD PTR [r12]
   61472:	cmp    DWORD PTR [rbp+0x0],0x0
   61476:	jne    614c9 <sqlite3VdbeExec+0x12029>
   61478:	mov    rcx,QWORD PTR [rax+0x48]
   6147c:	mov    edx,DWORD PTR [rax+0x4]
   6147f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6148a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61495:	mov    QWORD PTR [rsp+0x190],rdi
   6149d:	mov    rdi,rcx
   614a0:	mov    rsi,rax
   614a3:	call   614a8 <sqlite3VdbeExec+0x12008>
   614a8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   614b3:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   614be:	mov    DWORD PTR [rbp+0x0],eax
   614c1:	mov    rdi,QWORD PTR [rsp+0x190]
   614c9:	mov    rax,QWORD PTR [r12]
   614cd:	test   rax,rax
   614d0:	je     615bc <sqlite3VdbeExec+0x1211c>
   614d6:	mov    rax,QWORD PTR [rax+0x70]
   614da:	movzx  ecx,WORD PTR [rax+0x34]
   614de:	and    ecx,0x20
   614e1:	test   ecx,ecx
   614e3:	je     61578 <sqlite3VdbeExec+0x120d8>
   614e9:	mov    rcx,QWORD PTR [rax+0x28]
   614ed:	mov    edx,DWORD PTR [rcx+0x98]
   614f3:	sub    edx,0x1
   614f6:	mov    DWORD PTR [rcx+0x98],edx
   614fc:	mov    rdx,QWORD PTR [rcx+0xa8]
   61503:	mov    QWORD PTR [rax+0x20],rdx
   61507:	mov    QWORD PTR [rcx+0xa8],rax
   6150e:	mov    rdx,QWORD PTR [rcx+0x48]
   61512:	mov    esi,DWORD PTR [rax+0x30]
   61515:	sub    esi,0x1
   61518:	imul   rsi,QWORD PTR [rcx+0xc8]
   61520:	mov    rax,QWORD PTR [rax+0x8]
   61524:	mov    rcx,QWORD PTR [rdx]
   61527:	mov    rcx,QWORD PTR [rcx+0x90]
   6152e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   61539:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61544:	mov    QWORD PTR [rsp+0x190],rdi
   6154c:	mov    rdi,rdx
   6154f:	mov    rdx,rax
   61552:	mov    r10,rcx
   61555:	call   r10
   61558:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61563:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6156e:	mov    rdi,QWORD PTR [rsp+0x190]
   61576:	jmp    615bc <sqlite3VdbeExec+0x1211c>
   61578:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   61583:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6158e:	mov    QWORD PTR [rsp+0x190],rdi
   61596:	mov    rdi,rax
   61599:	call   6159e <sqlite3VdbeExec+0x120fe>
   6159e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   615a9:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   615b4:	mov    rdi,QWORD PTR [rsp+0x190]
   615bc:	cmp    DWORD PTR [rbp+0x0],0x0
   615c0:	je     615dd <sqlite3VdbeExec+0x1213d>
   615c2:	mov    eax,DWORD PTR [rbp+0x0]
   615c5:	mov    r13,QWORD PTR [rsp+0x208]
   615cd:	mov    rbp,rbx
   615d0:	mov    rbx,QWORD PTR [rsp+0x1e0]
   615d8:	jmp    6185d <sqlite3VdbeExec+0x123bd>
   615dd:	lea    r12,[rsp+0x408]
   615e5:	mov    eax,DWORD PTR [r12]
   615e9:	mov    DWORD PTR [rsp+0x41c],eax
   615f0:	mov    eax,DWORD PTR [r12]
   615f4:	sub    eax,0x1
   615f7:	mov    DWORD PTR [r12],eax
   615fb:	jmp    61661 <sqlite3VdbeExec+0x121c1>
   615fd:	mov    eax,DWORD PTR [r15+0x38]
   61601:	mov    edx,0xcccccccd
   61606:	mul    edx
   61608:	shr    edx,0x2
   6160b:	mov    eax,edx
   6160d:	lea    esi,[rax+0x1]
   61610:	sub    ecx,0x2
   61613:	mov    rax,rcx
   61616:	xor    edx,edx
   61618:	div    esi
   6161a:	imul   eax,esi
   6161d:	lea    ecx,[rax+0x2]
   61620:	mov    eax,DWORD PTR [rip+0x0]        # 61626 <sqlite3VdbeExec+0x12186>
   61626:	mov    esi,DWORD PTR [r15+0x34]
   6162a:	xor    edx,edx
   6162c:	div    esi
   6162e:	add    eax,0x1
   61631:	xor    edx,edx
   61633:	mov    esi,0x1
   61638:	cmp    ecx,eax
   6163a:	cmove  edx,esi
   6163d:	lea    eax,[rcx+rdx*1]
   61640:	lea    rbp,[rsp+0x428]
   61648:	lea    r12,[rsp+0x408]
   61650:	cmp    eax,DWORD PTR [r12]
   61654:	jne    6168b <sqlite3VdbeExec+0x121eb>
   61656:	mov    eax,DWORD PTR [r12]
   6165a:	sub    eax,0x1
   6165d:	mov    DWORD PTR [r12],eax
   61661:	mov    ecx,DWORD PTR [r12]
   61665:	mov    eax,DWORD PTR [rip+0x0]        # 6166b <sqlite3VdbeExec+0x121cb>
   6166b:	mov    esi,DWORD PTR [r15+0x34]
   6166f:	xor    edx,edx
   61671:	div    esi
   61673:	add    eax,0x1
   61676:	cmp    ecx,eax
   61678:	je     61656 <sqlite3VdbeExec+0x121b6>
   6167a:	mov    ecx,DWORD PTR [r12]
   6167e:	cmp    ecx,0x2
   61681:	jae    615fd <sqlite3VdbeExec+0x1215d>
   61687:	xor    eax,eax
   61689:	jmp    61650 <sqlite3VdbeExec+0x121b0>
   6168b:	mov    eax,0x4
   61690:	mov    ecx,DWORD PTR [r12]
   61694:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6169f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   616aa:	mov    QWORD PTR [rsp+0x190],rdi
   616b2:	mov    rdi,r13
   616b5:	mov    rsi,rax
   616b8:	mov    rdx,rcx
   616bb:	call   616c0 <sqlite3VdbeExec+0x12220>
   616c0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   616cb:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   616d6:	mov    DWORD PTR [rbp+0x0],eax
   616d9:	mov    rdi,QWORD PTR [rsp+0x190]
   616e1:	mov    r11,rbx
   616e4:	mov    rbx,rbp
   616e7:	mov    rbp,r11
   616ea:	jmp    6184b <sqlite3VdbeExec+0x123ab>
   616ef:	lea    rbx,[rsp+0x428]
   616f7:	lea    r12,[rsp+0x1e8]
   616ff:	mov    rax,QWORD PTR [r12]
   61703:	cmp    DWORD PTR [rbx],0x0
   61706:	jne    61758 <sqlite3VdbeExec+0x122b8>
   61708:	mov    rcx,QWORD PTR [rax+0x48]
   6170c:	mov    edx,DWORD PTR [rax+0x4]
   6170f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6171a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61725:	mov    QWORD PTR [rsp+0x190],rdi
   6172d:	mov    rdi,rcx
   61730:	mov    rsi,rax
   61733:	call   61738 <sqlite3VdbeExec+0x12298>
   61738:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61743:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6174e:	mov    DWORD PTR [rbx],eax
   61750:	mov    rdi,QWORD PTR [rsp+0x190]
   61758:	mov    rax,QWORD PTR [r12]
   6175c:	test   rax,rax
   6175f:	je     6184b <sqlite3VdbeExec+0x123ab>
   61765:	mov    rax,QWORD PTR [rax+0x70]
   61769:	movzx  ecx,WORD PTR [rax+0x34]
   6176d:	and    ecx,0x20
   61770:	test   ecx,ecx
   61772:	je     61807 <sqlite3VdbeExec+0x12367>
   61778:	mov    rcx,QWORD PTR [rax+0x28]
   6177c:	mov    edx,DWORD PTR [rcx+0x98]
   61782:	sub    edx,0x1
   61785:	mov    DWORD PTR [rcx+0x98],edx
   6178b:	mov    rdx,QWORD PTR [rcx+0xa8]
   61792:	mov    QWORD PTR [rax+0x20],rdx
   61796:	mov    QWORD PTR [rcx+0xa8],rax
   6179d:	mov    rdx,QWORD PTR [rcx+0x48]
   617a1:	mov    esi,DWORD PTR [rax+0x30]
   617a4:	sub    esi,0x1
   617a7:	imul   rsi,QWORD PTR [rcx+0xc8]
   617af:	mov    rax,QWORD PTR [rax+0x8]
   617b3:	mov    rcx,QWORD PTR [rdx]
   617b6:	mov    rcx,QWORD PTR [rcx+0x90]
   617bd:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   617c8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   617d3:	mov    QWORD PTR [rsp+0x190],rdi
   617db:	mov    rdi,rdx
   617de:	mov    rdx,rax
   617e1:	mov    r10,rcx
   617e4:	call   r10
   617e7:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   617f2:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   617fd:	mov    rdi,QWORD PTR [rsp+0x190]
   61805:	jmp    6184b <sqlite3VdbeExec+0x123ab>
   61807:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   61812:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6181d:	mov    QWORD PTR [rsp+0x190],rdi
   61825:	mov    rdi,rax
   61828:	call   6182d <sqlite3VdbeExec+0x1238d>
   6182d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61838:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   61843:	mov    rdi,QWORD PTR [rsp+0x190]
   6184b:	mov    eax,DWORD PTR [rbx]
   6184d:	mov    r13,QWORD PTR [rsp+0x208]
   61855:	mov    rbx,QWORD PTR [rsp+0x1e0]
   6185d:	mov    r12d,eax
   61860:	mov    WORD PTR [r13+0x14],0x4
   61867:	movsxd rax,DWORD PTR [rsp+0x41c]
   6186f:	mov    QWORD PTR [r13+0x0],rax
   61873:	test   r12d,r12d
   61876:	je     61898 <sqlite3VdbeExec+0x123f8>
   61878:	mov    QWORD PTR [rsp+0x1c8],rbp
   61880:	mov    rbp,r12
   61883:	mov    r13,QWORD PTR [rsp+0x1b0]
   6188b:	mov    rbx,QWORD PTR [rsp+0x1d8]
   61893:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   61898:	cmp    DWORD PTR [rsp+0x41c],0x0
   618a0:	je     6190f <sqlite3VdbeExec+0x1246f>
   618a2:	mov    eax,DWORD PTR [rsp+0x41c]
   618a9:	mov    ecx,DWORD PTR [rbp+0x4]
   618ac:	mov    rdx,QWORD PTR [r14+0x20]
   618b0:	mov    r13,QWORD PTR [rsp+0x210]
   618b8:	mov    rsi,r13
   618bb:	shl    rsi,0x5
   618bf:	mov    r8,QWORD PTR [rdx+rsi*1+0x18]
   618c4:	mov    r8,QWORD PTR [r8+0x10]
   618c8:	jmp    618db <sqlite3VdbeExec+0x1243b>
   618ca:	mov    r9,QWORD PTR [r8+0x10]
   618ce:	cmp    eax,DWORD PTR [r9+0x28]
   618d2:	jne    618d8 <sqlite3VdbeExec+0x12438>
   618d4:	mov    DWORD PTR [r9+0x28],ecx
   618d8:	mov    r8,QWORD PTR [r8]
   618db:	test   r8,r8
   618de:	jne    618ca <sqlite3VdbeExec+0x1242a>
   618e0:	mov    rdx,QWORD PTR [rdx+rsi*1+0x18]
   618e5:	mov    rdx,QWORD PTR [rdx+0x28]
   618e9:	jmp    618fa <sqlite3VdbeExec+0x1245a>
   618eb:	mov    rsi,QWORD PTR [rdx+0x10]
   618ef:	cmp    eax,DWORD PTR [rsi+0x58]
   618f2:	jne    618f7 <sqlite3VdbeExec+0x12457>
   618f4:	mov    DWORD PTR [rsi+0x58],ecx
   618f7:	mov    rdx,QWORD PTR [rdx]
   618fa:	test   rdx,rdx
   618fd:	jne    618eb <sqlite3VdbeExec+0x1244b>
   618ff:	lea    eax,[r13+0x1]
   61903:	movzx  r13d,al
   61907:	mov    DWORD PTR [rsp+0x400],r13d
   6190f:	mov    DWORD PTR [rsp+0x40c],r12d
   61917:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6191c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   61924:	mov    r13,QWORD PTR [rsp+0x1d0]
   6192c:	mov    QWORD PTR [rsp+0x1b0],r12
   61934:	mov    r12d,DWORD PTR [rsp+0x414]
   6193c:	mov    QWORD PTR [rsp+0x210],0x0
   61948:	mov    rax,QWORD PTR [r14+0x20]
   6194c:	movsxd rcx,DWORD PTR [rbp+0x8]
   61950:	shl    rcx,0x5
   61954:	mov    DWORD PTR [rsp+0x414],r12d
   6195c:	mov    r12,QWORD PTR [rax+rcx*1+0x8]
   61961:	mov    QWORD PTR [rsp+0x1d0],r13
   61969:	mov    r13d,DWORD PTR [rbp+0x4]
   6196d:	mov    DWORD PTR [rsp+0x41c],r13d
   61975:	lea    r13,[rsp+0x210]
   6197d:	mov    r13,QWORD PTR [r12+0x8]
   61982:	mov    rax,QWORD PTR [r12+0x8]
   61987:	mov    rcx,QWORD PTR [r12]
   6198b:	mov    QWORD PTR [rax+0x8],rcx
   6198f:	xor    eax,eax
   61991:	mov    rcx,QWORD PTR [r13+0x10]
   61995:	jmp    619fb <sqlite3VdbeExec+0x1255b>
   61997:	test   rcx,rcx
   6199a:	jne    619ae <sqlite3VdbeExec+0x1250e>
   6199c:	mov    QWORD PTR [rsp+0x208],r13
   619a4:	mov    r13d,DWORD PTR [rsp+0x41c]
   619ac:	jmp    619e7 <sqlite3VdbeExec+0x12547>
   619ae:	xor    edx,edx
   619b0:	mov    QWORD PTR [rsp+0x208],r13
   619b8:	mov    r13d,DWORD PTR [rsp+0x41c]
   619c0:	cmp    edx,r13d
   619c3:	jne    619cf <sqlite3VdbeExec+0x1252f>
   619c5:	mov    r13,QWORD PTR [rsp+0x208]
   619cd:	jmp    61a00 <sqlite3VdbeExec+0x12560>
   619cf:	cmp    r13d,DWORD PTR [rcx+0x50]
   619d3:	jne    619e7 <sqlite3VdbeExec+0x12547>
   619d5:	mov    DWORD PTR [rsp+0x41c],r13d
   619dd:	mov    r13,QWORD PTR [rsp+0x208]
   619e5:	jmp    61a00 <sqlite3VdbeExec+0x12560>
   619e7:	mov    rcx,QWORD PTR [rcx+0x28]
   619eb:	mov    DWORD PTR [rsp+0x41c],r13d
   619f3:	mov    r13,QWORD PTR [rsp+0x208]
   619fb:	test   rcx,rcx
   619fe:	jne    61997 <sqlite3VdbeExec+0x124f7>
   61a00:	test   rcx,rcx
   61a03:	jne    61a17 <sqlite3VdbeExec+0x12577>
   61a05:	mov    QWORD PTR [rsp+0x208],r13
   61a0d:	mov    r13d,DWORD PTR [rsp+0x41c]
   61a15:	jmp    61a7b <sqlite3VdbeExec+0x125db>
   61a17:	mov    QWORD PTR [rsp+0x208],r13
   61a1f:	mov    r13d,DWORD PTR [rsp+0x41c]
   61a27:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   61a32:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61a3d:	mov    QWORD PTR [rsp+0x190],rdi
   61a45:	mov    rdi,rcx
   61a48:	mov    rsi,r13
   61a4b:	mov    rdx,rax
   61a4e:	call   61a53 <sqlite3VdbeExec+0x125b3>
   61a53:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61a5e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   61a69:	xor    ecx,ecx
   61a6b:	mov    rdi,QWORD PTR [rsp+0x190]
   61a73:	cmp    ecx,eax
   61a75:	jne    61b26 <sqlite3VdbeExec+0x12686>
   61a7b:	cmp    BYTE PTR [r12+0x13],0x0
   61a81:	je     61ab7 <sqlite3VdbeExec+0x12617>
   61a83:	mov    BYTE PTR [r12+0x13],0x0
   61a89:	mov    rax,QWORD PTR [r12+0x8]
   61a8e:	mov    rax,QWORD PTR [rax+0x10]
   61a92:	jmp    61ab2 <sqlite3VdbeExec+0x12612>
   61a94:	movzx  ecx,BYTE PTR [rax+0x1]
   61a98:	and    ecx,0x10
   61a9b:	test   ecx,ecx
   61a9d:	je     61aae <sqlite3VdbeExec+0x1260e>
   61a9f:	mov    BYTE PTR [r12+0x13],0x1
   61aa5:	cmp    r13d,DWORD PTR [rax+0x50]
   61aa9:	jne    61aae <sqlite3VdbeExec+0x1260e>
   61aab:	mov    BYTE PTR [rax],0x1
   61aae:	mov    rax,QWORD PTR [rax+0x28]
   61ab2:	test   rax,rax
   61ab5:	jne    61a94 <sqlite3VdbeExec+0x125f4>
   61ab7:	xor    eax,eax
   61ab9:	mov    DWORD PTR [rsp+0x3fc],r15d
   61ac1:	lea    r12,[rsp+0x210]
   61ac9:	mov    r15,QWORD PTR [rsp+0x208]
   61ad1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   61adc:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61ae7:	mov    QWORD PTR [rsp+0x190],rdi
   61aef:	mov    rdi,r15
   61af2:	mov    rsi,r13
   61af5:	mov    rdx,rax
   61af8:	mov    rcx,r12
   61afb:	call   61b00 <sqlite3VdbeExec+0x12660>
   61b00:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61b0b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   61b16:	mov    rdi,QWORD PTR [rsp+0x190]
   61b1e:	mov    r15d,DWORD PTR [rsp+0x3fc]
   61b26:	mov    r12d,eax
   61b29:	cmp    DWORD PTR [rbp+0xc],0x0
   61b2d:	je     61b5d <sqlite3VdbeExec+0x126bd>
   61b2f:	mov    rax,QWORD PTR [rdi+0x38]
   61b33:	add    rax,QWORD PTR [rsp+0x210]
   61b3b:	mov    QWORD PTR [rdi+0x38],rax
   61b3f:	cmp    DWORD PTR [rbp+0xc],0x0
   61b43:	jle    61b5d <sqlite3VdbeExec+0x126bd>
   61b45:	movsxd rax,DWORD PTR [rbp+0xc]
   61b49:	imul   rax,rax,0x38
   61b4d:	mov    rcx,QWORD PTR [rbx+rax*1]
   61b51:	add    rcx,QWORD PTR [rsp+0x210]
   61b59:	mov    QWORD PTR [rbx+rax*1],rcx
   61b5d:	test   r12d,r12d
   61b60:	je     61b82 <sqlite3VdbeExec+0x126e2>
   61b62:	mov    QWORD PTR [rsp+0x1c8],rbp
   61b6a:	mov    rbp,r12
   61b6d:	mov    r13,QWORD PTR [rsp+0x1b0]
   61b75:	mov    rbx,QWORD PTR [rsp+0x1d8]
   61b7d:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   61b82:	mov    DWORD PTR [rsp+0x3fc],r15d
   61b8a:	mov    DWORD PTR [rsp+0x40c],r12d
   61b92:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   61b97:	mov    r15d,DWORD PTR [rsp+0x3fc]
   61b9f:	mov    r13,QWORD PTR [rsp+0x1d0]
   61ba7:	mov    QWORD PTR [rsp+0x1b0],r12
   61baf:	mov    r12d,DWORD PTR [rsp+0x414]
   61bb7:	mov    rax,QWORD PTR [rdi+0x78]
   61bbb:	movsxd rcx,DWORD PTR [rbp+0x4]
   61bbf:	mov    rax,QWORD PTR [rax+rcx*8]
   61bc3:	cmp    BYTE PTR [rax],0x1
   61bc6:	jne    61c30 <sqlite3VdbeExec+0x12790>
   61bc8:	mov    rax,QWORD PTR [rax+0x28]
   61bcc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   61bd7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61be2:	mov    QWORD PTR [rsp+0x190],rdi
   61bea:	mov    rdi,r14
   61bed:	mov    rsi,rax
   61bf0:	call   61bf5 <sqlite3VdbeExec+0x12755>
   61bf5:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61c00:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   61c0b:	mov    rdi,QWORD PTR [rsp+0x190]
   61c13:	mov    DWORD PTR [rsp+0x3fc],r15d
   61c1b:	mov    QWORD PTR [rsp+0x1d0],r13
   61c23:	mov    DWORD PTR [rsp+0x414],r12d
   61c2b:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   61c30:	mov    rax,QWORD PTR [rax+0x28]
   61c34:	mov    DWORD PTR [rsp+0x414],r12d
   61c3c:	mov    r12,QWORD PTR [rax+0x8]
   61c40:	mov    QWORD PTR [rsp+0x1d0],r13
   61c48:	mov    r13d,DWORD PTR [rax+0x50]
   61c4c:	mov    DWORD PTR [rsp+0x41c],r13d
   61c54:	mov    r13,QWORD PTR [r12+0x8]
   61c59:	mov    rax,QWORD PTR [r12+0x8]
   61c5e:	mov    rcx,QWORD PTR [r12]
   61c62:	mov    QWORD PTR [rax+0x8],rcx
   61c66:	xor    eax,eax
   61c68:	mov    rcx,QWORD PTR [r13+0x10]
   61c6c:	jmp    61cd2 <sqlite3VdbeExec+0x12832>
   61c6e:	test   rcx,rcx
   61c71:	jne    61c85 <sqlite3VdbeExec+0x127e5>
   61c73:	mov    QWORD PTR [rsp+0x210],r13
   61c7b:	mov    r13d,DWORD PTR [rsp+0x41c]
   61c83:	jmp    61cbe <sqlite3VdbeExec+0x1281e>
   61c85:	xor    edx,edx
   61c87:	mov    QWORD PTR [rsp+0x210],r13
   61c8f:	mov    r13d,DWORD PTR [rsp+0x41c]
   61c97:	cmp    edx,r13d
   61c9a:	jne    61ca6 <sqlite3VdbeExec+0x12806>
   61c9c:	mov    r13,QWORD PTR [rsp+0x210]
   61ca4:	jmp    61cd7 <sqlite3VdbeExec+0x12837>
   61ca6:	cmp    r13d,DWORD PTR [rcx+0x50]
   61caa:	jne    61cbe <sqlite3VdbeExec+0x1281e>
   61cac:	mov    DWORD PTR [rsp+0x41c],r13d
   61cb4:	mov    r13,QWORD PTR [rsp+0x210]
   61cbc:	jmp    61cd7 <sqlite3VdbeExec+0x12837>
   61cbe:	mov    rcx,QWORD PTR [rcx+0x28]
   61cc2:	mov    DWORD PTR [rsp+0x41c],r13d
   61cca:	mov    r13,QWORD PTR [rsp+0x210]
   61cd2:	test   rcx,rcx
   61cd5:	jne    61c6e <sqlite3VdbeExec+0x127ce>
   61cd7:	test   rcx,rcx
   61cda:	jne    61cee <sqlite3VdbeExec+0x1284e>
   61cdc:	mov    QWORD PTR [rsp+0x210],r13
   61ce4:	mov    r13d,DWORD PTR [rsp+0x41c]
   61cec:	jmp    61d63 <sqlite3VdbeExec+0x128c3>
   61cee:	mov    QWORD PTR [rsp+0x210],r13
   61cf6:	mov    r13d,DWORD PTR [rsp+0x41c]
   61cfe:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   61d09:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61d14:	mov    QWORD PTR [rsp+0x190],rdi
   61d1c:	mov    rdi,rcx
   61d1f:	mov    rsi,r13
   61d22:	mov    rdx,rax
   61d25:	call   61d2a <sqlite3VdbeExec+0x1288a>
   61d2a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61d35:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   61d40:	xor    ecx,ecx
   61d42:	mov    rdi,QWORD PTR [rsp+0x190]
   61d4a:	cmp    ecx,eax
   61d4c:	je     61d63 <sqlite3VdbeExec+0x128c3>
   61d4e:	mov    r13,QWORD PTR [rsp+0x1d0]
   61d56:	mov    r12d,DWORD PTR [rsp+0x414]
   61d5e:	jmp    61e19 <sqlite3VdbeExec+0x12979>
   61d63:	cmp    BYTE PTR [r12+0x13],0x0
   61d69:	je     61d9f <sqlite3VdbeExec+0x128ff>
   61d6b:	mov    BYTE PTR [r12+0x13],0x0
   61d71:	mov    rax,QWORD PTR [r12+0x8]
   61d76:	mov    rax,QWORD PTR [rax+0x10]
   61d7a:	jmp    61d9a <sqlite3VdbeExec+0x128fa>
   61d7c:	movzx  ecx,BYTE PTR [rax+0x1]
   61d80:	and    ecx,0x10
   61d83:	test   ecx,ecx
   61d85:	je     61d96 <sqlite3VdbeExec+0x128f6>
   61d87:	mov    BYTE PTR [r12+0x13],0x1
   61d8d:	cmp    r13d,DWORD PTR [rax+0x50]
   61d91:	jne    61d96 <sqlite3VdbeExec+0x128f6>
   61d93:	mov    BYTE PTR [rax],0x1
   61d96:	mov    rax,QWORD PTR [rax+0x28]
   61d9a:	test   rax,rax
   61d9d:	jne    61d7c <sqlite3VdbeExec+0x128dc>
   61d9f:	xor    eax,eax
   61da1:	mov    DWORD PTR [rsp+0x3fc],r15d
   61da9:	xor    r12d,r12d
   61dac:	mov    r15,QWORD PTR [rsp+0x210]
   61db4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   61dbf:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61dca:	mov    QWORD PTR [rsp+0x190],rdi
   61dd2:	mov    rdi,r15
   61dd5:	mov    rsi,r13
   61dd8:	mov    rdx,rax
   61ddb:	mov    rcx,r12
   61dde:	call   61de3 <sqlite3VdbeExec+0x12943>
   61de3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61dee:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   61df9:	mov    rdi,QWORD PTR [rsp+0x190]
   61e01:	mov    r15d,DWORD PTR [rsp+0x3fc]
   61e09:	mov    r13,QWORD PTR [rsp+0x1d0]
   61e11:	mov    r12d,DWORD PTR [rsp+0x414]
   61e19:	mov    QWORD PTR [rsp+0x1d0],r13
   61e21:	mov    r13d,eax
   61e24:	test   r13d,r13d
   61e27:	jne    61e3e <sqlite3VdbeExec+0x1299e>
   61e29:	mov    DWORD PTR [rsp+0x40c],r13d
   61e31:	mov    r13,QWORD PTR [rsp+0x1d0]
   61e39:	jmp    61c13 <sqlite3VdbeExec+0x12773>
   61e3e:	mov    QWORD PTR [rsp+0x1c8],rbp
   61e46:	mov    rbp,r13
   61e49:	mov    r13,QWORD PTR [rsp+0x1b0]
   61e51:	mov    rbx,QWORD PTR [rsp+0x1d8]
   61e59:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   61e5e:	mov    r15d,DWORD PTR [rsp+0x3fc]
   61e66:	mov    r13,QWORD PTR [rsp+0x1d0]
   61e6e:	mov    QWORD PTR [rsp+0x1b0],r12
   61e76:	mov    r12d,DWORD PTR [rsp+0x414]
   61e7e:	mov    rax,QWORD PTR [rdi+0x68]
   61e82:	movsxd rcx,DWORD PTR [rbp+0x8]
   61e86:	imul   rcx,rcx,0x38
   61e8a:	mov    DWORD PTR [rsp+0x414],r12d
   61e92:	lea    r12,[rax+rcx*1]
   61e96:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   61e9b:	and    eax,0x9000
   61ea0:	test   eax,eax
   61ea2:	je     61eed <sqlite3VdbeExec+0x12a4d>
   61ea4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   61eaf:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61eba:	mov    QWORD PTR [rsp+0x190],rdi
   61ec2:	mov    rdi,r12
   61ec5:	call   61eca <sqlite3VdbeExec+0x12a2a>
   61eca:	mov    r12,rax
   61ecd:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61ed8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   61ee3:	mov    rdi,QWORD PTR [rsp+0x190]
   61eeb:	jmp    61ef5 <sqlite3VdbeExec+0x12a55>
   61eed:	mov    WORD PTR [r12+0x14],0x4
   61ef5:	mov    DWORD PTR [rsp+0x41c],0x0
   61f00:	mov    rax,QWORD PTR [r14+0x20]
   61f04:	movsxd rcx,DWORD PTR [rbp+0x4]
   61f08:	shl    rcx,0x5
   61f0c:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   61f11:	mov    QWORD PTR [rsp+0x1d0],r13
   61f19:	lea    r13,[rsp+0x41c]
   61f21:	mov    rcx,r13
   61f24:	mov    edx,DWORD PTR [rbp+0xc]
   61f27:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   61f32:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   61f3d:	mov    QWORD PTR [rsp+0x190],rdi
   61f45:	mov    rdi,rax
   61f48:	mov    rsi,rcx
   61f4b:	call   61f50 <sqlite3VdbeExec+0x12ab0>
   61f50:	mov    r13d,eax
   61f53:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   61f5e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   61f69:	mov    rdi,QWORD PTR [rsp+0x190]
   61f71:	test   r13d,r13d
   61f74:	je     61f96 <sqlite3VdbeExec+0x12af6>
   61f76:	mov    QWORD PTR [rsp+0x1c8],rbp
   61f7e:	mov    rbp,r13
   61f81:	mov    r13,QWORD PTR [rsp+0x1b0]
   61f89:	mov    rbx,QWORD PTR [rsp+0x1d8]
   61f91:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   61f96:	mov    eax,DWORD PTR [rsp+0x41c]
   61f9d:	mov    QWORD PTR [r12],rax
   61fa1:	mov    DWORD PTR [rsp+0x3fc],r15d
   61fa9:	mov    DWORD PTR [rsp+0x40c],r13d
   61fb1:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   61fb6:	mov    r15d,DWORD PTR [rsp+0x3fc]
   61fbe:	mov    QWORD PTR [rsp+0x1b0],r12
   61fc6:	movzx  eax,BYTE PTR [r14+0x70]
   61fcb:	add    eax,0x1
   61fce:	mov    BYTE PTR [r14+0x70],al
   61fd2:	mov    QWORD PTR [rsp+0x210],0x0
   61fde:	mov    r12,QWORD PTR [r14+0x1f8]
   61fe5:	movzx  r13d,BYTE PTR [r14+0x6e]
   61fea:	mov    DWORD PTR [rsp+0x3fc],r15d
   61ff2:	mov    r15d,DWORD PTR [r14+0x2e0]
   61ff9:	mov    eax,DWORD PTR [rbp+0x4]
   61ffc:	and    eax,0x1
   61fff:	test   eax,eax
   62001:	je     62013 <sqlite3VdbeExec+0x12b73>
   62003:	mov    QWORD PTR [r14+0x1f8],0x0
   6200e:	mov    BYTE PTR [r14+0x6e],0x0
   62013:	mov    eax,DWORD PTR [rbp+0x4]
   62016:	and    eax,0x2
   62019:	test   eax,eax
   6201b:	je     62027 <sqlite3VdbeExec+0x12b87>
   6201d:	mov    eax,DWORD PTR [rbp+0x8]
   62020:	mov    DWORD PTR [r14+0x2e0],eax
   62027:	mov    rax,QWORD PTR [rbp+0x10]
   6202b:	xor    ecx,ecx
   6202d:	xor    edx,edx
   6202f:	mov    QWORD PTR [rsp+0x1c8],rbp
   62037:	lea    rbp,[rsp+0x210]
   6203f:	mov    rsi,rbp
   62042:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6204d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62058:	mov    QWORD PTR [rsp+0x190],rdi
   62060:	mov    rdi,r14
   62063:	mov    r8,rsi
   62066:	mov    rsi,rax
   62069:	mov    r11,rdx
   6206c:	mov    rdx,rcx
   6206f:	mov    rcx,r11
   62072:	call   62077 <sqlite3VdbeExec+0x12bd7>
   62077:	mov    ebp,eax
   62079:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62084:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6208f:	movzx  eax,BYTE PTR [r14+0x70]
   62094:	sub    eax,0x1
   62097:	mov    BYTE PTR [r14+0x70],al
   6209b:	mov    QWORD PTR [r14+0x1f8],r12
   620a2:	mov    BYTE PTR [r14+0x6e],r13b
   620a6:	mov    DWORD PTR [r14+0x2e0],r15d
   620ad:	mov    rdi,QWORD PTR [rsp+0x190]
   620b5:	cmp    QWORD PTR [rsp+0x210],0x0
   620be:	jne    620c8 <sqlite3VdbeExec+0x12c28>
   620c0:	test   ebp,ebp
   620c2:	je     621a9 <sqlite3VdbeExec+0x12d09>
   620c8:	lea    rax,[rip+0x0]        # 620cf <sqlite3VdbeExec+0x12c2f>
   620cf:	mov    rcx,QWORD PTR [rsp+0x210]
   620d7:	mov    QWORD PTR [rsp+0x190],rdi
   620df:	mov    rsi,rax
   620e2:	mov    rdx,rcx
   620e5:	xor    eax,eax
   620e7:	call   620ec <sqlite3VdbeExec+0x12c4c>
   620ec:	mov    rbx,QWORD PTR [rsp+0x210]
   620f4:	mov    rdi,QWORD PTR [rsp+0x190]
   620fc:	test   rbx,rbx
   620ff:	je     62172 <sqlite3VdbeExec+0x12cd2>
   62101:	cmp    DWORD PTR [rip+0x0],0x0        # 62108 <sqlite3VdbeExec+0x12c68>
   62108:	je     6215a <sqlite3VdbeExec+0x12cba>
   6210a:	mov    rax,QWORD PTR [rip+0x0]        # 62111 <sqlite3VdbeExec+0x12c71>
   62111:	mov    rdi,rbx
   62114:	mov    r10,rax
   62117:	call   r10
   6211a:	mov    rcx,QWORD PTR [rip+0x0]        # 62121 <sqlite3VdbeExec+0x12c81>
   62121:	movsxd rax,eax
   62124:	sub    rcx,rax
   62127:	mov    QWORD PTR [rip+0x0],rcx        # 6212e <sqlite3VdbeExec+0x12c8e>
   6212e:	mov    rax,QWORD PTR [rip+0x0]        # 62135 <sqlite3VdbeExec+0x12c95>
   62135:	sub    rax,0x1
   62139:	mov    QWORD PTR [rip+0x0],rax        # 62140 <sqlite3VdbeExec+0x12ca0>
   62140:	mov    rax,QWORD PTR [rip+0x0]        # 62147 <sqlite3VdbeExec+0x12ca7>
   62147:	mov    rdi,rbx
   6214a:	mov    r10,rax
   6214d:	call   r10
   62150:	mov    rdi,QWORD PTR [rsp+0x190]
   62158:	jmp    62172 <sqlite3VdbeExec+0x12cd2>
   6215a:	mov    rax,QWORD PTR [rip+0x0]        # 62161 <sqlite3VdbeExec+0x12cc1>
   62161:	mov    rdi,rbx
   62164:	mov    r10,rax
   62167:	call   r10
   6216a:	mov    rdi,QWORD PTR [rsp+0x190]
   62172:	cmp    ebp,0x7
   62175:	jne    62194 <sqlite3VdbeExec+0x12cf4>
   62177:	mov    r13,QWORD PTR [rsp+0x1d0]
   6217f:	mov    rbx,QWORD PTR [rsp+0x1c8]
   62187:	mov    rbp,QWORD PTR [rsp+0x1d8]
   6218f:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   62194:	mov    r13,QWORD PTR [rsp+0x1b0]
   6219c:	mov    rbx,QWORD PTR [rsp+0x1d8]
   621a4:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   621a9:	mov    DWORD PTR [rsp+0x40c],ebp
   621b0:	mov    rbp,QWORD PTR [rsp+0x1c8]
   621b8:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   621bd:	mov    QWORD PTR [rsp+0x1c8],rbp
   621c5:	mov    QWORD PTR [rsp+0x1b0],r12
   621cd:	mov    rbp,QWORD PTR [rsp+0x1c8]
   621d5:	movsxd r12,DWORD PTR [rbp+0x4]
   621d9:	cmp    QWORD PTR [rbp+0x10],0x0
   621de:	jne    622b8 <sqlite3VdbeExec+0x12e18>
   621e4:	mov    rax,QWORD PTR [r14+0x20]
   621e8:	mov    rcx,r12
   621eb:	shl    rcx,0x5
   621ef:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   621f4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   621ff:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6220a:	mov    QWORD PTR [rsp+0x190],rdi
   62212:	mov    rdi,rax
   62215:	call   6221a <sqlite3VdbeExec+0x12d7a>
   6221a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62225:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62230:	mov    eax,DWORD PTR [r14+0x2c]
   62234:	and    eax,0xffffffef
   62237:	mov    DWORD PTR [r14+0x2c],eax
   6223b:	mov    rdi,QWORD PTR [rsp+0x190]
   62243:	lea    rax,[rdi+0xa8]
   6224a:	movzx  ecx,WORD PTR [rbp+0x2]
   6224e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62259:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62264:	mov    rdi,r14
   62267:	mov    rsi,r12
   6226a:	mov    rdx,rax
   6226d:	call   62272 <sqlite3VdbeExec+0x12dd2>
   62272:	mov    r12d,eax
   62275:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62280:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6228b:	mov    eax,DWORD PTR [r14+0x2c]
   6228f:	or     eax,0x1
   62292:	mov    DWORD PTR [r14+0x2c],eax
   62296:	mov    rdi,QWORD PTR [rsp+0x190]
   6229e:	movzx  eax,WORD PTR [rdi+0xc8]
   622a5:	and    rax,0xfffffffffffffffc
   622a9:	mov    WORD PTR [rdi+0xc8],ax
   622b0:	mov    r15,r12
   622b3:	jmp    624c6 <sqlite3VdbeExec+0x13026>
   622b8:	lea    rax,[rip+0x0]        # 622bf <sqlite3VdbeExec+0x12e1f>
   622bf:	mov    QWORD PTR [rsp+0x268],r14
   622c7:	mov    DWORD PTR [rsp+0x278],r12d
   622cf:	lea    rcx,[rdi+0xa8]
   622d6:	mov    QWORD PTR [rsp+0x270],rcx
   622de:	mov    DWORD PTR [rsp+0x280],0x0
   622e9:	mov    rcx,QWORD PTR [r14+0x20]
   622ed:	mov    rdx,r12
   622f0:	mov    rsi,rdx
   622f3:	shl    rsi,0x5
   622f7:	mov    rcx,QWORD PTR [rcx+rsi*1+0x8]
   622fc:	mov    rcx,QWORD PTR [rcx+0x8]
   62300:	mov    ecx,DWORD PTR [rcx+0x40]
   62303:	mov    DWORD PTR [rsp+0x288],ecx
   6230a:	lea    rcx,[rip+0x0]        # 62311 <sqlite3VdbeExec+0x12e71>
   62311:	mov    rsi,QWORD PTR [r14+0x20]
   62315:	shl    rdx,0x5
   62319:	mov    rdx,QWORD PTR [rsi+rdx*1]
   6231d:	mov    rsi,QWORD PTR [rbp+0x10]
   62321:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6232c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62337:	mov    QWORD PTR [rsp+0x190],rdi
   6233f:	mov    rdi,r14
   62342:	mov    r8,rsi
   62345:	mov    rsi,rcx
   62348:	mov    rcx,rax
   6234b:	xor    eax,eax
   6234d:	call   62352 <sqlite3VdbeExec+0x12eb2>
   62352:	mov    r12,rax
   62355:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62360:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6236b:	mov    rdi,QWORD PTR [rsp+0x190]
   62373:	test   r12,r12
   62376:	jne    62386 <sqlite3VdbeExec+0x12ee6>
   62378:	mov    r12d,0x7
   6237e:	mov    r15,r12
   62381:	jmp    624c6 <sqlite3VdbeExec+0x13026>
   62386:	mov    BYTE PTR [r14+0xc5],0x1
   6238e:	mov    DWORD PTR [rsp+0x27c],0x0
   62399:	mov    DWORD PTR [rsp+0x284],0x0
   623a4:	lea    rax,[rip+0x0]        # 623ab <sqlite3VdbeExec+0x12f0b>
   623ab:	lea    r13,[rsp+0x268]
   623b3:	mov    rcx,r13
   623b6:	xor    edx,edx
   623b8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   623c3:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   623ce:	mov    rdi,r14
   623d1:	mov    rsi,r12
   623d4:	mov    r8,rdx
   623d7:	mov    rdx,rax
   623da:	call   623df <sqlite3VdbeExec+0x12f3f>
   623df:	mov    r15d,eax
   623e2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   623ed:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   623f8:	mov    rdi,QWORD PTR [rsp+0x190]
   62400:	test   r15d,r15d
   62403:	jne    6240d <sqlite3VdbeExec+0x12f6d>
   62405:	mov    r15d,DWORD PTR [rsp+0x27c]
   6240d:	test   r15d,r15d
   62410:	jne    62477 <sqlite3VdbeExec+0x12fd7>
   62412:	cmp    DWORD PTR [rsp+0x284],0x0
   6241a:	jne    62477 <sqlite3VdbeExec+0x12fd7>
   6241c:	mov    eax,0x194dc
   62421:	mov    ecx,0xb
   62426:	lea    rdx,[rip+0x0]        # 6242d <sqlite3VdbeExec+0x12f8d>
   6242d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62438:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62443:	mov    QWORD PTR [rsp+0x190],rdi
   6244b:	mov    rdi,rcx
   6244e:	mov    rsi,rax
   62451:	call   62456 <sqlite3VdbeExec+0x12fb6>
   62456:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62461:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6246c:	mov    r15d,eax
   6246f:	mov    rdi,QWORD PTR [rsp+0x190]
   62477:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62482:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6248d:	mov    QWORD PTR [rsp+0x190],rdi
   62495:	mov    rdi,r14
   62498:	mov    rsi,r12
   6249b:	call   624a0 <sqlite3VdbeExec+0x13000>
   624a0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   624ab:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   624b6:	mov    BYTE PTR [r14+0xc5],0x0
   624be:	mov    rdi,QWORD PTR [rsp+0x190]
   624c6:	test   r15d,r15d
   624c9:	je     62521 <sqlite3VdbeExec+0x13081>
   624cb:	mov    QWORD PTR [rsp+0x190],rdi
   624d3:	mov    rdi,r14
   624d6:	call   624db <sqlite3VdbeExec+0x1303b>
   624db:	mov    rdi,QWORD PTR [rsp+0x190]
   624e3:	cmp    r15d,0x7
   624e7:	jne    62501 <sqlite3VdbeExec+0x13061>
   624e9:	mov    r13,QWORD PTR [rsp+0x1d0]
   624f1:	mov    rbx,rbp
   624f4:	mov    rbp,QWORD PTR [rsp+0x1d8]
   624fc:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   62501:	mov    QWORD PTR [rsp+0x1c8],rbp
   62509:	mov    rbp,r15
   6250c:	mov    r13,QWORD PTR [rsp+0x1b0]
   62514:	mov    rbx,QWORD PTR [rsp+0x1d8]
   6251c:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   62521:	mov    DWORD PTR [rsp+0x40c],r15d
   62529:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6252e:	mov    QWORD PTR [rsp+0x1b0],r12
   62536:	mov    eax,DWORD PTR [rbp+0x4]
   62539:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62544:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6254f:	mov    QWORD PTR [rsp+0x190],rdi
   62557:	mov    rdi,r14
   6255a:	mov    rsi,rax
   6255d:	call   62562 <sqlite3VdbeExec+0x130c2>
   62562:	mov    r12d,eax
   62565:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62570:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6257b:	mov    rdi,QWORD PTR [rsp+0x190]
   62583:	test   r12d,r12d
   62586:	je     625a8 <sqlite3VdbeExec+0x13108>
   62588:	mov    QWORD PTR [rsp+0x1c8],rbp
   62590:	mov    rbp,r12
   62593:	mov    r13,QWORD PTR [rsp+0x1b0]
   6259b:	mov    rbx,QWORD PTR [rsp+0x1d8]
   625a3:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   625a8:	mov    DWORD PTR [rsp+0x40c],r12d
   625b0:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   625b5:	mov    r15d,DWORD PTR [rsp+0x3fc]
   625bd:	mov    r13,QWORD PTR [rsp+0x1d0]
   625c5:	mov    QWORD PTR [rsp+0x1b0],r12
   625cd:	mov    r12d,DWORD PTR [rsp+0x414]
   625d5:	movsxd rax,DWORD PTR [rbp+0x4]
   625d9:	mov    rcx,QWORD PTR [rbp+0x10]
   625dd:	mov    rdx,QWORD PTR [r14+0x20]
   625e1:	shl    rax,0x5
   625e5:	mov    rax,QWORD PTR [rdx+rax*1+0x18]
   625ea:	add    rax,0x8
   625ee:	xor    edx,edx
   625f0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   625fb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62606:	mov    QWORD PTR [rsp+0x190],rdi
   6260e:	mov    rdi,rax
   62611:	mov    rsi,rcx
   62614:	call   62619 <sqlite3VdbeExec+0x13179>
   62619:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62624:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6262f:	mov    rdi,QWORD PTR [rsp+0x190]
   62637:	test   rax,rax
   6263a:	je     6269a <sqlite3VdbeExec+0x131fa>
   6263c:	cmp    QWORD PTR [r14+0x300],0x0
   62644:	jne    62653 <sqlite3VdbeExec+0x131b3>
   62646:	mov    ecx,DWORD PTR [rax+0x2c]
   62649:	sub    ecx,0x1
   6264c:	mov    DWORD PTR [rax+0x2c],ecx
   6264f:	test   ecx,ecx
   62651:	ja     6269a <sqlite3VdbeExec+0x131fa>
   62653:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6265e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62669:	mov    QWORD PTR [rsp+0x190],rdi
   62671:	mov    rdi,r14
   62674:	mov    rsi,rax
   62677:	call   6267c <sqlite3VdbeExec+0x131dc>
   6267c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62687:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62692:	mov    rdi,QWORD PTR [rsp+0x190]
   6269a:	mov    eax,DWORD PTR [r14+0x2c]
   6269e:	or     eax,0x1
   626a1:	mov    DWORD PTR [r14+0x2c],eax
   626a5:	mov    DWORD PTR [rsp+0x3fc],r15d
   626ad:	mov    QWORD PTR [rsp+0x1d0],r13
   626b5:	mov    DWORD PTR [rsp+0x414],r12d
   626bd:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   626c2:	mov    r15d,DWORD PTR [rsp+0x3fc]
   626ca:	mov    r13,QWORD PTR [rsp+0x1d0]
   626d2:	mov    QWORD PTR [rsp+0x1b0],r12
   626da:	mov    r12d,DWORD PTR [rsp+0x414]
   626e2:	movsxd rax,DWORD PTR [rbp+0x4]
   626e6:	mov    rcx,QWORD PTR [rbp+0x10]
   626ea:	mov    rdx,QWORD PTR [r14+0x20]
   626ee:	shl    rax,0x5
   626f2:	mov    rax,QWORD PTR [rdx+rax*1+0x18]
   626f7:	add    rax,0x20
   626fb:	xor    edx,edx
   626fd:	mov    DWORD PTR [rsp+0x414],r12d
   62705:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62710:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6271b:	mov    QWORD PTR [rsp+0x190],rdi
   62723:	mov    rdi,rax
   62726:	mov    rsi,rcx
   62729:	call   6272e <sqlite3VdbeExec+0x1328e>
   6272e:	mov    r12,rax
   62731:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6273c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62747:	mov    rdi,QWORD PTR [rsp+0x190]
   6274f:	test   r12,r12
   62752:	je     62943 <sqlite3VdbeExec+0x134a3>
   62758:	mov    rax,QWORD PTR [r12+0x18]
   6275d:	cmp    r12,QWORD PTR [rax+0x10]
   62761:	jne    62773 <sqlite3VdbeExec+0x132d3>
   62763:	mov    rax,QWORD PTR [r12+0x18]
   62768:	mov    rcx,QWORD PTR [r12+0x28]
   6276d:	mov    QWORD PTR [rax+0x10],rcx
   62771:	jmp    627a1 <sqlite3VdbeExec+0x13301>
   62773:	mov    rax,QWORD PTR [r12+0x18]
   62778:	mov    rax,QWORD PTR [rax+0x10]
   6277c:	jmp    62788 <sqlite3VdbeExec+0x132e8>
   6277e:	cmp    r12,QWORD PTR [rax+0x28]
   62782:	je     6278d <sqlite3VdbeExec+0x132ed>
   62784:	mov    rax,QWORD PTR [rax+0x28]
   62788:	test   rax,rax
   6278b:	jne    6277e <sqlite3VdbeExec+0x132de>
   6278d:	test   rax,rax
   62790:	je     627a1 <sqlite3VdbeExec+0x13301>
   62792:	cmp    r12,QWORD PTR [rax+0x28]
   62796:	jne    627a1 <sqlite3VdbeExec+0x13301>
   62798:	mov    rcx,QWORD PTR [r12+0x28]
   6279d:	mov    QWORD PTR [rax+0x28],rcx
   627a1:	mov    rax,QWORD PTR [r12+0x48]
   627a6:	test   rax,rax
   627a9:	je     627f2 <sqlite3VdbeExec+0x13352>
   627ab:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   627b6:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   627c1:	mov    QWORD PTR [rsp+0x190],rdi
   627c9:	mov    rdi,r14
   627cc:	mov    rsi,rax
   627cf:	call   627d4 <sqlite3VdbeExec+0x13334>
   627d4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   627df:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   627ea:	mov    rdi,QWORD PTR [rsp+0x190]
   627f2:	mov    rax,QWORD PTR [r12+0x50]
   627f7:	test   rax,rax
   627fa:	je     62843 <sqlite3VdbeExec+0x133a3>
   627fc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62807:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62812:	mov    QWORD PTR [rsp+0x190],rdi
   6281a:	mov    rdi,r14
   6281d:	mov    rsi,rax
   62820:	call   62825 <sqlite3VdbeExec+0x13385>
   62825:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62830:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6283b:	mov    rdi,QWORD PTR [rsp+0x190]
   62843:	mov    rax,QWORD PTR [r12+0x20]
   62848:	test   rax,rax
   6284b:	je     62894 <sqlite3VdbeExec+0x133f4>
   6284d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62858:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62863:	mov    QWORD PTR [rsp+0x190],rdi
   6286b:	mov    rdi,r14
   6286e:	mov    rsi,rax
   62871:	call   62876 <sqlite3VdbeExec+0x133d6>
   62876:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62881:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6288c:	mov    rdi,QWORD PTR [rsp+0x190]
   62894:	movzx  eax,WORD PTR [r12+0x63]
   6289a:	shl    rax,0x3b
   6289e:	shr    rax,0x3f
   628a2:	test   eax,eax
   628a4:	je     628f7 <sqlite3VdbeExec+0x13457>
   628a6:	mov    rax,QWORD PTR [r12+0x40]
   628ab:	test   rax,rax
   628ae:	je     628f7 <sqlite3VdbeExec+0x13457>
   628b0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   628bb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   628c6:	mov    QWORD PTR [rsp+0x190],rdi
   628ce:	mov    rdi,r14
   628d1:	mov    rsi,rax
   628d4:	call   628d9 <sqlite3VdbeExec+0x13439>
   628d9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   628e4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   628ef:	mov    rdi,QWORD PTR [rsp+0x190]
   628f7:	test   r12,r12
   628fa:	je     62943 <sqlite3VdbeExec+0x134a3>
   628fc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62907:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62912:	mov    QWORD PTR [rsp+0x190],rdi
   6291a:	mov    rdi,r14
   6291d:	mov    rsi,r12
   62920:	call   62925 <sqlite3VdbeExec+0x13485>
   62925:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62930:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6293b:	mov    rdi,QWORD PTR [rsp+0x190]
   62943:	mov    eax,DWORD PTR [r14+0x2c]
   62947:	or     eax,0x1
   6294a:	mov    DWORD PTR [r14+0x2c],eax
   6294e:	mov    DWORD PTR [rsp+0x3fc],r15d
   62956:	mov    QWORD PTR [rsp+0x1d0],r13
   6295e:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   62963:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6296b:	mov    r13,QWORD PTR [rsp+0x1d0]
   62973:	mov    QWORD PTR [rsp+0x1b0],r12
   6297b:	movsxd rax,DWORD PTR [rbp+0x4]
   6297f:	mov    rcx,QWORD PTR [rbp+0x10]
   62983:	mov    rdx,QWORD PTR [r14+0x20]
   62987:	shl    rax,0x5
   6298b:	mov    rax,QWORD PTR [rdx+rax*1+0x18]
   62990:	add    rax,0x38
   62994:	xor    edx,edx
   62996:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   629a1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   629ac:	mov    QWORD PTR [rsp+0x190],rdi
   629b4:	mov    rdi,rax
   629b7:	mov    rsi,rcx
   629ba:	call   629bf <sqlite3VdbeExec+0x1351f>
   629bf:	mov    r12,rax
   629c2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   629cd:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   629d8:	mov    rdi,QWORD PTR [rsp+0x190]
   629e0:	test   r12,r12
   629e3:	je     62f73 <sqlite3VdbeExec+0x13ad3>
   629e9:	mov    rax,QWORD PTR [r12+0x28]
   629ee:	cmp    rax,QWORD PTR [r12+0x30]
   629f3:	jne    62b42 <sqlite3VdbeExec+0x136a2>
   629f9:	mov    rax,QWORD PTR [r12+0x30]
   629fe:	mov    rcx,QWORD PTR [r12+0x8]
   62a03:	xor    edx,edx
   62a05:	mov    rsi,rcx
   62a08:	jmp    62a22 <sqlite3VdbeExec+0x13582>
   62a0a:	movzx  r8d,BYTE PTR [rsi]
   62a0e:	add    rsi,0x1
   62a12:	and    r8d,0xdf
   62a19:	add    edx,r8d
   62a1c:	imul   edx,edx,0x9e3779b1
   62a22:	cmp    BYTE PTR [rsi],0x0
   62a25:	jne    62a0a <sqlite3VdbeExec+0x1356a>
   62a27:	mov    esi,edx
   62a29:	cmp    QWORD PTR [rax+0x18],0x0
   62a2e:	je     62a51 <sqlite3VdbeExec+0x135b1>
   62a30:	mov    r8,QWORD PTR [rax+0x18]
   62a34:	mov    r9d,DWORD PTR [rax+0x8]
   62a38:	mov    rax,rsi
   62a3b:	xor    edx,edx
   62a3d:	div    r9d
   62a40:	mov    eax,edx
   62a42:	shl    rax,0x4
   62a46:	mov    rdx,QWORD PTR [r8+rax*1+0x8]
   62a4b:	mov    eax,DWORD PTR [r8+rax*1]
   62a4f:	jmp    62a58 <sqlite3VdbeExec+0x135b8>
   62a51:	mov    rdx,QWORD PTR [rax+0x10]
   62a55:	mov    eax,DWORD PTR [rax+0xc]
   62a58:	mov    r10,rax
   62a5b:	mov    rax,rdx
   62a5e:	jmp    62ae8 <sqlite3VdbeExec+0x13648>
   62a63:	mov    QWORD PTR [rsp+0x180],rdi
   62a6b:	lea    rdi,[rip+0x0]        # 62a72 <sqlite3VdbeExec+0x135d2>
   62a72:	movzx  edx,BYTE PTR [rdi+rdx*1]
   62a76:	movzx  edi,BYTE PTR [rdi+r9*1]
   62a7b:	sub    edx,edi
   62a7d:	test   edx,edx
   62a7f:	je     62aa1 <sqlite3VdbeExec+0x13601>
   62a81:	test   edx,edx
   62a83:	je     62a8f <sqlite3VdbeExec+0x135ef>
   62a85:	mov    rdi,QWORD PTR [rsp+0x180]
   62a8d:	jmp    62ad9 <sqlite3VdbeExec+0x13639>
   62a8f:	mov    rdi,QWORD PTR [rsp+0x180]
   62a97:	mov    rax,QWORD PTR [rsp+0x208]
   62a9f:	jmp    62b17 <sqlite3VdbeExec+0x13677>
   62aa1:	add    rax,0x1
   62aa5:	add    r8,0x1
   62aa9:	mov    rdi,QWORD PTR [rsp+0x180]
   62ab1:	movzx  edx,BYTE PTR [rax]
   62ab4:	movzx  r9d,BYTE PTR [r8]
   62ab8:	cmp    edx,r9d
   62abb:	jne    62a63 <sqlite3VdbeExec+0x135c3>
   62abd:	test   edx,edx
   62abf:	je     62acb <sqlite3VdbeExec+0x1362b>
   62ac1:	mov    QWORD PTR [rsp+0x180],rdi
   62ac9:	jmp    62aa1 <sqlite3VdbeExec+0x13601>
   62acb:	test   edx,edx
   62acd:	jne    62ad9 <sqlite3VdbeExec+0x13639>
   62acf:	mov    QWORD PTR [rsp+0x180],rdi
   62ad7:	jmp    62a8f <sqlite3VdbeExec+0x135ef>
   62ad9:	mov    rax,QWORD PTR [rsp+0x208]
   62ae1:	mov    rax,QWORD PTR [rax]
   62ae4:	sub    r10d,0x1
   62ae8:	test   r10d,r10d
   62aeb:	je     62b10 <sqlite3VdbeExec+0x13670>
   62aed:	cmp    esi,DWORD PTR [rax+0x20]
   62af0:	je     62afc <sqlite3VdbeExec+0x1365c>
   62af2:	mov    QWORD PTR [rsp+0x208],rax
   62afa:	jmp    62ad9 <sqlite3VdbeExec+0x13639>
   62afc:	mov    rdx,QWORD PTR [rax+0x18]
   62b00:	mov    QWORD PTR [rsp+0x208],rax
   62b08:	mov    rax,rdx
   62b0b:	mov    r8,rcx
   62b0e:	jmp    62ab1 <sqlite3VdbeExec+0x13611>
   62b10:	lea    rax,[rip+0x0]        # 62b17 <sqlite3VdbeExec+0x13677>
   62b17:	mov    rax,QWORD PTR [rax+0x10]
   62b1b:	test   rax,rax
   62b1e:	je     62b42 <sqlite3VdbeExec+0x136a2>
   62b20:	add    rax,0x58
   62b24:	jmp    62b2d <sqlite3VdbeExec+0x1368d>
   62b26:	mov    rax,QWORD PTR [rax]
   62b29:	add    rax,0x40
   62b2d:	cmp    QWORD PTR [rax],0x0
   62b31:	je     62b42 <sqlite3VdbeExec+0x136a2>
   62b33:	cmp    r12,QWORD PTR [rax]
   62b36:	jne    62b26 <sqlite3VdbeExec+0x13686>
   62b38:	mov    rcx,QWORD PTR [rax]
   62b3b:	mov    rcx,QWORD PTR [rcx+0x40]
   62b3f:	mov    QWORD PTR [rax],rcx
   62b42:	test   r12,r12
   62b45:	je     62f68 <sqlite3VdbeExec+0x13ac8>
   62b4b:	cmp    BYTE PTR [r12+0x12],0x0
   62b51:	jne    62f68 <sqlite3VdbeExec+0x13ac8>
   62b57:	mov    QWORD PTR [rsp+0x210],r12
   62b5f:	mov    r12,QWORD PTR [r12+0x38]
   62b64:	jmp    62dd5 <sqlite3VdbeExec+0x13935>
   62b69:	mov    QWORD PTR [rsp+0x1d0],r13
   62b71:	mov    r13,QWORD PTR [r12+0x48]
   62b76:	mov    rax,QWORD PTR [r12+0x20]
   62b7b:	test   rax,rax
   62b7e:	je     62bc7 <sqlite3VdbeExec+0x13727>
   62b80:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62b8b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62b96:	mov    QWORD PTR [rsp+0x190],rdi
   62b9e:	mov    rdi,r14
   62ba1:	mov    rsi,rax
   62ba4:	call   62ba9 <sqlite3VdbeExec+0x13709>
   62ba9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62bb4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62bbf:	mov    rdi,QWORD PTR [rsp+0x190]
   62bc7:	mov    rax,QWORD PTR [r12+0x28]
   62bcc:	test   rax,rax
   62bcf:	je     62c18 <sqlite3VdbeExec+0x13778>
   62bd1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62bdc:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62be7:	mov    QWORD PTR [rsp+0x190],rdi
   62bef:	mov    rdi,r14
   62bf2:	mov    rsi,rax
   62bf5:	call   62bfa <sqlite3VdbeExec+0x1375a>
   62bfa:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62c05:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62c10:	mov    rdi,QWORD PTR [rsp+0x190]
   62c18:	mov    rax,QWORD PTR [r12+0x10]
   62c1d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62c28:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62c33:	mov    QWORD PTR [rsp+0x190],rdi
   62c3b:	mov    rdi,r14
   62c3e:	mov    rsi,rax
   62c41:	call   62c46 <sqlite3VdbeExec+0x137a6>
   62c46:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62c51:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62c5c:	mov    rax,QWORD PTR [r12+0x30]
   62c61:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62c6c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62c77:	mov    rdi,r14
   62c7a:	mov    rsi,rax
   62c7d:	call   62c82 <sqlite3VdbeExec+0x137e2>
   62c82:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62c8d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62c98:	mov    rax,QWORD PTR [r12+0x38]
   62c9d:	mov    rdi,QWORD PTR [rsp+0x190]
   62ca5:	test   rax,rax
   62ca8:	je     62ce9 <sqlite3VdbeExec+0x13849>
   62caa:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62cb5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62cc0:	mov    rdi,r14
   62cc3:	mov    rsi,rax
   62cc6:	call   62ccb <sqlite3VdbeExec+0x1382b>
   62ccb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62cd6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62ce1:	mov    rdi,QWORD PTR [rsp+0x190]
   62ce9:	mov    rax,QWORD PTR [r12+0x18]
   62cee:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62cf9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62d04:	mov    QWORD PTR [rsp+0x190],rdi
   62d0c:	mov    rdi,r14
   62d0f:	mov    rsi,rax
   62d12:	call   62d17 <sqlite3VdbeExec+0x13877>
   62d17:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62d22:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62d2d:	mov    rax,QWORD PTR [r12+0x40]
   62d32:	mov    rdi,QWORD PTR [rsp+0x190]
   62d3a:	test   rax,rax
   62d3d:	je     62d7e <sqlite3VdbeExec+0x138de>
   62d3f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62d4a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62d55:	mov    rdi,r14
   62d58:	mov    rsi,rax
   62d5b:	call   62d60 <sqlite3VdbeExec+0x138c0>
   62d60:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62d6b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62d76:	mov    rdi,QWORD PTR [rsp+0x190]
   62d7e:	test   r12,r12
   62d81:	je     62dca <sqlite3VdbeExec+0x1392a>
   62d83:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62d8e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62d99:	mov    QWORD PTR [rsp+0x190],rdi
   62da1:	mov    rdi,r14
   62da4:	mov    rsi,r12
   62da7:	call   62dac <sqlite3VdbeExec+0x1390c>
   62dac:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62db7:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62dc2:	mov    rdi,QWORD PTR [rsp+0x190]
   62dca:	mov    r12,r13
   62dcd:	mov    r13,QWORD PTR [rsp+0x1d0]
   62dd5:	test   r12,r12
   62dd8:	jne    62b69 <sqlite3VdbeExec+0x136c9>
   62dde:	mov    r12,QWORD PTR [rsp+0x210]
   62de6:	mov    rax,QWORD PTR [r12]
   62dea:	test   rax,rax
   62ded:	je     62e36 <sqlite3VdbeExec+0x13996>
   62def:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62dfa:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62e05:	mov    QWORD PTR [rsp+0x190],rdi
   62e0d:	mov    rdi,r14
   62e10:	mov    rsi,rax
   62e13:	call   62e18 <sqlite3VdbeExec+0x13978>
   62e18:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62e23:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62e2e:	mov    rdi,QWORD PTR [rsp+0x190]
   62e36:	mov    rax,QWORD PTR [r12+0x8]
   62e3b:	test   rax,rax
   62e3e:	je     62e87 <sqlite3VdbeExec+0x139e7>
   62e40:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62e4b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62e56:	mov    QWORD PTR [rsp+0x190],rdi
   62e5e:	mov    rdi,r14
   62e61:	mov    rsi,rax
   62e64:	call   62e69 <sqlite3VdbeExec+0x139c9>
   62e69:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62e74:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62e7f:	mov    rdi,QWORD PTR [rsp+0x190]
   62e87:	mov    rax,QWORD PTR [r12+0x18]
   62e8c:	test   rax,rax
   62e8f:	je     62ed8 <sqlite3VdbeExec+0x13a38>
   62e91:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62e9c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62ea7:	mov    QWORD PTR [rsp+0x190],rdi
   62eaf:	mov    rdi,r14
   62eb2:	mov    rsi,rax
   62eb5:	call   62eba <sqlite3VdbeExec+0x13a1a>
   62eba:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62ec5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62ed0:	mov    rdi,QWORD PTR [rsp+0x190]
   62ed8:	mov    rax,QWORD PTR [r12+0x20]
   62edd:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62ee8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62ef3:	mov    QWORD PTR [rsp+0x190],rdi
   62efb:	mov    rdi,r14
   62efe:	mov    rsi,rax
   62f01:	call   62f06 <sqlite3VdbeExec+0x13a66>
   62f06:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62f11:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62f1c:	mov    rdi,QWORD PTR [rsp+0x190]
   62f24:	test   r12,r12
   62f27:	je     62f68 <sqlite3VdbeExec+0x13ac8>
   62f29:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   62f34:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   62f3f:	mov    rdi,r14
   62f42:	mov    rsi,r12
   62f45:	call   62f4a <sqlite3VdbeExec+0x13aaa>
   62f4a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   62f55:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   62f60:	mov    rdi,QWORD PTR [rsp+0x190]
   62f68:	mov    eax,DWORD PTR [r14+0x2c]
   62f6c:	or     eax,0x1
   62f6f:	mov    DWORD PTR [r14+0x2c],eax
   62f73:	mov    DWORD PTR [rsp+0x3fc],r15d
   62f7b:	mov    QWORD PTR [rsp+0x1d0],r13
   62f83:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   62f88:	mov    r15d,DWORD PTR [rsp+0x3fc]
   62f90:	mov    r13,QWORD PTR [rsp+0x1d0]
   62f98:	mov    QWORD PTR [rsp+0x1b0],r12
   62fa0:	mov    r12d,DWORD PTR [rbp+0x8]
   62fa4:	mov    DWORD PTR [rsp+0x428],r12d
   62fac:	mov    r12,QWORD PTR [rbp+0x10]
   62fb0:	movsxd rax,DWORD PTR [rbp+0x4]
   62fb4:	mov    QWORD PTR [rsp+0x1d0],r13
   62fbc:	imul   r13,rax,0x38
   62fc0:	mov    eax,DWORD PTR [rbp+0x4]
   62fc3:	add    eax,0x1
   62fc6:	movsxd rax,eax
   62fc9:	imul   rax,rax,0x38
   62fcd:	mov    DWORD PTR [rsp+0x3fc],r15d
   62fd5:	lea    r15,[rbx+rax*1]
   62fd9:	mov    rax,QWORD PTR [r14+0x20]
   62fdd:	movzx  ecx,WORD PTR [rbp+0x2]
   62fe1:	shl    rcx,0x5
   62fe5:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   62fea:	movsxd rcx,DWORD PTR [rbp+0xc]
   62fee:	imul   rcx,rcx,0x38
   62ff2:	mov    QWORD PTR [rsp+0x1e8],r15
   62ffa:	lea    r15,[rbx+rcx*1]
   62ffe:	mov    rcx,QWORD PTR [rbx+r13*1]
   63002:	mov    QWORD PTR [rsp+0x218],r15
   6300a:	lea    r15d,[rcx+0x1]
   6300e:	mov    DWORD PTR [rsp+0x418],r15d
   63016:	mov    r15,QWORD PTR [rax+0x8]
   6301a:	mov    rcx,QWORD PTR [r15+0x8]
   6301e:	mov    QWORD PTR [rsp+0x208],r13
   63026:	mov    r13,QWORD PTR [rcx+0x30]
   6302a:	cmp    DWORD PTR [r12+0x4],0x0
   63030:	je     6304d <sqlite3VdbeExec+0x13bad>
   63032:	mov    QWORD PTR [rsp+0x220],r13
   6303a:	xor    r11d,r11d
   6303d:	mov    DWORD PTR [rsp+0x424],r11d
   63045:	mov    r13d,0x1
   6304b:	jmp    63075 <sqlite3VdbeExec+0x13bd5>
   6304d:	xor    ecx,ecx
   6304f:	mov    QWORD PTR [rsp+0x220],r13
   63057:	mov    r13d,0x1
   6305d:	cmp    DWORD PTR [r12+0x8],0x1
   63063:	cmovne r13d,ecx
   63067:	mov    r11d,0x1
   6306d:	mov    DWORD PTR [rsp+0x424],r11d
   63075:	mov    rcx,QWORD PTR [rax+0x8]
   63079:	mov    rax,QWORD PTR [rax]
   6307c:	mov    QWORD PTR [rcx+0x8],rax
   63080:	mov    QWORD PTR [rsp+0x1e0],rbx
   63088:	lea    rbx,[rsp+0x378]
   63090:	mov    rax,rbx
   63093:	xor    ecx,ecx
   63095:	mov    edx,0x80
   6309a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   630a5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   630b0:	mov    QWORD PTR [rsp+0x190],rdi
   630b8:	mov    rdi,rax
   630bb:	mov    rsi,rcx
   630be:	call   630c3 <sqlite3VdbeExec+0x13c23>
   630c3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   630ce:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   630d9:	mov    QWORD PTR [rbx+0x70],r14
   630dd:	mov    QWORD PTR [rbx],r15
   630e0:	mov    rax,QWORD PTR [r15]
   630e3:	mov    QWORD PTR [rbx+0x8],rax
   630e7:	mov    rax,QWORD PTR [rbx]
   630ea:	mov    eax,DWORD PTR [rax+0x40]
   630ed:	mov    DWORD PTR [rbx+0x18],eax
   630f0:	mov    QWORD PTR [rsp+0x1a8],r14
   630f8:	mov    r14d,DWORD PTR [rsp+0x418]
   63100:	mov    DWORD PTR [rbx+0x1c],r14d
   63104:	lea    r14,[rsp+0x110]
   6310c:	mov    rax,r14
   6310f:	mov    QWORD PTR [rbx+0x50],rax
   63113:	mov    QWORD PTR [rbx+0x48],0x0
   6311b:	mov    DWORD PTR [rbx+0x58],0x64
   63122:	mov    DWORD PTR [rbx+0x5c],0x3b9aca00
   63129:	mov    DWORD PTR [rbx+0x60],0x0
   63130:	mov    BYTE PTR [rbx+0x64],0x0
   63134:	mov    BYTE PTR [rbx+0x65],0x0
   63138:	mov    BYTE PTR [rbx+0x65],0x1
   6313c:	mov    rdi,QWORD PTR [rsp+0x190]
   63144:	cmp    DWORD PTR [rbx+0x18],0x0
   63148:	je     6321e <sqlite3VdbeExec+0x13d7e>
   6314e:	mov    eax,DWORD PTR [rbx+0x18]
   63151:	shr    eax,0x3
   63154:	add    eax,0x1
   63157:	mov    r14,rax
   6315a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   63165:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   63170:	mov    rdi,r14
   63173:	call   63178 <sqlite3VdbeExec+0x13cd8>
   63178:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63183:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6318e:	mov    rdi,QWORD PTR [rsp+0x190]
   63196:	test   rax,rax
   63199:	je     631f2 <sqlite3VdbeExec+0x13d52>
   6319b:	xor    ecx,ecx
   6319d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   631a8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   631b3:	mov    QWORD PTR [rsp+0x188],rax
   631bb:	mov    rdi,rax
   631be:	mov    rsi,rcx
   631c1:	mov    rdx,r14
   631c4:	call   631c9 <sqlite3VdbeExec+0x13d29>
   631c9:	mov    rcx,rax
   631cc:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   631d7:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   631e2:	mov    rax,QWORD PTR [rsp+0x188]
   631ea:	mov    rdi,QWORD PTR [rsp+0x190]
   631f2:	mov    QWORD PTR [rbx+0x10],rax
   631f6:	cmp    QWORD PTR [rbx+0x10],0x0
   631fb:	jne    6332b <sqlite3VdbeExec+0x13e8b>
   63201:	mov    DWORD PTR [rbx+0x24],0x7
   63208:	mov    DWORD PTR [rbx+0x1c],0x0
   6320f:	cmp    DWORD PTR [rbx+0x20],0x0
   63213:	jne    6321e <sqlite3VdbeExec+0x13d7e>
   63215:	mov    eax,DWORD PTR [rbx+0x20]
   63218:	add    eax,0x1
   6321b:	mov    DWORD PTR [rbx+0x20],eax
   6321e:	mov    rax,QWORD PTR [rbx+0x68]
   63222:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6322d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   63238:	mov    QWORD PTR [rsp+0x190],rdi
   63240:	mov    rdi,rax
   63243:	call   63248 <sqlite3VdbeExec+0x13da8>
   63248:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63253:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6325e:	mov    r12,QWORD PTR [rbx+0x10]
   63262:	mov    rdi,QWORD PTR [rsp+0x190]
   6326a:	test   r12,r12
   6326d:	je     63dc6 <sqlite3VdbeExec+0x14926>
   63273:	cmp    DWORD PTR [rip+0x0],0x0        # 6327a <sqlite3VdbeExec+0x13dda>
   6327a:	je     63d82 <sqlite3VdbeExec+0x148e2>
   63280:	mov    rax,QWORD PTR [rip+0x0]        # 63287 <sqlite3VdbeExec+0x13de7>
   63287:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   63292:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6329d:	mov    rdi,r12
   632a0:	mov    r10,rax
   632a3:	call   r10
   632a6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   632b1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   632bc:	mov    rcx,QWORD PTR [rip+0x0]        # 632c3 <sqlite3VdbeExec+0x13e23>
   632c3:	movsxd rax,eax
   632c6:	sub    rcx,rax
   632c9:	mov    QWORD PTR [rip+0x0],rcx        # 632d0 <sqlite3VdbeExec+0x13e30>
   632d0:	mov    rax,QWORD PTR [rip+0x0]        # 632d7 <sqlite3VdbeExec+0x13e37>
   632d7:	sub    rax,0x1
   632db:	mov    QWORD PTR [rip+0x0],rax        # 632e2 <sqlite3VdbeExec+0x13e42>
   632e2:	mov    rax,QWORD PTR [rip+0x0]        # 632e9 <sqlite3VdbeExec+0x13e49>
   632e9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   632f4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   632ff:	mov    rdi,r12
   63302:	mov    r10,rax
   63305:	call   r10
   63308:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63313:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6331e:	mov    rdi,QWORD PTR [rsp+0x190]
   63326:	jmp    63dc6 <sqlite3VdbeExec+0x14926>
   6332b:	mov    eax,DWORD PTR [r15+0x34]
   6332f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6333a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   63345:	mov    QWORD PTR [rsp+0x190],rdi
   6334d:	mov    rdi,rax
   63350:	call   63355 <sqlite3VdbeExec+0x13eb5>
   63355:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63360:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6336b:	mov    QWORD PTR [rbx+0x68],rax
   6336f:	mov    rdi,QWORD PTR [rsp+0x190]
   63377:	cmp    QWORD PTR [rbx+0x68],0x0
   6337c:	jne    633a4 <sqlite3VdbeExec+0x13f04>
   6337e:	mov    DWORD PTR [rbx+0x24],0x7
   63385:	mov    DWORD PTR [rbx+0x1c],0x0
   6338c:	cmp    DWORD PTR [rbx+0x20],0x0
   63390:	jne    6321e <sqlite3VdbeExec+0x13d7e>
   63396:	mov    eax,DWORD PTR [rbx+0x20]
   63399:	add    eax,0x1
   6339c:	mov    DWORD PTR [rbx+0x20],eax
   6339f:	jmp    6321e <sqlite3VdbeExec+0x13d7e>
   633a4:	mov    eax,DWORD PTR [rip+0x0]        # 633aa <sqlite3VdbeExec+0x13f0a>
   633aa:	mov    ecx,DWORD PTR [r15+0x34]
   633ae:	xor    edx,edx
   633b0:	div    ecx
   633b2:	add    eax,0x1
   633b5:	cmp    eax,DWORD PTR [rbx+0x18]
   633b8:	ja     633e4 <sqlite3VdbeExec+0x13f44>
   633ba:	mov    rdx,QWORD PTR [rbx+0x10]
   633be:	mov    ecx,eax
   633c0:	shr    ecx,0x3
   633c3:	mov    rsi,rcx
   633c6:	movzx  ecx,BYTE PTR [rdx+rsi*1]
   633ca:	mov    r8d,ecx
   633cd:	mov    r9d,0x1
   633d3:	and    eax,0x7
   633d6:	mov    ecx,eax
   633d8:	mov    rax,r9
   633db:	shl    eax,cl
   633dd:	or     r8d,eax
   633e0:	mov    BYTE PTR [rdx+rsi*1],r8b
   633e4:	test   r13d,r13d
   633e7:	je     634b2 <sqlite3VdbeExec+0x14012>
   633ed:	lea    rax,[rip+0x0]        # 633f4 <sqlite3VdbeExec+0x13f54>
   633f4:	mov    QWORD PTR [rbx+0x30],rax
   633f8:	mov    rax,rbx
   633fb:	mov    ecx,0x1
   63400:	mov    rdx,QWORD PTR [r15+0x18]
   63404:	mov    rdx,QWORD PTR [rdx+0x50]
   63408:	movzx  esi,BYTE PTR [rdx+0x20]
   6340c:	shl    esi,0x18
   6340f:	movzx  r8d,BYTE PTR [rdx+0x21]
   63414:	shl    r8d,0x10
   63418:	or     esi,r8d
   6341b:	movzx  r8d,BYTE PTR [rdx+0x22]
   63420:	shl    r8d,0x8
   63424:	or     esi,r8d
   63427:	movzx  edx,BYTE PTR [rdx+0x23]
   6342b:	or     esi,edx
   6342d:	mov    rdx,QWORD PTR [r15+0x18]
   63431:	mov    rdx,QWORD PTR [rdx+0x50]
   63435:	movzx  r8d,BYTE PTR [rdx+0x24]
   6343a:	shl    r8d,0x18
   6343e:	movzx  r9d,BYTE PTR [rdx+0x25]
   63443:	shl    r9d,0x10
   63447:	or     r8d,r9d
   6344a:	movzx  r9d,BYTE PTR [rdx+0x26]
   6344f:	shl    r9d,0x8
   63453:	or     r8d,r9d
   63456:	movzx  edx,BYTE PTR [rdx+0x27]
   6345a:	or     r8d,edx
   6345d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   63468:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   63473:	mov    QWORD PTR [rsp+0x190],rdi
   6347b:	mov    rdi,rax
   6347e:	mov    rdx,rsi
   63481:	mov    rsi,rcx
   63484:	mov    rcx,r8
   63487:	call   6348c <sqlite3VdbeExec+0x13fec>
   6348c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63497:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   634a2:	mov    QWORD PTR [rbx+0x30],0x0
   634aa:	mov    rdi,QWORD PTR [rsp+0x190]
   634b2:	mov    r13d,DWORD PTR [rsp+0x424]
   634ba:	test   r13d,r13d
   634bd:	jne    6361e <sqlite3VdbeExec+0x1417e>
   634c3:	cmp    BYTE PTR [r15+0x21],0x0
   634c8:	je     6359d <sqlite3VdbeExec+0x140fd>
   634ce:	xor    eax,eax
   634d0:	xor    ecx,ecx
   634d2:	mov    r11,rax
   634d5:	mov    rax,rcx
   634d8:	mov    rcx,r11
   634db:	jmp    634f2 <sqlite3VdbeExec+0x14052>
   634dd:	mov    rdx,rax
   634e0:	cmp    ecx,DWORD PTR [r12+rdx*4+0x4]
   634e5:	jae    634ef <sqlite3VdbeExec+0x1404f>
   634e7:	mov    rcx,rax
   634ea:	mov    ecx,DWORD PTR [r12+rcx*4+0x4]
   634ef:	add    eax,0x1
   634f2:	mov    r14d,DWORD PTR [rsp+0x428]
   634fa:	cmp    eax,r14d
   634fd:	jl     634dd <sqlite3VdbeExec+0x1403d>
   634ff:	mov    rax,QWORD PTR [r15+0x18]
   63503:	mov    rax,QWORD PTR [rax+0x50]
   63507:	movzx  edx,BYTE PTR [rax+0x34]
   6350b:	shl    edx,0x18
   6350e:	movzx  esi,BYTE PTR [rax+0x35]
   63512:	shl    esi,0x10
   63515:	or     edx,esi
   63517:	movzx  esi,BYTE PTR [rax+0x36]
   6351b:	shl    esi,0x8
   6351e:	or     edx,esi
   63520:	movzx  eax,BYTE PTR [rax+0x37]
   63524:	or     edx,eax
   63526:	cmp    ecx,edx
   63528:	jne    63537 <sqlite3VdbeExec+0x14097>
   6352a:	mov    DWORD PTR [rsp+0x428],r14d
   63532:	jmp    6361e <sqlite3VdbeExec+0x1417e>
   63537:	lea    r14,[rsp+0x378]
   6353f:	mov    rax,r14
   63542:	lea    rsi,[rip+0x0]        # 63549 <sqlite3VdbeExec+0x140a9>
   63549:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   63554:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6355f:	mov    QWORD PTR [rsp+0x190],rdi
   63567:	mov    rdi,rax
   6356a:	mov    r11,rdx
   6356d:	mov    rdx,rcx
   63570:	mov    rcx,r11
   63573:	xor    eax,eax
   63575:	call   6357a <sqlite3VdbeExec+0x140da>
   6357a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63585:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   63590:	mov    rdi,QWORD PTR [rsp+0x190]
   63598:	jmp    6361e <sqlite3VdbeExec+0x1417e>
   6359d:	mov    r14,rbx
   635a0:	mov    rax,QWORD PTR [r15+0x18]
   635a4:	mov    rax,QWORD PTR [rax+0x50]
   635a8:	movzx  ecx,BYTE PTR [rax+0x40]
   635ac:	shl    ecx,0x18
   635af:	movzx  edx,BYTE PTR [rax+0x41]
   635b3:	shl    edx,0x10
   635b6:	or     ecx,edx
   635b8:	movzx  edx,BYTE PTR [rax+0x42]
   635bc:	shl    edx,0x8
   635bf:	or     ecx,edx
   635c1:	movzx  eax,BYTE PTR [rax+0x43]
   635c5:	or     ecx,eax
   635c7:	test   ecx,ecx
   635c9:	je     6361e <sqlite3VdbeExec+0x1417e>
   635cb:	mov    rax,r14
   635ce:	lea    rcx,[rip+0x0]        # 635d5 <sqlite3VdbeExec+0x14135>
   635d5:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   635e0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   635eb:	mov    QWORD PTR [rsp+0x190],rdi
   635f3:	mov    rdi,rax
   635f6:	mov    rsi,rcx
   635f9:	xor    eax,eax
   635fb:	call   63600 <sqlite3VdbeExec+0x14160>
   63600:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6360b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   63616:	mov    rdi,QWORD PTR [rsp+0x190]
   6361e:	mov    rax,QWORD PTR [r15+0x8]
   63622:	mov    rcx,QWORD PTR [rax+0x30]
   63626:	and    rcx,0xffffffffffdfffff
   6362d:	mov    QWORD PTR [rax+0x30],rcx
   63631:	xor    r14d,r14d
   63634:	mov    QWORD PTR [rsp+0x200],r15
   6363c:	mov    r15,QWORD PTR [rsp+0x218]
   63644:	mov    DWORD PTR [rsp+0x424],r13d
   6364c:	mov    rbx,r14
   6364f:	lea    r14,[rsp+0x378]
   63657:	jmp    63825 <sqlite3VdbeExec+0x14385>
   6365c:	mov    rbp,QWORD PTR [rsp+0x1c8]
   63664:	mov    r11,r15
   63667:	mov    r15,r13
   6366a:	mov    r13,r11
   6366d:	mov    DWORD PTR [rsp+0x424],r13d
   63675:	lea    r13,[rsp+0x44c]
   6367d:	cmp    BYTE PTR [r13+0x0],0x1
   63682:	jne    636a0 <sqlite3VdbeExec+0x14200>
   63684:	lea    r13,[rsp+0x418]
   6368c:	cmp    DWORD PTR [r13+0x0],0x0
   63691:	jne    636a0 <sqlite3VdbeExec+0x14200>
   63693:	mov    QWORD PTR [rsp+0x200],r15
   6369b:	jmp    6372e <sqlite3VdbeExec+0x1428e>
   636a0:	lea    rax,[rip+0x0]        # 636a7 <sqlite3VdbeExec+0x14207>
   636a7:	mov    ecx,0x1
   636ac:	lea    r13,[rsp+0x44c]
   636b4:	movzx  edx,BYTE PTR [r13+0x0]
   636b9:	lea    r13,[rsp+0x418]
   636c1:	mov    esi,DWORD PTR [r13+0x0]
   636c5:	mov    QWORD PTR [rsp+0x200],r15
   636cd:	lea    r13,[rsp+0x378]
   636d5:	xor    r15d,r15d
   636d8:	mov    QWORD PTR [rsp],rsi
   636dc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   636e7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   636f2:	mov    QWORD PTR [rsp+0x190],rdi
   636fa:	mov    rdi,r13
   636fd:	mov    rsi,rax
   63700:	mov    r8,r15
   63703:	mov    r9,rdx
   63706:	mov    rdx,r14
   63709:	xor    eax,eax
   6370b:	call   63710 <sqlite3VdbeExec+0x14270>
   63710:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6371b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   63726:	mov    rdi,QWORD PTR [rsp+0x190]
   6372e:	mov    rax,rbx
   63731:	mov    ecx,DWORD PTR [r12+rax*4+0x4]
   63736:	lea    r14,[rsp+0x378]
   6373e:	mov    DWORD PTR [r14+0x38],ecx
   63742:	mov    rcx,r14
   63745:	mov    eax,DWORD PTR [r12+rax*4+0x4]
   6374a:	lea    r13,[rsp+0x1f8]
   63752:	mov    rdx,r13
   63755:	movabs rsi,0x7fffffffffffffff
   6375f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6376a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   63775:	mov    QWORD PTR [rsp+0x190],rdi
   6377d:	mov    rdi,rcx
   63780:	mov    rcx,rsi
   63783:	mov    rsi,rax
   63786:	call   6378b <sqlite3VdbeExec+0x142eb>
   6378b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63796:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   637a1:	mov    rdi,QWORD PTR [rsp+0x190]
   637a9:	mov    rax,QWORD PTR [r14+0x78]
   637ad:	mov    rcx,rbx
   637b0:	imul   rcx,rcx,0x38
   637b4:	mov    r15,QWORD PTR [rsp+0x218]
   637bc:	lea    rdx,[r15+rcx*1]
   637c0:	movzx  ecx,WORD PTR [r15+rcx*1+0x14]
   637c6:	and    ecx,0x9000
   637cc:	test   ecx,ecx
   637ce:	je     63819 <sqlite3VdbeExec+0x14379>
   637d0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   637db:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   637e6:	mov    QWORD PTR [rsp+0x190],rdi
   637ee:	mov    rdi,rdx
   637f1:	mov    rsi,rax
   637f4:	call   637f9 <sqlite3VdbeExec+0x14359>
   637f9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63804:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6380f:	mov    rdi,QWORD PTR [rsp+0x190]
   63817:	jmp    63822 <sqlite3VdbeExec+0x14382>
   63819:	mov    QWORD PTR [rdx],rax
   6381c:	mov    WORD PTR [rdx+0x14],0x4
   63822:	add    ebx,0x1
   63825:	mov    r13d,DWORD PTR [rsp+0x428]
   6382d:	cmp    ebx,r13d
   63830:	jl     6384f <sqlite3VdbeExec+0x143af>
   63832:	mov    r13,QWORD PTR [rsp+0x200]
   6383a:	mov    r15d,DWORD PTR [rsp+0x424]
   63842:	mov    QWORD PTR [rsp+0x1c8],rbp
   6384a:	jmp    63a36 <sqlite3VdbeExec+0x14596>
   6384f:	cmp    DWORD PTR [r14+0x1c],0x0
   63854:	jne    63873 <sqlite3VdbeExec+0x143d3>
   63856:	mov    r13,QWORD PTR [rsp+0x200]
   6385e:	mov    r15d,DWORD PTR [rsp+0x424]
   63866:	mov    QWORD PTR [rsp+0x1c8],rbp
   6386e:	jmp    63a36 <sqlite3VdbeExec+0x14596>
   63873:	mov    QWORD PTR [r14+0x78],0x0
   6387b:	mov    rax,rbx
   6387e:	cmp    DWORD PTR [r12+rax*4+0x4],0x0
   63884:	jne    638a3 <sqlite3VdbeExec+0x14403>
   63886:	mov    DWORD PTR [rsp+0x428],r13d
   6388e:	mov    QWORD PTR [rsp+0x218],r15
   63896:	lea    r13,[rsp+0x1f8]
   6389e:	jmp    637a9 <sqlite3VdbeExec+0x14309>
   638a3:	mov    r13,QWORD PTR [rsp+0x200]
   638ab:	cmp    BYTE PTR [r13+0x21],0x0
   638b0:	jne    638bf <sqlite3VdbeExec+0x1441f>
   638b2:	mov    QWORD PTR [rsp+0x218],r15
   638ba:	jmp    6372e <sqlite3VdbeExec+0x1428e>
   638bf:	mov    rax,rbx
   638c2:	cmp    DWORD PTR [r12+rax*4+0x4],0x1
   638c8:	ja     638df <sqlite3VdbeExec+0x1443f>
   638ca:	mov    QWORD PTR [rsp+0x218],r15
   638d2:	mov    QWORD PTR [rsp+0x200],r13
   638da:	jmp    6372e <sqlite3VdbeExec+0x1428e>
   638df:	mov    QWORD PTR [rsp+0x218],r15
   638e7:	mov    r15d,DWORD PTR [rsp+0x424]
   638ef:	test   r15d,r15d
   638f2:	je     63901 <sqlite3VdbeExec+0x14461>
   638f4:	mov    QWORD PTR [rsp+0x200],r13
   638fc:	jmp    6372e <sqlite3VdbeExec+0x1428e>
   63901:	mov    rax,rbx
   63904:	mov    r14d,DWORD PTR [r12+rax*4+0x4]
   63909:	mov    QWORD PTR [rsp+0x1c8],rbp
   63911:	lea    rbp,[rsp+0x378]
   63919:	mov    rax,QWORD PTR [rbp+0x0]
   6391d:	lea    rbp,[rsp+0x44c]
   63925:	mov    rcx,rbp
   63928:	lea    rbp,[rsp+0x418]
   63930:	mov    rdx,rbp
   63933:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6393e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   63949:	mov    QWORD PTR [rsp+0x190],rdi
   63951:	mov    rdi,rax
   63954:	mov    rsi,r14
   63957:	mov    r11,rdx
   6395a:	mov    rdx,rcx
   6395d:	mov    rcx,r11
   63960:	call   63965 <sqlite3VdbeExec+0x144c5>
   63965:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63970:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6397b:	mov    rdi,QWORD PTR [rsp+0x190]
   63983:	test   eax,eax
   63985:	je     6365c <sqlite3VdbeExec+0x141bc>
   6398b:	cmp    eax,0x7
   6398e:	je     639a1 <sqlite3VdbeExec+0x14501>
   63990:	cmp    eax,0xc0a
   63995:	je     639a1 <sqlite3VdbeExec+0x14501>
   63997:	lea    rbp,[rsp+0x378]
   6399f:	jmp    639c6 <sqlite3VdbeExec+0x14526>
   639a1:	lea    rbp,[rsp+0x378]
   639a9:	mov    DWORD PTR [rbp+0x24],0x7
   639b0:	mov    DWORD PTR [rbp+0x1c],0x0
   639b7:	cmp    DWORD PTR [rbp+0x20],0x0
   639bb:	jne    639c6 <sqlite3VdbeExec+0x14526>
   639bd:	mov    eax,DWORD PTR [rbp+0x20]
   639c0:	add    eax,0x1
   639c3:	mov    DWORD PTR [rbp+0x20],eax
   639c6:	lea    rax,[rip+0x0]        # 639cd <sqlite3VdbeExec+0x1452d>
   639cd:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   639d8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   639e3:	mov    QWORD PTR [rsp+0x190],rdi
   639eb:	mov    rdi,rbp
   639ee:	mov    rsi,rax
   639f1:	mov    rdx,r14
   639f4:	xor    eax,eax
   639f6:	call   639fb <sqlite3VdbeExec+0x1455b>
   639fb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63a06:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   63a11:	mov    rdi,QWORD PTR [rsp+0x190]
   63a19:	mov    QWORD PTR [rsp+0x200],r13
   63a21:	mov    DWORD PTR [rsp+0x424],r15d
   63a29:	mov    rbp,QWORD PTR [rsp+0x1c8]
   63a31:	jmp    6372e <sqlite3VdbeExec+0x1428e>
   63a36:	mov    rax,QWORD PTR [r13+0x8]
   63a3a:	mov    rbx,QWORD PTR [rsp+0x220]
   63a42:	mov    QWORD PTR [rax+0x30],rbx
   63a46:	test   r15d,r15d
   63a49:	je     63a60 <sqlite3VdbeExec+0x145c0>
   63a4b:	mov    rbp,QWORD PTR [rsp+0x1c8]
   63a53:	lea    rbx,[rsp+0x378]
   63a5b:	jmp    6321e <sqlite3VdbeExec+0x13d7e>
   63a60:	mov    ebx,0x1
   63a65:	mov    r14,QWORD PTR [rsp+0x1a8]
   63a6d:	mov    rbp,QWORD PTR [rsp+0x1c8]
   63a75:	mov    r12,rbx
   63a78:	mov    rbx,QWORD PTR [rsp+0x1e0]
   63a80:	jmp    63bf6 <sqlite3VdbeExec+0x14756>
   63a85:	mov    QWORD PTR [rsp+0x1a8],r14
   63a8d:	mov    r14,r12
   63a90:	mov    QWORD PTR [rsp+0x1c8],rbp
   63a98:	mov    rbp,r15
   63a9b:	mov    QWORD PTR [rsp+0x1e0],rbx
   63aa3:	mov    eax,DWORD PTR [r13+0x38]
   63aa7:	mov    edx,0xcccccccd
   63aac:	mul    edx
   63aae:	shr    edx,0x2
   63ab1:	mov    eax,edx
   63ab3:	lea    ecx,[rax+0x1]
   63ab6:	mov    eax,r14d
   63ab9:	sub    eax,0x2
   63abc:	xor    edx,edx
   63abe:	div    ecx
   63ac0:	imul   eax,ecx
   63ac3:	lea    ecx,[rax+0x2]
   63ac6:	mov    eax,DWORD PTR [rip+0x0]        # 63acc <sqlite3VdbeExec+0x1462c>
   63acc:	mov    esi,DWORD PTR [r13+0x34]
   63ad0:	xor    edx,edx
   63ad2:	div    esi
   63ad4:	add    eax,0x1
   63ad7:	xor    edx,edx
   63ad9:	mov    esi,0x1
   63ade:	cmp    ecx,eax
   63ae0:	cmove  edx,esi
   63ae3:	lea    eax,[rcx+rdx*1]
   63ae6:	cmp    eax,r14d
   63ae9:	jne    63af2 <sqlite3VdbeExec+0x14652>
   63aeb:	cmp    BYTE PTR [r13+0x21],0x0
   63af0:	jne    63b48 <sqlite3VdbeExec+0x146a8>
   63af2:	mov    rax,rbp
   63af5:	lea    rcx,[rip+0x0]        # 63afc <sqlite3VdbeExec+0x1465c>
   63afc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   63b07:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   63b12:	mov    QWORD PTR [rsp+0x190],rdi
   63b1a:	mov    rdi,rax
   63b1d:	mov    rsi,rcx
   63b20:	mov    rdx,r14
   63b23:	xor    eax,eax
   63b25:	call   63b2a <sqlite3VdbeExec+0x1468a>
   63b2a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63b35:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   63b40:	mov    rdi,QWORD PTR [rsp+0x190]
   63b48:	mov    rax,QWORD PTR [rbp+0x10]
   63b4c:	mov    ecx,r14d
   63b4f:	shr    ecx,0x3
   63b52:	movzx  eax,BYTE PTR [rax+rcx*1]
   63b56:	mov    edx,0x1
   63b5b:	mov    ecx,r14d
   63b5e:	and    ecx,0x7
   63b61:	shl    edx,cl
   63b63:	and    eax,edx
   63b65:	test   eax,eax
   63b67:	je     63bd7 <sqlite3VdbeExec+0x14737>
   63b69:	cmp    r14d,0x2
   63b6d:	jae    63cd6 <sqlite3VdbeExec+0x14836>
   63b73:	xor    eax,eax
   63b75:	cmp    eax,r14d
   63b78:	jne    63bd7 <sqlite3VdbeExec+0x14737>
   63b7a:	cmp    BYTE PTR [r13+0x21],0x0
   63b7f:	je     63bd7 <sqlite3VdbeExec+0x14737>
   63b81:	mov    rax,rbp
   63b84:	lea    rcx,[rip+0x0]        # 63b8b <sqlite3VdbeExec+0x146eb>
   63b8b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   63b96:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   63ba1:	mov    QWORD PTR [rsp+0x190],rdi
   63ba9:	mov    rdi,rax
   63bac:	mov    rsi,rcx
   63baf:	mov    rdx,r14
   63bb2:	xor    eax,eax
   63bb4:	call   63bb9 <sqlite3VdbeExec+0x14719>
   63bb9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63bc4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   63bcf:	mov    rdi,QWORD PTR [rsp+0x190]
   63bd7:	add    r14d,0x1
   63bdb:	mov    rbp,QWORD PTR [rsp+0x1c8]
   63be3:	mov    rbx,QWORD PTR [rsp+0x1e0]
   63beb:	mov    r12,r14
   63bee:	mov    r14,QWORD PTR [rsp+0x1a8]
   63bf6:	lea    r15,[rsp+0x378]
   63bfe:	cmp    r12d,DWORD PTR [r15+0x18]
   63c02:	jbe    63c1c <sqlite3VdbeExec+0x1477c>
   63c04:	mov    QWORD PTR [rsp+0x1a8],r14
   63c0c:	mov    QWORD PTR [rsp+0x1e0],rbx
   63c14:	mov    rbx,r15
   63c17:	jmp    6321e <sqlite3VdbeExec+0x13d7e>
   63c1c:	cmp    DWORD PTR [r15+0x1c],0x0
   63c21:	jne    63c3b <sqlite3VdbeExec+0x1479b>
   63c23:	mov    QWORD PTR [rsp+0x1a8],r14
   63c2b:	mov    QWORD PTR [rsp+0x1e0],rbx
   63c33:	mov    rbx,r15
   63c36:	jmp    6321e <sqlite3VdbeExec+0x13d7e>
   63c3b:	mov    rax,QWORD PTR [r15+0x10]
   63c3f:	mov    ecx,r12d
   63c42:	shr    ecx,0x3
   63c45:	movzx  eax,BYTE PTR [rax+rcx*1]
   63c49:	mov    edx,0x1
   63c4e:	mov    ecx,r12d
   63c51:	and    ecx,0x7
   63c54:	shl    edx,cl
   63c56:	and    eax,edx
   63c58:	test   eax,eax
   63c5a:	je     63c7f <sqlite3VdbeExec+0x147df>
   63c5c:	mov    QWORD PTR [rsp+0x1a8],r14
   63c64:	mov    r14,r12
   63c67:	mov    QWORD PTR [rsp+0x1c8],rbp
   63c6f:	mov    rbp,r15
   63c72:	mov    QWORD PTR [rsp+0x1e0],rbx
   63c7a:	jmp    63b48 <sqlite3VdbeExec+0x146a8>
   63c7f:	cmp    r12d,0x2
   63c83:	jae    63a85 <sqlite3VdbeExec+0x145e5>
   63c89:	xor    eax,eax
   63c8b:	cmp    eax,r12d
   63c8e:	jne    63cb3 <sqlite3VdbeExec+0x14813>
   63c90:	mov    QWORD PTR [rsp+0x1a8],r14
   63c98:	mov    r14,r12
   63c9b:	mov    QWORD PTR [rsp+0x1c8],rbp
   63ca3:	mov    rbp,r15
   63ca6:	mov    QWORD PTR [rsp+0x1e0],rbx
   63cae:	jmp    63aeb <sqlite3VdbeExec+0x1464b>
   63cb3:	mov    QWORD PTR [rsp+0x1a8],r14
   63cbb:	mov    r14,r12
   63cbe:	mov    QWORD PTR [rsp+0x1c8],rbp
   63cc6:	mov    rbp,r15
   63cc9:	mov    QWORD PTR [rsp+0x1e0],rbx
   63cd1:	jmp    63af2 <sqlite3VdbeExec+0x14652>
   63cd6:	mov    r15,rbp
   63cd9:	mov    r12,r14
   63cdc:	mov    r14,QWORD PTR [rsp+0x1a8]
   63ce4:	mov    rbp,QWORD PTR [rsp+0x1c8]
   63cec:	mov    rbx,QWORD PTR [rsp+0x1e0]
   63cf4:	mov    eax,DWORD PTR [r13+0x38]
   63cf8:	mov    edx,0xcccccccd
   63cfd:	mul    edx
   63cff:	shr    edx,0x2
   63d02:	mov    eax,edx
   63d04:	lea    ecx,[rax+0x1]
   63d07:	mov    eax,r12d
   63d0a:	sub    eax,0x2
   63d0d:	xor    edx,edx
   63d0f:	div    ecx
   63d11:	imul   eax,ecx
   63d14:	lea    ecx,[rax+0x2]
   63d17:	mov    eax,DWORD PTR [rip+0x0]        # 63d1d <sqlite3VdbeExec+0x1487d>
   63d1d:	mov    esi,DWORD PTR [r13+0x34]
   63d21:	xor    edx,edx
   63d23:	div    esi
   63d25:	add    eax,0x1
   63d28:	xor    edx,edx
   63d2a:	mov    esi,0x1
   63d2f:	cmp    ecx,eax
   63d31:	cmove  edx,esi
   63d34:	lea    eax,[rcx+rdx*1]
   63d37:	cmp    eax,r12d
   63d3a:	je     63d5f <sqlite3VdbeExec+0x148bf>
   63d3c:	mov    QWORD PTR [rsp+0x1a8],r14
   63d44:	mov    r14,r12
   63d47:	mov    QWORD PTR [rsp+0x1c8],rbp
   63d4f:	mov    rbp,r15
   63d52:	mov    QWORD PTR [rsp+0x1e0],rbx
   63d5a:	jmp    63bd7 <sqlite3VdbeExec+0x14737>
   63d5f:	mov    QWORD PTR [rsp+0x1a8],r14
   63d67:	mov    r14,r12
   63d6a:	mov    QWORD PTR [rsp+0x1c8],rbp
   63d72:	mov    rbp,r15
   63d75:	mov    QWORD PTR [rsp+0x1e0],rbx
   63d7d:	jmp    63b7a <sqlite3VdbeExec+0x146da>
   63d82:	mov    rax,QWORD PTR [rip+0x0]        # 63d89 <sqlite3VdbeExec+0x148e9>
   63d89:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   63d94:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   63d9f:	mov    rdi,r12
   63da2:	mov    r10,rax
   63da5:	call   r10
   63da8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63db3:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   63dbe:	mov    rdi,QWORD PTR [rsp+0x190]
   63dc6:	mov    eax,DWORD PTR [rbx+0x20]
   63dc9:	mov    DWORD PTR [rsp+0x41c],eax
   63dd0:	cmp    DWORD PTR [rbx+0x20],0x0
   63dd4:	jne    63e72 <sqlite3VdbeExec+0x149d2>
   63dda:	movzx  eax,BYTE PTR [rbx+0x65]
   63dde:	and    eax,0x4
   63de1:	test   eax,eax
   63de3:	je     63e43 <sqlite3VdbeExec+0x149a3>
   63de5:	mov    rax,QWORD PTR [rbx+0x48]
   63de9:	mov    rcx,QWORD PTR [rbx+0x50]
   63ded:	test   rcx,rcx
   63df0:	je     63e39 <sqlite3VdbeExec+0x14999>
   63df2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   63dfd:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   63e08:	mov    QWORD PTR [rsp+0x190],rdi
   63e10:	mov    rdi,rax
   63e13:	mov    rsi,rcx
   63e16:	call   63e1b <sqlite3VdbeExec+0x1497b>
   63e1b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63e26:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   63e31:	mov    rdi,QWORD PTR [rsp+0x190]
   63e39:	movzx  eax,BYTE PTR [rbx+0x65]
   63e3d:	and    eax,0xfffffffb
   63e40:	mov    BYTE PTR [rbx+0x65],al
   63e43:	mov    DWORD PTR [rbx+0x58],0x0
   63e4a:	mov    DWORD PTR [rbx+0x60],0x0
   63e51:	mov    QWORD PTR [rbx+0x50],0x0
   63e59:	mov    QWORD PTR [rsp+0x210],0x0
   63e65:	mov    r15,QWORD PTR [rsp+0x1e8]
   63e6d:	jmp    63efb <sqlite3VdbeExec+0x14a5b>
   63e72:	lea    rax,[rbx+0x48]
   63e76:	cmp    QWORD PTR [rbx+0x50],0x0
   63e7b:	je     63ee7 <sqlite3VdbeExec+0x14a47>
   63e7d:	mov    rcx,QWORD PTR [rax+0x8]
   63e81:	mov    edx,DWORD PTR [rax+0x18]
   63e84:	mov    BYTE PTR [rcx+rdx*1],0x0
   63e88:	cmp    DWORD PTR [rax+0x14],0x0
   63e8c:	jbe    63ee7 <sqlite3VdbeExec+0x14a47>
   63e8e:	movzx  ecx,BYTE PTR [rax+0x1d]
   63e92:	and    ecx,0x4
   63e95:	test   ecx,ecx
   63e97:	jne    63ee7 <sqlite3VdbeExec+0x14a47>
   63e99:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   63ea4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   63eaf:	mov    QWORD PTR [rsp+0x190],rdi
   63eb7:	mov    rdi,rax
   63eba:	call   63ebf <sqlite3VdbeExec+0x14a1f>
   63ebf:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63eca:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   63ed5:	mov    rdi,QWORD PTR [rsp+0x190]
   63edd:	mov    r15,QWORD PTR [rsp+0x1e8]
   63ee5:	jmp    63ef3 <sqlite3VdbeExec+0x14a53>
   63ee7:	mov    rax,QWORD PTR [rax+0x8]
   63eeb:	mov    r15,QWORD PTR [rsp+0x1e8]
   63ef3:	mov    QWORD PTR [rsp+0x210],rax
   63efb:	mov    eax,DWORD PTR [rbx+0x24]
   63efe:	mov    ebx,eax
   63f00:	movzx  eax,WORD PTR [r15+0x14]
   63f05:	and    eax,0x9000
   63f0a:	test   eax,eax
   63f0c:	je     63f54 <sqlite3VdbeExec+0x14ab4>
   63f0e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   63f19:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   63f24:	mov    QWORD PTR [rsp+0x190],rdi
   63f2c:	mov    rdi,r15
   63f2f:	call   63f34 <sqlite3VdbeExec+0x14a94>
   63f34:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   63f3f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   63f4a:	mov    rdi,QWORD PTR [rsp+0x190]
   63f52:	jmp    63f5b <sqlite3VdbeExec+0x14abb>
   63f54:	mov    WORD PTR [r15+0x14],0x1
   63f5b:	cmp    DWORD PTR [rsp+0x41c],0x0
   63f63:	jne    63f72 <sqlite3VdbeExec+0x14ad2>
   63f65:	mov    r12,QWORD PTR [rsp+0x1e0]
   63f6d:	jmp    640c7 <sqlite3VdbeExec+0x14c27>
   63f72:	test   ebx,ebx
   63f74:	je     64034 <sqlite3VdbeExec+0x14b94>
   63f7a:	mov    r12,QWORD PTR [rsp+0x210]
   63f82:	test   r12,r12
   63f85:	je     6400c <sqlite3VdbeExec+0x14b6c>
   63f8b:	cmp    DWORD PTR [rip+0x0],0x0        # 63f92 <sqlite3VdbeExec+0x14af2>
   63f92:	je     63fec <sqlite3VdbeExec+0x14b4c>
   63f94:	mov    rax,QWORD PTR [rip+0x0]        # 63f9b <sqlite3VdbeExec+0x14afb>
   63f9b:	mov    QWORD PTR [rsp+0x190],rdi
   63fa3:	mov    rdi,r12
   63fa6:	mov    r10,rax
   63fa9:	call   r10
   63fac:	mov    rcx,QWORD PTR [rip+0x0]        # 63fb3 <sqlite3VdbeExec+0x14b13>
   63fb3:	movsxd rax,eax
   63fb6:	sub    rcx,rax
   63fb9:	mov    QWORD PTR [rip+0x0],rcx        # 63fc0 <sqlite3VdbeExec+0x14b20>
   63fc0:	mov    rax,QWORD PTR [rip+0x0]        # 63fc7 <sqlite3VdbeExec+0x14b27>
   63fc7:	sub    rax,0x1
   63fcb:	mov    QWORD PTR [rip+0x0],rax        # 63fd2 <sqlite3VdbeExec+0x14b32>
   63fd2:	mov    rax,QWORD PTR [rip+0x0]        # 63fd9 <sqlite3VdbeExec+0x14b39>
   63fd9:	mov    rdi,r12
   63fdc:	mov    r10,rax
   63fdf:	call   r10
   63fe2:	mov    rdi,QWORD PTR [rsp+0x190]
   63fea:	jmp    6400c <sqlite3VdbeExec+0x14b6c>
   63fec:	mov    rax,QWORD PTR [rip+0x0]        # 63ff3 <sqlite3VdbeExec+0x14b53>
   63ff3:	mov    QWORD PTR [rsp+0x190],rdi
   63ffb:	mov    rdi,r12
   63ffe:	mov    r10,rax
   64001:	call   r10
   64004:	mov    rdi,QWORD PTR [rsp+0x190]
   6400c:	mov    r14,QWORD PTR [rsp+0x1a8]
   64014:	mov    QWORD PTR [rsp+0x1c8],rbp
   6401c:	mov    rbp,rbx
   6401f:	mov    r13,QWORD PTR [rsp+0x1b0]
   64027:	mov    rbx,QWORD PTR [rsp+0x1d8]
   6402f:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   64034:	mov    r13,QWORD PTR [rsp+0x208]
   6403c:	mov    r12,QWORD PTR [rsp+0x1e0]
   64044:	mov    rax,QWORD PTR [r12+r13*1]
   64048:	mov    ecx,DWORD PTR [rsp+0x41c]
   6404f:	sub    ecx,0x1
   64052:	movsxd rcx,ecx
   64055:	sub    rax,rcx
   64058:	mov    QWORD PTR [r12+r13*1],rax
   6405c:	mov    rax,QWORD PTR [rsp+0x210]
   64064:	mov    rcx,0xffffffffffffffff
   6406b:	lea    rdx,[rip+0x0]        # 64072 <sqlite3VdbeExec+0x14bd2>
   64072:	mov    esi,0x1
   64077:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   64082:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6408d:	mov    QWORD PTR [rsp+0x190],rdi
   64095:	mov    rdi,r15
   64098:	mov    r8,rdx
   6409b:	mov    rdx,rcx
   6409e:	mov    rcx,rsi
   640a1:	mov    rsi,rax
   640a4:	call   640a9 <sqlite3VdbeExec+0x14c09>
   640a9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   640b4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   640bf:	mov    rdi,QWORD PTR [rsp+0x190]
   640c7:	mov    r13d,DWORD PTR [rsp+0x3fc]
   640cf:	mov    eax,r13d
   640d2:	movzx  ecx,WORD PTR [r15+0x14]
   640d7:	and    ecx,0x2
   640da:	test   ecx,ecx
   640dc:	jne    640e4 <sqlite3VdbeExec+0x14c44>
   640de:	mov    BYTE PTR [r15+0x16],al
   640e2:	jmp    64136 <sqlite3VdbeExec+0x14c96>
   640e4:	movzx  ecx,BYTE PTR [r15+0x16]
   640e9:	cmp    ecx,eax
   640eb:	jne    640ef <sqlite3VdbeExec+0x14c4f>
   640ed:	jmp    64136 <sqlite3VdbeExec+0x14c96>
   640ef:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   640fa:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   64105:	mov    QWORD PTR [rsp+0x190],rdi
   6410d:	mov    rdi,r15
   64110:	mov    rsi,rax
   64113:	call   64118 <sqlite3VdbeExec+0x14c78>
   64118:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   64123:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6412e:	mov    rdi,QWORD PTR [rsp+0x190]
   64136:	mov    r14,QWORD PTR [rsp+0x1a8]
   6413e:	mov    r15,r13
   64141:	mov    r13,QWORD PTR [rsp+0x1d0]
   64149:	mov    QWORD PTR [rsp+0x1c8],rbp
   64151:	mov    DWORD PTR [rsp+0x40c],ebx
   64158:	mov    ebx,DWORD PTR [rsp+0x410]
   6415f:	mov    QWORD PTR [rsp+0x1e0],r12
   64167:	mov    r12d,DWORD PTR [rsp+0x414]
   6416f:	jmp    4f836 <sqlite3VdbeExec+0x396>
   64174:	mov    QWORD PTR [rsp+0x1a8],r14
   6417c:	mov    r13d,DWORD PTR [rsp+0x3fc]
   64184:	mov    QWORD PTR [rsp+0x1b0],r12
   6418c:	mov    r12,rbx
   6418f:	mov    rax,QWORD PTR [rdi+0x78]
   64193:	movsxd rcx,DWORD PTR [rbp+0x4]
   64197:	mov    rbx,QWORD PTR [rax+rcx*8]
   6419b:	lea    r14,[rsp+0x268]
   641a3:	mov    rax,r14
   641a6:	xor    ecx,ecx
   641a8:	mov    edx,0x28
   641ad:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   641b8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   641c3:	mov    QWORD PTR [rsp+0x190],rdi
   641cb:	mov    rdi,rax
   641ce:	mov    rsi,rcx
   641d1:	call   641d6 <sqlite3VdbeExec+0x14d36>
   641d6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   641e1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   641ec:	movsxd rax,DWORD PTR [rbp+0xc]
   641f0:	imul   rax,rax,0x38
   641f4:	add    rax,r12
   641f7:	mov    QWORD PTR [rsp+0x270],rax
   641ff:	mov    rax,QWORD PTR [rbp+0x10]
   64203:	movzx  eax,WORD PTR [rax+0x60]
   64207:	mov    WORD PTR [rsp+0x284],ax
   6420f:	mov    rax,QWORD PTR [rbx+0x30]
   64213:	mov    QWORD PTR [rsp+0x268],rax
   6421b:	mov    rax,QWORD PTR [rbx+0x28]
   6421f:	mov    rcx,QWORD PTR [rbp+0x10]
   64223:	mov    rdx,r14
   64226:	lea    r15,[rsp+0x41c]
   6422e:	mov    rsi,r15
   64231:	mov    r8d,0x1
   64237:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   64242:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6424d:	mov    rdi,rax
   64250:	mov    r11,rsi
   64253:	mov    rsi,rcx
   64256:	mov    rcx,r11
   64259:	call   6425e <sqlite3VdbeExec+0x14dbe>
   6425e:	mov    r15d,eax
   64261:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6426c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   64277:	mov    rdi,QWORD PTR [rsp+0x190]
   6427f:	test   r15d,r15d
   64282:	jne    6428e <sqlite3VdbeExec+0x14dee>
   64284:	cmp    DWORD PTR [rsp+0x41c],0x0
   6428c:	je     642ac <sqlite3VdbeExec+0x14e0c>
   6428e:	mov    r15,r13
   64291:	mov    rbx,r12
   64294:	mov    r12,QWORD PTR [rsp+0x1a8]
   6429c:	xor    r11d,r11d
   6429f:	mov    DWORD PTR [rsp+0x40c],r11d
   642a7:	jmp    52730 <sqlite3VdbeExec+0x3290>
   642ac:	mov    BYTE PTR [rbx+0x2],0x0
   642b0:	mov    r14,QWORD PTR [rsp+0x1a8]
   642b8:	mov    DWORD PTR [rsp+0x3fc],r13d
   642c0:	mov    DWORD PTR [rsp+0x40c],r15d
   642c8:	mov    rbx,r12
   642cb:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   642d0:	mov    r15d,DWORD PTR [rsp+0x3fc]
   642d8:	mov    r13,QWORD PTR [rsp+0x1d0]
   642e0:	mov    QWORD PTR [rsp+0x1b0],r12
   642e8:	mov    r12d,DWORD PTR [rsp+0x414]
   642f0:	movsxd rax,DWORD PTR [rbp+0x4]
   642f4:	imul   rax,rax,0x38
   642f8:	mov    QWORD PTR [rsp+0x1d0],r13
   64300:	lea    r13,[rbx+rax*1]
   64304:	movsxd rcx,DWORD PTR [rbp+0x8]
   64308:	mov    QWORD PTR [rsp+0x1a8],r14
   64310:	imul   r14,rcx,0x38
   64314:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   64319:	and    eax,0x10
   6431c:	test   eax,eax
   6431e:	jne    64388 <sqlite3VdbeExec+0x14ee8>
   64320:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6432b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   64336:	mov    QWORD PTR [rsp+0x190],rdi
   6433e:	mov    rdi,r13
   64341:	call   64346 <sqlite3VdbeExec+0x14ea6>
   64346:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   64351:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6435c:	mov    rdi,QWORD PTR [rsp+0x190]
   64364:	test   eax,eax
   64366:	je     64388 <sqlite3VdbeExec+0x14ee8>
   64368:	mov    r14,QWORD PTR [rsp+0x1a8]
   64370:	mov    r13,QWORD PTR [rsp+0x1d0]
   64378:	mov    rbx,rbp
   6437b:	mov    rbp,QWORD PTR [rsp+0x1d8]
   64383:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   64388:	mov    r13,QWORD PTR [r13+0x8]
   6438c:	mov    r14,QWORD PTR [rbx+r14*1]
   64390:	cmp    WORD PTR [r13+0x30],0x0
   64396:	jne    6440b <sqlite3VdbeExec+0x14f6b>
   64398:	mov    rax,QWORD PTR [r13+0x8]
   6439c:	mov    ecx,0x3f8
   643a1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   643ac:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   643b7:	mov    QWORD PTR [rsp+0x190],rdi
   643bf:	mov    rdi,rax
   643c2:	mov    rsi,rcx
   643c5:	call   643ca <sqlite3VdbeExec+0x14f2a>
   643ca:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   643d5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   643e0:	mov    rdi,QWORD PTR [rsp+0x190]
   643e8:	test   rax,rax
   643eb:	jne    643f1 <sqlite3VdbeExec+0x14f51>
   643ed:	xor    eax,eax
   643ef:	jmp    64424 <sqlite3VdbeExec+0x14f84>
   643f1:	mov    rcx,QWORD PTR [r13+0x0]
   643f5:	mov    QWORD PTR [rax],rcx
   643f8:	mov    QWORD PTR [r13+0x0],rax
   643fc:	add    rax,0x8
   64400:	mov    QWORD PTR [r13+0x20],rax
   64404:	mov    WORD PTR [r13+0x30],0x2a
   6440b:	movzx  eax,WORD PTR [r13+0x30]
   64410:	sub    eax,0x1
   64413:	mov    WORD PTR [r13+0x30],ax
   64418:	mov    rax,QWORD PTR [r13+0x20]
   6441c:	lea    rcx,[rax+0x18]
   64420:	mov    QWORD PTR [r13+0x20],rcx
   64424:	test   rax,rax
   64427:	je     6445d <sqlite3VdbeExec+0x14fbd>
   64429:	mov    QWORD PTR [rax],r14
   6442c:	mov    QWORD PTR [rax+0x8],0x0
   64434:	mov    rcx,QWORD PTR [r13+0x18]
   64438:	test   rcx,rcx
   6443b:	je     64455 <sqlite3VdbeExec+0x14fb5>
   6443d:	cmp    r14,QWORD PTR [rcx]
   64440:	jg     6444f <sqlite3VdbeExec+0x14faf>
   64442:	movzx  edx,WORD PTR [r13+0x32]
   64447:	and    edx,0xfffffffe
   6444a:	mov    WORD PTR [r13+0x32],dx
   6444f:	mov    QWORD PTR [rcx+0x8],rax
   64453:	jmp    64459 <sqlite3VdbeExec+0x14fb9>
   64455:	mov    QWORD PTR [r13+0x10],rax
   64459:	mov    QWORD PTR [r13+0x18],rax
   6445d:	mov    r14,QWORD PTR [rsp+0x1a8]
   64465:	mov    DWORD PTR [rsp+0x3fc],r15d
   6446d:	mov    DWORD PTR [rsp+0x414],r12d
   64475:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6447a:	mov    QWORD PTR [rsp+0x1a8],r14
   64482:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6448a:	mov    QWORD PTR [rsp+0x1b0],r12
   64492:	mov    r12d,DWORD PTR [rsp+0x414]
   6449a:	movsxd rax,DWORD PTR [rbp+0x4]
   6449e:	imul   rax,rax,0x38
   644a2:	lea    r13,[rbx+rax*1]
   644a6:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   644ab:	and    eax,0x10
   644ae:	test   eax,eax
   644b0:	je     64669 <sqlite3VdbeExec+0x151c9>
   644b6:	mov    r14,QWORD PTR [r13+0x8]
   644ba:	movzx  eax,WORD PTR [r14+0x32]
   644bf:	and    eax,0x2
   644c2:	test   eax,eax
   644c4:	jne    6452b <sqlite3VdbeExec+0x1508b>
   644c6:	movzx  eax,WORD PTR [r14+0x32]
   644cb:	and    eax,0x1
   644ce:	test   eax,eax
   644d0:	jne    6451e <sqlite3VdbeExec+0x1507e>
   644d2:	mov    rax,QWORD PTR [r14+0x10]
   644d6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   644e1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   644ec:	mov    QWORD PTR [rsp+0x190],rdi
   644f4:	mov    rdi,rax
   644f7:	call   644fc <sqlite3VdbeExec+0x1505c>
   644fc:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   64507:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   64512:	mov    QWORD PTR [r14+0x10],rax
   64516:	mov    rdi,QWORD PTR [rsp+0x190]
   6451e:	movzx  eax,WORD PTR [r14+0x32]
   64523:	or     eax,0x3
   64526:	mov    WORD PTR [r14+0x32],ax
   6452b:	cmp    QWORD PTR [r14+0x10],0x0
   64530:	je     64669 <sqlite3VdbeExec+0x151c9>
   64536:	mov    rax,QWORD PTR [r14+0x10]
   6453a:	mov    rax,QWORD PTR [rax]
   6453d:	mov    QWORD PTR [rsp+0x210],rax
   64545:	mov    rax,QWORD PTR [r14+0x10]
   64549:	mov    rax,QWORD PTR [rax+0x8]
   6454d:	mov    QWORD PTR [r14+0x10],rax
   64551:	cmp    QWORD PTR [r14+0x10],0x0
   64556:	jne    645fa <sqlite3VdbeExec+0x1515a>
   6455c:	mov    r13,QWORD PTR [r14]
   6455f:	jmp    645c8 <sqlite3VdbeExec+0x15128>
   64561:	mov    DWORD PTR [rsp+0x414],r12d
   64569:	mov    r12,QWORD PTR [r13+0x0]
   6456d:	mov    rax,QWORD PTR [r14+0x8]
   64571:	test   r13,r13
   64574:	je     645bd <sqlite3VdbeExec+0x1511d>
   64576:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   64581:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6458c:	mov    QWORD PTR [rsp+0x190],rdi
   64594:	mov    rdi,rax
   64597:	mov    rsi,r13
   6459a:	call   6459f <sqlite3VdbeExec+0x150ff>
   6459f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   645aa:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   645b5:	mov    rdi,QWORD PTR [rsp+0x190]
   645bd:	mov    r13,r12
   645c0:	mov    r12d,DWORD PTR [rsp+0x414]
   645c8:	test   r13,r13
   645cb:	jne    64561 <sqlite3VdbeExec+0x150c1>
   645cd:	mov    QWORD PTR [r14],0x0
   645d4:	mov    WORD PTR [r14+0x30],0x0
   645db:	mov    QWORD PTR [r14+0x10],0x0
   645e3:	mov    QWORD PTR [r14+0x18],0x0
   645eb:	mov    QWORD PTR [r14+0x28],0x0
   645f3:	mov    WORD PTR [r14+0x32],0x1
   645fa:	movsxd rax,DWORD PTR [rbp+0xc]
   645fe:	imul   rax,rax,0x38
   64602:	lea    rcx,[rbx+rax*1]
   64606:	mov    rdx,QWORD PTR [rsp+0x210]
   6460e:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   64613:	and    eax,0x9000
   64618:	test   eax,eax
   6461a:	je     646d9 <sqlite3VdbeExec+0x15239>
   64620:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6462b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   64636:	mov    QWORD PTR [rsp+0x190],rdi
   6463e:	mov    rdi,rcx
   64641:	mov    rsi,rdx
   64644:	call   64649 <sqlite3VdbeExec+0x151a9>
   64649:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   64654:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6465f:	mov    rdi,QWORD PTR [rsp+0x190]
   64667:	jmp    646e2 <sqlite3VdbeExec+0x15242>
   64669:	movzx  eax,WORD PTR [r13+0x14]
   6466e:	and    eax,0x9000
   64673:	test   eax,eax
   64675:	je     646bd <sqlite3VdbeExec+0x1521d>
   64677:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   64682:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6468d:	mov    QWORD PTR [rsp+0x190],rdi
   64695:	mov    rdi,r13
   64698:	call   6469d <sqlite3VdbeExec+0x151fd>
   6469d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   646a8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   646b3:	mov    rdi,QWORD PTR [rsp+0x190]
   646bb:	jmp    646c4 <sqlite3VdbeExec+0x15224>
   646bd:	mov    WORD PTR [r13+0x14],0x1
   646c4:	mov    r14,QWORD PTR [rsp+0x1a8]
   646cc:	mov    r13,QWORD PTR [rsp+0x1d0]
   646d4:	jmp    4f80d <sqlite3VdbeExec+0x36d>
   646d9:	mov    QWORD PTR [rcx],rdx
   646dc:	mov    WORD PTR [rcx+0x14],0x4
   646e2:	mov    r14,QWORD PTR [rsp+0x1a8]
   646ea:	mov    r13,QWORD PTR [rsp+0x1d0]
   646f2:	mov    QWORD PTR [rsp+0x1c8],rbp
   646fa:	mov    QWORD PTR [rsp+0x1e0],rbx
   64702:	mov    ebx,DWORD PTR [rsp+0x410]
   64709:	jmp    4f836 <sqlite3VdbeExec+0x396>
   6470e:	mov    QWORD PTR [rsp+0x1a8],r14
   64716:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6471e:	mov    QWORD PTR [rsp+0x1b0],r12
   64726:	mov    r12d,DWORD PTR [rsp+0x414]
   6472e:	movsxd rax,DWORD PTR [rbp+0x4]
   64732:	imul   rax,rax,0x38
   64736:	lea    r13,[rbx+rax*1]
   6473a:	movsxd rcx,DWORD PTR [rbp+0xc]
   6473e:	imul   r14,rcx,0x38
   64742:	mov    QWORD PTR [rsp+0x1c8],rbp
   6474a:	mov    ebp,DWORD PTR [rbp+0x10]
   6474d:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   64752:	and    eax,0x10
   64755:	test   eax,eax
   64757:	jne    647c6 <sqlite3VdbeExec+0x15326>
   64759:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   64764:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6476f:	mov    QWORD PTR [rsp+0x190],rdi
   64777:	mov    rdi,r13
   6477a:	call   6477f <sqlite3VdbeExec+0x152df>
   6477f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6478a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   64795:	mov    rdi,QWORD PTR [rsp+0x190]
   6479d:	test   eax,eax
   6479f:	je     647c6 <sqlite3VdbeExec+0x15326>
   647a1:	mov    r14,QWORD PTR [rsp+0x1a8]
   647a9:	mov    r13,QWORD PTR [rsp+0x1d0]
   647b1:	mov    rbx,QWORD PTR [rsp+0x1c8]
   647b9:	mov    rbp,QWORD PTR [rsp+0x1d8]
   647c1:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   647c6:	test   ebp,ebp
   647c8:	jne    647d7 <sqlite3VdbeExec+0x15337>
   647ca:	mov    DWORD PTR [rsp+0x414],r12d
   647d2:	jmp    64d6b <sqlite3VdbeExec+0x158cb>
   647d7:	mov    DWORD PTR [rsp+0x414],r12d
   647df:	mov    r12,QWORD PTR [r13+0x8]
   647e3:	mov    QWORD PTR [rsp+0x1e8],r14
   647eb:	mov    r14,QWORD PTR [rbx+r14*1]
   647ef:	lea    r8,[rsp+0x230]
   647f7:	lea    r9,[rsp+0x238]
   647ff:	cmp    ebp,DWORD PTR [r12+0x34]
   64804:	jne    6481b <sqlite3VdbeExec+0x1537b>
   64806:	mov    QWORD PTR [rsp+0x210],r13
   6480e:	mov    QWORD PTR [rsp+0x200],r14
   64816:	jmp    64cf8 <sqlite3VdbeExec+0x15858>
   6481b:	mov    QWORD PTR [rsp+0x200],r14
   64823:	mov    r14,QWORD PTR [r12+0x10]
   64828:	test   r14,r14
   6482b:	jne    64841 <sqlite3VdbeExec+0x153a1>
   6482d:	mov    QWORD PTR [rsp+0x210],r13
   64835:	mov    DWORD PTR [rsp+0x41c],ebp
   6483c:	jmp    64cec <sqlite3VdbeExec+0x1584c>
   64841:	mov    QWORD PTR [rsp+0x210],r13
   64849:	lea    r13,[r12+0x28]
   6484e:	movzx  eax,WORD PTR [r12+0x32]
   64854:	and    eax,0x1
   64857:	test   eax,eax
   64859:	jne    648b2 <sqlite3VdbeExec+0x15412>
   6485b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   64866:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   64871:	mov    QWORD PTR [rsp+0x190],rdi
   64879:	mov    rdi,r14
   6487c:	call   64881 <sqlite3VdbeExec+0x153e1>
   64881:	mov    r14,rax
   64884:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6488f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6489a:	mov    rdi,QWORD PTR [rsp+0x190]
   648a2:	lea    r8,[rsp+0x230]
   648aa:	lea    r9,[rsp+0x238]
   648b2:	mov    QWORD PTR [rsp+0x220],r14
   648ba:	mov    r14,QWORD PTR [r12+0x28]
   648bf:	mov    DWORD PTR [rsp+0x41c],ebp
   648c6:	mov    rbp,r14
   648c9:	mov    r14,QWORD PTR [rsp+0x220]
   648d1:	mov    QWORD PTR [rsp+0x1f8],r13
   648d9:	jmp    64aea <sqlite3VdbeExec+0x1564a>
   648de:	mov    QWORD PTR [rsp+0x218],rbp
   648e6:	mov    rbp,QWORD PTR [r8]
   648e9:	mov    rax,QWORD PTR [rbp+0x8]
   648ed:	mov    QWORD PTR [r8],rax
   648f0:	mov    QWORD PTR [rbp+0x10],r13
   648f4:	mov    rax,r8
   648f7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   64902:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6490d:	mov    QWORD PTR [rsp+0x190],rdi
   64915:	mov    rdi,rax
   64918:	mov    rsi,r14
   6491b:	call   64920 <sqlite3VdbeExec+0x15480>
   64920:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6492b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   64936:	mov    QWORD PTR [rbp+0x8],rax
   6493a:	add    r14d,0x1
   6493e:	mov    rdi,QWORD PTR [rsp+0x190]
   64946:	mov    r13,rbp
   64949:	mov    rbp,QWORD PTR [rsp+0x218]
   64951:	lea    r8,[rsp+0x228]
   64959:	cmp    QWORD PTR [r8],0x0
   6495d:	jne    648de <sqlite3VdbeExec+0x1543e>
   64963:	mov    rax,r13
   64966:	mov    r13,QWORD PTR [rsp+0x1f0]
   6496e:	mov    QWORD PTR [r13+0x0],rax
   64972:	test   rbp,rbp
   64975:	jne    64ccb <sqlite3VdbeExec+0x1582b>
   6497b:	cmp    WORD PTR [r12+0x30],0x0
   64982:	jne    64bb1 <sqlite3VdbeExec+0x15711>
   64988:	mov    rax,QWORD PTR [r12+0x8]
   6498d:	mov    ecx,0x3f8
   64992:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6499d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   649a8:	mov    QWORD PTR [rsp+0x190],rdi
   649b0:	mov    rdi,rax
   649b3:	mov    rsi,rcx
   649b6:	call   649bb <sqlite3VdbeExec+0x1551b>
   649bb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   649c6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   649d1:	mov    rdi,QWORD PTR [rsp+0x190]
   649d9:	test   rax,rax
   649dc:	jne    64b95 <sqlite3VdbeExec+0x156f5>
   649e2:	xor    ebp,ebp
   649e4:	jmp    64bce <sqlite3VdbeExec+0x1572e>
   649e9:	mov    QWORD PTR [rsp+0x220],r14
   649f1:	mov    QWORD PTR [rsp+0x1f8],r13
   649f9:	mov    rax,QWORD PTR [rbp+0x10]
   649fd:	mov    rcx,r8
   64a00:	mov    rdx,r9
   64a03:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   64a0e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   64a19:	mov    QWORD PTR [rsp+0x190],rdi
   64a21:	mov    rdi,rax
   64a24:	mov    rsi,rcx
   64a27:	call   64a2c <sqlite3VdbeExec+0x1558c>
   64a2c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   64a37:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   64a42:	mov    QWORD PTR [rbp+0x10],0x0
   64a4a:	lea    r8,[rsp+0x230]
   64a52:	mov    r14,QWORD PTR [r8]
   64a55:	lea    rax,[rsp+0x250]
   64a5d:	mov    r13,rax
   64a60:	mov    rdi,QWORD PTR [rsp+0x190]
   64a68:	mov    QWORD PTR [rsp+0x208],r12
   64a70:	mov    r12,r13
   64a73:	mov    r13,r14
   64a76:	mov    r14,QWORD PTR [rsp+0x220]
   64a7e:	lea    r9,[rsp+0x238]
   64a86:	jmp    64aa8 <sqlite3VdbeExec+0x15608>
   64a88:	mov    QWORD PTR [rsp+0x248],r12
   64a90:	mov    r12,QWORD PTR [rsp+0x208]
   64a98:	mov    QWORD PTR [rsp+0x208],r12
   64aa0:	mov    r12,QWORD PTR [rsp+0x248]
   64aa8:	mov    rcx,QWORD PTR [r13+0x0]
   64aac:	cmp    rcx,QWORD PTR [r14]
   64aaf:	jg     64b66 <sqlite3VdbeExec+0x156c6>
   64ab5:	mov    rcx,QWORD PTR [r13+0x0]
   64ab9:	cmp    rcx,QWORD PTR [r14]
   64abc:	jge    64ac6 <sqlite3VdbeExec+0x15626>
   64abe:	mov    QWORD PTR [r12+0x8],r13
   64ac3:	mov    r12,r13
   64ac6:	mov    r13,QWORD PTR [r13+0x8]
   64aca:	test   r13,r13
   64acd:	jne    64a88 <sqlite3VdbeExec+0x155e8>
   64acf:	mov    QWORD PTR [r12+0x8],r14
   64ad4:	mov    rax,QWORD PTR [rax+0x8]
   64ad8:	mov    r12,rax
   64adb:	mov    rbp,QWORD PTR [rbp+0x8]
   64adf:	mov    r14,r12
   64ae2:	mov    r12,QWORD PTR [rsp+0x208]
   64aea:	test   rbp,rbp
   64aed:	jne    64afc <sqlite3VdbeExec+0x1565c>
   64aef:	mov    QWORD PTR [rsp+0x220],r14
   64af7:	jmp    64972 <sqlite3VdbeExec+0x154d2>
   64afc:	lea    r13,[rbp+0x8]
   64b00:	cmp    QWORD PTR [rbp+0x10],0x0
   64b05:	jne    649e9 <sqlite3VdbeExec+0x15549>
   64b0b:	mov    QWORD PTR [rsp+0x1f8],r13
   64b13:	lea    r13,[rbp+0x10]
   64b17:	lea    r8,[rsp+0x228]
   64b1f:	mov    QWORD PTR [rsp+0x228],r14
   64b27:	mov    QWORD PTR [rsp+0x1f0],r13
   64b2f:	mov    r13,QWORD PTR [rsp+0x228]
   64b37:	mov    rax,QWORD PTR [r13+0x8]
   64b3b:	mov    QWORD PTR [rsp+0x228],rax
   64b43:	mov    QWORD PTR [r13+0x8],0x0
   64b4b:	mov    QWORD PTR [r13+0x10],0x0
   64b53:	mov    QWORD PTR [rsp+0x220],r14
   64b5b:	mov    r14d,0x1
   64b61:	jmp    64959 <sqlite3VdbeExec+0x154b9>
   64b66:	mov    QWORD PTR [r12+0x8],r14
   64b6b:	mov    r12,QWORD PTR [r14+0x8]
   64b6f:	test   r12,r12
   64b72:	je     64b8c <sqlite3VdbeExec+0x156ec>
   64b74:	mov    QWORD PTR [rsp+0x248],r14
   64b7c:	mov    r14,r12
   64b7f:	mov    r12,QWORD PTR [rsp+0x208]
   64b87:	jmp    64a98 <sqlite3VdbeExec+0x155f8>
   64b8c:	mov    QWORD PTR [r14+0x8],r13
   64b90:	jmp    64ad4 <sqlite3VdbeExec+0x15634>
   64b95:	mov    rcx,QWORD PTR [r12]
   64b99:	mov    QWORD PTR [rax],rcx
   64b9c:	mov    QWORD PTR [r12],rax
   64ba0:	add    rax,0x8
   64ba4:	mov    QWORD PTR [r12+0x20],rax
   64ba9:	mov    WORD PTR [r12+0x30],0x2a
   64bb1:	movzx  eax,WORD PTR [r12+0x30]
   64bb7:	sub    eax,0x1
   64bba:	mov    WORD PTR [r12+0x30],ax
   64bc0:	mov    rbp,QWORD PTR [r12+0x20]
   64bc5:	lea    rax,[rbp+0x18]
   64bc9:	mov    QWORD PTR [r12+0x20],rax
   64bce:	mov    r14,QWORD PTR [rsp+0x1f8]
   64bd6:	mov    QWORD PTR [r14],rbp
   64bd9:	test   rbp,rbp
   64bdc:	je     64ccb <sqlite3VdbeExec+0x1582b>
   64be2:	mov    QWORD PTR [rbp+0x0],0x0
   64bea:	mov    QWORD PTR [rbp+0x8],0x0
   64bf2:	lea    r8,[rsp+0x1f8]
   64bfa:	mov    r14,QWORD PTR [rsp+0x220]
   64c02:	mov    QWORD PTR [rsp+0x1f8],r14
   64c0a:	mov    r14,QWORD PTR [rsp+0x1f8]
   64c12:	mov    rax,QWORD PTR [r14+0x8]
   64c16:	mov    QWORD PTR [rsp+0x1f8],rax
   64c1e:	mov    QWORD PTR [r14+0x8],0x0
   64c26:	mov    QWORD PTR [r14+0x10],0x0
   64c2e:	mov    r13d,0x1
   64c34:	mov    r11,r14
   64c37:	mov    r14,r13
   64c3a:	mov    r13,r11
   64c3d:	jmp    64cba <sqlite3VdbeExec+0x1581a>
   64c3f:	mov    QWORD PTR [rsp+0x240],rbp
   64c47:	mov    rbp,QWORD PTR [r8]
   64c4a:	mov    rax,QWORD PTR [rbp+0x8]
   64c4e:	mov    QWORD PTR [r8],rax
   64c51:	mov    QWORD PTR [rbp+0x10],r13
   64c55:	mov    rax,r8
   64c58:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   64c63:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   64c6e:	mov    QWORD PTR [rsp+0x190],rdi
   64c76:	mov    rdi,rax
   64c79:	mov    rsi,r14
   64c7c:	call   64c81 <sqlite3VdbeExec+0x157e1>
   64c81:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   64c8c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   64c97:	mov    QWORD PTR [rbp+0x8],rax
   64c9b:	add    r14d,0x1
   64c9f:	mov    rdi,QWORD PTR [rsp+0x190]
   64ca7:	mov    r13,rbp
   64caa:	mov    rbp,QWORD PTR [rsp+0x240]
   64cb2:	lea    r8,[rsp+0x1f8]
   64cba:	cmp    QWORD PTR [r8],0x0
   64cbe:	jne    64c3f <sqlite3VdbeExec+0x1579f>
   64cc4:	mov    rax,r13
   64cc7:	mov    QWORD PTR [rbp+0x10],rax
   64ccb:	mov    QWORD PTR [r12+0x10],0x0
   64cd4:	mov    QWORD PTR [r12+0x18],0x0
   64cdd:	movzx  eax,WORD PTR [r12+0x32]
   64ce3:	or     eax,0x1
   64ce6:	mov    WORD PTR [r12+0x32],ax
   64cec:	mov    ebp,DWORD PTR [rsp+0x41c]
   64cf3:	mov    DWORD PTR [r12+0x34],ebp
   64cf8:	mov    rax,QWORD PTR [r12+0x28]
   64cfd:	mov    r14,QWORD PTR [rsp+0x200]
   64d05:	mov    rcx,rax
   64d08:	jmp    64d39 <sqlite3VdbeExec+0x15899>
   64d0a:	mov    QWORD PTR [rsp+0x200],r14
   64d12:	mov    r14,QWORD PTR [rsp+0x200]
   64d1a:	cmp    r14,QWORD PTR [rax]
   64d1d:	jle    64d2a <sqlite3VdbeExec+0x1588a>
   64d1f:	mov    rax,QWORD PTR [rax+0x8]
   64d23:	test   rax,rax
   64d26:	jne    64d0a <sqlite3VdbeExec+0x1586a>
   64d28:	jmp    64d35 <sqlite3VdbeExec+0x15895>
   64d2a:	cmp    r14,QWORD PTR [rax]
   64d2d:	jge    64d56 <sqlite3VdbeExec+0x158b6>
   64d2f:	mov    rax,QWORD PTR [rax+0x10]
   64d33:	jmp    64d23 <sqlite3VdbeExec+0x15883>
   64d35:	mov    rcx,QWORD PTR [rcx+0x8]
   64d39:	test   rcx,rcx
   64d3c:	jne    64d50 <sqlite3VdbeExec+0x158b0>
   64d3e:	mov    r13,QWORD PTR [rsp+0x210]
   64d46:	mov    r14,QWORD PTR [rsp+0x1e8]
   64d4e:	jmp    64d6b <sqlite3VdbeExec+0x158cb>
   64d50:	mov    rax,QWORD PTR [rcx+0x10]
   64d54:	jmp    64d23 <sqlite3VdbeExec+0x15883>
   64d56:	mov    r12,QWORD PTR [rsp+0x1a8]
   64d5e:	mov    rbp,QWORD PTR [rsp+0x1c8]
   64d66:	jmp    52730 <sqlite3VdbeExec+0x3290>
   64d6b:	test   ebp,ebp
   64d6d:	jl     64e42 <sqlite3VdbeExec+0x159a2>
   64d73:	mov    rbp,QWORD PTR [r13+0x8]
   64d77:	mov    r12,QWORD PTR [rbx+r14*1]
   64d7b:	cmp    WORD PTR [rbp+0x30],0x0
   64d80:	jne    64df4 <sqlite3VdbeExec+0x15954>
   64d82:	mov    rax,QWORD PTR [rbp+0x8]
   64d86:	mov    ecx,0x3f8
   64d8b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   64d96:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   64da1:	mov    QWORD PTR [rsp+0x190],rdi
   64da9:	mov    rdi,rax
   64dac:	mov    rsi,rcx
   64daf:	call   64db4 <sqlite3VdbeExec+0x15914>
   64db4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   64dbf:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   64dca:	mov    rdi,QWORD PTR [rsp+0x190]
   64dd2:	test   rax,rax
   64dd5:	jne    64ddb <sqlite3VdbeExec+0x1593b>
   64dd7:	xor    eax,eax
   64dd9:	jmp    64e0b <sqlite3VdbeExec+0x1596b>
   64ddb:	mov    rcx,QWORD PTR [rbp+0x0]
   64ddf:	mov    QWORD PTR [rax],rcx
   64de2:	mov    QWORD PTR [rbp+0x0],rax
   64de6:	add    rax,0x8
   64dea:	mov    QWORD PTR [rbp+0x20],rax
   64dee:	mov    WORD PTR [rbp+0x30],0x2a
   64df4:	movzx  eax,WORD PTR [rbp+0x30]
   64df8:	sub    eax,0x1
   64dfb:	mov    WORD PTR [rbp+0x30],ax
   64dff:	mov    rax,QWORD PTR [rbp+0x20]
   64e03:	lea    rcx,[rax+0x18]
   64e07:	mov    QWORD PTR [rbp+0x20],rcx
   64e0b:	test   rax,rax
   64e0e:	je     64e42 <sqlite3VdbeExec+0x159a2>
   64e10:	mov    QWORD PTR [rax],r12
   64e13:	mov    QWORD PTR [rax+0x8],0x0
   64e1b:	mov    rcx,QWORD PTR [rbp+0x18]
   64e1f:	test   rcx,rcx
   64e22:	je     64e3a <sqlite3VdbeExec+0x1599a>
   64e24:	cmp    r12,QWORD PTR [rcx]
   64e27:	jg     64e34 <sqlite3VdbeExec+0x15994>
   64e29:	movzx  edx,WORD PTR [rbp+0x32]
   64e2d:	and    edx,0xfffffffe
   64e30:	mov    WORD PTR [rbp+0x32],dx
   64e34:	mov    QWORD PTR [rcx+0x8],rax
   64e38:	jmp    64e3e <sqlite3VdbeExec+0x1599e>
   64e3a:	mov    QWORD PTR [rbp+0x10],rax
   64e3e:	mov    QWORD PTR [rbp+0x18],rax
   64e42:	mov    r14,QWORD PTR [rsp+0x1a8]
   64e4a:	mov    DWORD PTR [rsp+0x3fc],r15d
   64e52:	mov    rbp,QWORD PTR [rsp+0x1c8]
   64e5a:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   64e5f:	mov    QWORD PTR [rsp+0x1a8],r14
   64e67:	mov    r15d,DWORD PTR [rsp+0x3fc]
   64e6f:	mov    QWORD PTR [rsp+0x1c8],rbp
   64e77:	mov    QWORD PTR [rsp+0x1b0],r12
   64e7f:	mov    rbp,QWORD PTR [rsp+0x1c8]
   64e87:	mov    r12,QWORD PTR [rbp+0x10]
   64e8b:	movsxd rax,DWORD PTR [rbp+0xc]
   64e8f:	imul   rax,rax,0x38
   64e93:	lea    r13,[rbx+rax*1]
   64e97:	cmp    WORD PTR [rbp+0x2],0x0
   64e9c:	jne    64ea8 <sqlite3VdbeExec+0x15a08>
   64e9e:	mov    r14,QWORD PTR [rsp+0x1a8]
   64ea6:	jmp    64ee9 <sqlite3VdbeExec+0x15a49>
   64ea8:	mov    rax,QWORD PTR [r12+0x20]
   64ead:	mov    rcx,QWORD PTR [rdi+0x108]
   64eb4:	jmp    64ec0 <sqlite3VdbeExec+0x15a20>
   64eb6:	cmp    rax,QWORD PTR [rcx+0x30]
   64eba:	je     64ec5 <sqlite3VdbeExec+0x15a25>
   64ebc:	mov    rcx,QWORD PTR [rcx+0x8]
   64ec0:	test   rcx,rcx
   64ec3:	jne    64eb6 <sqlite3VdbeExec+0x15a16>
   64ec5:	test   rcx,rcx
   64ec8:	jne    64ed4 <sqlite3VdbeExec+0x15a34>
   64eca:	mov    r14,QWORD PTR [rsp+0x1a8]
   64ed2:	jmp    64ee9 <sqlite3VdbeExec+0x15a49>
   64ed4:	mov    r14,QWORD PTR [rsp+0x1a8]
   64edc:	mov    DWORD PTR [rsp+0x3fc],r15d
   64ee4:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   64ee9:	mov    eax,DWORD PTR [rdi+0x118]
   64eef:	cmp    eax,DWORD PTR [r14+0xb0]
   64ef6:	jl     64f3e <sqlite3VdbeExec+0x15a9e>
   64ef8:	mov    ebx,0x1
   64efd:	lea    rax,[rip+0x0]        # 64f04 <sqlite3VdbeExec+0x15a64>
   64f04:	mov    QWORD PTR [rsp+0x190],rdi
   64f0c:	mov    rsi,rax
   64f0f:	xor    eax,eax
   64f11:	call   64f16 <sqlite3VdbeExec+0x15a76>
   64f16:	mov    rdi,QWORD PTR [rsp+0x190]
   64f1e:	mov    QWORD PTR [rsp+0x1c8],rbp
   64f26:	mov    rbp,rbx
   64f29:	mov    r13,QWORD PTR [rsp+0x1b0]
   64f31:	mov    rbx,QWORD PTR [rsp+0x1d8]
   64f39:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   64f3e:	movzx  eax,WORD PTR [r13+0x14]
   64f43:	and    eax,0x10
   64f46:	test   eax,eax
   64f48:	jne    65201 <sqlite3VdbeExec+0x15d61>
   64f4e:	mov    eax,DWORD PTR [r12+0xc]
   64f53:	mov    ebx,eax
   64f55:	add    ebx,DWORD PTR [r12+0x10]
   64f5a:	cmp    DWORD PTR [r12+0x10],0x0
   64f60:	jne    64f65 <sqlite3VdbeExec+0x15ac5>
   64f62:	add    ebx,0x1
   64f65:	movsxd rax,ebx
   64f68:	imul   rax,rax,0x38
   64f6c:	add    rax,0x70
   64f70:	movsxd rcx,DWORD PTR [r12+0x10]
   64f75:	shl    rcx,0x3
   64f79:	add    rax,rcx
   64f7c:	movsxd rcx,DWORD PTR [r12+0x8]
   64f81:	add    rcx,0x7
   64f85:	mov    rdx,rcx
   64f88:	sar    rdx,0x3f
   64f8c:	and    rdx,0x7
   64f90:	add    rcx,rdx
   64f93:	sar    rcx,0x3
   64f97:	mov    DWORD PTR [rsp+0x41c],ebx
   64f9e:	lea    rbx,[rax+rcx*1]
   64fa2:	test   r14,r14
   64fa5:	je     64ffb <sqlite3VdbeExec+0x15b5b>
   64fa7:	mov    QWORD PTR [rsp+0x1e8],r13
   64faf:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   64fba:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   64fc5:	mov    QWORD PTR [rsp+0x190],rdi
   64fcd:	mov    rdi,r14
   64fd0:	mov    rsi,rbx
   64fd3:	call   64fd8 <sqlite3VdbeExec+0x15b38>
   64fd8:	mov    r13,rax
   64fdb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   64fe6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   64ff1:	mov    rdi,QWORD PTR [rsp+0x190]
   64ff9:	jmp    6504a <sqlite3VdbeExec+0x15baa>
   64ffb:	mov    QWORD PTR [rsp+0x1e8],r13
   65003:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6500e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   65019:	mov    QWORD PTR [rsp+0x190],rdi
   65021:	mov    rdi,rbx
   65024:	call   65029 <sqlite3VdbeExec+0x15b89>
   65029:	mov    r13,rax
   6502c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   65037:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65042:	mov    rdi,QWORD PTR [rsp+0x190]
   6504a:	test   r13,r13
   6504d:	je     6509b <sqlite3VdbeExec+0x15bfb>
   6504f:	xor    eax,eax
   65051:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6505c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   65067:	mov    QWORD PTR [rsp+0x190],rdi
   6506f:	mov    rdi,r13
   65072:	mov    rsi,rax
   65075:	mov    rdx,rbx
   65078:	call   6507d <sqlite3VdbeExec+0x15bdd>
   6507d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   65088:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65093:	mov    rdi,QWORD PTR [rsp+0x190]
   6509b:	test   r13,r13
   6509e:	jne    650b8 <sqlite3VdbeExec+0x15c18>
   650a0:	mov    r13,QWORD PTR [rsp+0x1d0]
   650a8:	mov    rbx,rbp
   650ab:	mov    rbp,QWORD PTR [rsp+0x1d8]
   650b3:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   650b8:	mov    DWORD PTR [rsp+0x3fc],r15d
   650c0:	mov    r15,QWORD PTR [rsp+0x1e8]
   650c8:	movzx  eax,WORD PTR [r15+0x14]
   650cd:	and    eax,0x9000
   650d2:	test   eax,eax
   650d4:	jne    650dd <sqlite3VdbeExec+0x15c3d>
   650d6:	cmp    DWORD PTR [r15+0x20],0x0
   650db:	je     65121 <sqlite3VdbeExec+0x15c81>
   650dd:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   650e8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   650f3:	mov    QWORD PTR [rsp+0x190],rdi
   650fb:	mov    rdi,r15
   650fe:	call   65103 <sqlite3VdbeExec+0x15c63>
   65103:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6510e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65119:	mov    rdi,QWORD PTR [rsp+0x190]
   65121:	mov    WORD PTR [r15+0x14],0x1010
   65128:	mov    QWORD PTR [r15+0x8],r13
   6512c:	mov    DWORD PTR [r15+0x10],ebx
   65130:	lea    rax,[rip+0x0]        # 65137 <sqlite3VdbeExec+0x15c97>
   65137:	mov    QWORD PTR [r15+0x30],rax
   6513b:	mov    QWORD PTR [r13+0x0],rdi
   6513f:	mov    ebx,DWORD PTR [rsp+0x41c]
   65146:	mov    DWORD PTR [r13+0x58],ebx
   6514a:	mov    eax,DWORD PTR [r12+0x10]
   6514f:	mov    DWORD PTR [r13+0x5c],eax
   65153:	mov    rbx,QWORD PTR [rsp+0x1d0]
   6515b:	mov    rax,rbp
   6515e:	sub    rax,rbx
   65161:	movabs rdx,0x2aaaaaaaaaaaaaab
   6516b:	imul   rdx
   6516e:	sar    rdx,0x2
   65172:	mov    rax,rdx
   65175:	shr    rax,0x3f
   65179:	add    rdx,rax
   6517c:	mov    rax,rdx
   6517f:	mov    DWORD PTR [r13+0x4c],eax
   65183:	mov    rax,QWORD PTR [rdi+0x68]
   65187:	mov    QWORD PTR [r13+0x18],rax
   6518b:	mov    eax,DWORD PTR [rdi+0x24]
   6518e:	mov    DWORD PTR [r13+0x54],eax
   65192:	mov    rax,QWORD PTR [rdi+0x78]
   65196:	mov    QWORD PTR [r13+0x20],rax
   6519a:	mov    eax,DWORD PTR [rdi+0x28]
   6519d:	mov    DWORD PTR [r13+0x48],eax
   651a1:	mov    rax,QWORD PTR [rdi+0x88]
   651a8:	mov    QWORD PTR [r13+0x10],rax
   651ac:	mov    eax,DWORD PTR [rdi+0x90]
   651b2:	mov    DWORD PTR [r13+0x50],eax
   651b6:	mov    rax,QWORD PTR [r12+0x20]
   651bb:	mov    QWORD PTR [r13+0x30],rax
   651bf:	movsxd rax,DWORD PTR [r13+0x58]
   651c3:	imul   rax,rax,0x38
   651c7:	lea    rax,[r13+rax*1+0x70]
   651cc:	lea    rcx,[r13+0x70]
   651d0:	jmp    651e0 <sqlite3VdbeExec+0x15d40>
   651d2:	mov    WORD PTR [rcx+0x14],0x0
   651d8:	mov    QWORD PTR [rcx+0x18],r14
   651dc:	add    rcx,0x38
   651e0:	cmp    rcx,rax
   651e3:	jne    651d2 <sqlite3VdbeExec+0x15d32>
   651e5:	mov    r15d,DWORD PTR [rsp+0x3fc]
   651ed:	mov    ebp,DWORD PTR [rsp+0x410]
   651f4:	mov    rbx,r13
   651f7:	mov    r13d,DWORD PTR [rsp+0x414]
   651ff:	jmp    65214 <sqlite3VdbeExec+0x15d74>
   65201:	mov    rbx,QWORD PTR [r13+0x8]
   65205:	mov    ebp,DWORD PTR [rsp+0x410]
   6520c:	mov    r13d,DWORD PTR [rsp+0x414]
   65214:	mov    eax,DWORD PTR [rdi+0x118]
   6521a:	add    eax,0x1
   6521d:	mov    DWORD PTR [rdi+0x118],eax
   65223:	mov    rax,QWORD PTR [rdi+0x108]
   6522a:	mov    QWORD PTR [rbx+0x8],rax
   6522e:	mov    rax,QWORD PTR [r14+0x38]
   65232:	mov    QWORD PTR [rbx+0x38],rax
   65236:	mov    rax,QWORD PTR [rdi+0x38]
   6523a:	mov    QWORD PTR [rbx+0x60],rax
   6523e:	mov    rax,QWORD PTR [rdi]
   65241:	mov    rax,QWORD PTR [rax+0x78]
   65245:	mov    QWORD PTR [rbx+0x68],rax
   65249:	mov    rax,QWORD PTR [rdi+0x128]
   65250:	mov    QWORD PTR [rbx+0x40],rax
   65254:	mov    QWORD PTR [rdi+0x128],0x0
   6525f:	mov    QWORD PTR [rdi+0x38],0x0
   65267:	mov    QWORD PTR [rdi+0x108],rbx
   6526e:	mov    DWORD PTR [rsp+0x410],ebp
   65275:	lea    rbp,[rbx+0x70]
   65279:	mov    QWORD PTR [rdi+0x68],rbp
   6527d:	mov    eax,DWORD PTR [rbx+0x58]
   65280:	mov    DWORD PTR [rdi+0x24],eax
   65283:	mov    eax,DWORD PTR [rbx+0x5c]
   65286:	movzx  eax,ax
   65289:	mov    DWORD PTR [rdi+0x28],eax
   6528c:	movsxd rax,DWORD PTR [rdi+0x24]
   65290:	imul   rax,rax,0x38
   65294:	add    rax,rbp
   65297:	mov    QWORD PTR [rdi+0x78],rax
   6529b:	mov    rax,QWORD PTR [rdi+0x78]
   6529f:	movsxd rcx,DWORD PTR [r12+0x10]
   652a4:	lea    rax,[rax+rcx*8]
   652a8:	mov    QWORD PTR [rbx+0x28],rax
   652ac:	mov    rax,QWORD PTR [rbx+0x28]
   652b0:	xor    ecx,ecx
   652b2:	mov    edx,DWORD PTR [r12+0x8]
   652b7:	add    edx,0x7
   652ba:	mov    esi,edx
   652bc:	sar    esi,0x1f
   652bf:	and    esi,0x7
   652c2:	add    edx,esi
   652c4:	sar    edx,0x3
   652c7:	movsxd rdx,edx
   652ca:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   652d5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   652e0:	mov    QWORD PTR [rsp+0x190],rdi
   652e8:	mov    rdi,rax
   652eb:	mov    rsi,rcx
   652ee:	call   652f3 <sqlite3VdbeExec+0x15e53>
   652f3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   652fe:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65309:	mov    rbx,QWORD PTR [r12]
   6530d:	mov    rdi,QWORD PTR [rsp+0x190]
   65315:	mov    QWORD PTR [rdi+0x88],rbx
   6531c:	mov    eax,DWORD PTR [r12+0x8]
   65321:	mov    DWORD PTR [rdi+0x90],eax
   65327:	lea    r12,[rbx-0x18]
   6532b:	mov    QWORD PTR [rsp+0x1c8],r12
   65333:	mov    r12,r13
   65336:	mov    r13,rbx
   65339:	mov    ebx,DWORD PTR [rsp+0x410]
   65340:	mov    QWORD PTR [rsp+0x1e0],rbp
   65348:	jmp    4f836 <sqlite3VdbeExec+0x396>
   6534d:	mov    r15d,DWORD PTR [rsp+0x3fc]
   65355:	mov    r13,QWORD PTR [rsp+0x1d0]
   6535d:	mov    QWORD PTR [rsp+0x1b0],r12
   65365:	mov    r12d,DWORD PTR [rsp+0x414]
   6536d:	mov    rax,QWORD PTR [rdi+0x68]
   65371:	movsxd rcx,DWORD PTR [rbp+0x8]
   65375:	imul   rcx,rcx,0x38
   65379:	lea    rdx,[rax+rcx*1]
   6537d:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   65382:	and    eax,0x9000
   65387:	test   eax,eax
   65389:	je     653d4 <sqlite3VdbeExec+0x15f34>
   6538b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   65396:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   653a1:	mov    QWORD PTR [rsp+0x190],rdi
   653a9:	mov    rdi,rdx
   653ac:	call   653b1 <sqlite3VdbeExec+0x15f11>
   653b1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   653bc:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   653c7:	mov    rdi,QWORD PTR [rsp+0x190]
   653cf:	mov    rdx,rax
   653d2:	jmp    653da <sqlite3VdbeExec+0x15f3a>
   653d4:	mov    WORD PTR [rdx+0x14],0x4
   653da:	mov    rax,QWORD PTR [rdi+0x108]
   653e1:	mov    rcx,QWORD PTR [rax+0x18]
   653e5:	mov    esi,DWORD PTR [rbp+0x4]
   653e8:	mov    r8,QWORD PTR [rax+0x10]
   653ec:	movsxd rax,DWORD PTR [rax+0x4c]
   653f0:	imul   rax,rax,0x18
   653f4:	add    esi,DWORD PTR [r8+rax*1+0x4]
   653f9:	movsxd rax,esi
   653fc:	imul   rax,rax,0x38
   65400:	add    rcx,rax
   65403:	mov    eax,0x4000
   65408:	movzx  esi,WORD PTR [rdx+0x14]
   6540c:	and    esi,0x9000
   65412:	test   esi,esi
   65414:	je     65462 <sqlite3VdbeExec+0x15fc2>
   65416:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   65421:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6542c:	mov    QWORD PTR [rsp+0x190],rdi
   65434:	mov    rdi,rdx
   65437:	mov    rsi,rcx
   6543a:	mov    rdx,rax
   6543d:	call   65442 <sqlite3VdbeExec+0x15fa2>
   65442:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6544d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65458:	mov    rdi,QWORD PTR [rsp+0x190]
   65460:	jmp    6549f <sqlite3VdbeExec+0x15fff>
   65462:	mov    rax,QWORD PTR [rcx]
   65465:	mov    QWORD PTR [rdx],rax
   65468:	mov    rax,QWORD PTR [rcx+0x8]
   6546c:	mov    QWORD PTR [rdx+0x8],rax
   65470:	mov    rax,QWORD PTR [rcx+0x10]
   65474:	mov    QWORD PTR [rdx+0x10],rax
   65478:	movzx  eax,WORD PTR [rcx+0x14]
   6547c:	and    eax,0x2000
   65481:	test   eax,eax
   65483:	jne    6549f <sqlite3VdbeExec+0x15fff>
   65485:	movzx  eax,WORD PTR [rdx+0x14]
   65489:	and    eax,0xffff8fff
   6548e:	mov    WORD PTR [rdx+0x14],ax
   65492:	movzx  eax,WORD PTR [rdx+0x14]
   65496:	or     eax,0x4000
   6549b:	mov    WORD PTR [rdx+0x14],ax
   6549f:	mov    DWORD PTR [rsp+0x3fc],r15d
   654a7:	mov    QWORD PTR [rsp+0x1d0],r13
   654af:	mov    DWORD PTR [rsp+0x414],r12d
   654b7:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   654bc:	mov    r15d,DWORD PTR [rsp+0x3fc]
   654c4:	mov    r13,QWORD PTR [rsp+0x1d0]
   654cc:	mov    QWORD PTR [rsp+0x1b0],r12
   654d4:	mov    r12d,DWORD PTR [rsp+0x414]
   654dc:	cmp    DWORD PTR [rbp+0x4],0x0
   654e0:	je     654f9 <sqlite3VdbeExec+0x16059>
   654e2:	mov    rax,QWORD PTR [r14+0x2f0]
   654e9:	movsxd rcx,DWORD PTR [rbp+0x8]
   654ed:	add    rax,rcx
   654f0:	mov    QWORD PTR [r14+0x2f0],rax
   654f7:	jmp    6552e <sqlite3VdbeExec+0x1608e>
   654f9:	mov    rax,QWORD PTR [r14+0x30]
   654fd:	and    rax,0x80000
   65503:	test   rax,rax
   65506:	je     6551f <sqlite3VdbeExec+0x1607f>
   65508:	mov    rax,QWORD PTR [r14+0x2f8]
   6550f:	movsxd rcx,DWORD PTR [rbp+0x8]
   65513:	add    rax,rcx
   65516:	mov    QWORD PTR [r14+0x2f8],rax
   6551d:	jmp    6552e <sqlite3VdbeExec+0x1608e>
   6551f:	mov    rax,QWORD PTR [rdi+0x50]
   65523:	movsxd rcx,DWORD PTR [rbp+0x8]
   65527:	add    rax,rcx
   6552a:	mov    QWORD PTR [rdi+0x50],rax
   6552e:	mov    DWORD PTR [rsp+0x3fc],r15d
   65536:	mov    QWORD PTR [rsp+0x1d0],r13
   6553e:	mov    DWORD PTR [rsp+0x414],r12d
   65546:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6554b:	mov    r15d,DWORD PTR [rsp+0x3fc]
   65553:	mov    r13,QWORD PTR [rsp+0x1d0]
   6555b:	mov    QWORD PTR [rsp+0x1b0],r12
   65563:	mov    r12d,DWORD PTR [rsp+0x414]
   6556b:	cmp    DWORD PTR [rbp+0x4],0x0
   6556f:	je     6559d <sqlite3VdbeExec+0x160fd>
   65571:	cmp    QWORD PTR [r14+0x2f0],0x0
   65579:	jne    655c6 <sqlite3VdbeExec+0x16126>
   6557b:	cmp    QWORD PTR [r14+0x2f8],0x0
   65583:	jne    655c6 <sqlite3VdbeExec+0x16126>
   65585:	mov    QWORD PTR [rsp+0x1d0],r13
   6558d:	mov    DWORD PTR [rsp+0x414],r12d
   65595:	mov    r12,r14
   65598:	jmp    52730 <sqlite3VdbeExec+0x3290>
   6559d:	cmp    QWORD PTR [rdi+0x50],0x0
   655a2:	jne    655c6 <sqlite3VdbeExec+0x16126>
   655a4:	cmp    QWORD PTR [r14+0x2f8],0x0
   655ac:	jne    655c6 <sqlite3VdbeExec+0x16126>
   655ae:	mov    QWORD PTR [rsp+0x1d0],r13
   655b6:	mov    DWORD PTR [rsp+0x414],r12d
   655be:	mov    r12,r14
   655c1:	jmp    52730 <sqlite3VdbeExec+0x3290>
   655c6:	mov    DWORD PTR [rsp+0x3fc],r15d
   655ce:	mov    QWORD PTR [rsp+0x1d0],r13
   655d6:	mov    DWORD PTR [rsp+0x414],r12d
   655de:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   655e3:	mov    r15d,DWORD PTR [rsp+0x3fc]
   655eb:	mov    r13,QWORD PTR [rsp+0x1d0]
   655f3:	mov    QWORD PTR [rsp+0x1b0],r12
   655fb:	mov    r12d,DWORD PTR [rsp+0x414]
   65603:	cmp    QWORD PTR [rdi+0x108],0x0
   6560b:	je     6563b <sqlite3VdbeExec+0x1619b>
   6560d:	mov    rax,QWORD PTR [rdi+0x108]
   65614:	jmp    6561a <sqlite3VdbeExec+0x1617a>
   65616:	mov    rax,QWORD PTR [rax+0x8]
   6561a:	cmp    QWORD PTR [rax+0x8],0x0
   6561f:	jne    65616 <sqlite3VdbeExec+0x16176>
   65621:	mov    rax,QWORD PTR [rax+0x18]
   65625:	movsxd rcx,DWORD PTR [rbp+0x4]
   65629:	imul   rcx,rcx,0x38
   6562d:	mov    DWORD PTR [rsp+0x414],r12d
   65635:	lea    r12,[rax+rcx*1]
   65639:	jmp    6564f <sqlite3VdbeExec+0x161af>
   6563b:	mov    DWORD PTR [rsp+0x414],r12d
   65643:	movsxd rax,DWORD PTR [rbp+0x4]
   65647:	imul   rax,rax,0x38
   6564b:	lea    r12,[rbx+rax*1]
   6564f:	movzx  eax,WORD PTR [r12+0x14]
   65655:	mov    ecx,eax
   65657:	and    ecx,0x24
   6565a:	test   ecx,ecx
   6565c:	je     65667 <sqlite3VdbeExec+0x161c7>
   6565e:	mov    rax,QWORD PTR [r12]
   65662:	jmp    65716 <sqlite3VdbeExec+0x16276>
   65667:	mov    ecx,eax
   65669:	and    ecx,0x8
   6566c:	test   ecx,ecx
   6566e:	je     656bf <sqlite3VdbeExec+0x1621f>
   65670:	movsd  xmm2,QWORD PTR [r12]
   65676:	movabs r11,0xc3dfffffffffffff
   65680:	movq   xmm3,r11
   65685:	ucomisd xmm3,xmm2
   65689:	jbe    65697 <sqlite3VdbeExec+0x161f7>
   6568b:	movabs rax,0x8000000000000000
   65695:	jmp    656bd <sqlite3VdbeExec+0x1621d>
   65697:	movabs r11,0x43dfffffffffffff
   656a1:	movq   xmm3,r11
   656a6:	ucomisd xmm2,xmm3
   656aa:	jbe    656b8 <sqlite3VdbeExec+0x16218>
   656ac:	movabs rax,0x7fffffffffffffff
   656b6:	jmp    656bd <sqlite3VdbeExec+0x1621d>
   656b8:	cvttsd2si rax,xmm2
   656bd:	jmp    65716 <sqlite3VdbeExec+0x16276>
   656bf:	and    eax,0x12
   656c2:	test   eax,eax
   656c4:	je     65714 <sqlite3VdbeExec+0x16274>
   656c6:	cmp    QWORD PTR [r12+0x8],0x0
   656cc:	je     65714 <sqlite3VdbeExec+0x16274>
   656ce:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   656d9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   656e4:	mov    QWORD PTR [rsp+0x190],rdi
   656ec:	mov    rdi,r12
   656ef:	call   656f4 <sqlite3VdbeExec+0x16254>
   656f4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   656ff:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6570a:	mov    rdi,QWORD PTR [rsp+0x190]
   65712:	jmp    65716 <sqlite3VdbeExec+0x16276>
   65714:	xor    eax,eax
   65716:	mov    QWORD PTR [r12],rax
   6571a:	movzx  eax,WORD PTR [r12+0x14]
   65720:	and    eax,0xfffff240
   65725:	or     eax,0x4
   65728:	mov    WORD PTR [r12+0x14],ax
   6572e:	movsxd rax,DWORD PTR [rbp+0x8]
   65732:	imul   rax,rax,0x38
   65736:	mov    QWORD PTR [rsp+0x1e8],r12
   6573e:	lea    r12,[rbx+rax*1]
   65742:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   65747:	mov    ecx,eax
   65749:	and    ecx,0x24
   6574c:	test   ecx,ecx
   6574e:	je     65759 <sqlite3VdbeExec+0x162b9>
   65750:	mov    rax,QWORD PTR [r12]
   65754:	jmp    65808 <sqlite3VdbeExec+0x16368>
   65759:	mov    ecx,eax
   6575b:	and    ecx,0x8
   6575e:	test   ecx,ecx
   65760:	je     657b1 <sqlite3VdbeExec+0x16311>
   65762:	movsd  xmm2,QWORD PTR [r12]
   65768:	movabs r11,0xc3dfffffffffffff
   65772:	movq   xmm3,r11
   65777:	ucomisd xmm3,xmm2
   6577b:	jbe    65789 <sqlite3VdbeExec+0x162e9>
   6577d:	movabs rax,0x8000000000000000
   65787:	jmp    657af <sqlite3VdbeExec+0x1630f>
   65789:	movabs r11,0x43dfffffffffffff
   65793:	movq   xmm3,r11
   65798:	ucomisd xmm2,xmm3
   6579c:	jbe    657aa <sqlite3VdbeExec+0x1630a>
   6579e:	movabs rax,0x7fffffffffffffff
   657a8:	jmp    657af <sqlite3VdbeExec+0x1630f>
   657aa:	cvttsd2si rax,xmm2
   657af:	jmp    65808 <sqlite3VdbeExec+0x16368>
   657b1:	and    eax,0x12
   657b4:	test   eax,eax
   657b6:	je     65806 <sqlite3VdbeExec+0x16366>
   657b8:	cmp    QWORD PTR [r12+0x8],0x0
   657be:	je     65806 <sqlite3VdbeExec+0x16366>
   657c0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   657cb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   657d6:	mov    QWORD PTR [rsp+0x190],rdi
   657de:	mov    rdi,r12
   657e1:	call   657e6 <sqlite3VdbeExec+0x16346>
   657e6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   657f1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   657fc:	mov    rdi,QWORD PTR [rsp+0x190]
   65804:	jmp    65808 <sqlite3VdbeExec+0x16368>
   65806:	xor    eax,eax
   65808:	mov    QWORD PTR [r12],rax
   6580c:	movzx  eax,WORD PTR [r12+0x14]
   65812:	and    eax,0xfffff240
   65817:	or     eax,0x4
   6581a:	mov    WORD PTR [r12+0x14],ax
   65820:	mov    QWORD PTR [rsp+0x1d0],r13
   65828:	mov    r13,QWORD PTR [rsp+0x1e8]
   65830:	mov    rax,QWORD PTR [r13+0x0]
   65834:	cmp    rax,QWORD PTR [r12]
   65838:	jge    65842 <sqlite3VdbeExec+0x163a2>
   6583a:	mov    rax,QWORD PTR [r12]
   6583e:	mov    QWORD PTR [r13+0x0],rax
   65842:	mov    DWORD PTR [rsp+0x3fc],r15d
   6584a:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6584f:	mov    r15d,DWORD PTR [rsp+0x3fc]
   65857:	mov    QWORD PTR [rsp+0x1b0],r12
   6585f:	movsxd rax,DWORD PTR [rbp+0x4]
   65863:	imul   rax,rax,0x38
   65867:	cmp    QWORD PTR [rbx+rax*1],0x0
   6586c:	jle    65885 <sqlite3VdbeExec+0x163e5>
   6586e:	mov    rcx,QWORD PTR [rbx+rax*1]
   65872:	movsxd rdx,DWORD PTR [rbp+0xc]
   65876:	sub    rcx,rdx
   65879:	mov    QWORD PTR [rbx+rax*1],rcx
   6587d:	mov    r12,r14
   65880:	jmp    52730 <sqlite3VdbeExec+0x3290>
   65885:	mov    DWORD PTR [rsp+0x3fc],r15d
   6588d:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   65892:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6589a:	mov    QWORD PTR [rsp+0x1b0],r12
   658a2:	movsxd rax,DWORD PTR [rbp+0x4]
   658a6:	imul   r12,rax,0x38
   658aa:	movsxd rax,DWORD PTR [rbp+0xc]
   658ae:	imul   r13,rax,0x38
   658b2:	mov    rax,QWORD PTR [rdi+0x68]
   658b6:	movsxd rcx,DWORD PTR [rbp+0x8]
   658ba:	imul   rcx,rcx,0x38
   658be:	lea    rdx,[rax+rcx*1]
   658c2:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   658c7:	and    eax,0x9000
   658cc:	test   eax,eax
   658ce:	je     65919 <sqlite3VdbeExec+0x16479>
   658d0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   658db:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   658e6:	mov    QWORD PTR [rsp+0x190],rdi
   658ee:	mov    rdi,rdx
   658f1:	call   658f6 <sqlite3VdbeExec+0x16456>
   658f6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   65901:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6590c:	mov    rdi,QWORD PTR [rsp+0x190]
   65914:	mov    rdx,rax
   65917:	jmp    6591f <sqlite3VdbeExec+0x1647f>
   65919:	mov    WORD PTR [rdx+0x14],0x4
   6591f:	mov    rax,QWORD PTR [rbx+r12*1]
   65923:	mov    QWORD PTR [rsp+0x1e8],rax
   6592b:	cmp    QWORD PTR [rsp+0x1e8],0x0
   65934:	jle    65969 <sqlite3VdbeExec+0x164c9>
   65936:	cmp    QWORD PTR [rbx+r13*1],0x0
   6593b:	jle    65943 <sqlite3VdbeExec+0x164a3>
   6593d:	mov    rax,QWORD PTR [rbx+r13*1]
   65941:	jmp    65945 <sqlite3VdbeExec+0x164a5>
   65943:	xor    eax,eax
   65945:	mov    rcx,QWORD PTR [rsp+0x1e8]
   6594d:	test   rax,rax
   65950:	jl     65972 <sqlite3VdbeExec+0x164d2>
   65952:	test   rcx,rcx
   65955:	jle    65990 <sqlite3VdbeExec+0x164f0>
   65957:	movabs rsi,0x7fffffffffffffff
   65961:	sub    rsi,rcx
   65964:	cmp    rsi,rax
   65967:	jge    65990 <sqlite3VdbeExec+0x164f0>
   65969:	mov    QWORD PTR [rdx],0xffffffffffffffff
   65970:	jmp    659ab <sqlite3VdbeExec+0x1650b>
   65972:	test   rcx,rcx
   65975:	jge    65990 <sqlite3VdbeExec+0x164f0>
   65977:	movabs rsi,0x7fffffffffffffff
   65981:	add    rcx,rsi
   65984:	neg    rcx
   65987:	lea    rsi,[rax+0x1]
   6598b:	cmp    rcx,rsi
   6598e:	jg     65969 <sqlite3VdbeExec+0x164c9>
   65990:	add    rax,QWORD PTR [rsp+0x1e8]
   65998:	mov    QWORD PTR [rsp+0x1e8],rax
   659a0:	mov    rax,QWORD PTR [rsp+0x1e8]
   659a8:	mov    QWORD PTR [rdx],rax
   659ab:	mov    DWORD PTR [rsp+0x3fc],r15d
   659b3:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   659b8:	mov    r15d,DWORD PTR [rsp+0x3fc]
   659c0:	mov    QWORD PTR [rsp+0x1b0],r12
   659c8:	movsxd rax,DWORD PTR [rbp+0x4]
   659cc:	imul   rax,rax,0x38
   659d0:	cmp    QWORD PTR [rbx+rax*1],0x0
   659d5:	je     659f2 <sqlite3VdbeExec+0x16552>
   659d7:	cmp    QWORD PTR [rbx+rax*1],0x0
   659dc:	jle    659ea <sqlite3VdbeExec+0x1654a>
   659de:	mov    rcx,QWORD PTR [rbx+rax*1]
   659e2:	sub    rcx,0x1
   659e6:	mov    QWORD PTR [rbx+rax*1],rcx
   659ea:	mov    r12,r14
   659ed:	jmp    52730 <sqlite3VdbeExec+0x3290>
   659f2:	mov    DWORD PTR [rsp+0x3fc],r15d
   659fa:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   659ff:	mov    r15d,DWORD PTR [rsp+0x3fc]
   65a07:	mov    QWORD PTR [rsp+0x1b0],r12
   65a0f:	movsxd rax,DWORD PTR [rbp+0x4]
   65a13:	imul   rax,rax,0x38
   65a17:	movabs rcx,0x8000000000000000
   65a21:	cmp    rcx,QWORD PTR [rbx+rax*1]
   65a25:	jge    65a33 <sqlite3VdbeExec+0x16593>
   65a27:	mov    rcx,QWORD PTR [rbx+rax*1]
   65a2b:	sub    rcx,0x1
   65a2f:	mov    QWORD PTR [rbx+rax*1],rcx
   65a33:	cmp    QWORD PTR [rbx+rax*1],0x0
   65a38:	jne    65a42 <sqlite3VdbeExec+0x165a2>
   65a3a:	mov    r12,r14
   65a3d:	jmp    52730 <sqlite3VdbeExec+0x3290>
   65a42:	mov    DWORD PTR [rsp+0x3fc],r15d
   65a4a:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   65a4f:	mov    r15d,DWORD PTR [rsp+0x3fc]
   65a57:	mov    QWORD PTR [rsp+0x1b0],r12
   65a5f:	movzx  eax,WORD PTR [rbp+0x2]
   65a63:	mov    r12d,eax
   65a66:	mov    rax,r12
   65a69:	shl    rax,0x3
   65a6d:	lea    r13,[rax+0x30]
   65a71:	lea    rax,[r13+0x38]
   65a75:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   65a80:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   65a8b:	mov    QWORD PTR [rsp+0x190],rdi
   65a93:	mov    rdi,r14
   65a96:	mov    rsi,rax
   65a99:	call   65a9e <sqlite3VdbeExec+0x165fe>
   65a9e:	mov    rcx,rax
   65aa1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   65aac:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65ab7:	mov    rdi,QWORD PTR [rsp+0x190]
   65abf:	test   rcx,rcx
   65ac2:	jne    65adc <sqlite3VdbeExec+0x1663c>
   65ac4:	mov    r13,QWORD PTR [rsp+0x1d0]
   65acc:	mov    rbx,rbp
   65acf:	mov    rbp,QWORD PTR [rsp+0x1d8]
   65ad7:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   65adc:	lea    rax,[rcx+r13*1]
   65ae0:	mov    QWORD PTR [rcx],rax
   65ae3:	mov    rax,QWORD PTR [rcx]
   65ae6:	mov    WORD PTR [rax+0x14],0x1
   65aec:	mov    QWORD PTR [rax+0x18],r14
   65af0:	mov    DWORD PTR [rax+0x20],0x0
   65af7:	mov    QWORD PTR [rcx+0x10],0x0
   65aff:	mov    rax,QWORD PTR [rbp+0x10]
   65b03:	mov    QWORD PTR [rcx+0x8],rax
   65b07:	mov    r13,QWORD PTR [rsp+0x1d0]
   65b0f:	mov    rax,rbp
   65b12:	sub    rax,r13
   65b15:	movabs rdx,0x2aaaaaaaaaaaaaab
   65b1f:	imul   rdx
   65b22:	sar    rdx,0x2
   65b26:	mov    rax,rdx
   65b29:	shr    rax,0x3f
   65b2d:	add    rdx,rax
   65b30:	mov    rax,rdx
   65b33:	mov    DWORD PTR [rcx+0x20],eax
   65b36:	mov    QWORD PTR [rcx+0x18],rdi
   65b3a:	mov    BYTE PTR [rcx+0x29],0x0
   65b3e:	mov    DWORD PTR [rcx+0x24],0x0
   65b45:	mov    BYTE PTR [rcx+0x28],r15b
   65b49:	mov    WORD PTR [rcx+0x2a],r12w
   65b4e:	mov    BYTE PTR [rbp+0x1],0xf0
   65b52:	mov    QWORD PTR [rbp+0x10],rcx
   65b56:	mov    BYTE PTR [rbp+0x0],0xa5
   65b5a:	mov    r12,QWORD PTR [rbp+0x10]
   65b5e:	movsxd rax,DWORD PTR [rbp+0xc]
   65b62:	imul   rax,rax,0x38
   65b66:	add    rax,rbx
   65b69:	cmp    rax,QWORD PTR [r12+0x10]
   65b6e:	je     65b9e <sqlite3VdbeExec+0x166fe>
   65b70:	mov    QWORD PTR [r12+0x10],rax
   65b75:	movzx  ecx,WORD PTR [r12+0x2a]
   65b7b:	sub    ecx,0x1
   65b7e:	jmp    65b9a <sqlite3VdbeExec+0x166fa>
   65b80:	mov    rdx,rcx
   65b83:	mov    esi,ecx
   65b85:	add    esi,DWORD PTR [rbp+0x8]
   65b88:	movsxd rsi,esi
   65b8b:	imul   rsi,rsi,0x38
   65b8f:	add    rsi,rbx
   65b92:	mov    QWORD PTR [r12+rdx*8+0x30],rsi
   65b97:	sub    ecx,0x1
   65b9a:	test   ecx,ecx
   65b9c:	jge    65b80 <sqlite3VdbeExec+0x166e0>
   65b9e:	mov    ecx,DWORD PTR [rax+0x10]
   65ba1:	add    ecx,0x1
   65ba4:	mov    DWORD PTR [rax+0x10],ecx
   65ba7:	cmp    DWORD PTR [rbp+0x4],0x0
   65bab:	je     65c0b <sqlite3VdbeExec+0x1676b>
   65bad:	mov    rax,QWORD PTR [r12+0x8]
   65bb2:	mov    rax,QWORD PTR [rax+0x30]
   65bb6:	movzx  ecx,WORD PTR [r12+0x2a]
   65bbc:	lea    rdx,[r12+0x30]
   65bc1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   65bcc:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   65bd7:	mov    QWORD PTR [rsp+0x190],rdi
   65bdf:	mov    rdi,r12
   65be2:	mov    rsi,rcx
   65be5:	mov    r10,rax
   65be8:	call   r10
   65beb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   65bf6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65c01:	mov    rdi,QWORD PTR [rsp+0x190]
   65c09:	jmp    65c67 <sqlite3VdbeExec+0x167c7>
   65c0b:	mov    rax,QWORD PTR [r12+0x8]
   65c10:	mov    rax,QWORD PTR [rax+0x18]
   65c14:	movzx  ecx,WORD PTR [r12+0x2a]
   65c1a:	lea    rdx,[r12+0x30]
   65c1f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   65c2a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   65c35:	mov    QWORD PTR [rsp+0x190],rdi
   65c3d:	mov    rdi,r12
   65c40:	mov    rsi,rcx
   65c43:	mov    r10,rax
   65c46:	call   r10
   65c49:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   65c54:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65c5f:	mov    rdi,QWORD PTR [rsp+0x190]
   65c67:	cmp    DWORD PTR [r12+0x24],0x0
   65c6d:	je     65ea7 <sqlite3VdbeExec+0x16a07>
   65c73:	cmp    DWORD PTR [r12+0x24],0x0
   65c79:	jle    65d72 <sqlite3VdbeExec+0x168d2>
   65c7f:	mov    rax,QWORD PTR [r12]
   65c83:	test   rax,rax
   65c86:	jne    65c8c <sqlite3VdbeExec+0x167ec>
   65c88:	xor    eax,eax
   65c8a:	jmp    65d05 <sqlite3VdbeExec+0x16865>
   65c8c:	movzx  ecx,WORD PTR [rax+0x14]
   65c90:	and    ecx,0x202
   65c96:	cmp    ecx,0x202
   65c9c:	jne    65caa <sqlite3VdbeExec+0x1680a>
   65c9e:	cmp    BYTE PTR [rax+0x16],0x1
   65ca2:	jne    65caa <sqlite3VdbeExec+0x1680a>
   65ca4:	mov    rax,QWORD PTR [rax+0x8]
   65ca8:	jmp    65d05 <sqlite3VdbeExec+0x16865>
   65caa:	movzx  ecx,WORD PTR [rax+0x14]
   65cae:	and    ecx,0x1
   65cb1:	test   ecx,ecx
   65cb3:	je     65cb9 <sqlite3VdbeExec+0x16819>
   65cb5:	xor    eax,eax
   65cb7:	jmp    65d05 <sqlite3VdbeExec+0x16865>
   65cb9:	mov    ecx,0x1
   65cbe:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   65cc9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   65cd4:	mov    QWORD PTR [rsp+0x190],rdi
   65cdc:	mov    rdi,rax
   65cdf:	mov    rsi,rcx
   65ce2:	call   65ce7 <sqlite3VdbeExec+0x16847>
   65ce7:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   65cf2:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65cfd:	mov    rdi,QWORD PTR [rsp+0x190]
   65d05:	mov    QWORD PTR [rsp+0x1d0],r13
   65d0d:	lea    r13,[rip+0x0]        # 65d14 <sqlite3VdbeExec+0x16874>
   65d14:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   65d1f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   65d2a:	mov    QWORD PTR [rsp+0x190],rdi
   65d32:	mov    rsi,r13
   65d35:	mov    rdx,rax
   65d38:	xor    eax,eax
   65d3a:	call   65d3f <sqlite3VdbeExec+0x1689f>
   65d3f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   65d4a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65d55:	mov    r13d,DWORD PTR [r12+0x24]
   65d5a:	mov    rdi,QWORD PTR [rsp+0x190]
   65d62:	mov    DWORD PTR [rsp+0x40c],r13d
   65d6a:	mov    r13,QWORD PTR [rsp+0x1d0]
   65d72:	cmp    BYTE PTR [r12+0x29],0x0
   65d78:	je     65df9 <sqlite3VdbeExec+0x16959>
   65d7a:	movsxd rax,DWORD PTR [rbp-0x14]
   65d7e:	test   eax,eax
   65d80:	je     65df3 <sqlite3VdbeExec+0x16953>
   65d82:	imul   rax,rax,0x38
   65d86:	lea    rcx,[rbx+rax*1]
   65d8a:	mov    edx,0x1
   65d8f:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   65d94:	and    eax,0x9000
   65d99:	test   eax,eax
   65d9b:	je     65de6 <sqlite3VdbeExec+0x16946>
   65d9d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   65da8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   65db3:	mov    QWORD PTR [rsp+0x190],rdi
   65dbb:	mov    rdi,rcx
   65dbe:	mov    rsi,rdx
   65dc1:	call   65dc6 <sqlite3VdbeExec+0x16926>
   65dc6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   65dd1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65ddc:	mov    rdi,QWORD PTR [rsp+0x190]
   65de4:	jmp    65df3 <sqlite3VdbeExec+0x16953>
   65de6:	mov    QWORD PTR [rcx],0x1
   65ded:	mov    WORD PTR [rcx+0x14],0x4
   65df3:	mov    BYTE PTR [r12+0x29],0x0
   65df9:	mov    rax,QWORD PTR [r12]
   65dfd:	movzx  ecx,WORD PTR [rax+0x14]
   65e01:	and    ecx,0x9000
   65e07:	test   ecx,ecx
   65e09:	jne    65e11 <sqlite3VdbeExec+0x16971>
   65e0b:	cmp    DWORD PTR [rax+0x20],0x0
   65e0f:	je     65e55 <sqlite3VdbeExec+0x169b5>
   65e11:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   65e1c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   65e27:	mov    QWORD PTR [rsp+0x190],rdi
   65e2f:	mov    rdi,rax
   65e32:	call   65e37 <sqlite3VdbeExec+0x16997>
   65e37:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   65e42:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65e4d:	mov    rdi,QWORD PTR [rsp+0x190]
   65e55:	mov    rax,QWORD PTR [r12]
   65e59:	mov    WORD PTR [rax+0x14],0x1
   65e5f:	mov    DWORD PTR [r12+0x24],0x0
   65e68:	mov    r12d,DWORD PTR [rsp+0x40c]
   65e70:	test   r12d,r12d
   65e73:	jne    65e7f <sqlite3VdbeExec+0x169df>
   65e75:	mov    DWORD PTR [rsp+0x40c],r12d
   65e7d:	jmp    65ea7 <sqlite3VdbeExec+0x16a07>
   65e7f:	mov    QWORD PTR [rsp+0x1d0],r13
   65e87:	mov    QWORD PTR [rsp+0x1c8],rbp
   65e8f:	mov    rbp,r12
   65e92:	mov    r13,QWORD PTR [rsp+0x1b0]
   65e9a:	mov    rbx,QWORD PTR [rsp+0x1d8]
   65ea2:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   65ea7:	mov    DWORD PTR [rsp+0x3fc],r15d
   65eaf:	mov    QWORD PTR [rsp+0x1d0],r13
   65eb7:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   65ebc:	mov    r15d,DWORD PTR [rsp+0x3fc]
   65ec4:	mov    r13,QWORD PTR [rsp+0x1d0]
   65ecc:	mov    QWORD PTR [rsp+0x1b0],r12
   65ed4:	movsxd rax,DWORD PTR [rbp+0x4]
   65ed8:	imul   rax,rax,0x38
   65edc:	lea    r12,[rbx+rax*1]
   65ee0:	cmp    DWORD PTR [rbp+0xc],0x0
   65ee4:	je     66056 <sqlite3VdbeExec+0x16bb6>
   65eea:	movsxd rax,DWORD PTR [rbp+0xc]
   65eee:	mov    QWORD PTR [rsp+0x1d0],r13
   65ef6:	imul   r13,rax,0x38
   65efa:	mov    DWORD PTR [rsp+0x3fc],r15d
   65f02:	lea    r15,[rbx+r13*1]
   65f06:	mov    QWORD PTR [rsp+0x1a8],r14
   65f0e:	mov    r14,QWORD PTR [rbp+0x10]
   65f12:	mov    QWORD PTR [rsp+0x1c8],rbp
   65f1a:	lea    rbp,[rsp+0x290]
   65f22:	mov    rax,rbp
   65f25:	xor    ecx,ecx
   65f27:	mov    edx,0x30
   65f2c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   65f37:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   65f42:	mov    QWORD PTR [rsp+0x190],rdi
   65f4a:	mov    rdi,rax
   65f4d:	mov    rsi,rcx
   65f50:	call   65f55 <sqlite3VdbeExec+0x16ab5>
   65f55:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   65f60:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65f6b:	movzx  eax,WORD PTR [rbx+r13*1+0x14]
   65f71:	and    eax,0x9000
   65f76:	mov    rdi,QWORD PTR [rsp+0x190]
   65f7e:	test   eax,eax
   65f80:	je     65fc0 <sqlite3VdbeExec+0x16b20>
   65f82:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   65f8d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   65f98:	mov    rdi,r15
   65f9b:	call   65fa0 <sqlite3VdbeExec+0x16b00>
   65fa0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   65fab:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   65fb6:	mov    rdi,QWORD PTR [rsp+0x190]
   65fbe:	jmp    65fc7 <sqlite3VdbeExec+0x16b27>
   65fc0:	mov    WORD PTR [r15+0x14],0x1
   65fc7:	mov    QWORD PTR [rbp+0x0],r15
   65fcb:	mov    QWORD PTR [rbp+0x10],r12
   65fcf:	mov    QWORD PTR [rbp+0x8],r14
   65fd3:	mov    rax,QWORD PTR [r12+0x18]
   65fd8:	movzx  eax,BYTE PTR [rax+0x64]
   65fdc:	mov    BYTE PTR [rbp+0x28],al
   65fdf:	mov    rax,QWORD PTR [r14+0x28]
   65fe3:	mov    rcx,rbp
   65fe6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   65ff1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   65ffc:	mov    QWORD PTR [rsp+0x190],rdi
   66004:	mov    rdi,rcx
   66007:	mov    r10,rax
   6600a:	call   r10
   6600d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66018:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66023:	mov    eax,DWORD PTR [rbp+0x24]
   66026:	mov    ebp,eax
   66028:	mov    r12,QWORD PTR [rsp+0x1c8]
   66030:	movsxd rax,DWORD PTR [r12+0xc]
   66035:	imul   rax,rax,0x38
   66039:	lea    r13,[rbx+rax*1]
   6603d:	mov    rdi,QWORD PTR [rsp+0x190]
   66045:	mov    r11,rbp
   66048:	mov    rbp,r12
   6604b:	mov    r12,r13
   6604e:	mov    r13,r11
   66051:	jmp    6623f <sqlite3VdbeExec+0x16d9f>
   66056:	mov    QWORD PTR [rsp+0x1a8],r14
   6605e:	mov    DWORD PTR [rsp+0x3fc],r15d
   66066:	mov    QWORD PTR [rsp+0x1d0],r13
   6606e:	mov    r13,QWORD PTR [rbp+0x10]
   66072:	lea    r14,[rsp+0x290]
   6607a:	lea    r15,[rsp+0x2f8]
   66082:	mov    rax,r14
   66085:	xor    ecx,ecx
   66087:	mov    edx,0x30
   6608c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66097:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   660a2:	mov    QWORD PTR [rsp+0x190],rdi
   660aa:	mov    rdi,rax
   660ad:	mov    rsi,rcx
   660b0:	call   660b5 <sqlite3VdbeExec+0x16c15>
   660b5:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   660c0:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   660cb:	mov    rax,r15
   660ce:	xor    ecx,ecx
   660d0:	mov    edx,0x38
   660d5:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   660e0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   660eb:	mov    rdi,rax
   660ee:	mov    rsi,rcx
   660f1:	call   660f6 <sqlite3VdbeExec+0x16c56>
   660f6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66101:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6610c:	mov    WORD PTR [rsp+0x30c],0x1
   66116:	mov    rax,QWORD PTR [r12+0x18]
   6611b:	mov    QWORD PTR [rsp+0x310],rax
   66123:	mov    rax,r15
   66126:	mov    QWORD PTR [rsp+0x290],rax
   6612e:	mov    QWORD PTR [rsp+0x2a0],r12
   66136:	mov    QWORD PTR [rsp+0x298],r13
   6613e:	mov    rax,QWORD PTR [rsp+0x310]
   66146:	movzx  eax,BYTE PTR [rax+0x64]
   6614a:	mov    BYTE PTR [rsp+0x2b8],al
   66151:	mov    rax,QWORD PTR [r13+0x20]
   66155:	mov    rcx,r14
   66158:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66163:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6616e:	mov    rdi,rcx
   66171:	mov    r10,rax
   66174:	call   r10
   66177:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66182:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6618d:	mov    rdi,QWORD PTR [rsp+0x190]
   66195:	cmp    DWORD PTR [r12+0x20],0x0
   6619b:	jle    661e6 <sqlite3VdbeExec+0x16d46>
   6619d:	mov    rax,QWORD PTR [r12+0x18]
   661a2:	mov    rcx,QWORD PTR [r12+0x28]
   661a7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   661b2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   661bd:	mov    rdi,rax
   661c0:	mov    rsi,rcx
   661c3:	call   661c8 <sqlite3VdbeExec+0x16d28>
   661c8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   661d3:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   661de:	mov    rdi,QWORD PTR [rsp+0x190]
   661e6:	mov    rax,r15
   661e9:	mov    ecx,0x38
   661ee:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   661f9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66204:	mov    QWORD PTR [rsp+0x190],rdi
   6620c:	mov    rdi,r12
   6620f:	mov    rsi,rax
   66212:	mov    rdx,rcx
   66215:	call   6621a <sqlite3VdbeExec+0x16d7a>
   6621a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66225:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66230:	mov    eax,DWORD PTR [r14+0x24]
   66234:	mov    r13d,eax
   66237:	mov    rdi,QWORD PTR [rsp+0x190]
   6623f:	test   r13d,r13d
   66242:	je     66307 <sqlite3VdbeExec+0x16e67>
   66248:	lea    rbx,[rip+0x0]        # 6624f <sqlite3VdbeExec+0x16daf>
   6624f:	test   r12,r12
   66252:	jne    66260 <sqlite3VdbeExec+0x16dc0>
   66254:	xor    eax,eax
   66256:	mov    r14,QWORD PTR [rsp+0x1a8]
   6625e:	jmp    662ca <sqlite3VdbeExec+0x16e2a>
   66260:	movzx  eax,WORD PTR [r12+0x14]
   66266:	and    eax,0x202
   6626b:	cmp    eax,0x202
   66270:	jne    66289 <sqlite3VdbeExec+0x16de9>
   66272:	cmp    BYTE PTR [r12+0x16],0x1
   66278:	jne    66289 <sqlite3VdbeExec+0x16de9>
   6627a:	mov    rax,QWORD PTR [r12+0x8]
   6627f:	mov    r14,QWORD PTR [rsp+0x1a8]
   66287:	jmp    662ca <sqlite3VdbeExec+0x16e2a>
   66289:	movzx  eax,WORD PTR [r12+0x14]
   6628f:	and    eax,0x1
   66292:	test   eax,eax
   66294:	je     662a2 <sqlite3VdbeExec+0x16e02>
   66296:	xor    eax,eax
   66298:	mov    r14,QWORD PTR [rsp+0x1a8]
   662a0:	jmp    662ca <sqlite3VdbeExec+0x16e2a>
   662a2:	mov    eax,0x1
   662a7:	mov    QWORD PTR [rsp+0x190],rdi
   662af:	mov    rdi,r12
   662b2:	mov    rsi,rax
   662b5:	call   662ba <sqlite3VdbeExec+0x16e1a>
   662ba:	mov    rdi,QWORD PTR [rsp+0x190]
   662c2:	mov    r14,QWORD PTR [rsp+0x1a8]
   662ca:	mov    QWORD PTR [rsp+0x190],rdi
   662d2:	mov    rsi,rbx
   662d5:	mov    rdx,rax
   662d8:	xor    eax,eax
   662da:	call   662df <sqlite3VdbeExec+0x16e3f>
   662df:	mov    rdi,QWORD PTR [rsp+0x190]
   662e7:	mov    QWORD PTR [rsp+0x1c8],rbp
   662ef:	mov    rbp,r13
   662f2:	mov    r13,QWORD PTR [rsp+0x1b0]
   662fa:	mov    rbx,QWORD PTR [rsp+0x1d8]
   66302:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   66307:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6630f:	mov    eax,r15d
   66312:	movzx  ecx,WORD PTR [r12+0x14]
   66318:	and    ecx,0x2
   6631b:	test   ecx,ecx
   6631d:	jne    6632e <sqlite3VdbeExec+0x16e8e>
   6631f:	mov    BYTE PTR [r12+0x16],al
   66324:	mov    r14,QWORD PTR [rsp+0x1a8]
   6632c:	jmp    66391 <sqlite3VdbeExec+0x16ef1>
   6632e:	movzx  ecx,BYTE PTR [r12+0x16]
   66334:	cmp    ecx,eax
   66336:	jne    66342 <sqlite3VdbeExec+0x16ea2>
   66338:	mov    r14,QWORD PTR [rsp+0x1a8]
   66340:	jmp    66391 <sqlite3VdbeExec+0x16ef1>
   66342:	mov    r14,QWORD PTR [rsp+0x1a8]
   6634a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66355:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66360:	mov    QWORD PTR [rsp+0x190],rdi
   66368:	mov    rdi,r12
   6636b:	mov    rsi,rax
   6636e:	call   66373 <sqlite3VdbeExec+0x16ed3>
   66373:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6637e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66389:	mov    rdi,QWORD PTR [rsp+0x190]
   66391:	mov    DWORD PTR [rsp+0x3fc],r15d
   66399:	mov    DWORD PTR [rsp+0x40c],r13d
   663a1:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   663a6:	mov    r15d,DWORD PTR [rsp+0x3fc]
   663ae:	mov    QWORD PTR [rsp+0x1b0],r12
   663b6:	mov    DWORD PTR [rsp+0x440],0x0
   663c1:	mov    DWORD PTR [rsp+0x448],0xffffffff
   663cc:	mov    DWORD PTR [rsp+0x444],0xffffffff
   663d7:	mov    eax,DWORD PTR [rbp+0x4]
   663da:	mov    ecx,DWORD PTR [rbp+0x8]
   663dd:	lea    r12,[rsp+0x440]
   663e5:	lea    rdx,[r12+0x4]
   663ea:	lea    rsi,[r12+0x8]
   663ef:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   663fa:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66405:	mov    QWORD PTR [rsp+0x190],rdi
   6640d:	mov    rdi,r14
   66410:	mov    r8,rsi
   66413:	mov    rsi,rax
   66416:	mov    r11,rdx
   66419:	mov    rdx,rcx
   6641c:	mov    rcx,r11
   6641f:	call   66424 <sqlite3VdbeExec+0x16f84>
   66424:	mov    r13d,eax
   66427:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66432:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6643d:	mov    rdi,QWORD PTR [rsp+0x190]
   66445:	test   r13d,r13d
   66448:	je     6647e <sqlite3VdbeExec+0x16fde>
   6644a:	cmp    r13d,0x5
   6644e:	je     66470 <sqlite3VdbeExec+0x16fd0>
   66450:	mov    QWORD PTR [rsp+0x1c8],rbp
   66458:	mov    rbp,r13
   6645b:	mov    r13,QWORD PTR [rsp+0x1b0]
   66463:	mov    rbx,QWORD PTR [rsp+0x1d8]
   6646b:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   66470:	mov    DWORD PTR [rsp+0x440],0x1
   6647b:	xor    r13d,r13d
   6647e:	movsxd rax,DWORD PTR [rbp+0xc]
   66482:	imul   rax,rax,0x38
   66486:	lea    r12,[rbx+rax*1]
   6648a:	mov    DWORD PTR [rsp+0x40c],r13d
   66492:	mov    r13,r12
   66495:	xor    r12d,r12d
   66498:	jmp    664ad <sqlite3VdbeExec+0x1700d>
   6649a:	mov    QWORD PTR [r13+0x0],rax
   6649e:	mov    WORD PTR [r13+0x14],0x4
   664a5:	add    r12d,0x1
   664a9:	add    r13,0x38
   664ad:	cmp    r12d,0x3
   664b1:	jge    66516 <sqlite3VdbeExec+0x17076>
   664b3:	mov    rax,r12
   664b6:	movsxd rax,DWORD PTR [rsp+rax*4+0x440]
   664be:	movzx  ecx,WORD PTR [r13+0x14]
   664c3:	and    ecx,0x9000
   664c9:	test   ecx,ecx
   664cb:	je     6649a <sqlite3VdbeExec+0x16ffa>
   664cd:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   664d8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   664e3:	mov    QWORD PTR [rsp+0x190],rdi
   664eb:	mov    rdi,r13
   664ee:	mov    rsi,rax
   664f1:	call   664f6 <sqlite3VdbeExec+0x17056>
   664f6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66501:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6650c:	mov    rdi,QWORD PTR [rsp+0x190]
   66514:	jmp    664a5 <sqlite3VdbeExec+0x17005>
   66516:	mov    DWORD PTR [rsp+0x3fc],r15d
   6651e:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   66523:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6652b:	mov    r13,QWORD PTR [rsp+0x1d0]
   66533:	mov    QWORD PTR [rsp+0x1b0],r12
   6653b:	mov    r12d,DWORD PTR [rsp+0x414]
   66543:	mov    rax,QWORD PTR [rdi+0x68]
   66547:	movsxd rcx,DWORD PTR [rbp+0x8]
   6654b:	imul   rcx,rcx,0x38
   6654f:	mov    DWORD PTR [rsp+0x414],r12d
   66557:	lea    r12,[rax+rcx*1]
   6655b:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   66560:	and    eax,0x9000
   66565:	test   eax,eax
   66567:	je     665b2 <sqlite3VdbeExec+0x17112>
   66569:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66574:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6657f:	mov    QWORD PTR [rsp+0x190],rdi
   66587:	mov    rdi,r12
   6658a:	call   6658f <sqlite3VdbeExec+0x170ef>
   6658f:	mov    r12,rax
   66592:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6659d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   665a8:	mov    rdi,QWORD PTR [rsp+0x190]
   665b0:	jmp    665ba <sqlite3VdbeExec+0x1711a>
   665b2:	mov    WORD PTR [r12+0x14],0x4
   665ba:	mov    QWORD PTR [rsp+0x1e8],r12
   665c2:	mov    r12d,DWORD PTR [rbp+0xc]
   665c6:	mov    rax,QWORD PTR [r14+0x20]
   665ca:	movsxd rcx,DWORD PTR [rbp+0x4]
   665ce:	shl    rcx,0x5
   665d2:	mov    QWORD PTR [rsp+0x1d0],r13
   665da:	mov    r13,QWORD PTR [rax+rcx*1+0x8]
   665df:	mov    rax,QWORD PTR [r13+0x8]
   665e3:	mov    rax,QWORD PTR [rax]
   665e6:	mov    QWORD PTR [rsp+0x210],r13
   665ee:	mov    r13,rax
   665f1:	movzx  eax,BYTE PTR [r13+0x9]
   665f6:	mov    DWORD PTR [rsp+0x3fc],r15d
   665fe:	mov    r15d,eax
   66601:	cmp    r12d,0xffffffff
   66605:	jne    6660a <sqlite3VdbeExec+0x1716a>
   66607:	mov    r12,r15
   6660a:	cmp    BYTE PTR [r13+0x15],0x3
   6660f:	jae    66624 <sqlite3VdbeExec+0x17184>
   66611:	mov    rax,QWORD PTR [r13+0x50]
   66615:	cmp    QWORD PTR [rax],0x0
   66619:	je     66622 <sqlite3VdbeExec+0x17182>
   6661b:	cmp    QWORD PTR [r13+0x60],0x0
   66620:	jg     66624 <sqlite3VdbeExec+0x17184>
   66622:	jmp    66627 <sqlite3VdbeExec+0x17187>
   66624:	mov    r12,r15
   66627:	cmp    BYTE PTR [r13+0x13],0x0
   6662c:	jne    6663b <sqlite3VdbeExec+0x1719b>
   6662e:	lea    rax,[rip+0x0]        # 66635 <sqlite3VdbeExec+0x17195>
   66635:	cmp    rax,QWORD PTR [r13+0x0]
   66639:	jne    66644 <sqlite3VdbeExec+0x171a4>
   6663b:	lea    rax,[rip+0x0]        # 66642 <sqlite3VdbeExec+0x171a2>
   66642:	jmp    6664b <sqlite3VdbeExec+0x171ab>
   66644:	mov    rax,QWORD PTR [r13+0xd8]
   6664b:	cmp    r12d,0x5
   6664f:	jne    666e1 <sqlite3VdbeExec+0x17241>
   66655:	test   rax,rax
   66658:	je     666de <sqlite3VdbeExec+0x1723e>
   6665e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66669:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66674:	mov    QWORD PTR [rsp+0x190],rdi
   6667c:	mov    rdi,rax
   6667f:	call   66684 <sqlite3VdbeExec+0x171e4>
   66684:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6668f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6669a:	and    eax,0x3fffffff
   6669f:	mov    rdi,QWORD PTR [rsp+0x190]
   666a7:	test   eax,eax
   666a9:	je     666de <sqlite3VdbeExec+0x1723e>
   666ab:	mov    rax,QWORD PTR [r13+0x48]
   666af:	mov    rax,QWORD PTR [rax]
   666b2:	cmp    BYTE PTR [r13+0x11],0x0
   666b7:	jne    666de <sqlite3VdbeExec+0x1723e>
   666b9:	cmp    BYTE PTR [r13+0x8],0x0
   666be:	jne    66748 <sqlite3VdbeExec+0x172a8>
   666c4:	cmp    DWORD PTR [rax],0x2
   666c7:	jl     666d8 <sqlite3VdbeExec+0x17238>
   666c9:	cmp    QWORD PTR [rax+0x68],0x0
   666ce:	mov    eax,0x0
   666d3:	setne  al
   666d6:	jmp    666da <sqlite3VdbeExec+0x1723a>
   666d8:	xor    eax,eax
   666da:	test   eax,eax
   666dc:	jne    666e1 <sqlite3VdbeExec+0x17241>
   666de:	mov    r12,r15
   666e1:	cmp    r12d,r15d
   666e4:	jne    666fb <sqlite3VdbeExec+0x1725b>
   666e6:	mov    DWORD PTR [rsp+0x41c],r15d
   666ee:	mov    r15d,DWORD PTR [rsp+0x40c]
   666f6:	jmp    66e6a <sqlite3VdbeExec+0x179ca>
   666fb:	cmp    r15d,0x5
   666ff:	je     6671c <sqlite3VdbeExec+0x1727c>
   66701:	cmp    r12d,0x5
   66705:	je     6671c <sqlite3VdbeExec+0x1727c>
   66707:	mov    DWORD PTR [rsp+0x41c],r15d
   6670f:	mov    r15d,DWORD PTR [rsp+0x40c]
   66717:	jmp    66e6a <sqlite3VdbeExec+0x179ca>
   6671c:	cmp    BYTE PTR [r14+0x65],0x0
   66721:	je     6672d <sqlite3VdbeExec+0x1728d>
   66723:	cmp    DWORD PTR [r14+0xd4],0x1
   6672b:	jle    6678e <sqlite3VdbeExec+0x172ee>
   6672d:	mov    ebx,0x1
   66732:	lea    rax,[rip+0x0]        # 66739 <sqlite3VdbeExec+0x17299>
   66739:	cmp    r12d,0x5
   6673d:	jne    6674a <sqlite3VdbeExec+0x172aa>
   6673f:	lea    rcx,[rip+0x0]        # 66746 <sqlite3VdbeExec+0x172a6>
   66746:	jmp    66751 <sqlite3VdbeExec+0x172b1>
   66748:	jmp    666e1 <sqlite3VdbeExec+0x17241>
   6674a:	lea    rcx,[rip+0x0]        # 66751 <sqlite3VdbeExec+0x172b1>
   66751:	mov    QWORD PTR [rsp+0x190],rdi
   66759:	mov    rsi,rax
   6675c:	mov    rdx,rcx
   6675f:	xor    eax,eax
   66761:	call   66766 <sqlite3VdbeExec+0x172c6>
   66766:	mov    rdi,QWORD PTR [rsp+0x190]
   6676e:	mov    QWORD PTR [rsp+0x1c8],rbp
   66776:	mov    rbp,rbx
   66779:	mov    r13,QWORD PTR [rsp+0x1b0]
   66781:	mov    rbx,QWORD PTR [rsp+0x1d8]
   66789:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   6678e:	cmp    r15d,0x5
   66792:	jne    66d21 <sqlite3VdbeExec+0x17881>
   66798:	xor    eax,eax
   6679a:	cmp    QWORD PTR [r13+0x128],0x0
   667a2:	je     667b1 <sqlite3VdbeExec+0x17311>
   667a4:	mov    DWORD PTR [rsp+0x424],r12d
   667ac:	jmp    66902 <sqlite3VdbeExec+0x17462>
   667b1:	mov    DWORD PTR [rsp+0x424],r12d
   667b9:	lea    r12,[rsp+0x418]
   667c1:	mov    DWORD PTR [r12],0x0
   667c9:	mov    eax,0x1
   667ce:	cmp    BYTE PTR [r13+0x16],0x1
   667d3:	jb     667dc <sqlite3VdbeExec+0x1733c>
   667d5:	cmp    BYTE PTR [r13+0x16],0x5
   667da:	jne    66851 <sqlite3VdbeExec+0x173b1>
   667dc:	cmp    BYTE PTR [r13+0x11],0x0
   667e1:	je     667e7 <sqlite3VdbeExec+0x17347>
   667e3:	xor    eax,eax
   667e5:	jmp    6683a <sqlite3VdbeExec+0x1739a>
   667e7:	mov    rcx,QWORD PTR [r13+0x48]
   667eb:	mov    rdx,QWORD PTR [rcx]
   667ee:	mov    rdx,QWORD PTR [rdx+0x38]
   667f2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   667fd:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66808:	mov    QWORD PTR [rsp+0x190],rdi
   66810:	mov    rdi,rcx
   66813:	mov    rsi,rax
   66816:	mov    r10,rdx
   66819:	call   r10
   6681c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66827:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66832:	mov    rdi,QWORD PTR [rsp+0x190]
   6683a:	test   eax,eax
   6683c:	jne    66969 <sqlite3VdbeExec+0x174c9>
   66842:	cmp    BYTE PTR [r13+0x16],0x5
   66847:	jne    66957 <sqlite3VdbeExec+0x174b7>
   6684d:	test   eax,eax
   6684f:	jne    668b3 <sqlite3VdbeExec+0x17413>
   66851:	mov    rax,QWORD PTR [r13+0x0]
   66855:	mov    rcx,QWORD PTR [r13+0x130]
   6685c:	xor    edx,edx
   6685e:	mov    rsi,r12
   66861:	mov    r8,QWORD PTR [rax+0x38]
   66865:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66870:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6687b:	mov    QWORD PTR [rsp+0x190],rdi
   66883:	mov    rdi,rax
   66886:	mov    r10,r8
   66889:	mov    r11,rsi
   6688c:	mov    rsi,rcx
   6688f:	mov    rcx,r11
   66892:	call   r10
   66895:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   668a0:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   668ab:	mov    rdi,QWORD PTR [rsp+0x190]
   668b3:	test   eax,eax
   668b5:	jne    66902 <sqlite3VdbeExec+0x17462>
   668b7:	cmp    DWORD PTR [r12],0x0
   668bc:	je     66902 <sqlite3VdbeExec+0x17462>
   668be:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   668c9:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   668d4:	mov    QWORD PTR [rsp+0x190],rdi
   668dc:	mov    rdi,r13
   668df:	call   668e4 <sqlite3VdbeExec+0x17444>
   668e4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   668ef:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   668fa:	mov    rdi,QWORD PTR [rsp+0x190]
   66902:	test   eax,eax
   66904:	je     66913 <sqlite3VdbeExec+0x17473>
   66906:	mov    r12d,DWORD PTR [rsp+0x424]
   6690e:	jmp    66cad <sqlite3VdbeExec+0x1780d>
   66913:	cmp    QWORD PTR [r13+0x128],0x0
   6691b:	jne    6692a <sqlite3VdbeExec+0x1748a>
   6691d:	mov    r12d,DWORD PTR [rsp+0x424]
   66925:	jmp    66cad <sqlite3VdbeExec+0x1780d>
   6692a:	movzx  r12d,BYTE PTR [r13+0x16]
   6692f:	mov    eax,0x4
   66934:	xor    ecx,ecx
   66936:	cmp    BYTE PTR [r13+0x16],0x4
   6693b:	jb     6694c <sqlite3VdbeExec+0x174ac>
   6693d:	cmp    BYTE PTR [r13+0x16],0x5
   66942:	je     6694c <sqlite3VdbeExec+0x174ac>
   66944:	mov    rax,rcx
   66947:	jmp    669d7 <sqlite3VdbeExec+0x17537>
   6694c:	cmp    BYTE PTR [r13+0x11],0x0
   66951:	je     66976 <sqlite3VdbeExec+0x174d6>
   66953:	xor    eax,eax
   66955:	jmp    669c9 <sqlite3VdbeExec+0x17529>
   66957:	mov    BYTE PTR [r13+0x16],0x1
   6695c:	test   eax,eax
   6695e:	je     66851 <sqlite3VdbeExec+0x173b1>
   66964:	jmp    668b3 <sqlite3VdbeExec+0x17413>
   66969:	test   eax,eax
   6696b:	je     66851 <sqlite3VdbeExec+0x173b1>
   66971:	jmp    668b3 <sqlite3VdbeExec+0x17413>
   66976:	mov    rcx,QWORD PTR [r13+0x48]
   6697a:	mov    rdx,QWORD PTR [rcx]
   6697d:	mov    rdx,QWORD PTR [rdx+0x38]
   66981:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6698c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66997:	mov    QWORD PTR [rsp+0x190],rdi
   6699f:	mov    rdi,rcx
   669a2:	mov    rsi,rax
   669a5:	mov    r10,rdx
   669a8:	call   r10
   669ab:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   669b6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   669c1:	mov    rdi,QWORD PTR [rsp+0x190]
   669c9:	test   eax,eax
   669cb:	jne    669d7 <sqlite3VdbeExec+0x17537>
   669cd:	movzx  ecx,BYTE PTR [r13+0x16]
   669d2:	mov    BYTE PTR [r13+0x16],0x4
   669d7:	mov    DWORD PTR [rsp+0x41c],r15d
   669df:	mov    r15d,eax
   669e2:	test   r15d,r15d
   669e5:	je     66a5f <sqlite3VdbeExec+0x175bf>
   669e7:	mov    rax,QWORD PTR [r13+0x48]
   669eb:	cmp    QWORD PTR [rax],0x0
   669ef:	je     66a56 <sqlite3VdbeExec+0x175b6>
   669f1:	cmp    BYTE PTR [r13+0x11],0x0
   669f6:	jne    66a4b <sqlite3VdbeExec+0x175ab>
   669f8:	mov    rax,QWORD PTR [r13+0x48]
   669fc:	mov    rcx,QWORD PTR [rax]
   669ff:	mov    rcx,QWORD PTR [rcx+0x40]
   66a03:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66a0e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66a19:	mov    QWORD PTR [rsp+0x190],rdi
   66a21:	mov    rdi,rax
   66a24:	mov    rsi,r12
   66a27:	mov    r10,rcx
   66a2a:	call   r10
   66a2d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66a38:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66a43:	mov    rdi,QWORD PTR [rsp+0x190]
   66a4b:	cmp    BYTE PTR [r13+0x16],0x5
   66a50:	je     66a56 <sqlite3VdbeExec+0x175b6>
   66a52:	mov    BYTE PTR [r13+0x16],r12b
   66a56:	movzx  eax,BYTE PTR [r13+0x10]
   66a5b:	mov    BYTE PTR [r13+0x17],al
   66a5f:	mov    eax,r15d
   66a62:	test   eax,eax
   66a64:	je     66a7b <sqlite3VdbeExec+0x175db>
   66a66:	mov    r15d,DWORD PTR [rsp+0x41c]
   66a6e:	mov    r12d,DWORD PTR [rsp+0x424]
   66a76:	jmp    66cad <sqlite3VdbeExec+0x1780d>
   66a7b:	mov    rax,QWORD PTR [r13+0x128]
   66a82:	movzx  ecx,BYTE PTR [r13+0xf]
   66a87:	mov    rdx,QWORD PTR [r13+0xc8]
   66a8e:	mov    rsi,QWORD PTR [r13+0x118]
   66a95:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66aa0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66aab:	mov    QWORD PTR [rsp+0x190],rdi
   66ab3:	mov    rdi,rax
   66ab6:	mov    r8,rsi
   66ab9:	mov    rsi,r14
   66abc:	mov    r11,rdx
   66abf:	mov    rdx,rcx
   66ac2:	mov    rcx,r11
   66ac5:	call   66aca <sqlite3VdbeExec+0x1762a>
   66aca:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66ad5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66ae0:	mov    QWORD PTR [r13+0x128],0x0
   66aeb:	lea    rcx,[rsp+0x200]
   66af3:	mov    rdx,QWORD PTR [r13+0x48]
   66af7:	mov    rdi,QWORD PTR [rsp+0x190]
   66aff:	cmp    QWORD PTR [rdx],0x0
   66b03:	je     66bd8 <sqlite3VdbeExec+0x17738>
   66b09:	mov    rdx,QWORD PTR [rdx]
   66b0c:	cmp    DWORD PTR [rdx],0x3
   66b0f:	jl     66bd8 <sqlite3VdbeExec+0x17738>
   66b15:	mov    rdx,QWORD PTR [r13+0xa0]
   66b1c:	mov    QWORD PTR [rcx],rdx
   66b1f:	xor    edx,edx
   66b21:	cmp    QWORD PTR [rcx],0x0
   66b25:	setg   dl
   66b28:	mov    BYTE PTR [r13+0x1b],dl
   66b2c:	cmp    DWORD PTR [r13+0x30],0x0
   66b31:	je     66b43 <sqlite3VdbeExec+0x176a3>
   66b33:	lea    rdx,[rip+0x0]        # 66b3a <sqlite3VdbeExec+0x1769a>
   66b3a:	mov    QWORD PTR [r13+0x110],rdx
   66b41:	jmp    66b68 <sqlite3VdbeExec+0x176c8>
   66b43:	cmp    BYTE PTR [r13+0x1b],0x0
   66b48:	je     66b5a <sqlite3VdbeExec+0x176ba>
   66b4a:	lea    rdx,[rip+0x0]        # 66b51 <sqlite3VdbeExec+0x176b1>
   66b51:	mov    QWORD PTR [r13+0x110],rdx
   66b58:	jmp    66b68 <sqlite3VdbeExec+0x176c8>
   66b5a:	lea    rdx,[rip+0x0]        # 66b61 <sqlite3VdbeExec+0x176c1>
   66b61:	mov    QWORD PTR [r13+0x110],rdx
   66b68:	mov    rdx,QWORD PTR [r13+0x48]
   66b6c:	mov    esi,0x12
   66b71:	cmp    QWORD PTR [rdx],0x0
   66b75:	je     66bd8 <sqlite3VdbeExec+0x17738>
   66b77:	mov    r8,QWORD PTR [rdx]
   66b7a:	mov    r8,QWORD PTR [r8+0x50]
   66b7e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66b89:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66b94:	mov    QWORD PTR [rsp+0x188],rax
   66b9c:	mov    QWORD PTR [rsp+0x190],rdi
   66ba4:	mov    rdi,rdx
   66ba7:	mov    rdx,rcx
   66baa:	mov    r10,r8
   66bad:	call   r10
   66bb0:	mov    ecx,eax
   66bb2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66bbd:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66bc8:	mov    rax,QWORD PTR [rsp+0x188]
   66bd0:	mov    rdi,QWORD PTR [rsp+0x190]
   66bd8:	test   eax,eax
   66bda:	jne    66bf1 <sqlite3VdbeExec+0x17751>
   66bdc:	mov    r15d,DWORD PTR [rsp+0x41c]
   66be4:	mov    r12d,DWORD PTR [rsp+0x424]
   66bec:	jmp    66cad <sqlite3VdbeExec+0x1780d>
   66bf1:	cmp    BYTE PTR [r13+0x8],0x0
   66bf6:	je     66c0d <sqlite3VdbeExec+0x1776d>
   66bf8:	mov    r15d,DWORD PTR [rsp+0x41c]
   66c00:	mov    r12d,DWORD PTR [rsp+0x424]
   66c08:	jmp    66cad <sqlite3VdbeExec+0x1780d>
   66c0d:	mov    ecx,0x1
   66c12:	mov    rdx,QWORD PTR [r13+0x48]
   66c16:	cmp    QWORD PTR [rdx],0x0
   66c1a:	je     66c94 <sqlite3VdbeExec+0x177f4>
   66c1c:	cmp    BYTE PTR [r13+0x11],0x0
   66c21:	jne    66c88 <sqlite3VdbeExec+0x177e8>
   66c23:	mov    rdx,QWORD PTR [r13+0x48]
   66c27:	mov    rsi,QWORD PTR [rdx]
   66c2a:	mov    rsi,QWORD PTR [rsi+0x40]
   66c2e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66c39:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66c44:	mov    QWORD PTR [rsp+0x188],rax
   66c4c:	mov    QWORD PTR [rsp+0x190],rdi
   66c54:	mov    rdi,rdx
   66c57:	mov    r10,rsi
   66c5a:	mov    rsi,rcx
   66c5d:	call   r10
   66c60:	mov    ecx,eax
   66c62:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66c6d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66c78:	mov    rax,QWORD PTR [rsp+0x188]
   66c80:	mov    rdi,QWORD PTR [rsp+0x190]
   66c88:	cmp    BYTE PTR [r13+0x16],0x5
   66c8d:	je     66c94 <sqlite3VdbeExec+0x177f4>
   66c8f:	mov    BYTE PTR [r13+0x16],0x1
   66c94:	movzx  ecx,BYTE PTR [r13+0x10]
   66c99:	mov    BYTE PTR [r13+0x17],cl
   66c9d:	mov    r15d,DWORD PTR [rsp+0x41c]
   66ca5:	mov    r12d,DWORD PTR [rsp+0x424]
   66cad:	mov    DWORD PTR [rsp+0x41c],r15d
   66cb5:	mov    r15d,eax
   66cb8:	test   r15d,r15d
   66cbb:	jne    66d04 <sqlite3VdbeExec+0x17864>
   66cbd:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66cc8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66cd3:	mov    QWORD PTR [rsp+0x190],rdi
   66cdb:	mov    rdi,r13
   66cde:	mov    rsi,r12
   66ce1:	call   66ce6 <sqlite3VdbeExec+0x17846>
   66ce6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66cf1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66cfc:	mov    rdi,QWORD PTR [rsp+0x190]
   66d04:	test   r15d,r15d
   66d07:	jne    66e6a <sqlite3VdbeExec+0x179ca>
   66d0d:	cmp    r12d,0x5
   66d11:	jne    66df3 <sqlite3VdbeExec+0x17953>
   66d17:	mov    eax,0x2
   66d1c:	jmp    66e18 <sqlite3VdbeExec+0x17978>
   66d21:	mov    DWORD PTR [rsp+0x424],r12d
   66d29:	cmp    r15d,0x4
   66d2d:	jne    66db9 <sqlite3VdbeExec+0x17919>
   66d33:	mov    eax,0x2
   66d38:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66d43:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66d4e:	mov    QWORD PTR [rsp+0x190],rdi
   66d56:	mov    rdi,r13
   66d59:	mov    rsi,rax
   66d5c:	call   66d61 <sqlite3VdbeExec+0x178c1>
   66d61:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66d6c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66d77:	mov    rdi,QWORD PTR [rsp+0x190]
   66d7f:	mov    r12d,DWORD PTR [rsp+0x40c]
   66d87:	test   r12d,r12d
   66d8a:	je     66da4 <sqlite3VdbeExec+0x17904>
   66d8c:	mov    DWORD PTR [rsp+0x41c],r15d
   66d94:	mov    r15,r12
   66d97:	mov    r12d,DWORD PTR [rsp+0x424]
   66d9f:	jmp    66e6a <sqlite3VdbeExec+0x179ca>
   66da4:	mov    DWORD PTR [rsp+0x41c],r15d
   66dac:	mov    r12d,DWORD PTR [rsp+0x424]
   66db4:	jmp    66d0d <sqlite3VdbeExec+0x1786d>
   66db9:	mov    r12d,DWORD PTR [rsp+0x40c]
   66dc1:	test   r12d,r12d
   66dc4:	je     66dde <sqlite3VdbeExec+0x1793e>
   66dc6:	mov    DWORD PTR [rsp+0x41c],r15d
   66dce:	mov    r15,r12
   66dd1:	mov    r12d,DWORD PTR [rsp+0x424]
   66dd9:	jmp    66e6a <sqlite3VdbeExec+0x179ca>
   66dde:	mov    DWORD PTR [rsp+0x41c],r15d
   66de6:	mov    r12d,DWORD PTR [rsp+0x424]
   66dee:	jmp    66d0d <sqlite3VdbeExec+0x1786d>
   66df3:	mov    r15d,DWORD PTR [rsp+0x41c]
   66dfb:	mov    DWORD PTR [rsp+0x424],r12d
   66e03:	mov    eax,0x1
   66e08:	mov    DWORD PTR [rsp+0x41c],r15d
   66e10:	mov    r12d,DWORD PTR [rsp+0x424]
   66e18:	mov    r15,QWORD PTR [rsp+0x210]
   66e20:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66e2b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66e36:	mov    QWORD PTR [rsp+0x190],rdi
   66e3e:	mov    rdi,r15
   66e41:	mov    rsi,rax
   66e44:	call   66e49 <sqlite3VdbeExec+0x179a9>
   66e49:	mov    r15d,eax
   66e4c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66e57:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66e62:	mov    rdi,QWORD PTR [rsp+0x190]
   66e6a:	test   r15d,r15d
   66e6d:	je     66e77 <sqlite3VdbeExec+0x179d7>
   66e6f:	mov    r12d,DWORD PTR [rsp+0x41c]
   66e77:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66e82:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66e8d:	mov    QWORD PTR [rsp+0x190],rdi
   66e95:	mov    rdi,r13
   66e98:	mov    rsi,r12
   66e9b:	call   66ea0 <sqlite3VdbeExec+0x17a00>
   66ea0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66eab:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66eb6:	mov    r12,QWORD PTR [rsp+0x1e8]
   66ebe:	mov    WORD PTR [r12+0x14],0x2202
   66ec6:	mov    rdi,QWORD PTR [rsp+0x190]
   66ece:	cmp    eax,0x6
   66ed1:	jne    66ed7 <sqlite3VdbeExec+0x17a37>
   66ed3:	xor    eax,eax
   66ed5:	jmp    66ee5 <sqlite3VdbeExec+0x17a45>
   66ed7:	lea    rcx,[rip+0x0]        # 66ede <sqlite3VdbeExec+0x17a3e>
   66ede:	movsxd rax,eax
   66ee1:	mov    rax,QWORD PTR [rcx+rax*8]
   66ee5:	mov    QWORD PTR [r12+0x8],rax
   66eea:	mov    rax,QWORD PTR [r12+0x8]
   66eef:	test   rax,rax
   66ef2:	jne    66ef8 <sqlite3VdbeExec+0x17a58>
   66ef4:	xor    eax,eax
   66ef6:	jmp    66f41 <sqlite3VdbeExec+0x17aa1>
   66ef8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66f03:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66f0e:	mov    QWORD PTR [rsp+0x190],rdi
   66f16:	mov    rdi,rax
   66f19:	call   66f1e <sqlite3VdbeExec+0x17a7e>
   66f1e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66f29:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66f34:	and    eax,0x3fffffff
   66f39:	mov    rdi,QWORD PTR [rsp+0x190]
   66f41:	mov    DWORD PTR [r12+0x10],eax
   66f46:	mov    BYTE PTR [r12+0x16],0x1
   66f4c:	mov    r13d,DWORD PTR [rsp+0x3fc]
   66f54:	mov    eax,r13d
   66f57:	movzx  ecx,WORD PTR [r12+0x14]
   66f5d:	and    ecx,0x2
   66f60:	test   ecx,ecx
   66f62:	jne    66f8e <sqlite3VdbeExec+0x17aee>
   66f64:	mov    BYTE PTR [r12+0x16],al
   66f69:	test   r15d,r15d
   66f6c:	je     66f9d <sqlite3VdbeExec+0x17afd>
   66f6e:	mov    QWORD PTR [rsp+0x1c8],rbp
   66f76:	mov    rbp,r15
   66f79:	mov    r13,QWORD PTR [rsp+0x1b0]
   66f81:	mov    rbx,QWORD PTR [rsp+0x1d8]
   66f89:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   66f8e:	movzx  ecx,BYTE PTR [r12+0x16]
   66f94:	cmp    ecx,eax
   66f96:	jne    66fb2 <sqlite3VdbeExec+0x17b12>
   66f98:	test   r15d,r15d
   66f9b:	jne    66f6e <sqlite3VdbeExec+0x17ace>
   66f9d:	mov    DWORD PTR [rsp+0x3fc],r13d
   66fa5:	mov    DWORD PTR [rsp+0x40c],r15d
   66fad:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   66fb2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   66fbd:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   66fc8:	mov    QWORD PTR [rsp+0x190],rdi
   66fd0:	mov    rdi,r12
   66fd3:	mov    rsi,rax
   66fd6:	call   66fdb <sqlite3VdbeExec+0x17b3b>
   66fdb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   66fe6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   66ff1:	mov    rdi,QWORD PTR [rsp+0x190]
   66ff9:	test   r15d,r15d
   66ffc:	jne    66f6e <sqlite3VdbeExec+0x17ace>
   67002:	jmp    66f9d <sqlite3VdbeExec+0x17afd>
   67004:	mov    r13d,DWORD PTR [rsp+0x3fc]
   6700c:	mov    QWORD PTR [rsp+0x1b0],r12
   67014:	lea    rax,[rdi+0xa8]
   6701b:	mov    ecx,DWORD PTR [rbp+0x4]
   6701e:	cmp    DWORD PTR [rbp+0x8],0x0
   67022:	je     67031 <sqlite3VdbeExec+0x17b91>
   67024:	movsxd rdx,DWORD PTR [rbp+0x8]
   67028:	imul   rdx,rdx,0x38
   6702c:	add    rdx,rbx
   6702f:	jmp    67033 <sqlite3VdbeExec+0x17b93>
   67031:	xor    edx,edx
   67033:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6703e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67049:	mov    QWORD PTR [rsp+0x190],rdi
   67051:	mov    rdi,rax
   67054:	mov    rsi,r14
   67057:	mov    r11,rdx
   6705a:	mov    rdx,rcx
   6705d:	mov    rcx,r11
   67060:	call   67065 <sqlite3VdbeExec+0x17bc5>
   67065:	mov    r12d,eax
   67068:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67073:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6707e:	mov    rdi,QWORD PTR [rsp+0x190]
   67086:	test   r12d,r12d
   67089:	je     670ab <sqlite3VdbeExec+0x17c0b>
   6708b:	mov    QWORD PTR [rsp+0x1c8],rbp
   67093:	mov    rbp,r12
   67096:	mov    r13,QWORD PTR [rsp+0x1b0]
   6709e:	mov    rbx,QWORD PTR [rsp+0x1d8]
   670a6:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   670ab:	mov    DWORD PTR [rsp+0x3fc],r13d
   670b3:	mov    DWORD PTR [rsp+0x40c],r12d
   670bb:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   670c0:	mov    r13d,DWORD PTR [rsp+0x3fc]
   670c8:	mov    QWORD PTR [rsp+0x1b0],r12
   670d0:	mov    rax,QWORD PTR [r14+0x20]
   670d4:	movsxd rcx,DWORD PTR [rbp+0x4]
   670d8:	shl    rcx,0x5
   670dc:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   670e1:	mov    r12,QWORD PTR [rax+0x8]
   670e5:	mov    rcx,QWORD PTR [rax+0x8]
   670e9:	mov    rax,QWORD PTR [rax]
   670ec:	mov    QWORD PTR [rcx+0x8],rax
   670f0:	cmp    BYTE PTR [r12+0x21],0x0
   670f6:	jne    67102 <sqlite3VdbeExec+0x17c62>
   670f8:	mov    eax,0x65
   670fd:	jmp    67537 <sqlite3VdbeExec+0x18097>
   67102:	mov    eax,DWORD PTR [r12+0x40]
   67107:	mov    r15d,eax
   6710a:	mov    rax,QWORD PTR [r12+0x18]
   6710f:	mov    rax,QWORD PTR [rax+0x50]
   67113:	movzx  ecx,BYTE PTR [rax+0x24]
   67117:	shl    ecx,0x18
   6711a:	movzx  edx,BYTE PTR [rax+0x25]
   6711e:	shl    edx,0x10
   67121:	or     ecx,edx
   67123:	movzx  edx,BYTE PTR [rax+0x26]
   67127:	shl    edx,0x8
   6712a:	or     ecx,edx
   6712c:	movzx  eax,BYTE PTR [rax+0x27]
   67130:	or     ecx,eax
   67132:	mov    eax,DWORD PTR [r12+0x38]
   67137:	mov    edx,0xcccccccd
   6713c:	mul    edx
   6713e:	shr    edx,0x2
   67141:	mov    esi,edx
   67143:	mov    r8d,ecx
   67146:	sub    r8d,r15d
   67149:	cmp    r15d,0x2
   6714d:	jae    67153 <sqlite3VdbeExec+0x17cb3>
   6714f:	xor    eax,eax
   67151:	jmp    671a1 <sqlite3VdbeExec+0x17d01>
   67153:	mov    eax,DWORD PTR [r12+0x38]
   67158:	mov    edx,0xcccccccd
   6715d:	mul    edx
   6715f:	shr    edx,0x2
   67162:	mov    eax,edx
   67164:	lea    r9d,[rax+0x1]
   67168:	mov    eax,r15d
   6716b:	sub    eax,0x2
   6716e:	xor    edx,edx
   67170:	div    r9d
   67173:	imul   eax,r9d
   67177:	lea    r9d,[rax+0x2]
   6717b:	mov    eax,DWORD PTR [rip+0x0]        # 67181 <sqlite3VdbeExec+0x17ce1>
   67181:	mov    r10d,DWORD PTR [r12+0x34]
   67186:	xor    edx,edx
   67188:	div    r10d
   6718b:	add    eax,0x1
   6718e:	xor    edx,edx
   67190:	mov    r10d,0x1
   67196:	cmp    r9d,eax
   67199:	cmove  edx,r10d
   6719d:	lea    eax,[r9+rdx*1]
   671a1:	add    eax,r8d
   671a4:	add    eax,esi
   671a6:	xor    edx,edx
   671a8:	div    esi
   671aa:	mov    edx,r15d
   671ad:	sub    edx,ecx
   671af:	mov    esi,edx
   671b1:	sub    esi,eax
   671b3:	mov    eax,DWORD PTR [rip+0x0]        # 671b9 <sqlite3VdbeExec+0x17d19>
   671b9:	mov    r8d,DWORD PTR [r12+0x34]
   671be:	xor    edx,edx
   671c0:	div    r8d
   671c3:	add    eax,0x1
   671c6:	cmp    r15d,eax
   671c9:	jbe    67259 <sqlite3VdbeExec+0x17db9>
   671cf:	mov    eax,DWORD PTR [rip+0x0]        # 671d5 <sqlite3VdbeExec+0x17d35>
   671d5:	mov    r8d,DWORD PTR [r12+0x34]
   671da:	xor    edx,edx
   671dc:	div    r8d
   671df:	add    eax,0x1
   671e2:	mov    edx,esi
   671e4:	sub    edx,0x1
   671e7:	cmp    esi,eax
   671e9:	cmovb  esi,edx
   671ec:	jmp    67259 <sqlite3VdbeExec+0x17db9>
   671ee:	mov    eax,DWORD PTR [r12+0x38]
   671f3:	mov    edx,0xcccccccd
   671f8:	mul    edx
   671fa:	shr    edx,0x2
   671fd:	mov    eax,edx
   671ff:	lea    r8d,[rax+0x1]
   67203:	mov    eax,esi
   67205:	sub    eax,0x2
   67208:	xor    edx,edx
   6720a:	div    r8d
   6720d:	imul   eax,r8d
   67211:	lea    r8d,[rax+0x2]
   67215:	mov    eax,DWORD PTR [rip+0x0]        # 6721b <sqlite3VdbeExec+0x17d7b>
   6721b:	mov    r9d,DWORD PTR [r12+0x34]
   67220:	xor    edx,edx
   67222:	div    r9d
   67225:	add    eax,0x1
   67228:	xor    edx,edx
   6722a:	mov    r9d,0x1
   67230:	cmp    r8d,eax
   67233:	cmove  edx,r9d
   67237:	lea    eax,[r8+rdx*1]
   6723b:	cmp    eax,esi
   6723d:	je     67256 <sqlite3VdbeExec+0x17db6>
   6723f:	mov    eax,DWORD PTR [rip+0x0]        # 67245 <sqlite3VdbeExec+0x17da5>
   67245:	mov    r8d,DWORD PTR [r12+0x34]
   6724a:	xor    edx,edx
   6724c:	div    r8d
   6724f:	add    eax,0x1
   67252:	cmp    esi,eax
   67254:	jne    67266 <sqlite3VdbeExec+0x17dc6>
   67256:	sub    esi,0x1
   67259:	cmp    esi,0x2
   6725c:	jae    671ee <sqlite3VdbeExec+0x17d4e>
   6725e:	xor    eax,eax
   67260:	cmp    eax,esi
   67262:	je     67256 <sqlite3VdbeExec+0x17db6>
   67264:	jmp    6723f <sqlite3VdbeExec+0x17d9f>
   67266:	mov    DWORD PTR [rsp+0x3fc],r13d
   6726e:	mov    r13d,esi
   67271:	cmp    r15d,r13d
   67274:	jb     6727b <sqlite3VdbeExec+0x17ddb>
   67276:	cmp    ecx,r15d
   67279:	jb     672e0 <sqlite3VdbeExec+0x17e40>
   6727b:	mov    eax,0x12e03
   67280:	mov    ecx,0xb
   67285:	lea    rdx,[rip+0x0]        # 6728c <sqlite3VdbeExec+0x17dec>
   6728c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67297:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   672a2:	mov    QWORD PTR [rsp+0x190],rdi
   672aa:	mov    rdi,rcx
   672ad:	mov    rsi,rax
   672b0:	call   672b5 <sqlite3VdbeExec+0x17e15>
   672b5:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   672c0:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   672cb:	mov    rdi,QWORD PTR [rsp+0x190]
   672d3:	mov    r13d,DWORD PTR [rsp+0x3fc]
   672db:	jmp    67537 <sqlite3VdbeExec+0x18097>
   672e0:	test   ecx,ecx
   672e2:	jbe    6752a <sqlite3VdbeExec+0x1808a>
   672e8:	xor    eax,eax
   672ea:	xor    ecx,ecx
   672ec:	mov    rdx,QWORD PTR [r12+0x10]
   672f1:	jmp    672fc <sqlite3VdbeExec+0x17e5c>
   672f3:	test   rdx,rdx
   672f6:	jne    67301 <sqlite3VdbeExec+0x17e61>
   672f8:	mov    rdx,QWORD PTR [rdx+0x28]
   672fc:	test   rdx,rdx
   672ff:	jne    672f3 <sqlite3VdbeExec+0x17e53>
   67301:	test   rdx,rdx
   67304:	je     67358 <sqlite3VdbeExec+0x17eb8>
   67306:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67311:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6731c:	mov    QWORD PTR [rsp+0x190],rdi
   67324:	mov    rdi,rdx
   67327:	mov    rsi,rax
   6732a:	mov    rdx,rcx
   6732d:	call   67332 <sqlite3VdbeExec+0x17e92>
   67332:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6733d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   67348:	mov    rdi,QWORD PTR [rsp+0x190]
   67350:	test   eax,eax
   67352:	jne    6743b <sqlite3VdbeExec+0x17f9b>
   67358:	mov    rax,QWORD PTR [r12+0x10]
   6735d:	jmp    6736d <sqlite3VdbeExec+0x17ecd>
   6735f:	movzx  ecx,BYTE PTR [rax+0x1]
   67363:	and    ecx,0xfffffffb
   67366:	mov    BYTE PTR [rax+0x1],cl
   67369:	mov    rax,QWORD PTR [rax+0x28]
   6736d:	test   rax,rax
   67370:	jne    6735f <sqlite3VdbeExec+0x17ebf>
   67372:	xor    eax,eax
   67374:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6737f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6738a:	mov    QWORD PTR [rsp+0x190],rdi
   67392:	mov    rdi,r12
   67395:	mov    rsi,r13
   67398:	mov    rdx,r15
   6739b:	mov    rcx,rax
   6739e:	call   673a3 <sqlite3VdbeExec+0x17f03>
   673a3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   673ae:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   673b9:	mov    rdi,QWORD PTR [rsp+0x190]
   673c1:	test   eax,eax
   673c3:	jne    67520 <sqlite3VdbeExec+0x18080>
   673c9:	mov    rax,QWORD PTR [r12+0x18]
   673ce:	mov    rax,QWORD PTR [rax+0x70]
   673d2:	mov    rcx,QWORD PTR [rax+0x28]
   673d6:	movzx  edx,WORD PTR [rax+0x34]
   673da:	and    edx,0x4
   673dd:	test   edx,edx
   673df:	je     6744b <sqlite3VdbeExec+0x17fab>
   673e1:	mov    edx,DWORD PTR [rcx+0x20]
   673e4:	cmp    edx,DWORD PTR [rax+0x30]
   673e7:	jb     6744b <sqlite3VdbeExec+0x17fab>
   673e9:	cmp    DWORD PTR [rcx+0x80],0x0
   673f0:	je     67444 <sqlite3VdbeExec+0x17fa4>
   673f2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   673fd:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67408:	mov    QWORD PTR [rsp+0x190],rdi
   67410:	mov    rdi,rax
   67413:	call   67418 <sqlite3VdbeExec+0x17f78>
   67418:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67423:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6742e:	mov    rdi,QWORD PTR [rsp+0x190]
   67436:	jmp    674f4 <sqlite3VdbeExec+0x18054>
   6743b:	test   eax,eax
   6743d:	je     673c9 <sqlite3VdbeExec+0x17f29>
   6743f:	jmp    67520 <sqlite3VdbeExec+0x18080>
   67444:	xor    eax,eax
   67446:	jmp    674f4 <sqlite3VdbeExec+0x18054>
   6744b:	cmp    DWORD PTR [rcx+0x30],0x0
   6744f:	je     67459 <sqlite3VdbeExec+0x17fb9>
   67451:	mov    eax,DWORD PTR [rcx+0x30]
   67454:	jmp    674f4 <sqlite3VdbeExec+0x18054>
   67459:	mov    edx,DWORD PTR [rcx+0xb8]
   6745f:	mov    rcx,QWORD PTR [rcx+0xc8]
   67466:	cmp    edx,ecx
   67468:	jbe    674b0 <sqlite3VdbeExec+0x18010>
   6746a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67475:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67480:	mov    QWORD PTR [rsp+0x190],rdi
   67488:	mov    rdi,rax
   6748b:	call   67490 <sqlite3VdbeExec+0x17ff0>
   67490:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6749b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   674a6:	mov    rdi,QWORD PTR [rsp+0x190]
   674ae:	jmp    674f4 <sqlite3VdbeExec+0x18054>
   674b0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   674bb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   674c6:	mov    QWORD PTR [rsp+0x190],rdi
   674ce:	mov    rdi,rax
   674d1:	call   674d6 <sqlite3VdbeExec+0x18036>
   674d6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   674e1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   674ec:	mov    rdi,QWORD PTR [rsp+0x190]
   674f4:	mov    rcx,QWORD PTR [r12+0x18]
   674f9:	mov    rcx,QWORD PTR [rcx+0x50]
   674fd:	mov    edx,DWORD PTR [r12+0x40]
   67502:	mov    esi,edx
   67504:	shr    esi,0x18
   67507:	mov    BYTE PTR [rcx+0x1c],sil
   6750b:	mov    esi,edx
   6750d:	shr    esi,0x10
   67510:	mov    BYTE PTR [rcx+0x1d],sil
   67514:	mov    esi,edx
   67516:	shr    esi,0x8
   67519:	mov    BYTE PTR [rcx+0x1e],sil
   6751d:	mov    BYTE PTR [rcx+0x1f],dl
   67520:	mov    r13d,DWORD PTR [rsp+0x3fc]
   67528:	jmp    67537 <sqlite3VdbeExec+0x18097>
   6752a:	mov    eax,0x65
   6752f:	mov    r13d,DWORD PTR [rsp+0x3fc]
   67537:	mov    r12d,eax
   6753a:	test   r12d,r12d
   6753d:	je     6757b <sqlite3VdbeExec+0x180db>
   6753f:	cmp    r12d,0x65
   67543:	je     67565 <sqlite3VdbeExec+0x180c5>
   67545:	mov    QWORD PTR [rsp+0x1c8],rbp
   6754d:	mov    rbp,r12
   67550:	mov    r13,QWORD PTR [rsp+0x1b0]
   67558:	mov    rbx,QWORD PTR [rsp+0x1d8]
   67560:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   67565:	mov    r12,r14
   67568:	mov    r15,r13
   6756b:	xor    r11d,r11d
   6756e:	mov    DWORD PTR [rsp+0x40c],r11d
   67576:	jmp    52730 <sqlite3VdbeExec+0x3290>
   6757b:	mov    DWORD PTR [rsp+0x3fc],r13d
   67583:	mov    DWORD PTR [rsp+0x40c],r12d
   6758b:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   67590:	mov    r15d,DWORD PTR [rsp+0x3fc]
   67598:	mov    r13,QWORD PTR [rsp+0x1d0]
   675a0:	mov    QWORD PTR [rsp+0x1b0],r12
   675a8:	mov    r12d,DWORD PTR [rsp+0x414]
   675b0:	cmp    DWORD PTR [rbp+0x4],0x0
   675b4:	jne    675e6 <sqlite3VdbeExec+0x18146>
   675b6:	mov    eax,DWORD PTR [rbp+0x8]
   675b9:	mov    rcx,QWORD PTR [r14+0x8]
   675bd:	jmp    675df <sqlite3VdbeExec+0x1813f>
   675bf:	lea    edx,[rax+0x1]
   675c2:	and    rdx,0x3
   675c6:	movzx  esi,WORD PTR [rcx+0xc8]
   675cd:	and    rsi,0xfffffffffffffffc
   675d1:	or     rsi,rdx
   675d4:	mov    WORD PTR [rcx+0xc8],si
   675db:	mov    rcx,QWORD PTR [rcx+0x10]
   675df:	test   rcx,rcx
   675e2:	jne    675bf <sqlite3VdbeExec+0x1811f>
   675e4:	jmp    67605 <sqlite3VdbeExec+0x18165>
   675e6:	mov    eax,DWORD PTR [rbp+0x8]
   675e9:	add    eax,0x1
   675ec:	and    rax,0x3
   675f0:	movzx  ecx,WORD PTR [rdi+0xc8]
   675f7:	and    rcx,0xfffffffffffffffc
   675fb:	or     rcx,rax
   675fe:	mov    WORD PTR [rdi+0xc8],cx
   67605:	mov    DWORD PTR [rsp+0x3fc],r15d
   6760d:	mov    QWORD PTR [rsp+0x1d0],r13
   67615:	mov    DWORD PTR [rsp+0x414],r12d
   6761d:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   67622:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6762a:	mov    r13,QWORD PTR [rsp+0x1d0]
   67632:	mov    QWORD PTR [rsp+0x1b0],r12
   6763a:	mov    r12d,DWORD PTR [rsp+0x414]
   67642:	mov    rax,QWORD PTR [rdi+0x78]
   67646:	movsxd rcx,DWORD PTR [rbp+0x4]
   6764a:	mov    rax,QWORD PTR [rax+rcx*8]
   6764e:	mov    rax,QWORD PTR [rax+0x28]
   67652:	movzx  ecx,BYTE PTR [rax+0x1]
   67656:	or     ecx,0x40
   67659:	mov    BYTE PTR [rax+0x1],cl
   6765c:	mov    DWORD PTR [rsp+0x3fc],r15d
   67664:	mov    QWORD PTR [rsp+0x1d0],r13
   6766c:	mov    DWORD PTR [rsp+0x414],r12d
   67674:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   67679:	mov    r15d,DWORD PTR [rsp+0x3fc]
   67681:	mov    r13,QWORD PTR [rsp+0x1d0]
   67689:	mov    QWORD PTR [rsp+0x1b0],r12
   67691:	mov    r12d,DWORD PTR [rsp+0x414]
   67699:	mov    rax,QWORD PTR [rdi+0x78]
   6769d:	movsxd rcx,DWORD PTR [rbp+0x4]
   676a1:	mov    rax,QWORD PTR [rax+rcx*8]
   676a5:	mov    rax,QWORD PTR [rax+0x28]
   676a9:	movzx  ecx,BYTE PTR [rax+0x1]
   676ad:	and    ecx,0xffffffbf
   676b0:	mov    BYTE PTR [rax+0x1],cl
   676b3:	mov    DWORD PTR [rsp+0x3fc],r15d
   676bb:	mov    QWORD PTR [rsp+0x1d0],r13
   676c3:	mov    DWORD PTR [rsp+0x414],r12d
   676cb:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   676d0:	mov    r15d,DWORD PTR [rsp+0x3fc]
   676d8:	mov    r13,QWORD PTR [rsp+0x1d0]
   676e0:	mov    QWORD PTR [rsp+0x1b0],r12
   676e8:	mov    r12d,DWORD PTR [rsp+0x414]
   676f0:	mov    eax,DWORD PTR [rbp+0xc]
   676f3:	movzx  eax,al
   676f6:	mov    ecx,eax
   676f8:	test   ecx,ecx
   676fa:	jne    6772e <sqlite3VdbeExec+0x1828e>
   676fc:	xor    ecx,ecx
   676fe:	movabs rdx,0x400000000
   67708:	and    rdx,QWORD PTR [r14+0x30]
   6770c:	cmp    rcx,rdx
   6770f:	je     6772e <sqlite3VdbeExec+0x1828e>
   67711:	mov    QWORD PTR [rsp+0x1d0],r13
   67719:	mov    DWORD PTR [rsp+0x414],r12d
   67721:	mov    r12d,DWORD PTR [rsp+0x40c]
   67729:	jmp    679c3 <sqlite3VdbeExec+0x18523>
   6772e:	movsxd rcx,DWORD PTR [rbp+0x4]
   67732:	mov    rdx,QWORD PTR [r14+0x20]
   67736:	shl    rcx,0x5
   6773a:	mov    DWORD PTR [rsp+0x414],r12d
   67742:	mov    r12,QWORD PTR [rdx+rcx*1+0x8]
   67747:	mov    QWORD PTR [rsp+0x1d0],r13
   6774f:	mov    r13d,DWORD PTR [rbp+0x8]
   67753:	xor    ecx,ecx
   67755:	cmp    BYTE PTR [r12+0x11],0x0
   6775b:	je     67966 <sqlite3VdbeExec+0x184c6>
   67761:	mov    ecx,0x1
   67766:	add    cl,al
   67768:	mov    rax,QWORD PTR [r12+0x8]
   6776d:	mov    rdx,QWORD PTR [r12]
   67771:	mov    QWORD PTR [rax+0x8],rdx
   67775:	mov    eax,ecx
   67777:	mov    rdx,QWORD PTR [r12+0x8]
   6777c:	cmp    BYTE PTR [r12+0x11],0x0
   67782:	je     677eb <sqlite3VdbeExec+0x1834b>
   67784:	cmp    r12,QWORD PTR [rdx+0x80]
   6778b:	je     677a5 <sqlite3VdbeExec+0x18305>
   6778d:	movzx  esi,WORD PTR [rdx+0x28]
   67791:	and    esi,0x40
   67794:	test   esi,esi
   67796:	je     677a5 <sqlite3VdbeExec+0x18305>
   67798:	mov    eax,0x106
   6779d:	mov    rcx,rax
   677a0:	jmp    67966 <sqlite3VdbeExec+0x184c6>
   677a5:	mov    rsi,QWORD PTR [rdx+0x78]
   677a9:	jmp    677af <sqlite3VdbeExec+0x1830f>
   677ab:	mov    rsi,QWORD PTR [rsi+0x10]
   677af:	test   rsi,rsi
   677b2:	je     677eb <sqlite3VdbeExec+0x1834b>
   677b4:	cmp    r12,QWORD PTR [rsi]
   677b7:	je     677ab <sqlite3VdbeExec+0x1830b>
   677b9:	cmp    r13d,DWORD PTR [rsi+0x8]
   677bd:	jne    677ab <sqlite3VdbeExec+0x1830b>
   677bf:	movzx  r8d,BYTE PTR [rsi+0xc]
   677c4:	mov    r9d,eax
   677c7:	cmp    r8d,r9d
   677ca:	je     677ab <sqlite3VdbeExec+0x1830b>
   677cc:	cmp    eax,0x2
   677cf:	jne    677de <sqlite3VdbeExec+0x1833e>
   677d1:	movzx  eax,WORD PTR [rdx+0x28]
   677d5:	or     eax,0x80
   677da:	mov    WORD PTR [rdx+0x28],ax
   677de:	mov    eax,0x106
   677e3:	mov    rcx,rax
   677e6:	jmp    67966 <sqlite3VdbeExec+0x184c6>
   677eb:	mov    DWORD PTR [rsp+0x41c],r13d
   677f3:	mov    r13d,ecx
   677f6:	mov    DWORD PTR [rsp+0x424],r13d
   677fe:	mov    r13,QWORD PTR [r12+0x8]
   67803:	mov    rax,QWORD PTR [r13+0x78]
   67807:	jmp    6780d <sqlite3VdbeExec+0x1836d>
   67809:	mov    rax,QWORD PTR [rax+0x10]
   6780d:	test   rax,rax
   67810:	jne    67824 <sqlite3VdbeExec+0x18384>
   67812:	mov    DWORD PTR [rsp+0x3fc],r15d
   6781a:	mov    r15d,DWORD PTR [rsp+0x41c]
   67822:	jmp    6786d <sqlite3VdbeExec+0x183cd>
   67824:	mov    DWORD PTR [rsp+0x3fc],r15d
   6782c:	mov    r15d,DWORD PTR [rsp+0x41c]
   67834:	cmp    r15d,DWORD PTR [rax+0x8]
   67838:	je     67844 <sqlite3VdbeExec+0x183a4>
   6783a:	mov    r15d,DWORD PTR [rsp+0x3fc]
   67842:	jmp    67809 <sqlite3VdbeExec+0x18369>
   67844:	cmp    r12,QWORD PTR [rax]
   67847:	je     6785b <sqlite3VdbeExec+0x183bb>
   67849:	mov    DWORD PTR [rsp+0x41c],r15d
   67851:	mov    r15d,DWORD PTR [rsp+0x3fc]
   67859:	jmp    67809 <sqlite3VdbeExec+0x18369>
   6785b:	test   rax,rax
   6785e:	je     6786d <sqlite3VdbeExec+0x183cd>
   67860:	mov    r13d,DWORD PTR [rsp+0x424]
   67868:	jmp    6794a <sqlite3VdbeExec+0x184aa>
   6786d:	mov    DWORD PTR [rsp+0x41c],r15d
   67875:	mov    r15d,0x18
   6787b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67886:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67891:	mov    QWORD PTR [rsp+0x190],rdi
   67899:	mov    rdi,r15
   6789c:	call   678a1 <sqlite3VdbeExec+0x18401>
   678a1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   678ac:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   678b7:	mov    rdi,QWORD PTR [rsp+0x190]
   678bf:	test   rax,rax
   678c2:	je     6791b <sqlite3VdbeExec+0x1847b>
   678c4:	xor    ecx,ecx
   678c6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   678d1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   678dc:	mov    QWORD PTR [rsp+0x188],rax
   678e4:	mov    rdi,rax
   678e7:	mov    rsi,rcx
   678ea:	mov    rdx,r15
   678ed:	call   678f2 <sqlite3VdbeExec+0x18452>
   678f2:	mov    rcx,rax
   678f5:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67900:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6790b:	mov    rax,QWORD PTR [rsp+0x188]
   67913:	mov    rdi,QWORD PTR [rsp+0x190]
   6791b:	test   rax,rax
   6791e:	jne    67927 <sqlite3VdbeExec+0x18487>
   67920:	mov    eax,0x7
   67925:	jmp    6795b <sqlite3VdbeExec+0x184bb>
   67927:	mov    r15d,DWORD PTR [rsp+0x41c]
   6792f:	mov    DWORD PTR [rax+0x8],r15d
   67933:	mov    QWORD PTR [rax],r12
   67936:	mov    rcx,QWORD PTR [r13+0x78]
   6793a:	mov    QWORD PTR [rax+0x10],rcx
   6793e:	mov    QWORD PTR [r13+0x78],rax
   67942:	mov    r13d,DWORD PTR [rsp+0x424]
   6794a:	mov    ecx,r13d
   6794d:	movzx  edx,BYTE PTR [rax+0xc]
   67951:	cmp    ecx,edx
   67953:	jle    67959 <sqlite3VdbeExec+0x184b9>
   67955:	mov    BYTE PTR [rax+0xc],r13b
   67959:	xor    eax,eax
   6795b:	mov    r15d,DWORD PTR [rsp+0x3fc]
   67963:	mov    rcx,rax
   67966:	mov    r12d,ecx
   67969:	test   r12d,r12d
   6796c:	je     679c3 <sqlite3VdbeExec+0x18523>
   6796e:	mov    eax,r12d
   67971:	and    eax,0xff
   67976:	cmp    eax,0x6
   67979:	jne    679a3 <sqlite3VdbeExec+0x18503>
   6797b:	mov    rax,QWORD PTR [rbp+0x10]
   6797f:	lea    rcx,[rip+0x0]        # 67986 <sqlite3VdbeExec+0x184e6>
   67986:	mov    QWORD PTR [rsp+0x190],rdi
   6798e:	mov    rsi,rcx
   67991:	mov    rdx,rax
   67994:	xor    eax,eax
   67996:	call   6799b <sqlite3VdbeExec+0x184fb>
   6799b:	mov    rdi,QWORD PTR [rsp+0x190]
   679a3:	mov    QWORD PTR [rsp+0x1c8],rbp
   679ab:	mov    rbp,r12
   679ae:	mov    r13,QWORD PTR [rsp+0x1b0]
   679b6:	mov    rbx,QWORD PTR [rsp+0x1d8]
   679be:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   679c3:	mov    DWORD PTR [rsp+0x3fc],r15d
   679cb:	mov    DWORD PTR [rsp+0x40c],r12d
   679d3:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   679d8:	mov    r15d,DWORD PTR [rsp+0x3fc]
   679e0:	mov    QWORD PTR [rsp+0x1b0],r12
   679e8:	mov    r12,QWORD PTR [rbp+0x10]
   679ec:	xor    r13d,r13d
   679ef:	cmp    DWORD PTR [r14+0x21c],0x0
   679f7:	jle    67a16 <sqlite3VdbeExec+0x18576>
   679f9:	cmp    QWORD PTR [r14+0x240],0x0
   67a01:	jne    67a16 <sqlite3VdbeExec+0x18576>
   67a03:	mov    r13d,0x6
   67a09:	mov    DWORD PTR [rsp+0x424],r13d
   67a11:	jmp    67d6b <sqlite3VdbeExec+0x188cb>
   67a16:	test   r12,r12
   67a19:	jne    67a2b <sqlite3VdbeExec+0x1858b>
   67a1b:	xor    r13d,r13d
   67a1e:	mov    DWORD PTR [rsp+0x424],r13d
   67a26:	jmp    67d6b <sqlite3VdbeExec+0x188cb>
   67a2b:	mov    rax,QWORD PTR [r12+0x10]
   67a30:	mov    r13,QWORD PTR [rax]
   67a33:	cmp    QWORD PTR [r13+0x70],0x0
   67a38:	jne    67a4a <sqlite3VdbeExec+0x185aa>
   67a3a:	xor    r11d,r11d
   67a3d:	mov    DWORD PTR [rsp+0x424],r11d
   67a45:	jmp    67d6b <sqlite3VdbeExec+0x188cb>
   67a4a:	xor    eax,eax
   67a4c:	jmp    67a51 <sqlite3VdbeExec+0x185b1>
   67a4e:	add    eax,0x1
   67a51:	cmp    eax,DWORD PTR [r14+0x21c]
   67a58:	jge    67a7a <sqlite3VdbeExec+0x185da>
   67a5a:	mov    rcx,QWORD PTR [r14+0x240]
   67a61:	mov    rdx,rax
   67a64:	cmp    r12,QWORD PTR [rcx+rdx*8]
   67a68:	jne    67a4e <sqlite3VdbeExec+0x185ae>
   67a6a:	xor    r13d,r13d
   67a6d:	mov    DWORD PTR [rsp+0x424],r13d
   67a75:	jmp    67d6b <sqlite3VdbeExec+0x188cb>
   67a7a:	mov    eax,DWORD PTR [r14+0x21c]
   67a81:	mov    r11d,eax
   67a84:	mov    eax,0x66666667
   67a89:	imul   r11d
   67a8c:	sar    edx,0x1
   67a8f:	mov    eax,edx
   67a91:	shr    eax,0x1f
   67a94:	add    edx,eax
   67a96:	imul   edx,edx,0x5
   67a99:	neg    edx
   67a9b:	add    edx,r11d
   67a9e:	mov    eax,edx
   67aa0:	test   eax,eax
   67aa2:	je     67ab1 <sqlite3VdbeExec+0x18611>
   67aa4:	mov    QWORD PTR [rsp+0x1e8],r13
   67aac:	jmp    67c1d <sqlite3VdbeExec+0x1877d>
   67ab1:	movsxd rax,DWORD PTR [r14+0x21c]
   67ab8:	add    rax,0x5
   67abc:	shl    rax,0x3
   67ac0:	mov    QWORD PTR [rsp+0x1e8],r13
   67ac8:	mov    r13,QWORD PTR [r14+0x240]
   67acf:	test   r13,r13
   67ad2:	jne    67b23 <sqlite3VdbeExec+0x18683>
   67ad4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67adf:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67aea:	mov    QWORD PTR [rsp+0x190],rdi
   67af2:	mov    rdi,r14
   67af5:	mov    rsi,rax
   67af8:	call   67afd <sqlite3VdbeExec+0x1865d>
   67afd:	mov    r13,rax
   67b00:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67b0b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   67b16:	mov    rdi,QWORD PTR [rsp+0x190]
   67b1e:	jmp    67ba4 <sqlite3VdbeExec+0x18704>
   67b23:	cmp    r13,QWORD PTR [r14+0x1e8]
   67b2a:	jae    67b57 <sqlite3VdbeExec+0x186b7>
   67b2c:	cmp    r13,QWORD PTR [r14+0x1d8]
   67b33:	jb     67b3f <sqlite3VdbeExec+0x1869f>
   67b35:	cmp    rax,0x80
   67b3b:	ja     67b57 <sqlite3VdbeExec+0x186b7>
   67b3d:	jmp    67ba4 <sqlite3VdbeExec+0x18704>
   67b3f:	cmp    r13,QWORD PTR [r14+0x1e0]
   67b46:	jb     67b57 <sqlite3VdbeExec+0x186b7>
   67b48:	movzx  ecx,WORD PTR [r14+0x19e]
   67b50:	cmp    rax,rcx
   67b53:	ja     67b57 <sqlite3VdbeExec+0x186b7>
   67b55:	jmp    67ba4 <sqlite3VdbeExec+0x18704>
   67b57:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67b62:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67b6d:	mov    QWORD PTR [rsp+0x190],rdi
   67b75:	mov    rdi,r14
   67b78:	mov    rsi,r13
   67b7b:	mov    rdx,rax
   67b7e:	call   67b83 <sqlite3VdbeExec+0x186e3>
   67b83:	mov    r13,rax
   67b86:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67b91:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   67b9c:	mov    rdi,QWORD PTR [rsp+0x190]
   67ba4:	test   r13,r13
   67ba7:	jne    67bbc <sqlite3VdbeExec+0x1871c>
   67ba9:	mov    r13d,0x7
   67baf:	mov    DWORD PTR [rsp+0x424],r13d
   67bb7:	jmp    67d6b <sqlite3VdbeExec+0x188cb>
   67bbc:	movsxd rax,DWORD PTR [r14+0x21c]
   67bc3:	lea    rax,[r13+rax*8+0x0]
   67bc8:	xor    ecx,ecx
   67bca:	mov    edx,0x28
   67bcf:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67bda:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67be5:	mov    QWORD PTR [rsp+0x190],rdi
   67bed:	mov    rdi,rax
   67bf0:	mov    rsi,rcx
   67bf3:	call   67bf8 <sqlite3VdbeExec+0x18758>
   67bf8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67c03:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   67c0e:	mov    QWORD PTR [r14+0x240],r13
   67c15:	mov    rdi,QWORD PTR [rsp+0x190]
   67c1d:	mov    r13,QWORD PTR [rsp+0x1e8]
   67c25:	mov    rax,QWORD PTR [r13+0x70]
   67c29:	mov    rcx,QWORD PTR [r12+0x10]
   67c2e:	mov    DWORD PTR [rsp+0x3fc],r15d
   67c36:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67c41:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67c4c:	mov    QWORD PTR [rsp+0x190],rdi
   67c54:	mov    rdi,rcx
   67c57:	mov    r10,rax
   67c5a:	call   r10
   67c5d:	mov    r15d,eax
   67c60:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67c6b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   67c76:	mov    rdi,QWORD PTR [rsp+0x190]
   67c7e:	test   r15d,r15d
   67c81:	je     67c98 <sqlite3VdbeExec+0x187f8>
   67c83:	mov    DWORD PTR [rsp+0x424],r15d
   67c8b:	mov    r15d,DWORD PTR [rsp+0x3fc]
   67c93:	jmp    67d6b <sqlite3VdbeExec+0x188cb>
   67c98:	mov    eax,DWORD PTR [r14+0x2ec]
   67c9f:	add    eax,DWORD PTR [r14+0x2e8]
   67ca6:	mov    rcx,QWORD PTR [r14+0x240]
   67cad:	movsxd rdx,DWORD PTR [r14+0x21c]
   67cb4:	lea    esi,[rdx+0x1]
   67cb7:	mov    DWORD PTR [r14+0x21c],esi
   67cbe:	mov    QWORD PTR [rcx+rdx*8],r12
   67cc2:	mov    ecx,DWORD PTR [r12+0x18]
   67cc7:	add    ecx,0x1
   67cca:	mov    DWORD PTR [r12+0x18],ecx
   67ccf:	test   eax,eax
   67cd1:	jne    67ce8 <sqlite3VdbeExec+0x18848>
   67cd3:	mov    DWORD PTR [rsp+0x424],r15d
   67cdb:	mov    r15d,DWORD PTR [rsp+0x3fc]
   67ce3:	jmp    67d6b <sqlite3VdbeExec+0x188cb>
   67ce8:	cmp    QWORD PTR [r13+0xa0],0x0
   67cf0:	jne    67d04 <sqlite3VdbeExec+0x18864>
   67cf2:	mov    DWORD PTR [rsp+0x424],r15d
   67cfa:	mov    r15d,DWORD PTR [rsp+0x3fc]
   67d02:	jmp    67d6b <sqlite3VdbeExec+0x188cb>
   67d04:	mov    DWORD PTR [r12+0x20],eax
   67d09:	mov    rcx,QWORD PTR [r13+0xa0]
   67d10:	mov    rdx,QWORD PTR [r12+0x10]
   67d15:	sub    eax,0x1
   67d18:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67d23:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67d2e:	mov    rdi,rdx
   67d31:	mov    rsi,rax
   67d34:	mov    r10,rcx
   67d37:	call   r10
   67d3a:	mov    r13d,eax
   67d3d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67d48:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   67d53:	mov    rdi,QWORD PTR [rsp+0x190]
   67d5b:	mov    r15d,DWORD PTR [rsp+0x3fc]
   67d63:	mov    DWORD PTR [rsp+0x424],r13d
   67d6b:	test   r12,r12
   67d6e:	je     68078 <sqlite3VdbeExec+0x18bd8>
   67d74:	mov    r12,QWORD PTR [r12+0x10]
   67d79:	cmp    QWORD PTR [r12+0x10],0x0
   67d7f:	je     68078 <sqlite3VdbeExec+0x18bd8>
   67d85:	mov    r13,QWORD PTR [rdi]
   67d88:	mov    rax,QWORD PTR [rdi+0xa8]
   67d8f:	test   rax,rax
   67d92:	je     67ddb <sqlite3VdbeExec+0x1893b>
   67d94:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67d9f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67daa:	mov    QWORD PTR [rsp+0x190],rdi
   67db2:	mov    rdi,r13
   67db5:	mov    rsi,rax
   67db8:	call   67dbd <sqlite3VdbeExec+0x1891d>
   67dbd:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67dc8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   67dd3:	mov    rdi,QWORD PTR [rsp+0x190]
   67ddb:	mov    QWORD PTR [rsp+0x1e8],r12
   67de3:	mov    r12,QWORD PTR [r12+0x10]
   67de8:	test   r12,r12
   67deb:	jne    67e00 <sqlite3VdbeExec+0x18960>
   67ded:	xor    r12d,r12d
   67df0:	mov    r13,r12
   67df3:	mov    r12,QWORD PTR [rsp+0x1e8]
   67dfb:	jmp    67f51 <sqlite3VdbeExec+0x18ab1>
   67e00:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67e0b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67e16:	mov    QWORD PTR [rsp+0x190],rdi
   67e1e:	mov    rdi,r12
   67e21:	call   67e26 <sqlite3VdbeExec+0x18986>
   67e26:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67e31:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   67e3c:	mov    QWORD PTR [rsp+0x210],r12
   67e44:	lea    r12,[rax+0x1]
   67e48:	mov    rdi,QWORD PTR [rsp+0x190]
   67e50:	test   r13,r13
   67e53:	je     67e99 <sqlite3VdbeExec+0x189f9>
   67e55:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67e60:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67e6b:	mov    rdi,r13
   67e6e:	mov    rsi,r12
   67e71:	call   67e76 <sqlite3VdbeExec+0x189d6>
   67e76:	mov    r13,rax
   67e79:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67e84:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   67e8f:	mov    rdi,QWORD PTR [rsp+0x190]
   67e97:	jmp    67ed8 <sqlite3VdbeExec+0x18a38>
   67e99:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67ea4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67eaf:	mov    rdi,r12
   67eb2:	call   67eb7 <sqlite3VdbeExec+0x18a17>
   67eb7:	mov    r13,rax
   67eba:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67ec5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   67ed0:	mov    rdi,QWORD PTR [rsp+0x190]
   67ed8:	test   r13,r13
   67edb:	jne    67ee7 <sqlite3VdbeExec+0x18a47>
   67edd:	mov    DWORD PTR [rsp+0x3fc],r15d
   67ee5:	jmp    67f41 <sqlite3VdbeExec+0x18aa1>
   67ee7:	mov    DWORD PTR [rsp+0x3fc],r15d
   67eef:	mov    r15,QWORD PTR [rsp+0x210]
   67ef7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67f02:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67f0d:	mov    QWORD PTR [rsp+0x190],rdi
   67f15:	mov    rdi,r13
   67f18:	mov    rsi,r15
   67f1b:	mov    rdx,r12
   67f1e:	call   67f23 <sqlite3VdbeExec+0x18a83>
   67f23:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67f2e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   67f39:	mov    rdi,QWORD PTR [rsp+0x190]
   67f41:	mov    r15d,DWORD PTR [rsp+0x3fc]
   67f49:	mov    r12,QWORD PTR [rsp+0x1e8]
   67f51:	mov    QWORD PTR [rdi+0xa8],r13
   67f58:	mov    r13,QWORD PTR [r12+0x10]
   67f5d:	test   r13,r13
   67f60:	je     6806f <sqlite3VdbeExec+0x18bcf>
   67f66:	cmp    DWORD PTR [rip+0x0],0x0        # 67f6d <sqlite3VdbeExec+0x18acd>
   67f6d:	je     68023 <sqlite3VdbeExec+0x18b83>
   67f73:	mov    rax,QWORD PTR [rip+0x0]        # 67f7a <sqlite3VdbeExec+0x18ada>
   67f7a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67f85:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67f90:	mov    QWORD PTR [rsp+0x190],rdi
   67f98:	mov    rdi,r13
   67f9b:	mov    r10,rax
   67f9e:	call   r10
   67fa1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   67fac:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   67fb7:	mov    rcx,QWORD PTR [rip+0x0]        # 67fbe <sqlite3VdbeExec+0x18b1e>
   67fbe:	movsxd rax,eax
   67fc1:	sub    rcx,rax
   67fc4:	mov    QWORD PTR [rip+0x0],rcx        # 67fcb <sqlite3VdbeExec+0x18b2b>
   67fcb:	mov    rax,QWORD PTR [rip+0x0]        # 67fd2 <sqlite3VdbeExec+0x18b32>
   67fd2:	sub    rax,0x1
   67fd6:	mov    QWORD PTR [rip+0x0],rax        # 67fdd <sqlite3VdbeExec+0x18b3d>
   67fdd:	mov    rax,QWORD PTR [rip+0x0]        # 67fe4 <sqlite3VdbeExec+0x18b44>
   67fe4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   67fef:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   67ffa:	mov    rdi,r13
   67ffd:	mov    r10,rax
   68000:	call   r10
   68003:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6800e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68019:	mov    rdi,QWORD PTR [rsp+0x190]
   68021:	jmp    6806f <sqlite3VdbeExec+0x18bcf>
   68023:	mov    rax,QWORD PTR [rip+0x0]        # 6802a <sqlite3VdbeExec+0x18b8a>
   6802a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68035:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68040:	mov    QWORD PTR [rsp+0x190],rdi
   68048:	mov    rdi,r13
   6804b:	mov    r10,rax
   6804e:	call   r10
   68051:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6805c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68067:	mov    rdi,QWORD PTR [rsp+0x190]
   6806f:	mov    QWORD PTR [r12+0x10],0x0
   68078:	mov    r12d,DWORD PTR [rsp+0x424]
   68080:	test   r12d,r12d
   68083:	je     680a5 <sqlite3VdbeExec+0x18c05>
   68085:	mov    QWORD PTR [rsp+0x1c8],rbp
   6808d:	mov    rbp,r12
   68090:	mov    r13,QWORD PTR [rsp+0x1b0]
   68098:	mov    rbx,QWORD PTR [rsp+0x1d8]
   680a0:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   680a5:	mov    DWORD PTR [rsp+0x3fc],r15d
   680ad:	mov    DWORD PTR [rsp+0x40c],r12d
   680b5:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   680ba:	mov    r15d,DWORD PTR [rsp+0x3fc]
   680c2:	mov    QWORD PTR [rsp+0x1b0],r12
   680ca:	lea    r12,[rsp+0x2f8]
   680d2:	mov    rax,r12
   680d5:	xor    ecx,ecx
   680d7:	mov    edx,0x38
   680dc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   680e7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   680f2:	mov    QWORD PTR [rsp+0x190],rdi
   680fa:	mov    rdi,rax
   680fd:	mov    rsi,rcx
   68100:	call   68105 <sqlite3VdbeExec+0x18c65>
   68105:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68110:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6811b:	mov    QWORD PTR [rsp+0x310],r14
   68123:	mov    rax,r12
   68126:	movsxd rcx,DWORD PTR [rbp+0x8]
   6812a:	imul   rcx,rcx,0x38
   6812e:	add    rcx,rbx
   68131:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6813c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68147:	mov    rdi,rax
   6814a:	mov    rsi,rcx
   6814d:	call   68152 <sqlite3VdbeExec+0x18cb2>
   68152:	mov    r13d,eax
   68155:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68160:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6816b:	mov    rax,r12
   6816e:	mov    rdi,QWORD PTR [rsp+0x190]
   68176:	test   rax,rax
   68179:	jne    6817f <sqlite3VdbeExec+0x18cdf>
   6817b:	xor    eax,eax
   6817d:	jmp    681f8 <sqlite3VdbeExec+0x18d58>
   6817f:	movzx  ecx,WORD PTR [rax+0x14]
   68183:	and    ecx,0x202
   68189:	cmp    ecx,0x202
   6818f:	jne    6819d <sqlite3VdbeExec+0x18cfd>
   68191:	cmp    BYTE PTR [rax+0x16],0x1
   68195:	jne    6819d <sqlite3VdbeExec+0x18cfd>
   68197:	mov    rax,QWORD PTR [rax+0x8]
   6819b:	jmp    681f8 <sqlite3VdbeExec+0x18d58>
   6819d:	movzx  ecx,WORD PTR [rax+0x14]
   681a1:	and    ecx,0x1
   681a4:	test   ecx,ecx
   681a6:	je     681ac <sqlite3VdbeExec+0x18d0c>
   681a8:	xor    eax,eax
   681aa:	jmp    681f8 <sqlite3VdbeExec+0x18d58>
   681ac:	mov    ecx,0x1
   681b1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   681bc:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   681c7:	mov    QWORD PTR [rsp+0x190],rdi
   681cf:	mov    rdi,rax
   681d2:	mov    rsi,rcx
   681d5:	call   681da <sqlite3VdbeExec+0x18d3a>
   681da:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   681e5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   681f0:	mov    rdi,QWORD PTR [rsp+0x190]
   681f8:	test   rax,rax
   681fb:	je     6864f <sqlite3VdbeExec+0x191af>
   68201:	movsxd rcx,DWORD PTR [rbp+0x4]
   68205:	lea    r13,[rdi+0xa8]
   6820c:	mov    rdx,QWORD PTR [r14+0x20]
   68210:	shl    rcx,0x5
   68214:	mov    rcx,QWORD PTR [rdx+rcx*1]
   68218:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68223:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6822e:	mov    QWORD PTR [rsp+0x190],rdi
   68236:	mov    rdi,r14
   68239:	mov    rsi,rax
   6823c:	mov    rdx,rcx
   6823f:	call   68244 <sqlite3VdbeExec+0x18da4>
   68244:	mov    r12,rax
   68247:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68252:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6825d:	mov    rax,QWORD PTR [r12+0x48]
   68262:	mov    rcx,QWORD PTR [rax]
   68265:	xor    eax,eax
   68267:	mov    rdi,QWORD PTR [rsp+0x190]
   6826f:	mov    rsi,rcx
   68272:	jmp    68289 <sqlite3VdbeExec+0x18de9>
   68274:	movzx  edx,BYTE PTR [rsi]
   68277:	add    rsi,0x1
   6827b:	and    edx,0xdf
   68281:	add    eax,edx
   68283:	imul   eax,eax,0x9e3779b1
   68289:	cmp    BYTE PTR [rsi],0x0
   6828c:	jne    68274 <sqlite3VdbeExec+0x18dd4>
   6828e:	mov    esi,eax
   68290:	cmp    QWORD PTR [r14+0x230],0x0
   68298:	je     682ca <sqlite3VdbeExec+0x18e2a>
   6829a:	mov    r8,QWORD PTR [r14+0x230]
   682a1:	mov    r9d,DWORD PTR [r14+0x220]
   682a8:	mov    rax,rsi
   682ab:	xor    edx,edx
   682ad:	div    r9d
   682b0:	mov    eax,edx
   682b2:	shl    rax,0x4
   682b6:	mov    rdx,QWORD PTR [r8+rax*1+0x8]
   682bb:	mov    eax,DWORD PTR [r8+rax*1]
   682bf:	mov    r11,rax
   682c2:	mov    rax,rdx
   682c5:	mov    rdx,r11
   682c8:	jmp    682d8 <sqlite3VdbeExec+0x18e38>
   682ca:	mov    rax,QWORD PTR [r14+0x228]
   682d1:	mov    edx,DWORD PTR [r14+0x224]
   682d8:	mov    QWORD PTR [rsp+0x1e8],rcx
   682e0:	mov    r10,rax
   682e3:	mov    rcx,rdx
   682e6:	jmp    68366 <sqlite3VdbeExec+0x18ec6>
   682e8:	mov    QWORD PTR [rsp+0x210],r10
   682f0:	lea    r10,[rip+0x0]        # 682f7 <sqlite3VdbeExec+0x18e57>
   682f7:	movzx  edx,BYTE PTR [r10+rdx*1]
   682fc:	movzx  r9d,BYTE PTR [r10+r9*1]
   68301:	sub    edx,r9d
   68304:	test   edx,edx
   68306:	je     68328 <sqlite3VdbeExec+0x18e88>
   68308:	test   edx,edx
   6830a:	je     68316 <sqlite3VdbeExec+0x18e76>
   6830c:	mov    r10,QWORD PTR [rsp+0x210]
   68314:	jmp    68360 <sqlite3VdbeExec+0x18ec0>
   68316:	mov    rcx,QWORD PTR [rsp+0x1e8]
   6831e:	mov    rax,QWORD PTR [rsp+0x210]
   68326:	jmp    6838d <sqlite3VdbeExec+0x18eed>
   68328:	add    rax,0x1
   6832c:	add    r8,0x1
   68330:	mov    r10,QWORD PTR [rsp+0x210]
   68338:	movzx  edx,BYTE PTR [rax]
   6833b:	movzx  r9d,BYTE PTR [r8]
   6833f:	cmp    edx,r9d
   68342:	jne    682e8 <sqlite3VdbeExec+0x18e48>
   68344:	test   edx,edx
   68346:	je     68352 <sqlite3VdbeExec+0x18eb2>
   68348:	mov    QWORD PTR [rsp+0x210],r10
   68350:	jmp    68328 <sqlite3VdbeExec+0x18e88>
   68352:	test   edx,edx
   68354:	jne    68360 <sqlite3VdbeExec+0x18ec0>
   68356:	mov    QWORD PTR [rsp+0x210],r10
   6835e:	jmp    68316 <sqlite3VdbeExec+0x18e76>
   68360:	mov    r10,QWORD PTR [r10]
   68363:	sub    ecx,0x1
   68366:	test   ecx,ecx
   68368:	je     6837e <sqlite3VdbeExec+0x18ede>
   6836a:	cmp    esi,DWORD PTR [r10+0x20]
   6836e:	jne    68360 <sqlite3VdbeExec+0x18ec0>
   68370:	mov    rax,QWORD PTR [r10+0x18]
   68374:	mov    r8,QWORD PTR [rsp+0x1e8]
   6837c:	jmp    68338 <sqlite3VdbeExec+0x18e98>
   6837e:	lea    rax,[rip+0x0]        # 68385 <sqlite3VdbeExec+0x18ee5>
   68385:	mov    rcx,QWORD PTR [rsp+0x1e8]
   6838d:	mov    rax,QWORD PTR [rax+0x10]
   68391:	test   rax,rax
   68394:	je     683aa <sqlite3VdbeExec+0x18f0a>
   68396:	mov    rdx,QWORD PTR [rax]
   68399:	cmp    QWORD PTR [rdx+0x8],0x0
   6839e:	je     683aa <sqlite3VdbeExec+0x18f0a>
   683a0:	mov    rdx,QWORD PTR [rax]
   683a3:	cmp    QWORD PTR [rdx+0x28],0x0
   683a8:	jne    68408 <sqlite3VdbeExec+0x18f68>
   683aa:	lea    rax,[rip+0x0]        # 683b1 <sqlite3VdbeExec+0x18f11>
   683b1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   683bc:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   683c7:	mov    QWORD PTR [rsp+0x190],rdi
   683cf:	mov    rdi,r14
   683d2:	mov    rsi,rax
   683d5:	mov    rdx,rcx
   683d8:	xor    eax,eax
   683da:	call   683df <sqlite3VdbeExec+0x18f3f>
   683df:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   683ea:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   683f5:	mov    QWORD PTR [r13+0x0],rax
   683f9:	mov    eax,0x1
   683fe:	mov    rdi,QWORD PTR [rsp+0x190]
   68406:	jmp    6845c <sqlite3VdbeExec+0x18fbc>
   68408:	mov    rcx,QWORD PTR [rax]
   6840b:	mov    rcx,QWORD PTR [rcx+0x8]
   6840f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6841a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68425:	mov    QWORD PTR [rsp+0x190],rdi
   6842d:	mov    rdi,r14
   68430:	mov    rsi,r12
   68433:	mov    rdx,rax
   68436:	mov    r8,r13
   68439:	call   6843e <sqlite3VdbeExec+0x18f9e>
   6843e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68449:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68454:	mov    rdi,QWORD PTR [rsp+0x190]
   6845c:	test   eax,eax
   6845e:	jne    68649 <sqlite3VdbeExec+0x191a9>
   68464:	mov    rcx,QWORD PTR [r12+0x50]
   68469:	jmp    68474 <sqlite3VdbeExec+0x18fd4>
   6846b:	cmp    r14,QWORD PTR [rcx]
   6846e:	je     68479 <sqlite3VdbeExec+0x18fd9>
   68470:	mov    rcx,QWORD PTR [rcx+0x28]
   68474:	test   rcx,rcx
   68477:	jne    6846b <sqlite3VdbeExec+0x18fcb>
   68479:	test   rcx,rcx
   6847c:	je     68649 <sqlite3VdbeExec+0x191a9>
   68482:	mov    eax,DWORD PTR [r14+0x21c]
   68489:	mov    r11d,eax
   6848c:	mov    eax,0x66666667
   68491:	imul   r11d
   68494:	sar    edx,0x1
   68497:	mov    eax,edx
   68499:	shr    eax,0x1f
   6849c:	add    edx,eax
   6849e:	imul   edx,edx,0x5
   684a1:	neg    edx
   684a3:	add    edx,r11d
   684a6:	mov    eax,edx
   684a8:	test   eax,eax
   684aa:	jne    68608 <sqlite3VdbeExec+0x19168>
   684b0:	movsxd rax,DWORD PTR [r14+0x21c]
   684b7:	add    rax,0x5
   684bb:	shl    rax,0x3
   684bf:	mov    r13,QWORD PTR [r14+0x240]
   684c6:	test   r13,r13
   684c9:	jne    6851a <sqlite3VdbeExec+0x1907a>
   684cb:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   684d6:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   684e1:	mov    QWORD PTR [rsp+0x190],rdi
   684e9:	mov    rdi,r14
   684ec:	mov    rsi,rax
   684ef:	call   684f4 <sqlite3VdbeExec+0x19054>
   684f4:	mov    r13,rax
   684f7:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68502:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6850d:	mov    rdi,QWORD PTR [rsp+0x190]
   68515:	jmp    6859b <sqlite3VdbeExec+0x190fb>
   6851a:	cmp    r13,QWORD PTR [r14+0x1e8]
   68521:	jae    6854e <sqlite3VdbeExec+0x190ae>
   68523:	cmp    r13,QWORD PTR [r14+0x1d8]
   6852a:	jb     68536 <sqlite3VdbeExec+0x19096>
   6852c:	cmp    rax,0x80
   68532:	ja     6854e <sqlite3VdbeExec+0x190ae>
   68534:	jmp    6859b <sqlite3VdbeExec+0x190fb>
   68536:	cmp    r13,QWORD PTR [r14+0x1e0]
   6853d:	jb     6854e <sqlite3VdbeExec+0x190ae>
   6853f:	movzx  ecx,WORD PTR [r14+0x19e]
   68547:	cmp    rax,rcx
   6854a:	ja     6854e <sqlite3VdbeExec+0x190ae>
   6854c:	jmp    6859b <sqlite3VdbeExec+0x190fb>
   6854e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68559:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68564:	mov    QWORD PTR [rsp+0x190],rdi
   6856c:	mov    rdi,r14
   6856f:	mov    rsi,r13
   68572:	mov    rdx,rax
   68575:	call   6857a <sqlite3VdbeExec+0x190da>
   6857a:	mov    r13,rax
   6857d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68588:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68593:	mov    rdi,QWORD PTR [rsp+0x190]
   6859b:	test   r13,r13
   6859e:	jne    685a7 <sqlite3VdbeExec+0x19107>
   685a0:	mov    eax,0x7
   685a5:	jmp    6860a <sqlite3VdbeExec+0x1916a>
   685a7:	movsxd rax,DWORD PTR [r14+0x21c]
   685ae:	lea    rax,[r13+rax*8+0x0]
   685b3:	xor    ecx,ecx
   685b5:	mov    edx,0x28
   685ba:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   685c5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   685d0:	mov    QWORD PTR [rsp+0x190],rdi
   685d8:	mov    rdi,rax
   685db:	mov    rsi,rcx
   685de:	call   685e3 <sqlite3VdbeExec+0x19143>
   685e3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   685ee:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   685f9:	mov    QWORD PTR [r14+0x240],r13
   68600:	mov    rdi,QWORD PTR [rsp+0x190]
   68608:	xor    eax,eax
   6860a:	test   eax,eax
   6860c:	jne    68649 <sqlite3VdbeExec+0x191a9>
   6860e:	mov    rcx,QWORD PTR [r12+0x50]
   68613:	jmp    6861e <sqlite3VdbeExec+0x1917e>
   68615:	cmp    r14,QWORD PTR [rcx]
   68618:	je     68623 <sqlite3VdbeExec+0x19183>
   6861a:	mov    rcx,QWORD PTR [rcx+0x28]
   6861e:	test   rcx,rcx
   68621:	jne    68615 <sqlite3VdbeExec+0x19175>
   68623:	mov    rdx,QWORD PTR [r14+0x240]
   6862a:	movsxd rsi,DWORD PTR [r14+0x21c]
   68631:	lea    r8d,[rsi+0x1]
   68635:	mov    DWORD PTR [r14+0x21c],r8d
   6863c:	mov    QWORD PTR [rdx+rsi*8],rcx
   68640:	mov    edx,DWORD PTR [rcx+0x18]
   68643:	add    edx,0x1
   68646:	mov    DWORD PTR [rcx+0x18],edx
   68649:	mov    r12d,eax
   6864c:	mov    r13,r12
   6864f:	lea    r12,[rsp+0x2f8]
   68657:	mov    rax,r12
   6865a:	movzx  ecx,WORD PTR [rsp+0x30c]
   68662:	and    ecx,0x9000
   68668:	test   ecx,ecx
   6866a:	jne    68672 <sqlite3VdbeExec+0x191d2>
   6866c:	cmp    DWORD PTR [rax+0x20],0x0
   68670:	je     686b6 <sqlite3VdbeExec+0x19216>
   68672:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6867d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68688:	mov    QWORD PTR [rsp+0x190],rdi
   68690:	mov    rdi,rax
   68693:	call   68698 <sqlite3VdbeExec+0x191f8>
   68698:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   686a3:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   686ae:	mov    rdi,QWORD PTR [rsp+0x190]
   686b6:	test   r13d,r13d
   686b9:	je     686db <sqlite3VdbeExec+0x1923b>
   686bb:	mov    QWORD PTR [rsp+0x1c8],rbp
   686c3:	mov    rbp,r13
   686c6:	mov    r13,QWORD PTR [rsp+0x1b0]
   686ce:	mov    rbx,QWORD PTR [rsp+0x1d8]
   686d6:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   686db:	mov    DWORD PTR [rsp+0x3fc],r15d
   686e3:	mov    DWORD PTR [rsp+0x40c],r13d
   686eb:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   686f0:	mov    r15d,DWORD PTR [rsp+0x3fc]
   686f8:	mov    QWORD PTR [rsp+0x1b0],r12
   68700:	mov    eax,DWORD PTR [r14+0xe0]
   68707:	add    eax,0x1
   6870a:	mov    DWORD PTR [r14+0xe0],eax
   68711:	movsxd rax,DWORD PTR [rbp+0x4]
   68715:	mov    rcx,QWORD PTR [rbp+0x10]
   68719:	xor    r13d,r13d
   6871c:	mov    rdx,QWORD PTR [r14+0x20]
   68720:	shl    rax,0x5
   68724:	mov    rax,QWORD PTR [rdx+rax*1]
   68728:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68733:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6873e:	mov    QWORD PTR [rsp+0x190],rdi
   68746:	mov    rdi,r14
   68749:	mov    rsi,rcx
   6874c:	mov    rdx,rax
   6874f:	call   68754 <sqlite3VdbeExec+0x192b4>
   68754:	mov    r12,rax
   68757:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68762:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6876d:	mov    rdi,QWORD PTR [rsp+0x190]
   68775:	test   r12,r12
   68778:	je     68adb <sqlite3VdbeExec+0x1963b>
   6877e:	cmp    BYTE PTR [r12+0x3f],0x1
   68784:	jne    68adb <sqlite3VdbeExec+0x1963b>
   6878a:	cmp    QWORD PTR [r12+0x50],0x0
   68790:	je     68adb <sqlite3VdbeExec+0x1963b>
   68796:	mov    rax,QWORD PTR [r12+0x50]
   6879b:	jmp    687a1 <sqlite3VdbeExec+0x19301>
   6879d:	mov    rax,QWORD PTR [rax+0x28]
   687a1:	test   rax,rax
   687a4:	je     687be <sqlite3VdbeExec+0x1931e>
   687a6:	mov    rcx,QWORD PTR [rax+0x10]
   687aa:	cmp    DWORD PTR [rcx+0x8],0x0
   687ae:	jle    6879d <sqlite3VdbeExec+0x192fd>
   687b0:	mov    r12d,0x6
   687b6:	mov    r13,r12
   687b9:	jmp    68adb <sqlite3VdbeExec+0x1963b>
   687be:	xor    eax,eax
   687c0:	mov    rcx,QWORD PTR [r12+0x50]
   687c5:	mov    QWORD PTR [r12+0x50],0x0
   687ce:	jmp    687e5 <sqlite3VdbeExec+0x19345>
   687d0:	mov    r8,QWORD PTR [rdx+0x248]
   687d7:	mov    QWORD PTR [rcx+0x28],r8
   687db:	mov    QWORD PTR [rdx+0x248],rcx
   687e2:	mov    rcx,rsi
   687e5:	test   rcx,rcx
   687e8:	je     6880b <sqlite3VdbeExec+0x1936b>
   687ea:	mov    rdx,QWORD PTR [rcx]
   687ed:	mov    rsi,QWORD PTR [rcx+0x28]
   687f1:	cmp    rdx,r14
   687f4:	jne    687d0 <sqlite3VdbeExec+0x19330>
   687f6:	mov    QWORD PTR [r12+0x50],rcx
   687fb:	mov    QWORD PTR [rcx+0x28],0x0
   68803:	mov    rax,rcx
   68806:	mov    rcx,rsi
   68809:	jmp    687e5 <sqlite3VdbeExec+0x19345>
   6880b:	mov    r13,rax
   6880e:	mov    rax,QWORD PTR [r13+0x8]
   68812:	mov    rax,QWORD PTR [rax]
   68815:	mov    rax,QWORD PTR [rax+0x28]
   68819:	test   rax,rax
   6881c:	jne    68829 <sqlite3VdbeExec+0x19389>
   6881e:	mov    rax,QWORD PTR [r13+0x8]
   68822:	mov    rax,QWORD PTR [rax]
   68825:	mov    rax,QWORD PTR [rax+0x20]
   68829:	mov    ecx,DWORD PTR [r12+0x2c]
   6882e:	add    ecx,0x1
   68831:	mov    DWORD PTR [r12+0x2c],ecx
   68836:	mov    rcx,QWORD PTR [r13+0x10]
   6883a:	mov    DWORD PTR [rsp+0x3fc],r15d
   68842:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6884d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68858:	mov    QWORD PTR [rsp+0x190],rdi
   68860:	mov    rdi,rcx
   68863:	mov    r10,rax
   68866:	call   r10
   68869:	mov    r15d,eax
   6886c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68877:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68882:	mov    rdi,QWORD PTR [rsp+0x190]
   6888a:	test   r15d,r15d
   6888d:	je     688ac <sqlite3VdbeExec+0x1940c>
   6888f:	mov    DWORD PTR [rsp+0x424],r15d
   68897:	mov    QWORD PTR [rsp+0x1c8],rbp
   6889f:	mov    QWORD PTR [rsp+0x1e0],rbx
   688a7:	jmp    68a54 <sqlite3VdbeExec+0x195b4>
   688ac:	mov    QWORD PTR [r13+0x10],0x0
   688b4:	mov    QWORD PTR [r12+0x50],0x0
   688bd:	mov    DWORD PTR [rsp+0x424],r15d
   688c5:	mov    r15,QWORD PTR [r13+0x0]
   688c9:	mov    eax,DWORD PTR [r13+0x18]
   688cd:	sub    eax,0x1
   688d0:	mov    DWORD PTR [r13+0x18],eax
   688d4:	cmp    DWORD PTR [r13+0x18],0x0
   688d9:	je     688f0 <sqlite3VdbeExec+0x19450>
   688db:	mov    QWORD PTR [rsp+0x1c8],rbp
   688e3:	mov    QWORD PTR [rsp+0x1e0],rbx
   688eb:	jmp    68a54 <sqlite3VdbeExec+0x195b4>
   688f0:	mov    rax,QWORD PTR [r13+0x10]
   688f4:	test   rax,rax
   688f7:	je     6893d <sqlite3VdbeExec+0x1949d>
   688f9:	mov    rcx,QWORD PTR [rax]
   688fc:	mov    rcx,QWORD PTR [rcx+0x20]
   68900:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6890b:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68916:	mov    rdi,rax
   68919:	mov    r10,rcx
   6891c:	call   r10
   6891f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6892a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68935:	mov    rdi,QWORD PTR [rsp+0x190]
   6893d:	mov    QWORD PTR [rsp+0x1e0],rbx
   68945:	mov    rbx,QWORD PTR [r13+0x0]
   68949:	mov    QWORD PTR [rsp+0x1c8],rbp
   68951:	mov    rbp,QWORD PTR [r13+0x8]
   68955:	mov    eax,DWORD PTR [rbp+0x10]
   68958:	sub    eax,0x1
   6895b:	mov    DWORD PTR [rbp+0x10],eax
   6895e:	cmp    DWORD PTR [rbp+0x10],0x0
   68962:	jne    68a08 <sqlite3VdbeExec+0x19568>
   68968:	cmp    QWORD PTR [rbp+0x20],0x0
   6896d:	je     689bc <sqlite3VdbeExec+0x1951c>
   6896f:	mov    rax,QWORD PTR [rbp+0x20]
   68973:	mov    rcx,QWORD PTR [rbp+0x18]
   68977:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68982:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6898d:	mov    QWORD PTR [rsp+0x190],rdi
   68995:	mov    rdi,rcx
   68998:	mov    r10,rax
   6899b:	call   r10
   6899e:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   689a9:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   689b4:	mov    rdi,QWORD PTR [rsp+0x190]
   689bc:	test   rbp,rbp
   689bf:	je     68a08 <sqlite3VdbeExec+0x19568>
   689c1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   689cc:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   689d7:	mov    QWORD PTR [rsp+0x190],rdi
   689df:	mov    rdi,rbx
   689e2:	mov    rsi,rbp
   689e5:	call   689ea <sqlite3VdbeExec+0x1954a>
   689ea:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   689f5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68a00:	mov    rdi,QWORD PTR [rsp+0x190]
   68a08:	test   r13,r13
   68a0b:	je     68a54 <sqlite3VdbeExec+0x195b4>
   68a0d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68a18:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68a23:	mov    QWORD PTR [rsp+0x190],rdi
   68a2b:	mov    rdi,r15
   68a2e:	mov    rsi,r13
   68a31:	call   68a36 <sqlite3VdbeExec+0x19596>
   68a36:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68a41:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68a4c:	mov    rdi,QWORD PTR [rsp+0x190]
   68a54:	test   r12,r12
   68a57:	je     68abb <sqlite3VdbeExec+0x1961b>
   68a59:	cmp    QWORD PTR [r14+0x300],0x0
   68a61:	jne    68a74 <sqlite3VdbeExec+0x195d4>
   68a63:	mov    eax,DWORD PTR [r12+0x2c]
   68a68:	sub    eax,0x1
   68a6b:	mov    DWORD PTR [r12+0x2c],eax
   68a70:	test   eax,eax
   68a72:	ja     68abb <sqlite3VdbeExec+0x1961b>
   68a74:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68a7f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68a8a:	mov    QWORD PTR [rsp+0x190],rdi
   68a92:	mov    rdi,r14
   68a95:	mov    rsi,r12
   68a98:	call   68a9d <sqlite3VdbeExec+0x195fd>
   68a9d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68aa8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68ab3:	mov    rdi,QWORD PTR [rsp+0x190]
   68abb:	mov    r15d,DWORD PTR [rsp+0x3fc]
   68ac3:	mov    rbp,QWORD PTR [rsp+0x1c8]
   68acb:	mov    rbx,QWORD PTR [rsp+0x1e0]
   68ad3:	mov    r13d,DWORD PTR [rsp+0x424]
   68adb:	mov    eax,DWORD PTR [r14+0xe0]
   68ae2:	sub    eax,0x1
   68ae5:	mov    DWORD PTR [r14+0xe0],eax
   68aec:	test   r13d,r13d
   68aef:	je     68b11 <sqlite3VdbeExec+0x19671>
   68af1:	mov    QWORD PTR [rsp+0x1c8],rbp
   68af9:	mov    rbp,r13
   68afc:	mov    r13,QWORD PTR [rsp+0x1b0]
   68b04:	mov    rbx,QWORD PTR [rsp+0x1d8]
   68b0c:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   68b11:	mov    DWORD PTR [rsp+0x3fc],r15d
   68b19:	mov    DWORD PTR [rsp+0x40c],r13d
   68b21:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   68b26:	mov    r15d,DWORD PTR [rsp+0x3fc]
   68b2e:	mov    r13,QWORD PTR [rsp+0x1d0]
   68b36:	mov    QWORD PTR [rsp+0x1b0],r12
   68b3e:	mov    r12d,DWORD PTR [rsp+0x414]
   68b46:	mov    rax,QWORD PTR [rdi+0x78]
   68b4a:	movsxd rcx,DWORD PTR [rbp+0x4]
   68b4e:	mov    rax,QWORD PTR [rax+rcx*8]
   68b52:	test   rax,rax
   68b55:	je     68b8a <sqlite3VdbeExec+0x196ea>
   68b57:	cmp    BYTE PTR [rax],0x2
   68b5a:	jne    68b8a <sqlite3VdbeExec+0x196ea>
   68b5c:	mov    rax,QWORD PTR [rax+0x28]
   68b60:	mov    rax,QWORD PTR [rax]
   68b63:	mov    rcx,QWORD PTR [rbp+0x10]
   68b67:	cmp    rax,QWORD PTR [rcx+0x10]
   68b6b:	jne    68b8a <sqlite3VdbeExec+0x196ea>
   68b6d:	mov    DWORD PTR [rsp+0x3fc],r15d
   68b75:	mov    QWORD PTR [rsp+0x1d0],r13
   68b7d:	mov    DWORD PTR [rsp+0x414],r12d
   68b85:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   68b8a:	mov    QWORD PTR [rsp+0x1e8],0x0
   68b96:	mov    rax,QWORD PTR [rbp+0x10]
   68b9a:	mov    QWORD PTR [rsp+0x1d0],r13
   68ba2:	mov    r13,QWORD PTR [rax+0x10]
   68ba6:	test   r13,r13
   68ba9:	je     68bb2 <sqlite3VdbeExec+0x19712>
   68bab:	cmp    QWORD PTR [r13+0x0],0x0
   68bb0:	jne    68bd7 <sqlite3VdbeExec+0x19737>
   68bb2:	mov    ebx,0x6
   68bb7:	mov    QWORD PTR [rsp+0x1c8],rbp
   68bbf:	mov    rbp,rbx
   68bc2:	mov    r13,QWORD PTR [rsp+0x1b0]
   68bca:	mov    rbx,QWORD PTR [rsp+0x1d8]
   68bd2:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   68bd7:	mov    DWORD PTR [rsp+0x414],r12d
   68bdf:	mov    r12,QWORD PTR [r13+0x0]
   68be3:	mov    rax,QWORD PTR [r12+0x30]
   68be8:	mov    QWORD PTR [rsp+0x200],r12
   68bf0:	lea    r12,[rsp+0x1e8]
   68bf8:	mov    rcx,r12
   68bfb:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68c06:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68c11:	mov    QWORD PTR [rsp+0x190],rdi
   68c19:	mov    rdi,r13
   68c1c:	mov    rsi,rcx
   68c1f:	mov    r10,rax
   68c22:	call   r10
   68c25:	mov    r12d,eax
   68c28:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68c33:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68c3e:	mov    rdi,QWORD PTR [rsp+0x190]
   68c46:	cmp    QWORD PTR [r13+0x10],0x0
   68c4b:	jne    68c5a <sqlite3VdbeExec+0x197ba>
   68c4d:	mov    DWORD PTR [rsp+0x424],r12d
   68c55:	jmp    68f47 <sqlite3VdbeExec+0x19aa7>
   68c5a:	mov    DWORD PTR [rsp+0x424],r12d
   68c62:	mov    r12,QWORD PTR [rdi]
   68c65:	mov    rax,QWORD PTR [rdi+0xa8]
   68c6c:	test   rax,rax
   68c6f:	je     68cb0 <sqlite3VdbeExec+0x19810>
   68c71:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68c7c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68c87:	mov    rdi,r12
   68c8a:	mov    rsi,rax
   68c8d:	call   68c92 <sqlite3VdbeExec+0x197f2>
   68c92:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68c9d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68ca8:	mov    rdi,QWORD PTR [rsp+0x190]
   68cb0:	mov    QWORD PTR [rsp+0x210],r13
   68cb8:	mov    r13,QWORD PTR [r13+0x10]
   68cbc:	test   r13,r13
   68cbf:	jne    68cd1 <sqlite3VdbeExec+0x19831>
   68cc1:	xor    r12d,r12d
   68cc4:	mov    r13,QWORD PTR [rsp+0x210]
   68ccc:	jmp    68e22 <sqlite3VdbeExec+0x19982>
   68cd1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68cdc:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68ce7:	mov    QWORD PTR [rsp+0x190],rdi
   68cef:	mov    rdi,r13
   68cf2:	call   68cf7 <sqlite3VdbeExec+0x19857>
   68cf7:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68d02:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68d0d:	mov    QWORD PTR [rsp+0x208],r13
   68d15:	lea    r13,[rax+0x1]
   68d19:	mov    rdi,QWORD PTR [rsp+0x190]
   68d21:	test   r12,r12
   68d24:	je     68d6a <sqlite3VdbeExec+0x198ca>
   68d26:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68d31:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68d3c:	mov    rdi,r12
   68d3f:	mov    rsi,r13
   68d42:	call   68d47 <sqlite3VdbeExec+0x198a7>
   68d47:	mov    r12,rax
   68d4a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68d55:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68d60:	mov    rdi,QWORD PTR [rsp+0x190]
   68d68:	jmp    68da9 <sqlite3VdbeExec+0x19909>
   68d6a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68d75:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68d80:	mov    rdi,r13
   68d83:	call   68d88 <sqlite3VdbeExec+0x198e8>
   68d88:	mov    r12,rax
   68d8b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68d96:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68da1:	mov    rdi,QWORD PTR [rsp+0x190]
   68da9:	test   r12,r12
   68dac:	jne    68db8 <sqlite3VdbeExec+0x19918>
   68dae:	mov    DWORD PTR [rsp+0x3fc],r15d
   68db6:	jmp    68e12 <sqlite3VdbeExec+0x19972>
   68db8:	mov    DWORD PTR [rsp+0x3fc],r15d
   68dc0:	mov    r15,QWORD PTR [rsp+0x208]
   68dc8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68dd3:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68dde:	mov    QWORD PTR [rsp+0x190],rdi
   68de6:	mov    rdi,r12
   68de9:	mov    rsi,r15
   68dec:	mov    rdx,r13
   68def:	call   68df4 <sqlite3VdbeExec+0x19954>
   68df4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68dff:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68e0a:	mov    rdi,QWORD PTR [rsp+0x190]
   68e12:	mov    r15d,DWORD PTR [rsp+0x3fc]
   68e1a:	mov    r13,QWORD PTR [rsp+0x210]
   68e22:	mov    QWORD PTR [rdi+0xa8],r12
   68e29:	mov    r12,QWORD PTR [r13+0x10]
   68e2d:	test   r12,r12
   68e30:	je     68f3f <sqlite3VdbeExec+0x19a9f>
   68e36:	cmp    DWORD PTR [rip+0x0],0x0        # 68e3d <sqlite3VdbeExec+0x1999d>
   68e3d:	je     68ef3 <sqlite3VdbeExec+0x19a53>
   68e43:	mov    rax,QWORD PTR [rip+0x0]        # 68e4a <sqlite3VdbeExec+0x199aa>
   68e4a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68e55:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68e60:	mov    QWORD PTR [rsp+0x190],rdi
   68e68:	mov    rdi,r12
   68e6b:	mov    r10,rax
   68e6e:	call   r10
   68e71:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68e7c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68e87:	mov    rcx,QWORD PTR [rip+0x0]        # 68e8e <sqlite3VdbeExec+0x199ee>
   68e8e:	movsxd rax,eax
   68e91:	sub    rcx,rax
   68e94:	mov    QWORD PTR [rip+0x0],rcx        # 68e9b <sqlite3VdbeExec+0x199fb>
   68e9b:	mov    rax,QWORD PTR [rip+0x0]        # 68ea2 <sqlite3VdbeExec+0x19a02>
   68ea2:	sub    rax,0x1
   68ea6:	mov    QWORD PTR [rip+0x0],rax        # 68ead <sqlite3VdbeExec+0x19a0d>
   68ead:	mov    rax,QWORD PTR [rip+0x0]        # 68eb4 <sqlite3VdbeExec+0x19a14>
   68eb4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68ebf:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68eca:	mov    rdi,r12
   68ecd:	mov    r10,rax
   68ed0:	call   r10
   68ed3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68ede:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68ee9:	mov    rdi,QWORD PTR [rsp+0x190]
   68ef1:	jmp    68f3f <sqlite3VdbeExec+0x19a9f>
   68ef3:	mov    rax,QWORD PTR [rip+0x0]        # 68efa <sqlite3VdbeExec+0x19a5a>
   68efa:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68f05:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68f10:	mov    QWORD PTR [rsp+0x190],rdi
   68f18:	mov    rdi,r12
   68f1b:	mov    r10,rax
   68f1e:	call   r10
   68f21:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68f2c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68f37:	mov    rdi,QWORD PTR [rsp+0x190]
   68f3f:	mov    QWORD PTR [r13+0x10],0x0
   68f47:	mov    r12d,DWORD PTR [rsp+0x424]
   68f4f:	test   r12d,r12d
   68f52:	je     68f74 <sqlite3VdbeExec+0x19ad4>
   68f54:	mov    QWORD PTR [rsp+0x1c8],rbp
   68f5c:	mov    rbp,r12
   68f5f:	mov    r13,QWORD PTR [rsp+0x1b0]
   68f67:	mov    rbx,QWORD PTR [rsp+0x1d8]
   68f6f:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   68f74:	mov    rax,QWORD PTR [rsp+0x1e8]
   68f7c:	mov    QWORD PTR [rax],r13
   68f7f:	mov    eax,DWORD PTR [rbp+0x4]
   68f82:	xor    ecx,ecx
   68f84:	mov    edx,0x2
   68f89:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   68f94:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   68f9f:	mov    QWORD PTR [rsp+0x190],rdi
   68fa7:	mov    rsi,rax
   68faa:	mov    r11,rdx
   68fad:	mov    rdx,rcx
   68fb0:	mov    rcx,r11
   68fb3:	call   68fb8 <sqlite3VdbeExec+0x19b18>
   68fb8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   68fc3:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   68fce:	mov    rdi,QWORD PTR [rsp+0x190]
   68fd6:	test   rax,rax
   68fd9:	je     69007 <sqlite3VdbeExec+0x19b67>
   68fdb:	mov    rcx,QWORD PTR [rsp+0x1e8]
   68fe3:	mov    QWORD PTR [rax+0x28],rcx
   68fe7:	mov    eax,DWORD PTR [r13+0x8]
   68feb:	add    eax,0x1
   68fee:	mov    DWORD PTR [r13+0x8],eax
   68ff2:	mov    DWORD PTR [rsp+0x3fc],r15d
   68ffa:	mov    DWORD PTR [rsp+0x40c],r12d
   69002:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   69007:	mov    r12,QWORD PTR [rsp+0x200]
   6900f:	mov    rax,QWORD PTR [r12+0x38]
   69014:	mov    rcx,QWORD PTR [rsp+0x1e8]
   6901c:	mov    rdi,rcx
   6901f:	mov    r10,rax
   69022:	call   r10
   69025:	mov    rdi,QWORD PTR [rsp+0x190]
   6902d:	mov    r13,QWORD PTR [rsp+0x1d0]
   69035:	mov    rbx,rbp
   69038:	mov    rbp,QWORD PTR [rsp+0x1d8]
   69040:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   69045:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6904d:	mov    r13,QWORD PTR [rsp+0x1d0]
   69055:	mov    QWORD PTR [rsp+0x1b0],r12
   6905d:	mov    r12d,DWORD PTR [rsp+0x414]
   69065:	mov    QWORD PTR [rsp+0x1e8],0x0
   69071:	movsxd rax,DWORD PTR [rbp+0x8]
   69075:	imul   rax,rax,0x38
   69079:	mov    DWORD PTR [rsp+0x414],r12d
   69081:	lea    r12,[rbx+rax*1]
   69085:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   6908a:	and    eax,0x9000
   6908f:	test   eax,eax
   69091:	je     690d9 <sqlite3VdbeExec+0x19c39>
   69093:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6909e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   690a9:	mov    QWORD PTR [rsp+0x190],rdi
   690b1:	mov    rdi,r12
   690b4:	call   690b9 <sqlite3VdbeExec+0x19c19>
   690b9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   690c4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   690cf:	mov    rdi,QWORD PTR [rsp+0x190]
   690d7:	jmp    690e1 <sqlite3VdbeExec+0x19c41>
   690d9:	mov    WORD PTR [r12+0x14],0x1
   690e1:	mov    QWORD PTR [rsp+0x1d0],r13
   690e9:	mov    r13,QWORD PTR [rbp+0x10]
   690ed:	cmp    QWORD PTR [r13+0x50],0x0
   690f2:	jne    69101 <sqlite3VdbeExec+0x19c61>
   690f4:	mov    DWORD PTR [rsp+0x3fc],r15d
   690fc:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   69101:	mov    rax,QWORD PTR [r13+0x50]
   69105:	mov    rax,QWORD PTR [rax+0x10]
   69109:	mov    rcx,QWORD PTR [rax]
   6910c:	mov    rdx,QWORD PTR [r13+0x50]
   69110:	mov    esi,DWORD PTR [rdx+0x18]
   69113:	add    esi,0x1
   69116:	mov    DWORD PTR [rdx+0x18],esi
   69119:	mov    rcx,QWORD PTR [rcx+0xc0]
   69120:	mov    rdx,QWORD PTR [r14+0x20]
   69124:	movsxd rsi,DWORD PTR [rbp+0x4]
   69128:	shl    rsi,0x5
   6912c:	mov    rdx,QWORD PTR [rdx+rsi*1]
   69130:	mov    rsi,QWORD PTR [r13+0x0]
   69134:	mov    r8d,DWORD PTR [rbp+0xc]
   69138:	mov    QWORD PTR [rsp+0x1a8],r14
   69140:	lea    r14,[rsp+0x1e8]
   69148:	mov    r9,r14
   6914b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69156:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69161:	mov    QWORD PTR [rsp+0x190],rdi
   69169:	mov    rdi,rax
   6916c:	mov    r10,rcx
   6916f:	mov    rcx,r8
   69172:	mov    r8,r9
   69175:	mov    r11,rsi
   69178:	mov    rsi,rdx
   6917b:	mov    rdx,r11
   6917e:	call   r10
   69181:	mov    r14d,eax
   69184:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6918f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6919a:	mov    r13,QWORD PTR [r13+0x50]
   6919e:	mov    QWORD PTR [rsp+0x1c8],rbp
   691a6:	mov    rbp,QWORD PTR [r13+0x0]
   691aa:	mov    eax,DWORD PTR [r13+0x18]
   691ae:	sub    eax,0x1
   691b1:	mov    DWORD PTR [r13+0x18],eax
   691b5:	mov    rdi,QWORD PTR [rsp+0x190]
   691bd:	cmp    DWORD PTR [r13+0x18],0x0
   691c2:	je     691d9 <sqlite3VdbeExec+0x19d39>
   691c4:	mov    DWORD PTR [rsp+0x3fc],r15d
   691cc:	mov    QWORD PTR [rsp+0x200],r12
   691d4:	jmp    69340 <sqlite3VdbeExec+0x19ea0>
   691d9:	mov    rax,QWORD PTR [r13+0x10]
   691dd:	test   rax,rax
   691e0:	je     69226 <sqlite3VdbeExec+0x19d86>
   691e2:	mov    rcx,QWORD PTR [rax]
   691e5:	mov    rcx,QWORD PTR [rcx+0x20]
   691e9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   691f4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   691ff:	mov    rdi,rax
   69202:	mov    r10,rcx
   69205:	call   r10
   69208:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69213:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6921e:	mov    rdi,QWORD PTR [rsp+0x190]
   69226:	mov    QWORD PTR [rsp+0x200],r12
   6922e:	mov    r12,QWORD PTR [r13+0x0]
   69232:	mov    DWORD PTR [rsp+0x3fc],r15d
   6923a:	mov    r15,QWORD PTR [r13+0x8]
   6923e:	mov    eax,DWORD PTR [r15+0x10]
   69242:	sub    eax,0x1
   69245:	mov    DWORD PTR [r15+0x10],eax
   69249:	cmp    DWORD PTR [r15+0x10],0x0
   6924e:	jne    692f4 <sqlite3VdbeExec+0x19e54>
   69254:	cmp    QWORD PTR [r15+0x20],0x0
   69259:	je     692a8 <sqlite3VdbeExec+0x19e08>
   6925b:	mov    rax,QWORD PTR [r15+0x20]
   6925f:	mov    rcx,QWORD PTR [r15+0x18]
   69263:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6926e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69279:	mov    QWORD PTR [rsp+0x190],rdi
   69281:	mov    rdi,rcx
   69284:	mov    r10,rax
   69287:	call   r10
   6928a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69295:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   692a0:	mov    rdi,QWORD PTR [rsp+0x190]
   692a8:	test   r15,r15
   692ab:	je     692f4 <sqlite3VdbeExec+0x19e54>
   692ad:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   692b8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   692c3:	mov    QWORD PTR [rsp+0x190],rdi
   692cb:	mov    rdi,r12
   692ce:	mov    rsi,r15
   692d1:	call   692d6 <sqlite3VdbeExec+0x19e36>
   692d6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   692e1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   692ec:	mov    rdi,QWORD PTR [rsp+0x190]
   692f4:	test   r13,r13
   692f7:	je     69340 <sqlite3VdbeExec+0x19ea0>
   692f9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69304:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6930f:	mov    QWORD PTR [rsp+0x190],rdi
   69317:	mov    rdi,rbp
   6931a:	mov    rsi,r13
   6931d:	call   69322 <sqlite3VdbeExec+0x19e82>
   69322:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6932d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69338:	mov    rdi,QWORD PTR [rsp+0x190]
   69340:	test   r14d,r14d
   69343:	je     693fb <sqlite3VdbeExec+0x19f5b>
   69349:	mov    rbx,QWORD PTR [rsp+0x1e8]
   69351:	test   rbx,rbx
   69354:	je     693db <sqlite3VdbeExec+0x19f3b>
   6935a:	cmp    DWORD PTR [rip+0x0],0x0        # 69361 <sqlite3VdbeExec+0x19ec1>
   69361:	je     693bb <sqlite3VdbeExec+0x19f1b>
   69363:	mov    rax,QWORD PTR [rip+0x0]        # 6936a <sqlite3VdbeExec+0x19eca>
   6936a:	mov    QWORD PTR [rsp+0x190],rdi
   69372:	mov    rdi,rbx
   69375:	mov    r10,rax
   69378:	call   r10
   6937b:	mov    rcx,QWORD PTR [rip+0x0]        # 69382 <sqlite3VdbeExec+0x19ee2>
   69382:	movsxd rax,eax
   69385:	sub    rcx,rax
   69388:	mov    QWORD PTR [rip+0x0],rcx        # 6938f <sqlite3VdbeExec+0x19eef>
   6938f:	mov    rax,QWORD PTR [rip+0x0]        # 69396 <sqlite3VdbeExec+0x19ef6>
   69396:	sub    rax,0x1
   6939a:	mov    QWORD PTR [rip+0x0],rax        # 693a1 <sqlite3VdbeExec+0x19f01>
   693a1:	mov    rax,QWORD PTR [rip+0x0]        # 693a8 <sqlite3VdbeExec+0x19f08>
   693a8:	mov    rdi,rbx
   693ab:	mov    r10,rax
   693ae:	call   r10
   693b1:	mov    rdi,QWORD PTR [rsp+0x190]
   693b9:	jmp    693db <sqlite3VdbeExec+0x19f3b>
   693bb:	mov    rax,QWORD PTR [rip+0x0]        # 693c2 <sqlite3VdbeExec+0x19f22>
   693c2:	mov    QWORD PTR [rsp+0x190],rdi
   693ca:	mov    rdi,rbx
   693cd:	mov    r10,rax
   693d0:	call   r10
   693d3:	mov    rdi,QWORD PTR [rsp+0x190]
   693db:	mov    rbp,r14
   693de:	mov    r14,QWORD PTR [rsp+0x1a8]
   693e6:	mov    r13,QWORD PTR [rsp+0x1b0]
   693ee:	mov    rbx,QWORD PTR [rsp+0x1d8]
   693f6:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   693fb:	mov    r12,QWORD PTR [rsp+0x200]
   69403:	cmp    QWORD PTR [rsp+0x1e8],0x0
   6940c:	je     69479 <sqlite3VdbeExec+0x19fd9>
   6940e:	mov    rax,QWORD PTR [rsp+0x1e8]
   69416:	mov    rcx,0xffffffffffffffff
   6941d:	lea    rdx,[rip+0x0]        # 69424 <sqlite3VdbeExec+0x19f84>
   69424:	mov    esi,0x1
   69429:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69434:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6943f:	mov    QWORD PTR [rsp+0x190],rdi
   69447:	mov    rdi,r12
   6944a:	mov    r8,rdx
   6944d:	mov    rdx,rcx
   69450:	mov    rcx,rsi
   69453:	mov    rsi,rax
   69456:	call   6945b <sqlite3VdbeExec+0x19fbb>
   6945b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69466:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69471:	mov    rdi,QWORD PTR [rsp+0x190]
   69479:	mov    rbp,QWORD PTR [rsp+0x1c8]
   69481:	mov    DWORD PTR [rsp+0x40c],r14d
   69489:	mov    r14,QWORD PTR [rsp+0x1a8]
   69491:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   69496:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6949e:	mov    r13,QWORD PTR [rsp+0x1d0]
   694a6:	mov    QWORD PTR [rsp+0x1b0],r12
   694ae:	mov    r12d,DWORD PTR [rsp+0x414]
   694b6:	mov    rax,QWORD PTR [rdi+0x78]
   694ba:	movsxd rcx,DWORD PTR [rbp+0x4]
   694be:	mov    DWORD PTR [rsp+0x414],r12d
   694c6:	mov    r12,QWORD PTR [rax+rcx*8]
   694ca:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   694d5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   694e0:	mov    QWORD PTR [rsp+0x190],rdi
   694e8:	call   694ed <sqlite3VdbeExec+0x1a04d>
   694ed:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   694f8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69503:	mov    rdi,QWORD PTR [rsp+0x190]
   6950b:	test   eax,eax
   6950d:	je     6951e <sqlite3VdbeExec+0x1a07e>
   6950f:	mov    QWORD PTR [rsp+0x1d0],r13
   69517:	mov    r13,rbx
   6951a:	xor    ebx,ebx
   6951c:	jmp    69580 <sqlite3VdbeExec+0x1a0e0>
   6951e:	mov    QWORD PTR [rsp+0x1e8],r12
   69526:	mov    r12,rbx
   69529:	mov    ebx,0x10
   6952e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69539:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69544:	mov    rdi,rbx
   69547:	call   6954c <sqlite3VdbeExec+0x1a0ac>
   6954c:	mov    rbx,rax
   6954f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6955a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69565:	mov    rdi,QWORD PTR [rsp+0x190]
   6956d:	mov    QWORD PTR [rsp+0x1d0],r13
   69575:	mov    r13,r12
   69578:	mov    r12,QWORD PTR [rsp+0x1e8]
   69580:	test   rbx,rbx
   69583:	jne    6959d <sqlite3VdbeExec+0x1a0fd>
   69585:	mov    r13,QWORD PTR [rsp+0x1d0]
   6958d:	mov    rbx,rbp
   69590:	mov    rbp,QWORD PTR [rsp+0x1d8]
   69598:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   6959d:	mov    rax,QWORD PTR [r12+0x28]
   695a2:	mov    QWORD PTR [rbx],rax
   695a5:	movsxd rax,DWORD PTR [rbp+0xc]
   695a9:	imul   rax,rax,0x38
   695ad:	add    rax,r13
   695b0:	mov    QWORD PTR [rbx+0x8],rax
   695b4:	mov    rax,QWORD PTR [rdi+0x68]
   695b8:	movsxd rcx,DWORD PTR [rbp+0x8]
   695bc:	imul   rcx,rcx,0x38
   695c0:	lea    r12,[rax+rcx*1]
   695c4:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   695c9:	and    eax,0x9000
   695ce:	test   eax,eax
   695d0:	je     6961b <sqlite3VdbeExec+0x1a17b>
   695d2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   695dd:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   695e8:	mov    QWORD PTR [rsp+0x190],rdi
   695f0:	mov    rdi,r12
   695f3:	call   695f8 <sqlite3VdbeExec+0x1a158>
   695f8:	mov    r12,rax
   695fb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69606:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69611:	mov    rdi,QWORD PTR [rsp+0x190]
   69619:	jmp    69623 <sqlite3VdbeExec+0x1a183>
   6961b:	mov    WORD PTR [r12+0x14],0x4
   69623:	mov    WORD PTR [r12+0x14],0x1
   6962b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69636:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69641:	mov    QWORD PTR [rsp+0x190],rdi
   69649:	mov    rdi,r12
   6964c:	call   69651 <sqlite3VdbeExec+0x1a1b1>
   69651:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6965c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69667:	lea    rax,[rip+0x0]        # 6966e <sqlite3VdbeExec+0x1a1ce>
   6966e:	mov    DWORD PTR [rsp+0x3fc],r15d
   69676:	lea    r15,[rip+0x0]        # 6967d <sqlite3VdbeExec+0x1a1dd>
   6967d:	test   r15,r15
   69680:	cmovne rax,r15
   69684:	mov    QWORD PTR [r12],rax
   69688:	mov    QWORD PTR [r12+0x8],rbx
   6968d:	mov    WORD PTR [r12+0x14],0x1a01
   69695:	mov    BYTE PTR [r12+0x17],0x70
   6969b:	lea    rax,[rip+0x0]        # 696a2 <sqlite3VdbeExec+0x1a202>
   696a2:	lea    rbx,[rip+0x0]        # 696a9 <sqlite3VdbeExec+0x1a209>
   696a9:	test   rbx,rbx
   696ac:	cmovne rax,rbx
   696b0:	mov    QWORD PTR [r12+0x30],rax
   696b5:	mov    rdi,QWORD PTR [rsp+0x190]
   696bd:	mov    rbx,r13
   696c0:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   696c5:	mov    r13,rbx
   696c8:	mov    QWORD PTR [rsp+0x1b0],r12
   696d0:	movsxd rax,DWORD PTR [rbp+0xc]
   696d4:	imul   rax,rax,0x38
   696d8:	lea    rcx,[r13+rax*1+0x0]
   696dd:	add    rcx,0x38
   696e1:	mov    rdx,QWORD PTR [rdi+0x78]
   696e5:	movsxd rsi,DWORD PTR [rbp+0x4]
   696e9:	mov    rbx,QWORD PTR [rdx+rsi*8]
   696ed:	mov    r12,QWORD PTR [rbx+0x28]
   696f1:	mov    r15,QWORD PTR [r12]
   696f5:	mov    QWORD PTR [rsp+0x1e8],rbx
   696fd:	mov    rbx,QWORD PTR [r15]
   69700:	mov    rdx,QWORD PTR [r13+rax*1+0x38]
   69705:	mov    rax,QWORD PTR [r13+rax*1+0x0]
   6970a:	mov    rsi,QWORD PTR [rdi+0x70]
   6970e:	xor    r8d,r8d
   69711:	jmp    6972c <sqlite3VdbeExec+0x1a28c>
   69713:	mov    r9,r8
   69716:	lea    r10d,[r8+0x1]
   6971a:	movsxd r10,r10d
   6971d:	imul   r10,r10,0x38
   69721:	add    r10,rcx
   69724:	mov    QWORD PTR [rsi+r9*8],r10
   69728:	add    r8d,0x1
   6972c:	cmp    r8d,edx
   6972f:	jl     69713 <sqlite3VdbeExec+0x1a273>
   69731:	mov    rcx,QWORD PTR [rbx+0x40]
   69735:	mov    r8,QWORD PTR [rbp+0x10]
   69739:	mov    QWORD PTR [rsp+0x208],rbx
   69741:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6974c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69757:	mov    QWORD PTR [rsp+0x190],rdi
   6975f:	mov    rdi,r12
   69762:	mov    r10,rcx
   69765:	mov    rcx,rdx
   69768:	mov    rdx,r8
   6976b:	mov    r8,rsi
   6976e:	mov    rsi,rax
   69771:	call   r10
   69774:	mov    ebx,eax
   69776:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69781:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6978c:	mov    rdi,QWORD PTR [rsp+0x190]
   69794:	cmp    QWORD PTR [r15+0x10],0x0
   69799:	jne    697af <sqlite3VdbeExec+0x1a30f>
   6979b:	mov    QWORD PTR [rsp+0x200],r12
   697a3:	mov    DWORD PTR [rsp+0x424],ebx
   697aa:	jmp    69a8a <sqlite3VdbeExec+0x1a5ea>
   697af:	mov    DWORD PTR [rsp+0x424],ebx
   697b6:	mov    rbx,QWORD PTR [rdi]
   697b9:	mov    rax,QWORD PTR [rdi+0xa8]
   697c0:	test   rax,rax
   697c3:	je     69804 <sqlite3VdbeExec+0x1a364>
   697c5:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   697d0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   697db:	mov    rdi,rbx
   697de:	mov    rsi,rax
   697e1:	call   697e6 <sqlite3VdbeExec+0x1a346>
   697e6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   697f1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   697fc:	mov    rdi,QWORD PTR [rsp+0x190]
   69804:	mov    QWORD PTR [rsp+0x200],r12
   6980c:	mov    r12,QWORD PTR [r15+0x10]
   69810:	test   r12,r12
   69813:	jne    6981c <sqlite3VdbeExec+0x1a37c>
   69815:	xor    ebx,ebx
   69817:	jmp    69965 <sqlite3VdbeExec+0x1a4c5>
   6981c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69827:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69832:	mov    QWORD PTR [rsp+0x190],rdi
   6983a:	mov    rdi,r12
   6983d:	call   69842 <sqlite3VdbeExec+0x1a3a2>
   69842:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6984d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69858:	mov    QWORD PTR [rsp+0x240],r12
   69860:	lea    r12,[rax+0x1]
   69864:	mov    rdi,QWORD PTR [rsp+0x190]
   6986c:	test   rbx,rbx
   6986f:	je     698b5 <sqlite3VdbeExec+0x1a415>
   69871:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6987c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69887:	mov    rdi,rbx
   6988a:	mov    rsi,r12
   6988d:	call   69892 <sqlite3VdbeExec+0x1a3f2>
   69892:	mov    rbx,rax
   69895:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   698a0:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   698ab:	mov    rdi,QWORD PTR [rsp+0x190]
   698b3:	jmp    698f4 <sqlite3VdbeExec+0x1a454>
   698b5:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   698c0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   698cb:	mov    rdi,r12
   698ce:	call   698d3 <sqlite3VdbeExec+0x1a433>
   698d3:	mov    rbx,rax
   698d6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   698e1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   698ec:	mov    rdi,QWORD PTR [rsp+0x190]
   698f4:	test   rbx,rbx
   698f7:	jne    69903 <sqlite3VdbeExec+0x1a463>
   698f9:	mov    QWORD PTR [rsp+0x210],r15
   69901:	jmp    6995d <sqlite3VdbeExec+0x1a4bd>
   69903:	mov    QWORD PTR [rsp+0x210],r15
   6990b:	mov    r15,QWORD PTR [rsp+0x240]
   69913:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6991e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69929:	mov    QWORD PTR [rsp+0x190],rdi
   69931:	mov    rdi,rbx
   69934:	mov    rsi,r15
   69937:	mov    rdx,r12
   6993a:	call   6993f <sqlite3VdbeExec+0x1a49f>
   6993f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6994a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69955:	mov    rdi,QWORD PTR [rsp+0x190]
   6995d:	mov    r15,QWORD PTR [rsp+0x210]
   69965:	mov    QWORD PTR [rdi+0xa8],rbx
   6996c:	mov    rbx,QWORD PTR [r15+0x10]
   69970:	test   rbx,rbx
   69973:	je     69a82 <sqlite3VdbeExec+0x1a5e2>
   69979:	cmp    DWORD PTR [rip+0x0],0x0        # 69980 <sqlite3VdbeExec+0x1a4e0>
   69980:	je     69a36 <sqlite3VdbeExec+0x1a596>
   69986:	mov    rax,QWORD PTR [rip+0x0]        # 6998d <sqlite3VdbeExec+0x1a4ed>
   6998d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69998:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   699a3:	mov    QWORD PTR [rsp+0x190],rdi
   699ab:	mov    rdi,rbx
   699ae:	mov    r10,rax
   699b1:	call   r10
   699b4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   699bf:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   699ca:	mov    rcx,QWORD PTR [rip+0x0]        # 699d1 <sqlite3VdbeExec+0x1a531>
   699d1:	movsxd rax,eax
   699d4:	sub    rcx,rax
   699d7:	mov    QWORD PTR [rip+0x0],rcx        # 699de <sqlite3VdbeExec+0x1a53e>
   699de:	mov    rax,QWORD PTR [rip+0x0]        # 699e5 <sqlite3VdbeExec+0x1a545>
   699e5:	sub    rax,0x1
   699e9:	mov    QWORD PTR [rip+0x0],rax        # 699f0 <sqlite3VdbeExec+0x1a550>
   699f0:	mov    rax,QWORD PTR [rip+0x0]        # 699f7 <sqlite3VdbeExec+0x1a557>
   699f7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69a02:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69a0d:	mov    rdi,rbx
   69a10:	mov    r10,rax
   69a13:	call   r10
   69a16:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69a21:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69a2c:	mov    rdi,QWORD PTR [rsp+0x190]
   69a34:	jmp    69a82 <sqlite3VdbeExec+0x1a5e2>
   69a36:	mov    rax,QWORD PTR [rip+0x0]        # 69a3d <sqlite3VdbeExec+0x1a59d>
   69a3d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69a48:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69a53:	mov    QWORD PTR [rsp+0x190],rdi
   69a5b:	mov    rdi,rbx
   69a5e:	mov    r10,rax
   69a61:	call   r10
   69a64:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69a6f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69a7a:	mov    rdi,QWORD PTR [rsp+0x190]
   69a82:	mov    QWORD PTR [r15+0x10],0x0
   69a8a:	mov    ebx,DWORD PTR [rsp+0x424]
   69a91:	test   ebx,ebx
   69a93:	je     69ab5 <sqlite3VdbeExec+0x1a615>
   69a95:	mov    QWORD PTR [rsp+0x1c8],rbp
   69a9d:	mov    rbp,rbx
   69aa0:	mov    r13,QWORD PTR [rsp+0x1b0]
   69aa8:	mov    rbx,QWORD PTR [rsp+0x1d8]
   69ab0:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   69ab5:	mov    r12,QWORD PTR [rsp+0x200]
   69abd:	mov    r15,QWORD PTR [rsp+0x208]
   69ac5:	mov    rax,QWORD PTR [r15+0x50]
   69ac9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69ad4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69adf:	mov    QWORD PTR [rsp+0x190],rdi
   69ae7:	mov    rdi,r12
   69aea:	mov    r10,rax
   69aed:	call   r10
   69af0:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69afb:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69b06:	mov    r12,QWORD PTR [rsp+0x1e8]
   69b0e:	mov    BYTE PTR [r12+0x2],0x0
   69b14:	mov    rdi,QWORD PTR [rsp+0x190]
   69b1c:	test   eax,eax
   69b1e:	je     69b3a <sqlite3VdbeExec+0x1a69a>
   69b20:	mov    r12,r14
   69b23:	mov    r15d,DWORD PTR [rsp+0x3fc]
   69b2b:	mov    DWORD PTR [rsp+0x40c],ebx
   69b32:	mov    rbx,r13
   69b35:	jmp    52730 <sqlite3VdbeExec+0x3290>
   69b3a:	mov    DWORD PTR [rsp+0x40c],ebx
   69b41:	mov    rbx,r13
   69b44:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   69b49:	mov    r15d,DWORD PTR [rsp+0x3fc]
   69b51:	mov    r13,QWORD PTR [rsp+0x1d0]
   69b59:	mov    QWORD PTR [rsp+0x1b0],r12
   69b61:	mov    r12d,DWORD PTR [rsp+0x414]
   69b69:	mov    rax,QWORD PTR [rdi+0x78]
   69b6d:	movsxd rcx,DWORD PTR [rbp+0x4]
   69b71:	mov    DWORD PTR [rsp+0x414],r12d
   69b79:	mov    r12,QWORD PTR [rax+rcx*8]
   69b7d:	movsxd rax,DWORD PTR [rbp+0xc]
   69b81:	imul   rax,rax,0x38
   69b85:	mov    QWORD PTR [rsp+0x1d0],r13
   69b8d:	lea    r13,[rbx+rax*1]
   69b91:	cmp    BYTE PTR [r12+0x2],0x0
   69b97:	je     69c01 <sqlite3VdbeExec+0x1a761>
   69b99:	movzx  eax,WORD PTR [r13+0x14]
   69b9e:	and    eax,0x9000
   69ba3:	test   eax,eax
   69ba5:	je     69bed <sqlite3VdbeExec+0x1a74d>
   69ba7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69bb2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69bbd:	mov    QWORD PTR [rsp+0x190],rdi
   69bc5:	mov    rdi,r13
   69bc8:	call   69bcd <sqlite3VdbeExec+0x1a72d>
   69bcd:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69bd8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69be3:	mov    rdi,QWORD PTR [rsp+0x190]
   69beb:	jmp    69bf4 <sqlite3VdbeExec+0x1a754>
   69bed:	mov    WORD PTR [r13+0x14],0x1
   69bf4:	mov    DWORD PTR [rsp+0x3fc],r15d
   69bfc:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   69c01:	mov    rax,QWORD PTR [r12+0x28]
   69c06:	mov    QWORD PTR [rsp+0x1e0],rbx
   69c0e:	mov    rbx,QWORD PTR [rax]
   69c11:	mov    QWORD PTR [rsp+0x1a8],r14
   69c19:	mov    r14,QWORD PTR [rbx]
   69c1c:	mov    QWORD PTR [rsp+0x1e8],rbx
   69c24:	lea    rbx,[rsp+0x290]
   69c2c:	mov    rax,rbx
   69c2f:	xor    ecx,ecx
   69c31:	mov    edx,0x30
   69c36:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69c41:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69c4c:	mov    QWORD PTR [rsp+0x190],rdi
   69c54:	mov    rdi,rax
   69c57:	mov    rsi,rcx
   69c5a:	call   69c5f <sqlite3VdbeExec+0x1a7bf>
   69c5f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69c6a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69c75:	mov    QWORD PTR [rsp+0x290],r13
   69c7d:	mov    BYTE PTR [rsp+0x2b8],r15b
   69c85:	mov    QWORD PTR [rsp+0x338],0x0
   69c91:	mov    DWORD PTR [rsp+0x334],0x1000000
   69c9c:	lea    rbx,[rsp+0x330]
   69ca4:	mov    rax,rbx
   69ca7:	mov    QWORD PTR [rsp+0x298],rax
   69caf:	movzx  eax,WORD PTR [rbp+0x2]
   69cb3:	and    eax,0x1
   69cb6:	mov    rdi,QWORD PTR [rsp+0x190]
   69cbe:	test   eax,eax
   69cc0:	je     69d26 <sqlite3VdbeExec+0x1a886>
   69cc2:	movzx  eax,WORD PTR [r13+0x14]
   69cc7:	and    eax,0x9000
   69ccc:	test   eax,eax
   69cce:	je     69d0e <sqlite3VdbeExec+0x1a86e>
   69cd0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69cdb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69ce6:	mov    rdi,r13
   69ce9:	call   69cee <sqlite3VdbeExec+0x1a84e>
   69cee:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69cf9:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69d04:	mov    rdi,QWORD PTR [rsp+0x190]
   69d0c:	jmp    69d15 <sqlite3VdbeExec+0x1a875>
   69d0e:	mov    WORD PTR [r13+0x14],0x1
   69d15:	mov    WORD PTR [r13+0x14],0x401
   69d1c:	mov    DWORD PTR [r13+0x0],0x0
   69d24:	jmp    69d38 <sqlite3VdbeExec+0x1a898>
   69d26:	movzx  eax,WORD PTR [r13+0x14]
   69d2b:	and    eax,0xfffff240
   69d30:	or     eax,0x1
   69d33:	mov    WORD PTR [r13+0x14],ax
   69d38:	mov    rax,QWORD PTR [r14+0x58]
   69d3c:	mov    rcx,QWORD PTR [r12+0x28]
   69d41:	lea    r12,[rsp+0x290]
   69d49:	mov    rdx,r12
   69d4c:	mov    esi,DWORD PTR [rbp+0x8]
   69d4f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69d5a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69d65:	mov    QWORD PTR [rsp+0x190],rdi
   69d6d:	mov    rdi,rcx
   69d70:	mov    r10,rax
   69d73:	mov    r11,rsi
   69d76:	mov    rsi,rdx
   69d79:	mov    rdx,r11
   69d7c:	call   r10
   69d7f:	mov    r14d,eax
   69d82:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69d8d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69d98:	mov    rdi,QWORD PTR [rsp+0x190]
   69da0:	mov    rbx,QWORD PTR [rsp+0x1e8]
   69da8:	cmp    QWORD PTR [rbx+0x10],0x0
   69dad:	jne    69dbc <sqlite3VdbeExec+0x1a91c>
   69daf:	mov    DWORD PTR [rsp+0x424],r14d
   69db7:	jmp    6a091 <sqlite3VdbeExec+0x1abf1>
   69dbc:	mov    r12,QWORD PTR [rdi]
   69dbf:	mov    rax,QWORD PTR [rdi+0xa8]
   69dc6:	test   rax,rax
   69dc9:	je     69e0a <sqlite3VdbeExec+0x1a96a>
   69dcb:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69dd6:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69de1:	mov    rdi,r12
   69de4:	mov    rsi,rax
   69de7:	call   69dec <sqlite3VdbeExec+0x1a94c>
   69dec:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69df7:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69e02:	mov    rdi,QWORD PTR [rsp+0x190]
   69e0a:	mov    DWORD PTR [rsp+0x424],r14d
   69e12:	mov    r14,QWORD PTR [rbx+0x10]
   69e16:	test   r14,r14
   69e19:	jne    69e23 <sqlite3VdbeExec+0x1a983>
   69e1b:	xor    r12d,r12d
   69e1e:	jmp    69f6c <sqlite3VdbeExec+0x1aacc>
   69e23:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69e2e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69e39:	mov    QWORD PTR [rsp+0x190],rdi
   69e41:	mov    rdi,r14
   69e44:	call   69e49 <sqlite3VdbeExec+0x1a9a9>
   69e49:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69e54:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69e5f:	mov    QWORD PTR [rsp+0x200],r14
   69e67:	lea    r14,[rax+0x1]
   69e6b:	mov    rdi,QWORD PTR [rsp+0x190]
   69e73:	test   r12,r12
   69e76:	je     69ebc <sqlite3VdbeExec+0x1aa1c>
   69e78:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69e83:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69e8e:	mov    rdi,r12
   69e91:	mov    rsi,r14
   69e94:	call   69e99 <sqlite3VdbeExec+0x1a9f9>
   69e99:	mov    r12,rax
   69e9c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69ea7:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69eb2:	mov    rdi,QWORD PTR [rsp+0x190]
   69eba:	jmp    69efb <sqlite3VdbeExec+0x1aa5b>
   69ebc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69ec7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69ed2:	mov    rdi,r14
   69ed5:	call   69eda <sqlite3VdbeExec+0x1aa3a>
   69eda:	mov    r12,rax
   69edd:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69ee8:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69ef3:	mov    rdi,QWORD PTR [rsp+0x190]
   69efb:	test   r12,r12
   69efe:	jne    69f0a <sqlite3VdbeExec+0x1aa6a>
   69f00:	mov    QWORD PTR [rsp+0x1e8],rbx
   69f08:	jmp    69f64 <sqlite3VdbeExec+0x1aac4>
   69f0a:	mov    QWORD PTR [rsp+0x1e8],rbx
   69f12:	mov    rbx,QWORD PTR [rsp+0x200]
   69f1a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69f25:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69f30:	mov    QWORD PTR [rsp+0x190],rdi
   69f38:	mov    rdi,r12
   69f3b:	mov    rsi,rbx
   69f3e:	mov    rdx,r14
   69f41:	call   69f46 <sqlite3VdbeExec+0x1aaa6>
   69f46:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69f51:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69f5c:	mov    rdi,QWORD PTR [rsp+0x190]
   69f64:	mov    rbx,QWORD PTR [rsp+0x1e8]
   69f6c:	mov    QWORD PTR [rdi+0xa8],r12
   69f73:	mov    r12,QWORD PTR [rbx+0x10]
   69f77:	test   r12,r12
   69f7a:	je     6a089 <sqlite3VdbeExec+0x1abe9>
   69f80:	cmp    DWORD PTR [rip+0x0],0x0        # 69f87 <sqlite3VdbeExec+0x1aae7>
   69f87:	je     6a03d <sqlite3VdbeExec+0x1ab9d>
   69f8d:	mov    rax,QWORD PTR [rip+0x0]        # 69f94 <sqlite3VdbeExec+0x1aaf4>
   69f94:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   69f9f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   69faa:	mov    QWORD PTR [rsp+0x190],rdi
   69fb2:	mov    rdi,r12
   69fb5:	mov    r10,rax
   69fb8:	call   r10
   69fbb:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   69fc6:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   69fd1:	mov    rcx,QWORD PTR [rip+0x0]        # 69fd8 <sqlite3VdbeExec+0x1ab38>
   69fd8:	movsxd rax,eax
   69fdb:	sub    rcx,rax
   69fde:	mov    QWORD PTR [rip+0x0],rcx        # 69fe5 <sqlite3VdbeExec+0x1ab45>
   69fe5:	mov    rax,QWORD PTR [rip+0x0]        # 69fec <sqlite3VdbeExec+0x1ab4c>
   69fec:	sub    rax,0x1
   69ff0:	mov    QWORD PTR [rip+0x0],rax        # 69ff7 <sqlite3VdbeExec+0x1ab57>
   69ff7:	mov    rax,QWORD PTR [rip+0x0]        # 69ffe <sqlite3VdbeExec+0x1ab5e>
   69ffe:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a009:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a014:	mov    rdi,r12
   6a017:	mov    r10,rax
   6a01a:	call   r10
   6a01d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a028:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a033:	mov    rdi,QWORD PTR [rsp+0x190]
   6a03b:	jmp    6a089 <sqlite3VdbeExec+0x1abe9>
   6a03d:	mov    rax,QWORD PTR [rip+0x0]        # 6a044 <sqlite3VdbeExec+0x1aba4>
   6a044:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a04f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a05a:	mov    QWORD PTR [rsp+0x190],rdi
   6a062:	mov    rdi,r12
   6a065:	mov    r10,rax
   6a068:	call   r10
   6a06b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a076:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a081:	mov    rdi,QWORD PTR [rsp+0x190]
   6a089:	mov    QWORD PTR [rbx+0x10],0x0
   6a091:	cmp    DWORD PTR [rsp+0x2b4],0x0
   6a099:	jg     6a0a7 <sqlite3VdbeExec+0x1ac07>
   6a09b:	mov    ebx,DWORD PTR [rsp+0x424]
   6a0a2:	jmp    6a181 <sqlite3VdbeExec+0x1ace1>
   6a0a7:	lea    rbx,[rip+0x0]        # 6a0ae <sqlite3VdbeExec+0x1ac0e>
   6a0ae:	test   r13,r13
   6a0b1:	jne    6a0b7 <sqlite3VdbeExec+0x1ac17>
   6a0b3:	xor    eax,eax
   6a0b5:	jmp    6a131 <sqlite3VdbeExec+0x1ac91>
   6a0b7:	movzx  eax,WORD PTR [r13+0x14]
   6a0bc:	and    eax,0x202
   6a0c1:	cmp    eax,0x202
   6a0c6:	jne    6a0d5 <sqlite3VdbeExec+0x1ac35>
   6a0c8:	cmp    BYTE PTR [r13+0x16],0x1
   6a0cd:	jne    6a0d5 <sqlite3VdbeExec+0x1ac35>
   6a0cf:	mov    rax,QWORD PTR [r13+0x8]
   6a0d3:	jmp    6a131 <sqlite3VdbeExec+0x1ac91>
   6a0d5:	movzx  eax,WORD PTR [r13+0x14]
   6a0da:	and    eax,0x1
   6a0dd:	test   eax,eax
   6a0df:	je     6a0e5 <sqlite3VdbeExec+0x1ac45>
   6a0e1:	xor    eax,eax
   6a0e3:	jmp    6a131 <sqlite3VdbeExec+0x1ac91>
   6a0e5:	mov    eax,0x1
   6a0ea:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a0f5:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a100:	mov    QWORD PTR [rsp+0x190],rdi
   6a108:	mov    rdi,r13
   6a10b:	mov    rsi,rax
   6a10e:	call   6a113 <sqlite3VdbeExec+0x1ac73>
   6a113:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a11e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a129:	mov    rdi,QWORD PTR [rsp+0x190]
   6a131:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a13c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a147:	mov    QWORD PTR [rsp+0x190],rdi
   6a14f:	mov    rsi,rbx
   6a152:	mov    rdx,rax
   6a155:	xor    eax,eax
   6a157:	call   6a15c <sqlite3VdbeExec+0x1acbc>
   6a15c:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a167:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a172:	mov    ebx,DWORD PTR [rsp+0x2b4]
   6a179:	mov    rdi,QWORD PTR [rsp+0x190]
   6a181:	mov    eax,r15d
   6a184:	movzx  ecx,WORD PTR [r13+0x14]
   6a189:	and    ecx,0x2
   6a18c:	test   ecx,ecx
   6a18e:	jne    6a1c0 <sqlite3VdbeExec+0x1ad20>
   6a190:	mov    BYTE PTR [r13+0x16],al
   6a194:	test   ebx,ebx
   6a196:	je     6a1cd <sqlite3VdbeExec+0x1ad2d>
   6a198:	mov    r14,QWORD PTR [rsp+0x1a8]
   6a1a0:	mov    QWORD PTR [rsp+0x1c8],rbp
   6a1a8:	mov    rbp,rbx
   6a1ab:	mov    r13,QWORD PTR [rsp+0x1b0]
   6a1b3:	mov    rbx,QWORD PTR [rsp+0x1d8]
   6a1bb:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   6a1c0:	movzx  ecx,BYTE PTR [r13+0x16]
   6a1c5:	cmp    ecx,eax
   6a1c7:	jne    6a1f1 <sqlite3VdbeExec+0x1ad51>
   6a1c9:	test   ebx,ebx
   6a1cb:	jne    6a198 <sqlite3VdbeExec+0x1acf8>
   6a1cd:	mov    r14,QWORD PTR [rsp+0x1a8]
   6a1d5:	mov    DWORD PTR [rsp+0x3fc],r15d
   6a1dd:	mov    DWORD PTR [rsp+0x40c],ebx
   6a1e4:	mov    rbx,QWORD PTR [rsp+0x1e0]
   6a1ec:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6a1f1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a1fc:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a207:	mov    QWORD PTR [rsp+0x190],rdi
   6a20f:	mov    rdi,r13
   6a212:	mov    rsi,rax
   6a215:	call   6a21a <sqlite3VdbeExec+0x1ad7a>
   6a21a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a225:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a230:	mov    rdi,QWORD PTR [rsp+0x190]
   6a238:	test   ebx,ebx
   6a23a:	jne    6a198 <sqlite3VdbeExec+0x1acf8>
   6a240:	jmp    6a1cd <sqlite3VdbeExec+0x1ad2d>
   6a242:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6a24a:	mov    r13,QWORD PTR [rsp+0x1d0]
   6a252:	mov    QWORD PTR [rsp+0x1b0],r12
   6a25a:	mov    r12d,DWORD PTR [rsp+0x414]
   6a262:	mov    rax,QWORD PTR [rdi+0x78]
   6a266:	movsxd rcx,DWORD PTR [rbp+0x4]
   6a26a:	mov    DWORD PTR [rsp+0x414],r12d
   6a272:	mov    r12,QWORD PTR [rax+rcx*8]
   6a276:	cmp    BYTE PTR [r12+0x2],0x0
   6a27c:	je     6a293 <sqlite3VdbeExec+0x1adf3>
   6a27e:	mov    DWORD PTR [rsp+0x3fc],r15d
   6a286:	mov    QWORD PTR [rsp+0x1d0],r13
   6a28e:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6a293:	mov    rax,QWORD PTR [r12+0x28]
   6a298:	mov    QWORD PTR [rsp+0x1d0],r13
   6a2a0:	mov    r13,QWORD PTR [rax]
   6a2a3:	mov    DWORD PTR [rsp+0x3fc],r15d
   6a2ab:	mov    r15,QWORD PTR [r13+0x0]
   6a2af:	mov    rax,QWORD PTR [r15+0x48]
   6a2b3:	mov    rcx,QWORD PTR [r12+0x28]
   6a2b8:	mov    QWORD PTR [rsp+0x208],r15
   6a2c0:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a2cb:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a2d6:	mov    QWORD PTR [rsp+0x190],rdi
   6a2de:	mov    rdi,rcx
   6a2e1:	mov    r10,rax
   6a2e4:	call   r10
   6a2e7:	mov    r15d,eax
   6a2ea:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a2f5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a300:	mov    rdi,QWORD PTR [rsp+0x190]
   6a308:	cmp    QWORD PTR [r13+0x10],0x0
   6a30d:	jne    6a31c <sqlite3VdbeExec+0x1ae7c>
   6a30f:	mov    QWORD PTR [rsp+0x1e8],r12
   6a317:	jmp    6a615 <sqlite3VdbeExec+0x1b175>
   6a31c:	mov    DWORD PTR [rsp+0x40c],r15d
   6a324:	mov    r15,QWORD PTR [rdi]
   6a327:	mov    rax,QWORD PTR [rdi+0xa8]
   6a32e:	test   rax,rax
   6a331:	je     6a372 <sqlite3VdbeExec+0x1aed2>
   6a333:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a33e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a349:	mov    rdi,r15
   6a34c:	mov    rsi,rax
   6a34f:	call   6a354 <sqlite3VdbeExec+0x1aeb4>
   6a354:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a35f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a36a:	mov    rdi,QWORD PTR [rsp+0x190]
   6a372:	mov    QWORD PTR [rsp+0x1e8],r12
   6a37a:	mov    r12,QWORD PTR [r13+0x10]
   6a37e:	test   r12,r12
   6a381:	jne    6a38e <sqlite3VdbeExec+0x1aeee>
   6a383:	xor    r12d,r12d
   6a386:	mov    r15,r12
   6a389:	jmp    6a4d7 <sqlite3VdbeExec+0x1b037>
   6a38e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a399:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a3a4:	mov    QWORD PTR [rsp+0x190],rdi
   6a3ac:	mov    rdi,r12
   6a3af:	call   6a3b4 <sqlite3VdbeExec+0x1af14>
   6a3b4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a3bf:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a3ca:	mov    QWORD PTR [rsp+0x210],r12
   6a3d2:	lea    r12,[rax+0x1]
   6a3d6:	mov    rdi,QWORD PTR [rsp+0x190]
   6a3de:	test   r15,r15
   6a3e1:	je     6a427 <sqlite3VdbeExec+0x1af87>
   6a3e3:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a3ee:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a3f9:	mov    rdi,r15
   6a3fc:	mov    rsi,r12
   6a3ff:	call   6a404 <sqlite3VdbeExec+0x1af64>
   6a404:	mov    r15,rax
   6a407:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a412:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a41d:	mov    rdi,QWORD PTR [rsp+0x190]
   6a425:	jmp    6a466 <sqlite3VdbeExec+0x1afc6>
   6a427:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a432:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a43d:	mov    rdi,r12
   6a440:	call   6a445 <sqlite3VdbeExec+0x1afa5>
   6a445:	mov    r15,rax
   6a448:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a453:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a45e:	mov    rdi,QWORD PTR [rsp+0x190]
   6a466:	test   r15,r15
   6a469:	jne    6a475 <sqlite3VdbeExec+0x1afd5>
   6a46b:	mov    QWORD PTR [rsp+0x200],r13
   6a473:	jmp    6a4cf <sqlite3VdbeExec+0x1b02f>
   6a475:	mov    QWORD PTR [rsp+0x200],r13
   6a47d:	mov    r13,QWORD PTR [rsp+0x210]
   6a485:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a490:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a49b:	mov    QWORD PTR [rsp+0x190],rdi
   6a4a3:	mov    rdi,r15
   6a4a6:	mov    rsi,r13
   6a4a9:	mov    rdx,r12
   6a4ac:	call   6a4b1 <sqlite3VdbeExec+0x1b011>
   6a4b1:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a4bc:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a4c7:	mov    rdi,QWORD PTR [rsp+0x190]
   6a4cf:	mov    r13,QWORD PTR [rsp+0x200]
   6a4d7:	mov    QWORD PTR [rdi+0xa8],r15
   6a4de:	mov    r12,QWORD PTR [r13+0x10]
   6a4e2:	test   r12,r12
   6a4e5:	jne    6a4f4 <sqlite3VdbeExec+0x1b054>
   6a4e7:	mov    r15d,DWORD PTR [rsp+0x40c]
   6a4ef:	jmp    6a60d <sqlite3VdbeExec+0x1b16d>
   6a4f4:	cmp    DWORD PTR [rip+0x0],0x0        # 6a4fb <sqlite3VdbeExec+0x1b05b>
   6a4fb:	je     6a5b9 <sqlite3VdbeExec+0x1b119>
   6a501:	mov    rax,QWORD PTR [rip+0x0]        # 6a508 <sqlite3VdbeExec+0x1b068>
   6a508:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a513:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a51e:	mov    QWORD PTR [rsp+0x190],rdi
   6a526:	mov    rdi,r12
   6a529:	mov    r10,rax
   6a52c:	call   r10
   6a52f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a53a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a545:	mov    rcx,QWORD PTR [rip+0x0]        # 6a54c <sqlite3VdbeExec+0x1b0ac>
   6a54c:	movsxd rax,eax
   6a54f:	sub    rcx,rax
   6a552:	mov    QWORD PTR [rip+0x0],rcx        # 6a559 <sqlite3VdbeExec+0x1b0b9>
   6a559:	mov    rax,QWORD PTR [rip+0x0]        # 6a560 <sqlite3VdbeExec+0x1b0c0>
   6a560:	sub    rax,0x1
   6a564:	mov    QWORD PTR [rip+0x0],rax        # 6a56b <sqlite3VdbeExec+0x1b0cb>
   6a56b:	mov    rax,QWORD PTR [rip+0x0]        # 6a572 <sqlite3VdbeExec+0x1b0d2>
   6a572:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a57d:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a588:	mov    rdi,r12
   6a58b:	mov    r10,rax
   6a58e:	call   r10
   6a591:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a59c:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a5a7:	mov    rdi,QWORD PTR [rsp+0x190]
   6a5af:	mov    r15d,DWORD PTR [rsp+0x40c]
   6a5b7:	jmp    6a60d <sqlite3VdbeExec+0x1b16d>
   6a5b9:	mov    r15d,DWORD PTR [rsp+0x40c]
   6a5c1:	mov    rax,QWORD PTR [rip+0x0]        # 6a5c8 <sqlite3VdbeExec+0x1b128>
   6a5c8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a5d3:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a5de:	mov    QWORD PTR [rsp+0x190],rdi
   6a5e6:	mov    rdi,r12
   6a5e9:	mov    r10,rax
   6a5ec:	call   r10
   6a5ef:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a5fa:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a605:	mov    rdi,QWORD PTR [rsp+0x190]
   6a60d:	mov    QWORD PTR [r13+0x10],0x0
   6a615:	test   r15d,r15d
   6a618:	je     6a63a <sqlite3VdbeExec+0x1b19a>
   6a61a:	mov    QWORD PTR [rsp+0x1c8],rbp
   6a622:	mov    rbp,r15
   6a625:	mov    r13,QWORD PTR [rsp+0x1b0]
   6a62d:	mov    rbx,QWORD PTR [rsp+0x1d8]
   6a635:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   6a63a:	mov    r12,QWORD PTR [rsp+0x1e8]
   6a642:	mov    r13,QWORD PTR [rsp+0x208]
   6a64a:	mov    rax,QWORD PTR [r13+0x50]
   6a64e:	mov    rcx,QWORD PTR [r12+0x28]
   6a653:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a65e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a669:	mov    QWORD PTR [rsp+0x190],rdi
   6a671:	mov    rdi,rcx
   6a674:	mov    r10,rax
   6a677:	call   r10
   6a67a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a685:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a690:	mov    rdi,QWORD PTR [rsp+0x190]
   6a698:	test   eax,eax
   6a69a:	jne    6a6c1 <sqlite3VdbeExec+0x1b221>
   6a69c:	mov    r13,QWORD PTR [rsp+0x1d0]
   6a6a4:	mov    r12d,DWORD PTR [rsp+0x414]
   6a6ac:	mov    DWORD PTR [rsp+0x40c],r15d
   6a6b4:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6a6bc:	jmp    4f80d <sqlite3VdbeExec+0x36d>
   6a6c1:	mov    r12d,DWORD PTR [rsp+0x414]
   6a6c9:	mov    r13,QWORD PTR [rsp+0x1d0]
   6a6d1:	mov    QWORD PTR [rsp+0x1c8],rbp
   6a6d9:	mov    DWORD PTR [rsp+0x40c],r15d
   6a6e1:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6a6e9:	mov    QWORD PTR [rsp+0x1e0],rbx
   6a6f1:	mov    ebx,DWORD PTR [rsp+0x410]
   6a6f8:	jmp    4f836 <sqlite3VdbeExec+0x396>
   6a6fd:	mov    QWORD PTR [rsp+0x1b0],r12
   6a705:	mov    rax,QWORD PTR [r14+0x30]
   6a709:	and    rax,0x4000000
   6a70f:	mov    r12d,eax
   6a712:	mov    rax,QWORD PTR [r14+0x30]
   6a716:	or     rax,0x4000000
   6a71c:	mov    QWORD PTR [r14+0x30],rax
   6a720:	mov    rax,QWORD PTR [rbp+0x10]
   6a724:	mov    r13,QWORD PTR [rax+0x10]
   6a728:	movsxd rax,DWORD PTR [rbp+0x4]
   6a72c:	imul   rax,rax,0x38
   6a730:	lea    r15,[rbx+rax*1]
   6a734:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   6a739:	and    eax,0x2
   6a73c:	test   eax,eax
   6a73e:	jne    6a752 <sqlite3VdbeExec+0x1b2b2>
   6a740:	mov    BYTE PTR [r15+0x16],0x1
   6a745:	mov    DWORD PTR [rsp+0x424],r12d
   6a74d:	xor    r12d,r12d
   6a750:	jmp    6a7bd <sqlite3VdbeExec+0x1b31d>
   6a752:	cmp    BYTE PTR [r15+0x16],0x1
   6a757:	jne    6a766 <sqlite3VdbeExec+0x1b2c6>
   6a759:	mov    DWORD PTR [rsp+0x424],r12d
   6a761:	xor    r12d,r12d
   6a764:	jmp    6a7bd <sqlite3VdbeExec+0x1b31d>
   6a766:	mov    eax,0x1
   6a76b:	mov    DWORD PTR [rsp+0x424],r12d
   6a773:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a77e:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a789:	mov    QWORD PTR [rsp+0x190],rdi
   6a791:	mov    rdi,r15
   6a794:	mov    rsi,rax
   6a797:	call   6a79c <sqlite3VdbeExec+0x1b2fc>
   6a79c:	mov    r12d,eax
   6a79f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a7aa:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a7b5:	mov    rdi,QWORD PTR [rsp+0x190]
   6a7bd:	test   r12d,r12d
   6a7c0:	je     6a7e2 <sqlite3VdbeExec+0x1b342>
   6a7c2:	mov    QWORD PTR [rsp+0x1c8],rbp
   6a7ca:	mov    rbp,r12
   6a7cd:	mov    r13,QWORD PTR [rsp+0x1b0]
   6a7d5:	mov    rbx,QWORD PTR [rsp+0x1d8]
   6a7dd:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   6a7e2:	mov    r12d,DWORD PTR [rsp+0x424]
   6a7ea:	mov    rax,QWORD PTR [r13+0x0]
   6a7ee:	mov    rax,QWORD PTR [rax+0x98]
   6a7f5:	mov    rcx,QWORD PTR [r15+0x8]
   6a7f9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a804:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a80f:	mov    QWORD PTR [rsp+0x190],rdi
   6a817:	mov    rdi,r13
   6a81a:	mov    rsi,rcx
   6a81d:	mov    r10,rax
   6a820:	call   r10
   6a823:	mov    r15d,eax
   6a826:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a831:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a83c:	mov    rdi,QWORD PTR [rsp+0x190]
   6a844:	test   r12d,r12d
   6a847:	jne    6a857 <sqlite3VdbeExec+0x1b3b7>
   6a849:	mov    rax,QWORD PTR [r14+0x30]
   6a84d:	and    rax,0xfffffffffbffffff
   6a853:	mov    QWORD PTR [r14+0x30],rax
   6a857:	cmp    QWORD PTR [r13+0x10],0x0
   6a85c:	je     6ab58 <sqlite3VdbeExec+0x1b6b8>
   6a862:	mov    r12,QWORD PTR [rdi]
   6a865:	mov    rax,QWORD PTR [rdi+0xa8]
   6a86c:	test   rax,rax
   6a86f:	je     6a8b8 <sqlite3VdbeExec+0x1b418>
   6a871:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a87c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a887:	mov    QWORD PTR [rsp+0x190],rdi
   6a88f:	mov    rdi,r12
   6a892:	mov    rsi,rax
   6a895:	call   6a89a <sqlite3VdbeExec+0x1b3fa>
   6a89a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a8a5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a8b0:	mov    rdi,QWORD PTR [rsp+0x190]
   6a8b8:	mov    DWORD PTR [rsp+0x41c],r15d
   6a8c0:	mov    r15,QWORD PTR [r13+0x10]
   6a8c4:	test   r15,r15
   6a8c7:	jne    6a8d1 <sqlite3VdbeExec+0x1b431>
   6a8c9:	xor    r12d,r12d
   6a8cc:	jmp    6aa1a <sqlite3VdbeExec+0x1b57a>
   6a8d1:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a8dc:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a8e7:	mov    QWORD PTR [rsp+0x190],rdi
   6a8ef:	mov    rdi,r15
   6a8f2:	call   6a8f7 <sqlite3VdbeExec+0x1b457>
   6a8f7:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a902:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a90d:	mov    QWORD PTR [rsp+0x208],r15
   6a915:	lea    r15,[rax+0x1]
   6a919:	mov    rdi,QWORD PTR [rsp+0x190]
   6a921:	test   r12,r12
   6a924:	je     6a96a <sqlite3VdbeExec+0x1b4ca>
   6a926:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a931:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a93c:	mov    rdi,r12
   6a93f:	mov    rsi,r15
   6a942:	call   6a947 <sqlite3VdbeExec+0x1b4a7>
   6a947:	mov    r12,rax
   6a94a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a955:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a960:	mov    rdi,QWORD PTR [rsp+0x190]
   6a968:	jmp    6a9a9 <sqlite3VdbeExec+0x1b509>
   6a96a:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a975:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a980:	mov    rdi,r15
   6a983:	call   6a988 <sqlite3VdbeExec+0x1b4e8>
   6a988:	mov    r12,rax
   6a98b:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a996:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6a9a1:	mov    rdi,QWORD PTR [rsp+0x190]
   6a9a9:	test   r12,r12
   6a9ac:	jne    6a9b8 <sqlite3VdbeExec+0x1b518>
   6a9ae:	mov    QWORD PTR [rsp+0x1e8],r13
   6a9b6:	jmp    6aa12 <sqlite3VdbeExec+0x1b572>
   6a9b8:	mov    QWORD PTR [rsp+0x1e8],r13
   6a9c0:	mov    r13,QWORD PTR [rsp+0x208]
   6a9c8:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6a9d3:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6a9de:	mov    QWORD PTR [rsp+0x190],rdi
   6a9e6:	mov    rdi,r12
   6a9e9:	mov    rsi,r13
   6a9ec:	mov    rdx,r15
   6a9ef:	call   6a9f4 <sqlite3VdbeExec+0x1b554>
   6a9f4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6a9ff:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6aa0a:	mov    rdi,QWORD PTR [rsp+0x190]
   6aa12:	mov    r13,QWORD PTR [rsp+0x1e8]
   6aa1a:	mov    QWORD PTR [rdi+0xa8],r12
   6aa21:	mov    r12,QWORD PTR [r13+0x10]
   6aa25:	test   r12,r12
   6aa28:	jne    6aa37 <sqlite3VdbeExec+0x1b597>
   6aa2a:	mov    r15d,DWORD PTR [rsp+0x41c]
   6aa32:	jmp    6ab50 <sqlite3VdbeExec+0x1b6b0>
   6aa37:	cmp    DWORD PTR [rip+0x0],0x0        # 6aa3e <sqlite3VdbeExec+0x1b59e>
   6aa3e:	je     6aafc <sqlite3VdbeExec+0x1b65c>
   6aa44:	mov    rax,QWORD PTR [rip+0x0]        # 6aa4b <sqlite3VdbeExec+0x1b5ab>
   6aa4b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6aa56:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6aa61:	mov    QWORD PTR [rsp+0x190],rdi
   6aa69:	mov    rdi,r12
   6aa6c:	mov    r10,rax
   6aa6f:	call   r10
   6aa72:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6aa7d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6aa88:	mov    rcx,QWORD PTR [rip+0x0]        # 6aa8f <sqlite3VdbeExec+0x1b5ef>
   6aa8f:	movsxd rax,eax
   6aa92:	sub    rcx,rax
   6aa95:	mov    QWORD PTR [rip+0x0],rcx        # 6aa9c <sqlite3VdbeExec+0x1b5fc>
   6aa9c:	mov    rax,QWORD PTR [rip+0x0]        # 6aaa3 <sqlite3VdbeExec+0x1b603>
   6aaa3:	sub    rax,0x1
   6aaa7:	mov    QWORD PTR [rip+0x0],rax        # 6aaae <sqlite3VdbeExec+0x1b60e>
   6aaae:	mov    rax,QWORD PTR [rip+0x0]        # 6aab5 <sqlite3VdbeExec+0x1b615>
   6aab5:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6aac0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6aacb:	mov    rdi,r12
   6aace:	mov    r10,rax
   6aad1:	call   r10
   6aad4:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6aadf:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6aaea:	mov    rdi,QWORD PTR [rsp+0x190]
   6aaf2:	mov    r15d,DWORD PTR [rsp+0x41c]
   6aafa:	jmp    6ab50 <sqlite3VdbeExec+0x1b6b0>
   6aafc:	mov    r15d,DWORD PTR [rsp+0x41c]
   6ab04:	mov    rax,QWORD PTR [rip+0x0]        # 6ab0b <sqlite3VdbeExec+0x1b66b>
   6ab0b:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6ab16:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6ab21:	mov    QWORD PTR [rsp+0x190],rdi
   6ab29:	mov    rdi,r12
   6ab2c:	mov    r10,rax
   6ab2f:	call   r10
   6ab32:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6ab3d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6ab48:	mov    rdi,QWORD PTR [rsp+0x190]
   6ab50:	mov    QWORD PTR [r13+0x10],0x0
   6ab58:	movzx  eax,WORD PTR [rdi+0xc8]
   6ab5f:	and    rax,0xfffffffffffffffc
   6ab63:	mov    WORD PTR [rdi+0xc8],ax
   6ab6a:	test   r15d,r15d
   6ab6d:	je     6ab8f <sqlite3VdbeExec+0x1b6ef>
   6ab6f:	mov    QWORD PTR [rsp+0x1c8],rbp
   6ab77:	mov    rbp,r15
   6ab7a:	mov    r13,QWORD PTR [rsp+0x1b0]
   6ab82:	mov    rbx,QWORD PTR [rsp+0x1d8]
   6ab8a:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   6ab8f:	mov    DWORD PTR [rsp+0x40c],r15d
   6ab97:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6ab9c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6aba4:	mov    r13,QWORD PTR [rsp+0x1d0]
   6abac:	mov    QWORD PTR [rsp+0x1b0],r12
   6abb4:	mov    r12d,DWORD PTR [rsp+0x414]
   6abbc:	mov    QWORD PTR [rsp+0x1e8],0x0
   6abc8:	cmp    BYTE PTR [r14+0x67],0x0
   6abcd:	je     6abdf <sqlite3VdbeExec+0x1b73f>
   6abcf:	mov    rbx,rbp
   6abd2:	mov    rbp,QWORD PTR [rsp+0x1d8]
   6abda:	jmp    4f582 <sqlite3VdbeExec+0xe2>
   6abdf:	mov    rax,QWORD PTR [rbp+0x10]
   6abe3:	mov    QWORD PTR [rsp+0x1d0],r13
   6abeb:	mov    r13,QWORD PTR [rax+0x10]
   6abef:	test   r13,r13
   6abf2:	je     6abfb <sqlite3VdbeExec+0x1b75b>
   6abf4:	cmp    QWORD PTR [r13+0x0],0x0
   6abf9:	jne    6ac20 <sqlite3VdbeExec+0x1b780>
   6abfb:	mov    ebx,0x6
   6ac00:	mov    QWORD PTR [rsp+0x1c8],rbp
   6ac08:	mov    rbp,rbx
   6ac0b:	mov    r13,QWORD PTR [rsp+0x1b0]
   6ac13:	mov    rbx,QWORD PTR [rsp+0x1d8]
   6ac1b:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   6ac20:	mov    rax,QWORD PTR [r13+0x0]
   6ac24:	mov    ecx,DWORD PTR [rbp+0x8]
   6ac27:	cmp    QWORD PTR [rax+0x68],0x0
   6ac2c:	jne    6ac3b <sqlite3VdbeExec+0x1b79b>
   6ac2e:	mov    DWORD PTR [rsp+0x414],r12d
   6ac36:	jmp    6b081 <sqlite3VdbeExec+0x1bbe1>
   6ac3b:	mov    DWORD PTR [rsp+0x414],r12d
   6ac43:	movzx  r12d,BYTE PTR [r14+0x6c]
   6ac48:	mov    rdx,QWORD PTR [rdi+0x70]
   6ac4c:	movsxd rsi,DWORD PTR [rbp+0xc]
   6ac50:	imul   rsi,rsi,0x38
   6ac54:	add    rsi,rbx
   6ac57:	xor    r8d,r8d
   6ac5a:	mov    r11,rsi
   6ac5d:	mov    rsi,r8
   6ac60:	mov    r8,r11
   6ac63:	jmp    6ac73 <sqlite3VdbeExec+0x1b7d3>
   6ac65:	mov    r9,rsi
   6ac68:	mov    QWORD PTR [rdx+r9*8],r8
   6ac6c:	add    r8,0x38
   6ac70:	add    esi,0x1
   6ac73:	cmp    esi,ecx
   6ac75:	jl     6ac65 <sqlite3VdbeExec+0x1b7c5>
   6ac77:	movzx  esi,WORD PTR [rbp+0x2]
   6ac7b:	mov    BYTE PTR [r14+0x6c],sil
   6ac7f:	mov    rax,QWORD PTR [rax+0x68]
   6ac83:	mov    DWORD PTR [rsp+0x3fc],r15d
   6ac8b:	lea    r15,[rsp+0x1e8]
   6ac93:	mov    rsi,r15
   6ac96:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6aca1:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6acac:	mov    QWORD PTR [rsp+0x190],rdi
   6acb4:	mov    rdi,r13
   6acb7:	mov    r10,rax
   6acba:	mov    r11,rsi
   6acbd:	mov    rsi,rcx
   6acc0:	mov    rcx,r11
   6acc3:	call   r10
   6acc6:	mov    r15d,eax
   6acc9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6acd4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6acdf:	mov    BYTE PTR [r14+0x6c],r12b
   6ace3:	mov    rdi,QWORD PTR [rsp+0x190]
   6aceb:	cmp    QWORD PTR [r13+0x10],0x0
   6acf0:	je     6afe4 <sqlite3VdbeExec+0x1bb44>
   6acf6:	mov    r12,QWORD PTR [rdi]
   6acf9:	mov    rax,QWORD PTR [rdi+0xa8]
   6ad00:	test   rax,rax
   6ad03:	je     6ad44 <sqlite3VdbeExec+0x1b8a4>
   6ad05:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6ad10:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6ad1b:	mov    rdi,r12
   6ad1e:	mov    rsi,rax
   6ad21:	call   6ad26 <sqlite3VdbeExec+0x1b886>
   6ad26:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6ad31:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6ad3c:	mov    rdi,QWORD PTR [rsp+0x190]
   6ad44:	mov    DWORD PTR [rsp+0x41c],r15d
   6ad4c:	mov    r15,QWORD PTR [r13+0x10]
   6ad50:	test   r15,r15
   6ad53:	jne    6ad5d <sqlite3VdbeExec+0x1b8bd>
   6ad55:	xor    r12d,r12d
   6ad58:	jmp    6aea6 <sqlite3VdbeExec+0x1ba06>
   6ad5d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6ad68:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6ad73:	mov    QWORD PTR [rsp+0x190],rdi
   6ad7b:	mov    rdi,r15
   6ad7e:	call   6ad83 <sqlite3VdbeExec+0x1b8e3>
   6ad83:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6ad8e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6ad99:	mov    QWORD PTR [rsp+0x200],r15
   6ada1:	lea    r15,[rax+0x1]
   6ada5:	mov    rdi,QWORD PTR [rsp+0x190]
   6adad:	test   r12,r12
   6adb0:	je     6adf6 <sqlite3VdbeExec+0x1b956>
   6adb2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6adbd:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6adc8:	mov    rdi,r12
   6adcb:	mov    rsi,r15
   6adce:	call   6add3 <sqlite3VdbeExec+0x1b933>
   6add3:	mov    r12,rax
   6add6:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6ade1:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6adec:	mov    rdi,QWORD PTR [rsp+0x190]
   6adf4:	jmp    6ae35 <sqlite3VdbeExec+0x1b995>
   6adf6:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6ae01:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6ae0c:	mov    rdi,r15
   6ae0f:	call   6ae14 <sqlite3VdbeExec+0x1b974>
   6ae14:	mov    r12,rax
   6ae17:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6ae22:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6ae2d:	mov    rdi,QWORD PTR [rsp+0x190]
   6ae35:	test   r12,r12
   6ae38:	jne    6ae44 <sqlite3VdbeExec+0x1b9a4>
   6ae3a:	mov    QWORD PTR [rsp+0x208],r13
   6ae42:	jmp    6ae9e <sqlite3VdbeExec+0x1b9fe>
   6ae44:	mov    QWORD PTR [rsp+0x208],r13
   6ae4c:	mov    r13,QWORD PTR [rsp+0x200]
   6ae54:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6ae5f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6ae6a:	mov    QWORD PTR [rsp+0x190],rdi
   6ae72:	mov    rdi,r12
   6ae75:	mov    rsi,r13
   6ae78:	mov    rdx,r15
   6ae7b:	call   6ae80 <sqlite3VdbeExec+0x1b9e0>
   6ae80:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6ae8b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6ae96:	mov    rdi,QWORD PTR [rsp+0x190]
   6ae9e:	mov    r13,QWORD PTR [rsp+0x208]
   6aea6:	mov    QWORD PTR [rdi+0xa8],r12
   6aead:	mov    r12,QWORD PTR [r13+0x10]
   6aeb1:	test   r12,r12
   6aeb4:	jne    6aec3 <sqlite3VdbeExec+0x1ba23>
   6aeb6:	mov    r15d,DWORD PTR [rsp+0x41c]
   6aebe:	jmp    6afdc <sqlite3VdbeExec+0x1bb3c>
   6aec3:	cmp    DWORD PTR [rip+0x0],0x0        # 6aeca <sqlite3VdbeExec+0x1ba2a>
   6aeca:	je     6af88 <sqlite3VdbeExec+0x1bae8>
   6aed0:	mov    rax,QWORD PTR [rip+0x0]        # 6aed7 <sqlite3VdbeExec+0x1ba37>
   6aed7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6aee2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6aeed:	mov    QWORD PTR [rsp+0x190],rdi
   6aef5:	mov    rdi,r12
   6aef8:	mov    r10,rax
   6aefb:	call   r10
   6aefe:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6af09:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6af14:	mov    rcx,QWORD PTR [rip+0x0]        # 6af1b <sqlite3VdbeExec+0x1ba7b>
   6af1b:	movsxd rax,eax
   6af1e:	sub    rcx,rax
   6af21:	mov    QWORD PTR [rip+0x0],rcx        # 6af28 <sqlite3VdbeExec+0x1ba88>
   6af28:	mov    rax,QWORD PTR [rip+0x0]        # 6af2f <sqlite3VdbeExec+0x1ba8f>
   6af2f:	sub    rax,0x1
   6af33:	mov    QWORD PTR [rip+0x0],rax        # 6af3a <sqlite3VdbeExec+0x1ba9a>
   6af3a:	mov    rax,QWORD PTR [rip+0x0]        # 6af41 <sqlite3VdbeExec+0x1baa1>
   6af41:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6af4c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6af57:	mov    rdi,r12
   6af5a:	mov    r10,rax
   6af5d:	call   r10
   6af60:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6af6b:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6af76:	mov    rdi,QWORD PTR [rsp+0x190]
   6af7e:	mov    r15d,DWORD PTR [rsp+0x41c]
   6af86:	jmp    6afdc <sqlite3VdbeExec+0x1bb3c>
   6af88:	mov    r15d,DWORD PTR [rsp+0x41c]
   6af90:	mov    rax,QWORD PTR [rip+0x0]        # 6af97 <sqlite3VdbeExec+0x1baf7>
   6af97:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6afa2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6afad:	mov    QWORD PTR [rsp+0x190],rdi
   6afb5:	mov    rdi,r12
   6afb8:	mov    r10,rax
   6afbb:	call   r10
   6afbe:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6afc9:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6afd4:	mov    rdi,QWORD PTR [rsp+0x190]
   6afdc:	mov    QWORD PTR [r13+0x10],0x0
   6afe4:	test   r15d,r15d
   6afe7:	jne    6affb <sqlite3VdbeExec+0x1bb5b>
   6afe9:	cmp    DWORD PTR [rbp+0x4],0x0
   6afed:	je     6affb <sqlite3VdbeExec+0x1bb5b>
   6afef:	mov    rax,QWORD PTR [rsp+0x1e8]
   6aff7:	mov    QWORD PTR [r14+0x38],rax
   6affb:	mov    eax,r15d
   6affe:	and    eax,0xff
   6b003:	cmp    eax,0x13
   6b006:	jne    6b03e <sqlite3VdbeExec+0x1bb9e>
   6b008:	mov    rax,QWORD PTR [rbp+0x10]
   6b00c:	cmp    BYTE PTR [rax+0x1c],0x0
   6b010:	je     6b03e <sqlite3VdbeExec+0x1bb9e>
   6b012:	cmp    WORD PTR [rbp+0x2],0x4
   6b017:	jne    6b021 <sqlite3VdbeExec+0x1bb81>
   6b019:	xor    r12d,r12d
   6b01c:	mov    r15,r12
   6b01f:	jmp    6b03c <sqlite3VdbeExec+0x1bb9c>
   6b021:	cmp    WORD PTR [rbp+0x2],0x5
   6b026:	jne    6b02f <sqlite3VdbeExec+0x1bb8f>
   6b028:	mov    eax,0x2
   6b02d:	jmp    6b036 <sqlite3VdbeExec+0x1bb96>
   6b02f:	movzx  eax,WORD PTR [rbp+0x2]
   6b033:	movzx  eax,al
   6b036:	mov    BYTE PTR [rdi+0xc4],al
   6b03c:	jmp    6b04a <sqlite3VdbeExec+0x1bbaa>
   6b03e:	mov    rax,QWORD PTR [rdi+0x38]
   6b042:	add    rax,0x1
   6b046:	mov    QWORD PTR [rdi+0x38],rax
   6b04a:	test   r15d,r15d
   6b04d:	jne    6b061 <sqlite3VdbeExec+0x1bbc1>
   6b04f:	mov    DWORD PTR [rsp+0x40c],r15d
   6b057:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b05f:	jmp    6b081 <sqlite3VdbeExec+0x1bbe1>
   6b061:	mov    QWORD PTR [rsp+0x1c8],rbp
   6b069:	mov    rbp,r15
   6b06c:	mov    r13,QWORD PTR [rsp+0x1b0]
   6b074:	mov    rbx,QWORD PTR [rsp+0x1d8]
   6b07c:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   6b081:	mov    DWORD PTR [rsp+0x3fc],r15d
   6b089:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6b08e:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b096:	mov    r13,QWORD PTR [rsp+0x1d0]
   6b09e:	mov    QWORD PTR [rsp+0x1b0],r12
   6b0a6:	mov    r12d,DWORD PTR [rsp+0x414]
   6b0ae:	mov    rax,QWORD PTR [rdi+0x68]
   6b0b2:	movsxd rcx,DWORD PTR [rbp+0x8]
   6b0b6:	imul   rcx,rcx,0x38
   6b0ba:	lea    rdx,[rax+rcx*1]
   6b0be:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   6b0c3:	and    eax,0x9000
   6b0c8:	test   eax,eax
   6b0ca:	je     6b115 <sqlite3VdbeExec+0x1bc75>
   6b0cc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6b0d7:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6b0e2:	mov    QWORD PTR [rsp+0x190],rdi
   6b0ea:	mov    rdi,rdx
   6b0ed:	call   6b0f2 <sqlite3VdbeExec+0x1bc52>
   6b0f2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6b0fd:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6b108:	mov    rdi,QWORD PTR [rsp+0x190]
   6b110:	mov    rdx,rax
   6b113:	jmp    6b11b <sqlite3VdbeExec+0x1bc7b>
   6b115:	mov    WORD PTR [rdx+0x14],0x4
   6b11b:	mov    rax,QWORD PTR [r14+0x20]
   6b11f:	movsxd rcx,DWORD PTR [rbp+0x4]
   6b123:	shl    rcx,0x5
   6b127:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   6b12c:	mov    rax,QWORD PTR [rax+0x8]
   6b130:	mov    eax,DWORD PTR [rax+0x40]
   6b133:	mov    QWORD PTR [rdx],rax
   6b136:	mov    DWORD PTR [rsp+0x3fc],r15d
   6b13e:	mov    QWORD PTR [rsp+0x1d0],r13
   6b146:	mov    DWORD PTR [rsp+0x414],r12d
   6b14e:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6b153:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b15b:	mov    r13,QWORD PTR [rsp+0x1d0]
   6b163:	mov    QWORD PTR [rsp+0x1b0],r12
   6b16b:	mov    r12d,DWORD PTR [rsp+0x414]
   6b173:	mov    rax,QWORD PTR [rdi+0x68]
   6b177:	movsxd rcx,DWORD PTR [rbp+0x8]
   6b17b:	imul   rcx,rcx,0x38
   6b17f:	lea    rdx,[rax+rcx*1]
   6b183:	movzx  eax,WORD PTR [rax+rcx*1+0x14]
   6b188:	and    eax,0x9000
   6b18d:	test   eax,eax
   6b18f:	je     6b1da <sqlite3VdbeExec+0x1bd3a>
   6b191:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6b19c:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6b1a7:	mov    QWORD PTR [rsp+0x190],rdi
   6b1af:	mov    rdi,rdx
   6b1b2:	call   6b1b7 <sqlite3VdbeExec+0x1bd17>
   6b1b7:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6b1c2:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6b1cd:	mov    rdi,QWORD PTR [rsp+0x190]
   6b1d5:	mov    rdx,rax
   6b1d8:	jmp    6b1e0 <sqlite3VdbeExec+0x1bd40>
   6b1da:	mov    WORD PTR [rdx+0x14],0x4
   6b1e0:	mov    rax,QWORD PTR [r14+0x20]
   6b1e4:	movsxd rcx,DWORD PTR [rbp+0x4]
   6b1e8:	shl    rcx,0x5
   6b1ec:	mov    rax,QWORD PTR [rax+rcx*1+0x8]
   6b1f1:	xor    ecx,ecx
   6b1f3:	cmp    DWORD PTR [rbp+0xc],0x0
   6b1f7:	je     6b208 <sqlite3VdbeExec+0x1bd68>
   6b1f9:	mov    rcx,QWORD PTR [rax+0x8]
   6b1fd:	mov    ecx,DWORD PTR [rcx+0x40]
   6b200:	cmp    ecx,DWORD PTR [rbp+0xc]
   6b203:	jae    6b208 <sqlite3VdbeExec+0x1bd68>
   6b205:	mov    ecx,DWORD PTR [rbp+0xc]
   6b208:	mov    rsi,QWORD PTR [rax+0x8]
   6b20c:	mov    r8,QWORD PTR [rax]
   6b20f:	mov    QWORD PTR [rsi+0x8],r8
   6b213:	mov    rax,QWORD PTR [rax+0x8]
   6b217:	mov    rax,QWORD PTR [rax]
   6b21a:	test   ecx,ecx
   6b21c:	jbe    6b224 <sqlite3VdbeExec+0x1bd84>
   6b21e:	mov    DWORD PTR [rax+0xbc],ecx
   6b224:	mov    eax,DWORD PTR [rax+0xbc]
   6b22a:	mov    QWORD PTR [rdx],rax
   6b22d:	mov    DWORD PTR [rsp+0x3fc],r15d
   6b235:	mov    QWORD PTR [rsp+0x1d0],r13
   6b23d:	mov    DWORD PTR [rsp+0x414],r12d
   6b245:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6b24a:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b252:	mov    r13,QWORD PTR [rsp+0x1d0]
   6b25a:	mov    QWORD PTR [rsp+0x1b0],r12
   6b262:	mov    r12d,DWORD PTR [rsp+0x414]
   6b26a:	mov    DWORD PTR [rsp+0x414],r12d
   6b272:	mov    r12,QWORD PTR [rbp+0x10]
   6b276:	movsxd rax,DWORD PTR [rbp+0xc]
   6b27a:	imul   rax,rax,0x38
   6b27e:	mov    QWORD PTR [rsp+0x1d0],r13
   6b286:	lea    r13,[rbx+rax*1]
   6b28a:	cmp    r13,QWORD PTR [r12]
   6b28e:	je     6b2c7 <sqlite3VdbeExec+0x1be27>
   6b290:	mov    QWORD PTR [r12+0x18],rdi
   6b295:	mov    QWORD PTR [r12],r13
   6b299:	mov    BYTE PTR [r12+0x28],r15b
   6b29e:	movzx  eax,WORD PTR [r12+0x2a]
   6b2a4:	sub    eax,0x1
   6b2a7:	jmp    6b2c3 <sqlite3VdbeExec+0x1be23>
   6b2a9:	mov    rcx,rax
   6b2ac:	mov    edx,eax
   6b2ae:	add    edx,DWORD PTR [rbp+0x8]
   6b2b1:	movsxd rdx,edx
   6b2b4:	imul   rdx,rdx,0x38
   6b2b8:	add    rdx,rbx
   6b2bb:	mov    QWORD PTR [r12+rcx*8+0x30],rdx
   6b2c0:	sub    eax,0x1
   6b2c3:	test   eax,eax
   6b2c5:	jge    6b2a9 <sqlite3VdbeExec+0x1be09>
   6b2c7:	movzx  eax,WORD PTR [r13+0x14]
   6b2cc:	and    eax,0xfffff240
   6b2d1:	or     eax,0x1
   6b2d4:	mov    WORD PTR [r13+0x14],ax
   6b2d9:	mov    rax,QWORD PTR [r12+0x8]
   6b2de:	mov    rax,QWORD PTR [rax+0x18]
   6b2e2:	movzx  ecx,WORD PTR [r12+0x2a]
   6b2e8:	lea    rdx,[r12+0x30]
   6b2ed:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6b2f8:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6b303:	mov    QWORD PTR [rsp+0x190],rdi
   6b30b:	mov    rdi,r12
   6b30e:	mov    rsi,rcx
   6b311:	mov    r10,rax
   6b314:	call   r10
   6b317:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6b322:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6b32d:	mov    rdi,QWORD PTR [rsp+0x190]
   6b335:	cmp    DWORD PTR [r12+0x24],0x0
   6b33b:	je     6b645 <sqlite3VdbeExec+0x1c1a5>
   6b341:	cmp    DWORD PTR [r12+0x24],0x0
   6b347:	jle    6b42d <sqlite3VdbeExec+0x1bf8d>
   6b34d:	test   r13,r13
   6b350:	jne    6b356 <sqlite3VdbeExec+0x1beb6>
   6b352:	xor    eax,eax
   6b354:	jmp    6b3d0 <sqlite3VdbeExec+0x1bf30>
   6b356:	movzx  eax,WORD PTR [r13+0x14]
   6b35b:	and    eax,0x202
   6b360:	cmp    eax,0x202
   6b365:	jne    6b374 <sqlite3VdbeExec+0x1bed4>
   6b367:	cmp    BYTE PTR [r13+0x16],0x1
   6b36c:	jne    6b374 <sqlite3VdbeExec+0x1bed4>
   6b36e:	mov    rax,QWORD PTR [r13+0x8]
   6b372:	jmp    6b3d0 <sqlite3VdbeExec+0x1bf30>
   6b374:	movzx  eax,WORD PTR [r13+0x14]
   6b379:	and    eax,0x1
   6b37c:	test   eax,eax
   6b37e:	je     6b384 <sqlite3VdbeExec+0x1bee4>
   6b380:	xor    eax,eax
   6b382:	jmp    6b3d0 <sqlite3VdbeExec+0x1bf30>
   6b384:	mov    eax,0x1
   6b389:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6b394:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6b39f:	mov    QWORD PTR [rsp+0x190],rdi
   6b3a7:	mov    rdi,r13
   6b3aa:	mov    rsi,rax
   6b3ad:	call   6b3b2 <sqlite3VdbeExec+0x1bf12>
   6b3b2:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6b3bd:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6b3c8:	mov    rdi,QWORD PTR [rsp+0x190]
   6b3d0:	lea    r13,[rip+0x0]        # 6b3d7 <sqlite3VdbeExec+0x1bf37>
   6b3d7:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6b3e2:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6b3ed:	mov    QWORD PTR [rsp+0x190],rdi
   6b3f5:	mov    rsi,r13
   6b3f8:	mov    rdx,rax
   6b3fb:	xor    eax,eax
   6b3fd:	call   6b402 <sqlite3VdbeExec+0x1bf62>
   6b402:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6b40d:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6b418:	mov    r13d,DWORD PTR [r12+0x24]
   6b41d:	mov    rdi,QWORD PTR [rsp+0x190]
   6b425:	mov    DWORD PTR [rsp+0x40c],r13d
   6b42d:	lea    r13,[rdi+0x128]
   6b434:	mov    QWORD PTR [rsp+0x1e8],r13
   6b43c:	mov    r13d,DWORD PTR [r12+0x20]
   6b441:	mov    DWORD PTR [rsp+0x41c],r13d
   6b449:	mov    r13d,DWORD PTR [rbp+0x4]
   6b44d:	mov    DWORD PTR [rsp+0x424],r13d
   6b455:	mov    r13,QWORD PTR [rsp+0x1e8]
   6b45d:	jmp    6b463 <sqlite3VdbeExec+0x1bfc3>
   6b45f:	add    r13,0x18
   6b463:	cmp    QWORD PTR [r13+0x0],0x0
   6b468:	je     6b5f3 <sqlite3VdbeExec+0x1c153>
   6b46e:	mov    QWORD PTR [rsp+0x1c8],rbp
   6b476:	mov    rbp,QWORD PTR [r13+0x0]
   6b47a:	mov    DWORD PTR [rsp+0x3fc],r15d
   6b482:	mov    r15d,DWORD PTR [rsp+0x41c]
   6b48a:	test   r15d,r15d
   6b48d:	jge    6b49c <sqlite3VdbeExec+0x1bffc>
   6b48f:	mov    r15d,DWORD PTR [rsp+0x424]
   6b497:	jmp    6b52e <sqlite3VdbeExec+0x1c08e>
   6b49c:	cmp    r15d,DWORD PTR [rbp+0x0]
   6b4a0:	je     6b4bf <sqlite3VdbeExec+0x1c01f>
   6b4a2:	mov    DWORD PTR [rsp+0x41c],r15d
   6b4aa:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b4b2:	mov    r13,rbp
   6b4b5:	mov    rbp,QWORD PTR [rsp+0x1c8]
   6b4bd:	jmp    6b45f <sqlite3VdbeExec+0x1bfbf>
   6b4bf:	cmp    DWORD PTR [rbp+0x4],0x0
   6b4c3:	jge    6b4e5 <sqlite3VdbeExec+0x1c045>
   6b4c5:	mov    DWORD PTR [rsp+0x41c],r15d
   6b4cd:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b4d5:	mov    r13,rbp
   6b4d8:	mov    rbp,QWORD PTR [rsp+0x1c8]
   6b4e0:	jmp    6b45f <sqlite3VdbeExec+0x1bfbf>
   6b4e5:	cmp    DWORD PTR [rbp+0x4],0x1f
   6b4e9:	jle    6b4fd <sqlite3VdbeExec+0x1c05d>
   6b4eb:	mov    DWORD PTR [rsp+0x41c],r15d
   6b4f3:	mov    r15d,DWORD PTR [rsp+0x424]
   6b4fb:	jmp    6b52e <sqlite3VdbeExec+0x1c08e>
   6b4fd:	mov    eax,0x1
   6b502:	mov    ecx,DWORD PTR [rbp+0x4]
   6b505:	shl    eax,cl
   6b507:	mov    r15d,DWORD PTR [rsp+0x424]
   6b50f:	and    eax,r15d
   6b512:	test   eax,eax
   6b514:	je     6b52e <sqlite3VdbeExec+0x1c08e>
   6b516:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b51e:	mov    r13,rbp
   6b521:	mov    rbp,QWORD PTR [rsp+0x1c8]
   6b529:	jmp    6b45f <sqlite3VdbeExec+0x1bfbf>
   6b52e:	cmp    QWORD PTR [rbp+0x10],0x0
   6b533:	je     6b582 <sqlite3VdbeExec+0x1c0e2>
   6b535:	mov    rax,QWORD PTR [rbp+0x10]
   6b539:	mov    rcx,QWORD PTR [rbp+0x8]
   6b53d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6b548:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6b553:	mov    QWORD PTR [rsp+0x190],rdi
   6b55b:	mov    rdi,rcx
   6b55e:	mov    r10,rax
   6b561:	call   r10
   6b564:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6b56f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6b57a:	mov    rdi,QWORD PTR [rsp+0x190]
   6b582:	mov    rax,QWORD PTR [rbp+0x18]
   6b586:	mov    QWORD PTR [r13+0x0],rax
   6b58a:	test   rbp,rbp
   6b58d:	je     6b5d6 <sqlite3VdbeExec+0x1c136>
   6b58f:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6b59a:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6b5a5:	mov    QWORD PTR [rsp+0x190],rdi
   6b5ad:	mov    rdi,r14
   6b5b0:	mov    rsi,rbp
   6b5b3:	call   6b5b8 <sqlite3VdbeExec+0x1c118>
   6b5b8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6b5c3:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6b5ce:	mov    rdi,QWORD PTR [rsp+0x190]
   6b5d6:	mov    DWORD PTR [rsp+0x424],r15d
   6b5de:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b5e6:	mov    rbp,QWORD PTR [rsp+0x1c8]
   6b5ee:	jmp    6b463 <sqlite3VdbeExec+0x1bfc3>
   6b5f3:	mov    DWORD PTR [rsp+0x3fc],r15d
   6b5fb:	mov    QWORD PTR [rsp+0x1c8],rbp
   6b603:	mov    DWORD PTR [r12+0x24],0x0
   6b60c:	mov    ebp,DWORD PTR [rsp+0x40c]
   6b613:	test   ebp,ebp
   6b615:	jne    6b630 <sqlite3VdbeExec+0x1c190>
   6b617:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b61f:	mov    DWORD PTR [rsp+0x40c],ebp
   6b626:	mov    rbp,QWORD PTR [rsp+0x1c8]
   6b62e:	jmp    6b645 <sqlite3VdbeExec+0x1c1a5>
   6b630:	mov    r13,QWORD PTR [rsp+0x1b0]
   6b638:	mov    rbx,QWORD PTR [rsp+0x1d8]
   6b640:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   6b645:	mov    DWORD PTR [rsp+0x3fc],r15d
   6b64d:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6b652:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b65a:	mov    r13,QWORD PTR [rsp+0x1d0]
   6b662:	mov    QWORD PTR [rsp+0x1b0],r12
   6b66a:	mov    r12d,DWORD PTR [rsp+0x414]
   6b672:	movsxd rax,DWORD PTR [rbp+0x4]
   6b676:	imul   rax,rax,0x38
   6b67a:	movzx  ecx,WORD PTR [rbx+rax*1+0x14]
   6b67f:	and    ecx,0xfffff7ff
   6b685:	mov    WORD PTR [rbx+rax*1+0x14],cx
   6b68a:	mov    DWORD PTR [rsp+0x3fc],r15d
   6b692:	mov    QWORD PTR [rsp+0x1d0],r13
   6b69a:	mov    DWORD PTR [rsp+0x414],r12d
   6b6a2:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6b6a7:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b6af:	mov    r13,QWORD PTR [rsp+0x1d0]
   6b6b7:	mov    QWORD PTR [rsp+0x1b0],r12
   6b6bf:	mov    r12d,DWORD PTR [rsp+0x414]
   6b6c7:	movsxd rax,DWORD PTR [rbp+0x4]
   6b6cb:	imul   rax,rax,0x38
   6b6cf:	movsxd rcx,DWORD PTR [rbp+0x8]
   6b6d3:	imul   rcx,rcx,0x38
   6b6d7:	add    rcx,rbx
   6b6da:	movzx  edx,WORD PTR [rbx+rax*1+0x14]
   6b6df:	and    edx,0x800
   6b6e5:	test   edx,edx
   6b6e7:	je     6b750 <sqlite3VdbeExec+0x1c2b0>
   6b6e9:	movzx  eax,BYTE PTR [rbx+rax*1+0x17]
   6b6ee:	movzx  edx,WORD PTR [rcx+0x14]
   6b6f2:	and    edx,0x9000
   6b6f8:	test   edx,edx
   6b6fa:	je     6b745 <sqlite3VdbeExec+0x1c2a5>
   6b6fc:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6b707:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6b712:	mov    QWORD PTR [rsp+0x190],rdi
   6b71a:	mov    rdi,rcx
   6b71d:	mov    rsi,rax
   6b720:	call   6b725 <sqlite3VdbeExec+0x1c285>
   6b725:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6b730:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6b73b:	mov    rdi,QWORD PTR [rsp+0x190]
   6b743:	jmp    6b7a9 <sqlite3VdbeExec+0x1c309>
   6b745:	mov    QWORD PTR [rcx],rax
   6b748:	mov    WORD PTR [rcx+0x14],0x4
   6b74e:	jmp    6b7a9 <sqlite3VdbeExec+0x1c309>
   6b750:	movzx  eax,WORD PTR [rcx+0x14]
   6b754:	and    eax,0x9000
   6b759:	test   eax,eax
   6b75b:	je     6b7a3 <sqlite3VdbeExec+0x1c303>
   6b75d:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6b768:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6b773:	mov    QWORD PTR [rsp+0x190],rdi
   6b77b:	mov    rdi,rcx
   6b77e:	call   6b783 <sqlite3VdbeExec+0x1c2e3>
   6b783:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6b78e:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6b799:	mov    rdi,QWORD PTR [rsp+0x190]
   6b7a1:	jmp    6b7a9 <sqlite3VdbeExec+0x1c309>
   6b7a3:	mov    WORD PTR [rcx+0x14],0x1
   6b7a9:	mov    DWORD PTR [rsp+0x3fc],r15d
   6b7b1:	mov    QWORD PTR [rsp+0x1d0],r13
   6b7b9:	mov    DWORD PTR [rsp+0x414],r12d
   6b7c1:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6b7c6:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b7ce:	mov    r13,QWORD PTR [rsp+0x1d0]
   6b7d6:	mov    QWORD PTR [rsp+0x1b0],r12
   6b7de:	mov    r12d,DWORD PTR [rsp+0x414]
   6b7e6:	movsxd rax,DWORD PTR [rbp+0x4]
   6b7ea:	imul   rax,rax,0x38
   6b7ee:	movsxd rcx,DWORD PTR [rbp+0x8]
   6b7f2:	imul   rcx,rcx,0x38
   6b7f6:	movzx  edx,WORD PTR [rbx+rax*1+0x14]
   6b7fb:	and    edx,0x1
   6b7fe:	test   edx,edx
   6b800:	je     6b813 <sqlite3VdbeExec+0x1c373>
   6b802:	movzx  eax,WORD PTR [rbx+rcx*1+0x14]
   6b807:	and    eax,0xfffff7ff
   6b80c:	mov    WORD PTR [rbx+rcx*1+0x14],ax
   6b811:	jmp    6b831 <sqlite3VdbeExec+0x1c391>
   6b813:	movzx  edx,WORD PTR [rbx+rcx*1+0x14]
   6b818:	or     edx,0x800
   6b81e:	mov    WORD PTR [rbx+rcx*1+0x14],dx
   6b823:	mov    rax,QWORD PTR [rbx+rax*1]
   6b827:	and    rax,0xff
   6b82d:	mov    BYTE PTR [rbx+rcx*1+0x17],al
   6b831:	mov    DWORD PTR [rsp+0x3fc],r15d
   6b839:	mov    QWORD PTR [rsp+0x1d0],r13
   6b841:	mov    DWORD PTR [rsp+0x414],r12d
   6b849:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6b84e:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b856:	mov    r13,QWORD PTR [rsp+0x1d0]
   6b85e:	mov    QWORD PTR [rsp+0x1b0],r12
   6b866:	mov    r12d,DWORD PTR [rsp+0x414]
   6b86e:	movsxd rax,DWORD PTR [rbp+0x4]
   6b872:	mov    DWORD PTR [rsp+0x414],r12d
   6b87a:	imul   r12,rax,0x38
   6b87e:	mov    QWORD PTR [rsp+0x1e8],r12
   6b886:	movsxd r12,DWORD PTR [rbp+0xc]
   6b88a:	mov    QWORD PTR [rsp+0x208],r12
   6b892:	add    r12d,DWORD PTR [rbp+0x10]
   6b896:	mov    DWORD PTR [rsp+0x3fc],r15d
   6b89e:	mov    DWORD PTR [rsp+0x424],r12d
   6b8a6:	mov    r12,QWORD PTR [rsp+0x208]
   6b8ae:	xor    r15d,r15d
   6b8b1:	jmp    6b9ef <sqlite3VdbeExec+0x1c54f>
   6b8b6:	mov    DWORD PTR [rsp+0x424],r13d
   6b8be:	mov    QWORD PTR [rsp+0x208],r12
   6b8c6:	mov    r12,r15
   6b8c9:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6b8d1:	mov    rax,rcx
   6b8d4:	mov    r13,QWORD PTR [rsp+0x1d0]
   6b8dc:	movzx  ecx,WORD PTR [rax+0x14]
   6b8e0:	and    ecx,0x8
   6b8e3:	test   ecx,ecx
   6b8e5:	je     6b9b1 <sqlite3VdbeExec+0x1c511>
   6b8eb:	movzx  ecx,WORD PTR [rax+0x14]
   6b8ef:	mov    edx,ecx
   6b8f1:	and    edx,0x24
   6b8f4:	test   edx,edx
   6b8f6:	je     6b900 <sqlite3VdbeExec+0x1c460>
   6b8f8:	mov    rax,QWORD PTR [rax]
   6b8fb:	jmp    6b9ac <sqlite3VdbeExec+0x1c50c>
   6b900:	mov    edx,ecx
   6b902:	and    edx,0x8
   6b905:	test   edx,edx
   6b907:	je     6b956 <sqlite3VdbeExec+0x1c4b6>
   6b909:	movsd  xmm2,QWORD PTR [rax]
   6b90d:	movabs r11,0xc3dfffffffffffff
   6b917:	movq   xmm3,r11
   6b91c:	ucomisd xmm3,xmm2
   6b920:	jbe    6b92e <sqlite3VdbeExec+0x1c48e>
   6b922:	movabs rax,0x8000000000000000
   6b92c:	jmp    6b954 <sqlite3VdbeExec+0x1c4b4>
   6b92e:	movabs r11,0x43dfffffffffffff
   6b938:	movq   xmm3,r11
   6b93d:	ucomisd xmm2,xmm3
   6b941:	jbe    6b94f <sqlite3VdbeExec+0x1c4af>
   6b943:	movabs rax,0x7fffffffffffffff
   6b94d:	jmp    6b954 <sqlite3VdbeExec+0x1c4b4>
   6b94f:	cvttsd2si rax,xmm2
   6b954:	jmp    6b9ac <sqlite3VdbeExec+0x1c50c>
   6b956:	and    ecx,0x12
   6b959:	test   ecx,ecx
   6b95b:	je     6b9aa <sqlite3VdbeExec+0x1c50a>
   6b95d:	cmp    QWORD PTR [rax+0x8],0x0
   6b962:	je     6b9aa <sqlite3VdbeExec+0x1c50a>
   6b964:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6b96f:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6b97a:	mov    QWORD PTR [rsp+0x190],rdi
   6b982:	mov    rdi,rax
   6b985:	call   6b98a <sqlite3VdbeExec+0x1c4ea>
   6b98a:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6b995:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6b9a0:	mov    rdi,QWORD PTR [rsp+0x190]
   6b9a8:	jmp    6b9ac <sqlite3VdbeExec+0x1c50c>
   6b9aa:	xor    eax,eax
   6b9ac:	add    r12,rax
   6b9af:	jmp    6b9cb <sqlite3VdbeExec+0x1c52b>
   6b9b1:	movzx  ecx,WORD PTR [rax+0x14]
   6b9b5:	and    ecx,0x12
   6b9b8:	test   ecx,ecx
   6b9ba:	je     6b9cb <sqlite3VdbeExec+0x1c52b>
   6b9bc:	movzx  eax,WORD PTR [rax+0x14]
   6b9c0:	and    eax,0x12
   6b9c3:	add    eax,0xffd
   6b9c8:	add    r12,rax
   6b9cb:	mov    QWORD PTR [rsp+0x200],r12
   6b9d3:	mov    r12,QWORD PTR [rsp+0x208]
   6b9db:	add    r12d,0x1
   6b9df:	mov    DWORD PTR [rsp+0x3fc],r15d
   6b9e7:	mov    r15,QWORD PTR [rsp+0x200]
   6b9ef:	mov    QWORD PTR [rsp+0x1d0],r13
   6b9f7:	mov    r13d,DWORD PTR [rsp+0x424]
   6b9ff:	cmp    r12d,r13d
   6ba02:	jge    6ba47 <sqlite3VdbeExec+0x1c5a7>
   6ba04:	movsxd rax,r12d
   6ba07:	imul   rax,rax,0x38
   6ba0b:	lea    rcx,[rbx+rax*1]
   6ba0f:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   6ba14:	and    eax,0x24
   6ba17:	test   eax,eax
   6ba19:	je     6b8b6 <sqlite3VdbeExec+0x1c416>
   6ba1f:	add    r15,QWORD PTR [rcx]
   6ba22:	mov    DWORD PTR [rsp+0x424],r13d
   6ba2a:	mov    QWORD PTR [rsp+0x208],r12
   6ba32:	mov    r13,QWORD PTR [rsp+0x1d0]
   6ba3a:	mov    r12,r15
   6ba3d:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6ba45:	jmp    6b9cb <sqlite3VdbeExec+0x1c52b>
   6ba47:	mov    r12,QWORD PTR [rsp+0x1e8]
   6ba4f:	mov    rax,r15
   6ba52:	mov    ecx,DWORD PTR [rbx+r12*1+0x10]
   6ba57:	shl    ecx,0x3
   6ba5a:	movsxd rcx,ecx
   6ba5d:	xor    edx,edx
   6ba5f:	div    rcx
   6ba62:	mov    rax,rdx
   6ba65:	mov    rdx,QWORD PTR [rbx+r12*1+0x8]
   6ba6a:	mov    rsi,rax
   6ba6d:	shr    rsi,0x3
   6ba71:	movsx  r8d,BYTE PTR [rdx+rsi*1]
   6ba76:	mov    r9d,0x1
   6ba7c:	and    rax,0x7
   6ba80:	mov    ecx,eax
   6ba82:	mov    rax,r9
   6ba85:	shl    eax,cl
   6ba87:	or     r8d,eax
   6ba8a:	mov    BYTE PTR [rdx+rsi*1],r8b
   6ba8e:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6ba93:	mov    QWORD PTR [rsp+0x1b0],r12
   6ba9b:	movsxd rax,DWORD PTR [rbp+0x4]
   6ba9f:	imul   r12,rax,0x38
   6baa3:	movsxd r15,DWORD PTR [rbp+0xc]
   6baa7:	mov    r13d,r15d
   6baaa:	add    r13d,DWORD PTR [rbp+0x10]
   6baae:	mov    DWORD PTR [rsp+0x424],r13d
   6bab6:	xor    r13d,r13d
   6bab9:	jmp    6bbc4 <sqlite3VdbeExec+0x1c724>
   6babe:	mov    DWORD PTR [rsp+0x424],r12d
   6bac6:	mov    r12,QWORD PTR [rsp+0x1e8]
   6bace:	mov    rax,rcx
   6bad1:	movzx  ecx,WORD PTR [rax+0x14]
   6bad5:	and    ecx,0x8
   6bad8:	test   ecx,ecx
   6bada:	je     6bba6 <sqlite3VdbeExec+0x1c706>
   6bae0:	movzx  ecx,WORD PTR [rax+0x14]
   6bae4:	mov    edx,ecx
   6bae6:	and    edx,0x24
   6bae9:	test   edx,edx
   6baeb:	je     6baf5 <sqlite3VdbeExec+0x1c655>
   6baed:	mov    rax,QWORD PTR [rax]
   6baf0:	jmp    6bba1 <sqlite3VdbeExec+0x1c701>
   6baf5:	mov    edx,ecx
   6baf7:	and    edx,0x8
   6bafa:	test   edx,edx
   6bafc:	je     6bb4b <sqlite3VdbeExec+0x1c6ab>
   6bafe:	movsd  xmm2,QWORD PTR [rax]
   6bb02:	movabs r11,0xc3dfffffffffffff
   6bb0c:	movq   xmm3,r11
   6bb11:	ucomisd xmm3,xmm2
   6bb15:	jbe    6bb23 <sqlite3VdbeExec+0x1c683>
   6bb17:	movabs rax,0x8000000000000000
   6bb21:	jmp    6bb49 <sqlite3VdbeExec+0x1c6a9>
   6bb23:	movabs r11,0x43dfffffffffffff
   6bb2d:	movq   xmm3,r11
   6bb32:	ucomisd xmm2,xmm3
   6bb36:	jbe    6bb44 <sqlite3VdbeExec+0x1c6a4>
   6bb38:	movabs rax,0x7fffffffffffffff
   6bb42:	jmp    6bb49 <sqlite3VdbeExec+0x1c6a9>
   6bb44:	cvttsd2si rax,xmm2
   6bb49:	jmp    6bba1 <sqlite3VdbeExec+0x1c701>
   6bb4b:	and    ecx,0x12
   6bb4e:	test   ecx,ecx
   6bb50:	je     6bb9f <sqlite3VdbeExec+0x1c6ff>
   6bb52:	cmp    QWORD PTR [rax+0x8],0x0
   6bb57:	je     6bb9f <sqlite3VdbeExec+0x1c6ff>
   6bb59:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6bb64:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6bb6f:	mov    QWORD PTR [rsp+0x190],rdi
   6bb77:	mov    rdi,rax
   6bb7a:	call   6bb7f <sqlite3VdbeExec+0x1c6df>
   6bb7f:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6bb8a:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6bb95:	mov    rdi,QWORD PTR [rsp+0x190]
   6bb9d:	jmp    6bba1 <sqlite3VdbeExec+0x1c701>
   6bb9f:	xor    eax,eax
   6bba1:	add    r13,rax
   6bba4:	jmp    6bbc0 <sqlite3VdbeExec+0x1c720>
   6bba6:	movzx  ecx,WORD PTR [rax+0x14]
   6bbaa:	and    ecx,0x12
   6bbad:	test   ecx,ecx
   6bbaf:	je     6bbc0 <sqlite3VdbeExec+0x1c720>
   6bbb1:	movzx  eax,WORD PTR [rax+0x14]
   6bbb5:	and    eax,0x12
   6bbb8:	add    eax,0xffd
   6bbbd:	add    r13,rax
   6bbc0:	add    r15d,0x1
   6bbc4:	mov    QWORD PTR [rsp+0x1e8],r12
   6bbcc:	mov    r12d,DWORD PTR [rsp+0x424]
   6bbd4:	cmp    r15d,r12d
   6bbd7:	jge    6bc09 <sqlite3VdbeExec+0x1c769>
   6bbd9:	movsxd rax,r15d
   6bbdc:	imul   rax,rax,0x38
   6bbe0:	lea    rcx,[rbx+rax*1]
   6bbe4:	movzx  eax,WORD PTR [rbx+rax*1+0x14]
   6bbe9:	and    eax,0x24
   6bbec:	test   eax,eax
   6bbee:	je     6babe <sqlite3VdbeExec+0x1c61e>
   6bbf4:	add    r13,QWORD PTR [rcx]
   6bbf7:	mov    DWORD PTR [rsp+0x424],r12d
   6bbff:	mov    r12,QWORD PTR [rsp+0x1e8]
   6bc07:	jmp    6bbc0 <sqlite3VdbeExec+0x1c720>
   6bc09:	mov    r12,QWORD PTR [rsp+0x1e8]
   6bc11:	mov    rax,r13
   6bc14:	mov    ecx,DWORD PTR [rbx+r12*1+0x10]
   6bc19:	shl    ecx,0x3
   6bc1c:	movsxd rcx,ecx
   6bc1f:	xor    edx,edx
   6bc21:	div    rcx
   6bc24:	mov    rax,rdx
   6bc27:	mov    rcx,QWORD PTR [rbx+r12*1+0x8]
   6bc2c:	mov    rdx,rax
   6bc2f:	shr    rdx,0x3
   6bc33:	movsx  edx,BYTE PTR [rcx+rdx*1]
   6bc37:	mov    esi,0x1
   6bc3c:	and    rax,0x7
   6bc40:	mov    ecx,eax
   6bc42:	mov    rax,rsi
   6bc45:	shl    eax,cl
   6bc47:	and    edx,eax
   6bc49:	test   edx,edx
   6bc4b:	jne    6bc6c <sqlite3VdbeExec+0x1c7cc>
   6bc4d:	mov    eax,DWORD PTR [rdi+0xf4]
   6bc53:	add    eax,0x1
   6bc56:	mov    DWORD PTR [rdi+0xf4],eax
   6bc5c:	mov    r12,r14
   6bc5f:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6bc67:	jmp    52730 <sqlite3VdbeExec+0x3290>
   6bc6c:	mov    eax,DWORD PTR [rdi+0xf0]
   6bc72:	add    eax,0x1
   6bc75:	mov    DWORD PTR [rdi+0xf0],eax
   6bc7b:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6bc80:	mov    QWORD PTR [rsp+0x1b0],r12
   6bc88:	movzx  eax,BYTE PTR [r14+0x6e]
   6bc8d:	and    eax,0x41
   6bc90:	test   eax,eax
   6bc92:	je     6bff7 <sqlite3VdbeExec+0x1cb57>
   6bc98:	cmp    BYTE PTR [rdi+0xc5],0xfe
   6bc9f:	je     6bff7 <sqlite3VdbeExec+0x1cb57>
   6bca5:	cmp    QWORD PTR [rbp+0x10],0x0
   6bcaa:	je     6bcb2 <sqlite3VdbeExec+0x1c812>
   6bcac:	mov    rax,QWORD PTR [rbp+0x10]
   6bcb0:	jmp    6bcb9 <sqlite3VdbeExec+0x1c819>
   6bcb2:	mov    rax,QWORD PTR [rdi+0xf8]
   6bcb9:	test   rax,rax
   6bcbc:	je     6bff7 <sqlite3VdbeExec+0x1cb57>
   6bcc2:	movzx  ecx,BYTE PTR [r14+0x6e]
   6bcc7:	and    ecx,0x40
   6bcca:	test   ecx,ecx
   6bccc:	je     6be80 <sqlite3VdbeExec+0x1c9e0>
   6bcd2:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6bcdd:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6bce8:	mov    QWORD PTR [rsp+0x190],rdi
   6bcf0:	mov    rsi,rax
   6bcf3:	call   6bcf8 <sqlite3VdbeExec+0x1c858>
   6bcf8:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6bd03:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6bd0e:	mov    rcx,QWORD PTR [r14+0xf0]
   6bd15:	mov    rdx,QWORD PTR [r14+0xf8]
   6bd1c:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6bd27:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6bd32:	mov    QWORD PTR [rsp+0x188],rax
   6bd3a:	mov    rdi,rdx
   6bd3d:	mov    rsi,rax
   6bd40:	mov    r10,rcx
   6bd43:	call   r10
   6bd46:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6bd51:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6bd5c:	mov    rax,QWORD PTR [rsp+0x188]
   6bd64:	mov    rdi,QWORD PTR [rsp+0x190]
   6bd6c:	test   rax,rax
   6bd6f:	je     6bff7 <sqlite3VdbeExec+0x1cb57>
   6bd75:	cmp    DWORD PTR [rip+0x0],0x0        # 6bd7c <sqlite3VdbeExec+0x1c8dc>
   6bd7c:	je     6be37 <sqlite3VdbeExec+0x1c997>
   6bd82:	mov    rcx,QWORD PTR [rip+0x0]        # 6bd89 <sqlite3VdbeExec+0x1c8e9>
   6bd89:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6bd94:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6bd9f:	mov    rdi,rax
   6bda2:	mov    r10,rcx
   6bda5:	call   r10
   6bda8:	mov    ecx,eax
   6bdaa:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6bdb5:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6bdc0:	mov    rdx,QWORD PTR [rip+0x0]        # 6bdc7 <sqlite3VdbeExec+0x1c927>
   6bdc7:	movsxd rcx,ecx
   6bdca:	sub    rdx,rcx
   6bdcd:	mov    QWORD PTR [rip+0x0],rdx        # 6bdd4 <sqlite3VdbeExec+0x1c934>
   6bdd4:	mov    rcx,QWORD PTR [rip+0x0]        # 6bddb <sqlite3VdbeExec+0x1c93b>
   6bddb:	sub    rcx,0x1
   6bddf:	mov    QWORD PTR [rip+0x0],rcx        # 6bde6 <sqlite3VdbeExec+0x1c946>
   6bde6:	mov    rcx,QWORD PTR [rip+0x0]        # 6bded <sqlite3VdbeExec+0x1c94d>
   6bded:	mov    rax,QWORD PTR [rsp+0x188]
   6bdf5:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6be00:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6be0b:	mov    rdi,rax
   6be0e:	mov    r10,rcx
   6be11:	call   r10
   6be14:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6be1f:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6be2a:	mov    rdi,QWORD PTR [rsp+0x190]
   6be32:	jmp    6bff7 <sqlite3VdbeExec+0x1cb57>
   6be37:	mov    rcx,QWORD PTR [rip+0x0]        # 6be3e <sqlite3VdbeExec+0x1c99e>
   6be3e:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6be49:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6be54:	mov    rdi,rax
   6be57:	mov    r10,rcx
   6be5a:	call   r10
   6be5d:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6be68:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6be73:	mov    rdi,QWORD PTR [rsp+0x190]
   6be7b:	jmp    6bff7 <sqlite3VdbeExec+0x1cb57>
   6be80:	cmp    DWORD PTR [r14+0xdc],0x1
   6be88:	jle    6bf96 <sqlite3VdbeExec+0x1caf6>
   6be8e:	lea    rcx,[rip+0x0]        # 6be95 <sqlite3VdbeExec+0x1c9f5>
   6be95:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6bea0:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6beab:	mov    QWORD PTR [rsp+0x190],rdi
   6beb3:	mov    rdi,r14
   6beb6:	mov    rsi,rcx
   6beb9:	mov    rdx,rax
   6bebc:	xor    eax,eax
   6bebe:	call   6bec3 <sqlite3VdbeExec+0x1ca23>
   6bec3:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6bece:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6bed9:	mov    rcx,QWORD PTR [r14+0xf0]
   6bee0:	mov    edx,0x1
   6bee5:	mov    rsi,QWORD PTR [r14+0xf8]
   6beec:	mov    rdi,QWORD PTR [rsp+0x190]
   6bef4:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6beff:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6bf0a:	mov    QWORD PTR [rsp+0x188],rax
   6bf12:	mov    r10,rcx
   6bf15:	mov    rcx,rax
   6bf18:	mov    r11,rdi
   6bf1b:	mov    rdi,rdx
   6bf1e:	mov    rdx,r11
   6bf21:	call   r10
   6bf24:	mov    ecx,eax
   6bf26:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6bf31:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6bf3c:	mov    rax,QWORD PTR [rsp+0x188]
   6bf44:	mov    rdi,QWORD PTR [rsp+0x190]
   6bf4c:	test   rax,rax
   6bf4f:	je     6bff7 <sqlite3VdbeExec+0x1cb57>
   6bf55:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6bf60:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6bf6b:	mov    rdi,r14
   6bf6e:	mov    rsi,rax
   6bf71:	call   6bf76 <sqlite3VdbeExec+0x1cad6>
   6bf76:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6bf81:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6bf8c:	mov    rdi,QWORD PTR [rsp+0x190]
   6bf94:	jmp    6bff7 <sqlite3VdbeExec+0x1cb57>
   6bf96:	mov    rcx,QWORD PTR [r14+0xf0]
   6bf9d:	mov    edx,0x1
   6bfa2:	mov    rsi,QWORD PTR [r14+0xf8]
   6bfa9:	vmovdqu32 ZMMWORD PTR [rsp+0x10],zmm0
   6bfb4:	vmovdqu32 ZMMWORD PTR [rsp+0x50],zmm1
   6bfbf:	mov    QWORD PTR [rsp+0x190],rdi
   6bfc7:	mov    r10,rcx
   6bfca:	mov    rcx,rax
   6bfcd:	mov    r11,rdi
   6bfd0:	mov    rdi,rdx
   6bfd3:	mov    rdx,r11
   6bfd6:	call   r10
   6bfd9:	vmovdqu32 zmm0,ZMMWORD PTR [rsp+0x10]
   6bfe4:	vmovdqu32 zmm1,ZMMWORD PTR [rsp+0x50]
   6bfef:	mov    rdi,QWORD PTR [rsp+0x190]
   6bff7:	mov    eax,DWORD PTR [rbp+0x4]
   6bffa:	cmp    eax,DWORD PTR [rip+0x0]        # 6c000 <sqlite3VdbeExec+0x1cb60>
   6c000:	jl     6c04d <sqlite3VdbeExec+0x1cbad>
   6c002:	cmp    BYTE PTR [rbp+0x0],0xba
   6c006:	jne    6c00a <sqlite3VdbeExec+0x1cb6a>
   6c008:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6c00a:	mov    eax,0x1
   6c00f:	jmp    6c03e <sqlite3VdbeExec+0x1cb9e>
   6c011:	mov    rcx,QWORD PTR [rdi+0x88]
   6c018:	mov    rdx,rax
   6c01b:	imul   rdx,rdx,0x18
   6c01f:	cmp    BYTE PTR [rcx+rdx*1],0xf
   6c023:	jne    6c03b <sqlite3VdbeExec+0x1cb9b>
   6c025:	mov    rcx,QWORD PTR [rdi+0x88]
   6c02c:	mov    rdx,rax
   6c02f:	imul   rdx,rdx,0x18
   6c033:	mov    DWORD PTR [rcx+rdx*1+0x4],0x0
   6c03b:	add    eax,0x1
   6c03e:	cmp    eax,DWORD PTR [rdi+0x90]
   6c044:	jl     6c011 <sqlite3VdbeExec+0x1cb71>
   6c046:	mov    DWORD PTR [rbp+0x4],0x0
   6c04d:	mov    eax,DWORD PTR [rbp+0x4]
   6c050:	add    eax,0x1
   6c053:	mov    DWORD PTR [rbp+0x4],eax
   6c056:	mov    eax,DWORD PTR [rdi+0xec]
   6c05c:	add    eax,0x1
   6c05f:	mov    DWORD PTR [rdi+0xec],eax
   6c065:	mov    r12,r14
   6c068:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6c070:	jmp    52730 <sqlite3VdbeExec+0x3290>
   6c075:	add    rbp,0x18
   6c079:	mov    r12,QWORD PTR [rsp+0x1b0]
   6c081:	add    r12,0x1
   6c085:	movzx  eax,BYTE PTR [rbp+0x0]
   6c089:	cmp    eax,0xba
   6c08e:	jbe    6c09a <sqlite3VdbeExec+0x1cbfa>
   6c090:	mov    QWORD PTR [rsp+0x1b0],r12
   6c098:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6c09a:	lea    r13,[rip+0x0]        # 6c0a1 <sqlite3VdbeExec+0x1cc01>
   6c0a1:	movsxd rax,DWORD PTR [r13+rax*4+0x0]
   6c0a6:	add    rax,r13
   6c0a9:	jmp    rax
   6c0ab:	mov    QWORD PTR [rsp+0x1b0],r12
   6c0b3:	jmp    6c075 <sqlite3VdbeExec+0x1cbd5>
   6c0b5:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6c0bd:	mov    r13,QWORD PTR [rsp+0x1d0]
   6c0c5:	mov    QWORD PTR [rsp+0x1b0],r12
   6c0cd:	mov    r12d,DWORD PTR [rsp+0x414]
   6c0d5:	jmp    4f80d <sqlite3VdbeExec+0x36d>
   6c0da:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6c0e2:	mov    r13,QWORD PTR [rsp+0x1d0]
   6c0ea:	mov    QWORD PTR [rsp+0x1b0],r12
   6c0f2:	mov    r12d,DWORD PTR [rsp+0x414]
   6c0fa:	jmp    5a5d7 <sqlite3VdbeExec+0xb137>
   6c0ff:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6c107:	mov    r13,QWORD PTR [rsp+0x1d0]
   6c10f:	mov    QWORD PTR [rsp+0x1b0],r12
   6c117:	jmp    5abca <sqlite3VdbeExec+0xb72a>
   6c11c:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6c124:	mov    QWORD PTR [rsp+0x1b0],r12
   6c12c:	jmp    5dc54 <sqlite3VdbeExec+0xe7b4>
   6c131:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6c139:	mov    r13,QWORD PTR [rsp+0x1d0]
   6c141:	mov    QWORD PTR [rsp+0x1b0],r12
   6c149:	mov    r12d,DWORD PTR [rsp+0x414]
   6c151:	jmp    4faab <sqlite3VdbeExec+0x60b>
   6c156:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6c15e:	mov    QWORD PTR [rsp+0x1b0],r12
   6c166:	jmp    501db <sqlite3VdbeExec+0xd3b>
   6c16b:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6c173:	mov    r13,QWORD PTR [rsp+0x1d0]
   6c17b:	mov    QWORD PTR [rsp+0x1b0],r12
   6c183:	jmp    58528 <sqlite3VdbeExec+0x9088>
   6c188:	mov    r15d,DWORD PTR [rsp+0x3fc]
   6c190:	mov    r13,QWORD PTR [rsp+0x1d0]
   6c198:	mov    QWORD PTR [rsp+0x1b0],r12
   6c1a0:	jmp    65b5a <sqlite3VdbeExec+0x166ba>
   6c1a5:	cmp    ebp,0x210a
   6c1ab:	jne    6c1db <sqlite3VdbeExec+0x1cd3b>
   6c1ad:	mov    eax,0x19d26
   6c1b2:	mov    ecx,0xb
   6c1b7:	lea    rdx,[rip+0x0]        # 6c1be <sqlite3VdbeExec+0x1cd1e>
   6c1be:	mov    QWORD PTR [rsp+0x190],rdi
   6c1c6:	mov    rdi,rcx
   6c1c9:	mov    rsi,rax
   6c1cc:	call   6c1d1 <sqlite3VdbeExec+0x1cd31>
   6c1d1:	mov    ebp,eax
   6c1d3:	mov    rdi,QWORD PTR [rsp+0x190]
   6c1db:	cmp    QWORD PTR [rdi+0xa8],0x0
   6c1e3:	jne    6c26c <sqlite3VdbeExec+0x1cdcc>
   6c1e9:	cmp    ebp,0xc0a
   6c1ef:	je     6c26c <sqlite3VdbeExec+0x1cdcc>
   6c1f1:	lea    rax,[rip+0x0]        # 6c1f8 <sqlite3VdbeExec+0x1cd58>
   6c1f8:	lea    rcx,[rip+0x0]        # 6c1ff <sqlite3VdbeExec+0x1cd5f>
   6c1ff:	cmp    ebp,0x204
   6c205:	je     6c21a <sqlite3VdbeExec+0x1cd7a>
   6c207:	cmp    ebp,0x64
   6c20a:	je     6c223 <sqlite3VdbeExec+0x1cd83>
   6c20c:	cmp    ebp,0x65
   6c20f:	jne    6c22c <sqlite3VdbeExec+0x1cd8c>
   6c211:	lea    rcx,[rip+0x0]        # 6c218 <sqlite3VdbeExec+0x1cd78>
   6c218:	jmp    6c24f <sqlite3VdbeExec+0x1cdaf>
   6c21a:	lea    rcx,[rip+0x0]        # 6c221 <sqlite3VdbeExec+0x1cd81>
   6c221:	jmp    6c24f <sqlite3VdbeExec+0x1cdaf>
   6c223:	lea    rcx,[rip+0x0]        # 6c22a <sqlite3VdbeExec+0x1cd8a>
   6c22a:	jmp    6c24f <sqlite3VdbeExec+0x1cdaf>
   6c22c:	mov    edx,ebp
   6c22e:	and    edx,0xff
   6c234:	test   edx,edx
   6c236:	jl     6c24f <sqlite3VdbeExec+0x1cdaf>
   6c238:	cmp    edx,0x1d
   6c23b:	jge    6c24f <sqlite3VdbeExec+0x1cdaf>
   6c23d:	lea    rsi,[rip+0x0]        # 6c244 <sqlite3VdbeExec+0x1cda4>
   6c244:	mov    rdx,QWORD PTR [rsi+rdx*8]
   6c248:	test   rdx,rdx
   6c24b:	cmovne rcx,rdx
   6c24f:	mov    QWORD PTR [rsp+0x190],rdi
   6c257:	mov    rsi,rax
   6c25a:	mov    rdx,rcx
   6c25d:	xor    eax,eax
   6c25f:	call   6c264 <sqlite3VdbeExec+0x1cdc4>
   6c264:	mov    rdi,QWORD PTR [rsp+0x190]
   6c26c:	mov    DWORD PTR [rdi+0x34],ebp
   6c26f:	cmp    ebp,0xc0a
   6c275:	je     6c2ca <sqlite3VdbeExec+0x1ce2a>
   6c277:	mov    eax,ebp
   6c279:	and    eax,0xff
   6c27e:	cmp    eax,0xe
   6c281:	je     6c288 <sqlite3VdbeExec+0x1cde8>
   6c283:	cmp    eax,0xa
   6c286:	jne    6c2ca <sqlite3VdbeExec+0x1ce2a>
   6c288:	mov    rax,QWORD PTR [r14]
   6c28b:	cmp    QWORD PTR [rax+0x80],0x0
   6c293:	je     6c2c4 <sqlite3VdbeExec+0x1ce24>
   6c295:	mov    rcx,QWORD PTR [rax+0x80]
   6c29c:	xor    edx,edx
   6c29e:	xor    esi,esi
   6c2a0:	mov    QWORD PTR [rsp+0x190],rdi
   6c2a8:	mov    rdi,rax
   6c2ab:	mov    r10,rcx
   6c2ae:	mov    r11,rsi
   6c2b1:	mov    rsi,rdx
   6c2b4:	mov    rdx,r11
   6c2b7:	call   r10
   6c2ba:	mov    rdi,QWORD PTR [rsp+0x190]
   6c2c2:	jmp    6c2c6 <sqlite3VdbeExec+0x1ce26>
   6c2c4:	xor    eax,eax
   6c2c6:	mov    DWORD PTR [r14+0x5c],eax
   6c2ca:	mov    r12,QWORD PTR [rsp+0x1d0]
   6c2d2:	mov    r15,QWORD PTR [rsp+0x1c8]
   6c2da:	mov    QWORD PTR [rsp+0x190],rdi
   6c2e2:	mov    rsi,rbp
   6c2e5:	mov    rdx,r15
   6c2e8:	mov    rcx,r12
   6c2eb:	call   6c2f0 <sqlite3VdbeExec+0x1ce50>
   6c2f0:	mov    rdi,QWORD PTR [rsp+0x190]
   6c2f8:	cmp    BYTE PTR [rdi+0xc7],0x2
   6c2ff:	jne    6c30e <sqlite3VdbeExec+0x1ce6e>
   6c301:	call   6c306 <sqlite3VdbeExec+0x1ce66>
   6c306:	mov    rdi,QWORD PTR [rsp+0x190]
   6c30e:	cmp    ebp,0xc0a
   6c314:	jne    6c32e <sqlite3VdbeExec+0x1ce8e>
   6c316:	mov    QWORD PTR [rsp+0x190],rdi
   6c31e:	mov    rdi,r14
   6c321:	call   6c326 <sqlite3VdbeExec+0x1ce86>
   6c326:	mov    rdi,QWORD PTR [rsp+0x190]
   6c32e:	cmp    ebp,0xb
   6c331:	jne    6c34c <sqlite3VdbeExec+0x1ceac>
   6c333:	cmp    BYTE PTR [r14+0x65],0x0
   6c338:	jne    6c34c <sqlite3VdbeExec+0x1ceac>
   6c33a:	movabs rax,0x200000000
   6c344:	or     rax,QWORD PTR [r14+0x30]
   6c348:	mov    QWORD PTR [r14+0x30],rax
   6c34c:	mov    ebp,DWORD PTR [rsp+0x400]
   6c353:	movzx  eax,bpl
   6c357:	test   eax,eax
   6c359:	jg     6c37a <sqlite3VdbeExec+0x1ceda>
   6c35b:	mov    QWORD PTR [rsp+0x1d0],r12
   6c363:	mov    r11,rbp
   6c366:	mov    rbp,r15
   6c369:	mov    r15,r13
   6c36c:	mov    r13,r11
   6c36f:	mov    r12d,0x1
   6c375:	jmp    6c449 <sqlite3VdbeExec+0x1cfa9>
   6c37a:	movzx  eax,bpl
   6c37e:	sub    eax,0x1
   6c381:	test   eax,eax
   6c383:	jl     6c3bb <sqlite3VdbeExec+0x1cf1b>
   6c385:	mov    rcx,QWORD PTR [r14+0x20]
   6c389:	shl    rax,0x5
   6c38d:	mov    rax,QWORD PTR [rcx+rax*1+0x18]
   6c392:	movzx  ecx,WORD PTR [rax+0x72]
   6c396:	or     ecx,0x8
   6c399:	mov    WORD PTR [rax+0x72],cx
   6c39d:	mov    rax,QWORD PTR [r14+0x20]
   6c3a1:	mov    rax,QWORD PTR [rax+0x38]
   6c3a5:	movzx  ecx,WORD PTR [rax+0x72]
   6c3a9:	or     ecx,0x8
   6c3ac:	mov    WORD PTR [rax+0x72],cx
   6c3b0:	mov    eax,DWORD PTR [r14+0x2c]
   6c3b4:	and    eax,0xffffffef
   6c3b7:	mov    DWORD PTR [r14+0x2c],eax
   6c3bb:	cmp    DWORD PTR [r14+0x48],0x0
   6c3c0:	je     6c3cc <sqlite3VdbeExec+0x1cf2c>
   6c3c2:	mov    QWORD PTR [rsp+0x1d8],rbx
   6c3ca:	jmp    6c425 <sqlite3VdbeExec+0x1cf85>
   6c3cc:	mov    QWORD PTR [rsp+0x1d8],rbx
   6c3d4:	xor    ebx,ebx
   6c3d6:	jmp    6c41f <sqlite3VdbeExec+0x1cf7f>
   6c3d8:	mov    rax,QWORD PTR [r14+0x20]
   6c3dc:	mov    rcx,rbx
   6c3df:	shl    rcx,0x5
   6c3e3:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   6c3e8:	movzx  eax,WORD PTR [rax+0x72]
   6c3ec:	and    eax,0x8
   6c3ef:	cmp    eax,0x8
   6c3f2:	jne    6c41c <sqlite3VdbeExec+0x1cf7c>
   6c3f4:	mov    rax,QWORD PTR [r14+0x20]
   6c3f8:	mov    rcx,rbx
   6c3fb:	shl    rcx,0x5
   6c3ff:	mov    rax,QWORD PTR [rax+rcx*1+0x18]
   6c404:	mov    QWORD PTR [rsp+0x190],rdi
   6c40c:	mov    rdi,rax
   6c40f:	call   6c414 <sqlite3VdbeExec+0x1cf74>
   6c414:	mov    rdi,QWORD PTR [rsp+0x190]
   6c41c:	add    ebx,0x1
   6c41f:	cmp    ebx,DWORD PTR [r14+0x28]
   6c423:	jl     6c3d8 <sqlite3VdbeExec+0x1cf38>
   6c425:	mov    QWORD PTR [rsp+0x1d0],r12
   6c42d:	mov    rbx,QWORD PTR [rsp+0x1d8]
   6c435:	mov    r11,rbp
   6c438:	mov    rbp,r15
   6c43b:	mov    r15,r13
   6c43e:	mov    r13,r11
   6c441:	mov    r12d,0x1
   6c447:	jmp    6c449 <sqlite3VdbeExec+0x1cfa9>
   6c449:	cmp    r15,rbx
   6c44c:	jb     6c4b5 <sqlite3VdbeExec+0x1d015>
   6c44e:	cmp    QWORD PTR [r14+0x208],0x0
   6c456:	je     6c4b5 <sqlite3VdbeExec+0x1d015>
   6c458:	mov    eax,DWORD PTR [r14+0x218]
   6c45f:	add    rbx,rax
   6c462:	mov    rax,QWORD PTR [r14+0x208]
   6c469:	mov    rcx,QWORD PTR [r14+0x210]
   6c470:	mov    QWORD PTR [rsp+0x190],rdi
   6c478:	mov    rdi,rcx
   6c47b:	mov    r10,rax
   6c47e:	call   r10
   6c481:	mov    rdi,QWORD PTR [rsp+0x190]
   6c489:	test   eax,eax
   6c48b:	je     6c449 <sqlite3VdbeExec+0x1cfa9>
   6c48d:	mov    rbx,0xffffffffffffffff
   6c494:	mov    r12d,0x9
   6c49a:	mov    QWORD PTR [rsp+0x1c8],rbp
   6c4a2:	mov    rbp,r12
   6c4a5:	mov    DWORD PTR [rsp+0x400],r13d
   6c4ad:	mov    r13,r15
   6c4b0:	jmp    4f762 <sqlite3VdbeExec+0x2c2>
   6c4b5:	mov    eax,r15d
   6c4b8:	add    eax,DWORD PTR [rdi+0xe4]
   6c4be:	mov    DWORD PTR [rdi+0xe4],eax
   6c4c4:	mov    eax,DWORD PTR [rdi+0xd0]
   6c4ca:	mov    eax,r12d
   6c4cd:	add    rsp,0x458
   6c4d4:	pop    r15
   6c4d6:	pop    r14
   6c4d8:	pop    r13
   6c4da:	pop    r12
   6c4dc:	pop    rbp
   6c4dd:	pop    rbx
   6c4de:	ret
